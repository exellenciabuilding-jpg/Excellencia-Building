/* V174 — Reçu de paiement de l'apprenant IDENTIQUE à celui du logiciel (index.html › Reçus de paiement).
 * Même gabarit, mêmes styles, même QR : le PDF téléchargé dans l'espace apprenant a le même aspect que
 * l'export PDF du logiciel (page courte de 105 mm de large).  API : EXBRecuInscription.pdfBlob(d) -> Promise<Blob>
 * d = {no, formation, participant, programme, inscription:{montant,statut}, formation_frais:{montant,statut},
 *      debut, lieu, distinction, reservation, directeur, url, logo}                                       */
(function(w){
  'use strict';
  var CSS='*{box-sizing:border-box}.paperP{width:800px;background:#fff;position:relative;font-family:Arial,Helvetica,sans-serif;color:#252b38}'
  +'.receipt{border:1px solid #e3e6eb;border-radius:18px;padding:42px 50px;color:#252b38}'
  +'.rhead{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:4px solid #173565;padding-bottom:10px}'
  +'.rbrandwrap{display:flex;align-items:center;gap:14px}.rlogo{width:70px;height:70px;object-fit:contain}.rbrand{font-size:30px;font-weight:900;color:#17447d}.rno{font-size:17px}'
  +'.rbox{margin-top:22px;background:#eaf0fb;border-left:6px solid #20498a;padding:18px 22px}.rtitle{font-size:25px;font-weight:900;color:#20498a}.rsubtitle{font-size:21px;margin-top:3px}'
  +'.rlabel{font-size:16px;font-weight:900;margin-top:25px}.rname{font-size:28px;font-weight:900;margin-top:5px}.rprogram{font-size:19px;line-height:1.35}'
  +'.rgrid{display:grid;grid-template-columns:1fr 1fr;gap:28px;margin-top:22px}.rval{font-size:24px;font-weight:900;margin-top:4px}'
  +'.paid{display:inline-block;background:#dff5e5;color:#14753a;padding:7px 12px;border-radius:6px}.unpaid{display:inline-block;background:#fde1e1;color:#b12b2b;padding:7px 12px;border-radius:6px}'
  +'.rfoot{margin-top:25px;border-top:1px solid #ddd;padding-top:18px;font-size:18px}'
  +'.rsign{margin-top:25px;display:flex;justify-content:space-between;align-items:flex-end}.rdir{font:italic 700 28px Georgia,serif;color:#23457c}.seal{font-size:17px;position:relative;min-width:230px;text-align:center;padding-top:70px}'
  +'.receiptQRBlock{display:flex;align-items:center;justify-content:center;gap:10px;border-top:1px dashed #d8dee8;margin-top:12px;padding-top:10px}'
  +'.receiptQRBlock .qr{width:120px;height:120px;flex:0 0 120px}.receiptQRBlock .qr img{display:block;width:120px;height:120px}.receiptQRBlock .qrh{font-size:9px;line-height:1.35;text-align:left;color:#5e6877;max-width:190px}';
  function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
  function stat(s,t){var u=String(s||'').toUpperCase();
    if(t==='ins')return /NON/.test(u)||!u?'<span class="unpaid">NON PAYÉ</span>':'<span class="paid">PAYÉ ✓</span>';
    return /NON/.test(u)||!u?'<span class="unpaid">NON PAYÉ</span>':/MOITI/.test(u)?'<span class="paid" style="color:#b45309">MOITIÉ PAYÉE</span>':'<span class="paid">PAYÉ ✓</span>'}
  function html(d,logo,qr){
    var fi=d.inscription||{},ff=d.formation_frais||{},prog=String(d.programme||'').split('\n').filter(function(x){return x.trim()});
    return '<div class="paperP receipt"><div class="rhead"><div class="rbrandwrap">'+(logo?'<img class="rlogo" src="'+logo+'" alt=""/>':'')+'<div class="rbrand">EXCELLENCIA BUILDING</div></div><div class="rno">N° : <b>'+esc(d.no)+'</b></div></div>'
    +'<div class="rbox"><div class="rtitle">REÇU D\'INSCRIPTION</div><div class="rsubtitle">'+esc(d.formation)+'</div></div>'
    +'<div class="rlabel">NOM &amp; PRÉNOM DU PARTICIPANT</div><div class="rname">'+esc(d.participant)+'</div>'
    +(prog.length?'<div class="rlabel">Programme de la formation :</div><div class="rprogram">'+prog.map(function(x){return '• '+esc(x)}).join('<br/>')+'</div>':'')
    +'<div class="rgrid"><div><div class="rlabel">FRAIS D\'INSCRIPTION</div><div class="rval">'+esc(fi.montant)+'</div></div><div><div class="rlabel">STATUT (INSCRIPTION)</div><div class="rval">'+stat(fi.statut,'ins')+'</div></div>'
    +'<div><div class="rlabel">FRAIS DE FORMATION</div><div class="rval">'+esc(ff.montant)+'</div></div><div><div class="rlabel">STATUT (FORMATION)</div><div class="rval">'+stat(ff.statut,'for')+'</div></div></div>'
    +'<div class="rlabel">DATE DE DÉBUT</div><div class="rval">'+esc(d.debut)+'</div>'
    +'<div class="rlabel">LIEU &amp; SALLE</div><div class="rprogram">'+esc(d.lieu)+'</div>'
    +'<div class="rfoot"><b>Distinction :</b> <span>'+esc(d.distinction)+'</span><br/><b>Réservation :</b> <span>'+esc(d.reservation)+'</span></div>'
    +'<div class="rsign"><div><div class="rdir">'+esc(d.directeur)+'</div><b>Directeur Général</b></div><div class="seal">Signature / Sceau<br/>autorisé</div></div>'
    +'<div class="receiptQRBlock"><div class="qr">'+(qr?'<img src="'+qr+'" alt=""/>':'')+'</div><div class="qrh">Scannez pour vérifier l’authenticité du reçu</div></div></div>'}
  function toDataUrl(src){return new Promise(function(ok){if(!src)return ok('');if(/^data:/.test(src))return ok(src);
    var im=new Image();im.onload=function(){try{var c=document.createElement('canvas');c.width=im.naturalWidth;c.height=im.naturalHeight;c.getContext('2d').drawImage(im,0,0);ok(c.toDataURL('image/png'))}catch(e){ok('')}};im.onerror=function(){ok('')};im.src=src})}
  /* HTML -> canvas (SVG foreignObject, hors connexion : aucune ressource externe) */
  function toCanvas(markup,wpx,scale){return new Promise(function(ok,ko){
    var host=document.createElement('div');host.style.cssText='position:fixed;left:-10000px;top:0;width:'+wpx+'px';host.innerHTML='<style>'+CSS+'</style>'+markup;document.body.appendChild(host);
    var el=host.querySelector('.paperP'),h=Math.ceil(el.getBoundingClientRect().height);host.remove();
    var svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+wpx*scale+'" height="'+h*scale+'" viewBox="0 0 '+wpx+' '+h+'"><foreignObject x="0" y="0" width="'+wpx+'" height="'+h+'"><div xmlns="http://www.w3.org/1999/xhtml"><style>'+CSS+'</style>'+markup+'</div></foreignObject></svg>';
    var im=new Image();im.onload=function(){var c=document.createElement('canvas');c.width=wpx*scale;c.height=h*scale;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);ok(c)};
    im.onerror=function(){ko(new Error('rendu du reçu'))};im.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)})}
  function bytes(s){var u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i)&255;return u}
  /* JPEG -> PDF d'une page (largeur 105 mm, hauteur proportionnelle : même format que l'export du logiciel) */
  function pdfOfJpeg(jpgBytes,pw,ph){
    var W=Math.round(105/25.4*72*10)/10,H=Math.round(W*ph/pw*10)/10,ch=[],pos=0,off=[];
    function P(x){var u=typeof x==='string'?bytes(x):x;ch.push(u);pos+=u.length}
    function O(n,head,stream){off[n]=pos;P(n+' 0 obj\n'+head);if(stream){P('\nstream\n');P(stream);P('\nendstream')}P('\nendobj\n')}
    var cs='q '+W+' 0 0 '+H+' 0 0 cm /I0 Do Q';
    P('%PDF-1.4\n');O(1,'<< /Type /Catalog /Pages 2 0 R >>');O(2,'<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
    O(3,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /XObject << /I0 4 0 R >> >> /Contents 5 0 R >>');
    O(4,'<< /Type /XObject /Subtype /Image /Width '+pw+' /Height '+ph+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+jpgBytes.length+' >>',jpgBytes);
    O(5,'<< /Length '+cs.length+' >>',bytes(cs));
    var xr=pos,x='xref\n0 6\n0000000000 65535 f \n';for(var j=1;j<=5;j++)x+=('0000000000'+off[j]).slice(-10)+' 00000 n \n';
    P(x+'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF');return new Blob(ch,{type:'application/pdf'})}
  async function pdfBlob(d){
    var logo=await toDataUrl(d.logo||'icon-192.png'),qr='';try{qr=d.url&&w.EXBVerif&&w.EXBVerif.qrPng?w.EXBVerif.qrPng(d.url):''}catch(e){}
    var c=await toCanvas(html(d,logo,qr),800,2),url=c.toDataURL('image/jpeg',.94),b=atob(url.split(',')[1]);
    return pdfOfJpeg(bytes(b),c.width,c.height)}
  w.EXBRecuInscription={html:html,pdfBlob:pdfBlob,css:CSS};
})(window);
