/* Excellencia Building V122 — Série B : contrats, notes et modes opératoires, dossier de chantier, textes libres.
 * Objectif : au moins 50 modèles par onglet « Pièces écrites ». N’écrase jamais un modèle existant.
 * Ces textes sont des bases courantes : à faire valider par votre conseil juridique (contrats surtout). */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA; if (!D) return;
  var FT = '\n\nFait à {{ville}}, le {{date}}';
  function merge(t, src) { var dst = D.models[t] || (D.models[t] = {}); Object.keys(src).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(dst, k)) dst[k] = src[k]; }); }
  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  /* ---------- CONTRATS ---------- */
  var CTX = function (title, A, B, objet, spec) {
    var n = 1, h = '# ' + title.toUpperCase() + '\nEntre {{societe_rep}}, ci-après « ' + A + ' », et ____________, ci-après « ' + B + ' ».\n## Article 1 — Objet\n' + objet;
    spec.split('||').forEach(function (s) { var p = s.split('::'); n++; h += '\n## Article ' + n + ' — ' + p[0] + '\n' + p[1]; });
    h += '\n## Article ' + (n + 1) + ' — Durée\nDu ____________ au ____________, renouvelable par accord écrit des parties.' +
      '\n## Article ' + (n + 2) + ' — Prix et paiement\nPrix : ____________ ; paiement dans un délai de ___ jours après facture ou situation approuvée.' +
      '\n## Article ' + (n + 3) + ' — Résiliation\nChaque partie peut résilier le contrat après mise en demeure restée sans effet pendant ___ jours.' +
      '\n## Article ' + (n + 4) + ' — Litiges\nRèglement amiable d’abord ; à défaut, tribunaux compétents de {{ville}} ({{pays}}).' + FT +
      '\n| ' + cap(A) + ' | ' + cap(B) + ' |\n| Lu et approuvé | Lu et approuvé |';
    return h;
  };
  var MO = 'le maître d’ouvrage', EN = 'l’entreprise', PR = 'le prestataire', FO = 'le fournisseur', LO = 'le loueur', AC = 'l’acheteur';
  var CTL = [
    ['Contrat de travaux de gros œuvre', MO, EN, 'Exécution des travaux de gros œuvre du projet {{projet}} à {{lieu}}.', 'Consistance::Fondations, structure béton armé, maçonnerie et dalles selon plans et CCTP.||Matériaux::Fournis par l’entreprise, conformes aux normes et approuvés avant mise en œuvre.||Délai::___ jours calendaires, pénalité de retard de ___ ‰ par jour.'],
    ['Contrat de travaux de terrassement', MO, EN, 'Exécution des terrassements du projet {{projet}} : décapage, fouilles, remblais et évacuation.', 'Quantités::Mesurées contradictoirement ; payées au mètre cube réellement exécuté.||Évacuation::Les déblais sont évacués vers un site autorisé.||Réseaux::L’entreprise localise les réseaux existants avant toute fouille.'],
    ['Contrat de travaux de maçonnerie', MO, EN, 'Exécution des travaux de maçonnerie, chaînages et enduits du projet {{projet}}.', 'Qualité::Alignement, aplomb et planéité conformes au CCTP.||Matériaux::Blocs, ciment et sable conformes et stockés à l’abri.||Réception::Réception par ouvrage, avec levée des réserves avant paiement du solde.'],
    ['Contrat de travaux de plomberie', MO, EN, 'Fourniture et pose des installations de plomberie sanitaire du projet {{projet}}.', 'Essais::Essai de pression et d’étanchéité avant fermeture des gaines.||Garantie::Garantie de ___ mois sur la fourniture et la pose.||Documents::Remise des plans de récolement et notices.'],
    ['Contrat de travaux d’électricité', MO, EN, 'Fourniture et pose des installations électriques du projet {{projet}}.', 'Normes::Installations conformes aux normes en vigueur en {{pays}} et au CCTP.||Essais::Mesures d’isolement et de terre remises par écrit.||Garantie::Garantie de ___ mois.'],
    ['Contrat de travaux de peinture', MO, EN, 'Exécution des travaux de peinture intérieure et extérieure du projet {{projet}}.', 'Préparation::Rebouchage, ponçage et sous-couche avant finition.||Teintes::Teintes et marques approuvées par le maître d’ouvrage.||Protection::Protection des sols et menuiseries pendant les travaux.'],
    ['Contrat de travaux de carrelage', MO, EN, 'Fourniture et pose de carrelage du projet {{projet}}.', 'Pose::Calepinage validé, joints réguliers, planéité contrôlée.||Fournitures::Carreaux de choix ___ ; réserve de ___ % pour réparations futures.||Réception::Contrôle à la fin de la pose, avant jointoiement.'],
    ['Contrat de travaux de toiture et charpente', MO, EN, 'Exécution de la charpente et de la couverture du projet {{projet}}.', 'Matériaux::Bois traité ou métal protégé, tôles ou tuiles conformes.||Étanchéité::Essai d’étanchéité avant réception.||Sécurité::Protections contre les chutes de hauteur obligatoires.'],
    ['Contrat de travaux de menuiserie', MO, EN, 'Fabrication et pose des menuiseries (portes, fenêtres) du projet {{projet}}.', 'Dimensions::Relevées sur place avant fabrication.||Quincaillerie::Marques et qualité approuvées par le maître d’œuvre.||Garantie::Garantie de ___ mois sur le fonctionnement.'],
    ['Contrat de travaux d’étanchéité', MO, EN, 'Exécution de l’étanchéité des toitures-terrasses et ouvrages enterrés du projet {{projet}}.', 'Support::Support propre, sec et réceptionné avant application.||Essai::Essai de mise en eau de ___ heures.||Garantie::Garantie d’étanchéité de ___ ans.'],
    ['Contrat de travaux de ferraillage', MO, EN, 'Façonnage et pose des armatures du projet {{projet}} d’après les plans de ferraillage.', 'Contrôle::Aucun coulage sans accord écrit sur le ferraillage.||Tolérances::Enrobages et espacements conformes aux plans.||Fournitures::Aciers certifiés, stockés à l’abri.'],
    ['Contrat de construction d’une villa (clé en main)', MO, EN, 'Construction clé en main d’une villa à {{lieu}} selon plans, descriptif et devis annexés.', 'Prix forfaitaire::Prix ferme et non révisable sauf modification demandée par écrit.||Échéancier de paiement::Acomptes à la signature, aux fondations, au gros œuvre, aux finitions et à la remise des clés.||Modifications::Toute modification fait l’objet d’un avenant signé.'],
    ['Contrat de construction d’un immeuble', MO, EN, 'Construction d’un immeuble de ___ niveaux à {{lieu}} selon les plans et pièces du marché.', 'Autorisations::Le maître d’ouvrage remet les autorisations nécessaires avant le démarrage.||Phasage::Exécution par phases validées par procès-verbal.||Assurances::L’entreprise souscrit les assurances de chantier requises.'],
    ['Contrat de construction d’un mur de clôture', MO, EN, 'Construction d’un mur de clôture de ___ mètres linéaires à {{lieu}}.', 'Hauteur et matériaux::Hauteur ___ m ; blocs de ___ cm ; fondations conformes au plan.||Portail::Fourniture et pose d’un portail selon le devis annexé.||Délai::___ jours à compter de la remise du terrain.'],
    ['Contrat de rénovation / réhabilitation', MO, EN, 'Travaux de rénovation et de réhabilitation du bâtiment situé à {{lieu}}.', 'État des lieux::Un constat contradictoire est établi avant travaux.||Imprévus::Les travaux imprévus sont chiffrés et acceptés par écrit.||Occupation::Les travaux tiennent compte de l’occupation éventuelle des lieux.'],
    ['Contrat de maîtrise d’œuvre complète', MO, 'le maître d’œuvre', 'Mission complète de maîtrise d’œuvre du projet {{projet}} : conception, plans, dossier de consultation, suivi et réception.', 'Éléments de mission::Esquisse, avant-projet, projet, consultation des entreprises, direction et réception des travaux.||Honoraires::___ % du montant des travaux, payés par phases d’avancement.||Responsabilité::Le maître d’œuvre répond de ses études et de son suivi.'],
    ['Contrat de conduite de travaux', MO, PR, 'Conduite et coordination des travaux du projet {{projet}} sur le chantier de {{lieu}}.', 'Missions::Planning, suivi des entreprises, réunions, comptes rendus et rapports.||Présence::Présence sur chantier au moins ___ jours par semaine.||Rendu::Rapport hebdomadaire au maître d’ouvrage.'],
    ['Contrat d’assistance à maîtrise d’ouvrage', MO, PR, 'Assistance du maître d’ouvrage pour le projet {{projet}} : programme, budget, choix des intervenants et suivi.', 'Prestations::Aide à la décision, analyse des offres, suivi budgétaire.||Indépendance::Le prestataire agit dans l’intérêt exclusif du maître d’ouvrage.||Livrables::Notes et rapports remis à chaque étape.'],
    ['Contrat de contrôle technique', MO, PR, 'Mission de contrôle technique du projet {{projet}} (solidité, sécurité, conformité).', 'Documents::Plans et notes de calcul transmis avant exécution.||Visites::Visites de contrôle aux étapes clés du chantier.||Rapports::Rapport de contrôle après chaque visite.'],
    ['Contrat d’études géotechniques', MO, PR, 'Étude géotechnique du terrain situé à {{lieu}} : sondages, essais et recommandations de fondations.', 'Campagne::Nombre et profondeur des sondages : ____________.||Rapport::Rapport avec portance du sol et type de fondations conseillé.||Accès::Le maître d’ouvrage garantit l’accès au terrain.'],
    ['Contrat de levé topographique', MO, PR, 'Levé topographique et implantation du terrain situé à {{lieu}}.', 'Prestations::Levé, plan coté, courbes de niveau, bornage et implantation des axes.||Précision::Tolérance de ___ cm.||Livrables::Plans papier et fichiers numériques.'],
    ['Contrat d’ordonnancement, pilotage et coordination (OPC)', MO, PR, 'Mission d’ordonnancement, pilotage et coordination du projet {{projet}}.', 'Planning::Établissement et mise à jour du planning détaillé.||Coordination::Animation des réunions de coordination entre corps d’état.||Reporting::Tableau de bord mensuel.'],
    ['Contrat de fourniture de béton prêt à l’emploi', AC, FO, 'Fourniture de béton prêt à l’emploi pour le projet {{projet}}.', 'Qualité::Classe de résistance ___, affaissement ___ cm, bon de livraison pour chaque toupie.||Livraison::Rythme de livraison convenu à l’avance, tolérance de retard ___ minutes.||Essais::Le fournisseur accepte les prélèvements d’éprouvettes.'],
    ['Contrat de fourniture de sable et de gravier', AC, FO, 'Fourniture de sable et gravier pour le projet {{projet}}.', 'Granulométrie::Matériaux propres, conformes à la granulométrie demandée.||Livraison::Voyages de ___ m³, livrés à {{lieu}}.||Contrôle::Quantité vérifiée à chaque livraison.'],
    ['Contrat de fourniture d’acier', AC, FO, 'Fourniture d’aciers pour béton armé pour le projet {{projet}}.', 'Qualité::Aciers certifiés, diamètres et longueurs selon la liste annexée.||Livraison::Livraisons échelonnées selon planning.||Certificats::Remise des certificats de conformité.'],
    ['Contrat de transport de matériaux', AC, 'le transporteur', 'Transport de matériaux vers le chantier {{projet}} à {{lieu}}.', 'Prestations::Chargement, transport et déchargement aux points convenus.||Responsabilité::Le transporteur répond de la perte ou de l’avarie pendant le transport.||Tarif::Prix par voyage ou par tonne : ____________.'],
    ['Contrat de location d’engin avec chauffeur', 'le locataire', LO, 'Location de l’engin ____________ avec chauffeur pour le chantier {{projet}}.', 'Heures::Minimum de ___ heures par jour ; heures supplémentaires au tarif de ____________.||Carburant::À la charge du ____________.||Sécurité::Le chauffeur respecte le règlement du chantier.'],
    ['Contrat de location d’échafaudage', 'le locataire', LO, 'Location d’échafaudage pour le chantier {{projet}}.', 'Montage::Montage et démontage par ____________ selon les règles de sécurité.||Vérification::Réception de l’échafaudage avant usage.||Perte et casse::Éléments manquants ou abîmés facturés selon barème.'],
    ['Contrat de gardiennage de chantier', MO, PR, 'Gardiennage du chantier {{projet}} à {{lieu}}.', 'Horaires::De ___ h à ___ h, ___ jours par semaine.||Consignes::Contrôle des accès, ronde, registre des entrées.||Responsabilité::Le prestataire répond des vols dus à un défaut de surveillance.'],
    ['Contrat de nettoyage de chantier', MO, PR, 'Nettoyage du chantier {{projet}} : évacuation des déchets et nettoyage de fin de travaux.', 'Fréquence::Nettoyage ___ fois par semaine et nettoyage final avant réception.||Déchets::Évacuation vers un site autorisé.||Produits::Produits adaptés aux surfaces.'],
    ['Contrat de main-d’œuvre journalière', EN, 'l’ouvrier', 'Emploi de l’ouvrier en qualité de ____________ sur le chantier {{projet}}, rémunéré à la journée.', 'Salaire::___ par jour travaillé, payé chaque ____________.||Horaires::De ___ h à ___ h, du ____ au ____.||Sécurité::Port obligatoire des équipements de protection fournis.'],
    ['Contrat de travail à durée déterminée (ouvrier de chantier)', EN, 'le salarié', 'Embauche du salarié en qualité de ____________ pour la durée du chantier {{projet}}.', 'Rémunération::___ par mois, avantages éventuels : ____________.||Période d’essai::___ jours.||Fin de contrat::À l’achèvement du chantier ou à la date convenue.'],
    ['Contrat de stage', EN, 'le stagiaire', 'Accueil du stagiaire pour un stage de ____________ au sein de {{societe}}.', 'Mission::Tâches confiées : ____________, sous l’encadrement de ____________.||Gratification::___ par mois (si applicable).||Confidentialité::Le stagiaire s’engage à la confidentialité des informations.'],
    ['Contrat de prestation de conseil', 'le client', PR, 'Prestation de conseil en ____________ pour le compte de {{societe}}.', 'Livrables::Notes, recommandations et rapport final.||Honoraires::Forfait de ____________ ou taux journalier de ____________.||Confidentialité::Les informations échangées restent confidentielles.'],
    ['Contrat de bail d’un local ou d’un dépôt', 'le bailleur', 'le locataire', 'Location d’un local/dépôt situé à ____________ destiné à ____________.', 'Loyer::___ par mois, payable d’avance le ___ du mois.||Garantie::Dépôt de garantie de ____________.||Entretien::Menues réparations à la charge du locataire.'],
    ['Contrat de vente de matériel', 'le vendeur', AC, 'Vente du matériel suivant : ____________, en l’état.', 'Prix::____________, payé comptant / selon échéancier.||Transfert de propriété::À la réception du paiement intégral.||Garantie::___ mois / vendu sans garantie.'],
    ['Contrat d’entretien et de maintenance', 'le client', PR, 'Entretien et maintenance des installations suivantes : ____________.', 'Visites::___ visites par an et interventions de dépannage sous ___ heures.||Pièces::Pièces fournies à la charge du ____________.||Rapport::Rapport après chaque visite.'],
    ['Contrat de groupement d’entreprises', 'le mandataire', 'le cotraitant', 'Groupement pour répondre au marché {{projet}} et l’exécuter.', 'Répartition::Les travaux sont répartis selon l’annexe ; chacun répond de sa part.||Mandataire::Le mandataire représente le groupement auprès du maître d’ouvrage.||Partage::Résultat et charges répartis selon les parts : ____________.'],
    ['Contrat de cotraitance', 'le mandataire', 'le cotraitant', 'Cotraitance pour l’exécution du lot « {{lot}} » du projet {{projet}}.', 'Part::Le cotraitant exécute ___ % du lot.||Coordination::Réunions communes et planning commun.||Paiement::Paiement proportionnel aux travaux exécutés.'],
    ['Contrat d’apporteur d’affaires', 'le mandant', 'l’apporteur', 'Mise en relation de {{societe}} avec des clients potentiels pour des travaux de bâtiment.', 'Rémunération::___ % du montant hors taxes du marché signé grâce à l’apporteur.||Exclusivité::Sans exclusivité sauf accord écrit.||Déontologie::Aucun engagement n’est pris au nom du mandant.'],
    ['Contrat de mandat de représentation du maître d’ouvrage', MO, 'le mandataire', 'Représentation du maître d’ouvrage dans le suivi administratif et technique du projet {{projet}}.', 'Pouvoirs::Signer les ordres de service dans la limite de ____________.||Comptes::Reddition de comptes ___ fois par an.||Durée::Jusqu’à la réception définitive.'],
    ['Contrat de réservation d’un bien sur plan', 'le promoteur', 'le réservataire', 'Réservation du bien ____________ du projet {{projet}} à {{lieu}}.', 'Prix::____________ ; acompte de réservation de ____________.||Délai de livraison::Prévu le ____________.||Rétractation::Remboursement de l’acompte si le projet n’est pas réalisé.'],
    ['Contrat de prestation de modélisation et dessin (BIM)', 'le client', PR, 'Modélisation 3D et production des plans du projet {{projet}}.', 'Livrables::Maquette numérique, plans, coupes, façades et nomenclatures.||Corrections::___ cycles de corrections inclus.||Propriété::Les fichiers sources restent propriété du prestataire jusqu’au paiement intégral.'],
    ['Contrat de plans d’architecte (esquisse et avant-projet)', MO, 'l’architecte', 'Réalisation de l’esquisse et de l’avant-projet du bâtiment à {{lieu}}.', 'Phases::Esquisse, avant-projet sommaire, avant-projet détaillé.||Honoraires::___ % du coût estimé des travaux, payés à chaque phase.||Propriété::Le droit d’auteur reste à l’architecte ; usage limité à ce projet.'],
    ['Contrat de décoration et d’aménagement intérieur', 'le client', PR, 'Conception et réalisation de l’aménagement intérieur de {{lieu}}.', 'Concept::Plans d’ambiance et choix validés par le client.||Fournitures::Mobilier et matériaux selon le devis.||Réception::Réception pièce par pièce.'],
    ['Contrat d’installation de panneaux solaires', 'le client', EN, 'Fourniture et installation d’un système solaire de ___ kW à {{lieu}}.', 'Équipements::Panneaux, onduleur, batteries et câblage selon la fiche technique.||Mise en service::Essais et formation à l’utilisation.||Garantie::Garantie matériel ___ ans et installation ___ ans.'],
    ['Contrat de sous-traitance de main-d’œuvre', EN, 'le sous-traitant', 'Mise à disposition de main-d’œuvre qualifiée pour le chantier {{projet}}.', 'Effectif::___ personnes de catégorie ____________.||Encadrement::Le sous-traitant encadre ses agents.||Conformité::Le sous-traitant déclare et assure son personnel.'],
    ['Contrat d’assurance de chantier — engagement de souscription', MO, EN, 'Engagement de l’entreprise à souscrire les assurances nécessaires au chantier {{projet}}.', 'Garanties::Responsabilité civile, accidents du travail, dommages aux ouvrages.||Preuve::Attestations remises avant démarrage.||Défaut::À défaut, le maître d’ouvrage peut suspendre le démarrage.']
  ];
  var CT = {}; CTL.forEach(function (r) { CT[r[0]] = CTX(r[0], r[1], r[2], r[3], r[4]); });
  merge('contrat', CT);

  /* ---------- NOTES, MODES OPÉRATOIRES, PLANS ---------- */
  var MOX = function (t, steps, risks, ctrl) {
    return '# MODE OPÉRATOIRE — ' + t.toUpperCase() + '\nProjet : {{projet}} — {{lieu}}\nEntreprise : {{entreprise}} · Lot : {{lot}}\n## 1. Moyens\n- Personnel : ____________ — matériel : ____________ — matériaux : ____________\n## 2. Étapes d’exécution\n' +
      steps.split('|').map(function (s, i) { return (i + 1) + '. ' + s; }).join('\n') +
      '\n## 3. Risques et prévention\n' + risks.split('|').map(function (s) { return '- ' + s; }).join('\n') +
      '\n## 4. Contrôles\n' + ctrl.split('|').map(function (s) { return '- ' + s; }).join('\n') + FT;
  };
  var MOL = [
    ['Terrassement général', 'Implantation et piquetage|Décapage de la terre végétale|Déblais et chargement|Évacuation ou stockage|Réglage du fond de forme', 'Engins en circulation : signaleur obligatoire|Réseaux enterrés : repérage préalable|Stabilité des talus', 'Niveaux de fond de forme|Compactage|Propreté de la plate-forme'],
    ['Fouilles en tranchée', 'Traçage des axes|Excavation par passes|Blindage ou talutage|Nettoyage du fond|Réception de la fouille', 'Éboulement : talutage ou blindage|Chute de personnes : protection en rive|Eau dans la fouille : pompage', 'Profondeur|Largeur|Nature du sol rencontré'],
    ['Fondations superficielles (semelles)', 'Réception du fond de fouille|Béton de propreté|Pose du ferraillage et des cales|Coffrage latéral|Coulage et vibration|Cure du béton', 'Manutention des aciers|Circulation autour des fouilles|Projection de laitance', 'Cotes et dimensions|Enrobage|Éprouvettes de béton'],
    ['Poteaux et voiles en béton armé', 'Ferraillage selon plan|Coffrage et étaiement|Contrôle avant coulage|Coulage par couches|Décoffrage après durcissement', 'Travail en hauteur|Chute d’objets|Effondrement du coffrage', 'Aplomb|Enrobage|Qualité du béton'],
    ['Dalle et plancher en béton armé', 'Étaiement et coffrage|Pose des armatures et des réservations|Contrôle|Coulage et talochage|Cure et maintien des étais', 'Chutes en rive|Surcharge de coffrage|Électricité provisoire', 'Planéité|Épaisseur|Délai de décoffrage'],
    ['Maçonnerie de blocs', 'Traçage et première assise|Pose en élévation avec joints décalés|Chaînages et linteaux|Réservations|Contrôle d’aplomb', 'Manutention des blocs|Travail sur échafaudage|Poussières', 'Aplomb et alignement|Épaisseur des joints|Chaînages'],
    ['Enduit de façade et intérieur', 'Préparation et humidification du support|Gobetis|Corps d’enduit|Finition talochée|Protection contre le soleil', 'Projections dans les yeux|Travail en hauteur', 'Planéité|Adhérence|Fissures'],
    ['Chape et ragréage', 'Nettoyage du support|Pose des repères de niveau|Mise en œuvre du mortier|Réglage à la règle|Cure', 'Port de charges|Poussières de ciment', 'Niveau|Planéité|Délai de séchage'],
    ['Pose de carrelage', 'Vérification de la planéité|Calepinage|Encollage et pose|Contrôle des joints|Jointoiement et nettoyage', 'Poussières de coupe|Postures de travail', 'Alignement|Adhérence|Propreté'],
    ['Travaux de peinture', 'Protection des sols et menuiseries|Rebouchage et ponçage|Sous-couche|Couches de finition|Retouches', 'Vapeurs et ventilation|Travail en hauteur', 'Uniformité|Nombre de couches|Raccords'],
    ['Étanchéité de toiture-terrasse', 'Nettoyage du support|Primaire d’accrochage|Pose de la membrane|Relevés et points singuliers|Essai de mise en eau', 'Travaux à chaud : permis de feu|Chute en rive', 'Recouvrements|Pentes|Étanchéité à l’eau'],
    ['Charpente et couverture', 'Réception des appuis|Levage et assemblage de la charpente|Contreventement|Pose des liteaux et de la couverture|Faîtage et rives', 'Chute de hauteur : harnais et filets|Vent|Levage', 'Équerrage|Fixations|Étanchéité'],
    ['Plomberie sanitaire', 'Traçage des réseaux|Pose des alimentations|Pose des évacuations avec pente|Essai de pression|Pose des appareils', 'Coupures et brûlures|Eau sous pression', 'Pressions|Pentes|Absence de fuites'],
    ['Installation électrique', 'Traçage et saignées|Pose des gaines et boîtes|Tirage des câbles|Pose du tableau|Mesures et mise sous tension', 'Électrisation : consignation|Travail en hauteur', 'Isolement|Terre|Repérage des circuits'],
    ['Faux plafonds', 'Traçage des niveaux|Fixation de l’ossature|Pose des plaques|Joints et enduits|Finitions', 'Chutes depuis échafaudage|Poussières', 'Niveau|Fixations|Joints'],
    ['Pose de menuiseries', 'Contrôle des dimensions|Pose et calage|Scellement|Réglage|Finitions', 'Manutention de vitrages|Coupures', 'Aplomb|Fonctionnement|Étanchéité'],
    ['Montage d’échafaudage', 'Vérification du sol|Pose des socles et calage|Montage par niveaux|Pose des garde-corps|Réception avant usage', 'Chute de hauteur|Effondrement|Chute d’objets', 'Stabilité|Garde-corps complets|Vérification quotidienne'],
    ['Démolition d’ouvrage', 'Diagnostic des structures|Déconnexion des réseaux|Balisage|Démolition progressive|Tri et évacuation', 'Effondrement|Poussières|Chute d’éléments', 'Périmètre de sécurité|Stabilité des parties conservées'],
    ['Remblaiement et compactage', 'Préparation du fond|Mise en œuvre par couches|Arrosage|Compactage|Contrôle de densité', 'Circulation d’engins|Vibrations', 'Épaisseur des couches|Densité|Planéité'],
    ['Pose de pavés et bordures', 'Fondation et lit de sable|Pose des bordures|Pose des pavés|Compactage|Jointoiement au sable', 'Manutention|Poussières', 'Niveaux et pentes|Alignement'],
    ['Construction de clôture et portail', 'Implantation des poteaux|Fondations des poteaux|Élévation du mur ou pose de grillage|Pose du portail|Finitions', 'Manutention|Soudure : permis de feu', 'Alignement|Solidité|Fonctionnement du portail'],
    ['Levage et manutention d’éléments lourds', 'Étude du levage|Contrôle de l’engin et des accessoires|Balisage|Levage guidé|Dépose et calage', 'Chute de charge|Renversement de l’engin', 'Charge maximale|Habilitation du conducteur']
  ];
  var NT = {}; MOL.forEach(function (r) { NT['Mode opératoire — ' + r[0]] = MOX(r[0], r[1], r[2], r[3]); });

  var NX = function (t, body) { return '# ' + t.toUpperCase() + '\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}}\n' + body + FT; };
  var NOL = [
    ['Note de service', 'À tout le personnel du chantier.\n## Objet\n{{objet}}\n## Dispositions\n- ____________________\n- ____________________\nCes dispositions s’appliquent à compter du {{date_effet}}.'],
    ['Note d’information au personnel', 'À tout le personnel.\n## Information\n{{objet}}\n## À retenir\n- ____________________'],
    ['Note de procédure d’achat', '## But\nEncadrer les achats du chantier.\n## Étapes\n1. Demande d’achat visée par le chef de chantier.\n2. Consultation de ___ fournisseurs.\n3. Choix et bon de commande signé.\n4. Réception et contrôle.\n5. Paiement après contrôle de la facture.'],
    ['Note de cadrage du projet', '## Contexte\n____________________\n## Objectifs\n- ____________________\n## Périmètre\n____________________\n## Budget et délai\n- Budget : ____________ — délai : ____________\n## Intervenants\n- ____________________'],
    ['Note technique — observations sur plans', 'Plans examinés : ____________ indice ____\n| N° | Observation | Gravité | Réponse attendue |\n| 1 | ____________ | ____________ | ____________ |\n| 2 | ____________ | ____________ | ____________ |'],
    ['Note de synthèse de visite de chantier', '## Constats\n- ____________________\n## Points positifs\n- ____________________\n## Points à corriger\n- ____________________\n## Recommandations\n- ____________________'],
    ['Note d’organisation du chantier', '## Organigramme\n- Chef de chantier : ____________ — responsable sécurité : ____________ — magasinier : ____________\n## Horaires\n- De ___ h à ___ h\n## Zones\n- Stockage : ____________ — base de vie : ____________ — accès : ____________'],
    ['Note de recommandations de sécurité', '## Recommandations\n- Port obligatoire des équipements de protection.\n- Interdiction de travailler seul en fouille ou en hauteur.\n- Signalement immédiat de tout danger.\n- Respect des limitations de vitesse des engins.'],
    ['Note de suivi budgétaire', '| Poste | Budget | Dépensé | Reste à dépenser | Écart |\n| ____________ | ____ | ____ | ____ | ____ |\n| ____________ | ____ | ____ | ____ | ____ |\n## Commentaire\n____________________'],
    ['Note de justification de dépassement', '## Dépassement constaté\nPoste : ____________ — montant : ____________\n## Causes\n- ____________________\n## Mesures correctives\n- ____________________\n## Demande\nApprobation du maître d’ouvrage : oui / non'],
    ['Note de justification de prix', 'Prix unitaire concerné : ____________\n| Composante | Quantité | Prix unitaire | Montant |\n| Main-d’œuvre | ____ | ____ | ____ |\n| Matériaux | ____ | ____ | ____ |\n| Matériel | ____ | ____ | ____ |\n| Frais généraux et marge | ____ | ____ | ____ |'],
    ['Note de demande de dérogation', '## Exigence concernée\n____________________\n## Dérogation demandée\n{{objet}}\n## Justification\n____________________\n## Mesures compensatoires\n____________________'],
    ['Note de réponse technique', 'Question posée : ____________\n## Réponse\n____________________\n## Documents de référence\n- ____________________'],
    ['Note de passation de chantier', '## État d’avancement\n____________________\n## Points sensibles\n- ____________________\n## Documents et accès remis\n- ____________________\n## Contacts\n- ____________________'],
    ['Note de planning prévisionnel', '| Tâche | Début | Fin | Durée | Responsable |\n| ____________ | ____ | ____ | ____ | ____________ |\n| ____________ | ____ | ____ | ____ | ____________ |\n| ____________ | ____ | ____ | ____ | ____________ |'],
    ['Note sur les horaires et le pointage', '## Horaires\nDe ___ h à ___ h, pause de ___ h à ___ h.\n## Pointage\nChaque agent pointe à l’arrivée et au départ ; tout retard est consigné.'],
    ['Note de gestion du matériel', '## Règles\n- Tout matériel sort avec un bon de sortie signé.\n- Les outils sont rangés chaque soir.\n- Toute perte ou casse est signalée immédiatement.\n## Responsable\n____________'],
    ['Note de protection du chantier contre les vols', '## Mesures\n- Clôture et portail fermés à clé.\n- Gardiennage de nuit.\n- Inventaire quotidien du matériel sensible.\n- Éclairage des zones de stockage.'],
    ['Note de gestion de crise (accident grave)', '## Premiers gestes\n1. Sécuriser la zone et porter secours.\n2. Appeler les secours : ____________.\n3. Prévenir la direction et la maîtrise d’œuvre.\n4. Préserver les lieux.\n5. Rédiger le rapport d’accident.'],
    ['Note de préparation de la saison des pluies', '## Mesures\n- Drainage et évacuation des eaux.\n- Bâchage et protection des matériaux.\n- Stockage surélevé du ciment.\n- Arrêt des travaux en cas d’orage.'],
    ['Note de recommandations d’entretien des ouvrages', '| Ouvrage | Entretien | Fréquence |\n| Toiture | ____________ | ____ |\n| Peintures | ____________ | ____ |\n| Plomberie | ____________ | ____ |\n| Électricité | ____________ | ____ |'],
    ['Note de description des travaux', '## Consistance des travaux\n- ____________________\n## Matériaux principaux\n- ____________________\n## Particularités\n- ____________________'],
    ['Note de programme des travaux de la semaine', '| Jour | Travaux prévus | Équipe | Matériel |\n| Lundi | ____________ | ____ | ____ |\n| Mardi | ____________ | ____ | ____ |\n| Mercredi | ____________ | ____ | ____ |\n| Jeudi | ____________ | ____ | ____ |\n| Vendredi | ____________ | ____ | ____ |'],
    ['Note d’analyse des offres', '| Entreprise | Prix | Délai | Références | Note technique |\n| ____________ | ____ | ____ | ____ | ____ |\n| ____________ | ____ | ____ | ____ | ____ |\n## Proposition\nEntreprise recommandée : ____________'],
    ['Note de choix de matériaux', '| Option | Avantages | Inconvénients | Prix |\n| ____________ | ____________ | ____________ | ____ |\n| ____________ | ____________ | ____________ | ____ |\n## Choix retenu\n____________'],
    ['Note de cadrage qualité', '## Exigences\n- ____________________\n## Points de contrôle\n- ____________________\n## Responsables\n- ____________________']
  ];
  NOL.forEach(function (r) { NT[r[0]] = NX(r[0], r[1]); });
  merge('note', NT);

  /* ---------- DOSSIER DE CHANTIER ---------- */
  var PG = function (t) {
    return '# ' + t.toUpperCase() + '\n## {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}}\nEntreprise : {{societe}}\nPermis / autorisation : {{permis}}\nPhase : {{phase}}\nDate d’édition : {{date}} · Indice : ____\n\nChaque page du PDF porte un QR code de vérification : son scan ouvre la page publique d’authenticité du document.';
  };
  var LP = function (t, pieces) {
    return '# ' + t.toUpperCase() + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{societe}}\n| N° | Pièce | Présente | Observation |\n' +
      pieces.split('|').map(function (p, i) { return '| ' + (i + 1) + ' | ' + p + ' | oui / non | ____________ |'; }).join('\n') + '\nVérifié par : ____________ — le {{date}}';
  };
  var DS = {};
  ['dossier de consultation des entreprises', 'dossier d’offre', 'dossier technique', 'dossier de permis de construire', 'dossier de réception', 'dossier des ouvrages exécutés', 'dossier qualité', 'dossier hygiène et sécurité', 'dossier financier', 'dossier de sous-traitant', 'dossier administratif du marché', 'dossier de suivi de chantier', 'dossier de maintenance', 'dossier d’archivage', 'dossier photographique', 'dossier de plans d’exécution', 'dossier de présentation du projet'].forEach(function (t) { DS['Page de garde — ' + t] = PG(t); });
  var LPL = [
    ['Dossier d’offre (réponse à un appel d’offres)', 'Lettre de soumission|Présentation de l’entreprise|Références de chantiers similaires|Mémoire technique|Planning prévisionnel|Bordereau de prix et devis|Attestations d’assurance|Pièces administratives de l’entreprise'],
    ['Dossier de consultation des entreprises', 'Règlement de consultation|CCAP|CCTP|Plans|Bordereau quantitatif|Planning directeur|Modèle de cadre de réponse'],
    ['Dossier de permis de construire', 'Formulaire de demande|Titre de propriété|Plan de situation|Plan de masse|Plans des niveaux|Façades et coupes|Notice descriptive|Étude de sol'],
    ['Dossier de démarrage de chantier', 'Ordre de service de démarrage|Planning d’exécution|Plan d’installation de chantier|Plan d’hygiène et de sécurité|Attestations d’assurance|Liste du personnel|Autorisations administratives'],
    ['Dossier de suivi mensuel', 'Rapport mensuel|Situation de travaux|Comptes rendus de réunion|Rapports de contrôle|Photos datées|Journal de chantier'],
    ['Dossier de réception provisoire', 'Demande de réception|Liste des réserves|Procès-verbal de réception|Résultats d’essais|Attestations de conformité|Plans de récolement'],
    ['Dossier de réception définitive', 'Procès-verbal de levée des réserves|Attestations de garantie|Décompte général définitif|Procès-verbal de réception définitive|Restitution de la retenue de garantie'],
    ['Dossier des ouvrages exécutés (DOE)', 'Plans de récolement|Notices d’utilisation et d’entretien|Fiches techniques des matériaux|Certificats et essais|Garanties|Attestations d’assurance'],
    ['Dossier qualité du chantier', 'Plan d’assurance qualité|Fiches de contrôle|Rapports d’essais|Fiches de non-conformité|Procès-verbaux de réception de supports'],
    ['Dossier hygiène, sécurité et environnement', 'Plan d’hygiène et de sécurité|Registre des accidents|Fiches d’accueil sécurité|Rapports HSE|Rapport de gestion des déchets|Attestations d’aptitude'],
    ['Dossier financier du chantier', 'Marché et avenants|Situations de travaux|Factures et paiements|Retenues de garantie|Suivi budgétaire|Décompte final'],
    ['Dossier du sous-traitant', 'Contrat de sous-traitance|Agrément du maître d’ouvrage|Assurances|Liste du personnel|Situations de travaux|Réception des travaux sous-traités'],
    ['Dossier du personnel de chantier', 'Liste du personnel|Contrats de travail|Déclarations sociales|Attestations d’aptitude|Fiches d’accueil sécurité|Registre de présence'],
    ['Dossier d’études techniques', 'Étude géotechnique|Notes de calcul|Plans de structure|Plans de lots techniques|Estimation du coût|Rapport du bureau de contrôle'],
    ['Dossier de plans d’exécution', 'Plan de masse|Plans de fondations|Plans de coffrage et ferraillage|Plans d’architecture|Plans de plomberie et d’électricité|Plans de détails'],
    ['Dossier de gestion des modifications', 'Demandes de modification|Ordres de service|Avenants|Plans modifiés|Incidence sur prix et délai'],
    ['Dossier de réclamation ou de litige', 'Courriers échangés|Constats et photos|Procès-verbaux|Rapports techniques|Calculs de préjudice|Décisions et accords'],
    ['Dossier d’assurance du chantier', 'Polices d’assurance|Attestations de l’entreprise|Déclarations de sinistre|Constats|Rapports d’expert|Indemnisations'],
    ['Dossier de livraison à un client', 'Procès-verbal de livraison|Remise des clés|Notices d’utilisation|Garanties|Plans de récolement|Contacts du service après-vente'],
    ['Dossier de maintenance après travaux', 'Plan d’entretien|Contrats de maintenance|Fiches d’intervention|Historique des pannes|Pièces de rechange|Garanties en cours'],
    ['Dossier de présentation commerciale', 'Présentation de l’entreprise|Réalisations et références|Équipe|Certifications et assurances|Offre de services|Contacts'],
    ['Dossier de candidature à un marché', 'Lettre de candidature|Statuts et registre de l’entreprise|Références|Moyens humains et matériels|Chiffre d’affaires|Attestations'],
    ['Dossier d’ouverture de chantier', 'Déclaration d’ouverture|Panneau de chantier|Autorisations|Plan d’installation|Plan de sécurité|Assurances'],
    ['Dossier d’archivage de fin de chantier', 'Marché|Plans finaux|Procès-verbaux|Rapports|Photos|Dossier financier clos|Dossier des ouvrages exécutés'],
    ['Dossier d’agrément de matériaux', 'Fiches techniques|Échantillons|Certificats de conformité|Avis de la maîtrise d’œuvre|Bons de commande']
  ];
  LPL.forEach(function (r) { DS['Liste des pièces — ' + r[0]] = LP(r[0], r[1]); });
  DS['Bordereau d’envoi du dossier'] = '# BORDEREAU D’ENVOI DU DOSSIER\nProjet : {{projet}} — {{lieu}}\nDe : {{societe}} — À : ____________ — Date : {{date}}\n| N° | Document | Indice | Nombre | Observation |\n| 1 | ____________ | ____ | ____ | ____________ |\n| 2 | ____________ | ____ | ____ | ____________ |\nAccusé de réception : ____________';
  DS['Fiche de contrôle de complétude du dossier'] = '# FICHE DE CONTRÔLE DE COMPLÉTUDE\nProjet : {{projet}} — {{lieu}}\n| Rubrique | Complète | Pièces manquantes |\n| Administratif | oui / non | ____________ |\n| Technique | oui / non | ____________ |\n| Financier | oui / non | ____________ |\n| Qualité et sécurité | oui / non | ____________ |\nDécision : dossier complet / à compléter avant le ____________';
  DS['Registre des documents du chantier'] = '# REGISTRE DES DOCUMENTS DU CHANTIER\nProjet : {{projet}} — {{lieu}}\n| N° | Document | Émetteur | Date de réception | Indice | Classement |\n| ____ | ____________ | ____________ | ____ | ____ | ____ |\n| ____ | ____________ | ____________ | ____ | ____ | ____ |';
  DS['Index des plans'] = '# INDEX DES PLANS\nProjet : {{projet}} — {{lieu}}\n| N° de plan | Titre | Échelle | Indice | Date |\n| ____ | ____________ | ____ | ____ | ____ |\n| ____ | ____________ | ____ | ____ | ____ |';
  DS['Historique des révisions'] = '# HISTORIQUE DES RÉVISIONS\nProjet : {{projet}} — {{lieu}}\n| Indice | Date | Modification | Auteur | Approbation |\n| A | ____ | ____________ | ____________ | ____ |\n| B | ____ | ____________ | ____________ | ____ |';
  DS['Fiche d’archivage'] = '# FICHE D’ARCHIVAGE\nProjet : {{projet}} — {{lieu}}\nBoîte / classeur n° : ____ — localisation : ____________\nContenu : ____________________\nDate de clôture : ____________ — durée de conservation : ___ ans';
  DS['Fiche de transmission interne du dossier'] = '# FICHE DE TRANSMISSION INTERNE\nProjet : {{projet}} — {{lieu}}\nDe : ____________ — à : ____________ — date : {{date}}\nDossier transmis : {{objet}}\nObservations : ____________________';
  merge('dossier', DS);

  /* ---------- TEXTES LIBRES (trames à compléter) ---------- */
  var LB = function (t, secs) {
    return '# ' + t.toUpperCase() + '\n' + secs.split('|').map(function (s) { return '## ' + s + '\n____________________'; }).join('\n') + FT;
  };
  var LBL = [
    ['Note interne', 'Objet|Contexte|Consignes'],
    ['Mémo', 'À|De|Objet|Message'],
    ['Communiqué', 'Titre|Message principal|Contacts'],
    ['Avis au personnel', 'Objet|Informations|Date d’application'],
    ['Avis de recrutement', 'Poste|Missions|Profil recherché|Dossier de candidature|Date limite'],
    ['Offre d’emploi', 'Intitulé du poste|Lieu|Contrat|Missions|Compétences|Comment postuler'],
    ['Fiche de poste', 'Intitulé|Rattachement|Missions|Compétences requises|Conditions de travail'],
    ['Convocation à une assemblée', 'Ordre du jour|Date, heure et lieu|Documents à apporter'],
    ['Procuration', 'Mandant|Mandataire|Objet de la procuration|Durée'],
    ['Décharge simple', 'Objet remis|Date et lieu|Engagement de la personne'],
    ['Demande de congé', 'Période demandée|Motif|Remplacement prévu'],
    ['Demande d’emploi', 'Poste visé|Parcours|Disponibilité'],
    ['Lettre de motivation', 'Présentation|Motivations|Compétences|Disponibilité'],
    ['Présentation d’entreprise', 'Qui sommes-nous|Nos métiers|Nos réalisations|Nos engagements|Contacts'],
    ['Rapport de mission', 'Objectif de la mission|Déroulement|Résultats|Recommandations'],
    ['Rapport d’activité mensuel', 'Faits marquants|Chiffres du mois|Difficultés|Perspectives'],
    ['Bilan annuel', 'Résultats de l’année|Réalisations|Difficultés|Objectifs de l’année suivante'],
    ['Termes de référence (TdR)', 'Contexte|Objectifs|Tâches à réaliser|Livrables|Calendrier|Profil du prestataire'],
    ['Note conceptuelle de projet', 'Contexte et justification|Objectifs|Activités|Résultats attendus|Budget estimatif|Risques'],
    ['Plan d’affaires simplifié', 'Présentation de l’activité|Marché|Moyens nécessaires|Prévisions financières|Risques'],
    ['Budget prévisionnel', 'Recettes attendues|Dépenses prévues|Écarts possibles|Hypothèses'],
    ['Planning de travail', 'Tâches|Dates de début et de fin|Responsables|Points de contrôle'],
    ['Liste de tâches', 'Tâches à faire aujourd’hui|Tâches de la semaine|Tâches en attente'],
    ['Check-list libre', 'Éléments à vérifier|Éléments faits|Éléments restants'],
    ['Journal de bord', 'Date|Événements du jour|Décisions|À suivre'],
    ['Ordre du jour de réunion', 'Points à traiter|Documents|Durée prévue'],
    ['Proposition commerciale', 'Besoin du client|Notre proposition|Prix et conditions|Délai|Références'],
    ['Argumentaire commercial', 'Atouts de l’entreprise|Avantages pour le client|Réponses aux objections'],
    ['Conditions générales de vente', 'Objet|Prix et paiement|Délais|Garanties|Responsabilité|Litiges'],
    ['Conditions générales d’intervention', 'Champ d’application|Obligations du client|Obligations de l’entreprise|Conditions de paiement|Garanties'],
    ['Règlement intérieur de l’entreprise', 'Horaires et présence|Discipline|Hygiène et sécurité|Sanctions|Entrée en vigueur'],
    ['Charte de sécurité', 'Engagements de la direction|Engagements du personnel|Règles d’or|Signatures'],
    ['Charte qualité', 'Engagements envers le client|Méthodes de contrôle|Amélioration continue'],
    ['Politique environnementale', 'Engagements|Gestion des déchets|Économie des ressources|Sensibilisation'],
    ['Code de conduite', 'Valeurs|Comportements attendus|Conflits d’intérêts|Signalement des manquements'],
    ['Description d’organisation (organigramme en texte)', 'Direction|Services|Chantiers|Responsabilités'],
    ['Invitation à une inauguration', 'Événement|Date, heure et lieu|Programme|Confirmation de présence'],
    ['Discours d’inauguration', 'Accueil|Présentation du projet|Remerciements|Mot de la fin'],
    ['Communiqué de presse', 'Titre|Faits|Citation de la direction|À propos de l’entreprise'],
    ['Fiche service ou produit', 'Description|Avantages|Conditions|Prix'],
    ['Fiche de suivi client', 'Coordonnées|Échanges|Demandes en cours|Prochaines actions'],
    ['Témoignage client', 'Contexte|Résultat obtenu|Appréciation du client'],
    ['Programme de visite de site', 'Participants|Itinéraire|Points d’arrêt|Consignes de sécurité'],
    ['Compte rendu libre', 'Contexte|Points abordés|Décisions|Actions'],
    ['Procès-verbal libre', 'Faits constatés|Personnes présentes|Observations|Signatures'],
    ['Constat simple', 'Date et lieu|Faits constatés|Photos jointes|Témoins'],
    ['Engagement sur l’honneur', 'Identité|Engagement pris|Durée|Signature'],
    ['Reconnaissance de réception de documents', 'Documents reçus|Date|Réserves'],
    ['Demande de subvention ou de financement', 'Présentation du porteur|Projet|Budget|Retombées attendues'],
    ['Fiche de présentation d’un chantier', 'Projet|Localisation|Caractéristiques|Délai|Intervenants'],
    ['Cahier des charges simple', 'Contexte|Besoins|Contraintes|Livrables|Délais|Budget'],
    ['Tableau de suivi', 'Éléments suivis|État|Responsable|Échéance'],
    ['Lettre ouverte', 'Destinataires|Message|Demandes|Conclusion']
  ];
  var LBM = {}; LBL.forEach(function (r) { LBM[r[0]] = LB(r[0], r[1]); });
  merge('libre', LBM);
})(window);
