/* Excellencia Building — CORE v1 · adaptateurs métier (V143b)
 * Branche au noyau (exb-core.js) les collections sensibles, SANS modifier les modules : on observe l'unique point d'écriture
 * commun (exbStorage.setItem), on compare avec l'état précédent et on publie, pour chaque fiche créée / modifiée / supprimée :
 *   · un événement du bus  « <domaine>.cree | <domaine>.modifie | <domaine>.statut | <domaine>.supprime »
 *   · une ligne du journal d'audit chaîné (qui, quand, quoi, identifiant, montant, statut).
 * Domaines : devis/factures/reçus (exb_quotes), finance projet (exb_finance), caisse (exb_cash), paiements (exb_v93_payments),
 *            factures fournisseurs (exb_v92_supplier_invoices), projets (exb_projects, exb_v93_projects), documents de chantier (exb_pieces).
 * Règles : lecture seule sur les données ; une écriture refusée par les droits n'est pas journalisée ; au-delà de 20 changements
 * dans une même écriture (synchronisation, import) une seule ligne « .lot » résume l'opération. Aucun texte libre n'est copié.
 * Pour retirer : supprimer la balise <script src="exb-core-adapters.js"> de index.html. */
(function (w) {
  'use strict';
  if (w.EXBCoreAdapters) return;
  var WATCH = {
    exb_quotes: 'devis', exb_finance: 'finance', exb_cash: 'caisse', exb_v93_payments: 'paiement',
    exb_v92_supplier_invoices: 'facture_fournisseur', exb_projects: 'projet', exb_v93_projects: 'projet_btp', exb_pieces: 'document_chantier',
    exb_invoices: 'facture', exb_purchase_orders: 'bon_commande', exb_credit_notes: 'avoir', exb_clotures: 'cloture', exb_wf_dossiers: 'workflow', exb_payroll: 'paie', exb_payments: 'paiement_apprenant'
  };
  var BATCH = 20, snap = {}, stats = { events: 0, batches: 0, ignored: 0 };

  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function parse(s) { try { var a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : null; } catch (e) { return null; } }
  /* « uid » en dernier : V186 (exb-core-ids.js) l'ajoute aux fiches qui n'avaient que no/ref/code — l'identité suivie ne doit pas changer. */
  function ident(o, i) { return o && (o.id || o.no || o.number || o.invoice_no || o.ref || o.code || o.uid) ? String(o.id || o.no || o.number || o.invoice_no || o.ref || o.code || o.uid) : null; }
  function first(o, names) { for (var i = 0; i < names.length; i++) { var v = o[names[i]]; if (v != null && v !== '') return v; } return undefined; }
  function kind(o) { var t = first(o, ['type', 'kind', 'doc_type', 'famille']); return typeof t === 'string' && t.length <= 24 ? t.toLowerCase().replace(/[^a-z0-9_]/g, '') : ''; }
  function summary(o) {
    var s = {}, id = ident(o), t = kind(o), m = first(o, ['ttc', 'total', 'amount', 'montant', 'montant_ttc', 'budget']), st = first(o, ['status', 'statut', 'state', 'etat']), cur = first(o, ['cur', 'devise', 'currency']);
    if (id) s.id = id; if (t) s.type = t; if (typeof m === 'number' || (typeof m === 'string' && m.length < 20)) s.montant = m; if (cur && String(cur).length < 6) s.devise = cur;
    if (st != null && String(st).length < 30) s.statut = String(st);
    var lab = first(o, ['no', 'number', 'invoice_no', 'ref', 'name', 'nom', 'title', 'titre']); if (lab != null && String(lab).length < 60) s.ref = String(lab);
    return s;
  }
  function index(list) { var m = {}; list.forEach(function (o, i) { var k = ident(o, i) || ('h' + JSON.stringify(o)); m[k] = { raw: JSON.stringify(o), o: o }; }); return m; }

  function diff(key, nextList) {
    var C = w.EXBCore; if (!C) return;
    var dom = WATCH[key], prev = snap[key], next = index(nextList); snap[key] = next;
    if (!prev) return; /* première observation : on mémorise seulement */
    var ev = [], k;
    for (k in next) { if (!prev[k]) ev.push(['cree', next[k].o]); else if (prev[k].raw !== next[k].raw) { var a = summary(prev[k].o).statut, b = summary(next[k].o).statut; ev.push([a !== b ? 'statut' : 'modifie', next[k].o, a !== b ? { de: a, vers: b } : null]); } }
    for (k in prev) { if (!next[k]) ev.push(['supprime', prev[k].o]); }
    if (!ev.length) return;
    if (ev.length > BATCH) {
      var n = { cree: 0, modifie: 0, statut: 0, supprime: 0 }; ev.forEach(function (e) { n[e[0]]++; });
      stats.batches++; C.bus.emit(dom + '.lot', n, key); C.audit.log(dom + '.lot', key, n); return;
    }
    ev.forEach(function (e) {
      var s = summary(e[1]); if (e[2]) s.changement = e[2]; stats.events++;
      var name = dom + '.' + e[0]; C.bus.emit(name, s, key); C.audit.log(name, s.id || s.ref || key, s);
    });
  }

  function install() {
    var S = store(); if (!S || S.__coreAd || typeof S.setItem !== 'function' || typeof S.getItem !== 'function') return false;
    Object.keys(WATCH).forEach(function (k) { var a = parse(S.getItem(k)); if (a) snap[k] = index(a); else snap[k] = {}; });
    var orig = S.setItem; S.__coreAd = true;
    S.setItem = function (k, v) {
      var r = orig.apply(this, arguments);
      try {
        if (WATCH[k]) { /* écriture refusée par les droits (ou échouée) : l'état stocké ≠ v → rien à journaliser */
          if (S.getItem(k) === v) { var a = parse(v); if (a) diff(k, a); else stats.ignored++; } else stats.ignored++;
        }
      } catch (e) {}
      return r;
    };
    return true;
  }
  var tries = 0, t = setInterval(function () { if ((w.EXBCore && install()) || ++tries > 80) clearInterval(t); }, 500);
  w.EXBCoreAdapters = { watch: function () { return JSON.parse(JSON.stringify(WATCH)); }, stats: function () { return JSON.parse(JSON.stringify(stats)); } };
})(window);
