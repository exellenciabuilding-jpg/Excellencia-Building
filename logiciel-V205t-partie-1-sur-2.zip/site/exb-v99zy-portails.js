/* Excellencia Building V99zy — « 🔗 Portails & signatures » (Clients & CRM).
 * 1) Portails client / sous-traitant : l'entreprise PUBLIE un instantané choisi (avancement, jalons, photos, journal, factures, lots, documents)
 *    sous un lien secret + un code ; le visiteur ouvre portail.html (sans compte). Republier = mettre à jour ; Révoquer = couper l'accès.
 * 2) E-signature des contrats : modèles, empreinte SHA-256, signature de l'entreprise dans l'application, signature du client / sous-traitant dans le portail,
 *    attestation imprimable. Une fois joint à un portail, le texte est verrouillé (nouvelle version pour modifier).
 * 3) Retours : signatures, messages, déclarations d'avancement des sous-traitants (acceptées / refusées), visites.
 * 4) Relances : messages WhatsApp / SMS / e-mail PRÉPARÉS automatiquement (factures impayées, situations non facturées, signatures en attente, retards, publications) ;
 *    l'envoi se fait d'un appui (aucune passerelle d'envoi automatique n'est incluse).
 * Nécessite supabase/migration-v99zy-portails.sql, la connexion au compte en ligne ET l'appartenance à une organisation (⚙️ Administration › Équipe) pour publier / lire les retours.
 * Données synchronisées entre les appareils de l'organisation (collections portails, esign, relances). Les codes d'accès, eux, ne quittent jamais l'appareil (exb_portail_codes). */
(function (w, d) {
'use strict';
var $ = function (i) { return d.getElementById(i); };
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function G(k) { try { var v = w.EXBS.get(k); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
function Pu(k, v) { try { return w.EXBS.set(k, v); } catch (e) { return false; } }
function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
function today() { return new Date().toISOString().slice(0, 10); }
function days(t) { var x = new Date(t); return isNaN(x) ? 0 : Math.floor((Date.now() - x.getTime()) / 864e5); }
function fr(t, l) { if (!t) return '–'; var x = new Date(t); return isNaN(x) ? '–' : x.toLocaleDateString('fr-FR', l ? { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' } : { day: '2-digit', month: 'short', year: 'numeric' }); }
function money(n, c) { return (Number(n) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + (c === 'FC' ? 'FC' : '$'); }
function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); else exbAlert(m); } catch (e) {} }
var DOCG = [['plan', '📐 Plan'], ['devis', '💶 Devis'], ['note_calcul', '🧮 Note de calcul'], ['plan_execution', '📐 Plan d’exécution'], ['facture', '🧾 Facture'], ['contrat', '📑 Contrat'], ['rapport', '📋 Rapport'], ['autre', '📎 Autre document']];
function org() { try { return JSON.parse(localStorage.getItem('EXB_DB_META') || '{}').org || ''; } catch (e) { return ''; } }
function codes() { try { return JSON.parse(localStorage.getItem('exb_portail_codes') || '{}') || {}; } catch (e) { return {}; } }
function setCode(id, c) { var m = codes(); m[id] = c; try { localStorage.setItem('exb_portail_codes', JSON.stringify(m)); } catch (e) {} }
function needOrg() { if (!org()) throw new Error('Créez ou rejoignez votre organisation (⚙️ Administration › Équipe) : les portails sont rattachés à l’organisation.'); }
function isIn() { return !!(w.exbSb && w.exbSb.isIn && w.exbSb.isIn()); }
function rpc(fn, b) { return w.exbSb.api('/rest/v1/rpc/' + fn, { method: 'POST', body: JSON.stringify(b || {}) }); }
async function sha(t) { var b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)); return Array.prototype.map.call(new Uint8Array(b), function (x) { return x.toString(16).padStart(2, '0'); }).join(''); }
function ident() { try { return w.EXBId ? w.EXBId.get() : {}; } catch (e) { return {}; } }
function phoneNorm(p) { var raw = String(p || ''), dg = raw.replace(/\D/g, ''), cc = '243'; try { cc = localStorage.getItem('exb_cc') || '243'; } catch (e) {} if (!dg) return ''; if (/^\s*\+/.test(raw)) return dg; if (dg.indexOf('00') === 0) return dg.slice(2); if (dg[0] === '0') return cc + dg.slice(1); if (dg.length <= 9) return cc + dg; return dg; }
function opt(list, sel) { return list.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (String(x[0]) === String(sel) ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }
function linkOf(tok) { var b = (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,'')); return b + 'portail.html?t=' + tok; }

/* ---------- réglages des relances ---------- */
var CFG0 = { on: { facture: true, situation: true, signature: true, retard: true, publication: true }, factureJ: 15, situationJ: 7, signatureJ: 3,
  tpl: {
    facture: 'Bonjour {nom}, sauf erreur de notre part, la facture {no} du projet « {projet} » ({montant}) reste à régler depuis {jours} jours. Merci de nous indiquer la date de paiement. — {entreprise}',
    situation: 'Bonjour {nom}, la situation de travaux {no} du projet « {projet} » ({montant}) a été émise le {date}. Merci de la valider afin que nous puissions émettre la facture. — {entreprise}',
    signature: 'Bonjour {nom}, le document « {no} » attend votre signature depuis {jours} jours : {lien} (le code d’accès vous a été transmis séparément). — {entreprise}',
    retard: 'Alerte interne : le projet « {projet} » a dépassé sa date de fin prévue ({date}) avec un avancement de {montant}.',
    publication: 'Bonjour {nom}, l’avancement de votre projet « {projet} » est à jour sur votre espace de suivi : {lien} — {entreprise}'
  } };
function cfg() { var c = {}; try { c = JSON.parse(localStorage.getItem('exb_portail_cfg') || '{}') || {}; } catch (e) {} return { on: Object.assign({}, CFG0.on, c.on), factureJ: c.factureJ || CFG0.factureJ, situationJ: c.situationJ || CFG0.situationJ, signatureJ: c.signatureJ || CFG0.signatureJ, tpl: Object.assign({}, CFG0.tpl, c.tpl) }; }
function saveCfg(c) { try { localStorage.setItem('exb_portail_cfg', JSON.stringify(c)); } catch (e) {} }
function fill(t, v) { return String(t).replace(/\{(\w+)\}/g, function (m, k) { return v[k] != null ? v[k] : m; }); }

/* ---------- modèles de contrats (indicatifs : à faire relire par un juriste) ---------- */
var TYPES = [['contrat', 'Contrat de travaux (client)', 'client'], ['soustraitance', 'Contrat de sous-traitance', 'soustraitant'], ['avenant', 'Avenant', 'client'], ['os', 'Ordre de service', 'soustraitant'], ['pv', 'PV de réception', 'client'], ['devis', 'Devis accepté', 'client'], ['autre', 'Autre document', 'client']];
function model(type, v) {
  var E = v.entreprise || '…', C = v.client || '…', P = v.projet || '…', L = v.lieu || '…';
  var common = '\n\nPRIX ET PAIEMENT\nLe prix, les acomptes et les modalités de paiement sont ceux du devis / DQE validé : ………\n\nDÉLAI\nLes travaux débutent le ……… et s’achèvent le ………, sous réserve des cas de force majeure.\n\nPÉNALITÉS DE RETARD\nEn cas de retard imputable à l’entrepreneur, une pénalité de ……… % du montant par jour de retard est appliquée, plafonnée à ……… %.\n\nRETENUE DE GARANTIE\nUne retenue de ……… % est opérée sur chaque paiement et restituée à la réception définitive, après levée des réserves.\n\nRÉCEPTION\nLa réception a lieu par procès-verbal signé des deux parties ; les réserves sont levées dans un délai de ……… jours.\n\nRÉSILIATION\nChaque partie peut résilier après mise en demeure restée sans effet pendant ……… jours.\n\nLITIGES\nLes parties recherchent une solution amiable ; à défaut, le tribunal compétent est celui de ………\n\nFait en deux exemplaires. Signatures précédées de la mention « lu et approuvé » portée par la signature électronique.';
  if (type === 'soustraitance') return 'CONTRAT DE SOUS-TRAITANCE\n\nEntre ' + E + ' (« l’entrepreneur principal ») et ' + C + ' (« le sous-traitant »).\n\nOBJET\nLe sous-traitant exécute les lots suivants du projet « ' + P + ' » (' + L + ') : ………\n\nOBLIGATIONS DU SOUS-TRAITANT\nRespect des plans, des règles de l’art, de la sécurité du chantier (port des EPI) et des instructions du conducteur de travaux. Assurance responsabilité civile valable pendant toute la durée du marché.' + common;
  if (type === 'os') return 'ORDRE DE SERVICE N° ………\n\nDe : ' + E + '\nÀ : ' + C + '\nProjet : ' + P + ' (' + L + ')\n\nVous êtes invité à ………\n\nDate de prise d’effet : ………\nDélai d’exécution : ………\n\nLa signature de ce document vaut accusé de réception et acceptation de l’ordre.';
  if (type === 'pv') return 'PROCÈS-VERBAL DE RÉCEPTION\n\nProjet : ' + P + ' (' + L + ')\nMaître d’ouvrage : ' + C + '\nEntreprise : ' + E + '\n\nAprès visite des ouvrages le ………, le maître d’ouvrage déclare :\n☐ réceptionner les travaux sans réserve\n☐ réceptionner les travaux avec les réserves suivantes : ………\n\nLes réserves seront levées avant le ………\nLa garantie de parfait achèvement court à compter de ce jour.';
  if (type === 'avenant') return 'AVENANT N° ………\n\nAu contrat entre ' + E + ' et ' + C + ' relatif au projet « ' + P + ' ».\n\nObjet de la modification : ………\nIncidence sur le prix : ………\nIncidence sur le délai : ………\n\nLes autres clauses du contrat restent inchangées.';
  if (type === 'devis') return 'ACCEPTATION DE DEVIS\n\nLe client ' + C + ' accepte le devis n° ……… de ' + E + ' relatif au projet « ' + P + ' », pour un montant de ……… , aux conditions de paiement suivantes : ………';
  if (type === 'autre') return '';
  return 'CONTRAT DE TRAVAUX\n\nEntre ' + E + ' (« l’entrepreneur ») et ' + C + ' (« le client »).\n\nOBJET\nL’entrepreneur réalise pour le client les travaux du projet « ' + P + ' » situé à ' + L + ', décrits dans le devis / DQE : ………\n\nOBLIGATIONS\nL’entrepreneur exécute les travaux selon les règles de l’art et les plans validés. Le client donne l’accès au chantier et règle les sommes dues aux échéances prévues.' + common;
}

/* ---------- état ---------- */
var st = { pay: null, payAt: 0, newPay: 0, tab: 'p', ed: null, edDoc: null, ret: null, retAt: 0, busy: false, msg: '' };
function blankEd() { var pr = G('exb_projects')[0] || {}; return { id: '', token: '', kind: 'client', pid: pr.id || '', titre: '', dest: '', tel: '', email: '', code: String(100000 + Math.floor(Math.random() * 900000)), expDays: 90,
  opts: { avanc: true, jalons: '', photos: 12, journal: 5, fin: true, docs: [], lots: '' } }; }
function projOf(id) { return G('exb_projects').find(function (x) { return x.id === id; }) || {}; }
function clientOf(name) { var n = String(name || '').trim().toLowerCase(); if (!n) return {}; return G('exb_clients').find(function (c) { return String(c.full_name || '').toLowerCase() === n || String(c.company || '').toLowerCase() === n; }) || {}; }

/* ---------- instantané publié ---------- */
function shrink(u, mw, q) { return new Promise(function (res) { if (!/^data:image\//.test(u || '')) return res(''); var im = new Image(); im.onload = function () { try { var r = Math.min(1, mw / Math.max(im.width, im.height)), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * r)); c.height = Math.max(1, Math.round(im.height * r)); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); var o = c.toDataURL('image/jpeg', q); res(o.length < 110000 ? o : ''); } catch (e) { res(''); } }; im.onerror = function () { res(''); }; im.src = u; }); }
function lines(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.split('|').map(function (x) { return x.trim(); }); }).filter(function (a) { return a[0]; }); }
async function snapshot(r) {
  var o = r.opts, I = ident(), pr = projOf(r.pid), C = { v: 1, entreprise: { nom: I.name || '', tel: I.phone || '', email: I.email || '', adresse: I.address || '' } };
  if (o.avanc) C.projet = { nom: pr.name || r.titre, lieu: pr.location || '', debut: pr.start || '', fin: pr.end || '', statut: pr.status || '', avancement: Number(pr.progress) || 0 };
  C.jalons = lines(o.jalons).map(function (a) { return { nom: a[0], pct: Math.max(0, Math.min(100, Number(a[1]) || 0)) }; });
  if (r.kind === 'soustraitant') C.lots = lines(o.lots).map(function (a) { return { nom: a[0], montant: a[1] !== undefined && a[1] !== '' ? Number(a[1]) : null, cur: /fc|cdf/i.test(a[2] || '') ? 'FC' : 'USD' }; });
  var J = G('exb_site_journal').filter(function (j) { return j.project_id === r.pid; }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
  if (o.journal > 0 && r.kind === 'client') C.journal = J.slice(0, o.journal).map(function (j) { return { d: j.date, meteo: j.weather || '', effectif: j.crew || '', travaux: j.work || '' }; });
  if (o.photos > 0 && r.kind === 'client') { C.photos = []; for (var i = 0; i < J.length && C.photos.length < o.photos; i++) { var ph = J[i].photos || []; for (var k = 0; k < ph.length && C.photos.length < o.photos; k++) { var u = await shrink(ph[k], 520, .62); if (u) C.photos.push({ d: J[i].date, t: String(J[i].work || '').slice(0, 60), u: u }); } } }
  if (o.fin && r.kind === 'client') {
    var F = G('exb_finance').filter(function (x) { return x.project === r.pid && x.type !== 'taux'; }), pay = F.filter(function (x) { return x.type === 'paiement'; }), res = {};
    C.finances = F.filter(function (x) { return x.type !== 'devis' || x.status === 'accepté' || x.status === 'envoyé'; }).sort(function (a, b) { return String(a.date).localeCompare(String(b.date)); }).map(function (x) {
      var paid = x.type === 'facture' ? pay.filter(function (p) { return p.parent === x.id; }).reduce(function (s, p) { return s + (Number(p.ttc) || 0); }, 0) : 0, stt = x.status || '';
      if (x.type === 'facture') stt = paid >= (Number(x.ttc) || 0) - .005 ? 'Payée' : paid > 0 ? 'Partiellement payée' : 'À payer'; if (x.type === 'paiement') stt = 'Reçu';
      return { type: x.type, no: x.no, date: x.date, cur: x.cur, ttc: Number(x.ttc) || 0, statut: stt }; });
    F.forEach(function (x) { var c = x.cur === 'FC' ? 'FC' : 'USD'; res[c] = res[c] || { facture: 0, paye: 0, reste: 0 }; if (x.type === 'facture') res[c].facture += Number(x.ttc) || 0; if (x.type === 'paiement') res[c].paye += Number(x.ttc) || 0; });
    Object.keys(res).forEach(function (c) { res[c].reste = Math.max(0, res[c].facture - res[c].paye); }); C.resume = res;
  }
  var DOC = G('exb_esign'); C.documents = [];
  (o.docs || []).forEach(function (id) { var x = DOC.find(function (y) { return y.id === id; }); if (x) C.documents.push({ id: x.id, titre: x.titre + (x.v > 1 ? ' (version ' + x.v + ')' : ''), type: (TYPES.find(function (t) { return t[0] === x.type; }) || [0, 'Document'])[1], texte: x.texte, hash: x.hash, roles: x.roles, date: x.date }); });
  return C;
}

/* ---------- portails ---------- */
function portals() { return G('exb_portails'); }
async function publish(r) {
  if (!isIn()) throw new Error('Connectez-vous au compte en ligne pour publier.'); needOrg();
  var C = await snapshot(r);
  var exp = r.expDays > 0 ? new Date(Date.now() + r.expDays * 864e5).toISOString().slice(0, 10) : null;
  var sendCode = !r.token || (r.code && r.code !== r.codeOnServer);
  var res = await rpc('portail_publier', { p_org: org(), p_token: r.token || null, p_kind: r.kind, p_titre: r.titre, p_dest: r.dest, p_code: sendCode ? r.code : '', p_contenu: C, p_expire: exp });
  var DOC = G('exb_esign'); (r.opts.docs || []).forEach(function (id) { var x = DOC.find(function (y) { return y.id === id; }); if (x && !x.locked) { x.locked = true; x.published = new Date().toISOString(); } }); Pu('exb_esign', DOC);
  r.token = res.token; if (sendCode) setCode(r.id, { code: r.code, srv: r.code }); delete r.code; delete r.codeOnServer; r.pub = new Date().toISOString(); r.exp = exp; r.actif = true; r.size = JSON.stringify(C).length;
  return r;
}
function savePortal(r) { var L = portals(), i = L.findIndex(function (x) { return x.id === r.id; }); if (i >= 0) L[i] = r; else L.unshift(r); Pu('exb_portails', L); }

/* ---------- documents à signer ---------- */
function docs() { return G('exb_esign'); }
function docStatus(x) { var need = ['entreprise'].concat(x.roles || []), got = need.filter(function (r) { return x.sig && x.sig[r]; }); if (got.length === need.length) return ['Signé par toutes les parties', 'ok']; if (!got.length) return [x.locked ? 'En attente de signatures' : 'Brouillon', x.locked ? 'wa' : 'mu']; return ['Signé par ' + got.map(function (r) { return r === 'entreprise' ? 'l’entreprise' : r === 'client' ? 'le client' : 'le sous-traitant'; }).join(' et '), 'wa']; }
function padHtml() { return '<canvas id="ptPad" width="600" height="220" style="width:100%;height:150px;border:1px dashed #94a3b8;border-radius:10px;background:#fff;touch-action:none;display:block"></canvas><div style="margin:6px 0"><button class="pt-s" data-act="padClr" type="button">Effacer</button></div>'; }
function padInit() { var cv = $('ptPad'); if (!cv) return null; var cx = cv.getContext('2d'), dr = false, lx = 0, ly = 0, o = { any: false, cv: cv }; cx.lineWidth = 3; cx.lineCap = 'round'; cx.strokeStyle = '#0b1b4a';
  function pt(e) { var r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; }
  cv.onpointerdown = function (e) { dr = true; var p = pt(e); lx = p[0]; ly = p[1]; try { cv.setPointerCapture(e.pointerId); } catch (x) {} e.preventDefault(); };
  cv.onpointermove = function (e) { if (!dr) return; var p = pt(e); cx.beginPath(); cx.moveTo(lx, ly); cx.lineTo(p[0], p[1]); cx.stroke(); lx = p[0]; ly = p[1]; o.any = true; e.preventDefault(); };
  cv.onpointerup = cv.onpointercancel = function () { dr = false; };
  o.clear = function () { cx.clearRect(0, 0, cv.width, cv.height); o.any = false; };
  o.png = function () { var c = d.createElement('canvas'); c.width = 400; c.height = 147; var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 400, 147); x.drawImage(cv, 0, 0, 400, 147); return c.toDataURL('image/png'); }; return o; }
function modal(html, onOpen) { var o = $('ptModal'); if (o) o.remove(); o = d.createElement('div'); o.id = 'ptModal'; o.className = 'no-print'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:16px'; o.innerHTML = '<div class="pt-card" style="max-width:560px;width:100%;margin:auto">' + html + '</div>'; o.addEventListener('click', function (e) { if (e.target === o) o.remove(); }); d.body.appendChild(o); if (onOpen) onOpen(o); return o; }
var PAD = null;
function signModal(id) {
  var x = docs().find(function (y) { return y.id === id; }); if (!x) return; var vis = null;
  modal('<h3>✍️ Signature de l’entreprise</h3><p class="pt-mu">' + esc(x.titre) + ' · empreinte ' + esc((x.hash || '').slice(0, 12)) + '…</p><label>Nom du signataire</label><input id="ptSn" maxlength="120" placeholder="Nom et prénom" value="' + esc(ident().dg || '') + '"><label>Fonction</label><input id="ptSf" maxlength="80" placeholder="Directeur général…" value="' + esc(ident().dg ? ident().dgRole : '') + '">' + padHtml() + '<div id="ptVisi"></div><p class="pt-err" id="ptSe"></p><div class="pt-row"><button class="pt-s" data-act="close" type="button">Annuler</button><button data-act="signGo" data-id="' + esc(id) + '" type="button">Signer</button></div>',
    function () { PAD = padInit(); try { if (w.EXBSign && w.EXBSign.active && w.EXBSign.active() && w.EXBId && w.EXBId.visa) { $('ptVisi').innerHTML = '<button class="pt-s" data-act="useVisa" type="button">Utiliser ma signature et mon cachet enregistrés</button>'; } } catch (e) {} });
}
async function printDoc(id) {
  var x = docs().find(function (y) { return y.id === id; }); if (!x) return; var I = ident(), R = { entreprise: 'Entreprise', client: 'Client', soustraitant: 'Sous-traitant' };
  var s = ['entreprise'].concat(x.roles || []).map(function (r) { var g = x.sig && x.sig[r]; return '<div style="border:1px solid #999;border-radius:8px;padding:8px;margin:6px 0;break-inside:avoid"><b>' + R[r] + '</b> — ' + (g ? esc(g.nom) + (g.fonction ? ', ' + esc(g.fonction) : '') + '<br>Signé le ' + fr(g.at, 1) + (g.image ? '<br><img src="' + esc(g.image) + '" style="height:70px">' : '') : '<i>non signé</i>') + '</div>'; }).join('');
  w.EXBPrint.html(x.titre,'<!doctype html><meta charset="utf-8"><title>' + esc(x.titre) + '</title><body style="font:14px/1.5 system-ui;max-width:720px;margin:24px auto;color:#000"><h2>' + esc(x.titre) + (x.v > 1 ? ' — version ' + x.v : '') + '</h2><div style="color:#555">' + esc(I.name || '') + ' · ' + fr(x.date) + '</div><pre style="white-space:pre-wrap;font:inherit;margin:14px 0">' + esc(x.texte) + '</pre><h3>Signatures électroniques</h3>' + s + '<p style="font-size:12px;color:#444">Empreinte SHA-256 du document (titre + texte) : <code style="word-break:break-all">' + esc(x.hash) + '</code><br>Signature électronique simple : nom, tracé, acceptation, date et heure, empreinte du contenu. Toute modification du texte change l’empreinte.</p></body>');
}

/* ---------- relances ---------- */
function queue() { return G('exb_msg_queue'); }
function pushQ(items) { var Q = queue(), n = 0; items.forEach(function (it) { if (Q.some(function (q) { return q.key === it.key; })) return; Q.unshift(Object.assign({ id: uid('MSG'), created: new Date().toISOString(), status: 'a_envoyer' }, it)); n++; }); if (n) Pu('exb_msg_queue', Q); return n; }
function analyze() {
  var c = cfg(), I = ident(), out = [], F = G('exb_finance'), P = G('exb_projects'), pay = F.filter(function (x) { return x.type === 'paiement'; });
  function who(pid) { var p = P.find(function (x) { return x.id === pid; }) || {}, cl = clientOf(p.client); return { p: p, nom: cl.full_name || p.client || 'Madame, Monsieur', tel: cl.phone || '', email: cl.email || '' }; }
  if (c.on.facture) F.filter(function (x) { return x.type === 'facture'; }).forEach(function (f) { var paid = pay.filter(function (p) { return p.parent === f.id; }).reduce(function (s, p) { return s + (Number(p.ttc) || 0); }, 0), reste = (Number(f.ttc) || 0) - paid, j = days(f.date); if (reste > .005 && j >= c.factureJ) { var q = who(f.project); out.push({ key: 'F:' + f.id + ':' + Math.floor(j / 15), rule: 'facture', objet: 'Facture ' + (f.no || '') + ' à régler', nom: q.nom, tel: q.tel, email: q.email, texte: fill(c.tpl.facture, { nom: q.nom, projet: q.p.name || '', no: f.no || '', montant: money(reste, f.cur), jours: j, date: fr(f.date), entreprise: I.name || '' }) }); } });
  if (c.on.situation) F.filter(function (x) { return x.type === 'situation'; }).forEach(function (s) { var j = days(s.date); if (j >= c.situationJ && !F.some(function (f) { return f.type === 'facture' && f.parent === s.id; })) { var q = who(s.project); out.push({ key: 'S:' + s.id, rule: 'situation', objet: 'Situation ' + (s.no || '') + ' à valider', nom: q.nom, tel: q.tel, email: q.email, texte: fill(c.tpl.situation, { nom: q.nom, projet: q.p.name || '', no: s.no || '', montant: money(s.ttc, s.cur), jours: j, date: fr(s.date), entreprise: I.name || '' }) }); } });
  if (c.on.signature) { var PL = portals(); docs().forEach(function (x) { if (!x.locked) return; var need = (x.roles || []).filter(function (r) { return !(x.sig && x.sig[r]); }), j = days(x.published || x.date); if (!need.length || j < c.signatureJ) return; var pt = PL.find(function (p) { return p.actif && (p.opts.docs || []).indexOf(x.id) >= 0; }); if (!pt) return; out.push({ key: 'G:' + x.id + ':' + Math.floor(j / c.signatureJ), rule: 'signature', objet: 'Signature en attente : ' + x.titre, nom: pt.dest || 'Madame, Monsieur', tel: pt.tel, email: pt.email, texte: fill(c.tpl.signature, { nom: pt.dest || '', no: x.titre, jours: j, lien: pt.token ? linkOf(pt.token) : '', entreprise: I.name || '' }) }); }); }
  if (c.on.retard) P.forEach(function (p) { if (p.end && p.end < today() && (Number(p.progress) || 0) < 100 && !/termin|clos|livr/i.test(p.status || '')) out.push({ key: 'R:' + p.id + ':' + today().slice(0, 7), rule: 'retard', interne: true, objet: 'Retard : ' + p.name, nom: 'Interne', tel: '', email: '', texte: fill(c.tpl.retard, { projet: p.name, date: fr(p.end), montant: (Number(p.progress) || 0) + ' %' }) }); });
  return pushQ(out);
}
function openChan(q, how) { var txt = q.texte, num = phoneNorm(q.tel); if (how === 'wa') w.open('https://wa.me/' + num + '?text=' + encodeURIComponent(txt), '_blank', 'noopener'); else if (how === 'sms') w.location.href = 'sms:' + (q.tel || '') + '?body=' + encodeURIComponent(txt); else if (how === 'mail') w.location.href = 'mailto:' + (q.email || '') + '?subject=' + encodeURIComponent(q.objet || '') + '&body=' + encodeURIComponent(txt); else if (how === 'copy') { try { navigator.clipboard.writeText(txt); say('Message copié.'); } catch (e) { exbPrompt('Copiez le message :', txt); } return; }
  var Q = queue(), i = Q.findIndex(function (x) { return x.id === q.id; }); if (i >= 0) { Q[i].status = 'envoye'; Q[i].canal = how; Q[i].sent = new Date().toISOString(); Pu('exb_msg_queue', Q); } setTimeout(render, 400); }

/* ---------- retours du serveur ---------- */
/* V117 : réponse à un client depuis la Messagerie (même appel que « Répondre » du module Portails) */
w.EXBPortailRepondre = async function (token, texte) {
  if (!isIn()) throw new Error('Connectez-vous au compte en ligne pour répondre au client.');
  var t = String(texte || '').trim(); if (!t) throw new Error('Écrivez la réponse.');
  await rpc('portail_repondre', { p_token: token, p_texte: t }); await pullRet(true);
};
async function pullRet(silent) {
  if (!isIn()) { if (!silent) say('Connectez-vous au compte en ligne pour lire les retours.', 'warn'); return; }
  try { needOrg(); var r = await rpc('portail_retours', { p_org: org() }); st.ret = r; st.retAt = Date.now(); try { if (w.EXBMessagerie) { var _tt = {}; portals().forEach(function (x) { _tt[x.token] = x.titre || x.title || x.nom || x.name || ''; }); w.EXBMessagerie.ingestClients(r.messages || [], _tt); w.EXBMessagerie.ingestDeclarations(r.declarations || []); } } catch (e) { /* messagerie facultative */ } var D = docs(), PL = portals(), n = 0;
    (r.signatures || []).forEach(function (s) { var pl = PL.find(function (p) { return p.token === s.token; }); var x = D.find(function (y) { return y.id === s.doc_id; }); if (!x) return; x.sig = x.sig || {}; if (!x.sig[s.role]) { x.sig[s.role] = { nom: s.nom, image: s.image, at: s.signe_le, hash: s.doc_hash, agent: s.agent, mismatch: s.doc_hash !== x.hash }; n++; } });
    if (n) { Pu('exb_esign', D); say(n + ' nouvelle(s) signature(s) reçue(s).'); }
    (r.liens || []).forEach(function (l) { var p = PL.find(function (x) { return x.token === l.token; }); if (p) { p.visites = l.visites; p.lastVisit = l.derniere_visite; if (!l.actif) p.actif = false; } }); Pu('exb_portails', PL);
    var seen = 0; try { seen = Number(localStorage.getItem('exb_pt_seen') || 0); } catch (e) {} st.newMsg = (r.messages || []).filter(function (m) { return m.de === 'visiteur' && new Date(m.cree_le).getTime() > seen; }).length; st.newDecl = (r.declarations || []).filter(function (x) { return x.statut === 'a_verifier'; }).length; try { if (w.EXBALERT) { w.EXBALERT.signal('pt_msg', st.newMsg); w.EXBALERT.signal('pt_decl', st.newDecl); } } catch (e) { }
    render(); } catch (e) { if (!silent) say('Lecture impossible : ' + (e.message || e) + ' (le script SQL V99zn a-t-il été exécuté ?)', 'error'); }
}

/* ---------- rendu ---------- */
var CSS = '#portails .pt-card,.pt-card{background:var(--card,#fff);color:inherit;border:1px solid var(--line,#dbe3ef);border-radius:14px;padding:14px;margin:0 0 12px}#portails input,#portails select,#portails textarea,#ptModal input,#ptModal select,#ptModal textarea{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:10px;margin:3px 0 8px;font:inherit;box-sizing:border-box}#portails label,#ptModal label{font-size:13px;color:#64748b}#portails textarea,#ptModal textarea{min-height:70px}.pt-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.pt-tabs{display:flex;gap:6px;overflow-x:auto;margin-bottom:12px}.pt-tabs button{flex:0 0 auto}.pt-mu{color:#64748b;font-size:13px}.pt-err{color:#b91c1c;min-height:18px;font-size:13px}.pt-ok{color:#15803d}.pt-wa{color:#b45309}.pt-tag{display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:700;background:#eef3fb;border:1px solid #dbe3ef}.pt-s{background:#eef3fb!important;color:#14213d!important;border:1px solid #cbd5e1!important}#portails details{margin:6px 0}#portails .pt-chk{display:flex;gap:8px;align-items:center;margin:4px 0}#portails .pt-chk input{width:auto;margin:0}';
function F(id, label, val, extra) { return '<label>' + label + '</label><input data-f="' + id + '" value="' + esc(val) + '" ' + (extra || '') + '>'; }
function viewPortals() {
  var e = st.ed, h = '';
  if (!isIn()) h += '<div class="pt-card pt-wa">⚠️ Pour publier ou lire les retours, connectez-vous au compte en ligne (⚙️ Administration › Compte). Vous pouvez préparer les documents et les relances sans connexion.</div>';
  if (e) { var P = G('exb_projects'), DOCS = docs().filter(function (x) { return (x.roles || []).indexOf(e.kind) >= 0 && (!x.pid || x.pid === e.pid); });
    h += '<div class="pt-card"><h3>' + (e.id ? 'Modifier le portail' : 'Nouveau portail') + '</h3><label>Type</label><select data-f="kind">' + opt([['client', 'Portail client (maître d’ouvrage)'], ['soustraitant', 'Portail sous-traitant']], e.kind) + '</select><label>Projet</label><select data-f="pid">' + (P.length ? opt(P.map(function (p) { return [p.id, p.name]; }), e.pid) : '<option value="">Aucun projet</option>') + '</select><p class="pt-mu" style="margin:4px 0 0">Projet du client absent ? Une demande reçue ne devient projet qu’après import : <b>Demandes reçues › BTP &amp; Architecture › Pré-remplir</b>, puis enregistrez le projet. Pour que le client déclare ses paiements, ce portail n’est <b>pas</b> nécessaire.</p>' + F('titre', 'Titre affiché', e.titre, 'placeholder="Suivi de chantier"') + F('dest', e.kind === 'client' ? 'Nom du client' : 'Nom du sous-traitant', e.dest) + '<div class="pt-row"><div style="flex:1 1 140px">' + F('tel', 'Téléphone (WhatsApp / SMS)', e.tel, 'inputmode="tel"') + '</div><div style="flex:1 1 160px">' + F('email', 'E-mail', e.email, 'inputmode="email"') + '</div></div>'
      + '<div class="pt-chk"><input type="checkbox" id="ptAv" data-o="avanc"' + (e.opts.avanc ? ' checked' : '') + '><label for="ptAv" style="margin:0;color:inherit">Afficher l’avancement du projet (' + (Number(projOf(e.pid).progress) || 0) + ' %)</label></div><label>Jalons (une ligne : nom | % réalisé)</label><textarea data-o="jalons" placeholder="Fondations | 100&#10;Élévation | 40">' + esc(e.opts.jalons) + '</textarea>';
    if (e.kind === 'client') h += '<div class="pt-row"><div style="flex:1 1 120px"><label>Photos du journal</label><select data-o="photos">' + opt([[0, 'Aucune'], [4, '4 dernières'], [8, '8 dernières'], [12, '12 dernières'], [20, '20 dernières'], [30, '30 dernières']], e.opts.photos) + '</select></div><div style="flex:1 1 120px"><label>Entrées du journal</label><select data-o="journal">' + opt([[0, 'Aucune'], [3, '3 dernières'], [5, '5 dernières'], [10, '10 dernières']], e.opts.journal) + '</select></div></div><div class="pt-chk"><input type="checkbox" id="ptFin" data-o="fin"' + (e.opts.fin ? ' checked' : '') + '><label for="ptFin" style="margin:0;color:inherit">Afficher factures, situations et paiements</label></div><p class="pt-mu">Rien de interne (incidents, notes, coûts, marges) n’est publié.</p>';
    else h += '<label>Lots du marché (une ligne : lot | montant | USD ou FC)</label><textarea data-o="lots" placeholder="Maçonnerie | 12000 | USD">' + esc(e.opts.lots) + '</textarea>';
    h += '<label>Documents à signer</label>' + (DOCS.length ? DOCS.map(function (x) { return '<div class="pt-chk"><input type="checkbox" data-doc="' + esc(x.id) + '"' + ((e.opts.docs || []).indexOf(x.id) >= 0 ? ' checked' : '') + '><span>' + esc(x.titre) + (x.v > 1 ? ' (v' + x.v + ')' : '') + '</span></div>'; }).join('') : '<div class="pt-mu">Aucun document pour ce type. Créez-en dans l’onglet Signatures.</div>')
      + '<div class="pt-row"><div style="flex:1 1 120px"><label>Validité du lien</label><select data-f="expDays">' + opt([[30, '30 jours'], [90, '90 jours'], [180, '6 mois'], [365, '1 an'], [0, 'Sans limite']], e.expDays) + '</select></div><div style="flex:1 1 120px">' + F('code', e.token && !e.code ? 'Nouveau code (laisser vide pour ne pas le changer)' : 'Code d’accès (6 chiffres)', e.code, 'inputmode="numeric" maxlength="12"') + '</div></div><p class="pt-err" id="ptErr">' + esc(st.msg) + '</p><div class="pt-row"><button data-act="pubGo" type="button"' + (st.busy ? ' disabled' : '') + '>' + (st.busy ? 'Publication…' : '🚀 Publier') + '</button><button class="pt-s" data-act="edCancel" type="button">Annuler</button></div></div>';
  } else h += '<div class="pt-row" style="margin-bottom:10px"><button data-act="newP" type="button">➕ Nouveau portail</button></div>';
  var L = portals();
  h += L.length ? L.map(function (p) { var pr = projOf(p.pid); return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><b>' + (p.kind === 'client' ? '👤 ' : '🧱 ') + esc(p.titre) + '</b><span class="pt-tag ' + (p.actif === false ? 'pt-wa' : 'pt-ok') + '">' + (p.actif === false ? 'Révoqué' : p.exp && p.exp < today() ? 'Expiré' : 'Actif') + '</span></div><div class="pt-mu">' + esc(p.dest || '') + ' · ' + esc(pr.name || '') + '</div><div class="pt-mu">Publié le ' + fr(p.pub, 1) + (p.exp ? ' · valable jusqu’au ' + fr(p.exp) : '') + (p.visites != null ? ' · ' + p.visites + ' visite(s)' : '') + (p.lastVisit ? ', dernière le ' + fr(p.lastVisit, 1) : '') + '</div><div class="pt-row" style="margin-top:8px"><button class="pt-s" data-act="pLink" data-id="' + p.id + '" type="button">📨 Envoyer le lien</button><button class="pt-s" data-act="pCode" data-id="' + p.id + '" type="button">🔑 Envoyer le code</button><button class="pt-s" data-act="pQr" data-id="' + p.id + '" type="button">QR</button>' + (p.kind === 'client' && p.actif !== false ? '<button class="pt-s" data-act="pAcc" data-id="' + p.id + '" type="button">🔐 Compte client</button>' : '') + '' + (p.kind === 'client' && p.actif !== false ? '<button class="pt-s" data-act="pPlan" data-id="' + p.id + '" type="button">📎 Envoyer un document</button><button class="pt-s" data-act="pPlans" data-id="' + p.id + '" type="button">📋 Documents envoyés</button>' : '') + '<button class="pt-s" data-act="pRe" data-id="' + p.id + '" type="button">↻ Mettre à jour</button><button class="pt-s" data-act="pEd" data-id="' + p.id + '" type="button">✏️</button><button class="pt-s" data-act="pRev" data-id="' + p.id + '" type="button">⛔ Révoquer</button><button class="pt-s" data-act="pDel" data-id="' + p.id + '" type="button">🗑️</button></div></div>'; }).join('') : (e ? '' : '<div class="pt-card pt-mu">Aucun portail publié. Créez-en un pour partager l’avancement, les photos et les documents avec votre client ou votre sous-traitant.</div>');
  return h;
}
function viewDocs() {
  var e = st.edDoc, h = '', P = G('exb_projects');
  if (e) h += '<div class="pt-card"><h3>' + (e.id ? 'Modifier le document' : 'Nouveau document à signer') + '</h3><label>Type</label><select data-d="type">' + opt(TYPES.map(function (t) { return [t[0], t[1]]; }), e.type) + '</select><label>Projet</label><select data-d="pid"><option value="">—</option>' + opt(P.map(function (p) { return [p.id, p.name]; }), e.pid) + '</select><label>Signataire externe</label><select data-d="role">' + opt([['client', 'Client / maître d’ouvrage'], ['soustraitant', 'Sous-traitant']], e.role) + '</select>' + '<label>Titre</label><input data-d="titre" value="' + esc(e.titre) + '" maxlength="160"><div class="pt-row" style="justify-content:space-between"><label>Texte</label><button class="pt-s" data-act="dModel" type="button">📄 Insérer le modèle</button></div><textarea data-d="texte" style="min-height:240px">' + esc(e.texte) + '</textarea><p class="pt-mu">Modèles indicatifs : à faire relire par un juriste avant usage. Une fois joint à un portail, le texte est verrouillé.</p><p class="pt-err" id="ptErr">' + esc(st.msg) + '</p><div class="pt-row"><button data-act="dSave" type="button">💾 Enregistrer</button><button class="pt-s" data-act="dCancel" type="button">Annuler</button></div></div>';
  else h += '<div class="pt-row" style="margin-bottom:10px"><button data-act="newD" type="button">➕ Nouveau document</button></div>';
  var L = docs();
  h += L.length ? L.map(function (x) { var s = docStatus(x), pr = projOf(x.pid), mis = Object.keys(x.sig || {}).some(function (r) { return x.sig[r].mismatch; });
    return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><b>' + esc(x.titre) + (x.v > 1 ? ' <span class="pt-mu">v' + x.v + '</span>' : '') + '</b><span class="pt-tag pt-' + s[1] + '">' + s[0] + '</span></div><div class="pt-mu">' + esc((TYPES.find(function (t) { return t[0] === x.type; }) || [0, ''])[1]) + ' · ' + esc(pr.name || 'sans projet') + ' · ' + fr(x.date) + ' · empreinte ' + esc((x.hash || '').slice(0, 10)) + '…</div>' + (mis ? '<div class="pt-err">⚠ Une signature porte sur une empreinte différente du texte actuel.</div>' : '') + '<div class="pt-row" style="margin-top:8px">' + (!(x.sig && x.sig.entreprise) ? '<button data-act="dSign" data-id="' + x.id + '" type="button">✍️ Signer (entreprise)</button>' : '') + '<button class="pt-s" data-act="dPrint" data-id="' + x.id + '" type="button">🖨️ Imprimer / PDF</button>' + (!x.locked ? '<button class="pt-s" data-act="dEd" data-id="' + x.id + '" type="button">✏️ Modifier</button>' : '<button class="pt-s" data-act="dVer" data-id="' + x.id + '" type="button">Nouvelle version</button>') + (!x.locked && !Object.keys(x.sig || {}).length ? '<button class="pt-s" data-act="dDel" data-id="' + x.id + '" type="button">🗑️</button>' : '') + '</div></div>'; }).join('') : (e ? '' : '<div class="pt-card pt-mu">Aucun document. Créez un contrat, un ordre de service ou un PV : le client ou le sous-traitant le signera depuis son portail.</div>');
  return h;
}
function viewRet() {
  var r = st.ret, h = '<div class="pt-row" style="margin-bottom:10px"><button data-act="pull" type="button">↻ Actualiser depuis le serveur</button><span class="pt-mu">' + (st.retAt ? 'Lu à ' + new Date(st.retAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'Pas encore lu') + '</span></div>';
  if (!r) return h + '<div class="pt-card pt-mu">' + (isIn() ? 'Appuyez sur « Actualiser » pour lire les signatures, messages et déclarations.' : 'Connectez-vous au compte en ligne pour lire les retours.') + '</div>';
  var PL = portals(), tt = function (tok) { var p = PL.find(function (x) { return x.token === tok; }); return p ? p.titre : 'Portail'; };
  var D = (r.declarations || []).slice().reverse(), M = (r.messages || []).slice().reverse();
  h += '<div class="pt-card"><h3>📈 Déclarations des sous-traitants</h3>' + (D.length ? D.map(function (x) { var c = x.statut === 'accepte' ? 'ok' : x.statut === 'refuse' ? 'wa' : 'wa'; return '<div style="padding:7px 0;border-bottom:1px solid #dbe3ef"><b>' + esc(x.destinataire || x.titre) + '</b> — ' + esc(x.lot) + ' : <b>' + Number(x.pct) + ' %</b> <span class="pt-tag pt-' + c + '">' + (x.statut === 'accepte' ? 'Acceptée' : x.statut === 'refuse' ? 'Refusée' : 'À vérifier') + '</span><div class="pt-mu">' + fr(x.cree_le, 1) + (x.note ? ' · ' + esc(x.note) : '') + '</div>' + (x.statut === 'a_verifier' ? '<div class="pt-row" style="margin-top:6px"><button data-act="dec" data-id="' + x.id + '" data-s="accepte" type="button">✔ Accepter</button><button class="pt-s" data-act="dec" data-id="' + x.id + '" data-s="refuse" type="button">✖ Refuser</button></div>' : '') + '</div>'; }).join('') : '<div class="pt-mu">Aucune déclaration.</div>') + '</div>';
  var byTok = {}; M.forEach(function (m) { (byTok[m.token] = byTok[m.token] || []).push(m); });
  h += '<div class="pt-card"><h3>💬 Messages</h3>' + (Object.keys(byTok).length ? Object.keys(byTok).map(function (tok) { var L = byTok[tok].slice().reverse(); return '<div style="padding:7px 0;border-bottom:1px solid #dbe3ef"><b>' + esc(tt(tok)) + '</b>' + L.slice(-4).map(function (m) { return '<div style="margin:4px 0;' + (m.de === 'entreprise' ? 'text-align:right;color:#1d4ed8' : '') + '"><span class="pt-mu">' + (m.de === 'visiteur' ? 'Visiteur' : 'Vous') + ' · ' + fr(m.cree_le, 1) + '</span><br>' + esc(m.texte) + '</div>'; }).join('') + '<div class="pt-row"><input data-rep="' + esc(tok) + '" placeholder="Répondre…" style="flex:1"><button data-act="rep" data-id="' + esc(tok) + '" type="button">Envoyer</button></div></div>'; }).join('') : '<div class="pt-mu">Aucun message.</div>') + '</div>';
  var S = (r.signatures || []); h += '<div class="pt-card"><h3>✍️ Signatures reçues</h3>' + (S.length ? S.slice().reverse().map(function (s) { return '<div style="padding:5px 0;border-bottom:1px solid #dbe3ef"><b>' + esc(s.doc_titre) + '</b><div class="pt-mu">' + esc(s.nom) + ' (' + (s.role === 'client' ? 'client' : 'sous-traitant') + ') · ' + fr(s.signe_le, 1) + '</div></div>'; }).join('') : '<div class="pt-mu">Aucune signature.</div>') + '</div>';
  return h;
}
function viewRel() {
  var c = cfg(), Q = queue(), pend = Q.filter(function (q) { return q.status === 'a_envoyer'; }), h = '<div class="pt-row" style="margin-bottom:10px"><button data-act="analyze" type="button">🔎 Analyser maintenant</button><span class="pt-mu">Les messages sont préparés automatiquement ; vous les envoyez d’un appui.</span></div>';
  h += pend.length ? pend.map(function (q) { return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><b>' + esc(q.objet) + '</b><span class="pt-tag">' + ({ facture: 'Facture', situation: 'Situation', signature: 'Signature', retard: 'Retard', publication: 'Publication' }[q.rule] || q.rule) + '</span></div><div class="pt-mu">Pour ' + esc(q.nom) + (q.tel ? ' · ' + esc(q.tel) : '') + (q.email ? ' · ' + esc(q.email) : '') + '</div><div style="margin:6px 0;white-space:pre-wrap">' + esc(q.texte) + '</div><div class="pt-row">' + (q.interne ? '' : '<button data-act="send" data-how="wa" data-id="' + q.id + '" type="button">WhatsApp</button><button class="pt-s" data-act="send" data-how="sms" data-id="' + q.id + '" type="button">SMS</button><button class="pt-s" data-act="send" data-how="mail" data-id="' + q.id + '" type="button">E-mail</button>') + '<button class="pt-s" data-act="send" data-how="copy" data-id="' + q.id + '" type="button">Copier</button><button class="pt-s" data-act="qDone" data-id="' + q.id + '" type="button">' + (q.interne ? 'Vu' : 'Déjà envoyé') + '</button><button class="pt-s" data-act="qIgn" data-id="' + q.id + '" type="button">Ignorer</button></div></div>'; }).join('') : '<div class="pt-card pt-mu">Aucune relance à envoyer.</div>';
  h += '<details class="pt-card"><summary><b>⚙️ Règles et modèles</b></summary>' + [['facture', 'Facture non soldée depuis plus de', 'factureJ', 'jours'], ['situation', 'Situation non facturée depuis plus de', 'situationJ', 'jours'], ['signature', 'Document non signé depuis plus de', 'signatureJ', 'jours'], ['retard', 'Projet en retard (date de fin dépassée)', '', ''], ['publication', 'Annoncer chaque mise à jour de portail au client', '', '']].map(function (r) { return '<div class="pt-chk"><input type="checkbox" data-rule="' + r[0] + '"' + (c.on[r[0]] ? ' checked' : '') + '><span>' + r[1] + (r[2] ? ' <input type="number" min="1" data-rn="' + r[2] + '" value="' + c[r[2]] + '" style="width:70px;display:inline-block;margin:0"> ' + r[3] : '') + '</span></div>'; }).join('') + '<p class="pt-mu">Variables : {nom} {projet} {no} {montant} {jours} {date} {lien} {entreprise}</p>' + ['facture', 'situation', 'signature', 'publication'].map(function (k) { return '<label>Modèle « ' + k + ' »</label><textarea data-tpl="' + k + '">' + esc(c.tpl[k]) + '</textarea>'; }).join('') + '<button data-act="cfgSave" type="button">Enregistrer</button></details>';
  var done = Q.filter(function (q) { return q.status !== 'a_envoyer'; }).slice(0, 8); if (done.length) h += '<div class="pt-card"><h3>Historique</h3>' + done.map(function (q) { return '<div class="pt-mu" style="padding:3px 0">' + (q.status === 'envoye' ? '✔ ' : '— ') + esc(q.objet) + ' · ' + esc(q.nom) + (q.canal ? ' · ' + q.canal : '') + '</div>'; }).join('') + '</div>';
  h += '<p class="pt-mu">L’envoi se fait depuis votre téléphone (WhatsApp, SMS, e-mail). Un envoi entièrement automatique demande une passerelle (WhatsApp Business API, fournisseur SMS) qui n’est pas incluse.</p>';
  return h;
}
function render() {
  var el = $('portails'); if (!el || el.style.display === 'none') return; var pend = queue().filter(function (q) { return q.status === 'a_envoyer'; }).length;
  var T = [['p', '🔗 Portails'], ['s', '✍️ Signatures'], ['r', '📥 Retours' + ((st.newDecl || 0) + (st.newMsg || 0) ? ' (' + ((st.newDecl || 0) + (st.newMsg || 0)) + ')' : '')], ['dem', '📨 Demandes clients' + (st.newDem ? ' (' + st.newDem + ')' : '')], ['pay', '💳 Paiements' + (st.newPay ? ' (' + st.newPay + ')' : '')], ['n', '🔔 Relances' + (pend ? ' (' + pend + ')' : '')]];
  el.innerHTML = '<style>' + CSS + '</style><div class="pt-card"><h2 style="margin:0 0 4px">🔗 Portails & signatures</h2><div class="pt-mu">Partagez l’avancement avec vos clients et sous-traitants, faites signer vos contrats, relancez sans oublier.</div></div><div class="pt-tabs">' + T.map(function (t) { return '<button type="button" data-act="tab" data-id="' + t[0] + '"' + (st.tab === t[0] ? '' : ' class="pt-s"') + '>' + t[1] + '</button>'; }).join('') + '</div>' + (st.tab === 'p' ? viewPortals() : st.tab === 's' ? viewDocs() : st.tab === 'r' ? viewRet() : st.tab === 'pay' ? viewPay() : st.tab === 'dem' ? viewDem() : viewRel());
}

/* ---------- paiements des clients (déclarés dans l'espace client, confirmés ici, reçu renvoyé au client) ---------- */
var PAYM = { mobile_money: 'Mobile Money', banque: 'Banque', caisse: 'Caisse (espèces)', autre: 'Autre' };
async function pullPay(silent) {
  if (!isIn()) { if (!silent) say('Connectez-vous au compte en ligne pour lire les paiements.', 'warn'); return; }
  try { needOrg(); var r = await rpc('client_paiements_suivi', { p_org: org() }); st.pay = Array.isArray(r) ? r : []; st.payAt = Date.now(); st.newPay = st.pay.filter(function (x) { return x.statut === 'en_attente'; }).length; render(); }
  catch (e) { var m = String((e && e.message) || e); if (!silent) say('Lecture impossible : ' + m + (/function|client_paiements_suivi/i.test(m) ? ' — exécutez supabase/migration-v142b-paiements-client.sql.' : ''), 'error'); }
}
function viewPay() {
  var L = st.pay, h = '<div class="pt-row" style="margin-bottom:10px"><button data-act="payPull" type="button">↻ Actualiser</button><span class="pt-mu">' + (st.payAt ? 'Lu à ' + new Date(st.payAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'Pas encore lu') + '</span></div>'
    + '<div class="pt-card pt-mu">Le client paie hors du logiciel (Mobile Money, banque, caisse), puis déclare la référence et le numéro de transaction dans son espace. Vérifiez sur votre relevé, <b>confirmez</b> (ou refusez avec un motif), puis <b>générez le reçu</b> : il est envoyé dans son espace.</div>';
  if (!L) return h + '<div class="pt-card pt-mu">' + (isIn() ? 'Appuyez sur « Actualiser » pour lire les paiements déclarés.' : 'Connectez-vous au compte en ligne pour lire les paiements.') + '</div>';
  if (!L.length) return h + '<div class="pt-card pt-mu">Aucun paiement déclaré pour le moment.</div>';
  return h + L.map(function (x) {
    var tag = x.statut === 'confirme' ? '<span class="pt-ok">✔ Confirmé</span>' : x.statut === 'refuse' ? '<span class="pt-err">✖ Refusé</span>' : '<span style="color:#b45309;font-weight:700">⏳ À vérifier</span>';
    var btn = x.statut === 'en_attente' ? '<button data-act="payOk" data-id="' + x.id + '" type="button">✔ Confirmer</button><button class="pt-s" data-act="payNo" data-id="' + x.id + '" type="button">✖ Refuser</button>'
      : x.statut === 'confirme' ? '<button data-act="payRecu" data-id="' + x.id + '" type="button">🧾 ' + (x.recu ? 'Renvoyer le reçu' : 'Générer et envoyer le reçu') + '</button>' : '';
    return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><div><b>' + esc(x.client || x.portail || 'Client') + '</b> · ' + money(x.statut === 'confirme' && x.montant_confirme ? x.montant_confirme : x.montant, x.devise) + (x.facture ? ' · facture ' + esc(x.facture) : '') + '</div>' + tag + '</div>'
      + '<div class="pt-mu">' + esc(PAYM[x.mode] || x.mode) + ' · réf. ' + esc(x.reference) + ' · <b>transaction ' + esc(x.trans_no) + '</b> · payé le ' + fr(x.date_paiement) + ' · déclaré le ' + fr(x.cree_le, 1) + (x.note ? ' · ' + esc(x.note) : '') + (x.recu_no ? ' · reçu ' + esc(x.recu_no) + (x.recu ? ' (envoyé)' : ' (à envoyer)') : '') + (x.statut === 'refuse' && x.motif ? ' · motif : ' + esc(x.motif) : '') + '</div>'
      + (btn ? '<div class="pt-row" style="margin-top:8px">' + btn + '</div>' : '') + '</div>';
  }).join('');
}

/* ---------- V204 : demandes des clients (inscription en ligne) — tout se traite ici : fiche client, chantier, paiements, devis, échanges ---------- */
async function pullDem(silent) {
  var inb = w.EXB_INBOX; try { if (inb && inb.on() && inb.reload) await inb.reload(); } catch (e) {}
  if (!isIn()) { if (!silent) say('Connectez-vous au compte en ligne pour lire les demandes.', 'warn'); st.dem = st.dem || []; render(); return; }
  try { needOrg(); var r = await rpc('client_comptes_suivi', { p_org: org() }); st.dem = Array.isArray(r) ? r : []; st.demAt = Date.now(); demCache(demRows()); st.newDem = st.dem.filter(function (x) { return (x.paiements_attente | 0) > 0; }).length; await pullPay(true); }
  catch (e) { var m = String((e && e.message) || e); st.dem = st.dem || []; if (!silent) say('Lecture impossible : ' + m + (/function|client_comptes_suivi/i.test(m) ? ' — exécutez supabase/migration-v204-demandes-clients-portails.sql.' : ''), 'error'); }
  render();
}
/* V204 : dernière lecture conservée sur l'appareil → la liste reste visible hors connexion (comme les apprenants) */
function demCache(set) { try { if (set) { localStorage.setItem('exb_dem_cache', JSON.stringify({ at: Date.now(), dem: st.dem || [], rows: set })); return; } var c = JSON.parse(localStorage.getItem('exb_dem_cache') || 'null'); if (c && !st.dem) { st.dem = c.dem || []; st.demAt = c.at; } return c ? c.rows || [] : []; } catch (e) { return []; } }
function demRows() { var r = []; try { r = (w.EXB_INBOX && w.EXB_INBOX.on && w.EXB_INBOX.on() && w.EXB_INBOX.rows) ? w.EXB_INBOX.rows('btp') : []; } catch (e) {} if (r.length || (w.EXB_INBOX && w.EXB_INBOX.on && w.EXB_INBOX.on())) { if (r.length) demCache(r); return r; } return demCache(); }
function chantierOf(key) { return G('exb_projects').find(function (x) { return x.req && key && String(x.req).toUpperCase() === String(key).toUpperCase(); }); }
function ficheOf(tel, nom) { var dg = String(tel || '').replace(/\D/g, ''); return G('exb_clients').find(function (c) { return (dg && String(c.phone || '').replace(/\D/g, '') === dg) || (nom && String(c.full_name || '').toLowerCase() === String(nom).toLowerCase()); }); }
function viewDem() {
  var L = st.dem || [], rows = demRows(), used = {};
  var h = '<div class="pt-row" style="margin-bottom:10px"><button data-act="demPull" type="button">↻ Actualiser</button><span class="pt-mu">' + (st.demAt ? 'Lu à ' + new Date(st.demAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'Pas encore lu') + '</span>' + (isIn() ? '' : '<span class="pt-mu"> · hors connexion serveur : dernière liste affichée. Les fiches et chantiers déjà créés restent dans le logiciel ; connectez-vous pour récupérer les nouvelles demandes.</span>') + '</div>'
    + '<div class="pt-card pt-mu">Quand un client s’inscrit (formulaire en ligne), sa <b>fiche client</b> et son <b>chantier</b> sont créés automatiquement à l’ouverture du logiciel. Ici vous traitez <b>tout</b> ce qu’il envoie : confirmer ses paiements, <b>annexer un devis</b> ou un plan dans son espace, lui répondre, et ouvrir sa fiche dans Clients &amp; CRM. Ces demandes n’apparaissent plus dans « Inscriptions » (réservé à la formation).</div>';
  function card(a, row) {
    var d0 = row ? (row.d || {}) : {}, rs = (a && a.demandes && a.demandes[0] && a.demandes[0].resume) || {}, nom = (a && a.nom) || d0.name || rs.name || 'Client', tel = (a && a.tel) || d0.phone || rs.phone || '', mat = (a && a.matricule) || (row && row.m) || '';
    var key = mat || (row && row.id) || '', fi = ficheOf(tel, nom), ch = chantierOf(key), cat = d0.category || rs.category || (a && a.demandes && a.demandes[0] && a.demandes[0].type) || '';
    var pays = a && a.token ? (st.pay || []).filter(function (x) { return x.token === a.token; }) : [], att = pays.filter(function (x) { return x.statut === 'en_attente'; });
    var tag = function (ok, y, n2) { return '<span class="pt-tag" style="' + (ok ? 'background:#e7f6ec;color:#166534' : 'background:#fff4e5;color:#b45309') + '">' + (ok ? '✔ ' + y : '… ' + n2) + '</span> '; };
    var o = '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><div><b>' + esc(nom) + '</b>' + (mat ? ' · <span class="pt-mu">' + esc(mat) + '</span>' : '') + '</div><span class="pt-mu">' + (a && a.cree_le ? fr(a.cree_le, 1) : row && row.created_at ? fr(row.created_at, 1) : '') + '</span></div>'
      + '<div class="pt-mu">' + esc(tel) + (cat ? ' · ' + esc(cat) : '') + (d0.location || rs.location ? ' · ' + esc(d0.location || rs.location) : '') + (d0.budget || rs.budget ? ' · budget ' + esc(d0.budget || rs.budget) : '') + '</div>'
      + '<div style="margin:6px 0">' + tag(!!fi, 'Fiche client', 'Fiche client à créer') + tag(!!ch, 'Chantier', 'Chantier à créer') + tag(!!(a && a.token), a && a.brouillon ? 'Espace client (brouillon)' : 'Portail publié', 'Pas d’espace en ligne')
      + (a ? '<span class="pt-tag">💳 ' + (a.paiements_attente | 0) + ' à vérifier / ' + (a.paiements_total | 0) + '</span> <span class="pt-tag">📎 ' + (a.documents | 0) + ' document(s)</span> <span class="pt-tag">💬 ' + (a.messages_client | 0) + ' message(s) du client</span>' : '') + '</div>';
    att.forEach(function (x) { o += '<div class="pt-row" style="background:#fffbeb;border-radius:8px;padding:6px 8px;margin:4px 0"><span>⏳ <b>' + money(x.montant, x.devise) + '</b> · ' + esc(PAYM[x.mode] || x.mode) + ' · réf. ' + esc(x.reference) + ' · transaction ' + esc(x.trans_no) + '</span><button data-act="payOk" data-id="' + x.id + '" type="button">✔ Confirmer</button><button class="pt-s" data-act="payNo" data-id="' + x.id + '" type="button">✖ Refuser</button></div>'; });
    o += '<div class="pt-row" style="margin-top:8px">';
    if ((!fi || !ch) && row) o += '<button data-act="demMake" data-id="' + esc(row.id) + '" type="button">🏗️ Créer fiche client + chantier</button>';
    if (ch) o += '<button class="pt-s" data-act="demGo" data-id="projets" type="button">🏗️ Ouvrir le chantier</button>';
    o += '<button class="pt-s" data-act="demGo" data-id="clients" type="button">👥 Clients &amp; CRM</button>';
    if (a && a.token) o += '<button data-act="demDevis" data-id="' + esc(a.token) + '" data-k="' + esc(key) + '" type="button">📎 Annexer un devis / document</button><button class="pt-s" data-act="demMsg" data-id="' + esc(a.token) + '" type="button">💬 Répondre</button>';
    if (pays.length) o += '<button class="pt-s" data-act="tab" data-id="pay" type="button">💳 Tous les paiements</button>';
    return o + '</div></div>';
  }
  if (!isIn() && !rows.length) return h + '<div class="pt-card pt-mu">Connectez-vous au compte en ligne (⚙️ Administration › Compte, ou « Demandes reçues ») pour lire les inscriptions des clients.</div>';
  L.forEach(function (a) { var rw = rows.find(function (r) { return r.m && a.matricule && String(r.m).toUpperCase() === String(a.matricule).toUpperCase(); }); if (rw) used[rw.id] = 1; h += card(a, rw); });
  rows.forEach(function (r) { if (!used[r.id]) h += card(null, r); });
  if (!L.length && !rows.length) h += '<div class="pt-card pt-mu">' + (st.dem ? 'Aucune demande client pour le moment.' : 'Appuyez sur « Actualiser ».') + '</div>';
  return h;
}
function demDevisModal(tok, key) {
  var a = (st.dem || []).find(function (x) { return x.token === tok; }) || {}, nom = a.nom || '', ch = chantierOf(key) || {};
  var D = G('exb_finance').filter(function (x) { return x.type === 'devis' && ((ch.id && x.project === ch.id) || (nom && String(x.client || '').toLowerCase() === nom.toLowerCase())); });
  modal('<h3 style="margin:0 0 8px">📎 Annexer à ' + esc(nom || 'ce client') + '</h3>'
    + (D.length ? '<label>Devis du logiciel pour ce client / chantier (pré-remplit le titre et le numéro)</label><select id="dmD"><option value="">— choisir —</option>' + D.map(function (x, i) { return '<option value="' + i + '">' + esc(String(x.no || 'Devis')) + ' · ' + esc(String(x.title || x.label || '')) + (x.ttc ? ' · ' + money(x.ttc, x.cur || 'USD') : '') + '</option>'; }).join('') + '</select><p class="pt-mu">Ouvrez le devis dans Finance, générez son PDF, puis joignez-le ci-dessous.</p>' : '<p class="pt-mu">Aucun devis du logiciel n’est rattaché à ce client : joignez simplement le PDF.</p>')
    + '<label>Type de document</label><select id="dmG">' + DOCG.map(function (g) { return '<option value="' + g[0] + '"' + (g[0] === 'devis' ? ' selected' : '') + '>' + g[1] + '</option>'; }).join('') + '</select>'
    + '<label>Titre</label><input id="dmT" maxlength="160" placeholder="ex. Devis villa R+1"><label>Numéro (facultatif)</label><input id="dmN" maxlength="60"><label>Note pour le client (facultatif)</label><input id="dmO" maxlength="400">'
    + '<label>Fichier (PDF, PNG, JPG ou WebP — 6 Mo maximum)</label><input id="dmF" type="file" accept="application/pdf,image/png,image/jpeg,image/webp"><p class="pt-err" id="dmE"></p>'
    + '<div class="pt-row"><button data-act="demSend" data-id="' + esc(tok) + '" type="button">📤 Envoyer au client</button><button class="pt-s" data-act="close" type="button">Annuler</button></div>', function () {
      var sel = $('dmD'); if (sel) sel.onchange = function () { var x = D[Number(sel.value)]; if (x) { $('dmT').value = 'Devis ' + (x.no || '') + (x.title ? ' — ' + x.title : ''); $('dmN').value = x.no || ''; } };
      var ff = $('dmF'); if (ff) ff.onchange = function () { var t = $('dmT'), f0 = ff.files && ff.files[0]; if (f0 && t && !t.value) t.value = f0.name.replace(/\.[^.]+$/, ''); };
    });
}
/* V142c : reçu à la disposition du modèle Excellencia Building (sections 1 à 4, signatures, QR de vérification) ; repli sur l'ancien moteur si le module est absent */
async function recuBlob(px, nowT, amt) {
  if (w.EXBRecuClient) {
    var pc = portals().find(function (x) { return x.token === px.token; }) || {}, pr = projOf(pc.pid), cl = clientOf(px.client || pc.dest) || {};
    var fac = px.facture ? G('exb_finance').find(function (f) { return f.type === 'facture' && String(f.no) === String(px.facture) && (!pc.pid || !f.project || f.project === pc.pid); }) : null;
    var total = fac && Number(fac.ttc) > 0 && (fac.cur || px.devise) === px.devise ? Number(fac.ttc) : null;
    var avant = (st.pay || []).filter(function (x) { return x.id !== px.id && x.statut === 'confirme' && x.recu_no && x.recu_no < px.recu_no && x.devise === px.devise && (px.facture ? x.facture === px.facture : x.token === px.token); }).reduce(function (s0, x) { return s0 + (Number(x.montant_confirme || x.montant) || 0); }, 0);
    var solde = total == null ? null : Math.max(0, Math.round((total - avant - amt) * 100) / 100);
    var motif = solde != null && solde <= 0.005 ? 'solde' : avant > 0 ? 'avancement' : 'acompte';
    return w.EXBRecuClient.make({ recu_no: px.recu_no, date: String(nowT).slice(0, 10), devise: px.devise, client: px.client || pc.dest || '', matricule: cl.matricule || '', tel: cl.phone || pc.tel || '', adresse: cl.email || pc.email || cl.address || '',
      projet: pr.name || px.portail || '', contrat: px.facture ? 'Facture ' + px.facture : '', motif: motif, montant: amt, mode: px.mode, reference: px.reference, trans_no: px.trans_no, total: total, dejaPaye: avant, solde: solde });
  }
  return w.EXBPdf.make({ titre: 'REÇU DE PAIEMENT', sousTitre: 'N° ' + px.recu_no + ' · émis le ' + fr(nowT), verify: false, cover: false,
    rows: [['Reçu n°', px.recu_no], ['Reçu de', px.client || px.portail || '–'], ['Dossier / projet', px.portail || '–'], ['Facture concernée', px.facture || '–'], ['Montant reçu', money(amt, px.devise)], ['Mode de paiement', PAYM[px.mode] || px.mode], ['Référence', px.reference], ['N° de transaction', px.trans_no], ['Date du paiement', fr(px.date_paiement)], ['Statut', 'PAYÉ — confirmé le ' + fr(nowT)]],
    notes: ['Ce reçu atteste la réception du paiement indiqué ci-dessus, après vérification de la transaction par l’entreprise.'], footer: 'Reçu ' + px.recu_no });
}
function blobUrl(b) { return new Promise(function (ok, ko) { var f = new FileReader(); f.onload = function () { ok(f.result); }; f.onerror = function () { ko(new Error('lecture du reçu')); }; f.readAsDataURL(b); }); }

/* ---------- actions ---------- */
function setField(t) { if (t.dataset.f && st.ed) { var k = t.dataset.f; st.ed[k] = (k === 'expDays') ? Number(t.value) : t.value; if (k === 'kind') { st.ed.opts.docs = []; render(); } if (k === 'pid') { var pr = projOf(t.value), cl = clientOf(pr.client); if (!st.ed.titre) st.ed.titre = 'Suivi — ' + (pr.name || ''); if (st.ed.kind === 'client') { st.ed.dest = pr.client || st.ed.dest; st.ed.tel = cl.phone || st.ed.tel; st.ed.email = cl.email || st.ed.email; } render(); } }
  else if (t.dataset.o && st.ed) { var o = t.dataset.o; st.ed.opts[o] = t.type === 'checkbox' ? t.checked : (['photos', 'journal'].indexOf(o) >= 0 ? Number(t.value) : t.value); }
  else if (t.dataset.doc && st.ed) { var A = st.ed.opts.docs = st.ed.opts.docs || [], i = A.indexOf(t.dataset.doc); if (t.checked && i < 0) A.push(t.dataset.doc); if (!t.checked && i >= 0) A.splice(i, 1); }
  else if (t.dataset.d && st.edDoc) { st.edDoc[t.dataset.d] = t.value; if (t.dataset.d === 'type') { var ty = TYPES.find(function (x) { return x[0] === t.value; }); if (ty) st.edDoc.role = ty[2]; render(); } }
}
/* confirmation intégrée à la page (EXBUI) ; repli : boîte native */
async function askOk(m) { try { if (w.EXBUI && w.EXBUI.confirm) return !!(await w.EXBUI.confirm(m, { danger: true, ok: 'Confirmer' })); } catch (e) {} return w.confirm(m); }
function moTxt(n) { n = +n || 0; return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
function cleDoc(x) { return (x.genre || 'plan') + '|' + String(x.titre || '').trim().toLowerCase().replace(/\s+/g, ' '); }
/* anciennes versions : même genre + même titre, version inférieure à la plus récente, pour le portail (token) du document id */
function vieux(list, anyId) {
  var ref = (list || []).find(function (x) { return x.id === anyId; }), tok = ref ? ref.token : null, max = {}, out = [];
  (list || []).forEach(function (x) { if (tok && x.token !== tok) return; var k = cleDoc(x); if (!(k in max) || x.version > max[k]) max[k] = x.version; });
  (list || []).forEach(function (x) { if (tok && x.token !== tok) return; if (x.version < max[cleDoc(x)]) out.push(x.id); });
  return out;
}
function sumDocs(mine, pid) {
  if (!mine.length) return '';
  var tot = 0, max = {}, nOld = 0, firstOld = '';
  mine.forEach(function (x) { tot += +x.taille || 0; var k = cleDoc(x); if (!(k in max) || x.version > max[k]) max[k] = x.version; });
  mine.forEach(function (x) { if (x.version < max[cleDoc(x)]) { nOld++; if (!firstOld) firstOld = x.id; } });
  return '<p style="margin:0 0 6px"><small>' + mine.length + ' document(s) · ' + moTxt(tot) + ' sur Supabase</small>' +
    (nOld ? ' <button class="pt-s" type="button" data-act="pPlanOld" data-id="' + esc(firstOld) + '" data-p="' + esc(pid) + '">🧹 Supprimer les ' + nOld + ' ancienne(s) version(s)</button>' : '') + '</p>';
}
async function onAct(a, id, el) {
  var P;
  if (a === 'tab') { st.tab = id; st.msg = ''; if (id === 'r') { pullRet(true); try { localStorage.setItem('exb_pt_seen', String(Date.now())); } catch (e) {} st.newMsg = 0; } if (id === 'n') analyze(); if (id === 'pay') pullPay(true); if (id === 'dem') pullDem(true); return render(); }
  if (a === 'close') { var m = $('ptModal'); if (m) m.remove(); return; }
  if (a === 'padClr') { if (PAD) PAD.clear(); return; }
  if (a === 'newP') { st.ed = blankEd(); st.msg = ''; return render(); }
  if (a === 'edCancel') { st.ed = null; return render(); }
  if (a === 'pEd') { var p0 = portals().find(function (x) { return x.id === id; }); if (p0) { st.ed = JSON.parse(JSON.stringify(p0)); var cm = codes()[p0.id] || {}; st.ed.code = cm.code || ''; st.ed.codeOnServer = cm.srv || ''; st.msg = ''; render(); } return; }
  if (a === 'pubGo' || a === 'pRe') { var r = a === 'pRe' ? JSON.parse(JSON.stringify(portals().find(function (x) { return x.id === id; }))) : st.ed; if (!r) return; if (a === 'pRe') { var cm2 = codes()[r.id] || {}; r.code = cm2.code || ''; r.codeOnServer = cm2.srv || ''; }
    if (!r.pid) { st.msg = 'Choisissez un projet.'; return render(); } if (!/^\d{6,12}$/.test(r.code || '') && !r.token) { st.msg = 'Le code doit contenir 6 à 12 chiffres.'; return render(); }
    if (!r.id) r.id = uid('PT'); r.titre = r.titre || ('Suivi — ' + (projOf(r.pid).name || '')); st.busy = true; st.msg = ''; render();
    try { await publish(r); savePortal(r); st.ed = null; st.busy = false; 
      if (r.kind === 'client' && cfg().on.publication && r.dest) pushQ([{ key: 'P:' + r.id + ':' + r.pub, rule: 'publication', objet: 'Avancement mis à jour : ' + r.titre, nom: r.dest, tel: r.tel, email: r.email, texte: fill(cfg().tpl.publication, { nom: r.dest, projet: projOf(r.pid).name || '', lien: linkOf(r.token), entreprise: ident().name || '' }) }]);
      render(); say('Portail publié. Envoyez le lien, puis le code par un autre canal.'); } catch (e) { st.busy = false; st.msg = 'Publication impossible : ' + (e.message || e) + (/function|portail_publier/i.test(String(e.message)) ? ' — exécutez supabase/migration-v99zn-portails.sql.' : ''); if (a === 'pRe') say(st.msg, 'error'); render(); }
    return; }
  if (a === 'pLink' || a === 'pCode') { var p = portals().find(function (x) { return x.id === id; }); if (!p) return; var kc = (codes()[p.id] || {}).code;
    if (a === 'pCode' && !kc) { if (!(await exbConfirm('Le code n’est pas conservé sur cet appareil (il n’est jamais synchronisé). Générer un NOUVEAU code ? L’ancien cessera de fonctionner.'))) return; var nr = JSON.parse(JSON.stringify(p)); nr.code = String(100000 + Math.floor(Math.random() * 900000)); nr.codeOnServer = ''; try { await publish(nr); savePortal(nr); p = nr; kc = (codes()[p.id] || {}).code; } catch (e) { say('Échec : ' + (e.message || e), 'error'); return; } }
    p = Object.assign({}, p, { code: kc }); var I = ident(), txt = a === 'pLink' ? 'Bonjour ' + (p.dest || '') + ', voici votre espace de suivi « ' + p.titre + ' » : ' + linkOf(p.token) + '\n(Le code d’accès vous est envoyé séparément.) — ' + (I.name || '') : 'Code d’accès à votre espace de suivi « ' + p.titre + ' » : ' + p.code + ' — ' + (I.name || '');
    openChan({ id: 'x', texte: txt, tel: p.tel, email: p.email, objet: p.titre }, 'wa'); return; }
  if (a === 'pQr') { var q = portals().find(function (x) { return x.id === id; }); if (!q) return; var u = linkOf(q.token), svg = ''; try { svg = w.EXBQR.svg(u, { px: 5, quiet: 2 }); } catch (e) { svg = '<p class="pt-mu">Lien trop long pour un QR.</p>'; } modal('<h3>' + esc(q.titre) + '</h3><div style="max-width:260px;margin:10px auto;background:#fff;padding:8px">' + svg + '</div><p class="pt-mu" style="word-break:break-all">' + esc(u) + '</p><div class="pt-row"><button class="pt-s" data-act="copyL" data-id="' + q.id + '" type="button">Copier le lien</button><button data-act="close" type="button">Fermer</button></div>'); return; }
  if (a === 'demPull') return pullDem(false);
  if (a === 'demGo') { try { w.show(id); } catch (e) {} return; }
  if (a === 'demMake') { try { await w.EXB_INBOX.importBtp([id]); say('Fiche client et chantier créés.'); } catch (e) { say('Échec : ' + String((e && e.message) || e), 'error'); } return render(); }
  if (a === 'demDevis') return demDevisModal(id, el && el.dataset.k);
  if (a === 'demSend') { var de2 = $('dmE'), er2 = function (m) { if (de2) de2.textContent = m; }, f2 = $('dmF').files && $('dmF').files[0], t2 = ($('dmT').value || '').trim();
    if (!f2) return er2('Choisissez le fichier à envoyer.'); if (t2.length < 2) return er2('Saisissez un titre.'); if (f2.size > 6 * 1048576) return er2('Fichier trop lourd (6 Mo maximum).');
    if (!/^(application\/pdf|image\/(png|jpeg|webp))$/.test(f2.type)) return er2('Format accepté : PDF, PNG, JPG ou WebP.');
    var g2 = $('dmG').value, n2 = ($('dmN').value || '').trim(), o2 = ($('dmO').value || '').trim(), fr3 = new FileReader(); fr3.onload = async function () {
      try { needOrg(); await rpc('client_doc_publier', { p_org: org(), p_token: id, p_genre: g2, p_titre: t2, p_numero: n2, p_note: o2, p_data: fr3.result });
        var m4 = $('ptModal'); if (m4) m4.remove(); say('Document envoyé : le client le verra dans « Plans & Documents » de son espace.'); pullDem(true);
      } catch (e) { var em = String((e && e.message) || e); er2(/function|client_doc_publier/i.test(em) ? 'Envoi impossible : exécutez supabase/migration-v142a-documents-client.sql.' : /fichier_trop_lourd/.test(em) ? 'Fichier trop lourd (6 Mo maximum).' : 'Envoi impossible : ' + em); } };
    fr3.readAsDataURL(f2); return; }
  if (a === 'demMsg') { var tx2 = await exbPrompt('Votre réponse au client :', ''); if (!tx2 || !tx2.trim()) return; try { await rpc('portail_repondre', { p_token: id, p_texte: tx2.trim() }); say('Réponse envoyée dans l’espace du client.'); } catch (e) { say('Échec : ' + String((e && e.message) || e), 'error'); } return; }
  if (a === 'payPull') return pullPay(false);
  if (a === 'payOk') { var po = (st.pay || []).find(function (x) { return x.id === id; }); if (!po) return;
    var rec = (await exbPrompt('Montant réellement reçu (' + po.devise + ') pour la transaction ' + po.trans_no + ' :\nVérifiez d’abord sur votre relevé Mobile Money / banque.', String(po.montant))); if (rec === null) return;
    var mv = Number(String(rec).replace(/\s/g, '').replace(',', '.')); if (!(mv > 0)) return say('Montant invalide.', 'error');
    try { needOrg(); var ro = await rpc('client_paiement_decider', { p_org: org(), p_id: po.id, p_statut: 'confirme', p_montant: mv, p_motif: '' }); await pullPay(true); say('Paiement confirmé : reçu ' + ro.recu_no + '. Générez-le pour l’envoyer au client.'); }
    catch (e) { say('Échec : ' + String((e && e.message) || e), 'error'); } return; }
  if (a === 'payNo') { var pn = (st.pay || []).find(function (x) { return x.id === id; }); if (!pn) return;
    var mo = (await exbPrompt('Motif du refus (le client le verra) :', 'Transaction introuvable sur notre relevé.')); if (mo === null) return; if (mo.trim().length < 3) return say('Motif obligatoire.', 'error');
    try { needOrg(); await rpc('client_paiement_decider', { p_org: org(), p_id: pn.id, p_statut: 'refuse', p_montant: null, p_motif: mo.trim() }); await pullPay(true); say('Paiement refusé. Le client est informé dans son espace.'); }
    catch (e) { say('Échec : ' + (/recu_deja_envoye/.test(String((e && e.message) || e)) ? 'un reçu a déjà été envoyé pour ce paiement.' : String((e && e.message) || e)), 'error'); } return; }
  if (a === 'payRecu') { var px = (st.pay || []).find(function (x) { return x.id === id; }); if (!px || px.statut !== 'confirme' || !px.recu_no) return;
    if (!w.EXBPdf && !w.EXBRecuClient) return say('Module PDF indisponible dans cette copie.', 'warn');
    try { needOrg(); say('Génération du reçu…', 'info');
      var nowT = px.decide_le || new Date().toISOString(), amt = Number(px.montant_confirme || px.montant);
      var blob = await recuBlob(px, nowT, amt);
      if (blob.type !== 'application/pdf') blob = new Blob([blob], { type: 'application/pdf' });
      var du = await blobUrl(blob); var rr = await rpc('client_recu_publier', { p_org: org(), p_id: px.id, p_data: du }); await pullPay(true);
      say('Reçu ' + px.recu_no + ' envoyé dans l’espace du client.');
      var pc = portals().find(function (x) { return x.token === px.token; }) || {}, Ir = ident(), br = (window.exbBase ? window.exbBase() : location.origin + location.pathname.replace(/[^\/]*$/, ''));
      openChan({ id: 'x', texte: 'Bonjour ' + (px.client || pc.dest || '') + ', votre paiement de ' + money(amt, px.devise) + ' est confirmé. Votre reçu n° ' + px.recu_no + ' est disponible dans votre espace client : ' + br + 'espace-client.html' + (Ir.name ? ' — ' + Ir.name : ''), tel: pc.tel, email: pc.email, objet: 'Reçu ' + px.recu_no }, 'wa'); }
    catch (e) { var em2 = String((e && e.message) || e); say('Envoi du reçu impossible : ' + (/function|client_recu_publier/i.test(em2) ? 'exécutez supabase/migration-v142b-paiements-client.sql.' : /fichier_trop_lourd/.test(em2) ? 'fichier trop lourd.' : em2), 'error'); } return; }
  if (a === 'pPlan') { var pp = portals().find(function (x) { return x.id === id; }); if (!pp) return;
    modal('<h3 style="margin:0 0 8px">📎 Envoyer un document à ' + esc(pp.dest || pp.titre) + '</h3><label>Type de document</label><select id="dcG">' + DOCG.map(function (g) { return '<option value="' + g[0] + '">' + g[1] + '</option>'; }).join('') + '</select>'
      + '<label>Titre (même type + même titre = nouvelle version « modifiée »)</label><input id="dcT" maxlength="160" placeholder="ex. Plan R+1, Devis villa, Note de calcul poutre P1">'
      + '<label>Numéro du document (facultatif)</label><input id="dcN" maxlength="60" placeholder="ex. DEV-2026-007">'
      + '<label>Note pour le client (facultatif)</label><input id="dcO" maxlength="400" placeholder="ex. poteaux déplacés">'
      + '<label>Fichier (PDF, PNG, JPG ou WebP — 6 Mo maximum)</label><input id="dcF" type="file" accept="application/pdf,image/png,image/jpeg,image/webp">'
      + '<p class="pt-mu">Plan DXF, IFC ou DWG : exportez-le d’abord en PDF. Devis et notes de calcul : utilisez le PDF généré par le logiciel.</p><p class="pt-err" id="dcE"></p>'
      + '<div class="pt-row"><button data-act="docSend" data-id="' + pp.id + '" type="button">📤 Envoyer</button><button class="pt-s" data-act="close" type="button">Annuler</button></div>');
    var ff = $('dcF'); if (ff) ff.onchange = function () { var t = $('dcT'), f0 = ff.files && ff.files[0]; if (f0 && t && !t.value) t.value = f0.name.replace(/\.[^.]+$/, ''); };
    return; }
  if (a === 'docSend') { var dp = portals().find(function (x) { return x.id === id; }); if (!dp) return; var de = $('dcE'), er = function (m) { if (de) de.textContent = m; };
    var gen = $('dcG').value, tit = ($('dcT').value || '').trim(), num = ($('dcN').value || '').trim(), nte = ($('dcO').value || '').trim(), f = $('dcF').files && $('dcF').files[0];
    if (!f) return er('Choisissez le fichier à envoyer.'); if (tit.length < 2) return er('Saisissez un titre.');
    if (f.size > 6 * 1048576) return er('Fichier trop lourd (6 Mo maximum). Allégez le PDF.');
    if (!/^(application\/pdf|image\/(png|jpeg|webp))$/.test(f.type)) return er('Format accepté : PDF, PNG, JPG ou WebP.');
    if (el) el.disabled = true; var fr2 = new FileReader(); fr2.onload = async function () {
      try { needOrg(); var r2 = await rpc('client_doc_publier', { p_org: org(), p_token: dp.token, p_genre: gen, p_titre: tit, p_numero: num, p_note: nte, p_data: fr2.result });
        var mod = r2 && r2.version > 1, I3 = ident(), b3 = (window.exbBase ? window.exbBase() : location.origin + location.pathname.replace(/[^\/]*$/, '')), gl = (DOCG.find(function (g) { return g[0] === gen; }) || [0, 'Document'])[1];
        var m3 = $('ptModal'); if (m3) m3.remove();
        say(mod ? gl + ' modifié envoyé (version ' + r2.version + '). Le client le verra à sa prochaine connexion.' : gl + ' envoyé. Le client le verra à sa prochaine connexion.');
        openChan({ id: 'x', texte: 'Bonjour ' + (dp.dest || '') + ', ' + (mod ? 'le document « ' + tit + ' » (' + gl.toLowerCase() + ') a été mis à jour (version ' + r2.version + ')' : 'un nouveau document est disponible dans votre espace client : « ' + tit + ' » (' + gl.toLowerCase() + ')') + (nte ? ' — ' + nte : '') + '. Consultez-le ici : ' + b3 + 'espace-client.html' + (I3.name ? ' — ' + I3.name : ''), tel: dp.tel, email: dp.email, objet: gl + (mod ? ' modifié' : ' disponible') + ' : ' + tit }, 'wa');
      } catch (e) { var em = String((e && e.message) || e); if (el) el.disabled = false; er(/function|client_doc_publier/i.test(em) ? 'Envoi impossible : exécutez supabase/migration-v142a-documents-client.sql.' : /fichier_trop_lourd/.test(em) ? 'Fichier trop lourd (6 Mo maximum).' : 'Envoi impossible : ' + em); } };
    fr2.readAsDataURL(f); return; }
  if (a === 'pPlanDel' || a === 'pPlanOld') {
    var pid = el && el.dataset ? el.dataset.p : '', ids = [id];
    var okc = await askOk(a === 'pPlanDel' ? 'Supprimer ce document de l’espace du client ?\nIl disparaîtra de son espace et l’espace sera libéré sur Supabase. Action irréversible.'
      : 'Supprimer les anciennes versions des documents de ce client ?\nSeule la dernière version de chaque document est conservée. Action irréversible.');
    if (!okc) return;
    if (a === 'pPlanOld') { try { var sv2 = await rpc('client_plans_suivi', { p_org: org() }); ids = vieux(sv2, id); } catch (e) { say('Lecture impossible : ' + ((e && e.message) || e), 'error'); return; }
      if (!ids.length) { say('Aucune ancienne version à supprimer.'); return; } }
    try { needOrg(); for (var di = 0; di < ids.length; di++) await rpc('client_plan_retirer', { p_org: org(), p_id: ids[di] });
      say(ids.length > 1 ? ids.length + ' documents supprimés. Espace libéré sur Supabase.' : 'Document supprimé. Espace libéré sur Supabase.'); }
    catch (e) { var em9 = String((e && e.message) || e); say(/function|client_plan_retirer/i.test(em9) ? 'Suppression impossible : exécutez supabase/migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql.' : 'Suppression impossible : ' + em9, 'error'); }
    return onAct('pPlans', pid); }
  if (a === 'pPlans') { var pq = portals().find(function (x) { return x.id === id; }); if (!pq) return;
    try { var sv = await rpc('client_plans_suivi', { p_org: org() }); var mine = (sv || []).filter(function (x) { return x.token === pq.token; });
      modal('<h3 style="margin:0 0 8px">📋 Documents envoyés — ' + esc(pq.titre) + '</h3>' + sumDocs(mine, pq.id) + (mine.length ? mine.map(function (x) { return '<div class="pt-row" style="justify-content:space-between;border-bottom:1px solid #e2e8f0;padding:6px 0"><span><b>' + esc(x.titre) + '</b> · ' + esc(((DOCG.find(function (g) { return g[0] === x.genre; }) || [0, '📐 Plan'])[1])) + (x.numero ? ' ' + esc(x.numero) : '') + ' · version ' + x.version + '<br><small>Envoyé le ' + fr(x.publie_le, 1) + ' · ' + moTxt(x.taille) + '</small></span><span class="pt-tag ' + (x.vu_le ? 'pt-ok' : 'pt-wa') + '">' + (x.vu_le ? 'Vu le ' + fr(x.vu_le, 1) : 'Pas encore ouvert') + '</span><button class="pt-s" type="button" style="margin-left:8px" title="Supprimer ce document" data-act="pPlanDel" data-id="' + esc(x.id) + '" data-p="' + esc(pq.id) + '">🗑</button></div>'; }).join('') : '<p>Aucun document envoyé.</p>') + '<p><button class="pt-s" type="button" onclick="document.getElementById(\'ptModal\').remove()">Fermer</button></p>');
    } catch (e) { say('Lecture impossible : ' + ((e && e.message) || e), 'error'); } return; }
  if (a === 'pAcc') { var ap = portals().find(function (x) { return x.id === id; }); if (!ap || ap.kind !== 'client') return;
    var mat = (await exbPrompt('Matricule du client (c’est son identifiant de connexion).\nSon mot de passe provisoire sera ce même matricule ; il devra en choisir un nouveau dès sa première connexion.\nSi le compte existe déjà, il est réinitialisé.', (clientOf(ap.dest) || {}).id || ''));
    if (!mat || !mat.trim()) return; mat = mat.trim().toUpperCase();
    try { needOrg(); await rpc('client_compte_creer', { p_org: org(), p_matricule: mat, p_nom: ap.dest || '', p_token: ap.token }); }
    catch (e) { var em = String((e && e.message) || e); say(/matricule_invalide/.test(em) ? 'Matricule invalide (4 à 40 caractères : lettres, chiffres, - . _ /).' : /matricule_pris/.test(em) ? 'Ce matricule est déjà utilisé par une autre organisation.' : /portail_introuvable/.test(em) ? 'Portail introuvable : republiez-le d’abord.' : /function|client_compte_creer/i.test(em) ? 'Compte impossible : exécutez supabase/migration-v99zzzzzzzzzzzzzzz-espace-client.sql.' : 'Compte impossible : ' + em, 'error'); return; }
    var b2 = (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,'')), I2 = ident();
    openChan({ id: 'x', texte: 'Bonjour ' + (ap.dest || '') + ', votre espace client est prêt : ' + b2 + 'espace-client.html\nIdentifiant : ' + mat + '\nMot de passe provisoire : ' + mat + ' (à changer dès la première connexion).' + (I2.name ? ' — ' + I2.name : ''), tel: ap.tel, email: ap.email, objet: 'Votre espace client' }, 'wa');
    say('Compte client créé : identifiant et mot de passe provisoire = ' + mat + '.'); return; }
  if (a === 'copyL') { var c = portals().find(function (x) { return x.id === id; }); try { await navigator.clipboard.writeText(linkOf(c.token)); say('Lien copié.'); } catch (e) { (await exbPrompt('Copiez le lien :', linkOf(c.token))); } return; }
  if (a === 'pRev') { var rv = portals().find(function (x) { return x.id === id; }); if (!rv || !(await exbConfirm('Révoquer ce portail ? Le lien cessera de fonctionner immédiatement.'))) return; try { await rpc('portail_revoquer', { p_token: rv.token }); rv.actif = false; savePortal(rv); render(); say('Portail révoqué.'); } catch (e) { say('Échec : ' + (e.message || e), 'error'); } return; }
  if (a === 'pDel') { var dp = portals().find(function (x) { return x.id === id; }); if (!dp || !(await exbConfirm('Retirer ce portail de la liste ? (Pensez à le révoquer d’abord : sinon le lien reste actif.)'))) return; Pu('exb_portails', portals().filter(function (x) { return x.id !== id; })); return render(); }
  /* documents */
  if (a === 'newD') { var pj = G('exb_projects')[0] || {}; st.edDoc = { id: '', type: 'contrat', role: 'client', pid: pj.id || '', titre: '', texte: '', v: 1 }; st.msg = ''; return render(); }
  if (a === 'dCancel') { st.edDoc = null; return render(); }
  if (a === 'dEd') { var dd = docs().find(function (x) { return x.id === id; }); if (dd && !dd.locked) { st.edDoc = JSON.parse(JSON.stringify(dd)); st.edDoc.role = (dd.roles || ['client'])[0]; render(); } return; }
  if (a === 'dModel') { var e = st.edDoc, pr = projOf(e.pid), cl = clientOf(pr.client); if (e.texte && !(await exbConfirm('Remplacer le texte actuel par le modèle ?'))) return; e.texte = model(e.type, { entreprise: ident().name, client: e.role === 'client' ? (pr.client || cl.full_name) : '', projet: pr.name, lieu: pr.location }); if (!e.titre) e.titre = (TYPES.find(function (t) { return t[0] === e.type; }) || [0, ''])[1] + (pr.name ? ' — ' + pr.name : ''); return render(); }
  if (a === 'dSave') { var x = st.edDoc; if (!x.titre.trim() || x.texte.trim().length < 20) { st.msg = 'Titre et texte (20 caractères minimum) obligatoires.'; return render(); } var hh = await sha(x.titre.trim() + '\n' + x.texte), D = docs(), rec = x.id ? D.find(function (y) { return y.id === x.id; }) : null;
    if (rec && rec.locked) { st.msg = 'Document verrouillé : créez une nouvelle version.'; return render(); }
    var n = Object.assign(rec || { id: uid('DOC'), sig: {}, date: today(), v: x.v || 1, locked: false }, { type: x.type, pid: x.pid, titre: x.titre.trim(), texte: x.texte, roles: [x.role], hash: hh }); if (!rec) D.unshift(n); Pu('exb_esign', D); st.edDoc = null; return render(); }
  if (a === 'dDel') { if (!(await exbConfirm('Supprimer ce brouillon ?'))) return; Pu('exb_esign', docs().filter(function (x) { return x.id !== id; })); return render(); }
  if (a === 'dVer') { var s0 = docs().find(function (x) { return x.id === id; }); if (!s0) return; st.edDoc = { id: '', type: s0.type, role: (s0.roles || ['client'])[0], pid: s0.pid, titre: s0.titre.replace(/ \(version \d+\)$/, ''), texte: s0.texte, v: (s0.v || 1) + 1 }; st.tab = 's'; return render(); }
  if (a === 'dSign') return signModal(id);
  if (a === 'useVisa') { try { var vs = await w.EXBId.visa(); if (vs) { PAD.visa = vs; $('ptVisi').innerHTML = '<span class="pt-ok">✔ Signature et cachet enregistrés utilisés.</span><br><img src="' + vs + '" style="height:60px;background:#fff">'; } } catch (e) {} return; }
  if (a === 'signGo') { var nom = ($('ptSn').value || '').trim(), fo = ($('ptSf').value || '').trim(), er = $('ptSe'); if (nom.length < 3) { er.textContent = 'Saisissez le nom du signataire.'; return; } if (!PAD || (!PAD.any && !PAD.visa)) { er.textContent = 'Tracez la signature (ou utilisez celle enregistrée).'; return; }
    var D2 = docs(), t = D2.find(function (y) { return y.id === id; }); t.sig = t.sig || {}; t.sig.entreprise = { nom: nom, fonction: fo, image: PAD.visa || PAD.png(), at: new Date().toISOString(), hash: t.hash }; Pu('exb_esign', D2); var m2 = $('ptModal'); if (m2) m2.remove(); say('Document signé par l’entreprise.'); return render(); }
  if (a === 'dPrint') return printDoc(id);
  /* retours */
  if (a === 'pull') return pullRet(false);
  if (a === 'dec') { try { await rpc('portail_decider', { p_id: id, p_statut: el.dataset.s, p_reponse: '' }); await pullRet(true); } catch (e) { say('Échec : ' + (e.message || e), 'error'); } return; }
  if (a === 'rep') { var inp = d.querySelector('[data-rep="' + id + '"]'), tx = inp && inp.value.trim(); if (!tx) return; try { await rpc('portail_repondre', { p_token: id, p_texte: tx }); await pullRet(true); } catch (e) { say('Échec : ' + (e.message || e), 'error'); } return; }
  /* relances */
  if (a === 'analyze') { var k = analyze(); say(k ? k + ' relance(s) préparée(s).' : 'Rien de nouveau à relancer.', k ? 'success' : 'info'); return render(); }
  if (a === 'send') { var qq = queue().find(function (x) { return x.id === id; }); if (qq) openChan(qq, el.dataset.how); return; }
  if (a === 'qDone' || a === 'qIgn') { var Q = queue(), qi = Q.findIndex(function (x) { return x.id === id; }); if (qi >= 0) { Q[qi].status = a === 'qDone' ? 'envoye' : 'ignore'; Pu('exb_msg_queue', Q); } return render(); }
  if (a === 'cfgSave') { var c2 = cfg(); d.querySelectorAll('[data-rule]').forEach(function (i) { c2.on[i.dataset.rule] = i.checked; }); d.querySelectorAll('[data-rn]').forEach(function (i) { c2[i.dataset.rn] = Math.max(1, Number(i.value) || 1); }); d.querySelectorAll('[data-tpl]').forEach(function (i) { c2.tpl[i.dataset.tpl] = i.value; }); saveCfg(c2); say('Règles enregistrées.'); return render(); }
}

/* ---------- montage ---------- */
var mounted = false, tries = 0;
function mount() {
  if (mounted) return; var host = $('clients'), b = $('bclients'); if (!host || !b) { if (++tries > 40) mounted = true; return; }
  if (!$('portails')) {
    host.insertAdjacentHTML('afterend', '<section id="portails" class="no-print" style="display:none"></section>'); b.insertAdjacentHTML('afterend', ' <button id="bportails" onclick="show(\'portails\')">🔗 Portails & signatures</button>');
    var el = $('portails'); el.addEventListener('click', function (e) { var t = e.target.closest('[data-act]'); if (t) onAct(t.dataset.act, t.dataset.id, t); });
    el.addEventListener('change', function (e) { setField(e.target); }); el.addEventListener('input', function (e) { var t = e.target; if (t.matches('textarea,input[type=text],input:not([type]),input[type=number]') && (t.dataset.f || t.dataset.o || t.dataset.d) && t.dataset.f !== 'kind') { if (t.dataset.f === 'pid') return; setField(t); } });
    d.addEventListener('click', function (e) { var t = e.target.closest('#ptModal [data-act]'); if (t) onAct(t.dataset.act, t.dataset.id, t); });
    var os = w.show; w.show = function (x) { var r = os.apply(this, arguments); var s = $('portails'); if (s) s.style.display = x === 'portails' ? '' : 'none'; if (x === 'portails') { analyze(); render(); if (isIn() && Date.now() - st.retAt > 120000) pullRet(true); } return r; };
  }
  mounted = true;
}
setInterval(mount, 1500); setTimeout(mount, 800); setInterval(function () { try { analyze(); } catch (e) {} }, 6 * 3600 * 1000);
/* V142e : envoi d'un PDF déjà généré (pièces écrites, documents de chantier, page de garde…) dans l'espace d'un client.
 * EXB_PORTAILS.envoyerDocument(blobPdf, { project, titre, numero, genre, filename }) : choix du client, du type et du titre, puis client_doc_publier (même fonction que « 📎 Envoyer un document »). */
function envoyerDocument(blob, o) {
  o = o || {};
  if (!blob) return say('Aucun PDF à envoyer.', 'warn');
  if (!isIn()) return say('Connectez-vous au compte en ligne (⚙️ Administration › Compte) pour envoyer au client.', 'warn');
  var L = portals().filter(function (p) { return p.kind === 'client' && p.token && p.actif !== false; });
  if (!L.length) return say('Aucun portail client publié : créez-en un dans 🔗 Portails & signatures (Clients & CRM), puis réessayez.', 'warn');
  var def = L.filter(function (p) { return o.project && p.pid === o.project; })[0] || L[0];
  var gen0 = DOCG.some(function (g) { return g[0] === o.genre; }) ? o.genre : 'autre';
  var old = $('ptSendDoc'); if (old) old.remove();
  var ov = d.createElement('div'); ov.id = 'ptSendDoc'; ov.className = 'no-print';
  ov.style.cssText = 'position:fixed;inset:0;z-index:100001;background:rgba(0,0,0,.6);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:16px';
  var IS = 'width:100%;box-sizing:border-box;padding:9px;margin:3px 0 8px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial';
  var name0 = String(o.titre || o.filename || '').replace(/\.pdf$/i, '');
  ov.innerHTML = '<div id="pcBox" style="background:#fff;color:#172033;border-radius:14px;padding:18px;max-width:460px;width:100%;margin:auto;font:14px Arial">'
    + '<h3 style="margin:0 0 4px">📨 Envoyer à l’espace du client</h3><div style="font-size:12px;color:#64748b;margin-bottom:8px">' + esc(o.filename || 'document.pdf') + ' · ' + Math.max(1, Math.round(blob.size / 1024)) + ' Ko</div>'
    + '<label style="font-size:12px">Client (portail)</label><select id="pcP" style="' + IS + '">' + L.map(function (p) { return '<option value="' + esc(p.token) + '"' + (p === def ? ' selected' : '') + '>' + esc(p.dest || p.titre || 'Client') + (p.titre && p.dest ? ' — ' + esc(p.titre) : '') + '</option>'; }).join('') + '</select>'
    + '<label style="font-size:12px">Type de document</label><select id="pcG" style="' + IS + '">' + DOCG.map(function (g) { return '<option value="' + g[0] + '"' + (g[0] === gen0 ? ' selected' : '') + '>' + g[1] + '</option>'; }).join('') + '</select>'
    + '<label style="font-size:12px">Titre (même type + même titre = nouvelle version « modifiée »)</label><input id="pcT" maxlength="160" style="' + IS + '" value="' + esc(name0) + '">'
    + '<label style="font-size:12px">Numéro du document (facultatif)</label><input id="pcN" maxlength="60" style="' + IS + '" value="' + esc(o.numero || '') + '">'
    + '<label style="font-size:12px">Note pour le client (facultatif)</label><input id="pcO" maxlength="400" style="' + IS + '" placeholder="ex. à valider avant le début des travaux">'
    + '<p id="pcE" style="color:#b12b2b;font-size:13px;margin:4px 0;min-height:16px"></p>'
    + '<div style="display:flex;gap:8px"><button id="pcGo" type="button" style="flex:1;padding:12px;border:0;border-radius:9px;background:#173565;color:#fff;font-size:15px">📤 Envoyer</button><button id="pcNo" type="button" style="padding:12px 16px;border:0;border-radius:9px;background:#eef2f8;color:#173565;font-size:15px">Annuler</button></div></div>';
  ov.addEventListener('click', function (e) { if (e.target === ov) ov.remove(); });
  d.body.appendChild(ov);
  var er = function (m) { var e = $('pcE'); if (e) e.textContent = m; };
  $('pcNo').onclick = function () { ov.remove(); };
  $('pcGo').onclick = async function () {
    var tok = $('pcP').value, gen = $('pcG').value, tit = ($('pcT').value || '').trim(), num = ($('pcN').value || '').trim(), nte = ($('pcO').value || '').trim(), pp = L.filter(function (p) { return p.token === tok; })[0];
    if (!pp) return er('Choisissez le client.'); if (tit.length < 2) return er('Saisissez un titre.');
    if (blob.size > 6 * 1048576) return er('Fichier trop lourd (6 Mo maximum). Allégez le PDF (images plus petites).');
    var btn = $('pcGo'); btn.disabled = true; btn.textContent = 'Envoi…'; er('');
    try {
      needOrg(); var pdf = blob.type === 'application/pdf' ? blob : new Blob([blob], { type: 'application/pdf' }), du = await blobUrl(pdf);
      var r2 = await rpc('client_doc_publier', { p_org: org(), p_token: tok, p_genre: gen, p_titre: tit, p_numero: num, p_note: nte, p_data: du });
      var mod = r2 && r2.version > 1, I3 = ident(), b3 = (w.exbBase ? w.exbBase() : location.origin + location.pathname.replace(/[^\/]*$/, '')), gl = (DOCG.filter(function (g) { return g[0] === gen; })[0] || [0, 'Document'])[1];
      var txt = 'Bonjour ' + (pp.dest || '') + ', ' + (mod ? 'le document « ' + tit + ' » (' + gl.toLowerCase() + ') a été mis à jour (version ' + r2.version + ')' : 'un nouveau document est disponible dans votre espace client : « ' + tit + ' » (' + gl.toLowerCase() + ')') + (nte ? ' — ' + nte : '') + '. Consultez-le ici : ' + b3 + 'espace-client.html' + (I3.name ? ' — ' + I3.name : '');
      var box = $('pcBox'); if (!box) return;
      box.innerHTML = '<div style="text-align:center"><div style="font-size:34px">✅</div><b>' + esc(gl) + (mod ? ' modifié envoyé (version ' + r2.version + ')' : ' envoyé') + '</b><p style="color:#64748b;font-size:13px">' + esc(pp.dest || pp.titre || 'Le client') + ' le verra dans son espace (Plans &amp; Documents) à sa prochaine connexion ; il est aussi prévenu dans ses messages.</p>'
        + '<button id="pcWa" type="button" style="display:block;width:100%;padding:12px;margin:6px 0;border:0;border-radius:9px;background:#128c7e;color:#fff;font-size:15px">💬 Prévenir par WhatsApp</button>'
        + '<button id="pcMl" type="button" style="display:block;width:100%;padding:12px;margin:6px 0;border:0;border-radius:9px;background:#eef2f8;color:#173565;font-size:15px">✉️ Prévenir par e-mail</button>'
        + '<button id="pcOk" type="button" style="display:block;width:100%;padding:11px;margin-top:6px;border:0;background:none;color:#64748b;font-size:15px">Fermer</button></div>';
      var q = { id: 'x', texte: txt, tel: pp.tel, email: pp.email, objet: gl + (mod ? ' modifié' : ' disponible') + ' : ' + tit };
      $('pcWa').onclick = function () { openChan(q, 'wa'); }; $('pcMl').onclick = function () { openChan(q, 'mail'); }; $('pcOk').onclick = function () { ov.remove(); };
      say(gl + (mod ? ' modifié envoyé' : ' envoyé') + ' dans l’espace du client.');
    } catch (e) { var em = String((e && e.message) || e); btn.disabled = false; btn.textContent = '📤 Envoyer';
      er(/function|client_doc_publier/i.test(em) ? 'Envoi impossible : exécutez supabase/migration-v142a-documents-client.sql.' : /fichier_trop_lourd/.test(em) ? 'Fichier trop lourd (6 Mo maximum).' : /portail_introuvable/.test(em) ? 'Portail introuvable : republiez-le dans 🔗 Portails & signatures.' : 'Envoi impossible : ' + em); }
  };
}
w.EXB_PORTAILS = { version: 'V99zy', envoyerDocument: envoyerDocument, pull: pullRet, analyze: analyze, model: model, snapshot: snapshot, linkOf: linkOf };
})(window, document);
