/* Excellencia Building V175 — Import DWG (lecture via un convertisseur DWG → DXF FOURNI).
 * Un navigateur ne lit pas le DWG nativement. Ce module ne contient AUCUN décodeur DWG : il
 *   1. reconnaît la version du fichier (en-tête AC10xx) et refuse proprement ce qui n'est pas un DWG (fichier tronqué, renommé, DXF…) ;
 *   2. charge à la demande un convertisseur que VOUS fournissez : site/vendor/dwg/exb-dwg-converter.js, qui doit définir
 *        window.EXB_DWG_CONVERTER = { name:'…', convert:function(arrayBuffer){ retourne une Promise du texte DXF (string) } }
 *      (adaptateur mince autour d'une bibliothèque DWG→DXF, ex. LibreDWG compilé en WebAssembly : voir README-V175-DWG.md) ;
 *   3. contrôle le DXF produit (sections, entités, taille) avant de le passer au lecteur DXF des Plans (calques, mesures, annotations) ;
 *   4. journalise (sans contenu) : plans.dwg.converti / plans.dwg.echec.
 * Sans convertisseur : comportement inchangé (fichier archivé et versionné, message d'aide). Retrait : supprimer la balise <script src="exb-dwg.js">. */
(function (w, d) {
  'use strict';
  if (w.EXB_DWG) return;
  var SRC = 'vendor/dwg/exb-dwg-converter.js', TIMEOUT = 90000, MAXMB = 80;
  var VERS = { AC1006: 'R10', AC1009: 'R11/R12', AC1012: 'R13', AC1014: 'R14', AC1015: 'AutoCAD 2000', AC1018: 'AutoCAD 2004', AC1021: 'AutoCAD 2007', AC1024: 'AutoCAD 2010', AC1027: 'AutoCAD 2013', AC1032: 'AutoCAD 2018 et +' };
  var loading = null, loadErr = '', last = { err: '' };
  function audit(a, o, x) { try { w.EXBCore && w.EXBCore.audit.log(a, o, x); } catch (e) {} }
  function head(buf) {
    var u = new Uint8Array(buf.slice ? buf.slice(0, 6) : buf, 0, 6), s = ''; for (var i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
    return /^AC10\d\d$/.test(s) ? { code: s, label: VERS[s] || s, known: !!VERS[s] } : null;
  }
  function loadConverter() {
    if (w.EXB_DWG_CONVERTER && typeof w.EXB_DWG_CONVERTER.convert === 'function') return Promise.resolve(w.EXB_DWG_CONVERTER);
    if (loading) return loading;
    loading = new Promise(function (ok) {
      var s = d.createElement('script'); s.src = SRC; s.async = true;
      s.onload = function () { if (w.EXB_DWG_CONVERTER && typeof w.EXB_DWG_CONVERTER.convert === 'function') ok(w.EXB_DWG_CONVERTER); else { loadErr = 'Le fichier du convertisseur ne définit pas EXB_DWG_CONVERTER.convert.'; loading = null; ok(null); } };
      s.onerror = function () { loadErr = ''; loading = null; ok(null); };
      d.head.appendChild(s);
    });
    return loading;
  }
  function checkDxf(t) {
    if (typeof t !== 'string' || t.length < 200) return 'Le convertisseur n’a produit aucun DXF exploitable.';
    if (!/\bSECTION\b/.test(t) || !/\bENDSEC\b/.test(t)) return 'Le DXF produit est incomplet (sections absentes).';
    if (!/\bENTITIES\b/.test(t)) return 'Le DXF produit ne contient pas de section ENTITIES : le dessin est vide ou la conversion a échoué.';
    var n = (t.match(/^\s*0\r?\n\s*(LINE|LWPOLYLINE|POLYLINE|CIRCLE|ARC|TEXT|MTEXT|INSERT|ELLIPSE|SPLINE|DIMENSION|HATCH|SOLID|POINT)\s*$/gm) || []).length;
    if (!n) return 'Le DXF produit ne contient aucune entité reconnue (ligne, polyligne, cercle, texte…).';
    return '';
  }
  function withTimeout(p, ms) { return new Promise(function (ok, ko) { var t = setTimeout(function () { ko(new Error('Conversion trop longue (plus de ' + Math.round(ms / 1000) + ' s) : exportez le plan en DXF depuis AutoCAD.')); }, ms); p.then(function (v) { clearTimeout(t); ok(v); }, function (e) { clearTimeout(t); ko(e); }); });
  }
  /** blob (ou ArrayBuffer) DWG → texte DXF, ou null si aucun convertisseur n'est installé (le lecteur retombe sur l'aide). Rejette avec un message clair en cas d'échec. */
  function toDxf(blob) {
    last = { err: '' };
    var get = blob && blob.arrayBuffer ? blob.arrayBuffer() : Promise.resolve(blob);
    return get.then(function (buf) {
      if (!buf || !buf.byteLength) throw new Error('Fichier DWG vide.');
      if (buf.byteLength > MAXMB * 1048576) throw new Error('Fichier DWG trop volumineux (' + MAXMB + ' Mo maximum).');
      var h = head(buf);
      if (!h) throw new Error('Ce fichier n’est pas un DWG valide (en-tête AC10xx absent) : il est peut-être tronqué, renommé ou déjà au format DXF.');
      return loadConverter().then(function (cv) {
        if (!cv) { last.err = loadErr; return null; }
        return withTimeout(Promise.resolve().then(function () { return cv.convert(buf); }), TIMEOUT).then(function (txt) {
          var bad = checkDxf(txt); if (bad) throw new Error(bad);
          audit('plans.dwg.converti', 'plans', { version: h.code, octets: buf.byteLength, convertisseur: String(cv.name || 'inconnu').slice(0, 40) });
          return txt;
        });
      });
    }).catch(function (e) { last.err = e && e.message || String(e); audit('plans.dwg.echec', 'plans', { erreur: last.err.slice(0, 120) }); throw e; });
  }
  w.EXB_DWG = { toDxf: toDxf, head: head, check: checkDxf, available: function () { return loadConverter().then(function (c) { return !!c; }); }, lastError: function () { return last.err || loadErr; }, version: 'V175' };
})(window, document);
