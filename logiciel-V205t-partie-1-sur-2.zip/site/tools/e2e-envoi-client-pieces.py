import json, threading, http.server, functools, os, base64
from playwright.sync_api import sync_playwright
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a,**k): pass
H=functools.partial(Q,directory=D)
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8793),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=True
def chk(label,cond):
    global ok; ok=ok and bool(cond); print(('OK   ' if cond else 'FAIL ')+label)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':900}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}'))
    pg.route('http://x.test/**',lambda r:r.fulfill(status=200,content_type='application/json',body='{}'))
    pg.goto('http://127.0.0.1:8793/index.html'); pg.wait_for_timeout(2500)
    chk('API envoyerDocument exposée', pg.evaluate("()=>typeof (window.EXB_PORTAILS&&EXB_PORTAILS.envoyerDocument)")=='function')
    # --- contexte simulé : organisation, portail client publié, serveur en ligne
    pg.evaluate("""()=>{ localStorage.setItem('EXB_DB_META',JSON.stringify({org:'org-1'}));
      EXBS.set('exb_portails',[{id:'a1',kind:'client',token:'tok-A',titre:'Suivi — Villa',dest:'Ngelesi héritier',pid:'p1',tel:'0810644554',actif:true},{id:'a2',kind:'client',token:'tok-B',titre:'Suivi — Immeuble',dest:'M. Autre',pid:'p2',actif:true},{id:'a3',kind:'sous',token:'tok-S',titre:'ST',dest:'ST',pid:'p1',actif:true}]);
      window.__calls=[]; window.exbSb={isIn:()=>true,api:(path,o)=>{window.__calls.push({path:path,body:JSON.parse(o.body)});return Promise.resolve({ok:true,version:window.__ver||1})}};
      window.__pdf=new Blob([new Uint8Array([37,80,68,70,45,49,46,52,10,37,37,69,79,70])],{type:'application/pdf'}); }""")
    # --- 1) fenêtre d'envoi : seuls les portails CLIENT actifs, portail du projet présélectionné
    pg.evaluate("()=>EXB_PORTAILS.envoyerDocument(window.__pdf,{project:'p2',titre:'CCTP — Villa',numero:'CCT-001',genre:'contrat',filename:'CCT-001.pdf'})")
    pg.wait_for_selector('#pcBox')
    chk('2 portails client listés (sous-traitant exclu)', pg.evaluate("()=>document.querySelectorAll('#pcP option').length")==2)
    chk('portail du projet présélectionné', pg.input_value('#pcP')=='tok-B')
    chk('type présélectionné = contrat', pg.input_value('#pcG')=='contrat')
    chk('titre prérempli', pg.input_value('#pcT')=='CCTP — Villa')
    pg.select_option('#pcP','tok-A'); pg.fill('#pcO','à valider'); pg.click('#pcGo'); pg.wait_for_selector('#pcWa')
    c=[x for x in pg.evaluate("()=>window.__calls") if x['path'].endswith('client_doc_publier')]
    chk('1 appel client_doc_publier', len(c)==1)
    bd=c[0]['body'] if c else {}
    chk('paramètres corrects', bd.get('p_org')=='org-1' and bd.get('p_token')=='tok-A' and bd.get('p_genre')=='contrat' and bd.get('p_titre')=='CCTP — Villa' and bd.get('p_numero')=='CCT-001' and bd.get('p_note')=='à valider')
    chk('PDF envoyé en data-URL', str(bd.get('p_data','')).startswith('data:application/pdf;base64,') and base64.b64decode(bd['p_data'].split(',')[1]).startswith(b'%PDF'))
    chk('confirmation + prévenir WhatsApp/e-mail', 'envoyé' in pg.inner_text('#pcBox') and pg.locator('#pcMl').count()==1)
    pg.click('#pcOk'); chk('fenêtre fermée', pg.locator('#ptSendDoc').count()==0)
    # --- 2) nouvelle version (même titre) + erreurs
    pg.evaluate("()=>{window.__ver=2;EXB_PORTAILS.envoyerDocument(window.__pdf,{project:'p1',titre:'CCTP — Villa',filename:'x.pdf'})}"); pg.wait_for_selector('#pcBox'); pg.click('#pcGo'); pg.wait_for_selector('#pcWa')
    chk('version 2 annoncée', 'version 2' in pg.inner_text('#pcBox')); pg.click('#pcOk')
    pg.evaluate("()=>{EXB_PORTAILS.envoyerDocument(window.__pdf,{project:'p1',titre:'',filename:''})}"); pg.wait_for_selector('#pcBox'); pg.fill('#pcT',''); pg.click('#pcGo')
    chk('titre obligatoire', 'titre' in pg.inner_text('#pcE').lower()); pg.click('#pcNo')
    pg.evaluate("()=>{window.__big=new Blob([new Uint8Array(6*1048576+10)],{type:'application/pdf'});EXB_PORTAILS.envoyerDocument(window.__big,{titre:'Gros'})}"); pg.wait_for_selector('#pcBox'); pg.click('#pcGo')
    chk('fichier > 6 Mo refusé sans appel serveur', '6 Mo' in pg.inner_text('#pcE') and len([x for x in pg.evaluate("()=>window.__calls") if x['path'].endswith('client_doc_publier')])==2); pg.click('#pcNo')
    # --- 3) hors connexion / sans portail : message, pas de fenêtre
    pg.evaluate("()=>{window.exbSb.isIn=()=>false;EXB_PORTAILS.envoyerDocument(window.__pdf,{titre:'x'})}"); chk('hors connexion : pas de fenêtre', pg.locator('#ptSendDoc').count()==0)
    pg.evaluate("()=>{window.exbSb.isIn=()=>true;EXBS.set('exb_portails',[]);EXB_PORTAILS.envoyerDocument(window.__pdf,{titre:'x'})}"); chk('aucun portail : pas de fenêtre', pg.locator('#ptSendDoc').count()==0)
    # --- 4) bouton dans « PDF prêt » d'une vraie pièce écrite (PDF fabriqué localement)
    pg.evaluate("()=>{EXBS.set('exb_portails',[{id:'a1',kind:'client',token:'tok-A',titre:'Suivi — Villa',dest:'Ngelesi héritier',pid:'p1',actif:true}]);}")
    pg.evaluate("""()=>{ const pid='p1'; EXBS.set('exb_projects',[{id:pid,name:'Villa Test',client:'Ngelesi héritier'}]);
      EXBS.set('exb_pieces',[{id:'PIE-t1',type:'ccap',project:pid,no:'CCAP-001',date:'2026-11-12',status:'brouillon',title:'CCAP — Villa Test',dest:'',entreprise:'',lot:'',objet:'',effet:'',model:'',sign:'none',body:'# Objet\\nTexte du contrat.'}]); }""")
    pg.evaluate("()=>{EXBPIE.open();EXBPIE.edit('PIE-t1')}"); pg.wait_for_selector('#pBo',state='attached')
    pg.evaluate("()=>EXBPIE.print()"); pg.wait_for_selector('#exbPieOut',timeout=45000)
    chk('bouton « Envoyer à l’espace client » dans PDF prêt', pg.locator('#exbPieOut [data-k=e]').count()==1)
    pg.click('#exbPieOut [data-k=e]'); pg.wait_for_selector('#pcBox')
    chk('type par défaut du CCAP = contrat', pg.input_value('#pcG')=='contrat')
    chk('titre et numéro repris de la pièce', pg.input_value('#pcT')=='CCAP — Villa Test' and pg.input_value('#pcN')=='CCAP-001')
    chk('portail du projet présélectionné', pg.input_value('#pcP')=='tok-A')
    n0=len([x for x in pg.evaluate("()=>window.__calls") if x['path'].endswith('client_doc_publier')])
    pg.click('#pcGo'); pg.wait_for_selector('#pcWa')
    c=[x for x in pg.evaluate("()=>window.__calls") if x['path'].endswith('client_doc_publier')]
    chk('PDF réel de la pièce envoyé', len(c)==n0+1 and c[-1]['body']['p_data'].startswith('data:application/pdf;base64,') and base64.b64decode(c[-1]['body']['p_data'].split(',')[1])[:4]==b'%PDF')
    pg.screenshot(path='/tmp/envoi-client.png')
    chk('aucune erreur JS', not errs)
    if errs: print(errs)
    b.close()
print('RÉSULTAT', 'OK' if ok else 'ÉCHEC')
