#!/usr/bin/env python3
"""V186i : « Imprimer » = envoi direct à l'imprimante Windows pour tout le logiciel (via EXBPrint) ; « PDF » reste un PDF.
Usage, depuis le dossier du site : python3 tools/e2e-imprimer-partout.py"""
import http.server, threading, socketserver, os, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
DOC="<!doctype html><html><body><h1>Document de test</h1><p>"+("contenu "*30)+"</p></body></html>"
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':1100,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200])); a.on('dialog',lambda d:d.accept())
    exbui_auto(a)
    a.add_init_script("""window.__sent=[];window.exbDesktop={print:function(o){window.__sent.push('pdf');return Promise.resolve({ok:true})},printNative:function(o){window.__sent.push('imprimante');return Promise.resolve({ok:true})}};
      setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)""")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    a.evaluate("""(doc)=>{const mk=(id,label)=>{const b=document.createElement('button');b.id=id;b.textContent=label;b.style.cssText='position:fixed;left:0;top:0;z-index:2147483647';b.onclick=()=>EXBPrint.html('Test',doc,{});document.body.appendChild(b)};
      mk('t1','🖨 Imprimer');mk('t2','🖨 PDF');mk('t3','🖨 Imprimer / PDF');mk('t4','Imprimer le résultat');mk('t5','📄 Rapport PDF');mk('t6','🖨')}""",DOC)
    def run(i):
        a.evaluate("window.__sent.length=0"); a.evaluate("document.getElementById('%s').click()"%i); a.wait_for_timeout(700)
        return a.evaluate("window.__sent.slice()")
    for i,lab,exp in [('t1','🖨 Imprimer','imprimante'),('t2','🖨 PDF','pdf'),('t3','🖨 Imprimer / PDF','pdf'),('t4','Imprimer le résultat','imprimante'),('t5','Rapport PDF','pdf'),('t6','🖨 (icône seule)','imprimante')]:
        r=run(i); ok(r==[exp],f'« {lab} » → {exp} : {r}')
    # appel programmatique sans clic de bouton : reste un PDF
    a.evaluate("window.__sent.length=0"); a.evaluate("EXBPrint.html('Test',%r,{})"%DOC); a.wait_for_timeout(700)
    ok(a.evaluate("window.__sent.slice()")==['pdf'],'sans clic « Imprimer » : PDF (comportement habituel)')
    ok(not ae,'aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('\n%d échec(s)'%fails); raise SystemExit(1 if fails else 0)
