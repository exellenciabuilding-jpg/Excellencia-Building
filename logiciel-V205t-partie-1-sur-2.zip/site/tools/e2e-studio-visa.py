# Test navigateur V195 : signature + cachet dans le Studio libre (bouton + pose automatique sur les modèles à zone de signature).
# Lancer :  python3 tools/e2e-studio-visa.py   (Chromium + Playwright)
import http.server, threading, functools, os, sys
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8897), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
PNG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAAAyCAYAAACyf9ZxAAAAFUlEQVR42u3BAQ0AAADCoPdPbQ43oAAAAAAAAAAAAAAAAAAAAADwDwY4AAEyYlt1AAAAAElFTkSuQmCC"
S = "EXB_STUDIO.state()"
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    pg.goto('http://127.0.0.1:8897/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("show('affiches')"); pg.wait_for_timeout(600); pg.click('#exbsT2'); pg.wait_for_timeout(400)
    ok(pg.locator('#ad_v').count() == 1, 'bouton « Signature + cachet » présent dans le Studio libre')
    # 1) sans visa configuré : rien n'est ajouté, message clair
    pg.evaluate("window.EXBSign.anyVisa=function(){return Promise.resolve('')}")
    n0 = pg.evaluate(S + ".els.length"); pg.click('#ad_v'); pg.wait_for_timeout(500)
    ok(pg.evaluate(S + ".els.length") == n0, 'sans signature configurée : aucun élément ajouté')
    # 2) avec visa : élément image libre ajouté, sélectionné, déplaçable
    pg.evaluate("window.EXBSign.anyVisa=function(){return Promise.resolve(%r)}" % PNG)
    pg.click('#ad_v'); pg.wait_for_timeout(700)
    v = pg.evaluate(S + ".els.filter(e=>e.visa)")
    ok(len(v) == 1 and v[0]['t'] == 'img' and v[0]['src'].startswith('data:image/png') and v[0]['w'] > 0 and v[0]['h'] > 0, 'bouton : signature + cachet ajoutés comme image libre')
    pg.evaluate("(id)=>{const e=%s.els.find(x=>x.id===id);e.x=50;e.y=60}" % S, v[0]['id']); 
    ok(pg.evaluate("(id)=>{const e=%s.els.find(x=>x.id===id);return e.x===50&&e.y===60}" % S, v[0]['id']), 'l’élément est librement repositionnable')
    # 3) modèles avec zone « signature et cachet » : pose automatique au-dessus de la zone
    tpls = pg.evaluate("EXB_STUDIO.templates()")
    found = 0; placed = 0; bad = []
    for k in tpls:
        pg.evaluate("(k)=>EXB_STUDIO.applyTemplate(k)", k); pg.wait_for_timeout(120)
        an = pg.evaluate("(()=>{const a=%s.els.filter(e=>e.t==='text'&&/signature et cachet/i.test(e.tx||''));return a.map(e=>[e.x,e.y,e.w])})()" % S)
        if not an: continue
        found += 1; pg.wait_for_timeout(250)
        im = pg.evaluate("%s.els.filter(e=>e.visa).map(e=>[e.x,e.y,e.w,e.h])" % S)
        if len(im) == len(an): placed += 1
        else: bad.append(k)
    ok(found >= 2, 'modèles à zone de signature trouvés (%d)' % found)
    ok(placed == found, 'signature + cachet posés automatiquement sur ces %d modèles %s' % (found, bad[:5]))
    # 4) sans visa : modèles inchangés (pas d'image visa)
    pg.evaluate("window.EXBSign.anyVisa=function(){return Promise.resolve('')}")
    for k in tpls:
        pg.evaluate("(k)=>EXB_STUDIO.applyTemplate(k)", k); pg.wait_for_timeout(60)
        if pg.evaluate("%s.els.some(e=>e.t==='text'&&/signature et cachet/i.test(e.tx||''))" % S): break
    pg.wait_for_timeout(300)
    ok(pg.evaluate(S + ".els.filter(e=>e.visa).length") == 0, 'sans signature configurée : le modèle reste à signer à la main')
    ok(not errs, 'aucune erreur JavaScript ' + '; '.join(errs[:2]))
    b.close()
print('Résultat :', 'OK' if not fails else '%d échec(s)' % len(fails)); sys.exit(1 if fails else 0)
