/* Tests V177 : rapport PDF de marque (en-tête, QR, échappement) pour le CRM (node tools/test-rapport-marque-v177.js). */
const assert = require('assert'); let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const store = {}; global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.load = (k, df) => { try { const v = JSON.parse(store[k]); return v == null ? df : v; } catch (e) { return df; } };
global.save = (k, v) => { store[k] = JSON.stringify(v); return true; };
global.notify = () => {}; global.EXBCore = { audit: { log() {} }, modules: { register() {} } }; global.document = undefined;
global.EXBId = { get: () => ({ name: 'Excellencia Building', tagline: 'Excellence au cœur de vos constructions', phone: '+243 810 644 554', email: 'x@y.cd', address: 'Kinshasa, RDC', legal: 'RCCM test', logo: 'icon-192.png' }) };
require('../exb-qr.js'); require('../exb-rapport-marque.js'); require('../exb-crm-plus.js');
const D = new Date().toISOString().slice(0, 10);
store.exb_crm_opps = JSON.stringify([{ id: 'O1', title: '<img src=x onerror=alert(1)>', client: 'A & B', stage: 'devis', amount: 1500, currency: 'USD', expected: '2020-01-01', created: D }]);
const R = window.EXBCRMPLUS._t.rapportHtml(); const doc = window.EXBRapport.build('Rapport CRM', { html: R.html, meta: R.meta });
ok(doc.includes('Excellencia Building') && doc.includes('Excellence au cœur de vos constructions'), 'en-tête société + slogan');
ok(doc.includes('+243 810 644 554') && doc.includes('RCCM test'), 'contact + mentions légales');
ok(/<svg[^>]*>/.test(doc), 'QR code présent');
ok(!doc.includes('<img src=x'), 'nom piégé échappé'); ok(doc.includes('&lt;img src=x'), 'nom piégé affiché en texte');
ok(doc.includes('1 500,00 USD') || /1[\s  ]500,00 USD/.test(doc), 'montant formaté');
ok(/Empreinte|Contrôle : RAP-/.test(doc), 'référence de contrôle');
const d2 = window.EXBRapport.build('Rapport CRM', { html: R.html + 'x', meta: R.meta }); ok(doc !== d2, 'empreinte sensible au contenu');
/* QR de vérification public (comme les autres documents) : verification.html + inscription au registre */
global.navigator = { onLine: false }; global.location = { protocol: 'https:', href: 'https://excellenciabuilding.netlify.app/index.html', origin: 'https://excellenciabuilding.netlify.app' };
global.EXBVerif = null; try { require('../exb-verif.js'); } catch (e) { console.log('exb-verif non chargeable en node : ' + e.message); }
if (window.EXBVerif) {
  const pub = []; const orig = window.EXBVerif.publish; window.EXBVerif.publish = (r) => { pub.push(r); return Promise.resolve(false); };
  global.document = { createElement: () => ({ getContext: () => ({ fillRect() {}, set fillStyle(v) {} }), toDataURL: () => 'data:image/png;base64,AAAA', style: {} }), body: { appendChild() {} } };
  const vdoc = window.EXBRapport.build('Rapport CRM', { html: R.html, meta: R.meta });
  ok(vdoc.includes('verification.html'), 'adresse verification.html affichée sous le QR');
  ok(/RAP-\d{8}-[0-9A-F]{5}/.test(vdoc), 'numéro de registre RAP-…');
  window.EXBPrint = { html: () => {} }; window.EXBRapport.print('Rapport CRM', { html: R.html, meta: R.meta });
  ok(pub.length === 1 && pub[0].kind === 'document' && /^RAP-/.test(pub[0].no) && pub[0].hash, 'inscrit au registre (kind document)');
  const num = (vdoc.match(/RAP-\d{8}-[0-9A-F]{5}/) || [])[0]; ok(num === pub[0].no, 'numéro imprimé = numéro du registre');
  const u = window.EXBVerif.docRec({ title: 'Rapport CRM', sub: '', digest: window.EXBVerif.sha256(R.html), nom: 'Excellencia Building', prefix: 'RAP', date: D, detail: '' }).code.url; ok(/verification\.html\?c=g~RAP-/.test(u), 'lien public verification.html?c=g~…');
}
/* stock : rapport PDF de marque */
store.exb_stock = JSON.stringify([{ id: 'S1', name: '<b>Ciment</b>', qty: 120, unit: 'sac' }]);
require('../exb-stock-plus.js'); const SR = window.EXBSTOCKPLUS._t.rapportHtml();
ok(SR.html.includes('Soldes par dépôt') && SR.html.includes('&lt;b&gt;Ciment'), 'stock : soldes par dépôt, nom piégé échappé');
ok(SR.html.includes('commandé → reçu → facturé → payé') && SR.meta.length === 3, 'stock : chaîne BC et informations complémentaires');
console.log('test-rapport-marque-v177 : ' + n + ' contrôles OK');
process.exit(0);
