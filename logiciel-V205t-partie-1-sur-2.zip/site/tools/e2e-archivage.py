# Test navigateur V141u : 🗄 espace serveur (archiver en ZIP, libérer, restaurer) — plans, devis ET notes de calcul / plans d'exécution (table calcul_publics).
import json, os, re, zipfile, io, tempfile, threading, http.server, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8797),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ORG='11111111-2222-3333-4444-555555555555'; T1='a'*32; T2='b'*32; T3='c'*32; T4='d'*32
res=[]
def check(nom,cond,info=''): res.append(bool(cond)); print(('OK   ' if cond else 'ÉCHEC'),nom,info)
FILES={f'{ORG}/{T4}/note-de-calcul.pdf':b'%PDF-1.4 note '+os.urandom(1800),f'{ORG}/{T1}/plan-A.pdf':b'%PDF-1.4 plan A '+os.urandom(3000),f'{ORG}/{T1}/plan-A.dwg':os.urandom(2500),f'{ORG}/{T2}/devis.pdf':b'%PDF-1.4 devis '+os.urandom(2000),f'{ORG}/{T3}/devis.pdf':b'%PDF-1.4 recent '+os.urandom(500)}
OLD='2026-08-01T10:00:00Z'; NEW='2026-11-08T10:00:00Z'
ITEMS=[
 {'table':'plans','ref':'EXB-2026-001','code':'AAAAAAAAAA','genre':'plan','titre':'Villa Limete','sous_titre':'P-01','actif':True,'maj_le':OLD,'archive':False,'token':T1,'docs':[{'nom':'Plan A (PDF)','fichier':f'{ORG}/{T1}/plan-A.pdf','format':'PDF','taille':'3 Ko','kind':'plan'},{'nom':'Plan A (DWG)','fichier':f'{ORG}/{T1}/plan-A.dwg','format':'DWG','taille':'3 Ko','kind':'plan'}]},
 {'table':'devis','ref':'EXD-2026-001','code':'BBBBBBBBBB','genre':'devis','titre':'Villa Limete','sous_titre':'DEV-2026-001 · Jean','actif':True,'maj_le':OLD,'archive':False,'token':T2,'docs':[{'nom':'Devis N° DEV-2026-001','fichier':f'{ORG}/{T2}/devis.pdf','format':'PDF','taille':'2 Ko','kind':'devis'}]},
 {'table':'calcul','ref':'EXN-2026-001','code':'DDDDDDDDDD','genre':'note','titre':'Villa Limete','sous_titre':'NCS-2026-001 · M. Kabila','actif':True,'maj_le':OLD,'archive':False,'token':T4,'docs':[{'nom':'Note de calcul N° NCS-2026-001','fichier':f'{ORG}/{T4}/note-de-calcul.pdf','format':'PDF','taille':'2 Ko','kind':'note'}]},
 {'table':'devis','ref':'EXD-2026-002','code':'CCCCCCCCCC','genre':'devis','titre':'Récent','sous_titre':'DEV-2026-002','actif':True,'maj_le':NEW,'archive':False,'token':T3,'docs':[{'nom':'Devis N° DEV-2026-002','fichier':f'{ORG}/{T3}/devis.pdf','format':'PDF','taille':'0 Ko','kind':'devis'}]}]
FICHES={'EXB-2026-001':{'ref':'EXB-2026-001','code':'AAAAAAAAAA','plan_id':'P1','ref_plan':'P-01','titre':'Villa Limete','type_doc':'Plan R+1','maitre_oeuvre':'Excellencia','maitre_ouvrage':'M. Kabila','concepteur':'Ing. Z','echelle':'1/100','indice':'B','apercu':'data:image/png;base64,AAAA','docs':ITEMS[0]['docs']},
 'EXD-2026-001':{'ref':'EXD-2026-001','genre':'devis','devis_no':'DEV-2026-001','projet':'Villa Limete','client':'Jean','prestataire':'Excellencia','montant':'3 504,00 USD','validite':'30 jours','date_devis':'2026-08-01','statut':'envoyé','empreinte':'h','apercu':'data:image/png;base64,BBBB','docs':ITEMS[1]['docs']},
 'EXN-2026-001':{'ref':'EXN-2026-001','genre':'note','doc_no':'NCS-2026-001','titre':'Villa Limete','projet':'Villa Limete','client':'M. Kabila','etabli_par':'Bureau Z','indice':'A','norme':'Eurocode 2','statut':'Validé','date_doc':'2026-08-01','empreinte':'hn','apercu':'data:image/png;base64,CCCC','docs':ITEMS[2]['docs']},
 'EXD-2026-002':{'ref':'EXD-2026-002','genre':'devis','devis_no':'DEV-2026-002','docs':ITEMS[3]['docs']}}
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(accept_downloads=True,viewport={'width':1000,'height':1100}); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('dialog',lambda d:d.accept())
    exbui_auto(pg)
    pg.route('http://x.test/storage/v1/object/public/**',lambda r:r.fulfill(status=200,headers={'Access-Control-Allow-Origin':'*'},body=FILES[__import__('urllib.parse').parse.unquote(r.request.url.split('/object/public/')[1].split('/',1)[1])]))
    pg.goto('http://127.0.0.1:8797/index.html'); pg.wait_for_timeout(2500); pg.add_style_tag(content='#exbLicLock{display:none!important}')
    pg.evaluate("""(a)=>{window.__calls=[];window.__opened=[];
      window.EXBDB.org=()=>a.org;window.EXBDB.can=()=>true;window.exbSb.isIn=()=>true;window.exbSb.cfg=()=>({url:'http://x.test'});window.confirm=()=>true;
      window.open=(u)=>{window.__opened.push(String(u));return null};window.__n=0;window.__arch=[];
      window.exbSb.api=async(path,opt)=>{opt=opt||{};let body=opt.body;if(body instanceof Blob)body={blob:body.size,type:body.type};else if(typeof body==='string'){try{body=JSON.parse(body)}catch(e){}}
        window.__calls.push({path,method:opt.method||'GET',body});
        if(/rpc\\/devis_public_publier/.test(path)){window.__n++;const g=(body&&body.p_genre)||'devis';return{ok:true,ref:(g==='note_calcul'?'EXN':g==='plan_execution'?'EXE':'EXD')+'-2026-00'+window.__n,code:'A1B2C3D4E5'}}
        if(/rpc\\/calcul_public_publier/.test(path))return{ok:true,ref:'EXN-2026-001',code:'DDDDDDDDDD',ancien_token:null};
        if(/rpc\\/plan_public_publier/.test(path))return{ok:true,ref:body.p_ref,code:'AAAAAAAAAA',ancien_token:null};
        if(/rpc\\/espace_stats/.test(path))return{ok:true,db_bytes:420*1048576,storage_bytes:930*1048576,buckets:[],apercus_bytes:5242880,n_publies:4,n_archives:0};
        if(/rpc\\/docs_publics_pour_archivage/.test(path))return a.items;
        if(/rpc\\/docs_public_fiche/.test(path))return a.fiches[body.p_ref];
        if(/rpc\\/docs_public_archiver/.test(path)){window.__arch.push(body.p_ref);const it=a.items.find(x=>x.ref===body.p_ref);return{ok:true,token:it.token}}
        if(/object\\/list\\//.test(path))return[{name:'devis.pdf'}];
        return{}}}""",{'org':ORG,'items':ITEMS,'fiches':FICHES})

    # ---- B) espace serveur : archiver
    pg.evaluate("window.__calls.length=0;window.EXBESPACE.open()"); pg.wait_for_selector('#esList .esCk',timeout=8000)
    t=pg.inner_text('#exbEspace')
    check('jauges : base 420/500 Mo (84 %) et fichiers 930 Mo',('420,0 Mo' in t) and ('84 %' in t) and ('930,0 Mo' in t))
    check('explication : la jauge base ne baisse pas tout de suite','ne baisse pas immédiatement' in t)
    check('4 publications listées (plan, devis, note de calcul, devis récent)',pg.locator('#esList .esCk').count()==4)
    check('type « Note de calcul » proposé dans le filtre',pg.locator('#esType option[value=note]').count()==1 and pg.locator('#esType option[value=pex]').count()==1)
    pg.fill('#esDays','30'); pg.click('#esSel')
    ck=pg.evaluate("[...document.querySelectorAll('.esCk')].map(k=>k.checked)")
    check('filtre « plus de 30 jours » : les 3 anciennes cochées, la récente non',ck==[True,True,True,False],str(ck))
    pg.evaluate("window.__calls.length=0"); pg.click('#esZip'); pg.wait_for_selector('.esDl',timeout=30000)
    check('ZIP prêt, vérifié','relu' in pg.inner_text('#esStep2') and 'vérifié' in pg.inner_text('#esStep2'))
    nm=[x['path'] for x in pg.evaluate('window.__calls')]
    check('avant confirmation : AUCUNE suppression ni archivage',not any(('archiver' in n) or ('DELETE'==x['method']) for n,x in zip(nm,pg.evaluate('window.__calls'))))
    check('boutons « libérer » bloqués tant que le ZIP n\'est pas enregistré',pg.is_disabled('#esFree') and pg.is_disabled('#esOk'))
    with pg.expect_download() as dl: pg.click('.esDl')
    path=os.path.join(tempfile.gettempdir(),'exb-test-archive.zip'); dl.value.save_as(path)
    z=zipfile.ZipFile(path); names=z.namelist()
    check('ZIP : manifest + fiches + fichiers de chaque publication',all(n in names for n in ['manifest.json','EXB-2026-001/fiche.json','EXB-2026-001/plan-A.pdf','EXB-2026-001/plan-A.dwg','EXD-2026-001/fiche.json','EXD-2026-001/devis.pdf','EXN-2026-001/fiche.json','EXN-2026-001/note-de-calcul.pdf']) and not any(n.startswith('EXD-2026-002') for n in names),str(names))
    check('ZIP : contenu identique octet pour octet',z.read('EXB-2026-001/plan-A.pdf')==FILES[f'{ORG}/{T1}/plan-A.pdf'] and z.read('EXB-2026-001/plan-A.dwg')==FILES[f'{ORG}/{T1}/plan-A.dwg'] and z.read('EXD-2026-001/devis.pdf')==FILES[f'{ORG}/{T2}/devis.pdf'] and z.read('EXN-2026-001/note-de-calcul.pdf')==FILES[f'{ORG}/{T4}/note-de-calcul.pdf'])
    man=json.loads(z.read('manifest.json')); check('manifest : entreprise + 3 publications',man['org']==ORG and [i['ref'] for i in man['items']]==['EXB-2026-001','EXD-2026-001','EXN-2026-001'])
    check('fiche conserve l\'aperçu (restauration complète)',json.loads(z.read('EXB-2026-001/fiche.json'))['apercu']=='data:image/png;base64,AAAA')
    check('après téléchargement : case de confirmation activable',not pg.is_disabled('#esOk') and pg.is_disabled('#esFree'))
    pg.check('#esOk'); check('puis bouton libérer actif',not pg.is_disabled('#esFree'))
    pg.evaluate("window.__calls.length=0"); pg.click('#esFree'); pg.wait_for_selector('#esAgain',timeout=15000)
    calls=pg.evaluate('window.__calls')
    check('archivage serveur : exactement les 3 références cochées',pg.evaluate('window.__arch')==['EXB-2026-001','EXD-2026-001','EXN-2026-001'])
    dels=[c for c in calls if c['method']=='DELETE']
    check('suppression des fichiers dans le bon espace public (plans / devis / calcul)',len(dels)==3 and any('/object/exb-plans-publics' in c['path'] and c['body']['prefixes']==[f'{ORG}/{T1}/devis.pdf'] for c in dels) and any('/object/exb-devis-publics' in c['path'] for c in dels) and any('/object/exb-calcul-publics' in c['path'] for c in dels),str([(c['path'][-30:],c['body']) for c in dels]))
    check('la récente n\'est pas touchée',not any(T3 in json.dumps(c) for c in calls))
    check('message de réussite','3 publications archivées' in pg.inner_text('#esFreeRes'))

    # ---- C) restaurer depuis le ZIP
    pg.evaluate("window.__calls.length=0"); pg.click('#esAgain'); pg.wait_for_selector('#esFile',timeout=8000)
    pg.set_input_files('#esFile',path); pg.wait_for_selector('#esAgain2',timeout=20000)
    calls=pg.evaluate('window.__calls'); ups=[c for c in calls if c['method']=='POST' and '/storage/v1/object/exb-' in c['path'] and 'list' not in c['path']]
    check('restauration : 4 fichiers renvoyés (2 plans, 1 devis, 1 note) dans de nouveaux dossiers',len(ups)==4 and all(re.search(ORG+r'/[a-f0-9]{32}/',c['path']) for c in ups) and not any(T1 in c['path'] or T2 in c['path'] or T4 in c['path'] for c in ups),str([c['path'][-40:] for c in ups]))
    rd=[c['body'] for c in calls if 'devis_public_publier' in c['path']][0]; rp=[c['body'] for c in calls if 'plan_public_publier' in c['path']][0]
    check('devis restauré : même numéro, genre, montant, aperçu',rd['p_no']=='DEV-2026-001' and 'p_genre' not in rd and rd['p_montant']=='3 504,00 USD' and rd['p_apercu']=='data:image/png;base64,BBBB' and rd['p_docs'][0]['kind']=='devis')
    check('plan restauré avec p_ref : même référence et code',rp['p_ref']=='EXB-2026-001' and rp['p_titre']=='Villa Limete' and rp['p_indice']=='B' and len(rp['p_docs'])==2)
    rc=[c['body'] for c in calls if 'calcul_public_publier' in c['path']][0]
    check('note de calcul restaurée : genre, numéro, indice, norme, statut, aperçu',rc['p_genre']=='note' and rc['p_no']=='NCS-2026-001' and rc['p_indice']=='A' and rc['p_norme']=='Eurocode 2' and rc['p_statut']=='Validé' and rc['p_etabli']=='Bureau Z' and rc['p_date']=='2026-08-01' and rc['p_apercu']=='data:image/png;base64,CCCC' and rc['p_docs'][0]['kind']=='note' and re.search(ORG+r'/[a-f0-9]{32}/note-de-calcul.pdf',rc['p_docs'][0]['fichier']))
    check('message de réussite restauration','3 publications restaurées' in pg.inner_text('#esRes'))
    # ZIP d'une autre entreprise refusé
    bad=io.BytesIO()
    with zipfile.ZipFile(bad,'w') as zz: zz.writestr('manifest.json',json.dumps({'org':'00000000-0000-0000-0000-000000000000','items':[]}))
    open(os.path.join(tempfile.gettempdir(),'exb-bad.zip'),'wb').write(bad.getvalue())
    pg.set_input_files('#esFile',os.path.join(tempfile.gettempdir(),'exb-bad.zip')); pg.wait_for_function("document.getElementById('esRes').textContent.includes('autre entreprise')",timeout=8000)
    check('ZIP d\'une autre entreprise : refusé',True)
    # administrateur seulement
    pg.evaluate("""()=>{const o=window.exbSb.api;window.exbSb.api=async(p,x)=>/espace_stats/.test(p)?{ok:false,erreur:'Réservé à l’administrateur.'}:o(p,x)}""")
    pg.evaluate("window.EXBESPACE.open()"); pg.wait_for_function("document.getElementById('exbEspace').textContent.includes('Réservé')",timeout=8000)
    check('non-administrateur : message clair, rien d\'archivable',pg.locator('#esZip').count()==0)
    check('pas d\'erreur JS',not errs,str(errs[:2])); b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
