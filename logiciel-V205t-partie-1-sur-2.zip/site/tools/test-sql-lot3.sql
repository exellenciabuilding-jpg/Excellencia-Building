\set ON_ERROR_STOP 0
\pset tuples_only on
create temp table r(t text, ok boolean);
-- jeu d'essai : 1 admin, 1 ingénieur habilité (bureau_etudes), 1 ingénieur NON habilité, 1 comptable ; une organisation
insert into auth.users values ('00000000-0000-0000-0000-00000000000a','admin@t'),('00000000-0000-0000-0000-00000000000b','ing@t'),('00000000-0000-0000-0000-00000000000c','ing2@t'),('00000000-0000-0000-0000-00000000000d','cpt@t');
insert into organisations(id,nom) values ('11111111-1111-1111-1111-111111111111','Org test');
insert into membres(org_id,user_id,nom,role,fonction) values
 ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000a','Admin','admin','polyvalent'),
 ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000b','Ing Habilité','editeur','bureau_etudes'),
 ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000c','Ing Non','editeur','bureau_etudes'),
 ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000d','Compta','editeur','comptable');
insert into ingenieurs_habilites(org_id,user_id,nom,ordre) values ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000b','Ing Habilité','ONI-123');
\set org '''11111111-1111-1111-1111-111111111111'''
-- T05 : non habilité tente de valider
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000c'; set request.jwt.claims='{"aal":"aal2"}';
select (calcul_valider(:org,'P1','Poutre','NC-001','A','digest-aaaa','valide','ok',true)::jsonb->>'refus') as v \gset
reset role; insert into r select 'T05 : un ingénieur non habilité ne peut pas valider ('||:'v'||')', :'v'='ingenieur_habilite_requis';
insert into r select 'T05 : aucune validation enregistrée', (select count(*) from validations_calcul)=0;
insert into r select 'T05 : la tentative refusée est journalisée avec son auteur', exists(select 1 from journal_entreprise where action='calcul refusé : ingenieur_habilite_requis' and user_id='00000000-0000-0000-0000-00000000000c' and rec_id='NC-001');
-- l'ingénieur habilité valide (2FA), sans déclaration -> refus journalisé aussi
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000b'; set request.jwt.claims='{"aal":"aal2"}';
select (calcul_valider(:org,'P1','Poutre','NC-001','A','digest-aaaa','valide','ok',false)::jsonb->>'refus') as v2 \gset
select (calcul_valider(:org,'P1','Poutre','NC-001','A','digest-aaaa','valide','ok',true)::jsonb->>'ok') as v3 \gset
reset role;
insert into r select 'sans déclaration : refus « declaration_requise »', :'v2'='declaration_requise';
insert into r select 'T05 : l''ingénieur habilité valide avec déclaration', :'v3'='true';
insert into r select 'la validation porte le nom et le n° d''ordre issus de la fiche habilitée', exists(select 1 from validations_calcul where ing_nom='Ing Habilité' and ing_ordre='ONI-123' and statut='valide');
-- T06 : couverture
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000d'; set request.jwt.claims='{"aal":"aal1"}';
select calcul_couverture(:org,'NC-001','digest-aaaa')::jsonb->>'couvert' as c1 \gset
select calcul_couverture(:org,'NC-001','digest-bbbb')::jsonb->>'etat' as c2 \gset
select calcul_couverture(:org,'NC-001','digest-bbbb')::jsonb->>'couvert' as c3 \gset
select calcul_couverture(:org,'NC-XXX','digest-aaaa')::jsonb->>'etat' as c4 \gset
reset role;
insert into r select 'T06 : la version validée est couverte', :'c1'='true';
insert into r select 'T06 : après modification (autre empreinte), la validation ne couvre plus la nouvelle version', :'c2'='obsolete' and :'c3'='false';
insert into r select 'T06 : un calcul jamais validé n''est pas couvert', :'c4'='jamais_valide';
-- T06 bis : refus d'un non-membre
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000ff'; set request.jwt.claims='{}';
select calcul_couverture(:org,'NC-001','digest-aaaa')::jsonb->>'refus' as c5 \gset
reset role;
insert into r select 'un non-membre n''obtient aucune information', :'c5'='non_membre';
-- journal des validations en ajout seul (même pour un utilisateur métier, T10)
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000b';
do $$ begin begin update validations_calcul set statut='refuse'; exception when others then perform set_config('t.e1','x',false); end; end $$;
do $$ begin begin delete from journal_entreprise; exception when others then perform set_config('t.e2','x',false); end; end $$;
select count(*) as nj from journal_entreprise \gset
insert into validations_calcul(org_id,type_calcul,no,digest,statut,user_id) select :org,'x','n','123456','valide','00000000-0000-0000-0000-00000000000b' where false;
reset role;
insert into r select 'T10 : un utilisateur métier ne peut ni modifier une validation ni lire/effacer le journal d''entreprise', (select statut from validations_calcul limit 1)='valide' and :'nj'='0' and (select count(*) from journal_entreprise)>0;
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000b';
do $$ begin begin insert into journal_entreprise(org_id,user_id,collection,action) values (gen_random_uuid(),auth.uid(),'x','faux'); perform set_config('t.e3','insere',false); exception when others then perform set_config('t.e3','refuse',false); end; end $$;
select current_setting('t.e3') as e3 \gset
reset role;
insert into r select 'T10 : l''insertion directe dans le journal est refusée', :'e3'='refuse';
-- affectations
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000b';
do $$ begin begin perform affecter_projet('11111111-1111-1111-1111-111111111111','P1','00000000-0000-0000-0000-00000000000b'); perform set_config('t.a1','ok',false); exception when others then perform set_config('t.a1','refuse',false); end; end $$;
select current_setting('t.a1') as a1 \gset
set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000a';
select (affecter_projet(:org,'P1','00000000-0000-0000-0000-00000000000b')::jsonb->>'ok') as a2 \gset
select (affecter_projet(:org,'P2','00000000-0000-0000-0000-00000000000b')::jsonb->>'ok') as a3 \gset
select (affecter_projet(:org,'P2','00000000-0000-0000-0000-00000000000b',false)::jsonb->>'ok') as a4 \gset
select (mes_projets(:org)::jsonb->>'tous') as a5 \gset
set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000b';
select (mes_projets(:org)::jsonb) as a6 \gset
select count(*) filter (where user_id<>'00000000-0000-0000-0000-00000000000b') as a7 from affectations_projets \gset
reset role;
insert into r select 'seul l''administrateur peut affecter un projet', :'a1'='refuse' and :'a2'='true';
insert into r select 'l''administrateur voit tous les projets', :'a5'='true';
insert into r select 'l''ingénieur ne voit que ses projets actifs affectés', :'a6'::jsonb->'projets'='["P1"]'::jsonb and :'a6'::jsonb->>'tous'='false';
insert into r select 'l''ingénieur ne lit que ses propres affectations (RLS)', :'a7'='0';
insert into r select 'les affectations sont journalisées', (select count(*) from journal_entreprise where collection='affectations_projets')=3;
\echo ----- RÉSULTAT -----
select case when ok then 'OK   ' else 'FAIL ' end || t from r;
select 'Résultat : '||count(*) filter (where ok)||' OK, '||count(*) filter (where not ok)||' échec(s)' from r;
