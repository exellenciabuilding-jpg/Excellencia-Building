# Test navigateur : applique chacun des modèles ajoutés (V156 à V158) et détecte erreurs JS / débordements
import http.server, threading, functools, json, os
from playwright.sync_api import sync_playwright
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8872),H); threading.Thread(target=srv.serve_forever,daemon=True).start()

with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1300,'height':1000}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto('http://127.0.0.1:8872/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("show('affiches')"); pg.wait_for_timeout(800)
    # ouvrir l'onglet studio
    print(pg.evaluate("[...document.querySelectorAll('.exbs-tabs button,.exbs-tab')].map(b=>b.textContent.trim())"))
    ks=pg.evaluate("EXB_STUDIO.templates()"); new=ks[46:]
    print('total',len(ks),'nouveaux',len(new))
    res=[]
    for k in new:
        r=pg.evaluate("""(k)=>{EXB_STUDIO.applyTemplate(k);const st=EXB_STUDIO.state();const F={a4p:[794,1123],a4l:[1123,794],a3p:[1123,1587],sq:[1080,1080],story:[1080,1920],ban:[1200,628],a5p:[559,794],card:[1063,591],roll:[850,2000],ytb:[1280,720],ig:[1080,1350],badge:[638,1013],tw:[1500,500],pin:[1000,1500]}[st.fmt];
          const stage=document.getElementById('exbsStage');let over=0,bot=0,n=st.els.length;
          st.els.forEach(e=>{if(e.x<-2||e.y<-2||e.x+e.w>F[0]+2) over++;});
          const hs=[...stage.querySelectorAll('[data-id]')];
          return {fmt:st.fmt,n:n,over:over,stageH:stage.offsetHeight,F:F}}""",k)
        res.append((k,r))
    bad=[(k,r) for k,r in res if r['over'] or r['n']<3]
    print('erreurs JS',errs[:3]); print('hors cadre / vides',bad)
    json.dump(res,open(os.path.join(os.environ.get('TMPDIR','/tmp'),'res.json'),'w'))
    b.close()
