#!/usr/bin/env python3
"""V204 — Portails & signatures › « Demandes clients » : cartes de demandes, état fiche client / chantier / espace,
boutons de création, paiements, devis annexé, interconnexion Clients & CRM. (Serveur simulé : aucun appel Supabase réel.)
Usage, depuis le dossier du site :  python3 tools/e2e-demandes-clients.py"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':1100,'height':900}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:160])); exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    a.evaluate("""()=>{window.__made=[];
      window.EXB_INBOX={on:()=>true,reload:async()=>{},rows:()=>[{t:'btp',id:'r1',m:'BTP-2026-0015',s:'nouvelle',created_at:'2026-11-17T10:00:00Z',d:{name:'Jean Kabila',phone:'+243810000001',category:'Construction maison',location:'Lemba',budget:'50000'}},{t:'btp',id:'r2',m:'BTP-2026-0016',s:'nouvelle',created_at:'2026-11-17T11:00:00Z',d:{name:'Marie Tshala',phone:'+243810000002',category:'Plans'}}],importBtp:async ids=>{window.__made.push(ids)}};
      localStorage.setItem('exb_projects',JSON.stringify([]));}""")
    a.evaluate("show('portails')"); a.wait_for_timeout(1200)
    labels=a.evaluate("[...document.querySelectorAll('#portails .pt-tabs button')].map(b=>b.textContent.trim())")
    ok(any('Demandes clients' in l for l in labels),'Portails & signatures : onglet « Demandes clients » '+str(labels))
    a.click('#portails [data-act=tab][data-id=dem]'); a.wait_for_timeout(800)
    txt=a.evaluate("document.getElementById('portails').innerText")
    ok('Jean Kabila' in txt and 'Marie Tshala' in txt,'les deux demandes reçues sont listées')
    ok('Chantier à créer' in txt and 'Fiche client à créer' in txt,'état : fiche client et chantier à créer')
    ok(a.evaluate("document.querySelectorAll('#portails [data-act=demMake]').length")==2,'bouton « Créer fiche client + chantier » sur chaque demande')
    ok(a.evaluate("document.querySelectorAll('#portails [data-act=demGo][data-id=clients]').length")==2,'interconnexion : bouton Clients & CRM')
    a.click('#portails [data-act=demMake][data-id=r1]'); a.wait_for_timeout(500)
    ok(a.evaluate("JSON.stringify(window.__made)")=='[["r1"]]','le bouton lance la création de la fiche client et du chantier')
    a.click('#portails [data-act=demGo][data-id=clients]'); a.wait_for_timeout(500)
    ok(a.evaluate("getComputedStyle(document.getElementById('clients')).display")!='none','« Clients & CRM » s’ouvre')
    ok(not ae,'aucune erreur JavaScript '+str(ae))
    b.close()
print('Résultat :', 'OK' if not fails else f'{fails} échec(s)'); sys.exit(1 if fails else 0)
