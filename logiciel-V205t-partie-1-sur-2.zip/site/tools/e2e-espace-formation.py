# V205 lot 5b — Espace Formation : toute la catégorie Formation SAUF le reçu de paiement (comptable)
import http.server, threading, functools, os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    boot('espace-formation.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'formation', 'le lien /espace-formation ouvre l\'Espace Formation')
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(600)
    mt = ' | '.join(pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)"))
    for k in ['Formations', 'Planning', 'Certificats', 'Évaluations']:
        t(k in mt, 'le menu contient « %s »' % k)
    t('Reçus de paiement' not in mt and 'Reçus' not in mt, 'le menu ne contient PAS les reçus de paiement')
    t(not any(x in mt for x in ['Finances', 'Comptabilité', 'Stock', 'Projets', 'Paie']), 'ni finances, ni stock, ni projets, ni paie')
    # un reçu ne s'ouvre pas, même par appel direct (recherche, bouton apprenant)
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(400)
    t(pg.evaluate("document.getElementById('receipts').style.display") == 'none', 'show(\'receipts\') est refusé dans l\'Espace Formation')
    t('comptable' in pg.evaluate("document.body.innerText").lower(), 'le message renvoie vers le comptable')
    t('reçu' not in pg.evaluate("document.getElementById('xhK').innerText").lower() and 'attente' not in pg.evaluate("document.getElementById('xhK').innerText").lower(), 'le tableau de bord n\'affiche aucun paiement/reçu')
    # accès par fonction
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'un comptable est refusé dans l\'Espace Formation')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'formateur',label:'Formateur'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'un formateur est accepté')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'admin',fonction:'polyvalent',label:'Administrateur'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'l\'administrateur est accepté')
    # le comptable, lui, garde les reçus
    pg.evaluate("localStorage.setItem('exb_espace','comptable')"); boot('index.html'); 
    mt2 = ' | '.join(pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)"))
    t('Reçus de paiement' in mt2, 'l\'Espace Comptable contient toujours « Reçus de paiement »')
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(400)
    t(pg.evaluate("document.getElementById('receipts').style.display") != 'none', 'le comptable peut ouvrir les reçus')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
