# Test navigateur V141o : portail public plan.html avec une référence de DEVIS (EXD-…), serveur simulé.
import json, os, threading, http.server, functools
from playwright.sync_api import sync_playwright
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8796),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
ORG='11111111-2222-3333-4444-555555555555'; TOK='a'*32
DEVIS={'genre':'devis','ref':'EXD-2026-001','titre':'Villa R+1 Limete','date':'2026-11-09','devis_no':'DEV-2026-001','client':'Jean Mukendi','prestataire':'Excellencia Building','montant':'3 504,00 USD','validite':'Valable jusqu’au 09/12/2026','apercu':PNG,
 'docs':[{'nom':'Devis N° DEV-2026-001 — Jean Mukendi','fichier':f'{ORG}/{TOK}/devis.pdf','format':'PDF','taille':'70 Ko','kind':'devis'},{'nom':'Piégé','fichier':'../../etc/passwd','format':'PDF','taille':'','kind':'devis'}]}
rpcs=[]; dl_urls=[]
def rpc_d(route):
    body=json.loads(route.request.post_data or '{}'); rpcs.append(('devis',body))
    ok=body.get('p_ref')=='EXD-2026-001' and body.get('p_code')=='A1B2C3D4E5'
    route.fulfill(status=200,content_type='application/json',body=json.dumps(DEVIS if ok else None))
def rpc_p(route): rpcs.append(('plan',json.loads(route.request.post_data or '{}'))); route.fulfill(status=200,content_type='application/json',body='null')
def pdf(route): dl_urls.append(route.request.url); route.fulfill(status=200,headers={'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="devis.pdf"','Access-Control-Allow-Origin':'*'},body=b'%PDF-1.4\n%%EOF')
res=[]
def check(nom,cond,info=''): res.append(bool(cond)); print(('OK   ' if cond else 'ÉCHEC'),nom,info)
def newpage(b,w=1200):
    pg=b.new_page(viewport={'width':w,'height':900},accept_downloads=True); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"sb_publishable_test"}'))
    pg.route('http://x.test/rest/v1/rpc/devis_public_get',rpc_d); pg.route('http://x.test/rest/v1/rpc/plan_public_get',rpc_p); pg.route('http://x.test/storage/**',pdf)
    return pg,errs
T=lambda pg,i:pg.inner_text(i)
with sync_playwright() as p:
    b=p.chromium.launch()
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8796/plan.html?ref=EXD-2026-001&k=A1B2C-3D4E5'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('QR de devis : bonne fonction serveur appelée (pas celle des plans)',rpcs and rpcs[-1][0]=='devis' and rpcs[-1][1]=={'p_ref':'EXD-2026-001','p_code':'A1B2C3D4E5'},str(rpcs[-1:]))
    check('titre, référence, date',T(pg,'#title')=='Villa R+1 Limete' and T(pg,'#ref')=='EXD-2026-001' and T(pg,'#date')=='09/11/2026')
    lab=pg.evaluate("[...document.querySelectorAll('.details .item')].filter(e=>!e.hidden).map(e=>e.querySelector('span').textContent+'='+e.querySelector('b').textContent)")
    check('champs adaptés au devis (prestataire, client, montant, validité)',any(x=='Prestataire=Excellencia Building' for x in lab) and any(x=='Client=Jean Mukendi' for x in lab) and any(x=='Montant total=3 504,00 USD' for x in lab) and any(x.startswith('Validité=Valable jusqu’au 09/12/2026') for x in lab) and any(x=='Document=Devis N° DEV-2026-001' for x in lab),str(lab))
    check('champ « concepteur » masqué pour un devis',pg.evaluate("document.getElementById('designer').parentElement.hidden")==True)
    check('un seul document (chemin piégé ignoré) + bouton « Télécharger le Devis »',pg.locator('#docList .dlbig').count()==1 and 'Télécharger le Devis' in T(pg,'#docList'))
    check('message de succès « votre devis »','votre devis' in T(pg,'#status'))
    with pg.expect_download(timeout=8000) as dl: pg.click('#docList .dlbig')
    check('téléchargement du PDF depuis exb-devis-publics',dl.value.suggested_filename.endswith('.pdf') and dl_urls and '/object/public/exb-devis-publics/'+ORG+'/'+TOK+'/devis.pdf' in dl_urls[-1],dl_urls[-1][-80:] if dl_urls else '')
    check('aperçu image affiché',pg.locator('#preview img').count()==1)
    check('pas d\'erreur JS',not errs,str(errs[:2])); pg.close()
    # mauvais code
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8796/plan.html?ref=EXD-2026-001&k=ZZZZZZZZZZ'); pg.wait_for_selector('#empty:not([hidden])',timeout=8000)
    check('mauvais code : rien d\'affiché',pg.locator('#projectCard').is_hidden() and 'introuvable' in T(pg,'#status').lower()); pg.close()
    # saisie manuelle (le client tape la référence + le code imprimés sur la fiche)
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8796/plan.html'); pg.fill('#inRef','exd-2026-001'); pg.fill('#inCode','a1b2c-3d4e5'); pg.click('#inBtn'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('saisie manuelle d\'une référence de devis',T(pg,'#title')=='Villa R+1 Limete'); pg.close()
    # un plan garde ses libellés
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8796/plan.html?ref=EXB-2026-001&k=A1B2C3D4E5'); pg.wait_for_timeout(1200)
    check('référence de plan : appelle toujours plan_public_get',rpcs[-1][0]=='plan'); pg.close()
    # mobile
    pg,errs=newpage(b,390); pg.goto('http://127.0.0.1:8796/plan.html?ref=EXD-2026-001&k=A1B2C3D4E5'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('mobile 390 px : pas de défilement horizontal',pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
    pg.screenshot(path=os.environ.get('SHOT','/tmp/claude-0/-home-claude/3dae4c1c-80ac-590f-870b-add3d75f0741/scratchpad/portail-devis-mobile.png'),full_page=True); pg.close()
    pg,errs=newpage(b,1200); pg.goto('http://127.0.0.1:8796/plan.html?ref=EXD-2026-001&k=A1B2C3D4E5'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    pg.screenshot(path='/tmp/claude-0/-home-claude/3dae4c1c-80ac-590f-870b-add3d75f0741/scratchpad/portail-devis-pc.png',full_page=True); pg.close()
    b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
