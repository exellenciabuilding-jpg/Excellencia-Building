#!/usr/bin/env python3
"""V200 — demande de projet sur le portail client (formulaires séparés + compte automatique) :
   python3 tools/e2e-demande.py   (depuis le dossier du site). Le serveur Supabase est simulé (aucun appel réseau réel)."""
import http.server, threading, socketserver, os, functools, sys, json, base64
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.ThreadingTCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start(); U=f'http://127.0.0.1:{PORT}/'
fails=0
def ok(c,m):
    global fails; print(('  OK   ' if c else '  FAIL ')+m); fails+= (not c)
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')
open('/tmp/_demande_test.png','wb').write(PNG)
S='cs_'+'b'*48
calls=[]; mode={'absent':False}
def handler(route):
    fn=route.request.url.split('/rpc/')[-1]; b=json.loads(route.request.post_data or '{}'); calls.append((fn,b))
    def out(o,st=200): route.fulfill(status=st,content_type='application/json',body=json.dumps(o))
    if fn=='client_demande_envoyer':
        if mode['absent']: return out({'code':'PGRST202','message':'Could not find the function public.client_demande_envoyer'},404)
        return out({'ok':True,'matricule':'CLI-0042','compte':True,'deja':False,'session':False})
    if fn=='demande_projet_envoyer': return out({'ok':True,'matricule':'BTP-0007'})
    if fn=='btp_suivi_enregistrer': return out(True)
    if fn=='client_connexion': return out({'ok':True,'session':S,'doit_changer':False,'nom':'Jean','matricule':'CLI-0042'})
    if fn=='portail_lire': return out({'ok':False,'code':'revoque'})
    if fn=='client_dossier': return out({'ok':True,'nom':'Jean Kabongo','matricule':'CLI-0042','demandes':[{'id':'1','matricule':'CLI-0042','type':'renovation','statut':'recue','cree_le':'2026-11-18T08:00:00Z','resume':{'location':'Gombe','note':'Rénovation — Type de bien : Maison | Travaux souhaités : Peinture, Carrelage / sols'}}]})
    if fn=='client_deconnexion': return out({'ok':True})
    return out({'ok':True})
def n(fn): return [c for c in calls if c[0]==fn]
def pick(pg,grp,txt): pg.locator('#%s .pill'%grp,has_text=txt).first.click()
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    def page(w=1280,h=900):
        pg=b.new_page(viewport={'width':w,'height':h}); pg.on('pageerror',lambda e:errs.append(str(e)[:140]))
        pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}'))
        pg.route('http://x.test/**',handler); return pg
    has=lambda pg,i: pg.locator('#'+i).count()>0 and pg.locator('#'+i).is_visible()

    # 1. choix du type
    pg=page(); pg.goto(U+'demande.html'); pg.wait_for_timeout(500)
    ok(pg.locator('.tile').count()==5,'choix : 5 types de demande (construction, architecture, métré & devis, rénovation, autre)')
    ok(pg.is_hidden('#f'),'choix : aucun formulaire affiché avant le choix')
    pg.click('.tile[data-k="metre"]'); pg.wait_for_timeout(300)
    ok(pg.is_visible('#f') and 'métré' in pg.inner_text('#ft'),'tuile Métré → son formulaire')
    ok(not has(pg,'f_length_m') and not has(pg,'f_width_m') and not has(pg,'f_environment') and not has(pg,'f_titre'),'MÉTRÉ : aucune dimension de parcelle / terrain')
    ok(has(pg,'f_objet'),'métré : « Objet du devis » présent')
    # plans facultatifs
    ok(not has(pg,'f_plans'),'métré : dépôt de plans caché tant qu’on ne choisit rien (facultatif)')
    pick(pg,'f_plans_dispo','J’ai'); pg.wait_for_timeout(100)
    ok(has(pg,'f_plans'),'métré : « J’ai des plans » → dépôt de plans')
    pick(pg,'f_plans_dispo','Je n’ai pas'); pg.wait_for_timeout(100)
    ok(not has(pg,'f_plans') and has(pg,'f_surface_bati') and has(pg,'f_pieces'),'métré : « Pas de plans » → surface, niveaux, pièces')
    # corps d'état conditionnel
    ok(not has(pg,'f_corps'),'métré : corps d’état cachés par défaut')
    pg.select_option('#f_objet','Un ou plusieurs corps d’état'); pg.wait_for_timeout(100)
    ok(has(pg,'f_corps'),'métré : « corps d’état » → liste des corps d’état')
    # postes détaillés
    ok(pg.locator('.lrow').count()==1,'métré : une ligne de devis détaillé proposée')
    pg.click('#f_postes_add'); ok(pg.locator('.lrow').count()==2,'métré : « Ajouter un poste »')
    pg.close()

    for k,terr,label in [('construction',True,'Construction'),('architecture',True,'Architecture'),('renovation',False,'Rénovation'),('autre',False,'Autre')]:
        q=page(); q.goto(U+'demande.html?type='+k); q.wait_for_timeout(500)
        ok(q.is_visible('#f') and q.is_hidden('#choose'),f'{label} : ouverture directe par ?type={k}')
        ok(has(q,'f_length_m')==terr,f'{label} : dimensions de la parcelle {"présentes" if terr else "ABSENTES"}')
        ok(has(q,'f_name') and has(q,'f_phone') and has(q,'pwd'),f'{label} : coordonnées + mot de passe de l’espace')
        q.close()
    q=page(); q.goto(U+'demande.html?type=construction'); q.wait_for_timeout(400)
    q.fill('#f_length_m','25'); q.fill('#f_width_m','12'); ok(q.input_value('#f_surface')=='300','construction : superficie calculée (25 × 12 = 300)')
    ok(not has(q,'f_plans'),'construction : plans cachés avant la réponse')
    pick(q,'f_plans_exist','Oui'); ok(has(q,'f_plans'),'construction : « j’ai des plans » → dépôt de plans')
    q.close()

    # 2. validation : envoi à vide refusé, aucun appel serveur
    pg=page(); pg.goto(U+'demande.html?type=renovation'); pg.wait_for_timeout(400); calls.clear()
    pg.click('#send'); pg.wait_for_timeout(300)
    ok(pg.locator('.fe:not(:empty)').count()>=4 and not calls,'rénovation : envoi à vide refusé, erreurs affichées, aucun appel serveur')
    # 3. mots de passe différents
    pg.select_option('#f_bien','Maison'); pick(pg,'f_travaux','Peinture'); pick(pg,'f_travaux','Carrelage')
    pg.fill('#f_name','Jean Kabongo'); pg.fill('#f_phone','+243 810 000 111'); pg.fill('#f_location','Gombe, Kinshasa')
    pg.fill('#pwd','Secret#2026'); pg.fill('#pwd2','autre-chose'); pg.click('#send'); pg.wait_for_timeout(300)
    ok('différents' in pg.inner_text('#pwd2 >> xpath=..') and not calls,'mots de passe différents : refusé')
    # 4. envoi complet (rénovation, petit devis) + photo
    pg.fill('#pwd2','Secret#2026')
    pg.set_input_files('#f_photos',['/tmp/_demande_test.png']); pg.wait_for_timeout(700)
    ok('1 image' in pg.inner_text('#f_photos_i'),'rénovation : photo ajoutée et préparée')
    with pg.expect_download(timeout=15000) as dl: pg.click('#send')
    pg.wait_for_selector('#done:not([hidden])',timeout=8000)
    ok(dl.value.suggested_filename=='Fiche-Demande-CLI-0042.pdf','fiche PDF téléchargée automatiquement (Fiche-Demande-CLI-0042.pdf)')
    r=n('client_demande_envoyer'); d=r[0][1]['p_data'] if r else {}
    ok(len(r)==1 and d.get('type_demande')=='renovation' and d.get('category')=='BTP' and 'Peinture' in d.get('travaux',[]),'serveur : demande « rénovation » envoyée avec ses champs')
    ok(r[0][1]['p_mdp']=='Secret#2026' and r[0][1]['p_session'] is None,'serveur : mot de passe choisi transmis (haché côté base)')
    ok('Peinture' in d['note'] and 'Gombe' in d['location'] and d['state'].startswith('Maison déjà construite') and not d.get('length_m'),'données : note lisible pour l’équipe, état « déjà construite », pas de parcelle')
    ok('Secret#2026' not in json.dumps(d),'données de la demande : aucun mot de passe')
    ok(len(n('btp_suivi_enregistrer'))==1 and len(n('btp_suivi_enregistrer')[0][1]['p_photos'])==1,'photo transmise au suivi')
    ok(len(n('client_connexion'))==1 and n('client_connexion')[0][1]['p_matricule']=='CLI-0042','connexion automatique au nouvel espace (sans nouveau code)')
    ok(pg.inner_text('#dMatV')=='CLI-0042' and pg.get_attribute('#dGo','href')=='portail.html','confirmation : numéro client + bouton vers l’espace')
    ok(pg.evaluate("sessionStorage.getItem('exb_cs')")==S,'session client ouverte')
    pg.close()

    # 5. SQL V200 pas encore exécuté → repli sur l'ancien envoi, sans erreur
    mode['absent']=True; calls.clear()
    pg=page(); pg.goto(U+'demande.html?type=autre'); pg.wait_for_timeout(400)
    pg.fill('#f_objet','Vitrerie boutique'); pg.fill('#f_note','Remplacer 3 vitres'); pg.fill('#f_name','Marie T'); pg.fill('#f_phone','0810000222')
    pg.fill('#pwd','Secret#2026'); pg.fill('#pwd2','Secret#2026'); pg.click('#send'); pg.wait_for_selector('#done:not([hidden])',timeout=8000)
    ok(len(n('demande_projet_envoyer'))==1 and n('demande_projet_envoyer')[0][1]['p_data']['category']=='Divers','repli : ancienne fonction utilisée (catégorie Divers)')
    ok('activé par l’entreprise' in pg.inner_text('#dText'),'repli : message « espace activé par l’entreprise »')
    mode['absent']=False; pg.close()

    # 6. client déjà connecté : pas de mot de passe, rattaché à son compte
    calls.clear(); ctx=b.new_context(viewport={'width':1280,'height':900}); pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)[:140]))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}')); pg.route('http://x.test/**',handler)
    pg.goto(U+'demande.html'); pg.evaluate(f"sessionStorage.setItem('exb_cs','{S}')"); pg.goto(U+'demande.html?type=architecture'); pg.wait_for_timeout(400)
    ok(pg.is_hidden('#pwBox') and pg.is_visible('#sesNote'),'connecté : pas de mot de passe demandé, bandeau « ajoutée à votre espace »')
    pick(pg,'f_prestations','Plan de maison'); pg.select_option('#f_batiment','Maison / villa')
    pg.fill('#f_name','Jean Kabongo'); pg.fill('#f_phone','+243810000111'); pg.fill('#f_location','Gombe'); pg.click('#send'); pg.wait_for_selector('#done:not([hidden])',timeout=8000)
    ok(n('client_demande_envoyer')[0][1]['p_session']==S and not n('client_connexion'),'connecté : demande rattachée à la session, pas de nouvelle connexion')
    ctx.close()

    # 7. espace client : dossier d'un compte sans suivi publié
    ctx=b.new_context(viewport={'width':1280,'height':900}); pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)[:140]))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}')); pg.route('http://x.test/**',handler)
    pg.goto(U+'demande.html'); pg.evaluate(f"sessionStorage.setItem('exb_cs','{S}')"); pg.goto(U+'portail.html'); pg.wait_for_selector('.d-wrap',timeout=8000)
    t=pg.inner_text('.d-wrap')
    ok('Jean Kabongo' in t and 'Bienvenue dans votre espace client' in t and 'CLI-0042' in pg.inner_text('.d-chip'),'espace : nouveau tableau de bord (nom, identifiant du compte en haut)')
    ok('en cours d’étude' in t and not pg.locator('.dos').count(),'espace : bandeau « demande en cours d’étude », plus l’ancien « Mon dossier »')
    ok(not __import__('re').search(r'BTP-\d|numéro de suivi|code de suivi',t,__import__('re').I),'espace : aucun code / numéro de suivi affiché')
    pg.click('.d-nv[data-go="projet"]'); pg.wait_for_selector('#vApp .d-pagehd h1:has-text("Mon projet")',timeout=5000)
    tc=pg.text_content('.d-wrap')
    ok('Rénovation' in tc and 'Peinture' in tc and 'Demande reçue' in tc,'espace : « Mon projet » (demande envoyée, détail, étapes)')
    pg.click('button[data-a="newd"]'); pg.wait_for_url('**/demande.html',timeout=5000)
    ok(True,'espace : « Nouvelle demande » → formulaire')
    pg.goto(U+'portail.html#messages'); pg.wait_for_selector('.d-wrap',timeout=8000)
    ok(pg.locator('#mTx').count()==0 and pg.locator('.d-ct a').count()>=1,'espace : messagerie remplacée par les contacts avant lancement du projet')
    ctx.close()

    # 8. téléphone
    m=page(390,844); m.goto(U+'demande.html'); m.wait_for_timeout(500)
    ok(m.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1"),'téléphone : choix sans défilement horizontal')
    m.goto(U+'demande.html?type=metre'); m.wait_for_timeout(500)
    ok(m.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1"),'téléphone : formulaire métré sans défilement horizontal')
    m.close()
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2])); b.close()
print('\nRésultat :',('%d échec(s)'%fails) if fails else 'tout passe'); sys.exit(1 if fails else 0)
