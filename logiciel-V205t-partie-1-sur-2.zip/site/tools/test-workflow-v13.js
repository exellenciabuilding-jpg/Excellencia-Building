/* Tests Workflow v1.3 : factures, caisse, notifications, mode serveur (node tools/test-workflow-v13.js).
 * Le serveur est SIMULÉ avec le même moteur JavaScript : ce test vérifie le CLIENT (envoi, retour du serveur, refus, hors connexion, fusion),
 * pas le SQL (voir README-V149 : le SQL n'a pas pu être exécuté ici). */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const store = {}, notes = [], bell = [];
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } };
global.EXBCore = { audit: { log() {} }, bus: { emit(n, p) { global.__bus.push(n); }, on() {} } }; global.__bus = [];
global.notify = (m, t) => notes.push(t + ': ' + m);
global.exbLogNotification = (m, t) => bell.push(m);
global.document = { readyState: 'loading', visibilityState: 'visible', addEventListener() {}, getElementById: () => null, querySelector: () => null, createElement: () => ({}), body: { appendChild() {} } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
let who = { on: true, role: 'editeur', fonction: 'chef_projet', label: 'Chef de projet' }, nom = 'Paul';
global.EXBDB = { org: () => 'org1', info: () => who, _meta: () => ({ nom, role: who.role }) };
let online = true; const server = { dossiers: {}, circuits: {}, deleg: {}, calls: [], down: false };
let SRV_USER = { name: 'Paul', role: 'chef_projet', roles: [], id: 'u-paul', rl: 'editeur' };
require('../exb-workflow.js'); require('../exb-workflow-liens.js'); require('../exb-workflow-notif.js');
const W = window.EXBWF, L = window.EXBWFL, E = L.engine, WE = W.engine;
ok(W && L && E && WE, 'modules chargés');

/* ---- alias de fonction ---- */
eq(WE.rolesOf('direction', 'editeur').slice(0, 3), ['direction', 'directeur general', 'directeur'], 'alias direction');
ok(WE.rolesOf('', 'admin').indexOf('administrateur') >= 0, 'alias administrateur');
ok(WE.matches({ name: 'Paul', role: 'chef_projet', roles: WE.rolesOf('chef_projet', 'editeur') }, { role: 'Chef de projet' }), 'fonction « Chef de projet » reconnue');
ok(WE.matches({ name: 'Marie', role: 'direction', roles: WE.rolesOf('direction') }, { role: 'Directeur général' }), '« Directeur général » ↔ fonction direction');
ok(!WE.matches({ name: '', role: '', roles: [] }, { name: '' }), 'nom vide ne correspond jamais');
ok(WE.matches({ name: 'Marie' }, { name: 'marie' }), 'nom insensible à la casse (inchangé)');
eq(WE.norm('Bureau d’études'), "bureau d'etudes", 'apostrophe typographique normalisée');

/* ---- facture ---- */
const inv = { id: 'FAC-1', no: 'FAC-2026-001', client: 'ACME', currency: 'USD', tva: 16, project_id: 'P1', lines: [{ d: 'Dalle', q: 10, pu: 100 }], payments: [] };
const ii = E.invoiceInfo(inv);
eq(ii.montant, 1160, 'montant facture = TTC'); eq(ii.devise, 'USD', 'devise facture');
const inv2 = JSON.parse(JSON.stringify(inv)); inv2.payments.push({ amount: 50 });
eq(E.invoiceInfo(inv2).fp, ii.fp, 'un paiement ne change pas l\'empreinte');
inv2.lines[0].pu = 101; ok(E.invoiceInfo(inv2).fp !== ii.fp, 'une ligne modifiée change l\'empreinte');
eq(E.invoiceInfo({ id: 'x', currency: 'FC', lines: [] }).devise, 'CDF', 'FC → CDF');
ok(E.needs({ facture: { on: true, seuil: 1000, devise: 'USD' } }, 'facture', 1160, 'USD'), 'facture au-dessus du seuil : contrôlée');
ok(!E.needs({ facture: { on: true, seuil: 2000, devise: 'USD' } }, 'facture', 1160, 'USD'), 'facture sous le seuil : libre');

/* ---- dépense de caisse ---- */
const cfgv = { depense: { on: true, seuil: 500, devise: 'USD' } };
const ex1 = { id: 'C1', type: 'out', label: 'Ciment', amount: 800, date: '2026-11-01' };
ok(E.cashGated(ex1, cfgv), 'sortie ≥ seuil retenue');
ok(!E.cashGated({ id: 'C2', type: 'out', label: 'Colle', amount: 100 }, cfgv), 'sortie sous le seuil libre');
ok(!E.cashGated({ id: 'C3', type: 'in', label: 'Reçu', amount: 9000 }, cfgv), 'recette jamais retenue');
ok(!E.cashGated(Object.assign({}, ex1, { src: 'ch:1' }), cfgv), 'import automatique exclu');
ok(!E.cashGated(Object.assign({}, ex1, { po_id: 'PO1' }), cfgv), 'paiement de commande exclu');
ok(!E.cashGated(Object.assign({}, ex1, { ref: 'POINTAGE' }), cfgv), 'paie exclue');
ok(!E.cashGated(Object.assign({}, ex1, { wf_ok: 'WF-1' }), cfgv), 'écriture déjà validée exclue');
const dv = { no: 'WF-2026-0001', status: 'valide', ref: { module: 'depense', id: 'C1', payload: ex1 } };
eq(E.pendingApply([dv], [], [], [], []).depense.length, 1, 'dépense validée à ajouter');
eq(E.pendingApply([dv], [], [], [], ['C1']).depense.length, 0, 'déjà appliquée : rien');
eq(E.pendingApply([dv], [], [], [ex1], []).depense[0].present, true, 'déjà présente en caisse repérée');
eq(E.pendingApply([Object.assign({}, dv, { status: 'refuse' })], [], [], [], []).depense[0].to, 'ko', 'dépense refusée');
eq(E.pendingApply([{ status: 'valide', ref: { module: 'depense', id: 'C9' } }], [], [], [], []).depense.length, 0, 'sans copie de l\'écriture : rien');

/* ---- parcours caisse + facture avec le Workflow local ---- */
const set = (k, v) => { store[k] = JSON.stringify(v); }, get = (k, d) => (k in store ? JSON.parse(store[k]) : d);
who = { on: false }; nom = '';
set('exb_wf_circuits', [{ id: 'cd', nom: 'Dépenses', type: 'depense', actif: true, steps: [{ nom: 'Dir', mode: 'sequentiel', approvers: [{ name: 'Marie' }] }] }, { id: 'cf', nom: 'Factures', type: 'facture', actif: true, steps: [{ nom: 'Dir', mode: 'sequentiel', approvers: [{ name: 'Marie' }] }] }]);
set('exb_wf_liens', { depense: { on: true, seuil: 500, devise: 'USD' }, facture: { on: true, seuil: 0, devise: 'USD' } });
set('exb_cash', []);
const saved = []; global.exbCash = []; global.exbSave = (k, v) => { saved.push([k, v.length]); store[k] = JSON.stringify(v); };
let pdfCalls = 0; global.EXBCH = { pdf: id => { pdfCalls++; } };
L.install();
ok(window.exbSave.__wfl, 'exbSave enveloppé'); ok(EXBCH.pdf.__wfl, 'EXBCH.pdf enveloppé');
set('exb_invoices', [inv]);
EXBCH.pdf('FAC-1'); eq(pdfCalls, 0, 'PDF facture bloqué sans validation');
(async () => {
  await sleep(10);
  /* dépense : ajout par un écran */
  global.exbCash.push({ id: 'C1', type: 'out', label: 'Ciment', amount: 800, date: '2026-11-01' }, { id: 'C2', type: 'out', label: 'Colle', amount: 100 });
  window.exbSave('exb_cash', global.exbCash);
  eq(get('exb_cash', []).map(x => x.id), ['C2'], 'la grosse dépense est retenue, la petite enregistrée');
  eq(global.exbCash.map(x => x.id), ['C2'], 'liste vivante nettoyée avant l\'écran');
  const dos = W.list().filter(x => x.ref && x.ref.module === 'depense');
  eq(dos.length, 1, 'un dossier créé pour la dépense'); eq(dos[0].ref.payload.id, 'C1', 'le dossier porte la copie de l\'écriture');
  ok(notes.some(m => /Dépense soumise pour validation/.test(m)), 'message affiché');
  /* validation → ajout à la caisse, une seule fois */
  const r = W.decide(dos[0].id, 'approuver', '', { name: 'Marie' }); eq(r.event, 'valide', 'dépense validée');
  L.apply(); eq(get('exb_cash', []).map(x => x.id).sort(), ['C1', 'C2'], 'écriture ajoutée après validation');
  eq(get('exb_cash', []).filter(x => x.id === 'C1')[0].wf_ok, dos[0].no, 'écriture marquée validée');
  L.apply(); eq(get('exb_cash', []).length, 2, 'application idempotente');
  set('exb_cash', get('exb_cash', []).filter(x => x.id !== 'C1')); global.exbCash.length = 0;
  L.apply(); eq(get('exb_cash', []).length, 1, 'supprimée ensuite : pas ré-ajoutée');
  /* facture : soumission puis validation */
  EXBCH.pdf('FAC-1'); await sleep(10); /* demande de soumission : exbConfirm absent → confirm absent = non */
  const sub = require('../exb-workflow-liens.js'); /* no-op */
  const fd = W.submit({ type: 'facture', titre: ii.titre, montant: ii.montant, devise: ii.devise, ref: { module: 'facture', id: ii.id, fp: ii.fp } });
  ok(fd.ok, 'facture soumise'); EXBCH.pdf('FAC-1'); eq(pdfCalls, 0, 'toujours bloqué : en cours');
  W.decide(fd.dossier.id, 'approuver', '', { name: 'Marie' }); EXBCH.pdf('FAC-1'); eq(pdfCalls, 1, 'PDF autorisé après validation');
  const ch = JSON.parse(JSON.stringify(inv)); ch.lines[0].pu = 150; set('exb_invoices', [ch]); EXBCH.pdf('FAC-1'); eq(pdfCalls, 1, 'facture modifiée : nouvelle validation exigée');

  /* ================= notifications ================= */
  const N = window.EXBWFN; ok(N, 'EXBWFN chargé'); const P = N.pure;
  const dd = { id: 'a', no: 'WF-1', titre: 'Devis X', version: 1, cur: 0, status: 'en_cours', steps: [{ nom: 'Dir' }], echeance: '2026-11-20', history: [] };
  let c = P.collect({ mine: [dd], initiated: [], due: [], seen: {}, today: '2026-11-15' });
  eq(c.items.length, 1, 'un dossier à valider = un signal'); ok(/attend votre validation/.test(c.items[0].text) && /20\/11\/2026/.test(c.items[0].text), 'texte avec échéance');
  eq(P.collect({ mine: [dd], seen: { [P.kTask(dd)]: 1 }, today: 'x' }).items.length, 0, 'déjà vu : rien');
  eq(P.collect({ mine: [Object.assign({}, dd, { cur: 1, steps: [{}, { nom: 'DG' }] })], seen: { [P.kTask(dd)]: 1 }, today: 'x' }).items.length, 1, 'nouvelle étape = nouveau signal');
  eq(P.collect({ mine: [Object.assign({}, dd, { version: 2 })], seen: { [P.kTask(dd)]: 1 }, today: 'x' }).items.length, 1, 'resoumis = nouveau signal');
  c = P.collect({ mine: [dd], due: [{ id: 'a', etat: 'retard', jours: 3 }], seen: { [P.kTask(dd)]: 1 }, today: '2026-11-15' });
  ok(c.items.length === 1 && /retard de 3 jour/.test(c.items[0].text), 'retard signalé');
  eq(P.collect({ mine: [dd], due: [{ id: 'a', etat: 'retard', jours: 3 }], seen: { [P.kTask(dd)]: 1, [P.kDue(dd, '2026-11-15')]: 1 }, today: '2026-11-15' }).items.length, 0, 'rappel une fois par jour');
  const rf = { id: 'b', no: 'WF-2', titre: 'Achat', version: 1, cur: 0, status: 'refuse', steps: [{}], history: [{ action: 'refuser', acteur: 'Marie', motif: 'trop cher' }] };
  c = P.collect({ initiated: [rf], seen: {} }); ok(c.items.length === 1 && /refusé par Marie : « trop cher »/.test(c.items[0].text), 'refus notifié à l\'initiateur avec motif');
  eq(P.collect({ initiated: [Object.assign({}, rf, { status: 'en_cours' })], seen: {} }).items.length, 0, 'dossier en cours : pas de signal initiateur');
  const big = {}; for (let i = 0; i < 700; i++) big['k' + i] = i; eq(Object.keys(P.prune(big, 1000)).length, 600, 'mémoire bornée');

  /* première ouverture : synthèse seule ; ensuite signal individuel */
  who = { on: true, role: 'editeur', fonction: 'direction', label: 'Direction' }; nom = 'Marie'; notes.length = 0; bell.length = 0;
  set('exb_wf_dossiers', []);
  const s1 = W.submit({ circuit_id: 'cd', titre: 'Achat sable', montant: 900, devise: 'USD', initiateur: { name: 'Paul' } });
  ok(s1.ok, 'dossier pour Marie'); N._reset();
  let r1 = N.check(); ok(r1.first, 'première passe = synthèse'); ok(notes.some(m => /1 dossier\(s\) à valider/.test(m)), 'message de synthèse');
  notes.length = 0; r1 = N.check(); eq(r1.shown, 0, 'rien de nouveau : silence');
  W.submit({ circuit_id: 'cd', titre: 'Achat gravier', montant: 700, devise: 'USD', initiateur: { name: 'Paul' } });
  notes.length = 0; bell.length = 0; r1 = N.check(); eq(r1.shown, 1, 'nouveau dossier = un signal');
  ok(/Achat gravier/.test(notes[0]) && /Achat gravier/.test(bell[0]), 'toast + cloche');
  N.check(); eq(notes.length, 1, 'pas de répétition');
  who = { on: false };

  /* ================= mode serveur ================= */
  await serverTests();
  console.log('Workflow v1.3 : ' + n + ' contrôles OK'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });

async function serverTests() {
  const net = () => { if (server.down) { const e = new Error('Failed to fetch'); throw e; } };
  const rows = o => Object.values(o);
  global.exbSb = { isIn: () => true, api: async (path, opt) => {
    net(); server.calls.push(path.replace(/\?.*/, ''));
    const m = /\/rpc\/(\w+)/.exec(path), body = opt && opt.body ? JSON.parse(opt.body) : {};
    if (m) return rpc(m[1], body);
    if (/wf_circuits/.test(path)) return rows(server.circuits).map(x => ({ id: x.id, data: x }));
    if (/wf_deleg/.test(path)) return rows(server.deleg).map(x => ({ id: x.id, data: x }));
    if (/wf_dossiers\?/.test(path)) { const one = /[?&]id=eq\.([^&]+)/.exec(path); const all = rows(server.dossiers).map(x => ({ id: x.data.id, revision: x.revision, maj: x.maj, data: x.data })); return one ? all.filter(x => x.id === decodeURIComponent(one[1])) : all; }
    return [];
  } };
  let tick = 0; const maj = () => '2026-11-15T10:00:' + String(10 + (++tick)).padStart(2, '0') + 'Z';
  function rpc(fn, b) {
    const act = { name: SRV_USER.name, role: SRV_USER.role, roles: WE.rolesOf(SRV_USER.role, SRV_USER.rl) };
    if (fn === 'wf_etat') return { ok: true, version: 1, acteur: Object.assign({}, SRV_USER, { roles: act.roles }) };
    if (fn === 'wf_config_ecrire') { if (SRV_USER.rl !== 'admin') return { ok: false, refus: 'Réservé à l\'administrateur.' }; if (b.p_supprime) delete server[b.p_kind === 'circuit' ? 'circuits' : 'deleg'][b.p_id]; else server[b.p_kind === 'circuit' ? 'circuits' : 'deleg'][b.p_id] = b.p_data; return { ok: true }; }
    if (fn === 'wf_soumettre') {
      if (server.dossiers[b.p_id]) return { ok: true, deja: true, revision: server.dossiers[b.p_id].revision, dossier: server.dossiers[b.p_id].data };
      const c = rows(server.circuits).filter(x => x.id === b.p_circuit_id || x.type === b.p_data.type)[0]; if (!c) return { ok: false, refus: 'Aucun circuit actif pour ce type de dossier.' };
      const r = WE.start(c, Object.assign({ id: b.p_id }, b.p_data), { name: act.name, role: act.role }, new Date().toISOString(), 'WF-2026-S' + String(rows(server.dossiers).length + 1).padStart(3, '0'));
      if (!r.ok) return { ok: false, refus: r.error }; r.dossier.initiateur.uid = SRV_USER.id; server.dossiers[b.p_id] = { revision: 1, maj: maj(), data: r.dossier }; return { ok: true, revision: 1, dossier: r.dossier };
    }
    if (fn === 'wf_decider') {
      const cur = server.dossiers[b.p_id]; if (!cur) return { ok: false, refus: 'Dossier introuvable.' };
      if ((b.p_etape != null && b.p_etape !== cur.data.cur) || (b.p_version != null && b.p_version !== cur.data.version)) return { ok: false, refus: 'Le dossier a changé depuis que vous l\'avez ouvert : relisez-le avant de décider.' };
      const r = WE.act(cur.data, act, b.p_action, b.p_motif, { now: new Date().toISOString(), delegations: rows(server.deleg), verified: true }); if (!r.ok) return { ok: false, refus: r.error };
      cur.revision++; cur.maj = maj(); cur.data = r.dossier; return { ok: true, event: r.event, revision: cur.revision, dossier: r.dossier };
    }
    return { ok: false, refus: 'inconnu' };
  }
  require('../exb-workflow-serveur.js'); const S = window.EXBWFS; ok(S, 'EXBWFS chargé');

  /* fonctions pures */
  const D = S.pure.diffById([{ id: 'a', x: 1 }, { id: 'b' }], [{ id: 'a', x: 2 }, { id: 'c' }]);
  eq([D.up.map(x => x.id), D.del], [['a', 'c'], ['b']], 'diff circuits (modifié, ajouté, retiré)');
  eq(S.pure.eventBetween({ status: 'en_cours', cur: 0, version: 1, decisions: [] }, { status: 'valide', cur: 0, version: 1, decisions: [1] }), 'valide', 'événement valide');
  eq(S.pure.eventBetween({ status: 'en_cours', cur: 0, version: 1, decisions: [] }, { status: 'en_cours', cur: 1, version: 1, decisions: [1] }), 'decision', 'événement étape');
  eq(S.pure.eventBetween({ status: 'retourne', cur: 0, version: 1, decisions: [] }, { status: 'en_cours', cur: 0, version: 2, decisions: [] }), 'resoumis', 'événement resoumis');
  const lst = [{ id: 'z', _rev: 3, status: 'en_cours', decisions: [], cur: 0, version: 1 }];
  eq(S.pure.mergeRow(lst, { id: 'z', revision: 3, data: { id: 'z' } }, {}).changed, false, 'révision égale : inchangé');
  eq(S.pure.mergeRow(lst, { id: 'z', revision: 4, data: { id: 'z', status: 'valide', cur: 0, version: 1, decisions: [] } }, {}).event, 'valide', 'révision plus récente : fusionnée');
  eq(S.pure.mergeRow(lst, { id: 'z', revision: 9, data: { id: 'z' } }, { z: 1 }).changed, false, 'dossier en cours d\'envoi : intact');

  /* installation du serveur : l'administrateur envoie ses circuits */
  who = { on: true, role: 'admin', fonction: 'polyvalent', label: 'Administrateur' }; nom = 'Admin'; SRV_USER = { name: 'Admin', role: 'admin', roles: [], id: 'u-adm', rl: 'admin' };
  set('exb_wf_dossiers', []); set('exb_wf_circuits', [{ id: 'cx', nom: 'Dépenses', type: 'depense', actif: true, steps: [{ id: 's0', nom: 'Équipe', mode: 'parallele', approvers: [{ name: 'Marie' }, { name: 'Jean' }] }] }]); set('exb_wf_deleg', []);
  ok(!S.active(), 'inactif avant la sonde'); ok(await S.probe(), 'sonde wf_etat réussie'); ok(S.active(), 'actif après la sonde');
  await S.sync(); ok(server.circuits.cx, 'circuit local envoyé au serveur (première activation)');
  eq(get('exb_wf_circuits', []).map(x => x.id), ['cx'], 'copie locale = serveur');

  /* soumission par Paul : numéro du serveur */
  who = { on: true, role: 'editeur', fonction: 'chef_projet', label: 'Chef de projet' }; nom = 'Paul'; SRV_USER = { name: 'Paul', role: 'chef_projet', roles: [], id: 'u-paul', rl: 'editeur' };
  await probe2();
  const sb = W.submit({ circuit_id: 'cx', titre: 'Achat ferraille', montant: 300, devise: 'USD' });
  ok(sb.ok && sb.pending, 'soumission optimiste'); ok(W.list()[0]._pending, 'marquée « en attente » tant que le serveur n\'a pas répondu');
  await sleep(20); eq(W.list()[0]._pending, undefined, 'confirmation : plus en attente'); eq(W.list()[0].no, 'WF-2026-S001', 'numéro attribué par le serveur'); eq(W.list()[0]._rev, 1, 'révision connue');
  ok(window.__bus.indexOf('workflow.soumis') >= 0, 'événement soumis émis après confirmation');
  const id = sb.dossier.id;

  /* deux validateurs « en même temps » (étape parallèle, tous doivent approuver) */
  global.__bus.length = 0;
  await as('marie'); const ra = W.decide(id, 'approuver', '', null); ok(ra.ok && ra.pending, 'décision de Marie envoyée');
  await as('jean');
  const rb = W.decide(id, 'approuver', '', null); ok(rb.ok, 'décision de Jean envoyée avant le retour de la première');
  await sleep(30);
  const fin = server.dossiers[id].data; eq(fin.decisions.length, 2, 'les DEUX décisions sont enregistrées'); eq(fin.status, 'valide', 'dossier validé');
  eq(W.find(id).status, 'valide', 'copie locale alignée'); ok(global.__bus.indexOf('workflow.valide') >= 0, 'événement valide émis après confirmation');

  /* refus du serveur : décision hors tour → copie locale remise à l'état du serveur */
  await as('paul'); const sb2 = W.submit({ circuit_id: 'cx', titre: 'Achat clous', montant: 50, devise: 'USD' }); await sleep(20);
  const id2 = sb2.dossier.id; await as('marie'); notes.length = 0;
  W.decide(id2, 'approuver', '', null); await sleep(20);
  server.dossiers[id2].data.status = 'refuse'; server.dossiers[id2].revision++; /* un autre a refusé pendant ce temps */
  await as('jean');
  const loc = W.find(id2); ok(loc.status === 'en_cours', 'Jean voit encore « en cours » (copie périmée)');
  W.decide(id2, 'approuver', '', null); await sleep(30);
  eq(W.find(id2).status, 'refuse', 'refus du serveur : la copie locale est actualisée');
  ok(notes.some(m => /Décision non enregistrée/.test(m)), 'motif du refus affiché');

  /* étape / version vues : décision refusée si le dossier a avancé */
  await as('paul'); const sb3 = W.submit({ circuit_id: 'cx', titre: 'Achat bois', montant: 80, devise: 'USD' }); await sleep(20); const id3 = sb3.dossier.id;
  server.dossiers[id3].data.version = 2; server.dossiers[id3].revision++; notes.length = 0; await as('marie');
  W.decide(id3, 'approuver', '', null); await sleep(30); ok(notes.some(m => /relisez-le/.test(m)), 'dossier changé : décision refusée côté serveur');

  /* hors connexion */
  await as('paul'); server.down = true; notes.length = 0; const sb4 = W.submit({ circuit_id: 'cx', titre: 'Achat eau', montant: 20, devise: 'USD' }); await sleep(20);
  ok(sb4.ok, 'soumission hors connexion acceptée localement'); eq(S.outbox().length, 1, 'dans la boîte d\'envoi'); ok(W.find(sb4.dossier.id)._pending, 'marquée en attente');
  ok(notes.some(m => /sera envoyé au serveur/.test(m)), 'message hors connexion');
  server.down = false; await S.sync(); eq(S.outbox().length, 0, 'boîte d\'envoi vidée au retour du réseau'); ok(server.dossiers[sb4.dossier.id], 'dossier arrivé sur le serveur'); ok(!W.find(sb4.dossier.id)._pending, 'plus en attente');
  /* renvoi sans doublon */
  const nb = Object.keys(server.dossiers).length; await S.sync(); eq(Object.keys(server.dossiers).length, nb, 'aucun doublon');
  /* décision hors connexion : jamais en file */
  await as('marie'); server.down = true; notes.length = 0; const before = JSON.stringify(W.find(sb4.dossier.id).decisions); W.decide(sb4.dossier.id, 'approuver', '', null); await sleep(20);
  eq(JSON.stringify(W.find(sb4.dossier.id).decisions), before, 'décision hors connexion annulée localement'); ok(notes.some(m => /Hors connexion : la décision/.test(m)), 'message clair'); server.down = false;

  /* un autre appareil reçoit la décision (pull) et émet l'événement sans journal */
  await as('paul'); const sb5 = W.submit({ circuit_id: 'cx', titre: 'Achat sable', montant: 10, devise: 'USD' }); await sleep(20); const id5 = sb5.dossier.id;
  const cp = JSON.parse(JSON.stringify(server.dossiers[id5])); cp.data.status = 'refuse'; cp.revision++; cp.maj = '2026-11-15T11:00:00Z'; server.dossiers[id5] = cp;
  global.__bus.length = 0; await S.sync(); eq(W.find(id5).status, 'refuse', 'pull : décision reçue d\'un autre appareil'); ok(global.__bus.indexOf('workflow.refuse') >= 0, 'événement émis sur cet appareil');

  /* circuits : seul l'administrateur écrit sur le serveur */
  notes.length = 0; S.pushConfig('circuit', [], [{ id: 'cz', nom: 'X', steps: [{}] }]); await sleep(10);
  ok(notes.some(m => /Seul un administrateur/.test(m)), 'non-admin : modification de circuit refusée avec explication'); ok(!server.circuits.cz, 'rien d\'écrit par un non-admin');

  /* sans les tables : mode local */
  S._state().ok = false; S._state().probed = false; global.exbSb.api = async () => { throw new Error('Could not find the function public.wf_etat'); };
  await S.probe(); ok(!S.active(), 'tables absentes : mode local'); ok(/Mode local/.test(S.statusHtml()), 'message d\'installation affiché');
  const loc2 = W.submit({ circuit_id: 'cx', titre: 'Local', montant: 1, devise: 'USD' }); ok(loc2.ok && !loc2.pending, 'mode local : comportement inchangé');
  async function probe2() { await S.probe(); }
  async function as(u) {
    const U = { marie: [{ on: true, role: 'editeur', fonction: 'direction', label: 'Direction' }, 'Marie', { name: 'Marie', role: 'direction', roles: [], id: 'u-marie', rl: 'editeur' }],
      jean: [{ on: true, role: 'editeur', fonction: 'polyvalent', label: 'Jean' }, 'Jean', { name: 'Jean', role: 'editeur', roles: [], id: 'u-jean', rl: 'editeur' }],
      paul: [{ on: true, role: 'editeur', fonction: 'chef_projet', label: 'Chef de projet' }, 'Paul', { name: 'Paul', role: 'chef_projet', roles: [], id: 'u-paul', rl: 'editeur' }] }[u];
    who = U[0]; nom = U[1]; SRV_USER = U[2]; await S.probe();
  }
}
