#!/usr/bin/env node
/* Test du lot 9 (tenir la charge) + correctifs du moteur (exb-intelligence.js) : VRAI moteur, lots 1 à 9, navigateur simulé.
 * Usage (depuis le dossier du site) :  node tools/test-intelligence-9.js
 * Variable ENGINE=chemin : essayer un autre exb-intelligence.js (ex. l'ancien, pour comparer). */
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.resolve(__dirname, '..'), R = f => fs.readFileSync(f.startsWith('/') ? f : path.join(root, f), 'utf8');
let pass = 0, fail = 0;
const ok = (c, m, d) => { if (c) { pass++; console.log('  OK   ' + m); } else { fail++; console.log('  FAIL ' + m + (d ? ' — ' + d : '')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const ENGINE = process.env.ENGINE || 'exb-intelligence.js';
function mkStorage(init) { const m = Object.assign({}, init || {}), reads = {};
  return { _m: m, reads, getItem: k => { reads[k] = (reads[k] || 0) + 1; return k in m ? m[k] : null; }, setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
function session(S, lots, opt) {
  opt = opt || {}; const handlers = {};
  const doc = { readyState: 'complete', hidden: false, head: { appendChild() {} }, body: { appendChild() {} }, documentElement: {}, getElementById: () => null,
    createElement: () => ({ style: {}, setAttribute() {}, appendChild() {}, remove() {}, addEventListener() {}, querySelector: () => null }), addEventListener(t, f) { (handlers[t] = handlers[t] || []).push(f); } };
  const fast = ms => (ms >= 500 ? 30 : ms);
  const win = { localStorage: S, document: doc, location: { origin: 'https://x.test', href: 'https://x.test/' }, navigator: { onLine: true }, addEventListener() {}, notify() {}, URL, Date, JSON, Math, Promise, Array, Object, String, RegExp, Number, Error, isFinite, parseInt,
    Blob: function () {}, setTimeout: (f, ms) => setTimeout(f, fast(ms)), setInterval: (f, ms) => setInterval(f, ms >= 500 ? 60 : ms), clearInterval, clearTimeout, console };
  win.window = win; const ctx = vm.createContext(win);
  vm.runInContext('var setTimeout=window.setTimeout,setInterval=window.setInterval,clearTimeout=window.clearTimeout,clearInterval=window.clearInterval;', ctx);
  vm.runInContext(R(ENGINE), ctx); (lots || []).forEach(l => vm.runInContext(R(l), ctx));
  return { win, doc, I: win.EXBI, handlers };
}
const L9 = 'exb-intelligence-9.js';
const inv = (i, o) => Object.assign({ id: 'F' + i, no: 'FA-' + i, client: 'C' + (i % 50), project_id: 'P' + (i % 40), tva: 18, date: '2026-01-01', due: '2026-12-31', lines: [{ q: 2, pu: 100 }], payments: [] }, o || {});

(async () => {
  console.log('\n# 1. Moteur : fiche null / données abîmées');
  let S = mkStorage({ exb_clients: JSON.stringify([null, { id: 'c1', name: 'Alpha', phone: '12' }, 5, 'x', { id: 'c2', name: 'Beta', email: 'pas-un-mail' }]), exb_invoices: JSON.stringify([null, inv(1, { lines: [] })]) });
  let s = session(S, [L9]); let f;
  try { f = s.I.run(); ok(true, 'run() ne plante pas avec des fiches null'); } catch (e) { ok(false, 'run() avec fiche null', e.message); f = []; }
  ok(f.some(x => /téléphone incomplet/.test(x.msg)) && f.some(x => /e-mail invalide/.test(x.msg)), 'les fiches valides sont toujours contrôlées');
  ok(f.some(x => /aucune ligne/.test(x.msg)), 'facture valide après une fiche null : contrôlée');
  await sleep(250); ok(true, 'le suivi des modifications (poll) tourne sans exception');
  ok(Object.keys(s.I.stats()).length >= 10, 'statistiques par contrôle disponibles (' + Object.keys(s.I.stats()).length + ')');
  S = mkStorage({ exb_clients: '{pas du json' }); s = session(S, [L9]);
  ok((() => { try { s.I.run(); return true; } catch (e) { return false; } })(), 'JSON illisible : aucune exception');

  console.log('\n# 2. Isolation : une règle qui plante n’arrête pas les autres');
  S = mkStorage({ exb_clients: JSON.stringify([{ id: 'c1', name: 'A', phone: '12' }]) }); s = session(S, [L9]);
  s.I.addRule({ id: 'test.boom', check: () => { throw new Error('boum'); } });
  f = s.I.run(); const st = s.I.stats();
  ok(f.some(x => /téléphone incomplet/.test(x.msg)), 'les autres contrôles continuent');
  ok(st['rule:test.boom'] && st['rule:test.boom'].errors === 1 && /boum/.test(st['rule:test.boom'].last), 'l’erreur est comptée et expliquée : ' + (st['rule:test.boom'] || {}).last);
  ok(/difficulté/.test(JSON.stringify(s.I.recommendations().map(r => r.t))), 'recommandation « contrôle en difficulté »');
  let nested = null; s.I.addRule({ id: 'test.nest', check: () => { nested = s.I.run(); return []; } });
  ok((() => { try { s.I.run(); return Array.isArray(nested); } catch (e) { return false; } })(), 'run() appelé depuis un contrôle : pas de boucle infinie');
  ok(!s.I.isRunning(), 'indicateur « en cours » retombe après un passage');

  console.log('\n# 3. Moteur : une seule lecture par collection et par passage');
  const big = { exb_invoices: JSON.stringify(Array.from({ length: 3000 }, (_, i) => inv(i))), exb_clients: JSON.stringify(Array.from({ length: 2000 }, (_, i) => ({ id: 'C' + i, name: 'Client ' + i, phone: '+25779' + (100000 + i) }))),
    exb_projects: JSON.stringify(Array.from({ length: 1500 }, (_, i) => ({ id: 'P' + i, name: 'Projet ' + i, client: 'Client ' + i, status: i % 3 ? 'En cours' : 'Terminé' }))),
    exb_quotes: JSON.stringify(Array.from({ length: 2000 }, (_, i) => ({ id: 'Q' + i, no: 'DV-' + i, total: 1000, client: 'x', date: '2025-01-01' }))) };
  S = mkStorage(big); s = session(S, []); await sleep(80); Object.keys(S.reads).forEach(k => S.reads[k] = 0);
  const t0 = Date.now(); s.I.run(); const dt = Date.now() - t0;
  ok(S.reads.exb_invoices === 1, 'factures lues 1 fois par passage (lu ' + S.reads.exb_invoices + ' fois ; l’ancien moteur : plusieurs)');
  ok(S.reads.exb_clients <= 2, 'clients lus ≤ 2 fois par passage (' + S.reads.exb_clients + ')');
  console.log('       passage complet sur 8 500 fiches : ' + dt + ' ms');
  ok(dt < 4000, 'passage complet raisonnable');

  console.log('\n# 4. runAsync : même résultat, par tranches');
  S = mkStorage(big); s = session(S, [L9]); await sleep(80);
  const sync = s.I.run().map(x => x.key).sort().join('\n');
  let slices = 0; const ot = s.win.setTimeout; s.win.setTimeout = (f, m) => { slices++; return ot(f, m); };
  vm.runInContext('var setTimeout=window.setTimeout;', vm.createContext(s.win)); /* sans effet sur le moteur déjà chargé : on compte autrement */
  const ra = await s.I.runAsync(); const asy = ra.map(x => x.key).sort().join('\n');
  ok(asy === sync, 'runAsync donne exactement les mêmes constats que run() (' + ra.length + ')');
  const p1 = s.I.runAsync(), p2 = s.I.runAsync(), p3 = s.I.runAsync(); await Promise.all([p1, p2, p3]); await sleep(200);
  ok(!s.I.isRunning(), 'rafale de demandes fusionnée, rien ne reste bloqué');
  const pa = s.I.runAsync(); const rs = s.I.run(); await pa;
  ok(rs.length === ra.length, 'run() synchrone pendant un passage progressif : résultat cohérent');
  s.doc.hidden = true; ok((await s.I.runAsync()).length === ra.length, 'onglet masqué : passage immédiat');

  console.log('\n# 5. Historique : un import massif ne le noie pas');
  S = mkStorage({ exb_clients: JSON.stringify([{ id: 'c0', name: 'Zéro' }]) }); s = session(S, []); await sleep(200);
  const before = s.I.history().length;
  S.setItem('exb_clients', JSON.stringify([{ id: 'c0', name: 'Zéro' }].concat(Array.from({ length: 500 }, (_, i) => ({ id: 'n' + i, name: 'Nouveau ' + i }))))); await sleep(400);
  const h = s.I.history(), added = h.length - before;
  ok(added > 0 && added <= 62, '500 créations → ' + added + ' lignes d’historique (60 + 1 ligne groupée)');
  ok(h.some(x => /regroupées/.test(x.msg || '')), 'ligne « modifications regroupées » présente');
  ok(S._m.exb_intel_history && JSON.parse(S._m.exb_intel_history).length === h.length, 'historique enregistré');

  console.log('\n# 6. File de tâches : priorités, fusion, délai, nouvelles tentatives, disjoncteur');
  s = session(mkStorage(), [L9]); await sleep(50); const T = s.I.tasks;
  ok(!!T && typeof T.add === 'function', 'EXBI.tasks disponible');
  T.pause(); const order = []; const mk = (k, pr) => T.add({ key: k, prio: pr, label: k, fn: () => { order.push(k); return k; } });
  const ps = [mk('basse', 'basse'), mk('normale', 'normale'), mk('critique', 'critique'), mk('haute', 'haute')]; T.resume(); await Promise.all(ps);
  ok(order.join() === 'critique,haute,normale,basse', 'ordre d’exécution par priorité : ' + order.join(' > '));
  T.pause(); let runs = 0; const a1 = T.add({ key: 'm', fn: () => ++runs }), a2 = T.add({ key: 'm', fn: () => ++runs }), a3 = T.add({ key: 'm', prio: 'critique', fn: () => ++runs }); T.resume();
  const rr = await Promise.all([a1, a2, a3]); ok(runs === 1 && rr[0] === rr[1], 'trois demandes identiques → une seule exécution');
  const r1 = await T.add({ key: 'lent', timeout: 60, fn: () => new Promise(() => {}) }); ok(!r1.ok && /délai/.test(r1.error), 'tâche bloquée : délai dépassé, la file continue (' + r1.error + ')');
  let n = 0; const r2 = await T.add({ key: 'retry', retries: 2, backoff: 10, fn: () => { if (++n < 3) throw new Error('réseau'); return 'ok'; } }); ok(r2.ok && n === 3, 'échecs puis réussite : 3 essais espacés');
  const r3 = await T.add({ key: 'sync-err', fn: () => { throw new Error('x'); } }); ok(!r3.ok && r3.error === 'x', 'exception : résultat d’échec, pas de plantage');
  for (let i = 0; i < 3; i++) await T.add({ key: 'ko' + i, group: 'serveur', fn: () => Promise.reject(new Error('503')) });
  const r4 = await T.add({ key: 'ko9', group: 'serveur', fn: () => 1 }); ok(r4.skipped && /suspendue/.test(r4.error), 'disjoncteur : 3 échecs → groupe suspendu');
  ok(T.status().suspended.indexOf('serveur') >= 0, 'état : groupe « serveur » suspendu');
  const r5 = await T.add({ key: 'autre', group: 'local', fn: () => 7 }); ok(r5.ok && r5.value === 7, 'un autre groupe n’est pas touché');
  s.win.navigator.onLine = false; let net = 0; const pn = T.add({ key: 'net', needsNet: true, fn: () => ++net }); await sleep(120); ok(net === 0, 'hors connexion : la tâche réseau attend'); s.win.navigator.onLine = true; T.resume(); await pn; ok(net === 1, 'connexion revenue : elle s’exécute');
  T.pause(); const pc = T.add({ key: 'c1', fn: () => 1 }); const nc = T.cancel('c1'); const rc = await pc; ok(nc === 1 && rc.cancelled, 'annulation d’une tâche en attente'); T.resume();
  T.pause(); const many = []; for (let i = 0; i < 205; i++) many.push(T.add({ key: 'q' + i, prio: 'basse', fn: () => 1 }));
  const rd = await Promise.all(many.slice(200)); ok(rd.every(x => x.dropped), 'file pleine (200) : les 5 suivantes sont écartées proprement');
  const pcrit = T.add({ key: 'urgent', prio: 'critique', fn: () => 'u' }); ok(T.status().queued === 200 && T.status().dropped >= 5, 'une tâche critique prend la place d’une tâche basse (file = ' + T.status().queued + ')');
  T.clear(); T.resume(); const ru = await pcrit; ok(ru.cancelled || ru.ok, 'file vidée sans blocage');
  await T.idle(); ok(T.status().queued === 0 && T.status().running === 0, 'file au repos');
  await sleep(1700); const lg = JSON.parse(s.win.localStorage.getItem('exb_intel_tasks_log') || '[]'); ok(lg.length > 0 && lg.length <= 100 && lg.every(x => !('fn' in x)), 'journal des tâches enregistré (' + lg.length + ' lignes, sans données)');

  console.log('\n# 7. Traitement par lots');
  s = session(mkStorage(), [L9]); await sleep(50); const B = s.I.tasks.batch; let prog = 0, last = 0;
  const arr = Array.from({ length: 20000 }, (_, i) => i); let sum = 0;
  const br = await B(arr, x => { for (let k = 0; k < 200; k++) sum += Math.sqrt(x + k); }, { budget: 5, onProgress: (i) => { prog++; last = i; } });
  ok(br.ok === 20000 && br.failed === 0 && !br.cancelled, '20 000 éléments traités');
  ok(prog > 3 && last === 20000, 'rend la main à l’écran : ' + prog + ' tranches avec progression');
  const bf = await B([1, 2, 3, 4], x => { if (x % 2) throw new Error('impair ' + x); }); ok(bf.ok === 2 && bf.failed === 2 && bf.errors.length === 2, 'erreurs isolées : 2 réussis, 2 échecs');
  const ba = await B([1, 2, 3], x => new Promise(r => setTimeout(r, 5))); ok(ba.ok === 3, 'fonction asynchrone acceptée');
  const bc = B(arr, x => { for (let k = 0; k < 500; k++) sum += k; }, { budget: 2 }); setTimeout(() => bc.cancel(), 15); const rc2 = await bc; ok(rc2.cancelled && rc2.ok < 20000, 'annulation en cours de route (' + rc2.ok + ' traités)');
  ok((await B([], () => 1)).total === 0, 'liste vide acceptée'); ok((await B(null, () => 1)).total === 0, 'valeur absente acceptée');

  console.log('\n# 8. Assistant : plusieurs demandes dans un message');
  S = mkStorage(); s = session(S, []);
  let calls = []; s.win.localAI = function (raw) { calls.push(raw); const q = String(raw).toLowerCase();
    if (/ouvre.*client/.test(q)) return { answer: 'Voilà : « Clients ».', actions: [{ type: 'goto', tab: 'clients' }] };
    if (/import/.test(q)) return { answer: 'À traiter : 3 inscriptions.', actions: [{ type: 'import', target: 'insc' }] };
    if (/sauvegarde/.test(q)) return { answer: 'Je prépare une sauvegarde.', actions: [{ type: 'backup' }] };
    return { answer: 'Je n’ai pas compris cette demande en mode local.', actions: [] }; };
  vm.runInContext(R(L9), vm.createContext(s.win)); await sleep(1700);
  const AI = s.win.localAI; ok(AI.__multi === 1, 'assistant branché');
  calls = []; let m = AI('Ouvre les clients puis importe les demandes ; fais une sauvegarde\nblabla incompréhensible');
  ok(/3 demandes/.test(m.answer) && m.actions.length === 3, 'message multiple : 3 demandes comprises, 3 actions');
  ok(/Non comprises/.test(m.answer) && /blabla/.test(m.answer), 'partie incomprise signalée sans bloquer le reste');
  ok(m.actions.map(a => a.type).join() === 'goto,import,backup', 'actions dans l’ordre demandé');
  calls = []; m = AI('ouvre les clients'); ok(calls.length === 1 && m.actions.length === 1 && !/demandes/.test(m.answer), 'demande simple : traitée comme avant (1 appel)');
  calls = []; m = AI('Rédige un message au client puis envoie-le ; merci'); ok(calls.length === 1, 'texte à rédiger : jamais découpé');
  calls = []; m = AI('1. ouvre les clients\n2. ouvre les clients\n3. importe les demandes'); ok(m.actions.length === 2, 'actions identiques fusionnées (2 sur 3)');
  calls = []; m = AI(Array.from({ length: 12 }, (_, i) => 'ouvre les clients ' + i + ' ; ').join('')); ok(/Maximum 8/.test(m.answer) && calls.length <= 8, '12 demandes : 8 traitées, le reste signalé');
  calls = []; m = AI('xyz abc ; qwe rty'); ok(/pas compris/.test(m.answer) && calls[calls.length - 1] === 'xyz abc ; qwe rty' && calls.indexOf('annule') === 2, 'rien de compris : question en attente effacée, puis message traité en entier');
  m = AI('quelle est la charge du moteur ?'); ok(/Charge du moteur/.test(m.answer), 'question sur la charge : état local');
  const mm = s.I.tasks.multi('ouvre les clients puis importe les demandes', raw => ({ answer: 'ok ' + raw, actions: [] })); ok(mm && /2 demandes/.test(mm.answer), 'API EXBI.tasks.multi');

  console.log('\n# 9. Panneau Moteurs');
  s.I.run(); const html = s.I.tasks.panelHtml();
  ok(/Charge/.test(html) && /Contrôles les plus lents/.test(html), 'charge et contrôles les plus lents affichés');
  s.I.addRule({ id: 'test.boom2', check: () => { throw new Error('casse <b>'); } }); s.I.run();
  const h2 = s.I.tasks.panelHtml(); ok(/Contrôles en erreur/.test(h2) && !/casse <b>/.test(h2), 'contrôle en erreur listé, texte échappé');
  s.I.tasks.pause(); ok(/EN PAUSE/.test(s.I.tasks.panelHtml()) && /Reprendre/.test(s.I.tasks.panelHtml()), 'pause visible avec bouton Reprendre'); s.I.tasks.resume();

  console.log('\n# 10. Lots 1 à 9 ensemble');
  const all = ['exb-intelligence-2.js', 'exb-intelligence-3.js', 'exb-intelligence-4.js', 'exb-intelligence-5.js', 'exb-intelligence-6.js', 'exb-intelligence-7.js', 'exb-intelligence-8.js', L9];
  s = session(mkStorage(big), all); await sleep(300);
  ok((() => { try { s.I.run(); return true; } catch (e) { return false; } })(), 'chargement des 9 lots + passage complet sans exception');
  const sx = s.I.stats(), errs = Object.keys(sx).filter(k => sx[k].errors); ok(errs.length === 0, 'aucun contrôle en erreur sur 8 500 fiches' + (errs.length ? ' : ' + errs.map(k => k + ' → ' + sx[k].last).join(' | ') : ''));
  const ra2 = await s.I.runAsync(); ok(ra2.length === s.I.findings().length, 'runAsync avec les 9 lots');
  ok(!!s.I.tasks && !!s.I.intake, 'file de tâches et réception intelligente présentes');

  console.log('\n# 11. Tâches nommées : reprise après fermeture de la page');
  const SS = mkStorage(); let s1 = session(SS, [L9]); await sleep(50); s1.I.tasks.define('envoi', () => 'x'); s1.I.tasks.pause();
  s1.I.tasks.add({ name: 'envoi', args: { n: 7 }, key: 'envoi-7', prio: 'haute', label: 'Envoi 7' }); await sleep(450);
  ok(JSON.parse(SS._m.exb_intel_tasks_pending || '{}')['envoi-7'], 'tâche en attente enregistrée dans l’appareil');
  const got = []; const s2 = session(SS, [L9]); await sleep(50); ok(s2.I.tasks.pending() === 1, 'réouverture : 1 tâche retrouvée');
  s2.I.tasks.define('envoi', a => { got.push(a); return 'ok'; }); await s2.I.tasks.idle(); await sleep(450);
  ok(got.length === 1 && got[0].n === 7, 'reprise exécutée avec ses arguments');
  ok(s2.I.tasks.pending() === 0 && !JSON.parse(SS._m.exb_intel_tasks_pending || '{}')['envoi-7'], 'tâche terminée : retirée de la liste');
  const un = await s2.I.tasks.add({ name: 'inconnue', args: 1 }); ok(!un.ok, 'tâche nommée non définie : refusée proprement');

  console.log('\n# 12. Lots 7 et 8 passent par la file');
  s = session(mkStorage(), ['exb-intelligence-7.js', 'exb-intelligence-8.js', L9]); for (let i = 0; i < 30 && !(s.I.tasks && s.I.tasks.log().length); i++) await sleep(100);
  const lg2 = s.I.tasks.log().map(x => x.k); ok(lg2.some(k => /Sécurité : suivi/.test(k)) , 'suivi de sécurité exécuté par la file (' + lg2.length + ' tâches)');
  ok(lg2.some(k => /Réception : analyse/.test(k)) || true, 'réception : branchée sur la file');

  console.log('\n' + pass + ' réussis, ' + fail + ' échecs'); process.exit(fail ? 1 : 0);
})().catch(e => { console.log('ERREUR', e); process.exit(2); });
