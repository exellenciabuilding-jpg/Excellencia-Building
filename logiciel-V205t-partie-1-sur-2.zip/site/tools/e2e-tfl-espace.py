#!/usr/bin/env python3
"""V202 — Divisions : plus d'écran « Direction & pilotage » dans Ingénierie et architecture / Formation & académie ;
« Parcours TFL » a son propre côté (menu latéral, page dédiée, accès direct à chaque vue du module TFL).
Usage, depuis le dossier du site :  python3 tools/e2e-tfl-espace.py"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
DIRECTION=['exbV69Btn','exbV74Btn','exbPieBtn','exbPerBtn','inscBatch','qcm']
TILES="[...document.querySelectorAll('#exbHub .xg .c b')].map(b=>b.textContent.trim())"
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':1100,'height':900}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:160])); exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    a.evaluate("EXB_SHELL.setParcours('all')"); a.wait_for_timeout(200)
    # 1. les six écrans restent dans Direction & pilotage
    div=a.evaluate("(K)=>{const o={};EXB_SHELL.items().forEach(i=>{if(K.indexOf(i.key)>=0)o[i.key]=EXB_SHELL.divOf(i)});return o}",DIRECTION)
    ok(len(div)==6 and all(v=='dv_dir' for v in div.values()),'Intelligence BTP, Pièces écrites, Permis, Maintenance, Import inscriptions, QCM : division Direction & pilotage '+str(div))
    # 2. Ingénierie et architecture : aucune tuile Entreprise
    a.evaluate("EXB_SHELL.openDiv('dv_con')"); a.wait_for_timeout(300)
    heads=a.evaluate("[...document.querySelectorAll('#exbHub .xdg')].map(e=>e.textContent.trim())")
    t=a.evaluate(TILES)
    ok(not any('Entreprise' in h for h in heads),'Ingénierie et architecture : plus de groupe « Entreprise » '+str(heads))
    ok(not any(x in t for x in ['Intelligence BTP','Pièces écrites','Permis & autorisations','Maintenance / Facility']),'Ingénierie et architecture : aucun écran de Direction & pilotage')
    ok('Plan de maison' in t and 'Métré & devis' in t and 'Projets & chantiers' in t,'Ingénierie et architecture : ses propres modules sont toujours là')
    # 3. Direction & pilotage les retrouve
    a.evaluate("EXB_SHELL.openDiv('dv_dir')"); a.wait_for_timeout(300); t=a.evaluate(TILES)
    ok(all(x in t for x in ['Intelligence BTP','Pièces écrites','Permis & autorisations','Maintenance / Facility']),'Direction & pilotage : les 4 écrans y sont')
    # 4. Formation & académie : plus d'écran Direction, TFL à part
    a.evaluate("EXB_SHELL.openDiv('dv_for')"); a.wait_for_timeout(300); t=a.evaluate(TILES)
    ok('Import inscriptions' not in t and 'QCM logiciels' not in t,'Formation & académie : plus d\'Import inscriptions / QCM logiciels')
    ok(all(x in t for x in ['TFL','Frais TFL','Sujets','Encadreurs','Bibliothèque']),'Formation & académie : espace Parcours TFL détaillé '+str(t))
    # 5. menu latéral : « Parcours TFL » sous Formation & académie
    side=a.evaluate("[...document.querySelectorAll('#exbSide .xd,#exbSide .xs')].map(x=>x.textContent.replace(/[›]/g,'').trim())")
    i=[k for k,x in enumerate(side) if 'Formation & académie' in x]; j=[k for k,x in enumerate(side) if 'Parcours TFL' in x]
    ok(i and j and j[0]>i[0] and (len(i)==1) and all(not 'Parcours TFL' in side[k] for k in range(0,i[0])),'menu latéral : « Parcours TFL » juste sous Formation & académie '+str(side[-8:]))
    # 6. page dédiée
    ae.clear(); a.evaluate("document.querySelector('#exbSide .xs.sub[onclick*=\"openEspace\"]').click()"); a.wait_for_timeout(400)
    h=a.evaluate("document.querySelector('#exbHub h1').textContent"); t=a.evaluate(TILES)
    ok('Parcours TFL' in h and t[0]=='TFL' and len(t)>=8 and not ae,'page « Parcours TFL » : %d tuiles, sans erreur %s'%(len(t),ae[:1]))
    on=a.evaluate("document.querySelector('#exbSide .xs.sub.on')&&document.querySelector('#exbSide .xs.sub.on').textContent")
    ok(on and 'Parcours TFL' in on,'… entrée du menu surlignée')
    # 7. chaque vue du module s'ouvre
    bad=[]
    vues=a.evaluate("[...document.querySelectorAll('#exbHub .xg .c')].length")
    for n in range(vues):
        a.evaluate("EXB_SHELL.openEspace('tfl')"); a.wait_for_timeout(150); ae.clear()
        lab=a.evaluate("(n)=>document.querySelectorAll('#exbHub .xg .c')[n].querySelector('b').textContent",n)
        a.evaluate("(n)=>document.querySelectorAll('#exbHub .xg .c')[n].click()",n); a.wait_for_timeout(350)
        vis=a.evaluate("(()=>{const e=document.getElementById('tflSec');return !!e&&getComputedStyle(e).display!=='none'&&e.innerText.length>40})()")
        if not vis or ae: bad.append((lab,ae[:1]))
    ok(not bad,'les %d tuiles du Parcours TFL ouvrent le module sans erreur %s'%(vues,bad))
    # 8. une vue précise s'affiche vraiment
    a.evaluate("EXB_SHELL.goTfl('frais')"); a.wait_for_timeout(400)
    h3=a.evaluate("[...document.querySelectorAll('#tflBox h3')].map(h=>h.textContent).join('|')")
    ok('Frais TFL' in h3,'goTfl(frais) : la vue Frais TFL est affichée '+h3)
    a.evaluate("EXB_SHELL.goTfl('sujets')"); a.wait_for_timeout(400)
    h3=a.evaluate("[...document.querySelectorAll('#tflBox h3')].map(h=>h.textContent).join('|')")
    ok('sujets' in h3.lower(),'goTfl(sujets) : la vue Sujets est affichée '+h3)
    crumb=a.evaluate("document.getElementById('exbCrumb').innerText")
    ok('Parcours TFL' in crumb,'fil d\'Ariane : retour vers Parcours TFL '+crumb.replace('\n',' '))
    a.evaluate("document.querySelector('#exbCrumb button').click()"); a.wait_for_timeout(300)
    ok('Parcours TFL' in a.evaluate("document.querySelector('#exbHub h1').textContent"),'bouton « ← Parcours TFL » ramène à la page TFL')
    # 9. Retour / Avant
    a.evaluate("EXB_SHELL.openDiv('dv_inf')"); a.wait_for_timeout(150); a.evaluate("EXB_SHELL.back()"); a.wait_for_timeout(300)
    ok('Parcours TFL' in a.evaluate("document.querySelector('#exbHub h1').textContent"),'bouton Retour : revient à Parcours TFL')
    # 10. parcours : aucune fuite
    a.evaluate("EXB_SHELL.setParcours('btp')"); a.wait_for_timeout(200); a.evaluate("EXB_SHELL.openDiv('dv_for')"); a.wait_for_timeout(300)
    ok(a.evaluate(TILES)==[],'parcours Construction : division Formation sans écran de Direction '+str(a.evaluate(TILES)))
    a.evaluate("EXB_SHELL.setParcours('for')"); a.wait_for_timeout(200); a.evaluate("EXB_SHELL.openDiv('dv_con')"); a.wait_for_timeout(300)
    ok(a.evaluate(TILES)==[],'parcours Formation : division Construction sans écran de Direction '+str(a.evaluate(TILES)))
    a.evaluate("EXB_SHELL.setParcours('all')")
    ok(not ae,'aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('ÉCHECS :',fails); raise SystemExit(1 if fails else 0)
