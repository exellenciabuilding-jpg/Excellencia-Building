#!/usr/bin/env python3
"""Test navigateur du module PARCOURS (V122f). Usage : python3 tools/e2e-parcours.py
Tout le scénario tourne en UN appel (le banc recharge parfois la page au démarrage : on attend qu'elle soit stable)."""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m,d=''):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m+('' if c or not d else ' — '+str(d)))
    if not c: fails+=1
SCENARIO="""()=>{
  const out={};
  exbClients.push({id:'C1',full_name:'Marie Kabongo',phone:'0810000001'});save('exb_clients',exbClients);
  exbProjects.push({id:'P1',name:'Villa Gombe',client_id:'C1'},{id:'P2',name:'Tour Lemba'});save('exb_projects',exbProjects);
  exbQuotes.push({id:'Q1',project_id:'P1',client_id:'C1',status:'approuvé'});save('exb_quotes',exbQuotes);
  participants.push({id:'x1',participant_id:'PA1',name:'Jean',training:'AutoCAD'});save('exb_participants',participants);
  EXBLIEN.refresh();
  exbSessionStorage.setItem('exb_logged','1');document.getElementById('app').style.display='block';show('projets');EXBPARCOURS.render();
  const host=document.getElementById('exbParcoursPrj');out.panel=!!host;
  const s=host.querySelector('select');s.value='P1';s.dispatchEvent(new Event('change'));
  out.steps=host.querySelectorAll('.exbPcStep').length;
  out.next=host.querySelector('.exbPcNext').innerText;
  host.querySelector('.exbPcNext button').click();
  out.dch=!!document.getElementById('exbDch');
  show('participants');EXBPARCOURS.render();
  const h2=document.getElementById('exbParcoursPar');out.panelPar=!!h2;
  const s2=h2.querySelector('select');s2.value='PA1';s2.dispatchEvent(new Event('change'));
  out.stepsPar=h2.querySelectorAll('.exbPcStep').length;
  out.nextPar=h2.querySelector('.exbPcNext').innerText;
  /* fiches non rattachées + téléphone */
  exbQuotes.push({id:'Q7',no:'DEV-7',client_id:'C1'});save('exb_quotes',exbQuotes);
  show('projets');EXBPARCOURS.render();
  const hh=document.getElementById('exbParcoursPrj');const ss=hh.querySelector('select');ss.value='P1';ss.dispatchEvent(new Event('change'));
  out.orph=hh.querySelectorAll('[data-exbpc-att]').length;
  hh.querySelector('[data-exbpc-att]').click();
  out.orphAfter=hh.querySelectorAll('[data-exbpc-att]').length;
  out.q7=exbQuotes.find(x=>x.id==='Q7').project_id;
  out.overflow=hh.scrollWidth>hh.clientWidth+1;
  out.minBtn=Math.min(...[...hh.querySelectorAll('button')].map(b=>b.getBoundingClientRect().height).filter(h=>h>0));
  return out;}"""
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':375,'height':740},is_mobile=True,has_touch=True,device_scale_factor=2); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200])); pg.on('dialog',lambda d:d.accept())
    exbui_auto(pg)
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function('()=>window.EXBPARCOURS',timeout=15000)
    last=-1
    for _ in range(10):  # attendre que la page ne se recharge plus
        pg.wait_for_timeout(800)
        try: t=pg.evaluate("()=>performance.timeOrigin")
        except Exception: continue
        if t==last: break
        last=t
    ok(not errs,'chargement sans erreur JavaScript',errs[:2])
    ok(pg.evaluate("()=>!!(window.EXBPARCOURS&&EXBLIEN.parcours)"),'module Parcours chargé')
    ok(pg.evaluate("()=>EXBPARCOURS.registryIssues().length===0"),'registre sans référence cassée',pg.evaluate("()=>EXBPARCOURS.registryIssues()"))
    r=pg.evaluate(SCENARIO)
    ok(r['panel'],'panneau « Parcours du chantier » dans Projets')
    ok(r['steps']==11,'11 étapes affichées',r['steps'])
    ok('Contrat' in r['next'],'prochaine étape = Contrat',r['next'])
    ok(r['dch'],'« Continuer → » ouvre le module Documents de chantier')
    ok(r['panelPar'] and r['stepsPar']==6,'panneau « Parcours de l’apprenant » (6 étapes)',r['stepsPar'])
    ok('Paiement' in r['nextPar'],'apprenant : prochaine étape = Paiement',r['nextPar'])
    ok(r['orph']>=1 and r['orphAfter']==r['orph']-1 and r['q7']=='P1','fiche non rattachée proposée puis rattachée au clic (confirmée)',(r['orph'],r['orphAfter'],r['q7']))
    ok(not r['overflow'],'téléphone 375 px : aucun débordement horizontal du panneau')
    ok(r['minBtn']>=36,'téléphone : boutons assez grands pour le doigt (≥ 36 px)',r['minBtn'])
    # Calcul -> Plans : un export DXF du calcul propose « Envoyer vers Plans »
    def stable():
        last=-1
        for _ in range(12):
            pg.wait_for_timeout(800)
            try: t=pg.evaluate("()=>performance.timeOrigin")
            except Exception: continue
            if t==last: return
            last=t
    HOOK="""()=>{const cw=document.getElementById('exbCalcFrame').contentWindow;EXBCALC2PLANS.hook(cw);const u=cw.URL.createObjectURL(new cw.Blob(['0\\nSECTION\\n2\\nENTITIES\\n0\\nENDSEC\\n0\\nEOF\\n'],{type:'application/dxf'}));const a=cw.document.createElement('a');a.href=u;a.download='STR-POUTRE-PLAN.dxf';a.click()}"""
    for _ in range(4):
        stable()
        try:
            pg.evaluate("()=>{exbSessionStorage.setItem('exb_logged','1');document.getElementById('app').style.display='block';EXBCALC.open('poutre')}")
            pg.wait_for_function("()=>{const f=document.getElementById('exbCalcFrame');return f&&f.contentWindow&&f.contentWindow.document.readyState==='complete'}",timeout=15000); pg.wait_for_timeout(1500)
            pg.evaluate(HOOK); break
        except Exception as e: print('retry (rechargement du banc)',str(e)[:60])
    ok(pg.evaluate("()=>!!(EXBCALC2PLANS.last()&&EXBCALC2PLANS.last().name==='STR-POUTRE-PLAN.dxf')"),'export DXF du calcul détecté')
    try: pg.wait_for_selector('#exbCalcPlansBar',state='attached',timeout=10000)  # V184 : le bandeau est créé un instant après la détection de l'export
    except Exception: pass
    ok(pg.evaluate("()=>getComputedStyle(document.getElementById('exbCalcPlansBar')).display")!='none','bandeau « Envoyer vers Plans » affiché')
    pg.evaluate("()=>{const s=document.getElementById('exbCalcPlansSel');s.value='P1';document.getElementById('exbCalcPlansGo').click()}"); pg.wait_for_timeout(2500)
    n=pg.evaluate("()=>JSON.parse(exbStorage.getItem('exb_plan_files')||'[]').filter(x=>x.project==='P1'&&/STR-POUTRE/i.test(x.name)).length")
    ok(n==1,'le fichier arrive dans Plans, rattaché au chantier, sans re-sélection',n)
    ok(not errs,'aucune erreur JavaScript pendant le scénario',errs[:2])
    b.close()
print('Résultat :','échec' if fails else 'tout OK'); raise SystemExit(1 if fails else 0)
