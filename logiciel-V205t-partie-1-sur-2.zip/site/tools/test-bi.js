/* Tests de la BI Direction v2 (node tools/test-bi.js) — valeurs calculées à la main. */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const near = (a, b, m) => { assert(Math.abs(a - b) < 0.005, m + ' : ' + a + ' ≠ ' + b); n++; };

const store = {};
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
const box = { innerHTML: '', querySelectorAll: () => [] };
global.document = { readyState: 'loading', addEventListener() {}, getElementById: id => (id === 'bi_box' ? box : null), querySelector: () => null, createElement: () => ({}), body: { appendChild() {} } };
require('../exb-evm.js');
require('../exb-bi.js');
const B = window.EXBBI;
ok(B && B.version >= 2, 'EXBBI (v2 ou plus) chargé');

const T = '2026-11-15', R = { a: '2026-01-01', b: '2026-12-31', lab: 'Cette année' };
const invoices = [
  { id: 'i1', no: 'FAC-1', client: 'Kabila', project_id: 'p1', date: '2026-03-01', due: '2026-03-28', tva: 16, currency: 'USD', lines: [{ q: 2, pu: 500 }], payments: [{ amount: 100 }] },
  { id: 'i2', no: 'FAC-2', client: 'Autre', date: '2026-04-01', due: '2026-05-01', tva: 0, currency: 'USD', lines: [{ q: 1, pu: 300 }], payments: [{ amount: 300 }] },
  { id: 'i3', no: 'FAC-3', client: 'X', date: '2026-04-02', tva: 0, currency: 'FC', lines: [{ q: 1, pu: 2800000 }], payments: [], annule: true }];
const ledger = [
  { date: '2026-03-05', amount: 100, currency: 'USD', invoice_id: 'i1', source: 'facture' },
  { date: '2026-04-02', amount: 300, currency: 'USD', invoice_id: 'i2', source: 'facture' },
  { date: '2026-05-01', amount: 50, currency: 'USD', source: 'acompte' }];
const cash = [
  { id: 'c1', date: '2026-05-10', type: 'out', label: 'Ciment', amount: 150, currency: 'USD' },
  { id: 'c2', date: '2026-06-10', type: 'out', label: 'Sable', amount: 20000, currency: 'USD', project_id: 'p2' },
  { id: 'c3', date: '2026-06-11', type: 'out', label: 'Gravier FC', amount: 5000000, currency: 'FC', project_id: 'p2' }];

/* ---- v1 : indicateurs financiers ---- */
const c = B.compute({ invoices, ledger, cash }, { range: R, today: T });
const u = c.kpi.USD;
near(u.facture, 1460, 'facturé = 1160 + 300 (facture FC annulée exclue)');
near(u.encaisse, 450, 'encaissé = 100 + 300 + 50');
near(u.depenses, 20150, 'dépenses USD = 150 + 20 000');
near(u.resultat, 450 - 20150, 'résultat = encaissé − dépenses');
near(u.creances, 1060, 'créances = 1160 − 100');
near(u.echu, 1060, 'échues : FAC-1 échéance dépassée');
ok(!c.kpi.CDF || c.kpi.CDF.facture === 0, 'facture FC annulée non comptée');
ok(c.rapprochement.ok, 'rapprochement cohérent');

/* ---- v2 : projets ---- */
const projects = [
  { id: 'p1', name: 'Villa Kabila', client: 'Kabila' },
  { id: 'p2', name: '<img src=x onerror=alert(1)>', budget: 50000, progress: 50 },
  { id: 'p3', name: 'Sans budget' }];
const gantt = [{ project_id: 'p1', date: '2026-10-05', tasks: [{ start: 1, dur: 2, pct: 100, pred: '' }, { start: 3, dur: 2, pct: 50, pred: '1' }] }];
const budgets = [{ project_id: 'p1', postes: [{ label: 'Gros œuvre', b: 100000, r: 80000 }] }];
const src = { invoices, ledger, cash, projects, gantt, budgets, th: [] };
const P = B.computeProjets(src, { today: '2026-10-26' });
ok(P.dispo && P.rows.length === 3, '3 projets analysés');
const by = id => P.rows.filter(a => a.id === id)[0];
eq([by('p1').bac, by('p1').ac, by('p1').progress, by('p1').planned], [100000, 80000, 75, 75], 'p1 : budget, coût réel, avancement et planifié');
near(by('p1').cpi, 0.94, 'p1 : CPI = 75 000 / 80 000 (arrondi 0,94)');
eq(by('p1').status, 'orange', 'p1 : à surveiller (CPI < 0,95 ; impayé échu)');
ok(by('p1').alerts.some(a => a.code === 'IMPAYES'), 'p1 : impayé échu de FAC-1 remonté');
eq([by('p2').bac, by('p2').ac, by('p2').ev], [50000, 20000, 25000], 'p2 : budget saisi, coût réel USD seulement, valeur acquise');
near(by('p2').cpi, 1.25, 'p2 : CPI 1,25');
eq(by('p2').status, 'vert', 'p2 : sous contrôle');
eq(P.horsUsd, 1, 'dépense en FC non convertie : comptée à part');
eq(by('p3').status, 'gris', 'p3 : sans budget → données insuffisantes (aucun indice inventé)');
eq(B.computeProjets(src, { today: '2026-10-26', pid: 'p1' }).rows.length, 1, 'filtre projet');
eq(B.computeProjets(src, { today: '2026-10-26', evm: {} }).dispo, false, 'sans moteur EVM : indisponible, pas d’erreur');
ok(P.tot && P.tot.n === 3 && P.tot.actifs === 3, 'consolidation : 3 projets en cours');

/* ---- v2 : alertes de direction ---- */
const A = B.alertes(c, P, { suspects: 1 });
ok(A.length >= 4, 'alertes : résultat négatif, créances échues, doublons, projet');
eq(A[0].sev, 'high', 'les alertes graves passent en premier');
ok(A.some(a => a.src === 'Finance' && /négatif/.test(a.msg)), 'résultat de trésorerie négatif signalé');
ok(A.some(a => a.src === 'Finance' && /échues/.test(a.msg) && a.sev === 'high'), 'créances échues ≥ 50 % → grave');
ok(A.some(a => a.src === 'Projet' && a.pid === 'p1'), 'projet à surveiller remonté');
ok(!A.some(a => a.pid === 'p2' || a.pid === 'p3'), 'projets sous contrôle / sans données : pas d’alerte');
eq(B.alertes({ kpi: { USD: { resultat: 10, echu: 0, creances: 0 } }, rapprochement: { ok: true } }, { dispo: true, rows: [] }, {}).length, 0, 'aucun signal → aucune alerte');

/* ---- rendu : pas d’exception, HTML échappé ---- */
store.exb_invoices = JSON.stringify(invoices); store.exb_cash = JSON.stringify(cash); store.exb_projects = JSON.stringify(projects);
store.exb_gantt = JSON.stringify(gantt); store.exb_budgets = JSON.stringify(budgets);
B.render();
ok(box.innerHTML.length > 500 && !/Erreur/.test(box.innerHTML), 'rendu non vide');
ok(box.innerHTML.includes('Projets : budget, avancement et écarts'), 'section projets affichée');
ok(box.innerHTML.includes('Alertes de direction'), 'bloc alertes affiché');
ok(!box.innerHTML.includes('<img src=x'), 'nom de projet échappé (pas d’injection HTML)');
ok(box.innerHTML.includes('&lt;img'), 'nom de projet affiché en texte');
ok(B.definitions.some(d => d.id === 'cpi') && B.definitions.some(d => d.id === 'resultat'), 'dictionnaire : finance + projets');


/* ---- V186 : dictionnaire complet + statut de fiabilité ---- */
ok(B.definitions.every(d => d.source && d.frequence && d.responsable && d.validation), 'dictionnaire : source, fréquence, responsable et règle de validation pour chaque indicateur');
const F = B.fiabilite;
const okInv = [{ id: 'i1', no: 'F1', date: '2026-01-10', due: '2026-02-10', currency: 'USD', lines: [{ q: 1, pu: 100 }], tva: 0, payments: [{ amount: 100 }] }];
ok(F('facture', { last: { rapprochement: { ok: true } }, src: { invoices: okInv, cash: [], ledger: [] } }).s === 'ok', 'facturé : vérifié quand le rapprochement est cohérent');
ok(F('facture', { last: { rapprochement: { ok: false } }, src: { invoices: okInv, cash: [], ledger: [] } }).s === 'ko', 'facturé : non fiable si factures/paiements incohérents');
ok(F('encaisse', { last: { rapprochement: { ok: true } }, src: { invoices: okInv, cash: [], ledger: [], suspects: 2 } }).s === 'warn', 'encaissé : à vérifier si doublons suspects');
ok(F('facture', { last: { rapprochement: { ok: true } }, src: { invoices: [{ id: 'x', lines: [], payments: [] }], cash: [], ledger: [] } }).s === 'warn', 'facturé : à vérifier si facture sans date');
ok(F('echu', { last: { rapprochement: { ok: true } }, src: { invoices: [{ id: 'x', date: '2026-01-01', lines: [], payments: [] }], cash: [], ledger: [] } }).s === 'warn', 'échu : à vérifier si facture sans échéance');
ok(F('facture', { last: {}, src: { invoices: [], cash: [], ledger: [] } }).s === 'na', 'sans donnée : « aucune donnée » (jamais « vérifié »)');
ok(F('dettes', { src: { po: [] } }).s === 'na' && F('dettes', { src: { po: [{ id: 'a', lines: [] }] } }).s === 'warn', 'dettes : aucune donnée / bon incomplet');
ok(F('cpi', { pj: { rows: [{ bac: 0, progress: 0.2, planned: 0.3 }] } }).s === 'ko', 'CPI : non fiable si projet sans budget');
ok(F('spi', { pj: { rows: [{ bac: 100, progress: 0.2, planned: null }] } }).s === 'warn', 'SPI : à vérifier si pas de planning');
ok(F('cpi', { pj: { rows: [{ bac: 100, progress: 0.2, planned: 0.3 }] } }).s === 'ok', 'CPI : vérifié quand budget et avancement renseignés');
ok(/Fiabilité actuelle/.test(box.innerHTML) && /bi-fiab/.test(box.innerHTML), 'rendu : pastille de fiabilité et dictionnaire en tableau');

console.log('BI v2 : ' + n + ' contrôles OK');
