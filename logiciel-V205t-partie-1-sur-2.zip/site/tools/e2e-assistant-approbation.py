# Test navigateur (faux Supabase en mémoire) : assistant — importer + approuver, veille automatique, niveaux d'autorisation.
# Depuis la racine : python3 site/tools/e2e-assistant-approbation.py
import threading, http.server, socketserver, functools, json, re, sys
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
import os
SITE=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))  # dossier site/
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=SITE)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c,info=''):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n+((' -> '+str(info)) if (info and not c) else ''))

# faux serveur Supabase en mémoire
DB={'inscriptions':[
  {'id':'i1','created_at':'2026-11-06T08:00:00Z','name':'Jean Kasongo','phone':'0812345678','email':'jean@ex.com','training':'AutoCAD','note':'','matricule':None,'imported':False},
  {'id':'i2','created_at':'2026-11-06T08:05:00Z','name':'Marie Ilunga','phone':'0899111222','email':'marie@ex.com','training':'Revit','note':'','matricule':None,'imported':False}],
 'formulaires':[
  {'id':'f1','created_at':'2026-11-06T08:10:00Z','kind':'formateur','data':{'name':'Paul Mbuyi','phone':'0977000111','email':'paul@ex.com','specialty':'Robot'},'imported':False},
  {'id':'f2','created_at':'2026-11-06T08:11:00Z','kind':'client','data':{'full_name':'Societe Batir','phone':'0855000222'},'imported':False}]}
patches=[]
def handler(route):
    req=route.request; u=req.url; m=req.method
    def js(o,s=200): route.fulfill(status=s,content_type='application/json',headers={'access-control-allow-origin':'*'},body=json.dumps(o))
    if m=='OPTIONS': return route.fulfill(status=204,headers={'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'})
    if '/functions/v1/assistant' in u: return js({'error':'indisponible (test)'},500)
    if '/rpc/ma_licence' in u: return js({'admin':True,'statut':'actif'})
    if '/rpc/demandes_logiciel_liste' in u or '/rpc/demandes_projet_liste' in u: return js([])
    if '/auth/v1/user' in u: return js({'id':'u1'})
    mt=re.search(r'/rest/v1/(inscriptions|formulaires)\?(.*)',u)
    if mt:
        tb=mt.group(1)
        if m=='GET': return js([r for r in DB[tb] if not r['imported']] if False else DB[tb])
        if m=='PATCH':
            idv=re.search(r'id=eq\.([^&]+)',u).group(1); patches.append((tb,idv))
            for r in DB[tb]:
                if r['id']==idv: r['imported']=True
            return route.fulfill(status=204,headers={'access-control-allow-origin':'*'})
    return js([])
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':800}); errs=[]
    pg.on('pageerror',lambda e:(errs.append(str(e)[:300]),print('PAGEERR',str(e)[:300],flush=True)))
    pg.on('console',lambda m:print('CONSOLE',m.type,m.text[:200],flush=True) if m.type in ('error','warning') else None)
    dialogs=[]
    pg.on('dialog',lambda d:(dialogs.append(d.message[:80]),d.accept('TestLocal#2026' if d.type=='prompt' else None)))
    exbui_auto(pg)
    pg.route('**/*.supabase.co/**',handler)
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},150)")
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function("window.EXB_INBOX&&window.exbLocalAI&&window.exbSb",timeout=25000)
    pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(2500)
    pg.evaluate("exbSb.set({access_token:'tok',refresh_token:'r',exp:Date.now()+3600000})")
    pg.evaluate("EXB_INBOX.reload()"); pg.wait_for_timeout(1200)
    chk('5 demandes visibles',pg.evaluate("EXB_INBOX.pending()")==4,pg.evaluate("EXB_INBOX.pending()"))
    # 1. assistant local : phrase -> action
    R=pg.evaluate("exbLocalAI('importe et approuve les demandes')")
    types=[a['type'] for a in R['actions']]
    chk('local : « importe et approuve » -> actions importapprove',types and all(t=='importapprove' for t in types),R)
    chk('local : couvre insc, form, cli',set(a['target'] for a in R['actions'])>={'insc','form','cli'},R)
    R2=pg.evaluate("exbLocalAI('approuve Jean Kasongo')")
    chk('local : « approuve Jean » sans fiche en attente -> message clair',R2['actions']==[] and 'Aucun dossier' in R2['answer'],R2)
    # 2. exécution via le panneau : mode « Demander » (défaut) -> carte + confirmation
    pg.evaluate("exbAssistant()"); pg.wait_for_selector('#exbAIq')
    pg.fill('#exbAIq','importe et approuve les demandes apprenants'); pg.click('#exbAIgo'); pg.wait_for_timeout(1500)
    pg.wait_for_selector('#exbAIlog button:has-text("Appliquer")',timeout=5000)
    chk('carte « Appliquer » affichée (niveau Demander)',True)
    print('clic Appliquer',flush=True); pg.click('#exbAIlog button:has-text("Appliquer")',timeout=8000); print('clic fait',dialogs,flush=True); pg.wait_for_timeout(2500); print('apres attente',dialogs,flush=True)
    P=pg.evaluate("JSON.parse(exbStorage.getItem('exb_participants')||'[]')")
    chk('2 apprenants créés',len(P)==2,len(P))
    chk('les 2 apprenants sont APPROUVÉS avec matricule',all(x.get('approval_status')=='APPROUVE' and x.get('matricule') for x in P),[(x.get('name'),x.get('approval_status'),x.get('matricule')) for x in P])
    chk('demandes marquées importées sur le serveur',set(t for t in patches)>={('inscriptions','i1'),('inscriptions','i2')},patches)
    chk('un journal « validé » est écrit',pg.evaluate("JSON.parse(exbStorage.getItem('exb_ai_log')||'[]').some(x=>x.a==='importapprove')"))
    # 3. veille automatique : réglage + nouvelle demande
    pg.evaluate("exbStorage.setItem('exb_ai_perm',JSON.stringify({on:true,float:true,online:true,watch:true,lv:{importapprove:'auto'}}))")
    DB['inscriptions'].append({'id':'i3','created_at':'2026-11-06T09:00:00Z','name':'Alice Tshala','phone':'0820001111','email':'a@ex.com','training':'Lumion','note':'','matricule':None,'imported':False})
    pg.evaluate("EXB_INBOX.reload()"); pg.wait_for_timeout(4500)
    P=pg.evaluate("JSON.parse(exbStorage.getItem('exb_participants')||'[]')")
    al=[x for x in P if x['name']=='Alice Tshala']
    chk('veille auto : nouvelle demande importée ET approuvée sans clic',al and al[0].get('approval_status')=='APPROUVE' and al[0].get('matricule'),al)
    T=pg.evaluate("JSON.parse(exbStorage.getItem('exb_trainers')||'[]')")
    chk('veille auto : formateur importé et approuvé',any(x['name']=='Paul Mbuyi' and x.get('approval_status')=='APPROUVE' and x.get('matricule') for x in T),T)
    C=pg.evaluate("JSON.parse(exbStorage.getItem('exb_clients')||'[]')")
    chk('veille auto : client importé',any('Batir' in (x.get('full_name') or '') for x in C))
    # 4. niveau Interdit respecté
    pg.evaluate("exbStorage.setItem('exb_ai_perm',JSON.stringify({on:true,float:true,online:true,watch:true,lv:{importapprove:'forbid'}}))")
    DB['inscriptions'].append({'id':'i4','created_at':'2026-11-06T10:00:00Z','name':'Zoe Banza','phone':'0830002222','email':'z@ex.com','training':'Revit','note':'','matricule':None,'imported':False})
    pg.evaluate("EXB_INBOX.reload()"); pg.wait_for_timeout(3500)
    P=pg.evaluate("JSON.parse(exbStorage.getItem('exb_participants')||'[]')")
    chk('Interdit : rien n\'est importé automatiquement',not any(x['name']=='Zoe Banza' for x in P))
    # 5. approuver un dossier en attente par son nom
    pg.evaluate("exbStorage.setItem('exb_ai_perm',JSON.stringify({on:true,float:true,online:true,watch:false,lv:{}}))")
    pg.evaluate("""(()=>{const a=JSON.parse(exbStorage.getItem('exb_participants')||'[]');a.push({participant_id:'EXB-P-900',name:'Test Pending',phone:'0811',training:'X',approval_status:'EN ATTENTE',created_at:new Date().toISOString()});exbStorage.setItem('exb_participants',JSON.stringify(a));})()""")
    pg.reload(); pg.wait_for_function("window.exbLocalAI",timeout=25000); pg.wait_for_timeout(1500)
    if pg.is_visible('#li_user'):
        pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(2500)
    R3=pg.evaluate("exbLocalAI('approuve Test Pending')")
    chk('local : « approuve Test Pending » -> action approve',R3['actions'] and R3['actions'][0]['type']=='approve' and R3['actions'][0]['target']=='insc',R3)
    pg.evaluate("exbAssistant()"); pg.wait_for_selector('#exbAIq'); pg.fill('#exbAIq','approuve Test Pending'); pg.click('#exbAIgo'); pg.wait_for_timeout(1200)
    pg.click('#exbAIlog button:has-text("Appliquer")',timeout=8000); pg.wait_for_timeout(1500)
    P=pg.evaluate("JSON.parse(exbStorage.getItem('exb_participants')||'[]')")
    tp=[x for x in P if x['name']=='Test Pending']
    chk('action « approuver » exécutée : matricule attribué',tp and tp[0].get('approval_status')=='APPROUVE' and tp[0].get('matricule'),tp)
    print('erreurs JS :',errs[:5]); print('boites de dialogue :',dialogs)
    b.close()
print(f'{ok}/{tot}'); sys.exit(0 if ok==tot else 1)
