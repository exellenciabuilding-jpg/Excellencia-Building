/* Tests V178 : en-tête + QR de vérification sur tous les écrans qui imprimaient sans (node tools/test-qr-partout-v178.js). */
const assert = require('assert'); let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const store = {}; global.window = global; global.document = undefined;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.EXBId = { get: () => ({ name: 'Excellencia Building', tagline: 'Slogan', phone: '+243 1', email: 'x@y.cd', address: 'Kinshasa', legal: 'RCCM test', logo: 'icon-192.png' }) };
require('../exb-qr.js'); require('../exb-rapport-marque.js');
const R = window.EXBRapport;
ok(typeof R.stamp === 'function' && typeof R.printDoc === 'function' && typeof R.screen === 'function' && typeof R.qr === 'function' && typeof R.qrData === 'function', 'API V178 exposée');
/* 1) document sans <body> (Gantt, QCM, suivi des paiements) : en-tête en tête, QR en pied */
const g = '<!doctype html><meta charset="utf-8"><title>Planning</title><style>body{x:y}</style><h1>Planning</h1><table><tr><td>t</td></tr></table>';
const s1 = R.stamp('Planning de Gantt', g, { header: true, prefix: 'GAN' });
ok(s1.indexOf('data-exb-habillage') > s1.indexOf('</style>') && s1.indexOf('data-exb-habillage') < s1.indexOf('<h1>'), 'en-tête inséré avant le contenu, après le <style>');
ok(s1.indexOf('<!doctype html>') === 0, 'doctype conservé en tête (pas de mode quirks)');
ok(/data-exb-qr="GAN-\d{8}-[0-9A-F]{4}"/.test(s1) && /<svg/.test(s1), 'QR (repli hors ligne) + référence GAN-…');
ok(s1.indexOf('data-exb-qr') > s1.indexOf('</table>'), 'QR en pied de document');
ok(s1.includes('Excellencia Building') && s1.includes('+243 1'), 'en-tête : nom + contact');
/* 2) pas de doublon */
ok(R.stamp('Planning', s1, { header: true }) === s1, 'un document déjà tamponné n’est pas retouché');
/* 3) document avec <body> : QR avant </body> ; sans header si non demandé */
const b = '<html><head><title>x</title></head><body><div class="hd">Mon en-tête</div><p>texte</p></body></html>';
const s2 = R.stamp('Rapport', b, { prefix: 'PIL' });
ok(s2.indexOf('data-exb-qr') < s2.indexOf('</body>') && s2.indexOf('data-exb-qr') > s2.indexOf('texte'), 'QR juste avant </body>');
ok(s2.indexOf('data-exb-habillage') < 0, 'pas d’en-tête ajouté quand l’écran a déjà le sien');
/* 4) fragment (paie V81 : C.printDoc) */
const s3 = R.stamp('Bulletin Jean 2026-10', '<h1>Bulletin</h1><table></table>', { prefix: 'BUL' });
ok(/BUL-\d{8}/.test(s3) && s3.indexOf('data-exb-qr') > s3.indexOf('</table>'), 'fragment : QR ajouté à la fin');
/* 5) overlay (pastille fixe) */
ok(/position:fixed;right:6mm;bottom:6mm/.test(R.stamp('Plan', '<body><img src="x"></body>', { overlay: true })), 'option overlay : pastille fixe');
/* 6) l’empreinte suit le contenu */
const ref = (h) => (h.match(/data-exb-qr="([^"]+)"/) || [])[1];
ok(ref(R.stamp('T', '<p>a</p>', { prefix: 'ZZ' })) !== ref(R.stamp('T', '<p>b</p>', { prefix: 'ZZ' })), 'contenu différent → référence différente');
ok(ref(R.stamp('T', '<p>a</p>', { prefix: 'ZZ' })) === ref(R.stamp('T', '<p>a</p>', { prefix: 'ZZ' })), 'même contenu → même référence');
/* 7) échappement : un titre piégé ne s’exécute pas */
const s4 = R.stamp('<img src=x onerror=alert(1)>', '<p>a</p>', {});
ok(!s4.includes('<img src=x onerror') && s4.includes('&lt;img src=x'), 'titre piégé échappé');
/* 8) qr() et qrData() */
ok(/^<span data-exb-qr="[^"]+">/.test(R.qr('Feuille A', { prefix: 'PLN' }, 'abc', 64)), 'qr() : bloc intégrable dans un cartouche');
const qd = R.qrData('Devis', { prefix: 'DEV' }, 'abc'); ok(qd && /^data:image\/svg\+xml;base64,/.test(qd.img) && /^DEV-/.test(qd.ref), 'qrData() : image base64 + référence');
/* 9) moteur documentaire : QR accepté seulement s’il est une image base64 */
const C = require('../docengine/core.js'); require('../docengine/templates.js'); require('../docengine/templates-modules.js');
const data = { client_nom: 'ACME', objet: 'Test', lignes: [{ designation: 'A', quantite: 1, prix: 10 }] };
const h1 = C.render('devis', data, { options: { qr_img: qd.img, qr_ref: qd.ref, qr_host: 'verification.html' }, number: 'DEV-1', lenient: true }).html;
ok(h1.includes('class="doc-qr"') && h1.includes('Scanner pour vérifier') && h1.includes(qd.ref), 'devis : bloc QR rendu par le moteur');
const hBad = C.render('devis', data, { options: { qr_img: 'javascript:alert(1)', qr_ref: '<b>x</b>' }, number: 'DEV-1', lenient: true }).html;
ok(!hBad.includes('doc-qr"') && !hBad.includes('javascript:alert'), 'image non base64 refusée');
const hRef = C.render('devis', data, { options: { qr_img: qd.img, qr_ref: '<script>x</script>REF-1' }, number: 'DEV-1', lenient: true }).html;
ok(!hRef.includes('<script>x') && hRef.includes('REF-1'), 'référence filtrée');
ok(!C.render('devis', data, { number: 'DEV-1', lenient: true }).html.includes('doc-qr'), 'sans option : aucun QR (comportement inchangé)');
/* les 18 modèles du centre documentaire (hors modèles « modules » masqués) portent le QR */
const ids = C.list().filter(t => !t.hidden).map(t => t.id); ok(ids.length === 18, '18 modèles visibles (' + ids.length + ')');
let withQr = 0; for (const id of ids) { const h = C.render(id, {}, { options: { qr_img: qd.img, qr_ref: qd.ref }, number: 'X-1', lenient: true }).html; assert(h.includes('doc-qr'), id + ' : QR absent'); withQr++; } ok(withQr === 18, 'QR sur les 18 modèles');
const hm = C.render('doc-module', { titre: 'x' }, { options: { qr_img: qd.img, qr_ref: qd.ref }, number: 'X-1', lenient: true }).html; ok(!hm.includes('class="doc-qr"'), 'modèles « modules » : pas de second QR');
/* 10) serveur : options QR filtrées */
console.log('test-qr-partout-v178 : ' + n + ' contrôles OK');
process.exit(0);
