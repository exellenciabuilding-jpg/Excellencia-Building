#!/usr/bin/env python3
"""Test navigateur de l'identifiant stable unique (V186) : python3 tools/e2e-ids.py (depuis le dossier du site).
Vérifie dans le vrai logiciel : écriture par un module (exbSave), balayage des données existantes, audit, adaptateurs du noyau,
reconstruction d'une fiche par un module, copie de fiche, absence d'erreur JavaScript."""
import http.server, threading, socketserver, os, functools, sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:160])); exbui_auto(pg)
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(2500)
    # attendre l'installation de la couche (après les adaptateurs) ; le balayage différé de 4 s est neutralisé en le rappelant à la main
    pg.wait_for_function("()=>window.EXBIds&&exbStorage.__ids&&exbStorage.__coreAd",timeout=15000)
    ok(pg.evaluate("()=>!!(EXBCore.ids&&EXBCore.idOf)"),'EXBCore.ids et EXBCore.idOf exposés')
    pg.wait_for_timeout(5000)  # laisse passer le balayage automatique de démarrage (sur stockage vide)
    # 1) données « anciennes » : écrites sans passer par la couche (comme avant V186)
    pg.evaluate("""()=>{const raw=(k,a)=>localStorage.setItem(EXB_STORAGE_PREFIX+k,JSON.stringify(a));
      raw('exb_participants',[{participant_id:'P-001',name:'Aline'},{participant_id:'P-002',name:'Jean'}]);
      raw('exb_cash',[{no:'C-1',amount:10},{label:'sans ref',amount:3},{label:'sans ref',amount:3}]);
      raw('exb_quotes',[{id:'DEV-1',client:'X'}]);
      raw('exb_audit',[{t:1,a:'x'}]); raw('exb_theme','"bleu"');}""")
    a0=pg.evaluate("()=>EXBCore.ids.audit()")
    ok(a0['totals']['missing']==5 and not a0['ok'],'audit AVANT balayage : 5 fiches sans identifiant détectées (%s)'%a0['totals'])
    ok(any(x['key']=='exb_audit' for x in a0['ignored']),'journal exb_audit exclu du périmètre')
    s=pg.evaluate("()=>EXBCore.ids.sweep()")
    ok(s['assigned']==5 and not s['refused'],'balayage : 5 identifiants attribués, aucun refus (%s)'%s)
    a1=pg.evaluate("()=>EXBCore.ids.audit()")
    ok(a1['ok'] and a1['totals']['missing']==0 and a1['totals']['duplicates']==0,'audit APRÈS balayage : aucune fiche sans identifiant, aucun doublon')
    cash=pg.evaluate("()=>JSON.parse(exbStorage.getItem('exb_cash'))")
    ok(len({c['uid'] for c in cash})==3,'3 fiches de caisse : 3 identifiants distincts')
    ok(pg.evaluate("()=>JSON.parse(exbStorage.getItem('exb_quotes'))[0].uid")is None,'fiche qui a déjà un « id » : aucun « uid » ajouté')
    # 2) balayage rejoué : rien ne change
    ok(pg.evaluate("()=>EXBCore.ids.sweep().assigned")==0,'balayage rejoué : 0 attribution (idempotent)')
    # 3) écriture par un module (chemin réel exbSave) : nouvelle fiche
    uid_c1=[c for c in cash if c.get('no')=='C-1'][0]['uid']
    pg.evaluate("""()=>{const l=JSON.parse(exbStorage.getItem('exb_cash'));l.push({no:'C-2',amount:99});exbSave('exb_cash',l)}""")
    cash=pg.evaluate("()=>JSON.parse(exbStorage.getItem('exb_cash'))")
    ok(len(cash)==4 and all(c.get('uid') for c in cash),'exbSave : la nouvelle fiche reçoit un identifiant à l\'écriture')
    # 4) un module reconstruit la fiche C-1 sans son uid
    pg.evaluate("""()=>{const l=JSON.parse(exbStorage.getItem('exb_cash'));const i=l.findIndex(c=>c.no==='C-1');l[i]={no:'C-1',amount:55};exbSave('exb_cash',l)}""")
    cash=pg.evaluate("()=>JSON.parse(exbStorage.getItem('exb_cash'))")
    ok([c for c in cash if c.get('no')=='C-1'][0]['uid']==uid_c1,'fiche reconstruite par un module : même identifiant qu\'avant')
    # 5) copie de fiche
    pg.evaluate("""()=>{const l=JSON.parse(exbStorage.getItem('exb_cash'));l.push({...l[0],label:'copie'});exbSave('exb_cash',l)}""")
    a2=pg.evaluate("()=>EXBCore.ids.audit()")
    ok(a2['ok'],'fiche recopiée : aucun doublon d\'identifiant')
    # 6) adaptateurs du noyau : l'ajout de uid ne doit pas créer de faux « supprimé + créé »
    pg.wait_for_timeout(800)
    ev=pg.evaluate("()=>EXBCore.bus.journal().filter(e=>/^caisse\\./.test(e.name)).map(e=>e.name)")
    ok(not any(n=='caisse.supprime' for n in ev),'noyau : aucune fausse suppression de caisse après ajout des identifiants (%s)'%ev)
    # 7) santé du noyau
    h=pg.evaluate("()=>EXBCore.health()")
    ok(h.get('ids',{}).get('missing')==0,'EXBCore.health() contient le bilan des identifiants (%s)'%h.get('ids'))
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2]))
    b.close()
print('\nRésultat :',('%d échec(s)'%fails) if fails else 'tout passe'); sys.exit(1 if fails else 0)
