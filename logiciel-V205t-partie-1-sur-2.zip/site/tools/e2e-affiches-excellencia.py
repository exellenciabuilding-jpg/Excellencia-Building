# Test navigateur V186g : éditeur Word + raccourcis sur les Affiches Excellencia (onglet 1, à côté du Studio libre).
# Lancer :  python3 tools/e2e-affiches-excellencia.py   (Chromium + Playwright)
import http.server, threading, functools, os
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8897), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
def boot(pg):
    pg.goto('http://127.0.0.1:8897/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("show('affiches')"); pg.wait_for_timeout(1500)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    boot(pg)
    ok(pg.evaluate("typeof EXBPR==='object'&&EXBPR.fields().length>40"), 'module EXBPR chargé, champs branchés')
    ok(pg.locator('#p_hero_white + .exbpr button[data-w]').count() == 1 and pg.locator('#sp_title + .exbpr button[data-w]').count() == 1, 'bouton « ✍️ Word » à côté des champs des deux affiches')
    old = pg.evaluate("document.getElementById('pc_hero_white').textContent")
    pg.click('#p_hero_white + .exbpr button[data-w]'); pg.wait_for_timeout(900)
    ok(pg.locator('#exbawModal #exbEdSheet').count() == 1, 'l’éditeur Word s’ouvre sur le champ')
    pg.click('#exbEdSheet'); pg.keyboard.press('Control+A'); pg.keyboard.press('Control+B'); pg.keyboard.type('TITRE'); pg.keyboard.press('Control+B'); pg.keyboard.type(' test')
    pg.keyboard.press('Control+s'); pg.wait_for_timeout(600)
    ok(pg.locator('#exbawModal').count() == 0, 'Ctrl+S dans l’éditeur applique et ferme')
    ok(pg.evaluate("!!document.querySelector('#pc_hero_white .exbaw b')") and 'TITRE' in pg.evaluate("document.getElementById('pc_hero_white').textContent"), 'le texte mis en forme (gras) apparaît dans l’aperçu de l’affiche')
    ok(pg.evaluate("document.getElementById('p_hero_white').readOnly===true") and 'TITRE' in pg.evaluate("document.getElementById('p_hero_white').value"), 'le champ garde la version simple (lecture seule)')
    # une frappe dans un autre champ ne fait pas disparaître la mise en forme
    pg.fill('#p_srv1', 'Service modifié'); pg.evaluate('renderPoster()'); pg.wait_for_timeout(300)
    ok(pg.evaluate("!!document.querySelector('#pc_hero_white .exbaw b')") and 'Service modifié' in pg.evaluate("document.getElementById('pc_srv1').textContent"), 'la mise en forme reste après la modification d’un autre champ')
    # annuler / rétablir hors champ
    pg.evaluate("document.activeElement&&document.activeElement.blur()"); pg.keyboard.press('Control+z'); pg.wait_for_timeout(300)
    ok(pg.evaluate("!document.querySelector('#pc_hero_white .exbaw')"), 'après Ctrl+Z : aperçu revenu au texte simple')
    pg.keyboard.press('Control+y'); pg.wait_for_timeout(300)
    ok(pg.evaluate("!!document.querySelector('#pc_hero_white .exbaw b')"), 'Ctrl+Y rétablit la mise en forme')
    # persistance
    pg.keyboard.press('Control+s'); pg.wait_for_timeout(300)
    boot(pg)
    ok(pg.evaluate("!!document.querySelector('#pc_hero_white .exbaw b')"), 'après rechargement : le texte mis en forme est conservé')
    # double-clic sur l'aperçu
    pg.evaluate("document.getElementById('pc_quote').dispatchEvent(new MouseEvent('dblclick',{bubbles:true}))"); pg.wait_for_timeout(900)
    ok(pg.locator('#exbawModal #exbEdSheet').count() == 1, 'double-clic sur un texte de l’aperçu : ouvre l’éditeur Word')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    if pg.locator('#exbawModal').count(): pg.click('#exbawCancel'); pg.wait_for_timeout(300)
    # affiche logiciels
    pg.click('#sp_title + .exbpr button[data-w]'); pg.wait_for_timeout(900)
    pg.click('#exbEdSheet'); pg.keyboard.press('Control+A'); pg.keyboard.type('LOGICIELS TEST'); pg.click('#exbawOk'); pg.wait_for_timeout(500)
    ok(pg.evaluate("document.getElementById('spv_title').textContent.includes('LOGICIELS TEST')&&!!document.querySelector('#spv_title .exbaw')"), 'affiche « logiciels » : texte mis en forme dans l’aperçu')
    # Texte simple
    pg.click('#sp_title + .exbpr button[data-s]'); pg.wait_for_timeout(400)
    ok(pg.evaluate("!document.querySelector('#spv_title .exbaw')&&document.getElementById('sp_title').readOnly===false"), '« Texte simple » retire la mise en forme')
    # Studio libre non affecté
    pg.click('#exbsT2'); pg.wait_for_timeout(400)
    pg.evaluate("EXB_STUDIO.applyTemplate(EXB_STUDIO.templates()[10])"); pg.wait_for_timeout(300)
    n0 = pg.evaluate("EXB_STUDIO.state().els.length"); pg.keyboard.press('Control+a'); pg.keyboard.press('Delete'); pg.wait_for_timeout(200)
    ok(pg.evaluate("EXB_STUDIO.state().els.length") == 0 and n0 > 0, 'Studio libre : raccourcis toujours à part (Ctrl+A + Suppr)')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    ok(pg.evaluate("EXB_STUDIO.state().els.length") == n0, 'Studio libre : Ctrl+Z ne touche pas aux affiches Excellencia')
    ok(not errs, 'aucune erreur JavaScript' + (' : ' + errs[0] if errs else ''))
    b.close()
print('\n%s' % ('TOUT EST OK' if not fails else '%d ÉCHEC(S)' % len(fails)))
raise SystemExit(1 if fails else 0)
