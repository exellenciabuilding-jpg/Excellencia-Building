# Test navigateur V141r : la note de calcul (iframe « Calcul de structure ») est envoyée à l'équipe d'un chantier (serveur simulé) :
# bouton « Envoyer au chantier », choix du chantier (présélection par nom du projet), PDF réel dans le dossier du chantier, remplacement au nouvel indice,
# mise à jour automatique après « 📄 PDF ».
import json, os, threading, http.server, functools
from playwright.sync_api import sync_playwright
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8801),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
SITE='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
PARENT='''<!doctype html><meta charset=utf-8><body style="margin:0">
<script>
window.__calls=[];window.notify=(m,t)=>{};
window.exbSb={isIn:()=>true,api:async(p,o)=>{
 const rec={p,m:(o&&o.method)||"GET"};const body=o&&o.body;
 if(p.indexOf("/storage/v1/object/exb-chantier-docs/")===0&&rec.m==="POST"){rec.size=body.size;rec.type=body.type;window.__calls.push(rec);return {Key:"ok"}}
 if(p==="/storage/v1/object/exb-chantier-docs"&&rec.m==="DELETE"){rec.b=JSON.parse(body);window.__calls.push(rec);return []}
 if(p.indexOf("/rpc/chantier_liste")>0){return [{id:"%s",name:"Villa R+1 Limete",code:"CH-001"},{id:"bbbbbbbb-0000-0000-0000-000000000000",name:"Autre chantier",code:"CH-002"}]}
 if(p.indexOf("/rpc/chantier_doc_publier")>0){rec.b=JSON.parse(body);window.__calls.push(rec);return {ok:true,id:"x",ancien_fichier:window.__last&&window.__last!==rec.b.p_fichier?window.__last:null,_set:(window.__last=rec.b.p_fichier)}}
 window.__calls.push(rec);return null}};
</script><script src="/exb-chantier-docs.js"></script>
<iframe id="f" src="/calcul-structure/index.html" style="width:1200px;height:900px;border:0"></iframe>'''%SITE
res=[]
def check(n,c,i=''): res.append(bool(c)); print(('OK   ' if c else 'ÉCHEC'),n,i)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(accept_downloads=True,viewport={'width':1250,'height':950}); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('http://127.0.0.1:8801/__h.html',lambda r:r.fulfill(content_type='text/html',body=PARENT))
    pg.goto('http://127.0.0.1:8801/__h.html'); fr=pg.frame_locator('#f'); pg.wait_for_timeout(1500)
    fr.locator('button[data-mb="poutre"]').first.evaluate('e=>e.click()'); pg.wait_for_timeout(500)
    fr.locator('#go').click(); pg.wait_for_timeout(1500)
    fr.locator('#nb').click(); fr.locator('#exf_chgo').wait_for(timeout=8000)
    check('note : bouton « Envoyer au chantier » présent',fr.locator('#exf_chgo').count()==1)
    fr.locator('#exf_projet').fill('Villa R+1 Limete')
    fr.locator('#exf_chgo').click(); pg.wait_for_selector('#exbChDocs .chS',timeout=15000)
    boxes=pg.evaluate("[...document.querySelectorAll('#exbChDocs .chS')].map(x=>[x.value,x.checked])")
    check('chantier du même nom que le projet présélectionné, l’autre non',boxes==[[SITE,True],['bbbbbbbb-0000-0000-0000-000000000000',False]],str(boxes))
    pg.fill('#chNote','À appliquer dès demain'); pg.click('#chGo')
    pg.wait_for_function("window.__calls.some(c=>c.b&&c.b.p_genre)",timeout=120000)
    calls=pg.evaluate('window.__calls'); up=[c for c in calls if c['p'].startswith('/storage') and c['m']=='POST']; rp=[c for c in calls if c.get('b') and c['b'].get('p_genre')]
    check('PDF réel (> 5 Ko) rangé dans le dossier du chantier',len(up)==1 and up[0]['type']=='application/pdf' and up[0]['size']>5000 and ('/'+SITE+'/') in up[0]['p'] and up[0]['p'].endswith('/note-de-calcul.pdf'),str(up)[:200])
    r0=rp[0]['b']
    check('RPC : chantier, genre note, n° NCS-, message équipe',r0['p_site']==SITE and r0['p_genre']=='note' and r0['p_no'].startswith('NCS-') and r0['p_note']=='À appliquer dès demain' and r0['p_fichier'].startswith(SITE+'/'),str(r0)[:240])
    pg.wait_for_function("document.querySelector('#chSt').innerText.indexOf('Envoyé')>=0",timeout=10000)
    pg.evaluate("document.getElementById('exbChDocs').remove()")
    # nouvel indice : renvoi => même numéro, ancien fichier supprimé
    fr.locator('#exf_ind').fill('B'); fr.locator('#exf_ind').dispatch_event('input'); pg.wait_for_timeout(300)
    fr.locator('#exf_chgo').click(); pg.wait_for_selector('#exbChDocs .chS',timeout=15000)
    check('chantier déjà servi : annoncé « sera mis à jour »',pg.evaluate("document.getElementById('exbChDocs').innerText.indexOf('déjà envoyé')>=0"))
    pg.click('#chGo'); pg.wait_for_function("window.__calls.filter(c=>c.b&&c.b.p_genre).length>=2",timeout=120000)
    calls=pg.evaluate('window.__calls'); rp=[c for c in calls if c.get('b') and c['b'].get('p_genre')]; dl=[c for c in calls if c['m']=='DELETE']
    check('nouvel indice B : même numéro, ancien PDF supprimé',rp[1]['b']['p_no']==rp[0]['b']['p_no'] and rp[1]['b']['p_indice']=='B' and len(dl)==1 and dl[0]['b']['prefixes'][0]==rp[0]['b']['p_fichier'],str(dl)[:200])
    pg.evaluate("document.getElementById('exbChDocs').remove()")
    # « 📄 PDF » : mise à jour automatique du chantier déjà servi
    fr.locator('#exf_ind').fill('C'); fr.locator('#exf_ind').dispatch_event('input'); pg.wait_for_timeout(300)
    with pg.expect_download(timeout=120000) as dlw: fr.locator('#dpp').click()
    pg.wait_for_function("window.__calls.filter(c=>c.b&&c.b.p_genre).length>=3",timeout=60000)
    rp=[c for c in pg.evaluate('window.__calls') if c.get('b') and c['b'].get('p_genre')]
    check('après « 📄 PDF » : chantier mis à jour tout seul (indice C)',rp[-1]['b']['p_indice']=='C' and rp[-1]['b']['p_site']==SITE)
    pg.screenshot(path=os.environ.get('SHOT','/tmp/calcul-chantier.png'))
    check('pas d’erreur JS',not errs,str(errs[:2]))
    b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
