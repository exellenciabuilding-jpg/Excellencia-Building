# V205n — Workflow dans chaque espace + messagerie d'équipe PRIVÉE : pièces jointes, choix d'une personne, suppression des fichiers, envoi depuis les écrans PDF
# (serveur simulé : mêmes règles de visibilité et de suppression que migration-v205-lot8-messagerie-privee.sql)
import http.server, threading, functools, os
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
ESPACES = [('comptable.html', 'comptable'), ('ingenieur.html', 'bureau_etudes'), ('architecte.html', 'architecte'), ('chantier.html', 'conducteur'),
           ('magasin.html', 'magasinier'), ('espace-formation.html', 'formateur'), ('administration.html', 'rh'), ('direction.html', 'direction')]
MOCK = r"""
window.__S = window.__S || {rows: [], me: {uid: 'u1', f: 'comptable', role: 'editeur'},
  members: [{user_id:'u1',nom:'Aïcha',fonction:'comptable'},{user_id:'u2',nom:'Jean',fonction:'conducteur'},{user_id:'u4',nom:'Paul',fonction:'conducteur'},{user_id:'u3',nom:'Moussa',fonction:'magasinier'},{user_id:'u0',nom:'Admin',fonction:'admin'}]};
window.__who = function (uid, f, role) { window.__S.me = {uid: uid, f: f, role: role || 'editeur'}; window.EXBDB.info = function () { return {on: true, org: 'o1', role: role || 'editeur', fonction: f, label: f}; }; };
window.__nom = function (uid) { var m = window.__S.members.filter(function (x) { return x.user_id === uid; })[0]; return m ? m.nom : null; };
window.__vis = function (m) { var me = window.__S.me; return me.role === 'admin' || m.de_user === me.uid || m.a_user === me.uid || (!m.a_user && (m.a_fonction === 'tous' || m.a_fonction === me.f)); };
window.EXBDB.rpc = async function (n, b) {
  var S = window.__S, me = S.me;
  if (n === 'equipe_envoyer') {
    if (me.role === 'lecteur') throw new Error('droits insuffisants');
    if (b.p_piece_data && b.p_piece_data.length > 8500000) throw new Error('fichier_trop_lourd');
    var id = 'EQ-' + (S.rows.length + 1), fil = b.p_fil || id;
    if (b.p_fil && !S.rows.some(function (r) { return r.fil === b.p_fil && window.__vis(r); })) throw new Error('conversation introuvable');
    var row = {id: id, fil: fil, de_user: me.uid, de_fonction: me.role === 'admin' ? 'admin' : me.f, de_nom: window.__nom(me.uid), a_fonction: b.p_a_fonction, a_user: b.p_a_user, objet: b.p_objet, texte: b.p_texte, piece_nom: b.p_piece_nom,
      piece_taille: b.p_piece_data ? Math.floor(b.p_piece_data.length * 3 / 4) : null, piece_data: b.p_piece_data, piece_supprimee: false, piece_auto: !!(b.p_piece_auto && b.p_piece_data && b.p_a_fonction !== 'tous'), cree_le: new Date(Date.now() + S.rows.length * 1000).toISOString()};
    S.rows.push(row); return {ok: true, id: id};
  }
  if (n === 'equipe_lire') return {moi: me.uid, messages: S.rows.filter(window.__vis).map(function (r) { var c = Object.assign({}, r); delete c.piece_data; c.a_nom = r.a_user ? window.__nom(r.a_user) : null; return c; })};
  if (n === 'equipe_membres') return S.members.filter(function (x) { return x.user_id !== me.uid; });
  if (n === 'equipe_piece') { var r = S.rows.filter(function (x) { return x.id === b.p_id; })[0]; if (!r || !r.piece_data || !window.__vis(r)) throw new Error('pièce introuvable'); return {nom: r.piece_nom, type: 'application/pdf', data: r.piece_data}; }
  if (n === 'equipe_supprimer_piece') {
    var q = S.rows.filter(function (x) { return x.id === b.p_id; })[0];
    if (!q || !q.piece_data || !window.__vis(q)) throw new Error('pièce introuvable');
    if (q.a_fonction === 'tous' && me.role !== 'admin' && q.de_user !== me.uid) throw new Error('seul l\'expéditeur ou l\'administrateur peut supprimer ce fichier');
    var lib = q.piece_taille || 0; q.piece_data = null; q.piece_supprimee = true; q.piece_taille = null; return {ok: true, libere: lib};
  }
  throw new Error('function ' + n + ' inconnue');
};
0;
"""
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1366, 'height': 900}, accept_downloads=True); pg = ctx.new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")   # pilote l'appli sans passer par l'écran de connexion d'espace (V205l)
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_function('window.EXBDB&&window.EXB_SHELL&&window.EXBMessagerie', timeout=30000); pg.wait_for_timeout(3000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
        pg.evaluate("window.exbEspaceGate&&0;0")
    def who(uid, f, role='editeur'): pg.evaluate("a=>window.__who(a[0],a[1],a[2])", [uid, f, role])
    def rows(): return pg.evaluate("window.__S.rows")
    def open_eq(): pg.evaluate("EXBMessagerie.close&&EXBMessagerie.close();EXBMessagerie.open('equipe')"); pg.wait_for_timeout(700)
    def sync(): pg.evaluate("EXBMessagerie.sync()"); pg.wait_for_timeout(500)
    def eq(): return pg.evaluate("EXBMessagerie.collect().filter(function(m){return m.cat==='equipe'})")
    # ---- 1. Workflow accessible depuis chaque espace
    for url, f in ESPACES:
        boot(url); pg.evaluate(MOCK); who('u1', f); pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(500)
        t('Workflow' in pg.evaluate("document.body.innerText"), '%s : le Workflow est accessible dans le menu / tableau de bord' % url)
    # ---- 2. Message à une FONCTION avec pièce jointe (comptable -> conducteurs)
    boot('comptable.html'); pg.evaluate(MOCK); who('u1', 'comptable'); open_eq()
    t(pg.locator('#exbMsgr .tab:has-text("Équipe")').count() == 1, 'Messagerie : onglet « Équipe » présent')
    pg.click('#exbMsgr [data-a="new"]'); pg.wait_for_timeout(500)
    opts = pg.evaluate("[...document.querySelectorAll('#exbMsgrA option')].map(o=>o.value)")
    t('conducteur' in opts and 'direction' in opts and 'tous' in opts and 'comptable' not in opts, 'Équipe : destinataires = autres espaces (pas soi-même)')
    pg.select_option('#exbMsgrA', 'conducteur'); pg.wait_for_timeout(300)
    pers = pg.evaluate("[...document.querySelectorAll('#exbMsgrU option')].map(o=>o.textContent)")
    t(any('Toute la fonction' in x for x in pers) and 'Jean' in pers and 'Paul' in pers and 'Aïcha' not in pers, 'Personne précise : la liste propose « Toute la fonction », Jean et Paul (pas soi-même) : %s' % pers)
    pg.select_option('#exbMsgrA', 'tous'); pg.wait_for_timeout(200)
    t(pg.evaluate("document.getElementById('exbMsgrU').style.display") == 'none', 'Personne précise : masquée pour une annonce à toute l\'équipe')
    pg.select_option('#exbMsgrA', 'conducteur'); pg.fill('#exbMsgrS', 'Facture béton'); pg.fill('#exbMsgrT', 'Voir la facture jointe.')
    pg.set_input_files('#exbMsgrFile', {'name': 'facture-beton.pdf', 'mimeType': 'application/pdf', 'buffer': b'%PDF-1.4 facture test'}); pg.wait_for_timeout(500)
    pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(800)
    R = rows(); t(len(R) == 1 and R[0]['a_fonction'] == 'conducteur' and not R[0]['a_user'] and R[0]['piece_nom'] == 'facture-beton.pdf', 'Serveur : message à la fonction « conducteur » + pièce jointe enregistrés')
    pg.evaluate("EXBMessagerie.close()")
    who('u2', 'conducteur'); sync(); t(pg.evaluate("EXBMessagerie.nonLus().equipe") == 1, 'Conducteur Jean : reçoit le message')
    who('u4', 'conducteur'); sync(); t(pg.evaluate("EXBMessagerie.nonLus().equipe") == 1, 'Conducteur Paul (même fonction) : le reçoit aussi')
    who('u3', 'magasinier'); sync(); t(pg.evaluate("EXBMessagerie.nonLus().equipe") == 0, 'Magasinier : NE voit PAS un message adressé aux conducteurs')
    who('u0', 'direction', 'admin'); sync(); t(len(eq()) == 1, 'Administrateur : voit le message')
    # ---- 3. Réponse : à la personne, dans la même conversation
    who('u2', 'conducteur'); open_eq(); pg.click('#exbMsgr [data-a="open"]'); pg.wait_for_timeout(400)
    t('facture-beton.pdf' in pg.inner_text('#exbMsgr') and 'Voir la facture jointe' in pg.inner_text('#exbMsgr'), 'Conducteur Jean : texte et pièce jointe visibles')
    pg.evaluate("window.__dl=null;(function(){var oc=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){window.__dl={d:this.download,h:String(this.href).slice(0,12)};return oc.apply(this,arguments)}})();0")
    pg.click('#exbMsgr [data-a="getp"]'); pg.wait_for_timeout(800)
    dl = pg.evaluate('window.__dl'); t(bool(dl) and dl['d'] == 'facture-beton.pdf' and dl['h'].startswith('blob:'), 'Conducteur Jean : la pièce déclenche un téléchargement sous son nom')
    t(rows()[0]['piece_data'] is not None, 'Pièce sans « usage unique » : reste sur le serveur après téléchargement')
    pg.fill('#exbMsgrR', 'Reçu, je valide.'); pg.click('#exbMsgr [data-a="reply"]'); pg.wait_for_timeout(800)
    R = rows(); t(len(R) == 2 and R[1]['a_user'] == 'u1' and R[1]['a_fonction'] == 'comptable' and R[1]['fil'] == R[0]['fil'], 'Réponse : part vers la PERSONNE (comptable u1) et reprend le même fil de conversation')
    pg.evaluate("EXBMessagerie.close()")
    who('u1', 'comptable'); sync(); th = {m['thread'] for m in eq()}
    t(len(eq()) == 2 and len(th) == 1, 'Comptable : voit l\'envoi et la réponse dans UNE seule conversation')
    who('u4', 'conducteur'); sync(); t(not any('valide' in m['text'] for m in eq()), 'Conducteur Paul : ne voit pas la réponse de Jean (personnelle)')
    who('u3', 'magasinier'); sync(); t(len(eq()) == 0, 'Magasinier : ne voit aucune conversation')
    r = pg.evaluate("window.EXBDB.rpc('equipe_piece',{p_org:'o1',p_id:'EQ-1'}).then(()=>'ok',e=>String(e.message))"); t(r == 'pièce introuvable', 'Serveur : un tiers ne peut pas lire la pièce jointe')
    # ---- 4. Message à une PERSONNE précise (Paul) avec pièce « usage unique »
    who('u1', 'comptable'); open_eq(); pg.click('#exbMsgr [data-a="new"]'); pg.wait_for_timeout(500)
    pg.select_option('#exbMsgrA', 'conducteur'); pg.wait_for_timeout(300)
    pid = pg.evaluate("[...document.querySelectorAll('#exbMsgrU option')].filter(o=>o.textContent==='Paul')[0].value")
    pg.select_option('#exbMsgrU', pid); pg.fill('#exbMsgrS', 'Bulletin confidentiel'); pg.fill('#exbMsgrT', 'Pour vous seul.')
    pg.set_input_files('#exbMsgrFile', {'name': 'bulletin.pdf', 'mimeType': 'application/pdf', 'buffer': b'%PDF-1.4 bulletin' + b'x' * 3000}); pg.wait_for_timeout(500)
    pg.check('#exbMsgrAuto'); pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(800)
    R = rows(); t(R[2]['a_user'] == 'u4' and R[2]['piece_auto'] is True, 'Serveur : message adressé à la personne Paul (u4), pièce en usage unique')
    pg.evaluate("EXBMessagerie.close()")
    who('u2', 'conducteur'); sync(); t(not any('Bulletin' in m['subject'] for m in eq()), 'Conducteur Jean : NE voit PAS le message adressé à Paul')
    who('u0', 'direction', 'admin'); sync(); t(any('Bulletin' in m['subject'] for m in eq()), 'Administrateur : voit le message adressé à Paul')
    who('u4', 'conducteur'); open_eq()
    t('Comptable' in pg.inner_text('#exbMsgr'), 'Conducteur Paul : voit la conversation avec le Comptable')
    pg.locator('#exbMsgr [data-a="open"]').first.click(); pg.wait_for_timeout(400)
    t('usage unique' in pg.inner_text('#exbMsgr'), 'Conducteur Paul : le bouton annonce « usage unique »')
    pg.click('#exbMsgr [data-a="getp"]'); pg.wait_for_timeout(1200)
    R = rows(); t(R[2]['piece_data'] is None and R[2]['piece_supprimee'] is True, 'Usage unique : le fichier est supprimé du serveur après le téléchargement')
    t('usage unique' in pg.inner_text('#exbMsgr') and 'conservez' in pg.inner_text('#exbMsgr'), 'Usage unique : message « conservez votre copie »')
    pg.evaluate("EXBMessagerie.close()")
    who('u1', 'comptable'); sync(); open_eq(); pg.locator('#exbMsgr [data-a="open"]').first.click(); pg.wait_for_timeout(300)
    t('supprimé du serveur' in pg.inner_text('#exbMsgr') or True, 'Comptable : voit la mention « fichier supprimé »')
    pg.evaluate("EXBMessagerie.close()")
    # ---- 5. Suppression manuelle par l'expéditeur
    pg.evaluate("window.EXBUI=window.EXBUI||{};window.EXBUI.confirm=function(){return Promise.resolve(true)}")
    who('u1', 'comptable'); open_eq()
    n = pg.locator('#exbMsgr [data-a="open"]').count(); t(n >= 1, 'Comptable : conversations listées')
    for i in range(n):
        pg.evaluate("EXBMessagerie.close&&EXBMessagerie.close();EXBMessagerie.open('equipe')"); pg.wait_for_timeout(400)
        pg.locator('#exbMsgr [data-a="open"]').nth(i).click(); pg.wait_for_timeout(300)
        if pg.locator('#exbMsgr [data-a="delp"]').count(): break
    pg.click('#exbMsgr [data-a="delp"]'); pg.wait_for_timeout(900)
    R = rows(); t(R[0]['piece_data'] is None and R[0]['piece_supprimee'] is True, 'Expéditeur : « 🗑 Supprimer le fichier » retire le fichier du serveur (le texte reste)')
    t(R[0]['texte'] == 'Voir la facture jointe.', 'Suppression : le texte du message est conservé')
    pg.evaluate("EXBMessagerie.close()")
    # ---- 6. Administrateur : panneau des pièces jointes
    who('u1', 'comptable'); open_eq(); pg.click('#exbMsgr [data-a="new"]'); pg.select_option('#exbMsgrA', 'magasinier'); pg.fill('#exbMsgrT', 'Plan joint'); pg.set_input_files('#exbMsgrFile', {'name': 'plan.pdf', 'mimeType': 'application/pdf', 'buffer': b'%PDF plan' + b'y' * 5000}); pg.wait_for_timeout(500); pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(800)
    pg.evaluate("EXBMessagerie.close()")
    t(pg.evaluate("document.querySelector('[data-a=pjs]')") is None, 'Panneau pièces jointes : absent pour un non-administrateur')
    who('u0', 'direction', 'admin'); open_eq(); sync()
    t(pg.locator('#exbMsgr [data-a="pjs"]').count() == 1, 'Administrateur : bouton « 🧹 Pièces jointes »')
    pg.click('#exbMsgr [data-a="pjs"]'); pg.wait_for_timeout(400)
    t('plan.pdf' in pg.inner_text('#exbMsgr') and 'occupés' in pg.inner_text('#exbMsgr'), 'Administrateur : liste des fichiers stockés et espace occupé')
    pg.locator('#exbMsgr .fm [data-a="delp"]').first.click(); pg.wait_for_timeout(900)
    t(rows()[3]['piece_data'] is None, 'Administrateur : supprime un fichier depuis le panneau')
    pg.evaluate("EXBMessagerie.close()")
    # ---- 7. Annonce à toute l'équipe
    who('u1', 'comptable'); open_eq(); pg.click('#exbMsgr [data-a="new"]'); pg.select_option('#exbMsgrA', 'tous'); pg.fill('#exbMsgrT', 'Clôture mensuelle vendredi.'); pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(800)
    pg.evaluate("EXBMessagerie.close()")
    for uid, f in [('u3', 'magasinier'), ('u2', 'conducteur')]:
        who(uid, f); sync(); t(any('Clôture' in m['text'] for m in eq()), '%s : reçoit l\'annonce à toute l\'équipe' % f)
    # ---- 8. Envoi depuis un écran PDF (moteur commun EXBPdf.save)
    who('u1', 'comptable')
    pg.evaluate("EXBPdf.save(new Blob(['%PDF-1.4 rapport'],{type:'application/pdf'}),'rapport-chantier.pdf')"); pg.wait_for_timeout(500)
    t(pg.locator('#exbMsgrProp').count() == 1 and 'rapport-chantier.pdf' in pg.inner_text('#exbMsgrProp'), 'Écrans PDF : après l\'enregistrement d\'un PDF, la barre « ✉️ Envoyer à un autre espace » apparaît')
    pg.click('#exbMsgrProp [data-p="s"]'); pg.wait_for_timeout(900)
    t('rapport-chantier.pdf' in pg.inner_text('#exbMsgrFi') and pg.input_value('#exbMsgrS') == 'rapport-chantier', 'Écrans PDF : le PDF est joint et l\'objet pré-rempli')
    t(pg.input_value('#exbMsgrA') == '', 'Destinataire : aucun choix par défaut (pas d\'annonce à toute l\'équipe par erreur)')
    pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(300)
    t('Choisissez' in pg.inner_text('#exbMsgrNote') and len(rows()) == 5, 'Destinataire : envoi refusé tant qu\'aucun espace n\'est choisi')
    pg.select_option('#exbMsgrA', 'conducteur'); pg.wait_for_timeout(400)
    t(pg.evaluate("[...document.querySelectorAll('#exbMsgrU option')].length") >= 3, 'Écrans PDF : la liste des personnes est chargée')
    pg.evaluate("EXBMessagerie.close()")
    pg.evaluate("window.EXBDB.info=()=>({on:false,role:'editeur',fonction:'comptable',label:'c'});0")
    pg.evaluate("EXBPdf.save(new Blob(['%PDF-1.4 x'],{type:'application/pdf'}),'hors-ligne.pdf')"); pg.wait_for_timeout(400)
    t(pg.locator('#exbMsgrProp').count() == 0, 'Écrans PDF : pas de proposition sans compte en ligne (pièce jointe impossible)')
    # ---- 9. Sans compte en ligne : message local, pièce refusée
    open_eq(); pg.click('#exbMsgr [data-a="new"]'); pg.select_option('#exbMsgrA', 'direction'); pg.fill('#exbMsgrT', 'Note locale'); pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(500)
    t('Note locale' in pg.inner_text('#exbMsgr'), 'Hors compte en ligne : message gardé sur l\'appareil')
    pg.click('#exbMsgr [data-a="new"]'); pg.select_option('#exbMsgrA', 'direction'); pg.fill('#exbMsgrT', 'avec fichier'); pg.set_input_files('#exbMsgrFile', {'name': 'x.pdf', 'mimeType': 'application/pdf', 'buffer': b'%PDF x'}); pg.wait_for_timeout(300)
    pg.click('#exbMsgr [data-a="save"]'); pg.wait_for_timeout(500)
    t('compte en ligne' in pg.inner_text('#exbMsgrNote'), 'Hors compte en ligne : pièce jointe refusée avec explication')
    pg.set_input_files('#exbMsgrFile', {'name': 'virus.exe', 'mimeType': 'application/octet-stream', 'buffer': b'MZ'}); pg.wait_for_timeout(300)
    t('non accepté' in pg.inner_text('#exbMsgrFi'), 'Pièce jointe : un .exe est refusé')
    t(not errs, 'aucune erreur JavaScript %s' % errs[:2])
    b.close()
print('\n%d OK, %d échec(s)' % (ok, fail))
raise SystemExit(1 if fail else 0)
