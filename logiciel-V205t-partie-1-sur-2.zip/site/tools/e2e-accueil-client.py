#!/usr/bin/env python3
"""V190 — accueil client + connexion (d'après la maquette) : python3 tools/e2e-accueil-client.py (depuis le dossier du site)."""
import http.server, threading, socketserver, os, functools, sys, json, re
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.ThreadingTCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start(); U=f'http://127.0.0.1:{PORT}/'
fails=0
def ok(c,m):
    global fails; print(('  OK   ' if c else '  FAIL ')+m); fails+= (not c)
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    def page(w=1440,h=900,ctx=None):
        pg=ctx.new_page() if ctx else b.new_page(viewport={'width':w,'height':h}); pg.on('pageerror',lambda e:errs.append(str(e)[:120])); return pg
    pg=page(); pg.goto(U+'accueil-client.html'); pg.wait_for_timeout(1200)
    ok(pg.inner_text('h1').replace('\n',' ').upper().startswith('EXCELLENCIA BUILDING'),'accueil : titre « Excellencia Building — Votre projet commence ici. »')
    ok(pg.locator('.tile').count()==4,'accueil : 4 tuiles (Construction, Architecture, Métré & Devis, Rénovation)')
    ok(pg.locator('.checks li').count()==4 and pg.locator('.stat').count()==4,'accueil : 4 atouts et 4 chiffres')
    ok(pg.is_hidden('#exbHelpBtn') or pg.locator('#exbHelpBtn').count()==0,'accueil : aide du personnel (❓) masquée au client')
    ok(pg.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1"),'accueil : pas de défilement horizontal (ordinateur)')
    ok(all(pg.evaluate("()=>[...document.images].map(i=>i.complete&&i.naturalWidth>0)")),'accueil : toutes les images se chargent')
    # liens
    ok(pg.get_attribute('a.sec','href')=='espace-client.html' and pg.get_attribute('.btn-login','href')=='espace-client.html' and pg.get_attribute('.dossier .acces','href')=='espace-client.html','accueil : « Suivre mon projet », « Se connecter », « Accéder à mon espace » → connexion')
    ok(pg.get_attribute('a.pri','href')=='demande.html','accueil : « Déposer une demande de projet » → page de demande (choix du type)')
    ok(pg.get_attribute('#assist','href').startswith('https://wa.me/243810644554'),'accueil : Assistance → WhatsApp du numéro de l\'entreprise')
    # menu Services
    pg.click('#ddb'); ok(pg.is_visible('.dd .sub'),'menu « Nos Services » s\'ouvre'); pg.keyboard.press('Escape'); ok(not pg.is_visible('.dd .sub'),'… et se ferme (Échap)')
    # tuiles → formulaire SÉPARÉ pour chaque type (V200 : demande.html)
    cas=[('Construction','construction'),('Architecture','architecture'),('Métré','metre'),('Rénovation','renovation')]
    for nom,k in cas:
        q=page(); q.goto(U+'accueil-client.html'); q.wait_for_timeout(500); q.locator('.tile',has_text=nom).click(); q.wait_for_url('**/demande.html*'); q.wait_for_timeout(700)
        ok(('type='+k) in q.url and q.is_visible('#f') and q.is_hidden('#choose'),f'tuile « {nom} » → son propre formulaire de demande'); q.close()
    # téléphone
    m=page(390,844); m.goto(U+'accueil-client.html'); m.wait_for_timeout(1000)
    ok(m.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1"),'accueil téléphone : pas de défilement horizontal')
    ok(not m.is_visible('#menu') and m.is_visible('#burger'),'accueil téléphone : menu replié, bouton ☰ visible')
    m.click('#burger'); ok(m.is_visible('#menu') and m.is_visible('.btn-login'),'accueil téléphone : ☰ ouvre le menu avec « Se connecter »'); m.close()
    # connexion : fonctions ajoutées
    c=page(); c.goto(U+'espace-client.html'); c.wait_for_timeout(800)
    ok(c.is_visible('#fLogin h1') and 'Connexion' in c.inner_text('#fLogin h1'),'connexion : titre « Connexion à votre espace »')
    c.click('#eye'); ok(c.get_attribute('#pw','type')=='text','connexion : l\'œil affiche le mot de passe'); c.click('#eye'); ok(c.get_attribute('#pw','type')=='password','connexion : … et le masque')
    c.evaluate("()=>{window.__o=[];window.open=function(u){window.__o.push(u)}}"); c.click('#oubli')
    ok('wa.me/243810644554' in (c.evaluate('()=>window.__o[0]||""')),'connexion : « Mot de passe oublié ? » → WhatsApp de l\'entreprise'); 
    ok(c.get_attribute('.inscr a','href')=='demande.html','connexion : « Créer un compte » → demande de projet')
    ok(c.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1"),'connexion : pas de défilement horizontal')
    c.close()
    # se souvenir de moi (sans appel serveur : on pose la valeur comme le ferait une connexion réussie)
    ctx=b.new_context(); r1=page(ctx=ctx); r1.goto(U+'espace-client.html'); r1.evaluate("()=>localStorage.setItem('exb_cm_mem','CLI-2026-0001')"); r1.goto(U+'espace-client.html'); r1.wait_for_timeout(500)
    ok(r1.input_value('#mat')=='CLI-2026-0001' and r1.is_checked('#rem'),'connexion : « Se souvenir de moi » préremplit le matricule'); ctx.close()
    # marque blanche : couverte par tools/e2e-marque.py (il parcourt toutes les pages *.html, dont accueil-client et espace-client)
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2])); b.close()
print('\nRésultat :',('%d échec(s)'%fails) if fails else 'tout passe'); sys.exit(1 if fails else 0)
