# Test navigateur V186e : raccourcis clavier et édition directe dans le Studio libre.
# Lancer :  python3 tools/e2e-affiches-clavier.py   (Chromium + Playwright)
import http.server, threading, functools, os
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8895), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    pg.goto('http://127.0.0.1:8895/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("show('affiches')"); pg.wait_for_timeout(600); pg.click('#exbsT2'); pg.wait_for_timeout(400)
    pg.evaluate("EXB_STUDIO.applyTemplate(EXB_STUDIO.templates()[60])"); pg.wait_for_timeout(400)
    S = "EXB_STUDIO.state()"
    n0 = pg.evaluate(S + ".els.length")
    tid = pg.evaluate(S + ".els.find(x=>x.t==='text'&&x.tx.length>3).id")
    def click(id):
        pg.evaluate("(id)=>{const s=document.querySelector('#exbsStage');s.querySelector('[data-id=\"'+id+'\"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));s.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}))}", id); pg.wait_for_timeout(200)
    click(tid)
    x0 = pg.evaluate("(id)=>" + S + ".els.find(e=>e.id===id).x", tid)
    # flèches puis Ctrl+Z / Ctrl+Y
    pg.evaluate("document.activeElement&&document.activeElement.blur()")
    for _ in range(3): pg.keyboard.press('ArrowRight')
    x1 = pg.evaluate("(id)=>" + S + ".els.find(e=>e.id===id).x", tid)
    ok(x1 == x0 + 12, 'flèches : déplacement de 4 px par appui')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(150)
    ok(pg.evaluate("(id)=>" + S + ".els.find(e=>e.id===id).x", tid) == x0, 'Ctrl+Z annule les déplacements aux flèches (en un seul pas)')
    pg.keyboard.press('Control+y'); pg.wait_for_timeout(150)
    ok(pg.evaluate("(id)=>" + S + ".els.find(e=>e.id===id).x", tid) == x1, 'Ctrl+Y rétablit')
    pg.keyboard.press('Control+z'); pg.keyboard.press('Control+Shift+z'); pg.wait_for_timeout(150)
    ok(pg.evaluate("(id)=>" + S + ".els.find(e=>e.id===id).x", tid) == x1, 'Ctrl+Maj+Z rétablit aussi')
    # dupliquer, copier / coller, supprimer
    pg.keyboard.press('Control+d'); pg.wait_for_timeout(150)
    ok(pg.evaluate(S + ".els.length") == n0 + 1, 'Ctrl+D duplique l’élément')
    pg.keyboard.press('Delete'); pg.wait_for_timeout(150)
    ok(pg.evaluate(S + ".els.length") == n0, 'Suppr supprime l’élément sélectionné')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(150)
    ok(pg.evaluate(S + ".els.length") == n0 + 1, 'Ctrl+Z ramène l’élément supprimé')
    click(tid)
    pg.evaluate("document.dispatchEvent(new ClipboardEvent('copy',{bubbles:true,cancelable:true,clipboardData:new DataTransfer()}))")
    pg.evaluate("document.dispatchEvent(new ClipboardEvent('paste',{bubbles:true,cancelable:true,clipboardData:new DataTransfer()}))"); pg.wait_for_timeout(150)
    ok(pg.evaluate(S + ".els.length") == n0 + 2, 'copier / coller crée une copie décalée')
    # Échap
    pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
    ok(pg.locator('#pp_word').count() == 0, 'Échap désélectionne')
    # double-clic = éditeur Word ; Suppr/Retour arrière dans l'éditeur ne détruit pas l’affiche
    nn = pg.evaluate(S + ".els.length")
    pg.evaluate("(id)=>{document.querySelector('#exbsStage [data-id=\"'+id+'\"]').dispatchEvent(new MouseEvent('dblclick',{bubbles:true}))}", tid); pg.wait_for_timeout(900)
    ok(pg.locator('#exbawModal #exbEdSheet').count() == 1, 'double-clic sur un texte : ouvre l’éditeur Word')
    pg.click('#exbEdSheet'); pg.keyboard.press('Control+A'); pg.keyboard.press('Backspace'); pg.keyboard.type('Bonjour'); pg.keyboard.press('Control+z'); pg.keyboard.press('Control+y'); pg.wait_for_timeout(200)
    ok(pg.evaluate(S + ".els.length") == nn, 'Retour arrière dans l’éditeur Word ne supprime pas l’élément de l’affiche')
    pg.keyboard.press('Control+s'); pg.wait_for_timeout(500)
    ok(pg.locator('#exbawModal').count() == 0 and 'Bonjour' in pg.evaluate("(id)=>" + S + ".els.find(e=>e.id===id).tx", tid), 'Ctrl+S dans l’éditeur Word applique le texte à l’affiche')
    # Entrée rouvre l’éditeur
    click(tid); pg.evaluate("document.activeElement&&document.activeElement.blur()"); pg.keyboard.press('Enter'); pg.wait_for_timeout(800)
    ok(pg.locator('#exbawModal').count() == 1, 'Entrée sur un texte sélectionné : ouvre l’éditeur Word')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    if pg.locator('#exbawModal').count(): pg.click('#exbawCancel'); pg.wait_for_timeout(300)
    # Ctrl+S dans le Studio : enregistre sans ouvrir la boîte « enregistrer la page »
    pg.evaluate("document.activeElement&&document.activeElement.blur()"); pg.keyboard.press('Control+s'); pg.wait_for_timeout(300)
    ok(pg.evaluate("JSON.stringify(Object.keys(localStorage).filter(k=>/studio_posters/.test(k)&&localStorage[k].length>20))") != '[]', 'Ctrl+S enregistre l’affiche')
    ok(not errs, 'aucune erreur JavaScript' + (' : ' + errs[0] if errs else ''))
    b.close()
print('\n%s' % ('TOUT EST OK' if not fails else '%d ÉCHEC(S)' % len(fails)))
raise SystemExit(1 if fails else 0)
