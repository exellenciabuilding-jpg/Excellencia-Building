#!/usr/bin/env python3
"""V186i : dans la BI, « Imprimer » imprime le DOCUMENT du rapport (pas l'écran du logiciel) et l'envoie à l'imprimante Windows.
Usage, depuis le dossier du site : python3 tools/e2e-bi-imprimer.py"""
import http.server, threading, socketserver, os, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':1100,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200])); a.on('dialog',lambda d:d.accept())
    exbui_auto(a)
    # simule l'application Windows : on capte ce qui part vers l'imprimante et vers le PDF
    a.add_init_script("""window.__sent=[];window.exbDesktop={print:function(o){window.__sent.push(['pdf',o.html]);return Promise.resolve({ok:true})},printNative:function(o){window.__sent.push(['imprimante',o.html]);return Promise.resolve({ok:true})}};
      setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)""")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    a.evaluate("show('exbbi')"); a.wait_for_timeout(900)
    a.click('#bi_pdf'); a.wait_for_timeout(1500)
    s=a.evaluate("window.__sent")
    ok(len(s)==1 and s[0][0]=='imprimante','« Imprimer » part vers l’imprimante Windows (une seule fois) : '+str([x[0] for x in s]))
    h=s[0][1] if s else ''
    ok('Rapport de direction' in h,'le document imprimé est le rapport de direction')
    ok('Personnaliser' not in h and 'Export Excel' not in h and 'bi_pdf' not in h,'aucun bouton ni onglet du logiciel dans le document')
    ok('Alertes de direction' in h and 'Scanner pour vérifier' in h,'alertes + QR de vérification présents')
    a.evaluate("window.__sent.length=0"); a.click('#bi_rep'); a.wait_for_timeout(1500)
    s=a.evaluate("window.__sent")
    ok(len(s)==1 and s[0][0]=='pdf','« Rapport de direction (PDF) » reste un PDF enregistré : '+str([x[0] for x in s]))
    ok(not ae,'aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('\n%d échec(s)'%fails); raise SystemExit(1 if fails else 0)
