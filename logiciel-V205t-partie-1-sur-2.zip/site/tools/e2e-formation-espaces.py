#!/usr/bin/env python3
"""V186 — Division « Formation & académie » en trois espaces (formations classiques / parcours TFL / certificats)
et statuts de certificats (valide / suspendu / révoqué), motif obligatoire, traitement par lot. Usage : python3 tools/e2e-formation-espaces.py"""
import http.server, threading, socketserver, os, functools, re
from playwright.sync_api import sync_playwright
import sys as _s; _s.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m,d=''):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m+('' if c or not d else ' — '+str(d)))
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':900}); exbui_auto(pg)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(2500)
    pg.evaluate("()=>{exbSessionStorage.setItem('exb_logged','1');document.getElementById('app').style.display='block'}"); pg.wait_for_timeout(2500)
    # --- trois espaces
    pg.evaluate("EXB_SHELL.openDiv('dv_for')"); pg.wait_for_timeout(500)
    esp=pg.evaluate("[...document.querySelectorAll('#exbHub .xdg[data-espace]')].map(e=>e.dataset.espace)")
    ok(esp==['cls','tfl','cer'],'trois espaces dans la division Formation',esp)
    grp=pg.evaluate("""()=>{const o={};let cur='';for(const el of document.querySelectorAll('#exbHub .xdg, #exbHub .xg')){if(el.classList.contains('xdg'))cur=el.dataset.espace;else o[cur]=[...el.querySelectorAll('button b')].map(b=>b.textContent)}return o}""")
    ok('TFL' in grp.get('tfl',[]) and 'TFL' not in grp.get('cls',[]),'TFL dans son propre espace',grp.get('tfl'))
    ok('Certificats' in grp.get('cer',[]) and 'Formations' in grp.get('cls',[]) and 'Certificats' not in grp.get('cls',[]),'Certificats séparés ; formations classiques à part',grp)
    # --- statuts de certificats
    pg.evaluate("""()=>{certs.length=0;[['C-1','Paul Kasa'],['C-2','Marie Kasa'],['C-3','Jean Ilunga']].forEach(x=>certs.push({cert_no:x[0],holder:x[1],training:'AutoCAD',status:'VALIDE',issued_date:'2026-11-01'}));save('exb_certificates',certs);show('registry');loadRegistry()}""")
    pg.wait_for_timeout(300)
    st=lambda n:pg.evaluate("n=>certs.find(c=>c.cert_no===n).status",n)
    rowtxt=lambda n:pg.evaluate("n=>[...document.querySelectorAll('#regrows tr')].find(t=>t.textContent.includes(n))?.textContent||''",n)
    ok('Suspendre' in rowtxt('C-1') and 'Révoquer' in rowtxt('C-1'),'certificat valide : boutons Suspendre / Révoquer')
    pg.evaluate("window.__exbuiNext=['  ']"); pg.evaluate("setCertStatus('C-1','SUSPENDU')"); pg.wait_for_timeout(600)
    ok(st('C-1')=='VALIDE','suspension sans motif refusée')
    pg.evaluate("window.__exbuiNext=['Facture impayée']"); pg.evaluate("setCertStatus('C-1','SUSPENDU')"); pg.wait_for_timeout(600)
    ok(st('C-1')=='SUSPENDU' and pg.evaluate("certs[0].suspension_reason")=='Facture impayée','suspension avec motif enregistré')
    ok('Suspendu' in rowtxt('C-1') and 'Réactiver' in rowtxt('C-1'),'registre : « Suspendu » + Réactiver',rowtxt('C-1'))
    pg.evaluate("window.__exbuiNext=['Fraude']"); pg.evaluate("setCertStatus('C-1','ANNULE')"); pg.wait_for_timeout(600)
    ok(st('C-1')=='ANNULE' and 'Révoqué' in rowtxt('C-1'),'révocation : « Révoqué »',rowtxt('C-1'))
    pg.evaluate("setCertStatus('C-1','VALIDE')"); pg.wait_for_timeout(400)
    ok(st('C-1')=='VALIDE','réactivation')
    # --- lot : filtre « Kasa » = C-1 et C-2
    pg.fill('#registrySearch','Kasa'); pg.wait_for_timeout(200)
    pg.evaluate("window.__exbuiNext=['Session annulée']"); pg.evaluate("batchCertStatus('SUSPENDU')"); pg.wait_for_timeout(900)
    ok(st('C-1')=='SUSPENDU' and st('C-2')=='SUSPENDU' and st('C-3')=='VALIDE','lot : seuls les certificats de la liste filtrée sont suspendus',[st('C-1'),st('C-2'),st('C-3')])
    pg.evaluate("batchCertStatus('VALIDE')"); pg.wait_for_timeout(700)
    ok(st('C-1')=='VALIDE' and st('C-2')=='VALIDE','lot : réactivation')
    # --- pages publiques (statique)
    v=open(ROOT+'/verification.html',encoding='utf-8').read(); a=open(ROOT+'/espace-apprenant.html',encoding='utf-8').read(); e=open(ROOT+'/exb-verif.js',encoding='utf-8').read()
    ok('SUSPENDU' in v and 'suspendu' in e and 'SUSPEN' in a,'registre public, page de vérification et espace apprenant gèrent « suspendu »')
    ok(not errs,'aucune erreur JavaScript',errs[:2])
    b.close()
print('ÉCHECS :',fails); raise SystemExit(1 if fails else 0)
