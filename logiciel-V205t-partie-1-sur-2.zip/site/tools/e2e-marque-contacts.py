#!/usr/bin/env python3
"""V186b — VARIANTE : le NOM reste celui d'origine, seuls téléphone / e-mail / adresse / direction / slogan changent. Cherche leurs valeurs d'origine.
V120j — Contrôle « une seule configuration » : configure une fausse entreprise, puis parcourt TOUTES les pages
et TOUTES les sections du logiciel en cherchant le nom, l'e-mail, le téléphone, le dirigeant, le slogan et l'adresse d'origine.
Vérifie aussi le contenu des PDF produits (devis, moteur local). Usage, depuis le dossier du site :  python3 tools/e2e-marque.py
(Exceptions connues et voulues : mention de droit d'auteur du fichier de calcul « Metrec ».)"""
import http.server, threading, socketserver, os, functools, sys, json, re, glob
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
BR={"brand":{"name":"Excellencia Building","short":"Excellencia","chantier":"Excellencia Chantier","tagline":"Construire avec confiance","primary":"#0a6b3a","secondary":"#0a8a4a","accent":"#d35400","phone":"+243 999 111 222","email":"contact@batplus.test","address":"Av. Test 1"},"done":True,"fixed":False}
ID={"name":"Excellencia Building","tagline":"Construire avec confiance","phone":"+243 999 111 222","email":"contact@batplus.test","address":"Av. Test 1","dg":"M. Dupont"}
PAT=re.compile(r"810 ?644 ?554|Excellenciabuilding@gmail|Ibwampere|Ingénierie\s*(&|&amp;)\s*Construction",re.I)
TOLERE=re.compile(r"Metrec 2026",re.I)
FIND="""()=>{const re=/810[ ]?644[ ]?554|Excellenciabuilding@gmail|Ibwampere|Ingénierie\\s*(&|&amp;)\\s*Construction/i;const o=[];
const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
while(n=w.nextNode()){const e=n.parentElement;if(!e||['SCRIPT','STYLE'].includes(e.nodeName))continue;const m=re.exec(n.nodeValue);if(m)o.push(e.nodeName+(e.id?'#'+e.id:'')+' : '+n.nodeValue.slice(Math.max(0,m.index-40),m.index+60).replace(/\\s+/g,' '))}
document.querySelectorAll('*').forEach(e=>{for(const a of ['alt','title','placeholder','value','href','content','aria-label']){const v=e.getAttribute&&e.getAttribute(a);if(v&&v.length<400&&re.test(v))o.push(e.nodeName+(e.id?'#'+e.id:'')+' @'+a+' : '+v.slice(0,90))}});
const t=document.title;if(re.test(t))o.push('TITLE : '+t);return o}"""
fails=[]
def seed(ctx):
    # V167 : le site livre un entreprise.json d'origine qui prime sur localStorage -> la fausse entreprise est servie à sa place
    fj=dict(BR['brand']); fj.update({k:v for k,v in ID.items() if k not in fj or not fj[k]}); fj['version']=1; fj.setdefault('publicUrl','https://batplus.test')
    ctx.route('**/entreprise.json*',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps(fj)))
    # la vitrine lit aussi son propre config.json (logiciel_url…) : une autre entreprise n'a pas celui d'Excellencia
    ctx.route('**/site-vitrine/config.json*',lambda r:r.fulfill(status=200,content_type='application/json',body='{}'))
    ctx.add_init_script("localStorage.setItem('EXB_BRAND_V1',%s);localStorage.setItem('EXB_IDENTITE_V1',%s);"%(json.dumps(json.dumps(BR)),json.dumps(json.dumps(ID))))
with sync_playwright() as p:
    ex=os.environ.get('CHROMIUM_PATH')
    b=p.chromium.launch(executable_path=ex,args=['--no-sandbox']) if ex else p.chromium.launch()
    pages=sorted(glob.glob('*.html')+glob.glob('*/*.html')); pages=[x for x in pages if not x.startswith(('qcm/','node_modules/'))]
    for pg in pages:
        ctx=b.new_context(viewport={'width':430,'height':900}); seed(ctx); page=ctx.new_page()
        try:
            page.goto('http://127.0.0.1:%d/%s'%(PORT,pg),wait_until='load',timeout=20000); page.wait_for_timeout(1200)
            if pg=='index.html': page.evaluate("()=>{try{window.exbFinishLogin()}catch(e){}}"); page.wait_for_timeout(1500)
            seen=set(page.evaluate(FIND))
            if pg=='index.html':
                for i in page.evaluate("()=>[...document.querySelectorAll('section[id]')].map(s=>s.id)"):
                    page.evaluate("(i)=>{try{show(i)}catch(e){}}",i); page.wait_for_timeout(250); seen|=set(page.evaluate(FIND))
            for r in sorted(seen):
                if not TOLERE.search(r): fails.append(pg+' → '+r)
        except Exception as e: fails.append(pg+' → ÉCHEC chargement : '+str(e)[:80])
        ctx.close()
    # PDF : devis + moteur local, avec noms d'origine dans les données
    ctx=b.new_context(); seed(ctx); page=ctx.new_page(); page.goto('http://127.0.0.1:%d/index.html'%PORT,wait_until='load'); page.wait_for_timeout(1500)
    page.evaluate("()=>{try{window.exbFinishLogin()}catch(e){}}"); page.wait_for_timeout(1000)
    r=page.evaluate("""async()=>{const o={};const t=async b=>new TextDecoder('latin1').decode(await b.arrayBuffer());
      const a=await EXBPdf.make({titre:'Plan — Excellencia Building',rows:[['Tél','+243 810 644 554']],footer:'Tél +243 810 644 554',engine:'local'});const ta=await t(a);o.pdf_residu=/810 ?644 ?554/.test(ta);o.pdf_nom=/999 111 222/.test(ta);
      const d=await EXBDocs.build({kind:'devis',no:'D-1',title:'Devis Excellencia Building',date:'2026-11-01',client:{name:'X',phone:'+243 810 644 554'},cur:'USD',T:{tot:100,sub:100},lines:[['Mur','m2',2,50,100]]},{engine:'local'});const td=await t(d.blob||d);o.devis_residu=/810 ?644 ?554/.test(td);return o}""")
    if r.get('pdf_residu') or not r.get('pdf_nom'): fails.append('PDF (EXBPdf.make) : nom d\'origine présent ou nom du client absent')
    if r.get('devis_residu'): fails.append('PDF devis : nom d\'origine présent')
    b.close()
print('%d page(s) parcourue(s), %d résidu(s)'%(len(pages),len(fails)))
for f in fails: print('  ✗',f)
sys.exit(1 if fails else 0)
