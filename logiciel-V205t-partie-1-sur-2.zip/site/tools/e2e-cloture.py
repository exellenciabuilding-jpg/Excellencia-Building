#!/usr/bin/env python3
"""Test navigateur de l'onglet « 🏁 Clôture » (V163). Usage, depuis le dossier du site : python3 tools/e2e-cloture.py"""
import http.server, threading, socketserver, os, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200]))
    a.on('dialog',lambda d:d.accept('Réserves levées') if d.type=='prompt' else d.accept())
    exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    ok(a.evaluate("typeof EXBCL==='object'&&typeof EXBPL==='object'"),'modules chargés')
    a.evaluate("""()=>{const P={id:'PX',name:'Chantier test',budget:1000,progress:50};exbProjects.push(P);exbSave(EXB_ECO_KEYS.projects,exbProjects);
      save('exb_gantt',[{id:'G1',project_id:'PX',date:'2026-09-01',tasks:[{name:'A',start:1,dur:2,pct:50,pred:''}],jalons:[]}]);
      save('exb_purchase_orders',[{id:'O1',project_id:'PX',lines:[{q:10,pu:20,rec:10}],payments:[{amount:200}]}])}""")
    a.evaluate("window.exbConfirm=()=>Promise.resolve(true);window.exbPrompt=()=>Promise.resolve('Réserves levées')")
    a.evaluate("show('plangantt')"); a.wait_for_timeout(500)
    ok('🏁 Clôture' in a.inner_text('#exbpl_box'),'onglet Clôture présent')
    a.evaluate("EXBPL.pid('PX');EXBPL.tab('c')"); a.wait_for_timeout(400)
    t=a.inner_text('#exbpl_box'); ok('non terminée' in t and 'bloquant' in t,'tâche à 50 % signalée bloquante')
    a.evaluate("EXBCL.cloturer()"); a.wait_for_timeout(500)
    ok(a.evaluate("load('exb_clotures',[]).length")==0,'clôture refusée sans motif')
    a.evaluate("EXBCL.f('motif','Accord direction');EXBCL.cloturer()"); a.wait_for_timeout(600)
    ok(a.evaluate("load('exb_clotures',[]).length")==1 and 'Projet clôturé' in a.inner_text('#exbpl_box'),'clôture forcée enregistrée et affichée')
    ok(a.evaluate("exbProjects.find(p=>p.id==='PX').cloture_le")!=None,'date de clôture portée par la fiche projet')
    a.evaluate("EXBCL.rouvrir()"); a.wait_for_timeout(600)
    ok(a.evaluate("EXBCL.etat(load('exb_clotures',[]),'PX')")==None and 'Clôturer le projet' in a.inner_text('#exbpl_box'),'réouverture avec motif')
    ok(not ae,'0 erreur JavaScript '+str(ae[:2]))
    b.close()
print('ÉCHEC' if fails else 'OK'); raise SystemExit(1 if fails else 0)
