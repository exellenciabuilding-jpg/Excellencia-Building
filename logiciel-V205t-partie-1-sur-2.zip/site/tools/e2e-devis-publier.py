# Test navigateur V141o : devis publiés sur le portail client (génération réelle du PDF du devis, serveur Supabase simulé).
import json, os, re, threading, http.server, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8795),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ORG='11111111-2222-3333-4444-555555555555'
res=[]
def check(nom,cond,info=''): res.append(bool(cond)); print(('OK   ' if cond else 'ÉCHEC'),nom,info)
DOC="""(no,hash)=>({kind:'devis',no:no,date:'2026-11-09',validity:'2026-12-09',client:{name:'Jean Mukendi',address:'Gombe, Kinshasa',phone:'0812345678',email:'jean@example.com'},
  project:'Villa R+1 Limete',place:'Kinshasa',cur:'USD',
  lines:[['Maçonnerie murs','m2',120,14,1680,0],['Dalle béton armé','m2',48,38,1824,0]],
  T:{taux:2800,sub:3504,subfc:0,imp:0,impv:0,impfc:0,tot:3504,totfc:0},total:3504,note:'',title:'',noLogo:true,logo:'',visa:''})"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':900,'height':1000}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('dialog',lambda d:d.accept())
    exbui_auto(pg)
    pg.goto('http://127.0.0.1:8795/index.html'); pg.wait_for_timeout(2500)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')
    pg.evaluate("""async(a)=>{
      window.__calls=[]; window.__opened=[]; window.__fail=false;
      window.EXBDB.org=()=>a.org; window.EXBDB.can=()=>true;
      window.exbSb.isIn=()=>true;
      window.open=(u)=>{window.__opened.push(String(u));return null};
      window.exbSb.api=async(path,opt)=>{opt=opt||{};let body=opt.body;if(body instanceof Blob)body={blob:body.size,type:body.type};else if(typeof body==='string'){try{body=JSON.parse(body)}catch(e){}}
        window.__calls.push({path,method:opt.method||'GET',body});
        if(window.__fail)throw new Error('serveur indisponible');
        if(/rpc\\/devis_public_publier/.test(path)){window.__n=(window.__n||0)+1;return{ok:true,ref:'EXD-2026-001',code:'A1B2C3D4E5',ancien_token:window.__n>1?'c'.repeat(32):null}}
        if(/rpc\\/devis_public_lister/.test(path))return[{ref:'EXD-2026-001',code:'A1B2C3D4E5',devis_no:'DEV-2026-001',client:'Jean Mukendi',projet:'Villa R+1 Limete',montant:'3 504,00 USD',actif:true,maj_le:'2026-11-09T10:00:00Z'}];
        if(/rpc\\/devis_public_retirer/.test(path))return{ok:true,token:'b'.repeat(32),devis_no:'DEV-2026-001'};
        if(/object\\/list\\//.test(path))return[{name:'devis.pdf'}];
        return{}};
      window.confirm=()=>true;
      window.mkdoc=eval(a.doc);
    }""",{'org':ORG,'doc':DOC})
    check('module chargé',pg.evaluate("!!(window.EXBDEVPUB&&window.EXBDocs&&window.EXBPUB&&window.EXBPUB.util)"))

    # 1) génération d'un devis => publication AUTOMATIQUE
    r=pg.evaluate("async()=>{const r=await window.EXBDocs.build(window.mkdoc('DEV-2026-001'));return{pages:r.pages,size:r.blob.size,type:r.blob.type}}")
    check('PDF du devis généré normalement',r['type']=='application/pdf' and r['size']>1500,str(r))
    pg.wait_for_function("window.__calls.some(c=>/rpc\\/devis_public_publier/.test(c.path))",timeout=20000); pg.wait_for_timeout(500)
    calls=pg.evaluate('window.__calls')
    up=[c for c in calls if '/storage/v1/object/exb-devis-publics/' in c['path']]
    check('PDF envoyé dans <org>/<jeton 32 car.>/devis.pdf',len(up)==1 and re.fullmatch(r'/storage/v1/object/exb-devis-publics/'+ORG+r'/[a-f0-9]{32}/devis\.pdf',up[0]['path']) and up[0]['body']['type']=='application/pdf',up[0]['path'][-48:] if up else '')
    rp=[c for c in calls if 'devis_public_publier' in c['path']][0]['body']
    check('appel serveur : n°, client, projet, montant, validité',rp['p_no']=='DEV-2026-001' and rp['p_client']=='Jean Mukendi' and rp['p_projet']=='Villa R+1 Limete' and rp['p_montant']=='3 504,00 USD' and rp['p_validite']=='Valable jusqu’au 09/12/2026' and rp['p_org']==ORG,str({k:rp[k] for k in('p_no','p_client','p_montant','p_validite')}))
    check('aperçu JPEG (1re page du devis)',str(rp['p_apercu']).startswith('data:image/jpeg;base64,') and len(rp['p_apercu'])>2000,str(len(rp['p_apercu'] or '')))
    check('document : chemin = jeton, kind devis',rp['p_docs'][0]['fichier']==ORG+'/'+rp['p_token']+'/devis.pdf' and rp['p_docs'][0]['kind']=='devis')
    check('référence mémorisée (même QR à la republication)',pg.evaluate("JSON.parse(localStorage.getItem('exb_devpub_map'))['DEV-2026-001'].ref")=='EXD-2026-001')

    # 2) même PDF : pas de republication ; PDF modifié : republication + suppression de l'ancien dossier
    pg.evaluate("window.__calls.length=0")
    pg.evaluate("async()=>{await window.EXBDocs.build(window.mkdoc('DEV-2026-001'))}"); pg.wait_for_timeout(1500)
    check('devis inchangé : aucun nouvel envoi',not any('devis_public_publier' in c['path'] for c in pg.evaluate('window.__calls')))
    pg.evaluate("async()=>{const d=window.mkdoc('DEV-2026-001');d.lines[0][2]=150;d.lines[0][4]=2100;d.T.tot=3924;d.total=3924;await window.EXBDocs.build(d)}")
    pg.wait_for_function("window.__calls.some(c=>/rpc\\/devis_public_publier/.test(c.path))",timeout=20000); pg.wait_for_timeout(800)
    names=[c['path'] for c in pg.evaluate('window.__calls')]
    check('devis modifié : republié (même référence côté serveur, nouveau PDF)',sum('devis_public_publier' in n for n in names)==1 and any(re.search(r'devis\.pdf$',n) for n in names))
    check('ancien PDF supprimé après republication',any(n=='/storage/v1/object/exb-devis-publics' for n in names))

    # 3) interface « Suivi et envoi » : bouton QR + WhatsApp avec le LIEN
    pg.evaluate("window.__calls.length=0;window.__opened.length=0")
    pg.evaluate("""()=>window.EXBDocs.open({no:'DEV-2026-001',client:'Jean Mukendi',phone:'0812345678',email:'jean@example.com',getDoc:async()=>window.mkdoc('DEV-2026-001')})""")
    pg.wait_for_selector('#bportail',timeout=5000)
    check('bouton « QR / lien client » présent + libellés (lien)','QR / lien client' in pg.inner_text('#bportail') and 'WhatsApp (lien)' in pg.inner_text('#bwa'))
    pg.click('#bportail'); pg.wait_for_selector('#dpQr',timeout=45000)
    txt=pg.inner_text('#exbDevPub')
    check('résultat : référence + code formaté',('EXD-2026-001' in txt) and ('A1B2C-3D4E5' in txt))
    lk=pg.input_value('#dpLink'); check('lien du QR = /plan?ref=EXD-…&k=…',re.fullmatch(r'https?://[^ ]+/plan\?ref=EXD-2026-001&k=A1B2C3D4E5',lk) is not None,lk)
    check('QR image générée',pg.evaluate("document.getElementById('dpQr').src.startsWith('data:image/png')"))
    pg.click('#dpWa'); wa=pg.evaluate('window.__opened[window.__opened.length-1]')
    check('WhatsApp : numéro du client (243…) + lien du portail + code',wa.startswith('https://wa.me/243812345678?text=') and 'plan%3Fref%3DEXD-2026-001%26k%3DA1B2C3D4E5' in wa and 'A1B2C-3D4E5' in wa,wa[:120])
    check('bouton Imprimer la fiche QR + liste',pg.locator('#dpPr').count()==1 and pg.locator('#dpLs').count()==1)
    pg.evaluate("window.__printed=null;window.EXBPrint.html=(t,h)=>{window.__printed={t:t,h:h}}")
    pg.click('#dpPr'); pg.wait_for_timeout(500)
    pr=pg.evaluate('window.__printed')
    check('fiche A4 « VOTRE DEVIS » : QR + référence + code + 3 étapes adaptées',pr and pr['t']=='QR-Devis-EXD-2026-001' and 'VOTRE DEVIS' in pr['h'] and 'Devis N° DEV-2026-001' in pr['h'] and 'COMMENT TÉLÉCHARGER VOTRE DEVIS' in pr['h'] and 'A1B2C-3D4E5' in pr['h'] and 'data:image/png' in pr['h'] and 'DOSSIER DE PLANS' not in pr['h'],(pr or {}).get('t'))
    # bouton e-mail de la fiche d'envoi
    pg.evaluate("window.__opened.length=0"); pg.click('#dpX'); pg.wait_for_selector('#bml',timeout=3000); pg.evaluate("()=>{const l=document.getElementById('exbLock');if(l)l.remove()}")  # l'écran de licence du banc peut apparaître sous charge : sans rapport avec ce test
    pg.click('#bml'); pg.wait_for_function("window.__opened.length>0",timeout=20000)
    ml=pg.evaluate('window.__opened[0]')
    check('E-mail : adresse du client + lien du portail (pas de PDF joint)',ml.startswith('mailto:jean%40example.com') and 'plan%3Fref%3DEXD-2026-001' in ml,ml[:100])

    # 4) liste + retrait
    pg.evaluate("window.__calls.length=0;window.EXBDEVPUB.list()"); pg.wait_for_selector('#exbDevPub table',timeout=5000)
    check('liste des devis publiés + case « publication automatique »',('EXD-2026-001' in pg.inner_text('#exbDevPub')) and pg.locator('#dpAuto').is_checked())
    pg.click('#exbDevPub .dpR'); pg.wait_for_timeout(1500)
    names=[c['path'] for c in pg.evaluate('window.__calls')]
    check('retrait : fonction serveur + suppression des fichiers publics',any('devis_public_retirer' in n for n in names) and any('object/list/exb-devis-publics' in n for n in names) and any(n=='/storage/v1/object/exb-devis-publics' for n in names))
    check('retrait : référence locale oubliée (republication ultérieure possible)',pg.evaluate("!JSON.parse(localStorage.getItem('exb_devpub_map')||'{}')['DEV-2026-001']"))

    # 5) option « publication automatique » désactivée
    pg.evaluate("localStorage.setItem('exb_devpub_auto','0');window.__calls.length=0")
    pg.evaluate("async()=>{await window.EXBDocs.build(window.mkdoc('DEV-2026-002'))}"); pg.wait_for_timeout(1500)
    check('auto désactivée : rien n\'est envoyé',not any('devis_public' in c['path'] or 'exb-devis-publics' in c['path'] for c in pg.evaluate('window.__calls')))
    pg.evaluate("localStorage.removeItem('exb_devpub_auto')")

    # 6) hors connexion : PDF gardé puis publié au retour de la connexion
    pg.evaluate("window.exbSb.isIn=()=>false;window.__calls.length=0")
    pg.evaluate("async()=>{await window.EXBDocs.build(window.mkdoc('DEV-2026-003'))}"); pg.wait_for_timeout(1500)
    check('hors connexion : mis en attente, aucun appel serveur',pg.evaluate('window.EXBDEVPUB.pending()')==1 and not pg.evaluate('window.__calls.length'))
    pg.evaluate("window.exbSb.isIn=()=>true"); pg.evaluate("window.EXBDEVPUB.flush()")
    pg.wait_for_function("window.__calls.some(c=>/rpc\\/devis_public_publier/.test(c.path))",timeout=20000); pg.wait_for_timeout(800)
    rq=[c for c in pg.evaluate('window.__calls') if 'devis_public_publier' in c['path']][0]['body']
    check('retour de connexion : devis en attente publié automatiquement',rq['p_no']=='DEV-2026-003' and pg.evaluate('window.EXBDEVPUB.pending()')==0)

    # 7) serveur sans le script SQL : message clair, PDF non gêné
    pg.evaluate("""()=>{window.__calls.length=0;window.exbSb.api=async(path,opt)=>{window.__calls.push({path});if(/devis_public_publier/.test(path))throw new Error('Could not find the function public.devis_public_publier in the schema cache');return{}}}""")
    r=pg.evaluate("async()=>{const r=await window.EXBDocs.build(window.mkdoc('DEV-2026-004'));return r.blob.size}")
    pg.wait_for_function("window.EXBDEVPUB.lastError()!==''",timeout=15000)
    check('fonction SQL absente : PDF généré quand même + message clair',r>1500 and 'migration-v141o-devis-publics.sql' in pg.evaluate('window.EXBDEVPUB.lastError()'),pg.evaluate('window.EXBDEVPUB.lastError()')[:80])
    check('pas d\'erreur JS',not errs,str(errs[:2])); b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
