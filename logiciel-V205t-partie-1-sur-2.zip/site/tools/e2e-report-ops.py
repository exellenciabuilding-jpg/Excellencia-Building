#!/usr/bin/env python3
"""Test navigateur de l'onglet « 🔁 Report RH / Stock » (V164). Usage, depuis le dossier du site : python3 tools/e2e-report-ops.py"""
import http.server, threading, socketserver, os, functools
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200]))
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    ok(a.evaluate("typeof EXBRO==='object'"),'module chargé')
    a.evaluate("window.exbConfirm=()=>Promise.resolve(true);window.exbPrompt=()=>Promise.resolve('Erreur de saisie')")
    a.evaluate("save('exb_ro_cfg',{auto:false,base:[]})")
    a.evaluate("""()=>{exbProjects.push({id:'PX',name:'Chantier test',budget:1000,progress:10});exbSave(EXB_ECO_KEYS.projects,exbProjects);
      exbHr.push({id:'H1',name:'Paul'});exbSave(EXB_ECO_KEYS.hr,exbHr);
      exbStock.push({id:'S1',name:'Ciment',unit:'sac',qty:100,min:0,supplier:''});exbSave(EXB_ECO_KEYS.stock,exbStock);
      save('exb_timesheets',[{id:'T1',worker_id:'H1',worker_name:'Paul',project_id:'PX',date:'2026-11-02',days:1,rate:20,cost:20,cash_id:''},{id:'T2',worker_id:'HX',worker_name:'Inconnu',project_id:'PX',date:'2026-11-03',days:1,rate:20,cost:20,cash_id:''}])}""")
    a.evaluate("show('plangantt');EXBPL.pid('PX');EXBPL.tab('r')"); a.wait_for_timeout(500)
    t=a.inner_text('#exbpl_box'); ok('1 à reporter' in t and 'sans fiche Personnel' in t,'aperçu : 1 à reporter, 1 sans fiche')
    a.evaluate("EXBRO.reporter()"); a.wait_for_timeout(600)
    ok(a.evaluate("load('exb_hr_presences',[]).length")==1,'1 présence créée (ouvrier sans fiche non deviné)')
    a.evaluate("EXBRO.reporter()"); a.wait_for_timeout(400)
    ok(a.evaluate("load('exb_hr_presences',[]).length")==1,'second report : pas de doublon')
    ok(a.evaluate("load('exb_payroll',[]).length")==0,'paie non touchée')
    a.evaluate("document.getElementById('exbro_it').value='S1';document.getElementById('exbro_q').value='30';EXBRO.sortie()"); a.wait_for_timeout(600)
    ok(a.evaluate("exbStock.find(s=>s.id==='S1').qty")==70 and a.evaluate("exbStockMoves.some(m=>m.type==='out'&&m.project_id==='PX')"),'sortie : stock 100 → 70, mouvement lié au projet')
    a.evaluate("document.getElementById('exbro_q').value='500';EXBRO.sortie()"); a.wait_for_timeout(500)
    ok(a.evaluate("exbStock.find(s=>s.id==='S1').qty")==70,'stock insuffisant refusé')
    a.evaluate("EXBRO.annulerS(exbStockMoves.find(m=>m.source==='pm'&&m.type==='out').id)"); a.wait_for_timeout(600)
    ok(a.evaluate("exbStock.find(s=>s.id==='S1').qty")==100,'annulation : stock rétabli')
    a.evaluate("EXBRO.annulerP(load('exb_hr_presences',[])[0].id)"); a.wait_for_timeout(500)
    ok(a.evaluate("load('exb_hr_presences',[])[0].annule!==undefined"),'annulation du report conservée avec motif')
    # --- report automatique ---
    a.evaluate("EXBRO.setAuto(true)"); a.wait_for_timeout(400)
    n0=a.evaluate("load('exb_hr_presences',[]).length")
    a.evaluate("save('exb_timesheets',load('exb_timesheets',[]).concat([{id:'T3',worker_id:'H1',worker_name:'Paul',project_id:'PX',date:'2026-11-05',days:1,rate:20,cost:20,cash_id:''}]))"); a.wait_for_timeout(700)
    ok(a.evaluate("load('exb_hr_presences',[]).length")==n0+1 and a.evaluate("load('exb_hr_presences',[]).slice(-1)[0].par")=='automatique','nouveau pointage reporté automatiquement')
    ok(a.evaluate("load('exb_hr_presences',[]).filter(p=>p.cle==='TS:T1'&&!p.annule).length")==0,'ancien pointage (avant activation) non reporté')
    a.evaluate("save('exb_timesheets',load('exb_timesheets',[]).concat([{id:'T4',worker_id:'HX',worker_name:'Inconnu',project_id:'PX',date:'2026-11-06',days:1,rate:20,cost:20,cash_id:''}]))"); a.wait_for_timeout(600)
    ok(a.evaluate("load('exb_hr_presences',[]).filter(p=>p.cle==='TS:T4').length")==0,'ouvrier sans fiche : pas de report automatique')
    a.evaluate("EXBRO.setAuto(false)"); a.wait_for_timeout(300)
    a.evaluate("save('exb_timesheets',load('exb_timesheets',[]).concat([{id:'T5',worker_id:'H1',worker_name:'Paul',project_id:'PX',date:'2026-11-07',days:1,rate:20,cost:20,cash_id:''}]))"); a.wait_for_timeout(600)
    ok(a.evaluate("load('exb_hr_presences',[]).filter(p=>p.cle==='TS:T5').length")==0,'réglage désactivé : rien')
    ok(a.evaluate("load('exb_payroll',[]).length")==0,'paie toujours intacte')
    ok(not ae,'0 erreur JavaScript '+str(ae[:2]))
    b.close()
print('ÉCHEC' if fails else 'OK'); raise SystemExit(1 if fails else 0)
