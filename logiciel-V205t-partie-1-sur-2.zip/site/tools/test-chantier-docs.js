/* V141r — test du module d'envoi au chantier avec un serveur simulé (sans navigateur). node tools/test-chantier-docs.js */
const fs = require('fs'), vm = require('vm'), nassert = require('assert');
const assert = Object.assign((v, m) => nassert(v, m), nassert, { deepStrictEqual: (a, b) => nassert.strictEqual(JSON.stringify(a), JSON.stringify(b)) });
const store = {}, calls = [], db = {};
let admin = true;
const win = { navigator: { onLine: true }, crypto: require('crypto').webcrypto, console, setTimeout };
win.window = win; win.document = {}; win.navigator = { onLine: true };
win.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
win.notify = () => {};
win.exbSb = {
  isIn: () => true,
  api: async (p, o) => {
    o = o || {}; calls.push([o.method || 'GET', p]);
    if (p.startsWith('/storage/v1/object/exb-chantier-docs/') && o.method === 'POST') { db[p.split('/object/exb-chantier-docs/')[1]] = 1; return {}; }
    if (p === '/storage/v1/object/exb-chantier-docs' && o.method === 'DELETE') { JSON.parse(o.body).prefixes.forEach(x => delete db[x]); return []; }
    if (p.endsWith('/rpc/chantier_liste')) return [{ id: '11111111-1111-1111-1111-111111111111', name: 'Villa Lubumbashi', code: 'C1' }];
    if (p.endsWith('/rpc/chantier_doc_publier')) {
      const b = JSON.parse(o.body);
      if (!admin) return { ok: false, erreur: 'Réservé aux administrateurs.' };
      const k = b.p_site + '|' + b.p_no, old = db['row:' + k];
      db['row:' + k] = b.p_fichier;
      return { ok: true, id: 'x', ancien_fichier: old && old !== b.p_fichier ? old : null };
    }
    throw new Error('inattendu ' + p);
  }
};
vm.createContext(win);
vm.runInContext(fs.readFileSync(__dirname + '/../exb-chantier-docs.js', 'utf8'), win);
const C = win.EXBCHDOCS, S = '11111111-1111-1111-1111-111111111111';
const blob = { size: 20480, type: 'application/pdf' };
const note = { genre: 'note', no: 'NCS-2026-001', titre: 'Poutre P1', projet: 'Villa Lubumbashi', indice: 'B', statut: 'Émis', hash: 'h1' };
(async () => {
  let r = await C.send(note, blob, [S], 'À appliquer demain');
  assert.deepStrictEqual(r.ok, [S]); assert.strictEqual(r.ko.length, 0);
  const files1 = Object.keys(db).filter(k => !k.startsWith('row:')); assert.strictEqual(files1.length, 1);
  assert(/^11111111-1111-1111-1111-111111111111\/[a-f0-9]{32}\/note-de-calcul\.pdf$/.test(files1[0]), files1[0]);
  assert.deepStrictEqual(C.info(note.no).sites, [S]);
  // même contenu : rien n'est renvoyé
  const n0 = calls.length; assert.strictEqual(await C.autoUpdate(note, blob), null); assert.strictEqual(calls.length, n0);
  // nouvel indice : le fichier est REMPLACÉ, l'ancien supprimé
  const up = await C.autoUpdate(Object.assign({}, note, { indice: 'C', hash: 'h2' }), blob);
  assert.deepStrictEqual(up.ok, [S]);
  const files2 = Object.keys(db).filter(k => !k.startsWith('row:')); assert.strictEqual(files2.length, 1); assert.notStrictEqual(files2[0], files1[0]);
  // plan (autre genre / extension)
  await C.send({ genre: 'plan', no: 'EXB-PLN-001', hash: 'p', titre: 'Plan' }, { size: 10, type: 'image/png' }, [S]);
  assert(Object.keys(db).some(k => /\/plan\.png$/.test(k)));
  // refus serveur : le fichier téléversé est nettoyé
  admin = false; const before = Object.keys(db).filter(k => !k.startsWith('row:')).length;
  r = await C.send({ genre: 'pex', no: 'PEX-1', hash: 'z' }, blob, [S]);
  assert.strictEqual(r.ok.length, 0); assert.strictEqual(r.ko.length, 1); assert(/administrateur/i.test(r.ko[0].erreur));
  assert.strictEqual(Object.keys(db).filter(k => !k.startsWith('row:')).length, before);
  // hors connexion
  win.navigator.onLine = false; r = await C.send(note, blob, [S]); assert.strictEqual(r.ok.length, 0); assert.strictEqual(r.ko.length, 1);
  // désactivation de la mise à jour automatique
  win.navigator.onLine = true; admin = true; store.exb_chdocs_auto = '0';
  assert.strictEqual(await C.autoUpdate(Object.assign({}, note, { hash: 'h3' }), blob), null);
  console.log('OK — 8 vérifications du module chantier');
})().catch(e => { console.error('ÉCHEC', e); process.exit(1); });
