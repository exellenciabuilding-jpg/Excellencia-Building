# V205 lot 2 — Espace Comptable : lien /comptable, menu limité, accès par fonction, T03 (paiement confirmé) et T04 (devis sans paiement)
import http.server, threading, functools, os, sys, datetime
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
TODAY = datetime.date.today().isoformat()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    boot('comptable.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'comptable', 'le lien /comptable ouvre l\'Espace Comptable')
    t('espace=' not in pg.url, 'le paramètre ?espace= est retiré de l\'adresse')
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(600)
    menu = pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)")
    mt = ' | '.join(menu)
    t('Finances' in mt and 'Comptabilité' in mt and 'Reçus de paiement' in mt, 'le menu contient Finances, Comptabilité, Reçus')
    t(not any(x in mt for x in ['Paie', 'Projets', 'Stock', 'Apprenants', 'Formation']), 'le menu ne contient ni Paie & RH, ni Projets, ni Stock, ni Formation')
    t('Quitter l’espace' in mt, 'bouton « Quitter l\'espace » présent')
    # T04 : devis sans paiement -> aucun encaissement
    pg.evaluate("save('exb_quotes',[{id:'Q1',number:'D-1',total:5000,currency:'USD',status:'Accepté',date:'%s'}])" % TODAY)
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(600)
    rows = pg.evaluate("EXBLIEN.ledger().rows.length")
    t(rows == 0, 'T04 : un devis accepté sans paiement ne crée aucun encaissement (%s)' % rows)
    t('0 $' in pg.evaluate("document.querySelector('#xhK .xh-k b').innerText"), 'T04 : « Recettes du mois » reste à 0 $')
    # T03 : paiement enregistré -> visible au tableau de bord, horodaté
    pg.evaluate("save('exb_invoices',[{id:'I1',number:'F-1',currency:'USD',total:1000,date:'%s',payments:[{id:'pay1',date:'%s',amount:300,method:'Espèces'}]}])" % (TODAY, TODAY))
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(800)
    r2 = pg.evaluate("EXBLIEN.ledger().rows")
    t(len(r2) == 1 and r2[0]['amount'] == 300 and r2[0]['date'] == TODAY, 'T03 : le paiement est inscrit au registre avec sa date')
    k1 = pg.evaluate("document.querySelector('#xhK .xh-k b').innerText")
    t('300' in k1.replace(' ', '').replace('\xa0', ''), 'T03 : « Recettes du mois » affiche 300 $ (%s)' % k1)
    t('300' in pg.evaluate("document.getElementById('xhAct').innerText"), 'T03 : le paiement figure dans les dernières opérations')
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(500)
    cr = pg.evaluate("document.getElementById('exbCrumb').innerText")
    t('Espace Comptable' in cr and 'Formation' not in cr, 'fil d\'Ariane dans l\'espace : « Accueil › Espace Comptable › … » (%s)' % cr.replace('\n', ' '))
    # accès par fonction
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'magasinier',label:'Magasinier'})")
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(500)
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False and 'Accès refusé' in pg.evaluate("document.getElementById('xhK').innerText"), 'un magasinier connecté est refusé dans l\'Espace Comptable')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'un comptable est accepté')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'admin',fonction:'polyvalent',label:'Administrateur'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'l\'administrateur est accepté')
    pg.evaluate("EXB_SHELL.quitEspace()"); pg.wait_for_timeout(3500)
    t(pg.evaluate("localStorage.getItem('exb_espace')") is None, 'quitter l\'espace restaure le menu complet')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
