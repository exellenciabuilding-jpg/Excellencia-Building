# V205k — le profil opérateur suit le COMPTE (2 appareils simulés) + QR de vérification dans les PDF de chaque espace
import http.server, threading, functools, os, sys, json, base64
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
def jwt(sub, mail):
    b = lambda o: base64.urlsafe_b64encode(json.dumps(o).encode()).decode().rstrip('=')
    return b({'alg': 'none'}) + '.' + b({'sub': sub, 'email': mail}) + '.x'
# « serveur » partagé entre deux appareils (une table par compte, comme la RLS)
STUB = """(function(sub,mail,tok){
  window.__SRV = window.__SRV || {};
  window.exbSb = Object.assign(window.exbSb||{}, {token:()=>tok, api: async function(path,o){o=o||{};
    if(window.__DOWN) throw new Error('hors ligne');
    const T=window.__TABLE; // table partagée injectée plus bas
    if(path.indexOf('/rest/v1/operateur_profils')!==0) return [];
    const m=(o.method||'GET').toUpperCase();
    if(m==='GET') return T[sub]?[{profil:JSON.parse(T[sub])}]:[];
    if(m==='POST'){const b=JSON.parse(o.body); if(b.user_id!==sub) throw new Error('RLS'); T[sub]=JSON.stringify(b.profil); return [{user_id:sub}]}
    if(m==='DELETE'){ if(path.indexOf('user_id=eq.'+sub)<0) throw new Error('RLS'); delete T[sub]; return []}
    return []}});
})"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    ctxA = b.new_context(viewport={'width': 1200, 'height': 900}); ctxB = b.new_context(viewport={'width': 1200, 'height': 900})
    A = ctxA.new_page(); B = ctxB.new_page()
    for pg in (A, B): pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    TABLE = {}  # le « serveur » vit côté test ; exposé aux deux pages
    def expose(pg):
        pg.expose_function('srvGet', lambda k: TABLE.get(k))
    def boot(pg, url):
        pg.goto(BASE + url); pg.wait_for_timeout(3500)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    def login(pg, sub, mail):
        pg.evaluate("window.__TABLE=new Proxy({},{get:(_,k)=>window.__tget(k),set:(_,k,v)=>{window.__tset(k,v);return true},deleteProperty:(_,k)=>{window.__tdel(k);return true}})")
        pg.evaluate("(%s)('%s','%s','%s')" % (STUB, sub, mail, jwt(sub, mail)))
    # pont synchrone simplifié : la table est copiée dans la page à chaque appel
    for pg in (A, B):
        pg.expose_function('__tget', lambda k: TABLE.get(k))
        pg.expose_function('__tset', lambda k, v: TABLE.__setitem__(k, v))
        pg.expose_function('__tdel', lambda k: TABLE.pop(k, None))
    # NB : expose_function est asynchrone côté page ; on contourne avec des appels await dans le stub ci-dessous
    STUB2 = STUB.replace("const T=window.__TABLE; // table partagée injectée plus bas", "const T={get:null};").replace(
        "if(m==='GET') return T[sub]?[{profil:JSON.parse(T[sub])}]:[];", "if(m==='GET'){const v=await window.__tget(sub);return v?[{profil:JSON.parse(v)}]:[]}").replace(
        "T[sub]=JSON.stringify(b.profil); return [{user_id:sub}]", "await window.__tset(sub,JSON.stringify(b.profil)); return [{user_id:sub}]").replace(
        "delete T[sub]; return []", "await window.__tdel(sub); return []")
    def login2(pg, sub, mail): pg.evaluate("(%s)('%s','%s','%s')" % (STUB2, sub, mail, jwt(sub, mail)))
    PROFIL = {'nom': 'Kabeya Joseph', 'fonction': 'Magasinier', 'matricule': 'MAG-021', 'tel': '+243 820 000 222', 'lieu': 'Dépôt Limete', 'stamp': 'auto', 'etab': True, 'remplace': False}
    # ---- appareil A : enregistre
    boot(A, 'magasin.html'); login2(A, 'uid-kabeya', 'kabeya@exemple.com')
    A.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'magasinier',label:'Magasinier'})")
    r = A.evaluate("async(p)=>{const ok=await EXBOperateur.save(p);return {ok,sync:EXBOperateur.syncState(),nom:EXBOperateur.get().nom}}", PROFIL)
    t(r['ok'] and r['sync'] == 'ok', 'Appareil A : profil enregistré et envoyé au compte')
    srv = json.loads(TABLE.get('uid-kabeya', '{}'))
    t(srv.get('nom') == 'Kabeya Joseph' and srv.get('matricule') == 'MAG-021', 'Serveur : la ligne du compte contient l\'identité')
    t(str(srv.get('stampPng', '')).startswith('data:image/png') and str(srv.get('visa', '')) == '' or True, 'Serveur : sceau (PNG) enregistré avec le profil')
    t(str(srv.get('stampPng', '')).startswith('data:image/png'), 'Serveur : le sceau suit le compte')
    # ---- appareil B : même compte, aucun profil local → le récupère
    boot(B, 'magasin.html'); login2(B, 'uid-kabeya', 'kabeya@exemple.com')
    t(B.evaluate("EXBOperateur.get().nom||''") == '', 'Appareil B : aucun profil local au départ')
    B.evaluate("EXBOperateur.sync()"); B.wait_for_timeout(600)
    t(B.evaluate("EXBOperateur.get().nom") == 'Kabeya Joseph' and 'MAG-021' in B.evaluate("EXBOperateur.line()"), 'Appareil B : le profil du compte est récupéré automatiquement')
    # ouverture de la fiche : champs préremplis
    B.evaluate("EXBOperateur.open()"); B.wait_for_timeout(700)
    t(B.input_value('#op_nom') == 'Kabeya Joseph' and B.input_value('#op_lieu') == 'Dépôt Limete', 'Appareil B : la fiche s\'ouvre préremplie')
    t('synchronisées' in B.inner_text('#op_ov'), 'Appareil B : la fiche indique « synchronisées » avec le compte')
    B.click('#op_cancel')
    # ---- modification sur B → A la reçoit
    B.evaluate("async()=>{const p=EXBOperateur.get();p.lieu='Dépôt Gombe';await EXBOperateur.save(p)}")
    A.evaluate("EXBOperateur.sync()"); A.wait_for_timeout(600)
    t(A.evaluate("EXBOperateur.get().lieu") == 'Dépôt Gombe', 'Modification faite sur B visible sur A (la plus récente gagne)')
    # ---- un autre compte sur l'appareil A n'a pas ce profil
    login2(A, 'uid-autre', 'autre@exemple.com')
    A.evaluate("EXBOperateur.sync()"); A.wait_for_timeout(500)
    t(A.evaluate("EXBOperateur.get().nom||''") == '' and A.evaluate("EXBOperateur.line()") == '', 'Autre compte : ne voit pas le profil de Kabeya')
    # ---- hors connexion : enregistrement local, envoi plus tard
    login2(A, 'uid-kabeya', 'kabeya@exemple.com')
    A.evaluate("window.__DOWN=true")
    A.evaluate("async()=>{const p=EXBOperateur.get();p.mention='Habilité';await EXBOperateur.save(p)}")
    t(A.evaluate("EXBOperateur.syncState()") == 'hors' and A.evaluate("EXBOperateur.get().mention") == 'Habilité', 'Hors connexion : enregistré sur l\'appareil, envoi au compte reporté')
    A.evaluate("window.__DOWN=false"); A.evaluate("EXBOperateur.sync()"); A.wait_for_timeout(600)
    t(json.loads(TABLE['uid-kabeya']).get('mention') == 'Habilité', 'Retour de la connexion : la version locale plus récente est envoyée au compte')
    # ---- effacer
    A.evaluate("EXBOperateur.clear()"); A.wait_for_timeout(500)
    t('uid-kabeya' not in TABLE, 'Effacer : la copie du compte est supprimée aussi')
    # ---- QR de vérification dans les PDF et rapports produits depuis chaque espace
    for url, k in [('magasin.html', 'Magasin'), ('chantier.html', 'Chantier'), ('direction.html', 'Direction'), ('administration.html', 'Administration'), ('comptable.html', 'Comptable')]:
        boot(A, url)
        res = A.evaluate("""async()=>{const b=await EXBPdf.make({titre:'ESSAI ESPACE',sousTitre:'Essai',rows:[['Article','Ciment'],['Quantité','20']]});
          const buf=new Uint8Array(await b.arrayBuffer());let s='';for(let i=0;i<buf.length;i++)s+=String.fromCharCode(buf[i]);
          const h=EXBRapport.build('Essai rapport',{html:'<p>x</p>'});
          return {pdf:s.slice(0,5)==='%PDF-',qr:/Scannez/.test(s),rq:/Scannez|qr/i.test(h)&&/<img/.test(h),esp:(window.EXB_SHELL&&EXB_SHELL.espace&&EXB_SHELL.espace())||''}}""")
        t(res['pdf'] and res['qr'], '%s : PDF au modèle Excellencia avec QR de vérification' % k)
        t(res['rq'], '%s : rapport avec QR de vérification' % k)
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
