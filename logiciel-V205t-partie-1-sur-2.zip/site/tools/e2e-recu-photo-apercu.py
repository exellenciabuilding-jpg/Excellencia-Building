# V197 : (1) espace apprenant : « Mes reçus » = nouveau modèle (aperçu + vrai PDF) avec la photo ; (2) logiciel : aperçu et export au nouveau modèle avec photo ; (3) numéro : le reçu créé est bien le nouveau
import os, sys, threading, http.server, functools, base64, io, subprocess, tempfile
from playwright.sync_api import sync_playwright
from PIL import Image
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=D); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8795), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
ok = 0; ko = 0
def chk(c, m):
    global ok, ko
    if c: ok += 1; print('  OK  ', m)
    else: ko += 1; print('  FAIL', m)
im = Image.new('RGB', (120, 160), (40, 90, 200)); bio = io.BytesIO(); im.save(bio, 'JPEG'); PH = 'data:image/jpeg;base64,' + base64.b64encode(bio.getvalue()).decode()
def b64pdf(pg, expr):
    return pg.evaluate("async()=>{const b=await (%s);const r=new FileReader();return await new Promise(o=>{r.onload=()=>o(String(r.result).split(',')[1]);r.readAsDataURL(b)})}" % expr)
def pdf_info(b64, name):
    f = os.path.join(tempfile.gettempdir(), name); open(f, 'wb').write(base64.b64decode(b64))
    try: n = subprocess.run(['pdfinfo', f], capture_output=True, text=True).stdout
    except Exception: n = ''
    return f, n
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 420, 'height': 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('**/supabase-config.js', lambda r: r.fulfill(content_type='application/javascript', body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}'))
    pg.route('http://x.test/**', lambda r: r.fulfill(status=200, content_type='application/json', body='{}'))
    pg.goto('http://127.0.0.1:8795/espace-apprenant.html'); pg.wait_for_timeout(600)
    u = 'http://127.0.0.1:8795/verification.html?c=r~REC-0042~2026-11-14~0~USD~7K2MQ9XA4D'
    pg.evaluate("""async ([u,ph])=>{M='378-734-477';E={photo:ph,nom:'MUKENDI KALALA JEAN',formation:'Robot Structural Analysis',res:[],esp:{frais:{inscription:{montant:'50 USD',statut:'PAYÉ',ref:'REC-0042',date:'2026-11-14',reste_num:0,devise:'USD'},formation:{montant:'200 USD',statut:'MOITIÉ PAYÉE',ref:'REC-0042',date:'2026-11-14',reste_num:100,devise:'USD'},paiements:[]},
      recus:[{no:'REC-0042',formation:'Robot Structural Analysis',date:'2026-11-14',guichetier:'Marie Kabasele',statut:'VALIDE',inscription:{montant:'50 USD',statut:'PAYÉ'},formation_frais:{montant:'200 USD',statut:'MOITIÉ PAYÉE'},url:u}]}};
      document.querySelector('#view').innerHTML=vFrais();await apercusRecus()}""", [u, PH]); pg.wait_for_timeout(600)
    chk(pg.evaluate("()=>{const f=document.querySelector('.rcv iframe');return !!f&&f.srcdoc.includes('REÇU DE PAIEMENT DES FRAIS')&&f.srcdoc.includes('class=\"ph\" src=\"data:image/jpeg')}"), 'espace apprenant : l’aperçu affiché est le nouveau reçu, avec la photo')
    # vrai PDF téléchargé (pas de .html)
    with pg.expect_download(timeout=20000) as dl: pg.evaluate("()=>recuPdf(0)")
    nom = dl.value.suggested_filename; chk(nom.lower().endswith('.pdf'), 'espace apprenant : « Télécharger PDF » donne un fichier .pdf (%s)' % nom)
    f = os.path.join(tempfile.gettempdir(), 'recu-appr.pdf'); dl.value.save_as(f); raw = open(f, 'rb').read()
    chk(raw[:5] == b'%PDF-' and b'/Page' in raw, 'espace apprenant : le fichier est un PDF valide')
    pg2 = b.new_page(viewport={'width': 1300, 'height': 900}); pg2.on('pageerror', lambda e: errs.append(str(e)))
    pg2.goto('http://127.0.0.1:8795/index.html'); pg2.wait_for_timeout(2500)
    r = pg2.evaluate("""async (ph)=>{
      participants.push({participant_id:'P8',name:'ANCIEN PARTICIPANT',matricule:'111-111-111',approval_status:'APPROUVE'});
      participants.push({participant_id:'P9',name:'MUKENDI KALALA JEAN',matricule:'378-734-477',photo:ph,approval_status:'APPROUVE'});
      try{payments.push({participant_id:'P9',participant_name:'MUKENDI KALALA JEAN',amount:50})}catch(e){}
      receipts.length=0; receipts.push({receipt_no:'REC-2026-0001',participant:'ANCIEN PARTICIPANT',participant_id:'P8',matricule:'111-111-111',training:'Robot',created_at:'2026-09-28T10:00:00Z'});
      // enregistrement d'un nouveau reçu pour P9 (chaîne de wrappers du logiciel)
      fillReceiptPicker();const sel=document.getElementById('receiptParticipantSelect');sel.value='P9';sel.dispatchEvent(new Event('change'));
      document.getElementById('rtraining').value='Robot';document.getElementById('registration_fee').value='50 USD';document.getElementById('guichetier').value='Marie Kabasele';
      const avant=receipts.length;
      try{window.saveReceipt()}catch(e){}
      await new Promise(r=>setTimeout(r,700));
      const n=receipts.length, last=receipts[n-1], first=receipts[0];
      const ap=document.getElementById('recuModeleApercu'), f=ap&&ap.querySelector('iframe');
      let pdf=null; try{ pdf=await EXBRecuTFL.pdfBlob(await recuModeleLogiciel(last)); }catch(e){pdf=String(e)}
      return {avant, n, lastNo:last&&last.receipt_no, lastPid:last&&last.participant_id, firstPid:first.participant_id, formNo:document.getElementById('receipt_no').value,
        apercu: !!f && f.srcdoc.includes('REÇU DE PAIEMENT DES FRAIS') && f.srcdoc.includes('class="ph" src="data:image/jpeg'), noDansApercu: !!f && f.srcdoc.includes(last&&last.receipt_no), pdfOk: pdf&&pdf.size>5000}}""", PH)
    print(r)
    chk(r['n'] == r['avant'] + 1, 'logiciel : un nouveau reçu est bien créé')
    chk(r['lastPid'] == 'P9' and r['firstPid'] == 'P8', 'logiciel : le nouveau reçu est lié au participant ; l’ancien reçu n’est plus modifié')
    chk(r['formNo'] == r['lastNo'], 'logiciel : le numéro affiché est celui du reçu enregistré (%s)' % r['lastNo'])
    chk(r['apercu'] and r['noDansApercu'], 'logiciel : l’aperçu à l’écran est le nouveau modèle, avec photo et numéro')
    chk(r['pdfOk'], 'logiciel : PDF direct généré')
    # réparation d'un ancien lien écrasé
    rep = pg2.evaluate("""()=>{receipts.length=0;receipts.push({receipt_no:'REC-2026-0001',participant:'ANCIEN PARTICIPANT',participant_id:'P9',matricule:'378-734-477'});return 1}""")
    chk(not errs, 'aucune erreur JavaScript %s' % errs[:2])
    b.close()
print('\nRésultat : %d réussis, %d échec(s)' % (ok, ko)); sys.exit(1 if ko else 0)
