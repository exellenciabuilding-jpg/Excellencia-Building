/* Tests du module Workflow (node tools/test-workflow.js) — scénarios calculés à la main. */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const store = {}, logs = [], events = [];
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.EXBCore = { audit: { log: (a, o, d) => logs.push(a + '|' + o) }, bus: { emit: (name, p) => events.push(name) } };
const box = { innerHTML: '', querySelectorAll: () => [] }, pane = { innerHTML: '' };
global.document = { readyState: 'loading', addEventListener() {}, getElementById: id => (id === 'wf_box' ? box : id === 'wf_pane' ? pane : null), querySelector: () => null, createElement: () => ({}), body: { appendChild() {} } };
require('../exb-workflow.js');
const W = window.EXBWF, E = W.engine;
ok(W && W.version === 1 && E, 'EXBWF chargé');

const T0 = '2026-11-16T08:00:00.000Z';
const dep = () => ({ id: 'c1', nom: 'Dépense', type: 'depense', steps: [
  { nom: 'Chef de projet', mode: 'sequentiel', approvers: [{ role: 'Chef de projet' }], delaiJours: 2 },
  { nom: 'Direction', mode: 'sequentiel', approvers: [{ role: 'Directeur général' }], delaiJours: 3, seuil: { montant: 1000, devise: 'USD' } }] });
const PAUL = { name: 'Paul', role: 'Chef de projet' }, MARIE = { name: 'Marie', role: 'Chef de projet' }, JEAN = { name: 'Jean', role: 'Directeur général' };

/* ---- validation du circuit ---- */
ok(!E.validateCircuit({ nom: '', steps: [] }).ok, 'circuit vide refusé');
ok(!E.validateCircuit({ nom: 'X', steps: [{ nom: 'a', mode: 'sequentiel', approvers: [], }] }).ok, 'étape sans approbateur refusée');
ok(!E.validateCircuit({ nom: 'X', steps: [{ nom: 'a', mode: 'sequentiel', approvers: [{ name: 'A' }], seuil: { montant: 5, devise: 'USD' } }] }).ok, 'toutes les étapes à seuil : refusé (aucun dossier sans contrôle)');
ok(E.validateCircuit(dep()).ok, 'circuit de dépense valide');
eq(E.parseApprover('fonction: Directeur général'), { role: 'Directeur général' }, 'approbateur par fonction');
eq(E.parseApprover('Marie'), { name: 'Marie' }, 'approbateur par nom');

/* ---- seuils ---- */
const len = (m, dv) => E.start(dep(), { titre: 'T', montant: m, devise: dv }, PAUL, T0, 'WF-2026-0001').dossier.steps.length;
eq(len(500, 'USD'), 1, '500 $ : sous le seuil, une seule étape');
eq(len(1500, 'USD'), 2, '1 500 $ : deux étapes');
eq(len(500, 'CDF'), 2, 'devise différente du seuil : étape appliquée (aucune conversion, prudence)');
ok(!E.start(dep(), { titre: ' ' }, PAUL, T0).ok, 'titre obligatoire');

/* ---- parcours complet 2 étapes ---- */
let r = E.start(dep(), { titre: 'Achat ciment', montant: 1500, devise: 'USD' }, PAUL, T0, 'WF-2026-0001'); let D = r.dossier;
eq(E.pending(D).map(a => a.role), ['Chef de projet'], 'en attente du chef de projet');
eq(D.echeance, '2026-11-18', 'échéance étape 1 = +2 jours');
let x = E.act(D, PAUL, 'approuver', '', { now: T0 });
ok(!x.ok && /Séparation/.test(x.error), 'l\'initiateur ne peut pas approuver son dossier');
x = E.act(D, JEAN, 'approuver', '', { now: T0 }); ok(!x.ok && /pas à vous/.test(x.error), 'le directeur ne peut pas sauter l\'étape 1');
const T1 = '2026-11-17T09:00:00.000Z';
x = E.act(D, MARIE, 'approuver', 'OK budget', { now: T1 }); ok(x.ok && x.event === 'etape', 'étape 1 validée → étape 2'); D = x.dossier;
eq([D.cur, D.status, D.echeance], [1, 'en_cours', '2026-11-20'], 'étape 2 démarrée, échéance +3 jours');
eq(D.history.map(h => h.action), ['soumis', 'approuver'], 'historique : soumis, approuvé');
ok(!E.act(D, MARIE, 'approuver', '', { now: T1 }).ok, 'Marie ne peut pas décider à l\'étape 2');
const T2 = '2026-11-18T10:00:00.000Z';
x = E.act(D, JEAN, 'approuver', '', { now: T2 }); ok(x.ok && x.event === 'valide', 'dossier validé'); D = x.dossier;
eq([D.status, D.fin, D.echeance], ['valide', T2, ''], 'statut validé, date de fin');
ok(!E.act(D, JEAN, 'approuver', '', { now: T2 }).ok, 'dossier validé : plus de décision');
eq(D.history.map(h => h.action), ['soumis', 'approuver', 'approuver', 'valide'], 'historique complet');
const dValide = D;

/* ---- refus et correction : motif obligatoire ---- */
const fresh = () => E.start(dep(), { titre: 'Autre', montant: 1500, devise: 'USD' }, PAUL, T0, 'WF-2026-0002').dossier;
ok(!E.act(fresh(), MARIE, 'refuser', '', { now: T1 }).ok, 'refus sans motif refusé');
ok(!E.act(fresh(), MARIE, 'corriger', 'x', { now: T1 }).ok, 'correction avec motif trop court refusée');
x = E.act(fresh(), MARIE, 'refuser', 'Hors budget', { now: T1 }); ok(x.ok && x.dossier.status === 'refuse' && x.dossier.history[1].motif === 'Hors budget', 'refus motivé : dossier clos');
const dRefus = x.dossier;
x = E.act(fresh(), MARIE, 'corriger', 'Joindre le devis', { now: T1 }); eq(x.dossier.status, 'retourne', 'demande de correction → à corriger');
let Dr = x.dossier;
ok(!E.resubmit(Dr, MARIE, '', T2).ok, 'seul l\'initiateur peut soumettre à nouveau');
x = E.resubmit(Dr, PAUL, 'Devis joint', T2); ok(x.ok, 'resoumission'); Dr = x.dossier;
eq([Dr.version, Dr.cur, Dr.status], [2, 0, 'en_cours'], 'version 2, retour à l\'étape 1');
ok(Dr.history.length === 3 && Dr.history[1].action === 'corriger', 'historique conservé après resoumission');

/* ---- une personne ne valide pas deux étapes ---- */
const C2 = () => ({ id: 'c2', nom: 'Deux étapes même personne', type: 'achat', steps: [{ nom: 'E1', mode: 'sequentiel', approvers: [{ name: 'Marie' }] }, { nom: 'E2', mode: 'sequentiel', approvers: [{ name: 'Marie' }] }] });
let d2 = E.start(C2(), { titre: 'Z' }, { name: 'Zoé' }, T0, 'N').dossier; d2 = E.act(d2, { name: 'Marie' }, 'approuver', '', { now: T1 }).dossier;
ok(/deux étapes/.test(E.act(d2, { name: 'Marie' }, 'approuver', '', { now: T1 }).error), 'distincts : même personne refusée sur 2 étapes');
let c2b = C2(); c2b.distincts = false; d2 = E.start(c2b, { titre: 'Z' }, { name: 'Zoé' }, T0, 'N').dossier; d2 = E.act(d2, { name: 'Marie' }, 'approuver', '', { now: T1 }).dossier;
ok(E.act(d2, { name: 'Marie' }, 'approuver', '', { now: T1 }).ok, 'distincts désactivé : autorisé');

/* ---- parallèle / un seul / séquentiel dans une étape ---- */
const C3 = mode => ({ nom: 'P', type: 'document', steps: [{ nom: 'E1', mode, approvers: [{ name: 'A' }, { name: 'B' }] }, { nom: 'E2', mode: 'sequentiel', approvers: [{ name: 'C' }] }] });
let p = E.start(C3('parallele'), { titre: 'P' }, { name: 'Z' }, T0, 'N').dossier;
eq(E.pending(p).map(a => a.name), ['A', 'B'], 'parallèle : les deux sont attendus');
p = E.act(p, { name: 'B' }, 'approuver', '', { now: T1 }).dossier; eq([p.cur, E.pending(p).map(a => a.name)], [0, ['A']], 'parallèle : encore A');
p = E.act(p, { name: 'A' }, 'approuver', '', { now: T1 }).dossier; eq(p.cur, 1, 'parallèle : étape suivante quand tous ont approuvé');
let u = E.start(C3('un_seul'), { titre: 'U' }, { name: 'Z' }, T0, 'N').dossier;
u = E.act(u, { name: 'A' }, 'approuver', '', { now: T1 }).dossier; eq(u.cur, 1, 'un seul suffit : étape suivante dès la première approbation');
let s = E.start(C3('sequentiel'), { titre: 'S' }, { name: 'Z' }, T0, 'N').dossier;
eq(E.pending(s).map(a => a.name), ['A'], 'séquentiel : seul A est attendu');
ok(!E.act(s, { name: 'B' }, 'approuver', '', { now: T1 }).ok, 'séquentiel : B ne peut pas passer avant A');
s = E.act(s, { name: 'A' }, 'approuver', '', { now: T1 }).dossier; eq(E.pending(s).map(a => a.name), ['B'], 'séquentiel : puis B');

/* ---- délégation ---- */
const dl = [{ de: { role: 'Directeur général' }, a: { name: 'Alice' }, du: '2026-11-16', au: '2026-11-30', actif: true }];
let g = E.act(E.act(fresh(), MARIE, 'approuver', '', { now: T1 }).dossier, { name: 'Alice', role: '' }, 'approuver', 'Pour Jean', { now: T2, delegations: dl });
ok(g.ok && g.dossier.status === 'valide', 'délégataire : décision acceptée');
eq(g.dossier.history[g.dossier.history.length - 2].pour, 'Directeur général', 'historique : « pour le compte de » la fonction remplacée');
const dn = E.start(C2(), { titre: 'Z' }, { name: 'Zoé' }, T0, 'N').dossier;
ok(E.act(dn, { name: 'Alice' }, 'approuver', '', { now: T1, delegations: [{ de: { name: 'Marie' }, a: { name: 'Alice' }, du: '2026-11-01', au: '2026-11-30' }] }).ok, 'délégation d\'une personne nommée');
ok(!E.act(dn, { name: 'Alice' }, 'approuver', '', { now: T1, delegations: [{ de: { name: 'Pierre' }, a: { name: 'Alice' }, du: '2026-11-01', au: '2026-11-30' }] }).ok, 'délégation d\'une autre personne : sans effet');
const g1 = E.act(fresh(), MARIE, 'approuver', '', { now: T1 }).dossier;
ok(!E.act(g1, { name: 'Alice' }, 'approuver', '', { now: T2, delegations: [Object.assign({}, dl[0], { au: '2026-11-17' })] }).ok, 'délégation expirée : refusée');
ok(!E.act(g1, { name: 'Alice' }, 'approuver', '', { now: T2, delegations: [Object.assign({}, dl[0], { actif: false })] }).ok, 'délégation retirée : refusée');

/* ---- échéances, statistiques, numérotation ---- */
const open = fresh(); // échéance 2026-11-18
eq(E.echeances([open], '2026-11-17T12:00:00Z').map(e => [e.etat, e.jours]), [['rappel', 1]], 'rappel à J-1');
eq(E.echeances([open], '2026-11-21T12:00:00Z').map(e => [e.etat, e.jours]), [['retard', 3]], 'retard de 3 jours');
eq(E.echeances([open], '2026-11-10T12:00:00Z'), [], 'rien à signaler en avance');
eq(E.echeances([dValide], '2026-12-30T00:00:00Z'), [], 'dossier validé : aucune échéance');
const S = E.stats([dValide, dRefus, open, Dr], '2026-11-21T12:00:00Z');
eq([S.total, S.par_statut.valide, S.par_statut.refuse, S.par_statut.en_cours, S.en_retard], [4, 1, 1, 2, 2], 'statistiques par statut ; 2 en retard au 21/11 (échéances 18/11 et 20/11)');
eq(S.delai_moyen_jours, 2, 'délai moyen de validation = 2 jours (16 → 18 novembre)');
eq(E.nextNo([{ no: 'WF-2026-0007' }, { no: 'WF-2025-0099' }], 2026), 'WF-2026-0008', 'numérotation par année');
eq(E.tasksFor([open], MARIE, [], T1).length, 1, 'tâches de Marie : 1'); eq(E.tasksFor([open], PAUL, [], T1).length, 0, 'tâches de l\'initiateur : 0');

/* ---- annulation ---- */
ok(!E.cancel(open, MARIE, 'doublon', { now: T1 }).ok, 'annulation par un tiers non admin refusée');
ok(!E.cancel(open, PAUL, '', { now: T1 }).ok, 'annulation sans motif refusée');
ok(E.cancel(open, PAUL, 'doublon', { now: T1 }).ok && E.cancel(open, MARIE, 'doublon', { now: T1, admin: true }).ok, 'annulation par l\'initiateur ou un administrateur');

/* ---- couche stockage / API (mode local) ---- */
store.exb_wf_circuits = JSON.stringify([dep()]);
let a1 = W.submit({ type: 'depense', titre: '<b>Achat</b>', montant: 1500, devise: 'USD', ref: { module: 'caisse', id: 'c9' } });
ok(a1.ok && /^WF-\d{4}-0001$/.test(a1.dossier.no), 'soumission enregistrée, numéro WF-AAAA-0001');
let a2 = W.submit({ type: 'depense', titre: 'Deuxième', montant: 10, devise: 'USD' }); ok(/-0002$/.test(a2.dossier.no), 'numéro suivant');
ok(!W.submit({ type: 'conge', titre: 'x' }).ok, 'aucun circuit pour ce type : refus clair');
ok(JSON.parse(store.exb_wf_dossiers).length === 2, 'deux dossiers dans le stockage');
let dd = W.decide(a1.dossier.id, 'approuver', '', { role: 'Chef de projet' }); ok(dd.ok, 'décision en mode local avec identité choisie');
ok(JSON.parse(store.exb_wf_dossiers)[0].history.slice(-1)[0].verifie === false, 'mode local : « identité non vérifiée » consignée');
ok(logs.some(l => l.startsWith('workflow.soumis')) && logs.some(l => l.startsWith('workflow.etape') || l.startsWith('workflow.decision')), 'journal d\'audit du noyau alimenté');
ok(events.includes('workflow.soumis') && events.includes('workflow.decision'), 'événements publiés sur le bus du noyau');
eq(W.stats().total, 2, 'EXBWF.stats() pour la BI');

/* ---- rendu ---- */
const R = () => { box.innerHTML = ''; pane.innerHTML = ''; W.render(); return box.innerHTML + pane.innerHTML; };
let html = R(); ok(html.length > 200 && /À valider/.test(html), 'rendu de l\'écran');
ok(!html.includes('<b>Achat</b>') && html.includes('&lt;b&gt;Achat'), 'titre échappé (pas d\'injection HTML)');

console.log('Workflow : ' + n + ' contrôles OK');
