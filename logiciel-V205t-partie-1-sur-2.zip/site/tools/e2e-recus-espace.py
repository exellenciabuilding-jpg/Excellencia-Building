import json, threading, http.server, functools, os
from playwright.sync_api import sync_playwright
D=__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D)
H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8791),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(accept_downloads=True); pg=ctx.new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}'))
    pg.route('http://x.test/**',lambda r:r.fulfill(status=200,content_type='application/json',body='{}'))
    # ---- 1) espace apprenant : affichage des reçus
    pg.goto('http://127.0.0.1:8791/espace-apprenant.html'); pg.wait_for_timeout(500)
    url='http://127.0.0.1:8791/verification.html?c=p~REC-0001~~~~abc123def4~Jean_Kasongo'
    r=pg.evaluate("""(u)=>{E={nom:'Jean Kasongo',formation:'Maçonnerie',res:[],esp:{frais:{inscription:{montant:'50 USD',statut:'PAYÉ',ref:'REC-0001',date:'2026-11-01',reste_num:0,devise:'USD'},formation:{montant:'200 USD',statut:'MOITIÉ PAYÉE',ref:'REC-0001',date:'2026-11-01',reste_num:100,devise:'USD'},paiements:[]},
      recus:[{no:'REC-0001',formation:'Maçonnerie',date:'2026-11-01',statut:'VALIDE',inscription:{montant:'50 USD',statut:'PAYÉ'},formation_frais:{montant:'200 USD',statut:'MOITIÉ PAYÉE'},url:u},{no:'REC-0000',formation:'Maçonnerie',date:'2026-10-01',statut:'ANNULÉ',inscription:{montant:'50 USD',statut:'PAYÉ'},formation_frais:{},url:u}]}};M='123-456';
      const h=vFrais();document.body.insertAdjacentHTML('beforeend','<div id=tst>'+h+'</div>');
      document.querySelectorAll('#tst [data-rpdf]').forEach(x=>x.onclick=()=>recuPdf(+x.dataset.rpdf));
      return {qr:document.querySelectorAll('#tst img[src^="data:image"]').length,titre:h.includes('Mes reçus'),rec:h.includes('REC-0001'),annule:h.includes('ANNULÉ'),btn:document.querySelectorAll('#tst [data-rpdf]').length,msg:messages().some(m=>/reçu est disponible/i.test(m.t))}}""",url)
    print('affichage',r)
    with pg.expect_download(timeout=20000) as dl: pg.click('#tst [data-rpdf="0"]')
    print('pdf',dl.value.suggested_filename)
    print('vide',pg.evaluate("()=>{E.esp.recus=[];return vRecus().includes('Aucun reçu pour le moment')}"))
    print('erreurs',errs)
    b.close()
