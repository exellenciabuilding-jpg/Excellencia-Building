/* Tests V176 : alertes, import des prospects historiques, export CSV du CRM (node tools/test-crm-plus-v176.js). */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const store = {}, logs = [];
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.load = (k, df) => { try { const v = JSON.parse(store[k]); return v == null ? df : v; } catch (e) { return df; } };
global.save = (k, v) => { store[k] = JSON.stringify(v); return true; };
global.notify = () => {}; global.EXBCore = { audit: { log: (a, o) => logs.push(a + '|' + o) }, modules: { register() {} } };
global.document = undefined;
require('../exb-crm-plus.js');
const T = window.EXBCRMPLUS._t, set = (k, v) => { store[k] = JSON.stringify(v); };
const D = new Date().toISOString().slice(0, 10), add = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
eq(T.alertes(D), [], 'sans donnée : aucune alerte');

/* données : 4 opportunités ouvertes + 1 gagnée */
set('exb_crm_opps', [
  { id: 'O1', title: 'Villa', client: 'A', stage: 'devis', amount: 100, currency: 'USD', expected: add(-3), created: add(-2), history: [{ date: add(-2) }] },      // clôture dépassée, sans relance
  { id: 'O2', title: 'Mur', client: 'B', stage: 'prospect', amount: 50, created: add(-40), history: [{ date: add(-40) }] },                                        // inactive (40 j), sans relance
  { id: 'O3', title: 'Dalle', client: 'C', stage: 'negociation', amount: 10, created: add(-1), history: [{ date: add(-1) }] },                                      // avec relance planifiée
  { id: 'O4', title: 'Route', client: 'D', stage: 'qualifie', amount: 10, created: add(-30), history: [{ date: add(-30) }] },                                      // ancienne mais relance faite il y a 2 j
  { id: 'O5', title: 'Gagnée', client: 'E', stage: 'gagne', amount: 10, created: add(-90), history: [{ date: add(-90) }] }]);
set('exb_crm_followups', [{ id: 'F1', type: 'relance', client: 'C', opp_id: 'O3', date: add(5), done: false }, { id: 'F2', type: 'rdv', client: 'D', opp_id: 'O4', date: add(-2), done: true, done_at: add(-2), result: 'ok' }, { id: 'F3', type: 'relance', client: 'A', opp_id: 'O1', date: add(-4), done: false }]);
let A = T.alertes(D), by = {}; A.forEach(a => by[a.code] = a.n);
eq(by.relances, 1, 'une relance en retard (F3)');
eq(by.cloture, 1, 'une clôture prévue dépassée (O1)');
eq(by.sans_relance, 2, 'sans relance planifiée : O2 et O4 (O1 et O3 ont une relance non faite ; O5 est gagnée)');
eq(by.inactives, 1, 'inactive > 14 j : O2 seulement (O4 a eu un échange il y a 2 j)');
ok(by.reclamations === undefined, 'pas de réclamation, pas d’alerte');
eq(A.map(a => a.niveau), ['haute', 'haute', 'moyenne', 'moyenne'], 'tri : haute avant moyenne');

/* réclamations : urgente > 3 j, normale > 7 j, clôturée ignorée */
set('exb_crm_claims', [{ id: 'R1', no: 'REC-1', client: 'A', subject: 'x', severity: 'urgente', status: 'ouverte', date: add(-4), actions: [] }, { id: 'R2', no: 'REC-2', client: 'A', subject: 'y', severity: 'normale', status: 'en cours', date: add(-6), actions: [] },
  { id: 'R3', no: 'REC-3', client: 'A', subject: 'z', severity: 'normale', status: 'clôturée', date: add(-60), actions: [] }, { id: 'R4', no: 'REC-4', client: 'A', subject: 'w', severity: 'normale', status: 'ouverte', date: add(-8), actions: [] }]);
A = T.alertes(D); eq([A[0].niveau, A[0].n], ['critique', 2], 'réclamations hors délai : R1 (4 j > 3) et R4 (8 j > 7) ; R2 (6 j) et R3 (clôturée) exclues');

/* import des prospects historiques */
set('exb_crm', [{ id: 'p1', name: 'Société X', status: 'Visite', contact: 'M. X' }, { id: 'p2', name: '=HYPERLINK("http://x")', status: 'Perdu' }, { id: 'p3', name: '  ' }]);
set('exb_v92_crm', [{ name: 'Y SARL', status: 'Négociation' }]);
eq(T.importProspects(), 3, 'importe 3 prospects (le nom vide est ignoré)');
eq(T.importProspects(), 0, 'seconde importation : aucun doublon');
const ops = JSON.parse(store['exb_crm_opps']);
eq(ops.length, 5 + 3, 'opportunités existantes conservées + 3');
const x = ops.find(o => o.client === 'Société X'), y = ops.find(o => o.client === 'Y SARL'), z = ops.find(o => o.client.startsWith('=HYP'));
eq([x.stage, x.prob, y.stage, y.prob, z.stage, z.prob, z.lost_reason], ['qualifie', 30, 'negociation', 70, 'perdu', 0, 'Repris du CRM historique'], 'étapes converties, probabilités de V172');
ok(ops.slice(0, 5).every((o, i) => o.id === 'O' + (i + 1)), 'opportunités existantes inchangées');

/* export CSV : formule neutralisée, sections présentes */
const csv = T.toCsv();
ok(csv.includes("'=HYPERLINK") && !/;=HYPERLINK/.test(csv), 'CSV : formule neutralisée');
ok(['Opportunité', 'Relance / RDV', 'Réclamation'].every(t => csv.includes(t)), 'CSV : sections présentes');
ok(logs.some(l => l.startsWith('crm.import_prospects')), 'audit de l’import');
/* non-régression : fonctions V172 toujours exposées et opérationnelles */
ok(['saveOpp', 'moveOpp', 'pipeline', 'addFollow', 'addClaim', 'snapshot', 'compare'].every(k => typeof T[k] === 'function'), 'API V172 intacte');
ok(T.saveOpp({ title: 'T', client: 'C', amount: 10 }).ok && !T.saveOpp({ title: '', client: 'C' }).ok, 'création / validation V172 toujours actives');
console.log('test-crm-plus-v176 : ' + n + ' contrôles OK');
