/* V99o : le QR ouvre désormais la page publique verification.html (sans l'application, sans connexion) qui n'affiche que les informations du document.
 * Format : <site>/verification.html?c=type~numéro~date~montant~devise~code~nom   (l'ancien lien #verify= reste lu par la page).
 * Excellencia Building V99m — Vérification unifiée des documents (devis, factures, reçus, certificats, fiches d'inscription).
 * Chaque document porte un QR : lien #verify=type~numéro~date~montant~devise~code. Le scan ouvre la page « Vérification de document »,
 * qui interroge le registre (Supabase) et affiche les repères enregistrés (nom, matricule, formation/projet, date, montant, statut).
 * Aucune donnée de contact (téléphone, e-mail, adresse) n'est jamais affichée. Voir supabase/migration-v99m-verification.sql. */
(function (w, d) {
  'use strict';
  var KINDS = { d: 'Devis', f: 'Facture', r: 'Reçu', c: 'Certificat de formation', p: 'Reçu de paiement (formation)', i: 'Fiche d’inscription', e: 'Copie d’épreuve', g: 'Document' };
  var REG = { d: 'devis', f: 'facture', r: 'recu', c: 'certificat', p: 'recu_formation', i: 'inscription' };
  var RK = { devis: 'Devis', facture: 'Facture', recu: 'Reçu', certificat: 'Certificat de formation', recu_formation: 'Reçu de paiement (formation)', inscription: 'Fiche d’inscription', copie: 'Copie d’épreuve', document: 'Document' };

  /* SHA-256 synchrone (les QR sont dessinés de façon synchrone) */
  function sha256(s) {
    s = unescape(encodeURIComponent(String(s)));
    function rr(v, a) { return (v >>> a) | (v << (32 - a)); }
    var K = sha256.K, H0 = sha256.H, i, j;
    if (!K) { K = sha256.K = []; H0 = sha256.H = []; var pc = 0, comp = {}; for (var c = 2; pc < 64; c++) { if (!comp[c]) { for (i = c * c; i < 313; i += c) comp[i] = 1; H0[pc] = (Math.pow(c, .5) * 4294967296) | 0; K[pc++] = (Math.pow(c, 1 / 3) * 4294967296) | 0; } } }
    var bl = s.length * 8, words = [];
    s += '\x80'; while (s.length % 64 - 56) s += '\x00';
    for (i = 0; i < s.length; i++) words[i >> 2] |= s.charCodeAt(i) << ((3 - i) % 4) * 8;
    words.push((bl / 4294967296) | 0); words.push(bl | 0);
    var h = H0.slice(0, 8);
    for (j = 0; j < words.length; j += 16) {
      var wv = words.slice(j, j + 16), a = h.slice(0, 8);
      for (i = 0; i < 64; i++) {
        var w15 = wv[i - 15], w2 = wv[i - 2];
        if (i >= 16) wv[i] = (wv[i - 16] + (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) + wv[i - 7] + (rr(w2, 17) ^ rr(w2, 19) ^ (w2 >>> 10))) | 0;
        var e = a[4], t1 = (a[7] + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & a[5]) ^ (~e & a[6])) + K[i] + wv[i]) | 0;
        var t2 = ((rr(a[0], 2) ^ rr(a[0], 13) ^ rr(a[0], 22)) + ((a[0] & a[1]) ^ (a[0] & a[2]) ^ (a[1] & a[2]))) | 0;
        a = [(t1 + t2) | 0, a[0], a[1], a[2], (a[3] + t1) | 0, a[4], a[5], a[6]];
      }
      for (i = 0; i < 8; i++) h[i] = (h[i] + a[i]) | 0;
    }
    var out = ''; for (i = 0; i < 8; i++) for (j = 3; j >= 0; j--) { var b = (h[i] >> (j * 8)) & 255; out += (b < 16 ? '0' : '') + b.toString(16); }
    return out;
  }

  var DEFAULT_BASE = 'https://excellenciabuildingcent.netlify.app/';
  var MAXURL = 150; /* octets : au-delà le QR devient trop dense pour être scanné à petite taille */
  function base() { try { return (w.EXB77 && w.EXB77.base && w.EXB77.base()) || ((w.exbBase ? w.exbBase() : location.origin + '/')); } catch (e) { return (w.exbBase ? w.exbBase() : location.origin + '/'); } }
  /* Dossier public du site (adresse permanente si définie, sinon adresse courante, sinon adresse du site Excellencia) */
  function vbase() {
    var b = ''; try { b = (w.EXB77 && w.EXB77.base && w.EXB77.base()) || ''; } catch (e) {}
    if (!b) { try { if (/^https?:$/.test(location.protocol)) b = location.href; } catch (e) {} }
    /* application Android / Windows : l'adresse interne (localhost) n'existe pas pour le téléphone qui scanne le QR */
    if (!/^https?:\/\//i.test(b) || /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\]|10\.|192\.168\.)/i.test(b)) b = DEFAULT_BASE;
    b = b.split('#')[0].split('?')[0].replace(/^(https?:\/\/[^\/]+)$/i, '$1/');
    if (!/\/$/.test(b)) { var i = b.lastIndexOf('/'); b = /\./.test(b.slice(i + 1)) ? b.slice(0, i + 1) : b + '/'; }
    return b;
  }
  function blen(t) { try { return unescape(encodeURIComponent(t)).length; } catch (e) { return String(t).length; } }
  /* Lien de vérification public : la page verification.html affiche les informations, sans ouvrir l'application. */
  function vurl(raw, nom) {
    var pre = vbase() + 'verification.html?c=' + encodeURIComponent(raw), n = String(nom || '').replace(/[~_]/g, ' ').replace(/\s+/g, ' ').trim(), u = pre;
    function mk(x) { return x ? pre + '~' + encodeURIComponent(x).replace(/%20/g, '_') : pre; }
    u = mk(n); while (n && blen(u) > MAXURL) { var sp = n.lastIndexOf(' '); n = (sp > 8 ? n.slice(0, sp) : n.slice(0, -1)).replace(/[\s\/,.\-]+$/, ''); u = mk(n); }
    return u;
  }
  function code(kc, no, date, amount, cur, key, nom) {
    var am = (amount === '' || amount == null) ? '' : Number(amount).toFixed(2);
    var h = sha256([kc, no, date || '', am, cur || '', key || ''].join('|')).slice(0, 10);
    var raw = [kc, no, date || '', am, cur || '', h].join('~');
    return { hash: h, raw: raw, url: vurl(raw, nom) };
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function nf(v, n) { v = Number(v) || 0; var s = Math.abs(v).toFixed(n == null ? 2 : n).split('.'); s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (v < 0 ? '-' : '') + s.join(','); }
  function fd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function say(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 4000); } catch (e) {} try { alert(m); } catch (e) {} }

  /* ---------- appels serveur ---------- */
  function cfg() { var c = w.EXB_SUPABASE; return c && c.url && c.key ? c : null; }
  function rpc(fn, args) {
    var c = cfg(); if (!c) return Promise.resolve(null);
    var h = { apikey: c.key, 'Content-Type': 'application/json' }; if (/^eyJ/.test(c.key)) h.Authorization = 'Bearer ' + c.key;
    return fetch(String(c.url).replace(/\/+$/, '') + '/rest/v1/rpc/' + fn, { method: 'POST', headers: h, body: JSON.stringify(args) }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
  }
  var DONE = {};
  async function publish(r) {
    try {
      if (!r || !r.no || !r.hash || !w.exbSb || !w.exbSb.isIn || !w.exbSb.isIn() || !navigator.onLine) return false;
      var key = [r.no, r.hash, r.status || '', r.nom || ''].join('|'); if (DONE[key]) return true;
      await w.exbSb.api('/rest/v1/rpc/exb_doc_publish2', { method: 'POST', body: JSON.stringify({ p_no: r.no, p_kind: r.kind, p_hash: r.hash, p_date: r.date || null, p_total: Number(r.total) || 0, p_cur: r.cur || '', p_status: r.status || '', p_nom: r.nom || '', p_matricule: r.matricule || '', p_libelle: r.libelle || '', p_detail: r.detail || '' }) });
      DONE[key] = 1; return true;
    } catch (e) { return false; }
  }
  function declare(r) { return rpc('exb_doc_declare', { p_data: r }); }
  function lookup(no, hash) { return rpc('exb_doc_verify2', { p_no: no, p_hash: hash }).then(function (j) { if (j) return j; return rpc('exb_doc_verify', { p_no: no, p_hash: hash }); }); }

  /* ---------- certificats et reçus de formation (index.html) ---------- */
  function certRec(c) {
    var no = c.cert_no, c1 = code('c', no, '', '', '', [no, c.holder, c.training, c.mention || ''].join('|'), c.holder);
    var st = String(c.status || 'VALIDE').toUpperCase() === 'ANNULE' ? 'annulé' : 'valide';
    return { code: c1, rec: { no: no, kind: 'certificat', hash: c1.hash, date: String(c.created_at || '').slice(0, 10), total: 0, cur: '', status: st, nom: c.holder || '', matricule: c.matricule || '', libelle: (c.training || '') + (c.mention ? ' — ' + c.mention : ''), detail: c.cancellation_reason || '' } };
  }
  function certMatricule(c) { try { if (c.matricule) return c.matricule; if (typeof participants !== 'undefined') { var p = participants.find(function (x) { return (c.participant_id && x.participant_id === c.participant_id) || String(x.name || '').trim().toLowerCase() === String(c.holder || '').trim().toLowerCase(); }); if (p) return p.matricule || ''; } } catch (e) {} return ''; }
  function certUrl(c) { c = Object.assign({}, c); c.matricule = certMatricule(c); var o = certRec(c); if (c.cert_no && c.holder) publish(o.rec); return o.code.url; }
  function publishCert(c) { c = Object.assign({}, c); c.matricule = certMatricule(c); return publish(certRec(c).rec); }
  function recuRec(r) {
    var no = r.receipt_no, c1 = code('p', no, '', '', '', [no, r.participant, r.training, r.registration_fee, r.registration_status, r.training_fee, r.training_status].join('|'), r.participant);
    var mat = ''; try { if (typeof participants !== 'undefined') { var p = participants.find(function (x) { return (r.matricule && x.matricule === r.matricule) || String(x.name || '').trim().toLowerCase() === String(r.participant || '').trim().toLowerCase(); }); if (p) mat = p.matricule || ''; } } catch (e) {}
    return { code: c1, rec: { no: no, kind: 'recu_formation', hash: c1.hash, date: String(r.created_at || '').slice(0, 10), total: 0, cur: '', status: 'valide', nom: r.participant || '', matricule: r.matricule || mat, libelle: r.training || '', detail: 'Inscription : ' + (r.registration_fee || '—') + ' (' + (r.registration_status || '—') + ') · Formation : ' + (r.training_fee || '—') + ' (' + (r.training_status || '—') + ')' } };
  }
  function recuUrl(r) { var o = recuRec(r); if (r.receipt_no && r.participant) publish(o.rec); return o.code.url; }
  function publishRecu(r) { return publish(recuRec(r).rec); }

  /* ---------- fiche d'inscription publique (inscription.html) ---------- */
  function fiche(mat, name, label, date) {
    var c1 = code('i', mat, date || '', '', '', [mat, name, label, date || ''].join('|'), name);
    declare({ no: mat, hash: c1.hash, date: date || null, nom: name, matricule: mat, libelle: label });
    return c1;
  }
  /* QR net et peu dense : correction M (EXBQR), modules à taille ENTIÈRE (aucun flou à l'impression), marge blanche de 2 modules. */
  function qrCanvas(url, mod) {
    if (!w.EXBQR) return null;
    var m = w.EXBQR.matrix(url), n = m.length, q = 2, t = n + 2 * q, px = mod || 8, cv = d.createElement('canvas'); cv.width = cv.height = t * px;
    var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.fillStyle = '#000';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) x.fillRect((c + q) * px, (r + q) * px, px, px);
    return cv;
  }
  function qrPng(url) { try { var cv = qrCanvas(url, 8); return cv ? cv.toDataURL('image/png') : ''; } catch (e) { return ''; } }
  /* Dessine le QR dans un conteneur HTML (certificat, reçu, rapport…) sous forme d'image nette de size × size pixels CSS. */
  function qrInto(el, url, size) {
    try { var png = qrPng(url); if (!png || !el) return false; el.innerHTML = ''; var im = d.createElement('img'); im.src = png; im.alt = 'QR de vérification'; im.style.cssText = 'display:block;width:' + (size || 108) + 'px;height:' + (size || 108) + 'px;image-rendering:pixelated'; el.appendChild(im); return true; } catch (e) { return false; }
  }
  /* Opérations PDF vectorielles (moteur EXBPdf / exb-docs) : carré de sz points dont le coin bas-gauche est (qx,qy). */
  function qrOps(url, qx, qy, sz) {
    var m = w.EXBQR.matrix(url), n = m.length, q = 2, t = n + 2 * q, s = sz / t, pth = '';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) pth += (qx + (c + q) * s).toFixed(2) + ' ' + (qy + sz - (r + q + 1) * s).toFixed(2) + ' ' + s.toFixed(2) + ' ' + s.toFixed(2) + ' re ';
    return '1 1 1 rg ' + qx.toFixed(2) + ' ' + qy.toFixed(2) + ' ' + sz.toFixed(2) + ' ' + sz.toFixed(2) + ' re f 0 0 0 rg ' + pth + 'f';
  }

  /* ---------- documents divers (rapports, fiches, bons, procès-verbaux…) ---------- */
  function docRec(o) {
    var date = o.date || new Date().toISOString().slice(0, 10), key = [o.title || '', o.sub || '', o.digest || ''].join('|');
    var no = o.no || ((o.prefix || 'DOC') + '-' + date.replace(/-/g, '') + '-' + sha256(key).slice(0, 5).toUpperCase());
    var c1 = code('g', no, date, '', '', key, o.nom);
    return { code: c1, rec: { no: no, kind: 'document', hash: c1.hash, date: date, total: 0, cur: '', status: 'valide', nom: o.nom || '', matricule: o.matricule || '', libelle: String(o.title || '') + (o.sub ? ' — ' + o.sub : ''), detail: o.detail || '' } };
  }
  function docUrl(o) { var r = docRec(o); publish(r.rec); return r.code; }

  /* ---------- publication des documents déjà émis ---------- */
  function readLS(k) { try { return JSON.parse((w.exbStorage && w.exbStorage.getItem(k)) || localStorage.getItem(k) || '[]') || []; } catch (e) { return []; } }
  async function publishAll() {
    if (!w.exbSb || !w.exbSb.isIn || !w.exbSb.isIn()) { say('Connectez-vous d’abord au serveur (compte administrateur).', 'warn'); return; }
    var n = 0, bad = 0, list = [];
    readLS('exb_certificates').forEach(function (c) { c = Object.assign({}, c); c.matricule = certMatricule(c); if (c.cert_no) list.push(certRec(c).rec); });
    readLS('exb_receipts').forEach(function (r) { if (r.receipt_no) list.push(recuRec(r).rec); });
    try { var db = JSON.parse(localStorage.getItem('EXB_DOCS_V1') || '{}').docs || {}; Object.keys(db).forEach(function (k) { var r = db[k]; if (r && r.hash) list.push({ no: r.no, kind: r.kind === 'facture' ? 'facture' : r.kind === 'recu' ? 'recu' : 'devis', hash: r.hash, date: r.date, total: r.total, cur: r.cur, status: r.status || '', nom: r.client || '', libelle: r.project || '' }); }); } catch (e) {}
    for (var i = 0; i < list.length; i++) { if (await publish(list[i])) n++; else bad++; }
    say(n + ' document(s) publié(s) dans le registre' + (bad ? ' · ' + bad + ' en échec (exécutez migration-v99m-verification.sql).' : '.'), bad ? 'warn' : 'success');
    return { ok: n, ko: bad };
  }

  /* ---------- page de vérification ---------- */
  function overlay() { var o = d.createElement('div'); o.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:99999;display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px'; d.body.appendChild(o); var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;max-width:480px;width:100%;padding:18px;font-family:Arial,sans-serif;color:#172033;margin-top:24px'; o.appendChild(c); return { o: o, c: c }; }
  var BTN = 'border:0;border-radius:10px;padding:11px 14px;font-weight:700;cursor:pointer;background:#173565;color:#fff;';
  function banner(kind, txt) { var s = { ok: 'background:#dcfce7;color:#166534', ko: 'background:#fee2e2;color:#991b1b', wn: 'background:#ffedd5;color:#9a3412', in: 'background:#fef9c3;color:#854d0e' }[kind]; return '<div style="' + s + ';padding:10px;border-radius:10px;font-weight:700">' + txt + '</div>'; }
  function rows(a) { return '<table style="width:100%;font-size:14px;border-collapse:collapse">' + a.filter(function (r) { return r[1] !== '' && r[1] != null; }).map(function (r) { return '<tr><td style="padding:5px;color:#64748b;vertical-align:top;width:38%">' + esc(r[0]) + '</td><td style="padding:5px;font-weight:700">' + esc(r[1]) + '</td></tr>'; }).join('') + '</table>'; }
  function statusLabel(s) { s = String(s || '').toLowerCase(); return { '': '', valide: 'Valide', 'annulé': 'ANNULÉ', 'accepté': 'Accepté', 'refusé': 'Refusé', 'envoyé': 'Envoyé', 'brouillon': 'Brouillon', 'expiré': 'Expiré' }[s] || s; }
  function table(kc, no, v, date, amount, cur, hash) {
    var kind = (v && v.kind && RK[v.kind]) || KINDS[kc] || 'Document', lb0 = (v && v.libelle) || '', dt = (v && v.date) || date, tot = v && v.total != null ? v.total : amount, cr = (v && v.cur) || cur, hasAmt = tot !== '' && tot != null && Number(tot) > 0;
    if (/^Note de calcul/i.test(lb0)) kind = 'Note de calcul de structure'; else if (/^Plan d.ex/i.test(lb0)) kind = 'Plan d’exécution de structure';
    return rows([['Type', kind], ['Numéro', no], ['Nom', v && v.nom], ['Matricule', v && v.matricule], [(kc === 'c' || kc === 'p' || kc === 'i') ? 'Formation' : 'Objet', v && v.libelle], ['Date', fd(dt)], ['Montant', hasAmt ? nf(tot, 2) + ' ' + (cr || '') : ''], ['Statut', v ? statusLabel(v.status) : ''], ['Détail', v && v.detail], ['Code', String(hash || '').toUpperCase()]]);
  }
  function show(raw, getRec) {
    var p = String(raw || '').split('~'); if (p.length < 6) return;
    var kc = p[0], no = p[1], date = p[2], amount = p[3], cur = p[4], hash = p[5], O = overlay(), c = O.c, rec = getRec ? getRec(no) : null;
    c.innerHTML = '<b style="font-size:17px;color:#173565">Vérification de document</b><div id="vv" style="margin:12px 0">' + banner('in', 'Vérification en cours…') + '</div><div id="vt">' + table(kc, no, null, date, amount, cur, hash) + '</div><div id="vc"></div>'
      + '<p style="font-size:12px;color:#64748b;margin:12px 0 6px">Autre vérification : saisissez un matricule ou un numéro de document.</p><div style="display:flex;gap:6px"><input id="vq" placeholder="Matricule ou n° (ex. EXB-FP-2026-001)" style="flex:1;padding:10px;border:1px solid #cbd5e1;border-radius:10px"><button id="vg" style="' + BTN + '">🔎</button></div><div id="vm"></div>'
      + '<button id="vx" style="' + BTN + 'width:100%;margin-top:14px">Fermer</button>';
    function $(i) { return c.querySelector('#' + i); }
    $('vx').onclick = function () { O.o.remove(); try { history.replaceState(null, '', location.href.split('#')[0]); } catch (e) {} };
    wireSearch(c);
    lookup(no, hash).then(function (r) {
      var V = $('vv'), T = $('vt'), C = $('vc');
      if (r && r.found) {
        T.innerHTML = table(kc, no, r, date, amount, cur, hash);
        if (String(r.status).toLowerCase() === 'annulé') V.innerHTML = banner('ko', '⚠️ Document enregistré mais ANNULÉ par l’émetteur.');
        else if (r.confirmed === false) V.innerHTML = banner('wn', '⏳ Fiche déposée, non confirmée — pas encore confirmée par Excellencia Building : ne la considérez pas comme un document officiel.');
        else if (r.latest === false && r.current) { V.innerHTML = banner('wn', '⚠️ Ancienne version : ce document a été remplacé par une version plus récente.'); C.innerHTML = '<div style="margin-top:10px;padding:10px;border:2px solid #15803d;border-radius:10px"><b style="color:#15803d">Version en vigueur</b>' + rows([['Date', fd(r.current.date)], ['Montant', r.current.total > 0 ? nf(r.current.total, 2) + ' ' + (r.current.cur || '') : ''], ['Statut', statusLabel(r.current.status)], ['Objet', r.current.libelle], ['Code', String(r.current.hash || '').toUpperCase()]]) + '</div>'; }
        else V.innerHTML = banner('ok', '✅ Document authentique — enregistré par l’émetteur. Comparez le nom et les informations ci-dessous avec votre document.');
      } else if (r && r.found === false) {
        if (rec && rec.hash === hash) V.innerHTML = banner('ok', '✅ Document authentique — enregistré dans le registre de l’émetteur (cet appareil).');
        else if (rec && rec.hash) { V.innerHTML = banner('wn', '⚠️ Version différente de celle enregistrée : ce document a été modifié ou remplacé.'); C.innerHTML = '<div style="margin-top:10px;padding:10px;border:2px solid #15803d;border-radius:10px"><b style="color:#15803d">Version enregistrée</b>' + rows([['Nom', rec.client], ['Date', fd(rec.date)], ['Montant', rec.total ? nf(rec.total, 2) + ' ' + (rec.cur || '') : ''], ['Statut', statusLabel(rec.status)], ['Code', String(rec.hash).toUpperCase()]]) + '</div>'; }
        else V.innerHTML = banner('ko', '⚠️ Aucun enregistrement correspondant : document non reconnu ou modifié.');
      } else if (rec && rec.hash) {
        V.innerHTML = rec.hash === hash ? banner('ok', '✅ Document authentique — enregistré dans le registre de l’émetteur (cet appareil).') : banner('wn', '⚠️ Version différente de celle enregistrée sur cet appareil : montant actuel ' + nf(rec.total, 2) + ' ' + esc(rec.cur || '') + ', code ' + esc(String(rec.hash).toUpperCase()) + '.');
      } else V.innerHTML = banner('in', 'Vérification en ligne indisponible. Comparez les informations ci-dessous avec votre document.');
    });
  }
  function wireSearch(c) {
    var g = c.querySelector('#vg'), q = c.querySelector('#vq'), m = c.querySelector('#vm'); if (!g) return;
    g.onclick = async function () {
      var v = String(q.value || '').trim(); if (v.length < 3) { m.innerHTML = '<p style="color:#b45309">Saisissez au moins 3 caractères.</p>'; return; }
      m.innerHTML = '<p>Recherche…</p>'; var r = await rpc('exb_doc_search', { p_q: v });
      if (!r) { m.innerHTML = '<p style="color:#b45309">Recherche indisponible (hors connexion ou registre non configuré).</p>'; return; }
      var it = r.items || []; if (!it.length) { m.innerHTML = '<p style="color:#991b1b">Aucun document enregistré pour « ' + esc(v) + ' ».</p>'; return; }
      m.innerHTML = it.map(function (x) { return '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin-top:8px"><b>' + esc(RK[x.kind] || x.kind) + ' · ' + esc(x.no) + '</b>' + (String(x.status).toLowerCase() === 'annulé' ? ' <span style="color:#b91c1c;font-weight:700">ANNULÉ</span>' : '') + '<div style="font-size:13px;color:#475569">' + esc(x.nom || '') + (x.matricule ? ' · ' + esc(x.matricule) : '') + '<br>' + esc(x.libelle || '') + (x.date ? ' · ' + fd(x.date) : '') + '</div></div>'; }).join('');
    };
  }
  function search() { var O = overlay(), c = O.c; c.innerHTML = '<b style="font-size:17px;color:#173565">🔎 Vérifier un document</b><p style="font-size:13px;color:#475569">Saisissez un matricule ou un numéro (devis, reçu, certificat…).</p><div style="display:flex;gap:6px"><input id="vq" placeholder="Matricule ou numéro" style="flex:1;padding:10px;border:1px solid #cbd5e1;border-radius:10px"><button id="vg" style="' + BTN + '">🔎</button></div><div id="vm"></div><button id="vx" style="' + BTN + 'width:100%;margin-top:14px">Fermer</button>'; c.querySelector('#vx').onclick = function () { O.o.remove(); }; wireSearch(c); }

  w.EXBVerif = { vbase: vbase, vurl: vurl, qrCanvas: qrCanvas, qrInto: qrInto, qrOps: qrOps, docRec: docRec, docUrl: docUrl, sha256: sha256, code: code, publish: publish, declare: declare, lookup: lookup, show: show, search: search, fiche: fiche, qrPng: qrPng, publishAll: publishAll, publishCert: publishCert, publishRecu: publishRecu, certUrl: certUrl, recuUrl: recuUrl };
  w.exbVerifCertText = certUrl; w.exbVerifReceiptText = recuUrl;
})(window, document);
