-- Excellencia Building V102 — Espace apprenant : mot de passe par défaut 1234, plus de code de vérification.
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v101-apprenants-sans-blocage.sql déjà exécutée (tables apprenants_acces, fonction _exb_n).
--
-- Effets :
--  * Tant qu'un apprenant n'a pas choisi son propre mot de passe, « 1234 » est accepté (l'ancien 123456789 aussi).
--  * La connexion ne demande plus de changer le mot de passe (doit_changer n'est plus renvoyé).
--  * Le changement volontaire de mot de passe n'exige plus le code des 4 derniers chiffres du téléphone (4 caractères minimum).
--  * Un apprenant qui a déjà choisi son mot de passe garde ce mot de passe.

create or replace function public.apprenant_connexion(p_matricule text, p_mdp text)
 returns jsonb
 language plpgsql
 security definer
 set search_path to 'public', 'extensions'
as $function$
declare a public.apprenants_acces; m text := public._exb_n(p_matricule); res jsonb; ok boolean;
begin
  select * into a from public.apprenants_acces where matricule = m;
  if not found then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  ok := (a.mdp_hash = crypt(coalesce(p_mdp,''), a.mdp_hash))
        or (a.doit_changer and coalesce(p_mdp,'') = '1234');
  if not ok then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  select coalesce(jsonb_agg(jsonb_build_object('session', session, 'publie_le', publie_le, 'donnees', donnees)
                            order by publie_le desc), '[]'::jsonb)
    into res from public.resultats_publies where matricule = m;
  return jsonb_build_object('ok', true, 'doit_changer', false, 'nom', a.nom,
                            'formation', a.formation, 'resultats', res);
end $function$;

create or replace function public.apprenant_changer_mdp(p_matricule text, p_ancien text, p_nouveau text, p_code text default null::text)
 returns jsonb
 language plpgsql
 security definer
 set search_path to 'public', 'extensions'
as $function$
declare r jsonb; m text := public._exb_n(p_matricule);
begin
  r := public.apprenant_connexion(p_matricule, p_ancien);
  if not coalesce((r->>'ok')::boolean, false) then return r; end if;
  if length(coalesce(p_nouveau,'')) < 4 or p_nouveau in ('1234','123456789') then
    return jsonb_build_object('ok', false, 'code', 'faible');
  end if;
  update public.apprenants_acces
     set mdp_hash = crypt(p_nouveau, gen_salt('bf')), doit_changer = false, essais_code = 0
   where matricule = m;
  return jsonb_build_object('ok', true);
end $function$;
