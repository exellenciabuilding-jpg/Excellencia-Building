# V237 — Rapports & recette (Lot 6 du cahier « Portail Comptable V229+ »)

Base : V236n. Aucun nouveau SQL. Aucun fichier existant remplacé.

## Ce qui change
- Nouveau fichier : `site/exb-v237-rapports-recette.js` (bouton « 📊 Rapports & recette »).
- `site/index.html` : une balise ajoutée après `exb-v234-controle-paie-ecritures.js`.
- `site/sw.js` : fichier ajouté à la liste hors connexion, version incrémentée.
- `site/exb-v232-analytique-chantier.js` : une seule modification, `lire` est exposé (`EXBAN.lire`) pour que le rapport chantier lise les mêmes données que l'écran Analytique.

## Les 3 onglets
1. **Rapports** (export CSV + impression) : position de trésorerie, dettes fournisseurs (ancienneté + factures à payer), budget et marge par chantier (USD ou CDF), demandes du Centre (par statut, à contrôler depuis plus de 15 jours). Chaque devise reste séparée.
2. **Contrôles automatiques** : les critères d'acceptation du cahier (§ 14) vérifiés sur vos données : factures en double, caisse écrite deux fois, caisse sans paiement confirmé, paiement sans autorisation tracée, taux USD/CDF non figé, rapprochement double, écart ou annulation sans motif, clôtures de caisse, écritures non rattachées à un compte, chantiers au-dessus du budget. « Sans objet » = pas encore de données. Export CSV.
3. **Recette utilisateur** : 12 contrôles à faire sur téléphone Android et ordinateur (en ligne et hors connexion), résultat OK / KO daté et signé ; un KO exige une note ; plan de retour arrière.

## Déjà existant, non refait
- Sauvegarde, test de restauration, objectifs RPO/RTO, contrôle d'intégrité : « Continuité & sécurité » (`exb-continuite.js`).
- Audit unifié : onglet « 🔎 Audit » de « 🧮 Contrôle paie · Écritures » (V234).
- Journal, grand livre, balance, TVA, états : Comptabilité existante, inchangée.

## Sécurité des données
Lecture seule sur toutes les données comptables. Seules clés créées : `exb_rr_recette`, `exb_rr_audit`. Les exports CSV neutralisent les formules (cellules commençant par =, +, - ou @).

## Non couvert (à décider avec vous)
- Mode test avec données fictives séparées de la production (cahier § 16).
- Verrouillage de période et réouverture motivée : non touchés ici.
- Rapports PDF dédiés : l'impression du navigateur permet « Enregistrer en PDF ».

## Retour arrière
Supprimer la balise `<script src="exb-v237-rapports-recette.js">` dans `index.html` (et revenir au `sw.js` précédent). Les données restent.

## À tester (Android et ordinateur)
1. Ouvrir 📊 Rapports & recette : chaque rapport s'affiche, le CSV se télécharge.
2. Onglet Contrôles : saisir deux fois la même facture fournisseur dans les données de test, vérifier l'alerte.
3. Onglet Recette : passer les 12 contrôles, noter un KO avec sa note.
Tests automatiques : 23 contrôles de logique ; parcours complet dans le logiciel entier (mobile et ordinateur), sans erreur. Non testé sur téléphone Android réel.
