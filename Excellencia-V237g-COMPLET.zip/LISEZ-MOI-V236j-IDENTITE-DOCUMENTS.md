# V236j — Les documents lisent les paramètres de l'entreprise

## Nouveaux champs (Paramètres › Identité de l'entreprise › « Textes des documents »)
- **Ligne de spécialités** : sous le nom, sur les PDF. Vide : ligne d'origine pour Excellencia Building, rien pour une autre entreprise.
- **Bandeau du bas des PDF** : vide = « NOM • spécialités ».
- **Devise** : certificats, écran d'accueil, pages publiques. Vide : texte d'origine pour Excellencia Building.

## Les 4 PDF (bon de paiement, bon de livraison/commande, rapport matériaux, reçu client)
Nom, slogan, spécialités, adresse, téléphone, e-mail, couleurs, bandeau, pied de page, mentions légales
(2 lignes au maximum) et auteur du PDF viennent des paramètres.

## Aussi corrigé
Cartouche des plans, certificats, reçu d'inscription, reçu TFL, champs préremplis (dates du jour),
pages publiques (accueil client, vérification, plans, portail), écran d'accueil, affiches du studio,
export CSV de direction, maître d'œuvre par défaut.

## Laissé tel quel
- Valeurs d'origine : exb-brand.js, entreprise.json, valeurs de base d'exb-identite.js.
- Secours qui ne s'affichent que si l'identité est introuvable (exb-pdf, exb-docs, exb-form, atelier-mep, etc.).
- Affiches « Excellencia » toutes faites, images de marque, certains textes fixes des pages publiques (titres, mentions « Excellencia Building »),
  remplacés automatiquement à l'écran quand le nom change.
- « Concevoir · Construire · Transmettre » (page des plans) : affiché pour Excellencia Building seulement.
- Mention de copyright dans exb-etudes.js.

## Installation
Remplacer le site par le dossier site/ de ce dépôt, puis recharger l'application deux fois (mise à jour du cache hors ligne).
Pour l'APK / Windows : recompiler.
