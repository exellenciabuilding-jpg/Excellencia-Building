# V236k — Écrans de connexion Excellencia : fond, logo officiel et bienvenue par espace

Base : V236j (la courbe en S V236b y était déjà : `exb-pilote.js` identique, rien à rajouter).

## Réservé à Excellencia Building
Tout ce lot ne s'applique que lorsque le nom de l'entreprise (Paramètres › Identité) est « Excellencia Building ».
Une entreprise cliente garde son écran de connexion d'origine (fond neutre de V236j, son logo, aucun bandeau).

## Ce qui change (Excellencia seul)
- Fond : l'image Excellencia (bâtiment, chantier, équipe) sur l'écran de connexion et la porte de connexion des espaces (version portrait sur téléphone).
- Logo officiel (`logo-officiel.png`) sur ces écrans.
- Message de bienvenue au-dessus du formulaire : Comptable « Bienvenue dans votre espace comptable » · Ingénieur « …espace bureau d'études » · Architecture « …espace architecture » · Formation, Chantier, Direction, Administration, Magasin (même modèle) · sans espace « Bienvenue sur votre portail administrateur ».
- Affichage seulement (CSS) : aucune logique de connexion modifiée.

## Captures du module comptable retirées
Supprimées : `site/docs/espaces/comptable.png`, `site/docs/espaces/comptable-paiements-declares.png`,
`site/captures-guichet/bureau-1-menu-espace-comptable.png`, `telephone-1-menu-espace-comptable.png`, `apercu-espace-comptable-telephone.png`.
(Aucun écran du logiciel ne les utilisait ; ces dossiers n'entrent déjà ni dans l'APK ni dans l'EXE.)
Note : `site/tools/capture-espaces.py` les régénère si on le relance.

## Test corrigé
`site/tools/check.js` : le contrôle « Espace Administration » ne reconnaissait plus la définition (`conf:true` ajouté en V236e) ; le test est mis à jour, le logiciel n'est pas touché.

## Fichiers
Nouveaux : `site/exb-v236k-bienvenue-espaces.js`, `site/fond-connexion.jpg`, `site/logo-officiel.png`.
Modifiés : `site/index.html` (1 balise), `site/sw.js` (cache `v236k-…`), `site/tools/check.js`.

## Installation
Copier par-dessus la V236j, fermer complètement l'application une fois. Pas de SQL. Recompiler APK/EXE (OCR : archive séparée).
Retirer le lot : supprimer la balise `exb-v236k-bienvenue-espaces.js` dans index.html.

## Vérifié
check.js : 1001 contrôles, 0 échec · connexion testée pour l'administrateur et 3 espaces (dont téléphone) · entreprise autre : écran inchangé.
