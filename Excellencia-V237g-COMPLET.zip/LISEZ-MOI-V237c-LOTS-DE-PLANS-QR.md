# V237c — Lots de plans : un QR identique sur chaque plan

Base : V237b (appliqué aussi sur V236g). Modifiés : `site/atelier-mep/app.js`, `index.html`, `exb-doc-layout.js`, `LISEZ-MOI.txt`, `site/plan.html` (60 documents au lieu de 8), `site/sw.js` (cache v237c). Nouveaux : `site/supabase/migration-v236h-lots-de-plans.sql`, `site/tools/e2e-atelier-lots.py`, `site/tools/harness-atelier-lots.html`.

## Utilisation
1. Atelier de mise en page › importez vos plans PDF (onglet « Plans · Notes de calcul »), préparez chaque cartouche comme d'habitude.
2. Onglet **Lots de plans (QR)** › « Nouveau lot » › « Ajouter tous les plans » (ou un par un), réordonnez avec ▲▼.
3. **Exporter avec QR commun et publier** : chaque plan est exporté avec le même QR (référence du lot + code d'accès) et publié sur le portail « plan ».
4. Un scan d'un plan quelconque affiche tous les plans du lot (téléchargement). « QR / lien » : lien, fiche QR A4, WhatsApp ; « Tous les plans (ZIP) ».
5. Modifier un plan puis **republier** : même QR, plans mis à jour. « Retirer du portail » coupe l'accès.
6. Boîte « Scanner un QR de lot » : caméra ou photo ; ouvre le lot enregistré sur l'appareil, sinon le portail.

## Déploiement
- Supabase › SQL Editor : exécuter `site/supabase/migration-v236h-lots-de-plans.sql` (après v129). Sans elle, la publication est limitée à 8 plans.
- Netlify : redéposer `site/`. EXE/APK : reconstruire. Fermer l'application une fois (cache v237c).

## Contrôles effectués
Tests Atelier existants : 64/64. Test navigateur avec faux serveur : 6 plans importés → lot → publication (réservation de la référence, envoi des 6 PDF, publication) → QR décodé sur les 6 PDF : identique (`…/plan?ref=EXB-2026-001&k=…`) → republication : même référence, anciens fichiers supprimés. **Non testé** : le vrai serveur Supabase, la caméra, l'impression de la fiche QR.

## Limites
- Les plans non « Approuvé / Émis » peuvent être publiés après confirmation explicite (filigrane « Brouillon » conservé).
- La liste des lots est propre à l'appareil (la publication, elle, est sur le serveur) ; un lot créé ailleurs s'ouvre via le portail.
