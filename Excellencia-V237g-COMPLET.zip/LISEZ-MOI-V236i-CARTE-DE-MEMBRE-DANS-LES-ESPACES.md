# V236i — La carte de membre part dans l'espace apprenant et l'espace étudiant TFL

La carte créée dans « Affiches › Cartes de travail / membre » (n° EXB-CT-…) est envoyée automatiquement dans l'espace de la personne (recto + verso). Plus aucune carte n'est dessinée par les espaces eux-mêmes.

- Apprenants : publiée avec les données de l'espace (mise à jour automatique toutes les 30 s, logiciel connecté). Si la carte change (photo, nom, fonction, validité, contour), elle est renvoyée.
- Étudiants TFL : jointe à la publication du portail ; envoi automatique des cartes non envoyées (contrôle toutes les 20 s, 1 essai / minute) + bouton « Envoyer maintenant » dans la fiche de l'étudiant.
- Photo > 40 Ko (jeton exbidb) désormais relue pour la carte de membre.
- Espaces : page « Ma carte de membre » (recto, verso, téléchargement) ; message d'attente tant que la carte n'existe pas.
Fichiers : site/exb-carte-travail.js, index.html (espBuild/espPush/espHash), exb-tfl.js, espace-apprenant.html, tfl-portail.html, sw.js (v236i).
