# V237d — Message de bienvenue de l’écran de connexion en grand

Fichier modifié : `site/exb-v236k-bienvenue-espaces.js` (+ cache `site/sw.js` v237d). Le bandeau « Bienvenue dans votre espace … » occupe toute la largeur de l’écran, police 26 à 52 px selon l’écran. Aucune logique de connexion touchée. Retour arrière : remettre le fichier V237b.
