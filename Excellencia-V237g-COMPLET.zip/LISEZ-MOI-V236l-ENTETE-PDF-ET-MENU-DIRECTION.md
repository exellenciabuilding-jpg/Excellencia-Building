# V236l — En-tête / pied de page des rapports PDF et menu de l'Espace Direction

Base : V236k.

## 1. En-tête et pied de page des rapports de marque (modèle « Rappel »)
Constat : les PDF du moteur commun (Centre documentaire, pièces écrites, modules d'ingénierie, bon de paiement, bon de livraison, rapport de matériaux, reçu client) avaient déjà le bloc complet.
Les « rapports de marque » (`exb-rapport-marque.js`) ne l'avaient pas : adresse sans pays, une seule ligne de contact, pied « Excellencia Building — Kinshasa ».
Utilisés par : rapport de direction (BI Direction), comptabilité et paie, états comptables, CRM, stock, administration, impression d'un écran.
Maintenant, comme sur le PDF « Rappel » :
- en tête : logo, nom, slogan à gauche ; à droite adresse complète (pays compris), Tél, E-mail, site vitrine ;
- en pied : « Nom — slogan » puis adresse · Tél · E-mail · site, avec le QR de vérification.
Les valeurs viennent de Paramètres › Identité (une entreprise cliente voit ses propres coordonnées ; un champ vide n'est pas affiché).
Test : rapport généré = pays 2, téléphone 2, e-mail 2, site 3 occurrences (en-tête + pied).

## 2. Espace Direction : tous les modules de pilotage
Constat : l'Espace Direction montrait BI Direction, Pilotage direction, Workflow, Entreprise 360°, Supervision…, mais **pas « Pilotage projets »** (indices CPI/SPI, courbe en S) ni « Budget & pilotage ».
Maintenant ces deux modules sont dans le menu de l'Espace Direction (test : « Pilotage projets » s'ouvre depuis l'Espace Direction).
Fichier : `exb-v99r-shell.js`.

## 3. Petit correctif
`exb-metre.js` : adresse e-mail de secours corrigée (excellenciabuilding@gmail.com, il manquait un « l »). N'apparaissait que si l'identité était introuvable.

## Fichiers modifiés
`site/exb-rapport-marque.js`, `site/exb-v99r-shell.js`, `site/exb-metre.js`, `site/sw.js` (cache `v236l-…`).

## Installation
Copier par-dessus la V236k, fermer complètement l'application une fois. Pas de SQL. Recompiler APK/EXE.

## Vérifié
check.js : 1001 contrôles, 0 échec.

## Non modifié (à noter)
Impressions d'écran simples (fournisseurs & dettes, carte), pages publiques et cartouches de plans : elles gardent leur mise en page propre.
