/* Excellencia Building V219/V222 — Filigrane personnalisé ou au choix sur les modèles de certificat 1 à 5.
 * Les fonds « RDC » et « Excellencia Building » portent un filigrane ; les modèles 1 à 5 (images) le masquaient et n'offraient aucun choix.
 * Ce module ajoute, sous la liste « Modèle / fond », un réglage « Filigrane » (certificat individuel ET impression groupée) :
 *   - Selon mes logos (par défaut, comme les fonds précédents) : logo RDC enregistré, sinon logo Excellencia Building enregistré, sinon logo de la marque ; le filigrane dessiné dans le fond est effacé et remplacé. Aucun logo = filigrane d'origine conservé ;
 *   - Aucun (filigrane dessiné dans le fond conservé) ;
 *   - Logo Excellencia Building (logo enregistré dans Paramètres, sinon logo de la marque) ;
 *   - Filigrane RDC (celui du fond RDC, sinon le logo RDC enregistré) ;
 *   - Texte personnalisé (plusieurs lignes possibles) : le texte est entièrement libre, placé en diagonale au centre ;
 *   - intensité réglable (4 à 30 %).
 * Le réglage est mémorisé et s'applique à l'aperçu, au PDF et à l'impression groupée. Il n'apparaît que pour les modèles 1 à 5.
 * Retrait : supprimer la balise <script src="exb-certificat-filigrane.js"> de index.html (retour sans filigrane). */
(function (w, d) {
  'use strict';
  if (w.EXB_CERT_WM) return;
  var KEY = 'exb_cert_wm_v219', MODELS = ['m1', 'm2', 'm3', 'm4', 'm5'];
  var DEF = { mode: 'auto', text: String(((w.EXBId&&EXBId.get().name)||(w.EXB_BRAND&&EXB_BRAND.name)||'Excellencia Building')).toUpperCase(), op: 12 };
  var SANS = "'Segoe UI',Calibri,'Trebuchet MS','Helvetica Neue',Arial,sans-serif";
  var MODES = [['auto', 'Selon mes logos (RDC, sinon Excellencia)'], ['none', 'Aucun filigrane'], ['exb', 'Logo Excellencia Building'], ['rdc', 'Filigrane RDC'], ['text', 'Texte personnalisé']];
  var CV = d.createElement('canvas').getContext('2d');

  function store() { try { return w.exbStorage || w.localStorage; } catch (e) { return null; } }
  function ok(v) { return typeof v === 'string' && /^data:image\/(png|jpeg|jpg|webp|svg\+xml);base64,/i.test(v); }
  function stored(k) { try { var s = store(), v = s && s.getItem(k); return ok(v) ? v : ''; } catch (e) { return ''; } }
  function brandLogo() { try { var b = w.EXB_BRAND && w.EXB_BRAND.logo; if (b && (typeof w.exbSafeSrc !== 'function' || w.exbSafeSrc(b))) return String(b); } catch (e) {} return ''; }

  function cfg() {
    var c = { mode: DEF.mode, text: DEF.text, op: DEF.op };
    try {
      var s = store(), j = s && s.getItem(KEY); j = j ? JSON.parse(j) : null;
      if (j) {
        if (MODES.some(function (m) { return m[0] === j.mode; })) c.mode = j.mode;
        if (typeof j.text === 'string') c.text = j.text.slice(0, 160);
        var o = parseInt(j.op, 10); if (isFinite(o)) c.op = Math.max(4, Math.min(30, o));
      }
    } catch (e) {}
    return c;
  }
  function save(c) { try { var s = store(); if (s) s.setItem(KEY, JSON.stringify(c)); } catch (e) {} }

  var asked = 0;
  function srcFor(mode) {
    if (mode === 'auto') return stored('rdc_logo') || stored('exb_logo') || brandLogo();
    if (mode === 'exb') return stored('exb_logo') || brandLogo() || ((d.getElementById('certLogoExb') || {}).src || '');
    if (mode === 'rdc') {
      var g = w.EXB_CERT_WM_RDC || '';
      if (!g && typeof w.exbLoadImages === 'function' && !asked) { asked = 1; try { w.exbLoadImages(); } catch (e) {} setTimeout(rerender, 1500); }
      return g || stored('rdc_logo');
    }
    return '';
  }

  /* Pose le filigrane dans le calque du fond (1123 x 794), au-dessus de l'image du modèle et sous le texte, la photo, le QR et la signature. */
  function draw(parent, model) {
    if (MODELS.indexOf(model) < 0) return false;
    var c = cfg(); if (c.mode === 'none') return false;
    var op = (c.op / 100).toFixed(2), e;
    var src0 = c.mode === 'auto' ? srcFor('auto') : 'x';
    if (c.mode === 'auto' && !src0) return false;   /* aucun logo : filigrane d'origine conservé */
    if (w.EXB_CERT_LOGOS && w.EXB_CERT_LOGOS.wmPatch) w.EXB_CERT_LOGOS.wmPatch(parent, model);   /* efface le filigrane dessiné dans le fond */
    if (c.mode === 'text') {
      var lines = String(c.text || '').split(/\r?\n/).map(function (t) { return t.trim(); }).filter(Boolean).slice(0, 4);
      if (!lines.length) return false;
      var size = 110, wide = 0;
      CV.font = '800 ' + size + 'px ' + SANS;
      lines.forEach(function (t) { wide = Math.max(wide, CV.measureText(t).width); });
      if (wide > 760) size = Math.max(22, Math.floor(size * 760 / wide));
      e = d.createElement('div'); e.className = 'cert-wm-txt';
      e.setAttribute('style', 'position:absolute;left:561px;top:420px;transform:translate(-50%,-50%) rotate(-28deg);white-space:pre;text-align:center;pointer-events:none;' +
        'font-family:' + SANS + ';font-weight:800;font-size:' + size + 'px;line-height:1.12;color:#0f2a56;opacity:' + op);
      e.textContent = lines.join('\n'); parent.appendChild(e); return true;
    }
    var s = srcFor(c.mode); if (!s) return false;
    e = d.createElement('img'); e.className = 'cert-wm-img'; e.setAttribute('data-exb-wm', c.mode); e.alt = ''; e.src = s;
    e.setAttribute('style', 'position:absolute;left:311px;top:170px;width:500px;height:500px;object-fit:contain;pointer-events:none;opacity:' + op);
    parent.appendChild(e); return true;
  }

  function rerender() {
    try {
      ['certPaper', 'bulkPreview'].forEach(function (i) {
        var e = d.getElementById(i), s = d.getElementById(i === 'certPaper' ? 'background' : 'bulk_background');
        if (e && s && MODELS.indexOf(s.value) >= 0 && typeof w.applyCertBackground === 'function') w.applyCertBackground(e, s.value);
      });
    } catch (e) {}
  }

  /* ---------- réglage dans les deux formulaires ---------- */
  var panels = [];
  function sync(from) {
    var c = cfg();
    panels.forEach(function (p) {
      if (p === from) return;
      p.sel.value = c.mode; p.txt.value = c.text; p.rng.value = c.op; p.val.textContent = c.op + ' %';
    });
  }
  function refresh(p) {
    var c = cfg(), sh = MODELS.indexOf(p.back.value) >= 0;
    p.box.style.display = sh ? '' : 'none';
    p.txtRow.style.display = c.mode === 'text' ? '' : 'none';
    p.opRow.style.display = c.mode === 'none' ? 'none' : '';
    p.hint.textContent = c.mode === 'auto' && !srcFor('auto') ? 'Aucun logo enregistré (Paramètres › Logo) : le filigrane d\'origine du modèle est conservé.'
      : c.mode === 'exb' && !srcFor('exb') ? 'Aucun logo Excellencia Building enregistré (Paramètres › Logo) : aucun filigrane ne sera posé.'
      : c.mode === 'rdc' && !srcFor('rdc') ? 'Filigrane RDC en cours de chargement…'
      : c.mode === 'text' && !String(c.text || '').trim() ? 'Saisissez le texte du filigrane.' : '';
  }
  function make(backId) {
    var back = d.getElementById(backId); if (!back || back.__wm219) return false;
    back.__wm219 = 1;
    var box = d.createElement('div'); box.className = 'exb-wm-pick no-print'; box.setAttribute('style', 'margin:6px 0 2px;padding:8px 10px;border:1px dashed #c49a38;border-radius:10px;display:none');
    box.innerHTML = '<label style="margin-top:0">Filigrane du certificat</label><select data-wm="mode"></select>' +
      '<div data-wm="txtRow"><label>Texte du filigrane (une ligne par retour, 4 lignes au plus)</label><textarea data-wm="text" rows="2" maxlength="160" style="min-height:54px"></textarea></div>' +
      '<div data-wm="opRow"><label>Intensité : <b data-wm="val"></b></label><input data-wm="op" type="range" min="4" max="30" step="1"/></div>' +
      '<div class="localhint" data-wm="hint" style="margin-top:4px"></div>';
    var anchor = back; if (anchor.parentNode) anchor.parentNode.insertBefore(box, anchor.nextSibling);
    var q = function (n) { return box.querySelector('[data-wm="' + n + '"]'); };
    var p = { back: back, box: box, sel: q('mode'), txt: q('text'), rng: q('op'), val: q('val'), txtRow: q('txtRow'), opRow: q('opRow'), hint: q('hint') };
    MODES.forEach(function (m) { var o = d.createElement('option'); o.value = m[0]; o.textContent = m[1]; p.sel.appendChild(o); });
    var c = cfg(); p.sel.value = c.mode; p.txt.value = c.text; p.rng.value = c.op; p.val.textContent = c.op + ' %';
    var t = null;
    function change(now) {
      var n = { mode: p.sel.value, text: p.txt.value, op: parseInt(p.rng.value, 10) || DEF.op };
      save(n); p.val.textContent = n.op + ' %'; sync(p); panels.forEach(refresh);
      clearTimeout(t); t = setTimeout(rerender, now ? 0 : 150);
    }
    p.sel.addEventListener('change', function () { change(true); });
    p.txt.addEventListener('input', function () { change(false); });
    p.rng.addEventListener('input', function () { change(false); });
    back.addEventListener('change', function () { refresh(p); });
    panels.push(p); refresh(p); return true;
  }

  var tries = 0;
  function boot() {
    tries++;
    var a = make('background'), b = make('bulk_background');
    panels.forEach(refresh);
    return panels.length >= 2 || (tries > 40);
  }
  w.EXB_CERT_WM = { version: 'V219', models: MODELS.slice(), draw: draw, config: cfg, rerender: rerender };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 0); }); else setTimeout(boot, 0);
  /* l'affichage du réglage suit le modèle choisi, même quand un autre module change la liste par programme */
  setInterval(function () { try { boot(); } catch (e) {} }, 1000);
})(window, document);
