/* Excellencia Building V236i — Plans & esquisses : écran INTERNE du Parcours TFL.
 * Avant : « Plans » ouvrait une page séparée (iframe tfl-plans-admin.html) avec son propre formulaire de connexion.
 * Maintenant : le même écran s'affiche dans le module TFL, comme les autres vues, et utilise la connexion du logiciel central
 * (window.exbSb : même compte, aucun second mot de passe). Hors connexion, le catalogue se prépare comme avant.
 * Clavier / presse-papiers : Ctrl+S ou Ctrl+Entrée enregistre le plan, Échap annule la modification,
 * Ctrl+V colle un plan (image ou PDF copié) dans le catalogue ; clic droit : Couper / Copier / Coller (exb-menu-contextuel.js). */
(function (root) {
  'use strict';
  var KP = 'exb_tfl_plans';
  var SL = { disponible: 'Disponible', reserve: 'Réservé', attribue: 'Attribué', ferme: 'Fermé' };
  var EL = { recu: 'Reçue', a_corriger: 'À corriger', valide: 'Validée', refuse: 'Refusée' };
  var TYPES = ['Maison de plain-pied', 'Maison à étage R+1', 'Maison à étage R+2', 'Immeuble R+3 à R+5', 'Villa', 'Duplex', 'Bâtiment commercial', 'Bâtiment professionnel'];
  var CHAMPS = ['titre', 'type', 'ch', 'niv', 'surf', 'desc', 'src', 'lic'];
  var S = { tab: 'cat', edit: '', img: '', fileRef: '', bmsg: '', bcls: '', emsg: '', ecls: '', esq: [], d: {}, busy: false, fmsg: '', fcls: '' };
  /* par défaut : le même stockage que le reste du logiciel (clés préfixées par exbStorage) ; exb-tfl.js fournit ses propres accès en appelant html() */
  var H = {
    get: function (k, df) { try { var v = root.load(k, df); return v == null ? df : v; } catch (e) { return df; } },
    put: function (k, v) { try { return root.save(k, v) !== false; } catch (e) { return false; } },
    say: null, refresh: null
  };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(i) { return document.getElementById(i); }
  function plans() { var a = H.get ? H.get(KP, []) : []; return Array.isArray(a) ? a : []; }
  function put(a) { return H.put ? H.put(KP, a) : false; }
  function refresh() { try { if (H.refresh) H.refresh(); } catch (e) { /* écran fermé */ } }
  function say(m, t) { try { if (H.say) H.say(m, t); } catch (e) { /* silencieux */ } }

  /* ---------- session = celle du logiciel central ---------- */
  function sb() { return root.exbSb || null; }
  function on() { try { var s = sb(); return !!(s && s.isIn && s.isIn()); } catch (e) { return false; } }
  function email() { try { var c = sb().cfg(); return (c && c.email) || ''; } catch (e) { return ''; } }
  function rpc(n, b) {
    if (!on()) return Promise.reject(new Error('Non connecté au serveur.'));
    return sb().api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) });
  }
  function msgB(cls, t) { S.bcls = cls; S.bmsg = t; refresh(); }
  function msgE(cls, t) { S.ecls = cls; S.emsg = t; refresh(); }
  function besoinServeur(setter) {
    if (on()) return true;
    setter('err', 'Non connecté au serveur : utilisez la connexion du logiciel (bouton « Se connecter au serveur » ci-dessus). Le catalogue reste modifiable hors connexion.');
    return false;
  }
  function erreur(e) { var m = (e && e.message) || String(e); return m === 'Failed to fetch' ? 'pas de connexion internet.' : m; }

  function refSuivante(a) { var m = 0; a.forEach(function (p) { var x = /EXB-PLAN-(\d+)$/.exec(p.ref); if (x) m = Math.max(m, +x[1]); }); return 'EXB-PLAN-' + String(m + 1).padStart(4, '0'); }
  function d(k) { return S.d[k] == null ? '' : S.d[k]; }

  /* ---------- reprise des anciens plans ----------
   * L'ancienne page séparée (et le convertisseur) enregistraient dans la clé brute « exb_tfl_plans » du navigateur, alors que le logiciel
   * range ses données sous un préfixe : les deux ne se voyaient pas (d'où « 0 plan » dans le module). On rapatrie ici ces plans, une fois,
   * sans perte : les références déjà prises sont renumérotées (et le fichier joint déplacé), une copie brute est gardée. */
  var fusionEnCours = false;
  async function fusionner() {
    if (fusionEnCours) return false;
    var brut = null, raw = null;
    try { brut = root.localStorage.getItem(KP); raw = brut ? JSON.parse(brut) : null; } catch (e) { return false; }
    if (!Array.isArray(raw) || !raw.length) { if (brut) { try { root.localStorage.removeItem(KP); } catch (e) { /* ignoré */ } } return false; }
    fusionEnCours = true;
    try {
      var a = plans(), snap = {}, moves = [];
      try { snap = await idbAll(); } catch (e) { snap = {}; }
      raw.forEach(function (p) {
        if (!p || !p.ref) return;
        var same = a.filter(function (x) { return x.ref === p.ref; })[0];
        if (same && same.titre === p.titre) return;
        var q = Object.assign({}, p);
        if (same) { var nr = refSuivante(a); if (snap[p.ref]) moves.push([p.ref, nr]); q.ref = nr; }
        a.push(q);
      });
      if (put(a) === false) return false; /* rien n'est retiré de l'ancienne clé tant que l'enregistrement a échoué */
      for (var i = 0; i < moves.length; i++) { try { await idbPut(moves[i][1], snap[moves[i][0]]); await idbDel(moves[i][0]); } catch (e) { /* le fichier reste sous l'ancienne référence */ } }
      try { if (!root.localStorage.getItem(KP + '_v236h_copie')) root.localStorage.setItem(KP + '_v236h_copie', brut); root.localStorage.removeItem(KP); } catch (e) { /* ignoré */ }
      return true;
    } finally { fusionEnCours = false; }
  }

  /* ---------- affichage ---------- */
  var BTN = 'padding:8px 12px;border-radius:8px;margin:3px 3px 3px 0';
  function bt(a, t, cls, extra) { return '<button type="button" class="' + (cls || 'muted') + '" data-pl="' + a + '"' + (extra || '') + '>' + t + '</button>'; }
  function lbl(t) { return '<small style="display:block;margin-top:8px;font-weight:700">' + t + '</small>'; }
  function msgHtml(cls, t) { return t ? '<div style="margin-top:6px;font-size:14px;color:' + (cls === 'err' ? '#b91c1c' : cls === 'good' ? '#15803d' : '#667085') + '">' + esc(t) + '</div>' : ''; }

  function bandeau() {
    if (on()) return '<div style="border:1px solid #bbf7d0;background:#f0fdf4;border-radius:10px;padding:8px 12px;margin:8px 0;font-size:14px">✔ Connecté avec la connexion du logiciel' + (email() ? ' (' + esc(email()) + ')' : '') + ' : aucun second mot de passe.</div>';
    return '<div style="border:1px solid #fde68a;background:#fffbeb;border-radius:10px;padding:8px 12px;margin:8px 0;font-size:14px">🔐 Pas encore connecté au serveur. Hors connexion, vous pouvez préparer le catalogue ; pour synchroniser ou lire les esquisses, connectez-vous une fois au logiciel (même compte que partout).<div style="margin-top:6px">'
      + bt('login', '☁️ Se connecter au serveur', 'primary') + '</div></div>';
  }

  function listePlans() {
    var a = plans();
    if (!a.length) return '<div class="hint" style="padding:14px;text-align:center">Aucun plan pour le moment. Ajoutez-en un ci-dessus ou touchez « Importer mes plans ».</div>';
    return a.slice().reverse().map(function (p) {
      var r = esc(p.ref);
      return '<div style="border:1px solid #dce3ed;border-radius:12px;padding:10px;margin:8px 0;background:#fff">'
        + '<span class="hint">' + r + '</span> <span class="tag" style="display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;font-weight:700;background:#e5e7eb">' + esc(SL[p.statut || 'disponible'] || p.statut) + '</span> '
        + (p.publie ? '<span style="display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;font-weight:700;background:#dcfce7">publié</span>' : '')
        + '<br><b>' + esc(p.titre) + '</b><div class="hint">' + [p.type, p.chambres && p.chambres + ' ch.', p.niveaux, p.surface].filter(Boolean).map(esc).join(' · ') + '</div>'
        + (p.reserve_nom ? '<div class="hint">👤 ' + esc(p.reserve_nom) + ' · matricule ' + esc(p.reserve_tel || '') + (p.reserve_sujet ? ' · sujet ' + esc(p.reserve_sujet) : '') + '</div>' : '')
        + (p.fichier_nom ? '<div class="hint">📎 ' + esc(p.fichier_nom) + (p.attente ? ' — ⏳ en attente d’envoi (Synchroniser)' : '') + '</div>' : '')
        + '<div style="margin-top:6px">'
        + '<button type="button" class="muted" data-pl="edit" data-r="' + r + '">✏ Modifier</button>'
        + '<button type="button" class="muted" data-pl="file" data-r="' + r + '">📎 ' + (p.fichier_nom ? 'Remplacer' : 'Joindre') + ' le PDF</button>'
        + '<button type="button" class="muted" data-pl="pub" data-r="' + r + '">' + (p.publie ? 'Retirer' : 'Publier') + '</button>'
        + (p.statut === 'reserve' ? '<button type="button" class="muted" data-pl="lib" data-r="' + r + '">↩ Libérer</button><button type="button" class="muted" data-pl="att" data-r="' + r + '">✔ Attribuer</button>' : '')
        + (p.statut !== 'ferme' ? '<button type="button" class="muted" data-pl="fer" data-r="' + r + '">⛔ Fermer</button>' : '<button type="button" class="muted" data-pl="lib" data-r="' + r + '">↩ Rouvrir</button>')
        + '<button type="button" class="muted" data-pl="copy" data-r="' + r + '" title="Copier la référence et l’intitulé">📋 Copier</button>'
        + '<button type="button" class="muted" data-pl="del" data-r="' + r + '">🗑</button></div></div>';
    }).join('');
  }

  function formulaire() {
    var lic = d('lic');
    function I(id, l, ph, mode) { return '<div><small style="display:block;font-weight:700">' + l + '</small><input class="tplF" id="tpl_' + id + '" value="' + esc(d(id)) + '"' + (ph ? ' placeholder="' + esc(ph) + '"' : '') + (mode ? ' inputmode="' + mode + '"' : '') + ' style="width:100%"></div>'; }
    return '<div id="tplForm" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>' + (S.edit ? 'Modifier ' + esc(S.edit) : 'Nouveau plan') + '</b>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;margin-top:6px">'
      + '<div style="grid-column:1/-1"><small style="display:block;font-weight:700">Intitulé</small><input class="tplF" id="tpl_titre" value="' + esc(d('titre')) + '" style="width:100%"></div>'
      + '<div><small style="display:block;font-weight:700">Type</small><input class="tplF" id="tpl_type" list="tplTypes" value="' + esc(d('type')) + '" placeholder="Maison plain-pied, R+1, immeuble…" style="width:100%"><datalist id="tplTypes">' + TYPES.map(function (t) { return '<option>' + esc(t) + '</option>'; }).join('') + '</datalist></div>'
      + I('ch', 'Chambres', '', 'numeric') + I('niv', 'Niveaux', 'R+1') + I('surf', 'Surface', '120 m²') + '</div>'
      + '<p class="hint" style="margin:8px 0 0">Le PDF du plan se joint ensuite, depuis « Mes plans » (📎), après la première synchronisation : il est gardé en privé et rendu seulement à l’étudiant qui a réservé ce plan.</p>'
      + lbl('Description') + '<textarea class="tplF" id="tpl_desc" style="width:100%;min-height:62px">' + esc(d('desc')) + '</textarea>'
      + lbl('Source') + '<input class="tplF" id="tpl_src" value="' + esc(d('src')) + '" placeholder="auteur / site / « Excellencia Building »" style="width:100%">'
      + lbl('Droits d’utilisation (obligatoire pour publier)')
      + '<select class="tplF" id="tpl_lic" style="width:100%"><option value=""' + (lic ? '' : ' selected') + '>— à renseigner —</option>'
      + [['propre', 'Plan dessiné par nous'], ['autorise', 'Autorisation écrite de l’auteur'], ['libre', 'Licence libre / domaine public']].map(function (o) { return '<option value="' + o[0] + '"' + (lic === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>'
      + lbl('Aperçu (image)') + '<input type="file" id="tplImg" data-plf="img" accept="image/*"><div>' + (S.img ? '<img src="' + esc(S.img) + '" alt="aperçu" style="max-width:120px;max-height:80px;border:1px solid #ddd;border-radius:6px;margin-top:6px">' : '') + '</div>'
      + '<div style="margin-top:8px">' + bt('save', 'Enregistrer <small>(Ctrl+S)</small>', 'primary') + bt('new', 'Nouveau') + '</div>' + msgHtml(S.fcls, S.fmsg) + '</div>';
  }

  function vueCatalogue() {
    var a = plans();
    return formulaire()
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>Mes plans</b> <span class="hint">(' + a.length + ')</span>'
      + '<div style="margin-top:6px">' + bt('sync', '🌐 Synchroniser avec le serveur', 'primary') + bt('etat', '↻ Réservations') + bt('mes', '➕ Importer mes plans', 'primary')
      + bt('coller', '📋 Coller un plan <small>(Ctrl+V)</small>')
      + '<a class="muted" href="tfl-plans-convertir.html" target="_blank" rel="noopener" style="display:inline-block;' + BTN + ';background:#c9a227;color:#172033;font-weight:700;text-decoration:none">🗜 Convertisseur / alléger</a>'
      + bt('imp', '📥 Importer un lot (.json)') + bt('pdfs', '📎 Joindre plusieurs PDF') + '</div>'
      + msgHtml(S.bcls, S.bmsg) + '<div id="tplListe">' + listePlans() + '</div>'
      + '<input id="tplPdf" data-plf="pdf" type="file" accept=".pdf,image/*,.dwg,.dxf" hidden><input id="tplImp" data-plf="imp" type="file" accept=".json,application/json" hidden>'
      + '<input id="tplMes" data-plf="mes" type="file" accept=".pdf,image/*" multiple hidden><input id="tplPdfs" data-plf="pdfs" type="file" accept=".pdf" multiple hidden></div>';
  }

  function vueEsquisses() {
    return '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0">' + bt('esqLoad', '↻ Charger les esquisses', 'primary') + msgHtml(S.ecls, S.emsg)
      + S.esq.map(function (x) {
        var id = esc(x.id);
        return '<div style="border:1px solid #dce3ed;border-radius:12px;padding:10px;margin:8px 0;background:#fff"><span style="display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;font-weight:700;background:#e5e7eb">' + esc(EL[x.statut] || x.statut) + '</span> <span class="hint">' + esc(String(x.created_at || '').slice(0, 10)) + '</span><br><b>' + esc(x.titre || '(sans titre)') + '</b>'
          + '<div class="hint">' + esc(x.nom) + ' · matricule ' + esc(x.telephone) + (x.sujet_ref ? ' · ' + esc(x.sujet_ref) : '') + '</div>'
          + '<p style="white-space:pre-wrap;font-size:14px">' + esc(x.note || '') + '</p>'
          + (x.fichier ? '<button type="button" class="muted" data-pl="esqFile" data-f="' + esc(x.fichier) + '">👁 Ouvrir le fichier</button>' : '<span class="hint">pas de fichier</span>')
          + lbl('Commentaire pour l’étudiant') + '<textarea class="tplC" id="tplc_' + id + '" style="width:100%;min-height:56px">' + esc(x.commentaire || '') + '</textarea>'
          + ['valide', 'a_corriger', 'refuse'].map(function (s) { return '<button type="button" class="' + (s === 'valide' ? 'primary' : 'muted') + '" data-pl="esqDec" data-d="' + s + '" data-id="' + id + '">' + EL[s] + '</button>'; }).join('') + '</div>';
      }).join('') + '</div>';
  }

  /* appelé par exb-tfl.js (vuePlans) : renvoie le HTML de l'écran */
  function html(h) {
    if (h) { H.get = h.get || H.get; H.put = h.put || H.put; H.say = h.say || H.say; H.refresh = h.refresh || H.refresh; }
    fusionner().then(function (ch) { if (ch) { say('Anciens plans repris dans le catalogue.', 'success'); refresh(); } }, function () { /* ignoré */ });
    return bandeau()
      + '<div style="display:flex;gap:8px;margin:8px 0">' + bt('tab', '📁 Catalogue', S.tab === 'cat' ? 'primary' : 'muted', ' data-t="cat"') + bt('tab', '📥 Esquisses reçues', S.tab === 'esq' ? 'primary' : 'muted', ' data-t="esq"') + '</div>'
      + '<div id="tflPl">' + (S.tab === 'cat' ? vueCatalogue() : vueEsquisses()) + '</div>';
  }

  /* ---------- images, PDF, fichiers gardés sur l'appareil (IndexedDB) jusqu'à la synchronisation ---------- */
  function idb() { return new Promise(function (ok, ko) { var r = indexedDB.open('exb_tfl_plans_files', 1); r.onupgradeneeded = function () { r.result.createObjectStore('f'); }; r.onsuccess = function () { ok(r.result); }; r.onerror = function () { ko(r.error); }; }); }
  async function idbPut(k, v) { var db = await idb(); return new Promise(function (ok, ko) { var t = db.transaction('f', 'readwrite'); t.objectStore('f').put(v, k); t.oncomplete = ok; t.onerror = function () { ko(t.error); }; }); }
  async function idbAll() { var db = await idb(); return new Promise(function (ok, ko) { var o = {}, t = db.transaction('f', 'readonly'), c = t.objectStore('f').openCursor(); c.onsuccess = function () { var x = c.result; if (x) { o[x.key] = x.value; x.continue(); } else ok(o); }; c.onerror = function () { ko(c.error); }; }); }
  async function idbDel(k) { var db = await idb(); return new Promise(function (ok) { var t = db.transaction('f', 'readwrite'); t.objectStore('f').delete(k); t.oncomplete = ok; t.onerror = ok; }); }
  function jpeg(cv) { var q = 0.72, u = cv.toDataURL('image/jpeg', q); while (u.length > 82000 && q > 0.3) { q -= 0.1; u = cv.toDataURL('image/jpeg', q); } return u; }
  function charge(src) { return new Promise(function (ok, ko) { var im = new Image(); im.onload = function () { ok(im); }; im.onerror = ko; im.src = src; }); }
  function aB64(blob) { return new Promise(function (ok, ko) { var r = new FileReader(); r.onload = function () { ok(String(r.result).split(',')[1]); }; r.onerror = ko; r.readAsDataURL(blob); }); }
  function miniature(im, max) { var cv = document.createElement('canvas'), s = Math.min(1, max / Math.max(im.width, im.height)); cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s); var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.drawImage(im, 0, 0, cv.width, cv.height); return cv; }
  async function depuisImage(f) {
    var u = URL.createObjectURL(f);
    try {
      var im = await charge(u), cv = miniature(im, 2200);
      var blob = await new Promise(function (ok) { cv.toBlob(ok, 'image/jpeg', 0.85); });
      return { blob: blob, apercu: jpeg(miniature(im, 640)), mime: 'image/jpeg' };
    } finally { URL.revokeObjectURL(u); }
  }
  function pdfjs() {
    return (async function () {
      if (root.pdfjsLib) return root.pdfjsLib;
      try { var m = await import('./pdfjs/pdf.min.mjs'); m.GlobalWorkerOptions.workerSrc = './pdfjs/pdf.worker.min.mjs'; root.pdfjsLib = m; return m; } catch (e) { /* repli */ }
      return new Promise(function (ok) {
        var s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
        s.onload = function () { try { root.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'; } catch (e) { /* ignoré */ } ok(root.pdfjsLib || null); };
        s.onerror = function () { ok(null); }; document.head.appendChild(s);
      });
    })();
  }
  async function apercuPdf(f) {
    try {
      var L = await pdfjs(); if (!L) return '';
      var doc = await L.getDocument({ data: new Uint8Array(await f.arrayBuffer()) }).promise, pg = await doc.getPage(1), v = pg.getViewport({ scale: 1 }),
        v2 = pg.getViewport({ scale: 640 / Math.max(v.width, v.height) }), cv = document.createElement('canvas');
      cv.width = Math.round(v2.width); cv.height = Math.round(v2.height);
      var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height);
      await pg.render({ canvasContext: x, viewport: v2 }).promise; return jpeg(cv);
    } catch (e) { return ''; }
  }

  /* ---------- actions ---------- */
  function lireFormulaire() { CHAMPS.forEach(function (k) { var e = $('tpl_' + k); if (e) S.d[k] = e.value; }); }
  function champs() {
    lireFormulaire();
    return { titre: d('titre').trim(), type: d('type').trim(), chambres: d('ch').trim(), niveaux: d('niv').trim(), surface: d('surf').trim(), description: d('desc').trim(), source: d('src').trim(), licence: d('lic'), apercu: S.img };
  }
  function vider() { S.edit = ''; S.img = ''; S.d = {}; S.fmsg = ''; S.fcls = ''; }
  function enregistrer() {
    var c = champs(), a = plans();
    if (c.titre.length < 3) { S.fcls = 'err'; S.fmsg = 'Indiquez l’intitulé (3 caractères au moins).'; refresh(); return; }
    if (S.edit) { var p = a.filter(function (x) { return x.ref === S.edit; })[0]; if (p) { if (!c.apercu) c.apercu = p.apercu || ''; Object.assign(p, c); } }
    else { c.ref = refSuivante(a); c.statut = 'disponible'; c.publie = false; a.push(c); }
    if (put(a) === false) { S.fcls = 'err'; S.fmsg = 'Enregistrement impossible sur cet appareil (espace plein ?). Exportez une sauvegarde puis libérez de la place.'; refresh(); return; }
    vider(); S.fcls = 'good'; S.fmsg = 'Plan enregistré. Pour le rendre visible : « Publier » puis « Synchroniser ».'; refresh();
  }
  function maj(ref, fn) { var a = plans(), p = a.filter(function (x) { return x.ref === ref; })[0]; if (p) { var k = fn(p); if (k !== 'keep') p.push_statut = true; put(a); refresh(); } }
  function copierTexte(t) {
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(function () { say('Copié : ' + t, 'success'); }, function () { copieRepli(t); }); return; } } catch (e) { /* repli */ }
    copieRepli(t);
  }
  function copieRepli(t) { try { var ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); ta.remove(); say(ok ? 'Copié : ' + t : 'Copie impossible.', ok ? 'success' : 'warn'); } catch (e) { say('Copie impossible.', 'warn'); } }

  async function majEtat() {
    var rows = await rpc('tfl_plans_etat'), a = plans();
    (rows || []).forEach(function (s) { var p = a.filter(function (x) { return x.ref === s.ref; })[0]; if (p && !p.push_statut) { p.statut = s.statut; p.reserve_nom = s.reserve_nom || ''; p.reserve_tel = s.reserve_tel || ''; p.reserve_sujet = s.reserve_sujet || ''; } });
    put(a);
  }
  async function envoyerAttente() {
    var o = await idbAll(), ok = 0, ko = 0, a = plans();
    for (var k in o) {
      var v = o[k];
      try { await rpc('tfl_plan_fichier_poser', { p_ref: k, p_nom: v.nom, p_mime: v.mime, p_b64: await aB64(v.blob) }); await idbDel(k); var p = a.filter(function (x) { return x.ref === k; })[0]; if (p) { p.attente = false; p.fichier_nom = v.nom; } ok++; } catch (e) { ko++; }
    }
    put(a); return { ok: ok, ko: ko };
  }
  async function synchroniser() {
    if (!besoinServeur(msgB)) return;
    S.bcls = ''; S.bmsg = 'Synchronisation…'; refresh();
    try {
      var r = await rpc('tfl_plans_publier', { p_plans: plans().slice(0, 200) }), b = plans();
      b.forEach(function (p) { delete p.push_statut; }); put(b); await majEtat();
      var kk = await envoyerAttente();
      msgB('good', '✔ ' + ((r && r.n) || 0) + ' plan(s) synchronisé(s).' + (kk.ok ? ' ' + kk.ok + ' fichier(s) envoyé(s).' : '') + (kk.ko ? ' ' + kk.ko + ' fichier(s) à renvoyer (trop lourds ou erreur).' : ''));
    } catch (e) { msgB('err', String(e.message).indexOf('licence_manquante') >= 0 ? 'Un plan publié n’a pas de droits d’utilisation renseignés.' : 'Échec : ' + erreur(e)); }
  }
  async function reservations() {
    if (!besoinServeur(msgB)) return;
    try { await majEtat(); msgB('good', 'Réservations mises à jour.'); } catch (e) { msgB('err', 'Échec : ' + erreur(e)); }
  }

  /* importer MES plans (PDF ou images) : aussi appelé par le collage Ctrl+V */
  async function importerFichiers(fs) {
    fs = Array.prototype.slice.call(fs || []).filter(function (f) { return /pdf|^image\//i.test(f.type) || /\.(pdf|png|jpe?g|webp)$/i.test(f.name); });
    if (!fs.length) return false;
    var n = 0, ko = [];
    for (var i = 0; i < fs.length; i++) {
      var f = fs[i]; S.bcls = ''; S.bmsg = 'Préparation ' + (i + 1) + '/' + fs.length + ' : ' + (f.name || 'image collée') + '…'; refresh();
      try {
        var isPdf = /pdf/i.test(f.type) || /\.pdf$/i.test(f.name), blob, apercu, mime, nom = f.name || ('plan-colle-' + Date.now() + '.png');
        if (isPdf) { if (f.size > 4 * 1048576) { ko.push(nom + ' (> 4 Mo)'); continue; } blob = f; mime = 'application/pdf'; apercu = await apercuPdf(f); }
        else { var r = await depuisImage(f); blob = r.blob; apercu = r.apercu; mime = r.mime; if (blob.size > 4 * 1048576) { ko.push(nom + ' (> 4 Mo)'); continue; } }
        var a = plans(), ref = refSuivante(a), titre = nom.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ').trim();
        await idbPut(ref, { nom: isPdf ? nom : nom.replace(/\.[^.]+$/, '') + '.jpg', mime: mime, blob: blob });
        a.push({ ref: ref, titre: titre, type: '', chambres: '', niveaux: '', surface: '', description: '', source: 'Excellencia Building', licence: 'propre', publie: false, statut: 'disponible', apercu: apercu || '', fichier_nom: nom, attente: true }); put(a); n++;
      } catch (e) { ko.push((f.name || 'image') + ' (' + erreur(e) + ')'); }
    }
    msgB(ko.length ? 'err' : 'good', n + ' plan(s) importé(s) en brouillon (droits : « dessiné par nous »).' + (ko.length ? ' Refusés : ' + ko.join(', ') + '.' : '') + ' Complétez titre/type/chambres avec ✏ Modifier, puis Publier et Synchroniser.');
    return true;
  }
  async function collerDepuisPressePapiers() {
    try {
      if (!navigator.clipboard || !navigator.clipboard.read) throw new Error('indispo');
      var items = await navigator.clipboard.read(), fs = [];
      for (var i = 0; i < items.length; i++) for (var j = 0; j < items[i].types.length; j++) { var t = items[i].types[j]; if (/^image\/|pdf/.test(t)) { var b = await items[i].getType(t); fs.push(new File([b], 'plan-colle-' + Date.now() + '-' + i + (/pdf/.test(t) ? '.pdf' : '.png'), { type: t })); } }
      if (!fs.length) { msgB('err', 'Le presse-papiers ne contient ni image ni PDF. Copiez d’abord un plan (image) puis réessayez.'); return; }
      await importerFichiers(fs);
    } catch (e) { msgB('err', 'Collage direct impossible ici : sélectionnez la zone « Mes plans » puis appuyez sur Ctrl+V, ou utilisez « Importer mes plans ».'); }
  }
  async function importerLot(f) {
    if (!f) return;
    try {
      var j = JSON.parse(await f.text()); if (j.form !== 'EXB_TFL_PLANS_IMPORT' || !Array.isArray(j.plans)) throw new Error('fichier non reconnu');
      var a = plans(), n = 0, dd = 0;
      j.plans.forEach(function (x) { if (a.some(function (p) { return p.attendu && p.attendu === x.attendu; })) { dd++; return; } var p = Object.assign({}, x); p.ref = refSuivante(a); p.publie = false; p.licence = x.licence || ''; p.statut = 'disponible'; a.push(p); n++; });
      put(a); msgB('good', n + ' plan(s) importé(s) en brouillon' + (dd ? ' (' + dd + ' déjà présent(s))' : '') + '. Non publiés : renseignez les droits d’utilisation de chacun avant de publier.');
    } catch (e) { msgB('err', 'Import impossible : ' + erreur(e)); }
  }
  async function joindreUn(f) {
    if (!f || !S.fileRef) return;
    if (!besoinServeur(msgB)) return;
    if (f.size > 4 * 1048576) { msgB('err', 'Fichier trop lourd (4 Mo maximum) : exportez le PDF plus léger.'); return; }
    S.bcls = ''; S.bmsg = 'Envoi du fichier…'; refresh();
    try {
      await rpc('tfl_plan_fichier_poser', { p_ref: S.fileRef, p_nom: f.name, p_mime: f.type || 'application/pdf', p_b64: await aB64(f) });
      var a = plans(), p = a.filter(function (x) { return x.ref === S.fileRef; })[0]; if (p) { p.fichier_nom = f.name; put(a); }
      msgB('good', '✔ Fichier enregistré pour ' + S.fileRef + '.');
    } catch (e) { msgB('err', String(e.message).indexOf('plan_inconnu') >= 0 ? 'Ce plan n’est pas encore sur le serveur : cliquez d’abord « Synchroniser ».' : 'Échec : ' + erreur(e)); }
  }
  async function joindrePlusieurs(fs) {
    fs = Array.prototype.slice.call(fs || []); if (!fs.length) return;
    if (!besoinServeur(msgB)) return;
    try {
      await rpc('tfl_plans_publier', { p_plans: plans().slice(0, 200) });
      var ok = 0, skip = [], big = [];
      for (var i = 0; i < fs.length; i++) {
        var f = fs[i], a = plans(), p = a.filter(function (x) { return x.attendu === f.name || x.fichier_nom === f.name; })[0];
        if (!p) { skip.push(f.name); continue; } if (f.size > 4 * 1048576) { big.push(f.name); continue; }
        S.bcls = ''; S.bmsg = 'Envoi ' + (i + 1) + '/' + fs.length + ' : ' + f.name + '…'; refresh();
        await rpc('tfl_plan_fichier_poser', { p_ref: p.ref, p_nom: f.name, p_mime: f.type || 'application/pdf', p_b64: await aB64(f) }); p.fichier_nom = f.name; put(a); ok++;
      }
      msgB('good', '✔ ' + ok + ' PDF joint(s).' + (skip.length ? ' Sans plan correspondant : ' + skip.join(', ') + '.' : '') + (big.length ? ' Trop lourds (4 Mo max) : ' + big.join(', ') + '.' : ''));
    } catch (e) { msgB('err', 'Échec : ' + erreur(e)); }
  }
  async function chargerEsquisses() {
    if (!besoinServeur(msgE)) return;
    S.ecls = ''; S.emsg = '…'; refresh();
    try { var r = await rpc('tfl_esquisses_liste'); S.esq = r || []; msgE('', S.esq.length + ' esquisse(s)'); } catch (e) { msgE('err', 'Échec : ' + erreur(e)); }
  }
  async function ouvrirEsquisse(chemin) {
    try {
      var c = sb().cfg(); await sb().api('/auth/v1/user'); /* renouvelle la session si besoin */
      var r = await fetch(c.url + '/storage/v1/object/tfl-esquisses/' + chemin.split('/').map(encodeURIComponent).join('/'), { headers: { apikey: c.key, Authorization: 'Bearer ' + sb().token() } });
      if (!r.ok) throw new Error(r.status); root.open(URL.createObjectURL(await r.blob()), '_blank');
    } catch (x) { msgE('err', 'Ouverture impossible (' + erreur(x) + ').'); }
  }
  async function decider(id, statut, bouton) {
    if (!besoinServeur(msgE)) return;
    var c = $('tplc_' + id), txt = c ? c.value : '';
    try {
      await rpc('tfl_esquisse_decider', { p_id: id, p_statut: statut, p_commentaire: txt });
      S.esq.forEach(function (x) { if (String(x.id) === String(id)) { x.statut = statut; x.commentaire = txt; } });
      msgE('good', '✔ Esquisse « ' + EL[statut] + ' ».');
    } catch (x) { msgE('err', 'Échec : ' + erreur(x)); }
  }

  /* ---------- événements (une seule fois, délégués : survivent aux réaffichages du module) ---------- */
  function clic(e) {
    var b = e.target.closest && e.target.closest('[data-pl]'); if (!b || !$('tflBox') || !$('tflBox').contains(b)) return;
    var a = b.getAttribute('data-pl'), r = b.getAttribute('data-r'), p = r ? plans().filter(function (x) { return x.ref === r; })[0] : null;
    if (a === 'tab') { lireFormulaire(); S.tab = b.getAttribute('data-t') === 'esq' ? 'esq' : 'cat'; refresh(); return; }
    if (a === 'login') { try { root.show('cloudSync'); } catch (x) { say('Ouvrez le menu « Compte en ligne » du logiciel pour vous connecter.', 'info'); } return; }
    if (a === 'save') { enregistrer(); return; }
    if (a === 'new') { vider(); refresh(); return; }
    if (a === 'sync') { synchroniser(); return; }
    if (a === 'etat') { reservations(); return; }
    if (a === 'mes') { $('tplMes').click(); return; }
    if (a === 'imp') { $('tplImp').click(); return; }
    if (a === 'pdfs') { if (!besoinServeur(msgB)) return; $('tplPdfs').click(); return; }
    if (a === 'coller') { collerDepuisPressePapiers(); return; }
    if (a === 'esqLoad') { chargerEsquisses(); return; }
    if (a === 'esqFile') { ouvrirEsquisse(b.getAttribute('data-f')); return; }
    if (a === 'esqDec') { decider(b.getAttribute('data-id'), b.getAttribute('data-d'), b); return; }
    if (!p) return;
    if (a === 'file') { S.fileRef = r; $('tplPdf').click(); return; }
    if (a === 'copy') { copierTexte(p.ref + ' — ' + (p.titre || '')); return; }
    if (a === 'edit') {
      S.edit = r; S.img = p.apercu || ''; S.d = { titre: p.titre || '', type: p.type || '', ch: p.chambres || '', niv: p.niveaux || '', surf: p.surface || '', desc: p.description || '', src: p.source || '', lic: p.licence || '' };
      S.fmsg = ''; S.fcls = ''; refresh(); try { $('tplForm').scrollIntoView({ block: 'start' }); } catch (x) { /* ignoré */ } return;
    }
    if (a === 'pub') { if (!p.publie && !p.licence) { say('Renseignez d’abord les droits d’utilisation de ce plan (✏ Modifier).', 'warn'); return; } maj(r, function (x) { x.publie = !x.publie; return 'keep'; }); return; }
    if (a === 'lib') { maj(r, function (x) { x.statut = 'disponible'; x.reserve_nom = x.reserve_tel = x.reserve_sujet = ''; }); return; }
    if (a === 'att') { maj(r, function (x) { x.statut = 'attribue'; }); return; }
    if (a === 'fer') { maj(r, function (x) { x.statut = 'ferme'; }); return; }
    if (a === 'del') {
      if (p.statut === 'reserve' || p.statut === 'attribue') { say('Plan réservé ou attribué : libérez-le d’abord.', 'warn'); return; }
      if (typeof root.confirm === 'function' && !root.confirm('Supprimer ce plan de cet appareil ?')) return;
      put(plans().filter(function (x) { return x.ref !== r; })); refresh();
    }
  }
  function saisie(e) {
    var t = e.target; if (!t || !t.classList) return;
    if (t.classList.contains('tplF') && t.id && t.id.indexOf('tpl_') === 0) S.d[t.id.slice(4)] = t.value;
    else if (t.classList.contains('tplC') && t.id) { var id = t.id.slice(5); S.esq.forEach(function (x) { if (String(x.id) === id) x.commentaire = t.value; }); }
  }
  function fichier(e) {
    var t = e.target, k = t && t.getAttribute && t.getAttribute('data-plf'); if (!k || !$('tflBox') || !$('tflBox').contains(t)) return;
    var fs = Array.prototype.slice.call(t.files || []); t.value = '';
    if (k === 'img') {
      var f = fs[0]; if (!f) return; var u = URL.createObjectURL(f);
      charge(u).then(function (im) { S.img = jpeg(miniature(im, 640)); URL.revokeObjectURL(u); refresh(); }, function () { URL.revokeObjectURL(u); S.fcls = 'err'; S.fmsg = 'Image illisible.'; refresh(); });
    } else if (k === 'pdf') joindreUn(fs[0]);
    else if (k === 'imp') importerLot(fs[0]);
    else if (k === 'mes') importerFichiers(fs);
    else if (k === 'pdfs') joindrePlusieurs(fs);
  }
  function clavier(e) {
    var t = e.target; if (!t || !t.closest || !t.closest('#tplForm')) return;
    var mod = e.ctrlKey || e.metaKey, k = String(e.key || '').toLowerCase();
    if (mod && !e.altKey && (k === 's' || k === 'enter')) { e.preventDefault(); enregistrer(); } /* Ctrl+S / Ctrl+Entrée */
    else if (k === 'escape' && S.edit) { e.preventDefault(); vider(); refresh(); }
  }
  function colle(e) {
    var t = e.target; if (!t || !t.closest || !t.closest('#tflPl') || S.tab !== 'cat') return;
    var cd = e.clipboardData; if (!cd || !cd.files || !cd.files.length) return; /* texte : le collage normal du champ fonctionne */
    var fs = Array.prototype.slice.call(cd.files); e.preventDefault(); importerFichiers(fs);
  }
  if (!root.__exbTflPlansBound && root.document) {
    root.__exbTflPlansBound = 1;
    document.addEventListener('click', clic);
    document.addEventListener('input', saisie);
    document.addEventListener('change', function (e) { saisie(e); fichier(e); });
    document.addEventListener('keydown', clavier);
    document.addEventListener('paste', colle);
  }

  root.EXB_TFL_PLANS = { html: html, importer: importerFichiers, version: 'V236i' };
})(typeof window !== 'undefined' ? window : this);
