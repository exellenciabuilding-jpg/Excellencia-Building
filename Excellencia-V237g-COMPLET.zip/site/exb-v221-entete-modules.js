/* Excellencia Building V221e — EN-TÊTE DES PIÈCES ÉCRITES pour les rapports des modules ARCHITECTURE.
 * Concerne : Analyse de site, Coordination IFC / BCF, Contrôle réglementaire, Règles IDS, Matériaux & finitions, Programme & surfaces.
 * Chaque rapport reprend la mise en page officielle des pièces écrites (lettres, convocations…) : logo, nom, slogan, coordonnées et mentions légales
 * de l'entreprise (identité enregistrée dans le logiciel : EXBId), filet or et bleu, bloc Réf. / Projet / lieu et date, titre encadré,
 * puis pied de page avec QR code « Vérifier ce document », code de contrôle, coordonnées et pagination.
 * Aucune donnée n'est inventée : tout vient de l'identité enregistrée ; une information absente n'est tout simplement pas affichée.
 * API : EXBENT.wrap(htmlComplet, {prefix, sub}) -> document HTML complet (même gabarit que les pièces écrites).
 * Les modules appellent EXBENT.wrap avant document.write ; si ce fichier est absent, ils impriment comme avant. */
(function (w) {
  'use strict';
  if (w.EXBENT) return;
  var d = w.document;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function frDate(dt) { try { return (dt || new Date()).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }); } catch (e) { return ''; } }
  function ident() { try { return (w.EXBId && w.EXBId.get && w.EXBId.get()) || {}; } catch (e) { return {}; } }
  function who() { try { var op = w.EXBOperateur && w.EXBOperateur.who && w.EXBOperateur.who(); if (op) return op; } catch (e) { } return ''; }
  function logoUrl(I) {
    var l = I.logo || '';
    if (!l) { try { l = (w.EXB81 && w.EXB81.logo && w.EXB81.logo()) || ''; } catch (e) { } }
    if (!l) l = 'icon-192.png';   /* logo officiel Excellencia Building du logiciel (même repli que l'identité d'entreprise et le PDF) */
    if (/^(data:|https?:|blob:)/.test(l)) return l;
    try { if (l) return new URL(l, w.location.href).href; } catch (e) { }
    return l;
  }
  /* numéro de référence : PRÉFIXE-ANNÉE-NNN, compteur local par préfixe et par année (comme LTR-2026-006 pour les lettres) */
  function nextNo(prefix) {
    var y = new Date().getFullYear(), k = 'exb_ent_no_' + prefix + '_' + y, n = 0;
    try { n = (Number(localStorage.getItem(k)) || 0) + 1; localStorage.setItem(k, String(n)); } catch (e) { n = 1; }
    return prefix + '-' + y + '-' + ('000' + n).slice(-3);
  }
  /* QR de vérification : vérificateur de l'entreprise s'il existe, sinon QR du module commun de rapports ; sinon pas de QR (jamais de faux code) */
  function qr(title, sub, no, bodyText, I, prefix) {
    try {
      if (w.EXBVerif && w.EXBVerif.docUrl && w.EXBVerif.qrPng) {
        var c = w.EXBVerif.docUrl({ title: title, sub: sub, digest: bodyText, nom: I.name || '', no: no, date: new Date().toISOString().slice(0, 10), prefix: prefix, detail: 'Rapport de module' });
        var im = c && c.url ? w.EXBVerif.qrPng(c.url) : '';
        if (im) return { img: im, hash: c.hash };
      }
    } catch (e) { }
    try {
      var R = w.EXBRapport;
      if (R && R.qrData) { var q = R.qrData(title, { prefix: prefix, sousTitre: sub, ref: no }, String(bodyText || '')); if (q && q.img) return { img: q.img, hash: q.ref || '' }; }
    } catch (e) { }
    return null;
  }
  /* V236m : couleurs des Paramètres (identiques à l'origine tant qu'elles ne sont pas modifiées) */
  function cols(I) {
    var d = { navy: '#173565', gold: '#c49a38', gtx: '#8a6a1c', band: '#eef2fa' };
    try {
      if (!(w.EXBId && w.EXBId.palette)) return d;
      var P = w.EXBId.palette(I), lc = function (v) { return String(v || '').trim().toLowerCase(); };
      var hx = function (a) { return '#' + a.map(function (x) { return ('0' + Math.round(Math.max(0, Math.min(1, x)) * 255).toString(16)).slice(-2); }).join(''); };
      if (lc(I.primary) && lc(I.primary) !== '#173565') { d.navy = hx(P.NAVY); d.band = hx(P.BAND); }
      if (lc(I.accent) && lc(I.accent) !== '#c49a38') { d.gold = hx(P.GOLD); d.gtx = hx(P.GOLDTXT); }
    } catch (e) { }
    return d;
  }
  function themed(css, I) { var c = cols(I); return css.replace(/#c49a38/g, c.gold).replace(/#173565/g, c.navy).replace(/#8a6a1c/g, c.gtx).replace(/#eef2fa/g, c.band); }
  var CSS = '@page{size:A4;margin:12mm 14mm 16mm;@bottom-center{content:"Page " counter(page) " / " counter(pages);font:8pt Arial,sans-serif;color:#666}}'
    + '*{box-sizing:border-box}html,body{margin:0;font:10.5pt/1.45 Arial,Helvetica,sans-serif;color:#111;-webkit-print-color-adjust:exact;print-color-adjust:exact}'
    + '.wrap{width:100%;border-collapse:collapse;border:0}.wrap>thead>tr>td,.wrap>tbody>tr>td,.wrap>tfoot>tr>td{border:0;padding:0;vertical-align:top}'
    + '.hd{display:flex;align-items:center;gap:16px;border-bottom:3px solid #c49a38;padding-bottom:9px;margin-bottom:12px}.rl{height:0;border-top:1.5px solid #173565;margin:-8px 0 8px}'
    + '.lg{display:flex;flex-wrap:wrap;gap:4px 8px;font-size:7.5pt;color:#444;margin:0 0 10px}.lg span{background:#f3f5fa;border:1px solid #d5dbe8;border-radius:3px;padding:1px 6px}'
    + '.hd img{height:78px;max-width:200px;object-fit:contain;flex:none}.hd .nm{white-space:nowrap;font-size:18pt;font-weight:bold;color:#173565;line-height:1.1;letter-spacing:.2pt}'
    + '.hd .tg{font-size:9.5pt;color:#8a6a1c;font-style:italic;margin-top:2px}.hd .ct{margin-left:auto;text-align:right;font-size:8.5pt;color:#333;line-height:1.45;max-width:46%}'
    + '.rf{display:flex;justify-content:space-between;gap:10px;font-size:10pt;margin-bottom:10px}'
    + '.ft{border-top:2px solid #173565;margin-top:10px;padding-top:5px;display:flex;align-items:center;gap:10px;font-size:7.5pt;color:#444;line-height:1.35}.ft .fm{flex:1;text-align:center}'
    + '.ft .qr{flex:none;width:19mm;height:19mm;image-rendering:pixelated}.ft .qt{width:30mm;font-size:7pt;text-align:left}.ft b{color:#173565}'
    + '@media print{.wrap>thead{display:table-row-group}.wrap>tfoot>tr>td{height:27mm}.wrap>tfoot .ftw{position:fixed;left:0;right:0;bottom:0;margin:0;background:#fff}}'
    + '.bd h2.doct{font-size:16pt;text-align:center;text-transform:uppercase;color:#173565;border:0;border-top:1px solid #c49a38;border-bottom:1px solid #c49a38;padding:8px 0;margin:6px 0 12px}'
    + '.bd h2{font-size:13pt;color:#173565;border-bottom:1px solid #173565;margin:16px 0 6px;padding-bottom:2px}.bd h3{font-size:11.5pt;color:#173565;margin:12px 0 4px}'
    + '.bd table{border-collapse:collapse}.bd th{background:#eef2fa;color:#173565}';
  function wrap(html, o) {
    try {
      o = o || {};
      html = String(html || '');
      var tm = html.match(/<title>([\s\S]*?)<\/title>/i), st = html.match(/<style>([\s\S]*?)<\/style>/i), bm = html.match(/<body[^>]*>([\s\S]*)<\/body>/i);
      if (!bm) return html;
      var body = bm[1], rawTitle = tm ? tm[1] : (o.sub || 'Rapport'), proj = '', title = o.sub || rawTitle;
      var hm = body.match(/<h2[^>]*>([\s\S]*?)<\/h2>/i);
      if (hm) {
        var plain = hm[1].replace(/<[^>]+>/g, '').trim(), cut = plain.indexOf(' — ');
        if (cut > 0) { title = plain.slice(0, cut).trim(); proj = plain.slice(cut + 3).trim(); } else title = plain || title;
        body = body.replace(hm[0], '');
      }
      var I = ident(), name = I.name || 'Excellencia Building';
      var place = (w.EXBId && w.EXBId.placeLine) ? w.EXBId.placeLine(I) : (I.address || '');
      var lines = [place, I.phone ? 'Tél : ' + I.phone : '', I.email ? 'E-mail : ' + I.email : '', I.website || ''].filter(Boolean);
      var contact = [I.phone ? 'Tél : ' + I.phone : '', I.email ? 'E-mail : ' + I.email : '', I.website || ''].filter(Boolean).join(' · ');
      var chips = I.legal ? String(I.legal).split(/\r?\n+/).map(function (z) { return z.trim(); }).filter(Boolean) : [];
      var no = nextNo(o.prefix || 'RAP'), bodyText = body.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 4000);
      var Q = qr(title, (o.sub || title) + (proj ? ' · ' + proj : ''), no, bodyText, I, o.prefix || 'RAP');
      var lg = logoUrl(I);
      var head = '<div class="hd">' + (lg ? '<img src="' + esc(lg) + '" alt="">' : '') + '<div><div class="nm">' + esc(name) + '</div>' + (I.tagline ? '<div class="tg">' + esc(I.tagline) + '</div>' : '') + (I.specialties ? '<div class="tg" style="font-style:normal;font-size:7.5pt;letter-spacing:.4pt;color:#555">' + esc(I.specialties) + '</div>' : '') + '</div><div class="ct">' + lines.map(esc).join('<br>') + '</div></div><div class="rl"></div>'
        + (chips.length ? '<div class="lg">' + chips.map(function (z) { return '<span>' + esc(z) + '</span>'; }).join('') + '</div>' : '');
      var by = who();
      var top = '<div class="rf"><div><b>Réf. :</b> ' + esc(no) + (proj ? '<br><b>Projet :</b> ' + esc(proj) : '') + (by ? '<br><b>Établi par :</b> ' + esc(by) : '') + '</div><div style="text-align:right">' + esc(I.city ? I.city + ', ' : '') + 'le ' + esc(frDate()) + '</div></div>'
        + '<h2 class="doct">' + esc(title) + '</h2>';
      var foot = '<div class="ft">' + (Q ? '<img class="qr" src="' + esc(Q.img) + '" alt="QR"><div class="qt"><b>Vérifier ce document</b><br>Scannez le QR code' + (Q.hash ? '<br>Code : ' + esc(String(Q.hash).toUpperCase()) : '') + '</div>' : '')
        + '<div class="fm">' + esc(no) + ' · ' + esc(frDate()) + ([w.EXBId && w.EXBId.footerExtra ? w.EXBId.footerExtra(I) : '', w.EXBId && w.EXBId.bannerLine ? w.EXBId.bannerLine(I) : ''].filter(Boolean).map(function (z) { return '<br><b>' + esc(z) + '</b>'; }).join('')) + '</div></div>';
      /* styles propres au rapport (tableaux, tailles) : conservés, après ceux de l'en-tête, pour ne rien casser du contenu */
      return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>' + esc(no + ' ' + title) + '</title><style>' + themed(CSS, I) + (st ? st[1].replace(/body\s*\{[^}]*\}/i, '') : '') + '</style></head><body data-exb-habillage="own">'
        + '<table class="wrap"><thead><tr><td>' + head + '</td></tr></thead><tbody><tr><td class="bd">' + top + body + '</td></tr></tbody><tfoot><tr><td><div class="ftw">' + foot + '</div></td></tr></tfoot></table></body></html>';
    } catch (e) { return html; }
  }

  /* V221f : mêmes en-tête et pied de page pour les PDF des modules d'ingénierie (Électricité, Plomberie, Topographie, VRD, Études du sol / Géotechnique).
   * Reprend le style « pièce écrite » du générateur PDF (EXBPdf) : logo, nom, slogan, coordonnées, filet or / bleu, bloc Réf. · Projet · Date, titre encadré,
   * pied de page avec QR « Vérifier ce document ». Cachet et signature (visa) : repris de l'identité / de l'opérateur enregistré, comme sur les pièces écrites. Rien n'est inventé. */
  function piece(o) {
    try {
      if (!o || o.style) return o;
      var sub = String(o.sousTitre || ''), cut = sub.indexOf(' — '), head0 = cut > 0 ? sub.slice(0, cut).trim() : '', isNo = /^[A-Z0-9]{2,8}-\d{4}-\d+/i.test(head0), no = isNo ? head0 : '', obj = isNo ? sub.slice(cut + 3).trim() : sub.trim(), proj = '';
      (o.rows || []).some(function (r) { if (/^projet/i.test(String(r[0] || '')) && String(r[1] || '').trim() && !/^—/.test(String(r[1]))) { proj = String(r[1]).replace(/\s+—\s+—?$/, '').replace(/\s+—\s*$/, '').trim(); return true; } return false; });
      var by = who(), meta = [['Réf.', no], ['Projet', proj], ['Objet', obj], ['Établi par', by], ['Date', frDate()]].filter(function (r) { return String(r[1] || '').trim(); });
      return Object.assign({}, o, { style: 'piece', engine: 'local', meta: meta, refFooter: no || o.refFooter || '' });
    } catch (e) { return o; }
  }
  w.EXBENT = { wrap: wrap, piece: piece, nextNo: nextNo, version: 'V221e' };
})(typeof window !== 'undefined' ? window : globalThis);
