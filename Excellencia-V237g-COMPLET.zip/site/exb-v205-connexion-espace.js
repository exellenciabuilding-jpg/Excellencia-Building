/* Excellencia Building V205l — ÉCRAN DE CONNEXION D'ESPACE (comptable, ingénieur, architecte, chantier, direction, administration, magasin, formation).
 *
 * Le collaborateur ouvre le lien reçu (/comptable, /ingenieur…). Au lieu de l'écran local « identifiant admin », il voit l'écran de SON espace :
 *   • Se connecter       : e-mail + mot de passe du compte rattaché à l'entreprise (compte en ligne, Supabase) ;
 *   • Première connexion : création du compte avec l'adresse e-mail invitée (+ code d'invitation si demandé) ;
 *   • Mot de passe oublié : un CODE à 6 chiffres est envoyé par e-mail ; la personne le saisit ici avec son nouveau mot de passe (V205z : plus de lien à ouvrir,
 *     donc plus de jeton perdu quand le lien s'ouvre dans un autre navigateur ou une autre application). Le lien de confirmation / de réinitialisation reste accepté.
 * Après l'authentification, le compte est rattaché à l'entreprise (equipe_reclamer, sinon code d'invitation), puis la FONCTION est vérifiée
 * contre l'espace : une fonction non admise voit « Accès refusé » et un bouton vers son propre espace.
 *
 * SÉCURITÉ : cet écran n'est qu'une porte d'entrée. Les droits réels restent appliqués par le serveur (droits_fonction, enregistrer, RLS) ;
 * aucun mot de passe n'est stocké par ce module (la session Supabase est gardée par exbSb, comme avant).
 * Sans serveur configuré, ou pour le compte imposé par licence (exb-account.js), rien ne change : l'écran de connexion local reste utilisé.
 * API : EXBGATE.open() / .close() / .needGate() / .espace(). */
(function (w, d) {
  'use strict';
  var GID = 'exbGate', EMAIL_KEY = 'exb_gate_email', INV_KEY = 'exb_inv_code', BYPASS = 'exb_gate_bypass';
  var HTML_OF = { formation: 'espace-formation.html' };
  /* fonction du compte → page de son espace (même correspondance que le message d'invitation, exb-equipe.js) */
  var LIEN = { comptable: 'comptable.html', architecte: 'architecte.html', direction: 'direction.html', rh: 'administration.html', magasinier: 'magasin.html',
    formateur: 'espace-formation.html', chef_projet: 'chantier.html', conducteur: 'chantier.html', bureau_etudes: 'ingenieur.html' };
  var FLAB = { polyvalent: 'Polyvalent', direction: 'Direction', chef_projet: 'Chef de projet', conducteur: 'Conducteur de travaux', bureau_etudes: 'Ingénieur', architecte: 'Architecte',
    formateur: 'Formateur', comptable: 'Comptable', rh: 'Ressources humaines', magasinier: 'Magasinier' };
  var view = 'login', ctx = {}, busy = false, fails = 0, lockUntil = 0, timer = null, resendAt = 0;

  function $(i) { return d.getElementById(i); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k) { try { return w.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { w.localStorage.setItem(k, v); } catch (e) {} }
  function lsDel(k) { try { w.localStorage.removeItem(k); } catch (e) {} }
  function ssGet(k) { try { return w.sessionStorage.getItem(k); } catch (e) { return null; } }
  function ssSet(k, v) { try { w.sessionStorage.setItem(k, v); } catch (e) {} }
  function fonc(f) { return FLAB[f] || f || '—'; }

  /* ---------- l'espace demandé ---------- */
  function defs() { try { return w.EXB_SHELL.espaces() || {}; } catch (e) { return {}; } }
  function key() {
    var k = lsGet('exb_espace') || '';
    try { var q = new URLSearchParams(w.location.search).get('espace'); if (q) k = q; } catch (e) {}
    return defs()[k] ? k : '';
  }
  function cur() { return defs()[key()] || { t: 'Votre espace', sub: '', ic: '🔐', fonctions: [] }; }
  function pageUrl() { var k = key(); if (!k) return w.location.origin + w.location.pathname; return w.location.origin + w.location.pathname.replace(/[^\/]*$/, '') + (HTML_OF[k] || (k + '.html')); }
  function names(list) { return (list || []).map(fonc).join(', '); }
  /* V236 : tous les espaces qui conviennent à la fonction (au lieu d'un seul lien ou de « aucun espace ») */
  function boutonsEspaces(f, lien) {
    var D = defs(), h = '';
    Object.keys(D).forEach(function (k) { var e = D[k]; if (e && e.fonctions && (f === 'polyvalent' || e.fonctions.indexOf(f) >= 0)) h += '<button type="button" class="g2" data-go="' + esc(HTML_OF[k] || (k + '.html')) + '">' + esc((e.ic || '') + ' Ouvrir : ' + e.t) + '</button>'; });
    if (!h && lien) h = '<button type="button" class="g2" data-go="' + esc(lien) + '">Ouvrir l’espace de ma fonction</button>';
    return h || '<p>Aucun espace dédié à votre fonction : contactez votre administrateur.</p>';
  }

  /* ---------- serveur, session, écran local ---------- */
  function srv() {
    var u = '', k = '';
    try { var c = w.exbSb && w.exbSb.cfg && w.exbSb.cfg(); if (c) { u = c.url; k = c.key; } } catch (e) {}
    if (!u || !k) { var f = w.EXB_SUPABASE || {}; u = u || f.url; k = k || f.key; }
    return { u: String(u || '').replace(/\/+$/, ''), k: String(k || '') };
  }
  function configured() { var s = srv(); return !!(s.u && s.k); }
  function onlineIn() { try { return !!(w.exbSb && w.exbSb.isIn()); } catch (e) { return false; } }
  function localOpen() { try { return exbSessionStorage.getItem('exb_logged') === '1'; } catch (e) { return false; } }
  function loginVisible() { var l = $('loginScreen'); return !!(l && l.style.display !== 'none'); }
  /* La porte est montrée si un espace est demandé et que l'ouverture n'est pas déjà complète (session locale valide ET compte en ligne connecté). */
  function needGate() {
    if (!key() || ssGet(BYPASS) === '1' || w.EXB_ACCT_ON || w.EXB_FIELD_CONFIG || !configured()) return false;
    if (ssGet(OFFOK) === '1' && navigator.onLine === false) return false;   /* V229h : ouverture hors connexion en cours */
    return !(onlineIn() && localOpen());
  }

  /* ---------- appels d'authentification (Supabase GoTrue) ---------- */
  async function auth(path, body, method, bearer) {
    var s = srv(), h = { apikey: s.k, 'Content-Type': 'application/json' };
    if (bearer) h.Authorization = 'Bearer ' + bearer;
    var r = await fetch(s.u + path, { method: method || 'POST', headers: h, body: JSON.stringify(body || {}) }), j = null;
    try { j = await r.json(); } catch (e) {}
    return { ok: r.ok, status: r.status, j: j || {} };
  }
  function frErr(r) {
    var j = r.j || {}, m = (String(j.error_description || j.msg || j.message || j.error || '') + ' ' + String(j.error_code || '')).toLowerCase();
    if (/invalid login|invalid_credentials|invalid grant/.test(m)) return 'E-mail ou mot de passe incorrect. Si vous n’avez jamais choisi de mot de passe (première connexion après invitation), touchez « Mot de passe oublié ? » : un code vous est envoyé par e-mail.';
    if (/not confirmed|email_not_confirmed/.test(m)) return 'Adresse e-mail pas encore confirmée : ouvrez le message reçu et cliquez sur le lien de confirmation.';
    if (/already registered|user_already_exists|already been registered/.test(m)) return 'Cette adresse est déjà enregistrée : touchez « Mot de passe oublié ? » pour recevoir un code et choisir votre mot de passe.';
    if (r.status === 429 || /rate limit|too many|over_.*_rate_limit/.test(m)) return 'Trop de tentatives. Patientez quelques minutes avant de réessayer.';
    if (/otp_expired|token has expired|invalid.*(token|otp)|otp.*invalid/.test(m)) return 'Code incorrect ou expiré. Vérifiez-le, ou demandez-en un nouveau.';
    if (/weak_password|password.*(short|weak|least|characters)/.test(m)) return 'Mot de passe trop faible : 8 caractères minimum, avec lettres et chiffres.';
    if (/signup.*disabled|signups not allowed/.test(m)) return 'La création de compte est désactivée sur le serveur. Contactez l’administrateur.';
    if (/same.*password|different from the old/.test(m)) return 'Choisissez un mot de passe différent de l’ancien.';
    if (/invalid.*email|email.*invalid|unable to validate email/.test(m)) return 'Adresse e-mail invalide.';
    return 'Opération impossible (' + (r.status || 'réseau') + '). Réessayez dans un instant.';
  }
  function setSession(j) {
    w.exbSb.set({ access_token: j.access_token, refresh_token: j.refresh_token, exp: Date.now() + (Number(j.expires_in) || 3600) * 1000 });
  }
  function validEmail(v) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v); }
  function validPass(v) { return v.length >= 8; }

  /* ---------- rattachement à l'entreprise + contrôle de la fonction ---------- */
  function rpc(n, b) { return w.exbSb.api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  /* V227e : l'échec de equipe_reclamer n'est plus avalé en silence. Avant, une invitation « Comptable » non appliquée par le serveur faisait retomber la personne
     sur le code de l'entreprise (= « Polyvalent » définitif) sans que personne ne sache pourquoi. Le détail est gardé et montré sur l'écran « Accès refusé ». */
  function diagTxt(e) { var c = e && (e.code || e.status) || '', m = String((e && e.message) || e || '').replace(/\s+/g, ' ').slice(0, 180); return (c ? c + ' · ' : '') + m; }
  async function attach(email, code) {
    var recl = '', via = '';
    try { await rpc('equipe_reclamer'); } catch (e) { recl = diagTxt(e); }
    var o = null, err = null, joinErr = '';
    try { o = await rpc('mon_organisation'); } catch (e) { err = e; }
    if (err && !(o && o.id)) {
      var t = String((err && err.message) || '') + ' ' + String((err && err.code) || '');
      return { st: 'err', msg: /42883|PGRST202|404|schema cache|mon_organisation/i.test(t) ? 'Le serveur n’est pas à jour (migration « équipe » absente). Prévenez l’administrateur.' : 'Le serveur ne répond pas. Vérifiez votre connexion internet puis réessayez.' };
    }
    if (!(o && o.id)) {
      var c = String(code || lsGet(INV_KEY) || '').trim().toLowerCase();
      if (c) { try { o = await rpc('rejoindre_organisation', { p_code: c, p_nom_user: email || null }); if (o && o.id) via = 'code'; } catch (e) { joinErr = String((e && e.message) || ''); } }
    }
    if (!(o && o.id)) return { st: 'noorg', msg: joinErr + (recl ? ' [invitation : ' + recl + ']' : '') };
    /* V227g : la fonction est relue DIRECTEMENT dans la table des membres quand mon_organisation ne la donne pas ou répond « Polyvalent ».
       Cause constatée : la base contenait bien « Comptable », mais mon_organisation (ancienne version du serveur) ne renvoyait pas la fonction → « Polyvalent » à chaque connexion. */
    var brut = o.fonction == null ? '(absente)' : String(o.fonction), direct = '';
    if (o.role !== 'admin' && (!o.fonction || o.fonction === 'polyvalent')) {
      try {
        var u = await w.exbSb.api('/auth/v1/user'), rows = u && u.id ? await w.exbSb.api('/rest/v1/membres?org_id=eq.' + encodeURIComponent(o.id) + '&user_id=eq.' + encodeURIComponent(u.id) + '&select=role,fonction&limit=1') : null;
        if (rows && rows[0]) { direct = String(rows[0].fonction || ''); if (rows[0].fonction) o.fonction = rows[0].fonction; if (rows[0].role) o.role = rows[0].role; }
      } catch (e) { direct = 'lecture impossible'; }
    }
    var f = o.fonction || 'polyvalent', sp = cur();
    if (key() && o.role !== 'admin' && f !== 'polyvalent' /* V236 */ && sp.fonctions.indexOf(f) < 0) return { st: 'refus', org: o, recl: recl, via: via, brut: brut, direct: direct };   /* V205z : sans espace demandé (ex. lien ouvert sur la page d'accueil), pas de contrôle de fonction */
    return { st: 'ok', org: o };
  }
  /* V229h — OUVERTURE HORS CONNEXION. Avant : sans internet, l'écran de connexion refusait tout (« Pas de connexion internet : connectez-vous pour continuer »), même pour un membre déjà
     connecté la veille sur cet appareil. Maintenant, à chaque connexion EN LIGNE réussie, l'appareil mémorise une EMPREINTE du mot de passe (PBKDF2-SHA256, sel aléatoire, 150 000 tours : le
     mot de passe lui-même n'est jamais conservé) et la dernière entreprise/fonction connues. Sans internet, le même e-mail + le même mot de passe rouvrent l'espace, pendant 30 jours après la
     dernière connexion en ligne. Le contrôle de suspension et de délai (exb-acces-membre.js) reprend dès le retour d'internet. */
  var OFFK = 'exb_gate_off', OFFOK = 'exb_gate_off_ok', OFFDAYS = 30, lastPw = '', offNow = false;
  function b64(u) { var t = ''; for (var i = 0; i < u.length; i++) t += String.fromCharCode(u[i]); return w.btoa(t); }
  function unb64(t) { var b = w.atob(t), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  async function pbk(pw, salt) {
    var k = await w.crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
    return new Uint8Array(await w.crypto.subtle.deriveBits({ name: 'PBKDF2', salt: salt, iterations: 150000, hash: 'SHA-256' }, k, 256));
  }
  function offAll() { try { return JSON.parse(lsGet(OFFK) || '{}') || {}; } catch (e) { return {}; } }
  async function rememberOffline(email, pw, org) {
    try {
      if (!key() || !email || !org || !org.id) return;
      var all = offAll(), id = email + '|' + key(), r = all[id] || {};
      r.org = { id: org.id, nom: org.nom, role: org.role, fonction: org.fonction || 'polyvalent', code: org.code || null }; r.t = Date.now();
      if (pw) { var salt = w.crypto.getRandomValues(new Uint8Array(16)); r.s = b64(salt); r.h = b64(await pbk(pw, salt)); }
      if (!r.h) return;
      all[id] = r; lsSet(OFFK, JSON.stringify(all));
    } catch (e) {}
  }
  async function offlineLogin(em, pw) {
    try {
      var r = offAll()[em + '|' + key()];
      if (!r || !r.h) return { ok: false, why: 'none' };
      if (Date.now() - r.t > OFFDAYS * 864e5) return { ok: false, why: 'old' };
      var h = await pbk(pw, unb64(r.s)), g = unb64(r.h), diff = h.length ^ g.length;
      for (var i = 0; i < h.length; i++) diff |= h[i] ^ (g[i] || 0);
      if (diff) return { ok: false, why: 'bad' };
      var f = r.org.fonction || 'polyvalent';
      if (r.org.role !== 'admin' && cur().fonctions.indexOf(f) < 0) return { ok: false, why: 'refus', fonction: f };
      return { ok: true, org: r.org };
    } catch (e) { return { ok: false, why: 'none' }; }
  }
  /* true = traité (ouvert ou message affiché) ; false = rien de mémorisé, laisser le message habituel */
  async function tryOffline(em, pw, silent) {
    var r = await offlineLogin(em, pw);
    if (r.ok) { ssSet(OFFOK, '1'); fails = 0; offNow = true; try { finish(em, r.org); } finally { offNow = false; } return true; }
    if (silent) return false;
    if (r.why === 'bad') { fails++; if (fails >= 5) lockUntil = Date.now() + Math.min(300, 30 * Math.pow(2, fails - 5)) * 1000; note('E-mail ou mot de passe incorrect.'); return true; }
    if (r.why === 'old') { note('Votre dernière connexion en ligne date de plus de ' + OFFDAYS + ' jours : reconnectez-vous une fois avec internet.'); return true; }
    if (r.why === 'refus') { note('Votre fonction (' + fonc(r.fonction) + ') n’a pas accès à cet espace.'); return true; }
    note('Pas de connexion internet. Cet appareil ne connaît pas encore votre compte : connectez-vous une première fois avec internet.'); return true;
  }
  async function proceed(email, code) {
    setView('wait', { email: email });
    var r;
    try { r = await attach(email, code); } catch (e) { r = { st: 'err', msg: 'Connexion impossible. Réessayez.' }; }
    if (r.st === 'ok') return finish(email, r.org);
    if (r.st === 'refus') return setView('refus', { email: email, org: r.org, recl: r.recl, via: r.via, brut: r.brut, direct: r.direct });
    if (r.st === 'noorg') return setView('noorg', { email: email, msg: r.msg });
    setView('login', { email: email, err: r.msg });
  }
  function finish(email, org) {
    try { var inf = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); if (!(offNow && inf && inf.on) && w.EXBDB && w.EXBDB.adopt) w.EXBDB.adopt(org); } catch (e) {}
    if (!offNow) { rememberOffline(email, lastPw, org); lastPw = ''; ssSet(OFFOK, ''); }   /* V229h */
    if (email) lsSet(EMAIL_KEY, email);
    lsDel(INV_KEY); fails = 0;
    var wasLogin = loginVisible();
    close();
    try { if (wasLogin && typeof w.exbFinishLogin === 'function') w.exbFinishLogin('Connexion à « ' + cur().t + ' » (' + (email || '') + ')'); } catch (e) {}
    try { w.dispatchEvent(new Event('exb-rights')); } catch (e) {}
    try { w.EXB_SHELL.openCat('home'); } catch (e) {}
  }

  /* ---------- actions des formulaires ---------- */
  function note(msg, ok) { var x = $('gx'); if (x) { x.className = 'gx' + (ok ? ' ok' : ''); x.textContent = msg || ''; } }
  function lock() { var s = Math.ceil((lockUntil - Date.now()) / 1000); return s > 0 ? s : 0; }
  function busyOn(b) { busy = b; var g = $('gok'); if (g) g.disabled = b; }
  async function doLogin(ev) {
    ev.preventDefault(); if (busy) return;
    var em = $('gm').value.trim().toLowerCase(), pw = $('gp').value;
    if (lock()) return note('Trop d’échecs. Réessayez dans ' + lock() + ' s.');
    if (!validEmail(em)) return note('Saisissez votre adresse e-mail.');
    if (!pw) return note('Saisissez votre mot de passe.');
    if (navigator.onLine === false) { busyOn(true); note('Hors connexion : vérification sur cet appareil…', true); try { await tryOffline(em, pw); } finally { busyOn(false); } return; }
    busyOn(true); note('Connexion…', true);
    try {
      var r = await auth('/auth/v1/token?grant_type=password', { email: em, password: pw });
      if (!r.ok || !r.j.access_token) {
        fails++; if (fails >= 5) lockUntil = Date.now() + Math.min(300, 30 * Math.pow(2, fails - 5)) * 1000;
        busyOn(false); return note(frErr(r));
      }
      lastPw = pw; setSession(r.j); busyOn(false); await proceed(em);
    } catch (e) { busyOn(false); if (await tryOffline(em, pw, true)) return; note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  async function doFirst(ev) {
    ev.preventDefault(); if (busy) return;
    var nom = $('gn').value.trim(), em = $('gm').value.trim().toLowerCase(), pw = $('gp').value, pc = $('gc').value, code = ($('gi').value || '').trim().toLowerCase();
    if (nom.length < 2) return note('Saisissez votre nom complet.');
    if (!validEmail(em)) return note('Saisissez l’adresse e-mail indiquée dans votre invitation.');
    if (!validPass(pw)) return note('Mot de passe : 8 caractères minimum.');
    if (pw !== pc) return note('Les deux mots de passe ne sont pas identiques.');
    if (code && !/^[a-z0-9]{4,32}$/.test(code)) return note('Code d’invitation invalide (lettres et chiffres uniquement).');
    if (navigator.onLine === false) return note('Pas de connexion internet : la création du compte nécessite internet.');
    busyOn(true); note('Création du compte…', true);
    try {
      var r = await auth('/auth/v1/signup?redirect_to=' + encodeURIComponent(pageUrl()), { email: em, password: pw, data: { full_name: nom } });
      if (code) lsSet(INV_KEY, code);
      if (!r.ok) {
        busyOn(false);
        if (/already|exists/i.test(JSON.stringify(r.j))) return autoCode(em, nom);
        return note(frErr(r));
      }
      if (r.j.access_token) { lastPw = pw; setSession(r.j); busyOn(false); return proceed(em, code); }
      busyOn(false);
      /* serveur avec confirmation par e-mail : « identities » vide = adresse déjà inscrite (Supabase ne le dit pas, pour la confidentialité) */
      if (Array.isArray(r.j.identities) && r.j.identities.length === 0) return autoCode(em, nom);
      setView('confirm', { email: em });
    } catch (e) { busyOn(false); note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  /* V210e — « Première connexion » sur une adresse déjà enregistrée (création commencée plus tôt, jamais confirmée, ou vrai compte) : on ne dit plus « utilisez votre mot de passe habituel »
     à quelqu'un qui n'en a pas. On envoie directement le code par e-mail ; en le saisissant avec un nouveau mot de passe, la personne prend la main sur le compte. */
  async function autoCode(em, nom) {
    busyOn(true); note('Adresse déjà enregistrée : envoi d’un code par e-mail…', true);
    try {
      var r = await auth('/auth/v1/recover?redirect_to=' + encodeURIComponent(pageUrl()), { email: em });
      busyOn(false);
      if (r.status === 429) return setView('code', { email: em, nom: nom, info: 'Un code vous a déjà été envoyé il y a peu : utilisez le plus récent reçu par e-mail, ou patientez quelques minutes avant d’en demander un autre.' });
      resendAt = Date.now() + 60000; fails = 0; lockUntil = 0; ctx.token = ctx.refresh = null;
      setView('code', { email: em, nom: nom, info: 'Cette adresse était déjà enregistrée (création de compte commencée plus tôt, ou compte existant). Si vous n’avez jamais choisi de mot de passe, rien d’autre à faire : saisissez le code reçu par e-mail avec le mot de passe de votre choix.' });
    } catch (e) { busyOn(false); note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  async function doForgot(ev) {
    ev.preventDefault(); if (busy) return;
    var em = $('gm').value.trim().toLowerCase();
    if (!validEmail(em)) return note('Saisissez votre adresse e-mail.');
    if (navigator.onLine === false) return note('Pas de connexion internet.');
    busyOn(true); note('Envoi…', true);
    try {
      var r = await auth('/auth/v1/recover?redirect_to=' + encodeURIComponent(pageUrl()), { email: em });
      busyOn(false);
      if (r.status === 429) return note(frErr(r));
      resendAt = Date.now() + 60000; fails = 0; lockUntil = 0;
      setView('code', { email: em }); ctx.token = ctx.refresh = null;   /* même réponse que le compte existe ou non (pas de fuite d'information) */
      render();
    } catch (e) { busyOn(false); note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  /* V205z — code reçu par e-mail : vérification (/auth/v1/verify, type recovery) → session → nouveau mot de passe (/auth/v1/user). */
  async function doCode(ev) {
    ev.preventDefault(); if (busy) return;
    var em = ctx.email, pw = $('gp').value, pc = $('gc').value, verified = !!ctx.token;
    var code = verified ? '' : String(($('gk') && $('gk').value) || '').replace(/\D/g, '');
    if (lock()) return note('Trop d’échecs. Réessayez dans ' + lock() + ' s.');
    if (!verified && (code.length < 6 || code.length > 10)) return note('Saisissez le code reçu par e-mail (6 chiffres).');
    if (!validPass(pw)) return note('Mot de passe : 8 caractères minimum.');
    if (pw !== pc) return note('Les deux mots de passe ne sont pas identiques.');
    if (navigator.onLine === false) return note('Pas de connexion internet.');
    busyOn(true); note('Vérification du code…', true);
    try {
      if (!verified) {
        var v = await auth('/auth/v1/verify', { type: 'recovery', email: em, token: code });
        /* compte créé mais jamais confirmé : le code reçu peut être un code de confirmation d'inscription */
        if (!v.ok || !v.j.access_token) { var v2 = await auth('/auth/v1/verify', { type: 'signup', email: em, token: code }); if (v2.ok && v2.j.access_token) v = v2; }
        if (!v.ok || !v.j.access_token) {
          fails++; if (fails >= 5) lockUntil = Date.now() + Math.min(300, 30 * Math.pow(2, fails - 5)) * 1000;
          busyOn(false); return note(frErr(v));
        }
        ctx.token = v.j.access_token; ctx.refresh = v.j.refresh_token; ctx.exp = Number(v.j.expires_in) || 3600;
      }
      note('Enregistrement…', true);
      var r = await auth('/auth/v1/user', { password: pw }, 'PUT', ctx.token);
      if (!r.ok) {
        busyOn(false);
        /* le code est déjà consommé : on garde la session de réinitialisation, la personne n'a qu'à choisir un autre mot de passe */
        var msg = frErr(r); setView('code', { email: em }); return note(msg);
      }
      setSession({ access_token: ctx.token, refresh_token: ctx.refresh, expires_in: ctx.exp });
      fails = 0; ctx.token = ctx.refresh = null;
      lastPw = pw; busyOn(false); proceed((r.j && r.j.email) || em);
    } catch (e) { busyOn(false); note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  async function resend() {
    if (busy || !ctx.email) return;
    var left = Math.ceil((resendAt - Date.now()) / 1000);
    if (left > 0) return note('Patientez ' + left + ' s avant de demander un nouveau code.');
    if (navigator.onLine === false) return note('Pas de connexion internet.');
    busyOn(true); note('Envoi…', true);
    try {
      var r = await auth('/auth/v1/recover?redirect_to=' + encodeURIComponent(pageUrl()), { email: ctx.email });
      busyOn(false);
      if (r.status === 429) return note(frErr(r));
      resendAt = Date.now() + 60000; ctx.token = ctx.refresh = null; fails = 0;
      note('Nouveau code envoyé. Utilisez le plus récent.', true);
    } catch (e) { busyOn(false); note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  async function doNewPass(ev) {
    ev.preventDefault(); if (busy) return;
    var pw = $('gp').value, pc = $('gc').value;
    if (!validPass(pw)) return note('Mot de passe : 8 caractères minimum.');
    if (pw !== pc) return note('Les deux mots de passe ne sont pas identiques.');
    busyOn(true); note('Enregistrement…', true);
    try {
      var r = await auth('/auth/v1/user', { password: pw }, 'PUT', ctx.token);
      if (!r.ok) { busyOn(false); return note(frErr(r)); }
      setSession({ access_token: ctx.token, refresh_token: ctx.refresh, expires_in: ctx.exp });
      var em = (r.j && r.j.email) || ctx.email || '';
      lastPw = pw; busyOn(false); proceed(em);
    } catch (e) { busyOn(false); note('Le serveur est injoignable. Vérifiez votre connexion internet.'); }
  }
  async function doRetry(ev) {
    ev.preventDefault(); if (busy) return;
    var code = ($('gi') && $('gi').value || '').trim().toLowerCase();
    if (code && !/^[a-z0-9]{4,32}$/.test(code)) return note('Code d’invitation invalide (lettres et chiffres uniquement).');
    if (code) lsSet(INV_KEY, code);
    proceed(ctx.email, code);
  }
  function signOut() { try { w.exbSb.set(null); } catch (e) {} lsDel(INV_KEY); setView('login', { email: ctx.email }); }

  /* ---------- interface ---------- */
  var CSS = '#exbGate{position:fixed;inset:0;z-index:99990;overflow:auto;display:flex;align-items:flex-start;justify-content:center;padding:18px 14px;box-sizing:border-box;font:16px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#172033;background:linear-gradient(160deg,var(--g1,#173565),var(--g2,#0f4aa8))}' +
    '#exbGate *{box-sizing:border-box}#exbGate .gb{width:100%;max-width:440px;margin:auto;background:#fff;border-radius:18px;padding:20px 18px 16px;box-shadow:0 18px 50px rgba(0,0,0,.35)}' +
    '#exbGate .gh{display:flex;align-items:center;gap:12px;margin-bottom:12px}#exbGate .gh img{width:52px;height:52px;object-fit:contain;border-radius:10px;border:1px solid #e2e8f0;background:#fff;padding:2px}' +
    '#exbGate .gh b{display:block;font-size:17px;color:var(--g1,#173565)}#exbGate .gh small{display:block;color:#64748b;font-size:12px}' +
    '#exbGate .gs{display:flex;align-items:center;gap:12px;padding:12px;border-radius:14px;background:#f1f5fb;border-left:4px solid var(--g3,#c49a38);margin-bottom:14px}' +
    '#exbGate .gs .gi{font-size:30px;line-height:1}#exbGate .gs b{display:block;color:var(--g1,#173565);font-size:16px}#exbGate .gs small{display:block;color:#475569;font-size:13px}' +
    '#exbGate .gt{display:flex;gap:6px;background:#eef2f7;border-radius:12px;padding:4px;margin-bottom:12px}' +
    '#exbGate .gt button{flex:1;min-height:42px;border:0;border-radius:9px;background:transparent;font:inherit;font-size:14px;font-weight:700;color:#475569;cursor:pointer;white-space:nowrap}' +
    'html.exb-gate-on .exb-fab{display:none!important}' +
    '#exbGate .gt button.on{background:#fff;color:var(--g1,#173565);box-shadow:0 1px 4px rgba(0,0,0,.15)}' +
    '#exbGate h2{margin:0 0 6px;font-size:18px;color:var(--g1,#173565)}#exbGate p{margin:0 0 10px;color:#475569;font-size:14px}' +
    '#exbGate label{display:block;margin:10px 0 4px;font-weight:700;font-size:13px}' +
    '#exbGate input{width:100%;min-height:46px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:10px;font:inherit;font-size:16px;background:#fff;color:#172033}' +
    '#exbGate input:focus-visible,#exbGate button:focus-visible,#exbGate a:focus-visible,#exbGate summary:focus-visible{outline:3px solid #f5c542;outline-offset:2px}' +
    '#exbGate .gw{position:relative}#exbGate .gw input{padding-right:48px}#exbGate .gw button{position:absolute;right:2px;top:2px;bottom:2px;width:44px;border:0;background:transparent;font-size:18px;cursor:pointer}' +
    '#exbGate .gg{width:100%;min-height:48px;margin-top:14px;border:0;border-radius:12px;background:var(--g2,#0f4aa8);color:#fff;font:inherit;font-weight:800;cursor:pointer}#exbGate .gg:disabled{opacity:.6;cursor:wait}' +
    '#exbGate .g2{width:100%;min-height:46px;margin-top:10px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;color:var(--g1,#173565);font:inherit;font-weight:700;cursor:pointer}' +
    '#exbGate .gx{min-height:20px;margin-top:8px;color:#b91c1c;font-size:14px}#exbGate .gx.ok{color:#15803d}' +
    '#exbGate .gl{display:inline-block;margin-top:10px;color:var(--g2,#0f4aa8);font-size:14px;font-weight:600;text-decoration:underline;cursor:pointer;background:none;border:0;padding:6px 0;font-family:inherit}' +
    '#exbGate .gf{margin-top:14px;padding-top:10px;border-top:1px solid #e2e8f0;font-size:12px;color:#64748b;text-align:center}' +
    '#exbGate .gf a,#exbGate .gf button{color:#64748b;background:none;border:0;font:inherit;text-decoration:underline;cursor:pointer;padding:4px}' +
    '#exbGate details{margin-top:10px}#exbGate summary{cursor:pointer;font-weight:700;font-size:13px;color:var(--g2,#0f4aa8);padding:6px 0}' +
    '#exbGate .gq{padding:12px;border-radius:12px;background:#fff7e6;border:1px solid #f5d28a;font-size:14px;color:#6b4a00;margin:8px 0}' +
    '#exbGate .gsp{width:34px;height:34px;margin:14px auto;border:4px solid #dbe4f3;border-top-color:var(--g2,#0f4aa8);border-radius:50%;animation:exbGateSp 1s linear infinite}' +
    '@keyframes exbGateSp{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){#exbGate .gsp{animation:none}}';
  function css() { if ($('exbGateCss')) return; var s = d.createElement('style'); s.id = 'exbGateCss'; s.textContent = CSS; (d.head || d.documentElement).appendChild(s); }
  function brand() {
    var B = {}; try { B = (w.EXBEntreprise && w.EXBEntreprise.get()) || {}; } catch (e) {}
    var logo = B.logo || ''; if (!logo) { var l = $('loginLogo'); logo = (l && l.getAttribute('src')) || ''; }
    return { name: B.name || 'Excellencia Building', tagline: B.tagline || '', logo: logo, p: B.primary || '#173565', s: B.secondary || '#0f4aa8', a: B.accent || '#c49a38', phone: B.phone || '', email: B.email || '' };
  }
  function pwField(id, lab, auto) {
    return '<label for="' + id + '">' + lab + '</label><div class="gw"><input id="' + id + '" type="password" autocomplete="' + auto + '" autocapitalize="none" spellcheck="false"><button type="button" data-eye="' + id + '" aria-label="Afficher ou masquer le mot de passe">👁</button></div>';
  }
  function emailField(v) {
    return '<label for="gm">Adresse e-mail</label><input id="gm" type="email" inputmode="email" autocomplete="username" autocapitalize="none" spellcheck="false" value="' + esc(v || '') + '">';
  }
  function tabs(on) {
    return '<div class="gt" role="tablist"><button type="button" role="tab" aria-selected="' + (on === 'login') + '" class="' + (on === 'login' ? 'on' : '') + '" data-v="login">Se connecter</button>' +
      '<button type="button" role="tab" aria-selected="' + (on === 'first') + '" class="' + (on === 'first' ? 'on' : '') + '" data-v="first">Première connexion</button></div>';
  }
  function body() {
    var e = cur(), em = ctx.email || lsGet(EMAIL_KEY) || '';
    switch (view) {
      case 'wait': return '<div class="gsp" role="status" aria-label="Chargement"></div><p style="text-align:center">Vérification de votre compte…</p>';
      case 'login': return tabs('login') + '<form id="gform" novalidate>' + (ctx.reprise ? '<p>' + esc(ctx.reprise) + '</p>' : '<p>Connectez-vous avec le compte rattaché à votre entreprise.</p>') +
        emailField(em) + pwField('gp', 'Mot de passe', 'current-password') + '<div class="gx" id="gx" role="alert" aria-live="polite">' + esc(ctx.err || '') + '</div>' +
        '<button class="gg" id="gok" type="submit">Se connecter</button></form><button type="button" class="gl" data-v="forgot">Mot de passe oublié ?</button>';
      case 'first': return tabs('first') + '<form id="gform" novalidate><p>Première fois ? Créez votre compte avec <b>l’adresse e-mail indiquée dans votre invitation</b> et choisissez votre propre mot de passe (vous n’en avez pas encore) : vous rejoindrez l’entreprise automatiquement.</p>' +
        '<label for="gn">Nom complet</label><input id="gn" type="text" autocomplete="name" value="' + esc(ctx.nom || '') + '">' + emailField(em) +
        pwField('gp', 'Choisissez un mot de passe <span style="font-weight:400;color:#64748b">(8 caractères minimum)</span>', 'new-password') + pwField('gc', 'Confirmez le mot de passe', 'new-password') +
        '<details' + (lsGet(INV_KEY) ? ' open' : '') + '><summary>J’ai un code d’invitation</summary><label for="gi">Code d’invitation <span style="font-weight:400;color:#64748b">(si votre administrateur vous l’a donné)</span></label><input id="gi" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" value="' + esc(lsGet(INV_KEY) || '') + '"></details>' +
        '<div class="gx" id="gx" role="alert" aria-live="polite">' + esc(ctx.err || '') + '</div><button class="gg" id="gok" type="submit">Créer mon compte</button></form>';
      case 'forgot': return '<form id="gform" novalidate><h2>Mot de passe oublié</h2><p>Saisissez votre adresse e-mail : nous vous envoyons un <b>code à 6 chiffres</b> pour choisir un nouveau mot de passe.</p>' + emailField(em) +
        '<div class="gx" id="gx" role="alert" aria-live="polite"></div><button class="gg" id="gok" type="submit">Envoyer le code</button></form><button type="button" class="gl" data-v="login">← Retour à la connexion</button>';
      case 'code': return '<form id="gform" novalidate><h2>' + (ctx.token ? 'Nouveau mot de passe' : 'Saisissez le code reçu') + '</h2>' +
        (ctx.info ? '<div class="gq">' + esc(ctx.info) + '</div>' : '') + (ctx.token ? '<p>Code validé. Choisissez maintenant votre nouveau mot de passe.</p>'
          : '<p>Si un compte existe pour <b>' + esc(ctx.email) + '</b>, un code à 6 chiffres vient d’être envoyé par e-mail. Recopiez-le ici, puis choisissez votre nouveau mot de passe — <b>aucun lien à ouvrir</b>.</p>' +
            '<label for="gk">Code reçu par e-mail</label><input id="gk" type="text" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" maxlength="12" autocapitalize="none" spellcheck="false" style="letter-spacing:.35em;font-size:22px;text-align:center;font-weight:700">') +
        pwField('gp', 'Nouveau mot de passe <span style="font-weight:400;color:#64748b">(8 caractères minimum)</span>', 'new-password') + pwField('gc', 'Confirmez le mot de passe', 'new-password') +
        '<div class="gx" id="gx" role="alert" aria-live="polite"></div><button class="gg" id="gok" type="submit">Valider et continuer</button></form>' +
        (ctx.token ? '' : '<button type="button" class="gl" data-act="resend">Rien reçu ? Renvoyer le code</button><br><small style="color:#64748b">Regardez aussi dans les courriers indésirables.</small><br>') +
        '<button type="button" class="gl" data-v="login">← Retour à la connexion</button>';
      case 'confirm': return '<h2>Confirmez votre adresse e-mail</h2><p>Un message de confirmation a été envoyé à <b>' + esc(ctx.email) + '</b>. Ouvrez-le et touchez le lien : vous serez connecté(e) automatiquement à ' + esc(e.t) + '.</p><p>Rien reçu ? Regardez dans les courriers indésirables. Une fois l’adresse confirmée, vous pouvez aussi vous connecter ici avec votre mot de passe.</p><button type="button" class="g2" data-v="login">J’ai confirmé : me connecter</button><button type="button" class="g2" data-act="autocode">Je n’ai pas de lien : recevoir un code par e-mail</button>';
      case 'newpass': return '<form id="gform" novalidate><h2>Nouveau mot de passe</h2><p>Choisissez votre nouveau mot de passe (8 caractères minimum).</p>' + pwField('gp', 'Nouveau mot de passe', 'new-password') + pwField('gc', 'Confirmez le mot de passe', 'new-password') +
        '<div class="gx" id="gx" role="alert" aria-live="polite"></div><button class="gg" id="gok" type="submit">Enregistrer et continuer</button></form>';
      case 'noorg': return '<h2>Compte non rattaché</h2><div class="gq">Votre compte <b>' + esc(ctx.email) + '</b> n’est rattaché à aucune entreprise. Vérifiez que vous utilisez <b>exactement l’adresse e-mail de votre invitation</b>, ou saisissez le code d’invitation reçu.' + (ctx.msg ? '<br><i>' + esc(ctx.msg) + '</i>' : '') + '</div>' +
        '<form id="gform" novalidate><label for="gi">Code d’invitation</label><input id="gi" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" value="' + esc(lsGet(INV_KEY) || '') + '"><div class="gx" id="gx" role="alert" aria-live="polite"></div>' +
        '<button class="gg" id="gok" type="submit">Réessayer</button></form><button type="button" class="g2" data-act="out">Se déconnecter / changer de compte</button>';
      case 'refus': {
        var f = ctx.org && ctx.org.fonction || 'polyvalent', lien = LIEN[f] || '';
        return '<h2>Accès refusé à cet espace</h2><div class="gq">Votre compte <b>' + esc(ctx.email) + '</b> a la fonction <b>' + esc(fonc(f)) + '</b>. ' + esc(e.t) + ' est réservé à : <b>' + esc(names(e.fonctions)) + '</b> et à l’administrateur.</div>' +
          /* V205v : la fonction n'est pas choisie par la personne ni par l'espace où elle crée son compte : elle vient de l'invitation (ou « Polyvalent » par défaut sans invitation). */
          '<p>Cette fonction n’est <b>pas choisie par l’espace</b> où vous avez créé votre compte : elle vient de l’invitation de l’administrateur (ou « Polyvalent » par défaut si vous êtes entré avec le code de l’entreprise sans invitation à votre adresse). ' +
          'Demandez-lui de la corriger dans <b>Équipe › Fonction</b>, puis touchez « J’ai été corrigé(e) : réessayer ».</p>' +
          /* V227e : diagnostic — dit clairement POURQUOI l'invitation n'a pas été appliquée (à photographier et envoyer à l'administrateur) */
          (f === 'polyvalent' ? '<div class="gq" style="font-size:13px"><b>Diagnostic :</b> ' + (ctx.recl ? 'le serveur n’a pas pu appliquer l’invitation à cette adresse (' + esc(ctx.recl) + ').' : ctx.via === 'code' ? 'votre compte est entré avec un <b>code</b>, sans invitation reconnue à l’adresse <b>' + esc(ctx.email) + '</b>. Vérifiez que l’administrateur a invité exactement cette adresse.' : 'aucune invitation en attente n’a été trouvée pour <b>' + esc(ctx.email) + '</b>.') +
            '<br><small>Relevé serveur : mon_organisation → fonction « ' + esc(ctx.brut || '') + ' » ; table des membres → « ' + esc(ctx.direct || '—') + ' ». Si le serveur répond « (absente) », exécutez migration-v227g-mon-organisation-fonction.sql dans Supabase.</small></div>' : '') +
          '<button type="button" class="gg" data-act="retry">J’ai été corrigé(e) : réessayer</button>' +
          boutonsEspaces(f, lien) +
          '<button type="button" class="g2" data-act="out">Se déconnecter / changer de compte</button>';
      }
    }
    return '';
  }
  function render() {
    css();
    var g = $(GID), b = brand(), e = cur();
    if (!g) { g = d.createElement('div'); g.id = GID; g.setAttribute('role', 'dialog'); g.setAttribute('aria-modal', 'true'); g.setAttribute('aria-label', 'Connexion — ' + e.t); (d.body || d.documentElement).appendChild(g); }
    g.style.setProperty('--g1', b.p); g.style.setProperty('--g2', b.s); g.style.setProperty('--g3', b.a);
    var contact = b.phone || b.email ? 'Besoin d’aide ? ' + esc(b.phone || b.email) : 'Besoin d’aide ? Contactez votre administrateur.';
    g.innerHTML = '<div class="gb"><div class="gh">' + (b.logo ? '<img src="' + esc(b.logo) + '" alt="">' : '') + '<div><b>' + esc(b.name) + '</b>' + (b.tagline ? '<small>' + esc(b.tagline) + '</small>' : '') + '</div></div>' +
      '<div class="gs"><span class="gi" aria-hidden="true">' + esc(e.ic || '🔐') + '</span><div><b>' + esc(e.t) + '</b><small>' + esc(e.sub || '') + '</small></div></div>' +
      body() + '<div class="gf">' + contact + '<br><button type="button" data-act="local">Accès administrateur de cet appareil</button></div></div>';
    bind(g);
    try { d.documentElement.style.overflow = 'hidden'; d.documentElement.classList.add('exb-gate-on'); ['app', 'loginScreen'].forEach(function (i) { var x = $(i); if (x && x.setAttribute) x.setAttribute('inert', ''); }); } catch (x) {}
    var f = $('gm') && !$('gm').value ? $('gm') : ($('gk') || $('gp') || $('gi') || $('gm') || g.querySelector('button.gg'));
    try { if (f && view !== 'wait') f.focus(); } catch (x) {}
  }
  function bind(g) {
    var f = $('gform');
    if (f) f.addEventListener('submit', view === 'login' ? doLogin : view === 'first' ? doFirst : view === 'forgot' ? doForgot : view === 'code' ? doCode : view === 'newpass' ? doNewPass : doRetry);
    [].forEach.call(g.querySelectorAll('[data-v]'), function (b) { b.addEventListener('click', function () { keepEmail(); setView(b.getAttribute('data-v'), { email: ctx.email, nom: ctx.nom }); }); });
    [].forEach.call(g.querySelectorAll('[data-eye]'), function (b) { b.addEventListener('click', function () { var i = $(b.getAttribute('data-eye')); if (i) i.type = i.type === 'password' ? 'text' : 'password'; }); });
    [].forEach.call(g.querySelectorAll('[data-act="out"]'), function (b) { b.addEventListener('click', signOut); });
    [].forEach.call(g.querySelectorAll('[data-act="resend"]'), function (b) { b.addEventListener('click', resend); });
    [].forEach.call(g.querySelectorAll('[data-act="autocode"]'), function (b) { b.addEventListener('click', function () { autoCode(ctx.email, ctx.nom); }); });
    [].forEach.call(g.querySelectorAll('[data-go]'), function (b) { b.addEventListener('click', function () { w.location.href = b.getAttribute('data-go'); }); });
    [].forEach.call(g.querySelectorAll('[data-act="retry"]'), function (b) { b.addEventListener('click', function () { proceed(ctx.email, ''); }); });   /* V205v : l'administrateur a corrigé la fonction → on relit le rattachement */
    [].forEach.call(g.querySelectorAll('[data-act="local"]'), function (b) { b.addEventListener('click', function () { ssSet(BYPASS, '1'); close(); }); });
  }
  function keepEmail() { var m = $('gm'), n = $('gn'); if (m) ctx.email = m.value.trim(); if (n) ctx.nom = n.value.trim(); }
  function setView(v, c) { view = v; ctx = Object.assign({ token: ctx.token, refresh: ctx.refresh, exp: ctx.exp }, c || {}); render(); }
  function open(v, c) { if (v) { view = v; ctx = c || {}; } render(); }
  function close() {
    var g = $(GID); if (g) g.remove();
    try { d.documentElement.style.overflow = ''; d.documentElement.classList.remove('exb-gate-on'); ['app', 'loginScreen'].forEach(function (i) { var x = $(i); if (x && x.removeAttribute) x.removeAttribute('inert'); }); } catch (x) {}
  }

  /* ---------- lien reçu par e-mail : #access_token=…&type=signup|recovery|magiclink ou #error_description=… ---------- */
  function readHash() {
    var h = String(w.location.hash || '').replace(/^#/, '');
    if (!/(^|&)(access_token|error_description)=/.test(h)) return null;
    var p; try { p = new URLSearchParams(h); } catch (e) { return null; }
    try { w.history.replaceState(null, '', w.location.pathname + w.location.search); } catch (e) {}
    return { at: p.get('access_token'), rt: p.get('refresh_token'), exp: Number(p.get('expires_in')) || 3600, type: p.get('type') || '', err: p.get('error_description') || '' };
  }
  async function fromLink(h) {
    if (h.err && !h.at) return open('login', { err: /expired|invalid/i.test(h.err) ? 'Ce lien a expiré ou a déjà été utilisé. Demandez-en un nouveau avec « Mot de passe oublié ».' : h.err.replace(/\+/g, ' ') });
    if (h.type === 'recovery') { ctx = { token: h.at, refresh: h.rt, exp: h.exp }; return setView('newpass'); }
    setSession({ access_token: h.at, refresh_token: h.rt, expires_in: h.exp });
    var em = ''; try { var u = await w.exbSb.api('/auth/v1/user'); em = (u && u.email) || ''; } catch (e) {}
    open('wait', { email: em }); proceed(em);
  }

  /* ---------- déconnexion : l'espace ne doit pas se rouvrir tout seul avec l'ancien compte ---------- */
  function hookLogout() {
    var o = w.logout; if (typeof o !== 'function' || o.__gate) return;
    var n = function () { try { if (key() && w.exbSb) w.exbSb.set(null); } catch (e) {} try { w.sessionStorage.removeItem(BYPASS); } catch (e) {} return o.apply(this, arguments); };
    n.__gate = true; w.logout = n;
  }

  /* V205y — lien d'accès personnel : ?inv=CODE → code mémorisé ; l'écran s'ouvre sur « Première connexion » (la personne n'a pas encore de mot de passe). */
  function invFromUrl() { try { var m = String(w.location.search || '').match(/[?&]inv=([A-Za-z0-9]{4,32})/); return m ? m[1].toLowerCase() : ''; } catch (e) { return ''; } }
  function start() {
    hookLogout();
    var invc = invFromUrl(); if (invc) { lsSet(INV_KEY, invc); try { w.history.replaceState(null, '', w.location.pathname + w.location.search.replace(/([?&])inv=[A-Za-z0-9]+&?/, '$1').replace(/[?&]$/, '') + w.location.hash); } catch (e) {} }
    var h = configured() ? readHash() : null;   /* V205z : lien reçu accepté même si l'espace n'est pas connu (autre navigateur) : avant, le jeton était jeté et l'écran bleu « licence » revenait */
    if (h) { fromLink(h); return; }
    if (needGate()) {
      var re = onlineIn() ? 'Pour votre sécurité, saisissez de nouveau votre mot de passe.' : (localOpen() ? 'Votre session en ligne a expiré : reconnectez-vous pour continuer.' : '');
      open(invc ? 'first' : 'login', { reprise: invc ? '' : re, email: lsGet(EMAIL_KEY) || '' });
    }
  }
  /* session en ligne perdue pendant le travail (jeton refusé) : la porte se referme sur l'appli */
  setInterval(function () { try { hookLogout(); if (!$(GID) && !busy && needGate() && localOpen()) open('login', { reprise: 'Votre session en ligne a expiré : reconnectez-vous pour continuer.', email: lsGet(EMAIL_KEY) || '' }); } catch (e) {} }, 20000);

  /* V210e — application ouverte directement (Android, ordinateur) : il n'y a pas d'espace demandé, donc pas de porte ; l'écran local ne proposait que le « code de restauration » de l'administrateur.
     On ajoute ici deux accès à la porte en ligne : « code reçu par e-mail » (mot de passe oublié) et « première connexion » (invitation). */
  function loginLinks() {
    /* V221b : l'écran administrateur n'affiche PLUS « Première connexion » ni « recevoir un code par e-mail » : ces accès sont réservés aux portails des membres invités (comptable, ingénieur…). Reste seulement « Mot de passe oublié / code de restauration ». */
    var old = $('exbGateLinks'); if (old && old.parentNode) old.parentNode.removeChild(old);
    return;
    var lm = $('li_msg'); if (!lm || $('exbGateLinks') || !configured()) return;
    var x = d.createElement('div'); x.id = 'exbGateLinks'; x.style.cssText = 'text-align:center;margin-top:10px;font-size:13px;line-height:2';
    x.innerHTML = '<a href="#" data-g="first">🆕 Première connexion (invitation reçue)</a><br><a href="#" data-g="forgot">📧 Mot de passe oublié : recevoir un code par e-mail</a>';
    var anchor = $('exbForgot') ? $('exbForgot').parentNode : lm; anchor.parentNode.insertBefore(x, anchor.nextSibling);
    [].forEach.call(x.querySelectorAll('a'), function (a) { a.addEventListener('click', function (e) { e.preventDefault(); open(a.getAttribute('data-g'), { email: lsGet(EMAIL_KEY) || '' }); }); });
  }
  setInterval(function () { try { loginLinks(); } catch (e) {} }, 1500);
  w.EXBGATE = { open: open, close: close, needGate: needGate, espace: key, view: function () { return view; }, _t: { remember: rememberOffline, offline: offlineLogin, frErr: frErr, validEmail: validEmail, readHash: readHash, attach: attach } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
