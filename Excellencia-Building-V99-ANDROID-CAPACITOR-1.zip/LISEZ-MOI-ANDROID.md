# Excellencia Building — application Android (Capacitor)

Ce projet enveloppe le logiciel V99 (dossier `site/`) dans une vraie application Android.
Ce qui change par rapport au navigateur :

- plus de limite du navigateur : les données de travail restent dans l'espace privé de l'application ;
- **vrais fichiers** dans `Documents/ExcellenciaBuilding/` du téléphone, visibles dans le gestionnaire de fichiers :
  - `Plans/` : chaque plan (PDF, DWG, DXF, IFC, images) y est copié automatiquement à son enregistrement ;
  - `Sauvegardes/` : bouton « 📲 Enregistrer sur le téléphone » (sauvegarde complète) + une sauvegarde automatique par jour (les 7 dernières sont gardées) ;
- ce dossier survit à la désinstallation ; pour une carte SD ou une clé USB, copiez-le avec le gestionnaire de fichiers.
- Dans le menu « 💾 Données sur mon PC » → carte « 📱 Stockage de l'appareil », les boutons 📲 et 📐 écrivent maintenant dans ce dossier, et « 🔄 Tout recopier maintenant » a été ajouté.

Le logiciel du dossier `site/` n'est pas modifié (seul `index.html` reçoit une ligne `<script src="exb-native.js">` dans `www/`).
Dans un navigateur normal, `exb-native.js` ne fait rien.

## Fabriquer l'APK

### Option A — sans PC, avec GitHub (le plus simple depuis un téléphone)
1. Créez un dépôt GitHub privé et envoyez-y tout le contenu de ce dossier.
2. Onglet **Actions** → « Construire l'application Android » → **Run workflow**.
3. À la fin (≈ 6 min), téléchargez l'artefact `excellencia-building-debug-apk`, décompressez, installez `app-debug.apk` (autoriser les sources inconnues).

### Option B — sur PC (Node 20 + Android Studio)
```
npm install
npm run android:add      # une seule fois : crée le dossier android/
npm run android:sync     # à refaire à chaque mise à jour du dossier site/
npm run android:open     # ouvre Android Studio → Run
```

## Publication sur le Play Store
- Il faut un **fichier AAB signé** (`npm run android:release`, puis signature avec votre clé de téléversement — à conserver précieusement), un compte développeur Google Play et une politique de confidentialité.
- Identifiant de l'application : `com.excellencia.building` (modifiable dans `capacitor.config.json` **avant** `android:add` ; il ne peut plus changer une fois publié).
- Icône et écran de démarrage : générez-les avec `@capacitor/assets` à partir de `site/icon-512.png`.

## Mettre à jour le logiciel
Remplacez le contenu de `site/` par la nouvelle version, puis refaites l'option A (push) ou `npm run android:sync`. Augmentez `versionCode` dans `android/app/build.gradle` pour chaque publication Play Store.

## Limites à connaître
- Je n'ai pas pu compiler l'APK ni le tester sur un téléphone ici (pas d'accès réseau ni de SDK Android) : faites un premier essai sur un appareil et dites-moi ce qui se passe. Le point à vérifier en priorité : l'écriture dans `Documents/` selon la version d'Android (autorisation demandée au premier enregistrement).
- Le choix libre d'un dossier sur carte SD / clé USB (système SAF d'Android) n'est pas inclus : il demande un plugin dédié à tester sur appareil. En attendant, copiez le dossier avec le gestionnaire de fichiers.
- Les fichiers de plans restent aussi dans l'espace de l'application (copie de travail) : le dossier Documents double l'occupation.
- La synchronisation, les licences et Supabase fonctionnent comme dans le navigateur (HTTPS requis).

## Correctif « l'application se fige »
La sauvegarde automatique quotidienne assemblait tout le logiciel (images comprises) en un seul bloc de ~40 Mo puis l'envoyait d'un coup à Android, 12 s après l'ouverture. Elle est maintenant écrite en flux (une clé à la fois, morceaux de 1 Mo), lancée 90 s après l'ouverture au calme, une seule fois par jour (le jour est noté avant la tentative).
