/* Excellencia Building — stockage natif Android (Capacitor)
 * Actif UNIQUEMENT dans l'application Android installée ; dans un navigateur ce fichier ne fait rien.
 * Rôle : enregistrer les PDF/Excel générés (Fichiers/) et écrire de vrais fichiers dans le dossier Documents/ExcellenciaBuilding du téléphone
 *   - Plans/        : chaque fichier de plan (PDF, DWG, DXF, IFC, images) est copié automatiquement à son enregistrement
 *   - Sauvegardes/  : sauvegarde complète du logiciel (JSON) à la demande + une sauvegarde automatique par jour (7 gardées)
 * Les données de travail restent dans IndexedDB (comme avant) ; le dossier Documents est une copie visible
 * dans le gestionnaire de fichiers, qui survit à la désinstallation de l'application. */
(function (w) {
  'use strict';
  var C = w.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var FS = (C.Plugins && C.Plugins.Filesystem) || (C.registerPlugin && C.registerPlugin('Filesystem'));
  if (!FS) return;
  var ROOT = 'ExcellenciaBuilding', DIR = 'DOCUMENTS', CHUNK = 3 * 1024 * 1024, busy = false, queue = [], permOk = null;

  function safe(n) { return String(n || 'fichier').replace(/[\\\/:*?"<>|]+/g, '-').replace(/\s+/g, ' ').trim().slice(0, 120) || 'fichier'; }
  function isoDay() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function mb(n) { return (n / 1048576).toFixed(n < 10485760 ? 1 : 0).replace('.', ',') + ' Mo'; }
  function toast(t, k) { try { w.notify && w.notify(t, k || 'ok', 5000); } catch (e) {} }

  function permission() {
    if (permOk !== null) return Promise.resolve(permOk);
    return FS.checkPermissions().then(function (r) {
      if (r && r.publicStorage === 'granted') return r;
      return FS.requestPermissions();
    }).then(function (r) { permOk = !!(r && r.publicStorage === 'granted'); return permOk; }, function () { permOk = true; return true; });
  }
  function mkdir(p) { return FS.mkdir({ path: p, directory: DIR, recursive: true }).catch(function () {}); }
  function exists(p) { return FS.stat({ path: p, directory: DIR }).then(function (s) { return s; }, function () { return null; }); }

  function b64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(blob);
    });
  }
  /* écriture par morceaux : un gros plan de plusieurs centaines de Mo ne passe jamais entièrement en mémoire */
  function writeBlob(path, blob) {
    var off = 0;
    function next() {
      if (off >= blob.size && off > 0) return Promise.resolve();
      return b64(blob.slice(off, off + CHUNK)).then(function (d) {
        var first = off === 0; off += CHUNK;
        return (first ? FS.writeFile({ path: path, directory: DIR, data: d, recursive: true }) : FS.appendFile({ path: path, directory: DIR, data: d })).then(next);
      });
    }
    if (blob.size === 0) return FS.writeFile({ path: path, directory: DIR, data: '', recursive: true });
    return next();
  }
  function writeText(path, text) { return FS.writeFile({ path: path, directory: DIR, data: text, encoding: 'utf8', recursive: true }); }

  function S() { try { return typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) { return null; } }
  function planList() { try { return JSON.parse((S() && S().getItem('exb_plan_files')) || '[]') || []; } catch (e) { return []; } }
  function nameOf(m) { return safe((m.ref ? m.ref + ' ind' + (m.ver || '') + ' — ' : '') + (m.name || m.id)); }
  function idbGet(id) {
    return new Promise(function (res) {
      var r = indexedDB.open('exb81', 1);
      r.onupgradeneeded = function () { try { r.result.createObjectStore('blobs'); } catch (e) {} };
      r.onerror = function () { res(null); };
      r.onsuccess = function () {
        var d = r.result;
        if (!d.objectStoreNames.contains('blobs')) return res(null);
        var q = d.transaction('blobs').objectStore('blobs').get(id);
        q.onsuccess = function () { res(q.result || null); };
        q.onerror = function () { res(null); };
      };
    });
  }

  /* copie d'un plan dans Documents/ExcellenciaBuilding/Plans (ignoré s'il y est déjà avec la même taille) */
  function mirrorOne(m) {
    var path = ROOT + '/Plans/' + nameOf(m);
    return idbGet(m.id).then(function (b) {
      if (!b) return 'absent';
      return exists(path).then(function (s) {
        if (s && Number(s.size) === b.size) return 'deja';
        return writeBlob(path, b).then(function () { return 'ecrit'; });
      });
    });
  }
  function mirrorAll(verbose) {
    if (busy) return Promise.resolve({ ok: false, msg: 'Copie déjà en cours…' });
    busy = true;
    return permission().then(function (ok) {
      if (!ok) { busy = false; return { ok: false, msg: 'Autorisation de stockage refusée : activez-la dans les réglages Android de l’application.' }; }
      return mkdir(ROOT + '/Plans').then(function () {
        var L = planList(), n = 0, skip = 0, errs = 0, i = 0;
        if (!L.length) { busy = false; return { ok: false, msg: 'Aucun fichier de plan sur cet appareil.' }; }
        function step() {
          if (i >= L.length) { busy = false; return { ok: errs === 0, msg: n + ' plan(s) copié(s), ' + skip + ' déjà présent(s)' + (errs ? ', ' + errs + ' en erreur' : '') + ' — dossier Documents/' + ROOT + '/Plans.' }; }
          var m = L[i++];
          return mirrorOne(m).then(function (r) { if (r === 'ecrit') n++; else skip++; }, function () { errs++; }).then(step);
        }
        return step();
      });
    }).catch(function (e) { busy = false; return { ok: false, msg: 'Écriture impossible : ' + (e && e.message || e) }; });
  }

  /* sauvegarde complète : même contenu que le bouton « Sauvegarde complète » */
  function backupObject() {
    var s = S(), K = []; if (!s) return null;
    try { K = typeof EXB_ENTERPRISE_KEYS !== 'undefined' ? EXB_ENTERPRISE_KEYS.slice() : []; } catch (e) {}
    if (K.indexOf('exb_approvals') < 0) K.push('exb_approvals');
    if (K.indexOf('exb_plan_files') < 0) K.push('exb_plan_files');
    var data = {}; K.forEach(function (k) { var v = s.getItem(k); if (v === null) return; try { data[k] = JSON.parse(v); } catch (e) { data[k] = v; } });
    return { version: 6, app: 'Excellencia Building', exported_at: new Date().toISOString(), data: data };
  }
  function saveBackup(auto) {
    var o = backupObject(); if (!o) return Promise.resolve({ ok: false, msg: 'Stockage introuvable.' });
    var name = auto ? 'auto-' + isoDay() + '.json' : 'sauvegarde-complete-' + isoDay() + '.json';
    var path = ROOT + '/Sauvegardes/' + name, txt = JSON.stringify(o);
    return permission().then(function (ok) {
      if (!ok) return { ok: false, msg: 'Autorisation de stockage refusée.' };
      return mkdir(ROOT + '/Sauvegardes').then(function () { return writeText(path, txt); }).then(function () {
        return auto ? prune().then(function () { return { ok: true, msg: 'ok' }; }) : { ok: true, msg: 'Sauvegarde écrite (' + mb(txt.length) + ') : Documents/' + path };
      });
    }).catch(function (e) { return { ok: false, msg: 'Écriture impossible : ' + (e && e.message || e) }; });
  }
  function prune() {
    return FS.readdir({ path: ROOT + '/Sauvegardes', directory: DIR }).then(function (r) {
      var f = (r.files || []).map(function (x) { return x.name || x; }).filter(function (n) { return /^auto-\d{4}-\d{2}-\d{2}\.json$/.test(n); }).sort();
      return Promise.all(f.slice(0, Math.max(0, f.length - 7)).map(function (n) { return FS.deleteFile({ path: ROOT + '/Sauvegardes/' + n, directory: DIR }).catch(function () {}); }));
    }).catch(function () {});
  }

  /* les boutons existants du grand stockage écrivent désormais dans le vrai dossier */
  function hook() {
    var B = w.EXBBIG; if (!B) return false;
    B.savePlansToPhone = function () { return mirrorAll(true); };
    B.saveToPhone = function () { return saveBackup(false); };
    B.native = { mirrorAll: mirrorAll, saveBackup: saveBackup, root: 'Documents/' + ROOT };
    return true;
  }
  if (!hook()) { var t = setInterval(function () { if (hook()) clearInterval(t); }, 200); setTimeout(function () { clearInterval(t); }, 15000); }

  /* nouveau plan enregistré (IndexedDB « exb81 ») : copie automatique vers le dossier du téléphone */
  try {
    var put = IDBObjectStore.prototype.put;
    IDBObjectStore.prototype.put = function (value, key) {
      var r = put.apply(this, arguments);
      try {
        if (this.name === 'blobs' && this.transaction.db.name === 'exb81') {
          this.transaction.addEventListener('complete', function () { setTimeout(function () { mirrorAll(false).then(function (x) { if (x && x.ok && /[1-9]\d* plan\(s\) copié/.test(x.msg)) toast('📐 Plan copié dans Documents/' + ROOT + '/Plans', 'ok'); }); }, 1500); });
        }
      } catch (e) {}
      return r;
    };
  } catch (e) {}

  /* carte « Stockage de l'appareil » : informations du dossier réel */
  function decorate() {
    var el = document.getElementById('exb_big_card'); if (!el || el.getAttribute('data-n')) return;
    if (!el.getAttribute('data-r')) return;
    el.setAttribute('data-n', '1');
    var p = document.createElement('div'); p.className = 'msg'; p.id = 'exb_native_info';
    p.textContent = '📂 Application installée : vos plans et sauvegardes sont écrits dans le dossier « Documents/' + ROOT + ' » du téléphone (visible dans le gestionnaire de fichiers, copiable vers une carte SD ou une clé USB).';
    el.appendChild(p);
    var a = el.querySelector('.actions'); if (a) { var b = document.createElement('button'); b.className = 'muted'; b.textContent = '🔄 Tout recopier maintenant'; b.onclick = function () { var m = document.getElementById('exb_big_msg'); if (m) m.textContent = 'Copie en cours…'; mirrorAll(true).then(function (r) { if (m) m.textContent = (r.ok ? '✓ ' : '') + r.msg; }); }; a.appendChild(b); }
  }
  try { var mo = new MutationObserver(decorate); document.addEventListener('DOMContentLoaded', function () { decorate(); mo.observe(document.body, { childList: true, subtree: true }); }); } catch (e) {}


  /* ---- Téléchargements (PDF, Excel, images, ZIP…) ----
   * Le WebView Android ignore les liens « download » (blob:/data:) : rien ne se passait quand on générait un PDF.
   * On intercepte ces téléchargements, on écrit le fichier dans Documents/ExcellenciaBuilding/Fichiers
   * (repli : dossier de l'application) puis on ouvre le menu Partager d'Android (ouvrir, WhatsApp, Drive…). */
  var SH = null; try { SH = (C.Plugins && C.Plugins.Share) || (C.registerPlugin && C.registerPlugin('Share')); } catch (e) {}
  var DLDIR = ROOT + '/Fichiers';
  function mkIn(dir, p) { return FS.mkdir({ path: p, directory: dir, recursive: true }).catch(function () {}); }
  function statIn(dir, p) { return FS.stat({ path: p, directory: dir }).then(function (r) { return r; }, function () { return null; }); }
  function writeIn(dir, path, blob) {
    var off = 0;
    function next() {
      if (off >= blob.size && off > 0) return Promise.resolve();
      return b64(blob.slice(off, off + CHUNK)).then(function (d) {
        var first = off === 0; off += CHUNK;
        return (first ? FS.writeFile({ path: path, directory: dir, data: d, recursive: true }) : FS.appendFile({ path: path, directory: dir, data: d })).then(next);
      });
    }
    if (blob.size === 0) return FS.writeFile({ path: path, directory: dir, data: '', recursive: true });
    return next();
  }
  function extFor(t) {
    t = String(t || '').toLowerCase();
    return t.indexOf('pdf') >= 0 ? '.pdf' : t.indexOf('json') >= 0 ? '.json' : t.indexOf('csv') >= 0 ? '.csv' : t.indexOf('html') >= 0 ? '.html' :
      t.indexOf('zip') >= 0 ? '.zip' : t.indexOf('png') >= 0 ? '.png' : t.indexOf('jpeg') >= 0 ? '.jpg' : t.indexOf('sheet') >= 0 ? '.xlsx' :
      t.indexOf('wordprocessing') >= 0 ? '.docx' : t.indexOf('text') >= 0 ? '.txt' : '';
  }
  function dlName(a, blob) {
    var n = safe(a.getAttribute('download') || 'fichier');
    if (!/\.[A-Za-z0-9]{2,5}$/.test(n)) n += extFor(blob.type);
    return n;
  }
  function freeName(dir, name) {
    var m = name.match(/^(.*?)(\.[A-Za-z0-9]{2,5})?$/), base = m[1], ext = m[2] || '', i = 1;
    function tryName(n) {
      return statIn(dir, DLDIR + '/' + n).then(function (s) { return s ? (i++, tryName(base + ' (' + i + ')' + ext)) : n; });
    }
    return tryName(name);
  }
  function saveInto(dir, blob, name) {
    return mkIn(dir, DLDIR).then(function () { return freeName(dir, name); }).then(function (n) {
      var p = DLDIR + '/' + n;
      return writeIn(dir, p, blob).then(function () { return { dir: dir, path: p, name: n }; });
    });
  }
  function saveDownload(blob, name) {
    return permission().then(function () {
      return saveInto(DIR, blob, name).then(function (r) { r.where = 'Documents/' + r.path; return r; }, function () {
        return saveInto('EXTERNAL', blob, name).then(function (r) { r.where = 'Android/data/com.excellencia.building/files/' + r.path; return r; });
      });
    });
  }
  function shareFile(r) {
    if (!SH || !SH.share) return;
    FS.getUri({ path: r.path, directory: r.dir }).then(function (u) {
      return SH.share({ title: r.name, files: [u.uri], dialogTitle: 'Ouvrir ou envoyer ' + r.name });
    }).catch(function () {});
  }
  function isDl(a) { return !!(a && a.tagName === 'A' && a.hasAttribute && a.hasAttribute('download') && /^(blob:|data:)/i.test(a.href || '')); }
  function handleDl(a) {
    var now = Date.now(); if (a.__exbDl && now - a.__exbDl < 1500) return; a.__exbDl = now;
    var href = a.href;
    toast('⏳ Enregistrement du fichier…', 'ok');
    fetch(href).then(function (r) { return r.blob(); }).then(function (blob) {
      return saveDownload(blob, dlName(a, blob)).then(function (r) {
        toast('📄 ' + r.name + ' enregistré : ' + r.where, 'ok');
        shareFile(r);
      });
    }).catch(function (e) { toast('Enregistrement impossible : ' + (e && e.message || e), 'err'); });
  }
  try {
    var oClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () { if (isDl(this)) { handleDl(this); return; } return oClick.apply(this, arguments); };
    var oDisp = EventTarget.prototype.dispatchEvent;
    HTMLAnchorElement.prototype.dispatchEvent = function (e) {
      if (e && e.type === 'click' && isDl(this)) { handleDl(this); return true; }
      return oDisp.call(this, e);
    };
    document.addEventListener('click', function (e) {
      var a = e.target && e.target.closest && e.target.closest('a[download]');
      if (isDl(a)) { e.preventDefault(); e.stopPropagation(); handleDl(a); }
    }, true);
  } catch (e) {}
  w.EXBNativeDownload = { save: function (blob, name) { return saveDownload(blob, safe(name) + (/\.[A-Za-z0-9]{2,5}$/.test(name) ? '' : extFor(blob.type))); } };

  /* sauvegarde automatique quotidienne + rattrapage des plans déjà présents, quelques secondes après l'ouverture */
  setTimeout(function () {
    var k = 'exb_native_lastauto';
    try { if (w.localStorage.getItem(k) === isoDay()) return mirrorAll(false); } catch (e) {}
    saveBackup(true).then(function (r) { if (r.ok) { try { w.localStorage.setItem(k, isoDay()); } catch (e) {} } return mirrorAll(false); });
  }, 12000);
})(window);
