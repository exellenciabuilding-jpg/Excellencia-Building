/* Vue 3D de l'éditeur de plan — WebGL autonome (aucune bibliothèque externe, fonctionne hors connexion).
 * V4.5 « rendu réaliste » : soleil réglable avec ombres douces, ciel, matériaux procéduraux (enduit, carrelage, parquet,
 *  béton, tuiles, pavés, pelouse), fenêtres et portes détaillées (cadre, vitrage, appui, panneaux, poignée), toit avec débord,
 *  gouttière et faîtière, extérieur (pelouse, allée, clôture, portail, route, arbres).
 * Reçoit une « scène » préparée par l'éditeur : { r3d, levels[], slabs[], roofs[] } (mètres ; plan x,y -> monde X,Z ; hauteur -> Y).
 *  walls : { path:[[x,y]…], len, t, h, ops:[{pos,w,h,sill,kind}] }   rooms : { pts, hue, mat }   furn : { x,y,w,d,h,rot,parts }   elec : { x,y,z,col }
 *  r3d : { h: heure du soleil 6..18, ext: extérieur oui/non, sh: ombres oui/non }
 * V4.6 : capture(W,H) = rendu haute résolution (4K) ; turntable() = vidéo 360° (MediaRecorder).
 * Commandes : 1 doigt / clic gauche = tourner ; 2 doigts / clic droit / Maj = déplacer ; molette / pincement = zoom. */
(function(w){'use strict';
function hex(c){c=String(c||'#999999');if(c[0]==='#')c=c.slice(1);if(c.length===3)c=c[0]+c[0]+c[1]+c[1]+c[2]+c[2];return[parseInt(c.substr(0,2),16)/255,parseInt(c.substr(2,2),16)/255,parseInt(c.substr(4,2),16)/255]}
function hsl(h,s,l){h/=360;var a=s*Math.min(l,1-l);function f(n){var k=(n+h*12)%12;return l-a*Math.max(-1,Math.min(k-3,9-k,1))}return[f(0),f(8),f(4)]}

/* matériau courant : 0 uni · 1 enduit · 2 carrelage · 3 parquet · 4 pelouse · 5 tuiles · 6 verre · 7 béton · 8 bois · 9 pavés · 10 métal · 11 feuillage · 12 bitume */
var MT=0;
/* sélection au toucher : chaque sommet du maillage principal porte l'étiquette de l'objet qui l'a produit */
var TG=[],TGG=[],TAGS=[],TAGCUR=-1,CURM=null,CURG=null;function tag(o){TAGS.push(o);TAGCUR=TAGS.length-1}
function pv(m,x,y,z,nx,ny,nz,c){m.push(x,y,z,nx,ny,nz,c[0],c[1],c[2],MT);if(m===CURM)TG.push(TAGCUR);else if(m===CURG)TGG.push(TAGCUR)}

/* ---- géométrie : boîtes orientées autour de l'axe vertical (phi), 5 faces visibles ---- */
function box(m,cx,cy,cz,sx,sy,sz,phi,col,bot){
 if(!(sx>0&&sy>0&&sz>0))return;
 var c=Math.cos(phi),s=Math.sin(phi),hx=sx/2,hy=sy/2,hz=sz/2;
 function P(lx,ly,lz){return[cx+lx*c+lz*s,cy+ly,cz-lx*s+lz*c]}
 function N(nx,ny,nz){return[nx*c+nz*s,ny,-nx*s+nz*c]}
 var F=[
  [[0,1,0],[[-hx,hy,-hz],[hx,hy,-hz],[hx,hy,hz],[-hx,hy,hz]]],
  [[1,0,0],[[hx,-hy,-hz],[hx,-hy,hz],[hx,hy,hz],[hx,hy,-hz]]],
  [[-1,0,0],[[-hx,-hy,-hz],[-hx,hy,-hz],[-hx,hy,hz],[-hx,-hy,hz]]],
  [[0,0,1],[[-hx,-hy,hz],[-hx,hy,hz],[hx,hy,hz],[hx,-hy,hz]]],
  [[0,0,-1],[[-hx,-hy,-hz],[hx,-hy,-hz],[hx,hy,-hz],[-hx,hy,-hz]]]];
 if(bot)F.push([[0,-1,0],[[-hx,-hy,-hz],[-hx,-hy,hz],[hx,-hy,hz],[hx,-hy,-hz]]]);
 F.forEach(function(f){var n=N(f[0][0],f[0][1],f[0][2]),q=f[1].map(function(v){return P(v[0],v[1],v[2])});
  [0,1,2,0,2,3].forEach(function(i){pv(m,q[i][0],q[i][1],q[i][2],n[0],n[1],n[2],col)})})}
/* boîte à arêtes arrondies : somme de Minkowski (boîte intérieure + sphère de rayon r), maillage réparti pour des reflets lisses */
function rstops(h,r){var b=h-r;if(b<1e-4)return[-h,-.7*h,-.35*h,0,.35*h,.7*h,h];var k=.414*r;return[-h,-(b+k),-b,b,b+k,h]}
function rbox(m,cx,cy,cz,sx,sy,sz,phi,col,r){
 if(!(sx>0&&sy>0&&sz>0))return;var hx=sx/2,hy=sy/2,hz=sz/2;r=Math.min(r==null?.03:r,hx*.98,hy*.98,hz*.98);
 if(r<.004){box(m,cx,cy,cz,sx,sy,sz,phi,col);return}
 var bx=hx-r,by=hy-r,bz=hz-r,SX=rstops(hx,r),SY=rstops(hy,r),SZ=rstops(hz,r),c=Math.cos(phi),s=Math.sin(phi);
 function cl(v,b){return v<-b?-b:v>b?b:v}
 function V(i,j,k){var vx=SX[i],vy=SY[j],vz=SZ[k],qx=cl(vx,bx),qy=cl(vy,by),qz=cl(vz,bz),dx=vx-qx,dy=vy-qy,dz=vz-qz,l=Math.hypot(dx,dy,dz)||1,nx=dx/l,ny=dy/l,nz=dz/l,
  px=qx+nx*r,py=qy+ny*r,pz=qz+nz*r;return[cx+px*c+pz*s,cy+py,cz-px*s+pz*c,nx*c+nz*s,ny,-nx*s+nz*c]}
 function P(v){pv(m,v[0],v[1],v[2],v[3],v[4],v[5],col)}
 var nX=SX.length-1,nY=SY.length-1,nZ=SZ.length-1,i,j,k;
 function Q(a,b,c2,d){P(a);P(b);P(c2);P(a);P(c2);P(d)}
 for(j=0;j<nY;j++)for(k=0;k<nZ;k++){Q(V(0,j,k),V(0,j+1,k),V(0,j+1,k+1),V(0,j,k+1));Q(V(nX,j,k),V(nX,j+1,k),V(nX,j+1,k+1),V(nX,j,k+1))}
 for(i=0;i<nX;i++)for(k=0;k<nZ;k++){Q(V(i,0,k),V(i+1,0,k),V(i+1,0,k+1),V(i,0,k+1));Q(V(i,nY,k),V(i+1,nY,k),V(i+1,nY,k+1),V(i,nY,k+1))}
 for(i=0;i<nX;i++)for(j=0;j<nY;j++){Q(V(i,j,0),V(i+1,j,0),V(i+1,j+1,0),V(i,j+1,0));Q(V(i,j,nZ),V(i+1,j,nZ),V(i+1,j+1,nZ),V(i,j+1,nZ))}}
/* cylindre vertical (ellipse rx × rz), rayon du haut = tp × rayon du bas */
function cyl(m,cx,cy,cz,rx,rz,h,phi,col,tp,seg){
 if(!(rx>0&&rz>0&&h>0))return;seg=seg||12;tp=tp==null?1:tp;var c=Math.cos(phi),s=Math.sin(phi),y0=cy-h/2,y1=cy+h/2,i,sl=(1-tp)*(rx+rz)/2/h;
 function W(px,py,pz){return[cx+px*c+pz*s,py,cz-px*s+pz*c]}
 function Nw(nx,ny,nz){return[nx*c+nz*s,ny,-nx*s+nz*c]}
 for(i=0;i<seg;i++){var a0=2*Math.PI*i/seg,a1=2*Math.PI*(i+1)/seg,c0=Math.cos(a0),s0=Math.sin(a0),c1=Math.cos(a1),s1=Math.sin(a1),
  p00=W(rx*c0,y0,rz*s0),p10=W(rx*c1,y0,rz*s1),p11=W(rx*c1*tp,y1,rz*s1*tp),p01=W(rx*c0*tp,y1,rz*s0*tp),
  n0=Nw(c0/rx,sl,s0/rz),n1=Nw(c1/rx,sl,s1/rz),l0=Math.hypot(n0[0],n0[1],n0[2]),l1=Math.hypot(n1[0],n1[1],n1[2]);
  n0=[n0[0]/l0,n0[1]/l0,n0[2]/l0];n1=[n1[0]/l1,n1[1]/l1,n1[2]/l1];
  function Pq(p,n){pv(m,p[0],p[1],p[2],n[0],n[1],n[2],col)}
  Pq(p00,n0);Pq(p10,n1);Pq(p11,n1);Pq(p00,n0);Pq(p11,n1);Pq(p01,n0);
  var ct=W(0,y1,0),cb=W(0,y0,0);
  pv(m,ct[0],ct[1],ct[2],0,1,0,col);pv(m,p01[0],p01[1],p01[2],0,1,0,col);pv(m,p11[0],p11[1],p11[2],0,1,0,col);
  pv(m,cb[0],cb[1],cb[2],0,-1,0,col);pv(m,p10[0],p10[1],p10[2],0,-1,0,col);pv(m,p00[0],p00[1],p00[2],0,-1,0,col)}}
/* ellipsoïde (coussins, abat-jour, feuillage, boutons) */
function ell(m,cx,cy,cz,rx,ry,rz,phi,col,A,B){
 if(!(rx>0&&ry>0&&rz>0))return;var a=A||12,b=B||7,c=Math.cos(phi),s=Math.sin(phi),i,j;
 function P(i,j){var th=Math.PI*j/b,ph=2*Math.PI*i/a,ux=Math.sin(th)*Math.cos(ph),uy=Math.cos(th),uz=Math.sin(th)*Math.sin(ph),
  nx=ux/rx,ny=uy/ry,nz=uz/rz,l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;var px=rx*ux,pz=rz*uz;
  return[cx+px*c+pz*s,cy+ry*uy,cz-px*s+pz*c,nx*c+nz*s,ny,-nx*s+nz*c]}
 function V(v){pv(m,v[0],v[1],v[2],v[3],v[4],v[5],col)}
 for(j=0;j<b;j++)for(i=0;i<a;i++){var p00=P(i,j),p10=P(i+1,j),p01=P(i,j+1),p11=P(i+1,j+1);V(p00);V(p10);V(p11);V(p00);V(p11);V(p01)}}
/* une pièce de meuble : [x0,y0,z0,x1,y1,z1,couleur, forme, paramètre, matériau] — forme : b boîte · r arrondie (rayon m) · c cylindre · k cône tronqué · e ellipsoïde */
function furnPart(m,f,p,yb){
 var phi=-(f.rot||0)*Math.PI/180,c=Math.cos(phi),s=Math.sin(phi),lx=((p[0]+p[3])/2-.5)*f.w,lz=((p[1]+p[4])/2-.5)*f.d,
  cx=f.x+lx*c+lz*s,cy=yb+((p[2]+p[5])/2)*f.h+0.012,cz=f.y-lx*s+lz*c,sx=(p[3]-p[0])*f.w,sy=(p[5]-p[2])*f.h,sz=(p[4]-p[1])*f.d,col=hex(p[6]),sh=p[7]||'b',pa=p[8],keep=MT;
 if(p[9]!=null)MT=p[9];
 if(sh==='r')rbox(m,cx,cy,cz,sx,sy,sz,phi,col,pa);
 else if(sh==='c')cyl(m,cx,cy,cz,sx/2,sz/2,sy,phi,col,1,14);
 else if(sh==='k')cyl(m,cx,cy,cz,sx/2,sz/2,sy,phi,col,pa==null?.6:pa,14);
 else if(sh==='e')ell(m,cx,cy,cz,sx/2,sy/2,sz/2,phi,col,12,7);
 else box(m,cx,cy,cz,sx,sy,sz,phi,col);
 MT=keep}
function flat(m,P,i0,i1,i2,y,col){[i0,i1,i2].forEach(function(i){pv(m,P[i][0],y,P[i][1],0,1,0,col)})}
function inTri(p,a,b,c){function s(p1,p2,p3){return(p1[0]-p3[0])*(p2[1]-p3[1])-(p2[0]-p3[0])*(p1[1]-p3[1])}var d1=s(p,a,b),d2=s(p,b,c),d3=s(p,c,a);return!((d1<0||d2<0||d3<0)&&(d1>0||d2>0||d3>0))}
function earclip(P){var n=P.length,idx=[],i,A=0;for(i=0;i<n;i++)idx.push(i);
 for(i=0;i<n;i++){var a=P[i],b=P[(i+1)%n];A+=a[0]*b[1]-b[0]*a[1]}
 if(A<0)idx.reverse();var out=[],guard=0;
 while(idx.length>3&&guard++<1000){var ear=false;
  for(i=0;i<idx.length;i++){var i0=idx[(i+idx.length-1)%idx.length],i1=idx[i],i2=idx[(i+1)%idx.length],a2=P[i0],b2=P[i1],c2=P[i2];
   if((b2[0]-a2[0])*(c2[1]-a2[1])-(b2[1]-a2[1])*(c2[0]-a2[0])<=1e-12)continue;
   var ok=true;for(var j=0;j<idx.length;j++){var k=idx[j];if(k===i0||k===i1||k===i2)continue;if(inTri(P[k],a2,b2,c2)){ok=false;break}}
   if(ok){out.push([i0,i1,i2]);idx.splice(i,1);ear=true;break}}
  if(!ear)break}
 if(idx.length===3)out.push([idx[0],idx[1],idx[2]]);return out}

var CREME=hex('#e9e4d8'),BOISP=hex('#a16207'),BOISF=hex('#8a5a14'),CADRE=hex('#f8fafc'),CHAMB=hex('#e7e2d6'),METAL=hex('#c4c8d0'),SEUIL=hex('#9ca3af'),APPUI=hex('#eceae4'),VERRE=hex('#9ccbe6');
function wallPiece(m,ax,ay,ux,uy,s0,s1,y0,y1,t,col,extra){
 if(s1-s0<1e-3||y1-y0<1e-3)return;var mid=(s0+s1)/2;box(m,ax+ux*mid,(y0+y1)/2,ay+uy*mid,s1-s0+(extra||0),y1-y0,t,-Math.atan2(uy,ux),col)}

/* ouverture détaillée : porte (chambranle, vantail à panneaux, poignée, seuil) ou fenêtre (cadre, vitrage, meneau, appui) */
function openingBuild(m,gm,op,cx,cy,cz,ux,uy,W,hh,t,phi){
 function B(arr,off,dy,nr,sx,sy,sz,col){box(arr,cx+ux*off-uy*nr,cy+dy,cz+uy*off+ux*nr,sx,sy,sz,phi,col)}
 var fw=.05,dz=Math.min(t,.09);
 if(op.kind==='porte'){
  MT=1;B(m,-(W/2-.03),0,0,.06,hh,t+.03,CHAMB);B(m,W/2-.03,0,0,.06,hh,t+.03,CHAMB);B(m,0,hh/2-.03,0,W,.06,t+.03,CHAMB);
  MT=8;B(m,0,-.015,0,W-.12,hh-.06,.04,BOISP);
  var ph=hh*.34,pw=Math.max(.2,(W>1.5?W/2:W)-.34);
  [-1,1].forEach(function(sg){var nr=sg*.026;
   if(W>1.5){[-1,1].forEach(function(lf){var c0=lf*W/4;B(m,c0,hh*.2,nr,pw,ph,.012,BOISF);B(m,c0,-hh*.2,nr,pw,ph,.012,BOISF)})}
   else{B(m,0,hh*.2,nr,pw,ph,.012,BOISF);B(m,0,-hh*.2,nr,pw,ph,.012,BOISF)}});
  if(W>1.5)B(m,0,-.015,0,.02,hh-.06,.05,hex('#5b3a0a'));
  MT=10;var hx=W>1.5?.12:W/2-.14,hyy=Math.min(-hh/2+1.0,hh/2-.2);
  [-1,1].forEach(function(sg){B(m,hx,hyy,sg*.05,.13,.028,.03,METAL);B(m,hx,hyy,sg*.032,.05,.07,.012,METAL)});
  MT=7;B(m,0,-hh/2+.01,0,W,.02,t+.02,SEUIL)
 }else{
  MT=1;B(m,-(W/2-fw/2),0,0,fw,hh,dz,CADRE);B(m,W/2-fw/2,0,0,fw,hh,dz,CADRE);B(m,0,hh/2-fw/2,0,W,fw,dz,CADRE);B(m,0,-hh/2+fw/2,0,W,fw,dz,CADRE);
  if(W>1.1)B(m,0,0,0,.04,hh-2*fw,dz*.8,CADRE);
  if(hh>1.5&&W>.7)B(m,0,hh*.2,0,W-2*fw,.035,dz*.8,CADRE);
  MT=6;box(gm,cx,cy,cz,W-2*fw,hh-2*fw,.012,phi,VERRE);
  if(op.sill>.25){MT=7;B(m,0,-hh/2-.02,0,W+.12,.04,t+.1,APPUI)}
 }
 MT=1}
/* mur = chemin (2 points si droit, davantage si courbe) ; ouvertures repérées par leur abscisse curviligne */
function wallBuild(m,gm,wl,yb,bb){
 var P=wl.path,cum=[0],i,k;for(i=0;i<P.length-1;i++){cum.push(cum[i]+Math.hypot(P[i+1][0]-P[i][0],P[i+1][1]-P[i][1]));bb(P[i][0],P[i][1])}bb(P[P.length-1][0],P[P.length-1][1]);
 var L=cum[cum.length-1],sc=wl.len?L/wl.len:1,curved=P.length>2,ext=curved?Math.min(.04,wl.t*.2):0,
  ops=(wl.ops||[]).map(function(o){return{s0:(o.pos-o.w/2)*sc,s1:(o.pos+o.w/2)*sc,h:o.h,sill:o.sill||0,kind:o.kind,id:o.id}});
 for(i=0;i<P.length-1;i++){var a=P[i],b=P[i+1],sl=cum[i+1]-cum[i];if(sl<1e-4)continue;var ux=(b[0]-a[0])/sl,uy=(b[1]-a[1])/sl,g0=cum[i],g1=cum[i+1],br=[g0,g1];
  ops.forEach(function(o){if(o.s0>g0&&o.s0<g1)br.push(o.s0);if(o.s1>g0&&o.s1<g1)br.push(o.s1)});br.sort(function(p,q){return p-q});
  for(k=0;k<br.length-1;k++){var u0=br[k],u1=br[k+1];if(u1-u0<1e-4)continue;var mid=(u0+u1)/2,op=null;ops.forEach(function(o){if(mid>=o.s0&&mid<=o.s1)op=o});var l0=u0-g0,l1=u1-g0;
   MT=1;
   if(!op){wallPiece(m,a[0],a[1],ux,uy,l0,l1,yb,yb+wl.h,wl.t,CREME,ext);continue}
   var top=Math.min(wl.h,op.sill+op.h);
   if(op.sill>.001)wallPiece(m,a[0],a[1],ux,uy,l0,l1,yb,yb+op.sill,wl.t,CREME,ext);
   if(top<wl.h-.001)wallPiece(m,a[0],a[1],ux,uy,l0,l1,yb+top,yb+wl.h,wl.t,CREME,ext);
   var mm=(l0+l1)/2,cx=a[0]+ux*mm,cz=a[1]+uy*mm,phi=-Math.atan2(uy,ux),cy=yb+(op.sill+top)/2,hh=top-op.sill;
   var tk=TAGCUR,tw=TAGS[tk];if(op.id!=null&&tw)tag({t:'o',id:op.id,lv:tw.lv});openingBuild(m,gm,op,cx,cy,cz,ux,uy,l1-l0+.002,hh,wl.t,phi);TAGCUR=tk}}
 MT=1}
function tri(m,p,q,r,col,up){var ux=q[0]-p[0],uy=q[1]-p[1],uz=q[2]-p[2],vx=r[0]-p[0],vy=r[1]-p[1],vz=r[2]-p[2],nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;if(up&&ny<0){nx=-nx;ny=-ny;nz=-nz}
 [p,q,r].forEach(function(v){pv(m,v[0],v[1],v[2],nx,ny,nz,col)})}
function quad(m,a,b,c,d,col,up){tri(m,a,b,c,col,up);tri(m,a,c,d,col,up)}
function blob(m,cx,cy,cz,r,col){var a=8,b=5,i,j;
 function P(i,j){var th=Math.PI*j/b,ph=2*Math.PI*i/a;return[cx+r*Math.sin(th)*Math.cos(ph),cy+r*Math.cos(th)*.9,cz+r*Math.sin(th)*Math.sin(ph)]}
 for(j=0;j<b;j++)for(i=0;i<a;i++){var p00=P(i,j),p10=P(i+1,j),p01=P(i,j+1),p11=P(i+1,j+1);
  [[p00,p10,p11],[p00,p11,p01]].forEach(function(T){T.forEach(function(v){pv(m,v[0],v[1],v[2],(v[0]-cx)/r,(v[1]-cy)/(r*.9),(v[2]-cz)/r,col)})})}}

var TUILE='#b45f3c';
function roofBuild(m,R){var x0=R.x0,x1=R.x1,z0=R.y0,z1=R.y1,yE=R.yE,col=hex(R.col||TUILE),w=x1-x0,d=z1-z0,xc=(x0+x1)/2,zc=(z0+z1)/2,GR=hex('#8b8f98'),AC=hex('#d9d5ca');
 if(R.poly){var PP=R.poly,TT=earclip(PP),yt=yE+.2,kk;MT=7;TT.forEach(function(t){flat(m,PP,t[0],t[1],t[2],yt,GR)});MT=1;for(kk=0;kk<PP.length;kk++){var pa=PP[kk],pb=PP[(kk+1)%PP.length];quad(m,[pa[0],yE,pa[1]],[pb[0],yE,pb[1]],[pb[0],yt,pb[1]],[pa[0],yt,pa[1]],hex('#6b7280'),true)}return}
 if(R.type==='plat'){MT=7;box(m,xc,yE+.1,zc,w,.2,d,0,GR,true);MT=1;var ac=.3,at=.14,ya=yE+.2+ac/2;
  box(m,xc,ya,z0+at/2,w,ac,at,0,AC);box(m,xc,ya,z1-at/2,w,ac,at,0,AC);box(m,x0+at/2,ya,zc,at,ac,d-2*at,0,AC);box(m,x1-at/2,ya,zc,at,ac,d-2*at,0,AC);return}
  MT=1;quad(m,[x0,yE-.002,z0],[x1,yE-.002,z0],[x1,yE-.002,z1],[x0,yE-.002,z1],hex('#f1efe8'));
 var tn=Math.tan((R.slope||30)*Math.PI/180),alongX=R.axis==='x'?true:R.axis==='y'?false:w>=d,span=alongX?d:w,rise=span/2*tn,yR=yE+rise,cw=hex('#e9e4d8'),e=.35,ye=yE-e*tn,GU=hex('#6b7280'),FA=hex('#7c2d12');
 if(R.type==='2pans'){
  MT=5;
  if(alongX){quad(m,[x0-e,ye,z0-e],[x1+e,ye,z0-e],[x1+e,yR,zc],[x0-e,yR,zc],col,true);quad(m,[x0-e,ye,z1+e],[x1+e,ye,z1+e],[x1+e,yR,zc],[x0-e,yR,zc],col,true);MT=1;tri(m,[x0,yE,z0],[x0,yE,z1],[x0,yR,zc],cw);tri(m,[x1,yE,z0],[x1,yE,z1],[x1,yR,zc],cw);
   MT=7;box(m,xc,ye-.04,z0-e,w+2*e,.1,.08,0,GU);box(m,xc,ye-.04,z1+e,w+2*e,.1,.08,0,GU);box(m,xc,yR+.03,zc,w+2*e+.05,.07,.2,0,FA)}
  else{quad(m,[x0-e,ye,z0-e],[x0-e,ye,z1+e],[xc,yR,z1+e],[xc,yR,z0-e],col,true);quad(m,[x1+e,ye,z0-e],[x1+e,ye,z1+e],[xc,yR,z1+e],[xc,yR,z0-e],col,true);MT=1;tri(m,[x0,yE,z0],[x1,yE,z0],[xc,yR,z0],cw);tri(m,[x0,yE,z1],[x1,yE,z1],[xc,yR,z1],cw);
   MT=7;box(m,x0-e,ye-.04,zc,.08,.1,d+2*e,0,GU);box(m,x1+e,ye-.04,zc,.08,.1,d+2*e,0,GU);box(m,xc,yR+.03,zc,.2,.07,d+2*e+.05,0,FA)}
  MT=1;return}
 /* 4 pans */
 var h2=span/2,r1,r2;MT=5;if(alongX){r1=[x0+h2,yR,zc];r2=[x1-h2,yR,zc];if(r2[0]<r1[0]){r1=r2=[xc,yR,zc]}
  quad(m,[x0-e,ye,z0-e],[x1+e,ye,z0-e],r2,r1,col,true);quad(m,[x0-e,ye,z1+e],[x1+e,ye,z1+e],r2,r1,col,true);tri(m,[x0-e,ye,z0-e],[x0-e,ye,z1+e],r1,col,true);tri(m,[x1+e,ye,z0-e],[x1+e,ye,z1+e],r2,col,true)}
 else{r1=[xc,yR,z0+h2];r2=[xc,yR,z1-h2];if(r2[2]<r1[2]){r1=r2=[xc,yR,zc]}
  quad(m,[x0-e,ye,z0-e],[x0-e,ye,z1+e],r2,r1,col,true);quad(m,[x1+e,ye,z0-e],[x1+e,ye,z1+e],r2,r1,col,true);tri(m,[x0-e,ye,z0-e],[x1+e,ye,z0-e],r1,col,true);tri(m,[x0-e,ye,z1+e],[x1+e,ye,z1+e],r2,col,true)}
 MT=7;box(m,xc,ye-.04,z0-e,w+2*e,.1,.08,0,GU);box(m,xc,ye-.04,z1+e,w+2*e,.1,.08,0,GU);box(m,x0-e,ye-.04,zc,.08,.1,d+2*e,0,GU);box(m,x1+e,ye-.04,zc,.08,.1,d+2*e,0,GU);MT=1}

/* extérieur : pelouse, trottoir, route, allée, clôture avec portail, arbres */
function fenceSeg(m,x0,z0,x1,z1){var Ln=Math.hypot(x1-x0,z1-z0);if(Ln<.05)return;var phi=-Math.atan2(z1-z0,x1-x0),cx=(x0+x1)/2,cz=(z0+z1)/2,n=Math.max(1,Math.round(Ln/3)),i;MT=1;
 box(m,cx,.45,cz,Ln,.9,.14,phi,hex('#f1ede2'));box(m,cx,.92,cz,Ln,.04,.2,phi,hex('#d6d0c0'));
 for(i=0;i<=n;i++){box(m,x0+(x1-x0)*i/n,.58,z0+(z1-z0)*i/n,.28,1.16,.28,0,hex('#e2dccb'))}}
var GY=-.02;
function terrainBuild(m,T){var lo=1e9,hi=-1e9;T.forEach(function(t){t.forEach(function(p){lo=Math.min(lo,p[1]);hi=Math.max(hi,p[1])})});var rg=Math.max(.01,hi-lo);MT=4;
 T.forEach(function(t){var f=((t[0][1]+t[1][1]+t[2][1])/3-lo)/rg;tri(m,t[0],t[1],t[2],hsl(Math.round(100-f*60),.42,.5-f*.12),true)});return lo}
function exteriorBuild(m,minx,maxx,minz,maxz,deco){
 var cx=(minx+maxx)/2,cz=(minz+maxz)/2,M=6,px0=minx-M,px1=maxx+M,pz0=minz-M,pz1=maxz+M,R=Math.max(maxx-minx,maxz-minz)*3+80,GA=[[cx-R,cz-R],[cx+R,cz-R],[cx+R,cz+R],[cx-R,cz+R]],i,col;
 MT=4;col=hex('#7aa05a');flat(m,GA,0,1,2,GY,col);flat(m,GA,0,2,3,GY,col);if(deco===false)return;
 function strip(xa,xb,za,zb,y,c,mt){MT=mt;var q=[[xa,za],[xb,za],[xb,zb],[xa,zb]];flat(m,q,0,1,2,y,c);flat(m,q,0,2,3,y,c)}
 strip(cx-R,cx+R,pz1+1.6,pz1+8,-.012,hex('#4b5563'),12);
 strip(cx-R,cx+R,pz1,pz1+1.6,-.01,hex('#c2bdb1'),9);
 strip(cx-.7,cx+.7,maxz-.05,pz1,-.008,hex('#cdc7ba'),9);
 fenceSeg(m,px0,pz0,px1,pz0);fenceSeg(m,px0,pz0,px0,pz1);fenceSeg(m,px1,pz0,px1,pz1);fenceSeg(m,px0,pz1,cx-1.4,pz1);fenceSeg(m,cx+1.4,pz1,px1,pz1);
 MT=1;box(m,cx-1.45,.75,pz1,.34,1.5,.34,0,hex('#d9d2c0'));box(m,cx+1.45,.75,pz1,.34,1.5,.34,0,hex('#d9d2c0'));
 MT=10;[-1,1].forEach(function(sg){box(m,cx+sg*.7,.72,pz1,1.34,1.25,.05,0,hex('#2f3b4c'));box(m,cx+sg*.7,1.2,pz1,1.34,.05,.07,0,hex('#1f2937'))});
 var T=[[minx-3,minz-3],[maxx+3,minz-3],[minx-3,(minz+maxz)/2],[maxx+3,(minz+maxz)/2+1.5],[maxx+3,maxz+2.6],[minx-3,maxz+2.4]],g1=hex('#4f8a3c'),g2=hex('#3f7a35'),tk=hex('#6b4a2b');
 T.forEach(function(p,k){MT=8;box(m,p[0],1.1,p[1],.26,2.2,.26,0,tk);MT=11;blob(m,p[0],3.3,p[1],1.5+.12*(k%3),k%2?g1:g2);blob(m,p[0]+.7,2.85,p[1]+.35,1.0,k%2?g2:g1)});
 MT=0}

function build(S){var m=[],gm=[];TG=[];TGG=[];TAGS=[];TAGCUR=-1;CURM=m;CURG=gm;var minx=1e9,maxx=-1e9,miny=1e9,maxy=-1e9,topY=0,ext=!(S.r3d&&S.r3d.ext===false);
 function bb(x,y){if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y}
 (S.levels||[]).forEach(function(L,li){TAGCUR=-1;var yb=L.y0,H=L.H||2.8;topY=Math.max(topY,yb+H);
  (L.rooms||[]).forEach(function(r){tag({t:'r',id:r.id,lv:li});var mat=r.mat||'tile',col;
   if(mat==='parquet'){MT=3;col=hex('#b98552')}else if(mat==='beton'){MT=7;col=hex('#b3b3b0')}else{MT=2;col=hsl(r.hue,.1,.83)}
   var T=earclip(r.pts);T.forEach(function(t){flat(m,r.pts,t[0],t[1],t[2],yb+0.01,col)});r.pts.forEach(function(p){bb(p[0],p[1])})});
  TAGCUR=-1;MT=1;(L.walls||[]).forEach(function(wl){tag({t:'w',id:wl.id,lv:li});wallBuild(m,gm,wl,yb,bb)});TAGCUR=-1;
  MT=0;(L.furn||[]).forEach(function(f){tag({t:'f',id:f.id,lv:li});var phi=-(f.rot||0)*Math.PI/180;bb(f.x,f.y);
   (f.parts||[]).forEach(function(p){furnPart(m,f,p,yb+(f.z||0))})});
  TAGCUR=-1;(L.elec||[]).forEach(function(e){tag({t:'e',id:e.id,lv:li});var z=e.z==null?H-.04:e.z;box(m,e.x,yb+z,e.y,.11,.11,.11,0,hex(e.col));bb(e.x,e.y)})});
 TAGCUR=-1;MT=7;(S.slabs||[]).forEach(function(sl){var rs=[[sl.x0,sl.x1,sl.y0,sl.y1]];(sl.holes||[]).forEach(function(h){var nr=[];rs.forEach(function(r){var ox0=Math.max(r[0],h[0]),ox1=Math.min(r[1],h[1]),oy0=Math.max(r[2],h[2]),oy1=Math.min(r[3],h[3]);
   if(ox0>=ox1||oy0>=oy1){nr.push(r);return}if(ox0>r[0])nr.push([r[0],ox0,r[2],r[3]]);if(ox1<r[1])nr.push([ox1,r[1],r[2],r[3]]);if(oy0>r[2])nr.push([ox0,ox1,r[2],oy0]);if(oy1<r[3])nr.push([ox0,ox1,oy1,r[3]])});rs=nr});
  rs.forEach(function(r){box(m,(r[0]+r[1])/2,sl.y-.1,(r[2]+r[3])/2,r[1]-r[0],.2,r[3]-r[2],0,hex('#cfcfd2'),true)})});
 MT=10;(S.rails||[]).forEach(function(r){var dx=r.x1-r.x0,dz=r.z1-r.z0,Ls=Math.hypot(dx,dz);if(Ls<.05)return;var ang=Math.atan2(dz,dx),n=Math.max(1,Math.ceil(Ls/.9)),i,col=hex('#4b5563');
  for(i=0;i<=n;i++){var u=i/n;box(m,r.x0+dx*u,r.y+.5,r.z0+dz*u,.05,1.0,.05,0,col)}
  box(m,(r.x0+r.x1)/2,r.y+1.0,(r.z0+r.z1)/2,Ls,.05,.06,-ang,col);box(m,(r.x0+r.x1)/2,r.y+.55,(r.z0+r.z1)/2,Ls,.03,.03,-ang,col);box(m,(r.x0+r.x1)/2,r.y+.12,(r.z0+r.z1)/2,Ls,.03,.03,-ang,col)});MT=1;
 (S.roofs||(S.roof?[S.roof]:[])).forEach(function(R){tag({t:'T',id:R.id});roofBuild(m,R);bb(R.x0,R.y0);bb(R.x1,R.y1)});
 TAGCUR=-1;if(S.terrain&&S.terrain.tris)S.terrain.tris.forEach(function(t){t.forEach(function(p){bb(p[0],p[2])})});if(minx>maxx){minx=0;maxx=5;miny=0;maxy=5}
 if(S.terrain&&S.terrain.tris&&S.terrain.tris.length){var tlo=terrainBuild(m,S.terrain.tris);GY=Math.min(-.02,tlo-.05);exteriorBuild(m,minx,maxx,miny,maxy,false);GY=-.02}
 else if(ext)exteriorBuild(m,minx,maxx,miny,maxy);
 else{var gx=(minx+maxx)/2,gz=(miny+maxy)/2,R=Math.max(maxx-minx,maxy-miny)*3+60,gp=[[gx-R,gz-R],[gx+R,gz-R],[gx+R,gz+R],[gx-R,gz+R]],g0=hex('#dfe3e8');MT=0;flat(m,gp,0,1,2,-0.02,g0);flat(m,gp,0,2,3,-0.02,g0)}
 MT=0;
 return{data:new Float32Array(m),glass:new Float32Array(gm),ext:ext,bbox:[minx,maxx,miny,maxy,Math.max(topY,2.8)+(S.roofs&&S.roofs.length||S.roof?2:0)],tags:TAGS,tg:Int32Array.from(TG),gtg:Int32Array.from(TGG)}}

/* ---- matrices ---- */
function persp(f,a,n,fa){var t=1/Math.tan(f/2),r=1/(n-fa);return[t/a,0,0,0,0,t,0,0,0,0,(n+fa)*r,-1,0,0,2*n*fa*r,0]}
function ortho(l,r,b,t,n,f){return[2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1]}
function look(e,c,u){var zx=e[0]-c[0],zy=e[1]-c[1],zz=e[2]-c[2],l=Math.hypot(zx,zy,zz);zx/=l;zy/=l;zz/=l;
 var xx=u[1]*zz-u[2]*zy,xy=u[2]*zx-u[0]*zz,xz=u[0]*zy-u[1]*zx;l=Math.hypot(xx,xy,xz);xx/=l;xy/=l;xz/=l;
 var yx=zy*xz-zz*xy,yy=zz*xx-zx*xz,yz=zx*xy-zy*xx;
 return[xx,yx,zx,0,xy,yy,zy,0,xz,yz,zz,0,-(xx*e[0]+xy*e[1]+xz*e[2]),-(yx*e[0]+yy*e[1]+yz*e[2]),-(zx*e[0]+zy*e[1]+zz*e[2]),1]}
function mul(a,b){var o=new Array(16),i,j,k;for(i=0;i<4;i++)for(j=0;j<4;j++){var s=0;for(k=0;k<4;k++)s+=a[k*4+j]*b[i*4+k];o[i*4+j]=s}return o}
function mix3(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t]}

/* soleil : heure 6..18 -> direction (vers le soleil, nord = -Z), couleurs du ciel et de la lumière */
function sunOf(h){var t=Math.max(0,Math.min(1,((h==null?16:h)-6)/12)),el=(5+75*Math.sin(Math.PI*t))*Math.PI/180,az=(90-180*t)*Math.PI/180,
 L=[Math.cos(el)*Math.sin(az),Math.sin(el),-Math.cos(el)*Math.cos(az)],warm=Math.max(0,Math.min(1,1-el*180/Math.PI/40));
 return{L:L,el:el,SC:mix3([1,.96,.88],[1,.7,.42],warm),HZ:mix3([.8,.89,.97],[.98,.78,.6],warm),ZN:mix3([.27,.52,.88],[.36,.45,.7],warm),AM:.62-.18*warm}}

var VS='attribute vec3 p;attribute vec3 n;attribute vec3 c;attribute float m;uniform mat4 M;uniform mat4 LM;varying vec3 vp;varying vec3 vn;varying vec3 vc;varying float vm;varying vec4 vs;void main(){gl_Position=M*vec4(p,1.0);vp=p;vn=n;vc=c;vm=m;vs=LM*vec4(p,1.0);}';
var FS=['#ifdef GL_FRAGMENT_PRECISION_HIGH','precision highp float;','#else','precision mediump float;','#endif',
'varying vec3 vp;varying vec3 vn;varying vec3 vc;varying float vm;varying vec4 vs;',
'uniform vec3 L;uniform vec3 SC;uniform vec3 CP;uniform vec3 HZ;uniform vec3 ZN;uniform float SH;uniform float TS;uniform float AM;uniform float FL;uniform sampler2D SM;',
'bool is(float a){return abs(vm-a)<0.5;}',
'float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}',
'float vn2(vec2 p){vec2 i=floor(p);vec2 f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hs(i),hs(i+vec2(1.0,0.0)),f.x),mix(hs(i+vec2(0.0,1.0)),hs(i+vec2(1.0,1.0)),f.x),f.y);}',
'float ud(vec4 v){return dot(v,vec4(1.0,1.0/255.0,1.0/65025.0,1.0/16581375.0));}',
'float shd(vec3 N){if(SH<0.5)return 1.0;vec3 s=vs.xyz/vs.w*0.5+0.5;if(s.x<0.0||s.x>1.0||s.y<0.0||s.y>1.0||s.z>1.0)return 1.0;',
' float b=0.0006+0.0018*(1.0-max(dot(N,L),0.0));float a=0.0;',
' for(int i=-1;i<=1;i++){for(int j=-1;j<=1;j++){float d=ud(texture2D(SM,s.xy+vec2(float(i),float(j))*TS));a+=(s.z-b>d)?0.0:1.0;}}',
' return a/9.0;}',
'void main(){',
' vec3 N=normalize(vn);vec3 V=normalize(CP-vp);if(dot(N,V)<0.0)N=-N;',
' vec3 al=vc;float sp=0.0;',
' if(is(1.0)){al*=0.94+0.06*vn2((vp.xz+vp.y*1.7)*55.0)+0.03*vn2((vp.xz+vp.y)*9.0)-0.03;}',
' else if(is(2.0)){vec2 u=vp.xz/0.6;vec2 f=fract(u);float j=step(f.x,0.012)+step(f.y,0.012);al*=(1.0-0.05*hs(floor(u)))*(j>0.0?0.8:1.0);}',
' else if(is(3.0)){float row=floor(vp.z/0.12);float uu=vp.x+hs(vec2(row,3.0))*1.2;float pid=floor(uu/1.2);float tone=hs(vec2(pid,row));float jn=step(fract(vp.z/0.12),0.035)+step(fract(uu/1.2),0.006);al*=(0.86+0.28*tone)*(0.94+0.06*vn2(vec2(vp.x*5.0,vp.z*70.0)))*(jn>0.0?0.72:1.0);}',
' else if(is(4.0)){al*=0.72+0.22*vn2(vp.xz*2.5)+0.12*vn2(vp.xz*30.0);}',
' else if(is(5.0)){vec2 hd=N.xz;float hl=length(hd);if(hl<0.12){al*=0.9+0.1*vn2(vp.xz*30.0);}else{hd/=hl;float s=dot(vp.xz,hd)/max(N.y,0.25);float t=dot(vp.xz,vec2(-hd.y,hd.x));float row=floor(s/0.34);float fr=fract(s/0.34);float tt=(t+0.125*mod(row,2.0))/0.25;float id=hs(vec2(floor(tt),row));al*=(0.82+0.3*id)*(0.7+0.3*smoothstep(0.0,0.35,fr))*(fract(tt)<0.05?0.8:1.0);}}',
' else if(is(7.0)){al*=0.9+0.12*vn2(vp.xz*25.0+vp.y*25.0);}',
' else if(is(8.0)){al*=0.8+0.28*vn2(vec2((vp.x+vp.z)*18.0,vp.y*1.5));}',
' else if(is(9.0)){vec2 u=vp.xz/0.45;vec2 f=fract(u);float j=step(f.x,0.03)+step(f.y,0.03);al*=(0.9+0.1*hs(floor(u)))*(j>0.0?0.75:1.0);}',
' else if(is(10.0)){sp=1.0;}',
' else if(is(11.0)){al*=0.7+0.45*vn2(vp.xz*7.0+vp.y*7.0);}',
' else if(is(12.0)){al*=0.85+0.2*vn2(vp.xz*20.0);}',
' float ndl=max(dot(N,L),0.0);float sh=ndl>0.0?shd(N):1.0;',
' vec3 amb=mix(vec3(0.42,0.40,0.37),ZN*0.55+HZ*0.45,N.y*0.5+0.5)*AM;',
' float dl=length(CP-vp);float fl=FL*max(dot(N,(CP-vp)/max(dl,0.001)),0.0)/(1.0+0.45*dl*dl);',
' vec3 col=al*(amb+SC*ndl*sh+vec3(1.0,0.95,0.86)*fl);',
' if(sp>0.5){vec3 hv=normalize(L+V);col+=SC*pow(max(dot(N,hv),0.0),40.0)*sh*0.6;}',
' float alpha=1.0;',
' if(is(6.0)){float fr=pow(1.0-max(dot(N,V),0.0),3.0);vec3 rf=reflect(-V,N);vec3 sk=mix(HZ,ZN,clamp(rf.y*1.5,0.0,1.0));col=mix(vec3(0.30,0.45,0.58),sk,0.35+0.55*fr)+SC*pow(max(dot(rf,L),0.0),80.0)*0.9;alpha=0.42+0.4*fr;}',
' float dd=length(CP-vp);col=mix(col,HZ,smoothstep(70.0,230.0,dd));',
' gl_FragColor=vec4(col,alpha);}'].join('\n');
/* repli : éclairage simple de l'ancienne version, si l'appareil refuse le rendu réaliste */
var VSL='attribute vec3 p;attribute vec3 n;attribute vec3 c;attribute float m;uniform mat4 M;varying vec3 vc;varying float vl;void main(){gl_Position=M*vec4(p,1.0);vc=c+0.0*m;vec3 nn=normalize(n);vl=0.46+0.5*max(dot(nn,normalize(vec3(0.35,0.85,0.45))),0.0)+0.2*max(dot(nn,normalize(vec3(-0.6,0.25,-0.5))),0.0);}';
var FSL='precision mediump float;varying vec3 vc;varying float vl;void main(){gl_FragColor=vec4(vc*vl,1.0);}';
var VS2='attribute vec3 p;uniform mat4 LM;varying float z;void main(){vec4 q=LM*vec4(p,1.0);gl_Position=q;z=q.z*0.5+0.5;}';
var FS2=['#ifdef GL_FRAGMENT_PRECISION_HIGH','precision highp float;','#else','precision mediump float;','#endif','varying float z;',
'vec4 pk(float d){vec4 e=fract(d*vec4(1.0,255.0,65025.0,16581375.0));e-=e.yzww*vec4(1.0/255.0,1.0/255.0,1.0/255.0,0.0);return e;}',
'void main(){gl_FragColor=pk(clamp(z,0.0,0.99999));}'].join('\n');
var VS3='attribute vec2 a;varying vec2 v;void main(){v=a;gl_Position=vec4(a,0.9999,1.0);}';
var FS3=['precision mediump float;','varying vec2 v;uniform vec3 FW;uniform vec3 RT;uniform vec3 UP;uniform vec2 TN;uniform vec3 HZ;uniform vec3 ZN;uniform vec3 SC;uniform vec3 L;',
'void main(){vec3 r=normalize(FW+v.x*TN.x*RT+v.y*TN.y*UP);vec3 c=r.y>=0.0?mix(HZ,ZN,pow(clamp(r.y,0.0,1.0),0.5)):HZ*0.95;',
' float sd=max(dot(r,L),0.0);c+=SC*(pow(sd,700.0)*1.6+pow(sd,14.0)*0.14);gl_FragColor=vec4(c,1.0);}'].join('\n');

function create(canvas){
 var gl=null;try{gl=canvas.getContext('webgl',{antialias:true})||canvas.getContext('experimental-webgl')}catch(e){}
 if(!gl)return null;
 function sh(t,s){var o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS)){try{console.warn('EXB3D shader :',gl.getShaderInfoLog(o))}catch(e){}}return o}
 function prog(vs,fs,attrs){var pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,vs));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,fs));attrs.forEach(function(a,i){gl.bindAttribLocation(pr,i,a)});gl.linkProgram(pr);return gl.getProgramParameter(pr,gl.LINK_STATUS)?pr:null}
 function U(pr,names){var o={};names.forEach(function(n){o[n]=gl.getUniformLocation(pr,n)});return o}
 var pr=prog(VS,FS,['p','n','c','m']),simple=false;
 if(!pr){pr=prog(VSL,FSL,['p','n','c','m']);simple=true}
 if(!pr)return null;
 var pS=simple?null:prog(VS2,FS2,['p']),pK=simple?null:prog(VS3,FS3,['a']);
 var uM=U(pr,['M','LM','L','SC','CP','HZ','ZN','SH','TS','AM','FL','SM']),uS=pS?U(pS,['LM']):null,uK=pK?U(pK,['FW','RT','UP','TN','HZ','ZN','SC','L']):null;
 var buf=gl.createBuffer(),gbuf=gl.createBuffer(),qbuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,qbuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
 /* carte d'ombres (profondeur empaquetée en RGBA : fonctionne partout, sans extension) */
 var SS=Math.min(2048,gl.getParameter(gl.MAX_TEXTURE_SIZE)||1024),fbo=null,tex=null,shOK=false;
 try{if(pS){tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,SS,SS,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  var rb=gl.createRenderbuffer();gl.bindRenderbuffer(gl.RENDERBUFFER,rb);gl.renderbufferStorage(gl.RENDERBUFFER,gl.DEPTH_COMPONENT16,SS,SS);
  fbo=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);gl.framebufferRenderbuffer(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.RENDERBUFFER,rb);
  shOK=gl.checkFramebufferStatus(gl.FRAMEBUFFER)===gl.FRAMEBUFFER_COMPLETE;gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.bindTexture(gl.TEXTURE_2D,null)}}catch(e){shOK=false}
 var walk=null,wd=null,wRaf=0,wLast=0,wIn={x:0,y:0},wRun=false,wKeys={},gyro=null,wHook=null;
 var pk=null,hbuf=gl.createBuffer(),hcount=0,selKeys=null,lastMat=null,pickHook=null,mqHook=null,mqS=null,dgHook=null,dgMoved=false;
 var busy=false,count=0,gcount=0,cam={az:0.7,el:0.75,dist:15,t:[2.5,1,2.5]},bbx=[0,5,0,5,2.8],ptrs={},last=null,raf=0,opts={h:16,ext:true,sh:true},lastS=null,builtExt=true,LM=null,shDirty=true;
 function attrs(n){var i;for(i=0;i<4;i++){if(i<n)gl.enableVertexAttribArray(i);else gl.disableVertexAttribArray(i)}}
 function resize(){if(busy)return;var dp=window.devicePixelRatio||1,r=canvas.getBoundingClientRect(),W=Math.max(1,Math.round(r.width*dp)),H=Math.max(1,Math.round(r.height*dp));if(canvas.width!==W||canvas.height!==H){canvas.width=W;canvas.height=H}draw()}
 function eye(){var ce=Math.cos(cam.el);return[cam.t[0]+cam.dist*ce*Math.sin(cam.az),cam.t[1]+cam.dist*Math.sin(cam.el),cam.t[2]+cam.dist*ce*Math.cos(cam.az)]}
 function draw(){if(raf||busy)return;raf=requestAnimationFrame(function(){raf=0;render()})}
 function lightMat(sun){var ex=builtExt?9:2,hx=(bbx[1]-bbx[0])/2+ex,hz=(bbx[3]-bbx[2])/2+ex,hy=bbx[4]/2,rr=Math.hypot(hx,hz,hy),c=[(bbx[0]+bbx[1])/2,hy,(bbx[2]+bbx[3])/2],e=[c[0]+sun.L[0]*rr*2,c[1]+sun.L[1]*rr*2,c[2]+sun.L[2]*rr*2];
  return mul(ortho(-rr,rr,-rr,rr,.1,rr*4),look(e,c,sun.L[1]>.96?[0,0,1]:[0,1,0]))}
 function render(){
  var sun=sunOf(opts.h),useSh=!!(opts.sh!==false&&shOK&&!simple&&count);
  gl.disable(gl.BLEND);
  if(useSh&&(shDirty||!LM)){LM=lightMat(sun);gl.bindTexture(gl.TEXTURE_2D,null);gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);gl.viewport(0,0,SS,SS);gl.clearColor(1,1,1,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);
   gl.useProgram(pS);gl.uniformMatrix4fv(uS.LM,false,new Float32Array(LM));gl.bindBuffer(gl.ARRAY_BUFFER,buf);attrs(1);gl.vertexAttribPointer(0,3,gl.FLOAT,false,40,0);gl.drawArrays(gl.TRIANGLES,0,count);gl.bindFramebuffer(gl.FRAMEBUFFER,null);shDirty=false}
  gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(sun.HZ[0],sun.HZ[1],sun.HZ[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  var a=canvas.width/Math.max(1,canvas.height),E,V,fov=0.8,FWD,near=0.1;
  if(walk){E=[walk.x,walk.fy+1.6,walk.z];FWD=wFwd();V=look(E,[E[0]+FWD[0],E[1]+FWD[1],E[2]+FWD[2]],[0,1,0]);fov=Math.max(.9,Math.min(1.6,2*Math.atan(Math.tan(.55)/a)));near=0.06}
  else{E=eye();V=look(E,cam.t,[0,1,0]);FWD=[cam.t[0]-E[0],cam.t[1]-E[1],cam.t[2]-E[2]];var fl0=Math.hypot(FWD[0],FWD[1],FWD[2]);FWD=[FWD[0]/fl0,FWD[1]/fl0,FWD[2]/fl0]}
  var M=mul(persp(fov,a,near,400),V);lastMat=M;
  /* ciel */
  if(pK){var fw=FWD;
   var rt=[-fw[2],0,fw[0]],rl=Math.hypot(rt[0],rt[2])||1;rt=[rt[0]/rl,0,rt[2]/rl];var up=[rt[1]*fw[2]-rt[2]*fw[1],rt[2]*fw[0]-rt[0]*fw[2],rt[0]*fw[1]-rt[1]*fw[0]];
   gl.disable(gl.DEPTH_TEST);gl.useProgram(pK);gl.uniform3fv(uK.FW,fw);gl.uniform3fv(uK.RT,rt);gl.uniform3fv(uK.UP,up);gl.uniform2f(uK.TN,Math.tan(fov/2)*a,Math.tan(fov/2));gl.uniform3fv(uK.HZ,sun.HZ);gl.uniform3fv(uK.ZN,sun.ZN);gl.uniform3fv(uK.SC,sun.SC);gl.uniform3fv(uK.L,sun.L);
   gl.bindBuffer(gl.ARRAY_BUFFER,qbuf);attrs(1);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);gl.drawArrays(gl.TRIANGLES,0,3)}
  if(!count)return;
  gl.enable(gl.DEPTH_TEST);gl.useProgram(pr);gl.uniformMatrix4fv(uM.M,false,new Float32Array(M));gl.uniformMatrix4fv(uM.LM,false,new Float32Array(LM||mul(ortho(-1,1,-1,1,.1,2),look([0,1,0],[0,0,0],[0,0,1]))));
  gl.uniform3fv(uM.L,sun.L);gl.uniform3fv(uM.SC,sun.SC);gl.uniform3fv(uM.CP,E);gl.uniform3fv(uM.HZ,walk?mix3(sun.HZ,[.95,.93,.88],.65):sun.HZ);gl.uniform3fv(uM.ZN,walk?mix3(sun.ZN,[.93,.9,.85],.8):sun.ZN);gl.uniform1f(uM.SH,useSh?1:0);gl.uniform1f(uM.TS,1/SS);gl.uniform1f(uM.AM,walk?Math.min(.95,sun.AM+.2):sun.AM);gl.uniform1f(uM.FL,walk?.5:0);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.uniform1i(uM.SM,0);
  function bind(b){gl.bindBuffer(gl.ARRAY_BUFFER,b);attrs(4);gl.vertexAttribPointer(0,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(1,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(2,3,gl.FLOAT,false,40,24);gl.vertexAttribPointer(3,1,gl.FLOAT,false,40,36)}
  bind(buf);gl.drawArrays(gl.TRIANGLES,0,count);
   if(hcount){gl.depthFunc(gl.LEQUAL);gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(-1,-1);bind(hbuf);gl.drawArrays(gl.TRIANGLES,0,hcount);gl.disable(gl.POLYGON_OFFSET_FILL);gl.depthFunc(gl.LESS);bind(buf)}
  if(gcount){gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);bind(gbuf);gl.drawArrays(gl.TRIANGLES,0,gcount);gl.depthMask(true);gl.disable(gl.BLEND)}}
 function view(name){var cx=(bbx[0]+bbx[1])/2,cz=(bbx[2]+bbx[3])/2,r=Math.max(bbx[1]-bbx[0],bbx[3]-bbx[2],bbx[4]*1.25,3);cam.t=[cx,bbx[4]/3,cz];
  if(name==='top'){cam.el=1.5;cam.az=0;cam.dist=r*1.5+2}else if(name==='face'){cam.el=0.18;cam.az=0;cam.dist=r*1.6+3}else{cam.el=0.75;cam.az=0.7;cam.dist=r*1.35+3}draw()}
 function upload(S){prepWalk(S);var b=build(S);pk={data:b.data,tags:b.tags,tg:b.tg,gdata:b.glass,gtg:b.gtg};count=b.data.length/10;gcount=b.glass.length/10;bbx=b.bbox;builtExt=b.ext;gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,b.data,gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,gbuf);gl.bufferData(gl.ARRAY_BUFFER,b.glass,gl.STATIC_DRAW);shDirty=true}
 function set(S,refit){lastS=S;if(S&&S.r3d)opts=S.r3d;upload(S);applySel();if(refit)view('iso');else draw()}
 /* réglages (heure du soleil, extérieur, ombres) sans toucher au plan */
 function setOpts(o){var ext0=opts.ext!==false;opts=o||opts;if(lastS){var S=lastS;S.r3d=opts;if((opts.ext!==false)!==ext0)upload(S);applySel()}shDirty=true;draw()}
 /* ---- visite virtuelle : marche à hauteur d'yeux ---- */
 function wFwd(){var cp=Math.cos(walk.pitch);return[Math.sin(walk.yaw)*cp,Math.sin(walk.pitch),-Math.cos(walk.yaw)*cp]}
 function prepWalk(S){wd=(S.levels||[]).map(function(L){var segs=[],boxes=[],stairs=[];
  (L.walls||[]).forEach(function(wl){var P=wl.path,cum=[0],i;for(i=0;i<P.length-1;i++)cum.push(cum[i]+Math.hypot(P[i+1][0]-P[i][0],P[i+1][1]-P[i][1]));
   var sc=wl.len?cum[cum.length-1]/wl.len:1,gaps=(wl.ops||[]).filter(function(o){return o.kind==='porte'}).map(function(o){return[(o.pos-o.w/2)*sc,(o.pos+o.w/2)*sc]});
   for(i=0;i<P.length-1;i++){var a=P[i],b=P[i+1],sl=cum[i+1]-cum[i];if(sl<1e-4)continue;var iv=[[0,sl]],ux=(b[0]-a[0])/sl,uy=(b[1]-a[1])/sl;
    gaps.forEach(function(gp){var g0=gp[0]-cum[i],g1=gp[1]-cum[i];if(g1<=0||g0>=sl)return;var nv=[];iv.forEach(function(q){if(g1<=q[0]||g0>=q[1]){nv.push(q);return}if(g0>q[0])nv.push([q[0],g0]);if(g1<q[1])nv.push([g1,q[1]])});iv=nv});
    iv.forEach(function(q){if(q[1]-q[0]<.02)return;segs.push([a[0]+ux*q[0],a[1]+uy*q[0],a[0]+ux*q[1],a[1]+uy*q[1],wl.t/2])})}});
  (L.furn||[]).forEach(function(f){if(f.stair)stairs.push(f);else if(f.solid)boxes.push(f)});
  return{y0:L.y0,H:L.H,segs:segs,boxes:boxes,stairs:stairs}});
  (S.rails||[]).forEach(function(r){if(wd[r.lv])wd[r.lv].segs.push([r.x0,r.z0,r.x1,r.z1,.04])})}
 function fLocal(f,x,z){var ph=-(f.rot||0)*Math.PI/180,c=Math.cos(ph),s=Math.sin(ph),dx=x-f.x,dz=z-f.y;return[dx*c-dz*s,dx*s+dz*c]}
 function stairH(f,x,z){var l=fLocal(f,x,z),fx=l[0]/f.w+.5,fy=l[1]/f.d+.5,h=-1;if(fx<0||fx>1||fy<0||fy>1)return -1;
  (f.parts||[]).forEach(function(p){if(fx>=p[0]&&fx<=p[3]&&fy>=p[1]&&fy<=p[4])h=Math.max(h,p[5]*f.h)});return h}
 function wGround(lv,x,z){var Ld=wd[lv],g=Ld.y0;Ld.stairs.forEach(function(f){var h=stairH(f,x,z);if(h>=0)g=Math.max(g,Ld.y0+h)});
  if(lv>0){var Lb=wd[lv-1];Lb.stairs.forEach(function(f){var h=stairH(f,x,z);if(h>=0)g=Lb.y0+h})}return g}
 function wCollide(){var Ld=wd[walk.lv],R=.27,it,i,k;
  for(it=0;it<3;it++){
   for(i=0;i<Ld.segs.length;i++){var q=Ld.segs[i],dx=q[2]-q[0],dz=q[3]-q[1],l2=dx*dx+dz*dz,t=l2?((walk.x-q[0])*dx+(walk.z-q[1])*dz)/l2:0;t=Math.max(0,Math.min(1,t));
    var cx=q[0]+dx*t,cz=q[1]+dz*t,ex=walk.x-cx,ez=walk.z-cz,d=Math.hypot(ex,ez),rr=q[4]+R;
    if(d<rr){if(d<1e-6){var nl=Math.sqrt(l2)||1;ex=-dz/nl;ez=dx/nl;d=1}walk.x=cx+ex/d*rr;walk.z=cz+ez/d*rr}}
   for(k=0;k<Ld.boxes.length;k++){var f=Ld.boxes[k],l=fLocal(f,walk.x,walk.z),hx=f.w/2,hz=f.d/2,px=Math.max(-hx,Math.min(hx,l[0])),pz=Math.max(-hz,Math.min(hz,l[1])),ax=l[0]-px,az=l[1]-pz,dd=Math.hypot(ax,az);
    if(dd<R){var nx,nz;if(dd<1e-6){var ox=hx-Math.abs(l[0]),oz=hz-Math.abs(l[1]);if(ox<oz){nx=l[0]<0?-1:1;nz=0;dd=-ox}else{nx=0;nz=l[1]<0?-1:1;dd=-oz}}else{nx=ax/dd;nz=az/dd}
     var push=R-dd,ph=-(f.rot||0)*Math.PI/180,c=Math.cos(ph),s=Math.sin(ph),wx=nx*c+nz*s,wz=-nx*s+nz*c;walk.x+=wx*push;walk.z+=wz*push}}}}
 function wTick(ts){wRaf=0;if(!walk)return;var dt=Math.min(.05,(ts-wLast)/1000||.016);wLast=ts;
  var ix=wIn.x+((wKeys.d||wKeys.D)?1:0)-((wKeys.a||wKeys.A)?1:0),iy=wIn.y+((wKeys.w||wKeys.W||wKeys.ArrowUp)?1:0)-((wKeys.s||wKeys.S||wKeys.ArrowDown)?1:0);
  if(wKeys.ArrowLeft)walk.yaw-=1.7*dt;if(wKeys.ArrowRight)walk.yaw+=1.7*dt;
  var l=Math.hypot(ix,iy);if(l>1){ix/=l;iy/=l}
  if(l>.02){var sp=(wRun||wKeys.Shift)?3.4:1.6,fx=Math.sin(walk.yaw),fz=-Math.cos(walk.yaw),rx=Math.cos(walk.yaw),rz=Math.sin(walk.yaw);
   walk.x+=(fx*iy+rx*ix)*sp*dt;walk.z+=(fz*iy+rz*ix)*sp*dt;wCollide()}
  var cx=(bbx[0]+bbx[1])/2,cz=(bbx[2]+bbx[3])/2;walk.x=Math.max(cx-45,Math.min(cx+45,walk.x));walk.z=Math.max(cz-45,Math.min(cz+45,walk.z));
  var g=wGround(walk.lv,walk.x,walk.z);
  if(walk.lv>0&&g<wd[walk.lv].y0-.3){walk.lv--;g=wGround(walk.lv,walk.x,walk.z)}
  else if(walk.lv<wd.length-1&&g>=wd[walk.lv+1].y0-.12){walk.lv++;g=wGround(walk.lv,walk.x,walk.z)}
  walk.fy+=(g-walk.fy)*Math.min(1,dt*14);if(Math.abs(g-walk.fy)<.002)walk.fy=g;
  render();if(wHook)wHook(walk);wRaf=requestAnimationFrame(wTick)}
 function wKD(e){var t=e.target&&e.target.tagName;if(t==='INPUT'||t==='SELECT'||t==='TEXTAREA')return;if(/^(Arrow|[wasdWASD]$|Shift)/.test(e.key)){wKeys[e.key]=true;if(e.key.indexOf('Arrow')===0)e.preventDefault()}}
 function wKU(e){delete wKeys[e.key]}
 function walkStart(o){if(!wd||!wd.length)return false;var lv=Math.max(0,Math.min(wd.length-1,o.lv|0));walk={x:o.x,z:o.z,lv:lv,fy:wd[lv].y0,yaw:o.yaw||0,pitch:0};wIn={x:0,y:0};wKeys={};
  walk.fy=wGround(lv,walk.x,walk.z);wCollide();document.addEventListener('keydown',wKD);document.addEventListener('keyup',wKU);
  if(!wRaf){wLast=performance.now();wRaf=requestAnimationFrame(wTick)}return true}
 function walkStop(){walk=null;wIn={x:0,y:0};wKeys={};gyroOff();document.removeEventListener('keydown',wKD);document.removeEventListener('keyup',wKU);if(wRaf){cancelAnimationFrame(wRaf);wRaf=0}}
 function walkLevel(d){if(!walk)return;var nl=walk.lv+d;if(nl<0||nl>=wd.length)return;var ox=walk.x,oz=walk.z;walk.lv=nl;walk.fy=wd[nl].y0;wCollide();if(Math.hypot(walk.x-ox,walk.z-oz)>.6){walk.x=ox;walk.z=oz}}
 function gyroOff(){if(gyro){window.removeEventListener('deviceorientation',gyro.fn);gyro=null}}
 function walkGyro(on){gyroOff();if(!on||!walk)return Promise.resolve(false);
  function go(){gyro={a0:null,yaw0:0,fn:function(e){if(!walk||e.alpha==null)return;if(gyro.a0==null){gyro.a0=e.alpha;gyro.yaw0=walk.yaw}
   walk.yaw=gyro.yaw0-(e.alpha-gyro.a0)*Math.PI/180;if(e.beta!=null)walk.pitch=Math.max(-1.3,Math.min(1.3,(e.beta-90)*Math.PI/180))}};window.addEventListener('deviceorientation',gyro.fn);return true}
  try{if(window.DeviceOrientationEvent&&typeof DeviceOrientationEvent.requestPermission==='function')return DeviceOrientationEvent.requestPermission().then(function(r){return r==='granted'?go():false}).catch(function(){return false})}catch(e){}
  return Promise.resolve(go())}

 /* ---- sélection au toucher (lancer de rayon sur le maillage) ---- */
 function inv4(m){var i=new Array(16),d;
  i[0]=m[5]*m[10]*m[15]-m[5]*m[11]*m[14]-m[9]*m[6]*m[15]+m[9]*m[7]*m[14]+m[13]*m[6]*m[11]-m[13]*m[7]*m[10];
  i[4]=-m[4]*m[10]*m[15]+m[4]*m[11]*m[14]+m[8]*m[6]*m[15]-m[8]*m[7]*m[14]-m[12]*m[6]*m[11]+m[12]*m[7]*m[10];
  i[8]=m[4]*m[9]*m[15]-m[4]*m[11]*m[13]-m[8]*m[5]*m[15]+m[8]*m[7]*m[13]+m[12]*m[5]*m[11]-m[12]*m[7]*m[9];
  i[12]=-m[4]*m[9]*m[14]+m[4]*m[10]*m[13]+m[8]*m[5]*m[14]-m[8]*m[6]*m[13]-m[12]*m[5]*m[10]+m[12]*m[6]*m[9];
  i[1]=-m[1]*m[10]*m[15]+m[1]*m[11]*m[14]+m[9]*m[2]*m[15]-m[9]*m[3]*m[14]-m[13]*m[2]*m[11]+m[13]*m[3]*m[10];
  i[5]=m[0]*m[10]*m[15]-m[0]*m[11]*m[14]-m[8]*m[2]*m[15]+m[8]*m[3]*m[14]+m[12]*m[2]*m[11]-m[12]*m[3]*m[10];
  i[9]=-m[0]*m[9]*m[15]+m[0]*m[11]*m[13]+m[8]*m[1]*m[15]-m[8]*m[3]*m[13]-m[12]*m[1]*m[11]+m[12]*m[3]*m[9];
  i[13]=m[0]*m[9]*m[14]-m[0]*m[10]*m[13]-m[8]*m[1]*m[14]+m[8]*m[2]*m[13]+m[12]*m[1]*m[10]-m[12]*m[2]*m[9];
  i[2]=m[1]*m[6]*m[15]-m[1]*m[7]*m[14]-m[5]*m[2]*m[15]+m[5]*m[3]*m[14]+m[13]*m[2]*m[7]-m[13]*m[3]*m[6];
  i[6]=-m[0]*m[6]*m[15]+m[0]*m[7]*m[14]+m[4]*m[2]*m[15]-m[4]*m[3]*m[14]-m[12]*m[2]*m[7]+m[12]*m[3]*m[6];
  i[10]=m[0]*m[5]*m[15]-m[0]*m[7]*m[13]-m[4]*m[1]*m[15]+m[4]*m[3]*m[13]+m[12]*m[1]*m[7]-m[12]*m[3]*m[5];
  i[14]=-m[0]*m[5]*m[14]+m[0]*m[6]*m[13]+m[4]*m[1]*m[14]-m[4]*m[2]*m[13]-m[12]*m[1]*m[6]+m[12]*m[2]*m[5];
  i[3]=-m[1]*m[6]*m[11]+m[1]*m[7]*m[10]+m[5]*m[2]*m[11]-m[5]*m[3]*m[10]-m[9]*m[2]*m[7]+m[9]*m[3]*m[6];
  i[7]=m[0]*m[6]*m[11]-m[0]*m[7]*m[10]-m[4]*m[2]*m[11]+m[4]*m[3]*m[10]+m[8]*m[2]*m[7]-m[8]*m[3]*m[6];
  i[11]=-m[0]*m[5]*m[11]+m[0]*m[7]*m[9]+m[4]*m[1]*m[11]-m[4]*m[3]*m[9]-m[8]*m[1]*m[7]+m[8]*m[3]*m[5];
  i[15]=m[0]*m[5]*m[10]-m[0]*m[6]*m[9]-m[4]*m[1]*m[10]+m[4]*m[2]*m[9]+m[8]*m[1]*m[6]-m[8]*m[2]*m[5];
  d=m[0]*i[0]+m[1]*i[4]+m[2]*i[8]+m[3]*i[12];if(Math.abs(d)<1e-14)return null;d=1/d;for(var k=0;k<16;k++)i[k]*=d;return i}
 function unp(I,x,y,z){var o=[0,0,0,0],r,c,v=[x,y,z,1];for(r=0;r<4;r++)for(c=0;c<4;c++)o[r]+=I[c*4+r]*v[c];return[o[0]/o[3],o[1]/o[3],o[2]/o[3]]}
 /* rayon (monde) passant par le pixel (px,py) ; tir sur les triangles opaques ET le vitrage ; renvoie {i:indice d'étiquette, t:distance, p:point touché} */
 function rayOf(I,px,py,r){var A=unp(I,2*px/r.width-1,1-2*py/r.height,-1),B=unp(I,2*px/r.width-1,1-2*py/r.height,1),dx=B[0]-A[0],dy=B[1]-A[1],dz=B[2]-A[2],l=Math.hypot(dx,dy,dz)||1;return{A:A,d:[dx/l,dy/l,dz/l]}}
 function cast(R){var A=R.A,dx=R.d[0],dy=R.d[1],dz=R.d[2],best=1e30,bt=-1;
  function scan(d,tg){if(!d||!tg)return;var n=d.length/10,i;
   for(i=0;i+2<n;i+=3){var o0=i*10,o1=o0+10,o2=o0+20,e1x=d[o1]-d[o0],e1y=d[o1+1]-d[o0+1],e1z=d[o1+2]-d[o0+2],e2x=d[o2]-d[o0],e2y=d[o2+1]-d[o0+1],e2z=d[o2+2]-d[o0+2],
    hx=dy*e2z-dz*e2y,hy=dz*e2x-dx*e2z,hz=dx*e2y-dy*e2x,det=e1x*hx+e1y*hy+e1z*hz;if(det>-1e-12&&det<1e-12)continue;
    var f=1/det,sx=A[0]-d[o0],sy=A[1]-d[o0+1],sz=A[2]-d[o0+2],u=(sx*hx+sy*hy+sz*hz)*f;if(u<0||u>1)continue;
    var qx=sy*e1z-sz*e1y,qy=sz*e1x-sx*e1z,qz=sx*e1y-sy*e1x,vv=(dx*qx+dy*qy+dz*qz)*f;if(vv<0||u+vv>1)continue;
    var t=(e2x*qx+e2y*qy+e2z*qz)*f;if(t>1e-4&&t<best){best=t;bt=tg[i]}}}
  scan(pk.data,pk.tg);scan(pk.gdata,pk.gtg);
  return{i:bt,t:best,p:bt>=0?[A[0]+dx*best,A[1]+dy*best,A[2]+dz*best]:null}}
 /* étiquette de l'objet touché en (px,py) pixels CSS du canevas, ou null (ciel, rien). Le vitrage et les sols (pièces) sont touchables */
 function pickHit(px,py){if(!pk||!lastMat||walk||!pk.tg)return null;var r=canvas.getBoundingClientRect();if(!r.width||!r.height)return null;
  var I=inv4(lastMat);if(!I)return null;var h=cast(rayOf(I,px,py,r));return{tag:h.i>=0?pk.tags[h.i]:null,p:h.p}}
 function pick(px,py){var h=pickHit(px,py);return h?h.tag:null}
 /* rayon monde (pour déplacer un objet sur un plan horizontal) */
 function ray(px,py){if(!lastMat)return null;var r=canvas.getBoundingClientRect();if(!r.width||!r.height)return null;var I=inv4(lastMat);if(!I)return null;var R=rayOf(I,px,py,r);return{o:R.A,d:R.d}}
 /* sélection par fenêtre (pixels CSS du canevas). Ne retient que les objets VISIBLES (tir de rayons) ; crossing=false : entièrement dans le cadre ; true : touchés par le cadre */
 function pickRect(x0,y0,x1,y1,crossing){
  if(!pk||!lastMat||!pk.tg)return[];var r=canvas.getBoundingClientRect();if(!r.width||!r.height)return[];var I=inv4(lastMat);if(!I)return[];
  var M=lastMat,W=r.width,H=r.height,xl=Math.min(x0,x1),xr=Math.max(x0,x1),yt=Math.min(y0,y1),yb=Math.max(y0,y1),bb={},keys=pk.tags.map(function(t){return t&&t.id!=null?t.t+':'+t.id:null});
  function scr(d,i){var x=d[i*10],y=d[i*10+1],z=d[i*10+2],cw=M[3]*x+M[7]*y+M[11]*z+M[15];if(cw<=0.001)return null;return[((M[0]*x+M[4]*y+M[8]*z+M[12])/cw+1)/2*W,(1-(M[1]*x+M[5]*y+M[9]*z+M[13])/cw)/2*H]}
  function add(d,tg){if(!d||!tg)return;var n=d.length/10,i;
   for(i=0;i+2<n;i+=3){var ti=tg[i];if(ti<0||!keys[ti])continue;var b=bb[keys[ti]]||(bb[keys[ti]]={tag:pk.tags[ti],x0:1e9,y0:1e9,x1:-1e9,y1:-1e9,out:false,n:0,cs:[],c:0}),a=scr(d,i),c=scr(d,i+1),e=scr(d,i+2);
    if(!a||!c||!e){b.out=true;continue}
    [a,c,e].forEach(function(q){if(q[0]<b.x0)b.x0=q[0];if(q[0]>b.x1)b.x1=q[0];if(q[1]<b.y0)b.y0=q[1];if(q[1]>b.y1)b.y1=q[1]});b.n++;
    var cx=(a[0]+c[0]+e[0])/3,cy=(a[1]+c[1]+e[1])/3;if(cx>=xl&&cx<=xr&&cy>=yt&&cy<=yb&&(b.c<6||b.c%11===0)&&b.cs.length<24)b.cs.push([cx,cy]);if(cx>=xl&&cx<=xr&&cy>=yt&&cy<=yb)b.c++}}
  add(pk.data,pk.tg);add(pk.gdata,pk.gtg);
  var vis={};function shoot(px,py){var h=cast(rayOf(I,px,py,r));if(h.i>=0&&keys[h.i])vis[keys[h.i]]=1}
  var st=Math.max(4,Math.sqrt(Math.max(1,(xr-xl)*(yb-yt))/700)),gx,gy;for(gy=yt+st/2;gy<yb;gy+=st)for(gx=xl+st/2;gx<xr;gx+=st)shoot(gx,gy);
  Object.keys(bb).forEach(function(k){bb[k].cs.forEach(function(q){shoot(q[0],q[1])})});
  var out=[];Object.keys(bb).forEach(function(k){var b=bb[k];if(!b.n||!vis[k])return;var t=b.tag,inside=!b.out&&b.x0>=xl&&b.x1<=xr&&b.y0>=yt&&b.y1<=yb;
   if(crossing||inside)out.push({t:t.t,id:t.id,lv:t.lv})});
  return out}
 /* surbrillance : recopie les triangles des objets choisis avec une teinte bleue, redessinés par-dessus */
 function applySel(){hcount=0;if(pk&&pk.tg&&selKeys&&selKeys.length){var ok={},out=[],d=pk.data,tg=pk.tg,tags=pk.tags,n=d.length/10,i,j,mark;
   selKeys.forEach(function(k){ok[k.t+':'+k.id]=1});mark=tags.map(function(t){return !!ok[t.t+':'+t.id]});
   for(i=0;i+2<n;i+=3){var ti=tg[i];if(ti<0||!mark[ti])continue;for(j=0;j<3;j++){var o=(i+j)*10;out.push(d[o],d[o+1],d[o+2],d[o+3],d[o+4],d[o+5],d[o+6]*.35+.08,d[o+7]*.35+.29,d[o+8]*.35+.65,d[o+9])}}
   hcount=out.length/10;gl.bindBuffer(gl.ARRAY_BUFFER,hbuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(out),gl.STATIC_DRAW)}
  draw()}
 /* commandes */
 function pan(dx,dy){var k=cam.dist*0.0016,rx=Math.cos(cam.az),rz=-Math.sin(cam.az),fx=-Math.sin(cam.az),fz=-Math.cos(cam.az);cam.t[0]+=-dx*k*rx+dy*k*fx;cam.t[2]+=-dx*k*rz+dy*k*fz;draw()}
 function P(e){var r=canvas.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]}
 canvas.addEventListener('pointerdown',function(e){if(busy)return;try{canvas.setPointerCapture(e.pointerId)}catch(_){}var p=P(e);ptrs[e.pointerId]={x:p[0],y:p[1],sx:p[0],sy:p[1],t:performance.now(),b:e.button,sh:e.shiftKey};if(Object.keys(ptrs).length>1){Object.keys(ptrs).forEach(function(k){ptrs[k].multi=true;ptrs[k].mq=false;if(ptrs[k].dg){ptrs[k].dg=false;if(dgHook)dgHook.cancel()}});if(mqS){mqS=null;if(mqHook&&mqHook.cancel)mqHook.cancel()}}
  else if(mqHook&&!walk&&e.button===0&&mqHook.want(e)){ptrs[e.pointerId].mq=true;mqS={x0:p[0],y0:p[1],x1:p[0],y1:p[1],cx0:e.clientX,cy0:e.clientY,cx1:e.clientX,cy1:e.clientY};mqHook.move(mqS,e)}
  else if(dgHook&&!walk&&e.button===0&&!e.shiftKey&&dgHook.want(p[0],p[1],e)){ptrs[e.pointerId].dg=true;dgMoved=false}
  last=null});
 canvas.addEventListener('pointermove',function(e){var q=ptrs[e.pointerId];if(!q||busy)return;var p=P(e),ids=Object.keys(ptrs);
  if(q.dg){if(!dgMoved&&Math.hypot(p[0]-q.sx,p[1]-q.sy)<6)return;dgMoved=true;dgHook.move(p[0],p[1],e);return}
  if(q.mq&&mqS){mqS.x1=p[0];mqS.y1=p[1];mqS.cx1=e.clientX;mqS.cy1=e.clientY;mqHook.move(mqS,e);return}
  if(walk){var ddx=p[0]-q.x,ddy=p[1]-q.y;q.x=p[0];q.y=p[1];var k=.0052;walk.yaw+=ddx*k;walk.pitch=Math.max(-1.3,Math.min(1.3,walk.pitch-ddy*k*.8));if(gyro){gyro.yaw0+=ddx*k}return}
  if(ids.length>=2){var o=ptrs[ids[0]]===q?ptrs[ids[1]]:ptrs[ids[0]],d0=Math.hypot(q.x-o.x,q.y-o.y),mx0=(q.x+o.x)/2,my0=(q.y+o.y)/2;q.x=p[0];q.y=p[1];var d1=Math.hypot(q.x-o.x,q.y-o.y),mx1=(q.x+o.x)/2,my1=(q.y+o.y)/2;
   if(d0>0&&d1>0)cam.dist=Math.max(1.5,Math.min(250,cam.dist*d0/d1));pan(mx1-mx0,my1-my0);return}
  var dx=p[0]-q.x,dy=p[1]-q.y;q.x=p[0];q.y=p[1];
  if(q.b===2||q.sh)pan(dx,dy);else{cam.az-=dx*0.008;cam.el=Math.max(0.04,Math.min(1.55,cam.el+dy*0.008));draw()}});
 function up(e){var q=ptrs[e.pointerId];if(q&&q.dg){var mv=dgMoved;dgMoved=false;delete ptrs[e.pointerId];if(dgHook){if(e.type==='pointerup'){dgHook.end(mv);if(!mv&&pickHook)pickHook(pick(q.sx,q.sy),{shift:false,ctrl:false,alt:false,x:q.sx,y:q.sy})}else dgHook.cancel()}return}
  if(q&&q.mq){var ms=mqS;mqS=null;delete ptrs[e.pointerId];if(ms&&mqHook){if(e.type==='pointerup')mqHook.end(ms,e);else if(mqHook.cancel)mqHook.cancel()}return}
  if(q&&e.type==='pointerup'&&q.b===0&&!q.multi&&pickHook&&!walk&&!busy&&Object.keys(ptrs).length===1&&Math.hypot(q.x-q.sx,q.y-q.sy)<8&&performance.now()-q.t<700){pickHook(pick(q.sx,q.sy),{shift:!!(q.sh||e.shiftKey),ctrl:!!(e.ctrlKey||e.metaKey),alt:!!e.altKey,x:q.sx,y:q.sy})}delete ptrs[e.pointerId]}
 canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);canvas.addEventListener('contextmenu',function(e){e.preventDefault()});
 canvas.addEventListener('wheel',function(e){e.preventDefault();if(busy||walk)return;cam.dist=Math.max(1.5,Math.min(250,cam.dist*(e.deltaY>0?1.12:1/1.12)));draw()},{passive:false});

 /* ---- V4.6 : rendu haute résolution et vidéo tournante ---- */
 function maxDim(){var d=gl.getParameter(gl.MAX_VIEWPORT_DIMS)||[4096,4096],q=gl.getParameter(gl.MAX_RENDERBUFFER_SIZE)||4096;return Math.max(512,Math.min(d[0],d[1],q))}
 /* dessine la vue courante en W×H (réduit si l'appareil ne sait pas) et renvoie un canvas 2D {canvas,w,h} ; canvas=null si l'appareil refuse */
 function capture(W,H){if(busy||gl.isContextLost())return{canvas:null,w:0,h:0};
  var ow=canvas.width,oh=canvas.height,mx=maxDim(),k=Math.min(1,mx/W,mx/H),out=null;W=Math.round(W*k);H=Math.round(H*k);
  try{canvas.width=W;canvas.height=H;render();out=document.createElement('canvas');out.width=W;out.height=H;var c=out.getContext('2d');if(!c)throw 0;c.drawImage(canvas,0,0);if(gl.getError()===gl.OUT_OF_MEMORY)out=null}catch(e){out=null}
  canvas.width=ow;canvas.height=oh;draw();return{canvas:out,w:W,h:H}}
 /* tour complet autour du bâtiment, enregistré en vidéo (MediaRecorder). done(blob|null, message) */
 function turntable(o,onProg,done){o=o||{};
  if(busy){done(null,'Un enregistrement est déjà en cours.');return}
  if(!canvas.captureStream||typeof MediaRecorder==='undefined'){done(null,'L’enregistrement vidéo n’est pas disponible sur cet appareil ou ce navigateur.');return}
  var ow=canvas.width,oh=canvas.height,mx=maxDim(),W=Math.min(o.w||1280,mx),H=Math.min(o.h||720,mx),sec=o.sec||8,fps=o.fps||30,az0=cam.az,t0=0,chunks=[],rec=null,st=null,mt='';
  ['video/mp4;codecs=avc1','video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].some(function(t){try{if(MediaRecorder.isTypeSupported(t)){mt=t;return true}}catch(e){}return false});
  function restore(){busy=false;cam.az=az0;canvas.width=ow;canvas.height=oh;canvas.style.objectFit='';draw()}
  busy=true;canvas.width=W;canvas.height=H;canvas.style.objectFit='contain';
  try{st=canvas.captureStream(fps);rec=new MediaRecorder(st,mt?{mimeType:mt,videoBitsPerSecond:8000000}:{videoBitsPerSecond:8000000})}catch(e){restore();done(null,'Impossible de démarrer l’enregistrement vidéo.');return}
  var recErr='';rec.onerror=function(e){recErr=String((e&&e.error&&e.error.message)||'')};rec.ondataavailable=function(e){if(e.data&&e.data.size)chunks.push(e.data)};
  rec.onstop=function(){try{st.getTracks().forEach(function(t){t.stop()})}catch(e){}restore();var ty=String(rec.mimeType||mt||'video/webm').split(';')[0];done(chunks.length?new Blob(chunks,{type:ty}):null,chunks.length?'':'La vidéo est vide : l’appareil n’a fourni aucune image'+(recErr?' ('+recErr+')':'')+'.')};
  function frame(ts){if(!t0)t0=ts;var p=Math.min(1,(ts-t0)/(sec*1000));cam.az=az0+2*Math.PI*p;render();try{gl.finish()}catch(e){}if(onProg)onProg(p);if(p>=1){try{rec.stop()}catch(e){restore();done(null,'Arrêt de l’enregistrement impossible.')}return}requestAnimationFrame(frame)}
  try{rec.start(250)}catch(e){restore();done(null,'Impossible de démarrer l’enregistrement vidéo.');return}
  requestAnimationFrame(frame)}
 return{pick:pick,pickHit:pickHit,ray:ray,drag:function(h){dgHook=h||null},pickRect:pickRect,marquee:function(h){mqHook=h||null},select:function(a){selKeys=a||null;applySel()},onPick:function(fn){pickHook=fn},set:set,setOpts:setOpts,view:view,resize:resize,render:render,capture:capture,turntable:turntable,busy:function(){return busy},_cam:cam,shadows:function(){return shOK},
  walkStart:walkStart,walkStop:walkStop,walkOn:function(){return !!walk},walkInput:function(x,y){wIn={x:x||0,y:y||0}},walkRun:function(b){wRun=!!b},walkLevel:walkLevel,walkGyro:walkGyro,walkLook:function(dy,dp){if(walk){walk.yaw+=dy;walk.pitch=Math.max(-1.3,Math.min(1.3,walk.pitch+dp))}},
  walkPos:function(){return walk?{x:walk.x,z:walk.z,lv:walk.lv,yaw:walk.yaw}:null},onWalk:function(fn){wHook=fn},_walk:function(){return walk}}}
w.EXB3D={create:create,_earclip:earclip,_build:build};
})(window);
