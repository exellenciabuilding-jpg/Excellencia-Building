/* Excellencia Building V99t — Notes de calcul de structure : même présentation que les documents clients du logiciel.
 * - en-tête marine + filet doré (logo, nom, slogan, coordonnées, mentions légales) repris de l'identité unique EXBId ;
 * - fiche à remplir avant impression (client, projet, lieu, ingénieur, vérificateur, indice, n°, date, brouillon) ;
 * - numéro automatique NCS-AAAA-NNN (un même calcul garde le même numéro) ;
 * - QR de vérification public (verification.html) + code, publié au registre à l'impression (administrateur connecté) ;
 * - signature + cachet de l'administrateur (EXBSign), filigrane BROUILLON, pied de page sur chaque page.
 * Ce module ne modifie aucun calcul : il habille seulement l'aperçu ouvert par openDoc() et s'appuie sur les modules
 * du logiciel central via window.parent (même origine). Hors du logiciel (page ouverte seule) : mise en page identique,
 * sans QR ni signature. Retrait : supprimer la balise <script src="exb-calcul-doc.js"> de calcul-structure/index.html. */
(function (w, d) {
  'use strict';
  var NAVY = '#173565', GOLD = '#c49a38', SOFT = '#f0f4fa', LINE = '#cfd6e2', GREY = '#667085';
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  /* ---------- accès au logiciel central (si la page est affichée dedans) ---------- */
  function ext(n) { try { var p = w.parent; return p && p !== w && p[n] ? p[n] : null; } catch (e) { return null; } }
  /* V99zzf : enregistrement des validations CÔTÉ SERVEUR (supabase/migration-v99zzf-validation-ingenieur.sql).
   * Connecté à une entreprise : l'identité de l'ingénieur vient du compte, la date du serveur, le journal est en ajout seul.
   * Non connecté : repli local, signalé « non probant » partout (page de garde, visas, QR, journal). */
  function srv() {
    try {
      var sb = ext('exbSb'), dbx = ext('EXBDB'), org = dbx && dbx.org ? dbx.org() : null;
      if (sb && sb.api && sb.isIn && sb.isIn() && org) return { org: org, call: function (fn, args) { return sb.api('/rest/v1/rpc/' + fn, { method: 'POST', body: JSON.stringify(args) }); } };
    } catch (e) {}
    return null;
  }
  var REFUS = {
    connexion_requise: 'Connexion requise.', mfa_requise: 'Connectez-vous avec la double authentification (code à 6 chiffres).',
    session_2fa_requise: 'Valider exige une session avec double authentification : reconnectez-vous avec votre code à 6 chiffres.',
    ingenieur_habilite_requis: 'Votre compte n’est pas désigné « ingénieur habilité ». L’administrateur doit vous habiliter (Équipe › Ingénieur habilité).',
    declaration_requise: 'Cochez la déclaration de responsabilité.', commentaire_requis: 'Indiquez les réserves ou le motif du refus.',
    non_membre: 'Vous n’êtes pas membre de cette entreprise.', ecriture_interdite: 'Votre rôle (lecteur) ne permet pas d’enregistrer.',
    licence: 'Licence suspendue ou expirée : enregistrement impossible (lecture seule).', statut_invalide: 'Statut invalide.', donnees_invalides: 'Données incomplètes (numéro, empreinte).',
    non_autorise: 'Non autorisé.', validation_serveur_absente: 'Ce statut n’est pas enregistré sur le serveur pour cette version : enregistrez d’abord la validation.'
  };
  function ident(ctx) {
    var I = null, X = ext('EXBId');
    try { I = X ? X.get() : null; } catch (e) {}
    var p = ctx.pi();
    I = I || { name: p.bureau || 'Excellencia Building', tagline: 'Ingénierie & Construction', phone: '', email: '', address: '', country: '', logo: '', legal: '', city: '' };
    var logo = I.logo || '';
    if (logo && !/^(data:|https?:|\.\.\/|\/)/i.test(logo)) logo = '../' + logo;
    var o = {
      name: I.name, tagline: I.tagline, logo: logo, city: I.city || '', phone: I.phone || '', email: I.email || '', address: I.address || '',
      contact: '', place: '', legal: ''
    };
    try { o.contact = X ? X.contactLine(I) : ''; o.place = X ? X.placeLine(I) : ''; o.legal = X ? X.legalLine(I) : ''; } catch (e) {}
    return o;
  }

  /* ---------- petits outils ---------- */
  function today() { var t = new Date(), z = function (n) { return (n < 10 ? '0' : '') + n; }; return t.getFullYear() + '-' + z(t.getMonth() + 1) + '-' + z(t.getDate()); }
  function frDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function hash32(s) { var h = 5381, i; s = String(s); for (i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }

  /* ---------- feuille de style (aperçu + impression) ---------- */
  function css() {
    if (d.getElementById('exbCalcDocCss')) return;
    var s = d.createElement('style'); s.id = 'exbCalcDocCss';
    s.textContent =
      '#doc{-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
      '#doc .exf{background:#fff;border:1px solid ' + LINE + ';border-radius:12px;padding:12px;margin:10px 0;font-family:Arial,sans-serif;color:#172033}' +
      '#doc .exf h3{margin:0 0 4px;font-size:14px;color:' + NAVY + '}#doc .exf p{margin:0 0 8px;font-size:12px;color:' + GREY + '}' +
      '#doc .exf .g{display:grid;grid-template-columns:1fr 1fr;gap:8px}#doc .exf label{display:block;font:700 11px Arial;color:' + NAVY + '}' +
      '#doc .exf input[type=text],#doc .exf input[type=date]{width:100%;box-sizing:border-box;margin-top:3px;padding:9px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial}' +
      '#doc .exf .ck{display:flex;align-items:center;gap:8px;margin-top:8px;font:700 13px Arial}#doc .exf .ck input{width:18px;height:18px}' +
      '#doc .exf .st{margin-top:8px;font-size:12px;color:' + GREY + '}' +
      '@media(max-width:560px){#doc .exf .g{grid-template-columns:1fr}}' +
      '#doc .exv{background:#fff;border:1px solid ' + LINE + ';border-left:4px solid ' + GOLD + ';border-radius:12px;padding:12px;margin:10px 0;font-family:Arial,sans-serif;color:#172033}' +
      '#doc .exv h3{margin:0 0 4px;font-size:14px;color:' + NAVY + '}#doc .exv p{margin:0 0 8px;font-size:12px;color:' + GREY + '}' +
      '#doc .exv .g{display:grid;grid-template-columns:1fr 1fr;gap:8px}#doc .exv label{display:block;font:700 11px Arial;color:' + NAVY + '}#doc .exv .w{grid-column:1/-1}' +
      '#doc .exv input[type=text],#doc .exv select{width:100%;box-sizing:border-box;margin-top:3px;padding:9px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial;background:#fff}' +
      '#doc .exv .ck{display:flex;align-items:flex-start;gap:8px;margin-top:10px;font:600 12px Arial;color:#172033}#doc .exv .ck input{width:18px;height:18px;flex:none;margin-top:1px}' +
      '#doc .exv .cach{display:flex;align-items:center;gap:10px;margin-top:8px;flex-wrap:wrap}#doc .exv .cach img{max-height:64px;max-width:140px;border:1px dashed #cbd5e1;border-radius:6px;padding:3px;background:#fff}' +
      '#doc .exv button{border:0;border-radius:8px;padding:10px 14px;font:700 13px Arial;cursor:pointer;background:#e8eef9;color:' + NAVY + '}#doc .exv button.p{background:' + NAVY + ';color:#fff}' +
      '#doc .exv .msg{margin-top:8px;font:700 12px Arial}#doc .exv .msg.ko{color:#b91c1c}#doc .exv .msg.ok{color:#166534}#doc .exv .msg.wn{color:#92400e}' +
      '#doc .exv table{width:100%;border-collapse:collapse;margin-top:8px;font-size:11.5px}#doc .exv th{background:' + SOFT + ';color:' + NAVY + ';text-align:left;padding:5px 6px;border:1px solid ' + LINE + '}#doc .exv td{padding:5px 6px;border:1px solid ' + LINE + ';vertical-align:top}#doc .exv tr.cur td{background:#f0fdf4}' +
      '@media(max-width:560px){#doc .exv .g{grid-template-columns:1fr}}' +
      /* page de garde */
      '#doc .ex-cv{padding:56px 58px 38px!important;overflow:hidden;position:relative;box-sizing:border-box;background:#fff;border:9px solid ' + NAVY + '}' +
      '#doc .ex-cv:before{content:"";position:absolute;inset:4px;border:2.5px solid ' + GOLD + ';pointer-events:none}' +
      '#doc .ex-cv:after{content:"";position:absolute;inset:11px;border:8px solid rgba(196,154,56,.30);pointer-events:none}' +
      '#doc .ex-fin{position:absolute;inset:31px;border:1px solid ' + GOLD + ';pointer-events:none;box-shadow:inset 0 0 0 2px #fff,inset 0 0 0 2.4px rgba(196,154,56,.45)}' +
      '#doc .ex-c{position:relative;z-index:1;display:flex;flex-direction:column;align-items:stretch;text-align:center;color:#172033;min-height:100%}' +
      '#doc .ex-nm{font:800 24px Arial,sans-serif;letter-spacing:2px;color:' + NAVY + '}#doc .ex-tg{font:italic 12px Georgia,serif;color:' + GREY + ';margin-top:4px}' +
      '#doc .ex-rule{width:140px;height:1.5px;background:' + GOLD + ';margin:10px auto 14px}' +
      '#doc .ex-lg{height:150px;display:flex;align-items:center;justify-content:center;margin-bottom:12px}#doc .ex-lg img{max-height:150px;max-width:230px;object-fit:contain}' +
      '#doc .ex-t1{margin:6px 0 0;font:900 34px Arial,sans-serif;letter-spacing:7px;color:' + NAVY + '}#doc .ex-no{font:800 13px Arial;letter-spacing:1px;color:' + GOLD + ';margin-top:6px}' +
      '#doc .ex-rule2{width:220px;height:1px;background:' + GOLD + ';margin:12px auto}' +
      '#doc .ex-lb{font:800 8.5px Arial;letter-spacing:2.5px;color:' + GOLD + ';margin:10px 0 4px}' +
      '#doc .ex-obj2{margin:0;font:800 17px Arial;color:' + NAVY + ';line-height:1.25}' +
      '#doc .ex-cl{font-size:12.5px;line-height:1.5}#doc .ex-cl b{display:block;font-size:14px;color:' + NAVY + '}' +
      '#doc .ex-rf{font-size:11.5px;line-height:1.5;color:#3b4557;margin-top:6px}#doc .ex-rf em{font-style:normal;color:' + GREY + '}' +
      '#doc .ex-c .ex-som{columns:2;column-gap:18px;margin:4px 0 0;padding:0;list-style:none;font-size:11px;text-align:left}#doc .ex-c .ex-som li{display:flex;gap:6px;padding:1px 0}#doc .ex-c .ex-som li span{flex:1}#doc .ex-c .ex-som li i{font-style:normal;color:' + GREY + '}' +
      '#doc .ex-bt{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-top:auto;padding-top:14px}' +
      '#doc .ex-dl{text-align:right;font:italic 12px Arial;color:#172033;margin-bottom:8px}' +
      '#doc .ex-s1{width:230px;text-align:center;font-size:11px;position:relative}#doc .ex-s1 .z{height:84px;border-bottom:1px solid ' + NAVY + ';position:relative}' +
      '#doc .ex-s1 .z img{position:absolute;left:50%;bottom:-20px;transform:translateX(-50%);max-width:100%;max-height:92px;z-index:0}' +
      '#doc .ex-s1 b,#doc .ex-s1 span{position:relative;z-index:1;display:block}#doc .ex-s1 b{color:' + NAVY + ';margin-top:6px;font-size:10.5px}#doc .ex-s1 span{font-weight:700;margin-top:2px;min-height:14px}' +
      '#doc .ex-q1{text-align:center;font-size:9px;color:' + GREY + ';width:104px}#doc .ex-q1 img{width:92px;height:92px;image-rendering:pixelated;display:block;margin:0 auto 3px}#doc .ex-q1 b{color:' + NAVY + ';display:block}' +
      '#doc .ex-band{display:flex;gap:12px;align-items:center;background:' + NAVY + ';color:#fff;padding:14px 16px}' +
      '#doc .ex-logo{flex:none;width:64px;height:64px;background:#fff;border-radius:6px;display:flex;align-items:center;justify-content:center}' +
      '#doc .ex-logo img{max-width:58px;max-height:58px}' +
      '#doc .ex-id{flex:1;min-width:0}#doc .ex-id b{display:block;font-size:17px;letter-spacing:.3px}#doc .ex-id span{display:block;font-size:10.5px;color:#cfd9ec;margin-top:2px}#doc .ex-id i{display:block;font-size:9px;color:#b4c3dc;margin-top:3px;font-style:normal}' +
      '#doc .ex-ttl{text-align:right;flex:none}#doc .ex-ttl h1{margin:0;font-size:21px;color:#fff;letter-spacing:.5px}#doc .ex-ttl b{display:block;color:#f2d36a;font-size:12px;margin-top:3px}#doc .ex-ttl span{display:block;font-size:10.5px;color:#e5ebf6;margin-top:1px}' +
      '#doc .ex-gold{height:4px;background:' + GOLD + '}' +
      '#doc .ex-body{padding:14px 16px 16px;color:#172033}' +
      '#doc .ex-obj{margin:0 0 12px;font-size:13px;font-weight:700;color:' + NAVY + ';border-bottom:1.5px solid ' + GOLD + ';padding-bottom:4px}' +
      '#doc .ex-boxes{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}' +
      '#doc .ex-box{border:1px solid ' + LINE + ';border-radius:4px;font-size:13px}#doc .ex-box>b{display:block;background:' + SOFT + ';color:' + NAVY + ';font-size:12px;padding:5px 8px;letter-spacing:.4px}' +
      '#doc .ex-box>div{padding:6px 8px;line-height:1.55}#doc .ex-box em{font-style:normal;color:' + GREY + '}' +
      '#doc .ex-wide{margin-bottom:12px}' +
      '#doc .ex-fait{font-size:12px;color:' + GREY + ';margin:14px 0 6px}' +
      '#doc .ex-sig{display:grid;grid-template-columns:1fr 1fr 118px;gap:14px;align-items:end}' +
      '#doc .ex-sg{text-align:center;font-size:12.5px}#doc .ex-sg .z{height:78px;border-bottom:1px solid #8a93a5;display:flex;align-items:flex-end;justify-content:center}#doc .ex-sg .z img{max-width:100%;max-height:74px;position:relative;z-index:0;transform:translateY(38px)}#doc .ex-sg b,#doc .ex-sg span{position:relative;z-index:1}' +
      '#doc .ex-sg b{display:block;color:' + NAVY + ';margin-top:5px}#doc .ex-sg span{display:block;color:#172033;font-weight:700;margin-top:2px;min-height:14px}' +
      '#doc .ex-qr{text-align:center;font-size:9px;color:' + GREY + '}#doc .ex-qr img{width:104px;height:104px;image-rendering:pixelated;display:block;margin:0 auto 3px}#doc .ex-qr b{color:' + NAVY + ';display:block}' +
      '#doc .ex-note{margin-top:14px;font-size:11.5px;color:' + GREY + ';border-top:1px solid ' + LINE + ';padding-top:6px}' +
      /* entête des pages de calcul */
      '#doc .hd{background:' + NAVY + ';color:#fff;border-bottom:3px solid ' + GOLD + ';padding:7px 10px;align-items:center;font-size:12.5px}' +
      '#doc .hd b{color:#fff;font-size:14px}#doc .hd span{color:#e5ebf6}#doc .hd img.exl{width:22px;height:22px;background:#fff;border-radius:4px;padding:1px;margin-right:6px;vertical-align:middle}' +
      /* finition des pages de calcul */
      '#doc .pg{font-family:Arial,Helvetica,sans-serif;line-height:1.5}' +
      '#doc .pg h2{display:flex;align-items:center;gap:8px;font-size:16.5px;color:' + NAVY + ';border-bottom:1.5px solid ' + GOLD + ';padding:2px 0 3px;margin:16px 0 7px;break-after:avoid}' +
      '#doc .pg h2:before{content:"";width:5px;height:15px;background:' + NAVY + ';border-radius:1px;flex:none}' +
      '#doc .pg h3{color:' + NAVY + ';font-size:14.5px;margin:12px 0 4px;break-after:avoid}' +
      '#doc .pg table{border:1px solid ' + NAVY + ';break-inside:auto}#doc .pg tr{break-inside:avoid}' +
      '#doc .pg th{background:' + NAVY + ';color:#fff;border:1px solid ' + NAVY + ';font-size:13px;letter-spacing:.2px}' +
      '#doc .pg td{border:1px solid ' + LINE + '}#doc .pg tr:nth-child(even) td{background:#f7f9fc}' +
      '#doc .pg td.exok{color:#166534;font-weight:700}#doc .pg td.exko{color:#b91c1c;font-weight:700}' +
      '#doc .pg .nt{color:' + GREY + ';font-style:italic}' +
      '#doc .ex-sombox{margin-top:16px;margin-bottom:16px}#doc .ex-sombox>b{text-align:center}#doc .ex-som{columns:2;column-gap:18px;margin:0;padding:6px 8px 8px;list-style:none;font-size:12.5px}#doc .ex-som li{display:flex;gap:6px;padding:2px 0;break-inside:avoid;border-bottom:1px dotted ' + LINE + '}#doc .ex-som li span{flex:1}#doc .ex-som li i{font-style:normal;color:' + GREY + '}' +
      '#doc .ex-visas{margin-top:22px;break-inside:avoid;border:1px solid ' + NAVY + ';border-radius:4px;overflow:hidden}#doc .ex-visas>b{display:block;background:' + NAVY + ';color:#fff;font-size:11px;padding:5px 10px;border-bottom:3px solid ' + GOLD + '}' +
      '#doc .ex-vg{display:grid;grid-template-columns:repeat(3,1fr)}#doc .ex-vg>div{padding:8px 10px;border-right:1px solid ' + LINE + ';font-size:12px;text-align:center}#doc .ex-vg>div:last-child{border-right:0}#doc .ex-vg .z{height:70px;display:flex;align-items:flex-end;justify-content:center}#doc .ex-vg .z img{max-height:66px;max-width:100%;position:relative;z-index:0;transform:translateY(34px)}#doc .ex-vg .ln{position:relative;z-index:1}#doc .ex-vg .ln{border-top:1px solid #8a93a5;margin-top:4px;padding-top:4px}' +
      /* pied + filigrane */
      '#doc .ex-foot{font:10.5px Arial;color:' + GREY + ';text-align:center;border-top:1px solid ' + LINE + ';padding-top:4px;margin:10px 10px 0}' +
      '#doc .ex-wm{display:none}#doc .ex-wm.on{display:block}' +
      '@media screen and (max-width:560px){#doc .ex-band{flex-wrap:wrap}#doc .ex-ttl{width:100%;text-align:left;border-top:1px solid #ffffff33;padding-top:8px}#doc .ex-boxes{grid-template-columns:1fr}#doc .ex-sig{grid-template-columns:1fr 1fr}#doc .ex-qr{grid-column:1/-1}}' +
      '@media print{' +
      '@page{size:A4;margin:10mm 10mm 14mm}@page plan{size:A4 landscape;margin:8mm}@page plan3{size:A3 landscape;margin:7mm}' + /* les pages nommées APRÈS la page standard, sinon elles sont ignorées (plan en A4 portrait, minuscule) */
      '#doc .exf,#doc .exv{display:none!important}' +
      '#doc .ex-foot{position:fixed;left:0;right:0;bottom:0;margin:0;background:#fff}' +
      '#doc .ex-wm.on{position:fixed;left:0;right:0;top:42%;text-align:center;font:900 96px Arial;color:rgba(200,30,30,.13);transform:rotate(-30deg);pointer-events:none;z-index:9}' +
      '#doc .ex-cv{box-shadow:none;height:268mm;display:flex;flex-direction:column;break-inside:avoid}' +
      '#doc .ex-cv .ex-body{flex:1;display:flex;flex-direction:column;min-height:0}' +
      '#doc .ex-cv .ex-sombox{margin-top:auto;margin-bottom:auto}' +
      '#doc .ex-cv .ex-spacer{flex:1}' +
      '#doc .ex-cv .ex-fait{margin-top:14px}' +
      '#doc .pg.ex-last{display:flex;flex-direction:column;min-height:262mm}' +
      '#doc .pg.ex-last .ex-visas{margin-top:auto}}' +
      '@media screen{#doc .ex-wm.on{position:absolute;left:0;right:0;top:300px;text-align:center;font:900 60px Arial;color:rgba(200,30,30,.12);transform:rotate(-30deg);pointer-events:none;z-index:9}}';
    d.head.appendChild(s);
  }

  /* ---------- numérotation et mémoire (dans la clé xbp du calculateur : « Effacer » les vide aussi) ---------- */
  function mem(ctx) { var P = ctx.P(); P.nd = P.nd || { seq: {}, map: {}, ind: 'A', verif: '', pend: {} }; ['seq', 'map', 'pend', 'jv', 'cur'].forEach(function (k) { P.nd[k] = P.nd[k] || {}; }); P.nd.eng = P.nd.eng || { nom: '', ordre: '', cachet: '' }; return P.nd; }
  function numberFor(ctx, key, force, pre) {
    var m = mem(ctx), yr = String(new Date().getFullYear()), pf = pre || 'NCS';
    if (force) { m.map[key] = force; return force; }
    if (m.map[key]) return m.map[key];
    var sk = pf === 'NCS' ? yr : pf + yr, n = (m.seq[sk] || 0) + 1; m.seq[sk] = n;
    var no = pf + '-' + yr + '-' + (n < 100 ? (n < 10 ? '00' : '0') : '') + n; m.map[key] = no; ctx.save(); return no;
  }


  /* ---------- cartouche des plans d'exécution (remplace le cartouche d'origine, dans le SVG) ---------- */
  function cartouche(svg, c) {
    var F = c.F, I = c.I, st = c.st, NV = '#173565', GD = '#c9a227', LN = '#cfd6e2', SF = '#f0f4fa', GR = '#667085';
    var texts = Array.prototype.slice.call(svg.querySelectorAll('text'));
    var E = texts.filter(function (t) { return t.textContent === 'EXCELLENCIA'; })[0];
    var P1 = texts.filter(function (t) { return /^Page \d+\/\d+$/.test(t.textContent); })[0];
    if (!E || !P1) return;
    var ex = +E.getAttribute('x'), ey = +E.getAttribute('y'), k = (+P1.getAttribute('x') - ex) / 382;
    if (!(k > 0)) return;
    var ys = function (py) { return ey + (21 - py) * k; }, top = ys(35), bot = ys(5);
    /* lecture du cartouche d'origine (titre, sous-titre, données) puis retrait de ses traits et textes */
    var o = { titre: '', sous: '', i1: [], i2: [], i3: [], top: [] };
    var inside = [];
    Array.prototype.forEach.call(svg.children, function (e) {
      var tg = e.tagName.toLowerCase();
      if (tg === 'line') {
        var y1 = +e.getAttribute('y1'), y2 = +e.getAttribute('y2'), x1 = +e.getAttribute('x1'), x2 = +e.getAttribute('x2');
        if (Math.min(y1, y2) >= top - 0.05 && !(Math.abs(y1 - y2) < 0.01 && Math.abs(y1 - bot) < 0.05)) inside.push(e);
      } else if (tg === 'text') {
        var y = +e.getAttribute('y');
        if (y >= top - 0.05) {
          var px = 30 + (+e.getAttribute('x') - ex) / k, py = 21 - (y - ey) / k, fs = (+e.getAttribute('font-size')) / k, tx = e.textContent;
          if (Math.abs(px - 114) < 1.5 && fs > 5) o.titre = tx;
          else if (Math.abs(px - 114) < 1.5 && fs > 4) o.sous = tx;
          else if (Math.abs(py - 32.2) < 1.5) o.top.push(tx);
          else if (Math.abs(px - 252) < 1.5) o.i1.push(tx);
          else if (Math.abs(px - 312) < 1.5) o.i2.push(tx);
          else if (Math.abs(px - 367) < 1.5) o.i3.push(tx);
          inside.push(e);
        }
      }
    });
    inside.forEach(function (e) { e.remove(); });

    var tr = function (v, w, sz) { v = String(v == null ? '' : v); var n = Math.max(4, Math.floor(w / (sz * 0.56))); return v.length > n ? v.slice(0, n - 1) + '…' : v; };
    var T = function (u, v, str, sz, a) { a = a || {}; return '<text x="' + u + '" y="' + v + '" font-size="' + sz + '" font-family="Arial,sans-serif" fill="' + (a.f || '#172033') + '"' + (a.b ? ' font-weight="700"' : '') + (a.a ? ' text-anchor="' + a.a + '"' : '') + '>' + esc(str) + '</text>'; };
    var R = function (u, v, w, h, fill, stroke, sw) { return '<rect x="' + u + '" y="' + v + '" width="' + w + '" height="' + h + '" fill="' + (fill || 'none') + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="' + (sw || 0.3) + '"' : '') + '/>'; };
    var IMG = function (href, u, v, w, h, px) { return href ? '<image href="' + esc(href) + '" x="' + u + '" y="' + v + '" width="' + w + '" height="' + h + '" preserveAspectRatio="xMidYMid meet"' + (px ? ' style="image-rendering:pixelated"' : '') + '/>' : ''; };
    var cell = function (u, v, w, h, lab, val, sz) { return R(u, v, w, h, '#fff', LN, 0.25) + T(u + 2, v + 4.2, lab, 2.05, { f: GR, b: 1 }) + T(u + 2, v + h - 3.2, tr(val || '—', w - 3, sz || 3.2), sz || 3.2, { b: 1, f: val ? '#172033' : '#9aa4b5' }); };
    var g = '';
    g += R(0, 0, 405, 30, '#fff', NV, 0.5);
    /* identité Excellencia Building */
    g += R(0, 0, 95, 30, NV) + R(0, 0, 405, 1.4, GD);
    g += R(3, 4.5, 23, 23, '#fff') + IMG(I.logo, 4, 5.5, 21, 21);
    g += T(29, 10.5, tr(String(I.name).toUpperCase(), 64, 4.2), 4.2, { b: 1, f: '#fff' });
    if (I.tagline) g += T(29, 15.2, tr(I.tagline, 64, 2.5), 2.5, { f: '#cfd9ec' });
    if (I.phone) g += T(29, 19.4, tr('Tél : ' + I.phone, 64, 2.3), 2.3, { f: '#e5ebf6' });
    if (I.email) g += T(29, 23, tr(I.email, 64, 2.3), 2.3, { f: '#e5ebf6' });
    if (I.address) g += T(29, 26.6, tr(I.address, 64, 2.3), 2.3, { f: '#e5ebf6' });
    /* références du projet */
    var cw = 40, r1 = 1.4, rh = 14.3, norme = String(c.norme || '').split(' — ')[0];
    var gr = [['CLIENT / MAÎTRE D’OUVRAGE', F.moa], ['PROJET', F.projet], ['LIEU / SITE', F.site], ['ÉTABLI PAR', F.ing], ['VÉRIFIÉ PAR', F.verif], ['NORME', norme]];
    gr.forEach(function (x, i) { g += cell(95 + (i % 3) * cw, r1 + Math.floor(i / 3) * rh, cw, rh, x[0], x[1], i === 5 ? 2.7 : 3.2); });
    /* élément dessiné + données */
    g += R(215, 1.4, 85, 28.6, SF, LN, 0.25) + T(217, 9.8, tr(o.titre, 81, 5.2), 5.2, { b: 1, f: NV }) + T(217, 15, tr(o.sous, 81, 3.7), 3.7, { b: 1 });
    [o.i1[0], o.i1[1], o.i3[0]].forEach(function (x, i) { if (x) g += T(217, 19.6 + i * 3.6, tr(x, 40, 2.4), 2.4); });
    [o.i2[0], o.i2[1], o.top[0], o.top[1]].forEach(function (x, i) { if (x) g += T(258, 19.6 + i * 3.6, tr(x, 40, 2.4), 2.4); });
    /* visa : signature + cachet de l'administrateur */
    g += R(300, 1.4, 35, 28.6, '#fff', LN, 0.25) + T(302, 5.2, 'VISA / CACHET', 2, { f: GR, b: 1 }) + IMG(st.visa, 301, 6, 33, 23);
    /* QR de vérification */
    if (c.qpng) g += R(335, 1.4, 27, 28.6, '#fff', LN, 0.25) + IMG(c.qpng, 336.5, 2.6, 24, 24, 1) + T(348.5, 29, 'Code ' + String(c.q.code.hash).toUpperCase(), 1.8, { a: 'middle', f: GR });
    /* numéro, date, indice, page */
    g += R(362, 1.4, 43, 28.6, SF, LN, 0.25);
    [['N°', F.no, 1], ['Date', frDate(st.date), 0], ['Indice', F.ind, 0], ['Page', c.i + ' / ' + c.n, 0]].forEach(function (x, i) {
      g += T(364, 8 + i * 6.6, x[0], 2.2, { f: GR, b: 1 }) + T(374, 8 + i * 6.6, tr(x[1], 30, 3), 3, { b: 1, f: x[2] ? NV : '#172033' });
    });
    if (st.draft) g += T(383.5, 28.2, st.wm || 'BROUILLON', 2.7, { a: 'middle', b: 1, f: '#c81e1e' });
    var ns = 'http://www.w3.org/2000/svg', grp = d.createElementNS(ns, 'g');
    grp.setAttribute('transform', 'translate(' + (ex + (10 - 30) * k) + ',' + top + ') scale(' + k + ')');
    grp.setAttribute('class', 'exb-cart');
    grp.innerHTML = g;
    svg.appendChild(grp);
  }

  /* ---------- décoration de l'aperçu ---------- */
  function decorate(o, ctx) {
    try {
      var db = o.querySelector('.db'), ti = db && db.querySelector('.ti');
      var svgs = db ? Array.prototype.slice.call(db.querySelectorAll('.pl3 svg')) : [];
      var plan = !ti && svgs.some(function (v) { return Array.prototype.some.call(v.querySelectorAll('text'), function (t) { return t.textContent === 'EXCELLENCIA'; }); });
      if (!db || (!ti && !plan)) return; /* autres feuilles : inchangées */
      css();
      var V = ext('EXBVerif'), I = ident(ctx), m = mem(ctx);
      var normeTxt = (ti && ti.getAttribute('data-norme')) || ctx.nrm().nom;
      var objet = plan ? ((db.querySelector('.pg h2') || {}).textContent || 'Plan d’exécution') : ((ti.querySelector('h1') || {}).textContent || 'Note de calcul');
      objet = objet.replace(/\s*\([^)]*\)\s*$/, '').trim();
      var text = Array.prototype.map.call(db.querySelectorAll('.pg'), function (e) { return e.textContent; }).join('|');
      var origs = svgs.map(function (v) { return v.innerHTML; });
      var digest = (V && V.sha256 ? V.sha256(objet + '|' + text) : hash32(objet + '|' + text)).slice(0, 16);
      var key = hash32(objet + '|' + text);
      var st = { visa: '', draft: false, date: today() };
      var F = { moa: '', projet: '', site: '', ing: '', verif: m.verif || '', ind: m.ind || 'A', no: numberFor(ctx, key, null, plan ? 'PEX' : 'NCS') };

      var pi = ctx.pi(); F.moa = pi.moa || ''; F.projet = pi.projet || ''; F.site = pi.site || ''; F.ing = pi.ing || '';
      if (F.projet === 'Projet de construction') F.projet = ''; /* valeur par défaut du calculateur : à remplir */

      /* ---------- circuit de vérification / validation par un ingénieur ---------- */
      var LAB = { emis: 'Émis — non validé par un ingénieur', verif: 'Soumis à vérification — non valable pour exécution', valide: 'Validé par un ingénieur', reserves: 'Validé avec réserves', refuse: 'Refusé — à reprendre' };
      var SHORT = { emis: 'Émis', verif: 'En vérification', valide: 'Validé', reserves: 'Validé avec réserves', refuse: 'Refusé' };
      var WMT = { verif: 'EN VÉRIFICATION', refuse: 'REFUSÉ' };
      function vrec() { return m.cur[digest] || null; }
      function curS() { var r = vrec(); return r ? r.statut : 'emis'; }
      function isVal() { var s = curS(); return s === 'valide' || s === 'reserves'; }
      function isDraft() { var s = curS(); return !!st.draft || s === 'verif' || s === 'refuse'; }
      function wmText() { var s = curS(); return WMT[s] || 'BROUILLON'; }
      function cachetImg() { var r = vrec(); return (isVal() && r && m.eng.cachet && (r.par === m.eng.nom || (r.ordre && r.ordre === m.eng.ordre))) ? m.eng.cachet : ''; }
      function vName() { var r = vrec(); return isVal() && r ? r.par + (r.src === 'local' ? ' ⚠ validation locale non vérifiée par le serveur' : '') : F.verif; }
      var srvItems = null;
      function conv(x) { return { rev: x.indice, date: String(x.cree_le || '').slice(0, 10), no: x.no, statut: x.statut, par: x.ing_nom, ordre: x.ing_ordre, comment: x.commentaire, digest: x.digest, ts: Date.parse(x.cree_le) || 0, src: 'serveur' }; }
      function jk() { return (F.projet || '') + '|' + objet; }

      /* fiche à remplir */
      var f = d.createElement('div'); f.className = 'exf';
      f.innerHTML = '<h3>📝 Informations du document</h3><p>À remplir avant d’imprimer : elles s’inscrivent sur la page de garde et dans l’en-tête de chaque page.</p><div class="g">' +
        fld('moa', 'Client / Maître d’ouvrage', F.moa) + fld('projet', 'Projet', F.projet) + fld('site', 'Lieu / site', F.site) + fld('ing', 'Établi par (ingénieur)', F.ing) +
        fld('verif', 'Vérifié par', F.verif) + fld('ind', 'Indice de révision', F.ind) + fld('no', 'N° de la note', F.no) + '<div><label>Date</label><input type="date" id="exf_date" value="' + st.date + '"></div></div>' +
        '<label class="ck"><input type="checkbox" id="exf_draft"> Brouillon (filigrane « BROUILLON » sur chaque page)</label><div class="st" id="exf_st"></div>';
      function fld(k, l, v) { return '<div><label>' + esc(l) + '</label><input type="text" id="exf_' + k + '" value="' + esc(v) + '"></div>'; }
      db.insertBefore(f, db.firstChild);

      /* fiche de vérification / validation + journal des versions */
      var vb = d.createElement('div'); vb.className = 'exv';
      var r0 = vrec();
      vb.innerHTML = '<h3>✅ Vérification et validation par un ingénieur</h3><p>La validation est liée à cette version précise du calcul (empreinte ' + esc(digest.slice(0, 8).toUpperCase()) + '). Si les données changent, le statut redevient « Émis » et une nouvelle validation est nécessaire.</p>' +
        '<div class="g"><div><label>Statut</label><select id="exv_s">' + Object.keys(LAB).map(function (k) { return '<option value="' + k + '"' + (k === curS() ? ' selected' : '') + '>' + esc(SHORT[k]) + '</option>'; }).join('') + '</select></div>' +
        '<div><label>Ingénieur vérificateur / validateur</label><input type="text" id="exv_n" value="' + esc(r0 ? r0.par : m.eng.nom) + '"></div>' +
        '<div><label>N° d’inscription à l’ordre / matricule</label><input type="text" id="exv_o" value="' + esc(r0 ? r0.ordre : m.eng.ordre) + '"></div>' +
        '<div><label>Cachet et signature (image)</label><div class="cach"><span id="exv_img"></span><button type="button" id="exv_file">Choisir une image</button><button type="button" id="exv_rm">Retirer</button></div></div>' +
        '<div class="w"><label>Réserves / observations (obligatoire si « avec réserves » ou « refusé »)</label><input type="text" id="exv_c" value="' + esc(r0 ? r0.comment : '') + '"></div></div>' +
        '<label class="ck"><input type="checkbox" id="exv_a"><span>Je certifie avoir vérifié les hypothèses, les données et les résultats de ce calcul, et j’engage ma responsabilité d’ingénieur sur cette validation.</span></label>' +
        '<div style="margin-top:10px"><button type="button" class="p" id="exv_save">Enregistrer au journal</button></div><div class="msg" id="exv_m"></div><div id="exv_j"></div>';
      f.parentNode.insertBefore(vb, f.nextSibling);
      function q$(i) { return vb.querySelector('#' + i); }
      function showCachet() { q$('exv_img').innerHTML = m.eng.cachet ? '<img src="' + m.eng.cachet + '" alt="Cachet">' : '<em style="font-size:12px;color:' + GREY + '">Aucun cachet enregistré</em>'; }
      function say(t, c) { var e = q$('exv_m'); e.className = 'msg ' + (c || ''); e.textContent = t || ''; }
      function journal() {
        var L = srvItems ? srvItems.map(conv) : (m.jv[jk()] || []).slice().reverse(), lastV = null;
        L.some(function (e) { if (e.statut === 'valide' || e.statut === 'reserves') { lastV = e; return true; } return false; });
        var warn = '';
        if (lastV && lastV.digest !== digest) warn = '<div class="msg wn">⚠️ La dernière validation (indice ' + esc(lastV.rev) + ', ' + esc(lastV.no) + ') portait sur une version différente de ce calcul. Cette version n’est pas validée : passez à l’indice suivant et faites-la valider.</div>';
        q$('exv_j').innerHTML = warn + (L.length ? '<table><tr><th>Indice</th><th>Date</th><th>N°</th><th>Statut</th><th>Par</th></tr>' + L.map(function (e) {
          return '<tr' + (e.digest === digest ? ' class="cur"' : '') + '><td>' + esc(e.rev) + '</td><td>' + frDate(e.date) + '</td><td>' + esc(e.no) + (e.digest === digest ? '<br><i>version actuelle</i>' : '') + '</td><td>' + esc(SHORT[e.statut] || e.statut) + (e.comment ? '<br><i>' + esc(e.comment) + '</i>' : '') + '</td><td>' + esc(e.par || '—') + (e.ordre ? '<br>n° ' + esc(e.ordre) : '') + (e.src === 'serveur' ? '<br><i>enregistré sur le serveur ✓</i>' : '<br><i>local — non probant</i>') + '</td></tr>';
        }).join('') + '</table>' : '<p style="margin-top:8px">Aucune révision enregistrée pour ce calcul.</p>');
      }
      function readCachet(file, done) {
        var fr = new FileReader();
        fr.onload = function () {
          var im = new Image();
          im.onload = function () {
            var k = Math.min(1, 360 / im.width, 240 / im.height), c = d.createElement('canvas');
            c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
            c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
            done(c.toDataURL('image/png'));
          };
          im.onerror = function () { say('Image illisible.', 'ko'); };
          im.src = fr.result;
        };
        fr.readAsDataURL(file);
      }
      q$('exv_file').onclick = function () {
        var i = d.createElement('input'); i.type = 'file'; i.accept = 'image/*';
        i.onchange = function () { if (i.files && i.files[0]) readCachet(i.files[0], function (u) { m.eng.cachet = u; ctx.save(); showCachet(); paint(); say('Cachet enregistré sur cet appareil.', 'ok'); }); };
        i.click();
      };
      q$('exv_rm').onclick = function () { m.eng.cachet = ''; ctx.save(); showCachet(); paint(); };
      q$('exv_save').onclick = function () {
        var S = srv(), sS = q$('exv_s').value, nom = q$('exv_n').value.trim(), ordre = q$('exv_o').value.trim(), cm = q$('exv_c').value.trim(), ok = q$('exv_a').checked;
        var oui = (sS === 'valide' || sS === 'reserves'), def = oui || sS === 'refuse';
        if (oui && !S && (!nom || !ordre)) return say('Indiquez le nom de l’ingénieur et son numéro d’inscription pour valider.', 'ko');
        if (oui && !ok) return say('Cochez la déclaration de responsabilité pour valider.', 'ko');
        if ((sS === 'reserves' || sS === 'refuse') && !cm) return say('Indiquez les réserves ou le motif du refus.', 'ko');
        if (sS === 'verif' && !nom) return say('Indiquez l’ingénieur chargé de la vérification.', 'ko');
        var e = { rev: F.ind, date: st.date, no: F.no, statut: sS, par: nom, ordre: ordre, comment: cm, digest: digest, ts: Date.now(), src: S ? 'serveur' : 'local' }, jk0 = jk();
        function fin(e, msgT, msgC) {
          m.jv[jk0] = (m.jv[jk0] || []).concat([e]).slice(-60);
          if (sS === 'emis') delete m.cur[digest]; else m.cur[digest] = e;
          if (e.par) { m.eng.nom = e.par; m.eng.ordre = e.ordre; }
          if (def && e.src === 'serveur') { q$('exv_n').value = e.par; q$('exv_o').value = e.ordre; }
          ctx.save(); paint(); journal(); say(msgT, msgC); q$('exv_a').checked = false;
        }
        if (!S) {
          return fin(e, oui ? 'Validation LOCALE enregistrée : non probante (vous n’êtes pas connecté à une entreprise en ligne). Elle est signalée comme telle sur le document. Connectez-vous pour une validation enregistrée sur le serveur.' : 'Enregistré au journal local : ' + SHORT[sS] + '.', oui ? 'wn' : 'ok');
        }
        var btn = q$('exv_save'); btn.disabled = true; say('Enregistrement sur le serveur…', '');
        Promise.resolve(S.call('calcul_valider', { p_org: S.org, p_projet: F.projet || '', p_type: objet, p_no: F.no, p_indice: F.ind, p_digest: digest, p_statut: sS, p_commentaire: cm, p_declaration: ok })).then(function (r) {
          btn.disabled = false;
          if (!r || !r.ok) return say('Refusé par le serveur : ' + (REFUS[r && r.refus] || (r && r.refus) || 'réponse invalide') + ' Rien n’a été enregistré.', 'ko');
          if (def) { e.par = r.ing_nom || ''; e.ordre = r.ing_ordre || ''; }
          e.date = String(r.date || st.date).slice(0, 10);
          fin(e, 'Enregistré sur le serveur : ' + SHORT[sS] + (def ? ' — par ' + e.par + ' (ordre ' + e.ordre + ').' : '.') + (oui && !m.eng.cachet ? ' Aucun cachet : seule la mention de l’ingénieur sera imprimée.' : ''), 'ok');
          pull();
        }, function () { btn.disabled = false; say('Serveur injoignable (hors connexion ?). Rien n’a été enregistré : une validation doit l’être sur le serveur. Réessayez avec du réseau.', 'ko'); });
      };
      /* état de référence = serveur : une validation locale falsifiée ne survit pas à l'ouverture en ligne */
      function pull() {
        var S = srv(); if (!S) return;
        Promise.resolve(S.call('calcul_journal', { p_org: S.org, p_projet: F.projet || '', p_type: objet })).then(function (r) {
          if (!r || !r.ok) return;
          srvItems = r.items || [];
          var mine = null; srvItems.some(function (x) { if (x.digest === digest) { mine = x; return true; } return false; });
          var cur = m.cur[digest];
          if (mine && mine.statut !== 'emis') m.cur[digest] = conv(mine);
          else if (cur && cur.src !== 'local') delete m.cur[digest];
          ctx.save(); paint(); journal();
        }, function () {});
      }
      showCachet(); journal(); pull();

      /* filigrane + pied de page */
      var wm = d.createElement('div'); wm.className = 'ex-wm'; wm.textContent = 'BROUILLON'; db.insertBefore(wm, db.firstChild);
      var foot = d.createElement('div'); foot.className = 'ex-foot'; if (!plan) db.insertBefore(foot, db.firstChild);

      /* logo dans l'en-tête de chaque page de calcul */
      /* sommaire (titres des sections et feuille) et numérotation réelle des feuilles */
      var sheets = Array.prototype.slice.call(db.querySelectorAll('.pg')).filter(function (e) { return e.querySelector('.hd'); });
      var secs = []; sheets.forEach(function (e, i) { Array.prototype.forEach.call(e.querySelectorAll('h2'), function (h) { secs.push([h.textContent.replace(/\s+/g, ' ').trim(), i + 1]); }); });
      /* verdicts en couleur (cellules « Vérifié », « OK », « Non vérifié »…) */
      Array.prototype.forEach.call(db.querySelectorAll('.pg td'), function (c) {
        var t = c.textContent.replace(/[✔✓✘✗⚠️\s]/g, ' ').trim();
        if (/^(vérifiée?s?|ok|oui|conforme|satisfait)\b/i.test(t)) c.classList.add('exok'); else if (/^(non vérifiée?s?|non|insuffisante?|non conforme|à revoir)\b/i.test(t)) c.classList.add('exko');
      });
      var vis = null;
      if (sheets.length) { vis = d.createElement('div'); vis.className = 'ex-visas'; sheets[sheets.length - 1].appendChild(vis); sheets[sheets.length - 1].classList.add('ex-last'); }
      function heads() {
        sheets.forEach(function (e, i) { var sp = e.querySelectorAll('.hd span'); if (sp.length > 1) sp[sp.length - 1].textContent = 'Feuille ' + (i + 1) + ' / ' + sheets.length; });
        if (vis) vis.innerHTML = '<b>CONCLUSION ET VISAS</b><div class="ex-vg">' +
          '<div><div class="z">' + (st.visa ? '<img src="' + st.visa + '" alt="">' : '') + '</div><div class="ln"><b>Établi par</b><br>' + esc(F.ing || '') + '<br>' + esc(I.name) + '</div></div>' +
          '<div><div class="z">' + (cachetImg() ? '<img src="' + cachetImg() + '" alt="">' : '') + '</div><div class="ln"><b>' + (isVal() ? 'Validé par' : 'Vérifié par') + '</b><br>' + esc(vName() || '') + (isVal() && vrec().ordre ? '<br>Ordre n° ' + esc(vrec().ordre) : '') + '<br>Date : ' + frDate(isVal() ? vrec().date : st.date) + '</div></div>' +
          '<div><div class="z"></div><div class="ln"><b>Maître d’ouvrage — « Lu et approuvé »</b><br>' + esc(F.moa || '') + '</div></div></div>';
        Array.prototype.forEach.call(db.querySelectorAll('.hd'), function (h) {
          var b = h.querySelector('b'), sp = h.querySelectorAll('span');
          if (b) b.textContent = I.name;
          if (sp[0]) sp[0].textContent = (F.projet || 'Projet') + (F.site ? ' — ' + F.site : '') + ' · ' + F.no;
          if (I.logo && !h.querySelector('img.exl')) { var im = d.createElement('img'); im.className = 'exl'; im.alt = ''; im.src = I.logo; im.onerror = function () { im.remove(); }; h.insertBefore(im, h.firstChild); }
        });
      }

      function qrFor() {
        if (!V || !V.docRec) return null;
        try {
          var rec = V.docRec({ no: F.no, date: st.date, title: plan ? 'Plan d’exécution' : 'Note de calcul', sub: objet.replace(/^(NOTE DE CALCUL|PLAN D['’]EXÉCUTION)\s*(—|DE |DU |DES |D')?\s*/i, '').toLowerCase().replace(/^./, function (c) { return c.toUpperCase(); }) + (F.projet ? ' — ' + F.projet : ''), digest: digest + '|' + F.ind + '|' + curS(), nom: F.moa || F.projet, detail: normeTxt + ' · Indice ' + F.ind + (F.ing ? ' · Établi par ' + F.ing : '') + (isVal() ? ' · ' + SHORT[curS()] + ' par ' + vrec().par + (vrec().ordre ? ' (ordre ' + vrec().ordre + ')' : '') + ' le ' + frDate(vrec().date) + (vrec().src === 'local' ? ' (validation locale, non vérifiée par le serveur)' : '') : ' · Non validé par un ingénieur') });
          rec.rec.status = curS() === 'refuse' ? 'refusé' : isDraft() ? 'brouillon' : 'valide';
          return rec;
        } catch (e) { return null; }
      }

      function paint() {
        var q = qrFor(), qpng = '';
        try { qpng = q && V.qrPng ? V.qrPng(q.code.url) : ''; } catch (e) {}
        if (plan) { wm.textContent = wmText(); wm.classList.toggle('on', isDraft()); var stx = { visa: cachetImg() || st.visa, draft: isDraft(), date: st.date, wm: wmText() }, Fx = Object.assign({}, F, { verif: vName() }); svgs.forEach(function (v, i) { v.innerHTML = origs[i]; try { cartouche(v, { F: Fx, I: I, st: stx, q: q, qpng: qpng, i: i + 1, n: svgs.length, norme: normeTxt }); } catch (e) { try { console.error('cartouche', e); } catch (x) {} } }); return; }
        var som = secs.map(function (x, i) { return '<li><span>' + esc(x[0]) + '</span><i>Feuille ' + x[1] + '</i></li>'; }).join('');
        var lines = function (a) { return a.filter(function (r) { return String(r[1] || '').trim(); }).map(function (r) { return '<em>' + esc(r[0]) + ' :</em> <b>' + esc(r[1]) + '</b>'; }).join('<br>') || '<em>— à compléter —</em>'; };
        ti.className = 'ti ex-cv'; ti.setAttribute('style', '');
        var clx = [['Projet', F.projet], ['Lieu', F.site]].filter(function (r) { return String(r[1] || '').trim(); }).map(function (r) { return '<em style="color:' + GREY + ';font-style:normal">' + esc(r[0]) + ' :</em> ' + esc(r[1]); }).join('<br>');
        var rfx = [['Norme', normeTxt], ['Établi par', F.ing], [isVal() ? 'Validé par' : 'Vérifié par', vName()], ['N° d’ordre', isVal() ? vrec().ordre : ''], ['Statut', (st.draft ? 'Brouillon — non valable pour exécution' : LAB[curS()])]].filter(function (r) { return String(r[1] || '').trim(); }).map(function (r) { return '<em>' + esc(r[0]) + ' :</em> ' + esc(r[1]); }).join('  ·  ');
        ti.className = 'ti ex-cv'; ti.setAttribute('style', '');
        ti.innerHTML = '<div class="ex-fin"></div><div class="ex-c">' +
          '<div class="ex-nm">' + esc(String(I.name).toUpperCase()) + '</div>' + (I.tagline ? '<div class="ex-tg">' + esc(I.tagline) + '</div>' : '') + '<div class="ex-rule"></div>' +
          '<div class="ex-lg">' + (I.logo ? '<img src="' + esc(I.logo) + '" alt="" onerror="this.remove()">' : '') + '</div>' +
          '<h1 class="ex-t1">NOTE DE CALCUL</h1><div class="ex-no">N° ' + esc(F.no) + '  ·  Indice ' + esc(F.ind) + '</div><div class="ex-rule2"></div>' +
          '<div class="ex-lb">OBJET</div><p class="ex-obj2">' + esc((objet.replace(/^(NOTE DE CALCUL|PLAN D['’]EXÉCUTION)\s*(—|-|:)?\s*/i, '') || objet).toUpperCase()) + '</p>' +
          '<div class="ex-lb">CLIENT / MAÎTRE D’OUVRAGE</div><div class="ex-cl"><b>' + esc(F.moa || '— à compléter —') + '</b>' + clx + '</div>' +
          '<div class="ex-rf">' + rfx + '</div>' +
          (som ? '<div class="ex-lb">SOMMAIRE</div><ol class="ex-som">' + som + '</ol>' : '') +
          '<div class="ex-bt"><div class="ex-q1">' + (qpng ? '<img src="' + qpng + '" alt="QR de vérification"><b>Vérifier ce document</b>Code ' + esc(String(q.code.hash).toUpperCase()) : '') + '</div>' +
          '<div><div class="ex-dl">Fait à ' + esc(I.city || '…………………………') + ' — Date de délivrance : ' + frDate(st.date) + '</div>' +
          '<div class="ex-s1"><div class="z">' + (st.visa ? '<img src="' + st.visa + '" alt="">' : '') + '</div><b>Établi par</b><span>' + esc(F.ing || I.name) + '</span></div></div></div>' +
          '<p class="ex-note" style="font-size:8.5px;margin-top:10px;text-align:left">Les résultats de cette note sont une aide au dimensionnement établie selon la norme indiquée. Ils doivent être vérifiés, validés et signés par l’ingénieur responsable avant toute exécution. Toute modification des données ou des résultats entraîne un nouvel indice et une nouvelle validation.' + (isVal() ? ' Validation enregistrée au journal le ' + frDate(vrec().date) + ', indice ' + esc(vrec().rev) + '.' : '') + '</p></div>';
        wm.textContent = wmText(); wm.classList.toggle('on', isDraft());
        foot.textContent = [I.name, I.contact, F.no + ' · Indice ' + F.ind + (isDraft() ? ' · ' + wmText() : ' · ' + SHORT[curS()])].filter(Boolean).join('   ·   ');
        heads();
      }

      /* saisie : enregistrement dans les réglages du calculateur (mêmes champs que « Plus d'options ») */
      function persist() {
        var P = ctx.P(), cur = ctx.pi();
        P.i = Object.assign({}, cur, { moa: F.moa, projet: F.projet || cur.projet, site: F.site, ing: F.ing });
        var mm = mem(ctx); mm.verif = F.verif; mm.ind = F.ind; mm.map[key] = F.no; ctx.save();
      }
      ['moa', 'projet', 'site', 'ing', 'verif', 'ind', 'no'].forEach(function (k) {
        var e = f.querySelector('#exf_' + k);
        e.oninput = function () { F[k] = e.value.trim(); if (k === 'no' && !F.no) F.no = numberFor(ctx, key, null, plan ? 'PEX' : 'NCS'); persist(); paint(); };
      });
      f.querySelector('#exf_date').onchange = function (e) { st.date = e.target.value || today(); paint(); };
      f.querySelector('#exf_draft').onchange = function (e) { st.draft = !!e.target.checked; paint(); };

      /* signature + cachet de l'administrateur (module du logiciel central) */
      try { var X = ext('EXBId'); if (X && X.visa) X.visa().then(function (u) { st.visa = u || ''; paint(); }); } catch (e) {}
      paint();

      var stEl = f.querySelector('#exf_st');
      stEl.textContent = plan ? (V ? 'Le cartouche de chaque plan est rempli avec ces informations, le logo, la signature et le cachet ; le QR est enregistré au registre en ligne à l’impression (compte administrateur connecté).' : 'Cartouche rempli avec ces informations. QR et signature disponibles depuis le logiciel Excellencia Building (cette page est ouverte seule).') : V ? 'QR de vérification actif : il est enregistré au registre en ligne lors de l’impression (compte administrateur connecté).' : 'QR et signature disponibles depuis le logiciel Excellencia Building (cette page est ouverte seule).';

      /* impression : publication au registre puis boîte d'impression, titre du fichier = n° + projet */
      var pb = o.querySelector('#dp'), pp = o.querySelector('#dpp');
      /* deux boutons séparés : « PDF » (enregistrer / aperçu) et « Imprimer » (boîte d'impression habituelle) */
      /* TÉLÉPHONE (Android) : le navigateur intégré ne sait pas « Imprimer / PDF ». On fabrique donc le PDF nous-mêmes :
       * chaque feuille (page de garde, feuilles de calcul, plan) est photographiée puis assemblée en PDF, enregistré dans
       * Documents/ExcellenciaBuilding/Fichiers puis proposé à l'ouverture / au partage. */
      var topw = (function () { try { return w.parent && w.parent !== w && w.parent.document ? w.parent : w; } catch (e) { return w; } })();
      var isPhoneApp = function () {
        try { if ((w.Capacitor && w.Capacitor.isNativePlatform && w.Capacitor.isNativePlatform()) || (topw.Capacitor && topw.Capacitor.isNativePlatform && topw.Capacitor.isNativePlatform())) return true; } catch (e) {}
        return !!(topw.EXBNativeDownload || w.EXBNativeDownload) && !w.exbPrintPDF;
      };
      var rasterPdf = function (title) {
        var H2C = w.html2canvas || topw.html2canvas, J = ((w.jspdf || topw.jspdf) || {}).jsPDF;
        if (!H2C || !J) return Promise.reject(new Error('le moteur PDF n’est pas chargé'));
        var pages = Array.prototype.filter.call(o.querySelectorAll('.db .ti, .db .pg'), function (e) { return !e.closest('.exf,.exv'); });
        if (!pages.length) return Promise.reject(new Error('aucune feuille à convertir'));
        var pdf = null, i = 0;
        var next = function () {
          if (i >= pages.length) return Promise.resolve();
          var el = pages[i], n = ++i, land3 = el.classList.contains('pl3'), land = el.classList.contains('pl');
          ctx.toast('Création du PDF… feuille ' + n + ' / ' + pages.length);
          var sv = { ov: el.style.overflow, mw: el.style.minWidth, sh: el.style.boxShadow, mg: el.style.margin };
          el.style.overflow = 'visible'; el.style.boxShadow = 'none'; el.style.margin = '0';
          var W = Math.max(el.offsetWidth, el.scrollWidth), sc = Math.min(3, Math.max(1.5, 2200 / W));
          return new Promise(function (r) { setTimeout(r, 60); }).then(function () {
            return H2C(el, { scale: sc, backgroundColor: '#ffffff', logging: false, useCORS: false, width: W, windowWidth: Math.max(W, 900) });
          }).then(function (cv) {
            el.style.overflow = sv.ov; el.style.minWidth = sv.mw; el.style.boxShadow = sv.sh; el.style.margin = sv.mg;
            var PW = land3 ? 420 : land ? 297 : 210, PH = land3 ? 297 : land ? 210 : 297, M = land3 ? 7 : 10;
            if (!pdf) pdf = new J({ orientation: PW > PH ? 'l' : 'p', unit: 'mm', format: [PW, PH], compress: true });
            else pdf.addPage([PW, PH], PW > PH ? 'l' : 'p');
            var aw = PW - 2 * M, ah = PH - 2 * M, k = aw / cv.width, hmm = cv.height * k;
            if (hmm <= ah * 1.22) {                      /* tient (éventuellement un peu réduit) sur une page */
              var k2 = Math.min(k, ah / cv.height);
              pdf.addImage(cv.toDataURL('image/jpeg', 0.92), 'JPEG', M + (aw - cv.width * k2) / 2, M, cv.width * k2, cv.height * k2);
            } else {                                      /* feuille longue : découpée en plusieurs pages */
              var sliceH = Math.floor(ah / k), y = 0, first = true;
              while (y < cv.height) {
                var h = Math.min(sliceH, cv.height - y), part = d.createElement('canvas'); part.width = cv.width; part.height = h;
                var g = part.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, part.width, h); g.drawImage(cv, 0, y, cv.width, h, 0, 0, cv.width, h);
                if (!first) pdf.addPage([PW, PH], PW > PH ? 'l' : 'p');
                pdf.addImage(part.toDataURL('image/jpeg', 0.92), 'JPEG', M, M, aw, h * k); first = false; y += h;
              }
            }
          }, function (e) { el.style.overflow = sv.ov; el.style.minWidth = sv.mw; el.style.boxShadow = sv.sh; el.style.margin = sv.mg; throw e; }).then(next);
        };
        return next().then(function () {
          var blob = pdf.output('blob'), name = String(title || 'Document').replace(/[\\/:*?"<>|]+/g, '-').trim() + '.pdf', DL = topw.EXBNativeDownload || w.EXBNativeDownload;
          if (DL && DL.save) return DL.save(blob, name);
          var u = URL.createObjectURL(blob), a = d.createElement('a'); a.href = u; a.download = name; d.body.appendChild(a); a.click();
          setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 5000);
        });
      };
      var doPrint = function (mode) {
        var phone = isPhoneApp(), q = qrFor(), msg = (mode === 'pdf' || phone) ? (w.EXBDocPDF || w.exbPrintPDF || phone ? 'Création du PDF…' : 'Choisissez « Enregistrer au format PDF »') : 'Impression…', ok = false;
        var prev = d.title; d.title = F.no + (plan ? ' — Plan d’exécution' : ' — Note de calcul') + (F.projet ? ' — ' + F.projet : '');
        var back = function () { d.title = prev; w.removeEventListener('afterprint', back); };
        w.addEventListener('afterprint', back);
        var go = function () { ctx.toast(msg); setTimeout(function () { if (phone) { rasterPdf(d.title).then(function () { ctx.toast('✓ PDF créé'); }, function (e) { ctx.toast('PDF impossible : ' + (e && e.message || e)); }); } else if (mode === 'pdf' && w.EXBDocPDF) w.EXBDocPDF.run({ name: d.title }); else if (mode === 'pdf' && w.exbPrintPDF) w.exbPrintPDF(); else if (w.exbPrintNative) w.exbPrintNative(); else w.print(); }, 600); };
        var step = function () {
          if (q && V && V.publish) {
            var pk = q.rec.no + '|' + q.rec.hash, pend = mem(ctx).pend; pend[pk] = q.rec; ctx.save();
            V.publish(q.rec).then(function (r) { ok = !!r; if (ok) { delete pend[pk]; ctx.save(); } else msg = 'QR non confirmé en ligne (connexion administrateur requise) — il sera publié à la prochaine ouverture. ' + msg; go(); }, function () { msg = 'QR non confirmé en ligne. ' + msg; go(); });
          } else go();
        };
        /* V99zzf : lie le code du QR à la validation enregistrée sur le serveur (vérification publique par le QR) */
        var S0 = srv();
        if (q && S0) {
          Promise.resolve(S0.call('calcul_lier_qr', { p_org: S0.org, p_no: F.no, p_code: String(q.code.hash), p_digest: digest, p_indice: F.ind, p_statut: curS() })).then(function (r) {
            if (!r || !r.ok) msg = 'Lien QR non enregistré sur le serveur (' + (REFUS[r && r.refus] || (r && r.refus) || 'réponse invalide') + ') : la vérification par le QR n’affichera pas la validation. ' + msg;
            step();
          }, function () { msg = 'Lien QR non enregistré sur le serveur (hors connexion) : la vérification par le QR n’affichera pas la validation. ' + msg; step(); });
        } else step();
      };
      if (pb) pb.onclick = function () { doPrint('native'); };
      if (pp) pp.onclick = function () { doPrint('pdf'); };

      /* envois en attente (impression faite hors connexion) : republier dès que possible */
      try { var pd = mem(ctx).pend; if (V && V.publish) Object.keys(pd).forEach(function (k) { V.publish(pd[k]).then(function (r) { if (r) { delete pd[k]; ctx.save(); } }); }); } catch (e) {}
    } catch (e) { try { console.error('exb-calcul-doc', e); } catch (x) {} }
  }

  w.EXBCALCDOC = { decorate: decorate, version: 'V99zl' };
})(window, document);
