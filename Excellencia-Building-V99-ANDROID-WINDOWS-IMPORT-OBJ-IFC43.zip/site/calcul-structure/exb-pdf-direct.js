/* Excellencia Building — PDF direct des notes de calcul et des plans d'exécution.
 * Pourquoi : sous Windows (et sur certains appareils) le bouton PDF ouvrait la boîte d'impression « Microsoft Print to PDF »
 * avec le message « Cette application ne prend pas en charge l'aperçu avant impression » et le PDF n'était pas créé.
 * Ici le PDF est fabriqué DANS la page (aucune boîte d'impression, aucun module externe) :
 *   - chaque feuille du document (page de garde, pages de calcul, plans A3/A4) est dessinée en haute résolution ;
 *   - les feuilles longues sont coupées entre deux lignes de tableau (jamais au milieu d'une ligne) ;
 *   - pied de page et filigrane BROUILLON repris sur chaque feuille ;
 *   - le fichier est enregistré (Windows : fenêtre « Enregistrer sous » puis ouverture ; Android : dossier Documents ; navigateur : téléchargement).
 * Utilisation : EXBDocPDF.run() */
(function (w, d) {
  'use strict';
  var MM = 96 / 25.4;                       /* pixels CSS par millimètre */
  var PAGES = {
    a4: { W: 210, H: 297, mt: 10, mb: 14, ml: 10, mr: 10 },
    a4l: { W: 297, H: 210, mt: 8, mb: 12, ml: 8, mr: 8 },
    a3l: { W: 420, H: 297, mt: 6, mb: 10, ml: 6, mr: 6 }
  };

  function note(t, k, ms) { try { (w.top && w.top.notify ? w.top : w).notify(t, k || 'info', ms || 4000); } catch (e) {} try { if (w.toast) w.toast(t); } catch (e2) {} }
  function tick(ms) { return new Promise(function (r) { setTimeout(r, ms || 0); }); }

  /* ---------- feuille de style complète (l'impression est appliquée comme un style normal) ---------- */
  function allCss() {
    var out = [];
    function walk(rules, inPrint) {
      Array.prototype.forEach.call(rules, function (r) {
        try {
          if (r.type === 1) { if (/^body\s*>/.test(r.selectorText || '') || /^body\./.test(r.selectorText || '') || /^(#v3|#bar|#nav|main|body)$/.test(r.selectorText || '')) return; out.push(r.cssText); }
          else if (r.type === 4) {            /* @media */
            var m = (r.media && r.media.mediaText) || '';
            if (/print/.test(m) && !/screen/.test(m)) walk(r.cssRules, true);
            else if (/screen/.test(m) || /max-width|min-width/.test(m)) { if (/screen/.test(m) || window.matchMedia(m).matches) walk(r.cssRules, false); }
            else if (window.matchMedia(m).matches) walk(r.cssRules, false);
          } else if (r.type === 5 || r.type === 7) { out.push(r.cssText); } /* @font-face, @keyframes */
        } catch (e) {}
      });
    }
    Array.prototype.forEach.call(d.styleSheets, function (ss) { try { walk(ss.cssRules || [], false); } catch (e) {} });
    return out.join('\n');
  }

  /* ---------- rendu d'un élément dans un canvas (SVG + foreignObject, 100 % local) ---------- */
  function wrapFor(el, wpx, opts) {
    var root = d.createElement('div');
    root.id = 'doc'; root.className = (d.getElementById('doc') || {}).className || '';
    var lv = (d.getElementById('doc') && d.getElementById('doc').getAttribute('data-ec')) || '';
    if (lv) root.setAttribute('data-ec', lv);
    root.style.cssText = 'position:static;overflow:visible;background:#fff;inset:auto;width:' + wpx + 'px;';
    var db = d.createElement('div'); db.className = 'db'; db.style.cssText = 'max-width:none;padding:0;margin:0;width:' + wpx + 'px';
    var c = el.cloneNode(true);
    /* canvas → image, champs → valeur */
    var cs = el.querySelectorAll('canvas'), cc = c.querySelectorAll('canvas');
    for (var i = 0; i < cc.length && i < cs.length; i++) { try { var im = d.createElement('img'); im.src = cs[i].toDataURL('image/png'); im.setAttribute('style', cs[i].getAttribute('style') || ''); im.width = cs[i].width; im.height = cs[i].height; cc[i].parentNode.replaceChild(im, cc[i]); } catch (e) {} }
    Array.prototype.forEach.call(c.querySelectorAll('script,iframe,object,embed,video'), function (n) { n.remove(); });
    Array.prototype.forEach.call(c.querySelectorAll('img'), function (im2) { var s = String(im2.getAttribute('src') || ''); if (!/^(data:image\/|blob:)/i.test(s)) im2.remove(); });
    var st = 'margin:0;width:' + wpx + 'px;box-sizing:border-box;box-shadow:none;max-width:none;';
    if (opts && opts.static) st += 'position:static;left:auto;right:auto;bottom:auto;top:auto;';
    c.setAttribute('style', (c.getAttribute('style') || '') + ';' + st);
    db.appendChild(c); root.appendChild(db);
    return root;
  }
  function measure(root, wpx) {
    var host = d.createElement('div');
    host.style.cssText = 'position:fixed;left:-30000px;top:0;width:' + wpx + 'px;visibility:hidden;z-index:-1';
    var sty = d.createElement('style'); sty.textContent = allCss();
    host.appendChild(sty); host.appendChild(root); d.body.appendChild(host);
    return host;
  }
  function rasterize(root, wpx, hpx, scale) {
    var xml = new XMLSerializer();
    var sty = d.createElement('style'); sty.textContent = allCss();
    var holder = d.createElement('div');
    holder.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
    holder.style.cssText = 'width:' + wpx + 'px;height:' + hpx + 'px;background:#fff';
    holder.appendChild(sty); holder.appendChild(root);
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + wpx + '" height="' + hpx + '"><foreignObject x="0" y="0" width="' + wpx + '" height="' + hpx + '">' + xml.serializeToString(holder) + '</foreignObject></svg>';
    var url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    return new Promise(function (ok, ko) {
      var img = new Image();
      img.onload = function () {
        try {
          var cv = d.createElement('canvas'); cv.width = Math.round(wpx * scale); cv.height = Math.round(hpx * scale);
          var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height);
          x.drawImage(img, 0, 0, cv.width, cv.height); ok(cv);
        } catch (e) { ko(e); }
      };
      img.onerror = function () { ko(new Error('dessin de la feuille impossible')); };
      img.src = url;
    });
  }

  /* ---------- coupures : jamais au milieu d'une ligne de tableau ---------- */
  function breakpoints(host) {
    var base = host.getBoundingClientRect().top, ys = [];
    Array.prototype.forEach.call(host.querySelectorAll('tr,h2,h3,p,li,.ex-box,.ex-visas,.nt,.row'), function (e) {
      var r = e.getBoundingClientRect(); if (r.height > 0) ys.push(Math.round(r.top - base));
    });
    ys.sort(function (a, b) { return a - b; });
    return ys;
  }

  /* ---------- fabrication du PDF (JPEG par feuille) ---------- */
  function bytes(s) { var u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255; return u; }
  function dataToBytes(u) { var b = atob(u.split(',')[1]), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function buildPdf(pages, title) {
    var parts = [], off = 0, xref = [];
    function add(x) { var u = typeof x === 'string' ? bytes(x) : x; parts.push(u); off += u.length; }
    function obj(n, body) { xref[n] = off; add(n + ' 0 obj\n'); add(body); add('\nendobj\n'); }
    add('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
    var n = pages.length, kids = [];
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    for (var i = 0; i < n; i++) kids.push((3 + i * 3) + ' 0 R');
    obj(2, '<< /Type /Pages /Count ' + n + ' /Kids [' + kids.join(' ') + '] >>');
    for (var k = 0; k < n; k++) {
      var p = pages[k], a = 3 + k * 3, c = a + 1, im = a + 2;
      obj(a, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + p.wpt.toFixed(2) + ' ' + p.hpt.toFixed(2) + '] /Resources << /XObject << /Im0 ' + im + ' 0 R >> /ProcSet [/PDF /ImageC] >> /Contents ' + c + ' 0 R >>');
      var cont = 'q ' + p.wpt.toFixed(2) + ' 0 0 ' + p.hpt.toFixed(2) + ' 0 0 cm /Im0 Do Q';
      obj(c, '<< /Length ' + cont.length + ' >>\nstream\n' + cont + '\nendstream');
      xref[im] = off; add(im + ' 0 obj\n'); add('<< /Type /XObject /Subtype /Image /Width ' + p.px + ' /Height ' + p.py + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + p.jpg.length + ' >>\nstream\n'); add(p.jpg); add('\nendstream\nendobj\n');
    }
    var info = 3 + n * 3; obj(info, '<< /Title (' + String(title || 'Document').replace(/[^\x20-\x7E]/g, '').replace(/[()\\]/g, '') + ') /Producer (Excellencia Building) >>');
    var x0 = off, cnt = info + 1;
    add('xref\n0 ' + cnt + '\n0000000000 65535 f \n');
    for (var j = 1; j < cnt; j++) add(('0000000000' + xref[j]).slice(-10) + ' 00000 n \n');
    add('trailer\n<< /Size ' + cnt + ' /Root 1 0 R /Info ' + info + ' 0 R >>\nstartxref\n' + x0 + '\n%%EOF');
    return new Blob(parts, { type: 'application/pdf' });
  }

  function save(blob, name) {
    var nat = (w.EXBNativeDownload) || (w.parent && w.parent.EXBNativeDownload) || (w.top && w.top.EXBNativeDownload);
    if (nat && nat.save) return Promise.resolve(nat.save(blob, name));
    var u = URL.createObjectURL(blob), a = d.createElement('a');
    a.href = u; a.download = name; d.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
    return Promise.resolve();
  }

  /* ---------- fenêtre d'avancement ---------- */
  function overlay(t) {
    var o = d.getElementById('exbPdfWait');
    if (!o) {
      o = d.createElement('div'); o.id = 'exbPdfWait';
      o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(10,20,40,.6);display:grid;place-items:center;font-family:Arial,sans-serif';
      o.innerHTML = '<div style="background:#fff;border-radius:14px;padding:22px 26px;min-width:240px;text-align:center;box-shadow:0 10px 40px #0007"><div style="font:700 16px Arial;color:#12254a">Création du PDF…</div><div id="exbPdfWaitT" style="font:13px Arial;color:#51607e;margin-top:8px"></div><div style="height:6px;background:#e5ebf6;border-radius:4px;margin-top:12px;overflow:hidden"><div id="exbPdfWaitB" style="height:100%;width:5%;background:#e8590c;transition:width .2s"></div></div></div>';
      d.body.appendChild(o);
    }
    var tx = d.getElementById('exbPdfWaitT'); if (tx) tx.textContent = t || '';
    return o;
  }
  function progress(i, n, t) { overlay(t || ('Feuille ' + i + ' / ' + n)); var b = d.getElementById('exbPdfWaitB'); if (b) b.style.width = Math.max(5, Math.round(100 * i / Math.max(1, n))) + '%'; }
  function closeOverlay() { var o = d.getElementById('exbPdfWait'); if (o) o.remove(); }

  /* ---------- éléments à mettre en feuilles ---------- */
  function sources() {
    var doc = d.getElementById('doc'), root = doc ? doc.querySelector('.db') : null;
    if (!root) { var inl = d.querySelector('#inl .db'); root = inl; }
    if (!root) return null;
    var list = Array.prototype.filter.call(root.children, function (e) { return /(^|\s)(pg|ti)(\s|$)/.test(e.className) && e.offsetHeight > 0 && !/(^|\s)exf(\s|$)/.test(e.className); });
    return { root: root, pages: list, foot: root.querySelector('.ex-foot'), wm: root.querySelector('.ex-wm.on') };
  }
  function kindOf(e) { return /(^|\s)pl3(\s|$)/.test(e.className) ? 'a3l' : (/(^|\s)pl(\s|$)/.test(e.className) ? 'a4l' : 'a4'); }

  function run(opt) {
    opt = opt || {};
    var S = sources();
    if (!S || !S.pages.length) { note('Ouvrez d’abord la note de calcul ou le plan d’exécution (bouton « Note de calcul » ou « Plan d’exécution »).', 'warn', 6000); return Promise.resolve(false); }
    var title = (d.title || 'Document'); var nm = (S.root.querySelector('.ex-no,.ex-ttl b') || {}).textContent;
    var fileName = String(opt.name || ((nm ? nm.trim() + ' — ' : '') + 'Note de calcul')).replace(/[\\\/:*?"<>|]+/g, '-').slice(0, 110) + '.pdf';
    var out = [], total = S.pages.length, done = 0;
    try { window.dispatchEvent(new Event('beforeprint')); } catch (e) {}
    progress(0, total, 'Préparation…');

    /* pied de page commun, dessiné une seule fois par format */
    var footCache = {};
    function footCanvas(kind, wpx, scale) {
      var key = kind; if (footCache[key]) return Promise.resolve(footCache[key]);
      if (!S.foot) return Promise.resolve(null);
      var root = wrapFor(S.foot, wpx, { static: true }), host = measure(root, wpx);
      var h = Math.max(14, Math.ceil(root.getBoundingClientRect().height) + 2);
      return rasterize(wrapFor(S.foot, wpx, { static: true }), wpx, h, scale).then(function (cv) { host.remove(); footCache[key] = cv; return cv; }, function () { host.remove(); return null; });
    }

    function pageOut(kind, content, cvSlice, scale, partIdx) {
      var P = PAGES[kind], Wp = Math.round(P.W * MM), Hp = Math.round(P.H * MM);
      var cv = d.createElement('canvas'); cv.width = Math.round(Wp * scale); cv.height = Math.round(Hp * scale);
      var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height);
      x.drawImage(cvSlice.cv, 0, 0, cvSlice.cv.width, cvSlice.cv.height, Math.round(P.ml * MM * scale), Math.round(P.mt * MM * scale), Math.round(cvSlice.wpx * cvSlice.k * scale), Math.round(cvSlice.hpx * cvSlice.k * scale));
      return footCanvas(kind, Math.round((P.W - P.ml - P.mr) * MM), scale).then(function (fc) {
        if (fc) x.drawImage(fc, Math.round(P.ml * MM * scale), cv.height - fc.height - Math.round(4 * MM * scale) * 0.6);
        if (S.wm) {
          x.save(); x.translate(cv.width / 2, cv.height * 0.45); x.rotate(-Math.PI / 6); x.fillStyle = 'rgba(200,30,30,.13)';
          x.font = '900 ' + Math.round(96 * scale * (kind === 'a4' ? 1 : 1.2)) + 'px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle';
          x.fillText((S.wm.textContent || 'BROUILLON').trim() || 'BROUILLON', 0, 0); x.restore();
        }
        var u = cv.toDataURL('image/jpeg', 0.92); cv.width = cv.height = 0;
        out.push({ jpg: dataToBytes(u), px: Math.round(Wp * scale), py: Math.round(Hp * scale), wpt: P.W / 25.4 * 72, hpt: P.H / 25.4 * 72 });
      });
    }

    function onePage(e) {
      var kind = kindOf(e), P = PAGES[kind];
      var cw = Math.round((P.W - P.ml - P.mr) * MM), ch = Math.round((P.H - P.mt - P.mb) * MM);
      var scale = kind === 'a4' ? 2.6 : 2.0;
      var isCover = /(^|\s)ex-cv(\s|$)/.test(e.className);
      var root = wrapFor(e, cw);
      if (isCover) { var cl = root.querySelector('.ex-cv'); if (cl) cl.style.height = ch + 'px'; }
      var host = measure(root, cw);
      var hh = Math.ceil(root.getBoundingClientRect().height), ys = kind === 'a4' ? breakpoints(host) : [];
      host.remove();
      var k = 1;
      if (kind !== 'a4') { if (hh > ch) k = ch / hh; }
      var slices = [];
      if (kind === 'a4' && hh > ch + 2) {
        var start = 0;
        while (start < hh - 2) {
          var end = Math.min(hh, start + ch);
          if (end < hh) { var cut = 0; for (var i = 0; i < ys.length; i++) { if (ys[i] <= end && ys[i] > start + ch * 0.45) cut = ys[i]; } if (cut) end = cut; }
          slices.push([start, end]); start = end;
        }
      } else slices.push([0, Math.min(hh, kind === 'a4' ? ch : hh)]);
      var sc = scale;
      if (hh * sc > 15000) sc = 15000 / hh;
      return rasterize(wrapFor(e, cw), cw, Math.max(hh, 10), sc).then(function (big) {
        var chain = Promise.resolve();
        slices.forEach(function (s, idx) {
          chain = chain.then(function () {
            var sh = s[1] - s[0], cv = d.createElement('canvas'); cv.width = big.width; cv.height = Math.max(1, Math.round(sh * sc));
            var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
            cx.drawImage(big, 0, Math.round(s[0] * sc), big.width, cv.height, 0, 0, big.width, cv.height);
            return pageOut(kind, e, { cv: cv, wpx: cw, hpx: sh, k: k }, sc, idx).then(function () { cv.width = cv.height = 0; });
          });
        });
        return chain.then(function () { big.width = big.height = 0; });
      });
    }

    var chain = tick(60);
    S.pages.forEach(function (e, i) {
      chain = chain.then(function () { progress(i, total, 'Feuille ' + (i + 1) + ' / ' + total); return tick(20).then(function () { return onePage(e); }); }).then(function () { done++; });
    });
    return chain.then(function () {
      progress(total, total, 'Enregistrement…');
      var blob = buildPdf(out, title);
      return save(blob, fileName).then(function () { closeOverlay(); note('✓ PDF créé : ' + fileName + ' (' + out.length + ' page' + (out.length > 1 ? 's' : '') + ')', 'ok', 6000); try { window.dispatchEvent(new Event('afterprint')); } catch (e) {} return true; });
    }).catch(function (err) {
      closeOverlay(); try { window.dispatchEvent(new Event('afterprint')); } catch (e) {}
      note('Le PDF n’a pas pu être créé : ' + (err && err.message || err) + '. Essayez « Imprimer » puis « Enregistrer au format PDF ».', 'error', 9000);
      return false;
    });
  }

  w.EXBDocPDF = { _r: { wrapFor: wrapFor, measure: measure, rasterize: rasterize, allCss: allCss }, run: run, build: buildPdf, version: 'V99-correctifs-2' };
})(window, document);
