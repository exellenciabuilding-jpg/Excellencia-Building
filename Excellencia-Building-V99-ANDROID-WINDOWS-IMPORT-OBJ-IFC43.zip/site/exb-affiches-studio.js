/* Excellencia Building — Affiches : (1) logo modifiable sur les deux affiches ; (2) « Studio libre » pour créer des affiches sur n'importe quel contenu.
 * Aucune donnée existante n'est modifiée. Données : clés exb_poster_logo, exb_poster_logo_cfg, exb_studio_posters (stockage de l'appareil).
 * Pour retirer : supprimer la balise <script src="exb-affiches-studio.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_STUDIO) return;
  var $ = function (i) { return d.getElementById(i); };
  var K_LOGO = 'exb_poster_logo', K_CFG = 'exb_poster_logo_cfg', K_LIST = 'exb_studio_posters';
  function S() { try { return typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) { return null; } }
  function rd(k, def) { try { var v = S().getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function wr(k, v) { try { S().setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function note(t, k, ms) { try { w.notify && w.notify(t, k || 'ok', ms || 4000); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function uid() { return 'e' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function brand() {
    var I = null; try { I = w.EXBId && w.EXBId.get ? w.EXBId.get() : null; } catch (e) {}
    I = I || {};
    return { name: I.name || 'Excellencia Building', tagline: I.tagline || "L'excellence au cœur de vos constructions", phone: I.phone || '+243 810 644 554', email: I.email || 'Excellenciabuilding@gmail.com', address: I.address || 'Kinshasa, RDC', logo: I.logo || 'icon-192.png' };
  }
  /* image choisie → réduite (taille maximale) → data URL ; PNG conservé (transparence) pour les logos */
  function readImg(file, maxPx, keepPng, cb) {
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, maxPx / Math.max(im.naturalWidth, im.naturalHeight)), c = d.createElement('canvas');
        c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
        var x = c.getContext('2d');
        var png = keepPng || /png|webp|svg/i.test(file.type || '');
        if (!png) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
        x.drawImage(im, 0, 0, c.width, c.height);
        cb(c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.88));
      };
      im.onerror = function () { note('Image illisible.', 'error'); };
      im.src = r.result;
    };
    r.onerror = function () { note('Lecture du fichier impossible.', 'error'); };
    r.readAsDataURL(file);
  }
  function download(blob, name) {
    var u = URL.createObjectURL(blob), a = d.createElement('a');
    a.href = u; a.download = name; d.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 5000);
  }
  function css(id, txt) { if ($(id)) return; var s = d.createElement('style'); s.id = id; s.textContent = txt; d.head.appendChild(s); }

  /* =====================================================================
   *  1) LOGO DES DEUX AFFICHES EXCELLENCIA
   *  Le logo d'origine fait partie de l'image de fond : on « efface » sa zone en reconstituant le ciel
   *  (dégradé calculé depuis les bords de la zone), puis on pose le logo choisi par-dessus.
   * ===================================================================== */
  var ZONES = {
    poster: { rect: [146, 20, 424, 200], box: [150, 24, 266, 152] },
    software: { rect: [16, 6, 496, 282], box: [22, 10, 466, 262] }
  };
  var cache = {};
  function cfg() { var c = rd(K_CFG, null) || {}; return { z: c.z || 1, dx: c.dx || 0, dy: c.dy || 0 }; }
  function logoSrc() { try { return S().getItem(K_LOGO) || ''; } catch (e) { return ''; } }

  function coons(im, rect, wref) {
    var sc = im.naturalWidth / wref, c = d.createElement('canvas');
    c.width = im.naturalWidth; c.height = im.naturalHeight;
    var x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0);
    var x0 = Math.max(3, Math.round(rect[0] * sc)), y0 = Math.max(3, Math.round(rect[1] * sc)), x1 = Math.min(c.width - 3, Math.round(rect[2] * sc)), y1 = Math.min(c.height - 3, Math.round(rect[3] * sc));
    var W = x1 - x0, H = y1 - y0; if (W < 4 || H < 4) return c.toDataURL('image/jpeg', 0.92);
    var g = x.getImageData(x0 - 3, y0 - 3, W + 6, H + 6), D = g.data, GW = W + 6;
    function P(px, py) { var o = ((py + 3) * GW + (px + 3)) * 4; return [D[o], D[o + 1], D[o + 2]]; } /* px,py relatifs au coin de la zone */
    function avg(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]; }
    var T = [], B = [], L = [], R = [], i, j;
    for (i = 0; i < W; i++) { T[i] = avg(P(i, -1), P(i, -2)); B[i] = avg(P(i, H), P(i, H + 1)); }
    for (j = 0; j < H; j++) { L[j] = avg(P(-1, j), P(-2, j)); R[j] = avg(P(W, j), P(W + 1, j)); }
    var c00 = avg(T[0], L[0]), c10 = avg(T[W - 1], R[0]), c01 = avg(B[0], L[H - 1]), c11 = avg(B[W - 1], R[H - 1]);
    for (j = 0; j < H; j++) {
      var v = (j + 0.5) / H;
      for (i = 0; i < W; i++) {
        var u = (i + 0.5) / W, o = ((j + 3) * GW + (i + 3)) * 4;
        for (var k = 0; k < 3; k++) {
          var val = (1 - v) * T[i][k] + v * B[i][k] + (1 - u) * L[j][k] + u * R[j][k] -
            ((1 - u) * (1 - v) * c00[k] + u * (1 - v) * c10[k] + (1 - u) * v * c01[k] + u * v * c11[k]);
          D[o + k] = Math.max(0, Math.min(255, val + (Math.random() - 0.5) * 2.2));
        }
        D[o + 3] = 255;
      }
    }
    x.putImageData(g, x0 - 3, y0 - 3);
    return c.toDataURL('image/jpeg', 0.93);
  }
  function patched(kind, src, cb) {
    var key = kind + '|' + src.length + '|' + src.slice(-48);
    if (cache[kind] && cache[kind].key === key) return cb(cache[kind].out);
    var im = new Image();
    im.onload = function () { try { var out = coons(im, ZONES[kind].rect, 1024); cache[kind] = { key: key, out: out }; cb(out); } catch (e) { cb(null); } };
    im.onerror = function () { cb(null); };
    im.src = src;
  }
  function overlay(kind, paper) {
    var id = 'exbLogoOv_' + kind, el = $(id);
    if (!el) {
      el = d.createElement('img'); el.id = id; el.alt = 'Logo';
      el.style.cssText = 'position:absolute;object-fit:contain;pointer-events:none;z-index:6;display:none';
      paper.appendChild(el);
    }
    return el;
  }
  function place(kind, el) {
    var b = ZONES[kind].box, c = cfg(), cx = b[0] + b[2] / 2 + c.dx, cy = b[1] + b[3] / 2 + c.dy, W = b[2] * c.z, H = b[3] * c.z;
    el.style.left = (cx - W / 2) + 'px'; el.style.top = (cy - H / 2) + 'px'; el.style.width = W + 'px'; el.style.height = H + 'px';
  }
  var tries = { poster: 0, software: 0 };
  function applyOne(kind) {
    var paper = $(kind === 'poster' ? 'posterPaper' : 'softwarePosterPaper'); if (!paper) return;
    var logo = logoSrc(), ov = overlay(kind, paper);
    if (!logo) { ov.style.display = 'none'; restore(kind, paper); return; }
    var src = '';
    if (kind === 'poster') { try { src = typeof getPosterBg === 'function' ? getPosterBg() : ''; } catch (e) {} }
    else { var im = $('softwarePosterImage'); src = (im && (im.getAttribute('data-orig') || im.src)) || ''; }
    if (!src || src === location.href) { if (tries[kind]++ < 25) setTimeout(function () { applyOne(kind); }, 400); return; }
    tries[kind] = 0;
    ov.src = logo; place(kind, ov); ov.style.display = 'block';
    patched(kind, src, function (out) {
      if (!out) return;
      if (kind === 'poster') paper.style.backgroundImage = 'url(' + out + ')';
      else { var im2 = $('softwarePosterImage'); if (im2) { if (!im2.getAttribute('data-orig')) im2.setAttribute('data-orig', im2.src); im2.src = out; } }
    });
  }
  function restore(kind, paper) {
    if (kind === 'poster') { try { paper.style.backgroundImage = 'url(' + getPosterBg() + ')'; } catch (e) {} }
    else { var im = $('softwarePosterImage'); if (im && im.getAttribute('data-orig')) { im.src = im.getAttribute('data-orig'); im.removeAttribute('data-orig'); } }
  }
  function applyAll() { applyOne('poster'); applyOne('software'); }
  function wrapRender() {
    ['renderPoster', 'renderSoftwarePoster'].forEach(function (n) {
      var f = w[n]; if (typeof f !== 'function' || f.__exbLogo) return;
      var g = function () { var r = f.apply(this, arguments); try { applyOne(n === 'renderPoster' ? 'poster' : 'software'); } catch (e) {} return r; };
      g.__exbLogo = 1; w[n] = g;
    });
  }

  function logoCard() {
    var sec = $('affiches'); if (!sec || $('exbLogoCard')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    var card = d.createElement('div'); card.className = 'card no-print'; card.id = 'exbLogoCard'; card.style.gridColumn = '1/-1';
    card.innerHTML =
      '<h2>🔷 Logo des affiches</h2>' +
      '<p style="font-size:12.5px;color:#5e6877;margin:-4px 0 10px">Changez le logo des deux affiches (générale et logiciels). Le fond, les photos et les textes ne changent pas : seule la zone du logo est remplacée.</p>' +
      '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">' +
      '<div id="exbLogoPrev" style="width:130px;height:84px;border:1px dashed #9aa6b8;border-radius:10px;background:#fff center/contain no-repeat;display:grid;place-items:center;font-size:11px;color:#6b7a99;text-align:center">Logo d’origine</div>' +
      '<div style="flex:1;min-width:240px"><input type="file" id="exbLogoFile" accept="image/png,image/jpeg,image/webp,image/svg+xml">' +
      '<div class="actions" style="margin-top:8px"><button class="muted" id="exbLogoCo">🏢 Logo de l’entreprise</button><button class="muted" id="exbLogoRs">↩ Logo d’origine</button></div></div></div>' +
      '<div id="exbLogoSl" style="display:none;margin-top:10px">' +
      '<label>Taille <b id="exbLz_v"></b></label><input type="range" id="exbLz" min="40" max="160" step="2" style="width:100%">' +
      '<label>Position horizontale</label><input type="range" id="exbLx" min="-160" max="160" step="2" style="width:100%">' +
      '<label>Position verticale</label><input type="range" id="exbLy" min="-120" max="120" step="2" style="width:100%"></div>' +
      '<div class="msg" id="exbLogoMsg"></div>';
    grid.insertBefore(card, grid.firstChild);
    function sync() {
      var l = logoSrc(), c = cfg(), pv = $('exbLogoPrev');
      pv.style.backgroundImage = l ? 'url(' + l + ')' : 'none'; pv.textContent = l ? '' : 'Logo d’origine';
      $('exbLogoSl').style.display = l ? 'block' : 'none';
      $('exbLz').value = Math.round(c.z * 100); $('exbLx').value = c.dx; $('exbLy').value = c.dy; $('exbLz_v').textContent = Math.round(c.z * 100) + ' %';
    }
    function setLogo(u) { try { S().setItem(K_LOGO, u); } catch (e) { note('Stockage plein : logo non enregistré.', 'error'); } cache = {}; sync(); applyAll(); }
    $('exbLogoFile').onchange = function (e) { var f = e.target.files && e.target.files[0]; if (!f) return; readImg(f, 900, true, function (u) { setLogo(u); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo appliqué aux deux affiches.</span>'; }); e.target.value = ''; };
    $('exbLogoCo').onclick = function () {
      var u = brand().logo; if (!u) return;
      var im = new Image(); im.onload = function () { var c = d.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); try { setLogo(c.toDataURL('image/png')); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo de l’entreprise appliqué.</span>'; } catch (e) { note('Logo de l’entreprise illisible.', 'error'); } };
      im.onerror = function () { note('Logo de l’entreprise introuvable.', 'error'); }; im.src = u;
    };
    $('exbLogoRs').onclick = function () { try { S().removeItem(K_LOGO); S().removeItem(K_CFG); } catch (e) {} cache = {}; sync(); applyAll(); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo d’origine rétabli.</span>'; };
    function sl() { wr(K_CFG, { z: $('exbLz').value / 100, dx: +$('exbLx').value, dy: +$('exbLy').value }); $('exbLz_v').textContent = $('exbLz').value + ' %'; ['poster', 'software'].forEach(function (k) { var p = $(k === 'poster' ? 'posterPaper' : 'softwarePosterPaper'), o = p && $('exbLogoOv_' + k); if (o) place(k, o); }); }
    ['exbLz', 'exbLx', 'exbLy'].forEach(function (i) { $(i).oninput = sl; });
    sync();
  }

  /* =====================================================================
   *  2) STUDIO LIBRE
   * ===================================================================== */
  var FMT = {
    a4p: { l: 'A4 portrait', w: 794, h: 1123, mm: [210, 297], sc: 3 },
    a4l: { l: 'A4 paysage', w: 1123, h: 794, mm: [297, 210], sc: 3 },
    a3p: { l: 'A3 portrait', w: 1123, h: 1587, mm: [297, 420], sc: 2.2 },
    sq: { l: 'Carré (réseaux sociaux)', w: 1080, h: 1080, mm: null, sc: 2 },
    story: { l: 'Story / Statut (9:16)', w: 1080, h: 1920, mm: null, sc: 1.6 },
    ban: { l: 'Bannière (Facebook / LinkedIn)', w: 1200, h: 628, mm: null, sc: 2 }
  };
  var FONTS = [['Arial', 'Arial, Helvetica, sans-serif'], ['Arial Black', '"Arial Black", Arial, sans-serif'], ['Impact', 'Impact, Haettenschweiler, sans-serif'], ['Georgia', 'Georgia, serif'], ['Times', '"Times New Roman", Times, serif'], ['Trebuchet', '"Trebuchet MS", sans-serif'], ['Verdana', 'Verdana, sans-serif'], ['Manuscrit', 'Caveat, "Segoe Script", "Brush Script MT", cursive']];
  var PALETTES = {
    marine: ['#0f2a56', '#1e5fb4', 160, '#f2c94c'], ciel: ['#e8f3ff', '#7ab8f5', 170, '#12305e'], blanc: ['#ffffff', '#eef2f8', 180, '#12305e'],
    noir: ['#0b0f17', '#1d2635', 160, '#e0b54a'], vert: ['#0e3b2e', '#2e8b57', 160, '#ffd54a'], orange: ['#e8590c', '#f59f00', 150, '#ffffff'], rouge: ['#7a0c1c', '#c2283d', 160, '#ffffff']
  };
  var ST = { id: null, name: 'Mon affiche', fmt: 'a4p', bg: { c1: '#0f2a56', c2: '#1e5fb4', ang: 160, img: '', ovl: 0 }, els: [] };
  var sel = null, scale = 1, root = null, hist = [];

  function stageCss(el, e) {
    el.style.cssText = 'position:absolute;left:' + e.x + 'px;top:' + e.y + 'px;width:' + e.w + 'px;' + (e.t === 'text' ? '' : 'height:' + e.h + 'px;') +
      'opacity:' + (e.op == null ? 1 : e.op) + ';transform:rotate(' + (e.rot || 0) + 'deg);transform-origin:center;box-sizing:border-box;';
    if (e.t === 'text') {
      el.style.cssText += 'font-family:' + (FONTS[e.ff] ? FONTS[e.ff][1] : FONTS[0][1]) + ';font-size:' + e.fs + 'px;color:' + e.col + ';font-weight:' + (e.b ? 800 : 400) + ';font-style:' + (e.i ? 'italic' : 'normal') +
        ';text-align:' + (e.al || 'left') + ';line-height:' + (e.lh || 1.2) + ';white-space:pre-wrap;word-break:break-word;letter-spacing:' + (e.ls || 0) + 'px;' +
        (e.bg ? 'background:' + e.bg + ';padding:' + (e.pad || 10) + 'px;border-radius:' + (e.rad || 0) + 'px;' : '') + (e.up ? 'text-transform:uppercase;' : '') +
        (e.sh ? 'text-shadow:0 2px 8px rgba(0,0,0,.45);' : '');
    } else if (e.t === 'rect' || e.t === 'ellipse') {
      el.style.cssText += 'background:' + (e.fill || 'transparent') + ';border:' + (e.sw || 0) + 'px solid ' + (e.stroke || 'transparent') + ';border-radius:' + (e.t === 'ellipse' ? '50%' : (e.rad || 0) + 'px') + ';';
    } else if (e.t === 'line') {
      el.style.cssText += 'height:' + Math.max(1, e.h) + 'px;background:' + (e.fill || '#fff') + ';border-radius:' + (e.h / 2) + 'px;';
    }
  }
  function bgVal(b) {
    var s = 'linear-gradient(' + b.ang + 'deg,' + b.c1 + ',' + b.c2 + ')';
    if (b.img) return (b.ovl ? 'linear-gradient(rgba(0,0,0,' + b.ovl / 100 + '),rgba(0,0,0,' + b.ovl / 100 + ')),' : '') + 'url(' + b.img + ') center/cover no-repeat,' + s;
    return s;
  }
  /* construit la feuille ; interactive = vrai pour l'écran (sélection, poignées), faux pour l'export */
  function build(host, interactive) {
    var F = FMT[ST.fmt]; host.innerHTML = '';
    host.style.position = 'relative'; host.style.overflow = 'hidden'; host.style.width = F.w + 'px'; host.style.height = F.h + 'px'; host.style.background = bgVal(ST.bg);
    ST.els.forEach(function (e) {
      var el = d.createElement('div'); el.setAttribute('data-id', e.id); stageCss(el, e);
      if (e.t === 'text') el.textContent = e.tx;
      else if (e.t === 'img') {
        var im = d.createElement('img'); im.src = e.src; im.alt = ''; im.draggable = false;
        im.style.cssText = 'width:100%;height:100%;display:block;object-fit:' + (e.fit || 'contain') + ';border-radius:' + (e.rad || 0) + 'px;pointer-events:none';
        el.appendChild(im);
      }
      if (interactive) {
        el.style.cursor = 'move'; el.style.touchAction = 'none';
        if (e.id === sel) {
          el.style.outline = '2px dashed #1e88e5'; el.style.outlineOffset = '2px';
          var h = d.createElement('div'); h.setAttribute('data-h', '1');
          h.style.cssText = 'position:absolute;right:-12px;bottom:-12px;width:' + (26 / scale) + 'px;height:' + (26 / scale) + 'px;background:#1e88e5;border:2px solid #fff;border-radius:50%;cursor:nwse-resize;touch-action:none;transform:rotate(' + (-(e.rot || 0)) + 'deg)';
          el.appendChild(h);
        }
      }
      host.appendChild(el);
    });
  }
  function find(id) { for (var i = 0; i < ST.els.length; i++) if (ST.els[i].id === id) return ST.els[i]; return null; }
  function push() { hist.push(JSON.stringify(ST)); if (hist.length > 40) hist.shift(); }
  function undo() { if (!hist.length) return; var s = JSON.parse(hist.pop()); ST = s; if (!find(sel)) sel = null; refresh(); }

  function fit() {
    var wrap = $('exbsWrap'), F = FMT[ST.fmt]; if (!wrap) return;
    var avail = Math.max(240, ($('exbsBox').clientWidth || 700) - 4);
    scale = Math.min(1, avail / F.w);
    var maxH = Math.max(380, (w.innerHeight || 800) * 0.78);
    if (F.h * scale > maxH) scale = maxH / F.h;
    wrap.style.width = (F.w * scale) + 'px'; wrap.style.height = (F.h * scale) + 'px';
    $('exbsStage').style.transform = 'scale(' + scale + ')';
  }
  function refresh(keepProps) { fit(); build($('exbsStage'), true); if (!keepProps) props(); $('exbsFmtLbl').textContent = FMT[ST.fmt].l + ' — ' + FMT[ST.fmt].w + '×' + FMT[ST.fmt].h + ' px'; }

  /* ---------- glisser / redimensionner ---------- */
  function bindDrag() {
    var stage = $('exbsStage'), cur = null;
    stage.addEventListener('pointerdown', function (ev) {
      var h = ev.target.closest && ev.target.closest('[data-h]'), t = ev.target.closest && ev.target.closest('[data-id]');
      if (!t) { sel = null; refresh(); return; }
      var e = find(t.getAttribute('data-id')); if (!e) return;
      if (sel !== e.id) { sel = e.id; refresh(); }
      push();
      cur = { e: e, mode: h ? 'size' : 'move', x: ev.clientX, y: ev.clientY, ex: e.x, ey: e.y, ew: e.w, eh: e.h, moved: false };
      try { stage.setPointerCapture(ev.pointerId); } catch (x) {}
      ev.preventDefault();
    });
    stage.addEventListener('pointermove', function (ev) {
      if (!cur) return;
      var dx = (ev.clientX - cur.x) / scale, dy = (ev.clientY - cur.y) / scale; cur.moved = true;
      if (cur.mode === 'move') { cur.e.x = Math.round(cur.ex + dx); cur.e.y = Math.round(cur.ey + dy); }
      else { cur.e.w = Math.max(20, Math.round(cur.ew + dx)); if (cur.e.t !== 'text') cur.e.h = Math.max(cur.e.t === 'line' ? 2 : 20, Math.round(cur.eh + dy)); }
      var el = stage.querySelector('[data-id="' + cur.e.id + '"]');
      if (el) { el.style.left = cur.e.x + 'px'; el.style.top = cur.e.y + 'px'; el.style.width = cur.e.w + 'px'; if (cur.e.t !== 'text') el.style.height = cur.e.h + 'px'; }
    });
    function up() { if (!cur) return; var m = cur.moved; cur = null; if (!m) hist.pop(); refresh(); }
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
  }

  /* ---------- panneau de propriétés ---------- */
  function row(lbl, inner) { return '<label class="exbs-l">' + lbl + '</label>' + inner; }
  function props() {
    var P = $('exbsProps'); if (!P) return; var e = find(sel);
    if (!e) { P.innerHTML = '<p class="exbs-hint">Touchez un élément de l’affiche pour le modifier, ou ajoutez-en un avec les boutons ci-dessus.</p>'; return; }
    var h = '<b class="exbs-t">' + ({ text: 'Texte', img: 'Image', rect: 'Rectangle', ellipse: 'Cercle', line: 'Trait' }[e.t]) + ' sélectionné</b>';
    if (e.t === 'text') {
      h += '<textarea id="pp_tx" rows="3" class="exbs-in">' + esc(e.tx) + '</textarea>' +
        '<div class="exbs-2">' + row('Taille', '<input type="number" id="pp_fs" min="8" max="400" value="' + e.fs + '" class="exbs-in">') + row('Couleur', '<input type="color" id="pp_col" value="' + e.col + '" class="exbs-in">') + '</div>' +
        row('Police', '<select id="pp_ff" class="exbs-in">' + FONTS.map(function (f, i) { return '<option value="' + i + '"' + (i === (e.ff || 0) ? ' selected' : '') + '>' + f[0] + '</option>'; }).join('') + '</select>') +
        '<div class="exbs-btns"><button id="pp_b" class="' + (e.b ? 'on' : '') + '"><b>G</b></button><button id="pp_i" class="' + (e.i ? 'on' : '') + '"><i>I</i></button><button id="pp_up" class="' + (e.up ? 'on' : '') + '">AA</button><button id="pp_sh" class="' + (e.sh ? 'on' : '') + '">Ombre</button>' +
        '<button data-al="left" class="' + (e.al === 'left' || !e.al ? 'on' : '') + '">⬅</button><button data-al="center" class="' + (e.al === 'center' ? 'on' : '') + '">↔</button><button data-al="right" class="' + (e.al === 'right' ? 'on' : '') + '">➡</button></div>' +
        row('Interligne', '<input type="range" id="pp_lh" min="0.9" max="2" step="0.05" value="' + (e.lh || 1.2) + '" style="width:100%">') +
        '<div class="exbs-2">' + row('Fond du texte', '<input type="color" id="pp_bg" value="' + (e.bg || '#ffffff') + '" class="exbs-in">') + row('', '<button id="pp_nobg" class="exbs-mini">' + (e.bg ? 'Retirer le fond' : 'Aucun fond') + '</button>') + '</div>';
    } else if (e.t === 'rect' || e.t === 'ellipse' || e.t === 'line') {
      h += '<div class="exbs-2">' + row('Couleur', '<input type="color" id="pp_fill" value="' + (/^#/.test(e.fill) ? e.fill : '#1e5fb4') + '" class="exbs-in">') + (e.t === 'line' ? '' : row('Contour', '<input type="color" id="pp_stroke" value="' + (/^#/.test(e.stroke) ? e.stroke : '#ffffff') + '" class="exbs-in">')) + '</div>' +
        (e.t === 'rect' ? row('Coins arrondis', '<input type="range" id="pp_rad" min="0" max="200" value="' + (e.rad || 0) + '" style="width:100%">') : '') +
        (e.t === 'line' ? '' : row('Épaisseur du contour', '<input type="range" id="pp_sw" min="0" max="30" value="' + (e.sw || 0) + '" style="width:100%">'));
    } else if (e.t === 'img') {
      h += '<div class="exbs-btns"><button id="pp_swap">🖼 Changer l’image</button><button id="pp_fit">' + (e.fit === 'cover' ? 'Remplir (recadrer)' : 'Entière') + '</button></div>' +
        row('Coins arrondis (200 = rond)', '<input type="range" id="pp_rad" min="0" max="400" value="' + (e.rad || 0) + '" style="width:100%">');
    }
    h += row('Transparence', '<input type="range" id="pp_op" min="0.1" max="1" step="0.05" value="' + (e.op == null ? 1 : e.op) + '" style="width:100%">') +
      row('Rotation', '<input type="range" id="pp_rot" min="-180" max="180" value="' + (e.rot || 0) + '" style="width:100%">') +
      '<div class="exbs-btns"><button id="pp_front">⬆ Devant</button><button id="pp_back">⬇ Derrière</button><button id="pp_dup">⧉ Dupliquer</button><button id="pp_cx">⇔ Centrer</button><button id="pp_del" class="del">🗑 Supprimer</button></div>';
    P.innerHTML = h;
    var q = function (i) { return $(i); }, armed = false;
    function arm() { if (!armed) { push(); armed = true; } }
    function upd() {
      var el = $('exbsStage').querySelector('[data-id="' + e.id + '"]'); if (!el) return;
      stageCss(el, e); el.style.cursor = 'move'; el.style.touchAction = 'none'; el.style.outline = '2px dashed #1e88e5'; el.style.outlineOffset = '2px';
    }
    function on(id, ev, fn) { var x = q(id); if (x) x[ev] = fn; }
    function live(id, key, num) { on(id, 'onpointerdown', arm); on(id, 'onfocus', arm); on(id, 'oninput', function (ev) { arm(); e[key] = num ? +ev.target.value : ev.target.value; upd(); }); on(id, 'onchange', function () { refresh(true); }); }
    if (e.t === 'text') {
      on('pp_tx', 'onfocus', arm); on('pp_tx', 'oninput', function (ev) { arm(); e.tx = ev.target.value; refresh(true); });
      live('pp_fs', 'fs', 1); live('pp_col', 'col'); live('pp_lh', 'lh', 1);
      on('pp_ff', 'onchange', function (ev) { push(); e.ff = +ev.target.value; refresh(); });
      [['pp_b', 'b'], ['pp_i', 'i'], ['pp_up', 'up'], ['pp_sh', 'sh']].forEach(function (a) { on(a[0], 'onclick', function () { push(); e[a[1]] = !e[a[1]]; refresh(); }); });
      Array.prototype.forEach.call(P.querySelectorAll('[data-al]'), function (b) { b.onclick = function () { push(); e.al = b.getAttribute('data-al'); refresh(); }; });
      on('pp_bg', 'onpointerdown', arm); on('pp_bg', 'oninput', function (ev) { arm(); e.bg = ev.target.value; upd(); }); on('pp_bg', 'onchange', function () { refresh(true); });
      on('pp_nobg', 'onclick', function () { push(); e.bg = ''; refresh(); });
    } else if (e.t === 'img') {
      on('pp_swap', 'onclick', function () { pickImage(function (u) { push(); e.src = u; refresh(); }); });
      on('pp_fit', 'onclick', function () { push(); e.fit = e.fit === 'cover' ? 'contain' : 'cover'; refresh(); });
      on('pp_rad', 'onpointerdown', arm); on('pp_rad', 'oninput', function (ev) { arm(); e.rad = +ev.target.value; var im = $('exbsStage').querySelector('[data-id="' + e.id + '"] img'); if (im) im.style.borderRadius = e.rad + 'px'; });
    } else {
      live('pp_fill', 'fill'); live('pp_stroke', 'stroke'); live('pp_rad', 'rad', 1); live('pp_sw', 'sw', 1);
    }
    live('pp_op', 'op', 1); live('pp_rot', 'rot', 1);
    on('pp_front', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); ST.els.push(e); refresh(); });
    on('pp_back', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); ST.els.unshift(e); refresh(); });
    on('pp_dup', 'onclick', function () { push(); var c = JSON.parse(JSON.stringify(e)); c.id = uid(); c.x += 24; c.y += 24; ST.els.push(c); sel = c.id; refresh(); });
    on('pp_cx', 'onclick', function () { push(); e.x = Math.round((FMT[ST.fmt].w - e.w) / 2); refresh(); });
    on('pp_del', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); sel = null; refresh(); });
  }

  function pickImage(cb, keepPng) {
    var i = d.createElement('input'); i.type = 'file'; i.accept = 'image/png,image/jpeg,image/webp,image/svg+xml';
    i.onchange = function () { var f = i.files && i.files[0]; if (f) readImg(f, 1800, keepPng !== false, cb); };
    i.click();
  }
  function add(e) { push(); e.id = uid(); ST.els.push(e); sel = e.id; refresh(); }
  function addText(tx, o) { var F = FMT[ST.fmt]; add(Object.assign({ t: 'text', tx: tx, x: Math.round(F.w * 0.08), y: Math.round(F.h * 0.12), w: Math.round(F.w * 0.84), h: 60, fs: Math.round(F.w / 16), col: bgIsDark() ? '#ffffff' : '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 }, o || {})); }
  function bgIsDark() { var c = ST.bg.c1.replace('#', ''); if (c.length === 3) c = c.replace(/./g, '$&$&'); var r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16); return (r * 299 + g * 587 + b * 114) / 1000 < 150 || !!ST.bg.img; }

  /* ---------- fond ---------- */
  function bgPanel() {
    var P = $('exbsBg'); var b = ST.bg;
    P.innerHTML = '<div class="exbs-pal">' + Object.keys(PALETTES).map(function (k) { var p = PALETTES[k]; return '<button data-pal="' + k + '" title="' + k + '" style="background:linear-gradient(' + p[2] + 'deg,' + p[0] + ',' + p[1] + ')"></button>'; }).join('') + '</div>' +
      '<div class="exbs-2">' + row('Couleur 1', '<input type="color" id="bg_c1" value="' + b.c1 + '" class="exbs-in">') + row('Couleur 2', '<input type="color" id="bg_c2" value="' + b.c2 + '" class="exbs-in">') + '</div>' +
      row('Angle du dégradé', '<input type="range" id="bg_ang" min="0" max="360" value="' + b.ang + '" style="width:100%">') +
      '<div class="exbs-btns"><button id="bg_img">🖼 Photo de fond</button><button id="bg_noimg">Retirer la photo</button></div>' +
      row('Assombrir la photo', '<input type="range" id="bg_ovl" min="0" max="85" value="' + b.ovl + '" style="width:100%">');
    Array.prototype.forEach.call(P.querySelectorAll('[data-pal]'), function (x) { x.onclick = function () { var p = PALETTES[x.getAttribute('data-pal')]; push(); b.c1 = p[0]; b.c2 = p[1]; b.ang = p[2]; ST.els.forEach(function (e) { if (e.t === 'text' && (e.col === '#ffffff' || e.col === '#12305e')) e.col = bgIsDark() ? '#ffffff' : '#12305e'; }); bgPanel(); refresh(); }; });
    var lv = function (id, k, n) { $(id).oninput = function (ev) { b[k] = n ? +ev.target.value : ev.target.value; $('exbsStage').style.background = bgVal(b); }; $(id).onchange = function () { push(); refresh(true); }; };
    lv('bg_c1', 'c1'); lv('bg_c2', 'c2'); lv('bg_ang', 'ang', 1); lv('bg_ovl', 'ovl', 1);
    $('bg_img').onclick = function () { pickImage(function (u) { push(); b.img = u; refresh(); }, false); };
    $('bg_noimg').onclick = function () { push(); b.img = ''; refresh(); };
  }

  /* ---------- modèles ---------- */
  function logoSrcForStudio() { return logoSrc() || brand().logo; }
  function head(F, dark) {
    var B = brand(), W = F.w, m = Math.round(W * 0.06);
    return [
      { t: 'img', src: logoSrcForStudio(), x: m, y: Math.round(W * 0.05), w: Math.round(W * 0.16), h: Math.round(W * 0.16), fit: 'contain', op: 1, rad: 0 },
      { t: 'text', tx: B.name.toUpperCase(), x: m + Math.round(W * 0.18), y: Math.round(W * 0.075), w: Math.round(W * 0.6), h: 40, fs: Math.round(W / 26), col: dark ? '#ffffff' : '#12305e', b: true, al: 'left', ff: 0, lh: 1.1, ls: 1 },
      { t: 'text', tx: B.tagline, x: m + Math.round(W * 0.18), y: Math.round(W * 0.075) + Math.round(W / 20), w: Math.round(W * 0.6), h: 30, fs: Math.round(W / 46), col: dark ? '#cfe3ff' : '#42526e', b: false, i: true, al: 'left', ff: 3, lh: 1.2 }
    ];
  }
  function foot(F, dark, gold) {
    var B = brand(), W = F.w, H = F.h, m = Math.round(W * 0.06);
    return [
      { t: 'rect', x: 0, y: H - Math.round(W * 0.16), w: W, h: Math.round(W * 0.16), fill: dark ? 'rgba(0,0,0,.35)' : '#12305e', sw: 0, rad: 0 },
      { t: 'text', tx: '📞 ' + B.phone + '    ✉ ' + B.email, x: m, y: H - Math.round(W * 0.135), w: W - 2 * m, h: 30, fs: Math.round(W / 36), col: '#ffffff', b: true, al: 'center', ff: 0, lh: 1.2 },
      { t: 'text', tx: '📍 ' + B.address, x: m, y: H - Math.round(W * 0.075), w: W - 2 * m, h: 30, fs: Math.round(W / 40), col: gold || '#f2c94c', b: false, al: 'center', ff: 0, lh: 1.2 }
    ];
  }
  var TPL = {
    vide: { l: 'Page vide', pal: 'marine', f: function () { return []; } },
    annonce: {
      l: 'Annonce / Événement', pal: 'marine', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06), G = PALETTES.marine[3];
        return head(F, true).concat([
          { t: 'rect', x: m, y: Math.round(H * 0.24), w: Math.round(W * 0.2), h: 8, fill: G, rad: 4, sw: 0 },
          { t: 'text', tx: "TITRE DE L'ANNONCE", x: m, y: Math.round(H * 0.27), w: W - 2 * m, h: 200, fs: Math.round(W / 10), col: '#ffffff', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: 'Sous-titre ou message d’accroche', x: m, y: Math.round(H * 0.5), w: W - 2 * m, h: 80, fs: Math.round(W / 22), col: '#cfe3ff', b: false, al: 'left', ff: 3, lh: 1.25 },
          { t: 'text', tx: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', x: m, y: Math.round(H * 0.6), w: W - 2 * m, h: 160, fs: Math.round(W / 24), col: '#ffffff', b: true, al: 'left', ff: 0, lh: 1.55 }
        ], foot(F, true));
      }
    },
    emploi: {
      l: 'Offre d’emploi / Recrutement', pal: 'blanc', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06);
        return [{ t: 'rect', x: 0, y: 0, w: W, h: Math.round(H * 0.3), fill: '#12305e', sw: 0, rad: 0 }].concat(head(F, true), [
          { t: 'text', tx: 'NOUS RECRUTONS', x: m, y: Math.round(H * 0.17), w: W - 2 * m, h: 100, fs: Math.round(W / 11), col: '#f2c94c', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: 'Poste : Ingénieur / Technicien…', x: m, y: Math.round(H * 0.35), w: W - 2 * m, h: 70, fs: Math.round(W / 17), col: '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'Profil recherché\n• Diplôme : …\n• Expérience : … ans\n• Compétences : …\n\nNous offrons\n• Contrat : …\n• Rémunération attractive', x: m, y: Math.round(H * 0.44), w: W - 2 * m, h: 360, fs: Math.round(W / 26), col: '#1c2b45', b: false, al: 'left', ff: 0, lh: 1.5 },
          { t: 'text', tx: 'Envoyez votre CV avant le … à ' + brand().email, x: m, y: Math.round(H * 0.77), w: W - 2 * m, h: 70, fs: Math.round(W / 24), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.25, bg: '#f2c94c', pad: 16, rad: 14 }
        ], foot(F, false));
      }
    },
    promo: {
      l: 'Promotion / Offre spéciale', pal: 'orange', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06);
        return head(F, true).concat([
          { t: 'text', tx: 'OFFRE SPÉCIALE', x: m, y: Math.round(H * 0.24), w: W - 2 * m, h: 90, fs: Math.round(W / 12), col: '#ffffff', b: true, al: 'center', ff: 1, lh: 1.05, sh: true },
          { t: 'ellipse', x: Math.round(W * 0.2), y: Math.round(H * 0.36), w: Math.round(W * 0.6), h: Math.round(W * 0.6), fill: '#ffffff', stroke: '#12305e', sw: 10 },
          { t: 'text', tx: '-20 %', x: Math.round(W * 0.2), y: Math.round(H * 0.36) + Math.round(W * 0.18), w: Math.round(W * 0.6), h: 200, fs: Math.round(W / 4.2), col: '#e8590c', b: true, al: 'center', ff: 1, lh: 1 },
          { t: 'text', tx: 'sur …  jusqu’au …', x: Math.round(W * 0.2), y: Math.round(H * 0.36) + Math.round(W * 0.44), w: Math.round(W * 0.6), h: 60, fs: Math.round(W / 24), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'Contactez-nous dès maintenant !', x: m, y: Math.round(H * 0.8), w: W - 2 * m, h: 60, fs: Math.round(W / 20), col: '#ffffff', b: true, al: 'center', ff: 0, lh: 1.2 }
        ], foot(F, true, '#ffffff'));
      }
    },
    avis: {
      l: 'Avis / Communiqué', pal: 'blanc', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.08);
        return head(F, false).concat([
          { t: 'rect', x: m, y: Math.round(H * 0.2), w: W - 2 * m, h: 6, fill: '#c9a227', rad: 3, sw: 0 },
          { t: 'text', tx: 'COMMUNIQUÉ', x: m, y: Math.round(H * 0.23), w: W - 2 * m, h: 100, fs: Math.round(W / 10), col: '#12305e', b: true, al: 'center', ff: 4, lh: 1.1, ls: 4 },
          { t: 'text', tx: 'Objet : …', x: m, y: Math.round(H * 0.34), w: W - 2 * m, h: 60, fs: Math.round(W / 20), col: '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'La direction de ' + brand().name + ' porte à la connaissance de sa clientèle et du public que …\n\nPour toute information complémentaire, veuillez nous contacter.', x: m, y: Math.round(H * 0.42), w: W - 2 * m, h: 380, fs: Math.round(W / 26), col: '#1c2b45', b: false, al: 'left', ff: 3, lh: 1.6 },
          { t: 'text', tx: 'Fait à Kinshasa, le …\nLa Direction', x: m, y: Math.round(H * 0.72), w: W - 2 * m, h: 90, fs: Math.round(W / 26), col: '#12305e', b: true, al: 'right', ff: 3, lh: 1.4 }
        ], foot(F, false));
      }
    },
    formation: {
      l: 'Formation / Séminaire', pal: 'noir', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06), G = PALETTES.noir[3];
        return head(F, true).concat([
          { t: 'text', tx: 'SESSION DE FORMATION', x: m, y: Math.round(H * 0.23), w: W - 2 * m, h: 50, fs: Math.round(W / 26), col: G, b: true, al: 'left', ff: 0, lh: 1.2, ls: 3 },
          { t: 'text', tx: 'Thème de la formation', x: m, y: Math.round(H * 0.27), w: W - 2 * m, h: 180, fs: Math.round(W / 11), col: '#ffffff', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: '• Objectif 1\n• Objectif 2\n• Objectif 3\n• Attestation de participation', x: m, y: Math.round(H * 0.47), w: W - 2 * m, h: 240, fs: Math.round(W / 22), col: '#e8edf5', b: false, al: 'left', ff: 0, lh: 1.6 },
          { t: 'text', tx: 'Frais : … $   |   Durée : …   |   Début : …', x: m, y: Math.round(H * 0.72), w: W - 2 * m, h: 60, fs: Math.round(W / 24), col: '#0b0f17', b: true, al: 'center', ff: 0, lh: 1.25, bg: G, pad: 16, rad: 14 }
        ], foot(F, true, G));
      }
    }
  };
  function applyTpl(k) {
    var T = TPL[k]; push();
    ST.els = []; sel = null; var p = PALETTES[T.pal]; ST.bg = { c1: p[0], c2: p[1], ang: p[2], img: '', ovl: 0 };
    T.f(FMT[ST.fmt]).forEach(function (e) { e.id = uid(); e.op = e.op == null ? 1 : e.op; e.rot = e.rot || 0; ST.els.push(e); });
    bgPanel(); refresh();
  }

  /* ---------- changement de format : tout est remis à l'échelle ---------- */
  function setFmt(k) {
    if (k === ST.fmt) return; push();
    var A = FMT[ST.fmt], B = FMT[k], sx = B.w / A.w, sy = B.h / A.h, sf = Math.min(sx, sy);
    ST.els.forEach(function (e) { e.x = Math.round(e.x * sx); e.y = Math.round(e.y * sy); e.w = Math.round(e.w * sx); e.h = Math.round(e.h * (e.t === 'img' || e.t === 'ellipse' ? sf : sy)); if (e.t === 'text') e.fs = Math.max(8, Math.round(e.fs * sf)); });
    ST.fmt = k; refresh();
  }

  /* ---------- enregistrement ---------- */
  function listAll() { return rd(K_LIST, []) || []; }
  function saveCur() {
    var nm = ($('exbsName').value || '').trim() || 'Mon affiche'; ST.name = nm;
    var L = listAll(); if (!ST.id) ST.id = uid();
    var o = JSON.parse(JSON.stringify(ST)); o.saved = new Date().toISOString();
    var i = L.map(function (x) { return x.id; }).indexOf(ST.id); if (i >= 0) L[i] = o; else L.unshift(o);
    if (!wr(K_LIST, L)) { note('Enregistrement impossible : espace de stockage plein. Supprimez d’anciennes affiches.', 'error', 7000); return; }
    note('✓ Affiche « ' + nm + ' » enregistrée.', 'ok'); mine();
  }
  function mine() {
    var L = listAll(), el = $('exbsMine'); if (!el) return;
    el.innerHTML = L.length ? L.map(function (x) {
      return '<div class="exbs-it"><div><b>' + esc(x.name) + '</b><span>' + (FMT[x.fmt] ? FMT[x.fmt].l : '') + ' · ' + (x.saved || '').slice(0, 10) + '</span></div><button data-o="' + x.id + '">Ouvrir</button><button data-x="' + x.id + '" class="del">🗑</button></div>';
    }).join('') : '<p class="exbs-hint">Aucune affiche enregistrée pour l’instant.</p>';
    Array.prototype.forEach.call(el.querySelectorAll('[data-o]'), function (b) { b.onclick = function () { var x = listAll().filter(function (y) { return y.id === b.getAttribute('data-o'); })[0]; if (x) { push(); ST = JSON.parse(JSON.stringify(x)); sel = null; $('exbsName').value = ST.name; $('exbsFmt').value = ST.fmt; bgPanel(); refresh(); note('Affiche ouverte.', 'ok'); } }; });
    Array.prototype.forEach.call(el.querySelectorAll('[data-x]'), function (b) { b.onclick = function () { if (!confirm('Supprimer cette affiche enregistrée ?')) return; wr(K_LIST, listAll().filter(function (y) { return y.id !== b.getAttribute('data-x'); })); mine(); }; });
  }

  /* ---------- export ---------- */
  function render(cb) {
    if (typeof w.html2canvas !== 'function') { note('Export impossible : le moteur d’image n’est pas chargé.', 'error', 7000); return; }
    var F = FMT[ST.fmt], host = d.createElement('div');
    host.style.cssText = 'position:fixed;left:-100000px;top:0;';
    var st = d.createElement('div'); host.appendChild(st); d.body.appendChild(host); build(st, false);
    note('Création de l’affiche…', 'info', 2500);
    var imgs = Array.prototype.slice.call(st.querySelectorAll('img')), n = imgs.length, go = function () {
      setTimeout(function () {
        w.html2canvas(st, { scale: F.sc, backgroundColor: '#ffffff', useCORS: false, logging: false, width: F.w, height: F.h }).then(function (c) { host.remove(); cb(c); }, function (e) { host.remove(); note('Export impossible : ' + (e && e.message || e), 'error', 8000); });
      }, 120);
    };
    if (!n) return go();
    imgs.forEach(function (im) { var f = function () { if (--n === 0) go(); }; if (im.complete) f(); else { im.onload = f; im.onerror = f; } });
  }
  function fname() { return (ST.name || 'affiche').replace(/[\\/:*?"<>|]+/g, '-').trim() || 'affiche'; }
  function exportPng() { render(function (c) { c.toBlob(function (b) { if (b) { download(b, fname() + '.png'); note('✓ Image enregistrée.', 'ok'); } }, 'image/png'); }); }
  function exportPdf() {
    var J = w.jspdf && w.jspdf.jsPDF; if (!J) { note('Export PDF impossible : le moteur PDF n’est pas chargé.', 'error', 7000); return; }
    render(function (c) {
      var F = FMT[ST.fmt], mm = F.mm || [Math.round(F.w * 0.2646), Math.round(F.h * 0.2646)];
      var pdf = new J({ orientation: mm[0] > mm[1] ? 'l' : 'p', unit: 'mm', format: mm, compress: true });
      pdf.addImage(c.toDataURL('image/jpeg', 0.93), 'JPEG', 0, 0, mm[0], mm[1]);
      download(pdf.output('blob'), fname() + '.pdf'); note('✓ PDF enregistré.', 'ok');
    });
  }

  /* ---------- interface ---------- */
  function ui() {
    css('exbsCss',
      '.exbs-tabs{display:flex;gap:8px;margin:0 0 12px;flex-wrap:wrap}.exbs-tabs button{padding:11px 16px;border-radius:999px;border:1px solid #c9d3df;background:#fff;color:#12305e;font:700 14px Arial,sans-serif;cursor:pointer}.exbs-tabs button.on{background:#12305e;color:#fff;border-color:#12305e}' +
      '#exbsRoot{display:none}#exbsRoot.on{display:block}.exbs-grid{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:14px;align-items:start}@media(max-width:980px){.exbs-grid{grid-template-columns:1fr}}' +
      '.exbs-card{background:#fff;border:1px solid #dbe3ee;border-radius:14px;padding:12px;color:#172033}.exbs-card h3{margin:0 0 8px;font-size:15px;color:#12305e}' +
      '.exbs-bar{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}.exbs-bar button,.exbs-btns button,.exbs-mini,.exbs-it button{padding:9px 12px;border-radius:9px;border:1px solid #c9d3df;background:#f4f7fb;color:#12305e;font:700 13px Arial,sans-serif;cursor:pointer}' +
      '.exbs-bar button.p{background:#12305e;color:#fff;border-color:#12305e}.exbs-bar button.g{background:#c9a227;color:#12254a;border-color:#c9a227}.exbs-btns{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.exbs-btns button.on{background:#12305e;color:#fff}.exbs-btns button.del,.exbs-it button.del{color:#b91c1c}' +
      '.exbs-in{width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial,sans-serif;background:#fff;color:#172033}input[type=color].exbs-in{padding:2px;height:38px}.exbs-2{display:grid;grid-template-columns:1fr 1fr;gap:8px}' +
      '.exbs-l{display:block;font:700 12px Arial,sans-serif;color:#12305e;margin:8px 0 3px}.exbs-t{display:block;color:#12305e;margin-bottom:6px}.exbs-hint{font-size:12.5px;color:#5e6877;margin:6px 0}' +
      '#exbsBox{background:#dfe4ec;border-radius:12px;padding:10px;overflow:auto;display:flex;justify-content:center}#exbsWrap{position:relative;box-shadow:0 4px 18px #0004;background:#fff;flex:none}#exbsStage{transform-origin:top left;user-select:none;-webkit-user-select:none}' +
      '.exbs-pal{display:flex;gap:8px;flex-wrap:wrap}.exbs-pal button{width:40px;height:40px;border-radius:10px;border:2px solid #fff;box-shadow:0 0 0 1px #c9d3df;cursor:pointer}' +
      '.exbs-it{display:flex;gap:6px;align-items:center;border-top:1px solid #e3e9f2;padding:7px 0}.exbs-it div{flex:1;min-width:0}.exbs-it b{display:block;font-size:13px;color:#12305e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.exbs-it span{font-size:11px;color:#6b7a99}' +
      '@media print{#exbsRoot,.exbs-tabs{display:none!important}}');
    var sec = $('affiches'); if (!sec || $('exbsRoot')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    var tabs = d.createElement('div'); tabs.className = 'exbs-tabs no-print';
    tabs.innerHTML = '<button id="exbsT1" class="on">🖼️ Affiches Excellencia</button><button id="exbsT2">🎨 Studio libre (autres contenus)</button>';
    sec.insertBefore(tabs, grid);
    root = d.createElement('div'); root.id = 'exbsRoot'; root.className = 'no-print';
    root.innerHTML =
      '<div class="exbs-card" style="margin-bottom:12px"><h3>🎨 Studio libre — créez une affiche sur n’importe quel sujet</h3>' +
      '<p class="exbs-hint" style="margin-top:0">Choisissez un modèle ou partez d’une page vide, ajoutez vos textes, photos et formes, déplacez-les du doigt ou à la souris, puis exportez en image ou en PDF.</p>' +
      '<div class="exbs-2"><div><label class="exbs-l">Nom de l’affiche</label><input id="exbsName" class="exbs-in" value="Mon affiche"></div><div><label class="exbs-l">Format</label><select id="exbsFmt" class="exbs-in">' + Object.keys(FMT).map(function (k) { return '<option value="' + k + '">' + FMT[k].l + '</option>'; }).join('') + '</select></div></div>' +
      '<label class="exbs-l">Modèle de départ</label><select id="exbsTpl" class="exbs-in"><option value="">— Choisir un modèle —</option>' + Object.keys(TPL).map(function (k) { return '<option value="' + k + '">' + TPL[k].l + '</option>'; }).join('') + '</select></div>' +
      '<div class="exbs-grid"><div class="exbs-card"><div class="exbs-bar"><button id="ad_t">＋ Texte</button><button id="ad_i">＋ Photo</button><button id="ad_l">＋ Logo</button><button id="ad_r">▭ Rectangle</button><button id="ad_e">◯ Cercle</button><button id="ad_ln">▬ Trait</button><button id="ad_u">↶ Annuler</button></div>' +
      '<div id="exbsBox"><div id="exbsWrap"><div id="exbsStage"></div></div></div><div class="exbs-hint" id="exbsFmtLbl" style="text-align:center"></div>' +
      '<div class="exbs-bar" style="margin-top:8px"><button class="p" id="ex_save">💾 Enregistrer</button><button class="g" id="ex_png">⬇ Image (PNG)</button><button class="g" id="ex_pdf">📄 PDF</button><button id="ex_new">🆕 Nouvelle</button></div></div>' +
      '<div><div class="exbs-card" id="exbsPropsCard"><h3>Modifier</h3><div id="exbsProps"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Fond</h3><div id="exbsBg"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Mes affiches</h3><div id="exbsMine"></div></div></div></div>';
    sec.appendChild(root);
    $('exbsT1').onclick = function () { grid.style.display = ''; root.classList.remove('on'); $('exbsT1').classList.add('on'); $('exbsT2').classList.remove('on'); setTimeout(function () { w.exbFitPosters && w.exbFitPosters(); }, 50); };
    $('exbsT2').onclick = function () { grid.style.display = 'none'; root.classList.add('on'); $('exbsT2').classList.add('on'); $('exbsT1').classList.remove('on'); setTimeout(function () { fit(); refresh(true); }, 30); };
    $('exbsFmt').onchange = function () { setFmt(this.value); };
    $('exbsName').oninput = function () { ST.name = this.value; };
    $('exbsTpl').onchange = function () { if (this.value) { if (ST.els.length && !confirm('Remplacer le contenu actuel par ce modèle ?')) { this.value = ''; return; } applyTpl(this.value); this.value = ''; } };
    $('ad_t').onclick = function () { addText('Votre texte ici', {}); };
    $('ad_i').onclick = function () { pickImage(function (u) { var F = FMT[ST.fmt]; add({ t: 'img', src: u, x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.3), w: Math.round(F.w * 0.8), h: Math.round(F.w * 0.5), fit: 'cover', op: 1, rot: 0, rad: 0 }); }); };
    $('ad_l').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'img', src: logoSrcForStudio(), x: Math.round(F.w * 0.06), y: Math.round(F.h * 0.04), w: Math.round(F.w * 0.2), h: Math.round(F.w * 0.2), fit: 'contain', op: 1, rot: 0, rad: 0 }); };
    $('ad_r').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'rect', x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.4), w: Math.round(F.w * 0.8), h: Math.round(F.h * 0.12), fill: '#c9a227', stroke: '#ffffff', sw: 0, rad: 16, op: 1, rot: 0 }); };
    $('ad_e').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'ellipse', x: Math.round(F.w * 0.3), y: Math.round(F.h * 0.4), w: Math.round(F.w * 0.4), h: Math.round(F.w * 0.4), fill: '#ffffff', stroke: '#12305e', sw: 0, op: 1, rot: 0 }); };
    $('ad_ln').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'line', x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.5), w: Math.round(F.w * 0.8), h: 8, fill: '#f2c94c', op: 1, rot: 0 }); };
    $('ad_u').onclick = undo;
    $('ex_save').onclick = saveCur; $('ex_png').onclick = exportPng; $('ex_pdf').onclick = exportPdf;
    $('ex_new').onclick = function () { if (ST.els.length && !confirm('Commencer une nouvelle affiche ? (pensez à enregistrer l’actuelle)')) return; ST = { id: null, name: 'Mon affiche', fmt: ST.fmt, bg: { c1: '#0f2a56', c2: '#1e5fb4', ang: 160, img: '', ovl: 0 }, els: [] }; sel = null; hist = []; $('exbsName').value = ST.name; bgPanel(); refresh(); };
    d.addEventListener('keydown', function (ev) {
      if (!root.classList.contains('on')) return; var t = ev.target && ev.target.tagName; if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return;
      var e = find(sel); if (!e) return;
      if (ev.key === 'Delete' || ev.key === 'Backspace') { push(); ST.els.splice(ST.els.indexOf(e), 1); sel = null; refresh(); ev.preventDefault(); }
      var st = ev.shiftKey ? 20 : 4, mv = { ArrowLeft: [-st, 0], ArrowRight: [st, 0], ArrowUp: [0, -st], ArrowDown: [0, st] }[ev.key];
      if (mv) { e.x += mv[0]; e.y += mv[1]; refresh(true); ev.preventDefault(); }
    });
    w.addEventListener('resize', function () { if (root.classList.contains('on')) { fit(); build($('exbsStage'), true); } });
    bindDrag(); bgPanel(); mine(); props();
  }

  function start() {
    try { logoCard(); } catch (e) { try { console.error('logo affiches', e); } catch (x) {} }
    try { ui(); } catch (e) { try { console.error('studio affiches', e); } catch (x) {} }
    wrapRender(); applyAll();
  }
  d.addEventListener('exb-images-ready', function () { cache = {}; tries = { poster: 0, software: 0 }; setTimeout(applyAll, 60); });
  w.EXB_STUDIO = { version: 'V99-studio-1', applyLogo: applyAll, state: function () { return ST; } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(start, 0); }); else setTimeout(start, 0);
  /* la section peut être construite plus tard : nouvel essai discret */
  var n = 0, iv = setInterval(function () { if ($('exbsRoot') && $('exbLogoCard')) { clearInterval(iv); return; } if (++n > 40) { clearInterval(iv); return; } try { logoCard(); ui(); wrapRender(); } catch (e) {} }, 1500);
})(window, document);
