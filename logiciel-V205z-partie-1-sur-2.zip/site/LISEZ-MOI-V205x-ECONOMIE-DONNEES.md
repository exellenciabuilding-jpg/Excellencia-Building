# V205x — Économie de données (forfait Internet)

- Fichiers hors connexion (sw.js) : revérification au plus 1 fois par jour (avant : toutes les 30 min, à chaque ouverture). Le cache est reconstruit une seule fois à la mise à jour.
- Workflow serveur : vérification toutes les 120 s (avant : 30 s) ; circuits et délégations retéléchargés au plus toutes les 15 min (avant : à chaque passage).
- Base partagée : vérification toutes les 60 s (avant : 20 s).
- Messagerie équipe : toutes les 120 s et seulement application visible (avant : 45 s, même en arrière-plan).
- Les modifications restent envoyées dans les secondes qui suivent ; le retour sur l'application et le retour du réseau déclenchent toujours une synchronisation immédiate.
