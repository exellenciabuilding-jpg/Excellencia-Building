/* Excellencia Building — V177 : rapport PDF de marque (en-tête société, QR code de contrôle, informations complémentaires, mentions légales).
 * Aucune nouvelle donnée stockée ; réutilise l'identité unique (EXBId), le QR hors ligne (EXBQR) et l'impression universelle (EXBPrint : PDF direct sous Windows, boîte d'impression sous Android, aperçu sinon).
 * API : EXBRapport.print(titre, {sousTitre, ref, meta:[[libellé, valeur]], html, note, paysage}) · EXBRapport.build(...) -> document HTML (testable). */
(function (w) {
  'use strict';
  if (w.EXBRapport) return;
  var d = w.document;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function hash(s) { var h = 2166136261; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return ('00000000' + h.toString(16)).slice(-8).toUpperCase(); }
  function who() { try { var op = w.EXBOperateur && w.EXBOperateur.who && w.EXBOperateur.who(); if (op) return op; } catch (e) {} try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction || i.role)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function ident() { var I = {}; try { I = (w.EXBId && w.EXBId.get()) || {}; } catch (e) {} return I; }
  /* texte du QR : court (≤ 200 caractères), lisible hors ligne, avec empreinte du contenu pour détecter une copie modifiée */
  function qrText(I, titre, ref, date, body) {
    var t = [I.name || 'Excellencia Building', titre, ref, date, 'Empreinte ' + hash(body)];
    if (I.website) t.push(I.website); else if (I.phone) t.push(I.phone);
    var s = t.join(' | '); while (s.length > 200 && t.length > 4) { t.pop(); s = t.join(' | '); }
    return s.length > 200 ? s.slice(0, 200) : s;
  }
  /* V177b : QR de vérification PUBLIC, comme les autres documents (devis, reçus, certificats, PDF du moteur commun) :
   * il ouvre verification.html?c=… et le document est inscrit au registre (EXBVerif.publish, file d'attente hors ligne comprise).
   * Sans EXBVerif (page isolée) : repli sur un QR texte hors ligne (référence + empreinte). */
  function verif(I, titre, o, date, body) {
    try {
      if (!(w.EXBVerif && w.EXBVerif.docRec)) return null;
      var dg = w.EXBVerif.sha256 ? w.EXBVerif.sha256(body) : hash(body);
      var r = w.EXBVerif.docRec({ title: titre, sub: o.sousTitre || '', digest: dg, nom: I.name || 'Excellencia Building', no: o.ref, date: date, prefix: o.prefix || 'RAP', detail: (o.meta || []).map(function (m) { return m[0] + ' : ' + m[1]; }).join(' · ') });
      var img = w.EXBVerif.qrPng ? w.EXBVerif.qrPng(r.code.url) : '';
      return { rec: r.rec, url: r.code.url, no: r.rec.no, img: img };
    } catch (e) { return null; }
  }
  function opBlock() { try { return (w.EXBOperateur && w.EXBOperateur.blockHtml && w.EXBOperateur.blockHtml()) || ''; } catch (e) { return ''; } }
  function build(titre, o) {
    o = o || {}; var I = ident(), nm = I.name || 'Excellencia Building', date = today(), body = String(o.html || '');
    var V = verif(I, titre, o, date, body), ref = V ? V.no : (o.ref || ('RAP-' + date.replace(/-/g, '') + '-' + hash(titre + date + body).slice(0, 4))), q = '';
    try {
      if (V && V.img) q = '<img src="' + V.img + '" alt="QR de vérification" style="width:96px;height:96px;image-rendering:pixelated"/>';
      else if (w.EXBQR && w.EXBQR.svg) q = w.EXBQR.svg(qrText(I, titre, ref, date, body), { px: 96, quiet: 2 });
    } catch (e) { q = ''; }
    var vhost = V ? V.url.replace(/^https?:\/\//, '').split('?')[0] : '';
    var contact = [I.address, I.phone ? 'Tél : ' + I.phone : '', I.email, I.website].filter(Boolean).join(' · ');
    var head = '<div data-exb-habillage="1" style="display:flex;gap:12px;align-items:center;border-bottom:2px solid #c8962e;padding-bottom:8px;margin-bottom:10px">' + (I.logo ? '<img src="' + esc(I.logo) + '" style="height:52px" alt=""/>' : '') +
      '<div style="flex:1"><b style="font-size:16px">' + esc(nm) + '</b>' + (I.tagline ? '<div style="font-size:11px;color:#8a6a1c">' + esc(I.tagline) + '</div>' : '') + '<div style="font-size:11px;color:#555">' + esc(contact) + '</div></div>' +
      (q ? '<div style="text-align:center;font-size:9px;color:#555">' + q + '<div>' + (V ? 'Scanner pour vérifier' : 'Contrôle') + ' : ' + esc(ref) + '</div>' + (vhost ? '<div>' + esc(vhost) + '</div>' : '') + '</div>' : '') + '</div>';
    var meta = [['Référence', ref], ['Édité le', date], ['Édité par', who()]].concat(o.meta || []);
    var metaH = '<table class="m">' + meta.map(function (m) { return '<tr><td><b>' + esc(m[0]) + '</b></td><td>' + esc(m[1]) + '</td></tr>'; }).join('') + '</table>';
    var foot = '<div style="margin-top:14px;font-size:10px;color:#555;border-top:1px solid #ddd;padding-top:6px">' + (o.note ? esc(o.note) + '<br>' : '') + 'Document généré par ' + esc(nm) + ' — ' + (V ? 'le QR code ouvre la page publique de vérification (verification.html) qui confirme l’authenticité de ce document.' : 'le QR code contient la référence, la date et une empreinte du contenu pour vérifier qu’une copie n’a pas été modifiée.') +
      (I.legal ? '<br>' + esc(String(I.legal).split(/\r?\n+/).filter(Boolean).join('  ·  ')) : '') + (I.footer ? '<br>' + esc(I.footer) : '') + '</div>';
    return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>' + esc(titre) + '</title><style>@page{size:A4 ' + (o.paysage ? 'landscape' : 'portrait') + ';margin:12mm}body{font-family:Arial,sans-serif;color:#12305e;margin:0}h1{font-size:19px;margin:6px 0 2px}h2{font-size:14px;margin:14px 0 5px;border-bottom:1px solid #c8962e}table{width:100%;border-collapse:collapse;font-size:11.5px}td,th{padding:3px 6px;border-top:1px solid #ddd;text-align:left}th{background:#f3efe3}table.m{width:auto;margin:4px 0 8px}table.m td{border:0;padding:1px 8px 1px 0}.r{text-align:right}</style></head><body>' +
      head + '<h1>' + esc(titre) + '</h1>' + (o.sousTitre ? '<div style="font-size:12px;color:#555">' + esc(o.sousTitre) + '</div>' : '') + metaH + body + opBlock() + foot + '</body></html>';
  }
  function print(titre, o) {
    var doc = build(titre, o);
    try { var I = ident(), V = verif(I, titre, o || {}, today(), String((o && o.html) || '')); if (V && w.EXBVerif.publish) w.EXBVerif.publish(V.rec); } catch (e) {}
    if (w.EXBPrint && w.EXBPrint.html) { w.EXBPrint.html(titre, doc, { landscape: !!(o && o.paysage), print: !!(o && o.imprimer) }); return doc; }
    var f = d.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'; f.srcdoc = doc;
    f.onload = function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {} setTimeout(function () { f.remove(); }, 60000); }; d.body.appendChild(f); return doc;
  }
  /* ---------- V178 : habillage d'un document DÉJÀ construit par un module (plans, Gantt, QCM, bulletins, pièces…) ----------
   * stamp(titre, doc, {header, prefix, sousTitre, meta, overlay, digest, ref, publish}) -> document HTML avec :
   *   - header:true  → en-tête société (logo, nom, slogan, coordonnées) ajouté en tête (pour les écrans qui n'en ont pas) ;
   *   - un bloc QR de vérification PUBLIC (inscrit au registre, même page verification.html que les autres documents), en pied de page
   *     ou, avec overlay:true (plans, images pleine page), en pastille fixe en bas à droite sans créer de page supplémentaire.
   * Sans doublon : un document qui porte déjà data-exb-qr n'est pas retouché. Sans EXBVerif : repli sur le QR texte hors ligne.
   * printDoc(titre, doc, opts) = stamp + EXBPrint.html (opts.landscape) · screen(titre, opts) = imprime l'écran courant avec en-tête + QR. */
  var MARK = 'data-exb-qr';
  function plain(s) { return String(s == null ? '' : s).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim(); }
  function headHtml(I, qr) {
    var nm = I.name || 'Excellencia Building', contact = [I.address, I.phone ? 'Tél : ' + I.phone : '', I.email, I.website].filter(Boolean).join(' · ');
    return '<div data-exb-habillage="1" style="display:flex;gap:12px;align-items:center;border-bottom:2px solid #c8962e;padding-bottom:8px;margin:0 0 10px;font-family:Arial,sans-serif;color:#12305e;-webkit-print-color-adjust:exact;print-color-adjust:exact">' + (I.logo ? '<img src="' + esc(I.logo) + '" style="height:52px" alt=""/>' : '') +
      '<div style="flex:1"><b style="font-size:16px">' + esc(nm) + '</b>' + (I.tagline ? '<div style="font-size:11px;color:#8a6a1c">' + esc(I.tagline) + '</div>' : '') + '<div style="font-size:11px;color:#555">' + esc(contact) + '</div></div>' + (qr || '') + '</div>';
  }
  /* bloc QR : {html (QR + libellés), ref, V} — html vide si aucun générateur de QR n'est disponible */
  function qrParts(titre, o, digestSrc, I, size) {
    var date = today(), V = verif(I, titre, o, date, digestSrc), ref = V ? V.no : (o.ref || ((o.prefix || 'RAP') + '-' + date.replace(/-/g, '') + '-' + hash(titre + date + digestSrc).slice(0, 4))), q = '';
    try {
      if (V && V.img) q = '<img src="' + V.img + '" alt="QR de vérification" style="width:' + size + 'px;height:' + size + 'px;image-rendering:pixelated"/>';
      else if (w.EXBQR && w.EXBQR.svg) q = w.EXBQR.svg(qrText(I, titre, ref, date, digestSrc), { px: size, quiet: 2 });
    } catch (e) { q = ''; }
    var vhost = V ? V.url.replace(/^https?:\/\//, '').split('?')[0] : '';
    return { V: V, ref: ref, date: date, q: q, vhost: vhost };
  }
  function qrLabel(P) { return '<div style="text-align:center;font:9px Arial,sans-serif;color:#555">' + P.q + '<div>' + (P.V ? 'Scanner pour vérifier' : 'Contrôle') + ' : ' + esc(P.ref) + '</div>' + (P.vhost ? '<div>' + esc(P.vhost) + '</div>' : '') + '</div>'; }
  function insertStart(doc, blk) {
    var m = doc.match(/<body[^>]*>/i);
    if (m) return doc.slice(0, m.index + m[0].length) + blk + doc.slice(m.index + m[0].length);
    if (/<\/head>/i.test(doc)) return doc.replace(/<\/head>/i, '</head><body>' + blk);
    var i = doc.search(/<(h[1-6]|div|p|table|img|section|header|main|span|ul|ol|button|center|form|article|svg|canvas|b)\b/i);
    return i < 0 ? blk + doc : doc.slice(0, i) + blk + doc.slice(i);
  }
  function insertEnd(doc, blk) {
    var i = doc.toLowerCase().lastIndexOf('</body>'); if (i < 0) i = doc.toLowerCase().lastIndexOf('</html>');
    return i < 0 ? doc + blk : doc.slice(0, i) + blk + doc.slice(i);
  }
  function stamp(titre, doc, o) {
    o = o || {}; doc = String(doc == null ? '' : doc);
    if (doc.indexOf(MARK) >= 0) return doc;
    var I = ident(), src = (o.digest != null ? String(o.digest) : plain(doc)) + '|' + doc.length, size = o.overlay ? 72 : 84;
    var P = qrParts(titre, o, src, I, size), out = doc;
    try { if (P.V && w.EXBVerif && w.EXBVerif.publish && o.publish !== false) w.EXBVerif.publish(P.V.rec); } catch (e) {}
    if (o.header && doc.indexOf('data-exb-habillage') < 0) out = insertStart(out, headHtml(I, ''));
    if (P.q) {
      var txt = '<div style="flex:1;font:9px Arial,sans-serif;color:#555"><b>' + (P.V ? 'Vérification en ligne' : 'Contrôle') + '</b> — ' + esc(titre) + '<br>Réf. ' + esc(P.ref) + ' · ' + esc(P.date) + ' · ' + esc(who()) + (P.vhost ? '<br>' + esc(P.vhost) : '') +
        '<br>' + (P.V ? 'Scanner le QR code : la page publique confirme l’authenticité de ce document.' : 'Le QR code contient la référence, la date et une empreinte du contenu.') + '</div>';
      var blk = o.overlay
        ? '<div ' + MARK + '="' + esc(P.ref) + '" style="position:fixed;right:6mm;bottom:6mm;background:#fff;padding:2px;border:1px solid #ccc;z-index:9;-webkit-print-color-adjust:exact;print-color-adjust:exact">' + qrLabel(P) + '</div>'
        : '<div ' + MARK + '="' + esc(P.ref) + '" style="display:flex;gap:10px;align-items:center;margin-top:14px;padding-top:6px;border-top:1px solid #ddd;page-break-inside:avoid;break-inside:avoid;-webkit-print-color-adjust:exact;print-color-adjust:exact">' + qrLabel(P) + txt + '</div>';
      out = insertEnd(out, blk);
    }
    return out;
  }
  /* QR seul (image + libellés) pour l'intégrer dans une mise en page existante (cartouche d'un plan, case d'une pièce…) ; inscrit au registre */
  function qrHtml(titre, o, src, size) {
    o = o || {}; var P = qrParts(titre, o, String(src == null ? titre : src), ident(), size || 84);
    try { if (P.V && w.EXBVerif && w.EXBVerif.publish && o.publish !== false) w.EXBVerif.publish(P.V.rec); } catch (e) {}
    return P.q ? '<span ' + MARK + '="' + esc(P.ref) + '">' + qrLabel(P) + '</span>' : '';
  }
  /* QR sous forme de données (image + référence) : {img: data:image/png|svg base64, ref, host} — pour le moteur documentaire (options qr_img / qr_ref) */
  function qrData(titre, o, src) {
    o = o || {}; var P = qrParts(titre, o, String(src == null ? titre : src), ident(), 84), img = '';
    try { if (P.V && w.EXBVerif && w.EXBVerif.publish && o.publish !== false) w.EXBVerif.publish(P.V.rec); } catch (e) {}
    try {
      if (P.V && P.V.img) img = P.V.img;
      else if (P.q && /^<svg/.test(P.q) && typeof w.btoa === 'function') img = 'data:image/svg+xml;base64,' + w.btoa(unescape(encodeURIComponent(P.q)));
    } catch (e) { img = ''; }
    return img ? { img: img, ref: P.ref, host: P.vhost } : null;
  }
  function printDoc(titre, doc, o) {
    o = o || {}; var out = stamp(titre, doc, o);
    if (w.EXBPrint && w.EXBPrint.html) return w.EXBPrint.html(titre, out, { landscape: !!(o.landscape || o.paysage), nativeLayout: o.nativeLayout });
    var f = d.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'; f.srcdoc = out;
    f.onload = function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {} setTimeout(function () { f.remove(); }, 60000); }; d.body.appendChild(f); return out;
  }
  /* « Imprimer » qui imprime l'écran tel quel : en-tête société + QR ajoutés en tête pendant l'impression, retirés ensuite */
  function screen(titre, o) {
    o = o || {}; titre = titre || d.title || 'Écran';
    var old = d.querySelector('[data-exb-qr-screen]'); if (old) old.remove();
    var I = ident(), txt = plain(d.body ? (d.body.innerText || d.body.textContent || '') : '').slice(0, 20000), P = qrParts(titre, o, txt, I, 84), blk = d.createElement('div');
    try { if (P.V && w.EXBVerif && w.EXBVerif.publish) w.EXBVerif.publish(P.V.rec); } catch (e) {}
    blk.setAttribute('data-exb-qr-screen', '1'); if (P.q) blk.setAttribute(MARK, P.ref);
    blk.innerHTML = headHtml(I, P.q ? qrLabel(P) : '') + '<div style="font:11px Arial,sans-serif;color:#555;margin:0 0 8px"><b>' + esc(titre) + '</b> — Réf. ' + esc(P.ref) + ' · ' + esc(P.date) + ' · ' + esc(who()) + '</div>';
    d.body.insertBefore(blk, d.body.firstChild);
    var done = false, fin = function () { if (done) return; done = true; try { w.removeEventListener('afterprint', fin); } catch (e) {} try { blk.remove(); } catch (e) {} };
    try { w.addEventListener('afterprint', fin); } catch (e) {} setTimeout(fin, 120000);
    try { w.print(); } catch (e) { fin(); }
    return blk;
  }
  w.EXBRapport = { build: build, print: print, stamp: stamp, qr: qrHtml, qrData: qrData, printDoc: printDoc, screen: screen, head: function () { return headHtml(ident(), ''); }, _hash: hash, _plain: plain };
})(typeof window !== 'undefined' ? window : globalThis);
