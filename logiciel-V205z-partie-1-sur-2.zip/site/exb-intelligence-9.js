/* EXCELLENCIA INTELLIGENCE — lot 9 : tenir la charge (beaucoup de tâches, beaucoup de données).
 * Extension (à charger APRÈS exb-intelligence.js ; les lots 7 et 8 peuvent venir avant ou après).
 *  1. File de tâches EXBI.tasks : priorités (critique / haute / normale / basse) avec vieillissement (rien n'attend indéfiniment),
 *     fusion des tâches identiques, une tâche à la fois par défaut, délai maximum par tâche, nouvelles tentatives espacées,
 *     disjoncteur (3 échecs de suite → pause de 5 min pour ce type de tâche), attente automatique hors connexion / onglet masqué,
 *     pause / reprise / annulation, plafond de 200 tâches (les moins urgentes sont écartées en premier).
 *  2. Traitement par lots EXBI.tasks.batch(éléments, fonction) : de gros volumes sont traités par tranches de ≈ 12 ms, l'écran reste fluide,
 *     avec progression et annulation.
 *  3. Assistant : plusieurs demandes dans un seul message (« ouvre les clients puis importe les demandes ; fais une sauvegarde »)
 *     sont découpées, traitées une à une, et les actions proposées sont réunies (8 au plus). Les actions gardent leurs autorisations
 *     (Interdit / Demander / Automatique) : ce fichier ne contourne rien. Question « charge du moteur ? » → état local.
 *  4. Panneau 🧠 › Moteurs : charge, contrôles les plus lents, contrôles en erreur, volume des données ; recommandation si un contrôle échoue.
 * N'écrit que ses propres clés (exb_intel_tasks_log : 100 dernières tâches, sans donnée personnelle). Ne modifie aucune donnée métier.
 * Tâches nommées (EXBI.tasks.define / add({name,args})) : conservées dans exb_intel_tasks_pending et reprises à la réouverture.
 * Pour retirer : supprimer la balise <script src="exb-intelligence-9.js"> de index.html. */
(function (w, d) {
  'use strict';
  var I, tries = 0;
  function boot() {
    I = w.EXBI;
    if (!I || !I.helpers) { if (++tries < 80) setTimeout(boot, 250); return; }
    if (I.tasks) return;
    start();
  }
  function start() {
    var H = I.helpers, jget = H.jget, jset = H.jset, esc = H.esc, norm = H.norm;
    var K_LOG = 'exb_intel_tasks_log', PR = { critique: 0, haute: 1, normale: 2, basse: 3 };
    var MAXQ = 200, AGE = 60000, BRK_N = 3, BRK_MS = 300000;
    var Q = [], running = {}, nRun = 0, conc = 1, paused = false, seq = 0, brk = {}, wake = null, pumping = false;
    var st = { done: 0, failed: 0, dropped: 0, cancelled: 0, ms: 0, longest: 0 };
    var logArr = jget(K_LOG, []); if (!Array.isArray(logArr)) logArr = [];
    function now() { return Date.now(); }
    function msg(e) { return String(e && e.message || e || 'erreur').slice(0, 120); }
    function prNum(p) { if (typeof p === 'number') return Math.max(0, Math.min(3, p | 0)); return p in PR ? PR[p] : 2; }
    var logTm = null;
    function addLog(t, ok, ms, err) {
      logArr.unshift({ at: new Date().toISOString(), k: String(t.label || t.key).slice(0, 80), ok: !!ok, ms: ms, err: err ? String(err).slice(0, 100) : undefined });
      logArr = logArr.slice(0, 100); clearTimeout(logTm); logTm = setTimeout(function () { if (!jset(K_LOG, logArr)) { logArr = logArr.slice(0, 20); jset(K_LOG, logArr); } }, 1500);
    }
    function emit(ev, t) { try { I.bus.emit('task', { ev: ev, key: t && t.key, label: t && t.label, queued: Q.length, running: nRun }); } catch (e) {} }

    /* ---------- file ---------- */
    function eff(t) { return Math.max(0, t.prio - Math.floor((now() - t.at) / AGE)); }
    function eligible(t) {
      if (t.notBefore > now()) return false;
      if (t.spec.needsNet && w.navigator && w.navigator.onLine === false) return false;
      if (t.prio === 3 && !t.spec.hiddenOk && d.hidden) return false;
      if (brk[t.group] && brk[t.group].until > now()) return false;
      return true;
    }
    function next() {
      var best = null; Q.forEach(function (t) { if (!eligible(t)) return; if (!best || eff(t) < eff(best) || (eff(t) === eff(best) && t.at < best.at)) best = t; });
      return best;
    }
    function pump() {
      if (pumping) return; pumping = true;
      setTimeout(function () {
        pumping = false; if (paused) return;
        while (nRun < conc) { var t = next(); if (!t) break; start1(t); }
        clearTimeout(wake); wake = null;
        if (Q.length && nRun < conc) { /* des tâches attendent : réveil à la plus proche échéance, sinon dans 15 s (réseau, onglet masqué) */
          var soon = 15000; Q.forEach(function (t) { var dt = Math.max(250, t.notBefore - now()); if (t.notBefore > now() && dt < soon) soon = dt; });
          wake = setTimeout(pump, soon);
        }
      }, 0);
    }
    function start1(t) {
      var i = Q.indexOf(t); if (i >= 0) Q.splice(i, 1);
      nRun++; running[t.id] = t; t.t0 = now(); t.settled = false; emit('start', t);
      var tmo = t.spec.timeout == null ? 30000 : t.spec.timeout, tm = null;
      function end(ok, val, err) {
        if (t.settled) return; t.settled = true; clearTimeout(tm); delete running[t.id]; nRun--;
        var ms = now() - t.t0; st.ms += ms; if (ms > st.longest) st.longest = ms;
        if (t.cancelled) { st.cancelled++; t.res({ ok: false, cancelled: true }); }
        else if (ok) { st.done++; delete brk[t.group]; addLog(t, true, ms); t.res({ ok: true, value: val, ms: ms }); emit('done', t); }
        else if (t.tries < (t.spec.retries | 0)) {
          t.tries++; t.notBefore = now() + (t.spec.backoff || 2000) * Math.pow(2, t.tries - 1); Q.push(t); emit('retry', t);
        } else {
          st.failed++; var b = brk[t.group] || (brk[t.group] = { n: 0, until: 0 }); b.n++; if (b.n >= BRK_N) b.until = now() + BRK_MS;
          addLog(t, false, ms, err); t.res({ ok: false, error: err, ms: ms }); emit('fail', t);
        }
        pump();
      }
      if (tmo > 0) tm = setTimeout(function () { end(false, null, 'délai dépassé (' + Math.round(tmo / 1000) + ' s)'); }, tmo);
      var r; try { r = t.spec.fn(); } catch (e) { end(false, null, msg(e)); return; }
      if (r && typeof r.then === 'function') r.then(function (v) { end(true, v); }, function (e) { end(false, null, msg(e)); });
      else end(true, r);
    }
    /* Tâches nommées : define(nom, fonction) puis add({name, args}) ; elles sont gardées dans exb_intel_tasks_pending et reprises à la réouverture de l'application. */
    var K_PEND = 'exb_intel_tasks_pending', defs = {}, live = {}, pend = jget(K_PEND, {}), pendTm = null; if (!pend || typeof pend !== 'object' || Array.isArray(pend)) pend = {};
    function savePend() { clearTimeout(pendTm); pendTm = setTimeout(function () { jset(K_PEND, pend); }, 300); }
    function define(name, fn) { if (typeof fn !== 'function') return; defs[String(name)] = fn; Object.keys(pend).forEach(function (k) { var p = pend[k]; if (p && p.name === name && !live[k]) { add({ name: p.name, args: p.args, key: k, prio: p.prio, group: p.group, label: p.label, timeout: p.timeout }); } }); }
    function add(spec) {
      spec = spec || {};
      if (typeof spec.fn !== 'function' && spec.name && defs[spec.name]) { var nm = spec.name, ar = spec.args; spec = Object.assign({}, spec, { fn: function () { return defs[nm](ar); } }); }
      else if (spec.name) { spec = Object.assign({}, spec, { fn: null }); }
      if (typeof spec.fn !== 'function') return Promise.resolve({ ok: false, error: 'tâche invalide' });
      var key = String(spec.key || ('t' + (++seq))), group = String(spec.group || key), prio = prNum(spec.prio);
      var b = brk[group]; if (b && b.until > now()) return Promise.resolve({ ok: false, skipped: true, error: 'suspendue après des échecs répétés (reprise vers ' + new Date(b.until).toLocaleTimeString('fr-FR') + ')' });
      for (var i = 0; i < Q.length; i++) if (Q[i].key === key) { /* même tâche déjà en attente : fusion (la plus urgente et la plus récente gagnent) */
        if (prio < Q[i].prio) Q[i].prio = prio; Q[i].spec = spec; Q[i].coalesced = (Q[i].coalesced || 0) + 1; return Q[i].promise;
      }
      if (Q.length >= MAXQ) { /* file pleine : on écarte la tâche la moins urgente, la plus récente */
        var worst = null; Q.forEach(function (t) { if (!worst || t.prio > worst.prio || (t.prio === worst.prio && t.at > worst.at)) worst = t; });
        if (worst && worst.prio > prio) { Q.splice(Q.indexOf(worst), 1); st.dropped++; worst.res({ ok: false, dropped: true, error: 'file pleine' }); }
        else { st.dropped++; return Promise.resolve({ ok: false, dropped: true, error: 'file pleine (' + MAXQ + ' tâches)' }); }
      }
      var t = { id: ++seq, key: key, group: group, label: String(spec.label || key), prio: prio, spec: spec, at: now(), notBefore: spec.delay ? now() + spec.delay : 0, tries: 0 };
      t.promise = new Promise(function (res) { t.res = res; });
      if (spec.name && Object.keys(pend).length < 100) { var ag; try { ag = JSON.parse(JSON.stringify(spec.args === undefined ? null : spec.args)); } catch (e) { ag = null; }
        pend[key] = { name: spec.name, args: ag, prio: prio, group: group, label: t.label, timeout: spec.timeout }; live[key] = 1; savePend();
        t.promise.then(function () { delete live[key]; if (pend[key]) { delete pend[key]; savePend(); } }); }
      Q.push(t); emit('queued', t); pump(); return t.promise;
    }
    function cancel(key) {
      var n = 0; key = String(key);
      Q.slice().forEach(function (t) { if (t.key === key || t.group === key) { Q.splice(Q.indexOf(t), 1); st.cancelled++; t.res({ ok: false, cancelled: true }); n++; } });
      Object.keys(running).forEach(function (id) { var t = running[id]; if (t.key === key || t.group === key) { t.cancelled = true; n++; } });
      return n;
    }
    function clearQ() { var n = Q.length; Q.splice(0).forEach(function (t) { st.cancelled++; t.res({ ok: false, cancelled: true }); }); return n; }
    function status() {
      var by = [0, 0, 0, 0]; Q.forEach(function (t) { by[t.prio]++; });
      var open = Object.keys(brk).filter(function (g) { return brk[g].until > now(); });
      var n = st.done + st.failed;
      return { queued: Q.length, running: nRun, paused: paused, concurrency: conc, byPriority: { critique: by[0], haute: by[1], normale: by[2], basse: by[3] }, done: st.done, failed: st.failed, dropped: st.dropped, cancelled: st.cancelled,
        avgMs: n ? Math.round(st.ms / n) : 0, longestMs: st.longest, suspended: open, next: (function () { var t = next(); return t ? t.label : ''; })() };
    }
    function idle() { return new Promise(function (res) { (function chk() { if (!Q.length && !nRun) res(); else setTimeout(chk, 50); })(); }); }

    /* ---------- traitement par lots (tranches courtes) ---------- */
    function batch(items, fn, o) {
      o = o || {}; var arr = Array.isArray(items) ? items : [], i = 0, ok = 0, bad = 0, errs = [], stop = false, budget = o.budget > 0 ? o.budget : 12, t00 = now(), resolve;
      var p = new Promise(function (r) { resolve = r; });
      function fail(e) { bad++; if (errs.length < 5) errs.push(msg(e)); }
      function prog() { if (typeof o.onProgress === 'function') { try { o.onProgress(i, arr.length); } catch (e) {} } }
      function fin() { prog(); resolve({ total: arr.length, ok: ok, failed: bad, cancelled: stop && i < arr.length, ms: now() - t00, errors: errs }); }
      function pass() {
        var t0 = now();
        while (i < arr.length && !stop) {
          var idx = i++, r;
          try { r = fn(arr[idx], idx); } catch (e) { fail(e); r = undefined; if (now() - t0 >= budget) { prog(); setTimeout(pass, 0); return; } continue; }
          if (r && typeof r.then === 'function') { r.then(function () { ok++; }, fail).then(function () { prog(); pass(); }); return; }
          ok++; if (now() - t0 >= budget) { prog(); setTimeout(pass, 0); return; }
        }
        fin();
      }
      setTimeout(pass, 0); p.cancel = function () { stop = true; }; return p;
    }

    /* ---------- assistant : plusieurs demandes dans un message ---------- */
    var SEP = /\n+|\s*;\s*|\s+(?:puis|ensuite|et ensuite|et puis|et aussi|apr[eè]s (?:cela|ça|ca))\s+/i, MAXP = 8;
    function splitReq(raw) {
      var t = String(raw == null ? '' : raw).trim();
      if (t.length < 10 || t.length > 900) return [t];
      if (/\b(redige\w*|ecris|ecrire|compose\w*|message|mail|lettre|texte)\b/.test(norm(t))) return [t]; /* un texte à rédiger peut contenir « puis » ou « ; » */
      var parts = t.split(SEP).map(function (x) { return String(x || '').replace(/^\s*(?:\d{1,2}[.)]|[-•*])\s*/, '').trim(); }).filter(function (x) { return x.length >= 3; });
      return parts.length >= 2 ? parts.slice(0, MAXP + 1) : [t];
    }
    var UNK = /^je n.ai pas (compris|pu)/i;
    function multi(parts, orig, ctx) {
      var over = parts.length > MAXP; parts = parts.slice(0, MAXP);
      var ok = [], unk = [], acts = [], seen = {};
      parts.forEach(function (p) {
        var R = null; try { R = orig.call(ctx, p); } catch (e) { R = null; }
        if (!R || !R.answer || UNK.test(String(R.answer).trim())) { unk.push(p); return; }
        ok.push({ p: p, a: String(R.answer) });
        (R.actions || []).forEach(function (a) { var k; try { k = JSON.stringify(a); } catch (e) { k = String(acts.length); } if (!seen[k] && acts.length < MAXP) { seen[k] = 1; acts.push(a); } });
      });
      if (ok.length < 2) { try { orig.call(ctx, 'annule'); } catch (e) {} return null; } /* pas une vraie demande multiple : on efface la question en attente que les essais ont pu laisser (« Quel est le nom ? »), puis l'assistant traite le message tel quel */
      var t = 'J’ai compris ' + ok.length + ' demandes, traitées dans l’ordre :\n' + ok.map(function (x, i) { var a = x.a.length > 600 ? x.a.slice(0, 597) + '…' : x.a; return (i + 1) + ') ' + a; }).join('\n\n');
      if (unk.length) t += '\n\nNon comprises (à reformuler) : ' + unk.map(function (x) { return '« ' + x.slice(0, 60) + ' »'; }).join(' ; ');
      if (over) t += '\n\nMaximum ' + MAXP + ' demandes par message : envoyez le reste dans un second message.';
      if (acts.length > 1) t += '\n\n' + acts.length + ' actions proposées ci-dessous : chacune reste soumise à ses autorisations (Paramètres › Assistant IA).';
      return { answer: t.slice(0, 4000), actions: acts };
    }
    var STATQ = /\b(sante du moteur|etat du moteur|charge du moteur|surcharge|file des taches|taches? en attente|taches? en cours|moteur (est )?lent|performance du moteur|lenteur du moteur)\b/;
    function statusText() {
      var s = status(), t = 'Charge du moteur : ' + s.queued + ' tâche(s) en file, ' + s.running + ' en cours' + (s.paused ? ' (file en PAUSE)' : '') + '.\n' +
        'Terminées : ' + s.done + ' · échecs : ' + s.failed + ' · écartées : ' + s.dropped + ' · durée moyenne : ' + s.avgMs + ' ms.';
      if (s.suspended.length) t += '\nSuspendues après échecs répétés : ' + s.suspended.join(', ') + '.';
      var er = Object.keys(I.stats()).filter(function (k) { return I.stats()[k].errors; });
      if (er.length) t += '\nContrôles en erreur : ' + er.slice(0, 5).map(function (k) { return k.replace(/^(rule|engine):/, ''); }).join(', ') + '.';
      return t + '\n\nOuvrez 🧠 › Moteurs pour le détail.';
    }
    /* Chaque lot s'accroche UNE seule fois (registre w.__exbAIHooks) : avant, les lots 1, 7 et 8 s'enveloppaient mutuellement à chaque passage et la chaîne de l'assistant s'allongeait.
       Le lot 9 s'accroche en dernier pour passer en premier : il découpe le message avant que les autres lots ne l'interceptent en entier. */
    var HK = (w.__exbAIHooks = w.__exbAIHooks || {}), waitTicks = 0;
    function othersReady() { return (HK.intel || waitTicks > 30) && (!I.sec || HK.sec || waitTicks > 30) && (!I.intake || HK.inbox || waitTicks > 30); }
    function hookAI() {
      try {
        waitTicks++;
        if (typeof w.localAI === 'function' && !HK.multi && othersReady()) {
          HK.multi = 1; var l = w.localAI;
          w.localAI = function (raw) {
            try {
              if (STATQ.test(norm(raw))) return { answer: statusText(), actions: [] };
              var parts = splitReq(raw); if (parts.length >= 2) { var r = multi(parts, l, this); if (r) return r; }
            } catch (e) {}
            return l.apply(this, arguments);
          };
          w.localAI.__multi = 1;
        }
      } catch (e) {}
    }

    /* ---------- panneau 🧠 › Moteurs ---------- */
    function btn(a, l) { return '<button class="a" data-xt="' + a + '">' + l + '</button>'; }
    function panelHtml() {
      var s = status(), stt = I.stats(), keys = Object.keys(stt), h = '';
      h += '<div class="ic">⚙️ <b>Charge</b><small>' + s.queued + ' en file (critique ' + s.byPriority.critique + ' · haute ' + s.byPriority.haute + ' · normale ' + s.byPriority.normale + ' · basse ' + s.byPriority.basse + ') · ' + s.running + ' en cours' + (s.paused ? ' · <b>EN PAUSE</b>' : '') + '</small>' +
        '<small>Terminées ' + s.done + ' · échecs ' + s.failed + ' · écartées ' + s.dropped + ' · moyenne ' + s.avgMs + ' ms · plus longue ' + s.longestMs + ' ms</small>' +
        (s.suspended.length ? '<small>⛔ Suspendues : ' + esc(s.suspended.join(', ')) + '</small>' : '') +
        (s.paused ? btn('resume', '▶ Reprendre') : btn('pause', '⏸ Pause')) + (s.queued ? btn('clear', '🗑 Vider la file') : '') + '</div>';
      var slow = keys.filter(function (k) { return stt[k].runs; }).sort(function (a, b) { return stt[b].max - stt[a].max; }).slice(0, 5);
      if (slow.length) h += '<div class="ic">⏱ <b>Contrôles les plus lents</b>' + slow.map(function (k) { var x = stt[k]; return '<small>' + esc(k.replace(/^(rule|engine):/, '')) + ' : max ' + x.max + ' ms · moyenne ' + Math.round(x.ms / x.runs) + ' ms · ' + x.runs + ' passage(s)</small>'; }).join('') + '</div>';
      var bad = keys.filter(function (k) { return stt[k].errors; });
      if (bad.length) h += '<div class="ic">🛠 <b>Contrôles en erreur (' + bad.length + ')</b>' + bad.slice(0, 6).map(function (k) { return '<small>' + esc(k.replace(/^(rule|engine):/, '')) + ' : ' + stt[k].errors + ' erreur(s) — ' + esc(stt[k].last || 'voir la console') + '</small>'; }).join('') + '<small>Les autres contrôles continuent normalement.</small></div>';
      var vol = I.collections.map(function (c) { return [c.l, H.list(c.k).length]; }).filter(function (x) { return x[1]; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 4);
      if (vol.length) h += '<div class="ic">📊 <b>Volume des données</b><small>' + vol.map(function (x) { return esc(x[0]) + ' : ' + x[1]; }).join(' · ') + '</small></div>';
      if (logArr.length) h += '<div class="ic">🧾 <b>Dernières tâches</b>' + logArr.slice(0, 6).map(function (x) { return '<small>' + (x.ok ? '✓' : '✗') + ' ' + esc(x.k) + ' · ' + x.ms + ' ms' + (x.err ? ' · ' + esc(x.err) : '') + '</small>'; }).join('') + '</div>';
      return h;
    }
    I.addEngineInfo(panelHtml);
    d.addEventListener && d.addEventListener('click', function (e) {
      var b = e.target && e.target.closest && e.target.closest('[data-xt]'); if (!b) return;
      var a = b.getAttribute('data-xt');
      if (a === 'pause') paused = true; else if (a === 'resume') { paused = false; pump(); } else if (a === 'clear') clearQ();
      try { I.open('eng'); } catch (x) {}
    });
    I.addReco(function () {
      var s = status(), stt = I.stats(), bad = Object.keys(stt).filter(function (k) { return stt[k].errors; }), r = [];
      if (bad.length || s.suspended.length) r.push({ ic: '🛠', t: 'Moteur : ' + (bad.length + s.suspended.length) + ' contrôle(s) ou tâche(s) en difficulté', x: 'Les autres contrôles continuent. Détail dans 🧠 › Moteurs.', acts: [{ l: 'Voir l’état du moteur', f: function () { I.open('eng'); } }] });
      if (s.paused && s.queued) r.push({ ic: '⏸', t: s.queued + ' tâche(s) en pause', x: 'La file de tâches est suspendue.', acts: [{ l: 'Reprendre', f: function () { paused = false; pump(); } }] });
      return r;
    });
    try { w.addEventListener('online', pump); d.addEventListener && d.addEventListener('visibilitychange', pump); } catch (e) {}
    var n = 0, t2 = setInterval(function () { hookAI(); if (++n > 60) clearInterval(t2); }, 750); hookAI();

    I.tasks = { add: add, define: define, pending: function () { return Object.keys(pend).length; }, cancel: cancel, clear: clearQ, status: status, idle: idle, batch: batch,
      pause: function () { paused = true; }, resume: function () { paused = false; pump(); }, setConcurrency: function (k) { conc = Math.max(1, Math.min(3, k | 0 || 1)); pump(); },
      split: splitReq, multi: function (raw, fn) { var p = splitReq(raw); return p.length >= 2 ? multi(p, fn, null) : null; }, log: function () { return logArr.slice(); }, statusText: statusText, panelHtml: panelHtml };
    try { I.bus.emit('tasks-ready', 1); } catch (e) {}
  }
  if (d.readyState === 'loading' && d.addEventListener) d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
