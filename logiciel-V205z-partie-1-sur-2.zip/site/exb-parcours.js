/* Excellencia Building V128d — PARCOURS : interconnexion des modules le long de leur parcours métier.
 * Les tranches « Liaison » (V99) relient les DONNÉES (client_id, project_id…). Ce module relie les MODULES entre eux :
 *   1. Parcours chantier  : Client → Devis → Études → Plans → Contrat → Achats → Chantier → Documents → Facturation → Paiement → Réception.
 *   2. Parcours formation : Inscription → Formation → Paiement → Présence → Évaluation → Certificat.
 * Pour un chantier ou un participant, on voit où il en est, ce qui manque, et un bouton ouvre directement le module de l'étape suivante.
 * Principe : les écrans sont en LECTURE SEULE ; seules deux actions explicites, confirmées une à une par l'utilisateur, écrivent : « Rattacher à ce chantier »
 * (une fiche sans chantier) et « Préparer la facture » (brouillon, via le module existant). Aucun blocage, aucun lien deviné. Ajoute aussi au registre des modules ceux qui n'y figuraient pas et corrige ses références cassées. */
(function (w, d) {
  'use strict';
  var VERSION = 'V128d-PARCOURS';

  /* ---------------------------------------------------------------- registre : modules récents + références cassées ---------------------------------------------------------------- */
  function patchRegistry() {
    var M = w.EXB_MODULES; if (!Array.isArray(M) || M.__parcours) return;
    var has = function (id) { return M.some(function (m) { return m.id === id; }); };
    var add = function (m) { if (!has(m.id)) M.push(m); };
    /* sections historiques citées comme dépendances mais jamais déclarées */
    add({ id: 'formations', name: 'Catalogue des formations', area: 'Formation', icon: '📚', status: 'actif', deps: [] });
    add({ id: 'formateurs', name: 'Formateurs', area: 'Formation', icon: '🧑‍🏫', status: 'actif', deps: ['formations'] });
    add({ id: 'planning', name: 'Planning des séances', area: 'Formation', icon: '🗓️', status: 'actif', deps: ['formations', 'formateurs'] });
    add({ id: 'presence', name: 'Présences', area: 'Formation', icon: '✅', status: 'actif', deps: ['participants', 'planning'] });
    add({ id: 'evaluations', name: 'Évaluations & cotations', area: 'Formation', icon: '📝', status: 'actif', deps: ['participants', 'formations'] });
    add({ id: 'finances', name: 'Finances des apprenants', area: 'Finance', icon: '💵', status: 'actif', deps: ['participants'] });
    add({ id: 'reports', name: 'Rapports', area: 'Pilotage', icon: '📈', status: 'actif', deps: [] });
    /* modules livrés après la V94 */
    add({ id: 'docsChantier', name: 'Documents de chantier', area: 'BTP', icon: '📂', status: 'actif', deps: ['projets', 'clients', 'documents'] });
    add({ id: 'calculStructure', name: 'Calcul de structure', area: 'Technique', icon: '🧮', status: 'actif', deps: ['projets', 'etudesTechniques'] });
    add({ id: 'planEditeur', name: 'Éditeur de plans', area: 'Technique', icon: '✏️', status: 'actif', deps: ['projets', 'plansVersions'] });
    add({ id: 'tfl', name: 'TFL — travaux de fin de licence', area: 'Formation', icon: '🎓', status: 'actif', deps: ['participants', 'formateurs'] });
    add({ id: 'verification', name: 'Vérification de documents (QR)', area: 'Transverse', icon: '🔍', status: 'actif', deps: ['documents'] });
    add({ id: 'liaison', name: 'Liaison des données', area: 'Système', icon: '🔗', status: 'actif', deps: ['clients', 'projets', 'comptabilite'] });
    add({ id: 'parcours', name: 'Parcours chantier & formation', area: 'Pilotage', icon: '🧭', status: 'nouveau', deps: ['liaison', 'projets', 'participants'] });
    /* rôles : « reports » et « evaluations » existent maintenant */
    M.__parcours = true;
    w.EXB_FLOWS = {
      chantier: ['clients', 'metreDevis', 'etudesTechniques', 'plansVersions', 'contrats', 'procurement', 'projets', 'docsChantier', 'facturation', 'comptabilite', 'reserves'],
      formation: ['participants', 'formations', 'finances', 'presence', 'evaluations', 'portailApprenant']
    };
  }
  /* contrôle : toute dépendance et tout accès de rôle doit viser un module déclaré */
  function registryIssues() {
    var M = w.EXB_MODULES || [], ids = {}, out = [];
    M.forEach(function (m) { ids[m.id] = 1; });
    M.forEach(function (m) { (m.deps || []).forEach(function (x) { if (!ids[x]) out.push('Registre : « ' + m.name + ' » dépend de « ' + x + ' » qui n’est pas un module déclaré'); }); });
    var R = w.EXB_ROLES || {};
    Object.keys(R).forEach(function (r) { R[r].forEach(function (x) { if (x !== '*' && !ids[x]) out.push('Registre : le rôle « ' + r + ' » donne accès à « ' + x + ' » qui n’est pas un module déclaré'); }); });
    return out;
  }
  function patchArchitectureCheck() {
    var f = w.exbRunArchitectureCheck; if (typeof f !== 'function' || f.__parcours) return;
    var g = function () {
      var r = f.apply(this, arguments);
      try {
        var host = d.getElementById('exbArchChecks'); if (!host) return r;
        var bad = registryIssues();
        host.insertAdjacentHTML('beforeend', '<div style="padding:8px 10px;border-bottom:1px solid #edf1f5"><b>' + (bad.length ? '⚠️' : '✅') + ' Références du registre</b><div class="localhint">' +
          (bad.length ? bad.map(function (x) { return String(x).replace(/[&<>]/g, ''); }).join('<br>') : 'Toutes les dépendances et tous les accès de rôles visent des modules déclarés') + '</div></div>');
      } catch (e) {}
      return r;
    };
    g.__parcours = true; w.exbRunArchitectureCheck = g;
  }

  /* ---------------------------------------------------------------- moteur ---------------------------------------------------------------- */
  function boot(tries) {
    var X = w.EXBLIEN;
    if (!X || !X.extend || !X.rd) { if ((tries || 0) > 120) return; return setTimeout(function () { boot((tries || 0) + 1); }, 400); }
    patchRegistry(); patchArchitectureCheck();
    var norm = X.norm, esc = X.esc, num = X.num;

    var K = { cli: 'exb_clients', prj: 'exb_projects', qt: 'exb_quotes', st: 'exb_studies', inv: 'exb_invoices', cn: 'exb_calc_notes', mi: 'exb_be_missions',
      v94dr: 'exb_v94_drawings', v94st: 'exb_v94_studies', pf: 'exb_plan_files', pie: 'exb_pieces', po: 'exb_purchase_orders', mv: 'exb_stock_moves',
      jr: 'exb_site_journal', v93p: 'exb_v93_projects', v93t: 'exb_v93_tasks', v93c: 'exb_v93_subcontracts', ts: 'exb_timesheets', sit: 'exb_situations',
      v67c: 'exb_commitments', v67k: 'exb_contracts', v67r: 'exb_rfis', v67s: 'exb_submittals', v67a: 'exb_change_orders', v67q: 'exb_qhse', v67k2: 'exb_risks', v67m: 'exb_meetings', v67v: 'exb_reserves', v67e: 'exb_equipment',
      par: 'exb_participants', frm: 'exb_formations', pay: 'exb_payments', att: 'exb_attendance', ev: 'exb_evaluations', cot: 'exb_cotations', cert: 'exb_certificates' };

    function rd(k) {
      try { if (w.EXBS && typeof w.EXBS.get === 'function' && /^exb_v94_/.test(k)) { var v = w.EXBS.get(k); if (Array.isArray(v)) return v; } } catch (e) {}
      try { var l = X.rd(k); return Array.isArray(l) ? l : []; } catch (e) { return []; }
    }
    function liveFormation(k) {
      try { switch (k) { case K.att: return typeof attendance !== 'undefined' ? attendance : null; case K.ev: return typeof evaluations !== 'undefined' ? evaluations : null; case K.cot: return typeof cotations !== 'undefined' ? cotations : null; } } catch (e) {}
      return null;
    }
    function rdF(k) { var l = liveFormation(k); return Array.isArray(l) ? l : rd(k); }
    function mine(list, pid, f) { return list.filter(function (o) { return o && String((f ? f(o) : (o.project_id || o.project)) || '') === String(pid); }); }
    function issued(q) { return !!(q && (q.emis || q.issued_at || q.locked || q.approved || q.approved_at || /(envoy|emis|émis|approuv|accept|sign|valid|factur)/i.test(String(q.status || '')))); }
    function isModel(x) { return !!(x && (x.modele || x.model_perso)); }

    /* ======================= 1. parcours chantier ======================= */
    /* chaque étape : id, icône, libellé, module à ouvrir, `opt` = étape facultative (jamais comptée comme « sautée »), `calc(ctx)` → { n, detail } */
    var CH = [
      { id: 'client', ico: '👤', nom: 'Client', mod: 'clients', calc: function (c) { return { n: c.client ? 1 : 0, detail: c.client ? c.client : 'aucun client relié à ce chantier' }; } },
      { id: 'devis', ico: '📐', nom: 'Métré & devis', mod: 'metreDevis', calc: function (c) { return { n: c.quotes.length, detail: c.quotes.length ? c.quotes.length + ' devis (' + c.quotes.filter(issued).length + ' émis)' : 'aucun devis' }; } },
      { id: 'etude', ico: '🧮', nom: 'Études & calculs', mod: 'calcul', opt: true, calc: function (c) { return { n: c.etudes, detail: c.etudes ? c.etudes + ' étude(s), note(s) de calcul ou mission(s)' : 'aucune étude' }; } },
      { id: 'plans', ico: '🗺️', nom: 'Plans', mod: 'plans', opt: true, calc: function (c) { return { n: c.plans, detail: c.plans ? c.plans + ' plan(s) / fichier(s)' : 'aucun plan' }; } },
      { id: 'contrat', ico: '🤝', nom: 'Contrat', mod: 'docs', fam: 'contrat', calc: function (c) { return { n: c.contrats, detail: c.contrats ? c.contrats + ' contrat(s) / avenant(s)' : 'aucun contrat rédigé' }; } },
      { id: 'achats', ico: '🛒', nom: 'Achats & stock', mod: 'stock', opt: true, calc: function (c) { return { n: c.achats, detail: c.achats ? c.po.length + ' commande(s), ' + c.mv.length + ' mouvement(s) de stock' : 'aucun achat' }; } },
      { id: 'p360', ico: '📑', nom: 'Engagements & qualité (Projet 360°)', mod: 'v67', opt: true, calc: function (c) { return { n: c.v67n, detail: c.v67n ? c.v67.c.length + ' engagement(s) (' + Math.round(c.v67eng * 100) / 100 + '), ' + c.v67.r.length + ' RFI, ' + c.v67.a.length + ' avenant(s), ' + c.v67.q.length + ' QHSE, ' + c.v67.k2.length + ' risque(s), ' + c.v67.v.length + ' réserve(s)' : 'rien enregistré dans Projet 360° pour ce chantier' }; } },
      { id: 'chantier', ico: '🏗️', nom: 'Exécution du chantier', mod: 'projets', calc: function (c) { return { n: c.terrain, detail: c.terrain ? c.jr.length + ' note(s) de journal, ' + c.taches.length + ' tâche(s), ' + c.ts.length + ' pointage(s)' : 'aucune activité de chantier' }; } },
      { id: 'docs', ico: '📂', nom: 'Documents de chantier', mod: 'docs', calc: function (c) { return { n: c.docs.length, detail: c.docs.length ? c.docs.length + ' document(s) (' + c.docsEmis + ' émis ou signés)' : 'aucun document' }; } },
      { id: 'facture', ico: '🧾', nom: 'Facturation', mod: 'facture', prep: 'facture', calc: function (c) { return { n: c.inv.length + c.sit.length, detail: (c.inv.length + c.sit.length) ? c.inv.length + ' facture(s), ' + c.sit.length + ' situation(s)' : 'aucune facture' }; } },
      { id: 'paiement', ico: '💳', nom: 'Paiement', mod: 'facture', calc: function (c) { return { n: c.verse > 0 ? 1 : 0, detail: c.verse > 0 ? 'des versements sont enregistrés' : 'aucun versement' }; } },
      { id: 'reception', ico: '🟠', nom: 'Réception & réserves', mod: 'docs', fam: 'pv', opt: true, calc: function (c) { return { n: c.reception, detail: c.reception ? c.reception + ' document(s) de réception' : 'pas encore de réception' }; } }
    ];

    function chantierCtx(pid) {
      var P = rd(K.prj).filter(function (p) { return p && p.id === pid; })[0]; if (!P) return null;
      var cl = P.client_id ? rd(K.cli).filter(function (c) { return c && c.id === P.client_id; })[0] : null;
      var q = mine(rd(K.qt), pid), inv = mine(rd(K.inv), pid), sit = mine(rd(K.sit), pid);
      var pieces = mine(rd(K.pie), pid, function (o) { return o.project || o.project_id; }).filter(function (x) { return !isModel(x); });
      var etudes = mine(rd(K.st), pid).length + mine(rd(K.cn), pid).length + mine(rd(K.mi), pid).length + mine(rd(K.v94st), pid).length;
      var plans = mine(rd(K.v94dr), pid).length + mine(rd(K.pf), pid).length;
      var po = mine(rd(K.po), pid), mv = mine(rd(K.mv), pid), jr = mine(rd(K.jr), pid), ts = mine(rd(K.ts), pid);
      var taches = mine(rd(K.v93t), pid, function (o) { return o.core_project_id; });
      var v67 = {}; ['c', 'k', 'r', 's', 'a', 'q', 'k2', 'm', 'v', 'e'].forEach(function (z) { v67[z] = mine(rd(K['v67' + z]), pid); });
      v67.q = v67.q.concat(mine(rd('exb_v93_hse'), pid, function (o) { return o.core_project_id; }));
      v67.k2 = v67.k2.concat(mine(rd('exb_risk_register'), pid));
      v67.e = v67.e.concat(mine(rd('exb_v93_equipment'), pid, function (o) { return o.core_project_id; }));
      var v67n = Object.keys(v67).reduce(function (a, z) { return a + v67[z].length; }, 0), v67eng = v67.c.reduce(function (a, x) { return a + num(x.amount); }, 0);
      var contrats = pieces.filter(function (x) { return x.type === 'contrat'; }).length + mine(rd(K.v93c), pid, function (o) { return o.core_project_id; }).length + v67.k.length + rd('exb_crm_contracts').filter(function (x) { if (!x || x.annule) return false; if ((x.project_id || '') === pid) return true; var qq = rd(K.qt).filter(function (z) { return z.id === x.quote_id; })[0]; return !!(qq && (qq.project_id === pid)); }).length;
      var reception = pieces.filter(function (x) { return /r[ée]ception|lev[ée]e des r[ée]serves|garantie/i.test(String(x.title || '') + ' ' + String(x.model || '')); }).length;
      var verse = 0; try { var s = X.situation({ projectId: pid }).total; Object.keys(s || {}).forEach(function (c) { verse += num(s[c] && s[c].verse); }); } catch (e) {}
      return { P: P, client: cl ? (cl.full_name || cl.company || cl.id) : '', quotes: q, inv: inv, sit: sit, docs: pieces, docsEmis: pieces.filter(function (x) { return /^(emis|émis|sign)/i.test(String(x.status || '')); }).length,
        etudes: etudes, plans: plans, po: po, mv: mv, achats: po.length + mv.length, jr: jr, ts: ts, taches: taches, terrain: jr.length + ts.length + taches.length,
        contrats: contrats, reception: reception, verse: verse, v67: v67, v67n: v67n, v67eng: v67eng };
    }

    /* état d'une étape : fait / a-faire / saut (étape ultérieure faite alors qu'une étape obligatoire précédente manque) */
    function evaluate(defs, ctx) {
      var steps = defs.map(function (s) { var r = s.calc(ctx); return { fam: s.fam || '', prep: s.prep || '', id: s.id, ico: s.ico, nom: s.nom, mod: s.mod, opt: !!s.opt, n: r.n, detail: r.detail, done: r.n > 0, etat: r.n > 0 ? 'fait' : 'a-faire' }; });
      var lastDone = -1; steps.forEach(function (s, i) { if (s.done) lastDone = i; });
      steps.forEach(function (s, i) { if (!s.done && !s.opt && i < lastDone) s.etat = 'saut'; });
      var req = steps.filter(function (s) { return !s.opt; }), doneReq = req.filter(function (s) { return s.done; }).length;
      var next = steps.filter(function (s) { return !s.done && !s.opt; })[0] || steps.filter(function (s) { return !s.done; })[0] || null;
      return { steps: steps, pct: req.length ? Math.round(100 * doneReq / req.length) : 0, next: next, sauts: steps.filter(function (s) { return s.etat === 'saut'; }) };
    }
    function chantier(pid) { var c = chantierCtx(pid); return c ? Object.assign({ id: pid, nom: c.P.name }, evaluate(CH, c)) : null; }

    /* ======================= 2. parcours formation ======================= */
    var FO = [
      { id: 'inscription', ico: '👤', nom: 'Inscription', mod: 'participants', calc: function (c) { return { n: 1, detail: c.P.name || c.P.full_name || c.P.participant_id || '' }; } },
      { id: 'formation', ico: '📚', nom: 'Formation', mod: 'formations', calc: function (c) { return { n: (c.P.formation_id || c.P.training) ? 1 : 0, detail: c.P.training || (c.P.formation_id ? 'formation reliée' : 'aucune formation renseignée') }; } },
      { id: 'paiement', ico: '💵', nom: 'Paiement', mod: 'finances', calc: function (c) { return { n: c.pay.length, detail: c.pay.length ? c.pay.length + ' paiement(s) enregistré(s)' : 'aucun paiement enregistré' }; } },
      { id: 'recu', ico: '🧾', nom: 'Reçu', mod: 'receipts', opt: true, calc: function (c) { var sans = c.pay.filter(function (y) { return !y.receipt_no; }).length; return { n: c.rec.length, detail: c.rec.length ? c.rec.length + ' reçu(s)' + (sans ? ' — ' + sans + ' paiement(s) sans reçu' : '') : (c.pay.length ? c.pay.length + ' paiement(s) sans reçu' : 'aucun reçu') }; } },
      { id: 'presence', ico: '✅', nom: 'Présences', mod: 'presence', calc: function (c) { return { n: c.att.length, detail: c.att.length ? c.att.length + ' pointage(s) de présence' : 'aucune présence' }; } },
      { id: 'evaluation', ico: '📝', nom: 'Évaluations', mod: 'evaluations', calc: function (c) { return { n: c.ev.length + c.cot.length, detail: (c.ev.length + c.cot.length) ? (c.ev.length + c.cot.length) + ' évaluation(s) / cotation(s)' : 'aucune évaluation' }; } },
      { id: 'certificat', ico: '🏅', nom: 'Certificat', mod: 'certs', calc: function (c) { return { n: c.cert.length, detail: c.cert.length ? c.cert.length + ' certificat(s) délivré(s)' : 'pas de certificat' }; } }
    ];
    function partIds(p) { return [p.participant_id, p.id].filter(Boolean).map(String); }
    function formationCtx(key) {
      var P = rd(K.par).filter(function (p) { return p && partIds(p).indexOf(String(key)) >= 0; })[0]; if (!P) return null;
      var ids = partIds(P), nm = norm(P.name || P.full_name);
      var mineP = function (list) { return list.filter(function (o) { return o && (ids.indexOf(String(o.participant_id)) >= 0 || (!o.participant_id && nm && norm(o.participant || o.name || o.holder) === nm)); }); };
      return { P: P, rec: mineP(rd('exb_receipts')), pay: mineP(rd(K.pay)), att: mineP(rdF(K.att)), ev: mineP(rdF(K.ev)), cot: mineP(rdF(K.cot)), cert: mineP(rd(K.cert)) };
    }
    function formation(key) { var c = formationCtx(key); return c ? Object.assign({ id: String(key), nom: c.P.name || c.P.full_name || String(key) }, evaluate(FO, c)) : null; }

    /* ======================= 3. ouverture du module de l'étape ======================= */
    var SHOW = { clients: 'clients', metreDevis: 'metreDevis', stock: 'stock', projets: 'projets', comptabilite: 'comptabilite', participants: 'participants', formations: 'formations', finances: 'finances', presence: 'presence', evaluations: 'evaluations', certs: 'certs' };
    function pf(mod, pid) {
      var P = rd(K.par).filter(function (p) { return p && String(p.participant_id || p.id) === String(pid); })[0]; if (!P) return;
      var $ = function (i) { return d.getElementById(i); };
      setTimeout(function () {
        try {
          if (mod === 'finances') { var s = $('pay_participant'); if (s) { if (typeof w.fillPaymentParticipants === 'function') w.fillPaymentParticipants(); s.value = P.participant_id; if (typeof w.onPaymentParticipantChange === 'function') w.onPaymentParticipantChange(); } }
          else if (mod === 'presence') { var t = $('att_training'); if (t && P.training) { t.value = P.training; if (typeof w.renderAttendance === 'function') w.renderAttendance(); } }
          else if (mod === 'evaluations') { var e = $('eval_participant'); if (e) { e.value = P.participant_id; if (typeof w.loadEvaluationParticipant === 'function') w.loadEvaluationParticipant(); } }
          else if (mod === 'certs') {
            var hasEv = rdF(K.ev).some(function (x) { return x && x.participant_id === P.participant_id; }), es = $('eval_total_participant');
            if (hasEv && es && typeof w.importEvaluationTotalsToCertificate === 'function') { try { if (typeof w.renderEvaluationTotals === 'function') w.renderEvaluationTotals(); } catch (x) {} es.value = P.participant_id; w.importEvaluationTotalsToCertificate(); try { w.show('certs'); } catch (x) {} }
            else if (typeof w.certTemplateFromParticipant === 'function') { var c = w.certTemplateFromParticipant(P) || {}; var m = { cert_participant_id: 'participant_id', cert_photo_data: 'photo', holder: 'holder', training: 'training', start_date: 'start_date', end_date: 'end_date', duration: 'duration', mention: 'mention', place: 'place', program: 'program' }; Object.keys(m).forEach(function (id) { if ($(id) && c[m[id]] != null) $(id).value = c[m[id]]; }); }
          }
        } catch (x) {}
      }, 200);
    }
    function go(mod, pid, fam, kind) {
      try {
        if (kind === 'formation' && mod === 'receipts') { var Y = rd(K.pay).filter(function (y) { return y && y.participant_id === pid && !y.receipt_no; })[0]; if (Y && w.EXB205 && w.EXB205.makeReceipt) { w.EXB205.makeReceipt(Y.payment_id); return true; } }
        if (mod === 'v67' && typeof w.exbV67Open === 'function') { w.exbV67Open(null, pid); return true; }
        if (mod === 'docs' && w.EXBDCH && w.EXBDCH.open) { w.EXBDCH.open(); if (pid && w.EXBDCH.proj) w.EXBDCH.proj(pid); if (fam && w.EXBDCH.cat) w.EXBDCH.cat(fam); return true; }
        if (mod === 'facture') { if (typeof w.show === 'function') { try { w.show('chantiers'); } catch (e) { w.show('comptabilite'); } if (pid && w.EXBCH && w.EXBCH.pid) { try { w.EXBCH.pid(pid); } catch (e) {} } try { w.scrollTo(0, 0); } catch (e) {} return true; } }
        if (mod === 'calcul') { if (w.EXBCALC && w.EXBCALC.open) { w.EXBCALC.open(); return true; } mod = 'bureauEtudes'; }
        if (mod === 'plans') { if (w.EXBPLN && w.EXBPLN.open) { w.EXBPLN.open(); if (pid && w.EXBPLN.proj) w.EXBPLN.proj(pid); return true; } if (w.EXBPLANED && w.EXBPLANED.open) { w.EXBPLANED.open(); return true; } mod = 'bureauEtudes'; }
        var id = SHOW[mod] || mod; if (typeof w.show === 'function') { w.show(id); if (kind === 'formation') pf(mod, pid); try { w.scrollTo(0, 0); } catch (e) {} return true; }
      } catch (e) { try { if (typeof w.notify === 'function') w.notify('Ouverture du module impossible : ' + (e.message || e), 'error', 6000); } catch (x) {} }
      return false;
    }

    /* ======================= 3b. actions explicites (confirmées une à une) ======================= */
    function canWrite() { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can('projets', 'ecrire'); } catch (e) { return true; } }
    function readList(k) { try { if (w.EXBS && typeof w.EXBS.get === 'function' && /^exb_(pieces|plan_files)$/.test(k)) { var v = w.EXBS.get(k); if (Array.isArray(v)) return v; } } catch (e) {} return rd(k); }
    function writeList(k, list) { try { if (w.EXBS && typeof w.EXBS.set === 'function' && /^exb_(pieces|plan_files)$/.test(k)) { w.EXBS.set(k, list); return true; } } catch (e) {} return X.wr(k, list); }
    /* collections rattachables : [clé, libellé, champ du chantier, filtre, libellé d'une fiche] */
    var ATT = [
      [K.qt, 'Devis', 'project_id', null, function (o) { return o.no || o.id; }],
      [K.inv, 'Facture', 'project_id', null, function (o) { return o.no || o.id; }],
      [K.st, 'Étude', 'project_id', null, function (o) { return o.title || o.name || o.id; }],
      [K.cn, 'Note de calcul', 'project_id', null, function (o) { return o.title || o.name || o.id; }],
      [K.po, 'Commande d’achat', 'project_id', null, function (o) { return o.no || o.id; }],
      [K.jr, 'Journal de chantier', 'project_id', null, function (o) { return (o.date || '') + ' ' + (o.title || o.text || o.id); }],
      [K.pie, 'Document de chantier', 'project', function (o) { return !isModel(o); }, function (o) { return (o.no || '') + ' ' + (o.title || o.id); }],
      [K.pf, 'Fichier de plan', 'project', null, function (o) { return (o.ref || '') + ' ' + (o.name || o.id); }]
    ];
    /* fiches sans chantier. Si le chantier a un client, on ne propose que les fiches de ce client ou sans client (une proposition, jamais un rattachement automatique) */
    function orphans(pid) {
      var P = rd(K.prj).filter(function (p) { return p && p.id === pid; })[0]; if (!P) return [];
      var out = [];
      ATT.forEach(function (a) {
        readList(a[0]).forEach(function (o) {
          if (!o || !o.id || o[a[2]] || (a[3] && !a[3](o))) return;
          if (P.client_id && o.client_id && o.client_id !== P.client_id) return;
          out.push({ k: a[0], id: o.id, kind: a[1], label: String(a[4](o) || o.id).trim() });
        });
      });
      return out;
    }
    function attach(k, id, pid) {
      if (!canWrite()) { say('Écriture non autorisée.', 'error'); return false; }
      var a = ATT.filter(function (x) { return x[0] === k; })[0], list = readList(k), o = list.filter(function (x) { return x && x.id === id; })[0], P = rd(K.prj).filter(function (p) { return p && p.id === pid; })[0];
      if (!a || !o || !P || o[a[2]]) return false;
      if (!w.confirm('Rattacher ' + a[1].toLowerCase() + ' « ' + String(a[4](o)).trim() + ' » au chantier « ' + P.name + ' » ?')) return false;
      o[a[2]] = pid; if (P.client_id && !o.client_id && a[2] === 'project_id') o.client_id = P.client_id;
      if (!writeList(k, list)) { say('Enregistrement impossible.', 'error'); return false; }
      try { X.log('rattachement', { key: k, id: id, project_id: pid }, a[1] + ' rattaché(e) au chantier « ' + P.name + ' » depuis le Parcours'); } catch (e) {}
      return true;
    }
    function say(m, t) { try { if (typeof w.notify === 'function') w.notify(m, t || 'info', 5000); } catch (e) {} }
    /* brouillon de facture depuis le devis émis : même mécanisme que l'Intelligence (EXBCH.fromQuote), rien n'est créé sans confirmation */
    function prepareInvoice(pid) {
      var c = chantierCtx(pid); if (!c) return false;
      var q = c.quotes.filter(issued)[0];
      if (!q) { say('Aucun devis émis ou approuvé à facturer pour ce chantier.', 'warn'); return false; }
      if (!w.EXBCH || !w.EXBCH.fromQuote) { say('Le module de facturation est indisponible.', 'error'); return false; }
      if (!w.confirm('Préparer un brouillon de facture à partir du devis ' + (q.no || q.id) + ' ?')) return false;
      try { if (typeof w.show === 'function') w.show('chantiers'); } catch (e) {}
      setTimeout(function () { try { w.EXBCH.pid(pid); w.EXBCH.fromQuote(q.id); X.log('brouillon_facture', { project_id: pid, quote: q.id }, 'Brouillon de facture préparé depuis le devis ' + (q.no || q.id) + ' (Parcours)'); } catch (e) { say('Préparation impossible.', 'error'); } }, 500);
      return true;
    }

    /* ======================= 4. alertes (« points à vérifier » de la Liaison) ======================= */
    function anomalies() {
      var out = [], P = rd(K.prj), pids = {};
      P.forEach(function (p) { if (p && p.id) pids[p.id] = 1; });
      P.forEach(function (p) {
        if (!p || !p.id) return; var c = chantierCtx(p.id); if (!c) return; var nom = '« ' + p.name + ' »';
        if ((c.inv.length || c.sit.length) && !c.quotes.length && !c.contrats) out.push('Parcours — chantier ' + nom + ' : facturé sans devis ni contrat');
        if (c.terrain && !c.quotes.length && !c.contrats && !c.inv.length) out.push('Parcours — chantier ' + nom + ' : activité de chantier sans devis, contrat ni facture');
        if (c.docsEmis && !c.client) out.push('Parcours — chantier ' + nom + ' : ' + c.docsEmis + ' document(s) de chantier émis ou signé(s) mais aucun client relié');
        if ((c.plans || c.etudes) && !c.client) out.push('Parcours — chantier ' + nom + ' : études ou plans produits mais aucun client relié');
      });
      rd(K.pie).forEach(function (x) { if (x && !isModel(x) && x.project && !pids[x.project]) out.push('Parcours — document de chantier ' + (x.no || x.id) + ' : le chantier relié n’existe plus'); });
      rd(K.pf).forEach(function (x) { if (x && x.project && !pids[x.project]) out.push('Parcours — plan « ' + (x.ref || x.name || x.id) + ' » : le chantier relié n’existe plus'); });
      return out.concat(registryIssues());
    }

    /* ======================= 5. écrans ======================= */
    var BADGE = { fait: ['✅', '#16a34a', '#f0fdf4'], 'a-faire': ['⏳', '#64748b', '#f8fafc'], saut: ['⚠️', '#b45309', '#fffbeb'] };
    function css() {
      if (d.getElementById('exbParcoursCss')) return; var s = d.createElement('style'); s.id = 'exbParcoursCss';
      s.textContent = '.exbPc{border:1px solid #e2e8f0;border-radius:12px;padding:12px;margin:10px 0;background:#fff}.exbPc h3{margin:0 0 8px}.exbPcBar{height:8px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin:6px 0 10px}.exbPcBar i{display:block;height:100%;background:linear-gradient(90deg,#173565,#c49a38)}' +
        '.exbPcSteps{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:8px}.exbPcStep{border:1px solid;border-radius:10px;padding:8px 10px;display:flex;flex-direction:column;gap:4px}.exbPcStep b{font-size:13px}.exbPcStep small{font-size:11px;color:#475569}.exbPcStep button,.exbPc button{font-size:13px;padding:8px 12px;min-height:38px;cursor:pointer;margin:2px 4px 2px 0}.exbPcStep{min-width:0;overflow-wrap:anywhere}.exbPcOrph{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap;border-bottom:1px solid #e2e8f0;padding:4px 0;font-size:13px}.exbPc{max-width:100%;overflow-x:hidden}.exbPcNext{margin:8px 0;padding:8px 10px;border-radius:10px;background:#eff6ff;border:1px solid #bfdbfe;font-size:13px}';
      d.head.appendChild(s);
    }
    function ctxHasIssued(pid) { var c = chantierCtx(pid); return !!(c && c.quotes.some(issued)); }
    function orphansHtml(pid) {
      var O = orphans(pid), btn = '<button type="button" data-exbpc-link="1">🔗 Relier automatiquement (sans deviner)</button>';
      if (!O.length) return '<p style="margin:10px 0 0">' + btn + '</p>';
      return '<details style="margin-top:10px"><summary><b>Fiches non rattachées à un chantier (' + O.length + ')</b></summary><p class="exb-muted" style="font-size:12px;margin:6px 0">Rien n’est deviné : choisissez, fiche par fiche, celles qui appartiennent à ce chantier.</p>' +
        O.slice(0, 40).map(function (o) { return '<div class="exbPcOrph"><span><b>' + esc(o.kind) + '</b> · ' + esc(o.label) + '</span><button type="button" data-exbpc-att="' + esc(o.k + '|' + o.id) + '" data-exbpc-id="' + esc(pid) + '">Rattacher</button></div>'; }).join('') +
        (O.length > 40 ? '<p class="exb-muted" style="font-size:12px">… et ' + (O.length - 40) + ' autre(s).</p>' : '') + '</details><p style="margin:8px 0 0">' + btn + '</p>';
    }
    function stepsHtml(R, kind, id) {
      return '<div class="exbPcBar"><i style="width:' + R.pct + '%"></i></div><div class="exbPcNext">' + (R.next ? '<b>Prochaine étape :</b> ' + esc(R.next.ico + ' ' + R.next.nom) + ' — ' + esc(R.next.detail) + ' <button type="button" data-exbpc-go="' + esc(R.next.mod) + '" data-exbpc-id="' + esc(id) + '" data-exbpc-kind="' + kind + '" data-exbpc-fam="' + esc(R.next.fam) + '" style="margin-left:6px">Continuer →</button>' : '<b>Parcours complet</b> — toutes les étapes sont renseignées.') + '</div>' +
        '<div class="exbPcSteps">' + R.steps.map(function (s) { var b = BADGE[s.etat]; return '<div class="exbPcStep" style="border-color:' + b[1] + '55;background:' + b[2] + '"><b>' + b[0] + ' ' + esc(s.ico + ' ' + s.nom) + (s.opt ? ' <small>(facultatif)</small>' : '') + '</b><small>' + esc(s.detail) + (s.etat === 'saut' ? ' — étape sautée' : '') + '</small><button type="button" data-exbpc-go="' + esc(s.mod) + '" data-exbpc-id="' + esc(id) + '" data-exbpc-kind="' + kind + '" data-exbpc-fam="' + esc(s.fam) + '">Ouvrir</button>' + (kind === 'chantier' && s.prep === 'facture' && !s.done && ctxHasIssued(id) ? '<button type="button" data-exbpc-prep="facture" data-exbpc-id="' + esc(id) + '">Préparer la facture</button>' : '') + '</div>'; }).join('') + '</div>' + (kind === 'chantier' ? orphansHtml(id) : '') +
        (R.sauts.length ? '<p class="exb-muted" style="font-size:12px;margin:8px 0 0">⚠️ Étape(s) sautée(s) : ' + R.sauts.map(function (s) { return esc(s.nom); }).join(', ') + '. Ce n’est pas bloquant : c’est un rappel.</p>' : '');
    }
    function panel(hostId, title, options, kind, anchorId, parentId) {
      var sec = d.getElementById(parentId); if (!sec) return;
      var host = d.getElementById(hostId);
      if (!host) { host = d.createElement('div'); host.id = hostId; host.className = 'exbPc card'; var a = anchorId && d.getElementById(anchorId); if (a && a.parentNode) a.parentNode.insertBefore(host, a); else sec.insertBefore(host, sec.firstChild); }
      var sel = host.querySelector('select'), cur = sel ? sel.value : '';
      var sig = kind + '|' + options.map(function (o) { return o[0] + o[1]; }).join('~');
      if (host.getAttribute('data-sig') !== sig) {
        host.innerHTML = '<h3>' + title + '</h3><select style="max-width:100%"><option value="">— Choisir —</option>' + options.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (o[0] === cur ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select><div class="out" style="margin-top:8px"></div>';
        host.setAttribute('data-sig', sig);
      }
      var s = host.querySelector('select'), o = host.querySelector('.out');
      function fill() { var v = s.value; if (!v) { o.innerHTML = ''; return; } var R = kind === 'chantier' ? chantier(v) : formation(v); o.innerHTML = R ? stepsHtml(R, kind, v) : ''; }
      s.onchange = fill; fill();
    }
    function render() {
      try {
        css();
        panel('exbParcoursPrj', '🧭 Parcours du chantier', rd(K.prj).filter(function (p) { return p && p.id; }).map(function (p) { return [p.id, p.name || p.id]; }), 'chantier', 'exbLienPrj', 'projets');
        panel('exbParcoursPar', '🧭 Parcours de l’apprenant', rd(K.par).filter(function (p) { return p && (p.participant_id || p.id); }).map(function (p) { return [String(p.participant_id || p.id), (p.name || p.full_name || p.participant_id || p.id) + (p.training ? ' — ' + p.training : '')]; }), 'formation', '', 'participants');
      } catch (e) {}
    }
    d.addEventListener('click', function (e) {
      var t = e.target; if (!t || !t.closest) return;
      var b = t.closest('[data-exbpc-att]');
      if (b) { e.preventDefault(); var kv = b.getAttribute('data-exbpc-att').split('|'); if (attach(kv[0], kv.slice(1).join('|'), b.getAttribute('data-exbpc-id'))) render(); return; }
      b = t.closest('[data-exbpc-link]'); if (b) { e.preventDefault(); try { X.refresh(); } catch (x) {} render(); return; }
      b = t.closest('[data-exbpc-prep]'); if (b) { e.preventDefault(); prepareInvoice(b.getAttribute('data-exbpc-id')); return; }
      b = t.closest('[data-exbpc-go]'); if (!b) return;
      e.preventDefault(); go(b.getAttribute('data-exbpc-go'), b.getAttribute('data-exbpc-id') || '', b.getAttribute('data-exbpc-fam') || '', b.getAttribute('data-exbpc-kind') || '');
    });
    var f = w.show; if (typeof f === 'function' && !f.__parcours) { var g = function (x) { var r = f.apply(this, arguments); if (x === 'projets' || x === 'participants') setTimeout(render, 0); return r; }; g.__parcours = true; w.show = g; }
    w.addEventListener && w.addEventListener('exb-liaison-change', function () { setTimeout(render, 0); });

    X.extend({ link: function () { render(); }, anomalies: anomalies, html: function () { return ''; } });
    X.parcours = { version: VERSION, chantier: chantier, formation: formation, go: go, orphans: orphans, attach: attach, prepareInvoice: prepareInvoice, anomalies: anomalies, registryIssues: registryIssues, render: render, etapesChantier: CH.map(function (s) { return s.id; }), etapesFormation: FO.map(function (s) { return s.id; }) };
    w.EXBPARCOURS = X.parcours;
    render();
  }
  patchRegistry();
  boot(0);
})(window, document);
