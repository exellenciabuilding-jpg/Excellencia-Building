/* Excellencia — licence à échéance (hors ligne, signée). Le client ne peut pas modifier la date : le code est signé par la clé privée de l'administrateur. */
(function(w){'use strict';
var PUB={"kty":"EC","crv":"P-256","x":"gCpjrY7LwHWYrCh9gdvZyC2wgFF7ghdI4vRWdXHfh0c","y":"99QF0mj8LF9emZjQvRcjSKooAqP0tSZBOD-T-IdtgJ4"};
var CFG=Object.assign({requireToken:false,warnDays:7,defaultGrace:7,contact:'l’administrateur Excellencia Building',server:'',serverPub:null,offlineDays:7,checkEveryMin:30,version:'V120o'},w.EXB_LICENSE_CONFIG||{});
/* V120o — clé PUBLIQUE du serveur de licences (les licences activées par code sont signées par le serveur, pas par le PC du propriétaire). */
var PUBS=(CFG.serverPub&&CFG.serverPub.x&&CFG.serverPub.y)?{kty:'EC',crv:'P-256',x:CFG.serverPub.x,y:CFG.serverPub.y}:null;
var KB='exb_lic_blk',KC='exb_lic_chk',FIRST=true;
var KT='exb_lic_token',KS='exb_lic_seen',KP='exb_lic_priv',subtle=w.crypto&&w.crypto.subtle,enc=new TextEncoder(),dec=new TextDecoder();
var KD='exb_dev_id';
function devId(){var v=ls(KD);if(v&&/^[A-Z2-9]{12}$/.test(v))return v;var a='ABCDEFGHJKMNPQRSTUVWXYZ23456789',r=new Uint8Array(12),s='';w.crypto.getRandomValues(r);for(var i=0;i<12;i++)s+=a[r[i]%a.length];ls(KD,s);return s}
function devFmt(v){return String(v||'').replace(/(.{4})(?=.)/g,'$1-')}
function devNorm(v){return String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'')}
function devOk(p){var l=p&&p.dev;if(!l||(Array.isArray(l)&&!l.length))return true;if(!Array.isArray(l))l=[l];var me=devId();return l.some(function(x){return devNorm(x)===me})}
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){return null}}
function b64u(buf){var b=new Uint8Array(buf),s='';for(var i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function unb64u(s){s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';var r=atob(s),u=new Uint8Array(r.length);for(var i=0;i<r.length;i++)u[i]=r.charCodeAt(i);return u}
async function vk(tok,PUBX){try{var a=String(tok||'').trim().split('.');if(a.length!==2)return null;var k=await subtle.importKey('jwk',PUBX,{name:'ECDSA',namedCurve:'P-256'},false,['verify']),pl=unb64u(a[0]);
  var ok=await subtle.verify({name:'ECDSA',hash:'SHA-256'},k,unb64u(a[1]),pl);return ok?JSON.parse(dec.decode(pl)):null}catch(e){return null}}
async function verify(tok){var p=await vk(tok,PUB);if(p)return p;if(PUBS){p=await vk(tok,PUBS);if(p&&p.v===2&&(p.cid||p.org===1))return p}return null}
/* Heure de confiance : jamais en arrière de la dernière heure vue (même après une réponse du serveur, V120o) ; recalée sur le serveur quand le réseau est disponible. */
var srv=0,srvAt=0;
function now(){var d=Date.now(),s=Number(ls(KS))||0,t=srv?srv+(d-srvAt):d;if(t<s)t=s;ls(KS,String(t));return t}
var lastTS=0;/* V144e : au plus une demande d'heure au serveur toutes les 15 min (avant : chaque minute) */
async function syncTime(){try{var c=w.EXB_SUPABASE||w.EXB_FIELD_CONFIG||{},u=c.url||c.supabaseUrl,k=c.key||c.supabaseKey;if(!u||!navigator.onLine)return;if(lastTS&&Date.now()-lastTS<900000)return;lastTS=Date.now();
  var r=await fetch(u+'/auth/v1/health',{headers:{apikey:k||''}}),d=r.headers.get('Date');if(d){var t=Date.parse(d);if(t>0){srv=t;srvAt=Date.now();ls(KS,String(t))}}}catch(e){}}
/* V120n — une clé « administrateur » n'est valide que si elle SIGNE réellement un code reconnu par la clé publique.
   Avant : il suffisait d'écrire {"d":"x","x":<x public>} dans le stockage local pour supprimer tout blocage. */
var ADM_OK=null;
function shape(p){return !!(p&&typeof p.d==='string'&&p.d.length>=40&&p.x===PUB.x&&p.y===PUB.y&&p.kty==='EC'&&p.crv==='P-256')}
function isAdmin(){try{var p=JSON.parse(ls(KP)||'null');if(!shape(p))return false;return ADM_OK!==false}catch(e){return false}}
async function vetAdmin(){try{var p=JSON.parse(ls(KP)||'null');if(!p)return;if(!shape(p)||!(await keyOk(p))){ADM_OK=false;ls(KP,null);setTimeout(function(){try{location.reload()}catch(e){}},50)}else ADM_OK=true}catch(e){}}
async function state(){
  if(isAdmin())return{mode:'admin'};
  var tok=ls(KT);if(!tok)return CFG.requireToken?{mode:'locked',reason:'none'}:{mode:'free'};
  var p=await verify(tok);if(!p)return{mode:'locked',reason:'invalid'};
  if(!devOk(p))return{mode:'locked',reason:'device'};
  var bk=blk();if(bk)return{mode:'locked',reason:bk.r,name:p.name};
  var t=now(),exp=Date.parse(p.exp),g=(p.grace==null?CFG.defaultGrace:Number(p.grace))*864e5,left=exp-t;
  var info={name:p.name||'',exp:p.exp,graceDays:g/864e5,daysLeft:Math.ceil(left/864e5),blockAt:new Date(exp+g).toISOString(),skew:Math.round((t-Date.now())/864e5)};
  if(p.v===2&&p.off&&left+g>0){var vb=Date.parse(p.iat)+Number(p.off)*864e5,vl=vb-t;if(vl<=0)return Object.assign({mode:'locked',reason:'verify'},info);if(vl<2*864e5)info.verifyBy=new Date(vb).toISOString()}
  if(left>CFG.warnDays*864e5)return Object.assign({mode:'ok'},info);
  if(left>0)return Object.assign({mode:'warn'},info);
  if(left+g>0)return Object.assign({mode:'grace',daysToBlock:Math.ceil((left+g)/864e5)},info);
  return Object.assign({mode:'locked',reason:'expired'},info)}
function fmt(iso){try{return new Date(iso).toLocaleString('fr-FR',{dateStyle:'long',timeStyle:'short'})}catch(e){return iso}}
function banner(h,bg){var b=document.getElementById('exbLicBar');if(!h){if(b)b.remove();return}if(!b){b=document.createElement('div');b.id='exbLicBar';document.body.appendChild(b)}
  b.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:99998;padding:10px 14px;font:14px system-ui;text-align:center;color:#fff;background:'+bg;b.innerHTML=h}
function lock(msg){var d=document.getElementById('exbLicLock');if(d&&d.getAttribute('data-msg')===msg)return;if(!d){d=document.createElement('div');d.id='exbLicLock';document.body.appendChild(d)}
  d.style.cssText='position:fixed;inset:0;z-index:100000;background:#173565;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;font:17px system-ui;overflow:auto';
  d.setAttribute('data-msg',msg);d.innerHTML='<div style="max-width:420px"><div style="font-size:48px">🔒</div><h2 style="color:#fff">Logiciel verrouillé</h2><p>'+msg+'</p><p style="font-size:14px;opacity:.85">Saisissez votre <b>code d’activation</b> (<b>EXC-XXXX-XXXX-XXXX</b>) ou, si vous avez été invité(e), <b>uniquement votre code d’invitation</b> (8 caractères). Sinon, contactez '+CFG.contact+' pour obtenir un code d’activation (ou ouvrez le lien reçu).</p><p style="font-size:14px;margin:8px 0">Code de cet appareil : <b id="exbDevId" style="letter-spacing:1px">'+devFmt(devId())+'</b> <a href="#" id="exbDevCp" style="color:#fcd34d">copier</a></p><textarea id="exbLicIn" placeholder="Code d’invitation ou d’activation" autocapitalize="none" autocomplete="off" spellcheck="false" style="width:100%;min-height:70px;border-radius:10px;border:0;padding:10px;color:#000"></textarea><button id="exbLicGo" style="margin-top:10px;padding:12px 20px;border:0;border-radius:10px;background:#f5a623;font-weight:700">Activer</button><div id="exbLicMsg" style="margin-top:10px;color:#fecaca"></div></div>';
  document.getElementById('exbLicGo').onclick=async function(){var v=document.getElementById('exbLicIn').value.trim(),m=document.getElementById('exbLicMsg'),g=document.getElementById('exbLicGo');if(!v){m.textContent='Saisissez votre code.';return}g.disabled=true;m.textContent='Vérification…';var r=isActCode(v)?await activateCode(v):isInvCode(v)?await viaInvite(v):await apply(v);g.disabled=false;m.textContent=r.ok?'':r.msg;if(r.ok){if(r.reload)location.reload();else check()}};
  document.getElementById('exbDevCp').onclick=function(e){e.preventDefault();try{navigator.clipboard.writeText(devFmt(devId()))}catch(x){}this.textContent='copié'};
  adminUI(d)}
/* V99zzzk — accès administrateur depuis l'écran de verrouillage (nouvelle installation, nouvel appareil).
 * Accepte : sauvegarde chiffrée (SAUVEGARDE-CLE-LICENCE-*.json + mot de passe) ou clé brute (CLE-PRIVEE-ADMIN.txt).
 * La clé n'est acceptée que si elle signe un code que la clé publique intégrée reconnaît. */
function unb64s(x){var b=atob(x),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
async function decBackup(f,pass){var m=await subtle.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);
  var k=await subtle.deriveKey({name:'PBKDF2',salt:unb64s(f.salt),iterations:f.iter||250000,hash:'SHA-256'},m,{name:'AES-GCM',length:256},false,['decrypt']);
  try{return dec.decode(await subtle.decrypt({name:'AES-GCM',iv:unb64s(f.iv)},k,unb64s(f.data)))}catch(e){throw new Error('Mot de passe incorrect ou fichier modifié.')}}
async function keyOk(j){try{if(!j||!j.d||j.x!==PUB.x)return false;var k=await subtle.importKey('jwk',j,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
  var b=enc.encode(JSON.stringify({v:1,name:'test',exp:new Date(Date.now()+864e5).toISOString(),grace:0,id:'test'})),sg=await subtle.sign({name:'ECDSA',hash:'SHA-256'},k,b);
  return !!(await verify(b64u(b)+'.'+b64u(sg)))}catch(e){return false}}
async function adminUnlock(text,pass,keep){
  var j;try{j=JSON.parse(String(text||'').trim())}catch(e){return{ok:false,msg:'Contenu illisible : choisissez le bon fichier ou collez la clé complète.'}}
  if(j&&j.app==='excellencia-licence-key'){if(!pass)return{ok:false,msg:'Saisissez le mot de passe de la sauvegarde.'};try{j=JSON.parse(await decBackup(j,pass))}catch(e){return{ok:false,msg:e.message||'Sauvegarde illisible.'}}}
  if(!await keyOk(j))return{ok:false,msg:'Cette clé ne correspond pas à ce logiciel.'};
  try{if(keep)localStorage.setItem('exb_lic_keep','1');else localStorage.removeItem('exb_lic_keep')}catch(e){}
  ls(KP,JSON.stringify(j));
  return isAdmin()?{ok:true}:{ok:false,msg:'Impossible d’enregistrer la clé sur cet appareil.'}}
function adminUI(d){var box=d.firstChild;if(!box)return;var wr=document.createElement('div');
  wr.style.cssText='margin-top:22px;border-top:1px solid rgba(255,255,255,.25);padding-top:14px';
  var inp='width:100%;box-sizing:border-box;border-radius:10px;border:0;padding:10px;color:#000;margin-top:8px';
  wr.innerHTML='<a href="#" id="exbAdmLnk" style="color:#fcd34d;font-size:14px;text-decoration:underline">🔑 Accès administrateur</a>'
   +'<div id="exbAdmBox" style="display:none;margin-top:12px;text-align:left;font-size:14px">'
   +'<p style="opacity:.85;margin:0">Choisissez votre <b>sauvegarde chiffrée</b> (SAUVEGARDE-CLE-LICENCE-….json) ou <b>CLE-PRIVEE-ADMIN.txt</b>, ou collez la clé.</p>'
   +'<input type="file" id="exbAdmFile" accept=".json,.txt,application/json,text/plain" style="width:100%;margin-top:8px;color:#fff">'
   +'<textarea id="exbAdmTxt" placeholder="…ou collez ici la clé privée" autocapitalize="none" autocomplete="off" spellcheck="false" style="'+inp+';min-height:60px"></textarea>'
   +'<input type="password" id="exbAdmPw" placeholder="Mot de passe de la sauvegarde (fichier chiffré)" autocomplete="off" style="'+inp+'">'
   +'<label style="display:block;margin-top:10px"><input type="checkbox" id="exbAdmKeep" checked> Garder la clé sur cet appareil <span style="opacity:.75">(appareil personnel uniquement)</span></label>'
   +'<button id="exbAdmGo" style="margin-top:10px;padding:12px 20px;border:0;border-radius:10px;background:#fcd34d;color:#000;font-weight:700;width:100%">Déverrouiller en administrateur</button>'
   +'<div id="exbAdmMsg" style="margin-top:10px;color:#fecaca;text-align:center"></div></div>';
  box.appendChild(wr);
  var $=function(i){return document.getElementById(i)},fileText='';
  $('exbAdmLnk').onclick=function(e){e.preventDefault();var b=$('exbAdmBox');b.style.display=b.style.display==='none'?'block':'none'};
  $('exbAdmFile').onchange=function(){var f=this.files&&this.files[0];if(!f){fileText='';return}var r=new FileReader();r.onload=function(){fileText=String(r.result||'');$('exbAdmMsg').style.color='#bbf7d0';$('exbAdmMsg').textContent='Fichier chargé : '+f.name}; r.onerror=function(){$('exbAdmMsg').textContent='Lecture du fichier impossible.'};r.readAsText(f)};
  $('exbAdmGo').onclick=async function(){var m=$('exbAdmMsg'),g=this;m.style.color='#fecaca';var t=(fileText||$('exbAdmTxt').value||'').trim();if(!t){m.textContent='Choisissez un fichier ou collez la clé.';return}
    g.disabled=true;m.textContent='Vérification…';var r=await adminUnlock(t,$('exbAdmPw').value,$('exbAdmKeep').checked);g.disabled=false;
    if(r.ok){m.style.color='#bbf7d0';m.textContent='✓ Appareil administrateur activé.';setTimeout(function(){location.reload()},600)}else m.textContent=r.msg}}
function unlock(){var d=document.getElementById('exbLicLock');if(d)d.remove()}
async function apply(tok){tok=String(tok||'').trim();var p=await verify(tok);if(!p)return{ok:false,msg:'Code invalide ou modifié.'};
  if(!devOk(p))return{ok:false,msg:'Ce code est réservé à un autre appareil. Votre code appareil : '+devFmt(devId())+'. Envoyez-le à '+CFG.contact+'.'};
  var cur=ls(KT),c=cur?await verify(cur):null;if(c&&Date.parse(c.exp)>Date.parse(p.exp)&&Date.parse(c.exp)>now())return{ok:false,msg:'Ce code est plus ancien que votre abonnement actuel.'};
  if(Date.parse(p.exp)+(p.grace==null?CFG.defaultGrace:p.grace)*864e5<=now())return{ok:false,msg:'Ce code est déjà expiré.'};
  ls(KT,tok);try{if(p.brand){var bo={};try{bo=JSON.parse(ls('EXB_BRAND_V1')||'{}')}catch(e){}var nb=Object.assign({},(bo&&bo.brand)||{},p.brand);ls('EXB_BRAND_V1',JSON.stringify({done:true,fixed:!!p.lockBrand,brand:nb}))}if(p.srv&&p.srv.url&&p.srv.key){var b2={};try{b2=JSON.parse(ls('EXB_BRAND_V1')||'{}')}catch(e){}b2.brand=Object.assign({},b2.brand||{},{supabaseUrl:p.srv.url,supabaseKey:p.srv.key});b2.done=true;ls('EXB_BRAND_V1',JSON.stringify(b2))}if(p.acct&&p.acct.id&&(p.acct.pw||p.acct.first))ls('EXB_ACCT_LOCK',JSON.stringify({id:p.acct.id,pw:p.acct.pw||'',first:!!p.acct.first,jid:p.id||''}));else ls('EXB_ACCT_LOCK',null)}catch(e){}return{ok:true,payload:p,reload:!!(p.brand||p.acct||p.srv)}}
function lockMsg(s){var r=s.reason,c=CFG.contact;return r==='none'?'Ce logiciel nécessite un code d’activation.':r==='invalid'?'Code d’activation invalide.':r==='device'?'Cet appareil n’est plus reconnu par votre licence (données du navigateur effacées, application réinstallée ou autre adresse du site ?). Saisissez à nouveau votre code d’activation ; s’il est refusé pour cause de limite d’appareils, envoyez le code appareil ci-dessous à '+c+' pour libérer l’ancien.'
  :r==='suspended'?'Votre licence est suspendue. Contactez '+c+'.':r==='revoked'?'Votre licence a été révoquée. Contactez '+c+'.'
  :r==='released'||r==='unknown'?'Cet appareil n’est plus enregistré sur votre licence. Saisissez votre code d’activation (ou contactez '+c+').'
  :r==='verify'?'Vérification de la licence requise : connectez-vous à internet, le logiciel se déverrouillera tout seul.':'Votre abonnement a expiré le '+fmt(s.exp)+'.'}
function diag(s){var x='';if((s.reason==='verify'||s.reason==='expired')&&s.skew>=2)x+='<p style="font-size:14px;color:#fcd34d">⚠ La date de cet appareil semble avoir été modifiée (écart d’environ '+s.skew+' jour(s) avec l’heure de confiance). Connectez-vous à internet : la licence se resynchronise toute seule, sans nouveau code.</p>';return x+'<p style="font-size:12px;opacity:.65">Diagnostic : '+String(s.reason||'?').replace(/[^\w-]/g,'')+dgText()+'</p>'}
function invUrl(){try{var m=String(location.search||'').match(/[?&]inv=([A-Za-z0-9]{4,32})/);if(m)return m[1].toLowerCase();return sessionStorage.getItem('exb_inv_url')||''}catch(e){return''}}
try{var iu=(String(location.search||'').match(/[?&]inv=([A-Za-z0-9]{4,32})/)||[])[1];if(iu)sessionStorage.setItem('exb_inv_url',iu.toLowerCase())}catch(e){}
async function check(){await syncTime();await refresh(FIRST);FIRST=false;var s=await state();w.EXBLIC.last=s;
  /* V205y : lien d'accès personnel (?inv=CODE) → le logiciel s'active tout seul avec ce code, une seule tentative par ouverture */
  if(s.mode==='locked'){var ic=invUrl(),tried=null;try{tried=sessionStorage.getItem('exb_inv_try')}catch(e){}
    if(ic&&tried!==ic){try{sessionStorage.setItem('exb_inv_try',ic)}catch(e){}var ra=await viaInvite(ic);if(ra&&ra.ok){location.reload();return s}}}
  if(s.mode==='locked'){banner(null);lock(lockMsg(s)+diag(s));return s}
  unlock();
  if(s.mode==='warn')banner('⏳ Votre abonnement expire le <b>'+fmt(s.exp)+'</b> (dans '+s.daysLeft+' jour(s)). Pensez à le renouveler.','#b45309');
  else if(s.mode==='grace')banner('⚠️ Abonnement expiré. Renouvelez-le : le logiciel sera <b>bloqué le '+fmt(s.blockAt)+'</b> (dans '+s.daysToBlock+' jour(s)).','#b91c1c');
  else if(s.verifyBy)banner('📶 Connectez-vous à internet avant le <b>'+fmt(s.verifyBy)+'</b> pour vérifier votre licence.','#b45309');
  else banner(null);return s}
/* ---- Administrateur : génération de codes ---- */
/* V120q — UN SEUL MOTEUR : toute licence est émise par le serveur de licences (clé d'administration saisie dans « 🔑 Licences »). Plus de signature dans le navigateur. */
async function make(o){var s=null;try{s=JSON.parse(sessionStorage.getItem('exb_own')||'null')}catch(e){}
  if(!s||!s.url||!s.key)throw new Error('Moteur de licences non connecté : ouvrez « 🔑 Licences » et connectez-vous à votre serveur.');
  var r=await fetch(s.url,{method:'POST',headers:{'Content-Type':'application/json','x-admin-key':s.key},body:JSON.stringify({action:'admin.org_token',nom:o.name||'',expire_le:new Date(o.exp).toISOString(),grace_jours:o.grace==null?CFG.defaultGrace:Number(o.grace)})}),j=await r.json().catch(function(){return null});
  if(!j||!j.ok)throw new Error((j&&j.msg)||'Le serveur de licences a refusé.');return j.jeton}
async function adminDialog(){if(typeof w.exbOpenLicences==='function')return w.exbOpenLicences();exbAlert('Ouvrez « 🔑 Licences » (bouton en bas à droite) : c’est le seul endroit où l’on génère les licences.')}
/* V99zzj — activation par CODE D'INVITATION seul : le serveur renvoie l'abonnement signé de l'entreprise. */
function srvCfg(){var c=w.EXB_SUPABASE||{},u=c.url,k=c.key;try{var b=JSON.parse(ls('EXB_BRAND_V1')||'{}'),br=(b&&b.brand)||{};if(br.supabaseUrl&&br.supabaseKey){u=br.supabaseUrl;k=br.supabaseKey}}catch(e){}return{u:u,k:k}}
function isInvCode(v){v=String(v||'').trim();return v.indexOf('.')<0&&/^[a-z0-9]{4,32}$/i.test(v)}
async function viaInvite(code){code=String(code||'').trim().toLowerCase();var s=srvCfg();
  if(!s.u||!s.k)return{ok:false,msg:'Serveur non configuré : demandez un lien d’activation à l’administrateur.'};
  if(navigator.onLine===false)return{ok:false,msg:'Connexion internet requise pour utiliser un code d’invitation.'};
  try{var r=await fetch(s.u+'/rest/v1/rpc/activer_par_invitation',{method:'POST',headers:{'Content-Type':'application/json',apikey:s.k},body:JSON.stringify({p_code:code})});
    var j=null;try{j=await r.json()}catch(e){}
    if(!r.ok){var t=JSON.stringify(j||'');if(/activer_par_invitation|42883|PGRST202|schema cache/i.test(t))return{ok:false,msg:'Le service d’invitation n’est pas encore installé sur le serveur (migration v99zzj). Prévenez l’administrateur.'};return{ok:false,msg:'Serveur indisponible, réessayez dans un instant.'}}
    if(!j||!j.ok)return{ok:false,msg:(j&&j.msg)||'Code d’invitation invalide.'};
    var a=await apply(j.jeton);
    if(!a.ok)return{ok:false,msg:a.msg==='Code invalide ou modifié.'?'L’abonnement de cette entreprise n’est pas valide. Prévenez l’administrateur.':a.msg};
    ls('exb_inv_code',code);
    try{sessionStorage.setItem('exb_lic_msg','✓ Accès activé. Créez maintenant votre compte avec l’adresse e-mail indiquée dans votre invitation : vous rejoindrez l’entreprise automatiquement.')}catch(e){}
    a.reload=true;return a}
  catch(e){return{ok:false,msg:'Impossible de joindre le serveur. Vérifiez votre connexion.'}}}
/* V120o — activation par CODE (EXC-XXXX-XXXX-XXXX) : le serveur de licences enregistre l'appareil (2 par défaut) et renvoie la licence signée.
   Vérification en ligne dès que possible ; hors ligne, le logiciel fonctionne jusqu'à l'échéance ou jusqu'à « off » jours (7) sans vérification. */
function isActCode(v){return /^EXC[A-Z0-9]{12}$/.test(String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,''))}
function platformName(){try{if(w.Capacitor&&w.Capacitor.isNativePlatform&&w.Capacitor.isNativePlatform())return'android';if(/Electron/i.test(navigator.userAgent||''))return'windows'}catch(e){}return'web'}
function blk(){try{return JSON.parse(ls(KB)||'null')}catch(e){return null}}
async function post(body){if(!CFG.server)throw new Error('no-server');
  var r=await fetch(CFG.server,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),j=null;try{j=await r.json()}catch(e){}if(!j||typeof j!=='object')j={ok:false,raison:'reponse_illisible'};j.__http=r.status;
  if(j&&j.now){var t=Date.parse(j.now);if(t>0){srv=t;srvAt=Date.now();ls(KS,String(t))}}
  return j}
async function activateCode(code){
  if(!CFG.server)return{ok:false,msg:'Serveur de licences non configuré dans cette édition. Contactez '+CFG.contact+'.'};
  if(navigator.onLine===false)return{ok:false,msg:'Connexion internet requise pour activer votre code.'};
  var j;try{j=await post({action:'activate',code:String(code||'').trim(),device:devId(),label:String(navigator.platform||'').slice(0,40),platform:platformName(),version:CFG.version})}
  catch(e){return{ok:false,msg:'Impossible de joindre le serveur de licences. Vérifiez votre connexion.'}}
  if(!j||!j.ok){var hh=j&&j.__http;return{ok:false,msg:(j&&j.msg)||(hh===401||hh===403?'Le serveur de licences refuse la demande (HTTP '+hh+'). Prévenez '+CFG.contact+' : la fonction « licence » doit être déployée sans contrôle JWT.':hh===404?'Le serveur de licences est introuvable (HTTP 404). Prévenez '+CFG.contact+'.':hh>=500?'Le serveur de licences est en panne (HTTP '+hh+'). Réessayez dans quelques minutes.':'Activation refusée.')}}
  var a=await apply(j.jeton);if(!a.ok)return a;
  ls(KB,null);ls(KC,String(Date.now()));a.appareils=j.appareils;return a}
/* Vérification périodique : renouvelle la licence (nouvelle échéance, nouvelle date de vérification) ou la bloque si le serveur la refuse.
   Aucune réponse du serveur (hors ligne, panne) : rien ne change. */
/* V122f — diagnostic : la dernière vérification auprès du serveur est notée (nature seulement, aucun secret) et affichée sur l'écran « Logiciel verrouillé ». */
var KG='exb_lic_diag';
function dg(k,x){try{ls(KG,JSON.stringify(Object.assign({k:k,at:Date.now()},x||{})))}catch(e){}}
function dgText(){var g=null;try{g=JSON.parse(ls(KG)||'null')}catch(e){}if(!g)return'';var h=Number(g.http)||0,ra=String(g.raison||'').replace(/[^\w-]/g,'').slice(0,40),T={ok:'réussie',hors:'appareil hors ligne',reseau:'serveur de licences injoignable (réseau, pare-feu, CORS ou fonction non déployée)',jeton:'réponse du serveur non reconnue : la clé publique de ce logiciel ne correspond pas à celle du serveur de licences',raison:'refusée par le serveur ('+String(g.r||'?').replace(/[^\w-]/g,'')+')',http:'réponse inattendue du serveur'+(h?' (HTTP '+h+(h===401||h===403?' : la fonction « licence » doit être déployée sans contrôle JWT, option --no-verify-jwt':h===404?' : fonction « licence » introuvable':'')+')':'')+(ra?' ['+ra+']':'')};return'<br>Dernière vérification : '+(T[g.k]||'inconnue')}
async function refresh(force){
  try{var tok=ls(KT);if(!tok||!CFG.server)return null;var p=await verify(tok);if(!p||p.v!==2||!p.cid||!devOk(p))return null;
    if(navigator.onLine===false){dg('hors');return null}
    var lk=blk()||(w.EXBLIC&&w.EXBLIC.last&&w.EXBLIC.last.mode==='locked'),every=(lk?1:CFG.checkEveryMin)*60000;
    var dtc=Date.now()-(Number(ls(KC))||0);if(!force&&dtc>=0&&dtc<every)return null;/* V122f : dtc<0 = horloge de l'appareil reculée depuis la dernière vérification (date avancée par erreur puis corrigée) : on vérifie tout de suite, sinon le logiciel restait verrouillé sans jamais se resynchroniser */
    ls(KC,String(Date.now()));
    var j=await post({action:'check',cid:p.cid,device:devId(),version:CFG.version});
    if(j&&j.ok&&j.jeton){var q=await verify(j.jeton);if(q&&q.cid===p.cid&&devOk(q)){ls(KT,j.jeton);ls(KB,null);dg('ok');return{ok:true}}dg('jeton');return null}
    var m={suspendu:'suspended',revoque:'revoked',appareil_inconnu:'released',inconnu:'unknown'}[j&&j.raison];
    if(m){ls(KB,JSON.stringify({r:m,at:Date.now()}));dg('raison',{r:m});return{ok:false,raison:j.raison}}
    dg('http',{http:j&&j.__http,raison:j&&j.raison});
  }catch(e){dg('reseau')}
  return null}
w.EXBLIC={deviceId:function(){return devFmt(devId())},viaInvite:viaInvite,activateCode:activateCode,refresh:refresh,isActCode:isActCode,verify:verify,state:state,check:check,apply:apply,adminDialog:adminDialog,isAdmin:isAdmin,make:make,CFG:CFG,last:null,diagText:dgText};
/* Démarrage : activation par lien #lic=..., puis contrôle régulier */
(async function(){try{var m=/[#&]lic=([^&]+)/.exec(location.hash||'');if(m){var r=await apply(decodeURIComponent(m[1]));try{history.replaceState(null,'',location.pathname+location.search)}catch(e){}if(r.ok){try{sessionStorage.setItem('exb_lic_msg','✓ Abonnement activé jusqu’au '+fmt(r.payload.exp)+'.')}catch(e){}if(r.reload){location.reload();return}setTimeout(function(){exbAlert('✓ Abonnement activé jusqu’au '+fmt(r.payload.exp)+'.')},600)}}}catch(e){}
  try{var mm=sessionStorage.getItem('exb_lic_msg');if(mm){sessionStorage.removeItem('exb_lic_msg');setTimeout(function(){exbAlert(mm)},900)}}catch(e){}vetAdmin();check();setInterval(check,60000);document.addEventListener('visibilitychange',function(){if(!document.hidden)check()});w.addEventListener('online',check)})();
})(window);
