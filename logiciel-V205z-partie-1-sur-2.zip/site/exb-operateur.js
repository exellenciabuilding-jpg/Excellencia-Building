/* Excellencia Building V205k — PROFIL OPÉRATEUR : l'identité de la personne qui établit un document.
 * Chaque utilisateur (magasinier, comptable, conducteur, RH, direction…) enregistre une fois : nom, fonction, matricule, téléphone, e-mail,
 * lieu d'affectation, mention libre, SIGNATURE (dessinée ou importée) et SCEAU (automatique ou image).
 * Ce qui sort dans les documents :
 *   - PDF (EXBPdf) : ligne « Établi par … » en pied de page ; avec l'option « Utiliser ma signature et mon sceau », ils remplacent le visa du Directeur ;
 *   - Rapports (EXBRapport, ex. état du stock) : bloc « Établi par » avec signature et sceau ;
 *   - Pièces écrites : signature + sceau de l'opérateur à la place du visa du Directeur (même option).
 * Les certificats, reçus, devis, contrats et affiches gardent le visa du Directeur (EXBSign, inchangé).
 * Stockage : rattaché au COMPTE. Copie locale par compte (localStorage, marche hors connexion) + copie en ligne (table operateur_profils, RLS : chaque
 * compte ne voit que la sienne) ; la version la plus récente gagne, donc le profil suit le compte d'un appareil à l'autre. */
(function (w, d) {
  'use strict';
  var KEY = 'EXB_OPERATEUR_V1', LAST = 'EXB_OPERATEUR_LAST';
  function $(i) { return d.getElementById(i); }
  function s(v) { return String(v == null ? '' : v).trim(); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ls(k) { try { return w.localStorage.getItem(k); } catch (e) { return null; } }

  /* ---------- compte courant (clé de stockage) ---------- */
  function jwt() {
    try {
      var t = w.exbSb && w.exbSb.token && w.exbSb.token(); if (!t) return {};
      var p = String(t).split('.')[1].replace(/-/g, '+').replace(/_/g, '/'); p += '==='.slice((p.length + 3) % 4);
      return JSON.parse(decodeURIComponent(escape(w.atob(p)))) || {};
    } catch (e) { return {}; }
  }
  function jwtEmail() { return s(jwt().email).toLowerCase(); }
  function uid() { return s(jwt().sub); }
  function acct() {
    var a = ''; try { a = s(w.EXB_ACCT && w.EXB_ACCT.id).toLowerCase(); } catch (e) {}
    if (!a) a = jwtEmail();
    if (a) { try { w.localStorage.setItem(LAST, a); } catch (e) {} return a; }
    return s(ls(LAST)) || 'local';
  }
  function all() { try { var o = JSON.parse(ls(KEY) || '{}'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  function get() { var p = all()[acct()]; return p && typeof p === 'object' ? p : {}; }
  function put(p) { var o = all(); o[acct()] = p; try { w.localStorage.setItem(KEY, JSON.stringify(o)); return true; } catch (e) { return false; } }
  function clear() {
    var o = all(), ok = true; delete o[acct()]; try { w.localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) { ok = false; }
    if (online()) { try { Promise.resolve(w.exbSb.api('/rest/v1/operateur_profils?user_id=eq.' + encodeURIComponent(uid()), { method: 'DELETE', headers: { Prefer: 'return=minimal' } })).catch(function () {}); } catch (e) {} }
    return ok;
  }

  /* ---------- copie en ligne rattachée au compte ---------- */
  function online() { return !!(uid() && w.exbSb && w.exbSb.api); }
  var lastSync = 'local'; /* 'ok' = copie du compte à jour · 'local' = pas connecté · 'hors' = envoi échoué, réessai plus tard */
  function pushP(p) {
    if (!online()) { lastSync = 'local'; return Promise.resolve(lastSync); }
    return Promise.resolve(w.exbSb.api('/rest/v1/operateur_profils?on_conflict=user_id&select=user_id', { method: 'POST', headers: { 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=representation' }, body: JSON.stringify({ user_id: uid(), profil: p }) }))
      .then(function () { lastSync = 'ok'; return lastSync; }, function () { lastSync = 'hors'; return lastSync; });
  }
  function pull() {
    if (!online()) { lastSync = 'local'; return Promise.resolve(lastSync); }
    return Promise.resolve(w.exbSb.api('/rest/v1/operateur_profils?select=profil&limit=1')).then(function (r) {
      var S = r && r[0] && r[0].profil, L = get(), sm = s(S && S.maj), lm = s(L.maj);
      if (S && s(S.nom) && (!lm || sm > lm)) { put(S); lastSync = 'ok'; return lastSync; } /* le compte a une version plus récente */
      if (lm && (!sm || lm > sm)) return pushP(L); /* la version de l'appareil est plus récente */
      lastSync = 'ok'; return lastSync;
    }).catch(function () { lastSync = 'hors'; return lastSync; });
  }

  function accountLabel() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return i && i.on ? s(i.label || i.fonction) : ''; } catch (e) { return ''; } }
  function fonctionOf(p) { p = p || get(); return s(p.fonction) || accountLabel(); }

  /* ---------- textes qui sortent dans les documents ---------- */
  function line(p) {
    p = p || get(); if (!s(p.nom) || p.etab === false) return '';
    return ['Établi par : ' + s(p.nom), fonctionOf(p), s(p.matricule) ? 'Mat. ' + s(p.matricule) : '', s(p.tel), s(p.lieu)].filter(Boolean).join(' — ');
  }
  function who() { var p = get(); return s(p.nom) ? s(p.nom) + (fonctionOf(p) ? ' (' + fonctionOf(p) + ')' : '') : ''; }
  function sigLabel() { var p = get(), f = fonctionOf(p); return (f || 'Le signataire').slice(0, 34); }
  /* V205r : chacun son compte. Un compte qui n'est PAS administrateur (comptable, ingénieur, magasinier, conducteur…) signe lui-même ses documents avec SA signature et SON sceau.
   * Le visa du Directeur (Paramètres › Identité de l'entreprise, ou visa publié) reste réservé à l'administrateur / à la direction et aux appareils sans compte. */
  function signeSeul() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return !!(i && i.on && i.role !== 'admin'); } catch (e) { return false; } }
  function remplace() { var p = get(); return !!(p.visa && (p.remplace || signeSeul())); }
  function aVisa() { return !!get().visa; }
  function visaSignataire(fmt) { return signeSeul() ? visa(fmt) : Promise.resolve(''); }
  function blockHtml(p) {
    p = p || get(); if (!s(p.nom) || p.etab === false) return '';
    var t = [], f = fonctionOf(p);
    t.push('<b>Établi par</b><br><span style="font-size:13px"><b>' + esc(p.nom) + '</b></span>');
    if (f || s(p.matricule)) t.push(esc([f, s(p.matricule) ? 'Mat. ' + s(p.matricule) : ''].filter(Boolean).join(' · ')));
    if (s(p.tel) || s(p.email)) t.push(esc([s(p.tel), s(p.email)].filter(Boolean).join(' · ')));
    if (s(p.lieu)) t.push(esc(p.lieu));
    if (s(p.mention)) t.push(esc(p.mention));
    var im = (p.sig ? '<img src="' + p.sig + '" alt="" style="max-height:62px;max-width:170px;vertical-align:bottom"/>' : '') +
      (p.stampPng ? '<img src="' + p.stampPng + '" alt="" style="max-height:80px;max-width:140px;vertical-align:bottom;margin-left:6px"/>' : '');
    return '<div data-exb-operateur="1" style="margin-top:14px;display:flex;gap:18px;align-items:flex-end;justify-content:space-between;border-top:1px solid #ddd;padding-top:8px;font-size:11px;color:#12305e;page-break-inside:avoid"><div style="flex:1">' +
      t.join('<br>') + '</div>' + (im ? '<div style="text-align:center">' + im + '<div style="border-top:1px solid #999;font-size:10px;color:#555;margin-top:2px;padding-top:2px">Signature et sceau</div></div>' : '') + '</div>';
  }

  /* ---------- images : sceau automatique, visa composé ---------- */
  function loadImg(src) { return new Promise(function (ok) { if (!src) return ok(null); var im = new Image(); im.onload = function () { ok(im); }; im.onerror = function () { ok(null); }; im.src = src; }); }
  function rr(x, X, Y, W, H, r) { x.beginPath(); x.moveTo(X + r, Y); x.lineTo(X + W - r, Y); x.quadraticCurveTo(X + W, Y, X + W, Y + r); x.lineTo(X + W, Y + H - r); x.quadraticCurveTo(X + W, Y + H, X + W - r, Y + H); x.lineTo(X + r, Y + H); x.quadraticCurveTo(X, Y + H, X, Y + H - r); x.lineTo(X, Y + r); x.quadraticCurveTo(X, Y, X + r, Y); x.closePath(); }
  function stampAuto(p) {
    var I = {}; try { I = (w.EXBId && w.EXBId.get()) || {}; } catch (e) {}
    var c = d.createElement('canvas'); c.width = 600; c.height = 340; var x = c.getContext('2d'), col = '#173a8a';
    x.strokeStyle = col; x.fillStyle = col; x.lineWidth = 8; rr(x, 8, 8, 584, 324, 28); x.stroke(); x.lineWidth = 2.5; rr(x, 24, 24, 552, 292, 20); x.stroke();
    x.textAlign = 'center'; x.textBaseline = 'middle';
    var L = [[s(I.name) || 'Entreprise', 46, '800'], [fonctionOf(p).toUpperCase(), 38, '700'], [s(p.nom), 34, '600'], [s(p.lieu), 28, '600'], [s(p.matricule) ? 'Mat. ' + s(p.matricule) : '', 26, '600']].filter(function (l) { return l[0]; });
    var step = 252 / Math.max(1, L.length);
    L.forEach(function (l, i) { var sz = l[1]; do { x.font = l[2] + ' ' + sz + 'px Arial,sans-serif'; sz -= 2; } while (x.measureText(l[0]).width > 520 && sz > 12); x.fillText(l[0], 300, 44 + step * (i + .5)); });
    return c.toDataURL('image/png');
  }
  function trim(c) {
    var x = c.getContext('2d'), W = c.width, H = c.height, q; try { q = x.getImageData(0, 0, W, H).data; } catch (e) { return c; }
    var x0 = W, y0 = H, x1 = -1, y1 = -1;
    for (var y = 0; y < H; y++) for (var u = 0; u < W; u++) if (q[(y * W + u) * 4 + 3] > 12) { if (u < x0) x0 = u; if (u > x1) x1 = u; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return c; var o = d.createElement('canvas'); o.width = x1 - x0 + 1; o.height = y1 - y0 + 1; o.getContext('2d').drawImage(c, x0, y0, o.width, o.height, 0, 0, o.width, o.height); return o;
  }
  function compose(sig, stamp) {
    return Promise.all([loadImg(sig), loadImg(stamp)]).then(function (r) {
      var sg = r[0], st = r[1]; if (!sg && !st) return '';
      var W = 520, H = 260, c = d.createElement('canvas'); c.width = W; c.height = H; var x = c.getContext('2d');
      if (sg) { var k = Math.min((W * .62) / sg.naturalWidth, (H * .78) / sg.naturalHeight), sw = sg.naturalWidth * k, sh = sg.naturalHeight * k; x.drawImage(sg, st ? 10 : (W - sw) / 2, H - sh - 20, sw, sh); }
      if (st) { var kk = Math.min(230 / st.naturalWidth, 170 / st.naturalHeight), tw = st.naturalWidth * kk, th = st.naturalHeight * kk; x.save(); x.globalAlpha = .88; x.translate(W - tw / 2 - 10, H / 2 + 8); x.rotate(-.1); x.drawImage(st, -tw / 2, -th / 2, tw, th); x.restore(); }
      return trim(c).toDataURL('image/png');
    });
  }
  function visa(fmt) {
    var p = get(); if (!p.visa) return Promise.resolve('');
    if (fmt !== 'jpg') return Promise.resolve(p.visa);
    return loadImg(p.visa).then(function (im) { if (!im) return ''; var f = d.createElement('canvas'); f.width = im.naturalWidth; f.height = im.naturalHeight; var x = f.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, f.width, f.height); x.drawImage(im, 0, 0); return f.toDataURL('image/jpeg', .92); });
  }

  /* ---------- enregistrement ---------- */
  function save(p) {
    p = p || {}; var o = {
      nom: s(p.nom), fonction: s(p.fonction), matricule: s(p.matricule), tel: s(p.tel), email: s(p.email), lieu: s(p.lieu), mention: s(p.mention),
      sig: p.sig || '', stamp: p.stamp === 'auto' || p.stamp === 'img' ? p.stamp : 'none', stampImg: p.stampImg || '',
      etab: p.etab !== false, remplace: !!p.remplace, maj: new Date().toISOString()
    };
    var st = o.stamp === 'auto' ? stampAuto(o) : (o.stamp === 'img' ? o.stampImg : '');
    o.stampPng = st || '';
    return compose(o.sig, o.stampPng).then(function (v) { o.visa = v; var ok = put(o); return ok ? pushP(o).then(function () { return true; }) : false; });
  }

  /* ---------- écran « Mon profil opérateur » ---------- */
  var st = null;
  function fv(id) { var e = $(id); return e ? e.value : ''; }
  function cur() {
    return { nom: fv('op_nom'), fonction: fv('op_fonction'), matricule: fv('op_mat'), tel: fv('op_tel'), email: fv('op_mail'), lieu: fv('op_lieu'), mention: fv('op_mention'),
      sig: st.sig, stamp: fv('op_stamp'), stampImg: st.stampImg, etab: !!($('op_etab') || {}).checked, remplace: !!($('op_rempl') || {}).checked };
  }
  function previewNow() {
    var box = $('op_prev'); if (!box || !st) return; var p = cur();
    p.stampPng = p.stamp === 'auto' ? stampAuto(p) : (p.stamp === 'img' ? p.stampImg : '');
    var h = blockHtml(p);
    box.innerHTML = h || '<p style="margin:0;color:#6b7a99">Renseignez au moins votre nom pour voir l’aperçu du bloc « Établi par ».</p>';
    var sp = $('op_sigsaved'); if (sp) sp.innerHTML = st.sig ? '<img src="' + st.sig + '" alt="" style="max-height:70px;max-width:100%;border:1px dashed #b8c4dc;border-radius:6px;background:#fff;padding:4px"/>' : '<span style="color:#6b7a99">Aucune signature enregistrée.</span>';
    var ip = $('op_stampimgwrap'); if (ip) ip.style.display = p.stamp === 'img' ? '' : 'none';
    var pi = $('op_stampimgprev'); if (pi) pi.innerHTML = st.stampImg ? '<img src="' + st.stampImg + '" alt="" style="max-height:80px;max-width:100%"/>' : '';
  }
  function open() {
    var done = false, go = function () { if (done) return; done = true; render(); };
    pull().then(go); setTimeout(go, 2500);
  }
  function render() {
    var old = $('op_ov'); if (old) old.remove();
    var p = get(), fl = accountLabel(), email = acct();
    st = { sig: p.sig || '', stampImg: p.stampImg || '', pad: null };
    var inp = 'style="width:100%;box-sizing:border-box;padding:9px;border:1px solid #c6d0e4;border-radius:8px;font:14px Arial,sans-serif;background:#fff;color:#12254a"';
    var lab = function (t, id, v, ph, type) { return '<label style="display:block;font:600 12px Arial;color:#43557a;margin-top:8px">' + t + '<input id="' + id + '" type="' + (type || 'text') + '" value="' + esc(v) + '" placeholder="' + esc(ph || '') + '" ' + inp + '/></label>'; };
    var o = d.createElement('div'); o.id = 'op_ov';
    o.style.cssText = 'position:fixed;inset:0;z-index:99990;background:rgba(15,23,42,.6);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:10px';
    o.innerHTML = '<div role="dialog" aria-label="Mon profil opérateur" style="background:#fff;color:#12254a;width:100%;max-width:640px;border-radius:14px;padding:16px;box-sizing:border-box;font:14px Arial,sans-serif">' +
      '<div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0;font-size:18px">🪪 Mon profil opérateur</h3><button type="button" id="op_x" style="border:0;background:#eef1f6;border-radius:8px;padding:6px 10px;cursor:pointer">✕</button></div>' +
      '<p style="margin:6px 0 0;color:#6b7a99;font-size:12px">Ces informations sortent dans vos PDF et rapports (« Établi par »). Elles sont rattachées à votre compte <b>' + esc(email) + '</b> : ' + (lastSync === 'ok' ? '✅ synchronisées, vous les retrouvez sur tous vos appareils.' : (lastSync === 'hors' ? '⚠️ serveur injoignable : enregistrées sur cet appareil, envoi au compte au prochain essai.' : 'enregistrées sur cet appareil ; connectez-vous à votre compte en ligne pour les retrouver partout.')) + ' Les certificats, reçus, devis et contrats gardent le visa du Directeur.</p>' +
      lab('Nom complet *', 'op_nom', p.nom, 'Ex. Ndaye Mbuyi Alice') + lab('Fonction (si différente de votre compte)', 'op_fonction', p.fonction, fl || 'Ex. Magasinier') +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 10px">' + '<div>' + lab('Matricule / n° employé', 'op_mat', p.matricule, '') + '</div><div>' + lab('Téléphone', 'op_tel', p.tel, '+243 …', 'tel') + '</div>' +
      '<div>' + lab('E-mail', 'op_mail', p.email, '', 'email') + '</div><div>' + lab('Lieu d’affectation (dépôt, chantier, service)', 'op_lieu', p.lieu, 'Ex. Dépôt central') + '</div></div>' +
      lab('Autre information à imprimer (facultatif)', 'op_mention', p.mention, 'Ex. Habilitation, n° d’agrément…') +
      '<div style="margin-top:12px;font:700 13px Arial">✍️ Signature</div><div id="op_sigsaved" style="margin:6px 0"></div>' +
      '<canvas id="op_pad" style="width:100%;height:130px;border:1px dashed #8fa3c8;border-radius:10px;background:#fbfcff;touch-action:none;display:block"></canvas>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px"><button type="button" id="op_padclr" class="muted">Effacer le dessin</button><button type="button" id="op_sigimp" class="muted">📁 Importer une image</button><button type="button" id="op_sigdel" class="muted">🗑️ Supprimer ma signature</button><input id="op_sigfile" type="file" accept="image/*" style="display:none"/></div>' +
      '<p style="margin:4px 0 0;color:#6b7a99;font-size:12px">Dessinez au doigt ou à la souris, puis « Enregistrer ». Une image importée voit son fond blanc retiré.</p>' +
      '<div style="margin-top:12px;font:700 13px Arial">🔖 Sceau / cachet</div>' +
      '<select id="op_stamp" ' + inp + '><option value="none">Aucun sceau</option><option value="auto">Sceau automatique (entreprise, fonction, nom)</option><option value="img">Mon image de sceau</option></select>' +
      '<div id="op_stampimgwrap" style="display:none;margin-top:6px"><button type="button" id="op_stimp" class="muted">📁 Importer l’image du sceau</button><input id="op_stfile" type="file" accept="image/*" style="display:none"/><div id="op_stampimgprev" style="margin-top:6px"></div></div>' +
      '<label style="display:flex;gap:8px;align-items:flex-start;margin-top:12px"><input type="checkbox" id="op_etab"' + (p.etab === false ? '' : ' checked') + '/> <span>Imprimer « Établi par » avec mes informations sur mes PDF et rapports</span></label>' +
      '<label style="display:flex;gap:8px;align-items:flex-start;margin-top:8px"><input type="checkbox" id="op_rempl"' + (p.remplace ? ' checked' : '') + '/> <span>Utiliser ma signature et mon sceau <b>à la place du visa du Directeur</b> sur mes PDF et pièces écrites</span></label>' +
      '<div style="margin-top:12px;font:700 13px Arial">👁 Aperçu</div><div id="op_prev" style="border:1px solid #e3e9f4;border-radius:10px;padding:10px;background:#fff;margin-top:6px"></div>' +
      '<div id="op_msg" style="min-height:18px;margin-top:8px;font-size:13px"></div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button type="button" id="op_save" style="background:#1f6feb;color:#fff;border:0;border-radius:9px;padding:11px 18px;font:700 14px Arial;cursor:pointer">💾 Enregistrer</button><button type="button" id="op_cancel" class="muted">Annuler</button><button type="button" id="op_reset" class="muted" style="margin-left:auto;color:#b42318">Effacer mon profil</button></div></div>';
    d.body.appendChild(o);
    $('op_stamp').value = p.stamp === 'auto' || p.stamp === 'img' ? p.stamp : 'none';
    var say = function (m, ok) { var e = $('op_msg'); if (e) e.innerHTML = '<span style="color:' + (ok ? '#18733b' : '#b42318') + '">' + esc(m) + '</span>'; };
    var close = function () { var e = $('op_ov'); if (e) e.remove(); st = null; };
    $('op_x').onclick = close; $('op_cancel').onclick = close;
    ['op_nom', 'op_fonction', 'op_mat', 'op_tel', 'op_mail', 'op_lieu', 'op_mention', 'op_stamp', 'op_etab', 'op_rempl'].forEach(function (id) { var e = $(id); e.addEventListener('input', previewNow); e.addEventListener('change', previewNow); });
    var S = w.EXBSign;
    if (S && S.pad) { st.pad = S.pad($('op_pad'), {}); } else { $('op_pad').style.display = 'none'; }
    $('op_padclr').onclick = function () { if (st.pad) st.pad.clear(); };
    $('op_sigdel').onclick = function () { st.sig = ''; if (st.pad) st.pad.clear(); previewNow(); };
    $('op_sigimp').onclick = function () { $('op_sigfile').click(); };
    $('op_stimp').onclick = function () { $('op_stfile').click(); };
    function importImg(inputId, cb) { var f = $(inputId).files && $(inputId).files[0]; if (!f) return; if (!(S && S.cleanImage)) { say('Import d’image indisponible.'); return; } S.cleanImage(f, 700).then(function (u) { cb(u); previewNow(); }, function () { say('Image illisible.'); }); $(inputId).value = ''; }
    $('op_sigfile').onchange = function () { importImg('op_sigfile', function (u) { st.sig = u; if (st.pad) st.pad.clear(); }); };
    $('op_stfile').onchange = function () { importImg('op_stfile', function (u) { st.stampImg = u; }); };
    $('op_reset').onclick = function () { if (!w.confirm('Effacer votre profil opérateur (identité, signature, sceau) sur cet appareil ?')) return; clear(); close(); try { w.notify && w.notify('Profil opérateur effacé.', 'info'); } catch (e) {} };
    $('op_save').onclick = function () {
      var v = cur(); if (!s(v.nom)) { say('Le nom complet est obligatoire.'); return; }
      if (st.pad && !st.pad.isEmpty()) v.sig = st.pad.png() || v.sig;
      if (v.stamp === 'img' && !v.stampImg) { say('Importez l’image du sceau, ou choisissez « Sceau automatique ».'); return; }
      if (v.remplace && !v.sig && v.stamp === 'none') { say('Pour remplacer le visa du Directeur, ajoutez une signature ou un sceau.'); return; }
      $('op_save').disabled = true;
      save(v).then(function (ok) { if (!ok) { $('op_save').disabled = false; say('Enregistrement impossible : l’espace de stockage de l’appareil est plein.'); return; } try { w.notify && w.notify(lastSync === 'ok' ? 'Profil enregistré sur votre compte.' : 'Profil enregistré sur cet appareil (envoi au compte dès la connexion).', 'ok'); } catch (e) {} close(); },
        function () { $('op_save').disabled = false; say('Enregistrement impossible.'); });
    };
    previewNow();
  }

  w.EXBOperateur = { sync: pull, syncState: function () { return lastSync; }, get: get, save: save, clear: clear, open: open, line: line, who: who, sigLabel: sigLabel, remplace: remplace, signeSeul: signeSeul, aVisa: aVisa, visaSignataire: visaSignataire, visa: visa, blockHtml: blockHtml, account: acct, _t: { stampAuto: stampAuto, compose: compose } };
  setTimeout(function () { pull(); }, 5000); setTimeout(function () { pull(); }, 30000); w.addEventListener('online', function () { pull(); });
})(window, document);
