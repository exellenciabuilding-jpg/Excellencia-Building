# V205v — Un code d'activation PERSONNEL par membre (comptable 1, comptable 2, ingénieur, formateur…)

**SQL à exécuter UNE FOIS** (Supabase › SQL Editor) : `supabase/migration-v205v-codes-personnels.sql` (réexécutable sans danger).
Prérequis déjà en place : schéma, v99v, v99w (équipe), v99zzj (activation par invitation).

## Avant
Toute l'entreprise partageait le même code d'invitation. On ne savait pas qui l'avait utilisé et on ne pouvait pas couper l'accès d'une seule personne.

## Maintenant
- Panneau **👥 Équipe** : chaque invité reçoit **SON** code (8 caractères), affiché sous son nom avec l'état « pas encore utilisé / utilisé ✓ ».
  Le message à envoyer (copier, WhatsApp) contient son lien d'espace et son code personnel. Deux comptables ou plus, plusieurs ingénieurs, etc. : un code chacun.
- Le code **déverrouille le logiciel** sur son appareil (écran « code d'activation ») puis **sert à rejoindre l'entreprise**.
- Il est **lié à l'adresse e-mail invitée** : transmis à quelqu'un d'autre, il est refusé (« ce code est personnel »).
- **🔄 Nouveau code** : code perdu ou transmis par erreur ; l'ancien ne fonctionne plus.
- **Membre retiré** = son code est révoqué automatiquement. **Invitation annulée** = le code n'ouvre plus rien.
- Un membre déjà présent a lui aussi son code (bouton « ✉️ Lien », créé au premier usage).
- Le **code d'entreprise** continue de fonctionner pour les appareils déjà activés ; la limite d'utilisateurs de la licence reste appliquée.
- Sans la migration, le panneau retombe proprement sur l'ancien code d'entreprise (rien ne casse).

## Tests
- `bash tools/test-sql-codes-personnels.sh` (PostgreSQL 16 local, Supabase simulé) : 16 OK, migration réexécutable.
- `python3 tools/e2e-codes-personnels.py` : 10 OK (panneau Équipe).
- `node tools/check.js`.
