/* Excellencia Building V166 — Finances & comptabilité (module 15) : TVA récupérable, compte de résultat, bilan simplifié, verrou des périodes clôturées.
 * S'ajoute à exb-compta.js (V165) par ses points d'extension. Aucune facture, caisse ni paiement existant n'est modifié.
 *
 *  - TVA récupérable : registre de justificatifs de TVA déductible (exb_tva_achats). Chaque justificatif RECLASSE la TVA de l'achat de la charge (6xx)
 *    vers le compte 4452 « TVA récupérable sur achats » : débit 4452 / crédit charge. Le montant TTC de l'achat doit déjà être enregistré comme charge
 *    (facture fournisseur ou dépense de caisse) : les totaux de trésorerie et de dettes ne changent pas. État de TVA = collectée (4431) − récupérable (4452).
 *  - Compte de résultat : produits (classe 7) − charges (classe 6) sur une période, par devise, depuis le journal calculé.
 *  - Bilan simplifié : soldes des comptes de bilan cumulés jusqu'à une date + résultat cumulé ; contrôle actif = passif.
 *    SIMPLIFIÉ : ni capital, ni immobilisations, ni à-nouveaux d'ouverture, ni amortissements, ni stocks : ce n'est PAS un bilan certifié.
 *  - Verrou (option, désactivé par défaut) : refuse l'enregistrement d'une écriture qui ajoute, modifie ou supprime un mouvement d'un mois clôturé
 *    (factures, paiements, avoirs, factures fournisseurs, caisse, justificatifs de TVA). Principe : enveloppe de save() ; ne couvre pas un écran qui écrit
 *    sans passer par save(). Seuls les champs qui changent une écriture comptable comptent (changer une note ou un projet n'est pas refusé).
 * Hypothèses à valider avec votre comptable : TVA exigible à la date de facture (pas à l'encaissement) ; plan comptable indicatif SYSCOHADA ; taux saisi par justificatif.
 * Retrait : supprimer la balise <script src="exb-compta-etats.js"> (le registre exb_tva_achats reste ; les écritures de TVA disparaissent du journal). */
(function (w) {
  'use strict';
  var X = w.EXBCOMPTA && w.EXBCOMPTA._x; if (!X || w.EXBCOMPTA_ETATS) return;
  var d = w.document, TK = 'exb_tva_achats', CFG = 'exb_compta_cfg', r2 = X.r2, esc = X.esc, nf = X.nf, pn = X.pn;
  var CH = ['601', '604', '613', '616', '618', '623', '626', '658'], DATE = /^\d{4}-\d{2}-\d{2}$/;
  X.ACC['4452'] = 'TVA récupérable sur achats';
  function accName(a) { return X.ACC[a] || ('Compte ' + a); }
  function closedSet() { var o = {}; (X.LD(X.K.cl, []) || []).forEach(function (r) { if (r && r.ym && !r.reopened) o[r.ym] = 1; }); return o; }

  /* ---------------- TVA récupérable ---------------- */
  function tvaList() { return (X.LD(TK, []) || []).filter(function (t) { return t && t.id; }); }
  function tvaValidate(o, closed) {
    o = o || {}; var date = String(o.date || '').slice(0, 10), ht = r2(pn(o.ht)), rate = pn(o.rate);
    if (!DATE.test(date)) return { error: 'Date invalide (AAAA-MM-JJ).' };
    if (closed && closed[date.slice(0, 7)]) return { error: 'Le mois ' + date.slice(0, 7) + ' est clôturé : rouvrez-le (avec motif) avant d’y enregistrer.' };
    if (!String(o.supplier || '').trim()) return { error: 'Le fournisseur est obligatoire.' };
    if (!String(o.ref || '').trim()) return { error: 'Le numéro de la facture ou du justificatif est obligatoire : la TVA n’est récupérable que sur justificatif.' };
    if (!(ht > 0)) return { error: 'Montant hors taxe invalide.' };
    if (!(rate > 0 && rate <= 100)) return { error: 'Taux de TVA invalide (entre 0 et 100 %).' };
    if (CH.indexOf(String(o.acc)) < 0) return { error: 'Choisissez le compte de charge concerné.' };
    var tva = r2(ht * rate / 100); if (!(tva > 0)) return { error: 'TVA nulle : rien à enregistrer.' };
    return { ok: true, rec: { date: date, supplier: String(o.supplier).trim().slice(0, 120), ref: String(o.ref).trim().slice(0, 80), ht: ht, rate: rate, tva: tva, ttc: r2(ht + tva), acc: String(o.acc), currency: String(o.currency || 'USD').toUpperCase() === 'CDF' ? 'FC' : String(o.currency || 'USD').toUpperCase() } };
  }
  function addTva(o) {
    if (!X.can('factures', 'ecrire')) return { error: 'Droits insuffisants (factures).' };
    var v = tvaValidate(o, closedSet()); if (v.error) return v;
    var r = Object.assign({ id: X.uid('TVA'), status: 'actif', by: X.who(), at: new Date().toISOString() }, v.rec), a = tvaList(); a.push(r);
    if (!X.SV(TK, a)) return { error: 'Enregistrement impossible (stockage ou période clôturée).' };
    X.audit('compta.tva.ajout', r.ref, { tva: r.tva, devise: r.currency, mois: r.date.slice(0, 7) }); return { rec: r };
  }
  function cancelTva(id, why) {
    if (!X.can('factures', 'ecrire')) return { error: 'Droits insuffisants (factures).' };
    if (String(why || '').trim().length < 3) return { error: 'Le motif d’annulation est obligatoire.' };
    var a = tvaList(), r = a.filter(function (x) { return x.id === id; })[0]; if (!r) return { error: 'Justificatif introuvable.' }; if (r.status === 'annulé') return { error: 'Déjà annulé.' };
    if (closedSet()[r.date.slice(0, 7)]) return { error: 'Le mois ' + r.date.slice(0, 7) + ' est clôturé : rouvrez-le d’abord.' };
    r.status = 'annulé'; r.cancel_reason = String(why).trim(); r.cancel_by = X.who(); r.cancel_at = new Date().toISOString();
    if (!X.SV(TK, a)) return { error: 'Enregistrement impossible.' }; X.audit('compta.tva.annulation', r.ref, { motif: r.cancel_reason }); return { ok: true };
  }
  /* écritures : TVA reclassée de la charge vers 4452 (aucune écriture s'il n'y a pas de justificatif) */
  X.XT.entryFns.push(function (add) {
    tvaList().forEach(function (t) { if (t.status === 'annulé' || !(t.tva > 0) || !DATE.test(t.date || '')) return; add(t.date, 'AC', t.ref, 'TVA récupérable — ' + t.supplier, t.currency || 'USD', [['4452', t.tva, 0], [t.acc, 0, t.tva]]); });
  });
  function tvaState(L) {
    var col = 0, rec = 0; L.forEach(function (e) { if (e.acc === '4431') col = r2(col + e.c - e.d); else if (e.acc === '4452') rec = r2(rec + e.d - e.c); });
    var s = r2(col - rec); return { collectee: col, recuperable: rec, solde: s, etat: Math.abs(s) < 0.005 ? 'nul' : s > 0 ? 'à reverser' : 'crédit de TVA' };
  }

  /* ---------------- états financiers ---------------- */
  function sums(L) { var m = {}; L.forEach(function (e) { var a = m[e.acc] || (m[e.acc] = { acc: e.acc, d: 0, c: 0 }); a.d = r2(a.d + e.d); a.c = r2(a.c + e.c); }); return m; }
  function resultat(L) {
    var m = sums(L), P = [], C = [], tp = 0, tc = 0;
    Object.keys(m).sort().forEach(function (k) {
      if (k.charAt(0) === '7') { var v = r2(m[k].c - m[k].d); P.push({ acc: k, nom: accName(k), amount: v }); tp = r2(tp + v); }
      else if (k.charAt(0) === '6') { var u = r2(m[k].d - m[k].c); C.push({ acc: k, nom: accName(k), amount: u }); tc = r2(tc + u); }
    });
    return { produits: P, charges: C, totalProduits: tp, totalCharges: tc, resultat: r2(tp - tc) };
  }
  var NAT = { '411': 'A', '4452': 'A', '571': 'A', '521': 'A', '401': 'P', '4431': 'P' };
  function bilan(L) {
    var m = sums(L), A = [], Pa = [], ta = 0, tp = 0;
    Object.keys(m).sort().forEach(function (k) {
      var c0 = k.charAt(0); if (c0 === '6' || c0 === '7') return; var net = r2(m[k].d - m[k].c);
      if (net > 0.004) { A.push({ acc: k, nom: accName(k), amount: net, inverse: NAT[k] === 'P' }); ta = r2(ta + net); }
      else if (net < -0.004) { Pa.push({ acc: k, nom: accName(k), amount: -net, inverse: NAT[k] === 'A' }); tp = r2(tp - net); }
    });
    var res = resultat(L).resultat;
    if (res > 0.004) { Pa.push({ acc: 'RES', nom: 'Résultat cumulé (bénéfice)', amount: res }); tp = r2(tp + res); }
    else if (res < -0.004) { A.push({ acc: 'RES', nom: 'Résultat cumulé (perte)', amount: -res }); ta = r2(ta - res); }
    return { actif: A, passif: Pa, totalActif: ta, totalPassif: tp, equilibre: Math.abs(ta - tp) < 0.01 };
  }

  /* ---------------- verrou des périodes clôturées ---------------- */
  var WATCH = { exb_invoices: 'inv', exb_cash: 'cash', exb_v92_supplier_invoices: 'sup', exb_credit_notes: 'cn', exb_tva_achats: 'tva' };
  function dt(x) { var s = String(x || '').slice(0, 10); return DATE.test(s) ? s : ''; }
  function mainDate(kind, r) { return kind === 'sup' ? dt(r.date || r.invoice_date || r.created_at) : kind === 'cash' && (r.invoice_id || r.pay_id) ? '' : dt(r.date); }
  /* signature = uniquement ce qui change une écriture comptable */
  function sig(kind, r) {
    if (kind === 'inv') return JSON.stringify([r.date, r.no, r.currency, r.tva, r.annule, /annul/i.test(r.status || ''), (r.lines || []).map(function (l) { return [+l.q || 0, +l.pu || 0]; })]);
    if (kind === 'cash') return JSON.stringify([r.date, r.type, r.amount, r.currency, r.method, r.label, r.cat, r.ref, r.invoice_id, r.pay_id]);
    if (kind === 'sup') return JSON.stringify([r.date, r.invoice_date, r.created_at, r.amount, r.total, r.ttc, r.currency, r.no, r.number, r.ref, r.supplier, r.supplier_name, r.fournisseur]);
    if (kind === 'cn') return JSON.stringify([r.date, r.no, r.ttc, r.ht, r.tva_amount, r.status, r.currency]);
    return JSON.stringify([r.date, r.ref, r.ht, r.tva, r.acc, r.status, r.currency]);
  }
  function paySigs(r) { return (r.payments || []).map(function (p) { return { s: JSON.stringify([p.date || r.date, p.amount, p.method]), m: dt(p.date || r.date) }; }); }
  function touchedMonths(kind, oldArr, newArr) {
    var out = {}, O = {}, N = {};
    function key(r, i) { return r && r.id != null ? 'id:' + r.id : 'j:' + JSON.stringify(r); }
    (oldArr || []).forEach(function (r, i) { if (r && typeof r === 'object') O[key(r, i)] = r; });
    (newArr || []).forEach(function (r, i) { if (r && typeof r === 'object') N[key(r, i)] = r; });
    function mark(x) { if (x) out[x.slice(0, 7)] = 1; }
    function allDates(r) { mark(mainDate(kind, r)); if (kind === 'inv') paySigs(r).forEach(function (p) { mark(p.m); }); }
    Object.keys(O).forEach(function (k) { if (!N[k]) allDates(O[k]); });
    Object.keys(N).forEach(function (k) {
      var n = N[k], o = O[k]; if (!o) return allDates(n);
      if (sig(kind, o) !== sig(kind, n)) { mark(mainDate(kind, o)); mark(mainDate(kind, n)); }
      if (kind === 'inv') {
        var po = paySigs(o), pn_ = paySigs(n), so = po.map(function (p) { return p.s; }), sn = pn_.map(function (p) { return p.s; });
        po.forEach(function (p) { var i = sn.indexOf(p.s); if (i < 0) mark(p.m); else sn.splice(i, 1); });
        pn_.forEach(function (p) { var i = so.indexOf(p.s); if (i < 0) mark(p.m); else so.splice(i, 1); });
      }
    });
    return Object.keys(out);
  }
  function guardCheck(key, oldArr, newArr, closed) {
    var kind = WATCH[key]; if (!kind || !closed) return { blocked: false, months: [] };
    var m = touchedMonths(kind, oldArr, newArr).filter(function (x) { return closed[x]; }); return { blocked: m.length > 0, months: m.sort() };
  }
  function guardOn() { var c = X.LD(CFG, {}); return !!(c && c.guard); }
  function setGuard(on) { var c = X.LD(CFG, {}) || {}; c.guard = !!on; c.by = X.who(); c.at = new Date().toISOString(); X.SV(CFG, c); X.audit('compta.verrou.' + (on ? 'active' : 'desactive'), 'verrou', ''); }
  function install() {
    if (w.__exbCptGuard || typeof w.save !== 'function') return; var orig = w.save; w.__exbCptGuard = 1;
    w.save = function (k, v) {
      try {
        if (WATCH[k] && Array.isArray(v) && guardOn()) {
          var cs = closedSet(); if (Object.keys(cs).length) {
            var r = guardCheck(k, X.LD(k, []), v, cs);
            if (r.blocked) { X.audit('compta.verrou.refus', k, { mois: r.months.join(',') }); X.say('Période clôturée (' + r.months.join(', ') + ') : modification refusée et non enregistrée. Rouvrez le mois (Compta › Clôture) ou rechargez l’écran.', 'error'); return false; }
          }
        }
      } catch (e) {}
      return orig.apply(this, arguments);
    };
  }

  /* ---------------- interface ---------------- */
  var S = X.S, TV = { open: false };
  function tabTva() {
    var f = X.filt(), L = X.entries().filter(function (e) { return X.inPeriod(e, { from: f.from, to: f.to, cur: f.cur }); }), T = tvaState(L);
    var bar = '<p>Devise <select id="tv_cur" style="padding:5px">' + X.curOpts().map(function (c) { return '<option' + (c === f.cur ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select> Du ' + X.inp('tv_from', S.from, 'AAAA-MM-JJ', 'width:110px') + ' au ' + X.inp('tv_to', S.to, 'AAAA-MM-JJ', 'width:110px') + ' ' + X.btn('tv_new', '➕ Justificatif de TVA déductible') + '</p>';
    var card = '<p style="padding:8px;border-radius:8px;background:#f1f5f9">TVA collectée (ventes − avoirs) <b>' + nf(T.collectee) + '</b> − TVA récupérable <b>' + nf(T.recuperable) + '</b> = <b>' + nf(Math.abs(T.solde)) + ' ' + esc(f.cur) + '</b> ' + (T.etat === 'nul' ? '(nul)' : T.etat === 'à reverser' ? '<span style="color:#b45309">à reverser</span>' : '<span style="color:#15803d">crédit de TVA</span>') + '</p>';
    var form = '';
    if (S.form && S.form.type === 'tva') {
      var o = S.form;
      form = '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Justificatif de TVA déductible</b><p style="font-size:12px;color:#64748b;margin:4px 0">Le montant TTC de cet achat doit déjà figurer en charge (facture fournisseur ou dépense de caisse) : la TVA est reclassée de la charge vers « TVA récupérable » (4452), sans changer la trésorerie ni les dettes.</p>' +
        '<p>Date ' + X.inp('tv_d', o.date || X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Fournisseur ' + X.inp('tv_s', o.supplier, 'Fournisseur', 'width:160px') + ' N° pièce ' + X.inp('tv_r', o.ref, 'N° facture', 'width:130px') + '</p>' +
        '<p>HT ' + X.inp('tv_h', o.ht, '0.00', 'width:100px') + ' Taux % ' + X.inp('tv_t', o.rate == null ? 16 : o.rate, '16', 'width:60px') + ' Devise <select id="tv_c" style="padding:5px">' + X.curOpts().map(function (c) { return '<option' + (c === (o.currency || f.cur) ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select> Charge <select id="tv_a" style="padding:5px">' + CH.map(function (a) { return '<option value="' + a + '"' + (a === (o.acc || '601') ? ' selected' : '') + '>' + a + ' ' + esc(accName(a)) + '</option>'; }).join('') + '</select></p>' +
        '<p id="tv_prev" style="color:#334155"></p><p>' + X.btn('tv_ok', 'Enregistrer') + X.btn('tv_no', 'Retour') + '</p></div>';
    }
    if (S.form && S.form.type === 'tvax') form = '<div style="border:1px solid #fca5a5;border-radius:8px;padding:10px;margin:8px 0"><b>Annuler ' + esc(S.form.ref) + '</b><p>' + X.inp('tv_why', '', 'Motif obligatoire', 'width:100%') + '</p>' + X.btn('tv_xok', 'Confirmer') + X.btn('tv_xno', 'Retour') + '</div>';
    var rows = tvaList().slice().reverse().map(function (t) { return '<tr>' + X.td(esc(t.date)) + X.td(esc(t.supplier)) + X.td(esc(t.ref)) + X.td(nf(t.ht), 'right') + X.td(esc(t.rate) + ' %', 'right') + X.td(nf(t.tva) + ' ' + esc(t.currency), 'right') + X.td(t.acc) + X.td(t.status === 'annulé' ? '<span style="color:#94a3b8">annulé (' + esc(t.cancel_reason || '') + ')</span>' : '<button type="button" class="tv_x" data-id="' + esc(t.id) + '" data-ref="' + esc(t.ref) + '">Annuler</button>') + '</tr>'; });
    return bar + card + form + (rows.length ? X.table(['Date', 'Fournisseur', 'Pièce', 'HT', 'Taux', 'TVA', 'Charge', ''], rows) : '<p style="color:#64748b">Aucun justificatif de TVA déductible. Sans justificatif, la TVA récupérable reste à zéro.</p>') +
      '<p style="font-size:12px;color:#64748b">Hypothèses à valider avec votre comptable : TVA collectée à la date de facture (pas à l’encaissement) ; TVA récupérable uniquement sur justificatif saisi ici ; chaque devise séparée, sans conversion. Ceci n’est pas une déclaration fiscale.</p>';
  }
  function tabEtats() {
    var f = X.filt(), all = X.entries().filter(function (e) { return e.cur === f.cur; }), P = all.filter(function (e) { return X.inPeriod(e, { from: f.from, to: f.to, cur: f.cur }); }), R = resultat(P);
    var B = bilan(all.filter(function (e) { return !f.to || e.date <= f.to; }));
    var bar = '<p>Devise <select id="et_cur" style="padding:5px">' + X.curOpts().map(function (c) { return '<option' + (c === f.cur ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select> Du ' + X.inp('et_from', S.from, 'AAAA-MM-JJ', 'width:110px') + ' au ' + X.inp('et_to', S.to, 'AAAA-MM-JJ', 'width:110px') + ' ' + X.btn('et_csv', '⬇ CSV') + X.btn('et_pdf', '🖨 PDF') + '</p>';
    var line = function (x) { return '<tr>' + X.td(x.acc + ' ' + esc(x.nom) + (x.inverse ? ' ⚠' : '')) + X.td(nf(x.amount), 'right') + '</tr>'; };
    var cr = '<h4>Compte de résultat ' + (f.from || f.to ? '(' + esc(f.from || 'début') + ' → ' + esc(f.to || 'ce jour') + ')' : '(depuis le début)') + '</h4>' +
      X.table(['Produits', ''], R.produits.map(line).concat(['<tr style="font-weight:700">' + X.td('Total produits') + X.td(nf(R.totalProduits), 'right') + '</tr>'])) +
      X.table(['Charges', ''], R.charges.map(line).concat(['<tr style="font-weight:700">' + X.td('Total charges') + X.td(nf(R.totalCharges), 'right') + '</tr>'])) +
      '<p style="padding:8px;border-radius:8px;background:' + (R.resultat >= 0 ? '#e6f6ea' : '#fde8e8') + '"><b>' + (R.resultat >= 0 ? 'Bénéfice' : 'Perte') + ' : ' + nf(Math.abs(R.resultat)) + ' ' + esc(f.cur) + '</b></p>';
    var bl = '<h4>Bilan simplifié au ' + esc(f.to || X.today()) + ' (cumul depuis le début)</h4>' +
      '<p style="padding:6px;border-radius:6px;background:' + (B.equilibre ? '#e6f6ea' : '#fde8e8') + '">' + (B.equilibre ? '✅ Actif = passif' : '⛔ Actif ≠ passif : journal déséquilibré') + ' — ' + nf(B.totalActif) + ' / ' + nf(B.totalPassif) + ' ' + esc(f.cur) + '</p>' +
      X.table(['Actif', ''], B.actif.map(line).concat(['<tr style="font-weight:700">' + X.td('Total actif') + X.td(nf(B.totalActif), 'right') + '</tr>'])) +
      X.table(['Passif', ''], B.passif.map(line).concat(['<tr style="font-weight:700">' + X.td('Total passif') + X.td(nf(B.totalPassif), 'right') + '</tr>']));
    S._pdf = { html: cr + bl, cur: f.cur, from: f.from, to: f.to, res: R.resultat, ok: B.equilibre, ta: B.totalActif, tp: B.totalPassif };   /* V178 : contenu du PDF */
    return bar + cr + bl + '<p style="font-size:12px;color:#64748b">États <b>simplifiés</b> calculés depuis le journal : sans capital, immobilisations, amortissements, stocks ni à-nouveaux d’ouverture (⚠ = solde à l’envers de sa nature, à vérifier). Ce n’est pas un bilan certifié ; à valider avec votre comptable.</p>';
  }
  X.XT.tabs.push({ id: 'tva', label: '🧮 TVA', html: tabTva }, { id: 'etats', label: '📊 États', html: tabEtats });
  X.XT.clHtml = function () {
    var on = guardOn();
    return '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:8px;margin:8px 0"><label><input type="checkbox" id="cl_lock"' + (on ? ' checked' : '') + '> 🛡 <b>Verrou</b> : refuser l’enregistrement de factures, paiements, avoirs, achats, dépenses et justificatifs de TVA datés d’un mois clôturé</label><br><small style="color:#64748b">Option désactivée par défaut. Une saisie refusée n’est pas enregistrée (rechargez l’écran si elle y reste affichée). Ne couvre pas un écran qui écrit sans passer par l’enregistrement standard.</small></div>';
  };
  X.XT.bind.push(function (o) {
    var q = function (id) { return d.getElementById(id); }, redo = function () { X.render(); };
    ['tv', 'et'].forEach(function (p) {
      var c = q(p + '_cur'); if (c) c.onchange = function () { S.cur = c.value; redo(); };
      ['from', 'to'].forEach(function (k) { var e = q(p + '_' + k); if (e) e.onchange = function () { S[k] = DATE.test(e.value) ? e.value : ''; redo(); }; });
    });
    X.on('tv_new', function () { S.form = { type: 'tva' }; redo(); }); X.on('tv_no', function () { S.form = null; redo(); });
    var prev = function () { var h = pn((q('tv_h') || {}).value), t = pn((q('tv_t') || {}).value), el = q('tv_prev'); if (el) el.textContent = h > 0 && t > 0 ? 'TVA ' + nf(r2(h * t / 100)) + ' → TTC ' + nf(r2(h + r2(h * t / 100))) : ''; };
    ['tv_h', 'tv_t'].forEach(function (id) { var e = q(id); if (e) e.oninput = prev; }); prev();
    X.on('tv_ok', function () {
      var r = addTva({ date: q('tv_d').value, supplier: q('tv_s').value, ref: q('tv_r').value, ht: q('tv_h').value, rate: q('tv_t').value, currency: q('tv_c').value, acc: q('tv_a').value });
      if (r.error) { S.form = { type: 'tva', date: q('tv_d').value, supplier: q('tv_s').value, ref: q('tv_r').value, ht: q('tv_h').value, rate: q('tv_t').value, currency: q('tv_c').value, acc: q('tv_a').value }; S.msg = r.error; return redo(); }
      S.form = null; S.msg = 'Justificatif ' + r.rec.ref + ' enregistré : TVA récupérable ' + nf(r.rec.tva) + ' ' + r.rec.currency + '.'; redo();
    });
    Array.prototype.forEach.call(o.querySelectorAll('.tv_x'), function (x) { x.onclick = function () { S.form = { type: 'tvax', id: x.getAttribute('data-id'), ref: x.getAttribute('data-ref') }; redo(); }; });
    X.on('tv_xno', function () { S.form = null; redo(); });
    X.on('tv_xok', function () { var r = cancelTva(S.form.id, (q('tv_why') || {}).value); S.msg = r.error || 'Justificatif annulé.'; if (!r.error) S.form = null; redo(); });
    X.on('et_pdf', function () {
      var P = S._pdf; if (!P) return;
      if (!window.EXBRapport) { X.say('Module d’export PDF indisponible.', 'error'); return; }
      X.audit('compta.etats.pdf', P.cur, {});
      window.EXBRapport.print('États financiers simplifiés', { prefix: 'ETA', sousTitre: 'Devise ' + P.cur + ' · du ' + (P.from || 'début') + ' au ' + (P.to || 'ce jour'), meta: [['Résultat', nf(P.res) + ' ' + P.cur], ['Total actif', nf(P.ta) + ' ' + P.cur], ['Total passif', nf(P.tp) + ' ' + P.cur], ['Actif = passif', P.ok ? 'oui' : 'NON']], html: P.html, note: 'États simplifiés calculés depuis le journal, à valider avec le comptable. Ce n’est pas un bilan certifié.' });
    });
    var cl = q('et_csv'); if (cl) cl.onclick = function () {
      var f = X.filt(), all = X.entries().filter(function (e) { return e.cur === f.cur; }), R = resultat(all.filter(function (e) { return X.inPeriod(e, { from: f.from, to: f.to, cur: f.cur }); })), B = bilan(all.filter(function (e) { return !f.to || e.date <= f.to; })), L = [];
      L.push(['Etat', 'Compte', 'Intitule', 'Montant', 'Devise'].map(X.csvCell).join(';'));
      R.produits.forEach(function (x) { L.push(['Produits', x.acc, x.nom, x.amount, f.cur].map(X.csvCell).join(';')); }); R.charges.forEach(function (x) { L.push(['Charges', x.acc, x.nom, x.amount, f.cur].map(X.csvCell).join(';')); }); L.push(['Resultat', '', 'Resultat de la periode', R.resultat, f.cur].map(X.csvCell).join(';'));
      B.actif.forEach(function (x) { L.push(['Actif', x.acc, x.nom, x.amount, f.cur].map(X.csvCell).join(';')); }); B.passif.forEach(function (x) { L.push(['Passif', x.acc, x.nom, x.amount, f.cur].map(X.csvCell).join(';')); });
      X.audit('compta.etats.export', f.cur, { lignes: L.length }); var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + L.join('\r\n')], { type: 'text/csv;charset=utf-8' })); a.download = 'etats-financiers-simplifies-' + X.today() + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500);
    };
    var lk = q('cl_lock'); if (lk) lk.onchange = function () { setGuard(lk.checked); S.msg = lk.checked ? 'Verrou activé.' : 'Verrou désactivé.'; redo(); };
  });
  install();
  w.EXBCOMPTA_ETATS = { version: 1, tvaList: tvaList, tvaValidate: tvaValidate, addTva: addTva, cancelTva: cancelTva, tvaState: tvaState, resultat: resultat, bilan: bilan, guardCheck: guardCheck, touchedMonths: touchedMonths, setGuard: setGuard, guardOn: guardOn };
})(window);
