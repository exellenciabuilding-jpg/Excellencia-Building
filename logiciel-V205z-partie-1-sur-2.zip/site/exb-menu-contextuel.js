/* Excellencia Building — Menu du clic droit (Couper / Copier / Coller…) dans tous les modules + correction orthographique française.
 * - Clic droit (ou appui long sur téléphone) dans un champ ou sur un texte sélectionné : menu à côté du curseur.
 *   Maj + clic droit = menu normal du navigateur.
 * - Orthographe : soulignement du navigateur activé (français) dans les zones de texte, correction d'un mot ou du champ depuis le menu,
 *   et correction automatique douce (accents oubliés, mots doublés, espaces, majuscules) à la sortie des zones de texte libres (désactivable dans le menu).
 * Données : clé exb_autocorrect (activé par défaut). Aucune donnée envoyée. Pour retirer : supprimer la balise <script src="exb-menu-contextuel.js">. */
(function (w, d) {
  'use strict';
  if (w.EXB_MENU) return;
  var K_AUTO = 'exb_autocorrect';
  function note(t, k, ms) { try { w.notify && w.notify(t, k || 'info', ms || 4500); } catch (e) {} }
  function autoOn() { try { return localStorage.getItem(K_AUTO) !== '0'; } catch (e) { return true; } }
  function setAuto(v) { try { localStorage.setItem(K_AUTO, v ? '1' : '0'); } catch (e) {} }

  /* ---------------------------------------------------------------- orthographe */
  /* mots qui ne s'écrivent JAMAIS sans accent / avec cette faute (clé en minuscules) */
  var DICT = {
    'recu': 'reçu', 'recus': 'reçus', 'beton': 'béton', 'betonnage': 'bétonnage', 'betonniere': 'bétonnière', 'batiment': 'bâtiment', 'batiments': 'bâtiments', 'materiau': 'matériau', 'materiaux': 'matériaux', 'materiel': 'matériel', 'materiels': 'matériels',
    'quantite': 'quantité', 'quantites': 'quantités', 'designation': 'désignation', 'designations': 'désignations', 'qualite': 'qualité', 'securite': 'sécurité', 'proprietaire': 'propriétaire', 'societe': 'société', 'reseau': 'réseau', 'reseaux': 'réseaux',
    'telephone': 'téléphone', 'numero': 'numéro', 'numeros': 'numéros', 'delai': 'délai', 'delais': 'délais', 'duree': 'durée', 'periode': 'période', 'general': 'général', 'generale': 'générale', 'generaux': 'généraux', 'tres': 'très', 'pret': 'prêt', 'prets': 'prêts', 'verifie': 'vérifié', 'verifiee': 'vérifiée', 'verifies': 'vérifiés', 'terminee': 'terminée', 'deja': 'déjà', 'apres': 'après',
    'etre': 'être', 'meme': 'même', 'memes': 'mêmes', 'probleme': 'problème', 'problemes': 'problèmes', 'systeme': 'système', 'systemes': 'systèmes', 'theme': 'thème', 'cout': 'coût', 'couts': 'coûts', 'realisation': 'réalisation', 'realisations': 'réalisations', 'realise': 'réalisé', 'realises': 'réalisés',
    'amenagement': 'aménagement', 'amenagements': 'aménagements', 'renovation': 'rénovation', 'electrique': 'électrique', 'electriques': 'électriques', 'electricite': 'électricité', 'electricien': 'électricien', 'ingenieur': 'ingénieur', 'ingenieurs': 'ingénieurs', 'ingenierie': 'ingénierie',
    'preparation': 'préparation', 'verification': 'vérification', 'modele': 'modèle', 'modeles': 'modèles', 'categorie': 'catégorie', 'categories': 'catégories', 'reference': 'référence', 'references': 'références', 'reglement': 'règlement', 'reglements': 'règlements',
    'epaisseur': 'épaisseur', 'facade': 'façade', 'facades': 'façades', 'macon': 'maçon', 'maconnerie': 'maçonnerie', 'cloture': 'clôture', 'reception': 'réception', 'evenement': 'événement', 'evenements': 'événements', 'etude': 'étude', 'etudes': 'études', 'ecole': 'école', 'ecoles': 'écoles',
    'ferrailage': 'ferraillage', 'carelage': 'carrelage', 'plafon': 'plafond', 'aggregat': 'agrégat', 'aggregats': 'agrégats', 'apartement': 'appartement', 'appartment': 'appartement', 'oeuvre': 'œuvre', 'oeuvres': 'œuvres', 'excelencia': 'Excellencia',
    'tolle': 'tôle', 'toles': 'tôles', 'resistance': 'résistance', 'fondation': 'fondation', 'definitivement': 'définitivement', 'complement': 'complément', 'supplement': 'supplément', 'estimatif': 'estimatif', 'regle': 'réglé', 'acces': 'accès', 'progres': 'progrès',
    'deplacement': 'déplacement', 'deplacements': 'déplacements', 'equipement': 'équipement', 'equipements': 'équipements', 'equipe': 'équipe', 'equipes': 'équipes', 'echeance': 'échéance', 'echeances': 'échéances', 'etat': 'état', 'ete': 'été', 'metier': 'métier', 'metiers': 'métiers',
    'degats': 'dégâts', 'depot': 'dépôt', 'depots': 'dépôts', 'dossier': 'dossier', 'entreprise': 'entreprise', 'immeuble': 'immeuble', 'hopital': 'hôpital', 'hotel': 'hôtel', 'controle': 'contrôle', 'controles': 'contrôles', 'prevu': 'prévu', 'prevus': 'prévus', 'prevision': 'prévision', 'previsions': 'prévisions',
    'evaluation': 'évaluation', 'elevation': 'élévation', 'elevations': 'élévations', 'structure': 'structure', 'geometrie': 'géométrie', 'geotechnique': 'géotechnique', 'etage': 'étage', 'etages': 'étages', 'sejour': 'séjour', 'cuisine': 'cuisine', 'salle': 'salle', 'sous-sol': 'sous-sol'
  };
  /* 'ete' (été/été) et 'regle', 'etat' sont ambigus ou trop courts pour être corrigés seuls : on les retire */
  ['ete', 'regle', 'etat', 'fondation', 'dossier', 'entreprise', 'immeuble', 'structure', 'cuisine', 'salle', 'sous-sol', 'estimatif'].forEach(function (k) { delete DICT[k]; });
  var PHRASES = [[/\bbeton arme\b/gi, 'béton armé'], [/\bmain d['’ ]oeuvre\b/gi, 'main d’œuvre'], [/\bmise en oeuvre\b/gi, 'mise en œuvre'], [/\bsous traitant\b/gi, 'sous-traitant'], [/\ba cote\b/gi, 'à côté'], [/\bcest\b/gi, 'c’est']];
  var DOUBLES = /\b(le|la|les|de|du|des|un|une|et|à|en|que|pour|dans|sur|au|aux)\s+\1\b/gi;
  function matchCase(src, rep) {
    if (src.length > 1 && src === src.toUpperCase()) return rep.toUpperCase();
    if (src.charAt(0) !== src.charAt(0).toLowerCase()) return rep.charAt(0).toUpperCase() + rep.slice(1);
    return rep;
  }
  function skipToken(t) { return /@|:\/\/|www\.|\.(com|cd|org|net|fr)\b|[0-9]{3,}|[_\\\/#]/i.test(t); }
  /* corrige un texte ; opt.multiline : applique aussi les majuscules de début de phrase ; renvoie {text, changes:[[avant, après]]} */
  function fix(text, opt) {
    opt = opt || {}; var ch = [], src = String(text == null ? '' : text), out = src;
    function log(a, b) { if (a !== b && ch.length < 40) ch.push([a, b]); }
    PHRASES.forEach(function (p) { out = out.replace(p[0], function (m) { var r = matchCase(m, p[1]); log(m, r); return r; }); });
    out = out.split(/(\s+)/).map(function (tok) {
      if (!tok || /^\s+$/.test(tok) || skipToken(tok)) return tok;
      return tok.replace(/[A-Za-zÀ-ÿŒœ]+/g, function (wd) {
        var r = DICT[wd.toLowerCase()]; if (!r || r.toLowerCase() === wd.toLowerCase()) return wd;
        var o = matchCase(wd, r); log(wd, o); return o;
      });
    }).join('');
    out = out.replace(DOUBLES, function (m, a) { log(m, a); return a; });
    if (opt.multiline) {
      var o2 = out.replace(/[ \t]{2,}/g, ' ').replace(/ +([,.;])(?=\s|$)/g, '$1').replace(/([a-zà-ÿ]{2}),(?=[A-Za-zÀ-ÿ])/g, '$1, ').replace(/([a-zà-ÿ]{2})\.(?=[A-ZÀ-Ý][a-zà-ÿ])/g, '$1. ');
      o2 = o2.replace(/(^|[.!?]\s+|\n\s*)([a-zà-ÿ])(?![a-zà-ÿ0-9._-]*(?:@|:\/\/|\.[a-z]{2,3}\b))/g, function (m, a, b) { return a + b.toUpperCase(); });
      if (o2 !== out) log('espaces / majuscules', 'ajustés'); out = o2;
    }
    return { text: out, changes: ch };
  }
  /* mot sous le curseur (dans un champ) et sa correction éventuelle */
  function wordAt(txt, pos) {
    var re = /[A-Za-zÀ-ÿŒœ]+/g, m;
    while ((m = re.exec(txt))) { if (pos >= m.index && pos <= m.index + m[0].length) return { w: m[0], s: m.index, e: m.index + m[0].length }; }
    return null;
  }
  w.EXB_SPELL = { fix: fix, dict: DICT, phrases: PHRASES };

  /* ---------------------------------------------------------------- champs éditables */
  var NOEDIT = /^(checkbox|radio|button|submit|reset|file|color|range|image|hidden)$/i;
  function editable(el) {
    if (!el || !el.closest) return null;
    var e = el.closest('input,textarea,[contenteditable=""],[contenteditable="true"]');
    if (!e) return null;
    if (e.tagName === 'INPUT' && NOEDIT.test(e.type || 'text')) return null;
    if (e.readOnly || e.disabled) return null;
    return e;
  }
  function inputLike(e) { return e && (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA'); }
  function selRange(e) { try { if (inputLike(e) && typeof e.selectionStart === 'number') return [e.selectionStart, e.selectionEnd]; } catch (x) {} return null; }
  function selText(e) {
    if (e && inputLike(e)) { var r = selRange(e); return r ? e.value.slice(r[0], r[1]) : ''; }
    try { return String(w.getSelection ? w.getSelection().toString() : ''); } catch (x) { return ''; }
  }
  function fire(e) { try { e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); } catch (x) {} }
  function setSel(e, s, t) { try { e.setSelectionRange(s, t); } catch (x) {} }
  function insert(e, txt, saved) {
    try { e.focus(); } catch (x) {}
    if (inputLike(e)) {
      var r = saved || selRange(e);
      if (r) { try { e.setRangeText(txt, r[0], r[1], 'end'); } catch (x) { e.value = e.value.slice(0, r[0]) + txt + e.value.slice(r[1]); } }
      else { e.value += txt; }
      fire(e);
    } else { try { d.execCommand('insertText', false, txt); } catch (x) {} }
  }
  function copyText(t) {
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t); return true; } } catch (e) {}
    try { var ta = d.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;left:-9999px'; d.body.appendChild(ta); ta.select(); var ok = d.execCommand('copy'); ta.remove(); return ok; } catch (e) { return false; }
  }

  /* ---------------------------------------------------------------- menu */
  var box = null, ctx = null;
  function css() {
    if (d.getElementById('exbmCss')) return; var s = d.createElement('style'); s.id = 'exbmCss';
    s.textContent = '#exbMenu{position:fixed;z-index:2147483000;min-width:230px;max-width:320px;background:#fff;border:1px solid #c9d3df;border-radius:12px;box-shadow:0 10px 32px rgba(15,42,86,.28);padding:6px;font:14px Arial,Helvetica,sans-serif;color:#172033;user-select:none;-webkit-user-select:none}' +
      '#exbMenu button{display:flex;gap:10px;align-items:center;width:100%;text-align:left;border:0;background:none;padding:9px 12px;border-radius:8px;font:inherit;color:inherit;cursor:pointer}#exbMenu button:hover:not([disabled]){background:#eef4fc}' +
      '#exbMenu button[disabled]{opacity:.4;cursor:default}#exbMenu .k{margin-left:auto;font-size:11.5px;color:#6b7a99}#exbMenu hr{border:0;border-top:1px solid #e3e9f2;margin:5px 4px}#exbMenu .t{font-size:11.5px;color:#6b7a99;padding:4px 12px 2px}#exbMenu .sg{color:#0b6b3a;font-weight:700}';
    d.head.appendChild(s);
  }
  function close() { if (box) { box.remove(); box = null; } ctx = null; }
  function item(label, key, fn, off, cls) { return { label: label, key: key, fn: fn, off: off, cls: cls }; }
  function build(el, ev) {
    var ed = editable(el), sel = selText(ed), has = !!sel, rng = ed ? selRange(ed) : null, items = [], sug = null;
    if (ed && inputLike(ed) && rng && /^(text|search|)$/i.test(ed.type || 'text') || (ed && ed.tagName === 'TEXTAREA')) {
      var wd = wordAt(ed.value, rng ? rng[0] : 0);
      if (wd && !skipToken(wd.w)) { var rep = DICT[wd.w.toLowerCase()]; if (rep && rep.toLowerCase() !== wd.w.toLowerCase()) sug = { w: wd, rep: matchCase(wd.w, rep) }; else if (w.EXB_SPELL && w.EXB_SPELL.suggest && wd.w === wd.w.toLowerCase()) { var pr = w.EXB_SPELL.suggest(wd.w); if (pr && pr.toLowerCase() !== wd.w.toLowerCase()) sug = { w: wd, rep: matchCase(wd.w, pr), maybe: true }; } }
    }
    if (sug) { items.push(item('✎ ' + (sug.maybe ? 'Faute possible : ' : 'Corriger ') + '« ' + sug.w.w + ' » → « ' + sug.rep + ' »', '', function () { var e = ed; setSel(e, sug.w.s, sug.w.e); insert(e, sug.rep, [sug.w.s, sug.w.e]); }, false, 'sg')); items.push('-'); }
    if (ed) items.push(item('✂ Couper', 'Ctrl+X', function () { var t = selText(ed); if (!t) return; try { ed.focus(); if (rng) setSel(ed, rng[0], rng[1]); if (!d.execCommand('cut')) throw 0; } catch (x) { copyText(t); insert(ed, '', rng); } fire(ed); }, !has));
    items.push(item('⧉ Copier', 'Ctrl+C', function () { var t = sel || selText(ed); if (!t) return; try { if (ed) { ed.focus(); if (rng) setSel(ed, rng[0], rng[1]); } if (!d.execCommand('copy')) throw 0; } catch (x) { copyText(t); } note('✓ Copié', 'ok', 1500); }, !has));
    if (ed) items.push(item('📋 Coller', 'Ctrl+V', function () {
      var r = rng;
      if (navigator.clipboard && navigator.clipboard.readText) { navigator.clipboard.readText().then(function (t) { if (t) { ed.focus(); insert(ed, t, r); } }, function () { note('Le navigateur bloque le collage par le menu : utilisez Ctrl+V (ou appui long › Coller).', 'warn', 6000); }); }
      else note('Utilisez Ctrl+V pour coller dans ce navigateur.', 'warn', 6000);
    }));
    if (ed) items.push(item('☐ Tout sélectionner', 'Ctrl+A', function () { ed.focus(); if (inputLike(ed)) { try { ed.select(); } catch (x) {} } else d.execCommand('selectAll'); }));
    if (ed && inputLike(ed) && !/^(number|date|time|datetime-local|email|tel|url|password)$/i.test(ed.type || 'text')) {
      items.push('-');
      items.push(item(has ? '✔ Corriger l’orthographe de la sélection' : '✔ Corriger l’orthographe du champ', '', function () {
        var multi = ed.tagName === 'TEXTAREA';
        if (has && rng) { var r = fix(sel, { multiline: false }); if (r.text === sel) { note('Aucune faute trouvée dans la sélection.', 'info', 2500); return; } insert(ed, r.text, rng); report(r); }
        else { var r2 = fix(ed.value, { multiline: multi }); if (r2.text === ed.value) { note('Aucune faute trouvée.', 'info', 2500); return; } var pos = ed.selectionStart; ed.value = r2.text; try { ed.setSelectionRange(pos, pos); } catch (x) {} fire(ed); report(r2); }
      }));
    }
    if (ed && inputLike(ed) && w.EXB_SPELL && w.EXB_SPELL.check && String(ed.value || '').length > 3 && !/^(number|date|time|datetime-local|email|tel|url|password)$/i.test(ed.type || 'text')) {
      items.push(item('🔎 Signaler les fautes possibles', '', function () {
        var L = w.EXB_SPELL.check(ed.value);
        if (!L.length) { note('Aucune faute repérée. (Les noms propres ne sont pas vérifiés.)', 'info', 3500); return; }
        note('🔎 ' + L.slice(0, 6).map(function (x) { return x.w + ' → ' + x.rep + (x.sure ? '' : ' (?)'); }).join(' · ') + (L.length > 6 ? ' …' : '') + ' — rien n’a été modifié. Clic droit sur un mot pour le corriger.', 'warn', 9000);
      }));
    }
    items.push('-');
    items.push(item((autoOn() ? '☑' : '☐') + ' Correction automatique', '', function () { setAuto(!autoOn()); note(autoOn() ? '✎ Correction automatique activée.' : 'Correction automatique désactivée.', 'info', 2500); }));
    return items;
  }
  function report(r) { var s = r.changes.slice(0, 4).map(function (c) { return c[0] + ' → ' + c[1]; }).join(' · '); note('✎ Corrigé : ' + s + (r.changes.length > 4 ? ' …' : ''), 'ok', 5000); }
  function show(x, y, items) {
    close(); css(); box = d.createElement('div'); box.id = 'exbMenu'; box.setAttribute('role', 'menu');
    items.forEach(function (it) {
      if (it === '-') { box.appendChild(d.createElement('hr')); return; }
      var b = d.createElement('button'); b.type = 'button'; if (it.cls) b.className = it.cls; if (it.off) b.disabled = true;
      b.innerHTML = '<span></span><span class="k"></span>'; b.firstChild.textContent = it.label; b.lastChild.textContent = it.key || '';
      b.addEventListener('mousedown', function (e) { e.preventDefault(); });
      b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); if (it.off) return; close(); try { it.fn(); } catch (x) { try { console.error(x); } catch (y) {} } });
      box.appendChild(b);
    });
    d.body.appendChild(box);
    var W = w.innerWidth, H = w.innerHeight, r = box.getBoundingClientRect();
    box.style.left = Math.max(6, Math.min(x + 2, W - r.width - 6)) + 'px'; box.style.top = Math.max(6, Math.min(y + 2, H - r.height - 6)) + 'px';
  }
  d.addEventListener('contextmenu', function (ev) {
    if (ev.shiftKey || ev.ctrlKey) return;
    var t = ev.target; if (!t || !t.closest) return;
    if (t.closest('[data-nomenu],canvas,#exbMenu,video,audio')) return;
    var ed = editable(t), has = false;
    if (!ed) { try { has = !!(w.getSelection && String(w.getSelection()).trim()); } catch (e) {} if (!has) return; }
    ev.preventDefault(); show(ev.clientX, ev.clientY, build(t, ev));
  }, true);
  ['mousedown', 'scroll', 'resize', 'blur'].forEach(function (n) { w.addEventListener(n, function (e) { if (box && !(e.target && e.target.closest && e.target.closest('#exbMenu'))) close(); }, true); });
  d.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });

  /* ---------------------------------------------------------------- orthographe : soulignement + correction douce à la sortie du champ */
  var FREE = /note|desig|descr|projet|project|objet|libell|motif|comment|titre|title|sujet|subject|observ|lieu|place|nature|mention|condition|question|reponse|problem|remarque|detail|message|texte|text/i, NOT = /mail|phone|tel|url|code|matricule|numero|password|client|nom$|name|prenom|adresse|address|date|search|recherche|qr|key|token|id$/i;
  function eligible(e) {
    if (!e || !e.tagName) return false;
    /* champs techniques (code d'activation, clé, jeton…) : jamais corrigés — une majuscule ajoutée rendrait un code de licence invalide */
    if (e.tagName === 'TEXTAREA' || e.tagName === 'INPUT') {
      var ac = (e.getAttribute('autocapitalize') || '').toLowerCase(), sp = (e.getAttribute('spellcheck') || '').toLowerCase();
      if (ac === 'none' || ac === 'off' || sp === 'false' || e.hasAttribute('data-no-autocorrect') || (e.id && /^(exbLic|exbAdm)/.test(e.id))) return false;
      if (/\S{24,}/.test(String(e.value || '')) && !/\s/.test(String(e.value || '').trim())) return false;
    }
    if (e.tagName === 'TEXTAREA') return !e.readOnly && !e.disabled && !(e.id && /json|csv|code|import|export|sql|key/i.test(e.id));
    if (e.tagName !== 'INPUT' || !/^(text|search|)$/i.test(e.type || 'text') || e.readOnly || e.disabled) return false;
    if (e.matches('.mbx[data-k="d"]')) return true;
    var td = e.closest && e.closest('#exb_quote_lines td'); if (td && td.cellIndex === 2) return true;
    var tag = [e.id, e.name, e.placeholder, e.getAttribute('aria-label'), e.getAttribute('data-h')].join(' ');
    return FREE.test(tag) && !NOT.test(tag.replace(FREE, ''));
  }
  function mark(e) {
    if (!e || e.__exbSp) return; e.__exbSp = 1;
    try { if (!e.hasAttribute('spellcheck') && (e.tagName === 'TEXTAREA' || /^(text|search|)$/i.test(e.type || 'text'))) { e.setAttribute('spellcheck', 'true'); if (!e.getAttribute('lang') && !(e.closest && e.closest('[lang]'))) e.setAttribute('lang', 'fr'); } } catch (x) {}
  }
  function scan(root) { try { Array.prototype.forEach.call((root || d).querySelectorAll('input,textarea'), mark); } catch (e) {} }
  try { d.documentElement.getAttribute('lang') || d.documentElement.setAttribute('lang', 'fr'); } catch (e) {}
  scan(d);
  try { new MutationObserver(function (ms) { ms.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes || [], function (n) { if (n.nodeType === 1) { if (n.matches && n.matches('input,textarea')) mark(n); else if (n.querySelectorAll) scan(n); } }); }); }).observe(d.documentElement, { childList: true, subtree: true }); } catch (e) {}
  d.addEventListener('change', function (ev) {
    var e = ev.target; if (!autoOn() || !eligible(e) || e.__exbFixing) return;
    var r = fix(e.value, { multiline: e.tagName === 'TEXTAREA' }); if (r.text === e.value || !r.changes.length) return;
    e.__exbFixing = 1; e.value = r.text; fire(e); e.__exbFixing = 0; report(r);
  }, true);

  w.EXB_MENU = { version: 'V99-menu-1', close: close, autoOn: autoOn };
})(window, document);
