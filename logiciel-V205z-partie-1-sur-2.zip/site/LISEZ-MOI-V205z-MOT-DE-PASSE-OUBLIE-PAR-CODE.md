# V205z — Mot de passe oublié : un CODE à saisir (plus de lien) + fin de l'écran bleu au retour du lien

## À faire UNE FOIS dans Supabase (2 minutes, aucun SQL)
Le logiciel demande maintenant un code, mais c'est **Supabase qui écrit l'e-mail** : tant que son modèle contient encore le lien, le message reçu ne contiendra pas de code.
1. Supabase → **Authentication → Email Templates → Reset Password**.
2. Objet : `Votre code de réinitialisation — Excellencia Building`.
3. Corps : remplacer tout le contenu par celui de `supabase/email-template-mot-de-passe-oublie.html` (il contient `{{ .Token }}` = le code à 6 chiffres, et plus aucun `{{ .ConfirmationURL }}`).
4. Enregistrer. (Facultatif : durée de validité du code dans les réglages d'authentification, 1 heure par défaut.)

## Ce qui change pour l'utilisateur
1. Écran de connexion → « Mot de passe oublié ? » → saisir son e-mail → **Envoyer le code**.
2. Il reçoit un e-mail avec un code à 6 chiffres. Il revient sur le logiciel (même écran, rien à ouvrir), saisit le code + son nouveau mot de passe (2 fois) → **Valider et continuer** → il entre dans son espace.
3. « Rien reçu ? Renvoyer le code » (pas avant 60 s). 5 codes faux : attente imposée.
4. Le message reste le même que le compte existe ou non (pas de fuite d'information).

## Pourquoi l'écran bleu revenait (« Aucune licence associée à ce compte »)
Le lien de l'e-mail s'ouvrait dans un autre navigateur ou une autre application (Gmail, Chrome…) ou sur la page d'accueil sans « espace » mémorisé : l'ancien code jetait le jeton du lien, rien n'était réinitialisé, et le logiciel retombait sur l'écran bleu de verrouillage de licence. Avec le code, plus aucun lien : plus de jeton perdu.
Par sécurité, un lien de réinitialisation ou de confirmation **déjà reçu** (ancien e-mail) reste accepté, y compris ouvert sans espace connu : il affiche « Nouveau mot de passe », puis rattache le compte à l'entreprise (le contrôle de la fonction ne s'applique que lorsqu'un espace est demandé).

## Fichiers modifiés
exb-v205-connexion-espace.js, sw.js (cache), tools/check.js, tools/e2e-connexion-espace.py, + nouveaux : supabase/email-template-mot-de-passe-oublie.html et ce fichier.
Inchangé : le « code de restauration » donné par l'administrateur depuis l'écran de connexion locale (exb-sync.js).

## Tests
`node tools/check.js` ; `python3 tools/e2e-connexion-espace.py` (63 OK, serveur Supabase simulé : code correct / faux, trop court, même mot de passe, renvoi, ancien lien, lien sans espace).
