/* Excellencia Building V164 — Report contrôlé du chantier vers RH (pointage) et Stock (matériel) — module 02, Project Manager.
 * Principe du cahier des charges : pas d'écriture non contrôlée dans un autre module, pas de double traitement, chaque opération garde
 * identifiant, auteur, date, statut et lien avec le projet. Donc : APERÇU → validation par l'utilisateur → trace → annulation possible.
 * RH : écrit des présences dans exb_hr_presences (une par pointage, clé « TS:<id> »). N'écrit PAS dans la paie : la paie lit déjà exb_timesheets.
 * Stock : sortie de matériel vers le chantier (mouvement « out » + quantité), refusée si le stock est insuffisant ; annulation = contre-mouvement.
 * Moteur PUR (testable : tools/test-report-ops.js). Retrait : supprimer la balise <script src="exb-report-ops.js">. */
(function(root){'use strict';
var N=function(x){x=+x;return isFinite(x)?x:0},r2=function(x){return Math.round(N(x)*100)/100},sid=function(x){return String(x==null?'':x)};
var actifs=function(p){return (p||[]).filter(function(x){return x&&!x.annule})};

/* ---------- RH : pointages d'un projet → présences ---------- */
function apercuPointages(ts,hr,presences,pid){
  var emp={};(hr||[]).forEach(function(h){if(h&&h.id!=null)emp[sid(h.id)]=h});
  var deja={},jour={};actifs(presences).forEach(function(p){deja[sid(p.cle)]=1;jour[sid(p.emp)+'|'+sid(p.date)+'|'+sid(p.project_id)]=1});
  var L=[],vus={};
  (ts||[]).forEach(function(t){if(!t||sid(t.project_id)!==sid(pid))return;
    var l={ts:t.id,worker_id:t.worker_id,nom:t.worker_name||'',date:sid(t.date).slice(0,10),jours:N(t.days),statut:'a_reporter',raison:''};
    if(!l.date||l.jours<=0||!(l.jours<=1)){l.statut='invalide';l.raison='Date manquante ou jours hors de 0–1.'}
    else if(!emp[sid(t.worker_id)]){l.statut='sans_fiche';l.raison='Aucune fiche Personnel pour cet ouvrier : rien n\'est deviné.'}
    else if(deja['TS:'+sid(t.id)]){l.statut='deja';l.raison='Déjà reporté.'}
    else{var k=sid(t.worker_id)+'|'+l.date+'|'+sid(pid);if(jour[k]||vus[k]){l.statut='doublon';l.raison='Une présence existe déjà ce jour-là pour cet ouvrier sur ce projet.'}vus[k]=1}
    L.push(l)});
  var c={a_reporter:0,deja:0,sans_fiche:0,doublon:0,invalide:0};L.forEach(function(l){c[l.statut]++});
  return{lignes:L,compte:c}}

/* Crée les présences des lignes « a_reporter » choisies (ids). Pure : renvoie la nouvelle liste, ne modifie pas l'entrée. */
function reporterPointages(presences,ap,ids,o){o=o||{};var out=JSON.parse(JSON.stringify(presences||[])),cr=[],n=0;
  var pick={};(ids||[]).forEach(function(i){pick[sid(i)]=1});
  ap.lignes.forEach(function(l){if(l.statut!=='a_reporter'||!pick[sid(l.ts)])return;
    var cle='TS:'+sid(l.ts);if(out.some(function(p){return !p.annule&&p.cle===cle}))return;
    var p={id:(o.idf?o.idf(n):'PR-'+sid(o.now||Date.now())+'-'+sid(o.pid)+'-'+n),cle:cle,emp:sid(l.worker_id),nom:l.nom,date:l.date,jours:l.jours,project_id:sid(o.pid),source:'pointage',par:String(o.par||''),cree:String(o.now||new Date().toISOString())};
    out.push(p);cr.push(p);n++});
  return{ok:true,presences:out,crees:cr}}

/* Report AUTOMATIQUE (pur) : seuls les pointages créés après l'activation (hors « base »), valides, avec fiche Personnel, sans doublon,
 * et jamais annulés à la main. Les autres restent dans l'aperçu manuel. */
function reporterAuto(ts,hr,presences,base,o){o=o||{};var B={};(base||[]).forEach(function(i){B[sid(i)]=1});
  var an={};(presences||[]).forEach(function(p){if(p&&p.annule)an[sid(p.cle)]=1});
  var out=JSON.parse(JSON.stringify(presences||[])),crees=[],pids={};(ts||[]).forEach(function(t){if(t&&t.project_id)pids[sid(t.project_id)]=1});
  Object.keys(pids).forEach(function(pid){var ap=apercuPointages(ts,hr,out,pid),ids=ap.lignes.filter(function(l){return l.statut==='a_reporter'&&!B[sid(l.ts)]&&!an['TS:'+sid(l.ts)]}).map(function(l){return l.ts});
    if(!ids.length)return;var r=reporterPointages(out,ap,ids,{pid:pid,par:o.par||'automatique',now:o.now,idf:o.idf?function(n){return o.idf(pid,n)}:null});out=r.presences;crees=crees.concat(r.crees)});
  return{ok:true,presences:out,crees:crees}}

function annulerPresence(presences,id,motif,o){o=o||{};if(!String(motif||'').trim())return{ok:false,error:'Un motif est obligatoire pour annuler un report.'};
  var out=JSON.parse(JSON.stringify(presences||[])),p=out.filter(function(x){return x.id===id})[0];
  if(!p)return{ok:false,error:'Report introuvable.'};if(p.annule)return{ok:false,error:'Déjà annulé.'};
  p.annule={date:String(o.now||new Date().toISOString()).slice(0,10),par:String(o.par||''),motif:String(motif).trim().slice(0,200)};return{ok:true,presences:out}}

/* ---------- Stock : sortie de matériel vers le chantier ---------- */
function sortieMateriel(stock,moves,o){o=o||{};
  if(!o.pid)return{ok:false,error:'Choisissez un projet.'};
  var q=N(o.qty);if(!(q>0))return{ok:false,error:'Quantité invalide.'};
  var st=JSON.parse(JSON.stringify(stock||[])),mv=JSON.parse(JSON.stringify(moves||[])),it=st.filter(function(x){return sid(x.id)===sid(o.item)})[0];
  if(!it)return{ok:false,error:'Article introuvable dans le stock.'};
  if(!o.id)return{ok:false,error:'Identifiant de l\'opération manquant.'};
  if(mv.some(function(m){return m.id===o.id}))return{ok:false,error:'Opération déjà enregistrée (aucun double traitement).'};
  if(q>N(it.qty)+1e-9)return{ok:false,error:'Stock insuffisant : '+N(it.qty)+' '+(it.unit||'')+' disponible(s) pour '+q+' demandé(s).'};
  it.qty=r2(N(it.qty)-q);
  var m={id:o.id,item:it.id,type:'out',qty:q,ref:String(o.ref||'Chantier'),date:String(o.date||new Date().toISOString()).slice(0,10),project_id:sid(o.pid),source:'pm',par:String(o.par||'')};
  mv.push(m);return{ok:true,stock:st,moves:mv,move:m}}

function annulerSortie(stock,moves,id,motif,o){o=o||{};if(!String(motif||'').trim())return{ok:false,error:'Un motif est obligatoire pour annuler une sortie.'};
  var st=JSON.parse(JSON.stringify(stock||[])),mv=JSON.parse(JSON.stringify(moves||[])),m=mv.filter(function(x){return x.id===id})[0];
  if(!m||m.source!=='pm'||m.type!=='out')return{ok:false,error:'Sortie introuvable.'};if(m.annule)return{ok:false,error:'Déjà annulée.'};
  var it=st.filter(function(x){return sid(x.id)===sid(m.item)})[0];if(!it)return{ok:false,error:'Article introuvable dans le stock.'};
  it.qty=r2(N(it.qty)+N(m.qty));m.annule={date:String(o.now||new Date().toISOString()).slice(0,10),par:String(o.par||''),motif:String(motif).trim().slice(0,200)};
  var c={id:o.idc||('MV-ANN-'+id),item:m.item,type:'in',qty:m.qty,ref:'ANNULATION '+id,date:m.annule.date,project_id:m.project_id,source:'pm',contre:id,par:m.annule.par};
  mv.push(c);return{ok:true,stock:st,moves:mv}}

/* Consommation nette d'un projet, par article (sorties non annulées). */
function consommation(moves,stock,pid){var a={};(moves||[]).forEach(function(m){if(!m||m.source!=='pm'||m.type!=='out'||m.annule||sid(m.project_id)!==sid(pid))return;a[m.item]=r2((a[m.item]||0)+N(m.qty))});
  return Object.keys(a).map(function(k){var it=(stock||[]).filter(function(x){return sid(x.id)===k})[0]||{};return{item:k,nom:it.name||k,unite:it.unit||'',qty:a[k]}})}

var API={apercuPointages:apercuPointages,reporterPointages:reporterPointages,reporterAuto:reporterAuto,annulerPresence:annulerPresence,sortieMateriel:sortieMateriel,annulerSortie:annulerSortie,consommation:consommation};
root.EXBRO=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;

/* ===================== ÉCRAN (navigateur seulement) ===================== */
if(typeof document==='undefined')return;
var KP='exb_hr_presences',KC='exb_ro_cfg',ST={pid:'',sel:{}},BUSY=false;
var esc=function(v){return String(v==null?'':v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
var L=function(k){try{return load(k,[])}catch(e){return[]}};
var say=function(t,k){try{notify(t,k||'info',4500)}catch(e){try{exbAlert(t)}catch(_){}}};
var who=function(){try{return (window.exbUser&&(exbUser.name||exbUser.nom))||''}catch(e){return ''}};
var idf=function(p){return typeof exbId==='function'?exbId(p):p+'-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)};
var audit=function(a,o,d){try{if(window.EXBCore&&EXBCore.audit)EXBCore.audit.log(a,o,d)}catch(e){}};
var ICO={a_reporter:'🟢',deja:'✅',sans_fiche:'⛔',doublon:'⚠️',invalide:'⛔'},LIB={a_reporter:'à reporter',deja:'déjà reporté',sans_fiche:'sans fiche Personnel',doublon:'doublon',invalide:'invalide'};
function cfg(){try{var c=load(KC,null);return c&&typeof c==='object'&&!Array.isArray(c)?c:{auto:true,base:null}}catch(e){return{auto:true,base:null}}}
/* Exécution automatique : appelée après chaque enregistrement de pointages. Sans effet si désactivée ou avant la base de départ. */
function autoRun(){if(BUSY)return;var c=cfg();if(!c.auto||!Array.isArray(c.base))return;BUSY=true;
  try{var r=reporterAuto(L('exb_timesheets'),hrL(),L(KP),c.base,{par:'automatique',now:new Date().toISOString(),idf:function(pid,n){return idf('PR')}});
    if(r.crees.length){save(KP,r.presences);audit('report.rh.auto','pointages',{n:r.crees.length});say(r.crees.length+' pointage(s) reporté(s) automatiquement vers les RH.','success')}}
  catch(e){}finally{BUSY=false}}
function baseline(){var c=cfg();if(Array.isArray(c.base))return;c.base=L('exb_timesheets').map(function(t){return t.id});if(c.auto===undefined)c.auto=true;save(KC,c)}
function hook(){if(window.__exbRoHook)return;window.__exbRoHook=1;
  var os=window.save;if(typeof os==='function'){window.save=function(k){var r=os.apply(this,arguments);if(k==='exb_timesheets')setTimeout(autoRun,0);return r}}
  var t=0,iv=setInterval(function(){t++;var S=window.EXBS;if(S&&S.set&&!S.__roHook){S.__roHook=1;var o2=S.set;S.set=function(k){var r=o2.apply(this,arguments);if(k==='exb_timesheets')setTimeout(autoRun,0);return r}}if((S&&S.__roHook)||t>40)clearInterval(iv)},500)}
function hrL(){return typeof exbHr!=='undefined'?exbHr:[]}
function view(pid){ST.pid=pid;if(!pid)return '<p class="exb-muted">Choisissez un chantier pour reporter son pointage vers les RH et son matériel vers le Stock.</p>';
  var ap=apercuPointages(L('exb_timesheets'),hrL(),L(KP),pid),c=ap.compte,h='<h3 style="margin:10px 0 6px">👷 Pointage → RH (présences)</h3>';
  h+='<p class="exb-muted" style="margin:0 0 6px">Aperçu avant tout report. '+c.a_reporter+' à reporter · '+c.deja+' déjà reportés'+(c.sans_fiche?' · <b style="color:#b91c1c">'+c.sans_fiche+' sans fiche Personnel</b>':'')+(c.doublon?' · '+c.doublon+' doublon(s)':'')+(c.invalide?' · '+c.invalide+' invalide(s)':'')+'. La paie n\'est pas touchée : elle lit déjà les pointages.</p>';
  if(ap.lignes.length){h+='<div class="exb-scroll"><table class="exb-table"><thead><tr><th></th><th>Date</th><th>Ouvrier</th><th>Jours</th><th>État</th></tr></thead><tbody>'+ap.lignes.slice(0,120).map(function(l){return '<tr><td>'+(l.statut==='a_reporter'?'<input type="checkbox" style="width:auto" checked onchange="EXBRO.pick(\''+esc(l.ts)+'\',this.checked)">':'')+'</td><td>'+esc(l.date)+'</td><td>'+esc(l.nom)+'</td><td>'+l.jours+'</td><td>'+ICO[l.statut]+' '+LIB[l.statut]+(l.raison&&l.statut!=='deja'?'<br><small>'+esc(l.raison)+'</small>':'')+'</td></tr>'}).join('')+'</tbody></table></div>'}
  else h+='<p class="exb-muted">Aucun pointage sur ce chantier.</p>';
  var cf=cfg();h+='<label style="display:flex;gap:8px;align-items:flex-start;margin:6px 0"><input type="checkbox" style="width:auto;flex:none;margin-top:3px"'+(cf.auto?' checked':'')+' onchange="EXBRO.setAuto(this.checked)"><span>Report automatique des <b>nouveaux</b> pointages (valides, avec fiche Personnel, sans doublon). Les pointages déjà enregistrés avant l\'activation et les cas douteux restent à reporter ici, à la main.</span></label>';
  h+='<div class="exb-actions" style="margin:6px 0">'+(c.a_reporter?'<button class="primary" onclick="EXBRO.reporter()">⬇ Reporter la sélection vers les RH</button>':'')+'</div>';
  var pr=actifs(L(KP)).filter(function(p){return sid(p.project_id)===sid(pid)});
  if(pr.length)h+='<details><summary>'+pr.length+' présence(s) reportée(s)</summary>'+pr.slice(-30).map(function(p){return '<div>'+esc(p.date)+' — '+esc(p.nom)+' ('+p.jours+' j) <button class="muted" onclick="EXBRO.annulerP(\''+esc(p.id)+'\')">Annuler</button></div>'}).join('')+'</details>';
  var stk=typeof exbStock!=='undefined'?exbStock:[];
  h+='<h3 style="margin:14px 0 6px">📦 Matériel → Stock (sortie vers le chantier)</h3>';
  h+=stk.length?'<div class="exb-actions" style="align-items:end"><div><label>Article</label><select id="exbro_it">'+stk.map(function(s){return '<option value="'+esc(s.id)+'">'+esc(s.name)+' ('+(+s.qty||0)+' '+esc(s.unit||'')+')</option>'}).join('')+'</select></div><div><label>Quantité</label><input id="exbro_q" type="number" step="any" min="0" style="width:90px"></div><button class="primary" onclick="EXBRO.sortie()">⬆ Sortir du stock</button></div>':'<p class="exb-muted">Aucun article en stock.</p>';
  var cs=consommation(L('exb_stock_moves'),stk,pid);
  if(cs.length)h+='<p class="exb-muted" style="margin:6px 0">Consommé sur ce chantier : '+cs.map(function(x){return '<b>'+x.qty+'</b> '+esc(x.unite)+' '+esc(x.nom)}).join(' ; ')+'.</p>';
  var so=(typeof exbStockMoves!=='undefined'?exbStockMoves:[]).filter(function(m){return m.source==='pm'&&m.type==='out'&&!m.annule&&sid(m.project_id)===sid(pid)});
  if(so.length)h+='<details><summary>'+so.length+' sortie(s) enregistrée(s)</summary>'+so.slice(-30).map(function(m){var it=stk.filter(function(s){return s.id===m.item})[0]||{};return '<div>'+esc(m.date)+' — '+m.qty+' '+esc(it.unit||'')+' '+esc(it.name||m.item)+' <button class="muted" onclick="EXBRO.annulerS(\''+esc(m.id)+'\')">Annuler</button></div>'}).join('')+'</details>';
  return h+'<p class="exb-muted">Rien n\'est écrit sans votre validation. Chaque report garde auteur, date, projet et peut être annulé avec un motif (la quantité de stock est alors rétablie).</p>'}
function rerender(){try{EXBPL.tab('r')}catch(e){}}
function refreshStock(){try{renderExbStock()}catch(e){}}
var A={view:view,
 pick:function(id,on){ST.sel[id]=!!on},
 setAuto:function(on){var c=cfg();c.auto=!!on;if(!Array.isArray(c.base))c.base=L('exb_timesheets').map(function(t){return t.id});save(KC,c);audit('report.rh.auto.reglage','exb_ro_cfg',{auto:!!on});say(on?'Report automatique activé.':'Report automatique désactivé.','info');rerender()},
 reporter:async function(){var ap=apercuPointages(L('exb_timesheets'),hrL(),L(KP),ST.pid),ids=ap.lignes.filter(function(l){return l.statut==='a_reporter'&&ST.sel[l.ts]!==false}).map(function(l){return l.ts});
  if(!ids.length)return say('Rien à reporter.','warn');if(!(await exbConfirm('Reporter '+ids.length+' pointage(s) vers les RH (présences) ?')))return;
  var r=reporterPointages(L(KP),ap,ids,{pid:ST.pid,par:who(),now:new Date().toISOString(),idf:function(){return idf('PR')}});save(KP,r.presences);audit('report.rh',ST.pid,{n:r.crees.length});ST.sel={};say(r.crees.length+' présence(s) reportée(s).','success');rerender()},
 annulerP:async function(id){var m=await exbPrompt('Motif de l\'annulation :','');if(m===null)return;var r=annulerPresence(L(KP),id,m,{par:who(),now:new Date().toISOString()});if(!r.ok)return say(r.error,'warn');save(KP,r.presences);audit('report.rh.annule',id,{});say('Report annulé.','success');rerender()},
 sortie:async function(){var it=document.getElementById('exbro_it'),q=document.getElementById('exbro_q');if(!it||!q)return;
  var nm=(exbStock.filter(function(s){return s.id===it.value})[0]||{}).name||'';if(!(await exbConfirm('Sortir '+q.value+' × '+nm+' du stock vers ce chantier ?')))return;
  var r=sortieMateriel(exbStock,exbStockMoves,{item:it.value,qty:q.value,pid:ST.pid,par:who(),date:new Date().toISOString(),id:idf('MV'),ref:'Chantier'});if(!r.ok)return say(r.error,'warn');
  exbStock=r.stock;exbStockMoves=r.moves;exbSave(EXB_ECO_KEYS.stock,exbStock);exbSave(EXB_ECO_KEYS.stockMoves,exbStockMoves);audit('report.stock',r.move.id,{projet:ST.pid,qty:r.move.qty});refreshStock();say('Sortie enregistrée.','success');rerender()},
 annulerS:async function(id){var m=await exbPrompt('Motif de l\'annulation :','');if(m===null)return;var r=annulerSortie(exbStock,exbStockMoves,id,m,{par:who(),now:new Date().toISOString(),idc:idf('MV')});if(!r.ok)return say(r.error,'warn');
  exbStock=r.stock;exbStockMoves=r.moves;exbSave(EXB_ECO_KEYS.stock,exbStock);exbSave(EXB_ECO_KEYS.stockMoves,exbStockMoves);audit('report.stock.annule',id,{});refreshStock();say('Sortie annulée, stock rétabli.','success');rerender()}};
root.EXBRO=Object.assign(API,A);
setTimeout(function(){baseline();hook()},1500);
})(typeof window!=='undefined'?window:globalThis);
