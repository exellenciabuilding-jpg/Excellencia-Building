/* Excellencia Building V176 — Comptabilité : PONT « bulletins de paie V81 → écritures » (option EXCLUSIVE avec la paie comptable V173, exb-compta-paie.js).
 * UNE SEULE SOURCE PAR SALAIRE : la paie V173 (onglet « 👥 Paie ») calcule ses propres bulletins depuis le Personnel ; ce pont comptabilise ceux du module Paie V81 (barème IPR progressif).
 *  Règle unique, appliquée à chaque écriture (donc valable dans tous les ordres de saisie) : un bulletin V81 n'est comptabilisé que si la paie V173 n'a PAS déjà validé ou payé
 *  ce même employé pour ce même mois. Mois mixtes (une partie des employés en V173, le reste en V81) : chacun est compté une seule fois. Si la paie V173 est validée après coup,
 *  le bulletin V81 correspondant, et ses règlements, sortent automatiquement du journal. Les sorties de caisse déjà portées par la paie V173 (paie_run) ne sont jamais proposées.
 * S'ajoute à exb-compta.js par ses points d'extension. Les bulletins (exb_payroll, module Paie V81) ne sont JAMAIS modifiés : aucun taux ni règle
 * sociale ou fiscale n'est recalculé ici — les montants (brut, INSS, IPR, INPP, ONEM, avances, net) sont ceux déjà figés sur chaque bulletin validé.
 *
 *  Écriture d'un bulletin « validé » ou « payé » (journal OD, à la fin du mois de la période, en USD — devise des salaires de la fiche Personnel) :
 *    débit  661  Salaires                       = brut
 *    débit  664  Charges sociales patronales    = INSS patronal + INPP + ONEM
 *    crédit 421  Personnel, rémunérations dues  = net à payer
 *    crédit 431  Organismes sociaux             = INSS salarié + INSS patronal + INPP + ONEM
 *    crédit 447  État, IPR retenu               = IPR
 *    crédit 425  Personnel, avances recouvrées  = avances remboursées par retenue
 *    crédit 428  Personnel, retenues diverses   = retenues diverses
 *  Équilibre garanti par la formule du bulletin (net = brut − INSS salarié − IPR − avances − retenues) ; un bulletin déséquilibré est écarté et signalé.
 *
 *  Règlements : le paiement du net n'écrit pas dans la caisse (module Paie). Deux façons, jamais mélangées pour un même paiement :
 *    - « Règlement direct » : débit 421 / crédit 571 (caisse) ou 521 (banque) ; à utiliser si rien n'a été saisi en caisse.
 *    - « Rapprocher une sortie de caisse » : la sortie existe déjà en caisse (donc déjà en charge 661/658) ; on la RECLASSE : débit 421 (ou 425 pour une avance) / crédit sa charge.
 *      Aucune heuristique : c'est vous qui choisissez la sortie ; une sortie ne peut être rapprochée qu'une fois.
 *
 *  Activation (désactivée par défaut) à partir d'un mois choisi : refusée si ce mois ou un mois postérieur est déjà clôturé, afin de ne pas changer l'empreinte
 *  d'un mois clôturé. Désactivée, ce module n'ajoute aucune écriture : les journaux et clôtures existants restent identiques.
 * À valider avec votre comptable : numéros de comptes (indicatifs SYSCOHADA), regroupement INSS/INPP/ONEM dans 431, traitement des avances (425 doit être débité
 * quand l'avance est versée : rapprochez cette sortie de caisse), absence d'écritures de provision pour congés.
 * Retrait : supprimer la balise <script src="exb-compta-paie.js"> (le registre exb_paie_reglements reste ; les écritures de paie disparaissent du journal). */
(function (w) {
  'use strict';
  var X = w.EXBCOMPTA && w.EXBCOMPTA._x; if (!X || w.EXBCOMPTA_PAIEV81) return;
  var d = w.document, RK = 'exb_paie_reglements', CFG = 'exb_compta_cfg', PK = 'exb_payroll', V173 = 'exb_paie_runs', r2 = X.r2, esc = X.esc, nf = X.nf, pn = X.pn, DATE = /^\d{4}-\d{2}-\d{2}$/, YM = /^\d{4}-\d{2}$/;
  X.ACC['421'] = 'Personnel, rémunérations dues'; X.ACC['425'] = 'Personnel, avances et acomptes'; X.ACC['428'] = 'Personnel, retenues diverses';
  X.ACC['431'] = 'Organismes sociaux (INSS, INPP, ONEM)'; X.ACC['447'] = 'État, IPR retenu sur salaires'; X.ACC['664'] = 'Charges sociales patronales';
  var CUR = 'USD';
  /* salaires déjà comptabilisés par la paie V173 (validée ou payée), par mois et par employé */
  function v173Cov() { var all = {}, emp = {}, a = []; try { a = X.LD(V173, []) || []; } catch (e) { a = []; } (Array.isArray(a) ? a : []).forEach(function (r) { if (!r || (r.status !== 'validée' && r.status !== 'payée') || !YM.test(r.ym || '')) return; if (!Array.isArray(r.lines) || !r.lines.length) { all[r.ym] = 1; return; } r.lines.forEach(function (l) { if (l && l.emp != null) emp[r.ym + '|' + l.emp] = 1; }); }); return { all: all, emp: emp }; }
  function covered(b, cv) { cv = cv || v173Cov(); return !!(cv.all[b.period] || cv.emp[b.period + '|' + b.emp]); }
  function v173Months() { var cv = v173Cov(), o = {}; Object.keys(cv.all).forEach(function (m) { o[m] = 1; }); Object.keys(cv.emp).forEach(function (k) { o[k.slice(0, 7)] = 1; }); return o; }

  /* ---------------- moteur pur ---------------- */
  function lastDay(ym) { var y = +ym.slice(0, 4), m = +ym.slice(5, 7); return ym + '-' + ('0' + new Date(Date.UTC(y, m, 0)).getUTCDate()).slice(-2); }
  /* lignes [compte, débit, crédit] d'un bulletin ; null si déséquilibré ou inexploitable */
  function bulletinLines(b) {
    var f = b && b.fin; if (!f) return null;
    var g = r2(+f.gross || 0), ie = r2(+f.inssE || 0), ip = r2(+f.inssP || 0), inpp = r2(+f.inpp || 0), onem = r2(+f.onem || 0), ipr = r2(+f.ipr || 0), av = r2(+f.avances || 0), rd = r2(+f.retDiv || 0), net = r2(+f.net || 0);
    if (!(g > 0) || net < 0) return null;
    var pat = r2(ip + inpp + onem), soc = r2(ie + pat);
    var L = [['661', g, 0], ['664', pat, 0], ['421', 0, net], ['431', 0, soc], ['447', 0, ipr], ['425', 0, av], ['428', 0, rd]], D = 0, C = 0;
    L.forEach(function (l) { D = r2(D + l[1]); C = r2(C + l[2]); });
    return Math.abs(D - C) < 0.015 ? L.filter(function (l) { return l[1] || l[2]; }) : null;
  }
  function cfg() { var c = X.LD(CFG, {}) || {}; var p = c.paiev81 || {}; return { on: !!p.on, from: YM.test(p.from || '') ? p.from : '' }; }
  function closedMonths() { var a = []; (X.LD(X.K.cl, []) || []).forEach(function (r) { if (r && r.ym && !r.reopened) a.push(r.ym); }); return a.sort(); }
  /* activation possible ? */
  function canActivate(from, closed) {
    if (!YM.test(from || '')) return { error: 'Choisissez le premier mois à comptabiliser (AAAA-MM).' };
    var bad = (closed || []).filter(function (m) { return m >= from; });
    if (bad.length) return { error: 'Le mois ' + bad[0] + ' est déjà clôturé : choisissez un mois postérieur au dernier mois clôturé (' + closed[closed.length - 1] + '), ou rouvrez les mois concernés.' };
    return { ok: true };
  }
  function bulletins() { var a = []; try { a = (w.EXBS && w.EXBS.get && w.EXBS.get(PK)) || X.LD(PK, []) || []; } catch (e) { a = []; } if (!Array.isArray(a)) a = []; return a.filter(function (b) { return b && b.type === 'bulletin' && (b.status === 'validé' || b.status === 'payé') && YM.test(b.period || ''); }); }
  function regs() { return (X.LD(RK, []) || []).filter(function (r) { return r && r.id; }); }
  function cashList() { var a = []; try { a = (typeof w.exbCash !== 'undefined' && Array.isArray(w.exbCash)) ? w.exbCash : (X.LD('exb_cash', []) || []); } catch (e) { a = []; } return a.filter(function (x) { return x && x.type !== 'in' && !x.invoice_id && !x.pay_id && !x.paie_run && (+x.amount || 0) > 0 && DATE.test(String(x.date || '').slice(0, 10)); }); }
  function cashById(id) { return cashList().filter(function (x) { return String(x.id) === String(id); })[0]; }

  X.XT.entryFns.push(function (add) {
    var c = cfg(); if (!c.on || !c.from) return;
    var cv = v173Cov(), dropped = {};
    bulletins().forEach(function (b) {
      if (covered(b, cv)) dropped[b.id] = 1;
      if (b.period < c.from || covered(b, cv)) return; var L = bulletinLines(b); if (!L) return;
      add(lastDay(b.period), 'OD', 'PAIE-' + b.period + '-' + String(b.id).slice(-6), 'Paie ' + b.period + ' — ' + (b.name || b.emp || ''), CUR, L);
    });
    regs().forEach(function (r) {
      if (r.status === 'annulé' || !(r.amount > 0) || !DATE.test(r.date || '') || r.date.slice(0, 7) < c.from) return;
      if (r.bulletinId && dropped[r.bulletinId]) return; /* bulletin désormais comptabilisé par la paie V173 */
      var debit = r.kind === 'avance' ? '425' : '421';
      if (r.cashId) { var x = cashById(r.cashId); if (!x) return; add(r.date, 'OD', 'RAPPR-' + String(r.id).slice(-6), 'Rapprochement caisse — ' + (r.name || ''), CUR, [[debit, r.amount, 0], [X.depAcc(x.label, x.cat), 0, r.amount]]); }
      else add(r.date, 'OD', 'REGL-' + String(r.id).slice(-6), 'Règlement paie — ' + (r.name || ''), CUR, [[debit, r.amount, 0], [r.acc === '521' ? '521' : '571', 0, r.amount]]);
    });
  });

  /* ---------------- actions ---------------- */
  function setPaie(on, from) {
    if (!X.can('factures', 'ecrire')) return { error: 'Droits insuffisants.' };
    var c = X.LD(CFG, {}) || {};
    if (on) { var v = canActivate(from, closedMonths()); if (v.error) return v; c.paiev81 = { on: true, from: from }; } else c.paiev81 = { on: false, from: (c.paiev81 && c.paiev81.from) || '' };
    c.paiev81By = X.who(); c.paiev81At = new Date().toISOString();
    if (!X.SV(CFG, c)) return { error: 'Enregistrement impossible.' }; X.audit('compta.paiev81.' + (on ? 'active' : 'desactive'), 'paie', { depuis: from || '' }); return { ok: true };
  }
  function netDue(b) { var f = b.fin || {}; return r2(+f.net || 0); }
  function reglé(bid) { return regs().filter(function (r) { return r.bulletinId === bid && r.status !== 'annulé' && r.kind !== 'avance'; }).reduce(function (a, r) { return r2(a + r.amount); }, 0); }
  function addReg(o) {
    if (!X.can('factures', 'ecrire')) return { error: 'Droits insuffisants.' };
    var c = cfg(); if (!c.on) return { error: 'Activez d’abord les écritures de paie.' };
    o = o || {}; var date = String(o.date || '').slice(0, 10), kind = o.kind === 'avance' ? 'avance' : 'net', b = bulletins().filter(function (x) { return x.id === o.bulletinId; })[0], amt = r2(pn(o.amount));
    if (!DATE.test(date)) return { error: 'Date invalide (AAAA-MM-JJ).' };
    if (date.slice(0, 7) < c.from) return { error: 'La date est antérieure au premier mois comptabilisé (' + c.from + ').' };
    if (closedMonths().indexOf(date.slice(0, 7)) >= 0) return { error: 'Le mois ' + date.slice(0, 7) + ' est clôturé.' };
    if (!b && kind === 'net') return { error: 'Bulletin introuvable (validé ou payé).' };
    if (b && covered(b)) return { error: 'Ce salaire est déjà comptabilisé par la paie V173 pour ce mois : réglez-le depuis l’onglet 👥 Paie.' };
    if (kind === 'avance' && !String(o.name || '').trim()) return { error: 'Indiquez le nom de l’employé.' };
    if (!(amt > 0)) return { error: 'Montant invalide.' };
    var cashId = o.cashId ? String(o.cashId) : '';
    if (cashId) {
      var x = cashById(cashId); if (!x) return { error: 'Sortie de caisse introuvable.' };
      if (regs().some(function (r) { return r.cashId === cashId && r.status !== 'annulé'; })) return { error: 'Cette sortie de caisse est déjà rapprochée.' };
      if (r2(+x.amount) !== amt) return { error: 'Le montant doit être celui de la sortie de caisse (' + nf(+x.amount) + ').' };
      if (String(x.date).slice(0, 10) !== date) return { error: 'La date doit être celle de la sortie de caisse (' + String(x.date).slice(0, 10) + ').' };
    }
    if (kind === 'net' && b) { var reste = r2(netDue(b) - reglé(b.id)); if (amt > reste + 0.005) return { error: 'Le règlement (' + nf(amt) + ') dépasse le reste à payer (' + nf(reste) + ').' }; }
    var r = { id: X.uid('RGP'), bulletinId: b ? b.id : '', name: b ? (b.name || b.emp) : String(o.name || '').trim(), kind: kind, date: date, amount: amt, acc: o.acc === '521' ? '521' : '571', cashId: cashId, status: 'actif', by: X.who(), at: new Date().toISOString() };
    var a = regs(); a.push(r); if (!X.SV(RK, a)) return { error: 'Enregistrement impossible.' };
    X.audit('compta.paiev81.reglement', r.name, { montant: amt, mode: cashId ? 'rapprochement' : r.acc, genre: kind }); return { rec: r };
  }
  function cancelReg(id, why) {
    if (!X.can('factures', 'ecrire')) return { error: 'Droits insuffisants.' };
    if (String(why || '').trim().length < 3) return { error: 'Le motif d’annulation est obligatoire.' };
    var a = regs(), r = a.filter(function (x) { return x.id === id; })[0]; if (!r || r.status === 'annulé') return { error: 'Règlement introuvable ou déjà annulé.' };
    if (closedMonths().indexOf(r.date.slice(0, 7)) >= 0) return { error: 'Le mois ' + r.date.slice(0, 7) + ' est clôturé : rouvrez-le d’abord.' };
    r.status = 'annulé'; r.cancelReason = String(why).trim(); r.cancelBy = X.who(); r.cancelAt = new Date().toISOString();
    if (!X.SV(RK, a)) return { error: 'Enregistrement impossible.' }; X.audit('compta.paiev81.reglement_annule', r.name, { motif: r.cancelReason }); return { ok: true };
  }
  /* situation : par bulletin comptabilisé, net dû / réglé / reste ; bulletins écartés ; sorties de caisse candidates */
  function etat() {
    var c = cfg(), rows = [], skipped = [];
    var cv = v173Cov(); bulletins().forEach(function (b) { if (b.period < c.from || covered(b, cv)) return; if (!bulletinLines(b)) { skipped.push(b); return; } var nd = netDue(b), rg = reglé(b.id); rows.push({ b: b, net: nd, paye: rg, reste: r2(nd - rg) }); });
    var linked = {}; regs().forEach(function (r) { if (r.cashId && r.status !== 'annulé') linked[r.cashId] = 1; });
    var cands = cashList().filter(function (x) { return !linked[String(x.id)] && String(x.date).slice(0, 7) >= c.from && /salaire|paie|avance|acompte|main.?d.?oeuvre|ouvrier|journalier/.test(X.norm((x.label || '') + ' ' + (x.cat || ''))); });
    return { cfg: c, rows: rows, skipped: skipped, cands: cands };
  }

  /* V177 : état de paie PDF de marque (bulletins comptabilisés + règlements) */
  function rapportHtml() {
    var E = etat(), nfx = X.nf, tt = { g: 0, n: 0, p: 0, r: 0 };
    var rows = E.rows.map(function (r) { tt.g = r2(tt.g + r.b.fin.gross); tt.n = r2(tt.n + r.net); tt.p = r2(tt.p + r.paye); tt.r = r2(tt.r + r.reste); return '<tr><td>' + esc(r.b.period) + '</td><td>' + esc(r.b.name || r.b.emp) + '</td><td class="r">' + nfx(r.b.fin.gross) + '</td><td class="r">' + nfx(r.net) + '</td><td class="r">' + nfx(r.paye) + '</td><td class="r">' + nfx(r.reste) + '</td></tr>'; });
    var h = '<h2>Bulletins comptabilisés (USD)</h2>' + (rows.length ? '<table><tr><th>Période</th><th>Employé</th><th class="r">Brut</th><th class="r">Net dû</th><th class="r">Réglé</th><th class="r">Reste</th></tr>' + rows.join('') + '<tr><td colspan="2"><b>Total</b></td><td class="r"><b>' + nfx(tt.g) + '</b></td><td class="r"><b>' + nfx(tt.n) + '</b></td><td class="r"><b>' + nfx(tt.p) + '</b></td><td class="r"><b>' + nfx(tt.r) + '</b></td></tr></table>' : '<p>Aucun bulletin.</p>');
    var rg = regs().filter(function (r) { return r.status !== 'annulé'; }).map(function (r) { return '<tr><td>' + esc(r.date) + '</td><td>' + esc(r.name) + '</td><td>' + (r.kind === 'avance' ? 'avance' : 'net') + '</td><td>' + (r.cashId ? 'rapprochement caisse' : (r.acc === '521' ? 'banque' : 'caisse')) + '</td><td class="r">' + nfx(r.amount) + '</td></tr>'; });
    h += '<h2>Règlements enregistrés</h2>' + (rg.length ? '<table><tr><th>Date</th><th>Employé</th><th>Nature</th><th>Mode</th><th class="r">Montant</th></tr>' + rg.join('') + '</table>' : '<p>Aucun.</p>');
    return { html: h, meta: [['Comptabilisé depuis', E.cfg.from || '—'], ['Bulletins', E.rows.length]] };
  }
  function pdfRapport() {
    if (!w.EXBRapport) { X.say('Module d’export PDF indisponible.', 'error'); return null; }
    var R = rapportHtml(); X.audit('paie_v81.export', 'pdf', {});
    return w.EXBRapport.print('État de paie — bulletins V81', { sousTitre: 'Situation au ' + X.today(), meta: R.meta, html: R.html, note: 'Comptes indicatifs, à valider avec le comptable. Montants en USD.' });
  }

  /* ---------------- interface ---------------- */
  var S = X.S;
  function tabPaie() {
    var E = etat(), c = E.cfg, closed = closedMonths(), h = '';
    h += '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Écritures de paie</b> ' + (c.on ? '<span style="background:#e6f6ea;padding:2px 6px;border-radius:6px">actives depuis ' + esc(c.from) + '</span>' : '<span style="background:#fff7e6;padding:2px 6px;border-radius:6px">désactivées</span>') +
      '<p style="font-size:12px;color:#64748b;margin:4px 0">Chaque bulletin validé ou payé devient une écriture (charge, personnel, organismes sociaux, IPR). Les bulletins ne sont pas modifiés ; aucun taux n’est recalculé. ' + (closed.length ? 'Dernier mois clôturé : ' + esc(closed[closed.length - 1]) + '.' : '') + '</p>' +
      (c.on ? '<p>' + X.btn('pa_off', 'Désactiver') + '</p>' : '<p>À partir du mois ' + X.inp('pa_from', '', 'AAAA-MM', 'width:90px') + ' ' + X.btn('pa_on', 'Activer') + '</p>') + '</div>';
    var n73 = Object.keys(v173Months()).sort(); if (n73.length) h += '<div style="background:#fff7e6;border-radius:8px;padding:8px;margin:6px 0">ℹ La paie V173 (onglet 👥 Paie) a déjà validé des salaires pour ' + esc(n73.join(', ')) + ' : ces salaires ne sont pas comptabilisés une seconde fois ici (règle : un employé, un mois, une seule source).</div>';
    if (!c.on) return h + '<p style="color:#64748b">Désactivé : le journal, la balance et les clôtures restent exactement ceux de la V175.</p>';
    if (E.skipped.length) h += '<div style="background:#fde8e8;border-radius:8px;padding:8px;margin:6px 0">⛔ ' + E.skipped.length + ' bulletin(s) écarté(s) car déséquilibré(s) ou sans montants figés : ' + E.skipped.map(function (b) { return esc((b.name || b.emp) + ' ' + b.period); }).join(', ') + '</div>';
    if (S.form && S.form.type === 'pa_reg') {
      var o = S.form, row = E.rows.filter(function (r) { return r.b.id === o.bid; })[0], cs = E.cands;
      h += '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Règlement — ' + esc(row ? (row.b.name || row.b.emp) + ' ' + row.b.period : '') + '</b><p style="font-size:12px;color:#64748b;margin:4px 0">Reste à payer : ' + nf(row ? row.reste : 0) + ' USD. Choisissez « rapprocher » si le paiement est déjà saisi en caisse ; sinon « direct ».</p>' +
        '<p><label><input type="radio" name="pa_m" value="direct" checked> Règlement direct</label> Date ' + X.inp('pa_d', X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Montant ' + X.inp('pa_a', row ? row.reste : '', '0.00', 'width:100px') + ' <select id="pa_k" style="padding:5px"><option value="571">Caisse</option><option value="521">Banque / mobile money</option></select></p>' +
        '<p><label><input type="radio" name="pa_m" value="rappr"> Rapprocher une sortie de caisse</label> <select id="pa_c" style="padding:5px;max-width:100%"><option value="">— choisir —</option>' + cs.map(function (x) { return '<option value="' + esc(x.id) + '">' + esc(String(x.date).slice(0, 10) + ' · ' + nf(+x.amount) + ' · ' + (x.label || '')) + '</option>'; }).join('') + '</select></p>' +
        '<p>' + X.btn('pa_ok', 'Enregistrer') + X.btn('pa_no', 'Retour') + '</p></div>';
    }
    if (S.form && S.form.type === 'pa_x') h += '<div style="border:1px solid #fca5a5;border-radius:8px;padding:10px;margin:8px 0"><b>Annuler ce règlement</b><p>' + X.inp('pa_why', '', 'Motif obligatoire', 'width:100%') + '</p>' + X.btn('pa_xok', 'Confirmer') + X.btn('pa_xno', 'Retour') + '</div>';
    var rows = E.rows.map(function (r) { return '<tr>' + X.td(esc(r.b.period)) + X.td(esc(r.b.name || r.b.emp)) + X.td(nf(r.b.fin.gross), 'right') + X.td(nf(r.net), 'right') + X.td(nf(r.paye), 'right') + X.td(r.reste > 0.005 ? '<b>' + nf(r.reste) + '</b>' : '✔', 'right') + X.td(r.reste > 0.005 ? '<button type="button" class="pa_r" data-id="' + esc(r.b.id) + '" style="padding:3px 8px">Régler</button>' : '') + '</tr>'; });
    h += rows.length ? X.table(['Période', 'Employé', 'Brut', 'Net dû', 'Réglé', 'Reste', ''], rows) : '<p style="color:#64748b">Aucun bulletin validé ou payé à partir de ' + esc(c.from) + '.</p>';
    var rg = regs().slice().reverse().map(function (r) { return '<tr>' + X.td(esc(r.date)) + X.td(esc(r.name)) + X.td(r.kind === 'avance' ? 'avance' : 'net') + X.td(r.cashId ? 'rapprochement caisse' : (r.acc === '521' ? 'banque' : 'caisse')) + X.td(nf(r.amount), 'right') + X.td(r.status === 'annulé' ? '<span style="color:#94a3b8">annulé (' + esc(r.cancelReason) + ')</span>' : '<button type="button" class="pa_x" data-id="' + esc(r.id) + '" style="padding:3px 8px">Annuler</button>') + '</tr>'; });
    if (rg.length) h += '<h4>Règlements enregistrés</h4>' + X.table(['Date', 'Employé', 'Nature', 'Mode', 'Montant', ''], rg);
    if (E.cands.length) h += '<p style="font-size:12px;background:#fff7e6;padding:6px;border-radius:6px">ℹ ' + E.cands.length + ' sortie(s) de caisse ressemblent à des paiements de salaire et ne sont pas rapprochées : elles restent en charge 661/658. Si elles règlent un bulletin, rapprochez-les (« Régler ») pour éviter de compter la charge deux fois.</p>';
    if (S.form && S.form.type === 'pa_adv') h += '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Avance sur salaire versée</b><p style="font-size:12px;color:#64748b;margin:4px 0">Débite 425 « avances et acomptes » : à faire pour que les avances retenues sur les bulletins se soldent. Sortie déjà saisie en caisse : rapprochez-la ; sinon règlement direct.</p><p>Employé ' + X.inp('pa_an', '', 'Nom', 'width:160px') + '</p><p><label><input type="radio" name="pa_am" value="direct" checked> Direct</label> Date ' + X.inp('pa_ad', X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Montant ' + X.inp('pa_aa', '', '0.00', 'width:100px') + ' <select id="pa_ak" style="padding:5px"><option value="571">Caisse</option><option value="521">Banque / mobile money</option></select></p><p><label><input type="radio" name="pa_am" value="rappr"> Rapprocher une sortie de caisse</label> <select id="pa_ac" style="padding:5px;max-width:100%"><option value="">— choisir —</option>' + E.cands.map(function (x) { return '<option value="' + esc(x.id) + '">' + esc(String(x.date).slice(0, 10) + ' · ' + nf(+x.amount) + ' · ' + (x.label || '')) + '</option>'; }).join('') + '</select></p><p>' + X.btn('pa_aok', 'Enregistrer') + X.btn('pa_ano', 'Retour') + '</p></div>';
    h += '<p>' + X.btn('pa_adv', '＋ Avance versée') + X.btn('pa_pdf', '🖨 État de paie PDF') + '</p>';
    return h + '<p style="font-size:12px;color:#64748b">Comptes indicatifs, à valider avec votre comptable (INSS, INPP et ONEM regroupés en 431 ; pas de provision de congés). Les écritures d’un mois déjà clôturé seraient détectées par la clôture comme « modifié ».</p>';
  }
  X.XT.tabs.push({ id: 'paiev81', label: '💰 Paie V81', html: tabPaie });
  X.XT.bind.push(function (o) {
    var q = function (id) { return d.getElementById(id); }, redo = function () { X.render(); };
    X.on('pa_on', function () { var r = setPaie(true, (q('pa_from') || {}).value); S.msg = r.error || 'Écritures de paie activées.'; redo(); });
    X.on('pa_off', function () { var r = setPaie(false); S.msg = r.error || 'Écritures de paie désactivées.'; redo(); });
    Array.prototype.forEach.call(o.querySelectorAll('.pa_r'), function (b) { b.onclick = function () { S.form = { type: 'pa_reg', bid: b.getAttribute('data-id') }; redo(); }; });
    Array.prototype.forEach.call(o.querySelectorAll('.pa_x'), function (b) { b.onclick = function () { S.form = { type: 'pa_x', id: b.getAttribute('data-id') }; redo(); }; });
    X.on('pa_no', function () { S.form = null; redo(); }); X.on('pa_xno', function () { S.form = null; redo(); });
    X.on('pa_ok', function () {
      var m = (o.querySelector('input[name="pa_m"]:checked') || {}).value, bid = S.form.bid, r;
      if (m === 'rappr') { var x = cashById((q('pa_c') || {}).value); r = x ? addReg({ bulletinId: bid, date: String(x.date).slice(0, 10), amount: +x.amount, cashId: x.id }) : { error: 'Choisissez la sortie de caisse.' }; }
      else r = addReg({ bulletinId: bid, date: q('pa_d').value, amount: q('pa_a').value, acc: q('pa_k').value });
      S.msg = r.error || 'Règlement enregistré.'; if (!r.error) S.form = null; redo();
    });
    X.on('pa_pdf', function () { try { pdfRapport(); } catch (e) { X.say('Export PDF impossible.', 'error'); } });
    X.on('pa_adv', function () { S.form = { type: 'pa_adv' }; redo(); }); X.on('pa_ano', function () { S.form = null; redo(); });
    X.on('pa_aok', function () {
      var m = (o.querySelector('input[name="pa_am"]:checked') || {}).value, nm = (q('pa_an') || {}).value, r;
      if (m === 'rappr') { var x = cashById((q('pa_ac') || {}).value); r = x ? addReg({ kind: 'avance', name: nm, date: String(x.date).slice(0, 10), amount: +x.amount, cashId: x.id }) : { error: 'Choisissez la sortie de caisse.' }; }
      else r = addReg({ kind: 'avance', name: nm, date: q('pa_ad').value, amount: q('pa_aa').value, acc: q('pa_ak').value });
      S.msg = r.error || 'Avance enregistrée.'; if (!r.error) S.form = null; redo();
    });
    X.on('pa_xok', function () { var r = cancelReg(S.form.id, (q('pa_why') || {}).value); S.msg = r.error || 'Règlement annulé.'; if (!r.error) S.form = null; redo(); });
  });
  w.EXBCOMPTA_PAIEV81 = { version: 1, setPaie: setPaie, addReg: addReg, cancelReg: cancelReg, etat: etat, cfg: cfg, _t: { bulletinLines: bulletinLines, lastDay: lastDay, canActivate: canActivate, v173Months: v173Months } };
})(typeof window !== 'undefined' ? window : globalThis);
