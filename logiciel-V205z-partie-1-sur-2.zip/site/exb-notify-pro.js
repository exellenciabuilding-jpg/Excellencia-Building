/* Excellencia Building — Notifications professionnelles (V120l)
 * Même principe que « Excellencia Chantier » :
 *   • Toasts en haut à droite : carte claire, barre de couleur à gauche, icône carrée, titre + détail, bouton de fermeture,
 *     barre de temps (pause au survol).  VERT = réussi · JAUNE = attention · ROUGE = échec · BLEU = information.
 *   • Fichier généré (PDF, Word, Excel, image…) : notification « PDF généré » + nom du fichier, automatiquement,
 *     pour tout téléchargement lancé par le logiciel. Si la génération échoue : jaune (avertissement) ou rouge (échec).
 *   • Cloche 🔔 : elle sonne à chaque notification et au retour de la connexion ; le badge se met à jour tout de suite ;
 *     un clic ouvre la liste des dernières notifications (lien vers l'historique complet).
 *   • Connexion : pastille « Hors connexion · Dernière synchronisation hh:mm » à côté de la cloche ;
 *     au retour du réseau : notification verte « Connexion rétablie » + cloche qui sonne.
 * API : EXB_NOTIFY.show(msg,type,ms) · EXB_NOTIFY.file({kind,name,ok,error,warn}) · EXB_NOTIFY.ring()
 * Aucune donnée existante n'est modifiée. Retrait : supprimer la balise <script src="exb-notify-pro.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_NOTIFY) return;
  var $ = function (i) { return d.getElementById(i); };
  var K_SYNC = 'exb_last_sync';
  function lget(k, df) { try { var v = w.localStorage.getItem(k); return v == null ? df : v; } catch (e) { return df; } }
  function lset(k, v) { try { w.localStorage.setItem(k, v); } catch (e) {} }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmm(t) { var x = new Date(t); return pad(x.getHours()) + ':' + pad(x.getMinutes()); }

  /* ---------- 1. Titre + détail à partir d'un message ---------- */
  var DONE = 'généré|générée|générés|générées|exporté|exportée|exportés|exportées|téléchargé|téléchargée|téléchargés|téléchargées|partagé|partagée|enregistré|enregistrée|créé|créée|importé|importée|envoyé|envoyée|supprimé|supprimée|copié|copiée|sauvegardé|sauvegardée|restauré|restaurée|imprimé|imprimée|ajouté|ajoutée|mis à jour|mise à jour|validé|validée|publié|publiée';
  var RE_DONE = new RegExp('^(.{2,52}?\\s(?:' + DONE + '))(?:\\s+avec succès)?(?:\\s*[:—–-]\\s*|\\s*\\.\\s*|\\s+)(.*)$', 'i');
  function cap(s) { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); }
  function parse(msg, type) {
    var m = String(msg == null ? '' : msg).replace(/^[\s✓✔✅⚠️❌❗ℹ️]+/, '').trim(), r, title = '', detail = m;
    if (type === 'success' || type === 'info') {
      r = RE_DONE.exec(m);
      if (r) { title = r[1]; detail = (r[2] || '').trim(); }
    } else {
      r = /^([^:«»]{3,52}?)\s*:\s+(.+)$/.exec(m);
      if (r) { title = r[1]; detail = r[2].trim(); }
    }
    if (!title) {
      if (type === 'error') title = /pdf|génér|export|fichier|word|excel/i.test(m) ? 'Génération impossible' : 'Une action a échoué';
      else if (type === 'warn') title = 'Attention';
      else if (type === 'success') title = 'Terminé';
      else title = 'Information';
      if (m.length <= 34 && type !== 'error' && type !== 'warn') { title = m.replace(/[.!]+$/, ''); detail = ''; }
    }
    return { title: cap(title), detail: detail };
  }

  /* ---------- 2. Icônes ---------- */
  var IC = {
    success: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    warn: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v8"/><circle cx="12" cy="18" r=".6" fill="currentColor"/></svg>',
    error: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></svg>',
    info: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 11v6"/><circle cx="12" cy="7" r=".6" fill="currentColor"/></svg>'
  };

  /* ---------- 3. Style ---------- */
  function css() {
    if ($('exbNotifyCss')) return;
    var s = d.createElement('style'); s.id = 'exbNotifyCss';
    s.textContent =
      '#toastBox.exb-nt{position:fixed!important;top:74px!important;right:16px!important;bottom:auto!important;left:auto;z-index:99999;display:flex;flex-direction:column;gap:10px;width:min(400px,calc(100vw - 24px));max-width:none;pointer-events:none}' +
      '.exb-nt .xnt{--c:#1fa44a;--bg:#eef8f0;--fg:#12254a;--mu:#4a5a78;position:relative;display:flex;align-items:flex-start;gap:12px;padding:13px 12px 15px 14px;border-radius:14px;background:var(--bg);color:var(--fg);border:1px solid color-mix(in srgb,var(--c) 28%,transparent);border-left:6px solid var(--c);box-shadow:0 12px 30px #0f2e6638,0 2px 6px #0f2e661f;font:14px/1.4 Arial,Helvetica,sans-serif;pointer-events:auto;overflow:hidden;animation:xntIn .26s cubic-bezier(.2,.9,.3,1.1)}' +
      '.exb-nt .xnt.success{--c:#1fa44a;--bg:#eef8f0}.exb-nt .xnt.warn{--c:#f0a800;--bg:#fff8e1}.exb-nt .xnt.error{--c:#d93025;--bg:#fdeeec}.exb-nt .xnt.info{--c:#1f6feb;--bg:#eaf2fe}' +
      '.exb-nt .xnt.out{animation:xntOut .2s ease-in forwards}' +
      '.exb-nt .xnt-ic{flex:none;width:34px;height:34px;border-radius:9px;background:var(--c);color:#fff;display:grid;place-items:center;box-shadow:0 2px 6px color-mix(in srgb,var(--c) 45%,transparent)}' +
      '.exb-nt .xnt.warn .xnt-ic{color:#3a2a00}' +
      '.exb-nt .xnt-b{flex:1;min-width:0;padding-top:1px}.exb-nt .xnt-b b{display:block;font-size:15px;font-weight:700;line-height:1.25;color:var(--fg);margin:0}' +
      '.exb-nt .xnt-b span{display:block;margin-top:2px;color:var(--mu);font-size:13.5px;word-break:break-word;overflow-wrap:anywhere}' +
      '.exb-nt .xnt-n{display:inline-block;margin-left:6px;padding:0 7px;border-radius:9px;background:var(--c);color:#fff;font:700 11px/18px Arial;vertical-align:2px}.exb-nt .xnt.warn .xnt-n{color:#3a2a00}' +
      '.exb-nt .xnt-x{flex:none;background:transparent;border:0;color:var(--mu);width:28px;height:28px;margin:-3px -2px 0 0;border-radius:8px;font-size:20px;line-height:1;cursor:pointer;display:grid;place-items:center;padding:0}.exb-nt .xnt-x:hover{background:#0f2e6614;color:var(--fg)}' +
      '.exb-nt .xnt-x:focus-visible{outline:2px solid var(--c);outline-offset:1px}' +
      '.exb-nt .xnt-bar{position:absolute;left:0;right:0;bottom:0;height:3px;background:var(--c);opacity:.55;transform-origin:left;animation:xntBar linear forwards}' +
      '@keyframes xntIn{from{transform:translateX(26px);opacity:0}to{transform:none;opacity:1}}' +
      '@keyframes xntOut{to{transform:translateX(30px);opacity:0}}' +
      '@keyframes xntBar{from{transform:scaleX(1)}to{transform:scaleX(0)}}' +
      'html[data-exb-theme="dark"] .exb-nt .xnt{--fg:#eaf0ff;--mu:#aebbd8;box-shadow:0 12px 30px #000a}' +
      'html[data-exb-theme="dark"] .exb-nt .xnt.success{--bg:#11301d}html[data-exb-theme="dark"] .exb-nt .xnt.warn{--bg:#382d0a}html[data-exb-theme="dark"] .exb-nt .xnt.error{--bg:#3a1614}html[data-exb-theme="dark"] .exb-nt .xnt.info{--bg:#10294f}' +
      'html[data-exb-theme="dark"] .exb-nt .xnt-x:hover{background:#ffffff1c}' +
      '@media(max-width:700px){#toastBox.exb-nt{top:64px!important;right:10px!important;width:calc(100vw - 20px)}}' +
      '@media(prefers-reduced-motion:reduce){.exb-nt .xnt,.exb-nt .xnt.out{animation:none}}' +
      '@media print{#toastBox{display:none}}' +
      /* cloche */
      '#xbBell.exb-ring{animation:xntRing 1.2s ease-in-out}#xbBell.exb-ring i{animation:xntPop .5s ease-out}' +
      '@keyframes xntRing{0%{transform:rotate(0)}8%{transform:rotate(18deg)}16%{transform:rotate(-16deg)}24%{transform:rotate(13deg)}32%{transform:rotate(-11deg)}40%{transform:rotate(8deg)}48%{transform:rotate(-6deg)}58%{transform:rotate(3deg)}70%,100%{transform:rotate(0)}}' +
      '@keyframes xntPop{0%{transform:scale(.4)}60%{transform:scale(1.35)}100%{transform:scale(1)}}' +
      '#xbBell{transform-origin:50% 12%}' +
      /* pastille connexion */
      '#exbNetChip{display:none;align-items:center;gap:8px;max-width:210px;padding:4px 10px;border-radius:10px;background:#ffffff14;border:1px solid #ffffff2e;color:#fff;font:600 12px/1.2 Arial;white-space:nowrap}' +
      '#exbNetChip.off{display:flex}#exbNetChip i{flex:none;width:9px;height:9px;border-radius:50%;background:#ff4d45;box-shadow:0 0 0 3px #ff4d4533}' +
      '#exbNetChip small{display:block;font-size:10.5px;font-weight:400;opacity:.8}#exbNetChip span{overflow:hidden;text-overflow:ellipsis}' +
      '@media(max-width:900px){#exbNetChip small{display:none}#exbNetChip{padding:6px 9px}}' +
      '@media print{#exbNetChip,#exbNtPop{display:none!important}}' +
      /* fenêtre de la cloche */
      '#exbNtPop{position:fixed;z-index:99990;top:64px;right:70px;width:min(380px,calc(100vw - 20px));max-height:min(520px,calc(100vh - 90px));display:none;flex-direction:column;background:#fff;color:#12254a;border:1px solid #dfe6f3;border-radius:16px;box-shadow:0 18px 44px #0f2e664d;font:14px/1.4 Arial,Helvetica,sans-serif;overflow:hidden}' +
      '#exbNtPop.on{display:flex;animation:xntIn .18s ease-out}' +
      '#exbNtPop .np-h{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 16px;border-bottom:1px solid #e8edf6}#exbNtPop .np-h b{font-size:16px}' +
      '#exbNtPop .np-h button,#exbNtPop .np-f button{border:0;background:none;color:#1f6feb;font:700 12.5px Arial;cursor:pointer;padding:6px 8px;border-radius:8px}#exbNtPop .np-h button:hover,#exbNtPop .np-f button:hover{background:#e8f0fe}' +
      '#exbNtPop .np-l{overflow:auto;flex:1}' +
      '#exbNtPop .np-r{display:flex;gap:11px;align-items:flex-start;padding:11px 16px;border-bottom:1px solid #f0f3f9}#exbNtPop .np-r.new{background:#f3f8ff}' +
      '#exbNtPop .np-d{flex:none;width:30px;height:30px;border-radius:8px;display:grid;place-items:center;color:#fff;margin-top:1px}#exbNtPop .np-d svg{width:15px;height:15px}' +
      '#exbNtPop .np-d.success{background:#1fa44a}#exbNtPop .np-d.warn{background:#f0a800;color:#3a2a00}#exbNtPop .np-d.error{background:#d93025}#exbNtPop .np-d.info{background:#1f6feb}' +
      '#exbNtPop .np-t{min-width:0;flex:1}#exbNtPop .np-t b{display:block;font-size:13.5px}#exbNtPop .np-t span{display:block;color:#51617f;font-size:12.5px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}#exbNtPop .np-t small{color:#8190ac;font-size:11.5px}' +
      '#exbNtPop .np-e{padding:26px 16px;text-align:center;color:#6b7a99}' +
      '#exbNtPop .np-f{border-top:1px solid #e8edf6;padding:6px 10px;text-align:center}' +
      'html[data-exb-theme="dark"] #exbNtPop{background:#14213f;color:#eaf0ff;border-color:#ffffff22}' +
      'html[data-exb-theme="dark"] #exbNtPop .np-h,html[data-exb-theme="dark"] #exbNtPop .np-f,html[data-exb-theme="dark"] #exbNtPop .np-r{border-color:#ffffff1c}' +
      'html[data-exb-theme="dark"] #exbNtPop .np-r.new{background:#1a2c52}html[data-exb-theme="dark"] #exbNtPop .np-t span{color:#aebbd8}html[data-exb-theme="dark"] #exbNtPop .np-t small{color:#8d9bbb}' +
      'html[data-exb-theme="dark"] #exbNtPop .np-h button:hover,html[data-exb-theme="dark"] #exbNtPop .np-f button:hover{background:#ffffff14}' +
      '@media(max-width:700px){#exbNtPop{right:10px;top:58px}}';
    d.head.appendChild(s);
  }

  /* ---------- 4. Cloche ---------- */
  function ring() {
    var b = $('xbBell'); if (!b) return;
    b.classList.remove('exb-ring'); void b.offsetWidth; b.classList.add('exb-ring');
    setTimeout(function () { try { b.classList.remove('exb-ring'); } catch (e) {} }, 1400);
  }
  function badge() { try { if (w.EXB_SHELL && w.EXB_SHELL.updateBadge) w.EXB_SHELL.updateBadge(); } catch (e) {} }

  /* ---------- 5. Toasts ---------- */
  var lastAt = 0, autoToast = null;
  function box() {
    var b = $('toastBox');
    if (!b) { b = d.createElement('div'); b.id = 'toastBox'; b.setAttribute('role', 'status'); b.setAttribute('aria-live', 'polite'); d.body.appendChild(b); }
    b.classList.add('exb-nt'); return b;
  }
  function close(t) {
    if (!t || t._gone) return; t._gone = true; clearTimeout(t._to);
    if (autoToast === t) autoToast = null;
    t.classList.add('out'); setTimeout(function () { try { t.remove(); } catch (e) {} }, 210);
  }
  function arm(t, ms) {
    t._left = ms; t._st = Date.now(); clearTimeout(t._to); t._to = setTimeout(function () { close(t); }, ms);
    var br = t.querySelector('.xnt-bar'); if (br) { br.style.animation = 'none'; void br.offsetWidth; br.style.animation = 'xntBar ' + ms + 'ms linear forwards'; }
  }
  var INFO_SEEN = {};   /* V120q : un même message d'information n'est pas réaffiché pendant 90 s */
  function show(msg, type, ms, opt) {
    opt = opt || {};
    type = (type === 'error' || type === 'success' || type === 'warn' || type === 'info') ? type : 'info';
    css();
    /* « Fichier téléchargé : x.pdf » / « Téléchargement lancé : x.pdf » → titre selon le type du fichier ; ignoré si le fichier vient d'être annoncé */
    var dl = !opt.title && type === 'success' ? /^[\s✓✔]*(?:Fichier téléchargé|Téléchargement lancé)\s*:\s*(.+?)\s*$/i.exec(String(msg || '')) : null, b0 = box();
    if (dl) {
      var seenAlready = false;
      Array.prototype.forEach.call(b0.children, function (c) { if (!c._gone && c.classList.contains('success') && c.textContent.indexOf(dl[1]) >= 0) seenAlready = true; });
      if (seenAlready) { ring(); return null; }
      opt = { title: done(kindOf(dl[1])) }; msg = dl[1];
    }
    var p = opt.title ? { title: opt.title, detail: String(msg || '') } : parse(msg, type), b = b0, key = type + '|' + p.title + '|' + p.detail;
    if (type === 'info' && !opt.title) { var nowT = Date.now(); if (INFO_SEEN[key] && nowT - INFO_SEEN[key] < 90000) return null; INFO_SEEN[key] = nowT; }
    var dur = Math.max(3500, ms || (type === 'error' ? 9000 : type === 'warn' ? 7000 : 4500));
    /* une notification « automatique » de fichier est remplacée par le message précis envoyé juste après */
    if (!opt.auto && autoToast && Date.now() - autoToast._at < 2500 && type !== 'error') close(autoToast);
    var ex = null;
    Array.prototype.forEach.call(b.children, function (c) { if (c._key === key && !c._gone) ex = c; });
    if (ex) {
      ex._cnt = (ex._cnt || 1) + 1;
      var n = ex.querySelector('.xnt-n'); if (!n) { n = d.createElement('em'); n.className = 'xnt-n'; n.style.fontStyle = 'normal'; ex.querySelector('b').appendChild(n); }
      n.textContent = '×' + ex._cnt; arm(ex, dur); ring(); badge(); return ex;
    }
    var t = d.createElement('div'); t.className = 'xnt ' + type; t._key = key; t._at = Date.now();
    t.setAttribute('role', type === 'error' || type === 'warn' ? 'alert' : 'status');
    var ic = d.createElement('div'); ic.className = 'xnt-ic'; ic.innerHTML = IC[type];
    var body = d.createElement('div'); body.className = 'xnt-b';
    var h = d.createElement('b'); h.textContent = p.title; body.appendChild(h);
    if (p.detail) { var sp = d.createElement('span'); sp.textContent = p.detail; body.appendChild(sp); }
    var x = d.createElement('button'); x.type = 'button'; x.className = 'xnt-x'; x.title = 'Fermer'; x.setAttribute('aria-label', 'Fermer la notification'); x.innerHTML = '&times;';
    x.onclick = function () { close(t); };
    var bar = d.createElement('i'); bar.className = 'xnt-bar';
    t.appendChild(ic); t.appendChild(body); t.appendChild(x); t.appendChild(bar);
    t.addEventListener('mouseenter', function () { clearTimeout(t._to); t._left = Math.max(1200, t._left - (Date.now() - t._st)); var br = t.querySelector('.xnt-bar'); if (br) br.style.animationPlayState = 'paused'; });
    t.addEventListener('mouseleave', function () { var br = t.querySelector('.xnt-bar'); arm(t, t._left); if (br) br.style.animationPlayState = 'running'; });
    b.appendChild(t);
    /* V128c : close() ne retire la notification qu'après l'animation (210 ms) : l'ancienne boucle tournait donc sans fin dès la 5e notification et figeait la page (import en lot). On retire tout de suite, avec garde-fou. */
    for (var gd = 0; b.children.length > 4 && gd < 30; gd++) { var old1 = b.firstChild; close(old1); try { old1.remove(); } catch (e) { break; } }
    arm(t, dur);
    if (opt.auto) autoToast = t;
    lastAt = Date.now(); ring(); setTimeout(badge, 30);
    return t;
  }

  /* ---------- 6. Fichiers générés ---------- */
  var KINDS = [
    [/\.pdf$/i, 'PDF'], [/\.docx?$/i, 'Document Word'], [/\.xlsx?$|\.csv$/i, 'Fichier Excel'], [/\.pptx?$/i, 'Présentation'],
    [/\.(png|jpe?g|webp|svg|gif)$/i, 'Image'], [/\.json$/i, 'Sauvegarde'], [/\.zip$/i, 'Archive'], [/\.(txt|md)$/i, 'Fichier texte'],
    [/\.(dxf|dwg|ifc|obj|stl)$/i, 'Fichier de plan']
  ];
  function kindOf(name) { for (var i = 0; i < KINDS.length; i++) if (KINDS[i][0].test(name || '')) return KINDS[i][1]; return 'Fichier'; }
  var DONE_LBL = { 'PDF': 'PDF généré', 'Document Word': 'Document Word généré', 'Fichier Excel': 'Fichier Excel généré', 'Présentation': 'Présentation générée', 'Image': 'Image enregistrée', 'Sauvegarde': 'Sauvegarde exportée', 'Archive': 'Archive générée', 'Fichier texte': 'Fichier texte généré', 'Fichier de plan': 'Fichier de plan généré' };
  function done(kind) { return DONE_LBL[kind] || (kind + ' généré'); }
  /* file({kind:'PDF', name:'Rapport.pdf', ok:true})  ·  file({kind:'PDF', name:'…', ok:false, error:'…'})  ·  file({…, warn:'Généré sans photo'}) */
  function file(o) {
    o = o || {}; var kind = o.kind || kindOf(o.name), nm = o.name || '';
    if (o.ok === false) return show((nm ? nm + ' — ' : '') + (o.error || 'La génération a échoué.'), 'error', 9000, { title: kind + ' non généré' });
    if (o.warn) return show((nm ? nm + ' — ' : '') + o.warn, 'warn', 8000, { title: kind + ' généré avec réserve' });
    return show(nm, 'success', 5500, { title: done(kind) });
  }
  function maybeFile(a) {
    try {
      var nm = a.getAttribute('download'); if (nm == null) return;
      var href = String(a.href || ''); if (!/^(blob:|data:)/.test(href)) return;
      if (Date.now() - lastAt < 2500) return; /* un message précis vient d'être affiché */
      nm = nm || 'fichier';
      show(nm, 'success', 5500, { title: done(kindOf(nm)), auto: true });
    } catch (e) {}
  }
  function hookDownloads() {
    if (w.__exbNtHook || !w.HTMLAnchorElement) return; w.__exbNtHook = 1;
    var P = w.HTMLAnchorElement.prototype, oc = P.click, od = P.dispatchEvent;
    P.click = function () { maybeFile(this); return oc.apply(this, arguments); };
    P.dispatchEvent = function (ev) { if (ev && ev.type === 'click') maybeFile(this); return od.apply(this, arguments); };
  }

  /* ---------- 7. Connexion ---------- */
  function online() { return w.navigator.onLine !== false; }
  function chip() {
    var c = $('exbNetChip'), top = $('xbTop');
    if (!c && top) {
      c = d.createElement('div'); c.id = 'exbNetChip'; c.className = 'no-print'; c.setAttribute('role', 'status');
      top.insertBefore(c, top.firstChild);
    }
    if (!c) return;
    var on = online(), ls = Number(lget(K_SYNC, 0));
    c.classList.toggle('off', !on);
    c.innerHTML = on ? '' : '<i></i><span>Hors connexion<small>Dernière synchronisation : ' + (ls ? hhmm(ls) : '—') + '</small></span>';
    c.title = on ? '' : 'Vos données restent enregistrées sur cet appareil et seront synchronisées au retour de la connexion.';
  }
  function markSync() { if (online()) lset(K_SYNC, String(Date.now())); }
  /* Changement de connexion : bandeau + ligne dans l'historique + cloche (pastille et animation), comme dans Excellencia Chantier.
   * Les évènements « online/offline » du système sont parfois manqués (Wi‑Fi sans Internet, veille) : un contrôle léger toutes les 8 s complète. */
  var netOn = online();
  function netChange(on) {
    if (on === netOn) return;
    netOn = on;
    var title = on ? 'Connexion rétablie' : 'Hors connexion',
        text = on ? 'Vos données vont être synchronisées.' : 'Vos données restent enregistrées sur cet appareil. Elles seront synchronisées au retour de la connexion.';
    if (on) markSync();
    chip();
    try { if (typeof w.exbLogNotification === 'function') w.exbLogNotification(title + ' : ' + text, on ? 'success' : 'warn'); } catch (e) {}
    show(text, on ? 'success' : 'warn', on ? 5000 : 8000, { title: title });
    ring(); badge();
  }
  w.addEventListener('offline', function () { netChange(false); });
  w.addEventListener('online', function () { netChange(true); });
  setInterval(function () { var o = online(); if (o !== netOn) netChange(o); }, 8000);

  /* ---------- 8. Fenêtre de la cloche ---------- */
  function rel(t) {
    var ms = Date.now() - t; if (!(ms >= 0)) ms = 0; var m = Math.round(ms / 60000);
    if (m < 1) return 'À l’instant'; if (m < 60) return 'Il y a ' + m + ' min';
    var h = Math.round(m / 60); if (h < 24) return 'Il y a ' + h + ' h';
    var x = new Date(t); return x.toLocaleDateString('fr-FR') + ' à ' + hhmm(t);
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function describe(msg, type) {
    var m = type === 'success' ? /^[\s✓✔]*(?:Fichier téléchargé|Téléchargement lancé)\s*:\s*(.+?)\s*$/i.exec(String(msg || '')) : null;
    return m ? { title: done(kindOf(m[1])), detail: m[1] } : parse(msg, type);
  }
  function pop() { return $('exbNtPop'); }
  function renderPop() {
    var p = pop(); if (!p) return;
    var seen = parseInt(lget('exb_notif_seen', '0'), 10) || 0, list = (w.exbNotifications || []).slice(0, 10);
    p.innerHTML = '<div class="np-h"><b>Notifications</b><button type="button" data-a="read">Tout marquer comme lu</button></div><div class="np-l">' +
      (list.length ? list.map(function (n) {
        var at = Date.parse(n.at), ty = IC[n.type] ? n.type : 'info', pr = describe(n.message, ty);
        return '<div class="np-r' + (at > seen ? ' new' : '') + '"><span class="np-d ' + ty + '">' + IC[ty] + '</span><div class="np-t"><b>' + esc(pr.title) + '</b>' + (pr.detail ? '<span>' + esc(pr.detail) + '</span>' : '') + '<small>' + rel(at) + '</small></div></div>';
      }).join('') : '<div class="np-e">Aucune notification pour le moment.</div>') +
      '</div><div class="np-f"><button type="button" data-a="all">Voir toutes les notifications →</button></div>';
  }
  function openPop() {
    css(); var p = pop();
    if (!p) { p = d.createElement('div'); p.id = 'exbNtPop'; p.className = 'no-print'; p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'Notifications'); d.body.appendChild(p);
      p.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('[data-a]') : null; if (!a) return;
        if (a.getAttribute('data-a') === 'read') { lset('exb_notif_seen', String(Date.now())); badge(); renderPop(); }
        else { closePop(); try { w.show('notifications'); } catch (x) {} }
      }); }
    var b = $('xbBell'); if (b) { var r = b.getBoundingClientRect(); p.style.right = Math.max(10, Math.round(w.innerWidth - r.right - 8)) + 'px'; p.style.top = Math.round(r.bottom + 8) + 'px'; }
    renderPop(); p.classList.add('on'); if (b) b.setAttribute('aria-expanded', 'true');
  }
  function closePop() { var p = pop(), b = $('xbBell'); if (p) p.classList.remove('on'); if (b) b.setAttribute('aria-expanded', 'false'); }
  d.addEventListener('click', function (e) {
    var t = e.target, bell = t && t.closest ? t.closest('#xbBell') : null, p = pop();
    if (bell) {
      e.stopPropagation(); e.preventDefault();
      if (p && p.classList.contains('on')) closePop(); else { openPop(); lset('exb_notif_seen', String(Date.now() + 1)); setTimeout(badge, 30); }
      return;
    }
    if (p && p.classList.contains('on') && !(t.closest && t.closest('#exbNtPop'))) closePop();
  }, true);
  d.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePop(); });

  /* ---------- 9. Démarrage ---------- */
  hookDownloads();
  w.EXB_NOTIFY = { version: 'V120l', show: show, file: file, ring: ring, parse: parse, kindOf: kindOf, refresh: chip };
  var tries = 0, tm = setInterval(function () {
    var ok = !!$('xbTop'); chip();
    if (ok || ++tries > 120) { clearInterval(tm); if (ok && !online()) setTimeout(function () { show('Vos données restent enregistrées sur cet appareil.', 'warn', 6000, { title: 'Hors connexion' }); }, 1500); }
  }, 500);
  markSync(); setInterval(function () { markSync(); chip(); }, 60 * 1000);
  css();
})(window, document);
