/* Excellencia Building — V120q : navigation fiable entre les écrans.
 * Problème corrigé : les écrans « Cartes matricules », « Documents » et « Notifications » restaient affichés en haut de la page
 * quand on ouvrait un autre module (Formations, Formateurs…), et « Enterprise 360° » ne s'affichait jamais.
 * Principe : après chaque show(x), si x est un écran principal (<section id="x">), il est affiché et tous les autres écrans
 * principaux sont masqués (sauf l'accueil, composé de « dashboard » + « exbHome »). Aucune autre fonction n'est modifiée.
 * Ce fichier doit rester le DERNIER script de index.html (il enveloppe window.show en dernier). */
(function (w, d) {
  'use strict';
  if (w.__exbNavFix || typeof w.show !== 'function') return;
  w.__exbNavFix = 1;
  var PAIRS = { dashboard: ['exbHome'], exbHome: ['dashboard'] };
  var prev = w.show, last = '';
  function top(e) { return !!e && e.tagName === 'SECTION' && !(e.parentElement && e.parentElement.closest('section')); }
  function settle(x) {
    if (typeof x !== 'string') return;
    var t = d.getElementById(x);
    if (!top(t)) return;
    var keep = PAIRS[x] || [];
    Array.prototype.forEach.call(d.querySelectorAll('section[id]'), function (s) {
      if (s === t || keep.indexOf(s.id) >= 0 || !top(s)) return;
      if (s.style.display !== 'none') s.style.display = 'none';
    });
    if (t.style.display === 'none') t.style.display = '';
    if (x !== last) { last = x; try { w.scrollTo(0, 0); } catch (e) {} }
  }
  w.show = function (x) {
    var r;
    try { r = prev.apply(this, arguments); }
    catch (err) { try { console.error('Navigation EXB', err); } catch (e) {} }
    try { settle(x); } catch (e) {}
    return r;
  };
  try { w.show.__exbNav = 1; } catch (e) {}
})(window, document);
