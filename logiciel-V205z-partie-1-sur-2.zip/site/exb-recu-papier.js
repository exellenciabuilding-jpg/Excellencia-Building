/* Excellencia Building — Reçu de paiement : UN SEUL gabarit pour le logiciel (Reçus de paiement › Exporter PDF)
 * et pour l'espace apprenant (Mes reçus › Télécharger PDF). Reproduit le reçu affiché dans le logiciel (800 px de large,
 * mêmes polices, couleurs, positions), puis l'enregistre en PDF court (largeur 105 mm), comme l'export du logiciel.
 * API : EXBRecuPapier.draw(data[,opts]) -> Promise<canvas> ; .blob(data[,opts]) -> Promise<Blob PDF> ; .fromAdmin(rec,url) ; .fromSynced(r,nom)
 * data = { no, formation, participant, programme, fraisInscription, statutInscription, fraisFormation, statutFormation,
 *          debut, lieu, distinction, reservation, directeur, url, qr?, logo?, visa? }
 * visa = image PNG (data URL) de la signature + du cachet du Directeur Général, posée dans la zone « Signature / Sceau » comme dans le logiciel (EXBSign). */
(function (w) {
  'use strict';
  var W = 800, X0 = 51, CW = 698, INK = '#252b38', NAVY = '#173565', FONT = 'Arial,Helvetica,sans-serif';
  function s(v) { return v == null ? '' : String(v); }
  function lh(size) { return Math.round(size * 1.149); }
  function load(src) { return new Promise(function (ok) { if (!src) return ok(null); var i = new Image(); i.onload = function () { ok(i); }; i.onerror = function () { ok(null); }; i.src = src; }); }
  function wrap(ctx, text, maxW) {
    var out = []; s(text).split('\n').forEach(function (par) {
      var words = par.split(' '), cur = '';
      words.forEach(function (wd) { var t = cur ? cur + ' ' + wd : wd; if (cur && ctx.measureText(t).width > maxW) { out.push(cur); cur = wd; } else cur = t; });
      out.push(cur);
    }); return out;
  }
  function rr(ctx, x, y, w2, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w2, y, x + w2, y + h, r); ctx.arcTo(x + w2, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w2, y, r); ctx.closePath(); }
  function normalize(d) {
    d = d || {};
    return { no: s(d.no), formation: s(d.formation), participant: s(d.participant), programme: s(d.programme), fraisInscription: s(d.fraisInscription), statutInscription: s(d.statutInscription),
      fraisFormation: s(d.fraisFormation), statutFormation: s(d.statutFormation), debut: s(d.debut), lieu: s(d.lieu), distinction: s(d.distinction), reservation: s(d.reservation), directeur: s(d.directeur), url: s(d.url), qr: d.qr, logo: d.logo, visa: d.visa };
  }
  function fromAdmin(r, url) {
    r = r || {};
    return normalize({ no: r.receipt_no, formation: r.training, participant: r.participant, programme: r.program, fraisInscription: r.registration_fee, statutInscription: r.registration_status,
      fraisFormation: r.training_fee, statutFormation: r.training_status, debut: r.start_date, lieu: r.location_room, distinction: r.distinction, reservation: r.reservation_phone, director: r.director, directeur: r.director, url: url });
  }
  function fromSynced(r, nom) {
    r = r || {}; var fi = r.inscription || {}, ff = r.formation_frais || {};
    return normalize({ no: r.no, formation: r.formation, participant: r.participant || nom, programme: r.programme, fraisInscription: fi.montant, statutInscription: fi.statut,
      fraisFormation: ff.montant, statutFormation: ff.statut, debut: r.debut, lieu: r.lieu, distinction: r.distinction, reservation: r.reservation, directeur: r.directeur, url: r.url });
  }
  function badge(ctx, x, y, txt, kind) {
    ctx.font = 'bold 24px ' + FONT; var tw = ctx.measureText(txt).width, bw = tw + 24, bh = 42;
    ctx.fillStyle = kind === 'ko' ? '#fde1e1' : '#dff5e5'; rr(ctx, x, y, bw, bh, 6); ctx.fill();
    ctx.fillStyle = kind === 'ko' ? '#b12b2b' : (kind === 'half' ? '#b45309' : '#14753a'); ctx.textBaseline = 'alphabetic'; ctx.fillText(txt, x + 12, y + 7 + Math.round(0.905 * 24));
  }
  async function draw(data, opts) {
    var d = normalize(data), o = opts || {}, S = o.scale || 2, logo = await load(d.logo || 'icon-192.png');
    var qrImg = null;
    if (d.qr) qrImg = typeof d.qr === 'string' ? await load(d.qr) : d.qr;
    else if (d.url) { try { var u = w.EXBVerif && w.EXBVerif.qrPng ? w.EXBVerif.qrPng(d.url) : ''; qrImg = await load(u); } catch (e) {} }
    var visaImg = d.visa ? await load(d.visa) : null;
    var cv = document.createElement('canvas'); cv.width = W * S; cv.height = 2000 * S; var ctx = cv.getContext('2d'); ctx.scale(S, S);
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, 2000); ctx.textBaseline = 'alphabetic';
    function txt(t, x, top, size, weight, color, family, style) { ctx.font = (style || '') + ' ' + (weight || 'normal') + ' ' + size + 'px ' + (family || FONT); ctx.fillStyle = color || INK; ctx.fillText(t, x, top + Math.round(0.905 * size)); }
    function label(t, y) { txt(t, X0, y, 16, 'bold'); return y + lh(16); }
    var y = 43;
    /* en-tête */
    if (logo) { var k = Math.min(70 / logo.width, 70 / logo.height), lw = logo.width * k, lhh = logo.height * k; ctx.drawImage(logo, X0 + (70 - lw) / 2, y + (70 - lhh) / 2, lw, lhh); }
    txt('EXCELLENCIA BUILDING', 135, 61, 30, '900', '#17447d'); ctx.font = 'bold 30px ' + FONT;
    ctx.font = 'bold 17px ' + FONT; var nw = ctx.measureText(d.no).width; ctx.font = '17px ' + FONT; var pw = ctx.measureText('N° : ').width;
    txt('N° : ', X0 + CW - nw - pw, y, 17, 'normal'); txt(d.no, X0 + CW - nw, y, 17, 'bold');
    y += 70 + 10; ctx.fillStyle = NAVY; ctx.fillRect(X0, y, CW, 4); y += 4;
    /* encadré titre */
    y += 22; var by = y; ctx.font = '21px ' + FONT; var sub = wrap(ctx, d.formation, 648), bh = 18 + lh(25) + 3 + sub.length * lh(21) + 18;
    ctx.fillStyle = '#eaf0fb'; ctx.fillRect(X0, by, CW, bh); ctx.fillStyle = '#20498a'; ctx.fillRect(X0, by, 6, bh);
    txt("REÇU D'INSCRIPTION", X0 + 28, by + 18, 25, '900', '#20498a');
    sub.forEach(function (l, i) { txt(l, X0 + 28, by + 18 + lh(25) + 3 + i * lh(21), 21, 'normal'); }); y += bh;
    /* participant */
    y += 25; y = label('NOM & PRÉNOM DU PARTICIPANT', y); y += 5; ctx.font = 'bold 28px ' + FONT;
    wrap(ctx, d.participant, CW).forEach(function (l) { txt(l, X0, y, 28, '900'); y += lh(28); });
    /* programme */
    y += 25; y = label('Programme de la formation :', y); ctx.font = '19px ' + FONT;
    var prog = s(d.programme).split('\n').filter(function (x) { return x !== ''; }).map(function (x) { return '• ' + x; }).join('\n'), pl = prog ? wrap(ctx, prog, CW) : [];
    pl.forEach(function (l) { var ph = 19 * 1.35; txt(l, X0, y + (ph - lh(19)) / 2, 19, 'normal'); y += ph; });
    /* frais et statuts */
    y += 22; var colW = (CW - 28) / 2, x2 = X0 + colW + 28;
    function statut(v, kind) { var u = s(v).toUpperCase(); if (u === 'PAYÉ') return ['PAYÉ ✓', 'ok']; if (kind === 'f' && u === 'MOITIÉ PAYÉE') return ['MOITIÉ PAYÉE', 'half']; return ['NON PAYÉ', 'ko']; }
    var rows = [['FRAIS D\'INSCRIPTION', d.fraisInscription, 'STATUT (INSCRIPTION)', statut(d.statutInscription, 'i'), 43], ['FRAIS DE FORMATION', d.fraisFormation, 'STATUT (FORMATION)', statut(d.statutFormation, 'f'), 42]];
    rows.forEach(function (r, i) {
      var t = y + 25; txt(r[0], X0, t, 16, 'bold'); txt(r[2], x2, t, 16, 'bold'); var vt = t + lh(16) + 4;
      txt(r[1], X0, vt, 24, '900'); badge(ctx, x2, vt, r[3][0], r[3][1]); y += 25 + lh(16) + 4 + r[4] + (i === 0 ? 28 : 0);
    });
    /* date et lieu */
    y += 25; y = label('DATE DE DÉBUT', y); y += 4; txt(d.debut, X0, y, 24, '900'); y += lh(24);
    y += 25; y = label('LIEU & SALLE', y); ctx.font = '19px ' + FONT; wrap(ctx, d.lieu, CW).forEach(function (l) { var ph = 19 * 1.35; txt(l, X0, y + (ph - lh(19)) / 2, 19, 'normal'); y += ph; });
    /* distinction / réservation */
    y += 25; ctx.fillStyle = '#ddd'; ctx.fillRect(X0, y, CW, 1); y += 1 + 18;
    [['Distinction :', d.distinction], ['Réservation :', d.reservation]].forEach(function (p) {
      ctx.font = 'bold 18px ' + FONT; var bw2 = ctx.measureText(p[0] + ' ').width; txt(p[0], X0, y, 18, 'bold'); txt(s(p[1]), X0 + bw2, y, 18, 'normal'); y += lh(18);
    });
    /* signature */
    y += 25; var sy = y, sh = 110, bottom = sy + sh;
    txt(d.directeur, X0, bottom - 50, 28, '700', '#23457c', 'Georgia,"Times New Roman",serif', 'italic'); txt('Directeur Général', X0, bottom - 18, 16, 'bold');
    if (visaImg && visaImg.naturalHeight) { var vh = 118, vw = vh * visaImg.naturalWidth / visaImg.naturalHeight; ctx.drawImage(visaImg, 519 + 115 - vw / 2, sy - 22, vw, vh); }
    ctx.font = '17px ' + FONT; ctx.fillStyle = INK; ['Signature / Sceau', 'autorisé'].forEach(function (l, i) { var tw = ctx.measureText(l).width; txt(l, 519 + (230 - tw) / 2, sy + 70 + i * lh(17), 17, 'normal'); });
    y = bottom + 12;
    /* QR */
    ctx.save(); ctx.strokeStyle = '#d8dee8'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(X0, y + 0.5); ctx.lineTo(X0 + CW, y + 0.5); ctx.stroke(); ctx.restore();
    ctx.font = '9px ' + FONT; var cap = 'Scannez pour vérifier l’authenticité du reçu', cw2 = Math.min(190, Math.ceil(ctx.measureText(cap).width)), qx = X0 + Math.round((CW - (120 + 10 + cw2)) / 2), qy = y + 1 + 10;
    if (qrImg) { ctx.imageSmoothingEnabled = false; ctx.drawImage(qrImg, qx, qy, 120, 120); ctx.imageSmoothingEnabled = true; }
    txt(cap, qx + 130, qy + (120 - 12) / 2 + (12 - lh(9)) / 2, 9, 'normal', '#5e6877'); y = qy + 120;
    var H = Math.round(y + 42 + 1);
    /* cadre */
    ctx.strokeStyle = '#e3e6eb'; ctx.lineWidth = 1; rr(ctx, 0.5, 0.5, W - 1, H - 1, 18); ctx.stroke();
    var out = document.createElement('canvas'); out.width = W * S; out.height = H * S; out.getContext('2d').drawImage(cv, 0, 0, W * S, H * S, 0, 0, W * S, H * S); return out;
  }
  function jpegBytes(cv, q) { var u = cv.toDataURL('image/jpeg', q || 0.94), b = atob(u.split(',')[1]), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function hx(t) { var h = 'FEFF'; s(t).split('').forEach(function (c) { h += ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }); return '<' + h + '>'; }
  function pdf(cv, meta) {
    var en = new TextEncoder(), P = [], off = 0, xr = [], jp = jpegBytes(cv), Wp = 105 / 25.4 * 72, Hp = Wp * cv.height / cv.width; meta = meta || {};
    function wr(x) { var b = typeof x === 'string' ? en.encode(x) : x; P.push(b); off += b.length; }
    function ob(k, str, bin) { xr[k] = off; wr(k + ' 0 obj\n' + str); if (bin) { wr(bin); wr('\nendstream'); } wr('\nendobj\n'); }
    wr('%PDF-1.4\n'); ob(1, '<</Type/Catalog/Pages 2 0 R>>'); ob(2, '<</Type/Pages/Count 1/Kids[3 0 R]>>');
    ob(3, '<</Type/Page/Parent 2 0 R/MediaBox[0 0 ' + Wp.toFixed(2) + ' ' + Hp.toFixed(2) + ']/Resources<</XObject<</I 5 0 R>>>>/Contents 4 0 R>>');
    var c = 'q ' + Wp.toFixed(2) + ' 0 0 ' + Hp.toFixed(2) + ' 0 0 cm /I Do Q'; ob(4, '<</Length ' + c.length + '>>stream\n' + c + '\nendstream');
    ob(5, '<</Type/XObject/Subtype/Image/Width ' + cv.width + '/Height ' + cv.height + '/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ' + jp.length + '>>stream\n', jp);
    ob(6, '<</Title ' + hx(meta.title) + '/Author ' + hx('Excellencia Building') + '/Creator ' + hx('Excellencia Building') + '>>');
    var sx = off; wr('xref\n0 7\n0000000000 65535 f \n'); for (var i = 1; i < 7; i++) wr(String(xr[i]).padStart(10, '0') + ' 00000 n \n');
    wr('trailer\n<</Size 7/Root 1 0 R/Info 6 0 R>>\nstartxref\n' + sx + '\n%%EOF');
    var out = new Uint8Array(off), p0 = 0; P.forEach(function (b) { out.set(b, p0); p0 += b.length; }); return out;
  }
  async function blob(data, opts) { var d = normalize(data), cv = await draw(d, opts); return new Blob([pdf(cv, { title: 'Reçu ' + d.no })], { type: 'application/pdf' }); }
  w.EXBRecuPapier = { version: 1, draw: draw, blob: blob, pdfBytes: pdf, fromAdmin: fromAdmin, fromSynced: fromSynced, normalize: normalize };
})(typeof window !== 'undefined' ? window : globalThis);
