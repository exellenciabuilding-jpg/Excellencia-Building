/* Excellencia Building V117 — MESSAGERIE : une seule boîte de réception, séparée par catégories.
 * Onglets : Équipe · Clients · Apprenants · Encadreurs · Formateurs · Rapports · Autres.
 * V205n — ÉQUIPE : messages PRIVÉS (choix d'une personne précise, suppression des fichiers joints, envoi depuis les écrans PDF) entre les espaces (Comptable, Chantier, Ingénieur, Architecture, Formation, Magasin, Direction, Administration), avec pièce jointe
 *   (PDF, image, Word, Excel, PowerPoint, texte, CSV ; 6 Mo). Un message n'est lu que par son expéditeur, son destinataire (la personne ou les membres de la
 *   fonction visée) et l'administrateur ; une annonce « Toute l'équipe » est lue de tous. Le tri est fait PAR LE SERVEUR (migration-v205-lot8-messagerie-privee.sql :
 *   fonctions equipe_envoyer / equipe_lire / equipe_piece / equipe_membres / equipe_supprimer_piece). Sans compte en ligne : messages (sans pièce jointe) gardés sur l'appareil seulement.
 * Le module LIT les messages déjà reçus par les autres modules (il ne les modifie jamais) :
 *   – Apprenants / Encadreurs : exb_tfl_messages (messagerie TFL)
 *   – Formateurs / Rapports   : exb_formateur_retours (messages et rapports de séance)
 *   – Clients / Rapports      : retours des portails (copiés ici à chaque « Actualiser » du module Portails)
 *   – Autres                  : messages saisis à la main (WhatsApp, appel, courrier…)
 * Un bouton ✉️ flottant (pastille = non lus) ouvre la messagerie. API : EXBMessagerie.open(cat), .nonLus().
 * Pour retirer : supprimer la balise <script src="exb-messagerie.js"> de index.html. */
(function (w) {
  'use strict';
  if (w.EXBMessagerie) return;
  var d = document;
  var CATS = [
    { id: 'equipe', ic: '🧭', nom: 'Équipe' },
    { id: 'clients', ic: '👥', nom: 'Clients' },
    { id: 'apprenants', ic: '🎓', nom: 'Apprenants' },
    { id: 'encadreurs', ic: '🧑‍🏫', nom: 'Encadreurs' },
    { id: 'formateurs', ic: '📋', nom: 'Formateurs' },
    { id: 'rapports', ic: '📓', nom: 'Rapports' },
    { id: 'autres', ic: '📨', nom: 'Autres' }
  ];
  var K = { lus: 'exb_msg_lus', cli: 'exb_msg_clients', dec: 'exb_msg_declarations', aut: 'exb_msg_autres', sent: 'exb_msg_envoyes', eq: 'exb_msg_equipe', eqs: 'exb_msg_equipe_srv' };
  var ST = { cat: 'clients', thread: null, q: '', form: false, from: null, note: '', busy: false, file: null, prefObjet: '' };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function norm(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  /* exbStorage est déclaré avec « const » dans index.html : il faut l'atteindre par son nom global. */
  function stg() { try { if (typeof exbStorage !== 'undefined' && exbStorage && exbStorage.getItem) return exbStorage; } catch (e) { /* repli */ } return (w.exbStorage && w.exbStorage.getItem) ? w.exbStorage : null; }
  function rd(k) {
    var v = null, s = stg();
    try { v = s ? s.getItem(k) : null; } catch (e) { v = null; }
    if (v == null) { try { v = w.localStorage.getItem(k); } catch (e) { v = null; } }
    try { var j = JSON.parse(v || 'null'); return j == null ? [] : j; } catch (e) { return []; }
  }
  function wr(k, v) {
    var j = JSON.stringify(v), s = stg();
    try { if (s) { s.setItem(k, j); return true; } } catch (e) { /* repli */ }
    try { w.localStorage.setItem(k, j); return true; } catch (e) { return false; }
  }
  function arr(x) { return Array.isArray(x) ? x : []; }
  function when(at) { var t = new Date(at); if (isNaN(t.getTime())) return ''; return t.toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }); }
  function ts(at) { var t = new Date(at).getTime(); return isNaN(t) ? 0 : t; }
  function cut(s, n) { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; }

  var TYPE_TFL = { commentaire: 'Commentaire', progression: 'Progression proposée', validation: 'Validation du sujet', demande_encadreur: 'Demande d’encadreur', proposition_sujet: 'Proposition de sujet', proposition_plan: 'Proposition de plan' };


  /* ---------- Équipe : messages privés entre espaces ---------- */
  var FUNC = { tous: ['👥', 'Toute l’équipe (annonce)'], admin: ['🛡️', 'Administrateur'], direction: ['🧭', 'Direction'], chef_projet: ['🏗️', 'Chef de projet'], conducteur: ['🏗️', 'Conducteur de travaux (Chantier)'],
    bureau_etudes: ['📐', 'Bureau d’études (Ingénieur)'], architecte: ['🏛️', 'Architecte'], formateur: ['🎓', 'Formateur (Formation)'], comptable: ['🧮', 'Comptable'],
    rh: ['🛡️', 'Ressources humaines (Administration)'], magasinier: ['📦', 'Magasinier'], polyvalent: ['🧩', 'Polyvalent'] };
  var PIECE_MAX = 6 * 1048576, PIECE_OK = '.pdf,.png,.jpg,.jpeg,.webp,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv';
  var EQ = { busy: false, membres: null };
  function fl(f) { var x = FUNC[f]; return x ? x[1] : String(f || '—'); }
  function dbi() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || {}; } catch (e) { return {}; } }
  function srvOn() { var i = dbi(); return !!(i.on && i.org && w.EXBDB && typeof w.EXBDB.rpc === 'function'); }
  function me() {
    var i = dbi(), o = {}, ac = ''; try { if (w.EXBOperateur) { o = w.EXBOperateur.get() || {}; ac = w.EXBOperateur.account ? w.EXBOperateur.account() : ''; } } catch (e) { /* ignoré */ }
    return { f: i.role === 'admin' ? 'admin' : (i.fonction || 'polyvalent'), nom: String(o.nom || '').trim(), acct: String(ac || '') };
  }
  function eqKey(de, a) { return a === 'tous' ? 'equipe|tous' : 'equipe|' + [de, a].sort().join('~'); }
  function filKey(x) { return x.fil ? 'equipe|f|' + x.fil : eqKey(x.de_fonction, x.a_fonction); }
  function sizeTxt(n) { n = Number(n) || 0; return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function dataToBlob(du) {
    var i = String(du).indexOf(','), h = String(du).slice(0, i), b = String(du).slice(i + 1), mt = (/^data:([^;,]+)/.exec(h) || [])[1] || 'application/octet-stream';
    var bin = /;base64/.test(h) ? atob(b) : decodeURIComponent(b), u = new Uint8Array(bin.length); for (var k = 0; k < bin.length; k++) u[k] = bin.charCodeAt(k);
    return new Blob([u], { type: mt });
  }
  function toDataUrl(blob) { return new Promise(function (ok, ko) { var r = new FileReader(); r.onload = function () { ok(String(r.result)); }; r.onerror = function () { ko(new Error('Lecture du fichier impossible.')); }; r.readAsDataURL(blob); }); }
  function addEquipe(a, objet, texte) {            /* mode local (sans compte en ligne) : sur cet appareil seulement */
    var m = me(), L = arr(rd(K.eq));
    var x = { id: 'EQ-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), de_fonction: m.f, de_nom: m.nom || fl(m.f), de_acct: m.acct, a: a, objet: String(objet || '').slice(0, 120), texte: String(texte || '').slice(0, 4000), at: new Date().toISOString() };
    L.push(x); wr(K.eq, L.slice(-1500)); return x;
  }
  function errTxt(e) {
    var s = String((e && e.message) || e || '');
    if (/fichier_trop_lourd/.test(s)) return 'Fichier trop lourd (6 Mo maximum).';
    if (/type de fichier/.test(s)) return 'Type de fichier non accepté (PDF, image, Word, Excel, PowerPoint, texte, CSV).';
    if (/equipe_(envoyer|lire|piece)|function|schema cache|404/i.test(s)) return 'Messagerie d’équipe : exécutez supabase/migration-v205-lot8-messagerie-privee.sql sur Supabase.';
    if (/droits insuffisants/.test(s)) return 'Droits insuffisants pour écrire à l’équipe (compte en lecture seule ?).';
    return s || 'Échec de l’opération.';
  }
  async function syncEq() {                        /* lit MES messages sur le serveur (le tri de confidentialité est fait côté serveur) */
    if (!srvOn() || EQ.busy) return; EQ.busy = true;
    try { var r = await w.EXBDB.rpc('equipe_lire', { p_org: dbi().org }); if (r && Array.isArray(r.messages)) { wr(K.eqs, { moi: r.moi, messages: r.messages }); EQ.err = ''; } }
    catch (e) { EQ.err = errTxt(e); }
    EQ.busy = false; refreshFab();
    if (root && root.classList.contains('on') && !ST.thread && !ST.form && !(d.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(d.activeElement.tagName))) render();
  }
  async function sendEquipe(a, au, objet, texte, file, auto, fil) {
    if (srvOn()) {
      await w.EXBDB.rpc('equipe_envoyer', { p_org: dbi().org, p_a_fonction: a, p_a_user: au || null, p_objet: objet || '', p_texte: texte || '', p_piece_nom: file ? file.name : null, p_piece_type: file ? file.type : null, p_piece_data: file ? file.data : null, p_piece_auto: !!(auto && file), p_fil: fil || null });
      await syncEq(); return 'srv';
    }
    if (file) throw new Error('Une pièce jointe demande un compte en ligne (⚙️ Administration › Compte).');
    addEquipe(a, objet, texte); return 'local';
  }
  /* API : message automatique à une ou plusieurs fonctions (ex. paiement client encaissé → Conducteur + Chef de projet), reçu PDF joint si possible. Promise → 'srv' | 'local' */
  function notifier(fonctions, objet, texte, blob, nom) {
    var L = (fonctions || []).slice(0, 4), pr = blob && blob.size <= PIECE_MAX ? toDataUrl(blob) : Promise.resolve(null), how = 'local';
    return pr.then(function (du) {
      var file = du ? { name: String(nom || 'document.pdf'), type: blob.type || 'application/pdf', size: blob.size, data: du } : null;
      return L.reduce(function (p, f) {
        return p.then(function () { return sendEquipe(f, null, objet, texte, file).catch(function (e) { if (!file) throw e; return sendEquipe(f, null, objet, texte, null); }); }).then(function (r) { how = r; });
      }, Promise.resolve());
    }).then(function () { return how; });
  }
  function collectEquipe(out) {
    var m = me();
    if (srvOn()) {
      var c = rd(K.eqs); if (Array.isArray(c)) c = {}; var moi = c.moi || '';
      arr(c.messages).forEach(function (x) {
        if (!x || !x.id) return;
        var mine = !!moi && x.de_user === moi, ann = x.a_fonction === 'tous';
        var party = mine || x.a_user === moi || ann || x.a_fonction === m.f;
        var other = ann ? 'tous' : (mine ? x.a_fonction : x.de_fonction);
        var pn = ann ? '' : (mine ? x.a_nom : x.de_nom), title = ann ? FUNC.tous[0] + ' ' + FUNC.tous[1] : (party ? (FUNC[other] ? FUNC[other][0] + ' ' : '') + fl(other) + (pn ? ' · ' + pn : '') : fl(x.de_fonction) + (x.de_nom ? ' (' + x.de_nom + ')' : '') + ' ↔ ' + fl(x.a_fonction) + (x.a_nom ? ' (' + x.a_nom + ')' : ''));
        out.push({ id: x.id, cat: 'equipe', thread: filKey(x), title: title, from: mine ? 'Vous' : (x.de_nom || fl(x.de_fonction)) + ' · ' + fl(x.de_fonction), mine: mine, at: x.cree_le, subject: x.objet || '', text: x.texte || '',
          piece: x.piece_nom ? { nom: x.piece_nom, taille: x.piece_taille, supprimee: !!x.piece_supprimee, auto: !!x.piece_auto } : null, meta: { k: 'eq' }, eq: { de_user: x.de_user, a_user: x.a_user, de_f: x.de_fonction, a_f: x.a_fonction, mine: mine, fil: x.fil || '' } });
      });
      return;
    }
    arr(rd(K.eq)).forEach(function (x) {
      if (!x || !x.id || !x.a) return;
      var mine = (x.de_acct && m.acct) ? x.de_acct === m.acct : false;
      var party = x.a === 'tous' || x.a === m.f || x.de_fonction === m.f || mine;
      if (!party && m.f !== 'admin') return;
      var other = x.a === 'tous' ? 'tous' : (x.de_fonction === m.f ? x.a : x.de_fonction);
      var title = x.a === 'tous' ? FUNC.tous[0] + ' ' + FUNC.tous[1] : (party ? (FUNC[other] ? FUNC[other][0] + ' ' : '') + fl(other) : fl(x.de_fonction) + ' ↔ ' + fl(x.a));
      out.push({ id: x.id, cat: 'equipe', thread: eqKey(x.de_fonction, x.a), title: title, from: mine ? 'Vous' : (x.de_nom || fl(x.de_fonction)) + ' · ' + fl(x.de_fonction), mine: mine, at: x.at, subject: x.objet || '', text: x.texte || '', meta: { k: 'eq' }, eq: { de_user: null, a_user: null, de_f: x.de_fonction, a_f: x.a, mine: mine } });
    });
  }
  async function chargerMembres() {
    if (!srvOn()) return;
    try { var r = await w.EXBDB.rpc('equipe_membres', { p_org: dbi().org }); if (Array.isArray(r)) EQ.membres = r; } catch (e) { EQ.membres = EQ.membres || []; }
    fillPersonnes();
  }
  function fillPersonnes() {
    var a = d.getElementById('exbMsgrA'), u = d.getElementById('exbMsgrU'); if (!a || !u) return;
    var f = a.value, keep = u.value, L = (EQ.membres || []).filter(function (x) { return x.fonction === f; });
    u.style.display = (f === 'tous' || !f) ? 'none' : '';
    u.innerHTML = '<option value="">Toute la fonction (' + esc(fl(f)) + ')</option>' + L.map(function (x) { return '<option value="' + esc(x.user_id) + '">' + esc(x.nom) + '</option>'; }).join('');
    if (keep && L.some(function (x) { return x.user_id === keep; })) u.value = keep;
  }
  function findMsg(id) { var L = collect().filter(function (m) { return m.id === id; }); return L[0] || null; }
  async function supprimerPiece(id, silencieux) {
    var go = silencieux ? true : await (w.EXBUI && w.EXBUI.confirm ? w.EXBUI.confirm('Supprimer ce fichier du serveur ? Le message reste, mais le fichier ne pourra plus être ouvert.', { ok: 'Supprimer', danger: 1 }) : Promise.resolve(w.confirm('Supprimer ce fichier du serveur ?')));
    if (!go) return false;
    var ok = false;
    try { var r = await w.EXBDB.rpc('equipe_supprimer_piece', { p_org: dbi().org, p_id: id }); await syncEq(); ok = true; if (!silencieux) ST.note = '✓ Fichier supprimé du serveur' + (r && r.libere ? ' (' + sizeTxt(r.libere) + ' libérés).' : '.'); }
    catch (e) { if (!silencieux) ST.note = '⚠ ' + errTxt(e); }
    if (!silencieux) render();
    return ok;
  }
  function panneauPieces() {            /* administrateur : fichiers joints qui occupent de la place, du plus lourd au plus léger */
    var L = collect().filter(function (m) { return m.cat === 'equipe' && m.piece && !m.piece.supprimee; }).sort(function (a, b) { return (b.piece.taille || 0) - (a.piece.taille || 0); }), tot = 0;
    L.forEach(function (m) { tot += m.piece.taille || 0; });
    var h = '<div class="fm"><b>🧹 Pièces jointes sur le serveur</b><div style="font-size:12px;color:#475569;margin:4px 0">' + L.length + ' fichier(s) · ' + sizeTxt(tot) + ' occupés. Supprimer un fichier garde le message.</div>';
    if (!L.length) h += '<div style="font-size:12px;color:#64748b">Aucune pièce jointe stockée.</div>';
    L.slice(0, 50).forEach(function (m) { h += '<div style="display:flex;gap:6px;align-items:center;border-top:1px solid #e5eaf2;padding:6px 0;font-size:12px"><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">📎 ' + esc(m.piece.nom) + ' · ' + sizeTxt(m.piece.taille) + '<br><small style="color:#64748b">' + esc(m.from) + ' · ' + esc(when(m.at)) + '</small></span><button class="btn s" data-a="delp" data-id="' + esc(m.id) + '" style="color:#b12b2b">🗑</button></div>'; });
    return h + '</div>';
  }
  /* proposition d'envoi après chaque PDF enregistré par le moteur commun (EXBPdf.save) */
  function proposerEnvoi(blob, name) {
    try {
      if (!srvOn() || !blob || blob.size > PIECE_MAX || (root && root.classList.contains('on'))) return;
      var o = d.getElementById('exbMsgrProp'); if (o) o.remove();
      o = d.createElement('div'); o.id = 'exbMsgrProp';
      o.style.cssText = 'position:fixed;left:12px;right:12px;bottom:84px;z-index:99985;max-width:440px;margin:0 auto;background:#173565;color:#fff;border-radius:12px;padding:10px 12px;font:13px Arial;display:flex;gap:8px;align-items:center;box-shadow:0 6px 20px #0006';
      o.innerHTML = '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">📄 ' + esc(name) + '</span><button data-p="s" style="border:0;border-radius:8px;background:#c49a38;color:#fff;padding:8px 10px;font:inherit">✉️ Envoyer à un autre espace</button><button data-p="x" style="border:0;background:none;color:#cbd5e1;font-size:16px">✕</button>';
      d.body.appendChild(o);
      var t = setTimeout(function () { o.remove(); }, 15000);
      o.querySelector('[data-p=x]').onclick = function () { clearTimeout(t); o.remove(); };
      o.querySelector('[data-p=s]').onclick = function () { clearTimeout(t); o.remove(); envoyerDocument(blob, { titre: String(name).replace(/\.pdf$/i, ''), filename: name }); };
    } catch (e) { /* ignoré */ }
  }
  async function ouvrirPiece(id) {
    try {
      var r = await w.EXBDB.rpc('equipe_piece', { p_org: dbi().org, p_id: id }), bl = dataToBlob(r.data), url = URL.createObjectURL(bl), a = d.createElement('a');
      a.href = url; a.download = r.nom || 'document'; d.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      var mm = findMsg(id);
      if (mm && mm.piece && mm.piece.auto && !mm.mine && mm.eq && mm.eq.a_f !== 'tous') { var okd = await supprimerPiece(id, true); ST.note = okd ? '✓ Téléchargé. Fichier retiré du serveur (envoi à usage unique) : conservez votre copie.' : ''; render(); }
    } catch (e) { ST.note = '⚠ ' + errTxt(e); render(); }
  }
  /* API : n'importe quel module peut proposer « Envoyer à un autre espace » pour un PDF / un document déjà produit */
  function envoyerDocument(blob, o) {
    o = o || {}; if (!blob) return;
    var nm = String(o.filename || ((o.titre || 'document') + '.pdf')); if (!/\.[a-z0-9]{2,5}$/i.test(nm)) nm += '.pdf';
    if (blob.size > PIECE_MAX) { try { w.notify && w.notify('Fichier trop lourd (6 Mo maximum).', 'warn', 6000); } catch (e) { /* ignoré */ } return; }
    toDataUrl(blob).then(function (du) {
      ST.file = { name: nm, type: blob.type || 'application/pdf', size: blob.size, data: du }; ST.prefObjet = String(o.titre || '').slice(0, 120);
      open('equipe'); ST.form = true; render(); chargerMembres();
    });
  }

  /* ---------- collecte : chaque source donne des messages au même format ---------- */
  function collect() {
    var out = [];
    /* Apprenants / Encadreurs (TFL) */
    arr(rd('exb_tfl_messages')).forEach(function (m) {
      if (!m || !m.id) return;
      var mine = m.de === 'admin', cat = m.de === 'encadreur' ? 'encadreurs' : (m.de === 'etudiant' ? 'apprenants' : (m.pour === 'encadreur' ? 'encadreurs' : 'apprenants'));
      var tag = TYPE_TFL[m.type] || '';
      out.push({ id: m.id, cat: cat, thread: cat + '|TFL|' + (m.dossier || '—'), title: 'Dossier ' + (m.dossier || '—'), from: mine ? 'Vous' : (m.de_nom || (m.de === 'encadreur' ? 'Encadreur' : 'Apprenant')), mine: mine, at: m.at, meta: { k: 'tfl', dossier: m.dossier, pour: cat === 'encadreurs' ? 'encadreur' : 'etudiant' }, subject: tag, text: m.texte || (m.type === 'progression' ? 'Progression : ' + (m.valeur == null ? '–' : m.valeur + ' %') : '') });
    });
    /* Formateurs / Rapports */
    arr(rd('exb_formateur_retours')).forEach(function (x, i) {
      if (!x || !x.type) return; var dt = x.data || {}, who = x.nom || x.matricule || 'Formateur';
      if (x.type === 'message') out.push({ id: 'FR-' + (x.id || i), cat: 'formateurs', thread: 'formateurs|' + (x.matricule || who), title: who, from: who, mine: false, at: x.maj_le, meta: { k: 'form', matricule: x.matricule }, subject: dt.objet || '', text: dt.texte || '' });
      else if (x.type === 'rapport') out.push({ id: 'FR-' + (x.id || i), cat: 'rapports', thread: 'rapports|seance|' + (x.matricule || who), title: 'Rapports de séance — ' + who, from: who, mine: false, at: x.maj_le || dt.date, meta: x.matricule ? { k: 'form', matricule: x.matricule } : null, subject: [dt.date, dt.formation, dt.module].filter(Boolean).join(' · ') + (dt.realisee === false ? ' (séance non tenue)' : ''), text: [dt.contenu, dt.observations || dt.observation].filter(Boolean).join('\n') });
    });
    /* Clients (copie locale des retours des portails) */
    arr(rd(K.cli)).forEach(function (m) {
      if (!m || !m.id) return; var mine = m.de === 'entreprise';
      out.push({ id: 'CL-' + m.id, cat: 'clients', thread: 'clients|' + (m.token || '—'), title: m.titre || ('Lien ' + String(m.token || '').slice(0, 6)), from: mine ? 'Vous' : (m.titre || 'Visiteur'), mine: mine, at: m.cree_le, meta: m.token ? { k: 'cli', token: m.token } : null, subject: '', text: m.texte || '' });
    });
    /* Rapports : déclarations d'avancement des sous-traitants */
    arr(rd(K.dec)).forEach(function (x) {
      if (!x || !x.id) return; var st = x.statut === 'accepte' ? 'acceptée' : (x.statut === 'refuse' ? 'refusée' : 'à vérifier');
      out.push({ id: 'DC-' + x.id, cat: 'rapports', thread: 'rapports|avancement|' + (x.destinataire || x.titre || '—'), title: 'Avancement — ' + (x.destinataire || x.titre || '—'), from: x.destinataire || x.titre || 'Sous-traitant', mine: false, at: x.cree_le, subject: (x.lot || 'Lot') + ' : ' + Number(x.pct || 0) + ' % (' + st + ')', text: x.note || '' });
    });
    /* Autres : saisie manuelle */
    arr(rd(K.aut)).forEach(function (m) {
      if (!m || !m.id) return;
      out.push({ id: m.id, cat: 'autres', thread: 'autres|' + norm(m.from || '—'), title: m.from || 'Sans nom', from: m.from || 'Sans nom', mine: false, at: m.at, subject: m.subject || '', text: m.text || '', manual: true, meta: { k: 'aut' } });
    });
    collectEquipe(out);
    /* Réponses enregistrées ici (formateurs, autres) */
    arr(rd(K.sent)).forEach(function (r) { if (r && r.id) out.push({ id: r.id, cat: r.cat, thread: r.thread, title: r.title, from: 'Vous', mine: true, at: r.at, subject: '', text: r.text }); });
    return out;
  }
  function lusSet() { var s = {}; arr(rd(K.lus)).forEach(function (i) { s[i] = 1; }); return s; }
  function isUnread(m, L) { return !m.mine && !L[m.id]; }
  function counts() {
    var L = lusSet(), r = {}, tot = 0; CATS.forEach(function (c) { r[c.id] = 0; });
    collect().forEach(function (m) { if (isUnread(m, L)) { r[m.cat]++; tot++; } });
    r.total = tot; return r;
  }
  function markRead(ids) { var L = arr(rd(K.lus)), s = {}; L.forEach(function (i) { s[i] = 1; }); ids.forEach(function (i) { if (!s[i]) { L.push(i); s[i] = 1; } }); wr(K.lus, L.slice(-4000)); }

  /* ---------- réception depuis les autres modules ---------- */
  function merge(key, list, idf) {
    var cur = arr(rd(key)), seen = {}; cur.forEach(function (x) { seen[x.id] = 1; });
    var add = 0; arr(list).forEach(function (x) { if (x && x[idf] != null && !seen[x[idf]]) { cur.push(x); seen[x[idf]] = 1; add++; } });
    if (add) wr(key, cur.slice(-1500)); return add;
  }
  function ingestClients(list, titres) {
    titres = titres || {};
    var n = merge(K.cli, arr(list).map(function (m) { return { id: m.id, token: m.token, de: m.de, texte: String(m.texte || '').slice(0, 2000), cree_le: m.cree_le, titre: titres[m.token] || m.titre || '' }; }), 'id');
    if (n) refreshFab(); return n;
  }
  function ingestDeclarations(list) {
    var n = merge(K.dec, arr(list).map(function (x) { return { id: x.id, destinataire: x.destinataire, titre: x.titre, lot: x.lot, pct: x.pct, statut: x.statut, note: String(x.note || '').slice(0, 1000), cree_le: x.cree_le }; }), 'id');
    if (n) refreshFab(); return n;
  }

  /* ---------- interface ---------- */
  var root = null, fab = null;
  function css() {
    if (d.getElementById('exbMsgrCss')) return;
    var s = d.createElement('style'); s.id = 'exbMsgrCss';
    s.textContent = '#exbMsgr{position:fixed;inset:0;z-index:99990;background:#f4f6fb;display:none;flex-direction:column;font-family:system-ui,Arial,sans-serif;color:#12254a}'
      + '#exbMsgr.on{display:flex}#exbMsgr .mh{background:#12254a;color:#fff;padding:12px 14px;display:flex;align-items:center;gap:10px;padding-top:max(12px,env(safe-area-inset-top))}'
      + '#exbMsgr .mh b{flex:1;font-size:17px}#exbMsgr .mh button{background:none;border:0;color:#fff;font-size:22px;padding:2px 8px;cursor:pointer}'
      + '#exbMsgr .tabs{display:flex;gap:6px;overflow-x:auto;padding:8px 10px;background:#fff;border-bottom:1px solid #dbe3ef;flex:none}'
      + '#exbMsgr .tab{flex:none;border:1px solid #cfd8e6;background:#f4f6fb;color:#12254a;border-radius:18px;padding:7px 12px;font-size:13px;cursor:pointer;white-space:nowrap}'
      + '#exbMsgr .tab.on{background:#12254a;color:#fff;border-color:#12254a}'
      + '#exbMsgr .bd{display:inline-block;min-width:18px;text-align:center;background:#c8962e;color:#fff;border-radius:9px;font-size:11px;padding:1px 5px;margin-left:5px}'
      + '#exbMsgr .bar{display:flex;gap:8px;padding:8px 10px;flex:none}#exbMsgr .bar input{flex:1;padding:9px 11px;border:1px solid #cfd8e6;border-radius:8px;font-size:14px}'
      + '#exbMsgr .bar button,#exbMsgr .btn{border:0;background:#12254a;color:#fff;border-radius:8px;padding:9px 12px;font-size:13px;cursor:pointer}'
      + '#exbMsgr .btn.s{background:#e6ebf3;color:#12254a}'
      + '#exbMsgr .bdy{flex:1;overflow-y:auto;padding:4px 10px 24px;padding-bottom:max(24px,env(safe-area-inset-bottom))}'
      + '#exbMsgr .th{background:#fff;border:1px solid #dbe3ef;border-radius:10px;padding:10px 12px;margin:7px 0;cursor:pointer}'
      + '#exbMsgr .th.u{border-left:4px solid #c8962e}#exbMsgr .th .t{display:flex;justify-content:space-between;gap:8px;font-size:14px}'
      + '#exbMsgr .th .p{font-size:13px;color:#4b5b78;margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#exbMsgr .th small{color:#7a879c}'
      + '#exbMsgr .m{max-width:88%;margin:7px 0;padding:8px 11px;border-radius:12px;background:#fff;border:1px solid #dbe3ef;font-size:14px;white-space:pre-wrap;word-break:break-word}'
      + '#exbMsgr .m.me{margin-left:auto;background:#e8f0ff;border-color:#c5d5f5}#exbMsgr .m small{display:block;color:#7a879c;font-size:11px;margin-bottom:3px}'
      + '#exbMsgr .m b.sj{display:block;font-size:12px;color:#8a6414;margin-bottom:2px}'
      + '#exbMsgr .rp{margin-top:10px;background:#fff;border:1px solid #dbe3ef;border-radius:10px;padding:10px}#exbMsgr .rp textarea{width:100%;box-sizing:border-box;padding:8px;border:1px solid #cfd8e6;border-radius:8px;font:inherit;margin-bottom:8px}#exbMsgr .nt{font-size:12px;color:#14532d;margin-bottom:6px}#exbMsgr .btn[disabled]{opacity:.6}'
      + '#exbMsgr .vide{text-align:center;color:#7a879c;padding:36px 12px;font-size:14px}'
      + '#exbMsgr .fm{background:#fff;border:1px solid #dbe3ef;border-radius:10px;padding:10px;margin:8px 0}#exbMsgr .fm input,#exbMsgr .fm textarea{width:100%;box-sizing:border-box;margin:4px 0;padding:8px;border:1px solid #cfd8e6;border-radius:8px;font:inherit}'
      + '#exbMsgrFab{position:fixed;left:12px;bottom:86px;z-index:9990;width:48px;height:48px;border-radius:50%;border:2px solid #c8962e;background:#12254a;color:#fff;font-size:22px;cursor:pointer;box-shadow:0 3px 10px rgba(0,0,0,.3)}'
      + '#exbMsgrFab i{position:absolute;top:-6px;right:-6px;background:#c8962e;color:#fff;border-radius:10px;font:700 11px/18px Arial;min-width:18px;padding:0 4px;font-style:normal}';
    d.head.appendChild(s);
  }
  function fileBox() {
    return '<div style="margin:6px 0"><label style="font-size:12px;display:block;margin-bottom:3px">📎 Joindre un document (PDF, image, Word, Excel… 6 Mo max.)</label><input type="file" id="exbMsgrFile" accept="' + PIECE_OK + '" style="font-size:12px"><div id="exbMsgrFi" style="font-size:12px;color:#14532d;margin-top:3px">' + (ST.file ? '📎 ' + esc(ST.file.name) + ' · ' + sizeTxt(ST.file.size) + ' <a href="#" data-a="nofile" style="color:#b12b2b">retirer</a>' : '') + '</div></div>';
  }
  function threads(cat) {
    var L = lusSet(), by = {}, q = norm(ST.q);
    collect().filter(function (m) { return m.cat === cat; }).forEach(function (m) {
      if (q && norm(m.from + ' ' + m.title + ' ' + m.subject + ' ' + m.text).indexOf(q) < 0) return;
      var t = by[m.thread] = by[m.thread] || { key: m.thread, title: m.title, msgs: [], unread: 0, meta: null };
      if (m.meta && !t.meta) t.meta = m.meta;
      t.msgs.push(m); if (isUnread(m, L)) t.unread++;
    });
    return Object.keys(by).map(function (k) { var t = by[k]; t.msgs.sort(function (a, b) { return ts(a.at) - ts(b.at); }); t.last = t.msgs[t.msgs.length - 1]; return t; })
      .sort(function (a, b) { return ts(b.last.at) - ts(a.last.at); });
  }
  function render() {
    if (!root) return; var c = counts(), h = '';
    var cat = CATS.filter(function (x) { return x.id === ST.cat; })[0] || CATS[0];
    h += '<div class="mh">' + (ST.thread ? '<button data-a="back" aria-label="Retour">←</button>' : '') + '<b>✉️ Messagerie' + (c.total ? ' <span class="bd">' + c.total + '</span>' : '') + '</b><button data-a="close" aria-label="Fermer">✕</button></div>';
    h += '<div class="tabs">' + CATS.map(function (x) { return '<button class="tab' + (x.id === ST.cat ? ' on' : '') + '" data-a="cat" data-c="' + x.id + '">' + x.ic + ' ' + x.nom + (c[x.id] ? '<span class="bd">' + c[x.id] + '</span>' : '') + '</button>'; }).join('') + '</div>';
    if (!ST.thread) {
      h += '<div class="bar"><input id="exbMsgrQ" type="search" placeholder="Rechercher dans ' + esc(cat.nom) + '…" value="' + esc(ST.q) + '">' + (c[ST.cat] ? '<button data-a="readall">Tout lu</button>' : '') + (ST.cat === 'autres' ? '<button data-a="new">＋ Ajouter</button>' : '') + (ST.cat === 'equipe' ? '<button data-a="new">＋ Nouveau message</button>' + (me().f === 'admin' && srvOn() ? '<button data-a="pjs">🧹 Pièces jointes</button>' : '') : '') + '</div>';
      h += '<div class="bdy">';
      if (ST.cat === 'autres' && ST.form) h += '<div class="fm"><b>Message reçu (WhatsApp, appel, courrier…)</b><input id="exbMsgrF" placeholder="De la part de (nom)"><input id="exbMsgrS" placeholder="Objet (facultatif)"><textarea id="exbMsgrT" rows="4" placeholder="Contenu du message"></textarea><div style="display:flex;gap:8px;margin-top:6px"><button class="btn" data-a="save">Enregistrer</button><button class="btn s" data-a="cancel">Annuler</button></div></div>';
      if (ST.cat === 'equipe' && ST.form) h += '<div class=\"fm\"><b>Message privé à un autre espace</b><select id=\"exbMsgrA\" style=\"width:100%;box-sizing:border-box;margin:4px 0;padding:8px;border:1px solid #cfd8e6;border-radius:8px;font:inherit\">' + '<option value=\"\">— Choisir l’espace destinataire —</option>' + Object.keys(FUNC).filter(function (k) { return k !== 'polyvalent' && k !== me().f; }).map(function (k) { return '<option value=\"' + k + '\">' + FUNC[k][0] + ' ' + esc(FUNC[k][1]) + '</option>'; }).join('') + '</select><select id=\"exbMsgrU\" style=\"width:100%;box-sizing:border-box;margin:4px 0;padding:8px;border:1px solid #cfd8e6;border-radius:8px;font:inherit\"><option value=\"\">Toute la fonction</option></select><input id=\"exbMsgrS\" placeholder=\"Objet (ex. Facture à valider, plan à envoyer…)\" value=\"' + esc(ST.prefObjet) + '\"><textarea id=\"exbMsgrT\" rows=\"4\" placeholder=\"Votre message\"></textarea>' + fileBox() + '<label style=\"display:block;font-size:12px;margin:4px 0\"><input type=\"checkbox\" id=\"exbMsgrAuto\"> Supprimer le fichier du serveur après le 1er téléchargement du destinataire</label><div class=\"nt\" id=\"exbMsgrNote\" style=\"color:#b12b2b\"></div><div style=\"display:flex;gap:8px;margin-top:6px\"><button class=\"btn\" data-a=\"save\">Envoyer</button><button class=\"btn s\" data-a=\"cancel\">Annuler</button></div><div style=\"font-size:11px;color:#64748b;margin-top:6px\">Seuls vous, le destinataire et l’administrateur verront ce message.</div></div>';
      if (ST.cat === 'equipe' && ST.pjs && me().f === 'admin') h += panneauPieces();
      var T = threads(ST.cat);
      if (!T.length) h += '<div class="vide">' + (ST.q ? 'Aucun message ne correspond à la recherche.' : (ST.cat === 'equipe' ? 'Aucun message d’équipe. Utilisez « ＋ Nouveau message » pour écrire au Comptable, au Chantier, à la Direction…' : 'Aucun message dans « ' + esc(cat.nom) + ' ».')) + '</div>';
      T.forEach(function (t) { h += '<div class="th' + (t.unread ? ' u' : '') + '" data-a="open" data-k="' + esc(t.key) + '"><div class="t"><b>' + esc(t.title) + '</b><small>' + esc(when(t.last.at)) + '</small></div><div class="p">' + (t.last.mine ? 'Vous : ' : '') + esc(cut(t.last.subject ? t.last.subject + ' — ' + t.last.text : t.last.text, 110)) + '</div><small>' + t.msgs.length + ' message' + (t.msgs.length > 1 ? 's' : '') + (t.unread ? ' · <b style="color:#8a6414">' + t.unread + ' non lu' + (t.unread > 1 ? 's' : '') + '</b>' : '') + '</small></div>'; });
      h += '</div>';
    } else {
      var th = threads(ST.cat).filter(function (t) { return t.key === ST.thread; })[0];
      h += '<div class="bdy"><div style="font-weight:700;margin:10px 2px 4px">' + esc(th ? th.title : '') + '</div>';
      if (th) th.msgs.forEach(function (m) { h += '<div class="m' + (m.mine ? ' me' : '') + '"><small>' + esc(m.from) + ' · ' + esc(when(m.at)) + '</small>' + (m.subject ? '<b class="sj">' + esc(m.subject) + '</b>' : '') + esc(m.text || (m.piece ? '' : '—')) + (m.piece ? (m.piece.supprimee ? '<div style="margin-top:6px;font-size:12px;color:#64748b">📎 ' + esc(m.piece.nom) + ' — fichier supprimé du serveur</div>' : '<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap"><button class="btn s" data-a="getp" data-id="' + esc(m.id) + '">📎 ' + esc(m.piece.nom) + ' · ' + sizeTxt(m.piece.taille) + (m.piece.auto && !m.mine ? ' — ouvrir (usage unique)' : ' — ouvrir') + '</button><button class="btn s" data-a="delp" data-id="' + esc(m.id) + '" style="color:#b12b2b">🗑 Supprimer le fichier</button></div>') : '') + '</div>'; });
      if (th && th.meta) h += '<div class="rp">' + (ST.note ? '<div class="nt">' + esc(ST.note) + '</div>' : '') + '<textarea id="exbMsgrR" rows="3" placeholder="Votre réponse…"></textarea>' + (th.meta.k === 'eq' ? fileBox() : '') + '<button class="btn" data-a="reply"' + (ST.busy ? ' disabled' : '') + '>' + (ST.busy ? 'Envoi…' : '↩ Envoyer la réponse') + '</button></div>';
      else h += '<div class="vide" style="padding:14px;font-size:12px">' + (ST.cat === 'rapports' ? 'Pour accepter ou refuser une déclaration d’avancement, utilisez le module Portails.' : 'Aucune réponse possible pour ce message.') + '</div>';
      h += '</div>';
    }
    var keep = d.activeElement && d.activeElement.id === 'exbMsgrQ', pos = keep ? d.activeElement.selectionStart : 0;
    root.innerHTML = h;
    if (keep) { var q = d.getElementById('exbMsgrQ'); if (q) { q.focus(); try { q.setSelectionRange(pos, pos); } catch (e) { /* ignoré */ } } }
  }
  function build() {
    if (root) return; css();
    root = d.createElement('div'); root.id = 'exbMsgr'; d.body.appendChild(root);
    root.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-a]') : null; if (!b) return; var a = b.getAttribute('data-a');
      if (a === 'close') return close();
      if (a === 'back') { ST.thread = null; ST.note = ''; ST.file = null; return render(); }
      if (a === 'cat') { ST.cat = b.getAttribute('data-c'); ST.thread = null; ST.q = ''; ST.form = false; ST.file = null; ST.prefObjet = ''; if (ST.cat === 'equipe') syncEq(); return render(); }
      if (a === 'reply') return reply();
      if (a === 'open') { ST.note = ''; ST.thread = b.getAttribute('data-k'); var t = threads(ST.cat).filter(function (x) { return x.key === ST.thread; })[0]; if (t) markRead(t.msgs.map(function (m) { return m.id; })); render(); refreshFab(); return; }
      if (a === 'readall') { markRead(collect().filter(function (m) { return m.cat === ST.cat; }).map(function (m) { return m.id; })); render(); refreshFab(); return; }
      if (a === 'new') { ST.form = true; render(); if (ST.cat === 'equipe') chargerMembres(); return; }
      if (a === 'cancel') { ST.form = false; ST.file = null; ST.prefObjet = ''; ST.pjs = false; return render(); }
      if (a === 'nofile') { e.preventDefault(); ST.file = null; var fi = d.getElementById('exbMsgrFi'); if (fi) fi.textContent = ''; var fe = d.getElementById('exbMsgrFile'); if (fe) fe.value = ''; return; }
      if (a === 'getp') return ouvrirPiece(b.getAttribute('data-id'));
      if (a === 'delp') return supprimerPiece(b.getAttribute('data-id'), false);
      if (a === 'pjs') { ST.pjs = !ST.pjs; return render(); }
      if (a === 'save' && ST.cat === 'equipe') {
        var ea = d.getElementById('exbMsgrA'), es = d.getElementById('exbMsgrS'), et = d.getElementById('exbMsgrT'), etx = (et && et.value || '').trim(), nt = d.getElementById('exbMsgrNote');
        if (!ea || !ea.value) { if (nt) nt.textContent = '⚠ Choisissez l’espace destinataire.'; return; }
        if (etx.length < 2 && !ST.file) { et && et.focus(); return; }
        if (ST.busy) return; ST.busy = true; b.disabled = true;
        var eu = d.getElementById('exbMsgrU'), eauto = d.getElementById('exbMsgrAuto');
        sendEquipe(ea ? ea.value : 'tous', (eu && eu.value) || null, es ? es.value.trim() : '', etx, ST.file, !!(eauto && eauto.checked)).then(function () { ST.busy = false; ST.form = false; ST.file = null; ST.prefObjet = ''; render(); refreshFab(); })
          .catch(function (er) { ST.busy = false; b.disabled = false; if (nt) nt.textContent = '⚠ ' + errTxt(er); });
        return;
      }
      if (a === 'save') {
        var f = d.getElementById('exbMsgrF'), s = d.getElementById('exbMsgrS'), t2 = d.getElementById('exbMsgrT'), txt = (t2 && t2.value || '').trim();
        if (txt.length < 2) { t2 && t2.focus(); return; }
        var A = arr(rd(K.aut)); A.push({ id: 'MA-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), from: ((f && f.value) || '').trim().slice(0, 80), subject: ((s && s.value) || '').trim().slice(0, 120), text: txt.slice(0, 4000), at: new Date().toISOString() });
        wr(K.aut, A.slice(-1500)); ST.form = false; render(); refreshFab();
      }
    });
    root.addEventListener('change', function (e) {
      if (e.target && e.target.id === 'exbMsgrA') { fillPersonnes(); return; }
      if (!e.target || e.target.id !== 'exbMsgrFile') return;
      var f = e.target.files && e.target.files[0], fi = d.getElementById('exbMsgrFi'); if (!f) { ST.file = null; if (fi) fi.textContent = ''; return; }
      if (f.size > PIECE_MAX) { ST.file = null; e.target.value = ''; if (fi) { fi.style.color = '#b12b2b'; fi.textContent = '⚠ Fichier trop lourd (6 Mo maximum).'; } return; }
      if (!/\.(pdf|png|jpe?g|webp|docx?|xlsx?|pptx?|txt|csv)$/i.test(f.name)) { ST.file = null; e.target.value = ''; if (fi) { fi.style.color = '#b12b2b'; fi.textContent = '⚠ Type de fichier non accepté.'; } return; }
      toDataUrl(f).then(function (du) { ST.file = { name: f.name, type: f.type || 'application/octet-stream', size: f.size, data: du }; var fi2 = d.getElementById('exbMsgrFi'); if (fi2) { fi2.style.color = '#14532d'; fi2.innerHTML = '📎 ' + esc(f.name) + ' · ' + sizeTxt(f.size) + ' <a href="#" data-a="nofile" style="color:#b12b2b">retirer</a>'; } })
        .catch(function () { if (fi) fi.textContent = '⚠ Lecture du fichier impossible.'; });
    });
    root.addEventListener('input', function (e) { if (e.target && e.target.id === 'exbMsgrQ') { ST.q = e.target.value; render(); } });
  }
  function addSent(th, txt) {
    var A = arr(rd(K.sent)); A.push({ id: 'MS-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), cat: ST.cat, thread: th.key, title: th.title, text: txt.slice(0, 4000), at: new Date().toISOString() });
    wr(K.sent, A.slice(-1500));
  }
  async function reply() {
    if (ST.busy) return;
    var ta = d.getElementById('exbMsgrR'), txt = (ta && ta.value || '').trim();
    var th = threads(ST.cat).filter(function (t) { return t.key === ST.thread; })[0];
    if (!th || !th.meta) return; if (txt.length < 2 && !(th.meta.k === 'eq' && ST.file)) { if (ta) ta.focus(); return; }
    var mt = th.meta; ST.busy = true; ST.note = ''; render();
    try {
      if (mt.k === 'tfl') {
        var T = w.EXBTFL; if (!T || !T.portail || !T.portail.messageAdmin) throw new Error('Le module TFL n’est pas disponible.');
        T.portail.messageAdmin(mt.dossier, mt.pour, txt); ST.note = '✓ Réponse enregistrée.';
        try { if (T.ui && T.ui.publierPortails) { await T.ui.publierPortails({}); ST.note = '✓ Réponse envoyée au portail.'; } } catch (e) { ST.note = '✓ Réponse enregistrée. Publication du portail à refaire depuis TFL › Portails (hors ligne ?).'; }
      } else if (mt.k === 'cli') {
        if (!w.EXBPortailRepondre) throw new Error('Le module Portails n’est pas disponible.');
        await w.EXBPortailRepondre(mt.token, txt); ST.note = '✓ Réponse envoyée au client.';
      } else if (mt.k === 'form') {
        if (!w.EXBFormateurRepondre) throw new Error('Le module Formateurs n’est pas disponible.');
        await w.EXBFormateurRepondre(mt.matricule, txt); addSent(th, txt); ST.note = '✓ Réponse envoyée au formateur.';
      } else if (mt.k === 'eq') {
        var key = String(th.key || ''), last = th.msgs[th.msgs.length - 1] || {}, eqx = last.eq || {}, mf = me().f, to, toU = null;
        if (key === 'equipe|tous') to = 'tous';
        else if (eqx.mine) { to = eqx.a_f; toU = eqx.a_user || null; }
        else { to = eqx.de_f; toU = eqx.de_user || null; }
        if (!to) { var pr = key.replace('equipe|', '').split('~'); to = pr.filter(function (x) { return x !== mf; })[0] || pr[0]; }
        await sendEquipe(to, toU, last.subject ? 'Re : ' + String(last.subject).replace(/^Re : /, '') : '', txt, ST.file, false, eqx.fil || ''); ST.file = null; ST.note = '✓ Réponse envoyée' + (srvOn() ? '.' : ' (sur cet appareil : pas de compte en ligne).');
      } else { addSent(th, txt); ST.note = '✓ Réponse enregistrée dans la conversation.'; }
    } catch (e) { ST.note = '⚠ ' + ((e && e.message) || e); if (ta) ta.value = txt; ST.busy = false; render(); var t2 = d.getElementById('exbMsgrR'); if (t2) t2.value = txt; return; }
    ST.busy = false; render(); refreshFab();
  }
  function open(cat, from) {
    build(); ST.from = from || null; ST.note = ''; if (cat && CATS.some(function (x) { return x.id === cat; })) { ST.cat = cat; ST.thread = null; ST.q = ''; ST.form = false; }
    else if (!ST.thread) { var c = counts(); var first = CATS.filter(function (x) { return c[x.id] > 0; })[0]; if (first && !c[ST.cat]) ST.cat = first.id; }
    render(); root.classList.add('on'); if (fab) fab.style.display = 'none'; syncEq();
  }
  function close() {
    var f = ST.from; ST.from = null; ST.note = ''; ST.file = null; ST.prefObjet = ''; ST.form = false;
    if (root) root.classList.remove('on'); ST.thread = null; if (fab) fab.style.display = ''; refreshFab();
    if (f) { try { if (w.EXB_SHELL && w.EXB_SHELL.openCat) w.EXB_SHELL.openCat(f); } catch (e) { /* ignoré */ } }
  }
  var lastEq = null;
  function refreshFab() { if (!fab) return; var cc = counts(), n = cc.total; if (lastEq !== null && cc.equipe > lastEq && !(root && root.classList.contains('on'))) { try { w.notify && w.notify('✉️ Nouveau message d’équipe', 'info', 5000); } catch (e) { /* ignoré */ } } lastEq = cc.equipe; var i = fab.querySelector('i'); if (n) { if (!i) { i = d.createElement('i'); fab.appendChild(i); } i.textContent = n > 99 ? '99+' : n; } else if (i) i.remove(); }
  function initFab() {
    if (fab || !d.body) return; css();
    fab = d.createElement('button'); fab.id = 'exbMsgrFab'; fab.type = 'button'; fab.title = 'Messagerie'; fab.setAttribute('aria-label', 'Messagerie'); fab.textContent = '✉️';
    fab.onclick = function () { open(); }; d.body.appendChild(fab); refreshFab();
    injectTiles(); setInterval(injectTiles, 4000); setTimeout(syncEq, 3000); setInterval(function () { if (!d.hidden) syncEq(); }, 120000);
    setInterval(function () { if (!root || !root.classList.contains('on')) refreshFab(); else if (!ST.thread && !(d.activeElement && /^(INPUT|TEXTAREA)$/.test(d.activeElement.tagName))) render(); }, 30000);
  }
  /* Tuile « Messagerie » dans chaque grande catégorie de l'accueil (Formation, Clients, Ingénierie, Finance…) */
  var TILES = [['ent', 'equipe'], ['for', 'apprenants'], ['crm', 'clients'], ['arc', 'equipe'], ['ing', 'equipe'], ['prj', 'equipe'], ['fin', 'equipe'], ['ach', 'equipe'], ['rap', 'rapports']];
  function injectTiles() {
    var tb = d.querySelector('#app .tabs'); if (!tb) return;
    TILES.forEach(function (t) {
      var id = 'exbMsgrTile_' + t[0]; if (d.getElementById(id)) return;
      var b = d.createElement('button'); b.type = 'button'; b.id = id; b.setAttribute('data-exb-cat', t[0]); b.setAttribute('data-exb-desc', 'Équipe (autres espaces), clients, apprenants, encadreurs, rapports : lire et répondre');
      b.setAttribute('onclick', "EXBMessagerie.open(" + (t[1] ? "'" + t[1] + "'" : 'null') + ",'" + t[0] + "')"); b.textContent = '✉️ Messagerie'; tb.appendChild(b);
    });
  }
  w.EXBMessagerie = { notifier: notifier, proposerEnvoi: proposerEnvoi, envoyerDocument: envoyerDocument, sync: syncEq, open: open, close: close, nonLus: function () { return counts(); }, collect: collect, ingestClients: ingestClients, ingestDeclarations: ingestDeclarations, categories: CATS };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', initFab); else initFab();
})(window);
