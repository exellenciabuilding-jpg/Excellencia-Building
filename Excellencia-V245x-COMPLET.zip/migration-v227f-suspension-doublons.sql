-- ===== Excellencia Building V227f : répare « Could not choose the best candidate function » (suspension / réactivation) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger. Ne touche à aucune donnée.
-- Cause : equipe_suspendre existe en DEUX versions (anciennes migrations). Supabase ne sait pas laquelle appeler et refuse.
-- Correctif : on garde la version officielle (uuid, uuid, text) et on supprime les doublons. Même chose pour equipe_reactiver (uuid, uuid).

-- 0) Avant : liste des versions présentes (pour contrôle)
select p.proname, pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('equipe_suspendre','equipe_reactiver') order by 1, 2;

do $$
declare r record; n int := 0;
begin
  if to_regprocedure('equipe_suspendre(uuid,uuid,text)') is null then
    raise exception 'La version officielle equipe_suspendre(uuid,uuid,text) est absente : exécutez d''abord migration-v210f-suspension-membres.sql.'; end if;
  if to_regprocedure('equipe_reactiver(uuid,uuid)') is null then
    raise exception 'La version officielle equipe_reactiver(uuid,uuid) est absente : exécutez d''abord migration-v210f-suspension-membres.sql.'; end if;
  for r in
    select p.oid::regprocedure as sig
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and ((p.proname = 'equipe_suspendre' and p.oid <> to_regprocedure('equipe_suspendre(uuid,uuid,text)'))
        or (p.proname = 'equipe_reactiver' and p.oid <> to_regprocedure('equipe_reactiver(uuid,uuid)')))
  loop
    execute 'drop function ' || r.sig; n := n + 1;
  end loop;
  raise notice 'Doublons supprimés : %', n;
end $$;

grant execute on function equipe_suspendre(uuid,uuid,text), equipe_reactiver(uuid,uuid) to authenticated;
notify pgrst, 'reload schema';

-- Contrôle : doit afficher exactement 2 lignes (une par fonction)
select p.proname, pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('equipe_suspendre','equipe_reactiver') order by 1, 2;
