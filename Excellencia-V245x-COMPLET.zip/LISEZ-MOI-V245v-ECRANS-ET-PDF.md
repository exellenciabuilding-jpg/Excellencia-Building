# V245v — Écrans Finance en page + page de garde, visa et numérotation

Base : V245u.

## 1. Écrans
Centre de réception, Fournisseurs & dettes, Trésorerie, Analytique chantier, Paie · Fiscalité · Immo, Contrôle paie · Écritures, Rapports & recette
(et Périmètre projets) s'affichent dans la zone de contenu, comme les autres modules. Italique parasite du Centre de réception corrigé.
La Messagerie s’affiche elle aussi en page (V245w).

## 2. PDF et impressions
- Choix « Avec page de garde » / « Sans » : PDF directs, rapports HTML des modules, et impression des écrans Finance (application Windows).
- Avec : visa et signature sur la page de garde (page 1 / N).
- Sans : visa et signature en bas de la 1re page (page 1 / N).
- Non concernés (forme propre) : certificats, reçus, cartes, plans, affiches, étiquettes, bons, notes de calcul.
- Application Windows : « Imprimer » passe par le PDF (le visa et les numéros y sont posés), puis impression depuis le lecteur PDF.

## Installation
Reconstruire l'application Windows (dossier electron : npm run dist) : main.js et preload.js ont changé.
