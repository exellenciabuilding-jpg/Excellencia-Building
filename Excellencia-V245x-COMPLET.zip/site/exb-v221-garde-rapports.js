/* Excellencia Building V221l — PAGE DE GARDE AU CHOIX + MISE EN PAGE UNIQUE DES PDF.
 * Avant : les PDF du Centre documentaire (factures, reçus, décomptes, PV, rapports, notes d'études…) sortaient toujours en « couverture + contenu »,
 * avec une mise en page différente des pièces d'ingénierie.
 * Maintenant : au moment de produire le PDF, une petite fenêtre demande « Avec page de garde » ou « Sans page de garde (contenu seul) ».
 *  - contenu = mise en page « pièce » commune (en-tête, Réf./Projet/Date, titre, tableau, visa et signature, QR et pied de page en bas) ;
 *  - avec page de garde = page de garde officielle (logo, titre, QR) placée devant le contenu.
 * Le dernier choix est présélectionné (Entrée valide). Réglage fixe possible : EXBGARDE.set('avec'|'sans'|'ask').
 * Pièces qui gardent leur propre forme (reçus, plans, journaux) : options garde:false → jamais de demande. */
(function (w) {
  'use strict';
  if (w.EXBGARDE || !w.EXBPdf || !w.EXBPdf.make) return;
  var P = w.EXBPdf, orig = P.make, d = w.document, KEY = 'EXB_PDF_GARDE', LAST = 'EXB_PDF_GARDE_LAST';
  function ls(k, v) { try { if (v === undefined) return w.localStorage.getItem(k); w.localStorage.setItem(k, v); } catch (e) { } return null; }
  function ask(titre) {
    var mode = ls(KEY); if (mode === 'avec' || mode === 'sans') return Promise.resolve(mode);
    return new Promise(function (ok) {
      var last = ls(LAST) === 'avec' ? 'avec' : 'sans', o = d.createElement('div');
      o.setAttribute('role', 'dialog'); o.setAttribute('aria-modal', 'true');
      o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px';
      o.innerHTML = '<div style="background:#fff;border-radius:14px;padding:20px;max-width:420px;width:100%;font:14px Arial;color:#172033;box-shadow:0 10px 40px rgba(0,0,0,.3)">'
        + '<div style="font-weight:800;font-size:17px;color:#173565;margin-bottom:6px">Page de garde</div>'
        + '<div style="color:#475569;margin-bottom:14px">' + String(titre || 'Ce document').replace(/[<>&]/g, '') + ' : imprimer avec la page de garde, ou le contenu seul ?</div>'
        + '<div style="display:flex;gap:8px;flex-wrap:wrap"><button data-g="avec" style="flex:1;min-width:150px;padding:11px;border:2px solid #c49a38;border-radius:10px;background:#fff;color:#173565;font-weight:700;cursor:pointer">📕 Avec page de garde</button>'
        + '<button data-g="sans" style="flex:1;min-width:150px;padding:11px;border:2px solid #173565;border-radius:10px;background:#173565;color:#fff;font-weight:700;cursor:pointer">📄 Sans (contenu seul)</button></div>'
        + '<label style="display:flex;gap:8px;align-items:center;margin-top:12px;font-size:12.5px;color:#475569"><input type="checkbox" data-mem> Ne plus demander (garder ce choix)</label></div>';
      d.body.appendChild(o);
      var btn = o.querySelector('[data-g=' + last + ']'); try { btn.focus(); } catch (e) { }
      function done(v) { var mem = o.querySelector('[data-mem]').checked; d.removeEventListener('keydown', kd, true); o.remove(); ls(LAST, v); if (mem) ls(KEY, v); ok(v); }
      function kd(e) { if (e.key === 'Escape') { e.preventDefault(); done('sans'); } }
      o.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('button[data-g]'); if (b) done(b.getAttribute('data-g')); });
      d.addEventListener('keydown', kd, true);
    });
  }
  function make(o) {
    if (!o || o.garde === false || o.cover === false && o.garde === undefined && o.verify === false || o.__garde) return orig.call(P, o);
    var forced = o.garde === true ? 'avec' : null;
    return (forced ? Promise.resolve(forced) : ask(o.titre)).then(function (choice) {
      var base = Object.assign({}, o, { __garde: 1 });
      var content = w.EXBENT && w.EXBENT.piece && !base.style ? w.EXBENT.piece(Object.assign({}, base)) : base;
      if (!content.style) content = Object.assign({}, content, { cover: false });
      /* V245v : un seul document (garde + contenu) → numérotation 1/N et visa posé une seule fois */
      if (choice === 'avec') content = Object.assign({}, content, content.style === 'piece' ? { coverPage: true } : { cover: true });
      return orig.call(P, content);
    });
  }
  /* ───────── V245v : le même choix pour les documents HTML (rapports des modules, Centre documentaire, écrans Finance) ─────────
   * Avec page de garde : garde (logo, titre, visa et signature) = page 1. Sans : visa et signature en bas de la 1re page. Numérotation « Page 1 / N ».
   * Pièces à forme propre (certificats, reçus, cartes, plans, affiches, étiquettes) : inchangées. */
  var PROPRE = /certificat|attestation|re[çc]u|carte|affiche|badge|[ée]tiquette|\bplans?\b|cartouche|ticket|\bQR\b|dipl[ôo]me|bon de/i;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function eligible(titre, h, o) {
    if (o && (o.nativeLayout || o.garde === false)) return false;
    if (PROPRE.test(String(titre || ''))) return false;
    return !/data-exb-nogarde|@page[^{}]*\{[^{}]*margin\s*:\s*0(?:mm|px|cm)?\s*[;}]|class="(?:cert|ex-cv)[ "]/i.test(h);
  }
  function load(src) { return new Promise(function (ok) { var i = new w.Image(); i.onload = function () { ok(i); }; i.onerror = function () { ok(null); }; i.src = src; }); }
  function signataire() {
    var I = {}, nom = '', role = '';
    try { I = (w.EXBId && w.EXBId.get()) || {}; } catch (e) { }
    nom = I.dg || ''; role = I.dgRole || 'Directeur Général';
    try { var O = w.EXBOperateur; if (O && O.remplace && O.remplace()) { nom = (O.get() || {}).nom || nom; role = O.sigLabel() || role; } } catch (e) { }
    return { I: I, nom: nom, role: role };
  }
  /* bloc « fonction + visa + nom » en une seule image (marge de la page ou tampon sur le PDF) */
  function blocVisa(visa, S) {
    return (visa ? load(visa) : Promise.resolve(null)).then(function (im) {
      var W = 250, H = 150, c = d.createElement('canvas'); c.width = W * 3; c.height = H * 3;
      var x = c.getContext('2d'); x.scale(3, 3); x.textAlign = 'center'; x.fillStyle = '#173565';
      x.font = 'bold 13px Arial'; x.fillText(String(S.role).slice(0, 36), W / 2, 14);
      if (im) { var k = Math.min(220 / im.width, 104 / im.height); x.drawImage(im, (W - im.width * k) / 2, 22 + (104 - im.height * k) / 2, im.width * k, im.height * k); }
      x.fillStyle = '#172033'; x.font = 'bold 12px Arial'; x.fillText(String(S.nom).slice(0, 40), W / 2, 143);
      return c.toDataURL('image/png');
    });
  }
  function transformer(titre, h, choix, visa, o) {
    var S = signataire(), I = S.I;
    return blocVisa(visa, S).then(function (bloc) {
      /* le visa n'apparaît qu'une fois : les images de visa déjà posées en fin de document sont retirées */
      try {
        var doc = new w.DOMParser().parseFromString(h, 'text/html'), n = 0;
        Array.prototype.forEach.call(doc.querySelectorAll('img'), function (im) { if (im.matches('img.sg,img.st,img.exb-visa') || (visa && im.getAttribute('src') === visa)) { im.remove(); n++; } });
        if (n) h = '<!doctype html>' + doc.documentElement.outerHTML;
      } catch (e) { }
      var page = /@page[^{]*\{[^}]*?size\s*:[^;}]*landscape/i.test(h) || (o && o.landscape), ph = page ? 210 : 297;
      var m = /@page\s*\{[^}]*?margin\s*:\s*([^;}@]+)/i.exec(h), v = m ? m[1].trim().split(/\s+/).map(function (t) { var n = parseFloat(t) || 0; return /cm$/.test(t) ? n * 10 : /px$/.test(t) ? n * 25.4 / 96 : n; }) : [12];
      var mt = v[0], mr = v[1] === undefined ? v[0] : v[1], mb = v[2] === undefined ? v[0] : v[2];
      var chrome = /Chrome\/(\d+)/.exec((w.navigator && w.navigator.userAgent) || ''), tampon = !!(w.exbDesktop && chrome && +chrome[1] < 131);
      var BH = 42, BW = 70, css = '[data-exb-fill]{min-height:0!important}', cover = '';
      var num = '"Page " counter(page) " / " counter(pages)';
      if (!tampon && h.indexOf('counter(pages)') < 0) css += '@page{@bottom-right{content:' + num + ';font:8pt Arial,sans-serif;color:#173565}}';
      if (choix === 'avec') {
        var date = new Date().toLocaleDateString('fr-FR');
        cover = '<section data-exb-cover="1" style="height:' + (ph - mt - mb - 4) + 'mm;box-sizing:border-box;border:3mm solid #173565;outline:.6mm solid #c49a38;outline-offset:-5mm;padding:14mm 14mm 10mm;display:flex;flex-direction:column;align-items:center;text-align:center;font-family:Arial,sans-serif;color:#173565;break-after:page;page-break-after:always;overflow:hidden;-webkit-print-color-adjust:exact;print-color-adjust:exact">'
          + '<div style="font-size:22pt;font-weight:800;text-transform:uppercase">' + esc(I.name || 'Excellencia Building') + '</div>'
          + (I.tagline ? '<div style="font-size:10pt;color:#6b7280;margin-top:1mm">' + esc(I.tagline) + '</div>' : '')
          + (I.logo ? '<img src="' + esc(I.logo) + '" alt="" style="max-height:' + (page ? 34 : 55) + 'mm;max-width:80mm;margin-top:' + (page ? 4 : 14) + 'mm;object-fit:contain">' : '')
          + '<div style="font-size:21pt;font-weight:800;text-transform:uppercase;margin-top:' + (page ? 6 : 20) + 'mm;border-top:.5mm solid #c49a38;border-bottom:.5mm solid #c49a38;padding:4mm 8mm">' + esc(titre || 'Document') + '</div>'
          + '<div style="margin-top:auto;width:100%;display:flex;justify-content:space-between;align-items:flex-end"><div style="font-size:9pt;color:#172033;text-align:left">' + esc('Fait à ' + (I.city || '…………') + ', le ' + date) + '</div><img src="' + bloc + '" alt="Visa et signature" style="width:' + BW + 'mm;height:' + BH + 'mm"></div></section>';
      } else {
        css += '@page :first{margin-bottom:' + (mb + BH + 3) + 'mm}';
        if (!tampon) {
          var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="265" height="159"><image href="' + bloc + '" width="265" height="159"/></svg>';
          css += '@page :first{@bottom-right{content:url("data:image/svg+xml;base64,' + w.btoa(svg) + '") "\\A " ' + num + ';white-space:pre;text-align:right;font:8pt Arial,sans-serif;color:#173565}}';
        }
      }
      var st = '<style data-exb-garde="1">' + css + '</style>', i = h.toLowerCase().lastIndexOf('</head>');
      h = i >= 0 ? h.slice(0, i) + st + h.slice(i) : st + h;
      if (cover) { var b = /<body[^>]*>/i.exec(h); h = b ? h.slice(0, b.index + b[0].length) + cover + h.slice(b.index + b[0].length) : cover + h; }
      return { html: h, stamp: tampon ? { visa: choix === 'avec' ? '' : bloc, visaW: BW, visaH: BH, right: mr, bottom: mb } : null };
    });
  }
  function html(titre, h, o) {
    var tel = { html: h, stamp: null };
    if (!eligible(titre, h, o)) return Promise.resolve(tel);
    return ask(titre).then(function (choix) {
      var v = o && o.sign === false || !w.EXBSign ? Promise.resolve('') : Promise.resolve((w.EXBSign.anyVisa || w.EXBSign.visa)('png')).catch(function () { return ''; });
      return v.then(function (visa) { return transformer(titre, h, choix, visa, o); });
    }).catch(function () { return tel; });
  }
  P.make = make;
  w.EXBGARDE = { ask: ask, html: html, set: function (v) { ls(KEY, v); }, get: function () { return ls(KEY) || 'ask'; }, version: 'V245v' };
})(typeof window !== 'undefined' ? window : globalThis);
