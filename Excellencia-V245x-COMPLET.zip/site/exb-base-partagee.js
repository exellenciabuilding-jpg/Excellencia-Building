/* V236e — Paramètres › Infrastructure numérique › « Base de données partagée ».
 * Jusqu'ici, la base partagée (liaison à l'entreprise, rôle, synchronisation, code d'invitation) ne s'ouvrait que par la pastille
 * flottante « 🗄 », visible sur l'écran de connexion / d'accueil. On l'ajoute comme une vraie rubrique, à côté de « Synchronisation ». */
(function (w, d) {
  'use strict';
  var $ = function (i) { return d.getElementById(i); };
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function info() { try { return w.EXBDB && w.EXBDB.info ? w.EXBDB.info() : null; } catch (e) { return null; } }
  function isIn() { try { return !!(w.exbSb && w.exbSb.isIn && w.exbSb.isIn()); } catch (e) { return false; } }
  function render() {
    var el = $('basePartagee'); if (!el) return;
    var i = info() || {}, h = '<div class="card"><h2>🗄 Base de données partagée</h2>'
      + '<p class="localhint">Les fiches de l’entreprise (reçus, paiements, factures, caisse…) sont partagées entre les membres selon leur fonction. Ici : liaison à l’entreprise, rôle, synchronisation et code d’invitation.</p>';
    if (!isIn()) h += '<p class="ann">Compte en ligne non connecté : connectez-vous d’abord dans « ☁️ Synchronisation ».</p>';
    else if (!i.org) h += '<p class="ann">Cet appareil n’est pas encore relié à une entreprise.</p>';
    else h += '<p class="valid">✓ Relié à l’entreprise · rôle : <b>' + esc(i.role || '—') + '</b> · fonction : <b>' + esc(i.label || i.fonction || '—') + '</b></p>';
    h += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button class="primary" id="bp_open">🗄 Ouvrir la base partagée</button>'
      + (i.org ? '<button class="muted" id="bp_sync">🔄 Synchroniser maintenant</button>' : '') + '</div></div>';
    el.innerHTML = h;
    var o = $('bp_open'); if (o) o.onclick = function () { try { w.EXBDB.panel(); } catch (e) {} };
    var s = $('bp_sync'); if (s) s.onclick = function () { try { w.EXBDB.now(); } catch (e) {} s.textContent = '⏳ …'; setTimeout(render, 2500); };
  }
  function mount() {
    if ($('basePartagee')) return true;
    var adm = $('administration'), anchor = $('bcloud');
    if (!adm || !anchor) return false;
    adm.insertAdjacentHTML('afterend', '<section id="basePartagee" class="no-print" style="display:none"></section>');
    anchor.insertAdjacentHTML('afterend', ' <button id="bbase" onclick="show(\'basePartagee\')">🗄 Base partagée</button>');
    var os = w.show;
    w.show = function (x) { var r = os.apply(this, arguments); var el = $('basePartagee'); if (el) el.style.display = x === 'basePartagee' ? '' : 'none'; if (x === 'basePartagee') render(); return r; };
    return true;
  }
  var t = 0, iv = setInterval(function () { if (mount() || ++t > 60) clearInterval(iv); }, 1500);
})(window, document);
