-- ===== Excellencia Building V221e : RÉPARE « Code d'invitation inconnu » pour les codes PERSONNELS + abonnement jamais périmé =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, dans le projet de l'APPLICATION. Réexécutable sans danger. Ne supprime aucune donnée.
-- Prérequis : migration-v205v-codes-personnels.sql déjà exécutée (codes personnels).
--
-- Pourquoi : migration-v221c remplaçait la fonction « activer_par_invitation » par une version qui ne connaît QUE le code d'entreprise.
-- Or, depuis v205v, cette fonction sert d'aiguillage : elle reconnaît d'abord un code PERSONNEL (table codes_membres), puis appelle
-- « activer_par_invitation_org » pour le code d'entreprise. Après v221c, tous les codes personnels étaient donc refusés (« Code d'invitation inconnu »).
-- Ici : la logique v221c (abonnement valide) va dans « activer_par_invitation_org », et l'aiguillage v205v est remis en place.

do $$ begin
  if to_regclass('public.codes_membres') is null or to_regprocedure('activer_par_invitation_org(text)') is null then
    raise exception 'Exécutez d''abord supabase/migration-v205v-codes-personnels.sql (codes personnels), puis relancez ce fichier.';
  end if;
end $$;

create or replace function jeton_perime(t text) returns boolean
language plpgsql stable as $$
declare b text; j json; e timestamptz; g int;
begin
  if t is null then return false; end if;
  b := translate(split_part(t, '.', 1), '-_', '+/');
  b := b || repeat('=', (4 - length(b) % 4) % 4);
  j := convert_from(decode(b, 'base64'), 'UTF8')::json;
  e := (j->>'exp')::timestamptz;
  g := coalesce((j->>'grace')::int, 7);
  if e is null then return false; end if;
  return e + make_interval(days => g) <= now();
exception when others then return false;   -- illisible : on laisse le logiciel décider (il vérifie la signature)
end $$;


-- Logique d'entreprise (abonnement encore valide)
create or replace function activer_par_invitation_org(p_code text) returns json
language plpgsql security definer set search_path=public as $$
declare c text; o organisations; tok text; stat text; a_lic boolean := false; fails int; choix text;
begin
  c := lower(trim(coalesce(p_code, '')));
  delete from activations_invitation_essais where essai_le < now() - interval '1 day';
  select count(*) into fails from activations_invitation_essais where essai_le > now() - interval '10 minutes';
  if fails >= 40 then
    return json_build_object('ok', false, 'msg', 'Trop d’essais. Réessayez dans quelques minutes.'); end if;
  if c !~ '^[a-z0-9]{4,32}$' then
    insert into activations_invitation_essais default values;
    return json_build_object('ok', false, 'msg', 'Code d’invitation invalide : 8 caractères (lettres et chiffres).'); end if;
  select * into o from organisations where code_invitation = c;
  if not found then
    insert into activations_invitation_essais default values;
    return json_build_object('ok', false, 'msg', 'Code d’invitation inconnu. Vérifiez-le auprès de la personne qui vous a invité(e).'); end if;
  if to_regclass('public.licences_clients') is not null then
    execute 'select statut, dernier_jeton from licences_clients where org_id=$1 order by cree_le desc limit 1'
      into stat, tok using o.id;
    a_lic := stat is not null;
    if a_lic and stat in ('suspendu', 'resilie') then
      return json_build_object('ok', false, 'msg', 'Abonnement suspendu : contactez l’administrateur du logiciel.'); end if;
  end if;
  -- 1) abonnement d'équipe s'il est encore valide ; 2) sinon celui du client à code s'il est encore valide
  choix := null;
  if o.jeton_equipe is not null and not jeton_perime(o.jeton_equipe) then choix := o.jeton_equipe;
  elsif tok is not null and not jeton_perime(tok) then choix := tok;
  end if;
  if choix is null then
    if tok is null and o.jeton_equipe is null then
      return json_build_object('ok', false, 'msg', 'Aucun abonnement n’est encore enregistré pour cette entreprise. Demandez à l’administrateur d’ouvrir le panneau « Équipe » sur son appareil, ou de vous envoyer un lien d’activation.');
    end if;
    return json_build_object('ok', false, 'msg', 'L’abonnement enregistré pour l’équipe est périmé (ce n’est pas votre faute). Prévenez l’administrateur : il doit ouvrir le panneau « Équipe » sur son appareil, connecté à « 🔑 Licences », pour le renouveler.');
  end if;
  return json_build_object('ok', true, 'nom', o.nom, 'jeton', choix);
end $$;

-- Aiguillage (identique à v205v) : code personnel d'abord, sinon code d'entreprise
create or replace function activer_par_invitation(p_code text) returns json
language plpgsql security definer set search_path=public as $$
declare c text := lower(trim(coalesce(p_code,''))); pc codes_membres; oc text;
begin
  select * into pc from codes_membres where code = c;
  if found then
    if pc.revoque_le is not null then
      return json_build_object('ok', false, 'msg', 'Ce code n’est plus valide. Demandez un nouveau code à l’administrateur de l’entreprise.'); end if;
    select code_invitation into oc from organisations where id = pc.org_id;
    return activer_par_invitation_org(oc);
  end if;
  return activer_par_invitation_org(p_code);
end $$;

revoke execute on function activer_par_invitation_org(text) from public, anon, authenticated;
revoke execute on function activer_par_invitation(text) from public;
grant  execute on function activer_par_invitation(text) to anon, authenticated;
notify pgrst, 'reload schema';

-- Contrôle : doit afficher 2 lignes « OK »
select 'activer_par_invitation (aiguillage)' as nom, case when to_regprocedure('activer_par_invitation(text)') is not null then 'OK' else 'MANQUANT' end as etat
union all select 'activer_par_invitation_org (v221c)', case when to_regprocedure('activer_par_invitation_org(text)') is not null then 'OK' else 'MANQUANT' end;
