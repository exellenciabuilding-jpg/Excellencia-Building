-- Excellencia Building V244 — SÉCURISATION SERVEUR (étape 3) : ferme l'écriture directe sur « enregistrements » (contrôle S4 de tests-securite-v242.sql).
-- Principe de l'étude V238 §6 : toute écriture passe par enregistrer() (SECURITY DEFINER : contrôle peut(), licence, conflit de version, journal) — jamais par une politique d'écriture directe.
-- Vérifié dans le code : le client (exb-db.js) ne fait que LIRE /rest/v1/enregistrements ; il écrit via enregistrer(). Supprimer les politiques d'écriture directe ne bloque donc pas l'application.
-- Ce fichier : (1) diagnostic en lecture seule, (2) sauvegarde des politiques, (3) correction APRÈS confirmation explicite, (4) re-contrôle S4 / S11, (5) retour arrière.
-- Le contrôle S11 (droits plus larges que la matrice) se règle par migration-v242b puis migration-v243b (aperçu → 'OUI'), PAS par ce fichier : exécutez-les AVANT, sur la copie de recette.
-- ORDRE : v242 → v243 → (v242b, v243b après lecture de leur aperçu) → CE FICHIER. Réexécutable. NON exécuté sur un vrai Supabase : essayer d'abord sur la copie / le projet de recette.
do $$ begin
  if to_regclass('public.enregistrements') is null then raise exception 'La table enregistrements est absente'; end if;
  if to_regprocedure('public.peut(uuid,text,boolean)') is null then raise exception 'La fonction peut() est absente : exécutez migration-v99zn-synchro-modules.sql'; end if;
  if to_regprocedure('public.enregistrer(uuid,text,text,jsonb,integer,boolean)') is null then raise exception 'La fonction enregistrer() est absente : exécutez migration-v99zo / v226'; end if;
end $$;

-- ---------- 1. Diagnostic (lecture seule) ----------
-- 1a. Politiques d'écriture directe sur enregistrements (S4 : doit être vide pour réussir)
select policyname, cmd, roles, qual, with_check
  from pg_policies where schemaname = 'public' and tablename = 'enregistrements' and cmd in ('INSERT', 'UPDATE', 'DELETE', 'ALL');
-- 1b. enregistrer() est-elle bien SECURITY DEFINER ? (doit être true : sinon NE PAS appliquer la suite)
select proname, prosecdef as security_definer from pg_proc where proname = 'enregistrer' and pronamespace = 'public'::regnamespace;
-- 1c. Privilèges d'écriture directe accordés aux rôles de l'API sur enregistrements
select grantee, privilege_type from information_schema.role_table_grants
 where table_schema = 'public' and table_name = 'enregistrements' and grantee in ('anon', 'authenticated') and privilege_type in ('INSERT', 'UPDATE', 'DELETE', 'TRUNCATE');

-- ---------- 2. Sauvegarde des politiques (créée une seule fois, invisible depuis l'API) ----------
create table if not exists politiques_sauv_v244(
  table_name text not null, policyname text not null, permissive text, roles text, cmd text, qual text, with_check text, sauvegarde_le timestamptz not null default now(),
  primary key (table_name, policyname));
alter table politiques_sauv_v244 enable row level security;   -- aucune politique : lisible seulement dans le SQL Editor
insert into politiques_sauv_v244(table_name, policyname, permissive, roles, cmd, qual, with_check)
select tablename, policyname, permissive, roles::text, cmd, qual, with_check
  from pg_policies where schemaname = 'public' and tablename = 'enregistrements'
on conflict (table_name, policyname) do nothing;

-- ---------- 3. Correction (rien n'est modifié tant que la ligne ci-dessous reste à 'NON') ----------
select set_config('exb.confirmer', 'NON', false);   -- ← remplacez 'NON' par 'OUI' pour appliquer
do $$
declare p record; n int := 0;
begin
  if coalesce(current_setting('exb.confirmer', true), 'NON') <> 'OUI' then
    raise notice 'V244 : aperçu seulement (exb.confirmer <> OUI) : rien n''a été modifié.'; return;
  end if;
  -- Garde-fous : on ne ferme l'écriture directe que si le chemin sûr existe.
  if not coalesce((select prosecdef from pg_proc where proname = 'enregistrer' and pronamespace = 'public'::regnamespace limit 1), false) then
    raise exception 'V244 : enregistrer() n''est pas SECURITY DEFINER : l''écriture serait bloquée. Rien n''a été modifié.'; end if;
  if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'enregistrements' and policyname = 'enr_lire' and qual ilike '%peut(%') then
    raise exception 'V244 : la politique de lecture enr_lire (via peut()) est absente : exécutez migration-v66-roles.sql. Rien n''a été modifié.'; end if;
  -- Supprime les politiques d'écriture directe (la lecture enr_lire est conservée)
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'enregistrements' and cmd in ('INSERT', 'UPDATE', 'DELETE', 'ALL') loop
    execute format('drop policy %I on public.enregistrements', p.policyname); n := n + 1;
  end loop;
  -- Défense en profondeur : plus de privilège d'écriture directe pour les rôles de l'API (enregistrer() s'exécute avec les droits du propriétaire)
  revoke insert, update, delete, truncate on public.enregistrements from anon, authenticated;
  raise notice 'V244 : % politique(s) d''écriture directe supprimée(s) ; privilèges d''écriture directe retirés.', n;
end $$;

-- ---------- 4. Re-contrôle (à lire après exécution) ----------
with s(n, controle, ok) as (values
 ('S3',  'La lecture des fiches passe toujours par peut()', exists(select 1 from pg_policies where tablename = 'enregistrements' and policyname = 'enr_lire' and qual ilike '%peut(%')),
 ('S4',  'Aucune politique d''écriture directe sur enregistrements', not exists(select 1 from pg_policies where tablename = 'enregistrements' and cmd in ('INSERT', 'UPDATE', 'DELETE', 'ALL'))),
 ('S4b', 'enregistrer() est SECURITY DEFINER', coalesce((select prosecdef from pg_proc where proname = 'enregistrer' and pronamespace = 'public'::regnamespace limit 1), false)),
 ('S4c', 'Aucun privilège d''écriture directe pour anon / authenticated', not exists(select 1 from information_schema.role_table_grants where table_schema = 'public' and table_name = 'enregistrements' and grantee in ('anon', 'authenticated') and privilege_type in ('INSERT', 'UPDATE', 'DELETE', 'TRUNCATE'))),
 ('S11', 'Aucun droit plus large que la matrice (règle par v242b + v243b)', not exists(select 1 from droits_fonction d left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
          where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur')
            and d.collection in (select collection from droits_matrice_v242 where fonction in ('direction','comptable','architecte','bureau_etudes','conducteur','chef_projet','rh','magasinier','formateur')) and (m.fonction is null or (m.ecrire = false and d.ecrire = true))))
)
select n as controle, controle as description, case when ok then 'OK' else 'ÉCHEC' end as resultat from s order by n;

-- ---------- 5. Retour arrière (état d'avant V244) ----------
--   grant insert, update, delete on public.enregistrements to authenticated;
--   do $$ declare p record; begin
--     for p in select * from politiques_sauv_v244 where table_name = 'enregistrements' and cmd in ('INSERT', 'UPDATE', 'DELETE', 'ALL') loop
--       if not exists (select 1 from pg_policies where tablename = 'enregistrements' and policyname = p.policyname) then
--         execute format('create policy %I on public.enregistrements as %s for %s to %s %s %s', p.policyname, p.permissive, p.cmd,
--           replace(replace(p.roles, '{', ''), '}', ''),
--           case when p.qual is null then '' else 'using (' || p.qual || ')' end,
--           case when p.with_check is null then '' else 'with check (' || p.with_check || ')' end);
--       end if;
--     end loop; end $$;
