-- ===== Excellencia Building V221f : la FONCTION choisie dans l'invitation est appliquée quand la personne entre avec son code personnel =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, dans le projet de l'APPLICATION. Réexécutable sans danger. Ne supprime aucune donnée.
-- Prérequis : migration-v205v-codes-personnels.sql (codes personnels) déjà exécutée.
--
-- Problème : si la personne existait déjà comme membre (essai précédent, ancienne connexion…), la création du membre ne faisait « rien »
-- (insert … on conflict do nothing) : elle gardait « Polyvalent » au lieu de la fonction choisie dans l'invitation (ex. Comptable).
-- Correctif : à l'entrée avec un code personnel, on applique le rôle et la fonction de l'invitation
--   - si l'invitation est neuve (pas encore utilisée), ou
--   - si la personne est encore « Polyvalent » alors que l'invitation en désigne une autre.
-- Un administrateur n'est jamais rétrogradé par ce mécanisme. Une fonction changée à la main dans « Équipe » n'est pas écrasée
-- (l'invitation est alors déjà utilisée et la fonction n'est plus « Polyvalent »).

do $$ begin
  if to_regclass('public.codes_membres') is null or to_regprocedure('rejoindre_organisation_org(text,text)') is null then
    raise exception 'Exécutez d''abord supabase/migration-v205v-codes-personnels.sql (codes personnels), puis relancez ce fichier.';
  end if;
end $$;

create or replace function rejoindre_organisation(p_code text, p_nom_user text default null) returns json
language plpgsql security definer set search_path=public as $$
declare c text := lower(trim(coalesce(p_code,''))); pc codes_membres; oc text; em text; r json;
        inv invitations_equipe; neuve boolean := false; cur membres; appliquer boolean := false;
begin
  select * into pc from codes_membres where code = c;
  if not found then return rejoindre_organisation_org(p_code, p_nom_user); end if;
  if auth.uid() is null then raise exception 'non connecté'; end if;
  if pc.revoque_le is not null then raise exception 'code révoqué : demandez un nouveau code à l''administrateur'; end if;
  select lower(email) into em from auth.users where id = auth.uid();
  if em is distinct from pc.email then
    raise exception 'ce code est personnel : créez votre compte avec l''adresse e-mail invitée (%)', regexp_replace(pc.email, '^(.).*(@.*)$', '\1***\2'); end if;
  if not exists(select 1 from invitations_equipe where org_id=pc.org_id and email=pc.email and utilise_le is null)
     and not exists(select 1 from membres where org_id=pc.org_id and user_id=auth.uid()) then
    raise exception 'invitation annulée : demandez à l''administrateur de vous inviter de nouveau'; end if;
  -- invitation la plus récente pour cette adresse (avant l'entrée : l'entrée la marque « utilisée »)
  select * into inv from invitations_equipe where org_id=pc.org_id and email=pc.email order by cree_le desc limit 1;
  neuve := found and inv.utilise_le is null;
  select code_invitation into oc from organisations where id = pc.org_id;
  r := rejoindre_organisation_org(oc, p_nom_user);
  update codes_membres set user_id = auth.uid(), utilise_le = coalesce(utilise_le, now()) where id = pc.id;
  if inv.id is not null then
    select * into cur from membres where org_id=pc.org_id and user_id=auth.uid();
    if found and cur.role <> 'admin' then
      appliquer := neuve or (cur.fonction = 'polyvalent' and inv.fonction <> 'polyvalent');
      if appliquer and (cur.role is distinct from inv.role or cur.fonction is distinct from inv.fonction) then
        update membres set role = inv.role, fonction = inv.fonction where org_id=pc.org_id and user_id=auth.uid();
        r := json_build_object('id', r->>'id', 'nom', r->>'nom', 'role', inv.role, 'fonction', inv.fonction);
      end if;
    end if;
  end if;
  return r;
end $$;

revoke execute on function rejoindre_organisation(text,text) from public, anon;
grant  execute on function rejoindre_organisation(text,text) to authenticated;
notify pgrst, 'reload schema';

-- Contrôle : doit afficher « OK »
select 'rejoindre_organisation (v221f)' as nom, case when to_regprocedure('rejoindre_organisation(text,text)') is not null then 'OK' else 'MANQUANT' end as etat;
