-- ===== Excellencia Building — V236 : RAPPORTS DE MATÉRIAUX synchronisés entre espaces =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v66-roles.sql (et migration-v235-bons-paiement.sql si déjà utilisée).
-- Additive et réexécutable sans danger (on conflict do nothing) : aucun droit déjà personnalisé n'est modifié.
--
-- Nouvelle collection partagée « rapports_materiaux » (clé locale exb_rapports_materiaux ; fiche par fiche, détection de conflit, journal) :
--   le magasinier fait le rapport (réception, consommation, état du stock) ;
--   le conducteur / chef de projet le retrouve dans l'Espace Chantier, le vérifie et peut le compléter ;
--   la direction et le comptable le consultent ; le bureau d'études et l'architecte le lisent.
-- Règles : administrateur = tout ; « polyvalent » = tout (collection non sensible) ;
--          autres fonctions = uniquement les lignes ci-dessous (absence de ligne = refus). Un lecteur n'écrit jamais.

do $$ begin
  if to_regclass('public.droits_fonction') is null then
    raise exception 'Exécutez d''abord migration-v66-roles.sql.';
  end if;
end $$;

insert into droits_fonction(fonction, collection, lire, ecrire) values
 ('magasinier',    'rapports_materiaux', true, true),    -- fait le rapport, le synchronise, l'exporte en PDF
 ('direction',     'rapports_materiaux', true, true),
 ('chef_projet',   'rapports_materiaux', true, true),    -- vérifie / valide (Espace Chantier)
 ('conducteur',    'rapports_materiaux', true, true),    -- réception et consommation sur le chantier
 ('comptable',     'rapports_materiaux', true, false),   -- lecture : rapprochement avec les factures fournisseurs
 ('bureau_etudes', 'rapports_materiaux', true, false),   -- lecture
 ('architecte',    'rapports_materiaux', true, false)    -- lecture
on conflict (fonction, collection) do nothing;

-- Vérification :
--   select fonction, collection, lire, ecrire from droits_fonction where collection = 'rapports_materiaux' order by 1;
-- Attendu : 7 lignes (architecte, bureau_etudes, chef_projet, comptable, conducteur, direction, magasinier).
