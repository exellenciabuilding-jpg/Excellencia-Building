-- ===== Excellencia Building — V235 : BONS DE PAIEMENT synchronisés entre espaces =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v205-lot10-guichet-a-distance.sql.
-- Additive et réexécutable sans danger (on conflict do nothing) : aucun droit déjà personnalisé n'est modifié.
--
-- Nouvelle collection partagée « bons_paiement » (fiche par fiche, détection de conflit, journal) :
--   l'ingénieur, l'architecte ou le conducteur fait le bon ; le comptable le retrouve au guichet, l'encaisse
--   (le bon passe à PAYÉ) ; l'auteur voit le statut changer sur son propre appareil.
-- Les encaissements restent dans « guichet_encaissements » (déjà synchronisés, V205p).

do $$ begin
  if to_regclass('public.droits_fonction') is null then
    raise exception 'Exécutez d''abord migration-v66-roles.sql.';
  end if;
end $$;

insert into droits_fonction(fonction, collection, lire, ecrire) values
 ('comptable',     'bons_paiement', true, true),   -- retrouve le bon, l'encaisse, met le statut à jour
 ('direction',     'bons_paiement', true, true),
 ('chef_projet',   'bons_paiement', true, true),
 ('conducteur',    'bons_paiement', true, true),   -- chantiers
 ('bureau_etudes', 'bons_paiement', true, true),   -- ingénierie
 ('architecte',    'bons_paiement', true, true)    -- architecture
on conflict (fonction, collection) do nothing;

-- Vérification : select fonction, collection, lire, ecrire from droits_fonction where collection = 'bons_paiement' order by 1;
