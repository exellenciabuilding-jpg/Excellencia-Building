-- ===== Excellencia Building V221g : la fonction de l'invitation est appliquée MÊME si le compte a déjà été créé « Polyvalent » =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, dans le projet de l'APPLICATION. Réexécutable sans danger. Ne supprime aucune donnée.
--
-- Problème : à la création du compte, l'entrée dans l'entreprise pouvait se faire AVANT la prise en compte de l'invitation
-- (elle crée alors le membre « Polyvalent »). Ensuite « equipe_reclamer » trouvait le membre déjà là et ne changeait RIEN
-- (on conflict do nothing) : l'invité restait « Polyvalent » au lieu de « Comptable », et voyait « Accès refusé à cet espace ».
-- Correctif : equipe_reclamer applique le rôle et la fonction de l'invitation à un membre encore « Polyvalent ».
-- Un administrateur n'est jamais modifié. Un membre dont la fonction a déjà été choisie n'est pas touché.

create or replace function equipe_reclamer() returns json
language plpgsql security definer set search_path=public as $$
declare em text; i record; res json := '[]'::json; n int; mx int;
begin
  if auth.uid() is null then return res; end if;
  select lower(email) into em from auth.users where id=auth.uid();
  for i in select * from invitations_equipe where email=em and utilise_le is null loop
    if to_regclass('public.licences_clients') is not null then
      execute 'select max_utilisateurs from licences_clients where org_id=$1 order by cree_le desc limit 1' into mx using i.org_id;
      select count(*) into n from membres where org_id=i.org_id;
      if mx is not null and n>=mx and not exists(select 1 from membres where org_id=i.org_id and user_id=auth.uid()) then continue; end if;
    end if;
    insert into membres(org_id,user_id,nom,role,fonction) values (i.org_id,auth.uid(),i.nom,i.role,i.fonction)
      on conflict (org_id,user_id) do update set role=excluded.role, fonction=excluded.fonction
      where membres.role <> 'admin' and membres.fonction = 'polyvalent';
    update invitations_equipe set utilise_le=now() where id=i.id;
  end loop;
  return (select coalesce(json_agg(json_build_object('id',o.id,'nom',o.nom)),'[]'::json)
          from membres m join organisations o on o.id=m.org_id where m.user_id=auth.uid());
end $$;

revoke execute on function equipe_reclamer() from public, anon;
grant  execute on function equipe_reclamer() to authenticated;

-- Réparation des comptes déjà créés « Polyvalent » alors que leur invitation (utilisée depuis moins de 3 jours) désignait une autre fonction
update membres m set role = i.role, fonction = i.fonction
from invitations_equipe i join auth.users u on lower(u.email) = i.email
where m.org_id = i.org_id and m.user_id = u.id
  and m.role <> 'admin' and m.fonction = 'polyvalent' and i.fonction <> 'polyvalent'
  and i.utilise_le is not null and i.utilise_le > now() - interval '3 days';

notify pgrst, 'reload schema';

-- Contrôle : liste les membres et leur fonction (la colonne « fonction » doit être celle choisie à l'invitation)
select u.email, m.role, m.fonction, m.depuis::date as depuis
from membres m join auth.users u on u.id = m.user_id
order by m.depuis desc limit 10;
