-- Excellencia Building — DIAGNOSTIC S11 (lecture seule : ne modifie rien).
-- Liste exactement ce que le contrôle S11 de tests-securite-v242.sql reproche : les droits de fonction PLUS LARGES que la matrice.
--   RETIRÉ            = la fonction a un droit sur cette collection que la matrice refuse (« — »).
--   ÉCRITURE RETIRÉE  = la matrice limite à « L » (lecture seule) mais la fonction peut encore écrire.
-- S11 passe à OK quand cette requête ne renvoie plus aucune ligne.
-- Pour les corriger : migration-v242b-restriction-optionnelle.sql PUIS migration-v243b-restriction-optionnelle.sql
--   (lire l'aperçu, essayer sur la copie de recette, puis passer exb.confirmer de 'NON' à 'OUI'). Retour arrière prévu en bas de chaque fichier.
select d.fonction, d.collection,
       case when m.fonction is null then 'RETIRÉ' else 'ÉCRITURE RETIRÉE' end as action,
       d.lire as lire_actuel, d.ecrire as ecrire_actuel
  from droits_fonction d
  left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
 where d.fonction in ('direction','comptable','architecte','bureau_etudes','conducteur','chef_projet','rh','magasinier','formateur')
   and d.collection in (select collection from droits_matrice_v242 where fonction in ('direction','comptable','architecte','bureau_etudes','conducteur','chef_projet','rh','magasinier','formateur'))
   and (m.fonction is null or (m.ecrire = false and d.ecrire = true))
 order by d.collection, d.fonction;
