/* Excellencia Building — ATELIER DE MISE EN PAGE · app.js (interface). Assemble les modules EXBDOC : import → analyse → classement → modèle → configuration → aperçu → export → archivage. */
(function () {
  'use strict';
  var D = window.EXBDOC, C = D.cartouche, L = D.layout, V = D.version, X = D.exporter, AN = D.analysis, IM = D.importer, PV = D.preview, OC = D.ocr, PL = window.PDFLib;
  var $ = function (i) { return document.getElementById(i); }, host = null; try { host = parent !== window ? parent : null; } catch (e) { host = null; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var S = { screen: 'atelier', cur: null, sel: {}, mem: {}, vue: 'apres', page: 0, zoom: 1, rot: 0, plan: null, after: null, afterPdf: null, origPdf: {}, pdfjs: null, tok: 0, dtok: 0, logo: null, ent: { nom: 'Excellencia Building', slogan: '' }, tm: null, busy: '', lastWarns: [] };
  var ST = { 'Brouillon': 'st-Brouillon', 'Pour vérification': 'st-Pour', 'À corriger': 'st-Acorr', 'Approuvé': 'st-Appr', 'Émis': 'st-Emis' };

  /* ---------------------------------------------------------------- utilitaires ---------------------------------------------------------------- */
  function toast(m, k) { var t = document.createElement('div'); t.className = 'toast ' + (k || ''); t.textContent = m; t.setAttribute('role', 'status'); document.body.appendChild(t); setTimeout(function () { t.remove(); }, k === 'err' ? 7000 : 3500); }
  function jget(k, def) { try { var S0 = host && host.exbStorage; var r = S0 ? S0.getItem(k) : localStorage.getItem(k); return r ? JSON.parse(r) : def; } catch (e) { return def; } }
  function fdate(t) { try { var d = new Date(t); return C.dateFr(t) + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); } catch (e) { return ''; } }
  function fsize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function chip(st) { return '<span class="chip ' + (ST[st] || '') + '">' + esc(st) + '</span>'; }
  function cur() { return S.cur ? V.getDoc(S.cur) : null; }
  function liste() { return V.docs().filter(V.visible).sort(function (a, b) { return b.importeLe - a.importeLe; }); }
  function locked(d) { return !!d && d.statut !== 'Brouillon' && d.statut !== 'À corriger'; }
  function modal(titre, html, boutons) {
    return new Promise(function (res) {
      var dlg = $('dlg'), f = $('dform'), fini = false;
      f.innerHTML = '<h3>' + esc(titre) + '</h3>' + html + '<div class="acts" style="justify-content:flex-end">' + boutons.map(function (b, i) { return '<button class="btn ' + (b.c || '') + '" type="button" data-i="' + i + '">' + esc(b.t) + '</button>'; }).join('') + '</div>';
      function done(i) { if (fini) return; fini = true; var v = {}; f.querySelectorAll('[name]').forEach(function (el) { v[el.name] = el.type === 'checkbox' ? el.checked : el.value; }); try { dlg.close(); } catch (e) {} res({ i: i, v: v }); }
      f.querySelectorAll('button[data-i]').forEach(function (b) { b.onclick = function () { done(+b.getAttribute('data-i')); }; });
      dlg.oncancel = function (e) { e.preventDefault(); done(-1); }; dlg.showModal();
    });
  }
  function dl(bytes, name, type) { var b = new Blob([bytes], { type: type || 'application/pdf' }), u = URL.createObjectURL(b), a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 4000); }
  function slug(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, ''); }
  async function pdfjs() { if (S.pdfjs) return S.pdfjs; var m = await import('../pdfjs/pdf.min.mjs'); m.GlobalWorkerOptions.workerSrc = '../pdfjs/pdf.worker.min.mjs'; S.pdfjs = m; return m; }
  function progress(txt, p) { var n = $('vNote'); if (n) n.innerHTML = txt ? esc(txt) + (p != null ? '<div class="pbar"><i style="width:' + Math.round(p * 100) + '%"></i></div>' : '') : ''; }
  async function nomActeur(titre) {
    var a = V.actor().nom; if (a) return a;
    var r = await modal(titre || 'Identification', '<label class="f">Votre nom et fonction (mention nominative, pas une signature électronique)<input name="n" value="" autocomplete="name" placeholder="Ir Prénom Nom"></label>', [{ t: 'Annuler' }, { t: 'Valider', c: 'pri' }]);
    var n = r.i === 1 ? String(r.v.n || '').trim() : ''; if (n) V.setNom(n); return n;
  }

  /* ---------------------------------------------------------------- identité, logo, projets ---------------------------------------------------------------- */
  async function chargerIdentite() {
    var I = {}; try { I = (host && host.EXBId && host.EXBId.get()) || {}; } catch (e) {}
    var nm = I.name || 'Excellencia Building', eb = /excellencia\s+building/i.test(nm), url = I.logo || (eb ? '../assets/carte/logo-officiel.jpg' : '');
    S.ent = { nom: nm, slogan: I.tagline || 'Bureau d’études — Ingénieur', tagline: I.tagline || '', city: I.city || '', phone: I.phone || '', email: I.email || '', address: I.address || '', contact: ((host && host.EXBId && host.EXBId.contactLine && host.EXBId.contactLine(I)) || '').replace(/\s{2,}/g, ' ') };
    /* V236g : visa / cachet de l'administrateur (repris dans le cartouche des plans, versions approuvées ou émises seulement) */
    try { if (host && host.EXBId && host.EXBId.visa) { var vu = await host.EXBId.visa(); if (vu) { var vb = new Uint8Array(await (await fetch(vu)).arrayBuffer()); S.visa = { bytes: vb, type: (vb[0] === 0xFF && vb[1] === 0xD8) ? 'jpg' : 'png' }; } } } catch (e) { S.visa = null; }
    if (!url) return; try {
      var abs = /^(data:|https?:|blob:)/.test(url) ? url : new URL(url, (host && host.location) ? host.location.href : location.href).href;
      var buf = new Uint8Array(await (await fetch(abs)).arrayBuffer()), png = buf[0] === 0x89 && buf[1] === 0x50, jpg = buf[0] === 0xFF && buf[1] === 0xD8;
      if (!png && !jpg) { var im = new Image(); im.src = abs; await im.decode(); var cv = document.createElement('canvas'); cv.width = im.naturalWidth || 300; cv.height = im.naturalHeight || 150; cv.getContext('2d').drawImage(im, 0, 0); var bl = await new Promise(function (r) { cv.toBlob(r, 'image/png'); }); buf = new Uint8Array(await bl.arrayBuffer()); png = true; }
      S.logo = { bytes: buf, type: jpg ? 'jpg' : 'png' }; var el = $('logo'); el.src = abs; el.hidden = false;
    } catch (e) { S.logo = null; }
  }
  function projets() { var p = jget('exb_projects', []); return Array.isArray(p) ? p : []; }
  function pNom(p) { return p.nom || p.name || p.titre || p.title || ''; }

  /* ---------------------------------------------------------------- données en mémoire d'un document ---------------------------------------------------------------- */
  async function ensure(d, silencieux) {
    var m = S.mem[d.id] || (S.mem[d.id] = {});
    if (!m.bytes) { m.bytes = await V.getFile(d.sha256); if (!m.bytes) throw new Error('Original introuvable dans l’archive (' + d.nom + ').'); }
    if (!m.grilles) {
      var js = await pdfjs(), r = await AN.analyser(js, m.bytes, { motDePasse: m.pw, progress: function (i, n) { if (!silencieux) progress('Analyse de « ' + d.nom + ' » : page ' + i + ' / ' + n, i / n); } });
      if (r.besoinMotDePasse) {
        var q = await modal('PDF protégé — ' + d.nom, '<p class="note">' + (r.incorrect ? 'Mot de passe incorrect. ' : '') + 'Le mot de passe sert uniquement à l’analyse et à l’aperçu de cette session ; il n’est pas conservé. L’habillage d’un PDF chiffré reste impossible.</p><label class="f">Mot de passe<input name="pw" type="password" autocomplete="off"></label>', [{ t: 'Annuler' }, { t: 'Ouvrir', c: 'pri' }]);
        if (q.i !== 1) throw new Error('Mot de passe requis pour lire « ' + d.nom + ' ».'); m.pw = q.v.pw; return ensure(d, silencieux);
      }
      if (r.erreur) throw new Error(r.erreur);
      r.analyse.signe = !!d.signe; m.analyse = r.analyse; m.grilles = r.grilles; d.analyse = r.analyse; V.putDoc(d); progress('');
    }
    return m;
  }
  function devinerType(nom, an) {
    if (/note|calcul|\bnc[-_ ]/i.test(nom)) return 'note'; if (/rapport|report|etude|étude/i.test(nom)) return 'rapport'; if (/plan|coffrage|ferraillage|archi|detail|détail|pl[-_]/i.test(nom)) return 'plan';
    var p = an && an.pages && an.pages[0]; return p && p.format === 'A4' && p.texte ? 'note' : 'plan';
  }

  /* ---------------------------------------------------------------- import ---------------------------------------------------------------- */
  var ZONES = { auto: { log: 'impLog' }, plan: { log: 'logPlan', type: 'plan', lib: 'Plan d’exécution' }, note: { log: 'logNote', type: 'note', lib: 'Note de calcul' } }, rowSeq = 0;
  S.rows = { auto: [], plan: [], note: [] };
  /* V234c : liste des fichiers traités. Chaque ligne terminée peut être retirée de la liste (✕) : seul l'affichage est retiré, le document reste dans l'archive. */
  function paintLog(z) {
    var el = $(ZONES[z].log), rows = S.rows[z]; if (!el) return; if (!rows.length) { el.innerHTML = ''; return; }
    el.innerHTML = '<table><tr><th>Fichier</th><th>Résultat</th><th></th></tr>' + rows.map(function (r) {
      return '<tr><td>' + esc(r.nom) + '</td><td style="color:var(--' + (r.dup ? 'warn' : r.ok ? 'ok' : 'err') + ')">' + esc(r.msg) + '</td><td style="white-space:nowrap">'
        + (r.fini ? (r.id ? '<button class="btn sm" type="button" data-op="' + esc(r.id) + '">Ouvrir</button> ' : '') + '<button class="btn sm" type="button" data-rm="' + r.k + '" aria-label="Retirer ' + esc(r.nom) + ' de la liste">✕</button>' : '') + '</td></tr>';
    }).join('') + '</table>' + (rows.some(function (r) { return r.fini; }) ? '<div class="acts"><button class="btn sm" type="button" data-clr="1">Vider la liste</button><span class="note">Retire seulement l’affichage : les documents restent dans l’archive.</span></div>' : '');
  }
  function reclasser(d, type) {
    var old = d.classement.type, def = { plan: 'plan', note: 'note', rapport: 'rapport' }; d.classement.type = type;
    if (d.config && (!d.config.modele || d.config.modele === (def[old] || 'plan'))) d.config.modele = def[type] || d.config.modele;
    V.putDoc(d); V.log('reclasse', d, { detail: (C.TYPES[old] || old) + ' → ' + (C.TYPES[type] || type) });
  }
  /* z : 'auto' (onglet Importation, type deviné) | 'plan' | 'note' (onglet « Plans · Notes de calcul », type imposé). Un PDF déjà archivé (même SHA-256) n'est jamais réimporté. */
  async function importer(files, z) {
    z = ZONES[z] ? z : 'auto'; var Z = ZONES[z], rows = S.rows[z];
    if (!V.act('creer')) return toast('Votre profil n’a pas le droit d’importer des documents.', 'err');
    function paint() { paintLog(z); }
    function add(nom, msg) { var r = { k: ++rowSeq, nom: nom, ok: true, msg: msg, fini: false, id: '', dup: false }; rows.push(r); paint(); return r; }
    function fin(r, ok, msg, id, dup) { r.ok = ok; r.msg = msg; r.id = id || ''; r.dup = !!dup; r.fini = true; paint(); }
    var js = await pdfjs(), last = null, nNew = 0, nDup = 0;
    for (var i = 0; i < files.length; i++) {
      var f = files[i], r = await IM.lire(f); if (!r.ok) { fin(add(r.nom, ''), false, 'Refusé — ' + r.erreur); continue; }
      var row = add(r.nom, 'Vérification de l’archive…'), sha = await V.sha256(r.bytes), ex = V.docs().filter(function (x) { return x.sha256 === sha; })[0];
      if (ex) {
        nDup++; var vis = V.visible(ex), tEx = C.TYPES[ex.classement.type] || '', msg = 'Déjà dans l’archive' + (tEx ? ' (' + tEx + ')' : '') + ', importé le ' + fdate(ex.importeLe) + '. Non réimporté : l’original reste archivé, sans doublon.';
        if (!vis) { fin(row, true, 'Déjà dans l’archive (accès restreint à ce document). Non réimporté.', '', true); continue; }
        if (Z.type && ex.classement.type !== Z.type) {
          if (locked(ex)) msg += ' Reclassement impossible : le document est au statut « ' + ex.statut + ' ».';
          else {
            var qd = await modal('Déjà dans l’archive', '<p>« ' + esc(r.nom) + ' » est déjà archivé comme <b>' + esc(tEx) + '</b>. Le reclasser en <b>' + esc(Z.lib) + '</b> ?</p><p class="note">Aucun fichier n’est dupliqué ni modifié ; seul le classement change.</p>', [{ t: 'Laisser tel quel' }, { t: 'Reclasser', c: 'pri' }]);
            if (qd.i === 1) { reclasser(ex, Z.type); msg = 'Déjà dans l’archive : reclassé en « ' + Z.lib + ' ». Aucun doublon créé.'; }
          }
        }
        last = ex; fin(row, true, msg, ex.id, true); continue;
      }
      row.msg = 'Analyse…'; paint(); var pw = '', an = await AN.analyser(js, r.bytes, { progress: function (p, n) { row.msg = 'Analyse : page ' + p + ' / ' + n; paint(); } });
      while (an.besoinMotDePasse) {
        var q = await modal('PDF protégé — ' + r.nom, '<p class="note">' + (an.incorrect ? 'Mot de passe incorrect. ' : '') + 'Saisissez le mot de passe pour analyser et prévisualiser ce document (non conservé). Il ne pourra pas être habillé tant qu’il est chiffré.</p><label class="f">Mot de passe<input name="pw" type="password" autocomplete="off"></label>', [{ t: 'Refuser ce fichier' }, { t: 'Ouvrir', c: 'pri' }]);
        if (q.i !== 1) break; pw = q.v.pw; an = await AN.analyser(js, r.bytes, { motDePasse: pw });
      }
      if (an.besoinMotDePasse) { fin(row, false, 'Refusé — PDF protégé par mot de passe, non fourni.'); continue; }
      if (an.erreur) { fin(row, false, 'Refusé — ' + an.erreur); continue; }
      an.analyse.signe = r.signe; var d = await V.creerDoc({ nom: r.nom, bytes: r.bytes, analyse: an.analyse });
      d.protege = !!(r.chiffre || pw); d.signe = r.signe; d.classement.type = Z.type || devinerType(r.nom, an.analyse); d.config.modele = d.classement.type === 'note' ? 'note' : d.classement.type === 'rapport' ? 'rapport' : 'plan';
      var pj = Z.type ? projets().filter(function (x) { return String(x.id) === String(S.sepProj); })[0] : null;
      d.config.champs = C.prefill({}, pj || null, an.analyse, 0);
      if (pj) { d.classement.projet_id = String(pj.id); d.classement.projet = pNom(pj); }
      if (d.classement.type === 'note' || (Z.type && d.classement.type === 'plan')) { var nn = /([A-Z]{2,5}-\d{4}-\d{2,5})/i.exec(r.nom); if (nn) d.config.champs.numero = nn[1].toUpperCase(); d.config.champs.titre = r.nom.replace(/\.pdf$/i, '').replace(/_+/g, ' ').trim(); } V.putDoc(d); S.mem[d.id] = { bytes: r.bytes, analyse: an.analyse, grilles: an.grilles, pw: pw }; last = d; nNew++;
      var fl = []; if (d.protege) fl.push('protégé (aperçu seul, export refusé)'); if (r.signe) fl.push('signature numérique'); if (an.analyse.scannes) fl.push(an.analyse.scannes + ' page(s) scannée(s)'); if (an.analyse.formatsMixtes) fl.push('formats mixtes'); if (an.analyse.pages.some(function (p) { return p.cartouche.detecte; })) fl.push('cartouche existant détecté');
      fin(row, true, 'Archivé' + (Z.lib ? ' comme ' + Z.lib.toLowerCase() : '') + (pj ? ' · projet ' + pNom(pj) : '') + ' (' + an.analyse.nbPages + ' page(s), ' + fsize(r.bytes.length) + ', SHA-256 ' + d.sha256.slice(0, 10) + '…)' + (fl.length ? ' — ' + fl.join(', ') : ''), d.id);
    }
    if (last) S.cur = last.id;
    var bilan = (nNew ? nNew + ' document(s) importé(s)' : 'Aucun nouveau document') + (nDup ? ' · ' + nDup + ' déjà dans l’archive' : '') + '.';
    if (z === 'auto' && nNew) { toast(files.length > 1 ? 'Import terminé.' : 'Document importé.', 'ok'); go('atelier'); }
    else { if (files.length) toast(bilan, nNew ? 'ok' : ''); renderList(); renderDash(); renderSep(); renderSteps(); }
  }
  /* V234c : onglet « Plans · Notes de calcul » — contenu de l'archive par catégorie, sans quitter l'onglet */
  function renderSep() {
    var sel = $('sepProj'); if (sel) { var pr0 = projets(); sel.innerHTML = '<option value="">— aucun : champs « À compléter » —</option>' + pr0.map(function (p) { return opt(p.id, S.sepProj, pNom(p)); }).join(''); var nt = $('sepProjNote'); if (nt) nt.textContent = pr0.length ? (S.sepProj ? 'Chaque document importé sera rattaché à ce projet.' : 'Choisissez le projet avant d’importer pour que le cartouche reprenne le client et la référence.') : 'Aucun projet dans le logiciel : créez-le d’abord pour rattacher les documents.'; }
    var a = liste(), Z2 = { plan: ['hPlan', 'arcPlan', 'Plans d’exécution', 'plan'], note: ['hNote', 'arcNote', 'Notes de calcul', 'note'] };
    Object.keys(Z2).forEach(function (z) {
      var c = Z2[z], l = a.filter(function (d) { return d.classement.type === ZONES[z].type; }), h = $(c[0]), box = $(c[1]); if (!h || !box) return;
      h.textContent = c[2] + ' · ' + l.length + ' dans l’archive';
      box.innerHTML = l.length ? '<div style="overflow:auto"><table><tr><th>Document</th><th>Statut</th><th>Importé</th><th></th></tr>' + l.map(function (d) {
        return '<tr><td>' + esc(d.nom) + '<div class="note">' + ((d.analyse && d.analyse.nbPages) || '?') + ' p. · ' + fsize(d.taille || 0) + (d.protege ? ' · 🔒' : '') + (d.signe ? ' · ✍️' : '') + '</div></td><td>' + chip(d.statut) + '</td><td>' + fdate(d.importeLe) + '</td><td style="white-space:nowrap"><button class="btn sm" type="button" data-os="' + esc(d.id) + '">Ouvrir</button> <button class="btn sm" type="button" data-od="' + esc(d.id) + '">⬇️ Original</button></td></tr>';
      }).join('') + '</table></div>' : '<div class="note">Aucun ' + (z === 'plan' ? 'plan' : 'note de calcul') + ' dans l’archive pour l’instant.</div>';
    });
  }

  /* ---------------------------------------------------------------- travail préparatoire : job, plan, aperçu ---------------------------------------------------------------- */
  async function entree(d, dec) { var m = await ensure(d, true); return { id: d.id, nom: d.nom, sha: d.sha256, type: d.classement.type, bytes: m.bytes, analyse: Object.assign({}, m.analyse, { signe: !!d.signe }), grilles: m.grilles, cartoucheExistant: dec || '' }; }
  /* V214 : QR de vérification — même mécanisme que devis, reçus et plans (registre EXBVerif). Le code dépend du document, de l'indice, du statut et de la version :
     l'aperçu et l'export portent donc exactement le même QR ; il n'est publié au registre qu'à l'export réussi. */
  function qrPour(d, statut, tag) {
    try {
      var VF = host && host.EXBVerif, QR = host && host.EXBQR; if (!VF || !VF.docRec || !QR || !QR.matrix) return null;
      var ch = d.config.champs || {}, date = new Date().toISOString().slice(0, 10), no = ch.numero || ('MEP-' + String(d.id).slice(-8).toUpperCase());
      var o = VF.docRec({ no: no, prefix: 'MEP', date: date, title: ch.titre || d.nom, sub: (ch.indice ? 'ind. ' + ch.indice + ' · ' : '') + tag + ' · ' + statut, digest: [d.sha256, ch.indice || '', statut, tag].join('|'), nom: ch.client || '', detail: [ch.projet, ch.reference, d.config.modele].filter(Boolean).join(' · ') });
      o.rec.status = statut === 'Émis' ? 'valide' : 'brouillon';
      return { url: o.code.url, code: String(o.code.hash).toUpperCase(), matrix: QR.matrix(o.code.url), rec: o.rec };
    } catch (e) { return null; }
  }
  async function jobPour(d, apercu) {
    var cfg = d.config, tpl = C.modele(cfg.modele, V.modelesPerso()) || C.modele('plan'); if (cfg.position) tpl.position = cfg.position; if (+cfg.marge > 0) tpl.marge = +cfg.marge;
    var docs = [await entree(d, cfg.cartoucheExistant)];
    if (cfg.modele === 'dossier') { var ids = Object.keys(S.sel).filter(function (k) { return S.sel[k] && k !== d.id; }); for (var i = 0; i < ids.length; i++) { var o = V.getDoc(ids[i]); if (o) docs.push(await entree(o, o.config.cartoucheExistant || cfg.cartoucheExistant)); } }
    return { modele: cfg.modele, tpl: tpl, champs: cfg.champs, statut: d.statut, workflow: d.workflow, logo: !!S.logo, logoImage: S.logo, visa: !!S.visa, visaImage: S.visa, entreprise: S.ent, docs: docs, options: Object.assign({ mode: cfg.mode || 'auto' }, cfg.options || {}), redige: cfg.redige || '', meta: { auteur: V.actor().nom || d.workflow.auteur || '', version: 'v' + (V.versions(d.id).length + 1) }, qr: qrPour(d, d.statut, 'v' + (V.versions(d.id).length + 1)), apercu: !!apercu };
  }
  function refresh(now) { clearTimeout(S.tm); S.tm = setTimeout(recalcul, now ? 0 : 450); }
  async function recalcul() {
    var d = cur(); if (!d) { renderWarns([]); draw(); return; }
    var tok = ++S.tok; S.after = null; S.afterPdf = null; S.plan = null;
    try {
      if (d.protege && !(S.mem[d.id] && S.mem[d.id].pw) && d.signe === undefined) { /* rien */ }
      await ensure(d); if (tok !== S.tok) return; var job = await jobPour(d, true), plan = L.plan(job); S.plan = plan; S.lastWarns = plan.avertissements.slice(); renderWarns(S.lastWarns); renderSteps();
      if (d.protege) { S.lastWarns.unshift({ niv: 'bloquant', msg: 'PDF protégé (chiffré) : aperçu de l’original seulement. L’habillage est refusé : demandez une copie non chiffrée au propriétaire du document.' }); renderWarns(S.lastWarns); S.vue = 'avant'; draw(); return; }
      progress('Calcul de l’aperçu…'); var r = await X.build(PL, job, plan); if (tok !== S.tok) return; S.after = r; S.afterPdf = await PV.ouvrir(await pdfjs(), r.bytes); S.lastWarns = plan.avertissements.concat(r.notes); renderWarns(S.lastWarns); progress('');
    } catch (e) { progress(''); S.lastWarns = [{ niv: 'bloquant', msg: String(e && e.message || e) }]; renderWarns(S.lastWarns); }
    if (tok === S.tok) { S.page = Math.min(S.page, Math.max(0, total() - 1)); draw(); renderSteps(); }
  }
  function total() { return S.after ? S.after.map.length : ((S.mem[S.cur] && S.mem[S.cur].analyse && S.mem[S.cur].analyse.nbPages) || 0); }
  async function origHandle(docIdx) {
    var key = S.cur + ':' + docIdx; if (S.origPdf[key]) return S.origPdf[key]; var docs = S.plan && S.plan.docs, dd = docs && docs[docIdx]; if (!dd) return null;
    var h = await PV.ouvrir(await pdfjs(), dd.bytes, (S.mem[dd.id] || {}).pw); S.origPdf[key] = h; return h;
  }
  async function draw() {
    var st = $('stage'), tok = ++S.dtok, d = cur(); if (!d) { st.innerHTML = '<div class="empty">Sélectionnez un document.</div>'; $('pInfo').textContent = '—'; return; }
    var n = total(), p = S.page, mode = S.vue, avail = Math.max(260, st.clientWidth - 30), panes = [];
    $('pInfo').textContent = n ? 'Page ' + (p + 1) + ' / ' + n : '—'; $('zInfo').textContent = Math.round(S.zoom * 100) + ' %';
    var ent = S.after ? S.after.map[p] : null, srcDoc = ent && ent.kind === 'orig' ? ent.doc : 0, srcPage = ent ? (ent.kind === 'orig' ? ent.page : null) : p;
    var wantAfter = (mode === 'apres' || mode === 'cote') && S.afterPdf, wantBefore = mode === 'avant' || mode === 'cote' || !S.afterPdf, w1 = mode === 'cote' ? avail / 2 - 8 : avail;
    st.innerHTML = '';
    function pane(titre) { var c = document.createElement('canvas'), w = document.createElement('div'); w.className = 'pane'; w.innerHTML = '<b>' + esc(titre) + '</b>'; w.appendChild(c); st.appendChild(w); return c; }
    try {
      if (wantBefore) { var h = await origHandle(srcDoc); if (srcPage == null) { var m0 = document.createElement('div'); m0.className = 'empty'; m0.textContent = 'Page générée (' + (ent && ent.kind) + ') : pas d’original.'; st.appendChild(m0); } else if (h) { var c1 = pane('Avant (original intact)'); await PV.rendre(h, srcPage, c1, { maxW: w1, zoom: S.zoom, rotation: S.rot }); } }
      if (tok !== S.dtok) return;
      if (wantAfter) { var c2 = pane('Après (version habillée' + (ent && ent.mode ? ' — ' + ({ overlay: 'cartouche sur zone libre', band: 'bande ajoutée', conserve: 'cartouche existant conservé', intact: 'page intacte' }[ent.mode] || ent.mode) : '') + ')'); await PV.rendre(S.afterPdf, p, c2, { maxW: w1, zoom: S.zoom, rotation: S.rot }); }
      else if (!S.afterPdf && !d.protege && S.plan && S.plan.bloquants.length) { var m1 = document.createElement('div'); m1.className = 'empty'; m1.textContent = 'Aperçu « après » indisponible tant que les points bloquants ci-dessous ne sont pas traités.'; st.appendChild(m1); }
    } catch (e) { if (tok === S.dtok) st.innerHTML += '<div class="empty">Aperçu impossible : ' + esc(e && e.message || e) + '</div>'; }
    var th = $('thumbs'); th.innerHTML = ''; for (var i = 0; i < Math.min(n, 200); i++) { var b = document.createElement('button'); b.textContent = String(i + 1); b.className = i === p ? 'on' : ''; b.setAttribute('data-p', i); th.appendChild(b); }
  }

  /* ---------------------------------------------------------------- avertissements ---------------------------------------------------------------- */
  function renderWarns(ws) {
    var d = cur(), a = (ws || []).slice(), m = d ? C.manquants(d.config.champs) : []; if (m.length) a.push({ niv: 'attention', msg: 'Champs obligatoires à compléter avant de soumettre : ' + m.map(function (x) { return x.libelle; }).join(', ') + '.' });
    var ord = { bloquant: 0, attention: 1, info: 2 }; a.sort(function (x, y) { return ord[x.niv] - ord[y.niv]; }); var seen = {}; a = a.filter(function (x) { var k = x.niv + x.msg; if (seen[k]) return false; seen[k] = 1; return true; });
    $('warns').innerHTML = a.length ? a.slice(0, 40).map(function (x) { return '<div class="w ' + x.niv + '"><b>' + ({ bloquant: 'Bloquant', attention: 'Attention', info: 'Info' }[x.niv]) + ' — </b>' + esc(x.msg) + '</div>'; }).join('') : '<div class="w info">Aucun point à signaler : aucun contenu recouvert, marges respectées.</div>';
    var bl = a.filter(function (x) { return x.niv === 'bloquant'; }).length; $('ctl').querySelector('h2').textContent = 'Contrôles' + (bl ? ' — ' + bl + ' bloquant(s)' : a.length ? ' — ' + a.length + ' point(s)' : ' — conforme');
  }

  /* ---------------------------------------------------------------- panneau de propriétés ---------------------------------------------------------------- */
  function opt(v, cur0, t) { return '<option value="' + esc(v) + '"' + (String(v) === String(cur0) ? ' selected' : '') + '>' + esc(t == null ? v : t) + '</option>'; }
  function renderProps() {
    var d = cur(), P = $('props'); if (!d) { P.innerHTML = '<div class="card"><h2>Propriétés</h2><div class="body"><div class="empty">Aucun document sélectionné.</div></div></div>'; return; }
    var cfg = d.config, an = (S.mem[d.id] && S.mem[d.id].analyse) || d.analyse || { pages: [] }, dis = locked(d) || !V.act('modifier') ? ' disabled' : '', tplx = C.modele(cfg.modele, V.modelesPerso()) || {}, pr = projets(), isPlan = cfg.modele === 'plan' || (cfg.modele === 'dossier' && d.classement.type === 'plan');
    var det = an.pages.some(function (p) { return p.cartouche && p.cartouche.detecte; }), flags = [];
    if (d.protege) flags.push('🔒 protégé'); if (d.signe) flags.push('✍️ signé numériquement'); if (an.scannes) flags.push('🖨️ ' + an.scannes + ' page(s) scannée(s)'); if (an.formatsMixtes) flags.push('formats mixtes'); if (det) flags.push('cartouche existant');
    var h = '';
    h += '<details class="card" open><summary>1 · Document et classement</summary><div class="body"><div><b>' + esc(d.nom) + '</b><div class="note">' + (an.nbPages || 0) + ' page(s) — ' + esc(C.formatResume(an) || '') + ' — ' + fsize(d.taille) + '<br>Original : SHA-256 ' + esc(d.sha256.slice(0, 16)) + '… ' + (flags.length ? '<br>' + esc(flags.join(' · ')) : '') + '</div></div>'
      + '<label class="f">Projet<select data-k="projet_id"' + dis + '><option value="">— choisir —</option>' + pr.map(function (p) { return opt(p.id, d.classement.projet_id, pNom(p)); }).join('') + '</select></label>'
      + '<div class="row2"><label class="f">Type de document<select data-k="type"' + dis + '>' + Object.keys(C.TYPES).map(function (k) { return opt(k, d.classement.type, C.TYPES[k]); }).join('') + '</select></label><label class="f">Discipline<select data-c="champs.discipline"' + dis + '><option value="">—</option>' + C.DISCIPLINES.map(function (x) { return opt(x, cfg.champs.discipline); }).join('') + '</select></label></div>'
      + '<label class="f">Accès restreint à (noms ou « fonction: bureau_etudes », séparés par des virgules ; vide = tous)<input data-k="acces" value="' + esc((d.acces || []).join(', ')) + '"' + (V.act('administrer') ? '' : ' disabled') + '></label></div></details>';
    h += '<details class="card" open><summary>2 · Modèle et mise en page</summary><div class="body"><label class="f">Modèle<select data-c="modele"' + dis + '>' + C.MODELES.concat(V.modelesPerso()).map(function (m) { return opt(m.id, cfg.modele, m.nom + (m.integre ? '' : ' (personnalisé)')); }).join('') + '</select></label><div class="note">' + esc(tplx.desc || '') + '</div>';
    if (isPlan) {
      h += '<label class="f">Placement du cartouche<select data-c="mode"' + dis + '>' + opt('auto', cfg.mode || 'auto', 'Automatique (zone libre, sinon bande)') + opt('overlay', cfg.mode, 'Sur la page (zone libre)') + opt('band', cfg.mode, 'Bande ajoutée sous la page (rien n’est recouvert)') + opt('sheet', cfg.mode, 'Feuille de présentation distincte') + '</select></label>'
        + '<div class="row2"><label class="f">Position<select data-c="position"' + dis + '>' + opt('br', cfg.position || tplx.position, 'Bas droite') + opt('bl', cfg.position || tplx.position, 'Bas gauche') + opt('tr', cfg.position || tplx.position, 'Haut droite') + opt('tl', cfg.position || tplx.position, 'Haut gauche') + '</select></label><label class="f">Marge (mm)<input type="number" min="0" max="60" data-c="marge" value="' + esc(cfg.marge || tplx.marge || 10) + '"' + dis + '></label></div>';
      if (det) h += '<div class="w attention"><b>Cartouche existant détecté.</b> Que faire ?<br>' + [['conserver', 'Conserver (ne rien ajouter)'], ['remplacer', 'Remplacer (le nouveau recouvre l’ancien)'], ['ignorer', 'Ignorer (ajouter selon la zone libre)']].map(function (o) { return '<label class="chk"><input type="radio" name="cx" data-c="cartoucheExistant" value="' + o[0] + '"' + (cfg.cartoucheExistant === o[0] ? ' checked' : '') + dis + '>' + o[1] + '</label>'; }).join('') + '</div>';
      var natP = cfg.options && cfg.options.styleNatif != null ? cfg.options.styleNatif : (tplx.styleNatif != null ? tplx.styleNatif : true);
      h += '<label class="chk"><input type="checkbox" data-o="styleNatif"' + (natP ? ' checked' : '') + dis + '>Cartouche identique à celui des plans d’exécution du logiciel (bande pleine largeur : identité, références, titre, visa, QR, N° / date / indice / page)</label>';
      h += '<label class="chk"><input type="checkbox" data-o="accepteRecouvrement"' + (cfg.options && cfg.options.accepteRecouvrement ? ' checked' : '') + dis + '>J’accepte que le cartouche recouvre du contenu si je force « Sur la page »</label>';
    } else {
      [['couverture', 'Page de couverture'], ['sommaire', 'Sommaire'], ['pagination', 'Pagination, en-têtes et pieds de page'], ['filigrane', 'Filigrane de statut (discret)'], ['validation', 'Page de validation']].forEach(function (o) { var v = cfg.options && cfg.options[o[0]] != null ? cfg.options[o[0]] : tplx[o[0]]; h += '<label class="chk"><input type="checkbox" data-o="' + o[0] + '"' + (v ? ' checked' : '') + dis + '>' + o[1] + '</label>'; });
      if (cfg.modele === 'note') {
        var nat = cfg.options && cfg.options.styleNatif != null ? cfg.options.styleNatif : tplx.styleNatif;
        h += '<label class="chk"><input type="checkbox" data-o="styleNatif"' + (nat ? ' checked' : '') + dis + '>Présentation identique aux notes de calcul du logiciel (couverture à double cadre, bandeau « Feuille x / n », pied avec QR)</label>';
      }
      if (cfg.modele === 'dossier') h += '<div class="note">Dossier complet : cochez dans la liste les autres documents à inclure (notes, plans, annexes).</div>';
    }
    h += '<div class="w"><b>✏️ Éditeur Word</b><div class="note">Ouvre ce PDF dans l’éditeur Word du logiciel (ruban, styles, listes, export .docx). Le texte du PDF est repris s’il en contient ; ce que vous rédigez est ajouté sur des feuilles supplémentaires à la suite du document, avec le même bandeau et le même pied que les notes du logiciel. Les pages d’origine ne sont jamais modifiées.</div>'
      + '<div class="acts"><button class="btn sm pri" type="button" data-a="word"' + dis + '>✏️ ' + (cfg.redige ? 'Modifier' : 'Ouvrir') + ' dans l’éditeur Word</button>' + (cfg.redige ? '<button class="btn sm" type="button" data-a="wordclr"' + dis + '>Effacer le texte</button>' : '') + '</div>'
      + (cfg.redige ? '<div class="note">' + esc(String(cfg.redige).replace(/\[[^\]]*\]|[#*]/g, '').length) + ' caractère(s) — feuille(s) ajoutée(s) : ' + esc(L.chunksRedige(L.redigeItems(cfg.redige)).length) + '</div>' : '') + '</div>';
    if (d.signe) h += '<label class="chk"><input type="checkbox" data-o="accepteSignature"' + (cfg.options && cfg.options.accepteSignature ? ' checked' : '') + dis + '>Je comprends que la signature numérique sera invalidée dans la nouvelle version (l’original signé reste archivé).</label>';
    h += '</div></details>';
    h += '<details class="card" open><summary>3 · Cartouche et informations</summary><div class="body">';
    C.CHAMPS.forEach(function (c) { var k = c[0], v = cfg.champs[k] || '', ro = (k === 'format') ? '' : dis; if (k === 'discipline') return; h += '<label class="f' + (c[2] && !v ? ' miss' : '') + '">' + esc(c[1]) + (c[2] ? ' *' : '') + '<input data-c="champs.' + k + '" value="' + esc(v) + '" placeholder="' + (k === 'format' ? C.formatResume(an) : C.A_COMPLETER) + '"' + ro + '></label>'; });
    h += '<div class="acts"><button class="btn sm" type="button" data-a="proj"' + dis + '>↻ Reprendre les données du projet</button><button class="btn sm" type="button" data-a="nomfic"' + dis + '>Titre = nom du fichier</button><button class="btn sm" type="button" data-a="ocr">🔎 OCR (propositions)</button></div>'
      + '<div class="note">* obligatoire pour soumettre. Un champ vide reste affiché « À compléter » sur le document : rien n’est inventé. Les mentions dessiné / vérifié / approuvé viennent uniquement du circuit de validation.</div></div></details>';
    h += '<details class="card" open><summary>4 · Validation et export</summary><div class="body"><div>' + chip(d.statut) + ' <span class="note">' + esc(wfTxt(d)) + '</span></div><div class="acts">' + wfBtns(d) + '</div><hr style="border:0;border-top:1px solid var(--line);width:100%">'
      + '<div class="acts"><button class="btn gold" data-a="exp" type="button"' + (d.protege ? ' disabled' : '') + '>⬇️ Exporter ' + (d.statut === 'Émis' ? 'une copie' : 'un brouillon') + ' (PDF)</button>' + (V.peutEmettre(d) ? '<button class="btn ok" data-a="emettre" type="button">✅ Émettre (PDF final)</button>' : '') + '</div>'
      + '<div class="note">Chaque export crée une nouvelle version archivée ; l’original n’est jamais écrasé. Contrôle d’intégrité automatique (image et texte) hors zone ajoutée.</div></div></details>';
    h += carteApi(d);
    P.innerHTML = h; bindProps(P);
  }
  function wfTxt(d) { var w = d.workflow || {}, a = []; if (w.auteur) a.push('Auteur : ' + w.auteur); if (w.verif) a.push('Visé par ' + w.verif.par + ' (' + C.dateFr(w.verif.t) + ')'); if (w.approuve) a.push('Approuvé par ' + w.approuve.par + ' (' + C.dateFr(w.approuve.t) + ')'); if (w.rejet && d.statut === 'À corriger') a.push('Motif : ' + w.rejet.motif); if (w.emis) a.push('Émis le ' + C.dateFr(w.emis.t)); return a.join(' · '); }
  function wfBtns(d) {
    var b = '';
    if (d.statut === 'Brouillon' || d.statut === 'À corriger') b += '<button class="btn pri" data-w="soumettre" type="button">📤 Soumettre à vérification</button>';
    if (d.statut === 'Pour vérification') { if (!d.workflow.verif) b += '<button class="btn pri" data-w="verifier" type="button">🔍 Viser (vérifier)</button><button class="btn err" data-w="corriger" type="button">↩️ Demander des corrections</button>'; else b += '<button class="btn ok" data-w="approuver" type="button">✔️ Approuver</button><button class="btn err" data-w="refuser" type="button">✖️ Refuser</button>'; }
    if (d.statut === 'Émis') b += '<button class="btn" data-w="revision" type="button">🆕 Nouvelle révision</button>';
    return b;
  }
  async function workflow(w) {
    var d = cur(); if (!d) return; var r;
    if (w === 'revision') { var q0 = await modal('Nouvelle révision', '<label class="f">Motif de la révision (obligatoire)<textarea name="t" rows="3"></textarea></label>', [{ t: 'Annuler' }, { t: 'Créer', c: 'pri' }]); if (q0.i !== 1) return; var n0 = await nomActeur('Identification'); r = V.nouvelleRevision(d, n0, q0.v.t); if (r.ok) { S.cur = r.doc.id; toast('Révision ' + C.indiceDe(r.doc.rev) + ' créée en brouillon.', 'ok'); } else toast(r.msg, 'err'); return renderAll(); }
    var nom = await nomActeur(w === 'soumettre' ? 'Soumettre à vérification' : 'Identification'); if (!nom) return;
    if (w === 'soumettre') r = V.soumettre(d, nom);
    else { var ok = w === 'verifier' || w === 'approuver', need = !(w === 'approuver'), titre = { verifier: 'Viser', corriger: 'Demander des corrections', approuver: 'Approuver', refuser: 'Refuser' }[w]; var q = await modal(titre, '<label class="f">' + (ok ? (w === 'verifier' ? 'Ce qui a été contrôlé (obligatoire)' : 'Commentaire (facultatif)') : 'Motif (obligatoire)') + '<textarea name="t" rows="3"></textarea></label>', [{ t: 'Annuler' }, { t: titre, c: ok ? 'ok' : 'err' }]); if (q.i !== 1) return; r = (w === 'verifier' || w === 'corriger') ? V.verifier(d, nom, w === 'verifier', q.v.t) : V.approuver(d, nom, w === 'approuver', q.v.t); }
    if (r.ok) { V.setNom(nom); toast('Statut : ' + d.statut + '.', 'ok'); } else toast(r.msg, 'err'); renderAll();
  }
  function bindProps(P) {
    P.querySelectorAll('[data-k],[data-c],[data-o]').forEach(function (el) {
      el.addEventListener(el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'radio' ? 'change' : 'input', function () {
        var d = cur(); if (!d || (locked(d) && !el.hasAttribute('data-k'))) return; var rerender = false;
        if (el.hasAttribute('data-k')) {
          var k = el.getAttribute('data-k');
          if (k === 'acces') d.acces = el.value.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
          else if (k === 'projet_id') { var p = projets().filter(function (x) { return String(x.id) === el.value; })[0]; d.classement.projet_id = el.value; d.classement.projet = p ? pNom(p) : ''; if (p) { d.config.champs = C.prefill(d.config.champs, p, d.analyse, d.rev); rerender = true; } }
          else { d.classement[k] = el.value; if (k === 'type') { var mm = { plan: 'plan', note: 'note', rapport: 'rapport', annexe: 'rapport' }[el.value]; if (d.config.modele !== 'dossier') d.config.modele = mm; rerender = true; } }
        } else if (el.hasAttribute('data-o')) { d.config.options = d.config.options || {}; d.config.options[el.getAttribute('data-o')] = el.checked; }
        else { var path = el.getAttribute('data-c').split('.'), val = el.type === 'radio' ? el.value : el.value; if (path[0] === 'champs') d.config.champs[path[1]] = val; else { d.config[path[0]] = val; if (path[0] === 'modele') { d.config.options = {}; rerender = true; } if (path[0] === 'mode' || path[0] === 'cartoucheExistant') rerender = true; } if (path[0] === 'champs') { var lab = el.closest('label'); if (lab) lab.classList.toggle('miss', !val && /\*/.test(lab.textContent)); } }
        V.putDoc(d); if (rerender) { renderProps(); renderList(); } refresh(); renderSteps();
      });
    });
    P.querySelectorAll('[data-a]').forEach(function (b) { b.onclick = function () { action(b.getAttribute('data-a')); }; });
    P.querySelectorAll('[data-w]').forEach(function (b) { b.onclick = function () { workflow(b.getAttribute('data-w')); }; });
  }
  /* ---------------------------------------------------------------- V234d : portail client (QR / lien) des plans d'exécution et notes de calcul ---------------------------------------------------------------- */
  /* Même mécanisme que les plans et notes du logiciel (exb-calc-publics.js, référence EXE-/EXN- + code d'accès + QR) : on publie le PDF habillé de la dernière version approuvée ou émise. */
  var PUB_OK = ['Approuvé', 'Émis'];
  function pubApi() { try { var P = host && host.EXBCALCPUB; return P && P.available && P.available() ? P : null; } catch (e) { return null; } }
  function publiable(d) { return !!d && (d.classement.type === 'plan' || d.classement.type === 'note'); }
  function derniereVersion(d) { return V.versions(d.id).slice(-1)[0] || null; }
  function pubMeta(d, v) {
    var ch = d.config.champs || {};
    return { genre: d.classement.type === 'note' ? 'note' : 'pex', no: String(ch.numero || '').trim(), titre: ch.titre || d.nom.replace(/\.pdf$/i, ''), projet: ch.projet || d.classement.projet || '', client: ch.client || '', etabli: (d.workflow && d.workflow.auteur) || v.par || '', indice: ch.indice || '', norme: '', statut: v.statut, date: new Date(v.t).toISOString().slice(0, 10), hash: v.sha256 };
  }
  function contactClient(d) {
    var p = projets().filter(function (x) { return String(x.id) === String(d.classement.projet_id); })[0] || {};
    return { phone: p.client_tel || p.clientTel || p.client_phone || p.telephone_client || '', email: p.client_email || p.clientEmail || p.email_client || '' };
  }
  function pubCtx(d, m) { var c = contactClient(d); return { no: m.no, client: m.client, projet: m.projet, genre: m.genre, phone: c.phone, email: c.email }; }
  async function publier(d) {
    if (!publiable(d)) return toast('Seuls les plans d’exécution et les notes de calcul se publient sur le portail client.', 'err');
    var P = pubApi(); if (!P) return toast('Portail client indisponible ici : ouvrez l’Atelier depuis le logiciel, connecté au serveur (☁️).', 'err');
    try { var B = host.EXB81; if (B && B.can && !B.can('plans_fichiers', 'ecrire')) return toast('Votre profil n’a pas le droit de publier aux clients (droit « plans_fichiers »).', 'err'); } catch (e) {}
    var v = derniereVersion(d); if (!v || PUB_OK.indexOf(v.statut) < 0) return toast('Publiez seulement un document validé : exportez d’abord une version « Approuvé » ou « Émis ».', 'err');
    var m = pubMeta(d, v); if (!m.no) return toast('Renseignez le numéro du document : la référence et le QR du portail en dépendent.', 'err');
    var by = await V.getFile(v.sha256); if (!by) return toast('Fichier de la version introuvable.', 'err');
    progress('Publication sur le portail client…');
    var x = null; try { x = await P.publishResult(m, new Blob([by], { type: 'application/pdf' })); } catch (e) { x = null; } progress('');
    if (!x) { var le = P.lastError && P.lastError(); toast(le ? 'Publication impossible : ' + le : 'Hors connexion : le document est en attente et sera publié tout seul au retour de la connexion.', le ? 'err' : ''); return; }
    d.publication = { ref: x.ref, t: Date.now(), version: v.tag, hash: v.sha256, no: m.no }; V.putDoc(d); V.log('publie', d, { ref: x.ref, detail: 'Portail client — ' + x.ref + ' — ' + v.tag });
    renderProps(); renderSep(); toast('Publié sur le portail client (réf. ' + x.ref + ').', 'ok'); P.show(x, pubCtx(d, m));
  }
  function voirPub(d) {
    var P = pubApi(), no = (d.publication && d.publication.no) || (d.config.champs && d.config.champs.numero); if (!P || !no) return;
    var x = P.info(no); if (!x) return toast('Publication introuvable sur cet appareil : republiez le document.', 'err');
    var v = derniereVersion(d), m = v ? pubMeta(d, v) : { no: no, client: d.config.champs.client, projet: d.config.champs.projet, genre: d.classement.type === 'note' ? 'note' : 'pex' }; P.show(x, pubCtx(d, m));
  }
  async function proposerPublication(d) {
    if (!publiable(d) || !pubApi() || !(d.config.champs && d.config.champs.numero)) return;
    var q = await modal('Portail client', '<p>Le document est émis. Le publier maintenant sur le portail client (QR + lien à remettre au client) ?</p><p class="note">Vous pourrez aussi le faire plus tard depuis « Portail client ».</p>', [{ t: 'Plus tard' }, { t: '🌐 Publier', c: 'pri' }]);
    if (q.i === 1) publier(d);
  }
  function carteApi(d) {
    if (!publiable(d)) return '';
    var P = pubApi(), v = derniereVersion(d), ok = !!(v && PUB_OK.indexOf(v.statut) >= 0), pb = d.publication, h = '<details class="card" open><summary>5 · Portail client</summary><div class="body">';
    if (!P) return h + '<div class="note">Disponible depuis le logiciel, connecté au serveur (☁️) : le client scanne un QR ou saisit référence + code et télécharge son PDF.</div></div></details>';
    h += '<div class="note">Le client scanne un QR (ou saisit référence + code) et télécharge le PDF habillé, au lieu de recevoir le fichier. Seule une version <b>approuvée ou émise</b> se publie.</div>';
    if (pb) h += '<div class="w ' + (v && v.sha256 === pb.hash ? 'info' : 'attention') + '"><b>Publié</b> — réf. ' + esc(pb.ref) + ' (' + esc(pb.version) + ', ' + fdate(pb.t) + ')' + (v && v.sha256 !== pb.hash ? '<br>Une version plus récente existe : republier met à jour le PDF, le QR déjà remis reste valable.' : '') + '</div>';
    h += '<div class="acts"><button class="btn sm ok" type="button" data-a="pub"' + (ok ? '' : ' disabled') + '>🌐 ' + (pb ? 'Republier' : 'Publier') + ' — QR / lien client</button>' + (pb ? '<button class="btn sm" type="button" data-a="pubqr">QR / lien</button>' : '') + '<button class="btn sm" type="button" data-a="publist">Documents publiés</button></div>';
    if (!ok) h += '<div class="note">Publication possible après l’export d’une version approuvée ou émise.</div>';
    return h + '</div></details>';
  }
  async function action(a) {
    var d = cur(); if (!d) return;
    if (a === 'proj') { var p = projets().filter(function (x) { return String(x.id) === String(d.classement.projet_id); })[0]; if (!p) return toast('Choisissez d’abord un projet.', 'err'); ['projet', 'reference', 'client', 'localisation'].forEach(function (k) { d.config.champs[k] = ''; }); d.config.champs = C.prefill(d.config.champs, p, d.analyse, d.rev); V.putDoc(d); renderProps(); refresh(); }
    else if (a === 'nomfic') { d.config.champs.titre = d.nom.replace(/\.pdf$/i, '').replace(/[_]+/g, ' '); V.putDoc(d); renderProps(); refresh(); }
    else if (a === 'word') editerTexte(d);
    else if (a === 'wordclr') { if (await modal('Effacer le texte rédigé', '<p>Supprimer le texte rédigé de ce document ? Les feuilles ajoutées disparaîtront de l’aperçu et de l’export.</p>', [{ t: 'Annuler' }, { t: 'Effacer', c: 'pri' }]).then(function (q) { return q.i === 1; })) { d.config.redige = ''; V.putDoc(d); V.log('redige', d, { detail: 'Texte rédigé effacé' }); renderProps(); refresh(); } }
    else if (a === 'pub') publier(d); else if (a === 'pubqr') voirPub(d); else if (a === 'publist') { var P0 = pubApi(); if (P0) P0.list(); }
    else if (a === 'exp') exporter(false); else if (a === 'emettre') exporter(true); else if (a === 'ocr') ocr();
  }

  /* ---------------------------------------------------------------- V221 : éditeur Word (menus du logiciel) ---------------------------------------------------------------- */
  /* Ouvre l'éditeur « façon Word » du logiciel (ruban Fichier · Accueil · Insertion · Mise en page · Révision…) pour rédiger le texte ajouté à la note.
     Hors du logiciel (page ouverte seule), une zone de texte simple prend le relais. Le texte reste dans le balisage de l'éditeur (# titre, ## sous-titre, - liste). */
  async function editerTexte(d) {
    var start = d.config.redige || '', hostAtelier = host && host.EXBATELIERMEP;
    /* V234b : un document importé qui contient déjà du texte ne s'ouvre plus sur une page vide : on propose de reprendre son texte (lecture seule de l'original). */
    if (!start && d.analyse && d.analyse.pages && d.analyse.pages.some(function (p) { return p.texte; })) {
      var q0 = await modal('Texte du document importé', '<p class="note">Ce document contient déjà du texte. Vous pouvez le reprendre dans l’éditeur pour le retrouver au lieu d’une page vide. Le texte appliqué est ajouté sur des feuilles supplémentaires à la suite de la note ; l’original n’est jamais modifié, ne gardez donc que ce que vous voulez ajouter.</p>', [{ t: 'Page blanche' }, { t: 'Reprendre le texte du document', c: 'pri' }]);
      if (q0 && q0.i === 1) {
        try { progress('Lecture du texte du document…'); var m0 = await ensure(d, true); start = await AN.extraireTexte(await pdfjs(), m0.bytes, { motDePasse: m0.pw }); progress(''); if (!start) toast('Aucun texte lisible dans ce document.', 'err'); }
        catch (e) { progress(''); start = ''; toast('Lecture du texte impossible : ' + (e && e.message || e), 'err'); }
      }
    }
    /* V236g : PDF scanné (sans couche de texte) : reconnaissance de texte (OCR) proposée si elle est installée ; sinon page blanche. L'original n'est jamais modifié. */
    if (!start && d.analyse && d.analyse.pages && d.analyse.pages.length && !d.analyse.pages.some(function (p) { return p.texte; })) {
      try {
        if (await OC.disponible()) {
          var q1 = await modal('Document scanné', '<p class="note">Ce PDF ne contient pas de texte (image scannée). Lancer la reconnaissance de texte (OCR) pour l’ouvrir dans l’éditeur avec son texte ? Le résultat peut contenir des erreurs : relisez-le. Les 3 premières pages sont lues.</p>', [{ t: 'Page blanche' }, { t: 'Lire par OCR', c: 'pri' }]);
          if (q1 && q1.i === 1) {
            var m1 = await ensure(d, true), cv1 = [], n1 = Math.min(3, m1.analyse.nbPages), h1 = await PV.ouvrir(await pdfjs(), m1.bytes, m1.pw);
            for (var i1 = 0; i1 < n1; i1++) { var c1 = document.createElement('canvas'); await PV.rendre(h1, i1, c1, { maxW: 1800 }); cv1.push(c1); }
            progress('Reconnaissance du texte…', 0); var r1 = await OC.lire(cv1, function (p) { progress('Reconnaissance du texte…', p); }); progress(''); start = String(r1.texte || '').trim();
          }
        }
      } catch (e) { progress(''); toast('OCR impossible : ' + (e && e.message || e), 'err'); }
    }
    function appliquer(txt) { txt = String(txt || ''); if (txt === (d.config.redige || '')) return; d.config.redige = txt; V.putDoc(d); V.log('redige', d, { detail: 'Texte rédigé modifié (' + txt.length + ' caractères)' }); renderProps(); refresh(true); toast('Texte appliqué au document.', 'ok'); }
    if (hostAtelier && hostAtelier.editWord && hostAtelier.editWord({ titre: 'Texte rédigé — ' + (d.config.champs.titre || d.nom), texte: start, appliquer: appliquer })) return;
    var q = await modal('Texte rédigé', '<p class="note">Éditeur Word indisponible ici : saisie simple. Utilisez « # Titre », « ## Sous-titre » et « - liste ».</p><label class="f">Texte<textarea name="t" rows="12" style="width:100%">' + esc(start) + '</textarea></label>', [{ t: 'Annuler' }, { t: 'Appliquer', c: 'pri' }]);
    if (q.i === 1) appliquer(q.v.t);
  }

  /* ---------------------------------------------------------------- OCR facultatif ---------------------------------------------------------------- */
  async function ocr() {
    var d = cur(); if (!d) return; if (!(await OC.disponible())) return modal('OCR indisponible', '<p>Les fichiers de reconnaissance de texte (Tesseract, français) ne sont pas installés avec cette application (dossier <code>vendor/tesseract/</code>). La saisie manuelle des champs reste possible ; l’OCR ne modifie jamais le PDF.</p>', [{ t: 'Fermer', c: 'pri' }]);
    try {
      var m = await ensure(d), cvs = [], n = Math.min(3, m.analyse.nbPages), h = await PV.ouvrir(await pdfjs(), m.bytes, m.pw); for (var i = 0; i < n; i++) { var c = document.createElement('canvas'); await PV.rendre(h, i, c, { maxW: 1800 }); cvs.push(c); }
      progress('Reconnaissance du texte…', 0); var r = await OC.lire(cvs, function (p) { progress('Reconnaissance du texte…', p); }); progress('');
      var ch = r.champs, lines = Object.keys(ch).map(function (k) { return '<label class="f">' + esc((C.CHAMPS.filter(function (x) { return x[0] === k; })[0] || [k, k])[1]) + '<input name="' + k + '" value="' + esc(ch[k]) + '"></label>'; }).join('');
      var q = await modal('Propositions de l’OCR — à vérifier', '<p class="note">Texte lu automatiquement : il peut contenir des erreurs. Corrigez avant d’appliquer ; seuls les champs encore vides seront remplis.</p>' + (lines || '<p>Aucune valeur reconnue.</p>') + '<label class="f">Texte reconnu (modifiable)<textarea rows="5" name="_t">' + esc(r.texte.slice(0, 3000)) + '</textarea></label>', [{ t: 'Fermer' }, { t: 'Appliquer aux champs vides', c: 'pri' }]);
      d.ocr = { t: Date.now(), texte: r.texte.slice(0, 2000) }; if (q.i === 1) { Object.keys(ch).forEach(function (k) { if (!d.config.champs[k] && q.v[k]) d.config.champs[k] = q.v[k]; }); V.log('ocr', d, { champs: Object.keys(ch) }); }
      V.putDoc(d); renderProps(); refresh();
    } catch (e) { progress(''); toast('OCR impossible : ' + (e && e.message || e), 'err'); }
  }

  /* ---------------------------------------------------------------- export, intégrité, archivage ---------------------------------------------------------------- */
  function nomSortie(d, statut, n) { var st = { 'Brouillon': 'BROUILLON', 'Pour vérification': 'POUR-VERIF', 'À corriger': 'A-CORRIGER', 'Approuvé': 'APPROUVE', 'Émis': 'EMIS' }[statut] || 'BROUILLON'; return slug(d.nom.replace(/\.pdf$/i, '')) + '_ind' + (d.config.champs.indice || 'A') + '_' + st + '_v' + n + '.pdf'; }
  async function exporter(emettre, dd, lot, extra) {
    var d = dd || cur(); if (!d) return { ok: false, msg: 'Aucun document.' }; function ko(m) { if (!lot) toast(m, 'err'); return { ok: false, msg: m }; }
    if (!V.act('exporter')) return ko('Votre profil n’a pas le droit d’exporter.'); if (d.protege) return ko('PDF protégé : habillage refusé.');
    if (emettre && !V.peutEmettre(d)) return ko('Émission impossible : le document doit être approuvé et vous devez être habilité.');
    if (emettre) { var mq = C.manquants(d.config.champs); if (mq.length) return ko('Champs obligatoires à compléter : ' + mq.map(function (x) { return x.libelle; }).join(', ') + '.'); }
    var prev = S.cur; try {
      var job = await jobPour(d, false); if (emettre) { job.statut = 'Émis'; job.workflow = Object.assign({}, d.workflow, { emis: { par: V.actor().nom, t: Date.now() } }); job.qr = qrPour(d, 'Émis', job.meta.version); }
      if (extra && extra.qr) job.qr = extra.qr;   /* V237c : QR commun d'un lot de plans */
      var plan = L.plan(job); if (plan.bloquants.length) { if (!lot && d.id === S.cur) { S.lastWarns = plan.avertissements; renderWarns(S.lastWarns); } return ko(plan.bloquants[0].msg); }
      progress('Génération du PDF…'); var r = await X.build(PL, job, plan);
      progress('Contrôle d’intégrité…', 0); var ig = await PV.integrite(await pdfjs(), plan.docs.map(function (x) { return x.bytes; }), r.bytes, r.map, function (i, n) { progress('Contrôle d’intégrité : page ' + i + ' / ' + n, i / n); }); progress('');
      if (!ig.ok) {
        var det = ig.pages.filter(function (x) { return !x.ok; }).slice(0, 6).map(function (x) { return 'page ' + x.page + ' : ' + x.pixelsDifferents + ' px différents, ' + x.textesPerdus + ' texte(s) manquant(s)'; }).join(' ; ');
        if (emettre || lot) return ko('Contrôle d’intégrité en échec (' + det + ') — ' + (emettre ? 'émission refusée.' : 'fichier non enregistré.'));
        var q = await modal('Contrôle d’intégrité', '<p>Des différences ont été détectées entre l’original et la version habillée, en dehors de la zone ajoutée :</p><p class="note">' + esc(det) + '</p><p>Enregistrer quand même ce brouillon ?</p>', [{ t: 'Annuler' }, { t: 'Enregistrer le brouillon', c: 'pri' }]); if (q.i !== 1) return { ok: false, msg: 'Annulé.' };
      }
      var nom = V.actor().nom || (await nomActeur('Identification')); if (!nom) return ko('Identification requise pour tracer l’export.');
      var last = V.versions(d.id).slice(-1)[0], statut = emettre ? 'Émis' : d.statut, n = V.versions(d.id).length + 1, fic = nomSortie(d, statut, n);
      var v = await V.ajouterVersion(d, { bytes: r.bytes, statut: statut, nomFichier: fic, nbPages: r.map.length, par: nom, notes: r.notes.concat(plan.avertissements.filter(function (x) { return x.niv !== 'info'; })).map(function (x) { return x.msg; }).slice(0, 30), integrite: { ok: ig.ok, echantillon: ig.echantillon, total: ig.total }, champsModifies: V.champsModifies(last ? last.champs : {}, d.config.champs) });
      if (job.qr && job.qr.rec) { try { host.EXBVerif.publish(job.qr.rec); V.log('qr', d, { ref: job.qr.code, detail: 'QR de vérification enregistré — code ' + job.qr.code }); } catch (e) {} }
      if (!(extra && extra.silent)) dl(r.bytes, fic); if (emettre) await deposerArchives(d, r.bytes, fic, v);
      if (!lot) { toast((emettre ? 'Version émise ' : 'Version ') + v.tag + ' enregistrée et téléchargée — intégrité ' + (ig.ok ? 'contrôlée (' + ig.echantillon + ' page(s))' : 'avec écarts signalés') + '.', ig.ok ? 'ok' : 'err'); renderAll(); }
      if (emettre && !lot) proposerPublication(d);
      return { ok: true, msg: v.tag + ' — ' + fic + (ig.ok ? '' : ' (écarts d’intégrité)'), bytes: r.bytes, fic: fic, v: v };
    } catch (e) { progress(''); return ko(String(e && e.message || e)); }
  }
  async function deposerArchives(d, bytes, fic, v) {
    try { var AR = host && host.EXBAR; if (!AR || !AR.add || bytes.length > 14 * 1048576) return; var r = await AR.add({ fichier: new Blob([bytes], { type: 'application/pdf' }), nom: fic, mime: 'application/pdf', titre: (d.config.champs.titre || d.nom).slice(0, 150), type: ({ plan: 'plan', note: 'note', rapport: 'rapport' }[d.classement.type] || 'autre'), projet: d.classement.projet || d.config.champs.projet || '', client: d.config.champs.client || '', source: 'atelier-mep', note: 'Version émise ' + v.tag + ' — Atelier de mise en page' }); if (r && r.ok) toast('Copie déposée dans les Archives.', 'ok'); } catch (e) { /* facultatif */ }
  }
  async function exporterLot() {
    var ids = Object.keys(S.sel).filter(function (k) { return S.sel[k]; }); if (ids.length < 2) return; var rows = [];
    for (var i = 0; i < ids.length; i++) { var d = V.getDoc(ids[i]); if (!d) continue; progress('Lot : ' + (i + 1) + ' / ' + ids.length + ' — ' + d.nom); var r = await exporter(false, d, true); rows.push({ nom: d.nom, r: r }); await new Promise(function (ok) { setTimeout(ok, 450); }); }
    progress(''); await modal('Résultat du traitement par lot', '<table><tr><th>Document</th><th>Résultat</th></tr>' + rows.map(function (x) { return '<tr><td>' + esc(x.nom) + '</td><td style="color:var(--' + (x.r.ok ? 'ok' : 'err') + ')">' + esc(x.r.ok ? 'OK — ' + x.r.msg : 'Échec — ' + x.r.msg) + '</td></tr>'; }).join('') + '</table><p class="note">Chaque document échoue ou réussit séparément ; un échec n’arrête pas le lot.</p>', [{ t: 'Fermer', c: 'pri' }]); renderAll();
  }

  /* ---------------------------------------------------------------- écrans ---------------------------------------------------------------- */
  function renderList() {
    var a = liste(), L0 = $('list'); if (!a.length) { L0.innerHTML = '<div class="empty">Aucun document. Importez un PDF.</div>'; $('lotBar').hidden = true; return; }
    L0.innerHTML = a.map(function (d) { var c = d.config.modele === 'dossier' && d.id !== S.cur; return '<div class="ditem' + (d.id === S.cur ? ' on' : '') + '" data-id="' + esc(d.id) + '"><input type="checkbox" data-sel="' + esc(d.id) + '"' + (S.sel[d.id] ? ' checked' : '') + ' aria-label="Sélectionner ' + esc(d.nom) + '"><div style="min-width:0"><div class="t">' + esc(d.nom) + '</div><div class="m">' + chip(d.statut) + ' ' + esc(C.TYPES[d.classement.type] || '') + ' · ' + ((d.analyse && d.analyse.nbPages) || '?') + ' p.' + (d.protege ? ' 🔒' : '') + (d.signe ? ' ✍️' : '') + '</div></div></div>'; }).join('');
    var n = Object.keys(S.sel).filter(function (k) { return S.sel[k]; }).length, cd = cur(), dossier = cd && cd.config.modele === 'dossier', lb = $('lotBar'); lb.hidden = !n;
    lb.innerHTML = dossier ? '<div class="note">' + n + ' document(s) coché(s) seront inclus dans le dossier complet.</div>' : '<div class="note">' + n + ' document(s) coché(s).</div><button class="btn sm gold" id="lotGo" type="button"' + (n < 2 ? ' disabled' : '') + '>⬇️ Exporter le lot (brouillons)</button>';
    var lg = $('lotGo'); if (lg) lg.onclick = exporterLot;
  }
  function renderDash() {
    var a = liste(), cnt = function (s) { return a.filter(function (d) { return d.statut === s; }).length; }, vs = V.versions().length, att = a.filter(function (d) { return d.statut === 'Pour vérification'; }), j = V.journal().slice(0, 8);
    $('s-dash').innerHTML = '<div class="kpis"><div class="kpi"><b>' + a.length + '</b><span>Documents importés</span></div><div class="kpi"><b>' + cnt('Brouillon') + '</b><span>Brouillons</span></div><div class="kpi"><b>' + cnt('Pour vérification') + '</b><span>À vérifier / approuver</span></div><div class="kpi"><b>' + cnt('À corriger') + '</b><span>À corriger</span></div><div class="kpi"><b>' + cnt('Approuvé') + '</b><span>Approuvés</span></div><div class="kpi"><b>' + cnt('Émis') + '</b><span>Émis</span></div><div class="kpi"><b>' + vs + '</b><span>Versions produites</span></div></div>'
      + '<div class="card" style="margin-bottom:12px"><h2>En attente de validation</h2><div class="body">' + (att.length ? '<table><tr><th>Document</th><th>Auteur</th><th></th></tr>' + att.map(function (d) { return '<tr><td>' + esc(d.nom) + '</td><td>' + esc(d.workflow.auteur || '') + '</td><td><button class="btn sm" data-open="' + esc(d.id) + '" type="button">Ouvrir</button></td></tr>'; }).join('') + '</table>' : '<div class="note">Rien en attente.</div>') + '</div></div>'
      + '<div class="card"><h2>Dernières actions</h2><div class="body">' + (j.length ? '<table><tr><th>Date</th><th>Qui</th><th>Action</th><th>Document</th></tr>' + j.map(function (e) { return '<tr><td>' + fdate(e.t) + '</td><td>' + esc(e.par) + '</td><td>' + esc(e.action) + '</td><td>' + esc(e.nom) + '</td></tr>'; }).join('') + '</table>' : '<div class="note">Aucune action enregistrée.</div>') + '</div></div>';
    $('s-dash').querySelectorAll('[data-open]').forEach(function (b) { b.onclick = function () { S.cur = b.getAttribute('data-open'); go('atelier'); }; });
  }
  function renderModeles() {
    var adm = V.act('administrer'), all = C.MODELES.concat(V.modelesPerso()), cfg = V.config();
    $('s-modeles').innerHTML = '<div class="kpis">' + all.map(function (m) { return '<div class="card"><h2>' + esc(m.nom) + (m.integre ? '' : ' · perso') + '</h2><div class="body"><div class="note">' + esc(m.desc || '') + '</div><div class="note">Position ' + esc(m.position) + ' · marge ' + esc(m.marge) + ' mm' + (m.couverture ? ' · couverture' : '') + (m.sommaire ? ' · sommaire' : '') + (m.pagination ? ' · pagination' : '') + (m.filigrane ? ' · filigrane' : '') + (m.validation ? ' · validation' : '') + '</div><div class="acts">' + (adm ? '<button class="btn sm" data-dup="' + esc(m.id) + '" type="button">Dupliquer</button>' : '') + (adm && !m.integre ? '<button class="btn sm" data-edit="' + esc(m.id) + '" type="button">Modifier</button><button class="btn sm err" data-del="' + esc(m.id) + '" type="button">Supprimer</button>' : '') + '</div></div></div>'; }).join('') + '</div>'
      + '<div class="card"><h2>Paramètres</h2><div class="body"><label class="f">Durée de conservation des versions produites (années)<input type="number" min="1" max="99" id="cfgAns" value="' + esc(cfg.conservationAns) + '"' + (adm ? '' : ' disabled') + '></label><div class="note">Les modèles personnalisés et les paramètres sont réservés aux administrateurs (droit « administrer »). Les versions ne sont jamais supprimées : la durée indique l’échéance de conservation.</div></div></div>';
    var an = $('cfgAns'); if (an) an.onchange = function () { V.setConfig({ conservationAns: +an.value || 10 }); V.log('parametres', null, { detail: 'conservation ' + an.value + ' ans' }); toast('Paramètre enregistré.', 'ok'); };
    $('s-modeles').querySelectorAll('[data-dup]').forEach(function (b) { b.onclick = async function () { var m = C.modele(b.getAttribute('data-dup'), V.modelesPerso()), q = await modal('Dupliquer le modèle', '<label class="f">Nom du nouveau modèle<input name="n" value="' + esc(m.nom + ' (copie)') + '"></label>', [{ t: 'Annuler' }, { t: 'Créer', c: 'pri' }]); if (q.i !== 1 || !q.v.n.trim()) return; m.id = 'perso-' + Date.now().toString(36); m.nom = q.v.n.trim(); m.integre = false; var p = V.modelesPerso(); p.push(m); V.setModeles(p); V.log('modele', null, { detail: 'création ' + m.nom }); renderModeles(); }; });
    $('s-modeles').querySelectorAll('[data-del]').forEach(function (b) { b.onclick = function () { var id = b.getAttribute('data-del'); V.setModeles(V.modelesPerso().filter(function (m) { return m.id !== id; })); V.log('modele', null, { detail: 'suppression ' + id }); renderModeles(); }; });
    $('s-modeles').querySelectorAll('[data-edit]').forEach(function (b) { b.onclick = async function () { var id = b.getAttribute('data-edit'), p = V.modelesPerso(), m = p.filter(function (x) { return x.id === id; })[0]; if (!m) return; var q = await modal('Modifier « ' + m.nom + ' »', '<label class="f">Nom<input name="nom" value="' + esc(m.nom) + '"></label><div class="row2"><label class="f">Position<select name="position">' + ['br', 'bl', 'tr', 'tl'].map(function (x) { return opt(x, m.position); }).join('') + '</select></label><label class="f">Marge (mm)<input name="marge" type="number" value="' + esc(m.marge) + '"></label></div><label class="f">Largeur du cartouche (mm, 0 = automatique)<input name="largeur" type="number" value="' + esc(m.largeur || 0) + '"></label><label class="f">Texte d’en-tête<input name="enteteTexte" value="' + esc(m.enteteTexte || '') + '"></label><label class="f">Texte de pied de page<input name="piedTexte" value="' + esc(m.piedTexte || '') + '"></label><div class="note">Variables : {projet} {titre} {numero} {indice} {client} {reference} {date}</div>' + ['couverture', 'sommaire', 'pagination', 'filigrane', 'validation'].map(function (k) { return '<label class="chk"><input type="checkbox" name="' + k + '"' + (m[k] ? ' checked' : '') + '>' + k + '</label>'; }).join(''), [{ t: 'Annuler' }, { t: 'Enregistrer', c: 'pri' }]); if (q.i !== 1) return; Object.keys(q.v).forEach(function (k) { m[k] = (k === 'marge' || k === 'largeur') ? +q.v[k] || 0 : q.v[k]; }); V.setModeles(p); V.log('modele', null, { detail: 'modification ' + m.nom }); renderModeles(); }; });
  }
  function renderHisto() {
    var a = liste(), f = S.hf || '', vs = V.versions(f || undefined).slice().reverse(), j = V.journal(f || undefined).slice(0, 200);
    $('s-histo').innerHTML = '<div class="card" style="margin-bottom:12px"><h2>Versions et originaux</h2><div class="body"><label class="f">Document<select id="hf"><option value="">Tous</option>' + a.map(function (d) { return opt(d.id, f, d.nom); }).join('') + '</select></label>'
      + (vs.length ? '<div style="overflow:auto"><table><tr><th>Date</th><th>Document</th><th>Version</th><th>Statut</th><th>Par</th><th>Pages</th><th>Taille</th><th>SHA-256</th><th>Conservé jusqu’au</th><th></th></tr>' + vs.map(function (v) { var d = V.getDoc(v.doc); return '<tr><td>' + fdate(v.t) + '</td><td>' + esc(d ? d.nom : v.doc) + '</td><td>' + esc(v.tag) + '</td><td>' + chip(v.statut) + '</td><td>' + esc(v.par) + '</td><td>' + v.nbPages + '</td><td>' + fsize(v.taille) + '</td><td title="' + esc(v.sha256) + '">' + esc(v.sha256.slice(0, 10)) + '…</td><td>' + esc(v.conserveJusquau || '') + '</td><td style="white-space:nowrap"><button class="btn sm" data-dv="' + esc(v.id) + '" type="button">⬇️</button> <button class="btn sm" data-iv="' + esc(v.sha256) + '" type="button">Intégrité</button></td></tr>'; }).join('') + '</table></div>' : '<div class="note">Aucune version produite.</div>')
      + (a.length ? '<div class="note">Originaux (jamais modifiés) :</div><div style="overflow:auto"><table><tr><th>Document</th><th>Importé</th><th>SHA-256</th><th></th></tr>' + a.filter(function (d) { return !f || d.id === f; }).map(function (d) { return '<tr><td>' + esc(d.nom) + '</td><td>' + fdate(d.importeLe) + ' — ' + esc(d.importePar || '') + '</td><td title="' + esc(d.sha256) + '">' + esc(d.sha256.slice(0, 12)) + '…</td><td style="white-space:nowrap"><button class="btn sm" data-do="' + esc(d.id) + '" type="button">⬇️ Original</button> <button class="btn sm" data-iv="' + esc(d.sha256) + '" type="button">Intégrité</button></td></tr>'; }).join('') + '</table></div>' : '') + '</div></div>'
      + '<div class="card"><h2>Journal d’audit (ajout seul)</h2><div class="body"><div style="overflow:auto"><table><tr><th>Date</th><th>Qui</th><th>Action</th><th>Document</th><th>Statut</th><th>Détail</th></tr>' + j.map(function (e) { return '<tr><td>' + fdate(e.t) + '</td><td>' + esc(e.par) + '</td><td>' + esc(e.action) + '</td><td>' + esc(e.nom) + '</td><td>' + esc(e.statut) + '</td><td>' + esc((e.detail || '') + (e.champs && e.champs.length ? ' [champs : ' + e.champs.join(', ') + ']' : '')) + '</td></tr>'; }).join('') + '</table></div></div></div>';
    var hf = $('hf'); hf.onchange = function () { S.hf = hf.value; renderHisto(); };
    $('s-histo').querySelectorAll('[data-dv]').forEach(function (b) { b.onclick = async function () { var v = V.versions().filter(function (x) { return x.id === b.getAttribute('data-dv'); })[0], by = v && await V.getFile(v.sha256); if (!by) return toast('Fichier introuvable.', 'err'); if (!V.act('exporter')) return toast('Droit « exporter » requis.', 'err'); dl(by, v.nom); V.log('telechargement', V.getDoc(v.doc), { ref: v.sha256, detail: v.tag }); }; });
    $('s-histo').querySelectorAll('[data-do]').forEach(function (b) { b.onclick = async function () { var d = V.getDoc(b.getAttribute('data-do')), by = d && await V.getFile(d.sha256); if (!by) return toast('Original introuvable.', 'err'); dl(by, d.nom); V.log('telechargement', d, { ref: d.sha256, detail: 'original' }); }; });
    $('s-histo').querySelectorAll('[data-iv]').forEach(function (b) { b.onclick = async function () { var r = await V.verifierIntegrite(b.getAttribute('data-iv')); toast(r.ok ? 'Empreinte SHA-256 conforme : fichier inchangé.' : 'ALERTE : ' + r.msg, r.ok ? 'ok' : 'err'); }; });
  }
  var STEPS = ['Importer', 'Analyser', 'Classer', 'Modèle', 'Configurer', 'Prévisualiser', 'Exporter', 'Archiver'];
  function renderSteps() {
    var d = cur(), a = liste(), vs = d ? V.versions(d.id).length : 0, done = [a.length > 0, !!(d && d.analyse), !!(d && d.classement.projet_id && d.classement.type), !!d, !!(d && !C.manquants(d.config.champs).length), !!S.after, vs > 0, vs > 0], first = done.indexOf(false);
    $('steps').innerHTML = STEPS.map(function (s, i) { return '<li class="' + (done[i] ? 'done' : i === first ? 'on' : '') + '"><span class="n">' + (done[i] ? '✓' : i + 1) + '</span>' + s + '</li>'; }).join('');
  }
  function renderAll() { $('who').textContent = V.actor().nom || 'Non identifié'; renderList(); renderProps(); renderDash(); renderModeles(); renderHisto(); renderSep(); renderSteps(); refresh(true); }
  function go(s) {
    S.screen = s; document.body.classList.toggle('wide', s === 'apercu'); var real = s === 'apercu' ? 'atelier' : s;
    document.querySelectorAll('.scr').forEach(function (e) { e.classList.toggle('on', e.id === 's-' + real); }); document.querySelectorAll('#tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-s') === s); });
    if (s === 'dash') renderDash(); if (s === 'modeles') renderModeles(); if (s === 'histo') renderHisto(); if (s === 'sep') renderSep(); if (s === 'lots') renderLots(); if (s === 'atelier' || s === 'apercu') { renderAll(); } try { window.scrollTo(0, 0); } catch (e) {}
  }

  /* ---------------------------------------------------------------- V237c : LOTS DE PLANS — un QR identique sur chaque plan, un scan = tous les plans ---------------------------------------------------------------- */
  /* Un lot regroupe plusieurs plans PDF. À l'export, chaque plan reçoit le MÊME QR (référence + code d'accès du portail public « plan »).
     Le lot est publié comme un dossier unique (fonction serveur plan_public_publier, 1 à 60 documents, migration-v236h) : un scan ouvre la liste de tous les plans. */
  var LK = 'exb_mep_lots', LBK = 'exb-plans-publics';
  function lots() { var a = jget(LK, []); return Array.isArray(a) ? a : []; }
  function saveLots(a) { try { var j = JSON.stringify(a), S0 = host && host.exbStorage; if (S0) S0.setItem(LK, j); else localStorage.setItem(LK, j); } catch (e) {} }
  function getLot(id) { return lots().filter(function (x) { return x.id === id; })[0] || null; }
  function putLot(l) { var a = lots(), i = a.map(function (x) { return x.id; }).indexOf(l.id); if (i < 0) a.push(l); else a[i] = l; saveLots(a); }
  function sbOn() { try { return host && host.exbSb && host.exbSb.isIn && host.exbSb.isIn() && navigator.onLine ? host.exbSb : null; } catch (e) { return null; } }
  function orgId() { try { return (host.EXBDB && host.EXBDB.org && host.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function rnd32() { var a = new Uint8Array(16); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function lotUrl(ref, code) { var b = ''; try { b = host.EXBVerif.vbase(); } catch (e) { b = (host && host.location ? host.location.origin : location.origin) + '/'; } return b + 'plan?ref=' + encodeURIComponent(ref) + '&k=' + encodeURIComponent(code); }
  function fmtCode(c) { c = String(c || ''); return c.length === 10 ? c.slice(0, 5) + '-' + c.slice(5) : c; }
  function lotDocs(l) { return (l.docIds || []).map(function (id) { return V.getDoc(id); }).filter(function (d) { return d && V.visible(d); }); }
  function rpcL(sb, n, b) { return sb.api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  async function purgeL(sb, o, token) {
    if (!/^[a-f0-9]{32}$/.test(String(token || ''))) return; var pre = o + '/' + token + '/';
    try { var L0 = await sb.api('/storage/v1/object/list/' + LBK, { method: 'POST', body: JSON.stringify({ prefix: pre, limit: 100 }) }), n = (L0 || []).map(function (x) { return pre + x.name; }); if (n.length) await sb.api('/storage/v1/object/' + LBK, { method: 'DELETE', body: JSON.stringify({ prefixes: n }) }); } catch (e) { /* non bloquant */ }
  }
  function renderLots() {
    var box = $('s-lots'); if (!box) return; var all = lots(), cur0 = S.lotCur ? getLot(S.lotCur) : null;
    var h = '<div class="note" style="margin-bottom:10px">Regroupez vos plans PDF en un <b>lot</b> : à l’export, <b>chaque plan reçoit le même QR</b>. Le client (ou le chantier) scanne n’importe quel plan et retrouve <b>tous les plans du lot</b> au même endroit, au lieu de dossiers séparés.</div>'
      + '<div class="card" style="margin-bottom:12px"><h2>📷 Scanner un QR de lot</h2><div class="body"><div class="acts"><button class="btn sm pri" type="button" data-l="cam">Scanner avec la caméra</button><button class="btn sm" type="button" data-l="img">Lire une photo / capture…</button><input type="file" id="lotImg" accept="image/*" hidden></div><video id="lotVid" playsinline muted style="display:none;width:100%;max-width:340px;margin-top:8px;border-radius:10px;background:#000"></video><div class="note" id="lotScanMsg">Le QR ouvre le lot correspondant ; un QR d’un autre appareil s’ouvre sur le portail des plans.</div></div></div>';
    h += '<div class="card" style="margin-bottom:12px"><h2>Mes lots · ' + all.length + '</h2><div class="body">' + (all.length ? '<table><tr><th>Lot</th><th>Plans</th><th>Portail</th><th></th></tr>' + all.map(function (l) {
      return '<tr><td>' + esc(l.nom) + '</td><td>' + (l.docIds || []).length + '</td><td>' + (l.ref ? '<b>' + esc(l.ref) + '</b>' + (l.retire ? ' (retiré)' : '') : '—') + '</td><td style="white-space:nowrap"><button class="btn sm" type="button" data-l="open" data-id="' + esc(l.id) + '">Ouvrir</button></td></tr>';
    }).join('') + '</table>' : '<div class="note">Aucun lot. Créez-en un.</div>') + '<div class="acts"><button class="btn sm gold" type="button" data-l="new">➕ Nouveau lot</button></div></div></div>';
    if (cur0) {
      var plans = liste().filter(function (d) { return d.classement.type === 'plan'; }), chosen = lotDocs(cur0), ids = chosen.map(function (d) { return d.id; });
      h += '<div class="card"><h2>Lot : ' + esc(cur0.nom) + '</h2><div class="body"><label class="f">Nom du lot (titre sur le portail)<input id="lotNom" value="' + esc(cur0.nom) + '" maxlength="150"></label>'
        + '<h3>Plans du lot · ' + chosen.length + '</h3>' + (chosen.length ? '<table><tr><th>#</th><th>Plan</th><th>Statut</th><th></th></tr>' + chosen.map(function (d, i) {
          return '<tr><td>' + (i + 1) + '</td><td>' + esc(d.nom) + '</td><td>' + chip(d.statut) + '</td><td style="white-space:nowrap"><button class="btn sm" type="button" data-l="up" data-id="' + esc(d.id) + '" aria-label="Monter">▲</button> <button class="btn sm" type="button" data-l="dn" data-id="' + esc(d.id) + '" aria-label="Descendre">▼</button> <button class="btn sm" type="button" data-l="rm" data-id="' + esc(d.id) + '" aria-label="Retirer du lot">✕</button></td></tr>';
        }).join('') + '</table>' : '<div class="note">Aucun plan dans ce lot. Ajoutez-en ci-dessous.</div>')
        + '<h3>Plans disponibles dans l’archive</h3>' + (plans.filter(function (d) { return ids.indexOf(d.id) < 0; }).length ? '<div style="max-height:220px;overflow:auto"><table>' + plans.filter(function (d) { return ids.indexOf(d.id) < 0; }).map(function (d) { return '<tr><td>' + esc(d.nom) + '</td><td>' + chip(d.statut) + '</td><td><button class="btn sm" type="button" data-l="add" data-id="' + esc(d.id) + '">Ajouter</button></td></tr>'; }).join('') + '</table></div><div class="acts"><button class="btn sm" type="button" data-l="addall">Ajouter tous les plans</button></div>' : '<div class="note">Tous les plans de l’archive sont dans le lot (ou importez-en dans « Plans · Notes de calcul »).</div>');
      h += (cur0.ref ? '<div class="w info"><b>Publié</b> — réf. ' + esc(cur0.ref) + ', code ' + esc(fmtCode(cur0.code)) + (cur0.publieLe ? ' · ' + fdate(cur0.publieLe) : '') + (cur0.retire ? ' · <b>retiré du portail</b>' : '') + '. Republier met à jour les plans : <b>le QR déjà imprimé reste valable</b>.</div>' : '')
        + '<div class="acts"><button class="btn sm" type="button" data-l="save">💾 Enregistrer</button><button class="btn sm ok" type="button" data-l="pub"' + (chosen.length ? '' : ' disabled') + '>🔗 Exporter avec QR commun et publier</button>'
        + (cur0.ref ? '<button class="btn sm" type="button" data-l="qr">QR / lien</button><button class="btn sm" type="button" data-l="zip">📦 Tous les plans (ZIP)</button><button class="btn sm" type="button" data-l="ret">Retirer du portail</button>' : '') + '<button class="btn sm" type="button" data-l="del">Supprimer le lot</button></div>'
        + '<div class="note">Chaque plan garde son cartouche et son statut ; seul le QR change (même QR sur tous). Seule une version « Approuvé » ou « Émis » devrait être mise à disposition des clients.</div></div></div>';
    }
    box.innerHTML = h;
  }
  async function lotAction(a, id) {
    var l = S.lotCur ? getLot(S.lotCur) : null;
    if (a === 'new') { var q = await modal('Nouveau lot de plans', '<label class="f">Nom du lot<input name="n" placeholder="Ex. Villa Kabongo — plans d’exécution" maxlength="150"></label>', [{ t: 'Annuler' }, { t: 'Créer', c: 'pri' }]); var nm = q.i === 1 ? String(q.v.n || '').trim() : ''; if (nm.length < 2) return; l = { id: 'LOT-' + rnd32().slice(0, 10), nom: nm, docIds: [], creeLe: Date.now() }; putLot(l); S.lotCur = l.id; return renderLots(); }
    if (a === 'open') { S.lotCur = id; return renderLots(); }
    if (a === 'cam') return scannerCamera(); if (a === 'img') return $('lotImg').click();
    if (!l) return;
    var nmEl = $('lotNom'); if (nmEl && String(nmEl.value).trim().length >= 2) l.nom = String(nmEl.value).trim();
    if (a === 'add') { if (l.docIds.indexOf(id) < 0) l.docIds.push(id); }
    else if (a === 'addall') { liste().filter(function (d) { return d.classement.type === 'plan'; }).forEach(function (d) { if (l.docIds.indexOf(d.id) < 0) l.docIds.push(d.id); }); }
    else if (a === 'rm') l.docIds = l.docIds.filter(function (x) { return x !== id; });
    else if (a === 'up' || a === 'dn') { var i = l.docIds.indexOf(id), j = a === 'up' ? i - 1 : i + 1; if (i >= 0 && j >= 0 && j < l.docIds.length) { var t = l.docIds[i]; l.docIds[i] = l.docIds[j]; l.docIds[j] = t; } }
    else if (a === 'save') { putLot(l); toast('Lot enregistré.', 'ok'); return renderLots(); }
    else if (a === 'del') { var c = await modal('Supprimer le lot', '<p>Supprimer « ' + esc(l.nom) + ' » de cet appareil ? Les plans restent dans l’archive.' + (l.ref && !l.retire ? ' <b>Il reste publié sur le portail</b> : utilisez d’abord « Retirer du portail » si besoin.' : '') + '</p>', [{ t: 'Annuler' }, { t: 'Supprimer', c: 'pri' }]); if (c.i !== 1) return; saveLots(lots().filter(function (x) { return x.id !== l.id; })); S.lotCur = null; return renderLots(); }
    else if (a === 'pub') { putLot(l); return publierLot(l); }
    else if (a === 'qr') return montrerLot(l);
    else if (a === 'zip') return zipLot(l);
    else if (a === 'ret') return retirerLot(l);
    putLot(l); renderLots();
  }
  async function publierLot(l) {
    var sb = sbOn(), o = orgId(); if (!sb || !o) return toast('Publication impossible hors connexion : connectez-vous au serveur (☁️) dans le logiciel.', 'err');
    try { var B = host.EXB81; if (B && B.can && !B.can('plans_fichiers', 'ecrire')) return toast('Votre profil n’a pas le droit de publier aux clients (droit « plans_fichiers »).', 'err'); } catch (e) {}
    var docs = lotDocs(l); if (!docs.length) return toast('Le lot est vide.', 'err'); if (docs.length > 60) return toast('Un lot est limité à 60 plans.', 'err');
    if (!host.EXBQR || !host.EXBQR.matrix || !host.EXBVerif) return toast('Générateur de QR indisponible : ouvrez l’Atelier depuis le logiciel.', 'err');
    var nv = docs.filter(function (d) { return PUB_OK.indexOf(d.statut) < 0; });
    var q = await modal('Exporter et publier le lot', '<p>« ' + esc(l.nom) + ' » : <b>' + docs.length + ' plan(s)</b> recevront le même QR, puis seront mis à disposition sur le portail.</p>' + (nv.length ? '<div class="w attention"><b>' + nv.length + ' plan(s) non validé(s)</b> (statut autre que Approuvé / Émis) : ' + esc(nv.slice(0, 6).map(function (d) { return d.nom; }).join(', ')) + (nv.length > 6 ? '…' : '') + '<label class="f" style="flex-direction:row;gap:8px;align-items:center"><input type="checkbox" name="ok"> Je confirme les publier tels quels</label></div>' : '') + '<p class="note">Une nouvelle version est enregistrée pour chaque plan. L’original reste intact.</p>', [{ t: 'Annuler' }, { t: 'Publier', c: 'pri' }]);
    if (q.i !== 1) return; if (nv.length && !q.v.ok) return toast('Publication annulée : plans non validés non confirmés.', 'err');
    if (!(await nomActeur('Identification — export du lot'))) return toast('Identification requise pour tracer l’export.', 'err');
    var token = rnd32(), first = !l.ref, ref = l.ref, code = l.code, fn = docs.map(function (d, i) { return ('0' + (i + 1)).slice(-2) + '-' + (slug(d.nom.replace(/\.pdf$/i, '')).slice(0, 55) || 'plan') + '.pdf'; });
    var meta = docs.map(function (d, i) { return { nom: ((d.config.champs && d.config.champs.titre) || d.nom.replace(/\.pdf$/i, '')).slice(0, 110), fichier: o + '/' + token + '/' + fn[i], format: 'PDF', taille: '', kind: 'plan' }; });
    function args(ml, rf) { return { p_org: o, p_plan_id: l.id, p_ref_plan: '', p_titre: l.nom, p_type: 'Lot de ' + docs.length + ' plans', p_moe: S.ent.nom || 'Excellencia Building', p_mo: '', p_concepteur: '', p_echelle: '', p_indice: docs.length + ' plans', p_apercu: null, p_docs: ml, p_token: token, p_ref: rf || null }; }
    try {
      progress('Réservation de la référence du lot…');
      if (first) { var r0 = await rpcL(sb, 'plan_public_publier', args(meta, null)); if (!r0 || !r0.ok) throw new Error((r0 && r0.erreur) || 'Publication refusée par le serveur.'); ref = r0.ref; code = r0.code; }
      var url = lotUrl(ref, code), qr = { url: url, code: ref, matrix: host.EXBQR.matrix(url), rec: null, lot: { n: docs.length } }, items = [];
      for (var i = 0; i < docs.length; i++) {
        progress('Plan ' + (i + 1) + ' / ' + docs.length + ' — ' + docs[i].nom, i / docs.length);
        var r = await exporter(false, docs[i], true, { qr: qr, silent: true }); if (!r.ok) throw new Error(docs[i].nom + ' : ' + r.msg);
        await sb.api('/storage/v1/object/' + LBK + '/' + o + '/' + token + '/' + fn[i], { method: 'POST', headers: { 'Content-Type': 'application/pdf', 'x-upsert': 'true' }, body: new Blob([r.bytes], { type: 'application/pdf' }) });
        meta[i].taille = fsize(r.bytes.length); items.push({ docId: docs[i].id, nom: meta[i].nom, sha: r.v && r.v.sha256, tag: r.v && r.v.tag, fic: fn[i] });
      }
      progress('Publication du lot…'); var r1 = await rpcL(sb, 'plan_public_publier', args(meta, ref)); if (!r1 || !r1.ok) throw new Error((r1 && r1.erreur) || 'Publication refusée par le serveur.');
      if (r1.ancien_token && r1.ancien_token !== token) purgeL(sb, o, r1.ancien_token);
      l.ref = r1.ref || ref; l.code = r1.code || code; l.token = token; l.publieLe = Date.now(); l.retire = false; l.items = items; putLot(l); progress('');
      docs.forEach(function (d) { V.log('lot', d, { ref: l.ref, detail: 'Lot « ' + l.nom + ' » — QR commun ' + l.ref }); });
      toast('Lot publié : ' + docs.length + ' plans, QR commun ' + l.ref + '.', 'ok'); renderAll(); renderLots(); montrerLot(l);
    } catch (e) {
      progress(''); var msg = String(e && e.message || e);
      if (first && ref) { try { await rpcL(sb, 'plan_public_retirer', { p_org: o, p_ref: ref }); } catch (x) {} }
      await purgeL(sb, o, token);
      if (/plan_public|schema cache|PGRST202/i.test(msg)) msg = 'Fonction serveur absente : exécutez supabase/migration-v236h-lots-de-plans.sql (et v129) dans Supabase › SQL Editor.';
      if (/limit|invalide \(1 à 60|between/i.test(msg) && /8/.test(msg)) msg += ' — exécutez supabase/migration-v236h-lots-de-plans.sql.';
      toast('Publication du lot impossible : ' + msg, 'err');
    }
  }
  async function montrerLot(l) {
    var url = lotUrl(l.ref, l.code), png = ''; try { png = host.EXBVerif.qrPng(url); } catch (e) {}
    var r = await modal('Lot publié — ' + l.nom, '<div style="display:flex;flex-wrap:wrap;gap:16px;align-items:center">' + (png ? '<img src="' + png + '" alt="QR du lot" style="width:200px;height:200px;image-rendering:pixelated;border:1px solid #dce4ef;border-radius:8px">' : '') + '<div><div class="note">Référence</div><b style="font-size:20px">' + esc(l.ref) + '</b><div class="note" style="margin-top:8px">Code d’accès</div><b style="font-size:20px;letter-spacing:1px">' + esc(fmtCode(l.code)) + '</b><div class="note" style="margin-top:8px">Ce même QR est sur les ' + (l.items ? l.items.length : (l.docIds || []).length) + ' plans du lot.</div></div></div><label class="f">Lien<input readonly value="' + esc(url) + '" onclick="this.select()"></label>',
      [{ t: 'Fermer' }, { t: '📋 Copier le lien' }, { t: '🖨 Fiche QR (A4)', c: 'pri' }]);
    if (r.i === 1) { try { await navigator.clipboard.writeText(url); toast('Lien copié.', 'ok'); } catch (e) { toast('Copie impossible : sélectionnez le lien.', 'err'); } }
    if (r.i === 2) { try { host.EXBPUB.print(l.ref, l.code, l.nom, { label: 'LOT DE PLANS', file: 'QR-LOT-' }); } catch (e) { toast('Fiche QR indisponible ici.', 'err'); } }
  }
  async function zipLot(l) {
    var Z = host && host.EXB_ZIP; if (!Z || !Z.store) return toast('Création du ZIP indisponible ici.', 'err'); var files = [];
    for (var i = 0; i < (l.items || []).length; i++) { var it = l.items[i], by = it.sha ? await V.getFile(it.sha) : null; if (by) files.push({ name: it.fic, data: by }); }
    if (!files.length) return toast('Fichiers du lot introuvables sur cet appareil : republiez le lot.', 'err');
    dl(Z.store(files), slug(l.nom) + '-' + l.ref + '.zip', 'application/zip'); toast(files.length + ' plan(s) dans le ZIP.', 'ok');
  }
  async function retirerLot(l) {
    var sb = sbOn(), o = orgId(); if (!sb || !o) return toast('Connexion au serveur (☁️) requise.', 'err');
    var c = await modal('Retirer du portail', '<p>Le QR du lot ne donnera plus accès aux plans (les fichiers publics sont supprimés). Vous pourrez republier : même QR, même code.</p>', [{ t: 'Annuler' }, { t: 'Retirer', c: 'pri' }]); if (c.i !== 1) return;
    try { var r = await rpcL(sb, 'plan_public_retirer', { p_org: o, p_ref: l.ref }); if (!r || !r.ok) throw new Error((r && r.erreur) || 'refusé'); if (r.token) await purgeL(sb, o, r.token); l.retire = true; putLot(l); toast('Lot retiré du portail.', 'ok'); renderLots(); } catch (e) { toast('Retrait impossible : ' + (e && e.message || e), 'err'); }
  }
  /* scan : le QR d'un lot ouvre le lot local correspondant, sinon la page publique des plans */
  function lotScanne(txt) {
    var m = $('lotScanMsg'); txt = String(txt || '').trim(); var ref = '', u = null;
    try { u = new URL(txt); ref = (u.searchParams.get('ref') || '').toUpperCase(); } catch (e) { ref = /^EXB-\d{4}-\d+$/i.test(txt) ? txt.toUpperCase() : ''; }
    var l = ref ? lots().filter(function (x) { return String(x.ref || '').toUpperCase() === ref; })[0] : null;
    if (l) { S.lotCur = l.id; renderLots(); toast('Lot « ' + l.nom + ' » ouvert.', 'ok'); return true; }
    if (u && /^https?:$/.test(u.protocol) && ref) { window.open(u.href, '_blank', 'noopener'); if (m) m.textContent = 'Lot ' + ref + ' ouvert sur le portail des plans (il n’est pas dans cet appareil).'; return true; }
    if (m) m.textContent = 'QR non reconnu comme un lot de plans.'; return false;
  }
  async function scannerCamera() {
    var m = $('lotScanMsg'), vid = $('lotVid'); if (!('BarcodeDetector' in window)) { if (m) m.textContent = 'Ce navigateur ne lit pas les QR : utilisez l’appareil photo du téléphone, ou « Lire une photo ».'; return; }
    var st = null; try { st = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); } catch (e) { if (m) m.textContent = 'Caméra non autorisée : utilisez « Lire une photo ».'; return; }
    var det = new BarcodeDetector({ formats: ['qr_code'] }); vid.srcObject = st; vid.style.display = 'block'; await vid.play(); if (m) m.textContent = 'Visez le QR du lot…';
    var stop = function () { st.getTracks().forEach(function (t) { t.stop(); }); vid.style.display = 'none'; vid.srcObject = null; }, t0 = Date.now();
    (async function loop() { if (!vid.srcObject) return; try { var r = await det.detect(vid); if (r && r[0]) { stop(); lotScanne(r[0].rawValue); return; } } catch (e) {} if (Date.now() - t0 > 60000) { stop(); if (m) m.textContent = 'Aucun QR lu.'; return; } setTimeout(loop, 300); })();
  }
  async function scannerImage(f) {
    var m = $('lotScanMsg'); if (!f) return; if (!('BarcodeDetector' in window)) { if (m) m.textContent = 'Ce navigateur ne lit pas les QR : utilisez l’appareil photo du téléphone.'; return; }
    try { var bmp = await createImageBitmap(f), r = await new BarcodeDetector({ formats: ['qr_code'] }).detect(bmp); if (r && r[0]) lotScanne(r[0].rawValue); else if (m) m.textContent = 'Aucun QR trouvé dans l’image.'; } catch (e) { if (m) m.textContent = 'Image illisible.'; }
  }

  /* ---------------------------------------------------------------- événements ---------------------------------------------------------------- */
  function init() {
    try { var t = host && host.document.documentElement.getAttribute('data-theme'); if (t) document.documentElement.setAttribute('data-theme', t); } catch (e) {}
    $('s-lots').addEventListener('click', function (e) { var b = e.target.closest('button[data-l]'); if (b) lotAction(b.getAttribute('data-l'), b.getAttribute('data-id')); });
    $('s-lots').addEventListener('change', function (e) { if (e.target.id === 'lotImg') { var f = e.target.files[0]; e.target.value = ''; scannerImage(f); } });
    $('tabs').addEventListener('click', function (e) { var b = e.target.closest('button[data-s]'); if (b) go(b.getAttribute('data-s')); });
    $('bImp').onclick = function () { go('import'); }; $('bMod').onclick = function () { go('modeles'); }; $('bSave').onclick = function () { var d = cur(); if (d) { V.putDoc(d); V.log('enregistre', d, { detail: 'configuration' }); toast('Configuration enregistrée.', 'ok'); } else toast('Aucun document.', 'err'); };
    $('bExp').onclick = function () { exporter(false); };
    var dr = $('drop'), fi = $('file'); $('pick').onclick = function () { fi.click(); }; fi.onchange = function () { if (fi.files.length) importer(Array.prototype.slice.call(fi.files)); fi.value = ''; };
    ['dragenter', 'dragover'].forEach(function (ev) { dr.addEventListener(ev, function (e) { e.preventDefault(); dr.classList.add('over'); }); }); ['dragleave', 'drop'].forEach(function (ev) { dr.addEventListener(ev, function (e) { e.preventDefault(); dr.classList.remove('over'); }); });
    dr.addEventListener('drop', function (e) { var fs = Array.prototype.slice.call(e.dataTransfer.files).filter(function (f) { return /\.pdf$/i.test(f.name) || f.type === 'application/pdf'; }); if (fs.length) importer(fs); });
    var sp0 = $('sepProj'); if (sp0) sp0.onchange = function () { S.sepProj = sp0.value; renderSep(); };
    /* V234c : zones d'import séparées (plans d'exécution / notes de calcul) */
    function pdfs(fl) { return Array.prototype.slice.call(fl).filter(function (f) { return /\.pdf$/i.test(f.name) || f.type === 'application/pdf'; }); }
    document.querySelectorAll('[data-z]').forEach(function (box) {
      var z = box.getAttribute('data-z'), inp = box.querySelector('input[type=file]'), bt = box.querySelector('[data-pick]');
      bt.onclick = function () { inp.click(); }; inp.onchange = function () { var fs = Array.prototype.slice.call(inp.files); inp.value = ''; if (fs.length) importer(fs, z); };
      ['dragenter', 'dragover'].forEach(function (ev) { box.addEventListener(ev, function (e) { e.preventDefault(); box.classList.add('over'); }); }); ['dragleave', 'drop'].forEach(function (ev) { box.addEventListener(ev, function (e) { e.preventDefault(); box.classList.remove('over'); }); });
      box.addEventListener('drop', function (e) { var fs = pdfs(e.dataTransfer.files); if (fs.length) importer(fs, z); });
    });
    Object.keys(ZONES).forEach(function (z) {
      var el = $(ZONES[z].log); if (!el) return;
      el.addEventListener('click', function (e) {
        var b = e.target.closest('button'); if (!b) return;
        if (b.hasAttribute('data-rm')) { var k = +b.getAttribute('data-rm'); S.rows[z] = S.rows[z].filter(function (r) { return r.k !== k || !r.fini; }); paintLog(z); }
        else if (b.hasAttribute('data-clr')) { S.rows[z] = S.rows[z].filter(function (r) { return !r.fini; }); paintLog(z); }
        else if (b.hasAttribute('data-op')) { var d = V.getDoc(b.getAttribute('data-op')); if (d && V.visible(d)) { S.cur = d.id; S.page = 0; S.origPdf = {}; go('atelier'); } }
      });
    });
    $('s-sep').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-os],button[data-od]'); if (!b) return;
      if (b.hasAttribute('data-os')) { var d0 = V.getDoc(b.getAttribute('data-os')); if (d0) { S.cur = d0.id; S.page = 0; S.origPdf = {}; go('atelier'); } return; }
      (async function () { var d = V.getDoc(b.getAttribute('data-od')), by = d && await V.getFile(d.sha256); if (!by) return toast('Original introuvable.', 'err'); dl(by, d.nom); V.log('telechargement', d, { ref: d.sha256, detail: 'original' }); })();
    });
    $('list').addEventListener('click', function (e) { var c = e.target.closest('[data-sel]'); if (c) { S.sel[c.getAttribute('data-sel')] = c.checked; renderList(); if (cur() && cur().config.modele === 'dossier') refresh(); return; } var it = e.target.closest('.ditem'); if (it) { S.cur = it.getAttribute('data-id'); S.page = 0; S.origPdf = {}; renderAll(); } });
    $('vmode').addEventListener('click', function (e) { var b = e.target.closest('button[data-m]'); if (!b) return; S.vue = b.getAttribute('data-m'); document.querySelectorAll('#vmode button').forEach(function (x) { x.classList.toggle('on', x === b); }); draw(); });
    $('pPrev').onclick = function () { if (S.page > 0) { S.page--; draw(); } }; $('pNext').onclick = function () { if (S.page < total() - 1) { S.page++; draw(); } };
    $('zIn').onclick = function () { S.zoom = Math.min(4, S.zoom * 1.25); draw(); }; $('zOut').onclick = function () { S.zoom = Math.max(0.25, S.zoom / 1.25); draw(); }; $('rot').onclick = function () { S.rot = (S.rot + 90) % 360; draw(); };
    $('thumbs').addEventListener('click', function (e) { var b = e.target.closest('button[data-p]'); if (b) { S.page = +b.getAttribute('data-p'); draw(); } });
    var rt; window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 250); });
    chargerIdentite().then(function () { renderAll(); });
    /* V214 : envoi des fichiers PDF au serveur (espace privé) dès qu'une connexion est disponible */
    try { V.syncFichiers(); setInterval(function () { V.syncFichiers(); }, 60000); window.addEventListener('online', function () { V.syncFichiers(); }); } catch (e) {}
    var a = liste(); if (a.length) S.cur = a[0].id; renderAll();
  }
  window.EXBATELIER = { refresh: function () { renderAll(); }, importer: importer, lots: { liste: lots, publier: publierLot, scanne: lotScanne }, version: 'V237c-atelier-mep' };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
