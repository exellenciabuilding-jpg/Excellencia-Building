/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-export (génération du PDF habillé, via pdf-lib).
 * NON DESTRUCTIF : les pages d'origine sont COPIÉES telles quelles (flux de contenu, annotations, formulaires intacts) dans un NOUVEAU document.
 * Le cartouche / en-tête / pied de page est ajouté dans un flux de contenu SÉPARÉ, après le contenu d'origine, en vectoriel (texte, traits, logo).
 * Le contenu d'origine est encadré par une sauvegarde / restauration de l'état graphique (q … Q) : il ne peut pas être teinté ni déplacé par l'ajout.
 * Mode « bande » : seule la zone visible (CropBox) est agrandie sous la page, sans déplacer ni mettre à l'échelle le contenu d'origine.
 * Le PDF d'origine importé n'est jamais écrit ici : seul son contenu est lu. */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {}, PT = 72 / 25.4;
  var SUBST = { '≥': '>=', '≤': '<=', '−': '-', '→': '->', 'γ': 'gamma ', 'σ': 'sigma ', 'Δ': 'Delta ', ' ': ' ', ' ': ' ', '“': '"', '”': '"', '’': '’', '≈': '~', '∅': 'Ø', '✓': 'v', '•': '•' };

  function f3(n) { return (Math.round(n * 1000) / 1000).toString(); }
  function rgb(hex) { var m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '#000000')); if (!m) return [0, 0, 0]; var n = parseInt(m[1], 16); return [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; }
  function col(hex, fill) { var c = rgb(hex); return f3(c[0]) + ' ' + f3(c[1]) + ' ' + f3(c[2]) + (fill ? ' rg' : ' RG'); }

  /* Repère « visuel » (mm, origine en haut à gauche, y vers le bas) → espace utilisateur de la page, selon la rotation et la CropBox. */
  function baseMatrix(cb, rot) {
    var s = PT, cx = cb.x, cy = cb.y, cw = cb.width, ch = cb.height;
    if (rot === 90) return [0, s, s, 0, cx, cy];
    if (rot === 180) return [-s, 0, 0, s, cx + cw, cy];
    if (rot === 270) return [0, -s, -s, 0, cx + cw, cy + ch];
    return [s, 0, 0, -s, cx, cy + ch];
  }
  /* V221 : bande ajoutée au-dessus de la page (côté « haut » visuel) — bandeau d'en-tête du style Excellencia. */
  function extendTop(cb, rot, b) {
    var r = { x: cb.x, y: cb.y, width: cb.width, height: cb.height };
    if (rot === 90) { r.x -= b; r.width += b; } else if (rot === 180) { r.y -= b; r.height += b; } else if (rot === 270) r.width += b; else r.height += b;
    return r;
  }
  /* Nouvelle zone visible quand on ajoute une bande de b points sous la page (côté « bas » visuel). */
  function extendBottom(cb, rot, b) {
    var r = { x: cb.x, y: cb.y, width: cb.width, height: cb.height };
    if (rot === 90) r.width += b; else if (rot === 180) r.height += b; else if (rot === 270) { r.x -= b; r.width += b; } else { r.y -= b; r.height += b; }
    return r;
  }

  function Painter(PL, doc, page, fonts, images, notes, label) {
    this.PL = PL; this.doc = doc; this.page = page; this.fonts = fonts; this.images = images; this.notes = notes; this.label = label;
    this.ops = []; this.fn = {}; this.gs = {}; this.im = {}; this.lastAlpha = 1;
  }
  var P = Painter.prototype;
  P.font = function (k) { return this.fonts[k === 'b' ? 'b' : k === 'i' ? 'i' : k === 'bi' ? 'bi' : 'r']; };
  P.clean = function (font, t) {
    var o = '', bad = 0; t = String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ');
    for (var i = 0; i < t.length; i++) { var ch = t[i], r = SUBST[ch] != null ? SUBST[ch] : ch; try { font.encodeText(r); o += r; } catch (e) { o += '?'; bad++; } }
    if (bad) this.notes.push({ niv: 'attention', msg: this.label + ' : ' + bad + ' caractère(s) non pris en charge par la police standard remplacé(s) par « ? ».' });
    return o;
  };
  P.alpha = function (a) {
    a = Math.round(a * 1000) / 1000; if (a === this.lastAlpha) return; this.lastAlpha = a;
    var k = 'GS' + String(a).replace('.', '_'); if (!this.gs[k]) { this.gs[k] = this.page.node.newExtGState(k, this.doc.context.obj({ Type: 'ExtGState', ca: a, CA: a })); }
    this.ops.push(this.gs[k].toString() + ' gs');
  };
  /* V214 : QR en vectoriel (carrés pleins) ; la matrice vient de EXBQR.matrix (job.qr.matrix) ; marge blanche de 2 modules */
  P.qr = function (e) {
    var m = this.qrm; if (!m || !m.length) return; var n = m.length, q = 2, tt = n + 2 * q, s = e.s / tt, o = this.ops, pth = [];
    this.alpha(1); o.push('1 1 1 rg ' + f3(e.x) + ' ' + f3(e.y) + ' ' + f3(e.s) + ' ' + f3(e.s) + ' re f');
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) pth.push(f3(e.x + (c + q) * s) + ' ' + f3(e.y + (r + q) * s) + ' ' + f3(s) + ' ' + f3(s) + ' re');
    o.push('0 0 0 rg ' + pth.join(' ') + ' f');
  };
  P.run = function (els, base, inner) {
    var self = this, o = this.ops; if (!inner) o.push('q ' + base.map(f3).join(' ') + ' cm');
    els.forEach(function (e) {
      if (e.t === 'rect') {
        self.alpha(e.alpha != null ? e.alpha : 1);
        if (e.fill) o.push(col(e.fill, true) + ' ' + f3(e.x) + ' ' + f3(e.y) + ' ' + f3(e.w) + ' ' + f3(e.h) + ' re f');
        if (e.stroke) o.push(col(e.stroke, false) + ' ' + f3(e.lw || 0.25) + ' w ' + f3(e.x) + ' ' + f3(e.y) + ' ' + f3(e.w) + ' ' + f3(e.h) + ' re S');
      } else if (e.t === 'line') { self.alpha(1); o.push(col(e.color || '#000000', false) + ' ' + f3(e.lw || 0.25) + ' w ' + f3(e.x1) + ' ' + f3(e.y1) + ' m ' + f3(e.x2) + ' ' + f3(e.y2) + ' l S'); }
      else if (e.t === 'text') self.text(e);
      else if (e.t === 'para') self.para(e);
      else if (e.t === 'img') self.img(e);
      else if (e.t === 'qr') self.qr(e);
      else if (e.t === 'wm') self.wm(e);
      else if (e.t === 'flow') self.flow(e);
    });
    if (!inner) o.push('Q');
  };
  /* V221 : texte rédigé (éditeur Word) — mesure exacte des polices, titres et listes comme les feuilles de calcul du logiciel */
  P.flow = function (e) {
    var self = this, L = NS.layout, fr = this.font('r'), fb = this.font('b');
    function quiet(font, t) { var o = ''; t = String(t == null ? '' : t); for (var i = 0; i < t.length; i++) { var ch = t[i], r = SUBST[ch] != null ? SUBST[ch] : ch; try { font.encodeText(r); o += r; } catch (x) { o += '?'; } } return o; }
    var lay = L.flowLayout(e.items, e.w - 6, function (t, size, bold) { var f = bold ? fb : fr; return f.widthOfTextAtSize(quiet(f, t), size); });
    lay.lignes.forEach(function (g) {
      var it = g.item, F = L.FLOW[it.k] || L.FLOW.p, y = e.y + g.y, x = e.x + 3 + (F.ind || 0) * 0;
      if (it.k === 'blank') return;
      if (it.k === 'h2') {
        self.run([{ t: 'rect', x: e.x, y: y + 0.4, w: 1.3, h: F.lead - 1.2, fill: '#173565' }, { t: 'line', x1: e.x, y1: y + F.lead + 0.2, x2: e.x + e.w, y2: y + F.lead + 0.2, lw: 0.3, color: '#C49A38' }], [1, 0, 0, 1, 0, 0], true);
        x = e.x + 3.6;
      }
      g.lines.forEach(function (l, i) {
        var o = { t: 'text', s: l, x: x + (it.k === 'li' && i ? 3.2 : 0), y: y + F.lead * 0.8 + i * F.lead, size: F.size, font: it.k === 'h2' || it.k === 'h3' ? 'b' : 'r', color: it.k === 'h2' || it.k === 'h3' ? '#173565' : '#172033' };
        self.text(o);
      });
    });
  };
  P.tf = function (key, size) { if (!this.fn[key]) this.fn[key] = this.page.node.newFontDictionary('EXB' + key, this.font(key).ref); return this.fn[key].toString() + ' ' + f3(size) + ' Tf'; };
  P.text = function (e) {
    if (e.s === '' || e.s == null) return;
    var key = e.font || 'r', font = this.font(key), t = this.clean(font, e.s), size = e.size, sp = +e.sp || 0, w = font.widthOfTextAtSize(t, size) + sp * Math.max(0, t.length - 1);
    if (e.maxW && w > e.maxW && sp) { sp = Math.max(0, sp * (e.maxW / w) * 0.6); w = font.widthOfTextAtSize(t, size) + sp * Math.max(0, t.length - 1); }
    if (e.maxW && w > e.maxW) {
      var k = e.maxW / w; if (k >= 0.62 && e.fit !== false) { size = size * k; w = e.maxW; if (k < 0.8) this.notes.push({ niv: 'info', msg: this.label + ' : texte réduit pour tenir dans le champ « ' + (e.champ || t.slice(0, 20)) + ' ».' }); }
      else {
        if (e.fit !== false) size = size * 0.8; var tt = t; while (tt.length > 1 && font.widthOfTextAtSize(tt + '…', size) > e.maxW) tt = tt.slice(0, -1);
        this.notes.push({ niv: 'attention', msg: this.label + ' : texte tronqué dans le champ « ' + (e.champ || t.slice(0, 20)) + ' » (trop long pour le cartouche).' }); t = tt + '…'; w = font.widthOfTextAtSize(t, size);
      }
    }
    var x = e.x; if (e.align === 'c') x -= w / 2; else if (e.align === 'r') x -= w;
    this.alpha(e.alpha != null ? e.alpha : 1); this.ops.push(col(e.color || '#000000', true) + ' BT ' + this.tf(key, size) + (sp ? ' ' + f3(sp) + ' Tc' : '') + ' 1 0 0 -1 ' + f3(x) + ' ' + f3(e.y) + ' Tm ' + font.encodeText(t).toString() + ' Tj' + (sp ? ' 0 Tc' : '') + ' ET');
  };
  P.para = function (e) {
    var key = e.font || 'r', font = this.font(key), t = this.clean(font, e.s), words = t.split(/\s+/), lines = [], cur = '';
    words.forEach(function (w1) { var tr = cur ? cur + ' ' + w1 : w1; if (font.widthOfTextAtSize(tr, e.size) <= e.w) cur = tr; else { if (cur) lines.push(cur); cur = w1; } }); if (cur) lines.push(cur);
    if (lines.length > e.lines) { this.notes.push({ niv: 'attention', msg: this.label + ' : paragraphe tronqué.' }); lines = lines.slice(0, e.lines); lines[lines.length - 1] = lines[lines.length - 1].replace(/\s*\S*$/, '…'); }
    var self = this; lines.forEach(function (l, i) { self.text({ t: 'text', s: l, x: e.x, y: e.y + (i + 1) * e.lead, size: e.size, color: e.color, font: key }); });
  };
  P.img = function (e) {
    var im = this.images[e.key]; if (!im) return;
    var r = Math.min(e.w / im.width, e.h / im.height), w = im.width * r, h = im.height * r, x = e.x + (e.w - w) / 2, y = e.y + (e.h - h) / 2;
    if (!this.im[e.key]) this.im[e.key] = this.page.node.newXObject('EXBImg' + e.key, im.ref);
    this.alpha(1); this.ops.push('q ' + [f3(w), 0, 0, f3(-h), f3(x), f3(y + h)].join(' ') + ' cm ' + this.im[e.key].toString() + ' Do Q');
  };
  P.wm = function (e) {
    var font = this.font('b'), t = this.clean(font, e.s), size = e.size, w = font.widthOfTextAtSize(t, size), th = 30 * Math.PI / 180, c = Math.cos(th), s = Math.sin(th);
    var x = e.cx - (w / 2) * c, y = e.cy + (w / 2) * s;
    this.alpha(e.alpha || 0.07); this.ops.push(col('#0B2A5B', true) + ' BT ' + this.tf('b', size) + ' ' + [f3(c), f3(-s), f3(-s), f3(-c), f3(x), f3(y)].join(' ') + ' Tm ' + font.encodeText(t).toString() + ' Tj ET');
  };
  P.flush = function (doc, page) {
    this.alpha(1);
    var st = doc.context.register(doc.context.flateStream(this.ops.join('\n'))); page.node.addContentStream(st);
  };

  /* job : voir exb-doc-layout.js ; job.docs[i].bytes = octets du PDF d'origine ; job.logoImage = { bytes, type:'png'|'jpg' } ; job.meta = { auteur, version, shaOriginal } */
  async function build(PL, job, plan) {
    if (!PL) throw new Error('Le module PDF (pdf-lib) n’est pas chargé.');
    plan = plan || NS.layout.plan(job);
    if (!job.apercu && plan.bloquants && plan.bloquants.length) { var er = new Error('Export impossible : ' + plan.bloquants[0].msg); er.bloquants = plan.bloquants; throw er; }
    var out = await PL.PDFDocument.create(), SF = PL.StandardFonts, notes = [], srcs = [], docs = plan.docs || job.docs;
    var fonts = { r: await out.embedFont(SF.Helvetica), b: await out.embedFont(SF.HelveticaBold), i: await out.embedFont(SF.HelveticaOblique), bi: await out.embedFont(SF.HelveticaBoldOblique) }, images = {};
    if (job.logoImage && job.logoImage.bytes) {
      try { images.logo = job.logoImage.type === 'jpg' ? await out.embedJpg(job.logoImage.bytes) : await out.embedPng(job.logoImage.bytes); }
      catch (e) { notes.push({ niv: 'attention', msg: 'Logo illisible : le cartouche indique « LOGO À FOURNIR ».' }); }
    }
    if (job.visaImage && job.visaImage.bytes) {   /* V236g : visa / cachet du cartouche des plans (versions approuvées ou émises uniquement, décidé par la mise en page) */
      try { images.visa = job.visaImage.type === 'jpg' ? await out.embedJpg(job.visaImage.bytes) : await out.embedPng(job.visaImage.bytes); } catch (e) { notes.push({ niv: 'info', msg: 'Visa / cachet illisible : case laissée vide.' }); }
    }
    for (var i = 0; i < docs.length; i++) {
      var d = docs[i]; if (!d.bytes) throw new Error('Octets du PDF absents : ' + d.nom);
      try { srcs[i] = await PL.PDFDocument.load(d.bytes, { updateMetadata: false }); }
      catch (e) { var enc = (e && (e.name === 'EncryptedPDFError' || /encrypt/i.test(String(e.message)))); throw new Error(enc ? '« ' + d.nom + ' » est protégé (chiffré) : il ne peut pas être habillé sans le déprotéger au préalable par son propriétaire.' : '« ' + d.nom + ' » ne peut pas être repris sans altération (' + (e && e.message || e) + ').'); }
      if (srcs[i].getPageCount() !== (d.analyse && d.analyse.pages.length)) throw new Error('« ' + d.nom + ' » : le nombre de pages diffère de l’analyse (' + srcs[i].getPageCount() + ' ≠ ' + (d.analyse && d.analyse.pages.length) + '). Relancez l’analyse.');
    }
    var map = [];
    for (var k = 0; k < plan.pages.length; k++) {
      var p = plan.pages[k], page, label = 'Page ' + (k + 1);
      if (p.kind === 'orig') {
        var cp = (await out.copyPages(srcs[p.doc], [p.page]))[0]; page = out.addPage(cp);
        var rot = ((page.getRotation().angle % 360) + 360) % 360, cb = page.getCropBox(), mb = page.getMediaBox(), geom = cb;
        if (p.band || p.bandTop) {
          var nb = cb; if (p.bandTop) nb = extendTop(nb, rot, p.bandTop * PT); if (p.band) nb = extendBottom(nb, rot, p.band.h * PT); geom = nb;
          var ux0 = Math.min(mb.x, nb.x), uy0 = Math.min(mb.y, nb.y), ux1 = Math.max(mb.x + mb.width, nb.x + nb.width), uy1 = Math.max(mb.y + mb.height, nb.y + nb.height);
          page.setMediaBox(ux0, uy0, ux1 - ux0, uy1 - uy0); page.setCropBox(nb.x, nb.y, nb.width, nb.height);
        }
        if (p.els && p.els.length) {
          var qs = out.context.register(out.context.flateStream('q')), qe = out.context.register(out.context.flateStream('Q')); page.node.wrapContentStreams(qs, qe);
          var pt = new Painter(PL, out, page, fonts, images, notes, label); pt.qrm = job.qr && job.qr.matrix; pt.run(p.els, baseMatrix(geom, rot)); pt.flush(out, page);
        }
        map.push({ out: k, kind: 'orig', doc: p.doc, page: p.page, mode: p.mode, W: p.W, H: p.H, band: p.band ? p.band.h : 0, bandTop: p.bandTop || 0, rot: rot, zone: p.zone || null });
      } else {
        page = out.addPage([p.W * PT, p.H * PT]);
        var pt2 = new Painter(PL, out, page, fonts, images, notes, label + ' (' + p.kind + ')'); pt2.qrm = job.qr && job.qr.matrix; pt2.run(p.els, baseMatrix({ x: 0, y: 0, width: p.W * PT, height: p.H * PT }, 0)); pt2.flush(out, page);
        map.push({ out: k, kind: p.kind, W: p.W, H: p.H });
      }
    }
    var M = job.meta || {}, ch = job.champs || {};
    out.setTitle((ch.titre || (docs[0] && docs[0].nom) || 'Document technique') + (ch.indice ? ' — ind. ' + ch.indice : ''));
    out.setAuthor(M.auteur || 'Excellencia Building'); out.setSubject('Version habillée — ' + (docs.map(function (d) { return d.nom; }).join(' ; ')));
    out.setKeywords(['Excellencia Building', 'Atelier de mise en page', job.statut || 'Brouillon', M.version || '', (job.qr && job.qr.code ? 'verification:' + job.qr.code : ''), 'original-sha256:' + (docs.map(function (d) { return d.sha || ''; }).join(',') || '')].filter(Boolean));
    out.setProducer('Excellencia Atelier de mise en page (pdf-lib)'); out.setCreator('Excellencia Building'); out.setCreationDate(new Date()); out.setModificationDate(new Date());
    var bytes = await out.save({ useObjectStreams: true });
    return { bytes: bytes, notes: notes, map: map, plan: plan };
  }

  NS.exporter = { build: build, baseMatrix: baseMatrix, extendBottom: extendBottom, extendTop: extendTop, PT: PT };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.exporter;
})(typeof window !== 'undefined' ? window : globalThis);
