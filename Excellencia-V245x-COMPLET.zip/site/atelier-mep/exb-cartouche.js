/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-cartouche (champs, statuts et modèles du cartouche).
 * Module PUR (aucun accès à l'écran ni au stockage) : testable seul.
 * Règle du cahier des charges (§5) : tout champ manquant reste « À compléter » ; aucune signature, approbation ou donnée n'est inventée.
 * Les mentions « dessiné / vérifié / approuvé par » ne viennent QUE du circuit de validation enregistré (exb-doc-version.js). */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {};
  var A_COMPLETER = 'À compléter';

  var STATUTS = ['Brouillon', 'Pour vérification', 'À corriger', 'Approuvé', 'Émis'];
  var DISCIPLINES = ['Architecture', 'Structure / béton armé', 'Fondations / géotechnique', 'Charpente métallique', 'Électricité', 'Plomberie / sanitaire', 'CVC', 'VRD / assainissement', 'Topographie', 'Autre'];
  var TYPES = { plan: 'Plan', note: 'Note de calcul', rapport: 'Rapport technique', annexe: 'Annexe / autre' };

  /* Champs du cartouche (ordre = ordre de saisie) : [clé, libellé, obligatoire pour soumettre, origine] */
  var CHAMPS = [
    ['projet', 'Projet', true, 'projet'], ['reference', 'Référence du projet', false, 'projet'], ['client', 'Client / maître d’ouvrage', false, 'projet'],
    ['localisation', 'Localisation', false, 'projet'], ['discipline', 'Discipline', true, 'saisie'], ['titre', 'Titre du document', true, 'saisie'],
    ['numero', 'Numéro du document', true, 'saisie'], ['indice', 'Indice de révision', true, 'auto'], ['format', 'Format', false, 'analyse'],
    ['echelle', 'Échelle', false, 'saisie'], ['date', 'Date', true, 'auto'],
    ['objet', 'Objet de la note (couverture)', false, 'saisie'], ['norme', 'Règlement / norme', false, 'saisie']
  ];

  /* Modèles de présentation livrés (§6). Les modèles personnalisés en sont des copies modifiées (exb_mep_modeles). */
  var MODELES = [
    { id: 'plan', nom: 'Plans d’exécution', base: 'plan', integre: true, desc: 'Même cartouche que les plans d’exécution générés par le logiciel : bande pleine largeur (identité de l’entreprise, 6 références, titre, visa, QR de vérification, N° / date / indice / page).',
      position: 'br', marge: 10, largeur: 0, couverture: false, sommaire: false, enteteTexte: '', piedTexte: '', pagination: false, filigrane: false, validation: false, styleNatif: true, types: ['plan'] },
    { id: 'note', nom: 'Notes de calcul', base: 'note', integre: true, desc: 'Même présentation que les notes de calcul générées par le logiciel : couverture à double cadre, bandeau « Feuille x / n », pied avec QR, sommaire — sans altérer les résultats.',
      position: 'br', marge: 8, largeur: 0, couverture: true, sommaire: true, enteteTexte: '{projet}', piedTexte: '{titre} — {numero} ind. {indice}', pagination: true, filigrane: false, validation: false, styleNatif: true, types: ['note'] },
    { id: 'rapport', nom: 'Rapports', base: 'rapport', integre: true, desc: 'En-tête, pied de page, références, pagination et filigrane discret.',
      position: 'br', marge: 8, largeur: 0, couverture: false, sommaire: false, enteteTexte: '{projet}', piedTexte: '{titre} — {numero} ind. {indice}', pagination: true, filigrane: true, validation: false, types: ['rapport', 'annexe'] },
    { id: 'dossier', nom: 'Dossier complet', base: 'dossier', integre: true, desc: 'Couverture, sommaire, notes, plans, annexes et page de validation.',
      position: 'br', marge: 10, largeur: 0, couverture: true, sommaire: true, enteteTexte: '{projet}', piedTexte: '{titre} — {numero} ind. {indice}', pagination: true, filigrane: false, validation: true, types: ['note', 'plan', 'rapport', 'annexe'] }
  ];

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function s(v) { return v == null ? '' : String(v).trim(); }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function dateFr(t) { var d = t ? new Date(t) : new Date(); return isNaN(d) ? '' : pad2(d.getDate()) + '/' + pad2(d.getMonth() + 1) + '/' + d.getFullYear(); }

  /* Indice de révision : 0 → A, 1 → B … 25 → Z, 26 → AA */
  function indiceDe(n) { n = Math.max(0, Math.floor(+n || 0)); var o = ''; do { o = String.fromCharCode(65 + (n % 26)) + o; n = Math.floor(n / 26) - 1; } while (n >= 0); return o; }

  /* Valeur affichée : champ vide → « À compléter » (marqué manquant, jamais inventé). */
  function valeur(champs, k) { var v = s(champs && champs[k]); return v ? { v: v, manque: false } : { v: A_COMPLETER, manque: true }; }

  /* Champs manquants parmi les obligatoires (pour soumettre / émettre). */
  function manquants(champs) { return CHAMPS.filter(function (c) { return c[2] && !s(champs && champs[c[0]]); }).map(function (c) { return { cle: c[0], libelle: c[1] }; }); }

  /* Préremplissage depuis la fiche projet et l'analyse : ne remplace jamais une valeur déjà saisie. */
  function prefill(champs, projet, analyse, rev, existant) {
    var c = Object.assign({}, champs || {}), p = projet || {};
    function put(k, v) { if (!s(c[k]) && s(v)) c[k] = s(v); }
    put('projet', p.nom || p.name || p.title); put('reference', p.reference || p.ref || p.code || p.numero); put('client', p.client || p.client_name || p.maitre_ouvrage);
    put('localisation', p.localisation || p.location || p.adresse || p.address || p.lieu);
    if (analyse && analyse.pages && analyse.pages.length) put('format', formatResume(analyse));
    if (!s(c.indice)) c.indice = indiceDe(rev || 0);
    if (!s(c.date)) c.date = dateFr();
    return c;
  }
  function formatResume(an) {
    var f = {}; (an.pages || []).forEach(function (p) { f[p.format] = (f[p.format] || 0) + 1; });
    var ks = Object.keys(f); return ks.length === 1 ? ks[0] : ks.join(' / ');
  }

  /* Mentions nominatives issues du circuit de validation (jamais une signature électronique). */
  function visas(wf, statut) {
    wf = wf || {};
    function m(o) { return o && o.par ? { nom: o.par, date: dateFr(o.t) } : null; }
    return { dessine: wf.auteur ? { nom: wf.auteur, date: wf.soumis ? dateFr(wf.soumis.t) : '' } : null, verifie: m(wf.verif), approuve: m(wf.approuve), statut: STATUTS.indexOf(statut) >= 0 ? statut : 'Brouillon' };
  }

  /* Remplace {projet} {titre} {numero} {indice} {client} {date} {reference} dans les textes d'en-tête / pied. */
  function gabarit(txt, champs) { return String(txt || '').replace(/\{(\w+)\}/g, function (m, k) { return s(champs && champs[k]) || ''; }).replace(/\s+—\s+—/g, ' —').replace(/^[\s—]+|[\s—]+$/g, '').replace(/\s{2,}/g, ' '); }

  function modele(id, perso) { var all = MODELES.concat(perso || []), m = all.filter(function (x) { return x.id === id; })[0]; return m ? clone(m) : null; }

  NS.cartouche = { A_COMPLETER: A_COMPLETER, STATUTS: STATUTS, DISCIPLINES: DISCIPLINES, TYPES: TYPES, CHAMPS: CHAMPS, MODELES: MODELES, indiceDe: indiceDe, dateFr: dateFr, valeur: valeur, manquants: manquants, prefill: prefill, formatResume: formatResume, visas: visas, gabarit: gabarit, modele: modele };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.cartouche;
})(typeof window !== 'undefined' ? window : globalThis);
