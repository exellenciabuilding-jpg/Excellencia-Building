# V245t — Écran de connexion ajusté, pastilles masquées, Paramètres retrouvés

Fichiers modifiés : `exb-v236k-bienvenue-espaces.js`, `exb-v99r-shell.js`, `sw.js` (étiquette de cache). Aucune migration SQL.

1. **Pastilles flottantes** (plein écran, intelligence 🧠, aide ❓, thème 🌙, apparence 🎨, notifications 🔔, messagerie ✉, 2FA, état « Excellencia Building ⚠ ») : masquées tant que l'écran de connexion (ou la porte de connexion en ligne) est affiché ; elles reviennent après connexion.
2. **Photo de fond** : l'écran de connexion est calé sur la hauteur de la fenêtre (avant : 828 px de haut dans une fenêtre de 614 px, donc image et carte débordaient). Bandeau de bienvenue, logo et carte s'adaptent à la hauteur ; sur écran peu haut la carte se compacte. Mesuré à 1093×614 et 1366×768 : plus de débordement.
3. **Paramètres** : l'entrée « ⚙️ Paramètres » est de retour dans le menu de gauche (le menu par postes l'avait retirée). Elle ouvre la liste Identité / Administration / Paramètres ; la tuile « Paramètres › Réglages » contient 🔒 Verrouillage automatique et Identifiants de connexion (changer identifiant / mot de passe). Ces entrées sont aussi dans chaque poste.
