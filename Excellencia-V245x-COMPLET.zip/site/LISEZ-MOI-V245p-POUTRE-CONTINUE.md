# V245p — Module 1 « poutre continue » recréé

Aucune migration SQL.

Fichiers :
- `calcul-structure/exb-poutre-continue.js` (NOUVEAU) : module 1/4, analyse élastique par la méthode des rotations, EI variable par travée, enveloppes ELU / ELS. Nom global navigateur : `EXBPCONT` (le nom `EXBPC` appartient au contrôle de paie, `exb-v234-controle-paie-ecritures.js`).
- `calcul-structure/exb-poutre-appuis.js` (module 2) : lit désormais `root.EXBPCONT` dans le navigateur (au lieu de `root.EXBPC`). Aucun autre changement.
- `calcul-structure/test-poutre-continue.js` (NOUVEAU) : tests du module 1.

Tests (depuis la racine de l'archive) :
- `node site/calcul-structure/test-poutre-continue.js`  → 57 réussis, 0 échec
- `node site/calcul-structure/test-poutre-appuis.js`    → 74 réussis, 0 échec

Remarques :
- Le fichier d'origine, perdu, a été reconstruit : le calcul est celui de `calcul-structure/index.html` (rotations, appuis simples rigides), étendu aux charges uniformes par travée et aux EI différents.
- `resume.xt` est lu sur la grille de 20 points par travée (précision ≈ L/20).
- `resume.VmaxAppui` = tranchant ELU maximal sur les appuis intérieurs (appuis de rive inclus si une seule travée).
- Les modules 1 et 2 ne sont chargés par aucune page (pas d'écran à ce jour).
- Calcul d'aide à l'étude : à faire vérifier par un ingénieur.
