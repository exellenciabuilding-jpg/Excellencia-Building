# Comment exécuter les migrations V245l (Supabase)

Le dossier `SQL-V245l/` contient les 120 migrations **déjà numérotées dans l'ordre d'exécution** (01 à 120), plus `121-TEST-tests-securite-v242.sql`. Le fichier `00-ORDRE-EXECUTION.txt` en est la liste. Ces fichiers sont identiques à ceux de `supabase/`.

## Résultat d'essai réel (27/11/2026)
Les 120 migrations ont été exécutées dans cet ordre sur un PostgreSQL 16 local (imitation de Supabase, pas un vrai projet) : **0 migration en échec, 48/48 (test V245) et 46/46 (cahier §9)**. Une erreur de test a été corrigée (test 11 / 11b, le comptage du journal se faisait avant l'écriture). Le détail est dans `rapport-profils-V245l-base-locale.md`. Cela ne remplace pas l'essai sur votre projet de recette Supabase.

## Marche à suivre
1. **Projet de RECETTE d'abord**, jamais la production. Sauvegarde : Database → Backups.
2. Supabase → **SQL Editor** → New query. Ouvrir le fichier `01-…sql`, copier tout son contenu, **Run**, lire le résultat. Puis `02-…`, etc. **Un seul fichier à la fois, dans l'ordre des numéros.** Si un fichier donne une erreur, s'arrêter : ne pas passer au suivant.
3. **Fichiers à confirmer (3)** : `112`, `113`, `114`. Au début de chacun figure la ligne
   `select set_config('exb.confirmer', 'NON', false);`
   Première exécution avec `'NON'` : aperçu seulement, rien n'est restreint. Si l'aperçu vous convient, remplacer `'NON'` par `'OUI'` et exécuter de nouveau.
4. **`117` (v245d) : laisser `'NON'`.** Sa partie B est reprise par le fichier 119.
5. À la fin, exécuter `121-TEST-tests-securite-v242.sql` : toutes les lignes doivent afficher OK.

## Magasinier : fichier `119-migration-v245l-magasinier-stock-seul.sql`
Ce que cela change : le magasinier correspond à la colonne **Stock** de l'étude. Il **perd** l'accès à `engagements` (dépenses), `bons_paiement`, `v92_factures_fournisseurs` et `planning_chantier`. Il **garde** stock, mouvements, inventaires, transferts, dépôts, demandes d'achat, commandes, réceptions, fournisseurs et projets en lecture.
- **À exécuter après 117 (v245d) et 118 (v245e).** Le fichier s'arrête avec un message d'erreur si la fonction « achats » n'a pas déjà ces droits (sinon les achats perdraient leur accès). C'est voulu.
- Pas de confirmation à modifier : il s'exécute directement. Il fait seul la sauvegarde (`droits_fonction_sauv_v245l`, `droits_matrice_sauv_v245l`), affiche ce qui est retiré, puis un contrôle qui doit donner **0**.
- Réexécutable sans danger. Un magasinier déjà connecté voit le changement à sa prochaine ouverture.
- **Retour arrière** : les deux lignes `insert … select … from droits_*_sauv_v245l` en bas du fichier rétablissent exactement les 4 droits.
- Vérification dans l'application : avec un compte magasinier, planning et engagements ne s'affichent plus ; le stock fonctionne comme avant.
- À arbitrer : le menu **Achats** de l'application accepte encore la fonction magasinier (demandes, commandes, réceptions, fournisseurs, sans engagements).

## Autres fichiers qui comptent
- **115 / 116 (v245, v245c)** : fonctions Achats et Commercial, export, périmètre par projet (désactivé par défaut).
- **117 (v245d)** : écarts avec la matrice de l'étude (partie A : droits de la fonction Achats).
- **118 (v245e)** : seuils de validation. **120 (v245m)** : les 6 circuits interservices, ajoutés sans écraser les circuits existants. À comparer au §4 de l'étude avant usage.
- **Retour arrière de chaque fichier** : bloc « RETOUR ARRIÈRE » en bas du fichier, procédure complète dans `LISEZ-MOI-V245l-DEPLOIEMENT-ET-RAPPORT.md` §A5. Lancer un retour arrière dans l'ordre inverse de l'exécution.

## Après les migrations
Déployer le site V245l (le cache passe en `v245l`, les appareils se mettent à jour seuls). Pendant deux jours, surveiller `journal_entreprise` : une série de « refus » chez un profil signale un droit oublié.

## V245n (28 fichiers non concernés, 2 modifiés) — espace Achats
Point 3 du rapport V245l tranché : le **magasinier n'ouvre plus l'Espace Achats** (étude §3 : magasinier = colonne Stock). Il garde l'Espace Magasin, qui contient déjà Stock, Mouvements et « Terrain & achats ». Fichiers modifiés : `exb-v99r-shell.js`, `sw.js` (cache `v245n`), `tools/check.js`. Aucune migration SQL nouvelle : le fichier 119 suffit côté serveur.
Point 2 (six circuits) : le texte du §4 ne figure pas dans l'étude PDF reçue (seule la liste des livrables le mentionne). Les circuits restent à valider par vous avant d'exécuter le fichier 120.
