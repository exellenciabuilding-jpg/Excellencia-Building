-- Excellencia Building V243 — MATRICE ESSENTIELLE : 10 données ajoutées à la matrice de partage de l'étude V238 (§3) et alignement des demandes d'achat.
-- Prolonge migration-v242 (même table droits_matrice_v242, même sauvegarde droits_fonction_sauv_v242). Décisions conservées : Commercial = direction ; Achats = magasinier (aucune nouvelle fonction).
-- Codes : V, C, M → lire + écrire · L → lire seule · « — » → aucune ligne · le conditionnel « * » est accordé au niveau de la fonction (RLS par projet : étape ultérieure).
-- « polyvalent » et les lecteurs ne sont pas touchés (garanti par peut()). Journal d'audit, comptes et rôles : aucun droit de fonction à poser (serveur / rôle admin).
-- ORDRE : après migration-v242-passation-donnees.sql. FICHIER 1 sur 2 : partie ADDITIVE (ne retire aucun droit dans droits_fonction). Réexécutable. NON exécuté sur un vrai Supabase : essayer d'abord sur la copie / le projet de recette.
do $$ begin
  if to_regclass('public.droits_matrice_v242') is null or to_regclass('public.droits_fonction_sauv_v242') is null then raise exception 'Exécutez d''abord migration-v242-passation-donnees.sql'; end if;
end $$;

-- ---------- 1. Matrice cible : nouvelles lignes (les lignes de V242 sont conservées) ----------
delete from droits_matrice_v242 where collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat');
insert into droits_matrice_v242(fonction, collection, lire, ecrire) values
 ('architecte','crm_opportunites',true,false),
 ('direction','crm_opportunites',true,true),
 ('architecte','crm_relances',true,false),
 ('direction','crm_relances',true,true),
 ('architecte','crm_reclamations',true,false),
 ('direction','crm_reclamations',true,true),
 ('comptable','fournisseurs',true,false),
 ('direction','fournisseurs',true,true),
 ('magasinier','fournisseurs',true,true),
 ('chef_projet','v92_demandes_achat',true,true),
 ('comptable','v92_demandes_achat',true,false),
 ('conducteur','v92_demandes_achat',true,true),
 ('direction','v92_demandes_achat',true,true),
 ('magasinier','v92_demandes_achat',true,true),
 ('chef_projet','commandes',true,false),
 ('comptable','commandes',true,false),
 ('conducteur','commandes',true,false),
 ('direction','commandes',true,true),
 ('magasinier','commandes',true,true),
 ('chef_projet','receptions',true,true),
 ('comptable','receptions',true,false),
 ('conducteur','receptions',true,true),
 ('direction','receptions',true,false),
 ('magasinier','receptions',true,true),
 ('chef_projet','pointages',true,true),
 ('comptable','pointages',true,false),
 ('conducteur','pointages',true,true),
 ('direction','pointages',true,false),
 ('rh','pointages',true,true),
 ('chef_projet','presences_rh',true,true),
 ('comptable','presences_rh',true,false),
 ('conducteur','presences_rh',true,true),
 ('direction','presences_rh',true,false),
 ('rh','presences_rh',true,true),
 ('direction','conges',true,true),
 ('rh','conges',true,true),
 ('comptable','ecritures_od',true,true),
 ('direction','ecritures_od',true,true),
 ('comptable','rapprochement_bancaire',true,true),
 ('direction','rapprochement_bancaire',true,true),
 ('comptable','comptabilite',true,true),
 ('direction','comptabilite',true,true),
 ('comptable','clotures_compta',true,true),
 ('direction','clotures_compta',true,true);
-- Alignement des demandes d'achat sur l'étude §4 (Chantier exprime, Achats prépare, Direction valide) : Direction, Chantier et Achats écrivent ; Compta lit.
insert into droits_matrice_v242(fonction, collection, lire, ecrire) values
 ('direction','v92_demandes_achat',true,true),('comptable','v92_demandes_achat',true,false),('conducteur','v92_demandes_achat',true,true),('chef_projet','v92_demandes_achat',true,true),('magasinier','v92_demandes_achat',true,true)
on conflict (fonction, collection) do update set lire = excluded.lire, ecrire = excluded.ecrire;

-- ---------- 2. Accorde ce que la matrice prévoit (n'enlève rien) ----------
insert into droits_fonction(fonction, collection, lire, ecrire)
select fonction, collection, lire, ecrire from droits_matrice_v242 where collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat')
on conflict (fonction, collection) do update
  set lire = droits_fonction.lire or excluded.lire, ecrire = droits_fonction.ecrire or excluded.ecrire;

-- ---------- 3. Contrôles (à lire après exécution) ----------
-- 3a. Droits manquants (doit renvoyer 0 ligne)
select m.fonction, m.collection, 'manquant' as probleme
  from droits_matrice_v242 m left join droits_fonction d on d.fonction = m.fonction and d.collection = m.collection
 where m.collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat') and (d.fonction is null or (m.lire and not d.lire) or (m.ecrire and not d.ecrire));
-- 3b. Droits ACTUELS plus larges que la matrice (information : ce que le fichier 2 retirerait)
select d.fonction, d.collection, d.lire, d.ecrire,
       case when m.fonction is null then 'refusé par la matrice (—)' else 'lecture seule dans la matrice' end as ecart
  from droits_fonction d left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
 where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and d.collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat')
   and (m.fonction is null or (m.ecrire = false and d.ecrire = true))
 order by d.collection, d.fonction;
