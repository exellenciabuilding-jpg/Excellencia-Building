-- Excellencia Building V245l — MAGASINIER = colonne STOCK de l'étude V238 §3 (exécution de la partie B de V245d, sans condition).
-- Constat de conformité du 27/11/2026 : le magasinier lisait le planning de chantier et lisait/écrivait les engagements de dépense,
-- alors que l'étude ne lui donne aucun accès à ces données. La fonction « achats » existe (V245) et porte déjà ces droits (V245d partie A).
-- À exécuter APRÈS migration-v245d et v245e. Réexécutable. Essayer d'abord sur le projet de recette.
-- Retire au magasinier : engagements, bons_paiement, v92_factures_fournisseurs, planning_chantier (droits_fonction ET droits_matrice_v242).
-- Il garde tout le reste (stock, mouvements, inventaires, transferts, dépôts, demandes d'achat, commandes, réceptions, fournisseurs, projets en lecture…).
do $$ begin
  if to_regclass('public.droits_matrice_v242') is null or to_regclass('public.droits_fonction') is null then
    raise exception 'Exécutez d''abord migration-v242 / v243 / v245 (matrice et droits de fonction absents)';
  end if;
  if not exists (select 1 from droits_fonction where fonction = 'achats' and collection = 'engagements' and ecrire) then
    raise exception 'La fonction « achats » n''a pas encore les droits Dépenses : exécutez d''abord migration-v245d (partie A), sinon les achats perdraient l''accès.';
  end if;
  if not exists (select 1 from droits_fonction where fonction = 'achats' and collection = 'v92_factures_fournisseurs' and ecrire) then
    raise exception 'La fonction « achats » n''a pas les factures fournisseurs : exécutez d''abord migration-v245.';
  end if;
end $$;

-- Sauvegarde AVANT retrait (une seule fois : la première sauvegarde est conservée si on réexécute)
create table if not exists droits_fonction_sauv_v245l as select * from droits_fonction where fonction = 'magasinier';
alter table droits_fonction_sauv_v245l enable row level security;   -- aucune politique : lisible seulement dans le SQL Editor
create table if not exists droits_matrice_sauv_v245l as select * from droits_matrice_v242 where fonction = 'magasinier';
alter table droits_matrice_sauv_v245l enable row level security;

-- Aperçu : ce qui est retiré (visible dans le résultat)
select fonction, collection, lire, ecrire, 'RETIRÉ au magasinier' as action
  from droits_fonction
 where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier')
 order by collection;

delete from droits_fonction     where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier');
delete from droits_matrice_v242 where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier');

-- Contrôle immédiat : doit afficher 0 ligne restante
select count(*) as droits_magasinier_restants_a_retirer
  from droits_fonction
 where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier');

-- RETOUR ARRIÈRE (restaure exactement l'état d'avant) :
--   insert into droits_fonction select * from droits_fonction_sauv_v245l where collection in ('engagements','bons_paiement','v92_factures_fournisseurs','planning_chantier') on conflict (fonction, collection) do update set lire = excluded.lire, ecrire = excluded.ecrire;
--   insert into droits_matrice_v242 select * from droits_matrice_sauv_v245l where collection in ('engagements','bons_paiement','v92_factures_fournisseurs','planning_chantier') on conflict (fonction, collection) do update set lire = excluded.lire, ecrire = excluded.ecrire;
