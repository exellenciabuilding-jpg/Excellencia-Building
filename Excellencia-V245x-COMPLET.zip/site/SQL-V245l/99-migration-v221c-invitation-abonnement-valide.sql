-- ⚠ NE PLUS EXÉCUTER CE FICHIER SI v205v (codes personnels) EST INSTALLÉE : il écrase l'aiguillage et fait refuser les codes personnels.
-- Utilisez migration-v221e-reparer-codes-personnels.sql à la place (même correctif d'abonnement, sans ce défaut).
-- ===== Excellencia Building V221c : l'invité ne reçoit plus un abonnement PÉRIMÉ =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : migration-v99zzj-activation-invitation.sql déjà exécutée.
--
-- Problème : activer_par_invitation renvoyait toujours le dernier abonnement enregistré (licences_clients.dernier_jeton,
-- sinon organisations.jeton_equipe), même périmé. L'invité voyait alors l'écran bleu « Votre abonnement a expiré ».
-- Désormais : on lit la date d'échéance dans l'abonnement (sans le modifier) et on renvoie le premier qui n'est pas périmé,
-- en préférant l'abonnement d'équipe (jeton_equipe) à celui d'un client à code (lié à des appareils). Si tous sont périmés,
-- l'invité reçoit un message clair au lieu de l'écran bleu.

create or replace function jeton_perime(t text) returns boolean
language plpgsql stable as $$
declare b text; j json; e timestamptz; g int;
begin
  if t is null then return false; end if;
  b := translate(split_part(t, '.', 1), '-_', '+/');
  b := b || repeat('=', (4 - length(b) % 4) % 4);
  j := convert_from(decode(b, 'base64'), 'UTF8')::json;
  e := (j->>'exp')::timestamptz;
  g := coalesce((j->>'grace')::int, 7);
  if e is null then return false; end if;
  return e + make_interval(days => g) <= now();
exception when others then return false;   -- illisible : on laisse le logiciel décider (il vérifie la signature)
end $$;

create or replace function activer_par_invitation(p_code text) returns json
language plpgsql security definer set search_path=public as $$
declare c text; o organisations; tok text; stat text; a_lic boolean := false; fails int; choix text;
begin
  c := lower(trim(coalesce(p_code, '')));
  delete from activations_invitation_essais where essai_le < now() - interval '1 day';
  select count(*) into fails from activations_invitation_essais where essai_le > now() - interval '10 minutes';
  if fails >= 40 then
    return json_build_object('ok', false, 'msg', 'Trop d’essais. Réessayez dans quelques minutes.'); end if;
  if c !~ '^[a-z0-9]{4,32}$' then
    insert into activations_invitation_essais default values;
    return json_build_object('ok', false, 'msg', 'Code d’invitation invalide : 8 caractères (lettres et chiffres).'); end if;
  select * into o from organisations where code_invitation = c;
  if not found then
    insert into activations_invitation_essais default values;
    return json_build_object('ok', false, 'msg', 'Code d’invitation inconnu. Vérifiez-le auprès de la personne qui vous a invité(e).'); end if;
  if to_regclass('public.licences_clients') is not null then
    execute 'select statut, dernier_jeton from licences_clients where org_id=$1 order by cree_le desc limit 1'
      into stat, tok using o.id;
    a_lic := stat is not null;
    if a_lic and stat in ('suspendu', 'resilie') then
      return json_build_object('ok', false, 'msg', 'Abonnement suspendu : contactez l’administrateur du logiciel.'); end if;
  end if;
  -- 1) abonnement d'équipe s'il est encore valide ; 2) sinon celui du client à code s'il est encore valide
  choix := null;
  if o.jeton_equipe is not null and not jeton_perime(o.jeton_equipe) then choix := o.jeton_equipe;
  elsif tok is not null and not jeton_perime(tok) then choix := tok;
  end if;
  if choix is null then
    if tok is null and o.jeton_equipe is null then
      return json_build_object('ok', false, 'msg', 'Aucun abonnement n’est encore enregistré pour cette entreprise. Demandez à l’administrateur d’ouvrir le panneau « Équipe » sur son appareil, ou de vous envoyer un lien d’activation.');
    end if;
    return json_build_object('ok', false, 'msg', 'L’abonnement enregistré pour l’équipe est périmé (ce n’est pas votre faute). Prévenez l’administrateur : il doit ouvrir le panneau « Équipe » sur son appareil, connecté à « 🔑 Licences », pour le renouveler.');
  end if;
  return json_build_object('ok', true, 'nom', o.nom, 'jeton', choix);
end $$;

revoke execute on function activer_par_invitation(text) from public;
grant  execute on function activer_par_invitation(text) to anon, authenticated;
