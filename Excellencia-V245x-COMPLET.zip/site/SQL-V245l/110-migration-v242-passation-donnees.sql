-- Excellencia Building V242 — PASSATION DES DONNÉES entre services (matrice de partage de l'étude V238, §3).
-- Traduit la matrice « données × services » en droits serveur (table droits_fonction, appliquée par la fonction peut() de migration-v99zn) pour les fonctions :
--   direction = Direction · comptable = Compta · architecte = Archi · bureau_etudes = BE · conducteur + chef_projet = Chantier · rh = RH · magasinier = Achats + Stock · formateur = Formation.
--   « Commercial » n'a pas de fonction serveur : ses droits restent à la Direction (V237g). « Rapports de service » : aucune collection enregistrée, rien à régler.
-- Codes : V, C, M → lire + écrire · L → lire seule · « — » → aucune ligne (refus) · le conditionnel « * » est accordé au niveau de la fonction (filtrage par projet : RLS à poser, étape ultérieure).
-- Les rôles « lecteur » n'écrivent jamais, quel que soit le droit de fonction (peut() l'impose) ; « admin » a tout ; « polyvalent » n'est pas touché.
-- ORDRE : après migration-v66-roles.sql, migration-v99zn-synchro-modules.sql, migration-v223 et migration-v224. FICHIER 1 sur 2 : partie ADDITIVE (ne retire aucun droit).
-- Réexécutable sans danger. NON exécuté sur un vrai Supabase : essayer d'abord sur la copie / le projet de recette.
do $$ begin
  if to_regclass('public.droits_fonction') is null then raise exception 'La table droits_fonction est absente : exécutez d''abord migration-v66-roles.sql'; end if;
  if to_regprocedure('public.peut(uuid,text,boolean)') is null then raise exception 'La fonction peut() est absente : exécutez d''abord migration-v99zn-synchro-modules.sql'; end if;
end $$;

-- ---------- 0. Sauvegarde de la matrice actuelle (créée une seule fois : elle garde l'état d'AVANT V242) ----------
create table if not exists droits_fonction_sauv_v242 as select * from droits_fonction;
alter table droits_fonction_sauv_v242 enable row level security;   -- aucune politique : invisible depuis l'API, lisible seulement dans le SQL Editor

-- ---------- 1. Matrice cible (lue par les étapes 2 et 3, et par le fichier 2) ----------
create table if not exists droits_matrice_v242(fonction text not null, collection text not null, lire boolean not null, ecrire boolean not null, primary key(fonction, collection));
alter table droits_matrice_v242 enable row level security;
drop policy if exists dm_lire on droits_matrice_v242;
create policy dm_lire on droits_matrice_v242 for select to authenticated using (true);
delete from droits_matrice_v242;
insert into droits_matrice_v242(fonction, collection, lire, ecrire) values
 ('comptable','apprenants',true,false),
 ('direction','apprenants',true,false),
 ('formateur','apprenants',true,true),
 ('rh','apprenants',true,false),
 ('comptable','bons_paiement',true,true),
 ('direction','bons_paiement',true,true),
 ('magasinier','bons_paiement',true,false),
 ('comptable','caisse',true,true),
 ('direction','caisse',true,true),
 ('comptable','certificats',true,false),
 ('direction','certificats',true,false),
 ('formateur','certificats',true,true),
 ('rh','certificats',true,false),
 ('architecte','clients',true,false),
 ('bureau_etudes','clients',true,false),
 ('chef_projet','clients',true,false),
 ('comptable','clients',true,false),
 ('conducteur','clients',true,false),
 ('direction','clients',true,true),
 ('chef_projet','contrats_rh',true,false),
 ('comptable','contrats_rh',true,false),
 ('conducteur','contrats_rh',true,false),
 ('direction','contrats_rh',true,true),
 ('rh','contrats_rh',true,true),
 ('comptable','cotations',true,false),
 ('direction','cotations',true,false),
 ('formateur','cotations',true,true),
 ('rh','cotations',true,false),
 ('architecte','devis',true,false),
 ('bureau_etudes','devis',true,false),
 ('chef_projet','devis',true,false),
 ('comptable','devis',true,false),
 ('conducteur','devis',true,false),
 ('direction','devis',true,true),
 ('chef_projet','engagements',true,true),
 ('comptable','engagements',true,true),
 ('conducteur','engagements',true,true),
 ('direction','engagements',true,true),
 ('magasinier','engagements',true,true),
 ('comptable','evaluations',true,false),
 ('direction','evaluations',true,false),
 ('formateur','evaluations',true,true),
 ('rh','evaluations',true,false),
 ('chef_projet','factures',true,false),
 ('comptable','factures',true,true),
 ('conducteur','factures',true,false),
 ('direction','factures',true,false),
 ('comptable','formateurs',true,false),
 ('direction','formateurs',true,false),
 ('formateur','formateurs',true,true),
 ('rh','formateurs',true,false),
 ('comptable','formations',true,false),
 ('direction','formations',true,false),
 ('formateur','formations',true,true),
 ('rh','formations',true,false),
 ('chef_projet','mouvements',true,false),
 ('comptable','mouvements',true,false),
 ('conducteur','mouvements',true,false),
 ('direction','mouvements',true,false),
 ('magasinier','mouvements',true,true),
 ('architecte','notes_calcul',true,false),
 ('bureau_etudes','notes_calcul',true,true),
 ('chef_projet','notes_calcul',true,false),
 ('conducteur','notes_calcul',true,false),
 ('direction','notes_calcul',true,false),
 ('comptable','paie',true,true),
 ('direction','paie',true,true),
 ('rh','paie',true,true),
 ('comptable','paie_calculs',true,true),
 ('direction','paie_calculs',true,true),
 ('rh','paie_calculs',true,true),
 ('comptable','paie_reglements',true,true),
 ('direction','paie_reglements',true,true),
 ('rh','paie_reglements',true,true),
 ('comptable','paiements_apprenants',true,true),
 ('direction','paiements_apprenants',true,true),
 ('chef_projet','personnel',true,false),
 ('comptable','personnel',true,false),
 ('conducteur','personnel',true,false),
 ('direction','personnel',true,true),
 ('rh','personnel',true,true),
 ('architecte','planning_chantier',true,false),
 ('bureau_etudes','planning_chantier',true,false),
 ('chef_projet','planning_chantier',true,true),
 ('conducteur','planning_chantier',true,true),
 ('direction','planning_chantier',true,false),
 ('magasinier','planning_chantier',true,false),
 ('comptable','planning_formation',true,false),
 ('direction','planning_formation',true,false),
 ('formateur','planning_formation',true,true),
 ('rh','planning_formation',true,false),
 ('architecte','plans',true,false),
 ('bureau_etudes','plans',true,true),
 ('chef_projet','plans',true,false),
 ('conducteur','plans',true,false),
 ('direction','plans',true,false),
 ('architecte','plans_coupes_structure',true,false),
 ('bureau_etudes','plans_coupes_structure',true,true),
 ('chef_projet','plans_coupes_structure',true,false),
 ('conducteur','plans_coupes_structure',true,false),
 ('direction','plans_coupes_structure',true,false),
 ('architecte','plans_fichiers',true,true),
 ('bureau_etudes','plans_fichiers',true,false),
 ('chef_projet','plans_fichiers',true,false),
 ('conducteur','plans_fichiers',true,false),
 ('direction','plans_fichiers',true,false),
 ('architecte','plans_v94',true,true),
 ('bureau_etudes','plans_v94',true,false),
 ('chef_projet','plans_v94',true,false),
 ('conducteur','plans_v94',true,false),
 ('direction','plans_v94',true,false),
 ('comptable','presences',true,false),
 ('direction','presences',true,false),
 ('formateur','presences',true,true),
 ('rh','presences',true,false),
 ('architecte','projets',true,true),
 ('bureau_etudes','projets',true,true),
 ('chef_projet','projets',true,true),
 ('comptable','projets',true,false),
 ('conducteur','projets',true,true),
 ('direction','projets',true,true),
 ('magasinier','projets',true,false),
 ('comptable','recus',true,true),
 ('direction','recus',true,false),
 ('formateur','recus',true,true),
 ('architecte','revisions_plans_v94',true,true),
 ('bureau_etudes','revisions_plans_v94',true,false),
 ('chef_projet','revisions_plans_v94',true,false),
 ('conducteur','revisions_plans_v94',true,false),
 ('direction','revisions_plans_v94',true,false),
 ('chef_projet','stock',true,false),
 ('comptable','stock',true,false),
 ('conducteur','stock',true,false),
 ('direction','stock',true,false),
 ('magasinier','stock',true,true),
 ('chef_projet','stock_consultations',true,false),
 ('comptable','stock_consultations',true,false),
 ('conducteur','stock_consultations',true,false),
 ('direction','stock_consultations',true,false),
 ('magasinier','stock_consultations',true,true),
 ('chef_projet','stock_depots',true,false),
 ('comptable','stock_depots',true,false),
 ('conducteur','stock_depots',true,false),
 ('direction','stock_depots',true,false),
 ('magasinier','stock_depots',true,true),
 ('chef_projet','stock_inventaires',true,false),
 ('comptable','stock_inventaires',true,false),
 ('conducteur','stock_inventaires',true,false),
 ('direction','stock_inventaires',true,false),
 ('magasinier','stock_inventaires',true,true),
 ('chef_projet','stock_transferts',true,false),
 ('comptable','stock_transferts',true,false),
 ('conducteur','stock_transferts',true,false),
 ('direction','stock_transferts',true,false),
 ('magasinier','stock_transferts',true,true),
 ('chef_projet','v92_demandes_achat',true,true),
 ('comptable','v92_demandes_achat',true,true),
 ('conducteur','v92_demandes_achat',true,true),
 ('direction','v92_demandes_achat',true,true),
 ('magasinier','v92_demandes_achat',true,true),
 ('chef_projet','v92_factures_fournisseurs',true,false),
 ('comptable','v92_factures_fournisseurs',true,true),
 ('conducteur','v92_factures_fournisseurs',true,false),
 ('direction','v92_factures_fournisseurs',true,false),
 ('magasinier','v92_factures_fournisseurs',true,true),
 ('comptable','v93_paiements',true,true),
 ('direction','v93_paiements',true,true);

-- ---------- 2. Accorde ce que la matrice prévoit (n'enlève rien) ----------
insert into droits_fonction(fonction, collection, lire, ecrire)
select fonction, collection, lire, ecrire from droits_matrice_v242
on conflict (fonction, collection) do update
  set lire = droits_fonction.lire or excluded.lire, ecrire = droits_fonction.ecrire or excluded.ecrire;

-- ---------- 3. Contrôles (à lire après exécution) ----------
-- 3a. Droits de la matrice manquants (doit renvoyer 0 ligne)
select m.fonction, m.collection, 'manquant' as probleme
  from droits_matrice_v242 m left join droits_fonction d on d.fonction = m.fonction and d.collection = m.collection
 where d.fonction is null or (m.lire and not d.lire) or (m.ecrire and not d.ecrire);
-- 3b. Droits ACTUELS plus larges que la matrice (information : à retirer avec le fichier 2 si vous le décidez)
select d.fonction, d.collection, d.lire, d.ecrire,
       case when m.fonction is null then 'refusé par la matrice (—)' else 'lecture seule dans la matrice' end as ecart
  from droits_fonction d left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
 where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and d.collection in ('apprenants', 'bons_paiement', 'caisse', 'certificats', 'clients', 'contrats_rh', 'cotations', 'devis', 'engagements', 'evaluations', 'factures', 'formateurs', 'formations', 'mouvements', 'notes_calcul', 'paie', 'paie_calculs', 'paie_reglements', 'paiements_apprenants', 'personnel', 'planning_chantier', 'planning_formation', 'plans', 'plans_coupes_structure', 'plans_fichiers', 'plans_v94', 'presences', 'projets', 'recus', 'revisions_plans_v94', 'stock', 'stock_consultations', 'stock_depots', 'stock_inventaires', 'stock_transferts', 'v92_demandes_achat', 'v92_factures_fournisseurs', 'v93_paiements')
   and (m.fonction is null or (m.ecrire = false and d.ecrire = true))
 order by d.collection, d.fonction;
