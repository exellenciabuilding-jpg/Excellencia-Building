-- Excellencia Building V245 — SÉCURISATION SERVEUR (étapes 3 et 4 de l'étude V238) : fonctions « commercial » et « achats », droit d'export imposé par le serveur,
-- périmètre par projet (RLS fondée sur les affectations), séparation préparateur / encaisseur d'un bon de paiement.
-- ORDRE : après migration-v226, v235, v242, v243 et v244 (voir tools/test-rls/ordre-migrations.txt). Réexécutable. Essayer d'abord sur la copie de recette.
-- SÛRETÉ : le périmètre par projet est DÉSACTIVÉ par défaut (interrupteur par organisation) ; rien n'est caché tant que l'administrateur ne l'active pas.
--         Le droit d'export du MEMBRE vaut « autorisé » tant que l'administrateur ne l'a pas retiré (V226) : aucun changement pour les comptes existants.

do $$ begin
  if to_regclass('public.droits_fonction') is null or to_regclass('public.permissions_membre') is null or to_regclass('public.affectations_projets') is null then
    raise exception 'Exécutez d''abord migration-v66, v205-lot3-ingenierie et v226-permissions-membres.';
  end if;
end $$;

-- =====================================================================================================================
-- 1. FONCTIONS « commercial » ET « achats » (étude V238 §2 : espaces 07 et 08, qui n'avaient pas de fonction propre)
-- =====================================================================================================================
alter table membres drop constraint if exists membres_fonction_chk;
alter table membres add constraint membres_fonction_chk check (fonction in
  ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','formateur','comptable','rh','magasinier','commercial','achats'));
alter table invitations_equipe drop constraint if exists invitations_fonction_chk;
alter table invitations_equipe add constraint invitations_fonction_chk check (fonction in
  ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','formateur','comptable','rh','magasinier','commercial','achats'));

-- Les fonctions SQL qui contrôlent la liste des fonctions (invitation, changement de fonction, messagerie) la répètent en dur : on la complète
-- dans la base elle-même, sans recopier leur code (donc sans risque de régression). Réexécutable : une fonction déjà complétée est ignorée.
do $$
declare r record; def text; nouv text; n int := 0;
begin
  for r in select p.oid, p.proname from pg_proc p join pg_namespace s on s.oid = p.pronamespace
            where s.nspname = 'public' and p.prosrc like '%''rh'',''magasinier''%' and p.prosrc not like '%''commercial''%' loop
    def := pg_get_functiondef(r.oid);
    nouv := replace(def, '''rh'',''magasinier''', '''rh'',''magasinier'',''commercial'',''achats''');
    if nouv <> def then execute nouv; n := n + 1; end if;
  end loop;
  raise notice 'V245 : % fonction(s) SQL complétée(s) avec commercial / achats.', n;
end $$;

-- Droits de départ des deux nouvelles fonctions (étude §3). « * » (conditionnel) : accordé au niveau de la fonction ; le périmètre par projet (§3 ci-dessous) l'affine.
drop table if exists pg_temp._v245_droits;
create temp table _v245_droits(fonction text, collection text, lire boolean, ecrire boolean);
insert into _v245_droits values
 -- Commercial : clients, devis, CRM en création/modification ; projets, planning, factures en lecture (conditionnel)
 ('commercial','clients',true,true),('commercial','devis',true,true),('commercial','crm',true,true),('commercial','v92_crm',true,true),
 ('commercial','crm_contrats',true,true),('commercial','crm_satisfaction',true,true),('commercial','crm_opportunites',true,true),
 ('commercial','crm_relances',true,true),('commercial','crm_reclamations',true,true),('commercial','estimates',true,true),
 ('commercial','projets',true,false),('commercial','v93_projets',true,false),('commercial','factures',true,false),('commercial','contrats',true,false),
 ('commercial','documents',true,true),('commercial','courrier',true,true),('commercial','client_portal',true,true),('commercial','esign',true,true),
 -- Achats : demandes d'achat, fournisseurs, comparaison, bons de commande, réceptions, factures fournisseurs ; stock en modification ; projets en lecture
 ('achats','achats',true,true),('achats','fournisseurs',true,true),('achats','v92_fournisseurs',true,true),('achats','v92_demandes_achat',true,true),
 ('achats','commandes',true,true),('achats','v92_commandes',true,true),('achats','receptions',true,true),('achats','v92_receptions',true,true),
 ('achats','v92_factures_fournisseurs',true,true),('achats','benchmarks',true,true),('achats','price_library',true,true),('achats','contrats',true,false),
 ('achats','stock',true,true),('achats','stocks',true,true),('achats','v92_stock',true,true),('achats','mouvements',true,false),
 ('achats','projets',true,false),('achats','v93_projets',true,false),('achats','planning_chantier',true,false),
 ('achats','documents',true,true),('achats','courrier',true,true);
insert into droits_fonction(fonction, collection, lire, ecrire)
select fonction, collection, lire, ecrire from _v245_droits
on conflict (fonction, collection) do update set lire = droits_fonction.lire or excluded.lire, ecrire = droits_fonction.ecrire or excluded.ecrire;
-- CORRECTIF V242b : la restriction retirait « bons_paiement » au chantier, à l'ingénieur et à l'architecte, alors que la V235 repose dessus (le chantier PRÉPARE le bon,
-- le comptable l'ENCAISSE — étude §4 « Chantier exprime le besoin »). On rétablit la préparation ; la séparation préparateur/encaisseur est imposée par enregistrer() (§4 ci-dessous).
insert into _v245_droits values
 ('conducteur','bons_paiement',true,true),('chef_projet','bons_paiement',true,true),('bureau_etudes','bons_paiement',true,true),('architecte','bons_paiement',true,true);
insert into droits_fonction(fonction, collection, lire, ecrire)
select fonction, collection, lire, ecrire from _v245_droits where collection = 'bons_paiement'
on conflict (fonction, collection) do update set lire = droits_fonction.lire or excluded.lire, ecrire = droits_fonction.ecrire or excluded.ecrire;
-- Ces lignes entrent aussi dans la matrice cible (contrôles S9 à S11).
do $$ begin
  if to_regclass('public.droits_matrice_v242') is not null then
    insert into droits_matrice_v242(fonction, collection, lire, ecrire)
    select fonction, collection, lire, ecrire from _v245_droits
    on conflict (fonction, collection) do update set lire = excluded.lire, ecrire = excluded.ecrire;
  end if;
end $$;

-- =====================================================================================================================
-- 2. DROITS D'ACTION IMPOSÉS PAR LE SERVEUR : validation, export, administration (étude §5)
-- =====================================================================================================================
create table if not exists droits_actions_fonction(
  fonction text not null, action text not null check (action in ('validation','export')),
  autorise boolean not null default false, primary key (fonction, action));
alter table droits_actions_fonction enable row level security;
drop policy if exists daf_lire on droits_actions_fonction;
create policy daf_lire on droits_actions_fonction for select using (auth.uid() is not null);
revoke insert, update, delete, truncate on droits_actions_fonction from anon, authenticated;
revoke all on droits_actions_fonction from anon;
-- Mêmes valeurs de départ que la matrice « Droits d'action » de l'écran (exb-droits-actions.js), pour que l'écran et le serveur disent la même chose.
insert into droits_actions_fonction(fonction, action, autorise) values
 ('direction','validation',true),('chef_projet','validation',true),
 ('direction','export',true),('chef_projet','export',true),('bureau_etudes','export',true),('architecte','export',true),
 ('comptable','export',true),('rh','export',true),('commercial','export',true),('achats','export',true)
on conflict (fonction, action) do nothing;

-- Le serveur répond à : « cet utilisateur peut-il faire cette action ? » (administrateur : toujours ; lecteur : jamais de validation ni d'export de masse ; « polyvalent » : refus par défaut).
create or replace function peut_action(p_org uuid, p_action text, p_col text default null)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare m membres; ok boolean;
begin
  if auth.uid() is null then return false; end if;
  select * into m from membres where org_id = p_org and user_id = auth.uid();
  if not found then return false; end if;
  if m.role = 'admin' then return true; end if;
  if p_action = 'administration' then return false; end if;                 -- l'administration technique reste au rôle administrateur, distincte de la Direction
  if p_action = 'lecture' then return p_col is not null and peut(p_org, p_col, false);
  elsif p_action in ('creation','modification') then return p_col is not null and peut(p_org, p_col, true) and perm_ok(p_org, p_action);
  elsif p_action in ('validation','export') then
    if m.role = 'lecteur' then return false; end if;
    if not perm_ok(p_org, p_action) then return false; end if;                 -- permission retirée à CE membre (V226)
    select autorise into ok from droits_actions_fonction where fonction = m.fonction and action = p_action;
    if not coalesce(ok, false) then return false; end if;                      -- refus par défaut : la fonction doit être explicitement autorisée
    return p_col is null or peut(p_org, p_col, false);                          -- on n'exporte que ce que l'on a le droit de lire
  end if;
  return false;
end $$;
revoke all on function peut_action(uuid, text, text) from public, anon;
grant execute on function peut_action(uuid, text, text) to authenticated;

-- Modification de la matrice des actions : réservée à l'administrateur, journalisée.
create or replace function definir_action_fonction(p_org uuid, p_fonction text, p_action text, p_autorise boolean)
returns json language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if p_action not in ('validation','export') then raise exception 'action invalide'; end if;
  if p_fonction not in ('direction','chef_projet','conducteur','bureau_etudes','architecte','formateur','comptable','rh','magasinier','commercial','achats') then raise exception 'fonction invalide'; end if;
  insert into droits_actions_fonction(fonction, action, autorise) values (p_fonction, p_action, coalesce(p_autorise, false))
  on conflict (fonction, action) do update set autorise = excluded.autorise;
  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), 'droits_actions_fonction', p_fonction || '/' || p_action, case when coalesce(p_autorise,false) then 'autorisé' else 'retiré' end, 0);
  return json_build_object('ok', true);
end $$;
revoke all on function definir_action_fonction(uuid, text, text, boolean) from public, anon;
grant execute on function definir_action_fonction(uuid, text, text, boolean) to authenticated;

-- Contrôle + trace d'un export : l'écran l'appelle AVANT de produire le fichier (refus journalisé : « qui a exporté quoi »).
create or replace function exporter_controle(p_org uuid, p_col text, p_detail text default null)
returns json language plpgsql security definer set search_path = public as $$
begin
  if peut_action(p_org, 'export', nullif(p_col, '')) then
    insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
    values (p_org, auth.uid(), coalesce(nullif(p_col,''), '*'), left(coalesce(p_detail,''), 120), 'export', 0);
    return json_build_object('ok', true);
  end if;
  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), coalesce(nullif(p_col,''), '*'), left(coalesce(p_detail,''), 120), 'refus export', 0);
  return json_build_object('ok', false, 'refus', true);
end $$;
revoke all on function exporter_controle(uuid, text, text) from public, anon;
grant execute on function exporter_controle(uuid, text, text) to authenticated;

-- Téléchargement des documents générés : le serveur refuse si le droit d'export a été retiré au membre (avant : tout membre pouvait télécharger).
-- Enveloppe sans erreur pour « anon » (la politique est évaluée aussi pour les requêtes anonymes : elles doivent recevoir 0 ligne, pas une erreur).
create or replace function export_membre_ok(p_org uuid) returns boolean
language sql stable security definer set search_path = public as $$ select auth.uid() is not null and perm_ok(p_org, 'export') $$;
grant execute on function export_membre_ok(uuid) to anon, authenticated;
drop policy if exists dg_lire on storage.objects;
create policy dg_lire on storage.objects for select
  using (bucket_id = 'documents-generes' and est_membre(((storage.foldername(name))[1])::uuid) and export_membre_ok(((storage.foldername(name))[1])::uuid));

-- =====================================================================================================================
-- 3. PÉRIMÈTRE PAR PROJET (étude §6, couche 3) — fondé sur « affectations_projets » (V205 lot 3)
-- =====================================================================================================================
-- Règle (quand l'organisation l'a activé) : un conducteur, chef de projet, ingénieur ou architecte ne lit et n'écrit que les fiches des projets qui lui sont affectés.
-- L'administrateur et toutes les autres fonctions (direction, comptabilité, RH, achats…) ne sont pas concernés : leur périmètre reste celui de la matrice des droits.
-- Une fiche sans projet identifiable reste visible (le diagnostic la signale) : on ne cache jamais une fiche par erreur de classement.
create table if not exists parametres_securite(
  org_id uuid primary key references organisations(id) on delete cascade,
  perimetre_projet boolean not null default false, maj timestamptz not null default now(), par uuid);
alter table parametres_securite enable row level security;
drop policy if exists ps_lire on parametres_securite;
create policy ps_lire on parametres_securite for select using (est_membre(org_id));
revoke insert, update, delete, truncate on parametres_securite from anon, authenticated;
revoke all on parametres_securite from anon;

create table if not exists perimetre_collections(
  collection text primary key,
  mode text not null default 'champ' check (mode in ('champ','id')),        -- 'id' : la fiche EST le projet (collection « projets »)
  champs text[] not null default array['projet','projetId','projet_id','chantier','chantierId','chantier_id','project']);
alter table perimetre_collections enable row level security;
drop policy if exists pc_lire on perimetre_collections;
create policy pc_lire on perimetre_collections for select using (auth.uid() is not null);
revoke insert, update, delete, truncate on perimetre_collections from anon, authenticated;
revoke all on perimetre_collections from anon;
insert into perimetre_collections(collection, mode) values
 ('projets','id'),('v93_projets','id'),
 ('planning_chantier','champ'),('budgets_chantier','champ'),('plans','champ'),('plans_fichiers','champ'),('plans_v94','champ'),('revisions_plans_v94','champ'),
 ('notes_calcul','champ'),('etudes','champ'),('pointages','champ'),('situations','champ'),('bons_paiement','champ'),('v93_chantiers','champ'),('v93_taches','champ'),
 ('qhse','champ'),('reunions','champ'),('rfis','champ'),('submittals','champ'),('reserves','champ'),('documents_cde_v94','champ')
on conflict (collection) do nothing;

create or replace function fonction_a_perimetre(p_fonction text) returns boolean language sql immutable as $$
  select p_fonction in ('conducteur','chef_projet','bureau_etudes','architecte') $$;

-- Clés de projet d'une fiche (identifiant ET nom, car l'affectation peut porter l'un ou l'autre) — en minuscules.
create or replace function cles_projet_fiche(p_col text, p_id text, p_data jsonb)
returns text[] language plpgsql stable set search_path = public as $$
declare pc perimetre_collections; k text; v text; res text[] := '{}';
begin
  select * into pc from perimetre_collections where collection = p_col;
  if not found then return res; end if;
  if pc.mode = 'id' then
    res := array[lower(btrim(coalesce(p_id,''))), lower(btrim(coalesce(p_data->>'nom', p_data->>'name', p_data->>'titre', '')))];
  else
    foreach k in array pc.champs loop
      v := lower(btrim(coalesce(p_data->>k, '')));
      if v <> '' then res := res || v; end if;
    end loop;
  end if;
  return array(select distinct x from unnest(res) x where x <> '');
end $$;

create or replace function perimetre_ok(p_org uuid, p_col text, p_id text, p_data jsonb)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare m membres; cles text[];
begin
  if not exists(select 1 from perimetre_collections where collection = p_col) then return true; end if;
  if not exists(select 1 from parametres_securite where org_id = p_org and perimetre_projet) then return true; end if;
  select * into m from membres where org_id = p_org and user_id = auth.uid();
  if not found then return false; end if;
  if m.role = 'admin' or not fonction_a_perimetre(m.fonction) then return true; end if;
  cles := cles_projet_fiche(p_col, p_id, p_data);
  if coalesce(array_length(cles, 1), 0) = 0 then return true; end if;           -- fiche sans projet : non concernée
  return exists(select 1 from affectations_projets a where a.org_id = p_org and a.user_id = auth.uid() and a.actif and lower(btrim(a.projet)) = any(cles));
end $$;
-- Appelée par la politique de lecture : « anon » doit pouvoir l'évaluer (elle répond alors « non-membre → faux », sans erreur), comme peut().
grant execute on function perimetre_ok(uuid, text, text, jsonb) to anon, authenticated;
grant execute on function cles_projet_fiche(text, text, jsonb) to anon, authenticated;
grant execute on function fonction_a_perimetre(text) to anon, authenticated;

-- La lecture des fiches passe désormais par peut() ET par le périmètre.
drop policy if exists enr_lire on enregistrements;
create policy enr_lire on enregistrements for select using (peut(org_id, collection, false) and perimetre_ok(org_id, collection, id, data));

-- Interrupteur du périmètre (administrateur) et diagnostic (combien de fiches seraient cachées / non classées).
create or replace function perimetre_projet_definir(p_org uuid, p_actif boolean)
returns json language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  insert into parametres_securite(org_id, perimetre_projet, maj, par) values (p_org, coalesce(p_actif,false), now(), auth.uid())
  on conflict (org_id) do update set perimetre_projet = excluded.perimetre_projet, maj = now(), par = auth.uid();
  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), 'parametres_securite', 'perimetre_projet', case when coalesce(p_actif,false) then 'périmètre activé' else 'périmètre désactivé' end, 0);
  return json_build_object('ok', true, 'actif', coalesce(p_actif,false));
end $$;
revoke all on function perimetre_projet_definir(uuid, boolean) from public, anon;
grant execute on function perimetre_projet_definir(uuid, boolean) to authenticated;

create or replace function perimetre_diagnostic(p_org uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare v_actif boolean; l json;
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  select coalesce((select perimetre_projet from parametres_securite where org_id = p_org), false) into v_actif;
  select coalesce(json_agg(x order by (x->>'collection')), '[]'::json) into l from (
    select json_build_object('collection', c.collection,
             'fiches', count(e.id),
             'classees', count(e.id) filter (where coalesce(array_length(cles_projet_fiche(c.collection, e.id, e.data),1),0) > 0),
             'non_classees', count(e.id) filter (where coalesce(array_length(cles_projet_fiche(c.collection, e.id, e.data),1),0) = 0)) as x
      from perimetre_collections c left join enregistrements e on e.org_id = p_org and e.collection = c.collection and not e.supprime
     group by c.collection) q;
  return json_build_object('ok', true, 'actif', v_actif,
    'affectations_actives', (select count(*) from affectations_projets where org_id = p_org and actif),
    'membres_concernes', (select count(*) from membres where org_id = p_org and role <> 'admin' and fonction_a_perimetre(fonction)),
    'membres_sans_affectation', (select count(*) from membres m where m.org_id = p_org and m.role <> 'admin' and fonction_a_perimetre(m.fonction)
                                  and not exists(select 1 from affectations_projets a where a.org_id = p_org and a.user_id = m.user_id and a.actif)),
    'collections', l);
end $$;
revoke all on function perimetre_diagnostic(uuid) from public, anon;
grant execute on function perimetre_diagnostic(uuid) to authenticated;

-- =====================================================================================================================
-- 4. enregistrer() : périmètre à l'écriture + séparation préparateur / encaisseur d'un bon de paiement (étude §5)
--    Reprend à l'identique la version V226 (droit, licence, Création/Modification, conflit de version, journal) et AJOUTE deux contrôles.
-- =====================================================================================================================
create or replace function enregistrer(p_org uuid, p_col text, p_id text, p_data jsonb, p_base int, p_supprime boolean default false)
returns json language plpgsql security definer set search_path=public as $$
declare cur enregistrements; nv int; ex boolean; createur uuid; nb int;
begin
  if not peut(p_org,p_col,true) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus',0);
    return json_build_object('ok',false,'refus',true);
  end if;
  if not licence_ecriture_ok(p_org) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus licence',0);
    return json_build_object('ok',false,'refus',true,'licence',true);
  end if;
  select * into cur from enregistrements where org_id=p_org and collection=p_col and id=p_id for update;
  ex := found;
  if not perm_ok(p_org, case when ex then 'modification' else 'creation' end) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus permission',0);
    return json_build_object('ok',false,'refus',true,'permission',true);
  end if;
  -- V245 : périmètre par projet — on ne modifie pas une fiche d'un projet non affecté, et on ne range pas une fiche dans un projet non affecté
  if (ex and not perimetre_ok(p_org, p_col, p_id, cur.data)) or not perimetre_ok(p_org, p_col, p_id, p_data) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus périmètre',0);
    return json_build_object('ok',false,'refus',true,'perimetre',true);
  end if;
  -- V245 : le préparateur d'un bon de paiement n'est pas son encaisseur (sauf organisation d'un seul membre)
  if p_col = 'bons_paiement' and ex and (p_data->>'statut') in ('payé','partiel') and coalesce(cur.data->>'statut','') not in ('payé','partiel') then
    select user_id into createur from journal_entreprise where org_id = p_org and collection = p_col and rec_id = p_id and action = 'création' order by quand limit 1;
    select count(*) into nb from membres where org_id = p_org;
    if createur is not null and createur = auth.uid() and nb > 1 then
      insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus séparation des tâches',0);
      return json_build_object('ok',false,'refus',true,'separation',true);
    end if;
  end if;
  if ex then
    if cur.version<>p_base then
      return json_build_object('ok',false,'conflit',true,'version',cur.version,'data',cur.data,'supprime',cur.supprime);
    end if;
    nv:=cur.version+1;
    update enregistrements set data=p_data,version=nv,supprime=p_supprime,maj=now(),maj_par=auth.uid()
      where org_id=p_org and collection=p_col and id=p_id;
  else
    if p_base<>0 then
      return json_build_object('ok',false,'conflit',true,'version',0,'data',null,'supprime',true);
    end if;
    nv:=1;
    insert into enregistrements(org_id,collection,id,data,version,supprime,maj_par) values (p_org,p_col,p_id,p_data,1,p_supprime,auth.uid());
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org,auth.uid(),p_col,p_id,case when p_supprime then 'suppression' when nv=1 then 'création' else 'modification' end,nv);
  return json_build_object('ok',true,'version',nv);
end $$;
grant execute on function enregistrer(uuid,text,text,jsonb,int,boolean) to authenticated;

-- =====================================================================================================================
-- 5. Contrôles à lire après exécution
-- =====================================================================================================================
select 'V245-a' as controle, 'fonctions commercial et achats acceptées par membres' as description,
       case when pg_get_constraintdef((select oid from pg_constraint where conname = 'membres_fonction_chk')) like '%commercial%' and pg_get_constraintdef((select oid from pg_constraint where conname = 'membres_fonction_chk')) like '%achats%' then 'OK' else 'ÉCHEC' end as resultat
union all select 'V245-b', 'peut_action() présent', case when to_regprocedure('peut_action(uuid,text,text)') is not null then 'OK' else 'ÉCHEC' end
union all select 'V245-c', 'lecture des fiches : peut() + périmètre', case when exists(select 1 from pg_policies where tablename='enregistrements' and policyname='enr_lire' and qual ilike '%peut(%' and qual ilike '%perimetre_ok(%') then 'OK' else 'ÉCHEC' end
union all select 'V245-d', 'téléchargement des documents générés soumis au droit d''export', case when exists(select 1 from pg_policies where tablename='objects' and policyname='dg_lire' and qual ilike '%export_membre_ok(%') then 'OK' else 'ÉCHEC' end
union all select 'V245-e', 'périmètre par projet désactivé par défaut', case when not exists(select 1 from parametres_securite where perimetre_projet) then 'OK (désactivé)' else 'activé pour au moins une organisation' end;

-- RETOUR ARRIÈRE (si besoin) :
--   drop policy enr_lire on enregistrements; create policy enr_lire on enregistrements for select using (peut(org_id, collection, false));
--   drop policy dg_lire on storage.objects; create policy dg_lire on storage.objects for select using (bucket_id='documents-generes' and est_membre(((storage.foldername(name))[1])::uuid));
--   puis ré-exécuter migration-v226-permissions-membres.sql pour restaurer l'ancienne enregistrer().
