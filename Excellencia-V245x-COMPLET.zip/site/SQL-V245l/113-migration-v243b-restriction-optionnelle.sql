-- Excellencia Building V243 — MATRICE ESSENTIELLE. FICHIER 2 sur 2 : partie RESTRICTIVE (optionnelle).
-- Retire les droits que la matrice refuse (« — ») et repasse en lecture seule ceux qu'elle limite à « L », pour les 9 fonctions et les 10 collections de V243 + les demandes d'achat uniquement.
-- Rien n'est modifié tant que la ligne « confirmer » n'est pas passée de 'NON' à 'OUI'. À exécuter APRÈS le fichier 1, après lecture du contrôle 3b et essai sur la copie de recette.
do $$ begin
  if to_regclass('public.droits_matrice_v242') is null or to_regclass('public.droits_fonction_sauv_v242') is null then raise exception 'Exécutez d''abord migration-v242 puis migration-v243 (fichier 1)'; end if;
end $$;
-- Garde-fou : la matrice V243 doit être chargée (fichier 1 exécuté sans erreur). Sans elle, TOUS les droits de ces collections apparaîtraient « à retirer », y compris ceux de la Direction.
do $$ begin
  if (select count(*) from droits_matrice_v242 where collection in ('fournisseurs','commandes','receptions','pointages','presences_rh','conges','ecritures_od','crm_opportunites') and ecrire) < 8 then
    raise exception 'Matrice V243 absente : exécutez d''abord migration-v243-matrice-essentielle.sql (fichier 1) et vérifiez que le contrôle 3a ne renvoie aucune ligne. Rien n''a été modifié.';
  end if;
end $$;
-- Sauvegarde complémentaire (une seule fois) : état des droits avant les restrictions V243
create table if not exists droits_fonction_sauv_v243 as select * from droits_fonction;
alter table droits_fonction_sauv_v243 enable row level security;   -- aucune politique : lisible seulement dans le SQL Editor

select set_config('exb.confirmer', 'NON', false);   -- ← remplacez 'NON' par 'OUI' pour appliquer

-- Aperçu : ce qui sera retiré / repassé en lecture seule
select d.fonction, d.collection, case when m.fonction is null then 'RETIRÉ' else 'ÉCRITURE RETIRÉE' end as action
  from droits_fonction d left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
 where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and d.collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat')
   and (m.fonction is null or (m.ecrire = false and d.ecrire = true))
 order by d.collection, d.fonction;

do $$ begin
  if coalesce(current_setting('exb.confirmer', true), 'NON') = 'OUI' then
    delete from droits_fonction d
     where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and d.collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat')
       and not exists (select 1 from droits_matrice_v242 m where m.fonction = d.fonction and m.collection = d.collection);
    update droits_fonction d set ecrire = false
      from droits_matrice_v242 m
     where m.fonction = d.fonction and m.collection = d.collection and m.ecrire = false and d.ecrire = true and d.collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat');
    raise notice 'V243 : restrictions appliquées.';
  else
    raise notice 'V243 : aperçu seulement (exb.confirmer <> OUI) : rien n''a été modifié.';
  end if;
end $$;

-- Retour arrière complet (état d'avant les restrictions V243) :
--   delete from droits_fonction where fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat');
--   insert into droits_fonction select * from droits_fonction_sauv_v243 where fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and collection in ('clotures_compta', 'commandes', 'comptabilite', 'conges', 'crm_opportunites', 'crm_reclamations', 'crm_relances', 'ecritures_od', 'fournisseurs', 'pointages', 'presences_rh', 'rapprochement_bancaire', 'receptions', 'v92_demandes_achat');
