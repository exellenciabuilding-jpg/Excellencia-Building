-- ===== Excellencia Building — V245c : périmètre par projet, noms réels des champs « projet » =====
-- À exécuter APRÈS migration-v245 (Supabase › SQL Editor), d'abord sur la copie de recette. Additif, réexécutable.
-- Si migration-v245 est relancée plus tard, relancer ce fichier ensuite.
-- Constat (lecture du code) : la plupart des modules enregistrent le projet sous « project_id » (planning, budgets, pointages, situations,
-- études, notes de calcul, plans V94, RFI, réserves, QHSE, BTP V93). Ce nom manquait : ces fiches restaient visibles de tous.
-- Ce fichier : 1) ajoute les noms manquants ; 2) rattache une fiche sans champ projet à sa fiche parente (révision → plan, tâche → chantier) ;
-- 3) fait correspondre une affectation faite par le NOM à une fiche classée par l'IDENTIFIANT (et inversement).
do $$ begin
  if to_regclass('public.perimetre_collections') is null then raise exception 'Exécutez d''abord migration-v245-fonctions-export-perimetre.sql'; end if;
end $$;

alter table perimetre_collections add column if not exists parent_champ text;
alter table perimetre_collections add column if not exists parent_collection text;
alter table perimetre_collections alter column champs
  set default array['projet','projetId','projet_id','chantier','chantierId','chantier_id','project','project_id','projectId','core_project_id'];

-- noms ajoutés à la suite : les réglages personnalisés sont conservés
update perimetre_collections p
   set champs = p.champs || array(select x from unnest(array['project_id','projectId','core_project_id']) x where not (x = any(p.champs)))
 where not (p.champs @> array['project_id','projectId','core_project_id']);

update perimetre_collections set parent_champ = 'drawing_id', parent_collection = 'plans_v94'     where collection = 'revisions_plans_v94' and parent_champ is null;
update perimetre_collections set parent_champ = 'site_id',    parent_collection = 'v93_chantiers' where collection = 'v93_taches' and parent_champ is null;

-- Clés de projet d'une fiche, en remontant à la fiche parente si elle n'en porte aucune. Réservée aux fonctions serveur.
create or replace function cles_projet_rattachees(p_org uuid, p_col text, p_id text, p_data jsonb)
returns text[] language plpgsql stable security definer set search_path = public as $$
declare pc perimetre_collections; res text[]; e enregistrements;
begin
  res := cles_projet_fiche(p_col, p_id, p_data);
  if coalesce(array_length(res, 1), 0) > 0 then return res; end if;
  select * into pc from perimetre_collections where collection = p_col;
  if not found or pc.parent_champ is null or coalesce(p_data->>pc.parent_champ, '') = '' then return coalesce(res, '{}'); end if;
  select * into e from enregistrements where org_id = p_org and collection = pc.parent_collection and id = p_data->>pc.parent_champ;
  if not found then return '{}'; end if;
  return cles_projet_fiche(pc.parent_collection, e.id, e.data);
end $$;
revoke all on function cles_projet_rattachees(uuid, text, text, jsonb) from public, anon, authenticated;

-- Les projets désignés par des clés (identifiant ou nom) : tous leurs identifiants et noms, y compris le lien BTP V93 ↔ projet du logiciel.
create or replace function cles_projet_etendues(p_org uuid, p_cles text[])
returns text[] language sql stable security definer set search_path = public as $$
  with fiches as (
    select array(select lower(btrim(v)) from unnest(array[e.id, e.data->>'nom', e.data->>'name', e.data->>'titre', e.data->>'title', e.data->>'core_project_id']) v
                  where coalesce(btrim(v), '') <> '') as k
      from enregistrements e where e.org_id = p_org and e.collection in ('projets','v93_projets') and not e.supprime),
  n1 as (select p_cles || coalesce((select array_agg(u) from fiches f, unnest(f.k) u where f.k && p_cles), '{}') as k)
  select array(select distinct u from unnest(n1.k || coalesce((select array_agg(u) from fiches f, unnest(f.k) u where f.k && n1.k), '{}')) u) from n1 $$;
revoke all on function cles_projet_etendues(uuid, text[]) from public, anon, authenticated;

create or replace function perimetre_ok(p_org uuid, p_col text, p_id text, p_data jsonb)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare m membres; cles text[]; aff text[];
begin
  if not exists(select 1 from perimetre_collections where collection = p_col) then return true; end if;
  if not exists(select 1 from parametres_securite where org_id = p_org and perimetre_projet) then return true; end if;
  select * into m from membres where org_id = p_org and user_id = auth.uid();
  if not found then return false; end if;
  if m.role = 'admin' or not fonction_a_perimetre(m.fonction) then return true; end if;
  cles := cles_projet_rattachees(p_org, p_col, p_id, p_data);
  if coalesce(array_length(cles, 1), 0) = 0 then return true; end if;           -- fiche sans projet : non concernée
  select array_agg(lower(btrim(a.projet))) into aff from affectations_projets a where a.org_id = p_org and a.user_id = auth.uid() and a.actif;
  if aff is null then return false; end if;
  if cles && aff then return true; end if;
  return cles && cles_projet_etendues(p_org, aff);
end $$;
grant execute on function perimetre_ok(uuid, text, text, jsonb) to anon, authenticated;

create or replace function perimetre_diagnostic(p_org uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare v_actif boolean; l json;
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  select coalesce((select perimetre_projet from parametres_securite where org_id = p_org), false) into v_actif;
  select coalesce(json_agg(x order by (x->>'collection')), '[]'::json) into l from (
    select json_build_object('collection', c.collection,
             'fiches', count(e.id),
             'classees', count(e.id) filter (where coalesce(array_length(cles_projet_rattachees(p_org, c.collection, e.id, e.data),1),0) > 0),
             'non_classees', count(e.id) filter (where coalesce(array_length(cles_projet_rattachees(p_org, c.collection, e.id, e.data),1),0) = 0)) as x
      from perimetre_collections c left join enregistrements e on e.org_id = p_org and e.collection = c.collection and not e.supprime
     group by c.collection) q;
  return json_build_object('ok', true, 'actif', v_actif,
    'affectations_actives', (select count(*) from affectations_projets where org_id = p_org and actif),
    'membres_concernes', (select count(*) from membres where org_id = p_org and role <> 'admin' and fonction_a_perimetre(fonction)),
    'membres_sans_affectation', (select count(*) from membres m where m.org_id = p_org and m.role <> 'admin' and fonction_a_perimetre(m.fonction)
                                  and not exists(select 1 from affectations_projets a where a.org_id = p_org and a.user_id = m.user_id and a.actif)),
    'collections', l);
end $$;
revoke all on function perimetre_diagnostic(uuid) from public, anon;
grant execute on function perimetre_diagnostic(uuid) to authenticated;

-- Vérification : select collection, champs, parent_champ, parent_collection from perimetre_collections order by 1;
