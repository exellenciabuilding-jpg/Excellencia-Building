-- Excellencia Building V245m — LES SIX CIRCUITS INTERSERVICES de l'étude V238 §4, préconfigurés sur le serveur Workflow.
-- Circuits : projet · paiement fournisseur · approvisionnement · personnel · facturation · formation.
-- À exécuter APRÈS migration-v149-workflow-serveur.sql (tables wf_*). Réexécutable : n'écrase JAMAIS un circuit déjà présent (les modifications de l'administrateur sont respectées).
-- Identiques à INTERSERVICES dans exb-workflow.js (même identifiants wfc_s4_*) — contrôle automatique : node tools/test-circuits-s4.js
-- Les approbateurs sont des FONCTIONS (« Comptable », « Directeur général »…) : wf_acteur() les reconnaît quelle que soit la personne. Séparation des tâches : l'initiateur ne décide jamais de son propre dossier.
do $$ begin
  if to_regclass('public.wf_circuits') is null or to_regclass('public.organisations') is null then
    raise exception 'Exécutez d''abord migration-v149-workflow-serveur.sql (tables du Workflow absentes)';
  end if;
end $$;

drop table if exists pg_temp._s4;
create temp table _s4(id text primary key, data jsonb not null);
insert into _s4(id, data) values
  ('wfc_s4_projet', '{"id": "wfc_s4_projet", "nom": "Projet — lancement", "type": "projet", "steps": [{"nom": "Faisabilité technique", "mode": "sequentiel", "approvers": [{"role": "Ingénieur"}], "delaiJours": 3, "id": "s0"}, {"nom": "Budget et trésorerie", "mode": "sequentiel", "approvers": [{"role": "Comptable"}], "delaiJours": 2, "id": "s1"}, {"nom": "Décision de lancement", "mode": "sequentiel", "approvers": [{"role": "Directeur général"}], "delaiJours": 3, "id": "s2"}], "actif": true, "distincts": true}'::jsonb),
  ('wfc_s4_paiement_fournisseur', '{"id": "wfc_s4_paiement_fournisseur", "nom": "Paiement fournisseur", "type": "paiement_fournisseur", "steps": [{"nom": "Service fait (réception conforme)", "mode": "sequentiel", "approvers": [{"role": "Magasinier"}], "delaiJours": 2, "id": "s0"}, {"nom": "Contrôle de la facture", "mode": "sequentiel", "approvers": [{"role": "Comptable"}], "delaiJours": 2, "id": "s1"}, {"nom": "Autorisation de paiement", "mode": "sequentiel", "approvers": [{"role": "Directeur général"}], "delaiJours": 3, "seuil": {"montant": 1000, "devise": "USD"}, "id": "s2"}], "actif": true, "distincts": true}'::jsonb),
  ('wfc_s4_approvisionnement', '{"id": "wfc_s4_approvisionnement", "nom": "Approvisionnement", "type": "approvisionnement", "steps": [{"nom": "Validation du besoin", "mode": "sequentiel", "approvers": [{"role": "Chef de projet"}], "delaiJours": 2, "id": "s0"}, {"nom": "Engagement budgétaire", "mode": "sequentiel", "approvers": [{"role": "Comptable"}], "delaiJours": 2, "id": "s1"}, {"nom": "Autorisation de la direction", "mode": "sequentiel", "approvers": [{"role": "Directeur général"}], "delaiJours": 3, "seuil": {"montant": 1000, "devise": "USD"}, "id": "s2"}], "actif": true, "distincts": true}'::jsonb),
  ('wfc_s4_personnel', '{"id": "wfc_s4_personnel", "nom": "Personnel — embauche et mouvements", "type": "personnel", "steps": [{"nom": "Besoin du responsable", "mode": "sequentiel", "approvers": [{"role": "Chef de projet"}], "delaiJours": 3, "id": "s0"}, {"nom": "Ressources humaines", "mode": "sequentiel", "approvers": [{"role": "RH"}], "delaiJours": 3, "id": "s1"}, {"nom": "Approbation de la direction", "mode": "sequentiel", "approvers": [{"role": "Directeur général"}], "delaiJours": 3, "id": "s2"}], "actif": true, "distincts": true}'::jsonb),
  ('wfc_s4_facturation', '{"id": "wfc_s4_facturation", "nom": "Facturation client", "type": "facturation", "steps": [{"nom": "Avancement et quantités", "mode": "sequentiel", "approvers": [{"role": "Conducteur de travaux"}], "delaiJours": 2, "id": "s0"}, {"nom": "Contrôle comptable", "mode": "sequentiel", "approvers": [{"role": "Comptable"}], "delaiJours": 2, "id": "s1"}, {"nom": "Validation de la direction", "mode": "sequentiel", "approvers": [{"role": "Directeur général"}], "delaiJours": 3, "seuil": {"montant": 5000, "devise": "USD"}, "id": "s2"}], "actif": true, "distincts": true}'::jsonb),
  ('wfc_s4_formation', '{"id": "wfc_s4_formation", "nom": "Formation — inscription et certificat", "type": "formation", "steps": [{"nom": "Validation pédagogique", "mode": "sequentiel", "approvers": [{"role": "Formateur"}], "delaiJours": 2, "id": "s0"}, {"nom": "Contrôle des paiements", "mode": "sequentiel", "approvers": [{"role": "Comptable"}], "delaiJours": 2, "id": "s1"}, {"nom": "Délivrance par la direction", "mode": "sequentiel", "approvers": [{"role": "Directeur général"}], "delaiJours": 3, "id": "s2"}], "actif": true, "distincts": true}'::jsonb);

insert into wf_circuits(org_id, id, data, actif)
select o.id, s.id, s.data, true
  from organisations o cross join _s4 s
 where not exists (select 1 from wf_circuits g where g.org_id = o.id and g.id = s.id)
   and not exists (select 1 from wf_circuits g where g.org_id = o.id and g.data->>'nom' = s.data->>'nom');

-- Contrôle : chaque organisation doit avoir les six circuits (attendu : 6 pour chacune)
select o.id as organisation, count(g.id) as circuits_interservices
  from organisations o left join wf_circuits g on g.org_id = o.id and g.id like 'wfc_s4\_%' escape '\'
 group by o.id order by 1;

-- RETOUR ARRIÈRE : delete from wf_circuits where id like 'wfc_s4\_%' escape '\';   (les dossiers déjà soumis gardent leur copie du circuit)
