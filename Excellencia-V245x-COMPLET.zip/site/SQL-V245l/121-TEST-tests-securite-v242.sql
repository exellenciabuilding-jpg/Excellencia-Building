-- Excellencia Building V242 — TESTS DE SÉCURITÉ sur la VRAIE base (cahier de tests §9 de l'étude V238).
-- À exécuter dans Supabase › SQL Editor APRÈS migration-v242-passation-donnees.sql (et v242b si vous l'avez appliqué), de préférence sur la copie de recette.
-- AUCUNE donnée n'est écrite : seule une fonction temporaire de la session est créée. Chaque ligne du résultat se lit : test · profil · attendu · obtenu · OK/ÉCHEC.
-- La fonction t_peut() reproduit exactement peut() de migration-v99zn (admin / lecteur / polyvalent / droits_fonction) sans avoir besoin de comptes réels.
-- Si le fichier 2 (restrictions) n'est PAS appliqué, les tests « refusé » peuvent échouer : c'est alors la preuve que des droits plus larges que la matrice subsistent
-- (ils sont listés par le contrôle 3b du fichier 1).
create or replace function pg_temp.t_peut(p_role text, p_fonction text, p_col text, p_ecrire boolean)
returns boolean language sql stable as $$
  select case
    when p_role = 'admin' then true
    when p_ecrire and p_role <> 'editeur' then false
    when p_fonction = 'polyvalent' then not exists(select 1 from collections_sensibles s where s.collection = p_col)
    else exists(select 1 from droits_fonction d where d.fonction = p_fonction and d.collection = p_col and (case when p_ecrire then d.ecrire else d.lire end))
  end $$;

with t(n, test, profil, attendu, obtenu) as (values
 ('1',  'Ouvrir l''éditeur de plans (lecture des plans)',           'comptable',     false, (pg_temp.t_peut('editeur','comptable','plans',false) or pg_temp.t_peut('editeur','comptable','plans_v94',false) or pg_temp.t_peut('editeur','comptable','plans_coupes_structure',false))),
 ('2',  'Lire les écritures comptables (caisse, engagements, paie… ; hors « bons_paiement », demande préparée par le chantier, V235/V245)','architecte',   false, (pg_temp.t_peut('editeur','architecte','caisse',false) or pg_temp.t_peut('editeur','architecte','engagements',false) or pg_temp.t_peut('editeur','architecte','paie',false) or pg_temp.t_peut('editeur','architecte','factures',false))),
 ('3',  'Créer un paiement',                                        'magasinier',    false, (pg_temp.t_peut('editeur','magasinier','paiements_apprenants',true) or pg_temp.t_peut('editeur','magasinier','bons_paiement',true) or pg_temp.t_peut('editeur','magasinier','caisse',true))),
 ('4',  'Consulter les recettes globales (caisse, factures)',       'formateur',     false, (pg_temp.t_peut('editeur','formateur','caisse',false) or pg_temp.t_peut('editeur','formateur','factures',false) or pg_temp.t_peut('editeur','formateur','paiements_apprenants',false))),
 ('5',  'Transmettre une demande d''achat (création)',              'conducteur',    true,  pg_temp.t_peut('editeur','conducteur','v92_demandes_achat',true)),
 ('5b', 'La demande est visible aux services habilités',            'magasinier + comptable + direction', true, (pg_temp.t_peut('editeur','magasinier','v92_demandes_achat',false) and pg_temp.t_peut('editeur','comptable','v92_demandes_achat',false) and pg_temp.t_peut('editeur','direction','v92_demandes_achat',false))),
 ('5c', 'La demande n''est pas visible aux services non concernés', 'architecte',    false, pg_temp.t_peut('editeur','architecte','v92_demandes_achat',false)),
 ('7',  'Consulter les données globales',                           'direction',     true,  (pg_temp.t_peut('editeur','direction','clients',false) and pg_temp.t_peut('editeur','direction','factures',false) and pg_temp.t_peut('editeur','direction','projets',false) and pg_temp.t_peut('editeur','direction','stock',false))),
 ('8',  'Après changement de service (chef_projet → rh) : plus d''écriture sur le planning chantier', 'rh', false, pg_temp.t_peut('editeur','rh','planning_chantier',true)),
 ('9',  'Écriture directe par API avec un compte lecteur',          'lecteur',       false, pg_temp.t_peut('lecteur','comptable','factures',true)),
 ('9b', 'Accès direct aux collections sensibles (paie, personnel)', 'polyvalent',    false, (pg_temp.t_peut('editeur','polyvalent','paie',false) or pg_temp.t_peut('editeur','polyvalent','personnel',false))),
 ('9c', 'Accès direct aux notes de calcul',                         'comptable',     false, pg_temp.t_peut('editeur','comptable','notes_calcul',false)),
 ('9d', 'Accès direct aux données RH et paie',                      'formateur',     false, (pg_temp.t_peut('editeur','formateur','personnel',false) or pg_temp.t_peut('editeur','formateur','paie',false)))
)
select n as test, profil, test as description, case when attendu then 'autorisé' else 'refusé' end as attendu,
       case when obtenu then 'autorisé' else 'refusé' end as obtenu, case when attendu = obtenu then 'OK' else 'ÉCHEC' end as resultat
  from t order by n;

-- ---------- Contrôles de structure (le serveur applique les règles, pas seulement l'interface) ----------
with s(n, controle, ok) as (values
 ('S1', 'RLS active sur enregistrements',                                     (select relrowsecurity from pg_class where oid = 'public.enregistrements'::regclass)),
 ('S2', 'RLS active sur droits_fonction',                                     (select relrowsecurity from pg_class where oid = 'public.droits_fonction'::regclass)),
 ('S3', 'La lecture des fiches passe par peut()',                              exists(select 1 from pg_policies where tablename = 'enregistrements' and policyname = 'enr_lire' and qual ilike '%peut(%')),
 ('S4', 'Aucune politique d''écriture directe sur enregistrements (écriture par enregistrer() seulement)', not exists(select 1 from pg_policies where tablename = 'enregistrements' and cmd in ('INSERT','UPDATE','DELETE','ALL'))),
 ('S5', 'enregistrer() contrôle le droit et détecte les conflits de version',  (select prosrc ilike '%peut(%' and prosrc ilike '%conflit%' from pg_proc where proname = 'enregistrer' limit 1)),
 ('S6', 'Un refus est journalisé',                                            (select prosrc ilike '%''refus''%' from pg_proc where proname = 'enregistrer' limit 1)),
 ('S7', 'Séparation des tâches dans les décisions du workflow',               (select prosrc ilike '%Séparation des tâches%' from pg_proc where proname = 'wf_decider' limit 1)),
 ('S8', 'Collections sensibles déclarées (paie, personnel, contrats RH)',      (select count(*) = 3 from collections_sensibles where collection in ('paie','personnel','contrats_rh'))),
 ('S9', 'La matrice V242 est en place (droits_matrice_v242 non vide)',         (select count(*) >= 150 from droits_matrice_v242)),
 ('S10','Aucun droit de la matrice manquant',                                  not exists(select 1 from droits_matrice_v242 m left join droits_fonction d on d.fonction = m.fonction and d.collection = m.collection where d.fonction is null or (m.lire and not d.lire) or (m.ecrire and not d.ecrire))),
 ('S11','Aucun droit plus large que la matrice (collections gouvernées pour les 9 fonctions ; règle par v242b + v243b)',      not exists(select 1 from droits_fonction d left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
          where d.fonction in ('direction','comptable','architecte','bureau_etudes','conducteur','chef_projet','rh','magasinier','formateur')
            and d.collection in (select collection from droits_matrice_v242 where fonction in ('direction','comptable','architecte','bureau_etudes','conducteur','chef_projet','rh','magasinier','formateur')) and (m.fonction is null or (m.ecrire = false and d.ecrire = true))))
)
select n as controle, controle as description, case when ok then 'OK' else 'ÉCHEC' end as resultat from s order by length(n), n;
