-- Excellencia Building V242 — PASSATION DES DONNÉES entre services (matrice de partage de l'étude V238, §3).
-- Traduit la matrice « données × services » en droits serveur (table droits_fonction, appliquée par la fonction peut() de migration-v99zn) pour les fonctions :
--   direction = Direction · comptable = Compta · architecte = Archi · bureau_etudes = BE · conducteur + chef_projet = Chantier · rh = RH · magasinier = Achats + Stock · formateur = Formation.
--   « Commercial » n'a pas de fonction serveur : ses droits restent à la Direction (V237g). « Rapports de service » : aucune collection enregistrée, rien à régler.
-- Codes : V, C, M → lire + écrire · L → lire seule · « — » → aucune ligne (refus) · le conditionnel « * » est accordé au niveau de la fonction (filtrage par projet : RLS à poser, étape ultérieure).
-- Les rôles « lecteur » n'écrivent jamais, quel que soit le droit de fonction (peut() l'impose) ; « admin » a tout ; « polyvalent » n'est pas touché.
-- FICHIER 2 sur 2 : partie RESTRICTIVE (optionnelle). À exécuter APRÈS le fichier 1, après avoir lu les écarts (contrôle 3b) et essayé sur la copie de recette.
-- Elle retire les droits que la matrice refuse (« — ») et repasse en lecture seule ceux qu'elle limite à « L », pour les 9 fonctions et les collections de la matrice uniquement.
-- Sécurité : rien n'est modifié tant que la ligne « confirmer » ci-dessous n'est pas passée de 'NON' à 'OUI'. Retour arrière en bas du fichier.
do $$ begin
  if to_regclass('public.droits_matrice_v242') is null or to_regclass('public.droits_fonction_sauv_v242') is null then
    raise exception 'Exécutez d''abord migration-v242-passation-donnees.sql (fichier 1)';
  end if;
end $$;

select set_config('exb.confirmer', 'NON', false);   -- ← remplacez 'NON' par 'OUI' pour appliquer

-- Aperçu : ce qui sera retiré / repassé en lecture seule
select d.fonction, d.collection,
       case when m.fonction is null then 'RETIRÉ' else 'ÉCRITURE RETIRÉE' end as action
  from droits_fonction d left join droits_matrice_v242 m on m.fonction = d.fonction and m.collection = d.collection
 where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and d.collection in ('apprenants', 'bons_paiement', 'caisse', 'certificats', 'clients', 'contrats_rh', 'cotations', 'devis', 'engagements', 'evaluations', 'factures', 'formateurs', 'formations', 'mouvements', 'notes_calcul', 'paie', 'paie_calculs', 'paie_reglements', 'paiements_apprenants', 'personnel', 'planning_chantier', 'planning_formation', 'plans', 'plans_coupes_structure', 'plans_fichiers', 'plans_v94', 'presences', 'projets', 'recus', 'revisions_plans_v94', 'stock', 'stock_consultations', 'stock_depots', 'stock_inventaires', 'stock_transferts', 'v92_demandes_achat', 'v92_factures_fournisseurs', 'v93_paiements')
   and (m.fonction is null or (m.ecrire = false and d.ecrire = true))
 order by d.collection, d.fonction;

do $$ begin
  if coalesce(current_setting('exb.confirmer', true), 'NON') = 'OUI' then
    delete from droits_fonction d
     where d.fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and d.collection in ('apprenants', 'bons_paiement', 'caisse', 'certificats', 'clients', 'contrats_rh', 'cotations', 'devis', 'engagements', 'evaluations', 'factures', 'formateurs', 'formations', 'mouvements', 'notes_calcul', 'paie', 'paie_calculs', 'paie_reglements', 'paiements_apprenants', 'personnel', 'planning_chantier', 'planning_formation', 'plans', 'plans_coupes_structure', 'plans_fichiers', 'plans_v94', 'presences', 'projets', 'recus', 'revisions_plans_v94', 'stock', 'stock_consultations', 'stock_depots', 'stock_inventaires', 'stock_transferts', 'v92_demandes_achat', 'v92_factures_fournisseurs', 'v93_paiements')
       and not exists (select 1 from droits_matrice_v242 m where m.fonction = d.fonction and m.collection = d.collection);
    update droits_fonction d set ecrire = false
      from droits_matrice_v242 m
     where m.fonction = d.fonction and m.collection = d.collection and m.ecrire = false and d.ecrire = true;
    raise notice 'V242 : restrictions appliquées.';
  else
    raise notice 'V242 : aperçu seulement (exb.confirmer <> OUI) : rien n''a été modifié.';
  end if;
end $$;

-- Retour arrière complet (état d'avant V242) :
--   delete from droits_fonction where fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and collection in ('apprenants', 'bons_paiement', 'caisse', 'certificats', 'clients', 'contrats_rh', 'cotations', 'devis', 'engagements', 'evaluations', 'factures', 'formateurs', 'formations', 'mouvements', 'notes_calcul', 'paie', 'paie_calculs', 'paie_reglements', 'paiements_apprenants', 'personnel', 'planning_chantier', 'planning_formation', 'plans', 'plans_coupes_structure', 'plans_fichiers', 'plans_v94', 'presences', 'projets', 'recus', 'revisions_plans_v94', 'stock', 'stock_consultations', 'stock_depots', 'stock_inventaires', 'stock_transferts', 'v92_demandes_achat', 'v92_factures_fournisseurs', 'v93_paiements');
--   insert into droits_fonction select * from droits_fonction_sauv_v242 where fonction in ('direction', 'comptable', 'architecte', 'bureau_etudes', 'conducteur', 'chef_projet', 'rh', 'magasinier', 'formateur') and collection in ('apprenants', 'bons_paiement', 'caisse', 'certificats', 'clients', 'contrats_rh', 'cotations', 'devis', 'engagements', 'evaluations', 'factures', 'formateurs', 'formations', 'mouvements', 'notes_calcul', 'paie', 'paie_calculs', 'paie_reglements', 'paiements_apprenants', 'personnel', 'planning_chantier', 'planning_formation', 'plans', 'plans_coupes_structure', 'plans_fichiers', 'plans_v94', 'presences', 'projets', 'recus', 'revisions_plans_v94', 'stock', 'stock_consultations', 'stock_depots', 'stock_inventaires', 'stock_transferts', 'v92_demandes_achat', 'v92_factures_fournisseurs', 'v93_paiements') on conflict do nothing;
