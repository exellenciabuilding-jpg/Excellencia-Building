-- ===== Excellencia Building — V236h : LOTS DE PLANS (un QR commun pour 1 à 60 plans) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v129-plans-publics.sql. Réexécutable.
-- Seul changement : plan_public_publier accepte jusqu'à 60 documents (au lieu de 8). Tout le reste (code d'accès, dossier aléatoire,
-- droits « plans_fichiers », licence) est identique. plan_public_get renvoie déjà toute la liste des documents.

create or replace function plan_public_publier(
  p_org uuid, p_plan_id text, p_ref_plan text, p_titre text, p_type text, p_moe text, p_mo text,
  p_concepteur text, p_echelle text, p_indice text, p_apercu text, p_docs jsonb, p_token text, p_ref text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_docs jsonb; v_ap text; v_row plans_publics; v_ref text; v_code text; v_n int; v_yr text := to_char(now(),'YYYY'); e jsonb;
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  if p_token is null or p_token !~ '^[a-f0-9]{32}$' then
    return jsonb_build_object('ok',false,'erreur','Jeton de dossier invalide.');
  end if;
  if length(btrim(coalesce(p_titre,''))) < 2 then
    return jsonb_build_object('ok',false,'erreur','Le titre du projet est obligatoire.');
  end if;
  if p_docs is null or jsonb_typeof(p_docs) <> 'array' or jsonb_array_length(p_docs) not between 1 and 60 then
    return jsonb_build_object('ok',false,'erreur','Liste de documents invalide (1 à 60 documents).');
  end if;
  for e in select value from jsonb_array_elements(p_docs) loop
    if jsonb_typeof(e) <> 'object' or coalesce(e->>'fichier','') !~ ('^' || p_org::text || '/' || p_token || '/[A-Za-z0-9._-]{1,80}$') then
      return jsonb_build_object('ok',false,'erreur','Chemin de document invalide.');
    end if;
  end loop;
  select jsonb_agg(jsonb_build_object(
      'nom', left(coalesce(x.value->>'nom','Document'),120),
      'fichier', x.value->>'fichier',
      'format', left(upper(coalesce(x.value->>'format','PDF')),8),
      'taille', left(coalesce(x.value->>'taille',''),30),
      'kind', case when x.value->>'kind' = 'fiche' then 'fiche' else 'plan' end))
    into v_docs from jsonb_array_elements(p_docs) as x;
  v_ap := case when p_apercu is not null and length(p_apercu) <= 500000
                and p_apercu ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' then p_apercu else null end;

  if p_ref is not null then
    select * into v_row from plans_publics where org = p_org and ref = upper(btrim(p_ref)) for update;
    if not found then return jsonb_build_object('ok',false,'erreur','Référence inconnue.'); end if;
    update plans_publics set
      plan_id = left(p_plan_id,80), ref_plan = left(p_ref_plan,80), titre = left(btrim(p_titre),160), type_doc = left(p_type,160),
      maitre_oeuvre = left(p_moe,120), maitre_ouvrage = left(p_mo,120), concepteur = left(p_concepteur,120),
      echelle = left(p_echelle,40), indice = left(p_indice,60), apercu = v_ap, docs = v_docs,
      token = p_token, actif = true, maj_le = now()
    where id = v_row.id;
    return jsonb_build_object('ok',true,'ref',v_row.ref,'code',v_row.code,'ancien_token',v_row.token);
  end if;

  perform pg_advisory_xact_lock(hashtext('plans_publics_ref'));
  select coalesce(max(substring(ref from '([0-9]+)$')::int),0) + 1 into v_n from plans_publics where ref like 'EXB-' || v_yr || '-%';
  v_ref := 'EXB-' || v_yr || '-' || lpad(v_n::text, 3, '0');
  v_code := upper(substr(replace(gen_random_uuid()::text,'-',''),1,10));
  insert into plans_publics(org, ref, code, token, plan_id, ref_plan, titre, type_doc, maitre_oeuvre, maitre_ouvrage, concepteur, echelle, indice, apercu, docs)
  values (p_org, v_ref, v_code, p_token, left(p_plan_id,80), left(p_ref_plan,80), left(btrim(p_titre),160), left(p_type,160),
          left(p_moe,120), left(p_mo,120), left(p_concepteur,120), left(p_echelle,40), left(p_indice,60), v_ap, v_docs);
  return jsonb_build_object('ok',true,'ref',v_ref,'code',v_code);
end $$;
revoke all on function plan_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,jsonb,text,text) from public;
grant execute on function plan_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,jsonb,text,text) to authenticated;
