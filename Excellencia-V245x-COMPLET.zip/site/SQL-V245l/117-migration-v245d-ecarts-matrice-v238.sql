-- Excellencia Building V245d — ÉCARTS DE MATRICE avec l'étude V238 §3 (constat de conformité du 27/11/2026).
-- À exécuter APRÈS migration-v245c-perimetre-champs.sql. Réexécutable. Essayer d'abord sur la copie de recette.
--   PARTIE A (additive, appliquée tout de suite) : fonction « achats » — Dépenses C* (engagements, bons de paiement) et Paiements L* (v93_paiements).
--   PARTIE B (restrictive, SEULEMENT si exb.confirmer = 'OUI') : « magasinier » = colonne Stock de l'étude. Il garde les droits Stock mais perd ceux de la colonne Achats
--            (aujourd'hui portés par la fonction « achats » depuis V245) : engagements, bons_paiement, v92_factures_fournisseurs, planning_chantier.
--   Écart 1 (Chantier, Dépenses C*) : déjà conforme depuis V245 par engagements + bons_paiement. La CAISSE reste refusée au chantier (trésorerie : Compta / Direction) — décision à confirmer.
do $$ begin
  if to_regclass('public.droits_matrice_v242') is null or to_regclass('public.droits_fonction') is null then
    raise exception 'Exécutez d''abord migration-v242 / v243 / v245 (matrice et droits de fonction absents)';
  end if;
  if not exists (select 1 from droits_fonction where fonction = 'achats') then
    raise exception 'La fonction « achats » est absente : exécutez d''abord migration-v245-fonctions-export-perimetre.sql';
  end if;
end $$;

-- ---------- PARTIE A : droits manquants de la fonction « achats » ----------
drop table if exists pg_temp._v245d;
create temp table _v245d(fonction text, collection text, lire boolean, ecrire boolean);
insert into _v245d values
 ('achats','engagements',true,true), ('achats','bons_paiement',true,true), ('achats','v93_paiements',true,false);
insert into droits_fonction(fonction, collection, lire, ecrire)
select fonction, collection, lire, ecrire from _v245d
on conflict (fonction, collection) do update set lire = droits_fonction.lire or excluded.lire, ecrire = droits_fonction.ecrire or excluded.ecrire;
insert into droits_matrice_v242(fonction, collection, lire, ecrire)
select fonction, collection, lire, ecrire from _v245d
on conflict (fonction, collection) do update set lire = excluded.lire, ecrire = excluded.ecrire;

-- ---------- PARTIE B : magasinier = Stock seulement ----------
create table if not exists droits_fonction_sauv_v245d as select * from droits_fonction;
alter table droits_fonction_sauv_v245d enable row level security;   -- aucune politique : lisible seulement dans le SQL Editor
select set_config('exb.confirmer', 'NON', false);   -- ← remplacez 'NON' par 'OUI' pour appliquer la partie B

-- Aperçu : droits que le magasinier perdrait
select fonction, collection, lire, ecrire, 'RETIRÉ au magasinier' as action
  from droits_fonction
 where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier')
 order by collection;

do $$ begin
  if coalesce(current_setting('exb.confirmer', true), 'NON') = 'OUI' then
    delete from droits_fonction where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier');
    delete from droits_matrice_v242 where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier');
    raise notice 'V245d : le magasinier est limité à la colonne Stock.';
  else
    raise notice 'V245d : partie A appliquée ; partie B en aperçu seulement (exb.confirmer <> OUI).';
  end if;
end $$;

-- Retour arrière de la partie B :
--   insert into droits_fonction select * from droits_fonction_sauv_v245d where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier') on conflict do nothing;
--   insert into droits_matrice_v242(fonction, collection, lire, ecrire) select fonction, collection, lire, ecrire from droits_fonction_sauv_v245d where fonction = 'magasinier' and collection in ('engagements', 'bons_paiement', 'v92_factures_fournisseurs', 'planning_chantier') on conflict do nothing;
-- Retour arrière de la partie A :
--   delete from droits_fonction where fonction = 'achats' and collection in ('engagements', 'bons_paiement', 'v93_paiements');  (idem dans droits_matrice_v242)
