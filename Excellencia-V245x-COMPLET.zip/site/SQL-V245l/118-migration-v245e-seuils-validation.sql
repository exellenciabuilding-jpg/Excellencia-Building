-- Excellencia Building V245e — SEUILS DE VALIDATION (étude V238 §3, §4 « validation selon seuil » et §5 « validation ≠ modification »).
-- À exécuter APRÈS migration-v245d. Réexécutable. Essayer d'abord sur la copie de recette.
-- Règle : au-delà d'un montant (par devise), une fiche ne peut PASSER À un statut d'approbation que si l'auteur est administrateur ou d'une fonction « validante »
--         (par défaut : direction). En dessous du seuil, rien ne change. Tout refus est journalisé (« refus seuil de validation »). Contrôle côté SERVEUR (enregistrer()).
-- Règles de départ (modifiables, voir en bas) : devis ≥ 5 000 USD ; engagements de dépense ≥ 1 000 USD (équivalents CDF / EUR).
-- Non couvert à ce stade : commandes fournisseurs et règlements (champs non confirmés) — ajoutez une ligne dans seuils_validation quand les champs sont connus.
do $$ begin
  if to_regprocedure('public.perimetre_ok(uuid,text,text,jsonb)') is null or to_regclass('public.membres') is null then
    raise exception 'Exécutez d''abord migration-v245 et v245c (périmètre et enregistrer V245 absents)';
  end if;
end $$;

create table if not exists seuils_validation(
  id bigint generated always as identity primary key,
  org_id uuid,                                   -- null = règle pour toutes les organisations ; une ligne propre à l'organisation la remplace
  collection text not null,
  libelle text not null default '',
  champ_montant text not null,                   -- champ JSON du montant dans la fiche
  statuts_approbation text[] not null,           -- statuts (en minuscules) qui valent approbation
  seuil numeric not null check (seuil >= 0),
  devise text not null default 'USD',
  validantes text[] not null default array['direction'],
  actif boolean not null default true
);
create unique index if not exists seuils_validation_uq on seuils_validation (coalesce(org_id, '00000000-0000-0000-0000-000000000000'::uuid), collection, devise);
alter table seuils_validation enable row level security;
drop policy if exists sv_lire on seuils_validation;
create policy sv_lire on seuils_validation for select to authenticated
  using (org_id is null or exists (select 1 from membres m where m.org_id = seuils_validation.org_id and m.user_id = auth.uid()));
revoke insert, update, delete, truncate on seuils_validation from anon, authenticated;
revoke all on seuils_validation from anon;

insert into seuils_validation(org_id, collection, libelle, champ_montant, statuts_approbation, seuil, devise)
select null, v.collection, v.libelle, v.champ, v.st, v.seuil, v.devise
  from (values
   ('devis',       'Devis — acceptation / approbation', 'total',  array['approuvé','validé','accepté','signé'], 5000::numeric,    'USD'),
   ('devis',       'Devis — acceptation / approbation', 'total',  array['approuvé','validé','accepté','signé'], 12500000::numeric,'CDF'),
   ('devis',       'Devis — acceptation / approbation', 'total',  array['approuvé','validé','accepté','signé'], 5000::numeric,    'EUR'),
   ('engagements', 'Engagements de dépense',            'amount', array['approuvé','validé','engagé','commandé'], 1000::numeric,    'USD'),
   ('engagements', 'Engagements de dépense',            'amount', array['approuvé','validé','engagé','commandé'], 2500000::numeric, 'CDF'),
   ('engagements', 'Engagements de dépense',            'amount', array['approuvé','validé','engagé','commandé'], 1000::numeric,    'EUR')
  ) as v(collection, libelle, champ, st, seuil, devise)
 where not exists (select 1 from seuils_validation s where s.org_id is null and s.collection = v.collection and s.devise = v.devise);

-- Le fait que la fiche franchisse le seuil est jugé sur le MONTANT et le STATUT de la fiche enregistrée.
create or replace function seuil_ok(p_org uuid, p_col text, p_old jsonb, p_new jsonb)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare m membres; r seuils_validation; st_new text; st_old text; dv text; mt numeric; mt_old numeric; sans_seuil boolean := false; lim numeric;
begin
  if p_new is null or auth.uid() is null then return true; end if;
  select * into m from membres where org_id = p_org and user_id = auth.uid();
  if not found then return true; end if;                    -- l'appartenance est déjà exigée par peut()
  if m.role = 'admin' then return true; end if;
  dv := upper(coalesce(nullif(p_new->>'devise',''), nullif(p_new->>'cur',''), nullif(p_new->>'currency',''), 'USD'));
  if dv = 'FC' then dv := 'CDF'; end if;
  select * into r from seuils_validation where actif and collection = p_col and (org_id is null or org_id = p_org) and upper(devise) = dv
   order by org_id nulls last limit 1;
  if not found then
    select * into r from seuils_validation where actif and collection = p_col and (org_id is null or org_id = p_org) order by org_id nulls last limit 1;
    if not found then return true; end if;                  -- aucune règle pour cette collection
    sans_seuil := true;                                         -- devise sans seuil défini : on exige un validant (comme le workflow V149)
  end if;
  st_new := lower(coalesce(nullif(p_new->>'statut',''), nullif(p_new->>'status',''), ''));
  if st_new = '' or not (st_new = any (r.statuts_approbation)) then return true; end if;
  st_old := lower(coalesce(nullif(p_old->>'statut',''), nullif(p_old->>'status',''), ''));
  begin mt := nullif(regexp_replace(coalesce(p_new->>r.champ_montant, ''), '[^0-9.\-]', '', 'g'), '')::numeric; exception when others then mt := null; end;
  begin mt_old := nullif(regexp_replace(coalesce(p_old->>r.champ_montant, ''), '[^0-9.\-]', '', 'g'), '')::numeric; exception when others then mt_old := null; end;
  lim := case when sans_seuil then 0 else r.seuil end;
  if coalesce(mt, 0) <= 0 or coalesce(mt, 0) < lim then return true; end if;
  -- déjà approuvée avant, et le montant n'a pas augmenté : on ne bloque pas une correction sans effet financier
  if st_old = any (r.statuts_approbation) and coalesce(mt, 0) <= coalesce(mt_old, 0) then return true; end if;
  return m.fonction = any (r.validantes);
end $$;
revoke all on function seuil_ok(uuid, text, jsonb, jsonb) from public, anon;
grant execute on function seuil_ok(uuid, text, jsonb, jsonb) to authenticated;

-- Modifier un seuil : administrateur seulement, journalisé.
create or replace function definir_seuil(p_org uuid, p_collection text, p_devise text, p_seuil numeric, p_actif boolean default true)
returns json language plpgsql security definer set search_path = public as $$
declare base seuils_validation;
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  select * into base from seuils_validation where org_id is null and collection = p_collection and upper(devise) = upper(p_devise) limit 1;
  if not found then raise exception 'Aucune règle de départ pour % / %', p_collection, p_devise; end if;
  insert into seuils_validation(org_id, collection, libelle, champ_montant, statuts_approbation, seuil, devise, validantes, actif)
  values (p_org, base.collection, base.libelle, base.champ_montant, base.statuts_approbation, p_seuil, base.devise, base.validantes, p_actif)
  on conflict (coalesce(org_id, '00000000-0000-0000-0000-000000000000'::uuid), collection, devise) do update set seuil = excluded.seuil, actif = excluded.actif;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org, auth.uid(), 'seuils_validation', p_collection || '/' || upper(p_devise), 'modification seuil', 0);
  return json_build_object('ok', true);
end $$;
revoke all on function definir_seuil(uuid, text, text, numeric, boolean) from public, anon;
grant execute on function definir_seuil(uuid, text, text, numeric, boolean) to authenticated;

-- enregistrer() : version V245 + contrôle de seuil
create or replace function enregistrer(p_org uuid, p_col text, p_id text, p_data jsonb, p_base int, p_supprime boolean default false)
returns json language plpgsql security definer set search_path=public as $$
declare cur enregistrements; nv int; ex boolean; createur uuid; nb int;
begin
  if not peut(p_org,p_col,true) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus',0);
    return json_build_object('ok',false,'refus',true);
  end if;
  if not licence_ecriture_ok(p_org) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus licence',0);
    return json_build_object('ok',false,'refus',true,'licence',true);
  end if;
  select * into cur from enregistrements where org_id=p_org and collection=p_col and id=p_id for update;
  ex := found;
  if not perm_ok(p_org, case when ex then 'modification' else 'creation' end) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus permission',0);
    return json_build_object('ok',false,'refus',true,'permission',true);
  end if;
  -- V245 : périmètre par projet — on ne modifie pas une fiche d'un projet non affecté, et on ne range pas une fiche dans un projet non affecté
  if (ex and not perimetre_ok(p_org, p_col, p_id, cur.data)) or not perimetre_ok(p_org, p_col, p_id, p_data) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus périmètre',0);
    return json_build_object('ok',false,'refus',true,'perimetre',true);
  end if;
  -- V245e : seuil de validation (étude §3-§5) — au-delà du seuil, l'approbation d'une fiche est réservée aux fonctions validantes (par défaut : Direction) ou à l'administrateur
  if not p_supprime and not seuil_ok(p_org, p_col, case when ex then cur.data else null end, p_data) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus seuil de validation',0);
    return json_build_object('ok',false,'refus',true,'seuil',true);
  end if;
  -- V245 : le préparateur d'un bon de paiement n'est pas son encaisseur (sauf organisation d'un seul membre)
  if p_col = 'bons_paiement' and ex and (p_data->>'statut') in ('payé','partiel') and coalesce(cur.data->>'statut','') not in ('payé','partiel') then
    select user_id into createur from journal_entreprise where org_id = p_org and collection = p_col and rec_id = p_id and action = 'création' order by quand limit 1;
    select count(*) into nb from membres where org_id = p_org;
    if createur is not null and createur = auth.uid() and nb > 1 then
      insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus séparation des tâches',0);
      return json_build_object('ok',false,'refus',true,'separation',true);
    end if;
  end if;
  if ex then
    if cur.version<>p_base then
      return json_build_object('ok',false,'conflit',true,'version',cur.version,'data',cur.data,'supprime',cur.supprime);
    end if;
    nv:=cur.version+1;
    update enregistrements set data=p_data,version=nv,supprime=p_supprime,maj=now(),maj_par=auth.uid()
      where org_id=p_org and collection=p_col and id=p_id;
  else
    if p_base<>0 then
      return json_build_object('ok',false,'conflit',true,'version',0,'data',null,'supprime',true);
    end if;
    nv:=1;
    insert into enregistrements(org_id,collection,id,data,version,supprime,maj_par) values (p_org,p_col,p_id,p_data,1,p_supprime,auth.uid());
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org,auth.uid(),p_col,p_id,case when p_supprime then 'suppression' when nv=1 then 'création' else 'modification' end,nv);
  return json_build_object('ok',true,'version',nv);
end $$;
grant execute on function enregistrer(uuid,text,text,jsonb,int,boolean) to authenticated;

-- Contrôles à lire après exécution
select 'V245e-a' as controle, 'seuil_ok() présent' as description, case when to_regprocedure('seuil_ok(uuid,text,jsonb,jsonb)') is not null then 'OK' else 'ÉCHEC' end as resultat
union all select 'V245e-b', 'enregistrer() applique le seuil', case when exists(select 1 from pg_proc where proname = 'enregistrer' and pronamespace = 'public'::regnamespace and prosrc ilike '%seuil_ok(%') then 'OK' else 'ÉCHEC' end
union all select 'V245e-c', 'règles de départ chargées (6)', case when (select count(*) from seuils_validation where org_id is null) >= 6 then 'OK' else 'ÉCHEC' end;

-- Pour changer un seuil (administrateur connecté, depuis l'appli) : select definir_seuil('<id organisation>', 'devis', 'USD', 10000);
-- Pour désactiver une règle : select definir_seuil('<id organisation>', 'engagements', 'USD', 1000, false);
-- Retour arrière : réexécuter migration-v245-fonctions-export-perimetre.sql (remet enregistrer() V245) ; la table seuils_validation peut rester sans effet.
