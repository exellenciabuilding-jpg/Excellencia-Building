/* Excellencia Building V209j — ARCHITECTURE : matériaux et finitions.
 * Cahier des charges Évolution ERP V1.0, §5.2 : « Matériaux et finitions — bibliothèque, spécifications, fiches techniques, quantités et coûts indicatifs » (P2).
 *
 *  • BIBLIOTHÈQUE (commune à l’entreprise) : code, désignation, famille, unité, prix unitaire INDICATIF saisi par l’utilisateur, taux de perte, fournisseur, performances (texte libre),
 *    FICHE TECHNIQUE (référence, lien http(s), date, date de fin de validité), statut (à valider / validé / obsolète). Aucun prix ni aucune performance n’est prérempli.
 *  • SPÉCIFICATIONS (par projet) : une ligne = un matériau affecté à un poste (sol, mur, plafond…) d’un local du tableau des surfaces (V209e) ou d’une zone libre.
 *    Quantité = surface de référence du local (surface dessinée si renseignée, sinon surface cible) × coefficient (ex. 2,6 pour des murs) OU quantité saisie ; majorée de la perte.
 *  • COÛT INDICATIF = quantité majorée × prix unitaire ; totaux par lot/poste, par famille, par local ; part des lignes sans prix ; contrôle : matériau obsolète, non validé,
 *    fiche absente ou périmée, unité non surfacique avec coefficient, local introuvable.
 *  • Cahier des finitions par local (impression), export CSV de la bibliothèque, des spécifications, import CSV de la bibliothèque.
 *  Stockage : exb_arch_mat (collection serveur « arch_materiaux », migration-v209j-materiaux.sql). Aucune donnée existante touchée.
 *  Les calculs (EXBMAT.calcul, parseBib, urlOk, csvBib) sont purs et testés dans tools/test-materiaux.js. */
(function (w, d) {
  'use strict';
  var KEY = 'exb_arch_mat', COL = 'arch_materiaux', KP = 'exb_arch_prog';
  var FAM = [['sol', 'Revêtements de sol'], ['mur', 'Revêtements muraux / peintures'], ['plafond', 'Plafonds'], ['menuiserie', 'Menuiseries'], ['facade', 'Façade'], ['toiture', 'Toiture / étanchéité'], ['sanitaire', 'Appareils sanitaires'], ['elec', 'Électricité / éclairage'], ['structure', 'Maçonnerie / structure'], ['isolation', 'Isolation'], ['autre', 'Autre']];
  var POSTE = [['sol', 'Sol'], ['plinthe', 'Plinthe'], ['mur', 'Mur'], ['plafond', 'Plafond'], ['menuiserie', 'Menuiserie'], ['facade', 'Façade'], ['toiture', 'Toiture'], ['equipement', 'Équipement'], ['autre', 'Autre']];
  var UNITES = ['m²', 'ml', 'm³', 'u', 'kg', 'l', 'forfait'];
  var STAT = [['a_valider', 'À valider'], ['valide', 'Validé'], ['obsolete', 'Obsolète']];
  var SSTAT = [['propose', 'Proposé'], ['valide', 'Validé par le client'], ['commande', 'Commandé']];
  var st = { pid: '', tab: 'specs', q: '', fam: '' };

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function hasNum(v) { return v !== '' && v != null && !isNaN(Number(String(v).replace(',', '.'))); }
  function num(v, def) { return hasNum(v) ? Number(String(v).replace(',', '.')) : (def === undefined ? 0 : def); }
  function fm(n, dg) { return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: dg == null ? 2 : dg }).format(n || 0); }
  function s(v, n) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); } catch (e) { } }
  function canR() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'lire'); } catch (e) { return true; } }
  function canW() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'ecrire'); } catch (e) { return true; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function projs() { try { return w.EXBS.projects(); } catch (e) { return []; } }
  function load() { try { return w.EXBS.get(KEY) || []; } catch (e) { return []; } }
  function save(a) { return w.EXBS.set(KEY, a); }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction)) || ''; } catch (e) { return ''; } }
  function lab(L, k) { for (var i = 0; i < L.length; i++) if (L[i][0] === k) return L[i][1]; return k || ''; }
  function urlOk(u) { u = String(u || '').trim(); return u === '' || /^https?:\/\/[^\s<>"']+$/i.test(u); }       /* jamais javascript: ni data: */
  function dateOk(v) { return v === '' || v == null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(Date.parse(v))); }

  /* ================= CALCUL (pur) =================
   * mats : enregistrements 'mat' ; specs : enregistrements 'spec' du projet ; rooms : lignes de EXBARCP.calc (id, nom, niveau, cible, proj) ; now : 'AAAA-MM-JJ' (testable). */
  function calcul(mats, specs, rooms, now) {
    now = now || today();
    var M = {}, Rm = {}; (mats || []).forEach(function (m) { M[m.id] = m; }); (rooms || []).forEach(function (r) { Rm[r.id] = r; });
    var R = { lignes: [], lots: {}, familles: {}, locaux: {}, total: 0, sansPrix: 0, alertes: 0 };
    (specs || []).forEach(function (sp) {
      var m = M[sp.mat], al = [], room = sp.local ? Rm[sp.local] : null, base = 0, mode = sp.mode === 'manuel' ? 'manuel' : 'surface', q = 0;
      if (!m) al.push('Matériau introuvable dans la bibliothèque.');
      if (mode === 'surface') {
        if (!sp.local) al.push('Aucun local choisi : saisir une quantité ou choisir un local.');
        else if (!room) al.push('Local introuvable dans le tableau des surfaces.');
        else { base = room.proj !== null && room.proj !== undefined ? room.proj : room.cible; q = base * num(sp.coef, 1); if (room.proj === null || room.proj === undefined) al.push('Surface du local non dessinée : surface cible utilisée.'); }
        if (m && m.unite && m.unite !== 'm²' && num(sp.coef, 1) !== 1) al.push('Coefficient appliqué à une surface alors que l’unité du matériau est « ' + m.unite + ' ».');
        if (m && m.unite && ['m²', 'u', 'forfait'].indexOf(m.unite) < 0 && sp.local) al.push('Unité « ' + m.unite + ' » : vérifier que le coefficient donne bien une quantité dans cette unité.');
      } else q = num(sp.qte, 0);
      var perte = hasNum(sp.perte) ? num(sp.perte) : (m ? num(m.perte, 0) : 0), qt = q * (1 + perte / 100), pu = m ? num(m.pu, NaN) : NaN, noPrix = !m || !hasNum(m && m.pu) || num(m.pu) <= 0;
      var cout = noPrix ? null : qt * pu;
      if (m) {
        if (m.statut === 'obsolete') al.push('Matériau OBSOLÈTE.');
        else if (m.statut !== 'valide') al.push('Matériau non validé.');
        if (!m.fiche_ref && !m.fiche_url) al.push('Fiche technique absente.');
        else if (m.fiche_fin && m.fiche_fin < now) al.push('Fiche technique périmée depuis le ' + m.fiche_fin + '.');
        if (noPrix) al.push('Prix unitaire non renseigné : coût non chiffré.');
      }
      if (q <= 0 && (mode === 'manuel' || room)) al.push('Quantité nulle.');
      var L = { id: sp.id, lot: sp.poste || 'autre', matId: sp.mat, mat: m ? m.nom : '(supprimé)', code: m ? m.code : '', famille: m ? m.famille : '', unite: m ? m.unite : '', local: room ? room.nom : (sp.zone || ''), niveau: room ? room.niveau : '', localId: sp.local || '', mode: mode, base: base, coef: num(sp.coef, 1), q: q, perte: perte, qt: qt, pu: noPrix ? null : pu, cout: cout, statut: sp.statut || 'propose', alertes: al, note: sp.note || '' };
      R.lignes.push(L); R.alertes += al.length ? 1 : 0;
      if (cout === null) R.sansPrix++; else R.total += cout;
      var add = function (O, k) { if (!O[k]) O[k] = { cout: 0, n: 0, sansPrix: 0 }; O[k].n++; if (cout === null) O[k].sansPrix++; else O[k].cout += cout; };
      add(R.lots, L.lot); add(R.familles, L.famille || 'autre'); add(R.locaux, L.local || '(sans local)');
    });
    R.partSansPrix = R.lignes.length ? R.sansPrix / R.lignes.length * 100 : 0;
    return R;
  }

  /* ================= IMPORT / EXPORT CSV (purs) ================= */
  var COLS = ['code', 'nom', 'famille', 'unite', 'pu', 'perte', 'fournisseur', 'fiche_ref', 'fiche_url', 'fiche_date', 'fiche_fin', 'statut', 'perfs', 'notes'];
  function csvCell(c) { c = String(c == null ? '' : c); if (/^[=+\-@]/.test(c) && !/^-?\d+([.,]\d+)?$/.test(c)) c = "'" + c; return /[";\r\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }       /* neutralise les formules Excel */
  function csvBib(mats) { return '﻿' + [COLS.join(';')].concat((mats || []).map(function (m) { return COLS.map(function (k) { return csvCell(m[k]); }).join(';'); })).join('\r\n'); }
  function splitCsv(txt) {
    var rows = [], row = [], cur = '', q = false, i, c; txt = String(txt || '').replace(/^﻿/, '');
    for (i = 0; i < txt.length; i++) {
      c = txt[i];
      if (q) { if (c === '"') { if (txt[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
      else if (c === '"') q = true; else if (c === ';') { row.push(cur); cur = ''; } else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; } else if (c !== '\r') cur += c;
    }
    if (cur !== '' || row.length) { row.push(cur); rows.push(row); } return rows;
  }
  function parseBib(txt, existing) {
    var rows = splitCsv(txt).filter(function (r) { return r.some(function (x) { return String(x).trim() !== ''; }); }), out = { items: [], erreurs: [], maj: 0, nouveaux: 0 };
    if (rows.length < 2) { out.erreurs.push('Fichier vide ou sans ligne de données.'); return out; }
    var head = rows[0].map(function (h) { return String(h).trim().toLowerCase(); }), idx = {}; COLS.forEach(function (k) { idx[k] = head.indexOf(k); });
    if (idx.nom < 0) { out.erreurs.push('Colonne « nom » absente (séparateur « ; » attendu).'); return out; }
    var byCode = {}; (existing || []).forEach(function (m) { if (m.code) byCode[m.code.toLowerCase()] = m; });
    var seen = {};
    rows.slice(1).forEach(function (r, n) {
      var g = function (k) { return idx[k] >= 0 ? String(r[idx[k]] == null ? '' : r[idx[k]]).replace(/^'(?=[=+\-@])/, '').trim() : ''; }, ln = n + 2;
      var m = { code: s(g('code'), 40), nom: s(g('nom'), 160), famille: g('famille'), unite: g('unite'), pu: g('pu'), perte: g('perte'), fournisseur: s(g('fournisseur'), 120), fiche_ref: s(g('fiche_ref'), 120), fiche_url: g('fiche_url'), fiche_date: g('fiche_date'), fiche_fin: g('fiche_fin'), statut: g('statut'), perfs: s(g('perfs'), 400), notes: s(g('notes'), 400) };
      if (!m.nom) return out.erreurs.push('Ligne ' + ln + ' : désignation vide.');
      if (FAM.every(function (f) { return f[0] !== m.famille; })) m.famille = (FAM.filter(function (f) { return f[1].toLowerCase() === m.famille.toLowerCase(); })[0] || ['autre'])[0];
      if (UNITES.indexOf(m.unite) < 0) { if (m.unite !== '') out.erreurs.push('Ligne ' + ln + ' : unité « ' + m.unite + ' » inconnue → m².'); m.unite = 'm²'; }
      if (m.pu !== '' && (!hasNum(m.pu) || num(m.pu) < 0)) return out.erreurs.push('Ligne ' + ln + ' : prix unitaire invalide.');
      if (m.perte !== '' && (!hasNum(m.perte) || num(m.perte) < 0 || num(m.perte) > 100)) return out.erreurs.push('Ligne ' + ln + ' : perte invalide (0 à 100 %).');
      if (!urlOk(m.fiche_url)) return out.erreurs.push('Ligne ' + ln + ' : lien de fiche non http(s).');
      if (!dateOk(m.fiche_date) || !dateOk(m.fiche_fin)) return out.erreurs.push('Ligne ' + ln + ' : date invalide (AAAA-MM-JJ).');
      if (STAT.every(function (x) { return x[0] !== m.statut; })) m.statut = (STAT.filter(function (x) { return x[1].toLowerCase() === m.statut.toLowerCase(); })[0] || ['a_valider'])[0];
      m.pu = m.pu === '' ? '' : num(m.pu); m.perte = m.perte === '' ? '' : num(m.perte);
      if (m.code) { if (seen[m.code.toLowerCase()]) return out.erreurs.push('Ligne ' + ln + ' : code « ' + m.code + ' » en double dans le fichier.'); seen[m.code.toLowerCase()] = 1; if (byCode[m.code.toLowerCase()]) { m.__id = byCode[m.code.toLowerCase()].id; out.maj++; } else out.nouveaux++; } else out.nouveaux++;
      out.items.push(m);
    });
    return out;
  }

  /* ================= INTERFACE ================= */
  function pname() { var n = ''; projs().forEach(function (p) { if (String(p.id) === String(st.pid)) n = p.nom || p.name || p.titre || p.title || ''; }); return n; }
  function mats() { return load().filter(function (x) { return x.type === 'mat'; }); }
  function specs() { return load().filter(function (x) { return x.type === 'spec' && String(x.project) === String(st.pid); }); }
  function rooms() { try { var items = (w.EXBS.get(KP) || []).filter(function (x) { return String(x.project) === String(st.pid); }); return w.EXBARCP && w.EXBARCP.calc ? w.EXBARCP.calc(items, 'base').rows : []; } catch (e) { return []; } }
  function edit(fn) { if (!canW()) { say('Écriture non autorisée.', 'error'); return false; } var all = load(); if (fn(all) === false) return false; save(all); return true; }
  function open() {
    if (!canR()) return say('Accès non autorisé.', 'error');
    if (!st.pid) { var P = projs(); st.pid = (function () { try { return localStorage.getItem('exb_active_project'); } catch (e) { return ''; } })() || (P[0] && P[0].id) || ''; }
    draw();
  }
  function inp(v, ev, ex, type) { return '<input ' + (type ? 'type="' + type + '" ' : '') + 'value="' + esc(v == null ? '' : v) + '" onchange="' + ev + '" style="padding:5px;width:100%;box-sizing:border-box;' + (ex || '') + '"' + (canW() ? '' : ' disabled') + '>'; }
  function selo(list, cur, ev, ex) { return '<select onchange="' + ev + '" style="padding:5px;' + (ex || '') + '"' + (canW() ? '' : ' disabled') + '>' + list.map(function (o) { o = Array.isArray(o) ? o : [o, o]; return '<option value="' + esc(o[0]) + '"' + (o[0] === cur ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select>'; }
  function btn(t, fn, extra) { return '<button onclick="' + fn + '" style="padding:7px 10px;' + (extra || '') + '">' + t + '</button>'; }
  function kpi(l, v) { return '<div style="background:#f1f5f9;border-radius:10px;padding:8px 10px;min-width:120px"><div style="font-size:11px;color:#64748b">' + l + '</div><b>' + v + '</b></div>'; }
  function draw() {
    var o = d.getElementById('exbMat');
    if (!o) { o = d.createElement('div'); o.id = 'exbMat'; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:8px;overflow:auto'; o.onclick = function (e) { if (e.target === o) o.remove(); }; d.body.appendChild(o); }
    var P = projs(), tabs = [['specs', '🎨 Spécifications & coûts'], ['bib', '📚 Bibliothèque'], ['cahier', '📋 Cahier des finitions']].map(function (t) { return '<button onclick="EXBMAT.tab(\'' + t[0] + '\')" style="padding:8px 10px;border:0;border-radius:8px;background:' + (st.tab === t[0] ? '#173565;color:#fff' : '#e2e8f0;color:#172033') + '">' + t[1] + '</button>'; }).join(' ');
    var h = '<div style="background:#fff;border-radius:14px;padding:14px;max-width:1180px;width:100%;font:14px Arial;color:#172033"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">🎨 Architecture — matériaux et finitions</b><button onclick="document.getElementById(\'exbMat\').remove()" style="padding:6px 10px">✕</button></div>'
      + (st.tab === 'bib' ? '' : '<p><select onchange="EXBMAT.proj(this.value)" style="padding:8px;max-width:100%">' + (P.length ? '' : '<option value="">— aucun projet —</option>') + P.map(function (p) { return '<option value="' + esc(p.id) + '"' + (String(p.id) === String(st.pid) ? ' selected' : '') + '>' + esc(p.nom || p.name || p.titre || p.title || p.id) + '</option>'; }).join('') + '</select></p>') + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">' + tabs + '</div>';
    h += st.tab === 'bib' ? tabBib() : !st.pid ? '<p>Créez d’abord un projet.</p>' : st.tab === 'specs' ? tabSpecs() : tabCahier();
    o.innerHTML = h + '<p style="font-size:11px;color:#64748b;margin-top:10px">Aide à la prescription : prix unitaires, performances et fiches techniques sont ceux que vous saisissez ; les coûts sont INDICATIFS (hors pose, hors aléas, hors taxes sauf indication) et ne remplacent ni un devis ni un métré contractuel.</p></div>';
  }
  function tabBib() {
    var L = mats().filter(function (m) { var q = st.q.toLowerCase(); return (!st.fam || m.famille === st.fam) && (!q || (m.nom + ' ' + (m.code || '') + ' ' + (m.fournisseur || '')).toLowerCase().indexOf(q) >= 0); }), now = today();
    var h = '<p style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">' + (canW() ? btn('➕ Matériau', 'EXBMAT.addMat()') + '<label style="padding:7px 10px;background:#e2e8f0;border-radius:6px;cursor:pointer">⬆ Importer CSV<input type="file" accept=".csv,.txt" style="display:none" onchange="EXBMAT.importBib(this)"></label>' : '') + btn('⬇ CSV', 'EXBMAT.exportBib()')
      + '<input placeholder="Rechercher…" value="' + esc(st.q) + '" onchange="EXBMAT.setQ(this.value)" style="padding:6px"> ' + selo([['', 'Toutes familles']].concat(FAM), st.fam, 'EXBMAT.setFam(this.value)') + '</p>';
    if (!L.length) return h + '<p>' + (mats().length ? 'Aucun résultat.' : 'Bibliothèque vide. Ajoutez vos matériaux ou importez un CSV (colonnes : ' + COLS.join('; ') + ').') + '</p>';
    h += '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12px"><tr style="background:#f1f5f9;text-align:left"><th>Code</th><th>Désignation</th><th>Famille</th><th>Unité</th><th>PU indicatif</th><th>Perte %</th><th>Fournisseur</th><th>Fiche réf.</th><th>Lien fiche</th><th>Fin validité</th><th>Statut</th><th>Performances</th><th></th></tr>';
    L.forEach(function (m) {
      var e = function (k, ex, ty) { return '<td>' + inp(m[k], 'EXBMAT.setMat(\'' + m.id + '\',\'' + k + '\',this.value)', ex, ty) + '</td>'; }, per = m.fiche_fin && m.fiche_fin < now;
      h += '<tr style="border-top:1px solid #e2e8f0' + (m.statut === 'obsolete' ? ';opacity:.55' : '') + '">' + e('code', 'width:70px') + e('nom', 'min-width:150px') + '<td>' + selo(FAM, m.famille, 'EXBMAT.setMat(\'' + m.id + '\',\'famille\',this.value)') + '</td><td>' + selo(UNITES, m.unite, 'EXBMAT.setMat(\'' + m.id + '\',\'unite\',this.value)') + '</td>' + e('pu', 'width:80px') + e('perte', 'width:55px') + e('fournisseur') + e('fiche_ref') + '<td style="min-width:120px">' + inp(m.fiche_url, 'EXBMAT.setMat(\'' + m.id + '\',\'fiche_url\',this.value)') + (m.fiche_url && urlOk(m.fiche_url) ? '<a href="' + esc(m.fiche_url) + '" target="_blank" rel="noopener noreferrer">ouvrir</a>' : '') + '</td><td>' + inp(m.fiche_fin, 'EXBMAT.setMat(\'' + m.id + '\',\'fiche_fin\',this.value)', per ? 'border:1px solid #dc2626' : '', 'date') + '</td><td>' + selo(STAT, m.statut, 'EXBMAT.setMat(\'' + m.id + '\',\'statut\',this.value)') + '</td>' + e('perfs', 'min-width:150px') + '<td>' + (canW() ? btn('⧉', 'EXBMAT.dup(\'' + m.id + '\')', 'padding:4px 6px') + btn('🗑', 'EXBMAT.delMat(\'' + m.id + '\')', 'padding:4px 6px') : '') + '</td></tr>';
    });
    return h + '</table></div>';
  }
  function tabSpecs() {
    var M = mats(), S = specs(), RM = rooms(), C = calcul(M, S, RM), h = '';
    h += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0">' + kpi('Lignes', S.length) + kpi('Coût indicatif', fm(C.total, 0)) + kpi('Sans prix', C.sansPrix + (S.length ? ' (' + fm(C.partSansPrix, 0) + ' %)' : '')) + kpi('Lignes à contrôler', C.alertes) + '</div>';
    if (C.sansPrix) h += '<div style="background:#fff7ed;border:1px solid #fdba74;border-radius:8px;padding:6px 8px;margin:4px 0;font-size:13px">⚠ ' + C.sansPrix + ' ligne(s) sans prix : le total est PARTIEL.</div>';
    h += (canW() ? '<p>' + btn('➕ Ligne de spécification', 'EXBMAT.addSpec()') + '</p>' : '');
    if (!M.length) return h + '<p>Renseignez d’abord la bibliothèque.</p>';
    if (!S.length) return h + '<p>Aucune ligne. ' + (RM.length ? RM.length + ' local(aux) disponible(s) depuis le tableau des surfaces.' : 'Aucun local dans le tableau des surfaces : vous pouvez saisir des quantités manuelles.') + '</p>';
    var mo = M.map(function (m) { return [m.id, (m.code ? m.code + ' · ' : '') + m.nom]; }), lo = [['', '— zone libre —']].concat(RM.map(function (r) { return [r.id, (r.niveau ? r.niveau + ' · ' : '') + r.nom]; }));
    h += '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12px"><tr style="background:#f1f5f9;text-align:left"><th>Poste</th><th>Local</th><th>Matériau</th><th>Mode</th><th>Coef. / Qté</th><th>Perte %</th><th>Qté majorée</th><th>PU</th><th>Coût</th><th>Statut</th><th></th></tr>';
    C.lignes.forEach(function (L, i) {
      var sp = S[i], id = sp.id, f = function (k) { return 'EXBMAT.setSpec(\'' + id + '\',\'' + k + '\',this.value)'; };
      h += '<tr style="border-top:1px solid #e2e8f0"><td>' + selo(POSTE, sp.poste || 'autre', f('poste')) + '</td><td>' + selo(lo, sp.local || '', f('local'), 'max-width:170px') + (sp.local ? '' : '<br>' + inp(sp.zone, f('zone'), '', '')) + '</td><td>' + selo([['', '— choisir —']].concat(mo), sp.mat || '', f('mat'), 'max-width:200px') + '</td><td>' + selo([['surface', 'Surface × coef.'], ['manuel', 'Quantité saisie']], L.mode, f('mode')) + '</td><td style="width:80px">' + (L.mode === 'surface' ? inp(sp.coef === undefined ? 1 : sp.coef, f('coef')) : inp(sp.qte, f('qte'))) + '</td><td style="width:60px">' + inp(sp.perte, f('perte'), '') + '</td><td>' + fm(L.qt, 2) + ' ' + esc(L.unite) + '</td><td>' + (L.pu === null ? '—' : fm(L.pu, 2)) + '</td><td><b>' + (L.cout === null ? '—' : fm(L.cout, 0)) + '</b></td><td>' + selo(SSTAT, sp.statut || 'propose', f('statut')) + '</td><td>' + (canW() ? btn('🗑', 'EXBMAT.delSpec(\'' + id + '\')', 'padding:4px 6px') : '') + '</td></tr>'
        + (L.alertes.length ? '<tr><td colspan="11" style="color:#9a3412;font-size:11px;padding:0 0 4px 8px">⚠ ' + L.alertes.map(esc).join(' · ') + '</td></tr>' : '');
    });
    h += '</table></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-top:10px"><div><b>Par poste</b>' + sumTable(C.lots, POSTE) + '</div><div><b>Par famille</b>' + sumTable(C.familles, FAM) + '</div></div>';
    return h + '<p>' + btn('⬇ CSV des spécifications', 'EXBMAT.csvSpecs()') + '</p>';
  }
  function sumTable(O, LST) { return '<table style="border-collapse:collapse;width:100%;font-size:12px">' + Object.keys(O).map(function (k) { return '<tr style="border-top:1px solid #e2e8f0"><td>' + esc(lab(LST, k)) + '</td><td style="text-align:right">' + O[k].n + ' l.</td><td style="text-align:right"><b>' + fm(O[k].cout, 0) + '</b>' + (O[k].sansPrix ? ' <span style="color:#9a3412" title="lignes sans prix">⚠</span>' : '') + '</td></tr>'; }).join('') + '</table>'; }
  function cahierData() { var C = calcul(mats(), specs(), rooms()), by = {}; C.lignes.forEach(function (L) { var k = L.local || '(sans local)'; (by[k] = by[k] || []).push(L); }); return { C: C, by: by }; }
  function tabCahier() {
    var D = cahierData(), keys = Object.keys(D.by);
    if (!keys.length) return '<p>Aucune spécification : le cahier se construit à partir de l’onglet « Spécifications &amp; coûts ».</p>';
    return '<p>' + btn('🖨 Imprimer le cahier', 'EXBMAT.print()') + '</p>' + keys.map(function (k) { return '<h3 style="margin:10px 0 4px">' + esc(k) + '</h3><table style="border-collapse:collapse;width:100%;font-size:13px"><tr style="background:#f1f5f9;text-align:left"><th>Poste</th><th>Matériau</th><th>Réf. fiche</th><th>Quantité</th><th>Coût indicatif</th></tr>' + D.by[k].map(function (L) { var m = mats().filter(function (x) { return x.id === L.matId; })[0] || {}; return '<tr style="border-top:1px solid #e2e8f0"><td>' + esc(lab(POSTE, L.lot)) + '</td><td>' + esc((L.code ? L.code + ' · ' : '') + L.mat) + '</td><td>' + esc(m.fiche_ref || '—') + '</td><td>' + fm(L.qt, 2) + ' ' + esc(L.unite) + '</td><td>' + (L.cout === null ? '—' : fm(L.cout, 0)) + '</td></tr>'; }).join('') + '</table>'; }).join('');
  }

  function dl(name, data, type) { try { var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: type })); a.download = name; d.body.appendChild(a); a.click(); a.remove(); } catch (x) { say('Export impossible.', 'error'); } }
  var NUMF = { pu: 1, perte: 1 };
  var API = {
    open: open, calcul: calcul, parseBib: parseBib, csvBib: csvBib, exportBib: function () { dl('bibliotheque-materiaux.csv', csvBib(mats()), 'text/csv;charset=utf-8'); }, urlOk: urlOk, csvCell: csvCell, splitCsv: splitCsv, FAM: FAM, POSTE: POSTE, UNITES: UNITES,
    proj: function (v) { st.pid = v; draw(); }, tab: function (t) { st.tab = t; draw(); }, setQ: function (v) { st.q = v; draw(); }, setFam: function (v) { st.fam = v; draw(); },
    addMat: function () { edit(function (a) { a.push({ id: uid('MA'), type: 'mat', code: '', nom: 'Nouveau matériau', famille: st.fam || 'sol', unite: 'm²', pu: '', perte: '', fournisseur: '', fiche_ref: '', fiche_url: '', fiche_date: '', fiche_fin: '', statut: 'a_valider', perfs: '', notes: '', maj: today(), par: who() }); }); draw(); },
    dup: function (id) { edit(function (a) { var m = a.filter(function (x) { return x.id === id; })[0]; if (!m) return false; a.push(Object.assign({}, m, { id: uid('MA'), code: '', nom: m.nom + ' (copie)', statut: 'a_valider', maj: today(), par: who() })); }); draw(); },
    delMat: async function (id) { if (!canW()) return; var used = load().filter(function (x) { return x.type === 'spec' && x.mat === id; }).length; if (!(await (w.exbConfirm||function(a,b){return w['confirm'](a,b)})(used ? 'Ce matériau est utilisé par ' + used + ' ligne(s) de spécification (elles resteront, signalées « introuvable »). Supprimer ?' : 'Supprimer ce matériau ?'))) return; edit(function (a) { var i = a.findIndex(function (x) { return x.id === id; }); if (i < 0) return false; a.splice(i, 1); }); draw(); },
    setMat: function (id, k, v) {
      if (COLS.indexOf(k) < 0) return;
      if (NUMF[k] && v !== '' && (!hasNum(v) || num(v) < 0 || (k === 'perte' && num(v) > 100))) { say(k === 'perte' ? 'Perte : 0 à 100 %.' : 'Prix : nombre positif attendu.', 'error'); return setTimeout(draw, 0); }
      if (k === 'fiche_url' && !urlOk(v)) { say('Le lien doit commencer par http:// ou https://.', 'error'); return setTimeout(draw, 0); }
      if (/fiche_(date|fin)/.test(k) && !dateOk(v)) { say('Date invalide.', 'error'); return setTimeout(draw, 0); }
      if (k === 'code' && v.trim() && mats().some(function (m) { return m.id !== id && (m.code || '').toLowerCase() === v.trim().toLowerCase(); })) { say('Ce code existe déjà.', 'error'); return setTimeout(draw, 0); }
      edit(function (a) { var m = a.filter(function (x) { return x.id === id; })[0]; if (!m) return false; m[k] = NUMF[k] ? (v === '' ? '' : num(v)) : s(v, k === 'nom' ? 160 : 400); m.maj = today(); m.par = who(); }); setTimeout(draw, 0);
    },
    addSpec: function () { edit(function (a) { a.push({ id: uid('SP'), type: 'spec', project: st.pid, poste: 'sol', local: '', zone: '', mat: '', mode: 'surface', coef: 1, qte: '', perte: '', statut: 'propose', note: '' }); }); draw(); },
    delSpec: function (id) { if (!canW()) return; edit(function (a) { var i = a.findIndex(function (x) { return x.id === id; }); if (i < 0) return false; a.splice(i, 1); }); draw(); },
    setSpec: function (id, k, v) {
      if (['poste', 'local', 'zone', 'mat', 'mode', 'coef', 'qte', 'perte', 'statut', 'note'].indexOf(k) < 0) return;
      if (['coef', 'qte', 'perte'].indexOf(k) >= 0 && v !== '' && (!hasNum(v) || num(v) < 0)) { say('Nombre positif attendu.', 'error'); return setTimeout(draw, 0); }
      edit(function (a) { var sp = a.filter(function (x) { return x.id === id; })[0]; if (!sp) return false; sp[k] = ['coef', 'qte', 'perte'].indexOf(k) >= 0 ? (v === '' ? '' : num(v)) : s(v, 160); }); setTimeout(draw, 0);
    },
    importBib: function (el) {
      var f = el.files && el.files[0]; el.value = ''; if (!f || !canW()) return; if (f.size > 2097152) return say('Fichier trop volumineux (2 Mo max).', 'error');
      var rd = new FileReader(); rd.onload = async function () {
        var p = parseBib(String(rd.result), mats()); if (p.erreurs.length) say(p.erreurs.length + ' problème(s) : ' + p.erreurs.slice(0, 3).join(' | ') + (p.erreurs.length > 3 ? ' …' : ''), 'error');
        if (!p.items.length) return;
        if (!(await (w.exbConfirm||function(a,b){return w['confirm'](a,b)})('Importer ' + p.items.length + ' matériau(x) : ' + p.nouveaux + ' nouveau(x), ' + p.maj + ' mis à jour (même code) ?'))) return;
        edit(function (a) { p.items.forEach(function (m) { var id = m.__id; delete m.__id; var ex = id && a.filter(function (x) { return x.id === id; })[0]; if (ex) Object.assign(ex, m, { maj: today(), par: who() }); else a.push(Object.assign({ id: uid('MA'), type: 'mat', maj: today(), par: who() }, m)); }); }); say(p.items.length + ' matériau(x) importé(s).'); draw();
      }; rd.readAsText(f);
    },
    csvSpecs: function () {
      var C = calcul(mats(), specs(), rooms()), rows = [['Poste', 'Local', 'Niveau', 'Code', 'Matériau', 'Unité', 'Quantité', 'Perte %', 'Quantité majorée', 'PU indicatif', 'Coût indicatif', 'Statut', 'Alertes']].concat(C.lignes.map(function (L) { return [lab(POSTE, L.lot), L.local, L.niveau, L.code, L.mat, L.unite, L.q.toFixed(2), L.perte, L.qt.toFixed(2), L.pu === null ? '' : L.pu, L.cout === null ? '' : L.cout.toFixed(2), lab(SSTAT, L.statut), L.alertes.join(' / ')]; }));
      rows.push([], ['Total indicatif (hors lignes sans prix)', '', '', '', '', '', '', '', '', '', C.total.toFixed(2)]);
      dl('specifications-materiaux.csv', '﻿' + rows.map(function (r) { return r.map(csvCell).join(';'); }).join('\r\n'), 'text/csv;charset=utf-8');
    },
    print: function () {
      var D = cahierData(), win = (w.EXBPOP ? w.EXBPOP.open() : w.open('', '_blank')); if (!win) return say('Autorisez les fenêtres pour imprimer.', 'error');
      win.document.write((w.EXBENT ? w.EXBENT.wrap : function (h) { return h; })('<html><head><meta charset="utf-8"><title>Cahier des finitions</title><style>body{font:12px Arial;margin:20px}table{border-collapse:collapse;width:100%;margin-bottom:10px}td,th{border:1px solid #999;padding:3px 7px;text-align:left}</style></head><body><h2>Cahier des finitions — ' + esc(pname()) + '</h2><p>Édité le ' + new Date().toLocaleDateString('fr-FR') + ' par ' + esc(who() || '—') + '</p>'
        + Object.keys(D.by).map(function (k) { return '<h3>' + esc(k) + '</h3><table><tr><th>Poste</th><th>Matériau</th><th>Fiche technique</th><th>Quantité</th><th>Coût indicatif</th><th>Statut</th></tr>' + D.by[k].map(function (L) { var m = mats().filter(function (x) { return x.id === L.matId; })[0] || {}; return '<tr><td>' + esc(lab(POSTE, L.lot)) + '</td><td>' + esc((L.code ? L.code + ' · ' : '') + L.mat) + '</td><td>' + esc(m.fiche_ref || '—') + '</td><td>' + fm(L.qt, 2) + ' ' + esc(L.unite) + '</td><td>' + (L.cout === null ? '—' : fm(L.cout, 0)) + '</td><td>' + esc(lab(SSTAT, L.statut)) + '</td></tr>'; }).join('') + '</table>'; }).join('')
        + '<p><b>Total indicatif : ' + fm(D.C.total, 0) + '</b>' + (D.C.sansPrix ? ' (partiel : ' + D.C.sansPrix + ' ligne(s) sans prix)' : '') + '</p><p style="font-size:11px">Coûts indicatifs d’après les prix unitaires saisis dans la bibliothèque ; ne remplacent ni un devis ni un métré contractuel.</p></body></html>', { prefix: 'MAT', sub: 'Matériaux et finitions' })); win.document.close(); win.focus(); setTimeout(function () { win.print(); }, 300);
    }
  };
  w.EXBMAT = API;

  function ui() {
    var b = d.getElementById('exbArcPBtn') || d.getElementById('exbArcBtn'); /* V215 : repli si « Programme & surfaces » (V209e) n'est pas installé */ if (!b || d.getElementById('exbMatBtn')) return;
    var k = d.createElement('button'); k.id = 'exbMatBtn'; k.className = 'muted'; k.textContent = '🎨 Matériaux & finitions'; k.onclick = open; if (!canR()) k.setAttribute('data-exbrole', 'hide'); b.parentNode.appendChild(k);
  }
  if (d.documentElement && w.MutationObserver) { new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true }); d.addEventListener('DOMContentLoaded', ui); }
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { documentElement: null, getElementById: function () { return null; }, addEventListener: function () { } });
