# V245u — PDF du moteur documentaire : un seul en-tête, un seul QR ; logo et nom agrandis sur tous les PDF

Fichiers modifiés : `docengine/bridge.js`, `exb-rapport-marque.js`, `exb-bi.js`, `sw.js` (étiquette de cache). Aucune migration SQL.

**Cause.** Le PDF « Planning des séances » (modèle `planning-seances` du moteur documentaire) sortait avec deux en-têtes et deux QR : le sien (`<header class="lh">` + bloc `doc-qr`) et l'habillage commun ajouté par le pont (`bridge.js`). Le pont aurait dû reconnaître que le document avait déjà son en-tête, mais le logo en base64 (> 60 000 caractères) coupait la balise `<img>` dans la fenêtre d'analyse : le nom de l'entreprise n'était plus vu, d'où le doublon. Le QR en trop passait aussi sur une 2e page.

**Correction.**
- `bridge.js` : les données image (base64) sont retirées avant l'analyse (détection fiable de l'en-tête propre) ; pour un document du moteur documentaire, l'en-tête et le QR propres sont retirés et seuls restent l'en-tête commun (celui du modèle « Rappel ») et le QR de vérification en bas, comme les autres PDF.
- En-tête commun agrandi : logo 26 mm de haut (largeur max 38 mm, proportions respectées), nom 21 px, slogan 12 px — même taille de logo que l'ancien second en-tête. Appliqué à `exb-rapport-marque.js` (tous les rapports, plannings Gantt, QCM, paiements, plans, bulletins…), `exb-bi.js` (rapports BI) et au bandeau de repli de `bridge.js`.

**Vérifié.** Planning généré puis converti en PDF A4 paysage : 1 page, 1 en-tête (logo + nom agrandis), 1 QR en bas. Tests `tools/test-rapport-marque-v177.js` (15) et `tools/test-qr-partout-v178.js` (23) : OK, identiques à avant.
**Pas modifié** : les pièces qui ont leur mise en page propre (en-tête d'ingénierie V221 déjà à 78 px, reçus, certificats, plans) gardent leur forme.
