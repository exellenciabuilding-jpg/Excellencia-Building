# V245h — Seuils de validation (contrôle par montant)

> Correctif V245h : la variable `strict` (mot réservé PostgreSQL) est renommée `sans_seuil` dans `seuil_ok()`. Cela corrige l’erreur « 42601 syntax error at or near "strict" ». Aucun autre changement.

Fichier SQL à exécuter (après v245d) : `supabase/migration-v245e-seuils-validation.sql`

## Ce que ça fait
Au-delà d'un montant, une fiche ne peut passer à « approuvé / validé / accepté / signé… » que si la personne est **administrateur** ou de la **Direction**. En dessous du seuil, rien ne change. Le contrôle est fait par le serveur (on ne peut pas le contourner depuis l'appli). Tout refus est écrit dans le journal (« refus seuil de validation »).

## Seuils de départ (modifiables)
| Fiche | Seuil USD | Seuil CDF | Seuil EUR |
|---|---|---|---|
| Devis | 5 000 | 12 500 000 | 5 000 |
| Engagements de dépense | 1 000 | 2 500 000 | 1 000 |

Les bons de paiement (paiements reçus des clients) ne sont pas concernés. Commandes fournisseurs et règlements : à ajouter quand leurs champs seront confirmés.

## Changer un seuil (administrateur connecté)
`select definir_seuil('<id organisation>', 'devis', 'USD', 10000);`
Désactiver : `select definir_seuil('<id organisation>', 'engagements', 'USD', 1000, false);`

## Retour arrière
Réexécuter `migration-v245-fonctions-export-perimetre.sql`.

## À vérifier à la recette
Après exécution, 3 lignes V245e-a/b/c doivent afficher OK. Tester avec un compte non-Direction : approuver un devis de 6 000 USD doit être refusé ; 4 000 USD doit passer.
Non testé contre un vrai Supabase (pas d'accès depuis ici) : à essayer d'abord sur la copie de recette.
