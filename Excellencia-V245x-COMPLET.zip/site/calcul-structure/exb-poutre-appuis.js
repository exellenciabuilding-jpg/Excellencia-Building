/* V245k — Module 2/4 « poutres continues » : aciers de chapeaux sur appuis intermédiaires.
   Fonctions pures (navigateur : window.EXBPA ; Node : require). Dépend de exb-poutre-continue.js (EXBPCONT).
   Unités : cm pour la section, MPa, kN.m pour les moments, cm² pour les aciers.
   Flexion ELUR rectangulaire BAEL (mêmes formules que exb-etudes.js : fbu, μ critique, pivots A/B, z = d(1 − 0,4α)).
   Sur appui, la fibre comprimée est en bas : section rectangulaire b0 × h (la table de la poutre en té est tendue, elle ne contribue pas à la compression).
   Moment de calcul : par défaut le moment à l'AXE de l'appui (prudent). Si ecreter = true ET la largeur du poteau a_j est renseignée,
   le moment est pris à la FACE du poteau (x = a_j/2 de l'axe), avec le schéma de charge exact qui maximise le moment d'appui, du côté le moins réduit.
   V245o :
   • Lits multiples : si les barres ne tiennent pas en un lit, elles sont réparties en lits (espace libre horizontal et vertical = max(Ø ; 2,5 cm)),
     d est ramené au centre de gravité réel et le calcul est repris. d n'est jamais augmenté au-dessus de la valeur de départ.
     Au-delà de 2 lits : alerte. Plus de 3 lits, ou moins de 2 barres par lit : section refusée (ok = false).
   • Té sur appui (b et h0 renseignés) : As,min = 0,23·(ftj/fe)·b0·d × (I/v)té / (b0·h²/6), v = distance du centre de gravité à la fibre tendue (haute).
     C'est la non-fragilité (moment de fissuration) ; sans table, on retrouve la formule rectangulaire.
   • Plancher à la face (désactivé par défaut) : plancherFace = 0,65 impose Mface ≥ 0,65·q·l²/12 (EN 1992-1-1, 5.3.2.2(3), note ; règle Eurocode, non BAEL).
     l = entraxe des appuis (≥ portée nue, donc du côté de la sécurité) ; le moment retenu ne dépasse jamais le moment à l'axe.
   Limites : lits calculés avec un seul diamètre ; largeur de table b fournie par l'utilisateur ; ancrage et arrêts des chapeaux : module 3.
   Calcul d'aide à l'étude : à faire vérifier par un ingénieur. */
(function (root) {
  "use strict";
  const PC = (typeof require === "function" && typeof module !== "undefined") ? require("./exb-poutre-continue.js") : root.EXBPCONT;
  const FISS = ["peu préjudiciable", "préjudiciable", "très préjudiciable"];

  /* ---------- matériaux / flexion (reprise de exb-etudes.js) ---------- */
  const theta = t => (t === "t < 1 h" ? 0.85 : t === "1 h ≤ t ≤ 24 h" ? 0.9 : 1);
  function muCrit(gam, fc, fe, th) {
    if (fc > 30 || (fe !== 500 && fe !== 400)) return null;
    const k = fe === 500 ? [0.322, 0.0051, 0.31] : [0.344, 0.0049, 0.305];
    return (k[0] * gam + k[1] * fc - k[2]) * (1 - (1 - th) / 8.5) * th;
  }
  /* Mu en kN.m, bw et d en cm */
  function flex(Mu, bw, d, fc, fe, th, gam) {
    const fbu = 0.85 * fc / (1.5 * th), fsu = fe / 1.15, mu = Mu * 1e-3 / ((bw / 100) * Math.pow(d / 100, 2) * fbu);
    let mc = muCrit(gam, fc, fe, th), gen = false;
    if (mc == null) { const al = 3.5 / (3.5 + 1000 * fsu / 200000); mc = 0.8 * al * (1 - 0.4 * al); gen = true; }
    const r = { mu, mc, gen, fbu, fsu, piv: mu <= 0.186 ? "A" : "B", ok: mu <= 0.186 || mu <= mc };
    if (r.ok) { r.al = 1.25 * (1 - Math.sqrt(1 - 2 * mu)); r.z = d * (1 - 0.4 * r.al); r.As = Mu * 1e-3 / (fsu * r.z / 100) * 1e4; }
    return r;
  }
  function barres(As, min, d0) {
    const D = [10, 12, 14, 16, 20, 25, 32].filter(x => x >= (d0 || 12));
    for (let i = 0; i < D.length; i++) { const a = Math.PI * D[i] * D[i] / 400, k = Math.max(min || 2, Math.ceil(As / a - 1e-9)); if (k <= 8 || i === D.length - 1) return { n: k, d: D[i], as: k * a }; }
  }

  /* ---------- ELS (reprise de exb-etudes.js) : contrainte limite de l'acier, section d'acier ELS, contraintes de la section choisie ---------- */
  function limAcier(fc, fe, fs) {
    const ftj = 0.6 + 0.06 * fc;
    return fs === "peu préjudiciable" ? fe : fs === "très préjudiciable" ? Math.min(0.5 * fe, 90 * Math.sqrt(1.6 * ftj)) : Math.min(2 * fe / 3, 110 * Math.sqrt(1.6 * ftj));
  }
  function aserELS(Ms, b, d, fc, fe, fs) {
    const sst = limAcier(fc, fe, fs), sbc = 0.6 * fc, al = 15 * sbc / (15 * sbc + sst), A0 = Ms * 1e-3 / (sst * (d - al * d / 3) / 100) * 1e4, y = (-15 * A0 + Math.sqrt(225 * A0 * A0 + 30 * A0 * b * d)) / b;
    return Ms * 1e-3 / (sst * (d - y / 3) / 100) * 1e4;
  }
  function els(Ms, b, d, As, fc, fe, fs) {
    const y1 = (-15 * As + Math.sqrt(225 * As * As + 30 * As * b * d)) / b, I1 = b * y1 * y1 * y1 / 3 + 15 * As * Math.pow(d - y1, 2);
    return { y1, sb: Ms * 1000 * y1 / I1, ss: 15 * Ms * 1000 * (d - y1) / I1, sbl: 0.6 * fc, ssl: limAcier(fc, fe, fs) };
  }

  /* ---------- moment d'appui à l'axe et à la face du poteau ---------- */
  /* res : résultat de EXBPC.analyse ; j : appui intérieur (1 … n−1) ; a : largeur du poteau (cm, 0 = non renseignée) ; gG, gQ : coefficients.
     Retourne { axe, face, reduction } en kN.m, moments négatifs exprimés en valeur absolue (« hogging »). */
  function momentAppui(res, j, a, gG, gQ) {
    const n = res.n, Ls = res.Ls, q = Ls.map((_, i) => gG * res.G[i] + (res.cas.Q[i].Ma[j] < 0 ? gQ * res.Q[i] : 0));
    const c = PC.cas(Ls, res.EI, q, 4), axe = -c.Ma[j];
    if (!(a > 0)) return { axe, face: axe, reduction: 0, q };
    const s = a / 200;                                        /* demi-largeur du poteau (m) */
    if (s >= Math.min(Ls[j - 1], Ls[j]) / 2) return { axe, face: axe, reduction: 0, q, erreur: "Largeur de poteau incompatible avec les portées voisines." };
    const Ms = c.Ma, Vl = i => (Ms[i + 1] - Ms[i]) / Ls[i] + q[i] * Ls[i] / 2;
    const Mdr = Ms[j] + Vl(j) * s - q[j] * s * s / 2, xg = Ls[j - 1] - s, Mgc = Ms[j - 1] + Vl(j - 1) * xg - q[j - 1] * xg * xg / 2;
    const face = Math.max(-Mdr, -Mgc);                        /* côté le moins réduit = le plus défavorable */
    return { axe, face: Math.min(axe, face), reduction: axe > 0 ? 1 - Math.min(axe, face) / axe : 0, q };
  }

  /* ---------- disposition en lits ----------
     n barres de diamètre d (mm) ; b0, h, enr en cm ; dt (mm). Retourne null si moins de 2 barres tiennent par lit.
     yg : distance du centre de gravité à la fibre tendue ; d : hauteur utile réelle (cm). */
  function lits(n, dia, b0, h, enr, dt) {
    const f = dia / 10, e = Math.max(f, 2.5), larg = b0 - 2 * enr - 2 * dt / 10, par = Math.floor((larg + e) / (f + e) + 1e-9);
    if (par < 2) return null;
    const rep = []; let reste = n, somme = 0;
    while (reste > 0) { const k = Math.min(par, reste); somme += k * (enr + dt / 10 + f / 2 + rep.length * (f + e)); rep.push(k); reste -= k; }
    const yg = somme / n;
    return { nb: rep.length, rep, par, e, larg, yg, d: h - yg };
  }
  /* choix des barres : le choix habituel s'il tient en 2 lits au plus, sinon un diamètre supérieur qui réduit le nombre de lits */
  function disposer(As, b0, h, enr, dt) {
    const base = barres(As, 2), cand = [base];
    [12, 14, 16, 20, 25, 32].filter(x => x > base.d).forEach(x => { const a = Math.PI * x * x / 400, k = Math.max(2, Math.ceil(As / a - 1e-9)); cand.push({ n: k, d: x, as: k * a }); });
    let best = null;
    for (const B of cand) {
      const L = lits(B.n, B.d, b0, h, enr, dt);
      if (!L) continue;
      if (L.nb <= 2) return { B, L };
      if (!best || L.nb < best.L.nb) best = { B, L };
    }
    return best || { B: base, L: null };
  }

  /* ---------- section en té : rapport des modules d'inertie (fibre haute tendue) té / rectangle b0 × h ---------- */
  function coefTe(b0, h, b, h0) {
    if (!(b > b0 && h0 > 0 && h0 < h)) return { k: 1, te: false };
    const sa = (b - b0) * h0, A = b0 * h + sa, v = (b0 * h * h / 2 + sa * h0 / 2) / A;
    const I = b0 * h * h * h / 12 + b0 * h * Math.pow(h / 2 - v, 2) + (b - b0) * h0 * h0 * h0 / 12 + sa * Math.pow(v - h0 / 2, 2);
    return { k: (I / v) / (b0 * h * h / 6), te: true, v, I };
  }

  /* ---------- plancher à la face : ratio × moment d'encastrement parfait q·l²/12 (le plus grand des deux travées voisines) ---------- */
  function plancher(m, Ls, j, ratio) {
    const min = ratio * Math.max(m.q[j - 1] * Ls[j - 1] * Ls[j - 1], m.q[j] * Ls[j] * Ls[j]) / 12;
    const val = Math.min(m.axe, Math.max(m.face, min));
    return { min, val, actif: val > m.face + 1e-9 };
  }

  /* ---------- chapeaux ----------
     o : { res, b0, h (cm), enr = 3 (cm), fc, fe, t, fiss, colonnes:[a_j cm pour j = 0 … n], ecreter = false, plancherFace = 0 (ratio, ex. 0.65), b, h0 (cm, table du té, facultatifs), d (cm, facultatif), dt = 8 (mm, diamètre du cadre) } */
  function chapeaux(o) {
    const W = [], res = o && o.res;
    if (!res || !res.n || (res.erreurs && res.erreurs.length)) return { appuis: [], warn: ["Analyse de la poutre continue absente ou invalide."] };
    const b0 = +o.b0, h = +o.h, c = o.enr == null ? 3 : +o.enr, fc = +o.fc, fe = +o.fe, th = theta(o.t), fs = o.fiss || FISS[0], dt = o.dt == null ? 8 : +o.dt;
    if (!(b0 > 0 && h > 0 && fc > 0 && fe > 0)) return { appuis: [], warn: ["Renseignez la section (b0, h) et les matériaux (fc28, fe)."] };
    const d0 = o.d > 0 ? +o.d : Math.min(0.9 * h, h - c - 3), ftj = 0.6 + 0.06 * fc;
    const T = coefTe(b0, h, +o.b || 0, +o.h0 || 0), rp = +o.plancherFace > 0 ? Math.min(1, +o.plancherFace) : 0;
    if (+o.b > b0 && !T.te) W.push("Table du té ignorée : renseigner une épaisseur h0 comprise entre 0 et h.");
    const sbl = 0.6 * fc, ssl = limAcier(fc, fe, fs), appuis = [];
    for (let j = 1; j < res.n; j++) {
      const av = [], a = (o.colonnes && +o.colonnes[j]) || 0, ec = !!o.ecreter && a > 0;
      const mu = momentAppui(res, j, ec ? a : 0, res.gG, res.gQ), ms = momentAppui(res, j, ec ? a : 0, 1, 1);
      if (mu.erreur) av.push(mu.erreur);
      let Mu = ec ? mu.face : mu.axe, Ms = ec ? ms.face : ms.axe, Pu = null;
      if (ec && rp && !mu.erreur) {
        Pu = plancher(mu, res.Ls, j, rp); const Ps = plancher(ms, res.Ls, j, rp); Mu = Pu.val; Ms = Ps.val;
        if (Pu.actif) av.push("Appui " + j + " : plancher à la face appliqué (" + Mu.toFixed(1) + " kN.m au lieu de " + mu.face.toFixed(1) + ").");
      }
      const gam = Ms > 0 ? Mu / Ms : 1.4;
      const out = { j, a, ecrete: ec, Ma_axe: mu.axe, Ma_face: mu.face, reduction: mu.reduction, reductionRetenue: mu.axe > 0 ? 1 - Mu / mu.axe : 0, plancher: Pu, Mu, Ms, gam, d: d0, avert: av };
      if (!(Mu > 1e-9)) { Object.assign(out, { As: 0, Au: 0, Amin: 0, Ase: 0, barres: null, lits: null }); av.push("Moment d'appui nul : aucun chapeau de calcul (disposer un minimum constructif)."); appuis.push(out); continue; }
      /* itération : d ne peut que diminuer, jusqu'à ce que la hauteur utile réelle des barres choisies soit ≥ d de calcul */
      let d = d0, f, Au, Amin, Ase, As, S, conv = false;
      for (let it = 0; it < 20; it++) {
        f = flex(Mu, b0, d, fc, fe, th, gam);
        if (!f.ok) break;
        /* Amin : rectangle b0 × h (formule du classeur), majoré par le rapport I/v quand la table du té, tendue, est renseignée */
        Au = f.As; Amin = ftj / fe * 0.23 * d * b0 * T.k;
        Ase = fs !== "peu préjudiciable" ? aserELS(Ms, b0, d, fc, fe, fs) : 0;
        As = Math.max(Au, Ase, Amin); S = disposer(As, b0, h, c, dt);
        if (!S.L || S.L.d >= d - 1e-6) { conv = true; break; }
        if (!(S.L.d > 0)) break;
        d = S.L.d;
      }
      out.flex = f; out.d = d;
      if (!f.ok) { out.As = NaN; out.barres = null; out.lits = null; out.ok = false; av.push("Appui " + j + " : μ = " + f.mu.toFixed(3) + " > μ critique " + f.mc.toFixed(3) + (d < d0 ? " (avec d = " + d.toFixed(1) + " cm après mise en lits)" : "") + " : section de béton insuffisante, augmenter b0 ou h."); appuis.push(out); continue; }
      if (f.gen) av.push("fc28 > 30 MPa : μ critique par la formule générale, à vérifier.");
      const B = S.B, L = S.L, Ac = B.as, e = els(Ms, b0, d, Ac, fc, fe, fs), sb = e.sb, ss = e.ss;
      if (As === Amin) av.push("Appui " + j + " : condition de non-fragilité (As,min) imposée.");
      if (sb > sbl) av.push("Appui " + j + " : ELS, contrainte du béton dépassée (" + sb.toFixed(1) + " > " + sbl.toFixed(1) + " MPa).");
      if (ss > ssl) av.push("Appui " + j + " : ELS, contrainte de l'acier dépassée (" + ss.toFixed(0) + " > " + ssl.toFixed(0) + " MPa).");
      let pose = conv;
      if (!L) { pose = false; av.push("Appui " + j + " : les barres ne tiennent pas en un lit ni en plusieurs (moins de 2 HA" + B.d + " par lit dans b0 = " + b0 + " cm) : augmenter b0."); }
      else if (L.nb > 1) {
        av.push("Appui " + j + " : " + B.n + " HA" + B.d + " ne tiennent pas en un lit : " + L.nb + " lits (" + L.rep.join(" + ") + "), d réel = " + L.d.toFixed(1) + " cm, d de calcul = " + d.toFixed(1) + " cm.");
        if (L.nb > 3) { pose = false; av.push("Appui " + j + " : plus de 3 lits, disposition refusée : augmenter b0 ou h."); }
        else if (L.nb > 2) av.push("Appui " + j + " : 3 lits, disposition à valider (bétonnage, vibration).");
      } else if (L.d < d - 1e-6) av.push("Appui " + j + " : d réel (" + L.d.toFixed(1) + " cm) inférieur au d de calcul.");
      if (!conv) av.push("Appui " + j + " : la mise en lits ne converge pas : augmenter la section.");
      Object.assign(out, { Au, Amin, Ase, As, barres: B, lits: L, sb, ss, sbl, ssl, ok: pose && sb <= sbl && ss <= ssl });
      appuis.push(out);
    }
    appuis.forEach(x => x.avert.forEach(m => W.push(m)));
    return { appuis, warn: W, VuAppui: res.resume.VmaxAppui, coefTe: T.k };
  }

  const api = { theta, muCrit, flex, barres, limAcier, aserELS, els, momentAppui, lits, disposer, coefTe, plancher, chapeaux };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.EXBPA = api;
})(typeof window !== "undefined" ? window : globalThis);
