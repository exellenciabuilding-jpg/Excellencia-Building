/* V245p — Module 1/4 « poutres continues » : analyse élastique (méthode des rotations), enveloppes ELU / ELS.
   Fonctions pures (navigateur : window.EXBPCONT ; Node : require).
   NOM GLOBAL : EXBPCONT. Le nom EXBPC est pris par le contrôle de paie (exb-v234-controle-paie-ecritures.js) : ne pas l'utiliser ici.
   Unités : m, kN/m, kN, kN.m. EI relatif (un nombre pour toute la poutre, ou un nombre par travée ; seule la proportion compte).
   Convention de signes : moments POSITIFS en travée (fibre inférieure tendue), NÉGATIFS sur appui (« hogging »).
   Tranchant V(x) positif quand la résultante à gauche de la coupe est dirigée vers le haut ; V(0) = réaction de la travée sur son appui gauche.
   Méthode : identique à celle de calcul-structure/index.html (rotations des appuis, moments d'encastrement parfait, appuis simples rigides),
   étendue à des charges uniformes par travée et à des rigidités EI différentes d'une travée à l'autre.
   Enveloppes : G sur toutes les travées, Q en travées chargées/déchargées dans tous les cas utiles (une travée à la fois, superposition linéaire :
   on retient, en chaque point, la somme des contributions positives ou négatives de Q), comme dans index.html.
   Limites : charges uniformes seulement (une valeur G et une valeur Q par travée) ; appuis simples sans tassement ni raideur de poteau ;
   pas de console en rive ; ELS = mêmes enveloppes avec γG = γQ = 1. Calcul d'aide à l'étude : à faire vérifier par un ingénieur.
   API : analyse(o), cas(Ls, EI, q, ns), enveloppe(cG, cQ, fG, fQ), gauss(A).
   Résultat de analyse : { n (nombre de travées), Ls, EI, G, Q, gG, gQ, ns, cas:{G, Q:[…]}, U, E, resume, erreurs, avert }
     resume : { Ma[j] (moment d'appui j, valeur ABSOLUE du moment négatif max, j = 0 … n), Mt[s], xt[s] (moment max de travée et son abscisse),
                Vmax[j] (tranchant ELU maximal en valeur absolue au droit de l'appui j, des deux côtés), VmaxAppui (max de Vmax sur les appuis intérieurs ; sur l'appui unique d'une travée isolée : max des deux appuis),
                R[j] (réaction ELU maximale), Rmin[j] (réaction ELU minimale), MaS[j], MtS[s] (ELS) }. */
(function (root) {
  "use strict";
  const NS = 20, MAXT = 40;

  /* résolution d'un système linéaire par élimination de Gauss avec pivot partiel. A : matrice augmentée n × (n+1). Modifie A. */
  function gauss(A) {
    const n = A.length;
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
      if (!(Math.abs(A[p][i]) > 1e-12)) throw new Error("Système singulier : vérifier les portées et la rigidité EI.");
      const t = A[i]; A[i] = A[p]; A[p] = t;
      for (let r = i + 1; r < n; r++) { const f = A[r][i] / A[i][i]; if (f) for (let c = i; c <= n; c++) A[r][c] -= f * A[i][c]; }
    }
    const x = new Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) { let s = A[i][n]; for (let c = i + 1; c < n; c++) s -= A[i][c] * x[c]; x[i] = s / A[i][i]; }
    return x;
  }

  /* un cas de charge : q[s] = charge uniforme de la travée s (kN/m). ns = nombre de subdivisions par travée (20 par défaut).
     Retourne { n, Ls, EI, q, ns, Ma (n+1 valeurs, extrémités nulles), M[s][k], V[s][k] (k = 0 … ns), R (n+1 réactions) }.
     Lève une erreur si les données sont incohérentes (analyse() les vérifie avant). */
  function cas(Ls, EI, q, ns) {
    const n = Ls && Ls.length;
    if (!n) throw new Error("Aucune travée.");
    if (!Array.isArray(q) || q.length !== n) throw new Error("Une charge par travée est attendue.");
    const ei = Array.isArray(EI) ? EI.map(Number) : Ls.map(() => (EI == null ? 1 : +EI));
    if (ei.length !== n) throw new Error("Une rigidité EI par travée est attendue.");
    for (let s = 0; s < n; s++) {
      if (!(Ls[s] > 0) || !isFinite(Ls[s])) throw new Error("Portée invalide (travée " + (s + 1) + ").");
      if (!(ei[s] > 0) || !isFinite(ei[s])) throw new Error("Rigidité EI invalide (travée " + (s + 1) + ").");
      if (!isFinite(q[s])) throw new Error("Charge invalide (travée " + (s + 1) + ").");
    }
    const N = ns > 0 ? Math.round(ns) : NS, m = n + 1;
    const A = Array.from({ length: m }, () => new Array(m + 1).fill(0));
    const fem = q.map((w, s) => [-w * Ls[s] * Ls[s] / 12, w * Ls[s] * Ls[s] / 12]);
    for (let s = 0; s < n; s++) {
      const k = ei[s] / Ls[s];
      A[s][s] += 4 * k; A[s][s + 1] += 2 * k; A[s + 1][s + 1] += 4 * k; A[s + 1][s] += 2 * k;
      A[s][m] -= fem[s][0]; A[s + 1][m] -= fem[s][1];
    }
    const th = gauss(A), M = [], V = [], Ma = new Array(m).fill(0);
    for (let s = 0; s < n; s++) {
      const L = Ls[s], k = ei[s] / L, w = q[s];
      const ml = fem[s][0] + k * (4 * th[s] + 2 * th[s + 1]), mr = -(fem[s][1] + k * (4 * th[s + 1] + 2 * th[s]));
      if (s > 0) Ma[s] = ml;
      if (s === n - 1) Ma[n] = 0;
      const mm = [], vv = [];
      for (let i = 0; i <= N; i++) {
        const x = L * i / N;
        mm.push(w * x * (L - x) / 2 + ml * (1 - x / L) + mr * x / L);
        vv.push(w * (L / 2 - x) + (mr - ml) / L);
      }
      M.push(mm); V.push(vv);
    }
    /* extrémités simples : moments nuls exactement (le calcul donne ~1e-15) */
    for (let s = 0; s < n; s++) { M[s][0] = s === 0 ? 0 : M[s][0]; M[s][N] = s === n - 1 ? 0 : M[s][N]; }
    const R = Array.from({ length: m }, (_, i) => i === 0 ? V[0][0] : i === n ? -V[n - 1][N] : V[i][0] - V[i - 1][N]);
    return { n, Ls: Ls.slice(), EI: ei, q: q.slice(), ns: N, Ma, M, V, R };
  }

  /* enveloppe : cG = cas des charges permanentes, cQ = tableau des cas « Q sur la travée s seule », fG, fQ = coefficients.
     Retourne { mx, mn, vx, vn } (par travée, k = 0 … ns : moment max/min, tranchant max/min), R (réactions max), Rmin (réactions min),
     Ma (moment d'appui minimal, négatif, j = 0 … n). */
  function enveloppe(cG, cQ, fG, fQ) {
    const n = cG.n, N = cG.ns, mx = [], mn = [], vx = [], vn = [];
    for (let s = 0; s < n; s++) {
      const a = [], b = [], c = [], d = [];
      for (let k = 0; k <= N; k++) {
        let p = 0, q = 0, vp = 0, vq = 0;
        cQ.forEach(o => { p += Math.max(0, o.M[s][k]); q += Math.min(0, o.M[s][k]); vp += Math.max(0, o.V[s][k]); vq += Math.min(0, o.V[s][k]); });
        a.push(fG * cG.M[s][k] + fQ * p); b.push(fG * cG.M[s][k] + fQ * q);
        c.push(fG * cG.V[s][k] + fQ * vp); d.push(fG * cG.V[s][k] + fQ * vq);
      }
      mx.push(a); mn.push(b); vx.push(c); vn.push(d);
    }
    const R = cG.R.map((r, i) => fG * r + fQ * cQ.reduce((t, o) => t + Math.max(0, o.R[i]), 0));
    const Rmin = cG.R.map((r, i) => fG * r + fQ * cQ.reduce((t, o) => t + Math.min(0, o.R[i]), 0));
    const Ma = cG.Ma.map((m, j) => fG * m + fQ * cQ.reduce((t, o) => t + Math.min(0, o.Ma[j]), 0));
    return { mx, mn, vx, vn, R, Rmin, Ma };
  }

  /* valeur par travée : nombre ou tableau (sinon erreur) */
  function parTravee(v, n, nom, err, def) {
    if (v == null) return new Array(n).fill(def);
    if (Array.isArray(v)) {
      if (v.length !== n) { err.push(nom + " : " + n + " valeurs attendues (une par travée), " + v.length + " reçues."); return new Array(n).fill(def); }
      return v.map(Number);
    }
    return new Array(n).fill(+v);
  }

  /* analyse(o) : o = { Ls (m), EI (nombre ou tableau), G, Q (kN/m : nombre ou tableau), gG = 1,35, gQ = 1,5, ns = 20 } */
  function analyse(o) {
    const erreurs = [], avert = [];
    o = o || {};
    const Ls = Array.isArray(o.Ls) ? o.Ls.map(Number) : [], n = Ls.length;
    if (!n) erreurs.push("Aucune travée : renseigner au moins une portée.");
    if (n > MAXT) erreurs.push("Trop de travées (" + n + ") : maximum " + MAXT + ".");
    Ls.forEach((L, i) => { if (!(L > 0) || !isFinite(L)) erreurs.push("Portée de la travée " + (i + 1) + " invalide (valeur > 0 attendue, en m)."); });
    const G = parTravee(o.G, n, "G", erreurs, 0), Q = parTravee(o.Q, n, "Q", erreurs, 0), EI = parTravee(o.EI, n, "EI", erreurs, 1);
    G.forEach((v, i) => { if (!(v >= 0) || !isFinite(v)) erreurs.push("Charge permanente G de la travée " + (i + 1) + " invalide (valeur ≥ 0 attendue)."); });
    Q.forEach((v, i) => { if (!(v >= 0) || !isFinite(v)) erreurs.push("Charge d'exploitation Q de la travée " + (i + 1) + " invalide (valeur ≥ 0 attendue)."); });
    EI.forEach((v, i) => { if (!(v > 0) || !isFinite(v)) erreurs.push("Rigidité EI de la travée " + (i + 1) + " invalide (valeur > 0 attendue)."); });
    const gG = o.gG == null ? 1.35 : +o.gG, gQ = o.gQ == null ? 1.5 : +o.gQ;
    if (!(gG >= 0) || !(gQ >= 0) || !isFinite(gG) || !isFinite(gQ)) erreurs.push("Coefficients γG et γQ invalides.");
    const ns = o.ns > 0 ? Math.round(o.ns) : NS;
    if (erreurs.length) return { n: 0, Ls, EI, G, Q, gG, gQ, ns, erreurs, avert };

    if (n === 1) avert.push("Une seule travée : pas d'appui intermédiaire.");
    for (let i = 0; i < n; i++) {
      if (Ls[i] > 12) avert.push("Travée " + (i + 1) + " : portée de " + Ls[i] + " m, supérieure à 12 m : à justifier.");
      if (i > 0 && Math.max(Ls[i], Ls[i - 1]) / Math.min(Ls[i], Ls[i - 1]) > 2) avert.push("Travées " + i + " et " + (i + 1) + " : rapport de portées supérieur à 2.");
      if (Q[i] > 0 && G[i] === 0) avert.push("Travée " + (i + 1) + " : charge d'exploitation sans charge permanente (vérifier que le poids propre est compris dans G).");
    }
    const emax = Math.max.apply(null, EI), emin = Math.min.apply(null, EI);
    if (emax / emin > 10) avert.push("Rigidités EI très différentes (rapport > 10) : vérifier les sections.");

    let cG, cQ;
    try {
      cG = cas(Ls, EI, G, ns);
      cQ = Ls.map((_, i) => cas(Ls, EI, Ls.map((__, s) => s === i ? Q[i] : 0), ns));
    } catch (e) { erreurs.push(e.message); return { n: 0, Ls, EI, G, Q, gG, gQ, ns, erreurs, avert }; }
    const U = enveloppe(cG, cQ, gG, gQ), E = enveloppe(cG, cQ, 1, 1);

    const absMax = (...t) => Math.max(0, ...t);
    const Ma = [], MaS = [], Vmax = [], Mt = [], xt = [], MtS = [];
    for (let j = 0; j <= n; j++) {
      const gu = j === 0 || j === n ? 0 : Math.min(U.mn[j - 1][ns], U.mn[j][0]), gs = j === 0 || j === n ? 0 : Math.min(E.mn[j - 1][ns], E.mn[j][0]);
      Ma.push(Math.max(0, -gu)); MaS.push(Math.max(0, -gs));
      const v = [];
      if (j < n) v.push(Math.abs(U.vx[j][0]), Math.abs(U.vn[j][0]));
      if (j > 0) v.push(Math.abs(U.vx[j - 1][ns]), Math.abs(U.vn[j - 1][ns]));
      Vmax.push(absMax.apply(null, v));
    }
    for (let s = 0; s < n; s++) {
      let m = -Infinity, k0 = 0, ms = -Infinity;
      U.mx[s].forEach((v, k) => { if (v > m) { m = v; k0 = k; } });
      E.mx[s].forEach(v => { if (v > ms) ms = v; });
      Mt.push(Math.max(0, m)); xt.push(Ls[s] * k0 / ns); MtS.push(Math.max(0, ms));
    }
    const VmaxAppui = n > 1 ? absMax.apply(null, Vmax.slice(1, n)) : absMax.apply(null, Vmax);
    const resume = { Ma, Mt, xt, Vmax, VmaxAppui, R: U.R.slice(), Rmin: U.Rmin.slice(), MaS, MtS };
    return { n, Ls, EI, G, Q, gG, gQ, ns, cas: { G: cG, Q: cQ }, U, E, resume, erreurs, avert };
  }

  const API = { analyse, cas, enveloppe, gauss, NS, MAXT };
  if (typeof module !== "undefined" && module.exports) module.exports = API;
  if (root) root.EXBPCONT = API;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
