/* Tests — module 1/4 « poutres continues » (exb-poutre-continue.js) : méthode des rotations, enveloppes ELU / ELS.
   node site/calcul-structure/test-poutre-continue.js */
'use strict';
var PC = require('./exb-poutre-continue.js'), ok = 0, ko = 0;
function near(n, v, ref, tol) { var g = Math.abs(v - ref) <= tol; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + (+v).toFixed(5) + ' (réf. ' + (+ref).toFixed(5) + ' ± ' + tol + ')'); }
function is(n, v, ref) { var g = JSON.stringify(v) === JSON.stringify(ref); (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + JSON.stringify(v) + ' (réf. ' + JSON.stringify(ref) + ')'); }

/* 1. deux travées égales, q = 20, L = 5 : M_B = qL²/8 = 62,5 ; R_A = 3qL/8 = 37,5 ; R_B = 10qL/8 = 125 ; M_t = 9qL²/128 à x = 3L/8 (grille de 20 points : tolérance) */
var r = PC.analyse({ Ls: [5, 5], G: 20, Q: 0, gG: 1, gQ: 1 });
near('2 travées : M_B', r.resume.Ma[1], 62.5, 1e-9); near('2 travées : R_A', r.resume.R[0], 37.5, 1e-9); near('2 travées : R_B', r.resume.R[1], 125, 1e-9);
near('2 travées : M_t', r.resume.Mt[0], 9 * 20 * 25 / 128, 0.2); near('2 travées : x_t', r.resume.xt[0], 15 / 8, 0.13);
near('2 travées : appuis de rive nuls', r.resume.Ma[0] + r.resume.Ma[2], 0, 1e-12);
near('2 travées : V à l\'appui central = 5qL/8', r.resume.VmaxAppui, 5 * 20 * 5 / 8, 1e-9);

/* 2. trois travées égales, charge partout : M_B = M_C = qL²/10 ; R_A = 0,4 qL */
r = PC.analyse({ Ls: [6, 6, 6], G: 10, Q: 0, gG: 1, gQ: 1 });
near('3 travées : M_B', r.resume.Ma[1], 36, 1e-9); near('3 travées : M_C', r.resume.Ma[2], 36, 1e-9); near('3 travées : R_A', r.resume.R[0], 24, 1e-9);

/* 3. EI différents : équilibre vertical, équilibre des moments, continuité du moment aux appuis, indépendance de l'échelle de EI */
var Ls = [4.5, 6, 5.2, 3.8], q = [30, 45, 35, 22], c = PC.cas(Ls, [1, 2.5, 0.8, 1.3], q, 20), tot = 0, Mo = 0, x0 = 0, X = [0], Mr = 0;
Ls.forEach(function (L, i) { tot += q[i] * L; Mo += q[i] * L * (x0 + L / 2); x0 += L; X.push(x0); });
c.R.forEach(function (R, j) { Mr += R * X[j]; });
near('EI variables : ΣR = Σq·ℓ', c.R.reduce(function (a, b) { return a + b; }, 0), tot, 1e-9); near('EI variables : équilibre des moments', Mr, Mo, 1e-8);
[1, 2, 3].forEach(function (j) { near('EI variables : continuité du moment, appui ' + j, c.M[j - 1][20], c.M[j][0], 1e-9); });
near('EI variables : Ma[j] = moment sur appui', c.Ma[2], c.M[1][20], 1e-9);
near('EI : seule la proportion compte', PC.cas(Ls, [7, 17.5, 5.6, 9.1], q, 20).Ma[2], c.Ma[2], 1e-9);
is('EI vaut 1 par défaut', PC.cas(Ls, null, q, 20).EI, [1, 1, 1, 1]);
/* tranchant : dM/dx = V (différences finies, trapèze) */
var e = 0; Ls.forEach(function (L, s) { var h = L / 20; for (var k = 0; k < 20; k++) e = Math.max(e, Math.abs((c.M[s][k + 1] - c.M[s][k]) / h - (c.V[s][k] + c.V[s][k + 1]) / 2)); });
near('dM/dx = V (écart max)', e, 0, 1e-9);

/* 4. enveloppes : linéarité, ELS ≤ ELU, résumé cohérent avec les cas */
r = PC.analyse({ Ls: [4.5, 6, 5.2, 3.8], G: [14, 22, 17, 11], Q: [6, 9, 7, 4] });
is('analyse sans erreur', r.erreurs.length, 0); is('4 travées', r.n, 4); is('γG, γQ par défaut', [r.gG, r.gQ], [1.35, 1.5]);
[1, 2, 3].forEach(function (j) {
  var man = -(1.35 * r.cas.G.Ma[j] + 1.5 * r.cas.Q.reduce(function (t, o) { return t + Math.min(0, o.Ma[j]); }, 0));
  near('Ma ELU = G + Σ contributions négatives de Q (appui ' + j + ')', r.resume.Ma[j], man, 1e-9);
  is('ELS ≤ ELU (appui ' + j + ')', r.resume.MaS[j] <= r.resume.Ma[j] && r.resume.MaS[j] > 0, true);
});
[0, 1, 2, 3].forEach(function (s) { is('Mt ELS ≤ Mt ELU (travée ' + (s + 1) + ')', r.resume.MtS[s] <= r.resume.Mt[s] && r.resume.Mt[s] > 0, true); });
[0, 1, 2, 3, 4].forEach(function (j) { is('R min ≤ R max (appui ' + j + ')', r.resume.Rmin[j] <= r.resume.R[j] + 1e-12, true); });
is('Q nulle : une seule combinaison', PC.analyse({ Ls: [5, 5], G: 20, Q: 0 }).resume.Ma[1], 1.35 * 62.5);
is('G uniforme : Q alternées augmentent le moment de travée', PC.analyse({ Ls: [5, 5, 5], G: 10, Q: 10 }).resume.Mt[0] > PC.analyse({ Ls: [5, 5, 5], G: 10, Q: 0 }).resume.Mt[0], true);
near('moment négatif de rive = 0', r.resume.Ma[0] + r.resume.Ma[4], 0, 1e-12);
is('VmaxAppui = max des appuis intérieurs', r.resume.VmaxAppui, Math.max(r.resume.Vmax[1], r.resume.Vmax[2], r.resume.Vmax[3]));
is('G et Q sous forme de nombres → tableaux', PC.analyse({ Ls: [5, 5], G: 2, Q: 1 }).G, [2, 2]);

/* 5. une seule travée : poutre simple q·L²/8 */
r = PC.analyse({ Ls: [6], G: 10, Q: 0, gG: 1, gQ: 1 });
near('1 travée : M_t = qL²/8', r.resume.Mt[0], 45, 1e-9); near('1 travée : x_t = L/2', r.resume.xt[0], 3, 1e-9); is('1 travée : avertissement', r.avert.length, 1);

/* 6. validation des données */
is('aucune travée', PC.analyse({ Ls: [] }).erreurs.length > 0, true);
is('portée nulle', PC.analyse({ Ls: [5, 0], G: 1 }).erreurs.length, 1);
is('G de mauvaise longueur', PC.analyse({ Ls: [5, 5], G: [1] }).erreurs.length, 1);
is('Q négative (une erreur par travée)', PC.analyse({ Ls: [5, 5], G: 1, Q: -1 }).erreurs.length, 2);
is('EI nul', PC.analyse({ Ls: [5, 5], G: 1, EI: [1, 0] }).erreurs.length, 1);
is('trop de travées', PC.analyse({ Ls: new Array(41).fill(5), G: 1 }).erreurs.length, 1);
is('erreur → n = 0 (le module 2 refuse)', PC.analyse({ Ls: [5, -1] }).n, 0);
is('cas : charge manquante', (function () { try { PC.cas([5, 5], 1, [1], 20); } catch (x) { return x.message; } })(), 'Une charge par travée est attendue.');
is('gauss : système singulier', (function () { try { PC.gauss([[0, 0, 1], [0, 0, 1]]); } catch (x) { return /singulier/.test(x.message); } })(), true);
near('gauss : 2x + y = 5, x + 3y = 10', PC.gauss([[2, 1, 5], [1, 3, 10]])[0], 1, 1e-12);

/* 7. nom global : EXBPCONT (EXBPC appartient au contrôle de paie) */
global.window = global; delete require.cache[require.resolve('./exb-poutre-continue.js')]; require('./exb-poutre-continue.js');
is('window.EXBPCONT défini', typeof window.EXBPCONT, 'object'); is('window.EXBPC non touché', typeof window.EXBPC, 'undefined');

console.log('\n' + ok + ' réussi(s), ' + ko + ' échec(s).'); process.exit(ko ? 1 : 0);
