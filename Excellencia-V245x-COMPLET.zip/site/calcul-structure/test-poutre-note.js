/* Tests — note de calcul et plan d'exécution de poutre continue (exb-poutre-note.js). node site/calcul-structure/test-poutre-note.js */
'use strict';
var PC = require('./exb-poutre-continue.js'), N = require('./exb-poutre-note.js'), R = require('./exb-robot-analyse.js'), ok = 0, ko = 0;
function is(n, c) { (c ? ok++ : ko++); console.log((c ? 'OK  ' : 'ECHEC ') + n); }
var res = PC.analyse({ Ls: [5, 6, 4.5], G: 22, Q: 9 });
var o = { res: res, svg: R.svgEnvPoutre, s: { b0: 20, h: 55, enr: 3, dt: 8, fc: 25, fe: 500 }, p: { projet: 'Test' } };
var C = N.calc(o);
is('calcul sans erreur', !C.erreur); is('3 travées armées', C.trav.length === 3 && C.trav.every(function (t) { return t.B; }));
is('métré cohérent (poids > 0, volume > 0)', C.poids > 0 && C.vol > 0);
var h = N.doc(o);
is('note : 10 pages dont plan', (h.match(/class="pg/g) || []).length === 10); is('aucun NaN / undefined', !/NaN|undefined/.test(h));
is('erreur propre sans analyse', /Analyse de la poutre/.test(N.note({})));
console.log(ok + ' OK, ' + ko + ' échec'); process.exit(ko ? 1 : 0);
