/* Tests — module 2/4 « poutres continues » (exb-poutre-appuis.js) : chapeaux sur appuis, flexion BAEL, écrêtement à la face optionnel.
   node site/calcul-structure/test-poutre-appuis.js */
'use strict';
var vm = require('vm'), fs = require('fs'), path = require('path'), ok = 0, ko = 0;
var PC = require('./exb-poutre-continue.js'), PA = require('./exb-poutre-appuis.js');
function near(n, v, ref, tol) { var g = Math.abs(v - ref) <= tol; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + (+v).toFixed(4) + ' (réf. ' + (+ref).toFixed(4) + ' ± ' + tol + ')'); }
function is(n, v, ref) { var g = v === ref; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + v + ' (réf. ' + ref + ')'); }

/* 1. flexion : calcul à la main — Mu = 100 kN.m, b = 25, d = 45, fc = 25, fe = 500 : fbu = 14,167 ; μ = 0,1394 (pivot A) ; α = 0,18845 ; z = 41,61 cm ; As = 5,527 cm² */
var f = PA.flex(100, 25, 45, 25, 500, 1, 1.4);
near('flexion à la main : μ', f.mu, 0.1394, 5e-4); near('flexion à la main : α', f.al, 0.18845, 5e-4); near('flexion à la main : z (cm)', f.z, 41.61, 0.02); near('flexion à la main : As (cm²)', f.As, 5.527, 0.01);
is('flexion à la main : pivot A', f.piv, 'A');
is('μ > μ critique → ok = false', PA.flex(300, 20, 40, 25, 500, 1, 1.4).ok, false);

/* 2. moment à l'axe = résumé de l'analyse ; face : 2 travées égales sous q uniforme (M_B = qL²/8, V_B = 5qL/8 → M(face) = qL²/8 − 5qL·s/8 + q s²/2 ; q = 20, L = 5, a = 40 cm → s = 0,2 → 50,4) */
var Ls = [4.5, 6, 5.2, 3.8], G = [14, 22, 17, 11], Q = [6, 9, 7, 4], r = PC.analyse({ Ls: Ls, G: G, Q: Q });
[1, 2, 3].forEach(function (j) { near('moment à l\'axe = enveloppe (appui ' + j + ')', PA.momentAppui(r, j, 0, 1.35, 1.5).axe, r.resume.Ma[j], 1e-9); });
var r2 = PC.analyse({ Ls: [5, 5], G: 20, Q: 0, gG: 1, gQ: 1 }), m2 = PA.momentAppui(r2, 1, 40, 1, 1);
near('2 travées : moment à l\'axe = qL²/8', m2.axe, 62.5, 1e-9); near('2 travées : moment à la face = 50,4', m2.face, 50.4, 1e-9); near('2 travées : réduction = 19,4 %', m2.reduction, 1 - 50.4 / 62.5, 1e-9);
[1, 2, 3].forEach(function (j) { var m = PA.momentAppui(r, j, 40, 1.35, 1.5); is('face ≤ axe (appui ' + j + ')', m.face <= m.axe + 1e-12 && m.face > 0, true); });
is('largeur nulle : pas de réduction', PA.momentAppui(r, 2, 0, 1.35, 1.5).reduction, 0);
is('poteau plus large → réduction plus forte', PA.momentAppui(r, 2, 60, 1.35, 1.5).face < PA.momentAppui(r, 2, 30, 1.35, 1.5).face, true);
is('largeur de poteau incompatible signalée', !!PA.momentAppui(r, 1, 900, 1.35, 1.5).erreur, true);

/* 3. équivalence avec la note de calcul existante (exb-etudes.js) : même Mu, Ms, section → mêmes Au, mêmes barres, mêmes contraintes ELS */
var ls = {}; global.localStorage = { getItem: function (k) { return k in ls ? ls[k] : null; }, setItem: function (k, v) { ls[k] = String(v); }, removeItem: function (k) { delete ls[k]; } };
var fakeEl = function () { return { style: {}, children: [], appendChild: function () {}, addEventListener: function () {}, setAttribute: function () {}, remove: function () {}, classList: { add: function () {}, remove: function () {} }, querySelector: function () { return null; }, querySelectorAll: function () { return []; } }; };
global.window = global; global.document = { addEventListener: function () {}, documentElement: {}, body: fakeEl(), createElement: fakeEl, getElementById: function () { return null; }, querySelector: function () { return null; }, querySelectorAll: function () { return []; } };
vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', 'exb-etudes.js'), 'utf8'), { filename: 'exb-etudes.js' });
function note(v, fiss) { return { id: 'N', no: 'NC-1', fc: 25, fe: 500, enr: 3, fiss: fiss, els: [{ id: 'E', type: 'beam', name: 'Pt', v: Object.assign({ type: 'rect', b: 25, h: 50, b0: 25, h0: 12, L: 5, g: 10, q: 5, km: 0.125, Mu: 0, Ms: 0, Vu: 0, jr: 0, reprise: 'oui' }, v) }] }; }
function row(rr, k) { return (rr.rows.filter(function (x) { return x[0].indexOf(k) === 0; })[0] || [])[1] || ''; }
function num(t, re) { var m = t.match(re); return m ? parseFloat(m[1].replace(/[\s  ]/g, '').replace(',', '.')) : NaN; }
[[25, 50, 100, 70, undefined], [30, 60, 150, 110, 'préjudiciable'], [20, 45, 60, 42, 'très préjudiciable']].forEach(function (c) {
  var b = c[0], h = c[1], Mu = c[2], Ms = c[3], fiss = c[4], rn = global.EXBET.calcNote(note({ b: b, b0: b, h: h, Mu: Mu, Ms: Ms }, fiss))[0];
  var Au = num(row(rn, 'Flexion ELUR'), /Au = (-?[\d  ]+,\d+) cm²/), n0 = row(rn, 'RÉSULTAT').match(/(\d+) HA(\d+) \(([\d,]+) cm²\)/);
  /* même moment dans le module 2 : q tel que qL²/8 = Mu avec γG = 1,35 sur G seul ; l'ELS vaut alors Mu/1,35 ≠ Ms → on compare donc la flexion ELUR seule avec gam identique */
  var th = 1, d = Math.min(0.9 * h, h - 3 - 3), fl = PA.flex(Mu, b, d, 25, 500, th, Mu / Ms);
  near('note vs module 2 : Au (' + b + '×' + h + ', fiss. ' + (fiss || 'peu préj.') + ')', fl.As, Au, 0.006);
  var Amin = (0.6 + 0.06 * 25) / 500 * 0.23 * d * b;
  near('note vs module 2 : As,min', Amin, num(row(rn, 'Flexion ELUR'), /As,min = (-?[\d  ]+,\d+) cm²/), 0.006);
  /* ELS : mêmes aciers choisis → mêmes contraintes que la ligne « Vérification ELS » de la note */
  var Ase = fiss && fiss !== 'peu préjudiciable' ? PA.aserELS(Ms, b, d, 25, 500, fiss) : 0, B = PA.barres(Math.max(fl.As, Ase, Amin), 2), e = PA.els(Ms, b, d, B.as, 25, 500, fiss || 'peu préjudiciable'), tv = row(rn, 'Vérification ELS');
  is('note vs module 2 : mêmes barres', B.n + ' HA' + B.d, n0[1] + ' HA' + n0[2]);
  near('note vs module 2 : sigma-bc', e.sb, num(tv, /sigma-bc = (-?[\d  ]+,\d+) MPa/), 0.006); near('note vs module 2 : sigma-st', e.ss, num(tv, /sigma-st = (-?[\d  ]+,\d+) MPa/), 0.06);
});

/* 4. option C : écrêtement seulement si demandé ET si la largeur du poteau est connue */
var base = { res: r, b0: 30, h: 60, enr: 3, fc: 25, fe: 500, colonnes: [0, 40, 40, 40, 0] };
var cAxe = PA.chapeaux(base), cOff = PA.chapeaux(Object.assign({}, base, { ecreter: false })), cFace = PA.chapeaux(Object.assign({}, base, { ecreter: true })), cSans = PA.chapeaux(Object.assign({}, base, { ecreter: true, colonnes: [] }));
is('3 appuis intérieurs traités (4 travées)', cAxe.appuis.length, 3);
is('par défaut : moment à l\'axe', cAxe.appuis[1].Mu, cAxe.appuis[1].Ma_axe);
is('écrêtage coché mais désactivé = par défaut', cOff.appuis[1].Mu, cAxe.appuis[1].Mu);
is('écrêtage activé : Mu < Mu à l\'axe', cFace.appuis[1].Mu < cAxe.appuis[1].Mu, true);
is('écrêtage activé : As ≤ As à l\'axe', cFace.appuis[1].As <= cAxe.appuis[1].As, true);
is('écrêtage activé sans largeur : retombe sur l\'axe', cSans.appuis[1].Mu, cAxe.appuis[1].Mu);
is('écrêtage activé sans largeur : pas marqué écrêté', cSans.appuis[1].ecrete, false);
is('écrêtage activé avec largeur : marqué écrêté', cFace.appuis[1].ecrete, true);

/* 5. cas particuliers */
is('une seule travée : aucun chapeau', PA.chapeaux(Object.assign({}, base, { res: PC.analyse({ Ls: [5], G: 10, Q: 5 }) })).appuis.length, 0);
var bad = PA.chapeaux({ res: PC.analyse({ Ls: [6, 6], G: 40, Q: 20 }), b0: 12, h: 30, enr: 3, fc: 25, fe: 500 });
is('section insuffisante : alerte μ > μ critique', bad.warn.some(function (m) { return /μ critique/.test(m); }), true); is('section insuffisante : pas de barres', bad.appuis[0].barres, null);
var pr = PA.chapeaux(Object.assign({}, base, { fiss: 'préjudiciable' })).appuis[1];
is('fissuration préjudiciable : As ≥ Aser', pr.As >= pr.Ase - 1e-9 && pr.Ase > 0, true);
var lim = PA.chapeaux({ res: PC.analyse({ Ls: [6, 6], G: 25, Q: 10 }), b0: 20, h: 60, enr: 3, fc: 25, fe: 500 });
is('V245o : section acceptée à d forfaitaire mais refusée à d réel (2 lits)', lim.appuis[0].ok === false && lim.appuis[0].d < 54 && /après mise en lits/.test(lim.warn.join(' ')), true);
var etr = PA.chapeaux({ res: PC.analyse({ Ls: [6, 6], G: 22, Q: 9 }), b0: 20, h: 60, enr: 3, fc: 25, fe: 500, dt: 8 });
console.log('   (info) b0 = 20 : ' + etr.appuis[0].barres.n + ' HA' + etr.appuis[0].barres.d + ', alertes : ' + etr.warn.length);
is('barres qui ne tiennent pas en un lit : alerte émise', etr.warn.some(function (m) { return /ne tiennent pas/.test(m); }), true);
is('les barres couvrent As', base && cAxe.appuis.every(function (a) { return a.barres.as >= a.As - 1e-9; }), true);
is('sans analyse : message', PA.chapeaux({}).warn.length, 1);

/* 6. V245o : lits multiples — calcul à la main : 6 HA20, b0 = 20, h = 60, enr = 3, cadre 8 : larg = 12,4 ; esp. = 2,5 ; 3 par lit ;
   centres à 4,8 et 9,3 cm → yg = 7,05 → d = 52,95 cm */
var L6 = PA.lits(6, 20, 20, 60, 3, 8);
is('lits : 3 barres par lit', L6.par, 3); is('lits : 2 lits', L6.nb, 2); near('lits : centre de gravité (cm)', L6.yg, 7.05, 1e-9); near('lits : d réel (cm)', L6.d, 52.95, 1e-9);
near('lits : dernier lit incomplet pondéré (5 HA20)', PA.lits(5, 20, 20, 60, 3, 8).yg, (3 * 4.8 + 2 * 9.3) / 5, 1e-9);
is('lits : largeur insuffisante pour 2 barres → null', PA.lits(4, 32, 14, 60, 3, 8), null);
var m1 = etr.appuis[0];
is('multi-lits : plus d\'un lit', m1.lits.nb > 1, true);
is('multi-lits : d de calcul ≤ d réel', m1.d <= m1.lits.d + 1e-6, true);
is('multi-lits : d de calcul réduit', m1.d < Math.min(0.9 * 60, 60 - 6), true);
near('multi-lits : Au cohérent avec d retenu', m1.Au, PA.flex(m1.Mu, 20, m1.d, 25, 500, 1, m1.gam).As, 1e-9);
is('multi-lits : barres ≥ As', m1.barres.as >= m1.As - 1e-9, true);
is('un seul lit : d inchangé', cAxe.appuis[1].d, Math.min(0.9 * 60, 60 - 6));

/* 7. As,min en té — à la main : b0 = 25, h = 50, b = 100, h0 = 12 : A = 2150 ; v = 17,047 cm ; I = 460 112 cm4 ; (I/v)/(b0 h²/6) = 2,591 */
var T = PA.coefTe(25, 50, 100, 12);
near('té : v (cm)', T.v, 36650 / 2150, 1e-9); near('té : I (cm4)', T.I, 460112, 5); near('té : coefficient', T.k, 2.591, 0.002);
near('table nulle (b = b0) : coefficient 1', PA.coefTe(25, 50, 25, 12).k, 1, 1e-12);
var peu = { res: PC.analyse({ Ls: [5, 5], G: 3, Q: 1 }), b0: 25, h: 50, fc: 25, fe: 500 };
var aR = PA.chapeaux(peu).appuis[0], aT = PA.chapeaux(Object.assign({ b: 100, h0: 12 }, peu)).appuis[0];
near('té : As,min = rectangle × coefficient', aT.Amin, aR.Amin * T.k, 1e-9); is('té : As,min gouverne', aT.As, aT.Amin);
is('h0 manquant : table ignorée et signalée', PA.chapeaux(Object.assign({ b: 100 }, peu)).warn.some(function (m) { return /Table du té ignorée/.test(m); }), true);

/* 8. plancher à la face (EN 1992-1-1, 5.3.2.2(3)) : 2 travées 5 m, q = 20, poteau 150 cm : axe 62,5 ; 0,65·qL²/12 = 27,083 */
var large = { res: r2, b0: 25, h: 50, fc: 25, fe: 500, colonnes: [0, 150, 0], ecreter: true };
var s0 = PA.chapeaux(large).appuis[0], s1 = PA.chapeaux(Object.assign({ plancherFace: 0.65 }, large)).appuis[0];
is('plancher désactivé par défaut', s0.plancher, null); near('plancher : valeur minimale', s1.plancher.min, 0.65 * 20 * 25 / 12, 1e-9);
near('plancher : Mu retenu = max(face, min)', s1.Mu, Math.max(s0.Mu, 0.65 * 20 * 25 / 12), 1e-9);
near('plancher fort : actif et borné par l\'axe', PA.plancher({ axe: 62.5, face: 20, q: [20, 20] }, [5, 5], 1, 1).val, 41.6667, 1e-3);
near('plancher > axe : retenu = axe', PA.plancher({ axe: 30, face: 20, q: [20, 20] }, [5, 5], 1, 1).val, 30, 1e-9);
is('plancher sans écrêtage : sans effet', PA.chapeaux(Object.assign({}, large, { ecreter: false, plancherFace: 0.65 })).appuis[0].Mu, s0.Ma_axe);

console.log('\n' + ok + ' réussi(s), ' + ko + ' échec(s).'); process.exit(ko ? 1 : 0);
