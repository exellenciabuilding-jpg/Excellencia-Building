/* Excellencia Building — PDF VECTORIEL des notes de calcul et des plans d'exécution (V245i).
 * Avant : chaque feuille était photographiée (JPEG) → texte non sélectionnable, flou à l'agrandissement.
 * Maintenant : la feuille est lue dans la page (texte, cadres, fonds, tableaux, traits, plans SVG) et réécrite
 * avec pdf-lib en vrai PDF : texte sélectionnable / copiable / cherchable, traits nets à tout zoom, fichier léger.
 * Polices : Helvetica / Times / Courier + Symbol (lettres grecques, ≤ ≥ √ Σ →…) + ZapfDingbats (✓) : aucune police à embarquer.
 * Secours : si quoi que ce soit échoue, l'ancien rendu en images (EXBDocPDF.runRaster) prend le relais.
 * Utilisation : EXBDocPDF.run() (inchangé). */
(function (w, d) {
  'use strict';
  var D = w.EXBDocPDF;
  if (!D || !D._r || !D._r.sources) return;
  var R = D._r, MM = R.MM, PAGES = R.PAGES;
  var PX = 0.75;                                   /* 1 px CSS = 0.75 pt */
  var KAPPA = 0.5522847498;

  /* ---------------------------------------------------------------- utilitaires */
  function n2(v) { v = Math.round(v * 100) / 100; return String(v === 0 ? 0 : v); }
  function num(v, dflt) { var x = parseFloat(v); return isFinite(x) ? x : (dflt || 0); }
  function color(s) {
    if (!s) return null; s = String(s).trim();
    if (s === 'transparent' || s === 'none') return null;
    var m = s.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,\/]\s*([\d.%]+))?\s*\)/i);
    if (m) { var a = m[4] == null ? 1 : (/%/.test(m[4]) ? parseFloat(m[4]) / 100 : parseFloat(m[4])); return [num(m[1]) / 255, num(m[2]) / 255, num(m[3]) / 255, a]; }
    m = s.match(/^#([0-9a-f]{3,8})$/i);
    if (m) { var h = m[1]; if (h.length < 6) h = h.replace(/./g, '$&$&'); return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255, h.length >= 8 ? parseInt(h.substr(6, 2), 16) / 255 : 1]; }
    m = s.match(/color\(\s*srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)(?:\s*\/\s*([\d.]+))?\s*\)/i);
    if (m) return [num(m[1]), num(m[2]), num(m[3]), m[4] == null ? 1 : num(m[4], 1)];
    return null;
  }
  function rg(c) { return n2(c[0]) + ' ' + n2(c[1]) + ' ' + n2(c[2]); }

  /* ---------------------------------------------------------------- polices & caractères */
  var SUBS = { '⁰': ['0', 1], '⁴': ['4', 1], '⁵': ['5', 1], '⁶': ['6', 1], '⁷': ['7', 1], '⁸': ['8', 1], '⁹': ['9', 1], 'ⁿ': ['n', 1], '⁺': ['+', 1], '⁻': ['-', 1],
    '₀': ['0', -1], '₁': ['1', -1], '₂': ['2', -1], '₃': ['3', -1], '₄': ['4', -1], '₅': ['5', -1], '₆': ['6', -1], '₇': ['7', -1], '₈': ['8', -1], '₉': ['9', -1], 'ₓ': ['x', -1], '₊': ['+', -1], '₋': ['-', -1] };
  var MAPS = { '\u2126': '\u03A9', '\u2206': '\u0394', '\u00AD': '', '\u200B': '', '\u200D': '', '\uFE0F': '', '\uFE0E': '', '\u2009': ' ', '\u202F': ' ', '\u2002': ' ', '\u2003': ' ', '\u2007': ' ', '\u00A0': ' ', '\u2010': '-', '\u2011': '-', '\u2012': '-', '\u2212': '\u2212', '⚠': '!', '✅': '', '❌': 'x', '⭐': '*', '▪': '\u2022', '●': '\u2022', '◦': 'o', '‣': '\u2022', '∕': '/', '⁄': '/' };
  var FONTS = null;                                /* {clé: {font, name}} par document */

  function fontKey(cs) {
    var fam = String(cs.fontFamily || '').toLowerCase(), b = (parseInt(cs.fontWeight, 10) >= 600 || /bold/.test(cs.fontWeight)), it = /italic|oblique/.test(cs.fontStyle || '');
    var base = 'H';
    if (/mono|courier|consolas|menlo/.test(fam)) base = 'C';
    else if (/georgia|times|serif/.test(fam) && !/sans/.test(fam.replace(/ui-serif/g, ''))) base = 'T';
    return base + (b ? 'B' : '') + (it ? 'I' : '');
  }
  function segs(text, fk) {
    var out = [], cur = null, F = FONTS;
    function put(key, t, scale, rise) {
      if (!t) return;
      if (cur && cur.key === key && cur.scale === scale && cur.rise === rise) cur.text += t;
      else { cur = { key: key, text: t, scale: scale, rise: rise }; out.push(cur); }
    }
    var prim = F[fk] || F.H;
    for (var i = 0; i < text.length; i++) {
      var ch = text.charAt(i), cp = text.charCodeAt(i);
      if (cp >= 0xD800 && cp <= 0xDBFF) { i++; continue; }          /* émoji / plans supplémentaires : ignorés */
      if (MAPS.hasOwnProperty(ch)) { ch = MAPS[ch]; if (!ch) continue; cp = ch.charCodeAt(0); }
      if (prim.set[cp]) { put(fk, ch, 1, 0); continue; }
      if (SUBS[ch]) { var sb = SUBS[ch]; put(fk, sb[0], 0.65, sb[1] > 0 ? 0.38 : -0.14); continue; }
      if (F.S.set[cp]) { put('S', ch, 1, 0); continue; }
      if (F.Z.set[cp]) { put('Z', ch, 1, 0); continue; }
      var base = ch.normalize ? ch.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : ch;
      if (base && base !== ch && prim.set[base.charCodeAt(0)]) { put(fk, base.charAt(0), 1, 0); continue; }
      if (cp >= 0x2190 && cp <= 0x2BFF) continue;                    /* pictogrammes divers */
      put(fk, '?', 1, 0);
    }
    return out;
  }
  function segWidth(sg, fsPt, tc) {
    var wd = 0, F = FONTS;
    sg.forEach(function (s) { wd += F[s.key].font.widthOfTextAtSize(s.text, fsPt * s.scale) + tc * s.text.length * 0; });
    return wd;
  }
  function hexOf(F, key, t) { return F[key].font.encodeText(t).toString(); }

  /* ---------------------------------------------------------------- registre commun (opacités, images) */
  function Reg() { this.gs = {}; this.gsN = 0; this.img = {}; this.imgN = 0; this.imgList = []; }
  Reg.prototype.alpha = function (a) {
    var k = Math.round(a * 100); if (!this.gs[k]) { this.gs[k] = 'GS' + (++this.gsN); this.gs[k + '_a'] = k / 100; } return this.gs[k];
  };

  /* ---------------------------------------------------------------- éléments d'affichage */
  /* Un « item » = {y0, y1, kind, gen(E)} ; E = {f, ox, oy, s0, H, reg, F} ; X(x), Y(y) convertissent des px CSS en points PDF. */
  function mkE(base, f, ox, oy, s0) {
    var E = { f: f, ox: ox, oy: oy, s0: s0, H: base.H, reg: base.reg, F: base.F, cache: base.cache };
    E.X = function (x) { return ox + x * f; };
    E.Y = function (y) { return base.H - (oy + (y - s0) * f); };
    return E;
  }

  function rrect(E, x, y, w, h, r) {
    /* chemin rectangle (éventuellement arrondi), coordonnées px CSS */
    var X0 = E.X(x), X1 = E.X(x + w), Y0 = E.Y(y), Y1 = E.Y(y + h);
    if (!r || (!r[0] && !r[1] && !r[2] && !r[3])) return n2(X0) + ' ' + n2(Y1) + ' ' + n2(X1 - X0) + ' ' + n2(Y0 - Y1) + ' re ';
    var f = E.f, tl = r[0] * f, tr = r[1] * f, br = r[2] * f, bl = r[3] * f, k = KAPPA, s = '';
    var L = X0, Rr = X1, T = Y0, B = Y1;                           /* T = haut (y PDF plus grand) */
    s += n2(L + tl) + ' ' + n2(T) + ' m ';
    s += n2(Rr - tr) + ' ' + n2(T) + ' l ';
    s += n2(Rr - tr + tr * k) + ' ' + n2(T) + ' ' + n2(Rr) + ' ' + n2(T - tr + tr * k) + ' ' + n2(Rr) + ' ' + n2(T - tr) + ' c ';
    s += n2(Rr) + ' ' + n2(B + br) + ' l ';
    s += n2(Rr) + ' ' + n2(B + br - br * k) + ' ' + n2(Rr - br + br * k) + ' ' + n2(B) + ' ' + n2(Rr - br) + ' ' + n2(B) + ' c ';
    s += n2(L + bl) + ' ' + n2(B) + ' l ';
    s += n2(L + bl - bl * k) + ' ' + n2(B) + ' ' + n2(L) + ' ' + n2(B + bl - bl * k) + ' ' + n2(L) + ' ' + n2(B + bl) + ' c ';
    s += n2(L) + ' ' + n2(T - tl) + ' l ';
    s += n2(L) + ' ' + n2(T - tl + tl * k) + ' ' + n2(L + tl - tl * k) + ' ' + n2(T) + ' ' + n2(L + tl) + ' ' + n2(T) + ' c h ';
    return s;
  }
  function withAlpha(E, a, body) { return a < 0.995 ? 'q /' + E.reg.alpha(a) + ' gs ' + body + 'Q\n' : body; }

  /* ---------------------------------------------------------------- boîtes (fond, bordures, arrondis) */
  function radii(cs, w, h) {
    function one(v) { v = String(v || '0').split(' ')[0]; var p = /%/.test(v); var x = num(v); return p ? x / 100 * Math.min(w, h) : x; }
    var r = [one(cs.borderTopLeftRadius), one(cs.borderTopRightRadius), one(cs.borderBottomRightRadius), one(cs.borderBottomLeftRadius)];
    var mx = Math.min(w, h) / 2; return r.map(function (v) { return Math.max(0, Math.min(v, mx)); });
  }
  function boxItems(items, x, y, w, h, cs, alphaMul) {
    if (w <= 0.01 || h <= 0.01) return;
    var bg = color(cs.backgroundColor), r = radii(cs, w, h);
    var bs = ['Top', 'Right', 'Bottom', 'Left'].map(function (s) {
      var wd = num(cs['border' + s + 'Width']), st = cs['border' + s + 'Style'], c = color(cs['border' + s + 'Color']);
      return (wd > 0 && st !== 'none' && st !== 'hidden' && c && c[3] > 0) ? { w: wd, st: st, c: c } : null;
    });
    if (!bg && !bs[0] && !bs[1] && !bs[2] && !bs[3]) return;
    if (!bg && cs.backgroundImage && /gradient/.test(cs.backgroundImage)) { var gm = cs.backgroundImage.match(/rgba?\([^)]+\)/); if (gm) bg = color(gm[0]); }
    if (bg && bg[3] > 0.003) {
      items.push({ y0: y, y1: y + h, kind: 'box', gen: function (E) { return withAlpha(E, bg[3] * alphaMul, 'q ' + rg(bg) + ' rg ' + rrect(E, x, y, w, h, r) + 'f Q\n'); } });
    }
    var uni = bs[0] && bs[1] && bs[2] && bs[3] && bs[0].w === bs[1].w && bs[1].w === bs[2].w && bs[2].w === bs[3].w &&
      bs[0].st === bs[1].st && bs[1].st === bs[2].st && bs[2].st === bs[3].st &&
      bs[0].c.join() === bs[1].c.join() && bs[1].c.join() === bs[2].c.join() && bs[2].c.join() === bs[3].c.join();
    if (uni) {
      var b = bs[0], dash = b.st === 'dashed' ? [b.w * 3, b.w * 2] : (b.st === 'dotted' ? [b.w, b.w * 1.5] : null);
      var rr = r.map(function (v) { return Math.max(0, v - b.w / 2); });
      items.push({ y0: y, y1: y + h, kind: 'box', gen: function (E) {
        var body = 'q ' + rg(b.c) + ' RG ' + n2(b.w * E.f) + ' w ' + (dash ? '[' + dash.map(function (v) { return n2(v * E.f); }).join(' ') + '] 0 d ' : '') +
          rrect(E, x + b.w / 2, y + b.w / 2, w - b.w, h - b.w, rr) + 'S Q\n';
        return withAlpha(E, b.c[3] * alphaMul, body);
      } });
    } else {
      var ids = { 0: [x, y, w, bs[0] && bs[0].w, 0], 1: null, 2: null, 3: null };
      var tw = bs[0] ? bs[0].w : 0, rw = bs[1] ? bs[1].w : 0, bw = bs[2] ? bs[2].w : 0, lw = bs[3] ? bs[3].w : 0;
      var polys = [
        bs[0] && [[x, y], [x + w, y], [x + w - rw, y + tw], [x + lw, y + tw]],
        bs[1] && [[x + w, y], [x + w, y + h], [x + w - rw, y + h - bw], [x + w - rw, y + tw]],
        bs[2] && [[x + w, y + h], [x, y + h], [x + lw, y + h - bw], [x + w - rw, y + h - bw]],
        bs[3] && [[x, y + h], [x, y], [x + lw, y + tw], [x + lw, y + h - bw]]
      ];
      bs.forEach(function (b2, i) {
        if (!b2) return; var pl = polys[i];
        if (b2.st === 'dashed' || b2.st === 'dotted') {
          var P0, P1; if (i === 0) { P0 = [x, y + b2.w / 2]; P1 = [x + w, y + b2.w / 2]; } else if (i === 1) { P0 = [x + w - b2.w / 2, y]; P1 = [x + w - b2.w / 2, y + h]; } else if (i === 2) { P0 = [x, y + h - b2.w / 2]; P1 = [x + w, y + h - b2.w / 2]; } else { P0 = [x + b2.w / 2, y]; P1 = [x + b2.w / 2, y + h]; }
          var dsh = b2.st === 'dashed' ? [b2.w * 3, b2.w * 2] : [b2.w, b2.w * 1.5];
          items.push({ y0: y, y1: y + h, kind: 'box', gen: function (E) { return withAlpha(E, b2.c[3] * alphaMul, 'q ' + rg(b2.c) + ' RG ' + n2(b2.w * E.f) + ' w [' + dsh.map(function (v) { return n2(v * E.f); }).join(' ') + '] 0 d ' + n2(E.X(P0[0])) + ' ' + n2(E.Y(P0[1])) + ' m ' + n2(E.X(P1[0])) + ' ' + n2(E.Y(P1[1])) + ' l S Q\n'); } });
        } else {
          items.push({ y0: y, y1: y + h, kind: 'box', gen: function (E) {
            var s = rg(b2.c) + ' rg '; pl.forEach(function (p, j) { s += n2(E.X(p[0])) + ' ' + n2(E.Y(p[1])) + (j ? ' l ' : ' m '); }); return withAlpha(E, b2.c[3] * alphaMul, s + 'h f\n');
          } });
        }
      });
    }
  }

  /* ---------------------------------------------------------------- texte HTML */
  function textItems(items, tn, cs, O) {
    var s = tn.nodeValue; if (!s || !/\S/.test(s)) return;
    var fs = num(cs.fontSize, 12), fk = fontKey(cs), col = color(cs.color) || [0, 0, 0, 1];
    var tt = cs.textTransform, ls = cs.letterSpacing === 'normal' ? 0 : num(cs.letterSpacing);
    var deco = String(cs.textDecorationLine || cs.textDecoration || ''), ul = /underline/.test(deco), st = /line-through/.test(deco);
    var op = num(cs.opacity, 1);
    var rng = d.createRange(), runs = [], cur = null, re = /[^\s\u00a0]+/g, m;
    function addWord(txt, r) {
      var top = r.top - O.y, bot = r.bottom - O.y, l = r.left - O.x, rt = r.right - O.x;
      if (cur && Math.abs(cur.top - top) < Math.max(2, fs * 0.45) && l >= cur.x1 - 2) { cur.text += ' ' + txt; cur.x1 = Math.max(cur.x1, rt); cur.bot = Math.max(cur.bot, bot); }
      else { cur = { text: txt, x0: l, x1: rt, top: top, bot: bot }; runs.push(cur); }
    }
    while ((m = re.exec(s))) {
      rng.setStart(tn, m.index); rng.setEnd(tn, m.index + m[0].length);
      var rl = rng.getClientRects();
      if (rl.length === 1) addWord(m[0], rl[0]);
      else if (rl.length > 1) {                                    /* mot coupé sur deux lignes : caractère par caractère */
        var part = '', prev = null, pr = null;
        for (var i = 0; i < m[0].length; i++) {
          rng.setStart(tn, m.index + i); rng.setEnd(tn, m.index + i + 1);
          var cr = rng.getClientRects()[0]; if (!cr) continue;
          if (pr && Math.abs(cr.top - pr.top) > fs * 0.45) { addWord(part, { top: prev.top, bottom: prev.bottom, left: prev.left, right: prev.right }); cur = null; part = ''; prev = null; }
          part += m[0].charAt(i); prev = prev ? { top: Math.min(prev.top, cr.top), bottom: Math.max(prev.bottom, cr.bottom), left: Math.min(prev.left, cr.left), right: Math.max(prev.right, cr.right) } : { top: cr.top, bottom: cr.bottom, left: cr.left, right: cr.right }; pr = cr;
        }
        if (part) { addWord(part, prev); cur = null; }
      }
    }
    runs.forEach(function (r) {
      var txt = r.text;
      if (tt === 'uppercase') txt = txt.toUpperCase(); else if (tt === 'lowercase') txt = txt.toLowerCase(); else if (tt === 'capitalize') txt = txt.replace(/(^|\s)(\S)/g, function (a, b, c) { return b + c.toUpperCase(); });
      var h = r.bot - r.top, base = r.top + (h - fs * 1.117) / 2 + fs * 0.905, xw = r.x1 - r.x0;
      items.push({ y0: r.top, y1: r.bot, kind: 'text', ymid: (r.top + r.bot) / 2, gen: function (E) {
        var sg = segs(txt, fk); if (!sg.length) return '';
        var fsPt = fs * E.f, tc = ls * E.f, nat = 0, nsp = (txt.match(/ /g) || []).length, nch = txt.length;
        sg.forEach(function (q) { nat += E.F[q.key].font.widthOfTextAtSize(q.text, fsPt * q.scale); });
        nat += tc * nch;
        var diff = xw * E.f - nat, tw = 0, tcAdj = tc, tz = 100;
        if (Math.abs(diff) > 0.25) {
          if (nsp > 0 && Math.abs(diff / nsp) <= fsPt * 0.45) tw = diff / nsp;          /* texte justifié : on élargit les espaces */
          else { var base0 = nat - tc * nch; if (base0 > 1) tz = Math.max(55, Math.min(150, (xw * E.f - tc * nch) / base0 * 100)); }   /* police du navigateur différente : mise à l'échelle */
        }
        var s = 'q BT ' + rg(col) + ' rg 1 0 0 1 ' + n2(E.X(r.x0)) + ' ' + n2(E.Y(base)) + ' Tm ' + (tcAdj ? n2(tcAdj) + ' Tc ' : '') + (tw ? n2(tw) + ' Tw ' : '') + (tz !== 100 ? n2(tz) + ' Tz ' : '');
        sg.forEach(function (q) { s += '/' + E.F[q.key].name + ' ' + n2(fsPt * q.scale) + ' Tf ' + (q.rise ? n2(q.rise * fsPt) + ' Ts ' : '0 Ts ') + hexOf(E.F, q.key, q.text) + ' Tj '; });
        s += 'ET Q\n';
        if (ul || st) {
          var wl = n2(Math.max(0.4, fsPt * 0.06)); s += 'q [] 0 d ' + rg(col) + ' RG ' + wl + ' w ';
          if (ul) s += n2(E.X(r.x0)) + ' ' + n2(E.Y(base + fs * 0.12)) + ' m ' + n2(E.X(r.x1)) + ' ' + n2(E.Y(base + fs * 0.12)) + ' l S ';
          if (st) s += n2(E.X(r.x0)) + ' ' + n2(E.Y(base - fs * 0.3)) + ' m ' + n2(E.X(r.x1)) + ' ' + n2(E.Y(base - fs * 0.3)) + ' l S ';
          s += 'Q\n';
        }
        return withAlpha(E, col[3] * op, s);
      } });
    });
  }

  /* ---------------------------------------------------------------- images */
  function b64(u) { var b = atob(u.split(',')[1] || ''), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function imageSource(img) {
    /* retourne {key, bytes, type} (jpeg/png) ; conversion par canvas pour les autres formats */
    var src = String(img.currentSrc || img.src || '');
    var m = src.match(/^data:image\/(jpeg|jpg|png);base64,/i);
    if (m) return { key: src.length + ':' + src.slice(-40) + src.slice(30, 60), bytes: b64(src), type: /png/i.test(m[1]) ? 'png' : 'jpg', nw: img.naturalWidth, nh: img.naturalHeight };
    if (!img.complete || !img.naturalWidth) return null;
    var cv = d.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
    var cx = cv.getContext('2d'); cx.drawImage(img, 0, 0);
    var u = cv.toDataURL('image/png');
    return { key: 'c:' + src.length + ':' + src.slice(-40), bytes: b64(u), type: 'png', nw: cv.width, nh: cv.height };
  }
  function imageItem(items, img, x, y, w, h, cs, clipR) {
    var s = imageSource(img); if (!s || w <= 0 || h <= 0) return;
    var fit = cs.objectFit || 'fill', nw = s.nw || w, nh = s.nh || h, dx = x, dy = y, dw = w, dh = h;
    if (fit === 'contain' || fit === 'scale-down' || fit === 'cover') {
      var k = fit === 'cover' ? Math.max(w / nw, h / nh) : Math.min(w / nw, h / nh); if (fit === 'scale-down') k = Math.min(k, 1);
      dw = nw * k; dh = nh * k; dx = x + (w - dw) / 2; dy = y + (h - dh) / 2;
    }
    var op = num(cs.opacity, 1);
    items.push({ y0: y, y1: y + h, kind: 'img', gen: function (E) {
      var nm = E.reg.img[s.key];
      if (!nm) { nm = E.reg.img[s.key] = { name: 'Im' + (++E.reg.imgN), s: s }; E.reg.imgList.push(nm); }
      var X = E.X(dx), Y = E.Y(dy + dh), W = dw * E.f, H = dh * E.f, body = '';
      var needClip = fit === 'cover' || (clipR && (clipR[0] || clipR[1] || clipR[2] || clipR[3]));
      if (needClip) body += 'q ' + rrect(E, x, y, w, h, clipR) + 'W n ';
      body += 'q ' + n2(W) + ' 0 0 ' + n2(H) + ' ' + n2(X) + ' ' + n2(Y) + ' cm /' + nm.name + ' Do Q ';
      if (needClip) body += 'Q ';
      return withAlpha(E, op, body + '\n');
    } });
  }

  /* ---------------------------------------------------------------- SVG (plans) */
  function arcToBez(x1, y1, rx, ry, phi, fa, fs, x2, y2) {
    var out = [];
    if (rx === 0 || ry === 0) return [[x1, y1, x2, y2, x2, y2]];
    var sp = Math.sin(phi * Math.PI / 180), cp = Math.cos(phi * Math.PI / 180);
    var dx = (x1 - x2) / 2, dy = (y1 - y2) / 2, x1p = cp * dx + sp * dy, y1p = -sp * dx + cp * dy;
    rx = Math.abs(rx); ry = Math.abs(ry);
    var lam = x1p * x1p / (rx * rx) + y1p * y1p / (ry * ry); if (lam > 1) { var sl = Math.sqrt(lam); rx *= sl; ry *= sl; }
    var num_ = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p, den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
    var co = Math.sqrt(Math.max(0, num_ / (den || 1e-12))) * (fa === fs ? -1 : 1);
    var cxp = co * rx * y1p / ry, cyp = -co * ry * x1p / rx;
    var cx = cp * cxp - sp * cyp + (x1 + x2) / 2, cy = sp * cxp + cp * cyp + (y1 + y2) / 2;
    function ang(ux, uy, vx, vy) { var a = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a; }
    var th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry), dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
    if (!fs && dth > 0) dth -= 2 * Math.PI; else if (fs && dth < 0) dth += 2 * Math.PI;
    var seg = Math.max(1, Math.ceil(Math.abs(dth) / (Math.PI / 2 + 1e-6))), da = dth / seg, t = 4 / 3 * Math.tan(da / 4);
    for (var i = 0; i < seg; i++) {
      var a1 = th1 + i * da, a2 = a1 + da, c1 = Math.cos(a1), s1 = Math.sin(a1), c2 = Math.cos(a2), s2 = Math.sin(a2);
      var p1 = [c1 - t * s1, s1 + t * c1], p2 = [c2 + t * s2, s2 - t * c2], p3 = [c2, s2];
      function tr(p) { return [cp * rx * p[0] - sp * ry * p[1] + cx, sp * rx * p[0] + cp * ry * p[1] + cy]; }
      var q1 = tr(p1), q2 = tr(p2), q3 = tr(p3); out.push([q1[0], q1[1], q2[0], q2[1], q3[0], q3[1]]);
    }
    return out;
  }
  /* géométrie d'un élément SVG → liste de commandes [['M',x,y],['L',x,y],['C',x1,y1,x2,y2,x,y],['Z']] en coordonnées locales */
  function geom(el) {
    var t = el.tagName.toLowerCase(), a = function (k, dv) { return num(el.getAttribute(k), dv || 0); }, c = [];
    if (t === 'line') { c.push(['M', a('x1'), a('y1')], ['L', a('x2'), a('y2')]); }
    else if (t === 'rect') {
      var x = a('x'), y = a('y'), w = a('width'), h = a('height'), rx = el.getAttribute('rx') != null ? a('rx') : a('ry'), ry = el.getAttribute('ry') != null ? a('ry') : rx;
      rx = Math.min(rx, w / 2); ry = Math.min(ry, h / 2);
      if (!rx && !ry) c.push(['M', x, y], ['L', x + w, y], ['L', x + w, y + h], ['L', x, y + h], ['Z']);
      else {
        var kx = rx * KAPPA, ky = ry * KAPPA;
        c.push(['M', x + rx, y], ['L', x + w - rx, y], ['C', x + w - rx + kx, y, x + w, y + ry - ky, x + w, y + ry], ['L', x + w, y + h - ry], ['C', x + w, y + h - ry + ky, x + w - rx + kx, y + h, x + w - rx, y + h], ['L', x + rx, y + h], ['C', x + rx - kx, y + h, x, y + h - ry + ky, x, y + h - ry], ['L', x, y + ry], ['C', x, y + ry - ky, x + rx - kx, y, x + rx, y], ['Z']);
      }
    } else if (t === 'circle' || t === 'ellipse') {
      var cx = a('cx'), cy = a('cy'), rx2 = t === 'circle' ? a('r') : a('rx'), ry2 = t === 'circle' ? a('r') : a('ry'), kx2 = rx2 * KAPPA, ky2 = ry2 * KAPPA;
      c.push(['M', cx + rx2, cy], ['C', cx + rx2, cy + ky2, cx + kx2, cy + ry2, cx, cy + ry2], ['C', cx - kx2, cy + ry2, cx - rx2, cy + ky2, cx - rx2, cy], ['C', cx - rx2, cy - ky2, cx - kx2, cy - ry2, cx, cy - ry2], ['C', cx + kx2, cy - ry2, cx + rx2, cy - ky2, cx + rx2, cy], ['Z']);
    } else if (t === 'polyline' || t === 'polygon') {
      var nums = (el.getAttribute('points') || '').trim().split(/[\s,]+/).map(parseFloat).filter(function (v) { return isFinite(v); });
      for (var i = 0; i + 1 < nums.length; i += 2) c.push([i ? 'L' : 'M', nums[i], nums[i + 1]]);
      if (t === 'polygon' && c.length) c.push(['Z']);
    } else if (t === 'path') c = parsePath(el.getAttribute('d') || '');
    return c;
  }
  function parsePath(dStr) {
    var toks = dStr.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g) || [], i = 0, out = [], cx = 0, cy = 0, sx = 0, sy = 0, cmd = '', lc = null, lq = null;
    function nx() { return parseFloat(toks[i++]); }
    function flag() { var t = toks[i++]; if (t.length > 1) { toks.splice(i, 0, t.slice(1)); return t.charAt(0) === '1' ? 1 : 0; } return parseFloat(t) ? 1 : 0; }
    while (i < toks.length) {
      if (/[a-zA-Z]/.test(toks[i])) cmd = toks[i++]; else if (cmd === 'M') cmd = 'L'; else if (cmd === 'm') cmd = 'l';
      var rel = cmd === cmd.toLowerCase(), C = cmd.toUpperCase(), x, y, x1, y1, x2, y2;
      if (C === 'Z') { out.push(['Z']); cx = sx; cy = sy; lc = lq = null; continue; }
      if (C === 'M') { x = nx(); y = nx(); if (rel) { x += cx; y += cy; } out.push(['M', x, y]); cx = sx = x; cy = sy = y; lc = lq = null; }
      else if (C === 'L') { x = nx(); y = nx(); if (rel) { x += cx; y += cy; } out.push(['L', x, y]); cx = x; cy = y; lc = lq = null; }
      else if (C === 'H') { x = nx(); if (rel) x += cx; out.push(['L', x, cy]); cx = x; lc = lq = null; }
      else if (C === 'V') { y = nx(); if (rel) y += cy; out.push(['L', cx, y]); cy = y; lc = lq = null; }
      else if (C === 'C') { x1 = nx(); y1 = nx(); x2 = nx(); y2 = nx(); x = nx(); y = nx(); if (rel) { x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy; } out.push(['C', x1, y1, x2, y2, x, y]); lc = [x2, y2]; lq = null; cx = x; cy = y; }
      else if (C === 'S') { x2 = nx(); y2 = nx(); x = nx(); y = nx(); if (rel) { x2 += cx; y2 += cy; x += cx; y += cy; } x1 = lc ? 2 * cx - lc[0] : cx; y1 = lc ? 2 * cy - lc[1] : cy; out.push(['C', x1, y1, x2, y2, x, y]); lc = [x2, y2]; lq = null; cx = x; cy = y; }
      else if (C === 'Q' || C === 'T') {
        if (C === 'Q') { x1 = nx(); y1 = nx(); if (rel) { x1 += cx; y1 += cy; } } else { x1 = lq ? 2 * cx - lq[0] : cx; y1 = lq ? 2 * cy - lq[1] : cy; }
        x = nx(); y = nx(); if (rel) { x += cx; y += cy; }
        out.push(['C', cx + 2 / 3 * (x1 - cx), cy + 2 / 3 * (y1 - cy), x + 2 / 3 * (x1 - x), y + 2 / 3 * (y1 - y), x, y]); lq = [x1, y1]; lc = null; cx = x; cy = y;
      } else if (C === 'A') {
        var rx = nx(), ry = nx(), ph = nx(), fa = flag(), fs2 = flag(); x = nx(); y = nx(); if (rel) { x += cx; y += cy; }
        arcToBez(cx, cy, rx, ry, ph, fa, fs2, x, y).forEach(function (b) { out.push(['C', b[0], b[1], b[2], b[3], b[4], b[5]]); }); cx = x; cy = y; lc = lq = null;
      } else break;
    }
    return out;
  }
  function pathStr(E, cmds, M, O) {
    function T(x, y) { var px = M.a * x + M.c * y + M.e - O.x, py = M.b * x + M.d * y + M.f - O.y; return n2(E.X(px)) + ' ' + n2(E.Y(py)) + ' '; }
    var s = '';
    cmds.forEach(function (q) {
      if (q[0] === 'M') s += T(q[1], q[2]) + 'm '; else if (q[0] === 'L') s += T(q[1], q[2]) + 'l ';
      else if (q[0] === 'C') s += T(q[1], q[2]) + T(q[3], q[4]) + T(q[5], q[6]) + 'c '; else s += 'h ';
    });
    return s;
  }
  function bboxOf(cmds, M, O) {
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    cmds.forEach(function (q) { for (var i = 1; i + 1 < q.length; i += 2) { var px = M.a * q[i] + M.c * q[i + 1] + M.e - O.x, py = M.b * q[i] + M.d * q[i + 1] + M.f - O.y; if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py; } });
    return { x0: x0, y0: y0, x1: x1, y1: y1 };
  }
  function mmul(A, B) { return { a: A.a * B.a + A.c * B.b, b: A.b * B.a + A.d * B.b, c: A.a * B.c + A.c * B.d, d: A.b * B.c + A.d * B.d, e: A.a * B.e + A.c * B.f + A.e, f: A.b * B.e + A.d * B.f + A.f }; }
  function parseTransform(t) {
    var M = { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 }; if (!t) return M;
    (t.match(/\w+\s*\([^)]*\)/g) || []).forEach(function (s) {
      var nm = s.match(/^(\w+)/)[1], v = (s.match(/\(([^)]*)\)/)[1].split(/[\s,]+/).filter(Boolean)).map(parseFloat), N = null;
      if (nm === 'translate') N = { a: 1, b: 0, c: 0, d: 1, e: v[0], f: v[1] || 0 };
      else if (nm === 'scale') N = { a: v[0], b: 0, c: 0, d: v.length > 1 ? v[1] : v[0], e: 0, f: 0 };
      else if (nm === 'rotate') { var r = v[0] * Math.PI / 180, c = Math.cos(r), sn = Math.sin(r); N = { a: c, b: sn, c: -sn, d: c, e: 0, f: 0 }; if (v.length > 2) N = mmul(mmul({ a: 1, b: 0, c: 0, d: 1, e: v[1], f: v[2] }, N), { a: 1, b: 0, c: 0, d: 1, e: -v[1], f: -v[2] }); }
      else if (nm === 'matrix') N = { a: v[0], b: v[1], c: v[2], d: v[3], e: v[4], f: v[5] };
      else if (nm === 'skewX') N = { a: 1, b: 0, c: Math.tan(v[0] * Math.PI / 180), d: 1, e: 0, f: 0 };
      else if (nm === 'skewY') N = { a: 1, b: Math.tan(v[0] * Math.PI / 180), c: 0, d: 1, e: 0, f: 0 };
      if (N) M = mmul(M, N);
    });
    return M;
  }

  /* peinture d'une forme (fond uni, motif hachuré, contour) */
  function paintShape(items, el, cmds, M, O, svgRoot, ctxOpacity) {
    var cs = getComputedStyle(el), fillS = cs.fill, strokeS = cs.stroke, fo = num(cs.fillOpacity, 1) * ctxOpacity, so = num(cs.strokeOpacity, 1) * ctxOpacity;
    var sw = num(cs.strokeWidth, 1), sc = Math.sqrt(Math.abs(M.a * M.d - M.b * M.c)) || 1, cap = cs.strokeLinecap, join = cs.strokeLinejoin;
    var dashS = cs.strokeDasharray, dash = (dashS && dashS !== 'none') ? dashS.split(/[\s,]+/).map(parseFloat).filter(function (v) { return isFinite(v); }) : null;
    var evenodd = cs.fillRule === 'evenodd';
    var bb = bboxOf(cmds, M, O), op = num(cs.opacity, 1);
    var fillC = null, pat = null;
    if (fillS && fillS !== 'none') {
      var um = fillS.match(/url\(["']?#([^"')]+)["']?\)/);
      if (um) {
        var node = svgRoot.querySelector('[id="' + um[1] + '"]');
        if (node && /pattern/i.test(node.tagName)) pat = node;
        else if (node) { var stop = node.querySelector('stop'); if (stop) fillC = color(getComputedStyle(stop).stopColor); }
      } else fillC = color(fillS);
    }
    var strokeC = (strokeS && strokeS !== 'none') ? color(strokeS) : null;
    var kw = ['butt', 'round', 'square'].indexOf(cap); kw = kw < 0 ? 0 : kw; var jn = ['miter', 'round', 'bevel'].indexOf(join); jn = jn < 0 ? 0 : jn;
    var y0 = bb.y0 - sw * sc, y1 = bb.y1 + sw * sc;
    if (fillC && fillC[3] > 0) items.push({ y0: y0, y1: y1, kind: 'vec', gen: function (E) { return withAlpha(E, fillC[3] * fo * op, rg(fillC) + ' rg ' + pathStr(E, cmds, M, O) + (evenodd ? 'f*' : 'f') + '\n'); } });
    if (pat) {
      var pw = num(pat.getAttribute('width'), 6), ph = num(pat.getAttribute('height'), 6), PM = parseTransform(pat.getAttribute('patternTransform') || '');
      var kids = Array.prototype.slice.call(pat.children), baseRect = kids.filter(function (k) { return k.tagName.toLowerCase() === 'rect'; })[0];
      var bgc = baseRect ? color(getComputedStyle(baseRect).fill) : null;
      if (bgc) items.push({ y0: y0, y1: y1, kind: 'vec', gen: function (E) { return withAlpha(E, bgc[3] * fo * op, rg(bgc) + ' rg ' + pathStr(E, cmds, M, O) + 'f\n'); } });
      /* motif : on répète les traits du motif sur l'emprise de la forme (écrêtage par la forme) */
      var inv = (function (A) { var det = A.a * A.d - A.b * A.c || 1e-9; return { a: A.d / det, b: -A.b / det, c: -A.c / det, d: A.a / det, e: (A.c * A.f - A.d * A.e) / det, f: (A.b * A.e - A.a * A.f) / det }; })(mmul(M, PM));
      var corners = [[bb.x0 + O.x, bb.y0 + O.y], [bb.x1 + O.x, bb.y0 + O.y], [bb.x1 + O.x, bb.y1 + O.y], [bb.x0 + O.x, bb.y1 + O.y]].map(function (p) { return [inv.a * p[0] + inv.c * p[1] + inv.e, inv.b * p[0] + inv.d * p[1] + inv.f]; });
      var ux0 = Math.min.apply(null, corners.map(function (p) { return p[0]; })), ux1 = Math.max.apply(null, corners.map(function (p) { return p[0]; })), uy0 = Math.min.apply(null, corners.map(function (p) { return p[1]; })), uy1 = Math.max.apply(null, corners.map(function (p) { return p[1]; }));
      var i0 = Math.floor(ux0 / pw) - 1, i1 = Math.ceil(ux1 / pw) + 1, j0 = Math.floor(uy0 / ph) - 1, j1 = Math.ceil(uy1 / ph) + 1;
      if ((i1 - i0) * (j1 - j0) > 20000) { i1 = i0; }
      var tiles = [];
      kids.forEach(function (k) { if (k === baseRect) return; var g = geom(k); if (!g.length) return; var ks = getComputedStyle(k), sc2 = color(ks.stroke), sw2 = num(ks.strokeWidth, 1); if (sc2) tiles.push({ g: g, c: sc2, w: sw2, o: num(ks.strokeOpacity, 1), f: color(ks.fill) }); });
      if (tiles.length) items.push({ y0: y0, y1: y1, kind: 'vec', gen: function (E) {
        var body = 'q ' + pathStr(E, cmds, M, O) + (evenodd ? 'W* n ' : 'W n ');
        var MP = mmul(M, PM), scp = Math.sqrt(Math.abs(MP.a * MP.d - MP.b * MP.c)) || 1;
        tiles.forEach(function (t) {
          var s = rg(t.c) + ' RG ' + n2(t.w * scp * E.f) + ' w ';
          for (var i = i0; i <= i1; i++) for (var j = j0; j <= j1; j++) {
            var Mt = mmul(MP, { a: 1, b: 0, c: 0, d: 1, e: i * pw, f: j * ph });
            s += pathStr(E, t.g, Mt, O) + 'S ';
          }
          body += withAlpha(E, t.c[3] * t.o * op, s + '\n');
        });
        return body + 'Q\n';
      } });
    }
    if (strokeC && sw > 0 && strokeC[3] > 0) items.push({ y0: y0, y1: y1, kind: 'vec', gen: function (E) {
      var s = 'q ' + rg(strokeC) + ' RG ' + n2(Math.max(0.05, sw * sc * E.f)) + ' w ' + kw + ' J ' + jn + ' j ';
      if (dash && dash.length && dash.some(function (v) { return v > 0; })) s += '[' + dash.map(function (v) { return n2(v * sc * E.f); }).join(' ') + '] 0 d '; else s += '[] 0 d ';
      s += pathStr(E, cmds, M, O) + 'S Q\n'; return withAlpha(E, strokeC[3] * so * op, s);
    } });
  }
  function svgText(items, el, M, O, ctxOpacity) {
    var cs = getComputedStyle(el), fill = color(cs.fill); if (!fill) fill = [0, 0, 0, 1];
    var txt = (el.textContent || '').replace(/\s+/g, ' ').trim(); if (!txt) return;
    var x = num((el.getAttribute('x') || '0').split(/[\s,]+/)[0]) + num((el.getAttribute('dx') || '0').split(/[\s,]+/)[0]);
    var y = num((el.getAttribute('y') || '0').split(/[\s,]+/)[0]) + num((el.getAttribute('dy') || '0').split(/[\s,]+/)[0]);
    var fs = num(cs.fontSize, 10), fk = fontKey(cs), anchor = cs.textAnchor, op = num(cs.opacity, 1) * num(cs.fillOpacity, 1) * ctxOpacity;
    var sc = Math.sqrt(Math.abs(M.a * M.d - M.b * M.c)) || 1, th = Math.atan2(M.b, M.a);
    var px = M.a * x + M.c * y + M.e - O.x, py = M.b * x + M.d * y + M.f - O.y;
    var ls = cs.letterSpacing === 'normal' ? 0 : num(cs.letterSpacing);
    var ext = fs * sc * (txt.length + 2);
    items.push({ y0: py - ext, y1: py + ext, kind: 'text', ymid: py, gen: function (E) {
      var sg = segs(txt, fk); if (!sg.length) return '';
      var fsPt = fs * sc * E.f, wd = 0; sg.forEach(function (q) { wd += E.F[q.key].font.widthOfTextAtSize(q.text, fsPt * q.scale); }); wd += ls * sc * E.f * txt.length;
      var sh = anchor === 'middle' ? -wd / 2 : (anchor === 'end' ? -wd : 0), cth = Math.cos(th), sth = Math.sin(th);
      var X = E.X(px) + sh * cth, Y = E.Y(py) - sh * sth;
      var s = 'q BT ' + rg(fill) + ' rg ' + n2(cth) + ' ' + n2(-sth) + ' ' + n2(sth) + ' ' + n2(cth) + ' ' + n2(X) + ' ' + n2(Y) + ' Tm ' + (ls ? n2(ls * sc * E.f) + ' Tc ' : '');
      sg.forEach(function (q) { s += '/' + E.F[q.key].name + ' ' + n2(fsPt * q.scale) + ' Tf ' + (q.rise ? n2(q.rise * fsPt) + ' Ts ' : '0 Ts ') + hexOf(E.F, q.key, q.text) + ' Tj '; });
      return withAlpha(E, fill[3] * op, s + 'ET Q\n');
    } });
  }
  var SVG_SKIP = { defs: 1, pattern: 1, symbol: 1, marker: 1, clippath: 1, mask: 1, style: 1, title: 1, desc: 1, lineargradient: 1, radialgradient: 1, metadata: 1, script: 1, foreignobject: 1 };
  function svgWalk(items, el, root, O, ctxOpacity) {
    var t = el.tagName.toLowerCase(); if (SVG_SKIP[t]) return;
    var cs = getComputedStyle(el); if (cs.display === 'none' || cs.visibility === 'hidden') return;
    var op = ctxOpacity * (t === 'g' || t === 'svg' ? num(cs.opacity, 1) : 1);
    if (t === 'g' || t === 'a' || t === 'svg') { Array.prototype.forEach.call(el.children, function (k) { svgWalk(items, k, root, O, op); }); return; }
    var m = el.getScreenCTM && el.getScreenCTM(); if (!m) return;
    var M = { a: m.a, b: m.b, c: m.c, d: m.d, e: m.e, f: m.f };
    if (t === 'text') { svgText(items, el, M, O, ctxOpacity); return; }
    if (t === 'use') { var hr = (el.getAttribute('href') || el.getAttribute('xlink:href') || '').replace('#', ''), tg = hr && root.querySelector('[id="' + hr + '"]'); if (tg && !SVG_SKIP[tg.tagName.toLowerCase()]) { var wrap = { items: items }; var sub = []; svgWalk(sub, tg, root, O, op); sub.forEach(function (x) { items.push(x); }); } return; }
    if (t === 'image') {
      var href = el.getAttribute('href') || el.getAttribute('xlink:href') || ''; if (!/^data:image\//.test(href)) return;
      var im = new Image(); im.src = href; if (!im.complete) return;
      var bx = num(el.getAttribute('x')), by = num(el.getAttribute('y')), bw = num(el.getAttribute('width')), bh = num(el.getAttribute('height'));
      var p0 = [M.a * bx + M.c * by + M.e - O.x, M.b * bx + M.d * by + M.f - O.y]; var sx = Math.sqrt(M.a * M.a + M.b * M.b), sy = Math.sqrt(M.c * M.c + M.d * M.d);
      imageItem(items, im, p0[0], p0[1], bw * sx, bh * sy, cs, null); return;
    }
    var g = geom(el); if (!g.length) return;
    paintShape(items, el, g, M, O, root, ctxOpacity);
  }

  /* ---------------------------------------------------------------- parcours du DOM */
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1, BUTTON: 1, OPTION: 1, IFRAME: 1, OBJECT: 1, EMBED: 1, VIDEO: 1, AUDIO: 1, TEMPLATE: 1, HEAD: 1, META: 1, LINK: 1 };
  function relRect(r, O) { return { x: r.left - O.x, y: r.top - O.y, w: r.width, h: r.height }; }

  function pseudoItems(items, el, which, rect, O, cs0) {
    var ps = getComputedStyle(el, which), ct = ps.content; if (!ct || ct === 'none' || ct === 'normal') return;
    var pos = ps.position, w0, h0, x, y;
    var bsz = ps.boxSizing === 'border-box';
    var bl = num(ps.borderLeftWidth), br = num(ps.borderRightWidth), bt = num(ps.borderTopWidth), bb2 = num(ps.borderBottomWidth);
    var pl = num(ps.paddingLeft), pr = num(ps.paddingRight), ptp = num(ps.paddingTop), pbt = num(ps.paddingBottom);
    w0 = num(ps.width); h0 = num(ps.height);
    if (!bsz) { w0 += bl + br + pl + pr; h0 += bt + bb2 + ptp + pbt; }
    if (pos === 'absolute' || pos === 'fixed') {
      var bx = rect.x + num(cs0.borderLeftWidth), by = rect.y + num(cs0.borderTopWidth);
      var l = ps.left, t = ps.top, rr = ps.right, bo = ps.bottom, pw = rect.w - num(cs0.borderLeftWidth) - num(cs0.borderRightWidth), phh = rect.h - num(cs0.borderTopWidth) - num(cs0.borderBottomWidth);
      x = l !== 'auto' ? bx + num(l) : (rr !== 'auto' ? bx + pw - num(rr) - w0 : bx);
      y = t !== 'auto' ? by + num(t) : (bo !== 'auto' ? by + phh - num(bo) - h0 : by);
      if (cs0.position === 'static') { x = rect.x + (l !== 'auto' ? num(l) : 0); y = rect.y + (t !== 'auto' ? num(t) : 0); }
    } else {
      if (ps.float === 'none' && ps.display === 'inline') return;
      x = rect.x + num(cs0.borderLeftWidth) + num(cs0.paddingLeft) + num(ps.marginLeft);
      var lh = cs0.lineHeight === 'normal' ? num(cs0.fontSize) * 1.15 : num(cs0.lineHeight);
      y = rect.y + num(cs0.borderTopWidth) + num(cs0.paddingTop) + Math.max(0, (lh - h0) / 2);
    }
    if (w0 > 0 && h0 > 0) boxItems(items, x, y, w0, h0, ps, num(ps.opacity, 1));
  }

  function listMarker(items, li, cs, rect, O) {
    var lt = cs.listStyleType; if (!lt || lt === 'none' || cs.display !== 'list-item') return;
    var fs = num(cs.fontSize, 12), col = color(cs.color) || [0, 0, 0, 1], fk = fontKey(cs), mk = '';
    if (lt === 'disc') mk = '\u2022'; else if (lt === 'circle') mk = 'o'; else if (lt === 'square') mk = '\u25AA';
    else if (/decimal|lower|upper/.test(lt)) {
      var p = li.parentNode, idx = parseInt(p && p.getAttribute && p.getAttribute('start'), 10); if (!isFinite(idx)) idx = 1; var sib = li.previousElementSibling;
      while (sib) { if (sib.tagName === 'LI') idx++; sib = sib.previousElementSibling; }
      mk = /lower-alpha|lower-latin/.test(lt) ? String.fromCharCode(96 + idx) : (/upper-alpha|upper-latin/.test(lt) ? String.fromCharCode(64 + idx) : String(idx)); mk += '.';
    } else return;
    var lh = cs.lineHeight === 'normal' ? fs * 1.15 : num(cs.lineHeight), top = rect.y + num(cs.paddingTop) + num(cs.borderTopWidth);
    var base = top + (lh - fs * 1.117) / 2 + fs * 0.905;
    items.push({ y0: top, y1: top + lh, kind: 'text', ymid: top + lh / 2, gen: function (E) {
      var sg = segs(mk, fk); if (!sg.length) return ''; var fsPt = fs * E.f, wd = 0; sg.forEach(function (q) { wd += E.F[q.key].font.widthOfTextAtSize(q.text, fsPt * q.scale); });
      var s = 'q BT ' + rg(col) + ' rg 1 0 0 1 ' + n2(E.X(rect.x) - wd - fs * 0.35 * E.f) + ' ' + n2(E.Y(base)) + ' Tm ';
      sg.forEach(function (q) { s += '/' + E.F[q.key].name + ' ' + n2(fsPt * q.scale) + ' Tf 0 Ts ' + hexOf(E.F, q.key, q.text) + ' Tj '; });
      return s + 'ET Q\n';
    } });
  }

  function walk(el, items, O) {
    if (SKIP[el.tagName]) return;
    var cs = getComputedStyle(el); if (cs.display === 'none' || cs.visibility === 'hidden' && !el.children.length) return;
    if (cs.display === 'contents') { kids(el, items, O, cs); return; }
    var rc = el.getBoundingClientRect(), rect = relRect(rc, O), op = num(cs.opacity, 1);
    var clip = (cs.overflowX !== 'visible' || cs.overflowY !== 'visible') && /hidden|clip/.test(cs.overflowX + cs.overflowY);
    var pushedA = null, pushedC = null, tag = el.tagName, svgTag = tag.toLowerCase() === 'svg';
    if (op < 0.995 && !svgTag) {
      pushedA = { kind: 'push', y0: rect.y - 1, y1: rect.y + rect.h + 1, gen: function (E) { return 'q /' + E.reg.alpha(op) + ' gs\n'; } };
      items.push(pushedA);
    }
    if (rect.w > 0 && rect.h > 0) boxItems(items, rect.x, rect.y, rect.w, rect.h, cs, 1);
    if (clip && rect.w > 0 && rect.h > 0) {
      var bl = num(cs.borderLeftWidth), bt = num(cs.borderTopWidth), br = num(cs.borderRightWidth), bb = num(cs.borderBottomWidth);
      var cr = { x: rect.x + bl, y: rect.y + bt, w: rect.w - bl - br, h: rect.h - bt - bb, r: radii(cs, rect.w, rect.h) };
      pushedC = { kind: 'push', y0: rect.y - 1, y1: rect.y + rect.h + 1, gen: function (E) { return 'q ' + rrect(E, cr.x, cr.y, cr.w, cr.h, cr.r) + 'W n\n'; } };
      items.push(pushedC);
    }
    if (rect.w > 0 && rect.h > 0) pseudoItems(items, el, '::before', rect, O, cs);
    if (tag === 'LI') listMarker(items, el, cs, rect, O);
    if (tag === 'IMG') {
      var bl2 = num(cs.borderLeftWidth), bt2 = num(cs.borderTopWidth), pl2 = num(cs.paddingLeft), pt2 = num(cs.paddingTop);
      imageItem(items, el, rect.x + bl2 + pl2, rect.y + bt2 + pt2, rect.w - bl2 - num(cs.borderRightWidth) - pl2 - num(cs.paddingRight), rect.h - bt2 - num(cs.borderBottomWidth) - pt2 - num(cs.paddingBottom), cs, radii(cs, rect.w, rect.h));
    } else if (svgTag) {
      var vb = el.getAttribute('viewBox'), inner = { x: rect.x + num(cs.borderLeftWidth), y: rect.y + num(cs.borderTopWidth), w: rect.w - num(cs.borderLeftWidth) - num(cs.borderRightWidth), h: rect.h - num(cs.borderTopWidth) - num(cs.borderBottomWidth) };
      var sp = { kind: 'push', y0: inner.y - 1, y1: inner.y + inner.h + 1, gen: function (E) { return 'q ' + rrect(E, inner.x, inner.y, inner.w, inner.h, radii(cs, rect.w, rect.h)) + 'W n\n'; } };
      items.push(sp); Array.prototype.forEach.call(el.children, function (k) { svgWalk(items, k, el, O, op); }); items.push({ kind: 'pop', y0: inner.y - 1, y1: inner.y + inner.h + 1, gen: function () { return 'Q\n'; } });
    } else kids(el, items, O, cs);
    if (rect.w > 0 && rect.h > 0) pseudoItems(items, el, '::after', rect, O, cs);
    if (pushedC) items.push({ kind: 'pop', y0: rect.y - 1, y1: rect.y + rect.h + 1, gen: function () { return 'Q\n'; } });
    if (pushedA) items.push({ kind: 'pop', y0: rect.y - 1, y1: rect.y + rect.h + 1, gen: function () { return 'Q\n'; } });
  }
  function kids(el, items, O, cs) {
    var ns = el.childNodes;
    for (var i = 0; i < ns.length; i++) {
      var nd = ns[i];
      if (nd.nodeType === 3) textItems(items, nd, cs, O);
      else if (nd.nodeType === 1) walk(nd, items, O);
    }
  }

  /* ---------------------------------------------------------------- fabrication du PDF */
  function breakpoints(host) {
    var base = host.getBoundingClientRect().top, ys = [], heads = [];
    Array.prototype.forEach.call(host.querySelectorAll('tr,h2,h3,p,li,svg,img,.ex-box,.ex-visas,.nt,.row'), function (e) {
      var r = e.getBoundingClientRect(); if (r.height > 0) { var y = Math.round(r.top - base); ys.push(y); if (/^H[1-4]$/.test(e.tagName)) heads.push(y); }
    });
    ys.sort(function (a, b) { return a - b; }); heads.sort(function (a, b) { return a - b; }); ys.heads = heads; return ys;
  }
  function mkHost(root, wpx) {
    var host = d.createElement('div');
    host.style.cssText = 'position:fixed;left:-30000px;top:0;width:' + wpx + 'px;pointer-events:none;z-index:-1';
    var sty = d.createElement('style'); sty.textContent = R.allCss();
    host.appendChild(sty); host.appendChild(root); d.body.appendChild(host); return host;
  }
  function charSet(font) { var o = {}; (font.getCharacterSet() || []).forEach(function (c) { o[c] = 1; }); return o; }

  function makeFonts(doc, PL) {
    var SF = PL.StandardFonts, spec = { H: SF.Helvetica, HB: SF.HelveticaBold, HI: SF.HelveticaOblique, HBI: SF.HelveticaBoldOblique,
      T: SF.TimesRoman, TB: SF.TimesRomanBold, TI: SF.TimesRomanItalic, TBI: SF.TimesRomanBoldItalic,
      C: SF.Courier, CB: SF.CourierBold, CI: SF.CourierOblique, CBI: SF.CourierBoldOblique, S: SF.Symbol, Z: SF.ZapfDingbats };
    var F = {}, keys = Object.keys(spec), i = 0;
    return keys.reduce(function (p, k) {
      return p.then(function () { return doc.embedFont(spec[k]); }).then(function (f) { F[k] = { font: f, name: 'F' + (++i), set: charSet(f), ref: f.ref }; });
    }, Promise.resolve()).then(function () { return F; });
  }

  function vectorRun(opt) {
    var PL = w.PDFLib; if (!PL || !PL.PDFDocument) return Promise.reject(new Error('pdf-lib absent'));
    var S = R.sources();
    if (!S || !S.pages.length) { R.note('Ouvrez d’abord la note de calcul ou le plan d’exécution (bouton « Note de calcul » ou « Plan d’exécution »).', 'warn', 6000); return Promise.resolve(false); }
    var title = (d.title || 'Document'), nm = (S.root.querySelector('.ex-no,.ex-ttl b') || {}).textContent;
    var fileName = String(opt.name || ((nm ? nm.trim() + ' — ' : '') + 'Note de calcul')).replace(/[\\\/:*?"<>|]+/g, '-').slice(0, 110) + '.pdf';
    var total = S.pages.length, doc, reg = new Reg(), footCache = {}, pageCount = 0, base = { reg: reg, F: null, H: 0, cache: {} };
    try { window.dispatchEvent(new Event('beforeprint')); } catch (e) {}
    R.progress(0, total, 'Préparation…');
    var pagesDone = [];

    return PL.PDFDocument.create().then(function (dd) { doc = dd; return makeFonts(doc, PL); }).then(function (F) {
      FONTS = F; base.F = F;
      doc.setTitle(String(title)); doc.setProducer('Excellencia Building'); doc.setCreator('Excellencia Building — moteur PDF vectoriel'); doc.setLanguage('fr-FR');
      try { doc.setCreationDate(new Date()); } catch (e) {}

      function itemsOf(el, wpx, fixH, staticPos) {
        var root = R.wrapFor(el, wpx, staticPos ? { static: true } : null);
        if (fixH) { var cl = root.querySelector('.ex-cv'); if (cl) cl.style.height = fixH + 'px'; }
        var host = mkHost(root, wpx);
        var rr = root.getBoundingClientRect(), O = { x: rr.left, y: rr.top }, hh = Math.ceil(rr.height), ys = [];
        var items = []; var c0 = root.firstChild && root.firstChild.firstChild; if (c0) walk(c0, items, O);
        ys = breakpoints(host);
        host.remove(); return { items: items, hh: hh, ys: ys };
      }
      function footItems(kind, wpx) {
        if (footCache[kind] !== undefined) return footCache[kind];
        if (!S.foot) return (footCache[kind] = null);
        var r = itemsOf(S.foot, wpx, 0, true); r.hh = Math.max(14, r.hh + 2); return (footCache[kind] = r);
      }

      function emitSlice(items, E, s0, s1, clipRect) {
        var out = '', skip = 0, vis = [];
        out += 'q ' + clipRect + 'W n\n';
        for (var i = 0; i < items.length; i++) {
          var it = items[i];
          if (skip) { if (it.kind === 'push') skip++; else if (it.kind === 'pop') skip--; continue; }
          if (it.kind === 'push') { if (it.y1 < s0 - 1 || it.y0 > s1 + 1) { skip = 1; continue; } out += it.gen(E); continue; }
          if (it.kind === 'pop') { out += it.gen(E); continue; }
          if (it.kind === 'text') { if (!(it.ymid >= s0 && it.ymid < s1)) continue; }
          else if (it.y1 < s0 - 0.5 || it.y0 > s1 + 0.5) continue;
          out += it.gen(E);
        }
        return out + 'Q\n';
      }

      function addPage(content, wpt, hpt) {
        var pg = doc.addPage([wpt, hpt]); pagesDone.push({ pg: pg, content: content }); pageCount++; return pg;
      }

      var chain = Promise.resolve(), done = 0;
      S.pages.forEach(function (e, ix) {
        chain = chain.then(function () { R.progress(ix, total, 'Feuille ' + (ix + 1) + ' / ' + total); return R.tick(20); }).then(function () {
          var kind = R.kindOf(e), P = PAGES[kind], cw = Math.round((P.W - P.ml - P.mr) * MM), ch = Math.round((P.H - P.mt - P.mb) * MM);
          var isCover = /(^|\s)ex-cv(\s|$)/.test(e.className);
          var res = itemsOf(e, cw, isCover ? ch : 0, false), hh = res.hh, k = 1;
          if (kind !== 'a4' && hh > ch) k = ch / hh;
          var slices = [];
          if (kind === 'a4' && hh > ch + 2) {
            var start = 0;
            while (start < hh - 2) {
              var end = Math.min(hh, start + ch);
              if (end < hh) { var cut = 0; for (var i = 0; i < res.ys.length; i++) { if (res.ys[i] <= end && res.ys[i] > start + ch * 0.45) cut = res.ys[i]; } if (cut) { end = cut; var hs = res.ys.heads || [];   /* jamais un titre seul en bas de feuille : on coupe avant lui */
                for (var hi = hs.length - 1; hi >= 0; hi--) { if (hs[hi] < cut && cut - hs[hi] < 110 && hs[hi] > start + ch * 0.25) { end = hs[hi]; break; } } } }
              slices.push([start, end]); start = end;
            }
          } else slices.push([0, Math.min(hh, kind === 'a4' ? ch : hh)]);
          var Wpt = P.W / 25.4 * 72, Hpt = P.H / 25.4 * 72, f = PX * k;
          slices.forEach(function (sl, si) {
            base.H = Hpt;
            var s0 = sl[0], s1 = (si === slices.length - 1) ? hh + 2 : sl[1];
            var ox = P.ml * MM * PX, oy = P.mt * MM * PX, E = mkE(base, f, ox, oy, s0);
            var clipRect = n2(ox) + ' ' + n2(Hpt - oy - (s1 - s0) * f) + ' ' + n2(cw * f) + ' ' + n2((s1 - s0) * f + 0.5) + ' re ';
            var content = emitSlice(res.items, E, s0, s1, clipRect);
            /* pied de page commun (QR de vérification, n° de document) */
            var fc = footItems(kind, Math.round((P.W - P.ml - P.mr) * MM));
            if (fc) {
              var Hp = P.H * MM, footTop = Hp - fc.hh - 4 * MM * 0.6, Ef = mkE(base, PX, P.ml * MM * PX, footTop * PX, 0);
              content += emitSlice(fc.items, Ef, -1, fc.hh + 2, '0 0 ' + n2(Wpt) + ' ' + n2(Hpt) + ' re ');
            }
            /* filigrane BROUILLON */
            if (S.wm) {
              var wt = (S.wm.textContent || 'BROUILLON').trim() || 'BROUILLON', fsz = 96 * (kind === 'a4' ? 1 : 1.2) * PX, F0 = FONTS.HB, wd = F0.font.widthOfTextAtSize(wt.replace(/[^\x20-\xFF]/g, ''), fsz);
              var ang = Math.PI / 6, ca = Math.cos(ang), sa = Math.sin(ang), cx = Wpt / 2, cy = Hpt * (1 - 0.45);
              var gx = cx - (wd / 2) * ca + fsz * 0.35 * sa, gy = cy - (wd / 2) * sa - fsz * 0.35 * ca;
              content += 'q /' + reg.alpha(0.13) + ' gs BT 0.78 0.12 0.12 rg ' + n2(ca) + ' ' + n2(sa) + ' ' + n2(-sa) + ' ' + n2(ca) + ' ' + n2(gx) + ' ' + n2(gy) + ' Tm /' + F0.name + ' ' + n2(fsz) + ' Tf ' + hexOf(FONTS, 'HB', wt.replace(/[^\x20-\xFF]/g, '')) + ' Tj ET Q\n';
            }
            addPage(content, Wpt, Hpt);
          });
        }).then(function () { done++; });
      });

      return chain.then(function () {
        R.progress(total, total, 'Enregistrement…');
        var ctx = doc.context, pdfName = PL.PDFName;
        var fontD = {}; Object.keys(FONTS).forEach(function (k) { fontD[FONTS[k].name] = FONTS[k].ref; });
        var xo = {}, jobs = [];
        reg.imgList.forEach(function (im) {
          jobs.push((im.s.type === 'png' ? doc.embedPng(im.s.bytes) : doc.embedJpg(im.s.bytes)).then(function (e) { xo[im.name] = e.ref; }));
        });
        return Promise.all(jobs).then(function () {
          var gsD = {}; Object.keys(reg.gs).forEach(function (k) { if (/_a$/.test(k)) return; var a = reg.gs[k + '_a']; gsD[reg.gs[k]] = ctx.obj({ Type: 'ExtGState', ca: a, CA: a }); });
          var resObj = ctx.obj({ Font: fontD, XObject: xo, ExtGState: gsD, ProcSet: ['PDF', 'Text', 'ImageB', 'ImageC'] });
          var resRef = ctx.register(resObj);
          pagesDone.forEach(function (p) {
            p.pg.node.set(pdfName.of('Resources'), resRef);
            var st = ctx.flateStream(p.content); p.pg.node.addContentStream(ctx.register(st));
          });
          return doc.save({ useObjectStreams: false });
        });
      });
    }).then(function (bytes) {
      var blob = new Blob([bytes], { type: 'application/pdf' });
      return { blob: blob, name: fileName, pages: pageCount };
    });
  }

  /* ---------------------------------------------------------------- point d'entrée */
  function run(opt) {
    opt = opt || {};
    if (opt.raster || D.forceRaster || !w.PDFLib) { D.engine = 'raster'; return D.runRaster(opt); }
    return vectorRun(opt).then(function (r) {
      if (r === false) return false;
      D.engine = 'vector'; D.lastInfo = { pages: r.pages, bytes: r.blob.size, name: r.name };
      var finish = function () { try { window.dispatchEvent(new Event('afterprint')); } catch (e) {} };
      if (opt.noSave) { R.closeOverlay(); finish(); return { blob: r.blob, name: r.name }; }
      return R.save(r.blob, r.name).then(function () {
        try { if (opt.onBlob) opt.onBlob(r.blob, r.name); } catch (e) {}
        R.closeOverlay(); R.note('✓ PDF créé : ' + r.name + ' (' + r.pages + ' page' + (r.pages > 1 ? 's' : '') + ', texte sélectionnable)', 'ok', 6000); finish(); return true;
      });
    }).catch(function (err) {
      try { console.warn('[EXB PDF vectoriel] échec, retour au rendu en images :', err); } catch (e) {}
      D.lastError = String(err && err.stack || err); D.engine = 'raster';
      R.closeOverlay(); return D.runRaster(opt);
    });
  }
  D.run = run; D.runVector = vectorRun; D.vectorVersion = 'V245i';
})(window, document);
