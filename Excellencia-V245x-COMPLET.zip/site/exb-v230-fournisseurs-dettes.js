/* Excellencia Building V230 — 🤝 FOURNISSEURS & DETTES (Lot 2 du cahier « Portail Comptable V229+ »).
 * Vue unique : référentiel fournisseurs, commandes → réceptions → factures → paiements, échéancier des dettes, factures à contrôler,
 * relevé fournisseur. ADAPTATEUR : il LIT les données existantes (exb_suppliers, exb_v92_suppliers, exb_purchase_orders,
 * exb_v92_purchase_orders, exb_v92_supplier_invoices, exb_cash) et les demandes du Centre de réception (exb_cr_demandes).
 * Aucune double saisie : une facture déjà enregistrée n’est jamais ressaisie (une seule référence source) ; un doublon est bloqué.
 * Seule écriture : « Enregistrer la facture » ajoute UNE ligne dans exb_v92_supplier_invoices (clé existante, même format que
 *   createSupplierInvoice de V92, donc reprise telle quelle par la Comptabilité) + un lien dans exb_fd_liens et une trace dans exb_fd_audit.
 * Rien n’est payé ici : le règlement passe par le Centre de réception (autorisation Direction) puis la Trésorerie (Lot 3).
 * Ne remplace ni exb-compta*.js, ni exb-stock-plus.js, ni exb-v92-erp.js. Retirer : supprimer la balise <script src="exb-v230-fournisseurs-dettes.js">. */
(function (w, d) {
  'use strict';
  if (w.EXBFD) return;
  var KL = 'exb_fd_liens', KA = 'exb_fd_audit';
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nc(c) { c = String(c || 'USD').toUpperCase(); return /^(FC|CDF)$/.test(c) ? 'CDF' : c; }
  function nrm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
  function iso(x) { var s = String(x || '').slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ''; }
  function jour() { var n = new Date(); return n.getFullYear() + '-' + ('0' + (n.getMonth() + 1)).slice(-2) + '-' + ('0' + n.getDate()).slice(-2); }
  function ecartJours(a, b) { return Math.round((new Date(a + 'T00:00:00') - new Date(b + 'T00:00:00')) / 864e5); }
  function nf(n, c) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: c === 'CDF' ? 0 : 2, maximumFractionDigits: c === 'CDF' ? 0 : 2 }).replace(/\u202f/g, ' '); }
  function fm(o) { var k = Object.keys(o || {}).filter(function (c) { return Math.abs(o[c]) > 0.004; }); return k.length ? k.map(function (c) { return nf(o[c], c) + ' ' + c; }).join(' · ') : '—'; }
  function ajoute(o, c, v) { c = nc(c); o[c] = r2((o[c] || 0) + v); return o; }

  /* ---------- stockage (mêmes règles que les modules existants) ---------- */
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function raw(k) { var S = store(); try { return S ? S.getItem(k) : w.localStorage.getItem(k); } catch (e) { return null; } }
  function rdA(k) { try { var v = JSON.parse(raw(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, v) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(v)); else w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function peutEcrire() { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can('achats', 'ecrire'); } catch (e) { return true; } }
  function qui() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.nom)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }

  /* ---------- normalisation (fonctions pures, testées) ---------- */
  function nomFourn(x) { return x ? (x.name || x.nom || x.company || x.raison_sociale || x.supplier_name || '') : ''; }
  function unifierFournisseurs(a, b) {
    var out = [], seen = {};
    (a || []).concat(b || []).forEach(function (s) { var n = nomFourn(s), k = nrm(n); if (!k) return; if (seen[k]) { seen[k].ids.push(s.id); return; } seen[k] = { key: k, nom: n, ids: [s.id], tel: s.phone || s.tel || '', email: s.email || '', rccm: s.rccm || s.nif || '' }; out.push(seen[k]); });
    return out;
  }
  function trouveFourn(sups, ref) { var k = nrm(ref); if (!k) return null; return sups.filter(function (s) { return s.key === k || s.ids.indexOf(ref) >= 0; })[0] || null; }
  function normFacture(s, sups, cash) {
    var f = { id: s.id || '', no: s.no || s.number || s.ref || '', amount: r2(+s.amount || +s.total || +s.ttc || 0), cur: nc(s.currency || s.cur || s.devise), date: iso(s.date || s.invoice_date || s.created_at), due: iso(s.due || s.due_date || s.echeance || s.date_echeance), po: s.po || s.po_no || s.order || s.order_id || s.purchase_order || '', source: s.source || '' };
    var nom = s.supplier || s.supplier_name || s.fournisseur || s.supplier_id || ''; var sf = trouveFourn(sups, nom) || trouveFourn(sups, s.supplier_id); f.sup = sf ? sf.nom : String(nom); f.supKey = nrm(f.sup);
    var pay = (s.payments || []).reduce(function (a, p) { return a + (+p.amount || 0); }, 0), cs = 0, ids = [String(f.id), String(f.no)].filter(Boolean);
    (cash || []).forEach(function (x) { if (x && x.type === 'out' && x.ref && ids.indexOf(String(x.ref)) >= 0 && nc(x.currency) === f.cur) cs += +x.amount || 0; });
    f.paye = s.status === 'paid' ? f.amount : r2(Math.min(f.amount, Math.max(pay, cs))); f.solde = r2(f.amount - f.paye);
    return f;
  }
  function lignesCommande(p) { var o = 0, rc = 0; (p.lines || []).forEach(function (l) { var q = +l.q || 0, pu = +l.pu || 0; o += q * pu; rc += Math.min(+l.rec || 0, q) * pu; }); return { commande: r2(o), recu: r2(rc) }; }
  function normCommande(p, sups) {
    var t = lignesCommande(p), sf = trouveFourn(sups, p.supplier_id) || trouveFourn(sups, p.supplier_name || p.supplier);
    return { id: p.id || '', no: p.no || p.id || '', sup: sf ? sf.nom : (p.supplier_name || p.supplier || ''), supKey: sf ? sf.key : nrm(p.supplier_name || p.supplier), cur: nc(p.currency), date: iso(p.date), commande: t.commande, recu: t.recu, paye: r2((p.payments || []).reduce(function (a, x) { return a + (+x.amount || 0); }, 0)), projet: p.project_id || '' };
  }
  function rapprocher(cmds, facts) {
    return cmds.map(function (c) {
      var fs = facts.filter(function (f) { var r = nrm(f.po); return r && (r === nrm(c.no) || r === nrm(c.id)); }), fa = r2(fs.reduce(function (a, f) { return a + f.amount; }, 0)), fl = [];
      if (fa > c.recu + 0.005) fl.push('Facturé > reçu'); if (c.recu < c.commande - 0.005) fl.push('Reçu partiel'); if (!fa && c.recu > 0) fl.push('Reçu non facturé'); if (c.paye > Math.max(c.recu, fa) + 0.005) fl.push('Payé > reçu/facturé');
      return Object.assign({}, c, { facture: fa, aFacturer: r2(Math.max(0, c.recu - fa)), flags: fl });
    });
  }
  function tranche(due, auj) { if (!due) return 'Sans échéance'; var j = ecartJours(auj, due); return j <= 0 ? 'Non échu' : j <= 30 ? '1–30 j' : j <= 60 ? '31–60 j' : '> 60 j'; }
  var TRANCHES = ['Non échu', '1–30 j', '31–60 j', '> 60 j', 'Sans échéance'];
  function vieillissement(facts, auj) { var o = {}; TRANCHES.forEach(function (t) { o[t] = {}; }); facts.forEach(function (f) { if (f.solde > 0.004) ajoute(o[tranche(f.due, auj)], f.cur, f.solde); }); return o; }
  /* doublon : même fournisseur + même n° de facture, ou même fournisseur + même montant + même date (ignore soi-même et les liens déclarés) */
  function cleDoublons(x) { var k = []; if (x.supKey && x.no) k.push('n|' + x.supKey + '|' + nrm(x.no)); if (x.supKey && x.amount > 0 && x.date) k.push('m|' + x.supKey + '|' + x.amount + '|' + x.cur + '|' + x.date); return k; }
  function doublon(cand, liste) { var kc = cleDoublons(cand); return liste.filter(function (o) { if (o === cand || (cand.id && o.id === cand.id && o.origine === cand.origine)) return false; var ko = cleDoublons(o); return kc.some(function (k) { return ko.indexOf(k) >= 0; }); })[0] || null; }
  function valider(f) {
    var e = []; if (!String(f.sup || '').trim()) e.push('Choisissez le fournisseur.'); if (!String(f.no || '').trim()) e.push('Le numéro de la facture fournisseur est obligatoire.');
    if (!(+f.amount > 0)) e.push('Le montant doit être supérieur à zéro.'); if (!iso(f.date)) e.push('La date de la facture est obligatoire (AAAA-MM-JJ).'); if (f.due && !iso(f.due)) e.push('Échéance invalide (AAAA-MM-JJ).');
    if (iso(f.due) && iso(f.date) && f.due < f.date) e.push('L’échéance ne peut pas précéder la date de facture.'); return e;
  }
  function releve(sup, facts, cmds) {
    var L = [], solde = {};
    facts.filter(function (f) { return f.supKey === sup.key; }).forEach(function (f) {
      L.push({ date: f.date || '', type: 'Facture', ref: f.no || f.id, cur: f.cur, debit: 0, credit: f.amount });
      if (f.paye > 0) L.push({ date: f.due || f.date || '', type: 'Paiement', ref: f.no || f.id, cur: f.cur, debit: f.paye, credit: 0 });
    });
    cmds.filter(function (c) { return c.supKey === sup.key && c.paye > 0 && !facts.some(function (f) { var r = nrm(f.po); return r && (r === nrm(c.no) || r === nrm(c.id)); }); }).forEach(function (c) { L.push({ date: c.date, type: 'Paiement (commande)', ref: c.no, cur: c.cur, debit: c.paye, credit: 0 }); });
    L.sort(function (a, b) { return String(a.date).localeCompare(String(b.date)) || (a.type === 'Facture' ? -1 : 1); });
    L.forEach(function (x) { solde[x.cur] = r2((solde[x.cur] || 0) + x.credit - x.debit); x.solde = solde[x.cur]; });
    return { lignes: L, solde: solde };
  }

  /* ---------- lecture globale ---------- */
  function lire() {
    var sups = unifierFournisseurs(rdA('exb_suppliers'), rdA('exb_v92_suppliers')), cash = rdA('exb_cash'); try { if (w.exbCash && w.exbCash.length != null) cash = w.exbCash; } catch (e) {}
    var facts = rdA('exb_v92_supplier_invoices').filter(Boolean).map(function (s) { var f = normFacture(s, sups, cash); f.origine = 'v92'; return f; });
    var cmds = rapprocher(rdA('exb_purchase_orders').filter(function (p) { return p && !p.cancel; }).map(function (p) { return normCommande(p, sups); }), facts);
    var dem = rdA('exb_cr_demandes').filter(function (x) { return x && x.type === 'Facture fournisseur'; }).map(function (x) { var sf = trouveFourn(sups, x.tiers); return { id: x.id, origine: 'cr', ref: x.ref, no: x.numero_piece || '', sup: sf ? sf.nom : (x.tiers || ''), supKey: sf ? sf.key : nrm(x.tiers), amount: r2(+x.montant || 0), cur: nc(x.devise), date: iso(x.date_piece), due: iso(x.echeance || x.date_echeance), statut: x.statut, objet: x.objet || '' }; });
    return { sups: sups, facts: facts, cmds: cmds, dem: dem, liens: rdA(KL), auj: jour() };
  }
  function agregat(D) {
    return D.sups.map(function (s) {
      var a = { sup: s, commande: {}, recu: {}, facture: {}, paye: {}, dette: {}, aFacturer: {}, nbFact: 0, alertes: 0 };
      D.cmds.filter(function (c) { return c.supKey === s.key; }).forEach(function (c) { ajoute(a.commande, c.cur, c.commande); ajoute(a.recu, c.cur, c.recu); ajoute(a.aFacturer, c.cur, c.aFacturer); a.alertes += c.flags.length; });
      D.facts.filter(function (f) { return f.supKey === s.key; }).forEach(function (f) { ajoute(a.facture, f.cur, f.amount); ajoute(a.paye, f.cur, f.paye); ajoute(a.dette, f.cur, f.solde); a.nbFact++; if (f.solde > 0.004 && f.due && f.due < D.auj) a.alertes++; });
      return a;
    });
  }
  /* contrôle d’une demande « Facture fournisseur » du Centre : déjà enregistrée ? doublon ? supérieure au reçu non facturé ? */
  function controleDemande(dm, D) {
    var deja = D.facts.filter(function (f) { return f.supKey === dm.supKey && dm.no && nrm(f.no) === nrm(dm.no); })[0] || null, lien = D.liens.filter(function (l) { return l.demande_ref === dm.ref; })[0] || null;
    var autres = D.dem.filter(function (o) { return o.ref !== dm.ref && o.statut !== 'Rejetée' && o.statut !== 'Refusée'; }), dbl = doublon(dm, D.facts.concat(autres));
    var af = 0; D.cmds.filter(function (c) { return c.supKey === dm.supKey && c.cur === dm.cur; }).forEach(function (c) { af += c.aFacturer; });
    var alertes = []; if (!dm.supKey) alertes.push('Fournisseur non renseigné'); if (dbl && !deja) alertes.push('Doublon probable : ' + (dbl.ref || dbl.no || dbl.id)); if (dm.amount > af + 0.005 && !deja) alertes.push('Montant supérieur aux réceptions non facturées (' + nf(af, dm.cur) + ' ' + dm.cur + ')');
    return { deja: deja || (lien ? { no: lien.facture_no, id: lien.facture_id } : null), alertes: alertes, aFacturer: r2(af) };
  }
  function enregistrer(f, D, ctx) {
    ctx = ctx || {}; var e = valider(f); if (e.length) return { ok: false, err: e.join(' ') };
    var cand = { id: '', origine: 'v92', no: f.no, sup: f.sup, supKey: nrm(f.sup), amount: r2(f.amount), cur: nc(f.cur), date: iso(f.date) }, dbl = doublon(cand, D.facts.concat(D.dem.filter(function (x) { return x.ref !== f.demande_ref && x.statut !== 'Rejetée' && x.statut !== 'Refusée'; })));
    if (dbl) return { ok: false, err: 'Doublon : la facture ' + (dbl.no || dbl.ref || dbl.id) + ' du même fournisseur existe déjà (même numéro, ou même montant et même date). Elle garde sa référence source ; elle n’est pas ressaisie.' };
    if (f.po) { var c = D.cmds.filter(function (x) { return x.no === f.po || x.id === f.po; })[0]; if (c && r2(f.amount) > c.aFacturer + 0.005 && String(f.motif || '').trim().length < 3) return { ok: false, err: 'Le montant dépasse le reçu non facturé de la commande (' + nf(c.aFacturer, c.cur) + ' ' + c.cur + '). Saisissez un motif pour continuer.' }; }
    var now = ctx.now || new Date().toISOString(), id = 'ERP-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
    var ligne = { id: id, created_at: now, status: 'unpaid', supplier: f.sup, no: String(f.no).trim(), amount: r2(f.amount), currency: nc(f.cur), date: iso(f.date), due: iso(f.due), po: f.po || '', source: 'fournisseurs-dettes', demande_ref: f.demande_ref || '', motif_ecart: f.motif || '', saisi_par: ctx.qui || '' };
    return { ok: true, ligne: ligne, lien: { demande_ref: f.demande_ref || '', facture_id: id, facture_no: ligne.no, le: now, par: ctx.qui || '' } };
  }

  /* ---------- interface ---------- */
  var TAB = 'fournisseurs', SEL = '', ERR = '', FORM = null;
  function css() {
    if ($('fd_css')) return; var s = d.createElement('style'); s.id = 'fd_css';
    s.textContent = '#fd_c{background:#f5f8fd;color:#1b2a41;border-radius:14px;max-width:1100px;width:100%;padding:14px;font-family:inherit;box-sizing:border-box}#fd_c *{box-sizing:border-box}' +
      '#fd_c h3{margin:0;color:#0f2a5c}#fd_c .hd{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px}#fd_c .x{border:0;background:#0f2a5c;color:#fff;border-radius:8px;padding:7px 12px;cursor:pointer;font-weight:700}' +
      '#fd_c .tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}#fd_c .tabs button{border:1px solid #d5deee;background:#fff;border-radius:9px;padding:8px 12px;cursor:pointer;font-weight:600;color:#1b2a41}#fd_c .tabs button.on{background:#0f2a5c;color:#fff;border-color:#0f2a5c}' +
      '#fd_c .cd{background:#fff;border:1px solid #e3e9f3;border-radius:12px;padding:12px;margin-bottom:10px;overflow:hidden}#fd_c .tw{overflow-x:auto}#fd_c table{width:100%;border-collapse:collapse;font-size:13px}#fd_c th{text-align:left;color:#5b6b82;padding:7px 6px;border-bottom:1px solid #e3e9f3;white-space:nowrap}#fd_c td{padding:8px 6px;border-bottom:1px solid #eef2f9;vertical-align:top}' +
      '#fd_c tr.rw{cursor:pointer}#fd_c tr.rw:hover td{background:#f2f6fd}#fd_c .r{text-align:right;white-space:nowrap}#fd_c .pl{display:inline-block;border-radius:999px;padding:2px 9px;font-size:11.5px;font-weight:700;background:#fdecc8;color:#8a5200;margin:1px 2px 1px 0}#fd_c .pl.v{background:#dcfce7;color:#166534}#fd_c .pl.r{background:#fee4e2;color:#b42318}' +
      '#fd_c .er{background:#fee4e2;border:1px solid #f3b7b1;color:#8a1c14;border-radius:8px;padding:8px 10px;margin-bottom:8px}#fd_c .mu{color:#5b6b82;font-size:12.5px}#fd_c label{display:block;font-size:12.5px;color:#5b6b82;margin-top:6px}#fd_c input,#fd_c select{width:100%;padding:8px;border:1px solid #d5deee;border-radius:8px;font-size:14px;background:#fff;color:#1b2a41}' +
      '#fd_c .gr{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px}#fd_c .bt{background:#0f2a5c;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}#fd_c .bt.s{background:#e8edf6;color:#0f2a5c}' +
      '@media print{body:has(>#fd_ov)>*:not(#fd_ov){display:none!important}#fd_ov{position:static!important;background:#fff!important}#fd_c .tabs,#fd_c .x,#fd_c .no-print{display:none!important}}';
    d.head.appendChild(s);
  }
  function badge(t, c) { return '<span class="pl ' + (c || '') + '">' + esc(t) + '</span>'; }
  function tbl(h, rows) { return '<div class="tw"><table><thead><tr>' + h.map(function (x) { return '<th>' + x + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'; }
  function vFourn(D) {
    var A = agregat(D); if (!A.length) return '<div class="cd mu">Aucun fournisseur enregistré. Les fournisseurs créés dans Achats (V67 ou V92) apparaîtront ici, sans ressaisie.</div>';
    return '<div class="cd"><div class="mu" style="margin-bottom:6px">Référentiel unifié (lecture) : un fournisseur présent dans deux modules n’apparaît qu’une fois. Touchez une ligne pour son relevé.</div>' +
      tbl(['Fournisseur', 'Commandé', 'Reçu', 'À facturer', 'Facturé', 'Payé', 'Dette', ''], A.map(function (a) { return '<tr class="rw" data-s="' + esc(a.sup.key) + '"><td><b>' + esc(a.sup.nom) + '</b></td><td class="r">' + esc(fm(a.commande)) + '</td><td class="r">' + esc(fm(a.recu)) + '</td><td class="r">' + esc(fm(a.aFacturer)) + '</td><td class="r">' + esc(fm(a.facture)) + '</td><td class="r">' + esc(fm(a.paye)) + '</td><td class="r"><b>' + esc(fm(a.dette)) + '</b></td><td>' + (a.alertes ? badge(a.alertes + ' alerte' + (a.alertes > 1 ? 's' : '')) : '') + '</td></tr>'; })) + '</div>';
  }
  function vDettes(D) {
    var V = vieillissement(D.facts, D.auj), ouvertes = D.facts.filter(function (f) { return f.solde > 0.004; }).sort(function (a, b) { return String(a.due || '9999').localeCompare(String(b.due || '9999')); });
    var h = '<div class="cd"><b>Dettes par ancienneté d’échéance</b>' + tbl(TRANCHES.map(function (t) { return t; }), [ '<tr>' + TRANCHES.map(function (t) { return '<td class="r">' + esc(fm(V[t])) + '</td>'; }).join('') + '</tr>' ]) + '<div class="mu">Chaque devise reste séparée : aucun montant n’est converti ni additionné à une autre devise.</div></div>';
    h += '<div class="cd"><b>Factures fournisseurs à payer</b>' + (ouvertes.length ? tbl(['Fournisseur', 'Facture', 'Commande', 'Échéance', 'Reste dû', 'Statut'], ouvertes.map(function (f) { var j = f.due ? ecartJours(D.auj, f.due) : null; return '<tr><td>' + esc(f.sup) + '</td><td>' + esc(f.no || f.id) + '</td><td>' + esc(f.po || '—') + '</td><td>' + esc(f.due || '—') + '</td><td class="r"><b>' + esc(nf(f.solde, f.cur) + ' ' + f.cur) + '</b></td><td>' + (j != null && j > 0 ? badge('En retard de ' + j + ' j', 'r') : badge(j == null ? 'Sans échéance' : 'À échoir', j == null ? '' : 'v')) + '</td></tr>'; })) : '<div class="mu">Aucune facture fournisseur impayée.</div>') + '<div class="mu" style="margin-top:6px">Le règlement se prépare dans le Centre de réception (contrôle, puis autorisation de la Direction).</div></div>';
    return h;
  }
  function vControle(D) {
    var dem = D.dem.filter(function (x) { return ['Brouillon', 'À contrôler', 'Contrôlée', 'En attente d’autorisation', 'Autorisée'].indexOf(x.statut) >= 0; });
    var h = '<div class="cd"><b>Factures fournisseurs reçues par le Centre de réception</b><div class="mu" style="margin:4px 0 8px">Une facture déjà enregistrée est reconnue et n’est pas ressaisie. Sinon, enregistrez-la une seule fois ici : la Comptabilité la reprend.</div>';
    if (!dem.length) return h + '<div class="mu">Aucune demande « Facture fournisseur » en cours.</div></div>';
    h += tbl(['Réf.', 'Fournisseur', 'N° pièce', 'Montant', 'Statut', 'Contrôle', ''], dem.map(function (x, i) {
      var c = controleDemande(x, D), cel = c.deja ? badge('Déjà enregistrée : ' + (c.deja.no || c.deja.id), 'v') : (c.alertes.length ? c.alertes.map(function (a) { return badge(a); }).join('') : badge('Rien à signaler', 'v'));
      return '<tr><td>' + esc(x.ref) + '</td><td>' + esc(x.sup || '—') + '</td><td>' + esc(x.no || '—') + '</td><td class="r">' + esc(nf(x.amount, x.cur) + ' ' + x.cur) + '</td><td>' + esc(x.statut) + '</td><td>' + cel + '</td><td>' + (c.deja ? '' : '<button class="bt s" data-e="' + i + '">Enregistrer</button>') + '</td></tr>';
    })) + '</div>';
    return h + '<div class="cd"><b>Rapprochement commandes ↔ réceptions ↔ factures</b>' + (D.cmds.length ? tbl(['Commande', 'Fournisseur', 'Commandé', 'Reçu', 'Facturé', 'Payé', 'Contrôle'], D.cmds.map(function (c) { return '<tr><td>' + esc(c.no) + '</td><td>' + esc(c.sup) + '</td><td class="r">' + esc(nf(c.commande, c.cur) + ' ' + c.cur) + '</td><td class="r">' + esc(nf(c.recu, c.cur)) + '</td><td class="r">' + esc(nf(c.facture, c.cur)) + '</td><td class="r">' + esc(nf(c.paye, c.cur)) + '</td><td>' + (c.flags.length ? c.flags.map(function (f) { return badge(f, /Facturé >|Payé >/.test(f) ? 'r' : ''); }).join('') : badge('Conforme', 'v')) + '</td></tr>'; })) : '<div class="mu">Aucun bon de commande.</div>') + '</div>';
  }
  function vReleve(D) {
    var sel = D.sups.filter(function (s) { return s.key === SEL; })[0] || D.sups[0]; if (!sel) return '<div class="cd mu">Aucun fournisseur.</div>'; SEL = sel.key;
    var R = releve(sel, D.facts, D.cmds);
    return '<div class="cd"><div class="gr"><div><label>Fournisseur</label><select id="fd_sel">' + D.sups.map(function (s) { return '<option value="' + esc(s.key) + '"' + (s.key === sel.key ? ' selected' : '') + '>' + esc(s.nom) + '</option>'; }).join('') + '</select></div><div style="align-self:end"><button class="bt s no-print" id="fd_csv">Exporter CSV</button> <button class="bt s no-print" id="fd_prt">Imprimer</button></div></div>' +
      '<h4 style="margin:10px 0 4px">Relevé — ' + esc(sel.nom) + '</h4>' + (R.lignes.length ? tbl(['Date', 'Opération', 'Référence', 'Devise', 'Débit (payé)', 'Crédit (facturé)', 'Solde'], R.lignes.map(function (x) { return '<tr><td>' + esc(x.date) + '</td><td>' + esc(x.type) + '</td><td>' + esc(x.ref) + '</td><td>' + x.cur + '</td><td class="r">' + (x.debit ? esc(nf(x.debit, x.cur)) : '') + '</td><td class="r">' + (x.credit ? esc(nf(x.credit, x.cur)) : '') + '</td><td class="r"><b>' + esc(nf(x.solde, x.cur)) + '</b></td></tr>'; })) : '<div class="mu">Aucune opération.</div>') + '<p><b>Solde dû : ' + esc(fm(R.solde)) + '</b></p></div>';
  }
  function vForm(D) {
    var f = FORM, supOpts = D.sups.map(function (s) { return '<option' + (s.nom === f.sup ? ' selected' : '') + '>' + esc(s.nom) + '</option>'; }).join(''), cm = D.cmds.filter(function (c) { return !f.sup || c.supKey === nrm(f.sup); });
    return '<div class="cd"><h4 style="margin:0 0 6px">Enregistrer la facture fournisseur' + (f.demande_ref ? ' — demande ' + esc(f.demande_ref) : '') + '</h4>' + (ERR ? '<div class="er">' + ERR + '</div>' : '') +
      '<div class="gr"><div><label>Fournisseur</label><select id="ff_sup"><option value=""></option>' + supOpts + '</select></div><div><label>Commande liée (facultatif)</label><select id="ff_po"><option value=""></option>' + cm.map(function (c) { return '<option value="' + esc(c.no) + '"' + (c.no === f.po ? ' selected' : '') + '>' + esc(c.no + ' — à facturer ' + nf(c.aFacturer, c.cur) + ' ' + c.cur) + '</option>'; }).join('') + '</select></div>' +
      '<div><label>N° de la facture fournisseur</label><input id="ff_no" value="' + esc(f.no) + '"></div><div><label>Montant</label><input id="ff_am" inputmode="decimal" value="' + esc(f.amount || '') + '"></div><div><label>Devise</label><select id="ff_cu"><option' + (f.cur === 'USD' ? ' selected' : '') + '>USD</option><option' + (f.cur === 'CDF' ? ' selected' : '') + '>CDF</option></select></div>' +
      '<div><label>Date de la facture</label><input id="ff_dt" type="date" value="' + esc(f.date) + '"></div><div><label>Échéance</label><input id="ff_du" type="date" value="' + esc(f.due) + '"></div><div><label>Motif (si au-dessus du reçu non facturé)</label><input id="ff_mo" value="' + esc(f.motif || '') + '"></div></div>' +
      '<p><button class="bt" id="ff_ok">Enregistrer</button> <button class="bt s" id="ff_no_">Annuler</button></p><div class="mu">Ajoute une seule ligne dans les factures fournisseurs existantes ; rien n’est payé et aucune écriture de caisse n’est créée.</div></div>';
  }
  function paint() {
    var c = $('fd_c'); if (!c) return; var D = lire(), T = [['fournisseurs', '🤝 Fournisseurs'], ['dettes', '🧾 Dettes & échéances'], ['controle', '✔ Factures à contrôler'], ['releve', '📄 Relevé']];
    c.innerHTML = '<div class="hd"><h3>🤝 Fournisseurs & dettes</h3><button class="x" id="fd_x">Fermer ✕</button></div><div class="tabs">' + T.map(function (t) { return '<button data-t="' + t[0] + '" class="' + (TAB === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      (FORM ? vForm(D) : (ERR ? '<div class="er">' + ERR + '</div>' : '') + ({ fournisseurs: vFourn, dettes: vDettes, controle: vControle, releve: vReleve })[TAB](D));
    $('fd_x').onclick = close; c.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { TAB = b.getAttribute('data-t'); FORM = null; ERR = ''; paint(); }; });
    c.querySelectorAll('tr[data-s]').forEach(function (r) { r.onclick = function () { SEL = r.getAttribute('data-s'); TAB = 'releve'; paint(); }; });
    var s = $('fd_sel'); if (s) s.onchange = function () { SEL = s.value; paint(); };
    var dem = D.dem.filter(function (x) { return ['Brouillon', 'À contrôler', 'Contrôlée', 'En attente d’autorisation', 'Autorisée'].indexOf(x.statut) >= 0; });
    c.querySelectorAll('[data-e]').forEach(function (b) { b.onclick = function () { var x = dem[+b.getAttribute('data-e')]; FORM = { sup: x.sup, no: x.no, amount: x.amount, cur: x.cur, date: x.date, due: x.due, po: '', motif: '', demande_ref: x.ref }; ERR = ''; paint(); }; });
    if ($('ff_ok')) { $('ff_no_').onclick = function () { FORM = null; ERR = ''; paint(); }; $('ff_sup').onchange = function () { FORM.sup = this.value; lireForm(); paint(); }; $('ff_ok').onclick = function () { lireForm(); sauver(D); }; }
    if ($('fd_csv')) $('fd_csv').onclick = function () { exportCsv(D); }; if ($('fd_prt')) $('fd_prt').onclick = function () { try { w.print(); } catch (e) {} };
  }
  function lireForm() { FORM.sup = $('ff_sup').value; FORM.po = $('ff_po').value; FORM.no = $('ff_no').value; FORM.amount = $('ff_am').value.replace(',', '.'); FORM.cur = $('ff_cu').value; FORM.date = $('ff_dt').value; FORM.due = $('ff_du').value; FORM.motif = $('ff_mo').value; }
  function sauver(D) {
    if (!peutEcrire()) { ERR = 'Droits insuffisants pour enregistrer une facture fournisseur.'; return paint(); }
    var r = enregistrer(Object.assign({}, FORM, { amount: +FORM.amount }), D, { qui: qui() }); if (!r.ok) { ERR = esc(r.err); return paint(); }
    var all = rdA('exb_v92_supplier_invoices'); all.unshift(r.ligne); if (!wr('exb_v92_supplier_invoices', all)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); }
    var li = rdA(KL); li.push(r.lien); wr(KL, li); var au = rdA(KA); au.push({ le: r.lien.le, par: r.lien.par, action: 'facture_fournisseur_enregistree', facture: r.ligne.no, fournisseur: r.ligne.supplier, montant: r.ligne.amount, devise: r.ligne.currency, demande: r.lien.demande_ref, motif: r.ligne.motif_ecart }); wr(KA, au);
    try { w.EXB_CORE && w.EXB_CORE.audit && w.EXB_CORE.audit('supplier_invoice_created', 'Facture fournisseur ' + r.ligne.id, 'achats', r.ligne.id); } catch (e) {}
    FORM = null; ERR = ''; TAB = 'dettes'; paint();
  }
  function exportCsv(D) {
    var sel = D.sups.filter(function (s) { return s.key === SEL; })[0]; if (!sel) return; var R = releve(sel, D.facts, D.cmds);
    var q = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var csv = '\ufeff' + ['Date', 'Opération', 'Référence', 'Devise', 'Débit', 'Crédit', 'Solde'].join(';') + '\n' + R.lignes.map(function (x) { return [x.date, x.type, x.ref, x.cur, x.debit, x.credit, x.solde].map(q).join(';'); }).join('\n');
    try { var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = 'releve-' + sel.key.replace(/ /g, '-') + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { d.body.removeChild(a); }, 500); } catch (e) {}
  }
  function close() { var o = $('fd_ov'); if (o) o.remove(); }
  function open(tab) {
    close(); css(); TAB = tab || 'fournisseurs'; FORM = null; ERR = '';
    var o = d.createElement('div'); o.id = 'fd_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9990;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.onclick = function (e) { if (e.target === o) close(); }; o.innerHTML = '<div id="fd_c"></div>'; d.body.appendChild(o); paint();
  }
  function mount() {
    if ($('bfd')) return; var a = $('bcr') || $('bcompta'); if (!a || !a.parentNode) return;
    var b = d.createElement('button'); b.id = 'bfd'; b.textContent = '🤝 Fournisseurs & dettes'; b.onclick = function () { open('fournisseurs'); }; a.parentNode.insertBefore(b, a.nextSibling);
  }
  function enregistrerModule() {
    try { if (w.EXB_MODULES && !w.EXB_MODULES.some(function (m) { return m.id === 'fournisseursDettes'; })) w.EXB_MODULES.push({ id: 'fournisseursDettes', name: 'Fournisseurs & dettes', area: 'Finance', icon: '🤝', status: 'nouveau', deps: ['fournisseurs', 'achats', 'comptabilite'] }); } catch (e) {}
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'fournisseurs-dettes', name: 'Fournisseurs & dettes', version: '230.0.0', area: 'Finance', provides: ['compta.fournisseurs', 'compta.dettes'] }); } catch (e) {}
  }
  function start() { mount(); enregistrerModule(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000); }
  w.EXBFD = { open: open, pure: { nrm: nrm, unifierFournisseurs: unifierFournisseurs, normFacture: normFacture, normCommande: normCommande, rapprocher: rapprocher, vieillissement: vieillissement, tranche: tranche, doublon: doublon, valider: valider, releve: releve, controleDemande: controleDemande, enregistrer: enregistrer, agregat: agregat } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
