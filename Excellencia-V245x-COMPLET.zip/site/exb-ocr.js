/* Excellencia Building V153 — OCR du Scanner (hors-ligne, Tesseract.js servi avec l'application).
 * Lit le texte des pages numérisées et PRÉ-REMPLIT les champs vides de la fiche de vérification (titre, type, projet, client, mots-clés).
 * Rien n'est déposé automatiquement : la vérification humaine reste obligatoire. Sans les fichiers de vendor/tesseract/, le bouton explique quoi installer.
 * Retrait : supprimer la balise <script src="exb-ocr.js">. */
(function (w) {
  'use strict';
  var d = w.document, $ = function (i) { return d && d.getElementById(i); };
  var BASE = 'vendor/tesseract/', LANG = 'fra', MAXPAGES = 5, MAXPX = 2200;
  var STOP = 'dans pour avec cette entre sont plus tout tous leur leurs mais comme aussi sans sous ainsi vous nous elle elles votre notre dont donc alors afin chez selon cela celui celle ceux depuis lors être avoir fait faire ont les des une aux par sur est que qui pas ces ses son sa le la un de du en et ou au'.split(' ');
  var KW = [['facture', /\bfacture\b|\binvoice\b/i], ['devis', /\bdevis\b|\bquotation\b/i], ['contrat', /\bcontrat\b|\bconvention\b/i], ['pv', /proc[eè]s[- ]verbal|\bP\.?V\.? de\b|r[ée]ception des travaux/i], ['note', /note de calcul/i], ['plan', /\bplan\b|\bcoupe\b|\bfa[cç]ade\b|\bcartouche\b/i], ['rapport', /\brapport\b/i], ['courrier', /\bobjet\s*:|\bmonsieur\b|\bmadame\b|\bcordialement\b/i]];
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }

  /* --- extraction pure (testable sans navigateur) --- */
  function extract(text, ctx) {
    ctx = ctx || {}; text = String(text || '').replace(/\r/g, ''); var out = {}, types = ctx.types || {};
    var lines = text.split('\n').map(function (l) { return l.replace(/[|_~=]{2,}/g, ' ').replace(/\s+/g, ' ').trim(); }).filter(function (l) { return (l.match(/[A-Za-zÀ-ÿ]/g) || []).length >= 4; });
    if (lines.length) out.titre = lines[0].slice(0, 120);
    for (var i = 0; i < KW.length; i++) if (KW[i][1].test(text) && (!Object.keys(types).length || types[KW[i][0]])) { out.type = KW[i][0]; break; }
    var nt = norm(text);
    function single(list, keys) { var hit = []; (list || []).forEach(function (x) { keys.forEach(function (k) { var n = x && x[k] ? norm(x[k]) : ''; if (n.length >= 4 && nt.indexOf(n) >= 0 && hit.indexOf(x[k]) < 0) hit.push(x[k]); }); }); return hit.length === 1 ? hit[0] : null; }
    var p = single(ctx.projects, ['name', 'title', 'nom']), c = single(ctx.clients, ['full_name', 'company']);
    if (p) out.projet = p; if (c) out.client = c;
    var f = {}; norm(text).replace(/[^a-z0-9]+/g, ' ').split(' ').forEach(function (x) { if (x.length >= 5 && !/^\d+$/.test(x) && STOP.indexOf(x) < 0) f[x] = (f[x] || 0) + 1; });
    var ks = Object.keys(f).filter(function (k) { return f[k] >= 2; }).sort(function (a, b) { return f[b] - f[a] || a.localeCompare(b); }).slice(0, 6);
    if (ks.length) out.motsCles = ks.join(', ');
    var num = text.match(/\b(?:facture|devis|contrat|r[ée]f[ée]rence|n[°o])\s*[:\-]?\s*([A-Z0-9][A-Z0-9\/\-.]{2,20})/i); if (num) out.numero = num[1];
    return out;
  }

  /* --- moteur navigateur --- */
  var lib = null, worker = null;
  function absBase() { try { return new URL(BASE, (d && d.baseURI) || w.location.href).href; } catch (e) { return BASE; } }
  function loadScript(src) { return new Promise(function (ok, ko) { var s = d.createElement('script'); s.src = src; s.onload = ok; s.onerror = function () { ko(new Error('absent')); }; d.head.appendChild(s); }); }
  async function getWorker(onp) {
    if (worker) return worker;
    if (!w.Tesseract) await loadScript(absBase() + 'tesseract.min.js');
    if (!w.Tesseract || !w.Tesseract.createWorker) throw new Error('absent');
    /* V185b : Tesseract crée le worker depuis un blob ; un chemin RELATIF y est invalide (« importScripts … The URL 'vendor/tesseract/worker.min.js' is invalid »).
     * On passe donc des URL ABSOLUES (même origine : https, app:// ou file://) et on lance le worker directement depuis son fichier. */
    var ABS = absBase();
    worker = await w.Tesseract.createWorker(LANG, 1, { workerPath: ABS + 'worker.min.js', corePath: ABS, langPath: ABS, workerBlobURL: false, gzip: true, logger: function (m) { if (onp && m && m.status === 'recognizing text') onp(m.progress || 0); } });
    return worker;
  }
  function small(c) { var k = Math.min(1, MAXPX / Math.max(c.width, c.height)); if (k >= 1) return c; var n = d.createElement('canvas'); n.width = Math.round(c.width * k); n.height = Math.round(c.height * k); n.getContext('2d').drawImage(c, 0, 0, n.width, n.height); return n; }
  async function run(status) {
    var cs = (w.EXBSC && w.EXBSC.pages ? w.EXBSC.pages() : []).slice(0, MAXPAGES); if (!cs.length) throw new Error('vide');
    var txt = [], wk; try { wk = await getWorker(function (p) { status('Lecture… ' + Math.round(p * 100) + ' %'); }); } catch (e) { var er = new Error('absent'); throw er; }
    for (var i = 0; i < cs.length; i++) { status('Page ' + (i + 1) + '/' + cs.length + '…'); var r = await wk.recognize(small(cs[i])); txt.push((r && r.data && r.data.text) || ''); }
    return txt.join('\n');
  }
  function ctx() { return { types: (w.EXBSC && w.EXBSC.types && w.EXBSC.types()) || {}, projects: w.exbProjects, clients: w.exbClients }; }
  function fill(o) {
    var map = { titre: 'sc_t', type: 'sc_ty', projet: 'sc_p', client: 'sc_c', motsCles: 'sc_m' }, done = [];
    Object.keys(map).forEach(function (k) { var e = $(map[k]); if (e && o[k] && !String(e.value || '').trim()) { e.value = o[k]; done.push(k); } });
    return done;
  }
  async function click() {
    var st = $('sc_ocr_st'), btn = $('sc_ocr'); function say(t) { if (st) st.textContent = t; }
    btn.disabled = true;
    try {
      var text = await run(say), o = extract(text, ctx()), got = fill(o);
      try { w.EXBCore && w.EXBCore.audit.log('scanner.ocr', o.numero || '', { champs: got.join(','), car: text.length }); } catch (e) {}
      say(got.length ? 'Champs pré-remplis : ' + got.join(', ') + '. Vérifiez-les avant le dépôt.' : 'Texte lu, mais aucun champ vide à remplir ou rien de reconnu.');
      var pre = $('sc_ocr_tx'); if (pre) pre.textContent = text.slice(0, 4000);
    } catch (e) {
      say(e.message === 'absent' ? 'OCR non installé : copiez les 7 fichiers de « site/vendor/tesseract/ » (partie 2 OCR, voir LISEZ-MOI-OCR.md ; vérification : node scripts/verifier-ocr.js), puis rechargez l\'application.' : e.message === 'vide' ? 'Ajoutez d\'abord une page.' : 'Lecture impossible : ' + e.message);
    }
    btn.disabled = false;
  }
  function mount() {
    var f = $('sc_f'); if (!f || $('sc_ocr')) return;
    var box = d.createElement('div'); box.innerHTML = '<button type="button" id="sc_ocr">🔤 Lire le texte (OCR)</button> <span id="sc_ocr_st" style="font-size:12px;opacity:.8"></span><details style="font-size:12px"><summary>Texte lu</summary><pre id="sc_ocr_tx" style="white-space:pre-wrap;max-height:160px;overflow:auto"></pre></details>';
    f.insertBefore(box, f.children[1] || null); $('sc_ocr').onclick = click;
  }
  w.EXBOCR = { extract: extract, config: { base: BASE, lang: LANG } };
  if (d) { setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 1500); try { w.EXBCore && w.EXBCore.modules.register({ id: 'scanner-ocr', name: 'Scanner OCR', version: '153.0.0', deps: [], area: 'Infrastructure' }); } catch (e) {} }
})(typeof window !== 'undefined' ? window : globalThis);
if (typeof module !== 'undefined') module.exports = (typeof window !== 'undefined' ? window : globalThis).EXBOCR;
