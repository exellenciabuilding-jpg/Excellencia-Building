# V245s — Menu principal par postes (appliqué sur la V245r)

Fichiers remplacés par les versions fournies : `exb-v99r-shell.js`, `exb-ux-v100.js`, `sw.js` (étiquette de cache `v245s-…`). Aucune migration SQL.

- Menu principal regroupé par poste (Direction, Comptable, Ingénieur, Architecture, Chantier, Formation, RH, Commercial, Achats, Magasin), avec « Autres modules » pour ce qui n'appartient à aucun poste. Fil d'Ariane « ← poste » conservé en ouvrant un module depuis un poste.
- Pièces écrites (`exbPieBtn`) ajoutées aux postes concernés ; modules plans/BIM déplacés vers le poste Architecture.
- `exb-ux-v100.js` : le menu latéral se referme aussi après un clic sur un poste (`.xd`).

Vérifié : contrôle de syntaxe des 3 fichiers ; chargement de `index.html` dans Chromium (menu par postes affiché, 0 erreur JavaScript) ; `calcul-structure/poutre-continue.html` charge `EXBPCONT` et `EXBPA` ; tests `test-poutre-continue.js` (57), `test-poutre-appuis.js` (74), `test-poutre-note.js` (6) sans échec.
Remarque : `exb-poutre-note.js`, chargé par `poutre-continue.html`, n'est pas dans la liste de préchargement hors-ligne de `sw.js` (il est mis en cache à la première ouverture de la page).
