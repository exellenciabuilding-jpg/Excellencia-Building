/* exb-identite.js (V99k) — UNE SEULE identité pour tous les documents remis au client.
 * Nom, slogan, téléphone, e-mail, adresse, logo, mentions légales, lieu de signature, signature + cachet.
 * Utilisé automatiquement par : devis (métré + devis rapide), fiches du personnel, dossiers/fiches participants,
 * rapports, exports PDF (EXBPdf) et impressions. Aucune donnée n'est envoyée en ligne. */
window.EXBId = (function () {
  'use strict';
  var KEY = 'EXB_IDENTITE_V1';
  var ORIGIN = 'Excellencia Building';
  /* valeurs d'origine de l'application (déjà présentes dans l'affiche : Kinshasa, RDC / téléphone / e-mail) */
  var BASE = { phone: '+243 810 644 554', email: 'Excellenciabuilding@gmail.com', address: 'Kinshasa, RDC', country: 'République Démocratique du Congo', tag: 'Ingénierie & Construction', dg: 'Ir Ibwampere Ngwala Louis' };

  function own() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function setExtra(p) { var s = own(); Object.keys(p).forEach(function (k) { s[k] = p[k]; }); try { localStorage.setItem(KEY, JSON.stringify(s)); return true; } catch (e) { return false; } }
  function s(v) { return String(v == null ? '' : v).trim(); }

  /* V236j : textes propres à l'entreprise d'origine (utilisés seulement tant que le nom n'a pas changé et que le champ est vide) */
  var BASE_SPEC = 'ARCHITECTURE  •  INGÉNIERIE  •  RÉALISATION', BASE_MOTTO = 'Construire aujourd’hui, bâtir demain';

  function get() {
    var B = window.EXB_BRAND || {}, g = {}, p = {}, o = own();
    try { g = (typeof getBrand === 'function' && getBrand()) || {}; } catch (e) {}
    try { p = (typeof load === 'function' && load('exb_poster_data', null)) || {}; } catch (e) {}
    var name = s(B.name) && s(B.name) !== ORIGIN ? s(B.name) : (s(g.name) || s(B.name) || ORIGIN);
    var original = name.toLowerCase() === ORIGIN.toLowerCase();
    var logo = '';
    if (s(B.logo)) logo = B.logo; else { try { logo = typeof getLogo === 'function' ? getLogo('exb') : ''; } catch (e) {} }
    if (!logo && original) logo = 'icon-192.png';  /* une entreprise cliente sans logo n'affiche jamais celui de l'éditeur d'origine */
    var phone = s(o.phone) || s(B.phone) || s(p.p_contact_phone) || (original ? BASE.phone : '');
    var email = s(o.email) || s(B.email) || s(p.p_contact_email) || (original ? BASE.email : '');
    var address = s(o.address) || s(B.address) || s(p.p_contact_address) || (original ? BASE.address : '');
    return {
      name: name,
      tagline: s(B.tagline) || (original ? BASE.tag : ''),
      phone: phone, email: email, address: address,
      country: s(B.country) || (original ? BASE.country : ''),
      logo: logo,
      legal: s(o.legal), footer: s(o.footer), website: s(o.website),
      dg: s(o.dg) || (original ? BASE.dg : ''),
      dgRole: s(o.dgRole) || 'Directeur Général',
      city: s(o.city) || (original ? 'Kinshasa' : ''),
      specialties: s(o.specialties) || s(B.specialties) || (original ? BASE_SPEC : ''),
      banner: s(o.banner) || s(B.banner),
      motto: s(o.motto) || s(B.motto) || (original ? BASE_MOTTO : ''),
      primary: s(B.primary), secondary: s(B.secondary), accent: s(B.accent)
    };
  }
  /* Bandeau du bas des PDF : texte saisi, sinon « NOM  •  spécialités ». */
  function bannerLine(I) { I = I || get(); var b = s(I.banner); return b && b.toLowerCase() !== s(I.specialties).toLowerCase() ? b : ''; }
  /* Palette des PDF (valeurs 0..1) : les couleurs d'origine restent identiques ; une couleur modifiée dans les paramètres les remplace. */
  function palette(I) {
    I = I || get();
    var P = { NAVY: [0.090, 0.208, 0.396], BLUE: [0.125, 0.286, 0.541], BAND: [0.918, 0.941, 0.984], SOFT: [0.95, 0.97, 0.99], GOLD: [0.769, 0.604, 0.220], GOLDTXT: [0.62, 0.47, 0.13], GOLDLT: [0.95, 0.82, 0.40] };
    function hex(v) { var m = /^#?([0-9a-f]{6})$/i.exec(s(v)); if (!m) return null; var n = parseInt(m[1], 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; }
    function diff(v, origin) { return s(v).toLowerCase() !== origin ? hex(v) : null; }
    function mix(c, t, k) { return c.map(function (x) { return x + (t - x) * k; }); }
    /* fond portant du texte blanc, ou texte sur fond blanc : on assombrit une couleur trop claire */
    function dark(c, max) { var n = 0; while (n++ < 20 && 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2] > max) c = mix(c, 0, 0.12); return c; }
    var p = diff(I.primary, '#173565'), q = diff(I.secondary, '#0f4aa8'), a = diff(I.accent, '#c49a38');
    if (p) { P.NAVY = dark(p, 0.35); P.BLUE = dark(q || p, 0.40); P.BAND = mix(p, 1, 0.92); P.SOFT = mix(p, 1, 0.96); }
    else if (q) { P.BLUE = dark(q, 0.40); }
    if (a) { P.GOLD = a; P.GOLDTXT = dark(a, 0.50); P.GOLDLT = mix(a, 1, 0.30); }
    return P;
  }
  /* V236m : habille en couleurs de l'entreprise un morceau de CSS / HTML de document (impression) : les couleurs d'origine
   * (#173565 bleu, #c49a38 / #c8962e / #c9a227 or, #8a6a1c or foncé, #12305e texte, #eef2fa / #e8edf5 bandeaux) sont remplacées
   * seulement si l'entreprise a choisi d'autres couleurs dans Paramètres. Inchangé sinon. */
  function theme(str, I) {
    str = String(str == null ? '' : str); I = I || get();
    var lc = function (v) { return s(v).toLowerCase(); }, P = palette(I);
    var hx = function (a) { return '#' + a.map(function (x) { return ('0' + Math.round(Math.max(0, Math.min(1, x)) * 255).toString(16)).slice(-2); }).join(''); };
    if (lc(I.primary) && lc(I.primary) !== '#173565') { str = str.replace(/#173565|#12305e/gi, hx(P.NAVY)).replace(/#eef2fa|#e8edf5/gi, hx(P.BAND)); }
    if (lc(I.accent) && lc(I.accent) !== '#c49a38') { str = str.replace(/#c49a38|#c8962e|#c9a227/gi, hx(P.GOLD)).replace(/#8a6a1c/gi, hx(P.GOLDTXT)); }
    return str;
  }
  function contactLine(I) { I = I || get(); return [I.phone ? 'Tél : ' + I.phone : '', I.email ? 'E-mail : ' + I.email : ''].filter(Boolean).join('   ·   '); }
  function placeLine(I) { I = I || get(); var a = I.address, c = I.country; var dit = a && c && (a.toLowerCase().indexOf(c.toLowerCase()) >= 0 || (/d[ée]mocratique\s+du\s+congo/i.test(c) && /\bR\.?\s?D\.?\s?C\b|\bRD\s?Congo\b/i.test(a))); return [a, c && !dit ? c : ''].filter(Boolean).join(', '); }
  /* Mention de bas de page : ignorée si elle ne fait que redire le nom, la ville, l'adresse ou le pays déjà imprimés en en-tête. */
  function footerExtra(I) { I = I || get(); function n(x) { return s(x).toLowerCase().replace(/[^a-z0-9à-ÿ]+/g, ' ').trim(); } var r = ' ' + n(I.footer) + ' '; [I.name, I.address, I.country, I.city, I.tagline, I.website, 'rdc'].map(n).filter(Boolean).forEach(function (m) { r = r.split(' ' + m + ' ').join(' '); }); return r.trim() ? s(I.footer) : ''; }
  function legalLine(I) { I = I || get(); return I.legal ? I.legal.split(/\r?\n+/).map(function (x) { return x.trim(); }).filter(Boolean).join('  ·  ') : ''; }

  /* Nom du Directeur Général : une seule saisie, reprise partout (reçus, certificats, devis, factures, PDF). */
  function applyDg(force) {
    var I = get(), nm = I.dg; if (!nm) return;
    [].forEach.call(document.querySelectorAll('.exb-dg'), function (e) { e.textContent = nm; });
    var inp = document.getElementById('director');
    if (inp) { if (!inp.dataset.dgBound) { inp.dataset.dgBound = '1'; inp.addEventListener('input', function () { inp.dataset.touched = '1'; }); } if (force || inp.dataset.touched !== '1') inp.value = nm; }
  }
  (function () { var n = 0, t = setInterval(function () { n++; try { applyDg(false); } catch (e) {} if (n > 12) clearInterval(t); }, 700); })();

  /* V236j : champs préremplis des reçus, certificats et affiches. On ne remplace que les champs encore à leur valeur d'origine
   * (rien de ce que l'utilisateur a saisi ou enregistré n'est écrasé). */
  function applyForms() {
    var I = get(), w2 = I.name.split(/\s+/), t = new Date(), today = ('0' + t.getDate()).slice(-2) + '/' + ('0' + (t.getMonth() + 1)).slice(-2) + '/' + t.getFullYear();
    var V = { p_company_dark: w2[0] || '', p_company_light: w2.slice(1).join(' '), p_tagline_company: I.tagline, reservation_phone: I.phone, rissued: today, issued_date: today, bulk_issued: today };
    if (I.specialties && I.specialties !== BASE_SPEC) V.p_services_line = I.specialties;
    Object.keys(V).forEach(function (id) {
      var e = document.getElementById(id); if (!e || e.dataset.exbId === '1') return;
      e.dataset.exbId = '1';
      if (e.value !== e.defaultValue || e.value === V[id]) return;
      e.value = V[id]; try { e.dispatchEvent(new Event('input', { bubbles: true })); } catch (x) {}
    });
    var b = document.querySelector('#receiptPaper .rbrand'); if (b && b.textContent !== I.name.toUpperCase()) b.textContent = I.name.toUpperCase();
  }
  (function () { var n = 0, t = setInterval(function () { n++; try { if (document.readyState === 'complete') applyForms(); } catch (e) {} if (n > 20) clearInterval(t); }, 700); })();

  /* signature + cachet de l'administrateur (PNG transparent), mis en cache le temps d'une action */
  function visa() { try { if (window.EXBSign && EXBSign.active()) return EXBSign.visa('png'); } catch (e) {} return Promise.resolve(''); }

  /* petit bloc de réglage dans « Logo Excellencia Building » (à côté de la signature et du cachet) */
  function buildUi() {
    var anchor = document.getElementById('exbSignAuto');
    if (!anchor || document.getElementById('exbIdBox')) return !!document.getElementById('exbIdBox');
    var host = anchor.closest('label'); if (!host) return false;
    var o = own(), I = get();
    var box = document.createElement('div'); box.id = 'exbIdBox';
    box.style.cssText = 'margin-top:14px;padding:12px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc';
    function esc(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
    box.innerHTML = '<b>🧾 Identité imprimée sur les devis, fiches et documents clients</b>' +
      '<div class="hint" style="margin:4px 0 8px">Ces informations apparaissent automatiquement dans l\'en-tête et le pied de page de tous les documents remis au client.</div>' +
      '<label>Nom du Directeur Général (imprimé sous la signature des reçus, certificats, devis, factures…)</label><input id="exbIdDg" value="' + esc(I.dg) + '" placeholder="Ir Prénom Nom"/>' +
      '<label>Fonction</label><input id="exbIdDgRole" value="' + esc(I.dgRole) + '"/>' +
      '<label>Téléphone</label><input id="exbIdPhone" value="' + esc(I.phone) + '"/>' +
      '<label>E-mail</label><input id="exbIdEmail" value="' + esc(I.email) + '"/>' +
      '<label>Adresse</label><input id="exbIdAddress" value="' + esc(I.address) + '"/>' +
      '<label>Ville de signature (« Fait à … »)</label><input id="exbIdCity" value="' + esc(I.city) + '"/>' +
      '<label>Mentions légales (RCCM, Id. Nat., N° impôt, banque… — une ligne par information)</label><textarea id="exbIdLegal" rows="3" style="width:100%;box-sizing:border-box">' + esc(o.legal || '') + '</textarea>' +
      '<button type="button" class="gold" id="exbIdSave" style="margin-top:10px">Enregistrer l\'identité des documents</button><div class="hint" id="exbIdMsg"></div>';
    host.parentNode.insertBefore(box, host.nextSibling);
    document.getElementById('exbIdSave').onclick = function () {
      var ok = setExtra({
        phone: document.getElementById('exbIdPhone').value, email: document.getElementById('exbIdEmail').value,
        address: document.getElementById('exbIdAddress').value, city: document.getElementById('exbIdCity').value,
        legal: document.getElementById('exbIdLegal').value,
        dg: document.getElementById('exbIdDg').value.trim(), dgRole: document.getElementById('exbIdDgRole').value.trim()
      });
      applyDg(true);
      var m = document.getElementById('exbIdMsg'); if (m) m.textContent = ok ? '✓ Identité enregistrée : elle sera utilisée sur tous les prochains documents.' : 'Enregistrement impossible (espace de stockage plein).';
      try { if (window.EXBMetre && EXBMetre.refreshVisa) EXBMetre.refreshVisa(); } catch (e) {}
    };
    return true;
  }
  (function () { var n = 0, t = setInterval(function () { n++; try { if (buildUi() || n > 600) clearInterval(t); } catch (e) { if (n > 600) clearInterval(t); } }, 800); })();

  return { get: get, bannerLine: bannerLine, palette: palette, theme: theme, applyDg: applyDg, setExtra: setExtra, contactLine: contactLine, placeLine: placeLine, footerExtra: footerExtra, legalLine: legalLine, visa: visa };
})();
