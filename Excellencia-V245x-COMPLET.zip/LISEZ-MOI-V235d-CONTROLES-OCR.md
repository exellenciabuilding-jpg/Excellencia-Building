# V235d — Contrôle automatique à 0 échec + OCR (correctif à part)

À copier par-dessus le logiciel V235c (mêmes chemins), puis fermer complètement l'application une fois (cache v235d).

## Fichiers
`site/tools/check.js`, `site/exb-ocr.js`, `site/sw.js`, `scripts/verifier-ocr.js` (nouveau), `scripts/test-equipe-annuaire.js`.

## Les 11 échecs du contrôle
- **10 échecs « cache renouvelé »** : anciens contrôles qui n'acceptaient qu'un nom de cache en v21x/v22x. Le logiciel est en v235 : ils acceptent maintenant v21x à v29x. Aucune modification du logiciel.
- **1 échec « fichiers vendor/tesseract »** : le moteur OCR (~18 Mo) est livré à part. Absent = simple information ; présent = contrôle complet ; PARTIEL (fichier manquant/tronqué) = échec.
- Ce dernier contrôle faisait aussi **planter** le contrôle à mi-parcours : les ~685 vérifications suivantes ne s'exécutaient jamais. Résultat maintenant : **997 contrôles réussis, 0 échec**.
- `test-equipe-annuaire.js` : contrôle de version obsolète (attendait V226) corrigé.

## OCR
- Le moteur (7 fichiers dans `site/vendor/tesseract/`) n'est pas dans ce correctif : il est dans la « partie 2 OCR » (voir LISEZ-MOI-OCR.md). Dézippez-la à la racine du logiciel.
- `node scripts/verifier-ocr.js` dit si les 7 fichiers sont présents, complets et au bon format.
- Message de l'écran Scanner corrigé (il renvoyait vers un README inexistant).
- L'extraction de texte reste testée ; la lecture réelle d'une image n'est pas testée ici.
