# V234 — Report de la version comptable V233 sur la V229h + points « non fait »

Base : **V229h** (hors connexion, livraison matériel, bibliothèque BTP — conservés tels quels).

## 1. Report des modifications comptables (V229 → V233)
Ajoutés sans remplacer aucun fichier existant :
`exb-v229-centre-reception.js`, `exb-v229b-accueil-comptable.js`, `exb-v230-fournisseurs-dettes.js`, `exb-v231-tresorerie.js`, `exb-v232-analytique-chantier.js`, `exb-v233-paie-fiscalite-immo.js` + leurs LISEZ-MOI.
- `site/index.html` : 7 balises ajoutées juste après `exb-roles.js` (les 6 ci-dessus + V234).
- `site/sw.js` : version incrémentée et les 7 fichiers ajoutés à la liste hors connexion.
- NON repris de la V233 (plus anciens que la V229h) : `exb-db.js`, `exb-sync.js`, `exb-v205-connexion-espace.js`, ancien `index.html`/`sw.js` — les correctifs V227g/V227h/V229h sont donc conservés.

## 2. Points « non fait » traités — `site/exb-v234-controle-paie-ecritures.js` (bouton « 🧮 Contrôle paie · Écritures »)
**Contrôle des bulletins de paie V81** (lecture seule de `exb_payroll`) : net recalculé, coût employeur, brut/net négatif, taux absent, doublon employé+période, contrat actif, employé inconnu, avances présentes dans deux registres (V81 et V233), bulletin payé non lié à la caisse. Décision du comptable : « Contrôlé » ou « À corriger » (motif obligatoire) ; un bulletin modifié après contrôle est signalé. L'état du pont existant « bulletins V81 → écritures » (`exb-compta-paie-v81.js`, V176) est affiché : **les bulletins ne sont pas comptabilisés deux fois**, ce pont reste la seule source.
**Écritures automatiques** (cession, notes de frais sur avance, paiements fiscaux) : **proposées, jamais postées** au journal. Validation une par une par le comptable, rejet avec motif, export CSV des écritures validées. Impossible de valider si le plan de comptes n'est pas paramétré et validé, ou si l'écriture est déséquilibrée.
**Avances au personnel** : l'avance accordée, le remboursement par l'employé et le paiement à l'employé sont aussi proposés (rôle de compte « Caisse / banque (avances) »). À ne valider que si le décaissement n'est pas déjà comptabilisé via la Trésorerie (risque de doublon signalé dans le libellé).
**Audit** (onglet « 🔎 Audit », lecture seule) : journal unifié des événements de V229 à V234 (Centre de réception, Fournisseurs, Trésorerie, Analytique, Paie·Fiscalité·Immo, Contrôle), filtre par source et recherche, export CSV. Aucune action de cet écran ne modifie un événement.
**Plan de comptes et taux fiscaux** : onglet Paramètres, vides par défaut (aucun numéro ni taux codé), datés et sourcés ; toute modification annule la validation ; validation par un professionnel RDC enregistrée (nom, date, référence).

## Ce qui reste à faire par vous / votre comptable
- Saisir et faire valider le plan de comptes et les taux (cahier § 12) — sans cela, aucune écriture ne peut être validée.
- Valider les schémas d'écriture proposés (cession, frais, avances, paiement fiscal).
- Lot 6 : l'audit est fait (voir ci-dessus) ; restent les rapports/exports complets, la restauration testée et la recette utilisateur.

## Retour arrière
Retirer la balise `exb-v234-controle-paie-ecritures.js` (et, pour revenir à la V229h, les 6 balises V229–V233) dans `index.html`. Les données restent. Clés créées : `exb_pc_controles`, `exb_pc_ecritures`, `exb_pc_params`, `exb_pc_audit`.

## À tester (Android et ordinateur, hors connexion aussi)
1. Bulletin validé dans Paie V81 → onglet Contrôle : « Cohérent » → « Contrôlé » ; modifier le bulletin → « Modifié depuis le contrôle ».
2. Céder une immobilisation (V233) → écriture proposée avec comptes « non paramétré » ; saisir les comptes, enregistrer la validation, valider, exporter le CSV.
3. Modifier un compte → la validation est annulée.
Audit technique du paquet : 0 erreur de syntaxe sur tous les .js, toutes les balises et tous les fichiers du hors connexion présents, aucune clé de stockage en collision avec la V229h, seuls `index.html` et `sw.js` modifiés par rapport à la V229h, aucun appel réseau dans les modules V229–V234, sauvegarde des clés `exb_*` assurée par exb-continuite.js.
Tests automatiques : 25 contrôles de logique pure (V234) OK. Non testé sur navigateur réel.

## V234b — Atelier de mise en page : l'éditeur Word ne s'ouvre plus vide sur un document importé
Fichiers modifiés : `site/atelier-mep/app.js` (fonction `editerTexte`), `site/atelier-mep/exb-doc-analysis.js` (lecture du texte : `extraireTexte`, `regrouperLignes`, `lignesVersTexte`), `site/sw.js` (version), `site/tools/test-atelier-mep.js` (+4 tests, 54/54 OK).
- « Rédiger avec l'éditeur Word » sur un document importé qui contient du texte : l'Atelier propose « Reprendre le texte du document » (titres en majuscules repérés, paragraphes reconstitués, numéros de page ignorés, 60 000 caractères maximum) ou « Page blanche ». L'original n'est jamais modifié ; le texte appliqué s'ajoute sur des feuilles supplémentaires, donc ne garder que ce qui doit être ajouté.
- Document scanné (sans couche de texte) : la proposition n'apparaît pas (l'OCR reste facultatif et séparé).
- Retour arrière : restaurer `app.js` et `exb-doc-analysis.js` de la V229h.
- Non fait (à préciser) : zones d'import séparées « notes de calcul » / « plans d'exécution », et retrait d'un fichier de la liste une fois enregistré. Non testé sur navigateur réel.

## V234c — Atelier de mise en page : onglet « Plans · Notes de calcul » (import séparé)
Fichiers modifiés : `site/atelier-mep/index.html` (onglet + deux zones), `site/atelier-mep/app.js` (fonction `importer`, `renderSep`, `reclasser`), `site/sw.js` (version). Nouveau : `site/tools/e2e-atelier-import-separe.py`.
- Nouvel onglet **« Plans · Notes de calcul »** : une zone d'import pour les **plans d'exécution**, une zone pour les **notes de calcul**. Le type et le modèle sont imposés par la zone (plus de devinette sur le nom du fichier). On reste sur l'onglet après l'import.
- **Plan déjà importé** : le PDF est reconnu par son empreinte SHA-256 (quel que soit son nom). Il n'est **pas réimporté ni dupliqué** : il reste dans l'archive, la ligne indique « Déjà dans l'archive » avec un bouton « Ouvrir ». Même contrôle dans l'onglet « Importation » existant.
- Fichier déjà archivé dans l'autre catégorie : l'Atelier propose de le **reclasser** (seul le classement change, aucun fichier copié) ; refusé si le document est déjà soumis, approuvé ou émis.
- Chaque zone affiche la liste de ce qui est **déjà dans l'archive** (Ouvrir, Télécharger l'original, statut, date).
- **Retrait d'un fichier de la liste** (✕ par ligne, « Vider la liste ») une fois enregistré : seul l'affichage est retiré, le document reste dans l'archive.
- Retour arrière : restaurer `index.html`, `app.js` et `sw.js` de la V234b.
- Testé dans Chromium (Playwright) : import plan, import note, réimport du même plan (aucun doublon), reclassement, retrait de la liste, affichage mobile 390 px, 0 erreur JavaScript ; tests existants 54/54. Non testé sur Android réel.

## V234d — Atelier : plans et notes importés = informations Excellencia + portail client
Fichiers modifiés : `site/atelier-mep/index.html`, `site/atelier-mep/app.js`, `site/sw.js`. Tests : `site/tools/e2e-atelier-portail-client.py` (+ `harness-atelier-portail.html`).
- **Projet à l'import** : l'onglet « Plans · Notes de calcul » propose « Projet concerné ». Chaque PDF importé est rattaché au projet et le cartouche reprend automatiquement projet, référence, client, localisation, indice et date ; le numéro (ex. PEX-2026-0007, NCS-…) est lu dans le nom du fichier s'il y figure, sinon « À compléter ». Rien n'est inventé.
- **Déjà fourni par l'Atelier à l'export** : logo et identité de l'entreprise, cartouche, QR de vérification enregistré au registre, mentions établi / vérifié / approuvé issues du circuit de validation, filigrane de statut, pagination, versions et archivage à l'émission.
- **Portail client** (nouvelle carte « 5 · Portail client » dans les propriétés d'un plan ou d'une note) : « Publier — QR / lien client » utilise le même mécanisme que les plans d'exécution et notes du logiciel (références EXE-/EXN-, code d'accès, QR, envoi WhatsApp / e-mail au client du projet, liste et retrait dans « Documents publiés »). Republier garde la même référence et le même QR. Après « Émettre », l'Atelier propose de publier tout de suite.
- **Règle de sécurité** : seule la dernière version **approuvée ou émise** se publie (pas de brouillon aux clients) ; numéro du document obligatoire ; droit « plans_fichiers » (écriture) requis ; hors connexion, la publication est mise en attente et part toute seule au retour du réseau.
- **Non repris** : l'image de signature + cachet de l'administrateur posée sur les plans natifs n'est pas ajoutée aux PDF importés (le visa reste la mention nominative du circuit de validation).
- Prérequis serveur déjà existant : `supabase/migration-v141p-calcul-publics.sql`.
- Retour arrière : restaurer `index.html`, `app.js` et `sw.js` de la V234c.
- Testé dans Chromium avec un portail simulé : projet repris, bouton désactivé sans version validée, publication avec les bonnes données, QR / lien, liste, 0 erreur JavaScript. Non testé avec le vrai serveur ni sur Android.
