# V236i — Plans : écran interne du Parcours TFL, connexion unique, copier-coller

**Ce qui change**
- *Parcours TFL › Plans* s'ouvre comme les autres cartes (onglets **Catalogue** / **Esquisses reçues** dans le module). Plus de page séparée ni de fond d'accueil par-dessus.
- **Plus de second formulaire de connexion** : l'écran utilise la connexion du logiciel central (même compte). Si le logiciel n'est pas connecté au serveur, un bandeau propose « Se connecter au serveur » (ouvre la connexion du logiciel). Hors connexion, le catalogue se prépare comme avant.
- **Correction de fond** : l'ancienne page rangeait les plans dans une clé du navigateur que le module ne lisait pas (d'où « 0 plan(s) » en haut). Les plans sont désormais enregistrés avec le reste des données du logiciel (sauvegarde, synchronisation). Les anciens plans (et ceux du convertisseur) sont repris automatiquement à la première ouverture ; une copie brute reste sous `exb_tfl_plans_v236h_copie`.
- **Clavier / presse-papiers** : Ctrl+C / X / V / A / Z / Y fonctionnent dans tous les champs (menu « Édition » invisible ajouté à l'application Windows) ; clic droit Couper/Copier/Coller disponible comme ailleurs ; Ctrl+S ou Ctrl+Entrée enregistre le plan ; Échap annule la modification ; **Ctrl+V colle une image ou un PDF copié comme nouveau plan** (bouton « Coller un plan ») ; bouton « Copier » sur chaque plan (référence + intitulé).

**Fichiers** : `site/exb-tfl-plans.js` (nouveau), `site/exb-tfl.js`, `site/index.html`, `site/sw.js`, `site/tfl-plans-admin.html` (devient une simple redirection), `site/tfl-plans-convertir.html` (liens), `electron/main.js` (menu Édition).

Après installation : fermer complètement l'application une fois (cache v236i).
