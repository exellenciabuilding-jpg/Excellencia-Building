# V230 — Fournisseurs & dettes (Lot 2 du cahier « Portail Comptable V229+ »)

Base : V229b sur V227f. Aucun fichier existant remplacé.

## Ce qui change
- Nouveau fichier : `site/exb-v230-fournisseurs-dettes.js` (adaptateur).
- `site/index.html` : une balise ajoutée, juste après `exb-v229b-accueil-comptable.js`.
- Bouton « 🤝 Fournisseurs & dettes » à côté de « 📥 Centre de réception ».

## Les 4 onglets
1. Fournisseurs : référentiel unifié (V67 + V92, un fournisseur n'apparaît qu'une fois) ; commandé, reçu, à facturer, facturé, payé, dette.
2. Dettes & échéances : ancienneté (non échu, 1–30 j, 31–60 j, > 60 j, sans échéance) par devise + factures à payer.
3. Factures à contrôler : factures fournisseurs reçues par le Centre de réception, avec contrôle (déjà enregistrée, doublon, supérieure au reçu non facturé) et rapprochement commandes ↔ réceptions ↔ factures.
4. Relevé fournisseur : débit/crédit/solde par devise, export CSV, impression.

## Règles respectées
- Aucune double saisie : une facture déjà enregistrée est reconnue (même fournisseur + même numéro) et n'est pas ressaisie.
- Doublon bloqué : même fournisseur + même numéro, ou même montant + même date.
- Montant supérieur au reçu non facturé : motif obligatoire.
- Rien n'est payé ici (règlement = Centre de réception puis Trésorerie, Lot 3). Aucune écriture de caisse.
- Devises séparées : aucune conversion ni addition entre USD et CDF.
- Seule écriture : une ligne dans `exb_v92_supplier_invoices` (clé existante, format V92, reprise par la Comptabilité), plus `exb_fd_liens` et `exb_fd_audit` (nouvelles clés : auteur, date, motif).

## Retour arrière
Supprimer la balise `<script src="exb-v230-fournisseurs-dettes.js">` dans `index.html`. Les factures déjà enregistrées restent dans les données.

## À tester (Android et ordinateur)
1. Créer un fournisseur et un bon de commande dans Achats ; vérifier qu'ils apparaissent ici sans ressaisie.
2. Soumettre une « Facture fournisseur » dans le Centre de réception, puis « Enregistrer » dans l'onglet Factures à contrôler.
3. Vérifier que la facture apparaît une fois dans Dettes & échéances et dans la Comptabilité (journal AC), et qu'une seconde tentative est bloquée.
4. Dépasser le reçu non facturé : le motif doit être exigé.
Tests automatiques : 16 contrôles de logique et parcours navigateur mobile/ordinateur : OK.

## Reste à faire
Lot 3 (Trésorerie, rapprochement, Mobile Money), puis Lots 4 à 6.
