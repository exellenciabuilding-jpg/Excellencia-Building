# V236b — Courbe en S de « Pilotage projets » : cause et correctif

Base : V236 (aucun autre fichier modifié).

## Cause
La courbe en S n'est dessinée que si le planning du chantier a une **date de début (semaine 1)**.
Un planning créé avant l'ajout de ce champ n'en a pas : le logiciel n'affichait alors qu'une petite phrase grise et rien d'autre.
Le même manque rendait le SPI et le retard prévisionnel indisponibles.

## Correctif (`site/exb-pilote.js`)
- Sans planning : message « ce chantier n'a pas encore de planning » + bouton « Ouvrir Planning & budget ».
- Planning sans date : message explicite + boutons « Utiliser le début du projet (jj/mm/aaaa) », « Utiliser aujourd'hui » et « Ouvrir Planning & budget ». Un clic enregistre la date et la courbe apparaît.
- Les boutons de réglage respectent les droits (budgets_chantier en écriture).
- `site/sw.js` : cache renouvelé (`v236b-…`).

## Installation
Copier `site/exb-pilote.js` et `site/sw.js` par-dessus la V236, puis fermer complètement l'application une fois (cache).
Pas de SQL. Les APK/EXE se reconstruisent comme d'habitude (OCR : archive séparée).

## Vérifié
`tools/check.js` : 998 contrôles, 0 échec · `test-evm.js` · `test-bi.js` (47) · `test-auto-devis.py` (21) · test navigateur dédié : planning daté → courbe ; sans date → message ; sans planning → message ; clic sur le bouton → courbe affichée et date enregistrée.

## Guide
`guide-V236b/GUIDE-V236b-piloter-entreprise.pdf` : guide d'utilisation du pilotage de l'entreprise (captures réelles), avec une page sur ce cas.
