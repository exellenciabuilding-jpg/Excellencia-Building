# V227g — Le membre invité (Comptable) n'est plus lu « Polyvalent »

Base : V227f.

## Constat
Base de données correcte : invitation utilisée, membre = éditeur / **comptable**. Pourtant l'écran « Accès refusé » du membre disait « Polyvalent »
avec « Diagnostic : aucune invitation en attente » → l'application lisait la fonction par `mon_organisation`, qui ne la renvoyait pas (ancienne version serveur).

## Corrigé
1. `site/exb-v205-connexion-espace.js` : si `mon_organisation` ne donne pas la fonction (ou répond Polyvalent), l'application la relit dans la table `membres` (le membre peut lire sa propre ligne). L'écran « Accès refusé » affiche aussi un relevé serveur (réponse de mon_organisation / valeur de la table).
2. `site/exb-db.js` : même relecture lors du rafraîchissement des droits.
3. `sw.js` : cache `v227g-…`.

## SQL (recommandé) — projet Supabase de l'application
`migration-v227g-mon-organisation-fonction.sql` : recrée `mon_organisation` avec `role` + `fonction`. Le contrôle final doit afficher `true`.

## Après déploiement
Sur l'appareil du membre : fermer complètement le logiciel/onglet, rouvrir, se connecter, toucher « J'ai été corrigé(e) : réessayer » si l'écran apparaît.
