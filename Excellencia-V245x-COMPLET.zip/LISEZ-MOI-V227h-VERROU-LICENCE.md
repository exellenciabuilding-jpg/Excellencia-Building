# V227h — L'écran « Aucune licence associée à ce compte » ne doit plus apparaître à un membre d'entreprise

Base : V227g.

## Constat
Le membre (Comptable) arrive dans le logiciel, mais l'écran bleu « Aucune licence associée à ce compte » apparaît à la connexion, disparaît, puis revient.

## Cause (dans le code, `index.html › licTick` et `exb-sync.js › run`)
Le verrou se déclenche dès que le logiciel ne PEUT PAS prouver que le compte appartient à une entreprise. Deux défauts :
1. une erreur réseau ou serveur sur `mon_organisation` était lue comme « aucune entreprise » → verrou (puis déverrouillage au passage suivant, d'où le va-et-vient) ;
2. juste après la connexion, l'entreprise n'est pas encore enregistrée sur l'appareil : le verrou pouvait tomber avant l'adoption de l'entreprise.

## Corrigé
- `index.html` (licTick) : une erreur de vérification ne verrouille plus ; pas de verrou pendant l'écran de connexion d'espace ; un compte sans entreprise est vérifié DEUX fois (à 6 s d'intervalle) avant le verrou.
- `exb-sync.js` : avant de verrouiller un compte sans licence « par compte », l'entreprise est demandée au serveur ; une erreur réseau ne verrouille pas.
- Inchangé : un abonnement « suspendu » reste bloqué ; un compte réellement sans entreprise ni licence reste bloqué.
- `sw.js` : cache `v227h-…`.

## Après déploiement
Fermer complètement le logiciel/onglet puis rouvrir (Windows : fermer la fenêtre de l'application installée). Si l'écran réapparaît, noter l'heure et envoyer une photo.
