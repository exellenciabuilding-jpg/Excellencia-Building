# V236c — Membre invité : aucune licence, seul son statut compte

Base : V236b (fichiers modifiés : `site/index.html`, `site/exb-sync.js`, `site/sw.js`).

## Règle
- Un membre invité (rôle autre qu'administrateur, rattaché à une entreprise) n'est **jamais** jugé sur une licence « par compte » : plus d'écran « Aucune licence associée à ce compte », « Abonnement expiré » ou « Abonnement suspendu » pour lui.
- Seul son **statut de membre** peut le bloquer, via `mon_statut` (`exb-acces-membre.js`, inchangé) : **actif** = accès ; **suspendu** ou **retiré** = écran de blocage ; **réactivé** = l'accès revient automatiquement (vérification toutes les 30 s, au retour dans l'application et au retour du réseau).
- Inchangé : un compte sans entreprise (ou un administrateur) reste soumis à sa licence.

## Cause du va-et-vient de l'écran bleu
Deux contrôles de licence (`index.html › licTick` et `exb-sync.js › run`) posaient et retiraient le même écran. Ils ne regardent plus un membre invité.

## Après déploiement
Fermer complètement l'application une fois (cache v236c). Le membre doit être actif dans Équipe, avec sa fonction (ex. Comptable).
