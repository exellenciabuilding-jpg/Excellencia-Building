# V229 — Centre de réception comptable (Lot 1 du cahier « Portail Comptable V229+ »)

Base : V227f (le cahier cite V229e, non fournie). Aucun fichier existant n'a été remplacé.

## Ce qui change
- Nouveau fichier : `site/exb-v229-centre-reception.js` (adaptateur).
- `site/index.html` : une seule balise ajoutée, après `exb-roles.js`.
- Bouton « 📥 Centre de réception » ajouté à côté du bouton Comptabilité.

## Règles respectées
- Cycle : Brouillon → À contrôler → Complément / Rejetée → En attente d'autorisation → Autorisée / Refusée → Payée → Comptabilisée → Clôturée.
- Le comptable contrôle ; la Direction autorise. Par défaut TOUT paiement exige la Direction (seuils à fixer avec elle).
- USD/CDF : taux daté, figé à la soumission ; un nouveau taux ne réécrit pas l'historique.
- Un paiement déclaré par un client reste « à vérifier » : aucune écriture en caisse (raccord Trésorerie = Lot 3).
- Nouvelles clés seulement : exb_cr_demandes, exb_cr_taux, exb_cr_params, exb_cr_pieces.

## Retour arrière
Supprimer la balise `<script src="exb-v229-centre-reception.js">` dans `index.html`. Les données exb_cr_* restent intactes.

## À tester (téléphone Android et ordinateur)
1. Saisir un taux USD/CDF dans Paramètres. 2. Créer et soumettre une facture fournisseur. 3. Contrôler (4 cases). 4. Autoriser en profil Direction. 5. Vérifier que la caisse existante n'a pas bougé.
Logique testée par script Node (taux historisé, droits, seuil Direction) : 6/6.

## Reste à faire
Accueil « Vue financière consolidée » de la maquette, Lots 2 à 6.
