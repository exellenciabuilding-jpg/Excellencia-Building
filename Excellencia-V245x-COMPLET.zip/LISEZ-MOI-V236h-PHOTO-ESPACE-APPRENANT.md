# V236h — Photo de l'apprenant dans son espace (reçus et cartes)

Cause : le reçu du logiciel retrouve la photo comme il faut (jeton « exbidb: » des photos > 40 Ko relu, fiche en double avec photo), mais la publication de l'espace apprenant n'envoyait que les photos stockées en clair sur la fiche portant le matricule. Les photos > 40 Ko, ou rangées sur une fiche en double, n'étaient jamais publiées : reçus et cartes sortaient donc sans photo dans l'espace.

Correctif (site/index.html, `espBuild`) : même recherche de photo que le reçu du logiciel (jeton relu ; à défaut, fiche de même identifiant / matricule / nom). Publication par lots de 25 (les photos alourdissent les lignes).

Après installation : logiciel connecté au serveur → la mise à jour automatique republie les apprenants concernés en 30 s environ (ou « Publier l'espace apprenant »). L'apprenant rouvre son espace : la photo apparaît sur ses reçus et sa carte.
Cache v236h : fermer complètement l'application une fois.
