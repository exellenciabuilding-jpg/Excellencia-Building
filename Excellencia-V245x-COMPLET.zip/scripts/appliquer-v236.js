#!/usr/bin/env node
/* V236 — branche le Rapport de matériaux dans le logiciel, SANS DOUBLON (relançable sans danger).
 * Usage (depuis le dossier racine, celui qui contient site/) :  node scripts/appliquer-v236.js
 * Chaque point : « ajouté » la première fois, « déjà présent » ensuite. Code de sortie 1 si une ancre manque. */
const fs = require('fs'), path = require('path');
const S = path.join(__dirname, '..', 'site');
let bad = 0;
function edit(file, label, test, fn) {
  const p = path.join(S, file);
  if (!fs.existsSync(p)) { console.log('✗ ' + file + ' introuvable (' + label + ')'); bad++; return; }
  const src = fs.readFileSync(p, 'utf8');
  if (test(src)) { console.log('= ' + file + ' — ' + label + ' : déjà présent'); return; }
  const out = fn(src);
  if (out === src || out == null) { console.log('✗ ' + file + ' — ' + label + ' : point d’ancrage introuvable'); bad++; return; }
  fs.writeFileSync(p, out); console.log('+ ' + file + ' — ' + label + ' : ajouté');
}
const rep = (a, b) => s => s.indexOf(a) < 0 ? s : s.replace(a, () => b);

if (!fs.existsSync(path.join(S, 'exb-v236-rapport-materiaux.js'))) { console.log('✗ site/exb-v236-rapport-materiaux.js manquant'); process.exit(1); }

/* 1. page : une seule balise, juste après le bon de paiement V235 */
edit('index.html', 'balise du module', s => s.indexOf('exb-v236-rapport-materiaux.js') >= 0,
  rep('<script src="exb-v235-bon-paiement.js"></script>', '<script src="exb-v235-bon-paiement.js"></script><script src="exb-v236-rapport-materiaux.js"></script>'));

/* 2. cache hors connexion : nouvelle version + fichier dans la liste */
edit('sw.js', 'version du cache', s => s.indexOf("const V='v236-rapport-materiaux-") >= 0, rep("const V='", "const V='v236-rapport-materiaux-"));
edit('sw.js', 'fichier hors connexion', s => s.indexOf('exb-v236-rapport-materiaux.js') >= 0,
  rep("'./exb-v235-bon-paiement.js',", "'./exb-v235-bon-paiement.js','./exb-v236-rapport-materiaux.js',"));

/* 3. synchronisation entre espaces : collection partagée + réaffichage */
edit('exb-db.js', 'collection synchronisée', s => s.indexOf('exb_rapports_materiaux') >= 0,
  rep("exb_bons_paiement:'bons_paiement'", "exb_bons_paiement:'bons_paiement',exb_rapports_materiaux:'rapports_materiaux'"));
edit('exb-db.js', 'réaffichage', s => s.indexOf('exbReRenderRm') >= 0,
  rep("REND.exb_bons_paiement='exbReRenderBp';/* V235 */", "REND.exb_bons_paiement='exbReRenderBp';/* V235 */REND.exb_rapports_materiaux='exbReRenderRm';/* V236 */"));

/* 4. superviseur (Administration › Supervision des espaces) : Commercial & Stock et Ingénieur / Chantier */
edit('exb-v223-espaces-admin.js', 'superviseur : Commercial & Stock', s => s.indexOf('exb_rapports_materiaux') >= 0,
  rep("['Mouvements de stock', 'exb_stock_moves'],", "['Mouvements de stock', 'exb_stock_moves'], ['Rapports de matériaux', 'exb_rapports_materiaux'],"));
edit('exb-v223-espaces-admin.js', 'superviseur : chiffre Commercial & Stock', s => s.indexOf("n('exb_rapports_materiaux')") >= 0,
  rep("['Articles en stock', n('exb_stock')],", "['Articles en stock', n('exb_stock')], ['Rapports de matériaux', n('exb_rapports_materiaux')],"));


/* 5. ÉQUIPE : liens d'accès pour Polyvalent et Administrateur, et autres espaces ouverts selon la fonction (RH, chef de projet, ingénieur…) */
edit('exb-equipe.js', 'liens Polyvalent / Administrateur', s => s.indexOf('/* V236 */') >= 0, s => {
  var a = "function espaceLien(f){return f==='comptable'";
  if (s.indexOf(a) < 0) return s;
  s = s.replace(a, () => "function espaceLien(f){return (f==='polyvalent'||f==='administrateur')?'index.html':f==='comptable'");
  var b = "['Formateur','formateur']];";
  if (s.indexOf(b) < 0) return s;
  s = s.replace(b, () => "['Formateur','formateur'],['Polyvalent (tous les espaces)','polyvalent'],['Administrateur (accès total)','administrateur','admin']];/* V236 */\n" +
    "var TOUS=[['Espace Comptable','comptable.html'],['Espace Ingénieur','ingenieur.html'],['Espace Architecture','architecte.html'],['Espace Chantier','chantier.html'],['Espace Magasin','magasin.html'],['Espace Formation','espace-formation.html'],['Espace Administration (RH)','administration.html'],['Espace Direction','direction.html']];\n" +
    "function autresLiens(f,role){var m={chef_projet:['ingenieur.html','architecte.html'],conducteur:['ingenieur.html'],bureau_etudes:['architecte.html']},p=espaceLien(f==='formateur'?'formateur':f);if(f==='direction'||f==='polyvalent'||f==='administrateur'||role==='admin')return TOUS.filter(function(x){return x[1]!==p});return TOUS.filter(function(x){return (m[f]||[]).indexOf(x[1])>=0})}\n" +
    "function autresTxt(i){var l=autresLiens(i.fonction,i.role);return l.length?'\\nAutres espaces que vous pouvez ouvrir avec votre fonction :\\n'+l.map(function(x){return '• '+x[0]+' : '+appUrl()+x[1]}).join('\\n')+'\\n':''}");
  var c = "return t+'\\nVous rejoignez";
  if (s.indexOf(c) < 0) return s;
  s = s.replace(c, () => "return t+autresTxt(i)+'\\nVous rejoignez");
  var d = "async function genLien(f,k){";
  if (s.indexOf(d) < 0) return s;
  s = s.replace(d, () => "async function genLien(f,k){if(f==='administrateur')f='polyvalent';");
  var e = "opts(ROLES,'editeur')+'</select></td><td><button class=\"primary\" data-gl=\"'";
  if (s.indexOf(e) < 0) return s;
  s = s.replace(e, () => "opts(ROLES,x[2]||'editeur')+'</select></td><td><button class=\"primary\" data-gl=\"'");
  var g = "+esc(base+(x[1]==='formateur'?'espace-formation.html':espaceLien(x[1])))+'</span></td>";
  if (s.indexOf(g) < 0) return s;
  s = s.replace(g, () => "+esc(base+(x[1]==='formateur'?'espace-formation.html':espaceLien(x[1])))+'</span>'+(autresLiens(x[1]==='administrateur'?'administrateur':x[1],x[2]).length?'<br><span class=\"hint\">Ouvre aussi : '+autresLiens(x[1],x[2]).map(function(z){return esc(z[0].replace('Espace ',''))}).join(', ')+'</span>':'')+'</td>");
  return s;
});

/* 6. CONNEXION : Polyvalent n'est plus refusé dans les espaces ; l'écran de refus propose TOUS les espaces qui conviennent à la fonction */
edit('exb-v205-connexion-espace.js', 'Polyvalent admis dans les espaces', s => s.indexOf('/* V236 */') >= 0, s => {
  var a = "if (key() && o.role !== 'admin' && sp.fonctions.indexOf(f) < 0)";
  if (s.indexOf(a) < 0) return s;
  s = s.replace(a, () => "if (key() && o.role !== 'admin' && f !== 'polyvalent' /* V236 */ && sp.fonctions.indexOf(f) < 0)");
  var h = "function names(list) { return (list || []).map(fonc).join(', '); }";
  if (s.indexOf(h) < 0) return s;
  s = s.replace(h, () => h + "\n  /* V236 : tous les espaces qui conviennent à la fonction (au lieu d'un seul lien ou de « aucun espace ») */\n" +
    "  function boutonsEspaces(f, lien) {\n    var D = defs(), h = '';\n    Object.keys(D).forEach(function (k) { var e = D[k]; if (e && e.fonctions && (f === 'polyvalent' || e.fonctions.indexOf(f) >= 0)) h += '<button type=\"button\" class=\"g2\" data-go=\"' + esc(HTML_OF[k] || (k + '.html')) + '\">' + esc((e.ic || '') + ' Ouvrir : ' + e.t) + '</button>'; });\n" +
    "    if (!h && lien) h = '<button type=\"button\" class=\"g2\" data-go=\"' + esc(lien) + '\">Ouvrir l’espace de ma fonction</button>';\n    return h || '<p>Aucun espace dédié à votre fonction : contactez votre administrateur.</p>';\n  }");
  var i1 = s.indexOf("(lien ? '<button type=\"button\" class=\"g2\" data-go=\"' + esc(lien)"), tail = "contactez votre administrateur.</p>')";
  var i2 = i1 < 0 ? -1 : s.indexOf(tail, i1);
  if (i1 < 0 || i2 < 0) return s;
  return s.slice(0, i1) + 'boutonsEspaces(f, lien)' + s.slice(i2 + tail.length);
});


console.log(bad ? '\n' + bad + ' point(s) à traiter.' : '\nV236 branché. Fermez complètement l’application une fois (nouveau cache), puis exécutez supabase/migration-v236-rapports-materiaux.sql.');
process.exit(bad ? 1 : 0);
