/* V225 — test : annuaire de l'équipe (statistiques, statuts, lignes filtrables, filtre par fonction et recherche).
 * Usage : node scripts/test-equipe-annuaire.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const EQ = fs.readFileSync(path.join(__dirname, '..', 'site', 'exb-equipe.js'), 'utf8');
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) fail++; };
const wait = ms => new Promise(r => setTimeout(r, ms));
const mk = o => ({ getItem: k => (k in o ? o[k] : null), setItem: (k, v) => { o[k] = String(v); }, removeItem: k => { delete o[k]; } });
const rows = []; let html = ''; const calls = [];
const equipe = { style: { display: '' }, set innerHTML(v) { html = v; rows.length = 0; const re = /<tr data-q="([^"]*)" data-f="([^"]*)"/g; let m; while ((m = re.exec(v))) rows.push({ dataset: { q: m[1], f: m[2] }, style: {} }); }, get innerHTML() { return html },
  querySelectorAll: sel => sel === 'tr[data-q]' ? rows : [] };
const els = {}; const dummy = id => els[id] || (els[id] = { style: {}, value: '', textContent: '', disabled: false, remove() {} });
const doc = { hidden: false, body: { appendChild() {} }, addEventListener() {}, createElement: () => dummy('x'), getElementById: id => id === 'equipe' ? equipe : dummy(id) };
const w = { localStorage: mk({}), sessionStorage: mk({}), document: doc, JSON, Math, console, navigator: { onLine: true }, location: { hash: '', search: '', pathname: '/' },
  setInterval: () => 0, setTimeout: () => 0, addEventListener() {}, exbAlert() {},
  exbSb: { isIn: () => true, cfg: () => ({ email: 'a@b.cd' }), api: async (p, o) => { const n = p.split('/').pop(); calls.push([n, JSON.parse(o.body || '{}')]);
    if (n === 'equipe_permissions') return [{ user_id: 'u1', lecture: true, creation: false, modification: false, validation: true, export: true }];
    if (n === 'mon_organisation') return { id: 'o1', nom: 'Excellencia', role: 'admin' };
    if (n === 'equipe_liste') return { membres: [
      { user_id: 'u1', nom: 'Marie Kabila', email: 'marie@x.cd', role: 'editeur', fonction: 'comptable', depuis: '2026-01-01' },
      { user_id: 'u2', nom: 'Paul Ilunga', email: 'paul@x.cd', role: 'admin', fonction: 'direction', depuis: '2026-01-01' }],
      invitations: [{ id: 'i1', nom: 'Jean Mbuyi', email: 'jean@x.cd', role: 'lecteur', fonction: 'rh', cree_le: '2026-11-01' }],
      suspendus: [{ user_id: 'u3', nom: 'Awa Diallo', email: 'awa@x.cd', role: 'editeur', fonction: 'magasinier', suspendu_le: '2026-11-02' }] };
    return []; } } };
w.window = w; const ctx = vm.createContext(w); vm.runInContext(EQ, ctx);
(async () => {
  await w.EXB_EQUIPE.reload(); await wait(20);
  ok(/^V22[6-9]/.test(w.EXB_EQUIPE.version), 'version V226 ou suivante (' + w.EXB_EQUIPE.version + ')');
  ok(rows.length === 4, '4 lignes filtrables (2 membres, 1 suspendu, 1 invitation) : ' + rows.length);
  ok(/>4<\/b><span class="hint">Personnes/.test(html) && />2<\/b><span class="hint">Accès actifs/.test(html) && />1<\/b><span class="hint">Invitations en attente/.test(html) && />1<\/b><span class="hint">Suspendus/.test(html), 'statistiques 4 / 2 / 1 / 1');
  ok(/>Actif<\/span>/.test(html) && /En attente<\/span>/.test(html) && /suspendu<\/span>/.test(html), 'statuts Actif / En attente / suspendu affichés');
  ok(/id="eq_q"/.test(html) && /id="eq_ff"/.test(html) && /Règles de sécurité/.test(html), 'recherche, filtre et règles présents');
  ok(html.indexOf('id="eq_q"') < html.indexOf('Inviter un membre'), 'annuaire avant le formulaire d’invitation');
  els.eq_ff = els.eq_ff || dummy('eq_ff'); els.eq_q = dummy('eq_q');
  await w.EXB_EQUIPE.reload(); await wait(20);
  els.eq_ff.value = 'comptable'; els.eq_ff.onchange();
  ok(rows.filter(r => r.style.display !== 'none').length === 1, 'filtre « Comptable » : 1 ligne');
  els.eq_ff.value = ''; els.eq_ff.onchange(); els.eq_q.value = 'AWA'; els.eq_q.oninput();
  ok(rows.filter(r => r.style.display !== 'none').length === 1 && /1 résultat sur 4/.test(els.eq_cnt.textContent), 'recherche « awa » (insensible à la casse) : 1 résultat sur 4');
  els.eq_q.value = '@x.cd'; els.eq_q.oninput();
  ok(rows.filter(r => r.style.display !== 'none').length === 4, 'recherche par e-mail : 4 lignes');
  console.log('V226 — permissions par membre');
  ok((html.match(/data-pm="/g) || []).length === 2, 'un bouton « Permissions » par membre actif (2)');
  ok(/permissions limitées/.test(html) && (html.match(/permissions limitées/g) || []).length === 1, 'pastille « permissions limitées » seulement pour le membre restreint (u1)');
  ok(calls.some(c => c[0] === 'equipe_permissions' && c[1].p_org === 'o1'), 'permissions lues sur le serveur');
  ok(JSON.stringify(w.EXB_EQUIPE.permOf('u2')) === '{"lecture":true,"creation":true,"modification":true,"validation":true,"export":true}', 'sans ligne = aucune restriction');
  ok(w.EXB_EQUIPE.permOf('u1').creation === false && w.EXB_EQUIPE.permOf('u1').lecture === true, 'u1 : création retirée, lecture conservée');
  calls.length = 0;
  const r = await w.EXB_EQUIPE.setPermissions('u2', { lecture: true, creation: true, modification: false, validation: false, export: true });
  const c = calls.find(x => x[0] === 'equipe_definir_permissions');
  ok(r === true && c && c[1].p_user === 'u2' && c[1].p_modification === false && c[1].p_validation === false && c[1].p_lecture === true && c[1].p_org === 'o1', 'enregistrement : paramètres envoyés au serveur');
  ok(w.EXB_EQUIPE.permOf('u2').modification === false && /permissions limitées/.test(html), 'écran mis à jour après enregistrement');
  console.log('\n' + (fail ? fail + ' ÉCHEC(S)' : 'Tout est réussi.')); process.exit(fail ? 1 : 0);
})();
