#!/usr/bin/env node
/* V235d — vérifie que le moteur OCR (partie 2) est complet dans site/vendor/tesseract/.
 * Usage (depuis le dossier racine, celui qui contient site/) :  node scripts/verifier-ocr.js
 * Code de sortie 0 = complet ; 1 = fichier manquant, tronqué ou langue non gzip. */
const fs=require('fs'),path=require('path');
const dir=path.resolve(__dirname,'..','site','vendor','tesseract');
const need=[['fra.traineddata.gz',500000],['tesseract.min.js',50000],['worker.min.js',80000],['tesseract-core.wasm.js',1000000],['tesseract-core-simd.wasm.js',1000000],['tesseract-core-lstm.wasm.js',1000000],['tesseract-core-simd-lstm.wasm.js',1000000]];
let bad=0;console.log('Dossier : '+dir);
need.forEach(([f,min])=>{const p=path.join(dir,f);
  if(!fs.existsSync(p)){bad++;console.log('  ✗ MANQUANT   '+f);return}
  const n=fs.statSync(p).size;
  if(n<=min){bad++;console.log('  ✗ TROP PETIT '+f+' ('+n+' octets, attendu > '+min+') : copie interrompue ?');return}
  if(f.endsWith('.gz')){const b=fs.readFileSync(p);if(b[0]!==0x1f||b[1]!==0x8b){bad++;console.log('  ✗ PAS GZIP   '+f);return}}
  console.log('  ✓ '+f+' ('+Math.round(n/1024)+' Ko)')});
console.log(bad?('\n'+bad+' problème(s) : recopiez la partie 2 OCR (LISEZ-MOI-OCR.md) dans le dossier racine, puis relancez.'):'\nMoteur OCR complet.');
process.exit(bad?1:0);
