# V229h — Ouverture des espaces membres SANS internet

Base : V229g.

## Problème
Un membre (Comptable, Ingénieur…) ne pouvait pas ouvrir son espace sans internet : l'écran de connexion répondait « Pas de connexion internet : connectez-vous pour continuer ».

## Corrigé (`exb-v205-connexion-espace.js`, `sw.js`)
- À chaque connexion EN LIGNE réussie, l'appareil mémorise : une empreinte du mot de passe (PBKDF2-SHA256, sel aléatoire, 150 000 tours — le mot de passe n'est jamais conservé), l'entreprise et la dernière fonction connue.
- Sans internet (ou serveur injoignable), le même e-mail + le même mot de passe rouvrent l'espace pendant 30 jours après la dernière connexion en ligne. Mauvais mot de passe : refus (blocage progressif après 5 échecs). Fonction sans accès à l'espace : refus.
- Pendant le travail hors connexion, l'écran de connexion ne se rouvre pas. Au retour d'internet : si la session en ligne a expiré, il redemande la connexion ; la suspension / le retrait d'un membre reprennent effet (exb-acces-membre.js, y compris la règle « plus de 7 jours sans confirmation du serveur »).
- Première utilisation d'un appareil : une connexion avec internet est nécessaire UNE fois (rien n'est encore mémorisé).

## Inchangé
Administrateur (application principale) : ouverture hors connexion déjà possible. Verrou de licence : voir V227h.
