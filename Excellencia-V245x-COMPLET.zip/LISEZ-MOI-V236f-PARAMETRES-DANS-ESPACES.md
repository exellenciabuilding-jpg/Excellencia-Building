# V236f — « Paramètres » dans chaque espace, sans la configuration de l'entreprise

Base : V236e. Modifiés : `site/exb-v99r-shell.js`, `site/index.html` (3 identifiants ajoutés), `site/sw.js` (cache v236f).

## Maintenant
- Les espaces **Comptable, Ingénieur, Architecture, Formation, Chantier, Direction et Magasin** ont « ⚙️ Paramètres » dans leur menu.
- Dans ces espaces, Paramètres n'affiche **plus** : Identité de l'entreprise, Identité de l'application (nom/sous-titre), Centre documentaire (logo, adresse, signature, cachet) ni la Zone danger (réinitialisation des données).
- Restent : thème de couleurs, sécurité, alertes sonores, mémoire du travail, boutons flottants, assistant guidé.
- La configuration de l'entreprise reste accessible au propriétaire (hors espace) et dans l'Espace Administration (`conf:true`).
- Pour la masquer aussi dans l'Administration : retirer `conf:true` de cet espace dans `ESPACES`.

Ce n'est qu'un réglage d'affichage : les droits réels restent appliqués côté serveur. Fermer complètement l'application une fois (cache v236f).
