# V227e — « Comptable devient Polyvalent » : correction

SYMPTÔME
  L'administrateur invite quelqu'un avec la fonction Comptable ; la personne crée son compte et se retrouve « Polyvalent »,
  « Accès refusé » à l'Espace Comptable. L'invitation reste « En attente » dans Équipe.

CAUSE (côté application)
  À l'arrivée de la personne, l'application demande au serveur d'appliquer son invitation (equipe_reclamer). Si cet appel échouait,
  l'erreur était avalée en silence ; la personne était alors rattachée avec le code de l'entreprise = Polyvalent, définitivement.

CORRECTIONS
  1. Équipe › après « Inviter » ou « Lien + code » : l'application relit la liste et FORCE le rôle et la fonction choisis si le serveur a mis autre chose.
  2. Équipe › à chaque ouverture : toute invitation en attente dont l'e-mail correspond à un membre déjà Polyvalent est appliquée, puis classée.
     Un choix manuel de l'administrateur n'est jamais écrasé.
  3. Écran « Accès refusé » : une ligne « Diagnostic » dit pourquoi (erreur exacte renvoyée par le serveur, ou aucune invitation trouvée).
  4. sw.js : nouvelle version, pour que les téléphones rechargent les fichiers corrigés.

À FAIRE SI LE DIAGNOSTIC MONTRE UNE ERREUR SERVEUR
  Exécuter DIAGNOSTIC-INVITATIONS.sql dans Supabase (lecture seule) et envoyer les résultats : la correction définitive est alors dans equipe_reclamer.
