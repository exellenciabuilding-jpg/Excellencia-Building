# V236d — Un appareil à « 0 » alors que le serveur contient les fiches

Base : V236c (fichier modifié : `site/exb-db.js`, cache `v236d`).

## Constat
Supervision : colonne « Serveur » 8 reçus, 5 paiements… ; colonne « Cet appareil » 0 ; « Synchroniser maintenant » → « reçu : 0 ».

## Cause
Le registre de synchronisation de l'appareil (`meta.rec`) retient, fiche par fiche, la dernière version reçue. Si la copie locale d'une rubrique est vidée (données effacées, restauration, autre dossier de l'application) alors que ce registre reste, le serveur répond « déjà reçu » et ignore la fiche : l'appareil reste vide pour toujours.

## Correctif
Pendant la réception, si une fiche est « déjà reçue » mais que la copie locale de **toute la rubrique est vide**, la fiche est reprise depuis le serveur. Les fiches supprimées restent supprimées ; une rubrique qui contient déjà des fiches n'est pas touchée.

## Après déploiement
Netlify : déposer le dossier site/. EXE/APK : reconstruire avec ce zip. Puis ouvrir l'application, attendre une minute (ou « Synchroniser maintenant ») : les compteurs « Cet appareil » rejoignent ceux du serveur.
