# V236g — Atelier de mise en page : plan d'exécution identique au logiciel + éditeur Word pour tous les PDF

Base : V236f. Modifiés : `site/atelier-mep/exb-doc-layout.js`, `exb-cartouche.js`, `exb-doc-export.js`, `app.js`, `site/exb-atelier-mep.js`, `site/sw.js` (cache v236g), `site/tools/test-atelier-mep.js` (64 vérifications, OK).

## Plan d'exécution
Un PDF importé avec le modèle « Plans d'exécution » reçoit exactement le cartouche des plans générés par le logiciel : bande pleine largeur (mêmes proportions 405 × 30, mêmes blocs, mêmes couleurs), à l'échelle de la feuille. Zone du bas libre → sur la page ; sinon bande ajoutée sous la page. Rien n'est inventé : champ vide = « À compléter » ; visa/cachet seulement si la version est Approuvée ou Émise. Pour les petits formats (A4), le cartouche est réduit proportionnellement (conçu pour A3 et plus).

## Éditeur Word
« Ouvrir dans l'éditeur Word » est disponible pour tous les PDF importés (plus seulement les notes). Le texte du PDF est repris ; PDF scanné : OCR proposé s'il est installé. Le texte est ajouté sur des feuilles supplémentaires ; l'original reste intact.

Fermer complètement l'application une fois (cache v236g).
