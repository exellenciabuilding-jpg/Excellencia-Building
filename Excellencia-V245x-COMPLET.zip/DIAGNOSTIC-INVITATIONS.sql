-- Excellencia Building V227e — DIAGNOSTIC DES INVITATIONS (LECTURE SEULE : ne modifie rien)
-- À coller dans Supabase › SQL Editor, puis « Run ». Chaque bloc donne un tableau : envoyer une capture de chacun.

-- 1) Les fonctions d'équipe existent-elles, et que font-elles ? (surtout equipe_reclamer)
select p.proname as fonction, pg_get_function_arguments(p.oid) as arguments, pg_get_functiondef(p.oid) as code
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in ('equipe_reclamer','equipe_inviter','rejoindre_organisation','mon_organisation','equipe_modifier','activer_par_invitation');

-- 2) Les comptes connectés ont-ils le droit de les appeler ?
select routine_name, grantee, privilege_type
from information_schema.routine_privileges
where routine_schema = 'public'
  and routine_name in ('equipe_reclamer','equipe_inviter','rejoindre_organisation','mon_organisation','equipe_modifier')
order by routine_name, grantee;

-- 3) Colonnes des tables d'équipe
select table_name, column_name, data_type
from information_schema.columns
where table_schema = 'public' and table_name in ('membres','invitations','equipe_invitations')
order by table_name, ordinal_position;

-- 4) Les deux comptes de test : e-mail confirmé ? entreprise ? fonction ?
select u.email, u.email_confirmed_at, u.created_at, m.role, m.fonction
from auth.users u left join public.membres m on m.user_id = u.id
where lower(u.email) in ('huguekitambala@gmail.com','louisonibwampere@gmail.com');
