-- ===== Excellencia Building V227g : mon_organisation renvoie TOUJOURS le rôle ET la fonction du membre =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger. Ne modifie aucune donnée.
-- Cause : une ancienne version de mon_organisation (schema-entreprise.sql) ne renvoie pas la fonction. Le logiciel du membre
-- lisait alors « Polyvalent » à chaque connexion, alors que la table membres contenait bien « Comptable ».
-- (Corrigé aussi côté application : elle relit la fonction dans la table membres si le serveur ne la donne pas.)

create or replace function mon_organisation()
returns json language sql stable security definer set search_path=public as $$
  select json_build_object('id',o.id,'nom',o.nom,'role',m.role,'fonction',m.fonction,
         'code',case when m.role='admin' then o.code_invitation end)
  from membres m join organisations o on o.id=m.org_id where m.user_id=auth.uid() order by m.depuis limit 1 $$;

revoke execute on function mon_organisation() from public, anon;
grant  execute on function mon_organisation() to authenticated;
notify pgrst, 'reload schema';

-- Contrôle : la colonne « renvoie_fonction » doit afficher true
select p.proname, position('''fonction''' in pg_get_functiondef(p.oid)) > 0 as renvoie_fonction
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname = 'mon_organisation';
