/* Test BI v3 : dettes fournisseurs et engagements (calcul pur, sans navigateur). node tools/test-bi-dettes.js */
const fs = require('fs'), vm = require('vm'), path = require('path');
const win = { localStorage: { getItem() { return null; }, setItem() {} }, print() {} };
win.document = { readyState: 'complete', getElementById() { return null; }, addEventListener() {}, querySelector() { return null; } };
win.setTimeout = function () {}; win.window = win; win.globalThis = win;
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../site/exb-bi.js'), 'utf8'), win);
const BI = win.EXBBI; let ok = 0, ko = 0;
function eq(a, b, m) { if (typeof a === 'number' && typeof b === 'number' ? Math.abs(a - b) < 0.005 : a === b) ok++; else { ko++; console.log('KO', m, a, '≠', b); } }
const range = { a: '2026-01-01', b: '2026-12-31', lab: 't' };
const po = [
  { id: 'a', no: 'BC1', project_id: 'P1', date: '2026-03-01', lines: [{ q: 10, pu: 100, rec: 10 }], payments: [{ amount: 400 }] },          // reçu 1000, payé 400 -> dette 600
  { id: 'b', no: 'BC2', project_id: 'P2', date: '2026-04-01', lines: [{ q: 5, pu: 200, rec: 2 }], payments: [] },                          // reçu 400 -> dette 400 ; engagé 600
  { id: 'c', no: 'BC3', project_id: 'P1', lines: [{ q: 4, pu: 50, rec: 0 }], payments: [] },                                              // engagé 200
  { id: 'd', no: 'BC4', project_id: 'P1', cancel: true, lines: [{ q: 9, pu: 99, rec: 9 }] },                                              // annulé : ignoré
  { id: 'e', no: 'BC5', project_id: 'P1', currency: 'FC', lines: [{ q: 1, pu: 5000, rec: 1 }], payments: [{ amount: 6000 }] },            // payé > reçu : dette 0
  { id: 'f', no: 'BC6', project_id: 'P1', lines: [{ q: 2, pu: 10, rec: 5 }], payments: [] }                                             // reçu > commandé : plafonné à 20
];
let r = BI.compute({ po }, { range, today: '2026-06-01' });
eq(r.kpi.USD.dettes, 600 + 400 + 20, 'dettes USD'); eq(r.kpi.USD.engages, 600 + 200, 'engagements USD');
eq(r.kpi.USD.nbDettes, 3, 'nb dettes'); eq((r.sources['USD|dettes'] || []).length, 3, 'lignes sources');
eq((r.kpi.CDF || { dettes: 0 }).dettes, 0, 'FC dette nulle');
r = BI.compute({ po }, { range, pid: 'P1', today: '2026-06-01' });
eq(r.kpi.USD.dettes, 620, 'filtre projet P1'); eq(r.kpi.USD.engages, 200, 'engagés P1');
r = BI.compute({ po: [] }, { range, today: '2026-06-01' }); eq(Object.keys(r.kpi).length, 0, 'sans données : aucun faux zéro');
const al = BI.alertes(BI.compute({ po }, { range, today: '2026-06-01' }), null, {});
eq(al.filter(a => /Dettes fournisseurs/.test(a.msg)).length, 1, 'alerte dettes > encaissé');
eq(BI.definitions.filter(d => d.id === 'dettes' || d.id === 'engages').length, 2, 'dictionnaire');
/* filtre département */
const prj = [{ id: 'P1', name: 'A', dept: 'Construction' }, { id: 'P2', name: 'B', dept: ' construction ' }, { id: 'P3', name: 'C', dept: 'Formation' }, { id: 'P4', name: 'D' }];
const po2 = po.concat([{ id: 'g', no: 'BC7', project_id: 'P3', lines: [{ q: 1, pu: 70, rec: 1 }] }, { id: 'h', no: 'BC8', lines: [{ q: 1, pu: 30, rec: 1 }] }]);
r = BI.compute({ po: po2, projects: prj }, { range, dept: 'Construction', today: '2026-06-01' });
eq(r.kpi.USD.dettes, 1020, 'département Construction (P1+P2, casse/espaces ignorés)');
r = BI.compute({ po: po2, projects: prj }, { range, dept: 'Formation', today: '2026-06-01' });
eq(r.kpi.USD.dettes, 70, 'département Formation');
r = BI.compute({ po: po2, projects: prj }, { range, today: '2026-06-01' });
eq(r.kpi.USD.dettes, 1120, 'sans filtre : tout, y compris sans projet');
r = BI.compute({ po: po2, projects: prj }, { range, dept: 'Inconnu', today: '2026-06-01' });
eq(Object.keys(r.kpi).length, 0, 'département sans projet : rien');
eq(BI.departements(prj).join('|') === 'Construction|Formation' ? 1 : 0, 1, 'liste des départements dédoublonnée');
/* jalons dans la BI (moteur EVM factice : seul le branchement est testé) */
const CPM = require('../site/exb-cpm.js'), evm = { analyseProject: () => ({ status: 'vert', alerts: [], anomalies: [] }), thFor: () => ({}), tri: x => x, consolidate: () => null };
const gantt = [{ project_id: 'P1', date: '2026-10-05', tasks: [{ start: 1, dur: 2, pct: 0 }, { start: 3, dur: 2, pct: 0, pred: '1' }], jalons: [{ name: 'Fondations', task: 1 }, { name: 'Dalle', task: 2 }] },
               { project_id: 'P3', date: '2026-10-05', tasks: [{ start: 1, dur: 1, pct: 100 }], jalons: [{ name: 'Fin', task: 1 }] }];
let pj = BI.computeProjets({ projects: prj, gantt }, { evm, cpm: CPM, today: '2026-11-15' });   // 6e semaine
const p1 = pj.rows.filter(a => a.id === 'P1')[0], p3 = pj.rows.filter(a => a.id === 'P3')[0], p4 = pj.rows.filter(a => a.id === 'P4')[0];
eq(p1.jalons.length, 2, 'jalons rattachés au projet'); eq(p1.jalons[0].statut, 'en_retard', 'fondations : prévu S2, nous sommes en S6'); eq(p3.jalons[0].statut, 'atteint', 'tâche à 100 %');
eq(p4.jalons.length, 0, 'projet sans planning'); eq(p1.dept, 'Construction', 'département exposé');
const alj = BI.alertes({ kpi: {}, rapprochement: { ok: true } }, pj, {}).filter(a => a.src === 'Jalon');
eq(alj.length, 1, 'une alerte jalon (P1 seulement)'); eq(alj[0].sev, 'high', 'gravité jalon en retard'); eq(/Fondations/.test(alj[0].msg) && /\+1 autre/.test(alj[0].msg), true, 'message avec jalon et autres en retard');
pj = BI.computeProjets({ projects: prj, gantt }, { evm, cpm: CPM, today: '2026-11-15', dept: 'Formation' }); eq(pj.rows.length, 1, 'filtre département sur les projets');
/* engagements par projet */
const poE = [
  { id: 'e1', project_id: 'P1', lines: [{ q: 10, pu: 100, rec: 4 }], payments: [{ amount: 300 }] },   // commandé 1000, reçu 400, payé 300
  { id: 'e2', project_id: 'P1', lines: [{ q: 1, pu: 500, rec: 1 }] },                               // commandé 500, reçu 500
  { id: 'e3', project_id: 'P1', cancel: true, lines: [{ q: 1, pu: 9999, rec: 0 }] },                // annulé
  { id: 'e4', project_id: 'P1', currency: 'FC', lines: [{ q: 1, pu: 80000, rec: 0 }] },            // hors USD
  { id: 'e5', project_id: 'P2', lines: [{ q: 1, pu: 70, rec: 0 }] }];
let e = BI.engagements(poE, 'P1', 2000);
eq(e.commande, 1500, 'commandé'); eq(e.recu, 900, 'reçu'); eq(e.paye, 300, 'payé'); eq(e.reste, 600, 'reste à recevoir'); eq(e.nb, 2, 'bons comptés'); eq(e.horsUsd, 1, 'FC à part');
eq(e.taux, 75, 'taux d’engagement'); eq(e.disponible, 500, 'disponible'); eq(e.depasse, false, 'pas de dépassement');
e = BI.engagements(poE, 'P1', 1200); eq(e.depasse, true, 'dépassement'); eq(e.disponible, -300, 'disponible négatif');
e = BI.engagements(poE, 'P1', 0); eq(e.taux, null, 'sans budget : pas de taux inventé'); eq(e.disponible, null, 'sans budget : pas de disponible');
e = BI.engagements(poE, 'P9', 100); eq(e.nb, 0, 'projet sans commande');
const evm2 = { analyseProject: (p) => ({ status: 'vert', bac: +p.budget || 0, alerts: [], anomalies: [] }), thFor: () => ({}), tri: x => x, consolidate: () => null };
const prj2 = [{ id: 'P1', name: 'Dépassé', budget: 1200 }, { id: 'P2', name: 'Proche', budget: 75 }, { id: 'P3', name: 'Large', budget: 100000 }];
pj = BI.computeProjets({ projects: prj2, po: poE }, { evm: evm2, today: '2026-11-15' });
const ale = BI.alertes({ kpi: {}, rapprochement: { ok: true } }, pj, {}).filter(a => a.src === 'Engagements');
eq(ale.length, 2, 'deux alertes d’engagement (P1 dépassé, P2 ≥ 90 %)'); eq(ale[0].sev, 'high', 'dépassement en tête'); eq(ale[1].sev, 'medium', 'proche du budget');
/* v6 : activité des modules (RH, Stock, CRM, Workflow) */
const T0 = '2026-11-15';
const src6 = {
  hr: [{ approval_status: 'APPROUVE', status: 'Actif' }, { approval_status: 'APPROUVE', status: 'Congé' }, { matricule: 'M1', status: 'Suspendu' }, { matricule: 'M2' }, { approval_status: 'APPROUVE', status: 'Sorti' },
       { approval_status: 'REJETE' }, { name: 'sans matricule ni approbation' }, { approval_status: 'EN_ATTENTE' }],
  stock: [{ qty: 0, min: 5 }, { qty: 5, min: 5 }, { qty: 20, min: 5 }, { qty: -1, min: 0 }],
  clients: [{ id: 1 }, { id: 2 }, { id: 3 }],
  quotes: [{ date: '2026-11-02', currency: 'USD', total: 1000.5 }, { date: '2026-11-10', currency: 'FC', total: 500000 }, { date: '2026-11-11', total: 99.5 }, { date: '2025-01-01', total: 777 }],
  wf: [{ status: 'en_cours', echeance: '2026-11-10' }, { status: 'en_cours', echeance: '2026-11-20' }, { status: 'en_cours' }, { status: 'retourne' },
       { status: 'valide', fin: '2026-11-01T10:00:00Z' }, { status: 'refuse', fin: '2026-11-14T10:00:00Z' }, { status: 'valide', fin: '2026-09-01T10:00:00Z' }]
};
const op = BI.operationnel(src6, { today: T0, range: { a: '2026-11-01', b: T0 } });
eq(op.rh.actifs, 2, 'RH actifs (approuvés + matricule sans statut)'); eq(op.rh.conge, 1, 'RH congé'); eq(op.rh.suspendus, 1, 'RH suspendus'); eq(op.rh.sortis, 1, 'RH sortis');
eq(op.rh.enAttente, 2, 'RH en attente (rejeté ignoré)');
eq(op.stock.articles, 4, 'stock articles'); eq(op.stock.aCommander, 3, 'à commander : qty ≤ seuil'); eq(op.stock.ruptures, 2, 'ruptures : qty ≤ 0');
eq(op.crm.clients, 3, 'clients'); eq(op.crm.devis, 3, 'devis de la période'); eq(op.crm.montants.USD, 1100, 'devis USD (devise par défaut)'); eq(op.crm.montants.CDF, 500000, 'devis FC à part');
eq(op.wf.enCours, 3, 'workflow en cours'); eq(op.wf.enRetard, 1, 'workflow en retard'); eq(op.wf.retournes, 1, 'workflow retournés'); eq(op.wf.valides30, 1, 'validés 30 j'); eq(op.wf.refuses30, 1, 'refusés 30 j');
const op2 = BI.operationnel(src6, { today: T0, ok: { hr: false, stock: false } });
eq(op2.rh === undefined && op2.stock === undefined && !!op2.crm && !!op2.wf, true, 'droits : modules refusés absents');
const op3 = BI.operationnel({}, { today: T0 }); eq(op3.rh.actifs + op3.stock.articles + op3.crm.devis + op3.wf.enCours, 0, 'sans données : zéros, pas d’erreur');
const al6 = BI.alertes({ kpi: {}, rapprochement: { ok: true } }, null, { ops: op });
eq(al6.filter(a => a.src === 'Stock').length, 1, 'alerte rupture de stock'); eq(al6.filter(a => a.src === 'Workflow').length, 1, 'alerte workflow en retard');
eq(BI.alertes({ kpi: {}, rapprochement: { ok: true } }, null, { ops: BI.operationnel({ stock: [{ qty: 3, min: 5 }] }, { today: T0 }) }).length, 0, 'à commander sans rupture : pas d’alerte');
eq(BI.version, 7, 'version BI');
/* v7 : historique des soldes */
const kp = { USD: { creances: 1000.456, echu: 200, dettes: 300, engages: 0 }, CDF: { creances: 0, echu: 0, dettes: 0, engages: 0 } };
let sn = BI.snapshot(kp, op, '2026-11-15');
eq(sn.mois, '2026-11', 'mois de l’instantané'); eq(sn.kpi.USD.creances, 1000.46, 'créances arrondies'); eq(sn.kpi.CDF === undefined, true, 'devise à zéro non enregistrée');
eq(sn.ops.stockCmd, 3, 'compteur stock'); eq(sn.ops.wfRetard, 1, 'compteur workflow'); eq(sn.ops.rhActifs, 2, 'compteur RH');
eq(BI.snapshot({}, null, '2026-11-15'), null, 'aucune donnée : pas d’instantané');
eq(BI.snapshot({ USD: { creances: 0, echu: 0, dettes: 0, engages: 0 } }, { rh: { actifs: 0 }, stock: { aCommander: 0, ruptures: 0 }, wf: { enCours: 0, enRetard: 0 } }, '2026-11-15'), null, 'que des zéros : pas d’instantané');
eq(BI.snapshot({}, { stock: { aCommander: 2, ruptures: 0 } }, '2026-11-15').ops.stockCmd, 2, 'seulement des compteurs');
let hh = BI.histoUpsert([], sn, 36); eq(hh.length, 1, 'premier instantané');
const sn2 = Object.assign({}, sn, { kpi: { USD: { creances: 5, echu: 0, dettes: 0, engages: 0 } } });
hh = BI.histoUpsert(hh, sn2, 36); eq(hh.length, 1, 'même mois : remplacé'); eq(hh[0].kpi.USD.creances, 5, 'dernière valeur du mois');
hh = BI.histoUpsert(hh, Object.assign({}, sn, { mois: '2026-09' }), 36); hh = BI.histoUpsert(hh, Object.assign({}, sn, { mois: '2026-10' }), 36);
eq(hh.map(x => x.mois).join(','), '2026-09,2026-10,2026-11', 'trié par mois');
let big = []; for (let i = 0; i < 40; i++) big = BI.histoUpsert(big, Object.assign({}, sn, { mois: '2020-' + String(i % 12 + 1).padStart(2, '0') + '-' + i }), 36);
eq(big.length <= 36, true, 'plafonné à 36 mois');
eq(BI.histoUpsert(hh, null, 36).length, 3, 'instantané nul ignoré'); eq(BI.histoUpsert(null, sn, 36).length, 1, 'tableau absent toléré');
console.log(ko ? ko + ' échec(s)' : 'OK : ' + ok + ' contrôles');
process.exit(ko ? 1 : 0);
