# V226 — Permissions par membre (Équipe)

Base : V225. **Changent : `site/exb-equipe.js`, `site/sw.js`, `scripts/test-equipe-annuaire.js`. Nouveau : `site/supabase/migration-v226-permissions-membres.sql`.**

## 1. À exécuter une fois dans Supabase (SQL Editor)
`site/supabase/migration-v226-permissions-membres.sql` — après v66, v99w, v99zn, v99zo, v99zp (la migration vérifie et s'arrête avec un message clair s'il en manque une). Réexécutable. **Non exécutée sur un vrai Supabase** (pas de PostgreSQL dans l'environnement de développement) : l'essayer d'abord sur la copie / le projet de recette.

## 2. Dans Équipe › Membres : bouton « 🔐 Permissions »
Cases : **Lecture · Création · Modification · Validation · Export**, plus **Administration** (= le rôle Administrateur, non modifiable ici). Pastille « 🔐 permissions limitées » sur les membres restreints. « Tout autoriser » remet le membre à l'état normal.

## 3. Ce que le serveur applique
Une permission **retire** un droit, elle n'en donne jamais (le rôle et la fonction restent le plafond). Sans ligne = aucune restriction : personne n'est bloqué par la mise à jour.
| Permission | Effet serveur |
|---|---|
| Lecture | plus aucune fiche lisible (`peut(…,false)`) |
| Création | ne peut plus ajouter de fiche (`enregistrer`) |
| Modification | ne peut plus modifier ni supprimer une fiche existante (`enregistrer`) |
| Validation | ne peut plus enregistrer valide / réserves / refus d'un calcul d'ingénieur (`validations_calcul`) |
| Export | **enregistré seulement** : une donnée lisible est exportable ; à brancher module par module (`mes_permissions`) |
| Administration | rôle Administrateur : toutes les permissions, toujours |

## 4. Limites à connaître
- Tables dédiées (erp_*, btp_*, caisse, paiements…) : elles suivent Lecture et « Création **ou** Modification » (la fonction `peut()` est partagée) ; la distinction fine Création / Modification ne vaut que pour les fiches synchronisées (`enregistrer`).
- Validation : couvre la validation des calculs d'ingénieur ; la décision dans le Workflow (V149) n'est pas encore gardée par cette permission.
- Un administrateur ne peut pas être restreint : changer d'abord son rôle.
- Un membre retiré puis réinvité retrouve ses anciennes restrictions (choix prudent) : « Tout autoriser » les efface.
- `peut()` et `enregistrer()` sont redéfinies à partir de leurs dernières versions connues (V99zp et V99zo) : si vous les avez modifiées à la main dans Supabase, comparez avant d'exécuter.

## 5. Tests
`node scripts/test-equipe-annuaire.js` (16) · `node scripts/test-equipe-licence.js` · `node site/tools/test-espaces-admin.js` (92) · `node site/tools/test-conges-courrier.js` (21).
`sw.js` : cache `v226-…` — fermer complètement l'application une fois.
