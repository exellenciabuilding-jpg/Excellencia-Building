# V222 — BCF à deux éléments + règles IDS approfondies (base V221l)

Base : V221l (contient déjà V209e–l ; ses IDS / IA Architecte sont conservés, ceux de V213b non reportés).

## Livré
- **BCF à deux éléments** (`exb-bcf.js`) : une collision écrit 2 composants dans le point de vue, relecture de `guid2`. Tests ajoutés (`test-bim/test-bcf.js` : 30/30 ; `test-coordination.js` repris de V213b : 36/36).
- **IDS — types de données** : `dataType` contrôlé contre le type réel du fichier IFC (IFCLABEL, IFCREAL, IFCBOOLEAN…) ; booléens comparés en VRAI/FAUX ; motifs « Type de données incorrect / Valeur incorrecte ».
- **IDS — « partie de »** : IfcRelAggregates, ContainedInSpatialStructure, Nests, AssignsToGroup, VoidsElement, FillsElement, avec classe et type prédéfini du parent.
- **IDS — PredefinedType exact** : rang selon classe et schéma (IFC2X3/IFC4), USERDEFINED → ObjectType, valeur absente → type de l'objet.
- **IDS — contrôle avant export** : `validate()` (structure, versions, relations, motifs) ; export refusé en cas d'erreur.
- Cache hors connexion : nom `v221l-` inchangé (le renommer fait échouer 5 contrôles de check.js à adapter) ; fermer l’app une fois après déploiement.
- Tests : `test-regles-ids.js` 33/33 ; `test:architecture` branche les nouveaux tests ; `check.js` : 979 contrôles, 0 échec. `test-ifc-batiment` passe dans cette archive complète.

## Reste à faire
1. **Lecture des plans PDF par l'IA Architecte (OCR)** : non développée. Tesseract est déjà dans `site/vendor/tesseract/` (identique au lot V209e partie 2) ; reste le module de lecture (pdf.js + OCR → locaux proposés).
2. **Interpolation du terrain** : l'analyse de site utilise l'inverse des distances ; la triangulation (TIN) et les courbes de niveau restent à faire.
3. **Validation de l'export IDS par le schéma officiel ids.xsd** : impossible ici (accès réseau bloqué) ; à faire avec un outil tiers (IfcTester, xmllint + ids.xsd).
4. Recette navigateur / Android réelle.
