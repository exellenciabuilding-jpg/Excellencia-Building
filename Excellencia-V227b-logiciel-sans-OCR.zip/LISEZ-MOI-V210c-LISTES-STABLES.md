# V210c — les listes déroulantes ne se vident plus et le panneau du menu des modules ne disparaît plus

Correctif posé sur la V210b (partie 1 sur 2). À copier par-dessus le dossier du logiciel (mêmes chemins), puis redéployer et fermer complètement l'application une fois (cache v210c).

## Problème 1 — Messagerie › Équipe : « Choisir l'espace destinataire » se vide tout seul
Cause : toutes les 30 s, la messagerie ouverte se reconstruisait si le focus n'était pas dans un champ texte. Une liste déroulante n'était pas protégée : la reconstruction remettait « — Choisir l'espace destinataire — » et effaçait l'objet et le message déjà écrits. Cela touchait tous les choix (Architecte, Comptable…), après quelques secondes.
Correction : plus de reconstruction automatique pendant un formulaire, une liste ouverte, un envoi ou le panneau des pièces jointes ; et si le panneau est reconstruit pour une autre raison (recherche, envoi), le destinataire, la personne, l'objet, le message et la case « usage unique » sont conservés.

## Problème 2 — « Menu des modules » : en choisissant la Disposition, le panneau quitte l'écran
Cause : en touchant la liste « Disposition », la barre des modules se masquait (règle prévue pour le clavier), et le panneau, placé par rapport à cette barre, était repoussé au-dessus de l'écran (invisible).
Correction : le focus dans le panneau ne masque plus la barre, et le panneau n'est plus déplacé quand la barre est masquée.

## Fichiers (chemins du dépôt)
`site/exb-messagerie.js`, `site/exb-module-dock.js`, `site/sw.js` (cache v210c), `site/tools/check.js` (+5 contrôles, 11 anciens contrôles de cache corrigés), `site/tools/e2e-listes-stables.py` (nouveau).

## Vérifications
`e2e-listes-stables.py` : 10 OK (liste ouverte 32 s sur Comptable et Architecture ; reconstruction forcée ; 3 dispositions) · `e2e-messagerie-equipe.py` : 52 OK · `check.js` : 785 OK, 0 échec.
Les problèmes avant correction ont été reproduits : après 32 s la liste revenait à vide et l'objet était effacé ; le panneau se retrouvait à −334 px (hors écran).

## À savoir
- `check.js` : 11 anciens contrôles « cache renouvelé » (V199 à V205z) cherchaient des noms de cache d'anciennes versions et échouaient depuis la V210 ; ils acceptent maintenant les versions suivantes. Résultat : 785 contrôles, 0 échec.
- `e2e-connexion-espace.py` s'arrête aussi sur la V210b d'origine (étape « après déconnexion ») : non modifié ici.
- Seule la partie 1 sur 2 a été fournie : rien dans la partie 2 n'a été vérifié.
