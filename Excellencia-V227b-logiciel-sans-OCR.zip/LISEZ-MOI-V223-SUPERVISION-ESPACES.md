# V223 — Supervision des espaces + Formation / Comptabilité en base partagée

Base : V222h + correctif V222f (Retour / Avant).

## 1. Formation et Comptabilité passent en base partagée (`site/exb-db.js`)
Collections ajoutées (fiche par fiche, multi-utilisateurs) : apprenants, formations, formateurs, présences, évaluations, cotations, certificats, planning des séances, **reçus**, **paiements apprenants**.
- Identifiants **stables** (participant_id, receipt_no, payment_id, cert_no… ; présence = date + participant) : la même fiche garde le même id sur tous les appareils, sans doublon à la fusion.
- Les fiches existantes de l'appareil administrateur sont envoyées au serveur à la première synchronisation ; les autres appareils les reçoivent.
- **À exécuter une fois dans Supabase (SQL Editor) :** `site/supabase/migration-v223-formation-comptabilite-partage.sql` (droits par fonction : direction = tout ; formateur = pédagogie sans reçus ni paiements ; comptable = reçus et paiements, lecture des apprenants/formations). Essayer d'abord sur la copie.

## 2. 🧭 Supervision des espaces (`site/exb-v223-espaces-admin.js`)
Bouton dans le menu Administration (à côté de « 📡 Supervision ») et dans l'Espace Direction. Administrateur seulement, **lecture seule**, couleurs Excellencia (marine / or, thème clair et sombre).
- Onglets : Synthèse, Comptabilité, Ingénieur/Chantier, Formation, Autres services, Direction.
- Par rubrique : fiches sur cet appareil, fiches sur le **serveur** (✓ si identiques, ⚠ sinon), état 🟢/🟠/⚪, dernière fiche et 5 dernières.
- Indicateurs réels uniquement (reçus à encaisser, séances à venir, répartitions par statut). Aucun montant additionné (devises différentes).
- **Activité récente des membres** (journal partagé) : qui a créé / modifié / supprimé quoi ; ⛔ = refus de droits (droit manquant).
- Membres par fonction, état de synchronisation, bouton « 🔄 Synchroniser ».

## 3. Tests
`node site/tools/test-espaces-admin.js` (30 contrôles) · `node scripts/test-equipe-licence.js`. `sw.js` : cache `v223-…` — fermer complètement l'application une fois.

## Limites
- Non essayé sur un vrai Supabase : exécuter le SQL et tester sur la copie avant la production.
- Photos d'apprenants dans les fiches : première synchronisation possiblement lente.
- Portail formateur à matricule et modules TFL : tables Supabase propres, hors de ce tableau.
- Un formateur / comptable doit être membre de l'entreprise avec la bonne fonction pour que ses saisies arrivent chez l'administrateur.
- « Congés & présences » et « Courrier » (maquette) : pas de collection dans le logiciel central. Rapports financiers : calculés à l'écran, non enregistrés.
