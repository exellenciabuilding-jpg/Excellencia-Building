/* Excellencia Building V224 — 🏖️ CONGÉS & ABSENCES  +  ✉️ REGISTRE DU COURRIER.
 * Deux modules qui manquaient au logiciel central (« Congés & présences » et « Courrier » de la maquette Multi-Espaces V205).
 *   · Congés : demande, approbation / refus (direction, RH, administrateur), détection de chevauchement, jours calendaires.
 *   · Courrier : registre des courriers entrants / sortants, service concerné, échéance, statut de traitement.
 * Les fiches sont enregistrées dans exb_leaves / exb_mail → collections partagées « conges » et « courrier » (exb-db.js),
 * donc visibles en temps réel dans 🧭 Supervision des espaces (Autres services).
 * Droits : appliqués par le serveur (migration-v224-modules-supervision.sql) ; ici : lecture seule si le droit d'écriture manque.
 * Retirer : supprimer la balise <script src="exb-v224-conges-courrier.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBCC) return;
  var KL = 'exb_leaves', KM = 'exb_mail';
  var TYPES = ['Congé annuel', 'Maladie', 'Maternité / paternité', 'Congé sans solde', 'Permission exceptionnelle', 'Autre'];
  var STL = ['Demandé', 'Approuvé', 'Refusé', 'Annulé'];
  var STM = ['Reçu', 'En traitement', 'Traité', 'Archivé'];
  var SERV = ['Direction', 'Comptabilité', 'Ingénieur / Chantier', 'Bureau d’études', 'Architecte', 'Formation', 'RH', 'Magasin', 'Autre'];

  /* ---------- fonctions pures (testées en Node) ---------- */
  function isoOk(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && !isNaN(Date.parse(s + 'T00:00:00Z')); }
  function jours(du, au) {
    if (!isoOk(du) || !isoOk(au)) return 0;
    var n = Math.round((Date.parse(au + 'T00:00:00Z') - Date.parse(du + 'T00:00:00Z')) / 86400000) + 1;
    return n > 0 ? n : 0;
  }
  function actif(c) { return c && (c.status === 'Demandé' || c.status === 'Approuvé'); }
  function chevauche(list, emp, du, au, sauf) {
    var e = String(emp || '').trim().toLowerCase();
    return (list || []).filter(function (c) {
      return c && c.id !== sauf && actif(c) && String(c.employee || '').trim().toLowerCase() === e && c.from <= au && c.to >= du;
    });
  }
  function validerConge(c, list) {
    var err = [];
    if (!String(c.employee || '').trim()) err.push('Le nom de l’employé est obligatoire.');
    if (TYPES.indexOf(c.type) < 0) err.push('Type de congé inconnu.');
    if (!isoOk(c.from) || !isoOk(c.to)) err.push('Dates invalides.');
    else if (c.to < c.from) err.push('La date de fin précède la date de début.');
    else if (chevauche(list, c.employee, c.from, c.to, c.id).length) err.push('Cet employé a déjà un congé demandé ou approuvé sur cette période.');
    return err;
  }
  function statsConges(list, jour) {
    var r = { total: 0, demandes: 0, approuves: 0, enCours: 0, jours: 0 };
    (list || []).forEach(function (c) {
      if (!c) return; r.total++;
      if (c.status === 'Demandé') r.demandes++;
      if (c.status === 'Approuvé') { r.approuves++; r.jours += jours_(c); if (c.from <= jour && c.to >= jour) r.enCours++; }
    });
    return r;
  }
  function jours_(c) { return jours(c.from, c.to); }
  function enRetard(m, jour) { return !!(m && m.due && /^\d{4}-\d{2}-\d{2}/.test(m.due) && m.due.slice(0, 10) < jour && m.status !== 'Traité' && m.status !== 'Archivé' && m.direction === 'Entrant'); }
  function statsCourrier(list, jour) {
    var r = { total: 0, entrants: 0, sortants: 0, aTraiter: 0, enRetard: 0 };
    (list || []).forEach(function (m) {
      if (!m) return; r.total++;
      if (m.direction === 'Sortant') r.sortants++; else r.entrants++;
      if (m.direction !== 'Sortant' && (m.status === 'Reçu' || m.status === 'En traitement')) r.aTraiter++;
      if (enRetard(m, jour)) r.enRetard++;
    });
    return r;
  }
  function refCourrier(direction, date, hasard) { return (direction === 'Sortant' ? 'S-' : 'E-') + String(date || '').replace(/-/g, '') + '-' + String(hasard || '000').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4); }
  function validerCourrier(m) {
    var err = [];
    if (m.direction !== 'Entrant' && m.direction !== 'Sortant') err.push('Indiquez entrant ou sortant.');
    if (!isoOk(m.date)) err.push('Date invalide.');
    if (!String(m.subject || '').trim()) err.push('L’objet est obligatoire.');
    if (!String(m.correspondent || '').trim()) err.push('L’expéditeur / destinataire est obligatoire.');
    return err;
  }
  function trier(list) { return (list || []).slice().sort(function (a, b) { var x = String(a.date || a.from || a.created_at || ''), y = String(b.date || b.from || b.created_at || ''); return x < y ? 1 : x > y ? -1 : 0; }); }

  /* ---------- accès aux données ---------- */
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function info() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || { on: false }; } catch (e) { return { on: false }; } }
  function peut(col, m) { try { return !(w.EXBDB && w.EXBDB.can) || w.EXBDB.can(col, m); } catch (e) { return true; } }
  function decideur() { var i = info(); return !i.on || i.role === 'admin' || i.fonction === 'direction' || i.fonction === 'rh'; }
  function qui() { try { return (w.EXBLIC && w.EXBLIC.who && w.EXBLIC.who()) || (info().label) || ''; } catch (e) { return ''; } }
  function nowIso() { return new Date().toISOString(); }
  function jour() { return nowIso().slice(0, 10); }
  function uid(p) { return p + '-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t) { try { w.notify(m, t || 'info', 5000); } catch (e) { try { w.alert(m); } catch (x) {} } }
  function audit(a, b) { try { if (typeof w.audit === 'function') w.audit(a, b); } catch (e) {} }
  function ask(m) { try { return typeof w.exbConfirm === 'function' ? w.exbConfirm(m) : Promise.resolve(w.confirm(m)); } catch (e) { return Promise.resolve(false); } }

  /* ---------- style (marine / or, thème clair et sombre) ---------- */
  var CSS = '#cc_c{background:#eef1f6;color:#202633;width:100%;max-width:960px;border-radius:14px;overflow:hidden;font-family:Arial,sans-serif}' +
    '#cc_c .eh{background:linear-gradient(135deg,#13294e,#284775);color:#fff;padding:13px 16px;border-bottom:3px solid #c49a38;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}' +
    '#cc_c .eh b{font-size:17px}#cc_c .eh small{display:block;color:#dce4f0;font-size:11px}#cc_c .eh button{border:0;border-radius:8px;padding:8px 11px;font-weight:bold;cursor:pointer;background:#fff;color:#173565}' +
    '#cc_c .eb{padding:14px}#cc_c .kp{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:12px}' +
    '#cc_c .k{background:#fff;border-radius:12px;padding:10px;box-shadow:0 3px 16px #0001;border-top:3px solid #c49a38}#cc_c .k small{color:#667085;font-size:11px}#cc_c .k b{display:block;font-size:21px;color:#173565;margin-top:3px}' +
    '#cc_c .cd{background:#fff;border-radius:12px;padding:13px;box-shadow:0 3px 16px #0001;margin-bottom:12px}#cc_c h4{margin:0 0 8px;color:#173565;font-size:15px}' +
    '#cc_c .fm{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px}#cc_c label{font-size:11px;color:#667085;display:block}' +
    '#cc_c input,#cc_c select,#cc_c textarea{width:100%;box-sizing:border-box;padding:7px;border:1px solid #c9d2e1;border-radius:7px;background:#fff;color:#202633;font-size:13px}' +
    '#cc_c .pb{border:0;border-radius:8px;padding:8px 12px;background:#173565;color:#fff;font-weight:bold;cursor:pointer;margin-top:8px}#cc_c .mb{border:0;border-radius:6px;padding:4px 8px;background:#dce4f0;color:#173565;cursor:pointer;font-size:11px;margin:1px}' +
    '#cc_c table{width:100%;border-collapse:collapse;font-size:12px}#cc_c th{background:#173565;color:#fff;text-align:left;padding:7px;font-size:11px}#cc_c td{padding:7px;border-bottom:1px solid #e2e7ef;vertical-align:top}' +
    '#cc_c .wr{background:#fff7e6;border:1px solid #e9d9a8;color:#7a5a12;border-radius:8px;padding:8px 10px;font-size:12px;margin-bottom:10px}#cc_c .er{background:#fff1f0;border:1px solid #f3b7b1;color:#7a1d16;border-radius:8px;padding:8px 10px;font-size:12px;margin-top:8px}#cc_c .mu{color:#667085;font-size:12px}#cc_c .tw{overflow:auto}' +
    '#cc_c .tabs{display:flex;gap:6px;margin-bottom:12px}#cc_c .tabs button{border:0;border-radius:8px;padding:9px 12px;background:#dce4f0;color:#173565;font-weight:bold;cursor:pointer}#cc_c .tabs button.on{background:#173565;color:#fff;box-shadow:inset 0 -3px #c49a38}' +
    'html[data-exb-theme="dark"] #cc_c{background:#0d1424;color:#e4e9f3}html[data-exb-theme="dark"] #cc_c .k,html[data-exb-theme="dark"] #cc_c .cd{background:#151f33;box-shadow:none}html[data-exb-theme="dark"] #cc_c .k b,html[data-exb-theme="dark"] #cc_c h4{color:#6ea8ff}' +
    'html[data-exb-theme="dark"] #cc_c input,html[data-exb-theme="dark"] #cc_c select,html[data-exb-theme="dark"] #cc_c textarea{background:#0d1424;color:#e4e9f3;border-color:#2a3a58}html[data-exb-theme="dark"] #cc_c td{border-color:#2a3a58}' +
    'html[data-exb-theme="dark"] #cc_c .tabs button,html[data-exb-theme="dark"] #cc_c .mb{background:#1b2740;color:#cdd8ef}html[data-exb-theme="dark"] #cc_c .tabs button.on{background:#2f6fdb;color:#fff}html[data-exb-theme="dark"] #cc_c th{background:#22314d}' +
    'html[data-exb-theme="dark"] #cc_c .wr{background:#2b2412;border-color:#5b4a1c;color:#f0d98a}html[data-exb-theme="dark"] #cc_c .er{background:#2d1715;border-color:#6a2b26;color:#f3b7b1}html[data-exb-theme="dark"] #cc_c .mu,html[data-exb-theme="dark"] #cc_c label,html[data-exb-theme="dark"] #cc_c .k small{color:#9fb0cf}';
  function css() { if (d.getElementById('cc_css')) return; var s = d.createElement('style'); s.id = 'cc_css'; s.textContent = CSS; d.head.appendChild(s); }

  /* ---------- écran ---------- */
  var TAB = 'conges', ERR = '';
  function opts(a, v) { return a.map(function (x) { return '<option' + (x === v ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join(''); }
  function vueConges() {
    var L = trier(rd(KL)), S = statsConges(L, jour()), ecr = peut('conges', 'ecrire'), dec = decideur(), h = '';
    h += '<div class="kp"><div class="k"><small>Demandes en attente</small><b>' + S.demandes + '</b></div><div class="k"><small>Congés approuvés</small><b>' + S.approuves + '</b></div><div class="k"><small>En congé aujourd’hui</small><b>' + S.enCours + '</b></div><div class="k"><small>Jours approuvés</small><b>' + S.jours + '</b></div></div>';
    if (!ecr) h += '<div class="wr">Votre fonction ne permet pas d’enregistrer des congés : lecture seule.</div>';
    else h += '<div class="cd"><h4>➕ Nouvelle demande de congé</h4><div class="fm"><div><label>Employé</label><input id="cc_emp" placeholder="Nom et prénom"/></div><div><label>Type</label><select id="cc_typ">' + opts(TYPES) + '</select></div><div><label>Du</label><input id="cc_du" type="date" value="' + jour() + '"/></div><div><label>Au</label><input id="cc_au" type="date" value="' + jour() + '"/></div></div><div style="margin-top:8px"><label>Motif / remarque</label><input id="cc_mot"/></div><button class="pb" id="cc_addl" type="button">Enregistrer la demande</button>' + (ERR && TAB === 'conges' ? '<div class="er">' + ERR + '</div>' : '') + '</div>';
    h += '<div class="cd"><h4>🏖️ Congés et absences</h4>' + (L.length ? '<div class="tw"><table><thead><tr><th>Employé</th><th>Type</th><th>Période</th><th>Jours</th><th>Statut</th><th></th></tr></thead><tbody>' + L.map(function (c) {
      var b = '';
      if (ecr && dec && c.status === 'Demandé') b += '<button class="mb" data-l="' + esc(c.id) + '" data-s="Approuvé">✔ Approuver</button><button class="mb" data-l="' + esc(c.id) + '" data-s="Refusé">✖ Refuser</button>';
      if (ecr && (c.status === 'Demandé' || c.status === 'Approuvé')) b += '<button class="mb" data-l="' + esc(c.id) + '" data-s="Annulé">Annuler</button>';
      return '<tr><td><b>' + esc(c.employee) + '</b>' + (c.reason ? '<div class="mu">' + esc(c.reason) + '</div>' : '') + '</td><td>' + esc(c.type) + '</td><td>' + esc(c.from) + ' → ' + esc(c.to) + '</td><td>' + jours_(c) + '</td><td>' + esc(c.status) + (c.decided_by ? '<div class="mu">par ' + esc(c.decided_by) + '</div>' : '') + '</td><td>' + b + '</td></tr>';
    }).join('') + '</tbody></table></div>' : '<div class="mu">Aucun congé enregistré.</div>') + '</div>';
    return h;
  }
  function vueCourrier() {
    var L = trier(rd(KM)), S = statsCourrier(L, jour()), ecr = peut('courrier', 'ecrire'), h = '';
    h += '<div class="kp"><div class="k"><small>Entrants</small><b>' + S.entrants + '</b></div><div class="k"><small>Sortants</small><b>' + S.sortants + '</b></div><div class="k"><small>À traiter</small><b>' + S.aTraiter + '</b></div><div class="k"><small>Échéance dépassée</small><b>' + S.enRetard + '</b></div></div>';
    if (!ecr) h += '<div class="wr">Votre fonction ne permet pas d’enregistrer du courrier : lecture seule.</div>';
    else h += '<div class="cd"><h4>➕ Enregistrer un courrier</h4><div class="fm"><div><label>Sens</label><select id="cc_dir"><option>Entrant</option><option>Sortant</option></select></div><div><label>Date</label><input id="cc_dat" type="date" value="' + jour() + '"/></div><div><label>Expéditeur / destinataire</label><input id="cc_cor"/></div><div><label>Service concerné</label><select id="cc_srv">' + opts(SERV) + '</select></div><div><label>Échéance de réponse</label><input id="cc_ech" type="date"/></div></div><div style="margin-top:8px"><label>Objet</label><input id="cc_obj"/></div><button class="pb" id="cc_addm" type="button">Enregistrer le courrier</button>' + (ERR && TAB === 'courrier' ? '<div class="er">' + ERR + '</div>' : '') + '</div>';
    h += '<div class="cd"><h4>✉️ Registre du courrier</h4>' + (L.length ? '<div class="tw"><table><thead><tr><th>Réf.</th><th>Date</th><th>Correspondant</th><th>Objet</th><th>Service</th><th>Statut</th><th></th></tr></thead><tbody>' + L.map(function (m) {
      var b = ecr ? STM.filter(function (s) { return s !== m.status; }).map(function (s) { return '<button class="mb" data-m="' + esc(m.id) + '" data-s="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') : '';
      return '<tr><td>' + esc(m.ref) + '<div class="mu">' + esc(m.direction) + '</div></td><td>' + esc(m.date) + (m.due ? '<div class="mu' + '">échéance ' + esc(m.due) + (enRetard(m, jour()) ? ' ⚠' : '') + '</div>' : '') + '</td><td>' + esc(m.correspondent) + '</td><td>' + esc(m.subject) + '</td><td>' + esc(m.service) + '</td><td>' + esc(m.status) + '</td><td>' + b + '</td></tr>';
    }).join('') + '</tbody></table></div>' : '<div class="mu">Aucun courrier enregistré.</div>') + '<div class="mu" style="margin-top:8px">Registre manuel : ce n’est pas une boîte e-mail. Les pièces jointes se rangent dans Documents / Archives.</div></div>';
    return h;
  }
  function paint() {
    var c = d.getElementById('cc_c'); if (!c) return;
    c.innerHTML = '<div class="eh"><div><b>' + (TAB === 'conges' ? '🏖️ Congés &amp; absences' : '✉️ Registre du courrier') + '</b><small>Données partagées entre les membres selon les droits de leur fonction</small></div><div><button id="cc_x" type="button">✕</button></div></div><div class="eb"><div class="tabs"><button data-t="conges" class="' + (TAB === 'conges' ? 'on' : '') + '">🏖️ Congés</button><button data-t="courrier" class="' + (TAB === 'courrier' ? 'on' : '') + '">✉️ Courrier</button></div>' + (TAB === 'conges' ? vueConges() : vueCourrier()) + '</div>';
    c.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { TAB = b.getAttribute('data-t'); ERR = ''; paint(); }; });
    var x = d.getElementById('cc_x'); if (x) x.onclick = close;
    var al = d.getElementById('cc_addl'); if (al) al.onclick = ajouterConge;
    var am = d.getElementById('cc_addm'); if (am) am.onclick = ajouterCourrier;
    c.querySelectorAll('[data-l]').forEach(function (b) { b.onclick = function () { statutConge(b.getAttribute('data-l'), b.getAttribute('data-s')); }; });
    c.querySelectorAll('[data-m]').forEach(function (b) { b.onclick = function () { statutCourrier(b.getAttribute('data-m'), b.getAttribute('data-s')); }; });
  }
  function v(id) { var e = d.getElementById(id); return e ? String(e.value || '').trim() : ''; }
  function ajouterConge() {
    if (!peut('conges', 'ecrire')) return;
    var L = rd(KL), c = { id: uid('CNG'), employee: v('cc_emp'), type: v('cc_typ'), from: v('cc_du'), to: v('cc_au'), reason: v('cc_mot'), status: 'Demandé', created_at: nowIso(), created_by: qui() };
    var err = validerConge(c, L); if (err.length) { ERR = err.map(esc).join('<br>'); return paint(); }
    c.days = jours(c.from, c.to); L.push(c);
    if (!wr(KL, L)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); }
    ERR = ''; audit('CONGÉ_DEMANDÉ', c.employee + ' ' + c.from + '→' + c.to); say('Demande de congé enregistrée.', 'success'); paint();
  }
  function statutConge(id, st) {
    if (STL.indexOf(st) < 0 || !peut('conges', 'ecrire')) return;
    if ((st === 'Approuvé' || st === 'Refusé') && !decideur()) return say('Seuls la direction, les RH et l’administrateur décident des congés.', 'warn');
    var L = rd(KL), c = L.filter(function (x) { return x.id === id; })[0]; if (!c) return;
    c.status = st; c.updated_at = nowIso(); if (st === 'Approuvé' || st === 'Refusé') { c.decided_by = qui(); c.decided_at = c.updated_at; }
    wr(KL, L); audit('CONGÉ_' + st.toUpperCase(), c.employee); paint();
  }
  function ajouterCourrier() {
    if (!peut('courrier', 'ecrire')) return;
    var m = { id: uid('COU'), direction: v('cc_dir'), date: v('cc_dat'), correspondent: v('cc_cor'), service: v('cc_srv'), due: v('cc_ech'), subject: v('cc_obj'), status: v('cc_dir') === 'Sortant' ? 'Traité' : 'Reçu', created_at: nowIso(), created_by: qui() };
    var err = validerCourrier(m); if (err.length) { ERR = err.map(esc).join('<br>'); return paint(); }
    m.ref = refCourrier(m.direction, m.date, Math.random().toString(36).slice(2, 6));
    var L = rd(KM); L.push(m);
    if (!wr(KM, L)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); }
    ERR = ''; audit('COURRIER_ENREGISTRÉ', m.ref + ' ' + m.subject); say('Courrier enregistré : ' + m.ref, 'success'); paint();
  }
  function statutCourrier(id, st) {
    if (STM.indexOf(st) < 0 || !peut('courrier', 'ecrire')) return;
    var L = rd(KM), m = L.filter(function (x) { return x.id === id; })[0]; if (!m) return;
    m.status = st; m.updated_at = nowIso(); wr(KM, L); audit('COURRIER_STATUT', m.ref + ' → ' + st); paint();
  }
  function close() { var o = d.getElementById('cc_ov'); if (o) o.remove(); }
  function open(tab) {
    if (tab === 'conges' || tab === 'courrier') TAB = tab;
    if (!peut('conges', 'lire') && !peut('courrier', 'lire')) { say('Votre fonction n’a pas accès à ce module.', 'warn'); return; }
    close(); css(); ERR = '';
    var o = d.createElement('div'); o.id = 'cc_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9990;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.onclick = function (e) { if (e.target === o) close(); };
    o.innerHTML = '<div id="cc_c"></div>'; d.body.appendChild(o); paint();
  }
  function mount() {
    if (d.getElementById('bconges')) return;
    var a = d.getElementById('brh') || d.getElementById('bcompta'); if (!a || !a.parentNode) return;
    var b1 = d.createElement('button'); b1.id = 'bconges'; b1.textContent = '🏖️ Congés & absences'; b1.onclick = function () { open('conges'); };
    var b2 = d.createElement('button'); b2.id = 'bcourrier'; b2.textContent = '✉️ Courrier'; b2.onclick = function () { open('courrier'); };
    a.parentNode.insertBefore(b2, a.nextSibling); a.parentNode.insertBefore(b1, a.nextSibling);
  }
  function start() {
    mount(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000);
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'conges-courrier', name: 'Congés & Courrier', version: '224.0.0', area: 'RH', provides: ['rh.conges', 'courrier.registre'] }); } catch (e) {}
    /* un collègue modifie une fiche : l'écran ouvert se réaffiche */
    w.exbReRenderCC = function () { try { if (d.getElementById('cc_c')) paint(); } catch (e) {} };
  }
  w.EXBCC = { open: open, pure: { jours: jours, chevauche: chevauche, validerConge: validerConge, statsConges: statsConges, statsCourrier: statsCourrier, enRetard: enRetard, refCourrier: refCourrier, validerCourrier: validerCourrier, trier: trier } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
