/* Tests V176 : écritures de paie (node tools/test-compta-paie.js). Chiffres calculés à la main. */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const store = {}, logs = [];
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.load = (k, df) => { try { const v = JSON.parse(store[k]); return v == null ? df : v; } catch (e) { return df; } };
global.save = (k, v) => { store[k] = JSON.stringify(v); return true; };
global.notify = () => {};
global.EXBCore = { audit: { log: (a, o) => logs.push(a + '|' + o) }, modules: { register() {} } };
global.document = { readyState: 'loading', addEventListener() {}, getElementById: () => null, createElement: () => ({}), body: { appendChild() {} }, hidden: false };
const setStore = (k, v) => { store[k] = JSON.stringify(v); };
require('../exb-compta.js'); require('../exb-compta-etats.js'); require('../exb-compta-paie.js'); /* paie V173 chargée : les deux modules doivent coexister */
const T = window.EXBCOMPTA._t, X = window.EXBCOMPTA._x;
setStore('exb_invoices', [{ id: 'f1', no: 'FA-1', client: 'K', date: '2026-10-05', due: '2026-10-30', tva: 16, currency: 'USD', lines: [{ q: 2, pu: 500 }], payments: [] }]);
setStore('exb_cash', [{ id: 'c1', date: '2026-10-15', type: 'out', label: 'Loyer', amount: 200, currency: 'USD', method: 'Espèces' }, { id: 'c2', date: '2026-11-02', type: 'out', label: 'Salaire Paul octobre', amount: 410, currency: 'USD', method: 'Espèces' }]);
const baseJson = JSON.stringify(T.entries());
require('../exb-compta-paie-v81.js');
const P = window.EXBCOMPTA_PAIEV81, E = window.EXBCOMPTA_ETATS;
ok(P && P.version === 1, 'module chargé');
eq(JSON.stringify(T.entries()), baseJson, 'désactivé : journal strictement identique à la V175');

/* ---- bulletin : 1000 brut ; INSS sal 50 ; patronal 130+35+2 = 167 ; IPR 40 ; avance 100 ; net 810 ---- */
const fin = { gross: 1000, inssE: 50, inssP: 130, inpp: 35, onem: 2, ipr: 40, avances: 100, retDiv: 0, net: 810, cost: 1167 };
const bul = (id, per, st, f) => ({ id, type: 'bulletin', period: per, emp: 'E1', name: 'Paul', status: st, fin: f });
const L1 = P._t.bulletinLines(bul('B1', '2026-10', 'validé', fin));
eq(L1, [['661', 1000, 0], ['664', 167, 0], ['421', 0, 810], ['431', 0, 217], ['447', 0, 40], ['425', 0, 100]], 'lignes du bulletin');
ok(P._t.bulletinLines(bul('B', '2026-10', 'validé', Object.assign({}, fin, { net: 900 }))) === null, 'bulletin déséquilibré écarté');
ok(P._t.bulletinLines({ status: 'validé' }) === null, 'bulletin sans montants figés écarté');
eq(P._t.lastDay('2026-02'), '2026-02-28', 'dernier jour de février 2026'); eq(P._t.lastDay('2028-02'), '2028-02-29', 'année bissextile');

/* ---- activation ---- */
setStore('exb_payroll', [bul('B1', '2026-10', 'validé', fin), bul('B2', '2026-10', 'brouillon', fin), bul('B0', '2026-09', 'validé', fin), bul('BX', '2026-10', 'validé', Object.assign({}, fin, { net: 1 }))]);
ok(/AAAA-MM/.test(P.setPaie(true, '').error), 'mois obligatoire');
setStore(X.K.cl, [{ ym: '2026-09' }]);
ok(/clôturé/.test(P.setPaie(true, '2026-09').error), 'activation refusée sur un mois clôturé');
ok(P.setPaie(true, '2026-10').ok && P.cfg().on, 'activation à partir de 2026-10 (après le dernier mois clôturé)');
let L = T.entries(), po = L.filter(e => e.jr === 'OD');
eq(po.length, 6, 'un seul bulletin comptabilisé (brouillon, antérieur et déséquilibré ignorés) : 6 lignes');
ok(po.every(e => e.date === '2026-10-31' && e.cur === 'USD'), 'daté de fin de mois, en USD');
const sm = (a, f) => po.filter(e => e.acc === a).reduce((s, e) => s + f(e), 0);
eq([sm('661', e => e.d), sm('664', e => e.d), sm('421', e => e.c), sm('431', e => e.c), sm('447', e => e.c), sm('425', e => e.c)], [1000, 167, 810, 217, 40, 100], 'montants par compte');
eq(po.reduce((s, e) => s + e.d, 0), po.reduce((s, e) => s + e.c, 0), 'écriture équilibrée');
ok(L.filter(e => e.jr !== 'OD').length === JSON.parse(baseJson).length, 'écritures existantes inchangées');
let R = E.resultat(L.filter(e => e.cur === 'USD')), B = E.bilan(L.filter(e => e.cur === 'USD'));
eq(R.charges.map(c => [c.acc, c.amount]).filter(c => ['661', '664'].includes(c[0])), [['661', 1410], ['664', 167]], 'avant rapprochement : 661 = bulletin 1000 + sortie de caisse 410 (double compte à corriger)');
ok(B.equilibre, 'bilan équilibré avec la paie');

/* ---- règlements ---- */
ok(/introuvable/.test(P.addReg({ bulletinId: 'ZZ', date: '2026-10-31', amount: 10 }).error), 'bulletin inconnu refusé');
ok(/antérieure/.test(P.addReg({ bulletinId: 'B1', date: '2026-09-30', amount: 10 }).error), 'date avant le mois d’activation refusée');
ok(/dépasse/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-05', amount: 811 }).error), 'règlement > reste refusé');
let r = P.addReg({ bulletinId: 'B1', date: '2026-11-05', amount: 400, acc: '571' });
ok(r.rec && r.rec.amount === 400, 'règlement direct 400 enregistré');
L = T.entries(); let rg = L.filter(e => e.piece.startsWith('REGL-'));
eq(rg.map(e => [e.acc, e.d, e.c]), [['421', 400, 0], ['571', 0, 400]], 'règlement direct : débit 421 / crédit caisse');
/* rapprochement de la sortie de caisse c2 (410) : reste 810 − 400 = 410 */
ok(/montant/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-02', amount: 400, cashId: 'c2' }).error), 'montant ≠ sortie de caisse refusé');
ok(/date/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-03', amount: 410, cashId: 'c2' }).error), 'date ≠ sortie de caisse refusée');
ok(/introuvable/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-02', amount: 410, cashId: 'cX' }).error), 'sortie inconnue refusée');
let r2 = P.addReg({ bulletinId: 'B1', date: '2026-11-02', amount: 410, cashId: 'c2' });
ok(r2.rec, 'sortie de caisse rapprochée');
ok(/déjà rapprochée/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-02', amount: 410, cashId: 'c2' }).error), 'une sortie ne se rapproche qu’une fois');
L = T.entries().filter(e => e.cur === 'USD');
eq(L.filter(e => e.piece.startsWith('RAPPR-')).map(e => [e.acc, e.d, e.c]), [['421', 410, 0], ['661', 0, 410]], 'rapprochement : débit 421 / crédit 661 (reclassement)');
const bal = a => L.filter(e => e.acc === a).reduce((s, e) => s + e.d - e.c, 0);
eq([bal('421'), bal('661')], [-810 + 400 + 410, 1000], 'après règlements : 421 soldé à 0, charge 661 = 1000 (plus de double compte)');
ok(E.bilan(L).equilibre, 'bilan équilibré après règlements');
const st = P.etat(); eq([st.rows.length, st.rows[0].paye, st.rows[0].reste, st.skipped.length], [1, 810, 0, 1], 'état : réglé 810, reste 0, 1 bulletin écarté');
ok(/dépasse/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-06', amount: 1 }).error), 'plus rien à régler');

/* ---- annulation ---- */
ok(/motif/.test(P.cancelReg(r.rec.id, '').error), 'motif d’annulation obligatoire');
ok(P.cancelReg(r.rec.id, 'erreur de saisie').ok, 'règlement annulé');
L = T.entries().filter(e => e.cur === 'USD'); ok(!L.some(e => e.piece.startsWith('REGL-')), 'écritures du règlement annulé retirées');
eq(P.etat().rows[0].reste, 400, 'reste rétabli à 400');
ok(/introuvable|annulé/.test(P.cancelReg(r.rec.id, 'encore').error), 'double annulation refusée');

/* ---- mois clôturé ---- */
setStore(X.K.cl, [{ ym: '2026-09' }, { ym: '2026-11' }]);
ok(/clôturé/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-20', amount: 10 }).error), 'règlement dans un mois clôturé refusé');
ok(/clôturé/.test(P.cancelReg(r2.rec.id, 'test').error), 'annulation dans un mois clôturé refusée');

/* ---- désactivation : retour exact ---- */
ok(P.setPaie(false).ok && !P.cfg().on, 'désactivation');
eq(JSON.stringify(T.entries()), baseJson, 'désactivé : journal à nouveau identique à la V175');
ok(logs.some(l => l.startsWith('compta.paiev81.reglement')) && logs.some(l => l.startsWith('compta.paiev81.active')), 'audit des actions de paie');

/* ---- une seule source par salaire (employé × mois) avec la paie V173 : tous les parcours ---- */
setStore(X.K.cl, []);
const nPaie = () => T.entries().filter(e => e.piece.startsWith('PAIE-')).length, nReg = () => T.entries().filter(e => /^(REGL|RAPPR)-/.test(e.piece)).length;
setStore('exb_paie_runs', []);
ok(P.setPaie(true, '2026-10').ok, 'activation sans paie V173');
eq([nPaie(), nReg() > 0], [6, true], 'parcours A — V81 seul : bulletin et règlements comptabilisés');
/* B : la paie V173 valide ensuite le même employé et le même mois */
setStore('exb_paie_runs', [{ id: 'R1', ym: '2026-10', status: 'validée', lines: [{ emp: 'E1' }] }]);
eq([nPaie(), nReg()], [0, 0], 'parcours B — V173 validée après coup pour E1 : bulletin V81 ET ses règlements sortent du journal');
eq(P.etat().rows.length, 0, 'et de l’état');
ok(/V173/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-07', amount: 5 }).error), 'règlement refusé sur un salaire déjà comptabilisé par la V173');
/* C : mois mixte — la V173 ne couvre qu'un autre employé */
setStore('exb_paie_runs', [{ id: 'R1', ym: '2026-10', status: 'payée', lines: [{ emp: 'E2' }] }]);
eq(nPaie(), 6, 'parcours C — mois mixte : E1 reste comptabilisé ici (E2 l’est par la V173) : chacun une seule fois');
/* D : brouillon V173 ne bloque rien ; run sans lignes = tout le mois couvert ; autre mois sans effet */
setStore('exb_paie_runs', [{ id: 'R1', ym: '2026-10', status: 'brouillon', lines: [{ emp: 'E1' }] }]); eq(nPaie(), 6, 'parcours D — brouillon V173 : rien de bloqué');
setStore('exb_paie_runs', [{ id: 'R1', ym: '2026-10', status: 'validée' }]); eq(nPaie(), 0, 'run V173 sans détail : tout le mois est considéré couvert (prudence)');
setStore('exb_paie_runs', [{ id: 'R1', ym: '2026-09', status: 'validée', lines: [{ emp: 'E1' }] }]); eq(nPaie(), 6, 'V173 validée pour un autre mois : sans effet sur octobre');
/* E : activation possible même si la V173 existe déjà (la règle s'applique écriture par écriture) */
ok(P.setPaie(false).ok, 'désactivation');
setStore('exb_paie_runs', [{ id: 'R1', ym: '2026-10', status: 'validée', lines: [{ emp: 'E1' }] }]);
ok(P.setPaie(true, '2026-10').ok && nPaie() === 0, 'parcours E — activation avec V173 déjà validée : acceptée, aucun double compte');
/* F : sorties de caisse portées par la V173 */
setStore('exb_cash', [{ id: 'c9', date: '2026-11-03', type: 'out', label: 'Paie octobre', amount: 100, currency: 'USD', method: 'Espèces', paie_run: 'R1' }, { id: 'c8', date: '2026-11-03', type: 'out', label: 'Salaire Marie', amount: 50, currency: 'USD', method: 'Espèces' }, { id: 'c7', date: '2026-10-20', type: 'out', label: 'Avance Paul', amount: 30, currency: 'USD', method: 'Espèces' }]);
setStore('exb_paie_runs', []);
eq(P.etat().cands.map(x => x.id).sort(), ['c7', 'c8'], 'parcours F — la sortie portée par la V173 n’est jamais proposée');
ok(/introuvable/.test(P.addReg({ bulletinId: 'B1', date: '2026-11-03', amount: 100, cashId: 'c9' }).error), 'et ne peut pas être rapprochée');
/* G : avances (nouvel écran) */
ok(/nom/i.test(P.addReg({ kind: 'avance', name: '', date: '2026-11-05', amount: 10 }).error), 'avance : nom obligatoire');
const av1 = P.addReg({ kind: 'avance', name: 'Paul', date: '2026-11-05', amount: 100, acc: '571' });
eq(T.entries().filter(e => e.piece === 'REGL-' + String(av1.rec.id).slice(-6)).map(e => [e.acc, e.d, e.c]), [['425', 100, 0], ['571', 0, 100]], 'parcours G — avance directe : débit 425 / crédit caisse');
const av2 = P.addReg({ kind: 'avance', name: 'Paul', date: '2026-10-20', amount: 30, cashId: 'c7' });
eq(T.entries().filter(e => e.piece === 'RAPPR-' + String(av2.rec.id).slice(-6)).map(e => [e.acc, e.d, e.c]), [['425', 30, 0], ['658', 0, 30]], 'avance déjà en caisse : reclassée de 658 vers 425');
ok(P.setPaie(false).ok, 'désactivation finale');
console.log('test-compta-paie-v81 : ' + n + ' contrôles OK');
