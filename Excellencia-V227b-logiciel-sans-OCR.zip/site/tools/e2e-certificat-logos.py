"""Essai navigateur (V218) : les modèles de certificat 1 à 5 prennent les logos enregistrés (Excellencia Building et RDC).
Usage : python3 site/tools/e2e-certificat-logos.py [chemin chrome]"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); os.chdir(ROOT)
CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=ROOT)); PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
res = {'ok': 0, 'ko': 0}
def ok(c, m):
    res['ok' if c else 'ko'] += 1; print(('  OK   ' if c else '  ÉCHEC ') + m)
COUNT = "m=>{const e=document.getElementById('certPaper');const d=e.querySelector(':scope > .cmi-deco, :scope > .cm5-deco');return d?[...d.querySelectorAll('img')].map(i=>i.src.slice(0,40)+'|'+i.src.length):[]}"
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1200, 'height': 900}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    pg.goto('http://127.0.0.1:%d/index.html' % PORT); pg.wait_for_timeout(3500)
    ok(pg.evaluate("!!window.EXB_CERT_LOGOS&&!!window.EXB_CERT_IMG&&!!window.EXB_CERT_M5"), 'modules des certificats chargés')
    pg.evaluate("""()=>{
      const mk=(t,c,w,h)=>{const cv=document.createElement('canvas');cv.width=w;cv.height=h;const x=cv.getContext('2d');x.fillStyle=c;x.fillRect(0,0,w,h);x.fillStyle='#fff';x.font='bold 40px Arial';x.fillText(t,10,h/2);return cv.toDataURL('image/png')};
      window.__L={exb:mk('MON LOGO','#c0392b',300,200),rdc:mk('RDC','#16a085',220,200)};
      const e=document.getElementById('certPaper');document.body.appendChild(e);e.style.cssText='position:fixed;left:0;top:0;width:1123px;height:794px;z-index:999999;background:#fff;display:block'}""")
    for m in ['m1', 'm2', 'm3', 'm4', 'm5']:
        pg.evaluate("m=>applyCertBackground(document.getElementById('certPaper'),m)", m); pg.wait_for_timeout(300)
        base = len(pg.evaluate(COUNT, m))
        pg.evaluate("()=>{exbStorage.setItem('exb_logo',__L.exb);exbStorage.setItem('rdc_logo',__L.rdc)}")
        pg.evaluate("m=>applyCertBackground(document.getElementById('certPaper'),m)", m); pg.wait_for_timeout(300)
        imgs = pg.evaluate(COUNT, m)
        has = pg.evaluate("()=>{const e=document.getElementById('certPaper');const s=[...e.querySelectorAll('img')].map(i=>i.src);return [s.includes(__L.exb),s.includes(__L.rdc)]}")
        ok(has == [True, True], m + ' : logo Excellencia et logo RDC enregistrés affichés sur le certificat')
        ok(len(imgs) >= base + 4, m + ' : zones des logos dessinés recouvertes (pièces du fond + logos)')
        pg.evaluate("()=>{exbStorage.removeItem('exb_logo');exbStorage.removeItem('rdc_logo')}")
        pg.evaluate("m=>applyCertBackground(document.getElementById('certPaper'),m)", m); pg.wait_for_timeout(300)
        ok(len(pg.evaluate(COUNT, m)) == base, m + ' : sans logo enregistré, le dessin d\'origine est conservé')
    # un logo enregistré après coup redessine le certificat affiché
    pg.evaluate("()=>{const s=document.getElementById('background');if(s)s.value='m1';applyCertBackground(document.getElementById('certPaper'),'m1');exbStorage.setItem('rdc_logo',__L.rdc);applyLogos()}"); pg.wait_for_timeout(900)
    ok(pg.evaluate("()=>[...document.getElementById('certPaper').querySelectorAll('img')].some(i=>i.src===__L.rdc)") or not pg.evaluate("!!document.getElementById('background')"), 'logo enregistré après coup : certificat redessiné')
    ok(not errs, 'aucune erreur JavaScript ' + str(errs[:2]))
    b.close()
print('\n%d OK, %d échec(s)' % (res['ok'], res['ko'])); sys.exit(1 if res['ko'] else 0)
