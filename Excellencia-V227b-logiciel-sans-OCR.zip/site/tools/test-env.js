/* Tests de référence — bureau environnement (V213). Usage : node site/tools/test-env.js */
const path=require('path'),E=require(path.join(__dirname,'..','exb-env.js'));let n=0,f=0;
const ok=(c,m)=>{n++;if(!c){f++;console.log('ÉCHEC : '+m);}};const near=(a,b,t)=>Math.abs(a-b)<=(t||1e-9);const T='2026-11-22';
const dc=E.parseDechets('2026-11-10;Gravats;;12;t;Centre X;P;BSD-1;Évacué\n10/11/2026;Gravats;;3;t\n2026-11-12;Bois;;2;m3\n2026-11-12;Bois;;2;m3;;;;Perdu\n2026-13-01;X;;1;t');
ok(dc.rows.length===3&&dc.erreurs.length===2,'déchets : date JJ/MM/AAAA acceptée, état et date invalides refusés');
const bd=E.bilanDechets(dc.rows);ok(bd.length===2&&bd[0].total===15&&bd[0].sorti===12&&bd[0].stock===3,'bilan par type et unité (aucune conversion)');
const nu=E.parseNuis('2026-11-12;Bruit;N;71;dB(A);70\n2026-11-12;Bruit;S;70;dB(A);70\n2026-11-12;Poussière;S;5;mg;');
ok(nu.rows[0].depasse&&!nu.rows[1].depasse&&nu.rows[2].seuil===null&&!nu.rows[2].depasse,'nuisance : dépassement strict, pas de seuil = non jugée');
const bc=E.bilanConso(E.parseConso('2026-11-05;Eau;18;m3\n2026-11-20;Eau;2;m3\n2026-12-01;Eau;1;m3').rows);ok(bc.length===2&&bc[0].q===20&&bc[1].mois==='2026-12','consommations par mois');
const ic=E.parseInc('A;2026-11-01;d;Élevée;;;2026-11-15;;;\nB;2026-11-01;d;Faible;;;2026-12-30;;Photo;Paul\nC;2026-11-01;d;Faible;;;2026-12-30;;Photo;\nD;2026-11-01;d;Faible;;;2026-12-30;;;Paul\nE;2026-11-01;d;Grave;;;;;;\nA;2026-11-01;d;Faible',T);
ok(ic.rows.map(r=>r.etat).join()==='En retard,Clos,Incomplet,Incomplet'&&ic.erreurs.length===2,'incidents : retard, clos (preuve ET nom), incomplet, gravité et doublon refusés');
ok(E.parseInc('A;2026-11-01;d;Faible;;;2026-11-22',T).rows[0].etat==='Ouvert','échéance du jour = encore ouvert');
const pl=E.parsePlan('PG-1;Arrosage;Chef;2026-11-01;Quotidienne;;',T);ok(pl.rows[0].etat==='En retard','plan de gestion en retard');
const x=E.nouveau();x.dechTxt='2026-11-10;Gravats;;12;t;;;;Évacué';x.nuisTxt='2026-11-12;Bruit;N;71;dB(A);70\n2026-11-13;Poussière;S;5;mg;';x.incTxt='A;2026-11-01;d;Élevée;;;2026-11-15;;;';
const v=E.verif(x,T),ids=v.map(i=>i.id);ok(['ENV-2','ENV-3','ENV-4','ENV-5','ENV-6','ENV-7','ENV-8','ENV-11'].every(i=>ids.includes(i)),'contrôles ENV-2 à ENV-11');
ok(v.filter(i=>i.id==='ENV-6')[0].niveau==='bloquant'&&E.verif(E.nouveau(),T)[0].id==='ENV-1','dépassement = à traiter ; dossier vide signalé');
console.log(n-f+' OK, '+f+' échec(s)');process.exit(f?1:0);
