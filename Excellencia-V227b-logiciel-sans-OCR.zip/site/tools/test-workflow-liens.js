/* Tests des liens Workflow ↔ Devis / Achats / Congés / Certificats (node tools/test-workflow-liens.js) — scénarios calculés à la main. */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const store = {}, notes = [];
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.EXBCore = { audit: { log() {} }, bus: { emit() {}, on() {} } };
global.notify = (m, t) => notes.push(t + ': ' + m);
global.document = { readyState: 'loading', addEventListener() {}, getElementById: () => null, querySelector: () => null, createElement: () => ({}), body: { appendChild() {} } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
require('../exb-workflow.js'); require('../exb-workflow-liens.js');
const W = window.EXBWF, L = window.EXBWFL, E = L.engine;
ok(W && L && E, 'modules chargés');
const set = (k, v) => { store[k] = JSON.stringify(v); };
const get = (k, d) => (k in store ? JSON.parse(store[k]) : d);

/* ---- moteur pur ---- */
eq(E.fp(['A', ' b ']), E.fp(['a', 'B']), 'empreinte insensible à la casse / espaces');
ok(E.fp(['a', 'b']) !== E.fp(['a', 'c']), 'empreinte sensible au contenu');
ok(!E.needs({}, 'devis', 5000, 'USD'), 'sans réglage : aucun lien');
ok(!E.needs({ devis: { on: false } }, 'devis', 5000, 'USD'), 'lien désactivé : aucun contrôle');
ok(E.needs({ devis: { on: true, seuil: 0 } }, 'devis', 1, 'USD'), 'seuil 0 : toujours');
ok(!E.needs({ devis: { on: true, seuil: 1000, devise: 'USD' } }, 'devis', 999.99, 'USD'), 'sous le seuil : libre');
ok(E.needs({ devis: { on: true, seuil: 1000, devise: 'USD' } }, 'devis', 1000, 'USD'), 'au seuil : contrôlé');
ok(E.needs({ devis: { on: true, seuil: 1000, devise: 'USD' } }, 'devis', 10, 'CDF'), 'devise différente : contrôlé (prudence)');
ok(E.needs({ devis: { on: true, seuil: 1000, devise: 'USD' } }, 'devis', null, 'USD'), 'montant inconnu : contrôlé (prudence)');
ok(E.needs({ conge: { on: true, seuil: 1000 } }, 'conge', 0, ''), 'congé : le seuil ne s\'applique pas');
const q1 = { no: 'DEV-1', client: 'ACME', project: 'Villa', currency: 'USD', imp: 0, lines: [{ designation: 'Ciment', qty: 10, pu: 12 }, { designation: 'Sable', qty: 2, pu: 30 }] };
eq(E.quoteInfo(q1).montant, 180, 'montant du devis = somme qté × PU');
ok(E.quoteInfo(Object.assign({}, q1, { lines: [{ designation: 'Ciment', qty: 11, pu: 12 }, q1.lines[1]] })).fp !== E.quoteInfo(q1).fp, 'modifier une ligne change l\'empreinte');
eq(E.quoteInfo({ no: 'X' }).montant, null, 'devis sans lignes : montant inconnu');
eq(E.quoteInfo(Object.assign({}, q1, { imp: 10 })).montant, 198, 'divers & imprévus 10 % inclus : 180 × 1,10 = 198');
const PO = { id: 'BC1', no: 'BC-001', supplier_id: 'S1', lines: [{ d: 'Ciment', u: 'sac', q: 100, pu: 12, rec: 0 }, { d: 'Sable', u: 'm3', q: 10, pu: 30, rec: 0 }] };
eq(E.poInfo(PO, [{ id: 'S1', name: 'Quincaillerie X' }]).montant, 1500, 'bon de commande : somme qté × PU');
eq(E.poInfo(Object.assign({}, PO, { lines: PO.lines.map(l => Object.assign({}, l, { rec: 50 })) })).fp, E.poInfo(PO).fp, 'la réception ne change pas l\'empreinte');
ok(E.poInfo(Object.assign({}, PO, { lines: [PO.lines[0], { d: 'Sable', u: 'm3', q: 11, pu: 30, rec: 0 }] })).fp !== E.poInfo(PO).fp, 'modifier une quantité commandée change l\'empreinte');
const D = (st, f, id) => ({ id: 'w' + Math.random(), status: st, cree: '2026-11-16T0' + (D.i++) + ':00', ref: { module: 'devis', id: id || 'DEV-1', fp: f || 'F1' } }); D.i = 0;
eq(E.state([], 'devis', 'DEV-1', 'F1').s, 'none', 'aucun dossier');
eq(E.state([D('valide')], 'devis', 'DEV-1', 'F1').s, 'valide', 'validé');
eq(E.state([D('valide')], 'devis', 'DEV-1', 'F2').s, 'modifie', 'validé puis modifié');
eq(E.state([D('refuse')], 'devis', 'DEV-1', 'F1').s, 'refuse', 'refusé');
eq(E.state([D('refuse')], 'devis', 'DEV-1', 'F2').s, 'none', 'refusé puis corrigé : nouvelle soumission possible');
eq(E.state([D('valide'), D('annule')], 'devis', 'DEV-1', 'F1').s, 'valide', 'un dossier annulé postérieur est ignoré');
eq(E.state([D('valide', 'F1'), D('en_cours', 'F2')], 'devis', 'DEV-1', 'F1').s, 'valide', 'retour à la version validée malgré un dossier récent en cours');
eq(E.state([D('valide', 'F1'), D('en_cours', 'F2')], 'devis', 'DEV-1', 'F2').s, 'en_cours', 'la version modifiée suit son propre dossier');
eq(E.state([D('valide', 'F1', 'DEV-9')], 'devis', 'DEV-1', 'F1').s, 'none', 'dossier d\'un autre devis ignoré');
const pa = E.pendingApply([{ status: 'valide', ref: { module: 'conge', id: 'C1' } }, { status: 'refuse', ref: { module: 'conge', id: 'C2' } }, { status: 'valide', ref: { module: 'conge', id: 'C3' } }, { status: 'refuse', ref: { module: 'achat', id: 'O1' } }, { status: 'en_cours', ref: { module: 'achat', id: 'O2' } }],
  [{ id: 'C1', status: 'demandé' }, { id: 'C2', status: 'demandé' }, { id: 'C3', status: 'approuvé' }], [{ id: 'O1', status: 'pending_approval' }, { id: 'O2', status: 'pending_approval' }]);
eq(pa.conge, [{ id: 'C1', to: 'approuvé' }, { id: 'C2', to: 'refusé' }], 'congés à appliquer (déjà traité ignoré)');
eq(pa.achat, [{ id: 'O1', to: 'rejected' }], 'commandes à appliquer (dossier en cours ignoré)');

/* ---- circuits : un circuit à une étape par type ---- */
const circ = t => ({ id: 'c_' + t, nom: 'Circuit ' + t, type: t, actif: true, steps: [{ nom: 'Direction', mode: 'sequentiel', approvers: [{ role: 'Directeur général' }] }] });
set('exb_wf_circuits', ['devis', 'achat', 'conge', 'certificat'].map(circ));
const DG = { role: 'Directeur général' };
const approveLast = () => { const l = W.list(); const x = l[l.length - 1]; const r = W.decide(x.id, 'approuver', '', DG); ok(r.ok, 'validation par la direction : ' + (r.error || '')); return x; };

(async () => {
  /* ---- DEVIS ---- */
  let pdf = 0, prt = 0, form = JSON.parse(JSON.stringify(q1));
  global.exbQuoteFromForm = () => JSON.parse(JSON.stringify(form));
  global.exportExbQuotePdf = function () { pdf++; return 'pdf'; }; global.printExbQuote = function () { prt++; };
  global.exportExbQuotePdfSimple = function () { pdf++; }; global.exbQuotes = [Object.assign({ id: 'q-id-1' }, q1)];
  global.exbQuotePdfById = function () { pdf++; }; global.exbConfirm = async () => true;
  L.install();
  exportExbQuotePdf(); eq(pdf, 1, 'lien désactivé : export normal (comportement d\'origine)'); eq(W.list().length, 0, 'aucun dossier créé');
  set('exb_wf_liens', { devis: { on: true, seuil: 1000, devise: 'USD' } });
  exportExbQuotePdf(); eq(pdf, 2, 'devis de 180 $ sous le seuil de 1 000 $ : libre');
  set('exb_wf_liens', { devis: { on: true, seuil: 100, devise: 'USD' } });
  ok(exportExbQuotePdf() === undefined, 'devis de 180 $ ≥ 100 $ : export bloqué'); eq(pdf, 2, 'PDF non généré');
  await sleep(10); eq(W.list().length, 1, 'proposition acceptée : dossier créé'); eq(W.list()[0].ref.module, 'devis', 'lié au devis');
  printExbQuote(); eq(prt, 0, 'impression aussi bloquée (dossier en cours)'); ok(/en cours/.test(notes[notes.length - 1]), 'message « validation en cours »');
  eq(W.list().length, 1, 'pas de second dossier pour le même devis');
  approveLast(); exportExbQuotePdf(); eq(pdf, 3, 'devis validé : export autorisé'); printExbQuote(); eq(prt, 1, 'impression autorisée');
  exbQuotePdfById('q-id-1'); eq(pdf, 4, 'export par identifiant : même devis (même n° et mêmes lignes) déjà validé : autorisé');
  form.lines[0].qty = 11; exportExbQuotePdf(); eq(pdf, 4, 'devis modifié après validation : export bloqué'); await sleep(10);
  eq(W.list().length, 2, 'nouvelle validation proposée après modification');
  form.lines[0].qty = 10; exportExbQuotePdf(); eq(pdf, 5, 'retour à l\'état validé (même empreinte) : autorisé');
  global.exbConfirm = async () => false; form.no = 'DEV-2'; exportExbQuotePdf(); await sleep(10); eq(W.list().length, 2, 'proposition refusée : aucun dossier');
  global.exbConfirm = async () => true;

  /* ---- CERTIFICATS ---- */
  let cp = 0, cd = { cert_no: 'EXB-FP-001', holder: 'Jean Mbala', training: 'AutoCAD', start_date: '2026-10-01', end_date: '2026-10-30', mention: 'Bien' };
  global.certData = () => Object.assign({}, cd); global.exportCertPdf = async function () { cp++; return 'ok'; };
  L.install();
  await exportCertPdf(); eq(cp, 1, 'certificats : lien désactivé, export normal');
  set('exb_wf_liens', { devis: { on: true, seuil: 100, devise: 'USD' }, certificat: { on: true } });
  await exportCertPdf(); eq(cp, 1, 'certificat non validé : export bloqué'); await sleep(10);
  const cw = W.list().filter(x => x.type === 'certificat'); eq(cw.length, 1, 'dossier « certificat » créé');
  approveLast(); await exportCertPdf(); eq(cp, 2, 'certificat validé : export autorisé');
  cd.holder = 'Jean M. Mbala'; await exportCertPdf(); eq(cp, 2, 'titulaire modifié après validation : bloqué'); cd.holder = 'Jean Mbala';
  await sleep(10);

  /* ---- CONGÉS ---- */
  const cgCalls = [];
  global.EXBPAY = {
    addCg() { const a = get('exb_payroll', []); a.push({ id: 'CGE' + (a.length + 1), type: 'conge', emp: 'Marie', kind: 'Congé annuel', from: '2026-12-01', to: '2026-12-05', status: 'demandé' }); set('exb_payroll', a); },
    cg(id, s) { cgCalls.push(id + ':' + s); const a = get('exb_payroll', []); a.forEach(x => { if (x.id === id) x.status = s; }); set('exb_payroll', a); }
  };
  L.install();
  EXBPAY.addCg(); eq(W.list().filter(x => x.type === 'conge').length, 0, 'lien congés désactivé : pas de dossier');
  EXBPAY.cg('CGE1', 'refusé'); eq(cgCalls, ['CGE1:refusé'], 'lien désactivé : approbation directe d\'origine');
  set('exb_wf_liens', { conge: { on: true } });
  EXBPAY.addCg(); const cgw = W.list().filter(x => x.type === 'conge'); eq(cgw.length, 1, 'nouvelle demande : dossier créé automatiquement');
  eq(cgw[0].ref.id, 'CGE2', 'lié à la demande'); eq(cgw[0].montant, 0, 'sans montant');
  EXBPAY.cg('CGE2', 'approuvé'); eq(cgCalls.length, 1, 'approbation directe bloquée (circuit en cours)');
  EXBPAY.cg('CGE2', 'refusé'); eq(cgCalls.length, 1, 'refus direct bloqué : passer par le Workflow (motif obligatoire)');
  approveLast(); L.apply(); eq(cgCalls, ['CGE1:refusé', 'CGE2:approuvé'], 'validation du circuit → demande approuvée');
  L.apply(); eq(cgCalls.length, 2, 'application idempotente');
  EXBPAY.addCg(); const x3 = W.list().filter(x => x.type === 'conge')[1]; W.decide(x3.id, 'refuser', 'Période de forte activité', DG); L.apply();
  eq(cgCalls[2], 'CGE3:refusé', 'refus du circuit → demande refusée');
  const old = get('exb_payroll', []); old.push({ id: 'CGE9', type: 'conge', emp: 'Paul', kind: 'Congé annuel', from: '2026-11-02', to: '2026-11-03', status: 'demandé' }); set('exb_payroll', old);
  EXBPAY.cg('CGE9', 'refusé'); eq(cgCalls[3], 'CGE9:refusé', 'demande antérieure à l\'activation (sans dossier) : refus direct toujours possible');

  /* ---- ACHATS ---- */
  const KO = 'exb_v92_purchase_orders', rec = [];
  global.EXB_ERP = { keys: { orders: KO }, refresh() { rec.push('refresh'); },
    createPurchaseOrder(data) { const a = get(KO, []); const r = Object.assign({ id: 'ERP-' + (a.length + 1), status: 'pending_approval' }, data); a.unshift(r); set(KO, a); return r; },
    receiveOrder(data) { rec.push('recu:' + data.order_id); return { id: 'R' }; } };
  L.install();
  EXB_ERP.createPurchaseOrder({ supplier: 'Quincaillerie X', total: 5000, currency: 'USD' }); eq(W.list().filter(x => x.type === 'achat').length, 0, 'achats : lien désactivé');
  set('exb_wf_liens', { achat: { on: true, seuil: 1000, devise: 'USD' }, conge: { on: true } });
  const small = EXB_ERP.createPurchaseOrder({ supplier: 'Y', total: 200, currency: 'USD' }); eq(W.list().filter(x => x.type === 'achat').length, 0, 'commande de 200 $ sous le seuil : pas de dossier');
  EXB_ERP.receiveOrder({ order_id: small.id }); ok(rec.indexOf('recu:' + small.id) >= 0, 'réception d\'une commande sans dossier : autorisée');
  const big = EXB_ERP.createPurchaseOrder({ supplier: 'Z', total: 5000, currency: 'USD' }); const aw = W.list().filter(x => x.type === 'achat'); eq(aw.length, 1, 'commande de 5 000 $ : dossier créé'); eq(aw[0].montant, 5000, 'montant repris');
  assert.throws(() => EXB_ERP.receiveOrder({ order_id: big.id }), /Workflow/); n++;
  approveLast(); L.apply(); eq(get(KO, []).filter(o => o.id === big.id)[0].status, 'approved', 'validation → commande approuvée'); ok(rec.indexOf('refresh') >= 0, 'écran Achats rafraîchi');
  EXB_ERP.receiveOrder({ order_id: big.id }); ok(rec.indexOf('recu:' + big.id) >= 0, 'commande validée : réception autorisée');
  const big2 = EXB_ERP.createPurchaseOrder({ supplier: 'W', total: 9000, currency: 'USD' }); const a2 = W.list().filter(x => x.type === 'achat')[1];
  W.decide(a2.id, 'refuser', 'Prix trop élevé', DG); L.apply(); eq(get(KO, []).filter(o => o.id === big2.id)[0].status, 'rejected', 'refus → commande rejetée');

  /* ---- ACHATS : bons de commande de chantier (Terrain & achats) ---- */
  const POKEY = 'exb_purchase_orders'; let paid = 0, nextPo = 0; set(POKEY, []); set('exb_suppliers', [{ id: 'S1', name: 'Quincaillerie X' }]);
  global.EXBTR = {
    savePo(lines) { const a = get(POKEY, []); a.push({ id: 'BC' + (++nextPo), no: 'BC-00' + nextPo, supplier_id: 'S1', lines: lines || [{ d: 'Ciment', u: 'sac', q: 100, pu: 12, rec: 0 }] }); set(POKEY, a); },
    async payPo(id) { paid++; }
  };
  L.install();
  set('exb_wf_liens', { achat: { on: true, seuil: 1000, devise: 'USD' } });
  EXBTR.savePo([{ d: 'Clous', u: 'kg', q: 10, pu: 5, rec: 0 }]); eq(W.list().filter(x => x.ref && x.ref.id === 'BC1').length, 0, 'BC de 50 $ sous le seuil : pas de dossier');
  await EXBTR.payPo('BC1'); eq(paid, 1, 'BC sous le seuil : paiement libre');
  EXBTR.savePo(); const bcw = W.list().filter(x => x.ref && x.ref.id === 'BC2'); eq(bcw.length, 1, 'BC de 1 200 $ : dossier créé à l\'enregistrement'); eq(bcw[0].montant, 1200, 'montant du BC repris');
  await EXBTR.payPo('BC2'); eq(paid, 1, 'paiement bloqué tant que le BC n\'est pas validé');
  approveLast(); await EXBTR.payPo('BC2'); eq(paid, 2, 'BC validé : paiement autorisé');
  const bcs = get(POKEY, []); bcs[1].lines[0].q = 150; set(POKEY, bcs); await EXBTR.payPo('BC2'); eq(paid, 2, 'quantité commandée modifiée après validation : paiement bloqué');
  bcs[1].lines[0].q = 100; bcs[1].lines[0].rec = 40; set(POKEY, bcs); await EXBTR.payPo('BC2'); eq(paid, 3, 'réception partielle seule : validation conservée');
  /* ---- sécurité des réglages ---- */
  const wrapped = ['exportExbQuotePdf', 'printExbQuote', 'exportCertPdf'].every(f => global[f].__wfl); ok(wrapped, 'enveloppes posées une seule fois');
  const before = global.exportExbQuotePdf; L.install(); ok(before === global.exportExbQuotePdf, 'install() idempotent (pas de double enveloppe)');
  console.log('Liens Workflow : ' + n + ' contrôles OK');
})().catch(e => { console.error(e); process.exit(1); });
