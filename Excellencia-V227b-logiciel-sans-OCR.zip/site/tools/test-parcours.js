#!/usr/bin/env node
/* Test du module PARCOURS (V122f) : étapes, sauts, alertes, registre, lecture seule. Usage : node tools/test-parcours.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');let fails=0,passes=0;
const ok=(c,m,d)=>{if(c){passes++;console.log('  OK   '+m)}else{fails++;console.log('  FAIL '+m+(d?' — '+d:''))}};
const J=o=>JSON.stringify(o);
const seed={
 exb_clients:J([{id:'C1',full_name:'Marie Kabongo'}]),
 exb_projects:J([{id:'P1',name:'Villa Gombe',client_id:'C1'},{id:'P2',name:'Tour Lemba'},{id:'P3',name:'Vide'}]),
 exb_quotes:J([{id:'Q1',project_id:'P1',status:'approuvé'}]),
 exb_invoices:J([{id:'F1',project_id:'P1',lines:[{q:1,pu:100}],tva:0,payments:[{id:'A',date:'2026-10-01',amount:50}]},{id:'F2',project_id:'P2',lines:[{q:1,pu:10}],tva:0}]),
 exb_calc_notes:J([{id:'N1',project_id:'P1'}]),
 exb_pieces:J([{id:'D1',type:'contrat',project:'P1',status:'signé',title:'Contrat'},{id:'D2',type:'pv',project:'P1',status:'émis',title:'PV de réception provisoire'},{id:'D3',type:'pv',project:'P2',status:'émis',title:'PV'},{id:'D4',type:'rapport',project:'PX',title:'Orphelin'},{id:'M',type:'rapport',modele:true,title:'Modèle'}]),
 exb_site_journal:J([{id:'J1',project_id:'P1'},{id:'J2',project_id:'P2'}]),
 exb_participants:J([{id:'x1',participant_id:'PA1',name:'Jean',training:'AutoCAD'},{id:'x2',participant_id:'PA2',name:'Lea'}]),
 exb_payments:J([{id:'PY1',participant_id:'PA1'}]),
 exb_attendance:J([{participant_id:'PA1',date:'2026-10-02'}]),
 exb_certificates:J([{id:'CE1',participant_id:'PA1'}])
};
const mem=Object.assign({},seed);let before='';
const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
const w={localStorage:ls,exbStorage:ls,document:{readyState:'complete',getElementById:()=>null,addEventListener(){},createElement:()=>({}),head:{appendChild(){}}},save:(k,v)=>ls.setItem(k,JSON.stringify(v)),dispatchEvent(){},addEventListener(){},confirm:()=>true,setInterval:()=>0,setTimeout:f=>{try{f()}catch(e){}return 0}};
w.window=w;w.globalThis=w;const ctx=vm.createContext(w);vm.runInContext('Event=function(){}',ctx);
['modules/exb-module-registry.js','exb-liaison.js','exb-liaison-edu.js','exb-liaison-3.js','exb-liaison-4.js','exb-liaison-ops.js','exb-parcours.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f}));
const P=w.EXBPARCOURS;before=J(mem); /* la Liaison existante pose ses identifiants au démarrage : on mesure à partir d'ici */
console.log('# Registre');
ok(P&&P.registryIssues().length===0,'aucune référence cassée dans le registre',P&&J(P.registryIssues()));
ok(w.EXB_MODULES.some(m=>m.id==='docsChantier'),'modules récents déclarés');
console.log('# Parcours chantier');
const a=P.chantier('P1'),st=Object.fromEntries(a.steps.map(s=>[s.id,s]));
ok(st.client.done&&st.devis.done&&st.etude.done&&st.contrat.done&&st.chantier.done&&st.docs.done&&st.facture.done,'P1 : étapes détectées');
ok(st.paiement.done,'P1 : paiement détecté');
ok(st.reception.done&&st.docs.detail.indexOf('2 document')>=0,'P1 : réception et documents (modèles exclus)',st.docs.detail);
ok(!st.plans.done&&!st.achats.done&&st.plans.etat==='a-faire','étapes facultatives non faites = à faire, pas sautées');
ok(a.next===null||a.next.opt,'P1 : plus d’étape obligatoire manquante');
const b=P.chantier('P2');
ok(b.steps.find(s=>s.id==='client').etat==='saut'&&b.steps.find(s=>s.id==='devis').etat==='saut','P2 : client et devis sautés');
ok(b.next&&b.next.id==='client','P2 : prochaine étape = client');
ok(P.chantier('P3').pct===0&&P.chantier('P3').sauts.length===0,'P3 : vide, rien de sauté');
ok(P.chantier('ZZ')===null,'chantier inconnu → null');
console.log('# Parcours formation');
const f=P.formation('PA1'),fs_=Object.fromEntries(f.steps.map(s=>[s.id,s]));
ok(fs_.inscription.done&&fs_.formation.done&&fs_.paiement.done&&fs_.presence.done&&fs_.certificat.done,'PA1 : étapes détectées');
ok(fs_.evaluation.etat==='saut','PA1 : évaluation sautée avant certificat');
ok(P.formation('PA2').next.id==='formation','PA2 : prochaine étape = formation');
console.log('# Alertes');
const an=P.anomalies().join('\n');
ok(/« Tour Lemba » : facturé sans devis ni contrat/.test(an),'facturé sans devis ni contrat');
ok(/activité de chantier sans devis, contrat ni facture/.test(an)===false,'pas de fausse alerte (P2 a une facture)');
ok(/document\(s\) de chantier émis ou signé\(s\) mais aucun client/.test(an),'documents émis sans client');
ok(/D4|Orphelin|le chantier relié n’existe plus/.test(an),'document orphelin signalé');
ok(w.EXBLIEN.anomalies().some(x=>/Parcours —/.test(x)),'alertes visibles dans les points à vérifier de la Liaison');
console.log('# Lecture seule');
ok(J(mem)===before,'aucune donnée modifiée par le module');
console.log('# Fiches non rattachées (action explicite)');
mem.exb_quotes=J([{id:'Q1',project_id:'P1',status:'approuvé'},{id:'Q9',no:'DEV-9',client_id:'C1'},{id:'Q8',no:'DEV-8',client_id:'ZZ'}]);
w.__live&&0;
const O=P.orphans('P1');
ok(O.some(o=>o.id==='Q9')&&!O.some(o=>o.id==='Q8'),'proposées : fiches sans chantier du même client ; autre client exclu',J(O.map(o=>o.id)));
ok(!O.some(o=>o.id==='M'),'les modèles de documents ne sont jamais proposés');
ok(P.attach('exb_quotes','Q9','P1')===true,'rattachement confirmé → réussi');
ok(JSON.parse(mem.exb_quotes).find(x=>x.id==='Q9').project_id==='P1','le devis porte le chantier');
ok(P.attach('exb_quotes','Q9','P2')===false,'une fiche déjà rattachée n’est jamais déplacée');
w.confirm=()=>false;
ok(P.attach('exb_quotes','Q8','P1')===false&&!JSON.parse(mem.exb_quotes).find(x=>x.id==='Q8').project_id,'refus de confirmation → rien n’est écrit');
console.log('# Plan : étape ouvrable avec famille de documents');
const nx=P.chantier('P2').steps.find(x=>x.id==='contrat');
ok(nx.fam==='contrat'&&P.chantier('P1').steps.find(x=>x.id==='reception').fam==='pv','étapes contrat / réception ouvrent la bonne famille');
console.log('\nRésultat : '+passes+' réussis, '+fails+' échec(s).');process.exit(fails?1:0);
