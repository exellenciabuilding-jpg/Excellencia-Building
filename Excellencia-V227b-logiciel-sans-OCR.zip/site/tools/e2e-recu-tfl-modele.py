#!/usr/bin/env python3
"""V193 : reçu de paiement des frais TFL au format « carte paysage » (modèle INBTP) — espace étudiant.
Usage, depuis le dossier du site : python3 tools/e2e-recu-tfl-modele.py"""
import http.server, threading, socketserver, os, functools, subprocess, tempfile
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1123,'height':794}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(f'http://127.0.0.1:{PORT}/tfl-portail.html'); pg.wait_for_timeout(1500)
    OBJ="""{no:'REC-TFL-2026-00001',dateEmission:'17/11/2026 08:16',nom:'MUKENDI <img src=x onerror=alert(1)> JEAN',matricule:'378-734-477',faculte:'Bâtiment et Travaux Publics',filiere:'Construction Industrielle',promotion:'L3 BTP CIB 026',datePaiement:'14/11/2026',mode:'Banque (dépôt ou virement)',reference:'u3scbob1lmn4hlz7k',annee:'2025-2026',motif:'Frais de TFL',montant:'200 USD',operateur:'Administration Excellencia Building',code:'a1b2c3d4e5',qr:EXBQR.svg('https://x.example/verification.html?c=r~1',{px:132,quiet:2}),logo:'%s',photo:'%s',visa:'%s'}""" % (PNG,PNG,PNG)
    h=pg.evaluate("EXBRecuTFL.html("+OBJ+")")
    ok('landscape' in h,'gabarit chargé')
    for k in ['Étudiant','Matricule','Faculté','Département','Promotion','Payé le','Banque','No. Transaction','Année Académique','Opérateur','Motif','Montant']:
        if k not in h: ok(False,'champ manquant : '+k); break
    else: ok(True,'tous les champs du modèle sont présents')
    ok('378-734-477' in h and 'u3scbob1lmn4hlz7k' in h and '14/11/2026' in h and '200 USD' in h.replace('\u00a0',' ') and 'Frais de TFL' in h,'matricule, transaction, date de paiement, montant et motif reprennent les données du paiement')
    ok('<img src=x' not in h and '&lt;img src=x' in h,'texte saisi échappé (aucune injection)')
    ok(h.count('<div class="cd"><span>')==1 and h.count('<span>')>=10 and '<span>a</span><span>1</span>' in h,'code de vérification en cases sous le QR')
    ok('<svg' in h.split('class="qr"')[1][:80] if 'class="qr"' in h else False,'QR de vérification présent')
    ok(h.count(PNG)>=3,'logo, photo de l’étudiant et cachet + signature posés')
    ok('@page{size:A4 landscape' in h,'page A4 paysage')
    pg.set_content(h); pg.wait_for_timeout(400)
    ok(pg.evaluate("document.querySelectorAll('.bx th').length")==8,'8 lignes d’identité (sexe absent : non renseigné)')
    ok(pg.evaluate("(function(){var e=document.querySelector('.no');return e.scrollWidth<=e.clientWidth+1&&e.getBoundingClientRect().height<30})()"),'le numéro de reçu tient sur une ligne')
    f=tempfile.mktemp(suffix='.pdf'); pg.pdf(path=f,prefer_css_page_size=True,print_background=True)
    info=subprocess.run(['pdfinfo',f],capture_output=True,text=True).stdout
    ok('Pages:           1' in info and '841' in info,'PDF : une seule page A4 paysage')
    # sans photo ni visa : pas d'image cassée
    pg.goto(f'http://127.0.0.1:{PORT}/tfl-portail.html'); pg.wait_for_timeout(800)
    h2=pg.evaluate("EXBRecuTFL.html({no:'R1',nom:'A',montant:'1 USD',qr:'',logo:'',photo:'',visa:''})")
    ok('<img' not in h2 and 'class="ph0"' in h2,'sans photo ni cachet : cadre vide, aucune image cassée')
    h3=pg.evaluate("EXBRecuTFL.html({no:'R1',nom:'A',montant:'1 USD',qr:'<img src=x onerror=1>',photo:'javascript:alert(1)',visa:'data:text/html;base64,AAAA'})")
    ok('onerror' not in h3 and 'javascript:' not in h3 and 'text/html' not in h3,'QR non SVG, photo et visa non image : refusés')
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2]))
    b.close()
print('\n%d échec(s)'%fails); raise SystemExit(1 if fails else 0)
