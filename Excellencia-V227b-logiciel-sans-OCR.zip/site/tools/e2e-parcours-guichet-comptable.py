"""V205r : parcours du comptable au guichet (compte non administrateur avec son profil : signature + sceau) : recherche, reçu apprenant, reçu client PDF.
Usage : python3 tools/e2e-parcours-guichet-comptable.py"""
import sys, os, base64, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
import tempfile
OUT=tempfile.mkdtemp(prefix='parcours-guichet-')
SEED={
 'exb_participants':[{'participant_id':'P-001','name':'KABEYA Marie','phone':'0812345678','email':'','training':'Robot Structural Analysis','matricule':'TFL-0001','approval_status':'APPROUVE'}],
 'exb_clients':[{'name':'SOCIETE LUKUNI','phone':'0998887766','email':'lukuni@mail.cd','matricule':'CLI-0007'}],
 'exb_projects':[{'id':'PRJ1','name':'Villa R+1 Gombe','client':'SOCIETE LUKUNI'}],
 'exb_finance':[{'id':'FIN-1','type':'devis','no':'DEV-2026-001','client':'SOCIETE LUKUNI','project':'PRJ1','ttc':5000,'cur':'USD','title':'Villa'}],
}
fails=0
def ok(c,m):
    global fails; print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto('file://'+ROOT+'/index.html'); pg.wait_for_timeout(6000)
    pg.add_style_tag(content='#app{display:block !important} #loginScreen,#exbLicLock{display:none !important}')
    pg.evaluate("S=>{for(const k in S){if(k==='exb_participants'){S[k].forEach(x=>participants.push(x));save(k,participants)}else EXBS.set(k,S[k])}}",SEED)
    # --- compte : COMPTABLE (non administrateur) avec son profil : nom + signature dessinée + sceau automatique
    pg.evaluate("window.EXBDB.info=()=>({org:'O',on:true,role:'membre',fonction:'comptable',label:'Comptable'});window.EXB_ACCT={id:'comptable@excellencia.cd'}")
    sig=pg.evaluate("""()=>{const c=document.createElement('canvas');c.width=420;c.height=160;const x=c.getContext('2d');x.strokeStyle='#0b2a8a';x.lineWidth=5;x.lineCap='round';x.beginPath();x.moveTo(10,110);x.bezierCurveTo(60,10,90,170,140,70);x.bezierCurveTo(170,20,200,150,260,60);x.bezierCurveTo(300,10,330,120,410,50);x.stroke();return c.toDataURL('image/png')}""")
    pg.evaluate("async s=>{await EXBOperateur.save({nom:'Jean MUTOMBO',fonction:'Comptable',matricule:'EXB-C-012',tel:'0990000012',lieu:'Gombe — Siège',sig:s,stamp:'auto',etab:true})}",sig)
    pg.wait_for_timeout(500)
    ok(pg.evaluate("!!EXBOperateur.get().visa"),'profil opérateur du comptable enregistré (signature + sceau)')
    # --- 1. le comptable cherche avec la barre du haut
    pg.evaluate("q=>{const s=document.getElementById('exbGlobalSearch');s.value=q;runExbGlobalSearch(q)}",'lukuni'); pg.wait_for_timeout(900)
    t=pg.inner_text('#exbGlobalResults').lower()
    ok('devis (finances)' in t and 'société lukuni'.upper().lower() in t or 'lukuni' in t,'barre du haut : « lukuni » → client / devis trouvés')
    pg.evaluate("document.getElementById('exbGlobalResults').style.display='none'")
    # --- 2. guichet
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(1000)
    ok(pg.evaluate("!!document.getElementById('exbGuiCard')"),'guichet présent')
    pg.screenshot(path=OUT+'/1-guichet.png')
    # === APPRENANT ===
    pg.fill('#gSearch','kabeya'); pg.wait_for_timeout(400)
    ok('KABEYA Marie' in pg.inner_text('#gHits'),'recherche guichet : apprenant « kabeya » trouvé')
    pg.click('#gHits [data-ghit="0"]'); pg.wait_for_timeout(400)
    v=pg.evaluate("({t:gType.value,n:gNom.value,m:gMat.value,f:gProj.value})")
    ok(v['t']=='tfl' and v['n']=='KABEYA Marie' and v['m']=='TFL-0001','coordonnées chargées : '+str(v))
    pg.select_option('#gQuoi','insc_moitie'); pg.wait_for_timeout(300)
    pg.fill('#gGuich','Jean MUTOMBO'); pg.screenshot(path=OUT+'/2-apprenant-avant.png')
    pg.click('#gGo'); pg.wait_for_timeout(3000)
    rc=pg.evaluate("EXBS.get('exb_receipts')")
    ok(len(rc)==1 and rc[0]['participant']=='KABEYA Marie','reçu apprenant enregistré : '+(rc[0]['receipt_no'] if rc else '?'))
    pg.screenshot(path=OUT+'/3-apprenant-apres.png')
    print('   bandeau :',pg.inner_text('#gBanner')[:140].replace('\n',' '))
    # PDF du reçu apprenant : même chemin que le bouton « Exporter PDF » du reçu (visa = signature du comptable)
    visa=pg.evaluate("EXBSign.anyVisa('png')"); mine=pg.evaluate("EXBOperateur.get().visa")
    ok(visa==mine and bool(mine),'sur le reçu apprenant, la signature posée est celle du COMPTABLE (pas celle du Directeur)')
    html=pg.evaluate("""async()=>{const rec=EXBS.get('exb_receipts')[0];const o=await recuModeleLogiciel(rec);return {has:!!o,visa:o&&o.visa&&o.visa.length,html:o?EXBRecuTFL.html(o):''}}""")
    ok(html['has'] and html['visa']>100,'reçu apprenant (modèle TFL) construit avec la signature du comptable')
    open(OUT+'/recu-apprenant.html','w',encoding='utf-8').write(html['html'])
    # === CLIENT ===
    pg.click('#gReset'); pg.wait_for_timeout(300)
    pg.fill('#gSearch','lukuni'); pg.wait_for_timeout(400)
    pg.click('#gHits [data-ghit]:has-text("Devis")'); pg.wait_for_timeout(400)
    v=pg.evaluate("({t:gType.value,n:gNom.value,tot:gTotal.value,pj:gProj.value})")
    ok(v['t']=='devis' and v['tot']=='5000','devis choisi : '+str(v))
    pg.fill('#gMontant','2000'); pg.select_option('#gMode','mobile_money'); pg.fill('#gGuich','Jean MUTOMBO'); pg.wait_for_timeout(300)
    pg.click('#gGo'); pg.wait_for_timeout(3500)
    ok('REC-GUI-' in pg.inner_text('#gBanner'),'reçu client généré : '+pg.inner_text('#gBanner')[:100].replace('\n',' '))
    pg.screenshot(path=OUT+'/4-client-apres.png')
    href=pg.evaluate("(()=>{const a=document.querySelector('#gResult a[download]');return a?a.getAttribute('href'):''})()")
    name=pg.evaluate("(()=>{const a=document.querySelector('#gResult a[download]');return a?a.getAttribute('download'):''})()")
    ok(bool(href),'lien de téléchargement PDF du reçu client : '+name)
    if href:
        b64=pg.evaluate("async h=>{const r=await fetch(h);const b=new Uint8Array(await r.arrayBuffer());let s='';for(const x of b)s+=String.fromCharCode(x);return btoa(s)}",href)
        open(OUT+'/'+(name or 'recu-client.pdf'),'wb').write(base64.b64decode(b64))
        d=base64.b64decode(b64); ok(d[:5]==b'%PDF-' and len(d)>3000,'PDF client valide (%d octets)'%len(d))
    reg=pg.evaluate("EXBS.get('exb_guichet')")
    ok(len(reg)==2,'registre partagé : 2 encaissements (apprenant + client)')
    cs=pg.text_content('#gCaisse').replace(' ',' ').replace(' ',' ')
    print('   caisse du jour :',cs[:120].replace('\n',' '))
    ok(not errs,'aucune erreur JS '+str(errs[:2]))
    b.close()
print('Captures et PDF :',OUT)
print('ÉCHECS :',fails); sys.exit(1 if fails else 0)
