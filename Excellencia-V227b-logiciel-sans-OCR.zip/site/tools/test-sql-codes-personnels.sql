\set ON_ERROR_STOP 0
\pset tuples_only on
create temp table r(t text, ok boolean);
grant all on r to public;
\set org '''11111111-1111-1111-1111-111111111111'''
\set adm '''00000000-0000-0000-0000-00000000000a'''
\set c1 '''00000000-0000-0000-0000-0000000000c1'''
\set c2 '''00000000-0000-0000-0000-0000000000c2'''
\set ing '''00000000-0000-0000-0000-0000000000e1'''
insert into auth.users values (:adm,'admin@t.com'),(:c1,'compta1@t.com'),(:c2,'compta2@t.com'),(:ing,'ing@t.com');
insert into organisations(id,nom,code_invitation,jeton_equipe) values (:org,'Org test','abcd1234',repeat('x',60)||'.'||repeat('y',60));
insert into membres(org_id,user_id,nom,role,fonction) values (:org,:adm,'Admin','admin','polyvalent');
-- 1) l'administrateur invite deux comptables et un ingénieur (aucun n'a encore de compte « arrivé » : les comptes existent mais ne sont pas membres) -> on supprime d'abord leurs comptes pour simuler une pré-inscription
delete from auth.users where id in (:c1,:c2,:ing);
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000a'; set request.jwt.claims='{"aal":"aal1"}';
select (equipe_inviter(:org,'compta1@t.com','Compta Un','editeur','comptable')::jsonb->>'statut') as i1 \gset
select (equipe_inviter(:org,'compta2@t.com','Compta Deux','editeur','comptable')::jsonb->>'statut') as i2 \gset
select (equipe_inviter(:org,'ing@t.com','Ing','editeur','bureau_etudes')::jsonb->>'statut') as i3 \gset
select (equipe_code_membre(:org,'compta1@t.com')::jsonb->>'code') as k1 \gset
select (equipe_code_membre(:org,'compta2@t.com')::jsonb->>'code') as k2 \gset
select (equipe_code_membre(:org,'ing@t.com')::jsonb->>'code') as k3 \gset
select (equipe_code_membre(:org,'compta1@t.com')::jsonb->>'code') as k1b \gset
reset role;
insert into r select 'trois invitations enregistrées', :'i1'='invite' and :'i2'='invite' and :'i3'='invite';
insert into r select 'chaque personne a SON code (3 codes différents, 8 caractères, ≠ code entreprise)', :'k1'<>:'k2' and :'k1'<>:'k3' and :'k2'<>:'k3' and length(:'k1')=8 and :'k1'<>'abcd1234';
insert into r select 'le code d''une personne est stable (redemandé = identique)', :'k1'=:'k1b';
-- 2) activation de l'appareil, sans compte
set role anon;
select (activer_par_invitation(:'k1')::jsonb->>'ok') as a1, (activer_par_invitation('zzzzzzzz')::jsonb->>'ok') as a2, (activer_par_invitation('abcd1234')::jsonb->>'ok') as a3 \gset
reset role;
insert into r select 'le code personnel déverrouille l''appareil sans compte', :'a1'='true';
insert into r select 'un code inconnu est refusé', :'a2'='false';
insert into r select 'le code d''entreprise continue de fonctionner (appareils déjà activés)', :'a3'='true';
-- 3) les comptes sont créés ; le comptable 2 essaie le code du comptable 1
insert into auth.users values (:c1,'compta1@t.com'),(:c2,'compta2@t.com'),(:ing,'ing@t.com');
do $$ declare e text; k text; begin
  select code into k from codes_membres where email='compta1@t.com';
  set local role authenticated; perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000c2',true);
  begin perform rejoindre_organisation(k,'Compta Deux'); e:='aucune erreur'; exception when others then e:=sqlerrm; end;
  reset role; insert into r values('un code transmis à quelqu''un d''autre est refusé ('||left(e,60)||')', e like 'ce code est personnel%'); end $$;
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c1';
select (rejoindre_organisation(:'k1','Compta Un')::jsonb->>'fonction') as j1 \gset
set request.jwt.claim.sub='00000000-0000-0000-0000-0000000000c2';
select (rejoindre_organisation(:'k2','Compta Deux')::jsonb->>'fonction') as j2 \gset
reset role;
insert into r select 'comptable 1 rejoint avec SON code (fonction comptable)', :'j1'='comptable';
insert into r select 'comptable 2 rejoint avec SON code (fonction comptable) : deux comptables dans la même entreprise', :'j2'='comptable' and (select count(*) from membres where org_id=:org and fonction='comptable')=2;
insert into r select 'les codes sont marqués « utilisés »', (select count(*) from codes_membres where utilise_le is not null)=2;
-- 4) un membre ne peut pas générer de codes
do $$ declare e text; begin
  set local role authenticated; perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000c1',true);
  begin perform equipe_code_membre('11111111-1111-1111-1111-111111111111','ing@t.com'); e:='aucune erreur'; exception when others then e:=sqlerrm; end;
  reset role; insert into r values('un non-administrateur ne peut pas lire/créer les codes ('||e||')', e like 'réservé%'); end $$;
-- 5) renouvellement, retrait, annulation
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000a';
select (equipe_regenerer_code(:org,'compta2@t.com')::jsonb->>'code') as k2n \gset
select equipe_retirer(:org,:c1) as ret \gset
select equipe_annuler((select id from invitations_equipe where email='ing@t.com')) as ann \gset
select (equipe_codes(:org)::jsonb) as liste \gset
reset role;
insert into r select 'code renouvelé : nouveau ≠ ancien', :'k2n'<>:'k2' and length(:'k2n')=8;
set role anon;
select (activer_par_invitation(:'k2')::jsonb->>'ok') as o1, (activer_par_invitation(:'k2n')::jsonb->>'ok') as o2, (activer_par_invitation(:'k1')::jsonb->>'msg') as o3 \gset
reset role;
insert into r select 'ancien code du comptable 2 refusé, nouveau accepté', :'o1'='false' and :'o2'='true';
insert into r select 'membre retiré : son code est révoqué', :'o3' like 'Ce code n’est plus valide%';
do $$ declare e text; k text; begin
  select code into k from codes_membres where email='ing@t.com';
  set local role authenticated; perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-0000000000e1',true);
  begin perform rejoindre_organisation(k,'Ing'); e:='aucune erreur'; exception when others then e:=sqlerrm; end;
  reset role; insert into r values('invitation annulée : le code n''ouvre plus rien ('||left(e,50)||')', e like 'invitation annulée%'); end $$;
insert into r select 'equipe_codes renvoie les 3 codes avec leur état', jsonb_array_length(:'liste'::jsonb)=3;
\echo ----- RÉSULTAT -----
select case when ok then 'OK   ' else 'FAIL ' end || t from r;
select 'Résultat : '||count(*) filter (where ok)||' OK, '||count(*) filter (where not ok)||' échec(s)' from r;
