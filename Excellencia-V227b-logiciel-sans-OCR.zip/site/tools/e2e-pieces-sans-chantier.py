# Test navigateur V186h : une pièce écrite (lettre, convocation…) peut être SANS chantier.
# Lancer :  python3 tools/e2e-pieces-sans-chantier.py   (Chromium + Playwright)
import http.server, threading, functools, os
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8898), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    pg.goto('http://127.0.0.1:8898/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("EXBPIE.open()"); pg.wait_for_timeout(600)
    ok(pg.evaluate("[].some.call(document.querySelectorAll('#exbPie select option'),function(o){return o.value===''&&/Sans chantier/.test(o.textContent)})"), 'le sélecteur propose « Sans chantier »')
    pg.evaluate("EXBPIE.proj('')"); pg.wait_for_timeout(300)
    pg.evaluate("EXBPIE.neu()"); pg.wait_for_timeout(300); pg.evaluate("EXBPIE.ct('lettre')"); pg.wait_for_timeout(300); pg.evaluate("EXBPIE.blank()"); pg.wait_for_timeout(800)
    x = pg.evaluate("(function(){var a=EXBS.get('exb_pieces');return a[a.length-1]})()")
    ok(x and x.get('project') == '', 'la lettre est créée sans chantier')
    ok(x and ' — ' not in x.get('title', ''), 'le titre ne contient aucun nom de chantier : ' + str(x and x.get('title')))
    ok(x and 'Réf. projet' not in x.get('body', ''), 'la lettre vierge n’a plus la ligne « Réf. projet »')
    ok(pg.evaluate("!!document.getElementById('pPj')") and pg.evaluate("document.getElementById('pPj').value===''"), 'le champ « Chantier / projet (facultatif) » est vide dans l’éditeur')
    h = pg.evaluate("EXBPIE.html(EXBS.get('exb_pieces').slice(-1)[0],'')")
    ok('Projet :' not in h, 'le document imprimé ne porte aucune mention « Projet : »')
    # rattacher puis détacher
    pj = pg.evaluate("(function(){var s=document.getElementById('pPj');return s.options.length>1?s.options[1].value:null})()")
    if pj:
        pg.evaluate("(function(v){var s=document.getElementById('pPj');s.value=v})(%r)" % pj); pg.evaluate("EXBPIE.save()"); pg.wait_for_timeout(300)
        ok(pg.evaluate("EXBS.get('exb_pieces').slice(-1)[0].project") == pj, 'on peut rattacher la pièce à un chantier')
        pg.evaluate("document.getElementById('pPj').value=''"); pg.evaluate("EXBPIE.save()"); pg.wait_for_timeout(300)
        ok(pg.evaluate("EXBS.get('exb_pieces').slice(-1)[0].project") == '', 'et la détacher de nouveau')
    else:
        print('  --   aucun projet dans ce jeu d’essai : rattachement non testé')
    ok(not errs, 'aucune erreur JavaScript ' + str(errs[:2]))
    b.close()
print('\n%d échec(s)' % len(fails)); raise SystemExit(1 if fails else 0)
