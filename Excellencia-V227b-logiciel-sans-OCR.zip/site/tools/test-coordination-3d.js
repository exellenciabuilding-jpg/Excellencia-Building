// Test de l'assemblage 3D des collisions (node tools/test-coordination-3d.js)
var vm=require('vm'),fs=require('fs'),a=require('assert');
var w={document:{documentElement:null,getElementById:function(){return null}},addEventListener:function(){},console:console,setTimeout:setTimeout,Promise:Promise};w.window=w;w.globalThis=w;vm.createContext(w);
['exb-v209-coordination.js','exb-v209-coordination-3d.js'].forEach(f=>vm.runInContext(fs.readFileSync(__dirname+'/../'+f,'utf8'),w,{}));
var I=require(__dirname+'/../exb-ifc3d.js'),G=w.EXBCOORD,D=w.EXBCOORD3D,n=0,Q=[];function t(x,f){Q.push([x,f])}
var T=f=>fs.readFileSync(__dirname+'/test-bim/'+f+'.ifc','utf8'),M,comp,res;
t('assemblage : positions, éléments, marqueurs',async()=>{
 var m1=await I.parse(T('villa')),m2=await I.parse(T('batiment-3-niveaux'));
 M=[{ref:'A',name:'archi',disc:'architecture',parsed:m1},{ref:'S',name:'str',disc:'structure',parsed:m2}];
 res=await G.detect(M,{tol:0.01,jeu:0});var cl=res.items.map((x,i)=>Object.assign({id:'C'+i,statut:'nouveau',storey:x.a.storey},x));
 comp=D.compose(M,cl);var m=comp.model;
 a.strictEqual(m.els.length,m1.els.length+m2.els.length+cl.length);
 a.strictEqual(m.vertexCount,m1.vertexCount+m2.vertexCount+cl.length*36);
 a.strictEqual(m.positions.length,m.vertexCount*3);a.strictEqual(comp.mapped,cl.length);
 a.strictEqual(Object.keys(comp.marker).length,cl.length)});
t('assemblage : modèles d’origine non modifiés',async()=>{var m1=M[0].parsed;a.ok(m1.els.every(e=>e.id<1e6&&!e._m))});
t('assemblage : identifiants uniques',async()=>{var s=new Set(comp.model.els.map(e=>e.id));a.strictEqual(s.size,comp.model.els.length)});
t('assemblage : géométrie du 2e modèle décalée correctement',async()=>{var m=comp.model,e0=M[1].parsed.els[0],e=m.els[comp.idx['S:'+(e0.gid||'#'+e0.id)]];a.strictEqual(e.start,e0.start+M[0].parsed.vertexCount);
 var o=e.start*3,src=M[1].parsed.positions[e0.start*3];a.strictEqual(m.positions[o],src)});
t('assemblage : couleur par discipline, marqueurs rouges',async()=>{var m=comp.model;var J=x=>JSON.stringify(x);a.strictEqual(J(m.els[0].color),J(D.PAL.architecture));a.strictEqual(J(m.els[M[0].parsed.els.length].color),J(D.PAL.structure));a.strictEqual(J(m.els[comp.marker[Object.keys(comp.marker)[0]]].color),J([220,38,38]))});
t('assemblage : propriétés routées vers le bon modèle',async()=>{var e0=M[1].parsed.els[3],id=comp.model.els[comp.idx['S:'+(e0.gid||'#'+e0.id)]].id;a.deepStrictEqual(JSON.stringify(comp.model.props(id)),JSON.stringify(M[1].parsed.props(e0.id)));a.strictEqual(JSON.stringify(comp.model.props(5)),'[]')});
t('marqueur : au moins 20 cm par côté et contient la zone',async()=>{var c=res.items[0],b=D.markerBox(c);for(var k=0;k<3;k++){a.ok(b.mx[k]-b.mn[k]>=0.2-1e-9);a.ok(b.mn[k]<=c.box[k]+1e-9&&b.mx[k]>=c.box[k+3]-1e-9)}});
t('visibilité : paire + marqueur ; le contexte ajoute des voisins',async()=>{var c=Object.assign({id:'C0',storey:'x'},res.items[0]);var cl=[c],cp=D.compose(M,cl);var v=D.visibleFor(cp,c,false);a.strictEqual(v.length,3);a.ok(D.visibleFor(cp,c,true).length>3)});
t('assemblage : plafond de marqueurs',async()=>{var big=[];for(var i=0;i<2500;i++)big.push(Object.assign({id:'K'+i,storey:'x'},res.items[0]));var cp=D.compose(M,big);a.strictEqual(cp.used.length,2000)});
t('assemblage sans collision',async()=>{var cp=D.compose(M,[]);a.strictEqual(cp.model.vertexCount,M[0].parsed.vertexCount+M[1].parsed.vertexCount)});
(async function(){for(var i=0;i<Q.length;i++){try{await Q[i][1]();n++;console.log('ok',Q[i][0])}catch(e){console.log('ÉCHEC',Q[i][0],'\n  ',e&&e.message);process.exitCode=1}}console.log(n+'/'+Q.length+' tests')})();
