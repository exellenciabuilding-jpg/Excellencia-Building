import json, os, threading, http.server, functools
from playwright.sync_api import sync_playwright
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8792),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':390,'height':800}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8792/index.html'); pg.wait_for_timeout(2500)
    r=pg.evaluate("""()=>{
      participants=[
       {participant_id:'A1',name:'Alain Paye',matricule:'111-111-111',training:'AutoCAD',approval_status:'APPROUVE'},
       {participant_id:'A2',name:'Berthe Moitie',matricule:'222-222-222',training:'AutoCAD',approval_status:'APPROUVE'},
       {participant_id:'A3',name:'Chantal SansRecu',matricule:'333-333-333',training:'Revit',approval_status:'APPROUVE'},
       {participant_id:'A4',name:'Didier InscNon',matricule:'444-444-444',training:'Revit',approval_status:'APPROUVE'}];
      receipts=[
       {receipt_no:'REC-1',participant:'Alain Paye',matricule:'111-111-111',registration_status:'PAYÉ',training_status:'PAYÉ',created_at:'2026-11-01T10:00:00Z'},
       {receipt_no:'REC-2',participant:'Berthe Moitie',matricule:'222-222-222',registration_status:'PAYÉ',training_status:'MOITIÉ PAYÉE',created_at:'2026-11-02T10:00:00Z'},
       {receipt_no:'REC-4',participant:'Didier InscNon',matricule:'444-444-444',registration_status:'NON PAYÉ',training_status:'PAYÉ',created_at:'2026-11-03T10:00:00Z'}];
      show('participants'); document.querySelector('#exbPayBar button[data-tab="pay"]').click();
      const cols=[...document.querySelectorAll('#exbPayBody > div:last-child > div')].map(c=>({titre:c.firstChild.textContent,noms:[...c.querySelectorAll('b')].map(x=>x.textContent)}));
      const body=document.getElementById('exbPayBody');
      return {cols:cols,boutonsRecu:[...document.querySelectorAll('#exbPayTab button')].filter(x=>/reçu/i.test(x.textContent)).length,
              boutonsAction:document.querySelectorAll('#exbPayTab [data-a]').length,
              tags:[...body.querySelectorAll('span')].map(x=>x.textContent),
              cote:getComputedStyle(body.lastElementChild).display,
              debord:document.documentElement.scrollWidth<=window.innerWidth+1}}""")
    print(json.dumps(r,ensure_ascii=False,indent=1)); print('erreurs',errs[:3])
    b.close()
