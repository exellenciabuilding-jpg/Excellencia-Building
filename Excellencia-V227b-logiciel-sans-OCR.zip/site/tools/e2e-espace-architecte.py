# V205 lot 4 — Espace Architecture : lien /architecte, menu limité (sans calcul de structure, finance, stock, RH), accès par fonction
import http.server, threading, functools, os, sys, datetime
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
TODAY = datetime.date.today().isoformat()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    boot('architecte.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'architecte', 'le lien /architecte ouvre l\'Espace Architecture')
    pg.evaluate("exbProjects=[{id:'P1',name:'Villa Test',status:'En cours'},{id:'P2',name:'Ecole',status:'Terminé'}]")
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(700)
    mt = ' | '.join(pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)"))
    print('MENU :', mt)
    t('Projets' in mt and 'Clients' in mt, 'le menu contient Projets et Clients')
    t(not any(x in mt for x in ['Finances', 'finances', 'achats', 'Comptabilité', 'Reçus', 'Stock', 'Apprenants', 'Formation', 'Paie']), 'le menu ne contient ni finance, ni stock, ni RH, ni formation')
    t('Calcul' not in mt and 'béton' not in mt.lower() and 'Robot' not in mt, 'le menu ne contient pas les calculs de structure')
    t(mt.count('Messagerie') == 1, 'une seule entrée Messagerie')
    t('Planning & budget' not in mt and 'Pilotage projets' not in mt, 'pas de planning/budget ni de pilotage financier (budget hors des droits de l\'architecte)')
    h = pg.evaluate("document.getElementById('xhK').innerText")
    t('Projets en cours' in h and 'Plan Editor' in h and 'Villa Test' in pg.evaluate("document.getElementById('xhChart').innerText"), 'le tableau de bord liste les projets en cours et le Plan Editor')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(500)
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False and 'Accès refusé' in pg.evaluate("document.getElementById('xhK').innerText"), 'un comptable est refusé dans l\'Espace Architecture')
    for f, lab, att in [('architecte','Architecte',True),('bureau_etudes','Bureau etudes',True),('chef_projet','Chef de projet',True),('direction','Direction',True),('conducteur','Conducteur',False),('magasinier','Magasinier',False),('rh','RH',False)]:
        pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'%s',label:'%s'})" % (f, lab))
        t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is att, 'fonction %s : %s' % (f, 'acceptée' if att else 'refusée'))
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'admin',fonction:'polyvalent',label:'Administrateur'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'l\'administrateur est accepté')
    pg.evaluate("EXB_SHELL.quitEspace()"); pg.wait_for_timeout(3500)
    t(pg.evaluate("localStorage.getItem('exb_espace')") is None, 'quitter l\'espace restaure le menu complet')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
