/* Tests V166 : TVA récupérable, compte de résultat, bilan simplifié, verrou (node tools/test-compta-etats.js). Chiffres calculés à la main. */
const assert = require('assert'); let n = 0;
const ok = (c, m) => { assert(c, m); n++; };
const eq = (a, b, m) => { assert.deepStrictEqual(a, b, m + ' : ' + JSON.stringify(a) + ' ≠ ' + JSON.stringify(b)); n++; };
const store = {}, logs = [], said = [];
global.window = global;
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
global.load = (k, df) => { try { const v = JSON.parse(store[k]); return v == null ? df : v; } catch (e) { return df; } };
global.save = (k, v) => { store[k] = JSON.stringify(v); return true; };
global.notify = (m, t) => said.push(m);
global.EXBCore = { audit: { log: (a, o) => logs.push(a + '|' + o) }, modules: { register() {} } };
global.document = { readyState: 'loading', addEventListener() {}, getElementById: () => null, createElement: () => ({}), body: { appendChild() {} }, hidden: false };
const setStore = (k, v) => { store[k] = JSON.stringify(v); };
require('../exb-compta.js');
const T = window.EXBCOMPTA._t;
const before = T.entries().length; eq(before, 0, 'sans données : aucune écriture');
require('../exb-compta-etats.js');
const E = window.EXBCOMPTA_ETATS;
ok(E && E.version === 1, 'extension chargée');
ok(window.save !== undefined && window.__exbCptGuard === 1, 'verrou installé (inactif par défaut)');

/* ---------- données de base (USD) ---------- */
setStore('exb_invoices', [{ id: 'f1', no: 'FA-1', client: 'Kabila', project_id: 'p1', date: '2026-10-05', due: '2026-10-30', tva: 16, currency: 'USD', lines: [{ q: 2, pu: 500 }], payments: [{ amount: 600, date: '2026-10-20', method: 'Espèces' }] }]);
setStore('exb_v92_supplier_invoices', [{ id: 's1', no: 'FF-9', supplier: 'ABC', date: '2026-10-08', amount: 580, currency: 'USD' }]);
setStore('exb_cash', [{ id: 'c1', date: '2026-10-15', type: 'out', label: 'Loyer bureau', amount: 200, currency: 'USD', method: 'Espèces' }]);
const base = T.entries(); eq(base.length, 3 + 2 + 2 + 2, 'écritures V165 inchangées : facture 3 + encaissement 2 + achat 2 + loyer 2');
const sumAcc = (L, a, f) => L.filter(e => e.acc === a).reduce((s, e) => s + f(e), 0);

/* ---------- état sans justificatif de TVA ---------- */
let L = T.entries(), R = E.resultat(L), B = E.bilan(L), V = E.tvaState(L);
eq([R.totalProduits, R.totalCharges, R.resultat], [1000, 780, 220], 'résultat sans TVA récupérable : 1000 − (580 + 200)');
eq([V.collectee, V.recuperable, V.solde, V.etat], [160, 0, 160, 'à reverser'], 'TVA : collectée 160, récupérable 0');
ok(B.equilibre, 'bilan équilibré'); eq([B.totalActif, B.totalPassif], [1160 - 600 + 600 - 200, 580 + 160 + 220], 'actif = 960, passif = 960');

/* ---------- justificatif de TVA déductible ---------- */
const closed0 = {};
ok(/obligatoire/.test(E.tvaValidate({ date: '2026-10-08', supplier: 'ABC', ref: '', ht: 500, rate: 16, acc: '601' }, closed0).error), 'n° de pièce obligatoire');
ok(/Taux/.test(E.tvaValidate({ date: '2026-10-08', supplier: 'ABC', ref: 'FF-9', ht: 500, rate: 0, acc: '601' }, closed0).error), 'taux nul refusé');
ok(/Taux/.test(E.tvaValidate({ date: '2026-10-08', supplier: 'ABC', ref: 'FF-9', ht: 500, rate: 120, acc: '601' }, closed0).error), 'taux > 100 refusé');
ok(/charge/.test(E.tvaValidate({ date: '2026-10-08', supplier: 'ABC', ref: 'FF-9', ht: 500, rate: 16, acc: '411' }, closed0).error), 'compte de charge obligatoire (411 refusé)');
ok(/clôturé/.test(E.tvaValidate({ date: '2026-10-08', supplier: 'ABC', ref: 'FF-9', ht: 500, rate: 16, acc: '601' }, { '2026-10': 1 }).error), 'mois clôturé refusé');
let r = E.addTva({ date: '2026-10-08', supplier: 'ABC', ref: 'FF-9', ht: 500, rate: 16, acc: '601', currency: 'USD' });
ok(r.rec && r.rec.tva === 80 && r.rec.ttc === 580, 'TVA 16 % de 500 = 80, TTC 580');
L = T.entries(); eq(L.length, base.length + 2, 'deux écritures de reclassement ajoutées');
R = E.resultat(L); B = E.bilan(L); V = E.tvaState(L);
eq([R.totalProduits, R.totalCharges, R.resultat], [1000, 700, 300], 'résultat : charges 601 = 580 − 80, loyer 200');
eq([V.collectee, V.recuperable, V.solde, V.etat], [160, 80, 80, 'à reverser'], 'TVA : 160 − 80 = 80 à reverser');
ok(B.equilibre && B.totalActif === 1040 && B.totalPassif === 1040, 'bilan : actif = passif = 1 040');
eq(B.actif.map(x => [x.acc, x.amount]), [['411', 560], ['4452', 80], ['571', 400]], 'actif : clients 560, TVA récupérable 80, caisse 400');
eq(B.passif.map(x => [x.acc, x.amount]), [['401', 580], ['4431', 160], ['RES', 300]], 'passif : fournisseurs 580, TVA due 160, résultat 300');
const tl = T.balance(L); ok(tl.ok, 'journal équilibré débit = crédit');
/* avoir de 116 TTC (100 HT + 16 TVA) sur la facture */
setStore('exb_credit_notes', [{ id: 'a1', no: 'AV-2026-0001', date: '2026-10-25', invoice_id: 'f1', invoice_no: 'FA-1', currency: 'USD', ht: 100, tva_amount: 16, ttc: 116, status: 'émis', motif: 'remise' }]);
L = T.entries(); R = E.resultat(L); B = E.bilan(L); V = E.tvaState(L);
eq([R.totalProduits, R.resultat], [900, 200], 'avoir : produits 1000 − 100, résultat 200');
eq([V.collectee, V.solde], [144, 64], 'avoir : TVA collectée 144, solde 64');
ok(B.equilibre && B.totalActif === 924, 'bilan équilibré avec avoir : 924');
/* période : octobre seulement vs novembre vide */
eq(E.resultat(L.filter(e => e.date >= '2026-11-01')).resultat, 0, 'novembre : résultat 0');
/* annulation */
ok(/motif/.test(E.cancelTva(r.rec.id, '').error), 'annulation : motif obligatoire');
ok(E.cancelTva(r.rec.id, 'erreur de saisie').ok, 'annulation acceptée');
eq(T.entries().length, base.length + 3, 'justificatif annulé : plus d\'écriture TVA (avoir : +3)'); eq(E.tvaState(T.entries()).recuperable, 0, 'TVA récupérable revenue à 0');
ok(logs.some(l => l.startsWith('compta.tva.ajout')) && logs.some(l => l.startsWith('compta.tva.annulation')), 'journal d\'audit alimenté');
/* devises séparées */
setStore('exb_cash', [{ id: 'c1', date: '2026-10-15', type: 'out', label: 'Loyer bureau', amount: 200, currency: 'USD', method: 'Espèces' }, { id: 'c2', date: '2026-10-16', type: 'out', label: 'Loyer', amount: 500000, currency: 'CDF' }]);
L = T.entries(); eq(E.resultat(L.filter(e => e.cur === 'FC')).totalCharges, 500000, 'devise FC séparée'); eq(E.resultat(L.filter(e => e.cur === 'USD')).totalCharges, 780, 'USD inchangé par la dépense en FC');
ok(E.bilan(L.filter(e => e.cur === 'FC')).equilibre, 'bilan FC équilibré');

/* ---------- verrou ---------- */
const C = { '2026-10': 1 }, G = (k, o, nw) => E.guardCheck(k, o, nw, C);
const inv = JSON.parse(store.exb_invoices), cash = JSON.parse(store.exb_cash);
const cl = x => JSON.parse(JSON.stringify(x));
eq(G('exb_cash', cash, cash.concat([{ id: 'c9', date: '2026-10-30', type: 'out', amount: 10 }])), { blocked: true, months: ['2026-10'] }, 'dépense ajoutée dans un mois clôturé : refusée');
ok(!G('exb_cash', cash, cash.concat([{ id: 'c9', date: '2026-11-02', type: 'out', amount: 10 }])).blocked, 'dépense du mois suivant : acceptée');
ok(G('exb_cash', cash, []).blocked, 'suppression d\'une dépense d\'un mois clôturé : refusée');
ok(!G('exb_cash', cash, cash.concat([{ id: 'c8', date: '2026-10-30', type: 'in', amount: 10, invoice_id: 'f1' }])).blocked, 'ligne de caisse liée à une facture (ignorée par le journal) : non concernée');
let i2 = cl(inv); i2[0].payments.push({ amount: 50, date: '2026-11-03', method: 'Espèces' }); ok(!G('exb_invoices', inv, i2).blocked, 'paiement de novembre sur une facture d\'octobre : accepté');
i2 = cl(inv); i2[0].payments.push({ amount: 50, date: '2026-10-28', method: 'Espèces' }); ok(G('exb_invoices', inv, i2).blocked, 'paiement daté d\'octobre : refusé');
i2 = cl(inv); i2[0].payments[0].amount = 700; ok(G('exb_invoices', inv, i2).blocked, 'montant d\'un paiement d\'octobre modifié : refusé');
i2 = cl(inv); i2[0].lines[0].pu = 600; ok(G('exb_invoices', inv, i2).blocked, 'lignes de facture modifiées : refusé');
i2 = cl(inv); i2[0].note = 'rappel envoyé'; i2[0].project_id = 'p9'; i2[0].client = 'Kabila SA'; ok(!G('exb_invoices', inv, i2).blocked, 'note / projet / nom du client modifiés (aucune écriture changée) : accepté');
i2 = cl(inv); i2[0].annule = true; ok(G('exb_invoices', inv, i2).blocked, 'annulation d\'une facture d\'octobre : refusée');
i2 = cl(inv).concat([{ id: 'f2', no: 'FA-2', date: '2026-11-04', tva: 16, currency: 'USD', lines: [{ q: 1, pu: 10 }], payments: [] }]); ok(!G('exb_invoices', inv, i2).blocked, 'nouvelle facture de novembre : acceptée');
ok(!E.guardCheck('exb_clients', [], [{ id: 1 }], C).blocked, 'clé non surveillée : ignorée');
ok(!E.guardCheck('exb_cash', cash, cash.concat([{ id: 'c9', date: '2026-10-30', type: 'out', amount: 10 }]), {}).blocked, 'aucun mois clôturé : rien à refuser');

/* enveloppe de save() : désactivée par défaut, active après activation, levée à la réouverture */
setStore('exb_compta_close', [{ id: 'CLO1', ym: '2026-10', hash: 'x', n: 1, by: 'moi', at: '2026-11-01T00:00:00Z' }]);
const addOct = cash.concat([{ id: 'c9', date: '2026-10-30', type: 'out', amount: 10, currency: 'USD', label: 'Ciment' }]);
ok(window.save('exb_cash', addOct) === true && JSON.parse(store.exb_cash).length === cash.length + 1, 'verrou désactivé : saisie acceptée et enregistrée');
setStore('exb_cash', cash); E.setGuard(true); ok(E.guardOn(), 'verrou activé');
ok(window.save('exb_cash', addOct) === false, 'verrou actif : saisie d\'octobre refusée');
eq(JSON.parse(store.exb_cash).length, cash.length, 'rien n\'a été écrit'); ok(said.some(m => /clôturée/.test(m)), 'message à l\'utilisateur'); ok(logs.some(l => l.startsWith('compta.verrou.refus')), 'refus journalisé');
ok(window.save('exb_cash', cash.concat([{ id: 'c10', date: '2026-11-02', type: 'out', amount: 10, currency: 'USD' }])) === true, 'verrou actif : saisie de novembre acceptée');
ok(/clôturé/.test(E.addTva({ date: '2026-10-08', supplier: 'A', ref: 'R', ht: 10, rate: 16, acc: '601' }).error), 'justificatif de TVA dans un mois clôturé : refusé');
setStore('exb_compta_close', [{ id: 'CLO1', ym: '2026-10', reopened: true }]); ok(window.save('exb_cash', addOct) === true, 'mois rouvert : saisie acceptée');
E.setGuard(false); ok(!E.guardOn(), 'verrou désactivé');

/* l'empreinte des mois clôturés avant V166 ne change pas tant qu'aucun justificatif n'existe */
const nSans = (delete store.exb_tva_achats, T.entries().length); store.exb_tva_achats = JSON.stringify([{ id: 'x', status: 'annulé', date: '2026-10-08', tva: 5, acc: '601', ref: 'R', supplier: 'S' }]); eq(T.entries().length, nSans, 'aucun justificatif actif : V166 n\'ajoute aucune écriture (empreintes de clôture inchangées)');

console.log('V166 comptabilité : ' + n + ' contrôles OK');
