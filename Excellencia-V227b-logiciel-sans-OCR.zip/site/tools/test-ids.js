/* Tests de l'identifiant stable unique (V186) — node tools/test-ids.js */
const I=require('../exb-core-ids.js');let ko=0;
const eq=(a,b,m)=>{const ok=JSON.stringify(a)===JSON.stringify(b);console.log((ok?'  OK   ':'  FAIL ')+m+(ok?'':` (obtenu ${JSON.stringify(a)}, attendu ${JSON.stringify(b)})`));if(!ok)ko++};
const ok=(c,m)=>eq(!!c,true,m);

/* périmètre */
eq(['exb_participants','exb_v93_payments','exb_stock_moves'].map(I.eligible),[true,true,true],'collections métier éligibles');
eq(['exb_core_audit','exb_core_events','exb_audit','exb_errlog','exb_wf_outbox','exb_v73_offline_queue','exb_tr_cache','exb_lic_token','exb_theme','exb_msg_queue'].map(I.eligible),Array(10).fill(false),'journaux, files, caches, licence, préférences exclus');
eq(I.eligible('autre_cle'),false,'clé hors exb_ exclue');

/* attribution */
let l=[{id:'DEV-1'},{no:'F-1'},{name:'x'}];
let r=I.ensure('exb_quotes',l);
eq([r.changed,r.added],[true,2],'2 fiches sans identifiant : 2 attributions');
eq(l[0],{id:'DEV-1'},'une fiche qui a un « id » n\'est PAS modifiée');
ok(l[1].uid&&l[2].uid&&l[1].uid!==l[2].uid,'les « uid » ajoutés sont distincts');
ok(/^quotes_[a-z0-9]+_[a-z0-9]+$/.test(l[1].uid),'format type_horodatage_aléa : '+l[1].uid);
const snap=JSON.stringify(l);
r=I.ensure('exb_quotes',l);
eq([r.changed,JSON.stringify(l)===snap],[false,true],'idempotent : seconde passe = aucun changement');

/* stabilité : un module reconstruit la fiche et perd « uid » */
const prev=JSON.parse(snap), uid1=prev[1].uid;
const rebuilt=[{id:'DEV-1'},{no:'F-1',total:5},{name:'x'}];
r=I.ensure('exb_quotes',rebuilt,{prev:prev});
eq(rebuilt[1].uid,uid1,'fiche reconstruite : son « uid » est retrouvé par sa référence (no)');
eq(r.restored,1,'1 identifiant restauré');
ok(rebuilt[2].uid&&rebuilt[2].uid!==prev[2].uid,'fiche sans référence naturelle : nouvel identifiant (non devinable)');

/* copie par recopie d'objet */
l=[{no:'A'}];I.ensure('exb_cash',l);const cp=Object.assign({},l[0],{label:'copie'});l.push(cp);
r=I.ensure('exb_cash',l);
ok(l[0].uid!==l[1].uid,'copie {...x} : le doublon d\'« uid » est corrigé');eq(r.regenerated,1,'1 identifiant régénéré');
/* doublon d'« id » : signalé, jamais corrigé */
l=[{id:'X'},{id:'X'}];r=I.ensure('exb_cash',l);
eq([r.duplicates,l[1].id,r.changed],[['X'],'X',false],'doublon d\'« id » module : signalé, non modifié');

/* balayage déterministe : deux appareils → mêmes identifiants */
const A=[{no:'F-9',amount:5},{name:'sans ref',x:1},{name:'sans ref',x:1}];
const B=JSON.parse(JSON.stringify(A)).reverse();
I.ensure('exb_cash',A,{legacy:true});I.ensure('exb_cash',B,{legacy:true});
const ids=x=>x.map(o=>o.uid).sort();
eq(ids(A),ids(B),'balayage : mêmes fiches → mêmes identifiants sur deux appareils');
eq(new Set(A.map(o=>o.uid)).size,3,'balayage : fiches identiques → identifiants quand même uniques (suffixe)');
ok(A[0].uid.startsWith('cash_L_'),'balayage : préfixe « L » (existant) : '+A[0].uid);
const C=[{no:'F-9',amount:5}];I.ensure('exb_cash',C,{legacy:true});
eq(C[0].uid,A[0].uid,'la référence naturelle prime sur le contenu (modifiable) : même identifiant malgré un autre montant');
ok(JSON.stringify(A).indexOf('"uid":"cash_L_')>0&&A.every(o=>I.idOf(o)),'balayage : plus aucune fiche sans identifiant');

/* valeurs limites */
eq(I.ensure('exb_x',null).changed,false,'non-liste ignorée');
l=[1,'a',null,{a:1},[2]];r=I.ensure('exb_x',l);
eq([r.records,r.added,l[0],l[1],l[2]],[1,1,1,'a',null],'éléments non-objets laissés intacts');
eq(I.idOf({id:0,uid:'u1'}),'u1','id = 0 / vide traité comme absent');
eq(I.scan('exb_k',[{id:'a'},{uid:'b'},{x:1},{id:'a'}]).missing,1,'scan : 1 fiche sans identifiant');
console.log('\nRésultat :',ko?ko+' échec(s)':'tout passe');process.exit(ko?1:0);
