# Captures d'écran RÉELLES du logiciel (index.html) pour chaque espace ; données de démonstration (non réelles).
import http.server, threading, functools, os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); OUT = os.path.join(ROOT, 'docs', 'espaces')
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
SEED = """()=>{
 exbProjects.splice(0,exbProjects.length,
  {id:'PRJ-01',name:'Immeuble R+3 Gombe',client:'Société Kasa',status:'En cours',created_at:'2026-03-04'},
  {id:'PRJ-02',name:'Villa Ngaliema',client:'M. Mbuyi',status:'En cours',created_at:'2026-05-12'},
  {id:'PRJ-03',name:'Entrepôt Limete',client:'Logistik RDC',status:'En cours',created_at:'2026-07-02'},
  {id:'PRJ-04',name:'École primaire Kintambo',client:'ASBL Espoir',status:'Terminé',created_at:'2026-01-20'});
 exbClients.splice(0,exbClients.length,
  {name:'Société Kasa',phone:'+243 81 000 01 01',created_at:'2026-02-10'},{name:'M. Mbuyi',phone:'+243 99 000 02 02',created_at:'2026-04-18'},
  {name:'Logistik RDC',phone:'+243 85 000 03 03',created_at:'2026-06-25'},{name:'ASBL Espoir',phone:'+243 82 000 04 04',created_at:'2026-01-08'});
 participants.splice(0,participants.length,
  {participant_id:'P1',name:'Marie Kabila',training:'AutoCAD',matricule:'EXB-001',phone:'+243900111222',approval_status:'APPROUVE',created_at:'2026-09-02'},
  {participant_id:'P2',name:'Jean Mukendi',training:'Revit',matricule:'EXB-002',phone:'+243900333444',approval_status:'APPROUVE',created_at:'2026-09-14'},
  {participant_id:'P3',name:'Grace Ilunga',training:'AutoCAD',matricule:'EXB-003',phone:'+243900555666',approval_status:'APPROUVE',created_at:'2026-10-01'});
 exbHr.splice(0,exbHr.length,{id:'HR1',name:'Patrick Tshibangu',role:'Conducteur de travaux',status:'Actif'},{id:'HR2',name:'Sarah Mwamba',role:'Comptable',status:'Actif'},{id:'HR3',name:'Joël Kalala',role:'Magasinier',status:'Actif'},{id:'HR4',name:'Alice Nsimba',role:'Secrétaire',status:'Actif'});
 exbStock.splice(0,exbStock.length,{id:'S1',name:'Ciment 42,5 (sac 50 kg)',unit:'sacs',qty:12,min:40},{id:'S2',name:'Fer à béton Ø12',unit:'barres',qty:260,min:100},{id:'S3',name:'Sable lavé',unit:'m³',qty:8,min:10},{id:'S4',name:'Briques creuses',unit:'pcs',qty:1800,min:500});
 exbStockMoves.splice(0,exbStockMoves.length,{id:'M1',item:'S1',type:'sortie',qty:30},{id:'M2',item:'S2',type:'entrée',qty:100},{id:'M3',item:'S3',type:'sortie',qty:4});
 try{formations.splice(0,formations.length,{formation_id:'F1',name:'AutoCAD',price:150},{formation_id:'F2',name:'Revit',price:200})}catch(e){}
 receipts.splice(0,receipts.length,{receipt_no:'REC-001',participant:'Marie Kabila',matricule:'EXB-001',training:'AutoCAD',created_at:'2026-09-03T10:00:00Z',registration_status:'PAYÉ',training_status:'PAYÉ'});
}"""
def dash(fn, who):
    return "window.EXBDB.info=()=>({on:true,role:'%s',fonction:'%s',label:'%s'})" % who
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1440, 'height': 900}, device_scale_factor=2); pg = ctx.new_page()
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4500)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:grid!important}')
        pg.evaluate(SEED)
    def snap(name):
        pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(900); pg.evaluate("window.scrollTo(0,0)")
        pg.screenshot(path=os.path.join(OUT, name + '.png')); print('capture', name)
    for page, name, who in [('espace-formation.html','formation',('editeur','formateur','Formateur')),('chantier.html','chantier',('editeur','conducteur','Conducteur de travaux')),
                            ('magasin.html','magasin',('editeur','magasinier','Magasinier')),('direction.html','direction',('admin','direction','Direction')),
                            ('administration.html','administration',('editeur','rh','Ressources humaines')),('comptable.html','comptable',('editeur','comptable','Comptable')),('ingenieur.html','ingenieur',('editeur','bureau_etudes','Bureau d’études')),('architecte.html','architecte',('editeur','architecte','Architecte'))]:
        boot(page); pg.evaluate("window.EXBDB.info=()=>({on:true,role:'%s',fonction:'%s',label:'%s'})" % who); snap(name)
    # écrans de parcours : paiement déclaré -> comptable ; liste payé / pas payé dans Formation
    boot('comptable.html'); pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    pg.evaluate("""()=>{window.exbSb={isIn:()=>true,api:async(u)=>/paiements_declares\\?type/.test(u)?[{id:7,type:'apprenant',nom:'Jean Mukendi',telephone:'+243900333444',matricule:'EXB-002',montant:50,devise:'USD',reseau:'M-Pesa',numero_payeur:'+243900333444',reference:'MP58213947',statut:'a_verifier',doublon:false,created_at:new Date().toISOString()},{id:8,type:'apprenant',nom:'Grace Ilunga',telephone:'+243900555666',matricule:'EXB-003',montant:30,devise:'USD',reseau:'Airtel Money',numero_payeur:'+243900555666',reference:'AM77120045',statut:'a_verifier',doublon:true,created_at:new Date().toISOString()}]:[]}}""")
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(1200); pg.evaluate("window.scrollTo(0,0)")
    pg.screenshot(path=os.path.join(OUT, 'comptable-paiements-declares.png')); print('capture comptable-paiements-declares')
    boot('espace-formation.html'); pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'formateur',label:'Formateur'})")
    pg.evaluate("show('participants')"); pg.wait_for_timeout(800)
    pg.evaluate("(()=>{const b=document.querySelector('#exbPayBar button[data-tab=pay]');if(b)b.click()})()"); pg.wait_for_timeout(800); pg.evaluate("window.scrollTo(0,0)")
    pg.screenshot(path=os.path.join(OUT, 'formation-paiements-apprenants.png')); print('capture formation-paiements-apprenants')
    b.close()
