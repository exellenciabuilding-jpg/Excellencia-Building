# Test navigateur V192b : choix « Rattachée à » (chantier ou sans chantier) dès la création d'une pièce écrite, choix mémorisé.
# Lancer :  python3 tools/e2e-pieces-rattachement.py   (Chromium + Playwright)
import http.server, threading, functools, os
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8901), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
def boot(pg):
    pg.goto('http://127.0.0.1:8901/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    boot(pg)
    pg.evaluate("localStorage.setItem('exb_active_project','P1');localStorage.removeItem('exb_pie_none')")
    pg.evaluate("EXBS.set('exb_projects',[{id:'P1',nom:'Chantier Gombe'},{id:'P2',nom:'Villa Ngaliema'}])")
    pg.evaluate("EXBPIE.open()"); pg.wait_for_timeout(500)
    ok(pg.locator('#exbPie select').first.input_value() == 'P1', 'par défaut : le chantier actif (comportement habituel conservé)')
    pg.click('text=Nouvelle pièce'); pg.wait_for_timeout(300)
    s = pg.locator('#exbPie select').first
    ok('Sans chantier' in s.locator('option').first.inner_text(), 'écran « type de pièce » : menu « Rattachée à » avec « Sans chantier »')
    s.select_option(''); pg.wait_for_timeout(100)
    pg.click('button:has-text("Note, rapport ou fiche technique")'); pg.wait_for_timeout(300)
    ok(pg.locator('#exbPie select').first.input_value() == '', 'écran « modèle » : « Sans chantier » conservé')
    pg.click('button:has-text("Rapport de visite de chantier")'); pg.wait_for_timeout(900)
    x = pg.evaluate("(function(){var a=EXBS.get('exb_pieces');return a[a.length-1]})()")
    ok(x['project'] == '' and ' — ' not in x['title'], 'la note est créée sans chantier, titre sans nom de chantier : « %s »' % x['title'])
    ok(not any(t in x['body'] for t in ('{{projet}}','{{lieu}}','{{phase}}','{{moa}}','{{client}}','{{permis}}')) and '____________' in x['body'], 'les données de chantier du modèle sont à compléter (____), sans jeton {{projet}}, {{lieu}}… brut')
    h = pg.evaluate("EXBPIE.html(EXBS.get('exb_pieces').slice(-1)[0],'')")
    ok('Projet :' not in h and 'Lieu :' not in h, 'le PDF n’affiche ni « Projet » ni « Lieu » inutiles')
    pg.select_option('#pPj', 'P2'); pg.evaluate("EXBPIE.save()"); pg.wait_for_timeout(300)
    ok(pg.evaluate("EXBS.get('exb_pieces').slice(-1)[0].project") == 'P2', 'rattachement ultérieur à un chantier possible')
    pg.select_option('#pPj', ''); pg.evaluate("EXBPIE.save()"); pg.wait_for_timeout(300)
    # liste « Sans chantier » / chantier
    pg.evaluate("EXBPIE.back()"); pg.wait_for_timeout(300)
    ok('NOT-' in pg.locator('#exbPie').inner_text(), 'liste « Sans chantier » : la note apparaît')
    pg.evaluate("EXBPIE.proj('P1')"); pg.wait_for_timeout(300)
    ok('NOT-' not in pg.locator('#exbPie').inner_text(), 'liste du chantier : la note sans chantier n’apparaît pas')
    # mémorisation du dernier choix « Sans chantier »
    pg.evaluate("EXBPIE.proj('')"); boot(pg); pg.evaluate("EXBPIE.open()"); pg.wait_for_timeout(500)
    ok(pg.locator('#exbPie select').first.input_value() == '', 'après réouverture du logiciel : « Sans chantier » est retenu')
    pg.evaluate("EXBPIE.proj('P1')"); boot(pg); pg.evaluate("EXBPIE.open()"); pg.wait_for_timeout(500)
    ok(pg.locator('#exbPie select').first.input_value() == 'P1', 'et le choix d’un chantier le remplace')
    # pièce de chantier inchangée
    pg.evaluate("EXBPIE.neu()"); pg.wait_for_timeout(200); pg.evaluate("EXBPIE.ct('lettre')"); pg.wait_for_timeout(200); pg.evaluate("EXBPIE.blank()"); pg.wait_for_timeout(700)
    t = pg.evaluate("EXBS.get('exb_pieces').slice(-1)[0]")
    ok(t['project'] == 'P1' and 'Chantier Gombe' in t['title'], 'pièce de chantier : le nom du chantier reste dans le titre')
    ok(not errs, 'aucune erreur JavaScript' + (' : ' + errs[0] if errs else ''))
    b.close()
print('\n%s' % ('TOUT EST OK' if not fails else '%d ÉCHEC(S)' % len(fails)))
raise SystemExit(1 if fails else 0)
