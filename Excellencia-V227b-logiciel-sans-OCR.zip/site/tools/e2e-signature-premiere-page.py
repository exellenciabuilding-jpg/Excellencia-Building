# Test navigateur V198 : signature + cachet des pièces écrites posés UNE seule fois, en bas de la 1re page (jamais répétés).
# Lancer :  python3 tools/e2e-signature-premiere-page.py   (Chromium + Playwright ; poppler « pdfimages » pour compter les images du PDF)
import http.server, threading, functools, os, sys, subprocess, struct, zlib, base64, tempfile, shutil
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8912), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
if not shutil.which('pdfimages'):
    print('  --   pdfimages (poppler) absent : test ignoré'); raise SystemExit(0)
def png(w, h, rgb):
    raw = b''.join(b'\x00' + bytes(rgb) * w for _ in range(h))
    def ch(t, d): c = struct.pack('>I', len(d)) + t + d; return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw)) + ch(b'IEND', b'')
VISA = 'data:image/png;base64,' + base64.b64encode(png(211, 97, (200, 30, 30))).decode()   # repère 211 x 97
def par_page(path):
    out = subprocess.run(['pdfimages', '-list', path], capture_output=True, text=True).stdout; r = {}
    for l in out.splitlines()[2:]:
        f = l.split()
        if len(f) > 4 and f[2] == 'image' and f[3] == '211' and f[4] == '97': r[int(f[0])] = r.get(int(f[0]), 0) + 1
    return r
def npages(path):
    for l in subprocess.run(['pdfinfo', path], capture_output=True, text=True).stdout.splitlines():
        if l.startswith('Pages'): return int(l.split()[1])
    return 0
def corps(n): return '\n\n'.join('## Article %d\n\n' % i + ('Texte du paragraphe %d, assez long pour remplir des lignes entières et faire plusieurs pages. ' % i) * 4 for i in range(1, n + 1))
tmp = tempfile.mkdtemp()
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    pg.goto('http://127.0.0.1:8912/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    # 1) impression (Windows / Android / aperçu imprimable) : plusieurs pages, le visa ne sort qu'une fois, sur la page 1
    for (typ, mode, n, nom) in [('cctp', 'dg', 21, 'Directeur Général'), ('cctp', 'two', 21, 'Les parties (3 cases)'), ('os', 'dg', 21, 'Ordre de service'), ('lettre', 'dg', 14, 'Lettre'), ('cctp', 'dg', 1, 'Document court')]:
        x = {'id': 'T1', 'type': typ, 'title': 'Essai', 'no': 'T-001', 'date': '2026-11-18', 'body': corps(n), 'sign': mode, 'status': 'brouillon', 'project': '', 'entreprise': 'Entreprise X', 'dest': 'M. Dupont'}
        h = pg.evaluate("([x,v])=>EXBPIE.html(x,v)", [x, VISA]); q = ctx.new_page(); q.set_content(h); q.wait_for_timeout(600)
        f = os.path.join(tmp, 'a.pdf'); q.pdf(path=f, prefer_css_page_size=True, print_background=True); q.close()
        r = par_page(f); N = npages(f)
        ok(r == {1: 1}, '%s : %d page(s), visa une seule fois, sur la page 1 (%s)' % (nom, N, r))
        if n == 1: ok(N == 1, 'document court : une seule page (plus de page 2 quasi vide)')
    # 2) PDF fabriqué dans le navigateur
    pg.evaluate("window.EXBSign.anyVisa=function(){return Promise.resolve(%r)}" % VISA)
    pg.evaluate("""(b)=>{EXBS.set('exb_projects',[]);EXBS.set('exb_pieces',[{id:'PIE-v198',type:'cctp',project:'',no:'CCTP-001',date:'2026-11-18',status:'brouillon',title:'Essai V198',dest:'',entreprise:'',lot:'',objet:'',effet:'',model:'',sign:'dg',body:b}])}""", corps(21))
    pg.evaluate("()=>{EXBPIE.open();EXBPIE.edit('PIE-v198')}"); pg.wait_for_selector('#pBo', state='attached')
    pg.evaluate("()=>EXBPIE.print()"); pg.wait_for_selector('#exbPieOut', timeout=60000)
    data = pg.evaluate("""async()=>{const b=window.__exbLastPdf&&window.__exbLastPdf.blob;if(!b)return '';const buf=new Uint8Array(await b.arrayBuffer());let s='';for(let i=0;i<buf.length;i+=8192)s+=String.fromCharCode.apply(null,buf.subarray(i,i+8192));return btoa(s)}""")
    ok(bool(data), 'PDF direct produit')
    if data:
        f = os.path.join(tmp, 'b.pdf'); open(f, 'wb').write(base64.b64decode(data)); N = npages(f)
        out = subprocess.run(['pdfimages', '-list', f], capture_output=True, text=True).stdout
        pages_img = sorted(set(int(l.split()[0]) for l in out.splitlines()[2:] if len(l.split()) > 4))
        ok(N >= 2, 'PDF direct : %d pages' % N)
        # le PDF direct est une image de page : on vérifie visuellement la position via le rendu (page 1 contient la zone rouge, les autres non)
        subprocess.run(['pdftoppm', '-r', '30', '-png', f, os.path.join(tmp, 'd')], capture_output=True)
        try:
            from PIL import Image
            def rouge(i):
                fn = [z for z in os.listdir(tmp) if z.startswith('d-') and int(z[2:-4]) == i]
                im = Image.open(os.path.join(tmp, fn[0])).convert('RGB'); px = im.load(); c = 0
                for yy in range(im.height):
                    for xx in range(im.width):
                        r_, g_, b_ = px[xx, yy]
                        if r_ > 150 and g_ < 90 and b_ < 90: c += 1
                return c
            rc = [rouge(i) for i in range(1, N + 1)]
            ok(rc[0] > 20 and all(v == 0 for v in rc[1:]), 'PDF direct : visa sur la page 1 uniquement (pixels rouges par page : %s)' % rc)
        except ImportError:
            print('  --   Pillow absent : position du PDF direct non contrôlée')
    ok(not errs, 'aucune erreur JavaScript ' + str(errs[:2]))
    b.close()
shutil.rmtree(tmp, ignore_errors=True)
print('\n%d échec(s)' % len(fails)); raise SystemExit(1 if fails else 0)
