#!/bin/bash
# V214 — teste migration-v217-atelier-mise-en-page.sql sur un PostgreSQL local avec un schéma Supabase simulé (auth.uid(), auth.jwt(), rôles).
# Usage : bash tools/test-sql-lot3.sh   (nécessite PostgreSQL 16 : initdb/postgres, utilisateur « postgres »)
set -u
HERE="$(cd "$(dirname "$0")/.." && pwd)"; PGBIN=/usr/lib/postgresql/16/bin
D=$(mktemp -d /tmp/pgx.XXXXXX); chown postgres "$D"; PORT=54$((RANDOM%900+100))
run(){ su postgres -c "$*"; }
run "$PGBIN/initdb -D $D/data -A trust >/dev/null" || exit 2
run "$PGBIN/pg_ctl -D $D/data -o '-p $PORT -k $D' -l $D/log -w start >/dev/null" || { cat $D/log; exit 2; }
P="psql -h $D -p $PORT -U postgres -v ON_ERROR_STOP=1 -q -X"
trap 'run "$PGBIN/pg_ctl -D $D/data -m immediate stop >/dev/null"; rm -rf $D' EXIT
cat > $D/stub.sql <<'SQL'
create schema auth; grant usage on schema auth to anon, authenticated, service_role;
create table auth.users(id uuid primary key, email text);
create table auth.mfa_factors(user_id uuid, status text);
create schema storage; create table storage.buckets(id text primary key, name text, public boolean, file_size_limit bigint);
create table storage.objects(id uuid default gen_random_uuid(), bucket_id text, name text); alter table storage.objects enable row level security;
create function storage.foldername(n text) returns text[] language sql immutable as $$ select string_to_array(n,'/') $$;
grant usage on schema storage to anon, authenticated, service_role;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb,'{}'::jsonb) $$;
grant execute on function auth.uid(), auth.jwt() to anon, authenticated, service_role;
grant usage on schema public to anon, authenticated, service_role;
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
SQL
$P -d postgres -c "create role anon nologin" -c "create role authenticated nologin" -c "create role service_role nologin" -c "create database t" || exit 2
P="$P -d t"
echo "grant all on storage.objects to authenticated, service_role;" >> $D/stub.sql
$P -f $D/stub.sql || exit 2
for f in schema-entreprise migration-v66-roles migration-v99v-securite-licences migration-v90-enterprise migration-v99zn-synchro-modules ; do [ -f $HERE/supabase/$f.sql ] && { $P -f $HERE/supabase/$f.sql >/dev/null 2>$D/err || { echo "$f KO"; head -5 $D/err; exit 2; }; }; done
# v99zo : seules ses premières fonctions (licence_ecriture_ok, enregistrer) sont utiles ici ; la suite dépend d'autres lots (erreurs ignorées)
$P -v ON_ERROR_STOP=0 -f $HERE/supabase/migration-v99zo-securite-serveur.sql >/dev/null 2>&1
$P -f $HERE/supabase/migration-v217-atelier-mise-en-page.sql || { echo "v214 KO"; exit 2; }
$P -f $HERE/supabase/migration-v217-atelier-mise-en-page.sql || { echo "v214 non réexécutable"; exit 2; }
$P -f $HERE/tools/test-sql-atelier.sql
