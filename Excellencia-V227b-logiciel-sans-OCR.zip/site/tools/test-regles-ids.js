// Test des règles IDS (node tools/test-regles-ids.js) — fonctions pures sans DOM
var vm=require('vm'),fs=require('fs'),a=require('assert');
var w={document:{documentElement:null,getElementById:function(){return null}},addEventListener:function(){},console:console,setTimeout:setTimeout};w.window=w;w.globalThis=w;vm.createContext(w);
vm.runInContext(fs.readFileSync(__dirname+'/../exb-v209-ids.js','utf8'),w,{});
var X=w.EXBIDS,Q=[];function t(n,f){Q.push([n,f])}
var S=function(v){return{k:'simple',v:v}};
var els=[{id:'1',name:'M1',cls:'IfcWall',props:{Pset_WallCommon:{FireRating:'REI60',IsExternal:'T'}},mats:['Béton'],cl:[],level:'RDC'},
 {id:'2',name:'M2',cls:'IfcWall',props:{},mats:[],cl:[],level:''},
 {id:'3',name:'D1',cls:'IfcDoor',props:{},mats:[],cl:[],level:'RDC'}];
function spec(req,app,min){return{id:'s',name:'S',minOccurs:min==null?0:min,app:app||[{t:'entity',name:S('IFCWALL')}],req:req}}
t('matchValue : simple, nombre, énumération, motif, bornes',()=>{
 a.ok(X.matchValue(S('A'),'A'));a.ok(!X.matchValue(S('A'),'B'));a.ok(X.matchValue(S('2'),'2.0'));
 a.ok(X.matchValue({k:'enum',v:['A','B']},'B'));a.ok(!X.matchValue({k:'enum',v:['A']},'C'));
 a.ok(X.matchValue({k:'pattern',v:'REI\\d+'},'REI60'));a.ok(!X.matchValue({k:'pattern',v:'REI\\d+'},'EI30'));
 a.ok(X.matchValue({k:'bounds',minInclusive:1,maxExclusive:5},'1'));a.ok(!X.matchValue({k:'bounds',minInclusive:1,maxExclusive:5},'5'));a.ok(!X.matchValue({k:'bounds',minInclusive:1},'abc'))});
t('requis : un élément conforme, un non conforme avec motif',()=>{
 var r=X.verify(spec([{t:'property',card:'required',pset:S('Pset_WallCommon'),base:S('FireRating'),value:null}]),els);
 a.strictEqual(r.status,'non_conforme');a.strictEqual(r.n,2);a.strictEqual(r.pass,1);a.strictEqual(r.nfail,1);a.ok(/Manquant/.test(r.fails[0].why))});
t('tous conformes',()=>{var r=X.verify(spec([{t:'entity',card:'required',name:S('IFCWALL')}]),els);a.strictEqual(r.status,'conforme')});
t('interdit : présent à tort',()=>{var r=X.verify(spec([{t:'material',card:'prohibited',value:S('Béton')}]),els);a.strictEqual(r.status,'non_conforme');a.ok(/à tort/.test(r.fails[0].why))});
t('facultatif : jamais en échec',()=>{var r=X.verify(spec([{t:'material',card:'optional',value:S('Acier')}]),els);a.strictEqual(r.status,'conforme')});
t('niveau (partie de)',()=>{var r=X.verify(spec([{t:'partOf',card:'required',relation:'IfcRelContainedInSpatialStructure',entity:{name:S('IFCBUILDINGSTOREY')}}]),els);a.strictEqual(r.nfail,1)});
t('facette non lisible : non vérifiable, jamais conforme',()=>{var r=X.verify(spec([{t:'attribute',card:'required',name:S('Inconnu'),value:null}]),els.slice(0,1));a.strictEqual(r.status,'non_verifiable');a.ok(r.nv.length)});
t('aucun élément concerné : sans_element, ou non conforme si exigé',()=>{
 var ap=[{t:'entity',name:S('IFCBEAM')}];
 a.strictEqual(X.verify(spec([],ap,0),els).status,'sans_element');a.strictEqual(X.verify(spec([],ap,1),els).status,'non_conforme')});
t('verifyAll : synthèse par spécification',()=>{var R=X.verifyAll({specs:[spec([])]},els);a.strictEqual(R.examined,3);a.strictEqual(R.results.length,1)});
t('toXML : structure IDS 1.0 et échappement',()=>{var x=X.toXML({title:'A & <B>',specs:[spec([{t:'material',card:'required',value:S('a"b')}])]});a.ok(/<ids/.test(x)&&/specification/.test(x));a.ok(!/A & <B>/.test(x))});
t('parseXml : DOCTYPE/ENTITY refusés, fichier > 1 Mo refusé',()=>{
 a.throws(()=>X.parseXml('<!DOCTYPE x [<!ENTITY a "b">]><x/>'),/DOCTYPE/);a.throws(()=>X.parseXml('x'.repeat(1048577)),/volumineux/)});
t('elementsFromIFC : classe, nom, propriété, matériau, niveau',()=>{
 var ifc='DATA;\n#1=IFCBUILDINGSTOREY(\'g1\',$,\'RDC\',$,$,$,$,$,.ELEMENT.,0.);\n#2=IFCWALL(\'gw\',$,\'Mur A\',$,$,$,$,\'T1\',.STANDARD.);\n#3=IFCMATERIAL(\'Béton\');\n#4=IFCRELASSOCIATESMATERIAL(\'r\',$,$,$,(#2),#3);\n#5=IFCRELCONTAINEDINSPATIALSTRUCTURE(\'c\',$,$,$,(#2),#1);\nENDSEC;';
 var E=X.elementsFromIFC(ifc);E=E.elements||E;var m=E.filter(function(e){return /WALL/i.test(e.cls)})[0];a.ok(m,'mur lu');a.strictEqual(m.name,'Mur A');a.ok((m.mats||[]).indexOf('Béton')>=0);a.strictEqual(m.level,'RDC')});
t('csvText : injection de formule neutralisée',()=>{var c=X.csvText({date:'2026-11-22',examined:1,results:[{id:'s',name:'=CMD()',r:{status:'conforme',n:1,pass:1,nfail:0,fails:[],nv:[]}}]});a.ok(!/(^|;)=CMD/m.test(c))});

/* ===== V222 : types de données, « partie de », PredefinedType exact ===== */
var IFC4="ISO-10303-21;\nHEADER;\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n"
+"#1=IFCBUILDING('gb',$,'Bât A',$,$,$,$,$,.ELEMENT.,$,$,$);\n#2=IFCBUILDINGSTOREY('gs',$,'RDC',$,$,$,$,$,.ELEMENT.,0.);\n"
+"#3=IFCWALL('w1',$,'Mur ext',$,$,$,$,'T1',.SOLIDWALL.);\n"                      /* PredefinedType à l'indice 8 */
+"#4=IFCWALL('w2',$,'Mur perso',$,'MurRideau',$,$,'T2',.USERDEFINED.);\n"          /* USERDEFINED → ObjectType */
+"#5=IFCWALL('w3',$,'Mur sans type',$,$,$,$,'T3',$);\n#6=IFCWALLTYPE('tw',$,'Type mur',$,$,$,$,$,'MurPlein',.PARTITIONING.,$);\n#7=IFCRELDEFINESBYTYPE('rt',$,$,$,(#5),#6);\n"
+"#8=IFCDOOR('d1',$,'Porte',$,$,$,$,'T4',2.1,0.9,.DOOR.,.SWING.,$);\n"             /* PredefinedType à l'indice 10 */
+"#9=IFCSPACE('sp',$,'Salon',$,$,$,$,$,.ELEMENT.,.INTERNAL.,$);\n"                /* PredefinedType à l'indice 9 */
+"#10=IFCPROPERTYSINGLEVALUE('FireRating',$,IFCLABEL('REI60'),$);\n#11=IFCPROPERTYSINGLEVALUE('Epaisseur',$,IFCREAL(0.2),$);\n#12=IFCPROPERTYSINGLEVALUE('IsExternal',$,IFCBOOLEAN(.T.),$);\n#13=IFCPROPERTYSINGLEVALUE('Niveau',$,IFCINTEGER(3),$);\n"
+"#14=IFCPROPERTYSET('ps',$,'Pset_WallCommon',$,(#10,#11,#12,#13));\n#15=IFCRELDEFINESBYPROPERTIES('rp',$,$,$,(#3),#14);\n"
+"#16=IFCRELCONTAINEDINSPATIALSTRUCTURE('c1',$,$,$,(#3,#4,#5,#8),#2);\n#17=IFCRELAGGREGATES('a1',$,$,$,#1,(#2));\n#18=IFCRELCONTAINEDINSPATIALSTRUCTURE('c2',$,$,$,(#9),#2);\n"
+"#19=IFCOPENINGELEMENT('op',$,'Ouverture',$,$,$,$,$,.OPENING.);\n#20=IFCRELVOIDSELEMENT('v',$,$,$,#3,#19);\n#21=IFCRELFILLSELEMENT('f',$,$,$,#19,#8);\nENDSEC;\nEND-ISO-10303-21;";
var E4=X.elementsFromIFC(IFC4),by=function(n){return E4.filter(function(e){return e.name===n})[0]};
var P=function(pset,base,dt,v,card){return{t:'property',card:card||'required',pset:S(pset),base:S(base),dataType:dt,value:v||null}};
var W=[{t:'entity',name:S('IFCWALL')}];
t('PredefinedType : rang exact par classe (mur 8, porte 10, espace 9)',()=>{
 a.strictEqual(by('Mur ext').predef,'SOLIDWALL');a.strictEqual(by('Porte').predef,'DOOR');a.strictEqual(by('Salon').predef,'INTERNAL')});
t('PredefinedType : USERDEFINED → ObjectType ; absent → type de l\'objet',()=>{
 a.strictEqual(by('Mur perso').predef,'MurRideau');a.strictEqual(by('Mur perso').predefSrc,'ObjectType');
 a.strictEqual(by('Mur sans type').predef,'PARTITIONING');a.strictEqual(by('Mur sans type').predefSrc,'type')});
t('PredefinedType : facette entité filtre la bonne classe (énumération insensible à la casse, USERDEFINED sensible)',()=>{
 var f=function(pd){return X.verify(spec([],[{t:'entity',name:S('IFCWALL'),predef:S(pd)}]),E4).n};
 a.strictEqual(f('SOLIDWALL'),1);a.strictEqual(f('solidwall'),1);a.strictEqual(f('MurRideau'),1);a.strictEqual(f('murrideau'),0);a.strictEqual(f('PARTITIONING'),1);a.strictEqual(f('ELEMENT'),0)});
t('PredefinedType : exigence entité → motif « Type prédéfini incorrect »',()=>{
 var r=X.verify(spec([{t:'entity',card:'required',name:S('IFCWALL'),predef:S('SOLIDWALL')}]),E4);
 a.strictEqual(r.n,3);a.strictEqual(r.nfail,2);a.ok(/Type prédéfini incorrect/.test(r.fails[0].why)&&/lu /.test(r.fails[0].why))});
t('PredefinedType : IFC2X3 — un mur n\'a pas de PredefinedType, une dalle si',()=>{
 var T="FILE_SCHEMA(('IFC2X3'));\nDATA;\n#1=IFCWALL('w',$,'M',$,$,$,$,'T');\n#2=IFCSLAB('s',$,'D',$,$,$,$,'T',.FLOOR.);\nENDSEC;";
 var e=X.elementsFromIFC(T);a.strictEqual(e.filter(function(x){return x.name==='M'})[0].predef,'');a.strictEqual(e.filter(function(x){return x.name==='D'})[0].predef,'FLOOR')});
t('type de données : IFCLABEL, IFCREAL, IFCBOOLEAN, IFCINTEGER lus dans le fichier',()=>{
 var m=by('Mur ext');a.strictEqual(m.ptypes.Pset_WallCommon.FireRating,'IFCLABEL');a.strictEqual(m.ptypes.Pset_WallCommon.Epaisseur,'IFCREAL');
 a.strictEqual(m.ptypes.Pset_WallCommon.IsExternal,'IFCBOOLEAN');a.strictEqual(m.ptypes.Pset_WallCommon.Niveau,'IFCINTEGER');a.strictEqual(m.props.Pset_WallCommon.IsExternal,'TRUE')});
t('type de données : bon type = conforme',()=>{
 var el=E4.filter(function(e){return e.name==='Mur ext'});
 a.strictEqual(X.verify(spec([P('Pset_WallCommon','FireRating','IFCLABEL',S('REI60')),P('Pset_WallCommon','Epaisseur','IFCREAL',{k:'bounds',minInclusive:0.1}),P('Pset_WallCommon','Niveau','IFCINTEGER',S('3'))]),el).status,'conforme')});
t('type de données : mauvais type = non conforme avec motif précis (lu / attendu)',()=>{
 var el=E4.filter(function(e){return e.name==='Mur ext'});
 var r=X.verify(spec([P('Pset_WallCommon','Epaisseur','IFCLENGTHMEASURE',S('0.2'))]),el);
 a.strictEqual(r.status,'non_conforme');a.ok(/Type de données incorrect/.test(r.fails[0].why)&&/IFCREAL/.test(r.fails[0].why)&&/IFCLENGTHMEASURE/.test(r.fails[0].why),r.fails[0].why);
 r=X.verify(spec([P('Pset_WallCommon','Niveau','IFCREAL',null)]),el);a.strictEqual(r.status,'non_conforme')});
t('type de données : valeur fausse ≠ type faux ; propriété absente = Manquant',()=>{
 var el=E4.filter(function(e){return e.name==='Mur ext'});
 a.ok(/Valeur incorrecte/.test(X.verify(spec([P('Pset_WallCommon','FireRating','IFCLABEL',S('REI120'))]),el).fails[0].why));
 a.ok(/Manquant/.test(X.verify(spec([P('Pset_WallCommon','Absente','IFCLABEL',null)]),el).fails[0].why))});
t('type de données : booléens comparés en VRAI/FAUX (true, 1, .T.)',()=>{
 var el=E4.filter(function(e){return e.name==='Mur ext'});
 ['true','TRUE','1','T'].forEach(function(v){a.strictEqual(X.verify(spec([P('Pset_WallCommon','IsExternal','IFCBOOLEAN',S(v))]),el).status,'conforme',v)});
 a.strictEqual(X.verify(spec([P('Pset_WallCommon','IsExternal','IFCBOOLEAN',S('false'))]),el).status,'non_conforme')});
t('type de données : dataType vide ou éléments saisis à la main = non contrôlé (compatibilité)',()=>{
 var el=E4.filter(function(e){return e.name==='Mur ext'});a.strictEqual(X.verify(spec([P('Pset_WallCommon','Epaisseur','',S('0.2'))]),el).status,'conforme');
 a.strictEqual(X.verify(spec([P('Pset_WallCommon','FireRating','IFCREAL',S('REI60'))]),els.slice(0,1)).status,'conforme')});
t('type de données : interdit + type (présent à tort seulement si le type correspond)',()=>{
 var el=E4.filter(function(e){return e.name==='Mur ext'});
 a.strictEqual(X.verify(spec([P('Pset_WallCommon','Epaisseur','IFCREAL',null,'prohibited')]),el).status,'non_conforme');
 a.strictEqual(X.verify(spec([P('Pset_WallCommon','Epaisseur','IFCLABEL',null,'prohibited')]),el).status,'conforme')});
t('partie de : relations lues (contenu, agrégat, vide, remplit)',()=>{
 var m=by('Mur ext');a.strictEqual(m.parents.IFCRELCONTAINEDINSPATIALSTRUCTURE[0].cls,'IFCBUILDINGSTOREY');a.strictEqual(m.parents.IFCRELCONTAINEDINSPATIALSTRUCTURE[0].name,'RDC');
 a.strictEqual(by('Ouverture').parents.IFCRELVOIDSELEMENT[0].cls,'IFCWALL');a.strictEqual(by('Porte').parents.IFCRELFILLSELEMENT[0].cls,'IFCOPENINGELEMENT')});
var PO=function(rel,cls,pd,card){return{t:'partOf',card:card||'required',relation:rel,entity:{name:S(cls),predef:pd?S(pd):null}}};
t('partie de : classe parente réellement contrôlée (étage oui, bâtiment non)',()=>{
 a.strictEqual(X.verify(spec([PO('IFCRELCONTAINEDINSPATIALSTRUCTURE','IFCBUILDINGSTOREY')]),E4).status,'conforme');
 var r=X.verify(spec([PO('IFCRELCONTAINEDINSPATIALSTRUCTURE','IFCBUILDING')]),E4);a.strictEqual(r.status,'non_conforme');a.strictEqual(r.nfail,r.n);a.ok(/partie de IFCBUILDING/.test(r.fails[0].why))});
t('partie de : agrégat — un étage fait partie du bâtiment (IfcRelAggregates), un mur non',()=>{
 var storey=X.elementsFromIFC(IFC4.replace("#3=IFCWALL","#3=IFCBUILDINGELEMENTPROXY"));/* contrôle de non-régression du lecteur */a.ok(storey.length>0);
 var els2=E4.concat([{id:'#2',cls:'IFCBUILDINGSTOREY',name:'RDC',parents:{IFCRELAGGREGATES:[{cls:'IFCBUILDING',name:'Bât A',predef:''}]},props:{},mats:[],cl:[]}]);
 var r=X.verify({id:'s',name:'S',minOccurs:0,app:[{t:'entity',name:S('IFCBUILDINGSTOREY')}],req:[PO('IFCRELAGGREGATES','IFCBUILDING')]},els2);a.strictEqual(r.status,'conforme');
 a.strictEqual(X.verify(spec([PO('IFCRELAGGREGATES','IFCBUILDING')]),E4).status,'non_conforme')});
t('partie de : porte remplit une ouverture ; ouverture creusée dans un mur',()=>{
 a.strictEqual(X.verify(spec([PO('IFCRELFILLSELEMENT','IFCOPENINGELEMENT')],[{t:'entity',name:S('IFCDOOR')}]),E4).status,'conforme');
 a.strictEqual(X.verify(spec([PO('IFCRELVOIDSELEMENT','IFCWALL')],[{t:'entity',name:S('IFCOPENINGELEMENT')}]),E4).status,'conforme');
 a.strictEqual(X.verify(spec([PO('IFCRELVOIDSELEMENT','IFCSLAB')],[{t:'entity',name:S('IFCOPENINGELEMENT')}]),E4).status,'non_conforme')});
t('partie de : sans relation indiquée = n\'importe laquelle ; interdit ; relation inconnue = non vérifiable',()=>{
 a.strictEqual(X.verify(spec([PO('','IFCBUILDINGSTOREY')]),E4).status,'conforme');
 a.strictEqual(X.verify(spec([PO('IFCRELCONTAINEDINSPATIALSTRUCTURE','IFCBUILDINGSTOREY',null,'prohibited')]),E4).status,'non_conforme');
 var r=X.verify(spec([PO('IFCRELINVENTEE','IFCBUILDINGSTOREY')]),E4);a.strictEqual(r.status,'non_verifiable');a.ok(/relation/.test(r.nv.join(' ')))});
t('partie de : type prédéfini du parent (IFCSPACE : lecture du rang 9)',()=>{
 var m=E4.filter(function(e){return e.name==='Salon'});
 a.strictEqual(X.verify(spec([PO('IFCRELCONTAINEDINSPATIALSTRUCTURE','IFCBUILDINGSTOREY')],[{t:'entity',name:S('IFCSPACE')}]),m).status,'conforme')});
t('export : dataType en majuscules, relation IDS 1.0 en majuscules, type prédéfini du parent',()=>{
 var x=X.toXML({title:'T',specs:[{id:'s',name:'S',ifcVersion:'IFC4',minOccurs:0,app:[{t:'entity',name:S('IFCDOOR'),predef:S('DOOR')}],req:[P('Pset_DoorCommon','FireRating','ifclabel',null),PO('ifcrelfillselement','IFCOPENINGELEMENT','OPENING')]}]});
 a.ok(/dataType="IFCLABEL"/.test(x));a.ok(/relation="IFCRELFILLSELEMENT"/.test(x));a.ok(/<partOf[^>]*><entity><name><simpleValue>IFCOPENINGELEMENT<\/simpleValue><\/name><predefinedType><simpleValue>OPENING/.test(x));a.ok(/<entity><name>.*<\/name><predefinedType>/.test(x))});
t('validate : structure contrôlée avant export',()=>{
 var ok=X.validate({title:'T',specs:[spec([P('A','B','IFCLABEL',S('x')),PO('IFCRELAGGREGATES','IFCBUILDING')])]});a.strictEqual(ok.filter(function(x){return x.lvl==='erreur'}).length,0);
 var bad=X.validate({title:'T',specs:[{id:'s',name:'',ifcVersion:'IFC9',minOccurs:0,app:[],req:[{t:'property',card:'maybe',pset:null,base:S('b'),dataType:'IFCFOO',value:{k:'pattern',v:'(['}},PO('IFCRELX','IFCBUILDING')]}]}).map(function(x){return x.msg}).join('|');
 ['nom manquant','IFC9','applicabilité sans facette','cardinalité','obligatoires','motif invalide','non prévue'].forEach(function(k){a.ok(bad.indexOf(k)>=0,'attendu : '+k+' dans '+bad)})});
(async()=>{var ok=0;for(var q of Q){try{await q[1]();ok++}catch(e){console.log('ÉCHEC',q[0],'\n  ',e.message)}}console.log(ok+'/'+Q.length+' tests passés');process.exit(ok===Q.length?0:1)})();
