// Test des matériaux et finitions (node tools/test-materiaux.js)
var vm=require('vm'),fs=require('fs'),a=require('assert');
var w={document:{documentElement:null,getElementById:function(){return null}},addEventListener:function(){},console:console,setTimeout:setTimeout};w.window=w;w.globalThis=w;vm.createContext(w);
vm.runInContext(fs.readFileSync(__dirname+'/../exb-v209-materiaux.js','utf8'),w,{});
var X=w.EXBMAT,Q=[];function t(x,f){Q.push([x,f])}function near(x,y,e){a.ok(Math.abs(x-y)<=(e||1e-6),x+' ≠ '+y)}
var NOW='2026-11-22';
var mats=[{id:'m1',type:'mat',code:'C1',nom:'Carrelage',famille:'sol',unite:'m²',pu:20,perte:10,fiche_ref:'FT-1',fiche_fin:'2027-01-01',statut:'valide'},
 {id:'m2',type:'mat',code:'P1',nom:'Peinture',famille:'mur',unite:'m²',pu:'',perte:'',fiche_ref:'',fiche_url:'',statut:'a_valider'},
 {id:'m3',type:'mat',code:'O1',nom:'Ancien',famille:'sol',unite:'m²',pu:5,perte:0,fiche_ref:'x',fiche_fin:'2020-01-01',statut:'obsolete'},
 {id:'m4',type:'mat',code:'B1',nom:'Bordure',famille:'sol',unite:'ml',pu:3,perte:0,fiche_ref:'x',statut:'valide'}];
var rooms=[{id:'r1',nom:'Salon',niveau:'RDC',cible:30,proj:28},{id:'r2',nom:'Cuisine',niveau:'RDC',cible:12,proj:null}];
t('quantité surface × coef + perte, coût',()=>{var R=X.calcul(mats,[{id:'s1',poste:'sol',local:'r1',mat:'m1',mode:'surface',coef:1}],rooms,NOW),L=R.lignes[0];near(L.q,28);near(L.qt,30.8);near(L.cout,616);near(R.total,616);a.strictEqual(L.alertes.length,0)});
t('murs : coefficient 2,6',()=>{var L=X.calcul(mats,[{id:'s',poste:'mur',local:'r1',mat:'m1',coef:'2,6'}],rooms,NOW).lignes[0];near(L.q,72.8)});
t('perte de la ligne prioritaire sur celle du matériau',()=>{var L=X.calcul(mats,[{id:'s',local:'r1',mat:'m1',perte:0}],rooms,NOW).lignes[0];near(L.qt,28)});
t('surface cible utilisée si non dessiné, avec alerte',()=>{var L=X.calcul(mats,[{id:'s',local:'r2',mat:'m1'}],rooms,NOW).lignes[0];near(L.q,12);a.ok(L.alertes.some(x=>/non dessinée/.test(x)))});
t('quantité manuelle',()=>{var L=X.calcul(mats,[{id:'s',mode:'manuel',qte:10,zone:'Terrasse',mat:'m4'}],rooms,NOW).lignes[0];near(L.qt,10);near(L.cout,30);a.strictEqual(L.local,'Terrasse')});
t('sans prix : coût null, total partiel, alertes',()=>{var R=X.calcul(mats,[{id:'s',local:'r1',mat:'m2'},{id:'t',local:'r1',mat:'m1'}],rooms,NOW);a.strictEqual(R.lignes[0].cout,null);a.strictEqual(R.sansPrix,1);near(R.partSansPrix,50);near(R.total,R.lignes[1].cout);var al=R.lignes[0].alertes.join('|');a.ok(/non validé/.test(al)&&/Fiche technique absente/.test(al)&&/Prix unitaire/.test(al))});
t('obsolète et fiche périmée',()=>{var al=X.calcul(mats,[{id:'s',local:'r1',mat:'m3'}],rooms,NOW).lignes[0].alertes.join('|');a.ok(/OBSOL/.test(al)&&/périmée/.test(al))});
t('matériau supprimé / local introuvable / sans local',()=>{var R=X.calcul(mats,[{id:'a',local:'r1',mat:'zz'},{id:'b',local:'zz',mat:'m1'},{id:'c',mat:'m1'}],rooms,NOW);a.ok(R.lignes[0].alertes[0]&&/introuvable/.test(R.lignes[0].alertes[0]));a.ok(/Local introuvable/.test(R.lignes[1].alertes.join()));a.ok(/Aucun local/.test(R.lignes[2].alertes.join()))});
t('unité ml avec coefficient ≠ 1 : alerte',()=>{var al=X.calcul(mats,[{id:'s',local:'r1',mat:'m4',coef:0.5}],rooms,NOW).lignes[0].alertes.join('|');a.ok(/Coefficient appliqué/.test(al))});
t('totaux par poste, famille, local',()=>{var R=X.calcul(mats,[{id:'a',poste:'sol',local:'r1',mat:'m1'},{id:'b',poste:'sol',local:'r1',mat:'m4',mode:'manuel',qte:5},{id:'c',poste:'mur',local:'r2',mat:'m2'}],rooms,NOW);near(R.lots.sol.cout,616+15);a.strictEqual(R.lots.mur.sansPrix,1);near(R.familles.sol.cout,631);near(R.locaux.Salon.cout,631)});
t('aucune ligne : totaux nuls',()=>{var R=X.calcul(mats,[],rooms,NOW);a.strictEqual(R.total,0);a.strictEqual(R.partSansPrix,0)});
t('urlOk : refuse javascript: et data:',()=>{a.ok(X.urlOk(''));a.ok(X.urlOk('https://a.com/f.pdf'));a.ok(!X.urlOk('javascript:alert(1)'));a.ok(!X.urlOk('data:text/html,x'));a.ok(!X.urlOk('https://a.com/ "onmouseover=1'))});
t('CSV : aller-retour de la bibliothèque',()=>{var txt=X.csvBib(mats),p=X.parseBib(txt,[]);a.strictEqual(p.erreurs.length,0,p.erreurs.join());a.strictEqual(p.items.length,4);near(p.items[0].pu,20);a.strictEqual(p.items[0].statut,'valide');a.strictEqual(p.items[1].pu,'')});
t('CSV : injection de formule neutralisée à l’export et à la relecture',()=>{var m=[{id:'x',nom:'=HYPERLINK("http://x")',famille:'sol',unite:'m²',statut:'valide'}];var txt=X.csvBib(m);a.ok(txt.indexOf("'=HYPERLINK")>=0);var p=X.parseBib(txt,[]);a.strictEqual(p.items[0].nom,'=HYPERLINK("http://x")')});
t('CSV : guillemets, point-virgule et retour ligne dans une cellule',()=>{var m=[{id:'x',nom:'A;B "c"\nd',famille:'sol',unite:'m²',statut:'valide'}];var p=X.parseBib(X.csvBib(m),[]);a.strictEqual(p.items[0].nom,'A;B "c"\nd')});
t('import : mise à jour par code, nouveaux comptés',()=>{var p=X.parseBib('code;nom;pu\nC1;Carrelage 60x60;25\nZ9;Nouveau;1,5',mats);a.strictEqual(p.maj,1);a.strictEqual(p.nouveaux,1);a.strictEqual(p.items[0].__id,'m1');near(p.items[1].pu,1.5)});
t('import : erreurs ligne par ligne',()=>{var p=X.parseBib('nom;pu;perte;fiche_url;fiche_fin;code\nA;-3;;;;\nB;1;150;;;\nC;1;;javascript:x;;\nD;1;;;31/12/2026;\n;1;;;;\nE;1;;;;K\nF;1;;;;K',[]);a.strictEqual(p.items.length,1);a.strictEqual(p.erreurs.length,6)});
t('import : colonne nom absente, fichier vide',()=>{a.ok(X.parseBib('a;b\n1;2',[]).erreurs.length);a.ok(X.parseBib('',[]).erreurs.length)});
t('import : famille et statut par libellé, unité inconnue → m²',()=>{var p=X.parseBib('nom;famille;unite;statut\nA;Plafonds;toise;Validé',[]);a.strictEqual(p.items[0].famille,'plafond');a.strictEqual(p.items[0].statut,'valide');a.strictEqual(p.items[0].unite,'m²');a.strictEqual(p.erreurs.length,1)});
(async()=>{var ok=0;for(var q of Q){try{await q[1]();ok++}catch(e){console.log('ÉCHEC',q[0],'\n  ',e.message)}}console.log(ok+'/'+Q.length+' tests passés');process.exit(ok===Q.length?0:1)})();
