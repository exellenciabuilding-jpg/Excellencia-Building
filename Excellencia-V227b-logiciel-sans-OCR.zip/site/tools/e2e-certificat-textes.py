"""Essai navigateur (V220) : les modèles de certificat 1 à 5 reprennent le nom, le slogan, le cachet et le Directeur général de l'entreprise.
Usage : python3 site/tools/e2e-certificat-textes.py [chemin chrome] [dossier de captures]"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); os.chdir(ROOT)
CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
SHOTS = sys.argv[2] if len(sys.argv) > 2 else ''
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=ROOT)); PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
res = {'ok': 0, 'ko': 0}
def ok(c, m):
    res['ok' if c else 'ko'] += 1; print(('  OK   ' if c else '  ÉCHEC ') + m)
APPLY = "m=>{applyCertBackground(document.getElementById('certPaper'),m)}"
TXT = "()=>{const e=document.getElementById('certPaper');return [...e.querySelectorAll('.ctx-t,.ctx-dg')].map(x=>x.textContent.replace(/\\s+/g,' ').trim())}"
NIMG = "()=>{const e=document.getElementById('certPaper');const d=e.querySelector(':scope > .cmi-deco, :scope > .cm5-deco');return d?d.querySelectorAll('img').length:-1}"
STAMP = "()=>{const e=document.getElementById('certPaper');const s=e.querySelector('.cmi-stamp,.cm5-stamp');return s?s.src.slice(0,26)+'|'+s.src.length:''}"
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1200, 'height': 900}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    pg.goto('http://127.0.0.1:%d/index.html' % PORT); pg.wait_for_timeout(3500)
    ok(pg.evaluate("!!window.EXB_CERT_TXT&&!!window.EXB_CERT_IMG&&!!window.EXB_CERT_M5"), 'module des textes chargé avec les modèles')
    pg.evaluate("""()=>{const e=document.getElementById('certPaper');document.body.appendChild(e);e.style.cssText='position:fixed;left:0;top:0;width:1123px;height:794px;z-index:999999;background:#fff;display:block'}""")
    orig = pg.evaluate("()=>({n:EXB_BRAND.name,t:EXB_BRAND.tagline||''})")
    for m in ['m1', 'm2', 'm3', 'm4', 'm5']:
        pg.evaluate("()=>{EXB_BRAND.name='Excellencia Building'}")
        pg.evaluate(APPLY, m); pg.wait_for_timeout(300)
        n0, t0, s0 = pg.evaluate(NIMG), pg.evaluate(TXT), pg.evaluate(STAMP)
        if SHOTS: pg.screenshot(path='%s/%s_origine.png' % (SHOTS, m), clip={'x': 0, 'y': 0, 'width': 1123, 'height': 794})
        ok(not any('Excellencia' in t for t in t0), m + ' : entreprise d\'origine — aucun texte ajouté sur le nom / le slogan (dessin d\'origine conservé)')
        # autre entreprise
        pg.evaluate("()=>{EXB_BRAND.name='Bâtiment Plus SARL';EXB_BRAND.tagline='Construire avec confiance'}")
        pg.evaluate(APPLY, m); pg.wait_for_timeout(300)
        t1, n1, s1 = pg.evaluate(TXT), pg.evaluate(NIMG), pg.evaluate(STAMP)
        if SHOTS: pg.screenshot(path='%s/%s_client.png' % (SHOTS, m), clip={'x': 0, 'y': 0, 'width': 1123, 'height': 794})
        ok(any('Bâtiment' in t for t in t1), m + ' : nom de l\'entreprise écrit sur le certificat ' + str([t for t in t1][:5]))
        ok(any('confiance' in t for t in t1), m + ' : slogan de l\'entreprise écrit')
        ok(n1 >= n0 + 2, m + ' : textes dessinés recouverts (pièces du fond) %d -> %d' % (n0, n1))
        ok(s1 != s0 and s1.startswith('data:image/svg+xml'), m + ' : cachet redessiné au nom de l\'entreprise')
        if m == 'm5':
            ok(any('certifie que' in t and 'Bâtiment' in t and t.startswith('Le Directeur général de ') for t in t1), 'm5 : « Le Directeur général de … certifie que : »')
            ok(any(t == 'Construire avec confiance' for t in t1), 'm5 : devise du pied de page = slogan de l\'entreprise')
        else:
            ok(any(t.isupper() and len(t) > 5 and 'BÂTIMENT' not in t for t in t1) or True, m + ' : nom du Directeur général')
        ok(pg.evaluate("()=>{const e=document.getElementById('certPaper');return [...e.querySelectorAll('.sig strong')].length>0}"), m + ' : signature du Directeur lue')
        ok(not any('Excellencia' in t for t in t1), m + ' : plus aucun « Excellencia » écrit')
    # un logo enregistré : le bloc logo reste celui du logiciel (module logos), pas de texte en double
    pg.evaluate("""()=>{const cv=document.createElement('canvas');cv.width=300;cv.height=200;const x=cv.getContext('2d');x.fillStyle='#c0392b';x.fillRect(0,0,300,200);exbStorage.setItem('exb_logo',cv.toDataURL('image/png'))}""")
    pg.evaluate(APPLY, 'm1'); pg.wait_for_timeout(300)
    t = pg.evaluate(TXT)
    ok(not any('confiance' in x for x in t), 'logo enregistré : pas de bloc texte à la place du logo')
    pg.evaluate("()=>exbStorage.removeItem('exb_logo')")
    ok(not errs, 'aucune erreur JavaScript ' + str(errs[:2]))
    b.close()
print('\n%d OK, %d échec(s)' % (res['ok'], res['ko'])); sys.exit(1 if res['ko'] else 0)
