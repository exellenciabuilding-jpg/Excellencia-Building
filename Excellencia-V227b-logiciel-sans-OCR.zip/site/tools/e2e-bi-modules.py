#!/usr/bin/env python3
"""Test navigateur de la BI v7 : « Activité des modules » (RH, Stock, CRM, Workflow) et tableau de bord personnalisable, historique des soldes, PDF de direction. Usage, depuis le dossier du site : python3 tools/e2e-bi-modules.py"""
import http.server, threading, socketserver, os, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200])); a.on('dialog',lambda d:d.accept())
    exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    ok(a.evaluate("window.EXBBI&&EXBBI.version")>=7,'BI v7 chargée')
    a.evaluate("""()=>{const t=new Date().toISOString().slice(0,10);
      save('exb_hr',[{id:'h1',name:'A',approval_status:'APPROUVE',status:'Actif'},{id:'h2',name:'B',approval_status:'APPROUVE',status:'Congé'},{id:'h3',name:'C'}]);
      save('exb_stock',[{id:'s1',name:'Ciment',unit:'sac',qty:0,min:10},{id:'s2',name:'Fer',unit:'t',qty:50,min:5}]);
      save('exb_clients',[{id:'c1',name:'Client'}]);
      save('exb_quotes',[{id:'q1',no:'D1',client:'Client',date:t,currency:'USD',total:1500,lines:[]}]);
      save('exb_wf_dossiers',[{id:'w1',status:'en_cours',echeance:'2020-01-01'}]);}""")
    a.evaluate("show('exbbi')"); a.wait_for_timeout(900)
    t=a.inner_text('#bi_box')
    ok('Activité des modules' in t,'section « Activité des modules » affichée')
    ok('RH — effectif actif' in t and '1 en congé' in t and '1 fiche(s) à approuver' in t,'RH : compteurs agrégés (sans noms)')
    ok('Stock — articles à commander' in t and '1 en rupture' in t,'Stock : article à commander / rupture')
    print('   CRM>>',repr(t.split('CRM — devis de la période')[1][:90]) if 'CRM — devis' in t else 'absent')
    ok('CRM — devis de la période' in t and '1\u202f500' in t.replace('\u00a0','\u202f'),'CRM : devis et montant')
    ok('Workflow — dossiers en cours' in t and '1 en retard' in t,'Workflow : dossier en retard')
    ok('en rupture de stock' in t and 'dossier(s) de validation en retard' in t,'alertes de direction Stock et Workflow')
    ok('Ciment' not in t and 'Client' not in t.split('Activité des modules')[1][:900],'aucune donnée nominative dans la section')
    # personnalisation
    ok(a.locator('.bi-k').count()>0 or 'Aucune donnée financière' in t,'tuiles financières (ou message sans données)')
    a.click('#bi_cfg'); a.wait_for_timeout(300)
    ok(a.locator('.bi-show').count()>=8 and 'Indicateurs affichés' in a.inner_text('#bi_box'),'panneau Personnaliser ouvert')
    a.locator('.bi-show[data-id="ops"]').uncheck(); a.wait_for_timeout(400)
    ok('Activité des modules' not in a.inner_text('#bi_box').split('Indicateurs affichés')[1].split('Tout réafficher')[1],'section masquée après décochage')
    ok(a.evaluate("JSON.parse(localStorage.getItem('exb_bi_prefs')).hide.indexOf('ops')>=0"),'préférence enregistrée')
    a.evaluate("show('exbbi')"); a.wait_for_timeout(500)
    ok(a.evaluate("JSON.parse(localStorage.getItem('exb_bi_prefs')).hide.indexOf('ops')>=0")and 'Activité des modules' not in a.inner_text('#bi_box').split('Tout réafficher')[1],'masquage conservé au rechargement de l’écran')
    ok('en rupture de stock' in a.inner_text('#bi_box'),'les alertes restent visibles même section masquée')
    a.click('#bi_cfg_reset'); a.wait_for_timeout(400)
    ok('Activité des modules' in a.inner_text('#bi_box').split('Tout réafficher')[1],'« Tout réafficher » rétablit la section')
    # --- historique des soldes (v7) et PDF de direction
    mois=a.evaluate("new Date().toISOString().slice(0,7)")
    a.evaluate("""()=>{const t=new Date().toISOString().slice(0,10);
      save('exb_invoices',[{id:'F1',no:'F1',date:t,currency:'USD',lines:[{q:1,pu:800}],tva:0,payments:[]}]);
      const k='exb_bi_histo',v=JSON.stringify([{mois:'2020-01',date:'2020-01-31',kpi:{USD:{creances:100,echu:0,dettes:50,engages:0}},ops:{stockCmd:1}}]);
      if(window.exbStorage&&exbStorage.setItem)exbStorage.setItem(k,v);else localStorage.setItem(k,v)}""")
    a.evaluate("show('exbbi')"); a.wait_for_timeout(300); a.evaluate("EXBBI.render()"); a.wait_for_timeout(700)
    t2=a.inner_text('#bi_box')
    ok('Historique des soldes' in t2 and mois in t2,'historique affiché avec le mois courant')
    RD="JSON.parse((window.exbStorage&&exbStorage.getItem('exb_bi_histo'))||localStorage.getItem('exb_bi_histo')||'[]')"
    h=a.evaluate(RD)
    ok(len(h)==2 and h[0]['mois']=='2020-01' and h[1]['mois']==mois,'instantané du mois ajouté, ancien conservé')
    ok(h[1]['kpi'].get('USD',{}).get('creances')==800,'créances du mois = 800 (facture non payée)')
    ok(h[1]['ops'].get('stockCmd')==1 and h[1]['ops'].get('wfRetard')==1,'compteurs du mois enregistrés')
    ok(a.locator('#bi_box svg[aria-label="Créances et dettes par mois"]').count()==1,'courbe créances/dettes (2 mois)')
    a.evaluate("EXBBI.render()"); a.wait_for_timeout(500)
    ok(len(a.evaluate(RD))==2,'réouverture : pas de doublon pour le même mois')
    a.evaluate("window.EXBPrint={html:(t,d)=>{window.__pdf=d}}"); a.evaluate("EXBBI.render()"); a.wait_for_timeout(300)
    a.click('#bi_rep'); a.wait_for_timeout(600)
    pdf=a.evaluate("window.__pdf||''")
    ok('Activité des modules' in pdf and 'Articles à commander' in pdf,'PDF de direction : activité des modules')
    ok('Historique des soldes' in pdf and mois in pdf and '2020-01' in pdf,'PDF de direction : historique')
    ok('Ciment' not in pdf,'PDF : aucune donnée nominative')
    a.evaluate("EXBBI.render()"); a.wait_for_timeout(400)
    if a.locator('.bi-show').count()==0: a.click('#bi_cfg'); a.wait_for_timeout(300)
    a.locator('.bi-show[data-id="histo"]').uncheck(); a.wait_for_timeout(400)
    ok('Historique des soldes (à ce jour' not in a.inner_text('#bi_box'),'historique masquable')
    a.click('#bi_cfg_reset'); a.wait_for_timeout(300)
    ok(not ae,'0 erreur JavaScript '+(str(ae[:2]) if ae else ''))
    b.close()
print('ÉCHEC' if fails else 'OK'); raise SystemExit(1 if fails else 0)
