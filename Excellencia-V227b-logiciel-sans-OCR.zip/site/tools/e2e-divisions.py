#!/usr/bin/env python3
"""V168 — Menu en 5 divisions (cahier unifié V1.0 §1) : regroupement d'affichage, sans toucher aux modules.
Vérifie : 5 divisions dans le menu latéral ; chaque écran du menu d'origine est présent dans EXACTEMENT une division (rien de perdu, rien de dupliqué) ;
placement des écrans clés (BI/Workflow = Direction ; Archives/Scanner = Infrastructure ; RH/CRM/Finances/Stock = Gestion ; Certificats/TFL = Formation ; Plan Editor/Chantiers = Construction) ;
ouverture de chaque division et d'un écran de chaque division sans erreur JavaScript ; bouton Retour ; filtre des parcours ; catégories d'origine toujours accessibles.
Usage, depuis le dossier du site :  python3 tools/e2e-divisions.py"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
DV=['dv_dir','dv_con','dv_ges','dv_for','dv_inf']
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':1100,'height':800}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:160])); exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    a.evaluate("EXB_SHELL.setParcours('all')"); a.wait_for_timeout(200)
    t=a.evaluate("[...document.querySelectorAll('#exbSide .xd')].map(x=>x.lastChild.textContent.trim())")
    ok(t==['Direction & pilotage','Ingénierie et architecture','Gestion & finances','Formation & académie','Infrastructure numérique'],'menu latéral : les 5 divisions du §1, dans l\'ordre '+str(t))
    ok(a.evaluate("document.querySelectorAll('#exbSide .xs:not(.esp)').length")==11,'menu latéral : Accueil + les 10 catégories d\'origine restent présents')
    # complétude : chaque écran dans exactement une division
    r=a.evaluate("""()=>{const its=EXB_SHELL.items().filter(i=>!/^exbMsgrTile_/.test(i.key));const c={};its.forEach(i=>{const v=EXB_SHELL.divOf(i);c[v]=(c[v]||0)+1});
      const ds=EXB_SHELL.divisions().map(v=>v.k);return {n:its.length,bad:its.filter(i=>ds.indexOf(EXB_SHELL.divOf(i))<0).map(i=>i.key),c}}""")
    ok(r['n']>=100 and not r['bad'],f"{r['n']} écrans : tous rattachés à une division connue {r['bad']}")
    ok(all(r['c'].get(k,0)>0 for k in DV),'aucune division vide '+str(r['c']))
    # placements clés
    P={'exbbi':'dv_dir','exbwf':'dv_dir','administration':'dv_dir','exbar':'dv_inf','exbsc':'dv_inf','exbAuBtn':'dv_inf','cloudSync':'dv_inf','registry':'dv_inf',
       'rh':'dv_dir','portails':'dv_dir','clients':'dv_ges','finances':'dv_ges','comptabilite':'dv_ges','stock':'dv_ges','certs':'dv_for','tflSec':'dv_for','formations':'dv_for',
       'planEditeur':'dv_con','projets':'dv_con','metreDevis':'dv_con','bcs_pot':'dv_con'}
    got=a.evaluate("(P)=>{const o={};EXB_SHELL.items().forEach(i=>{if(i.key in P)o[i.key]=EXB_SHELL.divOf(i)});return o}",P)
    bad=[(k,got.get(k),v) for k,v in P.items() if got.get(k)!=v]
    ok(not bad,'placement des écrans clés (BI/Workflow, Archives/Scanner, RH/CRM/Finances/Stock, Certificats/TFL, Plans/Chantiers) '+str(bad))
    # ouverture de chaque division + d'un écran de chacune
    for k in DV:
        ae.clear(); a.evaluate("(k)=>EXB_SHELL.openDiv(k)",k); a.wait_for_timeout(250)
        n=a.evaluate("document.querySelectorAll('#exbHub .xg .c').length"); h=a.evaluate("document.querySelector('#exbHub h1').textContent.replace(/^\\S+\\s/,'')")
        vis=a.evaluate("getComputedStyle(document.getElementById('exbHub')).display")!='none'
        ok(n>0 and vis and not ae,f'division « {h.strip()} » : {n} écrans affichés, sans erreur JavaScript {ae[:1]}')
        on=a.evaluate("document.querySelector('#exbSide .xd.on')&&document.querySelector('#exbSide .xd.on').lastChild.textContent.trim()")
        ok(bool(on),'… division active surlignée dans le menu')
        ae.clear(); a.evaluate("document.querySelector('#exbHub .xg .c').click()"); a.wait_for_timeout(500)
        shown=a.evaluate("""()=>[...document.querySelectorAll('body *')].some(e=>e.id!=='app'&&e.id!=='exbHub'&&e.offsetParent!==null&&e.innerText&&e.innerText.length>40&&e.getBoundingClientRect().height>120)""")
        ok(shown and not ae,f'… ouvrir le premier écran de la division : page affichée, sans erreur {ae[:1]}')
    # tous les écrans de chaque division s'ouvrent (clic depuis la division)
    tot=0; bad=[]
    for k in DV:
        keys=a.evaluate("(k)=>EXB_SHELL.items().filter(i=>EXB_SHELL.divOf(i)===k&&!/^exbMsgrTile_/.test(i.key)).map(i=>i.key)",k)
        for key in keys:
            ae.clear(); a.evaluate("(k)=>EXB_SHELL.openDiv(k)",k); a.wait_for_timeout(60)
            a.evaluate("(key)=>EXB_SHELL.goKey(key)",key); a.wait_for_timeout(200); tot+=1
            if ae: bad.append((k,key,ae[0][:60]))
    ok(not bad,f'les {tot} écrans s\'ouvrent depuis leur division sans erreur JavaScript '+str(bad[:3]))
    # Retour
    a.evaluate("EXB_SHELL.openDiv('dv_for')"); a.wait_for_timeout(150); a.evaluate("EXB_SHELL.openDiv('dv_inf')"); a.wait_for_timeout(150)
    a.evaluate("EXB_SHELL.back()"); a.wait_for_timeout(250)
    ok('Formation' in a.evaluate("document.querySelector('#exbHub h1').textContent.replace(/^\\S+\\s/,'')"),'bouton Retour : revient à la division précédente')
    # catégories d'origine
    a.evaluate("EXB_SHELL.openCat('ent')"); a.wait_for_timeout(200)
    nEnt=a.evaluate("document.querySelectorAll('#exbHub .xg .c').length"); print('   (cat Entreprise : %d écrans)'%nEnt)
    ok(nEnt>=5,'catégorie d\'origine « Entreprise » : accessible et non vide (filtrée par division depuis V185c)')
    # parcours
    a.evaluate("EXB_SHELL.setParcours('btp')"); a.wait_for_timeout(200)
    t=a.evaluate("[...document.querySelectorAll('#exbSide .xd')].map(x=>x.lastChild.textContent.trim())")
    ok('Formation & académie' not in t and 'Ingénierie et architecture' in t,'parcours Construction : division Formation masquée')
    a.evaluate("EXB_SHELL.setParcours('for')"); a.wait_for_timeout(200)
    t=a.evaluate("[...document.querySelectorAll('#exbSide .xd')].map(x=>x.lastChild.textContent.trim())")
    ok('Formation & académie' in t and 'Ingénierie et architecture' not in t,'parcours Formation : division Construction masquée')
    a.evaluate("EXB_SHELL.setParcours('all')")
    ok(not ae,'aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('\nRésultat :',('tout passe' if not fails else f'{fails} échec(s)')); sys.exit(1 if fails else 0)
