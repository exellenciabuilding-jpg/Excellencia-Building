#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) du Workflow v1.3 : liens Factures / Caisse, notifications. Usage : python3 tools/e2e-workflow-v13.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); errs=[]
    a.on('pageerror',lambda e:errs.append(str(e)[:200])); a.on('dialog',lambda d:d.accept())
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    ok(a.evaluate("typeof EXBWF==='object'&&typeof EXBWFL==='object'&&typeof EXBWFS==='object'&&typeof EXBWFN==='object'"),'4 modules Workflow chargés')
    ok(a.evaluate("EXBWF.revision==='1.3'"),'Workflow v1.3')
    ok(a.evaluate("!EXBWFS.active()"),'sans compte connecté : mode local (serveur inactif)')
    a.evaluate("""()=>{
      localStorage.setItem('exb_wf_circuits',JSON.stringify([
        {id:'c1',nom:'Dépenses',type:'depense',actif:true,steps:[{id:'s0',nom:'Direction',mode:'sequentiel',approvers:[{name:'Marie'}]}]},
        {id:'c2',nom:'Factures',type:'facture',actif:true,steps:[{id:'s0',nom:'Direction',mode:'sequentiel',approvers:[{name:'Marie'}]}]}]));
      localStorage.setItem('exb_wf_liens',JSON.stringify({depense:{on:true,seuil:500,devise:'USD'},facture:{on:true,seuil:0,devise:'USD'}}));
      EXBWFL.install(); }""")
    ok(a.evaluate("!!window.exbSave.__wfl"),'exbSave enveloppé')
    # écran Workflow : panneau des liens avec les 2 nouvelles lignes
    a.evaluate("show('exbwf')"); a.wait_for_timeout(900)
    txt=a.evaluate("document.getElementById('wfl_panel')?document.getElementById('wfl_panel').innerText:''")
    ok('Factures' in txt and 'Dépenses de caisse' in txt,'panneau « Liens » : Factures et Dépenses de caisse présentes')
    # vraie saisie de caisse par l'écran
    n0=a.evaluate("exbCash.length")
    a.evaluate("show('finances')"); a.wait_for_timeout(300)
    a.evaluate("""()=>{document.getElementById('exb_cash_label').value='Achat ciment 50 sacs';document.getElementById('exb_cash_amount').value='800';
      document.getElementById('exb_cash_type').value='out';saveExbCash();}""")
    a.wait_for_timeout(500)
    ok(a.evaluate("exbCash.length")==n0,'dépense de 800 $ retenue : pas ajoutée à la caisse')
    ok(a.evaluate("EXBWF.list().filter(x=>x.ref&&x.ref.module==='depense').length")==1,'dossier de validation créé')
    a.evaluate("""()=>{document.getElementById('exb_cash_label').value='Colle';document.getElementById('exb_cash_amount').value='40';document.getElementById('exb_cash_type').value='out';saveExbCash();}""")
    a.wait_for_timeout(400)
    ok(a.evaluate("exbCash.some(x=>x.label==='Colle')"),'dépense de 40 $ enregistrée normalement')
    # décision de Marie → ajout à la caisse
    a.evaluate("()=>{const d=EXBWF.list().filter(x=>x.ref&&x.ref.module==='depense')[0];const r=EXBWF.decide(d.id,'approuver','',{name:'Marie'});window.__r=r.event;}")
    a.wait_for_timeout(1800)
    ok(a.evaluate("window.__r")=='valide','Marie valide')
    ok(a.evaluate("exbCash.some(x=>x.label==='Achat ciment 50 sacs'&&x.wf_ok)"),'après validation : écriture ajoutée à la caisse (marquée)')
    ok(a.evaluate("exbCash.filter(x=>x.label==='Achat ciment 50 sacs').length")==1,'une seule fois')
    ok(a.evaluate("JSON.parse(exbStorage.getItem('exb_cash')).some(x=>x.label==='Achat ciment 50 sacs')"),'et enregistrée dans le stockage')
    # facture : PDF bloqué
    a.evaluate("""()=>{exbProjects.push({id:'P1',name:'Villa Test',client:'ACME'});save('exb_projects',exbProjects);save('exb_invoices',[{id:'F1',no:'FAC-2026-001',client:'ACME',currency:'USD',tva:16,project_id:'P1',lines:[{d:'Dalle',q:2,pu:300}],payments:[]}]);
      window.__pdf=0;const o=EXBCH.pdf;}""")
    # le garde-fou de saisie (exb-guide) est devant EXBCH.pdf : on vérifie ici la porte du Workflow elle-même, sur la vraie facture enregistrée
    a.evaluate("()=>{window.exbConfirm=()=>Promise.resolve(true);window.__inf=EXBWFL.engine.invoiceInfo(load('exb_invoices',[])[0]);EXBWFL.install();}")
    ok(a.evaluate("!!EXBCH.__wflPdf"),'EXBCH.pdf enveloppé (drapeau sur l\'objet, malgré le garde-fou de saisie)')
    ok(a.evaluate("EXBWFL.gate('facture',window.__inf,'l\\u2019émission')")==False,'porte : facture non validée = refus')
    a.wait_for_timeout(600)
    ok(a.evaluate("EXBWF.list().filter(x=>x.ref&&x.ref.module==='facture').length")==1,'proposition de soumission acceptée : dossier facture créé')
    a.evaluate("()=>{const d=EXBWF.list().filter(x=>x.ref&&x.ref.module==='facture')[0];EXBWF.decide(d.id,'approuver','',{name:'Marie'})}")
    ok(a.evaluate("EXBWFL.gate('facture',window.__inf,'l\\u2019émission')")==True,'porte : facture validée = accord')
    a.evaluate("()=>{const i=load('exb_invoices',[]);i[0].lines[0].pu=999;save('exb_invoices',i);window.__inf2=EXBWFL.engine.invoiceInfo(i[0])}")
    ok(a.evaluate("EXBWFL.gate('facture',window.__inf2,'l\\u2019émission')")==False,'facture modifiée après validation : nouvel accord exigé')
    # notifications : badge dans le menu pour Marie (mode local : pas d'organisation → pas de badge, pas d'erreur)
    ok(a.evaluate("typeof EXBWFN.check()==='object'"),'notifications : passe sans erreur en mode local')
    ok(not errs,'aucune erreur JavaScript '+str(errs[:3]))
    b.close()
print('ÉCHECS : %d'%fails); raise SystemExit(1 if fails else 0)
