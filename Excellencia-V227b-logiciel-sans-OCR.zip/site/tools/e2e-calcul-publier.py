# Test navigateur V141p : le module « Calcul de structure » (dans un iframe du logiciel simulé) publie la note de calcul et le plan d'exécution
# au portail client (serveur Supabase simulé) : bouton « Publier », publication automatique après « PDF », republication sans doublon.
import json, os, threading, http.server, functools
from playwright.sync_api import sync_playwright
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8800),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ORG='11111111-2222-3333-4444-555555555555'
PARENT='''<!doctype html><meta charset=utf-8><body style="margin:0">
<script>
window.__calls=[];window.__notes=[];
window.EXBDB={org:()=>"%s"};
window.notify=(m,t)=>window.__notes.push(m);
window.EXBVerif={qrPng:u=>"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",vbase:()=>location.origin+"/"};
window.EXBPUB={util:{thumb:()=>Promise.resolve("")},print:(...a)=>window.__calls.push(["print",a[0]])};
let n={note:0,pex:0};const refs={};
window.exbSb={isIn:()=>true,api:async(p,o)=>{
 const body=o&&o.body;let rec={p,m:(o&&o.method)||"GET"};
 if(p.indexOf("/storage/v1/object/exb-calcul-publics/")===0&&rec.m==="POST"){rec.size=body.size;rec.type=body.type;window.__calls.push(rec);return {Key:"ok"}}
 if(p.indexOf("/rpc/calcul_public_publier")>0){const b=JSON.parse(body);rec.b=b;window.__calls.push(rec);
   const k=b.p_no;if(!refs[k]){n[b.p_genre]++;refs[k]={ref:(b.p_genre==="pex"?"EXE":"EXN")+"-2026-00"+n[b.p_genre],code:"ABCDE12345"}}
   return {ok:true,ref:refs[k].ref,code:refs[k].code}}
 if(p.indexOf("/storage/v1/object/list/")===0){return []}
 window.__calls.push(rec);return null}};
</script><script src="/exb-calc-publics.js"></script>
<iframe id="f" src="/calcul-structure/index.html" style="width:1200px;height:900px;border:0"></iframe>'''%ORG
res=[]
def check(n,c,i=''): res.append(bool(c)); print(('OK   ' if c else 'ÉCHEC'),n,i)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(accept_downloads=True,viewport={'width':1250,'height':950}); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('http://127.0.0.1:8800/__h.html',lambda r:r.fulfill(content_type='text/html',body=PARENT))
    pg.goto('http://127.0.0.1:8800/__h.html'); fr=pg.frame_locator('#f'); pg.wait_for_timeout(1500)
    fr.locator('button[data-mb="poutre"]').first.evaluate('e=>e.click()'); pg.wait_for_timeout(500)
    fr.locator('#go').click(); pg.wait_for_timeout(1500)
    fr.locator('#nb').click(); pg.wait_for_selector('#f',timeout=3000); fr.locator('#exf_pubgo').wait_for(timeout=8000)
    check('note : bouton « Publier — QR / lien client » présent dans l’aperçu',fr.locator('#exf_pubgo').count()==1)
    fr.locator('#exf_projet').fill('Villa R+1 Limete'); fr.locator('#exf_moa').fill('Jean Mukendi'); fr.locator('#exf_ing').fill('Ing. K. Tshala')
    fr.locator('#exf_pubgo').click(); pg.wait_for_selector('#exbCalcPub',state='attached',timeout=60000) if False else None
    pg.wait_for_function("document.getElementById('exbCalcPub')",timeout=90000)
    calls=pg.evaluate('window.__calls'); up=[c for c in calls if c.get('p','').startswith('/storage')]; rp=[c for c in calls if c.get('b')]
    check('note : PDF réel envoyé (type PDF, taille > 5 Ko) dans un dossier aléatoire',len(up)==1 and up[0]['type']=='application/pdf' and up[0]['size']>5000 and '/'+ORG+'/' in up[0]['p'] and up[0]['p'].endswith('/note-de-calcul.pdf'),str(up)[:200])
    check('note : RPC avec genre note, n° NCS-, projet, client, indice',len(rp)==1 and rp[0]['b']['p_genre']=='note' and rp[0]['b']['p_no'].startswith('NCS-') and rp[0]['b']['p_projet']=='Villa R+1 Limete' and rp[0]['b']['p_client']=='Jean Mukendi' and rp[0]['b']['p_etabli']=='Ing. K. Tshala' and rp[0]['b']['p_indice']=='A',str(rp[0]['b'] if rp else '')[:300])
    txt=pg.inner_text('#exbCalcPub')
    check('note : fenêtre QR avec référence EXN- et code',('EXN-2026-001' in txt) and 'ABCDE-12345' in txt)
    check('note : lien du portail /plan?ref=…&k=…',pg.evaluate("document.getElementById('cpLink').value")=='http://127.0.0.1:8800/plan?ref=EXN-2026-001&k=ABCDE12345')
    pg.evaluate("document.getElementById('exbCalcPub').remove()")
    # republier sans changement : pas de nouvel envoi
    fr.locator('#exf_pubgo').click(); pg.wait_for_function("document.getElementById('exbCalcPub')",timeout=30000)
    calls=pg.evaluate('window.__calls'); check('note : republication d’un PDF inchangé = aucun nouvel envoi',len([c for c in calls if c.get('b')])==1)
    pg.evaluate("document.getElementById('exbCalcPub').remove()")
    # changement d'indice => même référence, PDF remplacé
    fr.locator('#exf_ind').fill('B'); fr.locator('#exf_ind').dispatch_event('input'); pg.wait_for_timeout(300)
    fr.locator('#exf_pubgo').click(); pg.wait_for_function("document.getElementById('exbCalcPub')",timeout=90000)
    rp=[c for c in pg.evaluate('window.__calls') if c.get('b')]
    check('note : nouvel indice => même référence EXN-2026-001, PDF remplacé',len(rp)==2 and rp[1]['b']['p_no']==rp[0]['b']['p_no'] and rp[1]['b']['p_indice']=='B' and 'EXN-2026-001' in pg.inner_text('#exbCalcPub'))
    pg.evaluate("document.getElementById('exbCalcPub').remove()")
    # bouton PDF : le fichier est enregistré ET publié automatiquement
    before=len([c for c in pg.evaluate('window.__calls') if c.get('b')])
    fr.locator('#exf_ind').fill('C'); fr.locator('#exf_ind').dispatch_event('input'); pg.wait_for_timeout(300)
    with pg.expect_download(timeout=120000) as dl: fr.locator('#dpp').click()
    check('note : « 📄 PDF » télécharge un fichier PDF',dl.value.suggested_filename.endswith('.pdf'),dl.value.suggested_filename)
    pg.wait_for_function("window.__calls.filter(c=>c.b).length>%d"%before,timeout=30000)
    rp=[c for c in pg.evaluate('window.__calls') if c.get('b')]
    check('note : après « PDF », publication automatique (indice C)',rp[-1]['b']['p_indice']=='C' and rp[-1]['b']['p_genre']=='note')
    # plan d'exécution
    fr.locator('#dx').click(); pg.wait_for_timeout(500)
    fr.locator('#pb').click(); pg.wait_for_timeout(1500)
    # Hors licence, le cartouche d'origine du moteur affiche « EXCELLENCIA DÉMO » et n'est pas habillé (comportement existant) : on simule ici la version sous licence.
    fr.locator('body').evaluate("""()=>{document.querySelectorAll('#doc svg text').forEach(t=>{if(/^EXCELLENCIA D.MO$/.test(t.textContent))t.textContent='EXCELLENCIA'});
      if(!document.querySelector('#doc .exf'))EXBCALCDOC.decorate(document.getElementById('doc'),{P:()=>P,pi,nrm,save:()=>sv('xbp',P),toast})}""")
    fr.locator('#exf_pubgo').wait_for(timeout=15000)
    fr.locator('#exf_projet').fill('Villa R+1 Limete')
    fr.locator('#exf_pubgo').click(); pg.wait_for_function("document.getElementById('exbCalcPub')",timeout=120000)
    rp=[c for c in pg.evaluate('window.__calls') if c.get('b')]; up=[c for c in pg.evaluate('window.__calls') if c.get('p','').startswith('/storage')]
    check('plan d’exécution : RPC genre pex, n° PEX-',rp[-1]['b']['p_genre']=='pex' and rp[-1]['b']['p_no'].startswith('PEX-'),str(rp[-1]['b'])[:200])
    check('plan d’exécution : fichier plan-execution.pdf, référence EXE-',up[-1]['p'].endswith('/plan-execution.pdf') and 'EXE-2026-001' in pg.inner_text('#exbCalcPub'))
    pg.screenshot(path=os.environ.get('SHOT','/tmp/claude-0/-home-claude/685b6ae9-eb13-5e3e-8070-1881940941c8/scratchpad/calcul-publier.png'))
    check('pas d’erreur JS',not errs,str(errs[:2]))
    b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
