import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch()
    a=b.new_page(viewport={'width':1100,'height':900}); errs=[]
    a.on('pageerror',lambda e:errs.append(str(e)[:200]))
    a.on('dialog',lambda d:d.accept('x'))
    exbui_auto(a)
    a.route('**/rest/v1/**',lambda r:r.fulfill(status=200,content_type='application/json',body='[]'))
    a.route('**/auth/**',lambda r:r.fulfill(status=400,body='{}'))
    a.add_init_script("""setInterval(()=>{['exbLicLock','exbLock'].forEach(i=>{const d=document.getElementById(i);if(d)d.remove()})},200);
      Object.defineProperty(navigator,'clipboard',{value:{writeText:t=>{window.__clip=t;return Promise.resolve()}},configurable:true});""")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    ok(not errs,'aucune erreur JS '+str(errs[:2]))
    a.evaluate("()=>window.show('clients')"); a.wait_for_timeout(2500)
    ok(a.locator('#clients .exb-liens-profil').count()==1,'module Clients : encadré « Liens à envoyer aux clients »')
    ok(a.locator('#clients .exb-liens-profil input[readonly]').count()==7,'7 liens proposés (demande, 4 types, espace client, fiche)')
    vals=a.eval_on_selector_all('#clients .exb-liens-profil input[readonly]','e=>e.map(x=>x.value)')
    ok(any(v.endswith('demande.html') for v in vals) and any(v.endswith('demande.html?type=renovation') for v in vals) and any(v.endswith('espace-client.html') for v in vals),'adresses : demande.html, ?type=renovation, espace-client.html '+str([v.split('/')[-1] for v in vals]))
    ok(a.locator('#clients .exbInbox[data-t="btp"]').count()==1 and a.locator('#clients .exbInbox[data-t="cli"]').count()==1,'module Clients : boîte des demandes BTP en plus de la boîte Clients')
    ok(a.locator('#projets .exbInbox[data-t="btp"]').count()==1,'module Projets : boîte des demandes BTP conservée')
    a.locator('#clients .exb-liens-profil button[data-exbl="copy"]').first.click(); a.wait_for_timeout(300)
    ok(a.evaluate('()=>window.__clip||""').endswith('demande.html'),'bouton « Copier » : copie l’adresse de la demande')
    ok(not errs,'aucune erreur JS finale '+str(errs[:2]))
    b.close()
print('\nRésultat :','tout passe' if not fails else str(fails)+' échec(s)')
