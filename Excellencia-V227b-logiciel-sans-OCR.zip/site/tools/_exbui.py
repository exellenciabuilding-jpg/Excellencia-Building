"""Aide commune des tests navigateur (V167+).
Depuis la V144e, les confirm()/prompt()/alert() natifs sont remplacés par des boîtes intégrées à la page (EXBUI, classe .exbui-bg),
que page.on('dialog') ne voit plus. exbui_auto() répond à ces boîtes comme les tests le faisaient pour les boîtes natives :
saisie -> `prompt`, ou la prochaine valeur de window.__exbuiNext si le test en a empilé (puis OK), confirmation -> OK, alerte -> OK. Les messages sont gardés dans window.__exbuiLog."""
def exbui_script(prompt='TestLocal#2026'):
    """Texte du script d'initialisation (pour l'API asynchrone : await page.add_init_script(exbui_script()))."""
    return """(()=>{window.__exbuiLog=window.__exbuiLog||[];const P=%r;
      function rep(bg){ if(bg.__done)return; bg.__done=true;
        setTimeout(()=>{ const m=bg.querySelector('.exbui-msg'); window.__exbuiLog.push(m?m.textContent.slice(0,120):'');
          const i=bg.querySelector('input.exbui-in'); if(i){ i.value=(window.__exbuiNext&&window.__exbuiNext.length)?window.__exbuiNext.shift():P; i.dispatchEvent(new Event('input',{bubbles:true})); }
          const ok=bg.querySelector('.exbui-ok'); if(ok) ok.click(); },30); }
      new MutationObserver(ms=>{ for(const m of ms) for(const n of m.addedNodes) if(n.nodeType===1){
        if(n.classList&&n.classList.contains('exbui-bg')) rep(n); else if(n.querySelectorAll) n.querySelectorAll('.exbui-bg').forEach(rep); } })
        .observe(document,{childList:true,subtree:true});
    })();""" % prompt

def exbui_auto(page, prompt='TestLocal#2026'):
    page.add_init_script(exbui_script(prompt))
