# Test navigateur V141p : portail public plan.html avec une NOTE DE CALCUL (EXN-…) et un PLAN D'EXÉCUTION (EXE-…), serveur simulé.
import json, os, threading, http.server, functools
from playwright.sync_api import sync_playwright
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8797),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ORG='11111111-2222-3333-4444-555555555555'; TOK='b'*32
def doc(genre,ref,no,nom,fic):
    return {'genre':genre,'ref':ref,'titre':'Poutre P1','date':'2026-11-09','doc_no':no,'projet':'Villa R+1 Limete','client':'Jean Mukendi','etabli_par':'Ing. K. Tshala','indice':'B','norme':'Eurocode 2','statut':'Validé',
     'apercu':None,'docs':[{'nom':nom,'fichier':f'{ORG}/{TOK}/{fic}','format':'PDF','taille':'210 Ko','kind':genre},{'nom':'Piégé','fichier':'../../etc/passwd','format':'PDF','taille':'','kind':genre}]}
DB={'EXN-2026-001':doc('note','EXN-2026-001','NCS-2026-001','Note de calcul N° NCS-2026-001','note-de-calcul.pdf'),'EXE-2026-001':doc('pex','EXE-2026-001','PEX-2026-001','Plan d’exécution N° PEX-2026-001','plan-execution.pdf')}
rpcs=[]; dl=[]
def rpc_c(route):
    b=json.loads(route.request.post_data or '{}'); rpcs.append(('calcul',b))
    d=DB.get(b.get('p_ref')); route.fulfill(status=200,content_type='application/json',body=json.dumps(d if d and b.get('p_code')=='A1B2C3D4E5' else None))
def rpc_o(name): return lambda route:(rpcs.append((name,{})),route.fulfill(status=200,content_type='application/json',body='null'))
def pdf(route): dl.append(route.request.url); route.fulfill(status=200,headers={'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="x.pdf"','Access-Control-Allow-Origin':'*'},body=b'%PDF-1.4\n%%EOF')
res=[]
def check(n,c,i=''): res.append(bool(c)); print(('OK   ' if c else 'ÉCHEC'),n,i)
def newpage(b,w=1200):
    pg=b.new_page(viewport={'width':w,'height':900},accept_downloads=True); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"sb_publishable_test"}'))
    pg.route('http://x.test/rest/v1/rpc/calcul_public_get',rpc_c); pg.route('http://x.test/rest/v1/rpc/devis_public_get',rpc_o('devis')); pg.route('http://x.test/rest/v1/rpc/plan_public_get',rpc_o('plan')); pg.route('http://x.test/storage/**',pdf)
    return pg,errs
T=lambda pg,i:pg.inner_text(i)
with sync_playwright() as p:
    b=p.chromium.launch()
    for ref,genre,btn,bucketfile,lab in [('EXN-2026-001','note','Télécharger la Note de calcul','note-de-calcul.pdf','votre note de calcul'),('EXE-2026-001','pex','Télécharger le Plan d’exécution','plan-execution.pdf','votre plan d’exécution')]:
        pg,errs=newpage(b); pg.goto('http://127.0.0.1:8797/plan.html?ref=%s&k=A1B2C-3D4E5'%ref); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
        check(ref+' : fonction calcul_public_get appelée',rpcs[-1][0]=='calcul' and rpcs[-1][1]=={'p_ref':ref,'p_code':'A1B2C3D4E5'})
        check(ref+' : titre, référence, date',T(pg,'#title')=='Villa R+1 Limete' and T(pg,'#ref')==ref and T(pg,'#date')=='09/11/2026')
        lab_=pg.evaluate("[...document.querySelectorAll('.details .item')].filter(e=>!e.hidden).map(e=>e.querySelector('span').textContent+'='+e.querySelector('b').textContent)")
        check(ref+' : champs adaptés (établi par, maître d’ouvrage, norme, statut, indice)',all(any(x==k for x in lab_) for k in ['Établi par=Ing. K. Tshala','Maître d’ouvrage=Jean Mukendi','Norme de calcul=Eurocode 2','Statut=Validé','Indice de révision=B']),str(lab_))
        check(ref+' : un seul document (chemin piégé ignoré), bouton « '+btn+' »',pg.locator('#docList .dlbig').count()==1 and btn in T(pg,'#docList'))
        check(ref+' : message de succès',lab in T(pg,'#status'))
        with pg.expect_download(timeout=8000) as d: pg.click('#docList .dlbig')
        check(ref+' : PDF servi depuis exb-calcul-publics',dl and '/object/public/exb-calcul-publics/'+ORG+'/'+TOK+'/'+bucketfile in dl[-1],dl[-1][-70:])
        check(ref+' : pas d’erreur JS',not errs,str(errs[:2])); pg.close()
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8797/plan.html?ref=EXN-2026-001&k=ZZZZZZZZZZ'); pg.wait_for_selector('#empty:not([hidden])',timeout=8000)
    check('mauvais code : rien d’affiché',pg.locator('#projectCard').is_hidden()); pg.close()
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8797/plan.html'); pg.fill('#inRef','exe-2026-001'); pg.fill('#inCode','a1b2c-3d4e5'); pg.click('#inBtn'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('saisie manuelle d’un plan d’exécution',T(pg,'#ref')=='EXE-2026-001'); pg.close()
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8797/plan.html?ref=EXB-2026-001&k=A1B2C3D4E5'); pg.wait_for_timeout(1000)
    check('plan EXB- : toujours plan_public_get',rpcs[-1][0]=='plan'); pg.close()
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8797/plan.html?ref=EXD-2026-001&k=A1B2C3D4E5'); pg.wait_for_timeout(1000)
    check('devis EXD- : toujours devis_public_get',rpcs[-1][0]=='devis'); pg.close()
    pg,errs=newpage(b,390); pg.goto('http://127.0.0.1:8797/plan.html?ref=EXN-2026-001&k=A1B2C3D4E5'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('mobile 390 px : pas de défilement horizontal',pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
    pg.screenshot(path=os.environ.get('SHOT','/tmp/claude-0/-home-claude/685b6ae9-eb13-5e3e-8070-1881940941c8/scratchpad/portail-note-mobile.png'),full_page=True); pg.close()
    b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
