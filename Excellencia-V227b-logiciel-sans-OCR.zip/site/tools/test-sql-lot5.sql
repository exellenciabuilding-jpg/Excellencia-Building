\set ON_ERROR_STOP 0
\pset tuples_only on
create temp table r(t text, ok boolean);
insert into auth.users values ('00000000-0000-0000-0000-00000000000a','admin@t.com'),('00000000-0000-0000-0000-00000000000f','form@t.com'),('00000000-0000-0000-0000-00000000000e','archi@t.com');
insert into organisations(id,nom) values ('11111111-1111-1111-1111-111111111111','Org test');
\set org '''11111111-1111-1111-1111-111111111111'''
insert into membres(org_id,user_id,nom,role,fonction) values (:org,'00000000-0000-0000-0000-00000000000a','Admin','admin','polyvalent');
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000a'; set request.jwt.claims='{"aal":"aal1"}';
select (equipe_inviter(:org,'form@t.com','Form','editeur','formateur')::jsonb->>'statut') as i1 \gset
select (equipe_inviter(:org,'archi@t.com','Archi','editeur','architecte')::jsonb->>'statut') as i2 \gset
reset role;
insert into r select 'equipe_inviter accepte « formateur »', :'i1'='ajoute' and exists(select 1 from membres where user_id='00000000-0000-0000-0000-00000000000f' and fonction='formateur');
insert into r select 'la fonction « architecte » du lot 4 reste acceptée', :'i2'='ajoute';
do $$ declare e text; begin
  set local role authenticated; perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-00000000000a',true);
  begin perform equipe_inviter('11111111-1111-1111-1111-111111111111','z@t.com','Z','editeur','astronaute'); e:='aucune erreur';
  exception when others then e:=sqlerrm; end;
  reset role; insert into r values('une fonction inconnue reste refusée ('||e||')', e='fonction invalide'); end $$;
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000f';
select peut(:org,'communication',true) as d1, peut(:org,'documents',false) as d2, peut(:org,'documents',true) as d3,
       peut(:org,'caisse',false) as d4, peut(:org,'factures',false) as d5, peut(:org,'personnel',false) as d6, peut(:org,'clients',false) as d7, peut(:org,'projets',false) as d8 \gset
reset role;
insert into r select 'le formateur écrit les messages et lit les documents', :'d1'='t' and :'d2'='t';
insert into r select 'le formateur ne modifie pas les documents', :'d3'='f';
insert into r select 'le formateur n''a ni caisse, ni factures, ni personnel, ni clients, ni projets', :'d4'='f' and :'d5'='f' and :'d6'='f' and :'d7'='f' and :'d8'='f';
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000f'; set request.jwt.claims='{"aal":"aal2"}';
select (calcul_valider(:org,'P1','Poutre','NC-001','A','digest-aaaa','valide','ok',true)::jsonb->>'refus') as v \gset
reset role;
insert into r select 'un formateur ne peut pas valider un calcul ('||:'v'||')', :'v'='ingenieur_habilite_requis';
\echo ----- RÉSULTAT -----
select case when ok then 'OK   ' else 'FAIL ' end || t from r;
select 'Résultat : '||count(*) filter (where ok)||' OK, '||count(*) filter (where not ok)||' échec(s)' from r;
