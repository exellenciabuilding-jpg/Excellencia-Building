#!/usr/bin/env python3
"""Parcours bout en bout « Devis ≠ paiement » (cahier unifié §4) : un devis, même accepté / converti en contrat signé, ne crée AUCUN paiement ni encaissement ;
seul un paiement enregistré (objet distinct) compte, une seule fois, et il survit aux changements du devis. Usage, depuis le dossier du site : python3 tools/e2e-devis-paiement.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
SNAP="""()=>{const L=EXBLIEN.ledger(),rd=EXBLIEN.rd,K=EXBLIEN.keys,inv=rd(K.invoices),S=EXBLIEN.situation({}).total,usd=S.USD||{devis:0,facture:0,verse:0,solde:0,aFacturer:0};
 const bi=EXBBI.compute(EXBBI.gather(),{range:{a:'0000-00-00',b:'9999-12-31',lab:'t'}}).kpi.USD||{encaisse:0,creances:0,facture:0};
 return{ledger:L.rows.length,cash:rd(K.cash).length,v93:rd(K.v93).length,payInv:inv.reduce((a,i)=>a+(i.payments||[]).length,0),sit:usd,bi:{enc:bi.encaisse,cre:bi.creances,fac:bi.facture}}}"""
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200])); a.on('dialog',lambda d:d.accept())
    exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    t=a.evaluate("new Date().toISOString().slice(0,10)")
    a.evaluate("""(t)=>{const setL=(arr,k,items)=>{arr.splice(0,arr.length,...items);save(k,arr)};window.__setL=setL;
      setL(exbClients,'exb_clients',[{id:'c1',name:'Client Test'}]);setL(exbProjects,'exb_projects',[{id:'p1',name:'Chantier A',client_id:'c1'}]);
      setL(exbQuotes,'exb_quotes',[{id:'q1',no:'D-1',client:'Client Test',client_id:'c1',project_id:'p1',date:t,currency:'USD',total:1000,status:'accepté',lines:[{designation:'Travaux',qty:1,pu:1000}]}]);
      save('exb_invoices',[]);setL(exbCash,'exb_cash',[]);save('exb_v93_payments',[]);}""",t)
    k0=a.evaluate("JSON.stringify(EXBLIEN.rd('exb_quotes').map(q=>[q.id,q.no,q.total,q.status,q.currency,q.lines]))")
    s0=a.evaluate(SNAP)
    ok(s0['sit']['devis']==1000 and s0['sit']['verse']==0 and s0['sit']['aFacturer']==1000,'A. devis accepté : devis 1000, versé 0, à facturer 1000')
    ok(s0['ledger']==0 and s0['cash']==0 and s0['v93']==0 and s0['bi']['enc']==0,'A. aucun paiement / encaissement / BI encaissé à 0')
    # B. conversion en contrat signé
    r=a.evaluate("(()=>{const T=EXBCRMPLUS._t;const r=T.toContract?T.toContract('q1',{}):null;return r&&r.contract?r.contract.id:null})()")
    if r:
        a.evaluate("(id)=>EXBCRMPLUS._t.setContractStatus(id,'signé')",r)
        s1=a.evaluate(SNAP); ok(s1['ledger']==0 and s1['cash']==0 and s1['v93']==0 and s1['bi']['enc']==0,'B. contrat signé : toujours aucun paiement')
    else:
        print('  --   B. conversion en contrat non exposée au test (ignorée)')
    # C. facture issue du devis
    a.evaluate("""(t)=>{save('exb_invoices',[{id:'i1',no:'F-1',client:'Client Test',client_id:'c1',project_id:'p1',quote_id:'q1',date:t,due:t,currency:'USD',tva:0,lines:[{q:1,pu:1000}],payments:[]}])}""",t)
    s2=a.evaluate(SNAP)
    ok(s2['sit']['facture']==1000 and s2['sit']['verse']==0 and s2['sit']['solde']==1000,'C. facture : facturé 1000, versé 0, solde 1000')
    ok(s2['bi']['cre']==1000 and s2['bi']['enc']==0 and s2['ledger']==0,'C. BI : créances 1000, encaissé 0')
    # D. paiement enregistré
    r=a.evaluate("EXBLIEN.recordPayment({invoice_id:'i1',amount:400,method:'cash',idem:'K1'})")
    s3=a.evaluate(SNAP)
    ok(r['duplicate']==False and s3['ledger']==1 and s3['cash']==1 and s3['payInv']==1,'D. un paiement : 1 ligne registre, 1 caisse, 1 sur la facture (pas de doublon)')
    ok(s3['sit']['verse']==400 and s3['sit']['solde']==600 and s3['bi']['enc']==400 and s3['bi']['cre']==600,'D. versé 400, solde 600 ; BI encaissé 400, créances 600')
    KEEP="JSON.stringify(EXBLIEN.rd('exb_quotes').map(q=>[q.id,q.no,q.total,q.status,q.currency,q.lines]))"
    ok(a.evaluate(KEEP)==k0,'D. le devis (total, statut, lignes, devise) n’est pas modifié par le paiement')
    # E. idempotence et surpaiement
    r=a.evaluate("EXBLIEN.recordPayment({invoice_id:'i1',amount:400,method:'cash',idem:'K1'})")
    s4=a.evaluate(SNAP); ok(r['duplicate']==True and s4['ledger']==1 and s4['bi']['enc']==400,'E. même clé d’idempotence : aucun doublon')
    err=a.evaluate("(()=>{try{EXBLIEN.recordPayment({invoice_id:'i1',amount:700,method:'cash'});return ''}catch(e){return e.message}})()")
    s5=a.evaluate(SNAP); ok('dépasse' in err and s5['ledger']==1,'E. surpaiement refusé, rien d’écrit')
    err=a.evaluate("(()=>{try{EXBLIEN.recordPayment({amount:50,method:'cash'});return ''}catch(e){return e.message}})()")
    ok('client ou à un chantier' in err,'E. paiement sans client ni chantier refusé')
    # F. V93 en attente ne compte pas ; confirmé compte une fois
    a.evaluate("""()=>{const P=EXB_PAYMENTS;P.refresh&&0;const r=P.recordPayment({method:'cash',amount:100,direction:'in',client_id:'c1',project_id:'p1',currency:'USD'});window.__v=r.id}""")
    s6=a.evaluate(SNAP); ok(s6['v93']==1 and s6['ledger']==1 and s6['bi']['enc']==400,'F. paiement V93 « en attente » : non compté')
    a.evaluate("EXB_PAYMENTS.confirmPayment(window.__v)")
    s7=a.evaluate(SNAP); ok(s7['ledger']==2 and s7['bi']['enc']==500,'F. paiement V93 confirmé : compté une seule fois (500)')
    # G. modifier / supprimer le devis ne touche pas aux paiements
    a.evaluate("()=>{exbQuotes[0].total=5000;exbQuotes[0].status='refusé';save('exb_quotes',exbQuotes)}")
    s8=a.evaluate(SNAP); ok(s8['ledger']==2 and s8['bi']['enc']==500 and s8['payInv']==1,'G. devis modifié / refusé : paiements inchangés')
    a.evaluate("()=>{__setL(exbQuotes,'exb_quotes',[])}")
    s9=a.evaluate(SNAP); ok(s9['ledger']==2 and s9['bi']['enc']==500 and s9['sit']['verse']==500,'G. devis supprimé : paiements conservés')
    ok(ae==[], '0 erreur JavaScript '+' '.join(ae))
    b.close()
srv.shutdown(); print('OK' if not fails else 'ÉCHEC'); _s.exit(1 if fails else 0)
