/* Excellencia Building — WORKFLOW v1 (cahier des charges ERP, module 07).
 * Circuits de validation configurables par type de dossier : étapes séquentielles, parallèles (tous) ou « un seul suffit »,
 * étapes conditionnées par un seuil de montant, approbation, refus motivé, demande de correction + nouvelle soumission,
 * délégations datées, échéances et rappels, historique horodaté (ajout seul) relié au journal d'audit chaîné du noyau CORE.
 *
 * Données (3 clés, synchronisées comme les autres clés exb_* du compte) :
 *   exb_wf_circuits  : modèles de circuits          exb_wf_dossiers : dossiers soumis (avec une COPIE du circuit au moment de la soumission)
 *   exb_wf_deleg     : délégations
 * Le moteur (EXBWF.engine) est PUR : aucune lecture de l'écran ni du stockage, testable seul (tools/test-workflow.js).
 * Les autres modules soumettent un dossier avec EXBWF.submit({type, titre, montant, devise, ref:{module,id}}) ; ils peuvent écouter le bus
 * EXBCore (workflow.soumis / .decision / .valide / .refuse / .retourne / .annule). Ce lot ne modifie AUCUN autre module.
 * Limites assumées : identité = nom OU fonction (mode local : non vérifiée, signalée dans l'historique) ; synchronisation par clé entière
 * (deux décisions simultanées sur deux appareils : la dernière écriture gagne, SAUF en mode serveur v1.3 : exb-workflow-serveur.js + migration-v149) ; notifications à l'approbateur : exb-workflow-notif.js (application ouverte).
 * Pour retirer : supprimer la balise <script src="exb-workflow.js"> de index.html (les données restent). */
(function (w, d) {
  'use strict';
  if (w.EXBWF) return;
  var CK = 'exb_wf_circuits', DK = 'exb_wf_dossiers', LK = 'exb_wf_deleg', PK = 'exb_wf_prefs';

  /* ============================ MOTEUR PUR ============================ */
  var TYPES = { depense: 'Dépense', achat: 'Achat / bon de commande', devis: 'Devis', facture: 'Facture', conge: 'Congé / absence', certificat: 'Certificat', document: 'Document', autre: 'Autre' };
  var MODES = { sequentiel: 'À la suite (chacun son tour)', parallele: 'En parallèle (tous doivent approuver)', un_seul: 'En parallèle (un seul suffit)' };
  var STAT = { en_cours: 'En cours', valide: 'Validé', refuse: 'Refusé', retourne: 'À corriger', annule: 'Annulé' };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function num(x) { x = +x; return isFinite(x) ? x : 0; }
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim(); }
  function day(t) { return String(t || '').slice(0, 10); }
  function addDays(iso, n) { var x = new Date(day(iso) + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + Math.round(n)); return x.toISOString().slice(0, 10); }
  function diffDays(a, b) { return Math.round((Date.parse(day(a) + 'T00:00:00Z') - Date.parse(day(b) + 'T00:00:00Z')) / 864e5); }
  function akey(a) { return norm(a && a.name) + '|' + norm(a && a.role); }
  function alabel(a) { return (a && (a.name || a.role)) || '?'; }
  function matches(actor, ap) {
    if (!actor || !ap) return false;
    if (ap.name && norm(actor.name) && norm(actor.name) === norm(ap.name)) return true;
    if (!ap.role) return false;
    var r = norm(ap.role);
    if (actor.role && norm(actor.role) === r) return true;
    /* v1.3 : alias de fonction (« Directeur général » ↔ fonction « direction ») ; mêmes alias côté serveur (wf_acteur) */
    return Array.isArray(actor.roles) && actor.roles.some(function (x) { return norm(x) === r; });
  }
  /* alias des fonctions de la base partagée (FLAB de exb-db.js) → intitulés usuels d'un circuit. Miroir exact de wf_acteur() en SQL. */
  var ALIAS = { direction: ['directeur general', 'directeur', 'dg', 'direction'], chef_projet: ['chef de projet', 'chef projet'], conducteur: ['conducteur de travaux', 'conducteur'],
    bureau_etudes: ["bureau d'etudes", 'bureau etudes', 'ingenieur'], comptable: ['comptable', 'comptabilite'], rh: ['rh', 'ressources humaines'], magasinier: ['magasinier'] };
  function rolesOf(fonction, role) {
    var f = String(fonction || ''), out = f ? [norm(f), norm(f.replace(/_/g, ' '))].concat(ALIAS[f] || []) : [];
    if (role === 'admin') out.push('administrateur', 'admin');
    if (role === 'lecteur') out.push('lecteur');
    return out.filter(function (x, i) { return x && out.indexOf(x) === i; });
  }
  /* « Marie » ou « Directeur général » → {name} ou {role} : un approbateur contenant « fonction: » est une fonction */
  function parseApprover(s) {
    s = String(s || '').trim(); if (!s) return null;
    var m = /^(fonction|role|rôle)\s*:\s*(.+)$/i.exec(s);
    return m ? { role: m[2].trim() } : { name: s };
  }

  function validateCircuit(c) {
    var E = [];
    if (!c || !String(c.nom || '').trim()) E.push('Le circuit doit avoir un nom.');
    var st = (c && c.steps) || [];
    if (!st.length) E.push('Ajoutez au moins une étape.');
    st.forEach(function (s, i) {
      var n = 'Étape ' + (i + 1) + (s && s.nom ? ' (« ' + s.nom + ' »)' : '');
      if (!s || !String(s.nom || '').trim()) E.push(n + ' : un nom est obligatoire.');
      if (!s || !MODES[s.mode]) E.push(n + ' : mode inconnu.');
      if (!s || !Array.isArray(s.approvers) || !s.approvers.length || s.approvers.some(function (a) { return !a || !(a.name || a.role); })) E.push(n + ' : au moins un approbateur (nom ou fonction).');
      if (s && s.delaiJours != null && s.delaiJours !== '' && !(num(s.delaiJours) >= 0 && num(s.delaiJours) <= 365)) E.push(n + ' : délai entre 0 et 365 jours.');
      if (s && s.seuil && !(num(s.seuil.montant) > 0 && s.seuil.devise)) E.push(n + ' : seuil = montant positif et devise.');
    });
    if (st.length && st.every(function (s) { return s && s.seuil; })) E.push('Au moins une étape doit s\'appliquer à tous les montants (sans seuil), pour qu\'aucun dossier ne soit validé sans contrôle.');
    return { ok: !E.length, errors: E };
  }
  /* étape applicable ? seuil comparé dans la devise du dossier ; devise différente → l'étape s'applique (prudence, aucune conversion) */
  function applies(s, data) {
    if (!s.seuil) return true;
    if (String(data.devise || '').toUpperCase() !== String(s.seuil.devise || '').toUpperCase()) return true;
    return num(data.montant) >= num(s.seuil.montant);
  }
  function entry(d_, actor, action, motif, now, extra) {
    var st = d_.steps[d_.cur];
    var e = { t: now, acteur: alabel(actor), fonction: actor && actor.role || '', action: action, etape: st ? st.nom : '', version: d_.version, motif: motif || '' };
    if (extra) Object.keys(extra).forEach(function (k) { e[k] = extra[k]; });
    d_.history.push(e); return e;
  }
  function startStep(d_, now) { var s = d_.steps[d_.cur]; d_.debutEtape = now; d_.echeance = s && num(s.delaiJours) > 0 ? addDays(now, num(s.delaiJours)) : ''; }

  /* soumission : copie figée du circuit (une modification ultérieure du modèle n'affecte pas un dossier en cours) */
  function start(circuit, data, initiateur, now, no) {
    var v = validateCircuit(circuit); if (!v.ok) return { ok: false, error: v.errors[0] };
    data = data || {};
    if (!String(data.titre || '').trim()) return { ok: false, error: 'Le titre du dossier est obligatoire.' };
    if (!initiateur || !(initiateur.name || initiateur.role)) return { ok: false, error: 'Initiateur inconnu.' };
    var steps = clone(circuit.steps).filter(function (s) { return applies(s, data); });
    var d_ = { id: data.id || ('wf_' + now.replace(/\D/g, '').slice(0, 14) + '_' + Math.random().toString(36).slice(2, 6)), no: no || '', circuit_id: circuit.id || '', circuit_nom: circuit.nom, type: circuit.type || data.type || 'autre',
      titre: String(data.titre).trim().slice(0, 200), description: String(data.description || '').slice(0, 2000), ref: data.ref || null, montant: data.montant == null || data.montant === '' ? null : num(data.montant), devise: data.devise || '',
      initiateur: { name: initiateur.name || '', role: initiateur.role || '' }, distincts: circuit.distincts !== false, autoApprobation: !!circuit.autoApprobation,
      status: 'en_cours', version: 1, steps: steps, cur: 0, decisions: [], history: [], cree: now, maj: now, fin: '' };
    entry(d_, initiateur, 'soumis', d_.description, now, { circuit: circuit.nom });
    startStep(d_, now); return { ok: true, dossier: d_ };
  }
  function approvedKeys(d_, step) {
    var o = {}; d_.decisions.forEach(function (x) { if (x.step === step && x.version === d_.version && x.action === 'approuver') o[x.approver] = 1; }); return o;
  }
  /* qui doit agir maintenant ? */
  function pending(d_) {
    if (!d_ || d_.status !== 'en_cours') return [];
    var s = d_.steps[d_.cur]; if (!s) return [];
    var done = approvedKeys(d_, d_.cur), left = s.approvers.filter(function (a) { return !done[akey(a)]; });
    if (s.mode === 'sequentiel') return left.slice(0, 1);
    if (s.mode === 'un_seul' && left.length < s.approvers.length) return [];
    return left;
  }
  function delegActive(dl, today) { return dl && dl.actif !== false && (!dl.du || day(dl.du) <= today) && (!dl.au || day(dl.au) >= today); }
  /* l'acteur peut-il agir ? → {ap, pour} ou null ; pour = approbateur dont il tient la place (délégation) */
  function canAct(d_, actor, delegations, now) {
    var today = day(now), p = pending(d_), i;
    for (i = 0; i < p.length; i++) if (matches(actor, p[i])) return { ap: p[i], pour: '' };
    var dl = (delegations || []).filter(function (x) { return delegActive(x, today); });
    for (i = 0; i < p.length; i++) for (var j = 0; j < dl.length; j++) if (matches(dl[j].de, p[i]) && matches(dl[j].a, actor)) return { ap: p[i], pour: alabel(dl[j].de) };
    return null;
  }
  function isInitiator(d_, actor) { return !!(actor && ((d_.initiateur.name && norm(actor.name) === norm(d_.initiateur.name)) || (!d_.initiateur.name && d_.initiateur.role && norm(actor.role) === norm(d_.initiateur.role)))); }
  function finish(d_, status, now) { d_.status = status; d_.fin = now; d_.echeance = ''; }

  /* action de décision. ctx : {now, delegations, verified} ; verified=false (mode local) est consigné */
  function act(src, actor, action, motif, ctx) {
    ctx = ctx || {}; var now = ctx.now, d_ = clone(src), mo = String(motif || '').trim();
    if (['approuver', 'refuser', 'corriger'].indexOf(action) < 0) return { ok: false, error: 'Action inconnue.' };
    if (d_.status !== 'en_cours') return { ok: false, error: 'Ce dossier n\'est plus en cours (' + STAT[d_.status] + ').' };
    if ((action === 'refuser' || action === 'corriger') && mo.length < 3) return { ok: false, error: (action === 'refuser' ? 'Un refus' : 'Une demande de correction') + ' doit être motivé(e).' };
    var who = canAct(d_, actor, ctx.delegations, now);
    if (!who) return { ok: false, error: 'Ce n\'est pas à vous de décider à cette étape.' };
    if (isInitiator(d_, actor) && !d_.autoApprobation) return { ok: false, error: 'Séparation des tâches : l\'initiateur ne peut pas décider de son propre dossier.' };
    if (action === 'approuver' && d_.distincts) {
      var prev = d_.decisions.filter(function (x) { return x.version === d_.version && x.action === 'approuver' && x.step !== d_.cur && norm(x.acteur) === norm(alabel(actor)); });
      if (prev.length) return { ok: false, error: 'Une même personne ne peut pas approuver deux étapes du même dossier.' };
    }
    var ex = { verifie: ctx.verified !== false }; if (who.pour) ex.pour = who.pour;
    d_.decisions.push({ step: d_.cur, version: d_.version, approver: akey(who.ap), acteur: alabel(actor), action: action, t: now, motif: mo, pour: who.pour || '' });
    entry(d_, actor, action, mo, now, ex); d_.maj = now;
    if (action === 'refuser') { finish(d_, 'refuse', now); return { ok: true, dossier: d_, event: 'refuse' }; }
    if (action === 'corriger') { d_.status = 'retourne'; d_.echeance = ''; return { ok: true, dossier: d_, event: 'retourne' }; }
    var s = d_.steps[d_.cur], done = approvedKeys(d_, d_.cur), nb = s.approvers.filter(function (a) { return done[akey(a)]; }).length;
    var complete = s.mode === 'un_seul' ? nb >= 1 : nb >= s.approvers.length;
    if (!complete) return { ok: true, dossier: d_, event: 'decision' };
    if (d_.cur + 1 >= d_.steps.length) { finish(d_, 'valide', now); entry(d_, actor, 'valide', '', now); return { ok: true, dossier: d_, event: 'valide' }; }
    d_.cur++; startStep(d_, now); return { ok: true, dossier: d_, event: 'etape' };
  }
  /* l'initiateur corrige puis soumet à nouveau : repart de la première étape, l'historique est conservé */
  function resubmit(src, actor, note, now) {
    var d_ = clone(src);
    if (d_.status !== 'retourne') return { ok: false, error: 'Ce dossier n\'est pas à corriger.' };
    if (!isInitiator(d_, actor)) return { ok: false, error: 'Seul l\'initiateur peut soumettre à nouveau.' };
    d_.version++; d_.status = 'en_cours'; d_.cur = 0; d_.fin = ''; d_.maj = now;
    entry(d_, actor, 'resoumis', String(note || '').trim(), now); startStep(d_, now); return { ok: true, dossier: d_, event: 'resoumis' };
  }
  function cancel(src, actor, motif, ctx) {
    ctx = ctx || {}; var d_ = clone(src), mo = String(motif || '').trim();
    if (d_.status !== 'en_cours' && d_.status !== 'retourne') return { ok: false, error: 'Ce dossier est déjà clos.' };
    if (!isInitiator(d_, actor) && !ctx.admin) return { ok: false, error: 'Seul l\'initiateur ou un administrateur peut annuler.' };
    if (mo.length < 3) return { ok: false, error: 'Un motif d\'annulation est obligatoire.' };
    entry(d_, actor, 'annule', mo, ctx.now); d_.maj = ctx.now; finish(d_, 'annule', ctx.now); return { ok: true, dossier: d_, event: 'annule' };
  }
  /* échéances : retard (jours dépassés) et rappel (échéance dans 1 jour ou moins) des dossiers en cours */
  function echeances(list, now) {
    var t = day(now), out = [];
    (list || []).forEach(function (d_) {
      if (d_.status !== 'en_cours' || !d_.echeance) return;
      var left = diffDays(d_.echeance, t);
      if (left < 0) out.push({ id: d_.id, no: d_.no, titre: d_.titre, etat: 'retard', jours: -left, attente: pending(d_) });
      else if (left <= 1) out.push({ id: d_.id, no: d_.no, titre: d_.titre, etat: 'rappel', jours: left, attente: pending(d_) });
    });
    return out.sort(function (a, b) { return (a.etat === b.etat ? b.jours - a.jours : a.etat === 'retard' ? -1 : 1); });
  }
  function stats(list, now) {
    var S = { total: 0, par_statut: { en_cours: 0, valide: 0, refuse: 0, retourne: 0, annule: 0 }, par_type: {}, en_retard: 0, delai_moyen_jours: null }, sum = 0, n = 0;
    (list || []).forEach(function (d_) {
      S.total++; S.par_statut[d_.status] = (S.par_statut[d_.status] || 0) + 1; S.par_type[d_.type] = (S.par_type[d_.type] || 0) + 1;
      if (d_.status === 'valide' && d_.fin) { sum += Math.max(0, diffDays(d_.fin, d_.cree)); n++; }
    });
    S.en_retard = echeances(list, now).filter(function (x) { return x.etat === 'retard'; }).length;
    if (n) S.delai_moyen_jours = Math.round(sum / n * 10) / 10;
    return S;
  }
  /* « à valider par moi » : dossiers dont l'acteur (ou son délégant) est attendu */
  function tasksFor(list, actor, delegations, now) {
    return (list || []).filter(function (d_) { return !!canAct(d_, actor, delegations, now) && !(isInitiator(d_, actor) && !d_.autoApprobation); });
  }
  function nextNo(list, year) {
    var mx = 0, re = new RegExp('^WF-' + year + '-(\\d+)$');
    (list || []).forEach(function (x) { var m = re.exec(x.no || ''); if (m) mx = Math.max(mx, +m[1]); });
    return 'WF-' + year + '-' + ('000' + (mx + 1)).slice(-4);
  }
  var ENGINE = { rolesOf: rolesOf, norm: norm, isInitiator: isInitiator, TYPES: TYPES, MODES: MODES, STAT: STAT, validateCircuit: validateCircuit, applies: applies, start: start, pending: pending, canAct: canAct, act: act, resubmit: resubmit, cancel: cancel, echeances: echeances, stats: stats, tasksFor: tasksFor, nextNo: nextNo, parseApprover: parseApprover, matches: matches };

  /* ============================ STOCKAGE ============================ */
  function G(k) { try { if (w.EXBS && w.EXBS.get) { var a = w.EXBS.get(k); if (Array.isArray(a)) return a; } } catch (e) {} try { var v = JSON.parse((w.exbStorage || w.localStorage).getItem(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function rawPut(k, a) {
    try { if (w.EXBS && w.EXBS.set) { w.EXBS.set(k, a); return true; } } catch (e) {}
    try { (w.exbStorage || w.localStorage).setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; }
  }
  function srv() { try { return w.EXBWFS && w.EXBWFS.active() ? w.EXBWFS : null; } catch (e) { return null; } }
  /* quiet = écriture venant du serveur (ne pas la renvoyer). Circuits / délégations modifiés localement : transmis au serveur (administrateur). */
  function put(k, a, quiet) {
    var prev = (!quiet && (k === CK || k === LK) && srv()) ? G(k) : null, r = rawPut(k, a);
    if (r && prev) { try { srv().pushConfig(k === CK ? 'circuit' : 'deleg', prev, a); } catch (e) {} }
    return r;
  }
  function nowIso() { return new Date().toISOString(); }
  function info() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || { on: false }; } catch (e) { return { on: false }; } }
  /* v1.3 : le nom est celui du compte (membres.nom) quand il est connu ; la fonction sert d'alias (Directeur général, Chef de projet…) */
  function me() {
    var i = info(), nom = ''; try { nom = (w.EXBDB && w.EXBDB._meta && w.EXBDB._meta().nom) || ''; } catch (e) {}
    if (!i.on) return { name: '', role: '', roles: [], verified: false, on: false };
    var sw = null; try { sw = w.EXBWFS && w.EXBWFS.who(); } catch (e) {}
    if (sw) return { name: sw.name || nom || i.label || '', role: sw.role || '', roles: sw.roles || [], verified: true, on: true };
    var f = i.fonction && i.fonction !== 'polyvalent' ? i.fonction : '';
    return { name: nom || i.label || '', role: f || i.role || '', roles: rolesOf(f, i.role), verified: true, on: true };
  }
  function isAdmin() { var i = info(); return !i.on || i.role === 'admin'; }
  function audit(a, obj, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, obj, det); } catch (e) {} }
  function emit(n, p) { try { if (w.EXBCore && w.EXBCore.bus) w.EXBCore.bus.emit(n, p, 'workflow'); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'info', 5000); } catch (e) {} }

  function saveDossier(nd) {
    var L = G(DK), i = L.findIndex(function (x) { return x.id === nd.id; });
    if (i >= 0) L[i] = nd; else L.push(nd);
    return put(DK, L);
  }
  var EVT = { resoumis: 'workflow.soumis', decision: 'workflow.decision', etape: 'workflow.decision', valide: 'workflow.valide', refuse: 'workflow.refuse', retourne: 'workflow.retourne', annule: 'workflow.annule' };
  function after(nd, ev, motif) {
    audit('workflow.' + ev, nd.no, { statut: nd.status, titre: nd.titre.slice(0, 60), motif: String(motif || '').slice(0, 80) });
    emit(EVT[ev] || 'workflow.decision', { id: nd.id, no: nd.no, status: nd.status, type: nd.type, ref: nd.ref });
  }
  /* API publique pour les autres modules et pour l'écran */
  function submit(o) {
    o = o || {}; var C = G(CK).filter(function (c) { return c.actif !== false; });
    var c = o.circuit_id ? C.filter(function (x) { return x.id === o.circuit_id; })[0] : C.filter(function (x) { return x.type === o.type; })[0];
    if (!c) return { ok: false, error: 'Aucun circuit actif pour ce type de dossier.' };
    var m = o.initiateur || me(); if (!(m.name || m.role)) m = { name: 'Utilisateur local', role: '' };
    var now = nowIso(), r = start(c, o, m, now, nextNo(G(DK), now.slice(0, 4)));
    if (!r.ok) return r;
    if (!saveDossier(r.dossier)) return { ok: false, error: 'Enregistrement impossible (stockage plein ?).' };
    var s = srv();
    if (s) { s.push('submit', r.dossier, { circuit_id: c.id, circuit: c.nom }); r.pending = true; return r; }
    afterSubmit(r.dossier, c.nom);
    return r;
  }
  function afterSubmit(nd, circuitNom) {
    audit('workflow.soumis', nd.no, { circuit: circuitNom || nd.circuit_nom, titre: nd.titre.slice(0, 60) }); emit('workflow.soumis', { id: nd.id, no: nd.no, status: nd.status, type: nd.type, ref: nd.ref });
  }
  function find(id) { return G(DK).filter(function (x) { return x.id === id; })[0]; }
  function decide(id, action, motif, actorOverride) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Dossier introuvable.' };
    var m = me(), actor = actorOverride || { name: m.name, role: m.role };
    var r = act(dd, actor, action, motif, { now: nowIso(), delegations: G(LK), verified: m.verified && !actorOverride });
    if (!r.ok) return r; if (!saveDossier(r.dossier)) return { ok: false, error: 'Enregistrement impossible.' };
    var s = srv();
    if (s) { s.push('decide', r.dossier, { action: action, motif: motif, etape: dd.cur, version: dd.version, event: r.event, avant: dd }); r.pending = true; return r; }
    after(r.dossier, r.event, motif); return r;
  }
  function resubmitD(id, note) { var dd = find(id); if (!dd) return { ok: false, error: 'Dossier introuvable.' }; var m = me(); var r = resubmit(dd, m.on ? m : { name: dd.initiateur.name, role: dd.initiateur.role }, note, nowIso()); if (!r.ok) return r; saveDossier(r.dossier); var s = srv(); if (s) { s.push('resubmit', r.dossier, { motif: note, event: 'resoumis', avant: dd }); r.pending = true; return r; } after(r.dossier, 'resoumis', note); return r; }
  function cancelD(id, motif) { var dd = find(id); if (!dd) return { ok: false, error: 'Dossier introuvable.' }; var m = me(); var r = cancel(dd, m.on ? m : { name: dd.initiateur.name, role: dd.initiateur.role }, motif, { now: nowIso(), admin: isAdmin() }); if (!r.ok) return r; saveDossier(r.dossier); var s = srv(); if (s) { s.push('cancel', r.dossier, { motif: motif, event: 'annule', avant: dd }); r.pending = true; return r; } after(r.dossier, 'annule', motif); return r; }

  /* ============================ ÉCRAN ============================ */
  if (!d) { w.EXBWF = { version: 1, engine: ENGINE }; return; }
  var $ = function (i) { return d.getElementById(i); };
  var P = { tab: 'taches', filtre: '' }; try { Object.assign(P, JSON.parse(w.localStorage.getItem(PK) || '{}')); } catch (e) {} function sp() { try { w.localStorage.setItem(PK, JSON.stringify({ tab: P.tab })); } catch (e) {} }
  var BADGE = { en_cours: '#1f5fbf', valide: '#15803d', refuse: '#b91c1c', retourne: '#d97706', annule: '#6b7280' };
  function fr(s) { return s ? String(s).slice(0, 10).split('-').reverse().join('/') : '—'; }
  function money(d_) { return d_.montant == null ? '—' : new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(d_.montant) + ' ' + (d_.devise === 'CDF' || d_.devise === 'FC' ? 'FC' : d_.devise === 'USD' ? '$' : esc(d_.devise)); }
  function names(l) { return l.map(function (a) { return esc(alabel(a)); }).join(', ') || '—'; }
  function modal(html) { var el = d.createElement('div'); el.id = 'wf_md'; el.style.cssText = 'position:fixed;inset:0;background:rgba(10,20,40,.55);z-index:100000;display:flex;align-items:center;justify-content:center;padding:12px'; el.innerHTML = '<div style="background:#fff;border-radius:12px;max-width:680px;width:100%;max-height:88vh;overflow:auto;padding:14px">' + html + '</div>'; var o = $('wf_md'); if (o) o.remove(); d.body.appendChild(el); el.onclick = function (e) { if (e.target === el) el.remove(); }; return el; }
  function closeM() { var o = $('wf_md'); if (o) o.remove(); }

  function renderTaches(box) {
    var m = me(), L = G(DK), E = echeances(L, nowIso()), mine = m.on ? tasksFor(L, m, G(LK), nowIso()) : L.filter(function (x) { return x.status === 'en_cours'; });
    var h = '';
    if (!m.on) h += '<p class="exb-muted" style="margin:0 0 8px">Mode local (aucune organisation connectée) : tous les dossiers en cours sont listés ; vous choisissez en quel nom vous décidez, et l\'historique le signale comme « identité non vérifiée ».</p>';
    var late = E.filter(function (x) { return x.etat === 'retard'; }).length;
    if (late) h += '<div style="border:1px solid #f1c0c0;background:#fff5f5;border-radius:10px;padding:8px 10px;margin-bottom:8px">⏰ ' + late + ' dossier(s) en retard de validation.</div>';
    if (!mine.length) return h + '<p class="exb-muted">Aucun dossier à valider.</p>';
    return h + dossierTable(mine);
  }
  function dossierTable(list) {
    var t = nowIso(), E = {}; echeances(list, t).forEach(function (x) { E[x.id] = x; });
    return '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.92em"><tr style="text-align:left"><th>N°</th><th>Dossier</th><th>Type</th><th style="text-align:right">Montant</th><th>Statut</th><th>Attend</th><th>Échéance</th></tr>' +
      list.slice().sort(function (a, b) { return a.maj < b.maj ? 1 : -1; }).slice(0, 200).map(function (x) {
        var e = E[x.id], st = '<span style="color:' + BADGE[x.status] + ';font-weight:600">' + esc(STAT[x.status]) + '</span>';
        return '<tr class="wf-row" data-id="' + esc(x.id) + '" style="border-top:1px solid #e3e9f2;cursor:pointer"><td>' + esc(x.no) + '</td><td>' + esc(x.titre) + '</td><td>' + esc(TYPES[x.type] || x.type) + '</td><td style="text-align:right">' + money(x) + '</td><td>' + st + (x.status === 'en_cours' ? ' · étape ' + (x.cur + 1) + '/' + x.steps.length : '') + (x._pending ? ' <span title="En attente d\'envoi au serveur">⏳</span>' : '') + '</td><td>' + (x.status === 'en_cours' ? names(pending(x)) : '—') + '</td><td style="color:' + (e && e.etat === 'retard' ? '#b91c1c' : 'inherit') + '">' + (x.echeance ? fr(x.echeance) + (e ? (e.etat === 'retard' ? ' (+' + e.jours + ' j)' : ' ⚠') : '') : '—') + '</td></tr>';
      }).join('') + '</table></div>';
  }
  function renderDossiers(box) {
    var L = G(DK), f = P.filtre, S = stats(L, nowIso());
    var h = '<p class="exb-muted" style="margin:0 0 8px">' + S.total + ' dossier(s) · en cours ' + S.par_statut.en_cours + ' · validés ' + S.par_statut.valide + ' · refusés ' + S.par_statut.refuse + ' · à corriger ' + S.par_statut.retourne + (S.en_retard ? ' · <b style="color:#b91c1c">' + S.en_retard + ' en retard</b>' : '') + (S.delai_moyen_jours != null ? ' · délai moyen de validation ' + String(S.delai_moyen_jours).replace('.', ',') + ' j' : '') + '</p>';
    h += '<label>Statut <select id="wf_f"><option value="">Tous</option>' + Object.keys(STAT).map(function (k) { return '<option value="' + k + '"' + (f === k ? ' selected' : '') + '>' + STAT[k] + '</option>'; }).join('') + '</select></label> ';
    var LL = f ? L.filter(function (x) { return x.status === f; }) : L;
    return h + (LL.length ? dossierTable(LL) : '<p class="exb-muted">Aucun dossier.</p>');
  }
  function renderCircuits(box) {
    var C = G(CK), adm = isAdmin(), h = '';
    if (!adm) h += '<p class="exb-muted">Seul un administrateur peut créer ou modifier les circuits.</p>';
    if (adm) h += '<p><button type="button" id="wf_newc">＋ Nouveau circuit</button> <button type="button" id="wf_models">📋 Ajouter les circuits modèles</button></p>';
    if (!C.length) return h + '<p class="exb-muted">Aucun circuit. Ajoutez les circuits modèles puis adaptez-les, ou créez le vôtre.</p>';
    return h + C.map(function (c) {
      return '<div style="border:1px solid #d7deea;border-radius:10px;padding:8px 10px;margin-bottom:8px"><b>' + esc(c.nom) + '</b> <small class="exb-muted">· ' + esc(TYPES[c.type] || c.type) + (c.actif === false ? ' · désactivé' : '') + (c.distincts === false ? ' · mêmes personnes autorisées sur plusieurs étapes' : '') + '</small>' +
        '<ol style="margin:6px 0 4px;padding-left:20px">' + c.steps.map(function (s) { return '<li>' + esc(s.nom) + ' — ' + names(s.approvers) + ' <small class="exb-muted">(' + esc(MODES[s.mode]) + (s.delaiJours ? ', délai ' + esc(s.delaiJours) + ' j' : '') + (s.seuil ? ', dès ' + esc(s.seuil.montant) + ' ' + esc(s.seuil.devise) : '') + ')</small></li>'; }).join('') + '</ol>' +
        (adm ? '<button type="button" class="wf-ct" data-id="' + esc(c.id) + '">' + (c.actif === false ? 'Activer' : 'Désactiver') + '</button> <button type="button" class="wf-cd" data-id="' + esc(c.id) + '">Supprimer</button>' : '') + '</div>';
    }).join('');
  }
  function renderDeleg(box) {
    var D = G(LK), h = '<p class="exb-muted" style="margin:0 0 8px">Une délégation permet à une personne de décider à la place d\'une autre pendant une période. L\'historique indique « pour le compte de ».</p>';
    h += '<form id="wf_df" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px"><input id="wf_dd" placeholder="Délégant : nom ou fonction: Directeur général" required><input id="wf_da" placeholder="Remplaçant (nom)" required><label>du <input id="wf_du" type="date" required></label><label>au <input id="wf_dz" type="date" required></label><button type="submit">Déléguer</button></form>';
    return h + (D.length ? '<ul>' + D.map(function (x) { var on = delegActive(x, day(nowIso())); return '<li>' + esc(alabel(x.de)) + ' → ' + esc(alabel(x.a)) + ' · ' + fr(x.du) + ' au ' + fr(x.au) + (on ? ' <b style="color:#15803d">en cours</b>' : ' <span class="exb-muted">inactive</span>') + ' <button type="button" class="wf-dx" data-id="' + esc(x.id) + '">Retirer</button></li>'; }).join('') + '</ul>' : '<p class="exb-muted">Aucune délégation.</p>');
  }
  function render() {
    var box = $('wf_box'); if (!box) return;
    var tabs = [['taches', '✅ À valider'], ['dossiers', '📁 Dossiers'], ['circuits', '🔀 Circuits'], ['deleg', '🤝 Délégations']];
    var h = (w.EXBWFS ? w.EXBWFS.statusHtml() : '') + '<div class="exb-tabs">' + tabs.map(function (t) { return '<button type="button" class="wf-tab" data-t="' + t[0] + '" style="' + (P.tab === t[0] ? 'font-weight:700;border-bottom:3px solid #c9a24b' : '') + '">' + t[1] + '</button>'; }).join('') + '</div><div style="margin:0 0 10px"><button type="button" id="wf_new" style="white-space:nowrap">＋ Nouveau dossier</button></div>';
    h += '<div id="wf_pane"></div>'; box.innerHTML = h;
    var pane = $('wf_pane'), body = P.tab === 'dossiers' ? renderDossiers(pane) : P.tab === 'circuits' ? renderCircuits(pane) : P.tab === 'deleg' ? renderDeleg(pane) : renderTaches(pane);
    pane.innerHTML = body; bind(box);
  }
  function bind(box) {
    each(box, '.wf-tab', function (b) { b.onclick = function () { P.tab = b.getAttribute('data-t'); sp(); render(); }; });
    each(box, '.wf-row', function (r) { r.onclick = function () { openDossier(r.getAttribute('data-id')); }; });
    if ($('wf_new')) $('wf_new').onclick = formDossier;
    if ($('wf_f')) $('wf_f').onchange = function () { P.filtre = this.value; render(); };
    if ($('wf_newc')) $('wf_newc').onclick = formCircuit;
    if ($('wf_models')) $('wf_models').onclick = addModels;
    each(box, '.wf-ct', function (b) { b.onclick = function () { var C = G(CK), c = C.filter(function (x) { return x.id === b.getAttribute('data-id'); })[0]; if (c) { c.actif = c.actif === false; put(CK, C); audit('workflow.circuit', c.nom, { actif: c.actif !== false }); render(); } }; });
    each(box, '.wf-cd', function (b) { b.onclick = function () { delCircuit(b.getAttribute('data-id')); }; });
    if ($('wf_df')) $('wf_df').onsubmit = function (e) { e.preventDefault(); var du = $('wf_du').value, dz = $('wf_dz').value; if (dz < du) return say('La date de fin précède la date de début.', 'warn'); var D = G(LK); D.push({ id: 'dl_' + Date.now().toString(36), de: parseApprover($('wf_dd').value), a: { name: $('wf_da').value.trim() }, du: du, au: dz, actif: true }); put(LK, D); audit('workflow.delegation', $('wf_dd').value.trim(), { a: $('wf_da').value.trim(), du: du, au: dz }); render(); };
    each(box, '.wf-dx', function (b) { b.onclick = function () { put(LK, G(LK).filter(function (x) { return x.id !== b.getAttribute('data-id'); })); audit('workflow.delegation.retrait', b.getAttribute('data-id'), ''); render(); }; });
  }
  function each(root, sel, fn) { Array.prototype.forEach.call(root.querySelectorAll(sel), fn); }
  async function delCircuit(id) {
    var used = G(DK).some(function (x) { return x.circuit_id === id && (x.status === 'en_cours' || x.status === 'retourne'); });
    if (used) return say('Ce circuit a des dossiers en cours : désactivez-le plutôt.', 'warn');
    var ok = typeof w.exbConfirm === 'function' ? await w.exbConfirm('Supprimer ce circuit ? Les dossiers déjà traités gardent leur copie.') : true; if (!ok) return;
    put(CK, G(CK).filter(function (x) { return x.id !== id; })); audit('workflow.circuit.suppression', id, ''); render();
  }
  function formDossier() {
    var C = G(CK).filter(function (c) { return c.actif !== false; });
    if (!C.length) return say('Créez d\'abord un circuit (onglet Circuits).', 'warn');
    var el = modal('<h3 style="margin:0 0 8px">Nouveau dossier à valider</h3><form id="wf_nf" style="display:grid;gap:8px"><label>Circuit <select id="wf_c">' + C.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.nom) + ' (' + esc(TYPES[c.type] || c.type) + ')</option>'; }).join('') + '</select></label><label>Titre <input id="wf_t" required maxlength="200"></label><label>Montant (facultatif) <input id="wf_m" type="number" min="0" step="0.01"></label><label>Devise <select id="wf_dv"><option>USD</option><option>CDF</option></select></label><label>Description <textarea id="wf_ds" rows="3" maxlength="2000"></textarea></label><div><button type="submit">Soumettre</button> <button type="button" id="wf_cx">Annuler</button></div></form>');
    $('wf_cx').onclick = closeM;
    $('wf_nf').onsubmit = function (e) { e.preventDefault(); var r = submit({ circuit_id: $('wf_c').value, titre: $('wf_t').value, montant: $('wf_m').value, devise: $('wf_dv').value, description: $('wf_ds').value }); if (!r.ok) return say(r.error, 'warn'); closeM(); say('Dossier ' + r.dossier.no + ' soumis.', 'success'); P.tab = 'dossiers'; render(); };
  }
  function openDossier(id) {
    var x = find(id); if (!x) return;
    var m = me(), cand = pending(x), can_ = m.on ? canAct(x, m, G(LK), nowIso()) : (cand.length ? { ap: cand[0], pour: '' } : null), ini = m.on ? isInitiator(x, m) : true;
    var h = '<div style="display:flex;justify-content:space-between;gap:8px"><h3 style="margin:0">' + esc(x.no) + ' — ' + esc(x.titre) + '</h3><button type="button" id="wf_x">✕</button></div>' +
      '<p class="exb-muted">' + esc(TYPES[x.type] || x.type) + ' · ' + money(x) + ' · initié par ' + esc(alabel(x.initiateur)) + ' le ' + fr(x.cree) + ' · circuit « ' + esc(x.circuit_nom) + ' » · version ' + x.version + '</p>' + (x.description ? '<p>' + esc(x.description) + '</p>' : '') +
      '<p><b style="color:' + BADGE[x.status] + '">' + esc(STAT[x.status]) + '</b>' + (x.status === 'en_cours' ? ' · étape ' + (x.cur + 1) + '/' + x.steps.length + ' « ' + esc(x.steps[x.cur].nom) + ' » — en attente de ' + names(cand) + (x.echeance ? ' · avant le ' + fr(x.echeance) : '') : '') + '</p>' +
      '<ol style="padding-left:20px;margin:4px 0">' + x.steps.map(function (s, i) { return '<li style="' + (i === x.cur && x.status === 'en_cours' ? 'font-weight:700' : i < x.cur || x.status === 'valide' ? 'color:#15803d' : '') + '">' + esc(s.nom) + ' — ' + names(s.approvers) + '</li>'; }).join('') + '</ol>';
    if (x.status === 'en_cours' && can_ && !(ini && !x.autoApprobation && m.on)) {
      var pick = '';
      if (!m.on) pick = '<label>Je décide en tant que <select id="wf_as">' + cand.map(function (a, i) { return '<option value="' + i + '">' + esc(alabel(a)) + '</option>'; }).join('') + '</select></label><br><small class="exb-muted">Identité non vérifiée (mode local), consignée dans l\'historique.</small>';
      h += '<div style="border:1px solid #d7deea;border-radius:10px;padding:8px;margin:8px 0">' + pick + '<label>Motif / commentaire <textarea id="wf_mo" rows="2" style="width:100%" maxlength="500"></textarea></label><button type="button" data-a="approuver" class="wf-do">✅ Approuver</button> <button type="button" data-a="corriger" class="wf-do">↩ Demander une correction</button> <button type="button" data-a="refuser" class="wf-do">⛔ Refuser</button><br><small class="exb-muted">Le refus et la demande de correction exigent un motif.</small></div>' + (can_.pour ? '<p class="exb-muted">Vous décidez pour le compte de ' + esc(can_.pour) + ' (délégation).</p>' : '');
    }
    if (x.status === 'retourne' && (ini || !m.on)) h += '<div style="border:1px solid #f0d9a8;background:#fffaf0;border-radius:10px;padding:8px;margin:8px 0"><label>Corrections apportées <textarea id="wf_nt" rows="2" style="width:100%"></textarea></label><button type="button" id="wf_rs">📨 Soumettre à nouveau</button></div>';
    if ((x.status === 'en_cours' || x.status === 'retourne') && (ini || isAdmin())) h += '<p><button type="button" id="wf_an">🚫 Annuler le dossier</button></p>';
    h += '<h4 style="margin:10px 0 4px">Historique</h4><ul style="padding-left:18px;margin:0">' + x.history.slice().reverse().map(function (e) { return '<li><small>' + esc(String(e.t).replace('T', ' ').slice(0, 16)) + '</small> <b>' + esc(e.acteur) + '</b>' + (e.pour ? ' (pour ' + esc(e.pour) + ')' : '') + ' — ' + esc({ soumis: 'a soumis', approuver: 'a approuvé', refuser: 'a refusé', corriger: 'demande une correction', resoumis: 'a soumis à nouveau', valide: 'dossier validé', annule: 'a annulé' }[e.action] || e.action) + (e.etape && e.action !== 'soumis' ? ' · ' + esc(e.etape) : '') + (e.motif ? ' : « ' + esc(e.motif) + ' »' : '') + (e.verifie === false ? ' <small class="exb-muted">(identité non vérifiée)</small>' : '') + '</li>'; }).join('') + '</ul>';
    modal(h); $('wf_x').onclick = closeM;
    each($('wf_md'), '.wf-do', function (b) { b.onclick = function () {
      var o = null; if ($('wf_as')) o = cand[+$('wf_as').value];
      var r = decide(id, b.getAttribute('data-a'), $('wf_mo').value, o); if (!r.ok) return say(r.error, 'warn');
      closeM(); say({ valide: 'Dossier validé.', etape: 'Étape validée, dossier transmis à la suivante.', decision: 'Décision enregistrée.', refuse: 'Dossier refusé.', retourne: 'Dossier renvoyé pour correction.' }[r.event] || 'Enregistré.', 'success'); render(); }; });
    if ($('wf_rs')) $('wf_rs').onclick = function () { var r = resubmitD(id, $('wf_nt').value); if (!r.ok) return say(r.error, 'warn'); closeM(); say('Dossier soumis à nouveau.', 'success'); render(); };
    if ($('wf_an')) $('wf_an').onclick = async function () { var mo = typeof w.exbPrompt === 'function' ? await w.exbPrompt('Motif de l\'annulation ?') : ''; if (mo == null) return; var r = cancelD(id, mo); if (!r.ok) return say(r.error, 'warn'); closeM(); render(); };
  }
  function formCircuit() {
    modal('<h3 style="margin:0 0 8px">Nouveau circuit</h3><form id="wf_cf" style="display:grid;gap:8px"><label>Nom <input id="wf_cn" required></label><label>Type de dossier <select id="wf_ct">' + Object.keys(TYPES).map(function (k) { return '<option value="' + k + '">' + esc(TYPES[k]) + '</option>'; }).join('') + '</select></label>' +
      '<label><input type="checkbox" id="wf_cdi" checked> Une même personne ne peut pas approuver deux étapes</label>' +
      '<div id="wf_cs"></div><button type="button" id="wf_as_">＋ Ajouter une étape</button><div><button type="submit">Enregistrer le circuit</button> <button type="button" id="wf_cx">Annuler</button></div><div id="wf_ce" style="color:#b91c1c"></div></form>');
    function addStep() { var el = d.createElement('div'); el.className = 'wf-st'; el.style.cssText = 'border:1px solid #d7deea;border-radius:8px;padding:6px;margin-bottom:6px;display:grid;gap:4px'; el.innerHTML = '<input class="s-n" placeholder="Nom de l\'étape (ex. Validation chef de projet)"><input class="s-a" placeholder="Approbateurs : Marie, fonction: Directeur général"><select class="s-m">' + Object.keys(MODES).map(function (k) { return '<option value="' + k + '">' + esc(MODES[k]) + '</option>'; }).join('') + '</select><span><label>Délai (jours) <input class="s-d" type="number" min="0" max="365" style="width:70px"></label> <label>Seulement dès <input class="s-sm" type="number" min="0" style="width:90px" placeholder="montant"></label> <select class="s-sd"><option>USD</option><option>CDF</option></select></span>'; $('wf_cs').appendChild(el); }
    addStep(); $('wf_as_').onclick = addStep; $('wf_cx').onclick = closeM;
    $('wf_cf').onsubmit = function (e) {
      e.preventDefault();
      var steps = []; each($('wf_cs'), '.wf-st', function (el) { var q = function (c) { return el.querySelector(c); }; var s = { id: 's' + steps.length, nom: q('.s-n').value.trim(), mode: q('.s-m').value, approvers: q('.s-a').value.split(',').map(parseApprover).filter(Boolean), delaiJours: q('.s-d').value === '' ? '' : +q('.s-d').value }; if (q('.s-sm').value) s.seuil = { montant: +q('.s-sm').value, devise: q('.s-sd').value }; steps.push(s); });
      var c = { id: 'wfc_' + Date.now().toString(36), nom: $('wf_cn').value.trim(), type: $('wf_ct').value, distincts: $('wf_cdi').checked, actif: true, steps: steps }, v = validateCircuit(c);
      if (!v.ok) { $('wf_ce').textContent = v.errors.join(' '); return; }
      var C = G(CK); C.push(c); put(CK, C); audit('workflow.circuit', c.nom, { etapes: steps.length }); closeM(); render();
    };
  }
  function addModels() {
    var C = G(CK), have = {}; C.forEach(function (c) { have[c.nom] = 1; });
    var M = [
      { nom: 'Dépense / achat', type: 'depense', steps: [{ nom: 'Validation du responsable', mode: 'sequentiel', approvers: [{ role: 'Chef de projet' }], delaiJours: 2 }, { nom: 'Validation de la direction', mode: 'sequentiel', approvers: [{ role: 'Directeur général' }], delaiJours: 3, seuil: { montant: 1000, devise: 'USD' } }] },
      { nom: 'Congé / absence', type: 'conge', steps: [{ nom: 'Responsable hiérarchique', mode: 'sequentiel', approvers: [{ role: 'Responsable de département' }], delaiJours: 3 }, { nom: 'Ressources humaines', mode: 'sequentiel', approvers: [{ role: 'RH' }], delaiJours: 3 }] },
      { nom: 'Devis important', type: 'devis', steps: [{ nom: 'Contrôle technique', mode: 'sequentiel', approvers: [{ role: 'Ingénieur' }], delaiJours: 2 }, { nom: 'Approbation commerciale et direction', mode: 'parallele', approvers: [{ role: 'Commercial' }, { role: 'Directeur général' }], delaiJours: 3 }] }];
    var n = 0; M.forEach(function (m) { if (have[m.nom]) return; m.id = 'wfc_' + Date.now().toString(36) + n; m.actif = true; m.distincts = true; m.steps.forEach(function (s, i) { s.id = 's' + i; }); C.push(m); n++; });
    put(CK, C); audit('workflow.circuits_modeles', 'modeles', { ajoutes: n }); say(n ? n + ' circuit(s) modèle(s) ajouté(s). Adaptez les approbateurs (noms ou fonctions) à votre équipe.' : 'Les circuits modèles existent déjà.', 'info'); render();
  }

  function mount() {
    if ($('exbwf')) return;
    var ref = $('exbbi') || $('budgetfin') || $('chantiers') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, s = d.createElement('section');
    s.id = 'exbwf'; s.style.display = 'none';
    s.innerHTML = '<div class="card"><div class="exb-module-head"><div><h2>✅ Excellencia Workflow</h2><p class="exb-muted">Circuits de validation : approbation, refus ou correction motivés, délégations, échéances et historique.</p></div></div><div id="wf_box"></div></div>';
    if (ref && ref.parentNode) ref.parentNode.insertBefore(s, ref.nextSibling); else host.appendChild(s);
    var b = $('bbi') || $('bbfin') || $('bcompta') || $('bchan') || $('bprj');
    if (b && !$('bwf')) { var n = d.createElement('button'); n.id = 'bwf'; n.textContent = '✅ Workflow'; n.setAttribute('onclick', "show('exbwf')"); b.parentNode.insertBefore(n, b.nextSibling); }
    var os = w.show;
    if (typeof os === 'function' && !w.__exbWfShow) { w.__exbWfShow = 1; w.show = function (x) { var r = os.apply(this, arguments), e = $('exbwf'); if (e) e.style.display = (x === 'exbwf') ? '' : 'none'; if (x === 'exbwf') render(); return r; }; }
  }
  w.EXBWF = { version: 1, revision: '1.3', engine: ENGINE, _after: after, _afterSubmit: afterSubmit, _emit: function (nd, ev) { emit(EVT[ev] || 'workflow.decision', { id: nd.id, no: nd.no, status: nd.status, type: nd.type, ref: nd.ref }); }, _put: function (k, a) { return put(k, a, true); }, _keys: { circuits: CK, dossiers: DK, deleg: LK }, me: me, initiatedByMe: function () { var m = me(); return m.on ? G(DK).filter(function (x) { return isInitiator(x, m); }) : []; }, submit: submit, decide: decide, find: find, list: function () { return G(DK); }, tasksFor: function () { var m = me(); return tasksFor(G(DK), m, G(LK), nowIso()); }, stats: function () { return stats(G(DK), nowIso()); }, echeances: function () { return echeances(G(DK), nowIso()); }, render: render };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(mount, 1000); }); else setTimeout(mount, 1000);
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
