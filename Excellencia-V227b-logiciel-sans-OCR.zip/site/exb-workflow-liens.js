/* Excellencia Building — LIENS WORKFLOW (v1.1 du Workflow, cahier des charges ERP, modules 07 ↔ 04, 06, 05, 10).
 * Branche le Workflow (exb-workflow.js) sur six modules existants (v1.3 : + Factures, + Dépenses de caisse), SANS réécrire ces modules : les fonctions publiques sont
 * « enveloppées » (le comportement d'origine est conservé quand le lien est désactivé ou que le montant est sous le seuil).
 *
 *   Devis        : l'export / l'impression du PDF d'un devis exige un dossier « Validé » (portail client inclus, car le PDF le publie).
 *   Achats       : un bon de commande de chantier (Terrain & achats : EXBTR.savePo) ouvre un dossier et son PAIEMENT (EXBTR.payPo) exige « Validé » ;
 *                  une commande ERP (EXB_ERP.createPurchaseOrder) ouvre un dossier ; « Validé » → status approved, « Refusé » → rejected ;
 *                  la réception d'une commande non validée est refusée.
 *   Congés       : une demande ouvre un dossier ; l'approbation directe (✔/✖) est remplacée par le circuit ; la décision finale est
 *                  appliquée à la demande (approuvé / refusé).
 *   Certificats  : l'export du PDF (= émission) exige un dossier « Validé ».
 *
 * Tout est DÉSACTIVÉ par défaut : rien ne change tant que la direction n'a pas coché un lien (Workflow > « Liens avec les modules »)
 * et qu'un circuit actif existe pour ce type. Un dossier validé est lié à une empreinte du document : si le devis / le certificat est
 * modifié ensuite, il faut une nouvelle validation. Données : exb_wf_liens (réglages). Aucun SQL.
 * Pour retirer : supprimer la balise <script src="exb-workflow-liens.js"> (les modules reprennent leur comportement d'origine). */
(function (w, d) {
  'use strict';
  if (w.EXBWFL) return;
  var CFGK = 'exb_wf_liens', CIRK = 'exb_wf_circuits', DOSK = 'exb_wf_dossiers', PAYK = 'exb_payroll';
  var LABEL = { devis: 'Devis (export / impression du PDF)', facture: 'Factures (export du PDF)', depense: 'Dépenses de caisse (sorties)', achat: 'Achats : bons de commande (paiement) et commandes ERP (réception)', conge: 'Congés', certificat: 'Certificats (export du PDF)' };
  var WITH_SEUIL = { devis: 1, facture: 1, depense: 1, achat: 1 };
  var APPLK = 'exb_wf_appl';

  /* ============================ MOTEUR PUR ============================ */
  function num(x) { x = +x; return isFinite(x) ? x : 0; }
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  /* empreinte courte et stable d'un document (détecte une modification après validation) */
  function fp(parts) {
    var s = (parts || []).map(norm).join('|'), h = 5381;
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(16) + '.' + s.length;
  }
  /* Faut-il passer par le workflow ? seuil dans la devise du seuil ; devise différente ou montant inconnu → oui (prudence) */
  function needs(cfg, type, montant, devise) {
    var c = cfg && cfg[type]; if (!c || !c.on) return false;
    var seuil = num(c.seuil); if (!WITH_SEUIL[type] || seuil <= 0) return true;
    if (montant == null || montant === '' || !isFinite(+montant)) return true;
    if (String(devise || '').toUpperCase() !== String(c.devise || 'USD').toUpperCase()) return true;
    return num(montant) >= seuil;
  }
  /* état du dossier lié à un document : none | en_cours | retourne | valide | refuse | modifie */
  function state(dossiers, type, refId, f) {
    var L = (dossiers || []).filter(function (x) { return x && x.ref && x.ref.module === type && String(x.ref.id) === String(refId) && x.status !== 'annule'; })
      .sort(function (a, b) { return String(b.cree).localeCompare(String(a.cree)); });
    var x = L[0]; if (!x) return { s: 'none' };
    /* une version identique déjà validée l'emporte (retour à la version validée après une modification annulée) */
    var vok = L.filter(function (k) { return k.status === 'valide' && k.ref.fp === f; })[0]; if (vok) return { s: 'valide', dossier: vok };
    if (x.status === 'valide') return x.ref.fp === f ? { s: 'valide', dossier: x } : { s: 'modifie', dossier: x };
    if (x.status === 'refuse') return x.ref.fp === f ? { s: 'refuse', dossier: x } : { s: 'none', dossier: x };
    return { s: x.status, dossier: x };
  }
  function quoteInfo(q) {
    q = q || {}; var L = q.lines || q.rows || null, tot = null;
    if (Array.isArray(L)) { tot = L.reduce(function (a, l) { return a + (l && !l.info ? num(l.qty != null ? l.qty : l.q) * num(l.pu) : 0); }, 0); tot = Math.round(tot * (1 + Math.max(0, num(q.imp)) / 100) * 100) / 100; } /* imp = « divers & imprévus » en % */
    var id = q.no || q.id || '';
    return { id: id, titre: 'Devis ' + id + (q.client ? ' — ' + q.client : ''), montant: tot, devise: q.currency || q.devise || 'USD',
      fp: fp([id, q.client, q.project, q.currency, q.imp, Array.isArray(L) ? L.map(function (l) { return [l && l.designation, l && (l.qty != null ? l.qty : l.q), l && l.pu].join(':'); }).join(';') : '?']) };
  }
  function cur(c) { return /^(FC|CDF)$/i.test(String(c || '')) ? 'CDF' : String(c || 'USD').toUpperCase(); }
  /* facture (exb_invoices) : montant = TTC ; l'empreinte ignore les paiements (ils changent après l'émission) */
  function invoiceInfo(i) {
    i = i || {}; var L = i.lines || [], ht = L.reduce(function (a, l) { return a + num(l && l.q) * num(l && l.pu); }, 0), tva = num(i.tva);
    return { id: i.id, titre: 'Facture ' + (i.no || '') + (i.client ? ' — ' + i.client : ''), montant: Math.round(ht * (1 + tva / 100) * 100) / 100, devise: cur(i.currency),
      fp: fp([i.no, i.client, i.currency, i.tva, i.project_id, L.map(function (l) { return [l && l.d, l && l.q, l && l.pu].join(':'); }).join(';')]) };
  }
  /* sortie de caisse : l'écriture est retenue par le workflow jusqu'à validation ; le dossier porte une copie de l'écriture */
  function cashInfo(e) {
    e = e || {}; return { id: e.id, titre: 'Dépense — ' + (e.label || '') + (e.category ? ' (' + e.category + ')' : ''), montant: num(e.amount), devise: cur(e.currency || e.devise), payload: e,
      fp: fp([e.id, e.label, e.amount, e.date]) };
  }
  /* sorties qui passent par le circuit : manuelles seulement (pas les imports automatiques, paies, paiements de commandes déjà validées) */
  function cashGated(e, cfgv) {
    if (!e || e.type !== 'out' || e.wf_ok || e.src || e.po_id || e.invoice_id || e.idem || e.ref === 'POINTAGE') return false;
    var i = cashInfo(e); return needs(cfgv, 'depense', i.montant, i.devise);
  }
  function certInfo(c) {
    c = c || {}; return { id: c.cert_no || '', titre: 'Certificat ' + (c.cert_no || '') + (c.holder ? ' — ' + c.holder : ''), montant: 0, devise: '',
      fp: fp([c.cert_no, c.holder, c.training, c.start_date, c.end_date, c.mention]) };
  }
  function congeInfo(c) {
    c = c || {}; return { id: c.id, titre: 'Congé ' + (c.kind || '') + ' — ' + (c.emp || '') + ' (' + (c.from || '?') + ' → ' + (c.to || '?') + ')', montant: 0, devise: '', fp: fp([c.emp, c.kind, c.from, c.to]) };
  }
  /* bon de commande du module Terrain & achats (exb-terrain.js) : lignes {d, q, pu, rec} ; la réception (rec) ne change pas l'empreinte */
  function poInfo(p, suppliers) {
    p = p || {}; var tot = (p.lines || []).reduce(function (a, l) { return a + num(l && l.q) * num(l && l.pu); }, 0);
    var s = (suppliers || []).filter(function (x) { return x && x.id === p.supplier_id; })[0];
    return { id: p.id, titre: 'Bon de commande ' + (p.no || p.id) + (s && s.name ? ' — ' + s.name : ''), montant: Math.round(tot * 100) / 100, devise: 'USD',
      fp: fp([p.id, p.supplier_id].concat((p.lines || []).filter(function (l) { return l && l.d; }).map(function (l) { return [l.d, l.u, l.q, l.pu].join(':'); }))) };
  }
  function orderInfo(o) {
    o = o || {}; var m = o.total != null ? o.total : o.amount != null ? o.amount : o.montant != null ? o.montant : (o.quantity != null && o.price != null ? num(o.quantity) * num(o.price) : null);
    var who = o.supplier_name || o.supplier || o.fournisseur || '';
    return { id: o.id, titre: 'Commande ' + (o.id || '') + (who ? ' — ' + who : ''), montant: m == null ? null : num(m), devise: o.currency || o.devise || 'USD', fp: fp([o.id]) };
  }
  /* décisions à appliquer : { conge: [{id, to}], achat: [{id, to}] } d'après les dossiers terminés et l'état actuel des demandes / commandes */
  function pendingApply(dossiers, conges, orders, cash, applied) {
    var out = { conge: [], achat: [], depense: [] }, done = {}; (applied || []).forEach(function (k) { done[k] = 1; });
    (dossiers || []).forEach(function (x) {
      if (!x || !x.ref || (x.status !== 'valide' && x.status !== 'refuse')) return;
      if (x.ref.module === 'conge') { var c = (conges || []).filter(function (k) { return k.id === x.ref.id; })[0]; if (c && c.status === 'demandé') out.conge.push({ id: c.id, to: x.status === 'valide' ? 'approuvé' : 'refusé' }); }
      if (x.ref.module === 'achat') { var o = (orders || []).filter(function (k) { return k.id === x.ref.id; })[0]; if (o && o.status === 'pending_approval') out.achat.push({ id: o.id, to: x.status === 'valide' ? 'approved' : 'rejected' }); }
      if (x.ref.module === 'depense' && x.ref.payload && !done[x.ref.id]) {
        var there = (cash || []).some(function (k) { return k.id === x.ref.id; });
        out.depense.push({ id: x.ref.id, no: x.no, to: x.status === 'valide' ? 'ok' : 'ko', entry: x.ref.payload, present: there });
      }
    });
    return out;
  }
  var ENGINE = { fp: fp, needs: needs, state: state, invoiceInfo: invoiceInfo, cashInfo: cashInfo, cashGated: cashGated, quoteInfo: quoteInfo, poInfo: poInfo, certInfo: certInfo, congeInfo: congeInfo, orderInfo: orderInfo, pendingApply: pendingApply };

  /* ============================ STOCKAGE ============================ */
  function store() { try { return w.exbStorage || w.localStorage; } catch (e) { return null; } }
  function rd(k, def) { try { var s = store(), v = s && s.getItem(k); if (v == null && w.localStorage) v = w.localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function wr(k, v) { try { var s = store(); s.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function list(k) { try { if (w.EXBS && w.EXBS.get) { var a = w.EXBS.get(k); if (Array.isArray(a)) return a; } } catch (e) {} var v = rd(k, []); return Array.isArray(v) ? v : []; }
  function putList(k, a) { try { if (w.EXBS && w.EXBS.set) { w.EXBS.set(k, a); return true; } } catch (e) {} return wr(k, a); }
  function cfg() { var c = rd(CFGK, {}); return c && typeof c === 'object' && !Array.isArray(c) ? c : {}; }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'info', 7000); } catch (e) {} }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function hasCircuit(type) { return list(CIRK).some(function (c) { return c && c.type === type && c.actif !== false; }); }
  function ask(msg) { try { if (typeof w.exbConfirm === 'function') return Promise.resolve(w.exbConfirm(msg)); } catch (e) {} return Promise.resolve(typeof w.confirm === 'function' ? w.confirm(msg) : false); }

  /* ============================ PORTE DE VALIDATION ============================ */
  function submitFor(type, info, extra) {
    if (!w.EXBWF) return { ok: false, error: 'Module Workflow absent.' };
    return w.EXBWF.submit({ type: type, titre: info.titre, montant: info.montant, devise: info.devise, description: extra || '', ref: { module: type, id: info.id, fp: info.fp, payload: info.payload } });
  }
  /* true = l'action peut continuer ; false = bloquée (un message est affiché, et on propose de soumettre au circuit) */
  function gate(type, info, what) {
    var c = cfg(); if (!needs(c, type, info.montant, info.devise)) return true;
    if (!w.EXBWF) return true; /* module Workflow retiré : on ne bloque pas */
    var st = state(w.EXBWF.list(), type, info.id, info.fp);
    if (st.s === 'valide') return true;
    var no = st.dossier ? st.dossier.no : '';
    if (st.s === 'en_cours') { say('Validation en cours' + (no ? ' (' + no + ')' : '') + ' : ' + what + ' sera possible une fois le dossier validé (✅ Workflow).', 'warn'); return false; }
    if (st.s === 'retourne') { say('Le dossier ' + no + ' est à corriger : corrigez puis soumettez-le à nouveau dans ✅ Workflow.', 'warn'); return false; }
    if (st.s === 'refuse') { say('Le dossier ' + no + ' a été refusé : ' + what + ' est impossible.', 'error'); return false; }
    var why = st.s === 'modifie' ? 'Le document a été modifié depuis sa validation (' + no + ').' : 'Ce document doit être validé avant ' + what + '.';
    ask(why + '\n\nLe soumettre maintenant au circuit de validation ?').then(function (yes) {
      if (!yes) return;
      var r = submitFor(type, info, st.s === 'modifie' ? 'Nouvelle validation après modification du document.' : '');
      if (!r.ok) return say(r.error, 'error');
      audit('workflow.lien.soumis', r.dossier.no, { type: type, ref: String(info.id).slice(0, 40) });
      say('Soumis pour validation : ' + r.dossier.no + '. ' + what.charAt(0).toUpperCase() + what.slice(1) + ' sera possible une fois validé.', 'success');
    });
    return false;
  }

  /* la liste vivante de la caisse (let/const global de index.html : accessible par son nom, pas via window) */
  function liveCash() { try { return typeof exbCash !== 'undefined' && Array.isArray(exbCash) ? exbCash : null; } catch (e) { return null; } }

  /* ============================ APPLICATION DES DÉCISIONS ============================ */
  var origCg = null, busy = false, timer = 0, savingCash = false;
  function applyDecisions() {
    if (busy) return; busy = true;
    try {
      var ps = list(PAYK), orders = w.EXB_ERP && w.EXB_ERP.keys ? list(w.EXB_ERP.keys.orders) : [];
      var todo = pendingApply(list(DOSK), ps.filter(function (x) { return x && x.type === 'conge'; }), orders);
      var cashKey = 'exb_cash', applied = list(APPLK), live = liveCash(), cashNow = live || list(cashKey);
      var td = pendingApply(list(DOSK), [], [], cashNow, applied).depense;
      if (td.length) {
        var done2 = applied.slice(), arr = cashNow;
        td.forEach(function (a) {
          if (a.to === 'ok' && !a.present) { var e = Object.assign({}, a.entry, { wf_ok: a.no }); arr.push(e); audit('workflow.lien.applique', a.id, { module: 'depense', statut: 'validee' }); }
          else if (a.to === 'ko') audit('workflow.lien.applique', a.id, { module: 'depense', statut: 'refusee' });
          done2.push(a.id);
        });
        savingCash = true; try { if (live && typeof w.exbSave === 'function') w.exbSave(cashKey, arr); else putList(cashKey, arr); } catch (e) {} savingCash = false;
        putList(APPLK, done2.slice(-2000)); try { w.renderExbCash && w.renderExbCash(); w.updateExbDirection && w.updateExbDirection(); } catch (e) {}
      }
      todo.conge.forEach(function (a) { if (origCg) { origCg(a.id, a.to); audit('workflow.lien.applique', a.id, { module: 'conge', statut: a.to }); } });
      if (todo.achat.length) {
        var key = w.EXB_ERP.keys.orders, all = list(key), changed = false;
        todo.achat.forEach(function (a) { all.forEach(function (o) { if (o.id === a.id && o.status === 'pending_approval') { o.status = a.to; o.workflow = true; changed = true; audit('workflow.lien.applique', a.id, { module: 'achat', statut: a.to }); } }); });
        if (changed) { putList(key, all); try { w.EXB_ERP.refresh && w.EXB_ERP.refresh(); } catch (e) {} }
      }
    } catch (e) { try { console.warn('[EXBWFL]', e); } catch (x) {} }
    busy = false;
  }
  function applySoon() { clearTimeout(timer); timer = setTimeout(applyDecisions, 700); }

  /* ============================ BRANCHEMENTS ============================ */
  var done = {};
  function wrapGlobal(name, mk) { var o = w[name]; if (typeof o !== 'function' || o.__wfl) return false; var n = mk(o); n.__wfl = 1; w[name] = n; return true; }
  function installDevis() {
    if (done.devis) return;
    var q = function (from) { return function () { try { return from(); } catch (e) { return null; } }; };
    var fromForm = q(function () { return w.exbQuoteFromForm(); });
    var any = false;
    ['exportExbQuotePdf', 'printExbQuote', 'exportExbQuotePdfSimple'].forEach(function (nm) {
      any = wrapGlobal(nm, function (o) { return function () { var inf = quoteInfo(fromForm()); if (inf.id && !gate('devis', inf, 'l\u2019export du devis')) return; return o.apply(this, arguments); }; }) || any;
    });
    any = wrapGlobal('exbQuotePdfById', function (o) { return function (id) { var x = null; try { x = (w.exbQuotes || []).filter(function (k) { return k.id === id; })[0]; } catch (e) {} if (x && !gate('devis', quoteInfo(x), 'l\u2019export du devis')) return; return o.apply(this, arguments); }; }) || any;
    if (w.EXBMetre && typeof w.EXBMetre.quotePdf === 'function' && !w.EXBMetre.quotePdf.__wfl) {
      var om = w.EXBMetre.quotePdf; w.EXBMetre.quotePdf = function (x) { if (x && !gate('devis', quoteInfo(x), 'l\u2019export du devis')) return; return om.apply(this, arguments); }; w.EXBMetre.quotePdf.__wfl = 1; any = true;
    }
    if (any) done.devis = 1;
  }
  function installCert() {
    if (done.cert) return;
    done.cert = wrapGlobal('exportCertPdf', function (o) { return function () {
      var inf = null; try { inf = certInfo(w.certData()); } catch (e) {}
      if (inf && inf.id && !gate('certificat', inf, 'l\u2019export du certificat')) return Promise.resolve();
      return o.apply(this, arguments);
    }; });
  }
  function conges() { return list(PAYK).filter(function (x) { return x && x.type === 'conge'; }); }
  function installConge() {
    var P = w.EXBPAY; if (done.conge || !P || typeof P.cg !== 'function' || typeof P.addCg !== 'function') return;
    origCg = P.cg; var oAdd = P.addCg;
    P.addCg = function () {
      var before = conges().map(function (c) { return c.id; }), r = oAdd.apply(this, arguments);
      try {
        if (cfg().conge && cfg().conge.on && w.EXBWF) conges().forEach(function (c) {
          if (before.indexOf(c.id) >= 0 || c.status !== 'demandé') return;
          var inf = congeInfo(c), res = submitFor('conge', inf, 'Demande de congé.');
          if (res.ok) { audit('workflow.lien.soumis', res.dossier.no, { type: 'conge', ref: c.id }); say('Demande de congé soumise au circuit de validation (' + res.dossier.no + ').', 'success'); } else say(res.error + ' (Workflow > Ajouter les circuits modèles)', 'warn');
        });
      } catch (e) {} return r;
    };
    P.cg = function (id, s) {
      var on = cfg().conge && cfg().conge.on && w.EXBWF, c = conges().filter(function (x) { return x.id === id; })[0];
      if (!on || !c) return origCg.apply(this, arguments);
      var st = state(w.EXBWF.list(), 'conge', id, congeInfo(c).fp);
      if (s === 'approuvé') { if (gate('conge', congeInfo(c), 'l\u2019approbation du congé')) return origCg.apply(this, arguments); return; }
      if (st.s === 'en_cours' || st.s === 'retourne') { say('Cette demande suit un circuit de validation : refusez-la dans ✅ Workflow (motif obligatoire).', 'warn'); return; }
      return origCg.apply(this, arguments);
    };
    done.conge = 1;
  }
  function installAchat() {
    var E = w.EXB_ERP; if (done.achat || !E || typeof E.createPurchaseOrder !== 'function' || typeof E.receiveOrder !== 'function') return;
    var oc = E.createPurchaseOrder, orc = E.receiveOrder;
    E.createPurchaseOrder = function (data) {
      var r = oc.apply(this, arguments);
      try {
        var inf = orderInfo(r); if (needs(cfg(), 'achat', inf.montant, inf.devise) && w.EXBWF) {
          var res = submitFor('achat', inf, 'Commande d\u2019achat.');
          if (res.ok) { audit('workflow.lien.soumis', res.dossier.no, { type: 'achat', ref: r.id }); say('Commande soumise au circuit de validation (' + res.dossier.no + ').', 'success'); } else say(res.error + ' (Workflow > Ajouter les circuits modèles)', 'warn');
        }
      } catch (e) {} return r;
    };
    E.receiveOrder = function (data) {
      try {
        if (cfg().achat && cfg().achat.on && w.EXBWF && data && data.order_id) {
          var st = state(w.EXBWF.list(), 'achat', data.order_id, fp([data.order_id]));
          if (st.s !== 'none' && st.s !== 'valide') throw new Error('Commande en attente de validation (Workflow) : réception impossible.');
        }
      } catch (e) { if (/Workflow/.test(e.message)) throw e; }
      return orc.apply(this, arguments);
    };
    done.achat = 1;
  }
  function installFacture() {
    var A = w.EXBCH; if (!A || typeof A.pdf !== 'function' || A.__wflPdf) return; /* drapeau sur l'objet : un autre module (garde-fous de saisie) peut envelopper notre fonction sans conserver notre marque ; un nouvel objet EXBCH est de nouveau enveloppé */
    var o = A.pdf; A.pdf = function (id) {
      var i = null; try { i = list('exb_invoices').filter(function (x) { return x.id === id; })[0]; } catch (e) {}
      if (i && !gate('facture', invoiceInfo(i), 'l\u2019émission de la facture')) return; return o.apply(this, arguments);
    }; A.pdf.__wfl = 1; A.__wflPdf = 1;
  }
  /* Caisse : toute sortie manuelle enregistrée par un écran (Caisse, dépenses de chantier, budget) est retenue AVANT l'enregistrement si elle
   * dépasse le seuil : l'écriture est retirée de la liste, un dossier la porte, et elle est ajoutée à la caisse à la validation. */
  function installCaisse() {
    if (typeof w.exbSave !== 'function' || w.exbSave.__wfl || w.__wflSave) return;
    var o = w.exbSave; w.exbSave = function (k, v) {
      try {
        if (k === 'exb_cash' && Array.isArray(v) && !savingCash && w.EXBWF) {
          var c = cfg(); if (c.depense && c.depense.on) {
            var prev = {}; list('exb_cash').forEach(function (x) { prev[x.id] = 1; });
            var held = v.filter(function (e) { return e && e.id && !prev[e.id] && cashGated(e, c); });
            if (held.length) {
              held.forEach(function (e) {
                var inf = cashInfo(e), res = submitFor('depense', inf, 'Sortie de caisse retenue jusqu\u2019à validation.');
                if (res.ok) { v.splice(v.indexOf(e), 1); audit('workflow.lien.soumis', res.dossier.no, { type: 'depense', ref: String(e.id).slice(0, 40) }); say('Dépense soumise pour validation (' + res.dossier.no + ') : elle sera ajoutée à la caisse une fois validée.', 'warn'); }
                else say(res.error + ' (Workflow > Ajouter les circuits modèles) — dépense enregistrée sans validation.', 'warn');
              });
            }
          }
        }
      } catch (e) {}
      return o.apply(this, arguments);
    }; w.exbSave.__wfl = 1; w.__wflSave = 1;
  }
  var POK = 'exb_purchase_orders', SUPK = 'exb_suppliers';
  function installTerrain() {
    var T = w.EXBTR; if (done.terrain || !T || typeof T.savePo !== 'function' || typeof T.payPo !== 'function') return;
    var osave = T.savePo, opay = T.payPo;
    T.savePo = function () {
      var before = list(POK).map(function (p) { return p.id; }), r = osave.apply(this, arguments);
      try {
        list(POK).forEach(function (p) {
          if (before.indexOf(p.id) >= 0) return;
          var inf = poInfo(p, list(SUPK)); if (!needs(cfg(), 'achat', inf.montant, inf.devise) || !w.EXBWF) return;
          var res = submitFor('achat', inf, 'Bon de commande de chantier.');
          if (res.ok) { audit('workflow.lien.soumis', res.dossier.no, { type: 'achat', ref: String(p.id).slice(0, 40) }); say('Bon de commande soumis au circuit de validation (' + res.dossier.no + ') : le paiement sera possible une fois validé.', 'success'); }
          else say(res.error + ' (Workflow > Ajouter les circuits modèles)', 'warn');
        });
      } catch (e) {} return r;
    };
    T.payPo = function (id) {
      var p = list(POK).filter(function (x) { return x.id === id; })[0];
      if (p && !gate('achat', poInfo(p, list(SUPK)), 'le paiement du bon de commande')) return Promise.resolve();
      return opay.apply(this, arguments);
    };
    done.terrain = 1;
  }
  function installAll() { installDevis(); installFacture(); installCaisse(); installCert(); installConge(); installAchat(); installTerrain(); }

  /* ============================ RÉGLAGES (écran Workflow) ============================ */
  function panelHtml() {
    var c = cfg(), h = '<div id="wfl_panel" style="margin:12px 0;padding:10px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc"><b>🔗 Liens avec les modules</b>'
      + '<p style="font-size:12px;color:#475569;margin:4px 0 8px">Cochez un module pour exiger une validation Workflow. Désactivé par défaut. Un circuit actif du même type est nécessaire.</p>';
    Object.keys(LABEL).forEach(function (t) {
      var x = c[t] || {}, ok = hasCircuit(t);
      h += '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:4px 0"><label style="min-width:230px"><input type="checkbox" data-wfl="' + t + '"' + (x.on ? ' checked' : '') + '> ' + LABEL[t] + '</label>'
        + (WITH_SEUIL[t] ? '<span style="font-size:12px">dès <input type="number" min="0" step="any" data-wfl-s="' + t + '" value="' + (num(x.seuil) || '') + '" placeholder="0 = toujours" style="width:110px"> <select data-wfl-d="' + t + '"><option' + (x.devise === 'CDF' ? '' : ' selected') + '>USD</option><option' + (x.devise === 'CDF' ? ' selected' : '') + '>CDF</option></select></span>' : '')
        + '<span style="font-size:12px;color:' + (ok ? '#166534' : '#b91c1c') + '">' + (ok ? 'circuit actif' : 'aucun circuit actif') + '</span></div>';
    });
    return h + '<button type="button" id="wfl_save" style="margin-top:6px">Enregistrer les liens</button> <button type="button" id="wfl_apply" style="margin-top:6px">Appliquer les décisions en attente</button></div>';
  }
  function bindPanel(host) {
    var s = host.querySelector('#wfl_save'), a = host.querySelector('#wfl_apply');
    if (s) s.onclick = function () {
      var c = cfg(), bad = [];
      Object.keys(LABEL).forEach(function (t) {
        var on = host.querySelector('[data-wfl="' + t + '"]').checked, se = host.querySelector('[data-wfl-s="' + t + '"]'), dv = host.querySelector('[data-wfl-d="' + t + '"]');
        if (on && !hasCircuit(t)) { bad.push(LABEL[t]); on = false; }
        c[t] = { on: on, seuil: se ? Math.max(0, num(se.value)) : 0, devise: dv ? dv.value : 'USD' };
      });
      wr(CFGK, c); audit('workflow.lien.reglage', 'liens', { actifs: Object.keys(c).filter(function (t) { return c[t].on; }).join(',') });
      say(bad.length ? 'Enregistré, mais sans circuit actif (non activé) : ' + bad.join(', ') + '. Ajoutez d\u2019abord un circuit.' : 'Liens enregistrés.', bad.length ? 'warn' : 'success');
      installAll(); mountPanel();
    };
    if (a) a.onclick = function () { applyDecisions(); say('Décisions appliquées.', 'success'); };
  }
  function mountPanel() {
    var host = d && d.getElementById('exbwf'); if (!host) return;
    var old = host.querySelector('#wfl_panel'); if (old) old.parentNode.removeChild(old);
    var div = d.createElement('div'); div.innerHTML = panelHtml(); var p = div.firstChild;
    host.insertBefore(p, host.firstChild.nextSibling || null); bindPanel(host);
  }
  function watchPanel() {
    var host = d.getElementById('exbwf'); if (!host || host.__wflObs || typeof MutationObserver === 'undefined') return; host.__wflObs = 1;
    new MutationObserver(function () { if (host.style.display !== 'none' && !host.querySelector('#wfl_panel') && host.children.length) { try { mountPanel(); } catch (e) {} } }).observe(host, { childList: true });
  }

  w.EXBWFL = { version: 1, engine: ENGINE, config: cfg, gate: gate, apply: applyDecisions, install: installAll };
  if (!d) return;
  function hookShow() {
    var os = w.show; if (typeof os !== 'function' || os.__wfl) return;
    w.show = function (x) { var r = os.apply(this, arguments); if (x === 'exbwf') setTimeout(function () { try { mountPanel(); watchPanel(); } catch (e) {} }, 60); return r; }; w.show.__wfl = 1;
  }
  function boot() {
    installAll(); hookShow(); watchPanel();
    try { if (w.EXBCore && w.EXBCore.bus && !w.__wflBus) { w.__wflBus = 1; ['workflow.valide', 'workflow.refuse'].forEach(function (n) { w.EXBCore.bus.on(n, applySoon); }); w.EXBCore.bus.on('data.changed', function (ev) { if (ev && ev.payload && ev.payload.key === DOSK) applySoon(); }); } } catch (e) {}
    applySoon();
  }
  [1500, 4000, 10000, 20000].forEach(function (ms) { setTimeout(boot, ms); });
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
