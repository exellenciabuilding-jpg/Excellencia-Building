/* Excellencia Building V186 — 📡 SUPERVISION DU SERVEUR (module 11 « Server »).
 * Écran de supervision + alertes de disponibilité, côté application (aucun serveur à installer) :
 *   · sondes : connexion internet, API Supabase (santé auth), serveur de licences, + points de contrôle ajoutés par l'administrateur
 *     (ex. moteur documents) ; mesure du temps de réponse, délai maximum 8 s ;
 *   · historique local (288 relevés max par sonde, ≈ 24 h à un relevé / 5 min) → disponibilité 24 h, pannes consécutives, dernière panne ;
 *   · états : « en service », « dégradé » (réponse lente ≥ 3 s ou 1 échec), « en panne » (≥ 2 échecs consécutifs) ;
 *   · ALERTES : passage en panne / retour en service journalisés (journal d'audit CORE), badge sur le bouton, notification à l'ouverture ;
 *   · « reprise des traitements » : relance de l'envoi des opérations Workflow en attente (boîte d'envoi) et des nettoyages différés de l'espace serveur ;
 *   · file d'attente : nombre d'opérations en attente d'envoi.
 * Limites : la sonde tourne tant que l'application est ouverte (pas de surveillance 24 h/24 quand elle est fermée) ; une sonde « no-cors » prouve que
 * l'adresse répond, pas que le service est correct. Réservé à l'administrateur. Retirer : supprimer la balise <script src="exb-supervision.js">. */
(function (w, d) {
  'use strict';
  if (w.EXBSUP) return;
  var HK = 'exb_sup_histo', CK = 'exb_sup_custom', MAXH = 288, LENT = 3000, TIMEOUT = 8000, EVERY = 5 * 60000;

  /* ---------- fonctions pures (testées en Node) ---------- */
  function pushResult(hist, id, r, max) {
    var h = JSON.parse(JSON.stringify(hist || {})); var a = h[id] || (h[id] = []);
    a.push({ t: r.t, ok: !!r.ok, ms: r.ms == null ? null : Math.round(r.ms), err: r.err || '' }); if (a.length > (max || MAXH)) a.splice(0, a.length - (max || MAXH)); return h;
  }
  function etat(arr) {
    arr = arr || []; if (!arr.length) return { code: 'inconnu', lab: 'Pas encore mesuré', echecs: 0, dispo: null, ms: null };
    var n = 0; for (var i = arr.length - 1; i >= 0 && !arr[i].ok; i--) n++;
    var last = arr[arr.length - 1], ok = arr.filter(function (x) { return x.ok; }).length, dispo = Math.round(ok * 1000 / arr.length) / 10;
    var code = n >= 2 ? 'panne' : n === 1 ? 'degrade' : (last.ms != null && last.ms >= LENT ? 'degrade' : 'ok');
    return { code: code, lab: { ok: 'En service', degrade: 'Dégradé', panne: 'En panne' }[code], echecs: n, dispo: dispo, ms: last.ms, t: last.t, err: last.err || '' };
  }
  /* alertes à journaliser : transition entre l'état précédent et le nouvel état (jamais de doublon tant que l'état ne change pas) */
  function transition(avant, apres) {
    if (avant === apres || avant === 'inconnu') return '';
    if (apres === 'panne') return 'panne';
    if (apres === 'ok' && (avant === 'panne' || avant === 'degrade')) return 'retour';
    return '';
  }
  function derniere(arr) { for (var i = (arr || []).length - 1; i >= 0; i--) if (!arr[i].ok) return arr[i].t; return ''; }
  function sanitizeUrl(u) { u = String(u || '').trim(); return /^https:\/\/[^\s]+$/i.test(u) ? u : ''; }

  /* ---------- stockage / contexte ---------- */
  function ls(k, def) { try { var v = JSON.parse(w.localStorage.getItem(k)); return v == null ? def : v; } catch (e) { return def; } }
  function ss(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function audit(a, x) { try { w.EXBCore && w.EXBCore.audit.log(a, 'supervision', x || {}); } catch (e) {} }
  function info() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || { on: false }; } catch (e) { return { on: false }; } }
  function allowed() { var i = info(); return !i.on || i.role === 'admin' || i.fonction === 'polyvalent'; }
  function sbUrl() { try { return (w.exbSb && w.exbSb.cfg && w.exbSb.cfg().url) || (w.EXB_SUPABASE && w.EXB_SUPABASE.url) || ''; } catch (e) { return ''; } }
  function licUrl() { try { return (w.EXBLIC && w.EXBLIC.CFG && w.EXBLIC.CFG.server) || ''; } catch (e) { return ''; } }
  function sondes() {
    var s = [{ id: 'net', nom: 'Connexion internet', local: true }];
    if (sbUrl()) s.push({ id: 'supabase', nom: 'Base et fichiers (Supabase)', url: sbUrl().replace(/\/+$/, '') + '/auth/v1/health', cors: true });
    if (licUrl()) s.push({ id: 'licences', nom: 'Serveur de licences', url: licUrl() });
    ls(CK, []).forEach(function (c, i) { if (c && sanitizeUrl(c.url)) s.push({ id: 'c' + i, nom: c.nom || ('Point ' + (i + 1)), url: c.url }); });
    return s;
  }
  function ping(s) {
    var t0 = Date.now();
    if (s.local) return Promise.resolve({ t: new Date().toISOString(), ok: w.navigator.onLine !== false, ms: 0, err: w.navigator.onLine === false ? 'hors connexion' : '' });
    if (w.navigator.onLine === false) return Promise.resolve({ t: new Date().toISOString(), ok: false, ms: null, err: 'hors connexion' });
    var ctl = w.AbortController ? new w.AbortController() : null, to = setTimeout(function () { try { ctl && ctl.abort(); } catch (e) {} }, TIMEOUT), hd = {};
    try { var k = w.exbSb && w.exbSb.cfg && w.exbSb.cfg().key; if (s.cors && k) hd.apikey = k; } catch (e) {}
    return w.fetch(s.url, { method: 'GET', mode: s.cors ? 'cors' : 'no-cors', cache: 'no-store', headers: hd, signal: ctl ? ctl.signal : undefined })
      .then(function (r) { clearTimeout(to); var ok = s.cors ? r.status < 500 : true; return { t: new Date().toISOString(), ok: ok, ms: Date.now() - t0, err: ok ? '' : 'HTTP ' + r.status }; })
      .catch(function (e) { clearTimeout(to); return { t: new Date().toISOString(), ok: false, ms: null, err: e && e.name === 'AbortError' ? 'délai dépassé (8 s)' : 'injoignable' }; });
  }
  function previousCodes() { var H = ls(HK, {}), o = {}; Object.keys(H).forEach(function (k) { o[k] = etat(H[k]).code; }); return o; }
  function mesurer() {
    var S = sondes(), prev = previousCodes();
    return Promise.all(S.map(function (s) { return ping(s).then(function (r) { return { s: s, r: r }; }); })).then(function (L) {
      var H = ls(HK, {}), alerts = [];
      L.forEach(function (x) {
        H = pushResult(H, x.s.id, x.r); var nv = etat(H[x.s.id]).code, tr = transition(prev[x.s.id] || 'inconnu', nv);
        if (tr === 'panne') { audit('supervision.panne', { sonde: x.s.nom, erreur: x.r.err }); alerts.push('🔴 ' + x.s.nom + ' : en panne (' + (x.r.err || 'sans réponse') + ')'); }
        if (tr === 'retour') { audit('supervision.retour', { sonde: x.s.nom }); alerts.push('🟢 ' + x.s.nom + ' : retour en service'); }
      });
      ss(HK, H); badge(); return { H: H, alerts: alerts };
    });
  }
  function file() { var n = 0; try { n += ls('exb_wf_outbox', []).length; } catch (e) {} try { n += ls('exb_espace_todo', []).length; } catch (e) {} return n; }
  function reprise() {
    var p = Promise.resolve(); try { if (w.EXBWFS && w.EXBWFS.sync) p = Promise.resolve(w.EXBWFS.sync()); } catch (e) {}
    return p.catch(function () {}).then(function () { audit('supervision.reprise', { restant: file() }); return file(); });
  }
  function badge() {
    try { var b = d.getElementById('bsup'); if (!b) return; var H = ls(HK, {}), n = Object.keys(H).filter(function (k) { return etat(H[k]).code === 'panne'; }).length; b.textContent = '📡 Supervision' + (n ? ' 🔴' + n : ''); } catch (e) {}
  }

  /* ---------- écran ---------- */
  var COL = { ok: '#1f7a4d', degrade: '#b45309', panne: '#b91c1c', inconnu: '#64748b' }, DOT = { ok: '🟢', degrade: '🟠', panne: '🔴', inconnu: '⚪' };
  function paint(msg) {
    var c = d.getElementById('sup_c'); if (!c) return; var H = ls(HK, {}), S = sondes(), q = file();
    var h = '<div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">📡 Supervision du serveur</h3><button id="sup_x" type="button">✕</button></div>' +
      (msg && msg.length ? '<div id="sup_al" style="background:#fff1f0;border:1px solid #f3b7b1;border-radius:8px;padding:8px;margin:8px 0">' + msg.map(esc).join('<br>') + '</div>' : '') +
      '<p><button id="sup_go" type="button">↻ Mesurer maintenant</button> <button id="sup_rep" type="button">▶ Relancer les traitements en attente (' + q + ')</button></p>' +
      '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:13px"><thead><tr style="text-align:left;background:#f1f5fb"><th>Service</th><th>État</th><th>Réponse</th><th>Disponibilité</th><th>Dernière panne</th></tr></thead><tbody>' +
      S.map(function (s) { var e = etat(H[s.id]), dp = derniere(H[s.id]); return '<tr style="border-top:1px solid #e2e8f0"><td><b>' + esc(s.nom) + '</b></td><td style="color:' + COL[e.code] + '" data-etat="' + e.code + '">' + DOT[e.code] + ' ' + esc(e.lab) + (e.err && e.code !== 'ok' ? '<br><small>' + esc(e.err) + '</small>' : '') + '</td><td>' + (e.ms == null ? '—' : e.ms + ' ms') + '</td><td>' + (e.dispo == null ? '—' : e.dispo + ' %') + '</td><td>' + esc(dp ? new Date(dp).toLocaleString('fr-FR') : '—') + '</td></tr>'; }).join('') + '</tbody></table></div>' +
      '<p style="font-size:12px;color:#64748b">Disponibilité calculée sur les relevés conservés sur cet appareil (≈ 24 h). Mesure automatique toutes les 5 minutes tant que l’application est ouverte.</p>' +
      '<h4 style="margin:10px 0 4px">Points de contrôle supplémentaires</h4><p style="font-size:12px;color:#64748b">Adresse https d’un service à surveiller (par exemple le moteur documents). Vérifie que l’adresse répond.</p>' +
      '<p><input id="sup_n" placeholder="Nom" style="width:9em"> <input id="sup_u" placeholder="https://…" style="width:16em"> <button id="sup_add" type="button">Ajouter</button></p>' +
      '<ul style="font-size:13px">' + ls(CK, []).map(function (x, i) { return '<li>' + esc(x.nom) + ' — ' + esc(x.url) + ' <button type="button" data-del="' + i + '">Retirer</button></li>'; }).join('') + '</ul><p id="sup_m" style="font-weight:600"></p>';
    c.innerHTML = h;
    d.getElementById('sup_x').onclick = function () { var o = d.getElementById('sup_ov'); if (o) o.remove(); };
    d.getElementById('sup_go').onclick = function () { mesurer().then(function (r) { paint(r.alerts); }); };
    d.getElementById('sup_rep').onclick = function () { reprise().then(function (n) { paint(); d.getElementById('sup_m').textContent = n ? n + ' opération(s) encore en attente (réseau ou serveur indisponible).' : 'Aucune opération en attente.'; }); };
    d.getElementById('sup_add').onclick = function () { var u = sanitizeUrl(d.getElementById('sup_u').value), n = d.getElementById('sup_n').value.trim(); if (!u) { d.getElementById('sup_m').textContent = 'Adresse https valide requise.'; return; } var L = ls(CK, []); L.push({ nom: n || u, url: u }); ss(CK, L); audit('supervision.point.ajoute', { nom: n }); mesurer().then(function (r) { paint(r.alerts); }); };
    Array.prototype.forEach.call(c.querySelectorAll('[data-del]'), function (b) { b.onclick = function () { var L = ls(CK, []); L.splice(+b.getAttribute('data-del'), 1); ss(CK, L); audit('supervision.point.retire'); paint(); }; });
  }
  function open() {
    if (!allowed()) { try { w.notify('Accès réservé aux administrateurs.', 'warn', 5000); } catch (e) {} return; }
    audit('supervision.ouvert'); var o = d.getElementById('sup_ov'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'sup_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.innerHTML = '<div id="sup_c" style="background:var(--card,#fff);color:var(--fg,#0f172a);width:100%;max-width:820px;border-radius:12px;padding:14px;box-sizing:border-box"></div>'; d.body.appendChild(o);
    paint(); mesurer().then(function (r) { paint(r.alerts); });
  }
  function mount() {
    var a = d.getElementById('badm2') || d.getElementById('badm');
    if (a && !d.getElementById('bsup')) { var b = d.createElement('button'); b.id = 'bsup'; b.textContent = '📡 Supervision'; b.onclick = open; a.parentNode.insertBefore(b, a.nextSibling); badge(); }
  }
  function start() {
    mount(); setInterval(function () { try { if (!d.hidden) { mount(); } } catch (e) {} }, 3000);
    setInterval(function () { try { if (!d.hidden && allowed() && info().on) mesurer().then(function (r) { r.alerts.forEach(function (m) { try { w.notify(m, 'warn', 8000); } catch (e) {} }); }); } catch (e) {} }, EVERY);
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'supervision', name: 'Supervision du serveur', version: '186.0.0', area: 'Direction', provides: ['supervision.ui'] }); } catch (e) {}
  }
  w.EXBSUP = { open: open, measure: mesurer, pure: { pushResult: pushResult, etat: etat, transition: transition, derniere: derniere, sanitizeUrl: sanitizeUrl }, _file: file };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
