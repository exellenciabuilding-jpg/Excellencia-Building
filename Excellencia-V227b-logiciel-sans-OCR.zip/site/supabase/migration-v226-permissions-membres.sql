-- ===== Excellencia Building — V226 : PERMISSIONS PAR MEMBRE (Lecture, Création, Modification, Validation, Export) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run.
-- Prérequis déjà exécutés : schema-entreprise.sql, migration-v66-roles.sql, migration-v99zn-synchro-modules.sql,
--   migration-v99zo-securite-serveur.sql, migration-v99zp-double-authentification.sql, migration-v99w-equipe.sql.
-- Réexécutable sans danger. NON exécuté sur un vrai Supabase (aucun PostgreSQL dans l'environnement de développement) :
-- essayer d'abord sur la copie / le projet de recette.
--
-- PRINCIPE : une permission ne peut que RESTREINDRE, jamais élargir. Elle s'ajoute au rôle (admin / éditeur / lecteur)
-- et à la fonction (droits_fonction). Un membre sans ligne dans « permissions_membre » garde exactement ses droits actuels.
--   · Administrateur : toutes les permissions, toujours (la case « Administration » de l'écran = le rôle Administrateur).
--   · Lecture      = false : plus aucune fiche lisible (peut(...,false) refuse).
--   · Création     = false : ne peut plus ajouter de nouvelle fiche.
--   · Modification = false : ne peut plus modifier ni supprimer une fiche existante.
--   · Validation   = false : ne peut plus enregistrer une validation / un refus de calcul (validations_calcul).
--   · Export       : enregistré et lisible par le logiciel (mes_permissions), mais PAS appliqué par le serveur
--                    (une donnée lisible est exportable) : réservé au logiciel, à brancher module par module.
-- Les tables dédiées (erp_*, btp_*, caisse, paiements…) suivent Lecture et « Création ou Modification » (peut() est partagé).

do $$ begin
  if to_regclass('public.membres') is null then raise exception 'La table membres est absente : exécutez schema-entreprise.sql'; end if;
  if to_regprocedure('public.mfa_ok()') is null then raise exception 'mfa_ok() absente : exécutez migration-v99zp-double-authentification.sql'; end if;
  if to_regprocedure('public.licence_ecriture_ok(uuid)') is null then raise exception 'licence_ecriture_ok() absente : exécutez migration-v99zo-securite-serveur.sql'; end if;
  if to_regclass('public.collections_sensibles') is null then raise exception 'collections_sensibles absente : exécutez migration-v99zn-synchro-modules.sql'; end if;
end $$;

-- ---------- 1. Table des permissions (absence de ligne = aucune restriction) ----------
create table if not exists permissions_membre(
  org_id uuid not null references organisations(id) on delete cascade,
  user_id uuid not null,
  droit_lecture boolean not null default true,
  droit_creation boolean not null default true,
  droit_modification boolean not null default true,
  droit_validation boolean not null default true,
  droit_export boolean not null default true,
  maj_le timestamptz not null default now(),
  maj_par uuid,
  primary key(org_id, user_id));
alter table permissions_membre enable row level security;
drop policy if exists pm_admin on permissions_membre;
create policy pm_admin on permissions_membre for select using (est_membre(org_id, array['admin']));
drop policy if exists pm_moi on permissions_membre;
create policy pm_moi on permissions_membre for select using (user_id = auth.uid());
-- aucune politique d'écriture : modification uniquement par equipe_definir_permissions()
revoke insert, update, delete, truncate on permissions_membre from anon, authenticated;
revoke all on permissions_membre from anon;

-- ---------- 2. Contrôle d'une permission pour l'utilisateur connecté ----------
create or replace function perm_ok(p_org uuid, p_action text) returns boolean
language plpgsql stable security definer set search_path=public as $$
declare r permissions_membre; adm boolean;
begin
  select exists(select 1 from membres where org_id=p_org and user_id=auth.uid() and role='admin') into adm;
  if adm then return true; end if;
  select * into r from permissions_membre where org_id=p_org and user_id=auth.uid();
  if not found then return true; end if;
  return case p_action
    when 'lecture' then r.droit_lecture
    when 'creation' then r.droit_creation
    when 'modification' then r.droit_modification
    when 'ecriture' then (r.droit_creation or r.droit_modification)
    when 'validation' then r.droit_validation
    when 'export' then r.droit_export
    else false end;
end $$;
revoke all on function perm_ok(uuid, text) from public, anon;
grant execute on function perm_ok(uuid, text) to authenticated, service_role;

-- ---------- 3. peut() : identique à V99zp, plus la permission (jamais pour l'administrateur) ----------
create or replace function peut(p_org uuid, p_col text, p_ecrire boolean default false)
returns boolean language sql stable security definer set search_path=public as $$
  select mfa_ok() and exists(
    select 1 from membres m
    where m.org_id=p_org and m.user_id=auth.uid() and (
      m.role='admin'
      or (perm_ok(p_org, case when p_ecrire then 'ecriture' else 'lecture' end)
          and (not p_ecrire or m.role='editeur') and (
            (m.fonction='polyvalent' and not exists(select 1 from collections_sensibles s where s.collection=p_col))
            or exists(select 1 from droits_fonction d
                      where d.fonction=m.fonction and d.collection=p_col
                        and (case when p_ecrire then d.ecrire else d.lire end))
      ))
    )) $$;
grant execute on function peut(uuid,text,boolean) to authenticated;

-- ---------- 4. enregistrer() : identique à V99zo, plus Création / Modification ----------
create or replace function enregistrer(p_org uuid, p_col text, p_id text, p_data jsonb, p_base int, p_supprime boolean default false)
returns json language plpgsql security definer set search_path=public as $$
declare cur enregistrements; nv int; ex boolean;
begin
  if not peut(p_org,p_col,true) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus',0);
    return json_build_object('ok',false,'refus',true);
  end if;
  if not licence_ecriture_ok(p_org) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus licence',0);
    return json_build_object('ok',false,'refus',true,'licence',true);
  end if;
  select * into cur from enregistrements where org_id=p_org and collection=p_col and id=p_id for update;
  ex := found;
  if not perm_ok(p_org, case when ex then 'modification' else 'creation' end) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus permission',0);
    return json_build_object('ok',false,'refus',true,'permission',true);
  end if;
  if ex then
    if cur.version<>p_base then
      return json_build_object('ok',false,'conflit',true,'version',cur.version,'data',cur.data,'supprime',cur.supprime);
    end if;
    nv:=cur.version+1;
    update enregistrements set data=p_data,version=nv,supprime=p_supprime,maj=now(),maj_par=auth.uid()
      where org_id=p_org and collection=p_col and id=p_id;
  else
    if p_base<>0 then
      return json_build_object('ok',false,'conflit',true,'version',0,'data',null,'supprime',true);
    end if;
    nv:=1;
    insert into enregistrements(org_id,collection,id,data,version,supprime,maj_par) values (p_org,p_col,p_id,p_data,1,p_supprime,auth.uid());
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org,auth.uid(),p_col,p_id,case when p_supprime then 'suppression' when nv=1 then 'création' else 'modification' end,nv);
  return json_build_object('ok',true,'version',nv);
end $$;
grant execute on function enregistrer(uuid,text,text,jsonb,int,boolean) to authenticated;

-- ---------- 5. Validation des calculs d'ingénieur ----------
create or replace function validation_permise() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if new.statut in ('valide','reserves','refuse') and not perm_ok(new.org_id,'validation') then
    raise exception 'permission de validation retirée par l''administrateur';
  end if;
  return new;
end $$;
do $do$ begin
  if to_regclass('public.validations_calcul') is not null then
    drop trigger if exists validations_calcul_perm on validations_calcul;
    create trigger validations_calcul_perm before insert on validations_calcul
      for each row execute function validation_permise();
  end if;
end $do$;

-- ---------- 6. Écran Équipe : lire et définir les permissions (administrateur seulement) ----------
create or replace function equipe_permissions(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  return (select coalesce(json_agg(json_build_object('user_id',p.user_id,'lecture',p.droit_lecture,'creation',p.droit_creation,
            'modification',p.droit_modification,'validation',p.droit_validation,'export',p.droit_export)),'[]'::json)
          from permissions_membre p where p.org_id=p_org);
end $$;

create or replace function equipe_definir_permissions(p_org uuid, p_user uuid, p_lecture boolean, p_creation boolean,
  p_modification boolean, p_validation boolean, p_export boolean) returns json
language plpgsql security definer set search_path=public as $$
declare cur text;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  select role into cur from membres where org_id=p_org and user_id=p_user;
  if cur is null then raise exception 'membre introuvable'; end if;
  if cur='admin' then raise exception 'un administrateur a tous les droits : changez d''abord son rôle en Éditeur ou Lecteur'; end if;
  if coalesce(p_lecture,true) and coalesce(p_creation,true) and coalesce(p_modification,true)
     and coalesce(p_validation,true) and coalesce(p_export,true) then
    delete from permissions_membre where org_id=p_org and user_id=p_user;
  else
    insert into permissions_membre(org_id,user_id,droit_lecture,droit_creation,droit_modification,droit_validation,droit_export,maj_le,maj_par)
    values (p_org,p_user,coalesce(p_lecture,true),coalesce(p_creation,true),coalesce(p_modification,true),coalesce(p_validation,true),coalesce(p_export,true),now(),auth.uid())
    on conflict (org_id,user_id) do update set droit_lecture=excluded.droit_lecture, droit_creation=excluded.droit_creation,
      droit_modification=excluded.droit_modification, droit_validation=excluded.droit_validation, droit_export=excluded.droit_export,
      maj_le=now(), maj_par=auth.uid();
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),'permissions_membre',p_user::text,'permissions',0);
  return json_build_object('ok',true);
end $$;

-- Mes propres permissions (le logiciel s'en sert pour griser Export, etc.)
create or replace function mes_permissions(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
declare r permissions_membre;
begin
  if not exists(select 1 from membres where org_id=p_org and user_id=auth.uid()) then
    return json_build_object('lecture',false,'creation',false,'modification',false,'validation',false,'export',false);
  end if;
  select * into r from permissions_membre where org_id=p_org and user_id=auth.uid();
  if not found or exists(select 1 from membres where org_id=p_org and user_id=auth.uid() and role='admin') then
    return json_build_object('lecture',true,'creation',true,'modification',true,'validation',true,'export',true);
  end if;
  return json_build_object('lecture',r.droit_lecture,'creation',r.droit_creation,'modification',r.droit_modification,
                           'validation',r.droit_validation,'export',r.droit_export);
end $$;

revoke all on function equipe_permissions(uuid) from public, anon;
revoke all on function equipe_definir_permissions(uuid,uuid,boolean,boolean,boolean,boolean,boolean) from public, anon;
revoke all on function mes_permissions(uuid) from public, anon;
grant execute on function equipe_permissions(uuid) to authenticated;
grant execute on function equipe_definir_permissions(uuid,uuid,boolean,boolean,boolean,boolean,boolean) to authenticated;
grant execute on function mes_permissions(uuid) to authenticated;

notify pgrst, 'reload schema';

-- Vérification (à la main, connecté en administrateur) :
--  select * from permissions_membre;
--  select equipe_definir_permissions('<org>','<user>', true, false, false, true, true);   -- lecture seule + validation + export
--  Puis, connecté comme ce membre : select enregistrer('<org>','clients','test1','{}'::jsonb,0);  → {"ok":false,"refus":true,"permission":true}
