-- V215 — Architecture : droits par fonction des collections arch_programme, arch_reglementation, arch_coordination
-- RATTRAPAGE idempotent : ces trois collections (V209e à V209g) sont déclarées dans exb-db.js, mais leurs migrations ne figuraient
-- pas dans le lot « fichiers modifiés seulement » V209j. Si vous les avez déjà exécutées, cette migration ne change rien
-- (on conflict do nothing). Droits calqués sur arch_site et arch_materiaux (V209i / V209j) : à ajuster si vos migrations V209e–g
-- prévoyaient autre chose — dans ce cas, supprimez d'abord les lignes concernées de droits_fonction.
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','arch_programme',true,true),
 ('chef_projet','arch_programme',true,true),
 ('bureau_etudes','arch_programme',true,true),
 ('architecte','arch_programme',true,true),
 ('comptable','arch_programme',true,false),
 ('direction','arch_reglementation',true,true),
 ('chef_projet','arch_reglementation',true,true),
 ('bureau_etudes','arch_reglementation',true,true),
 ('architecte','arch_reglementation',true,true),
 ('comptable','arch_reglementation',true,false),
 ('direction','arch_coordination',true,true),
 ('chef_projet','arch_coordination',true,true),
 ('bureau_etudes','arch_coordination',true,true),
 ('architecte','arch_coordination',true,true),
 ('comptable','arch_coordination',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
