-- ===== Excellencia Building V221d : vérifier la migration v210f et recharger le cache de Supabase =====
-- À exécuter dans Supabase › SQL Editor › New query › Run. Sans danger : ne modifie aucune donnée.

-- 1) Droits : réaffirme l'accès des comptes connectés aux fonctions de suspension (idempotent)
do $$ begin
  if to_regprocedure('equipe_suspendre(uuid,uuid,text)') is not null then
    grant execute on function equipe_suspendre(uuid,uuid,text), equipe_reactiver(uuid,uuid), equipe_retirer(uuid,uuid),
      equipe_liste(uuid), mon_statut(uuid) to authenticated;
  end if;
end $$;

-- 2) Force PostgREST (l'API de Supabase) à relire la liste des fonctions
notify pgrst, 'reload schema';

-- 3) Contrôle : chaque ligne doit afficher « OK ». Une ligne « ABSENTE » = exécutez migration-v210f-suspension-membres.sql.
select f.nom,
       case when to_regprocedure(f.sig) is not null then 'OK' else 'ABSENTE' end as etat
from (values
  ('equipe_suspendre','equipe_suspendre(uuid,uuid,text)'),
  ('equipe_reactiver','equipe_reactiver(uuid,uuid)'),
  ('equipe_retirer','equipe_retirer(uuid,uuid)'),
  ('equipe_liste','equipe_liste(uuid)'),
  ('mon_statut','mon_statut(uuid)'),
  ('activer_par_invitation','activer_par_invitation(text)'),
  ('jeton_perime (v221c)','jeton_perime(text)')
) as f(nom,sig);
