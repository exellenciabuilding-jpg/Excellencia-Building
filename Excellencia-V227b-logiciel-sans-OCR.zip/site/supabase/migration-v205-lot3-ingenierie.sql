-- ===== Excellencia Building — V205 / cahier Multi-Espaces, LOT 3 « Ingénierie » =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v99zzf-validation-ingenieur.sql. Additive et réexécutable sans danger.
-- Testée sur PostgreSQL 16 avec un schéma Supabase simulé (voir tools/test-sql-lot3.sh).
--
--  1. T05 — Ingénieur non habilité : la validation est refusée (déjà le cas) ET la TENTATIVE EST DÉSORMAIS JOURNALISÉE
--     (journal_entreprise : « calcul refusé : <motif> »). Avant, un refus ne laissait aucune trace.
--  2. T06 — Document modifié après validation : calcul_couverture() dit si la validation couvre encore la version
--     (empreinte) présentée. Une modification change l'empreinte : la validation précédente ne couvre plus la nouvelle version.
--  3. Affectations de projets : l'administrateur affecte un projet à un collaborateur ; chacun lit ses propres affectations.
--     ATTENTION : dans ce lot, l'affectation pilote l'écran « Mes projets » de l'Espace Ingénieur. Elle ne restreint pas encore
--     la lecture de la collection « projets » côté serveur (voir LISEZ-MOI-V205).

-- ---------- 0. Prérequis ----------
do $$ begin
  if to_regclass('public.validations_calcul') is null or to_regprocedure('public.mfa_ok()') is null then
    raise exception 'Exécutez d''abord migration-v99zzf-validation-ingenieur.sql.';
  end if;
end $$;

-- ---------- 1. T05 : journaliser les tentatives refusées ----------
create or replace function calcul_refus(p_org uuid, p_no text, p_motif text)
returns json language plpgsql security definer set search_path = public as $$
begin
  -- on ne journalise que pour un membre de l'organisation (sinon l'auteur n'est pas attribuable et on évite d'écrire dans le journal d'autrui)
  if auth.uid() is not null and exists(select 1 from membres m where m.org_id = p_org and m.user_id = auth.uid()) then
    insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
    values (p_org, auth.uid(), 'validations_calcul', left(coalesce(btrim(p_no), ''), 60), left('calcul refusé : ' || coalesce(p_motif, ''), 120), 0);
  end if;
  return json_build_object('ok', false, 'refus', p_motif);
end $$;
revoke all on function calcul_refus(uuid, text, text) from public, anon, authenticated;

create or replace function calcul_valider(
  p_org uuid, p_projet text, p_type text, p_no text, p_indice text, p_digest text,
  p_statut text, p_commentaire text default '', p_declaration boolean default false)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_role text; v_ing ingenieurs_habilites; v_aal text := coalesce(auth.jwt()->>'aal', 'aal1');
  v_nom text := ''; v_ordre text := ''; v_id bigint; v_t timestamptz;
begin
  if auth.uid() is null then return calcul_refus(p_org, p_no, 'connexion_requise'); end if;
  if not mfa_ok() then return calcul_refus(p_org, p_no, 'mfa_requise'); end if;
  if p_statut not in ('emis', 'verif', 'valide', 'reserves', 'refuse') then
    return calcul_refus(p_org, p_no, 'statut_invalide'); end if;
  if length(btrim(coalesce(p_no, ''))) < 3 or length(btrim(coalesce(p_digest, ''))) < 6 or length(btrim(coalesce(p_type, ''))) < 2 then
    return calcul_refus(p_org, p_no, 'donnees_invalides'); end if;

  select m.role into v_role from membres m where m.org_id = p_org and m.user_id = auth.uid();
  if v_role is null then return calcul_refus(p_org, p_no, 'non_membre'); end if;
  if v_role not in ('admin', 'editeur') then return calcul_refus(p_org, p_no, 'ecriture_interdite'); end if;
  if not licence_ecriture_ok(p_org) then return calcul_refus(p_org, p_no, 'licence'); end if;

  if p_statut in ('valide', 'reserves', 'refuse') then
    select * into v_ing from ingenieurs_habilites h where h.org_id = p_org and h.user_id = auth.uid() and h.actif;
    if not found then return calcul_refus(p_org, p_no, 'ingenieur_habilite_requis'); end if;
    v_nom := v_ing.nom; v_ordre := v_ing.ordre;
    if p_statut in ('valide', 'reserves') then
      if v_aal <> 'aal2' then return calcul_refus(p_org, p_no, 'session_2fa_requise'); end if;
      if not coalesce(p_declaration, false) then return calcul_refus(p_org, p_no, 'declaration_requise'); end if;
    end if;
    if p_statut in ('reserves', 'refuse') and length(btrim(coalesce(p_commentaire, ''))) < 3 then
      return calcul_refus(p_org, p_no, 'commentaire_requis'); end if;
  end if;

  insert into validations_calcul(org_id, projet, type_calcul, no, indice, digest, statut, commentaire, declaration, user_id, ing_nom, ing_ordre, aal)
  values (p_org, left(coalesce(p_projet, ''), 200), left(p_type, 80), left(btrim(p_no), 60), left(coalesce(nullif(btrim(p_indice), ''), 'A'), 10),
          left(btrim(p_digest), 64), p_statut, left(coalesce(p_commentaire, ''), 600), coalesce(p_declaration, false) and p_statut in ('valide', 'reserves'),
          auth.uid(), v_nom, v_ordre, v_aal)
  returning id, cree_le into v_id, v_t;

  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), 'validations_calcul', v_id::text, 'calcul ' || p_statut, 0);

  return json_build_object('ok', true, 'id', v_id, 'ing_nom', v_nom, 'ing_ordre', v_ordre, 'date', v_t, 'statut', p_statut);
end $$;
revoke all on function calcul_valider(uuid, text, text, text, text, text, text, text, boolean) from public, anon;
grant execute on function calcul_valider(uuid, text, text, text, text, text, text, text, boolean) to authenticated;

-- ---------- 2. T06 : une validation ne couvre que la version exacte validée ----------
create or replace function calcul_couverture(p_org uuid, p_no text, p_digest text)
returns json language plpgsql stable security definer set search_path = public as $$
declare v validations_calcul;
begin
  if auth.uid() is null or not exists(select 1 from membres m where m.org_id = p_org and m.user_id = auth.uid()) then
    return json_build_object('ok', false, 'refus', 'non_membre'); end if;
  if not mfa_ok() then return json_build_object('ok', false, 'refus', 'mfa_requise'); end if;
  select * into v from validations_calcul
   where org_id = p_org and no = left(btrim(coalesce(p_no, '')), 60) and statut in ('valide', 'reserves', 'refuse')
   order by id desc limit 1;
  if not found then return json_build_object('ok', true, 'couvert', false, 'etat', 'jamais_valide'); end if;
  if v.digest = left(btrim(coalesce(p_digest, '')), 64) then
    return json_build_object('ok', true, 'couvert', v.statut in ('valide', 'reserves'), 'etat', v.statut, 'indice', v.indice,
                             'date', v.cree_le, 'ing_nom', v.ing_nom, 'ing_ordre', v.ing_ordre);
  end if;
  return json_build_object('ok', true, 'couvert', false, 'etat', 'obsolete', 'derniere_decision', v.statut, 'indice', v.indice,
                           'date', v.cree_le, 'ing_nom', v.ing_nom);
end $$;
revoke all on function calcul_couverture(uuid, text, text) from public, anon;
grant execute on function calcul_couverture(uuid, text, text) to authenticated;

-- ---------- 3. Affectations de projets ----------
create table if not exists affectations_projets(
  org_id uuid not null references organisations(id) on delete cascade,
  projet text not null check (length(btrim(projet)) between 1 and 80),
  user_id uuid not null,
  actif boolean not null default true,
  par uuid,
  maj timestamptz not null default now(),
  primary key (org_id, projet, user_id));
alter table affectations_projets enable row level security;
drop policy if exists affp_lire on affectations_projets;
create policy affp_lire on affectations_projets for select
  using (est_membre(org_id, array['admin']) or (user_id = auth.uid() and est_membre(org_id)));
revoke insert, update, delete, truncate on affectations_projets from anon, authenticated;
revoke all on affectations_projets from anon;

create or replace function affecter_projet(p_org uuid, p_projet text, p_user uuid, p_actif boolean default true)
returns json language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if length(btrim(coalesce(p_projet, ''))) < 1 then raise exception 'projet invalide'; end if;
  if not exists(select 1 from membres where org_id = p_org and user_id = p_user) then raise exception 'collaborateur introuvable'; end if;
  insert into affectations_projets(org_id, projet, user_id, actif, par) values (p_org, left(btrim(p_projet), 80), p_user, coalesce(p_actif, true), auth.uid())
  on conflict (org_id, projet, user_id) do update set actif = excluded.actif, par = auth.uid(), maj = now();
  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), 'affectations_projets', left(btrim(p_projet), 80), case when coalesce(p_actif, true) then 'affectation projet' else 'retrait affectation projet' end, 0);
  return json_build_object('ok', true);
end $$;
revoke all on function affecter_projet(uuid, text, uuid, boolean) from public, anon;
grant execute on function affecter_projet(uuid, text, uuid, boolean) to authenticated;

-- Projets affectés au compte connecté. L'administrateur et la fonction « direction » voient tout (tous = true).
create or replace function mes_projets(p_org uuid)
returns json language plpgsql stable security definer set search_path = public as $$
declare m membres; l json;
begin
  select * into m from membres where org_id = p_org and user_id = auth.uid();
  if not found then return json_build_object('ok', false, 'refus', 'non_membre'); end if;
  if m.role = 'admin' or m.fonction = 'direction' then return json_build_object('ok', true, 'tous', true, 'projets', '[]'::json); end if;
  select coalesce(json_agg(projet order by projet), '[]'::json) into l from affectations_projets where org_id = p_org and user_id = auth.uid() and actif;
  return json_build_object('ok', true, 'tous', false, 'projets', l);
end $$;
revoke all on function mes_projets(uuid) from public, anon;
grant execute on function mes_projets(uuid) to authenticated;

-- Liste complète (administrateur) : projet, collaborateur, état.
create or replace function affectations_liste(p_org uuid)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  return coalesce((select json_agg(json_build_object('projet', projet, 'user_id', user_id, 'actif', actif, 'maj', maj) order by projet) from affectations_projets where org_id = p_org), '[]'::json);
end $$;
revoke all on function affectations_liste(uuid) from public, anon;
grant execute on function affectations_liste(uuid) to authenticated;
