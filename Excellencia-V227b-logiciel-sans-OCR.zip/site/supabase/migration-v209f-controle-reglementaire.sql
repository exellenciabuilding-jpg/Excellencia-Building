-- V209F — Architecture : contrôle réglementaire (collection arch_reglementation)
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','arch_reglementation',true,true),
 ('chef_projet','arch_reglementation',true,true),
 ('bureau_etudes','arch_reglementation',true,true),
 ('architecte','arch_reglementation',true,true),
 ('comptable','arch_reglementation',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
