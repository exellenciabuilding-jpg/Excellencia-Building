-- ===== Excellencia Building — V205 / cahier Multi-Espaces, LOT 4 « Architecture » =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v99w-equipe.sql et migration-v205-lot3-ingenierie.sql.
-- Additive et réexécutable sans danger : aucune donnée existante n'est modifiée ni supprimée.
--
--  1. Nouvelle fonction de compte « architecte » (membres et invitations). Les anciennes fonctions sont conservées telles quelles.
--  2. Droits serveur de la fonction « architecte » dans droits_fonction : copie des droits du « bureau_etudes » (études, plans, BIM,
--     CDE, pièces, autorisations…), SAUF les notes de calcul de structure, en lecture seule (le calcul reste le métier de l'ingénieur).
--     Pas d'accès finances, caisse, stock, paie : ils ne figurent pas dans les droits du bureau d'études.
--     Les droits déjà personnalisés pour « architecte » sont conservés (on conflict do nothing).
--  3. equipe_inviter / equipe_modifier acceptent la fonction « architecte » (corps identiques à la V99w, seule la liste change).
--  ATTENTION : si vous avez déjà exécuté le lot 5 (formateur), ne réexécutez pas ce fichier : réexécutez migration-v205-lot5-formateur.sql à la place.
--  La validation d'un calcul reste réservée aux ingénieurs HABILITÉS (table ingenieurs_habilites, 2FA) : être architecte ne l'autorise pas.

-- ---------- 0. Prérequis ----------
do $$ begin
  if to_regclass('public.droits_fonction') is null or to_regclass('public.invitations_equipe') is null then
    raise exception 'Exécutez d''abord migration-v66-roles.sql et migration-v99w-equipe.sql.';
  end if;
  if to_regclass('public.affectations_projets') is null then
    raise exception 'Exécutez d''abord migration-v205-lot3-ingenierie.sql.';
  end if;
end $$;

-- ---------- 1. La fonction « architecte » ----------
alter table membres drop constraint if exists membres_fonction_chk;
alter table membres add constraint membres_fonction_chk check (fonction in
  ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','comptable','rh','magasinier'));

-- la contrainte des invitations porte un nom généré : on retrouve toute contrainte CHECK qui cite « fonction »
do $$ declare c record; begin
  for c in select conname from pg_constraint
           where conrelid = 'public.invitations_equipe'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%fonction%'
  loop execute format('alter table invitations_equipe drop constraint %I', c.conname); end loop;
end $$;
alter table invitations_equipe drop constraint if exists invitations_fonction_chk;
alter table invitations_equipe add constraint invitations_fonction_chk check (fonction in
  ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','comptable','rh','magasinier'));

-- ---------- 2. Droits serveur ----------
insert into droits_fonction(fonction, collection, lire, ecrire)
select 'architecte', collection, lire, case when collection = 'notes_calcul' then false else ecrire end
from droits_fonction where fonction = 'bureau_etudes'
on conflict (fonction, collection) do nothing;

-- ---------- 3. Équipe : accepter la fonction « architecte » ----------
create or replace function equipe_inviter(p_org uuid, p_email text, p_nom text default null,
  p_role text default 'editeur', p_fonction text default 'polyvalent') returns json
language plpgsql security definer set search_path=public as $$
declare em text := lower(trim(coalesce(p_email,''))); uid uuid; mx int; n int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if em !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'adresse e-mail invalide'; end if;
  if p_role not in ('admin','editeur','lecteur') then raise exception 'rôle invalide'; end if;
  if p_fonction not in ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','comptable','rh','magasinier') then
    raise exception 'fonction invalide'; end if;
  select id into uid from auth.users where lower(email)=em limit 1;
  -- limite d'utilisateurs de la licence (si l'entreprise a une licence suivie par le propriétaire)
  if to_regclass('public.licences_clients') is not null then
    execute 'select max_utilisateurs from licences_clients where org_id=$1 order by cree_le desc limit 1' into mx using p_org;
    if mx is not null then
      select count(*) into n from membres where org_id=p_org;
      n := n + (select count(*) from invitations_equipe where org_id=p_org and utilise_le is null and email<>em);
      if n >= mx and not exists(select 1 from membres where org_id=p_org and user_id=uid) then
        raise exception 'nombre maximal d''utilisateurs atteint (%)', mx; end if;
    end if;
  end if;
  if uid is not null then
    insert into membres(org_id,user_id,nom,role,fonction) values (p_org,uid,nullif(trim(p_nom),''),p_role,p_fonction)
      on conflict (org_id,user_id) do update set role=excluded.role, fonction=excluded.fonction,
        nom=coalesce(excluded.nom, membres.nom);
    delete from invitations_equipe where org_id=p_org and email=em;
    return json_build_object('statut','ajoute','email',em);
  end if;
  insert into invitations_equipe(org_id,email,nom,role,fonction,cree_par) values (p_org,em,nullif(trim(p_nom),''),p_role,p_fonction,auth.uid())
    on conflict (org_id,email) do update set nom=excluded.nom, role=excluded.role, fonction=excluded.fonction, utilise_le=null;
  return json_build_object('statut','invite','email',em);
end $$;

create or replace function equipe_modifier(p_org uuid, p_user uuid, p_role text, p_fonction text) returns json
language plpgsql security definer set search_path=public as $$
declare cur text; admins int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if p_role not in ('admin','editeur','lecteur') then raise exception 'rôle invalide'; end if;
  if p_fonction not in ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','comptable','rh','magasinier') then
    raise exception 'fonction invalide'; end if;
  select role into cur from membres where org_id=p_org and user_id=p_user;
  if cur is null then raise exception 'membre introuvable'; end if;
  select count(*) into admins from membres where org_id=p_org and role='admin';
  if cur='admin' and p_role<>'admin' and admins<=1 then raise exception 'impossible : c''est le dernier administrateur'; end if;
  update membres set role=p_role, fonction=p_fonction where org_id=p_org and user_id=p_user;
  return json_build_object('ok',true);
end $$;

revoke all on function equipe_inviter(uuid,text,text,text,text) from public, anon;
grant execute on function equipe_inviter(uuid,text,text,text,text) to authenticated;
revoke all on function equipe_modifier(uuid,uuid,text,text) from public, anon;
grant execute on function equipe_modifier(uuid,uuid,text,text) to authenticated;
