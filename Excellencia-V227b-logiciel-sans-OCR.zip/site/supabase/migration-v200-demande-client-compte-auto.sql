-- Excellencia Building V200 — Demande de projet SUR LE PORTAIL CLIENT + compte client créé automatiquement
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzzzzzzzzzzzzzz-espace-client.sql (tables client_comptes / client_sessions, client_connexion)
--             + vos fonctions actuelles de demande BTP (demande_projet_envoyer), inchangées.
--
-- PRINCIPE
--   Le client remplit sa demande sur demande.html (formulaire adapté : construction, architecture, métré & devis,
--   rénovation, autre). Cette fonction :
--     1. enregistre la demande EXACTEMENT comme avant (appel de demande_projet_envoyer → même boîte de réception,
--        même numéro de suivi / matricule, même approbation côté entreprise) ;
--     2. crée AUTOMATIQUEMENT le compte du client (identifiant = ce matricule, mot de passe = celui qu'il a choisi
--        dans le formulaire) : plus aucun code à lui remettre, il suit ses travaux depuis son espace ;
--     3. garde un résumé de la demande dans son dossier (table client_demandes), visible dans son espace même
--        avant que l'entreprise ait publié le suivi de chantier.
--   Si le téléphone a déjà un espace : aucun nouveau compte (pas de doublon) ; la demande est enregistrée quand même.
--   Si le client est déjà connecté (session), la demande est rattachée à son compte, sans nouveau mot de passe.
--
-- SÉCURITÉ
--   * Le mot de passe est haché (bcrypt) dans la base ; il n'est jamais renvoyé ni journalisé.
--   * Le matricule vient du serveur (demande_projet_envoyer), jamais du navigateur : personne ne peut « réserver »
--     le compte d'un autre client.
--   * Limite : 60 comptes créés par heure au total (anti-abus) ; blocage 15 min après 5 mots de passe faux (déjà en place).
--   * Aucune lecture directe des tables : tout passe par des fonctions.
--
-- NOTE : le compte est rattaché à la PREMIÈRE organisation (table organisations). Installation Excellencia = une seule.

create extension if not exists pgcrypto with schema extensions;

alter table public.client_comptes add column if not exists tel text;
create index if not exists client_comptes_tel_idx on public.client_comptes (tel);

create table if not exists public.client_demandes (
  id uuid primary key default gen_random_uuid(),
  compte_id uuid not null references public.client_comptes(id) on delete cascade,
  matricule text not null,
  type text not null default 'autre',
  resume jsonb not null default '{}'::jsonb,
  statut text not null default 'recue',
  created_at timestamptz not null default now()
);
create index if not exists client_demandes_compte_idx on public.client_demandes (compte_id, created_at desc);
alter table public.client_demandes enable row level security;
revoke all on public.client_demandes from anon, authenticated;
grant select on public.client_demandes to authenticated;
drop policy if exists client_demandes_org on public.client_demandes;
create policy client_demandes_org on public.client_demandes for select to authenticated using (
  exists (select 1 from public.client_comptes c where c.id = compte_id and public.peut(c.org_id, 'portails', false))
);

-- ---------- Envoi de la demande + création automatique du compte ----------
drop function if exists public.client_demande_envoyer(jsonb, text);
create or replace function public.client_demande_envoyer(p_data jsonb, p_mdp text default null, p_session text default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v_res jsonb; v_mat text; v_org uuid; v_nom text; v_tel text; v_digits text; v_type text;
  v_cid uuid; v_deja boolean := false; v_cree boolean := false; v_sess boolean := false; s record;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(p_data::text) > 20000 then raise exception 'donnees_trop_longues'; end if;
  v_nom := left(btrim(coalesce(p_data->>'name','')), 160);
  v_tel := left(btrim(coalesce(p_data->>'phone','')), 40);
  v_digits := regexp_replace(v_tel, '[^0-9]', '', 'g');
  v_type := left(coalesce(nullif(p_data->>'type_demande',''), 'autre'), 30);
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if length(v_digits) < 6 then raise exception 'telephone_invalide'; end if;

  -- Client déjà connecté : on rattache la demande à son compte (pas de nouveau mot de passe).
  if coalesce(p_session, '') <> '' then
    select c.id, c.matricule into s
      from public.client_sessions se join public.client_comptes c on c.id = se.compte_id
     where se.token_hash = public.client_sh(left(p_session, 80)) and se.expire_le > now() and not se.restreint and c.actif;
    if found then v_cid := s.id; v_sess := true; end if;
  end if;

  if not v_sess then
    if length(coalesce(p_mdp, '')) < 8 then raise exception 'mdp_court'; end if;
    if length(p_mdp) > 200 then raise exception 'mdp_long'; end if;
    v_deja := exists (select 1 from public.client_comptes where tel = v_digits);
    if not v_deja and (select count(*) from public.client_comptes where created_at > now() - interval '1 hour') >= 60 then
      raise exception 'trop_de_demandes';
    end if;
  end if;

  -- 1) La demande est enregistrée par la fonction existante (même boîte de réception, même numéro de suivi).
  execute 'select to_jsonb(public.demande_projet_envoyer($1))' into v_res using p_data;
  if jsonb_typeof(v_res) = 'string' then v_mat := upper(btrim(v_res #>> '{}'));
  else v_mat := upper(btrim(coalesce(v_res->>'matricule', ''))); end if;
  if v_mat !~ '^[A-Z0-9][A-Z0-9._/-]{3,39}$' then v_mat := null; end if;

  -- 2) Création automatique du compte (si aucun espace n'existe déjà pour ce téléphone / ce matricule).
  if not v_sess and not v_deja and v_mat is not null then
    select id into v_org from public.organisations order by cree_le limit 1;
    if v_org is not null and not exists (select 1 from public.client_comptes where upper(matricule) = v_mat) then
      insert into public.client_comptes(org_id, matricule, nom, tel, pw_hash, doit_changer)
      values (v_org, v_mat, v_nom, v_digits, extensions.crypt(left(p_mdp, 200), extensions.gen_salt('bf', 10)), false)
      returning id into v_cid;
      v_cree := true;
    end if;
  end if;

  -- 3) Résumé dans le dossier du client (visible dans son espace).
  if v_cid is not null then
    insert into public.client_demandes(compte_id, matricule, type, resume)
    values (v_cid, coalesce(v_mat, ''), v_type, p_data);
  end if;

  return jsonb_build_object('ok', true, 'matricule', v_mat, 'compte', v_cree, 'deja', v_deja, 'session', v_sess);
end $$;
revoke all on function public.client_demande_envoyer(jsonb, text, text) from public;
grant execute on function public.client_demande_envoyer(jsonb, text, text) to anon, authenticated;

-- ---------- Dossier du client (demandes envoyées) : lu avec la session du client ----------
create or replace function public.client_dossier(p_session text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c public.client_comptes; r record;
begin
  select c2.* into c from public.client_sessions se join public.client_comptes c2 on c2.id = se.compte_id
   where se.token_hash = public.client_sh(left(coalesce(p_session, ''), 80)) and se.expire_le > now() and c2.actif;
  if not found then return jsonb_build_object('ok', false, 'code', 'session'); end if;
  select restreint into r from public.client_sessions where token_hash = public.client_sh(left(p_session, 80));
  if r.restreint then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  return jsonb_build_object('ok', true, 'nom', c.nom, 'matricule', c.matricule,
    'demandes', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'matricule', d.matricule, 'type', d.type,
                   'statut', d.statut, 'cree_le', d.created_at, 'resume', d.resume) order by d.created_at desc), '[]'::jsonb)
                   from public.client_demandes d where d.compte_id = c.id));
end $$;
revoke all on function public.client_dossier(text) from public;
grant execute on function public.client_dossier(text) to anon, authenticated;

notify pgrst, 'reload schema';

-- Contrôles après exécution :
--  select proname from pg_proc where proname in ('client_demande_envoyer','client_dossier');          -- 2 lignes
--  Essai : envoyer une demande depuis demande.html → select matricule, nom, tel, doit_changer from public.client_comptes order by created_at desc limit 3;
--  → le matricule affiché à l'écran de confirmation y figure ; connexion sur espace-client.html avec le mot de passe choisi.
