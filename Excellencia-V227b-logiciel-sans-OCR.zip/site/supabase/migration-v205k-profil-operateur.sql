-- Excellencia Building V205k — Profil opérateur rattaché au COMPTE (identité, signature, sceau).
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger. Aucune dépendance sur les autres tables.
-- Principe : une ligne par compte (user_id = auth.uid()). Chaque compte lit, écrit et efface UNIQUEMENT sa ligne (RLS).
-- La signature et le sceau sont de petites images PNG stockées dans le JSON « profil ». Le profil suit donc le compte d'un appareil à l'autre.

create table if not exists public.operateur_profils (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  profil jsonb not null default '{}'::jsonb,
  maj timestamptz not null default now(),
  constraint operateur_profils_taille check (pg_column_size(profil) < 900000)
);

create or replace function public.operateur_profils_maj() returns trigger language plpgsql as $$
begin new.maj := now(); return new; end $$;
drop trigger if exists operateur_profils_maj on public.operateur_profils;
create trigger operateur_profils_maj before insert or update on public.operateur_profils
  for each row execute function public.operateur_profils_maj();

alter table public.operateur_profils enable row level security;
drop policy if exists operateur_profils_lire on public.operateur_profils;
drop policy if exists operateur_profils_creer on public.operateur_profils;
drop policy if exists operateur_profils_modifier on public.operateur_profils;
drop policy if exists operateur_profils_effacer on public.operateur_profils;
create policy operateur_profils_lire on public.operateur_profils for select to authenticated using (user_id = auth.uid());
create policy operateur_profils_creer on public.operateur_profils for insert to authenticated with check (user_id = auth.uid());
create policy operateur_profils_modifier on public.operateur_profils for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy operateur_profils_effacer on public.operateur_profils for delete to authenticated using (user_id = auth.uid());

revoke all on public.operateur_profils from anon;
grant select, insert, update, delete on public.operateur_profils to authenticated;
