-- ===== Excellencia Building — V205 / cahier Multi-Espaces, LOT 5b « Paiements déclarés → comptable » =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v99g-paiements.sql et migration-v205-lot5-formateur.sql.
-- Additive et réexécutable sans danger.
--
-- Avant : seuls les e-mails administrateur codés en dur (migration-v99g) lisaient / vérifiaient les paiements Mobile Money déclarés
-- par les apprenants. Désormais : AUSSI les membres de l'entreprise de fonction « comptable » ou « direction », et les administrateurs
-- (rôle admin). Les e-mails d'origine sont conservés. Un formateur, un architecte, etc. n'y ont PAS accès.
-- Les visiteurs continuent d'écrire uniquement par paiement_declarer().

do $$ begin
  if to_regclass('public.paiements_declares') is null then
    raise exception 'Exécutez d''abord migration-v99g-paiements.sql.';
  end if;
  if to_regclass('public.membres') is null then
    raise exception 'Exécutez d''abord schema-entreprise.sql.';
  end if;
end $$;

create or replace function public.est_comptable_direction() returns boolean
language sql stable security definer set search_path=public as $$
  select exists(select 1 from membres where user_id = auth.uid() and (role = 'admin' or fonction in ('comptable','direction'))) $$;
revoke all on function public.est_comptable_direction() from public, anon;
grant execute on function public.est_comptable_direction() to authenticated;

drop policy if exists paiements_lire on public.paiements_declares;
create policy paiements_lire on public.paiements_declares for select to authenticated
  using (lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com'])
         or public.est_comptable_direction());

drop policy if exists paiements_modifier on public.paiements_declares;
create policy paiements_modifier on public.paiements_declares for update to authenticated
  using (lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com'])
         or public.est_comptable_direction())
  with check (lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com'])
         or public.est_comptable_direction());
