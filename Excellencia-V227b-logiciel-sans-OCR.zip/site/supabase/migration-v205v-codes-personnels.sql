-- ===== Excellencia Building  V205v : UN CODE D'ACTIVATION PERSONNEL PAR MEMBRE =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : schema-entreprise.sql, migration-v99v, migration-v99w-equipe.sql et migration-v99zzj-activation-invitation.sql déjà exécutés.
--
-- Avant : toute l'entreprise partageait UN SEUL code d'invitation (celui de l'entreprise). Impossible de savoir qui l'avait utilisé,
--         ni de couper l'accès d'une personne sans changer le code de tout le monde.
-- Maintenant : chaque personne invitée (comptable 1, comptable 2, ingénieur, formateur…) reçoit SON code d'activation, lié à SON adresse e-mail.
--   • Il déverrouille le logiciel sur son appareil (écran « code d'activation ») puis sert à rejoindre l'entreprise.
--   • Il ne fonctionne qu'avec le compte créé avec l'adresse e-mail invitée : transmis à quelqu'un d'autre, il est refusé.
--   • L'administrateur peut le renouveler (l'ancien code devient inutilisable) ; il est révoqué automatiquement quand le membre est retiré.
--   • Une invitation annulée n'ouvre plus rien.
--   • Le code d'entreprise (v99zzj) continue de fonctionner pour les appareils déjà activés.
-- La limite de nombre d'utilisateurs de la licence reste appliquée.

create table if not exists codes_membres(
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organisations(id) on delete cascade,
  email text not null,
  code text not null unique,
  user_id uuid,
  cree_le timestamptz not null default now(),
  utilise_le timestamptz,
  revoque_le timestamptz,
  unique(org_id, email));
alter table codes_membres enable row level security;   -- aucune lecture/écriture directe : fonctions seulement

-- Code lisible : 8 caractères sans ambiguïté (ni 0/o ni 1/l/i), jamais déjà pris (ni par un autre membre, ni par une entreprise).
create or replace function code_perso_gen() returns text language plpgsql set search_path=public as $$
declare a text := 'abcdefghjkmnpqrstuvwxyz23456789'; s text; i int;
begin
  loop
    s := '';
    for i in 1..8 loop s := s || substr(a, 1 + floor(random() * length(a))::int, 1); end loop;
    exit when not exists(select 1 from codes_membres where code = s) and not exists(select 1 from organisations where code_invitation = s);
  end loop;
  return s;
end $$;

-- Obtenir (ou créer) le code personnel d'une personne. Administrateur de l'entreprise uniquement.
create or replace function equipe_code_membre(p_org uuid, p_email text) returns json
language plpgsql security definer set search_path=public as $$
declare em text := lower(trim(coalesce(p_email,''))); c codes_membres;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if em !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'adresse e-mail invalide'; end if;
  if not exists(select 1 from invitations_equipe where org_id=p_org and email=em)
     and not exists(select 1 from membres m join auth.users u on u.id=m.user_id where m.org_id=p_org and lower(u.email)=em) then
    raise exception 'personne introuvable dans l''équipe : invitez-la d''abord'; end if;
  select * into c from codes_membres where org_id=p_org and email=em;
  if not found then
    insert into codes_membres(org_id,email,code) values (p_org, em, code_perso_gen()) returning * into c;
  elsif c.revoque_le is not null then
    update codes_membres set code=code_perso_gen(), revoque_le=null, utilise_le=null where id=c.id returning * into c;
  end if;
  return json_build_object('email', em, 'code', c.code, 'utilise', c.utilise_le is not null);
end $$;

-- Renouveler le code d'une personne (code perdu ou transmis par erreur) : l'ancien code ne fonctionne plus.
create or replace function equipe_regenerer_code(p_org uuid, p_email text) returns json
language plpgsql security definer set search_path=public as $$
declare em text := lower(trim(coalesce(p_email,''))); c codes_membres;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  perform equipe_code_membre(p_org, em);
  update codes_membres set code=code_perso_gen(), revoque_le=null, utilise_le=null where org_id=p_org and email=em returning * into c;
  return json_build_object('email', em, 'code', c.code, 'utilise', false);
end $$;

-- Liste des codes (administrateur) : pour afficher « code utilisé / non utilisé » à côté de chaque personne.
create or replace function equipe_codes(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  return (select coalesce(json_agg(json_build_object('email',email,'code',code,'utilise',utilise_le is not null,'revoque',revoque_le is not null)),'[]'::json)
          from codes_membres where org_id=p_org);
end $$;

-- Membre retiré = son code est révoqué.
create or replace function codes_membres_revoquer() returns trigger language plpgsql security definer set search_path=public as $$
begin
  update codes_membres set revoque_le=now() where org_id=old.org_id and (user_id=old.user_id or email=(select lower(email) from auth.users where id=old.user_id));
  return old;
end $$;
drop trigger if exists trg_codes_membres_revoquer on membres;
create trigger trg_codes_membres_revoquer after delete on membres for each row execute function codes_membres_revoquer();

-- Les deux fonctions d'origine sont conservées sous un autre nom (une seule fois), puis enveloppées : un code personnel est d'abord reconnu,
-- sinon on retombe sur le comportement d'avant (code d'entreprise).
do $$ begin
  if to_regprocedure('rejoindre_organisation_org(text,text)') is null then
    alter function rejoindre_organisation(text,text) rename to rejoindre_organisation_org; end if;
  if to_regprocedure('activer_par_invitation_org(text)') is null then
    alter function activer_par_invitation(text) rename to activer_par_invitation_org; end if;
end $$;

create or replace function activer_par_invitation(p_code text) returns json
language plpgsql security definer set search_path=public as $$
declare c text := lower(trim(coalesce(p_code,''))); pc codes_membres; oc text;
begin
  select * into pc from codes_membres where code = c;
  if found then
    if pc.revoque_le is not null then
      return json_build_object('ok', false, 'msg', 'Ce code n’est plus valide. Demandez un nouveau code à l’administrateur de l’entreprise.'); end if;
    select code_invitation into oc from organisations where id = pc.org_id;
    return activer_par_invitation_org(oc);
  end if;
  return activer_par_invitation_org(p_code);
end $$;

create or replace function rejoindre_organisation(p_code text, p_nom_user text default null) returns json
language plpgsql security definer set search_path=public as $$
declare c text := lower(trim(coalesce(p_code,''))); pc codes_membres; oc text; em text; r json;
begin
  select * into pc from codes_membres where code = c;
  if not found then return rejoindre_organisation_org(p_code, p_nom_user); end if;
  if auth.uid() is null then raise exception 'non connecté'; end if;
  if pc.revoque_le is not null then raise exception 'code révoqué : demandez un nouveau code à l''administrateur'; end if;
  select lower(email) into em from auth.users where id = auth.uid();
  if em is distinct from pc.email then
    raise exception 'ce code est personnel : créez votre compte avec l''adresse e-mail invitée (%)', regexp_replace(pc.email, '^(.).*(@.*)$', '\1***\2'); end if;
  if not exists(select 1 from invitations_equipe where org_id=pc.org_id and email=pc.email and utilise_le is null)
     and not exists(select 1 from membres where org_id=pc.org_id and user_id=auth.uid()) then
    raise exception 'invitation annulée : demandez à l''administrateur de vous inviter de nouveau'; end if;
  select code_invitation into oc from organisations where id = pc.org_id;
  r := rejoindre_organisation_org(oc, p_nom_user);
  update codes_membres set user_id = auth.uid(), utilise_le = coalesce(utilise_le, now()) where id = pc.id;
  return r;
end $$;

revoke execute on function rejoindre_organisation_org(text,text), activer_par_invitation_org(text), code_perso_gen() from public, anon, authenticated;
revoke execute on function equipe_code_membre(uuid,text), equipe_regenerer_code(uuid,text), equipe_codes(uuid) from public, anon;
grant  execute on function equipe_code_membre(uuid,text), equipe_regenerer_code(uuid,text), equipe_codes(uuid) to authenticated;
revoke execute on function rejoindre_organisation(text,text) from public, anon;
grant  execute on function rejoindre_organisation(text,text) to authenticated;
revoke execute on function activer_par_invitation(text) from public;
grant  execute on function activer_par_invitation(text) to anon, authenticated;
