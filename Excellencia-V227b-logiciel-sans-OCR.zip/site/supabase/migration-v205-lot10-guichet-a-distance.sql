-- ===== Excellencia Building — V205p : GUICHET du comptable À DISTANCE (chacun son compte, synchronisation) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v205-lot9-guichet-comptable-notif-chantier.sql.
-- Additive et réexécutable sans danger. Ne supprime ni ne remplace aucun droit déjà personnalisé (on conflict do nothing),
-- sauf UN droit voulu : le comptable peut ENREGISTRER un client (fiche créée au guichet pour une personne de passage).
--
-- Deux nouvelles collections partagées (table « enregistrements », fiche par fiche, avec détection de conflit et journal) :
--   annuaire_guichet       : annuaire léger des apprenants et étudiants TFL (nom, matricule, téléphone, e-mail, formation, dossier approuvé).
--                            Publié automatiquement par le compte qui détient les apprenants (Formation / Direction), lu par le comptable.
--                            AUCUNE photo, AUCUNE note, AUCUN paiement : seulement de quoi retrouver la personne au guichet.
--   guichet_encaissements  : registre des encaissements du guichet (caisse du jour, « déjà payé ») identique sur tous les appareils.
-- Les apprenants complets restent, comme avant, dans la copie du compte qui les a saisis.

do $$ begin
  if to_regclass('public.droits_fonction') is null then
    raise exception 'Exécutez d''abord migration-v66-roles.sql.';
  end if;
end $$;

insert into droits_fonction(fonction, collection, lire, ecrire) values
 -- annuaire des apprenants : le comptable lit ; Formation (formateur) et Direction publient et lisent
 ('comptable',  'annuaire_guichet', true,  true),
 ('direction',  'annuaire_guichet', true,  true),
 ('formateur',  'annuaire_guichet', true,  true),
 ('rh',         'annuaire_guichet', true,  false),
 ('chef_projet','annuaire_guichet', true,  false),
 -- registre des encaissements
 ('comptable',  'guichet_encaissements', true, true),
 ('direction',  'guichet_encaissements', true, true),
 ('chef_projet','guichet_encaissements', true, false),
 -- le comptable lit aussi le CRM (prospects qui viennent payer) et les devis
 ('comptable',  'crm',   true, false),
 ('comptable',  'devis', true, false)
on conflict (fonction, collection) do nothing;

-- Le comptable crée la fiche d'une personne de passage dans « clients » : droit d'écriture (il était en lecture seule).
update droits_fonction set ecrire = true where fonction = 'comptable' and collection = 'clients' and ecrire = false;

-- Vérification : select fonction, collection, lire, ecrire from droits_fonction
--   where collection in ('annuaire_guichet','guichet_encaissements','clients','finance','crm') and fonction in ('comptable','direction','formateur') order by 1,2;
