-- Excellencia Building V204 (inclut V203) — Le client peut DÉCLARER SES PAIEMENTS dès l'inscription, sans que l'entreprise ait publié de portail.
-- À exécuter UNE fois (Supabase › SQL Editor), après migration-v200-demande-client-compte-auto.sql et migration-v142b-paiements-client.sql. Réexécutable.
-- Cause du message « Ce lien a été désactivé par l'entreprise » : le compte créé par la demande n'était relié à AUCUN portail,
--   or déclarer un paiement, recevoir un reçu et échanger des messages passent tous par un portail.
-- Principe : chaque compte client reçoit automatiquement un « espace brouillon » (portail_liens.brouillon = true) :
--   · invisible du client comme « suivi » (il voit toujours « Mon dossier », rien n'est publié) ;
--   · déjà utilisable pour les paiements → l'entreprise les voit dans Portails & signatures › Paiements, confirme, envoie le reçu ;
--   · quand l'entreprise relie le compte à un vrai portail (bouton « Compte client »), paiements, reçus et messages sont transférés
--     automatiquement vers le vrai portail et le brouillon est supprimé.

alter table public.portail_liens add column if not exists brouillon boolean not null default false;

create or replace function public.client_lien_brouillon(p_org uuid, p_mat text, p_nom text)
returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare v_tok text := encode(extensions.gen_random_bytes(12), 'hex'); v_id uuid; v_own uuid;
begin
  select coalesce(cree_par, '00000000-0000-0000-0000-000000000000'::uuid) into v_own from public.organisations where id = p_org;
  insert into public.portail_liens(owner, org_id, token, kind, titre, destinataire, code_hash, contenu, brouillon)
  values (coalesce(v_own, '00000000-0000-0000-0000-000000000000'::uuid), p_org, v_tok, 'client',
          left('Espace client — ' || coalesce(p_mat, ''), 160), left(coalesce(p_nom, ''), 160),
          public.portail_h(encode(extensions.gen_random_bytes(8), 'hex'), v_tok), '{}'::jsonb, true)
  returning id into v_id;
  return v_id;
end $$;
revoke all on function public.client_lien_brouillon(uuid, text, text) from public, anon, authenticated;

-- ---------- Inscription : le compte reçoit tout de suite son espace brouillon ----------
create or replace function public.client_demande_envoyer(p_data jsonb, p_mdp text default null, p_session text default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v_res jsonb; v_mat text; v_org uuid; v_nom text; v_tel text; v_digits text; v_type text;
  v_cid uuid; v_deja boolean := false; v_cree boolean := false; v_sess boolean := false; s record;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(p_data::text) > 20000 then raise exception 'donnees_trop_longues'; end if;
  v_nom := left(btrim(coalesce(p_data->>'name','')), 160);
  v_tel := left(btrim(coalesce(p_data->>'phone','')), 40);
  v_digits := regexp_replace(v_tel, '[^0-9]', '', 'g');
  v_type := left(coalesce(nullif(p_data->>'type_demande',''), 'autre'), 30);
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if length(v_digits) < 6 then raise exception 'telephone_invalide'; end if;

  -- Client déjà connecté : on rattache la demande à son compte (pas de nouveau mot de passe).
  if coalesce(p_session, '') <> '' then
    select c.id, c.matricule into s
      from public.client_sessions se join public.client_comptes c on c.id = se.compte_id
     where se.token_hash = public.client_sh(left(p_session, 80)) and se.expire_le > now() and not se.restreint and c.actif;
    if found then v_cid := s.id; v_sess := true; end if;
  end if;

  if not v_sess then
    if length(coalesce(p_mdp, '')) < 8 then raise exception 'mdp_court'; end if;
    if length(p_mdp) > 200 then raise exception 'mdp_long'; end if;
    v_deja := exists (select 1 from public.client_comptes where tel = v_digits);
    if not v_deja and (select count(*) from public.client_comptes where created_at > now() - interval '1 hour') >= 60 then
      raise exception 'trop_de_demandes';
    end if;
  end if;

  -- 1) La demande est enregistrée par la fonction existante (même boîte de réception, même numéro de suivi).
  execute 'select to_jsonb(public.demande_projet_envoyer($1))' into v_res using p_data;
  if jsonb_typeof(v_res) = 'string' then v_mat := upper(btrim(v_res #>> '{}'));
  else v_mat := upper(btrim(coalesce(v_res->>'matricule', ''))); end if;
  if v_mat !~ '^[A-Z0-9][A-Z0-9._/-]{3,39}$' then v_mat := null; end if;

  -- 2) Création automatique du compte (si aucun espace n'existe déjà pour ce téléphone / ce matricule).
  if not v_sess and not v_deja and v_mat is not null then
    select id into v_org from public.organisations order by cree_le limit 1;
    if v_org is not null and not exists (select 1 from public.client_comptes where upper(matricule) = v_mat) then
      insert into public.client_comptes(org_id, matricule, nom, tel, pw_hash, doit_changer)
      values (v_org, v_mat, v_nom, v_digits, extensions.crypt(left(p_mdp, 200), extensions.gen_salt('bf', 10)), false)
      returning id into v_cid;
      v_cree := true;
      update public.client_comptes set lien_id = public.client_lien_brouillon(v_org, v_mat, v_nom) where id = v_cid;
    end if;
  end if;

  -- 3) Résumé dans le dossier du client (visible dans son espace).
  if v_cid is not null then
    insert into public.client_demandes(compte_id, matricule, type, resume)
    values (v_cid, coalesce(v_mat, ''), v_type, p_data);
  end if;

  return jsonb_build_object('ok', true, 'matricule', v_mat, 'compte', v_cree, 'deja', v_deja, 'session', v_sess);
end $$;

-- ---------- Entreprise : « Compte client » relie le compte à un vrai portail et transfère les paiements du brouillon ----------
create or replace function public.client_compte_creer(p_org uuid, p_matricule text, p_nom text, p_token text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v_mat text := upper(btrim(coalesce(p_matricule,''))); v_lien uuid; v_id uuid; v_old uuid; v_new uuid;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  if v_mat !~ '^[A-Z0-9][A-Z0-9._/-]{3,39}$' then raise exception 'matricule_invalide'; end if;
  if coalesce(p_token,'') <> '' then
    select id into v_lien from public.portail_liens where token = p_token and org_id = p_org and kind = 'client';
    if v_lien is null then raise exception 'portail_introuvable'; end if;
  end if;
  if exists (select 1 from public.client_comptes where upper(matricule) = v_mat and org_id <> p_org) then raise exception 'matricule_pris'; end if;
  select lien_id into v_old from public.client_comptes where upper(matricule) = v_mat;
  insert into public.client_comptes(org_id, matricule, nom, lien_id, pw_hash)
  values (p_org, v_mat, left(btrim(coalesce(p_nom,'')),160), v_lien, extensions.crypt(v_mat, extensions.gen_salt('bf', 10)))
  on conflict (upper(matricule)) do update set
    nom = excluded.nom, lien_id = coalesce(excluded.lien_id, public.client_comptes.lien_id),
    -- V204 : si le client a déjà choisi son mot de passe à l'inscription (doit_changer = false), on le CONSERVE ; sinon réinitialisation = matricule
    pw_hash = case when public.client_comptes.doit_changer then excluded.pw_hash else public.client_comptes.pw_hash end,
    doit_changer = public.client_comptes.doit_changer, actif = true, essais = 0, bloque_jusqua = null
  returning id into v_id;
  select lien_id into v_new from public.client_comptes where id = v_id;
  if v_new is null then
    v_new := public.client_lien_brouillon(p_org, v_mat, left(btrim(coalesce(p_nom,'')),160));
    update public.client_comptes set lien_id = v_new where id = v_id;
  elsif v_old is not null and v_old <> v_new and exists (select 1 from public.portail_liens where id = v_old and brouillon) then
    -- le client passe de l'espace « brouillon » au vrai portail : ses paiements, reçus et messages le suivent
    update public.client_paiements set lien_id = v_new where lien_id = v_old;
    update public.client_plans set lien_id = v_new where lien_id = v_old
       and not exists (select 1 from public.client_plans q where q.lien_id = v_new and q.plan_ref = client_plans.plan_ref and q.version = client_plans.version);
    update public.portail_messages set lien_id = v_new where lien_id = v_old;
    delete from public.portail_liens where id = v_old and brouillon;
  end if;
  if exists (select 1 from public.client_comptes where id = v_id and doit_changer) then delete from public.client_sessions where compte_id = v_id; end if;
  return jsonb_build_object('ok', true, 'matricule', v_mat);
end $$;

-- ---------- Le suivi n'est affiché au client que s'il est publié (un brouillon ne contient rien) ----------
create or replace function public.portail_lire(p_token text, p_code text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; l public.portail_liens;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  -- V203 : espace « brouillon » (créé à l'inscription) : rien n'est publié → le client voit « Mon dossier » (même code que lien désactivé, pour les anciennes pages en cache)
  if exists (select 1 from public.portail_liens where id = c.v_id and brouillon) then return jsonb_build_object('ok', false, 'code', 'revoque'); end if;
  update public.portail_liens set visites = visites + 1, derniere_visite = now() where id = c.v_id returning * into l;
  return jsonb_build_object('ok', true, 'kind', l.kind, 'titre', l.titre, 'destinataire', l.destinataire, 'publie_le', l.publie_le, 'contenu', l.contenu,
    'signatures', coalesce((select jsonb_agg(jsonb_build_object('doc_id', s.doc_id, 'role', s.role, 'nom', s.nom, 'signe_le', s.signe_le, 'doc_hash', s.doc_hash)) from public.portail_signatures s where s.lien_id = l.id), '[]'::jsonb),
    'messages', coalesce((select jsonb_agg(jsonb_build_object('de', m.de, 'texte', m.texte, 'cree_le', m.cree_le) order by m.cree_le) from public.portail_messages m where m.lien_id = l.id), '[]'::jsonb),
    'declarations', coalesce((select jsonb_agg(jsonb_build_object('lot', d.lot, 'pct', d.pct, 'note', d.note, 'statut', d.statut, 'reponse', d.reponse, 'cree_le', d.cree_le) order by d.cree_le) from public.portail_declarations d where d.lien_id = l.id), '[]'::jsonb));
end $$;
revoke all on function public.portail_lire(text,text) from public;
grant execute on function public.portail_lire(text,text) to anon, authenticated;

-- ---------- Rattrapage : comptes déjà créés sans portail (ex. BTP-2026-0015) ----------
do $$
declare r record; v uuid;
begin
  for r in select id, org_id, matricule, nom from public.client_comptes where lien_id is null loop
    v := public.client_lien_brouillon(r.org_id, r.matricule, r.nom);
    update public.client_comptes set lien_id = v where id = r.id;
  end loop;
end $$;

-- ---------- V204 : « Demandes clients » dans Portails & signatures ----------
-- Un comptes client = une ligne ; l'entreprise voit pour chacun : sa demande, son espace (jeton), ses paiements à vérifier,
-- ses documents envoyés (devis…), ses messages. Lecture seule, réservée aux personnes ayant le droit « portails ».
create or replace function public.client_comptes_suivi(p_org uuid)
returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', false) then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object(
      'id', c.id, 'matricule', c.matricule, 'nom', c.nom, 'tel', c.tel, 'actif', c.actif, 'cree_le', c.created_at, 'derniere_connexion', c.derniere_connexion,
      'token', l.token, 'brouillon', coalesce(l.brouillon, false), 'portail_titre', l.titre,
      'demandes', coalesce((select jsonb_agg(jsonb_build_object('matricule', d.matricule, 'type', d.type, 'statut', d.statut, 'cree_le', d.created_at, 'resume', d.resume) order by d.created_at desc)
                              from public.client_demandes d where d.compte_id = c.id), '[]'::jsonb),
      'paiements_attente', (select count(*) from public.client_paiements x where x.lien_id = c.lien_id and x.statut = 'en_attente'),
      'paiements_total', (select count(*) from public.client_paiements x where x.lien_id = c.lien_id),
      'documents', (select count(*) from public.client_plans q where q.lien_id = c.lien_id),
      'messages_client', (select count(*) from public.portail_messages m where m.lien_id = c.lien_id and m.de <> 'entreprise'))
    order by c.created_at desc)
    from public.client_comptes c left join public.portail_liens l on l.id = c.lien_id where c.org_id = p_org), '[]'::jsonb);
end $$;
revoke all on function public.client_comptes_suivi(uuid) from public, anon;
grant execute on function public.client_comptes_suivi(uuid) to authenticated;

notify pgrst, 'reload schema';
-- Contrôle V204 : select jsonb_array_length(public.client_comptes_suivi('<org>'));  (connecté en entreprise)
-- Contrôles : select count(*) from public.client_comptes where lien_id is null;  -- 0
--             select titre, brouillon from public.portail_liens where brouillon;  -- un espace par client sans vrai portail
