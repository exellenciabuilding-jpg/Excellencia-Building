-- V209K — Architecture : règles IDS (collection arch_ids)
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','arch_ids',true,true),
 ('chef_projet','arch_ids',true,true),
 ('bureau_etudes','arch_ids',true,true),
 ('architecte','arch_ids',true,true),
 ('comptable','arch_ids',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
