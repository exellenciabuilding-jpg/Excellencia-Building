-- V209E — Architecture : programme et surfaces (collection arch_programme)
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','arch_programme',true,true),
 ('chef_projet','arch_programme',true,true),
 ('bureau_etudes','arch_programme',true,true),
 ('architecte','arch_programme',true,true),
 ('comptable','arch_programme',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
