-- Excellencia Building V224 — Modules ajoutés à la base partagée et à la supervision :
--   Congés, Courrier, Bureau d'études (dalles, géotechnique, quantitatifs, liens BIM, électricité, plomberie, topographie, VRD, dossiers),
--   Contrôle qualité (contrôles, causes, non-conformités), clôtures de projet, présences du personnel,
--   Comptabilité (avoirs, échéanciers, clôtures mensuelles, écritures OD, immobilisations, TVA achats, paie : calculs et règlements),
--   CRM (opportunités, relances, contrats, réclamations, satisfaction), Stock (dépôts, transferts, inventaires, consultations).
-- À exécuter UNE fois dans Supabase › SQL Editor, APRÈS migration-v66-roles.sql, migration-v99zn-synchro-modules.sql et migration-v223-formation-comptabilite-partage.sql.
-- Réexécutable sans danger (on conflict do nothing). NON exécuté sur un vrai Supabase : essayer d'abord sur la copie / le projet de recette.
-- Règles : administrateur = tout ; « polyvalent » = tout SAUF les collections sensibles (conges, paie_calculs, paie_reglements) ;
--          autres fonctions = uniquement les lignes ci-dessous (absence de ligne = refus). Un lecteur n'écrit jamais.
do $$ begin
  if to_regclass('public.droits_fonction') is null then
    raise exception 'La table droits_fonction est absente : exécutez d''abord migration-v66-roles.sql';
  end if;
  if to_regclass('public.collections_sensibles') is null then
    raise exception 'La table collections_sensibles est absente : exécutez d''abord migration-v99zn-synchro-modules.sql';
  end if;
end $$;

-- ---------- 1. Collections sensibles : congés et paie ----------
insert into collections_sensibles(collection) values ('conges'),('paie_calculs'),('paie_reglements') on conflict do nothing;
delete from droits_fonction where fonction='polyvalent' and collection in ('conges','paie_calculs','paie_reglements');

-- ---------- 2. Droits explicites ----------
with droits(fonction, collection, lire, ecrire) as (values
 -- Congés (RH sensible) : direction et RH seulement
 ('direction','conges',true,true),('rh','conges',true,true),
 -- Courrier : registre commun, tous les services peuvent lire et enregistrer
 ('direction','courrier',true,true),('rh','courrier',true,true),('comptable','courrier',true,true),('chef_projet','courrier',true,true),
 ('conducteur','courrier',true,true),('bureau_etudes','courrier',true,true),('architecte','courrier',true,true),('formateur','courrier',true,true),('magasinier','courrier',true,true),
 -- Présences du personnel
 ('direction','presences_rh',true,true),('rh','presences_rh',true,true),('chef_projet','presences_rh',true,true),('conducteur','presences_rh',true,true),('comptable','presences_rh',true,false),
 -- Comptabilité
 ('direction','avoirs',true,true),('comptable','avoirs',true,true),
 ('direction','echeanciers',true,true),('comptable','echeanciers',true,true),
 ('direction','clotures_compta',true,true),('comptable','clotures_compta',true,true),
 ('direction','ecritures_od',true,true),('comptable','ecritures_od',true,true),
 ('direction','immobilisations',true,true),('comptable','immobilisations',true,true),
 ('direction','tva_achats',true,true),('comptable','tva_achats',true,true),
 -- Budgets financiers (budgetfin) : comptable et direction
 ('direction','budgets_fin',true,true),('comptable','budgets_fin',true,true),('direction','tva_deductible',true,true),('comptable','tva_deductible',true,true),
 -- Contrôle qualité et clôtures de projet
 ('direction','ctl_controles',true,true),('chef_projet','ctl_controles',true,true),('conducteur','ctl_controles',true,true),('bureau_etudes','ctl_controles',true,false),('architecte','ctl_controles',true,false),
 ('direction','ctl_causes',true,true),('chef_projet','ctl_causes',true,true),('conducteur','ctl_causes',true,true),('bureau_etudes','ctl_causes',true,false),('architecte','ctl_causes',true,false),
 ('direction','ctl_non_conformites',true,true),('chef_projet','ctl_non_conformites',true,true),('conducteur','ctl_non_conformites',true,true),('bureau_etudes','ctl_non_conformites',true,false),('architecte','ctl_non_conformites',true,false),
 ('direction','clotures_projet',true,true),('chef_projet','clotures_projet',true,true),('conducteur','clotures_projet',true,false),('comptable','clotures_projet',true,false),('bureau_etudes','clotures_projet',true,false),('architecte','clotures_projet',true,false),
 -- Bureau d'études : écriture par le bureau d'études et la direction ; lecture par chef de projet, conducteur, architecte
 ('direction','be_dossiers',true,true),('bureau_etudes','be_dossiers',true,true),('chef_projet','be_dossiers',true,false),('conducteur','be_dossiers',true,false),('architecte','be_dossiers',true,false),
 ('direction','be_dalles',true,true),('bureau_etudes','be_dalles',true,true),('chef_projet','be_dalles',true,false),('conducteur','be_dalles',true,false),('architecte','be_dalles',true,false),
 ('direction','be_geotechnique',true,true),('bureau_etudes','be_geotechnique',true,true),('chef_projet','be_geotechnique',true,false),('conducteur','be_geotechnique',true,false),('architecte','be_geotechnique',true,false),
 ('direction','be_quantitatifs',true,true),('bureau_etudes','be_quantitatifs',true,true),('chef_projet','be_quantitatifs',true,false),('conducteur','be_quantitatifs',true,false),('architecte','be_quantitatifs',true,false),
 ('direction','be_liens_bim',true,true),('bureau_etudes','be_liens_bim',true,true),('chef_projet','be_liens_bim',true,false),('conducteur','be_liens_bim',true,false),('architecte','be_liens_bim',true,true),
 ('direction','be_reserves_geo',true,true),('bureau_etudes','be_reserves_geo',true,true),('chef_projet','be_reserves_geo',true,false),('conducteur','be_reserves_geo',true,false),('architecte','be_reserves_geo',true,false),
 ('direction','be_electricite',true,true),('bureau_etudes','be_electricite',true,true),('chef_projet','be_electricite',true,false),('conducteur','be_electricite',true,false),('architecte','be_electricite',true,false),
 ('direction','be_plomberie',true,true),('bureau_etudes','be_plomberie',true,true),('chef_projet','be_plomberie',true,false),('conducteur','be_plomberie',true,false),('architecte','be_plomberie',true,false),
 ('direction','be_topographie',true,true),('bureau_etudes','be_topographie',true,true),('chef_projet','be_topographie',true,false),('conducteur','be_topographie',true,false),('architecte','be_topographie',true,false),
 ('direction','be_vrd',true,true),('bureau_etudes','be_vrd',true,true),('chef_projet','be_vrd',true,false),('conducteur','be_vrd',true,false),('architecte','be_vrd',true,false),
 -- CRM et stock : direction et magasinier explicites (le reste est copié plus bas depuis « crm » et « stock »)
 ('direction','crm_opportunites',true,true),('direction','crm_relances',true,true),('direction','crm_contrats',true,true),('direction','crm_reclamations',true,true),('direction','crm_satisfaction',true,true),
 ('direction','stock_depots',true,true),('direction','stock_transferts',true,true),('direction','stock_inventaires',true,true),('direction','stock_consultations',true,true),
 ('magasinier','stock_depots',true,true),('magasinier','stock_transferts',true,true),('magasinier','stock_inventaires',true,true),('magasinier','stock_consultations',true,true)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;

-- ---------- 3. Droits copiés depuis la collection équivalente (rien n'est écrasé) ----------
insert into droits_fonction(fonction,collection,lire,ecrire)
select d.fonction, m.nouveau, d.lire, d.ecrire
from droits_fonction d
join (values
  ('paie','paie_calculs'),('paie','paie_reglements'),
  ('crm','crm_opportunites'),('crm','crm_relances'),('crm','crm_contrats'),('crm','crm_reclamations'),('crm','crm_satisfaction'),
  ('stock','stock_depots'),('stock','stock_transferts'),('stock','stock_inventaires'),('stock','stock_consultations')
) as m(ancien,nouveau) on m.ancien=d.collection
on conflict (fonction,collection) do nothing;

-- Vérification :
--  select fonction, collection, lire, ecrire from droits_fonction where collection in
--   ('conges','courrier','presences_rh','paie_calculs','paie_reglements','be_dossiers','be_vrd','ctl_non_conformites','crm_opportunites','stock_transferts') order by 2,1;
--  select * from collections_sensibles order by 1;
