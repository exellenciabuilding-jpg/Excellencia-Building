-- V194 — Nom du guichetier sur le reçu TFL.
-- À exécuter UNE FOIS dans Supabase › SQL Editor (après le bloc 5, partie 4). Sans danger si relancé.
-- Ce que ça fait :
--   1) deux colonnes sur tfl_paiements : guichetier (nom affiché sur le reçu) et guichetier_email (compte connecté, relevé par le serveur, non modifiable) ;
--   2) le serveur enregistre le nom du guichetier quand un paiement est confirmé ou saisi à la caisse ;
--   3) le nom est renvoyé avec le paiement confirmé (étudiant et administration) ; il est effacé si le paiement est refusé ou remis en attente.
-- Les paiements déjà confirmés n'ont pas de nom : leur reçu garde « Administration Excellencia Building ».

alter table public.tfl_paiements add column if not exists guichetier text;
alter table public.tfl_paiements add column if not exists guichetier_email text;

create or replace function public.tfl_paiement_json(p public.tfl_paiements) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object('id', p.id, 'source', p.source, 'dossier', p.dossier, 'montant', p.montant, 'devise', p.devise, 'mode', p.mode,
    'reference', p.reference, 'date_paiement', p.date_paiement, 'note', p.note, 'nom', p.nom_fichier, 'mime', p.mime, 'taille', p.taille,
    'parties', p.parties, 'statut', p.statut, 'montant_confirme', p.montant_confirme, 'motif', p.motif, 'recu_no', p.recu_no,
    'verif', case when p.statut = 'confirme' then p.verif_hash end, 'guichetier', case when p.statut = 'confirme' then p.guichetier end,
    'decide_le', p.decide_le, 'cree_le', p.cree_le)
$$;
revoke all on function public.tfl_paiement_json(public.tfl_paiements) from public, anon, authenticated;

-- Les anciennes signatures sont retirées (sinon deux versions de la fonction coexisteraient).
drop function if exists public.tfl_paiement_admin_decider(uuid, text, numeric, text);
drop function if exists public.tfl_paiement_admin_ajouter(text, numeric, text, text, text, date, text);

-- Décision : confirme (reçu + code + registre + nom du guichetier), refuse (motif obligatoire) ou remet en attente (le reçu est annulé au registre).
create or replace function public.tfl_paiement_admin_decider(p_id uuid, p_statut text, p_montant numeric default null, p_motif text default '', p_guichetier text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare d public.tfl_paiements; v_motif text := left(btrim(coalesce(p_motif,'')), 500); v_m numeric(12,2); v_reg boolean := true; v_g text := left(btrim(coalesce(p_guichetier,'')), 80);
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('confirme','refuse','en_attente') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_statut = 'confirme' then
    v_m := round(coalesce(p_montant, d.montant), 2);
    if v_m <= 0 or v_m > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
    update public.tfl_paiements set statut = 'confirme', montant_confirme = v_m, motif = v_motif, recu_no = coalesce(recu_no, public.tfl_recu_numero()),
      verif_hash = coalesce(verif_hash, substr(md5(random()::text || clock_timestamp()::text || id::text), 1, 10)), guichetier = nullif(v_g, ''), guichetier_email = nullif(auth.jwt() ->> 'email', ''), decide_le = now(), maj_le = now()
      where id = d.id returning * into d;
    v_reg := public.tfl_recu_registre(d);
  else
    if p_statut = 'refuse' and length(v_motif) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    perform public.tfl_recu_annuler(d.recu_no);
    if p_statut = 'refuse' then
      update public.tfl_paiements set statut = 'refuse', montant_confirme = null, motif = v_motif, recu_no = null, verif_hash = null, guichetier = null, guichetier_email = null, decide_le = now(), maj_le = now() where id = d.id;
    else
      update public.tfl_paiements set statut = 'en_attente', montant_confirme = null, motif = '', recu_no = null, verif_hash = null, guichetier = null, guichetier_email = null, decide_le = null, maj_le = now() where id = d.id;
    end if;
  end if;
  return jsonb_build_object('ok', true, 'verifiable', v_reg);
end $$;
revoke all on function public.tfl_paiement_admin_decider(uuid,text,numeric,text,text) from public, anon;
grant execute on function public.tfl_paiement_admin_decider(uuid,text,numeric,text,text) to authenticated;

-- Paiement reçu en caisse ou enregistré par l'administration : directement confirmé, avec son reçu et son code de vérification.
create or replace function public.tfl_paiement_admin_ajouter(p_dossier text, p_montant numeric, p_devise text, p_mode text, p_reference text, p_date date, p_note text default '', p_guichetier text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_m numeric(12,2); v_recu text; v_dev text := upper(left(coalesce(nullif(btrim(p_devise), ''), 'USD'), 5)); p public.tfl_paiements; v_reg boolean;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if v_d = '' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 800 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 60 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  v_m := round(p_montant, 2); v_recu := public.tfl_recu_numero();
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, statut, montant_confirme, recu_no, verif_hash, guichetier, guichetier_email, decide_le)
  values (null, v_d, 'administration', v_m, v_dev, p_mode, left(btrim(coalesce(p_reference,'')), 80), p_date, left(btrim(coalesce(p_note,'')), 500), 'confirme', v_m, v_recu,
          substr(md5(random()::text || clock_timestamp()::text || v_recu), 1, 10),
          nullif(left(btrim(coalesce(p_guichetier,'')), 80), ''), nullif(auth.jwt() ->> 'email', ''), now())
  returning * into p;
  v_reg := public.tfl_recu_registre(p);
  return jsonb_build_object('ok', true, 'id', p.id, 'recu_no', v_recu, 'verifiable', v_reg);
end $$;
revoke all on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text,text) from public, anon;
grant execute on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text,text) to authenticated;
