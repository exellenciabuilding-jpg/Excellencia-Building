-- V209I — Architecture : analyse de site (collection arch_site)
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','arch_site',true,true),
 ('chef_projet','arch_site',true,true),
 ('bureau_etudes','arch_site',true,true),
 ('architecte','arch_site',true,true),
 ('comptable','arch_site',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
