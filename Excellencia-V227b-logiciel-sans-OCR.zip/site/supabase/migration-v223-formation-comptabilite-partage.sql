-- Excellencia Building V223 — Formation + Comptabilité en base partagée (fiche par fiche).
-- Collections ajoutées à « enregistrements » : apprenants, formations, formateurs, presences, evaluations, cotations,
-- certificats, planning_formation, recus, paiements_apprenants.
-- À exécuter UNE fois dans Supabase › SQL Editor (après migration-v66-roles.sql et migration-v75-droits-v69-v74.sql). Réexécutable sans danger.
-- NON exécuté sur un vrai Supabase : essayer d'abord sur la copie / le projet de recette.
-- Règles : administrateur = tout ; fonction « polyvalent » = traité par peut() comme pour les autres collections ;
--          les autres fonctions n'ont que les droits ci-dessous (absence de ligne = refus).
do $$ begin
  if to_regclass('public.droits_fonction') is null then
    raise exception 'La table droits_fonction est absente : exécutez d''abord migration-v66-roles.sql';
  end if;
end $$;

insert into droits_fonction(fonction, collection, lire, ecrire) values
 -- Direction : tout
 ('direction','apprenants',true,true),('direction','formations',true,true),('direction','formateurs',true,true),('direction','presences',true,true),
 ('direction','evaluations',true,true),('direction','cotations',true,true),('direction','certificats',true,true),('direction','planning_formation',true,true),
 ('direction','recus',true,true),('direction','paiements_apprenants',true,true),
 -- Formateur : pédagogie (pas de reçus ni de paiements)
 ('formateur','apprenants',true,true),('formateur','formations',true,false),('formateur','formateurs',true,false),('formateur','presences',true,true),
 ('formateur','evaluations',true,true),('formateur','cotations',true,true),('formateur','certificats',true,true),('formateur','planning_formation',true,true),
 ('formateur','recus',false,false),('formateur','paiements_apprenants',false,false),
 -- Comptable : reçus et paiements ; lecture seule des apprenants et formations (frais)
 ('comptable','recus',true,true),('comptable','paiements_apprenants',true,true),('comptable','apprenants',true,false),('comptable','formations',true,false),
 ('comptable','formateurs',false,false),('comptable','presences',false,false),('comptable','evaluations',false,false),('comptable','cotations',false,false),
 ('comptable','certificats',false,false),('comptable','planning_formation',false,false),
 -- RH : lecture des formateurs et du planning
 ('rh','formateurs',true,false),('rh','planning_formation',true,false)
on conflict (fonction, collection) do nothing;

-- Vérification : select fonction, collection, lire, ecrire from droits_fonction where collection in
--  ('apprenants','formations','formateurs','presences','evaluations','cotations','certificats','planning_formation','recus','paiements_apprenants') order by 2,1;
