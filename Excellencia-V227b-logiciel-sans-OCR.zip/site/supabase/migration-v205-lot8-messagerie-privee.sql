-- ===== Excellencia Building — V205m / cahier Multi-Espaces : messagerie d'équipe PRIVÉE, avec pièces jointes (choix d'une personne, suppression des fichiers) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v205-lot5-formateur.sql. Additive et réexécutable sans danger.
--
--  Un message d'équipe n'est visible QUE par : son expéditeur, son destinataire (la personne, ou les membres de la fonction visée),
--  et l'administrateur. Un message « Toute l'équipe » (annonce) est visible de tous les membres.
--  Contrairement à la V205l (collection partagée lisible par toute fonction), la lecture et l'écriture passent par des FONCTIONS serveur :
--  la table n'a aucune politique d'accès direct, donc aucun membre ne peut la lire en contournant l'application.
--  Pièce jointe : un fichier (PDF, image, Word, Excel, PowerPoint, texte, CSV) de 6 Mo au plus, lu seulement par les mêmes personnes.
--  Destinataire : une fonction (tous ses membres) OU une personne précise (equipe_membres donne la liste : noms et fonctions seulement).
--  Suppression : equipe_supprimer_piece retire le FICHIER de la base (le texte du message reste) pour libérer de la place ; option « usage unique »
--  (le fichier est retiré après le premier téléchargement du destinataire). Espace libéré : réutilisé par PostgreSQL après nettoyage automatique (autovacuum) ;
--  la jauge du tableau de bord Supabase peut mettre du temps à baisser.
--  Si la V205l (lot 7) a déjà été exécutée : ses messages sont recopiés ici, puis la collection partagée « messages_equipe » est supprimée.

do $$ begin
  if to_regclass('public.membres') is null or to_regclass('public.organisations') is null then
    raise exception 'Exécutez d''abord schema-entreprise.sql et migration-v66-roles.sql.';
  end if;
end $$;

create table if not exists equipe_messages(
  id text primary key,
  org_id uuid not null references organisations(id) on delete cascade,
  de_user uuid not null,
  de_fonction text not null,
  de_nom text,
  a_fonction text not null,
  a_user uuid,
  objet text not null default '',
  texte text not null default '',
  piece_nom text,
  piece_type text,
  piece_taille integer,
  piece_data text,
  piece_supprimee boolean not null default false,
  piece_auto boolean not null default false,
  fil text,
  cree_le timestamptz not null default now()
);
alter table equipe_messages add column if not exists piece_supprimee boolean not null default false;
alter table equipe_messages add column if not exists piece_auto boolean not null default false;
alter table equipe_messages add column if not exists fil text;   -- identifiant de conversation : une réponse reprend le « fil » du message d'origine
create index if not exists equipe_messages_org_idx on equipe_messages(org_id, cree_le desc);
alter table equipe_messages enable row level security;
-- aucune politique : accès uniquement par les fonctions ci-dessous (security definer)
revoke all on equipe_messages from anon, authenticated;

-- le message m est-il visible de la personne connectée ?
create or replace function equipe_visible(m equipe_messages) returns boolean
language sql stable security definer set search_path=public as $$
  select exists(select 1 from membres x where x.org_id=m.org_id and x.user_id=auth.uid() and (
      x.role='admin'
      or m.de_user=auth.uid()
      or m.a_user=auth.uid()
      or (m.a_user is null and (m.a_fonction='tous' or m.a_fonction=x.fonction))
  )) $$;
revoke all on function equipe_visible(equipe_messages) from public, anon;

drop function if exists equipe_envoyer(uuid,text,uuid,text,text,text,text,text);
drop function if exists equipe_envoyer(uuid,text,uuid,text,text,text,text,text,boolean);
create or replace function equipe_envoyer(p_org uuid, p_a_fonction text, p_a_user uuid, p_objet text, p_texte text,
  p_piece_nom text default null, p_piece_type text default null, p_piece_data text default null, p_piece_auto boolean default false, p_fil text default null) returns json
language plpgsql security definer set search_path=public as $$
declare me membres; nid text; taille int; fonc text; f text;
begin
  select * into me from membres where org_id=p_org and user_id=auth.uid();
  if not found or me.role not in ('admin','editeur') then raise exception 'droits insuffisants'; end if;
  if p_a_fonction is null or p_a_fonction not in ('tous','admin','polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','formateur','comptable','rh','magasinier') then
    raise exception 'destinataire invalide'; end if;
  if length(coalesce(trim(p_texte),'')) < 1 and p_piece_data is null then raise exception 'message vide'; end if;
  if length(coalesce(p_texte,'')) > 4000 then raise exception 'message trop long'; end if;
  if p_a_user is not null and not exists(select 1 from membres where org_id=p_org and user_id=p_a_user) then raise exception 'destinataire introuvable'; end if;
  if p_piece_data is not null then
    if p_piece_data !~ '^data:[^,]{0,120},' then raise exception 'pièce jointe invalide'; end if;
    if length(p_piece_data) > 8500000 then raise exception 'fichier_trop_lourd'; end if;
    if coalesce(p_piece_nom,'') !~* '\.(pdf|png|jpe?g|webp|docx?|xlsx?|pptx?|txt|csv)$' then raise exception 'type de fichier non accepté'; end if;
    taille := (length(p_piece_data) * 3) / 4;
  end if;
  f := nullif(left(trim(coalesce(p_fil,'')), 40), '');
  if f is not null and not exists(select 1 from equipe_messages x where x.org_id=p_org and x.fil=f and equipe_visible(x)) then raise exception 'conversation introuvable'; end if;
  fonc := case when me.role='admin' then 'admin' else coalesce(me.fonction,'polyvalent') end;
  nid := 'EQ-' || substr(md5(random()::text || clock_timestamp()::text || auth.uid()::text), 1, 14);
  insert into equipe_messages(id, org_id, de_user, de_fonction, de_nom, a_fonction, a_user, objet, texte, piece_nom, piece_type, piece_taille, piece_data, piece_auto, fil)
  values (nid, p_org, auth.uid(), fonc, nullif(trim(coalesce(me.nom,'')),''), p_a_fonction, p_a_user, left(coalesce(p_objet,''),120), coalesce(p_texte,''),
          case when p_piece_data is null then null else left(p_piece_nom,160) end, case when p_piece_data is null then null else left(coalesce(p_piece_type,''),120) end,
          taille, p_piece_data, coalesce(p_piece_auto,false) and p_piece_data is not null and p_a_fonction <> 'tous', coalesce(f, nid));
  return json_build_object('ok', true, 'id', nid);
end $$;

-- lecture : mes messages (sans le contenu des pièces jointes)
create or replace function equipe_lire(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
declare r json;
begin
  if not est_membre(p_org) then raise exception 'droits insuffisants'; end if;
  select coalesce(json_agg(t order by t.cree_le), '[]'::json) into r from (
    select m.id, m.de_user, m.de_fonction, m.de_nom, m.a_fonction, m.a_user,
           (select nullif(trim(coalesce(y.nom,'')),'') from membres y where y.org_id=m.org_id and y.user_id=m.a_user) as a_nom,
           m.objet, m.texte, m.piece_nom, m.piece_taille, m.piece_supprimee, m.piece_auto, m.fil, m.cree_le
    from equipe_messages m where m.org_id=p_org and equipe_visible(m) order by m.cree_le desc limit 500) t;
  return json_build_object('moi', auth.uid(), 'messages', r);
end $$;

-- une pièce jointe, avec la même règle de visibilité
create or replace function equipe_piece(p_org uuid, p_id text) returns json
language plpgsql stable security definer set search_path=public as $$
declare m equipe_messages;
begin
  if not est_membre(p_org) then raise exception 'droits insuffisants'; end if;
  select * into m from equipe_messages where org_id=p_org and id=p_id;
  if not found or m.piece_data is null or not equipe_visible(m) then raise exception 'pièce introuvable'; end if;
  return json_build_object('nom', m.piece_nom, 'type', m.piece_type, 'data', m.piece_data);
end $$;

-- liste des membres (noms et fonctions seulement) pour écrire à une personne précise
create or replace function equipe_membres(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
declare r json;
begin
  if not est_membre(p_org) then raise exception 'droits insuffisants'; end if;
  select coalesce(json_agg(t order by t.nom), '[]'::json) into r from (
    select x.user_id, coalesce(nullif(trim(coalesce(x.nom,'')),''), 'Membre') as nom,
           case when x.role='admin' then 'admin' else coalesce(x.fonction,'polyvalent') end as fonction
    from membres x where x.org_id=p_org and x.user_id <> auth.uid()) t;
  return r;
end $$;

-- retire le FICHIER d'un message (le texte reste) : expéditeur, destinataire, administrateur
create or replace function equipe_supprimer_piece(p_org uuid, p_id text) returns json
language plpgsql security definer set search_path=public as $$
declare m equipe_messages; x membres; lib int;
begin
  select * into x from membres where org_id=p_org and user_id=auth.uid();
  if not found or x.role not in ('admin','editeur') then raise exception 'droits insuffisants'; end if;
  select * into m from equipe_messages where org_id=p_org and id=p_id;
  if not found or m.piece_data is null or not equipe_visible(m) then raise exception 'pièce introuvable'; end if;
  if m.a_fonction='tous' and x.role<>'admin' and m.de_user<>auth.uid() then
    raise exception 'seul l''expéditeur ou l''administrateur peut supprimer ce fichier'; end if;
  lib := coalesce(m.piece_taille,0);
  update equipe_messages set piece_data=null, piece_supprimee=true, piece_taille=null where org_id=p_org and id=p_id;
  return json_build_object('ok', true, 'libere', lib);
end $$;

revoke all on function equipe_envoyer(uuid,text,uuid,text,text,text,text,text,boolean,text) from public, anon;
revoke all on function equipe_membres(uuid) from public, anon;
revoke all on function equipe_supprimer_piece(uuid,text) from public, anon;
grant execute on function equipe_membres(uuid) to authenticated;
grant execute on function equipe_supprimer_piece(uuid,text) to authenticated;
revoke all on function equipe_lire(uuid) from public, anon;
revoke all on function equipe_piece(uuid,text) from public, anon;
grant execute on function equipe_envoyer(uuid,text,uuid,text,text,text,text,text,boolean,text) to authenticated;
grant execute on function equipe_lire(uuid) to authenticated;
grant execute on function equipe_piece(uuid,text) to authenticated;

-- reprise de la V205l (lot 7) si elle avait été exécutée : les messages deviennent privés, la collection partagée est supprimée
do $$ begin
  if to_regclass('public.enregistrements') is not null then
    insert into equipe_messages(id, org_id, de_user, de_fonction, de_nom, a_fonction, objet, texte, cree_le)
    select e.id, e.org_id, e.maj_par, coalesce(e.data->>'de_fonction','polyvalent'), nullif(e.data->>'de_nom',''), coalesce(e.data->>'a','tous'),
           left(coalesce(e.data->>'objet',''),120), left(coalesce(e.data->>'texte',''),4000), coalesce((e.data->>'at')::timestamptz, e.maj)
    from enregistrements e
    where e.collection='messages_equipe' and not e.supprime and e.maj_par is not null
      and (e.data->>'a') in ('tous','admin','polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','formateur','comptable','rh','magasinier')
    on conflict (id) do nothing;
    delete from enregistrements where collection='messages_equipe';
  end if;
  if to_regclass('public.droits_fonction') is not null then
    delete from droits_fonction where collection='messages_equipe';
  end if;
end $$;
