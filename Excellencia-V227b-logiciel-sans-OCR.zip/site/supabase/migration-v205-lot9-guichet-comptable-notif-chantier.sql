-- ===== Excellencia Building — V205n / LOT 9 « Paiement au guichet du comptable → notification automatique au chantier » =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS : migration-v142b-paiements-client.sql, migration-v205-lot5-formateur.sql,
-- migration-v205-lot5b-paiements-comptable.sql et migration-v205-lot8-messagerie-privee.sql. Additive et réexécutable sans danger.
--
-- Parcours :
--  1. Le client, dans son espace, déclare qu'il passera payer au guichet du comptable (montant, facture) → paiement au statut « annonce ».
--  2. Le comptable (ou la direction / l'administrateur) voit l'annonce, encaisse, puis la confirme avec client_guichet_encaisser().
--  3. Dès qu'un paiement client passe à « confirmé » (guichet OU Mobile Money/banque confirmé par client_paiement_decider),
--     un message privé est envoyé AUTOMATIQUEMENT aux espaces Chantier (conducteur) et Chef de projet : « le client X a payé ».
--     Ce message passe par la table fermée equipe_messages (lot 8) : seuls ces espaces, l'expéditeur et l'administrateur le lisent.

do $$ begin
  if to_regclass('public.client_paiements') is null then raise exception 'Exécutez d''abord migration-v142b-paiements-client.sql.'; end if;
  if to_regclass('public.equipe_messages') is null then raise exception 'Exécutez d''abord migration-v205-lot8-messagerie-privee.sql.'; end if;
end $$;

-- 1) Nouveau mode « guichet » et nouveau statut « annonce » (le client a annoncé son passage, rien n'est encore encaissé)
alter table public.client_paiements drop constraint if exists client_paiements_mode_check;
alter table public.client_paiements add constraint client_paiements_mode_check
  check (mode in ('mobile_money','banque','caisse','guichet','autre'));
alter table public.client_paiements drop constraint if exists client_paiements_statut_check;
alter table public.client_paiements add constraint client_paiements_statut_check
  check (statut in ('annonce','en_attente','confirme','refuse'));

-- 2) Côté client : « je passerai payer au guichet du comptable »
create or replace function public.client_guichet_annoncer(p_token text, p_code text, p_facture text, p_montant numeric, p_devise text, p_note text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; l public.portail_liens; v_dev text := upper(btrim(coalesce(p_devise,''))); v_m numeric(14,2);
        v_fac text := left(btrim(coalesce(p_facture,'')), 60); v_id uuid; v_ref text;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into l from public.portail_liens where id = c.v_id and kind = 'client';
  if not found then return jsonb_build_object('ok', false, 'code', 'revoque'); end if;
  if v_dev not in ('USD','FC') then return jsonb_build_object('ok', false, 'code', 'devise'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  v_m := round(p_montant, 2);
  if (select count(*) from public.client_paiements where lien_id = l.id and statut = 'annonce') >= 5 then return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  if (select count(*) from public.client_paiements where lien_id = l.id) >= 200 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  v_ref := 'GUI-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
  insert into public.client_paiements(org_id, lien_id, facture, montant, devise, mode, reference, trans_no, date_paiement, note, statut)
  values (l.org_id, l.id, v_fac, v_m, v_dev, 'guichet', v_ref, v_ref, current_date, left(btrim(coalesce(p_note,'')), 400), 'annonce')
  returning id into v_id;
  insert into public.portail_messages(lien_id, de, texte)
  values (l.id, 'visiteur', 'Je passerai payer au guichet du comptable : ' || to_char(v_m, 'FM999G999G999G990D00') || ' ' || v_dev
          || case when v_fac <> '' then ' pour la facture ' || v_fac else '' end || '. Annonce n° ' || v_ref || '.');
  return jsonb_build_object('ok', true, 'id', v_id, 'annonce', v_ref);
end $$;
revoke all on function public.client_guichet_annoncer(text,text,text,numeric,text,text) from public;
grant execute on function public.client_guichet_annoncer(text,text,text,numeric,text,text) to anon, authenticated;

-- 3) Côté comptable : les annonces et paiements en attente de l'entreprise (comptable, direction, administrateur)
create or replace function public.client_guichet_a_encaisser(p_org uuid)
returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if auth.uid() is null or not exists(select 1 from membres where org_id = p_org and user_id = auth.uid() and (role = 'admin' or fonction in ('comptable','direction'))) then
    raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'client', l.destinataire, 'portail', l.titre, 'facture', x.facture, 'montant', x.montant,
      'devise', x.devise, 'mode', x.mode, 'statut', x.statut, 'annonce', x.reference, 'note', x.note, 'cree_le', x.cree_le) order by x.cree_le desc)
    from public.client_paiements x join public.portail_liens l on l.id = x.lien_id
    where x.org_id = p_org and x.statut in ('annonce','en_attente')), '[]'::jsonb);
end $$;
revoke all on function public.client_guichet_a_encaisser(uuid) from public, anon;
grant execute on function public.client_guichet_a_encaisser(uuid) to authenticated;

-- 4) Côté comptable : « le client a payé au guichet » → confirmé (le chantier est prévenu par le déclencheur ci-dessous)
create or replace function public.client_guichet_encaisser(p_org uuid, p_id uuid, p_montant numeric default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare d public.client_paiements; v_m numeric(14,2); v_recu text;
begin
  if auth.uid() is null or not exists(select 1 from membres where org_id = p_org and user_id = auth.uid()
       and (role = 'admin' or (role = 'editeur' and fonction in ('comptable','direction')))) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  select * into d from public.client_paiements where id = p_id and org_id = p_org for update;
  if not found then raise exception 'introuvable'; end if;
  if d.statut not in ('annonce','en_attente','confirme') then raise exception 'statut_invalide'; end if;
  v_m := round(coalesce(p_montant, d.montant), 2);
  if v_m <= 0 or v_m > 1000000000 then raise exception 'montant_invalide'; end if;
  v_recu := coalesce(d.recu_no, public.client_recu_numero());
  update public.client_paiements set statut = 'confirme', montant_confirme = v_m, motif = '', recu_no = v_recu, decide_le = now() where id = d.id;
  if d.statut <> 'confirme' then
    insert into public.portail_messages(lien_id, de, texte)
    values (d.lien_id, 'entreprise', 'Paiement reçu au guichet : ' || to_char(v_m, 'FM999G999G999G990D00') || ' ' || d.devise || '. Reçu n° ' || v_recu || '.');
  end if;
  return jsonb_build_object('ok', true, 'recu_no', v_recu);
end $$;
revoke all on function public.client_guichet_encaisser(uuid,uuid,numeric) from public, anon;
grant execute on function public.client_guichet_encaisser(uuid,uuid,numeric) to authenticated;

-- 5) Notification AUTOMATIQUE au chantier dès qu'un paiement client devient « confirmé » (guichet, Mobile Money, banque…)
create or replace function public.client_paiement_notifier_chantier() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_nom text; v_fonc text; v_client text; v_txt text; f text;
begin
  if new.statut <> 'confirme' or (tg_op = 'UPDATE' and old.statut = 'confirme') then return new; end if;   -- une seule notification par paiement
  select coalesce(nullif(btrim(l.destinataire),''), l.titre) into v_client from public.portail_liens l where l.id = new.lien_id;
  if v_uid is null then select user_id into v_uid from membres where org_id = new.org_id and role = 'admin' order by 1 limit 1; end if;
  if v_uid is null then return new; end if;
  select nullif(btrim(coalesce(m.nom,'')),''), case when m.role = 'admin' then 'admin' else coalesce(m.fonction,'comptable') end
    into v_nom, v_fonc from membres m where m.org_id = new.org_id and m.user_id = v_uid;
  v_txt := 'Le client ' || coalesce(v_client,'—') || ' a payé : ' || to_char(coalesce(new.montant_confirme, new.montant), 'FM999G999G999G990D00') || ' ' || new.devise
           || case when new.facture <> '' then ' (facture ' || new.facture || ')' else '' end
           || case when new.mode = 'guichet' then ', encaissé au guichet du comptable' else ', paiement vérifié par la comptabilité' end
           || '. Reçu n° ' || coalesce(new.recu_no,'—') || '.';
  foreach f in array array['conducteur','chef_projet'] loop
    insert into equipe_messages(id, org_id, de_user, de_fonction, de_nom, a_fonction, objet, texte)
    values ('EQ-' || substr(md5(random()::text || clock_timestamp()::text || f || new.id::text), 1, 14), new.org_id, v_uid, coalesce(v_fonc,'comptable'),
            v_nom, f, left('💰 Paiement client confirmé — ' || coalesce(v_client,''), 120), v_txt);
  end loop;
  return new;
end $$;
revoke all on function public.client_paiement_notifier_chantier() from public, anon, authenticated;

drop trigger if exists client_paiement_notif_chantier on public.client_paiements;
create trigger client_paiement_notif_chantier after insert or update of statut on public.client_paiements
  for each row execute function public.client_paiement_notifier_chantier();

notify pgrst, 'reload schema';
-- Contrôle : select count(*) from pg_trigger where tgname='client_paiement_notif_chantier'; -> 1
