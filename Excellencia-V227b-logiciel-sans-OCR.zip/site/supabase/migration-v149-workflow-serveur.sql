-- ===== Excellencia Building — V149 : WORKFLOW SUR LE SERVEUR (plusieurs validateurs en même temps) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, APRÈS schema-entreprise.sql et migration-v66-roles.sql
-- (il utilise organisations, membres, est_membre() et membres.fonction). Réexécutable sans danger.
--
-- POURQUOI : jusqu'ici les dossiers du Workflow étaient copiés « clé entière » : si deux validateurs décidaient au même instant
-- sur deux appareils, la dernière écriture gagnait et une décision pouvait être perdue. Ici :
--   · chaque dossier est UNE ligne (wf_dossiers) ; chaque décision passe par une fonction qui VERROUILLE la ligne (for update),
--     relit l'état réel, applique les règles (à qui le tour, séparation des tâches, deux paires d'yeux, motif) puis écrit ;
--   · l'identité du validateur est celle du compte connecté (membres.nom / fonction), jamais celle envoyée par l'appareil ;
--   · l'historique des décisions est en ajout seul (wf_decisions) et une même personne ne peut pas approuver deux fois la même étape
--     (index unique) ;
--   · le numéro WF-AAAA-NNNN est attribué par le serveur (plus de doublon entre deux appareils) ;
--   · aucune écriture directe dans ces tables : seules les fonctions ci-dessous écrivent (RLS : lecture réservée aux membres).
-- Les règles du moteur JavaScript (exb-workflow.js) sont reprises à l'identique ; les alias de fonction (direction = « Directeur
-- général »…) sont les mêmes que dans wf_acteur().

-- ---------- 1. Tables ----------
create table if not exists wf_circuits(
  org_id uuid not null references organisations(id) on delete cascade,
  id text not null, data jsonb not null,
  actif boolean not null default true,
  maj timestamptz not null default now(),
  primary key(org_id,id));

create table if not exists wf_deleg(
  org_id uuid not null references organisations(id) on delete cascade,
  id text not null, data jsonb not null,
  maj timestamptz not null default now(),
  primary key(org_id,id));

create table if not exists wf_compteur(
  org_id uuid not null references organisations(id) on delete cascade,
  annee int not null, dernier int not null default 0,
  primary key(org_id,annee));

create table if not exists wf_dossiers(
  org_id uuid not null references organisations(id) on delete cascade,
  id text not null,
  no text not null,
  status text not null,
  revision int not null default 1,
  data jsonb not null,
  cree_par uuid,
  cree timestamptz not null default now(),
  maj timestamptz not null default now(),
  primary key(org_id,id),
  unique(org_id,no));
create index if not exists wf_dossiers_maj_idx on wf_dossiers(org_id,maj);

create table if not exists wf_decisions(
  n bigserial primary key,
  org_id uuid not null, dossier_id text not null,
  dversion int not null, step int not null, approver text not null,
  acteur_id uuid, acteur text, action text not null, motif text, pour text,
  t timestamptz not null default now());
create unique index if not exists wf_decisions_une_approbation
  on wf_decisions(org_id,dossier_id,dversion,step,approver) where action='approuver';

-- ---------- 2. Droits : lecture pour les membres, AUCUNE écriture directe ----------
alter table wf_circuits enable row level security;
alter table wf_deleg enable row level security;
alter table wf_compteur enable row level security;
alter table wf_dossiers enable row level security;
alter table wf_decisions enable row level security;

drop policy if exists wf_circuits_lire on wf_circuits;   create policy wf_circuits_lire on wf_circuits for select using (est_membre(org_id));
drop policy if exists wf_deleg_lire on wf_deleg;         create policy wf_deleg_lire on wf_deleg for select using (est_membre(org_id));
drop policy if exists wf_dossiers_lire on wf_dossiers;   create policy wf_dossiers_lire on wf_dossiers for select using (est_membre(org_id));
drop policy if exists wf_decisions_lire on wf_decisions; create policy wf_decisions_lire on wf_decisions for select using (est_membre(org_id));
-- wf_compteur : aucune politique (seules les fonctions security definer y accèdent).

revoke insert, update, delete on wf_circuits, wf_deleg, wf_compteur, wf_dossiers, wf_decisions from anon, authenticated;

-- ---------- 3. Fonctions d'aide ----------
create or replace function wf_now() returns text language sql stable set search_path=public as $$
  select to_char(now() at time zone 'utc','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') $$;

create or replace function wf_refus(p_msg text) returns jsonb language sql immutable set search_path=public as $$
  select jsonb_build_object('ok',false,'refus',p_msg) $$;

-- minuscules, sans accents, apostrophes droites, espaces simples (comme norm() de exb-workflow.js)
create or replace function wf_norm(t text) returns text language sql immutable set search_path=public as $$
  select btrim(regexp_replace(
    translate(replace(replace(lower(coalesce(t,'')),'’',''''),'‘',''''),
      'àâäáãåçèéêëìíîïñòóôöõùúûüýÿ','aaaaaaceeeeiiiinooooouuuuyy'),
    '\s+',' ','g')) $$;

create or replace function wf_statut(s text) returns text language sql immutable set search_path=public as $$
  select case s when 'en_cours' then 'En cours' when 'valide' then 'Validé' when 'refuse' then 'Refusé'
                when 'retourne' then 'À corriger' when 'annule' then 'Annulé' else coalesce(s,'?') end $$;

-- identité du compte connecté dans l'organisation : nom, fonction et alias (miroir de rolesOf() en JavaScript)
create or replace function wf_acteur(p_org uuid) returns jsonb
language plpgsql stable security definer set search_path=public as $$
declare m membres; f text; ali text[];
begin
  select * into m from membres where org_id=p_org and user_id=auth.uid();
  if not found then return null; end if;
  f := coalesce(m.fonction,'polyvalent');
  if f = 'polyvalent' then
    ali := array[]::text[];
  else
    ali := array[wf_norm(f), wf_norm(replace(f,'_',' '))] || case f
      when 'direction'     then array['directeur general','directeur','dg','direction']
      when 'chef_projet'   then array['chef de projet','chef projet']
      when 'conducteur'    then array['conducteur de travaux','conducteur']
      when 'bureau_etudes' then array['bureau d''etudes','bureau etudes','ingenieur']
      when 'comptable'     then array['comptable','comptabilite']
      when 'rh'            then array['rh','ressources humaines']
      when 'magasinier'    then array['magasinier']
      else array[]::text[] end;
  end if;
  if m.role = 'admin'   then ali := ali || array['administrateur','admin']; end if;
  if m.role = 'lecteur' then ali := ali || array['lecteur']; end if;
  return jsonb_build_object('id', m.user_id, 'name', coalesce(m.nom,''),
                            'role', case when f = 'polyvalent' then m.role else f end,
                            'roles', to_jsonb(ali), 'rl', m.role);
end $$;

-- l'acteur correspond-il à l'approbateur {name} ou {role} ? (miroir de matches())
create or replace function wf_match(p_actor jsonb, p_ap jsonb) returns boolean
language sql immutable set search_path=public as $$
  select coalesce(
    ( wf_norm(p_ap->>'name') <> '' and wf_norm(p_actor->>'name') = wf_norm(p_ap->>'name') )
    or ( wf_norm(p_ap->>'role') <> ''
         and ( wf_norm(p_actor->>'role') = wf_norm(p_ap->>'role')
               or coalesce((p_actor->'roles') ? wf_norm(p_ap->>'role'), false) ) ),
    false) $$;

create or replace function wf_cle(p_ap jsonb) returns text language sql immutable set search_path=public as $$
  select wf_norm(p_ap->>'name') || '|' || wf_norm(p_ap->>'role') $$;

-- qui doit agir maintenant ? (miroir de pending())
create or replace function wf_attendus(d jsonb) returns jsonb
language plpgsql immutable set search_path=public as $$
declare s jsonb; cur int; ver int; done text[]; reste jsonb := '[]'::jsonb; total int; ap jsonb;
begin
  if d->>'status' <> 'en_cours' then return '[]'::jsonb; end if;
  cur := (d->>'cur')::int; ver := (d->>'version')::int;
  s := d->'steps'->cur;
  if s is null then return '[]'::jsonb; end if;
  select coalesce(array_agg(x.value->>'approver'), array[]::text[]) into done
    from jsonb_array_elements(d->'decisions') x
   where (x.value->>'step')::int = cur and (x.value->>'version')::int = ver and x.value->>'action' = 'approuver';
  total := jsonb_array_length(s->'approvers');
  for ap in select a.value from jsonb_array_elements(s->'approvers') a loop
    if not (wf_cle(ap) = any(done)) then reste := reste || jsonb_build_array(ap); end if;
  end loop;
  if s->>'mode' = 'sequentiel' then
    if jsonb_array_length(reste) > 0 then return jsonb_build_array(reste->0); end if;
    return '[]'::jsonb;
  end if;
  if s->>'mode' = 'un_seul' and jsonb_array_length(reste) < total then return '[]'::jsonb; end if;
  return reste;
end $$;

-- l'acteur peut-il décider ? → {ap, pour} (pour = personne remplacée par délégation) ou null (miroir de canAct())
create or replace function wf_peut(p_org uuid, d jsonb, who jsonb) returns jsonb
language plpgsql stable security definer set search_path=public as $$
declare att jsonb := wf_attendus(d); ap jsonb; dl jsonb; de jsonb; du date; au date;
        ajd date := (now() at time zone 'utc')::date;
begin
  if who is null then return null; end if;
  for ap in select a.value from jsonb_array_elements(att) a loop
    if wf_match(who, ap) then return jsonb_build_object('ap', ap, 'pour', ''); end if;
  end loop;
  for ap in select a.value from jsonb_array_elements(att) a loop
    for dl in select g.data from wf_deleg g where g.org_id = p_org loop
      de := dl->'de';
      du := nullif(dl->>'du','')::date;
      au := nullif(dl->>'au','')::date;
      if coalesce(dl->>'actif','true') <> 'false'
         and (du is null or du <= ajd) and (au is null or au >= ajd)
         and wf_match(jsonb_build_object('name', de->>'name', 'role', de->>'role',
                                         'roles', jsonb_build_array(wf_norm(de->>'role'))), ap)
         and wf_match(who, dl->'a') then
        return jsonb_build_object('ap', ap, 'pour', coalesce(nullif(de->>'name',''), de->>'role', '?'));
      end if;
    end loop;
  end loop;
  return null;
end $$;

-- échéance (AAAA-MM-JJ) d'une étape à partir d'aujourd'hui, '' si pas de délai
create or replace function wf_echeance(p_step jsonb) returns text language sql stable set search_path=public as $$
  select case when coalesce(nullif(p_step->>'delaiJours','')::numeric,0) > 0
              then to_char((now() at time zone 'utc')::date + round(nullif(p_step->>'delaiJours','')::numeric)::int,'YYYY-MM-DD')
              else '' end $$;

-- ---------- 4. Fonctions appelées par l'application ----------

-- État : le serveur Workflow est-il installé, et qui suis-je ?
create or replace function wf_etat(p_org uuid) returns jsonb
language plpgsql stable security definer set search_path=public as $$
begin
  if auth.uid() is null or not est_membre(p_org) then return jsonb_build_object('ok',false,'refus','non membre'); end if;
  return jsonb_build_object('ok',true,'version',1,'acteur',wf_acteur(p_org));
end $$;

-- Circuits et délégations : réservé à l'administrateur (une ligne par circuit / délégation)
create or replace function wf_config_ecrire(p_org uuid, p_kind text, p_id text, p_data jsonb, p_supprime boolean default false)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then return wf_refus('Réservé à l''administrateur.'); end if;
  if p_kind not in ('circuit','deleg') then return wf_refus('Type inconnu.'); end if;
  if coalesce(btrim(p_id),'') = '' then return wf_refus('Identifiant manquant.'); end if;
  if p_kind = 'circuit' then
    if p_supprime then
      delete from wf_circuits where org_id = p_org and id = p_id;
    else
      if coalesce(btrim(p_data->>'nom'),'') = '' or jsonb_typeof(p_data->'steps') <> 'array' or jsonb_array_length(p_data->'steps') = 0 then
        return wf_refus('Circuit invalide (nom et au moins une étape).');
      end if;
      insert into wf_circuits(org_id,id,data,actif) values (p_org,p_id,p_data,coalesce(p_data->>'actif','true') <> 'false')
      on conflict (org_id,id) do update set data = excluded.data, actif = excluded.actif, maj = now();
    end if;
  else
    if p_supprime then
      delete from wf_deleg where org_id = p_org and id = p_id;
    else
      insert into wf_deleg(org_id,id,data) values (p_org,p_id,p_data)
      on conflict (org_id,id) do update set data = excluded.data, maj = now();
    end if;
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org, auth.uid(), 'wf_' || p_kind, p_id, case when p_supprime then 'suppression' else 'enregistrement' end, 1);
  return jsonb_build_object('ok',true);
end $$;

-- Soumission : le serveur reconstruit le dossier depuis le circuit enregistré, attribue le numéro et fixe l'initiateur
create or replace function wf_soumettre(p_org uuid, p_id text, p_circuit_id text, p_data jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  c jsonb; who jsonb; ex jsonb; exrev int; steps jsonb := '[]'::jsonb; s jsonb; n int; d jsonb;
  an int := extract(year from now() at time zone 'utc')::int;
  t text := wf_now(); titre text; montant numeric; devise text; typ text; nom text; descr text; numero text;
begin
  if auth.uid() is null then return wf_refus('Non connecté.'); end if;
  if not est_membre(p_org, array['admin','editeur']) then return wf_refus('Droits insuffisants (compte lecteur).'); end if;
  if coalesce(btrim(p_id),'') = '' then return wf_refus('Identifiant du dossier manquant.'); end if;
  -- idempotent : un renvoi (réseau coupé puis rétabli) ne crée pas de doublon
  select data, revision into ex, exrev from wf_dossiers where org_id = p_org and id = p_id;
  if found then return jsonb_build_object('ok',true,'deja',true,'revision',exrev,'dossier',ex); end if;

  select g.data into c from wf_circuits g where g.org_id = p_org and g.id = p_circuit_id and g.actif;
  if c is null then
    select g.data into c from wf_circuits g
     where g.org_id = p_org and g.actif and g.data->>'type' = p_data->>'type' order by g.id limit 1;
  end if;
  if c is null then return wf_refus('Aucun circuit actif pour ce type de dossier (circuits non envoyés au serveur ?).'); end if;

  titre := btrim(coalesce(p_data->>'titre',''));
  if titre = '' then return wf_refus('Le titre du dossier est obligatoire.'); end if;
  montant := nullif(p_data->>'montant','')::numeric;
  devise := coalesce(p_data->>'devise','');
  descr := left(coalesce(p_data->>'description',''), 2000);

  -- étapes applicables (seuil comparé dans la devise du seuil ; devise différente → l'étape s'applique)
  for s in select a.value from jsonb_array_elements(c->'steps') a loop
    if s->'seuil' is null or jsonb_typeof(s->'seuil') = 'null'
       or upper(devise) <> upper(coalesce(s->'seuil'->>'devise',''))
       or coalesce(montant,0) >= coalesce(nullif(s->'seuil'->>'montant','')::numeric,0) then
      steps := steps || jsonb_build_array(s);
    end if;
  end loop;
  if jsonb_array_length(steps) = 0 then return wf_refus('Aucune étape applicable pour ce dossier.'); end if;

  who := wf_acteur(p_org);
  nom := coalesce(nullif(who->>'name',''), who->>'role', '?');
  typ := coalesce(c->>'type', p_data->>'type', 'autre');

  insert into wf_compteur(org_id,annee,dernier) values (p_org, an, 1)
  on conflict (org_id,annee) do update set dernier = wf_compteur.dernier + 1
  returning dernier into n;
  numero := 'WF-' || an::text || '-' || lpad(n::text, 4, '0');

  d := jsonb_build_object(
    'id', p_id, 'no', numero, 'circuit_id', c->>'id', 'circuit_nom', c->>'nom', 'type', typ,
    'titre', left(titre,200), 'description', descr, 'ref', p_data->'ref', 'montant', montant, 'devise', devise,
    'initiateur', jsonb_build_object('name', coalesce(who->>'name',''), 'role', coalesce(who->>'role',''), 'uid', who->>'id'),
    'distincts', coalesce((c->>'distincts')::boolean, true),
    'autoApprobation', coalesce((c->>'autoApprobation')::boolean, false),
    'status', 'en_cours', 'version', 1, 'steps', steps, 'cur', 0, 'decisions', '[]'::jsonb,
    'history', jsonb_build_array(jsonb_build_object('t', t, 'acteur', nom, 'fonction', coalesce(who->>'role',''),
              'action', 'soumis', 'etape', steps->0->>'nom', 'version', 1, 'motif', descr, 'circuit', c->>'nom')),
    'cree', t, 'maj', t, 'fin', '', 'debutEtape', t, 'echeance', wf_echeance(steps->0));

  insert into wf_dossiers(org_id,id,no,status,revision,data,cree_par) values (p_org, p_id, numero, 'en_cours', 1, d, auth.uid());
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org, auth.uid(), 'wf_dossiers', p_id, 'soumission', 1);
  return jsonb_build_object('ok',true,'revision',1,'dossier',d);
end $$;

-- Décision : approuver / refuser / corriger. La ligne est verrouillée : deux validateurs simultanés sont traités l'un après l'autre,
-- chacun sur l'état réel laissé par le précédent. p_etape / p_version : étape et version que la personne a sous les yeux
-- (si le dossier a avancé entre-temps, la décision est refusée plutôt que posée sur autre chose que ce qui a été relu).
create or replace function wf_decider(p_org uuid, p_id text, p_action text, p_motif text default '', p_etape int default null, p_version int default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  d jsonb; who jsonb; per jsonb; rev int; cur int; ver int; stp jsonb; decis jsonb; h jsonb; nb int; complete boolean; ev text;
  mo text := btrim(coalesce(p_motif,'')); t text := wf_now(); nom text; apk text;
begin
  if auth.uid() is null then return wf_refus('Non connecté.'); end if;
  if not est_membre(p_org, array['admin','editeur']) then return wf_refus('Droits insuffisants (compte lecteur).'); end if;
  if p_action not in ('approuver','refuser','corriger') then return wf_refus('Action inconnue.'); end if;

  select data, revision into d, rev from wf_dossiers where org_id = p_org and id = p_id for update;
  if not found then return wf_refus('Dossier introuvable.'); end if;
  if d->>'status' <> 'en_cours' then
    return wf_refus('Ce dossier n''est plus en cours (' || wf_statut(d->>'status') || ').');
  end if;
  cur := (d->>'cur')::int; ver := (d->>'version')::int;
  if (p_etape is not null and p_etape <> cur) or (p_version is not null and p_version <> ver) then
    return wf_refus('Le dossier a changé depuis que vous l''avez ouvert : relisez-le avant de décider.');
  end if;
  if p_action in ('refuser','corriger') and length(mo) < 3 then
    return wf_refus(case when p_action = 'refuser' then 'Un refus' else 'Une demande de correction' end || ' doit être motivé(e).');
  end if;

  who := wf_acteur(p_org);
  per := wf_peut(p_org, d, who);
  if per is null then return wf_refus('Ce n''est pas à vous de décider à cette étape.'); end if;
  if (d->'initiateur'->>'uid') = (who->>'id') and not coalesce((d->>'autoApprobation')::boolean, false) then
    return wf_refus('Séparation des tâches : l''initiateur ne peut pas décider de son propre dossier.');
  end if;
  if p_action = 'approuver' and coalesce((d->>'distincts')::boolean, true) then
    if exists (select 1 from jsonb_array_elements(d->'decisions') x
                where (x.value->>'version')::int = ver and x.value->>'action' = 'approuver'
                  and (x.value->>'step')::int <> cur and x.value->>'uid' = who->>'id') then
      return wf_refus('Une même personne ne peut pas approuver deux étapes du même dossier.');
    end if;
  end if;

  stp := d->'steps'->cur;
  apk := wf_cle(per->'ap');
  nom := coalesce(nullif(who->>'name',''), who->>'role', '?');
  decis := jsonb_build_object('step', cur, 'version', ver, 'approver', apk, 'acteur', nom, 'uid', who->>'id',
                            'action', p_action, 't', t, 'motif', mo, 'pour', coalesce(per->>'pour',''));
  h := jsonb_build_object('t', t, 'acteur', nom, 'fonction', coalesce(who->>'role',''), 'action', p_action,
                          'etape', stp->>'nom', 'version', ver, 'motif', mo, 'verifie', true);
  if coalesce(per->>'pour','') <> '' then h := h || jsonb_build_object('pour', per->>'pour'); end if;

  insert into wf_decisions(org_id,dossier_id,dversion,step,approver,acteur_id,acteur,action,motif,pour)
    values (p_org, p_id, ver, cur, apk, auth.uid(), nom, p_action, mo, coalesce(per->>'pour',''));

  d := jsonb_set(d, '{decisions}', coalesce(d->'decisions','[]'::jsonb) || jsonb_build_array(decis));
  d := jsonb_set(d, '{history}',   coalesce(d->'history','[]'::jsonb)   || jsonb_build_array(h));
  d := jsonb_set(d, '{maj}', to_jsonb(t));

  if p_action = 'refuser' then
    d := d || jsonb_build_object('status','refuse','fin',t,'echeance','');
    ev := 'refuse';
  elsif p_action = 'corriger' then
    d := d || jsonb_build_object('status','retourne','echeance','');
    ev := 'retourne';
  else
    select count(*) into nb from jsonb_array_elements(stp->'approvers') a
     where wf_cle(a.value) in (select x.value->>'approver' from jsonb_array_elements(d->'decisions') x
                                where (x.value->>'step')::int = cur and (x.value->>'version')::int = ver
                                  and x.value->>'action' = 'approuver');
    complete := case when stp->>'mode' = 'un_seul' then nb >= 1 else nb >= jsonb_array_length(stp->'approvers') end;
    if not complete then
      ev := 'decision';
    elsif cur + 1 >= jsonb_array_length(d->'steps') then
      d := d || jsonb_build_object('status','valide','fin',t,'echeance','');
      d := jsonb_set(d, '{history}', d->'history' || jsonb_build_array(jsonb_build_object(
             't', t, 'acteur', nom, 'fonction', coalesce(who->>'role',''), 'action', 'valide',
             'etape', stp->>'nom', 'version', ver, 'motif', '')));
      ev := 'valide';
    else
      d := d || jsonb_build_object('cur', cur + 1, 'debutEtape', t, 'echeance', wf_echeance(d->'steps'->(cur + 1)));
      ev := 'etape';
    end if;
  end if;

  update wf_dossiers set data = d, status = d->>'status', revision = rev + 1, maj = now()
   where org_id = p_org and id = p_id;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org, auth.uid(), 'wf_dossiers', p_id, 'decision:' || p_action, rev + 1);
  return jsonb_build_object('ok',true,'event',ev,'revision',rev + 1,'dossier',d);
end $$;

-- Nouvelle soumission après « À corriger » (initiateur seulement) : version suivante, retour à l'étape 1, historique conservé
create or replace function wf_resoumettre(p_org uuid, p_id text, p_note text default '')
returns jsonb language plpgsql security definer set search_path=public as $$
declare d jsonb; who jsonb; rev int; ver int; t text := wf_now(); nom text; note text := left(btrim(coalesce(p_note,'')),2000);
begin
  if auth.uid() is null then return wf_refus('Non connecté.'); end if;
  if not est_membre(p_org, array['admin','editeur']) then return wf_refus('Droits insuffisants (compte lecteur).'); end if;
  select data, revision into d, rev from wf_dossiers where org_id = p_org and id = p_id for update;
  if not found then return wf_refus('Dossier introuvable.'); end if;
  if d->>'status' <> 'retourne' then return wf_refus('Ce dossier n''est pas à corriger.'); end if;
  who := wf_acteur(p_org);
  if (d->'initiateur'->>'uid') is distinct from (who->>'id') then return wf_refus('Seul l''initiateur peut soumettre à nouveau.'); end if;
  ver := (d->>'version')::int + 1;
  nom := coalesce(nullif(who->>'name',''), who->>'role', '?');
  d := d || jsonb_build_object('version', ver, 'status', 'en_cours', 'cur', 0, 'fin', '', 'maj', t,
                               'debutEtape', t, 'echeance', wf_echeance(d->'steps'->0));
  d := jsonb_set(d, '{history}', d->'history' || jsonb_build_array(jsonb_build_object(
         't', t, 'acteur', nom, 'fonction', coalesce(who->>'role',''), 'action', 'resoumis',
         'etape', d->'steps'->0->>'nom', 'version', ver, 'motif', note)));
  update wf_dossiers set data = d, status = 'en_cours', revision = rev + 1, maj = now() where org_id = p_org and id = p_id;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org, auth.uid(), 'wf_dossiers', p_id, 'resoumission', rev + 1);
  return jsonb_build_object('ok',true,'event','resoumis','revision',rev + 1,'dossier',d);
end $$;

-- Annulation (initiateur ou administrateur, motif obligatoire)
create or replace function wf_annuler(p_org uuid, p_id text, p_motif text default '')
returns jsonb language plpgsql security definer set search_path=public as $$
declare d jsonb; who jsonb; rev int; t text := wf_now(); nom text; mo text := btrim(coalesce(p_motif,''));
begin
  if auth.uid() is null then return wf_refus('Non connecté.'); end if;
  if not est_membre(p_org, array['admin','editeur']) then return wf_refus('Droits insuffisants (compte lecteur).'); end if;
  select data, revision into d, rev from wf_dossiers where org_id = p_org and id = p_id for update;
  if not found then return wf_refus('Dossier introuvable.'); end if;
  if d->>'status' not in ('en_cours','retourne') then return wf_refus('Ce dossier est déjà clos.'); end if;
  who := wf_acteur(p_org);
  if (d->'initiateur'->>'uid') is distinct from (who->>'id') and (who->>'rl') is distinct from 'admin' then
    return wf_refus('Seul l''initiateur ou un administrateur peut annuler.');
  end if;
  if length(mo) < 3 then return wf_refus('Un motif d''annulation est obligatoire.'); end if;
  nom := coalesce(nullif(who->>'name',''), who->>'role', '?');
  d := d || jsonb_build_object('status','annule','fin',t,'echeance','','maj',t);
  d := jsonb_set(d, '{history}', d->'history' || jsonb_build_array(jsonb_build_object(
         't', t, 'acteur', nom, 'fonction', coalesce(who->>'role',''), 'action', 'annule',
         'etape', d->'steps'->((d->>'cur')::int)->>'nom', 'version', (d->>'version')::int, 'motif', mo)));
  update wf_dossiers set data = d, status = 'annule', revision = rev + 1, maj = now() where org_id = p_org and id = p_id;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org, auth.uid(), 'wf_dossiers', p_id, 'annulation', rev + 1);
  return jsonb_build_object('ok',true,'event','annule','revision',rev + 1,'dossier',d);
end $$;

-- ---------- 5. Autorisations d'appel ----------
revoke all on function wf_acteur(uuid), wf_peut(uuid,jsonb,jsonb) from public, anon, authenticated;
revoke all on function wf_etat(uuid), wf_config_ecrire(uuid,text,text,jsonb,boolean), wf_soumettre(uuid,text,text,jsonb),
  wf_decider(uuid,text,text,text,int,int), wf_resoumettre(uuid,text,text), wf_annuler(uuid,text,text) from public, anon;
grant execute on function wf_etat(uuid), wf_config_ecrire(uuid,text,text,jsonb,boolean), wf_soumettre(uuid,text,text,jsonb),
  wf_decider(uuid,text,text,text,int,int), wf_resoumettre(uuid,text,text), wf_annuler(uuid,text,text) to authenticated;
-- Facultatif (les autres appareils voient une décision aussitôt, au lieu d'attendre ~30 s) :
-- alter publication supabase_realtime add table wf_dossiers;

-- ---------- 6. Contrôles (à lancer à la main) ----------
-- a) Tables : select to_regclass('public.wf_dossiers'), to_regclass('public.wf_decisions');           -- 2 valeurs non nulles
-- b) Fonctions : select proname from pg_proc where proname in ('wf_etat','wf_config_ecrire','wf_soumettre','wf_decider',
--      'wf_resoumettre','wf_annuler','wf_acteur','wf_peut','wf_attendus','wf_match','wf_norm');           -- 11 lignes
-- c) Normalisation : select wf_norm('  Directeur   Général '), wf_norm('Bureau d’études');              -- 'directeur general', 'bureau d''etudes'
-- d) Circuit à étape parallèle : à deux comptes (A et B), soumettre un dossier avec 2 approbateurs « tous doivent approuver »,
--    puis faire approuver A et B au même instant : les DEUX décisions doivent apparaître dans select * from wf_decisions;
-- e) Écriture directe refusée : insert into wf_dossiers(org_id,id,no,status,data) values (gen_random_uuid(),'x','x','x','{}');  -- doit échouer
