-- ===== Excellencia Building — V217 : synchronisation de l'ATELIER DE MISE EN PAGE (Bureau d'études – Ingénieur) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v99zn, v99zo et v99zw. Additive et réexécutable sans danger.
--
--  1. Fiches : 4 collections de la base partagée (mep_documents, mep_versions, mep_journal, mep_modeles). Aucune table nouvelle :
--     elles passent par la table « enregistrements » et la fonction enregistrer() existantes (version, conflits, journal serveur).
--     Droits : copiés depuis « plans_fichiers » (mêmes fonctions que pour les plans), plus bureau_etudes et direction (lecture + écriture).
--  2. Fichiers PDF : espace PRIVÉ « exb-atelier », un dossier par entreprise : <id entreprise>/<empreinte SHA-256>.pdf
--     · lecture : droit de lecture sur « mep_documents » ; envoi : droit d'écriture + licence valide ;
--     · AUCUNE règle de modification ni de suppression : un fichier envoyé est IMMUABLE (le nom est son empreinte).
--  Le contenu d'un PDF n'est jamais interprété par le serveur.

do $$ begin
  if to_regprocedure('public.peut(uuid,text,boolean)') is null or to_regclass('public.droits_fonction') is null then
    raise exception 'Exécutez d''abord migration-v99zn-synchro-modules.sql (droits par fonction).';
  end if;
  if to_regprocedure('public.licence_ecriture_ok(uuid)') is null then
    raise exception 'Exécutez d''abord migration-v99zo-securite-serveur.sql (licence).';
  end if;
end $$;

-- ---------- 1. Droits des collections ----------
insert into droits_fonction(fonction, collection, lire, ecrire)
select d.fonction, c.col, d.lire, d.ecrire
from droits_fonction d
cross join (values ('mep_documents'), ('mep_versions'), ('mep_journal'), ('mep_modeles')) as c(col)
where d.collection = 'plans_fichiers'
on conflict do nothing;

insert into droits_fonction(fonction, collection, lire, ecrire)
select f.fonction, c.col, true, true
from (values ('bureau_etudes'), ('direction')) as f(fonction)
cross join (values ('mep_documents'), ('mep_versions'), ('mep_journal'), ('mep_modeles')) as c(col)
on conflict do nothing;

-- ---------- 2. Espace de fichiers privé et immuable ----------
insert into storage.buckets(id, name, public, file_size_limit)
values ('exb-atelier', 'exb-atelier', false, 314572800)
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit;

create or replace function org_du_chemin(p_name text) returns uuid language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

drop policy if exists atelier_lire on storage.objects;
create policy atelier_lire on storage.objects for select to authenticated
  using (bucket_id = 'exb-atelier' and peut(org_du_chemin(name), 'mep_documents', false));
drop policy if exists atelier_ajout on storage.objects;
create policy atelier_ajout on storage.objects for insert to authenticated
  with check (bucket_id = 'exb-atelier' and name ~ '^[0-9a-f-]{36}/[0-9a-f]{64}\.pdf$'
              and peut(org_du_chemin(name), 'mep_documents', true) and licence_ecriture_ok(org_du_chemin(name)));
-- volontairement : pas de règle update ni delete (fichiers immuables).
drop policy if exists atelier_modif on storage.objects;
drop policy if exists atelier_suppr on storage.objects;
