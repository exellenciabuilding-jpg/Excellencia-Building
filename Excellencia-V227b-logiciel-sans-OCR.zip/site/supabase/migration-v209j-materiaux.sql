-- V209J — Architecture : matériaux et finitions (collection arch_materiaux)
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','arch_materiaux',true,true),
 ('chef_projet','arch_materiaux',true,true),
 ('bureau_etudes','arch_materiaux',true,true),
 ('architecte','arch_materiaux',true,true),
 ('comptable','arch_materiaux',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
