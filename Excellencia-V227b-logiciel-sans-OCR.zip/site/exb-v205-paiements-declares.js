/* Excellencia Building V205 lot 5b — Paiements déclarés par les apprenants → Espace Comptable.
 * Un apprenant qui déclare son paiement Mobile Money (formulaire d'inscription, table paiements_declares) arrive ici, dans
 * « 🧾 Reçus de paiement » : le comptable vérifie, confirme (ou rejette) et prépare le reçu. L'enregistrement du reçu, l'envoi à
 * l'espace apprenant et la mise à jour « payé / pas encore payé » de la liste des apprenants restent ceux d'avant (inchangés).
 * Côté serveur : migration-v205-lot5b-paiements-comptable.sql (le comptable/direction lit et vérifie ; les autres fonctions non). */
(function (w, d) {
  'use strict';
  var $ = function (i) { return d.getElementById(i); };
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function dg(v) { return String(v || '').replace(/\D/g, ''); }
  function online() { try { return !!(w.exbSb && w.exbSb.isIn && w.exbSb.isIn()); } catch (e) { return false; } }
  function P() { try { return typeof participants !== 'undefined' && participants || []; } catch (e) { return []; } }
  var rows = [];
  function findParticipant(x) {
    return P().filter(function (q) { return x.matricule && (q.matricule === x.matricule || q.matricule_en_ligne === x.matricule); })[0] ||
      P().filter(function (q) { return dg(q.phone).length >= 6 && (dg(q.phone) === dg(x.telephone) || dg(q.phone) === dg(x.numero_payeur)); })[0];
  }
  function mount() {
    var sec = $('receipts'); if (!sec || $('exbDeclCard')) return;
    var c = d.createElement('div'); c.id = 'exbDeclCard'; c.className = 'card no-print'; c.style.marginBottom = '14px';
    c.innerHTML = '<h2>📥 Paiements déclarés par les apprenants <span id="exbDeclCnt" class="hint"></span></h2>' +
      '<p class="hint" style="margin:0 0 6px">L’apprenant a envoyé son paiement Mobile Money et l’a déclaré (numéro, référence). Vérifiez-le dans votre relevé, puis « Confirmer et faire le reçu ». Le reçu enregistré arrive dans son espace apprenant ; la liste des apprenants (Formation) passe à « payé ».</p>' +
      '<div id="exbDeclBanner" class="msg"></div><div id="exbDeclList"></div><button type="button" class="muted" id="exbDeclRef">↻ Actualiser</button>';
    var pp = $('payPanel'); if (pp && pp.parentNode === sec) sec.insertBefore(c, pp); else sec.insertBefore(c, sec.firstChild);
    $('exbDeclRef').onclick = load;
    $('exbDeclList').addEventListener('click', onClick);
  }
  function draw() {
    var L = $('exbDeclList'); if (!L) return;
    $('exbDeclCnt').textContent = rows.length ? '(' + rows.length + ' à vérifier)' : '';
    L.innerHTML = rows.length ? rows.map(function (x) {
      return '<div style="border:1px solid #d5dbe5;border-radius:10px;padding:10px;margin:8px 0" data-id="' + esc(x.id) + '"><div><b>' + esc(x.nom || '—') + '</b>' + (x.matricule ? ' <span class="hint">· ' + esc(x.matricule) + '</span>' : '') + '</div>' +
        '<div class="hint">' + esc(x.telephone || '') + ' · ' + esc(x.reseau || '') + ' · payeur ' + esc(x.numero_payeur || '') + '</div>' +
        '<div style="margin:4px 0"><b>' + esc(x.montant) + ' ' + esc(x.devise) + '</b> · Réf. <b>' + esc(x.reference) + '</b>' + (x.doublon ? ' <span style="color:#b91c1c">⚠ référence déjà utilisée</span>' : '') + ' <small class="hint">' + esc(new Date(x.created_at).toLocaleString('fr-FR')) + '</small></div>' +
        '<div style="display:flex;gap:6px;flex-wrap:wrap"><button type="button" data-dact="confirme" style="background:#18733b;color:#fff">🧾 Confirmer et faire le reçu</button><button type="button" data-dact="rejete" style="background:#fee2e2;color:#b91c1c">✗ Rejeter</button></div></div>';
    }).join('') : '<p class="hint">Aucun paiement déclaré à vérifier.</p>';
  }
  async function load() {
    mount(); var L = $('exbDeclList'); if (!L) return;
    if (!online()) { L.innerHTML = '<p class="hint">Connectez-vous (en ligne) pour voir les paiements déclarés par les apprenants.</p>'; return; }
    try {
      var r = await w.exbSb.api('/rest/v1/paiements_declares?type=eq.apprenant&statut=eq.a_verifier&select=*&order=created_at.desc&limit=100');
      rows = Array.isArray(r) ? r : []; draw();
    } catch (e) { L.innerHTML = '<p class="ann">Impossible de lire les paiements déclarés : ' + esc(e && e.message || e) + ' — exécutez migration-v205-lot5b-paiements-comptable.sql dans Supabase.</p>'; }
  }
  async function setStatut(id, s) {
    await w.exbSb.api('/rest/v1/paiements_declares?id=eq.' + encodeURIComponent(id), { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'Prefer': 'return=representation' }, body: JSON.stringify({ statut: s, verifie_le: new Date().toISOString() }) });
  }
  async function onClick(e) {
    var b = e.target.closest && e.target.closest('button[data-dact]'); if (!b) return;
    var h = b.closest('[data-id]'), id = h && h.getAttribute('data-id'), x = rows.filter(function (r) { return String(r.id) === String(id); })[0], bn = $('exbDeclBanner');
    if (!x) return;
    try {
      if (b.getAttribute('data-dact') === 'rejete') { await setStatut(id, 'rejete'); bn.innerHTML = '<span class="valid">Paiement rejeté : ' + esc(x.nom || '') + '</span>'; await load(); return; }
      await setStatut(id, 'confirme');
      var p = findParticipant(x), msg = 'Paiement confirmé : <b>' + esc(x.montant) + ' ' + esc(x.devise) + '</b> (réf. ' + esc(x.reference) + ') de <b>' + esc(x.nom || '') + '</b>.';
      if (p && typeof w.prepareReceiptFromParticipant === 'function') { w.prepareReceiptFromParticipant(p); bn.innerHTML = '<span class="valid">' + msg + ' Reçu préparé : vérifiez les montants et les statuts (inscription / formation) puis « Enregistrer ».</span>'; }
      else bn.innerHTML = '<span class="ann">' + msg + ' Apprenant introuvable dans la liste locale : importez-le avec « 🧾 Faire le reçu » dans « Apprenants inscrits en ligne » ci-dessous.</span>';
      await load();
    } catch (err) { bn.innerHTML = '<span class="ann">Échec : ' + esc(err && err.message || err) + '</span>'; }
  }
  var _show = w.show;
  if (typeof _show === 'function') w.show = function (x) { var r = _show.apply(this, arguments); if (x === 'receipts') { try { load(); } catch (e) {} } return r; };
  w.exbDeclPaiements = { load: load, mount: mount };
})(window, document);
