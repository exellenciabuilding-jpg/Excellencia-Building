/* Excellencia Scanner (module 13) — numérisation intégrée à l'ERP, dépôt direct dans Archives (EXBAR.add).
   Moteur pur (testé sous Node) + écran. Aucune dépendance externe. */
(function (w, d) {
  'use strict';
  var TWORDS = [['facture', 'facture'], ['devis', 'devis'], ['plan', 'plan'], ['contrat', 'contrat'], ['certificat', 'certificat'], ['rapport', 'rapport'], ['note de calcul', 'note'], ['note', 'note'], ['courrier', 'courrier'], ['lettre', 'courrier'], ['reception', 'pv'], ['pv', 'pv'], ['photo', 'photo']];
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }
  function guessType(n) { n = norm(n); for (var i = 0; i < TWORDS.length; i++) if (n.indexOf(TWORDS[i][0]) > -1) return TWORDS[i][1]; return 'autre'; }
  function guessService(t) { return { plan: 'etudes', note: 'etudes', devis: 'commercial', contrat: 'commercial', facture: 'finance', pv: 'chantier', rapport: 'chantier', certificat: 'formation' }[t] || ''; }

  /* ---- détection du cadre du document (rectangle) : pixels RGBA réduits → boîte {x0,y0,x1,y1} ou null ---- */
  function autoCropBox(D, w0, h0) {
    var tot = w0 * h0, G = new Uint8Array(tot), H = new Array(256).fill(0), i, k;
    for (i = 0; i < tot; i++) { G[i] = (D[i * 4] * 77 + D[i * 4 + 1] * 150 + D[i * 4 + 2] * 29) >> 8; H[G[i]]++; }
    var sum = 0; for (k = 0; k < 256; k++) sum += k * H[k];
    var sB = 0, wB = 0, mx = -1, T = 127;
    for (k = 0; k < 256; k++) { wB += H[k]; if (!wB) continue; var wF = tot - wB; if (!wF) break; sB += k * H[k]; var d1 = sB / wB, d2 = (sum - sB) / wF, v = wB * wF * (d1 - d2) * (d1 - d2); if (v > mx) { mx = v; T = k; } }
    var bs = 0, bn = 0, cs = 0, cn = 0, e = Math.max(2, Math.round(Math.min(w0, h0) * 0.06)), x, y;
    for (y = 0; y < h0; y++) for (x = 0; x < w0; x++) { var g = G[y * w0 + x]; if (x < e || y < e || x >= w0 - e || y >= h0 - e) { bs += g; bn++; } else if (x > w0 * 0.3 && x < w0 * 0.7 && y > h0 * 0.3 && y < h0 * 0.7) { cs += g; cn++; } }
    var light = (cs / Math.max(1, cn)) > (bs / Math.max(1, bn)), M = new Uint8Array(tot);
    for (i = 0; i < tot; i++) M[i] = light ? (G[i] > T ? 1 : 0) : (G[i] < T ? 1 : 0);
    var L = new Int32Array(tot), best = 0, bb = null, id = 0, st = [], px, j;
    for (i = 0; i < tot; i++) {
      if (!M[i] || L[i]) continue; id++; var n = 0, x0 = w0, y0 = h0, x1 = 0, y1 = 0; st.length = 0; st.push(i); L[i] = id;
      while (st.length) {
        px = st.pop(); n++; var X = px % w0, Y = (px - X) / w0; if (X < x0) x0 = X; if (X > x1) x1 = X; if (Y < y0) y0 = Y; if (Y > y1) y1 = Y;
        var nb = [X > 0 ? px - 1 : -1, X < w0 - 1 ? px + 1 : -1, Y > 0 ? px - w0 : -1, Y < h0 - 1 ? px + w0 : -1];
        for (j = 0; j < 4; j++) { var q = nb[j]; if (q > -1 && M[q] && !L[q]) { L[q] = id; st.push(q); } }
      }
      if (n > best) { best = n; bb = { x0: x0, y0: y0, x1: x1, y1: y1 }; }
    }
    if (!bb) return null;
    var ar = ((bb.x1 - bb.x0 + 1) * (bb.y1 - bb.y0 + 1)) / tot; if (ar < 0.15 || ar > 0.97 || best / tot < 0.1) return null;
    var pad = Math.round(Math.min(w0, h0) * 0.01);
    return { x0: Math.max(0, bb.x0 - pad), y0: Math.max(0, bb.y0 - pad), x1: Math.min(w0 - 1, bb.x1 + pad), y1: Math.min(h0 - 1, bb.y1 + pad) };
  }

  /* ---- V2 : détection par différence avec le fond, 4 coins, redressement ---- */
  function med(a) { a.sort(function (x, y) { return x - y; }); return a[a.length >> 1]; }
  function hull(P) {
    P.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
    function cr(o, a, b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); }
    var lo = [], up = [], i;
    for (i = 0; i < P.length; i++) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], P[i]) <= 0) lo.pop(); lo.push(P[i]); }
    for (i = P.length - 1; i >= 0; i--) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], P[i]) <= 0) up.pop(); up.push(P[i]); }
    lo.pop(); up.pop(); return lo.concat(up);
  }
  function detectQuad(D, w0, h0) {
    var tot = w0 * h0, e = Math.max(2, Math.round(Math.min(w0, h0) * 0.04)), R = [], Gc = [], B = [], x, y, i, k;
    for (y = 0; y < h0; y++) for (x = 0; x < w0; x++) if (x < e || y < e || x >= w0 - e || y >= h0 - e) { i = (y * w0 + x) * 4; R.push(D[i]); Gc.push(D[i + 1]); B.push(D[i + 2]); }
    var br = med(R), bg = med(Gc), bb = med(B), dd = new Uint8Array(tot), H = new Array(256).fill(0), bsum = 0, bn = 0;
    for (y = 0; y < h0; y++) for (x = 0; x < w0; x++) { i = y * w0 + x; var q = i * 4, v0 = Math.min(255, (Math.abs(D[q] - br) + Math.abs(D[q + 1] - bg) + Math.abs(D[q + 2] - bb)) >> 1); dd[i] = v0; H[v0]++; if (x < e || y < e || x >= w0 - e || y >= h0 - e) { bsum += v0; bn++; } }
    var sum = 0; for (k = 0; k < 256; k++) sum += k * H[k];
    var sB = 0, wB = 0, mx = -1, T = 20;
    for (k = 0; k < 256; k++) { wB += H[k]; if (!wB) continue; var wF = tot - wB; if (!wF) break; sB += k * H[k]; var d1 = sB / wB, d2 = (sum - sB) / wF, vv = wB * wF * (d1 - d2) * (d1 - d2); if (vv > mx) { mx = vv; T = k; } }
    T = Math.max(14 + 2 * (bsum / Math.max(1, bn)), Math.min(T, 30));
    var M = new Uint8Array(tot); for (i = 0; i < tot; i++) M[i] = dd[i] > T ? 1 : 0;
    var L = new Int32Array(tot), best = 0, bid = 0, id = 0, st = [], px, j;
    for (i = 0; i < tot; i++) {
      if (!M[i] || L[i]) continue; id++; var n = 0; st.length = 0; st.push(i); L[i] = id;
      while (st.length) { px = st.pop(); n++; var X = px % w0, Y = (px - X) / w0, nb = [X > 0 ? px - 1 : -1, X < w0 - 1 ? px + 1 : -1, Y > 0 ? px - w0 : -1, Y < h0 - 1 ? px + w0 : -1]; for (j = 0; j < 4; j++) { var qq = nb[j]; if (qq > -1 && M[qq] && !L[qq]) { L[qq] = id; st.push(qq); } } }
      if (n > best) { best = n; bid = id; }
    }
    if (!bid || best / tot < 0.1) return null;
    var P = [];
    for (y = 0; y < h0; y++) for (x = 0; x < w0; x++) { i = y * w0 + x; if (L[i] !== bid) continue; if (x === 0 || y === 0 || x === w0 - 1 || y === h0 - 1 || L[i - 1] !== bid || L[i + 1] !== bid || L[i - w0] !== bid || L[i + w0] !== bid) P.push([x, y]); }
    if (P.length < 8) return null;
    var Hl = hull(P), ba = 1e18, bt = 0, t;
    for (t = -45; t <= 45; t++) { var c = Math.cos(t * Math.PI / 180), sn = Math.sin(t * Math.PI / 180), u0 = 1e9, u1 = -1e9, v0b = 1e9, v1 = -1e9; Hl.forEach(function (p) { var u = p[0] * c + p[1] * sn, v = -p[0] * sn + p[1] * c; if (u < u0) u0 = u; if (u > u1) u1 = u; if (v < v0b) v0b = v; if (v > v1) v1 = v; }); var ar = (u1 - u0) * (v1 - v0b); if (ar < ba) { ba = ar; bt = t; } }
    var cs = Math.cos(bt * Math.PI / 180), sn2 = Math.sin(bt * Math.PI / 180), tl = null, tr = null, brr = null, bl = null, a1 = 1e9, a2 = -1e9, a3 = -1e9, a4 = 1e9;
    Hl.forEach(function (p) { var u = p[0] * cs + p[1] * sn2, v = -p[0] * sn2 + p[1] * cs, s1 = u + v, s2 = u - v; if (s1 < a1) { a1 = s1; tl = p; } if (s2 > a2) { a2 = s2; tr = p; } if (s1 > a3) { a3 = s1; brr = p; } if (s2 < a4) { a4 = s2; bl = p; } });
    var Q = [tl, tr, brr, bl].map(function (p) { return { x: p[0], y: p[1] }; });
    var area = Math.abs((Q[0].x * Q[1].y - Q[1].x * Q[0].y) + (Q[1].x * Q[2].y - Q[2].x * Q[1].y) + (Q[2].x * Q[3].y - Q[3].x * Q[2].y) + (Q[3].x * Q[0].y - Q[0].x * Q[3].y)) / 2;
    if (area / tot < 0.12 || area / tot > 0.985 || best / area < 0.6) return null;
    var ctr = Q.reduce(function (a, p) { return { x: a.x + p.x / 4, y: a.y + p.y / 4 }; }, { x: 0, y: 0 });
    return Q.map(function (p) { var dx = p.x - ctr.x, dy = p.y - ctr.y, l = Math.sqrt(dx * dx + dy * dy) || 1, g = 1 + 1 / l; return { x: Math.max(0, Math.min(w0 - 1, ctr.x + dx * g)), y: Math.max(0, Math.min(h0 - 1, ctr.y + dy * g)) }; });
  }
  function quadSize(Q, cap) {
    function ds(a, b) { return Math.sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)); }
    var ow = (ds(Q[0], Q[1]) + ds(Q[3], Q[2])) / 2, oh = (ds(Q[0], Q[3]) + ds(Q[1], Q[2])) / 2, s = Math.min(1, (cap || 1800) / Math.max(ow, oh, 1));
    return { w: Math.max(1, Math.round(ow * s)), h: Math.max(1, Math.round(oh * s)) };
  }
  function warp(src, sw, sh, Q, ow, oh) {
    var x0 = Q[0].x, y0 = Q[0].y, x1 = Q[1].x, y1 = Q[1].y, x2 = Q[2].x, y2 = Q[2].y, x3 = Q[3].x, y3 = Q[3].y, a, b, c, dd, e, f, g, h;
    var sx = x0 - x1 + x2 - x3, sy = y0 - y1 + y2 - y3;
    if (Math.abs(sx) < 1e-9 && Math.abs(sy) < 1e-9) { a = x1 - x0; b = x3 - x0; c = x0; dd = y1 - y0; e = y3 - y0; f = y0; g = 0; h = 0; }
    else { var dx1 = x1 - x2, dx2 = x3 - x2, dy1 = y1 - y2, dy2 = y3 - y2, den = dx1 * dy2 - dx2 * dy1; g = (sx * dy2 - dx2 * sy) / den; h = (dx1 * sy - sx * dy1) / den; a = x1 - x0 + g * x1; b = x3 - x0 + h * x3; c = x0; dd = y1 - y0 + g * y1; e = y3 - y0 + h * y3; f = y0; }
    var out = new Uint8ClampedArray(ow * oh * 4), X, Y, o = 0;
    for (Y = 0; Y < oh; Y++) for (X = 0; X < ow; X++, o += 4) {
      var u = (X + 0.5) / ow, v = (Y + 0.5) / oh, z = g * u + h * v + 1, px = (a * u + b * v + c) / z - 0.5, py = (dd * u + e * v + f) / z - 0.5;
      px = Math.max(0, Math.min(sw - 1.001, px)); py = Math.max(0, Math.min(sh - 1.001, py));
      var ix = px | 0, iy = py | 0, fx = px - ix, fy = py - iy, i00 = (iy * sw + ix) * 4, i10 = i00 + 4, i01 = i00 + sw * 4, i11 = i01 + 4;
      for (var ch = 0; ch < 4; ch++) out[o + ch] = (src[i00 + ch] * (1 - fx) + src[i10 + ch] * fx) * (1 - fy) + (src[i01 + ch] * (1 - fx) + src[i11 + ch] * fx) * fy;
    }
    return out;
  }

  /* ---- PDF multipages (JPEG intégré) avec métadonnées (UTF-16BE) ---- */
  function hx(t) { var h = 'FEFF'; String(t || '').split('').forEach(function (c) { h += ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }); return '<' + h + '>'; }
  function buildPdf(pages, meta) {
    var en = new TextEncoder(), P = [], off = 0, xr = [], n = pages.length; meta = meta || {};
    function wr(x) { var b = typeof x === 'string' ? en.encode(x) : x; P.push(b); off += b.length; }
    function ob(k, s, bin) { xr[k] = off; wr(k + ' 0 obj\n' + s); if (bin) { wr(bin); wr('\nendstream'); } wr('\nendobj\n'); }
    wr('%PDF-1.4\n'); ob(1, '<</Type/Catalog/Pages 2 0 R>>');
    ob(2, '<</Type/Pages/Count ' + n + '/Kids[' + pages.map(function (_, i) { return (3 + i * 3) + ' 0 R'; }).join(' ') + ']>>');
    pages.forEach(function (p, i) {
      var b = 3 + i * 3, s = Math.min(595 / p.w, 842 / p.h), W = p.w * s, H = p.h * s;
      ob(b, '<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Resources<</XObject<</I ' + (b + 2) + ' 0 R>>>>/Contents ' + (b + 1) + ' 0 R>>');
      var c = 'q ' + W.toFixed(1) + ' 0 0 ' + H.toFixed(1) + ' ' + ((595 - W) / 2).toFixed(1) + ' ' + ((842 - H) / 2).toFixed(1) + ' cm /I Do Q';
      ob(b + 1, '<</Length ' + c.length + '>>stream\n' + c + '\nendstream');
      ob(b + 2, '<</Type/XObject/Subtype/Image/Width ' + p.w + '/Height ' + p.h + '/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ' + p.jpeg.length + '>>stream\n', p.jpeg);
    });
    var N = 3 + n * 3; ob(N, '<</Title ' + hx(meta.title) + '/Subject ' + hx(meta.subject) + '/Keywords ' + hx(meta.keywords) + '/Author ' + hx(meta.author) + '/Creator ' + hx('Excellencia Scanner') + '>>'); N++;
    var sx = off; wr('xref\n0 ' + N + '\n0000000000 65535 f \n'); for (var i = 1; i < N; i++) wr(String(xr[i]).padStart(10, '0') + ' 00000 n \n');
    wr('trailer\n<</Size ' + N + '/Root 1 0 R/Info ' + (N - 1) + ' 0 R>>\nstartxref\n' + sx + '\n%%EOF');
    var out = new Uint8Array(off), p0 = 0; P.forEach(function (b) { out.set(b, p0); p0 += b.length; }); return out;
  }
  function safeName(s) { return String(s || '').normalize('NFC').replace(/[^\w\u00C0-\u017F-]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '') || 'Scan'; }
  /* V152 : rattachement aux fiches réelles (projet / client) par identifiant stable, quand le nom saisi correspond exactement à une fiche. */
  function nrm(x) { return String(x == null ? '' : x).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function findId(list, names, v) { v = nrm(v); if (!v) return null; var hit = (list || []).filter(function (x) { return names.some(function (k) { return x && x[k] && nrm(x[k]) === v; }); }); return hit.length === 1 && hit[0].id != null ? String(hit[0].id) : null; }
  function srcLinks(f, idScan) {
    var o = { module: 'scanner', id: idScan }, p = null, c = null;
    try { p = findId(w.exbProjects, ['name', 'title', 'nom'], f.projet); c = findId(w.exbClients, ['full_name', 'company'], f.client); } catch (e) {}
    if (p) o.projetId = p; if (c) o.clientId = c; return o;
  }
  function archiveMeta(f, pagesCount, idScan) {
    return { titre: String(f.titre || '').trim(), type: f.type, projet: f.projet || '', client: f.client || '', service: f.service || '', motsCles: f.motsCles || '', description: f.description || ('Numérisé — ' + pagesCount + ' page' + (pagesCount > 1 ? 's' : '')), conservationAns: f.conservationAns === undefined ? '' : f.conservationAns, source: srcLinks(f, idScan) };
  }
  var ENGINE = { detectQuad: detectQuad, quadSize: quadSize, warp: warp, hull: hull, guessType: guessType, guessService: guessService, autoCropBox: autoCropBox, buildPdf: buildPdf, hx: hx, safeName: safeName, archiveMeta: archiveMeta };
  if (typeof module !== 'undefined' && module.exports) module.exports = { engine: ENGINE };
  if (!d) return; w.EXBSC = { version: 2, engine: ENGINE, pages: function () { return S.pages.map(function (x) { return x.c; }); }, types: function () { return TY(); } };

  /* ================= Écran ================= */
  var MAXB = 15 * 1048576, S = { pages: [], cur: -1, mode: 'new', last: null }, LOGK = 'exb_sc_log';
  var FL = { Original: 'none', 'N&B': 'grayscale(1) contrast(2.2) brightness(1.1)', Gris: 'grayscale(1)', Contraste: 'contrast(1.5)', 'Améliorer': 'contrast(1.2) brightness(1.08) saturate(1.1)' };
  function $(i) { return d.getElementById(i); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'info', 5000); } catch (e) {} }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function emit(n, p) { try { if (w.EXBCore && w.EXBCore.bus) w.EXBCore.bus.emit(n, p, 'scanner'); } catch (e) {} }
  function getLog() { try { return JSON.parse((w.exbStorage || w.localStorage).getItem(LOGK)) || []; } catch (e) { return []; } }
  function putLog(L) { try { (w.exbStorage || w.localStorage).setItem(LOGK, JSON.stringify(L.slice(0, 50))); } catch (e) {} }
  function loadImg(file) { return new Promise(function (res, rej) { var i = new Image(), u = URL.createObjectURL(file); i.onload = function () { var s = Math.min(1, 1800 / Math.max(i.width, i.height)), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(i.width * s)); c.height = Math.max(1, Math.round(i.height * s)); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c); }; i.onerror = function () { rej(new Error('Image illisible : ' + file.name)); }; i.src = u; }); }
  function detect(c) {
    var m = Math.min(1, 320 / Math.max(c.width, c.height)), w1 = Math.max(8, Math.round(c.width * m)), h1 = Math.max(8, Math.round(c.height * m)), t = d.createElement('canvas'); t.width = w1; t.height = h1;
    var x = t.getContext('2d', { willReadFrequently: true }); x.drawImage(c, 0, 0, w1, h1); var D = x.getImageData(0, 0, w1, h1).data, f = c.width / w1, q = detectQuad(D, w1, h1);
    if (q) return q.map(function (p) { return { x: p.x * f, y: p.y * f }; });
    var bx = autoCropBox(D, w1, h1); if (!bx) return null;
    return [{ x: bx.x0 * f, y: bx.y0 * f }, { x: (bx.x1 + 1) * f, y: bx.y0 * f }, { x: (bx.x1 + 1) * f, y: (bx.y1 + 1) * f }, { x: bx.x0 * f, y: (bx.y1 + 1) * f }];
  }
  function render(p, q) { var c = d.createElement('canvas'); c.width = p.c.width; c.height = p.c.height; var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.filter = FL[p.f] || 'none'; x.drawImage(p.c, 0, 0); x.filter = 'none'; return { url: c.toDataURL('image/jpeg', q), w: c.width, h: c.height }; }
  function b2u(u) { var b = atob(u.split(',')[1]), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function pdfFor(meta) {
    var q = 0.85, out;
    for (var t = 0; t < 4; t++, q -= 0.12) { out = buildPdf(S.pages.map(function (p) { var r = render(p, q); return { jpeg: b2u(r.url), w: r.w, h: r.h }; }), meta); if (out.length <= MAXB) break; }
    return out;
  }
  function sugg() { var p = {}, c = {}; (w.exbProjects || []).forEach(function (x) { var n = x.name || x.title || x.nom; if (n) p[n] = 1; }); (w.exbClients || []).forEach(function (x) { var n = x.full_name || x.company; if (n) c[n] = 1; }); try { (w.EXBAR ? w.EXBAR.list() : []).forEach(function (x) { if (x.projet) p[x.projet] = 1; if (x.client) c[x.client] = 1; }); } catch (e) {} return '<datalist id="sc_pl">' + Object.keys(p).map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist><datalist id="sc_cl">' + Object.keys(c).map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist>'; }
  function opts(o, sel) { return Object.keys(o).map(function (k) { return '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + esc(o[k]) + '</option>'; }).join(''); }
  function TY() { return (w.EXBAR && w.EXBAR.engine && w.EXBAR.engine.TYPES) || { autre: 'Autre' }; }
  function SV() { return (w.EXBAR && w.EXBAR.engine && w.EXBAR.engine.SERVICES) || {}; }

  function view() {
    var b = $('sc_box'); if (!b) return;
    if (!w.EXBAR) { b.innerHTML = '<p style="color:#b91c1c">Le module Archives n’est pas chargé : le dépôt est impossible.</p>'; return; }
    var cur = S.pages[S.cur], last = S.last;
    var thumbs = S.pages.map(function (p, i) { return '<div style="display:inline-block;margin:0 6px 6px 0;text-align:center;font-size:11px"><img data-i="' + i + '" class="sc-th" src="' + p.th + '" style="height:64px;border:2px solid ' + (i === S.cur ? '#c49a38' : '#bbb') + ';border-radius:6px;cursor:pointer"><br>' + (i + 1) + ' <a href="#" class="sc-up" data-i="' + i + '">◀</a> <a href="#" class="sc-dn" data-i="' + i + '">▶</a> <a href="#" class="sc-rm" data-i="' + i + '">✕</a></div>'; }).join('');
    var type0 = S.meta ? S.meta.type : 'autre';
    b.innerHTML = sugg() +
      (last ? '<div style="background:#eef8f0;border-left:5px solid #1fa44a;padding:8px 10px;border-radius:8px;margin-bottom:10px">✅ Déposé dans Archives : <b>' + esc(last.no) + '</b> — ' + esc(last.titre) + '</div>' : '') +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px"><button type="button" id="sc_cam">📷 Photographier</button><button type="button" id="sc_imp">🖼 Importer des images</button><span style="font-size:12px;opacity:.7;align-self:center">Plusieurs pages = un seul PDF.</span></div>' +
      '<input id="sc_fc" type="file" accept="image/*" capture="environment" hidden><input id="sc_fi" type="file" accept="image/*" multiple hidden>' +
      (S.pages.length ? '<div>' + thumbs + '</div><canvas id="sc_cv" style="width:100%;max-width:560px;background:#eee;border-radius:8px;touch-action:none"></canvas>' +
        '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><button type="button" id="sc_auto">🔲 Cadre auto</button><button type="button" id="sc_crop">' + (cur && cur.cropMode ? '✔ Appliquer et redresser' : '✂️ Recadrer') + '</button><button type="button" id="sc_rot">⟳ Rotation</button><select id="sc_fl">' + Object.keys(FL).map(function (f) { return '<option' + (cur && cur.f === f ? ' selected' : '') + '>' + esc(f) + '</option>'; }).join('') + '</select></div>' +
        '<form id="sc_f" style="display:grid;gap:8px;max-width:560px;border-top:1px solid #0002;padding-top:10px"><b>Vérifiez les informations avant le dépôt</b>' +
        '<label>Titre <input id="sc_t" required maxlength="160" value="' + esc(S.meta.titre) + '"></label>' +
        '<label>Type <select id="sc_ty">' + opts(TY(), S.meta.type) + '</select></label>' +
        '<label>Projet <input id="sc_p" list="sc_pl" value="' + esc(S.meta.projet) + '"></label>' +
        '<label>Client <input id="sc_c" list="sc_cl" value="' + esc(S.meta.client) + '"></label>' +
        '<label>Service <select id="sc_sv"><option value="">(aucun)</option>' + opts(SV(), S.meta.service) + '</select></label>' +
        '<label>Mots-clés <input id="sc_m" value="' + esc(S.meta.motsCles) + '" placeholder="séparés par des virgules"></label>' +
        '<label>Conservation (années, vide = non définie) <input id="sc_cs" type="number" min="0" max="99" value="' + esc(S.meta.conservationAns) + '"></label>' +
        '<div id="sc_err" style="color:#b91c1c;font-size:13px"></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="submit">🗄 Déposer dans Archives (' + S.pages.length + ' page' + (S.pages.length > 1 ? 's' : '') + ')</button><button type="button" id="sc_dl">⬇ Télécharger le PDF</button><button type="button" id="sc_cl2">Annuler</button></div></form>' : '') +
      '<div style="margin-top:16px;border-top:1px solid #0002;padding-top:10px"><b>🔎 Retrouver un document par son numéro ou son QR</b><div style="display:flex;gap:6px;flex-wrap:wrap;margin:6px 0"><input id="sc_q" placeholder="Ex. ARC-2026-0001" style="flex:1;min-width:160px"><button type="button" id="sc_qs">Chercher</button><button type="button" id="sc_qr">📷 Lire un QR (photo)</button></div><input id="sc_fq" type="file" accept="image/*" capture="environment" hidden><div id="sc_qres" style="font-size:14px"></div></div>' +
      '<div style="margin-top:16px;border-top:1px solid #0002;padding-top:10px"><b>Dernières numérisations</b>' + (getLog().length ? getLog().slice(0, 10).map(function (l) { return '<div style="font-size:13px;margin-top:4px">' + esc(l.no) + ' — ' + esc(l.titre) + ' <span style="opacity:.65">(' + l.pages + ' p. · ' + new Date(l.at).toLocaleString('fr-FR') + ')</span></div>'; }).join('') : '<div style="font-size:13px;opacity:.7">Aucune pour l’instant.</div>') + '</div>';
    bind(); if (S.pages.length) paint();
  }
  function paint() {
    var p = S.pages[S.cur], v = $('sc_cv'); if (!p || !v) return; v.width = p.c.width; v.height = p.c.height; var x = v.getContext('2d'); x.filter = FL[p.f] || 'none'; x.drawImage(p.c, 0, 0); x.filter = 'none';
    var r = Math.max(10, v.width / 55);
    if (p.quad) {
      var Q = p.quad; x.save(); x.fillStyle = 'rgba(0,0,0,.45)'; x.beginPath(); x.rect(0, 0, v.width, v.height); x.moveTo(Q[0].x, Q[0].y); for (var k = 3; k >= 0; k--) x.lineTo(Q[k].x, Q[k].y); x.closePath(); x.fill('evenodd'); x.restore();
      x.strokeStyle = '#e0a82e'; x.lineWidth = Math.max(3, v.width / 150); x.beginPath(); x.moveTo(Q[0].x, Q[0].y); for (k = 1; k < 4; k++) x.lineTo(Q[k].x, Q[k].y); x.closePath(); x.stroke();
      if (p.cropMode) Q.forEach(function (pt) { x.fillStyle = '#e0a82e'; x.beginPath(); x.arc(pt.x, pt.y, r, 0, 6.2832); x.fill(); x.strokeStyle = '#fff'; x.lineWidth = 3; x.stroke(); });
    }
    var s = null, drag = -1;
    function pt(ev) { var rc = v.getBoundingClientRect(); return { x: Math.max(0, Math.min(v.width, (ev.clientX - rc.left) * v.width / rc.width)), y: Math.max(0, Math.min(v.height, (ev.clientY - rc.top) * v.height / rc.height)) }; }
    v.onpointerdown = function (ev) {
      if (!p.cropMode) return; var q = pt(ev); drag = -1;
      if (p.quad) { var bd = r * 3; p.quad.forEach(function (c, i) { var dx = c.x - q.x, dy = c.y - q.y, dist = Math.sqrt(dx * dx + dy * dy); if (dist < bd) { bd = dist; drag = i; } }); }
      if (drag < 0) s = q; v.setPointerCapture(ev.pointerId);
    };
    v.onpointermove = function (ev) {
      var q = pt(ev);
      if (drag > -1) { p.quad[drag] = { x: q.x, y: q.y }; paint(); return; }
      if (s) { var x0 = Math.min(s.x, q.x), y0 = Math.min(s.y, q.y), x1 = Math.max(s.x, q.x), y1 = Math.max(s.y, q.y); p.quad = [{ x: x0, y: y0 }, { x: x1, y: y0 }, { x: x1, y: y1 }, { x: x0, y: y1 }]; paint(); }
    };
    v.onpointerup = function () { s = null; drag = -1; };
  }
  function thumb(p) { var c = d.createElement('canvas'), s = 128 / Math.max(p.c.width, p.c.height); c.width = Math.max(1, Math.round(p.c.width * s)); c.height = Math.max(1, Math.round(p.c.height * s)); c.getContext('2d').drawImage(p.c, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', 0.6); }
  function applyCrop(p) {
    var Q = p.quad; p.quad = null; p.cropMode = false; if (!Q) return;
    var sz = quadSize(Q, 1800); if (sz.w < 20 || sz.h < 20) return;
    var sc = p.c.getContext('2d'), src = sc.getImageData(0, 0, p.c.width, p.c.height), out = warp(src.data, p.c.width, p.c.height, Q, sz.w, sz.h), n = d.createElement('canvas'); n.width = sz.w; n.height = sz.h;
    var img = n.getContext('2d').createImageData(sz.w, sz.h); img.data.set(out); n.getContext('2d').putImageData(img, 0, 0); p.c = n; p.th = thumb(p);
  }
  function addFiles(files, auto, fromCam) {
    var arr = [].slice.call(files || []); if (!arr.length) return Promise.resolve();
    return arr.reduce(function (pr, f) { return pr.then(function () { return loadImg(f).then(function (c) { var p = { c: c, f: 'Original', quad: null, cropMode: false, th: '' }; if (auto) { var r = null; try { r = detect(c); } catch (e) {} if (r) { p.quad = r; p.cropMode = true; } } p.th = thumb(p); S.pages.push(p); S.cur = S.pages.length - 1; if (!S.meta) { var nm = (arr.length === 1 && !fromCam ? f.name.replace(/\.[^.]+$/, '') : '') || ('Scan ' + new Date().toLocaleDateString('fr-FR')); var ty = guessType(nm); S.meta = { titre: nm, type: ty, projet: '', client: '', service: guessService(ty), motsCles: '', conservationAns: '' }; } }); }); }, Promise.resolve()).then(function () { var p = S.pages[S.cur]; if (auto && p && p.quad) say('Cadre détecté — déplacez les coins si besoin, puis « Appliquer et redresser ».', 'info'); view(); }).catch(function (e) { say(e.message, 'error'); view(); });
  }
  function readForm() { S.meta = { titre: $('sc_t').value, type: $('sc_ty').value, projet: $('sc_p').value, client: $('sc_c').value, service: $('sc_sv').value, motsCles: $('sc_m').value, conservationAns: $('sc_cs').value }; return S.meta; }
  function metaPdf(m) { return { title: m.titre, subject: (TY()[m.type] || '') + (m.projet ? ' — ' + m.projet : ''), keywords: [m.projet, m.client, m.motsCles].filter(Boolean).join(', '), author: 'Excellencia Building' }; }
  function reset() { S.pages = []; S.cur = -1; S.meta = null; }
  function bind() {
    var g = function (i) { return $(i); };
    g('sc_cam').onclick = function () { var f = g('sc_fc'); f.value = ''; f.onchange = function () { addFiles(f.files, true, true); }; f.click(); };
    g('sc_imp').onclick = function () { var f = g('sc_fi'); f.value = ''; f.onchange = function () { addFiles(f.files, true, false); }; f.click(); };
    [].forEach.call(d.querySelectorAll('#sc_box .sc-th'), function (e) { e.onclick = function () { S.cur = +e.dataset.i; view(); }; });
    [].forEach.call(d.querySelectorAll('#sc_box .sc-up,#sc_box .sc-dn,#sc_box .sc-rm'), function (e) { e.onclick = function (ev) { ev.preventDefault(); var i = +e.dataset.i, P = S.pages; if (e.className === 'sc-rm') { P.splice(i, 1); S.cur = Math.min(S.cur, P.length - 1); if (!P.length) reset(); } else { var j = e.className === 'sc-up' ? i - 1 : i + 1; if (j < 0 || j >= P.length) return; var t = P[i]; P[i] = P[j]; P[j] = t; S.cur = j; } view(); }; });
    if (S.pages.length) {
      var p = S.pages[S.cur];
      g('sc_auto').onclick = function () { var r = null; try { r = detect(p.c); } catch (e) {} if (r) { p.quad = r; p.cropMode = true; say('Cadre détecté.', 'info'); } else say('Cadre non détecté : recadrez à la main.', 'warn'); readForm(); view(); };
      g('sc_crop').onclick = function () { readForm(); if (p.cropMode) applyCrop(p); else p.cropMode = true; view(); };
      g('sc_rot').onclick = function () { readForm(); var c = d.createElement('canvas'); c.width = p.c.height; c.height = p.c.width; var x = c.getContext('2d'); x.translate(c.width, 0); x.rotate(Math.PI / 2); x.drawImage(p.c, 0, 0); p.c = c; p.quad = null; p.cropMode = false; p.th = thumb(p); view(); };
      g('sc_fl').onchange = function () { readForm(); p.f = g('sc_fl').value; view(); };
      g('sc_ty').onchange = function () { var m = readForm(); if (!m.service) { S.meta.service = guessService(m.type); } view(); };
      g('sc_cl2').onclick = function () { reset(); view(); };
      g('sc_dl').onclick = function () { var m = readForm(); S.pages.forEach(applyCrop); var u = pdfFor(metaPdf(m)), a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([u], { type: 'application/pdf' })); a.download = safeName(m.titre) + '.pdf'; a.click(); };
      g('sc_f').onsubmit = function (e) { e.preventDefault(); depose(); };
    }
    g('sc_qs').onclick = function () { search(g('sc_q').value); };
    g('sc_q').onkeydown = function (e) { if (e.key === 'Enter') search(g('sc_q').value); };
    g('sc_qr').onclick = function () { var f = g('sc_fq'); f.value = ''; f.onchange = function () { readQr(f.files[0]); }; f.click(); };
  }
  async function depose() {
    var err = $('sc_err'), m = readForm(); err.textContent = ''; S.pages.forEach(applyCrop);
    var idScan = 'sc_' + Date.now().toString(36), meta = archiveMeta(m, S.pages.length, idScan), u;
    try { u = pdfFor(metaPdf(m)); } catch (e) { err.textContent = 'Création du PDF impossible : ' + e.message; return; }
    if (u.length > MAXB) { err.textContent = 'PDF trop lourd (' + (u.length / 1048576).toFixed(1) + ' Mo, maximum 15 Mo). Retirez des pages.'; return; }
    meta.fichier = new Blob([u], { type: 'application/pdf' }); meta.nom = safeName(m.titre) + '.pdf'; meta.mime = 'application/pdf';
    var btn = d.querySelector('#sc_f button[type=submit]'); if (btn) btn.disabled = true;
    var r = await w.EXBAR.add(meta);
    if (!r || !r.ok) { err.textContent = (r && r.error) || 'Dépôt refusé.'; if (btn) btn.disabled = false; return; }
    var n = S.pages.length, L = getLog(); L.unshift({ no: r.doc.no, titre: r.doc.titre, pages: n, at: Date.now() }); putLog(L);
    audit('scanner.numerise', r.doc.no, { pages: n, type: r.doc.type }); emit('scanner.numerise', { archiveId: r.doc.id, no: r.doc.no, pages: n });
    S.last = { no: r.doc.no, titre: r.doc.titre }; reset(); say('Document déposé dans Archives : ' + r.doc.no, 'success'); view();
  }
  function search(q) {
    var out = $('sc_qres'); q = String(q || '').trim(); if (!q) { out.textContent = 'Saisissez un numéro.'; return; }
    var m = q.match(/ARC-\d{4}-\d{4}/i), no = (m ? m[0] : q).toUpperCase(), L = [];
    try { L = w.EXBAR.list().filter(function (x) { return x.no === no; }); } /* list() ne renvoie que les documents que l'utilisateur a le droit de voir */ catch (e) {}
    if (!L.length) { out.innerHTML = '<span style="color:#b91c1c">Aucun document accessible avec ce numéro.</span> <span style="opacity:.7">(ou accès non autorisé)</span>'; return; }
    var x = L[0]; out.innerHTML = '<div style="background:#f3f6fc;border-radius:8px;padding:8px 10px"><b>' + esc(x.no) + '</b> — ' + esc(x.titre) + '<br><span style="font-size:12px;opacity:.75">' + esc(TY()[x.type] || x.type) + (x.projet ? ' · ' + esc(x.projet) : '') + (x.client ? ' · ' + esc(x.client) : '') + '</span><br><button type="button" id="sc_open" style="margin-top:6px">Ouvrir dans Archives</button></div>';
    $('sc_open').onclick = function () { try { w.show('exbar'); } catch (e) {} };
  }
  async function readQr(file) {
    var out = $('sc_qres'); if (!file) return;
    if (!w.BarcodeDetector) { out.innerHTML = '<span style="color:#b45309">Lecture de QR non disponible sur ce navigateur : saisissez le numéro à la main.</span>'; return; }
    try { var bm = await createImageBitmap(file), r = await new w.BarcodeDetector({ formats: ['qr_code'] }).detect(bm); if (!r.length) { out.textContent = 'Aucun QR lisible sur la photo.'; return; } $('sc_q').value = r[0].rawValue; search(r[0].rawValue); } catch (e) { out.textContent = 'Lecture impossible.'; }
  }

  function mount() {
    var ref = $('exbar') || $('exbwf') || $('exbbi') || $('budgetfin') || $('chantiers') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, s = d.createElement('section');
    s.id = 'exbsc'; s.style.display = 'none';
    s.innerHTML = '<div class="card"><div class="exb-module-head"><div><h2>📷 Excellencia Scanner</h2><p class="exb-muted">Numérisation : photo ou import, cadre automatique, rotation, filtres, PDF multipages, vérification des informations puis dépôt direct dans Archives.</p></div></div><div id="sc_box"></div></div>';
    if (ref && ref.parentNode) ref.parentNode.insertBefore(s, ref.nextSibling); else host.appendChild(s);
    var b = $('bar') || $('bwf') || $('bbi') || $('bbfin') || $('bchan') || $('bprj');
    if (b && !$('bsc')) { var n = d.createElement('button'); n.id = 'bsc'; n.textContent = '📷 Scanner'; n.setAttribute('onclick', "show('exbsc')"); b.parentNode.insertBefore(n, b.nextSibling); }
    var os = w.show;
    if (typeof os === 'function' && !w.__exbScShow) { w.__exbScShow = 1; w.show = function (x) { var r = os.apply(this, arguments), e = $('exbsc'); if (e) e.style.display = (x === 'exbsc') ? '' : 'none'; if (x === 'exbsc') view(); return r; }; }
  }
  function watch() { setInterval(function () { try { if (d.hidden) return; if (!$('exbsc') || !$('bsc')) { var e = $('exbsc'); if (e && !$('bsc')) e.remove(); mount(); } } catch (e) {} }, 3000); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(mount, 1300); watch(); }); else { setTimeout(mount, 1300); watch(); }
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
