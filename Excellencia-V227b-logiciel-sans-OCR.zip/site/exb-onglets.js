/* Excellencia Building V181 — onglets uniformes dans tous les modules, en colonne latérale ou barre du bas (comme la barre des modules).
 *
 * V181 : au lieu d'une rangée en haut, les onglets se rangent À GAUCHE (colonne, comme dans « Calcul de structure ») ou EN BAS,
 * se réduisent en icônes (« » ) et se rouvrent d'un appui ; deux petits boutons en bout de barre : « réduire/ouvrir » et « position »
 * (Auto → Gauche → Bas → Haut). « Auto » suit le réglage de la barre des modules (⚙ Gauche / Bas), sinon : gauche sur grand écran,
 * bas sur téléphone. Le choix est mémorisé sur l'appareil. Toutes les barres (dès 2 onglets) suivent ce réglage ; un panneau plein écran en colonne (messagerie)
 * reçoit la barre en bas. Aucun clic, droit ou donnée de module n'est modifié.
 *
 * (V179 ci-dessous : une seule ligne défilante.)
 * Excellencia Building V179 — onglets uniformes dans tous les modules.
 *
 * Problème : chaque module dessinait sa barre d'onglets à sa façon (styles écrits dans le code, retour à la ligne
 * automatique). Résultat : dans « Finances & comptabilité » les 10 onglets passaient sur deux lignes, et les autres
 * modules (Admin, CRM, Stock, Budget, Contrôles, Décomptes, Métrés, Portails, Archives, Workflow…) avaient chacun
 * un aspect différent.
 *
 * Solution : ce module reconnaît toutes les barres d'onglets connues (même celles créées plus tard par un module)
 * et leur applique le même comportement :
 *   - une seule ligne, qui défile horizontalement au doigt / à la molette quand il y a trop d'onglets
 *     (le nombre d'onglets peut donc augmenter sans casser la mise en page : l'onglet actif est recentré tout seul) ;
 *   - même taille, même espacement, même repère d'onglet actif (trait doré + gras) ;
 *   - léger dégradé sur le bord quand d'autres onglets sont cachés ;
 *   - rôles d'accessibilité (tablist / tab / aria-selected) et flèches ← → au clavier.
 * Aucun code métier n'est modifié : les clics, les droits et les données des modules restent inchangés.
 * Pour qu'un futur module en profite : lui donner simplement la classe « exb-tabs » (ou l'ajouter à SEL ci-dessous). */
(function (w, d) {
  'use strict';
  if (w.EXBOnglets) return;

  /* barres connues : classes historiques des modules + classe commune exb-tabs */
  var SEL = ['.exb-tabs', '.cpt_tabs', '.adm_tabs', '.crp_tabs', '.stp_tabs', '.bf-tabs', '.mbtabs', '.exb-v51-tabs', '.pt-tabs', '#exbMsgr .tabs', '#exbPayBar', '#payTabs', '#mb_seg', '.exbs-tabs'].join(',');

  var CSS = '' +
    '.exb-onglets{display:flex!important;flex-wrap:nowrap!important;align-items:stretch;gap:4px;overflow-x:auto;overflow-y:hidden;max-width:100%;box-sizing:border-box;margin:8px 0 12px;padding:0;border-bottom:2px solid var(--line,#dbe3ef);-webkit-overflow-scrolling:touch;scrollbar-width:none;overscroll-behavior-x:contain}' +
    '.exb-onglets::-webkit-scrollbar{display:none;height:0}' +
    '.exb-onglets>button{flex:0 0 auto!important;width:auto!important;min-width:0!important;min-height:40px;margin:0!important;padding:9px 14px!important;box-sizing:border-box;border:0!important;border-bottom:3px solid transparent!important;border-radius:8px 8px 0 0!important;outline:0!important;background:transparent!important;box-shadow:none!important;color:inherit!important;font:inherit;font-size:13px!important;font-weight:600!important;line-height:1.2;white-space:nowrap;cursor:pointer;opacity:.78;-webkit-tap-highlight-color:transparent}' +
    '.exb-onglets>button:hover{opacity:1;background:rgba(23,53,101,.08)!important}' +
    '.exb-onglets>button:focus-visible{outline:2px solid var(--g,#c49a38)!important;outline-offset:-2px}' +
    '.exb-onglets>button.exb-on{opacity:1;font-weight:700!important;border-bottom-color:var(--g,#c49a38)!important;background:rgba(196,154,56,.14)!important}' +
    '.exb-onglets>button .bd{margin-left:6px}' +
    '.exb-onglets.exb-sc-r{-webkit-mask-image:linear-gradient(to right,#000 calc(100% - 26px),transparent);mask-image:linear-gradient(to right,#000 calc(100% - 26px),transparent)}' +
    '.exb-onglets.exb-sc-l{-webkit-mask-image:linear-gradient(to left,#000 calc(100% - 26px),transparent);mask-image:linear-gradient(to left,#000 calc(100% - 26px),transparent)}' +
    '.exb-onglets.exb-sc-l.exb-sc-r{-webkit-mask-image:linear-gradient(to right,transparent,#000 26px,#000 calc(100% - 26px),transparent);mask-image:linear-gradient(to right,transparent,#000 26px,#000 calc(100% - 26px),transparent)}' +
    '.exb-onglets>.exb-ctl{flex:0 0 auto;display:flex;gap:2px;align-items:center;order:99;margin-left:auto;padding-left:4px}' +
    '.exb-ctl>span{display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:15px;line-height:1;color:#64748b;user-select:none;-webkit-user-select:none}' +
    '.exb-ctl>span:hover{background:rgba(23,53,101,.12)}.exb-ctl>span:focus-visible{outline:2px solid var(--g,#c49a38);outline-offset:-2px}' +
    '.exb-onglets:not(.exb-rl):not(.exb-rb)>.exb-ctl>.exb-c-min{display:none}' +
    '.exb-host-l.exb-host-l{display:grid;grid-template-columns:max-content minmax(0,1fr);column-gap:14px;row-gap:0;align-items:start}' +
    '.exb-host-l.exb-host-l>*{grid-column:2;min-width:0}' +
    '.exb-host-l.exb-host-l>.exb-onglets{grid-column:1;grid-row:1 / span 80;align-self:start}' +
    '.exb-host-b.exb-host-b{display:flex;flex-direction:column}' +
    '.exb-host-b.exb-host-b>*{flex-shrink:0}' +
    '.exb-onglets.exb-rl,.exb-onglets.exb-rb{-webkit-mask-image:none!important;mask-image:none!important;background:var(--exb-rb,#12254a)!important;border-bottom:0!important;box-shadow:0 4px 16px rgba(15,46,102,.28)}' +
    '.exb-onglets.exb-rl{flex-direction:column!important;position:sticky;top:8px;width:172px;max-height:calc(100vh - 20px);overflow-x:hidden;overflow-y:auto;border-radius:16px;padding:8px 0 10px 8px!important;margin:0 0 12px;gap:4px;z-index:6}' +
    '.exb-onglets.exb-rl>button{width:100%!important;justify-content:flex-start;text-align:left;white-space:normal!important;color:#fff!important;border-radius:12px 0 0 12px!important;padding:10px!important;opacity:.95;overflow-wrap:anywhere}' +
    '.exb-onglets.exb-rl>button:hover,.exb-onglets.exb-rb>button:hover{background:rgba(255,255,255,.16)!important}' +
    '.exb-onglets.exb-rl>button.exb-on{background:#fff!important;color:var(--exb-rb,#12254a)!important;box-shadow:inset 5px 0 0 var(--exb-ra,#c8962e)!important}' +
    '.exb-onglets.exb-rl>.exb-ctl{order:-1;margin:0;padding:0 6px 4px 0;justify-content:flex-end}' +
    '.exb-onglets.exb-rb{position:sticky;bottom:var(--exb-b,0px);order:9999;flex:none;margin:14px 0 0;padding:6px 8px!important;border-top:3px solid var(--exb-ra,#c8962e)!important;border-radius:14px 14px 0 0;z-index:6;box-shadow:0 -4px 16px rgba(15,46,102,.28)}' +
    '.exb-onglets.exb-rb>button{color:#fff!important;border:1px solid rgba(255,255,255,.35)!important;border-radius:10px!important;min-height:42px}' +
    '.exb-onglets.exb-rb>button.exb-on{background:#fff!important;color:var(--exb-rb,#12254a)!important;border-color:#fff!important;box-shadow:inset 0 -4px 0 var(--exb-ra,#c8962e)!important}' +
    '.exb-onglets.exb-rl>.exb-ctl>span,.exb-onglets.exb-rb>.exb-ctl>span{color:var(--exb-ra2,#e3b85a)}' +
    '.exb-onglets.exb-rl>.exb-ctl>span:hover,.exb-onglets.exb-rb>.exb-ctl>span:hover{background:rgba(255,255,255,.16)}' +
    '.exb-onglets.exb-rc>button{font-size:0!important;justify-content:center!important;gap:0}' +
    '.exb-onglets.exb-rc>button::before{content:attr(data-ic);font-size:19px;line-height:1;font-style:normal;font-weight:700}' +
    '.exb-onglets.exb-rc>button .bd{display:none}' +
    '.exb-onglets.exb-rl.exb-rc{width:52px;padding-left:4px}' +
    '.exb-onglets.exb-rl.exb-rc>button{padding:9px 0!important;border-radius:12px!important;min-height:42px}' +
    '.exb-onglets.exb-rl.exb-rc>.exb-ctl{justify-content:center;padding-right:4px}' +
    '.exb-onglets.exb-rb.exb-rc>button{padding:0 14px!important}' +
    '@media print{.exb-host-l.exb-host-l,.exb-host-b.exb-host-b{display:block}}' +
    '@media (max-width:640px){.exb-onglets>button{padding:9px 11px!important;min-height:42px}}' +
    '@media print{.exb-onglets{display:none!important}}';

  /* ---------- préférences (mémorisées sur l'appareil) ---------- */
  var KEY = 'exb_onglets_v1';
  function readPref() {
    try { var o = JSON.parse(w.localStorage.getItem(KEY) || 'null'); return { pos: o && /^(auto|left|bottom|top)$/.test(o.pos) ? o.pos : 'auto', compact: !!(o && o.compact) }; } catch (e) { return { pos: 'auto', compact: false }; }
  }
  var pref = readPref();
  function savePref() { try { w.localStorage.setItem(KEY, JSON.stringify(pref)); } catch (e) { /* stockage indisponible : le choix vaut pour cette séance */ } }
  function dockCfg() { try { var o = JSON.parse(w.localStorage.getItem('exb_dock_v1') || 'null'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; } }
  function posNow() {
    if (pref.pos !== 'auto') return pref.pos;
    var l = dockCfg().layout;
    return l === 'left' || l === 'bottom' ? l : (w.innerWidth >= 900 ? 'left' : 'bottom');
  }
  function lighten(h) { var n = parseInt(h.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255; function m(c) { return Math.round(c + (255 - c) * 0.35); } return '#' + [m(r), m(g), m(b)].map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join(''); }
  /* couleurs : celles de la barre des modules (⚙), sinon bleu nuit + or ; hauteur à laisser libre quand cette barre est en bas */
  function vars() {
    var root = d.documentElement, c = dockCfg(), hex = /^#[0-9a-fA-F]{6}$/;
    root.style.setProperty('--exb-rb', hex.test(c.bg) ? c.bg : '#12254a');
    root.style.setProperty('--exb-ra', hex.test(c.acc) ? c.acc : '#c8962e');
    root.style.setProperty('--exb-ra2', hex.test(c.acc) ? lighten(c.acc) : '#e3b85a');
    var dk = d.getElementById('exbDock'), b = 0;
    if (dk && dk.classList.contains('on') && dk.classList.contains('bottom') && !dk.classList.contains('mini') && !dk.classList.contains('free')) b = dk.offsetHeight || 0;
    root.style.setProperty('--exb-b', b + 'px');
  }
  var GLYPH = { auto: '⇄', left: '◧', bottom: '⬓', top: '⬒' }, LABEL = { auto: 'Auto (suit la barre des modules)', left: 'À gauche', bottom: 'En bas', top: 'En haut' };
  function icon(b) {
    var t = (b.textContent || '').trim(), m = null;
    try { m = t.match(/^(?:\p{Extended_Pictographic}\uFE0F?(?:\u200D\p{Extended_Pictographic}\uFE0F?)*)/u); } catch (e) { m = null; }
    return m ? m[0] : (t.replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2).toUpperCase() || '•');
  }
  function ctl(c) {
    var k = null, i;
    for (i = 0; i < c.children.length; i++) if (c.children[i].classList && c.children[i].classList.contains('exb-ctl')) { k = c.children[i]; break; }
    if (!k) {
      k = d.createElement('div'); k.className = 'exb-ctl';
      k.innerHTML = '<span class="exb-c-min" data-a="min" role="button" tabindex="0"></span><span class="exb-c-pos" data-a="pos" role="button" tabindex="0"></span>';
      c.appendChild(k);
    }
    var mn = k.firstChild, ps = k.lastChild;
    mn.textContent = pref.compact ? '»' : '«'; mn.title = pref.compact ? 'Ouvrir les onglets' : 'Réduire en icônes'; mn.setAttribute('aria-label', mn.title);
    ps.textContent = GLYPH[pref.pos]; ps.title = 'Position des onglets : ' + LABEL[pref.pos] + ' — appuyer pour changer'; ps.setAttribute('aria-label', ps.title);
  }
  /* range la barre : colonne à gauche, barre en bas, ou rangée en haut (et dit ce qui a été choisi) */
  function layout(c, n) {
    var host = c.parentElement, m = posNow(), had = !!host && (host.classList.contains('exb-host-l') || host.classList.contains('exb-host-b')), ok = true, col = false;
    if (m === 'top' || n < 2 || !host || host === d.body || host === d.documentElement) ok = false;
    else if (!had) {
      var cs = w.getComputedStyle(host), disp = cs.display;
      if (/flex/.test(disp) && /column/.test(cs.flexDirection) && host.children.length >= 2) { col = true; }   /* panneau plein écran en colonne (messagerie…) : la barre passe en bas */
      else if (/flex|grid|none|inline|table/.test(disp) || host.children.length < 2) ok = false;
    } else if (host.children.length < 2) ok = false;
    else if (host.getAttribute('data-exb-col') === '1') col = true;
    if (host) { if (col) host.setAttribute('data-exb-col', '1'); else host.removeAttribute('data-exb-col'); }
    var L = ok && !col && m === 'left', B = ok && (col || m === 'bottom');
    if (host) { host.classList.toggle('exb-host-l', L); host.classList.toggle('exb-host-b', B && !col); }
    c.classList.toggle('exb-rl', L); c.classList.toggle('exb-rb', B); c.classList.toggle('exb-rc', ok && pref.compact);
    return L ? 'l' : B ? 'b' : 't';
  }

  function css() {
    if (d.getElementById('exbOngletsCss')) return;
    var s = d.createElement('style'); s.id = 'exbOngletsCss'; s.textContent = CSS;
    (d.head || d.documentElement).appendChild(s);
  }

  function has(b, c) { return b.classList.contains(c); }

  /* quel bouton est l'onglet actif ? chaque module le signale à sa manière */
  function actives(btns) {
    var on = btns.map(function (b) { return has(b, 'on') || has(b, 'active') || has(b, 'exb-on-src'); });
    if (on.some(Boolean)) return on;
    if (btns.some(function (b) { return has(b, 'muted'); })) return btns.map(function (b) { return !has(b, 'muted'); });
    if (btns.some(function (b) { return has(b, 'pt-s'); })) return btns.map(function (b) { return !has(b, 'pt-s'); });
    return btns.map(function (b) {
      var st = b.getAttribute('style') || '';
      return /font-weight\s*:\s*(700|bold)/i.test(st) || /outline\s*:\s*[1-9]/i.test(st) || /border(-bottom)?\s*:\s*[23]px\s+solid/i.test(st);
    });
  }

  function fade(c) {
    if (c.classList.contains('exb-rl') || c.classList.contains('exb-rb')) { c.classList.remove('exb-sc-l', 'exb-sc-r'); return; }
    var more = c.scrollWidth > c.clientWidth + 2;
    c.classList.toggle('exb-sc-l', more && c.scrollLeft > 2);
    c.classList.toggle('exb-sc-r', more && c.scrollLeft + c.clientWidth < c.scrollWidth - 2);
  }

  function reveal(c, b) {
    if (b && c.classList.contains('exb-rl')) { if (c.scrollHeight > c.clientHeight + 2 && (b.offsetTop < c.scrollTop + 4 || b.offsetTop + b.offsetHeight > c.scrollTop + c.clientHeight - 4)) c.scrollTop = Math.max(0, b.offsetTop - 40); return; }
    if (!b || c.scrollWidth <= c.clientWidth + 2) return;
    var l = b.offsetLeft, r = l + b.offsetWidth;
    if (l < c.scrollLeft + 8 || r > c.scrollLeft + c.clientWidth - 8) c.scrollLeft = Math.max(0, l - (c.clientWidth - b.offsetWidth) / 2);
  }

  function apply(c) {
    var btns = Array.prototype.filter.call(c.children, function (n) { return n.tagName === 'BUTTON'; });
    if (!btns.length) return;
    if (!c.classList.contains('exb-onglets')) {
      c.classList.add('exb-onglets'); c.setAttribute('role', 'tablist');
      c.addEventListener('scroll', function () { fade(c); }, { passive: true });
      c.addEventListener('keydown', function (e) {
        var rt = e.key === 'ArrowRight' || e.key === 'ArrowDown', lf = e.key === 'ArrowLeft' || e.key === 'ArrowUp';
        if (!rt && !lf) return;
        var l = Array.prototype.filter.call(c.children, function (n) { return n.tagName === 'BUTTON'; }), i = l.indexOf(d.activeElement);
        if (i < 0) return; e.preventDefault();
        var n = l[(i + (rt ? 1 : l.length - 1)) % l.length]; n.focus(); reveal(c, n);
      });
    }
    var a = actives(btns), cur = null, key = '';
    var lay = layout(c, btns.length);
    ctl(c);
    btns.forEach(function (b, i) {
      b.setAttribute('role', 'tab');
      var lb = (b.textContent || '').trim(), ic = icon(b);
      if (b.getAttribute('data-ic') !== ic) b.setAttribute('data-ic', ic);
      if (!b.getAttribute('title') || b.getAttribute('data-exb-t') === '1') { b.setAttribute('title', lb); b.setAttribute('data-exb-t', '1'); } b.setAttribute('aria-selected', a[i] ? 'true' : 'false');
      b.classList.toggle('exb-on', !!a[i]);
      if (a[i]) { cur = b; key += i; }
    });
    /* on ne recentre que lorsque l'onglet actif a changé, pour ne pas bloquer le défilement de la personne */
    if (c.getAttribute('data-exb-act') !== key + '/' + btns.length + lay) { c.setAttribute('data-exb-act', key + '/' + btns.length + lay); reveal(c, cur); }
    fade(c);
  }

  function scan() {
    css(); vars();
    Array.prototype.forEach.call(d.querySelectorAll(SEL), function (c) { try { apply(c); } catch (e) { /* une barre en erreur ne doit jamais gêner les autres */ } });
  }

  var t = 0;
  function later(ms) { clearTimeout(t); t = setTimeout(scan, ms || 60); }

  function start() {
    scan();
    if (w.MutationObserver) {
      new MutationObserver(function (m) {
        for (var i = 0; i < m.length; i++) if (m[i].addedNodes && m[i].addedNodes.length) { later(60); return; }
      }).observe(d.body || d.documentElement, { childList: true, subtree: true });
    }
    /* certains modules changent seulement la classe de l'onglet (sans redessiner) : on relit après chaque clic */
    d.addEventListener('click', function (e) { later(e.target && e.target.closest && e.target.closest('.exb-onglets') ? 30 : 150); }, true);   /* un clic ailleurs peut afficher un module : on range ses barres aussitôt */
    w.addEventListener('resize', function () { later(120); });
    /* boutons « réduire / position » (délégués : survivent aux redessins des modules) */
    function act(t) {
      var a = t.getAttribute('data-a');
      if (a === 'min') pref.compact = !pref.compact;
      else if (a === 'pos') { var o = ['auto', 'left', 'bottom', 'top']; pref.pos = o[(o.indexOf(pref.pos) + 1) % o.length]; if (pref.pos === 'top') pref.compact = false; }
      else return false;
      savePref(); scan(); return true;
    }
    d.addEventListener('click', function (e) { var t = e.target && e.target.closest && e.target.closest('.exb-ctl>span[data-a]'); if (t && act(t)) { e.preventDefault(); e.stopPropagation(); } }, true);
    d.addEventListener('keydown', function (e) { if (e.key !== 'Enter' && e.key !== ' ') return; var t = e.target && e.target.closest && e.target.closest('.exb-ctl>span[data-a]'); if (t && act(t)) { e.preventDefault(); e.stopPropagation(); } }, true);
    /* une section affichée plus tard (ou un réglage de la barre des modules changé) : on range de nouveau les barres */
    w.addEventListener('storage', function () { pref = readPref(); later(30); });
    setInterval(function () { if (!d.hidden) scan(); }, 1500);
  }

  w.EXBOnglets = { scan: scan, SEL: SEL, pref: function () { return pref; }, set: function (o) { if (o) { if (o.pos) pref.pos = o.pos; if (typeof o.compact === 'boolean') pref.compact = o.compact; savePref(); scan(); } } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
