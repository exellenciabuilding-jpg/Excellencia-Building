/* Excellencia Building — CORE v1 · écran « Journal d'audit » (V166b)
 * Affiche le journal d'audit commun du noyau (exb-core.js) : vérification de la chaîne d'empreintes, filtres, export CSV.
 * Bouton « 📜 Journal d'audit » ajouté à côté de « 🛡 Sécurité & sauvegardes ». Lecture seule : rien n'est modifié.
 * Le journal est local à CET appareil (500 dernières entrées). Pour retirer : supprimer la balise <script src="exb-core-audit-ui.js">. */
(function (w, d) {
  'use strict';
  if (w.EXBAuditUI) return;
  var DOM = { devis: 'Devis / facture / reçu', finance: 'Finance projet', caisse: 'Caisse', paiement: 'Paiement', facture_fournisseur: 'Facture fournisseur', projet: 'Projet', projet_btp: 'Projet BTP', document_chantier: 'Document de chantier', core: 'Noyau', audit: 'Audit', droits: 'Droits d’action', export: 'Export', continuite: 'Continuité' };
  var VERB = { cree: 'créé', modifie: 'modifié', statut: 'changement de statut', supprime: 'supprimé', lot: 'lot de modifications', demarrage: 'démarrage', refus: 'refusé', fichier: 'fichier exporté', test: 'test de restauration', controle: 'contrôle d’intégrité', reference: 'état de référence', objectifs: 'objectifs modifiés', alerte: 'alerte' };
  var PAGE = 100, shown = PAGE, chainState = null;
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function admin() { try { return w.EXBSEC && w.EXBSEC._canRestore ? !!w.EXBSEC._canRestore() : true; } catch (e) { return true; } }
  function parts(a) { var p = String(a || '').split('.'); return { dom: p[0] || '', verb: p[1] || '' }; }
  function label(a) { var p = parts(a); return (DOM[p.dom] || p.dom) + ' — ' + (VERB[p.verb] || p.verb); }
  function detail(e) {
    var o = null; try { o = JSON.parse(e.d); } catch (x) {}
    if (!o || typeof o !== 'object') return e.d || '';
    if (o.cree != null || o.supprime != null) return (o.cree || 0) + ' créées, ' + (o.modifie || 0) + ' modifiées, ' + (o.statut || 0) + ' statuts, ' + (o.supprime || 0) + ' supprimées';
    var t = [];
    if (o.type) t.push(o.type); if (o.ref) t.push(o.ref);
    if (o.montant != null) t.push(o.montant + (o.devise ? ' ' + o.devise : ''));
    if (o.changement) t.push(o.changement.de + ' → ' + o.changement.vers); else if (o.statut) t.push(o.statut);
    return t.join(' · ');
  }
  function when(t) { return String(t || '').slice(0, 19).replace('T', ' '); }
  function rows() {
    var q = ((d.getElementById('exbAuQ') || {}).value || '').toLowerCase(), f = (d.getElementById('exbAuD') || {}).value || '';
    return EXBCore.audit.list().slice().reverse().filter(function (e) {
      if (f && parts(e.action).dom !== f) return false;
      if (!q) return true;
      return (label(e.action) + ' ' + e.obj + ' ' + detail(e) + ' ' + e.user + ' ' + when(e.t)).toLowerCase().indexOf(q) >= 0;
    });
  }
  function state() {
    if (!chainState) return '<span style="color:#64748b">Chaîne non vérifiée.</span>';
    return chainState.ok ? '<b style="color:#15803d">✅ Chaîne intacte</b> — ' + chainState.entries + ' entrées, aucune modification détectée.'
      : '<b style="color:#b91c1c">⛔ Chaîne rompue</b> — ' + chainState.broken + ' entrée(s) modifiée(s) ou manquante(s), à partir du n° ' + esc(chainState.firstBroken) + '.';
  }
  function paint() {
    var o = d.getElementById('exbAu'); if (!o) return;
    var all = rows(), list = all.slice(0, shown), inp = 'padding:8px;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:8px', bt = 'padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;cursor:pointer';
    var keepQ = (d.getElementById('exbAuQ') || {}).value || '', keepD = (d.getElementById('exbAuD') || {}).value || '';
    var opts = '<option value="">Tous les domaines</option>' + Object.keys(DOM).map(function (k) { return '<option value="' + k + '"' + (k === keepD ? ' selected' : '') + '>' + esc(DOM[k]) + '</option>'; }).join('');
    var tr = list.map(function (e) {
      return '<tr><td style="white-space:nowrap">' + esc(when(e.t)) + '</td><td>' + esc(e.user) + '</td><td>' + esc(label(e.action)) + '</td><td style="word-break:break-all">' + esc(e.obj) + '</td><td>' + esc(detail(e)) + '</td></tr>';
    }).join('');
    o.firstChild.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">📜 Journal d’audit</b><button onclick="document.getElementById(\'exbAu\').remove()" style="' + bt + '">✕</button></div>'
      + '<p style="font-size:12px;color:#64748b;margin:6px 0">Qui a créé, modifié ou supprimé quoi, sur cet appareil (500 dernières actions). Chaque ligne est liée à la précédente par une empreinte : une ligne falsifiée casse la chaîne. Les textes libres ne sont pas conservés.</p>'
      + '<div style="margin:8px 0;padding:8px;border-radius:8px;background:#f1f5f9">' + state() + ' <button onclick="EXBAuditUI.verify()" style="' + bt + ';margin-left:6px">Vérifier</button></div>'
      + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><input id="exbAuQ" value="' + esc(keepQ) + '" placeholder="Rechercher (n°, montant, statut…)" oninput="EXBAuditUI.refresh()" style="' + inp + ';flex:1 1 200px"><select id="exbAuD" onchange="EXBAuditUI.refresh()" style="' + inp + '">' + opts + '</select><button onclick="EXBAuditUI.csv()" style="' + bt + '">⬇ Export CSV</button><button onclick="EXBAuditUI.pdf()" style="' + bt + '">📄 PDF</button></div>'
      + '<div style="overflow:auto;max-height:55vh"><table style="border-collapse:collapse;font-size:12px;width:100%"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:5px">Date et heure</th><th style="padding:5px">Utilisateur</th><th style="padding:5px">Action</th><th style="padding:5px">Fiche</th><th style="padding:5px">Détail</th></tr></thead><tbody>'
      + (tr || '<tr><td colspan="5" style="padding:14px;color:#64748b">Aucune action enregistrée pour ce filtre.</td></tr>') + '</tbody></table></div>'
      + '<p style="font-size:12px;color:#64748b;margin:8px 0 0">' + list.length + ' affichée(s) sur ' + all.length + (all.length > list.length ? ' <button onclick="EXBAuditUI.more()" style="' + bt + ';margin-left:6px">Afficher plus</button>' : '') + '</p>';
    var q = d.getElementById('exbAuQ'); if (q && keepQ) { try { q.focus(); q.setSelectionRange(keepQ.length, keepQ.length); } catch (e) {} }
  }
  function open() {
    if (!w.EXBCore) { try { w.alert('Le noyau n’est pas chargé.'); } catch (e) {} return; }
    if (!admin()) { try { w.alert('Le journal d’audit est réservé à l’administrateur.'); } catch (e) {} return; }
    var o = d.getElementById('exbAu'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbAu'; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;padding:16px;max-width:900px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    shown = PAGE; chainState = null; paint(); verify();
  }
  function verify() { return EXBCore.audit.verify().then(function (r) { chainState = r; paint(); return r; }); }
  function csv() {
    var h = ['n', 'date_heure', 'utilisateur', 'action', 'fiche', 'detail', 'empreinte'], cell = function (v) { v = String(v == null ? '' : v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
    var lines = [h.join(';')].concat(rows().reverse().map(function (e) { return [e.n, e.t, e.user, label(e.action), e.obj, detail(e), e.h].map(cell).join(';'); }));
    var blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 'JOURNAL-AUDIT-EXB-' + new Date().toISOString().slice(0, 10) + '.csv'; d.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  function pdf() {
    if (!w.EXBPdf) { try { w.alert('Module PDF indisponible.'); } catch (e) {} return; }
    var all = rows(), list = all.slice(0, 150);
    return EXBCore.audit.verify().then(function (ch) {
      var last = EXBCore.audit.list().slice(-1)[0], dom = (d.getElementById('exbAuD') || {}).value || '', q = (d.getElementById('exbAuQ') || {}).value || '';
      var r = [['Chaîne d’empreintes', ch.ok ? 'INTACTE — ' + ch.entries + ' lignes, aucune modification détectée' : 'ROMPUE — ' + ch.broken + ' ligne(s) touchée(s), à partir du n° ' + ch.firstBroken],
        ['Dernière empreinte (SHA-256)', last ? last.h : '—'], ['Filtre', (dom ? DOM[dom] || dom : 'tous les domaines') + (q ? ' · recherche « ' + q + ' »' : '')], ['Lignes de ce rapport', list.length + ' sur ' + all.length]];
      list.forEach(function (e) { r.push(['n° ' + e.n + ' · ' + when(e.t) + ' · ' + e.user, label(e.action) + ' — ' + e.obj + (detail(e) ? ' — ' + detail(e) : '')]); });
      return EXBPdf.make({ titre: 'JOURNAL D’AUDIT', sousTitre: 'Édité le ' + new Date().toLocaleDateString('fr-FR') + ' à ' + new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) + ' · journal de cet appareil',
        rows: r, notes: ['Chaque ligne est liée à la précédente par une empreinte SHA-256 : une ligne falsifiée casse la chaîne. Ce journal est propre à l’appareil et limité aux 500 dernières actions. Les textes libres ne sont pas conservés.'], footer: 'Journal d’audit — Excellencia Building' })
        .then(function (b) { EXBPdf.save(b, 'JOURNAL-AUDIT-EXB-' + new Date().toISOString().slice(0, 10) + '.pdf'); });
    });
  }
  function ui() {
    var b = d.getElementById('exbSecBtn'); if (!b || d.getElementById('exbAuBtn')) return;
    var k = d.createElement('button'); k.id = 'exbAuBtn'; k.className = b.className; k.textContent = '📜 Journal d’audit'; k.onclick = open; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  w.EXBAuditUI = { open: open, verify: verify, csv: csv, pdf: pdf, refresh: function () { shown = PAGE; paint(); }, more: function () { shown += PAGE; paint(); } };
})(window, document);
