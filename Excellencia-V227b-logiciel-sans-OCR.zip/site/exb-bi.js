/* v7 : + « Historique des soldes » (instantané mensuel des soldes à ce jour : créances, échues, dettes, engagements + compteurs RH/Stock/Workflow ;
 *      clé exb_bi_histo, 36 mois, un instantané par mois mis à jour à chaque ouverture ; l'historique COMMENCE à la première ouverture, rien n'est reconstitué)
 *      et section « Activité des modules » + historique dans le Rapport de direction PDF.
 * v6 : + « Activité des modules » (RH, Stock, CRM, Workflow : compteurs agrégés, lecture seule, sans donnée nominative) et tableau de bord PERSONNALISABLE
 *      (masquer/afficher chaque indicateur et chaque section ; préférence enregistrée dans exb_bi_prefs, par appareil).
 * v3 : + « Dettes fournisseurs » et « Engagements » (bons de commande exb_purchase_orders), lecture seule, par devise.
 * v5 : + « Tout en dollars » (conversion optionnelle au taux Finances), « Rapport de direction » PDF, rappel périodique (hebdo/mensuel), badge d'alertes.
 * v2 : + « Projets : budget, avancement, écarts » (consolidation du moteur EVM exb-evm.js, en USD, à ce jour) et « Alertes de direction »
 *      (finance + projets). Toujours lecture seule. Les écritures de caisse en FC ne sont PAS converties : elles sont comptées à part et signalées.
 * Excellencia Building — BUSINESS INTELLIGENCE v1 (cahier des charges ERP, module 01 · priorité de développement).
 * Tableau de bord de direction, LECTURE SEULE : aucune donnée n'est modifiée, aucune nouvelle clé de stockage (hors préférences d'affichage).
 * Sources : exb_invoices (factures + paiements), exb_cash (caisse), exb_v93_payments (via le registre EXBLIEN.ledger), exb_projects, exb_quotes.
 * Règles : montants SÉPARÉS PAR DEVISE (USD / CDF), aucune conversion implicite ; factures annulées exclues ;
 *   « Encaissé » = registre unique des encaissements (sans doublon facture/caisse/paiements V93) ; « Dépenses » = sorties de caisse.
 * Chaque indicateur est cliquable : on voit les opérations sources. Export CSV (Excel) et impression PDF. Dictionnaire des KPI intégré.
 * Pour retirer : supprimer la balise <script src="exb-bi.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (!d || w.EXBBI) return;
  var $ = function (i) { return d.getElementById(i); };
  var PK = 'exb_bi_prefs', P = { per: 'annee', pid: '', dept: '', conv: 0, rap: 'off', lastRap: '', lastAlert: '', hide: [], cfg: 0, auto: 1 };
  var FORCE = null; /* V173 : période élargie automatiquement quand la période choisie ne contient aucune donnée */
  try { Object.assign(P, JSON.parse(w.localStorage.getItem(PK) || '{}')); } catch (e) {}
  function savePrefs() { try { w.localStorage.setItem(PK, JSON.stringify(P)); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(x) { x = +x; return isFinite(x) ? x : 0; }
  function rd(k) { try { var s = w.exbStorage ? w.exbStorage.getItem(k) : w.localStorage.getItem(k); var v = JSON.parse(s || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function cur(c) { c = String(c || 'USD').toUpperCase(); return /^(FC|CDF)$/.test(c) ? 'CDF' : c; }
  function fmt(n, c) { try { return new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n) + ' ' + (c === 'CDF' ? 'FC' : c === 'USD' ? '$' : c); } catch (e) { return String(n); } }
  function iso(t) { return String(t || '').slice(0, 10); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function invTot(i) { var ht = (i.lines || []).reduce(function (a, l) { return a + num(l.q) * num(l.pu); }, 0); return Math.round(ht * (1 + num(i.tva) / 100) * 100) / 100; }
  function cancelled(i) { return !!(i.annule || /annul/i.test(i.status || '')); }
  function can() { try { return !w.EXBCore || w.EXBCore.can('exb_invoices', 'lire') !== false; } catch (e) { return true; } }

  /* ---------- période ---------- */
  function range() {
    var per = FORCE || P.per, n = new Date(), y = n.getFullYear(), m = n.getMonth(), a, b = today(), lab;
    function ymd(dt) { return dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2) + '-' + ('0' + dt.getDate()).slice(-2); }
    if (per === 'mois') { a = ymd(new Date(y, m, 1)); lab = 'Ce mois'; }
    else if (per === 'trimestre') { a = ymd(new Date(y, Math.floor(m / 3) * 3, 1)); lab = 'Ce trimestre'; }
    else if (per === '12m') { a = ymd(new Date(y, m - 11, 1)); lab = '12 derniers mois'; }
    else if (per === 'tout') { a = '0000-00-00'; lab = 'Depuis le début'; }
    else { a = y + '-01-01'; lab = 'Cette année'; }
    return { a: a, b: b, lab: lab };
  }
  function inR(dt, r) { dt = iso(dt); return !!dt && dt >= r.a && dt <= r.b; }

  /* v3 : département = champ « dept » du projet ; un filtre actif ne retient que les opérations rattachées à un projet de ce département */
  function deptOf(p) { return String((p && p.dept) || '').trim(); }
  function deptIds(projects, dept) { if (!dept) return null; var m = {}; (projects || []).forEach(function (p) { if (p && deptOf(p).toLowerCase() === String(dept).toLowerCase()) m[String(p.id)] = 1; }); return m; }
  function deptList(projects) { var m = {}; (projects || []).forEach(function (p) { var d = deptOf(p); if (d) m[d.toLowerCase()] = m[d.toLowerCase()] || d; }); return Object.keys(m).map(function (k) { return m[k]; }).sort(); }

  /* ---------- calcul des indicateurs (fonction pure : testable) ---------- */
  function compute(src, opt) {
    src = src || {}; opt = opt || {};
    var r = opt.range || range(), pid = opt.pid || '', t = opt.today || today();
    var ids = deptIds(src.projects, opt.dept);
    function okP(x) { return (!pid || x.project_id === pid) && (!ids || !!ids[String(x.project_id)]); }
    var inv = (src.invoices || []).filter(function (i) { return !cancelled(i) && okP(i); });
    var rows = (src.ledger || []).filter(okP);
    var out = (src.cash || []).filter(function (x) { return x && x.type === 'out' && okP(x); });
    var K = {}, src_ = {};
    function B(c) { return K[c] || (K[c] = { facture: 0, encaisse: 0, depenses: 0, resultat: 0, creances: 0, echu: 0, nbImpayees: 0, nbEchues: 0, dettes: 0, engages: 0, nbDettes: 0 }); }
    function S(c, k) { var kk = c + '|' + k; return src_[kk] || (src_[kk] = []); }
    inv.forEach(function (i) {
      var c = cur(i.currency), tot = invTot(i), paid = (i.payments || []).reduce(function (a, p) { return a + num(p.amount); }, 0), solde = Math.max(0, Math.round((tot - paid) * 100) / 100), b = B(c);
      if (inR(i.date, r)) { b.facture += tot; S(c, 'facture').push({ date: iso(i.date), ref: i.no || i.id, lib: i.client || '', montant: tot }); }
      if (solde > 0.004) { b.creances += solde; b.nbImpayees++; S(c, 'creances').push({ date: iso(i.date), ref: i.no || i.id, lib: (i.client || '') + (i.due ? ' · échéance ' + iso(i.due) : ''), montant: solde });
        if (i.due && iso(i.due) < t) { b.echu += solde; b.nbEchues++; S(c, 'echu').push({ date: iso(i.due), ref: i.no || i.id, lib: i.client || '', montant: solde }); } }
    });
    /* v3 : dettes fournisseurs = valeur REÇUE non payée ; engagements = commandé non encore reçu (bons de commande non annulés) */
    (src.po || []).forEach(function (o) {
      if (!o || o.cancel || (pid && String(o.project_id) !== String(pid)) || (ids && !ids[String(o.project_id)])) return;
      var c = cur(o.currency), b = B(c), tot = 0, rec = 0;
      (o.lines || []).forEach(function (l) { tot += num(l.q) * num(l.pu); rec += Math.min(num(l.rec), num(l.q)) * num(l.pu); });
      var paid = (o.payments || []).reduce(function (a, x) { return a + num(x.amount); }, 0), ref = o.no || o.id, lib = o.supplier_name || o.supplier || o.supplier_id || '';
      var dette = Math.max(0, Math.round((rec - paid) * 100) / 100), eng = Math.max(0, Math.round((tot - Math.max(rec, paid)) * 100) / 100);
      if (dette > 0.004) { b.dettes += dette; b.nbDettes++; S(c, 'dettes').push({ date: iso(o.date), ref: ref, lib: lib, montant: dette }); }
      if (eng > 0.004) { b.engages += eng; S(c, 'engages').push({ date: iso(o.date), ref: ref, lib: lib, montant: eng }); }
    });
    rows.forEach(function (x) { if (!inR(x.date, r)) return; var c = cur(x.currency), b = B(c); b.encaisse += num(x.amount); S(c, 'encaisse').push({ date: iso(x.date), ref: x.invoice_id || x.id, lib: x.source || '', montant: num(x.amount) }); });
    out.forEach(function (x) { if (!inR(x.date, r)) return; var c = cur(x.currency), a = num(x.amount); if (!a) return; B(c).depenses += a; S(c, 'depenses').push({ date: iso(x.date), ref: x.id, lib: x.label || '', montant: a }); });
    Object.keys(K).forEach(function (c) { var b = K[c]; ['facture', 'encaisse', 'depenses', 'creances', 'echu', 'dettes', 'engages'].forEach(function (k) { b[k] = Math.round(b[k] * 100) / 100; }); b.resultat = Math.round((b.encaisse - b.depenses) * 100) / 100; });
    /* tendance : 12 derniers mois */
    var mois = [], n = new Date(t + 'T00:00:00'), i;
    for (i = 11; i >= 0; i--) { var dt = new Date(n.getFullYear(), n.getMonth() - i, 1); mois.push(dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2)); }
    var T = {};
    function TB(c) { return T[c] || (T[c] = mois.map(function (m) { return { m: m, enc: 0, dep: 0 }; })); }
    rows.forEach(function (x) { var k = mois.indexOf(iso(x.date).slice(0, 7)); if (k >= 0) TB(cur(x.currency))[k].enc += num(x.amount); });
    out.forEach(function (x) { var k = mois.indexOf(iso(x.date).slice(0, 7)); if (k >= 0) TB(cur(x.currency))[k].dep += num(x.amount); });
    /* rapprochement : somme des soldes de factures = facturé cumulé − encaissé sur factures */
    var rap = {}; inv.forEach(function (i) { var c = cur(i.currency), tot = invTot(i), paid = (i.payments || []).reduce(function (a, p) { return a + num(p.amount); }, 0); var o = rap[c] || (rap[c] = { tot: 0, paid: 0, solde: 0 }); o.tot += tot; o.paid += paid; o.solde += Math.max(0, tot - paid); });
    var okRap = Object.keys(rap).every(function (c) { var o = rap[c]; return o.solde >= -0.01 && o.solde <= o.tot + 0.01; });
    return { range: r, kpi: K, sources: src_, tendance: T, mois: mois, rapprochement: { ok: okRap, devises: rap }, nbFactures: inv.length };
  }

  function lastRate() { var t = rd('exb_finance').filter(function (x) { return x && x.type === 'taux' && num(x.rate) > 0; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; }); return t.length ? num(t[t.length - 1].rate) : 0; }
  /* conversion OPTIONNELLE FC -> USD au dernier taux enregistré (Finances) : copie des données, jamais d'écriture */
  function convertSrc(src, rate) {
    if (!(rate > 0)) return src;
    function A(c, a) { return cur(c) === 'CDF' ? num(a) / rate : num(a); }
    function pays(c, l) { return (l || []).map(function (p) { return Object.assign({}, p, { amount: A(c, p.amount) }); }); }
    var o = Object.assign({}, src);
    o.invoices = (src.invoices || []).map(function (i) { var c = i.currency; return Object.assign({}, i, { currency: 'USD', lines: (i.lines || []).map(function (l) { return Object.assign({}, l, { pu: A(c, l.pu) }); }), payments: pays(c, i.payments) }); });
    o.cash = (src.cash || []).map(function (x) { return Object.assign({}, x, { currency: 'USD', amount: A(x.currency, x.amount) }); });
    o.ledger = (src.ledger || []).map(function (x) { return Object.assign({}, x, { currency: 'USD', amount: A(x.currency, x.amount) }); });
    o.po = (src.po || []).map(function (q) { var c = q.currency; return Object.assign({}, q, { currency: 'USD', lines: (q.lines || []).map(function (l) { return Object.assign({}, l, { pu: A(c, l.pu) }); }), payments: pays(c, q.payments) }); });
    return o;
  }
  function gather() {
    var L = w.EXBLIEN, led = [], susp = 0;
    try { if (L && L.ledger) { var g = L.ledger(); led = g.rows || []; susp = (g.suspects || []).length; } } catch (e) {}
    try { /* paiements des apprenants (formations) : ajoutés à l'encaissé, sans doublon */
      var seen = {}; led.forEach(function (x) { if (x && x.id) seen[String(x.id)] = 1; });
      led = led.concat(rd('exb_payments').filter(function (p) { return p && p.date && num(p.amount) > 0 && !seen[String(p.payment_id || p.id || '')]; }).map(function (p) {
        return { id: p.payment_id || p.id || p.reference || '', date: p.date, amount: num(p.amount), currency: p.currency || p.cur || 'USD', source: 'Formation · ' + (p.participant_name || p.participant || '') };
      }));
    } catch (e) {}
    return { invoices: rd('exb_invoices'), cash: rd('exb_cash'), ledger: led, suspects: susp, po: rd('exb_purchase_orders'), hr: rd('exb_hr'), stock: rd('exb_stock'), clients: rd('exb_clients'), wf: rdS('exb_wf_dossiers'), projects: rd('exb_projects'), quotes: rd('exb_quotes'),
      gantt: rdS('exb_gantt'), budgets: rdS('exb_budgets'), th: rdS('exb_pilot_th'), rate: lastRate() };
  }
  /* même source que « Pilotage projets » (EXBS), repli sur le stockage commun */
  function rdS(k) { try { if (w.EXBS && w.EXBS.get) { var a = w.EXBS.get(k); if (Array.isArray(a)) return a; } } catch (e) {} return rd(k); }

  /* ---------- v6 : activité des autres modules — compteurs agrégés (fonction pure : testable) ----------
   * RH : seules les fiches approuvées comptent (comme l'écran Personnel) ; rejetées ignorées ; le reste = « en attente ». Aucun nom, aucun salaire.
   * Stock : « à commander » = quantité ≤ seuil (même règle que l'écran Stock) ; rupture = quantité ≤ 0.
   * CRM : devis émis sur la période, montants par devise (jamais convertis). Workflow : dossiers en cours / en retard (échéance dépassée) / décisions des 30 derniers jours. */
  function addDaysIso(t, n) { var x = new Date(String(t) + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); }
  function operationnel(src, opt) {
    opt = opt || {}; var t = opt.today || today(), r = opt.range || { a: '0000-00-00', b: '9999-12-31' }, ok = opt.ok || {}, o = {};
    if (ok.hr !== false) {
      var hr = { actifs: 0, conge: 0, suspendus: 0, sortis: 0, enAttente: 0 };
      (src.hr || []).forEach(function (x) {
        if (!x || x.approval_status === 'REJETE') return;
        if (!(x.approval_status === 'APPROUVE' || (!x.approval_status && x.matricule))) { hr.enAttente++; return; }
        var st = String(x.status || 'Actif'); if (/^cong/i.test(st)) hr.conge++; else if (/^suspend/i.test(st)) hr.suspendus++; else if (/^sorti/i.test(st)) hr.sortis++; else hr.actifs++;
      });
      o.rh = hr;
    }
    if (ok.stock !== false) {
      var sk = { articles: 0, aCommander: 0, ruptures: 0 };
      (src.stock || []).forEach(function (x) { if (!x) return; sk.articles++; if (num(x.qty) <= num(x.min)) sk.aCommander++; if (num(x.qty) <= 0) sk.ruptures++; });
      o.stock = sk;
    }
    if (ok.crm !== false) {
      var cr = { clients: (src.clients || []).length, devis: 0, montants: {} };
      (src.quotes || []).forEach(function (q) { if (!q || !inR(q.date, r)) return; cr.devis++; var c = cur(q.currency); cr.montants[c] = Math.round(((cr.montants[c] || 0) + num(q.total)) * 100) / 100; });
      o.crm = cr;
    }
    if (ok.wf !== false) {
      var wf = { enCours: 0, enRetard: 0, retournes: 0, valides30: 0, refuses30: 0 }, since = addDaysIso(t, -30);
      (src.wf || []).forEach(function (x) {
        if (!x) return;
        if (x.status === 'en_cours') { wf.enCours++; if (iso(x.echeance) && iso(x.echeance) < t) wf.enRetard++; }
        else if (x.status === 'retourne') wf.retournes++;
        else if ((x.status === 'valide' || x.status === 'refuse') && iso(x.fin) >= since && iso(x.fin) <= t) { if (x.status === 'valide') wf.valides30++; else wf.refuses30++; }
      });
      o.wf = wf;
    }
    return o;
  }
  /* ---------- v7 : historique des soldes (fonctions pures : testables) ---------- */
  var HK = 'exb_bi_histo';
  function r2(x) { return Math.round(num(x) * 100) / 100; }
  function snapshot(kpi, ops, t) {
    var s = { mois: String(t).slice(0, 7), date: String(t).slice(0, 10), kpi: {}, ops: {} }, any = false;
    Object.keys(kpi || {}).forEach(function (c) { var k = kpi[c] || {}, o = { creances: r2(k.creances), echu: r2(k.echu), dettes: r2(k.dettes), engages: r2(k.engages) }; if (o.creances || o.echu || o.dettes || o.engages) { s.kpi[c] = o; any = true; } });
    ops = ops || {};
    if (ops.rh) { s.ops.rhActifs = ops.rh.actifs; if (ops.rh.actifs) any = true; }
    if (ops.stock) { s.ops.stockCmd = ops.stock.aCommander; s.ops.ruptures = ops.stock.ruptures; if (ops.stock.aCommander || ops.stock.ruptures) any = true; }
    if (ops.wf) { s.ops.wfCours = ops.wf.enCours; s.ops.wfRetard = ops.wf.enRetard; if (ops.wf.enCours || ops.wf.enRetard) any = true; }
    return any ? s : null;
  }
  function histoUpsert(arr, snap, max) {
    arr = Array.isArray(arr) ? arr : []; if (!snap || !snap.mois) return arr;
    var a = arr.filter(function (x) { return x && x.mois && x.mois !== snap.mois; }); a.push(snap);
    a.sort(function (x, y) { return x.mois < y.mois ? -1 : x.mois > y.mois ? 1 : 0; });
    return a.slice(-(max || 36));
  }
  function histoRead() { try { var s = w.exbStorage ? w.exbStorage.getItem(HK) : w.localStorage.getItem(HK), v = JSON.parse(s || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function histoWrite(a) { try { var s = JSON.stringify(a); if (w.exbStorage && w.exbStorage.setItem) w.exbStorage.setItem(HK, s); else w.localStorage.setItem(HK, s); } catch (e) {} }
  /* instantané du mois courant : toujours SANS filtre projet/département et SANS conversion, pour que l'historique reste comparable d'un mois à l'autre */
  function recordHisto() {
    try {
      if (!can() || !SRC) return; var t = today(), c0 = compute(SRC, { range: { a: t.slice(0, 7) + '-01', b: t, lab: '' }, today: t }), snap = snapshot(c0.kpi, OPS, t); if (!snap) return;
      var a = histoRead(), n = histoUpsert(a, snap, 36); if (JSON.stringify(n) !== JSON.stringify(a)) histoWrite(n);
    } catch (e) {}
  }
  function canK(k) { try { return !w.EXBCore || !w.EXBCore.can || w.EXBCore.can(k, 'lire') !== false; } catch (e) { return true; } }
  function opsOf(src) { return operationnel(src, { range: range(), today: today(), ok: { hr: canK('exb_hr'), stock: canK('exb_stock'), crm: canK('exb_quotes'), wf: canK('exb_wf_dossiers') } }); }
  function hiddenHas(id) { return (P.hide || []).indexOf(id) >= 0; }

  /* ---------- v4 : engagements budgétaires d'un projet (bons de commande non annulés, USD) — fonction pure : testable ----------
   * commande = total commandé ; recu = valeur reçue ; paye = paiements ; reste = commandé − reçu ; taux = commandé ÷ budget ; disponible = budget − commandé.
   * Volontairement SÉPARÉ du « coût réel » (les paiements fournisseurs peuvent déjà figurer en caisse : aucun cumul pour éviter le double comptage). */
  function engagements(po, pid, bac) {
    var r = { commande: 0, recu: 0, paye: 0, reste: 0, nb: 0, horsUsd: 0, taux: null, disponible: null, depasse: false };
    (po || []).forEach(function (o) {
      if (!o || o.cancel || String(o.project_id) !== String(pid)) return;
      if (cur(o.currency) !== 'USD') { r.horsUsd++; return; }
      var tot = 0, rec = 0; (o.lines || []).forEach(function (l) { tot += num(l.q) * num(l.pu); rec += Math.min(num(l.rec), num(l.q)) * num(l.pu); });
      r.commande += tot; r.recu += rec; r.paye += (o.payments || []).reduce(function (a, x) { return a + num(x.amount); }, 0); r.nb++;
    });
    ['commande', 'recu', 'paye'].forEach(function (k) { r[k] = Math.round(r[k] * 100) / 100; });
    r.reste = Math.round((r.commande - r.recu) * 100) / 100;
    if (bac > 0) { r.taux = Math.round(r.commande / bac * 1000) / 10; r.disponible = Math.round((bac - r.commande) * 100) / 100; r.depasse = r.commande > bac + 0.004; }
    return r;
  }

  /* ---------- v2 : projets (budget, avancement, écarts) — fonction pure : testable ---------- */
  function lateUsd(src, pid) {
    var t = today(), s = 0;
    (src.invoices || []).forEach(function (i) {
      if (cancelled(i) || cur(i.currency) !== 'USD' || String(i.project_id) !== String(pid)) return;
      var solde = invTot(i) - (i.payments || []).reduce(function (a, p) { return a + num(p.amount); }, 0);
      if (solde > 0.004 && i.due && iso(i.due) < (src.today || t)) s += solde;
    });
    return Math.round(s * 100) / 100;
  }
  function computeProjets(src, opt) {
    src = src || {}; opt = opt || {};
    var E = opt.evm || w.EXBEVM, t = opt.today || today(), pid = opt.pid || '';
    if (!E || !E.analyseProject) return { dispo: false, rows: [], tot: null, horsUsd: 0 };
    var Gs = src.gantt || [], Bs = src.budgets || [], C = src.cash || [], CF = src.th || [], horsUsd = 0;
    var dids = deptIds(src.projects, opt.dept);
    var rows = (src.projects || []).filter(function (p) { return p && (!pid || String(p.id) === String(pid)) && (!dids || !!dids[String(p.id)]); }).map(function (p) {
      var g = Gs.filter(function (x) { return String(x.project_id) === String(p.id); })[0], b = Bs.filter(function (x) { return String(x.project_id) === String(p.id); })[0];
      var rc = C.filter(function (c) { return c && String(c.project_id) === String(p.id); });
      var usd = rc.filter(function (c) { if (cur(c.currency) !== 'USD') { if (c.type === 'out') horsUsd++; return false; } return true; });
      var cash = usd.reduce(function (a, c) { return c.type === 'out' ? a + num(c.amount) : a; }, 0);
      var a = E.analyseProject(p, g, b, cash, t, lateUsd({ invoices: src.invoices, today: t }, p.id), E.thFor(CF, p.id), usd);
      a.id = p.id; a.name = p.name || p.nom || p.id; a.client = p.client || ''; a.dept = deptOf(p); a.eng = engagements(src.po, p.id, a.bac);
      var CP = opt.cpm || w.EXBCPM; a.jalons = (CP && CP.jalons && g && g.jalons && g.jalons.length) ? CP.jalons(g.tasks || [], g.jalons, CP.semaine ? CP.semaine(g.date, t) : 0) : [];
      return a;
    });
    var open = rows.filter(function (a) { return !a.closed; });
    return { dispo: true, rows: E.tri ? E.tri(rows) : rows, tot: E.consolidate ? E.consolidate(open) : null, horsUsd: horsUsd };
  }

  /* ---------- v2 : alertes de direction (finance + projets) ---------- */
  function alertes(r, pj, ctx) {
    var A = []; ctx = ctx || {};
    Object.keys(r.kpi).forEach(function (c) {
      var k = r.kpi[c];
      if (k.resultat < 0) A.push({ sev: 'high', src: 'Finance', msg: 'Résultat de trésorerie négatif en ' + c + ' : ' + fmt(k.resultat, c) + ' sur la période.' });
      if (k.echu > 0) A.push({ sev: (k.creances > 0 && k.echu / k.creances >= 0.5) ? 'high' : 'medium', src: 'Finance', msg: fmt(k.echu, c) + ' de créances échues (' + k.nbEchues + ' facture(s)) sur ' + fmt(k.creances, c) + ' dus.' });
      if (k.dettes > 0 && k.dettes > k.encaisse) A.push({ sev: 'medium', src: 'Finance', msg: 'Dettes fournisseurs ' + fmt(k.dettes, c) + ' (' + k.nbDettes + ' bon(s) de commande reçus non soldés), supérieures aux encaissements de la période.' });
    });
    if (r.rapprochement && !r.rapprochement.ok) A.push({ sev: 'high', src: 'Finance', msg: 'Incohérence entre factures et paiements : vérifier les données sources.' });
    if (ctx.suspects) A.push({ sev: 'medium', src: 'Finance', msg: ctx.suspects + ' encaissement(s) possiblement en double (voir Finances).' });
    if (pj && pj.dispo) pj.rows.filter(function (a) { return !a.closed && (a.status === 'rouge' || a.status === 'orange'); }).forEach(function (a) {
      var top = (a.alerts || []).concat(a.anomalies || []).filter(function (x) { return x.sev !== 'low'; });
      A.push({ sev: a.status === 'rouge' ? 'high' : 'medium', src: 'Projet', pid: a.id, msg: a.name + ' — ' + (top[0] ? top[0].msg : 'à surveiller') + (top.length > 1 ? ' (+' + (top.length - 1) + ' autre(s))' : '') });
    });
    if (pj && pj.dispo) pj.rows.filter(function (a) { return !a.closed; }).forEach(function (a) {
      var rt = (a.jalons || []).filter(function (j) { return j.statut === 'en_retard'; }), mn = (a.jalons || []).filter(function (j) { return j.statut === 'menace'; });
      if (rt.length) A.push({ sev: 'high', src: 'Jalon', pid: a.id, msg: a.name + ' — jalon en retard : « ' + (rt[0].name || 'sans nom') + ' » (S' + rt[0].semaine_prevue + ')' + (rt.length > 1 ? ' (+' + (rt.length - 1) + ' autre(s))' : '') });
      else if (mn.length) A.push({ sev: 'medium', src: 'Jalon', pid: a.id, msg: a.name + ' — jalon menacé : « ' + (mn[0].name || 'sans nom') + ' » prévu S' + mn[0].semaine_prevue + ', prévision S' + mn[0].semaine_fin_prevue + (mn.length > 1 ? ' (+' + (mn.length - 1) + ' autre(s))' : '') });
    });
    if (pj && pj.dispo) pj.rows.filter(function (a) { return !a.closed && a.eng && a.eng.nb; }).forEach(function (a) {
      if (a.eng.depasse) A.push({ sev: 'high', src: 'Engagements', pid: a.id, msg: a.name + ' — commandes ' + fmt(a.eng.commande, 'USD') + ' supérieures au budget ' + fmt(a.bac, 'USD') + ' (' + a.eng.taux + ' %).' });
      else if (a.eng.taux != null && a.eng.taux >= 90) A.push({ sev: 'medium', src: 'Engagements', pid: a.id, msg: a.name + ' — ' + a.eng.taux + ' % du budget déjà engagé (reste ' + fmt(a.eng.disponible, 'USD') + ').' });
    });
    var o = ctx.ops || {};
    if (o.stock && o.stock.ruptures > 0) A.push({ sev: 'medium', src: 'Stock', msg: o.stock.ruptures + ' article(s) en rupture de stock' + (o.stock.aCommander > o.stock.ruptures ? ' (' + o.stock.aCommander + ' à commander au total).' : '.') });
    if (o.wf && o.wf.enRetard > 0) A.push({ sev: 'medium', src: 'Workflow', msg: o.wf.enRetard + ' dossier(s) de validation en retard (échéance dépassée) sur ' + o.wf.enCours + ' en cours.' });
    var rk = { high: 0, medium: 1, low: 2 };
    return A.sort(function (a, b) { return rk[a.sev] - rk[b.sev]; });
  }

  /* ---------- affichage ---------- */
  var LAST = null, SRC = null, PJ = null, AL = [], OPS = {};
  var COLS = { rouge: '#b91c1c', orange: '#d97706', vert: '#15803d', gris: '#6b7280' }, LABS = { rouge: 'À traiter', orange: 'À surveiller', vert: 'Sous contrôle', gris: 'Données insuffisantes' }, DOTS = { rouge: '🔴', orange: '🟠', vert: '🟢', gris: '⚪' };
  function idx(v) { return v == null ? '—' : Number(v).toFixed(2).replace('.', ','); }
  function pct(v) { return v == null ? '—' : Math.round(v) + ' %'; }
  function opsHtml() {
    var o = OPS || {}, t = [];
    function tile(titre, val, sub, bad) { return '<div style="text-align:left;border:1px solid #d7deea;border-radius:10px;background:#fff;padding:10px"><small style="color:#5e6877">' + esc(titre) + '</small><div style="font-size:1.15em;font-weight:700;color:' + (bad ? '#c0392b' : '#12305e') + '">' + esc(val) + '</div><small class="exb-muted">' + esc(sub) + '</small></div>'; }
    if (o.rh) t.push(tile('RH — effectif actif', o.rh.actifs, o.rh.conge + ' en congé · ' + o.rh.suspendus + ' suspendu(s) · ' + o.rh.enAttente + ' fiche(s) à approuver'));
    if (o.stock) t.push(tile('Stock — articles à commander', o.stock.aCommander, 'sur ' + o.stock.articles + ' article(s) · ' + o.stock.ruptures + ' en rupture', o.stock.ruptures > 0));
    if (o.crm) t.push(tile('CRM — devis de la période', o.crm.devis, o.crm.clients + ' client(s)' + Object.keys(o.crm.montants).map(function (c) { return ' · ' + fmt(o.crm.montants[c], c); }).join('')));
    if (o.wf) t.push(tile('Workflow — dossiers en cours', o.wf.enCours, o.wf.enRetard + ' en retard · ' + o.wf.retournes + ' retourné(s) · 30 j : ' + o.wf.valides30 + ' validé(s), ' + o.wf.refuses30 + ' refusé(s)', o.wf.enRetard > 0));
    if (!t.length) return '';
    return '<h3 style="margin:14px 0 6px">Activité des modules</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px">' + t.join('') + '</div>';
  }
  function histoCurrencies(rows) { var m = {}; rows.forEach(function (r) { Object.keys(r.kpi || {}).forEach(function (c) { m[c] = 1; }); }); return Object.keys(m).sort(function (a, b) { return a === 'USD' ? -1 : b === 'USD' ? 1 : a < b ? -1 : 1; }); }
  function histoChart(c, rows) {
    var pts = rows.filter(function (r) { return r.kpi && r.kpi[c]; }); if (pts.length < 2) return '';
    var W = 560, H = 120, pad = 24, max = 1; pts.forEach(function (r) { max = Math.max(max, r.kpi[c].creances, r.kpi[c].dettes); });
    function line(key, col) { return '<polyline fill="none" stroke="' + col + '" stroke-width="2" points="' + pts.map(function (r, i) { return (pad + i * (W - 2 * pad) / (pts.length - 1)).toFixed(1) + ',' + (H - 18 - r.kpi[c][key] / max * (H - 36)).toFixed(1); }).join(' ') + '"/>'; }
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;max-width:640px" role="img" aria-label="Créances et dettes par mois">' + line('creances', '#1f5fae') + line('dettes', '#c0392b') +
      '<text x="' + pad + '" y="' + (H - 4) + '" font-size="9" fill="#5e6877">' + esc(pts[0].mois) + '</text><text x="' + (W - pad) + '" y="' + (H - 4) + '" font-size="9" text-anchor="end" fill="#5e6877">' + esc(pts[pts.length - 1].mois) + '</text></svg>';
  }
  function histoHtml(n, forPrint) {
    if (!can()) return ''; var all = histoRead(), rows = all.slice(-(n || 12)); if (!rows.length) return '';
    var h = '<h' + (forPrint ? 2 : 3) + (forPrint ? '' : ' style="margin:14px 0 6px"') + '>Historique des soldes (à ce jour, par mois)</h' + (forPrint ? 2 : 3) + '>', desc = rows.slice().reverse();
    histoCurrencies(rows).forEach(function (c) {
      h += '<p' + (forPrint ? '' : ' class="exb-muted"') + ' style="margin:6px 0 2px"><b>' + esc(c === 'CDF' ? 'FC' : c) + '</b></p><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.92em"><tr style="text-align:left"><th>Mois</th><th style="text-align:right">Créances</th><th style="text-align:right">Dont échues</th><th style="text-align:right">Dettes</th><th style="text-align:right">Engagements</th></tr>' +
        desc.map(function (r) { var k = r.kpi && r.kpi[c]; return '<tr style="border-top:1px solid #e3e9f2"><td>' + esc(r.mois) + '</td>' + (k ? ['creances', 'echu', 'dettes', 'engages'].map(function (f) { return '<td style="text-align:right">' + esc(fmt(k[f], c)) + '</td>'; }).join('') : '<td colspan="4" style="text-align:right">—</td>') + '</tr>'; }).join('') + '</table></div>';
      if (!forPrint) h += histoChart(c, rows);
    });
    var withOps = desc.filter(function (r) { return r.ops && Object.keys(r.ops).length; });
    if (withOps.length) h += '<p' + (forPrint ? '' : ' class="exb-muted"') + ' style="margin:8px 0 2px"><b>Activité</b></p><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.92em"><tr style="text-align:left"><th>Mois</th><th style="text-align:right">RH actifs</th><th style="text-align:right">Stock à commander</th><th style="text-align:right">Ruptures</th><th style="text-align:right">Workflow en cours</th><th style="text-align:right">Workflow en retard</th></tr>' +
      withOps.map(function (r) { function v(x) { return '<td style="text-align:right">' + (x == null ? '—' : esc(x)) + '</td>'; } return '<tr style="border-top:1px solid #e3e9f2"><td>' + esc(r.mois) + '</td>' + v(r.ops.rhActifs) + v(r.ops.stockCmd) + v(r.ops.ruptures) + v(r.ops.wfCours) + v(r.ops.wfRetard) + '</tr>'; }).join('') + '</table></div>';
    return h + '<p class="exb-muted" style="margin:6px 0 0"><small>Un instantané par mois, mis à jour à chaque ouverture du tableau de bord. L’historique commence à la première ouverture : les mois passés ne sont pas reconstitués.</small></p>';
  }
  function opsPrint() {
    var o = OPS || {}, r = [];
    if (o.rh) r.push(['RH', 'Effectif actif', o.rh.actifs], ['RH', 'En congé / suspendus', o.rh.conge + ' / ' + o.rh.suspendus], ['RH', 'Fiches à approuver', o.rh.enAttente]);
    if (o.stock) r.push(['Stock', 'Articles à commander', o.stock.aCommander + ' sur ' + o.stock.articles], ['Stock', 'En rupture', o.stock.ruptures]);
    if (o.crm) { r.push(['CRM', 'Clients', o.crm.clients], ['CRM', 'Devis de la période', o.crm.devis]); Object.keys(o.crm.montants).forEach(function (c) { r.push(['CRM', 'Montant des devis', fmt(o.crm.montants[c], c)]); }); }
    if (o.wf) r.push(['Workflow', 'Dossiers en cours', o.wf.enCours], ['Workflow', 'En retard', o.wf.enRetard], ['Workflow', 'Retournés', o.wf.retournes], ['Workflow', 'Validés / refusés (30 jours)', o.wf.valides30 + ' / ' + o.wf.refuses30]);
    if (!r.length) return '';
    return '<h2>Activité des modules</h2><table>' + r.map(function (x) { return '<tr><td>' + esc(x[0]) + '</td><td>' + esc(x[1]) + '</td><td style="text-align:right">' + esc(x[2]) + '</td></tr>'; }).join('') + '</table>';
  }
  function cfgHtml() {
    if (!P.cfg) return '';
    var items = DEF.map(function (df) { return [df[0], df[1]]; }).concat([['tendance', 'Graphique mensuel'], ['ops', 'Activité des modules'], ['histo', 'Historique des soldes'], ['projets', 'Tableau des projets']]);
    return '<div style="border:1px solid #d7deea;border-radius:10px;padding:8px;margin-bottom:8px;background:#f7f9fc"><b>Indicateurs affichés</b> <small class="exb-muted">(les alertes restent toujours visibles)</small><label style="display:block;margin:6px 0"><input type="checkbox" id="bi_auto" style="width:auto;height:auto;margin-right:4px"' + (P.auto !== 0 ? ' checked' : '') + '><b>Adapter automatiquement aux données</b> <small class="exb-muted">(masque les indicateurs à zéro et les sections vides ; élargit la période si elle est vide)</small></label><div style="display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:6px">' +
      items.map(function (x) { return '<label style="white-space:nowrap"><input type="checkbox" class="bi-show" data-id="' + x[0] + '" style="width:auto;height:auto;margin-right:4px"' + (hiddenHas(x[0]) ? '' : ' checked') + '>' + esc(x[1]) + '</label>'; }).join('') +
      '</div><button type="button" id="bi_cfg_reset" style="margin-top:6px">Tout réafficher</button></div>';
  }
  function alertsHtml() {
    if (!AL.length) return '<div style="border:1px solid #cfe8d8;background:#f2faf5;border-radius:10px;padding:8px 10px;margin-bottom:10px">✅ Aucune alerte de direction : indicateurs financiers et projets sans signal à traiter.</div>';
    return '<div style="border:1px solid #f0d9a8;background:#fffaf0;border-radius:10px;padding:8px 10px;margin-bottom:10px"><b>🔔 Alertes de direction (' + AL.length + ')</b><ul style="margin:6px 0 0;padding-left:18px">' +
      AL.slice(0, 12).map(function (a) { return '<li style="color:' + (a.sev === 'high' ? '#b91c1c' : '#8a5a00') + '"><small>' + (a.sev === 'high' ? 'À traiter' : 'À surveiller') + ' · ' + esc(a.src) + '</small> ' + esc(a.msg) + (a.pid != null ? ' <a href="#" class="bi-pj" data-id="' + esc(a.pid) + '">détail</a>' : '') + '</li>'; }).join('') + '</ul>' + (AL.length > 12 ? '<small class="exb-muted">12 premières alertes sur ' + AL.length + '.</small>' : '') + '</div>';
  }
  /* V205 : cartes de synthèse « Direction de projets » en tête de l'écran (écran seulement : le PDF garde projetsHtml tel quel) */
  function projetsCartes() {
    if (!PJ || !PJ.dispo || !PJ.rows.length || !PJ.tot || !PJ.tot.n) return '';
    var T = PJ.tot;
    function tile(l, v, col, sub) { return '<div style="border:1px solid #d7deea;border-radius:10px;background:#fff;padding:10px"><small style="color:#5e6877">' + esc(l) + '</small><div style="font-size:1.25em;font-weight:700;color:' + (col || '#12305e') + '">' + esc(v) + '</div>' + (sub ? '<small class="exb-muted">' + esc(sub) + '</small>' : '') + '</div>'; }
    var t = [tile('Projets en cours', String(T.actifs), '', 'sur ' + T.n + ' projet(s)'), tile('À traiter', String(T.rouge), T.rouge ? COLS.rouge : COLS.vert), tile('À surveiller', String(T.orange), T.orange ? COLS.orange : COLS.vert), tile('Sous contrôle', String(T.vert), COLS.vert)];
    if (T.bac > 0) t.push(tile('Budget total', fmt(T.bac, 'USD')), tile('Coût réel', fmt(T.ac, 'USD')), tile('Coût final estimé', fmt(T.eac, 'USD')));
    t.push(tile('CPI (coûts)', idx(T.cpi), '', '1 = budget tenu'), tile('SPI (délais)', idx(T.spi), '', '1 = planning tenu'));
    return '<h3 style="margin:14px 0 6px">🏗️ Direction de projets — tableau de bord</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">' + t.join('') + '</div>';
  }
  function projetsHtml() {
    if (!PJ || !PJ.dispo) return '<p class="exb-muted">Le moteur de pilotage projets n’est pas chargé : section indisponible.</p>';
    var h = '<h3 style="margin:16px 0 6px">Projets : budget, avancement et écarts <small class="exb-muted">(USD, à ce jour)</small></h3>';
    if (!PJ.rows.length) return h + '<p class="exb-muted">Aucun projet. Créez un projet, son budget et son planning : les écarts se calculent seuls.</p>';
    var T = PJ.tot;
    if (T && T.n) h += '<p class="exb-muted" style="margin:0 0 6px">Projets en cours : ' + T.actifs + ' · à traiter ' + T.rouge + ' · à surveiller ' + T.orange + ' · sous contrôle ' + T.vert + (T.gris ? ' · sans données ' + T.gris : '') + (T.bac > 0 ? ' — budget ' + fmt(T.bac, 'USD') + ', coût réel ' + fmt(T.ac, 'USD') + ', coût final estimé ' + fmt(T.eac, 'USD') + ' · CPI ' + idx(T.cpi) + ' · SPI ' + idx(T.spi) : '') + '</p>';
    h += '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.92em"><tr style="text-align:left"><th>Projet</th><th>Statut</th><th style="text-align:right">Budget</th><th style="text-align:right">Coût réel</th><th style="text-align:right">Engagé</th><th style="text-align:right">Coût final estimé</th><th style="text-align:right">Écart final</th><th style="text-align:right">Avancement / planifié</th><th style="text-align:right">CPI</th><th style="text-align:right">SPI</th><th style="text-align:right">Retard</th></tr>';
    PJ.rows.slice(0, 150).forEach(function (a) {
      var st = a.closed ? 'Terminé' : (DOTS[a.status] + ' ' + LABS[a.status]);
      h += '<tr class="bi-pj" data-id="' + esc(a.id) + '" style="border-top:1px solid #e3e9f2;cursor:pointer"><td>' + esc(a.name) + '</td><td>' + esc(st) + '</td><td style="text-align:right">' + (a.bac > 0 ? esc(fmt(a.bac, 'USD')) : '—') + '</td><td style="text-align:right">' + (a.ac > 0 ? esc(fmt(a.ac, 'USD')) : '—') + '</td><td style="text-align:right;color:' + (a.eng && a.eng.depasse ? '#b91c1c' : 'inherit') + '">' + (a.eng && a.eng.nb ? esc(fmt(a.eng.commande, 'USD')) + (a.eng.taux != null ? ' <small>(' + a.eng.taux + ' %)</small>' : '') : '—') + '</td><td style="text-align:right">' + (a.eac != null ? esc(fmt(a.eac, 'USD')) : '—') + '</td><td style="text-align:right;color:' + (a.vac != null && a.vac < 0 ? '#b91c1c' : 'inherit') + '">' + (a.vac != null ? esc(fmt(a.vac, 'USD')) : '—') + '</td><td style="text-align:right">' + pct(a.progress) + ' / ' + pct(a.planned) + '</td><td style="text-align:right">' + idx(a.cpi) + '</td><td style="text-align:right">' + idx(a.spi) + '</td><td style="text-align:right">' + (a.finPrevue == null ? '—' : a.retard + ' sem') + '</td></tr>';
    });
    h += '</table></div>' + (PJ.rows.length > 150 ? '<p class="exb-muted">150 premiers projets affichés sur ' + PJ.rows.length + '.</p>' : '') +
      '<p class="exb-muted" style="margin-top:4px">Calcul à la date du jour (le filtre de période ne s’applique pas). Cliquez sur un projet pour le détail et ses alertes.' + (PJ.horsUsd ? ' ⚠ ' + PJ.horsUsd + ' dépense(s) de caisse en FC liées à des projets ne sont pas comptées (pas de conversion automatique).' : '') + '</p>';
    return h;
  }
  function drillProjet(id) {
    var a = PJ && PJ.rows.filter(function (x) { return String(x.id) === String(id); })[0]; if (!a) return;
    var al = (a.alerts || []).concat(a.anomalies || []);
    var html = '<div id="bi_dr" style="position:fixed;inset:0;background:rgba(10,20,40,.55);z-index:100000;display:flex;align-items:center;justify-content:center;padding:12px"><div style="background:#fff;border-radius:12px;max-width:640px;width:100%;max-height:86vh;overflow:auto;padding:14px"><div style="display:flex;justify-content:space-between;gap:8px"><h3 style="margin:0">' + esc(a.name) + '</h3><button type="button" id="bi_x">✕</button></div>' +
      '<p class="exb-muted">' + esc(a.closed ? 'Projet terminé' : DOTS[a.status] + ' ' + LABS[a.status]) + (a.client ? ' · client : ' + esc(a.client) : '') + '</p>' +
      '<p>Budget ' + esc(fmt(a.bac, 'USD')) + ' · coût réel ' + esc(fmt(a.ac, 'USD')) + ' · valeur acquise ' + esc(fmt(a.ev, 'USD')) + (a.eac != null ? ' · coût final estimé ' + esc(fmt(a.eac, 'USD')) : '') + '</p>' +
      '<p>Avancement ' + pct(a.progress) + ' (planifié ' + pct(a.planned) + ') · CPI ' + idx(a.cpi) + ' · SPI ' + idx(a.spi) + (a.finPrevue != null ? ' · retard prévisionnel ' + a.retard + ' sem' : '') + '</p>' +
      (a.eng && a.eng.nb ? '<p><b>Engagements</b> (bons de commande non annulés, USD) : commandé ' + esc(fmt(a.eng.commande, 'USD')) + ' · reçu ' + esc(fmt(a.eng.recu, 'USD')) + ' · reste à recevoir ' + esc(fmt(a.eng.reste, 'USD')) + ' · payé ' + esc(fmt(a.eng.paye, 'USD')) + (a.eng.disponible != null ? ' · disponible sur le budget ' + esc(fmt(a.eng.disponible, 'USD')) + ' (' + a.eng.taux + ' % engagé)' : ' · pas de budget pour comparer') + '</p><p class="exb-muted">Les engagements ne sont pas ajoutés au coût réel : un paiement fournisseur peut déjà figurer en caisse.' + (a.eng.horsUsd ? ' ⚠ ' + a.eng.horsUsd + ' bon(s) de commande en FC non comptés.' : '') + '</p>' : '') +
      ((a.jalons || []).length ? '<p><b>Jalons</b></p><ul>' + a.jalons.map(function (j) { return '<li>' + esc(j.name || 'Jalon') + ' · prévu S' + j.semaine_prevue + (j.ecart > 0 ? ' (prévision S' + j.semaine_fin_prevue + ')' : '') + ' · <b>' + esc({ atteint: 'atteint', en_retard: 'en retard', menace: 'menacé', a_venir: 'à venir' }[j.statut]) + '</b></li>'; }).join('') + '</ul>' : '') +
      '<p class="exb-muted">Sources : avancement = ' + esc((a.sources || {}).progress || '—') + ' ; planifié = ' + esc((a.sources || {}).planned || '—') + '.</p>' +
      (al.length ? '<ul>' + al.map(function (x) { return '<li><small>' + esc(x.sev === 'high' ? 'À traiter' : x.sev === 'medium' ? 'À surveiller' : 'Donnée') + '</small> ' + esc(x.msg) + (x.hint ? '<br><small class="exb-muted">→ ' + esc(x.hint) + '</small>' : '') + '</li>'; }).join('') + '</ul>' : '<p class="exb-muted">Aucune alerte.</p>') +
      '<p class="exb-muted">Réglage des seuils et rapport PDF du projet : menu « Pilotage projets ».</p></div></div>';
    var el = d.createElement('div'); el.innerHTML = html; d.body.appendChild(el.firstChild);
    $('bi_x').onclick = function () { var x = $('bi_dr'); if (x) x.remove(); };
    $('bi_dr').onclick = function (e) { if (e.target === this) this.remove(); };
  }
  var DEF = [
    ['facture', 'Facturé', 'Total TTC des factures non annulées émises sur la période.'],
    ['encaisse', 'Encaissé', 'Encaissements de la période (registre unique : factures, caisse, paiements V93, sans doublon).'],
    ['depenses', 'Dépenses', 'Sorties de caisse de la période.'],
    ['resultat', 'Résultat de trésorerie', 'Encaissé − Dépenses (hors engagements non payés).'],
    ['creances', 'Créances clients', 'Soldes restant dus sur toutes les factures non annulées, à ce jour (indépendant de la période).'],
    ['echu', 'Dont échues', 'Part des créances dont l’échéance est dépassée.'],
    ['dettes', 'Dettes fournisseurs', 'Valeur reçue moins paiements sur les bons de commande non annulés, à ce jour (indépendant de la période).'],
    ['engages', 'Engagements', 'Commandé non encore reçu ni payé sur les bons de commande non annulés, à ce jour.']
  ];
  var DEFP = [
    ['bac', 'Budget du projet', 'Total du budget de construction détaillé s’il existe, sinon budget saisi sur le projet (USD).'],
    ['ac', 'Coût réel', 'Le plus élevé entre le coût réel du budget détaillé et les sorties de caisse du projet en USD (jamais sous-estimé).'],
    ['ev', 'Valeur acquise', 'Budget × avancement physique (planning pondéré par les durées, sinon avancement saisi du projet).'],
    ['cpi', 'CPI', 'Valeur acquise ÷ coût réel. Sous 1 : le projet coûte plus que prévu pour ce qui est réalisé.'],
    ['spi', 'SPI', 'Valeur acquise ÷ valeur planifiée à ce jour. Sous 1 : le projet est en retard sur le planifié.'],
    ['eng', 'Engagé', 'Total commandé sur les bons de commande non annulés du projet (USD), comparé au budget ; non ajouté au coût réel (pas de double comptage avec la caisse).'],
    ['histo', 'Historique des soldes', 'Instantané mensuel (créances, échues, dettes, engagements et compteurs RH/Stock/Workflow) pris à chaque ouverture du tableau de bord, sans filtre ni conversion. Commence à la première ouverture ; aucun mois passé n’est reconstitué.'],
    ['ops', 'Activité des modules', 'RH : fiches approuvées par statut (aucun nom ni salaire) ; Stock : articles dont la quantité est ≤ au seuil ; CRM : devis de la période ; Workflow : dossiers en cours, en retard (échéance dépassée) et décisions sur 30 jours.'],
    ['eac', 'Coût final estimé / écart final', 'Budget ÷ CPI ; écart final = budget − coût final estimé (négatif = dépassement attendu).']
  ];
  /* ---------- V186 : dictionnaire complet (source, fréquence, responsable, règle de validation) et statut de fiabilité par indicateur ----------
   * Cahier des charges §8 : « La BI ne doit pas afficher comme fiables des données incomplètes ou non validées. »
   * Statuts : ok = vérifié · warn = à vérifier (anomalie ou donnée incomplète) · ko = non fiable (incohérence) · na = aucune donnée source.
   * Le statut est calculé à chaque affichage à partir des données ; il ne modifie jamais les valeurs. */
  var FIN = { src: 'Factures, caisse et paiements (Finances)', freq: 'À chaque ouverture (temps réel)', resp: 'Responsable Finance', regle: 'Rapprochement : somme des soldes de factures = facturé − encaissé sur factures ; aucun encaissement en double' };
  var META = {
    facture: Object.assign({}, FIN, { src: 'Factures (exb_invoices)', regle: 'Factures non annulées, avec date ; rapprochement factures/paiements cohérent' }),
    encaisse: Object.assign({}, FIN, { src: 'Registre unique des encaissements (factures, caisse, paiements, formations)', regle: 'Rapprochement cohérent ; aucun encaissement suspect en double' }),
    depenses: Object.assign({}, FIN, { src: 'Sorties de caisse (exb_cash)', regle: 'Sorties datées et rattachées ; encaissements suspects signalés' }),
    resultat: Object.assign({}, FIN, { src: 'Encaissé − Dépenses', regle: 'Hérite de la fiabilité de l’encaissé et des dépenses' }),
    creances: Object.assign({}, FIN, { src: 'Soldes des factures clients', regle: 'Rapprochement factures/paiements cohérent' }),
    echu: Object.assign({}, FIN, { src: 'Factures clients avec échéance', regle: 'Chaque facture impayée possède une échéance' }),
    dettes: { src: 'Bons de commande (exb_purchase_orders)', freq: 'À chaque ouverture', resp: 'Responsable Achats / Stock', regle: 'Bons de commande avec lignes, devise et quantités reçues renseignées' },
    engages: { src: 'Bons de commande (exb_purchase_orders)', freq: 'À chaque ouverture', resp: 'Responsable Achats / Stock', regle: 'Bons de commande avec lignes et devise ; commandé ≥ reçu' },
    bac: { src: 'Budget détaillé ou budget saisi du projet', freq: 'À chaque ouverture', resp: 'Chef de projet', regle: 'Budget > 0 sur chaque projet ouvert' },
    ac: { src: 'Budget détaillé et sorties de caisse du projet', freq: 'À chaque ouverture', resp: 'Chef de projet / Finance', regle: 'Budget > 0 ; dépenses rattachées au projet' },
    ev: { src: 'Budget × avancement (planning pondéré)', freq: 'À chaque ouverture', resp: 'Chef de projet', regle: 'Budget > 0 et avancement renseigné (planning ou saisie)' },
    cpi: { src: 'Valeur acquise ÷ coût réel', freq: 'À chaque ouverture', resp: 'Chef de projet', regle: 'Budget > 0 et coût réel > 0' },
    spi: { src: 'Valeur acquise ÷ valeur planifiée', freq: 'À chaque ouverture', resp: 'Chef de projet', regle: 'Planning renseigné (dates de début et de fin)' },
    eng: { src: 'Bons de commande du projet (USD)', freq: 'À chaque ouverture', resp: 'Chef de projet / Achats', regle: 'Bons de commande en USD ; hors USD signalés et exclus' },
    eac: { src: 'Budget ÷ CPI', freq: 'À chaque ouverture', resp: 'Chef de projet', regle: 'CPI calculable (budget et coût réel > 0)' },
    histo: { src: 'Instantané mensuel pris à l’ouverture du tableau de bord', freq: 'Mensuel (à la première ouverture du mois)', resp: 'Contrôle de gestion', regle: 'Commence à la première ouverture ; aucun mois passé reconstitué' },
    ops: { src: 'Fiches RH approuvées, Stock, devis CRM, dossiers Workflow', freq: 'À chaque ouverture', resp: 'Responsables de modules', regle: 'Fiches RH approuvées seulement ; compteurs agrégés sans nom ni salaire' }
  };
  var FIAB_LAB = { ok: ['✔', 'Vérifié', '#1f7a4d'], warn: ['⚠', 'À vérifier', '#b26a00'], ko: ['⛔', 'Non fiable', '#c0392b'], na: ['–', 'Aucune donnée', '#5e6877'] };
  function fiabilite(id, ctx) {
    ctx = ctx || {}; var L = ctx.last || {}, src = ctx.src || {}, pj = ctx.pj || { rows: [] }, ops = ctx.ops || null, rows = pj.rows || [];
    function R(s, why) { return { s: s, why: why || '' }; }
    var rap = L.rapprochement || { ok: true };
    if (id === 'facture' || id === 'creances' || id === 'echu' || id === 'encaisse' || id === 'depenses' || id === 'resultat') {
      var inv = src.invoices || [];
      if (!inv.length && !(src.cash || []).length && !(src.ledger || []).length) return R('na', 'Aucune facture ni mouvement de caisse enregistré.');
      if (!rap.ok && id !== 'depenses') return R('ko', 'Incohérence entre factures et paiements : vérifier les données sources (Finances).');
      if ((id === 'encaisse' || id === 'resultat') && src.suspects) return R('warn', src.suspects + ' encaissement(s) possiblement en double (voir Finances).');
      if (id === 'facture') { var sd = inv.filter(function (i) { return !cancelled(i) && !iso(i.date); }).length; if (sd) return R('warn', sd + ' facture(s) sans date : exclues de la période.'); }
      if (id === 'echu') { var sn = inv.filter(function (i) { return !cancelled(i) && !i.due; }).length; if (sn) return R('warn', sn + ' facture(s) sans échéance : jamais comptées comme échues.'); }
      if (id === 'depenses' || id === 'resultat') { var sx = (src.cash || []).filter(function (x) { return x && x.type === 'out' && !iso(x.date); }).length; if (sx) return R('warn', sx + ' sortie(s) de caisse sans date : exclues de la période.'); }
      return R('ok', 'Rapprochement cohérent, aucune anomalie détectée.');
    }
    if (id === 'dettes' || id === 'engages') {
      var po = (src.po || []).filter(function (q) { return q && !q.cancel; });
      if (!po.length) return R('na', 'Aucun bon de commande enregistré.');
      var bad = po.filter(function (q) { return !(q.lines || []).length || !q.currency; }).length;
      if (bad) return R('warn', bad + ' bon(s) de commande sans ligne ou sans devise.');
      return R('ok', 'Bons de commande complets.');
    }
    if (/^(bac|ac|ev|cpi|spi|eng|eac)$/.test(id)) {
      var ouv = rows.filter(function (a) { return !a.closed; });
      if (!ouv.length) return R('na', 'Aucun projet ouvert à analyser.');
      var sb = ouv.filter(function (a) { return !(a.bac > 0); }).length;
      if (sb && id !== 'spi') return R('ko', sb + ' projet(s) sans budget : indicateur non fiable pour ces projets.');
      if (id === 'spi') { var sp = ouv.filter(function (a) { return a.planned == null; }).length; if (sp) return R('warn', sp + ' projet(s) sans planning : SPI non calculable pour ces projets.'); }
      if (id === 'ev' || id === 'cpi' || id === 'eac') { var sg = ouv.filter(function (a) { return a.progress == null; }).length; if (sg) return R('warn', sg + ' projet(s) sans avancement renseigné.'); }
      var an = ouv.filter(function (a) { return (a.anomalies || []).length; }).length;
      if (an) return R('warn', an + ' projet(s) avec anomalie de données (ouvrir le détail du projet).');
      if (pj.horsUsd) return R('warn', 'Des montants hors USD ne sont pas pris en compte dans l’analyse des projets.');
      return R('ok', 'Budget, avancement et coûts renseignés.');
    }
    if (id === 'ops') { if (!ops) return R('na', 'Aucune donnée de module disponible ou droit de lecture absent.'); return R('ok', 'Compteurs agrégés (fiches approuvées seulement).'); }
    if (id === 'histo') return R('ok', 'Instantané pris à l’ouverture.');
    return R('na', '');
  }
  function fiabBadge(id) {
    var f = fiabilite(id, { last: LAST, src: SRC, pj: PJ, ops: OPS }), l = FIAB_LAB[f.s] || FIAB_LAB.na;
    return '<span class="bi-fiab bi-fiab-' + f.s + '" title="' + esc(l[1] + (f.why ? ' — ' + f.why : '')) + '" style="display:inline-block;margin-top:3px;font-size:11px;color:' + l[2] + '">' + l[0] + ' ' + l[1] + '</span>';
  }
  function dicoHtml() {
    var all = DEF.concat(DEFP), h = '<div style="overflow:auto"><table style="border-collapse:collapse;font-size:12px;width:100%"><tr style="text-align:left;background:#eef2f8"><th style="padding:4px 6px">Indicateur</th><th style="padding:4px 6px">Formule / définition</th><th style="padding:4px 6px">Source</th><th style="padding:4px 6px">Fréquence</th><th style="padding:4px 6px">Responsable</th><th style="padding:4px 6px">Règle de validation</th><th style="padding:4px 6px">Fiabilité actuelle</th></tr>';
    all.forEach(function (df) {
      var m = META[df[0]] || {}, resp = (P.resp && P.resp[df[0]]) || m.resp || '';
      h += '<tr style="border-top:1px solid #e3e8f0;vertical-align:top"><td style="padding:4px 6px"><b>' + esc(df[1]) + '</b></td><td style="padding:4px 6px">' + esc(df[2]) + '</td><td style="padding:4px 6px">' + esc(m.src || '') + '</td><td style="padding:4px 6px">' + esc(m.freq || '') + '</td><td style="padding:4px 6px"><input class="bi-resp" data-id="' + esc(df[0]) + '" value="' + esc(resp) + '" aria-label="Responsable de ' + esc(df[1]) + '" style="width:100%;min-width:120px;font-size:12px"></td><td style="padding:4px 6px">' + esc(m.regle || '') + '</td><td style="padding:4px 6px">' + fiabBadge(df[0]) + '</td></tr>';
    });
    return h + '</table></div>';
  }
  function chart(c, series) {
    var W = 560, H = 150, pad = 22, max = 1; series.forEach(function (s) { max = Math.max(max, s.enc, s.dep); });
    var bw = (W - pad * 2) / series.length, g = '';
    series.forEach(function (s, i) {
      var x = pad + i * bw, h1 = s.enc / max * (H - 40), h2 = s.dep / max * (H - 40);
      g += '<rect x="' + (x + 2).toFixed(1) + '" y="' + (H - 20 - h1).toFixed(1) + '" width="' + (bw / 2 - 3).toFixed(1) + '" height="' + h1.toFixed(1) + '" fill="#1f7a4d"><title>' + esc(s.m + ' · encaissé ' + fmt(s.enc, c)) + '</title></rect>';
      g += '<rect x="' + (x + bw / 2).toFixed(1) + '" y="' + (H - 20 - h2).toFixed(1) + '" width="' + (bw / 2 - 3).toFixed(1) + '" height="' + h2.toFixed(1) + '" fill="#c0392b"><title>' + esc(s.m + ' · dépenses ' + fmt(s.dep, c)) + '</title></rect>';
      g += '<text x="' + (x + bw / 2).toFixed(1) + '" y="' + (H - 6) + '" font-size="9" text-anchor="middle" fill="#5e6877">' + esc(s.m.slice(5)) + '</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;max-width:640px" role="img" aria-label="Encaissé et dépenses par mois">' + g + '</svg>';
  }
  function render() {
    var box = $('bi_box'); if (!box) return;
    if (!can()) { box.innerHTML = '<p class="exb-muted">Vous n’avez pas le droit de consulter le tableau de bord de direction.</p>'; return; }
    SRC = gather(); FORCE = null;
    LAST = compute(P.conv && SRC.rate > 0 ? convertSrc(SRC, SRC.rate) : SRC, { range: range(), pid: P.pid, dept: P.dept });
    /* V173 — adaptation aux données : si la période choisie est vide mais qu'il existe des données, on élargit à « Depuis le début » (signalé, préférence inchangée) */
    var hasFlow = function (X) { return Object.keys(X.kpi).some(function (c) { var k = X.kpi[c]; return k.facture || k.encaisse || k.depenses; }); };
    if (P.auto !== 0 && P.per !== 'tout' && !hasFlow(LAST)) { FORCE = 'tout'; var L2 = compute(P.conv && SRC.rate > 0 ? convertSrc(SRC, SRC.rate) : SRC, { range: range(), pid: P.pid, dept: P.dept }); if (hasFlow(L2)) LAST = L2; else FORCE = null; }
    PJ = computeProjets(SRC, { pid: P.pid, dept: P.dept }); AL = alertes(LAST, PJ, { suspects: SRC.suspects, ops: (OPS = opsOf(SRC)) }); recordHisto();
    var cs = Object.keys(LAST.kpi).sort(function (a, b) { return a === 'USD' ? -1 : b === 'USD' ? 1 : a < b ? -1 : 1; });
    var h = '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px">' +
      '<label>Période <select id="bi_per">' + [['mois', 'Ce mois'], ['trimestre', 'Ce trimestre'], ['annee', 'Cette année'], ['12m', '12 derniers mois'], ['tout', 'Depuis le début']].map(function (o) { return '<option value="' + o[0] + '"' + (P.per === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>' +
      '<label>Projet <select id="bi_pid"><option value="">Tous les projets</option>' + SRC.projects.map(function (p) { return '<option value="' + esc(p.id) + '"' + (P.pid === p.id ? ' selected' : '') + '>' + esc(p.name || p.id) + '</option>'; }).join('') + '</select></label>' +
      (deptList(SRC.projects).length ? '<label>Département <select id="bi_dept"><option value="">Tous</option>' + deptList(SRC.projects).map(function (x) { return '<option value="' + esc(x) + '"' + (P.dept === x ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('') + '</select></label>' : '') +
      '<label title="Convertit les francs congolais en dollars au dernier taux enregistré dans Finances"><input type="checkbox" style="width:auto;height:auto;margin-right:4px" id="bi_conv"' + (P.conv && SRC.rate > 0 ? ' checked' : '') + (SRC.rate > 0 ? '' : ' disabled') + '> Tout en dollars' + (SRC.rate > 0 ? ' (1 $ = ' + fmt(SRC.rate, 'FC') + ')' : ' (taux absent)') + '</label>' +
      '<label>Rapport auto <select id="bi_rap">' + [['off', 'Aucun'], ['hebdo', 'Chaque semaine'], ['mensuel', 'Chaque mois']].map(function (o) { return '<option value="' + o[0] + '"' + (P.rap === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label>' +
      '<button id="bi_cfg" type="button">⚙ Personnaliser</button><button id="bi_csv" type="button">⬇ Export Excel (CSV)</button><button id="bi_pdf" type="button">🖨 Imprimer</button><button id="bi_rep" type="button">📄 Rapport de direction (PDF)</button></div>' + (rapportDu() ? '<div style="background:#fff7e0;border:1px solid #e8c766;border-radius:8px;padding:8px;margin-bottom:8px">📄 Votre rapport ' + (P.rap === 'mensuel' ? 'mensuel' : 'hebdomadaire') + ' est prêt à être généré. <button id="bi_rep2" type="button">Générer maintenant</button></div>' : '');
    h += '<p class="exb-muted" style="margin:0 0 8px">' + esc(LAST.range.lab) + ' · ' + LAST.nbFactures + ' facture(s) · ' + (LAST.rapprochement.ok ? '✓ rapprochement factures/paiements cohérent' : '⚠ incohérence factures/paiements : vérifiez les données sources') + (SRC.suspects ? ' · ⚠ ' + SRC.suspects + ' encaissement(s) possiblement en double (voir Finances)' : '') + '</p>';
    if (FORCE) h += '<p style="margin:0 0 8px;padding:6px 10px;border-radius:8px;background:#fff7e0;border:1px solid #f0d78a">ℹ️ Aucune donnée sur « ' + esc(({ mois: 'ce mois', trimestre: 'ce trimestre', annee: 'cette année', '12m': 'les 12 derniers mois' })[P.per] || P.per) + ' » : le tableau affiche <b>depuis le début</b>. (Désactivable dans ⚙ Personnaliser.)</p>';
    h += cfgHtml() + alertsHtml();
    var showPj = !hiddenHas('projets') && !(P.auto !== 0 && PJ && PJ.dispo && !PJ.rows.length);
    if (showPj) h += projetsCartes() + projetsHtml();
    if (!cs.length) h += '<p class="exb-muted">Aucune donnée financière sur cette période. Créez des factures et enregistrez des encaissements : les indicateurs se calculent seuls.</p>';
    cs.forEach(function (c) {
      var k = LAST.kpi[c];
      h += '<h3 style="margin:14px 0 6px">Montants en ' + (c === 'CDF' ? 'francs congolais (FC)' : c === 'USD' ? 'dollars américains ($)' : esc(c)) + '</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">';
      DEF.forEach(function (df) {
        if (hiddenHas(df[0])) return;
        if (P.auto !== 0 && !k[df[0]] && df[0] !== 'facture' && df[0] !== 'encaisse') return; /* V173 : indicateur à zéro masqué en mode adaptatif */
        var v = k[df[0]], bad = (df[0] === 'resultat' && v < 0) || (df[0] === 'echu' && v > 0);
        h += '<button type="button" class="bi-k" data-c="' + esc(c) + '" data-k="' + df[0] + '" title="' + esc(df[2]) + '" style="text-align:left;border:1px solid #d7deea;border-radius:10px;background:#fff;padding:10px;cursor:pointer"><small style="color:#5e6877">' + esc(df[1]) + '</small><div style="font-size:1.15em;font-weight:700;color:' + (bad ? '#c0392b' : '#12305e') + '">' + esc(fmt(v, c)) + '</div>' + fiabBadge(df[0]) + '</button>';
      });
      h += '</div>' + (hiddenHas('tendance') || (P.auto !== 0 && !(LAST.tendance[c] || []).some(function (x) { return x.enc || x.dep; })) ? '' : '<div style="margin-top:8px"><small class="exb-muted">Encaissé (vert) et dépenses (rouge) par mois, 12 derniers mois</small>' + chart(c, LAST.tendance[c] || []) + '</div>');
    });
    if (!hiddenHas('ops')) h += opsHtml();
    if (!hiddenHas('histo')) h += histoHtml(12, false);
    h += '<details style="margin-top:12px"><summary>ℹ️ Dictionnaire des indicateurs (formule, source, fréquence, responsable, règle de validation, fiabilité)</summary>' + dicoHtml() + '<p class="exb-muted">Les montants ne sont jamais convertis entre devises. Cliquez sur un indicateur pour voir les opérations qui le composent.</p></details>';
    box.innerHTML = h;
    var s1 = $('bi_per'), s2 = $('bi_pid');
    if (s1) s1.onchange = function () { P.per = this.value; savePrefs(); render(); };
    if (s2) s2.onchange = function () { P.pid = this.value; savePrefs(); render(); };
    var s3 = $('bi_dept'); if (s3) s3.onchange = function () { P.dept = this.value; savePrefs(); render(); };
    if ($('bi_csv')) $('bi_csv').onclick = exportCsv;
    Array.prototype.forEach.call(box.querySelectorAll('.bi-resp'), function (inp) { inp.onchange = function () { var id = inp.getAttribute('data-id'); P.resp = P.resp || {}; var v = String(inp.value || '').trim().slice(0, 80); if (v) P.resp[id] = v; else delete P.resp[id]; savePrefs(); }; });
    if ($('bi_cfg')) $('bi_cfg').onclick = function () { P.cfg = P.cfg ? 0 : 1; savePrefs(); render(); };
    Array.prototype.forEach.call(box.querySelectorAll('.bi-show'), function (cb) { cb.onchange = function () { var id = cb.getAttribute('data-id'), a = (P.hide || []).filter(function (x) { return x !== id; }); if (!cb.checked) a.push(id); P.hide = a; savePrefs(); render(); }; });
    if ($('bi_auto')) $('bi_auto').onchange = function () { P.auto = this.checked ? 1 : 0; savePrefs(); render(); };
    if ($('bi_cfg_reset')) $('bi_cfg_reset').onclick = function () { P.hide = []; savePrefs(); render(); };
    if ($('bi_conv')) $('bi_conv').onchange = function () { P.conv = this.checked ? 1 : 0; savePrefs(); render(); };
    if ($('bi_rap')) $('bi_rap').onchange = function () { P.rap = this.value; savePrefs(); render(); };
    if ($('bi_rep')) $('bi_rep').onclick = function () { rapport(); }; if ($('bi_rep2')) $('bi_rep2').onclick = function () { rapport(); };
    badge();
    if ($('bi_pdf')) $('bi_pdf').onclick = function () { try { rapport({ imprimer: true }); } catch (e) { try { if (w.EXBRapport && w.EXBRapport.screen) w.EXBRapport.screen('Tableau de bord BI Direction', { prefix: 'BI' }); else w.print(); } catch (e2) {} audit('bi.impression'); } };
    Array.prototype.forEach.call(box.querySelectorAll('.bi-k'), function (b) { b.onclick = function () { drill(b.getAttribute('data-c'), b.getAttribute('data-k')); }; });
    Array.prototype.forEach.call(box.querySelectorAll('.bi-pj'), function (b) { b.onclick = function (e) { if (e && e.preventDefault) e.preventDefault(); drillProjet(b.getAttribute('data-id')); }; });
  }
  /* ---------- rapport de direction et rappel périodique ---------- */
  function monday(s_) { var x = new Date(String(s_) + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x.toISOString().slice(0, 10); }
  function rapportDu() {
    if (P.rap === 'off') return false; var t = today(), l = P.lastRap || '';
    if (!l) return true;
    return P.rap === 'mensuel' ? l.slice(0, 7) < t.slice(0, 7) : monday(l) < monday(t);
  }
  function badge() {
    try { var b = $('bbi'); if (!b || !LAST) return; var n = (AL || []).filter(function (a) { return a.sev === 'high'; }).length; b.textContent = '📈 BI Direction' + (n ? ' 🔴' + n : '') + (rapportDu() ? ' 📄' : ''); } catch (e) {}
  }
  function rapport(opt) {
    var IMP = !!(opt && opt.imprimer === true); /* V186i : « Imprimer » = même document que le rapport, envoyé à l'imprimante */
    if (!LAST) render();
    var h = '<h1>Excellencia Building — Rapport de direction</h1><p>' + esc(LAST.range.lab) + (P.dept ? ' · département ' + esc(P.dept) : '') + ' · généré le ' + esc(today()) + (P.conv && SRC.rate > 0 ? ' · montants en dollars (1 $ = ' + esc(fmt(SRC.rate, 'FC')) + ')' : '') + '</p>';
    h += '<h2>Alertes de direction</h2>' + (AL.length ? '<ul>' + AL.map(function (a) { return '<li>' + (a.sev === 'high' ? '🔴' : '🟠') + ' ' + esc(a.msg) + '</li>'; }).join('') + '</ul>' : '<p>Aucune alerte.</p>');
    Object.keys(LAST.kpi).forEach(function (c) { var k = LAST.kpi[c]; h += '<h2>Indicateurs (' + esc(c === 'CDF' ? 'FC' : c) + ')</h2><table>' + DEF.map(function (df) { return '<tr><td>' + esc(df[1]) + '</td><td style="text-align:right">' + esc(fmt(k[df[0]], c)) + '</td></tr>'; }).join('') + '</table>'; });
    try { h += projetsHtml().replace(/class="exb-muted"/g, '').replace(/<button[^>]*>/g, '<span>').replace(/<\/button>/g, '</span>'); } catch (e) {}
    try { h += opsPrint(); h += histoHtml(6, true); } catch (e) {}
    h += '<p style="margin-top:18px;font-size:11px;color:#555">Rapport calculé automatiquement à partir des factures, encaissements, dépenses et plannings. Lecture seule.</p>';
    var I = {}; try { I = (w.EXBId && EXBId.get()) || {}; } catch (e) {}
    var nm = I.name || 'Excellencia Building';
    h = h.replace('Excellencia Building — Rapport de direction', esc(nm) + ' — Rapport de direction');
    /* V177 : en-tête de marque + QR de vérification publique (module commun) ; l'ancienne mise en page reste le repli */
    if (w.EXBRapport) {
      try {
        var body = h.replace(/^<h1>[\s\S]*?<\/h1>/, '').replace(/<p>[\s\S]*?<\/p>/, '');
        w.EXBRapport.print('Rapport de direction', { sousTitre: LAST.range.lab + (P.dept ? ' · département ' + P.dept : '') + (P.conv && SRC.rate > 0 ? ' · montants en dollars (1 $ = ' + fmt(SRC.rate, 'FC') + ')' : ''), meta: [['Période', LAST.range.lab], ['Alertes', AL.length]], html: body, prefix: 'BI', imprimer: IMP });
        P.lastRap = today(); savePrefs(); audit(IMP ? 'bi.impression' : 'bi.rapport'); setTimeout(render, 800); return;
      } catch (e) {}
    }
    var head = '<div data-exb-habillage="1" style="display:flex;gap:12px;align-items:center;border-bottom:2px solid #c8962e;padding-bottom:8px;margin-bottom:10px">' + (I.logo ? '<img src="' + esc(I.logo) + '" style="height:48px"/>' : '') + '<div><b style="font-size:15px">' + esc(nm) + '</b><div style="font-size:11px;color:#555">' + esc([I.address, I.phone, I.email].filter(Boolean).join(' · ')) + '</div></div></div>';
    var foot = '<div style="margin-top:14px;font-size:10px;color:#555;border-top:1px solid #ddd;padding-top:6px">' + esc(I.legal ? String(I.legal).split(/\r?\n+/).filter(Boolean).join('  ·  ') : '') + (I.footer ? ' ' + esc(I.footer) : '') + '</div>';
    var doc = '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Rapport de direction</title><style>body{font-family:Arial,sans-serif;color:#12305e;margin:24px}h1{font-size:20px}h2{font-size:15px;margin:16px 0 6px;border-bottom:1px solid #c8962e}table{width:100%;border-collapse:collapse;font-size:12px}td,th{padding:3px 6px;border-top:1px solid #ddd}</style></head><body>' + head + h + foot + '</body></html>';
    if (w.EXBPrint && EXBPrint.html) EXBPrint.html('Rapport de direction', doc, { print: IMP });
    else { var f = d.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'; f.srcdoc = doc; f.onload = function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {} setTimeout(function () { f.remove(); }, 60000); }; d.body.appendChild(f); }
    P.lastRap = today(); savePrefs(); audit('bi.rapport'); setTimeout(render, 800);
  }
  function drill(c, k) {
    var rows = ((LAST.sources[c + '|' + k]) || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }), tot = rows.reduce(function (a, r) { return a + r.montant; }, 0), df = DEF.filter(function (x) { return x[0] === k; })[0] || [k, k, ''];
    var html = '<div id="bi_dr" style="position:fixed;inset:0;background:rgba(10,20,40,.55);z-index:100000;display:flex;align-items:center;justify-content:center;padding:12px"><div style="background:#fff;border-radius:12px;max-width:760px;width:100%;max-height:86vh;overflow:auto;padding:14px"><div style="display:flex;justify-content:space-between;gap:8px"><h3 style="margin:0">' + esc(df[1]) + ' — opérations sources (' + rows.length + ')</h3><button type="button" id="bi_x">✕</button></div><p class="exb-muted">' + esc(df[2]) + '</p>' +
      (rows.length ? '<table style="width:100%;border-collapse:collapse"><tr style="text-align:left"><th>Date</th><th>Référence</th><th>Détail</th><th style="text-align:right">Montant</th></tr>' + rows.slice(0, 300).map(function (r) { return '<tr style="border-top:1px solid #e3e9f2"><td>' + esc(r.date) + '</td><td>' + esc(r.ref) + '</td><td>' + esc(r.lib) + '</td><td style="text-align:right">' + esc(fmt(r.montant, c)) + '</td></tr>'; }).join('') + '</table>' + (rows.length > 300 ? '<p class="exb-muted">300 premières lignes affichées sur ' + rows.length + '.</p>' : '') + '<p><b>Total : ' + esc(fmt(Math.round(tot * 100) / 100, c)) + '</b></p>' : '<p class="exb-muted">Aucune opération.</p>') + '</div></div>';
    var el = d.createElement('div'); el.innerHTML = html; d.body.appendChild(el.firstChild);
    $('bi_x').onclick = function () { var x = $('bi_dr'); if (x) x.remove(); };
    $('bi_dr').onclick = function (e) { if (e.target === this) this.remove(); };
  }
  function csvCell(v) { var isStr = typeof v === 'string'; v = String(v == null ? '' : v); if (isStr && /^[=+\-@\t\r]/.test(v)) v = "'" + v; return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  function exportCsv() {
    if (!LAST) return;
    var L = ['Excellencia Building — Tableau de bord direction;' + LAST.range.lab + (P.dept ? ' · departement ' + P.dept : '') + ';Genere le ' + today(), '', 'Devise;Indicateur;Montant'];
    Object.keys(LAST.kpi).forEach(function (c) { DEF.forEach(function (df) { L.push([c, df[1], LAST.kpi[c][df[0]]].map(csvCell).join(';')); }); });
    L.push('', 'Devise;Indicateur;Date;Reference;Detail;Montant');
    Object.keys(LAST.sources).forEach(function (kk) { var p = kk.split('|'); LAST.sources[kk].forEach(function (r) { L.push([p[0], p[1], r.date, r.ref, r.lib, r.montant].map(csvCell).join(';')); }); });
    if (PJ && PJ.dispo && PJ.rows.length) {
      L.push('', 'Projets (USD, a ce jour)', 'Projet;Statut;Budget;Cout reel;Engage;Cout final estime;Ecart final;Avancement %;Planifie %;CPI;SPI;Retard (sem)');
      PJ.rows.forEach(function (a) { L.push([a.name, a.closed ? 'Termine' : LABS[a.status], a.bac, a.ac, a.eng && a.eng.nb ? a.eng.commande : '', a.eac == null ? '' : a.eac, a.vac == null ? '' : a.vac, a.progress, a.planned == null ? '' : a.planned, a.cpi == null ? '' : a.cpi, a.spi == null ? '' : a.spi, a.finPrevue == null ? '' : a.retard].map(csvCell).join(';')); });
    }
    if (PJ && PJ.dispo) { var JR = []; PJ.rows.forEach(function (a) { (a.jalons || []).forEach(function (j) { JR.push([a.name, j.name, 'S' + j.semaine_prevue, 'S' + j.semaine_fin_prevue, j.statut].map(csvCell).join(';')); }); }); if (JR.length) { L.push('', 'Jalons', 'Projet;Jalon;Semaine prevue;Semaine prevision;Statut'); JR.forEach(function (x) { L.push(x); }); } }
    if (OPS && (OPS.rh || OPS.stock || OPS.crm || OPS.wf)) {
      L.push('', 'Dictionnaire des indicateurs', 'Indicateur;Source;Frequence;Responsable;Regle de validation;Fiabilite');
      DEF.concat(DEFP).forEach(function (df) { var m = META[df[0]] || {}, f = fiabilite(df[0], { last: LAST, src: SRC, pj: PJ, ops: OPS }); L.push([df[1], m.src || '', m.freq || '', (P.resp && P.resp[df[0]]) || m.resp || '', m.regle || '', (FIAB_LAB[f.s] || [])[1] + (f.why ? ' - ' + f.why : '')].map(csvCell).join(';')); });
      L.push('', 'Activite des modules', 'Module;Indicateur;Valeur');
      if (OPS.rh) { L.push(['RH', 'Effectif actif', OPS.rh.actifs].map(csvCell).join(';'), ['RH', 'En conge', OPS.rh.conge].map(csvCell).join(';'), ['RH', 'Fiches a approuver', OPS.rh.enAttente].map(csvCell).join(';')); }
      if (OPS.stock) { L.push(['Stock', 'Articles', OPS.stock.articles].map(csvCell).join(';'), ['Stock', 'A commander', OPS.stock.aCommander].map(csvCell).join(';'), ['Stock', 'En rupture', OPS.stock.ruptures].map(csvCell).join(';')); }
      if (OPS.crm) { L.push(['CRM', 'Clients', OPS.crm.clients].map(csvCell).join(';'), ['CRM', 'Devis de la periode', OPS.crm.devis].map(csvCell).join(';')); Object.keys(OPS.crm.montants).forEach(function (c) { L.push(['CRM', 'Montant des devis ' + c, OPS.crm.montants[c]].map(csvCell).join(';')); }); }
      if (OPS.wf) { L.push(['Workflow', 'Dossiers en cours', OPS.wf.enCours].map(csvCell).join(';'), ['Workflow', 'En retard', OPS.wf.enRetard].map(csvCell).join(';'), ['Workflow', 'Retournes', OPS.wf.retournes].map(csvCell).join(';')); }
    }
    var HI = histoRead(); if (can() && HI.length) { L.push('', 'Historique des soldes', 'Mois;Devise;Creances;Dont echues;Dettes;Engagements'); HI.forEach(function (r) { Object.keys(r.kpi || {}).forEach(function (c) { var k = r.kpi[c]; L.push([r.mois, c, k.creances, k.echu, k.dettes, k.engages].map(csvCell).join(';')); }); }); }
    if (AL.length) { L.push('', 'Alertes de direction', 'Gravite;Source;Message'); AL.forEach(function (a) { L.push([a.sev === 'high' ? 'A traiter' : 'A surveiller', a.src, a.msg].map(csvCell).join(';')); }); }
    var blob = new Blob(['﻿' + L.join('\r\n')], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 'BI-direction-' + today() + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    audit('bi.export');
  }
  function audit(a) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, 'exbbi', { periode: P.per, projet: P.pid ? 1 : 0 }); } catch (e) {} }

  function mount() {
    if ($('exbbi')) return;
    var ref = $('budgetfin') || $('comptabilite') || $('chantiers') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, s = d.createElement('section');
    s.id = 'exbbi'; s.style.display = 'none';
    s.innerHTML = '<div class="card"><div class="exb-module-head"><div><h2>📈 Excellencia BI — Direction</h2><p class="exb-muted">Indicateurs financiers calculés à partir de vos factures, encaissements et dépenses. Lecture seule : rien n’est modifié.</p></div></div><div id="bi_box"></div></div>';
    if (ref && ref.parentNode) ref.parentNode.insertBefore(s, ref.nextSibling); else host.appendChild(s);
    var b = $('bbfin') || $('bcompta') || $('bchan') || $('bprj');
    if (b && !$('bbi')) { var n = d.createElement('button'); n.id = 'bbi'; n.textContent = '📈 BI Direction'; n.setAttribute('onclick', "show('exbbi')"); b.parentNode.insertBefore(n, b.nextSibling); }
    setTimeout(function () { try { SRC = gather(); LAST = compute(SRC, { range: range(), pid: P.pid, dept: P.dept }); PJ = computeProjets(SRC, { pid: P.pid, dept: P.dept }); AL = alertes(LAST, PJ, { suspects: SRC.suspects, ops: (OPS = opsOf(SRC)) }); recordHisto(); badge(); var n = AL.filter(function (a) { return a.sev === 'high'; }).length; if (n && P.lastAlert !== today() && w.notify) { P.lastAlert = today(); savePrefs(); w.notify('📈 BI Direction : ' + n + ' alerte(s) critique(s) à consulter.', 'warn', 6000); } } catch (e) {} }, 6000);
    var os = w.show;
    if (typeof os === 'function' && !w.__exbBiShow) { w.__exbBiShow = 1; w.show = function (x) { var r = os.apply(this, arguments), e = $('exbbi'); if (e) e.style.display = (x === 'exbbi') ? '' : 'none'; if (x === 'exbbi') render(); return r; }; }
  }
  w.EXBBI = { version: 8, fiabilite: fiabilite, meta: META, snapshot: snapshot, histoUpsert: histoUpsert, operationnel: operationnel, convertSrc: convertSrc, departements: deptList, engagements: engagements, compute: compute, computeProjets: computeProjets, alertes: alertes, gather: gather, render: render, definitions: DEF.concat(DEFP).map(function (x) { var m = META[x[0]] || {}; return { id: x[0], nom: x[1], regle: x[2], source: m.src || '', frequence: m.freq || '', responsable: m.resp || '', validation: m.regle || '' }; }) };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(mount, 900); }); else setTimeout(mount, 900);
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
