/* Excellencia Building — EXCELLENCIA CORE v1.0 (V143b)
 * Noyau commun, ajouté SANS modifier les modules existants. Il fournit aux modules, un par un, un contrat unique :
 *   1. Version unique        : EXBCore.build (lue par le pied de page et le diagnostic).
 *   2. Identifiants stables  : EXBCore.id('facture') → "facture_K7_m3x9a2_f4q1" ; EXBCore.ensureId(fiche, 'facture').
 *   3. Bus d'événements      : EXBCore.bus.emit / on / off, enveloppe versionnée {v, id, t, name, source, payload}, journal des 200 derniers.
 *   4. Journal d'audit commun: EXBCore.audit.log(action, objet, détail), chaîné par empreinte SHA-256, vérifiable (audit.verify()).
 *   5. Contrat de module     : EXBCore.modules.register({id, name, version, area, deps, provides, collections}) + validate().
 *   6. Droits                : EXBCore.can(collection, 'lire'|'ecrire') délègue au serveur de droits existant (EXBDB.can).
 *   7. Santé                 : EXBCore.health() — version, appareil, modules, dernière sauvegarde, intégrité du journal.
 * Écoute (lecture seule) : chaque EXBS.set() publie l'événement « data.changed » {key, count}. Aucune donnée métier n'est modifiée.
 * Pour retirer : supprimer la balise <script src="exb-core.js"> de index.html (les modules n'en dépendent pas encore). */
(function (w) {
  'use strict';
  if (w.EXBCore) return;
  var BUILD = 'V194-CORE', CORE = '1.0.0', EV_KEY = 'exb_core_events', AU_KEY = 'exb_core_chain', EV_MAX = 200, AU_MAX = 500;

  function lsGet(k) { try { return JSON.parse(w.localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function lsSet(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function device() { try { return (w.EXB_UNIQUE && w.EXB_UNIQUE.deviceCode && w.EXB_UNIQUE.deviceCode()) || 'XX'; } catch (e) { return 'XX'; } }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.role)) || 'local'; } catch (e) { return 'local'; } }
  function rnd(n) { var s = ''; try { var a = new Uint8Array(n); w.crypto.getRandomValues(a); for (var i = 0; i < n; i++) s += (a[i] % 36).toString(36); } catch (e) { while (s.length < n) s += Math.random().toString(36).slice(2); s = s.slice(0, n); } return s; }

  /* 2. identifiants stables */
  function id(type) { return String(type || 'obj').replace(/[^a-z0-9_]/gi, '').toLowerCase() + '_' + String(device()).toLowerCase() + '_' + Date.now().toString(36) + '_' + rnd(4); }
  function ensureId(o, type) { if (o && typeof o === 'object' && !o.id && !o.uid) o.uid = id(type); return o; }

  /* 3. bus d'événements */
  var subs = {}, journal = (function () { var j = lsGet(EV_KEY); return Array.isArray(j) ? j.slice(-EV_MAX) : []; })();
  function on(name, fn) { (subs[name] = subs[name] || []).push(fn); return function () { off(name, fn); }; }
  function off(name, fn) { subs[name] = (subs[name] || []).filter(function (f) { return f !== fn; }); }
  function emit(name, payload, source) {
    var ev = { v: 1, id: id('evt'), t: new Date().toISOString(), name: String(name), source: source || 'core', payload: payload === undefined ? null : payload };
    var keep = { v: ev.v, id: ev.id, t: ev.t, name: ev.name, source: ev.source };
    try { var p = JSON.stringify(payload); if (p && p.length <= 300) keep.payload = payload; } catch (e) {}
    journal.push(keep); if (journal.length > EV_MAX) journal = journal.slice(-EV_MAX);
    if (name !== 'data.changed') lsSet(EV_KEY, journal); /* data.changed est trop fréquent pour être écrit à chaque fois */
    (subs[name] || []).concat(subs['*'] || []).forEach(function (f) { try { f(ev); } catch (e) { try { w.console.warn('[EXBCore] abonné en erreur', name, e); } catch (x) {} } });
    return ev;
  }

  /* 4. journal d'audit chaîné */
  function sha(text) {
    try {
      if (w.crypto && w.crypto.subtle) return w.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)).then(function (b) { return Array.prototype.map.call(new Uint8Array(b), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); });
    } catch (e) {}
    var h = 5381; for (var i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
    return Promise.resolve('d' + (h >>> 0).toString(16));
  }
  /* V185b : l'ancienne clé « exb_core_audit » est aussi utilisée par core/index.js (V91) avec un TABLEAU de lignes ; les deux formats se marchaient dessus
   * et « auditStore.list » devenait indéfini (erreurs « reading 'slice' » / « reading 'forEach' »). Le journal chaîné a désormais sa propre clé, et son contenu est validé. */
  function okStore(o) { return !!o && typeof o === 'object' && !Array.isArray(o) && Array.isArray(o.list) && typeof o.base === 'string'; }
  var auditStore = lsGet(AU_KEY); if (!okStore(auditStore)) { var legacy = lsGet('exb_core_audit'); auditStore = okStore(legacy) ? legacy : { base: '0', list: [] }; } /* reprend un ancien journal chaîné valide, jamais le tableau V91 */
  var chain = Promise.resolve();
  function line(e) { return [e.n, e.t, e.user, e.action, e.obj, e.d, e.prev].join('|'); }
  function log(action, obj, detail) {
    var d = detail == null ? '' : (typeof detail === 'string' ? detail : (function () { try { return JSON.stringify(detail); } catch (e) { return ''; } })());
    d = d.slice(0, 300);
    chain = chain.then(function () {
      var last = auditStore.list[auditStore.list.length - 1];
      var e = { n: (last ? last.n : 0) + 1, t: new Date().toISOString(), user: who(), action: String(action), obj: obj == null ? '' : String(obj), d: d, prev: last ? last.h : auditStore.base };
      return sha(line(e)).then(function (h) {
        e.h = h; auditStore.list.push(e);
        while (auditStore.list.length > AU_MAX) { auditStore.base = auditStore.list.shift().h; }
        lsSet(AU_KEY, auditStore); emit('audit.logged', { n: e.n, action: e.action, obj: e.obj }, 'core'); return e;
      });
    }).catch(function () {});
    return chain;
  }
  function verify() {
    return chain.then(function () {
      var prev = auditStore.base, bad = 0, firstBad = null, p = Promise.resolve();
      auditStore.list.forEach(function (e) {
        p = p.then(function () {
          if (e.prev !== prev) { bad++; if (firstBad == null) firstBad = e.n; prev = e.h; return; }
          return sha(line(e)).then(function (h) { if (h !== e.h) { bad++; if (firstBad == null) firstBad = e.n; } prev = e.h; });
        });
      });
      return p.then(function () { return { ok: bad === 0, entries: auditStore.list.length, broken: bad, firstBroken: firstBad }; });
    });
  }

  /* 5. contrat de module */
  var declared = {};
  function register(m) {
    if (!m || !m.id) throw new Error('EXBCore.modules.register : « id » obligatoire');
    declared[m.id] = { id: String(m.id), name: m.name || m.id, version: m.version || '0.0.0', area: m.area || '', deps: m.deps || [], provides: m.provides || [], collections: m.collections || [], t: Date.now() };
    emit('module.registered', { id: m.id, version: declared[m.id].version }, 'core');
    return declared[m.id];
  }
  function registry() { try { return (w.EXB_MODULES || []).slice(); } catch (e) { return []; } }
  function validate() {
    var known = {}, issues = [];
    registry().forEach(function (m) { known[m.id] = m; });
    Object.keys(declared).forEach(function (k) { if (!known[k]) issues.push({ module: k, type: 'absent-du-registre' }); });
    registry().forEach(function (m) { (m.deps || []).forEach(function (d) { if (!known[d]) issues.push({ module: m.id, type: 'dependance-inconnue', dep: d }); }); });
    return { registry: registry().length, declared: Object.keys(declared).length, issues: issues };
  }

  /* 6. droits (le serveur reste l'autorité ; ceci est le même contrôle que l'écran) */
  function can(collection, action) {
    try { if (w.EXBDB && w.EXBDB.can) return !!w.EXBDB.can(collection, action === 'lire' ? 'lire' : 'ecrire'); } catch (e) {}
    return true; /* mode local sans organisation : tout est permis, comme dans les modules existants */
  }

  /* 7. santé */
  function health() {
    var used = 0; try { for (var i = 0; i < w.localStorage.length; i++) { var k = w.localStorage.key(i); used += (k.length + (w.localStorage.getItem(k) || '').length) * 2; } } catch (e) {}
    var lb = null; try { lb = w.localStorage.getItem('exb_last_backup'); } catch (e) {}
    return verify().then(function (a) {
      return { build: BUILD, core: CORE, device: device(), online: w.navigator ? w.navigator.onLine : null, user: who(), modules: validate(), lastBackup: lb, auditChain: a, events: journal.length, storageKB: Math.round(used / 1024) };
    });
  }

  /* écoute en lecture seule des écritures du pont de stockage commun */
  function hook() {
    try {
      var S = w.EXBS; if (!S || S.__core || typeof S.set !== 'function') return false;
      var orig = S.set; S.__core = true;
      S.set = function (k, a) { var r = orig.apply(this, arguments); try { emit('data.changed', { key: k, count: Array.isArray(a) ? a.length : null }, 'EXBS'); } catch (e) {} return r; };
      return true;
    } catch (e) { return false; }
  }
  var tries = 0, t = setInterval(function () { if (hook() || ++tries > 60) clearInterval(t); }, 500);

  w.EXB_BUILD = BUILD;
  w.EXBCore = {
    build: BUILD, version: CORE, id: id, ensureId: ensureId, can: can, health: health,
    bus: { on: on, off: off, emit: emit, journal: function () { return journal.slice(); } },
    audit: { log: log, verify: verify, list: function () { return auditStore.list.slice(); } },
    modules: { register: register, list: function () { return Object.keys(declared).map(function (k) { return declared[k]; }); }, registry: registry, validate: validate }
  };
  emit('core.ready', { build: BUILD }, 'core');
  log('core.demarrage', 'EXBCore', BUILD);
})(window);
