/* Excellencia Building V227 — TOUS les modules s'ouvrent en page (plus aucune fenêtre flottante pour un module) + retour exact.
 * V227 : (1) la liste des modules en page passe de 18 à 45 : Tâches terrain, Cartouche des plans, Stock : dépôts/inventaires, CRM, Congés, Courrier,
 *   Finances & comptabilité, Devis automatique, Supervision, Administration avancée, Finance USD/FC, Phases architecture, Pilotage direction, Sécurité & sauvegardes,
 *   Continuité, Droits d'action, Journal d'audit, Versions, Synchronisation, Dossier projet, Pièces écrites, Plans & CAO, Permis, Paie & RH, Documents de chantier,
 *   Maintenance/Facility (V74), Réception de chantier… (2) ✕ / « ← catégorie » ramène exactement là d'où l'on venait (liste de la catégorie, module précédent),
 *   et non plus à l'écran d'accueil (EXB_SHELL.leave). (3) la barre de titre et l'habillage résistent aux rafraîchissements du module (changement d'onglet).
 *   Les petites fenêtres de saisie (nouvelle tâche, formulaire, confirmation) restent des fenêtres : seul l'écran principal du module devient une page.
 * (V221i ci-dessous.)
 * Excellencia Building V221i — ÉCRANS DES MODULES EN PAGE (comme « Pilotage projets »).
 * Avant : Environnement, Maintenance, Électricité, Plomberie, Topographie, VRD, Géotechnique, Études P2, Dalles, Juridique, Contrôle réglementaire,
 * Règles IDS, Programme & surfaces, IA architecte, Analyse de site, Coordination, Matériaux et Dossier BE s'ouvraient dans une fenêtre flottante sur fond sombre.
 * Maintenant : chaque module s'affiche dans la zone de contenu, à la place de l'écran en cours, avec la barre latérale visible — exactement comme Pilotage projets.
 * Le contenu, les calculs et les boutons des modules ne changent pas : seule la présentation change (bouton ✕ = retour à l'écran précédent).
 * Si ce fichier est absent, les modules reprennent leur fenêtre flottante d'origine. */
(function (w) {
  'use strict';
  if (w.EXBPAGE) return;
  var d = w.document;
  var OLD = ['exbBeDal', 'exbBeP2', 'exbElec', 'exbEnv', 'exbGeoPlus', 'exbMaint', 'exbReg', 'exbIds', 'exbJur', 'exbPlomb', 'exbTopo', 'exbProg', 'exbIaArch', 'exbVrd', 'exbSite', 'exbCoord', 'exbMat', 'exbBeD'];
  /* V227 : écrans principaux qui s'ouvraient encore en fenêtre flottante (relevé automatique : chaque module du menu ouvert, fenêtre plein écran détectée) */
  var NEW = ['exbTTpanel', 'exbCart', 'stp_ov', 'crp_ov', 'cc_ov', 'cpt_ov', 'exbAd', 'adm_ov', 'sup_ov', 'esp_ov', 'exbDch', 'exbPie', 'exbFin', 'exbArc', 'exbPil', 'exbSec', 'exbCont', 'exbAct', 'exbAu',
    'exbComV', 'exbComS', 'exbComD', 'exbPln', 'exbPer', 'exbPay', 'exbV74Panel', 'exbV76RecPanel'];
  var IDS = OLD.concat(NEW);
  var last = 'dashboard', wrapped = false, current = null;
  function $(i) { return d.getElementById(i); }

  /* V221i : habillage « Chantiers & finances » — titre fort, description, onglets horizontaux à soulignement doré, fil d'Ariane, bouton retour */
  var CSS = '.exb-page-module{font-family:inherit}'
    + '.exb-page-module>div[id$="Box"]{background:#fff!important;border-radius:16px!important;padding:22px 24px!important;box-shadow:0 1px 6px rgba(15,23,42,.10)!important;border:1px solid #e5e9f2}'
    + '.exb-page-module h3{font-size:24px!important;line-height:1.25;color:#173565!important;font-weight:800;margin:6px 0 8px!important}'
    + '.exb-page-module h3+p{font-size:14.5px!important;color:#475569!important;margin:0 0 14px!important}'
    + '.exb-page-module [data-a=close]{display:none!important}'
    + '.exb-page-module div:has(>[data-a=tab]){gap:2px!important;border-bottom:1px solid #d8dfec;margin:0 0 14px!important;overflow-x:auto;flex-wrap:nowrap!important}'
    + '.exb-page-module [data-a=tab]{background:transparent!important;color:#475569!important;border-radius:0!important;border-bottom:3px solid transparent!important;padding:10px 14px!important;font-weight:700;white-space:nowrap}'
    + '.exb-page-module [data-a=tab][style*="0f766e"],.exb-page-module [data-a=tab][style*="15, 118, 110"]{color:#173565!important;border-bottom-color:#c49a38!important}'
    + '.exbpg-top{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:0 0 10px;font:13px Arial,sans-serif;color:#64748b}'
    + '.exbpg-top button{background:#173565;color:#fff;border:0;border-radius:999px;padding:7px 14px;font-weight:700;cursor:pointer}'
    + '.exbpg-top b{color:#173565}';
  CSS += '.exb-page-new{font-family:inherit;width:100%;max-width:1500px;margin:0 auto}'
    + '.exb-page-new>*{max-width:none!important;width:100%!important;max-height:none!important;overflow:visible!important;box-sizing:border-box;border-radius:16px!important;box-shadow:0 1px 6px rgba(15,23,42,.10)!important;border:1px solid #e5e9f2}'
    + '.exb-page-new [data-exbpg-x]{display:none!important}'
    + '.exb-page-new h2,.exb-page-new h3{color:#173565}'
    + '.exb-page-new .tw,.exb-page-new [style*="overflow:auto"]{max-width:100%}'
    + '.exbpg-top.exbpg-sib{max-width:1500px;margin:0 auto 10px;padding:0 2px}';
  function addCss() { if ($('exbPageCss')) return; var st = d.createElement('style'); st.id = 'exbPageCss'; st.textContent = CSS; (d.head || d.documentElement).appendChild(st); }
  function addTop(o) {
    if (o.querySelector('.exbpg-top')) return;
    var top = d.createElement('div'); top.className = 'exbpg-top';
    /* V222f : la catégorie affichée est celle du module (Ingénierie & Structure, Environnement…), lue sur le fil d'Ariane du logiciel ; à défaut « Projets & Chantiers » */
    var catN = 'Projets & Chantiers';
    try { var cb = $('exbCrumb'), cbb = cb && cb.style.display !== 'none' ? cb.querySelector('button') : null, t = cbb ? (cbb.textContent || '').replace(/^[^\wÀ-ÿ]+/u, '').trim() : ''; if (t && t !== 'Accueil') catN = t; } catch (e) { }
    catN = catN.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    top.innerHTML = '<button type="button" data-exbpg-back>← ' + catN + '</button><span>Accueil › ' + catN + ' › <b data-exbpg-name></b></span>';
    o.insertBefore(top, o.firstChild);
    top.querySelector('[data-exbpg-back]').addEventListener('click', function () { var c = o.querySelector('[data-a=close]'); if (c) c.click(); else o.remove(); });
    function name() { var h = o.querySelector('h3'), n = top.querySelector('[data-exbpg-name]'); if (h && n) n.textContent = h.textContent.replace(/^[^\wÀ-ÿ]+/, '').trim(); }
    name(); try { new MutationObserver(name).observe(o, { childList: true, subtree: true }); } catch (e) { }
  }
  function isNew(o) { return NEW.indexOf(o.id) >= 0; }
  function titleOf(o) { var h = o.querySelector('h1,h2,h3,.eh b,h4,b'); return h ? h.textContent.replace(/^[^\wÀ-ÿ]+/u, '').trim() : ''; }
  /* bouton de fermeture du module : [data-a=close], ✕ / × / « Fermer » placé dans l'en-tête (avant tout champ de saisie ou tableau) */
  function findClose(o) {
    var c = o.querySelector('[data-a=close]'); if (c) return c;
    var bs = [].slice.call(o.querySelectorAll('button'));
    for (var i = 0; i < bs.length; i++) { if (/^(?:[✕×✖❌]\s*(?:Fermer)?|Fermer)$/.test((bs[i].textContent || '').trim())) return bs[i]; }
    return null;
  }
  function catName() {
    var catN = 'Projets & Chantiers';
    /* V227 : la catégorie est celle du module ouvert (lue dans le menu), pas celle d'un fil d'Ariane périmé */
    try { var lc = w.EXB_SHELL && w.EXB_SHELL.lastCat && w.EXB_SHELL.lastCat(); if (lc) return lc; } catch (e) { }
    try { var cb = $('exbCrumb'), cbb = cb && cb.style.display !== 'none' ? cb.querySelector('button') : null, t = cbb ? (cbb.textContent || '').replace(/^[^\wÀ-ÿ]+/u, '').trim() : ''; if (t && t !== 'Accueil') catN = t; } catch (e) { }
    return catN;
  }
  /* V227 : barre « ← Catégorie · Accueil › Catégorie › Module » placée AVANT la page (frère) : les modules qui réécrivent leur contenu ne l'effacent plus */
  function skin(o) {
    if (!o.parentNode || !o.getAttribute('data-exbpage')) return;
    var top = o.__exbTop;
    if (!top || !top.isConnected) {
      var catN = (o.__exbCat = o.__exbCat || catName()).replace(/&/g, '&amp;').replace(/</g, '&lt;');
      top = d.createElement('div'); top.className = 'exbpg-top exbpg-sib';
      top.innerHTML = '<button type="button" data-exbpg-back>← ' + catN + '</button><span>Accueil › ' + catN + ' › <b data-exbpg-name></b></span>';
      o.parentNode.insertBefore(top, o); o.__exbTop = top;
      top.querySelector('[data-exbpg-back]').addEventListener('click', function () { var c = findClose(o); if (c) c.click(); else o.remove(); });
    }
    var n = top.querySelector('[data-exbpg-name]'), t = titleOf(o); if (n && t && n.textContent !== t) n.textContent = t;
    var c = findClose(o);
    if (c && !c.hasAttribute('data-exbpg-x')) {
      var first = o.querySelector('input,select,textarea,table');
      if (!first || (first.compareDocumentPosition(c) & 2)) c.setAttribute('data-exbpg-x', '1');
    }
  }
  function watch(o) {
    if (typeof MutationObserver === 'undefined') return; var tm = 0;
    var mo = new MutationObserver(function () { clearTimeout(tm); tm = setTimeout(function () { if (o.isConnected) skin(o); else mo.disconnect(); }, 40); });
    mo.observe(o, { childList: true, subtree: true });
  }
  function hostRef() { return $('pilotprojet') || $('dashboard') || $('projets') || $('direction'); }
  function wrapShow() {
    if (wrapped || typeof w.show !== 'function') return; wrapped = true;
    var os = w.show;
    w.show = function (x) { if (x !== '__exbpage') { last = x || last; closeAll(true); } return os.apply(this, arguments); };
  }
  function drop(o) { o.setAttribute('data-exbpage', ''); try { if (o.__exbTop) Element.prototype.remove.call(o.__exbTop); } catch (e) { } Element.prototype.remove.call(o); }
  function closeAll(silent) { IDS.forEach(function (id) { var o = $(id); if (o && o.getAttribute('data-exbpage')) drop(o); }); if (!silent) current = null; }
  /* transforme la fenêtre flottante `o` en page intégrée */
  function toPage(o) {
    try {
      var ref = hostRef(); if (!ref || !ref.parentNode) return false;
      /* V227 : zone de pages invisible (application non affichée, écran de connexion…) : le module garde sa fenêtre d'origine plutôt que de disparaître */
      if (!ref.parentNode.getClientRects || !ref.parentNode.getClientRects().length) return false;
      wrapShow();
      IDS.forEach(function (id) { var p = $(id); if (p && p !== o && p.getAttribute('data-exbpage')) drop(p); });
      addCss(); o.setAttribute('data-exbpage', '1'); o.classList.add(isNew(o) ? 'exb-page-new' : 'exb-page-module'); if (!isNew(o)) addTop(o);
      try { d.body.style.overflow = ''; d.documentElement.style.overflow = ''; } catch (e) { }
      o.style.cssText = 'display:block;position:static;background:transparent;padding:0;margin:0;width:100%;overflow:visible';
      o.onclick = null;
      var box = o.firstElementChild; if (box && !isNew(o)) { box.style.maxWidth = 'none'; box.style.width = '100%'; box.style.boxSizing = 'border-box'; box.style.boxShadow = '0 1px 4px rgba(15,23,42,.12)'; }
      /* masquer l'écran en cours (liste officielle de show()), puis placer la page dans la zone de contenu */
      try { w.show('__exbpage'); } catch (e) { }
      ref.parentNode.insertBefore(o, ref.nextSibling);
      /* fermeture : retour à l'écran précédent */
      if (isNew(o)) { skin(o); watch(o); }
      /* V227 : fermeture = retour exact à l'écran d'où l'on venait (EXB_SHELL.leave) ; à défaut seulement, écran précédent connu de show(), puis accueil */
      o.remove = function () {
        if (o.getAttribute('data-exbpage')) {
          drop(o);
          /* un module qui change d'étape retire puis recrée son écran dans la même seconde : ce n'est pas une fermeture, on ne navigue pas */
          setTimeout(function () {
            if (IDS.some(function (id) { var e = $(id); return e && e !== o && e.isConnected; })) return;
            var done = false; try { done = !!(w.EXB_SHELL && w.EXB_SHELL.leave && w.EXB_SHELL.leave()); } catch (e) { }
            if (!done) { try { w.show(last || 'dashboard'); } catch (e) { } }
          }, 0);
        } else Element.prototype.remove.call(o);
      };
      current = o;
      try { o.scrollIntoView({ block: 'start' }); w.scrollTo(0, 0); } catch (e) { }
      return true;
    } catch (e) { return false; }
  }
  function isModuleOverlay(n) {
    if (!(n && n.nodeType === 1 && n.tagName === 'DIV' && IDS.indexOf(n.id) >= 0 && !n.getAttribute('data-exbpage'))) return false;
    if (/position:\s*fixed/.test(n.getAttribute('style') || '')) return true;
    try { return w.getComputedStyle(n).position === 'fixed'; } catch (e) { return false; }
  }
  if (typeof MutationObserver !== 'undefined' && d.body) {
    new MutationObserver(function (list) {
      list.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes, function (n) { if (isModuleOverlay(n)) { var o = n; o.style.visibility = 'hidden'; setTimeout(function () { var ok = false; if (o.parentNode === d.body && isModuleOverlay(o)) ok = toPage(o); if (!ok) o.style.visibility = ''; }, 0); } }); });
    }).observe(d.body, { childList: true });
  } else d.addEventListener('DOMContentLoaded', function () { if (typeof MutationObserver !== 'undefined') new MutationObserver(function (list) { list.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes, function (n) { if (isModuleOverlay(n)) { var o = n; setTimeout(function () { toPage(o); }, 0); } }); }); }).observe(d.body, { childList: true }); });
  w.EXBPAGE = { ids: IDS, toPage: toPage, closeAll: closeAll, version: 'V227' };
})(typeof window !== 'undefined' ? window : globalThis);
