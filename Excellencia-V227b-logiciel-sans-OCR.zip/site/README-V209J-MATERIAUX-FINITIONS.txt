V209j — Architecture : matériaux et finitions (cahier §5.2, P2)

Nouveau bouton « 🎨 Matériaux & finitions ».
- Bibliothèque : code, désignation, famille, unité, prix unitaire INDICATIF, perte %, fournisseur, performances, fiche technique (référence, lien http/https uniquement, dates, fin de validité), statut à valider / validé / obsolète ; doublon, import/export CSV (mise à jour par code, erreurs ligne par ligne, formules Excel neutralisées). Rien n'est prérempli.
- Spécifications par projet : matériau affecté à un poste d'un local du tableau des surfaces (V209e) ou d'une zone libre ; quantité = surface (dessinée, sinon cible) × coefficient, ou saisie, + perte. Coût indicatif, totaux par poste, famille, local ; alertes : matériau obsolète/non validé, fiche absente/périmée, sans prix (total signalé PARTIEL), local introuvable.
- Cahier des finitions par local (impression) et export CSV des spécifications.
Limites : coûts hors pose et aléas, ne remplacent ni devis ni métré ; surfaces murales via un coefficient saisi (pas de calcul depuis la 3D).
Installation serveur : supabase/migration-v209j-materiaux.sql ; collection exb_arch_mat -> arch_materiaux.
Fichiers : exb-v209-materiaux.js (nouveau) ; modifiés : index.html, sw.js (cache V209j), exb-db.js. Test : node tools/test-materiaux.js (19). tools/check.js : 782 réussis, mêmes 5 échecs de base.
Non fait : IA Architecte, règles IDS.
