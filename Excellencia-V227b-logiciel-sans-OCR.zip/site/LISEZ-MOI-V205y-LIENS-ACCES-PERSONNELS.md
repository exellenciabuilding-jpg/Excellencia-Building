# V205y — Liens d'accès personnels : le lien active le logiciel, puis « Première connexion »

Aucun SQL nouveau : tout repose sur `supabase/migration-v205v-codes-personnels.sql` (à exécuter une fois si ce n'est pas fait).

## Équipe › « 🔗 Espaces et liens d'accès » (nouveau tableau)
Tous les espaces (Comptable, Ingénieur, Architecte, Direction, RH, Magasinier, Chef de projet, Conducteur, Formateur) : saisir nom + e-mail → « 🔑 Lien + code » → message prêt (copier / WhatsApp) avec un lien personnel `…comptable.html?inv=CODE` et le code aléatoire propre à cette personne (code lié à son e-mail, voir V205v).

## Parcours de l'invité
1. Il ouvre son lien : le logiciel s'active **tout seul** avec son code (une tentative par ouverture ; sinon l'écran « code d'activation » reste disponible).
2. L'écran de connexion s'ouvre directement sur **« Première connexion »** : il crée son compte et choisit SON mot de passe.
3. Il rejoint l'entreprise avec la fonction prévue ; il apparaît dans « Membres ».

## Révocation en cas d'abus
« Retirer » (Membres) ou « Annuler » (Invitations en attente) : l'accès est coupé et le code révoqué automatiquement ; « 🔄 Nouveau code » pour en refaire un. Les autres invités ne sont pas touchés.

## L'ingénieur dans la liste de l'équipe
La fonction s'appelait « Bureau d'études » dans les menus (Inviter, Membres, écran d'accès) : on ne voyait pas « Ingénieur ». Elle s'appelle maintenant **« Ingénieur »** (valeur interne inchangée : `bureau_etudes`, espace /ingenieur).

## « Aucune licence associée à ce compte. Contactez l'administrateur. »
Un invité qui venait de créer son compte voyait ce message (fond bleu) : l'ancien circuit de synchronisation par compte (exb-sync.js, fonction serveur `ma_licence`) exigeait une licence rattachée à SON compte, alors qu'un membre d'équipe est couvert par la licence de l'ENTREPRISE. Corrigé : un membre d'une entreprise (base partagée active) sans licence « par compte » n'est plus bloqué. Un abonnement réellement suspendu ou expiré reste bloqué. Cas reproduit puis corrigé en test.

## Captures réelles
Voir `GUIDE-V205y-liens-acces-personnels.pdf` (à la racine de l'archive, partie 1).

## Fichiers modifiés
exb-equipe.js, exb-sync.js, exb-db.js, exb-license.js, exb-v205-connexion-espace.js, les 8 pages d'espace (elles transmettent `?inv=`), sw.js (cache), tools/check.js (contrôle des pages d'espace adapté).

## Tests
`node tools/check.js` : 761 OK, 0 échec · `e2e-connexion-espace.py` : 54 OK · `e2e-codes-personnels.py` : 15 OK.
