/* Excellencia Building V173 — Finances & comptabilité (module 15) : PAIE, BILAN COMPLET, immobilisations, stocks, opérations diverses.
 * S'ajoute à exb-compta.js (V165) et exb-compta-etats.js (V166) par leurs points d'extension. Aucune facture ni caisse existante n'est modifiée.
 *
 *  - PAIE : exb_paie_cfg (taux), exb_paie_runs (bulletins du mois, calcul brut → net). Lit le personnel existant (exb_hr : fiche approuvée, statut ≠ sorti/suspendu, salaire > 0).
 *    Brouillon modifiable (primes, retenues/avances) → « Valider » = écritures : D 661 brut + D 664 charges patronales / C 421 net + C 431 cotisations + C 447 impôt + C 425 avances.
 *    « Payer » = sortie de caisse liée (exb_cash, drapeau paie_run) : D 421 / C 571 ou 521. Pas de double charge : la sortie liée est portée au compte 421, jamais en 661.
 *  - TAUX : AUCUN taux légal n'est imposé. CNSS salarié, CNSS patronale et impôt sur salaire sont des POURCENTAGES SAISIS (0 par défaut) à valider avec la législation locale
 *    et votre comptable. L'impôt est un taux unique sur (brut − CNSS salarié) : ce n'est PAS le barème progressif de l'IPR.
 *  - OPÉRATIONS DIVERSES (exb_od) : écritures équilibrées (débit = crédit) pour l'ouverture (à-nouveaux : capital, immobilisations, stocks, emprunts, soldes antérieurs), apports, emprunts…
 *  - IMMOBILISATIONS (exb_immo) : amortissement linéaire mensuel CALCULÉ (D 681 / C 28x) ; écriture d'acquisition selon le mode choisi (déjà en ouverture, caisse, banque, reclassement d'une charge).
 *  - STOCKS (exb_stock_val) : valorisation saisie à une date → variation D 31 / C 603 (le stock de l'application n'a pas de prix : valeur déclarée, jamais inventée).
 *  - BILAN COMPLET : actif (immobilisations nettes, stocks, créances, trésorerie), passif (capitaux propres + résultat, dettes financières, dettes, trésorerie négative) ; contrôle actif = passif.
 *    Cumul depuis le début, par devise, sans conversion. Ce n'est PAS un bilan certifié ni une déclaration fiscale/sociale : à valider avec votre comptable.
 * Retrait : supprimer la balise <script src="exb-compta-paie.js"> (les données restent dans leurs clés ; les écritures associées disparaissent du journal). */
(function (w) {
  'use strict';
  var X = w.EXBCOMPTA && w.EXBCOMPTA._x; if (!X || w.EXBCOMPTA_PAIE) return;
  var d = w.document, K = { cfg: 'exb_paie_cfg', run: 'exb_paie_runs', od: 'exb_od', im: 'exb_immo', sv: 'exb_stock_val' }, r2 = X.r2, esc = X.esc, nf = X.nf, pn = X.pn;
  var DATE = /^\d{4}-\d{2}-\d{2}$/, YM = /^\d{4}-(0[1-9]|1[0-2])$/;
  var NEWACC = { '101': 'Capital', '106': 'Réserves', '111': 'Report à nouveau', '161': 'Emprunts et dettes financières', '24': 'Matériel, mobilier et installations', '284': 'Amortissements du matériel et mobilier',
    '31': 'Stocks de marchandises et matériaux', '425': 'Avances et acomptes au personnel', '421': 'Personnel — rémunérations dues', '431': 'Organismes sociaux (CNSS)', '447': 'État — impôts retenus sur salaires',
    '664': 'Charges sociales patronales', '681': 'Dotations aux amortissements', '603': 'Variation des stocks' };
  Object.keys(NEWACC).forEach(function (k) { X.ACC[k] = NEWACC[k]; });
  function accName(a) { return X.ACC[a] || ('Compte ' + a); }
  function closedSet() { var o = {}; (X.LD(X.K.cl, []) || []).forEach(function (r) { if (r && r.ym && !r.reopened) o[r.ym] = 1; }); return o; }
  function lastDay(ym) { var y = +ym.slice(0, 4), m = +ym.slice(5, 7); return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10); }
  function curN(c) { c = String(c || 'USD').toUpperCase(); return c === 'CDF' ? 'FC' : c; }
  function lock(date) { var ym = String(date || '').slice(0, 7); return closedSet()[ym] ? 'Le mois ' + ym + ' est clôturé : rouvrez-le (avec motif) avant d’y enregistrer.' : ''; }

  /* ---------------- PAIE ---------------- */
  function cfg() { var c = X.LD(K.cfg, {}) || {}; return { cnss_emp: Math.max(0, Math.min(100, pn(c.cnss_emp))), cnss_pat: Math.max(0, Math.min(100, pn(c.cnss_pat))), impot: Math.max(0, Math.min(100, pn(c.impot))), currency: curN(c.currency || 'USD') }; }
  function saveCfg(o) {
    var c = { cnss_emp: pn(o.cnss_emp), cnss_pat: pn(o.cnss_pat), impot: pn(o.impot), currency: curN(o.currency) };
    if ([c.cnss_emp, c.cnss_pat, c.impot].some(function (v) { return v < 0 || v > 100; })) return { error: 'Les taux doivent être compris entre 0 et 100 %.' };
    if (!X.SV(K.cfg, c)) return { error: 'Enregistrement impossible.' }; X.audit('paie.taux', 'cfg', c); return { ok: true };
  }
  function runs() { return (X.LD(K.run, []) || []).filter(function (r) { return r && r.id; }); }
  function employees() {
    return (X.LD('exb_hr', []) || []).filter(function (x) {
      if (!x || x.approval_status === 'REJETE') return false; if (!(x.approval_status === 'APPROUVE' || (!x.approval_status && x.matricule) || !x.approval_status)) return false;
      var st = String(x.status || 'Actif'); if (/^sorti|^suspend/i.test(st)) return false; return pn(x.salary) > 0;
    });
  }
  function calc(line, c) {
    var base = r2(pn(line.base)), pr = r2(pn(line.primes)), ret = r2(pn(line.retenues)), brut = r2(base + pr), ce = r2(brut * c.cnss_emp / 100), imp = r2((brut - ce) * c.impot / 100), cp = r2(brut * c.cnss_pat / 100);
    var net = r2(brut - ce - imp - ret); return Object.assign({}, line, { base: base, primes: pr, retenues: ret, brut: brut, cnss_emp: ce, impot: imp, cnss_pat: cp, net: net });
  }
  function totals(run) { var t = { brut: 0, cnss_emp: 0, cnss_pat: 0, impot: 0, retenues: 0, net: 0 }; run.lines.forEach(function (l) { Object.keys(t).forEach(function (k) { t[k] = r2(t[k] + (+l[k] || 0)); }); }); return t; }
  function createRun(ym) {
    if (!X.can('factures', 'ecrire') || !X.can('personnel', 'lire')) return { error: 'Droits insuffisants (factures en écriture et personnel en lecture).' };
    if (!YM.test(String(ym || ''))) return { error: 'Mois invalide (AAAA-MM).' };
    var m = lock(lastDay(ym)); if (m) return { error: m };
    var c = cfg(); if (runs().some(function (r) { return r.ym === ym && r.currency === c.currency && r.status !== 'annulée'; })) return { error: 'Une paie ' + ym + ' (' + c.currency + ') existe déjà : annulez-la d’abord (avec motif).' };
    var emp = employees(); if (!emp.length) return { error: 'Aucun employé actif avec un salaire dans le module Personnel.' };
    var run = { id: X.uid('PAIE'), no: 'PAIE-' + ym + '-' + c.currency, ym: ym, currency: c.currency, rates: { cnss_emp: c.cnss_emp, cnss_pat: c.cnss_pat, impot: c.impot }, status: 'brouillon', by: X.who(), at: new Date().toISOString(),
      lines: emp.map(function (e) { return calc({ emp: e.id, name: e.name, role: e.role || '', base: e.salary, primes: 0, retenues: 0 }, c); }) };
    var a = runs(); a.push(run); if (!X.SV(K.run, a)) return { error: 'Enregistrement impossible.' }; X.audit('paie.creation', run.no, { employes: run.lines.length }); return { run: run };
  }
  function getRun(id) { return runs().filter(function (r) { return r.id === id; })[0]; }
  function putRun(run) { var a = runs().map(function (r) { return r.id === run.id ? run : r; }); return X.SV(K.run, a); }
  function editLine(id, emp, o) {
    var r = getRun(id); if (!r) return { error: 'Paie introuvable.' }; if (r.status !== 'brouillon') return { error: 'Seul un brouillon est modifiable.' };
    var l = r.lines.filter(function (x) { return x.emp === emp; })[0]; if (!l) return { error: 'Employé introuvable dans cette paie.' };
    var pr = pn(o.primes), rt = pn(o.retenues); if (pr < 0 || rt < 0) return { error: 'Primes et retenues ne peuvent pas être négatives.' };
    var n = calc(Object.assign({}, l, { primes: pr, retenues: rt }), r.rates); if (n.net < 0) return { error: 'Le net à payer de ' + l.name + ' serait négatif.' };
    r.lines = r.lines.map(function (x) { return x.emp === emp ? n : x; }); if (!putRun(r)) return { error: 'Enregistrement impossible.' }; return { ok: true, line: n };
  }
  function validateRun(id) {
    var r = getRun(id); if (!r) return { error: 'Paie introuvable.' }; if (r.status !== 'brouillon') return { error: 'Déjà validée.' };
    var m = lock(lastDay(r.ym)); if (m) return { error: m };
    if (r.lines.some(function (l) { return l.net < 0; })) return { error: 'Un net à payer est négatif.' };
    r.status = 'validée'; r.validated_by = X.who(); r.validated_at = new Date().toISOString(); if (!putRun(r)) return { error: 'Enregistrement impossible.' };
    X.audit('paie.validation', r.no, totals(r)); return { ok: true };
  }
  function cancelRun(id, why) {
    var r = getRun(id); if (!r) return { error: 'Paie introuvable.' }; if (String(why || '').trim().length < 3) return { error: 'Le motif d’annulation est obligatoire.' };
    if (r.status === 'payée') return { error: 'Cette paie est payée : elle ne peut pas être annulée.' }; if (r.status === 'annulée') return { error: 'Déjà annulée.' };
    var m = lock(lastDay(r.ym)); if (m) return { error: m };
    r.status = 'annulée'; r.cancel_reason = String(why).trim(); r.cancel_by = X.who(); r.cancel_at = new Date().toISOString(); putRun(r); X.audit('paie.annulation', r.no, { motif: r.cancel_reason }); return { ok: true };
  }
  function payRun(id, date, method) {
    var r = getRun(id); if (!r) return { error: 'Paie introuvable.' }; if (r.status !== 'validée') return { error: r.status === 'payée' ? 'Déjà payée.' : 'Validez la paie avant de la payer.' };
    if (!DATE.test(String(date || ''))) return { error: 'Date de paiement invalide.' }; var m = lock(date); if (m) return { error: m };
    var net = totals(r).net; if (!(net > 0)) return { error: 'Rien à payer.' };
    var meth = /banque|bank|mobile|virement/i.test(String(method || '')) ? 'Banque' : 'Espèces', cid = X.uid('CSH');
    var rec = { id: cid, date: date, type: 'out', label: 'Paie ' + r.ym + ' — salaires nets', amount: net, method: meth, ref: r.no, cat: 'Salaires', currency: r.currency === 'FC' ? 'CDF' : r.currency, paie_run: r.id };
    var ok = false;
    try { if (typeof exbCash !== 'undefined' && Array.isArray(exbCash)) { exbCash.push(rec); if (typeof exbSave === 'function') { exbSave((w.EXB_ECO_KEYS || EXB_ECO_KEYS).cash, exbCash); ok = true; } } } catch (e) {}
    if (!ok) { var a = X.LD('exb_cash', []) || []; a.push(rec); ok = X.SV('exb_cash', a); }
    if (!ok) return { error: 'Enregistrement du paiement impossible.' };
    r.status = 'payée'; r.paid_date = date; r.cash_id = cid; r.paid_by = X.who(); putRun(r); X.audit('paie.paiement', r.no, { net: net, mode: meth }); return { ok: true, net: net };
  }
  /* écritures de paie */
  X.XT.entryFns.push(function (add) {
    runs().forEach(function (r) {
      if (r.status !== 'validée' && r.status !== 'payée') return; var t = totals(r), dt = lastDay(r.ym), c = r.currency;
      add(dt, 'PA', r.no, 'Paie ' + r.ym + ' — salaires bruts', c, [['661', t.brut, 0], ['664', t.cnss_pat, 0], ['421', 0, t.net], ['431', 0, r2(t.cnss_emp + t.cnss_pat)], ['447', 0, t.impot], ['425', 0, t.retenues]]);
    });
  });

  /* ---------------- OPÉRATIONS DIVERSES / OUVERTURE ---------------- */
  var OD_ACC = ['101', '106', '111', '161', '24', '284', '31', '411', '401', '421', '425', '431', '447', '4431', '4452', '521', '571'];
  function odList() { return (X.LD(K.od, []) || []).filter(function (o) { return o && o.id; }); }
  function addOd(o) {
    if (!X.can('factures', 'ecrire')) return { error: 'Droits insuffisants.' };
    var date = String(o.date || '').slice(0, 10); if (!DATE.test(date)) return { error: 'Date invalide (AAAA-MM-JJ).' }; var m = lock(date); if (m) return { error: m };
    if (!String(o.label || '').trim()) return { error: 'Le libellé est obligatoire.' };
    var lines = (o.lines || []).map(function (l) { return { acc: String(l.acc || '').trim(), d: r2(pn(l.d)), c: r2(pn(l.c)) }; }).filter(function (l) { return l.acc && (l.d || l.c); });
    if (lines.length < 2) return { error: 'Au moins deux lignes sont nécessaires.' };
    if (lines.some(function (l) { return l.d < 0 || l.c < 0 || (l.d && l.c); })) return { error: 'Chaque ligne a un montant au débit OU au crédit (positif).' };
    if (lines.some(function (l) { return !/^[1-5]\d{1,3}$/.test(l.acc); })) return { error: 'Seuls les comptes de bilan (classes 1 à 5) sont permis ici.' };
    var td = r2(lines.reduce(function (a, l) { return a + l.d; }, 0)), tc = r2(lines.reduce(function (a, l) { return a + l.c; }, 0));
    if (Math.abs(td - tc) > 0.004) return { error: 'Écriture déséquilibrée : débit ' + nf(td) + ' ≠ crédit ' + nf(tc) + '.' };
    var rec = { id: X.uid('OD'), jr: o.jr === 'AN' ? 'AN' : 'OD', date: date, label: String(o.label).trim().slice(0, 140), currency: curN(o.currency), lines: lines, status: 'actif', by: X.who(), at: new Date().toISOString() };
    var a = odList(); a.push(rec); if (!X.SV(K.od, a)) return { error: 'Enregistrement impossible.' }; X.audit('compta.od', rec.id, { libelle: rec.label, total: td }); return { rec: rec };
  }
  function cancelOd(id, why) {
    if (String(why || '').trim().length < 3) return { error: 'Le motif d’annulation est obligatoire.' };
    var a = odList(), r = a.filter(function (x) { return x.id === id; })[0]; if (!r || r.status === 'annulé') return { error: 'Écriture introuvable ou déjà annulée.' }; var m = lock(r.date); if (m) return { error: m };
    r.status = 'annulé'; r.cancel_reason = String(why).trim(); r.cancel_by = X.who(); X.SV(K.od, a); X.audit('compta.od.annulation', id, { motif: r.cancel_reason }); return { ok: true };
  }
  X.XT.entryFns.push(function (add) { odList().forEach(function (o) { if (o.status === 'annulé') return; add(o.date, o.jr, o.id, o.label, o.currency, o.lines.map(function (l) { return [l.acc, l.d, l.c]; })); }); });

  /* ---------------- IMMOBILISATIONS ---------------- */
  function imList() { return (X.LD(K.im, []) || []).filter(function (o) { return o && o.id; }); }
  function addImmo(o) {
    var date = String(o.date || '').slice(0, 10); if (!DATE.test(date)) return { error: 'Date d’acquisition invalide.' }; var m = lock(date); if (m) return { error: m };
    if (!String(o.label || '').trim()) return { error: 'La désignation est obligatoire.' }; var cost = r2(pn(o.cost)), life = Math.round(pn(o.life)), res = r2(pn(o.residual));
    if (!(cost > 0)) return { error: 'Valeur d’acquisition invalide.' }; if (!(life >= 1 && life <= 50)) return { error: 'Durée d’amortissement entre 1 et 50 ans.' }; if (res < 0 || res >= cost) return { error: 'La valeur résiduelle doit être ≥ 0 et inférieure à la valeur d’acquisition.' };
    var mode = ['ouverture', 'caisse', 'banque', 'reclasse'].indexOf(o.mode) >= 0 ? o.mode : 'ouverture'; if (mode === 'reclasse' && !/^6\d\d$/.test(String(o.from_acc || ''))) return { error: 'Choisissez le compte de charge à reclasser.' };
    var rec = { id: X.uid('IMM'), label: String(o.label).trim().slice(0, 120), date: date, cost: cost, life: life, residual: res, currency: curN(o.currency), mode: mode, from_acc: o.from_acc || '', status: 'actif', by: X.who(), at: new Date().toISOString() };
    var a = imList(); a.push(rec); if (!X.SV(K.im, a)) return { error: 'Enregistrement impossible.' }; X.audit('compta.immo', rec.id, { cout: cost }); return { rec: rec };
  }
  function cancelImmo(id, why) {
    if (String(why || '').trim().length < 3) return { error: 'Le motif est obligatoire.' }; var a = imList(), r = a.filter(function (x) { return x.id === id; })[0]; if (!r || r.status === 'annulé') return { error: 'Introuvable.' };
    r.status = 'annulé'; r.cancel_reason = String(why).trim(); X.SV(K.im, a); X.audit('compta.immo.annulation', id, {}); return { ok: true };
  }
  function schedule(im, upTo) { /* dotations mensuelles linéaires, 1er mois = mois d'acquisition, arrondi : dernière dotation = solde */
    var n = im.life * 12, base = r2(im.cost - im.residual), per = r2(base / n), out = [], cum = 0, y = +im.date.slice(0, 4), m = +im.date.slice(5, 7) - 1;
    for (var k = 0; k < n; k++) { var dt = lastDay(new Date(Date.UTC(y, m + k, 1)).toISOString().slice(0, 7)); if (dt > upTo) break; var amt = k === n - 1 ? r2(base - cum) : per; cum = r2(cum + amt); out.push({ date: dt, amount: amt, cum: cum }); }
    return out;
  }
  X.XT.entryFns.push(function (add) {
    var t = X.today();
    imList().forEach(function (im) {
      if (im.status === 'annulé') return; var cr = im.mode === 'caisse' ? '571' : im.mode === 'banque' ? '521' : im.mode === 'reclasse' ? im.from_acc : null;
      if (cr) add(im.date, 'OD', im.id, 'Acquisition — ' + im.label, im.currency, [['24', im.cost, 0], [cr, 0, im.cost]]);
      schedule(im, t).forEach(function (s) { add(s.date, 'OD', im.id, 'Dotation amortissement — ' + im.label, im.currency, [['681', s.amount, 0], ['284', 0, s.amount]]); });
    });
  });

  /* ---------------- VALORISATION DES STOCKS ---------------- */
  function svList() { return (X.LD(K.sv, []) || []).filter(function (o) { return o && o.id && o.status !== 'annulé'; }).sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; }); }
  function addStockVal(o) {
    var date = String(o.date || '').slice(0, 10); if (!DATE.test(date)) return { error: 'Date invalide.' }; var m = lock(date); if (m) return { error: m };
    var v = r2(pn(o.value)); if (v < 0) return { error: 'La valeur ne peut pas être négative.' }; var rec = { id: X.uid('SV'), date: date, value: v, currency: curN(o.currency), note: String(o.note || '').slice(0, 140), status: 'actif', by: X.who(), at: new Date().toISOString() };
    var a = X.LD(K.sv, []) || []; a.push(rec); if (!X.SV(K.sv, a)) return { error: 'Enregistrement impossible.' }; X.audit('compta.stock.valeur', rec.id, { valeur: v }); return { rec: rec };
  }
  function cancelStockVal(id, why) {
    if (String(why || '').trim().length < 3) return { error: 'Le motif est obligatoire.' }; var a = X.LD(K.sv, []) || [], r = a.filter(function (x) { return x.id === id; })[0]; if (!r || r.status === 'annulé') return { error: 'Introuvable.' };
    var m = lock(r.date); if (m) return { error: m }; r.status = 'annulé'; r.cancel_reason = String(why).trim(); X.SV(K.sv, a); X.audit('compta.stock.annulation', id, {}); return { ok: true };
  }
  X.XT.entryFns.push(function (add) {
    var prev = {}; odList().forEach(function (o) { if (o.status === 'annulé') return; o.lines.forEach(function (l) { if (/^31/.test(l.acc)) prev[o.currency] = r2((prev[o.currency] || 0) + l.d - l.c); }); });
    svList().forEach(function (s) { var p = prev[s.currency] || 0, delta = r2(s.value - p); prev[s.currency] = s.value; if (Math.abs(delta) < 0.005) return; add(s.date, 'OD', s.id, 'Variation de stock — valorisation ' + s.date, s.currency, delta > 0 ? [['31', delta, 0], ['603', 0, delta]] : [['603', -delta, 0], ['31', 0, -delta]]); });
  });

  /* ---------------- BILAN COMPLET ---------------- */
  function bilanComplet(L) {
    var m = {}; L.forEach(function (e) { var a = m[e.acc] || (m[e.acc] = { d: 0, c: 0 }); a.d = r2(a.d + e.d); a.c = r2(a.c + e.c); });
    var G = { immo: [], stock: [], crea: [], treA: [], cp: [], dfin: [], dcir: [], treP: [] }, p = 0, ch = 0;
    Object.keys(m).sort().forEach(function (k) {
      var net = r2(m[k].d - m[k].c), c0 = k.charAt(0), c2 = k.slice(0, 2); if (c0 === '6') { ch = r2(ch + net); return; } if (c0 === '7') { p = r2(p - net); return; } if (Math.abs(net) < 0.005) return;
      var it = { acc: k, nom: accName(k), amount: net };
      if (c0 === '2') G.immo.push(it); else if (c0 === '3') G.stock.push(it);
      else if (c0 === '4') { if (net > 0) G.crea.push(it); else G.dcir.push({ acc: k, nom: accName(k), amount: -net }); }
      else if (c0 === '5') { if (net > 0) G.treA.push(it); else G.treP.push({ acc: k, nom: accName(k), amount: -net }); }
      else if (c0 === '1') { var o = { acc: k, nom: accName(k), amount: -net }; if (c2 === '16' || c2 === '17') G.dfin.push(o); else G.cp.push(o); }
    });
    var res = r2(p - ch); G.cp.push({ acc: 'RES', nom: res >= 0 ? 'Résultat cumulé (bénéfice)' : 'Résultat cumulé (perte)', amount: res });
    function sum(a) { return r2(a.reduce(function (s, x) { return s + x.amount; }, 0)); }
    var T = { immo: sum(G.immo), stock: sum(G.stock), crea: sum(G.crea), treA: sum(G.treA), cp: sum(G.cp), dfin: sum(G.dfin), dcir: sum(G.dcir), treP: sum(G.treP) };
    T.actif = r2(T.immo + T.stock + T.crea + T.treA); T.passif = r2(T.cp + T.dfin + T.dcir + T.treP); return { G: G, T: T, resultat: res, equilibre: Math.abs(T.actif - T.passif) < 0.01 };
  }

  /* ---------------- interface ---------------- */
  var S = { run: null, form: null, sub: 'od', bcur: '', bto: '' };
  function sel(id, arr, cur, style) { return '<select id="' + id + '" style="padding:5px;' + (style || '') + '">' + arr.map(function (x) { var v = Array.isArray(x) ? x[0] : x, l = Array.isArray(x) ? x[1] : x; return '<option value="' + esc(v) + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('') + '</select>'; }
  function q(id) { return d.getElementById(id); }
  var STC = { brouillon: '#92400e', 'validée': '#1d4ed8', 'payée': '#15803d', 'annulée': '#64748b' };

  function tabPaie() {
    var c = cfg(), all = runs().slice().reverse(), run = S.run ? getRun(S.run) : null;
    var card = '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:8px;margin:6px 0"><b>Paramètres de paie</b> <small style="color:#64748b">(à valider avec la législation locale et votre comptable — 0 par défaut)</small><p>CNSS salarié % ' + X.inp('pc_e', c.cnss_emp, '0', 'width:60px') + ' CNSS patronale % ' + X.inp('pc_p', c.cnss_pat, '0', 'width:60px') + ' Impôt sur salaire % ' + X.inp('pc_i', c.impot, '0', 'width:60px') + ' Devise ' + sel('pc_c', ['USD', 'FC'], c.currency) + ' ' + X.btn('pc_ok', 'Enregistrer') + '</p><small style="color:#64748b">Impôt = taux unique sur (brut − CNSS salarié), pas le barème progressif de l’IPR.</small></div>';
    if (!run) {
      var new_ = '<p>Mois ' + X.inp('pn_ym', X.today().slice(0, 7), 'AAAA-MM', 'width:90px') + ' ' + X.btn('pn_new', '➕ Préparer la paie du mois') + ' <small style="color:#64748b">' + employees().length + ' employé(s) avec salaire</small></p>';
      var rows = all.map(function (r) { var t = totals(r); return '<tr>' + X.td(esc(r.no)) + X.td('<span style="color:' + STC[r.status] + '">' + r.status + '</span>') + X.td(r.lines.length, 'right') + X.td(nf(t.brut), 'right') + X.td(nf(t.net), 'right') + X.td('<button class="pn_open" data-id="' + esc(r.id) + '" type="button">Ouvrir</button>') + '</tr>'; });
      return card + new_ + (rows.length ? X.table(['Paie', 'Statut', 'Employés', 'Brut', 'Net à payer', ''], rows) : '<p style="color:#64748b">Aucune paie préparée.</p>');
    }
    var t = totals(run), ro = run.status !== 'brouillon', form = '';
    if (S.form && S.form.type === 'pay') form = '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Payer ' + nf(t.net) + ' ' + esc(run.currency) + '</b><p>Date ' + X.inp('pp_d', X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Mode ' + sel('pp_m', ['Espèces', 'Banque'], 'Espèces') + '</p><small>Une sortie de caisse liée est créée (porte le compte 421, jamais 661) : ne la saisissez pas une seconde fois en caisse.</small><p>' + X.btn('pp_ok', 'Confirmer le paiement') + X.btn('pp_no', 'Retour') + '</p></div>';
    if (S.form && S.form.type === 'cx') form = '<div style="border:1px solid #fca5a5;border-radius:8px;padding:10px;margin:8px 0"><b>Annuler ' + esc(run.no) + '</b><p>' + X.inp('px_why', '', 'Motif obligatoire', 'width:100%') + '</p>' + X.btn('px_ok', 'Confirmer') + X.btn('px_no', 'Retour') + '</div>';
    var rows2 = run.lines.map(function (l) { return '<tr>' + X.td(esc(l.name) + '<br><small>' + esc(l.role) + '</small>') + X.td(nf(l.base), 'right') + X.td(ro ? nf(l.primes) : X.inp('pl_p_' + l.emp, l.primes, '0', 'width:70px'), 'right') + X.td(nf(l.brut), 'right') + X.td(nf(l.cnss_emp), 'right') + X.td(nf(l.impot), 'right') + X.td(ro ? nf(l.retenues) : X.inp('pl_r_' + l.emp, l.retenues, '0', 'width:70px'), 'right') + X.td('<b>' + nf(l.net) + '</b>', 'right') + '</tr>'; });
    var foot = '<tfoot><tr style="font-weight:700">' + X.td('Totaux') + X.td('') + X.td('') + X.td(nf(t.brut), 'right') + X.td(nf(t.cnss_emp), 'right') + X.td(nf(t.impot), 'right') + X.td(nf(t.retenues), 'right') + X.td(nf(t.net), 'right') + '</tr></tfoot>';
    return '<p><b>' + esc(run.no) + '</b> — <span style="color:' + STC[run.status] + '">' + run.status + '</span> — CNSS patronale (charge) : ' + nf(t.cnss_pat) + ' ' + esc(run.currency) + '</p>' + form +
      X.table(['Employé', 'Base', 'Primes', 'Brut', 'CNSS sal.', 'Impôt', 'Retenues / avances', 'Net'], rows2, foot) + '<p>' + (run.status === 'brouillon' ? X.btn('pl_save', '💾 Recalculer') + X.btn('pl_val', '✅ Valider (écritures)') : '') + (run.status === 'validée' ? X.btn('pl_pay', '💵 Payer') : '') + (run.status !== 'payée' && run.status !== 'annulée' ? X.btn('pl_cx', 'Annuler') : '') + X.btn('pl_csv', '⬇ CSV') + X.btn('pl_pdf', '🖨 PDF') + X.btn('pl_back', '← Retour') + '</p>' +
      '<p style="font-size:12px;color:#64748b">Validation : D 661 brut + D 664 CNSS patronale / C 421 net, C 431 cotisations, C 447 impôt, C 425 avances. Les taux sont figés à la création de la paie.</p>';
  }
  function bindPaie(o) {
    var msg = function (m) { X.S.msg = m; X.render(); };
    X.on('pc_ok', function () { var r = saveCfg({ cnss_emp: q('pc_e').value, cnss_pat: q('pc_p').value, impot: q('pc_i').value, currency: q('pc_c').value }); msg(r.error || 'Paramètres enregistrés (appliqués aux nouvelles paies).'); });
    X.on('pn_new', function () { var r = createRun(q('pn_ym').value); if (r.error) return msg(r.error); S.run = r.run.id; msg('Paie ' + r.run.no + ' préparée.'); });
    Array.prototype.forEach.call(o.querySelectorAll('.pn_open'), function (b) { b.onclick = function () { S.run = b.getAttribute('data-id'); S.form = null; X.render(); }; });
    X.on('pl_back', function () { S.run = null; S.form = null; X.render(); });
    var save = function () { var run = getRun(S.run); if (!run || run.status !== 'brouillon') return null; for (var i = 0; i < run.lines.length; i++) { var l = run.lines[i], e = q('pl_p_' + l.emp), r = q('pl_r_' + l.emp); if (!e) continue; var res = editLine(run.id, l.emp, { primes: e.value, retenues: r.value }); if (res.error) return res; } return { ok: true }; };
    X.on('pl_save', function () { var r = save(); msg(r && r.error ? r.error : 'Recalculé.'); });
    X.on('pl_val', async function () { var r = save(); if (r && r.error) return msg(r.error); if (!(await w.exbConfirm('Valider cette paie ? Les écritures comptables seront générées.'))) return; var v = validateRun(S.run); msg(v.error || 'Paie validée.'); });
    X.on('pl_pay', function () { S.form = { type: 'pay' }; X.render(); }); X.on('pp_no', function () { S.form = null; X.render(); });
    X.on('pp_ok', function () { var r = payRun(S.run, q('pp_d').value, q('pp_m').value); if (!r.error) S.form = null; msg(r.error || 'Paiement enregistré : ' + nf(r.net) + '.'); });
    X.on('pl_cx', function () { S.form = { type: 'cx' }; X.render(); }); X.on('px_no', function () { S.form = null; X.render(); });
    X.on('px_ok', function () { var r = cancelRun(S.run, q('px_why').value); if (!r.error) S.form = null; msg(r.error || 'Paie annulée.'); });
    /* V178 : état de paie (période) en PDF de marque — en-tête société, QR de vérification public */
    X.on('pl_pdf', function () {
      var run = getRun(S.run); if (!run) return;
      if (!w.EXBRapport) { X.say('Module d’export PDF indisponible.', 'error'); return; }
      var t = totals(run), cur = esc(run.currency);
      var rows = run.lines.map(function (l) { return '<tr>' + X.td(esc(l.name) + '<br><small>' + esc(l.role || '') + '</small>') + X.td(nf(l.base), 'right') + X.td(nf(l.primes), 'right') + X.td(nf(l.brut), 'right') + X.td(nf(l.cnss_emp), 'right') + X.td(nf(l.impot), 'right') + X.td(nf(l.retenues), 'right') + X.td('<b>' + nf(l.net) + '</b>', 'right') + X.td(nf(l.cnss_pat), 'right') + '</tr>'; });
      var foot = '<tfoot><tr style="font-weight:700">' + X.td('Totaux') + X.td('') + X.td('') + X.td(nf(t.brut), 'right') + X.td(nf(t.cnss_emp), 'right') + X.td(nf(t.impot), 'right') + X.td(nf(t.retenues), 'right') + X.td(nf(t.net), 'right') + X.td(nf(t.cnss_pat), 'right') + '</tr></tfoot>';
      X.audit('paie.pdf', run.no, {});
      w.EXBRapport.print('État de paie ' + run.no, { prefix: 'PAI', sousTitre: 'Période ' + run.ym + ' · statut ' + run.status, meta: [['Paie', run.no], ['Période', run.ym], ['Statut', run.status], ['Salariés', String(run.lines.length)], ['Net à payer', nf(t.net) + ' ' + run.currency], ['CNSS patronale', nf(t.cnss_pat) + ' ' + run.currency]], html: X.table(['Employé', 'Base', 'Primes', 'Brut', 'CNSS sal.', 'Impôt', 'Retenues / avances', 'Net', 'CNSS patr.'], rows, foot), note: 'Montants en ' + run.currency + '. Taux figés à la création de la paie ; à valider avec le comptable.', paysage: true });
    });
    X.on('pl_csv', function () {
      var run = getRun(S.run); if (!run) return; var L = [['Employe', 'Base', 'Primes', 'Brut', 'CNSS salarie', 'Impot', 'Retenues', 'Net', 'CNSS patronale'].map(X.csvCell).join(';')];
      run.lines.forEach(function (l) { L.push([l.name, l.base, l.primes, l.brut, l.cnss_emp, l.impot, l.retenues, l.net, l.cnss_pat].map(X.csvCell).join(';')); });
      var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + L.join('\r\n')], { type: 'text/csv;charset=utf-8' })); a.download = 'paie-' + run.ym + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); X.audit('paie.export', run.no, {});
    });
  }

  function tabBilan() {
    var cs = X.curOpts(), cur = S.bcur && cs.indexOf(S.bcur) >= 0 ? S.bcur : cs[0], to = S.bto, L = X.entries().filter(function (e) { return e.cur === cur && (!to || e.date <= to); }), B = bilanComplet(L);
    var bar = '<p>Devise ' + sel('bc_cur', cs, cur) + ' Au ' + X.inp('bc_to', to, 'AAAA-MM-JJ', 'width:110px') + ' ' + X.btn('bc_csv', '⬇ CSV') + X.btn('bc_pdf', '🖨 PDF') + '</p>';
    function grp(title, arr, tot, neg) { if (!arr.length) return ''; return '<tr style="background:#f8fafc;font-weight:600">' + X.td(title) + X.td(nf(tot), 'right') + '</tr>' + arr.map(function (x) { return '<tr>' + X.td('&nbsp;&nbsp;' + x.acc + ' ' + esc(x.nom)) + X.td(nf(x.amount), 'right') + '</tr>'; }).join(''); }
    function box(h, rows, tot) { return X.table([h, ''], [rows], '<tfoot><tr style="font-weight:700">' + X.td('Total') + X.td(nf(tot), 'right') + '</tr></tfoot>'); }
    var G = B.G, T = B.T;
    S._bilPdf = { cur: cur, to: to, ok: B.equilibre, ta: T.actif, tp: T.passif, html: '<h2>Bilan au ' + esc(to || X.today()) + ' (cumul)</h2>' + box('ACTIF', grp('Immobilisations (nettes d’amortissements)', G.immo, T.immo) + grp('Stocks', G.stock, T.stock) + grp('Créances', G.crea, T.crea) + grp('Trésorerie', G.treA, T.treA), T.actif) +
      box('PASSIF', grp('Capitaux propres (dont résultat)', G.cp, T.cp) + grp('Dettes financières', G.dfin, T.dfin) + grp('Dettes (fournisseurs, personnel, État, organismes sociaux)', G.dcir, T.dcir) + grp('Trésorerie passive (découvert)', G.treP, T.treP), T.passif) };   /* V178 : contenu du PDF */
    return bar + '<p style="padding:6px;border-radius:6px;background:' + (B.equilibre ? '#e6f6ea' : '#fde8e8') + '">' + (B.equilibre ? '✅ Actif = passif' : '⛔ Actif ≠ passif : journal déséquilibré') + ' — ' + nf(T.actif) + ' / ' + nf(T.passif) + ' ' + esc(cur) + '</p>' +
      '<h4>Bilan au ' + esc(to || X.today()) + ' (cumul)</h4>' + box('ACTIF', grp('Immobilisations (nettes d’amortissements)', G.immo, T.immo) + grp('Stocks', G.stock, T.stock) + grp('Créances', G.crea, T.crea) + grp('Trésorerie', G.treA, T.treA), T.actif) +
      box('PASSIF', grp('Capitaux propres (dont résultat)', G.cp, T.cp) + grp('Dettes financières', G.dfin, T.dfin) + grp('Dettes (fournisseurs, personnel, État, organismes sociaux)', G.dcir, T.dcir) + grp('Trésorerie passive (découvert)', G.treP, T.treP), T.passif) +
      '<p style="font-size:12px;color:#64748b">Calculé depuis le journal (factures, caisse, paie, immobilisations, valorisations de stock, opérations diverses/ouverture). Cumul depuis le début, par devise, sans conversion. Non certifié ; à valider avec votre comptable. Les soldes d’ouverture se saisissent dans l’onglet « Ouverture & immos ».</p>';
  }
  function bindBilan() {
    var c = q('bc_cur'); if (c) c.onchange = function () { S.bcur = c.value; X.render(); }; var t = q('bc_to'); if (t) t.onchange = function () { S.bto = DATE.test(t.value) ? t.value : ''; X.render(); };
    X.on('bc_pdf', function () {
      var P = S._bilPdf; if (!P) return;
      if (!w.EXBRapport) { X.say('Module d’export PDF indisponible.', 'error'); return; }
      X.audit('compta.bilan.pdf', P.cur, {});
      w.EXBRapport.print('Bilan complet', { prefix: 'BIL', sousTitre: 'Devise ' + P.cur + ' · au ' + (P.to || X.today()), meta: [['Total actif', nf(P.ta) + ' ' + P.cur], ['Total passif', nf(P.tp) + ' ' + P.cur], ['Actif = passif', P.ok ? 'oui' : 'NON']], html: P.html, note: 'Calculé depuis le journal, par devise, sans conversion. Non certifié ; à valider avec le comptable.' });
    });
    X.on('bc_csv', function () {
      var cs = X.curOpts(), cur = S.bcur && cs.indexOf(S.bcur) >= 0 ? S.bcur : cs[0], B = bilanComplet(X.entries().filter(function (e) { return e.cur === cur && (!S.bto || e.date <= S.bto); })), L = [['Poste', 'Compte', 'Intitule', 'Montant', 'Devise'].map(X.csvCell).join(';')];
      [['Immobilisations nettes', B.G.immo], ['Stocks', B.G.stock], ['Creances', B.G.crea], ['Tresorerie actif', B.G.treA], ['Capitaux propres', B.G.cp], ['Dettes financieres', B.G.dfin], ['Dettes', B.G.dcir], ['Tresorerie passif', B.G.treP]].forEach(function (g) { g[1].forEach(function (x) { L.push([g[0], x.acc, x.nom, x.amount, cur].map(X.csvCell).join(';')); }); });
      L.push(['Total actif', '', '', B.T.actif, cur].map(X.csvCell).join(';')); L.push(['Total passif', '', '', B.T.passif, cur].map(X.csvCell).join(';'));
      var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + L.join('\r\n')], { type: 'text/csv;charset=utf-8' })); a.download = 'bilan-complet-' + X.today() + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); X.audit('compta.bilan.export', cur, {});
    });
  }

  function tabOd() {
    var f = S.form || {}, cs = X.curOpts(), accs = OD_ACC.map(function (a) { return [a, a + ' ' + accName(a)]; });
    var rowsF = ''; for (var k = 0; k < 6; k++) rowsF += '<p style="margin:3px 0">' + sel('od_a' + k, [['', '— compte —']].concat(accs), (f.lines && f.lines[k] || {}).acc || '', 'width:260px') + ' Débit ' + X.inp('od_d' + k, (f.lines && f.lines[k] || {}).d || '', '', 'width:90px') + ' Crédit ' + X.inp('od_c' + k, (f.lines && f.lines[k] || {}).c || '', '', 'width:90px') + '</p>';
    var od = '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:8px;margin:6px 0"><b>Écriture d’ouverture / opération diverse</b><p>Type ' + sel('od_jr', [['AN', 'Ouverture (à-nouveaux)'], ['OD', 'Opération diverse (apport, emprunt…)']], f.jr || 'AN') + ' Date ' + X.inp('od_dt', f.date || X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Devise ' + sel('od_cu', ['USD', 'FC'], f.currency || cs[0]) + ' ' + X.inp('od_lb', f.label || '', 'Libellé (ex. Ouverture au 01/01)', 'width:230px') + '</p>' + rowsF + '<p>' + X.btn('od_ok', 'Enregistrer l’écriture') + ' <small style="color:#64748b">Débit = crédit obligatoire. Ne ressaisissez pas ici des factures ou paiements déjà dans l’application.</small></p></div>';
    var list = odList().slice().reverse(), odT = list.length ? X.table(['Date', 'Type', 'Libellé', 'Montant', ''], list.map(function (o) { var tt = o.lines.reduce(function (a, l) { return a + l.d; }, 0); return '<tr style="' + (o.status === 'annulé' ? 'opacity:.55;text-decoration:line-through' : '') + '">' + X.td(esc(o.date)) + X.td(o.jr) + X.td(esc(o.label)) + X.td(nf(tt) + ' ' + esc(o.currency), 'right') + X.td(o.status === 'annulé' ? 'annulé' : '<button class="od_x" data-id="' + esc(o.id) + '" type="button">Annuler</button>') + '</tr>'; })) : '<p style="color:#64748b">Aucune écriture.</p>';
    var im = '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:8px;margin:10px 0"><b>Immobilisation (amortissement linéaire mensuel)</b><p>' + X.inp('im_lb', '', 'Désignation', 'width:170px') + ' ' + X.inp('im_dt', X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Coût ' + X.inp('im_co', '', '0', 'width:90px') + ' Durée (ans) ' + X.inp('im_li', '5', '5', 'width:50px') + ' Résiduel ' + X.inp('im_re', '0', '0', 'width:70px') + ' ' + sel('im_cu', ['USD', 'FC'], cs[0]) + '</p><p>Acquisition : ' + sel('im_mo', [['ouverture', 'déjà dans l’ouverture (aucune écriture)'], ['caisse', 'payée en espèces'], ['banque', 'payée par banque'], ['reclasse', 'déjà saisie comme charge (reclasser)']], 'ouverture') + ' ' + sel('im_fa', ['601', '604', '613', '616', '618', '658'], '658') + ' ' + X.btn('im_ok', 'Ajouter') + '</p></div>';
    var imL = imList(), imT = imL.length ? X.table(['Désignation', 'Acquisition', 'Coût', 'Durée', 'Amorti à ce jour', 'VNC', ''], imL.map(function (m) { var cum = (schedule(m, X.today()).slice(-1)[0] || { cum: 0 }).cum; return '<tr style="' + (m.status === 'annulé' ? 'opacity:.55;text-decoration:line-through' : '') + '">' + X.td(esc(m.label)) + X.td(esc(m.date) + '<br><small>' + esc(m.mode) + '</small>') + X.td(nf(m.cost) + ' ' + esc(m.currency), 'right') + X.td(m.life + ' ans') + X.td(nf(cum), 'right') + X.td(nf(m.cost - cum), 'right') + X.td(m.status === 'annulé' ? '' : '<button class="im_x" data-id="' + esc(m.id) + '" type="button">Annuler</button>') + '</tr>'; })) : '';
    var sv = '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:8px;margin:10px 0"><b>Valorisation du stock</b> <small style="color:#64748b">(valeur déclarée ; le stock de l’application n’a pas de prix)</small><p>' + X.inp('sv_dt', X.today(), 'AAAA-MM-JJ', 'width:110px') + ' Valeur ' + X.inp('sv_va', '', '0', 'width:100px') + ' ' + sel('sv_cu', ['USD', 'FC'], cs[0]) + ' ' + X.inp('sv_no', '', 'Note (inventaire du…)', 'width:180px') + X.btn('sv_ok', 'Enregistrer') + '</p></div>';
    var svL = X.LD(K.sv, []).slice().reverse(), svT = svL.length ? X.table(['Date', 'Valeur', 'Note', ''], svL.map(function (s) { return '<tr style="' + (s.status === 'annulé' ? 'opacity:.55;text-decoration:line-through' : '') + '">' + X.td(esc(s.date)) + X.td(nf(s.value) + ' ' + esc(s.currency), 'right') + X.td(esc(s.note)) + X.td(s.status === 'annulé' ? '' : '<button class="sv_x" data-id="' + esc(s.id) + '" type="button">Annuler</button>') + '</tr>'; })) : '';
    return od + odT + im + imT + sv + svT;
  }
  function bindOd(o) {
    var msg = function (m) { X.S.msg = m; X.render(); };
    X.on('od_ok', function () {
      var lines = []; for (var k = 0; k < 6; k++) lines.push({ acc: q('od_a' + k).value, d: q('od_d' + k).value, c: q('od_c' + k).value });
      var form = { jr: q('od_jr').value, date: q('od_dt').value, currency: q('od_cu').value, label: q('od_lb').value, lines: lines }, r = addOd(form); if (r.error) { S.form = form; return msg(r.error); } S.form = null; msg('Écriture enregistrée.');
    });
    X.on('im_ok', function () { var r = addImmo({ label: q('im_lb').value, date: q('im_dt').value, cost: q('im_co').value, life: q('im_li').value, residual: q('im_re').value, currency: q('im_cu').value, mode: q('im_mo').value, from_acc: q('im_fa').value }); msg(r.error || 'Immobilisation ajoutée : amortissement calculé automatiquement.'); });
    X.on('sv_ok', function () { var r = addStockVal({ date: q('sv_dt').value, value: q('sv_va').value, currency: q('sv_cu').value, note: q('sv_no').value }); msg(r.error || 'Valorisation enregistrée.'); });
    [['od_x', cancelOd], ['im_x', cancelImmo], ['sv_x', cancelStockVal]].forEach(function (p) { Array.prototype.forEach.call(o.querySelectorAll('.' + p[0]), function (b) { b.onclick = async function () { var why = await w.exbPrompt('Motif de l’annulation :', ''); if (why == null) return; var r = p[1](b.getAttribute('data-id'), why); msg(r.error || 'Annulé.'); }; }); });
  }

  X.XT.tabs.push({ id: 'paie', label: '👥 Paie', html: tabPaie }, { id: 'bilanc', label: '🏛 Bilan complet', html: tabBilan }, { id: 'od', label: '🧱 Ouverture & immos', html: tabOd });
  X.XT.bind.push(function (o) { var t = X.S.tab; if (t === 'paie') bindPaie(o); else if (t === 'bilanc') bindBilan(); else if (t === 'od') bindOd(o); });
  w.EXBCOMPTA_PAIE = { version: 1, cfg: cfg, saveCfg: saveCfg, employees: employees, createRun: createRun, editLine: editLine, validateRun: validateRun, payRun: payRun, cancelRun: cancelRun, getRun: getRun, totals: totals, addOd: addOd, cancelOd: cancelOd, addImmo: addImmo, schedule: schedule, addStockVal: addStockVal, bilanComplet: bilanComplet };
})(window);
