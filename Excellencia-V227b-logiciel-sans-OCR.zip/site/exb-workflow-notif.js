/* Excellencia Building — NOTIFICATIONS DU WORKFLOW (v1.3 du Workflow).
 * Prévient l'approbateur attendu, sans le serveur de messagerie : chaque appareil regarde les dossiers qu'il connaît (copie locale,
 * rafraîchie par la synchronisation du Workflow serveur) et signale ce qui est NOUVEAU pour la personne connectée :
 *   · « à valider » : un dossier vient d'arriver à son étape (ou revient après correction) → toast + ligne dans la cloche 🔔 + carillon,
 *     et pastille « ✅ Workflow (n) » dans le menu ;
 *   · « suites » : à l'initiateur, quand son dossier est validé, refusé ou renvoyé pour correction ;
 *   · « échéance » : rappel (échéance demain) ou retard, une fois par jour et par dossier.
 * Chaque signal n'est donné qu'une fois (mémoire locale exb_wf_notif:<organisation>:<personne>). À la toute première ouverture sur un appareil,
 * un seul message de synthèse est affiché (pas de rafale pour l'existant).
 * Limite : la notification arrive tant que l'application est ouverte ou à sa prochaine ouverture ; elle ne réveille pas un téléphone fermé
 * et ne passe pas par WhatsApp / e-mail. Entre deux comptes différents, elle suppose le Workflow serveur (sinon les dossiers ne se partagent pas).
 * Pour retirer : supprimer la balise <script src="exb-workflow-notif.js">. */
(function (w, d) {
  'use strict';
  if (w.EXBWFN) return;
  var MAXTOAST = 3;

  /* ============================ MOTEUR PUR ============================ */
  function day(t) { return String(t || '').slice(0, 10); }
  function fr(s) { return s ? String(s).slice(0, 10).split('-').reverse().join('/') : ''; }
  function names(list) { return (list || []).map(function (a) { return (a && (a.name || a.role)) || '?'; }).join(', '); }
  /* clé d'un signal : change quand le dossier change d'étape / de version, donc un nouveau tour = un nouveau signal */
  function kTask(x) { return 'T:' + x.id + ':v' + x.version + ':s' + x.cur; }
  function kOutcome(x) { return 'O:' + x.id + ':v' + x.version + ':' + x.status; }
  function kDue(x, today) { return 'E:' + x.id + ':' + today; }
  /* À partir des dossiers « à valider par moi », « initiés par moi » et des échéances, liste des signaux pas encore vus.
   * in : { mine:[dossier], initiated:[dossier], due:[{id,etat,jours}], today, seen:{clé:ts} } → { items:[{k,kind,id,no,titre,text,type}] } */
  function collect(o) {
    var seen = o.seen || {}, items = [], today = o.today, dueById = {};
    (o.due || []).forEach(function (e) { dueById[e.id] = e; });
    (o.mine || []).forEach(function (x) {
      var s = x.steps && x.steps[x.cur], k = kTask(x);
      if (!seen[k]) items.push({ k: k, kind: 'task', id: x.id, no: x.no, titre: x.titre, type: 'info',
        text: x.no + ' « ' + x.titre + ' » attend votre validation' + (s ? ' (étape ' + (x.cur + 1) + '/' + x.steps.length + ' : ' + s.nom + ')' : '') + (x.echeance ? ', avant le ' + fr(x.echeance) : '') + (x.version > 1 ? ' — corrigé et soumis à nouveau' : '') + '.' });
      var e = dueById[x.id];
      if (e && !seen[kDue(x, today)]) items.push({ k: kDue(x, today), kind: 'due', id: x.id, no: x.no, titre: x.titre, type: 'warn',
        text: e.etat === 'retard' ? '⏰ ' + x.no + ' « ' + x.titre + ' » : validation en retard de ' + e.jours + ' jour(s).' : '⏰ ' + x.no + ' « ' + x.titre + ' » : échéance de validation ' + (e.jours <= 0 ? 'aujourd\'hui' : 'demain') + '.' });
    });
    (o.initiated || []).forEach(function (x) {
      if (['valide', 'refuse', 'retourne', 'annule'].indexOf(x.status) < 0) return;
      var k = kOutcome(x); if (seen[k]) return;
      var last = (x.history || []).slice().reverse().filter(function (h) { return h.action === 'refuser' || h.action === 'corriger' || h.action === 'valide' || h.action === 'annule'; })[0] || {};
      var by = last.acteur ? ' par ' + last.acteur : '';
      var tx = { valide: '✅ ' + x.no + ' « ' + x.titre + ' » est validé.', refuse: '⛔ ' + x.no + ' « ' + x.titre + ' » a été refusé' + by + (last.motif ? ' : « ' + last.motif + ' »' : '') + '.',
        retourne: '↩ ' + x.no + ' « ' + x.titre + ' » est à corriger' + by + (last.motif ? ' : « ' + last.motif + ' »' : '') + '.', annule: '🚫 ' + x.no + ' « ' + x.titre + ' » a été annulé.' }[x.status];
      items.push({ k: k, kind: 'outcome', id: x.id, no: x.no, titre: x.titre, type: x.status === 'valide' ? 'success' : x.status === 'annule' ? 'info' : 'warn', text: tx });
    });
    return { items: items };
  }
  /* mémoire : on garde les clés des 90 derniers jours et au plus 600 */
  function prune(seen, nowMs) {
    var keys = Object.keys(seen).filter(function (k) { return nowMs - (seen[k] || 0) < 90 * 864e5; }).sort(function (a, b) { return seen[b] - seen[a]; }).slice(0, 600), o = {};
    keys.forEach(function (k) { o[k] = seen[k]; }); return o;
  }
  var PURE = { collect: collect, prune: prune, kTask: kTask, kOutcome: kOutcome, kDue: kDue };

  /* ============================ APPLICATION ============================ */
  var busy = false, timer = 0, lastN = -1;
  function WF() { return w.EXBWF; }
  function me() { try { return WF() && WF().me ? WF().me() : null; } catch (e) { return null; } }
  function ls() { try { return w.localStorage; } catch (e) { return null; } }
  function org() { try { return (w.EXBDB && w.EXBDB.org && w.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function skey(m) { return 'exb_wf_notif:' + org() + ':' + String(m.name || m.role || '').toLowerCase(); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'info', 8000); } catch (e) {} }
  function bell(msg, type) { try { if (typeof w.exbLogNotification === 'function') w.exbLogNotification(msg, type || 'info'); } catch (e) {} }
  function ring() { try { if (w.EXB_NOTIFY && w.EXB_NOTIFY.ring) w.EXB_NOTIFY.ring(); } catch (e) {} }

  function badge(n) {
    if (n === lastN || !d) return; lastN = n;
    var b = d.getElementById('bwf'); if (!b) return;
    b.textContent = '✅ Workflow' + (n ? ' (' + n + ')' : '');
    b.style.fontWeight = n ? '700' : '';
  }
  /* un passage : regarde, signale ce qui est nouveau, met à jour la pastille */
  function check() {
    if (busy) return { shown: 0 }; busy = true;
    try {
      var W = WF(), m = me(); if (!W || !m || !m.on) { badge(0); return { shown: 0 }; }
      var mine = W.tasksFor(), init = W.initiatedByMe ? W.initiatedByMe() : [], due = W.echeances ? W.echeances() : [];
      var mineIds = {}; mine.forEach(function (x) { mineIds[x.id] = 1; });
      due = due.filter(function (e) { return mineIds[e.id]; });
      badge(mine.length);
      var key = skey(m), store = ls(), seen = null;
      try { seen = store && JSON.parse(store.getItem(key) || 'null'); } catch (e) { seen = null; }
      var first = !seen, now = Date.now(), today = new Date().toISOString().slice(0, 10);
      var r = collect({ mine: mine, initiated: init, due: due, seen: seen || {}, today: today });
      seen = seen || {};
      if (first) {
        /* première fois sur cet appareil : tout l'existant est marqué « vu », un seul message de synthèse */
        r.items.forEach(function (it) { seen[it.k] = now; });
        if (mine.length) { var msg = mine.length + ' dossier(s) à valider dans ✅ Workflow.'; say(msg, 'info'); bell(msg, 'info'); }
        try { store && store.setItem(key, JSON.stringify(seen)); } catch (e) {}
        return { shown: 0, first: true };
      }
      var shown = 0;
      r.items.forEach(function (it) { seen[it.k] = now; });
      r.items.slice(0, MAXTOAST).forEach(function (it) { say('✅ Workflow — ' + it.text, it.type); shown++; });
      if (r.items.length > MAXTOAST) say('✅ Workflow — et ' + (r.items.length - MAXTOAST) + ' autre(s) signalement(s) : ouvrez le Workflow.', 'info');
      r.items.forEach(function (it) { bell('Workflow — ' + it.text, it.type); });
      if (r.items.some(function (it) { return it.kind === 'task'; })) ring();
      try { store && store.setItem(key, JSON.stringify(prune(seen, now))); } catch (e) {}
      return { shown: r.items.length };
    } catch (e) { try { console.warn('[EXBWFN]', e); } catch (x) {} return { shown: 0, error: String(e && e.message || e) }; }
    finally { busy = false; }
  }
  function open() { try { w.show('exbwf'); } catch (e) {} }

  w.EXBWFN = { version: 1, pure: PURE, check: check, open: open, _reset: function () { lastN = -1; } };
  if (!d) return;
  function boot() {
    [3500, 12000].forEach(function (ms) { setTimeout(check, ms); });
    if (!timer) timer = setInterval(function () { if (d.visibilityState !== 'hidden') check(); }, 45000);
    try { if (w.EXBCore && w.EXBCore.bus && !w.__wfnBus) { w.__wfnBus = 1; ['workflow.soumis', 'workflow.decision', 'workflow.valide', 'workflow.refuse', 'workflow.retourne', 'workflow.annule'].forEach(function (n) { w.EXBCore.bus.on(n, function () { setTimeout(check, 300); }); }); } } catch (e) {}
    try { d.addEventListener('visibilitychange', function () { if (d.visibilityState === 'visible') check(); }); } catch (e) {}
  }
  boot();
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
