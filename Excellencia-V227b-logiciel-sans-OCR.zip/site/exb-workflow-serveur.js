/* Excellencia Building — WORKFLOW SERVEUR (v1.3 du Workflow).
 * Branche exb-workflow.js sur les tables Supabase de migration-v149-workflow-serveur.sql : plusieurs validateurs peuvent décider
 * en même temps sans qu'une décision soit perdue (verrou de la ligne côté serveur, identité du compte, numéro attribué par le serveur).
 *
 * Fonctionnement (« serveur d'abord, affichage optimiste ») :
 *   1. L'écran applique la décision localement (retour immédiat) avec le moteur habituel.
 *   2. Elle est envoyée au serveur (wf_decider…), qui relit l'état réel, vérifie qui a le droit d'agir et écrit.
 *   3. La réponse du serveur remplace la copie locale. Si le serveur refuse (un autre validateur a décidé entre-temps, droits…),
 *      la copie locale est remise à l'état du serveur et le motif du refus est affiché. Rien n'est écrit « à moitié ».
 *   Les événements (journal d'audit, bus CORE : workflow.valide…) ne partent qu'APRÈS la confirmation du serveur.
 *   Les nouvelles soumissions faites hors connexion attendent dans une boîte d'envoi (exb_wf_outbox) et partent au retour du réseau
 *   (le renvoi est sans doublon : l'identifiant du dossier est fourni par l'appareil et le serveur l'ignore s'il existe déjà).
 *   Les décisions, elles, ne sont jamais mises en attente : une décision hors connexion est refusée (elle doit se prendre sur l'état réel).
 *
 * Actif seulement si : compte connecté + base partagée (organisation) + tables installées (wf_etat répond). Sinon : mode local
 * inchangé (la dernière écriture gagne ; limite connue). Circuits et délégations : écrits sur le serveur par l'administrateur.
 * Pour retirer : supprimer la balise <script src="exb-workflow-serveur.js"> (retour au mode local). */
(function (w, d) {
  'use strict';
  if (w.EXBWFS) return;
  var OUTK = 'exb_wf_outbox', SINCEK = 'exb_wf_since', PROBEK = 'exb_wf_srv', OVERLAP_MS = 60000;

  /* ============================ OUTILS PURS (testés) ============================ */
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function same(a, b) { try { return JSON.stringify(a) === JSON.stringify(b); } catch (e) { return false; } }
  /* diff de deux listes par id : { up: [éléments nouveaux ou modifiés], del: [ids retirés] } */
  function diffById(prev, next) {
    var pm = {}, up = [], del = [];
    (prev || []).forEach(function (x) { if (x && x.id) pm[x.id] = x; });
    (next || []).forEach(function (x) { if (!x || !x.id) return; if (!pm[x.id] || !same(pm[x.id], x)) up.push(x); delete pm[x.id]; });
    Object.keys(pm).forEach(function (k) { del.push(k); });
    return { up: up, del: del };
  }
  /* quel événement un dossier a-t-il vécu entre deux copies ? (pour les autres appareils : bus seulement, sans journal) */
  function eventBetween(prev, next) {
    if (!prev || !next) return '';
    if (prev.status !== next.status) return { valide: 'valide', refuse: 'refuse', retourne: 'retourne', annule: 'annule', en_cours: prev.status === 'retourne' ? 'resoumis' : '' }[next.status] || '';
    if (next.version !== prev.version) return 'resoumis';
    if (next.cur !== prev.cur || (next.decisions || []).length !== (prev.decisions || []).length) return 'decision';
    return '';
  }
  /* fusion d'une ligne serveur dans la liste locale : la ligne serveur gagne si sa révision est plus récente ; un dossier en cours d'envoi n'est pas touché */
  function mergeRow(list, row, inflight) {
    var i = -1; list.forEach(function (x, k) { if (x.id === row.id) i = k; });
    var local = i >= 0 ? list[i] : null;
    if (inflight && inflight[row.id]) return { changed: false };
    if (local && (local._rev || 0) >= row.revision && !local._pending) return { changed: false };
    var nd = Object.assign({}, row.data, { _rev: row.revision });
    if (i >= 0) list[i] = nd; else list.push(nd);
    return { changed: true, prev: local, next: nd, event: local ? eventBetween(local, nd) : '' };
  }
  var PURE = { diffById: diffById, eventBetween: eventBetween, mergeRow: mergeRow };

  /* ============================ ÉTAT ============================ */
  var S = { ok: false, probed: false, org: '', who: null, busy: false, err: '', last: '', inflight: {}, cfgBusy: 0, timer: 0, warned: {} };
  try { var pv = w.localStorage && w.localStorage.getItem(PROBEK); if (pv) S.org = pv; S.ok = !!pv; } catch (e) {}
  function ls() { try { return w.localStorage; } catch (e) { return null; } }
  function rdj(k, def) { try { var v = ls().getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function wrj(k, v) { try { ls().setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function sb() { return w.exbSb; }
  function signedIn() { try { return !!(sb() && sb().isIn && sb().isIn()); } catch (e) { return false; } }
  function orgId() { try { return (w.EXBDB && w.EXBDB.org && w.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function myRole() { try { return (w.EXBDB && w.EXBDB._meta && w.EXBDB._meta().role) || ''; } catch (e) { return ''; } }
  function api(p, o) { return sb().api(p, o); }
  function rpc(n, b) { return api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  function say(m, t, ms) { try { if (w.notify) w.notify(m, t || 'info', ms || 7000); } catch (e) {} }
  function WF() { return w.EXBWF; }
  function active() { return !!(S.ok && signedIn() && orgId() && S.org === orgId()); }
  function K() { var k = WF() && WF()._keys; return k || { circuits: 'exb_wf_circuits', dossiers: 'exb_wf_dossiers', deleg: 'exb_wf_deleg' }; }
  function online() { try { return w.navigator.onLine !== false; } catch (e) { return true; } }
  /* erreur réseau (à réessayer) ou refus du serveur (définitif) ? */
  function isNet(e) { var m = String((e && e.message) || e || ''); return !online() || /Failed to fetch|NetworkError|Load failed|network|timeout|HTTP 5\d\d|HTTP 0/i.test(m); }

  /* ============================ COPIE LOCALE ============================ */
  function localList() { try { return WF().list().slice(); } catch (e) { return []; } }
  function putLocal(list) { try { return WF()._put(K().dossiers, list); } catch (e) { return false; } }
  function setLocal(nd) { var L = localList(), i = -1; L.forEach(function (x, k) { if (x.id === nd.id) i = k; }); if (i >= 0) L[i] = nd; else L.push(nd); putLocal(L); }
  function dropLocal(id) { putLocal(localList().filter(function (x) { return x.id !== id; })); }
  function withRev(dossier, rev) { var nd = clone(dossier); nd._rev = rev; delete nd._pending; return nd; }
  function refreshUI() { try { if (WF() && WF().render && w.document && w.document.getElementById('wf_box') && w.document.getElementById('exbwf') && w.document.getElementById('exbwf').style.display !== 'none') WF().render(); } catch (e) {} try { if (w.EXBWFN) w.EXBWFN.check(); } catch (e) {} try { if (w.EXBWFL) w.EXBWFL.apply(); } catch (e) {} }

  /* ============================ ENVOIS ============================ */
  function dataOf(nd) { return { titre: nd.titre, description: nd.description, montant: nd.montant, devise: nd.devise, type: nd.type, ref: nd.ref }; }
  function outbox() { return rdj(OUTK, []); }
  function outAdd(job) { var o = outbox().filter(function (x) { return x.id !== job.id; }); o.push(job); wrj(OUTK, o); }
  function outDel(id) { wrj(OUTK, outbox().filter(function (x) { return x.id !== id; })); }
  function inc(id) { S.inflight[id] = (S.inflight[id] || 0) + 1; }
  function dec(id) { S.inflight[id] = Math.max(0, (S.inflight[id] || 1) - 1); if (!S.inflight[id]) delete S.inflight[id]; }

  async function fetchOne(id) {
    try {
      var rows = await api('/rest/v1/wf_dossiers?org_id=eq.' + S.org + '&id=eq.' + encodeURIComponent(id) + '&select=id,revision,maj,data');
      if (rows && rows[0]) { setLocal(Object.assign({}, rows[0].data, { _rev: rows[0].revision })); return true; }
    } catch (e) {}
    return false;
  }
  /* envoie un dossier soumis (idempotent) ; true = confirmé ou refusé définitivement, false = à réessayer */
  async function sendSubmit(job) {
    var r;
    try { r = await rpc('wf_soumettre', { p_org: S.org, p_id: job.id, p_circuit_id: job.circuit_id || '', p_data: job.data }); }
    catch (e) { if (isNet(e)) return false; r = { ok: false, refus: (e && e.message) || 'erreur' }; }
    if (r && r.ok) {
      var nd = withRev(r.dossier, r.revision); setLocal(nd); outDel(job.id);
      if (!r.deja) { try { WF()._afterSubmit(nd, nd.circuit_nom); } catch (e) {} }
      return true;
    }
    outDel(job.id); dropLocal(job.id);
    say('Dossier non enregistré par le serveur : ' + ((r && r.refus) || 'refus') + '.', 'error', 9000);
    return true;
  }
  async function flush() {
    var o = outbox(); for (var i = 0; i < o.length; i++) { var ok = await sendSubmit(o[i]); if (!ok) break; }
  }
  async function decide(job) {
    var a = job.args, r;
    try { r = await rpc('wf_decider', { p_org: S.org, p_id: job.id, p_action: a.action, p_motif: a.motif || '', p_etape: a.etape, p_version: a.version }); }
    catch (e) {
      if (isNet(e)) { if (a.avant) setLocal(a.avant); say('Hors connexion : la décision n\'a pas pu être enregistrée sur le serveur. Reprenez-la au retour du réseau.', 'warn', 9000); return; }
      r = { ok: false, refus: (e && e.message) || 'erreur' };
    }
    return finishDecision(job, r, a.motif);
  }
  async function other(job, fn, params) {
    var r;
    try { r = await rpc(fn, params); }
    catch (e) {
      if (isNet(e)) { if (job.args.avant) setLocal(job.args.avant); say('Hors connexion : l\'opération n\'a pas pu être enregistrée sur le serveur.', 'warn', 9000); return; }
      r = { ok: false, refus: (e && e.message) || 'erreur' };
    }
    return finishDecision(job, r, job.args.motif);
  }
  async function finishDecision(job, r, motif) {
    if (r && r.ok) {
      var nd = withRev(r.dossier, r.revision); setLocal(nd);
      try { WF()._after(nd, r.event || job.args.event, motif); } catch (e) {}
      return;
    }
    await fetchOne(job.id);
    say('Décision non enregistrée : ' + ((r && r.refus) || 'refus du serveur') + ' Le dossier a été actualisé.', 'warn', 10000);
  }
  /* point d'entrée appelé par exb-workflow.js */
  function push(kind, nd, args) {
    var job = { kind: kind, id: nd.id, args: args || {} }, p;
    inc(nd.id);
    if (kind === 'submit') {
      var local = clone(nd); local._pending = true; setLocal(local);
      var j = { id: nd.id, circuit_id: job.args.circuit_id, data: dataOf(nd) }; outAdd(j);
      p = sendSubmit(j).then(function (ok) { if (!ok) say('Hors connexion : le dossier sera envoyé au serveur dès le retour du réseau.', 'warn', 8000); });
    } else if (kind === 'decide') p = decide(job);
    else if (kind === 'resubmit') p = other(job, 'wf_resoumettre', { p_org: S.org, p_id: nd.id, p_note: job.args.motif || '' });
    else if (kind === 'cancel') p = other(job, 'wf_annuler', { p_org: S.org, p_id: nd.id, p_motif: job.args.motif || '' });
    else { dec(nd.id); return; }
    p.catch(function () {}).then(function () { dec(nd.id); refreshUI(); });
  }

  /* ============================ CIRCUITS ET DÉLÉGATIONS (administrateur) ============================ */
  async function pushConfigAsync(kind, prev, next) {
    var df = diffById(prev, next);
    if (myRole() !== 'admin') {
      if (df.up.length || df.del.length) { say('Seul un administrateur peut enregistrer les ' + (kind === 'circuit' ? 'circuits' : 'délégations') + ' sur le serveur : votre modification reste locale et sera remplacée à la prochaine synchronisation.', 'warn', 9000); }
      return;
    }
    S.cfgBusy++;
    try {
      for (var i = 0; i < df.up.length; i++) { var r = await rpc('wf_config_ecrire', { p_org: S.org, p_kind: kind, p_id: df.up[i].id, p_data: df.up[i], p_supprime: false }); if (r && !r.ok) say('Serveur : ' + r.refus, 'warn', 8000); }
      for (var j = 0; j < df.del.length; j++) await rpc('wf_config_ecrire', { p_org: S.org, p_kind: kind, p_id: df.del[j], p_data: {}, p_supprime: true });
    } catch (e) { say('Circuits / délégations non enregistrés sur le serveur : ' + ((e && e.message) || e), 'warn', 9000); }
    S.cfgBusy--;
  }
  function pushConfig(kind, prev, next) { if (!active()) return; pushConfigAsync(kind, prev, next); }
  /* première activation : l'administrateur envoie au serveur les circuits / délégations qui n'y sont pas encore (jamais de suppression) */
  async function migrateConfig(serverCircuits, serverDeleg) {
    if (myRole() !== 'admin') return;
    var k = K(), sc = {}, sd = {}; (serverCircuits || []).forEach(function (x) { sc[x.id] = 1; }); (serverDeleg || []).forEach(function (x) { sd[x.id] = 1; });
    var lc = rdLocal(k.circuits), ld = rdLocal(k.deleg);
    var up = 0;
    for (var i = 0; i < lc.length; i++) if (lc[i] && lc[i].id && !sc[lc[i].id]) { await rpc('wf_config_ecrire', { p_org: S.org, p_kind: 'circuit', p_id: lc[i].id, p_data: lc[i], p_supprime: false }); up++; }
    for (var j = 0; j < ld.length; j++) if (ld[j] && ld[j].id && !sd[ld[j].id]) { await rpc('wf_config_ecrire', { p_org: S.org, p_kind: 'deleg', p_id: ld[j].id, p_data: ld[j], p_supprime: false }); up++; }
    if (up) say(up + ' circuit(s) / délégation(s) envoyé(s) au serveur Workflow.', 'success', 6000);
    return up;
  }
  function rdLocal(k) {
    try { if (w.EXBS && w.EXBS.get) { var a = w.EXBS.get(k); if (Array.isArray(a)) return a; } } catch (e) {}
    try { var v = JSON.parse((w.exbStorage || w.localStorage).getItem(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }

  /* ============================ SYNCHRONISATION ============================ */
  function sinceKey() { return SINCEK + ':' + S.org; }
  async function pull() {
    var k = K(), cfgDue = !S.cfgAt || Date.now() - S.cfgAt > 900000 || !S.migrated, sc = [], sd = [];
    /* V205x : circuits et délégations ne sont plus retéléchargés à chaque passage (au plus toutes les 15 min) */
    if (cfgDue) { sc = await api('/rest/v1/wf_circuits?org_id=eq.' + S.org + '&select=id,data') || []; sd = await api('/rest/v1/wf_deleg?org_id=eq.' + S.org + '&select=id,data') || []; S.cfgAt = Date.now(); }
    if (cfgDue && !S.cfgBusy) {
      if (!S.migrated) { S.migrated = 1; var n = await migrateConfig(sc, sd); if (n) { sc = await api('/rest/v1/wf_circuits?org_id=eq.' + S.org + '&select=id,data') || []; sd = await api('/rest/v1/wf_deleg?org_id=eq.' + S.org + '&select=id,data') || []; } }
      var cl = sc.map(function (x) { return x.data; }), dl = sd.map(function (x) { return x.data; });
      if (!same(rdLocal(k.circuits), cl) && (cl.length || myRole() !== 'admin')) WF()._put(k.circuits, cl);
      if (!same(rdLocal(k.deleg), dl) && (dl.length || myRole() !== 'admin')) WF()._put(k.deleg, dl);
    }
    var since = (ls() && ls().getItem(sinceKey())) || '1970-01-01T00:00:00Z', maxMaj = since, all = [], page = 0, rows;
    do {
      rows = await api('/rest/v1/wf_dossiers?org_id=eq.' + S.org + '&maj=gt.' + encodeURIComponent(since) + '&select=id,revision,maj,data&order=maj.asc&limit=300') || [];
      rows.forEach(function (row) { all.push(row); if (row.maj > maxMaj) maxMaj = row.maj; });
      if (rows.length) since = rows[rows.length - 1].maj;
      page++;
    } while (rows.length === 300 && page < 10);
    /* fusion synchrone sur la liste locale LA PLUS RÉCENTE (une décision prise pendant le téléchargement n'est pas écrasée) */
    var list = localList(), changed = 0, evs = [];
    all.forEach(function (row) { var m = mergeRow(list, row, S.inflight); if (m.changed) { changed++; if (m.event) evs.push({ nd: m.next, ev: m.event }); } });
    if (changed) putLocal(list);
    /* on garde un recouvrement d'une minute : une ligne validée tardivement (transaction longue) n'est jamais manquée */
    var keep = new Date(Math.max(0, Date.parse(maxMaj) - OVERLAP_MS)).toISOString(); if (ls() && !isNaN(Date.parse(maxMaj))) ls().setItem(sinceKey(), keep);
    evs.forEach(function (e) { try { WF()._emit(e.nd, e.ev); } catch (x) {} });
    return changed;
  }
  async function probe() {
    S.probed = true;
    if (!signedIn() || !orgId()) { S.ok = false; return false; }
    try {
      var r = await rpc('wf_etat', { p_org: orgId() });
      if (r && r.ok) { S.ok = true; S.org = orgId(); S.who = r.acteur || null; S.err = ''; try { ls().setItem(PROBEK, S.org); } catch (e) {} return true; }
      S.err = (r && r.refus) || 'refus';
    } catch (e) { if (isNet(e)) return S.ok; S.err = 'absent'; }
    S.ok = false; try { ls().removeItem(PROBEK); } catch (e) {} return false;
  }
  async function sync() {
    if (S.busy) return; S.busy = true;
    try {
      if (!S.probed || !S.ok) await probe();
      if (active()) { await flush(); var n = await pull(); S.last = new Date().toISOString(); S.err = ''; if (n) refreshUI(); else if (w.EXBWFN) w.EXBWFN.check(); }
    } catch (e) { S.err = (e && e.message) || String(e); }
    S.busy = false;
  }
  function boot() {
    if (S.timer) return;
    [2500, 9000].forEach(function (ms) { setTimeout(sync, ms); });
    S.timer = setInterval(function () { try { if (!d || d.visibilityState !== 'hidden') sync(); } catch (e) {} }, 120000); /* V205x : économie de données (avant : 30 s) */
    try { if (d) d.addEventListener('visibilitychange', function () { if (d.visibilityState === 'visible') sync(); }); w.addEventListener('online', sync); } catch (e) {}
    try { var os = w.show; if (typeof os === 'function' && !os.__wfs) { w.show = function (x) { var r = os.apply(this, arguments); if (x === 'exbwf') setTimeout(sync, 80); return r; }; w.show.__wfs = 1; } } catch (e) {}
  }
  function statusHtml() {
    if (!signedIn() || !orgId()) return '';
    var o = outbox().length, st = 'font-size:12px;border-radius:8px;padding:6px 10px;margin:0 0 8px;';
    if (active()) return '<div id="wfs_state" style="' + st + 'background:#f0faf3;border:1px solid #b7e4c7;color:#14532d">🟢 <b>Serveur Workflow actif</b> : chaque décision est vérifiée et enregistrée par le serveur (plusieurs validateurs en même temps, sans perte).' + (S.last ? ' Dernière synchronisation ' + new Date(S.last).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) + '.' : '') + (o ? ' <b>' + o + ' dossier(s) en attente d\'envoi.</b>' : '') + '</div>';
    if (S.probed) return '<div id="wfs_state" style="' + st + 'background:#fff8e6;border:1px solid #f0d9a8;color:#7a4b00">🟠 <b>Mode local</b> : le serveur Workflow n\'est pas installé (' + (S.err === 'absent' ? 'fonctions absentes' : 'accès refusé') + '). Si deux validateurs décident au même instant, la dernière écriture gagne. Pour l\'activer : exécutez <code>migration-v149-workflow-serveur.sql</code> dans Supabase.</div>';
    return '';
  }

  w.EXBWFS = { version: 1, pure: PURE, active: active, push: push, pushConfig: pushConfig, sync: sync, probe: probe, statusHtml: statusHtml, who: function () { return active() ? S.who : null; }, outbox: outbox, _state: function () { return S; } };
  if (d) boot();
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
