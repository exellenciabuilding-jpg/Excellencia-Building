/* Excellencia Building V165 — Finances & Comptabilité (module 15 du cahier des charges) : avoirs, échéanciers, journal comptable, clôture de période.
 * Principe : AUCUNE double saisie et AUCUNE modification des factures / de la caisse existantes.
 *  - Avoirs (notes de crédit)  : exb_credit_notes  (nouveau). Une facture n'est jamais modifiée : le net à payer = TTC − avoirs − paiements.
 *  - Échéanciers de paiement   : exb_pay_schedules (nouveau). Statut calculé en affectant paiements + avoirs aux échéances par date.
 *  - Journal / balance / grand livre : CALCULÉS à la demande depuis exb_invoices, exb_credit_notes, exb_cash, exb_v92_supplier_invoices (jamais stockés → toujours cohérents).
 *  - Clôture de période        : exb_compta_close (nouveau). Empreinte SHA-256 des écritures ; « Vérifier » signale toute modification postérieure (ne bloque pas les autres modules).
 * Plan comptable : repères de type SYSCOHADA proposés par défaut ; le paramétrage comptable et fiscal est À VALIDER localement avec votre comptable.
 * Devises : chaque devise est traitée séparément (aucune conversion). Retrait : supprimer la balise <script src="exb-compta.js"> (les données nouvelles restent dans leurs clés). */
(function (w) {
  'use strict';
  var d = w.document, $ = function (i) { return d && d.getElementById ? d.getElementById(i) : null; };
  var K = { cn: 'exb_credit_notes', ps: 'exb_pay_schedules', cl: 'exb_compta_close' };
  var XT = { tabs: [], entryFns: [], clHtml: function () { return ''; }, bind: [] }; /* V166 : points d'extension (exb-compta-etats.js) ; sans extension, comportement identique à la V165 */
  var ACC = {
    '411': 'Clients', '401': 'Fournisseurs', '701': 'Ventes de prestations', '709': 'Rabais, remises et ristournes accordés', '4431': 'TVA facturée (collectée)',
    '571': 'Caisse', '521': 'Banque / mobile money', '601': 'Achats de matériaux et fournitures', '604': 'Fournitures de bureau', '613': 'Loyers et charges locatives',
    '616': 'Abonnements et logiciels', '618': 'Transports et déplacements', '623': 'Publicité et marketing', '626': 'Télécommunications', '641': 'Impôts et taxes',
    '661': 'Salaires et main-d’œuvre', '658': 'Charges diverses', '758': 'Produits divers'
  };
  var DEP = [[/loyer|bail|location|electricite|snel|regideso|\beau\b/, '613'], [/salaire|paie|main.?d.?oeuvre|ouvrier|journalier|prime/, '661'], [/ciment|\bfer\b|sable|gravier|brique|agglo|beton|materiau|peinture|bois/, '601'],
    [/transport|carburant|essence|gasoil|diesel|taxi|voyage/, '618'], [/internet|\bdata\b|credit|airtime|telephone/, '626'], [/publicit|affiche|marketing|\bpub\b/, '623'],
    [/fourniture|papier|imprim|encre|bureau|papeterie/, '604'], [/abonnement|licence|logiciel|hebergement/, '616'], [/impot|taxe|\btva\b|\bdgi\b|inss|onem/, '641']];

  /* ---------- utilitaires ---------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function norm(s) { return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim(); }
  function pn(v) { var x = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isNaN(x) ? 0 : x; }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nf(n) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/[  ]/g, ' '); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function addDays(iso, n) { var t = new Date(iso + 'T00:00:00Z'); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); }
  function addMonths(iso, n) { var y = +iso.slice(0, 4), m = +iso.slice(5, 7) - 1 + n, dd = +iso.slice(8, 10); y += Math.floor(m / 12); m = ((m % 12) + 12) % 12; var last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate(); return y + '-' + String(m + 1).padStart(2, '0') + '-' + String(Math.min(dd, last)).padStart(2, '0'); }
  function daysBetween(a, b) { return Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000); }
  function LD(k, df) { try { var v = w.load ? w.load(k, df) : JSON.parse(w.localStorage.getItem(k)); return v == null ? df : v; } catch (e) { return df; } }
  function SV(k, v) { try { return w.save ? w.save(k, v) : (w.localStorage.setItem(k, JSON.stringify(v)), true); } catch (e) { return false; } }
  function uid(p) { try { return w.exbId(p); } catch (e) { return p + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); } }
  function audit(a, o, x) { try { w.EXBCore && w.EXBCore.audit.log(a, o, x); } catch (e) {} }
  function say(m, t) { try { w.notify(m, t || 'info', 4500); } catch (e) { try { w.exbAlert(m); } catch (x) {} } }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction || i.role)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function can(c, m) { try { return w.EXBDB && w.EXBDB.can ? !!w.EXBDB.can(c, m) : true; } catch (e) { return true; } }
  function cur(x) { var c = String((x && x.currency) || 'USD').toUpperCase(); return c === 'CDF' ? 'FC' : c; }

  /* ---------- sources ---------- */
  function invs() { return LD('exb_invoices', []).filter(function (i) { return i && i.id; }); }
  function cancelled(i) { return !!(i.annule || /annul/i.test(i.status || '')); }
  function iTot(i) { var ht = (i.lines || []).reduce(function (a, l) { return a + (+l.q || 0) * (+l.pu || 0); }, 0), tv = ht * (+i.tva || 0) / 100; return { ht: r2(ht), tva: r2(tv), ttc: r2(ht + tv), paid: r2((i.payments || []).reduce(function (a, p) { return a + (+p.amount || 0); }, 0)) }; }
  function notes() { return LD(K.cn, []).filter(function (n) { return n && n.id; }); }
  function validNotes(invId) { return notes().filter(function (n) { return n.status !== 'annulé' && (!invId || n.invoice_id === invId); }); }
  function creditsOf(invId) { return r2(validNotes(invId).reduce(function (a, n) { return a + (+n.ttc || 0); }, 0)); }
  function netDue(i) { var t = iTot(i); return r2(Math.max(0, t.ttc - t.paid - creditsOf(i.id))); }
  function scheds() { return LD(K.ps, []); }
  function supInvs() { return LD('exb_v92_supplier_invoices', []).filter(Boolean); }
  function cash() { try { return (w.exbCash && w.exbCash.length != null) ? w.exbCash : LD('exb_cash', []); } catch (e) { return LD('exb_cash', []); } }

  /* ---------- avoirs ---------- */
  function nextNoteNo(date) { var y = String(date || today()).slice(0, 4), max = 0; notes().forEach(function (n) { var m = /^AV-(\d{4})-(\d+)$/.exec(n.no || ''); if (m && m[1] === y) max = Math.max(max, +m[2]); }); return 'AV-' + y + '-' + String(max + 1).padStart(4, '0'); }
  function createNote(o) {
    var i = invs().find(function (x) { return x.id === o.invoice_id; });
    if (!i) return { error: 'Facture introuvable.' };
    if (cancelled(i)) return { error: 'Cette facture est annulée : pas d’avoir.' };
    var t = iTot(i), already = creditsOf(i.id), room = r2(t.ttc - already), ttc = r2(pn(o.ttc));
    if (!(ttc > 0)) return { error: 'Montant de l’avoir invalide.' };
    if (ttc > room + 0.005) return { error: 'L’avoir (' + nf(ttc) + ') dépasse le solde créditable de la facture (' + nf(room) + ').' };
    if (!String(o.motif || '').trim()) return { error: 'Le motif est obligatoire.' };
    var rate = +i.tva || 0, ht = r2(ttc / (1 + rate / 100)), tv = r2(ttc - ht), date = o.date || today();
    var n = { id: uid('AV'), no: nextNoteNo(date), date: date, invoice_id: i.id, invoice_no: i.no || i.id, client: i.client || '', project_id: i.project_id || '', currency: cur(i), tva: rate, ht: ht, tva_amount: tv, ttc: ttc, motif: String(o.motif).trim(), status: 'émis', by: who(), at: new Date().toISOString() };
    var a = notes(); a.push(n); if (!SV(K.cn, a)) return { error: 'Enregistrement impossible (stockage).' };
    audit('compta.avoir.emis', n.no, { facture: n.invoice_no, ttc: n.ttc, motif: n.motif });
    var apresPaye = r2(t.paid - (t.ttc - already - ttc)); /* part payée en trop après l'avoir */
    n.rembourser = apresPaye > 0.005 ? apresPaye : 0;
    return { note: n };
  }
  function cancelNote(id, why) {
    if (!String(why || '').trim()) return { error: 'Le motif d’annulation est obligatoire.' };
    var a = notes(), n = a.find(function (x) { return x.id === id; }); if (!n) return { error: 'Avoir introuvable.' }; if (n.status === 'annulé') return { error: 'Déjà annulé.' };
    n.status = 'annulé'; n.cancel_reason = String(why).trim(); n.cancelled_at = new Date().toISOString(); n.cancelled_by = who();
    SV(K.cn, a); audit('compta.avoir.annule', n.no, { motif: n.cancel_reason }); return { note: n };
  }

  /* ---------- échéanciers ---------- */
  function buildSchedule(total, count, first, step, unit) {
    count = Math.max(1, Math.min(60, Math.floor(count))); var base = Math.floor(total * 100 / count) / 100, out = [], sum = 0;
    for (var k = 0; k < count; k++) { var amt = k === count - 1 ? r2(total - sum) : base; sum = r2(sum + amt); out.push({ n: k + 1, due: unit === 'jours' ? addDays(first, k * step) : addMonths(first, k * step), amount: amt }); }
    return out;
  }
  /* affecte (paiements + avoirs) aux échéances, par date croissante */
  function allocate(items, covered) {
    var rest = covered, t = today();
    return items.slice().sort(function (a, b) { return a.due < b.due ? -1 : a.due > b.due ? 1 : a.n - b.n; }).map(function (it) {
      var got = r2(Math.min(it.amount, Math.max(0, rest))); rest = r2(rest - got);
      var st = got >= it.amount - 0.005 ? 'payée' : (it.due < t ? 'en retard' : (daysBetween(t, it.due) <= 7 ? 'bientôt' : 'à venir'));
      return { n: it.n, due: it.due, amount: it.amount, paid: got, left: r2(it.amount - got), status: st, late: st === 'en retard' ? daysBetween(it.due, t) : 0 };
    });
  }
  function scheduleView(s) {
    var i = invs().find(function (x) { return x.id === s.invoice_id; }); if (!i) return null; var t = iTot(i);
    return { inv: i, rows: allocate(s.items || [], r2(t.paid + creditsOf(i.id))), net: netDue(i), cancelled: cancelled(i) };
  }
  function saveSchedule(invId, items) {
    var i = invs().find(function (x) { return x.id === invId; }); if (!i) return { error: 'Facture introuvable.' };
    items = (items || []).map(function (x, k) { return { n: k + 1, due: String(x.due || '').slice(0, 10), amount: r2(pn(x.amount)) }; });
    if (!items.length || items.some(function (x) { return !/^\d{4}-\d{2}-\d{2}$/.test(x.due) || !(x.amount > 0); })) return { error: 'Chaque échéance doit avoir une date et un montant > 0.' };
    var t = iTot(i), expect = r2(t.ttc - creditsOf(i.id)), sum = r2(items.reduce(function (a, x) { return a + x.amount; }, 0));
    if (Math.abs(sum - expect) > 0.01) return { error: 'Le total des échéances (' + nf(sum) + ') doit égaler le TTC net d’avoirs (' + nf(expect) + ').' };
    var a = scheds().filter(function (s) { return s.invoice_id !== invId; }); a.push({ id: uid('ECH'), invoice_id: invId, invoice_no: i.no || i.id, items: items, by: who(), at: new Date().toISOString() });
    if (!SV(K.ps, a)) return { error: 'Enregistrement impossible (stockage).' }; audit('compta.echeancier.enregistre', i.no || i.id, { echeances: items.length, total: sum }); return { ok: true };
  }
  function overdueList() {
    var out = []; scheds().forEach(function (s) { var v = scheduleView(s); if (!v || v.cancelled) return; v.rows.forEach(function (r) { if (r.status === 'en retard' || r.status === 'bientôt') out.push({ inv: v.inv, row: r }); }); });
    return out.sort(function (a, b) { return a.row.due < b.row.due ? -1 : 1; });
  }

  /* ---------- journal (calculé) ---------- */
  function payAcc(method) { return /esp|cash|caisse/i.test(method || '') || !method ? '571' : '521'; }
  function depAcc(label, cat) { var t = norm((label || '') + ' ' + (cat || '')); for (var k = 0; k < DEP.length; k++) if (DEP[k][0].test(t)) return DEP[k][1]; return '658'; }
  function entries() {
    var E = [], seq = 0;
    function add(date, jr, piece, lib, c, lines) { seq++; lines.forEach(function (l) { if (l[1] || l[2]) E.push({ s: seq, date: date, jr: jr, piece: piece, lib: lib, cur: c, acc: l[0], d: r2(l[1] || 0), c: r2(l[2] || 0) }); }); }
    invs().forEach(function (i) {
      if (cancelled(i) || !i.date) return; var t = iTot(i), c = cur(i); if (!(t.ttc > 0)) return;
      add(String(i.date).slice(0, 10), 'VT', i.no || i.id, 'Facture ' + (i.client || ''), c, [['411', t.ttc, 0], ['701', 0, t.ht], ['4431', 0, t.tva]]);
      (i.payments || []).forEach(function (p) { var a = r2(+p.amount || 0); if (a > 0) add(String(p.date || i.date).slice(0, 10), 'CA', i.no || i.id, 'Encaissement ' + (i.client || '') + (p.method ? ' (' + p.method + ')' : ''), c, [[payAcc(p.method), a, 0], ['411', 0, a]]); });
    });
    validNotes().forEach(function (n) { add(String(n.date).slice(0, 10), 'VT', n.no, 'Avoir ' + n.invoice_no + ' — ' + (n.motif || ''), n.currency || 'USD', [['709', n.ht, 0], ['4431', n.tva_amount, 0], ['411', 0, n.ttc]]); });
    var sup = supInvs(); sup.forEach(function (s) {
      var a = r2(+s.amount || +s.total || +s.ttc || 0), dt = String(s.date || s.invoice_date || s.created_at || '').slice(0, 10); if (!(a > 0) || !/^\d{4}-\d{2}-\d{2}$/.test(dt)) return;
      add(dt, 'AC', s.no || s.number || s.ref || s.id || '', 'Facture fournisseur ' + (s.supplier || s.supplier_name || s.fournisseur || ''), cur(s), [['601', a, 0], ['401', 0, a]]);
    });
    var supKey = {}; sup.forEach(function (s) { [s.id, s.no, s.number, s.ref].forEach(function (k) { if (k) supKey[String(k)] = 1; }); });
    cash().forEach(function (x) {
      if (!x || x.invoice_id || x.pay_id) return; /* encaissements de factures : déjà issus de la facture */
      var a = r2(+x.amount || 0), dt = String(x.date || '').slice(0, 10); if (!(a > 0) || !/^\d{4}-\d{2}-\d{2}$/.test(dt)) return; var c = cur(x), ca = payAcc(x.method), lib = x.label || (x.type === 'in' ? 'Recette' : 'Dépense');
      if (x.type === 'in') add(dt, 'CA', x.ref || x.id || '', lib, c, [[ca, a, 0], ['758', 0, a]]);
      else add(dt, 'CA', x.ref || x.id || '', lib, c, [[x.paie_run ? '421' : (x.ref && supKey[String(x.ref)] ? '401' : depAcc(x.label, x.cat)), a, 0], [ca, 0, a]]);
    });
    XT.entryFns.forEach(function (fn) { try { fn(add); } catch (e) {} });
    return E.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : a.s - b.s; });
  }
  function inPeriod(e, f) { return (!f.from || e.date >= f.from) && (!f.to || e.date <= f.to) && (!f.cur || e.cur === f.cur) && (!f.jr || e.jr === f.jr); }
  function balance(list) {
    var m = {}; list.forEach(function (e) { var o = m[e.acc] || (m[e.acc] = { acc: e.acc, d: 0, c: 0 }); o.d = r2(o.d + e.d); o.c = r2(o.c + e.c); });
    var rows = Object.keys(m).sort().map(function (k) { var o = m[k]; o.sd = o.d > o.c ? r2(o.d - o.c) : 0; o.sc = o.c > o.d ? r2(o.c - o.d) : 0; return o; });
    var td = r2(rows.reduce(function (a, r) { return a + r.d; }, 0)), tc = r2(rows.reduce(function (a, r) { return a + r.c; }, 0)); return { rows: rows, td: td, tc: tc, ok: Math.abs(td - tc) < 0.005 };
  }
  function csvCell(v) { v = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
  function toCsv(list) { var h = ['date', 'journal', 'piece', 'libelle', 'devise', 'compte', 'intitule', 'debit', 'credit']; return '﻿' + [h.map(csvCell).join(';')].concat(list.map(function (e) { return [e.date, e.jr, e.piece, e.lib, e.cur, e.acc, ACC[e.acc] || '', String(e.d).replace('.', ','), String(e.c).replace('.', ',')].map(csvCell).join(';'); })).join('\r\n'); }

  /* ---------- clôture (empreinte) ---------- */
  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function digest(s) { try { return w.crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(hex); } catch (e) { return Promise.resolve(''); } }
  function monthRange(ym) { return { from: ym + '-01', to: ym + '-31' }; }
  function periodFingerprint(ym) { var f = monthRange(ym); var l = entries().filter(function (e) { return e.date >= f.from && e.date <= f.to; }); return digest(JSON.stringify(l.map(function (e) { return [e.date, e.jr, e.piece, e.cur, e.acc, e.d, e.c]; }))).then(function (h) { return { hash: h, n: l.length }; }); }
  function closeMonth(ym) {
    if (!/^\d{4}-\d{2}$/.test(ym)) return Promise.resolve({ error: 'Mois invalide.' });
    var a = LD(K.cl, []); if (a.some(function (x) { return x.ym === ym && !x.reopened; })) return Promise.resolve({ error: 'Ce mois est déjà clôturé.' });
    return periodFingerprint(ym).then(function (p) { var b = balance(entries().filter(function (e) { var f = monthRange(ym); return e.date >= f.from && e.date <= f.to; }));
      a.push({ id: uid('CLO'), ym: ym, hash: p.hash, n: p.n, d: b.td, c: b.tc, by: who(), at: new Date().toISOString() }); SV(K.cl, a); audit('compta.cloture', ym, { ecritures: p.n }); return { ok: true }; });
  }
  function verifyClose(rec) { return periodFingerprint(rec.ym).then(function (p) { return { ok: p.hash === rec.hash, now: p.n, was: rec.n }; }); }
  function reopen(ym, why) { if (!String(why || '').trim()) return { error: 'Le motif de réouverture est obligatoire.' }; var a = LD(K.cl, []); var r = a.find(function (x) { return x.ym === ym && !x.reopened; }); if (!r) return { error: 'Mois non clôturé.' }; r.reopened = true; r.reopen_reason = String(why).trim(); r.reopened_at = new Date().toISOString(); r.reopened_by = who(); SV(K.cl, a); audit('compta.reouverture', ym, { motif: r.reopen_reason }); return { ok: true }; }

  /* ---------- interface ---------- */
  var S = { tab: 'avoirs', jr: '', cur: '', from: '', to: '', acc: '', form: null, msg: '' };
  function btn(id, label, cls) { return '<button id="' + id + '" type="button" class="' + (cls || '') + '" style="padding:6px 10px;margin:2px">' + label + '</button>'; }
  function inp(id, v, ph, extra) { return '<input id="' + id + '" value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(ph || '') + '" style="padding:6px;max-width:100%;box-sizing:border-box;' + (extra || '') + '">'; }
  function curOpts() { var s = {}; entries().forEach(function (e) { s[e.cur] = 1; }); invs().forEach(function (i) { s[cur(i)] = 1; }); var k = Object.keys(s); return k.length ? k : ['USD']; }
  function table(head, rows, foot) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12.5px"><thead><tr style="text-align:left;background:#f1f5fb">' + head.map(function (h) { return '<th style="padding:5px">' + h + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody>' + (foot || '') + '</table></div>'; }
  function td(v, al) { return '<td style="padding:5px;border-top:1px solid #e2e8f0;' + (al ? 'text-align:' + al : '') + '">' + v + '</td>'; }
  var STC = { 'payée': '#16a34a', 'en retard': '#dc2626', 'bientôt': '#d97706', 'à venir': '#64748b' };

  function tabAvoirs() {
    var L = notes().slice().reverse(), I = invs().filter(function (i) { return !cancelled(i) && iTot(i).ttc > 0; }), f = S.form && S.form.type === 'avoir' ? S.form : null, h = '';
    if (f) {
      var i = I.find(function (x) { return x.id === f.invoice_id; }), room = i ? r2(iTot(i).ttc - creditsOf(i.id)) : 0;
      h += '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Nouvel avoir</b><p><label>Facture<br><select id="cp_inv" style="padding:6px;max-width:100%">' + '<option value="">— choisir —</option>' + I.map(function (x) { return '<option value="' + esc(x.id) + '"' + (x.id === f.invoice_id ? ' selected' : '') + '>' + esc((x.no || x.id) + ' — ' + (x.client || '') + ' — ' + nf(iTot(x).ttc) + ' ' + cur(x)) + '</option>'; }).join('') + '</select></label></p>' +
        (i ? '<p style="font-size:12px;color:#475569">Solde créditable : <b>' + nf(room) + ' ' + cur(i) + '</b> (TVA ' + (+i.tva || 0) + ' %). ' + btn('cp_full', 'Avoir total') + '</p>' : '') +
        '<p><label>Montant TTC de l’avoir<br>' + inp('cp_ttc', f.ttc, '0,00') + '</label> <label>Date<br>' + inp('cp_date', f.date || today(), 'AAAA-MM-JJ') + '</label></p><p><label>Motif (obligatoire)<br>' + inp('cp_motif', f.motif, 'Ex. remise commerciale, erreur de prix, retour…', 'width:100%') + '</label></p>' + btn('cp_ok', 'Émettre l’avoir') + btn('cp_no', 'Annuler') + '</div>';
    } else h += '<p>' + btn('cp_new', '➕ Nouvel avoir') + '</p>';
    var rows = L.map(function (n) { var ann = n.status === 'annulé'; return '<tr style="' + (ann ? 'opacity:.55;text-decoration:line-through' : '') + '">' + td(esc(n.no)) + td(esc(n.date)) + td(esc(n.invoice_no)) + td(esc(n.client)) + td(nf(n.ttc) + ' ' + esc(n.currency), 'right') + td(esc(n.motif)) + td(ann ? 'annulé' : (f ? '' : '<button class="cp_x" data-id="' + esc(n.id) + '" type="button">Annuler</button>')) + '</tr>'; });
    h += rows.length ? table(['N°', 'Date', 'Facture', 'Client', 'Montant TTC', 'Motif', ''], rows) : '<p style="color:#64748b">Aucun avoir émis.</p>';
    if (S.form && S.form.type === 'annul') h += '<div style="border:1px solid #fca5a5;border-radius:8px;padding:10px;margin:8px 0"><b>Annuler l’avoir ' + esc(S.form.no) + '</b><p>' + inp('cp_why', '', 'Motif d’annulation (obligatoire)', 'width:100%') + '</p>' + btn('cp_xok', 'Confirmer l’annulation') + btn('cp_xno', 'Retour') + '</div>';
    return h + '<p style="font-size:12px;color:#64748b">Un avoir ne modifie jamais la facture : le net à payer = TTC − avoirs − paiements. Il est annulé (jamais supprimé) pour garder la trace.</p>';
  }
  function tabEcheances() {
    var h = '', od = overdueList(), f = S.form && S.form.type === 'ech' ? S.form : null;
    if (od.length) h += '<div style="background:#fff7ed;border:1px solid #fdba74;border-radius:8px;padding:8px;margin-bottom:8px"><b>⚠ ' + od.length + ' échéance(s) en retard ou à venir sous 7 jours</b><br>' + od.slice(0, 8).map(function (o) { return '<span style="color:' + STC[o.row.status] + '">' + esc(o.inv.no || o.inv.id) + ' — ' + esc(o.inv.client || '') + ' — ' + nf(o.row.left) + ' ' + cur(o.inv) + ' — ' + esc(o.row.due) + (o.row.late ? ' (' + o.row.late + ' j de retard)' : '') + '</span>'; }).join('<br>') + '</div>';
    var I = invs().filter(function (i) { return !cancelled(i) && netDue(i) > 0; });
    if (f) {
      var i = invs().find(function (x) { return x.id === f.invoice_id; }), net = i ? r2(iTot(i).ttc - creditsOf(i.id)) : 0;
      h += '<div style="border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin:8px 0"><b>Échéancier — ' + esc(i ? (i.no || i.id) : '') + '</b> (TTC net d’avoirs : ' + nf(net) + ' ' + (i ? cur(i) : '') + ')<p>Générer : ' + inp('ep_n', f.n || 3, 'nb', 'width:60px') + ' échéance(s), première le ' + inp('ep_first', f.first || addMonths(today(), 1), 'AAAA-MM-JJ', 'width:120px') + ', tous les ' + inp('ep_step', f.step || 1, '1', 'width:50px') + ' <select id="ep_unit" style="padding:6px"><option value="mois"' + (f.unit === 'jours' ? '' : ' selected') + '>mois</option><option value="jours"' + (f.unit === 'jours' ? ' selected' : '') + '>jours</option></select> ' + btn('ep_gen', 'Générer') + '</p>' +
        '<div id="ep_rows">' + (f.items || []).map(function (x, k) { return '<p style="margin:3px 0">' + (k + 1) + '. ' + inp('ep_d' + k, x.due, 'AAAA-MM-JJ', 'width:120px') + ' ' + inp('ep_a' + k, x.amount, 'montant', 'width:110px') + '</p>'; }).join('') + '</div>' + ((f.items || []).length ? '<p style="font-size:12px">Total saisi : <b id="ep_tot"></b></p>' + btn('ep_ok', 'Enregistrer l’échéancier') : '') + btn('ep_no', 'Fermer') + '</div>';
    }
    var S2 = scheds().map(scheduleView).filter(Boolean);
    h += '<p><b>Factures avec échéancier</b></p>' + (S2.length ? S2.map(function (v) { return '<div style="margin:6px 0"><b>' + esc(v.inv.no || v.inv.id) + '</b> — ' + esc(v.inv.client || '') + ' — net à payer ' + nf(v.net) + ' ' + cur(v.inv) + ' <button class="ep_edit" type="button" data-id="' + esc(v.inv.id) + '">Modifier</button>' +
      table(['N°', 'Échéance', 'Montant', 'Réglé', 'Reste', 'Statut'], v.rows.map(function (r) { return '<tr>' + td(r.n) + td(esc(r.due)) + td(nf(r.amount), 'right') + td(nf(r.paid), 'right') + td(nf(r.left), 'right') + td('<span style="color:' + STC[r.status] + ';font-weight:600">' + r.status + (r.late ? ' (' + r.late + ' j)' : '') + '</span>') + '</tr>'; })) + '</div>'; }).join('') : '<p style="color:#64748b">Aucun échéancier.</p>');
    h += '<p><b>Créer un échéancier pour une facture</b></p>' + (I.length ? '<p><select id="ep_pick" style="padding:6px;max-width:100%"><option value="">— choisir une facture non soldée —</option>' + I.map(function (x) { return '<option value="' + esc(x.id) + '">' + esc((x.no || x.id) + ' — ' + (x.client || '') + ' — reste ' + nf(netDue(x)) + ' ' + cur(x)) + '</option>'; }).join('') + '</select> ' + btn('ep_start', 'Commencer') + '</p>' : '<p style="color:#64748b">Aucune facture non soldée.</p>');
    return h + '<p style="font-size:12px;color:#64748b">Statut calculé : les paiements et avoirs de la facture sont affectés aux échéances par ordre de date.</p>';
  }
  function filt() { var f = { from: S.from, to: S.to, cur: S.cur || curOpts()[0], jr: S.jr }; return f; }
  function tabJournal() {
    var f = filt(), all = entries(), L = all.filter(function (e) { return inPeriod(e, f); }), B = balance(L), shown = L.slice(-200);
    var bar = '<p>Devise ' + '<select id="jr_cur" style="padding:5px">' + curOpts().map(function (c) { return '<option' + (c === f.cur ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select> Journal <select id="jr_j" style="padding:5px"><option value="">Tous</option>' + [['VT', 'Ventes'], ['AC', 'Achats'], ['CA', 'Caisse / banque']].map(function (j) { return '<option value="' + j[0] + '"' + (S.jr === j[0] ? ' selected' : '') + '>' + j[1] + '</option>'; }).join('') + '</select> Du ' + inp('jr_from', S.from, 'AAAA-MM-JJ', 'width:110px') + ' au ' + inp('jr_to', S.to, 'AAAA-MM-JJ', 'width:110px') + ' ' + btn('jr_csv', '⬇ CSV') + btn('jr_pdf', '🖨 PDF') + '</p>';
    var bal = '<p style="padding:6px;border-radius:6px;background:' + (B.ok ? '#e6f6ea' : '#fde8e8') + '">' + (B.ok ? '✅ Équilibre débit = crédit' : '⛔ Déséquilibre') + ' — Débit ' + nf(B.td) + ' / Crédit ' + nf(B.tc) + ' ' + esc(f.cur) + ' (' + L.length + ' écritures)</p>';
    var j = table(['Date', 'Jnl', 'Pièce', 'Libellé', 'Compte', 'Débit', 'Crédit'], shown.map(function (e) { return '<tr>' + td(esc(e.date)) + td(e.jr) + td(esc(e.piece)) + td(esc(e.lib)) + td(e.acc + ' ' + esc(ACC[e.acc] || '')) + td(e.d ? nf(e.d) : '', 'right') + td(e.c ? nf(e.c) : '', 'right') + '</tr>'; }));
    var b = table(['Compte', 'Intitulé', 'Débit', 'Crédit', 'Solde D', 'Solde C'], B.rows.map(function (r) { return '<tr>' + td('<a href="#" class="jr_gl" data-acc="' + r.acc + '">' + r.acc + '</a>') + td(esc(ACC[r.acc] || '')) + td(nf(r.d), 'right') + td(nf(r.c), 'right') + td(r.sd ? nf(r.sd) : '', 'right') + td(r.sc ? nf(r.sc) : '', 'right') + '</tr>'; }));
    var g = '';
    if (S.acc) { var run = 0, gl = L.filter(function (e) { return e.acc === S.acc; }); g = '<h4>Grand livre — ' + S.acc + ' ' + esc(ACC[S.acc] || '') + ' ' + btn('jr_glx', 'Fermer') + '</h4>' + table(['Date', 'Pièce', 'Libellé', 'Débit', 'Crédit', 'Solde'], gl.map(function (e) { run = r2(run + e.d - e.c); return '<tr>' + td(esc(e.date)) + td(esc(e.piece)) + td(esc(e.lib)) + td(e.d ? nf(e.d) : '', 'right') + td(e.c ? nf(e.c) : '', 'right') + td(nf(run), 'right') + '</tr>'; })); }
    return bar + bal + g + '<h4>Balance</h4>' + b + '<h4>Journal' + (L.length > shown.length ? ' (200 dernières écritures — export CSV pour tout)' : '') + '</h4>' + j + '<p style="font-size:12px;color:#64748b">Écritures calculées depuis vos factures, paiements, avoirs, factures fournisseurs et caisse (rien n’est saisi deux fois). Plan comptable indicatif (type SYSCOHADA) : à valider avec votre comptable. Chaque devise est séparée, sans conversion.</p>';
  }
  function tabCloture() {
    var a = LD(K.cl, []).slice().reverse(), ym = today().slice(0, 7), h = '<p>Mois à clôturer ' + inp('cl_ym', S.cm || addMonths(ym + '-01', -1).slice(0, 7), 'AAAA-MM', 'width:90px') + ' ' + btn('cl_ok', '🔒 Clôturer') + '</p>';
    h += a.length ? table(['Mois', 'Écritures', 'Clôturé par', 'Le', 'État', ''], a.map(function (r) { return '<tr>' + td(esc(r.ym)) + td(r.n) + td(esc(r.by)) + td(esc(String(r.at).slice(0, 16).replace('T', ' '))) + td(r.reopened ? 'rouvert (' + esc(r.reopen_reason) + ')' : '<span class="cl_state" data-ym="' + esc(r.ym) + '">…</span>') + td(r.reopened ? '' : '<button class="cl_re" data-ym="' + esc(r.ym) + '" type="button">Rouvrir</button>') + '</tr>'; })) : '<p style="color:#64748b">Aucun mois clôturé.</p>';
    if (S.form && S.form.type === 'reopen') h += '<div style="border:1px solid #fca5a5;border-radius:8px;padding:10px;margin:8px 0"><b>Rouvrir ' + esc(S.form.ym) + '</b><p>' + inp('cl_why', '', 'Motif obligatoire', 'width:100%') + '</p>' + btn('cl_rok', 'Confirmer') + btn('cl_rno', 'Retour') + '</div>';
    return h + XT.clHtml() + '<p style="font-size:12px;color:#64748b">La clôture enregistre une empreinte SHA-256 des écritures du mois. « OK » = aucune écriture n’a changé depuis ; « modifié » = une facture, un paiement, un avoir ou une dépense de ce mois a été ajouté ou changé après la clôture. Par défaut elle ne bloque pas les saisies : elle les rend visibles (le verrou optionnel ci-dessus peut les refuser).</p>';
  }
  function msgBar() { return S.msg ? '<div style="padding:6px 8px;margin-bottom:6px;border-radius:6px;background:#eef2ff">' + esc(S.msg) + '</div>' : ''; }
  function render() {
    var o = $('cpt_ov'); if (!o) return; var T = [['avoirs', '🧾 Avoirs'], ['ech', '📅 Échéanciers'], ['jr', '📒 Journal']].concat(XT.tabs.map(function (t) { return [t.id, t.label]; }), [['cl', '🔒 Clôture']]);
    o.querySelector('.cpt_tabs').innerHTML = T.map(function (t) { return '<button data-t="' + t[0] + '" type="button" style="padding:8px 10px;margin-right:4px;' + (S.tab === t[0] ? 'font-weight:700;border-bottom:3px solid #1d4ed8' : '') + '">' + t[1] + '</button>'; }).join('');
    var b = o.querySelector('.cpt_body'); b.innerHTML = msgBar() + (S.tab === 'avoirs' ? tabAvoirs() : S.tab === 'ech' ? tabEcheances() : S.tab === 'jr' ? tabJournal() : XT.tabs.some(function (t) { return t.id === S.tab; }) ? XT.tabs.filter(function (t) { return t.id === S.tab; })[0].html() : tabCloture()); S.msg = '';
    Array.prototype.forEach.call(o.querySelectorAll('.cpt_tabs button'), function (x) { x.onclick = function () { S.tab = x.getAttribute('data-t'); S.form = null; render(); }; });
    bind(o); XT.bind.forEach(function (fn) { try { fn(o); } catch (e) {} });
  }
  function on(id, fn) { var e = $(id); if (e) e.onclick = fn; }
  function bind(o) {
    var f = S.form;
    on('cp_new', function () { if (!can('factures', 'ecrire')) { S.msg = 'Droits insuffisants (factures).'; return render(); } S.form = { type: 'avoir' }; render(); });
    on('cp_no', function () { S.form = null; render(); });
    var sel = $('cp_inv'); if (sel) sel.onchange = function () { f.invoice_id = sel.value; f.ttc = ''; render(); };
    on('cp_full', function () { var i = invs().find(function (x) { return x.id === f.invoice_id; }); if (i) { f.ttc = r2(iTot(i).ttc - creditsOf(i.id)); f.motif = ($('cp_motif') || {}).value || ''; render(); } });
    on('cp_ok', function () { var r = createNote({ invoice_id: f.invoice_id, ttc: ($('cp_ttc') || {}).value, date: ($('cp_date') || {}).value, motif: ($('cp_motif') || {}).value }); if (r.error) { f.ttc = ($('cp_ttc') || {}).value; f.motif = ($('cp_motif') || {}).value; S.msg = r.error; return render(); } S.form = null; S.msg = 'Avoir ' + r.note.no + ' émis.' + (r.note.rembourser ? ' ⚠ ' + nf(r.note.rembourser) + ' ' + r.note.currency + ' déjà encaissés en trop : un remboursement est à prévoir.' : ''); render(); });
    Array.prototype.forEach.call(o.querySelectorAll('.cp_x'), function (x) { x.onclick = function () { var n = notes().find(function (z) { return z.id === x.getAttribute('data-id'); }); S.form = { type: 'annul', id: n.id, no: n.no }; render(); }; });
    on('cp_xno', function () { S.form = null; render(); });
    on('cp_xok', function () { var r = cancelNote(f.id, ($('cp_why') || {}).value); S.msg = r.error || 'Avoir annulé.'; if (!r.error) S.form = null; render(); });
    /* échéanciers */
    on('ep_start', function () { var v = ($('ep_pick') || {}).value; if (!v) return; if (!can('factures', 'ecrire')) { S.msg = 'Droits insuffisants (factures).'; return render(); } S.form = { type: 'ech', invoice_id: v, items: [] }; render(); });
    Array.prototype.forEach.call(o.querySelectorAll('.ep_edit'), function (x) { x.onclick = function () { var id = x.getAttribute('data-id'), s = scheds().find(function (z) { return z.invoice_id === id; }); S.form = { type: 'ech', invoice_id: id, items: s ? s.items.map(function (z) { return { due: z.due, amount: z.amount }; }) : [] }; render(); }; });
    function readRows() { var out = [], k = 0; while ($('ep_d' + k)) { out.push({ due: $('ep_d' + k).value, amount: $('ep_a' + k).value }); k++; } return out; }
    function tot() { var el = $('ep_tot'); if (el) el.textContent = nf(readRows().reduce(function (a, x) { return a + pn(x.amount); }, 0)); }
    on('ep_gen', function () { var i = invs().find(function (x) { return x.id === f.invoice_id; }); if (!i) return; var net = r2(iTot(i).ttc - creditsOf(i.id)), first = ($('ep_first') || {}).value; if (!/^\d{4}-\d{2}-\d{2}$/.test(first)) { S.msg = 'Date de première échéance invalide (AAAA-MM-JJ).'; return render(); } f.n = +($('ep_n') || {}).value || 1; f.first = first; f.step = Math.max(1, +($('ep_step') || {}).value || 1); f.unit = ($('ep_unit') || {}).value; f.items = buildSchedule(net, f.n, first, f.step, f.unit); render(); });
    Array.prototype.forEach.call(o.querySelectorAll('#ep_rows input'), function (x) { x.oninput = tot; }); tot();
    on('ep_ok', function () { var r = saveSchedule(f.invoice_id, readRows()); if (r.error) { f.items = readRows(); S.msg = r.error; return render(); } S.form = null; S.msg = 'Échéancier enregistré.'; render(); });
    on('ep_no', function () { S.form = null; render(); });
    /* journal */
    var c1 = $('jr_cur'); if (c1) c1.onchange = function () { S.cur = c1.value; render(); };
    var j1 = $('jr_j'); if (j1) j1.onchange = function () { S.jr = j1.value; render(); };
    ['jr_from', 'jr_to'].forEach(function (id) { var e = $(id); if (e) e.onchange = function () { S[id === 'jr_from' ? 'from' : 'to'] = /^\d{4}-\d{2}-\d{2}$/.test(e.value) ? e.value : ''; render(); }; });
    on('jr_csv', function () { var l = entries().filter(function (e) { return inPeriod(e, filt()); }); audit('compta.journal.export', 'journal', { lignes: l.length }); var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([toCsv(l)], { type: 'text/csv;charset=utf-8' })); a.download = 'journal-comptable-' + today() + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); });
    /* V178 : journal + balance en PDF de marque (en-tête société, QR de vérification public) — toutes les écritures de la période, pas seulement les 200 affichées */
    on('jr_pdf', function () {
      if (!w.EXBRapport) { say('Module d’export PDF indisponible.', 'error'); return; }
      var f = filt(), l = entries().filter(function (e) { return inPeriod(e, f); }), B = balance(l);
      var bal = table(['Compte', 'Intitulé', 'Débit', 'Crédit', 'Solde D', 'Solde C'], B.rows.map(function (r) { return '<tr>' + td(r.acc) + td(esc(ACC[r.acc] || '')) + td(nf(r.d), 'right') + td(nf(r.c), 'right') + td(r.sd ? nf(r.sd) : '', 'right') + td(r.sc ? nf(r.sc) : '', 'right') + '</tr>'; }));
      var jr = table(['Date', 'Jnl', 'Pièce', 'Libellé', 'Compte', 'Débit', 'Crédit'], l.map(function (e) { return '<tr>' + td(esc(e.date)) + td(e.jr) + td(esc(e.piece)) + td(esc(e.lib)) + td(e.acc + ' ' + esc(ACC[e.acc] || '')) + td(e.d ? nf(e.d) : '', 'right') + td(e.c ? nf(e.c) : '', 'right') + '</tr>'; }));
      audit('compta.journal.pdf', 'journal', { lignes: l.length });
      w.EXBRapport.print('Journal et balance comptables', { prefix: 'JRN', sousTitre: 'Devise ' + f.cur + ' · du ' + (f.from || 'début') + ' au ' + (f.to || 'ce jour') + (f.jr ? ' · journal ' + f.jr : ''), meta: [['Écritures', String(l.length)], ['Total débit', nf(B.td) + ' ' + f.cur], ['Total crédit', nf(B.tc) + ' ' + f.cur], ['Équilibre', B.ok ? 'oui' : 'NON — déséquilibre']], html: '<h2>Balance</h2>' + bal + '<h2>Journal</h2>' + jr, note: 'Plan comptable indicatif (type SYSCOHADA) : à valider avec le comptable. Chaque devise est séparée, sans conversion.', paysage: true });
    });
    Array.prototype.forEach.call(o.querySelectorAll('.jr_gl'), function (x) { x.onclick = function (ev) { ev.preventDefault(); S.acc = x.getAttribute('data-acc'); render(); }; });
    on('jr_glx', function () { S.acc = ''; render(); });
    /* clôture */
    on('cl_ok', function () { if (!can('factures', 'ecrire')) { S.msg = 'Droits insuffisants.'; return render(); } var ym = ($('cl_ym') || {}).value; S.cm = ym; closeMonth(ym).then(function (r) { S.msg = r.error || 'Mois ' + ym + ' clôturé.'; render(); }); });
    Array.prototype.forEach.call(o.querySelectorAll('.cl_re'), function (x) { x.onclick = function () { S.form = { type: 'reopen', ym: x.getAttribute('data-ym') }; render(); }; });
    on('cl_rno', function () { S.form = null; render(); });
    on('cl_rok', function () { var r = reopen(f.ym, ($('cl_why') || {}).value); S.msg = r.error || 'Mois rouvert.'; if (!r.error) S.form = null; render(); });
    Array.prototype.forEach.call(o.querySelectorAll('.cl_state'), function (x) { var rec = LD(K.cl, []).find(function (z) { return z.ym === x.getAttribute('data-ym') && !z.reopened; }); if (!rec) return; verifyClose(rec).then(function (v) { x.innerHTML = v.ok ? '<span style="color:#16a34a">✔ OK</span>' : '<span style="color:#dc2626">⚠ modifié depuis la clôture (' + v.was + ' → ' + v.now + ' écritures)</span>'; }); });
  }
  function open() {
    var o = $('cpt_ov'); if (o) o.remove(); o = d.createElement('div'); o.id = 'cpt_ov';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.innerHTML = '<div style="background:var(--card,#fff);color:var(--fg,#0f172a);width:100%;max-width:940px;border-radius:12px;padding:14px;box-sizing:border-box"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">📒 Finances & comptabilité</h3><button id="cpt_x" type="button" aria-label="Fermer">✕</button></div><div class="cpt_tabs" style="margin:8px 0"></div><div class="cpt_body"></div></div>';
    d.body.appendChild(o); $('cpt_x').onclick = function () { o.remove(); }; S.form = null; audit('compta.ouvert', 'comptabilité', who()); render();
  }
  function mount() { var ref = $('bbfin') || $('bcompta'); if (ref && !$('bcpt')) { var b = d.createElement('button'); b.id = 'bcpt'; b.type = 'button'; b.textContent = '📒 Compta : avoirs, échéances, journal'; b.onclick = open; ref.parentNode.insertBefore(b, ref.nextSibling); } }
  function start() { mount(); var n = 0, t = setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} if ($('bcpt') || ++n > 40) clearInterval(t); }, 1500); try { w.EXBCore && w.EXBCore.modules.register({ id: 'compta', name: 'Finances & comptabilité', version: '166.0.0', area: 'Gestion & finances' }); } catch (e) {} }
  w.EXBCOMPTA = { _x: { depAcc: depAcc, XT: XT, ACC: ACC, S: S, LD: LD, SV: SV, uid: uid, who: who, audit: audit, say: say, can: can, nf: nf, r2: r2, pn: pn, esc: esc, norm: norm, today: today, cur: cur, table: table, td: td, btn: btn, inp: inp, on: on, curOpts: curOpts, inPeriod: inPeriod, balance: balance, entries: entries, render: render, K: K, csvCell: csvCell, filt: filt }, open: open, creditsOf: creditsOf, netDue: netDue, _t: { createNote: createNote, cancelNote: cancelNote, buildSchedule: buildSchedule, allocate: allocate, saveSchedule: saveSchedule, entries: entries, balance: balance, toCsv: toCsv, closeMonth: closeMonth, verifyClose: verifyClose, reopen: reopen, overdueList: overdueList, periodFingerprint: periodFingerprint } };
  if (d) { if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start(); }
})(window);
