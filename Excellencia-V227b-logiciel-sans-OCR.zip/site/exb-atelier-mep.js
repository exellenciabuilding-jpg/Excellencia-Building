/* Excellencia Building V209 — ATELIER DE MISE EN PAGE (module du Bureau d'études ingénieur).
 * Habille des PDF techniques (plans, notes de calcul, rapports, dossiers complets) SANS modifier l'original : import archivé par empreinte SHA-256,
 * analyse des pages, cartouche / couverture / sommaire / pagination, aperçu avant-après, circuit de validation, versions et journal d'audit.
 * Le module vit dans atelier-mep/index.html (cadre de la page, même origine) : il lit l'identité (EXBId), les projets (exb_projects), les droits (EXBAction)
 * et le stockage (exbStorage). Aucune fonction existante n'est modifiée.
 * Pour retirer le module : supprimer la balise <script src="exb-atelier-mep.js"> de index.html. */
(function (w, d) {
  'use strict';
  var URL_ED = 'atelier-mep/index.html', $ = function (i) { return d.getElementById(i); };
  function exposeStorage() { try { if (!w.exbStorage && typeof exbStorage !== 'undefined') w.exbStorage = exbStorage; } catch (e) { /* inaccessible */ } }
  exposeStorage();
  function css() {
    if ($('exbAtelierMepCss')) return; var s = d.createElement('style'); s.id = 'exbAtelierMepCss';
    s.textContent = '#atelierMep .am-wrap{border:1px solid #d5dbe5;border-radius:14px;overflow:hidden;background:#f4f4f4;box-shadow:0 6px 24px #0f2e6618}'
      + '#atelierMep iframe{display:block;width:100%;height:calc(100vh - 150px);min-height:680px;border:0;background:#fff}'
      + '@media(max-width:700px){#atelierMep iframe{height:calc(100vh - 130px);min-height:620px}}';
    d.head.appendChild(s);
  }
  function build() {
    var sec = d.createElement('section'); sec.id = 'atelierMep'; sec.style.display = 'none';
    sec.innerHTML = '<div class="card"><h2>🖨️ Atelier de mise en page</h2><p class="hint">Plans, notes de calcul, rapports et dossiers PDF : cartouche, couverture, sommaire, pagination et validation — le contenu technique d’origine n’est jamais modifié.</p><div class="am-wrap"><iframe id="exbAtelierMepFrame" title="Atelier de mise en page" loading="lazy" allow="fullscreen"></iframe></div></div>';
    return sec;
  }
  function mount() {
    exposeStorage();
    if ($('atelierMep')) return;
    var ref = $('planCartouche') || $('planEditeur') || $('calcStructure') || $('bureauEtudes') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, sec = build(); css();
    if (ref && ref.parentNode) ref.parentNode.insertBefore(sec, ref.nextSibling); else host.appendChild(sec);
    var anchor = $('bplancart') || $('bplanedit') || $('bbet') || $('bdev'), par = anchor && anchor.parentNode;
    if (par && !$('batelier')) { var b = d.createElement('button'); b.id = 'batelier'; b.type = 'button'; b.textContent = '🖨️ Atelier de mise en page'; b.setAttribute('onclick', "show('atelierMep')"); par.insertBefore(b, anchor.nextSibling); }
    var os = w.show;
    if (typeof os === 'function' && !w.__exbAtelierMepShow) {
      w.__exbAtelierMepShow = 1;
      w.show = function (x) {
        var r = os.apply(this, arguments), e = $('atelierMep');
        if (e) {
          e.style.display = (x === 'atelierMep') ? '' : 'none';
          if (x === 'atelierMep') { var f = $('exbAtelierMepFrame'); if (f && !f.getAttribute('src')) f.setAttribute('src', URL_ED); else if (f) { try { var E = f.contentWindow.EXBATELIER; if (E && E.refresh) E.refresh(); } catch (er) {} } }
        }
        var b2 = $('batelier'); if (b2) b2.classList.toggle('active', x === 'atelierMep'); return r;
      };
    }
  }
  /* V221 : éditeur « façon Word » du logiciel (ruban Fichier · Accueil · Insertion · Mise en page · Références · Révision · Affichage, export Word .docx)
   * ouvert en fenêtre pour rédiger le texte ajouté à une note de calcul. opts = { titre, texte, appliquer(texte) } ; renvoie false si l'éditeur n'est pas disponible. */
  var wmodal = null;
  function wcss() {
    if ($('exbAtelierWordCss')) return; var s = d.createElement('style'); s.id = 'exbAtelierWordCss';
    s.textContent = '#exbamModal{position:fixed;inset:0;z-index:100500;background:rgba(15,23,42,.6);display:flex;align-items:stretch;justify-content:center;padding:10px}'
      + '#exbamBox{background:#dfe6f2;border-radius:12px;width:min(1180px,100%);display:flex;flex-direction:column;min-height:0;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.45)}'
      + '#exbamBar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#173565;color:#fff;padding:8px 12px;font:700 14px Arial,sans-serif}#exbamBar span{flex:1;min-width:160px}'
      + '#exbamBar button{padding:9px 14px;border-radius:9px;border:1px solid #fff5;background:#ffffff1a;color:#fff;font:700 13px Arial,sans-serif;cursor:pointer}#exbamBar button.ok{background:#c49a38;border-color:#c49a38;color:#12254a}'
      + '#exbamHint{background:#fff8e1;color:#5d4b0a;font:12.5px Arial,sans-serif;padding:6px 12px;border-bottom:1px solid #e6d9a2}'
      + '#exbamBody{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden}#exbamBody #exbEd{margin:0;border:0;border-radius:0;flex:1;min-height:0;display:flex;flex-direction:column}#exbamBody #exbEdWrap{flex:1;max-height:none;min-height:0}'
      + '@media print{#exbamModal{display:none!important}}';
    d.head.appendChild(s);
  }
  function editWord(opts) {
    var ED = w.EXBPIE_ED, X = w.EXBPIE_X; opts = opts || {};
    if (!ED || !ED.attach || !X) return false;
    if (wmodal) return true;
    if ($('exbEd')) { try { w.EXB81 && w.EXB81.say && w.EXB81.say('Fermez d’abord la pièce écrite en cours d’édition (Pièces écrites), puis réessayez.', 'error'); } catch (e) {} return false; }
    wcss();
    wmodal = d.createElement('div'); wmodal.id = 'exbamModal';
    wmodal.innerHTML = '<div id="exbamBox" role="dialog" aria-label="Éditeur Word — texte de la note"><div id="exbamBar"><span>✍️ ' + String(opts.titre || 'Texte de la note').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }) + ' — éditeur Word</span><button type="button" id="exbamCancel">Annuler</button><button type="button" class="ok" id="exbamOk">✓ Appliquer à la note</button></div>'
      + '<div id="exbamHint">Ce texte est ajouté sur des feuilles supplémentaires à la suite de la note, avec le bandeau et le pied de page habituels. Titres (« Titre 1 / 2 »), listes et gras sont repris ; la mise en forme fine (couleurs, polices, images) n’est pas reportée sur le PDF.</div>'
      + '<div id="exbamBody"><textarea id="exbamTa" style="display:none"></textarea></div></div>';
    d.body.appendChild(wmodal);
    var ta = $('exbamTa'), start = String(opts.texte || ''), done = false; ta.value = start;
    function close() { try { ED.detach(); } catch (e) {} if (wmodal) { wmodal.remove(); wmodal = null; } }
    function apply() { if (done) return; done = true; try { ED.sync(); } catch (e) {} var md = ta.value; close(); try { if (opts.appliquer) opts.appliquer(md); } catch (e) {} }
    async function cancel() {
      try { ED.sync(); } catch (e) {}
      if (ta.value !== start && typeof w.exbConfirm === 'function' && !(await w.exbConfirm('Fermer sans appliquer vos modifications ?'))) return;
      close();
    }
    $('exbamOk').onclick = apply; $('exbamCancel').onclick = cancel;
    wmodal.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !$('exbEdPop') && !($('exbEdFind') && $('exbEdFind').contains(d.activeElement))) { ev.stopPropagation(); cancel(); } });
    ED.attach({ fmt: 'A4', ori: 'portrait' }, false, { ta: ta, noIdentity: true, forceWord: true, fileName: String(opts.titre || 'texte-note').replace(/[^\w\- ]+/g, '').slice(0, 60) || 'texte-note', hide: ['print', 'saveMod', 'dup', 'fillv', 'back', 'mode'], actions: { save: apply } });
    var sv = wmodal.querySelector('button[data-c="save"]'); if (sv) { sv.title = 'Appliquer à la note (Ctrl+S)'; var lb = sv.querySelector('.lb,span:last-child'); if (lb && /nregistrer/.test(lb.textContent)) lb.textContent = 'Appliquer'; }
    return true;
  }
  w.EXBATELIERMEP = { editWord: editWord, open: function () { exposeStorage(); if (!$('atelierMep')) mount(); if (typeof w.show === 'function') w.show('atelierMep'); try { w.scrollTo(0, 0); } catch (e) {} }, version: 'V221' };
  function start() { setTimeout(mount, 950); }
  if (d.readyState === 'complete') start(); else w.addEventListener('load', start);
})(window, document);
