/* V186 : + onglet « 🔍 Revue des accès » (revue PÉRIODIQUE des comptes : échéance 30/90/180 j, décision par membre, écarts depuis la dernière revue, historique journalisé).
 * Excellencia Building V152 — Administration avancée (module 14) : consultation du journal d'audit CORE, matrice des droits de la session, accès & santé.
 * Lecture seule : ne modifie aucune donnée, aucun compte. Le serveur reste l'autorité des droits. Retrait : supprimer la balise <script src="exb-admin.js">. */
(function (w) {
  'use strict';
  var d = w.document, $ = function (i) { return d.getElementById(i); };
  var COLS = ['projets', 'clients', 'devis', 'metres', 'stock', 'mouvements', 'personnel', 'caisse', 'factures', 'etudes', 'communication', 'documents', 'commandes', 'journal', 'pointages', 'situations', 'fournisseurs', 'notes_calcul', 'plans', 'missions_be', 'heures_be', 'planning_chantier', 'budgets_chantier', 'crm', 'contrats', 'rfis', 'submittals', 'avenants', 'engagements', 'risques', 'reunions', 'reserves', 'parc_materiel', 'qhse', 'cde', 'bim_issues', 'evm', 'maintenance', 'risk_register', 'client_portal', 'price_library', 'estimates', 'benchmarks', 'ai_notes', 'portails', 'drawing_sheets', 'drawing_sets', 'autorisations'];
  var RVK = 'exb_admin_revue';
  var state = { rv: null, rvMsg: '', rvDec: {}, tab: 'audit', q: '', last: null, dev: null, devMsg: '' };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function info() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || { on: false }; } catch (e) { return { on: false }; } }
  function allowed() { var i = info(); return !i.on || i.role === 'admin' || i.fonction === 'polyvalent'; }
  function can(c, m) { try { return w.EXBDB && w.EXBDB.can ? !!w.EXBDB.can(c, m) : true; } catch (e) { return true; } }
  function audit(a, o, x) { try { w.EXBCore && w.EXBCore.audit.log(a, o, x); } catch (e) {} }
  function fdate(t) { try { return new Date(t).toLocaleString('fr-FR'); } catch (e) { return t || ''; } }
  function rows() { try { return w.EXBCore ? w.EXBCore.audit.list().slice().reverse() : []; } catch (e) { return []; } }
  function match(e, q) { q = String(q || '').toLowerCase().trim(); if (!q) return true; return [e.action, e.obj, e.user, e.d].join(' ').toLowerCase().indexOf(q) >= 0; }
  function csvCell(v) { v = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
  function toCsv(list) { var h = ['n', 'date', 'utilisateur', 'action', 'objet', 'detail', 'empreinte']; return '\ufeff' + [h.map(csvCell).join(';')].concat(list.map(function (e) { return [e.n, e.t, e.user, e.action, e.obj, e.d, e.h].map(csvCell).join(';'); })).join('\r\n'); }

  function tabAudit() {
    var all = rows(), list = all.filter(function (e) { return match(e, state.q); }), shown = list.slice(0, 100);
    var v = state.last ? '<div id="adm_v" style="padding:8px;border-radius:8px;margin:8px 0;background:' + (state.last.ok ? '#e6f6ea' : '#fde8e8') + '">' + (state.last.ok ? '✅ Chaîne intègre — ' + state.last.entries + ' entrées vérifiées.' : '⛔ Chaîne rompue : ' + state.last.broken + ' entrée(s) ; première anomalie n° ' + state.last.firstBroken + '.') + '</div>' : '<div id="adm_v"></div>';
    return '<p><input id="adm_q" value="' + esc(state.q) + '" placeholder="Filtrer (action, objet, utilisateur)" style="width:100%;box-sizing:border-box;padding:8px"></p>' +
      '<p><button id="adm_ver">🔗 Vérifier la chaîne</button> <button id="adm_csv">⬇ Exporter CSV</button> <button id="adm_pdf">🖨 PDF</button></p>' + v +
      '<p style="font-size:12px;color:#64748b">' + list.length + ' entrée(s) correspondante(s) sur ' + all.length + ' conservées sur cet appareil (500 max, les plus anciennes sont retirées). Affichage : 100 plus récentes.</p>' +
      '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12px"><thead><tr style="text-align:left;background:#f1f5fb"><th>N°</th><th>Date</th><th>Utilisateur</th><th>Action</th><th>Objet</th></tr></thead><tbody>' +
      shown.map(function (e) { return '<tr style="border-top:1px solid #e2e8f0" title="' + esc(e.d) + '"><td>' + e.n + '</td><td>' + esc(fdate(e.t)) + '</td><td>' + esc(e.user) + '</td><td>' + esc(e.action) + '</td><td>' + esc(e.obj) + '</td></tr>'; }).join('') + '</tbody></table></div>';
  }
  function tabDroits() {
    var i = info();
    if (!i.on) return '<p>Mode local sans organisation : aucun contrôle de droits n\'est appliqué sur cet appareil (tout est permis).</p>';
    var tr = COLS.map(function (c) { var r = can(c, 'lire'), e = can(c, 'ecrire'); return '<tr style="border-top:1px solid #e2e8f0"><td>' + esc(c) + '</td><td style="text-align:center">' + (r ? '✔' : '—') + '</td><td style="text-align:center">' + (e ? '✔' : '—') + '</td></tr>'; }).join('');
    return '<p>Session : <b>' + esc(i.label || i.fonction || i.role || '?') + '</b> (rôle : ' + esc(i.role || '?') + ').</p><p style="font-size:12px;color:#64748b">Droits effectifs de <b>votre</b> session, tels que l\'écran les applique. La matrice de tous les comptes se gère côté serveur (Supabase) ; cet écran ne la modifie pas.</p>' +
      '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:13px"><thead><tr style="text-align:left;background:#f1f5fb"><th>Collection</th><th>Lire</th><th>Écrire</th></tr></thead><tbody>' + tr + '</tbody></table></div>';
  }
  function tabAcces() {
    return '<p id="adm_h">Chargement…</p>';
  }
  function fillAcces() {
    if (!w.EXBCore) return; w.EXBCore.health().then(function (h) {
      var el = $('adm_h'); if (!el) return; var dev = h.device && typeof h.device === 'object' ? JSON.stringify(h.device) : h.device;
      el.innerHTML = '<ul style="padding-left:18px;line-height:1.6"><li>Version : <b>' + esc(h.build) + '</b> (noyau ' + esc(h.core) + ')</li><li>Utilisateur : ' + esc(h.user) + '</li><li>Appareil : ' + esc(dev) + '</li><li>Connexion : ' + (h.online ? 'en ligne' : 'hors ligne') + '</li><li>Dernière sauvegarde : ' + esc(h.lastBackup || 'aucune enregistrée') + '</li><li>Stockage local : ' + esc(h.storageKB) + ' Ko</li><li>Journal d\'audit : ' + (h.auditChain && h.auditChain.ok ? '✅ intègre' : '⛔ anomalie') + '</li><li>Modules déclarés : ' + esc(h.modules && h.modules.declared) + ' — problèmes : ' + esc(h.modules && h.modules.issues && h.modules.issues.length) + '</li></ul><p style="font-size:12px;color:#64748b">Non couvert ici : sessions et appareils des autres comptes, délégations, suspension de comptes (à faire côté serveur).</p>';
    });
  }

  /* ---------- V175 : sessions & appareils (licence) ---------- */
  function lsg(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function srvUrl() { try { return (w.EXBLIC && w.EXBLIC.CFG && w.EXBLIC.CFG.server) || ''; } catch (e) { return ''; } }
  function myDev() { try { return w.EXBLIC && w.EXBLIC.deviceId ? w.EXBLIC.deviceId() : ''; } catch (e) { return ''; } }
  function ago(iso) { var t = Date.parse(iso); if (isNaN(t)) return '—'; var m = Math.max(0, Math.round((Date.now() - t) / 60000)); return m < 2 ? 'à l’instant' : m < 90 ? m + ' min' : m < 2880 ? Math.round(m / 60) + ' h' : Math.round(m / 1440) + ' j'; }
  function sess(dt) { var t = Date.parse(dt); if (isNaN(t)) return ['—', '#64748b']; var h = (Date.now() - t) / 36e5; return h < 24 ? ['actif', '#166534'] : h < 168 ? ['récent', '#b45309'] : ['inactif', '#991b1b']; }
  function lic(body) {
    var u = srvUrl(); if (!u) return Promise.reject(new Error('Serveur de licences non configuré dans cette édition.'));
    if (navigator.onLine === false) return Promise.reject(new Error('Connexion internet requise.'));
    return fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(function (r) { return r.json().catch(function () { return { ok: false, msg: 'Réponse illisible du serveur.' }; }); });
  }
  function tabAppareils() {
    var i = info(), lastChk = lsg('exb_lic_chk'), me = myDev();
    var h = '<h4 style="margin:0 0 6px">Cette session</h4><ul style="padding-left:18px;line-height:1.6;margin:0 0 12px"><li>Utilisateur : <b>' + esc(i.label || i.role || 'local') + '</b>' + (i.role ? ' (' + esc(i.role) + ')' : '') + '</li><li>Appareil : <b>' + esc(me || '—') + '</b></li><li>Connexion : ' + (navigator.onLine === false ? 'hors ligne' : 'en ligne') + '</li><li>Dernière vérification de la licence : ' + (lastChk && !isNaN(Number(lastChk)) ? esc(fdate(Number(lastChk))) : 'jamais sur cet appareil') + '</li></ul>';
    h += '<h4 style="margin:0 0 6px">Appareils enregistrés sur la licence</h4><p style="font-size:12px;color:#64748b;margin:0 0 8px">Saisissez le <b>code d’activation</b> de l’entreprise (EXC-XXXX-XXXX-XXXX). Il n’est ni conservé ni journalisé : il sert uniquement à interroger le serveur de licences.</p>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px"><input id="adm_code" type="password" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="EXC-XXXX-XXXX-XXXX" style="flex:1 1 200px;padding:8px;border:1px solid #9aafc6;border-radius:8px"><button id="adm_dev_go" style="padding:8px 12px">📱 Afficher les appareils</button></div><div id="adm_dev_out">' + devOut() + '</div>' +
      '<p style="font-size:12px;color:#64748b;margin-top:10px">Libérer un appareil le déconnecte : à sa prochaine vérification (au plus tard après la durée hors ligne autorisée) il redemandera le code d’activation et reprendra une place s’il y en a une. Les comptes et sessions des autres utilisateurs ne sont pas gérés ici : ils dépendent du serveur de données (Supabase).</p>';
    return h;
  }
  function devOut() {
    var r = state.dev; if (state.devMsg) return '<p style="background:#fff7e6;border:1px solid #f0c36d;padding:8px;border-radius:8px">' + esc(state.devMsg) + '</p>'; if (!r) return '';
    var me = String(myDev()).replace(/-/g, '');
    return '<p><b>' + esc(r.nom) + '</b> — statut : ' + esc(r.statut) + ' — échéance : ' + esc(fdate(r.exp).slice(0, 10)) + ' — appareils : <b>' + r.appareils.length + ' / ' + r.max + '</b></p>' +
      '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12px"><thead><tr style="text-align:left;background:#f1f5fb"><th>Appareil</th><th>Type</th><th>Version</th><th>Dernière activité</th><th>Session</th><th></th></tr></thead><tbody>' +
      (r.appareils.length ? r.appareils.map(function (a) { var s = sess(a.dernier_vu), mine = String(a.device).replace(/-/g, '') === me; return '<tr style="border-top:1px solid #e2e8f0"><td><b>' + esc(a.device) + '</b>' + (mine ? ' <i>(cet appareil)</i>' : '') + '<br><small>' + esc(a.libelle || '') + '</small></td><td>' + esc(a.plateforme || '—') + '</td><td>' + esc(a.version || '—') + '</td><td>' + esc(ago(a.dernier_vu)) + '<br><small>' + esc(fdate(a.dernier_vu)) + '</small></td><td style="color:' + s[1] + ';font-weight:700">' + s[0] + '</td><td><button data-rel="' + esc(a.device) + '" style="padding:6px 9px">Libérer</button></td></tr>'; }).join('') : '<tr><td colspan="6">Aucun appareil enregistré.</td></tr>') + '</tbody></table></div>';
  }
  function bindAppareils() {
    var go = $('adm_dev_go'); if (!go) return;
    function refresh(msg) { state.devMsg = msg || ''; var o = $('adm_dev_out'); if (o) { o.innerHTML = devOut(); bindRel(); } }
    function bindRel() { Array.prototype.forEach.call(d.querySelectorAll('#adm_dev_out [data-rel]'), function (b) { b.onclick = function () { release(b.getAttribute('data-rel')); }; }); }
    var code = function () { return String(($('adm_code') || {}).value || '').trim(); };
    function release(dev) {
      var mine = String(dev).replace(/-/g, '') === String(myDev()).replace(/-/g, '');
      var q = 'Libérer l’appareil ' + dev + ' ?' + (mine ? '\n\nC’EST CET APPAREIL : il sera déconnecté et demandera à nouveau le code d’activation.' : '\n\nIl sera déconnecté à sa prochaine vérification de licence.');
      (w.exbConfirm ? w.exbConfirm(q) : Promise.resolve(w.confirm(q))).then(function (okk) {
        if (!okk) return;
        lic({ action: 'release_own', code: code(), device: dev }).then(function (j) {
          if (!j.ok) return refresh(j.msg || 'Libération refusée.');
          audit('admin.appareil.libere', 'licence', { appareil: dev, cetAppareil: mine });
          return lic({ action: 'devices', code: code() }).then(function (k) { state.dev = k.ok ? k : null; refresh(k.ok ? '' : (k.msg || '')); });
        }).catch(function (e) { refresh(e.message || String(e)); });
      });
    }
    go.onclick = function () {
      if (!code()) return refresh('Saisissez le code d’activation.');
      refresh('Interrogation du serveur…');
      lic({ action: 'devices', code: code() }).then(function (j) { if (!j.ok) { state.dev = null; return refresh(j.msg || 'Refusé par le serveur.'); } state.dev = j; audit('admin.appareils.consultes', 'licence', { n: j.appareils.length }); refresh(''); }).catch(function (e) { state.dev = null; refresh(e.message || String(e)); });
    };
    bindRel();
  }

  /* ---------- V186 : revue périodique des accès (fonctions pures : testables) ---------- */
  var PERIODES = [30, 90, 180];
  function rvRead() { try { var v = JSON.parse(w.localStorage.getItem(RVK) || '{}'); v = v && typeof v === 'object' ? v : {}; v.hist = Array.isArray(v.hist) ? v.hist : []; v.periode = PERIODES.indexOf(+v.periode) >= 0 ? +v.periode : 90; return v; } catch (e) { return { periode: 90, hist: [] }; } }
  function rvWrite(v) { try { w.localStorage.setItem(RVK, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function addDays(t, n) { var x = new Date(String(t).slice(0, 10) + 'T00:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); }
  function rvEtat(st, t) {
    t = String(t || new Date().toISOString()).slice(0, 10); var last = st && st.hist && st.hist.length ? st.hist[0] : null, per = (st && st.periode) || 90;
    if (!last) return { due: true, jamais: true, echeance: t, jours: 0, periode: per };
    var ech = addDays(last.le, per), j = Math.round((Date.parse(t + 'T00:00:00Z') - Date.parse(ech + 'T00:00:00Z')) / 864e5);
    return { due: j >= 0, jamais: false, echeance: ech, jours: j, periode: per, derniere: last.le, par: last.par };
  }
  /* écarts entre les membres actuels et la photo prise à la dernière revue */
  function rvEcarts(membres, last) {
    var snap = (last && last.snapshot) || [], cur = {}, old = {}, o = { nouveaux: [], retires: [], modifies: [] };
    (membres || []).forEach(function (m) { cur[m.user_id] = m; }); snap.forEach(function (m) { old[m.id] = m; });
    Object.keys(cur).forEach(function (id) { var m = cur[id], a = old[id]; if (!a) o.nouveaux.push(m); else if (a.role !== m.role || a.fonction !== m.fonction) o.modifies.push({ m: m, avant: a }); });
    Object.keys(old).forEach(function (id) { if (!cur[id]) o.retires.push(old[id]); });
    return o;
  }
  /* clôture : chaque membre doit avoir une décision (maintenir / retirer) ; un relecteur est exigé */
  function rvCloturer(st, membres, dec, par, t) {
    par = String(par || '').trim(); if (!par) return { err: 'Nom du relecteur requis.' };
    if (!membres || !membres.length) return { err: 'Aucun compte à revoir (liste non chargée).' };
    var manque = membres.filter(function (m) { return dec[m.user_id] !== 'maintenir' && dec[m.user_id] !== 'retirer'; });
    if (manque.length) return { err: manque.length + ' compte(s) sans décision.' };
    var e = { le: String(t || new Date().toISOString()).slice(0, 10), par: par, n: membres.length,
      maintenus: membres.filter(function (m) { return dec[m.user_id] === 'maintenir'; }).length,
      aRetirer: membres.filter(function (m) { return dec[m.user_id] === 'retirer'; }).map(function (m) { return { id: m.user_id, nom: m.nom || '', email: m.email || '', role: m.role || '', fonction: m.fonction || '' }; }),
      snapshot: membres.map(function (m) { return { id: m.user_id, role: m.role || '', fonction: m.fonction || '' }; }) };
    var o = JSON.parse(JSON.stringify(st || { periode: 90, hist: [] })); o.hist = [e].concat(o.hist || []).slice(0, 12);
    return { st: o, entree: e };
  }
  function rvCsv(e) {
    var L = [['Revue des accès', e.le, 'Relecteur', e.par].map(csvCell).join(';'), ['Membre', 'E-mail', 'Rôle', 'Fonction', 'Décision'].map(csvCell).join(';')];
    (e.aRetirer || []).forEach(function (m) { L.push([m.nom, m.email, m.role, m.fonction, 'À retirer'].map(csvCell).join(';')); });
    L.push(['Maintenus', e.maintenus].map(csvCell).join(';')); return '﻿' + L.join('\r\n');
  }
  function rvLoad() {
    state.rv = { loading: true }; state.rvMsg = '';
    var sb = w.exbSb; if (!(sb && sb.api && sb.isIn && sb.isIn())) { state.rv = { off: true }; render(); return; }
    var rpc = function (n, b) { return sb.api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); };
    rpc('mon_organisation').then(function (o) { if (!o || !o.id) throw new Error('Organisation introuvable.'); return rpc('equipe_liste', { p_org: o.id }); })
      .then(function (r) { state.rv = { membres: (r && r.membres) || [] }; state.rvDec = {}; render(); })
      .catch(function (e) { state.rv = { err: String((e && e.message) || e) }; render(); });
  }
  function tabRevue() {
    var st = rvRead(), et = rvEtat(st), h = '';
    h += '<div style="padding:8px;border-radius:8px;margin:0 0 8px;background:' + (et.due ? '#fff7e0' : '#e6f6ea') + '">' + (et.jamais ? '🔔 Aucune revue des accès enregistrée : à faire maintenant.' : et.due ? '🔔 Revue en retard de ' + et.jours + ' jour(s) (échéance ' + esc(et.echeance) + ').' : '✅ Dernière revue le ' + esc(et.derniere) + ' par ' + esc(et.par) + ' · prochaine avant le ' + esc(et.echeance) + '.') + '</div>';
    h += '<p><label>Fréquence de revue <select id="rv_per">' + PERIODES.map(function (n) { return '<option value="' + n + '"' + (st.periode === n ? ' selected' : '') + '>tous les ' + n + ' jours</option>'; }).join('') + '</select></label> <button id="rv_go" type="button">🔍 ' + (state.rv && state.rv.membres ? 'Recharger les comptes' : 'Démarrer la revue') + '</button></p>';
    var R = state.rv;
    if (R && R.loading) h += '<p>Chargement des comptes…</p>';
    else if (R && R.off) h += '<p>Revue des comptes impossible : connexion à l’entreprise en ligne requise (mode local : un seul utilisateur, aucun compte à revoir).</p>';
    else if (R && R.err) h += '<p style="color:#b91c1c">Comptes indisponibles : ' + esc(R.err) + ' (réservé à l’administrateur de l’entreprise).</p>';
    else if (R && R.membres) {
      var ec = rvEcarts(R.membres, st.hist[0]);
      if (st.hist[0]) h += '<p style="font-size:13px">Depuis la dernière revue : ' + ec.nouveaux.length + ' nouveau(x) compte(s), ' + ec.retires.length + ' retiré(s), ' + ec.modifies.length + ' rôle(s)/fonction(s) modifié(s).</p>';
      h += '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:13px"><thead><tr style="text-align:left;background:#f1f5fb"><th>Membre</th><th>Rôle</th><th>Fonction</th><th>Décision</th></tr></thead><tbody>' + R.membres.map(function (m) {
        var nv = ec.nouveaux.indexOf(m) >= 0, md = ec.modifies.some(function (x) { return x.m === m; }), dc = state.rvDec[m.user_id] || '';
        return '<tr style="border-top:1px solid #e2e8f0"><td><b>' + esc(m.nom || '—') + '</b>' + (nv ? ' <small>(nouveau)</small>' : '') + (md ? ' <small>(modifié)</small>' : '') + '<br><small>' + esc(m.email || '') + '</small></td><td>' + esc(m.role || '') + '</td><td>' + esc(m.fonction || '') + '</td><td><select data-rv="' + esc(m.user_id) + '"><option value="">— choisir —</option><option value="maintenir"' + (dc === 'maintenir' ? ' selected' : '') + '>Maintenir</option><option value="retirer"' + (dc === 'retirer' ? ' selected' : '') + '>À retirer</option></select></td></tr>';
      }).join('') + '</tbody></table></div>' +
      '<p><button id="rv_all" type="button">Tout maintenir</button> <label>Relecteur <input id="rv_par" placeholder="Nom" style="width:11em"></label> <button id="rv_fin" type="button">✔ Terminer la revue</button></p>' +
      '<p style="font-size:12px;color:#64748b">Les comptes « À retirer » sont listés dans le compte rendu ; le retrait lui-même se fait dans Paramètres › 👥 Équipe (cette revue ne supprime aucun accès).</p>';
    }
    if (state.rvMsg) h += '<p id="rv_msg" style="font-weight:600">' + esc(state.rvMsg) + '</p>';
    h += '<h4 style="margin:12px 0 4px">Historique des revues</h4>' + (st.hist.length ? '<ul style="font-size:13px;line-height:1.6">' + st.hist.map(function (e, i) { return '<li>' + esc(e.le) + ' · ' + esc(e.par) + ' · ' + e.n + ' compte(s) : ' + e.maintenus + ' maintenu(s), ' + (e.aRetirer || []).length + ' à retirer <button type="button" data-rvcsv="' + i + '">⬇ CSV</button></li>'; }).join('') + '</ul>' : '<p style="font-size:13px;color:#64748b">Aucune revue enregistrée.</p>');
    return h;
  }
  function bindRevue() {
    var per = $('rv_per'); if (per) per.onchange = function () { var s = rvRead(); s.periode = +per.value; rvWrite(s); audit('admin.revue.periode', 'acces', { jours: s.periode }); render(); };
    var go = $('rv_go'); if (go) go.onclick = rvLoad;
    Array.prototype.forEach.call(d.querySelectorAll('[data-rv]'), function (x) { x.onchange = function () { state.rvDec[x.getAttribute('data-rv')] = x.value; }; });
    var all = $('rv_all'); if (all) all.onclick = function () { (state.rv.membres || []).forEach(function (m) { state.rvDec[m.user_id] = 'maintenir'; }); render(); };
    var fin = $('rv_fin'); if (fin) fin.onclick = function () {
      var r = rvCloturer(rvRead(), state.rv.membres, state.rvDec, ($('rv_par') || {}).value);
      if (r.err) { state.rvMsg = r.err; render(); return; }
      rvWrite(r.st); audit('admin.revue.terminee', 'acces', { n: r.entree.n, aRetirer: r.entree.aRetirer.length }); state.rvMsg = '✅ Revue enregistrée (' + r.entree.n + ' comptes, ' + r.entree.aRetirer.length + ' à retirer).'; state.rvDec = {}; render();
    };
    Array.prototype.forEach.call(d.querySelectorAll('[data-rvcsv]'), function (x) { x.onclick = function () { var e = rvRead().hist[+x.getAttribute('data-rvcsv')]; if (!e) return; audit('admin.revue.export', 'acces', {}); var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([rvCsv(e)], { type: 'text/csv;charset=utf-8' })); a.download = 'revue-acces-' + e.le + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); }; });
  }
  function render() {
    var o = $('adm_ov'); if (!o) return;
    var T = [['audit', '📜 Audit'], ['droits', '🔑 Droits'], ['appareils', '📱 Sessions & appareils'], ['revue', '🔍 Revue des accès'], ['acces', '🩺 Accès & santé']];
    o.querySelector('.adm_tabs').innerHTML = T.map(function (t) { return '<button data-t="' + t[0] + '" style="padding:8px 10px;margin-right:4px;' + (state.tab === t[0] ? 'font-weight:700;border-bottom:3px solid #1d4ed8' : '') + '">' + t[1] + '</button>'; }).join('');
    var b = o.querySelector('.adm_body'); b.innerHTML = state.tab === 'audit' ? tabAudit() : state.tab === 'droits' ? tabDroits() : state.tab === 'appareils' ? tabAppareils() : state.tab === 'revue' ? tabRevue() : tabAcces();
    Array.prototype.forEach.call(o.querySelectorAll('.adm_tabs button'), function (x) { x.onclick = function () { state.tab = x.getAttribute('data-t'); render(); }; });
    if (state.tab === 'audit') {
      var q = $('adm_q'); q.oninput = function () { state.q = q.value; var p = q.selectionStart; render(); var n = $('adm_q'); n.focus(); try { n.setSelectionRange(p, p); } catch (e) {} };
      $('adm_ver').onclick = function () { w.EXBCore.audit.verify().then(function (r) { state.last = r; audit('admin.audit.verifie', 'journal', { ok: r.ok, n: r.entries }); render(); }); };
      /* V178 : journal d'audit en PDF de marque (en-tête société, QR de vérification public) — toutes les entrées filtrées (500 max sur l'appareil) */
      $('adm_pdf').onclick = function () {
        if (!w.EXBRapport) { try { w.notify('Module d’export PDF indisponible.', 'error'); } catch (e) {} return; }
        var l = rows().filter(function (e) { return match(e, state.q); }); audit('admin.audit.pdf', 'journal', { lignes: l.length });
        var th = '<tr style="text-align:left;background:#f3efe3">' + ['N°', 'Date', 'Utilisateur', 'Action', 'Objet', 'Détail', 'Empreinte'].map(function (h) { return '<th style="padding:3px 6px">' + h + '</th>'; }).join('') + '</tr>';
        var tb = l.map(function (e) { return '<tr><td>' + esc(e.n) + '</td><td>' + esc(fdate(e.t)) + '</td><td>' + esc(e.user) + '</td><td>' + esc(e.action) + '</td><td>' + esc(e.obj) + '</td><td>' + esc(e.d) + '</td><td style="font-family:monospace;font-size:9px">' + esc(String(e.h || '').slice(0, 16)) + '</td></tr>'; }).join('');
        w.EXBRapport.print('Journal d’audit', { prefix: 'AUD', sousTitre: 'Entrées conservées sur cet appareil' + (state.q ? ' · filtre « ' + state.q + ' »' : ''), meta: [['Entrées', String(l.length)], ['Chaîne', state.last ? (state.last.ok ? 'vérifiée — intègre' : 'ROMPUE (' + state.last.broken + ' entrée(s))') : 'non vérifiée à l’impression']], html: '<table><thead>' + th + '</thead><tbody>' + tb + '</tbody></table>', note: 'Journal local chaîné (empreintes). 500 entrées maximum sur l’appareil ; les plus anciennes sont retirées.', paysage: true });
      };
      $('adm_csv').onclick = function () { var l = rows().filter(function (e) { return match(e, state.q); }); audit('admin.audit.export', 'journal', { lignes: l.length }); var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([toCsv(l)], { type: 'text/csv;charset=utf-8' })); a.download = 'journal-audit-' + new Date().toISOString().slice(0, 10) + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); };
    }
    if (state.tab === 'appareils') bindAppareils();
    if (state.tab === 'revue') bindRevue();
    if (state.tab === 'acces') fillAcces();
  }
  function open() {
    if (!allowed()) { try { w.notify ? w.notify('Accès réservé aux administrateurs.', 'warn', 5000) : w.exbAlert('Accès réservé aux administrateurs.'); } catch (e) {} return; }
    if (!w.EXBCore) { w.exbAlert('Le noyau CORE n\'est pas chargé.'); return; }
    audit('admin.ouvert', 'administration', info().label || '');
    var o = $('adm_ov'); if (o) o.remove(); o = d.createElement('div'); o.id = 'adm_ov';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.innerHTML = '<div style="background:var(--card,#fff);color:var(--fg,#0f172a);width:100%;max-width:820px;border-radius:12px;padding:14px;box-sizing:border-box"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">🛡 Administration avancée</h3><button id="adm_x" style="padding:6px 10px">✕</button></div><div class="adm_tabs" style="margin:10px 0"></div><div class="adm_body"></div></div>';
    d.body.appendChild(o); $('adm_x').onclick = function () { o.remove(); }; state.last = null; render();
  }
  function mount() {
    if ($('badm') && !$('badm2')) { var b = d.createElement('button'); b.id = 'badm2'; b.textContent = '🛡 Administration avancée'; b.onclick = open; $('badm').parentNode.insertBefore(b, $('badm').nextSibling); }
    var bb = $('badm2'); if (bb) { var due = false; try { due = !!(info().on && rvEtat(rvRead()).due); } catch (e) {} var tx = '🛡 Administration avancée' + (due ? ' 🔔' : ''); if (bb.textContent !== tx) bb.textContent = tx; bb.title = due ? 'Revue périodique des accès à faire' : ''; }
  }
  function start() { mount(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000); try { w.EXBCore && w.EXBCore.modules.register({ id: 'admin', name: 'Administration avancée', version: '152.0.0', area: 'Direction', provides: ['audit.ui'] }); } catch (e) {} }
  w.EXBADM = { _rvEtat: rvEtat, _rvEcarts: rvEcarts, _rvCloturer: rvCloturer, _rvCsv: rvCsv, open: open, _devOut: devOut, _sess: sess, _csv: toCsv, _match: match };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window);
