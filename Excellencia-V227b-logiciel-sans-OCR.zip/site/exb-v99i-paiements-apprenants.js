/* Excellencia Building V99i — Suivi des paiements des apprenants (inscription + formation).
 * Onglet « 💰 Paiements » dans 👤 Participants : qui a payé, qui n'a pas payé, qui a payé la moitié, et l'historique des versements.
 * Les données restent dans le logiciel (participants + reçus). Un paiement Mobile Money confirmé dans 🌐 Site vitrine peut mettre le statut à jour. */
(function(w,d){'use strict';
var $=function(i){return d.getElementById(i)};
function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
var F={q:'',st:'tous',tr:''};
var LBL={non_paye:'NON PAYÉE',moitie:'PAYÉE EN PARTIE',total:'PAYÉE'};
function P(){try{return typeof participants!=='undefined'&&participants||[]}catch(e){return[]}}
function R(){try{return typeof receipts!=='undefined'&&receipts||[]}catch(e){return[]}}
function fsOf(txt){return txt==='PAYÉ'?'total':txt==='MOITIÉ PAYÉE'?'moitie':'non_paye'}
function approved(p){return p.approval_status!=='REJETE'}
function lastReceipt(p){var l=null;R().forEach(function(r){var ok=(p.matricule&&r.matricule===p.matricule)||(r.participant&&r.participant===p.name);if(ok&&(!l||String(r.created_at||'')>=String(l.created_at||'')))l=r});return l}
function status(p){
  var r=lastReceipt(p),m=p.pay,base={insc:false,form:'non_paye',src:'aucun',at:'',rec:r};
  if(r){base.insc=r.registration_status==='PAYÉ';base.form=fsOf(r.training_status);base.src='reçu '+(r.receipt_no||'');base.at=r.created_at||''}
  if(m&&m.at&&(!base.at||String(m.at)>=String(base.at))){base.insc=!!m.insc;base.form=m.form||'non_paye';base.src='saisie manuelle';base.at=m.at}
  /* V205a : les paiements enregistrés dans Finances & paiements comptent (le plus récent l'emporte) */
  try{var ys=(typeof payments!=='undefined'&&payments||[]).filter(function(y){return y.participant_id===p.participant_id});
   if(ys.length){var ly=ys.reduce(function(a,y){return String(y.created_at||'')>=String(a.created_at||'')?y:a},ys[0]);
    if(!base.at||String(ly.created_at||'')>=String(base.at)){
     var fo=(typeof formations!=='undefined'&&formations||[]).filter(function(f){return (p.formation_id&&f.formation_id===p.formation_id)||f.name===p.training})[0],pr=fo?Number(fo.price)||0:0,vs=ys.reduce(function(a,y){return a+(Number(y.amount)||0)},0);
     if(pr>0){base.form=vs>=pr?'total':'moitie';base.src='paiement '+(ly.reference||'');base.at=ly.created_at||base.at}}}}catch(e){}
  return base
}
function badge(t,c){return'<span style="display:inline-block;border-radius:10px;padding:2px 9px;font-size:12px;font-weight:700;color:#fff;background:'+c+'">'+t+'</span>'}
function bi(s){return badge('Inscription : '+(s.insc?'PAYÉE':'NON PAYÉE'),s.insc?'#15803d':'#b91c1c')}
function bf(s){return badge('Formation : '+LBL[s.form],s.form==='total'?'#15803d':s.form==='moitie'?'#b45309':'#b91c1c')}
function setPay(p,patch,note){
  var s=status(p),now=new Date().toISOString();
  var n={insc:patch.insc!=null?patch.insc:s.insc,form:patch.form||s.form,at:now,log:((p.pay&&p.pay.log)||[]).slice(-40)};
  n.log.push({at:now,insc:n.insc,form:n.form,note:note||''});
  p.pay=n;
  try{if(typeof w.save==='function')w.save('exb_participants',P())}catch(e){}
  try{if(typeof w.audit==='function')w.audit('PAIEMENT_STATUT',(p.matricule||p.participant_id)+' — '+p.name+' : inscription '+(n.insc?'payée':'non payée')+', formation '+LBL[n.form])}catch(e){}
  draw();try{if(typeof w.renderParticipants==='function')w.renderParticipants()}catch(e){}
}
function trainings(){var o={};P().forEach(function(p){if(p.training)o[p.training]=1});return Object.keys(o).sort()}
function rowsFiltered(){
  var q=F.q.trim().toLowerCase();
  return P().filter(function(p){
    if(!approved(p))return false;
    if(F.tr&&p.training!==F.tr)return false;
    if(q&&[p.name,p.matricule,p.phone,p.training].join(' ').toLowerCase().indexOf(q)<0)return false;
    var s=status(p);
    if(F.st==='total')return s.form==='total';
    if(F.st==='moitie')return s.form==='moitie';
    if(F.st==='non_paye')return s.form==='non_paye';
    if(F.st==='insc_non')return !s.insc;
    return true
  }).slice().reverse()
}
function counts(list){var c={n:0,total:0,moitie:0,non_paye:0,insc_non:0};list.forEach(function(p){var s=status(p);c.n++;c[s.form]++;if(!s.insc)c.insc_non++});return c}
function chip(k,t,n,col){return'<button type="button" data-f="'+k+'" style="border:2px solid '+col+';background:'+(F.st===k?col:'#fff')+';color:'+(F.st===k?'#fff':col)+';border-radius:20px;padding:6px 12px;font-weight:700;cursor:pointer">'+t+' ('+n+')</button>'}
function draw(){
  var box=$('exbPayBody');if(!box)return;
  var list=rowsFiltered(),oui=[],non=[];
  list.forEach(function(p){var s=status(p);(s.insc&&s.form==='total'?oui:non).push({p:p,s:s})});
  var opts='<option value="">Toutes les formations</option>'+trainings().map(function(t){return'<option'+(F.tr===t?' selected':'')+'>'+esc(t)+'</option>'}).join('');
  function why(s){var t=[];if(s.src==='aucun')t.push(badge('Aucun reçu','#6b7280'));else{if(!s.insc)t.push(badge('Inscription non payée','#b91c1c'));if(s.form==='moitie')t.push(badge('Formation : moitié payée','#b45309'));else if(s.form==='non_paye')t.push(badge('Formation non payée','#b91c1c'))}return t.join(' ')}
  function item(x,ok){var p=x.p,s=x.s;
    return'<div style="border:1px solid #d5dbe5;border-radius:8px;padding:7px 9px;margin:6px 0;background:#fff"><b>'+esc(p.name)+'</b>'
     +'<div class="localhint" style="word-break:break-word">'+esc(p.matricule||'sans matricule')+' · '+esc(p.training||'—')+'</div>'
     +(ok?'<div class="localhint" style="margin-top:3px">'+(s.at?'Payé · '+esc(new Date(s.at).toLocaleDateString('fr-FR')):'Payé')+(s.src&&s.src!=='aucun'?' · '+esc(s.src):'')+'</div>':'<div style="margin-top:4px">'+why(s)+'</div>')+'</div>'}
  function col(titre,col,arr,ok){
    return'<div style="min-width:0"><div style="background:'+col+';color:#fff;border-radius:8px;padding:8px 10px;font-weight:700">'+titre+' ('+arr.length+')</div>'
     +'<div style="max-height:62vh;overflow:auto">'+(arr.length?arr.map(function(x){return item(x,ok)}).join(''):'<p class="localhint">Aucun apprenant.</p>')+'</div></div>'}
  var h='<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin:10px 0"><div style="flex:2;min-width:180px"><label>Rechercher</label><input id="exbPayQ" value="'+esc(F.q)+'" placeholder="Nom, matricule, téléphone…"></div>'
   +'<div style="flex:1;min-width:160px"><label>Formation</label><select id="exbPayTr">'+opts+'</select></div>'
   +'<button type="button" class="muted smallbtn" id="exbPayCsv">⬇ Excel (CSV)</button><button type="button" class="gold smallbtn" id="exbPayPrint">📄 Imprimer / PDF</button></div>'
   +'<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;align-items:start">'+col('✅ Ont payé','#15803d',oui,true)+col('❌ N’ont pas payé','#b91c1c',non,false)+'</div>';
  box.innerHTML=h;
  var q=$('exbPayQ');if(q){q.oninput=function(){F.q=q.value;var pos=q.selectionStart;draw();var q2=$('exbPayQ');if(q2){q2.focus();try{q2.setSelectionRange(pos,pos)}catch(e){}}}}
  var t=$('exbPayTr');if(t)t.onchange=function(){F.tr=t.value;draw()}
}
function rowsData(){return rowsFiltered().map(function(p){var s=status(p);return[p.name||'',p.matricule||'',p.phone||'',p.training||'',s.insc?'PAYÉE':'NON PAYÉE',LBL[s.form],s.at?s.at.slice(0,10):'']})}
var HEAD=['Nom','Matricule','Téléphone','Formation','Inscription','Frais de formation','Dernière mise à jour'];
function csv(){
  var l=[HEAD].concat(rowsData()).map(function(r){return r.map(function(x){return'"'+String(x).replace(/"/g,'""')+'"'}).join(';')}).join('\r\n');
  var a=d.createElement('a');a.href=URL.createObjectURL(new Blob(['﻿'+l],{type:'text/csv;charset=utf-8'}));a.download='paiements-apprenants-'+new Date().toISOString().slice(0,10)+'.csv';d.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500)
}
/* V178 : le suivi imprimé porte aussi le QR de vérification public (registre des documents) */
function outQr(t,h){try{if(window.EXBRapport&&EXBRapport.stamp)h=EXBRapport.stamp(t,h,{prefix:'PAY',meta:[['Apprenants',String(rowsData().length)]]})}catch(e){}return EXBPrint.html(t,h)}
function print(){
  var c=counts(rowsFiltered());var logo=(window.exbLogoSrc?exbLogoSrc():'icon-192.png');outQr('Suivi des paiements — '+(window.EXB_BRAND&&EXB_BRAND.name||'Excellencia Building'),'<!doctype html><meta charset="utf-8"><title>Suivi des paiements</title><style>body{font-family:Arial;margin:24px;color:#172033}h1{color:#173565;font-size:20px;margin:0}table{border-collapse:collapse;width:100%;font-size:12px;margin-top:12px}th,td{border:1px solid #cbd5e1;padding:6px;text-align:left}th{background:#173565;color:#fff}.hd{display:flex;gap:12px;align-items:center;border-bottom:3px solid #c9a227;padding-bottom:8px}img{width:56px}</style>'
   +'<div class="hd"><img src="'+logo+'"><div><h1>Excellencia Building — Suivi des paiements des apprenants</h1><div>Édité le '+new Date().toLocaleDateString('fr-FR')+(F.tr?' · '+esc(F.tr):'')+' · '+c.n+' apprenant(s) : '+c.total+' payé(s), '+c.moitie+' moitié, '+c.non_paye+' non payé(s)</div></div></div>'
   +'<table><thead><tr>'+HEAD.map(function(h){return'<th>'+h+'</th>'}).join('')+'</tr></thead><tbody>'+rowsData().map(function(r){return'<tr>'+r.map(function(x){return'<td>'+esc(x)+'</td>'}).join('')+'</tr>'}).join('')+'</tbody></table>')
}
d.addEventListener('click',function(e){
  var b=e.target.closest&&e.target.closest('#exbPayTab button,#exbPayBar button');if(!b)return;
  if(b.hasAttribute('data-f')){F.st=b.getAttribute('data-f');draw();return}
  if(b.id==='exbPayCsv'){csv();return}
  if(b.id==='exbPayPrint'){print();return}
  if(b.getAttribute('data-tab')){tab(b.getAttribute('data-tab'));return}
});
function tab(k){
  var sec=$('participants');if(!sec)return;
  [].forEach.call(sec.children,function(el){if(el.id==='exbPayBar'||el.id==='exbPayTab')return;el.style.display=k==='pay'?'none':''});
  $('exbPayTab').style.display=k==='pay'?'':'none';
  [].forEach.call($('exbPayBar').querySelectorAll('button'),function(x){x.style.outline=x.getAttribute('data-tab')===k?'3px solid #c9a227':''});
  if(k==='pay')draw()
}
function mount(){
  var sec=$('participants');if(!sec||$('exbPayBar'))return;
  var bar=d.createElement('div');bar.id='exbPayBar';bar.className='exb-tabs';
  bar.innerHTML='<button type="button" data-tab="list" style="outline:3px solid #c9a227">👤 Liste &amp; fiches</button><button type="button" data-tab="pay">💰 Paiements (qui a payé ?)</button>';
  var tabEl=d.createElement('div');tabEl.id='exbPayTab';tabEl.style.display='none';
  tabEl.innerHTML='<div class="card"><h2>💰 Suivi des paiements — inscription &amp; formation</h2><p class="localhint">Liste en lecture seule : à gauche ceux qui ont tout payé (inscription et formation), à droite les autres. Les reçus sont établis par le comptable (🧾 Reçus de paiement) : la liste se met à jour toute seule dès qu’un reçu est enregistré.</p><div id="exbPayBody"></div></div>';
  sec.insertBefore(tabEl,sec.firstChild);sec.insertBefore(bar,sec.firstChild)
}
/* badges sous le nom dans la liste des participants */
function decorate(){
  var tb=$('participantRows');if(!tb)return;var map={};P().forEach(function(p){map[p.participant_id]=p});
  [].forEach.call(tb.querySelectorAll('tr'),function(tr){var td=tr.children;if(td.length<9)return;var p=map[(td[1].textContent||'').trim()];if(!p||!approved(p))return;if(td[3].querySelector('.exbpb'))return;
    var s=status(p),sp=d.createElement('div');sp.className='exbpb';sp.style.marginTop='3px';sp.innerHTML=bf(s).replace('Formation : ','💰 ');td[3].appendChild(sp)})
}
var oldRP=w.renderParticipants;
if(typeof oldRP==='function')w.renderParticipants=function(){var r=oldRP.apply(this,arguments);try{decorate()}catch(e){}return r};
/* Mobile Money confirmé (🌐 Site vitrine) → met à jour le statut de l'apprenant */
d.addEventListener('click',async function(e){
  var b=e.target.closest&&e.target.closest('button[data-ps="confirme"]');if(!b)return;
  var id=b.getAttribute('data-pid'),motif=null;
  try{var rows=await w.exbSb.api('/rest/v1/paiements_declares?id=eq.'+encodeURIComponent(id)+'&select=*&limit=1');var x=rows&&rows[0];if(!x||x.type!=='apprenant')return;
    var a=w.prompt('Ce paiement de '+x.montant+' '+x.devise+' (réf. '+x.reference+') concerne :\n1 = Frais d’inscription\n2 = Formation — moitié\n3 = Formation — totalité\n(Annuler = ne pas changer le statut)','1');
    if(a==null)return;motif=a.trim();
    var dg=function(v){return String(v||'').replace(/\D/g,'')};
    var p=P().filter(function(q){return x.matricule&&(q.matricule===x.matricule||q.matricule_en_ligne===x.matricule)})[0]||P().filter(function(q){return dg(q.phone).length>=6&&(dg(q.phone)===dg(x.telephone)||dg(q.phone)===dg(x.numero_payeur))})[0];
    if(!p){w.alert('Paiement confirmé, mais l’apprenant est introuvable dans vos participants : importez/approuvez-le d’abord puis mettez son statut dans 👤 Participants › 💰 Paiements.');return}
    if(motif==='2')setPay(p,{form:'moitie'},'Mobile Money '+x.reference);else if(motif==='3')setPay(p,{form:'total'},'Mobile Money '+x.reference);else setPay(p,{insc:true},'Mobile Money '+x.reference);
  }catch(err){}
},true);
function init(){mount();try{decorate()}catch(e){}}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',init);else init();
w.exbPayTrack={draw:draw,status:status,setPay:setPay}
})(window,document);
