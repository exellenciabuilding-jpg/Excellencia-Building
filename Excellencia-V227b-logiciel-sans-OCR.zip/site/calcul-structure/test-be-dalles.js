/* Tests de référence — exb-be-dalles.js (V209) : valeurs calculées à la main (BAEL 91 mod. 99, ELU).  node site/calcul-structure/test-be-dalles.js */
'use strict';
var ls = {}; global.localStorage = { getItem: function (k) { return k in ls ? ls[k] : null; }, setItem: function (k, v) { ls[k] = String(v); } };
var D = require('../exb-be-dalles.js'), ok = 0, ko = 0;
function near(n, v, ref, tol) { var g = Math.abs(v - ref) <= tol; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + v.toFixed(4) + ' (réf. ' + ref + ' ± ' + tol + ')'); }
function is(n, v, ref) { var g = v === ref; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + v + ' (réf. ' + ref + ')'); }
/* flexion : M = 9,7254 kN.m/m, d = 11,5 cm, fc 25, fe 500 → μ = 0,0519 ; As = 1,9985 cm²/m */
var f = D.flexion(9.7254, 11.5, 25, 500); near('μbu', f.mu, 0.05191, 1e-4); near('As flexion (cm²/m)', f.As, 1.9985, 0.01); near('μℓ fe500', f.mul, 0.3718, 0.001);
is('section insuffisante refusée', D.flexion(80, 11.5, 25, 500).ok, false);
/* dalle 4 × 5 m, h = 15 cm, G rev. 1,5, Q 2,5 : G = 5,25 ; qu = 10,8375 ; α = 0,8 ; μx = 0,05609 ; μy = 0,61568 ; M0x = 9,725 */
var d = D.dalle({ lx: 5, ly: 4, h: 15, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'simple' });
is('dalle calculée (portées inversées acceptées)', d.ok, true); near('qu dalle', d.out.qu, 10.8375, 1e-9);
var txt = JSON.stringify(d.rows); is('μx = 0,0561', /μx = 0,0561/.test(txt), true); is('M0x = 9,72 (μx·qu·lx² = 0,05608·10,8375·16)', /M0x = 9,7[23]/.test(txt), true); is('M0y = 5,99', /M0y = 5,99/.test(txt), true);
is('Ax calculé 2,00 cm²/m', /Ax = 2,00 cm²\/m \(calculé 2,00/.test(txt), true); is('Ay = 1,34 cm²/m (calculé, > minimum 1,20)', /Ay = 1,34 cm²\/m \(calculé 1,34 ; minimum 1,20/.test(txt), true);
/* continuité : travée 0,75 M0, chapeaux présents */
var dc = D.dalle({ lx: 4, ly: 5, h: 15, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'continu' }); is('chapeaux calculés', !!dc.out.chap, true);
/* dalle portant dans un sens : α = 3/9 = 0,33 < 0,4, M0x = qu lx²/8 */
var d1 = D.dalle({ lx: 3, ly: 9, h: 15, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 }); is('sens unique détecté', /un seul sens/.test(JSON.stringify(d1.rows)), true); is('M0x sens unique = 10,8375·9/8 = 12,19', /M0x = 12,19/.test(JSON.stringify(d1.rows)), true);
/* trop mince : refusée */
is('dalle trop mince refusée', D.dalle({ lx: 6, ly: 6, h: 8, grev: 1.5, Q: 5, fc: 25, fe: 500, enr: 2.5 }).ok, false);
/* escalier H = 3,06 m, 18 contremarches (17 cm), giron 28, L = 4 m, e = 15 cm : cosα = 0,8547 ; G = 8,012 ; qu = 14,566 ; M0 = 29,13 ; As = 6,37 */
var e = D.escalier({ H: 3.06, nm: 18, g: 28, L: 4, e: 15, b: 1, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'simple' });
is('escalier calculé', e.ok, true); var te = JSON.stringify(e.rows); is('Blondel 62 cm', /2h \+ g = 62,0/.test(te), true); is('G = 8,01', /G = 8,01 kN/.test(te), true); is('qu = 14,57', /qu = 14,57/.test(te), true); is('M0 = 29,13', /M0 = qu L²\/8 = 29,13/.test(te), true);
is('As = 6,37 cm²/m', /As = 6,37 cm²\/m/.test(te), true); is('aucune alerte Blondel', e.warn.some(function (m) { return /Blondel/.test(m); }), false);
is('Blondel hors plage signalé', D.escalier({ H: 3.06, nm: 18, g: 20, L: 4, e: 15, fc: 25, fe: 500 }).warn.some(function (m) { return /Blondel/.test(m); }), true);
/* treillis : As = 6,37 → HA10 à 10 cm (HA8 donnerait 7,5 cm < 10) ; espacement jamais supérieur au maximum */
var t = D.treillis(6.37, 33); is('treillis HA10', t.d, 10); is('espacement 10 cm', t.s, 10); near('As fournie ≥ requise', t.as >= 6.37 ? 1 : 0, 1, 0); is('espacement plafonné', D.treillis(0.5, 33).s, 32.5);
/* quantités : dalle 4 × 5 × 0,15 = 3 m³ ; coffrage 20 + 2·9·0,15 = 22,7 m² ; escalier : béton (0,15/0,8547 + 0,085)·4·1 */
var q = D.quant({ type: 'dalle', name: 'D1', p: { lx: 4, ly: 5, h: 15, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 } }); near('béton dalle m³', q.beton, 3, 1e-9); near('coffrage dalle m²', q.coffrage, 22.7, 1e-9); is('acier dalle > 0', Object.keys(q.acier).length > 0, true);
var qe = D.quant({ type: 'escalier', name: 'E1', p: { H: 3.06, nm: 18, g: 28, L: 4, e: 15, b: 1, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 } }); near('béton escalier m³', qe.beton, (0.15 / 0.85472 + 0.085) * 4, 1e-4);

/* ===== V210 : ELS, fissuration, flèche, chapeaux, trémies, charges concentrées, palier, poutre palière — références calculées à la main / en Python indépendant ===== */
/* contraintes ELS : b = 1 m, d = 0,115 m, As = 7,854 cm² (HA10 à 10), M = 0,01 MN.m → x = 4,159 cm ; I = 8,7468e-5 m4 ; σbc = 4,755 MPa ; σs = 125,89 MPa */
var se = D.sigELS(0.01, 1, 0.115, 7.854e-4); near('x ELS (cm)', se.x * 100, 4.159, 0.005); near('σbc ELS', se.sbc, 4.7548, 0.005); near('σs ELS', se.ss, 125.89, 0.05);
near('limite σs préjudiciable fe500 = min(333 ; max(250 ; 201,6))', D.limELS(25, 500, 'prej').ss, 250, 1e-9); near('limite σs très préjudiciable = 0,8 × 250', D.limELS(25, 500, 'tres').ss, 200, 1e-9); near('limite σbc = 0,6 fc28', D.limELS(25, 500, 'peu').sbc, 15, 1e-9);
/* As minimal pour σs ≤ 250 MPa : M = 8,57 kN.m/m, d = 14,5 cm → 2,537 cm²/m */
near('As ELS (cm²/m)', D.asELS(0.00857, 1, 0.145, 25, 500, 'prej', 1e-4).A * 1e4, 2.537, 0.01);
is('espacements max préjudiciable h = 18', JSON.stringify(D.smaxFis(18, 'prej')), JSON.stringify([25, 33])); is('espacements max peu préjudiciable h = 15', JSON.stringify(D.smaxFis(15, 'peu')), JSON.stringify([33, 45]));
/* intégration : dalle 4 × 5 h = 18, fissuration préjudiciable → Ax relevé à 2,54 (ELS gouverne) alors que l'ELU donne 1,72 */
var dp = D.dalle({ lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, fis: 'prej' }), tp2 = JSON.stringify(dp.rows);
is('ELU inchangé (Ax calculé 1,72)', /Ax = 1,72 cm²\/m \(calculé 1,72/.test(tp2), true); is('ELS relève Ax à 2,54', /Ax = 2,54/.test(tp2), true); is('aucun point bloquant', dp.block.length, 0);
/* flèche : bande 1 m, L = 4, h = 15, d = 11,5, As = 7,854 cm², G = 8, Q = 2,5, jr = 0,6 → 13,44 mm (formule fermée indépendante) */
var Mg = [], Mq = []; for (var i = 0; i <= 20; i++) { var tt = i / 20; Mg.push(8 * 16 / 8 * 4 * tt * (1 - tt)); Mq.push(2.5 * 16 / 8 * 4 * tt * (1 - tt)); }
var fl = D.fleche(4, 1, 0.15, 0.115, 0.025, 7.854e-4, 25, Mg, Mq, 0.6); near('flèche BAEL B.6.5 (mm)', fl.delta * 1000, 13.44, 0.1); is('flèche > L/500 détectée', fl.ok, false);
var dmin = D.dalle({ lx: 4, ly: 4.2, h: 11, grev: 1.5, Q: 5, fc: 25, fe: 500, enr: 2.5 }); is('flèche excessive → point bloquant', dmin.block.some(function (m) { return /Flèche/.test(m); }), true);
/* moments d'appui forfaitaires : M0 = 10 ; aq = 2,5/8,5 ; appui intermédiaire 2 travées (0,6) + rive : Ma = 6,0 ; Mt = max(1,05 M0 − 3,0 ; (1,2 + 0,3 aq)/2 M0) = 7,882 */
var md = D.momDir(10, 'c2', 'rive', 2.5 / 8.5, 0); near('Ma intermédiaire = 0,6 M0', md.Ma1, 6, 1e-9); near('Ma rive = 0,15 M0', md.Ma2, 1.5, 1e-9); near('Mt forfaitaire', md.Mt, 7.8824, 1e-3);
near('appuis simples : Mt = M0', D.momDir(10, 'simple', 'simple', 0.3, 0).Mt, 10, 1e-9); near('M0 voisin plus grand gouverne Ma', D.momDir(10, 'c2', 'simple', 0.3, 12).Ma1, 7.2, 1e-9);
var dap = D.dalle({ lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'appuis', ed: { xg: 'c2', xd: 'rive', yb: 'simple', yh: 'c3' } });
is('3 chapeaux calculés', dap.out.chapeaux.length, 3); near('Ma gauche = 0,6 M0x (M0x = 10,63)', dap.out.chapeaux[0].Ma, 6.38, 0.01); near('longueur chapeau rive = 0,2 lx', dap.out.chapeaux[1].len, 0.8, 1e-9);
is('quantité : chapeaux ajoutés à l\u2019acier', D.quant({ type: 'dalle', name: 'A', p: { lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'appuis', ed: { xg: 'c2', xd: 'rive', yb: 'simple', yh: 'c3' } } }).acier[8] > D.quant({ type: 'dalle', name: 'A', p: { lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'simple' } }).acier[8], true);
/* diagramme : charge totale 40 kN sur 4 m → 20 kN.m ; charge partielle centrée 10 kN/m sur 2 m, L = 4 : w c (2L − c)/8 = 15 */
near('Mmax charge répartie', D.diag(4, [{ a: 0, b: 4, w: 10 }], 400).max, 20, 1e-6); near('Mmax charge partielle centrée', D.diag(4, [{ a: 1, b: 3, w: 10 }], 400).max, 15, 1e-6);
/* charge concentrée : P = 20 kN (Q) 20 × 20 cm à mi-portée de 4 m, h = 18 → Pu = 30 ; b_eff = 0,38 + 2,4·2·0,5 = 2,78 ; ΔM = 30·1/2,78 = 10,79 ; poinçonnement 0,045·1,52·0,18·25/1,5 = 205,2 kN */
var pc = D.chargePC({ P: 20, nat: 'Q', u: 20, v: 20, xc: '' }, 4, 5, 18, 25); near('largeur d\u2019effet', pc.beff, 2.78, 1e-9); near('ΔM ELU (kN.m/m)', pc.dMu, 10.7914, 1e-3); near('poinçonnement admissible (kN)', pc.punch.lim * 1000, 205.2, 0.1); is('poinçonnement OK', pc.punch.ok, true);
var pb2 = D.dalle({ lx: 4, ly: 5, h: 12, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, pc: [{ P: 150, nat: 'Q', u: 10, v: 10, xc: '' }] }); is('poinçonnement non satisfait → bloquant', pb2.block.some(function (m) { return /poinçonnement/.test(m); }), true);
/* trémie 60 × 40 dans une nappe HA8 à 12,5 cm : coupées ceil(40/12,5) = 4 (sens x), ceil(60/32,5) = 2 (sens y) ; renfort ½ de chaque côté */
var tr = D.tremie({ a: 60, b: 40, xc: 200, yc: 250 }, 4, 5, 18, { d: 8, s: 12.5 }, { d: 8, s: 32.5 }); is('barres coupées x', tr.nx, 4); is('barres coupées y', tr.ny, 2); is('renfort par côté x', tr.px, 2); is('trémie dans le domaine', tr.hors.length, 0);
is('trémie trop grande hors domaine', D.tremie({ a: 150, b: 150, xc: 200, yc: 250 }, 4, 5, 18, { d: 8, s: 12.5 }, { d: 8, s: 32.5 }).hors.length > 0, true); is('trémie trop proche du bord', D.tremie({ a: 40, b: 40, xc: 30, yc: 250 }, 4, 5, 18, { d: 8, s: 12.5 }, { d: 8, s: 32.5 }).hors.length > 0, true);
/* palier : volée 2,4 m (qu = 15,75) + palier 1,2 m (qu = 11,85) sur 3,6 m → RA = 27,57 ; RB = 24,45 ; x(V = 0) = 1,7505 ; Mmax = 24,13 */
var ep = D.escalier({ H: 1.53, nm: 9, g: 28, L: 2.4, e: 18, b: 1.2, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, Lp: 1.2, ep: 18, pb: { on: true, Lb: 1.2, bp: 25, hp: 40, qmur: 0 } }), tep = JSON.stringify(ep.rows);
is('palier : réactions 27,6 / 24,5', /27,6 \/ 24,5/.test(tep), true); is('palier : Mmax = 24,13', /Mmax \(volée \+ palier\) = 24,13/.test(tep), true); is('poutre palière calculée', !!ep.out.pb, true);
/* poutre palière : Mu = 5,0 kN.m (charge partielle 24,45 kN/m sur 1,2 m + poids propre 1,35 × 2,5) → As min = 0,23·25·35,5·2,1/500 = 0,857 cm² → 2 HA12 */
is('poutre palière 2 HA12', ep.out.pb.bars.n === 2 && ep.out.pb.bars.d === 12, true); is('cadres espacés 14 cm (u/8 imposé par la torsion ; 0,9 d = 31 cm)', ep.out.pb.st, 14);
is('poutre palière sans palier → bloquant', D.escalier({ H: 1.53, nm: 9, g: 28, L: 2.4, e: 18, fc: 25, fe: 500, pb: { on: true, Lb: 1.2, bp: 25, hp: 40 } }).block.length > 0, true);
var qpal = D.quant({ type: 'escalier', name: 'EP', p: { H: 1.53, nm: 9, g: 28, L: 2.4, e: 18, b: 1.2, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, Lp: 1.2, ep: 18, pb: { on: true, Lb: 1.2, bp: 25, hp: 40, qmur: 0 } } }); var qsp = D.quant({ type: 'escalier', name: 'EP', p: { H: 1.53, nm: 9, g: 28, L: 2.4, e: 18, b: 1.2, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 } });
near('béton palier + poutre = +1,2·1,2·0,18 + 0,25·0,4·1,2', qpal.beton - qsp.beton, 1.2 * 1.2 * 0.18 + 0.25 * 0.4 * 1.2, 1e-9);
/* contrôles pour le dossier : non conforme → bloquant ; avec justification → attention */
var rr = { id: 'x', type: 'dalle', name: 'D', nb: 1, p: { lx: 4, ly: 4.2, h: 11, grev: 1.5, Q: 5, fc: 25, fe: 500, enr: 2.5 } };
is('non conforme sans justification → bloquant', D.controle(rr).some(function (c) { return c.niv === 'bloquant'; }), true); rr.justif = 'Flèche admise par le maître d\u2019ouvrage'; is('justifié → plus de bloquant', D.controle(rr).some(function (c) { return c.niv === 'bloquant'; }), false);
var e1 = D.empreinte(rr); rr.p.h = 12; is('empreinte change si une donnée change', e1 !== D.empreinte(rr), true);


/* ===== V210b : torsion de la poutre palière, épaisseur minimale au poinçonnement, armatures de coin, arrêts de barres, ancrage — références Python indépendantes ===== */
/* torsion : M0 = 24,13 ; kenc = 0,15 ; c = 1,2 m → Tu = 2,172 kN.m ; e = 25/6 = 4,167 cm ; Ω = 746,5 cm² ; u = 1,133 m ; τtu = 0,349 MPa ; At/st = 0,3345 cm²/m par brin ; Al = 0,379 cm² (0,070 en bas) */
var tt = JSON.stringify(ep.rows.filter(function (r) { return /torsion/.test(r[0]); })); is('torsion : Tu = 2,17 kN.m', /Tu = 2,17 kN\.m/.test(tt), true); is('torsion : Ω = 747 cm²', /Ω = 747 cm²/.test(tt), true); is('torsion : τtu = 0,349 MPa', /τtu = 0,349 MPa/.test(tt), true); is('torsion : At/st = 0,33 cm²/m par brin', /At\/st torsion = 0,33 cm²\/m/.test(tt), true); is('torsion : Al = 0,38 cm²', /Al = 0,38 cm²/.test(tt), true);
var ep0 = D.escalier({ H: 1.53, nm: 9, g: 28, L: 2.4, e: 18, b: 1.2, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, Lp: 1.2, ep: 18, pb: { on: true, Lb: 1.2, bp: 25, hp: 40, qmur: 0, kenc: 0 } }); is('kenc = 0 : torsion négligée (cadres à 0,9 d = 31 cm)', ep0.out.pb.st, 31); is('kenc = 0 : alerte « torsion négligée »', ep0.warn.some(function (m) { return /torsion négligée/.test(m); }), true);
var ept = D.escalier({ H: 1.53, nm: 9, g: 28, L: 2.4, e: 18, b: 1.2, grev: 1.5, Q: 6, fc: 25, fe: 500, enr: 2.5, Lp: 1.2, ep: 18, pb: { on: true, Lb: 1.2, bp: 15, hp: 25, qmur: 5, kenc: 0.5 } }); is('torsion excessive : section insuffisante → bloquant', ept.block.some(function (m) { return /flexion-torsion|section/.test(m); }), true);
/* ancrage : ls = Ø fe / (4 · 0,6 · 1,5² · ft28) = 352,7 mm pour HA8 ; 529,1 mm pour HA12 (fc 25, fe 500) */
near('ls HA8 (mm)', D.lsMm(8, 25, 500), 352.73, 0.01); near('ls HA12 (mm)', D.lsMm(12, 25, 500), 529.10, 0.01);
/* poinçonnement : P = 150 kN (Q) sur 10 × 10 cm, h = 12 → Pu = 225 kN ; 0,75 (0,4 + 4h) h ≥ 0,225 → h ≥ 22,8 cm → 23 cm */
is('épaisseur minimale poinçonnement = 23 cm', /épaisseur minimale 23 cm/.test(pb2.block.join(' ')), true);
/* coins : dalle simplement appuyée → 4 coins ; carré lx/5 = 0,8 m ; As = max(Ax, Ay) */
var dco = D.dalle({ lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 }); is('4 coins armés (appuis simples)', dco.out.coins.n, 4); near('côté du carré de coin = lx/5', dco.out.coins.side, 0.8, 1e-9);
var dcc = D.dalle({ lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'appuis', ed: { xg: 'c2', xd: 'rive', yb: 'simple', yh: 'c3' } }); is('coins : seul le coin sans côté continu (bas-droit) est armé', JSON.stringify(dcc.out.coins.noms), JSON.stringify(['bas-droit']));
is('dalle à 1 sens : pas de coin', D.dalle({ lx: 3, ly: 9, h: 15, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 }).out.coins, null);
/* arrêts forfaitaires : la moitié des barres est raccourcie → acier du lit courant < barres toutes prolongées */
var qa = D.quant({ type: 'dalle', name: 'Q', p: { lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'continu' } }); var nbx = Math.ceil(5 * 100 / D.dalle({ lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, cont: 'continu' }).out.bx.s + 1);
is('quantité : arrêts de barres pris en compte (remarque)', /arrêts forfaitaires/.test(qa.remarque), true); is('quantité : acier > 0', qa.acier[8] > 0, true);

console.log('\n' + ok + ' réussi(s), ' + ko + ' échec(s).'); process.exit(ko ? 1 : 0);
