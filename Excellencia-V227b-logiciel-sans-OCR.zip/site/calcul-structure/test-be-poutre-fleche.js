/* Tests — flèche des poutres des notes de calcul (exb-etudes.js, V214) : BAEL B.6.5 via exb-verif-els.js.  node site/calcul-structure/test-be-poutre-fleche.js */
'use strict';
var vm = require('vm'), fs = require('fs'), path = require('path'), ok = 0, ko = 0;
var ls = {}; global.localStorage = { getItem: function (k) { return k in ls ? ls[k] : null; }, setItem: function (k, v) { ls[k] = String(v); }, removeItem: function (k) { delete ls[k]; } };
var fakeEl = function () { return { style: {}, children: [], appendChild: function () {}, addEventListener: function () {}, setAttribute: function () {}, remove: function () {}, classList: { add: function () {}, remove: function () {} }, querySelector: function () { return null; }, querySelectorAll: function () { return []; } }; };
global.window = global; global.document = { addEventListener: function () {}, documentElement: {}, body: fakeEl(), createElement: fakeEl, getElementById: function () { return null; }, querySelector: function () { return null; }, querySelectorAll: function () { return []; } };
global.EXBV = require('./exb-verif-els.js');
vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', 'exb-etudes.js'), 'utf8'), { filename: 'exb-etudes.js' });
function near(n, v, ref, tol) { var g = Math.abs(v - ref) <= tol; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + (+v).toFixed(4) + ' (réf. ' + ref + ' ± ' + tol + ')'); }
function is(n, v, ref) { var g = v === ref; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + v + ' (réf. ' + ref + ')'); }
function note(v) { return { id: 'N', no: 'NC-1', fc: 25, fe: 500, enr: 3, els: [{ id: 'E', type: 'beam', name: 'Pt', v: Object.assign({ type: 'rect', b: 20, h: 40, b0: 20, h0: 12, L: 4, g: 10, q: 5, km: 0.125, Mu: 0, Ms: 0, Vu: 0, jr: 0, reprise: 'oui' }, v || {}) }] }; }
function res(v) { return global.EXBET.calcNote(note(v))[0]; }
function row(r, k) { return (r.rows.filter(function (x) { return x[0].indexOf(k) === 0; })[0] || [])[1] || ''; }
function mm(t, k) { var m = t.match(new RegExp(k + ' = (-?[\\d  ]+,\\d+) mm')); return m ? parseFloat(m[1].replace(/[\s  ]/g, '').replace(',', '.')) : NaN; }

var r = res(); var t = row(r, 'Flèche');
is('la ligne « Flèche (BAEL B.6.5) » est produite', /Flèche \(BAEL B\.6\.5/.test(r.rows.map(function (x) { return x[0]; }).join('|')), true);
/* poutre 20×40, L = 4 m, g = 10 + 2 (poids propre) ; q = 5 : qs = 17 kN/m ; Ms = 34 kN.m ; adm = L/500 = 8 mm */
near('flèche admissible L ≤ 5 m (mm)', mm(t, 'admissible'), 8.0, 0.05);
/* borne basse : flèche élastique NON fissurée sous qs = 5 qs L⁴ / (384 Ei I0), Ei = 11000 fc^(1/3), I0 = b h³/12 ; la flèche fissurée doit être supérieure */
var Ei = 11000 * Math.cbrt(25), I0 = 0.2 * Math.pow(0.4, 3) / 12, f0 = 5 * 0.017 * Math.pow(4, 4) / (384 * Ei * I0) * 1000;
is('fpi fissurée > élastique non fissurée (' + f0.toFixed(2) + ' mm)', mm(t, 'fpi') > f0, true);
is('fpi borne haute (< 4 × élastique)', mm(t, 'fpi') < 4 * f0, true);
is('fgv > fgi (fluage)', mm(t, 'fgv') > mm(t, 'fgi'), true);
is('fgi (permanentes) < fpi (totales)', mm(t, 'fgi') < mm(t, 'fpi'), true);
/* cohérence interne : Δf = fgv − fji + fpi − fgi */
near('Δf = fgv − fji + fpi − fgi', mm(t, 'Δf = fgv − fji \\+ fpi − fgi'), mm(t, 'fgv') - mm(t, 'fji') + mm(t, 'fpi') - mm(t, 'fgi'), 0.02);
/* cohérence avec le moteur exb-verif-els.js appelé directement (mêmes entrées, hors du moteur de note) */
var Mmax = 34 / 1000, pf = function (i) { var x = i / 20; return 4 * x * (1 - x); }, Mg = [], Mq = [];
for (var i = 0; i <= 20; i++) { Mg.push(Mmax * 12 / 17 * pf(i)); Mq.push(Mmax * 5 / 17 * pf(i)); }
var As = parseFloat(row(r, 'RÉSULTAT').match(/\(([\d,]+) cm²\)/)[1].replace(',', '.')) * 1e-4;
var direct = global.EXBV.flecheBAEL({ L: 4, Mg: Mg, Mq: Mq, jr: 2 / 12, fc: 25, sP: { b: 0.2, h: 0.4, bf: 0.2, h0: 0, d: Math.min(0.9 * 0.4, 0.4 - 0.03 - 0.03), dp: 0.04, As: As, Asc: 0 } });
near('Δf identique au moteur appelé directement (mm)', mm(t, 'Δf = fgv − fji \\+ fpi − fgi'), direct.delta * 1000, 0.005);
/* portée > 5 m : limite 0,5 cm + L/1000 */
near('admissible L = 6 m : 0,5 cm + L/1000 = 11 mm', mm(row(res({ L: 6, h: 60 }), 'Flèche'), 'admissible'), 11.0, 0.05);
/* plus de charge → plus de flèche ; plus de hauteur → moins de flèche */
is('Q plus forte → Δf plus grande', mm(row(res({ q: 15 }), 'Flèche'), 'Δf = fgv − fji \\+ fpi − fgi') > mm(t, 'Δf = fgv − fji \\+ fpi − fgi'), true);
is('h plus grande → Δf plus petite', mm(row(res({ h: 50 }), 'Flèche'), 'Δf = fgv − fji \\+ fpi − fgi') < mm(t, 'Δf = fgv − fji \\+ fpi − fgi'), true);
/* section trop souple : L = 6,5 m, 30 × 38 cm, g = 6, q = 4 → Δf = 23,6 mm > 11,5 mm admissibles : alerte obligatoire */
var gr = res({ L: 6.5, h: 38, b: 30, g: 6, q: 4 }), tg = row(gr, 'Flèche');
is('poutre élancée : Δf > admissible', mm(tg, 'Δf = fgv − fji \\+ fpi − fgi') > mm(tg, 'admissible'), true);
is('poutre élancée : alerte « Flèche : Δf » émise', gr.warn.some(function (m) { return /^Flèche : Δf/.test(m); }), true);
is('poutre correcte : aucune alerte flèche', r.warn.some(function (m) { return /^Flèche : Δf/.test(m); }), false);
/* poutre en té */
var rt = res({ type: 'té', b: 60, b0: 20, h: 45, h0: 12 }); is('té : flèche calculée', /Δf/.test(row(rt, 'Flèche')), true);
/* j/g explicite : 1 → les permanentes sont toutes appliquées avant cloisons : fji = fgi, Δf diminue */
is('j/g = 1 → Δf plus petite que poids propre seul', mm(row(res({ jr: 1 }), 'Flèche'), 'Δf = fgv − fji \\+ fpi − fgi') < mm(t, 'Δf = fgv − fji \\+ fpi − fgi'), true);
/* les autres lignes de la note sont inchangées et l'avertissement « flèche non calculée » a disparu */
is('plus de « flèche non calculée » quand elle est calculée', r.warn.some(function (m) { return /flèche \(non calculée\)|flèche et arrêts/.test(m); }), false);
is('ELS section choisie toujours présent', /Vérification ELS/.test(r.rows.map(function (x) { return x[0]; }).join('|')), true);
/* sans le moteur de flèche : comportement antérieur conservé */
var saved = global.EXBV; delete global.EXBV; var r0 = res({ L: 6.5, h: 38, b: 30, g: 6, q: 4 });
is('sans EXBV : pas de ligne flèche', r0.rows.some(function (x) { return /^Flèche/.test(x[0]); }), false); is('sans EXBV : ancien avertissement conservé', r0.warn.some(function (m) { return /flèche/.test(m); }), true); global.EXBV = saved;
console.log('\n' + ok + ' réussi(s), ' + ko + ' échec(s).'); process.exit(ko ? 1 : 0);
