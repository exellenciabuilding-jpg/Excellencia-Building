/* Tests de référence — exb-be-p2.js (V208) : portance, tassement, quantitatif, coordination BIM.  node site/calcul-structure/test-be-p2.js */
'use strict';
var ls = {}; global.localStorage = { getItem: function (k) { return k in ls ? ls[k] : null; }, setItem: function (k, v) { ls[k] = String(v); } };
var P = require('../exb-be-p2.js'), ok = 0, ko = 0;
function near(n, v, ref, tol) { var good = Math.abs(v - ref) <= tol; (good ? ok++ : ko++); console.log((good ? 'OK  ' : 'ECHEC ') + n + ' = ' + v.toFixed(4) + ' (réf. ' + ref + ' ± ' + tol + ')'); }
function is(n, v, ref) { var good = v === ref; (good ? ok++ : ko++); console.log((good ? 'OK  ' : 'ECHEC ') + n + ' = ' + v + ' (réf. ' + ref + ')'); }
/* facteurs de portance — valeurs classiques Prandtl/Reissner/Vesic */
var f30 = P.facteurs(30); near('Nq(30°)', f30.Nq, 18.40, 0.01); near('Nc(30°)', f30.Nc, 30.14, 0.01); near('Ngamma Vesic(30°)', f30.Ng, 22.40, 0.01);
var f0 = P.facteurs(0); near('Nc(0°)', f0.Nc, 5.14, 0.01); near('Nq(0°)', f0.Nq, 1, 1e-9); near('Ngamma(0°)', f0.Ng, 0, 1e-9);
/* contrainte verticale effective avec nappe */
near('sigma_v z=4 m, nappe 2 m', P.sigmaV([{ de: 0, a: 5, gamma: 18 }], 2, 4), 18 * 2 + (18 - 9.81) * 2, 1e-9);
near('sigma_v sans nappe', P.sigmaV([{ de: 0, a: 5, gamma: 18 }], '', 4), 72, 1e-9);
/* portance argile non drainée, semelle carrée 2 × 2 m, Df = 1 m, gamma = 18, cu = 50 kPa, F = 3 */
var pa = P.portance({ phi: 0, c: 50, B: 2, L: 2, Df: 1, F: 3, gamma: 18 });
near('qu argile (50·5,142·1,1945 + 18)', pa.qu, 50 * 5.14159 * (1 + 1 / 5.14159) + 18, 0.05); near('q adm nette argile', pa.qadmNet, 50 * 5.14159 * (1 + 1 / 5.14159) / 3, 0.05);
/* tassement de consolidation : Cc = 0,3 ; e0 = 1 ; H = 2 m ; s0 = 100 kPa ; Δσ = 100 kPa → 0,3·2/2·log10(2) = 90,3 mm */
near('tassement NC (m)', P.tassTranche({ H: 2, e0: 1, Cc: 0.3, s0: 100, ds: 100 }), 0.3 * Math.log10(2), 1e-9);
near('tassement SC→NC (m)', P.tassTranche({ H: 2, e0: 1, Cc: 0.3, Cr: 0.05, s0: 100, ds: 100, sp: 150 }), 0.05 * Math.log10(1.5) + 0.3 * Math.log10(200 / 150), 1e-9);
near('tassement SC pur (m)', P.tassTranche({ H: 2, e0: 1, Cc: 0.3, Cr: 0.05, s0: 100, ds: 40, sp: 150 }), 0.05 * Math.log10(1.4), 1e-9);
is('tassement sans Cc', P.tassTranche({ H: 2, e0: 1, s0: 100, ds: 100 }), 0);
/* tassement élastique : q = 100 kPa, B = 2, ν = 0,3, Iw = 0,82, E = 10 000 kPa → 100·2·0,91·0,82/10000 = 14,9 mm */
var t = P.tassement({ B: 2, L: 2, Df: 1, q: 100, couches: [{ de: 0, a: 6, gamma: 18, E: 10000, nu: 0.3 }], nappe: '' });
near('tassement immédiat (m)', t.immediat, 100 * 2 * (1 - 0.09) * 0.82 / 10000, 1e-9); is('pas de consolidation sans Cc', t.consolidation, 0);
/* chaîne complète : rapport avec sondage + fondation */
var r = { sondRef: 0, sondages: [{ nom: 'S1', prof: 8, nappe: '', couches: [{ de: 0, a: 8, nature: 'argile', gamma: 18, c: 50, phi: 0, e0: 1, Cc: 0.3, sp: '', E: 10000, nu: 0.3 }] }], fond: { B: 2, L: 2, Df: 1, q: 100, F: 3, limite: 50, zinf: 2, Iw: 0.82 }, reco: ['x'] };
var gc = P.geoCalc(r); is('geoCalc ok', gc.ok, true); is('portance > charge (aucune alerte GEO-16)', P.geoVerif(r).some(function (a) { return a.id === 'GEO-16'; }), false);
r.fond.q = 5000; is('charge excessive → GEO-16 bloquant', P.geoVerif(r).some(function (a) { return a.id === 'GEO-16' && a.niveau === 'bloquant'; }), true);
r.sondages = []; is('sans sondage → GEO-1 bloquant', P.geoVerif(r).some(function (a) { return a.id === 'GEO-1' && a.niveau === 'bloquant'; }), true);
/* quantitatif — poteau 30×30, l0 = 3 m ; semelle 150×150×40 ; poutre 20×40, L = 4 m ; enrobage 3 cm */
var n = { enr: 3 }, Pm = { ancrage: 40, crochet: 20, densite: 7850 };
var col = P.quantElement({ name: 'P1', type: 'col', v: { forme: 'rect', a: 30, b: 30, l0: 300 } }, { n: 4, d: 14, ph: 8, st: 20 }, n, Pm);
near('poteau béton m³', col.beton, 0.27, 1e-9); near('poteau coffrage m²', col.coffrage, 3.6, 1e-9);
near('poteau acier HA14 kg', col.acier[14], 4 * (3 + 40 * 0.014) * Math.PI * 196 / 4e6 * 7850, 1e-6); is('poteau quantifié', col.ok, true);
var ft = P.quantElement({ name: 'S1', type: 'foot', v: {} }, { B: 150, A: 150, h: 40, X: { n: 8, d: 12 }, Y: { n: 8, d: 12 } }, n, Pm);
near('semelle béton m³', ft.beton, 0.9, 1e-9); near('semelle coffrage m²', ft.coffrage, 2.4, 1e-9);
var bm = P.quantElement({ name: 'Pt1', type: 'beam', v: { type: 'rect', b: 20, h: 40, L: 4 } }, { n: 3, d: 14, dt: 8, st: 15 }, n, Pm);
near('poutre béton m³', bm.beton, 0.32, 1e-9); near('poutre coffrage m²', bm.coffrage, 4.0, 1e-9);
var bad = P.quantElement({ name: 'P2', type: 'col', v: { forme: 'rect', a: 30, b: 30, l0: 300 } }, {}, n, Pm); is('poteau sans armatures → non quantifié', bad.ok, false);
/* quantifier() avec notes simulées */
global.EXBET = { calcNote: function (note) { return (note.els || []).map(function () { return { out: { n: 4, d: 14, ph: 8, st: 20 }, rows: [], warn: [] }; }); } };
ls.exb_calc_notes = JSON.stringify([{ id: 'N1', no: 'NC-1', enr: 3, fc: 25, fe: 500, els: [{ id: 'E1', type: 'col', name: 'P1', v: { forme: 'rect', a: 30, b: 30, l0: 300 } }, { id: 'E2', type: 'dc', name: 'DC', v: {} }] }]);
var q = P.quantifier({ notes: ['N1'] }, { params: { ancrage: 40, crochet: 20, pertes: 5, densite: 7850 }, nb: { 'N1:E1': 10 } });
near('10 poteaux : béton m³', q.beton, 2.7, 1e-9); is('descente de charges ignorée', q.lignes.length, 1); near('chutes 5 % : acier brut / net', q.acierBrut / q.acierNet, 1.05, 1e-9);
/* rapprochement */
var rp = P.rapproche({ beton: 100, coffrage: 500, acierBrut: 8000 }, { beton: 97, coffrage: 400, acier: '', tol: 5, justif: { coffrage: 'voiles non comptés' } });
is('béton dans la tolérance', rp[0].statut, 'Conforme'); is('coffrage justifié', rp[1].statut, 'Justifié'); is('acier non saisi', rp[2].statut, 'Métré non saisi');
is('écart non justifié', P.rapproche({ beton: 100, coffrage: 0, acierBrut: 0 }, { beton: 80, coffrage: '', acier: '', tol: 5, justif: {} })[0].statut, 'Écart à justifier');
/* GlobalId IFC */
is('GlobalId valide', P.validGuid('3cUkl32yn9qRSPvBJVyWYp'), true); is('GlobalId trop court', P.validGuid('abc'), false); is('GlobalId caractère interdit', P.validGuid('3cUkl32yn9qRSPvBJVyWY!'), false);
console.log('\n' + ok + ' réussi(s), ' + ko + ' échec(s).'); process.exit(ko ? 1 : 0);
