/* Test d'intégration V210 : dalles et escaliers dans le dossier d'étude V207 (contrôles, empreinte au visa, verrou, révision).  node site/calcul-structure/test-be-dossier-dalles.js */
'use strict';
var ls = {}; global.localStorage = { getItem: function (k) { return k in ls ? ls[k] : null; }, setItem: function (k, v) { ls[k] = String(v); } };
global.window = global; var noop = function () {};
global.document = { addEventListener: noop, documentElement: {}, getElementById: function () { return null; }, querySelector: function () { return null; }, querySelectorAll: function () { return []; }, createElement: function () { return { style: {}, appendChild: noop, addEventListener: noop }; }, body: { appendChild: noop } };
require('../exb-be-dalles.js'); require('../exb-be-dossier.js');
var D = global.EXBBeD, E = global.EXBBeDal, ok = 0, ko = 0;
function is(n, v, ref) { var g = v === ref; (g ? ok++ : ko++); console.log((g ? 'OK  ' : 'ECHEC ') + n + ' = ' + v + ' (réf. ' + ref + ')'); }
var x = D.nouveau(); x.titre = 'Villa test'; x.norme = { id: (D.normes()[0] || {}).id || '', edition: '1999' }; D.put(x);
var bon = { id: 'DS-1', dossier_id: x.id, type: 'dalle', name: 'D1', nb: 1, justif: '', p: { lx: 4, ly: 5, h: 18, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5, fis: 'peu' } };
var mauvais = { id: 'DS-2', dossier_id: x.id, type: 'dalle', name: 'D2', nb: 1, justif: '', p: { lx: 4, ly: 4.2, h: 11, grev: 1.5, Q: 5, fc: 25, fe: 500, enr: 2.5 } };
E.put(bon);
var bl = function (code) { return D.verif(D.get(x.id)).filter(function (r) { return r.niv === 'bloquant' && r.code === code; }).length; };
is('élément conforme : aucun bloquant DAL', bl('DAL-2') + bl('DAL-1'), 0);
is('le dossier compte la dalle (pas d\u2019alerte CAL-1)', D.verif(D.get(x.id)).filter(function (r) { return r.code === 'CAL-1'; }).length, 0);
E.put(mauvais); is('élément non conforme → bloquant DAL-2 (visa impossible)', bl('DAL-2') > 0, true);
mauvais.justif = 'Flèche admise par le maître d\u2019ouvrage (note du 21/11)'; E.put(mauvais); is('justification d\u2019ingénieur → plus de bloquant', bl('DAL-2'), 0);
/* visa simulé : empreintes + statut Visé */
var v = D.get(x.id); v.empreintes = {}; E.forDossier(x.id).forEach(function (e) { v.empreintes[e.id] = E.empreinte(e); }); v.statut = 'Visé'; D.put(v);
is('élément inchangé depuis le visa : pas de DAL-6', bl('DAL-6'), 0);
is('verrou actif dès que le dossier n\u2019est plus en brouillon', E.verrou(x.id), true);
bon.p.h = 20; E.put(bon); is('élément modifié après visa → DAL-6 bloquant', bl('DAL-6'), 1);
bon.p.h = 18; E.put(bon); E.put({ id: 'DS-3', dossier_id: x.id, type: 'escalier', name: 'E1', nb: 1, justif: '', p: { H: 3.06, nm: 18, g: 28, L: 4.5, e: 20, b: 1, grev: 1.5, Q: 2.5, fc: 25, fe: 500, enr: 2.5 } });
is('élément ajouté après le visa → DAL-6 bloquant', bl('DAL-6'), 1);
/* révision : copie des éléments sur le nouveau dossier */
var y = D.nouveau(); y.titre = 'Villa test rév 1'; D.put(y); var n = E.cloneFor(x.id, y.id);
is('révision : 3 éléments copiés', n, 3); is('révision : ids distincts', E.forDossier(y.id).every(function (e) { return ['DS-1', 'DS-2', 'DS-3'].indexOf(e.id) < 0; }), true);
is('nouveau dossier en brouillon : non verrouillé', E.verrou(y.id), false);
/* rapport PDF : les éléments, les points non conformes justifiés et les empreintes y figurent */
var cap = null; global.EXBPdf = { make: function (o) { cap = o; return Promise.resolve({}); }, save: noop };
D.rapport(x.id); var rows = cap ? cap.rows : [], flat = JSON.stringify(rows);
is('rapport : ligne « Dalle D1 »', rows.some(function (r) { return /^Dalle D1/.test(r[0]); }), true); is('rapport : ligne « Escalier E1 »', rows.some(function (r) { return /^Escalier E1/.test(r[0]); }), true);
is('rapport : justification de l\u2019ingénieur reprise', /Flèche admise par le ma/.test(flat), true); is('rapport : empreintes des éléments', /Dalle D1 : [0-9a-f]+/.test(flat), true);
is('rapport : lignes ELS et flèche présentes', /ELS . contraintes/.test(flat) && /Flèche \(BAEL B\.6\.5\)/.test(flat), true);
console.log('\n' + ok + ' réussi(s), ' + ko + ' échec(s).'); process.exit(ko ? 1 : 0);
