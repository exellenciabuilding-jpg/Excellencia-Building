/* Excellencia Building — BUREAU JURIDIQUE / CONTRATS V213 (cahier des charges V1.0, §5.8)
 * Fonctions du cahier : contrats, avenants, garanties, assurances, litiges, échéances et validation.
 *   1. CONTRAT : fiche (référence, parties, montant initial, dates) ; AVENANTS : montant actuel = initial + avenants SIGNÉS seulement,
 *      échéance actuelle = fin + jours des avenants signés (un avenant en brouillon ou refusé ne modifie rien).
 *   2. GARANTIES et ASSURANCES : état calculé Valide / Expire bientôt / Expirée selon le délai d'alerte SAISI.
 *   3. LITIGES : suivi (ouvert, négociation, judiciaire, clos) ; une clôture exige une PREUVE et un NOM.
 *   4. ÉCHÉANCES : points à suivre (Ouvert / En retard / Clos) et CALENDRIER consolidé (fin de contrat, garanties, assurances, litiges, échéances).
 *   5. VALIDATION : visa nominatif Brouillon → Vérifié → Visé, vérificateur ≠ auteur.
 * Hors périmètre de cette étape (signalé, jamais simulé) : rédaction ou analyse juridique des clauses, calcul de pénalités ou d'intérêts, signature électronique qualifiée,
 * qualification juridique d'un litige. Ce module ne remplace pas l'avis d'un juriste.
 * Garde-fou : moteurs déterministes, aucune IA, aucune valeur légale imposée. Données : clé exb_jur. Pour retirer : supprimer la balise <script src="exb-jur.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBJur) return;
  var K = 'exb_jur', EXP = {};

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function num(v, def) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : (def === undefined ? NaN : def); }
  function fx(v, n) { return isFinite(v) ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: n, maximumFractionDigits: n }) : '—'; }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function who() { return ask('Votre nom (signature nominative, non qualifiée) :', '').then(function (v) { return String(v || '').trim(); }); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id) }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function san(t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/→/g, '->').replace(/²/g, '2').replace(/³/g, '3').replace(/×/g, 'x').replace(/√/g, 'rac ').replace(/·/g, '.').replace(/Δ/g, 'delta ').replace(/Ø/g, 'D ').replace(/φ/g, 'phi ').replace(/’/g, "'"); }
  function csv(rows, name) { var t = '﻿' + rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); try { var b = new Blob([t], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = (w.URL || w.webkitURL).createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); } catch (e) { toast('Export impossible : ' + e.message, 'error'); } }
  function pdf(o) { if (!w.EXBPdf) return toast('Module PDF indisponible.', 'error'); try { var p = w.EXBPdf.make(w.EXBENT && w.EXBENT.piece ? w.EXBENT.piece(o) : o); return Promise.resolve(p).then(function (b) { if (b && b.size && w.EXBPdf.save) { w.EXBPdf.save(b, String((o && (o.sousTitre || o.titre)) || 'rapport').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) + '.pdf'); toast('PDF généré.', 'success'); } return b; }, function (e) { toast('PDF impossible : ' + (e && e.message || e), 'error'); }); } catch (e) { toast('PDF impossible : ' + e.message, 'error'); } }

  /* Lecture de lignes de saisie (« a ; b ; c »), dates, états calculés. */
  function lignes(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return l && l.charAt(0) !== '#'; }); }
  function champs(l) { return l.split(/[;\t]/).map(function (x) { return x.trim(); }); }
  /* fn(champs, indice) renvoie un objet (ligne valide) ou une chaîne (motif du refus). */
  function parse(t, fn) { var R = [], E = []; lignes(t).forEach(function (l, i) { var r = fn(champs(l), i); if (typeof r === 'string') E.push({ ligne: i + 1, msg: r }); else R.push(r); }); return { rows: R, erreurs: E }; }
  function iso(s) { s = String(s == null ? '' : s).trim(); var a, b, c, m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s); if (m) { a = +m[1]; b = +m[2]; c = +m[3]; } else { m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s); if (!m) return null; a = +m[3]; b = +m[2]; c = +m[1]; } var t = new Date(Date.UTC(a, b - 1, c)); if (t.getUTCFullYear() !== a || t.getUTCMonth() !== b - 1 || t.getUTCDate() !== c) return null; return t.toISOString().slice(0, 10); }
  /* D : '' si vide, null si illisible, sinon la date AAAA-MM-JJ. */
  function D(s) { return String(s == null ? '' : s).trim() === '' ? '' : iso(s); }
  function dj(a, b) { return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000); }
  function plus(a, n) { return new Date(Date.parse(a + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10); }
  function auj() { var t = new Date(), p = function (v) { return (v < 10 ? '0' : '') + v; }; return t.getFullYear() + '-' + p(t.getMonth() + 1) + '-' + p(t.getDate()); }
  function df(s) { return s ? String(s).split('-').reverse().join('/') : '—'; }
  /* État d'un point de suivi : clôture = preuve ET nom ; l'un sans l'autre = « Incomplet ». */
  function suivi(ech, preuve, par, today) { var p = String(preuve || '').trim(), n = String(par || '').trim(); if (p && n) return 'Clos'; if (p || n) return 'Incomplet'; return ech && ech < today ? 'En retard' : 'Ouvert'; }
  /* État d'une validité (garantie, assurance) : jours d'alerte saisis. */
  function validite(fin, today, alerteJ) { if (!fin) return 'Sans échéance'; if (fin < today) return 'Expirée'; return dj(today, fin) <= (isFinite(alerteJ) ? alerteJ : 0) ? 'Expire bientôt' : 'Valide'; }
  function em(sec, e) { return (sec ? sec + ' ' : '') + (typeof e === 'string' ? e : 'ligne ' + e.ligne + ' : ' + e.msg); }
  function et(e) { var c = /^(Clos|Valide|À jour|Sous garantie|Levée|Conforme|OK)/.test(e) ? '#15803d' : /^(En retard|Expirée|Incomplet|Clôture|Échéance dépassée|Dépassement|Surcharge|Hors)/.test(e) ? '#b91c1c' : '#b45309'; return '<b style="color:' + c + '">' + esc(e) + '</b>'; }
  function pad3(n) { return String(n).padStart(3, '0'); }

  /* ========================================================== MOTEURS ========================================================== */
  var STAV = ['Brouillon', 'Signé', 'Refusé'], STLI = ['Ouvert', 'Négociation', 'Judiciaire', 'Clos'];
  /* Avenants : n° ; objet ; date ; montant (+/−) ; jours supplémentaires ; statut */
  function parseAv(t) { var seen = {}; return parse(t, function (f) { var dt = D(f[2]), m = f[3] === '' || f[3] === undefined ? 0 : num(f[3]), j = f[4] === '' || f[4] === undefined ? 0 : num(f[4]), st = f[5] || 'Brouillon'; return !f[0] ? 'numéro manquant' : seen[f[0]] ? 'avenant « ' + f[0] + ' » en double' : !f[1] ? 'objet manquant' : dt === null ? 'date illisible' : !isFinite(m) ? 'montant invalide' : (!isFinite(j) || j !== Math.floor(j)) ? 'jours : nombre entier' : STAV.indexOf(st) < 0 ? 'statut : ' + STAV.join(' / ') : (seen[f[0]] = 1, { no: f[0], obj: f[1], date: dt, m: m, j: j, st: st }); }); }
  /* Garanties / assurances : type ; émetteur ; référence ; montant ; début ; fin */
  function parseGa(t, ref) { return parse(t, function (f) { var m = f[3] === '' || f[3] === undefined ? 0 : num(f[3]), a = D(f[4]), b = D(f[5]); return !f[0] ? 'type manquant' : !f[1] ? (ref ? 'émetteur' : 'assureur') + ' manquant' : !(m >= 0) ? 'montant invalide' : (a === null || b === null) ? 'date illisible' : (a && b && b < a) ? 'fin avant le début' : { type: f[0], emet: f[1], ref: f[2] || '', m: m, deb: a, fin: b }; }); }
  /* Litiges : réf ; objet ; partie adverse ; ouvert le ; montant en jeu ; état ; prochaine échéance ; preuve de clôture ; clos par */
  function etatLit(r, today) { if (r.st === 'Clos') return r.preuve && r.par ? 'Clos' : 'Clôture à justifier'; return r.ech && r.ech < today ? 'Échéance dépassée' : r.st; }
  function parseLit(t, today) { var seen = {}; return parse(t, function (f) { var dt = D(f[3]), m = f[4] === '' || f[4] === undefined ? 0 : num(f[4]), st = f[5] || 'Ouvert', ec = D(f[6]); var r; return !f[0] ? 'référence manquante' : seen[f[0]] ? 'référence « ' + f[0] + ' » en double' : !f[1] ? 'objet manquant' : dt === null ? 'date illisible' : !(m >= 0) ? 'montant invalide' : STLI.indexOf(st) < 0 ? 'état : ' + STLI.join(' / ') : ec === null ? 'échéance illisible' : (seen[f[0]] = 1, r = { ref: f[0], obj: f[1], adv: f[2] || '', date: dt, m: m, st: st, ech: ec, preuve: f[7] || '', par: f[8] || '' }, r.etat = etatLit(r, today), r); }); }
  /* Échéances : libellé ; date ; responsable ; preuve ; fait par */
  function parseEch(t, today) { return parse(t, function (f) { var dt = D(f[1]); return !f[0] ? 'libellé manquant' : !dt ? 'date manquante ou illisible' : { lib: f[0], date: dt, resp: f[2] || '', preuve: f[3] || '', par: f[4] || '', etat: suivi(dt, f[3], f[4], today) }; }); }
  function synthese(c, A) {
    var m0 = num(c.montant), cum = 0, jours = 0; A.forEach(function (a) { if (a.st === 'Signé') { cum += a.m; jours += a.j; } });
    var fin = D(c.fin), debut = D(c.debut), sig = D(c.signature);
    return { m0: m0, cumul: cum, actuel: isFinite(m0) ? m0 + cum : NaN, pct: isFinite(m0) && m0 > 0 ? cum / m0 * 100 : NaN, jours: jours, fin0: fin, finA: fin ? plus(fin, jours) : (fin === '' ? '' : null), debut: debut, sig: sig, nSignes: A.filter(function (a) { return a.st === 'Signé'; }).length };
  }
  function calendrier(S, G, As, L, E, today) {
    var o = []; if (S.finA) o.push({ date: S.finA, src: 'Contrat', lib: 'Fin du contrat' });
    G.forEach(function (g) { if (g.fin) o.push({ date: g.fin, src: 'Garantie', lib: g.type + ' — ' + g.emet }); }); As.forEach(function (g) { if (g.fin) o.push({ date: g.fin, src: 'Assurance', lib: g.type + ' — ' + g.emet }); });
    L.forEach(function (l) { if (l.etat !== 'Clos' && l.ech) o.push({ date: l.ech, src: 'Litige', lib: l.ref + ' — ' + l.obj }); }); E.forEach(function (e) { if (e.etat !== 'Clos') o.push({ date: e.date, src: 'Échéance', lib: e.lib }); });
    o.forEach(function (i) { i.j = dj(today, i.date); }); o.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; }); return o;
  }

  /* ========================================================== DOSSIER ========================================================== */
  function nouveau() { var n = all().length + 1, y = new Date().getFullYear(); return { id: uid('JUR'), no: 'JUR-' + y + '-' + pad3(n), statut: 'Brouillon', titre: '', project_id: '', site: '', date: auj(), auteur: '', norme: { nom: '', edition: '' }, ctr: { ref: '', type: '', objet: '', client: '', titulaire: '', montant: '', devise: '', signature: '', debut: '', fin: '', alerteJ: '30' }, avTxt: '', gaTxt: '', asTxt: '', liTxt: '', ecTxt: '', histo: [], cree: Date.now() }; }
  function calc(x, today) {
    today = today || auj(); var aj = num(x.ctr.alerteJ, 0), av = parseAv(x.avTxt), ga = parseGa(x.gaTxt, true), as = parseGa(x.asTxt, false), li = parseLit(x.liTxt, today), ec = parseEch(x.ecTxt, today), S = synthese(x.ctr, av.rows);
    var st = function (r) { r.etat = validite(r.fin, today, aj); return r; }; ga.rows.forEach(st); as.rows.forEach(st);
    return { today: today, aj: aj, av: av, ga: ga, as: as, li: li, ec: ec, S: S, cal: calendrier(S, ga.rows, as.rows, li.rows, ec.rows, today) };
  }
  function verif(x, today) {
    var a = [], add = function (n, id, m) { a.push({ niveau: n, id: id, msg: m }); }, k = calc(x, today), c = x.ctr, S = k.S;
    if (!String(c.ref || '').trim() || !String(c.titulaire || '').trim()) add('bloquant', 'JUR-1', 'Référence du contrat et titulaire non renseignés.');
    if (!String(x.auteur || '').trim()) add('bloquant', 'JUR-2', 'Rédacteur du dossier non renseigné.');
    if (!(S.m0 > 0)) add('bloquant', 'JUR-3', 'Montant initial du contrat non saisi (nombre > 0).');
    if (S.fin0 === null || S.debut === null || S.sig === null) add('bloquant', 'JUR-4', 'Date de signature, de début ou de fin illisible (AAAA-MM-JJ ou JJ/MM/AAAA).'); else if (S.debut && S.fin0 && S.fin0 < S.debut) add('bloquant', 'JUR-4', 'La date de fin précède la date de début.');
    if (S.finA && S.finA < k.today) add('alerte', 'JUR-12', 'Contrat arrivé à échéance le ' + df(S.finA) + '.');
    k.ga.rows.forEach(function (g) { if (g.etat === 'Expirée') add('alerte', 'JUR-6', 'Garantie ' + g.type + ' (' + g.emet + ') expirée le ' + df(g.fin) + '.'); else if (g.etat === 'Expire bientôt') add('alerte', 'JUR-7', 'Garantie ' + g.type + ' (' + g.emet + ') expire le ' + df(g.fin) + '.'); });
    k.as.rows.forEach(function (g) { if (g.etat === 'Expirée') add('alerte', 'JUR-6', 'Assurance ' + g.type + ' (' + g.emet + ') expirée le ' + df(g.fin) + '.'); else if (g.etat === 'Expire bientôt') add('alerte', 'JUR-7', 'Assurance ' + g.type + ' (' + g.emet + ') expire le ' + df(g.fin) + '.'); });
    k.av.rows.forEach(function (v) { if (v.st === 'Signé' && !v.date) add('alerte', 'JUR-11', 'Avenant ' + v.no + ' signé sans date.'); });
    k.li.rows.forEach(function (l) { if (l.etat === 'Clôture à justifier') add('alerte', 'JUR-10', 'Litige ' + l.ref + ' : clôture sans preuve et nom.'); else if (l.etat === 'Échéance dépassée') add('alerte', 'JUR-8', 'Litige ' + l.ref + ' : échéance ' + df(l.ech) + ' dépassée.'); else if (l.etat !== 'Clos') add('alerte', 'JUR-8', 'Litige ' + l.ref + ' en cours (' + l.st + ').'); });
    k.ec.rows.forEach(function (e) { if (e.etat === 'En retard') add('alerte', 'JUR-9', 'Échéance « ' + e.lib + ' » du ' + df(e.date) + ' dépassée.'); if (e.etat === 'Incomplet') add('alerte', 'JUR-10', 'Échéance « ' + e.lib + ' » : clôture incomplète (preuve ET nom).'); });
    [['Avenants', k.av.erreurs], ['Garanties', k.ga.erreurs], ['Assurances', k.as.erreurs], ['Litiges', k.li.erreurs], ['Échéances', k.ec.erreurs]].forEach(function (s) { s[1].forEach(function (e) { add('alerte', 'JUR-5', em(s[0], e)); }); });
    return a;
  }

  /* ========================================================== ONGLETS ========================================================== */
  function money(v, c) { return fx(v, 2) + (c.devise ? ' ' + esc(c.devise) : ''); }
  function tabCtr(x, dis) {
    var c = x.ctr, k = calc(x), S = k.S, h = grid(lab('Référence du contrat', inp('ctr.ref', c.ref, dis)) + lab('Type (marché, sous-traitance, fourniture…)', inp('ctr.type', c.type, dis)) + lab('Client / maître d’ouvrage', inp('ctr.client', c.client, dis)) + lab('Titulaire / cocontractant', inp('ctr.titulaire', c.titulaire, dis)) + lab('Montant initial', inp('ctr.montant', c.montant, dis)) + lab('Devise (ex. USD, CDF, EUR)', inp('ctr.devise', c.devise, dis)) + lab('Date de signature', inp('ctr.signature', c.signature, dis)) + lab('Date de début', inp('ctr.debut', c.debut, dis)) + lab('Date de fin', inp('ctr.fin', c.fin, dis)) + lab('Délai d’alerte avant échéance (jours) — saisi', inp('ctr.alerteJ', c.alerteJ, dis)));
    h += lab('Objet du contrat', inp('ctr.objet', c.objet, dis)) + lab('Avenants (n° ; objet ; date ; montant +/− ; jours supplémentaires ; statut Brouillon|Signé|Refusé)', ta('avTxt', x.avTxt, dis, 4, 'AV-1;Travaux supplémentaires;2026-09-01;12000;30;Signé')) + '<!--RES-->' + errs([['Avenants', k.av.erreurs]]);
    if (isFinite(S.m0)) h += '<p style="font-size:12.5px">Montant initial : <b>' + money(S.m0, c) + '</b> — avenants signés (' + S.nSignes + ') : <b>' + money(S.cumul, c) + '</b>' + (isFinite(S.pct) ? ' (' + fx(S.pct, 1) + ' %)' : '') + ' — <b>montant actuel : ' + money(S.actuel, c) + '</b>.</p>';
    if (S.finA) h += '<p style="font-size:12.5px">Fin initiale : ' + df(S.fin0) + (S.jours ? ' — +' + S.jours + ' j d’avenants signés' : '') + ' — <b>fin actuelle : ' + df(S.finA) + '</b>.</p>';
    if (k.av.rows.length) h += table(['N°', 'Objet', 'Date', 'Montant', 'Jours', 'Statut'], k.av.rows.map(function (a) { return [esc(a.no), esc(a.obj), df(a.date), fx(a.m, 2), a.j, a.st === 'Signé' ? '<b style="color:#15803d">Signé</b>' : esc(a.st)]; })) + note('Seuls les avenants « Signé » modifient le montant et l’échéance.');
    return h;
  }
  function tabGa(x, dis) {
    var k = calc(x), c = x.ctr, h = lab('Garanties (type ; émetteur ; référence ; montant ; début ; fin)', ta('gaTxt', x.gaTxt, dis, 4, 'Retenue de garantie;Maître d’ouvrage;RG-01;5000;2026-01-01;2027-01-01')) + lab('Assurances (type ; assureur ; n° de police ; montant garanti ; début ; fin)', ta('asTxt', x.asTxt, dis, 4, 'Responsabilité civile;Assureur X;POL-123;100000;2026-01-01;2026-12-31')) + '<!--RES-->' + errs([['Garanties', k.ga.erreurs], ['Assurances', k.as.erreurs]]);
    if (k.ga.rows.length) h += '<h4 style="margin:8px 0 4px">Garanties</h4>' + table(['Type', 'Émetteur', 'Réf.', 'Montant', 'Fin', 'État'], k.ga.rows.map(function (g) { return [esc(g.type), esc(g.emet), esc(g.ref || '—'), money(g.m, c), df(g.fin), et(g.etat)]; }));
    if (k.as.rows.length) h += '<h4 style="margin:8px 0 4px">Assurances</h4>' + table(['Type', 'Assureur', 'Police', 'Garanti', 'Fin', 'État'], k.as.rows.map(function (g) { return [esc(g.type), esc(g.emet), esc(g.ref || '—'), money(g.m, c), df(g.fin), et(g.etat)]; }));
    return h;
  }
  function tabLit(x, dis) {
    var k = calc(x), c = x.ctr, h = lab('Litiges (réf ; objet ; partie adverse ; ouvert le ; montant en jeu ; état Ouvert|Négociation|Judiciaire|Clos ; prochaine échéance ; preuve de clôture ; clos par)', ta('liTxt', x.liTxt, dis, 5, 'LIT-1;Retard de paiement;Société Z;2026-08-01;8000;Négociation;2026-12-15;;')) + '<!--RES-->' + errs([['Litiges', k.li.erreurs]]);
    if (k.li.rows.length) h += table(['Réf', 'Objet', 'Partie adverse', 'Ouvert le', 'Montant en jeu', 'Prochaine échéance', 'État'], k.li.rows.map(function (l) { return [esc(l.ref), esc(l.obj), esc(l.adv || '—'), df(l.date), money(l.m, c), df(l.ech), et(l.etat)]; })) + note('« Clos » exige une preuve de clôture ET un nom. Aucune qualification juridique n’est faite par le logiciel.');
    return h;
  }
  function tabEch(x, dis) {
    var k = calc(x), h = lab('Échéances à suivre (libellé ; date ; responsable ; preuve ; fait par)', ta('ecTxt', x.ecTxt, dis, 4, 'Renouveler la police RC;2026-12-20;Juriste;;')) + '<!--RES-->' + errs([['Échéances', k.ec.erreurs]]);
    if (k.cal.length) h += '<h4 style="margin:8px 0 4px">Calendrier consolidé (éléments non clos)</h4>' + table(['Date', 'Source', 'Libellé', 'Jours'], k.cal.map(function (i) { return [df(i.date), esc(i.src), esc(i.lib), i.j < 0 ? '<b style="color:#b91c1c">' + i.j + '</b>' : (i.j <= k.aj ? '<b style="color:#b45309">' + i.j + '</b>' : i.j)]; })) + note('Jours = nombre de jours jusqu’à la date (négatif = dépassée). Alerte à ' + k.aj + ' jour(s).');
    if (k.ec.rows.length) h += '<h4 style="margin:8px 0 4px">Échéances saisies</h4>' + table(['Libellé', 'Date', 'Responsable', 'État'], k.ec.rows.map(function (e) { return [esc(e.lib), df(e.date), esc(e.resp || '—'), et(e.etat)]; }));
    return h;
  }

  var CFG = {
    id: 'exbJur', glob: 'EXBJur', audit: 'jur', nom: 'Bureau juridique / contrats', area: 'Direction', cat: 'ent', visa: true,
    label: '⚖️ Juridique / contrats', desc: 'Contrats, avenants, garanties, assurances, litiges, échéances et validation',
    intro: 'Suivi des contrats, avenants, garanties, assurances, litiges et échéances, avec validation nominative. Ne remplace pas l’avis d’un juriste.', nouveau: 'Nouveau dossier contrat', auteur: 'Rédacteur du dossier',
    anchors: ['exbEnvBtn', 'exbVrdBtn', 'exbPlombBtn', 'exbElecBtn', 'exbGeoPlusBtn', 'exbTopoBtn', 'exbBeDalBtn', 'exbBeP2Btn', 'exbBeBtn'],
    tabs: [['ctr', '📄 Contrat / avenants'], ['ga', '🛡️ Garanties / assurances'], ['lit', '⚔️ Litiges'], ['ech', '📅 Échéances']], tabf: { ctr: tabCtr, ga: tabGa, lit: tabLit, ech: tabEch },
    creer: nouveau, pdfBtn: 'Fiche de validation PDF', pdfTitre: 'FICHE CONTRAT ET VALIDATION', pdfNote: 'Suivi deterministe - ne remplace pas l\'avis d\'un juriste. Montants, dates et delais saisis par le dossier.',
    csvBtns: [['csvc', '⬇️ Calendrier CSV', function (x) { var k = calc(x); return { rows: [['Date', 'Source', 'Libellé', 'Jours']].concat(k.cal.map(function (i) { return [i.date, i.src, i.lib, i.j]; })), name: x.no + '-calendrier.csv' }; }]],
    pdfRows: function (x) {
      var k = calc(x), c = x.ctr, S = k.S, r = [['Dossier', x.no + ' — ' + (x.titre || '—') + ' — statut : ' + x.statut], ['Projet / site', pnom(x.project_id) + ' — ' + (x.site || '—')], ['Rédacteur / date', (x.auteur || '—') + ' — ' + (x.date || '—')], ['Contrat', (c.ref || '—') + ' — ' + (c.type || '—') + ' — ' + (c.objet || '—')], ['Parties', (c.client || '—') + ' / ' + (c.titulaire || '—')], ['Montant initial', fx(S.m0, 2) + ' ' + (c.devise || '')], ['Avenants signés', S.nSignes + ' — ' + fx(S.cumul, 2) + ' ' + (c.devise || '') + ' — jours : ' + S.jours], ['Montant actuel', fx(S.actuel, 2) + ' ' + (c.devise || '')], ['Fin actuelle', df(S.finA)]];
      k.ga.rows.forEach(function (g) { r.push(['Garantie ' + g.type, g.emet + ' — ' + fx(g.m, 2) + ' — fin ' + df(g.fin) + ' — ' + g.etat]); }); k.as.rows.forEach(function (g) { r.push(['Assurance ' + g.type, g.emet + ' — police ' + (g.ref || '—') + ' — fin ' + df(g.fin) + ' — ' + g.etat]); });
      k.li.rows.forEach(function (l) { r.push(['Litige ' + l.ref, l.obj + ' — ' + l.etat]); }); k.ec.rows.forEach(function (e) { r.push(['Échéance', e.lib + ' — ' + df(e.date) + ' — ' + e.etat]); }); return r;
    }
  };
  EXP = { parseAv: parseAv, parseGa: parseGa, parseLit: parseLit, parseEch: parseEch, etatLit: etatLit, synthese: synthese, calendrier: calendrier, validite: validite, verif: verif, nouveau: nouveau, calc: calc };

  /* ========================================================== DOSSIER ========================================================== */
  function all() { return rd(K); }
  function find(id) { return all().filter(function (x) { return x.id === id; })[0]; }
  function saveDos(x) { var a = all(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i < 0) a.push(x); else a[i] = x; return wr(K, a); }
  function bloque(x) { return verif(x).filter(function (v) { return v.niveau === 'bloquant'; }); }

  /* ========================================================== INTERFACE ========================================================== */
  var TAB = null, GID = null;
  function box() { return d.getElementById(CFG.id + 'Box'); }
  function ro(x) { return !!CFG.visa && x.statut !== 'Brouillon'; }
  function btn(l, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + l + '</button>'; }
  function lab(t, h) { return '<label style="display:block;font-size:12.5px;color:#334155">' + t + h + '</label>'; }
  function inp(f, v, dis) { return '<input data-f="' + f + '" value="' + esc(v) + '"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px;box-sizing:border-box">'; }
  function ta(f, v, dis, rows, ph) { return '<textarea data-f="' + f + '" rows="' + (rows || 5) + '"' + (dis ? ' disabled' : '') + ' placeholder="' + esc(ph || '') + '" style="width:100%;box-sizing:border-box;padding:6px;font:12.5px monospace">' + esc(v) + '</textarea>'; }
  function table(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr>' + h.map(function (c) { return '<th style="text-align:left;border-bottom:1px solid #cbd5e1;padding:4px 8px">' + c + '</th>'; }).join('') + '</tr>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="border-bottom:1px solid #e2e8f0;padding:4px 8px">' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</table></div>'; }
  function alertesHtml(A) { return A.length ? '<ul style="margin:6px 0;padding-left:18px;font-size:12.5px">' + A.map(function (a) { return '<li style="color:' + (a.niveau === 'bloquant' ? '#b91c1c' : '#b45309') + '">' + esc(a.id) + ' — ' + esc(a.msg) + '</li>'; }).join('') + '</ul>' : '<p style="color:#15803d;font-size:12.5px">Aucune alerte.</p>'; }
  function grid(h) { return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + h + '</div>'; }
  function errs(list) { var e = []; list.forEach(function (s) { s[1].forEach(function (m) { e.push(em(s[0], m)); }); }); return e.length ? '<ul style="font-size:12.5px;color:#b45309;padding-left:18px">' + e.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>' : ''; }
  function note(t) { return '<p style="font-size:12px;color:#475569;margin:6px 0">' + t + '</p>'; }
  function liste0() { var a = all(); return '<h3 style="margin:6px 0">' + CFG.label + '</h3><p style="font-size:12.5px;color:#475569">' + CFG.intro + '</p>' + btn('➕ ' + CFG.nouveau, 'new') + (a.length ? table(['N°', 'Titre', 'Projet', 'Statut', ''], a.map(function (r) { return [esc(r.no), esc(r.titre || '—'), esc(pnom(r.project_id)), esc(r.statut), btn('Ouvrir', 'open', r.id)]; })) : '<p>Aucun dossier.</p>'); }
  function tabRap(x) {
    var A = verif(x), h = '<h4 style="margin:6px 0">Contrôles</h4>' + alertesHtml(A);
    if (CFG.visa) {
      h += '<h4 style="margin:10px 0 4px">Visa</h4><p style="font-size:12.5px">Statut : <b>' + esc(x.statut) + '</b>' + (x.verifie ? ' — vérifié par ' + esc(x.verifie.par) : '') + (x.vise ? ' — visé par ' + esc(x.vise.par) : '') + '</p>';
      if (x.statut === 'Brouillon') h += btn('Marquer comme vérifié', 'verifier', null, '#7c3aed'); if (x.statut === 'Vérifié') h += btn('Viser le dossier', 'viser', null, '#7c3aed'); if (x.statut !== 'Brouillon') h += btn('Rouvrir (motif obligatoire)', 'rouvrir', null, '#475569');
    }
    h += '<div style="margin-top:8px">' + btn('📄 ' + CFG.pdfBtn, 'pdf', null, '#0369a1') + CFG.csvBtns.map(function (b) { return btn(b[1], b[0], null, '#475569'); }).join('') + '</div>';
    if (x.histo.length) h += '<h4 style="margin:10px 0 4px">Historique</h4><ul style="font-size:12px;padding-left:18px">' + x.histo.map(function (e) { return '<li>' + esc(new Date(e.t).toLocaleString('fr-FR')) + ' — ' + esc(e.msg) + '</li>'; }).join('') + '</ul>';
    return h;
  }
  /* Chaque onglet renvoie « saisie <!--RES--> résultats » : seuls les résultats sont redessinés à chaque modification, la saisie garde le focus. */
  function onglet(x, dis) { return TAB === 'rap' ? tabRap(x) : CFG.tabf[TAB](x, dis); }
  function coupe(h) { var i = h.indexOf('<!--RES-->'); return i < 0 ? [h, null] : [h.slice(0, i), h.slice(i + 10)]; }
  function paint() {
    var b = box(); if (!b) return; var x = GID ? find(GID) : null;
    if (!x) { b.innerHTML = '<div style="display:flex"><button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + liste0(); return; }
    if (!TAB) TAB = CFG.tabs[0][0];
    var dis = ro(x), tabs = CFG.tabs.concat([['rap', '✅ Rapport']]), s = coupe(onglet(x, dis));
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><button data-a="back" style="padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">← Dossiers</button>' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:999px;background:' + (TAB === t[0] ? '#0f766e' : '#e2e8f0') + ';color:' + (TAB === t[0] ? '#fff' : '#0f172a') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' +
      grid(lab('Titre', inp('titre', x.titre, dis)) + lab('Projet', '<select data-f="project_id"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="">—</option>' + projets().map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === x.project_id ? ' selected' : '') + '>' + esc(p.nom) + '</option>'; }).join('') + '</select>') + lab('Site / bâtiment', inp('site', x.site, dis)) + lab(CFG.auteur, inp('auteur', x.auteur, dis))) + '<p style="font-size:12px;color:#475569;margin:6px 0">' + esc(x.no) + ' — ' + esc(x.statut) + (dis ? ' (verrouillé : rouvrir pour modifier)' : '') + '</p><div id="' + CFG.id + 'Tab">' + s[0] + (s[1] !== null ? '<div id="' + CFG.id + 'Res">' + s[1] + '</div>' : '') + '</div>';
  }
  function repaintRes(x) { var s = coupe(onglet(x, ro(x))), r = d.getElementById(CFG.id + 'Res'); if (s[1] === null || !r) return paint(); r.innerHTML = s[1]; }
  function setPath(x, f, v) { var p = f.split('.'), o = x; while (p.length > 1) o = o[p.shift()]; o[p[0]] = v; }
  function jrn(x, m) { x.histo.push({ t: Date.now(), msg: m }); }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), x = GID ? find(GID) : null; if (!f || !x || ro(x)) return;
    setPath(x, f, t.value); var full = CFG.onSet ? CFG.onSet(x, f) : false; saveDos(x); if (full) paint(); else if (f !== 'project_id' && f !== 'titre' && f !== 'site' && f !== 'auteur') repaintRes(x);
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i'), x = GID ? find(GID) : null, A = CFG.audit;
    if (a === 'close') { var o = d.getElementById(CFG.id); if (o) o.remove(); return; }
    if (a === 'new') { var n = CFG.creer(); saveDos(n); GID = n.id; TAB = CFG.tabs[0][0]; audit(A + '.nouveau', n.no, {}); return paint(); }
    if (a === 'open') { GID = i; TAB = CFG.tabs[0][0]; return paint(); }
    if (a === 'back') { GID = null; return paint(); }
    if (a === 'tab') { TAB = i; return paint(); }
    if (!x) return;
    if (CFG.extra && CFG.extra(a, i, x)) return;
    if (a === 'verifier') { var bl = bloque(x); if (bl.length) return toast('Vérification impossible : ' + bl.map(function (v) { return v.id; }).filter(function (v, j, s) { return s.indexOf(v) === j; }).join(', ') + ' (voir Rapport).', 'warn'); return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le vérificateur doit être une autre personne que l’auteur.', 'warn'); x.statut = 'Vérifié'; x.verifie = { par: par, t: Date.now() }; jrn(x, 'Vérifié par ' + par); saveDos(x); audit(A + '.verifie', x.no, { par: par }); paint(); }); }
    if (a === 'viser') return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le visa ne peut pas être donné par l’auteur.', 'warn'); x.statut = 'Visé'; x.vise = { par: par, t: Date.now() }; jrn(x, 'Visé par ' + par); saveDos(x); audit(A + '.vise', x.no, { par: par }); paint(); });
    if (a === 'rouvrir') return ask('Motif de la réouverture (obligatoire) :', '').then(function (m) { m = String(m || '').trim(); if (!m) return toast('Motif obligatoire.', 'warn'); jrn(x, 'Rouvert en brouillon — ' + m); x.statut = 'Brouillon'; delete x.verifie; delete x.vise; saveDos(x); audit(A + '.rouvert', x.no, { motif: m }); paint(); });
    var cb = CFG.csvBtns.filter(function (b) { return b[0] === a; })[0]; if (cb) { var c = cb[2](x); return csv(c.rows, c.name); }
    if (a === 'pdf') { var rows = CFG.pdfRows(x); verif(x).forEach(function (v) { rows.push(['Contrôle ' + v.id, v.niveau + ' : ' + v.msg]); }); return pdf({ titre: CFG.pdfTitre, sousTitre: san(x.no + ' — ' + (x.titre || '')), rows: rows.map(function (r) { return [san(r[0]), san(r[1])]; }), notes: [san(CFG.pdfNote)], footer: san(x.no + ' — ' + x.statut) }); }
  }
  function ouvrir(tab) {
    if (tab) TAB = tab; var o = d.getElementById(CFG.id); if (o) o.remove();
    o = d.createElement('div'); o.id = CFG.id; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = CFG.id + 'Box'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('change', onChange); c.addEventListener('click', onClick); paint();
  }
  function ui() {
    if (d.getElementById(CFG.id + 'Btn')) return; var b = null; CFG.anchors.forEach(function (id) { if (!b) b = d.getElementById(id); }); if (!b) return;
    var k = d.createElement('button'); k.id = CFG.id + 'Btn'; k.setAttribute('data-exb-cat', CFG.cat); k.setAttribute('data-exb-desc', CFG.desc); k.className = b.className; k.textContent = CFG.label; k.onclick = function () { ouvrir(CFG.tabs[0][0]); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined' && d.documentElement && d.documentElement.nodeType) new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: CFG.audit, name: CFG.nom, version: '1.0.0', area: CFG.area, deps: [], collections: [K] }); } catch (e) {}
  EXP.open = ouvrir; EXP.verif = verif; EXP.nouveau = CFG.creer; EXP.calc = calc;
  w[CFG.glob] = EXP;
  if (typeof module !== 'undefined' && module.exports) module.exports = w[CFG.glob];
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { addEventListener: function () {}, documentElement: {} });
