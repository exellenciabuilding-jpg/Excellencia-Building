/* Excellencia Building V172 — Stock & Approvisionnement : compléments (module 06 du cahier des charges).
 * Principe : le stock existant (exb_stock / exb_stock_moves) reste la SEULE source de vérité des quantités totales.
 *  - Dépôts + transferts : exb_stock_depots, exb_stock_transfers (nouveaux). Un transfert ne change PAS le total ; le solde par dépôt est CALCULÉ
 *    (dépôt « Principal » = total − quantités placées dans les autres dépôts). Transfert refusé si solde du dépôt source insuffisant.
 *  - Inventaires physiques : exb_stock_counts (nouveau). À la validation, chaque écart EXIGE un motif ; l'ajustement est écrit dans le stock existant
 *    sous forme de mouvement in/out (réf. INV-…) → traçable, annulable seulement par un nouvel inventaire.
 *  - Comparatifs fournisseurs : exb_stock_consults (nouveau). Le moins-disant est proposé ; choisir un autre fournisseur exige un motif.
 *  - Rapprochement commande / réception / facture : CALCULÉ en lecture seule depuis exb_purchase_orders et exb_v92_supplier_invoices.
 * Le stock ne porte pas de prix : aucune valorisation n'est inventée (les montants viennent des bons de commande et factures fournisseurs).
 * Retrait : supprimer la balise <script src="exb-stock-plus.js"> (les données nouvelles restent dans leurs clés). */
(function (w) {
  'use strict';
  var d = w.document, $ = function (i) { return d && d.getElementById ? d.getElementById(i) : null; };
  var K = { dep: 'exb_stock_depots', tr: 'exb_stock_transfers', ct: 'exb_stock_counts', cs: 'exb_stock_consults' };
  var MAIN = 'Principal';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function norm(s) { return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim(); }
  function pn(v) { var x = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isNaN(x) ? 0 : x; }
  function r3(n) { return Math.round((+n || 0) * 1000) / 1000; }
  function nf(n) { return Number(n || 0).toLocaleString('fr-FR', { maximumFractionDigits: 3 }).replace(/[  ]/g, ' '); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function LD(k, df) { try { var v = w.load ? w.load(k, df) : JSON.parse(w.localStorage.getItem(k)); return v == null ? df : v; } catch (e) { return df; } }
  function SV(k, v) { try { return w.save ? w.save(k, v) : (w.localStorage.setItem(k, JSON.stringify(v)), true); } catch (e) { return false; } }
  function uid(p) { try { return w.exbId(p); } catch (e) { return p + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); } }
  function audit(a, o, x) { try { w.EXBCore && w.EXBCore.audit.log(a, o, x); } catch (e) {} }
  function say(m, t) { try { w.notify(m, t || 'info', 4500); } catch (e) { try { w.exbAlert(m); } catch (x) {} } }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction || i.role)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function can(c, m) { try { return w.EXBDB && w.EXBDB.can ? !!w.EXBDB.can(c, m) : true; } catch (e) { return true; } }

  /* ---------- accès au stock existant (variables globales de l'application, repli sur le stockage) ---------- */
  function stockList() { try { if (typeof exbStock !== 'undefined' && Array.isArray(exbStock)) return exbStock; } catch (e) {} return LD('exb_stock', []); }
  function moveList() { try { if (typeof exbStockMoves !== 'undefined' && Array.isArray(exbStockMoves)) return exbStockMoves; } catch (e) {} return LD('exb_stock_moves', []); }
  function persistStock(st, mv) {
    try { if (typeof exbStock !== 'undefined') { exbStock = st; } } catch (e) {}
    try { if (typeof exbStockMoves !== 'undefined') { exbStockMoves = mv; } } catch (e) {}
    SV('exb_stock', st); SV('exb_stock_moves', mv);
    try { if (typeof renderExbStock === 'function') renderExbStock(); } catch (e) {}
  }
  function depots() { var a = LD(K.dep, []); return [MAIN].concat(a.map(function (x) { return x.name; })); }
  function transfers() { return LD(K.tr, []).filter(function (t) { return !t.annule; }); }

  /* ---------- dépôts : soldes calculés ---------- */
  function balances(itemId) {
    var it = stockList().find(function (s) { return s.id === itemId; }), total = it ? (+it.qty || 0) : 0, by = {};
    transfers().forEach(function (t) { if (t.item !== itemId) return; by[t.from] = r3((by[t.from] || 0) - t.qty); by[t.to] = r3((by[t.to] || 0) + t.qty); });
    var others = 0; Object.keys(by).forEach(function (k) { if (k !== MAIN) others += by[k]; });
    by[MAIN] = r3(total - others); // les transferts depuis/vers Principal sont déjà inclus dans others par différence
    return { total: total, by: by };
  }
  function transfer(o) {
    var it = stockList().find(function (s) { return s.id === o.item; });
    if (!it) return { error: 'Article inconnu.' };
    var q = r3(pn(o.qty)); if (!(q > 0)) return { error: 'La quantité doit être supérieure à 0.' };
    var from = String(o.from || '').trim(), to = String(o.to || '').trim();
    if (!from || !to) return { error: 'Choisissez le dépôt source et le dépôt destination.' };
    if (norm(from) === norm(to)) return { error: 'Le dépôt source et le dépôt destination doivent être différents.' };
    var dp = depots(); if (dp.indexOf(from) < 0 || dp.indexOf(to) < 0) return { error: 'Dépôt inconnu.' };
    var b = balances(o.item).by; if ((b[from] || 0) < q - 1e-9) return { error: 'Solde insuffisant dans « ' + from + ' » : ' + nf(b[from] || 0) + ' ' + (it.unit || '') + '.' };
    var t = { id: uid('TRF'), date: o.date || today(), item: o.item, name: it.name, unit: it.unit || '', from: from, to: to, qty: q, motif: String(o.motif || '').trim(), by: who() };
    var a = LD(K.tr, []); a.push(t); SV(K.tr, a); audit('stock.transfert', t.id, { article: it.name, de: from, vers: to, qty: q }); return { ok: true, transfer: t };
  }
  function cancelTransfer(id, motif) {
    motif = String(motif || '').trim(); if (!motif) return { error: 'Le motif d’annulation est obligatoire.' };
    var a = LD(K.tr, []), t = a.find(function (x) { return x.id === id; }); if (!t || t.annule) return { error: 'Transfert introuvable ou déjà annulé.' };
    t.annule = true; t.annule_motif = motif; t.annule_par = who(); t.annule_date = today();
    SV(K.tr, a); var b = balances(t.item); // refuser (et revenir en arrière) si l'annulation rend un solde négatif
    var neg = Object.keys(b.by).some(function (k) { return b.by[k] < -1e-9; });
    if (neg) { t.annule = false; delete t.annule_motif; delete t.annule_par; delete t.annule_date; SV(K.tr, a); return { error: 'Annulation impossible : des transferts ultérieurs utilisent cette quantité.' }; }
    audit('stock.transfert.annule', id, { motif: motif }); return { ok: true };
  }
  function addDepot(name) {
    name = String(name || '').trim(); if (!name) return { error: 'Le nom du dépôt est obligatoire.' };
    if (depots().some(function (x) { return norm(x) === norm(name); })) return { error: 'Ce dépôt existe déjà.' };
    var a = LD(K.dep, []); a.push({ id: uid('DEP'), name: name }); SV(K.dep, a); audit('stock.depot', name, {}); return { ok: true };
  }

  /* ---------- inventaires ---------- */
  function newCount(depot) {
    var dp = depot || MAIN; var lines = stockList().map(function (s) { var th = balances(s.id).by[dp] || 0; return { item: s.id, name: s.name, unit: s.unit || '', theo: th, counted: '', motif: '' }; });
    return { id: uid('INV'), date: today(), depot: dp, status: 'brouillon', lines: lines, by: who() };
  }
  function checkCount(c) {
    var err = [], touched = 0;
    c.lines.forEach(function (l) {
      if (l.counted === '' || l.counted == null) return; touched++;
      var q = pn(l.counted); if (q < 0) err.push(l.name + ' : quantité négative.');
      var diff = r3(q - l.theo); if (Math.abs(diff) > 1e-9 && !String(l.motif || '').trim()) err.push(l.name + ' : écart de ' + nf(diff) + ' sans motif.');
    });
    if (!touched) err.push('Aucune quantité comptée.'); return err;
  }
  function validateCount(c) {
    if (c.status === 'validé') return { error: 'Inventaire déjà validé.' };
    var err = checkCount(c); if (err.length) return { error: err.join(' ') };
    var st = stockList().map(function (s) { return Object.assign({}, s); }), mv = moveList().slice(), adj = [];
    c.lines.forEach(function (l) {
      if (l.counted === '' || l.counted == null) return;
      var live = balances(l.item).by[c.depot] || 0, q = pn(l.counted), diff = r3(q - live); l.theo_final = live; l.diff = diff;
      if (Math.abs(diff) < 1e-9) return;
      var it = st.find(function (s) { return s.id === l.item; }); if (!it) return;
      it.qty = r3((+it.qty || 0) + diff);
      if (it.qty < 0) { it.qty = 0; }
      mv.push({ id: uid('MV'), item: l.item, type: diff > 0 ? 'in' : 'out', qty: Math.abs(diff), ref: c.id + ' (inventaire ' + c.depot + ')', date: today(), motif: l.motif });
      adj.push({ name: l.name, diff: diff, motif: l.motif });
    });
    persistStock(st, mv); c.status = 'validé'; c.validated_at = new Date().toISOString(); c.validated_by = who(); c.adjustments = adj;
    var a = LD(K.ct, []).filter(function (x) { return x.id !== c.id; }); a.push(c); SV(K.ct, a); audit('stock.inventaire', c.id, { depot: c.depot, ajustements: adj.length });
    return { ok: true, adjustments: adj };
  }
  function saveDraft(c) { var a = LD(K.ct, []).filter(function (x) { return x.id !== c.id; }); a.push(c); SV(K.ct, a); return { ok: true }; }

  /* ---------- comparatifs fournisseurs ---------- */
  function lowest(cs) { var o = (cs.offers || []).filter(function (x) { return +x.pu > 0; }); if (!o.length) return null; return o.reduce(function (a, b) { return (+b.pu < +a.pu || (+b.pu === +a.pu && (+b.delay || 99999) < (+a.delay || 99999))) ? b : a; }); }
  function saveConsult(cs) {
    if (!String(cs.item || '').trim()) return { error: 'La désignation est obligatoire.' };
    cs.offers = (cs.offers || []).filter(function (x) { return String(x.supplier || '').trim() && pn(x.pu) > 0; }).map(function (x) { return { supplier: String(x.supplier).trim(), pu: pn(x.pu), delay: x.delay === '' || x.delay == null ? '' : pn(x.delay), note: x.note || '' }; });
    if (cs.offers.length < 2) return { error: 'Un comparatif demande au moins 2 offres (fournisseur + prix unitaire).' };
    if (cs.chosen) {
      var low = lowest(cs), ch = cs.offers.find(function (x) { return x.supplier === cs.chosen; });
      if (!ch) return { error: 'Le fournisseur retenu doit faire partie des offres.' };
      if (low && ch.pu > low.pu + 1e-9 && !String(cs.motif || '').trim()) return { error: 'Le fournisseur retenu n’est pas le moins-disant (' + low.supplier + ') : un motif est obligatoire.' };
    }
    cs.qty = pn(cs.qty) || 1; var a = LD(K.cs, []).filter(function (x) { return x.id !== cs.id; }); a.push(cs); SV(K.cs, a); audit('stock.comparatif', cs.id, { article: cs.item, retenu: cs.chosen || '' }); return { ok: true, consult: cs };
  }

  /* ---------- rapprochement commande / réception / facture (calculé) ---------- */
  function poRows() {
    var pos = LD('exb_purchase_orders', []), sups = LD('exb_suppliers', []).concat(LD('exb_v92_suppliers', [])), inv = LD('exb_v92_supplier_invoices', []);
    return pos.map(function (p) {
      var ord = 0, rec = 0; (p.lines || []).forEach(function (l) { var q = +l.q || 0, pu = +l.pu || 0; ord += q * pu; rec += Math.min(+l.rec || 0, q) * pu; });
      var sp = sups.find(function (s) { return s.id === p.supplier_id; });
      var fact = inv.filter(function (f) { var ref = norm(f.po || f.po_no || f.order || f.order_id || f.purchase_order || f.ref || ''); return ref && (ref === norm(p.no) || ref === norm(p.id)); })
        .reduce(function (a, f) { return a + (+f.amount || +f.total || +f.ttc || 0); }, 0);
      var paid = (p.payments || []).reduce(function (a, x) { return a + (+x.amount || 0); }, 0);
      ord = Math.round(ord * 100) / 100; rec = Math.round(rec * 100) / 100; fact = Math.round(fact * 100) / 100;
      var flags = []; if (fact > rec + 0.005) flags.push('Facturé > reçu'); if (rec < ord - 0.005) flags.push('Reçu partiel'); if (!fact && rec > 0) flags.push('Reçu non facturé'); if (paid > Math.max(rec, fact) + 0.005 && paid > 0) flags.push('Payé > reçu/facturé');
      return { no: p.no || p.id, supplier: sp ? sp.name : '', date: p.date || '', ordered: ord, received: rec, invoiced: fact, paid: Math.round(paid * 100) / 100, flags: flags, ok: !flags.length };
    });
  }

  /* ---------- interface ---------- */
  var S = { tab: 'dep', count: null, consult: null };
  function inp(id, v, ph, ex) { return '<input id="' + id + '" value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(ph || '') + '" style="padding:6px;max-width:100%;box-sizing:border-box;' + (ex || '') + '">'; }
  function btn(id, l) { return '<button id="' + id + '" type="button" style="padding:6px 10px;margin:2px">' + l + '</button>'; }
  function tbl(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12.5px"><thead><tr style="text-align:left;background:#f1f5fb">' + h.map(function (x) { return '<th style="padding:5px">' + x + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'; }
  function td(v, a) { return '<td style="padding:5px;border-top:1px solid #e2e8f0;' + (a ? 'text-align:' + a : '') + '">' + v + '</td>'; }
  function opts(arr, sel) { return arr.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === sel ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }
  function body() { var o = $('stp_ov'); return o && o.querySelector('.stp_body'); }
  function tabs() {
    var o = $('stp_ov'); if (!o) return; var T = [['dep', '🏬 Dépôts & transferts'], ['inv', '📋 Inventaires'], ['cmp', '⚖ Comparatifs'], ['rap', '🔗 Rapprochement']];
    o.querySelector('.stp_tabs').innerHTML = T.map(function (t) { return '<button type="button" data-t="' + t[0] + '" style="padding:6px 10px;margin:2px;' + (S.tab === t[0] ? 'font-weight:700;border:2px solid #1d4ed8' : '') + '">' + t[1] + '</button>'; }).join('');
    Array.prototype.forEach.call(o.querySelectorAll('.stp_tabs button'), function (b) { b.onclick = function () { S.tab = b.getAttribute('data-t'); render(); }; });
  }
  function render() { tabs(); var b = body(); if (!b) return; ({ dep: vDep, inv: vInv, cmp: vCmp, rap: vRap })[S.tab](b); }

  function vDep(b) {
    var st = stockList(), dp = depots(), items = st.map(function (s) { return [s.id, s.name + ' (' + nf(s.qty) + ' ' + (s.unit || '') + ')']; }), canW = can('stock', 'ecrire') || can('exb_stock', 'ecrire');
    var h = '<p style="margin:4px 0;color:#475569">Le total par article reste celui du Stock. Un transfert déplace seulement la quantité entre dépôts.</p>';
    if (canW) h += '<p>' + inp('sd_new', '', 'Nouveau dépôt (ex. Chantier Gombe)', 'width:230px') + btn('sd_add', '➕ Ajouter le dépôt') + '</p>';
    h += '<h4 style="margin:8px 0 4px">Soldes par dépôt</h4>';
    h += st.length ? tbl(['Article', 'Total'].concat(dp), st.map(function (s) { var bl = balances(s.id); return '<tr>' + td(esc(s.name)) + td(nf(bl.total) + ' ' + esc(s.unit || ''), 'right') + dp.map(function (x) { return td(nf(bl.by[x] || 0), 'right'); }).join('') + '</tr>'; })) : '<p>Aucun article en stock.</p>';
    if (canW && st.length && dp.length > 1) h += '<h4 style="margin:10px 0 4px">Nouveau transfert</h4><p><select id="st_it">' + opts(items) + '</select> <select id="st_fr">' + opts(dp.map(function (x) { return [x, 'De : ' + x]; })) + '</select> <select id="st_to">' + opts(dp.map(function (x) { return [x, 'Vers : ' + x]; }), dp[1]) + '</select> ' + inp('st_q', '', 'Quantité', 'width:90px') + ' ' + inp('st_m', '', 'Motif (facultatif)', 'width:170px') + btn('st_go', '⇄ Transférer') + '</p>';
    var tr = LD(K.tr, []).slice().reverse();
    h += '<h4 style="margin:10px 0 4px">Historique des transferts</h4>' + (tr.length ? tbl(['Date', 'Article', 'Qté', 'De → Vers', 'Motif', ''], tr.map(function (t) { return '<tr' + (t.annule ? ' style="opacity:.55;text-decoration:line-through"' : '') + '>' + td(esc(t.date)) + td(esc(t.name)) + td(nf(t.qty) + ' ' + esc(t.unit), 'right') + td(esc(t.from) + ' → ' + esc(t.to)) + td(esc(t.motif || '') + (t.annule ? ' (annulé : ' + esc(t.annule_motif) + ')' : '')) + td(t.annule || !canW ? '' : '<button type="button" class="st_x" data-id="' + esc(t.id) + '">Annuler</button>') + '</tr>'; })) : '<p>Aucun transfert.</p>');
    b.innerHTML = h;
    if ($('sd_add')) $('sd_add').onclick = function () { var r = addDepot($('sd_new').value); if (r.error) return say(r.error, 'warn'); say('Dépôt ajouté.', 'success'); render(); };
    if ($('st_go')) $('st_go').onclick = function () { var r = transfer({ item: $('st_it').value, from: $('st_fr').value, to: $('st_to').value, qty: $('st_q').value, motif: $('st_m').value }); if (r.error) return say(r.error, 'warn'); say('Transfert enregistré.', 'success'); render(); };
    Array.prototype.forEach.call(b.querySelectorAll('.st_x'), function (x) { x.onclick = async function () { var m = await w.exbPrompt('Motif de l’annulation du transfert :', ''); if (m == null) return; var r = cancelTransfer(x.getAttribute('data-id'), m); if (r.error) return say(r.error, 'warn'); say('Transfert annulé.', 'success'); render(); }; });
  }

  function vInv(b) {
    var h = '', c = S.count;
    if (!c) {
      var dp = depots(), all = LD(K.ct, []).slice().reverse();
      h += '<p>' + '<select id="si_dep">' + opts(dp.map(function (x) { return [x, x]; })) + '</select> ' + btn('si_new', '📋 Nouvel inventaire') + '</p>';
      h += all.length ? tbl(['N°', 'Date', 'Dépôt', 'Statut', 'Ajustements', ''], all.map(function (x) { return '<tr>' + td(esc(x.id)) + td(esc(x.date)) + td(esc(x.depot)) + td(esc(x.status)) + td(x.adjustments ? x.adjustments.length : '') + td('<button type="button" class="si_open" data-id="' + esc(x.id) + '">' + (x.status === 'validé' ? 'Voir' : 'Reprendre') + '</button>') + '</tr>'; })) : '<p>Aucun inventaire.</p>';
      b.innerHTML = h; $('si_new').onclick = function () { S.count = newCount($('si_dep').value); render(); };
      Array.prototype.forEach.call(b.querySelectorAll('.si_open'), function (x) { x.onclick = function () { S.count = LD(K.ct, []).find(function (z) { return z.id === x.getAttribute('data-id'); }); render(); }; }); return;
    }
    var ro = c.status === 'validé';
    h = '<p><b>' + esc(c.id) + '</b> — dépôt « ' + esc(c.depot) + ' » — ' + esc(c.date) + ' — ' + esc(c.status) + '</p>';
    h += tbl(['Article', 'Théorique', 'Compté', 'Écart', 'Motif de l’écart'], c.lines.map(function (l, k) {
      var q = l.counted === '' || l.counted == null ? null : pn(l.counted), diff = q == null ? '' : r3(q - (ro ? (l.theo_final != null ? l.theo_final : l.theo) : l.theo));
      return '<tr>' + td(esc(l.name) + ' <small>' + esc(l.unit) + '</small>') + td(nf(ro && l.theo_final != null ? l.theo_final : l.theo), 'right') + td(ro ? esc(l.counted) : inp('sc_q' + k, l.counted, '', 'width:80px')) + td(diff === '' ? '' : '<b style="color:' + (diff ? '#b91c1c' : '#15803d') + '">' + nf(diff) + '</b>', 'right') + td(ro ? esc(l.motif || '') : inp('sc_m' + k, l.motif, 'obligatoire si écart', 'width:190px')) + '</tr>';
    }));
    if (!ro) h += '<p>' + btn('si_save', '💾 Enregistrer le brouillon') + btn('si_val', '✅ Valider et ajuster le stock') + '</p>';
    h += '<p>' + btn('si_back', '← Retour') + '</p>'; b.innerHTML = h;
    function read() { c.lines.forEach(function (l, k) { if ($('sc_q' + k)) { l.counted = $('sc_q' + k).value; l.motif = $('sc_m' + k).value; } }); }
    if (!ro) {
      Array.prototype.forEach.call(b.querySelectorAll('input'), function (i) { i.onchange = function () { read(); render(); }; });
      $('si_save').onclick = function () { read(); saveDraft(c); say('Brouillon enregistré.', 'success'); };
      $('si_val').onclick = async function () { read(); var e = checkCount(c); if (e.length) return say(e.join(' '), 'warn'); if (!(await w.exbConfirm('Valider cet inventaire ? Les écarts seront appliqués au stock (mouvements tracés).'))) return; var r = validateCount(c); if (r.error) return say(r.error, 'warn'); say('Inventaire validé : ' + r.adjustments.length + ' ajustement(s).', 'success'); render(); };
    }
    $('si_back').onclick = function () { S.count = null; render(); };
  }

  function vCmp(b) {
    var c = S.consult, h = '';
    if (!c) {
      var all = LD(K.cs, []).slice().reverse();
      h = '<p>' + btn('sk_new', '➕ Nouvelle consultation') + '</p>' + (all.length ? tbl(['Date', 'Article', 'Qté', 'Moins-disant', 'Retenu', ''], all.map(function (x) { var lw = lowest(x); return '<tr>' + td(esc(x.date)) + td(esc(x.item)) + td(nf(x.qty), 'right') + td(lw ? esc(lw.supplier) + ' (' + nf(lw.pu) + ')' : '') + td(esc(x.chosen || '—')) + td('<button type="button" class="sk_open" data-id="' + esc(x.id) + '">Ouvrir</button>') + '</tr>'; })) : '<p>Aucune consultation.</p>');
      b.innerHTML = h; $('sk_new').onclick = function () { S.consult = { id: uid('CS'), date: today(), item: '', unit: '', qty: 1, offers: [{ supplier: '', pu: '', delay: '', note: '' }, { supplier: '', pu: '', delay: '', note: '' }], chosen: '', motif: '' }; render(); };
      Array.prototype.forEach.call(b.querySelectorAll('.sk_open'), function (x) { x.onclick = function () { S.consult = LD(K.cs, []).find(function (z) { return z.id === x.getAttribute('data-id'); }); render(); }; }); return;
    }
    var lw = lowest(c);
    h = '<p>' + inp('sk_item', c.item, 'Article / prestation à acheter', 'width:240px') + ' ' + inp('sk_q', c.qty, 'Qté', 'width:70px') + ' ' + inp('sk_u', c.unit, 'Unité', 'width:70px') + '</p>';
    h += tbl(['Fournisseur', 'Prix unitaire', 'Délai (jours)', 'Remarque', 'Total', 'Retenir'], c.offers.map(function (o, k) {
      return '<tr>' + td(inp('so_s' + k, o.supplier, 'Fournisseur', 'width:150px')) + td(inp('so_p' + k, o.pu, '0', 'width:90px')) + td(inp('so_d' + k, o.delay, '', 'width:70px')) + td(inp('so_n' + k, o.note, '', 'width:140px')) + td(pn(o.pu) > 0 ? nf(pn(o.pu) * (pn(c.qty) || 1)) + (lw && o.supplier === lw.supplier ? ' ⭐' : '') : '', 'right') + td('<input type="radio" name="so_ch" class="so_ch" value="' + k + '"' + (o.supplier && o.supplier === c.chosen ? ' checked' : '') + '>') + '</tr>';
    }));
    h += '<p>' + btn('sk_add', '➕ Ajouter une offre') + '</p><p>' + inp('sk_mot', c.motif, 'Motif si le retenu n’est pas le moins-disant', 'width:340px') + '</p><p>' + btn('sk_save', '💾 Enregistrer') + btn('sk_back', '← Retour') + '</p>';
    b.innerHTML = h;
    function read() { c.item = $('sk_item').value; c.qty = $('sk_q').value; c.unit = $('sk_u').value; c.motif = $('sk_mot').value; c.offers.forEach(function (o, k) { o.supplier = $('so_s' + k).value; o.pu = $('so_p' + k).value; o.delay = $('so_d' + k).value; o.note = $('so_n' + k).value; }); var r = b.querySelector('.so_ch:checked'); c.chosen = r ? (c.offers[+r.value].supplier || '') : ''; }
    $('sk_add').onclick = function () { read(); c.offers.push({ supplier: '', pu: '', delay: '', note: '' }); render(); };
    $('sk_save').onclick = function () { read(); var r = saveConsult(c); if (r.error) return say(r.error, 'warn'); say('Comparatif enregistré.', 'success'); S.consult = null; render(); };
    $('sk_back').onclick = function () { S.consult = null; render(); };
  }

  function vRap(b) {
    var rows = poRows();
    b.innerHTML = '<p>' + btn('sr_pdf', '🖨 État du stock PDF') + '</p><p style="color:#475569">Lecture seule : commandé (bons de commande) → reçu (réceptions) → facturé (factures fournisseurs rattachées par n° de BC) → payé.</p>' + (rows.length ? tbl(['BC', 'Fournisseur', 'Commandé', 'Reçu', 'Facturé', 'Payé', 'Contrôle'], rows.map(function (r) { return '<tr>' + td(esc(r.no)) + td(esc(r.supplier)) + td(nf(r.ordered), 'right') + td(nf(r.received), 'right') + td(nf(r.invoiced), 'right') + td(nf(r.paid), 'right') + td(r.ok ? '✅ Cohérent' : '⚠ ' + esc(r.flags.join(' · '))) + '</tr>'; })) : '<p>Aucun bon de commande.</p>');
    if ($('sr_pdf')) $('sr_pdf').onclick = function () { try { pdfRapport(); } catch (e) { say('Export PDF impossible.', 'error'); } };
  }

  /* V177 : rapport PDF de marque (soldes par dépôt + chaîne commandé → reçu → facturé → payé) */
  function rapportHtml() {
    var st = stockList(), dp = depots(), rows = poRows();
    var h = '<h2>Soldes par dépôt</h2>' + (st.length ? '<table><tr><th>Article</th><th class="r">Total</th>' + dp.map(function (x) { return '<th class="r">' + esc(x) + '</th>'; }).join('') + '</tr>' + st.map(function (s) { var bl = balances(s.id); return '<tr><td>' + esc(s.name) + '</td><td class="r">' + nf(bl.total) + ' ' + esc(s.unit || '') + '</td>' + dp.map(function (x) { return '<td class="r">' + nf(bl.by[x] || 0) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>' : '<p>Aucun article en stock.</p>');
    h += '<h2>Bons de commande : commandé → reçu → facturé → payé</h2>' + (rows.length ? '<table><tr><th>BC</th><th>Fournisseur</th><th class="r">Commandé</th><th class="r">Reçu</th><th class="r">Facturé</th><th class="r">Payé</th><th>Contrôle</th></tr>' + rows.map(function (r) { return '<tr><td>' + esc(r.no) + '</td><td>' + esc(r.supplier) + '</td><td class="r">' + nf(r.ordered) + '</td><td class="r">' + nf(r.received) + '</td><td class="r">' + nf(r.invoiced) + '</td><td class="r">' + nf(r.paid) + '</td><td>' + (r.ok ? 'Cohérent' : '⚠ ' + esc(r.flags.join(' · '))) + '</td></tr>'; }).join('') + '</table>' : '<p>Aucun bon de commande.</p>');
    return { html: h, meta: [['Articles', st.length], ['Dépôts', dp.length], ['Bons de commande', rows.length]] };
  }
  function pdfRapport() {
    if (!w.EXBRapport) { say('Module d’export PDF indisponible.', 'error'); return null; }
    var R = rapportHtml(); audit('stock.plus.export', 'pdf', who());
    return w.EXBRapport.print('État du stock et des approvisionnements', { sousTitre: 'Situation au ' + today(), meta: R.meta, html: R.html, note: 'Lecture seule : le total par article reste celui du Stock.', paysage: true, prefix: 'STK' });
  }

  function open() {
    var o = $('stp_ov'); if (o) o.remove(); o = d.createElement('div'); o.id = 'stp_ov';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.innerHTML = '<div style="background:var(--card,#fff);color:var(--fg,#0f172a);width:100%;max-width:940px;border-radius:12px;padding:14px;box-sizing:border-box"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">📦 Stock & approvisionnement — compléments</h3><button id="stp_x" type="button" aria-label="Fermer">✕</button></div><div class="stp_tabs" style="margin:8px 0"></div><div class="stp_body"></div></div>';
    d.body.appendChild(o); $('stp_x').onclick = function () { o.remove(); }; S.count = null; S.consult = null; audit('stock.plus.ouvert', 'stock', who()); render();
  }
  function mount() { var ref = $('bstk'); if (ref && !$('bstkp')) { var b = d.createElement('button'); b.id = 'bstkp'; b.type = 'button'; b.textContent = '📦 Stock : dépôts, inventaires, comparatifs'; b.onclick = open; ref.parentNode.insertBefore(b, ref.nextSibling); } }
  function start() { mount(); var n = 0, t = setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} if ($('bstkp') || ++n > 40) clearInterval(t); }, 1500); try { w.EXBCore && w.EXBCore.modules.register({ id: 'stock-plus', name: 'Stock : dépôts, inventaires, comparatifs', version: '172.0.0', area: 'Gestion & finances' }); } catch (e) {} }

  w.EXBSTOCKPLUS = { open: open, _t: { rapportHtml: rapportHtml, pdfRapport: pdfRapport, balances: balances, transfer: transfer, cancelTransfer: cancelTransfer, addDepot: addDepot, newCount: newCount, checkCount: checkCount, validateCount: validateCount, saveConsult: saveConsult, lowest: lowest, poRows: poRows, depots: depots } };
  if (d) { if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else setTimeout(start, 0); }
})(typeof window !== 'undefined' ? window : globalThis);
