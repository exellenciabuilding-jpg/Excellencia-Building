/* Excellencia Building — ARCHIVES v1 (cahier des charges ERP, module 08).
 * Bibliothèque documentaire centralisée : classement par projet / client / service / type / période, métadonnées et mots-clés,
 * recherche et filtres, versionnement (empreinte SHA-256 par version), aperçu, droits de téléchargement, partage limité (nom ou fonction,
 * avec date de fin), archivage, durée de conservation, historique horodaté (ajout seul) relié au journal d'audit chaîné du noyau CORE,
 * suppression autorisée (motif obligatoire ; pendant la conservation : administrateur seul).
 *
 * Données : exb_ar_docs (fiches, sans contenu) · exb_ar_f_<id>_<n> (contenu d'une version, « data: » rangé par exb-bigstore en IndexedDB)
 *           exb_ar_supprimes (trace des suppressions). Synchronisées comme les autres clés exb_*.
 * Le moteur (EXBAR.engine) est PUR : aucune lecture de l'écran ni du stockage, testable seul (tools/test-archives.js).
 * Les autres modules (Scanner, Plan Editor, Project Manager…) déposent avec EXBAR.add({...}) et peuvent écouter le bus EXBCore
 * (archives.depose / .version / .archive / .desarchive / .restaure / .droits / .partage / .supprime). Ce lot ne modifie AUCUN autre module.
 * Limites assumées : identité = nom OU fonction (mode local : non vérifiée) ; les droits sont appliqués par l'écran, pas par un serveur
 * (un utilisateur technique peut lire le stockage local de son propre appareil) ; fichier limité à 15 Mo ; synchronisation par clé entière.
 * Pour retirer : supprimer la balise <script src="exb-archives.js"> de index.html (les données restent). */
(function (w, d) {
  'use strict';
  if (w.EXBAR) return;
  var DK = 'exb_ar_docs', FK = 'exb_ar_f_', XK = 'exb_ar_supprimes', PK = 'exb_ar_prefs', MAX = 15 * 1024 * 1024;

  /* ============================ MOTEUR PUR ============================ */
  var TYPES = { plan: 'Plan', note: 'Note de calcul', contrat: 'Contrat', devis: 'Devis', facture: 'Facture', rapport: 'Rapport', pv: 'PV / réception', courrier: 'Courrier', photo: 'Photo', certificat: 'Certificat', autre: 'Autre' };
  var SERVICES = { direction: 'Direction', etudes: 'Bureau d\'études', chantier: 'Chantier', finance: 'Finances', rh: 'RH', commercial: 'Commercial', formation: 'Formation', technique: 'Technique' };
  var STAT = { actif: 'Actif', archive: 'Archivé' };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function num(x) { x = +x; return isFinite(x) ? x : 0; }
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function day(t) { return String(t || '').slice(0, 10); }
  function addYears(iso, n) { var x = new Date(day(iso) + 'T00:00:00Z'); x.setUTCFullYear(x.getUTCFullYear() + Math.round(n)); return x.toISOString().slice(0, 10); }
  function diffDays(a, b) { return Math.round((Date.parse(day(a) + 'T00:00:00Z') - Date.parse(day(b) + 'T00:00:00Z')) / 864e5); }
  function words(s) { return norm(s).split(/[\s,;]+/).filter(Boolean); }
  function matches(actor, c) { if (!actor || !c) return false; if (c.name && norm(actor.name) === norm(c.name)) return true; return !!(c.role && actor.role && norm(actor.role) === norm(c.role)); }
  /* « Marie » → {name} ; « fonction: Directeur général » → {role} */
  function parseTarget(s) { s = String(s || '').trim(); if (!s) return null; var m = /^(fonction|role|rôle)\s*:\s*(.+)$/i.exec(s); return m ? { role: m[2].trim() } : { name: s }; }
  function tlabel(c) { return (c && (c.name || (c.role ? 'fonction : ' + c.role : ''))) || '?'; }

  function validateMeta(m) {
    var E = []; m = m || {};
    if (!String(m.titre || '').trim()) E.push('Un titre est obligatoire.');
    if (!TYPES[m.type]) E.push('Type de document inconnu.');
    if (m.service && !SERVICES[m.service]) E.push('Service inconnu.');
    if (!String(m.projet || '').trim() && !String(m.client || '').trim() && !m.service) E.push('Classez le document : projet, client ou service.');
    if (m.conservationAns != null && m.conservationAns !== '' && !(num(m.conservationAns) >= 0 && num(m.conservationAns) <= 99)) E.push('Conservation : entre 0 et 99 ans (vide = non définie).');
    return { ok: !E.length, errors: E };
  }
  function validateFile(f) {
    var E = []; f = f || {};
    if (!String(f.nom || '').trim()) E.push('Nom de fichier manquant.');
    if (!(num(f.taille) > 0)) E.push('Le fichier est vide.');
    if (num(f.taille) > MAX) E.push('Fichier trop volumineux (' + (f.taille / 1048576).toFixed(1) + ' Mo ; maximum ' + (MAX / 1048576) + ' Mo).');
    return { ok: !E.length, errors: E };
  }
  function nextNo(list, year) {
    var re = new RegExp('^ARC-' + year + '-(\\d+)$'), n = 0;
    (list || []).forEach(function (x) { var m = re.exec(x.no || ''); if (m) n = Math.max(n, +m[1]); });
    return 'ARC-' + year + '-' + ('000' + (n + 1)).slice(-4);
  }
  function histo(doc, a, par, le, det) { doc.historique.push({ a: a, par: par && (par.name || par.role) || '?', verifie: !!(par && par.verified), le: le, det: det || '' }); }

  /* Création d'une fiche + version 1. file = {nom, mime, taille, sha}. */
  function create(meta, file, actor, now, no, id) {
    var v = validateMeta(meta); if (!v.ok) return { ok: false, errors: v.errors, error: v.errors[0] };
    var f = validateFile(file); if (!f.ok) return { ok: false, errors: f.errors, error: f.errors[0] };
    var doc = {
      id: id, no: no, titre: String(meta.titre).trim().slice(0, 160), type: meta.type, projet: String(meta.projet || '').trim(), client: String(meta.client || '').trim(),
      service: meta.service || '', motsCles: words(meta.motsCles).filter(function (x, i, a) { return a.indexOf(x) === i; }).slice(0, 20), description: String(meta.description || '').slice(0, 500),
      statut: 'actif', proprietaire: { name: actor.name || '', role: actor.role || '', verified: !!actor.verified }, acces: meta.acces === 'restreint' ? 'restreint' : 'tous',
      telechargement: meta.telechargement === 'non' ? 'non' : 'oui', partages: [], source: meta.source || null,
      conservationAns: meta.conservationAns === '' || meta.conservationAns == null ? null : Math.round(num(meta.conservationAns)),
      cree: now, versions: [], historique: []
    };
    doc.versions.push({ n: 1, nom: file.nom, mime: file.mime || '', taille: num(file.taille), sha: file.sha || '', par: actor.name || actor.role || '?', le: now, note: String(meta.note || '').slice(0, 200) });
    histo(doc, 'depot', actor, now, file.nom + ' (v1)');
    return { ok: true, doc: doc };
  }
  function current(doc) { return doc.versions[doc.versions.length - 1]; }
  function isOwner(doc, actor) { return !!(actor && doc.proprietaire && ((doc.proprietaire.name && norm(actor.name) === norm(doc.proprietaire.name)) || (!doc.proprietaire.name && doc.proprietaire.role && norm(actor.role) === norm(doc.proprietaire.role)))); }
  function shareFor(doc, actor, now) {
    return (doc.partages || []).filter(function (p) { return matches(actor, p.cible) && (!p.jusqu || day(now) <= day(p.jusqu)); })[0] || null;
  }
  /* droits : { voir, telecharger, modifier } — administrateur et propriétaire : tout ; sinon partage actif ; sinon « accès tous » (lecture seule) */
  function rights(doc, actor, admin, now) {
    if (admin || isOwner(doc, actor)) return { voir: true, telecharger: true, modifier: true, gerer: true };
    var p = shareFor(doc, actor, now);
    if (p) return { voir: true, telecharger: !!p.telechargement, modifier: false, gerer: false };
    if (doc.acces === 'tous') return { voir: true, telecharger: doc.telechargement === 'oui', modifier: false, gerer: false };
    return { voir: false, telecharger: false, modifier: false, gerer: false };
  }
  function addVersion(doc, file, actor, now, note) {
    var f = validateFile(file); if (!f.ok) return { ok: false, error: f.errors[0] };
    var dd = clone(doc), n = current(dd).n + 1;
    dd.versions.push({ n: n, nom: file.nom, mime: file.mime || '', taille: num(file.taille), sha: file.sha || '', par: actor.name || actor.role || '?', le: now, note: String(note || '').slice(0, 200) });
    if (dd.statut === 'archive') return { ok: false, error: 'Document archivé : désarchivez-le avant d\'ajouter une version.' };
    histo(dd, 'version', actor, now, 'v' + n + ' · ' + file.nom + (note ? ' · ' + note : '')); return { ok: true, doc: dd, version: n };
  }
  /* Restaurer = nouvelle version qui réutilise le contenu d'une ancienne (l'historique n'est jamais réécrit) */
  function restore(doc, n, actor, now) {
    if (doc.statut === 'archive') return { ok: false, error: 'Document archivé : désarchivez-le d\'abord.' };
    var src = doc.versions.filter(function (v) { return v.n === n; })[0]; if (!src) return { ok: false, error: 'Version introuvable.' };
    if (src.n === current(doc).n) return { ok: false, error: 'C\'est déjà la version courante.' };
    var dd = clone(doc), k = current(dd).n + 1;
    dd.versions.push({ n: k, nom: src.nom, mime: src.mime, taille: src.taille, sha: src.sha, par: actor.name || actor.role || '?', le: now, note: 'Restaurée depuis v' + src.n, depuis: src.n });
    histo(dd, 'restaure', actor, now, 'v' + src.n + ' → v' + k); return { ok: true, doc: dd, version: k, depuis: src.n };
  }
  function retentionEnd(doc) { return doc.conservationAns == null ? null : addYears(doc.cree, doc.conservationAns); }
  function retentionState(doc, now) {
    var e = retentionEnd(doc); if (!e) return { etat: 'non_definie', fin: null, jours: null };
    var j = diffDays(e, now); return { etat: j < 0 ? 'echue' : j <= 90 ? 'proche' : 'en_cours', fin: e, jours: j };
  }
  function archive(doc, actor, now, motif) {
    if (doc.statut === 'archive') return { ok: false, error: 'Déjà archivé.' };
    var dd = clone(doc); dd.statut = 'archive'; dd.archiveLe = now; histo(dd, 'archive', actor, now, String(motif || '').slice(0, 160)); return { ok: true, doc: dd };
  }
  function unarchive(doc, actor, now, motif) {
    if (doc.statut !== 'archive') return { ok: false, error: 'Ce document n\'est pas archivé.' };
    if (!String(motif || '').trim()) return { ok: false, error: 'Un motif est obligatoire pour désarchiver.' };
    var dd = clone(doc); dd.statut = 'actif'; delete dd.archiveLe; histo(dd, 'desarchive', actor, now, String(motif).slice(0, 160)); return { ok: true, doc: dd };
  }
  function share(doc, cible, telecharger, jusqu, actor, now) {
    if (!cible || !(cible.name || cible.role)) return { ok: false, error: 'Indiquez une personne ou « fonction: … ».' };
    if (jusqu && day(jusqu) < day(now)) return { ok: false, error: 'La date de fin est dans le passé.' };
    var dd = clone(doc); dd.partages = dd.partages.filter(function (p) { return tlabel(p.cible) !== tlabel(cible); });
    dd.partages.push({ cible: cible, telechargement: !!telecharger, jusqu: jusqu ? day(jusqu) : '', par: actor.name || actor.role || '?', le: now });
    histo(dd, 'partage', actor, now, tlabel(cible) + (telecharger ? ' · téléchargement' : ' · lecture') + (jusqu ? ' · jusqu\'au ' + day(jusqu) : '')); return { ok: true, doc: dd };
  }
  function unshare(doc, label, actor, now) {
    var dd = clone(doc), n = dd.partages.length; dd.partages = dd.partages.filter(function (p) { return tlabel(p.cible) !== label; });
    if (dd.partages.length === n) return { ok: false, error: 'Partage introuvable.' };
    histo(dd, 'partage.retrait', actor, now, label); return { ok: true, doc: dd };
  }
  function setAccess(doc, acces, telechargement, actor, now) {
    var dd = clone(doc); dd.acces = acces === 'restreint' ? 'restreint' : 'tous'; dd.telechargement = telechargement === 'non' ? 'non' : 'oui';
    histo(dd, 'droits', actor, now, 'accès ' + dd.acces + ' · téléchargement ' + dd.telechargement); return { ok: true, doc: dd };
  }
  /* Modification des métadonnées : champs modifiables listés ; raccourcir la conservation = administrateur seul (protège les échéances) */
  var EDITABLE = ['titre', 'type', 'projet', 'client', 'service', 'motsCles', 'description', 'conservationAns'];
  function editMeta(doc, ch, actor, now, admin) {
    if (doc.statut === 'archive') return { ok: false, error: 'Document archivé : désarchivez-le avant de modifier ses informations.' };
    var m = { titre: doc.titre, type: doc.type, projet: doc.projet, client: doc.client, service: doc.service, motsCles: (doc.motsCles || []).join(' '), description: doc.description, conservationAns: doc.conservationAns };
    var dd = clone(doc), chg = [];
    EDITABLE.forEach(function (k) { if (ch && Object.prototype.hasOwnProperty.call(ch, k)) m[k] = ch[k]; });
    var v = validateMeta(m); if (!v.ok) return { ok: false, error: v.errors[0], errors: v.errors };
    var nt = String(m.titre).trim().slice(0, 160), nk = words(m.motsCles).filter(function (x, i, a) { return a.indexOf(x) === i; }).slice(0, 20),
        nc = m.conservationAns === '' || m.conservationAns == null ? null : Math.round(num(m.conservationAns)), nd = String(m.description || '').slice(0, 500);
    if (dd.conservationAns != null && (nc == null || nc < dd.conservationAns) && !admin) return { ok: false, error: 'Réduire ou retirer la durée de conservation est réservé à un administrateur.' };
    function set(k, val, lab) { if (JSON.stringify(dd[k]) !== JSON.stringify(val)) { dd[k] = val; chg.push(lab || k); } }
    set('titre', nt); set('type', m.type); set('projet', String(m.projet || '').trim()); set('client', String(m.client || '').trim()); set('service', m.service || ''); set('motsCles', nk, 'mots-clés'); set('description', nd); set('conservationAns', nc, 'conservation');
    if (!chg.length) return { ok: false, error: 'Aucune modification.' };
    histo(dd, 'modif', actor, now, chg.join(', ')); return { ok: true, doc: dd, champs: chg };
  }
  /* Type et service probables d'après le nom d'un fichier (dépôt automatique des PDF générés) */
  function guess(nom) {
    var n = norm(nom), R = [['facture', 'facture', 'finance'], ['devis', 'devis', 'commercial'], ['certificat', 'certificat', 'formation'], ['attestation', 'certificat', 'formation'], ['plan', 'plan', 'etudes'], ['note', 'note', 'etudes'], ['calcul', 'note', 'etudes'], ['contrat', 'contrat', 'commercial'], ['recu', 'facture', 'finance'], ['rapport', 'rapport', 'chantier'], ['pv', 'pv', 'chantier'], ['reception', 'pv', 'chantier']];
    for (var i = 0; i < R.length; i++) if (n.indexOf(R[i][0]) >= 0) return { type: R[i][1], service: R[i][2] };
    return { type: 'autre', service: 'technique' };
  }
  /* Suppression : motif obligatoire ; conservation non échue → administrateur seul ; sinon propriétaire ou administrateur */
  function canDelete(doc, actor, admin, now, motif) {
    if (!String(motif || '').trim()) return { ok: false, error: 'Un motif est obligatoire pour supprimer.' };
    var r = retentionState(doc, now);
    if (r.etat !== 'echue' && r.etat !== 'non_definie' && !admin) return { ok: false, error: 'Conservation en cours jusqu\'au ' + r.fin + ' : seul un administrateur peut supprimer.' };
    if (!admin && !isOwner(doc, actor)) return { ok: false, error: 'Seuls le propriétaire ou un administrateur peuvent supprimer.' };
    return { ok: true, forcee: (r.etat === 'en_cours' || r.etat === 'proche') };
  }
  /* Recherche : tous les mots doivent se retrouver (accents et casse ignorés) ; filtres exacts ; période sur la date de dépôt */
  function search(docs, q, f, actor, admin, now) {
    f = f || {}; var ws = words(q);
    return (docs || []).filter(function (x) {
      if (!rights(x, actor, admin, now).voir) return false;
      if (f.statut && x.statut !== f.statut) return false;
      if (f.type && x.type !== f.type) return false;
      if (f.service && x.service !== f.service) return false;
      if (f.projet && norm(x.projet) !== norm(f.projet)) return false;
      if (f.client && norm(x.client) !== norm(f.client)) return false;
      if (f.du && day(x.cree) < day(f.du)) return false;
      if (f.au && day(x.cree) > day(f.au)) return false;
      if (!ws.length) return true;
      var hay = norm([x.no, x.titre, x.projet, x.client, TYPES[x.type], SERVICES[x.service], x.description, (x.motsCles || []).join(' '), x.versions.map(function (v) { return v.nom; }).join(' ')].join(' '));
      return ws.every(function (t) { return hay.indexOf(t) >= 0; });
    }).sort(function (a, b) { return a.cree < b.cree ? 1 : -1; });
  }
  function groupBy(docs, key) {
    var g = {}; docs.forEach(function (x) { var k = (key === 'periode' ? day(x.cree).slice(0, 7) : x[key]) || '(non classé)'; (g[k] = g[k] || []).push(x); }); return g;
  }
  function stats(docs, now) {
    var s = { total: docs.length, actifs: 0, archives: 0, echues: 0, proches: 0, taille: 0 };
    docs.forEach(function (x) { if (x.statut === 'archive') s.archives++; else s.actifs++; var r = retentionState(x, now); if (r.etat === 'echue') s.echues++; if (r.etat === 'proche') s.proches++; x.versions.forEach(function (v) { s.taille += num(v.taille); }); });
    return s;
  }
  var ENGINE = { TYPES: TYPES, SERVICES: SERVICES, STAT: STAT, MAX: MAX, validateMeta: validateMeta, validateFile: validateFile, create: create, current: current, rights: rights, addVersion: addVersion, restore: restore, retentionEnd: retentionEnd, retentionState: retentionState, archive: archive, unarchive: unarchive, share: share, unshare: unshare, setAccess: setAccess, editMeta: editMeta, guess: guess, canDelete: canDelete, search: search, groupBy: groupBy, stats: stats, nextNo: nextNo, parseTarget: parseTarget, tlabel: tlabel, norm: norm, words: words };
  if (typeof module !== 'undefined' && module.exports) module.exports = { engine: ENGINE };

  /* ============================ STOCKAGE ============================ */
  function G(k) { try { if (w.EXBS && w.EXBS.get) { var a = w.EXBS.get(k); if (Array.isArray(a)) return a; } } catch (e) {} try { var v = JSON.parse((w.exbStorage || w.localStorage).getItem(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function put(k, a) {
    try { if (w.EXBS && w.EXBS.set) { w.EXBS.set(k, a); return true; } } catch (e) {}
    try { (w.exbStorage || w.localStorage).setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; }
  }
  function rawGet(k) { try { return (w.exbStorage || w.localStorage).getItem(k); } catch (e) { return null; } }
  function rawSet(k, v) { try { (w.exbStorage || w.localStorage).setItem(k, v); return true; } catch (e) { return false; } }
  function rawDel(k) { try { (w.exbStorage || w.localStorage).removeItem(k); } catch (e) {} }
  function nowIso() { return new Date().toISOString(); }
  function info() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || { on: false }; } catch (e) { return { on: false }; } }
  function me() { var i = info(); return { name: i.on ? (i.label || '') : '', role: i.on ? (i.fonction && i.fonction !== 'polyvalent' ? i.fonction : i.role || '') : '', verified: !!i.on, on: !!i.on }; }
  function isAdmin() { var i = info(); return !i.on || i.role === 'admin'; }
  function actor() { var m = me(); return (m.name || m.role) ? m : { name: 'Utilisateur local', role: '', verified: false }; }
  function audit(a, obj, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, obj, det); } catch (e) {} }
  function emit(n, p) { try { if (w.EXBCore && w.EXBCore.bus) w.EXBCore.bus.emit(n, p, 'archives'); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'info', 5000); } catch (e) {} }
  function uid() { return 'ar_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function saveDoc(nd) { var L = G(DK), i = L.findIndex(function (x) { return x.id === nd.id; }); if (i >= 0) L[i] = nd; else L.push(nd); return put(DK, L); }
  function find(id) { return G(DK).filter(function (x) { return x.id === id; })[0]; }
  function fileKey(id, n) { return FK + id + '_' + n; }
  /* La version restaurée réutilise le contenu de la version d'origine (depuis) : on remonte jusqu'au contenu réel */
  function contentKey(doc, n) { var v = doc.versions.filter(function (x) { return x.n === n; })[0]; while (v && v.depuis) { var s = doc.versions.filter(function (x) { return x.n === v.depuis; })[0]; if (!s) break; v = s; } return v ? fileKey(doc.id, v.n) : null; }
  function readFile(file) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = function () { rej(new Error('Lecture impossible.')); }; r.readAsDataURL(file); }); }
  async function sha256(file) {
    try { if (!w.crypto || !w.crypto.subtle) return ''; var b = await file.arrayBuffer(), h = new Uint8Array(await w.crypto.subtle.digest('SHA-256', b)); return Array.prototype.map.call(h, function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); } catch (e) { return ''; }
  }
  function dataToBlob(u) { var m = /^data:([^;,]*)(;base64)?,(.*)$/.exec(u || ''); if (!m) return null; var bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]), a = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: m[1] || 'application/octet-stream' }); }

  /* ---- API publique : dépôt et nouvelle version (utilisée par l'écran et par les autres modules) ---- */
  async function add(o) {
    o = o || {}; var f = o.fichier; if (!f) return { ok: false, error: 'Aucun fichier.' };
    var isF = typeof f === 'object' && typeof f.size === 'number';
    var file = { nom: o.nom || (isF && f.name) || '', mime: o.mime || (isF && f.type) || '', taille: isF ? f.size : (o.taille || 0), sha: '' };
    if (!isF && typeof f === 'string') { var bl = dataToBlob(f); if (!bl) return { ok: false, error: 'Contenu non reconnu (attendu : fichier ou « data: »).' }; file.taille = bl.size; file.mime = file.mime || bl.type; f = bl; isF = true; }
    var vf = validateFile(file); if (!vf.ok) return { ok: false, error: vf.errors[0], errors: vf.errors };
    var a = actor(), now = nowIso(), r = create(o, file, a, now, nextNo(G(DK), now.slice(0, 4)), uid());
    if (!r.ok) return r;
    file.sha = await sha256(f); r.doc.versions[0].sha = file.sha;
    var url = await readFile(f);
    if (!rawSet(fileKey(r.doc.id, 1), url)) return { ok: false, error: 'Stockage plein : le fichier n\'a pas pu être enregistré.' };
    if (!saveDoc(r.doc)) { rawDel(fileKey(r.doc.id, 1)); return { ok: false, error: 'Enregistrement impossible (stockage plein ?).' }; }
    audit('archives.depose', r.doc.no, { titre: r.doc.titre.slice(0, 60), type: r.doc.type, sha: (file.sha || '').slice(0, 12) });
    emit('archives.depose', { id: r.doc.id, no: r.doc.no, type: r.doc.type, projet: r.doc.projet, source: r.doc.source }); return r;
  }
  async function newVersion(id, f, note) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Document introuvable.' };
    if (!rights(dd, actor(), isAdmin(), nowIso()).modifier) return { ok: false, error: 'Droit insuffisant pour ajouter une version.' };
    var file = { nom: f.name, mime: f.type, taille: f.size, sha: '' }, r = addVersion(dd, file, actor(), nowIso(), note); if (!r.ok) return r;
    file.sha = await sha256(f); r.doc.versions[r.version - 1].sha = file.sha;
    var url = await readFile(f); if (!rawSet(fileKey(id, r.version), url)) return { ok: false, error: 'Stockage plein.' };
    if (!saveDoc(r.doc)) { rawDel(fileKey(id, r.version)); return { ok: false, error: 'Enregistrement impossible.' }; }
    audit('archives.version', r.doc.no, { v: r.version, sha: (file.sha || '').slice(0, 12) }); emit('archives.version', { id: id, no: r.doc.no, v: r.version }); return r;
  }
  function mutate(id, fn, ev, det) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Document introuvable.' };
    if (!rights(dd, actor(), isAdmin(), nowIso()).gerer) return { ok: false, error: 'Droit insuffisant (propriétaire ou administrateur).' };
    var r = fn(dd, actor(), nowIso()); if (!r.ok) return r; if (!saveDoc(r.doc)) return { ok: false, error: 'Enregistrement impossible.' };
    audit('archives.' + ev, r.doc.no, det || {}); emit('archives.' + ev, { id: id, no: r.doc.no, statut: r.doc.statut }); return r;
  }
  function restoreD(id, n) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Document introuvable.' };
    if (!rights(dd, actor(), isAdmin(), nowIso()).modifier) return { ok: false, error: 'Droit insuffisant.' };
    var r = restore(dd, n, actor(), nowIso()); if (!r.ok) return r; if (!saveDoc(r.doc)) return { ok: false, error: 'Enregistrement impossible.' };
    audit('archives.restaure', r.doc.no, { de: n, vers: r.version }); emit('archives.restaure', { id: id, no: r.doc.no, v: r.version }); return r;
  }
  function editD(id, ch) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Document introuvable.' };
    if (!rights(dd, actor(), isAdmin(), nowIso()).modifier) return { ok: false, error: 'Droit insuffisant pour modifier ce document.' };
    var r = editMeta(dd, ch, actor(), nowIso(), isAdmin()); if (!r.ok) return r; if (!saveDoc(r.doc)) return { ok: false, error: 'Enregistrement impossible.' };
    audit('archives.modifie', r.doc.no, { champs: r.champs.join(',') }); emit('archives.modifie', { id: id, no: r.doc.no }); return r;
  }
  /* Réglages (locaux à l'appareil, clé exb_ar_cfg) : auto = déposer les PDF générés ; wf = dossier Workflow validé requis pour une suppression pendant la conservation */
  function cfg() { try { return Object.assign({ auto: false, wf: false }, JSON.parse(rawGet('exb_ar_cfg') || '{}')); } catch (e) { return { auto: false, wf: false }; } }
  function setCfg(c) { rawSet('exb_ar_cfg', JSON.stringify({ auto: !!c.auto, wf: !!c.wf })); audit('archives.reglages', 'exb_ar_cfg', { auto: !!c.auto, wf: !!c.wf }); }
  function wfOk(id) { return !!(w.EXBWF && w.EXBWF.list && w.EXBWF.list().some(function (x) { return x.status === 'valide' && x.ref && x.ref.module === 'archives' && x.ref.id === id; })); }
  function removeD(id, motif) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Document introuvable.' };
    var a = actor(), c = canDelete(dd, a, isAdmin(), nowIso(), motif); if (!c.ok) return c;
    if (c.forcee && cfg().wf) {
      if (!w.EXBWF) return { ok: false, error: 'Réglage actif mais module Workflow absent.' };
      if (!wfOk(id)) { var op = w.EXBWF.list().filter(function (x) { return x.ref && x.ref.module === 'archives' && x.ref.id === id && (x.status === 'en_cours' || x.status === 'retourne'); })[0]; if (op) return { ok: false, error: 'Dossier Workflow ' + op.no + ' déjà ouvert (' + (op.status === 'retourne' ? 'à corriger' : 'en attente') + ') : la suppression sera possible une fois validé.' }; var sr = w.EXBWF.submit({ type: 'document', titre: 'Suppression anticipée : ' + dd.titre, description: String(motif).slice(0, 200), ref: { module: 'archives', id: id } }); return { ok: false, error: sr.ok ? 'Dossier Workflow ' + sr.dossier.no + ' ouvert : la suppression sera possible une fois validé.' : 'Workflow : ' + sr.error }; }
    }
    dd.versions.forEach(function (v) { if (!v.depuis) rawDel(fileKey(id, v.n)); });
    put(DK, G(DK).filter(function (x) { return x.id !== id; }));
    var X = G(XK); X.push({ no: dd.no, titre: dd.titre, motif: String(motif).slice(0, 160), par: a.name || a.role, le: nowIso(), forcee: !!c.forcee, sha: current(dd).sha }); put(XK, X.slice(-500));
    audit('archives.supprime', dd.no, { motif: String(motif).slice(0, 80), forcee: !!c.forcee }); emit('archives.supprime', { id: id, no: dd.no }); return { ok: true, forcee: !!c.forcee };
  }
  function fetchContent(id, n, usage) {
    var dd = find(id); if (!dd) return { ok: false, error: 'Document introuvable.' };
    var rt = rights(dd, actor(), isAdmin(), nowIso());
    if (usage === 'telecharger' ? !rt.telecharger : !rt.voir) return { ok: false, error: usage === 'telecharger' ? 'Téléchargement non autorisé pour vous.' : 'Accès refusé.' };
    var k = contentKey(dd, n || current(dd).n), u = k && rawGet(k); if (!u) return { ok: false, error: 'Contenu introuvable sur cet appareil (synchronisation en attente ?).' };
    var v = dd.versions.filter(function (x) { return x.n === (n || current(dd).n); })[0];
    audit(usage === 'telecharger' ? 'archives.telecharge' : 'archives.consulte', dd.no, { v: v.n }); return { ok: true, url: u, version: v, doc: dd };
  }
  /* Dépôt automatique d'un PDF généré : ignoré si même empreinte déjà archivée ; même nom → nouvelle version ; sinon nouvelle fiche classée par service probable */
  async function autoArchive(blob, nom) {
    try {
      if (!blob || !blob.size || blob.size > MAX) return { ok: false, skipped: 'taille' };
      var h = await sha256(blob), L = G(DK);
      if (h && L.some(function (x) { return x.versions.some(function (v) { return v.sha === h; }); })) return { ok: true, skipped: 'identique' };
      var ex = L.filter(function (x) { return x.statut === 'actif' && current(x).nom === nom && x.source && x.source.module === 'auto'; })[0];
      if (ex) { var f = new File([blob], nom, { type: blob.type || 'application/pdf' }); return await newVersion(ex.id, f, 'Régénéré automatiquement'); }
      var g = guess(nom); return await add({ fichier: blob, nom: nom, mime: blob.type || 'application/pdf', titre: String(nom).replace(/\.[^.]+$/, ''), type: g.type, service: g.service, source: { module: 'auto', id: nom } });
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }
  function hook() {
    var P_ = w.EXBPdf; if (!P_ || typeof P_.save !== 'function' || P_.__arHook) return !!(P_ && P_.__arHook);
    var o = P_.save; P_.__arHook = 1;
    P_.save = function (blob, name) { var r = o.apply(this, arguments); try { if (cfg().auto && blob && blob.size) autoArchive(blob, name || 'document.pdf'); } catch (e) {} return r; };
    return true;
  }
  var hk = 0; (function tryHook() { if (hook() || ++hk > 40) return; setTimeout(tryHook, 1500); })();
  w.EXBAR = { version: 2, edit: editD, remove: removeD, config: cfg, setConfig: setCfg, autoArchive: autoArchive, engine: ENGINE, add: add, find: find, list: function () { return G(DK).filter(function (x) { return rights(x, actor(), isAdmin(), nowIso()).voir; }); }, stats: function () { return stats(G(DK), nowIso()); }, newVersion: newVersion, fetch: fetchContent };
  if (!d) return;

  /* ============================ ÉCRAN ============================ */
  var $ = function (i) { return d.getElementById(i); };
  var P = { tab: 'biblio', q: '', f: {} }; try { var sv = JSON.parse(w.localStorage.getItem(PK) || '{}'); if (sv.tab) P.tab = sv.tab; } catch (e) {} function sp() { try { w.localStorage.setItem(PK, JSON.stringify({ tab: P.tab })); } catch (e) {} }
  function fr(s) { return s ? String(s).slice(0, 10).split('-').reverse().join('/') : '—'; }
  function size(n) { n = num(n); return n >= 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function each(root, sel, fn) { Array.prototype.forEach.call(root.querySelectorAll(sel), fn); }
  function modal(html) { closeM(); var el = d.createElement('div'); el.id = 'ar_md'; el.style.cssText = 'position:fixed;inset:0;background:rgba(10,20,40,.55);z-index:100000;display:flex;align-items:center;justify-content:center;padding:12px'; el.innerHTML = '<div style="background:#fff;color:#111;border-radius:12px;max-width:760px;width:100%;max-height:92vh;overflow:auto;padding:16px">' + html + '</div>'; d.body.appendChild(el); return el; }
  function closeM() { var o = $('ar_md'); if (o) o.remove(); }
  var RET = { non_definie: ['Non définie', '#6b7280'], en_cours: ['En cours', '#15803d'], proche: ['Échéance proche', '#d97706'], echue: ['Échue', '#b91c1c'] };
  function opts(map, sel, blank) { return (blank ? '<option value="">' + blank + '</option>' : '') + Object.keys(map).map(function (k) { return '<option value="' + k + '"' + (sel === k ? ' selected' : '') + '>' + esc(map[k]) + '</option>'; }).join(''); }
  function distinct(key) { var s = {}; G(DK).forEach(function (x) { if (x[key]) s[x[key]] = 1; }); return Object.keys(s).sort(); }
  function suggestions() {
    var p = {}, c = {}; (w.exbProjects || []).forEach(function (x) { var n = x.name || x.title || x.nom; if (n) p[n] = 1; }); (w.exbClients || []).forEach(function (x) { var n = x.full_name || x.company; if (n) c[n] = 1; });
    distinct('projet').forEach(function (n) { p[n] = 1; }); distinct('client').forEach(function (n) { c[n] = 1; });
    return '<datalist id="ar_pl">' + Object.keys(p).map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist><datalist id="ar_cl">' + Object.keys(c).map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist>';
  }
  function row(x) {
    var v = current(x), r = retentionState(x, nowIso()), b = RET[r.etat];
    return '<div class="ar-row" data-id="' + esc(x.id) + '" style="border:1px solid #d9dee8;border-radius:10px;padding:8px 10px;margin:6px 0;cursor:pointer;background:#fff"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>' + esc(x.titre) + '</b><span style="font-size:12px;color:#555">' + esc(x.no) + ' · v' + v.n + (x.statut === 'archive' ? ' · 🗄 archivé' : '') + '</span></div><div style="font-size:12px;color:#555">' +
      esc(TYPES[x.type] || x.type) + (x.projet ? ' · 📐 ' + esc(x.projet) : '') + (x.client ? ' · 👤 ' + esc(x.client) : '') + (x.service ? ' · ' + esc(SERVICES[x.service]) : '') + ' · ' + fr(x.cree) + ' · ' + size(v.taille) + (r.etat !== 'non_definie' ? ' · <span style="color:' + b[1] + '">⏳ ' + b[0] + ' (' + fr(r.fin) + ')</span>' : '') + '</div>' +
      (x.motsCles.length ? '<div style="font-size:11px;color:#777">#' + x.motsCles.map(esc).join(' #') + '</div>' : '') + '</div>';
  }
  function filtersBar() {
    var F = P.f;
    return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:6px;margin-bottom:8px"><input id="ar_q" type="search" placeholder="🔎 Rechercher (titre, projet, mot-clé, fichier…)" value="' + esc(P.q) + '" style="grid-column:1/-1">' +
      '<select id="ar_ft">' + opts(TYPES, F.type, 'Tous les types') + '</select><select id="ar_fs">' + opts(SERVICES, F.service, 'Tous les services') + '</select>' +
      '<select id="ar_fp"><option value="">Tous les projets</option>' + distinct('projet').map(function (n) { return '<option' + (F.projet === n ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join('') + '</select>' +
      '<select id="ar_fc"><option value="">Tous les clients</option>' + distinct('client').map(function (n) { return '<option' + (F.client === n ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join('') + '</select>' +
      '<select id="ar_fa">' + opts(STAT, F.statut, 'Actifs + archivés') + '</select><label style="font-size:12px">Du <input id="ar_fd" type="date" value="' + esc(F.du || '') + '"></label><label style="font-size:12px">Au <input id="ar_fe" type="date" value="' + esc(F.au || '') + '"></label></div>';
  }
  function visible() { return search(G(DK), P.q, P.f, actor(), isAdmin(), nowIso()); }
  function renderBiblio() {
    var L = visible(), s = stats(G(DK), nowIso());
    return suggestions() + '<div style="display:flex;gap:10px;flex-wrap:wrap;font-size:13px;margin-bottom:8px"><span>📄 ' + s.total + ' document(s)</span><span>🟢 ' + s.actifs + ' actifs</span><span>🗄 ' + s.archives + ' archivés</span><span>💾 ' + size(s.taille) + '</span>' + (s.echues ? '<span style="color:#b91c1c">⏳ ' + s.echues + ' conservation(s) échue(s)</span>' : '') + (s.proches ? '<span style="color:#d97706">⚠ ' + s.proches + ' échéance(s) sous 90 j</span>' : '') + '</div>' +
      '<button type="button" id="ar_new" class="btn">➕ Déposer un document</button> <button type="button" id="ar_lot">📦 Déposer plusieurs</button>' + '<div style="margin-top:8px">' + filtersBar() + '</div><div id="ar_list">' + listHtml(L) + '</div>';
  }
  function listHtml(L) { return L.length ? '<div style="font-size:12px;color:#555">' + L.length + ' résultat(s)</div>' + L.slice(0, 150).map(row).join('') + (L.length > 150 ? '<div style="font-size:12px;color:#555">… affinez la recherche (150 premiers affichés).</div>' : '') : '<p class="exb-muted">Aucun document. Déposez-en un ou modifiez les filtres.</p>'; }
  function renderClass() {
    var key = P.by || 'projet', L = visible(), g = groupBy(L, key);
    var h = '<div style="margin-bottom:8px">Classer par : ' + [['projet', 'Projet'], ['client', 'Client'], ['service', 'Service'], ['type', 'Type'], ['periode', 'Période']].map(function (k) { return '<button type="button" class="ar-by" data-k="' + k[0] + '" style="' + (key === k[0] ? 'font-weight:700;border-bottom:3px solid #c9a24b' : '') + '">' + k[1] + '</button>'; }).join(' ') + '</div>';
    var ks = Object.keys(g).sort(); if (!ks.length) return h + '<p class="exb-muted">Aucun document.</p>';
    return h + ks.map(function (k) { var label = key === 'type' ? TYPES[k] || k : key === 'service' ? SERVICES[k] || k : k; return '<details style="margin:6px 0"' + (ks.length < 6 ? ' open' : '') + '><summary><b>📁 ' + esc(label) + '</b> <span style="color:#555">(' + g[k].length + ')</span></summary>' + g[k].map(row).join('') + '</details>'; }).join('');
  }
  function renderCons() {
    var L = G(DK).filter(function (x) { return rights(x, actor(), isAdmin(), nowIso()).voir; }).map(function (x) { return { x: x, r: retentionState(x, nowIso()) }; }).filter(function (o) { return o.r.etat !== 'non_definie'; }).sort(function (a, b) { return a.r.jours - b.r.jours; });
    var X = G(XK).slice(-20).reverse();
    var C = cfg();
    return '<div style="border:1px solid #d9dee8;border-radius:10px;padding:8px 10px;margin-bottom:10px"><b>🔗 Liens avec les autres modules</b> <span style="font-size:12px;color:#555">(réglages de cet appareil, désactivés par défaut)</span>' +
      '<label style="display:block;margin-top:6px"><input type="checkbox" class="ar-cfg" data-k="auto"' + (C.auto ? ' checked' : '') + '> Archiver automatiquement les PDF générés par l\'application (devis, certificats, plans, notes, reçus…) — doublons ignorés, même nom = nouvelle version</label>' +
      '<label style="display:block;margin-top:4px"><input type="checkbox" class="ar-cfg" data-k="wf"' + (C.wf ? ' checked' : '') + '> Suppression pendant la conservation : exiger un dossier Workflow « Validé »' + (w.EXBWF ? '' : ' <i>(module Workflow absent)</i>') + '</label></div>' +
      '<p class="exb-muted">Conservation = date de dépôt + durée choisie. Aucune suppression automatique : une échéance échue signale seulement qu\'un propriétaire ou un administrateur peut supprimer (motif obligatoire). Pendant la conservation, seul un administrateur peut supprimer.</p>' +
      (L.length ? L.map(function (o) { return row(o.x); }).join('') : '<p class="exb-muted">Aucun document avec durée de conservation.</p>') +
      '<h4 style="margin:14px 0 4px">🗑 Dernières suppressions</h4>' + (X.length ? X.map(function (z) { return '<div style="font-size:12px;border-bottom:1px solid #eee;padding:3px 0">' + fr(z.le) + ' · <b>' + esc(z.no) + '</b> ' + esc(z.titre) + ' — ' + esc(z.motif) + ' (par ' + esc(z.par) + (z.forcee ? ', conservation non échue' : '') + ')</div>'; }).join('') : '<p class="exb-muted">Aucune.</p>');
  }
  function render() {
    var box = $('ar_box'); if (!box) return;
    var tabs = [['biblio', '📚 Bibliothèque'], ['classement', '🗂 Classement'], ['conservation', '⏳ Conservation']];
    var h = '<div class="exb-tabs">' + tabs.map(function (t) { return '<button type="button" class="ar-tab" data-t="' + t[0] + '" style="' + (P.tab === t[0] ? 'font-weight:700;border-bottom:3px solid #c9a24b' : '') + '">' + t[1] + '</button>'; }).join('') + '</div><div id="ar_pane">' + (P.tab === 'classement' ? renderClass() : P.tab === 'conservation' ? renderCons() : renderBiblio()) + '</div>';
    box.innerHTML = h; bind(box);
  }
  function refreshList() { var e = $('ar_list'); if (e) { e.innerHTML = listHtml(visible()); bindRows(e); } }
  function bindRows(root) { each(root, '.ar-row', function (r) { r.onclick = function () { openDoc(r.getAttribute('data-id')); }; }); }
  function bind(box) {
    each(box, '.ar-tab', function (b) { b.onclick = function () { P.tab = b.getAttribute('data-t'); sp(); render(); }; });
    each(box, '.ar-by', function (b) { b.onclick = function () { P.by = b.getAttribute('data-k'); render(); }; });
    bindRows(box);
    if ($('ar_new')) $('ar_new').onclick = formDepot;
    if ($('ar_lot')) $('ar_lot').onclick = formLot;
    each(box, '.ar-cfg', function (c) { c.onchange = function () { var o = cfg(); o[c.getAttribute('data-k')] = c.checked; setCfg(o); say('Réglage enregistré.', 'success'); }; });
    var m = { ar_ft: 'type', ar_fs: 'service', ar_fp: 'projet', ar_fc: 'client', ar_fa: 'statut', ar_fd: 'du', ar_fe: 'au' };
    Object.keys(m).forEach(function (id) { if ($(id)) $(id).onchange = function () { P.f[m[id]] = this.value; refreshList(); }; });
    if ($('ar_q')) { var t; $('ar_q').oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { P.q = v; refreshList(); }, 250); }; }
  }
  function formDepot() {
    var el = modal('<h3 style="margin:0 0 8px">Déposer un document</h3><form id="ar_nf" style="display:grid;gap:8px">' + suggestions() +
      '<label>Fichier (max ' + (MAX / 1048576) + ' Mo) <input id="ar_file" type="file" required></label><label>Titre <input id="ar_t" required maxlength="160"></label>' +
      '<label>Type <select id="ar_ty">' + opts(TYPES, 'autre') + '</select></label><label>Projet <input id="ar_p" list="ar_pl"></label><label>Client <input id="ar_c" list="ar_cl"></label>' +
      '<label>Service <select id="ar_s">' + opts(SERVICES, '', '— aucun —') + '</select></label><label>Mots-clés (séparés par des virgules) <input id="ar_k"></label><label>Description <textarea id="ar_d" rows="2" maxlength="500"></textarea></label>' +
      '<label>Conservation (années, vide = non définie) <input id="ar_cv" type="number" min="0" max="99"></label><label>Accès <select id="ar_a"><option value="tous">Tous les utilisateurs (lecture)</option><option value="restreint">Restreint (propriétaire, administrateurs, partages)</option></select></label>' +
      '<label>Téléchargement <select id="ar_dl"><option value="oui">Autorisé</option><option value="non">Réservé au propriétaire, aux administrateurs et aux partages avec téléchargement</option></select></label>' +
      '<div id="ar_err" style="color:#b91c1c;font-size:13px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" id="ar_cx">Annuler</button><button type="submit" id="ar_ok" class="btn">Déposer</button></div></form>');
    $('ar_cx').onclick = closeM;
    $('ar_file').onchange = function () { var f = this.files[0]; if (f && !$('ar_t').value) $('ar_t').value = f.name.replace(/\.[^.]+$/, ''); };
    $('ar_nf').onsubmit = async function (e) {
      e.preventDefault(); var f = $('ar_file').files[0]; if (!f) return; $('ar_ok').disabled = true; $('ar_err').textContent = '';
      var r = await add({ fichier: f, titre: $('ar_t').value, type: $('ar_ty').value, projet: $('ar_p').value, client: $('ar_c').value, service: $('ar_s').value, motsCles: $('ar_k').value, description: $('ar_d').value, conservationAns: $('ar_cv').value, acces: $('ar_a').value, telechargement: $('ar_dl').value });
      if (!r.ok) { $('ar_err').textContent = r.error; $('ar_ok').disabled = false; return; } closeM(); say('Document déposé : ' + r.doc.no, 'success'); render();
    };
  }
  async function preview(id, n) {
    var r = fetchContent(id, n, 'voir'); if (!r.ok) return say(r.error, 'warn');
    var b = dataToBlob(r.url); if (!b) return say('Aperçu impossible.', 'warn'); var u = URL.createObjectURL(b), m = (r.version.mime || b.type || '').toLowerCase(), body;
    if (m.indexOf('image/') === 0) body = '<img src="' + u + '" style="max-width:100%">'; else if (m === 'application/pdf') body = '<iframe src="' + u + '" style="width:100%;height:70vh;border:0"></iframe>';
    else if (m.indexOf('text/') === 0 || m === 'application/json') { var t = await b.text(); body = '<pre style="white-space:pre-wrap;max-height:70vh;overflow:auto">' + esc(t.slice(0, 20000)) + '</pre>'; }
    else body = '<p>Aperçu indisponible pour ce format (' + esc(m || 'inconnu') + ').' + (rights(r.doc, actor(), isAdmin(), nowIso()).telecharger ? ' Utilisez « Télécharger ».' : '') + '</p>';
    var el = modal('<div style="display:flex;justify-content:space-between"><b>' + esc(r.doc.titre) + ' · v' + r.version.n + '</b><button type="button" id="ar_pc">✖</button></div>' + body); $('ar_pc').onclick = function () { el.remove(); URL.revokeObjectURL(u); };
  }
  function download(id, n) {
    var r = fetchContent(id, n, 'telecharger'); if (!r.ok) return say(r.error, 'warn'); var b = dataToBlob(r.url); if (!b) return say('Téléchargement impossible.', 'warn');
    var u = URL.createObjectURL(b), a = d.createElement('a'); a.href = u; a.download = r.version.nom; d.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 4000);
  }
  var HL = { depot: '📥 Dépôt', version: '🆕 Version', restaure: '↩ Restauration', archive: '🗄 Archivage', desarchive: '📂 Désarchivage', partage: '🤝 Partage', 'partage.retrait': '🚫 Partage retiré', droits: '🔐 Droits' };
  function openDoc(id) {
    var x = find(id); if (!x) return; var a = actor(), rt = rights(x, a, isAdmin(), nowIso()), v = current(x), r = retentionState(x, nowIso());
    var h = '<div style="display:flex;justify-content:space-between;gap:8px"><h3 style="margin:0">' + esc(x.titre) + '</h3><button type="button" id="ar_x">✖</button></div>' +
      '<div style="font-size:13px;color:#444;margin:4px 0">' + esc(x.no) + ' · ' + esc(TYPES[x.type]) + ' · ' + esc(STAT[x.statut]) + ' · propriétaire : ' + esc(x.proprietaire.name || x.proprietaire.role || '?') + (x.proprietaire.verified ? '' : ' <i>(identité non vérifiée)</i>') + '</div>' +
      '<div style="font-size:13px">' + (x.projet ? '📐 ' + esc(x.projet) + ' ' : '') + (x.client ? '👤 ' + esc(x.client) + ' ' : '') + (x.service ? '· ' + esc(SERVICES[x.service]) : '') + '<br>Déposé le ' + fr(x.cree) + ' · conservation : ' + (x.conservationAns == null ? 'non définie' : x.conservationAns + ' an(s), fin ' + fr(r.fin) + ' (' + RET[r.etat][0] + ')') + '<br>Accès : ' + (x.acces === 'tous' ? 'tous (lecture)' : 'restreint') + ' · téléchargement : ' + (x.telechargement === 'oui' ? 'autorisé' : 'restreint') + (x.source ? '<br>Source : ' + esc(x.source.module || '') + ' ' + esc(x.source.id || '') : '') + '</div>' +
      (x.description ? '<p style="font-size:13px">' + esc(x.description) + '</p>' : '') + (x.motsCles.length ? '<div style="font-size:12px;color:#777">#' + x.motsCles.map(esc).join(' #') + '</div>' : '') +
      '<div style="margin:10px 0;display:flex;gap:6px;flex-wrap:wrap"><button type="button" id="ar_pv">👁 Aperçu</button>' + (rt.telecharger ? '<button type="button" id="ar_dl">⬇ Télécharger</button>' : '') + (rt.modifier && x.statut === 'actif' ? '<button type="button" id="ar_nv">🆕 Nouvelle version</button><button type="button" id="ar_ed">✏ Modifier</button>' : '') + (rt.gerer ? (x.statut === 'actif' ? '<button type="button" id="ar_ar">🗄 Archiver</button>' : '<button type="button" id="ar_ua">📂 Désarchiver</button>') + '<button type="button" id="ar_dr">🔐 Droits et partages</button><button type="button" id="ar_rm" style="color:#b91c1c">🗑 Supprimer</button>' : '') + '</div>' +
      '<h4 style="margin:10px 0 4px">Versions</h4>' + x.versions.slice().reverse().map(function (vv) { return '<div style="font-size:12px;border-bottom:1px solid #eee;padding:3px 0">v' + vv.n + (vv.n === v.n ? ' (courante)' : '') + ' · ' + esc(vv.nom) + ' · ' + size(vv.taille) + ' · ' + fr(vv.le) + ' · ' + esc(vv.par) + (vv.note ? ' · ' + esc(vv.note) : '') + (vv.sha ? ' · <span title="SHA-256 ' + vv.sha + '">🔒 ' + vv.sha.slice(0, 10) + '…</span>' : '') + ' <a href="#" class="ar-vp" data-n="' + vv.n + '">aperçu</a>' + (rt.telecharger ? ' <a href="#" class="ar-vd" data-n="' + vv.n + '">télécharger</a>' : '') + (rt.modifier && x.statut === 'actif' && vv.n !== v.n ? ' <a href="#" class="ar-vr" data-n="' + vv.n + '">restaurer</a>' : '') + '</div>'; }).join('') +
      (rt.gerer && x.partages.length ? '<h4 style="margin:10px 0 4px">Partages</h4>' + x.partages.map(function (p) { return '<div style="font-size:12px">🤝 ' + esc(tlabel(p.cible)) + ' · ' + (p.telechargement ? 'téléchargement' : 'lecture') + (p.jusqu ? ' · jusqu\'au ' + fr(p.jusqu) : '') + '</div>'; }).join('') : '') +
      '<h4 style="margin:10px 0 4px">Historique</h4><div style="max-height:160px;overflow:auto">' + x.historique.slice().reverse().map(function (e) { return '<div style="font-size:12px;border-bottom:1px solid #eee;padding:2px 0">' + fr(e.le) + ' ' + String(e.le).slice(11, 16) + ' · ' + (HL[e.a] || esc(e.a)) + ' · ' + esc(e.par) + (e.verifie ? '' : ' <i>(non vérifié)</i>') + (e.det ? ' — ' + esc(e.det) : '') + '</div>'; }).join('') + '</div>';
    var el = modal(h);
    $('ar_x').onclick = closeM; $('ar_pv').onclick = function () { closeM(); preview(id); };
    if ($('ar_dl')) $('ar_dl').onclick = function () { download(id); };
    each(el, '.ar-vp', function (b) { b.onclick = function (e) { e.preventDefault(); closeM(); preview(id, +b.getAttribute('data-n')); }; });
    each(el, '.ar-vd', function (b) { b.onclick = function (e) { e.preventDefault(); download(id, +b.getAttribute('data-n')); }; });
    each(el, '.ar-vr', function (b) { b.onclick = async function (e) { e.preventDefault(); var ok = typeof w.exbConfirm === 'function' ? await w.exbConfirm('Restaurer la version ' + b.getAttribute('data-n') + ' ? Elle devient une nouvelle version courante ; l\'historique est conservé.') : true; if (!ok) return; var r = restoreD(id, +b.getAttribute('data-n')); if (!r.ok) return say(r.error, 'warn'); closeM(); render(); openDoc(id); }; });
    if ($('ar_nv')) $('ar_nv').onclick = function () { formVersion(id); };
    if ($('ar_ed')) $('ar_ed').onclick = function () { formEdit(id); };
    if ($('ar_ar')) $('ar_ar').onclick = async function () { var m = typeof w.exbPrompt === 'function' ? await w.exbPrompt('Motif d\'archivage (facultatif) :', '') : ''; if (m === null) return; var r = mutate(id, function (dd, a, n) { return archive(dd, a, n, m); }, 'archive', { motif: String(m || '').slice(0, 80) }); if (!r.ok) return say(r.error, 'warn'); closeM(); render(); };
    if ($('ar_ua')) $('ar_ua').onclick = async function () { var m = typeof w.exbPrompt === 'function' ? await w.exbPrompt('Motif du désarchivage (obligatoire) :', '') : null; if (m === null) return; var r = mutate(id, function (dd, a, n) { return unarchive(dd, a, n, m); }, 'desarchive', { motif: String(m || '').slice(0, 80) }); if (!r.ok) return say(r.error, 'warn'); closeM(); render(); };
    if ($('ar_dr')) $('ar_dr').onclick = function () { formDroits(id); };
    if ($('ar_rm')) $('ar_rm').onclick = async function () {
      var m = typeof w.exbPrompt === 'function' ? await w.exbPrompt('Suppression définitive de « ' + x.titre + ' » (toutes les versions). Motif obligatoire :', '') : null; if (m === null) return;
      var c = canDelete(find(id), actor(), isAdmin(), nowIso(), m); if (!c.ok) return say(c.error, 'warn');
      if (c.forcee) { var ok = typeof w.exbConfirm === 'function' ? await w.exbConfirm('La conservation n\'est pas échue. Supprimer quand même (tracé dans le journal) ?') : false; if (!ok) return; }
      var r = removeD(id, m); if (!r.ok) return say(r.error, 'warn'); closeM(); say('Document supprimé.', 'success'); render();
    };
  }
  function formEdit(id) {
    var x = find(id); if (!x) return;
    var el = modal('<h3 style="margin:0 0 8px">Modifier — ' + esc(x.no) + '</h3><form id="ar_ef" style="display:grid;gap:8px">' + suggestions() + '<label>Titre <input id="ar_t" required maxlength="160" value="' + esc(x.titre) + '"></label><label>Type <select id="ar_ty">' + opts(TYPES, x.type) + '</select></label><label>Projet <input id="ar_p" list="ar_pl" value="' + esc(x.projet) + '"></label><label>Client <input id="ar_c" list="ar_cl" value="' + esc(x.client) + '"></label><label>Service <select id="ar_s">' + opts(SERVICES, x.service, '— aucun —') + '</select></label><label>Mots-clés <input id="ar_k" value="' + esc(x.motsCles.join(', ')) + '"></label><label>Description <textarea id="ar_d" rows="2" maxlength="500">' + esc(x.description) + '</textarea></label><label>Conservation (années) <input id="ar_cv" type="number" min="0" max="99" value="' + (x.conservationAns == null ? '' : x.conservationAns) + '"></label><div style="font-size:12px;color:#555">Réduire ou retirer la conservation : administrateur seul. Le fichier et ses versions ne changent pas.</div><div id="ar_err" style="color:#b91c1c;font-size:13px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" id="ar_cx">Annuler</button><button type="submit" class="btn">Enregistrer</button></div></form>');
    $('ar_cx').onclick = function () { closeM(); openDoc(id); };
    $('ar_ef').onsubmit = function (e) { e.preventDefault(); var r = editD(id, { titre: $('ar_t').value, type: $('ar_ty').value, projet: $('ar_p').value, client: $('ar_c').value, service: $('ar_s').value, motsCles: $('ar_k').value, description: $('ar_d').value, conservationAns: $('ar_cv').value }); if (!r.ok) { $('ar_err').textContent = r.error; return; } closeM(); render(); openDoc(id); };
  }
  function formLot() {
    var el = modal('<h3 style="margin:0 0 8px">Déposer plusieurs documents</h3><form id="ar_lf" style="display:grid;gap:8px">' + suggestions() + '<label>Fichiers (max ' + (MAX / 1048576) + ' Mo chacun) <input id="ar_files" type="file" multiple required></label><div style="font-size:12px;color:#555">Le titre de chaque document est son nom de fichier ; le type et le service sont déduits du nom si vous ne les choisissez pas.</div><label>Type <select id="ar_ty">' + opts(TYPES, '', '— selon le nom —') + '</select></label><label>Projet <input id="ar_p" list="ar_pl"></label><label>Client <input id="ar_c" list="ar_cl"></label><label>Service <select id="ar_s">' + opts(SERVICES, '', '— selon le nom —') + '</select></label><label>Mots-clés <input id="ar_k"></label><label>Conservation (années) <input id="ar_cv" type="number" min="0" max="99"></label><div id="ar_err" style="font-size:13px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" id="ar_cx">Fermer</button><button type="submit" id="ar_ok" class="btn">Déposer</button></div></form>');
    $('ar_cx').onclick = function () { closeM(); render(); };
    $('ar_lf').onsubmit = async function (e) {
      e.preventDefault(); var fs = Array.prototype.slice.call($('ar_files').files), ok = 0, bad = []; $('ar_ok').disabled = true;
      for (var i = 0; i < fs.length; i++) {
        $('ar_err').textContent = 'Dépôt ' + (i + 1) + '/' + fs.length + '…'; var g = guess(fs[i].name);
        var r = await add({ fichier: fs[i], titre: fs[i].name.replace(/\.[^.]+$/, ''), type: $('ar_ty').value || g.type, projet: $('ar_p').value, client: $('ar_c').value, service: $('ar_s').value || ((!$('ar_p').value.trim() && !$('ar_c').value.trim()) ? g.service : ''), motsCles: $('ar_k').value, conservationAns: $('ar_cv').value });
        if (r.ok) ok++; else bad.push(fs[i].name + ' : ' + r.error);
      }
      $('ar_err').style.color = bad.length ? '#b91c1c' : '#15803d'; $('ar_err').innerHTML = ok + ' document(s) déposé(s) sur ' + fs.length + (bad.length ? '<br>' + bad.map(esc).join('<br>') : ''); $('ar_ok').disabled = false; render();
    };
  }
  function formVersion(id) {
    var el = modal('<h3 style="margin:0 0 8px">Nouvelle version</h3><form id="ar_vf" style="display:grid;gap:8px"><label>Fichier <input id="ar_vfile" type="file" required></label><label>Note de version <input id="ar_vn" maxlength="200"></label><div id="ar_err" style="color:#b91c1c;font-size:13px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" id="ar_cx">Annuler</button><button type="submit" class="btn">Ajouter</button></div></form>');
    $('ar_cx').onclick = function () { closeM(); openDoc(id); };
    $('ar_vf').onsubmit = async function (e) { e.preventDefault(); var r = await newVersion(id, $('ar_vfile').files[0], $('ar_vn').value); if (!r.ok) { $('ar_err').textContent = r.error; return; } closeM(); render(); openDoc(id); };
  }
  function formDroits(id) {
    var x = find(id); if (!x) return;
    var el = modal('<h3 style="margin:0 0 8px">Droits et partages — ' + esc(x.no) + '</h3><form id="ar_rf" style="display:grid;gap:8px"><label>Accès <select id="ar_a"><option value="tous"' + (x.acces === 'tous' ? ' selected' : '') + '>Tous (lecture)</option><option value="restreint"' + (x.acces === 'restreint' ? ' selected' : '') + '>Restreint</option></select></label><label>Téléchargement <select id="ar_dl"><option value="oui"' + (x.telechargement === 'oui' ? ' selected' : '') + '>Autorisé</option><option value="non"' + (x.telechargement === 'non' ? ' selected' : '') + '>Restreint</option></select></label><button type="submit" class="btn">Enregistrer les droits</button></form>' +
      '<h4 style="margin:12px 0 4px">Partager avec</h4><form id="ar_sf" style="display:grid;gap:8px"><label>Personne ou « fonction: Directeur général » <input id="ar_sc" required></label><label>Fin du partage (facultatif) <input id="ar_sj" type="date"></label><label><input id="ar_st" type="checkbox"> Autoriser le téléchargement</label><div id="ar_err" style="color:#b91c1c;font-size:13px"></div><button type="submit" class="btn">Partager</button></form>' +
      (x.partages.length ? '<h4 style="margin:12px 0 4px">Partages en cours</h4>' + x.partages.map(function (p) { return '<div style="font-size:13px">🤝 ' + esc(tlabel(p.cible)) + ' · ' + (p.telechargement ? 'téléchargement' : 'lecture') + (p.jusqu ? ' · jusqu\'au ' + fr(p.jusqu) : '') + ' <a href="#" class="ar-un" data-l="' + esc(tlabel(p.cible)) + '">retirer</a></div>'; }).join('') : '') + '<div style="text-align:right;margin-top:10px"><button type="button" id="ar_cx">Fermer</button></div>');
    $('ar_cx').onclick = function () { closeM(); openDoc(id); };
    $('ar_rf').onsubmit = function (e) { e.preventDefault(); var r = mutate(id, function (dd, a, n) { return setAccess(dd, $('ar_a').value, $('ar_dl').value, a, n); }, 'droits', { acces: $('ar_a').value, dl: $('ar_dl').value }); if (!r.ok) return say(r.error, 'warn'); closeM(); formDroits(id); };
    $('ar_sf').onsubmit = function (e) { e.preventDefault(); var c = parseTarget($('ar_sc').value), r = mutate(id, function (dd, a, n) { return share(dd, c, $('ar_st').checked, $('ar_sj').value, a, n); }, 'partage', { cible: tlabel(c) }); if (!r.ok) { $('ar_err').textContent = r.error; return; } closeM(); formDroits(id); };
    each(el, '.ar-un', function (b) { b.onclick = function (e) { e.preventDefault(); var l = b.getAttribute('data-l'), r = mutate(id, function (dd, a, n) { return unshare(dd, l, a, n); }, 'partage', { retrait: l }); if (!r.ok) return say(r.error, 'warn'); closeM(); formDroits(id); }; });
  }
  function mount() {
    if ($('exbar')) return;
    var ref = $('exbwf') || $('exbbi') || $('budgetfin') || $('chantiers') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, s = d.createElement('section');
    s.id = 'exbar'; s.style.display = 'none';
    s.innerHTML = '<div class="card"><div class="exb-module-head"><div><h2>🗄 Excellencia Archives</h2><p class="exb-muted">Bibliothèque documentaire : classement, recherche, versions, droits, partage limité, conservation et historique.</p></div></div><div id="ar_box"></div></div>';
    if (ref && ref.parentNode) ref.parentNode.insertBefore(s, ref.nextSibling); else host.appendChild(s);
    var b = $('bwf') || $('bbi') || $('bbfin') || $('bcompta') || $('bchan') || $('bprj');
    if (b && !$('bar')) { var n = d.createElement('button'); n.id = 'bar'; n.textContent = '🗄 Archives'; n.setAttribute('onclick', "show('exbar')"); b.parentNode.insertBefore(n, b.nextSibling); }
    var os = w.show;
    if (typeof os === 'function' && !w.__exbArShow) { w.__exbArShow = 1; w.show = function (x) { var r = os.apply(this, arguments), e = $('exbar'); if (e) e.style.display = (x === 'exbar') ? '' : 'none'; if (x === 'exbar') render(); return r; }; }
  }
  /* démarrage lent / interface reconstruite par l'application (ex. après la connexion) : on remonte l'écran s'il manque.
     Deux recherches d'identifiant toutes les 3 s, uniquement quand la page est visible. */
  function watch() { setInterval(function () { try { if (d.hidden) return; if (!$('exbar') || !$('bar')) { var e = $('exbar'); if (e && !$('bar')) e.remove(); mount(); } } catch (e) {} }, 3000); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(mount, 1100); watch(); }); else { setTimeout(mount, 1100); watch(); }
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
