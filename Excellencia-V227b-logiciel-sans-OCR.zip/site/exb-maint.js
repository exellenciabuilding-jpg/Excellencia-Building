/* Excellencia Building — BUREAU MAINTENANCE / FACILITY V213 (cahier des charges V1.0, §5.8)
 * Fonctions du cahier : registre équipements, plans de maintenance, ordres de travail, garanties et historique.
 *   1. REGISTRE : repère unique, désignation, local, fabricant / modèle, mise en service, fin de garantie, GlobalId IFC contrôlé (22 caractères) ; état de garantie calculé.
 *   2. PLANS DE MAINTENANCE : tâche + périodicité en jours (SAISIE) + dernière réalisation → prochaine échéance, état À jour / Bientôt / En retard / À planifier.
 *      La dernière réalisation tient compte des ordres de travail préventifs CLOS (même repère, même tâche).
 *   3. ORDRES DE TRAVAIL : préventif ou correctif, priorité, échéance ; « Clos » exige la date de réalisation, un NOM et un compte rendu ;
 *      génération des OT préventifs échus (jamais de doublon avec un OT ouvert) ; un correctif est marqué sous garantie ou hors garantie selon la date d'ouverture.
 *   4. HISTORIQUE par équipement : interventions closes, correctifs, coût cumulé, dernière intervention.
 * Hors périmètre de cette étape (signalé, jamais simulé) : maintenance prédictive, périodicités réglementaires pré-remplies, stocks de pièces, planning d'équipes.
 * Registre vivant : pas de verrouillage par visa ; les contrôles « bloquants » signalent ce qui est à traiter.
 * Garde-fou : moteurs déterministes, aucune IA. Données : clé exb_maint. Pour retirer : supprimer la balise <script src="exb-maint.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBMaint) return;
  var K = 'exb_maint', EXP = {}, RGUID = /^[0-9A-Za-z_$]{22}$/;

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function num(v, def) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : (def === undefined ? NaN : def); }
  function fx(v, n) { return isFinite(v) ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: n, maximumFractionDigits: n }) : '—'; }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function who() { return ask('Votre nom (signature nominative, non qualifiée) :', '').then(function (v) { return String(v || '').trim(); }); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id) }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function san(t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/→/g, '->').replace(/²/g, '2').replace(/³/g, '3').replace(/×/g, 'x').replace(/√/g, 'rac ').replace(/·/g, '.').replace(/Δ/g, 'delta ').replace(/Ø/g, 'D ').replace(/φ/g, 'phi ').replace(/’/g, "'"); }
  function csv(rows, name) { var t = '﻿' + rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); try { var b = new Blob([t], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = (w.URL || w.webkitURL).createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); } catch (e) { toast('Export impossible : ' + e.message, 'error'); } }
  function pdf(o) { if (!w.EXBPdf) return toast('Module PDF indisponible.', 'error'); try { var p = w.EXBPdf.make(w.EXBENT && w.EXBENT.piece ? w.EXBENT.piece(o) : o); return Promise.resolve(p).then(function (b) { if (b && b.size && w.EXBPdf.save) { w.EXBPdf.save(b, String((o && (o.sousTitre || o.titre)) || 'rapport').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) + '.pdf'); toast('PDF généré.', 'success'); } return b; }, function (e) { toast('PDF impossible : ' + (e && e.message || e), 'error'); }); } catch (e) { toast('PDF impossible : ' + e.message, 'error'); } }

  /* Lecture de lignes de saisie (« a ; b ; c »), dates, états calculés. */
  function lignes(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return l && l.charAt(0) !== '#'; }); }
  function champs(l) { return l.split(/[;\t]/).map(function (x) { return x.trim(); }); }
  /* fn(champs, indice) renvoie un objet (ligne valide) ou une chaîne (motif du refus). */
  function parse(t, fn) { var R = [], E = []; lignes(t).forEach(function (l, i) { var r = fn(champs(l), i); if (typeof r === 'string') E.push({ ligne: i + 1, msg: r }); else R.push(r); }); return { rows: R, erreurs: E }; }
  function iso(s) { s = String(s == null ? '' : s).trim(); var a, b, c, m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s); if (m) { a = +m[1]; b = +m[2]; c = +m[3]; } else { m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s); if (!m) return null; a = +m[3]; b = +m[2]; c = +m[1]; } var t = new Date(Date.UTC(a, b - 1, c)); if (t.getUTCFullYear() !== a || t.getUTCMonth() !== b - 1 || t.getUTCDate() !== c) return null; return t.toISOString().slice(0, 10); }
  /* D : '' si vide, null si illisible, sinon la date AAAA-MM-JJ. */
  function D(s) { return String(s == null ? '' : s).trim() === '' ? '' : iso(s); }
  function dj(a, b) { return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000); }
  function plus(a, n) { return new Date(Date.parse(a + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10); }
  function auj() { var t = new Date(), p = function (v) { return (v < 10 ? '0' : '') + v; }; return t.getFullYear() + '-' + p(t.getMonth() + 1) + '-' + p(t.getDate()); }
  function df(s) { return s ? String(s).split('-').reverse().join('/') : '—'; }
  /* État d'un point de suivi : clôture = preuve ET nom ; l'un sans l'autre = « Incomplet ». */
  function suivi(ech, preuve, par, today) { var p = String(preuve || '').trim(), n = String(par || '').trim(); if (p && n) return 'Clos'; if (p || n) return 'Incomplet'; return ech && ech < today ? 'En retard' : 'Ouvert'; }
  /* État d'une validité (garantie, assurance) : jours d'alerte saisis. */
  function validite(fin, today, alerteJ) { if (!fin) return 'Sans échéance'; if (fin < today) return 'Expirée'; return dj(today, fin) <= (isFinite(alerteJ) ? alerteJ : 0) ? 'Expire bientôt' : 'Valide'; }
  function em(sec, e) { return (sec ? sec + ' ' : '') + (typeof e === 'string' ? e : 'ligne ' + e.ligne + ' : ' + e.msg); }
  function et(e) { var c = /^(Clos|Valide|À jour|Sous garantie|Levée|Conforme|OK)/.test(e) ? '#15803d' : /^(En retard|Expirée|Incomplet|Clôture|Échéance dépassée|Dépassement|Surcharge|Hors)/.test(e) ? '#b91c1c' : '#b45309'; return '<b style="color:' + c + '">' + esc(e) + '</b>'; }
  function pad3(n) { return String(n).padStart(3, '0'); }

  /* ========================================================== MOTEURS ========================================================== */
  var TYP = ['Préventif', 'Correctif'], PRIO = ['Basse', 'Normale', 'Haute', 'Urgente'];
  /* Équipements : repère ; désignation ; local ; fabricant / modèle ; mise en service ; fin de garantie ; GlobalId IFC */
  function parseEq(t) { var seen = {}; return parse(t, function (f) { var ms = D(f[4]), g = D(f[5]); return !f[0] ? 'repère manquant' : seen[f[0]] ? 'repère « ' + f[0] + ' » en double' : !f[1] ? 'désignation manquante' : (ms === null || g === null) ? 'date illisible' : (ms && g && g < ms) ? 'fin de garantie avant la mise en service' : (f[6] && !RGUID.test(f[6])) ? 'GlobalId IFC invalide (22 caractères [0-9A-Za-z_$])' : (seen[f[0]] = 1, { rep: f[0], des: f[1], local: f[2] || '', fab: f[3] || '', ms: ms, gar: g, guid: f[6] || '' }); }); }
  /* OT : n° ; repère ; description ; type ; priorité ; ouvert le ; échéance ; réalisé le ; réalisé par ; compte rendu ; coût */
  function parseOT(t, today) {
    var seen = {}; return parse(t, function (f) {
      var ouv = D(f[5]), ec = D(f[6]), re = D(f[7]), c = f[10] === '' || f[10] === undefined ? 0 : num(f[10]), typ = f[3] || 'Correctif', pr = f[4] || 'Normale', n;
      if (!f[0]) return 'n° manquant'; if (seen[f[0]]) return 'OT « ' + f[0] + ' » en double'; if (!f[1]) return 'repère manquant'; if (!f[2]) return 'description manquante'; if (TYP.indexOf(typ) < 0) return 'type : ' + TYP.join(' / '); if (PRIO.indexOf(pr) < 0) return 'priorité : ' + PRIO.join(' / ');
      if (!ouv) return 'date d’ouverture manquante ou illisible'; if (ec === null || re === null) return 'date illisible'; if (!(c >= 0)) return 'coût invalide'; if (re && re < ouv) return 'réalisation avant l’ouverture';
      seen[f[0]] = 1; n = [f[7], f[8], f[9]].filter(Boolean).length;
      return { no: f[0], rep: f[1], des: f[2], typ: typ, pr: pr, ouv: ouv, ech: ec, re: re, par: f[8] || '', cr: f[9] || '', cout: c, etat: n === 3 ? 'Clos' : n > 0 ? 'Incomplet' : (ec && ec < today ? 'En retard' : 'Ouvert') };
    });
  }
  /* Plans : repère ; tâche ; périodicité (jours) ; dernière réalisation ; responsable */
  function parsePlan(t) { return parse(t, function (f) { var p = num(f[2]), dr = D(f[3]); return !f[0] ? 'repère manquant' : !f[1] ? 'tâche manquante' : (!(p > 0) || p !== Math.floor(p)) ? 'périodicité : nombre entier de jours > 0' : dr === null ? 'date illisible' : { rep: f[0], tache: f[1], per: p, der: dr, resp: f[4] || '' }; }); }
  function plans(P, EQ, OT, today, aj) {
    var rep = {}; EQ.forEach(function (e) { rep[e.rep] = 1; });
    return P.map(function (p) {
      var der = p.der || ''; OT.forEach(function (o) { if (o.typ === 'Préventif' && o.etat === 'Clos' && o.rep === p.rep && o.des.toLowerCase() === p.tache.toLowerCase() && o.re > der) der = o.re; });
      var pro = der ? plus(der, p.per) : '', etat = !rep[p.rep] ? 'Repère inconnu' : !der ? 'À planifier' : pro < today ? 'En retard' : dj(today, pro) <= aj ? 'Bientôt' : 'À jour';
      return { p: p, der: der, pro: pro, etat: etat };
    });
  }
  function suivantNo(OT) { var m = 0; OT.forEach(function (o) { var r = /(\d+)$/.exec(o.no); if (r) m = Math.max(m, +r[1]); }); return m + 1; }
  /* Génère les lignes d'OT préventifs pour les plans à échéance (en retard, bientôt, à planifier) sans OT ouvert pour le même repère et la même tâche. */
  function genererOT(PL, OT, today) {
    var n = suivantNo(OT), L = [];
    PL.forEach(function (r) { if (['En retard', 'Bientôt', 'À planifier'].indexOf(r.etat) < 0) return; var dup = OT.some(function (o) { return o.etat !== 'Clos' && o.rep === r.p.rep && o.des.toLowerCase() === r.p.tache.toLowerCase(); }) || L.some(function (l) { return l.rep === r.p.rep && l.tache === r.p.tache; }); if (dup) return; L.push({ rep: r.p.rep, tache: r.p.tache, ligne: 'OT-' + String(n++).padStart(4, '0') + ';' + r.p.rep + ';' + r.p.tache + ';Préventif;Normale;' + today + ';' + (r.pro || today) + ';;;;' }); });
    return L;
  }
  function garantieOT(o, EQ) { var e = EQ.filter(function (x) { return x.rep === o.rep; })[0]; if (o.typ !== 'Correctif' || !e || !e.gar) return '—'; return o.ouv <= e.gar ? 'Sous garantie' : 'Hors garantie'; }
  function historique(EQ, OT) {
    return EQ.map(function (e) { var cl = OT.filter(function (o) { return o.rep === e.rep && o.etat === 'Clos'; }), last = ''; cl.forEach(function (o) { if (o.re > last) last = o.re; }); var cout = 0; cl.forEach(function (o) { cout += o.cout; });
      return { rep: e.rep, des: e.des, clos: cl.length, corr: cl.filter(function (o) { return o.typ === 'Correctif'; }).length, cout: cout, der: last, ouverts: OT.filter(function (o) { return o.rep === e.rep && o.etat !== 'Clos'; }).length }; });
  }

  /* ========================================================== DOSSIER ========================================================== */
  function nouveau() { var n = all().length + 1, y = new Date().getFullYear(); return { id: uid('MNT'), no: 'MNT-' + y + '-' + pad3(n), statut: 'En cours', titre: '', project_id: '', site: '', date: auj(), auteur: '', norme: { nom: '', edition: '' }, par: { alerteJ: '15' }, eqTxt: '', planTxt: '', otTxt: '', histo: [], cree: Date.now() }; }
  function calc(x, today) {
    today = today || auj(); var aj = num(x.par.alerteJ, 0), eq = parseEq(x.eqTxt), ot = parseOT(x.otTxt, today), pp = parsePlan(x.planTxt), pl = plans(pp.rows, eq.rows, ot.rows, today, aj);
    var inconnus = pl.filter(function (r) { return r.etat === 'Repère inconnu'; });
    return { today: today, aj: aj, eq: eq, ot: ot, pp: pp, pl: pl, inconnus: inconnus, hist: historique(eq.rows, ot.rows), gen: genererOT(pl, ot.rows, today) };
  }
  function verif(x, today) {
    var a = [], add = function (n, id, m) { a.push({ niveau: n, id: id, msg: m }); }, k = calc(x, today);
    if (!k.eq.rows.length) add('bloquant', 'MNT-1', 'Aucun équipement au registre.');
    if (!String(x.auteur || '').trim()) add('alerte', 'MNT-2', 'Responsable maintenance non renseigné.');
    k.eq.rows.forEach(function (e) { var v = validite(e.gar, k.today, k.aj); if (v === 'Expire bientôt') add('alerte', 'MNT-4', 'Équipement ' + e.rep + ' : garantie expire le ' + df(e.gar) + '.'); if (!k.pl.some(function (r) { return r.p.rep === e.rep; })) add('alerte', 'MNT-8', 'Équipement ' + e.rep + ' : aucun plan de maintenance.'); });
    k.pl.forEach(function (r) { var n = r.p.rep + ' / ' + r.p.tache; if (r.etat === 'En retard') add('bloquant', 'MNT-5', 'Plan ' + n + ' : échéance ' + df(r.pro) + ' dépassée.'); else if (r.etat === 'Bientôt') add('alerte', 'MNT-5', 'Plan ' + n + ' : échéance le ' + df(r.pro) + '.'); else if (r.etat === 'À planifier') add('alerte', 'MNT-5', 'Plan ' + n + ' : jamais réalisé, à planifier.'); else if (r.etat === 'Repère inconnu') add('alerte', 'MNT-3', 'Plan ' + n + ' : repère absent du registre.'); });
    k.ot.rows.forEach(function (o) { if (!k.eq.rows.some(function (e) { return e.rep === o.rep; })) add('alerte', 'MNT-3', 'OT ' + o.no + ' : repère « ' + o.rep + ' » absent du registre.'); if (o.etat === 'En retard') add('bloquant', 'MNT-6', 'OT ' + o.no + ' (' + o.rep + ') : échéance ' + df(o.ech) + ' dépassée.'); if (o.etat === 'Incomplet') add('alerte', 'MNT-7', 'OT ' + o.no + ' : clôture incomplète (date, nom et compte rendu obligatoires).'); if (o.pr === 'Urgente' && o.etat !== 'Clos') add('bloquant', 'MNT-9', 'OT ' + o.no + ' urgent non clos.'); });
    [['Équipements', k.eq.erreurs], ['Plans', k.pp.erreurs], ['Ordres de travail', k.ot.erreurs]].forEach(function (s) { s[1].forEach(function (e) { add('alerte', 'MNT-3', em(s[0], e)); }); });
    return a;
  }

  /* ========================================================== ONGLETS ========================================================== */
  function tabEq(x, dis) {
    var k = calc(x), h = lab('Équipements (repère ; désignation ; local ; fabricant / modèle ; mise en service ; fin de garantie ; [GlobalId IFC])', ta('eqTxt', x.eqTxt, dis, 6, 'CH-01;Chauffe-eau;Local technique;Marque X 200 L;2025-03-01;2027-03-01;')) + lab('Délai d’alerte avant échéance (jours) — saisi', inp('par.alerteJ', x.par.alerteJ, dis)) + '<!--RES-->' + errs([['Équipements', k.eq.erreurs]]);
    if (k.eq.rows.length) h += table(['Repère', 'Désignation', 'Local', 'Fabricant / modèle', 'Mise en service', 'Fin de garantie', 'Garantie', 'IFC'], k.eq.rows.map(function (e) { return [esc(e.rep), esc(e.des), esc(e.local || '—'), esc(e.fab || '—'), df(e.ms), df(e.gar), e.gar ? et(validite(e.gar, k.today, k.aj)) : '—', e.guid ? '✔' : '—']; })) + '<p style="font-size:12.5px">' + k.eq.rows.length + ' équipement(s) — ' + k.eq.rows.filter(function (e) { return e.guid; }).length + ' lié(s) à un objet IFC.</p>';
    return h;
  }
  function tabPlan(x, dis) {
    var k = calc(x), h = lab('Plans de maintenance (repère ; tâche ; périodicité en jours ; dernière réalisation ; [responsable])', ta('planTxt', x.planTxt, dis, 5, 'CH-01;Détartrage;365;2026-03-01;Technicien')) + '<!--RES-->' + errs([['Plans', k.pp.erreurs]]);
    if (k.pl.length) h += table(['Repère', 'Tâche', 'Périodicité (j)', 'Dernière réalisation', 'Prochaine', 'État'], k.pl.map(function (r) { return [esc(r.p.rep), esc(r.p.tache), r.p.per, df(r.der), df(r.pro), et(r.etat)]; })) + note('La dernière réalisation tient compte des OT préventifs clos (même repère, même tâche).');
    return h;
  }
  function tabOT(x, dis) {
    var k = calc(x), h = lab('Ordres de travail (n° ; repère ; description ; type Préventif|Correctif ; priorité Basse|Normale|Haute|Urgente ; ouvert le ; échéance ; réalisé le ; réalisé par ; compte rendu ; coût)', ta('otTxt', x.otTxt, dis, 7, 'OT-0001;CH-01;Fuite au raccord;Correctif;Haute;2026-11-10;2026-11-17;;;;')) + '<!--RES-->' + errs([['Ordres de travail', k.ot.erreurs]]);
    h += (k.gen.length ? '<p style="font-size:12.5px">' + k.gen.length + ' OT préventif(s) à générer : ' + k.gen.map(function (g) { return esc(g.rep + ' / ' + g.tache); }).join(', ') + '.</p>' + (!dis ? btn('⚙️ Générer les OT préventifs à échéance', 'genot', null, '#7c3aed') : '') : '<p style="font-size:12.5px;color:#475569">Aucun OT préventif à générer.</p>');
    if (k.ot.rows.length) h += table(['N°', 'Repère', 'Description', 'Type', 'Priorité', 'Échéance', 'Réalisé le', 'Coût', 'Garantie', 'État'], k.ot.rows.map(function (o) { var g = garantieOT(o, k.eq.rows); return [esc(o.no), esc(o.rep), esc(o.des), o.typ, o.pr, df(o.ech), df(o.re), fx(o.cout, 2), g === '—' ? '—' : et(g), et(o.etat)]; })) + note('« Clos » = date de réalisation, nom et compte rendu renseignés ; sinon « Incomplet ».');
    return h;
  }
  function tabHist(x) {
    var k = calc(x); if (!k.hist.length) return '<p>Saisissez d’abord des équipements.</p>';
    var cl = k.ot.rows.filter(function (o) { return o.etat === 'Clos'; }).sort(function (a, b) { return a.re < b.re ? 1 : a.re > b.re ? -1 : 0; });
    return table(['Repère', 'Désignation', 'OT clos', 'dont correctifs', 'OT ouverts', 'Coût cumulé', 'Dernière intervention'], k.hist.map(function (h) { return [esc(h.rep), esc(h.des), h.clos, h.corr, h.ouverts, fx(h.cout, 2), df(h.der)]; })) + (cl.length ? '<h4 style="margin:10px 0 4px">Interventions closes</h4>' + table(['Date', 'Repère', 'OT', 'Type', 'Réalisé par', 'Compte rendu'], cl.map(function (o) { return [df(o.re), esc(o.rep), esc(o.no), o.typ, esc(o.par), esc(o.cr)]; })) : '');
  }

  var CFG = {
    id: 'exbMaint', glob: 'EXBMaint', audit: 'maint', nom: 'Bureau maintenance / facility', area: 'Exploitation', cat: 'prj', visa: false,
    label: '🛠️ Maintenance / facility', desc: 'Registre équipements, plans de maintenance, ordres de travail, garanties, historique',
    intro: 'Registre des équipements, plans de maintenance, ordres de travail et historique. Les périodicités sont celles que vous saisissez.', nouveau: 'Nouveau dossier maintenance', auteur: 'Responsable maintenance',
    anchors: ['exbJurBtn', 'exbEnvBtn', 'exbVrdBtn', 'exbPlombBtn', 'exbElecBtn', 'exbGeoPlusBtn', 'exbTopoBtn', 'exbBeDalBtn', 'exbBeP2Btn', 'exbBeBtn'],
    tabs: [['eq', '🧰 Équipements'], ['plan', '🗓️ Plans'], ['ot', '📝 Ordres de travail'], ['hist', '📚 Historique']], tabf: { eq: tabEq, plan: tabPlan, ot: tabOT, hist: tabHist },
    creer: nouveau, pdfBtn: 'Rapport de maintenance PDF', pdfTitre: 'RAPPORT DE MAINTENANCE', pdfNote: 'Registre deterministe - periodicites et delais saisis par le projet ; ne remplace pas le suivi d\'un responsable de maintenance.',
    csvBtns: [['csve', '⬇️ Registre équipements CSV', function (x) { return { rows: [['Repère', 'Désignation', 'Local', 'Fabricant / modèle', 'Mise en service', 'Fin de garantie', 'GlobalId IFC']].concat(calc(x).eq.rows.map(function (e) { return [e.rep, e.des, e.local, e.fab, e.ms, e.gar, e.guid]; })), name: x.no + '-equipements.csv' }; }], ['csvo', '⬇️ Ordres de travail CSV', function (x) { return { rows: [['N°', 'Repère', 'Description', 'Type', 'Priorité', 'Ouvert le', 'Échéance', 'Réalisé le', 'Réalisé par', 'Compte rendu', 'Coût', 'État']].concat(calc(x).ot.rows.map(function (o) { return [o.no, o.rep, o.des, o.typ, o.pr, o.ouv, o.ech, o.re, o.par, o.cr, o.cout, o.etat]; })), name: x.no + '-ordres-de-travail.csv' }; }]],
    extra: function (a, i, x) { if (a !== 'genot') return false; var k = calc(x); if (!k.gen.length) { toast('Aucun OT préventif à générer.', 'info'); return true; } x.otTxt = (String(x.otTxt || '').replace(/\s+$/, '') + (String(x.otTxt || '').trim() ? '\n' : '') + k.gen.map(function (g) { return g.ligne; }).join('\n')); jrn(x, k.gen.length + ' OT préventif(s) généré(s)'); saveDos(x); audit('maint.ot.generes', x.no, { n: k.gen.length }); paint(); return true; },
    pdfRows: function (x) {
      var k = calc(x), r = [['Dossier', x.no + ' — ' + (x.titre || '—')], ['Projet / site', pnom(x.project_id) + ' — ' + (x.site || '—')], ['Responsable / date', (x.auteur || '—') + ' — ' + (x.date || '—')], ['Équipements', k.eq.rows.length + ' repère(s) — ' + k.eq.rows.filter(function (e) { return e.guid; }).length + ' lié(s) IFC']];
      k.pl.forEach(function (p) { r.push(['Plan ' + p.p.rep, p.p.tache + ' — tous les ' + p.p.per + ' j — prochaine ' + df(p.pro) + ' — ' + p.etat]); });
      k.ot.rows.forEach(function (o) { r.push(['OT ' + o.no, o.rep + ' — ' + o.typ + ' — ' + o.pr + ' — ' + o.etat]); });
      k.hist.forEach(function (h) { r.push(['Historique ' + h.rep, h.clos + ' OT clos (' + h.corr + ' correctif(s)) — coût ' + fx(h.cout, 2) + ' — dernière ' + df(h.der)]); }); return r;
    }
  };
  EXP = { parseEq: parseEq, parseOT: parseOT, parsePlan: parsePlan, plans: plans, genererOT: genererOT, garantieOT: garantieOT, historique: historique, suivantNo: suivantNo, verif: verif, nouveau: nouveau, calc: calc };

  /* ========================================================== DOSSIER ========================================================== */
  function all() { return rd(K); }
  function find(id) { return all().filter(function (x) { return x.id === id; })[0]; }
  function saveDos(x) { var a = all(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i < 0) a.push(x); else a[i] = x; return wr(K, a); }
  function bloque(x) { return verif(x).filter(function (v) { return v.niveau === 'bloquant'; }); }

  /* ========================================================== INTERFACE ========================================================== */
  var TAB = null, GID = null;
  function box() { return d.getElementById(CFG.id + 'Box'); }
  function ro(x) { return !!CFG.visa && x.statut !== 'Brouillon'; }
  function btn(l, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + l + '</button>'; }
  function lab(t, h) { return '<label style="display:block;font-size:12.5px;color:#334155">' + t + h + '</label>'; }
  function inp(f, v, dis) { return '<input data-f="' + f + '" value="' + esc(v) + '"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px;box-sizing:border-box">'; }
  function ta(f, v, dis, rows, ph) { return '<textarea data-f="' + f + '" rows="' + (rows || 5) + '"' + (dis ? ' disabled' : '') + ' placeholder="' + esc(ph || '') + '" style="width:100%;box-sizing:border-box;padding:6px;font:12.5px monospace">' + esc(v) + '</textarea>'; }
  function table(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr>' + h.map(function (c) { return '<th style="text-align:left;border-bottom:1px solid #cbd5e1;padding:4px 8px">' + c + '</th>'; }).join('') + '</tr>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="border-bottom:1px solid #e2e8f0;padding:4px 8px">' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</table></div>'; }
  function alertesHtml(A) { return A.length ? '<ul style="margin:6px 0;padding-left:18px;font-size:12.5px">' + A.map(function (a) { return '<li style="color:' + (a.niveau === 'bloquant' ? '#b91c1c' : '#b45309') + '">' + esc(a.id) + ' — ' + esc(a.msg) + '</li>'; }).join('') + '</ul>' : '<p style="color:#15803d;font-size:12.5px">Aucune alerte.</p>'; }
  function grid(h) { return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + h + '</div>'; }
  function errs(list) { var e = []; list.forEach(function (s) { s[1].forEach(function (m) { e.push(em(s[0], m)); }); }); return e.length ? '<ul style="font-size:12.5px;color:#b45309;padding-left:18px">' + e.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>' : ''; }
  function note(t) { return '<p style="font-size:12px;color:#475569;margin:6px 0">' + t + '</p>'; }
  function liste0() { var a = all(); return '<h3 style="margin:6px 0">' + CFG.label + '</h3><p style="font-size:12.5px;color:#475569">' + CFG.intro + '</p>' + btn('➕ ' + CFG.nouveau, 'new') + (a.length ? table(['N°', 'Titre', 'Projet', 'Statut', ''], a.map(function (r) { return [esc(r.no), esc(r.titre || '—'), esc(pnom(r.project_id)), esc(r.statut), btn('Ouvrir', 'open', r.id)]; })) : '<p>Aucun dossier.</p>'); }
  function tabRap(x) {
    var A = verif(x), h = '<h4 style="margin:6px 0">Contrôles</h4>' + alertesHtml(A);
    if (CFG.visa) {
      h += '<h4 style="margin:10px 0 4px">Visa</h4><p style="font-size:12.5px">Statut : <b>' + esc(x.statut) + '</b>' + (x.verifie ? ' — vérifié par ' + esc(x.verifie.par) : '') + (x.vise ? ' — visé par ' + esc(x.vise.par) : '') + '</p>';
      if (x.statut === 'Brouillon') h += btn('Marquer comme vérifié', 'verifier', null, '#7c3aed'); if (x.statut === 'Vérifié') h += btn('Viser le dossier', 'viser', null, '#7c3aed'); if (x.statut !== 'Brouillon') h += btn('Rouvrir (motif obligatoire)', 'rouvrir', null, '#475569');
    }
    h += '<div style="margin-top:8px">' + btn('📄 ' + CFG.pdfBtn, 'pdf', null, '#0369a1') + CFG.csvBtns.map(function (b) { return btn(b[1], b[0], null, '#475569'); }).join('') + '</div>';
    if (x.histo.length) h += '<h4 style="margin:10px 0 4px">Historique</h4><ul style="font-size:12px;padding-left:18px">' + x.histo.map(function (e) { return '<li>' + esc(new Date(e.t).toLocaleString('fr-FR')) + ' — ' + esc(e.msg) + '</li>'; }).join('') + '</ul>';
    return h;
  }
  /* Chaque onglet renvoie « saisie <!--RES--> résultats » : seuls les résultats sont redessinés à chaque modification, la saisie garde le focus. */
  function onglet(x, dis) { return TAB === 'rap' ? tabRap(x) : CFG.tabf[TAB](x, dis); }
  function coupe(h) { var i = h.indexOf('<!--RES-->'); return i < 0 ? [h, null] : [h.slice(0, i), h.slice(i + 10)]; }
  function paint() {
    var b = box(); if (!b) return; var x = GID ? find(GID) : null;
    if (!x) { b.innerHTML = '<div style="display:flex"><button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + liste0(); return; }
    if (!TAB) TAB = CFG.tabs[0][0];
    var dis = ro(x), tabs = CFG.tabs.concat([['rap', '✅ Rapport']]), s = coupe(onglet(x, dis));
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><button data-a="back" style="padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">← Dossiers</button>' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:999px;background:' + (TAB === t[0] ? '#0f766e' : '#e2e8f0') + ';color:' + (TAB === t[0] ? '#fff' : '#0f172a') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' +
      grid(lab('Titre', inp('titre', x.titre, dis)) + lab('Projet', '<select data-f="project_id"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="">—</option>' + projets().map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === x.project_id ? ' selected' : '') + '>' + esc(p.nom) + '</option>'; }).join('') + '</select>') + lab('Site / bâtiment', inp('site', x.site, dis)) + lab(CFG.auteur, inp('auteur', x.auteur, dis))) + '<p style="font-size:12px;color:#475569;margin:6px 0">' + esc(x.no) + ' — ' + esc(x.statut) + (dis ? ' (verrouillé : rouvrir pour modifier)' : '') + '</p><div id="' + CFG.id + 'Tab">' + s[0] + (s[1] !== null ? '<div id="' + CFG.id + 'Res">' + s[1] + '</div>' : '') + '</div>';
  }
  function repaintRes(x) { var s = coupe(onglet(x, ro(x))), r = d.getElementById(CFG.id + 'Res'); if (s[1] === null || !r) return paint(); r.innerHTML = s[1]; }
  function setPath(x, f, v) { var p = f.split('.'), o = x; while (p.length > 1) o = o[p.shift()]; o[p[0]] = v; }
  function jrn(x, m) { x.histo.push({ t: Date.now(), msg: m }); }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), x = GID ? find(GID) : null; if (!f || !x || ro(x)) return;
    setPath(x, f, t.value); var full = CFG.onSet ? CFG.onSet(x, f) : false; saveDos(x); if (full) paint(); else if (f !== 'project_id' && f !== 'titre' && f !== 'site' && f !== 'auteur') repaintRes(x);
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i'), x = GID ? find(GID) : null, A = CFG.audit;
    if (a === 'close') { var o = d.getElementById(CFG.id); if (o) o.remove(); return; }
    if (a === 'new') { var n = CFG.creer(); saveDos(n); GID = n.id; TAB = CFG.tabs[0][0]; audit(A + '.nouveau', n.no, {}); return paint(); }
    if (a === 'open') { GID = i; TAB = CFG.tabs[0][0]; return paint(); }
    if (a === 'back') { GID = null; return paint(); }
    if (a === 'tab') { TAB = i; return paint(); }
    if (!x) return;
    if (CFG.extra && CFG.extra(a, i, x)) return;
    if (a === 'verifier') { var bl = bloque(x); if (bl.length) return toast('Vérification impossible : ' + bl.map(function (v) { return v.id; }).filter(function (v, j, s) { return s.indexOf(v) === j; }).join(', ') + ' (voir Rapport).', 'warn'); return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le vérificateur doit être une autre personne que l’auteur.', 'warn'); x.statut = 'Vérifié'; x.verifie = { par: par, t: Date.now() }; jrn(x, 'Vérifié par ' + par); saveDos(x); audit(A + '.verifie', x.no, { par: par }); paint(); }); }
    if (a === 'viser') return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le visa ne peut pas être donné par l’auteur.', 'warn'); x.statut = 'Visé'; x.vise = { par: par, t: Date.now() }; jrn(x, 'Visé par ' + par); saveDos(x); audit(A + '.vise', x.no, { par: par }); paint(); });
    if (a === 'rouvrir') return ask('Motif de la réouverture (obligatoire) :', '').then(function (m) { m = String(m || '').trim(); if (!m) return toast('Motif obligatoire.', 'warn'); jrn(x, 'Rouvert en brouillon — ' + m); x.statut = 'Brouillon'; delete x.verifie; delete x.vise; saveDos(x); audit(A + '.rouvert', x.no, { motif: m }); paint(); });
    var cb = CFG.csvBtns.filter(function (b) { return b[0] === a; })[0]; if (cb) { var c = cb[2](x); return csv(c.rows, c.name); }
    if (a === 'pdf') { var rows = CFG.pdfRows(x); verif(x).forEach(function (v) { rows.push(['Contrôle ' + v.id, v.niveau + ' : ' + v.msg]); }); return pdf({ titre: CFG.pdfTitre, sousTitre: san(x.no + ' — ' + (x.titre || '')), rows: rows.map(function (r) { return [san(r[0]), san(r[1])]; }), notes: [san(CFG.pdfNote)], footer: san(x.no + ' — ' + x.statut) }); }
  }
  function ouvrir(tab) {
    if (tab) TAB = tab; var o = d.getElementById(CFG.id); if (o) o.remove();
    o = d.createElement('div'); o.id = CFG.id; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = CFG.id + 'Box'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('change', onChange); c.addEventListener('click', onClick); paint();
  }
  function ui() {
    if (d.getElementById(CFG.id + 'Btn')) return; var b = null; CFG.anchors.forEach(function (id) { if (!b) b = d.getElementById(id); }); if (!b) return;
    var k = d.createElement('button'); k.id = CFG.id + 'Btn'; k.setAttribute('data-exb-cat', CFG.cat); k.setAttribute('data-exb-desc', CFG.desc); k.className = b.className; k.textContent = CFG.label; k.onclick = function () { ouvrir(CFG.tabs[0][0]); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined' && d.documentElement && d.documentElement.nodeType) new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: CFG.audit, name: CFG.nom, version: '1.0.0', area: CFG.area, deps: [], collections: [K] }); } catch (e) {}
  EXP.open = ouvrir; EXP.verif = verif; EXP.nouveau = CFG.creer; EXP.calc = calc;
  w[CFG.glob] = EXP;
  if (typeof module !== 'undefined' && module.exports) module.exports = w[CFG.glob];
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { addEventListener: function () {}, documentElement: {} });
