# V205w — Messages d'invitation (mot de passe) et fonction d'un membre

Aucun SQL nouveau (la migration `supabase/migration-v205v-codes-personnels.sql` de V205v reste à exécuter une fois si ce n'est pas fait).

## 1. « Connectez-vous avec votre mot de passe habituel »
Un membre qu'on vient d'enregistrer n'a pas encore de mot de passe. Le message dit maintenant, dans tous les cas :
- **première fois** : « Première connexion » → il crée son compte avec l'adresse e-mail invitée et **choisit lui-même son mot de passe** (8 caractères minimum) ;
- **compte déjà existant** : « Se connecter » avec son mot de passe, ou « Mot de passe oublié ? ».
Le message rappelle aussi sa **fonction** (« attribuée par l'administrateur : rien à choisir ») et contient son code d'activation personnel.

## 2. Une fonction qu'il n'a pas choisie alors qu'il a créé son compte dans l'espace Comptable
La fonction ne dépend **pas** de l'espace où le compte est créé (sinon n'importe qui pourrait se donner « Direction » ou « Comptable » en ouvrant le bon lien) : elle vient de l'**invitation de l'administrateur**.
Le problème venait du formulaire d'invitation, qui proposait « Polyvalent » par défaut.
- **Équipe › Inviter** : plus de fonction par défaut, **le choix est obligatoire** (« — Choisir la fonction — »).
- **Équipe › Membres** : un membre resté « Polyvalent » est signalé « ⚠ fonction à choisir » ; l'administrateur corrige en un clic dans la liste déroulante.
- **Accès refusé** (écran de l'espace) : explique que la fonction vient de l'invitation (ou « Polyvalent » par défaut sans invitation à son adresse), indique quoi demander à l'administrateur, et offre **« J'ai été corrigé(e) : réessayer »** (plus besoin de se déconnecter ni de recréer le compte).

## Tests
`e2e-connexion-espace.py` 54 OK · `e2e-codes-personnels.py` 15 OK · `check.js` (voir sortie).
