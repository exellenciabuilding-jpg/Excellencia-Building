/* Excellencia Building V175 — Sauvegardes CHIFFRÉES + TEST DE RESTAURATION + objectifs RPO / RTO.
 *  • Un mot de passe de sauvegarde (10 caractères minimum, jamais conservé) → clé AES-GCM 256 dérivée (PBKDF2-SHA256, 250 000 itérations),
 *    gardée NON EXTRACTIBLE dans IndexedDB de cet appareil. Les copies internes automatiques, les fichiers écrits dans le dossier choisi et les
 *    fichiers téléchargés par « Sauvegarde automatique » sont alors chiffrés. Format identique à 🛡 Sécurité & sauvegardes : un fichier se
 *    déchiffre avec le mot de passe (sur n'importe quel appareil) dans « Tester une sauvegarde ».
 *  • Test de restauration : déchiffre, vérifie la somme de contrôle, REJOUE la restauration dans une mémoire temporaire (rien n'est écrit dans
 *    les données réelles), recontrôle l'empreinte et compare avec les données actuelles. Résultat journalisé (sans contenu), durée mesurée = RTO.
 *  • Test automatique de la dernière copie interne au plus toutes les semaines ; rappel si aucun test réussi depuis 30 jours.
 * Réutilise EXBSEC (exb-v81-securite.js) et EXB_ABK (exb-sauvegarde-auto.js). Retrait : supprimer la balise <script src="exb-sauvegarde-chiffree.js">. */
(function (w, d) {
  'use strict';
  if (w.EXB_BKC) return;
  var $ = function (i) { return d.getElementById(i); };
  var DB = 'EXB_BKENC', LT = 'exb_bkc_test', LO = 'exb_bkc_obj', MINPW = 10, ITER = 250000, WEEK = 7 * 864e5, MONTH = 30 * 864e5;
  var enc = new TextEncoder(), dec = new TextDecoder(), subtle = w.crypto && w.crypto.subtle;
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function note(t, k, ms) { try { w.notify ? w.notify(t, k || 'info', ms || 6000) : w.exbAlert(t); } catch (e) {} }
  function lsg(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lss(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function fmt(t) { if (!t) return 'jamais'; var x = new Date(t); return isNaN(x) ? '—' : x.toLocaleDateString('fr-FR') + ' à ' + x.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }); }
  function b64(buf) { var b = new Uint8Array(buf), s = ''; for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s); }
  function unb64(s) { var r = atob(s), u = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) u[i] = r.charCodeAt(i); return u; }
  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function audit(a, o, x) { try { w.EXBCore && w.EXBCore.audit.log(a, o, x); } catch (e) {} }
  function SEC() { return w.EXBSEC && w.EXBSEC._makeBackup ? w.EXBSEC : null; }
  function isEnc(t) { try { var o = JSON.parse(t); return !!(o && o.exb === 'enc'); } catch (e) { return false; } }

  /* ---------- clé conservée (IndexedDB, non extractible) ---------- */
  var dbp = null;
  function idb() {
    if (dbp) return dbp;
    dbp = new Promise(function (ok, ko) { try { var r = indexedDB.open(DB, 1); r.onupgradeneeded = function () { r.result.createObjectStore('kv'); }; r.onsuccess = function () { ok(r.result); }; r.onerror = function () { ko(r.error); }; } catch (e) { ko(e); } });
    return dbp;
  }
  function kv(mode, fn) { return idb().then(function (db) { return new Promise(function (ok, ko) { var t = db.transaction('kv', mode), r = fn(t.objectStore('kv')); t.oncomplete = function () { ok(r && r.result); }; t.onerror = t.onabort = function () { ko(t.error); }; }); }); }
  var cfg = null; /* { salt:b64, iter, key:CryptoKey } */
  function load() { return kv('readonly', function (s) { return s.get('cfg'); }).then(function (c) { cfg = c && c.key ? c : null; return cfg; }).catch(function () { cfg = null; return null; }); }
  async function derive(pass, salt, iter) {
    var mat = await subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']);
    return subtle.deriveKey({ name: 'PBKDF2', salt: salt, iterations: iter, hash: 'SHA-256' }, mat, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function setPassword(pass) {
    if (!subtle) throw new Error('Chiffrement indisponible dans ce navigateur.');
    if (String(pass || '').length < MINPW) throw new Error('Mot de passe trop court (' + MINPW + ' caractères minimum).');
    var salt = w.crypto.getRandomValues(new Uint8Array(16)), key = await derive(pass, salt, ITER);
    var c = { salt: b64(salt), iter: ITER, key: key, at: new Date().toISOString() };
    await kv('readwrite', function (s) { return s.put(c, 'cfg'); }); cfg = c;
    audit('sauvegarde.chiffrement.active', 'sauvegarde', {}); return true;
  }
  async function disable() { await kv('readwrite', function (s) { return s.delete('cfg'); }); cfg = null; audit('sauvegarde.chiffrement.desactive', 'sauvegarde', {}); }
  /* même format que EXBSEC._seal, avec le sel de la clé conservée : déchiffrable par mot de passe */
  async function sealStored(text) {
    var iv = w.crypto.getRandomValues(new Uint8Array(12)), ct = await subtle.encrypt({ name: 'AES-GCM', iv: iv }, cfg.key, enc.encode(text));
    return JSON.stringify({ exb: 'enc', v: 1, alg: 'AES-GCM/PBKDF2-SHA256', iter: cfg.iter, salt: cfg.salt, iv: b64(iv), ct: b64(ct) });
  }
  async function unsealStored(text) {
    var o = JSON.parse(text);
    if (!cfg || o.salt !== cfg.salt || o.iter !== cfg.iter) throw new Error('clé absente');
    var pt = await subtle.decrypt({ name: 'AES-GCM', iv: unb64(o.iv) }, cfg.key, unb64(o.ct)); return dec.decode(pt);
  }

  /* ---------- branchement sur EXBSEC : les sauvegardes sans mot de passe explicite deviennent chiffrées ---------- */
  var warned = false;
  function hook() {
    var S = SEC(); if (!S || S._bkcHooked) return !!(S && S._bkcHooked);
    var mk = S._makeBackup, vf = S._verify;
    S._makeBackup = async function (pass, store) {
      if (pass || !wantEnc()) return mk.call(S, pass, store);
      if (!cfg) { if (!warned) { warned = true; note('Sauvegarde chiffrée activée mais la clé est absente de cet appareil : saisissez à nouveau le mot de passe (💾 → 🔐).', 'warn', 9000); } throw new Error('Clé de chiffrement absente : sauvegarde refusée pour ne pas écrire de copie non chiffrée.'); }
      return sealStored(await mk.call(S, null, store));
    };
    S._verify = async function (text, pass, store) {
      if (!pass && isEnc(text) && cfg) { try { var plain = await unsealStored(text), r = await vf.call(S, plain, null, store); r.encrypted = true; return r; } catch (e) { /* mot de passe requis */ } }
      return vf.call(S, text, pass, store);
    };
    S._bkcHooked = 1; return true;
  }
  function wantEnc() { return lsg('exb_bkc_on') === '1'; }

  /* ---------- test de restauration (aucune écriture dans les données réelles) ---------- */
  function memStore() { var m = {}; return { get length() { return Object.keys(m).length; }, key: function (i) { return Object.keys(m)[i]; }, getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; }, setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; }, clear: function () { m = {}; } }; }
  function rows(v) { try { var x = JSON.parse(v); return Array.isArray(x) ? x.length : (x && typeof x === 'object' ? Object.keys(x).length : 1); } catch (e) { return -1; } }
  async function sha(keys) { return hex(await subtle.digest('SHA-256', enc.encode(JSON.stringify(keys)))); }
  function objectives() { var o = {}; try { o = JSON.parse(lsg(LO) || '{}'); } catch (e) {} return { rpoH: Number(o.rpoH) > 0 ? Number(o.rpoH) : 24, rtoMin: Number(o.rtoMin) > 0 ? Number(o.rtoMin) : 60 }; }
  /** source : texte d'une sauvegarde (chiffrée ou non). pass : mot de passe si le fichier ne vient pas de cet appareil. */
  async function testText(text, pass, label) {
    var S = SEC(); if (!S) throw new Error('Module de sécurité indisponible.');
    hook(); var t0 = Date.now(), res = { at: new Date().toISOString(), source: label || '', ok: false, steps: [], errors: [], rows: [], ms: 0 };
    function step(ok, msg) { res.steps.push({ ok: !!ok, msg: msg }); if (!ok) res.errors.push(msg); return ok; }
    var v = await S._verify(text, pass || null, null);
    res.encrypted = !!v.encrypted; res.backupAt = v.at || '';
    step(true, v.encrypted ? 'Fichier chiffré lu et déchiffré.' : 'Fichier lu (non chiffré).');
    if (!v.ok) { v.errors.forEach(function (e) { step(false, e); }); res.ms = Date.now() - t0; return finish(res); }
    step(true, 'Somme de contrôle correcte (' + v.payload.n + ' éléments).');
    var mem = memStore(), n = S._restoreInto(v.payload, mem);
    step(n === Object.keys(v.payload.keys).length, n + ' éléments rejoués dans une mémoire temporaire.');
    var again = S._collect(mem), s2 = await sha(again);
    step(s2 === v.payload.sum, s2 === v.payload.sum ? 'Données restaurées identiques à la sauvegarde (empreinte SHA-256 recontrôlée).' : 'Les données rejouées ne correspondent pas à l’empreinte de la sauvegarde.');
    var bad = 0; Object.keys(again).forEach(function (k) { if (/^\s*[\[{]/.test(again[k]) && rows(again[k]) < 0) { bad++; step(false, 'Données illisibles : ' + k); } });
    if (!bad) step(true, 'Toutes les collections se relisent correctement.');
    var cur = S._collect(null), diff = [];
    Object.keys(again).forEach(function (k) { var a = rows(again[k]), b = cur[k] != null ? rows(cur[k]) : null; if (a !== b && /^\s*[\[{]/.test(again[k])) diff.push({ key: k, backup: a, current: b }); });
    res.rows = diff.slice(0, 12); res.diffTotal = diff.length; res.n = n;
    res.bytes = text.length; res.ms = Date.now() - t0; return finish(res);
  }
  function finish(res) {
    res.ok = res.errors.length === 0; var o = objectives();
    res.rtoMin = Math.max(res.ms / 60000, 0); res.rtoOk = res.ms / 60000 <= o.rtoMin;
    var age = res.backupAt ? (Date.now() - Date.parse(res.backupAt)) / 36e5 : null; res.ageH = age; res.rpoOk = age != null && age <= o.rpoH;
    lss(LT, JSON.stringify({ at: res.at, ok: res.ok, source: res.source, ms: res.ms, n: res.n || 0, errors: res.errors.slice(0, 3) }));
    audit('sauvegarde.test_restauration', 'sauvegarde', { ok: res.ok, source: res.source, ms: res.ms, elements: res.n || 0, erreurs: res.errors.length });
    return res;
  }
  async function testLatestInternal(silent) {
    var A = w.EXB_ABK; if (!A || !A.snapshots) throw new Error('Sauvegarde automatique indisponible.');
    var all = (await A.snapshots()).filter(function (s) { return s.id !== 'avant-restauration'; });
    if (!all.length) throw new Error('Aucune copie interne à tester : faites d’abord « Sauvegarder maintenant ».');
    var s = all[0], r = await testText(s.text, null, 'copie interne du ' + fmt(s.at));
    if (!silent) render(r); return r;
  }
  async function testFile(file, pass) {
    if (!file) throw new Error('Choisissez un fichier de sauvegarde.');
    var text = await file.text(), r = await testText(text, pass || null, 'fichier ' + String(file.name).slice(0, 60)); render(r); return r;
  }

  /* ---------- écran ---------- */
  var last = null;
  function css() {
    if ($('exbBkcCss')) return; var s = d.createElement('style'); s.id = 'exbBkcCss';
    s.textContent = '#exbBkc{position:fixed;inset:0;z-index:99997;background:#0008;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto}#exbBkc .bx{background:#fff;color:#12254a;border-radius:14px;max-width:660px;width:100%;padding:16px 18px;font:14px/1.45 Arial,sans-serif;box-shadow:0 10px 40px #0006}#exbBkc h2{margin:0 0 6px;font-size:19px}#exbBkc h3{margin:14px 0 6px;font-size:14px}#exbBkc small{color:#5b6b85}#exbBkc .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}#exbBkc button{border:0;border-radius:9px;padding:10px 13px;background:#12254a;color:#fff;font:700 13px Arial;cursor:pointer;min-height:40px}#exbBkc button.s{background:#e3e9f4;color:#12254a}#exbBkc button.r{background:#fee2e2;color:#991b1b}#exbBkc input[type=password],#exbBkc input[type=number]{padding:9px 10px;border:1px solid #9aafc6;border-radius:8px;font:14px Arial;flex:1 1 180px;min-width:0}#exbBkc input[type=number]{flex:0 0 90px}#exbBkc .ok{color:#166534;font-weight:700}#exbBkc .ko{color:#b45309;font-weight:700}#exbBkc .st{padding:3px 0}#exbBkc table{border-collapse:collapse;width:100%;font-size:12px}#exbBkc td,#exbBkc th{border-top:1px solid #e3e9f4;padding:4px;text-align:left}@media print{#exbBkc{display:none!important}}';
    d.head.appendChild(s);
  }
  function box(r) {
    var o = objectives(), t = null; try { t = JSON.parse(lsg(LT) || 'null'); } catch (e) {}
    var on = wantEnc(), age = t && t.ok ? Date.now() - Date.parse(t.at) : null;
    var h = '<div class="row" style="justify-content:space-between"><h2>🔐 Sauvegardes chiffrées &amp; test de restauration</h2><button class="s" data-a="close" aria-label="Fermer">✕</button></div>';
    h += '<h3>1. Chiffrement des sauvegardes</h3><p>' + (on && cfg ? '<span class="ok">✔ Activé</span> — copies internes, dossier de sauvegarde et fichiers téléchargés sont chiffrés (AES-256-GCM).' : on ? '<span class="ko">⚠ Activé mais la clé est absente de cet appareil</span> — ressaisissez le mot de passe.' : '<span class="ko">⚠ Désactivé</span> — les sauvegardes sont lisibles par quiconque obtient le fichier.') + '</p>' +
      '<small><b>Le mot de passe n’est jamais conservé et ne peut pas être retrouvé.</b> Sans lui, un fichier chiffré est définitivement illisible. Notez-le dans un endroit sûr, séparé de la sauvegarde. Changer de mot de passe ne re-chiffre pas les anciennes copies (elles gardent l’ancien mot de passe).</small>' +
      '<div class="row"><input id="bkcPw" type="password" autocomplete="new-password" placeholder="Mot de passe (' + MINPW + ' caractères minimum)"><input id="bkcPw2" type="password" autocomplete="new-password" placeholder="Confirmer"><button data-a="enable">' + (on ? 'Changer le mot de passe' : 'Activer le chiffrement') + '</button>' + (on ? '<button class="s" data-a="disable">Désactiver</button>' : '') + '</div>';
    h += '<h3>2. Test de restauration</h3><small>Le test lit la sauvegarde, la déchiffre, vérifie son empreinte puis <b>rejoue la restauration dans une mémoire temporaire</b> : vos données actuelles ne sont jamais modifiées.</small>' +
      '<p>' + (t ? (t.ok ? '<span class="ok">✔ Dernier test réussi : ' + esc(fmt(t.at)) + '</span>' : '<span class="ko">✖ Dernier test ÉCHOUÉ : ' + esc(fmt(t.at)) + '</span>') + (age != null && age > MONTH ? ' <span class="ko">— plus de 30 jours : refaites un test.</span>' : '') : '<span class="ko">⚠ Aucun test de restauration effectué sur cet appareil.</span>') + '</p>' +
      '<div class="row"><button data-a="tlast">🔍 Tester la dernière copie interne</button></div>' +
      '<div class="row"><input id="bkcFile" type="file" accept=".json,.exbbak" style="flex:1 1 200px"><input id="bkcFp" type="password" autocomplete="off" placeholder="Mot de passe (fichier d’un autre appareil)"><button class="s" data-a="tfile">🔍 Tester ce fichier</button></div><div id="bkcRes">' + (r ? resHtml(r) : '') + '</div>';
    h += '<h3>3. Objectifs de reprise (RPO / RTO)</h3><small><b>RPO</b> = perte de données maximale acceptable (âge de la dernière sauvegarde). <b>RTO</b> = durée maximale acceptable pour reprendre après un incident. Valeurs de départ à ajuster avec votre direction ; le test mesure la durée réelle de la restauration sur cet appareil.</small>' +
      '<div class="row"><label>RPO (heures) <input id="bkcRpo" type="number" min="1" max="720" value="' + o.rpoH + '"></label><label>RTO (minutes) <input id="bkcRto" type="number" min="1" max="1440" value="' + o.rtoMin + '"></label><button class="s" data-a="obj">Enregistrer</button></div>';
    return h;
  }
  function resHtml(r) {
    var o = objectives(), h = '<div style="border:1px solid ' + (r.ok ? '#86efac' : '#fca5a5') + ';background:' + (r.ok ? '#f0fdf4' : '#fef2f2') + ';border-radius:10px;padding:10px;margin-top:6px"><b>' + (r.ok ? '✔ Test réussi — cette sauvegarde est restaurable.' : '✖ Test échoué — NE comptez PAS sur cette sauvegarde.') + '</b> <small>(' + esc(r.source) + ')</small>';
    h += r.steps.map(function (s) { return '<div class="st">' + (s.ok ? '✔' : '✖') + ' ' + esc(s.msg) + '</div>'; }).join('');
    if (r.ok) {
      h += '<div class="st">⏱ Durée de la restauration mesurée : <b>' + (r.ms < 1000 ? r.ms + ' ms' : (r.ms / 1000).toFixed(1).replace('.', ',') + ' s') + '</b> — objectif RTO ' + o.rtoMin + ' min : ' + (r.rtoOk ? '<span class="ok">respecté</span>' : '<span class="ko">dépassé</span>') + ' <small>(durée du test seule : ajoutez le temps de retrouver le fichier et de se reconnecter)</small></div>';
      h += '<div class="st">🕒 Âge de la sauvegarde : <b>' + (r.ageH == null ? '—' : r.ageH < 1 ? 'moins d’1 h' : Math.round(r.ageH) + ' h') + '</b> — objectif RPO ' + o.rpoH + ' h : ' + (r.rpoOk ? '<span class="ok">respecté</span>' : '<span class="ko">dépassé</span>') + '</div>';
      if (r.diffTotal) h += '<div class="st"><small>' + r.diffTotal + ' collection(s) diffèrent des données actuelles (normal si vous avez travaillé depuis) :</small><table><tr><th>Collection</th><th>Sauvegarde</th><th>Actuel</th></tr>' + r.rows.map(function (x) { return '<tr><td>' + esc(x.key) + '</td><td>' + x.backup + '</td><td>' + (x.current == null ? '—' : x.current) + '</td></tr>'; }).join('') + '</table></div>';
    }
    return h + '</div>';
  }
  function render(r) { if (r) last = r; var m = $('exbBkc'); if (!m) return; m.querySelector('.bx').innerHTML = box(last); }
  function open() {
    css(); hook(); var m = $('exbBkc');
    if (!m) { m = d.createElement('div'); m.id = 'exbBkc'; m.className = 'no-print'; m.innerHTML = '<div class="bx"></div>'; m.addEventListener('click', onClick); d.body.appendChild(m); }
    load().then(function () { render(); });
  }
  function onClick(e) {
    var m = $('exbBkc'); if (e.target === m) return m.remove();
    var t = e.target.closest && e.target.closest('[data-a]'); if (!t) return; var a = t.getAttribute('data-a');
    var val = function (i) { return ($(i) || {}).value || ''; };
    if (a === 'close') m.remove();
    else if (a === 'enable') { var p = val('bkcPw'); if (p !== val('bkcPw2')) return note('Les deux mots de passe ne sont pas identiques.', 'warn');
      setPassword(p).then(function () { lss('exb_bkc_on', '1'); warned = false; note('Chiffrement activé. Faites maintenant « Sauvegarder maintenant » puis testez la copie.', 'success', 8000); render(); }).catch(function (x) { note(x.message || String(x), 'warn', 8000); }); }
    else if (a === 'disable') { (w.exbConfirm ? w.exbConfirm('Désactiver le chiffrement ?\n\nLes prochaines sauvegardes ne seront PLUS chiffrées. Les anciennes copies chiffrées restent lisibles avec leur mot de passe.') : Promise.resolve(true)).then(function (ok) { if (!ok) return; return disable().then(function () { lss('exb_bkc_on', '0'); render(); }); }); }
    else if (a === 'tlast') testLatestInternal(false).catch(function (x) { note(x.message || String(x), 'warn', 8000); });
    else if (a === 'tfile') { var f = $('bkcFile') && $('bkcFile').files[0]; testFile(f, val('bkcFp')).catch(function (x) { note(x.message || String(x), 'warn', 8000); }); }
    else if (a === 'obj') { lss(LO, JSON.stringify({ rpoH: Number(val('bkcRpo')) || 24, rtoMin: Number(val('bkcRto')) || 60 })); audit('sauvegarde.objectifs', 'sauvegarde', objectives()); render(); }
  }
  function mountBtn() {
    var st = $('exbStatus'); if (!st || $('exbBkcBtn')) return;
    var s = d.createElement('button'); s.id = 'exbBkcBtn'; s.type = 'button'; s.className = 'no-print'; s.textContent = '🔐 Test restauration';
    s.style.cssText = 'border:0;background:transparent;color:inherit;font:inherit;font-weight:700;cursor:pointer;text-decoration:underline;padding:0 6px;margin:0;min-height:0;line-height:inherit;white-space:nowrap'; s.onclick = open; st.insertBefore(s, st.children[3] || null);
  }
  /* test automatique hebdomadaire de la dernière copie interne (hors saisie), rappel mensuel */
  function tick() {
    mountBtn(); hook();
    try {
      if (d.visibilityState === 'hidden') return;
      var t = null; try { t = JSON.parse(lsg(LT) || 'null'); } catch (e) {}
      var due = !t || Date.now() - Date.parse(t.at) > WEEK;
      if (due && w.EXB_ABK && !tick.busy && !$('exbBkc')) {
        tick.busy = 1;
        load().then(function () { return w.EXB_ABK.snapshots(); }).then(function (all) {
          all = (all || []).filter(function (s) { return s.id !== 'avant-restauration'; }); if (!all.length) return;
          return testText(all[0].text, null, 'test automatique — copie interne du ' + fmt(all[0].at)).then(function (r) { if (!r.ok) note('⚠ Test automatique de restauration ÉCHOUÉ : ouvrez 🔐 Test restauration.', 'error', 12000); });
        }).catch(function () {}).then(function () { tick.busy = 0; });
      } else if (t && t.ok && Date.now() - Date.parse(t.at) > MONTH && !tick.warnedOld) { tick.warnedOld = 1; note('Aucun test de restauration réussi depuis plus de 30 jours : 🔐 Test restauration.', 'warn', 9000); }
    } catch (e) {}
  }
  w.EXB_BKC = { open: open, test: testText, testLatest: testLatestInternal, testFile: testFile, setPassword: function (p) { return setPassword(p).then(function () { lss('exb_bkc_on', '1'); }); }, disable: function () { return disable().then(function () { lss('exb_bkc_on', '0'); }); }, objectives: objectives, version: 'V175', _sealStored: function (t) { return sealStored(t); }, _hook: hook, _load: load };
  function start() { load().then(function () { hook(); }); setTimeout(tick, 15000); setInterval(tick, 10 * 60 * 1000); setInterval(mountBtn, 2500); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
