/* Excellencia Building — BUREAU D'ÉTUDES · LOT P2 V208 (cahier des charges V1.0, §5.1, priorité P2)
 * S'ajoute au dossier d'étude V207 (exb-be-dossier.js) sans le modifier. Trois fonctions :
 *   1. GÉOTECHNIQUE        : rapports de sol (sondages, couches, essais, nappe), portance (Vesic, sans facteurs de profondeur → prudent),
 *                            tassement (consolidation par tranches, répartition 2:1 + élastique), recommandations, visa (vérificateur ≠ auteur).
 *                            Calcul d'ORIENTATION déterministe : il ne remplace ni la mission G2 ni l'avis du géotechnicien.
 *   2. QUANTITATIF STRUCTURE : béton (m³), coffrage (m²), acier par diamètre (kg), chutes, ratios — lus dans les notes de calcul du dossier
 *                            (poteaux, semelles, poutres), nombre d'éléments identiques, versions figées, rapprochement avec le métré saisi.
 *   3. COORDINATION BIM    : lien élément calculé ↔ objet IFC (GlobalId) ↔ observations BCF ; alerte « à réexaminer » si l'élément a changé
 *                            depuis le lien (tâche d'analyse d'impact — jamais de recalcul ni de ré-émission automatique).
 * Garde-fou : aucune IA, aucune validation automatique. Les moteurs sont déterministes et testés (site/calcul-structure/test-be-p2.js).
 * Données : clés exb_be_geo, exb_be_quant, exb_be_bimlink. Pour retirer : supprimer la balise <script src="exb-be-p2.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBBeP2) return;
  var KG = 'exb_be_geo', KQ = 'exb_be_quant', KL = 'exb_be_bimlink', GW = 9.81;
  var STG = ['Brouillon', 'Vérifié', 'Visé'];

  /* ------------------------------------------------------------ outils ------------------------------------------------------------ */
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function num(v, def) { var n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : (def === undefined ? 0 : def); }
  function fx(v, n) { return isFinite(v) ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: n, maximumFractionDigits: n }) : '—'; }
  function fdate(t) { try { return new Date(t).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return String(t || ''); } }
  function hash(s) { s = String(s); var h1 = 0xdeadbeef, h2 = 0x41c6ce57; for (var i = 0, c; i < s.length; i++) { c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); } h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909); h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909); return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16); }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function norm(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id) }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function infoDB() { try { return w.EXBDB && w.EXBDB.info ? w.EXBDB.info() : null; } catch (e) { return null; } }
  function habilite() { var i = infoDB(); if (!i || !i.on) return true; return i.role === 'admin' || i.fonction === 'bureau_etudes'; }
  function san(t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/γ/g, 'gamma ').replace(/φ/g, 'phi ').replace(/σ/g, 'sigma ').replace(/Δ/g, 'delta ').replace(/→/g, '->').replace(/²/g, '2').replace(/³/g, '3').replace(/×/g, 'x'); }
  function dossiers() { try { return w.EXBBeD && w.EXBBeD.all ? w.EXBBeD.all() : []; } catch (e) { return []; } }
  function notesAll() { return rd('exb_calc_notes'); }
  function calcNote(n) { try { return w.EXBET && w.EXBET.calcNote ? w.EXBET.calcNote(n) : null; } catch (e) { return null; } }
  function csv(rows, name) { var t = '\ufeff' + rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); try { var b = new Blob([t], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(a.href); }, 500); } catch (e) { toast('Export impossible : ' + e.message, 'error'); } }
  function pdf(o) { if (!w.EXBPdf) return toast('Module PDF indisponible.', 'error'); try { var p = w.EXBPdf.make(w.EXBENT && w.EXBENT.piece ? w.EXBENT.piece(o) : o); return Promise.resolve(p).then(function (b) { if (b && b.size && w.EXBPdf.save) { w.EXBPdf.save(b, String((o && (o.sousTitre || o.titre)) || 'rapport').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) + '.pdf'); toast('PDF généré.', 'success'); } return b; }, function (e) { toast('PDF impossible : ' + (e && e.message || e), 'error'); }); } catch (e) { toast('PDF impossible : ' + e.message, 'error'); } }

  /* ========================================================== 1. GÉOTECHNIQUE (moteurs) ========================================================== */
  /* Facteurs de portance : Prandtl/Reissner (Nq, Nc) et Vesic (Ngamma = 2 (Nq+1) tan phi). phi en degrés. */
  function facteurs(phi) {
    var p = phi * Math.PI / 180, t = Math.tan(p);
    var Nq = Math.exp(Math.PI * t) * Math.pow(Math.tan(Math.PI / 4 + p / 2), 2);
    var Nc = phi > 0.0001 ? (Nq - 1) / t : 5.14159265358979;
    var Ng = 2 * (Nq + 1) * t;
    return { Nq: Nq, Nc: Nc, Ng: Ng };
  }
  /* Contrainte verticale effective (kPa) à la profondeur z (m) : gamma = poids volumique humide au-dessus de la nappe, saturé en dessous. */
  function sigmaV(couches, nappe, z) {
    var s = 0, u = 0, hasN = isFinite(nappe) && nappe !== null && nappe !== '';
    (couches || []).forEach(function (c) {
      var de = num(c.de), a = num(c.a), g = num(c.gamma);
      if (z <= de) return;
      var bas = Math.min(a, z), h = bas - de; if (h <= 0) return;
      if (hasN && num(nappe) < bas) {
        var hs = Math.max(0, bas - Math.max(de, num(nappe))), hh = h - hs;
        s += g * hh + (g - GW) * hs;
      } else s += g * h;
    });
    return s;
  }
  /* Portance (Vesic sans facteurs de profondeur ni d'inclinaison). Entrées en m, kPa, kN/m³. Sorties kPa. */
  function portance(p) {
    var phi = num(p.phi), c = num(p.c), B = num(p.B), L = Math.max(num(p.L, num(p.B)), B), Df = num(p.Df), F = num(p.F, 3), g = num(p.gamma);
    var q0 = num(p.q0, g * Df);
    var f = facteurs(phi), r = L > 0 ? B / L : 1, t = Math.tan(phi * Math.PI / 180);
    var sc = 1 + r * (f.Nq / f.Nc), sq = 1 + r * t, sg = Math.max(0.6, 1 - 0.4 * r);
    var gEff = num(p.gammaEff, g);
    var qu = c * f.Nc * sc + q0 * f.Nq * sq + 0.5 * gEff * B * f.Ng * sg;
    var qnet = qu - q0;
    return { Nq: f.Nq, Nc: f.Nc, Ng: f.Ng, sc: sc, sq: sq, sg: sg, q0: q0, qu: qu, qnet: qnet, qadmNet: qnet / F, qadm: qnet / F + q0, F: F };
  }
  /* Tassement de consolidation d'UNE tranche (m) : sigma0, dsig, sigp en kPa ; sigp = pression de préconsolidation (vide = normalement consolidé). */
  function tassTranche(t) {
    var H = num(t.H), e0 = num(t.e0), Cc = num(t.Cc), Cr = num(t.Cr, Cc / 6), s0 = num(t.s0), ds = num(t.ds), sp = num(t.sp, 0);
    if (!(H > 0 && e0 > -0.5 && Cc > 0 && s0 > 0 && ds > 0)) return 0;
    var k = H / (1 + e0), sf = s0 + ds;
    if (!(sp > s0)) return k * Cc * Math.log10(sf / s0);
    if (sf <= sp) return k * Cr * Math.log10(sf / s0);
    return k * (Cr * Math.log10(sp / s0) + Cc * Math.log10(sf / sp));
  }
  /* Tassement total (m) sous une semelle B × L chargée de qnet (kPa) à la profondeur Df, couches [{de,a,gamma,e0,Cc,Cr,sp,E,nu}], nappe (m ou ''). */
  function tassement(p) {
    var B = num(p.B), L = Math.max(num(p.L, B), B), Df = num(p.Df), q = num(p.q), zinf = num(p.zinf, 2) * B, pas = num(p.pas, 1), nap = p.nappe;
    var cs = p.couches || [], det = [], sc = 0, i;
    cs.forEach(function (c, ci) {
      var de = Math.max(num(c.de), Df), a = Math.min(num(c.a), Df + zinf);
      if (!(num(c.Cc) > 0) || !(a > de)) return;
      var n = Math.max(1, Math.ceil((a - de) / pas)), h = (a - de) / n;
      for (i = 0; i < n; i++) {
        var zm = de + h * (i + 0.5), zb = zm - Df;
        var ds = q * B * L / ((B + zb) * (L + zb)); /* répartition 2:1 */
        var s0 = sigmaV(cs, nap, zm), s = tassTranche({ H: h, e0: c.e0, Cc: c.Cc, Cr: c.Cr, s0: s0, ds: ds, sp: c.sp });
        sc += s; det.push({ couche: ci, z: zm, ds: ds, s0: s0, s: s });
      }
    });
    var c1 = cs.filter(function (c) { return num(c.E) > 0 && num(c.a) > Df; })[0], si = 0;
    if (c1) si = q * B * (1 - Math.pow(num(c1.nu, 0.3), 2)) * num(p.Iw, 0.82) / num(c1.E);
    return { consolidation: sc, immediat: si, total: sc + si, tranches: det };
  }
  function geoCalc(r) {
    var o = { ok: false, msgs: [] }, S = (r.sondages || [])[num(r.sondRef, 0)], F = r.fond || {};
    if (!S) { o.msgs.push('Aucun sondage de référence.'); return o; }
    var B = num(F.B), Df = num(F.Df);
    if (!(B > 0)) { o.msgs.push('Largeur B de la fondation à renseigner.'); return o; }
    var cs = S.couches || [], nap = S.nappe === '' || S.nappe == null ? '' : num(S.nappe);
    var cb = cs.filter(function (c) { return num(c.de) <= Df && Df < num(c.a); })[0] || cs.filter(function (c) { return num(c.a) > Df; })[0];
    if (!cb) { o.msgs.push('Aucune couche ne contient le niveau d’assise (Df = ' + Df + ' m).'); return o; }
    var q0 = sigmaV(cs, nap, Df), gEff = num(cb.gamma);
    if (nap !== '' && nap <= Df) gEff = num(cb.gamma) - GW; else if (nap !== '' && nap < Df + B) gEff = num(cb.gamma) - GW * (1 - (nap - Df) / B);
    o.port = portance({ phi: cb.phi, c: cb.c, B: B, L: F.L, Df: Df, F: F.F, gamma: cb.gamma, gammaEff: gEff, q0: q0 });
    o.couche = cb;
    o.tass = tassement({ B: B, L: F.L, Df: Df, q: F.q, couches: cs, nappe: nap, zinf: F.zinf, Iw: F.Iw });
    o.ok = true; return o;
  }
  function geoVerif(r) {
    var a = [], S = (r.sondages || [])[num(r.sondRef, 0)], F = r.fond || {}, add = function (n, id, m) { a.push({ niveau: n, id: id, msg: m }); };
    if (!(r.sondages || []).length) add('bloquant', 'GEO-1', 'Aucun sondage enregistré : un rapport de sol sans reconnaissance ne peut pas être visé.');
    (r.sondages || []).forEach(function (s, i) {
      var nom = s.nom || 'Sondage ' + (i + 1);
      if (!(num(s.prof) > 0)) add('bloquant', 'GEO-2', nom + ' : profondeur non renseignée.');
      var cs = s.couches || [], prev = 0;
      if (!cs.length) add('alerte', 'GEO-3', nom + ' : aucune couche décrite.');
      cs.forEach(function (c, j) {
        if (!(num(c.a) > num(c.de))) add('bloquant', 'GEO-4', nom + ' couche ' + (j + 1) + ' : base ≤ toit.');
        if (j > 0 && Math.abs(num(c.de) - prev) > 0.001) add('alerte', 'GEO-5', nom + ' couche ' + (j + 1) + ' : discontinuité de profondeur (' + fx(prev, 2) + ' → ' + fx(num(c.de), 2) + ' m).');
        if (!String(c.nature || '').trim()) add('alerte', 'GEO-6', nom + ' couche ' + (j + 1) + ' : nature du sol non décrite.');
        if (!(num(c.gamma) > 0)) add('alerte', 'GEO-7', nom + ' couche ' + (j + 1) + ' : poids volumique manquant.');
        prev = num(c.a);
      });
      if (cs.length && prev > 0 && num(s.prof) > 0 && Math.abs(prev - num(s.prof)) > 0.001) add('alerte', 'GEO-8', nom + ' : la dernière couche s’arrête à ' + fx(prev, 2) + ' m mais la profondeur du sondage est ' + fx(num(s.prof), 2) + ' m.');
      (s.essais || []).forEach(function (e, j) { if (!String(e.unite || '').trim() || e.valeur === '' || e.valeur == null) add('alerte', 'GEO-9', nom + ' essai ' + (j + 1) + ' : valeur ou unité manquante.'); });
      if (s.nappe === '' || s.nappe == null) add('alerte', 'GEO-10', nom + ' : niveau de nappe non renseigné (indiquer « absente » en observation si c’est le cas).');
    });
    if (S) {
      var B = num(F.B), Df = num(F.Df);
      if (B > 0 && num(S.prof) > 0 && num(S.prof) < Df + 1.5 * B) add('alerte', 'GEO-11', 'Reconnaissance (' + fx(num(S.prof), 1) + ' m) inférieure à Df + 1,5 B = ' + fx(Df + 1.5 * B, 1) + ' m : justifier la profondeur d’investigation.');
      if (S.nappe !== '' && S.nappe != null && B > 0 && num(S.nappe) < Df + B) add('alerte', 'GEO-12', 'Nappe à ' + fx(num(S.nappe), 2) + ' m : dans la zone d’influence de la fondation (portance et tassement affectés).');
      if (num(F.F, 3) < 2.5) add('alerte', 'GEO-13', 'Coefficient de sécurité F = ' + fx(num(F.F, 3), 1) + ' inférieur à 2,5 : à justifier par la norme choisie.');
      var c = geoCalc(r);
      if (!c.ok) c.msgs.forEach(function (m) { add('alerte', 'GEO-14', 'Calcul non réalisé : ' + m); });
      else {
        var cb = c.couche;
        if (!(num(cb.phi) > 0 || num(cb.c) > 0)) add('bloquant', 'GEO-15', 'Couche d’assise : ni cohésion ni angle de frottement renseigné, portance non calculable.');
        if (num(F.q) > c.port.qadmNet) add('bloquant', 'GEO-16', 'Charge nette appliquée ' + fx(num(F.q), 0) + ' kPa > contrainte admissible nette ' + fx(c.port.qadmNet, 0) + ' kPa.');
        if (num(F.limite) > 0 && c.tass.total * 1000 > num(F.limite)) add('bloquant', 'GEO-17', 'Tassement calculé ' + fx(c.tass.total * 1000, 0) + ' mm > limite fixée ' + fx(num(F.limite), 0) + ' mm.');
        if (!(num(F.limite) > 0)) add('alerte', 'GEO-18', 'Aucune limite de tassement fixée : à définir avec l’ingénieur de structure.');
        if (!(c.tass.consolidation > 0) && !(c.tass.immediat > 0)) add('alerte', 'GEO-19', 'Aucune donnée de compressibilité (e0, Cc ou E) : tassement non évalué.');
      }
    }
    if (!(r.reco || []).length) add('alerte', 'GEO-20', 'Aucune recommandation rédigée.');
    return a;
  }

  /* ========================================================== 2. QUANTITATIF STRUCTURE (moteur) ========================================================== */
  var KGM = function (d, rho) { return Math.PI * d * d / 4e6 * rho; }; /* kg/m pour un diamètre en mm */
  function quantElement(e, out, n, P) {
    var c = num(n.enr, 3) / 100, rho = num(P.densite, 7850), v = e.v || {}, o = out || {}, q = { nom: e.name, type: e.type, ok: false, beton: 0, coffrage: 0, acier: {}, remarque: '' };
    var add = function (d, len) { if (!(d > 0 && len > 0)) return; q.acier[d] = (q.acier[d] || 0) + len * KGM(d, rho); };
    var anc = num(P.ancrage, 40), hook = num(P.crochet, 20);
    if (e.type === 'col') {
      var circ = v.forme === 'circulaire', a = num(v.a) / 100, b = circ ? a : num(v.b) / 100, l0 = num(v.l0); if (l0 > 0 && l0 <= 15) l0 *= 100; l0 /= 100;
      if (!(a > 0 && b > 0 && l0 > 0)) { q.remarque = 'Dimensions incomplètes.'; return q; }
      if (!(o.n > 0)) { q.remarque = 'Armatures non calculées dans la note.'; }
      q.beton = (circ ? Math.PI * a * a / 4 : a * b) * l0; q.coffrage = (circ ? Math.PI * a : 2 * (a + b)) * l0;
      if (o.n > 0) {
        add(o.d, o.n * (l0 + anc * o.d / 1000));
        var per = circ ? Math.PI * (a - 2 * c) : 2 * ((a - 2 * c) + (b - 2 * c)), nb = Math.ceil(l0 * 100 / (o.st || 15)) + 1;
        add(o.ph, nb * (per + hook * o.ph / 1000));
      }
      q.ok = o.n > 0;
    } else if (e.type === 'foot') {
      if (!(o.B > 0 && o.A > 0 && o.h > 0)) { q.remarque = 'Semelle non dimensionnée dans la note.'; return q; }
      var B = o.B / 100, A = o.A / 100, h = o.h / 100;
      q.beton = B * A * h; q.coffrage = 2 * (B + A) * h;
      if (o.X && o.Y) { add(o.X.d, o.X.n * (B - 2 * c + hook * o.X.d / 1000)); add(o.Y.d, o.Y.n * (A - 2 * c + hook * o.Y.d / 1000)); q.ok = true; }
    } else if (e.type === 'beam') {
      var T = v.type === 'té', bb = num(v.b) / 100, b0 = T ? num(v.b0) / 100 : bb, hh = num(v.h) / 100, h0 = num(v.h0) / 100, L = num(v.L);
      if (!(bb > 0 && hh > 0 && L > 0)) { q.remarque = 'Dimensions incomplètes.'; return q; }
      q.beton = (T ? b0 * hh + (bb - b0) * h0 : bb * hh) * L; q.coffrage = (bb + 2 * hh) * L;
      if (o.n > 0) {
        add(o.d, o.n * (L + anc * o.d / 1000));
        var pc = 2 * ((b0 - 2 * c) + (hh - 2 * c)), nc = Math.ceil(L * 100 / (o.st || 15)) + 1;
        add(o.dt, nc * (pc + hook * o.dt / 1000));
        q.remarque = 'Cadres comptés au premier espacement (majorant) ; chapeaux, arrêts de barres et moments sur appuis non calculés dans la note.';
        q.ok = true;
      } else q.remarque = 'Armatures non calculées dans la note.';
    } else { q.remarque = 'Élément sans quantité (descente de charges).'; q.ok = true; }
    return q;
  }
  function quantifier(dos, rec) {
    var P = rec.params || {}, lignes = [], tot = { beton: 0, coffrage: 0, acier: {} }, avert = [], nbm = rec.nb || {};
    (dos.notes || []).forEach(function (nid) {
      var n = notesAll().filter(function (z) { return z.id === nid; })[0]; if (!n) { avert.push('Note ' + nid + ' introuvable.'); return; }
      var res = calcNote(n) || [];
      (n.els || []).forEach(function (e, i) {
        if (e.type === 'dc') return;
        var q = quantElement(e, (res[i] || {}).out, n, P), k = nid + ':' + e.id, m = Math.max(0, num(nbm[k], 1));
        q.note = n.no || n.title || nid; q.key = k; q.nb = m; lignes.push(q);
        tot.beton += q.beton * m; tot.coffrage += q.coffrage * m;
        Object.keys(q.acier).forEach(function (dd) { tot.acier[dd] = (tot.acier[dd] || 0) + q.acier[dd] * m; });
        if (!q.ok) avert.push(q.note + ' · ' + q.nom + ' : ' + q.remarque);
      });
    });
    /* V209 : dalles et escaliers du dossier (exb-be-dalles.js) */
    try { if (w.EXBBeDal && w.EXBBeDal.forDossier && dos.id) w.EXBBeDal.forDossier(dos.id).forEach(function (r) {
      var q = w.EXBBeDal.quant(r, P), k = 'DS:' + r.id, m = Math.max(0, num(nbm[k] != null ? nbm[k] : r.nb, 1));
      q.note = r.type === 'escalier' ? 'Escaliers' : 'Dalles'; q.key = k; q.nb = m; lignes.push(q);
      tot.beton += q.beton * m; tot.coffrage += q.coffrage * m;
      Object.keys(q.acier).forEach(function (dd) { tot.acier[dd] = (tot.acier[dd] || 0) + q.acier[dd] * m; });
      if (!q.ok) avert.push(q.note + ' · ' + q.nom + ' : ' + q.remarque);
    }); } catch (e) {}
    var net = 0; Object.keys(tot.acier).forEach(function (k) { net += tot.acier[k]; });
    var pertes = num(P.pertes, 5), brut = net * (1 + pertes / 100);
    var ratio = tot.beton > 0 ? net / tot.beton : 0;
    if (tot.beton > 0 && net > 0 && (ratio < 40 || ratio > 250)) avert.push('Ratio acier / béton = ' + fx(ratio, 0) + ' kg/m³ : hors de la plage usuelle indicative 40–250 kg/m³ pour l’ensemble ; vérifier les notes et les nombres d’éléments.');
    return { lignes: lignes, beton: tot.beton, coffrage: tot.coffrage, acierDiam: tot.acier, acierNet: net, acierBrut: brut, pertes: pertes, ratio: ratio, avert: avert };
  }
  function rapproche(qt, m) {
    var tol = num(m.tol, 5), rows = [];
    [['Béton', qt.beton, m.beton, 'm³', 'beton'], ['Coffrage', qt.coffrage, m.coffrage, 'm²', 'coffrage'], ['Acier (brut)', qt.acierBrut, m.acier, 'kg', 'acier']].forEach(function (r) {
      var ref = (m[r[4]] === '' || m[r[4]] == null) ? null : num(r[2]);
      var ec = ref && ref > 0 ? (r[1] - ref) / ref * 100 : null;
      rows.push({ nom: r[0], calc: r[1], metre: ref, unite: r[3], ecart: ec, statut: ref == null ? 'Métré non saisi' : (ref <= 0 ? 'Métré nul' : (Math.abs(ec) <= tol ? 'Conforme' : ((m.justif || {})[r[4]] ? 'Justifié' : 'Écart à justifier'))), k: r[4] });
    });
    return rows;
  }

  /* ========================================================== 3. COORDINATION BIM (règles) ========================================================== */
  var RGUID = /^[0-9A-Za-z_$]{22}$/;
  function elemEmpreinte(nid, eid) {
    var n = notesAll().filter(function (z) { return z.id === nid; })[0]; if (!n) return '';
    var i = (n.els || []).findIndex(function (e) { return e.id === eid; }); if (i < 0) return '';
    var res = calcNote(n) || [];
    return hash(JSON.stringify({ e: n.els[i], fc: n.fc, fe: n.fe, enr: n.enr, r: (res[i] || {}).out || {} }));
  }
  function issuesBim() { try { return w.EXB_ARCH && w.EXB_ARCH.bimRows ? w.EXB_ARCH.bimRows() : []; } catch (e) { return []; } }
  function modelesBim() { try { return w.EXB_ARCH && w.EXB_ARCH.bimModels ? w.EXB_ARCH.bimModels() : []; } catch (e) { return []; } }
  function coordEtat(dos) {
    var liens = rd(KL).filter(function (l) { return l.dossier_id === dos.id; }), iss = issuesBim(), els = [], al = [], guids = {};
    (dos.notes || []).forEach(function (nid) { var n = notesAll().filter(function (z) { return z.id === nid; })[0]; if (n) (n.els || []).forEach(function (e) { if (e.type !== 'dc') els.push({ nid: nid, eid: e.id, nom: e.name, note: n.no || n.title || nid, type: e.type }); }); });
    liens.forEach(function (l) { if (l.guid) { (guids[l.guid] = guids[l.guid] || []).push(l); } });
    var rows = els.map(function (e) {
      var ls = liens.filter(function (l) { return l.nid === e.nid && l.eid === e.eid; }), emp = elemEmpreinte(e.nid, e.eid);
      var r = { el: e, liens: ls.map(function (l) {
        var li = iss.filter(function (x) { return x.guid && x.guid === l.guid; }), stale = !!l.emp && l.emp !== emp, st = stale ? 'À réexaminer' : (l.confirme ? 'Confirmé' : 'À confirmer');
        if (!RGUID.test(l.guid || '')) al.push({ niveau: 'bloquant', id: 'BIM-1', msg: e.note + ' · ' + e.nom + ' : GlobalId IFC invalide (22 caractères attendus).' });
        if ((guids[l.guid] || []).length > 1) al.push({ niveau: 'alerte', id: 'BIM-2', msg: 'GlobalId ' + l.guid + ' associé à plusieurs éléments calculés.' });
        if (!l.model) al.push({ niveau: 'alerte', id: 'BIM-3', msg: e.note + ' · ' + e.nom + ' : modèle IFC non précisé.' });
        if (stale) al.push({ niveau: 'alerte', id: 'BIM-4', msg: e.note + ' · ' + e.nom + ' : l’élément a changé depuis le lien — analyse d’impact à faire (structure, quantités, coûts, planning) ; aucun recalcul ni ré-émission automatique.' });
        li.filter(function (x) { return x.status !== 'Clôturé' && (x.priority === 'Critique' || x.priority === 'Haute'); }).forEach(function (x) { al.push({ niveau: 'alerte', id: 'BIM-5', msg: e.note + ' · ' + e.nom + ' : observation BCF ' + x.priority.toLowerCase() + ' ouverte — « ' + x.title + ' ».' }); });
        return { l: l, issues: li, etat: st, stale: stale };
      }), emp: emp };
      if (!ls.length) al.push({ niveau: 'alerte', id: 'BIM-6', msg: e.note + ' · ' + e.nom + ' : aucun objet IFC associé.' });
      return r;
    });
    return { rows: rows, alertes: al };
  }

  /* ========================================================== données / UI ========================================================== */
  var TAB = 'geo', DOS = '', GID = '', O = null;
  function geoAll() { return rd(KG); } function geoGet(id) { return geoAll().filter(function (x) { return x.id === id; })[0] || null; }
  function geoPut(x) { var a = geoAll(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i >= 0) a[i] = x; else a.push(x); return wr(KG, a); }
  function geoNew() { var n = geoAll().length + 1, y = new Date().getFullYear(); return { id: uid('GEO'), no: 'RS-' + y + '-' + String(n).padStart(3, '0'), statut: 'Brouillon', titre: '', project_id: '', dossier_id: '', site: '', date: new Date().toISOString().slice(0, 10), geotechnicien: '', auteur: '', sondages: [], sondRef: 0, fond: { B: '', L: '', Df: '', q: '', F: 3, Iw: 0.82, zinf: 2, limite: '' }, reco: [], histo: [], cree: Date.now() }; }
  function geoRo(r) { return r.statut === 'Visé'; }
  function qrec(did) { var a = rd(KQ), r = a.filter(function (x) { return x.dossier_id === did; })[0]; if (!r) { r = { id: uid('QT'), dossier_id: did, params: { ancrage: 40, crochet: 20, pertes: 5, densite: 7850 }, nb: {}, metre: { beton: '', coffrage: '', acier: '', source: '', tol: 5, justif: {} }, versions: [] }; } return r; }
  function qput(r) { var a = rd(KQ), i = a.findIndex(function (y) { return y.id === r.id; }); if (i >= 0) a[i] = r; else a.push(r); return wr(KQ, a); }
  function setPath(o, path, v) { var p = path.split('.'), k; for (var i = 0; i < p.length - 1; i++) { k = /^\d+$/.test(p[i]) ? +p[i] : p[i]; if (o[k] == null) o[k] = /^\d+$/.test(p[i + 1]) ? [] : {}; o = o[k]; } k = /^\d+$/.test(p[p.length - 1]) ? +p[p.length - 1] : p[p.length - 1]; o[k] = v; }
  function box() { return d.getElementById('exbBeP2Box'); }
  function inp(path, v, o) { o = o || {}; return '<input data-f="' + esc(path) + '"' + (o.n ? ' data-n="1" inputmode="decimal"' : '') + (o.type ? ' type="' + o.type + '"' : '') + ' value="' + esc(v) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.dis ? ' disabled' : '') + ' style="width:' + (o.w || '100%') + ';padding:6px;border:1px solid #cbd5e1;border-radius:8px;box-sizing:border-box">'; }
  function lab(t, h) { return '<label style="display:block;font-size:12px;color:#475569;margin:6px 0 2px">' + t + '</label>' + h; }
  function btn(t, a, i, cl) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + i + '"' : '') + ' style="padding:7px 11px;border:0;border-radius:8px;background:' + (cl || '#0f766e') + ';color:#fff;margin:3px 3px 3px 0;font-size:13px">' + t + '</button>'; }
  function alertesHtml(a) {
    if (!a.length) return '<p style="color:#047857">✔ Aucune alerte de contrôle. Cela ne vaut pas validation : le visa reste une décision de l’ingénieur.</p>';
    return a.map(function (x) { return '<div style="padding:6px 8px;margin:4px 0;border-radius:8px;font-size:13px;background:' + (x.niveau === 'bloquant' ? '#fee2e2' : '#fef3c7') + '">' + (x.niveau === 'bloquant' ? '⛔ ' : '⚠️ ') + '<b>' + x.id + '</b> — ' + esc(x.msg) + '</div>'; }).join('');
  }
  function table(h, rows) { return '<div style="overflow:auto"><table style="border-collapse:collapse;width:100%;font-size:12.5px"><thead><tr>' + h.map(function (t) { return '<th style="text-align:left;padding:5px;border-bottom:2px solid #e2e8f0;white-space:nowrap">' + t + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="padding:4px 5px;border-bottom:1px solid #f1f5f9;vertical-align:top">' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>'; }

  function geoHtml() {
    var all = geoAll();
    if (!GID) {
      return '<h3 style="margin:6px 0">🪨 Rapports de sol</h3><p style="font-size:12.5px;color:#475569">Sondages, essais, nappe, portance, tassement et recommandations. Calcul d’orientation (Vesic, consolidation 2:1) : il ne remplace pas la mission géotechnique ni l’avis du géotechnicien.</p>' + btn('➕ Nouveau rapport de sol', 'gnew') + (all.length ? table(['N°', 'Titre', 'Projet', 'Statut', ''], all.map(function (r) { return [esc(r.no), esc(r.titre || '—'), esc(pnom(r.project_id)), esc(r.statut), btn('Ouvrir', 'gopen', r.id)]; })) : '<p>Aucun rapport.</p>');
    }
    var r = geoGet(GID); if (!r) { GID = ''; return geoHtml(); }
    var ro = geoRo(r), dis = { dis: ro }, ps = projets(), S = (r.sondages || [])[num(r.sondRef, 0)];
    var h = '<div>' + btn('← Liste', 'gback', null, '#475569') + ' <b>' + esc(r.no) + '</b> · ' + esc(r.statut) + (ro ? ' · 🔒 verrouillé après visa' : '') + '</div>';
    h += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px">' + lab('Titre', inp('titre', r.titre, dis)) + lab('Projet', '<select data-f="project_id"' + (ro ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="">—</option>' + ps.map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === r.project_id ? ' selected' : '') + '>' + esc(p.nom) + '</option>'; }).join('') + '</select>') + lab('Site / parcelle', inp('site', r.site, dis)) + lab('Date', inp('date', r.date, { type: 'date', dis: ro })) + lab('Géotechnicien / entreprise de sondage', inp('geotechnicien', r.geotechnicien, dis)) + lab('Auteur du rapport (obligatoire avant vérification)', inp('auteur', r.auteur, dis)) + '</div>';
    h += '<h4 style="margin:12px 0 4px">Sondages</h4>';
    (r.sondages || []).forEach(function (s, i) {
      var p = 'sondages.' + i;
      h += '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin:6px 0"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:6px">' + lab('Nom', inp(p + '.nom', s.nom, dis)) + lab('Type (SPT, pénétro, puits…)', inp(p + '.type', s.type, dis)) + lab('Profondeur (m)', inp(p + '.prof', s.prof, { n: 1, dis: ro })) + lab('Nappe (m, vide = non vue)', inp(p + '.nappe', s.nappe, { n: 1, dis: ro })) + '</div>';
      h += '<b style="font-size:12px">Couches</b>' + table(['De (m)', 'À (m)', 'Nature', 'γ kN/m³', 'c kPa', 'φ °', 'e0', 'Cc', 'Cr', 'σp kPa', 'E kPa', 'ν', ''], (s.couches || []).map(function (c, j) { var q = p + '.couches.' + j; return [inp(q + '.de', c.de, { n: 1, w: '54px', dis: ro }), inp(q + '.a', c.a, { n: 1, w: '54px', dis: ro }), inp(q + '.nature', c.nature, { w: '110px', dis: ro }), inp(q + '.gamma', c.gamma, { n: 1, w: '52px', dis: ro }), inp(q + '.c', c.c, { n: 1, w: '48px', dis: ro }), inp(q + '.phi', c.phi, { n: 1, w: '44px', dis: ro }), inp(q + '.e0', c.e0, { n: 1, w: '44px', dis: ro }), inp(q + '.Cc', c.Cc, { n: 1, w: '44px', dis: ro }), inp(q + '.Cr', c.Cr, { n: 1, w: '44px', dis: ro }), inp(q + '.sp', c.sp, { n: 1, w: '54px', dis: ro }), inp(q + '.E', c.E, { n: 1, w: '58px', dis: ro }), inp(q + '.nu', c.nu, { n: 1, w: '40px', dis: ro }), ro ? '' : btn('✕', 'cdel', i + '.' + j, '#b91c1c')]; }));
      h += (ro ? '' : btn('➕ Couche', 'cadd', i)) + '<b style="font-size:12px;display:block;margin-top:6px">Essais</b>' + table(['Type', 'Prof. (m)', 'Valeur', 'Unité', 'Norme / réf.', ''], (s.essais || []).map(function (e, j) { var q = p + '.essais.' + j; return [inp(q + '.type', e.type, { w: '90px', dis: ro }), inp(q + '.prof', e.prof, { n: 1, w: '56px', dis: ro }), inp(q + '.valeur', e.valeur, { n: 1, w: '64px', dis: ro }), inp(q + '.unite', e.unite, { w: '54px', dis: ro }), inp(q + '.norme', e.norme, { w: '100px', dis: ro }), ro ? '' : btn('✕', 'edel', i + '.' + j, '#b91c1c')]; }));
      h += (ro ? '' : btn('➕ Essai', 'eadd', i) + btn('Supprimer le sondage', 'sdel', i, '#b91c1c')) + '</div>';
    });
    h += ro ? '' : btn('➕ Sondage', 'sadd');
    h += '<h4 style="margin:12px 0 4px">Fondation étudiée (orientation)</h4><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:6px">' +
      lab('Sondage de calcul', '<select data-f="sondRef" data-n="1"' + (ro ? ' disabled' : '') + ' style="width:100%;padding:6px">' + (r.sondages || []).map(function (s, i) { return '<option value="' + i + '"' + (i === num(r.sondRef, 0) ? ' selected' : '') + '>' + esc(s.nom || 'Sondage ' + (i + 1)) + '</option>'; }).join('') + '</select>') +
      lab('B (m)', inp('fond.B', r.fond.B, { n: 1, dis: ro })) + lab('L (m, vide = carrée)', inp('fond.L', r.fond.L, { n: 1, dis: ro })) + lab('Assise Df (m)', inp('fond.Df', r.fond.Df, { n: 1, dis: ro })) + lab('Charge nette q (kPa)', inp('fond.q', r.fond.q, { n: 1, dis: ro })) + lab('Sécurité F', inp('fond.F', r.fond.F, { n: 1, dis: ro })) + lab('Facteur Iw', inp('fond.Iw', r.fond.Iw, { n: 1, dis: ro })) + lab('Zone d’influence (× B)', inp('fond.zinf', r.fond.zinf, { n: 1, dis: ro })) + lab('Tassement limite (mm)', inp('fond.limite', r.fond.limite, { n: 1, dis: ro })) + '</div>';
    h += '<div id="p2res"></div>';
    h += '<h4 style="margin:12px 0 4px">Recommandations</h4>' + (r.reco || []).map(function (t, i) { return '<div style="display:flex;gap:4px;margin:3px 0">' + inp('reco.' + i, t, dis) + (ro ? '' : btn('✕', 'rdel', i, '#b91c1c')) + '</div>'; }).join('') + (ro ? '' : btn('➕ Recommandation', 'radd'));
    h += '<h4 style="margin:12px 0 4px">Circuit de visa</h4><div>' + (r.statut === 'Brouillon' ? btn('Marquer « Vérifié »', 'gverif') : '') + (r.statut === 'Vérifié' ? btn('Viser (ingénieur)', 'gvise') + btn('Retour brouillon', 'gretour', null, '#475569') : '') + btn('📄 Rapport PDF', 'gpdf', null, '#1d4ed8') + (r.statut === 'Visé' ? btn('Nouvelle révision (copie)', 'grev', null, '#92400e') : '') + '</div>';
    h += '<details style="margin-top:8px"><summary>Historique (' + (r.histo || []).length + ')</summary>' + (r.histo || []).map(function (x) { return '<div style="font-size:12px">' + fdate(x.t) + ' — ' + esc(x.action) + ' — ' + esc(x.par || '') + (x.motif ? ' — ' + esc(x.motif) : '') + '</div>'; }).join('') + '</details>';
    return h;
  }
  function geoRes() {
    var r = geoGet(GID), e = d.getElementById('p2res'); if (!r || !e) return;
    var c = geoCalc(r), h = '<h4 style="margin:12px 0 4px">Résultats de calcul (orientation)</h4>';
    if (c.ok) {
      var p = c.port, t = c.tass;
      h += table(['Grandeur', 'Valeur'], [['Couche d’assise', esc(c.couche.nature || '—') + ' (γ ' + fx(num(c.couche.gamma), 1) + ' kN/m³ ; c ' + fx(num(c.couche.c), 0) + ' kPa ; φ ' + fx(num(c.couche.phi), 1) + '°)'], ['Facteurs Nc / Nq / Nγ', fx(p.Nc, 2) + ' / ' + fx(p.Nq, 2) + ' / ' + fx(p.Ng, 2)], ['Facteurs de forme sc / sq / sγ', fx(p.sc, 3) + ' / ' + fx(p.sq, 3) + ' / ' + fx(p.sg, 3)], ['Surcharge q0 à l’assise', fx(p.q0, 1) + ' kPa'], ['Capacité portante ultime qu', fx(p.qu, 0) + ' kPa'], ['Contrainte admissible nette (qu − q0) / F', '<b>' + fx(p.qadmNet, 0) + ' kPa</b> (F = ' + fx(p.F, 1) + ')'], ['Tassement de consolidation', fx(t.consolidation * 1000, 1) + ' mm'], ['Tassement immédiat (élastique)', fx(t.immediat * 1000, 1) + ' mm'], ['<b>Tassement total</b>', '<b>' + fx(t.total * 1000, 1) + ' mm</b>']]);
      h += '<p style="font-size:12px;color:#475569">Hypothèses : poids volumique humide au-dessus de la nappe, saturé en dessous ; pas de facteurs de profondeur ni d’inclinaison (prudent) ; répartition 2:1 ; ν par défaut 0,3. Valeurs à confirmer par le géotechnicien.</p>' + (r.project_id || r.dossier_id ? '' : '') + (geoRo(r) ? '' : btn('Proposer q admissible comme hypothèse de sol du dossier', 'gprop', null, '#7c3aed'));
    } else h += c.msgs.map(function (m) { return '<p style="color:#b45309">⚠️ ' + esc(m) + '</p>'; }).join('');
    h += '<h4 style="margin:12px 0 4px">Contrôles</h4>' + alertesHtml(geoVerif(r));
    e.innerHTML = h;
  }

  function dosSel() {
    var ds = dossiers();
    return '<div style="margin:6px 0">' + lab('Dossier d’étude (V207)', '<select data-a="dos" style="width:100%;padding:7px"><option value="">— choisir —</option>' + ds.map(function (x) { return '<option value="' + esc(x.id) + '"' + (x.id === DOS ? ' selected' : '') + '>' + esc(x.no + ' — ' + (x.titre || 'sans titre') + ' (' + x.statut + ')') + '</option>'; }).join('') + '</select>') + '</div>';
  }
  function quantHtml() {
    var h = '<h3 style="margin:6px 0">📐 Quantitatif structure</h3>' + dosSel(), dos = w.EXBBeD && w.EXBBeD.get ? w.EXBBeD.get(DOS) : null;
    if (!dos) return h + '<p>Choisissez un dossier d’étude ayant des notes de calcul rattachées.</p>';
    if (!(dos.notes || []).length) return h + '<p>Ce dossier n’a aucune note de calcul rattachée (onglet « Notes » du dossier d’étude).</p>';
    var r = qrec(DOS), P = r.params;
    h += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:6px">' + lab('Ancrage / recouvrement (× φ)', inp('params.ancrage', P.ancrage, { n: 1 })) + lab('Crochets (× φ par cadre/barre)', inp('params.crochet', P.crochet, { n: 1 })) + lab('Chutes / pertes acier (%)', inp('params.pertes', P.pertes, { n: 1 })) + lab('Masse volumique acier (kg/m³)', inp('params.densite', P.densite, { n: 1 })) + '</div><div id="p2res"></div>';
    return h;
  }
  function quantRes() {
    var dos = w.EXBBeD && w.EXBBeD.get ? w.EXBBeD.get(DOS) : null, e = d.getElementById('p2res'); if (!dos || !e) return;
    var r = qrec(DOS), q = quantifier(dos, r), h = '<h4 style="margin:10px 0 4px">Éléments calculés</h4>';
    h += table(['Note', 'Élément', 'Nb', 'Béton m³', 'Coffrage m²', 'Acier kg', 'Remarque'], q.lignes.map(function (l) { var kg = 0; Object.keys(l.acier).forEach(function (k) { kg += l.acier[k]; }); return [esc(l.note), esc(l.nom), inp('nb.' + l.key, l.nb, { n: 1, w: '46px' }), fx(l.beton * l.nb, 3), fx(l.coffrage * l.nb, 2), fx(kg * l.nb, 1), '<span style="font-size:11px">' + esc(l.remarque) + '</span>']; }));
    h += '<h4 style="margin:10px 0 4px">Totaux</h4>' + table(['Désignation', 'Quantité'], [['Béton', '<b>' + fx(q.beton, 2) + ' m³</b>'], ['Coffrage', '<b>' + fx(q.coffrage, 1) + ' m²</b>']].concat(Object.keys(q.acierDiam).sort(function (a, b) { return a - b; }).map(function (k) { return ['Acier HA' + k, fx(q.acierDiam[k], 1) + ' kg']; })).concat([['Acier net', fx(q.acierNet, 1) + ' kg'], ['Acier avec chutes (' + fx(q.pertes, 1) + ' %)', '<b>' + fx(q.acierBrut, 1) + ' kg</b>'], ['Ratio acier net / béton', fx(q.ratio, 0) + ' kg/m³']]));
    var M = r.metre;
    h += '<h4 style="margin:10px 0 4px">Rapprochement avec le métré</h4><p style="font-size:12px;color:#475569">Saisissez les quantités du module Métré & devis pour le même périmètre ; le logiciel compare, il ne corrige rien.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:6px">' + lab('Béton métré (m³)', inp('metre.beton', M.beton, { n: 1 })) + lab('Coffrage métré (m²)', inp('metre.coffrage', M.coffrage, { n: 1 })) + lab('Acier métré (kg)', inp('metre.acier', M.acier, { n: 1 })) + lab('Tolérance (%)', inp('metre.tol', M.tol, { n: 1 })) + lab('Source du métré', inp('metre.source', M.source)) + '</div>';
    h += table(['', 'Calculé', 'Métré', 'Écart', 'Statut', 'Justification'], rapproche(q, M).map(function (x) { return [x.nom, fx(x.calc, 2) + ' ' + x.unite, x.metre == null ? '—' : fx(x.metre, 2), x.ecart == null ? '—' : fx(x.ecart, 1) + ' %', '<b style="color:' + (x.statut === 'Conforme' ? '#047857' : x.statut === 'Justifié' ? '#1d4ed8' : '#b45309') + '">' + x.statut + '</b>', (x.statut === 'Écart à justifier' || x.statut === 'Justifié') ? inp('metre.justif.' + x.k, (M.justif || {})[x.k] || '', { ph: 'motif de l’écart', w: '160px' }) : '']; }));
    h += '<h4 style="margin:10px 0 4px">Contrôles</h4>' + alertesHtml(q.avert.map(function (m) { return { niveau: 'alerte', id: 'QTE', msg: m }; }));
    h += '<div>' + btn('📌 Figer une version', 'qfige') + btn('📄 PDF', 'qpdf', null, '#1d4ed8') + btn('⬇️ CSV', 'qcsv', null, '#475569') + '</div>';
    h += '<details style="margin-top:8px"><summary>Versions figées (' + (r.versions || []).length + ')</summary>' + (r.versions || []).map(function (v) { return '<div style="font-size:12px">v' + v.n + ' — ' + fdate(v.t) + ' — ' + esc(v.par) + ' — béton ' + fx(v.beton, 2) + ' m³, coffrage ' + fx(v.coffrage, 1) + ' m², acier brut ' + fx(v.acier, 0) + ' kg — empreinte ' + esc(v.emp) + '</div>'; }).join('') + '</details>';
    e.innerHTML = h; O = { q: q, r: r, dos: dos };
  }

  function bimHtml() {
    var h = '<h3 style="margin:6px 0">🧩 Coordination BIM</h3>' + dosSel(), dos = w.EXBBeD && w.EXBBeD.get ? w.EXBBeD.get(DOS) : null;
    if (!dos) return h + '<p>Choisissez un dossier d’étude.</p>';
    var E = coordEtat(dos), mods = modelesBim();
    h += '<p style="font-size:12.5px;color:#475569">Associez chaque élément calculé à un objet IFC (GlobalId de 22 caractères) et aux observations BCF. Un changement de l’élément après le lien déclenche une alerte d’analyse d’impact — jamais de recalcul automatique.</p>';
    if (!E.rows.length) return h + '<p>Aucun élément calculé (poteau, semelle, poutre) dans les notes du dossier.</p>';
    h += E.rows.map(function (r) {
      var x = '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin:6px 0"><b>' + esc(r.el.note) + ' · ' + esc(r.el.nom) + '</b> <span style="font-size:12px;color:#64748b">(' + r.el.type + ')</span>';
      r.liens.forEach(function (L) {
        var l = L.l, k = rd(KL).findIndex(function (z) { return z.id === l.id; });
        x += '<div style="margin:6px 0;padding:6px;background:#f8fafc;border-radius:8px"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:6px">' + lab('Modèle IFC', '<select data-lk="' + l.id + '" data-lf="model" style="width:100%;padding:6px"><option value="">—</option>' + mods.map(function (m) { return '<option value="' + esc(m.id) + '"' + (m.id === l.model ? ' selected' : '') + '>' + esc(m.name || m.id) + '</option>'; }).join('') + '</select>') + lab('GlobalId IFC', '<input data-lk="' + l.id + '" data-lf="guid" value="' + esc(l.guid) + '" maxlength="22" style="width:100%;padding:6px;font-family:monospace;box-sizing:border-box">') + lab('Étiquette IFC (facultatif)', '<input data-lk="' + l.id + '" data-lf="label" value="' + esc(l.label || '') + '" style="width:100%;padding:6px;box-sizing:border-box">') + '</div><div style="font-size:12.5px;margin-top:4px"><b style="color:' + (L.etat === 'Confirmé' ? '#047857' : L.etat === 'À réexaminer' ? '#b45309' : '#475569') + '">' + L.etat + '</b>' + (l.confirme ? ' — par ' + esc(l.confirme.par) + ', ' + fdate(l.confirme.t) : '') + ' — BCF liées : ' + (L.issues.length ? L.issues.map(function (i) { return esc(i.title) + ' [' + esc(i.status) + ']'; }).join(' ; ') : 'aucune') + '</div><div>' + btn('✔ Confirmer', 'lconf', l.id) + btn('Observation BCF', 'lbcf', l.id, '#7c3aed') + btn('Supprimer le lien', 'ldel', l.id, '#b91c1c') + '</div></div>';
      });
      return x + btn('➕ Associer un objet IFC', 'ladd', r.el.nid + '|' + r.el.eid) + '</div>';
    }).join('');
    h += '<h4 style="margin:10px 0 4px">Contrôles de coordination</h4>' + alertesHtml(E.alertes) + '<div>' + btn('⬇️ Matrice CSV', 'bcsv', null, '#475569') + '</div>';
    return h;
  }

  function paint() {
    var b = box(); if (!b) return;
    var tabs = [['geo', '🪨 Géotechnique'], ['quant', '📐 Quantitatif'], ['bim', '🧩 Coordination BIM']];
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px">' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:999px;background:' + (TAB === t[0] ? '#0f766e' : '#e2e8f0') + ';color:' + (TAB === t[0] ? '#fff' : '#0f172a') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + (TAB === 'geo' ? geoHtml() : TAB === 'quant' ? quantHtml() : bimHtml());
    if (TAB === 'geo' && GID) geoRes(); if (TAB === 'quant') quantRes();
  }
  function ouvrir(tab) {
    if (tab) TAB = tab; var o = d.getElementById('exbBeP2'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbBeP2'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbBeP2Box'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('change', onChange); c.addEventListener('click', onClick); paint();
  }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), a = t.getAttribute && t.getAttribute('data-a'), lk = t.getAttribute && t.getAttribute('data-lk');
    if (a === 'dos') { DOS = t.value; return paint(); }
    if (lk) { var L = rd(KL), l = L.filter(function (z) { return z.id === lk; })[0]; if (!l) return; var lf = t.getAttribute('data-lf'); l[lf] = lf === 'guid' ? String(t.value).trim() : t.value; if (lf === 'guid' || lf === 'model') delete l.confirme; wr(KL, L); audit('be.p2.bim.modif', lk, { champ: lf }); return paint(); }
    if (!f) return;
    var v = t.getAttribute('data-n') ? (t.value === '' ? '' : num(t.value)) : t.value;
    if (TAB === 'geo') { var r = geoGet(GID); if (!r || geoRo(r)) return; setPath(r, f, v); r.histo.push({ t: Date.now(), action: 'modif', par: '', motif: f }); if (r.histo.length > 200) r.histo.splice(0, r.histo.length - 200); geoPut(r); if (f === 'project_id' || f === 'sondRef') paint(); else geoRes(); }
    else if (TAB === 'quant') { var q = qrec(DOS); setPath(q, f, v); qput(q); quantRes(); }
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t || t.tagName === 'SELECT') return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i');
    if (a === 'close') { var o = d.getElementById('exbBeP2'); if (o) o.remove(); return; }
    if (a === 'tab') { TAB = i; return paint(); }
    if (TAB === 'geo') return geoAct(a, i);
    if (TAB === 'quant') return quantAct(a);
    if (TAB === 'bim') return bimAct(a, i);
  }
  function who(msg) { return ask(msg || 'Votre nom (signature nominative, non qualifiée) :', '').then(function (v) { return String(v || '').trim(); }); }
  function geoAct(a, i) {
    var r = GID ? geoGet(GID) : null;
    if (a === 'gnew') { var n = geoNew(); n.histo.push({ t: Date.now(), action: 'cree', par: '', motif: '' }); geoPut(n); audit('be.geo.cree', n.no, {}); GID = n.id; return paint(); }
    if (a === 'gopen') { GID = i; return paint(); } if (a === 'gback') { GID = ''; return paint(); }
    if (!r) return;
    if (a === 'gpdf') return geoPdf(r);
    if (geoRo(r) && a !== 'grev') return toast('Rapport visé : verrouillé. Créez une nouvelle révision.', 'warn');
    var S = r.sondages;
    if (a === 'sadd') S.push({ nom: 'S' + (S.length + 1), type: '', prof: '', nappe: '', couches: [], essais: [] });
    else if (a === 'sdel') { S.splice(+i, 1); r.sondRef = 0; }
    else if (a === 'cadd') { var cs = S[+i].couches, last = cs.length ? num(cs[cs.length - 1].a) : 0; cs.push({ de: last, a: '', nature: '', gamma: '', c: '', phi: '', e0: '', Cc: '', Cr: '', sp: '', E: '', nu: '' }); }
    else if (a === 'cdel') { var p = i.split('.'); S[+p[0]].couches.splice(+p[1], 1); }
    else if (a === 'eadd') S[+i].essais.push({ type: '', prof: '', valeur: '', unite: '', norme: '' });
    else if (a === 'edel') { var p2 = i.split('.'); S[+p2[0]].essais.splice(+p2[1], 1); }
    else if (a === 'radd') r.reco.push(''); else if (a === 'rdel') r.reco.splice(+i, 1);
    else if (a === 'gverif') {
      if (!String(r.auteur || '').trim()) return toast('Renseignez l’auteur du rapport avant la vérification.', 'warn');
      return who('Nom du vérificateur (différent de l’auteur) :').then(function (par) { if (!par) return;
        if (norm(par) === norm(r.auteur)) return toast('Le vérificateur doit être différent de l’auteur.', 'warn');
        var bl = geoVerif(r).filter(function (x) { return x.niveau === 'bloquant'; }); if (bl.length) return toast('Vérification impossible : ' + bl.length + ' point(s) bloquant(s).', 'warn');
        r.verificateur = par; r.statut = 'Vérifié'; r.histo.push({ t: Date.now(), action: 'verifie', par: par, motif: '' }); geoPut(r); audit('be.geo.verifie', r.no, { par: par }); paint(); });
    }
    else if (a === 'gretour') { r.statut = 'Brouillon'; r.histo.push({ t: Date.now(), action: 'retour', par: '', motif: '' }); }
    else if (a === 'gvise') {
      if (!habilite()) return toast('Le visa est réservé à la fonction Ingénieur (ou administrateur).', 'warn');
      return who().then(function (par) { if (!par) return; if (norm(par) === norm(r.verificateur || '') || norm(par) === norm(r.auteur || '')) return toast('Le viseur doit être différent de l’auteur et du vérificateur.', 'warn');
        var bl = geoVerif(r).filter(function (x) { return x.niveau === 'bloquant'; }); if (bl.length) return toast('Visa impossible : ' + bl.length + ' point(s) bloquant(s).', 'warn');
        r.statut = 'Visé'; r.vise = { par: par, t: Date.now(), emp: hash(JSON.stringify({ s: r.sondages, f: r.fond, r: r.reco })) }; r.histo.push({ t: Date.now(), action: 'vise', par: par, motif: '' }); geoPut(r); audit('be.geo.vise', r.no, { par: par }); paint(); });
    }
    else if (a === 'grev') { var c = JSON.parse(JSON.stringify(r)); c.id = uid('GEO'); c.no = r.no.replace(/-R\d+$/, '') + '-R' + ((num((r.no.match(/-R(\d+)$/) || [])[1], 0)) + 1); c.statut = 'Brouillon'; delete c.vise; delete c.verificateur; c.histo = [{ t: Date.now(), action: 'revision', par: '', motif: 'issue de ' + r.no }]; geoPut(c); GID = c.id; return paint(); }
    else if (a === 'gprop') return geoPropose(r);
    geoPut(r); paint();
  }
  function geoPropose(r) {
    var c = geoCalc(r); if (!c.ok) return toast('Calcul non disponible : ' + c.msgs.join(' '), 'warn');
    var ds = dossiers().filter(function (x) { return x.project_id && x.project_id === r.project_id && x.statut === 'Brouillon'; });
    if (!ds.length) return toast('Aucun dossier d’étude en brouillon pour ce projet : rattachez le rapport à un projet ayant un dossier modifiable.', 'warn');
    var dos = ds[0], mpa = Math.round(c.port.qadmNet) / 1000;
    ask('Ajouter au dossier ' + dos.no + ' l’hypothèse « Contrainte admissible nette du sol » = ' + fx(mpa, 3) + ' MPa ? (OK pour confirmer — à valider par l’ingénieur)', fx(mpa, 3)).then(function (v) {
      if (v == null || v === '') return;
      dos.hypotheses.push({ cat: 'sol', desc: 'Contrainte admissible nette du sol (qu − q0)/F', valeur: String(v), unite: 'MPa', justif: 'Rapport de sol ' + r.no + ' — Vesic, F = ' + fx(c.port.F, 1) + ' — calcul d’orientation à valider par le géotechnicien.' });
      if (w.EXBBeD.put(dos)) { audit('be.geo.hypothese', dos.no, { rapport: r.no }); toast('Hypothèse de sol ajoutée au dossier ' + dos.no + '.', 'success'); }
    });
  }
  function geoPdf(r) {
    var c = geoCalc(r), S = r.sondages || [], rows = [['Rapport de sol', r.no + ' — ' + (r.titre || '—') + ' — statut : ' + r.statut], ['Projet / site', pnom(r.project_id) + ' — ' + (r.site || '—')], ['Date / géotechnicien', (r.date || '—') + ' — ' + (r.geotechnicien || '—')]];
    S.forEach(function (s) { rows.push(['Sondage ' + (s.nom || ''), (s.type || '—') + ' — prof. ' + fx(num(s.prof), 1) + ' m — nappe : ' + (s.nappe === '' || s.nappe == null ? 'non vue' : fx(num(s.nappe), 2) + ' m') + '\n' + (s.couches || []).map(function (l) { return fx(num(l.de), 2) + '–' + fx(num(l.a), 2) + ' m : ' + (l.nature || '—') + ' (γ ' + fx(num(l.gamma), 1) + ' ; c ' + fx(num(l.c), 0) + ' ; φ ' + fx(num(l.phi), 1) + ')'; }).join('\n') + ((s.essais || []).length ? '\nEssais : ' + s.essais.map(function (e) { return e.type + ' ' + e.valeur + ' ' + e.unite + ' à ' + e.prof + ' m'; }).join(' ; ') : '')]); });
    if (c.ok) rows.push(['Fondation étudiée', 'B = ' + fx(num(r.fond.B), 2) + ' m ; L = ' + fx(num(r.fond.L, num(r.fond.B)), 2) + ' m ; Df = ' + fx(num(r.fond.Df), 2) + ' m ; q = ' + fx(num(r.fond.q), 0) + ' kPa'], ['Portance (Vesic, sans facteurs de profondeur)', 'qu = ' + fx(c.port.qu, 0) + ' kPa ; q admissible nette = ' + fx(c.port.qadmNet, 0) + ' kPa (F = ' + fx(c.port.F, 1) + ')'], ['Tassement (orientation)', 'consolidation ' + fx(c.tass.consolidation * 1000, 1) + ' mm + immédiat ' + fx(c.tass.immediat * 1000, 1) + ' mm = ' + fx(c.tass.total * 1000, 1) + ' mm']);
    var al = geoVerif(r); rows.push(['Recommandations', (r.reco || []).map(function (t, i) { return (i + 1) + '. ' + t; }).join('\n') || '—'], ['Contrôles', al.length ? al.map(function (x) { return x.id + ' — ' + x.msg; }).join('\n') : 'Aucune alerte (ne vaut pas validation).'], ['Signatures (mentions nominatives non qualifiées)', 'Vérifié : ' + (r.verificateur || '—') + '\nVisé : ' + (r.vise ? r.vise.par + ' — ' + fdate(r.vise.t) + ' — empreinte ' + r.vise.emp : '— (non visé)')]);
    pdf({ titre: 'RAPPORT DE SOL', sousTitre: san(r.no + ' — ' + (r.titre || '')), rows: rows.map(function (x) { return [san(x[0]), san(x[1])]; }), notes: ['Calcul d’orientation déterministe — ne remplace pas la mission géotechnique ni l’avis du géotechnicien.'], footer: san(r.no + ' — ' + r.statut) });
  }
  function quantAct(a) {
    if (!O || !O.dos) return; var q = O.q, r = O.r, dos = O.dos;
    if (a === 'qfige') return who().then(function (par) { if (!par) return; var emp = hash(JSON.stringify({ l: q.lignes.map(function (l) { return [l.key, l.nb, l.beton, l.coffrage, l.acier]; }), p: r.params })); r.versions.push({ n: r.versions.length + 1, t: Date.now(), par: par, beton: q.beton, coffrage: q.coffrage, acier: q.acierBrut, emp: emp }); qput(r); audit('be.quant.fige', dos.no, { v: r.versions.length, par: par }); paint(); });
    if (a === 'qcsv') { var rows = [['Note', 'Élément', 'Nb', 'Béton m3', 'Coffrage m2', 'Acier kg']]; q.lignes.forEach(function (l) { var kg = 0; Object.keys(l.acier).forEach(function (k) { kg += l.acier[k]; }); rows.push([l.note, l.nom, l.nb, fx(l.beton * l.nb, 3), fx(l.coffrage * l.nb, 2), fx(kg * l.nb, 1)]); }); rows.push(['TOTAL', '', '', fx(q.beton, 2), fx(q.coffrage, 1), fx(q.acierBrut, 1)]); return csv(rows, 'quantitatif-' + dos.no + '.csv'); }
    if (a === 'qpdf') { var rap = rapproche(q, r.metre); pdf({ titre: 'QUANTITATIF STRUCTURE', sousTitre: san(dos.no + ' — ' + (dos.titre || '')), rows: [['Béton', fx(q.beton, 2) + ' m3'], ['Coffrage', fx(q.coffrage, 1) + ' m2'], ['Acier par diamètre', Object.keys(q.acierDiam).sort(function (x, y) { return x - y; }).map(function (k) { return 'HA' + k + ' : ' + fx(q.acierDiam[k], 1) + ' kg'; }).join('\n') || '—'], ['Acier net / avec chutes', fx(q.acierNet, 1) + ' kg / ' + fx(q.acierBrut, 1) + ' kg (' + fx(q.pertes, 1) + ' %)'], ['Ratio acier / béton', fx(q.ratio, 0) + ' kg/m3'], ['Hypothèses', 'ancrage ' + r.params.ancrage + ' phi ; crochets ' + r.params.crochet + ' phi ; densité ' + r.params.densite + ' kg/m3 ; cadres comptés au premier espacement'], ['Éléments', q.lignes.map(function (l) { return l.note + ' · ' + l.nom + ' x' + l.nb; }).join('\n') || '—'], ['Rapprochement métré (' + (r.metre.source || 'source non précisée') + ')', rap.map(function (x) { return x.nom + ' : ' + x.statut + (x.ecart == null ? '' : ' (' + fx(x.ecart, 1) + ' %)'); }).join('\n')], ['Alertes', q.avert.join('\n') || '—']].map(function (x) { return [san(x[0]), san(x[1])]; }), notes: ['Quantitatif calculé à partir des notes de calcul du dossier ; à confirmer par l’ingénieur et par le métreur.'], footer: san('Quantitatif ' + dos.no) }); }
  }
  function bimAct(a, i) {
    var dos = w.EXBBeD && w.EXBBeD.get ? w.EXBBeD.get(DOS) : null; if (!dos) return;
    if (a === 'ladd') { var p = i.split('|'), L = rd(KL), nm = notesAll().filter(function (z) { return z.id === p[0]; })[0], el = nm && (nm.els || []).filter(function (e) { return e.id === p[1]; })[0]; L.push({ id: uid('LK'), dossier_id: dos.id, nid: p[0], eid: p[1], el_nom: el ? el.name : '', model: '', guid: '', label: '', emp: elemEmpreinte(p[0], p[1]), t: Date.now() }); wr(KL, L); audit('be.p2.bim.lien', dos.no, {}); return paint(); }
    var Ls = rd(KL), l = Ls.filter(function (z) { return z.id === i; })[0]; if (!l) return;
    if (a === 'ldel') { wr(KL, Ls.filter(function (z) { return z.id !== i; })); audit('be.p2.bim.supprime', dos.no, { guid: l.guid }); return paint(); }
    if (a === 'lconf') return who().then(function (par) { if (!par) return; if (!RGUID.test(l.guid || '')) return toast('GlobalId IFC invalide : 22 caractères [0-9A-Za-z_$].', 'warn'); l.emp = elemEmpreinte(l.nid, l.eid); l.confirme = { par: par, t: Date.now() }; wr(KL, Ls); audit('be.p2.bim.confirme', dos.no, { guid: l.guid, par: par }); paint(); });
    if (a === 'lbcf') {
      if (!w.EXB_ARCH || !w.EXB_ARCH.addBim) return toast('Module BIM indisponible.', 'error');
      if (!RGUID.test(l.guid || '')) return toast('Renseignez d’abord un GlobalId IFC valide.', 'warn');
      return ask('Titre de l’observation BCF :', 'Structure — vérifier ' + (l.el_nom || 'élément') + ' (' + dos.no + ')').then(function (t) { if (!t) return; try { w.EXB_ARCH.addBim({ project: dos.project_id || '', title: t, priority: 'Normale', status: 'Ouvert', disc: 'Structure', loc: dos.localisation || '', guid: l.guid, model: l.model || '' }); audit('be.p2.bim.bcf', dos.no, { guid: l.guid }); toast('Observation BIM créée (visible dans Architecture › BIM / BCF).', 'success'); paint(); } catch (e) { toast('Création impossible : ' + e.message, 'error'); } });
    }
    if (a === 'bcsv') { var E = coordEtat(dos), rows = [['Note', 'Élément', 'Type', 'Modèle IFC', 'GlobalId', 'Statut lien', 'Observations BCF']]; E.rows.forEach(function (r) { if (!r.liens.length) rows.push([r.el.note, r.el.nom, r.el.type, '', '', 'Non lié', '']); r.liens.forEach(function (L) { rows.push([r.el.note, r.el.nom, r.el.type, L.l.model, L.l.guid, L.etat, L.issues.map(function (x) { return x.title + ' [' + x.status + ']'; }).join(' | ')]); }); }); csv(rows, 'coordination-bim-' + dos.no + '.csv'); }
  }
  function ui() {
    var b = d.getElementById('exbBeBtn'); if (!b || d.getElementById('exbBeP2Btn')) return;
    var k = d.createElement('button'); k.id = 'exbBeP2Btn'; k.setAttribute('data-exb-cat', 'ing'); k.setAttribute('data-exb-desc', 'Sol, quantitatif de structure et coordination BIM'); k.className = b.className; k.textContent = '🪨 Études P2 (sol · quantitatif · BIM)'; k.onclick = function () { ouvrir('geo'); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'beP2', name: 'Études P2 (géotechnique, quantitatif structure, coordination BIM)', version: '1.0.0', area: 'Technique', deps: ['beDossier', 'calcul', 'bimEnterprise'], collections: [KG, KQ, KL] }); } catch (e) {}

  w.EXBBeP2 = { open: ouvrir, facteurs: facteurs, sigmaV: sigmaV, portance: portance, tassTranche: tassTranche, tassement: tassement, geoCalc: geoCalc, geoVerif: geoVerif, quantElement: quantElement, quantifier: quantifier, rapproche: rapproche, coordEtat: coordEtat, validGuid: function (g) { return RGUID.test(g || ''); } };
  if (typeof module !== 'undefined' && module.exports) module.exports = w.EXBBeP2;
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { addEventListener: function () {}, documentElement: {} });
