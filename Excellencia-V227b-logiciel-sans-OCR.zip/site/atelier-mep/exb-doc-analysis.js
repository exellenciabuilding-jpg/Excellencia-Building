/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-analysis (analyse des pages, via pdf.js).
 * Détecte par page : taille réelle (mm, rotation comprise), format ISO ou personnalisé, orientation, texte / page scannée, cartouche existant (mots-clés + emprise),
 * et une carte de l'encre (grille 96×96) servant à savoir où l'on peut poser un cartouche SANS recouvrir de contenu. Lit seulement : ne modifie rien. */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {}, MM = 25.4 / 72, N = 96;
  var MOTS = [['echelle', /\bechelle\b|\bscale\b|\bech\.?\s*:/i], ['dessine', /dessine|\bdrawn\b|\bdess\b/i], ['verifie', /verifie|\bchecked\b/i], ['approuve', /approuve|\bapproved\b/i], ['indice', /\bindice\b|\brev(?:ision)?\b/i],
    ['projet', /\bprojet\b|\bproject\b/i], ['client', /\bclient\b|maitre d.ouvrage|\bm\.?o\.?a\b/i], ['titre', /\btitre\b|\btitle\b|\bdesignation\b/i], ['date', /\bdate\b/i], ['plan', /\bplan n|n[°o] de plan|\bfolio\b|\bformat\b|\bphase\b/i], ['bet', /bureau d.etudes|\barchitecte\b|\bingenieur\b/i]];
  function sansAccents(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }

  function fmt(wmm, hmm) { return (g.EXBDOC.layout || require('./exb-doc-layout.js')).detectFormat(wmm, hmm); }

  /* Fonction pure (testable) : à partir des éléments de texte d'une page (str, x, y en mm, origine en haut à gauche) → cartouche détecté ? */
  function detecterCartouche(items, W, H) {
    var mots = {}, bb = null;
    items.forEach(function (it) {
      var inZone = it.y > H * 0.58 || it.x > W * 0.62; if (!inZone) return;
      var sa = sansAccents(it.s); MOTS.forEach(function (m) { if (m[1].test(sa)) { mots[m[0]] = 1; bb = bb ? [Math.min(bb[0], it.x), Math.min(bb[1], it.y - it.h), Math.max(bb[2], it.x + it.w), Math.max(bb[3], it.y)] : [it.x, it.y - it.h, it.x + it.w, it.y]; } });
    });
    var ks = Object.keys(mots);
    if (ks.length < 3 || !bb) return { detecte: false, bbox: null, mots: ks };
    var e = 8; bb = [Math.max(0, bb[0] - e), Math.max(0, bb[1] - e), Math.min(W, bb[2] + e), Math.min(H, bb[3] + e)];
    return { detecte: true, bbox: bb.map(function (v) { return Math.round(v * 10) / 10; }), mots: ks };
  }

  async function grilleEncre(page, wpt, hpt) {
    var k = 960 / Math.max(wpt, hpt), vp = page.getViewport({ scale: k }), cv = document.createElement('canvas'); cv.width = Math.max(N, Math.round(vp.width)); cv.height = Math.max(N, Math.round(vp.height));
    var cx = cv.getContext('2d', { willReadFrequently: true }); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
    await page.render({ canvasContext: cx, viewport: page.getViewport({ scale: cv.width / wpt }) }).promise;
    var d = cx.getImageData(0, 0, cv.width, cv.height).data, W = cv.width, H = cv.height, cnt = new Float32Array(N * N), tot = new Float32Array(N * N);
    for (var y = 0; y < H; y++) { var j = Math.min(N - 1, Math.floor(y * N / H)); for (var x = 0; x < W; x++) { var i = Math.min(N - 1, Math.floor(x * N / W)), p = (y * W + x) * 4, lum = 0.3 * d[p] + 0.59 * d[p + 1] + 0.11 * d[p + 2]; tot[j * N + i]++; if (lum < 200 && d[p + 3] > 0) cnt[j * N + i]++; } }
    var out = new Uint8Array(N * N); for (var c = 0; c < out.length; c++) out[c] = Math.min(255, Math.round(255 * cnt[c] / (tot[c] || 1)));
    cv.width = cv.height = 0; return { n: N, data: out };
  }

  async function outline(pdf) {
    try {
      var ol = await pdf.getOutline(); if (!ol) return []; var res = [];
      async function pageDe(dest) { try { if (typeof dest === 'string') dest = await pdf.getDestination(dest); if (!dest || !dest[0]) return null; return typeof dest[0] === 'object' ? (await pdf.getPageIndex(dest[0])) + 1 : (+dest[0] + 1); } catch (e) { return null; } }
      async function walk(items, lvl) { for (var i = 0; i < items.length && res.length < 80; i++) { var it = items[i], p = await pageDe(it.dest); if (p && it.title) res.push({ titre: String(it.title).trim().slice(0, 100), page: p, niveau: lvl }); if (it.items && it.items.length && lvl < 2) await walk(it.items, lvl + 1); } }
      await walk(ol, 1); return res;
    } catch (e) { return []; }
  }

  /* pdfjs = module pdf.js ; opts = { motDePasse, progress(i,n), grilles:true } → { analyse, grilles } | { besoinMotDePasse, incorrect } | { erreur } */
  async function analyser(pdfjs, bytes, opts) {
    opts = opts || {}; var task, pdf;
    try { task = pdfjs.getDocument({ data: bytes.slice(), password: opts.motDePasse || undefined, isEvalSupported: false, useSystemFonts: false }); pdf = await task.promise; }
    catch (e) { if (e && e.name === 'PasswordException') return { besoinMotDePasse: true, incorrect: e.code === 2 }; return { erreur: 'PDF illisible : ' + (e && e.message || e) }; }
    var pages = [], grilles = [], n = pdf.numPages, OPS = pdfjs.OPS || {};
    for (var i = 1; i <= n; i++) {
      var pg = await pdf.getPage(i), vp = pg.getViewport({ scale: 1 }), W = vp.width * MM, H = vp.height * MM, f = fmt(W, H), items = [], chars = 0;
      try { var tc = await pg.getTextContent(); tc.items.forEach(function (it) { if (!it.str || !String(it.str).trim()) return; chars += it.str.length; var p = vp.convertToViewportPoint(it.transform[4], it.transform[5]); items.push({ s: it.str, x: p[0] * MM, y: p[1] * MM, w: (it.width || 0) * MM, h: (it.height || 6) * MM }); }); } catch (e) {}
      var scan = false;
      if (chars < 15) { try { var ol = await pg.getOperatorList(), im = [OPS.paintImageXObject, OPS.paintInlineImageXObject, OPS.paintImageMaskXObject, OPS.paintJpegXObject].filter(Boolean); scan = ol.fnArray.some(function (fn) { return im.indexOf(fn) >= 0; }); } catch (e) {} }
      var cart = scan ? { detecte: false, bbox: null, mots: [], note: 'page scannée : détection par OCR seulement' } : detecterCartouche(items, W, H);
      pages.push({ n: i, wmm: Math.round(W * 10) / 10, hmm: Math.round(H * 10) / 10, format: f.nom, orient: f.orient, rot: pg.rotate || 0, chars: chars, scan: scan, texte: chars >= 15, cartouche: cart });
      grilles.push(opts.grilles === false ? null : await grilleEncre(pg, vp.width, vp.height).catch(function () { return null; }));
      pg.cleanup(); if (opts.progress) opts.progress(i, n);
    }
    var fm = {}; pages.forEach(function (p) { fm[p.format] = 1; });
    var an = { nbPages: n, pages: pages, formatsMixtes: Object.keys(fm).length > 1, scannes: pages.filter(function (p) { return p.scan; }).length, outline: await outline(pdf) };
    try { await pdf.destroy(); } catch (e) {}
    return { analyse: an, grilles: grilles };
  }
  NS.analysis = { analyser: analyser, detecterCartouche: detecterCartouche, MOTS: MOTS };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.analysis;
})(typeof window !== 'undefined' ? window : globalThis);
