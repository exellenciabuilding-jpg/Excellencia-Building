/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-ocr (OCR français FACULTATIF).
 * Utilise Tesseract.js servi avec l'application (dossier vendor/tesseract/, comme le Scanner). Si les fichiers sont absents, le bouton l'explique.
 * L'OCR ne MODIFIE JAMAIS le PDF : il lit le texte des premières pages scannées pour PROPOSER des valeurs de champs (titre, numéro, échelle, indice, date),
 * affichées dans une zone modifiable : la correction manuelle est obligatoire avant usage. */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {}, BASE = '../vendor/tesseract/', worker = null;

  /* Pure : propositions de champs à partir d'un texte. */
  function suggerer(text) {
    var t = String(text || '').replace(/\r/g, ''), o = {}, lines = t.split('\n').map(function (l) { return l.replace(/\s+/g, ' ').trim(); }).filter(function (l) { return (l.match(/[A-Za-zÀ-ÿ]/g) || []).length >= 4; });
    var m;
    if ((m = /[ée]chelle\s*[:\-]?\s*(1\s*[\/:]\s*\d{1,5})/i.exec(t)) || (m = /\b(1\s*\/\s*(?:20|25|50|75|100|125|150|200|250|500|1000))\b/.exec(t))) o.echelle = m[1].replace(/\s+/g, '');
    if ((m = /\bindice\s*[:\-]?\s*([A-Za-z]{1,2})\b/i.exec(t)) || (m = /\bR[ée]v(?:ision|\.)?\s*[:\-]?\s*([A-Z0-9]{1,2})\b/i.exec(t))) o.indice = m[1].toUpperCase();
    if ((m = /\b(?:plan|document|r[ée]f[ée]rence|n[°o])\s*(?:n[°o])?\s*[:\-]?\s*([A-Z0-9][A-Z0-9\/\-._]{3,24})/i.exec(t))) o.numero = m[1];
    if ((m = /\b(\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{2,4})\b/.exec(t))) o.date = m[1];
    if ((m = /\btitre\s*[:\-]\s*(.{4,80})/i.exec(t))) o.titre = m[1].trim(); else if (lines.length) o.titre = lines[0].slice(0, 100);
    return o;
  }
  function abs(p) { try { return new URL(p, g.document.baseURI).href; } catch (e) { return p; } }
  async function disponible() { try { var r = await fetch(abs(BASE + 'worker.min.js'), { method: 'HEAD' }); return !!r.ok; } catch (e) { return false; } }
  function loadScript(src) { return new Promise(function (ok, ko) { var s = g.document.createElement('script'); s.src = src; s.onload = ok; s.onerror = function () { ko(new Error('absent')); }; g.document.head.appendChild(s); }); }
  async function getWorker(onp) {
    if (worker) return worker; if (!g.Tesseract) await loadScript(abs(BASE + 'tesseract.min.js')); if (!g.Tesseract || !g.Tesseract.createWorker) throw new Error('absent');
    var A = abs(BASE); worker = await g.Tesseract.createWorker('fra', 1, { workerPath: A + 'worker.min.js', corePath: A, langPath: A, workerBlobURL: false, gzip: true, logger: function (m) { if (onp && m && m.status === 'recognizing text') onp(m.progress || 0); } }); return worker;
  }
  /* canvases = pages rendues (≤ 3) → { texte, champs } */
  async function lire(canvases, onp) { var wk = await getWorker(onp), tx = []; for (var i = 0; i < canvases.length; i++) { var r = await wk.recognize(canvases[i]); tx.push((r && r.data && r.data.text) || ''); } var texte = tx.join('\n'); return { texte: texte, champs: suggerer(texte) }; }
  NS.ocr = { suggerer: suggerer, disponible: disponible, lire: lire, BASE: BASE };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.ocr;
})(typeof window !== 'undefined' ? window : globalThis);
