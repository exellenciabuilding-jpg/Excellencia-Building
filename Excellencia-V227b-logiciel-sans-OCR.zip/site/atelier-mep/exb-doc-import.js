/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-import (lecture des fichiers et métadonnées).
 * Contrôles à l'import : vrai PDF (signature « %PDF- »), fichier non vide, taille raisonnable, PDF chiffré/protégé, signature numérique.
 * Aucune modification du fichier : on lit les octets et on les transmet tels quels à l'archivage. */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {}, MAX = 300 * 1024 * 1024;
  function latin1(b) { var o = '', n = b.length, CH = 1 << 20; for (var i = 0; i < n; i += CH) o += String.fromCharCode.apply(null, b.subarray(i, Math.min(n, i + CH))); return o; }
  function estPdf(b) { var h = latin1(b.subarray(0, Math.min(b.length, 1024))); return h.indexOf('%PDF-') >= 0; }
  /* Signature numérique : champ /Sig avec /ByteRange (les deux présents). */
  function signe(b) { var s = latin1(b); return /\/ByteRange\s*\[/.test(s) && /\/Type\s*\/Sig\b|\/FT\s*\/Sig\b|\/SubFilter\s*\/(adbe|ETSI)/.test(s); }
  function chiffre(b) { var s = latin1(b); return /\/Encrypt\s+\d+\s+\d+\s+R|\/Encrypt\s*<</.test(s); }

  /* octets → { ok, bytes, erreur?, signe, chiffre } */
  async function lire(file) {
    var nom = file.name || 'document.pdf';
    if (!file.size) return { ok: false, nom: nom, erreur: 'Fichier vide.' };
    if (file.size > MAX) return { ok: false, nom: nom, erreur: 'Fichier trop volumineux (' + Math.round(file.size / 1048576) + ' Mo ; maximum ' + Math.round(MAX / 1048576) + ' Mo).' };
    var buf; try { buf = new Uint8Array(await file.arrayBuffer()); } catch (e) { return { ok: false, nom: nom, erreur: 'Lecture impossible : ' + (e && e.message || e) }; }
    if (!estPdf(buf)) return { ok: false, nom: nom, erreur: 'Ce fichier n’est pas un PDF (en-tête « %PDF- » absent).' };
    return { ok: true, nom: nom, bytes: buf, signe: signe(buf), chiffre: chiffre(buf) };
  }
  NS.importer = { MAX: MAX, lire: lire, estPdf: estPdf, signe: signe, chiffre: chiffre };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.importer;
})(typeof window !== 'undefined' ? window : globalThis);
