/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-preview (aperçu page par page et contrôle d'intégrité, via pdf.js).
 * L'aperçu « après » est le PDF réellement produit (même moteur que l'export) : ce qu'on voit est ce qui sera exporté.
 * Contrôle d'intégrité : pour chaque page d'origine, on compare l'image et le texte de la page ORIGINALE avec ceux de la page produite, EN DEHORS de la zone ajoutée
 * (cartouche / en-tête / pied / bande). Toute différence est signalée : calculs, cotes et dessins d'origine doivent rester identiques. */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {};
  async function ouvrir(pdfjs, bytes, pw) { var task = pdfjs.getDocument({ data: bytes.slice(), password: pw || undefined, isEvalSupported: false }); return task.promise; }
  async function rendre(pdf, index, canvas, o) {
    o = o || {}; var pg = await pdf.getPage(index + 1), rot = ((pg.rotate || 0) + (o.rotation || 0)) % 360, vp0 = pg.getViewport({ scale: 1, rotation: rot });
    var k = o.maxW ? (o.maxW / vp0.width) * (o.zoom || 1) : (o.zoom || 1), dpr = Math.min(2, g.devicePixelRatio || 1), vp = pg.getViewport({ scale: k * dpr, rotation: rot });
    canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height); canvas.style.width = Math.round(vp.width / dpr) + 'px'; canvas.style.height = Math.round(vp.height / dpr) + 'px';
    var cx = canvas.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, canvas.width, canvas.height);
    if (o.task && o.task.cancel) { try { o.task.cancel(); } catch (e) {} }
    var t = pg.render({ canvasContext: cx, viewport: vp }); if (o.setTask) o.setTask(t); await t.promise; return { wmm: vp0.width * 25.4 / 72, hmm: vp0.height * 25.4 / 72, k: k * dpr };
  }

  async function pixels(pdf, index, pxPerPt) {
    var pg = await pdf.getPage(index + 1), vp = pg.getViewport({ scale: pxPerPt }), cv = document.createElement('canvas'); cv.width = Math.round(vp.width); cv.height = Math.round(vp.height);
    var cx = cv.getContext('2d', { willReadFrequently: true }); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); await pg.render({ canvasContext: cx, viewport: vp }).promise;
    var tc = await pg.getTextContent(); var tx = tc.items.map(function (i) { return String(i.str || '').trim(); }).filter(Boolean);
    return { w: cv.width, h: cv.height, data: cx.getImageData(0, 0, cv.width, cv.height).data, texte: tx };
  }

  /* origs : tableau (index de document du plan) → octets ; sortie : octets produits ; carte = résultat de exporter.build().map */
  async function integrite(pdfjs, origs, outBytes, carte, onp) {
    var out = await ouvrir(pdfjs, outBytes), cache = {}, res = [], cibles = carte.filter(function (m) { return m.kind === 'orig'; }), pas = Math.max(1, Math.ceil(cibles.length / 24));
    var echant = cibles.filter(function (m, i) { return i % pas === 0 || i === cibles.length - 1; });
    for (var q = 0; q < echant.length; q++) {
      var m = echant[q]; if (onp) onp(q + 1, echant.length);
      var src = cache[m.doc] || (cache[m.doc] = await ouvrir(pdfjs, origs[m.doc])), pgO = await src.getPage(m.page + 1), vpO = pgO.getViewport({ scale: 1 }), s = Math.min(1.2, 1100 / Math.max(vpO.width, vpO.height));
      var A = await pixels(src, m.page, s), B = await pixels(out, m.out, s), diff = 0, total = 0, z = m.mode === 'overlay' && m.zone ? { x0: m.zone.x * s * 72 / 25.4, y0: m.zone.y * s * 72 / 25.4, x1: (m.zone.x + m.zone.w) * s * 72 / 25.4, y1: (m.zone.y + m.zone.h) * s * 72 / 25.4 } : null;
      var hdrFtr = m.mode === 'overlay' && m.zone && m.zone.w >= m.W - 0.1 && m.zone.h >= m.H - 0.1;   /* en-tête + pied : zone = page entière → on exclut les bandes haute et basse */
      var yMax = A.h; if (m.mode === 'band' && m.zone) yMax = Math.min(A.h, Math.floor((m.zone.y - (m.bandTop || 0)) * s * 72 / 25.4) - 1);   /* bande ajoutée : on compare seulement la zone d'origine */
      var offT = Math.round((m.bandTop || 0) * s * 72 / 25.4);   /* V221 : bande ajoutée au-dessus → la page d'origine est décalée vers le bas */
      for (var y = 0; y < yMax; y++) for (var x = 0; x < A.w; x++) {
        if (z && !hdrFtr && x >= z.x0 - 2 && x <= z.x1 + 2 && y >= z.y0 - 2 && y <= z.y1 + 2) continue;
        if (hdrFtr && (y < 14 * s * 72 / 25.4 || y > A.h - 16 * s * 72 / 25.4)) continue;
        total++; var a = (y * A.w + x) * 4, b = ((y + offT) * B.w + x) * 4; if (x >= B.w || y + offT >= B.h) { diff++; continue; }
        if (Math.abs(A.data[a] - B.data[b]) > 40 || Math.abs(A.data[a + 1] - B.data[b + 1]) > 40 || Math.abs(A.data[a + 2] - B.data[b + 2]) > 40) diff++;
      }
      var bag = {}; B.texte.forEach(function (t) { bag[t] = (bag[t] || 0) + 1; }); var perdus = 0; A.texte.forEach(function (t) { if (bag[t]) bag[t]--; else perdus++; });
      var okImg = total ? diff / total < 0.0005 : true;
      res.push({ page: m.out + 1, ok: okImg && perdus === 0, pixelsDifferents: diff, ratio: total ? diff / total : 0, textesOrigine: A.texte.length, textesPerdus: perdus });
    }
    try { await out.destroy(); } catch (e) {} for (var k in cache) { try { await cache[k].destroy(); } catch (e) {} }
    return { ok: res.every(function (r) { return r.ok; }), pages: res, echantillon: echant.length, total: cibles.length };
  }
  NS.preview = { ouvrir: ouvrir, rendre: rendre, integrite: integrite };
})(typeof window !== 'undefined' ? window : globalThis);
