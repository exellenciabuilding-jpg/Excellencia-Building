/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-version (archivage, versions, circuit de validation, journal d'audit).
 * - L'ORIGINAL importé est IMMUABLE : octets rangés une seule fois, adressés par leur empreinte SHA-256 (ajout seul : jamais d'écrasement).
 * - Chaque export crée une NOUVELLE VERSION liée à l'original (empreinte, modèle, champs, statut, auteur, date).
 * - Le journal (ajout seul) garde utilisateur, date, action, modèle, champs modifiés, statut et référence du fichier produit ; il est aussi copié dans le journal d'audit chaîné du noyau (EXBCore).
 * Octets : IndexedDB « exb_mep » (hors localStorage : plans de plusieurs dizaines de Mo). Fiches : clés exb_mep_* via exbStorage (sauvegardes de l'application). */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {}, C = NS.cartouche || (typeof require !== 'undefined' ? require('./exb-cartouche.js') : null);
  var K = { docs: 'exb_mep_docs', vers: 'exb_mep_versions', jrn: 'exb_mep_journal', mod: 'exb_mep_modeles', cfg: 'exb_mep_config' };
  var host = null; try { host = g.parent && g.parent !== g ? g.parent : null; } catch (e) { host = null; }
  function H(n) { try { return host && host[n]; } catch (e) { return null; } }
  function store() { try { return H('exbStorage') || g.exbStorage || null; } catch (e) { return null; } }
  var mem = {};   /* repli (tests, navigation privée) */
  function rd(k, def) { try { var S = store(), raw = S ? S.getItem(k) : (g.localStorage ? g.localStorage.getItem(k) : mem[k]); var v = raw ? JSON.parse(raw) : def; return v == null ? def : v; } catch (e) { return mem[k] ? JSON.parse(mem[k]) : def; } }
  function wr(k, v) { var j = JSON.stringify(v); try { var S = store(); if (S) S.setItem(k, j); else if (g.localStorage) g.localStorage.setItem(k, j); else mem[k] = j; return true; } catch (e) { mem[k] = j; return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  /* ---------------------------------------------------------------- octets : IndexedDB, adressage par contenu ---------------------------------------------------------------- */
  var backend = null, memFiles = {};
  function idb() {
    if (backend) return backend;
    backend = new Promise(function (ok, ko) {
      if (typeof indexedDB === 'undefined') return ko(new Error('idb'));
      var r = indexedDB.open('exb_mep', 1); r.onupgradeneeded = function () { r.result.createObjectStore('files'); }; r.onsuccess = function () { ok(r.result); }; r.onerror = function () { ko(r.error); };
    }).catch(function () { return null; });
    return backend;
  }
  function tx(db, mode, fn) { return new Promise(function (ok, ko) { var t = db.transaction('files', mode), st = t.objectStore('files'), res = fn(st); t.oncomplete = function () { ok(res && res.result); }; t.onerror = function () { ko(t.error); }; t.onabort = function () { ko(t.error || new Error('abort')); }; }); }
  async function sha256(bytes) {
    var c = (g.crypto && g.crypto.subtle) ? g.crypto : (typeof require !== 'undefined' ? require('crypto').webcrypto : null);
    var d = await c.subtle.digest('SHA-256', bytes); return Array.prototype.map.call(new Uint8Array(d), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  /* put-once : si l'empreinte existe déjà, rien n'est réécrit (immuabilité) ; renvoie true si c'est un nouvel enregistrement. */
  async function putLocal(sha, bytes) {
    var db = await idb(); if (!db) { if (memFiles[sha]) return false; memFiles[sha] = new Uint8Array(bytes); return true; }
    var had = await tx(db, 'readonly', function (st) { return st.count(sha); }); if (had) return false;
    await tx(db, 'readwrite', function (st) { return st.add(new Uint8Array(bytes), sha); }); return true;
  }
  async function getLocal(sha) { var db = await idb(); if (!db) return memFiles[sha] ? new Uint8Array(memFiles[sha]) : null; var v = await tx(db, 'readonly', function (st) { return st.get(sha); }); return v ? new Uint8Array(v) : null; }
  async function hasLocal(sha) { var db = await idb(); if (!db) return !!memFiles[sha]; return !!(await tx(db, 'readonly', function (st) { return st.count(sha); })); }

  /* ---------------------------------------------------------------- V214 : copie serveur des fichiers ----------------------------------------------------------------
   * Fiches (documents, versions, journal, modèles) : synchronisées par la base partagée (exb-db.js, collections mep_*).
   * Fichiers PDF : copiés dans l'espace PRIVÉ « exb-atelier » du serveur, sous <organisation>/<empreinte>.pdf. Le nom EST l'empreinte SHA-256 :
   * un fichier n'est jamais remplacé (envoi sans écrasement) et, à la réception, l'empreinte est recalculée avant de l'accepter. */
  var BK = 'exb-atelier', UPK = 'exb_mep_up_v214', upBusy = false;
  function sbo() { try { var s = H('exbSb'), i = infoDB(); return (s && s.isIn && s.isIn() && s.api && i && i.on && i.org && (typeof navigator === 'undefined' || navigator.onLine !== false)) ? { s: s, org: i.org } : null; } catch (e) { return null; } }
  function rpath(o, sha) { return o.org + '/' + sha + '.pdf'; }
  function upList() { try { return JSON.parse(g.localStorage.getItem(UPK) || '[]') || []; } catch (e) { return []; } }
  function upMark(sha) { try { var l = upList(); if (l.indexOf(sha) < 0) { l.push(sha); g.localStorage.setItem(UPK, JSON.stringify(l)); } } catch (e) {} }
  async function pushFile(sha) {
    var o = sbo(); if (!o) return false; var b = await getLocal(sha); if (!b) return false;
    try { await o.s.api('/storage/v1/object/' + BK + '/' + rpath(o, sha), { method: 'POST', headers: { 'Content-Type': 'application/pdf' }, body: new Blob([b], { type: 'application/pdf' }) }); }
    catch (e) { if (!/already exists|duplicate|exist/i.test(String(e && e.message || ''))) return false; }
    upMark(sha); return true;
  }
  /* envoie au serveur tous les fichiers (originaux et versions) qui n'y sont pas encore ; renvoie le nombre envoyé */
  async function syncFichiers() {
    if (upBusy || !sbo()) return 0; upBusy = true; var n = 0;
    try {
      var done = upList(), want = {}; docs().forEach(function (d) { if (d.sha256) want[d.sha256] = 1; }); rd(K.vers, []).forEach(function (v) { if (v.sha256) want[v.sha256] = 1; });
      var all = Object.keys(want).filter(function (s) { return done.indexOf(s) < 0; });
      for (var i = 0; i < all.length; i++) { if (await pushFile(all[i])) n++; }
    } catch (e) {} upBusy = false; return n;
  }
  async function pullFile(sha) {
    var o = sbo(); if (!o) return null;
    try {
      var r = await o.s.api('/storage/v1/object/sign/' + BK + '/' + rpath(o, sha), { method: 'POST', body: JSON.stringify({ expiresIn: 300 }) });
      var rs = await fetch(o.s.cfg().url + '/storage/v1' + r.signedURL); if (!rs.ok) return null;
      var b = new Uint8Array(await rs.arrayBuffer()); if ((await sha256(b)) !== sha) return null;   /* empreinte différente : refusé */
      await putLocal(sha, b); upMark(sha); return b;
    } catch (e) { return null; }
  }
  async function putFile(sha, bytes) { var r = await putLocal(sha, bytes); try { pushFile(sha); } catch (e) {} return r; }
  async function getFile(sha) { var b = await getLocal(sha); return b || (await pullFile(sha)); }
  async function hasFile(sha) { if (await hasLocal(sha)) return true; var o = sbo(); if (!o) return false; return !!(await pullFile(sha)); }

  /* ---------------------------------------------------------------- acteur, droits ---------------------------------------------------------------- */
  function actor() {
    var n = ''; try { n = (g.localStorage && g.localStorage.getItem('exb_be_signataire')) || ''; } catch (e) {}
    var u = null; try { u = H('EXB_CORE') && H('EXB_CORE').user && H('EXB_CORE').user(); } catch (e) {}
    return { nom: (u && u.nom) || n || '', role: (u && u.role) || '', fonction: (u && u.fonction) || '' };
  }
  function setNom(n) { try { g.localStorage.setItem('exb_be_signataire', n); } catch (e) {} }
  function act(a) { try { var A = H('EXBAction'); return A && A.can ? !!A.can(a) : true; } catch (e) { return true; } }
  function infoDB() { try { var D = H('EXBDB'); return D && D.info ? D.info() : null; } catch (e) { return null; } }
  function habilite() { var i = infoDB(); if (!i || !i.on) return true; return i.role === 'admin' || i.fonction === 'bureau_etudes' || i.fonction === 'direction'; }
  function norm(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  /* accès par document : liste vide = tous ceux qui ont le module ; sinon nom ou « fonction: … » (contrôle côté écran, comme les Archives) */
  function visible(doc) {
    var a = doc && doc.acces; if (!a || !a.length) return true; var i = infoDB(); if (!i || !i.on || i.role === 'admin') return true;
    var me = actor(); return a.some(function (x) { var m = /^(fonction|role|rôle)\s*:\s*(.+)$/i.exec(String(x)); return m ? norm(m[2]) === norm(me.fonction) || norm(m[2]) === norm(me.role) : norm(x) === norm(me.nom); });
  }

  /* ---------------------------------------------------------------- données ---------------------------------------------------------------- */
  function docs() { return rd(K.docs, []); }
  function getDoc(id) { return docs().filter(function (d) { return d.id === id; })[0] || null; }
  function putDoc(d) { var a = docs(), i = a.findIndex(function (x) { return x.id === d.id; }); if (i >= 0) a[i] = d; else a.push(d); return wr(K.docs, a); }
  function versions(docId) { var v = rd(K.vers, []); return docId ? v.filter(function (x) { return x.doc === docId; }) : v; }
  function journal(docId) { var j = rd(K.jrn, []); return docId ? j.filter(function (x) { return x.doc === docId; }) : j; }
  function modelesPerso() { return rd(K.mod, []); }
  function setModeles(m) { return wr(K.mod, m); }
  function config() { return Object.assign({ conservationAns: 10 }, rd(K.cfg, {})); }
  function setConfig(c) { return wr(K.cfg, Object.assign(config(), c)); }

  function log(action, d, o) {
    o = o || {}; var a = actor(), e = { id: uid('JRN'), t: Date.now(), par: o.par || a.nom || '(non identifié)', action: action, doc: d ? d.id : '', nom: d ? d.nom : '', modele: o.modele || (d && d.config && d.config.modele) || '', champs: o.champs || [], statut: o.statut || (d && d.statut) || '', ref: o.ref || '', detail: o.detail || '' };
    var j = rd(K.jrn, []); j.unshift(e); wr(K.jrn, j.slice(0, 20000));
    try { var Co = H('EXBCore') || H('EXB_CORE'); if (Co && Co.audit) { if (Co.audit.log) Co.audit.log('mep.' + action, e.nom, { doc: e.doc, statut: e.statut, ref: e.ref, modele: e.modele }); else if (typeof Co.audit === 'function') Co.audit('mep.' + action, e.nom + (e.detail ? ' — ' + e.detail : ''), 'atelier-mep', e.doc); } } catch (er) {}
    return e;
  }

  /* Création de la fiche à l'import : l'original est rangé ici, jamais modifié ensuite. */
  async function creerDoc(o) {
    var sha = await sha256(o.bytes), neuf = await putFile(sha, o.bytes), a = actor();
    var d = { id: uid('MEP'), nom: o.nom, taille: o.bytes.length, sha256: sha, importeLe: Date.now(), importePar: a.nom, analyse: o.analyse || null, classement: { projet_id: '', projet: '', client: '', discipline: '', type: 'plan' },
      config: { modele: 'plan', mode: 'auto', cartoucheExistant: '', champs: {}, options: {} }, statut: 'Brouillon', workflow: { auteur: '' }, rev: 0, acces: [], ocr: null };
    putDoc(d); log('import', d, { detail: neuf ? sha.slice(0, 12) : 'déjà archivé (' + sha.slice(0, 12) + ')', ref: sha }); return d;
  }

  /* ---------------------------------------------------------------- circuit de validation ---------------------------------------------------------------- */
  function bloquants(d) { return C.manquants(d.config.champs).map(function (m) { return 'Champ obligatoire à compléter : ' + m.libelle; }); }
  function res(ok, msg, d) { return { ok: ok, msg: msg || '', doc: d || null }; }
  function soumettre(d, nom) {
    if (d.statut !== 'Brouillon' && d.statut !== 'À corriger') return res(false, 'Seul un brouillon ou un document « À corriger » peut être soumis.');
    if (!act('soumettre')) return res(false, 'Votre profil n’a pas le droit « soumettre ».');
    var b = bloquants(d); if (b.length) return res(false, b.length + ' champ(s) obligatoire(s) à compléter : ' + b.map(function (x) { return x.replace('Champ obligatoire à compléter : ', ''); }).join(', ') + '.');
    if (!nom) return res(false, 'Nom du signataire requis.');
    d.workflow = { auteur: nom, soumis: { par: nom, t: Date.now() } }; d.statut = 'Pour vérification'; putDoc(d); log('soumis', d, { par: nom }); return res(true, '', d);
  }
  function verifier(d, nom, ok, texte) {
    if (d.statut !== 'Pour vérification') return res(false, 'Le document n’est pas en attente de vérification.');
    if (!nom) return res(false, 'Nom du vérificateur requis.');
    if (norm(nom) === norm(d.workflow.auteur)) return res(false, 'Le vérificateur doit être une autre personne que l’auteur (' + d.workflow.auteur + ').');
    if (!String(texte || '').trim()) return res(false, ok ? 'Précisez ce qui a été contrôlé.' : 'Les corrections demandées doivent être motivées.');
    if (ok) { if (!act('approuver') && !act('rejeter')) return res(false, 'Votre profil n’a pas le droit de vérifier.'); d.workflow.verif = { par: nom, t: Date.now(), commentaire: texte }; log('verifie', d, { par: nom, detail: texte }); }
    else { if (!act('rejeter')) return res(false, 'Votre profil n’a pas le droit « rejeter » (demander des corrections).'); d.statut = 'À corriger'; d.workflow.rejet = { par: nom, t: Date.now(), motif: texte }; log('a-corriger', d, { par: nom, detail: texte }); }
    putDoc(d); return res(true, '', d);
  }
  function approuver(d, nom, ok, texte) {
    if (d.statut !== 'Pour vérification') return res(false, 'Le document doit être « Pour vérification ».');
    if (!d.workflow.verif && ok) return res(false, 'Le document doit d’abord être vérifié.');
    if (!act('approuver')) return res(false, 'Votre profil n’a pas le droit « approuver ».');
    if (!habilite()) return res(false, 'L’approbation est réservée à un responsable habilité (fonction Ingénieur / Direction) ou à l’administrateur.');
    if (!nom) return res(false, 'Nom requis.'); if (norm(nom) === norm(d.workflow.auteur)) return res(false, 'L’approbateur doit être une autre personne que l’auteur.');
    if (!ok) { if (!String(texte || '').trim()) return res(false, 'Un refus doit être motivé.'); d.statut = 'À corriger'; d.workflow.rejet = { par: nom, t: Date.now(), motif: texte }; log('refuse', d, { par: nom, detail: texte }); }
    else { d.statut = 'Approuvé'; d.workflow.approuve = { par: nom, t: Date.now(), commentaire: texte || '' }; log('approuve', d, { par: nom, detail: texte || '' }); }
    putDoc(d); return res(true, '', d);
  }
  function peutEmettre(d) { return d.statut === 'Approuvé' && act('approuver') && habilite() && act('exporter'); }
  function nouvelleRevision(d, nom, motif) {
    if (d.statut !== 'Émis') return res(false, 'Seul un document émis peut faire l’objet d’une nouvelle révision.'); if (!String(motif || '').trim()) return res(false, 'Précisez le motif de la révision.');
    var y = clone(d); y.id = uid('MEP'); y.rev = d.rev + 1; y.statut = 'Brouillon'; y.workflow = { auteur: '' }; y.config.champs.indice = C.indiceDe(y.rev); y.precedent = d.id; y.importeLe = Date.now();
    putDoc(y); log('revision', y, { par: nom, detail: 'Révision ' + y.rev + ' de ' + d.nom + ' : ' + motif }); d.remplace = y.id; putDoc(d); return res(true, '', y);
  }

  /* ---------------------------------------------------------------- versions produites ---------------------------------------------------------------- */
  async function ajouterVersion(d, o) {
    var sha = await sha256(o.bytes); await putFile(sha, o.bytes);
    var n = versions(d.id).length + 1, a = actor(), cfg = config(), t = Date.now(), fin = new Date(t); fin.setFullYear(fin.getFullYear() + (+cfg.conservationAns || 10));
    var v = { id: uid('VER'), doc: d.id, n: n, tag: 'v' + n, t: t, par: o.par || a.nom, statut: o.statut || d.statut, modele: d.config.modele, champs: clone(d.config.champs), config: clone(d.config), sha256: sha, taille: o.bytes.length, nbPages: o.nbPages || 0, originalSha: d.sha256, nom: o.nomFichier, notes: o.notes || [], integrite: o.integrite || null, conserveJusquau: fin.toISOString().slice(0, 10) };
    var all = rd(K.vers, []); all.push(v); wr(K.vers, all);
    if (v.statut === 'Émis' && d.statut === 'Approuvé') { d.statut = 'Émis'; d.workflow.emis = { par: v.par, t: t }; putDoc(d); }
    log(v.statut === 'Émis' ? 'emis' : 'export', d, { par: v.par, statut: v.statut, ref: sha, champs: o.champsModifies || [], detail: v.tag + ' — ' + v.nom }); return v;
  }
  /* Vérifie que les octets rangés correspondent encore à l'empreinte enregistrée. */
  async function verifierIntegrite(sha) { var b = await getFile(sha); if (!b) return { ok: false, msg: 'Fichier absent du stockage.' }; var h = await sha256(b); return h === sha ? { ok: true } : { ok: false, msg: 'Empreinte différente : fichier altéré.' }; }
  function champsModifies(avant, apres) { var o = []; Object.keys(Object.assign({}, avant, apres)).forEach(function (k) { if (String((avant || {})[k] || '') !== String((apres || {})[k] || '')) o.push(k); }); return o; }

  NS.version = { syncFichiers: syncFichiers, K: K, sha256: sha256, putFile: putFile, getFile: getFile, hasFile: hasFile, actor: actor, setNom: setNom, act: act, habilite: habilite, visible: visible, docs: docs, getDoc: getDoc, putDoc: putDoc, versions: versions, journal: journal, modelesPerso: modelesPerso, setModeles: setModeles, config: config, setConfig: setConfig, log: log, creerDoc: creerDoc, soumettre: soumettre, verifier: verifier, approuver: approuver, peutEmettre: peutEmettre, nouvelleRevision: nouvelleRevision, ajouterVersion: ajouterVersion, verifierIntegrite: verifierIntegrite, champsModifies: champsModifies, norm: norm };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.version;
})(typeof window !== 'undefined' ? window : globalThis);
