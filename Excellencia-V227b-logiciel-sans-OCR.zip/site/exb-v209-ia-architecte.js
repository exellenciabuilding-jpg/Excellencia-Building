/* Excellencia Building V209l — ARCHITECTURE : IA Architecte (assistant spécialisé, DÉTERMINISTE).
 * Cahier des charges Évolution ERP V1.0, §7 : « IA Architecte – structurer programme, comparer variantes, lire pièces, signaler omissions et préparer
 * synthèses. Contrôle obligatoire : l'architecte valide conception et conformité. L'assistant exploite uniquement les données auxquelles
 * l'utilisateur a droit et indique les sources utilisées. »
 *
 * Choix de conception : AUCUN modèle génératif, aucune clé, aucun envoi de données. Chaque phrase produite vient d'un calcul ou d'un contrôle sur les
 * données de l'ERP et porte sa SOURCE (module, nombre de lignes). Lecture seule : ce module n'écrit dans aucune collection.
 *  • SYNTHÈSE du projet : programme et surfaces (V209e), site (V209i), réglementation (V209f), coordination (V209g), matériaux (V209j), règles IDS (V209k).
 *  • OMISSIONS : contrôles croisés entre modules (terrain du programme ≠ superficie du site, locaux sans finition, collisions non traitées, règles à
 *    paramétrer, prix manquants, aucune variante retenue...), classées par importance, chacune avec sa source et l'action à faire. Un module auquel
 *    l'utilisateur n'a pas droit n'est ni lu ni commenté (« non accessible »). Un module absent de l'installation est signalé « non disponible ».
 *  • VARIANTES : tableau comparatif brut (surface, rendement, coût, CES, COS, écarts, alertes) SANS recommandation : l'architecte et le client décident.
 *  • PROGRAMME depuis un texte : un cahier des charges collé (« 3 chambres 12 m² », « Salon : 30 m² ») est découpé en locaux PROPOSÉS ; rien n'est
 *    enregistré par ce module : les lignes validées s'exportent en CSV pour être saisies / importées dans « Programme & surfaces ».
 *  • Assistant : phrases « synthèse du projet architecture », « omissions du projet », « compare les variantes » (lecture seule).
 * Hypothèses sur les données (à confirmer avec V209e/V209f, absents du lot fourni) : lignes de exb_arch_prog { type:'cadre', terrain } ; variantes
 * { type:'variante', nom, surface, rendement, cout, ces, cos, retenue } ; locaux lus via EXBARCP.calc(...).rows { id, nom, niveau, cible, proj } si présent.
 * Fonctions pures (analyse, parseProgramme, variantes) testées dans tools/test-ia-architecte.js. */
(function (w, d) {
  'use strict';
  if (w.EXBIAARCH) return;
  var K = { prog: 'exb_arch_prog', reg: 'exb_arch_reg', coord: 'exb_arch_coord', site: 'exb_arch_site', mat: 'exb_arch_mat', ids: 'exb_arch_ids' };
  var COLS = { prog: 'arch_programme', reg: 'arch_reglementation', coord: 'arch_coordination', site: 'arch_site', mat: 'arch_materiaux', ids: 'arch_ids' };
  var SRC = { prog: 'Programme & surfaces', reg: 'Contrôle réglementaire', coord: 'Coordination IFC / BCF', site: 'Analyse de site', mat: 'Matériaux & finitions', ids: 'Règles IDS' };
  var st = { pid: '', tab: 'synthese', brief: '', props: [], out: [] };

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function s(v, n) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n); }
  function num(v, def) { var n = Number(String(v == null ? '' : v).replace(',', '.')); return (v === '' || v == null || isNaN(n)) ? (def === undefined ? 0 : def) : n; }
  function has(v) { return v !== '' && v != null && !isNaN(Number(String(v).replace(',', '.'))); }
  function fm(n, dg) { return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: dg == null ? 1 : dg }).format(n || 0); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); } catch (e) { } }
  function can(k) { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COLS[k], 'lire'); } catch (e) { return true; } }
  function projs() { try { return w.EXBS.projects() || []; } catch (e) { return []; } }
  function get(k) { try { return w.EXBS.get(K[k]) || []; } catch (e) { return []; } }
  function mine(a, pid) { return a.filter(function (x) { return String(x.project) === String(pid); }); }
  function today() { return new Date().toISOString().slice(0, 10); }

  /* ---------- Programme depuis un texte (pur) ---------- */
  function parseProgramme(text) {
    var rooms = [], ignored = [];
    String(text || '').slice(0, 20000).split(/\n|;|,(?!\d)/).forEach(function (l) {
      l = l.trim(); if (!l) return;
      var m = l.match(/^(\d+)\s*(?:x\s*)?([^\d:]+?)\s+(?:de\s+)?(\d+(?:[.,]\d+)?)\s*m[²2]/i), q, n, sf;
      if (m) { q = Number(m[1]); n = m[2]; sf = num(m[3]); }
      else if ((m = l.match(/^([^:\d][^:]*?)\s*[:=\-]\s*(\d+(?:[.,]\d+)?)\s*m[²2]/i))) { q = 1; n = m[1]; sf = num(m[2]); }
      else { ignored.push(l); return; }
      rooms.push({ nom: s(n, 80).replace(/^\w/, function (c) { return c.toUpperCase(); }), qty: q, surface: sf, total: q * sf });
    });
    return { rooms: rooms, ignored: ignored };
  }

  /* ---------- Lecture des données autorisées ---------- */
  function roomsOf(items) { try { return w.EXBARCP && w.EXBARCP.calc ? (w.EXBARCP.calc(items, 'base').rows || []) : null; } catch (e) { return null; } }
  function pdata(pid) {
    var D = { pid: pid, mods: {} };
    Object.keys(K).forEach(function (k) { D[k] = can(k) ? mine(get(k), pid) : null; });
    D.progAll = D.prog; D.rooms = D.prog === null ? null : roomsOf(D.prog);
    D.mats = can('mat') ? get('mat').filter(function (x) { return x.type === 'mat'; }) : null; /* bibliothèque commune à l'entreprise */
    D.specs = D.mat === null ? null : D.mat.filter(function (x) { return x.type === 'spec'; });
    D.regles = D.ids === null ? null : (get('ids').filter(function (x) { return x.type === 'regles'; })[0] || { specs: [] });
    D.runs = D.ids === null ? null : D.ids.filter(function (x) { return x.type === 'run'; }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
    return D;
  }
  function siteArea(D) {
    var r = D.site && D.site.filter(function (x) { return x.type === 'site'; })[0]; if (!r || !w.EXBSITE || !w.EXBSITE.analyse) return null;
    try { var R = w.EXBSITE.analyse(r); return R && R.ok ? R.superficie : null; } catch (e) { return null; }
  }
  function matCalc(D) { try { return w.EXBMAT && w.EXBMAT.calcul && D.mats ? w.EXBMAT.calcul(D.mats, D.specs || [], D.rooms || [], today()) : null; } catch (e) { return null; } }
  function variantes(D) {
    if (D.prog === null) return null;
    var cible = (D.rooms || []).reduce(function (a, r) { return a + num(r.cible); }, 0);
    return D.prog.filter(function (x) { return x.type === 'variante'; }).map(function (x) {
      var al = [], surf = num(x.surface);
      ['surface', 'cout', 'ces', 'cos'].forEach(function (c) { if (!has(x[c])) al.push(c + ' non renseigné'); });
      return { nom: s(x.nom || x.name, 120), surface: surf, rendement: num(x.rendement), cout: num(x.cout), ces: num(x.ces), cos: num(x.cos), ecart: cible && has(x.surface) ? surf - cible : null, alertes: al, retenue: !!x.retenue };
    });
  }

  /* ---------- Synthèse et omissions (purs sur D) ---------- */
  function synthese(D) {
    var o = [];
    function add(k, txt, extra) { o.push({ txt: SRC[k] + ' : ' + (D[k] === null ? 'non accessible' : txt), src: SRC[k] + (D[k] === null ? '' : ' (' + D[k].length + ' ligne(s))'), extra: extra }); }
    add('prog', D.rooms ? D.rooms.length + ' local(aux), surface cible ' + fm(D.rooms.reduce(function (a, r) { return a + num(r.cible); }, 0)) + ' m²' : D.prog && D.prog.length ? D.prog.length + ' ligne(s) ; calcul des surfaces non disponible (module « Programme & surfaces » absent)' : 'aucune donnée');
    var A = D.site === null ? null : siteArea(D);
    add('site', A != null ? 'superficie du terrain ' + fm(A) + ' m²' : D.site && D.site.length ? 'données saisies, superficie non calculable' : 'aucune donnée');
    add('reg', (D.reg ? D.reg.length : 0) + ' règle(s) / contrôle(s)');
    var cl = D.coord && D.coord.filter(function (x) { return x.type === 'clash'; }); add('coord', D.coord === null ? '' : cl.length + ' collision(s), dont ' + cl.filter(function (x) { return x.statut === 'résolu' || x.statut === 'ignoré'; }).length + ' traitée(s) ou écartée(s)');
    var mc = matCalc(D); add('mat', D.specs ? D.specs.filter(function (x) { return String(x.project) === String(D.pid); }).length + ' spécification(s) du projet' + (mc ? ', coût indicatif ' + fm(mc.total, 0) : '') : '');
    add('ids', D.regles ? D.regles.specs.length + ' règle(s) IDS' + (D.runs && D.runs[0] ? ', dernière vérification le ' + String(D.runs[0].date).slice(0, 10) : ', jamais vérifiée') : '');
    return o;
  }
  function omissions(D) {
    var o = [], P = D.pid;
    function add(imp, titre, k, action) { o.push({ imp: imp, titre: titre, src: SRC[k] + (D[k] ? ' (' + D[k].length + ' ligne(s))' : ''), action: action }); }
    ['prog', 'site', 'reg', 'coord', 'mat', 'ids'].forEach(function (k) { if (D[k] === null) o.push({ imp: 0, titre: SRC[k] + ' : non accessible', src: SRC[k], action: 'Demander l\'accès à ce module pour le contrôler' }); });
    if (D.prog !== null) {
      if (!D.prog.length) add(3, 'Aucun programme saisi pour ce projet', 'prog', 'Saisir le tableau des surfaces (ou importer le cahier des charges)');
      else if (D.rooms === null) add(1, 'Locaux et surfaces non contrôlables : module « Programme & surfaces » absent', 'prog', 'Installer le module V209e');
      else { var sans = D.rooms.filter(function (r) { return !has(r.cible) || !num(r.cible); }); if (sans.length) add(2, sans.length + ' local(aux) sans surface cible', 'prog', 'Renseigner : ' + sans.slice(0, 5).map(function (r) { return r.nom; }).join(', ')); }
      var vs = D.prog.filter(function (x) { return x.type === 'variante'; }); if (vs.length && !vs.some(function (x) { return x.retenue; })) add(2, 'Aucune variante retenue (' + vs.length + ' variante(s))', 'prog', 'Faire décider l\'architecte et le client');
    }
    if (D.site !== null) {
      var A = siteArea(D); if (!D.site.length) add(1, 'Aucune analyse de site', 'site', 'Saisir limites, orientation, topographie');
      var cadre = D.prog && D.prog.filter(function (x) { return x.type === 'cadre'; })[0], t = cadre && num(cadre.terrain);
      if (A != null && t && Math.abs(t - A) / A > 0.005) o.push({ imp: 3, titre: 'Terrain du programme (' + fm(t) + ' m²) ≠ superficie du site (' + fm(A) + ' m²)', src: SRC.prog + ' ↔ ' + SRC.site, action: 'Corriger l\'une des deux valeurs (report possible depuis l\'analyse de site)' });
    }
    if (D.coord !== null) { var ouv = D.coord.filter(function (x) { return x.type === 'clash' && x.statut !== 'résolu' && x.statut !== 'ignoré'; }); if (ouv.length) add(3, ouv.length + ' collision(s) non traitée(s)', 'coord', 'Traiter, assigner ou clore dans Coordination IFC / BCF'); }
    if (D.reg !== null && !D.reg.length) add(2, 'Aucune règle réglementaire paramétrée', 'reg', 'Paramétrer les règles du pays / de la commune / du projet');
    if (D.specs !== null && D.rooms) {
      var sp = D.specs.filter(function (x) { return String(x.project) === String(P); }), fin = {}; sp.forEach(function (x) { if (x.local) fin[x.local] = 1; });
      var nof = D.rooms.filter(function (r) { return !fin[r.id]; }); if (nof.length) add(2, nof.length + ' local(aux) sans finition', 'mat', 'Affecter des finitions : ' + nof.slice(0, 5).map(function (r) { return r.nom; }).join(', '));
    }
    var mc = matCalc(D); if (mc && mc.sansPrix) add(2, mc.sansPrix + ' ligne(s) de finition sans prix (total partiel)', 'mat', 'Renseigner les prix unitaires dans la bibliothèque');
    if (D.regles) {
      if (!D.regles.specs.length) add(1, 'Aucune règle IDS enregistrée', 'ids', 'Importer ou créer des règles IDS');
      else if (D.runs && !D.runs.length) add(1, 'Règles IDS jamais vérifiées sur ce projet', 'ids', 'Lancer la vérification sur les modèles IFC');
      else if (D.runs && D.runs[0] && (D.runs[0].res || []).some(function (x) { return x.status === 'non_conforme'; })) add(3, 'Dernière vérification IDS : écarts constatés', 'ids', 'Corriger les modèles ou revoir les règles, puis revérifier');
      else if (D.runs && D.runs[0] && (D.runs[0].res || []).some(function (x) { return x.status === 'non_verifiable'; })) add(1, 'Dernière vérification IDS : facettes non vérifiables', 'ids', 'Contrôler ces points avec un outil IDS tiers');
    }
    return o.sort(function (a, b) { return b.imp - a.imp; });
  }
  function analyse(pid) { var D = pdata(pid); return { synthese: synthese(D), omissions: omissions(D), variantes: variantes(D) }; }
  function ask(q, pid) {
    q = String(q || '').toLowerCase(); var A = analyse(pid), L = [];
    if (/omission/.test(q)) A.omissions.forEach(function (x) { L.push('[' + x.imp + '] ' + x.titre + ' — source : ' + x.src + ' — action : ' + x.action); });
    else if (/variante/.test(q)) (A.variantes || []).forEach(function (v) { L.push(v.nom + ' : ' + fm(v.surface) + ' m², rendement ' + fm(v.rendement) + ', coût ' + fm(v.cout, 0) + ', CES ' + fm(v.ces, 2) + ', COS ' + fm(v.cos, 2) + (v.alertes.length ? ' ⚠ ' + v.alertes.join(', ') : '')); });
    else if (/synth/.test(q)) A.synthese.forEach(function (x) { L.push(x.txt + ' — source : ' + x.src); });
    else return ['Phrases comprises : « synthèse du projet architecture », « omissions du projet », « compare les variantes ».'];
    return L.length ? L : ['Rien à signaler dans les données accessibles.'];
  }

  /* ---------- Interface ---------- */
  function box() { return d.getElementById('exbIaArchBox'); }
  function btn(t, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + t + '</button>'; }
  function body() {
    if (!st.pid) return '<p>Choisissez un projet.</p>';
    var A = analyse(st.pid), h = '';
    if (st.tab === 'synthese') h = '<ul style="font-size:13px">' + A.synthese.map(function (x) { return '<li>' + esc(x.txt) + ' <small style="color:#64748b">(source : ' + esc(x.src) + ')</small></li>'; }).join('') + '</ul>';
    else if (st.tab === 'omissions') h = A.omissions.length ? '<ol style="font-size:13px">' + A.omissions.map(function (x) { return '<li style="margin:6px 0"><b>' + esc(x.titre) + '</b><br><small>Source : ' + esc(x.src) + ' — Action : ' + esc(x.action) + '</small></li>'; }).join('') + '</ol>' : '<p>Aucune omission détectée dans les données accessibles.</p>';
    else if (st.tab === 'variantes') h = A.variantes && A.variantes.length ? '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr><th align="left">Variante</th><th>Surface</th><th>Rendement</th><th>Coût</th><th>CES</th><th>COS</th><th>Écart / cible</th><th align="left">Alertes</th></tr>' + A.variantes.map(function (v) { return '<tr style="border-top:1px solid #e2e8f0"><td>' + esc(v.nom) + (v.retenue ? ' ✔' : '') + '</td><td align="right">' + fm(v.surface) + '</td><td align="right">' + fm(v.rendement) + '</td><td align="right">' + fm(v.cout, 0) + '</td><td align="right">' + fm(v.ces, 2) + '</td><td align="right">' + fm(v.cos, 2) + '</td><td align="right">' + (v.ecart == null ? '—' : fm(v.ecart)) + '</td><td>' + esc(v.alertes.join(', ')) + '</td></tr>'; }).join('') + '</table></div><p style="font-size:12px;color:#475569">Comparatif brut : aucune recommandation, l\'architecte et le client décident.</p>' : '<p>Aucune variante enregistrée (ou module non accessible).</p>';
    else if (st.tab === 'prog') {
      h = '<textarea id="iaBrief" rows="5" style="width:100%;box-sizing:border-box;padding:6px" placeholder="3 chambres 12 m², Salon : 30 m²">' + esc(st.brief) + '</textarea>' + btn('Proposer les locaux', 'parse');
      if (st.props.length) h += '<ul style="font-size:13px;list-style:none;padding:0">' + st.props.map(function (r, i) { return '<li><label><input type="checkbox" data-p="' + i + '" checked> ' + r.qty + ' × ' + esc(r.nom) + ' — ' + fm(r.surface) + ' m² (total ' + fm(r.total) + ')</label></li>'; }).join('') + '</ul>' + btn('Exporter les lignes validées (CSV)', 'csv', null, '#0369a1') + '<p style="font-size:12px;color:#475569">Rien n\'est enregistré : saisissez ou importez ces lignes dans « Programme & surfaces » après relecture.</p>';
    } else h = '<input id="iaQ" placeholder="omissions du projet" style="padding:8px;width:70%">' + btn('Demander', 'ask') + '<ul style="font-size:13px">' + st.out.map(function (l) { return '<li>' + esc(l) + '</li>'; }).join('') + '</ul>';
    return h;
  }
  function paint() {
    var b = box(); if (!b) return;
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><b style="align-self:center;margin-right:8px">🧠 IA Architecte</b>' + [['synthese', 'Synthèse'], ['omissions', 'Omissions'], ['variantes', 'Variantes'], ['prog', 'Programme (texte)'], ['chat', 'Assistant']].map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:8px;background:' + (st.tab === t[0] ? '#0f766e;color:#fff' : '#e2e8f0') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>'
      + '<p style="font-size:12px;color:#475569;margin:4px 0">Assistant déterministe : aucun modèle génératif, aucune donnée envoyée. Chaque ligne cite sa source ; l\'architecte valide conception et conformité.</p>'
      + '<label>Projet <select id="iaPid" style="padding:6px"><option value="">—</option>' + projs().map(function (p) { return '<option value="' + esc(p.id) + '"' + (String(p.id) === String(st.pid) ? ' selected' : '') + '>' + esc(p.nom || p.name || p.titre || p.title || p.id) + '</option>'; }).join('') + '</select></label>' + body();
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i');
    if (a === 'close') { var o = d.getElementById('exbIaArch'); if (o) o.remove(); return; }
    if (a === 'tab') { st.tab = i; return paint(); }
    if (a === 'parse') { st.brief = d.getElementById('iaBrief').value; var p = parseProgramme(st.brief); st.props = p.rooms; if (p.ignored.length) say(p.ignored.length + ' ligne(s) non reconnue(s)', 'error'); return paint(); }
    if (a === 'ask') { st.out = ask(d.getElementById('iaQ').value, st.pid); return paint(); }
    if (a === 'csv') {
      var rows = [['Local', 'Quantité', 'Surface unitaire m2', 'Total m2']], bx = box().querySelectorAll('input[data-p]');
      for (var k = 0; k < bx.length; k++) if (bx[k].checked) { var r = st.props[Number(bx[k].getAttribute('data-p'))]; rows.push([r.nom, r.qty, r.surface, r.total]); }
      var txt = '\ufeff' + rows.map(function (r) { return r.map(function (c) { c = String(c); if (/^[=+\-@]/.test(c)) c = "'" + c; return '"' + c.replace(/"/g, '""') + '"'; }).join(';'); }).join('\r\n'), l = d.createElement('a');
      l.href = URL.createObjectURL(new Blob([txt], { type: 'text/csv' })); l.download = 'programme-propose.csv'; d.body.appendChild(l); l.click(); setTimeout(function () { URL.revokeObjectURL(l.href); l.remove(); }, 500);
    }
  }
  function open() {
    if (!st.pid) { var P = projs(); st.pid = (function () { try { return localStorage.getItem('exb_active_project'); } catch (e) { return ''; } })() || (P[0] && P[0].id) || ''; }
    var o = d.getElementById('exbIaArch'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbIaArch'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbIaArchBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('click', onClick); c.addEventListener('change', function (e) { if (e.target.id === 'iaPid') { st.pid = e.target.value; st.out = []; paint(); } }); paint();
  }
  var API = { open: open, analyse: analyse, synthese: synthese, omissions: omissions, variantes: variantes, parseProgramme: parseProgramme, ask: ask, pdata: pdata };
  w.EXBIAARCH = API;
  function ui() {
    var b = d.getElementById('exbIdsBtn') || d.getElementById('exbMatBtn') || d.getElementById('exbSiteBtn') || d.getElementById('exbCoordBtn') || d.getElementById('exbArcPBtn') || d.getElementById('exbArcBtn');
    if (!b || d.getElementById('exbIaArchBtn')) return;
    var k = d.createElement('button'); k.id = 'exbIaArchBtn'; k.className = 'muted'; k.textContent = '🧠 IA Architecte'; k.onclick = open; b.parentNode.appendChild(k);
  }
  if (d.documentElement && w.MutationObserver) { new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true }); d.addEventListener('DOMContentLoaded', ui); }
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'ia_architecte', name: 'IA Architecte', version: '1.0.0', area: 'Architecture', deps: [], collections: [] }); } catch (e) { }
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { documentElement: null, getElementById: function () { return null; }, addEventListener: function () { } });
