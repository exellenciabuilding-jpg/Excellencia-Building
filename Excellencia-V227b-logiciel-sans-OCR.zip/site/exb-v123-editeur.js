/* Excellencia Building V124 — ÉDITEUR « FAÇON WORD » pour les pièces écrites et les documents de chantier (notes, comptes rendus, lettres, PV, OS…).
 * V123 : feuille A4 éditable + ruban. V124 : ruban à onglets comme la maquette (Fichier · Accueil · Insertion · Mise en page · Références · Révision · Affichage · Aide),
 * groupes Presse-papiers / Police / Paragraphe / Styles / Insertion, règle, barre d'état (page, mots, langue, zoom), en-tête de société sur la feuille,
 * et les fonctions qui manquaient : barré, indice, exposant, surlignage, interligne, retraits et listes à plusieurs niveaux, images, liens, symboles,
 * rechercher / remplacer, reproduire la mise en forme, sommaire, statistiques, marques de paragraphe, plein écran, raccourcis clavier.
 * Le texte reste enregistré dans le MÊME champ « body » (# titre, **gras**, >> centré…, [i] [u] [s] [sub] [sup] [t=14] [c=#hex] [h=#hex] [f=police] [a=url],
 * propriétés de ligne [ind=1] [ls=1.5], images [img=60]data:…), donc tous les modèles, les PDF (Windows, Android, serveur) et le « Mode texte » continuent de fonctionner.
 * Retrait : supprimer la balise <script> de ce fichier (l'ancienne zone de texte revient seule). */
(function (w, d) {
  'use strict';
  var X = w.EXBPIE_X;
  if (!X || !w.EXBPIE) return;
  var FONT_LIST = String(X.FONTS || 'Arial').split('|');
  var SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72];
  var FSIZE_MAP = { 1: 8, 2: 10, 3: 12, 4: 14, 5: 18, 6: 24, 7: 36 };
  var BLOCKS = /^(P|DIV|H1|H2|H3|H4|H5|H6|UL|OL|LI|TABLE|THEAD|TBODY|TR|TD|TH|HR|BLOCKQUOTE|PRE)$/;
  var PAGE_W = 688, PAGE_WMM = 210, PAGE_USABLE = 750, IND_PX = 39, DEF_COLOR = '#111111';
  var SYMBOLS = '© ® ™ € £ ¥ $ ¢ § ¶ † ‡ ° ± × ÷ ≤ ≥ ≠ ≈ ∞ √ ∑ ∆ π Ω µ α β γ δ θ λ σ φ ² ³ ¼ ½ ¾ ‰ → ← ↑ ↓ ↔ ⇒ ✓ ✔ ✗ ✘ ★ ☆ ● ○ ■ □ ▲ ▼ • … « » – — ‘ ’ “ ” ¿ ¡ ∅ ⌀ ⊥ ∥ ∠ ∴ ∈ ≡ ¹ ⁰ ₀ ₁ ₂ ₃ ☎ ✉ ✂ ⚠ ☑ ☐'.split(' ');
  var cur = null; /* { ta, ed, ro, last, img, painter, col, hl, zoomAuto, holder } */

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function mode() { try { return w.localStorage.getItem('EXB_ED_MODE') !== 'texte'; } catch (e) { return true; } }
  function setMode(word) { try { w.localStorage.setItem('EXB_ED_MODE', word ? 'word' : 'texte'); } catch (e) {} }
  function say(m, t) { try { if (w.EXB81 && w.EXB81.say) w.EXB81.say(m, t); } catch (e) {} }
  function $(id) { return d.getElementById(id); }

  /* ───────────── balisage → HTML (même lecteur que le PDF) ───────────── */
  function toHtml(md) {
    var h = '';
    try { h = X.rd(md || ''); } catch (e) { h = ''; }
    if (!h.trim()) h = '<p><br></p>';
    return h;
  }

  /* ───────────── HTML → balisage ───────────── */
  function rgbHex(c) {
    c = String(c || '').trim(); if (!c || c === 'transparent') return '';
    var m = /^#([0-9a-f]{6})$/i.exec(c); if (m) return '#' + m[1].toLowerCase();
    m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(c); if (m) return ('#' + m[1] + m[1] + m[2] + m[2] + m[3] + m[3]).toLowerCase();
    m = /^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+))?/i.exec(c);
    if (m) {
      if (m[4] !== undefined && +m[4] === 0) return '';
      return '#' + [m[1], m[2], m[3]].map(function (n) { return ('0' + Math.max(0, Math.min(255, +n)).toString(16)).slice(-2); }).join('');
    }
    return '';
  }
  function ptOf(v) {
    v = String(v || '').trim(); var m;
    if ((m = /^([\d.]+)pt$/.exec(v))) return Math.round(+m[1]);
    if ((m = /^([\d.]+)px$/.exec(v))) return Math.round(+m[1] * 0.75);
    return 0;
  }
  function fontOf(v) {
    v = String(v || '').toLowerCase();
    for (var i = 0; i < FONT_LIST.length; i++) if (v.indexOf(FONT_LIST[i].toLowerCase()) >= 0) return FONT_LIST[i];
    return '';
  }
  function safeHref(h) {
    h = String(h || '').trim().replace(/\s/g, '%20').replace(/\]/g, '%5D').replace(/["'<>]/g, '');
    return /^(https?:\/\/|mailto:|tel:)/i.test(h) ? h : '';
  }
  /* style effectif d'un texte : l'ancêtre le plus proche l'emporte (jamais deux balises du même type imbriquées) */
  function styleOf(node, root) {
    var st = { b: null, i: null, u: false, s: false, sub: false, sup: false, t: 0, c: '', h: '', f: '', a: '' };
    for (var n = node.parentNode; n && n !== root; n = n.parentNode) {
      if (n.nodeType !== 1) continue;
      var tg = n.tagName, s = n.style || {}, td = String(s.textDecorationLine || s.textDecoration || '');
      if (st.b === null) {
        if (tg === 'B' || tg === 'STRONG') st.b = true;
        else if (s.fontWeight) st.b = (s.fontWeight === 'bold' || +s.fontWeight >= 600);
      }
      if (st.i === null) {
        if (tg === 'I' || tg === 'EM') st.i = true;
        else if (s.fontStyle) st.i = (s.fontStyle === 'italic');
      }
      if (tg === 'U' || /underline/.test(td)) st.u = true;
      if (tg === 'S' || tg === 'STRIKE' || tg === 'DEL' || /line-through/.test(td)) st.s = true;
      if (tg === 'SUB' || s.verticalAlign === 'sub') st.sub = true;
      if (tg === 'SUP' || s.verticalAlign === 'super') st.sup = true;
      if (!st.a && tg === 'A') st.a = safeHref(n.getAttribute('href'));
      if (!st.t) { var p = ptOf(s.fontSize); if (!p && tg === 'FONT' && n.getAttribute('size')) p = FSIZE_MAP[n.getAttribute('size')] || 0; if (p) st.t = p; }
      var bgBlk = n.hasAttribute && n.hasAttribute('data-bg');
      if (!st.c && !bgBlk) { var c = rgbHex(s.color || (tg === 'FONT' ? n.getAttribute('color') : '')); if (c && c !== DEF_COLOR) st.c = c; }
      if (!st.h && !bgBlk) { var hh = rgbHex(s.backgroundColor || ''); if (!hh && tg === 'MARK') hh = '#ffff00'; if (hh) st.h = hh; }
      if (!st.f) { var f = fontOf(s.fontFamily || (tg === 'FONT' ? n.getAttribute('face') : '')); if (f) st.f = f; }
    }
    st.b = !!st.b; st.i = !!st.i;
    if (st.sub && st.sup) st.sub = false;
    return st;
  }
  function key(st) { return [st.b, st.i, st.u, st.s, st.sub, st.sup, st.t, st.c, st.h, st.f, st.a].join('|'); }
  function wrapRun(txt, st) {
    if (!txt) return '';
    if (!/\S/.test(txt)) return txt; /* espaces seuls : pas de balise */
    var lead = /^\s*/.exec(txt)[0], trail = /\s*$/.exec(txt)[0], core = txt.slice(lead.length, txt.length - trail.length);
    if (st.sub) core = '[sub]' + core + '[/sub]';
    if (st.sup) core = '[sup]' + core + '[/sup]';
    if (st.f) core = '[f=' + st.f + ']' + core + '[/f]';
    if (st.t) core = '[t=' + st.t + ']' + core + '[/t]';
    if (st.c) core = '[c=' + st.c + ']' + core + '[/c]';
    if (st.h) core = '[h=' + st.h + ']' + core + '[/h]';
    if (st.s) core = '[s]' + core + '[/s]';
    if (st.u) core = '[u]' + core + '[/u]';
    if (st.i) core = '[i]' + core + '[/i]';
    if (st.b) core = '**' + core + '**';
    if (st.a) core = '[a=' + st.a + ']' + core + '[/a]';
    return lead + core + trail;
  }
  var IMG_MARK = '\u0001';
  /* contenu en ligne d'un bloc → tableau de lignes (un <br> = une nouvelle ligne ; une image = une ligne « \u0001[img=…]… ») */
  function inlineLines(el, root) {
    var toks = [];
    (function walk(n) {
      if (n.nodeType === 3) { toks.push({ t: String(n.nodeValue).replace(/ /g, ' ').replace(/[\r\n]+/g, ' '), st: styleOf(n, root) }); return; }
      if (n.nodeType !== 1) return;
      if (n.tagName === 'BR') { toks.push({ t: null }); return; }
      if (n.tagName === 'IMG') { var src = n.getAttribute('src') || '', wp = parseInt(n.getAttribute('data-w') || (n.style && n.style.width) || '60', 10) || 60; if (/^(data:image\/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+\/=]+|https?:\/\/[^\s"'<>]+)$/i.test(src)) toks.push({ img: '[img=' + Math.max(5, Math.min(100, wp)) + (/^[lr]$/.test(n.getAttribute('data-fl') || '') ? ',' + n.getAttribute('data-fl') : '') + ']' + src }); return; }
      if (n.tagName === 'UL' || n.tagName === 'OL' || n.tagName === 'TABLE') return;
      for (var c = n.firstChild; c; c = c.nextSibling) walk(c);
    })(el);
    var lines = [[]], last;
    toks.forEach(function (k) {
      if (k.img) { last = lines[lines.length - 1]; if (Array.isArray(last) && !last.length) lines.pop(); lines.push({ img: k.img }); lines.push([]); }
      else if (k.t === null) lines.push([]);
      else lines[lines.length - 1].push(k);
    });
    /* le <br> final d'un bloc n'est qu'un repère de Chrome : il ne crée pas de ligne */
    var lastTok = toks[toks.length - 1];
    last = lines[lines.length - 1];
    if (lines.length > 1 && Array.isArray(last) && !last.length && (!lastTok || lastTok.t === null || lastTok.img)) lines.pop();
    if (!lines.length) lines = [[]];
    return lines.map(function (ln) {
      if (!Array.isArray(ln)) return IMG_MARK + ln.img;
      var out = '', run = null;
      ln.forEach(function (k) {
        if (run && key(run.st) === key(k.st)) run.t += k.t; else { if (run) out += wrapRun(run.t, run.st); run = { t: k.t, st: k.st }; }
      });
      if (run) out += wrapRun(run.t, run.st);
      return out.replace(/\s+$/, '');
    });
  }
  function alignOf(el) {
    var a = (el.style && el.style.textAlign) || el.getAttribute('align') || '';
    if (!a) { var c = el.className || ''; if (/\bc\b/.test(c)) a = 'center'; else if (/\br\b/.test(c)) a = 'right'; }
    return { center: '>> ', right: '<< ', left: '<= ', justify: '== ' }[a] || '';
  }
  function propsOf(el, noInd) {
    var p = '', i = parseInt(el.getAttribute('data-ind') || '0', 10), ls = parseFloat(el.style && el.style.lineHeight);
    if (!noInd && i > 0) p += '[ind=' + Math.min(8, i) + ']';
    if (ls > 0 && Math.abs(ls - 1.5) > 0.001) p += '[ls=' + Math.min(4, Math.max(1, Math.round(ls * 100) / 100)) + ']';
    var bg = el.getAttribute && el.getAttribute('data-bg'); if (/^#[0-9a-f]{6}$/i.test(bg || '')) p += '[bg=' + bg.toLowerCase() + ']';
    return p;
  }
  function cellText(el, root) { return inlineLines(el, root).filter(function (l) { return l.charAt(0) !== IMG_MARK; }).join(' ').replace(/\|/g, '/').trim(); }

  function toMd(ed0) {
    var out = [], ed = ed0.cloneNode(true), run = null;
    /* éléments en ligne (ou texte) posés directement à la racine : regroupés dans un paragraphe */
    [].slice.call(ed.childNodes).forEach(function (n) {
      var isBlock = n.nodeType === 1 && (BLOCKS.test(n.tagName) || (n.classList && n.classList.contains('pb')));
      if (isBlock) { run = null; return; }
      if (n.nodeType === 3 && !String(n.nodeValue).trim()) { return; }
      if (!run) { run = d.createElement('p'); ed.insertBefore(run, n); }
      run.appendChild(n);
    });
    function para(el, prefix, pre) {
      var lines = inlineLines(el, ed), al = alignOf(el), pr = propsOf(el);
      lines.forEach(function (ln) {
        if (ln.charAt(0) === IMG_MARK) { out.push(al + ln.slice(1)); return; }
        if (!ln.trim()) { out.push((al ? al : '') + '[~]'); return; }
        var l = ln;
        if (el.classList && el.classList.contains('obj')) l = l.replace(/^\*\*(Objet|Réf\.? projet|Référence) :\*\* /, '$1 : ');
        out.push((pre || '') + al + pr + prefix + l);
      });
    }
    function list(n, lvl) {
      var tg = n.tagName, i = 0, pad = new Array(Math.min(3, lvl) * 2 + 1).join(' ');
      [].forEach.call(n.children, function (li) {
        if (li.tagName === 'UL' || li.tagName === 'OL') { list(li, lvl + 1); return; }
        if (li.tagName !== 'LI') return;
        var lines = inlineLines(li, ed), al = alignOf(li), pr = propsOf(li, true);
        lines.forEach(function (ln) {
          if (!ln.trim() || ln.charAt(0) === IMG_MARK) return;
          i++; out.push(al + pr + pad + (tg === 'UL' ? '- ' : i + '. ') + ln);
        });
        [].forEach.call(li.children, function (c) { if (c.tagName === 'UL' || c.tagName === 'OL') list(c, lvl + 1); });
      });
    }
    function block(n) {
      if (n.nodeType === 3) { var t = String(n.nodeValue).replace(/ /g, ' ').trim(); if (t) out.push(t); return; }
      if (n.nodeType !== 1) return;
      var tg = n.tagName;
      if (n.classList && n.classList.contains('pb')) { out.push('[saut de page]'); return; }
      if (tg === 'HR') { out.push('---'); return; }
      if (tg === 'H2') { para(n, '# '); return; }
      if (tg === 'H3') { para(n, '## '); return; }
      if (tg === 'H4' || tg === 'H5' || tg === 'H6' || tg === 'H1') { para(n, tg === 'H1' ? '# ' : '### '); return; }
      if (tg === 'UL' || tg === 'OL') { list(n, 0); return; }
      if (tg === 'TABLE') {
        [].forEach.call(n.querySelectorAll('tr'), function (tr) {
          var cells = [].map.call(tr.children, function (c) { return cellText(c, ed) || ' '; });
          if (cells.length) out.push('| ' + cells.join(' | ') + ' |');
        });
        return;
      }
      if (tg === 'P' || tg === 'LI' || tg === 'BLOCKQUOTE' || tg === 'PRE') { para(n, ''); return; }
      if (tg === 'DIV') {
        var hasBlock = [].some.call(n.children, function (c) { return BLOCKS.test(c.tagName) || (c.classList && c.classList.contains('pb')); });
        if (hasBlock) { for (var c = n.firstChild; c; c = c.nextSibling) block(c); } else para(n, '');
        return;
      }
      para(n, '');
    }
    for (var c = ed.firstChild; c; c = c.nextSibling) block(c);
    while (out.length && /^(<<|>>|<=|==)? ?\[~\]$/.test(out[out.length - 1])) out.pop();
    while (out.length && /^(<<|>>|<=|==)? ?\[~\]$/.test(out[0])) out.shift();
    return out.join('\n');
  }

  /* ───────────── sélection ───────────── */
  function inEd(n) { return !!(cur && n && cur.ed.contains(n)); }
  function saveSel() {
    if (!cur) return;
    var s = w.getSelection(); if (!s || !s.rangeCount) return;
    var r = s.getRangeAt(0); if (cur.ed.contains(r.commonAncestorContainer)) cur.last = r.cloneRange();
  }
  function restoreSel() {
    if (!cur) return; cur.ed.focus();
    if (cur.last) { var s = w.getSelection(); s.removeAllRanges(); s.addRange(cur.last); }
  }
  function blockOf(n) {
    for (; n && n !== cur.ed; n = n.parentNode) if (n.nodeType === 1 && /^(P|H[1-6]|LI|TD|TH|DIV)$/.test(n.tagName)) return n;
    return null;
  }
  /* sans texte sélectionné, le formatage s'applique à tout le paragraphe courant (plus pratique qu'au prochain caractère) */
  function selectBlockIfCollapsed() {
    var s = w.getSelection(); if (!s || !s.rangeCount) return;
    cur.pend = null;
    if (s.isCollapsed) {
      var b = blockOf(s.anchorNode);
      if (b) {
        /* on retient où était le curseur : après la mise en forme on le remet là, sinon le paragraphe resterait sélectionné et la frappe suivante l'écraserait */
        cur.pend = { n: s.anchorNode, o: s.anchorOffset, c: charOff(cur.ed, s.anchorNode, s.anchorOffset) };
        var r = d.createRange(); r.selectNodeContents(b); s.removeAllRanges(); s.addRange(r);
      }
    }
  }
  function unselectBlock() {
    if (!cur || !cur.pend) return;
    var pd = cur.pend; cur.pend = null;
    var s = w.getSelection(); if (!s || !s.rangeCount || s.isCollapsed) return;
    var r = d.createRange(), ok = false;
    if (pd.n && cur.ed.contains(pd.n)) {
      var max = pd.n.nodeType === 3 ? pd.n.nodeValue.length : pd.n.childNodes.length;
      try { r.setStart(pd.n, Math.min(pd.o, max)); r.collapse(true); ok = true; } catch (e) {}
    }
    if (!ok && pd.c >= 0) { var q = rangeFromOffs(cur.ed, [pd.c, pd.c]); if (q) { r = q; ok = true; } }
    if (!ok) { r = s.getRangeAt(0).cloneRange(); r.collapse(false); }
    s.removeAllRanges(); s.addRange(r); saveSel();
  }
  function prep() { restoreSel(); selectBlockIfCollapsed(); saveSel(); }
  var BSEL = 'p,h1,h2,h3,h4,h5,h6,li';
  function selBlocks() {
    restoreSel();
    var s = w.getSelection(); if (!s || !s.rangeCount) return [];
    var r = s.getRangeAt(0), res = [].slice.call(cur.ed.querySelectorAll(BSEL)).filter(function (b) {
      return r.intersectsNode(b) && ![].some.call(b.querySelectorAll(BSEL), function (x) { return r.intersectsNode(x); });
    });
    if (!res.length) { var b = blockOf(r.startContainer); if (b) res = [b]; }
    return res;
  }
  /* Chromium range parfois une liste / un tableau / un titre DANS un <p> (ex. liste créée dans un paragraphe vidé par Ctrl+A) : le balisage devenait vide.
     On sort ces blocs du paragraphe (le curseur reste dans les mêmes nœuds). */
  var NEST = 'p > ul, p > ol, p > table, p > hr, p > h1, p > h2, p > h3, p > h4, p > blockquote, p > pre, p > div:not(.pb)';
  function unnestBlocks() {
    var ed = cur.ed, guard = 0, bad, changed = false;
    while ((bad = ed.querySelector(NEST)) && guard++ < 200) {
      var p = bad.parentNode, kids = [].slice.call(p.childNodes), out = [], run = null;
      kids.forEach(function (k) {
        if (k.nodeType === 1 && (BLOCKS.test(k.tagName) || (k.classList && k.classList.contains('pb')))) { out.push(k); run = null; return; }
        if (k.nodeType === 3 && !String(k.nodeValue).trim() && !run) return;
        if (!run) { run = p.cloneNode(false); out.push(run); }
        run.appendChild(k);
      });
      var lost = [];
      out = out.filter(function (o) {
        var keep = o.tagName !== 'P' || o.querySelector('img,br') || String(o.textContent).trim() || out.length === 1;
        if (!keep) [].forEach.call(o.querySelectorAll('[data-exb-caret]'), function (m) { lost.push(m); });
        return keep;
      });
      /* un paragraphe réduit à un repère de curseur disparaît : le repère passe au début du bloc suivant (sinon il resterait une ligne vide en trop) */
      if (lost.length && out.length) { var tg = out[0].querySelector('li,td,th') || out[0]; lost.forEach(function (m) { tg.insertBefore(m, tg.firstChild); }); }
      out.forEach(function (o) { p.parentNode.insertBefore(o, p); });
      p.parentNode.removeChild(p); changed = true;
    }
    return changed;
  }
  /* position d'un point de la sélection en nombre de caractères depuis le début de la feuille (survit aux déplacements de nœuds) */
  function charOff(ed, node, off) { var r = d.createRange(); r.selectNodeContents(ed); try { r.setEnd(node, off); } catch (e) { return -1; } return r.toString().length; }
  function pointAt(ed, n) {
    var tw = d.createTreeWalker(ed, 4, null), t, acc = 0, last = null;
    while ((t = tw.nextNode())) { var L = t.nodeValue.length; if (n <= acc + L) return [t, n - acc]; acc += L; last = t; }
    return last ? [last, last.nodeValue.length] : [ed, 0];
  }
  function rangeOffs(ed, rg) { return rg && ed.contains(rg.startContainer) && ed.contains(rg.endContainer) ? [charOff(ed, rg.startContainer, rg.startOffset), charOff(ed, rg.endContainer, rg.endOffset)] : null; }
  function rangeFromOffs(ed, o) { if (!o || o[0] < 0 || o[1] < 0) return null; var a = pointAt(ed, o[0]), z = pointAt(ed, o[1]), r = d.createRange(); try { r.setStart(a[0], a[1]); r.setEnd(z[0], z[1]); } catch (e) { return null; } return r; }
  function cleanDom(ed) {
    var changed = false;
    /* balise parasite laissée par Chromium (désactiver une liste, outdent…) : <span style="font-size:11pt"> seul = taille par défaut */
    [].slice.call(ed.querySelectorAll('span[style]')).forEach(function (sp) {
      if (sp.style.length === 1 && sp.style.fontSize === '11pt') { var pr = sp.parentNode; while (sp.firstChild) pr.insertBefore(sp.firstChild, sp); pr.removeChild(sp); changed = true; }
    });
    return unnestBlocks() || changed;
  }
  /* Pose un repère invisible à un bord de la sélection : il suit son nœud quand le DOM est réarrangé. Le comptage en caractères confondait le début d'un bloc
     avec la fin du bloc précédent (le curseur « sautait » dans la ligne d'avant après le bouton liste à puces). */
  var CMARK = 'data-exb-caret';
  function dropMark(rg, id, atEnd) {
    if (!rg) return null;
    var c = rg.cloneRange(); c.collapse(!atEnd);
    var m = d.createElement('span'); m.setAttribute(CMARK, id); m.setAttribute('contenteditable', 'false');
    try { c.insertNode(m); } catch (e) { return null; }
    return m;
  }
  function needsClean(ed) {
    if (ed.querySelector(NEST)) return true;
    var sp = ed.querySelectorAll('span[style]');
    for (var i = 0; i < sp.length; i++) if (sp[i].style.length === 1 && sp[i].style.fontSize === '11pt') return true;
    return false;
  }
  function markRange(ed, id, rg) {
    if (!rg || !ed.contains(rg.startContainer) || !ed.contains(rg.endContainer)) return null;
    var a = dropMark(rg, id + 's', false), z = dropMark(rg, id + 'e', true);
    /* le repère de fin est posé après celui de début : même point si la sélection est réduite */
    return a && z ? id : null;
  }
  function rangeFromMarks(ed, id) {
    var a = ed.querySelector('[' + CMARK + '="' + id + 's"]'), z = ed.querySelector('[' + CMARK + '="' + id + 'e"]');
    if (!a || !z) return null;
    var r = d.createRange();
    try { r.setStartAfter(a); r.setEndBefore(z); if (r.collapsed === false && r.toString() === '' && a.nextSibling === z) r.collapse(true); } catch (e) { return null; }
    return r;
  }
  function normalizeRoot() {
    var ed = cur.ed, run = null, sel0 = w.getSelection(), focused = d.activeElement === ed;
    /* la sélection n'est rétablie que si le DOM a bougé ET que la feuille a le focus : sinon on volerait le focus aux boîtes de dialogue (blur → sync) */
    if (needsClean(ed)) {
      var live = sel0 && sel0.rangeCount ? sel0.getRangeAt(0).cloneRange() : null, saved = cur.last ? cur.last.cloneRange() : null;
      var k1 = markRange(ed, 'a', live), k2 = markRange(ed, 'b', saved);
      cleanDom(ed);
      var r1 = k1 ? rangeFromMarks(ed, 'a') : null, r2 = k2 ? rangeFromMarks(ed, 'b') : null;
      [].slice.call(ed.querySelectorAll('[' + CMARK + ']')).forEach(function (m) { var pr = m.parentNode; if (!pr) return; pr.removeChild(m); if (pr.tagName === 'P' && !pr.firstChild) pr.appendChild(d.createElement('br')); });
      ed.normalize();
      if (r2) cur.last = r2;
      if (r1 && focused) { try { sel0.removeAllRanges(); sel0.addRange(r1); } catch (e) {} }
    } else cleanDom(ed);
    [].slice.call(ed.childNodes).forEach(function (n) {
      var isBlock = n.nodeType === 1 && (BLOCKS.test(n.tagName) || (n.classList && n.classList.contains('pb')));
      if (isBlock) { run = null; return; }
      if (n.nodeType === 3 && !String(n.nodeValue).trim()) return;
      if (!run) { run = d.createElement('p'); ed.insertBefore(run, n); }
      run.appendChild(n);
    });
    if (!ed.firstChild) { ed.innerHTML = '<p><br></p>'; var r = d.createRange(); r.setStart(ed.firstChild, 0); r.collapse(true); var s = w.getSelection(); s.removeAllRanges(); s.addRange(r); }
  }
  function pagesInfo() {
    var ed = cur.ed, base = ed.getBoundingClientRect().top, z = parseFloat(cur.page.style.zoom) || 1, pbs = [].slice.call(ed.querySelectorAll('.pb')).map(function (p) { return (p.getBoundingClientRect().top - base) / z; });
    var total = (ed.getBoundingClientRect().height / z), cuts = [0].concat(pbs).concat([total]), pages = 0, starts = [];
    for (var i = 0; i < cuts.length - 1; i++) { var h = Math.max(1, cuts[i + 1] - cuts[i]), n = Math.max(1, Math.ceil((h - 20) / PAGE_USABLE)); for (var k = 0; k < n; k++) starts.push(cuts[i] + k * PAGE_USABLE); pages += n; }
    var cp = 1, s = w.getSelection();
    if (s && s.rangeCount && inEd(s.anchorNode)) {
      var rc = s.getRangeAt(0).cloneRange(); rc.collapse(true); var rr = rc.getClientRects()[0] || (s.anchorNode.nodeType === 1 ? s.anchorNode.getBoundingClientRect() : s.anchorNode.parentNode.getBoundingClientRect());
      var y = (rr.top - base) / z; for (i = 0; i < starts.length; i++) if (y >= starts[i] - 1) cp = i + 1;
    }
    return { pages: Math.max(1, pages), page: Math.min(cp, Math.max(1, pages)) };
  }
  function stats() {
    var t = (cur.ed.innerText || '').replace(/ /g, ' '), tt = t.trim();
    return { words: tt ? tt.split(/\s+/).length : 0, chars: tt.length, nospace: tt.replace(/\s/g, '').length, paras: cur.ed.querySelectorAll(BSEL).length, imgs: cur.ed.querySelectorAll('img').length, tables: cur.ed.querySelectorAll('table').length };
  }
  function sync() {
    if (!cur) return;
    if (!cur.ro) normalizeRoot();
    cur.ta.value = toMd(cur.ed);
    var st = stats(), c = $('exbEdCount'); if (c) c.textContent = 'Mots : ' + st.words;
    var pi = pagesInfo(), pg = $('exbEdPage1'); if (pg) pg.textContent = 'Page ' + pi.page + ' sur ' + pi.pages;
  }
  function cmd(c, v) {
    if (!cur || cur.ro) return;
    restoreSel();
    try { d.execCommand('styleWithCSS', false, true); } catch (e) {}
    d.execCommand(c, false, v == null ? null : v);
    unselectBlock();
    saveSel(); sync(); refresh();
  }
  function applySize(pt) {
    if (!cur || cur.ro) return;
    prep();
    try { d.execCommand('styleWithCSS', false, false); } catch (e) {}
    d.execCommand('fontSize', false, '7');
    var made = [];
    [].forEach.call(cur.ed.querySelectorAll('font[size="7"]'), function (f) {
      var sp = d.createElement('span'); sp.style.fontSize = pt + 'pt';
      while (f.firstChild) sp.appendChild(f.firstChild);
      f.parentNode.replaceChild(sp, f); made.push(sp);
    });
    /* un <span> de taille dans un autre de taille : on ne garde que le plus proche (évite les doublons) */
    [].forEach.call(cur.ed.querySelectorAll('span[style*="font-size"] span[style*="font-size"]'), function (inner) {
      var up = inner.parentNode.closest && inner.parentNode.closest('span[style*="font-size"]');
      if (up && up.childNodes.length === 1 && up.firstChild === inner) { up.style.fontSize = inner.style.fontSize; while (inner.firstChild) up.insertBefore(inner.firstChild, inner); inner.remove(); }
    });
    if (made.length) { var rg = d.createRange(); rg.setStartBefore(made[0]); rg.setEndAfter(made[made.length - 1]); var sl = w.getSelection(); sl.removeAllRanges(); sl.addRange(rg); }
    unselectBlock();
    saveSel(); sync(); showSize();
  }
  function currentSize() {
    var s = w.getSelection(); if (!s || !s.anchorNode) return 11;
    var n = s.anchorNode;
    /* après une mise en forme la sélection est « avant/après le <span> » : on descend jusqu'au premier texte réellement sélectionné */
    if (s.rangeCount && !s.isCollapsed) {
      var r0 = s.getRangeAt(0); n = r0.startContainer;
      if (n.nodeType === 1) { n = n.childNodes[r0.startOffset] || n; while (n.firstChild) n = n.firstChild; }
    }
    n = n.nodeType === 3 ? n.parentNode : n;
    var px = parseFloat(w.getComputedStyle(n).fontSize) || 14.67;
    return Math.round(px * 0.75);
  }
  function showSize() {
    var sel = $('exbEdSize'); if (!sel || !cur) return;
    var v = currentSize(); sel.value = String(v);
    if (sel.value !== String(v)) { var o = d.createElement('option'); o.value = String(v); o.textContent = v; sel.appendChild(o); sel.value = String(v); }
  }

  /* ───────────── paragraphes : retraits, interligne ───────────── */
  function indent(dir) {
    if (!cur || cur.ro) return;
    var bl = selBlocks();
    if (bl.some(function (b) { return b.tagName === 'LI'; })) {
      cmd(dir > 0 ? 'indent' : 'outdent');
      /* Chromium laisse un <span style="font-size:11pt"> parasite après « outdent » : on le retire (11 pt = taille par défaut, aucun changement visible) */
      [].slice.call(cur.ed.querySelectorAll('li span[style]')).forEach(function (sp) {
        if (sp.style.length === 1 && sp.style.fontSize === '11pt') { var pr = sp.parentNode; while (sp.firstChild) pr.insertBefore(sp.firstChild, sp); pr.removeChild(sp); }
      });
      saveSel(); sync(); return;
    }
    bl.forEach(function (b) {
      var n = Math.max(0, Math.min(8, (parseInt(b.getAttribute('data-ind') || '0', 10) || 0) + dir));
      if (n) { b.setAttribute('data-ind', n); b.style.marginLeft = (n * IND_PX) + 'px'; } else { b.removeAttribute('data-ind'); b.style.marginLeft = ''; }
    });
    saveSel(); sync();
  }
  function setSpacing(v) {
    if (!cur || cur.ro) return;
    selBlocks().forEach(function (b) { if (!v || Math.abs(parseFloat(v) - 1.5) < 0.001) b.style.lineHeight = ''; else b.style.lineHeight = v; if (!b.getAttribute('style')) b.removeAttribute('style'); });
    saveSel(); sync(); refresh();
  }

  /* ───────────── tableaux ───────────── */
  function cellOf() { var s = w.getSelection(); if (!s || !s.anchorNode) return null; var n = s.anchorNode.nodeType === 3 ? s.anchorNode.parentNode : s.anchorNode; return n.closest ? n.closest('td,th') : null; }
  function insertTable() {
    if (!cur || cur.ro) return; saveSel();
    X.ask('Insérer un tableau', [{ label: 'Colonnes (1 à 8)', val: '3', type: 'number' }, { label: 'Lignes sans l’en-tête (1 à 40)', val: '3', type: 'number' }], function (v) {
      var n = Math.max(1, Math.min(8, parseInt(v[0], 10) || 0)), r = Math.max(1, Math.min(40, parseInt(v[1], 10) || 0)), h = '<table><tbody><tr>';
      for (var i = 0; i < n; i++) h += '<th>Colonne ' + (i + 1) + '</th>'; h += '</tr>';
      for (var j = 0; j < r; j++) { h += '<tr>'; for (i = 0; i < n; i++) h += '<td><br></td>'; h += '</tr>'; }
      restoreSel(); d.execCommand('insertHTML', false, h + '</tbody></table><p><br></p>'); saveSel(); sync();
    });
  }
  function tableOp(op) {
    if (!cur || cur.ro) return; restoreSel();
    var c = cellOf(); if (!c) return say('Placez le curseur dans une cellule du tableau.', 'error');
    var tr = c.parentNode, tb = tr.closest('table'), idx = [].indexOf.call(tr.children, c);
    if (op === 'row+') { var nr = tr.cloneNode(true); [].forEach.call(nr.children, function (x) { x.innerHTML = '<br>'; if (x.tagName === 'TH') { var td = d.createElement('td'); td.innerHTML = '<br>'; nr.replaceChild(td, x); } }); tr.parentNode.insertBefore(nr, tr.nextSibling); }
    else if (op === 'row-') { if (tb.rows.length > 1) tr.remove(); else tb.remove(); }
    else if (op === 'col+') { [].forEach.call(tb.rows, function (r) { var ref = r.children[idx], nc = d.createElement(ref && ref.tagName === 'TH' ? 'th' : 'td'); nc.innerHTML = ref && ref.tagName === 'TH' ? 'Colonne' : '<br>'; r.insertBefore(nc, ref ? ref.nextSibling : null); }); }
    else if (op === 'col-') { if (tr.children.length > 1) [].forEach.call(tb.rows, function (r) { if (r.children[idx]) r.children[idx].remove(); }); else tb.remove(); }
    else if (op === 'tdel') tb.remove();
    sync();
  }

  /* ───────────── images ───────────── */
  function loadImage(file, cb) {
    if (!file || !/^image\//.test(file.type)) return say('Choisissez un fichier image (PNG, JPG, WebP…).', 'error');
    var fr = new FileReader();
    fr.onerror = function () { say('Image illisible.', 'error'); };
    fr.onload = function () {
      var im = new Image();
      im.onerror = function () { say('Image illisible.', 'error'); };
      im.onload = function () {
        var maxW = 1000, q = 0.82, url = '';
        for (var k = 0; k < 4; k++) {
          var sc = Math.min(1, maxW / im.width), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * sc)); c.height = Math.max(1, Math.round(im.height * sc));
          var g = c.getContext('2d');
          if (file.type === 'image/png' && k === 0) { g.drawImage(im, 0, 0, c.width, c.height); url = c.toDataURL('image/png'); if (url.length <= 450000) break; }
          g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height); url = c.toDataURL('image/jpeg', q);
          if (url.length <= 450000) break; maxW = Math.round(maxW * 0.75); q = Math.max(0.55, q - 0.08);
        }
        cb(url);
      };
      im.src = fr.result;
    };
    fr.readAsDataURL(file);
  }
  function putImage(url) {
    if (!cur || cur.ro) return;
    restoreSel(); d.execCommand('insertHTML', false, '<p style="text-align:center"><img src="' + url + '" data-w="60" style="width:60%"></p><p><br></p>');
    saveSel(); sync(); say('Image insérée. Cliquez dessus pour la redimensionner.');
  }
  function selectImg(img) {
    if (!cur) return;
    if (cur.img && cur.img !== img) cur.img.classList.remove('sel');
    cur.img = img || null; if (img) img.classList.add('sel');
    [].forEach.call(cur.holder.querySelectorAll('[data-img]'), function (b) { b.disabled = !img || cur.ro; });
  }
  /* Rogner : cadre réglable sur l'image (poignées aux coins et aux bords, ou déplacement du cadre), puis « Appliquer » */
  function cropImage(im) {
    var nat = new Image();
    nat.onload = function () {
      var NW = nat.naturalWidth, NH = nat.naturalHeight; if (!NW || !NH) return say('Image illisible.', 'error');
      var mw = Math.min(560, w.innerWidth - 40), mh = Math.round(w.innerHeight * 0.58), sc = Math.min(mw / NW, mh / NH, 1), DW = Math.round(NW * sc), DH = Math.round(NH * sc);
      var o = d.createElement('div'); o.style.cssText = 'position:fixed;inset:0;z-index:100002;background:#000b;display:flex;align-items:center;justify-content:center;padding:12px';
      o.innerHTML = '<div style="background:#fff;border-radius:12px;padding:14px;max-width:100%;font:14px/1.4 Arial;color:#172033"><b style="color:#0b3d91">✂ Rogner l’image</b><div style="font-size:12px;color:#5b6b86;margin:3px 0 8px">Tirez les poignées bleues ou déplacez le cadre ; seule la partie claire est conservée.</div>'
        + '<div id="exbCrBox" style="position:relative;width:' + DW + 'px;height:' + DH + 'px;margin:auto;touch-action:none;user-select:none;background:#ddd"><img src="' + nat.src + '" style="width:100%;height:100%;display:block;pointer-events:none"><div id="exbCrR" style="position:absolute;border:2px solid #1d6fe0;box-shadow:0 0 0 9999px rgba(0,0,0,.5);cursor:move;box-sizing:border-box"></div></div>'
        + '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px;flex-wrap:wrap"><button type="button" data-k="full" style="padding:8px 12px">Tout</button><button type="button" data-k="no" style="padding:8px 14px">Annuler</button><button type="button" data-k="ok" style="padding:8px 16px;background:#173565;color:#fff;border:0;border-radius:6px">Appliquer</button></div></div>';
      d.body.appendChild(o);
      var box = o.querySelector('#exbCrBox'), R = o.querySelector('#exbCrR'), r = { x: 0, y: 0, w: DW, h: DH }, MIN = 24;
      var HS = [['nw', 0, 0], ['n', .5, 0], ['ne', 1, 0], ['e', 1, .5], ['se', 1, 1], ['s', .5, 1], ['sw', 0, 1], ['w', 0, .5]];
      HS.forEach(function (h) { var e = d.createElement('i'); e.setAttribute('data-h', h[0]); e.style.cssText = 'position:absolute;width:18px;height:18px;margin:-9px;background:#1d6fe0;border:2px solid #fff;border-radius:50%;left:' + h[1] * 100 + '%;top:' + h[2] * 100 + '%;cursor:' + (h[0] === 'n' || h[0] === 's' ? 'ns' : h[0] === 'e' || h[0] === 'w' ? 'ew' : (h[0] === 'nw' || h[0] === 'se') ? 'nwse' : 'nesw') + '-resize'; R.appendChild(e); });
      function draw() { R.style.left = r.x + 'px'; R.style.top = r.y + 'px'; R.style.width = r.w + 'px'; R.style.height = r.h + 'px'; }
      draw();
      var drag = null;
      R.addEventListener('pointerdown', function (e) { e.preventDefault(); drag = { h: e.target.getAttribute('data-h') || 'move', x: e.clientX, y: e.clientY, r: { x: r.x, y: r.y, w: r.w, h: r.h } }; try { R.setPointerCapture(e.pointerId); } catch (x) {} });
      R.addEventListener('pointermove', function (e) {
        if (!drag) return; var dx = e.clientX - drag.x, dy = e.clientY - drag.y, a = drag.r, h = drag.h, n = { x: a.x, y: a.y, w: a.w, h: a.h };
        if (h === 'move') { n.x = Math.max(0, Math.min(DW - a.w, a.x + dx)); n.y = Math.max(0, Math.min(DH - a.h, a.y + dy)); }
        else {
          if (h.indexOf('w') >= 0) { var nx = Math.max(0, Math.min(a.x + a.w - MIN, a.x + dx)); n.w = a.x + a.w - nx; n.x = nx; }
          if (h.indexOf('e') >= 0) n.w = Math.max(MIN, Math.min(DW - a.x, a.w + dx));
          if (h.indexOf('n') >= 0) { var ny = Math.max(0, Math.min(a.y + a.h - MIN, a.y + dy)); n.h = a.y + a.h - ny; n.y = ny; }
          if (h.indexOf('s') >= 0) n.h = Math.max(MIN, Math.min(DH - a.y, a.h + dy));
        }
        r = n; draw();
      });
      ['pointerup', 'pointercancel'].forEach(function (ev) { R.addEventListener(ev, function () { drag = null; }); });
      function close() { o.remove(); }
      o.addEventListener('click', function (e) {
        var k = e.target.getAttribute && e.target.getAttribute('data-k'); if (!k) return;
        if (k === 'no') return close();
        if (k === 'full') { r = { x: 0, y: 0, w: DW, h: DH }; return draw(); }
        var sx = Math.round(r.x / sc), sy = Math.round(r.y / sc), sw = Math.max(1, Math.round(r.w / sc)), sh = Math.max(1, Math.round(r.h / sc));
        if (sw >= NW - 1 && sh >= NH - 1) return close();
        var png = /^data:image\/png/i.test(nat.src), maxW = 1000, q = 0.85, url = '';
        for (var t = 0; t < 4; t++) {
          var k2 = Math.min(1, maxW / sw), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(sw * k2)); c.height = Math.max(1, Math.round(sh * k2));
          var g = c.getContext('2d');
          if (png && t === 0) { g.drawImage(nat, sx, sy, sw, sh, 0, 0, c.width, c.height); url = c.toDataURL('image/png'); if (url.length <= 450000) break; }
          g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(nat, sx, sy, sw, sh, 0, 0, c.width, c.height); url = c.toDataURL('image/jpeg', q);
          if (url.length <= 450000) break; maxW = Math.round(maxW * 0.75); q = Math.max(0.55, q - 0.08);
        }
        if (!im.getAttribute('data-orig')) im.setAttribute('data-orig', im.getAttribute('src'));
        im.setAttribute('src', url); close(); sync(); say('Image rognée. « ↺ Rétablir » revient à l’original.');
      });
    };
    nat.onerror = function () { say('Image illisible.', 'error'); };
    nat.src = im.getAttribute('src');
  }
  function imgOp(op) {
    var im = cur && cur.img; if (!im || cur.ro) return say('Cliquez d’abord sur une image.', 'error');
    if (/^w\d+$/.test(op)) { var p = +op.slice(1); im.style.width = p + '%'; im.setAttribute('data-w', p); }
    else if (op === 'ifl' || op === 'ifr') { var r0 = op === 'ifr'; im.style.float = r0 ? 'right' : 'left'; im.style.margin = r0 ? '0 0 8px 14px' : '0 14px 8px 0'; im.setAttribute('data-fl', r0 ? 'r' : 'l'); }
    else if (op === 'ial' || op === 'ic' || op === 'iar') { im.style.float = ''; im.style.margin = ''; im.removeAttribute('data-fl'); var pb = im.closest('p,div,li') || im.parentNode; if (pb && pb !== cur.ed) pb.style.textAlign = op === 'ial' ? 'left' : op === 'iar' ? 'right' : 'center'; }
    else if (op === 'crop') return cropImage(im);
    else if (op === 'uncrop') { var o0 = im.getAttribute('data-orig'); if (!o0) return say('Cette image n’a pas été rognée dans cette session.', 'error'); im.setAttribute('src', o0); im.removeAttribute('data-orig'); }
    else if (op === 'del') { var par = im.parentNode; im.remove(); selectImg(null); if (par && par !== cur.ed && !par.textContent.trim() && !par.querySelector('img,br')) par.innerHTML = '<br>'; }
    sync();
  }

  /* ───────────── liens, symboles, date, sommaire ───────────── */
  function selText() { var s = w.getSelection(); return s && !s.isCollapsed && inEd(s.anchorNode) ? String(s.toString()) : ''; }
  function insertLink() {
    if (!cur || cur.ro) return; saveSel();
    var txt = selText(), a = null, s0 = w.getSelection(), n0 = s0 && s0.anchorNode;
    if (n0) { n0 = n0.nodeType === 3 ? n0.parentNode : n0; a = n0.closest ? n0.closest('a') : null; }
    X.ask(a ? 'Modifier le lien' : 'Insérer un lien', [{ label: 'Adresse (https://…, mailto:…, tel:…)', val: a ? a.getAttribute('href') : 'https://' }, { label: 'Texte à afficher', val: a ? a.textContent : txt }], function (v) {
      var u = String(v[0] || '').trim();
      if (/^[\w.+-]+@[\w-]+\.[\w.-]+$/.test(u)) u = 'mailto:' + u; else if (/^(www\.|[\w-]+\.[a-z]{2,}(\/|$))/i.test(u) && !/^[a-z]+:/i.test(u)) u = 'https://' + u;
      u = safeHref(u); if (!u) return say('Adresse non valide : utilisez https://, mailto: ou tel:.', 'error');
      var label = String(v[1] || '').trim() || u;
      restoreSel();
      if (a && cur.ed.contains(a)) { a.setAttribute('href', u); if (label !== a.textContent) a.textContent = label; sync(); return; }
      d.execCommand('insertHTML', false, '<a href="' + esc(u) + '">' + esc(label) + '</a>&nbsp;'); saveSel(); sync();
    });
  }
  function unlink() { if (!cur || cur.ro) return; restoreSel(); d.execCommand('unlink'); saveSel(); sync(); }
  function insertText(t) { if (!cur || cur.ro) return; restoreSel(); d.execCommand('insertText', false, t); saveSel(); sync(); }
  function insertSommaire() {
    if (!cur || cur.ro) return;
    var hs = [].slice.call(cur.ed.querySelectorAll('h2,h3,h4')).filter(function (h) { return h.textContent.trim(); });
    if (!hs.length) return say('Ajoutez d’abord des titres (onglet Accueil › Styles) : le sommaire les reprend.', 'error');
    var html = '<h3>Sommaire</h3>' + hs.map(function (h) { var lv = h.tagName === 'H2' ? 0 : h.tagName === 'H3' ? 1 : 2; return '<p style="margin-left:' + (lv * IND_PX) + 'px"' + (lv ? ' data-ind="' + lv + '"' : '') + '>' + esc(h.textContent.trim()) + '</p>'; }).join('') + '<p><br></p>';
    restoreSel(); d.execCommand('insertHTML', false, html); saveSel(); sync(); say('Sommaire inséré (à régénérer si les titres changent).');
  }

  /* ───────────── fenêtres, menus flottants ───────────── */
  function info(title, html) {
    var o = d.createElement('div'); o.style.cssText = 'position:fixed;inset:0;z-index:100001;background:#000a;display:flex;align-items:center;justify-content:center;padding:12px';
    o.innerHTML = '<div style="background:#fff;border-radius:12px;padding:16px;max-width:560px;width:100%;max-height:86vh;overflow:auto;font:14px/1.45 Arial;color:#172033"><b style="font-size:16px;color:#0b3d91">' + esc(title) + '</b><div style="margin-top:8px">' + html + '</div><p style="text-align:right;margin:12px 0 0"><button type="button" style="padding:8px 16px;background:#0b3d91;color:#fff;border:0;border-radius:8px">Fermer</button></p></div>';
    d.body.appendChild(o); function close() { o.remove(); d.removeEventListener('keydown', esck, true); }
    function esck(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
    d.addEventListener('keydown', esck, true);
    o.querySelector('button').onclick = close; o.onclick = function (e) { if (e.target === o) close(); };
  }
  function shade(hex) {
    if (!cur || cur.ro) return; prep();
    selBlocks().forEach(function (el) {
      if (hex) {
        var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b2 = parseInt(hex.slice(5, 7), 16);
        el.style.background = hex; el.style.color = (0.299 * r + 0.587 * g + 0.114 * b2) < 150 ? '#fff' : '#111'; el.style.padding = '1.5mm 3.5mm'; el.style.border = '0'; el.style.textTransform = 'none'; el.style.borderRadius = '1mm'; el.setAttribute('data-bg', hex.toLowerCase());
      } else { ['background', 'color', 'padding', 'border', 'textTransform', 'borderRadius'].forEach(function (k) { el.style[k] = ''; }); el.removeAttribute('data-bg'); }
    });
    sync(); refresh();
  }
  function bandeau(kind) {
    if (!cur || cur.ro) return; prep(); cmd('formatBlock', kind === 'titre' ? 'h2' : 'h3');
    selBlocks().forEach(function (el) { el.style.textAlign = kind === 'titre' ? 'center' : ''; });
    shade('#0b4aa8');
  }
  function changeCase(mode) {
    if (!cur || cur.ro) return; restoreSel(); var t = selText(); if (!t) return say('Sélectionnez d’abord du texte.', 'error');
    var o = mode === 'up' ? t.toUpperCase() : mode === 'low' ? t.toLowerCase() : mode === 'title' ? t.toLowerCase().replace(/(^|[\s\-’'(])(\S)/g, function (m, a, c) { return a + c.toUpperCase(); }) : t.replace(/./g, function (c) { return c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase(); });
    d.execCommand('insertText', false, o); saveSel(); sync();
  }
  function planDoc() {
    if (!cur) return; var hs = [].slice.call(cur.ed.querySelectorAll('h2,h3,h4'));
    var html = hs.length ? hs.map(function (h, i) { var lv = h.tagName === 'H2' ? 0 : h.tagName === 'H3' ? 1 : 2; return '<div><a href="#" data-nav="' + i + '" style="display:block;padding:5px 4px;margin-left:' + lv * 16 + 'px;color:#0b3d91;text-decoration:none;border-bottom:1px solid #eef2f8;' + (lv ? '' : 'font-weight:bold') + '">' + esc(h.textContent.trim() || '(titre vide)') + '</a></div>'; }).join('') : '<p>Aucun titre : appliquez le style « Titre 1 / 2 / 3 » pour construire le plan.</p>';
    info('Plan du document', html);
    var ov = d.body.lastElementChild;
    ov.addEventListener('click', function (e) { var a = e.target.closest && e.target.closest('[data-nav]'); if (!a) return; e.preventDefault(); var h = hs[+a.getAttribute('data-nav')]; ov.querySelector('button').click(); if (h) h.scrollIntoView({ block: 'start' }); });
  }
  function exportDocx() {
    if (!cur) return; if (!w.EXBDocx) return say('Module Word indisponible.', 'error'); sync();
    var nm = (cur.holder.querySelector('.hd .nm') || {}).textContent || '', tg = (cur.holder.querySelector('.hd .tg') || {}).textContent || '', blob;
    try { blob = w.EXBDocx.build(cur.ed, { name: nm, tagline: tg, fmt: cur.pfmt, ori: cur.pori }); } catch (e) { return say('Export Word impossible : ' + e.message, 'error'); }
    var ti = d.querySelector('#pTi,#pTitle,#pTit'), fn = (((cur.fname || (ti && ti.value) || 'Document')).replace(/[^\wÀ-ÿ\- ]+/g, '').trim().replace(/\s+/g, '-') || 'Document') + '.docx';
    var url = URL.createObjectURL(blob), a = d.createElement('a'); a.href = url; a.download = fn; d.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 60000); say('Document Word « ' + fn + ' » prêt.', 'ok');
  }
  function closePop() { var p = $('exbEdPop'); if (p) p.remove(); }
  function pop(btn, html, onClick) {
    closePop(); if (!cur) return;
    var p = d.createElement('div'); p.id = 'exbEdPop'; p.innerHTML = html; cur.holder.appendChild(p);
    var hb = cur.holder.getBoundingClientRect(), bb = btn.getBoundingClientRect();
    p.style.left = Math.max(4, Math.min(bb.left - hb.left, hb.width - p.offsetWidth - 4)) + 'px'; p.style.top = (bb.bottom - hb.top + 2) + 'px';
    p.addEventListener('mousedown', function (e) { e.preventDefault(); });
    p.addEventListener('click', function (e) { var b = e.target.closest('[data-v]'); if (!b) return; closePop(); onClick(b.getAttribute('data-v')); });
    setTimeout(function () { d.addEventListener('mousedown', function off(e) { if (!p.contains(e.target)) { closePop(); d.removeEventListener('mousedown', off, true); } else d.removeEventListener('mousedown', off, true); }, true); }, 0);
  }
  function symbolsPop(btn) {
    pop(btn, '<div class="sym">' + SYMBOLS.map(function (s) { return '<button type="button" data-v="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') + '</div>', function (v) { insertText(v); });
  }

  /* ───────────── rechercher / remplacer ───────────── */
  function findOpen(rep) {
    var f = $('exbEdFind'); if (!f) return; f.style.display = 'flex';
    $('exbEdFindRep').style.display = rep ? '' : 'none';
    var q = $('exbEdFindQ'), t = selText(); if (t && t.length < 80 && t.indexOf('\n') < 0) q.value = t; q.focus(); q.select(); findCount();
  }
  function findClose() { var f = $('exbEdFind'); if (f) f.style.display = 'none'; if (cur) restoreSel(); }
  function fq() { return ($('exbEdFindQ') || {}).value || ''; }
  function fcs() { var c = $('exbEdFindCase'); return !!(c && c.checked); }
  function findCount() {
    var q = fq(), el = $('exbEdFindN'); if (!el || !cur) return 0; if (!q) { el.textContent = ''; return 0; }
    var t = cur.ed.innerText || '', n = 0, a = fcs() ? t : t.toLowerCase(), b = fcs() ? q : q.toLowerCase(), i = 0;
    while ((i = a.indexOf(b, i)) >= 0) { n++; i += Math.max(1, b.length); }
    el.textContent = n + ' résultat' + (n > 1 ? 's' : ''); return n;
  }
  function findNext(back) {
    var q = fq(); if (!q || !cur) return false;
    cur.ed.focus(); if (cur.last) { var s0 = w.getSelection(); s0.removeAllRanges(); s0.addRange(cur.last); }
    var ok = w.find(q, fcs(), !!back, true, false, false, false), s = w.getSelection();
    if (ok && !inEd(s.anchorNode)) {
      var r = d.createRange(); r.selectNodeContents(cur.ed); r.collapse(!back); s.removeAllRanges(); s.addRange(r); ok = w.find(q, fcs(), !!back, false, false, false, false);
    }
    if (ok && inEd(s.anchorNode)) { saveSel(); var rg = s.getRangeAt(0), rc = rg.getBoundingClientRect(), wr = $('exbEdWrap').getBoundingClientRect(); if (rc.top < wr.top + 40 || rc.bottom > wr.bottom - 10) { var nd = s.anchorNode.nodeType === 3 ? s.anchorNode.parentNode : s.anchorNode; if (nd.scrollIntoView) nd.scrollIntoView({ block: 'center' }); } refresh(); return true; }
    say('Aucun résultat pour « ' + q + ' ».', 'error'); return false;
  }
  function findReplace() {
    if (!cur || cur.ro) return; var q = fq(), t = selText();
    if (t && (fcs() ? t === q : t.toLowerCase() === q.toLowerCase())) { restoreSel(); d.execCommand('insertText', false, ($('exbEdFindR') || {}).value || ''); saveSel(); sync(); findCount(); }
    findNext(false);
  }
  function findAll() {
    if (!cur || cur.ro) return; var q = fq(); if (!q) return; var rep = ($('exbEdFindR') || {}).value || '', n = 0;
    cur.ed.focus(); var r = d.createRange(); r.selectNodeContents(cur.ed); r.collapse(true); var s = w.getSelection(); s.removeAllRanges(); s.addRange(r);
    while (n < 2000 && w.find(q, fcs(), false, false, false, false, false)) { if (!inEd(s.anchorNode)) break; d.execCommand('insertText', false, rep); n++; }
    saveSel(); sync(); findCount(); say(n + ' remplacement' + (n > 1 ? 's' : '') + ' effectué' + (n > 1 ? 's' : '') + '.');
  }

  /* ───────────── reproduire la mise en forme ───────────── */
  function fmtAt() {
    var s = w.getSelection(), n = s && s.anchorNode; if (!n || !inEd(n)) return null;
    var el = n.nodeType === 3 ? n.parentNode : n, cs = w.getComputedStyle(el), q = function (c) { try { return d.queryCommandState(c); } catch (e) { return false; } };
    var hl = ''; for (var x = el; x && x !== cur.ed && !hl; x = x.parentNode) if (x.nodeType === 1) hl = rgbHex(x.style.backgroundColor || '');
    return { b: q('bold'), i: q('italic'), u: q('underline'), s: q('strikeThrough'), sub: q('subscript'), sup: q('superscript'), font: fontOf(cs.fontFamily), size: Math.round((parseFloat(cs.fontSize) || 14.67) * 0.75), color: rgbHex(cs.color), hl: hl,
      al: q('justifyCenter') ? 'justifyCenter' : q('justifyRight') ? 'justifyRight' : q('justifyFull') ? 'justifyFull' : 'justifyLeft' };
  }
  function paintApply(f) {
    var q = function (c) { try { return d.queryCommandState(c); } catch (e) { return false; } };
    restoreSel(); try { d.execCommand('styleWithCSS', false, true); } catch (e) {}
    [['bold', f.b], ['italic', f.i], ['underline', f.u], ['strikeThrough', f.s], ['subscript', f.sub], ['superscript', f.sup]].forEach(function (p) { if (q(p[0]) !== !!p[1]) d.execCommand(p[0], false, null); });
    if (f.font) d.execCommand('fontName', false, f.font);
    if (f.color && f.color !== DEF_COLOR) d.execCommand('foreColor', false, f.color);
    d.execCommand('hiliteColor', false, f.hl || 'transparent');
    if (f.size) applySize(f.size);
    d.execCommand(f.al, false, null);
    saveSel(); sync(); refresh();
  }

  /* ───────────── ruban ───────────── */
  function ico(t) {
    var L = { left: [[2, 14], [2, 10], [2, 14], [2, 8]], center: [[2, 14], [4, 12], [2, 14], [5, 11]], right: [[2, 14], [6, 14], [2, 14], [8, 14]], justify: [[2, 14], [2, 14], [2, 14], [2, 14]] }[t];
    return '<svg width="18" height="18" viewBox="0 0 16 16" aria-hidden="true">' + L.map(function (l, i) { return '<line x1="' + l[0] + '" y1="' + (3 + i * 3.4) + '" x2="' + l[1] + '" y2="' + (3 + i * 3.4) + '" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'; }).join('') + '</svg>';
  }
  /* b(commande, icône, étiquette, infobulle, options) : options.big = grand bouton, options.view = utilisable en lecture seule */
  function b(c, icon, label, title, o) {
    o = o || {};
    return '<button type="button" class="rb' + (o.big ? ' big' : '') + '" data-c="' + c + '" title="' + esc(title || label || '') + '"' + (o.view ? ' data-view="1"' : '') + (o.img ? ' data-img="1" disabled' : '') + '>' +
      '<span class="ic">' + icon + '</span>' + (label ? '<span class="lb">' + label + '</span>' : '') + '</button>';
  }
  function G(name, inner) { return '<div class="grp"><div class="rows">' + inner + '</div><div class="gl">' + name + '</div></div>'; }
  function col(inner) { return '<div class="col">' + inner + '</div>'; }
  function row(inner) { return '<div class="rw">' + inner + '</div>'; }
  function sel(c, title, opts, o) { return '<select data-c="' + c + '"' + ((o && o.id) ? ' id="' + o.id + '"' : '') + ' title="' + esc(title) + '"' + ((o && o.view) ? ' data-view="1"' : '') + ((o && o.w) ? ' style="width:' + o.w + 'px"' : '') + '>' + opts + '</select>'; }

  function ribbon() {
    var fonts = sel('font', 'Police', '<option value="">Police…</option>' + FONT_LIST.map(function (f) { return '<option value="' + esc(f) + '" style="font-family:\'' + esc(f) + '\'">' + esc(f) + '</option>'; }).join(''), { id: 'exbEdFont', w: 128 });
    var sizes = sel('size', 'Taille de police (pt)', SIZES.map(function (n) { return '<option value="' + n + '"' + (n === 11 ? ' selected' : '') + '>' + n + '</option>'; }).join(''), { id: 'exbEdSize', w: 62 });
    var vars = sel('var', 'Insérer une donnée du chantier', '<option value="">{{ }} Donnée…</option>' + (X.VARS || []).map(function (q) { return '<option value="' + q[0] + '">' + esc(q[1]) + '</option>'; }).join(''), { w: 138 });
    var spac = sel('spacing', 'Interligne', '<option value="">Interligne…</option>' + [['1', '1,0'], ['1.15', '1,15'], ['1.5', '1,5 (défaut)'], ['2', '2,0'], ['2.5', '2,5'], ['3', '3,0']].map(function (x) { return '<option value="' + x[0] + '">' + x[1] + '</option>'; }).join(''), { id: 'exbEdSpacing', w: 96 });
    var zoom = sel('zoom', 'Zoom', '<option value="auto">Zoom : ajusté</option>' + [50, 75, 100, 125, 150, 200].map(function (z) { return '<option value="' + z + '">' + z + ' %</option>'; }).join(''), { id: 'exbEdZoom', w: 118, view: 1 });
    var gal = '<div class="gal">' + [['p', 'Normal', 'AaBbCc', 'Texte normal'], ['h2', 'Titre 1', 'AaBbCc', 'Titre 1 (grand titre souligné)'], ['h3', 'Titre 2', 'AaBbCc', 'Titre 2'], ['h4', 'Titre 3', 'AaBbCc', 'Titre 3']].map(function (s) {
      return '<button type="button" class="rb st st-' + s[0] + '" data-c="style" data-s="' + s[0] + '" title="' + esc(s[3]) + '"><span class="sa">' + s[2] + '</span><span class="sn">' + s[1] + '</span></button>';
    }).join('') + '</div>';
    var colA = '<span class="cb"><button type="button" class="rb" data-c="color" title="Couleur du texte"><span class="ic"><b style="font-size:15px">A</b></span><i id="exbEdColBar" style="background:#b91c1c"></i></button><span class="dd">▾</span><input type="color" id="exbEdColor" value="#b91c1c" title="Choisir la couleur du texte"></span>';
    var colH = '<span class="cb"><button type="button" class="rb" data-c="hilite" title="Surlignage"><span class="ic"><b style="font-size:13px;background:#fff59d;padding:0 2px">ab</b></span><i id="exbEdHlBar" style="background:#ffe600"></i></button><span class="dd">▾</span><input type="color" id="exbEdHl" value="#ffe600" title="Choisir la couleur de surlignage"></span>';
    var colB = '<span class="cb"><button type="button" class="rb" data-c="shade" title="Trame de fond du paragraphe (bandeau coloré)"><span class="ic"><b style="font-size:13px;background:#0b4aa8;color:#fff;padding:0 3px">▇</b></span><i id="exbEdBgBar" style="background:#0b4aa8"></i></button><span class="dd">▾</span><input type="color" id="exbEdBg" value="#0b4aa8" title="Choisir la couleur de la trame"></span>';
    var P = {};
    P.fichier = G('Document', b('save', '💾', 'Enregistrer', 'Enregistrer (Ctrl+S)', { big: 1 }) + b('print', '📄', 'PDF officiel', 'Ouvrir le PDF officiel avec en-tête, pied de page et QR', { big: 1, view: 1 }) + b('saveMod', '⭐', 'Enregistrer comme modèle', 'Réutiliser ce texte pour d’autres projets', { big: 1 }) + b('dup', '⧉', 'Dupliquer', 'Créer une copie de cette pièce', { big: 1 }) + b('docx', '📝', 'Exporter en Word', 'Télécharger ce texte au format Word (.docx)', { big: 1, view: 1 }) + b('fillv', '↻', 'Remplir les données', 'Remplacer les {{données}} par celles du projet', { big: 1 })) +
      G('Mode', b('mode', '⌨', 'Mode texte', 'Revenir à la zone de texte brute', { big: 1, view: 1 }) + b('back', '←', 'Liste', 'Retour à la liste des pièces', { big: 1, view: 1 }));
    P.accueil = G('Presse-papiers', b('paste', '📋', 'Coller', 'Coller (Ctrl+V)', { big: 1 }) + col(b('cut', '✂', 'Couper', 'Couper (Ctrl+X)') + b('copy', '⧉', 'Copier', 'Copier (Ctrl+C)') + b('painter', '🖌', 'Reproduire la mise en forme', 'Reproduire la mise en forme : cliquez, puis sélectionnez le texte à mettre en forme')))
      + G('Police', col(row(fonts + sizes + b('size+', 'A<sup>^</sup>', '', 'Agrandir la police') + b('size-', 'A<sub>v</sub>', '', 'Réduire la police')) +
        row(b('bold', '<b>G</b>', '', 'Gras (Ctrl+B)') + b('italic', '<i>I</i>', '', 'Italique (Ctrl+I)') + b('underline', '<u>S</u>', '', 'Souligné (Ctrl+U)') + b('strike', '<s>abc</s>', '', 'Barré') + b('sub', 'x<sub>2</sub>', '', 'Indice') + b('sup', 'x<sup>2</sup>', '', 'Exposant') + colA + colH + b('case', 'Aa', '', 'Modifier la casse (majuscules, minuscules…)') + b('clear', 'Tx', '', 'Effacer la mise en forme'))))
      + G('Paragraphe', col(row(b('ul', '• ☰', '', 'Liste à puces') + b('ol', '1.☰', '', 'Liste numérotée') + b('outdent', '⇤', '', 'Diminuer le retrait (Maj+Tab) — liste : remonte d’un niveau') + b('indent', '⇥', '', 'Augmenter le retrait (Tab) — liste : descend d’un niveau') + spac) +
        row(b('left', ico('left'), '', 'Aligner à gauche') + b('center', ico('center'), '', 'Centrer') + b('right', ico('right'), '', 'Aligner à droite') + b('full', ico('justify'), '', 'Justifier') + b('marks', '¶', '', 'Afficher / masquer les marques de paragraphe', { view: 1 }) + colB + b('unshade', '∅', '', 'Retirer la trame de fond'))))
      + G('Styles', gal + b('styles+', '▾', '', 'Plus de styles (bandeaux colorés…)'))
      + G('Insertion', b('image', '🖼', 'Image', 'Insérer une image', { big: 1 }) + b('table', '▦', 'Tableau', 'Insérer un tableau', { big: 1 }) + b('link', '🔗', 'Lien', 'Insérer un lien (Ctrl+K)', { big: 1 }) + b('symbol', 'Ω', 'Symbole', 'Insérer un symbole', { big: 1 }))
      + G('Édition', col(b('find', '🔍', 'Rechercher', 'Rechercher (Ctrl+F)', { view: 1 }) + b('replace', '⇄', 'Remplacer', 'Remplacer (Ctrl+H)')));
    P.insertion = G('Pages', b('pb', '⤓', 'Saut de page', 'Insérer un saut de page', { big: 1 }) + b('hr', '―', 'Séparateur', 'Ligne de séparation', { big: 1 }))
      + G('Tableau', b('table', '▦', 'Tableau', 'Insérer un tableau', { big: 1 }) + col(b('row+', '＋', 'Ligne', 'Ajouter une ligne') + b('row-', '－', 'Ligne', 'Supprimer la ligne')) + col(b('col+', '＋', 'Colonne', 'Ajouter une colonne') + b('col-', '－', 'Colonne', 'Supprimer la colonne')) + b('tdel', '✕', 'Supprimer', 'Supprimer le tableau', { big: 1 }))
      + G('Illustrations', b('image', '🖼', 'Image', 'Insérer une image (PNG, JPG, WebP)', { big: 1 }) + col(row(b('w25', '25 %', '', 'Largeur 25 %', { img: 1 }) + b('w50', '50 %', '', 'Largeur 50 %', { img: 1 }) + b('w75', '75 %', '', 'Largeur 75 %', { img: 1 }) + b('w100', '100 %', '', 'Largeur 100 %', { img: 1 })) + row(b('ifl', '◧', '', 'Texte autour : image à gauche', { img: 1 }) + b('ifr', '◨', '', 'Texte autour : image à droite', { img: 1 }) + b('ial', '⬅', '', 'Image à gauche (sans texte autour)', { img: 1 }) + b('ic', '↔', '', 'Image centrée', { img: 1 }) + b('iar', '➡', '', 'Image à droite', { img: 1 }) + b('crop', '✂ Rogner', '', 'Rogner l’image (comme dans Word)', { img: 1 }) + b('uncrop', '↺ Rétablir', '', 'Rétablir l’image d’origine (tant que le document reste ouvert)', { img: 1 }) + b('imgdel', '✕', '', 'Supprimer l’image sélectionnée', { img: 1 }))))
      + G('Liens', b('link', '🔗', 'Lien', 'Insérer ou modifier un lien (Ctrl+K)', { big: 1 }) + b('unlink', '⛓', 'Retirer', 'Retirer le lien', { big: 1 }))
      + G('Texte', b('symbol', 'Ω', 'Symbole', 'Insérer un symbole', { big: 1 }) + b('date', '📅', 'Date du jour', 'Insérer la date du jour', { big: 1 }) + col(vars));
    P.mise = G('Paragraphe', col(row(b('outdent', '⇤', 'Retrait −', 'Diminuer le retrait') + b('indent', '⇥', 'Retrait +', 'Augmenter le retrait')) + row(spac)) + col(row(b('left', ico('left'), '', 'Aligner à gauche') + b('center', ico('center'), '', 'Centrer')) + row(b('right', ico('right'), '', 'Aligner à droite') + b('full', ico('justify'), '', 'Justifier'))))
      + G('Pages', b('pb', '⤓', 'Saut de page', 'Insérer un saut de page', { big: 1 }) + b('hr', '―', 'Séparateur', 'Ligne de séparation', { big: 1 }))
      + '<div class="note">Les marges A4, l’en-tête de la société, le pied de page, le QR de vérification et la signature sont posés automatiquement par le PDF officiel.</div>';
    P.ref = G('Données', col(vars) + b('fillv', '↻', 'Remplir les données', 'Remplacer les {{données}} par celles du projet', { big: 1 }))
      + G('Sommaire', b('toc', '☰', 'Sommaire', 'Insérer un sommaire à partir des titres', { big: 1 }))
      + G('Titres', col(b('style1', 'Titre 1', '', 'Appliquer le style Titre 1') + b('style2', 'Titre 2', '', 'Appliquer le style Titre 2') + b('style3', 'Titre 3', '', 'Appliquer le style Titre 3')));
    P.rev = G('Recherche', b('find', '🔍', 'Rechercher', 'Rechercher (Ctrl+F)', { big: 1, view: 1 }) + b('replace', '⇄', 'Remplacer', 'Remplacer (Ctrl+H)', { big: 1 }))
      + G('Vérification', b('spell', 'abc✓', 'Orthographe', 'Activer / désactiver la correction orthographique', { big: 1, view: 1 }) + b('stats', '123', 'Statistiques', 'Mots, caractères, paragraphes, pages…', { big: 1, view: 1 }));
    P.aff = G('Zoom', col(row(zoom) + row(b('zoom-', '－', '', 'Zoom arrière', { view: 1 }) + b('zoom+', '＋', '', 'Zoom avant', { view: 1 }) + b('zoomfit', 'Ajuster', '', 'Ajuster à la largeur', { view: 1 }))))
      + G('Afficher', b('ruler', '📏', 'Règle', 'Afficher / masquer la règle', { big: 1, view: 1 }) + b('marks', '¶', 'Marques', 'Afficher / masquer les marques de paragraphe', { big: 1, view: 1 }) + b('fscreen', '⛶', 'Plein écran', 'Plein écran (Échap pour quitter)', { big: 1, view: 1 }))
      + G('Mode', b('mode', '⌨', 'Mode texte', 'Revenir à la zone de texte brute', { big: 1, view: 1 }));
    P.aide = G('Aide', b('keys', '⌨', 'Raccourcis', 'Raccourcis clavier', { big: 1, view: 1 }) + b('marks_help', '{ }', 'Repères du texte', 'Comment le texte est enregistré', { big: 1, view: 1 }) + b('about', 'ℹ', 'À propos', 'À propos de l’éditeur', { big: 1, view: 1 }));
    var T = [['fichier', 'Fichier'], ['accueil', 'Accueil'], ['insertion', 'Insertion'], ['mise', 'Mise en page'], ['ref', 'Références'], ['rev', 'Révision'], ['aff', 'Affichage'], ['aide', 'Aide']];
    return '<div id="exbEdTabs" role="tablist">' + T.map(function (t) { return '<button type="button" role="tab" class="tb' + (t[0] === 'fichier' ? ' fich' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '<span class="qa">' + b('undo', '↶', '', 'Annuler (Ctrl+Z)') + b('redo', '↷', '', 'Rétablir (Ctrl+Y)') + '</span></div>' +
      T.map(function (t) { return '<div class="pn" data-pn="' + t[0] + '" role="tabpanel" style="display:none">' + P[t[0]] + '</div>'; }).join('') +
      '<div id="exbEdFind" style="display:none"><div class="fr"><input id="exbEdFindQ" placeholder="Rechercher…" aria-label="Rechercher"><button type="button" data-f="prev" title="Précédent">▲</button><button type="button" data-f="next" title="Suivant">▼</button><label><input type="checkbox" id="exbEdFindCase"> Aa</label><span id="exbEdFindN"></span><button type="button" data-f="close" title="Fermer">✕</button></div>' +
      '<div class="fr" id="exbEdFindRep"><input id="exbEdFindR" placeholder="Remplacer par…" aria-label="Remplacer par"><button type="button" data-f="rep">Remplacer</button><button type="button" data-f="all">Tout remplacer</button></div></div>';
  }
  function css() {
    if ($('exbEdCss')) return;
    var rules = (String(X.CSS).match(/\.bd[^{}]*\{[^}]*\}/g) || []).map(function (r) { return '#exbEdSheet' + r.replace(/^\.bd/, '').replace(/,\.bd/g, ',#exbEdSheet'); }).join('');
    var s = d.createElement('style'); s.id = 'exbEdCss';
    s.textContent = rules +
      '#exbEd{position:relative;margin:8px 0;border:1px solid #c5d0e3;border-radius:10px;background:#dfe6f2;overflow:hidden;font:13px Arial,sans-serif;color:#13294b}' +
      '#exbEd.full{position:fixed;inset:0;z-index:100000;margin:0;border-radius:0;display:flex;flex-direction:column}#exbEd.full #exbEdWrap{flex:1;max-height:none}' +
      '#exbEdTabs{display:flex;gap:2px;background:#eef2f9;padding:6px 8px 0;overflow-x:auto;white-space:nowrap;border-bottom:1px solid #c5d0e3}' +
      '#exbEdTabs .tb{border:0;background:transparent;padding:7px 12px;font:14px Arial;color:#1c2f55;border-radius:6px 6px 0 0;cursor:pointer;flex:none}#exbEdTabs .qa{margin-left:auto;display:flex;gap:2px;align-items:center;padding-left:8px;flex:none}#exbEdTabs .tb:hover{background:#e0e8f5}' +
      '#exbEdTabs .tb.on{background:#fff;color:#0b3d91;font-weight:bold;box-shadow:inset 0 -3px 0 #1d6fe0}#exbEdTabs .tb.fich{background:#1d6fe0;color:#fff;margin-right:4px}#exbEdTabs .tb.fich.on{background:#0b4aa2;box-shadow:none}' +
      '#exbEd .pn{display:flex;align-items:stretch;gap:0;background:#fff;padding:6px 8px 4px;overflow-x:auto;border-bottom:2px solid #c49a38;min-height:92px}' +
      '#exbEd .grp{display:flex;flex-direction:column;justify-content:space-between;padding:0 8px;border-right:1px solid #dbe2ee;flex:none}#exbEd .grp:last-child{border:0}' +
      '#exbEd .rows{display:flex;gap:3px;align-items:flex-start;flex:1}#exbEd .gl{text-align:center;font-size:11px;color:#5b6b86;padding-top:3px;white-space:nowrap}' +
      '#exbEd .col{display:flex;flex-direction:column;gap:3px}#exbEd .rw{display:flex;gap:2px;align-items:center}' +
      '#exbEd .rb{min-width:28px;height:28px;padding:0 6px;border:1px solid transparent;border-radius:6px;background:transparent;color:#13294b;font:13px Arial;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:5px;white-space:nowrap}' +
      '#exbEd .rb:hover:not(:disabled){background:#e8f0fc;border-color:#bcd0ee}#exbEd .rb.on{background:#cfe0fa;border-color:#8fb3ec}#exbEd .rb:disabled{opacity:.38;cursor:default}' +
      '#exbEd .rb.big{flex-direction:column;height:66px;min-width:56px;max-width:88px;gap:2px;padding:4px 5px;white-space:normal;text-align:center}#exbEd .rb.big .ic{font-size:24px;line-height:28px}#exbEd .rb.big .lb{font-size:11.5px;line-height:1.1}' +
      '#exbEd .col .rb{justify-content:flex-start;height:20px;font-size:12px}#exbEd .col .rb .ic{font-size:14px}' +
      '#exbEd .rw .rb{height:28px}#exbEd select{height:26px;border:1px solid #bcc9de;border-radius:5px;background:#fff;color:#13294b;font:12.5px Arial;max-width:150px}' +
      '#exbEd .cb{display:inline-flex;align-items:center;position:relative}#exbEd .cb .rb{flex-direction:column;gap:0;padding:0 4px}#exbEd .cb i{display:block;width:16px;height:3px;margin-top:-3px;border-radius:1px}' +
      '#exbEd .cb input[type=color]{position:absolute;right:0;top:0;width:14px;height:26px;padding:0;border:0;opacity:0;cursor:pointer}#exbEd .cb .dd{font-size:9px;color:#41567f;width:12px;text-align:center;pointer-events:none}' +
      '@media(min-width:700px){#exbEd .pn{flex-wrap:wrap;row-gap:4px}}' +
      '#exbEd .gal{display:flex;gap:4px;align-items:stretch}#exbEd .st{flex-direction:column;width:68px;height:52px;border:1px solid #cdd6e6;background:#fff;gap:2px;padding:2px}#exbEd .st .sa{font-size:15px;line-height:1.1;color:#111}#exbEd .st .sn{font-size:11px;color:#41567f}' +
      '#exbEd .st-h2 .sa{color:#173565;font-weight:bold;font-size:16px}#exbEd .st-h3 .sa{color:#173565;font-weight:bold;font-size:14px}#exbEd .st-h4 .sa{font-weight:bold;font-size:13px}#exbEd .st.on{border:2px solid #1d6fe0;background:#eaf2ff}' +
      '#exbEd .note{align-self:center;max-width:280px;font-size:12px;color:#5b6b86;padding:0 10px}' +
      '#exbEdFind{flex-direction:column;gap:4px;background:#f6f8fc;border-bottom:1px solid #c5d0e3;padding:6px 10px}#exbEdFind .fr{display:flex;gap:6px;align-items:center;flex-wrap:wrap}' +
      '#exbEdFind input[type=text],#exbEdFind input:not([type]){height:28px;border:1px solid #bcc9de;border-radius:5px;padding:0 8px;min-width:160px;flex:1 1 160px;max-width:300px}#exbEdFind button{height:28px;padding:0 10px;border:1px solid #bcc9de;border-radius:5px;background:#fff;color:#13294b;cursor:pointer}#exbEdFindN{font-size:12px;color:#5b6b86}' +
      '#exbEdPop{position:absolute;z-index:6;background:#fff;border:1px solid #bcc9de;border-radius:8px;box-shadow:0 6px 20px rgba(20,35,70,.25);padding:6px}#exbEdPop .sym{display:grid;grid-template-columns:repeat(10,30px);gap:2px}#exbEdPop .sym button{height:30px;border:1px solid #e1e7f2;border-radius:4px;background:#fff;font:15px Arial;cursor:pointer}#exbEdPop .sym button:hover{background:#e8f0fc}' +
      '#exbEdWrap{position:relative;padding:0 8px 14px;max-height:62vh;overflow:auto;background:#dfe6f2}' +
      '#exbEdZ{width:' + PAGE_W + 'px;margin:0 auto;transform-origin:top center}' +
      '#exbEdRuler{position:sticky;top:0;z-index:2;height:20px;margin:0 0 6px;background:#fff;border:1px solid #c5d0e3;border-top:0;border-radius:0 0 4px 4px;overflow:hidden;font:9px Arial;color:#5b6b86}#exbEdRuler .m{position:absolute;top:0;bottom:0;background:#cbd5e6}#exbEdRuler .t{position:absolute;bottom:0;width:1px;background:#8a98b3;height:5px}#exbEdRuler .t.c{height:9px}#exbEdRuler .n{position:absolute;top:1px;transform:translateX(-50%)}' +
      '#exbEdPage{box-sizing:border-box;width:' + PAGE_W + 'px;min-height:970px;background:#fff;padding:30px 53px 20px;box-shadow:0 2px 12px rgba(20,35,70,.25);color:#111}' +
      '#exbEdPage .hd{display:flex;align-items:center;gap:16px;border-bottom:3px solid #c49a38;padding-bottom:9px;margin-bottom:12px;user-select:none;pointer-events:none}#exbEdPage .hd img{height:84px;max-width:210px;object-fit:contain;flex:none}#exbEdPage .hd .nm{font:bold 18pt Arial;color:#173565;line-height:1.1}#exbEdPage .hd .tg{font:italic 9.5pt Arial;color:#8a6a1c;margin-top:2px}#exbEdPage .hd .ct{margin-left:auto;text-align:right;font:8.5pt/1.45 Arial;color:#333;max-width:46%}' +
      '#exbEdPage .ft{margin-top:14px;border-top:2px solid #173565;padding-top:5px;font:7.5pt Arial;color:#8a98b3;text-align:center;user-select:none}' +
      '#exbEdSheet{box-sizing:border-box;min-height:760px;font:11pt/1.5 Arial,Helvetica,sans-serif;color:#111;outline:0}#exbEdSheet[contenteditable=false]{background:#fafafa}#exbEdSheet.painter{cursor:crosshair}' +
      '#exbEdSheet .pb{height:20px;margin:10px 0;border-top:1px dashed #94a3b8;text-align:center;font:10px Arial;color:#94a3b8;page-break-after:auto;user-select:none}#exbEdSheet .pb::after{content:"saut de page";position:relative;top:-8px;background:#fff;padding:0 6px}' +
      '#exbEdSheet table{border-collapse:collapse;width:100%;margin:6px 0}#exbEdSheet td,#exbEdSheet th{border:1px solid #777;padding:4px 6px;min-width:30px}#exbEdSheet th{background:#e8edf5;color:#173565}' +
      '#exbEdSheet p{margin:0 0 6px;text-align:justify}#exbEdSheet p.sp{min-height:1.5em}#exbEdSheet img{cursor:pointer;max-width:100%;height:auto}#exbEdSheet img.sel{outline:2px solid #1d6fe0;outline-offset:1px}#exbEdSheet a{color:#1d4ed8;text-decoration:underline}' +
      '#exbEdSheet.marks p::after,#exbEdSheet.marks li::after,#exbEdSheet.marks h2::after,#exbEdSheet.marks h3::after,#exbEdSheet.marks h4::after{content:"¶";color:#9db0d0;font-size:.8em;margin-left:2px}' +
      '#exbEd.read #exbEdTabs,#exbEd.read .pn,#exbEd.read #exbEdFind{display:none}#exbEdSheet h2,#exbEdSheet h3,#exbEdSheet h4{margin:8px 0 6px}' +
      '#exbEdBar2{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:3px 12px;font:12px Arial;color:#1c2f55;background:#eef2f9;border-top:1px solid #c5d0e3;flex-wrap:wrap}#exbEdBar2 .l{display:flex;gap:14px;flex-wrap:wrap}#exbEdBar2 .r{display:flex;gap:6px;align-items:center}' +
      '#exbEdBar2 button{border:0;background:transparent;font:16px Arial;color:#1c2f55;cursor:pointer;padding:0 4px}#exbEdBar2 input[type=range]{width:120px}';
    d.head.appendChild(s);
  }
  function applyZoom(v) {
    if (!cur) return; var wrap = $('exbEdWrap'); if (!wrap) return;
    var z;
    if (v === 'auto' || !v) { cur.zoomAuto = true; z = Math.min(1, Math.max(0.4, (wrap.clientWidth - 24) / (PAGE_W + 12))); }
    else { cur.zoomAuto = false; z = Math.max(0.3, Math.min(2, (+v) / 100)); }
    cur.z.style.zoom = z; cur.page.style.zoom = ''; cur.zoom = z;
    var pct = Math.round(z * 100), sl = $('exbEdZ1'), lb = $('exbEdZ2'); if (sl) sl.value = String(pct); if (lb) lb.textContent = pct + ' %';
    var zs = $('exbEdZoom'); if (zs) { var opt = [].filter.call(zs.options, function (o) { return o.value === String(pct); })[0]; zs.value = cur.zoomAuto ? 'auto' : (opt ? String(pct) : 'auto'); }
    sync();
  }
  function buildRuler() {
    var h = '<div class="m" style="left:0;width:53px"></div><div class="m" style="right:0;width:53px"></div>', cm = PAGE_W / (PAGE_WMM / 10), N = Math.floor(PAGE_WMM / 10), i;
    for (i = 0; i <= N; i++) { h += '<span class="t c" style="left:' + (i * cm).toFixed(1) + 'px"></span>'; if (i > 0 && i < N) h += '<span class="n" style="left:' + (i * cm).toFixed(1) + 'px">' + i + '</span>'; if (i < N) h += '<span class="t" style="left:' + ((i + 0.5) * cm).toFixed(1) + 'px"></span>'; }
    return h;
  }
  /* V144g : la page de l'éditeur suit le format et l'orientation choisis pour la pièce (échelle : A4 = 688 px de large) */
  var PG_T = { A4: [210, 297], A3: [297, 420], A5: [148, 210], Letter: [216, 279], Legal: [216, 356] };
  function setPageFmt(f, o) {
    if (cur) { cur.pfmt = f; cur.pori = o; }
    var a = PG_T[f] || PG_T.A4, L = o === 'landscape', wm = L ? a[1] : a[0], hm = L ? a[0] : a[1];
    PAGE_W = Math.round(wm * 688 / 210); PAGE_WMM = wm; PAGE_USABLE = Math.round(750 * hm / 297);
    var z = $('exbEdZ'), pg = $('exbEdPage'), rl = $('exbEdRuler');
    if (z) z.style.width = PAGE_W + 'px';
    if (pg) { pg.style.width = PAGE_W + 'px'; pg.style.minHeight = Math.round(970 * hm / 297) + 'px'; }
    if (rl) rl.innerHTML = buildRuler();
    if (cur && cur.zoomAuto) applyZoom('auto'); else if (cur) sync();
  }
  if (!w.__pgFmtL) { w.__pgFmtL = 1; d.addEventListener('change', function (e) { var t = e.target; if (t && (t.id === 'pFm' || t.id === 'pOr') && cur) setPageFmt(($('pFm') || {}).value, ($('pOr') || {}).value); }); }
  function identity() {
    var I = {}, C = w.EXB81 || {}; try { I = (w.EXBId && w.EXBId.get && w.EXBId.get()) || {}; } catch (e) {}
    var name = I.name || (C.brand && C.brand()) || '', logo = I.logo || '';
    try { if (/^(data:|https?:|blob:)/.test(logo)) { /* tel quel */ } else if (logo) logo = new URL(logo, w.location.href).href; else if (C.logo) logo = C.logo(); } catch (e) { logo = ''; }
    var place = ''; try { place = w.EXBId && w.EXBId.placeLine ? w.EXBId.placeLine(I) : (I.address || ''); } catch (e) {}
    var contact = [I.phone ? 'Tél : ' + I.phone : '', I.email ? 'E-mail : ' + I.email : ''].filter(Boolean).join(' · ');
    return '<div class="hd">' + (logo ? '<img src="' + esc(logo) + '" alt="">' : '') + '<div><div class="nm">' + esc(name) + '</div>' + (I.tagline ? '<div class="tg">' + esc(I.tagline) + '</div>' : '') + '</div><div class="ct">' + (place ? esc(place) + '<br>' : '') + esc(contact) + '</div></div>';
  }

  /* ───────────── état des boutons ───────────── */
  function setOn(c, on) { if (!cur) return;[].forEach.call(cur.holder.querySelectorAll('[data-c="' + c + '"]'), function (x) { x.classList.toggle('on', !!on); }); }
  function refresh() {
    if (!cur || cur.ro) return;
    var s = w.getSelection(); if (!s || !s.anchorNode || !inEd(s.anchorNode)) return;
    var q = function (c) { try { return d.queryCommandState(c); } catch (e) { return false; } };
    setOn('bold', q('bold')); setOn('italic', q('italic')); setOn('underline', q('underline')); setOn('strike', q('strikeThrough')); setOn('sub', q('subscript')); setOn('sup', q('superscript'));
    setOn('ul', q('insertUnorderedList')); setOn('ol', q('insertOrderedList'));
    setOn('left', q('justifyLeft') && !q('justifyCenter')); setOn('center', q('justifyCenter')); setOn('right', q('justifyRight')); setOn('full', q('justifyFull'));
    var bl = blockOf(s.anchorNode), tg = bl ? bl.tagName.toLowerCase() : 'p', key2 = /^h[234]$/.test(tg) ? tg : 'p';
    [].forEach.call(cur.holder.querySelectorAll('.st'), function (x) { x.classList.toggle('on', x.getAttribute('data-s') === key2); });
    var el = s.anchorNode.nodeType === 3 ? s.anchorNode.parentNode : s.anchorNode, f = $('exbEdFont'); if (f) f.value = fontOf(w.getComputedStyle(el).fontFamily);
    var sp = $('exbEdSpacing'); if (sp) { var lh = bl && bl.style.lineHeight ? String(parseFloat(bl.style.lineHeight)) : ''; sp.value = [].some.call(sp.options, function (o) { return o.value === lh; }) ? lh : ''; }
    showSize();
    var pi = pagesInfo(), pg = $('exbEdPage1'); if (pg) pg.textContent = 'Page ' + pi.page + ' sur ' + pi.pages;
  }
  function showTab(t) {
    [].forEach.call(cur.holder.querySelectorAll('.pn'), function (p) { p.style.display = p.getAttribute('data-pn') === t ? 'flex' : 'none'; });
    [].forEach.call(cur.holder.querySelectorAll('.tb'), function (x) { x.classList.toggle('on', x.getAttribute('data-tab') === t); x.setAttribute('aria-selected', x.getAttribute('data-tab') === t ? 'true' : 'false'); });
    try { w.localStorage.setItem('EXB_ED_TAB', t); } catch (e) {}
    closePop();
  }

  /* ───────────── installation dans l'écran d'édition ───────────── */
  /* V186d : attach(x, ro, opts) sert aussi hors des pièces écrites (Studio d'affiches). opts = { ta, noIdentity, forceWord, hide:[commandes], fileName, actions:{save,…} } */
  function attach(x, ro, opts) {
    opts = opts || {};
    var ta = opts.ta || $('pBo'); if (!ta) return;
    function act(n) { if (opts.actions && opts.actions[n]) return opts.actions[n](); if (w.EXBPIE && w.EXBPIE[n]) return w.EXBPIE[n](); }
    css(); cur = null;
    var old = ta.previousElementSibling, prev = $('pPrev');
    var holder = d.createElement('div'); holder.id = 'exbEd';
    ta.parentNode.insertBefore(holder, ta);
    function showWord() {
      holder.style.display = ''; ta.style.display = 'none'; if (old) old.style.display = 'none'; if (prev) prev.style.display = 'none';
      var ap = d.querySelector('#exbPie [onclick="EXBPIE.prev()"]'); if (ap) ap.style.display = 'none';
      holder.className = '';
      holder.innerHTML = ribbon() +
        '<div id="exbEdWrap"><div id="exbEdZ"><div id="exbEdRuler">' + buildRuler() + '</div><div id="exbEdPage">' + (opts.noIdentity ? '' : identity()) +
        '<div id="exbEdSheet" class="bd" ' + (ro ? 'contenteditable="false"' : 'contenteditable="true"') + ' spellcheck="true" lang="fr"></div>' +
        (opts.noIdentity ? '' : '<div class="ft">Pied de page, QR de vérification et signature du Directeur : ajoutés automatiquement au PDF officiel</div>') + '</div></div></div>' +
        '<div id="exbEdBar2"><div class="l"><span id="exbEdPage1">Page 1 sur 1</span><span id="exbEdCount">Mots : 0</span><span>Français (France)</span></div>' +
        '<div class="r"><button type="button" data-c="plan" title="Plan du document (titres)" data-view="1">☰</button><button type="button" data-c="lect" title="Mode lecture (masque le ruban)" data-view="1">📖</button><button type="button" data-c="zoom-" title="Zoom arrière" data-view="1">－</button><input type="range" id="exbEdZ1" min="40" max="200" step="5" value="100" aria-label="Zoom"><button type="button" data-c="zoom+" title="Zoom avant" data-view="1">＋</button><span id="exbEdZ2" style="min-width:44px;text-align:right">100 %</span></div></div>' +
        '<input type="file" id="exbEdFile" accept="image/*" style="display:none">';
      var ed = $('exbEdSheet'); ed.innerHTML = toHtml(ta.value);
      [].forEach.call(ed.querySelectorAll('.pb'), function (e) { e.setAttribute('contenteditable', 'false'); });
      cur = { ta: ta, ed: ed, ro: ro, last: null, img: null, painter: null, col: '#b91c1c', hl: '#ffe600', holder: holder, page: $('exbEdPage'), z: $('exbEdZ'), zoomAuto: true, zoom: 1 };
      var tab = 'accueil'; try { tab = w.localStorage.getItem('EXB_ED_TAB') || 'accueil'; } catch (e) {} if (!holder.querySelector('[data-tab="' + tab + '"]')) tab = 'accueil';
      if (opts.hide) { opts.hide.forEach(function (c) { [].forEach.call(holder.querySelectorAll('button[data-c="' + c + '"]'), function (b) { b.remove(); }); }); [].forEach.call(holder.querySelectorAll('.grp'), function (g) { if (!g.querySelector('button,select')) g.remove(); }); }
      cur.fname = opts.fileName || '';
      showTab(tab);
      if (ro) [].forEach.call(holder.querySelectorAll('button[data-c],select[data-c],input[type=color]'), function (el) { if (!el.hasAttribute('data-view')) el.disabled = true; });
      try { d.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}
      ed.addEventListener('input', function () { normalizeRoot(); sync(); });
      ed.addEventListener('keyup', function () { saveSel(); refresh(); });
      ed.addEventListener('mouseup', function (e) {
        saveSel();
        if (e.target && e.target.tagName === 'IMG') selectImg(e.target); else if (cur.img) selectImg(null);
        if (cur.painter) { var s = w.getSelection(); if (s && !s.isCollapsed) { paintApply(cur.painter); cur.painter = null; ed.classList.remove('painter'); setOn('painter', false); } }
        refresh();
      });
      ed.addEventListener('click', function (e) { var a = e.target.closest && e.target.closest('a'); if (a && (e.ctrlKey || e.metaKey)) { var h = safeHref(a.getAttribute('href')); if (h) w.open(h, '_blank', 'noopener'); } });
      ed.addEventListener('blur', function () { saveSel(); sync(); });
      ed.addEventListener('keydown', function (e) {
        var k = String(e.key || '').toLowerCase(), mod = e.ctrlKey || e.metaKey;
        if (mod && k === 's') { e.preventDefault(); sync(); act('save'); return; }
        if (mod && k === 'f') { e.preventDefault(); findOpen(false); return; }
        if (mod && k === 'h') { e.preventDefault(); findOpen(true); return; }
        if (ro) return;
        if (mod && k === 'k') { e.preventDefault(); insertLink(); return; }
        if (k === 'tab') {
          var c = cellOf();
          if (c) { e.preventDefault(); var cells = [].slice.call(c.closest('table').querySelectorAll('td,th')), i = cells.indexOf(c) + (e.shiftKey ? -1 : 1); if (i >= cells.length) { tableOp('row+'); cells = [].slice.call(c.closest('table').querySelectorAll('td,th')); } var t = cells[Math.max(0, i)]; if (t) { var r = d.createRange(); r.selectNodeContents(t); r.collapse(false); var s = w.getSelection(); s.removeAllRanges(); s.addRange(r); saveSel(); } return; }
          e.preventDefault(); saveSel(); indent(e.shiftKey ? -1 : 1); return;
        }
        if (k === 'escape' && cur.painter) { cur.painter = null; ed.classList.remove('painter'); setOn('painter', false); }
      });
      ed.addEventListener('paste', function (e) {
        if (ro) return; e.preventDefault();
        var cd = e.clipboardData || w.clipboardData, fl = cd && cd.files && cd.files[0];
        if (fl && /^image\//.test(fl.type)) { loadImage(fl, putImage); return; }
        var t = ''; try { t = cd.getData('text/plain'); } catch (z) {}
        if (t) d.execCommand('insertText', false, t);
      });
      ed.addEventListener('drop', function (e) {
        var fl = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (!fl || !/^image\//.test(fl.type)) return; e.preventDefault(); if (ro) return; loadImage(fl, putImage);
      });
      holder.addEventListener('mousedown', function (e) { var t = e.target; if (t.closest && t.closest('button') && !t.closest('#exbEdFind') && !t.closest('#exbEdTabs')) e.preventDefault(); }); /* garde la sélection du texte */
      holder.addEventListener('click', onClick);
      holder.addEventListener('change', onChange);
      holder.addEventListener('input', function (e) {
        if (e.target.id === 'exbEdColor') { $('exbEdColBar').style.background = e.target.value; cur.col = e.target.value; }
        if (e.target.id === 'exbEdBg') { $('exbEdBgBar').style.background = e.target.value; cur.bg = e.target.value; }
        if (e.target.id === 'exbEdHl') { $('exbEdHlBar').style.background = e.target.value; cur.hl = e.target.value; }
        if (e.target.id === 'exbEdZ1') applyZoom(e.target.value);
        if (e.target.id === 'exbEdFindQ' || e.target.id === 'exbEdFindCase') findCount();
      });
      $('exbEdFind').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); findNext(e.shiftKey); } if (e.key === 'Escape') { e.stopPropagation(); findClose(); } });
      d.addEventListener('selectionchange', onSelChange);
      d.addEventListener('keydown', onEsc, true);
      w.addEventListener('resize', onResize);
      normalizeRoot(); setPageFmt(x && x.fmt, x && x.ori); applyZoom('auto'); selectImg(null); sync(); $('exbEdWrap').scrollTop = 0;
      if (!ro) setTimeout(function () { try { ed.focus({ preventScroll: true }); $('exbEdWrap').scrollTop = 0; } catch (e) {} }, 50);
    }
    function onSelChange() { if (!cur || !d.body.contains(cur.ed)) { d.removeEventListener('selectionchange', onSelChange); d.removeEventListener('keydown', onEsc, true); w.removeEventListener('resize', onResize); return; } saveSel(); }
    function onEsc(e) { if (e.key === 'Escape' && cur && cur.holder.classList.contains('full') && !d.getElementById('exbEdPop') && !$('exbEdFind').contains(d.activeElement)) { cur.holder.classList.remove('full'); setOn('fscreen', false); applyZoom(cur.zoomAuto ? 'auto' : cur.zoom * 100); } }
    function onResize() { if (cur && d.body.contains(cur.ed) && cur.zoomAuto) applyZoom('auto'); }
    function onChange(e) {
      var s = e.target, c = s.getAttribute('data-c'), v = s.value;
      if (s.id === 'exbEdColor') { cur.col = v; $('exbEdColBar').style.background = v; prep(); cmd('foreColor', v); return; }
      if (s.id === 'exbEdBg') { cur.bg = v; $('exbEdBgBar').style.background = v; shade(v); return; }
      if (s.id === 'exbEdHl') { cur.hl = v; $('exbEdHlBar').style.background = v; prep(); cmd('hiliteColor', v); return; }
      if (s.id === 'exbEdFile') { var fl = s.files && s.files[0]; s.value = ''; if (fl) loadImage(fl, putImage); return; }
      if (!c || (cur.ro && !s.hasAttribute('data-view'))) return;
      if (c === 'zoom') return applyZoom(v);
      if (c === 'font' && v) { prep(); cmd('fontName', v); return; }
      if (c === 'size' && v) return applySize(+v);
      if (c === 'spacing') { if (v) setSpacing(v); return; }
      if (c === 'var' && v) { cmd('insertText', '{{' + v + '}}'); s.selectedIndex = 0; return; }
    }
    function onClick(e) {
      var tb = e.target.closest && e.target.closest('.tb'); if (tb) return showTab(tb.getAttribute('data-tab'));
      var fb = e.target.closest && e.target.closest('[data-f]');
      if (fb) { var f = fb.getAttribute('data-f'); if (f === 'close') findClose(); else if (f === 'next') findNext(false); else if (f === 'prev') findNext(true); else if (f === 'rep') findReplace(); else if (f === 'all') findAll(); return; }
      var bt = e.target.closest && e.target.closest('button[data-c]'); if (!bt || bt.disabled) return;
      var c = bt.getAttribute('data-c');
      if (cur.ro && !bt.hasAttribute('data-view')) return;
      switch (c) {
        case 'save': sync(); return act('save');
        case 'print': sync(); return act('print');
        case 'saveMod': sync(); return act('saveMod');
        case 'dup': sync(); return act('dup');
        case 'fillv': sync(); return act('fillv');
        case 'back': return act('back');
        case 'mode': sync(); setMode(false); return showText();
        case 'undo': return cmd('undo');
        case 'redo': return cmd('redo');
        case 'bold': return cmd('bold'); case 'italic': return cmd('italic'); case 'underline': return cmd('underline');
        case 'strike': return cmd('strikeThrough'); case 'sub': return cmd('subscript'); case 'sup': return cmd('superscript');
        case 'left': return cmd('justifyLeft'); case 'center': return cmd('justifyCenter'); case 'right': return cmd('justifyRight'); case 'full': return cmd('justifyFull');
        case 'ul': return cmd('insertUnorderedList'); case 'ol': return cmd('insertOrderedList');
        case 'indent': return indent(1); case 'outdent': return indent(-1);
        case 'hr': return cmd('insertHTML', '<hr><p><br></p>');
        case 'pb': return cmd('insertHTML', '<div class="pb" contenteditable="false"></div><p><br></p>');
        case 'clear': {
          /* Tx : n'efface que la sélection (avant, tous les <span> du document perdaient leur style) et garde la sélection pour la commande suivante */
          prep(); var ed2 = cur.ed, sl0 = w.getSelection(), o0 = sl0.rangeCount ? rangeOffs(ed2, sl0.getRangeAt(0)) : null;
          d.execCommand('removeFormat');
          var rr = w.getSelection().rangeCount ? w.getSelection().getRangeAt(0) : null;
          [].forEach.call(ed2.querySelectorAll('span[style]'), function (s) { if (!rr || rr.intersectsNode(s)) s.removeAttribute('style'); });
          selBlocks().forEach(function (b2) { b2.style.lineHeight = ''; });
          var rn = rangeFromOffs(ed2, o0); if (rn) { var sl1 = w.getSelection(); sl1.removeAllRanges(); sl1.addRange(rn); }
          saveSel(); sync(); return refresh();
        }
        case 'size+': return applySize(Math.min(72, currentSize() + (currentSize() >= 28 ? 4 : currentSize() >= 12 ? 2 : 1)));
        case 'size-': return applySize(Math.max(6, currentSize() - (currentSize() > 28 ? 4 : currentSize() > 12 ? 2 : 1)));
        case 'color': prep(); return cmd('foreColor', cur.col);
        case 'hilite': prep(); return cmd('hiliteColor', cur.hl);
        case 'style': { var v = bt.getAttribute('data-s'); return cmd('formatBlock', v === 'p' ? 'p' : v); }
        case 'style1': return cmd('formatBlock', 'h2'); case 'style2': return cmd('formatBlock', 'h3'); case 'style3': return cmd('formatBlock', 'h4');
        case 'table': return insertTable();
        case 'row+': case 'row-': case 'col+': case 'col-': case 'tdel': return tableOp(c);
        case 'image': saveSel(); return $('exbEdFile').click();
        case 'w25': case 'w50': case 'w75': case 'w100': return imgOp(c);
        case 'imgdel': return imgOp('del');
        case 'ial': case 'ic': case 'iar': case 'ifl': case 'ifr': case 'crop': case 'uncrop': return imgOp(c);
        case 'link': return insertLink();
        case 'unlink': return unlink();
        case 'symbol': saveSel(); return symbolsPop(bt);
        case 'date': return insertText(new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }));
        case 'toc': return insertSommaire();
        case 'paste': saveSel(); try { if (w.navigator.clipboard && w.navigator.clipboard.readText) { w.navigator.clipboard.readText().then(function (t) { if (t) insertText(t); }, function () { say('Le navigateur bloque le bouton Coller : utilisez Ctrl+V.', 'error'); }); return; } } catch (z) {} return say('Utilisez Ctrl+V pour coller.', 'error');
        case 'cut': restoreSel(); if (!d.execCommand('cut')) say('Utilisez Ctrl+X pour couper.', 'error'); saveSel(); return sync();
        case 'copy': restoreSel(); if (!d.execCommand('copy')) say('Utilisez Ctrl+C pour copier.', 'error'); return;
        case 'painter': if (cur.painter) { cur.painter = null; cur.ed.classList.remove('painter'); return setOn('painter', false); } restoreSel(); cur.painter = fmtAt(); if (cur.painter) { cur.ed.classList.add('painter'); setOn('painter', true); say('Sélectionnez maintenant le texte à mettre en forme.'); } else say('Placez d’abord le curseur dans le texte à copier.', 'error'); return;
        case 'find': return findOpen(false);
        case 'case': saveSel(); return pop(bt, [['up', 'MAJUSCULES'], ['low', 'minuscules'], ['title', 'Première Lettre En Majuscule'], ['inv', 'iNVERSER LA CASSE']].map(function (q) { return '<button type="button" data-v="' + q[0] + '" style="display:block;width:100%;text-align:left;padding:6px 10px;border:0;background:#fff;cursor:pointer;font:13px Arial">' + q[1] + '</button>'; }).join(''), changeCase);
        case 'shade': return shade(cur.bg || '#0b4aa8');
        case 'unshade': return shade(null);
        case 'styles+': saveSel(); return pop(bt, [['titre', 'Bandeau titre (centré, fond bleu)'], ['section', 'Bandeau de section (fond bleu)']].map(function (q) { return '<button type="button" data-v="' + q[0] + '" style="display:block;width:100%;text-align:left;padding:6px 10px;border:0;background:#fff;cursor:pointer;font:13px Arial">' + q[1] + '</button>'; }).join(''), bandeau);
        case 'docx': return exportDocx();
        case 'plan': return planDoc();
        case 'lect': { var on = !cur.holder.classList.contains('read'); cur.holder.classList.toggle('read', on); cur.ed.setAttribute('contenteditable', on || cur.ro ? 'false' : 'true'); return applyZoom(cur.zoomAuto ? 'auto' : cur.zoom * 100); }
        case 'replace': return findOpen(true);
        case 'spell': cur.ed.spellcheck = !cur.ed.spellcheck; setOn('spell', cur.ed.spellcheck); cur.ed.blur(); cur.ed.focus(); return say(cur.ed.spellcheck ? 'Correction orthographique activée.' : 'Correction orthographique désactivée.');
        case 'stats': { var st = stats(), pi = pagesInfo(); return info('Statistiques', '<table style="border-collapse:collapse;width:100%">' + [['Pages (estimation)', pi.pages], ['Mots', st.words], ['Caractères (espaces compris)', st.chars], ['Caractères (sans espaces)', st.nospace], ['Paragraphes', st.paras], ['Tableaux', st.tables], ['Images', st.imgs]].map(function (r) { return '<tr><td style="padding:4px 8px;border-bottom:1px solid #e2e8f0">' + r[0] + '</td><td style="padding:4px 8px;border-bottom:1px solid #e2e8f0;text-align:right"><b>' + r[1] + '</b></td></tr>'; }).join('') + '</table><p style="color:#5b6b86;font-size:12px">Le nombre de pages exact est celui du PDF officiel (en-tête et pied de page compris).</p>'); }
        case 'zoom+': return applyZoom(Math.min(200, Math.round(cur.zoom * 100 / 5) * 5 + 10));
        case 'zoom-': return applyZoom(Math.max(30, Math.round(cur.zoom * 100 / 5) * 5 - 10));
        case 'zoomfit': return applyZoom('auto');
        case 'ruler': { var rl = $('exbEdRuler'); rl.style.display = rl.style.display === 'none' ? '' : 'none'; return setOn('ruler', rl.style.display !== 'none'); }
        case 'marks': cur.ed.classList.toggle('marks'); return setOn('marks', cur.ed.classList.contains('marks'));
        case 'fscreen': cur.holder.classList.toggle('full'); setOn('fscreen', cur.holder.classList.contains('full')); return applyZoom(cur.zoomAuto ? 'auto' : cur.zoom * 100);
        case 'keys': return info('Raccourcis clavier', '<table style="width:100%;border-collapse:collapse">' + [['Ctrl + S', 'Enregistrer'], ['Ctrl + Z / Ctrl + Y', 'Annuler / rétablir'], ['Ctrl + B / I / U', 'Gras / italique / souligné'], ['Ctrl + K', 'Insérer un lien'], ['Ctrl + F', 'Rechercher'], ['Ctrl + H', 'Remplacer'], ['Tab / Maj + Tab', 'Augmenter / diminuer le retrait (liste : changer de niveau ; tableau : changer de cellule)'], ['Ctrl + clic sur un lien', 'Ouvrir le lien'], ['Échap', 'Quitter le plein écran / annuler « Reproduire la mise en forme »']].map(function (r) { return '<tr><td style="padding:4px 8px;border-bottom:1px solid #e2e8f0;white-space:nowrap"><b>' + r[0] + '</b></td><td style="padding:4px 8px;border-bottom:1px solid #e2e8f0">' + r[1] + '</td></tr>'; }).join('') + '</table>');
        case 'marks_help': return info('Repères du texte', '<p>Le texte est enregistré en clair, ce qui permet de le retrouver dans le « Mode texte » et de le mettre en forme dans les PDF :</p><p><code>**gras**</code> <code>[i]italique[/i]</code> <code>[u]souligné[/u]</code> <code>[s]barré[/s]</code> <code>[sub]indice[/sub]</code> <code>[sup]exposant[/sup]</code><br><code>[t=14]taille[/t]</code> <code>[c=#b91c1c]couleur[/c]</code> <code>[h=#ffe600]surlignage[/h]</code> <code>[f=Georgia]police[/f]</code> <code>[a=https://…]lien[/a]</code></p><p>En début de ligne : <code>&gt;&gt;</code> centré · <code>&lt;&lt;</code> droite · <code>==</code> justifié · <code>[ind=1]</code> retrait · <code>[ls=2]</code> interligne · <code># </code> / <code>## </code> / <code>### </code> titres · <code>- </code> et <code>1. </code> listes (2 espaces par niveau) · <code>[img=60]…</code> image · <code>[saut de page]</code>.</p>');
        case 'about': return info('À propos', '<p><b>Éditeur Excellencia Building</b> — feuille A4, ruban à onglets, mise en forme complète. Le texte reste compatible avec tous les modèles et avec le PDF officiel.</p><p style="color:#5b6b86;font-size:12px">Non pris en charge : cellules de tableau fusionnées, notes de bas de page, collage mis en forme depuis Word (le collage est converti en texte simple pour garder des PDF propres).</p>');
      }
    }
    function showText() {
      cur = null; holder.className = ''; holder.innerHTML = '<p style="margin:6px;"><button type="button" id="exbEdBack" style="padding:7px 12px;background:#0b3d91;color:#fff;border:0;border-radius:8px">✍️ Passer en mode Word</button></p>';
      ta.style.display = ''; if (old) old.style.display = ''; var ap = d.querySelector('#exbPie [onclick="EXBPIE.prev()"]'); if (ap) ap.style.display = '';
      $('exbEdBack').onclick = function () { setMode(true); showWord(); };
    }
    if (opts.forceWord || mode()) showWord(); else showText();
  }

  function detach() { cur = null; }
  w.EXBPIE_ED = { attach: attach, detach: detach, toMd: toMd, toHtml: toHtml, sync: sync };
})(window, document);
