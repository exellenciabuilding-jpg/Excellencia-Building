/* Excellencia Building — SOCLE COMMUN V207 · cahier des charges V1.0, exigences COM-01, COM-04, COM-08, COM-10
 * Module AJOUTÉ, sans modifier les modules existants (même principe que exb-core-adapters.js).
 *
 *  COM-04 « Version documentaire » : fiche commune de chaque document suivi → numéro, version, statut, auteur, date, discipline, projet.
 *  COM-10 « Historique des changements » : à chaque modification d'une fiche suivie, une version est conservée (qui, quand, statut,
 *          champs avant → après, copie de la fiche). Écran « 📚 Versions » : liste, consultation d'une ancienne version, comparaison.
 *          L'état de la fiche au moment où le suivi la voit pour la première fois devient la version 1 (état initial).
 *  COM-01 « Dossier projet unique » : EXBCom.dossier(idProjet) rassemble, pour un même identifiant de projet, tout ce que les autres
 *          modules y ont rattaché (client, devis, factures, études, plans, achats, chantier, documents…), filtré par les droits de lecture.
 *          Lecture seule. Écran « 📁 Dossier projet » ; lien direct : adresse#dossier=<identifiant>.
 *  COM-08 « Exports » : EXBPdf.make reçoit un pied de page normalisé « Version · Statut · Projet » (la pagination « Page i / N » et la date
 *          y figuraient déjà). Les valeurs viennent de l'appelant (version, statut, projet) ou, à défaut, du registre de versions (par n°).
 *          Rien n'est inventé : une information inconnue n'est pas affichée.
 *
 * Données : registre de versions dans localStorage (clé exb_com_versions_v1), borné : 15 versions par fiche, 400 fiches, copie ≤ 12 Ko
 * (au-delà, seuls les champs modifiés sont gardés). Ne contient ni photos, ni signatures, ni champs de type mot de passe.
 * Limites : l'historique est LOCAL à l'appareil (comme le journal d'audit) ; il commence à la mise en service du module ; la restauration
 * d'une ancienne version n'est pas proposée (consultation et comparaison seulement) ; contrôle d'accès côté écran, le serveur reste l'autorité.
 * Pour retirer : supprimer la balise <script src="exb-com-socle.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBCom) return;
  var VKEY = 'exb_com_versions_v1', MAXV = 15, MAXREC = 400, SNAPMAX = 12000, VALMAX = 300;

  /* collection → domaine, discipline, module à ouvrir (identifiants du registre EXB_MODULES) */
  var WATCH = {
    exb_quotes: { dom: 'Devis', disc: 'Commercial', sec: 'metreDevis' },
    exb_invoices: { dom: 'Facture', disc: 'Comptabilité', sec: 'facture' },
    exb_finance: { dom: 'Finances', disc: 'Comptabilité', sec: 'finances', skip: function (r) { return r && r.type === 'taux'; } },
    exb_situations: { dom: 'Situation de travaux', disc: 'Chantier', sec: 'facture' },
    exb_pieces: { dom: 'Pièce / document de chantier', disc: 'Chantier', sec: 'docs', skip: function (r) { return r && (r.modele || r.model_perso); } },
    exb_v94_drawings: { dom: 'Plan', disc: 'Architecture', sec: 'plans' },
    exb_plan_files: { dom: 'Fichier de plan', disc: 'Architecture', sec: 'plans' },
    exb_studies: { dom: 'Étude', disc: 'Ingénierie', sec: 'calcul' },
    exb_v94_studies: { dom: 'Étude', disc: 'Ingénierie', sec: 'calcul' },
    exb_calc_notes: { dom: 'Note de calcul', disc: 'Ingénierie', sec: 'calcul' },
    exb_be_missions: { dom: 'Mission du bureau d’études', disc: 'Ingénierie', sec: 'calcul' },
    exb_contracts: { dom: 'Contrat', disc: 'Juridique / contrats', sec: 'v67' },
    exb_change_orders: { dom: 'Avenant', disc: 'Juridique / contrats', sec: 'v67' },
    exb_rfis: { dom: 'RFI', disc: 'Chantier', sec: 'v67' },
    exb_submittals: { dom: 'Soumission', disc: 'Chantier', sec: 'v67' },
    exb_purchase_orders: { dom: 'Bon de commande', disc: 'Achats', sec: 'stock' },
    exb_budgets: { dom: 'Budget', disc: 'Comptabilité', sec: 'finances' },
    exb_be_dossiers: { dom: 'Dossier d’étude', disc: 'Ingénierie', sec: 'calcul' },
    exb_be_normes: { dom: 'Référentiel normatif', disc: 'Ingénierie', sec: 'calcul' }
  };
  /* domaines du dossier projet : collection, libellé, module, champs de rattachement au projet (en plus de project_id) */
  var DOSS = [
    ['exb_quotes', 'Devis', 'metreDevis'], ['exb_invoices', 'Factures', 'facture'], ['exb_finance', 'Finances (devis, situations, paiements)', 'finances'],
    ['exb_situations', 'Situations de travaux', 'facture'], ['exb_studies', 'Études', 'calcul'], ['exb_v94_studies', 'Études (architecture)', 'calcul'],
    ['exb_calc_notes', 'Notes de calcul', 'calcul'], ['exb_be_dossiers', 'Dossiers d’étude', 'calcul'], ['exb_be_missions', 'Missions du bureau d’études', 'calcul'], ['exb_v94_drawings', 'Plans', 'plans'],
    ['exb_plan_files', 'Fichiers de plans', 'plans'], ['exb_pieces', 'Documents de chantier', 'docs'], ['exb_contracts', 'Contrats', 'v67'],
    ['exb_commitments', 'Engagements', 'v67'], ['exb_change_orders', 'Avenants', 'v67'], ['exb_rfis', 'RFI', 'v67'], ['exb_submittals', 'Soumissions', 'v67'],
    ['exb_qhse', 'Qualité / sécurité', 'v67'], ['exb_risks', 'Risques', 'v67'], ['exb_meetings', 'Réunions', 'v67'], ['exb_reserves', 'Réserves', 'v67'],
    ['exb_equipment', 'Équipements', 'v67'], ['exb_purchase_orders', 'Commandes', 'stock'], ['exb_stock_moves', 'Mouvements de stock', 'stock'],
    ['exb_site_journal', 'Journal de chantier', 'projets'], ['exb_timesheets', 'Pointages', 'projets'], ['exb_v93_tasks', 'Tâches', 'projets'],
    ['exb_v93_subcontracts', 'Sous-traitants', 'projets'], ['exb_v93_payments', 'Paiements', 'finances'], ['exb_cash', 'Caisse', 'finances']
  ];
  var LINKS = ['project_id', 'projet_id', 'core_project_id', 'chantier_id', 'project', 'projet'];

  /* ------------------------------------------------------------------ outils ------------------------------------------------------------------ */
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rawGet(k) { var S = store(); try { if (S && typeof S.getItem === 'function') { var v = S.getItem(k); if (v != null) return v; } } catch (e) {} try { return w.localStorage.getItem(k); } catch (e) { return null; } }
  function list(k) { try { var a = JSON.parse(rawGet(k) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function first(o, names) { for (var i = 0; i < names.length; i++) { var v = o[names[i]]; if (v != null && v !== '' && typeof v !== 'object') return v; } return ''; }
  function ident(o) { var v = o && (o.id || o.uid || o.no || o.number || o.invoice_no || o.ref || o.code); return v ? String(v) : null; }
  function numero(o) { return String(first(o, ['no', 'number', 'invoice_no', 'ref', 'code', 'cert_no', 'id', 'uid']) || ''); }
  function libelle(o) { var n = numero(o), t = String(first(o, ['title', 'titre', 'name', 'nom', 'label', 'objet']) || ''); return (n && t && n !== t ? n + ' — ' + t : (n || t || '(sans titre)')).slice(0, 90); }
  function statutDe(o) { var s = first(o, ['status', 'statut', 'state', 'etat']); return s === '' ? '' : String(s).slice(0, 40); }
  function userNow() {
    try { if (w.EXBCore && w.EXBCore.who) { var u = w.EXBCore.who(); if (u) return String(u.nom || u.name || u.id || u).slice(0, 60); } } catch (e) {}
    try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); if (i && (i.nom || i.label || i.role)) return String(i.nom || i.label || i.role).slice(0, 60); } catch (e) {}
    try { if (w.EXB_ACCT && w.EXB_ACCT.id) return String(w.EXB_ACCT.id).slice(0, 60); } catch (e) {}
    return 'appareil';
  }
  function can(col, act) { try { return w.EXBCore && w.EXBCore.can ? !!w.EXBCore.can(col, act || 'lire') : true; } catch (e) { return true; } }
  function canAction(a) { try { return w.EXBAction && w.EXBAction.can ? !!w.EXBAction.can(a) : true; } catch (e) { return true; } }
  function fmtDate(t) { try { return new Date(t).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return String(t); } }
  function short(v) { if (v == null) return ''; var s = typeof v === 'object' ? JSON.stringify(v) : String(v); return s.length > VALMAX ? s.slice(0, VALMAX) + '…' : s; }
  var HEAVY = /^(photo|photos|signature|sign|logo|image|img|file|fichier_data|b64|base64|blob|cachet|password|pass|mdp|code_acces|token|key|cle)/i;
  function clean(o) { var c = {}; Object.keys(o).forEach(function (k) { var v = o[k]; if (HEAVY.test(k)) return; if (typeof v === 'string' && (v.length > 4000 || /^data:/.test(v))) return; c[k] = v; }); return c; }

  /* ------------------------------------------------------------------ registre ------------------------------------------------------------------ */
  var REG = null;
  function load() { if (REG) return REG; try { REG = JSON.parse(w.localStorage.getItem(VKEY) || 'null'); } catch (e) { REG = null; } if (!REG || typeof REG !== 'object' || !REG.r) REG = { r: {} }; return REG; }
  function persist() {
    var R = load(), keys = Object.keys(R.r);
    if (keys.length > MAXREC) { keys.sort(function (a, b) { return (R.r[a].t || 0) - (R.r[b].t || 0); }).slice(0, keys.length - MAXREC).forEach(function (k) { delete R.r[k]; }); }
    for (var tries = 0; tries < 6; tries++) {
      try { w.localStorage.setItem(VKEY, JSON.stringify(R)); return true; } catch (e) {
        /* espace plein : on retire d'abord les copies des plus anciennes versions, puis les plus anciennes fiches */
        var ks = Object.keys(R.r).sort(function (a, b) { return (R.r[a].t || 0) - (R.r[b].t || 0); }), n = Math.max(1, Math.ceil(ks.length / 5));
        ks.slice(0, n).forEach(function (k) { delete R.r[k]; });
      }
    }
    return false;
  }
  function changed(prev, next) {
    var ch = {}, n = 0, keys = {}; Object.keys(prev).forEach(function (k) { keys[k] = 1; }); Object.keys(next).forEach(function (k) { keys[k] = 1; });
    Object.keys(keys).forEach(function (k) { if (HEAVY.test(k)) return; var a = JSON.stringify(prev[k]), b = JSON.stringify(next[k]); if (a !== b && n < 40) { ch[k] = [short(prev[k]), short(next[k])]; n++; } });
    return ch;
  }
  function snapOf(o) { try { var s = JSON.stringify(clean(o)); return s.length <= SNAPMAX ? s : null; } catch (e) { return null; } }
  function projetDe(o) { return String(first(o, LINKS) || ''); }
  function addVersion(col, prevO, nextO) {
    var R = load(), id = ident(nextO); if (!id) return;
    var key = col + '|' + id, rec = R.r[key], meta = WATCH[col];
    if (!rec) {
      rec = R.r[key] = { c: col, id: id, vs: [] };
      if (prevO) rec.vs.push({ v: 1, t: Date.now(), u: 'état initial', s: statutDe(prevO), ch: {}, snap: snapOf(prevO), init: 1 });
    }
    var last = rec.vs[rec.vs.length - 1], before = last && last.snap ? safeParse(last.snap) : prevO;
    var ch = changed(before || {}, nextO);
    if (!Object.keys(ch).length && rec.vs.length) return;
    rec.vs.push({ v: (last ? last.v : 0) + 1, t: Date.now(), u: userNow(), s: statutDe(nextO), ch: ch, snap: snapOf(nextO) });
    while (rec.vs.length > MAXV) rec.vs.splice(1, 1); /* on garde toujours l'état initial */
    rec.l = libelle(nextO); rec.p = projetDe(nextO); rec.t = Date.now(); rec.d = meta.dom; rec.disc = meta.disc;
    persist();
    try { if (w.EXBCore && w.EXBCore.bus) w.EXBCore.bus.emit('version.creee', { col: col, id: id, v: rec.vs[rec.vs.length - 1].v }, 'com'); } catch (e) {}
  }
  function safeParse(s) { try { return JSON.parse(s); } catch (e) { return null; } }

  /* écoute du point d'écriture commun, en lecture seule (même méthode que exb-core-adapters.js) */
  var snap = {};
  function index(arr) { var m = {}; arr.forEach(function (o) { var id = o && typeof o === 'object' ? ident(o) : null; if (id) m[id] = { raw: JSON.stringify(o), o: o }; }); return m; }
  function diff(col, arr) {
    var prev = snap[col], next = index(arr), W = WATCH[col]; snap[col] = next; if (!prev) return;
    var ids = Object.keys(next), n = 0;
    ids.forEach(function (id) {
      var p = prev[id], q = next[id];
      if (W.skip && W.skip(q.o)) return;
      if (p && p.raw !== q.raw) { if (++n > 60) return; try { addVersion(col, p.o, q.o); } catch (e) {} }
    });
  }
  function install() {
    var S = store(); if (!S || S.__comVer || typeof S.setItem !== 'function' || typeof S.getItem !== 'function') return false;
    Object.keys(WATCH).forEach(function (k) { try { var a = JSON.parse(S.getItem(k) || '[]'); snap[k] = Array.isArray(a) ? index(a) : {}; } catch (e) { snap[k] = {}; } });
    var orig = S.setItem; S.__comVer = true;
    S.setItem = function (k, v) {
      var r = orig.apply(this, arguments);
      try { if (WATCH[k] && S.getItem(k) === v) { var a = JSON.parse(v); if (Array.isArray(a)) diff(k, a); } } catch (e) {}
      return r;
    };
    return true;
  }
  var tries = 0, tm = setInterval(function () { if (install() || ++tries > 80) clearInterval(tm); }, 500);

  /* ------------------------------------------------------------------ COM-04 : fiche commune ------------------------------------------------------------------ */
  function projetNom(pid) {
    if (!pid) return '';
    var all = list('exb_projects').concat(list('exb_v93_projects'));
    for (var i = 0; i < all.length; i++) if (all[i] && String(all[i].id) === String(pid)) return String(all[i].name || all[i].nom || all[i].title || all[i].titre || pid);
    return String(pid);
  }
  /* fiche commune d'un document : { numero, version, statut, auteur, date, discipline, projet, projetId, domaine, label } */
  function fiche(col, id) {
    var W = WATCH[col]; if (!W) return null;
    var o = list(col).filter(function (x) { return x && ident(x) === String(id); })[0], rec = load().r[col + '|' + id];
    if (!o && !rec) return null;
    var lv = rec && rec.vs[rec.vs.length - 1];
    var pid = o ? projetDe(o) : (rec && rec.p) || '';
    return {
      numero: o ? numero(o) : String(id), version: lv ? lv.v : 1, statut: o ? statutDe(o) : (lv ? lv.s : ''),
      auteur: lv ? lv.u : String((o && first(o, ['created_by', 'auteur', 'author', 'par'])) || '—'),
      date: lv ? lv.t : (o ? first(o, ['updated_at', 'date', 'created_at', 'created']) : ''),
      discipline: W.disc, domaine: W.dom, projetId: pid, projet: projetNom(pid), label: o ? libelle(o) : (rec && rec.l) || String(id), versions: rec ? rec.vs.length : 0
    };
  }
  function versions(col, id) { var rec = load().r[col + '|' + id]; return rec ? rec.vs.map(function (v) { return { v: v.v, t: v.t, user: v.u, statut: v.s, champs: v.ch, copie: !!v.snap, initial: !!v.init }; }) : []; }
  function version(col, id, n) { var rec = load().r[col + '|' + id], v = rec && rec.vs.filter(function (x) { return x.v === n; })[0]; return v && v.snap ? safeParse(v.snap) : null; }
  function comparer(col, id, a, b) {
    var A = version(col, id, a), B = version(col, id, b), out = [];
    if (!A || !B) return null;
    var keys = {}; Object.keys(A).forEach(function (k) { keys[k] = 1; }); Object.keys(B).forEach(function (k) { keys[k] = 1; });
    Object.keys(keys).sort().forEach(function (k) { var x = JSON.stringify(A[k]), y = JSON.stringify(B[k]); if (x !== y) out.push({ champ: k, avant: short(A[k]), apres: short(B[k]) }); });
    return out;
  }

  /* ------------------------------------------------------------------ COM-01 : dossier projet unique ------------------------------------------------------------------ */
  function projets() {
    var seen = {}, out = [];
    list('exb_projects').concat(list('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !seen[p.id]) { seen[p.id] = 1; out.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id), client: String(p.client_name || p.client || ''), statut: statutDe(p), lieu: String(p.location || p.lieu || ''), clientId: p.client_id }); } });
    return out;
  }
  function rattache(o, pid) { for (var i = 0; i < LINKS.length; i++) { var v = o[LINKS[i]]; if (v != null && v !== '' && typeof v !== 'object' && String(v) === String(pid)) return true; } return false; }
  /* tout ce qui est rattaché au projet, domaine par domaine ; un domaine dont l'utilisateur n'a pas le droit de lecture est signalé « masqué » */
  function dossier(pid) {
    var P = projets().filter(function (p) { return p.id === String(pid); })[0]; if (!P) return null;
    var cl = null; if (P.clientId != null) cl = list('exb_clients').filter(function (c) { return c && String(c.id) === String(P.clientId); })[0] || null;
    var domaines = [], total = 0, masques = 0;
    DOSS.forEach(function (D) {
      if (!can(D[0], 'lire')) { masques++; return; }
      var items = list(D[0]).filter(function (o) { return o && typeof o === 'object' && rattache(o, pid) && !(WATCH[D[0]] && WATCH[D[0]].skip && WATCH[D[0]].skip(o)); });
      if (!items.length) return;
      total += items.length;
      domaines.push({ col: D[0], titre: D[1], sec: D[2], n: items.length, items: items.slice(0, 12).map(function (o) { return { id: ident(o), label: libelle(o), statut: statutDe(o), suivi: !!(WATCH[D[0]] && load().r[D[0] + '|' + ident(o)]) }; }) });
    });
    var cdoc = (can('exb_clients', 'lire') && cl) ? { id: String(cl.id), nom: String(cl.full_name || cl.company || cl.name || cl.id), tel: String(cl.phone || ''), email: String(cl.email || '') } : null;
    return { projet: P, client: cdoc, domaines: domaines, total: total, masques: masques, date: Date.now() };
  }

  /* ------------------------------------------------------------------ COM-08 : pied de page normalisé des PDF ------------------------------------------------------------------ */
  function pied(o) {
    if (!o || typeof o !== 'object') return '';
    var ver = o.version || o.ver || '', st = o.statut || o.status || '', pr = o.projet || o.project_name || '', no = o.no || o.numero || o.refNo || '';
    if (no && (!ver || !st)) {
      var R = load().r;
      Object.keys(R).some(function (k) { var rec = R[k]; if (rec.id === String(no) || String(rec.l || '').indexOf(String(no)) === 0) { var lv = rec.vs[rec.vs.length - 1]; if (!ver) ver = lv.v; if (!st) st = lv.s; if (!pr && rec.p) pr = projetNom(rec.p); return true; } return false; });
    }
    var parts = []; if (ver) parts.push('Version ' + String(ver).replace(/^v/i, '')); if (st) parts.push('Statut : ' + String(st)); if (pr) parts.push('Projet : ' + String(pr).slice(0, 40));
    return parts.join(' · ');
  }
  function patchPdf() {
    var P = w.EXBPdf; if (!P || P.__com || typeof P.make !== 'function') return false;
    var om = P.make; P.__com = true;
    P.make = function (o) {
      try { if (o && typeof o === 'object' && !o.__comPied) { var p = pied(o); o.__comPied = 1; if (p) o.refFooter = o.refFooter ? (String(o.refFooter).indexOf(p) < 0 ? o.refFooter + ' · ' + p : o.refFooter) : p; } } catch (e) {}
      return om.apply(this, arguments);
    };
    return true;
  }
  var pt = 0, ptm = setInterval(function () { if (patchPdf() || ++pt > 80) clearInterval(ptm); }, 500);

  /* ------------------------------------------------------------------ écrans ------------------------------------------------------------------ */
  var BT = 'border:1px solid #cbd5e1;background:#fff;border-radius:8px;padding:6px 10px;cursor:pointer;font:13px Arial', IN = 'border:1px solid #cbd5e1;border-radius:8px;padding:7px 9px;font:13px Arial';
  function overlay(id) {
    var o = d.getElementById(id); if (o) o.remove();
    o = d.createElement('div'); o.id = id; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;padding:16px;max-width:940px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o); return c;
  }
  function head(t, closeId) { return '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h3 style="margin:0">' + t + '</h3><button style="' + BT + '" onclick="document.getElementById(\'' + closeId + '\').remove()">✕ Fermer</button></div>'; }
  function open(sec) { try { w.show(sec); } catch (e) { try { w.alert('Module indisponible : ' + sec); } catch (x) {} } var a = d.getElementById('exbComV'); if (a) a.remove(); var b = d.getElementById('exbComD'); if (b) b.remove(); }

  /* --- Versions --- */
  var VS = { q: '', col: '', sel: null, a: null, b: null };
  function allFiches() {
    var R = load().r, out = [];
    Object.keys(R).forEach(function (k) { var rec = R[k]; if (!WATCH[rec.c] || !can(rec.c, 'lire')) return; var lv = rec.vs[rec.vs.length - 1]; out.push({ col: rec.c, id: rec.id, label: rec.l || rec.id, dom: rec.d, disc: rec.disc, p: rec.p, v: lv.v, u: lv.u, t: lv.t, s: lv.s, n: rec.vs.length }); });
    return out.sort(function (a, b) { return b.t - a.t; });
  }
  function paintV() {
    var c = d.querySelector('#exbComV > div'); if (!c) return;
    var all = allFiches(), q = VS.q.toLowerCase();
    var rows = all.filter(function (f) { return (!VS.col || f.col === VS.col) && (!q || (f.label + ' ' + f.id + ' ' + f.dom + ' ' + f.disc + ' ' + projetNom(f.p)).toLowerCase().indexOf(q) >= 0); }).slice(0, 120);
    var opts = '<option value="">Tous les types</option>' + Object.keys(WATCH).map(function (k) { return '<option value="' + k + '"' + (VS.col === k ? ' selected' : '') + '>' + esc(WATCH[k].dom + ' (' + k.replace('exb_', '') + ')') + '</option>'; }).join('');
    var h = head('📚 Versions & historique des documents', 'exbComV')
      + '<p style="font-size:12px;color:#64748b;margin:6px 0">Une version est conservée à chaque modification d’une fiche suivie (sur cet appareil, à partir de la mise en service du module). Consultation et comparaison seulement.</p>'
      + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><input id="exbComVq" placeholder="Rechercher (n°, titre, projet, discipline…)" value="' + esc(VS.q) + '" style="' + IN + ';flex:1 1 220px" oninput="EXBCom._q(this.value)"><select style="' + IN + '" onchange="EXBCom._c(this.value)">' + opts + '</select></div>';
    if (VS.sel) { h += detailV(); }
    else {
      h += '<div style="overflow:auto;max-height:60vh"><table style="border-collapse:collapse;font-size:12px;width:100%"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:5px">N° / titre</th><th style="padding:5px">Type</th><th style="padding:5px">Discipline</th><th style="padding:5px">Projet</th><th style="padding:5px">Vers.</th><th style="padding:5px">Statut</th><th style="padding:5px">Auteur</th><th style="padding:5px">Date</th></tr></thead><tbody>'
        + (rows.map(function (f) { return '<tr style="border-top:1px solid #e5e7eb;cursor:pointer" onclick="EXBCom._s(\'' + esc(f.col) + '\',\'' + esc(String(f.id).replace(/\\/g, '\\\\').replace(/'/g, "\\'")) + '\')"><td style="padding:5px">' + esc(f.label) + '</td><td style="padding:5px">' + esc(f.dom) + '</td><td style="padding:5px">' + esc(f.disc) + '</td><td style="padding:5px">' + esc(projetNom(f.p) || '—') + '</td><td style="padding:5px">v' + f.v + ' <span style="color:#64748b">(' + f.n + ')</span></td><td style="padding:5px">' + esc(f.s || '—') + '</td><td style="padding:5px">' + esc(f.u) + '</td><td style="padding:5px">' + esc(fmtDate(f.t)) + '</td></tr>'; }).join('') || '<tr><td colspan="8" style="padding:14px;color:#64748b">Aucune modification suivie pour l’instant. Les versions apparaissent dès qu’un devis, une facture, une étude, un plan, un contrat… est modifié.</td></tr>')
        + '</tbody></table></div>';
    }
    c.innerHTML = h;
    var qi = d.getElementById('exbComVq'); if (qi && VS.q) { try { qi.focus(); qi.setSelectionRange(VS.q.length, VS.q.length); } catch (e) {} }
  }
  function detailV() {
    var col = VS.sel[0], id = VS.sel[1], f = fiche(col, id), vs = versions(col, id); if (!f) return '<p>Fiche introuvable.</p>';
    if (VS.b == null && vs.length) VS.b = vs[vs.length - 1].v; if (VS.a == null && vs.length > 1) VS.a = vs[vs.length - 2].v;
    var h = '<button style="' + BT + ';margin:6px 0" onclick="EXBCom._s(null)">← Retour à la liste</button>'
      + '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;margin:6px 0;font-size:13px"><b>' + esc(f.label) + '</b><br>'
      + 'N° : ' + esc(f.numero) + ' · Version : v' + f.version + ' · Statut : ' + esc(f.statut || '—') + '<br>Auteur : ' + esc(f.auteur) + ' · Date : ' + esc(f.date ? fmtDate(f.date) : '—') + '<br>Discipline : ' + esc(f.discipline) + ' · Projet : ' + esc(f.projet || '—') + '</div>';
    h += '<table style="border-collapse:collapse;font-size:12px;width:100%"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:5px">Version</th><th style="padding:5px">Date</th><th style="padding:5px">Auteur</th><th style="padding:5px">Statut</th><th style="padding:5px">Champs modifiés</th></tr></thead><tbody>'
      + vs.slice().reverse().map(function (v) { return '<tr style="border-top:1px solid #e5e7eb"><td style="padding:5px">v' + v.v + (v.initial ? ' <i>(état initial)</i>' : '') + '</td><td style="padding:5px">' + esc(fmtDate(v.t)) + '</td><td style="padding:5px">' + esc(v.user) + '</td><td style="padding:5px">' + esc(v.statut || '—') + '</td><td style="padding:5px">' + esc(Object.keys(v.champs).join(', ') || (v.initial ? '—' : '—')) + (v.copie ? '' : ' <span style="color:#b45309">(copie trop volumineuse : champs seuls)</span>') + '</td></tr>'; }).join('') + '</tbody></table>';
    if (vs.length > 1) {
      var sel = function (id2, cur) { return '<select style="' + IN + '" onchange="EXBCom._v(\'' + id2 + '\',this.value)">' + vs.map(function (v) { return '<option value="' + v.v + '"' + (cur === v.v ? ' selected' : '') + '>v' + v.v + ' — ' + esc(fmtDate(v.t)) + '</option>'; }).join('') + '</select>'; };
      var cmp = comparer(col, id, VS.a, VS.b);
      h += '<h4 style="margin:12px 0 6px">Comparer avant / après</h4><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">Avant ' + sel('a', VS.a) + ' Après ' + sel('b', VS.b) + '</div>';
      h += cmp === null ? '<p style="color:#b45309;font-size:12px">Une des deux versions n’a pas de copie complète : consultez la colonne « Champs modifiés » ci-dessus.</p>'
        : '<div style="overflow:auto;max-height:40vh;margin-top:6px"><table style="border-collapse:collapse;font-size:12px;width:100%"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:5px">Champ</th><th style="padding:5px">Avant</th><th style="padding:5px">Après</th></tr></thead><tbody>'
        + (cmp.map(function (r) { return '<tr style="border-top:1px solid #e5e7eb"><td style="padding:5px"><b>' + esc(r.champ) + '</b></td><td style="padding:5px;background:#fef2f2">' + esc(r.avant || '—') + '</td><td style="padding:5px;background:#f0fdf4">' + esc(r.apres || '—') + '</td></tr>'; }).join('') || '<tr><td colspan="3" style="padding:10px;color:#64748b">Aucune différence entre ces deux versions.</td></tr>') + '</tbody></table></div>';
    }
    if (canAction('exporter')) h += '<p style="margin-top:10px"><button style="' + BT + '" onclick="EXBCom._csv()">⬇ Exporter l’historique (CSV)</button></p>';
    return h;
  }
  function csvHist() {
    if (!VS.sel) return; var col = VS.sel[0], id = VS.sel[1], f = fiche(col, id), vs = versions(col, id);
    var cell = function (v) { v = String(v == null ? '' : v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
    var lines = [['document', 'numero', 'version', 'date_heure', 'auteur', 'statut', 'champ', 'avant', 'apres', 'projet', 'discipline'].join(';')];
    vs.forEach(function (v) { var ks = Object.keys(v.champs); if (!ks.length) lines.push([f.label, f.numero, 'v' + v.v, new Date(v.t).toISOString(), v.user, v.statut, '', '', '', f.projet, f.discipline].map(cell).join(';')); ks.forEach(function (k) { lines.push([f.label, f.numero, 'v' + v.v, new Date(v.t).toISOString(), v.user, v.statut, k, v.champs[k][0], v.champs[k][1], f.projet, f.discipline].map(cell).join(';')); }); });
    var blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 'HISTORIQUE-' + String(f.numero).replace(/[^\w-]+/g, '_') + '-' + new Date().toISOString().slice(0, 10) + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  }
  function ouvrirVersions(col, id) { VS = { q: '', col: '', sel: col && id ? [col, String(id)] : null, a: null, b: null }; overlay('exbComV'); paintV(); }

  /* --- Dossier projet --- */
  var DS = { q: '', pid: null };
  function paintD() {
    var c = d.querySelector('#exbComD > div'); if (!c) return;
    var h = head('📁 Dossier projet unique', 'exbComD');
    if (!DS.pid) {
      var q = DS.q.toLowerCase(), P = projets().filter(function (p) { return !q || (p.nom + ' ' + p.id + ' ' + p.client + ' ' + p.lieu).toLowerCase().indexOf(q) >= 0; }).slice(0, 80);
      h += '<p style="font-size:12px;color:#64748b;margin:6px 0">Choisissez un projet : tous les modules l’ouvrent par le même identifiant et n’affichent que ce que vos droits permettent.</p>'
        + '<input id="exbComDq" placeholder="Rechercher un projet (nom, code, client)…" value="' + esc(DS.q) + '" style="' + IN + ';width:100%;box-sizing:border-box" oninput="EXBCom._dq(this.value)">'
        + '<div style="margin-top:8px;max-height:60vh;overflow:auto">' + (P.map(function (p) { return '<div style="border:1px solid #e5e7eb;border-radius:10px;padding:8px 10px;margin:5px 0;cursor:pointer" onclick="EXBCom._dp(\'' + esc(p.id.replace(/\\/g, '\\\\').replace(/'/g, "\\'")) + '\')"><b>' + esc(p.nom) + '</b> <span style="color:#64748b;font-size:12px">' + esc(p.id) + '</span><br><span style="font-size:12px;color:#475569">' + esc([p.client, p.lieu, p.statut].filter(Boolean).join(' · ') || '—') + '</span></div>'; }).join('') || '<p style="color:#64748b">Aucun projet enregistré.</p>') + '</div>';
    } else {
      var D = dossier(DS.pid);
      if (!D) h += '<p>Projet introuvable.</p>';
      else {
        h += '<button style="' + BT + ';margin:6px 0" onclick="EXBCom._dp(null)">← Autres projets</button>'
          + '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;margin:6px 0;font-size:13px"><b style="font-size:15px">' + esc(D.projet.nom) + '</b><br>Identifiant : ' + esc(D.projet.id) + ' · Statut : ' + esc(D.projet.statut || '—') + (D.projet.lieu ? ' · Lieu : ' + esc(D.projet.lieu) : '')
          + '<br>Client : ' + (D.client ? esc(D.client.nom) + (D.client.tel ? ' · ' + esc(D.client.tel) : '') + (D.client.email ? ' · ' + esc(D.client.email) : '') : '<i>' + (D.projet.clientId != null ? 'non visible avec vos droits ou fiche absente' : 'aucun client relié') + '</i>')
          + '<br>' + D.total + ' élément(s) rattaché(s) dans ' + D.domaines.length + ' domaine(s)' + (D.masques ? ' · <span style="color:#b45309">' + D.masques + ' domaine(s) masqué(s) par vos droits</span>' : '') + '</div>';
        h += D.domaines.map(function (g) {
          return '<div style="border:1px solid #e5e7eb;border-radius:10px;margin:8px 0;overflow:hidden"><div style="background:#f1f5f9;padding:7px 10px;display:flex;justify-content:space-between;align-items:center;gap:6px"><b>' + esc(g.titre) + ' <span style="color:#64748b">(' + g.n + ')</span></b><button style="' + BT + '" onclick="EXBCom._open(\'' + esc(g.sec) + '\')">Ouvrir le module</button></div><div style="padding:4px 10px;font-size:12px">'
            + g.items.map(function (it) { return '<div style="padding:3px 0;border-top:1px solid #f1f5f9;display:flex;justify-content:space-between;gap:6px"><span>' + esc(it.label) + (it.statut ? ' <span style="color:#64748b">· ' + esc(it.statut) + '</span>' : '') + '</span>' + (it.suivi ? '<a href="#" style="color:#1d4ed8" onclick="EXBCom.versions(\'' + esc(g.col) + '\',\'' + esc(String(it.id).replace(/\\/g, '\\\\').replace(/'/g, "\\'")) + '\');return false">📚 versions</a>' : '') + '</div>'; }).join('')
            + (g.n > g.items.length ? '<div style="padding:4px 0;color:#64748b">… et ' + (g.n - g.items.length) + ' autre(s) dans le module.</div>' : '') + '</div></div>';
        }).join('') || '<p style="color:#64748b">Rien n’est encore rattaché à ce projet (champ « project_id »).</p>';
        h += '<p style="font-size:11px;color:#64748b;margin-top:10px">Lecture seule · photographie du ' + esc(fmtDate(D.date)) + ' · lien direct : <code>#dossier=' + esc(D.projet.id) + '</code></p>';
      }
    }
    c.innerHTML = h;
    var qi = d.getElementById('exbComDq'); if (qi && DS.q) { try { qi.focus(); qi.setSelectionRange(DS.q.length, DS.q.length); } catch (e) {} }
  }
  function ouvrirDossier(pid) { DS = { q: '', pid: pid != null ? String(pid) : null }; overlay('exbComD'); paintD(); }

  /* boutons à côté de « 📜 Journal d'audit » (même méthode que exb-core-audit-ui.js) et lien direct #dossier=<id> */
  function ui() {
    var b = d.getElementById('exbAuBtn') || d.getElementById('exbSecBtn'); if (!b || d.getElementById('exbComBtnV')) return;
    var k = d.createElement('button'); k.id = 'exbComBtnV'; k.setAttribute('data-exb-cat', 'rap'); k.setAttribute('data-exb-desc', 'Historique et comparaison des versions de documents'); k.className = b.className; k.textContent = '📚 Versions'; k.onclick = function () { ouvrirVersions(); };
    var k2 = d.createElement('button'); k2.id = 'exbComBtnD'; k2.setAttribute('data-exb-cat', 'prj'); k2.setAttribute('data-exb-desc', 'Tout ce qui est rattaché à un projet, selon vos droits'); k2.className = b.className; k2.textContent = '📁 Dossier projet'; k2.onclick = function () { ouvrirDossier(); };
    b.parentNode.insertBefore(k, b.nextSibling); b.parentNode.insertBefore(k2, k.nextSibling);
  }
  function lien() { var m = /[#&?]dossier=([^&]+)/.exec(w.location && w.location.hash || ''); if (m) { try { ouvrirDossier(decodeURIComponent(m[1])); } catch (e) {} } }
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', function () { ui(); setTimeout(lien, 1500); });
  try { w.addEventListener('hashchange', lien); } catch (e) {}

  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'comSocle', name: 'Socle commun COM-01/04/08/10', version: '1.0.0', area: 'Transverse', provides: ['versions', 'dossier-projet', 'pied-exports'] }); } catch (e) {}

  w.EXBCom = {
    version: 'V207-COM-1.0', watch: function () { return Object.keys(WATCH); },
    fiche: fiche, versions: ouvrirVersions, listeVersions: versions, version: version, comparer: comparer,
    projets: projets, dossier: dossier, ouvrirDossier: ouvrirDossier, ouvrirVersions: ouvrirVersions, pied: pied, registre: function () { return load(); }, _reset: function () { REG = { r: {} }; persist(); },
    _q: function (v) { VS.q = v; paintV(); }, _c: function (v) { VS.col = v; paintV(); }, _s: function (c, i) { VS.sel = c ? [c, i] : null; VS.a = VS.b = null; paintV(); },
    _v: function (w2, v) { VS[w2] = parseInt(v, 10); paintV(); }, _csv: csvHist, _dq: function (v) { DS.q = v; paintD(); }, _dp: function (p) { DS.pid = p; paintD(); }, _open: open
  };
})(window, document);
