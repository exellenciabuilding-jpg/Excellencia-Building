/* Excellencia Building V221l — PAGE DE GARDE AU CHOIX + MISE EN PAGE UNIQUE DES PDF.
 * Avant : les PDF du Centre documentaire (factures, reçus, décomptes, PV, rapports, notes d'études…) sortaient toujours en « couverture + contenu »,
 * avec une mise en page différente des pièces d'ingénierie.
 * Maintenant : au moment de produire le PDF, une petite fenêtre demande « Avec page de garde » ou « Sans page de garde (contenu seul) ».
 *  - contenu = mise en page « pièce » commune (en-tête, Réf./Projet/Date, titre, tableau, visa et signature, QR et pied de page en bas) ;
 *  - avec page de garde = page de garde officielle (logo, titre, QR) placée devant le contenu.
 * Le dernier choix est présélectionné (Entrée valide). Réglage fixe possible : EXBGARDE.set('avec'|'sans'|'ask').
 * Pièces qui gardent leur propre forme (reçus, plans, journaux) : options garde:false → jamais de demande. */
(function (w) {
  'use strict';
  if (w.EXBGARDE || !w.EXBPdf || !w.EXBPdf.make) return;
  var P = w.EXBPdf, orig = P.make, d = w.document, KEY = 'EXB_PDF_GARDE', LAST = 'EXB_PDF_GARDE_LAST';
  function ls(k, v) { try { if (v === undefined) return w.localStorage.getItem(k); w.localStorage.setItem(k, v); } catch (e) { } return null; }
  function ask(titre) {
    var mode = ls(KEY); if (mode === 'avec' || mode === 'sans') return Promise.resolve(mode);
    return new Promise(function (ok) {
      var last = ls(LAST) === 'avec' ? 'avec' : 'sans', o = d.createElement('div');
      o.setAttribute('role', 'dialog'); o.setAttribute('aria-modal', 'true');
      o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px';
      o.innerHTML = '<div style="background:#fff;border-radius:14px;padding:20px;max-width:420px;width:100%;font:14px Arial;color:#172033;box-shadow:0 10px 40px rgba(0,0,0,.3)">'
        + '<div style="font-weight:800;font-size:17px;color:#173565;margin-bottom:6px">Page de garde</div>'
        + '<div style="color:#475569;margin-bottom:14px">' + String(titre || 'Ce document').replace(/[<>&]/g, '') + ' : imprimer avec la page de garde, ou le contenu seul ?</div>'
        + '<div style="display:flex;gap:8px;flex-wrap:wrap"><button data-g="avec" style="flex:1;min-width:150px;padding:11px;border:2px solid #c49a38;border-radius:10px;background:#fff;color:#173565;font-weight:700;cursor:pointer">📕 Avec page de garde</button>'
        + '<button data-g="sans" style="flex:1;min-width:150px;padding:11px;border:2px solid #173565;border-radius:10px;background:#173565;color:#fff;font-weight:700;cursor:pointer">📄 Sans (contenu seul)</button></div>'
        + '<label style="display:flex;gap:8px;align-items:center;margin-top:12px;font-size:12.5px;color:#475569"><input type="checkbox" data-mem> Ne plus demander (garder ce choix)</label></div>';
      d.body.appendChild(o);
      var btn = o.querySelector('[data-g=' + last + ']'); try { btn.focus(); } catch (e) { }
      function done(v) { var mem = o.querySelector('[data-mem]').checked; d.removeEventListener('keydown', kd, true); o.remove(); ls(LAST, v); if (mem) ls(KEY, v); ok(v); }
      function kd(e) { if (e.key === 'Escape') { e.preventDefault(); done('sans'); } }
      o.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('button[data-g]'); if (b) done(b.getAttribute('data-g')); });
      d.addEventListener('keydown', kd, true);
    });
  }
  /* PDF « page de garde » seule : 1re page du rendu du Centre documentaire (couverture) */
  function gardeOnly(o) {
    var c = Object.assign({}, o, { cover: true, style: undefined, engine: undefined, noSignBlock: undefined, __rb: undefined });
    return Promise.resolve(orig.call(P, c)).then(function (b) { return b && b.size ? b : null; }, function () { return null; });
  }
  function lib() {
    if (w.PDFLib) return Promise.resolve(w.PDFLib);
    return new Promise(function (ok, ko) { var s = d.createElement('script'); s.src = 'pdflib/pdf-lib.min.js'; s.onload = function () { w.PDFLib ? ok(w.PDFLib) : ko(new Error('pdf-lib')); }; s.onerror = ko; d.head.appendChild(s); });
  }
  function merge(cover, body) {
    return lib().then(function (L) {
      return Promise.all([cover.arrayBuffer(), body.arrayBuffer()]).then(function (ab) {
        return Promise.all([L.PDFDocument.load(ab[0]), L.PDFDocument.load(ab[1]), L.PDFDocument.create()]).then(function (docs) {
          var out = docs[2];
          return out.copyPages(docs[0], [0]).then(function (cp) { out.addPage(cp[0]); return out.copyPages(docs[1], docs[1].getPageIndices()); })
            .then(function (pp) { pp.forEach(function (p) { out.addPage(p); }); return out.save(); })
            .then(function (u8) { return new Blob([u8], { type: 'application/pdf' }); });
        });
      });
    });
  }
  function make(o) {
    if (!o || o.garde === false || o.cover === false && o.garde === undefined && o.verify === false || o.__garde) return orig.call(P, o);
    var forced = o.garde === true ? 'avec' : null;
    return (forced ? Promise.resolve(forced) : ask(o.titre)).then(function (choice) {
      var base = Object.assign({}, o, { __garde: 1 });
      var content = w.EXBENT && w.EXBENT.piece && !base.style ? w.EXBENT.piece(Object.assign({}, base)) : base;
      if (!content.style) content = Object.assign({}, content, { cover: false });
      var pBody = Promise.resolve(orig.call(P, content));
      if (choice !== 'avec') return pBody;
      return Promise.all([pBody, gardeOnly(base)]).then(function (r) {
        if (!r[1] || !r[0]) return r[0];
        return merge(r[1], r[0]).catch(function () { return r[0]; });
      });
    });
  }
  P.make = make;
  w.EXBGARDE = { ask: ask, set: function (v) { ls(KEY, v); }, get: function () { return ls(KEY) || 'ask'; }, version: 'V221l' };
})(typeof window !== 'undefined' ? window : globalThis);
