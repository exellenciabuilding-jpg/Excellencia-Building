/* Excellencia Building — Continuité & intégrité (V166c) · cahier des charges unifié §6 (RPO/RTO, restauration, intégrité)
 *  1. Objectifs RPO / RTO par niveau de criticité (critique, important, standard), modifiables, comparés à l'état RÉEL des sauvegardes
 *     (dernière copie téléchargée, copie automatique, copies internes) : ✅ conforme / ⛔ dépassé, avec alerte.
 *  2. Test de restauration de la dernière copie interne, SANS rien écrire : vérification de la somme de contrôle, lecture des données,
 *     temps mesuré ; la date du dernier test (copie interne OU fichier testé dans « Sécurité & sauvegardes ») est conservée.
 *  3. Contrôle d'intégrité : lecture de toutes les données, doublons d'identifiants, chaîne du journal d'audit.
 *  4. État de référence AVANT une migration / restauration, puis comparaison APRÈS : jeux de données ajoutés, retirés ou dont le nombre de fiches a changé.
 * Aucune donnée métier n'est modifiée. Réservé à l'administrateur. Réutilise EXBSEC (exb-v81-securite.js) et EXB_ABK (copies automatiques).
 * Limite : le temps de reprise réel (RTO) dépend aussi des personnes ; l'écran mesure la partie technique. Retirer : supprimer la balise du script. */
(function (w, d) {
  'use strict';
  if (w.EXBContinuite) return;
  var K = 'exb_continuite', KT = 'exb_last_restore_test', KR = 'exb_integrity_ref';
  var TIERS = [
    { id: 'critique', label: 'Critique', ex: 'Finances, factures, paiements, caisse, paie, licences', rpo: 24, rto: 4 },
    { id: 'important', label: 'Important', ex: 'Projets, chantiers, CRM, stock, workflow, documents de chantier', rpo: 72, rto: 24 },
    { id: 'standard', label: 'Standard', ex: 'Formation, archives courantes, affiches, réglages d’affichage', rpo: 168, rto: 72 }
  ];
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k) { try { return JSON.parse(w.localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function lsRaw(k) { try { return w.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function audit(a, o, det) { try { if (w.EXBCore) return w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function store() { try { return w.exbStorage || (typeof exbStorage !== 'undefined' ? exbStorage : null); } catch (e) { return null; } }
  function admin() { try { return w.EXBAction ? w.EXBAction.profile() === 'admin' : true; } catch (e) { return true; } }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 7000); } catch (e) {} }
  function fmt(iso) { var t = new Date(iso); return isNaN(t) ? '—' : t.toLocaleDateString('fr-FR') + ' ' + t.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }); }
  function hours(ms) { return ms / 3600000; }
  function dur(h) { return h < 1 ? Math.round(h * 60) + ' min' : h < 48 ? (Math.round(h * 10) / 10) + ' h' : Math.round(h / 24) + ' j'; }

  function targets() {
    var o = lsGet(K) || {}, t = {};
    TIERS.forEach(function (x) { var s = (o.tiers || {})[x.id] || {}; t[x.id] = { rpo: num(s.rpo, x.rpo), rto: num(s.rto, x.rto) }; });
    return t;
  }
  function num(v, f) { v = Number(v); return isFinite(v) && v > 0 && v < 100000 ? v : f; }

  /* état réel des sauvegardes */
  function lastBackups() {
    var c = [['Fichier téléchargé', lsRaw('exb_last_backup')], ['Copie automatique', lsRaw('exb_autobk_last')]], out = [];
    c.forEach(function (x) { var t = Date.parse(x[1] || ''); if (!isNaN(t)) out.push({ src: x[0], t: t }); });
    return Promise.resolve(w.EXB_ABK && w.EXB_ABK.snapshots ? w.EXB_ABK.snapshots() : []).then(function (s) {
      (s || []).forEach(function (x) { if (x.id !== 'avant-restauration') { var t = Date.parse(x.at || ''); if (!isNaN(t)) out.push({ src: 'Copie interne ' + String(x.id).slice(0, 10), t: t }); } });
      out.sort(function (a, b) { return b.t - a.t; }); return { list: out, snaps: s || [] };
    }).catch(function () { out.sort(function (a, b) { return b.t - a.t; }); return { list: out, snaps: [] }; });
  }
  function status() {
    return lastBackups().then(function (b) {
      var now = Date.now(), last = b.list[0] || null, age = last ? hours(now - last.t) : null, tg = targets(), rows = TIERS.map(function (x) {
        return { id: x.id, label: x.label, ex: x.ex, rpo: tg[x.id].rpo, rto: tg[x.id].rto, ok: age != null && age <= tg[x.id].rpo };
      });
      return { last: last, ageH: age, rows: rows, ok: rows.every(function (r) { return r.ok; }), snaps: b.snaps, test: lsGet(KT) };
    });
  }

  /* test de restauration (lecture seule) */
  function testSnapshot() {
    var S = w.EXBSEC, A = w.EXB_ABK; if (!S || !S._verify || !A || !A.snapshots) return Promise.resolve({ ok: false, error: 'Modules de sauvegarde absents.' });
    return A.snapshots().then(function (list) {
      var s = (list || []).filter(function (x) { return x.id !== 'avant-restauration' && x.text; })[0];
      if (!s) return { ok: false, error: 'Aucune copie interne disponible : lancez d’abord une sauvegarde.' };
      var t0 = Date.now();
      return S._verify(s.text, null, null).then(function (r) {
        var res = { at: new Date().toISOString(), ok: !!r.ok, src: 'copie interne ' + String(s.id).slice(0, 10), ms: Date.now() - t0, jeux: r.rows ? r.rows.length : 0, errors: r.errors || [] };
        lsSet(KT, res); audit('continuite.test', res.src, { ref: res.src, statut: res.ok ? 'valide' : 'invalide' }); return res;
      });
    }).catch(function (e) { return { ok: false, error: e && e.message || String(e) }; });
  }

  /* intégrité */
  function readAll() {
    var s = store(), out = { keys: 0, counts: {}, unreadable: [], dups: [] }; if (!s || s.length == null) return out;
    for (var i = 0; i < s.length; i++) {
      var k = s.key(i); if (!k || !/^exb/i.test(k) || /^exb_(core_|autobk|integrity|continuite|last_restore)/.test(k)) continue;
      var v = s.getItem(k); if (v == null) continue; out.keys++;
      var c = v.charAt(0); if (c !== '[' && c !== '{') continue;
      try {
        var x = JSON.parse(v);
        if (Array.isArray(x)) {
          out.counts[k] = x.length; var seen = {}, dd = 0;
          x.forEach(function (o) { var id = o && typeof o === 'object' ? (o.id || o.uid) : null; if (id != null) { if (seen[id]) dd++; seen[id] = 1; } });
          if (dd) out.dups.push({ key: k, n: dd });
        } else out.counts[k] = Object.keys(x).length;
      } catch (e) { out.unreadable.push(k); }
    }
    return out;
  }
  function integrity() {
    var r = readAll();
    return (w.EXBCore ? w.EXBCore.audit.verify() : Promise.resolve(null)).then(function (ch) {
      var res = { at: new Date().toISOString(), keys: r.keys, jeux: Object.keys(r.counts).length, unreadable: r.unreadable, dups: r.dups, chain: ch, ok: !r.unreadable.length && !r.dups.length && (!ch || ch.ok) };
      audit('continuite.controle', 'integrite', { statut: res.ok ? 'conforme' : 'anomalies', ref: res.keys + ' jeux lus' }); return res;
    });
  }
  function setRef() { var r = readAll(), o = { at: new Date().toISOString(), counts: r.counts }; lsSet(KR, o); audit('continuite.reference', 'etat', { ref: Object.keys(r.counts).length + ' jeux' }); return o; }
  function compare() {
    var ref = lsGet(KR); if (!ref) return null; var cur = readAll().counts, ch = [];
    Object.keys(ref.counts).forEach(function (k) { if (!(k in cur)) ch.push({ k: k, t: 'retiré', a: ref.counts[k], b: null }); else if (cur[k] !== ref.counts[k]) ch.push({ k: k, t: 'modifié', a: ref.counts[k], b: cur[k] }); });
    Object.keys(cur).forEach(function (k) { if (!(k in ref.counts)) ch.push({ k: k, t: 'ajouté', a: null, b: cur[k] }); });
    return { at: ref.at, changes: ch, total: Object.keys(ref.counts).length };
  }

  /* écran */
  var bt = 'padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;cursor:pointer', inp = 'padding:6px;border:1px solid #cbd5e1;border-radius:6px;width:80px;box-sizing:border-box';
  var view = { integ: null, cmp: null, test: null };
  function paint() {
    var o = d.getElementById('exbCont'); if (!o) return;
    status().then(function (st) {
      var tb = st.rows.map(function (r) {
        return '<tr><td style="padding:5px"><b>' + esc(r.label) + '</b><br><small style="color:#64748b">' + esc(r.ex) + '</small></td>'
          + '<td><input type="number" min="1" id="ct_rpo_' + r.id + '" value="' + r.rpo + '" style="' + inp + '"> h</td><td><input type="number" min="1" id="ct_rto_' + r.id + '" value="' + r.rto + '" style="' + inp + '"> h</td>'
          + '<td>' + (r.ok ? '<b style="color:#15803d">✅ respecté</b>' : '<b style="color:#b91c1c">⛔ dépassé</b>') + '</td></tr>';
      }).join('');
      var lastTxt = st.last ? esc(fmt(st.last.t)) + ' — ' + esc(st.last.src) + ' (il y a ' + dur(st.ageH) + ')' : '<b style="color:#b91c1c">aucune sauvegarde trouvée</b>';
      var t = view.test || st.test;
      var testTxt = t ? (t.ok ? '<b style="color:#15803d">✅ Valide</b>' : '<b style="color:#b91c1c">⛔ Invalide</b>') + ' le ' + esc(fmt(t.at)) + (t.src ? ' — ' + esc(t.src) : '') + (t.ms != null ? ' — lecture technique en ' + t.ms + ' ms' : '') + (t.error ? '<br>' + esc(t.error) : '') + ((t.errors || []).length ? '<br>' + t.errors.map(esc).join('<br>') : '') : '<span style="color:#b91c1c">Jamais testé sur cet appareil.</span>';
      var ig = view.integ, igTxt = !ig ? '<span style="color:#64748b">Non lancé.</span>' : (ig.ok ? '<b style="color:#15803d">✅ Conforme</b>' : '<b style="color:#b91c1c">⛔ Anomalies</b>') + ' — ' + ig.jeux + ' jeux de données lus'
        + (ig.unreadable.length ? '<br>Illisibles : ' + ig.unreadable.map(esc).join(', ') : '') + (ig.dups.length ? '<br>Identifiants en double : ' + ig.dups.map(function (x) { return esc(x.key) + ' (' + x.n + ')'; }).join(', ') : '')
        + (ig.chain ? '<br>Journal d’audit : ' + (ig.chain.ok ? 'chaîne intacte (' + ig.chain.entries + ' lignes)' : 'chaîne rompue à partir du n° ' + esc(ig.chain.firstBroken)) : '');
      var ref = lsGet(KR), cm = view.cmp, cmTxt = !ref ? '<span style="color:#64748b">Aucun état de référence enregistré.</span>' : 'Référence du ' + esc(fmt(ref.at)) + ' (' + Object.keys(ref.counts).length + ' jeux).'
        + (cm ? (cm.changes.length ? '<table style="font-size:12px;border-collapse:collapse;margin-top:6px"><tr style="background:#f1f5f9"><th style="padding:3px 8px;text-align:left">Données</th><th>Changement</th><th>Avant</th><th>Après</th></tr>' + cm.changes.map(function (c) { return '<tr><td style="padding:3px 8px">' + esc(c.k) + '</td><td>' + c.t + '</td><td style="text-align:center">' + (c.a == null ? '—' : c.a) + '</td><td style="text-align:center">' + (c.b == null ? '—' : c.b) + '</td></tr>'; }).join('') + '</table>' : '<br><b style="color:#15803d">✅ Identique à la référence</b> : aucune donnée ajoutée, retirée ou modifiée en nombre.') : '');
      o.firstChild.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">🛟 Continuité & intégrité</b><button onclick="document.getElementById(\'exbCont\').remove()" style="' + bt + '">✕</button></div>'
        + '<div style="margin:10px 0;padding:10px;border-radius:8px;background:' + (st.ok ? '#f0fdf4' : '#fef2f2') + '"><b>' + (st.ok ? '✅ Objectifs de reprise respectés' : '⛔ Au moins un objectif de reprise est dépassé') + '</b><br>Dernière sauvegarde : ' + lastTxt + '</div>'
        + '<h3 style="margin:12px 0 4px">1. Objectifs de reprise</h3><p style="font-size:12px;color:#64748b;margin:0 0 6px">RPO = perte de données maximale acceptée (âge de la dernière sauvegarde). RTO = durée maximale pour reprendre. Ils s’appliquent à chaque niveau de criticité.</p>'
        + '<table style="border-collapse:collapse;font-size:13px;width:100%"><tr style="background:#f1f5f9;text-align:left"><th style="padding:5px">Niveau</th><th>RPO</th><th>RTO</th><th>État (RPO)</th></tr>' + tb + '</table>'
        + '<p style="margin:8px 0"><button onclick="EXBContinuite._saveTargets()" style="' + bt + '">Enregistrer les objectifs</button> <button onclick="EXBContinuite._backupNow()" style="' + bt + '">Sauvegarder maintenant</button> <button onclick="EXBSEC&&EXBSEC.open()" style="' + bt + '">🛡 Sauvegarde chiffrée / test de fichier</button></p>'
        + '<h3 style="margin:12px 0 4px">2. Test de restauration (lecture seule)</h3><p style="margin:0 0 6px">' + testTxt + '</p><button onclick="EXBContinuite._test()" style="' + bt + '">Tester la dernière copie interne</button>'
        + '<h3 style="margin:12px 0 4px">3. Contrôle d’intégrité</h3><p style="margin:0 0 6px">' + igTxt + '</p><button onclick="EXBContinuite._integrity()" style="' + bt + '">Lancer le contrôle</button>'
        + '<h3 style="margin:12px 0 4px">4. Avant / après migration ou restauration</h3><p style="margin:0 0 6px;font-size:13px">' + cmTxt + '</p><button onclick="EXBContinuite._ref()" style="' + bt + '">Enregistrer l’état de référence</button> <button onclick="EXBContinuite._cmp()" style="' + bt + '">Comparer à maintenant</button>'
        + '<p style="margin:14px 0 0"><button onclick="EXBContinuite.pdf()" style="' + bt + '">📄 Rapport PDF</button></p>';
    });
  }
  function open() {
    if (!admin()) { toast('Écran réservé à l’administrateur.', 'warn'); return; }
    var o = d.getElementById('exbCont'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbCont'; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;padding:16px;max-width:860px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    view = { integ: null, cmp: null, test: null }; paint();
  }
  function saveTargets() {
    var t = { tiers: {} }; TIERS.forEach(function (x) { var a = d.getElementById('ct_rpo_' + x.id), b = d.getElementById('ct_rto_' + x.id); t.tiers[x.id] = { rpo: num(a && a.value, x.rpo), rto: num(b && b.value, x.rto) }; });
    lsSet(K, t); audit('continuite.objectifs', 'RPO/RTO', { ref: TIERS.map(function (x) { return x.id + ' ' + t.tiers[x.id].rpo + '/' + t.tiers[x.id].rto + ' h'; }).join(' ; ') }); paint();
  }
  function backupNow() { if (w.EXB_ABK && w.EXB_ABK.run) Promise.resolve(w.EXB_ABK.run()).then(function () { setTimeout(paint, 600); }, function () { toast('Sauvegarde impossible.', 'error'); }); else toast('Copie automatique indisponible.', 'warn'); }
  function pdf() {
    if (!w.EXBPdf) { toast('Module PDF indisponible.', 'warn'); return Promise.resolve(); }
    return Promise.all([status(), integrity()]).then(function (a) {
      var st = a[0], ig = a[1], t = st.test, ref = lsGet(KR), cm = compare(), r = [];
      r.push(['Situation', st.ok ? 'Objectifs de reprise respectés' : 'Au moins un objectif de reprise est dépassé']);
      r.push(['Dernière sauvegarde', st.last ? fmt(st.last.t) + ' — ' + st.last.src + ' (il y a ' + dur(st.ageH) + ')' : 'aucune sauvegarde trouvée']);
      st.rows.forEach(function (x) { r.push(['Niveau ' + x.label + ' — RPO / RTO', x.rpo + ' h / ' + x.rto + ' h — RPO ' + (x.ok ? 'respecté' : 'dépassé') + ' (' + x.ex + ')']); });
      r.push(['Dernier test de restauration', t ? (t.ok ? 'Valide' : 'Invalide') + ' le ' + fmt(t.at) + (t.src ? ' — ' + t.src : '') + (t.ms != null ? ' — lecture technique ' + t.ms + ' ms' : '') : 'jamais testé sur cet appareil']);
      r.push(['Contrôle d’intégrité', (ig.ok ? 'Conforme' : 'Anomalies') + ' — ' + ig.jeux + ' jeux de données lus']);
      if (ig.unreadable.length) r.push(['Données illisibles', ig.unreadable.join(', ')]);
      if (ig.dups.length) r.push(['Identifiants en double', ig.dups.map(function (x) { return x.key + ' (' + x.n + ')'; }).join(', ')]);
      if (ig.chain) r.push(['Journal d’audit', ig.chain.ok ? 'chaîne intacte (' + ig.chain.entries + ' lignes)' : 'chaîne rompue à partir du n° ' + ig.chain.firstBroken]);
      r.push(['État de référence', ref ? 'enregistré le ' + fmt(ref.at) + ' (' + Object.keys(ref.counts).length + ' jeux)' : 'aucun']);
      if (cm) { if (!cm.changes.length) r.push(['Comparaison à la référence', 'identique']); else cm.changes.slice(0, 60).forEach(function (c) { r.push(['Écart : ' + c.k, c.t + ' (avant ' + (c.a == null ? '—' : c.a) + ', après ' + (c.b == null ? '—' : c.b) + ')']); }); }
      return EXBPdf.make({ titre: 'RAPPORT DE CONTINUITÉ ET D’INTÉGRITÉ', sousTitre: 'Édité le ' + new Date().toLocaleDateString('fr-FR') + ' à ' + new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }), rows: r,
        notes: ['RPO : perte de données maximale acceptée. RTO : durée maximale de reprise ; le logiciel ne mesure que la partie technique. Valeurs par défaut à valider avec la direction. Rapport établi pour cet appareil.'], footer: 'Continuité — Excellencia Building' })
        .then(function (b) { EXBPdf.save(b, 'CONTINUITE-EXB-' + new Date().toISOString().slice(0, 10) + '.pdf'); });
    });
  }
  function ui() {
    var b = d.getElementById('exbSecBtn'); if (!b || d.getElementById('exbContBtn')) return;
    var k = d.createElement('button'); k.id = 'exbContBtn'; k.className = b.className; k.textContent = '🛟 Continuité'; k.onclick = open; b.parentNode.insertBefore(k, b.nextSibling);
  }
  /* alerte discrète au démarrage si l'objectif critique est dépassé (administrateur seulement, une fois par session) */
  setTimeout(function () { try { if (!admin() || !store()) return; status().then(function (st) { var c = st.rows[0]; if (c && !c.ok) { toast('Continuité : la dernière sauvegarde dépasse l’objectif « critique » (' + c.rpo + ' h). Ouvrez 🛟 Continuité.', 'warn'); audit('continuite.alerte', 'rpo-critique', { ref: st.last ? 'age ' + dur(st.ageH) : 'aucune sauvegarde' }); } }); } catch (e) {} }, 20000);
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  w.EXBContinuite = {
    open: open, pdf: pdf, status: status, targets: targets, testSnapshot: testSnapshot, integrity: integrity, setReference: setRef, compare: compare, readAll: readAll,
    _saveTargets: saveTargets, _backupNow: backupNow,
    _test: function () { testSnapshot().then(function (r) { view.test = r; paint(); }); },
    _integrity: function () { integrity().then(function (r) { view.integ = r; paint(); }); },
    _ref: function () { setRef(); view.cmp = null; paint(); },
    _cmp: function () { view.cmp = compare(); paint(); }
  };
})(window, document);
