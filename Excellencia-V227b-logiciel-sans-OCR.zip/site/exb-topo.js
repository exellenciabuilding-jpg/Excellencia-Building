/* Excellencia Building — BUREAU DE TOPOGRAPHIE V211 (cahier des charges V1.0, §5.8)
 * Fonctions du cahier : import de points, système de coordonnées, implantation, nivellement, surfaces, profils, cubatures, rapports.
 *   1. POINTS         : import texte/CSV (N ; X ; Y ; Z ; code), contrôle des doublons et des lignes illisibles, système de coordonnées DÉCLARÉ
 *                       (nom/EPSG saisi par l'opérateur : aucune transformation de projection n'est faite ni inventée).
 *   2. SURFACE        : aire (formule du lacet), périmètre, détection d'un contour qui se croise.
 *   3. NIVELLEMENT    : cheminement par lectures arrière/avant, fermeture, tolérance (mm·√km, à fixer par la mission), compensation proportionnelle.
 *   4. IMPLANTATION   : gisement, angle horizontal à reporter depuis une station et une référence, distance.
 *   5. PROFIL EN LONG : chaînages cumulés, pentes, dénivelée.
 *   6. CUBATURES      : profils moyens (sections) ou grille de carrés (triangulation, passage déblai/remblai exact), cote de projet.
 * Garde-fou : moteurs déterministes, aucune IA, aucune validation automatique ; visa nominatif (vérificateur ≠ opérateur).
 * Données : clé exb_topo. Pour retirer : supprimer la balise <script src="exb-topo.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBTopo) return;
  var K = 'exb_topo', STG = ['Brouillon', 'Vérifié', 'Visé'], PI = Math.PI;

  /* ------------------------------------------------------------ outils ------------------------------------------------------------ */
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function num(v, def) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : (def === undefined ? NaN : def); }
  function fx(v, n) { return isFinite(v) ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: n, maximumFractionDigits: n }) : '—'; }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function who() { return ask('Votre nom (signature nominative, non qualifiée) :', '').then(function (v) { return String(v || '').trim(); }); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id) }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function san(t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/→/g, '->').replace(/²/g, '2').replace(/³/g, '3').replace(/×/g, 'x').replace(/√/g, 'rac ').replace(/·/g, '.'); }
  function csv(rows, name) { var t = '\ufeff' + rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); try { var b = new Blob([t], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = (w.URL || w.webkitURL).createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); } catch (e) { toast('Export impossible : ' + e.message, 'error'); } }
  function pdf(o) { if (!w.EXBPdf) return toast('Module PDF indisponible.', 'error'); try { var p = w.EXBPdf.make(w.EXBENT && w.EXBENT.piece ? w.EXBENT.piece(o) : o); return Promise.resolve(p).then(function (b) { if (b && b.size && w.EXBPdf.save) { w.EXBPdf.save(b, String((o && (o.sousTitre || o.titre)) || 'rapport').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) + '.pdf'); toast('PDF généré.', 'success'); } return b; }, function (e) { toast('PDF impossible : ' + (e && e.message || e), 'error'); }); } catch (e) { toast('PDF impossible : ' + e.message, 'error'); } }

  /* ========================================================== MOTEURS (déterministes) ========================================================== */
  /* Import : lignes « N ; X ; Y ; Z ; code ». Séparateur : tabulation, « ; », « , » ou espaces. Virgule décimale acceptée avec « ; » ou tabulation. */
  function parsePoints(text) {
    var pts = [], err = [], seen = {}, lines = String(text || '').split(/\r?\n/), first = true;
    lines.forEach(function (ln, i) {
      var s = ln.trim(); if (!s || s.charAt(0) === '#' || s.slice(0, 2) === '//') return;
      var sep = /\t/.test(s) ? /\t/ : (/;/.test(s) ? /;/ : (/,/.test(s) ? /,/ : /\s+/)), f = s.split(sep).map(function (x) { return x.trim(); });
      var x = num(f[1]), y = num(f[2]);
      if (first && (!isFinite(x) || !isFinite(y)) && f.length >= 3) { first = false; return; } /* ligne d'en-tête */
      first = false;
      if (f.length < 3 || !f[0]) { err.push({ ligne: i + 1, msg: 'Ligne illisible (il faut au moins N, X, Y).' }); return; }
      if (!isFinite(x) || !isFinite(y)) { err.push({ ligne: i + 1, msg: 'X ou Y n’est pas un nombre.' }); return; }
      var zr = f[3], z = zr === undefined || zr === '' ? null : num(zr);
      if (z !== null && !isFinite(z)) { err.push({ ligne: i + 1, msg: 'Z n’est pas un nombre.' }); return; }
      if (seen[f[0]]) { err.push({ ligne: i + 1, msg: 'Numéro « ' + f[0] + ' » en double : ligne ignorée.' }); return; }
      seen[f[0]] = 1; pts.push({ n: f[0], x: x, y: y, z: z, code: f[4] || '' });
    });
    return { pts: pts, erreurs: err };
  }
  function dist2(a, b) { return Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2)); }
  function gisement(a, b) { var g = Math.atan2(b.x - a.x, b.y - a.y) * 200 / PI; return g < 0 ? g + 400 : g; } /* grades, depuis le Nord, sens horaire */
  function seg(p1, p2, p3, p4) { /* intersection stricte de [p1p2] et [p3p4] */
    function o(a, b, c) { return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x); }
    var d1 = o(p3, p4, p1), d2 = o(p3, p4, p2), d3 = o(p1, p2, p3), d4 = o(p1, p2, p4);
    return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
  }
  function surface(P) {
    var n = P.length; if (n < 3) return { ok: false, msg: 'Au moins 3 points sont nécessaires.' };
    var s = 0, per = 0, i, j, croise = false;
    for (i = 0; i < n; i++) { var a = P[i], b = P[(i + 1) % n]; s += a.x * b.y - b.x * a.y; per += dist2(a, b); }
    for (i = 0; i < n && !croise; i++) for (j = i + 2; j < n; j++) { if (i === 0 && j === n - 1) continue; if (seg(P[i], P[(i + 1) % n], P[j], P[(j + 1) % n])) { croise = true; break; } }
    return { ok: true, aire: Math.abs(s) / 2, perimetre: per, n: n, croise: croise };
  }
  /* Nivellement : z(i) = z(i−1) + AR − AV. stations : [{pt, ar, av, d}] ; zArr = cote connue d'arrivée (ou null) ; tol en mm par √km. */
  function nivellement(o) {
    var z = num(o.zDep), S = o.stations || [], rows = [], sd = 0, allD = true, i;
    if (!isFinite(z)) return { ok: false, msg: 'Cote de départ manquante.' };
    if (!S.length) return { ok: false, msg: 'Aucune station.' };
    S.forEach(function (s) { var dd = num(s.d); if (!isFinite(dd) || dd <= 0) allD = false; else sd += dd; });
    var cum = 0;
    for (i = 0; i < S.length; i++) {
      var ar = num(S[i].ar), av = num(S[i].av); if (!isFinite(ar) || !isFinite(av)) return { ok: false, msg: 'Lecture illisible à la station ' + (i + 1) + '.' };
      z = z + ar - av; cum += allD ? num(S[i].d) : 1; rows.push({ pt: S[i].pt || String(i + 1), ar: ar, av: av, zBrut: z, cum: cum });
    }
    var zArr = o.zArr === '' || o.zArr == null ? NaN : num(o.zArr), tot = allD ? sd : S.length, res = { ok: true, rows: rows, L: allD ? sd / 1000 : null, ferme: isFinite(zArr) };
    if (isFinite(zArr)) {
      var f = rows[rows.length - 1].zBrut - zArr; res.f = f; res.tolMm = (allD && isFinite(num(o.tol))) ? num(o.tol) * Math.sqrt(sd / 1000) : null;
      res.dansTol = res.tolMm == null ? null : Math.abs(f) * 1000 <= res.tolMm + 1e-9;
      rows.forEach(function (r) { r.corr = -f * r.cum / tot; r.zComp = r.zBrut + r.corr; });
    } else rows.forEach(function (r) { r.corr = 0; r.zComp = r.zBrut; });
    return res;
  }
  function implantation(S, R, cibles) {
    if (dist2(S, R) < 1e-9) return { ok: false, msg: 'La station et la référence sont confondues.' };
    var gR = gisement(S, R);
    return { ok: true, gR: gR, rows: cibles.map(function (T) {
      var dd = dist2(S, T); if (dd < 1e-9) return { n: T.n, err: 'Point confondu avec la station.' };
      var g = gisement(S, T), a = g - gR; if (a < 0) a += 400; return { n: T.n, g: g, angle: a, angleDeg: a * 0.9, dist: dd };
    }) };
  }
  function profil(P) {
    if (P.length < 2) return { ok: false, msg: 'Au moins 2 points.' };
    var rows = [], ch = 0, zmin = Infinity, zmax = -Infinity, i;
    for (i = 0; i < P.length; i++) {
      if (!isFinite(num(P[i].z))) return { ok: false, msg: 'Le point ' + P[i].n + ' n’a pas de cote Z.' };
      var seg2 = i ? dist2(P[i - 1], P[i]) : 0; ch += seg2;
      rows.push({ n: P[i].n, ch: ch, z: P[i].z, pente: i && seg2 > 0 ? (P[i].z - P[i - 1].z) / seg2 * 100 : null });
      zmin = Math.min(zmin, P[i].z); zmax = Math.max(zmax, P[i].z);
    }
    return { ok: true, rows: rows, L: ch, zmin: zmin, zmax: zmax, deniv: P[P.length - 1].z - P[0].z };
  }
  /* Aire de déblai (terrain au-dessus du projet) et de remblai d'une section [{o, z}] pour une cote de projet. */
  function sectionAires(T, zp) {
    var dg = 0, rm = 0, i;
    for (i = 0; i < T.length - 1; i++) {
      var dx = T[i + 1].o - T[i].o, h1 = T[i].z - zp, h2 = T[i + 1].z - zp;
      if (!(dx > 0)) continue;
      if (h1 >= 0 && h2 >= 0) dg += (h1 + h2) / 2 * dx;
      else if (h1 <= 0 && h2 <= 0) rm += (-h1 - h2) / 2 * dx;
      else { var x0 = dx * h1 / (h1 - h2), a1 = Math.abs(h1) * x0 / 2, a2 = Math.abs(h2) * (dx - x0) / 2; if (h1 > 0) { dg += a1; rm += a2; } else { rm += a1; dg += a2; } }
    }
    return { deblai: dg, remblai: rm };
  }
  function cubProfils(S) { /* S : [{ch, ad, ar}] */
    var a = S.slice().sort(function (p, q) { return p.ch - q.ch; }), vd = 0, vr = 0, i;
    if (a.length < 2) return { ok: false, msg: 'Au moins 2 profils.' };
    for (i = 0; i < a.length - 1; i++) { var L = a[i + 1].ch - a[i].ch; vd += (a[i].ad + a[i + 1].ad) / 2 * L; vr += (a[i].ar + a[i + 1].ar) / 2 * L; }
    return { ok: true, deblai: vd, remblai: vr, net: vd - vr, methode: 'profils moyens' };
  }
  function triVol(A, h1, h2, h3) { /* volume de déblai (h>0) et de remblai (h<0) sous un triangle d'aire A */
    var tot = A * (h1 + h2 + h3) / 3, h = [h1, h2, h3], np = h.filter(function (x) { return x > 0; }).length, nn = h.filter(function (x) { return x < 0; }).length, odd, o2, o3;
    if (!np && !nn) return { d: 0, r: 0 };
    if (!nn) return { d: tot, r: 0 };
    if (!np) return { d: 0, r: -tot };
    if (np === 1) { odd = h.filter(function (x) { return x > 0; })[0]; o2 = h.filter(function (x) { return x <= 0; }); var dd = A * Math.pow(odd, 3) / (3 * (odd - o2[0]) * (odd - o2[1])); return { d: dd, r: dd - tot }; }
    odd = h.filter(function (x) { return x < 0; })[0]; o3 = h.filter(function (x) { return x >= 0; }); var rr = A * Math.pow(-odd, 3) / (3 * (odd - o3[0]) * (odd - o3[1])); return { d: rr + tot, r: rr };
  }
  function cubGrille(o) { /* o.pas (m), o.zp (cote projet), o.G : matrice des cotes de terrain [lignes][colonnes] */
    var G = o.G || [], pas = num(o.pas), zp = num(o.zp), r = G.length, c = r ? G[0].length : 0, i, j, vd = 0, vr = 0;
    if (!(pas > 0)) return { ok: false, msg: 'Pas de grille invalide.' };
    if (!isFinite(zp)) return { ok: false, msg: 'Cote de projet manquante.' };
    if (r < 2 || c < 2) return { ok: false, msg: 'La grille doit avoir au moins 2 lignes et 2 colonnes.' };
    for (i = 0; i < r; i++) { if (G[i].length !== c) return { ok: false, msg: 'La ligne ' + (i + 1) + ' n’a pas le même nombre de cotes que la première.' }; for (j = 0; j < c; j++) if (!isFinite(num(G[i][j]))) return { ok: false, msg: 'Cote illisible (ligne ' + (i + 1) + ', colonne ' + (j + 1) + ').' }; }
    var A = pas * pas / 2;
    for (i = 0; i < r - 1; i++) for (j = 0; j < c - 1; j++) {
      var a = G[i][j] - zp, b = G[i][j + 1] - zp, e = G[i + 1][j + 1] - zp, f = G[i + 1][j] - zp, t1 = triVol(A, a, b, e), t2 = triVol(A, a, e, f);
      vd += t1.d + t2.d; vr += t1.r + t2.r;
    }
    return { ok: true, deblai: vd, remblai: vr, net: vd - vr, surface: (r - 1) * (c - 1) * pas * pas, methode: 'grille de carrés (triangulation)' };
  }

  /* ========================================================== DOSSIER ========================================================== */
  function all() { return rd(K); }
  function find(id) { return all().filter(function (x) { return x.id === id; })[0]; }
  function saveDos(x) { var a = all(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i < 0) a.push(x); else a[i] = x; return wr(K, a); }
  function nouveau() {
    var n = all().length + 1, y = new Date().getFullYear();
    return { id: uid('TOPO'), no: 'TOPO-' + y + '-' + String(n).padStart(3, '0'), statut: 'Brouillon', titre: '', project_id: '', site: '', date: new Date().toISOString().slice(0, 10), operateur: '', sys: { nom: '', epsg: '', note: '' },
      ptsTxt: '', surfTxt: '', niv: { zDep: '', zArr: '', tol: '', txt: '' }, impl: { st: '', ref: '', cibles: '' }, profTxt: '', cub: { mode: 'grille', zp: '', pas: '', grille: '', sections: '' }, histo: [], cree: Date.now() };
  }
  function pts(x) { return parsePoints(x.ptsTxt).pts; }
  function byN(x) { var m = {}; pts(x).forEach(function (p) { m[p.n] = p; }); return m; }
  function liste(t) { return String(t || '').split(/[\s;,]+/).filter(Boolean); }
  function choose(x, t) { var m = byN(x), miss = [], out = []; liste(t).forEach(function (n) { if (m[n]) out.push(m[n]); else miss.push(n); }); return { pts: out, absents: miss }; }
  function lignesNiv(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return l && l.charAt(0) !== '#'; }).map(function (l) { var f = l.split(/[;\t]/).map(function (z) { return z.trim(); }); return { pt: f[0], ar: f[1], av: f[2], d: f[3] }; }); }
  function matrice(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean).map(function (l) { return l.split(/[\s;]+/).filter(Boolean).map(function (v) { return num(v); }); }); }
  function sectionsTxt(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return l && l.charAt(0) !== '#'; }).map(function (l) { var f = l.split(/[;\t]/).map(num); return { ch: f[0], ad: f[1], ar: f[2] }; }); }
  function cubCalc(x) {
    if (x.cub.mode === 'sections') { var S = sectionsTxt(x.cub.sections); if (S.some(function (s) { return !isFinite(s.ch) || !isFinite(s.ad) || !isFinite(s.ar); })) return { ok: false, msg: 'Section illisible : format « chaînage ; aire déblai ; aire remblai ».' }; return cubProfils(S); }
    return cubGrille({ pas: x.cub.pas, zp: x.cub.zp, G: matrice(x.cub.grille) });
  }
  function verif(x) {
    var a = [], add = function (n, id, m) { a.push({ niveau: n, id: id, msg: m }); }, pr = parsePoints(x.ptsTxt), P = pr.pts, i, j;
    if (!P.length) add('bloquant', 'TOPO-1', 'Aucun point importé : un dossier de topographie sans points ne peut pas être vérifié.');
    if (!String(x.sys.nom || '').trim()) add('bloquant', 'TOPO-2', 'Système de coordonnées non déclaré (nom ou EPSG).');
    if (!String(x.operateur || '').trim()) add('bloquant', 'TOPO-9', 'Opérateur / auteur du levé non renseigné.');
    pr.erreurs.forEach(function (e) { add('alerte', 'TOPO-3', 'Import ligne ' + e.ligne + ' : ' + e.msg); });
    var sz = P.filter(function (p) { return p.z === null; }).length; if (sz) add('alerte', 'TOPO-4', sz + ' point(s) sans cote Z.');
    if (P.length && P.length <= 2000) { var prox = 0; for (i = 0; i < P.length; i++) for (j = i + 1; j < P.length; j++) if (dist2(P[i], P[j]) < 0.01 && (P[i].z === null || P[j].z === null || Math.abs(P[i].z - P[j].z) < 0.01)) prox++; if (prox) add('alerte', 'TOPO-5', prox + ' paire(s) de points distants de moins de 1 cm : doublon probable.'); }
    if (P.length > 1) { var xs = P.map(function (p) { return p.x; }), ys = P.map(function (p) { return p.y; }); if (Math.max.apply(null, xs) - Math.min.apply(null, xs) > 20000 || Math.max.apply(null, ys) - Math.min.apply(null, ys) > 20000) add('alerte', 'TOPO-6', 'Étendue supérieure à 20 km : vérifier les coordonnées (point aberrant ou mauvais système).'); }
    if (x.niv.txt.trim()) { var N = nivellement({ zDep: x.niv.zDep, zArr: x.niv.zArr, tol: x.niv.tol, stations: lignesNiv(x.niv.txt) }); if (!N.ok) add('alerte', 'TOPO-7', 'Nivellement : ' + N.msg); else if (N.dansTol === false) add('bloquant', 'TOPO-7', 'Nivellement : fermeture ' + fx(N.f * 1000, 1) + ' mm > tolérance ' + fx(N.tolMm, 1) + ' mm — cheminement à reprendre.'); else if (N.ferme && N.dansTol === null) add('alerte', 'TOPO-7', 'Nivellement : tolérance ou distances non renseignées, fermeture non jugée.'); }
    if (x.surfTxt.trim()) { var c = choose(x, x.surfTxt); if (c.absents.length) add('alerte', 'TOPO-8', 'Surface : point(s) inconnu(s) : ' + c.absents.join(', ') + '.'); var s = surface(c.pts); if (s.ok && s.croise) add('alerte', 'TOPO-8', 'Surface : le contour se croise, l’aire calculée n’est pas fiable.'); }
    if ((x.cub.grille.trim() || x.cub.sections.trim()) && x.cub.mode === 'grille' && !isFinite(num(x.cub.zp))) add('alerte', 'TOPO-10', 'Cubature : cote de projet non renseignée.');
    return a;
  }
  function bloque(x) { return verif(x).filter(function (v) { return v.niveau === 'bloquant'; }); }

  /* ========================================================== INTERFACE ========================================================== */
  var TAB = 'pts', GID = null, MAXPTS = 5000;
  function box() { return d.getElementById('exbTopoBox'); }
  function ro(x) { return x.statut !== 'Brouillon'; }
  function btn(l, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + l + '</button>'; }
  function lab(t, h) { return '<label style="display:block;font-size:12.5px;color:#334155">' + t + h + '</label>'; }
  function inp(f, v, o) { o = o || {}; return '<input data-f="' + f + '" value="' + esc(v) + '"' + (o.dis ? ' disabled' : '') + ' style="width:100%;padding:6px;box-sizing:border-box">'; }
  function ta(f, v, dis, rows, ph) { return '<textarea data-t="' + f + '" rows="' + (rows || 6) + '"' + (dis ? ' disabled' : '') + ' placeholder="' + esc(ph || '') + '" style="width:100%;box-sizing:border-box;padding:6px;font:12.5px monospace">' + esc(v) + '</textarea>'; }
  function table(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr>' + h.map(function (c) { return '<th style="text-align:left;border-bottom:1px solid #cbd5e1;padding:4px 8px">' + c + '</th>'; }).join('') + '</tr>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="border-bottom:1px solid #e2e8f0;padding:4px 8px">' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</table></div>'; }
  function alertesHtml(A) { return A.length ? '<ul style="margin:6px 0;padding-left:18px;font-size:12.5px">' + A.map(function (a) { return '<li style="color:' + (a.niveau === 'bloquant' ? '#b91c1c' : '#b45309') + '">' + esc(a.id) + ' — ' + esc(a.msg) + '</li>'; }).join('') + '</ul>' : '<p style="color:#15803d;font-size:12.5px">Aucune alerte.</p>'; }
  function select(f, v, opts, dis) { return '<select data-f="' + f + '"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="">—</option>' + opts.map(function (o) { return '<option value="' + esc(o.id) + '"' + (o.id === v ? ' selected' : '') + '>' + esc(o.nom) + '</option>'; }).join('') + '</select>'; }

  function liste0() {
    var a = all();
    return '<h3 style="margin:6px 0">🗺️ Topographie</h3><p style="font-size:12.5px;color:#475569">Points, surfaces, nivellement, implantation, profils et cubatures. Calculs déterministes : ils ne remplacent pas le visa d’un géomètre / topographe qualifié.</p>' + btn('➕ Nouveau dossier topographique', 'new') +
      (a.length ? table(['N°', 'Titre', 'Projet', 'Statut', ''], a.map(function (r) { return [esc(r.no), esc(r.titre || '—'), esc(pnom(r.project_id)), esc(r.statut), btn('Ouvrir', 'open', r.id)]; })) : '<p>Aucun dossier.</p>');
  }
  function tabPts(x, dis) {
    var pr = parsePoints(x.ptsTxt), sys = x.sys, h = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px">' + lab('Système de coordonnées (nom)', inp('sys.nom', sys.nom, { dis: dis })) + lab('Code EPSG (si connu)', inp('sys.epsg', sys.epsg, { dis: dis })) + lab('Note (fuseau, origine locale, datum vertical)', inp('sys.note', sys.note, { dis: dis })) + '</div>';
    h += '<p style="font-size:12px;color:#475569">Le système est <b>déclaré</b> ici : le logiciel ne convertit pas d’un système à un autre.</p>';
    h += lab('Points (un par ligne : N ; X ; Y ; Z ; code)', ta('ptsTxt', x.ptsTxt, dis, 8, 'P1;1000,25;2000,10;310,52;PIQ'));
    if (!dis) h += '<div>' + '<input type="file" accept=".csv,.txt" data-a="file" style="margin:4px 0"></div>';
    h += '<p style="font-size:12.5px"><b>' + pr.pts.length + '</b> point(s) lu(s)' + (pr.pts.length > MAXPTS ? ' — attention : plus de ' + MAXPTS + ' points, l’affichage est limité.' : '') + '.</p>';
    if (pr.erreurs.length) h += '<ul style="font-size:12.5px;color:#b45309;padding-left:18px">' + pr.erreurs.slice(0, 20).map(function (e) { return '<li>Ligne ' + e.ligne + ' : ' + esc(e.msg) + '</li>'; }).join('') + (pr.erreurs.length > 20 ? '<li>… ' + (pr.erreurs.length - 20) + ' autre(s).</li>' : '') + '</ul>';
    if (pr.pts.length) h += table(['N', 'X', 'Y', 'Z', 'Code'], pr.pts.slice(0, 200).map(function (p) { return [esc(p.n), fx(p.x, 3), fx(p.y, 3), p.z === null ? '—' : fx(p.z, 3), esc(p.code)]; })) + (pr.pts.length > 200 ? '<p style="font-size:12px">Aperçu des 200 premiers points.</p>' : '');
    return h;
  }
  function tabSurf(x, dis) {
    var c = choose(x, x.surfTxt), s = x.surfTxt.trim() ? surface(c.pts) : null, h = lab('Contour : numéros de points dans l’ordre (séparés par espace, « ; » ou « , »)', ta('surfTxt', x.surfTxt, dis, 3, 'P1 P2 P3 P4'));
    if (c.absents.length) h += '<p style="color:#b45309;font-size:12.5px">Point(s) inconnu(s) : ' + esc(c.absents.join(', ')) + '</p>';
    if (s) h += s.ok ? '<p><b>Aire : ' + fx(s.aire, 2) + ' m²</b> (' + fx(s.aire / 10000, 4) + ' ha) — périmètre : ' + fx(s.perimetre, 2) + ' m — ' + s.n + ' sommets.' + (s.croise ? ' <span style="color:#b91c1c">Contour croisé : aire non fiable.</span>' : '') + '</p>' : '<p style="color:#b45309">' + esc(s.msg) + '</p>';
    return h;
  }
  function tabNiv(x, dis) {
    var n = x.niv, h = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + lab('Cote de départ (m)', inp('niv.zDep', n.zDep, { dis: dis })) + lab('Cote d’arrivée connue (m) — vide si cheminement ouvert', inp('niv.zArr', n.zArr, { dis: dis })) + lab('Tolérance (mm par √km), fixée par la mission', inp('niv.tol', n.tol, { dis: dis })) + '</div>';
    h += lab('Stations (un par ligne : point ; lecture arrière ; lecture avant ; distance en m, facultatif)', ta('niv.txt', n.txt, dis, 6, 'A;1,500;1,200;45\nB;1,400;1,300;50'));
    if (n.txt.trim()) { var N = nivellement({ zDep: n.zDep, zArr: n.zArr, tol: n.tol, stations: lignesNiv(n.txt) });
      if (!N.ok) h += '<p style="color:#b45309">' + esc(N.msg) + '</p>';
      else { h += table(['Point', 'AR', 'AV', 'Cote brute', 'Correction', 'Cote compensée'], N.rows.map(function (r) { return [esc(r.pt), fx(r.ar, 3), fx(r.av, 3), fx(r.zBrut, 3), fx(r.corr * 1000, 1) + ' mm', '<b>' + fx(r.zComp, 3) + '</b>']; }));
        if (N.ferme) h += '<p>Fermeture : <b>' + fx(N.f * 1000, 1) + ' mm</b>' + (N.tolMm != null ? ' — tolérance ' + fx(N.tolMm, 1) + ' mm — ' + (N.dansTol ? '<span style="color:#15803d">dans la tolérance</span>' : '<span style="color:#b91c1c">HORS tolérance : reprendre le cheminement</span>') : ' — tolérance ou distances non renseignées : fermeture non jugée.') + '</p>'; else h += '<p style="font-size:12.5px">Cheminement ouvert : aucune fermeture ni compensation possible.</p>'; } }
    return h;
  }
  function tabImpl(x, dis) {
    var P = pts(x), m = byN(x), i = x.impl, h = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + lab('Station (n° de point)', inp('impl.st', i.st, { dis: dis })) + lab('Référence (n° de point visé)', inp('impl.ref', i.ref, { dis: dis })) + '</div>' + lab('Points à implanter (numéros)', ta('impl.cibles', i.cibles, dis, 2, 'P5 P6 P7'));
    if (i.st && i.ref && i.cibles.trim()) {
      if (!m[i.st] || !m[i.ref]) h += '<p style="color:#b45309">Station ou référence introuvable dans les points.</p>';
      else { var c = choose(x, i.cibles), R = implantation(m[i.st], m[i.ref], c.pts); if (!R.ok) h += '<p style="color:#b45309">' + esc(R.msg) + '</p>'; else { h += '<p style="font-size:12.5px">Gisement station→référence : ' + fx(R.gR, 4) + ' gr. Angle horizontal à lire depuis la référence, sens horaire.</p>' + table(['Point', 'Gisement (gr)', 'Angle (gr)', 'Angle (°)', 'Distance (m)'], R.rows.map(function (r) { return r.err ? [esc(r.n), '—', '—', '—', esc(r.err)] : [esc(r.n), fx(r.g, 4), '<b>' + fx(r.angle, 4) + '</b>', fx(r.angleDeg, 4), '<b>' + fx(r.dist, 3) + '</b>']; })); if (c.absents.length) h += '<p style="color:#b45309">Introuvable(s) : ' + esc(c.absents.join(', ')) + '</p>'; } }
    }
    return h + (P.length ? '' : '<p style="font-size:12.5px">Importez d’abord des points.</p>');
  }
  function tabProf(x, dis) {
    var h = lab('Points du profil dans l’ordre (numéros)', ta('profTxt', x.profTxt, dis, 3, 'P1 P2 P3'));
    if (x.profTxt.trim()) { var c = choose(x, x.profTxt), R = profil(c.pts); if (c.absents.length) h += '<p style="color:#b45309">Introuvable(s) : ' + esc(c.absents.join(', ')) + '</p>';
      h += R.ok ? '<p style="font-size:12.5px">Longueur : <b>' + fx(R.L, 2) + ' m</b> — Z min ' + fx(R.zmin, 3) + ' / max ' + fx(R.zmax, 3) + ' — dénivelée ' + fx(R.deniv, 3) + ' m.</p>' + table(['Point', 'Chaînage (m)', 'Z (m)', 'Pente (%)'], R.rows.map(function (r) { return [esc(r.n), fx(r.ch, 2), fx(r.z, 3), r.pente === null ? '—' : fx(r.pente, 2)]; })) : '<p style="color:#b45309">' + esc(R.msg) + '</p>'; }
    return h;
  }
  function tabCub(x, dis) {
    var c = x.cub, h = lab('Méthode', '<select data-f="cub.mode"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="grille"' + (c.mode === 'grille' ? ' selected' : '') + '>Grille de carrés (cotes de terrain aux nœuds)</option><option value="sections"' + (c.mode === 'sections' ? ' selected' : '') + '>Profils moyens (aires par section)</option></select>');
    if (c.mode === 'grille') h += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + lab('Pas de la grille (m)', inp('cub.pas', c.pas, { dis: dis })) + lab('Cote de projet (m)', inp('cub.zp', c.zp, { dis: dis })) + '</div>' + lab('Cotes de terrain : une ligne de grille par ligne de texte, valeurs séparées par un espace', ta('cub.grille', c.grille, dis, 6, '10,0 10,2 10,4\n9,8 10,0 10,1'));
    else h += lab('Sections (un par ligne : chaînage ; aire déblai m² ; aire remblai m²)', ta('cub.sections', c.sections, dis, 6, '0;12,5;0\n20;8;1,5'));
    var R = (c.grille.trim() || c.sections.trim()) ? cubCalc(x) : null;
    if (R) h += R.ok ? '<p>Déblai : <b>' + fx(R.deblai, 2) + ' m³</b> — Remblai : <b>' + fx(R.remblai, 2) + ' m³</b> — Solde : ' + fx(R.net, 2) + ' m³ (' + (R.net >= 0 ? 'excédent de déblai' : 'déficit, apport de remblai') + ').</p><p style="font-size:12px;color:#475569">Méthode : ' + esc(R.methode) + '. Volumes géométriques, sans foisonnement ni tassement.</p>' : '<p style="color:#b45309">' + esc(R.msg) + '</p>';
    return h;
  }
  function tabRap(x) {
    var A = verif(x), h = '<h4 style="margin:6px 0">Contrôles</h4>' + alertesHtml(A) + '<h4 style="margin:10px 0 4px">Visa</h4><p style="font-size:12.5px">Statut : <b>' + esc(x.statut) + '</b>' + (x.verifie ? ' — vérifié par ' + esc(x.verifie.par) + ' le ' + esc(new Date(x.verifie.t).toLocaleDateString('fr-FR')) : '') + (x.vise ? ' — visé par ' + esc(x.vise.par) + ' le ' + esc(new Date(x.vise.t).toLocaleDateString('fr-FR')) : '') + '</p>';
    if (x.statut === 'Brouillon') h += btn('Marquer comme vérifié', 'verifier', null, '#7c3aed'); if (x.statut === 'Vérifié') h += btn('Viser le dossier', 'viser', null, '#7c3aed') + btn('Rouvrir en brouillon', 'rouvrir', null, '#475569'); if (x.statut === 'Visé') h += btn('Rouvrir (motif obligatoire)', 'rouvrir', null, '#475569');
    h += '<div style="margin-top:8px">' + btn('📄 Rapport PDF', 'pdf', null, '#0369a1') + btn('⬇️ Points CSV', 'csvp', null, '#475569') + '</div>';
    if (x.histo.length) h += '<h4 style="margin:10px 0 4px">Historique</h4><ul style="font-size:12px;padding-left:18px">' + x.histo.map(function (e) { return '<li>' + esc(new Date(e.t).toLocaleString('fr-FR')) + ' — ' + esc(e.msg) + '</li>'; }).join('') + '</ul>';
    return h;
  }
  function paint() {
    var b = box(); if (!b) return; var x = GID ? find(GID) : null;
    if (!x) { b.innerHTML = '<div style="display:flex"><button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + liste0(); return; }
    var dis = ro(x), tabs = [['pts', '📍 Points'], ['surf', '⬛ Surface'], ['niv', '📏 Nivellement'], ['impl', '🎯 Implantation'], ['prof', '📈 Profil'], ['cub', '⛏️ Cubatures'], ['rap', '✅ Rapport']];
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><button data-a="back" style="padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">← Dossiers</button>' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:999px;background:' + (TAB === t[0] ? '#0f766e' : '#e2e8f0') + ';color:' + (TAB === t[0] ? '#fff' : '#0f172a') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px;margin-bottom:8px">' + lab('Titre', inp('titre', x.titre, { dis: dis })) + lab('Projet', select('project_id', x.project_id, projets(), dis)) + lab('Site / parcelle', inp('site', x.site, { dis: dis })) + lab('Date du levé', '<input data-f="date" type="date" value="' + esc(x.date) + '"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px;box-sizing:border-box">') + lab('Opérateur / auteur du levé', inp('operateur', x.operateur, { dis: dis })) + '</div><p style="font-size:12px;color:#475569;margin:0 0 6px">' + esc(x.no) + ' — ' + esc(x.statut) + (dis ? ' (verrouillé : rouvrir pour modifier)' : '') + '</p><div id="exbTopoTab">' +
      ({ pts: tabPts, surf: tabSurf, niv: tabNiv, impl: tabImpl, prof: tabProf, cub: tabCub, rap: tabRap }[TAB])(x, dis) + '</div>';
  }
  function setPath(x, f, v) { var p = f.split('.'), o = x; while (p.length > 1) o = o[p.shift()]; o[p[0]] = v; }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && (t.getAttribute('data-f') || t.getAttribute('data-t')), x = GID ? find(GID) : null; if (!f || !x || ro(x)) return;
    setPath(x, f, t.value); saveDos(x); if (t.tagName === 'SELECT' || f === 'cub.mode' || t.getAttribute('data-t')) paint();
  }
  function jrn(x, msg) { x.histo.push({ t: Date.now(), msg: msg }); }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i'), x = GID ? find(GID) : null;
    if (a === 'file') return;
    if (a === 'close') { var o = d.getElementById('exbTopo'); if (o) o.remove(); return; }
    if (a === 'new') { var n = nouveau(); saveDos(n); GID = n.id; TAB = 'pts'; audit('topo.nouveau', n.no, {}); return paint(); }
    if (a === 'open') { GID = i; TAB = 'pts'; return paint(); }
    if (a === 'back') { GID = null; return paint(); }
    if (a === 'tab') { TAB = i; return paint(); }
    if (!x) return;
    if (a === 'verifier') { var bl = bloque(x); if (bl.length) return toast('Vérification impossible : ' + bl.map(function (v) { return v.id; }).join(', ') + ' (voir l’onglet Rapport).', 'warn'); return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.operateur).trim().toLowerCase()) return toast('Le vérificateur doit être une autre personne que l’opérateur.', 'warn'); x.statut = 'Vérifié'; x.verifie = { par: par, t: Date.now() }; jrn(x, 'Vérifié par ' + par); saveDos(x); audit('topo.verifie', x.no, { par: par }); paint(); }); }
    if (a === 'viser') return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.operateur).trim().toLowerCase()) return toast('Le visa ne peut pas être donné par l’opérateur du levé.', 'warn'); x.statut = 'Visé'; x.vise = { par: par, t: Date.now() }; jrn(x, 'Visé par ' + par); saveDos(x); audit('topo.vise', x.no, { par: par }); paint(); });
    if (a === 'rouvrir') return ask('Motif de la réouverture (obligatoire) :', '').then(function (m) { m = String(m || '').trim(); if (!m) return toast('Motif obligatoire.', 'warn'); jrn(x, 'Rouvert en brouillon — ' + m); x.statut = 'Brouillon'; delete x.verifie; delete x.vise; saveDos(x); audit('topo.rouvert', x.no, { motif: m }); paint(); });
    if (a === 'csvp') return csv([['N', 'X', 'Y', 'Z', 'Code']].concat(pts(x).map(function (p) { return [p.n, p.x, p.y, p.z === null ? '' : p.z, p.code]; })), x.no + '-points.csv');
    if (a === 'pdf') {
      var rows = [['Dossier', x.no + ' — ' + (x.titre || '—') + ' — statut : ' + x.statut], ['Projet / site', pnom(x.project_id) + ' — ' + (x.site || '—')], ['Date / opérateur', (x.date || '—') + ' — ' + (x.operateur || '—')], ['Système de coordonnées', (x.sys.nom || '—') + (x.sys.epsg ? ' (EPSG ' + x.sys.epsg + ')' : '') + (x.sys.note ? ' — ' + x.sys.note : '')], ['Points', String(pts(x).length)]], c;
      if (x.surfTxt.trim()) { c = surface(choose(x, x.surfTxt).pts); if (c.ok) rows.push(['Surface', fx(c.aire, 2) + ' m² — périmètre ' + fx(c.perimetre, 2) + ' m']); }
      if (x.niv.txt.trim()) { c = nivellement({ zDep: x.niv.zDep, zArr: x.niv.zArr, tol: x.niv.tol, stations: lignesNiv(x.niv.txt) }); if (c.ok) rows.push(['Nivellement', c.rows.length + ' station(s)' + (c.ferme ? ' — fermeture ' + fx(c.f * 1000, 1) + ' mm' : ' — cheminement ouvert') + (c.tolMm != null ? ' (tolérance ' + fx(c.tolMm, 1) + ' mm)' : '')]); }
      if (x.cub.grille.trim() || x.cub.sections.trim()) { c = cubCalc(x); if (c.ok) rows.push(['Cubatures', 'déblai ' + fx(c.deblai, 2) + ' m3 — remblai ' + fx(c.remblai, 2) + ' m3 — ' + c.methode]); }
      verif(x).forEach(function (v) { rows.push(['Contrôle ' + v.id, v.niveau + ' : ' + v.msg]); });
      return pdf({ titre: 'DOSSIER TOPOGRAPHIQUE', sousTitre: san(x.no + ' — ' + (x.titre || '')), rows: rows.map(function (r) { return [san(r[0]), san(r[1])]; }), notes: ['Calculs déterministes — ne remplacent pas le visa d’un géomètre / topographe qualifié. Volumes géométriques, sans foisonnement.'], footer: san(x.no + ' — ' + x.statut) });
    }
  }
  function ouvrir(tab) {
    if (tab) TAB = tab; var o = d.getElementById('exbTopo'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbTopo'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbTopoBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('change', function (ev) {
      var t = ev.target; if (t.type === 'file' && t.files && t.files[0]) { var x = GID ? find(GID) : null; if (!x || ro(x)) return; var f = t.files[0]; if (f.size > 5 * 1024 * 1024) return toast('Fichier trop volumineux (5 Mo maximum).', 'warn'); var r = new FileReader(); r.onload = function () { x.ptsTxt = (x.ptsTxt ? x.ptsTxt.replace(/\s+$/, '') + '\n' : '') + String(r.result || ''); jrn(x, 'Import du fichier « ' + f.name + ' »'); saveDos(x); audit('topo.import', x.no, { fichier: f.name }); paint(); }; r.readAsText(f); return; }
      onChange(ev);
    });
    c.addEventListener('click', onClick); paint();
  }
  function ui() {
    var b = d.getElementById('exbBeDalBtn') || d.getElementById('exbBeP2Btn') || d.getElementById('exbBeBtn'); if (!b || d.getElementById('exbTopoBtn')) return;
    var k = d.createElement('button'); k.id = 'exbTopoBtn'; k.setAttribute('data-exb-cat', 'ing'); k.setAttribute('data-exb-desc', 'Points, surfaces, nivellement, implantation, profils, cubatures'); k.className = b.className; k.textContent = '🗺️ Topographie'; k.onclick = function () { ouvrir('pts'); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined' && d.documentElement && d.documentElement.nodeType) new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'topo', name: 'Bureau de topographie', version: '1.0.0', area: 'Technique', deps: [], collections: [K] }); } catch (e) {}

  w.EXBTopo = { open: ouvrir, parsePoints: parsePoints, gisement: gisement, dist: dist2, surface: surface, nivellement: nivellement, implantation: implantation, profil: profil, sectionAires: sectionAires, cubProfils: cubProfils, cubGrille: cubGrille, triVol: triVol, verif: verif, nouveau: nouveau };
  if (typeof module !== 'undefined' && module.exports) module.exports = w.EXBTopo;
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { addEventListener: function () {}, documentElement: {} });
