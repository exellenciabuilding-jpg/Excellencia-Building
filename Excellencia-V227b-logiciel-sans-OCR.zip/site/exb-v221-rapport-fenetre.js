/* Excellencia Building V221i — RAPPORTS DES MODULES SANS FENÊTRE POPUP.
 * Programme & surfaces, Contrôle réglementaire, Analyse de site, Matériaux, Coordination et Règles IDS généraient leur rapport dans une nouvelle fenêtre
 * (window.open). Les navigateurs, l'application Windows et le mobile la bloquent souvent : le rapport/PDF « ne sortait pas ».
 * EXBPOP.open() renvoie une fenêtre virtuelle (document.write / close / print) : le document est confié à l'aperçu commun EXBPrint
 * (Imprimer / Enregistrer en PDF), sans popup. Si EXBPrint est absent, retour à window.open. */
(function (w) {
  'use strict';
  if (w.EXBPOP) return;
  function open() {
    var buf = [], done = false;
    var win = {
      document: {
        open: function () { buf = []; return win.document; },
        write: function () { for (var i = 0; i < arguments.length; i++) buf.push(String(arguments[i])); },
        writeln: function () { win.document.write.apply(null, arguments); },
        close: function () {
          if (done) return; done = true;
          var html = buf.join(''), m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html), t = m ? m[1].replace(/<[^>]+>/g, '').trim() : 'Rapport';
          try { if (w.EXBPrint && w.EXBPrint.html) w.EXBPrint.html(t || 'Rapport', html, {}); else { var x = w.open('', '_blank'); if (x) { x.document.write(html); x.document.close(); } } } catch (e) { }
        }
      },
      focus: function () { }, print: function () { }, close: function () { done = true; }
    };
    return win;
  }
  w.EXBPOP = { open: open, version: 'V221i' };
})(typeof window !== 'undefined' ? window : globalThis);
