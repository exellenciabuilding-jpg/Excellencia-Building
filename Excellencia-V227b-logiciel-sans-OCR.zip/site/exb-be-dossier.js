/* Excellencia Building — BUREAU D'ÉTUDES · DOSSIER D'ÉTUDE V207 (cahier des charges V1.0, §5.1, priorité P1)
 * Couche de gouvernance AU-DESSUS des notes de calcul existantes (exb-etudes.js : poteaux, semelles, poutres, descente de charges — BAEL 91 mod. 99).
 * Aucun calcul nouveau n'est introduit : les moteurs restent déterministes ; ce module cadre, contrôle, fait viser et documente.
 *   1. Dossier d'étude        : mission, client, bâtiment, localisation, données d'entrée, livrables, responsable, échéances.
 *   2. Référentiel normatif   : bibliothèque versionnée (BAEL 91 mod. 99, Eurocodes…), norme ET édition choisies explicitement par dossier.
 *   3. Hypothèses de calcul   : matériaux, charges, combinaisons, sol, conditions aux limites, unités — chacune avec valeur, unité et JUSTIFICATION.
 *   4. Vérification indépendante : contrôles déterministes (norme choisie, cohérence norme/moteur, hypothèses complètes et justifiées, cohérence
 *      matériaux dossier/notes, alertes des notes, sol pour les fondations, empreinte des notes depuis le visa). Elle ALERTE ; elle ne valide jamais.
 *   5. Visa et signature      : brouillon → soumis → vérifié → visé → émis. Rejet motivé, vérificateur ≠ auteur, viseur ≠ auteur,
 *      droits d'action « soumettre / approuver » et fonction ingénieur (ou administrateur), historique complet, dossier verrouillé après émission
 *      (une modification passe par une NOUVELLE RÉVISION).
 *   6. Rapport technique PDF  : hypothèses, références, résultats des notes, contrôles, limites, signatures et empreintes des notes.
 * Garde-fou : aucune IA générative ne calcule ni n'approuve ici. Les signatures sont des mentions nominatives saisies par la personne connectée :
 * ce ne sont PAS des signatures électroniques qualifiées. Dalles et escaliers : calculés par exb-be-dalles.js et repris ici (V210) ; géotechnique détaillé : voir exb-be-p2.js.
 * Données : clés exb_be_dossiers et exb_be_normes (suivies par exb-com-socle.js pour l'historique des versions).
 * Pour retirer : supprimer la balise <script src="exb-be-dossier.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBBeD) return;
  var KD = 'exb_be_dossiers', KN = 'exb_be_normes';
  var CATS = [['materiaux', 'Matériaux'], ['charges', 'Charges'], ['combinaisons', 'Combinaisons'], ['sol', 'Sol / géotechnique'], ['limites', 'Conditions aux limites'], ['unites', 'Unités'], ['autre', 'Autre']];
  var REQ = ['materiaux', 'charges', 'combinaisons', 'limites', 'unites'];
  var ST = ['Brouillon', 'Soumis', 'Vérifié', 'Visé', 'Émis', 'Remplacé'];
  var NORMES0 = [
    { id: 'BAEL91m99', nom: 'BAEL 91 modifié 99', edition: '1999', moteur: 'exb-etudes', note: 'Moteur de l’application (formules du classeur Metrec 2026), méthode simplifiée, ELU.', params: { 'γb (béton)': '1,5', 'γs (acier)': '1,15', 'Combinaison ELU': '1,35 G + 1,5 Q', 'Combinaison ELS': 'G + Q' } },
    { id: 'EC2', nom: 'Eurocode 2 — EN 1992-1-1', edition: '2004 (+A1:2014)', moteur: 'aucun', note: 'Référence documentaire : AUCUN moteur de calcul correspondant dans l’application.', params: { 'γc (béton, situation durable)': '1,5', 'γs (acier)': '1,15', 'Combinaison ELU': '1,35 G + 1,5 Q' } },
    { id: 'EC0', nom: 'Eurocode 0 — EN 1990 (bases de calcul)', edition: '2002 (+A1:2005)', moteur: 'aucun', note: 'Référence documentaire.', params: {} },
    { id: 'EC1', nom: 'Eurocode 1 — EN 1991 (actions)', edition: '2002–2006', moteur: 'aucun', note: 'Référence documentaire.', params: {} },
    { id: 'EC7', nom: 'Eurocode 7 — EN 1997-1 (géotechnique)', edition: '2004 (+A1:2013)', moteur: 'aucun', note: 'Référence documentaire.', params: {} },
    { id: 'LOCAL', nom: 'Référentiel local / autre (à préciser)', edition: 'à préciser', moteur: 'aucun', note: 'À décrire dans le dossier.', params: {} }
  ];
  var PARAM_NOTE = 'Valeurs de départ proposées : à confirmer par l’ingénieur pour chaque projet.';

  /* ------------------------------------------------------------ outils ------------------------------------------------------------ */
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid() { return 'DE-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function fdate(t) { try { return new Date(t).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return String(t || ''); } }
  function hash(s) { s = String(s); var h1 = 0xdeadbeef, h2 = 0x41c6ce57; for (var i = 0, c; i < s.length; i++) { c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); } h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909); h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909); return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16); }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function norm(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id), client: String(p.client_name || p.client || '') }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function infoDB() { try { return w.EXBDB && w.EXBDB.info ? w.EXBDB.info() : null; } catch (e) { return null; } }
  function act(a) { try { return w.EXBAction && w.EXBAction.can ? !!w.EXBAction.can(a) : true; } catch (e) { return true; } }
  /* viser / émettre : fonction « Ingénieur » (ou administrateur) quand une base partagée est active ; en mode local, aucune restriction de fonction */
  function habilite() { var i = infoDB(); if (!i || !i.on) return true; return i.role === 'admin' || i.fonction === 'bureau_etudes'; }
  function normes() {
    var a = rd(KN); if (!a.length) { a = NORMES0.map(function (n) { return JSON.parse(JSON.stringify(n)); }); wr(KN, a); }
    return a;
  }
  function notes() { return rd('exb_calc_notes'); }
  /* V210 : dalles et escaliers (exb-be-dalles.js) rattachés au dossier — contrôlés, empreints, visés et repris dans le rapport comme les notes de calcul */
  function elems(x) { try { return w.EXBBeDal && w.EXBBeDal.forDossier ? w.EXBBeDal.forDossier(x.id) : []; } catch (e) { return []; } }
  function enom(e) { return (e.type === 'escalier' ? 'Escalier ' : 'Dalle ') + (e.name || ''); }
  function noteHash(n) { try { return hash(JSON.stringify(n)); } catch (e) { return ''; } }
  function calcNote(n) { try { return w.EXBET && w.EXBET.calcNote ? w.EXBET.calcNote(n) : null; } catch (e) { return null; } }

  /* ------------------------------------------------------------ données ------------------------------------------------------------ */
  function all() { return rd(KD); }
  function get(id) { return all().filter(function (x) { return x.id === id; })[0] || null; }
  function put(x) { var a = all(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i >= 0) a[i] = x; else a.push(x); return wr(KD, a); }
  function numero() { var y = new Date().getFullYear(), n = all().filter(function (x) { return String(x.no || '').indexOf('ETU-' + y) === 0; }).length + 1; return 'ETU-' + y + '-' + String(n).padStart(3, '0'); }
  function nouveau() {
    return { id: uid(), no: numero(), rev: 0, statut: 'Brouillon', titre: '', project_id: '', client: '', batiment: '', localisation: '', mission: '', entree: '', livrables: [], responsable: '', echeance: '', norme: { id: '', edition: '' }, hypotheses: [], notes: [], empreintes: {}, histo: [], auteur: '', cree: Date.now() };
  }
  function log(x, action, par, motif) { x.histo.push({ t: Date.now(), action: action, par: par || '', motif: motif || '', statut: x.statut }); audit('be.' + action, x.no, { statut: x.statut, par: par || '', rev: x.rev }); }

  /* ------------------------------------------------------------ vérification indépendante ------------------------------------------------------------ */
  function verif(x) {
    var R = [], add = function (niv, code, msg) { R.push({ niv: niv, code: code, msg: msg }); };
    var N = normes().filter(function (n) { return n.id === x.norme.id; })[0];
    if (!x.titre.trim()) add('bloquant', 'DOS-1', 'Intitulé du dossier manquant.');
    if (!x.project_id) add('bloquant', 'DOS-2', 'Aucun projet rattaché au dossier.');
    if (!x.responsable.trim()) add('attention', 'DOS-3', 'Responsable de l’étude non renseigné.');
    if (!x.echeance) add('info', 'DOS-4', 'Aucune échéance globale fixée.');
    else if (x.echeance < today() && x.statut !== 'Émis' && x.statut !== 'Remplacé') add('attention', 'DOS-5', 'Échéance dépassée (' + x.echeance + ').');
    if (!x.entree.trim()) add('attention', 'DOS-6', 'Données d’entrée non décrites (levé, programme, rapport de sol, plans de référence).');
    if (!x.livrables.length) add('info', 'DOS-7', 'Aucun livrable listé.');
    if (!x.norme.id) add('bloquant', 'NOR-1', 'Norme non choisie : le choix de la norme ET de son édition doit être explicite.');
    else if (!N) add('bloquant', 'NOR-2', 'La norme choisie n’existe plus dans le référentiel.');
    else if (N.edition !== x.norme.edition) add('attention', 'NOR-3', 'L’édition de la norme a changé dans le référentiel (' + x.norme.edition + ' → ' + N.edition + ') : confirmer l’édition applicable.');
    var ns = x.notes.map(function (id) { return notes().filter(function (n) { return n.id === id; })[0]; });
    if (!x.notes.length && !elems(x).length) add('attention', 'CAL-1', 'Aucune note de calcul ni dalle/escalier liés : le dossier n’a pas de dimensionnement.');
    x.notes.forEach(function (id, i) { if (!ns[i]) add('bloquant', 'CAL-2', 'Note de calcul liée introuvable (' + id + ').'); });
    ns = ns.filter(Boolean);
    if (N && ns.length && N.moteur !== 'exb-etudes') add('bloquant', 'NOR-4', 'Les notes liées sont calculées avec le moteur BAEL 91 mod. 99 de l’application, mais le dossier cite « ' + N.nom + ' » : aucun moteur correspondant. Choisir BAEL 91 mod. 99 ou faire calculer ailleurs et le documenter.');
    var foot = false;
    ns.forEach(function (n) {
      if (n.project_id && x.project_id && n.project_id !== x.project_id) add('attention', 'CAL-3', 'La note ' + n.no + ' est rattachée à un autre projet.');
      (n.els || []).forEach(function (e) { if (e.type === 'foot') foot = true; });
      var res = calcNote(n);
      if (res) res.forEach(function (r) { r.warn.forEach(function (m) { add('attention', 'CAL-4', n.no + ' · ' + r.name + ' : ' + m); }); if (!r.rows.length) add('bloquant', 'CAL-5', n.no + ' · ' + r.name + ' : données incomplètes, aucun résultat.'); });
      if ((x.statut === 'Visé' || x.statut === 'Émis') && x.empreintes[n.id] && x.empreintes[n.id] !== noteHash(n)) add('bloquant', 'CAL-6', 'La note ' + n.no + ' a été MODIFIÉE depuis le visa : nouvelle révision nécessaire.');
    });
    elems(x).forEach(function (e) {
      w.EXBBeDal.controle(e).forEach(function (c) { add(c.niv, c.code, c.msg); });
      if (x.statut === 'Visé' || x.statut === 'Émis') {
        var em = x.empreintes[e.id];
        if (!em) add('bloquant', 'DAL-6', enom(e) + ' : élément non couvert par le visa (ajouté ou créé avant l’intégration au visa) : nouvelle révision nécessaire.');
        else if (em !== w.EXBBeDal.empreinte(e)) add('bloquant', 'DAL-6', enom(e) + ' a été MODIFIÉ depuis le visa : nouvelle révision nécessaire.');
      }
    });
    var H = x.hypotheses;
    REQ.forEach(function (c) { if (!H.some(function (h) { return h.cat === c; })) add('bloquant', 'HYP-1', 'Aucune hypothèse de la catégorie « ' + label(c) + ' ».'); });
    if (foot && !H.some(function (h) { return h.cat === 'sol'; })) add('bloquant', 'HYP-2', 'Des fondations sont calculées mais aucune hypothèse de sol (contrainte admissible, rapport géotechnique) n’est renseignée.');
    H.forEach(function (h, i) {
      var t = 'Hypothèse ' + (i + 1) + ' (' + label(h.cat) + ')';
      if (!String(h.desc || '').trim()) add('bloquant', 'HYP-3', t + ' : libellé vide.');
      if (!String(h.justif || '').trim()) add('bloquant', 'HYP-4', t + ' « ' + (h.desc || '') + ' » : justification manquante.');
      if (String(h.valeur || '').trim() && !isNaN(parseFloat(String(h.valeur).replace(',', '.'))) && !String(h.unite || '').trim()) add('attention', 'HYP-5', t + ' « ' + (h.desc || '') + ' » : valeur numérique sans unité.');
      if (!String(h.valeur || '').trim() && h.cat !== 'limites' && h.cat !== 'combinaisons') add('attention', 'HYP-6', t + ' « ' + (h.desc || '') + ' » : valeur vide.');
      var nd = norm(h.desc), v = parseFloat(String(h.valeur).replace(',', '.'));
      if (isFinite(v)) ns.forEach(function (n) {
        if (/fc ?28|resistance.*beton|beton.*mpa/.test(nd) && +n.fc && +n.fc !== v) add('attention', 'HYP-7', 'Hypothèse « ' + h.desc + ' » = ' + v + ' ≠ fc28 de la note ' + n.no + ' (' + n.fc + ' MPa).');
        if (/\bfe\b|limite elastique|acier.*mpa/.test(nd) && +n.fe && +n.fe !== v) add('attention', 'HYP-8', 'Hypothèse « ' + h.desc + ' » = ' + v + ' ≠ fe de la note ' + n.no + ' (' + n.fe + ' MPa).');
      });
    });
    return R;
  }
  function label(c) { var f = CATS.filter(function (z) { return z[0] === c; })[0]; return f ? f[1] : c; }
  function bloquants(x) { return verif(x).filter(function (r) { return r.niv === 'bloquant'; }); }

  /* ------------------------------------------------------------ circuit de visa ------------------------------------------------------------ */
  function signataire() {
    var last = ''; try { last = w.localStorage.getItem('exb_be_signataire') || ''; } catch (e) {}
    return Promise.resolve(ask('Votre nom complet (mention nominative portée au dossier) :', last)).then(function (n) { n = String(n || '').trim(); if (n) { try { w.localStorage.setItem('exb_be_signataire', n); } catch (e) {} } return n; });
  }
  function motif(msg) { return Promise.resolve(ask(msg, '')).then(function (m) { return String(m || '').trim(); }); }
  var CUR = null, TAB = 'general', VIEW = 'liste';
  function ro(x) { return x.statut !== 'Brouillon'; }
  function refuse(m) { toast(m, 'warn'); }
  function sauve(x) { put(x); }
  function transition(kind) {
    var x = get(CUR); if (!x) return;
    if (kind === 'soumettre') {
      if (x.statut !== 'Brouillon') return;
      if (!act('soumettre')) return refuse('Votre profil n’a pas le droit « soumettre ».');
      var b = bloquants(x); if (b.length) { TAB = 'controles'; paint(); return refuse(b.length + ' point(s) bloquant(s) : corrigez-les avant de soumettre.'); }
      signataire().then(function (n) { if (!n) return; x.auteur = n; x.statut = 'Soumis'; x.soumis = { par: n, t: Date.now() }; log(x, 'soumis', n); sauve(x); paint(); });
    } else if (kind === 'verifier' || kind === 'rejeter') {
      if (x.statut !== 'Soumis') return;
      if (!act('approuver')) return refuse('Votre profil n’a pas le droit « approuver ».');
      signataire().then(function (n) {
        if (!n) return;
        if (norm(n) === norm(x.auteur)) return refuse('Le vérificateur doit être une autre personne que l’auteur (' + x.auteur + ').');
        if (kind === 'rejeter') return motif('Motif du rejet (obligatoire) :').then(function (m) { if (!m) return refuse('Un rejet doit être motivé.'); x.statut = 'Brouillon'; x.rejet = { par: n, t: Date.now(), motif: m }; log(x, 'rejete', n, m); sauve(x); paint(); });
        motif('Commentaire de vérification (obligatoire : ce qui a été contrôlé) :').then(function (m) { if (!m) return refuse('Précisez ce qui a été vérifié.'); x.statut = 'Vérifié'; x.verif = { par: n, t: Date.now(), commentaire: m }; log(x, 'verifie', n, m); sauve(x); paint(); });
      });
    } else if (kind === 'viser') {
      if (x.statut !== 'Vérifié') return;
      if (!act('approuver')) return refuse('Votre profil n’a pas le droit « approuver ».');
      if (!habilite()) return refuse('Le visa est réservé à un ingénieur habilité (fonction « Ingénieur ») ou à l’administrateur.');
      var b2 = bloquants(x); if (b2.length) { TAB = 'controles'; paint(); return refuse(b2.length + ' point(s) bloquant(s) : le visa est impossible.'); }
      signataire().then(function (n) {
        if (!n) return;
        if (norm(n) === norm(x.auteur)) return refuse('Le visa ne peut pas être donné par l’auteur du dossier.');
        motif('Observations du visa (peut être « sans observation ») :').then(function (m) {
          if (!m) return refuse('Saisissez « sans observation » ou vos observations.');
          x.empreintes = {}; notes().forEach(function (nt) { if (x.notes.indexOf(nt.id) >= 0) x.empreintes[nt.id] = noteHash(nt); }); elems(x).forEach(function (e) { x.empreintes[e.id] = w.EXBBeDal.empreinte(e); });
          x.statut = 'Visé'; x.vise = { par: n, t: Date.now(), observations: m }; log(x, 'vise', n, m); sauve(x); paint();
        });
      });
    } else if (kind === 'emettre') {
      if (x.statut !== 'Visé') return;
      if (!act('approuver')) return refuse('Votre profil n’a pas le droit « approuver ».');
      if (!habilite()) return refuse('L’émission est réservée à un ingénieur habilité ou à l’administrateur.');
      var b3 = bloquants(x); if (b3.length) { TAB = 'controles'; paint(); return refuse('Émission impossible : ' + b3.length + ' point(s) bloquant(s).'); }
      signataire().then(function (n) { if (!n) return; x.statut = 'Émis'; x.emis = { par: n, t: Date.now() }; log(x, 'emis', n); sauve(x); rapport(x.id); paint(); });
    } else if (kind === 'revision') {
      if (x.statut !== 'Émis') return;
      signataire().then(function (n) {
        if (!n) return;
        motif('Motif de la nouvelle révision (obligatoire) :').then(function (m) {
          if (!m) return refuse('Précisez le motif de la révision.');
          var y = JSON.parse(JSON.stringify(x)); y.id = uid(); y.rev = x.rev + 1; y.statut = 'Brouillon'; y.histo = []; y.soumis = y.verif = y.vise = y.emis = y.rejet = null; y.empreintes = {}; y.precedent = x.id; y.auteur = '';
          log(y, 'revision', n, 'Révision ' + y.rev + ' de ' + x.no + ' : ' + m);
          x.statut = 'Remplacé'; log(x, 'remplace', n, m); sauve(x); put(y); try { if (w.EXBBeDal && w.EXBBeDal.cloneFor) w.EXBBeDal.cloneFor(x.id, y.id); } catch (e) {} CUR = y.id; TAB = 'general'; paint();
        });
      });
    }
  }

  /* ------------------------------------------------------------ rapport technique ------------------------------------------------------------ */
  function rapport(id) {
    var x = get(id); if (!x) return; if (!w.EXBPdf) return refuse('Module PDF indisponible.');
    var N = normes().filter(function (n) { return n.id === x.norme.id; })[0] || { nom: x.norme.id || '—', params: {} };
    var san = function (t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/γ/g, 'gamma ').replace(/→/g, '->'); };
    var who = function (o) { return o ? o.par + ' — ' + fdate(o.t) : '— (non signé)'; };
    var r = [['Dossier', x.no + ' — révision ' + x.rev + ' — ' + x.titre], ['Projet / client', pnom(x.project_id) + (x.client ? ' — ' + x.client : '')], ['Bâtiment / localisation', [x.batiment, x.localisation].filter(Boolean).join(' — ') || '—'], ['Mission', x.mission || '—'],
      ['Responsable / échéance', (x.responsable || '—') + ' — ' + (x.echeance || '—')], ['Données d’entrée', x.entree || '—'],
      ['Norme et édition', N.nom + ' — édition ' + (x.norme.edition || '—') + (Object.keys(N.params || {}).length ? '\n' + Object.keys(N.params).map(function (k) { return k + ' = ' + N.params[k]; }).join(' ; ') : '')]];
    r.push(['Hypothèses de calcul', x.hypotheses.map(function (h, i) { return (i + 1) + '. [' + label(h.cat) + '] ' + h.desc + ' = ' + (h.valeur || '—') + ' ' + (h.unite || '') + ' — justification : ' + (h.justif || '—'); }).join('\n') || '—']);
    var lim = [];
    x.notes.forEach(function (nid) {
      var n = notes().filter(function (z) { return z.id === nid; })[0]; if (!n) return;
      var res = calcNote(n);
      r.push(['Note de calcul ' + n.no, n.title + ' (fc28 ' + n.fc + ' MPa ; fe ' + n.fe + ' MPa ; enrobage ' + n.enr + ' cm)' + (res ? '\n' + res.map(function (e) { return '• ' + e.name + ' : ' + (e.rows.length ? e.rows.map(function (z) { return z[0] + ' : ' + z[1]; }).join(' | ') : 'données incomplètes'); }).join('\n') : '')]);
      if (res) res.forEach(function (e) { e.warn.forEach(function (m) { lim.push(n.no + ' · ' + e.name + ' : ' + m); }); });
    });
    elems(x).forEach(function (e) {
      var c = w.EXBBeDal.calc(e), j = String(e.justif || '').trim();
      r.push([enom(e) + ' (×' + (e.nb || 1) + ')', 'fc28 ' + e.p.fc + ' MPa ; fe ' + e.p.fe + ' MPa ; enrobage ' + e.p.enr + ' cm\n' + (c.rows.length ? c.rows.map(function (z) { return '• ' + z[0] + ' : ' + z[1]; }).join('\n') : 'données incomplètes') + (c.block.length ? '\nPoints non conformes : ' + c.block.join(' | ') + '\nJustification de l’ingénieur : ' + (j || '— (aucune)') : '')]);
      c.warn.forEach(function (m) { lim.push(enom(e) + ' : ' + m); });
    });
    var v = verif(x);
    r.push(['Contrôles automatiques', v.length ? v.map(function (c) { return '[' + c.niv + '] ' + c.msg; }).join('\n') : 'Aucune alerte.']);
    r.push(['Livrables', x.livrables.map(function (l) { return l.nom + (l.echeance ? ' (' + l.echeance + ')' : '') + (l.fait ? ' — fait' : ''); }).join('\n') || '—']);
    r.push(['Établi / soumis par', who(x.soumis)]); r.push(['Vérifié par', who(x.verif) + (x.verif ? '\n' + x.verif.commentaire : '')]); r.push(['Visé par', who(x.vise) + (x.vise ? '\n' + x.vise.observations : '')]); r.push(['Émis par', who(x.emis)]);
    r.push(['Empreintes des notes (traçabilité)', Object.keys(x.empreintes).map(function (k) { var n = notes().filter(function (z) { return z.id === k; })[0]; var el = elems(x).filter(function (z) { return z.id === k; })[0]; return (n ? n.no : (el ? enom(el) : k)) + ' : ' + x.empreintes[k]; }).join('\n') || '—']);
    r = r.map(function (z) { return [san(z[0]), san(z[1])]; });
    var notesPdf = lim.map(function (m) { return san('Attention — ' + m); }).concat([
      'Limites : calculs issus de formules déterministes documentées (aucune IA générative) ; méthode simplifiée ; points non calculés listés élément par élément (arrêts de barres exacts, torsion des poutres palières, dalles non rectangulaires, armatures de coin, chevêtres) à compléter par l’ingénieur.',
      'Les mentions de vérification, de visa et d’émission sont nominatives mais ne constituent pas une signature électronique qualifiée.', 'Document valable pour la révision ' + x.rev + ' uniquement ; toute modification des hypothèses ou des notes impose une nouvelle révision.'].map(san));
    return w.EXBPdf.make({ titre: 'RAPPORT TECHNIQUE ' + x.no, sousTitre: san(x.titre) + ' — ' + san(pnom(x.project_id)), rows: r, notes: notesPdf, footer: 'Rapport technique ' + x.no + ' rév. ' + x.rev + ' — Excellencia Building', no: x.no, version: 'Rév. ' + x.rev, statut: x.statut, projet: pnom(x.project_id) })
      .then(function (b) { if (w.EXBPdf.save) w.EXBPdf.save(b, 'RAPPORT-' + x.no + '-REV' + x.rev + '.pdf'); }, function () { refuse('Échec de la génération du PDF.'); });
  }

  /* ------------------------------------------------------------ écran ------------------------------------------------------------ */
  var BT = 'border:1px solid #cbd5e1;background:#fff;border-radius:8px;padding:6px 10px;cursor:pointer;font:13px Arial', IN = 'border:1px solid #cbd5e1;border-radius:8px;padding:6px 8px;font:13px Arial;box-sizing:border-box';
  var BADGE = { Brouillon: '#6b7280', Soumis: '#1d4ed8', 'Vérifié': '#a16207', 'Visé': '#15803d', 'Émis': '#0f766e', 'Remplacé': '#9ca3af' };
  function badge(s) { return '<span style="background:' + (BADGE[s] || '#6b7280') + ';color:#fff;border-radius:10px;padding:2px 8px;font-size:11px">' + esc(s) + '</span>'; }
  function box() { return d.querySelector('#exbBeD > div'); }
  function fld(label, html, w2) { return '<div style="flex:1 1 ' + (w2 || 220) + 'px"><label style="display:block;font-size:12px;color:#475569">' + label + '</label>' + html + '</div>'; }
  function inp(x, f, ph, type) { return '<input ' + (type ? 'type="' + type + '" ' : '') + (ro(x) ? 'disabled ' : '') + 'value="' + esc(x[f]) + '" placeholder="' + esc(ph || '') + '" style="' + IN + ';width:100%" oninput="EXBBeD._f(\'' + f + '\',this.value)">'; }
  function paint() {
    var c = box(); if (!c) return;
    var h = '<div style="display:flex;justify-content:space-between;align-items:center;gap:6px"><h3 style="margin:0">🏗️ Dossiers d’étude — bureau d’études</h3><button style="' + BT + '" onclick="document.getElementById(\'exbBeD\').remove()">✕ Fermer</button></div>';
    var x = CUR ? get(CUR) : null;
    if (!x) {
      var L = all().slice().reverse();
      h += '<p style="font-size:12px;color:#64748b;margin:6px 0">Cadre de gouvernance des études : norme, hypothèses justifiées, contrôles, visa à deux personnes, rapport. Les calculs restent dans « Notes de calcul » ; aucune validation automatique.</p><p><button style="' + BT + ';background:#1d4ed8;color:#fff" onclick="EXBBeD._new()">➕ Nouveau dossier d’étude</button> <button style="' + BT + '" onclick="EXBBeD._normes()">📚 Référentiel normatif</button></p>';
      h += '<table style="border-collapse:collapse;font-size:12px;width:100%"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:5px">N°</th><th style="padding:5px">Titre</th><th style="padding:5px">Projet</th><th style="padding:5px">Norme</th><th style="padding:5px">Rév.</th><th style="padding:5px">Statut</th><th style="padding:5px">Échéance</th></tr></thead><tbody>'
        + (L.map(function (z) { return '<tr style="border-top:1px solid #e5e7eb;cursor:pointer" onclick="EXBBeD._open(\'' + z.id + '\')"><td style="padding:5px">' + esc(z.no) + '</td><td style="padding:5px">' + esc(z.titre || '(sans titre)') + '</td><td style="padding:5px">' + esc(pnom(z.project_id)) + '</td><td style="padding:5px">' + esc(z.norme.id ? z.norme.id + ' · ' + z.norme.edition : '—') + '</td><td style="padding:5px">' + z.rev + '</td><td style="padding:5px">' + badge(z.statut) + '</td><td style="padding:5px">' + esc(z.echeance || '—') + '</td></tr>'; }).join('') || '<tr><td colspan="7" style="padding:14px;color:#64748b">Aucun dossier d’étude.</td></tr>') + '</tbody></table>';
      if (VIEW === 'normes') h = normesHtml();
      c.innerHTML = h; return;
    }
    var tabs = [['general', 'Général'], ['norme', 'Norme'], ['hyp', 'Hypothèses (' + x.hypotheses.length + ')'], ['notes', 'Notes de calcul (' + (x.notes.length + elems(x).length) + ')'], ['controles', 'Contrôles'], ['visa', 'Visa'], ['rapport', 'Rapport']];
    var nv = verif(x), nb = nv.filter(function (r) { return r.niv === 'bloquant'; }).length;
    h += '<div style="margin:6px 0"><button style="' + BT + '" onclick="EXBBeD._back()">← Dossiers</button> <b>' + esc(x.no) + '</b> rév. ' + x.rev + ' ' + badge(x.statut) + (ro(x) ? ' <span style="font-size:12px;color:#b45309">🔒 verrouillé (' + (x.statut === 'Émis' ? 'utilisez « Nouvelle révision »' : 'seul le brouillon est modifiable') + ')</span>' : '') + '</div>';
    h += '<div style="display:flex;gap:4px;flex-wrap:wrap;margin:8px 0">' + tabs.map(function (t) { return '<button style="' + BT + (TAB === t[0] ? ';background:#1e3a6b;color:#fff' : '') + '" onclick="EXBBeD._tab(\'' + t[0] + '\')">' + t[1] + (t[0] === 'controles' && nb ? ' ⛔' + nb : '') + '</button>'; }).join('') + '</div>';
    h += ({ general: tGen, norme: tNorme, hyp: tHyp, notes: tNotes, controles: tCtl, visa: tVisa, rapport: tRap })[TAB](x);
    c.innerHTML = h;
  }
  function tGen(x) {
    var P = projets(), ps = '<select ' + (ro(x) ? 'disabled ' : '') + 'style="' + IN + ';width:100%" onchange="EXBBeD._f(\'project_id\',this.value)"><option value="">—</option>' + P.map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === x.project_id ? ' selected' : '') + '>' + esc(p.nom) + '</option>'; }).join('') + '</select>';
    return '<div style="display:flex;gap:8px;flex-wrap:wrap">' + fld('Intitulé *', inp(x, 'titre')) + fld('Projet *', ps) + fld('Client', inp(x, 'client')) + fld('Bâtiment / ouvrage', inp(x, 'batiment')) + fld('Localisation', inp(x, 'localisation')) + fld('Responsable de l’étude', inp(x, 'responsable')) + fld('Échéance', inp(x, 'echeance', '', 'date'), 160) + '</div>'
      + fld('Mission', '<textarea ' + (ro(x) ? 'disabled ' : '') + 'rows="2" style="' + IN + ';width:100%" oninput="EXBBeD._f(\'mission\',this.value)">' + esc(x.mission) + '</textarea>', 300)
      + fld('Données d’entrée (levé, programme, rapport de sol, plans de référence…)', '<textarea ' + (ro(x) ? 'disabled ' : '') + 'rows="3" style="' + IN + ';width:100%" oninput="EXBBeD._f(\'entree\',this.value)">' + esc(x.entree) + '</textarea>', 300)
      + '<h4 style="margin:10px 0 4px">Livrables</h4>' + x.livrables.map(function (l, i) { return '<div style="display:flex;gap:6px;margin:3px 0;align-items:center"><input ' + (ro(x) ? 'disabled ' : '') + 'value="' + esc(l.nom) + '" style="' + IN + ';flex:1" oninput="EXBBeD._l(' + i + ',\'nom\',this.value)"><input type="date" ' + (ro(x) ? 'disabled ' : '') + 'value="' + esc(l.echeance) + '" style="' + IN + '" oninput="EXBBeD._l(' + i + ',\'echeance\',this.value)"><label style="font-size:12px"><input type="checkbox" ' + (l.fait ? 'checked ' : '') + (ro(x) ? 'disabled ' : '') + 'onchange="EXBBeD._l(' + i + ',\'fait\',this.checked)"> fait</label>' + (ro(x) ? '' : '<button style="' + BT + '" onclick="EXBBeD._ldel(' + i + ')">×</button>') + '</div>'; }).join('') + (ro(x) ? '' : '<button style="' + BT + '" onclick="EXBBeD._ladd()">➕ Livrable</button>');
  }
  function tNorme(x) {
    var Ns = normes(), N = Ns.filter(function (n) { return n.id === x.norme.id; })[0];
    return '<p style="font-size:12px;color:#64748b">Choisissez explicitement la norme et son édition : il n’y a pas de choix par défaut.</p><div style="display:flex;gap:8px;flex-wrap:wrap">' + fld('Norme', '<select ' + (ro(x) ? 'disabled ' : '') + 'style="' + IN + ';width:100%" onchange="EXBBeD._norme(this.value)"><option value="">— choisir —</option>' + Ns.map(function (n) { return '<option value="' + esc(n.id) + '"' + (n.id === x.norme.id ? ' selected' : '') + '>' + esc(n.nom) + '</option>'; }).join('') + '</select>') + fld('Édition', '<input disabled value="' + esc(x.norme.edition) + '" style="' + IN + ';width:100%">', 160) + '</div>'
      + (N ? '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin:8px 0;font-size:13px"><b>' + esc(N.nom) + '</b> — moteur de calcul : <b style="color:' + (N.moteur === 'exb-etudes' ? '#15803d' : '#b45309') + '">' + (N.moteur === 'exb-etudes' ? 'disponible (notes de calcul)' : 'aucun dans l’application') + '</b><br>' + esc(N.note || '') + '<br>' + (Object.keys(N.params || {}).map(function (k) { return esc(k) + ' = ' + esc(N.params[k]); }).join(' · ') || '') + '</div>' : '');
  }
  function tHyp(x) {
    var h = (ro(x) ? '' : '<p style="margin:4px 0"><button style="' + BT + '" onclick="EXBBeD._hmodel()">📋 Insérer la liste type à compléter</button> <button style="' + BT + '" onclick="EXBBeD._hadd()">➕ Hypothèse</button></p>');
    h += '<div style="overflow:auto"><table style="border-collapse:collapse;font-size:12px;width:100%;min-width:640px"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:4px">Catégorie</th><th style="padding:4px">Libellé</th><th style="padding:4px">Valeur</th><th style="padding:4px">Unité</th><th style="padding:4px">Justification *</th><th></th></tr></thead><tbody>'
      + (x.hypotheses.map(function (z, i) {
        var dis = ro(x) ? 'disabled ' : '', i2 = function (f, wd) { return '<input ' + dis + 'value="' + esc(z[f]) + '" style="' + IN + ';width:' + wd + '" oninput="EXBBeD._h(' + i + ',\'' + f + '\',this.value)">'; };
        return '<tr style="border-top:1px solid #e5e7eb"><td style="padding:3px"><select ' + dis + 'style="' + IN + '" onchange="EXBBeD._h(' + i + ',\'cat\',this.value)">' + CATS.map(function (c) { return '<option value="' + c[0] + '"' + (c[0] === z.cat ? ' selected' : '') + '>' + c[1] + '</option>'; }).join('') + '</select></td><td style="padding:3px">' + i2('desc', '150px') + '</td><td style="padding:3px">' + i2('valeur', '80px') + '</td><td style="padding:3px">' + i2('unite', '60px') + '</td><td style="padding:3px">' + i2('justif', '210px') + '</td><td>' + (ro(x) ? '' : '<button style="' + BT + '" onclick="EXBBeD._hdel(' + i + ')">×</button>') + '</td></tr>';
      }).join('') || '<tr><td colspan="6" style="padding:10px;color:#64748b">Aucune hypothèse. Catégories obligatoires : matériaux, charges, combinaisons, conditions aux limites, unités (+ sol si fondations).</td></tr>') + '</tbody></table></div>';
    return h;
  }
  function tNotes(x) {
    var N = notes().filter(function (n) { return !x.project_id || !n.project_id || n.project_id === x.project_id; });
    return '<p style="font-size:12px;color:#64748b">Liez les notes de calcul (module « Notes de calcul ») qui composent cette étude. Leur contenu est empreint au moment du visa.</p>'
      + (N.map(function (n) { var on = x.notes.indexOf(n.id) >= 0, res = calcNote(n), nw = res ? res.reduce(function (a, r) { return a + r.warn.length; }, 0) : 0; return '<label style="display:block;border:1px solid #e5e7eb;border-radius:8px;padding:6px 8px;margin:4px 0;font-size:13px"><input type="checkbox" ' + (on ? 'checked ' : '') + (ro(x) ? 'disabled ' : '') + 'onchange="EXBBeD._note(\'' + esc(n.id) + '\',this.checked)"> <b>' + esc(n.no) + '</b> — ' + esc(n.title) + ' <span style="color:#64748b">· ' + (n.els || []).length + ' élément(s) · fc28 ' + esc(n.fc) + ' · fe ' + esc(n.fe) + (nw ? ' · <span style="color:#b45309">' + nw + ' alerte(s)</span>' : '') + '</span></label>'; }).join('') || '<p style="color:#64748b">Aucune note de calcul pour ce projet.</p>')
      + '<h4 style="margin:12px 0 4px">Dalles et escaliers du dossier</h4>' + (elems(x).map(function (e) { var cl = w.EXBBeDal.controle(e), nb = cl.filter(function (c) { return c.niv === 'bloquant'; }).length; return '<div style="display:flex;justify-content:space-between;gap:6px;border:1px solid #e5e7eb;border-radius:8px;padding:6px 8px;margin:4px 0;font-size:13px"><span><b>' + esc(enom(e)) + '</b> <span style="color:#64748b">· ×' + esc(e.nb || 1) + ' · ' + (nb ? '<span style="color:#b91c1c">' + nb + ' point(s) bloquant(s)</span>' : 'sans point bloquant') + '</span></span><button style="' + BT + '" onclick="EXBBeDal.open(\'' + esc(x.id) + '\')">Ouvrir</button></div>'; }).join('') || '<p style="color:#64748b;font-size:13px">Aucun élément. Ajoutez-les avec « 🧱 Dalles et escaliers » (ELU, ELS, fissuration, flèche) : ils sont alors contrôlés, empreints au visa et repris dans le rapport.</p>')
      + '<p style="font-size:12px;color:#b45309;margin-top:8px">Moteurs disponibles : descente de charges, poteaux, semelles isolées, poutres, dalles pleines et escaliers (BAEL 91 mod. 99). Fondations spéciales : pas de moteur dans l’application — les justifier hors application et le consigner dans les hypothèses.</p>';
  }
  function tCtl(x) {
    var v = verif(x), col = { bloquant: '#b91c1c', attention: '#b45309', info: '#475569' }, ic = { bloquant: '⛔', attention: '⚠', info: 'ℹ' };
    return '<p style="font-size:12px;color:#64748b">Contrôles déterministes : ils alertent mais ne valident jamais. Seule la vérification et le visa de personnes le font. ⛔ bloque la soumission, le visa et l’émission.</p>'
      + (v.length ? v.map(function (r) { return '<div style="border-left:4px solid ' + col[r.niv] + ';background:#f8fafc;padding:5px 8px;margin:4px 0;font-size:13px"><b style="color:' + col[r.niv] + '">' + ic[r.niv] + ' ' + esc(r.code) + '</b> ' + esc(r.msg) + '</div>'; }).join('') : '<p style="color:#15803d">✅ Aucune alerte automatique. Cela ne remplace pas la vérification par une autre personne.</p>');
  }
  function tVisa(x) {
    var s = x.statut, B = function (k, t, ok) { return ok ? '<button style="' + BT + ';background:#1e3a6b;color:#fff" onclick="EXBBeD._go(\'' + k + '\')">' + t + '</button> ' : ''; };
    var h = '<div style="margin:6px 0">' + B('soumettre', '📤 Soumettre à vérification', s === 'Brouillon') + B('verifier', '🔎 Marquer « vérifié »', s === 'Soumis') + B('rejeter', '↩ Rejeter (motivé)', s === 'Soumis') + B('viser', '✍ Viser', s === 'Vérifié') + B('emettre', '📨 Émettre (rapport PDF)', s === 'Visé') + B('revision', '🔁 Nouvelle révision', s === 'Émis') + '</div>';
    h += '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;font-size:13px">'
      + [['Soumis par', x.soumis && x.soumis.par + ' — ' + fdate(x.soumis.t)], ['Vérifié par', x.verif && x.verif.par + ' — ' + fdate(x.verif.t) + ' — ' + x.verif.commentaire], ['Visé par', x.vise && x.vise.par + ' — ' + fdate(x.vise.t) + ' — ' + x.vise.observations], ['Émis par', x.emis && x.emis.par + ' — ' + fdate(x.emis.t)], ['Dernier rejet', x.rejet && x.rejet.par + ' — ' + fdate(x.rejet.t) + ' — ' + x.rejet.motif]].map(function (z) { return z[0] + ' : ' + (z[1] ? esc(z[1]) : '—'); }).join('<br>') + '</div>';
    h += '<h4 style="margin:10px 0 4px">Historique</h4>' + (x.histo.slice().reverse().map(function (e) { return '<div style="font-size:12px;border-top:1px solid #e5e7eb;padding:3px 0">' + esc(fdate(e.t)) + ' · <b>' + esc(e.action) + '</b> · ' + esc(e.par) + (e.motif ? ' · ' + esc(e.motif) : '') + '</div>'; }).join('') || '<p style="font-size:12px;color:#64748b">Aucun événement.</p>');
    return h + '<p style="font-size:11px;color:#64748b;margin-top:8px">Règles : vérificateur et viseur ≠ auteur ; visa et émission réservés à la fonction Ingénieur (ou administrateur) et au droit « approuver ». Mentions nominatives, pas de signature électronique qualifiée.</p>';
  }
  function tRap(x) { return '<p style="font-size:13px">Le rapport technique reprend : dossier, norme et édition, hypothèses justifiées, résultats des notes, contrôles, limites, vérification / visa / émission et empreintes des notes.</p><p><button style="' + BT + '" onclick="EXBBeD.rapport(\'' + x.id + '\')">📄 Générer le rapport PDF</button></p>' + (x.statut !== 'Émis' ? '<p style="font-size:12px;color:#b45309">Dossier non émis : le rapport est un document de travail (statut « ' + esc(x.statut) + ' » inscrit en pied de page).</p>' : ''); }
  function normesHtml() {
    var Ns = normes(), h = '<div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">📚 Référentiel normatif</h3><button style="' + BT + '" onclick="EXBBeD._back()">← Retour</button></div><p style="font-size:12px;color:#64748b">' + esc(PARAM_NOTE) + ' Toute modification est conservée dans l’historique des versions (📚 Versions).</p>';
    return h + Ns.map(function (n, i) {
      return '<div style="border:1px solid #e5e7eb;border-radius:10px;padding:8px;margin:6px 0"><div style="display:flex;gap:6px;flex-wrap:wrap"><input value="' + esc(n.nom) + '" style="' + IN + ';flex:2 1 220px" oninput="EXBBeD._n(' + i + ',\'nom\',this.value)"><input value="' + esc(n.edition) + '" style="' + IN + ';flex:1 1 120px" oninput="EXBBeD._n(' + i + ',\'edition\',this.value)"></div><div style="font-size:12px;margin-top:4px">Moteur : <b>' + (n.moteur === 'exb-etudes' ? 'oui' : 'aucun') + '</b> · ' + esc(n.note || '') + '</div><div style="font-size:12px">' + (Object.keys(n.params || {}).map(function (k) { return '<label style="margin-right:8px">' + esc(k) + ' <input value="' + esc(n.params[k]) + '" style="' + IN + ';width:90px" oninput="EXBBeD._np(' + i + ',\'' + esc(k).replace(/'/g, "\\'") + '\',this.value)"></label>'; }).join('') || '') + '</div></div>';
    }).join('') + '<p><button style="' + BT + '" onclick="EXBBeD._nadd()">➕ Ajouter une norme / un référentiel</button></p>';
  }

  function ouvrir(id) { VIEW = 'liste'; CUR = id || null; TAB = 'general'; var o = d.getElementById('exbBeD'); if (o) o.remove(); o = d.createElement('div'); o.id = 'exbBeD'; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto'; o.onclick = function (e) { if (e.target === o) o.remove(); }; var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;padding:16px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o); paint(); }
  function edit(fn) { var x = get(CUR); if (!x || ro(x)) return null; fn(x); put(x); return x; }
  function ui() {
    var b = d.getElementById('exbComBtnS') || d.getElementById('exbComBtnD') || d.getElementById('exbAuBtn'); if (!b || d.getElementById('exbBeBtn')) return;
    var k = d.createElement('button'); k.id = 'exbBeBtn'; k.setAttribute('data-exb-cat', 'ing'); k.setAttribute('data-exb-desc', 'Norme, hypothèses justifiées, contrôles, visa et rapport technique'); k.className = b.className; k.textContent = '🏗️ Dossiers d’étude'; k.onclick = function () { ouvrir(); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'beDossier', name: 'Dossier d’étude (bureau d’études)', version: '1.0.0', area: 'Technique', deps: ['calcul', 'projets'], collections: [KD, KN] }); } catch (e) {}

  w.EXBBeD = {
    open: ouvrir, verif: verif, rapport: rapport, normes: normes, get: get, all: all, nouveau: nouveau, put: put, hash: noteHash,
    _new: function () { var x = nouveau(); x.histo.push({ t: Date.now(), action: 'cree', par: '', motif: '', statut: 'Brouillon' }); put(x); CUR = x.id; TAB = 'general'; paint(); },
    _open: function (id) { CUR = id; TAB = 'general'; paint(); }, _back: function () { CUR = null; VIEW = 'liste'; paint(); }, _tab: function (t) { TAB = t; paint(); }, _normes: function () { VIEW = 'normes'; CUR = null; var c = box(); if (c) c.innerHTML = normesHtml(); },
    _f: function (f, v) { edit(function (x) { x[f] = v; if (f === 'project_id') { var p = projets().filter(function (z) { return z.id === v; })[0]; if (p && !x.client) x.client = p.client; } }); if (f === 'project_id') paint(); },
    _l: function (i, f, v) { edit(function (x) { x.livrables[i][f] = v; }); }, _ladd: function () { edit(function (x) { x.livrables.push({ nom: '', echeance: '', fait: false }); }); paint(); }, _ldel: function (i) { edit(function (x) { x.livrables.splice(i, 1); }); paint(); },
    _norme: function (id) { edit(function (x) { var n = normes().filter(function (z) { return z.id === id; })[0]; x.norme = n ? { id: n.id, edition: n.edition } : { id: '', edition: '' }; }); paint(); },
    _h: function (i, f, v) { edit(function (x) { x.hypotheses[i][f] = v; }); if (f === 'cat') paint(); }, _hadd: function () { edit(function (x) { x.hypotheses.push({ cat: 'materiaux', desc: '', valeur: '', unite: '', justif: '' }); }); paint(); }, _hdel: function (i) { edit(function (x) { x.hypotheses.splice(i, 1); }); paint(); },
    _hmodel: function () { edit(function (x) { [['materiaux', 'Résistance du béton fc28', 'MPa'], ['materiaux', 'Limite élastique de l’acier fe', 'MPa'], ['charges', 'Charges permanentes G', 'kN/m²'], ['charges', 'Charges d’exploitation Q', 'kN/m²'], ['combinaisons', 'Combinaison ELU', ''], ['sol', 'Contrainte admissible du sol', 'MPa'], ['limites', 'Conditions d’appui / liaisons', ''], ['unites', 'Système d’unités', '']].forEach(function (m) { x.hypotheses.push({ cat: m[0], desc: m[1], valeur: '', unite: m[2], justif: '' }); }); }); paint(); },
    _note: function (id, on) { edit(function (x) { var i = x.notes.indexOf(id); if (on && i < 0) x.notes.push(id); if (!on && i >= 0) x.notes.splice(i, 1); }); },
    _go: transition,
    _n: function (i, f, v) { var a = normes(); a[i][f] = v; wr(KN, a); }, _np: function (i, k, v) { var a = normes(); a[i].params[k] = v; wr(KN, a); }, _nadd: function () { var a = normes(); a.push({ id: 'N' + Date.now().toString(36), nom: 'Nouvelle norme', edition: '', moteur: 'aucun', note: '', params: {} }); wr(KN, a); VIEW = 'normes'; var c = box(); if (c) c.innerHTML = normesHtml(); }
  };
})(window, document);
