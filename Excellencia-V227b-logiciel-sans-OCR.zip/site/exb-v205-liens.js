/* Excellencia Building V205a — LIENS apprenant : paiement → caisse → reçu → statut.
 * - Après « Enregistrer le paiement » : ajoute formation_id au paiement, inscrit la recette en caisse (case cochée par défaut, jamais en double),
 *   et propose « Établir le reçu » (participant, montant et statut préremplis ; le reçu enregistré est relié au paiement).
 * - Aucune donnée existante n'est modifiée ou supprimée ; tout est ajouté. */
(function (w, d) {
  'use strict';
  function $(i) { return d.getElementById(i); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function G(name) { try { return (0, eval)('typeof ' + name + "!=='undefined'?" + name + ':null'); } catch (e) { return null; } }
  function list(name) { var v = G(name); return Array.isArray(v) ? v : []; }
  function price(trainingName, fid) {
    var f = list('formations').filter(function (x) { return (fid && x.formation_id === fid) || x.name === trainingName; })[0];
    return Number(f && f.price) || 0;
  }
  function paid(pid) { return list('payments').filter(function (x) { return x.participant_id === pid; }).reduce(function (a, x) { return a + (Number(x.amount) || 0); }, 0); }
  function persist(key, arr) { try { if (typeof w.save === 'function') return w.save(key, arr); } catch (e) {} }
  var pending = null;

  function afterPayment(y, cashOn) {
    var f = list('formations').filter(function (x) { return x.name === y.training; })[0];
    if (f && f.formation_id && !y.formation_id) y.formation_id = f.formation_id;
    var cashDone = false;
    try {
      var cash = G('exbCash');
      if (cashOn && Array.isArray(cash) && typeof w.exbSave === 'function' && !cash.some(function (x) { return x.payment_id === y.payment_id; })) {
        var id = (typeof w.exbId === 'function') ? w.exbId('CASH') : 'CASH-' + Date.now().toString(36);
        cash.push({ id: id, date: y.date, type: 'in', label: 'Formation — ' + (y.participant_name || y.participant_id) + (y.training ? ' (' + y.training + ')' : ''),
          amount: y.amount, method: y.method, ref: y.reference, category: 'Formation', payment_id: y.payment_id, participant_id: y.participant_id, source: 'paiement_formation' });
        var keys = G('EXB_ECO_KEYS');
        w.exbSave(keys && keys.cash || 'exb_cash', cash);
        y.cash_id = id; cashDone = true;
        try { if (typeof w.renderExbCash === 'function') w.renderExbCash(); } catch (e) {}
      }
    } catch (e) {}
    persist('exb_payments', list('payments'));
    var m = $('pay_msg');
    if (m) m.innerHTML = '<span class="valid">✓ Paiement enregistré' + (cashDone ? ' et inscrit en caisse' : '') + '.</span> <button type="button" onclick="EXB205.makeReceipt(\'' + esc(y.payment_id) + '\')">🧾 Établir le reçu</button>';
  }

  function installPayment() {
    if (typeof w.savePayment !== 'function' || w.savePayment.__v205) return false;
    var orig = w.savePayment;
    var g = function () {
      var P = list('payments'), before = P.length, top = P[0], cb = $('pay_cash'), cashOn = !cb || cb.checked;
      var r = orig.apply(this, arguments);
      try { var y = list('payments')[0]; if (list('payments').length > before && y && y !== top) afterPayment(y, cashOn); } catch (e) {}
      return r;
    };
    g.__v205 = 1; w.savePayment = g; return true;
  }
  function installReceipt() {
    if (typeof w.saveReceipt !== 'function' || w.saveReceipt.__v205) return false;
    var orig = w.saveReceipt;
    var g = function () {
      var R = list('receipts'), before = R.length;
      var r = orig.apply(this, arguments);
      try {
        var RR = list('receipts');
        if (pending && RR.length > before) {
          var rc = RR[RR.length - 1], Y = list('payments').filter(function (x) { return x.payment_id === pending.payment_id; })[0];
          if (Y && (rc.participant === pending.name || rc.participant_id === pending.participant_id)) {
            rc.payment_id = Y.payment_id; rc.participant_id = Y.participant_id; if (Y.formation_id) rc.formation_id = Y.formation_id;
            Y.receipt_no = rc.receipt_no;
            persist('exb_receipts', RR); persist('exb_payments', list('payments'));
            pending = null;
          }
        }
      } catch (e) {}
      return r;
    };
    g.__v205 = 1; w.saveReceipt = g; return true;
  }

  function makeReceipt(paymentId) {
    var y = list('payments').filter(function (x) { return x.payment_id === paymentId; })[0];
    var p = y && list('participants').filter(function (x) { return x.participant_id === y.participant_id; })[0];
    if (!y || !p) { try { w.notify('Paiement ou participant introuvable.', 'warn'); } catch (e) {} return; }
    pending = { payment_id: y.payment_id, participant_id: p.participant_id, name: p.name };
    try { w.show('receipts'); } catch (e) {}
    setTimeout(function () {
      try { if (typeof w.fillReceiptPicker === 'function') w.fillReceiptPicker(); } catch (e) {}
      var sel = $('receiptParticipantSelect');
      if (sel) { sel.value = p.participant_id; sel.dispatchEvent(new Event('change')); }
      var tf = $('training_fee'); if (tf) tf.value = (Number(y.amount) || 0).toFixed(2);
      var pr = price(p.training, p.formation_id), pd = paid(p.participant_id), st = $('training_status');
      if (st && pr > 0) { if (pd >= pr) st.value = 'PAYÉ'; else if (pd >= pr / 2) st.value = 'MOITIÉ PAYÉE'; }
      try { if (typeof w.renderReceipt === 'function' && typeof w.receiptData === 'function') w.renderReceipt(w.receiptData()); } catch (e) {}
      try { w.notify('Reçu prérempli : vérifiez puis enregistrez.', 'info'); } catch (e) {}
    }, 300);
  }

  w.EXB205 = { makeReceipt: makeReceipt, afterPayment: afterPayment };
  function boot() { installPayment(); installReceipt(); }
  /* Prospects des anciens CRM (V67, V92) → pipeline CRM : import automatique, une seule fois par prospect, sans recréer un prospect supprimé */
  function syncProspects() { try { if (w.EXBCRMPLUS && w.EXBCRMPLUS._t && w.EXBCRMPLUS._t.importProspects) w.EXBCRMPLUS._t.importProspects(); } catch (e) {} }
  w.addEventListener('load', function () { setTimeout(syncProspects, 4000); });
  boot(); d.addEventListener('DOMContentLoaded', boot); w.addEventListener('load', function () { boot(); setTimeout(boot, 1500); });
})(window, document);
