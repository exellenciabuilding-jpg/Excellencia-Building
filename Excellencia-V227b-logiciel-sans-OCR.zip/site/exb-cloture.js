/* Excellencia Building V163 — Dossier de clôture d'un projet (module 02, Project Manager).
 * Moteur PUR (analyse, clôture, réouverture) : aucune lecture de l'écran ni du stockage, testable seul (tools/test-cloture.js).
 * Lecture seule des autres modules (planning, budget, bons de commande, factures, caisse) : RH et Stock ne sont PAS touchés.
 * Données propres : exb_clotures (une fiche par clôture, historique de réouverture conservé). Retrait : supprimer la balise <script src="exb-cloture.js">. */
(function(root){'use strict';
var N=function(x){x=+x;return isFinite(x)?x:0},r2=function(x){return Math.round(N(x)*100)/100};
var cur=function(c){c=String(c||'USD').toUpperCase();return /^(FC|CDF)$/.test(c)?'CDF':c};
var cancelled=function(i){return !!(i&&(i.annule||i.cancel||/annul/i.test(i.status||'')))};
var invTot=function(i){var ht=(i.lines||[]).reduce(function(a,l){return a+N(l.q)*N(l.pu)},0);return r2(ht*(1+N(i.tva)/100))};
var paid=function(o){return (o.payments||[]).reduce(function(a,p){return a+N(p.amount)},0)};
var sid=function(x){return String(x==null?'':x)};

/* Analyse d'un projet : contrôles de clôture + bilan chiffré.
 * src = { project, gantt:{tasks,jalons,date}, budget:{postes}, po:[], invoices:[], cash:[], today:'AAAA-MM-JJ' } */
function analyse(src,opt){
  src=src||{};opt=opt||{};var p=src.project||{},pid=sid(p.id),C=[],B={};
  var add=function(id,etat,lib,det){C.push({id:id,etat:etat,libelle:lib,detail:det||''})};
  /* planning */
  var g=src.gantt,E=root.EXBCPM||opt.cpm;
  if(!g||!(g.tasks||[]).length){add('taches','alerte','Planning','Aucun planning pour ce projet : l\'avancement n\'est pas vérifiable.');B.taches=null}
  else{var tk=g.tasks,fin=tk.filter(function(t){return N(t.pct)>=100}).length,rest=tk.length-fin;B.taches={total:tk.length,finies:fin};
    add('taches',rest?'bloquant':'ok','Tâches du planning',rest?rest+' tâche(s) sur '+tk.length+' non terminée(s).':'Toutes les tâches ('+tk.length+') sont terminées.');
    var js=g.jalons||[];
    if(js.length&&E&&E.jalons){var cw=E.semaine?E.semaine(g.date,src.today):0,R=E.jalons(tk,js,cw),ok=R.filter(function(j){return j.statut==='atteint'}).length;B.jalons={total:js.length,atteints:ok};
      add('jalons',ok<js.length?'alerte':'ok','Jalons',ok<js.length?(js.length-ok)+' jalon(s) sur '+js.length+' non atteint(s).':'Tous les jalons ('+js.length+') sont atteints.')}
    else B.jalons=null}
  /* bons de commande (USD ; FC signalés, non convertis) */
  var bc={nb:0,commande:0,recu:0,paye:0,reste:0,aPayer:0,horsUsd:0,nonSoldes:0};
  (src.po||[]).forEach(function(o){if(!o||o.cancel||sid(o.project_id)!==pid)return;if(cur(o.currency)!=='USD'){bc.horsUsd++;return}
    var tot=0,rec=0;(o.lines||[]).forEach(function(l){tot+=N(l.q)*N(l.pu);rec+=Math.min(N(l.rec),N(l.q))*N(l.pu)});
    var py=paid(o);bc.nb++;bc.commande+=tot;bc.recu+=rec;bc.paye+=py;if(tot-rec>0.004||tot-py>0.004)bc.nonSoldes++});
  ['commande','recu','paye'].forEach(function(k){bc[k]=r2(bc[k])});bc.reste=r2(bc.commande-bc.recu);bc.aPayer=r2(bc.commande-bc.paye);B.bc=bc;
  if(bc.nb)add('bc',bc.nonSoldes?'bloquant':'ok','Bons de commande',bc.nonSoldes?bc.nonSoldes+' bon(s) non soldé(s) : '+bc.reste+' $ à recevoir, '+(bc.aPayer>0?bc.aPayer:0)+' $ à payer.':'Tous les bons de commande ('+bc.nb+') sont reçus et payés.');
  if(bc.horsUsd)add('bc_fc','alerte','Bons de commande hors USD',bc.horsUsd+' bon(s) en FC non vérifié(s) (pas de conversion).');
  /* factures clients */
  var fa={nb:0,total:0,encaisse:0,solde:0,horsUsd:0,impayees:0};
  (src.invoices||[]).forEach(function(i){if(!i||cancelled(i)||sid(i.project_id)!==pid)return;if(cur(i.currency)!=='USD'){fa.horsUsd++;return}
    var t=invTot(i),py=paid(i),s=t-py;fa.nb++;fa.total+=t;fa.encaisse+=py;if(s>0.004){fa.solde+=s;fa.impayees++}});
  ['total','encaisse','solde'].forEach(function(k){fa[k]=r2(fa[k])});B.factures=fa;
  if(fa.nb)add('factures',fa.impayees?'bloquant':'ok','Factures du projet',fa.impayees?fa.impayees+' facture(s) non soldée(s) : '+fa.solde+' $ à encaisser.':'Toutes les factures ('+fa.nb+') sont soldées.');
  if(fa.horsUsd)add('factures_fc','alerte','Factures hors USD',fa.horsUsd+' facture(s) en FC non vérifiée(s) (pas de conversion).');
  /* budget */
  var b=src.budget,bud=null;
  if(b&&(b.postes||[]).length){var pb=0,pr=0,dep=0;b.postes.forEach(function(x){pb+=N(x.b);pr+=N(x.r);if(N(x.b)>0&&N(x.r)>N(x.b))dep++});
    bud={budget:r2(pb),reel:r2(pr),ecart:r2(pr-pb),postesDepasses:dep};
    add('budget',(bud.ecart>0.004||dep)?'alerte':'ok','Budget de construction',bud.ecart>0.004?'Dépassement global de '+bud.ecart+' $.':(dep?dep+' poste(s) dépassent leur budget (global respecté).':'Coût réel dans le budget ('+bud.reel+' $ sur '+bud.budget+' $).'))}
  else add('budget','alerte','Budget de construction','Aucun budget saisi : le bilan financier est incomplet.');
  B.budget=bud;
  var out=0;(src.cash||[]).forEach(function(c){if(c&&c.type==='out'&&sid(c.project_id)===pid)out+=N(c.amount)});B.caisse=r2(out);
  if(bud&&B.caisse>bud.reel+0.005)add('caisse','alerte','Dépenses de caisse','Caisse imputée ('+B.caisse+' $) supérieure au coût réel saisi ('+bud.reel+' $) : '+r2(B.caisse-bud.reel)+' $ non affectés à un poste.');
  /* pointages non reportés vers les RH (alerte : information seulement) */
  var RO=root.EXBRO;if(RO&&src.timesheets){var ap=RO.apercuPointages(src.timesheets,src.hr||[],src.presences||[],pid);B.pointages=ap.compte;
    if(ap.compte.a_reporter||ap.compte.sans_fiche)add('pointages','alerte','Pointages et RH',ap.compte.a_reporter+' pointage(s) à reporter vers les RH'+(ap.compte.sans_fiche?', '+ap.compte.sans_fiche+' sans fiche Personnel':'')+'.')}
  B.avancement=N(p.progress);B.projet={id:pid,nom:p.name||'',budget:N(p.budget)};
  var bl=C.filter(function(x){return x.etat==='bloquant'}),al=C.filter(function(x){return x.etat==='alerte'});
  return {controles:C,bloquants:bl.length,alertes:al.length,pret:bl.length===0,bilan:B}}

/* État de clôture d'un projet : la dernière fiche non rouverte. */
function etat(list,pid){var f=(list||[]).filter(function(c){return sid(c.project_id)===sid(pid)&&!c.rouvert});return f.length?f[f.length-1]:null}

/* Clôture : refusée si des points bloquants subsistent sans motif de clôture forcée. */
function cloturer(list,pid,an,o){o=o||{};list=(list||[]).slice();
  if(!pid)return{ok:false,error:'Choisissez un projet.'};
  if(etat(list,pid))return{ok:false,error:'Ce projet est déjà clôturé.'};
  var forced=an.bloquants>0,motif=String(o.motif||'').trim();
  if(forced&&!motif)return{ok:false,error:an.bloquants+' point(s) bloquant(s) : un motif est obligatoire pour clôturer quand même.'};
  var rec={id:o.id||('CL'+(o.now||Date.now())),project_id:sid(pid),date:String(o.now||new Date().toISOString()).slice(0,10),par:String(o.par||''),forcee:forced,motif:forced?motif.slice(0,300):'',notes:String(o.notes||'').slice(0,2000),
    bloquants:an.controles.filter(function(x){return x.etat==='bloquant'}).map(function(x){return x.libelle+' — '+x.detail}),bilan:JSON.parse(JSON.stringify(an.bilan)),controles:an.controles.length};
  list.push(rec);return{ok:true,list:list,rec:rec}}

/* Réouverture : motif obligatoire ; la fiche est conservée (historique), marquée rouverte. */
function rouvrir(list,pid,motif,o){o=o||{};list=JSON.parse(JSON.stringify(list||[]));var f=etat(list,pid);
  if(!f)return{ok:false,error:'Ce projet n\'est pas clôturé.'};
  if(!String(motif||'').trim())return{ok:false,error:'Un motif est obligatoire pour rouvrir un projet.'};
  var t=list.filter(function(c){return c.id===f.id})[0];t.rouvert={date:String(o.now||new Date().toISOString()).slice(0,10),par:String(o.par||''),motif:String(motif).trim().slice(0,300)};
  return{ok:true,list:list}}

var API={analyse:analyse,etat:etat,cloturer:cloturer,rouvrir:rouvrir};
root.EXBCL=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;

/* ===================== ÉCRAN (navigateur seulement) ===================== */
if(typeof document==='undefined')return;
var K='exb_clotures',ST={pid:'',motif:'',notes:''};
var esc=function(v){return String(v==null?'':v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
var fx=function(x){return Number(x||0).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2}).replace(/[\u202f\u00a0]/g,' ')};
var L=function(k){try{return load(k,[])}catch(e){return[]}};
var say=function(t,k){try{notify(t,k||'info',4500)}catch(e){try{exbAlert(t)}catch(_){}}};
var today=function(){return new Date().toISOString().slice(0,10)};
var who=function(){try{return (window.exbUser&&(exbUser.name||exbUser.nom))||''}catch(e){return ''}};
function source(pid){var P=(typeof exbProjects!=='undefined'?exbProjects:[]).filter(function(x){return sid(x.id)===sid(pid)})[0];
  var f=function(k){return L(k).filter(function(x){return sid(x.project_id)===sid(pid)})[0]};
  return{project:P,gantt:f('exb_gantt'),budget:f('exb_budgets'),po:L('exb_purchase_orders'),invoices:L('exb_invoices'),cash:L('exb_cash'),timesheets:L('exb_timesheets'),hr:(typeof exbHr!=='undefined'?exbHr:[]),presences:L('exb_hr_presences'),today:today()}}
var ICO={ok:'✅',bloquant:'⛔',alerte:'⚠️'};
function view(pid){ST.pid=pid;if(!pid)return '<p class="exb-muted">Choisissez un chantier pour préparer son dossier de clôture.</p>';
  var S=source(pid);if(!S.project)return '<p class="exb-muted">Projet introuvable.</p>';
  var an=analyse(S),B=an.bilan,cl=etat(L(K),pid),h='';
  if(cl)h+='<div class="exb-card" style="border-left:4px solid #15803d"><b>🏁 Projet clôturé le '+esc(cl.date.split('-').reverse().join('/'))+'</b>'+(cl.par?' par '+esc(cl.par):'')+(cl.forcee?'<br><span style="color:#b91c1c">Clôture forcée : '+esc(cl.motif)+'</span>':'')+(cl.notes?'<br><small>'+esc(cl.notes)+'</small>':'')+'</div>';
  h+='<h3 style="margin:10px 0 6px">Contrôles de clôture</h3><ul style="list-style:none;padding:0;margin:0">'+an.controles.map(function(c){return '<li style="margin:4px 0">'+ICO[c.etat]+' <b>'+esc(c.libelle)+'</b> — '+esc(c.detail)+'</li>'}).join('')+'</ul>';
  h+='<p class="'+(an.pret?'':'exb-muted')+'" style="margin:8px 0;color:'+(an.pret?'#15803d':'#b91c1c')+'">'+(an.pret?'Aucun point bloquant : le projet peut être clôturé.':'⛔ '+an.bloquants+' point(s) bloquant(s) : réglez-les, ou clôturez avec un motif.')+(an.alertes?' ('+an.alertes+' alerte(s) à vérifier)':'')+'</p>';
  var cards=[['Avancement',fx(B.avancement)+' %'],['Budget',B.budget?fx(B.budget.budget)+' $':'—'],['Coût réel',B.budget?fx(B.budget.reel)+' $':'—'],['Écart',B.budget?(B.budget.ecart>0?'+':'')+fx(B.budget.ecart)+' $':'—'],['Commandé',fx(B.bc.commande)+' $'],['Encaissé',fx(B.factures.encaisse)+' $']];
  h+='<div class="exb-grid">'+cards.map(function(c){return '<div class="exb-card"><b style="font-size:16px">'+c[1]+'</b><br><small>'+c[0]+'</small></div>'}).join('')+'</div>';
  if(!cl){h+='<label>Bilan et leçons retenues (facultatif)</label><textarea rows="3" style="width:100%" onchange="EXBCL.f(\'notes\',this.value)">'+esc(ST.notes)+'</textarea>';
    if(!an.pret)h+='<label>Motif de clôture forcée (obligatoire : des points bloquent)</label><input style="width:100%" value="'+esc(ST.motif)+'" onchange="EXBCL.f(\'motif\',this.value)">'}
  h+='<div class="exb-actions" style="margin-top:8px">'+(cl?'<button class="muted" onclick="EXBCL.rouvrir()">↩ Rouvrir le projet</button>':'<button class="primary" onclick="EXBCL.cloturer()">🏁 Clôturer le projet</button>')+'<button class="muted" onclick="EXBCL.pdf()">📄 Dossier de clôture (PDF)</button></div>';
  h+='<p class="exb-muted">Lecture seule des autres modules : la clôture ne modifie ni le planning, ni le budget, ni les RH, ni le Stock. Elle conserve une photo du bilan à la date de clôture.</p>';return h}
function rerender(){try{EXBPL.tab('c')}catch(e){}}
var A={view:view,f:function(k,v){ST[k]=v},
 cloturer:async function(){var S=source(ST.pid),an=analyse(S);if(!(await exbConfirm(an.pret?'Clôturer ce projet ?':'Clôturer malgré '+an.bloquants+' point(s) bloquant(s) ?')))return;
  var r=cloturer(L(K),ST.pid,an,{motif:ST.motif,notes:ST.notes,par:who(),now:new Date().toISOString(),id:(typeof exbId==='function'?exbId('CL'):null)});if(!r.ok)return say(r.error,'warn');
  save(K,r.list);S.project.cloture_le=r.rec.date;try{exbSave(EXB_ECO_KEYS.projects,exbProjects)}catch(e){}ST.motif='';ST.notes='';say('Projet clôturé.','success');rerender()},
 rouvrir:async function(){var m=await exbPrompt('Motif de la réouverture :','');if(m===null)return;var r=rouvrir(L(K),ST.pid,m,{par:who(),now:new Date().toISOString()});if(!r.ok)return say(r.error,'warn');
  save(K,r.list);var P=source(ST.pid).project;if(P){delete P.cloture_le;try{exbSave(EXB_ECO_KEYS.projects,exbProjects)}catch(e){}}say('Projet rouvert.','success');rerender()},
 pdf:function(){var S=source(ST.pid),an=analyse(S),B=an.bilan,cl=etat(L(K),ST.pid),n=S.project.name||'',d=function(s){return s.split('-').reverse().join('/')};
  var rows=[['Projet',n],['Statut',cl?'Clôturé le '+d(cl.date)+(cl.forcee?' (forcée)':''):'Non clôturé — état au '+d(today())],['Avancement',fx(B.avancement)+' %']];
  if(B.taches)rows.push(['Tâches',B.taches.finies+' / '+B.taches.total+' terminées']);if(B.jalons)rows.push(['Jalons',B.jalons.atteints+' / '+B.jalons.total+' atteints']);
  if(B.budget)rows.push(['Budget / réel / écart',fx(B.budget.budget)+' $ / '+fx(B.budget.reel)+' $ / '+(B.budget.ecart>0?'+':'')+fx(B.budget.ecart)+' $']);
  rows.push(['Bons de commande',B.bc.nb+' : '+fx(B.bc.commande)+' $ commandés, '+fx(B.bc.recu)+' $ reçus, '+fx(B.bc.paye)+' $ payés']);rows.push(['Factures',B.factures.nb+' : '+fx(B.factures.total)+' $ facturés, '+fx(B.factures.encaisse)+' $ encaissés, '+fx(B.factures.solde)+' $ à encaisser']);
  an.controles.forEach(function(c){rows.push([(c.etat==='ok'?'OK':c.etat==='bloquant'?'BLOQUANT':'ALERTE')+' — '+c.libelle,c.detail])});
  if(cl&&cl.motif)rows.push(['Motif de clôture forcée',cl.motif]);if(cl&&cl.notes)rows.push(['Bilan et leçons retenues',cl.notes]);
  EXBPdf.make({titre:'DOSSIER DE CLÔTURE',sousTitre:n+' — édité le '+d(today()),rows:rows,notes:['Les montants en FC ne sont pas convertis : ils sont signalés mais non comptés.'],footer:'Clôture — '+n+' — Excellencia Building'}).then(function(x){EXBPdf.save(x,'dossier-cloture.pdf')})}};
root.EXBCL=Object.assign(API,A);
})(typeof window!=='undefined'?window:globalThis);
