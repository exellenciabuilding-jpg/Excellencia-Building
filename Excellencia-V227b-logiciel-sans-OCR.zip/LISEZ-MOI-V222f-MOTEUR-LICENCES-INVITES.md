# V222f — Moteur de licences connecté sur l'appareil administrateur (abonnement des invités)

## Problème
Les personnes invitées pouvaient voir « abonnement expiré » : l'abonnement de l'entreprise est signé par le serveur de licences et déposé sur Supabase depuis l'appareil administrateur (panneau Équipe). Dans cette version, **rien ne permettait de connecter l'appareil au moteur de licences** (le bouton « 🔑 Licences » n'est pas dans le zip) : l'abonnement n'était donc jamais enregistré ni renouvelé, sans aucun message.

## Correctif
- `exb-license.js` : connexion au moteur (adresse + clé d'administration) avec une fenêtre dédiée, option « Rester connecté sur cet appareil ». Réservé à l'édition propriétaire (retiré de l'édition client par `strip-owner.js`).
- `exb-equipe.js` : encadré rouge + bouton **« 🔑 Connecter le moteur de licences »** dans l'onglet Équipe, quand l'abonnement doit être (re)déposé. Dès la connexion, l'abonnement (400 jours) est créé et enregistré ; renouvelé tous les 30 jours à l'ouverture d'Équipe. Les erreurs du serveur sont affichées au lieu d'être avalées.
- Message plus clair côté invité si l'abonnement de l'entreprise est périmé.
- `sw.js` : cache `v222f-…` (fermer complètement l'application une fois).

## À faire une fois
Équipe › « Connecter le moteur de licences » › adresse du serveur + clé d'administration (fichier ADMIN-KEY-LICENCES.txt, la même que dans le générateur).

## Tests
`node scripts/test-equipe-licence.js` · `node scripts/test-licence.js` · `node site/tools/check.js`

## Fusion avec la V222e « partie 1 sur 2 » (équipe / licence)
Repris de la V222e : V221a (bandeau « Réseau coupé » désactivé, `exb-com-sync.js`), V221b (écran administrateur sans « Première connexion », `exb-v205-connexion-espace.js`), V221c (3 essais d'invitation + message clair, `exb-license.js`, `migration-v221c-invitation-abonnement-valide.sql`), V221d (message de suspension précis, `exb-equipe.js`, `migration-v221d-recharger-schema.sql`), correctif `migration-v210f-suspension-membres.sql`.
Conservé de la V221+V222e complète (plus récent) : affiches Word / éditeur Word (V222 « toute l'affiche », textes d'aide), PDF des modules (électricité, plomberie, environnement…), BCF/IDS, filigrane.
Pour la connexion au moteur de licences, la fenêtre V222f remplace le bouton V222e (même but ; la clé peut rester sur l'appareil).
SQL à exécuter dans Supabase (SQL Editor) : migration-v221c puis migration-v221d (et v210f si la suspension affiche une erreur).

## V222g — Vérification du statut au moins tous les 7 jours (`exb-acces-membre.js`)
Un membre qui n'a pas pu confirmer son statut auprès du serveur depuis plus de 7 jours (ou dont l'horloge a été reculée de plus de 2 jours) voit « Vérification requise » : il se connecte à internet et le logiciel se déverrouille tout seul dès que le serveur répond « actif ». Un membre suspendu en ligne reste bloqué en 30 s au plus. Le compte à rebours démarre à la première ouverture après la mise à jour : personne n'est bloqué par surprise.
