# V219 — Filigrane au choix sur les modèles de certificat 1 à 5

## Constat
Les fonds « RDC » et « Excellencia Building » portaient un filigrane. Les modèles 1 à 5 (images) le masquaient et n'offraient aucun choix : ni logo en filigrane, ni texte personnalisé.

## Correctif
Nouveau module `site/exb-certificat-filigrane.js`. Sous la liste « Modèle / fond du certificat » (certificat individuel **et** impression groupée), un réglage **Filigrane du certificat** apparaît dès qu'un modèle 1 à 5 est choisi :
- **Aucun filigrane** (par défaut : le rendu d'origine ne change pas) ;
- **Logo Excellencia Building** (logo enregistré dans Paramètres, sinon logo de la marque du client) ;
- **Filigrane RDC** (celui du fond RDC, sinon le logo RDC enregistré) ;
- **Texte personnalisé** : texte libre, jusqu'à 4 lignes (un retour à la ligne = une ligne), posé en diagonale au centre ;
- **Intensité** de 4 à 30 %.
Le réglage est mémorisé et s'applique à l'aperçu, à l'export PDF et à l'impression groupée. Le filigrane est placé au-dessus du fond du modèle et sous le texte, la photo, le cachet, le QR et les signatures. Pour les fonds RDC / Excellencia / blanc, le réglage est masqué (ils gardent leur filigrane habituel).

## Fichiers
`site/exb-certificat-filigrane.js` (nouveau) · `site/exb-v206c-certificats-images.js` et `site/exb-v206b-certificat-modele-5.js` (1 ligne chacun) · `site/index.html` (1 balise) · `site/sw.js` (cache v219) · `site/tools/check.js` (+7) · `site/tools/e2e-certificat-filigrane.py` (nouveau).
Déploiement : copier ces fichiers, redéployer, fermer complètement l'application une fois (cache v219).
Retrait : supprimer la balise `exb-certificat-filigrane.js` (retour sans filigrane).

## Vérifications
`check.js` : 916 contrôles, 0 échec. `e2e-certificat-filigrane.py` (Chromium, application réelle) : 52 vérifications, 0 échec : pour chacun des 5 modèles, aucun filigrane par défaut, logo Excellencia, filigrane RDC, texte sur 2 lignes avec intensité, ordre d'empilement, réglage mémorisé et partagé avec l'impression groupée, masqué sur les anciens fonds. `e2e-certificat-logos.py` (V218) toujours sans échec.

## À savoir
- Le réglage est commun à tous les certificats (il n'est pas enregistré dans chaque certificat déjà émis : un certificat rouvert reprend le réglage actuel).
- Pour un logo en filigrane, préférer un PNG à fond transparent.
