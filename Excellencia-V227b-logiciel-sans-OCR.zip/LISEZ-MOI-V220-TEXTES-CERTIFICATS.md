# V220 — Textes personnalisés sur les modèles de certificat 1 à 5

## Constat
Sur les modèles 1 à 5 (images), plusieurs textes étaient dessinés dans le fond : nom « Excellencia Building » sous le titre, logo + slogan en haut à gauche, cachet, phrase « Le Directeur général d'Excellencia Building certifie que : » et devise du pied de page (modèle 5). Ils ne suivaient donc pas l'identité de l'entreprise, contrairement aux fonds précédents (RDC, Excellencia Building, blanc) qui reprennent le nom, le slogan et le Directeur général.

## Correctif
Nouveau module `site/exb-certificat-textes.js`. Quand l'entreprise n'est plus « Excellencia Building » (Paramètres › Identité, ou `entreprise.json`), il recouvre chaque texte dessiné par une pièce du fond d'origine (texte effacé, décor conservé) et écrit celui de l'entreprise :
- **nom de l'entreprise** sous le titre (modèles 1 à 5) ;
- **bloc logo** (nom + slogan) en haut à gauche, tant qu'aucun logo n'est enregistré (un logo enregistré garde la priorité, comme en V218) ;
- **cachet** redessiné : nom et slogan en arc, logo enregistré au centre (sinon petit immeuble) ;
- **modèle 5** : « Le Directeur général de … certifie que : » et devise du pied de page = slogan de l'entreprise ;
- **modèles 1 à 4** : le nom du Directeur général s'écrit sous « LE DIRECTEUR » (le modèle 5 le faisait déjà).
Tant que l'entreprise est « Excellencia Building », le rendu d'origine ne change pas. Valable pour l'aperçu, l'export PDF et l'impression groupée.

## Fichiers
`site/exb-certificat-textes.js` (nouveau) · `site/exb-v206c-certificats-images.js` et `site/exb-v206b-certificat-modele-5.js` (1 ligne chacun) · `site/index.html` (1 balise) · `site/sw.js` (cache v220) · `site/tools/check.js` · `site/tools/e2e-certificat-textes.py` (nouveau).
Déploiement : copier ces fichiers, redéployer, fermer complètement l'application une fois (cache v220).
Retrait : supprimer la balise `exb-certificat-textes.js` (retour aux textes dessinés).

## Vérifications
`check.js` sans échec. `e2e-certificat-textes.py` (Chrome, application réelle) : 44 vérifications, 0 échec. `e2e-certificat-logos.py` (18) et `e2e-certificat-filigrane.py` (52) toujours sans échec.

## À savoir
- « République Démocratique du Congo », « CERTIFICAT DE FORMATION », « Unité · Travail · Progrès » et les étiquettes « LE RÉCIPIENDAIRE / LE DIRECTEUR » restent fixes, comme sur les fonds existants.
- Sans logo enregistré, une autre entreprise voit un bloc texte (nom + slogan) à la place du logo Excellencia dessiné.
