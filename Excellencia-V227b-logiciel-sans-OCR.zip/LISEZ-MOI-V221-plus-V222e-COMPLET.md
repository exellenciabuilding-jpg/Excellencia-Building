# V221 + V222e (complet) — sauf équipe / licence

Base : V221. On y applique **tout le reste de la V222e** (V221a à V221l, V222, V222b, V222c, V222e), à l'exception de l'équipe / licence, laissée telle quelle sur demande.

## Appliqué
- **PDF des modules d'ingénierie** (V221f–h) : Électricité, Plomberie/HVAC, Topographie, VRD, Études P2 / Géotechnique, Maintenance, Environnement, Pilotage : en-tête « pièce écrite », QR de vérification, pagination ; PDF enregistré (V221i). `exb-v221-entete-modules.js`, `exb-pdf.js`, `exb-elec/plomb/topo/vrd/be-p2/maint/env/pilote/jur.js`.
- **Écrans en page** (V221h) : modules Architecture & ingénierie affichés dans la zone de contenu : `exb-v221-pages-modules.js`.
- **Rapports sans popup**, **page de garde au choix**, **QR en bas**, **double en-tête corrigé** (V221i–l) : `exb-v221-rapport-fenetre.js`, `exb-v221-garde-rapports.js`, `docengine/bridge.js`, `exb-rapport-marque.js`, rapports Architecture (programme, contrôle réglementaire, analyse de site, matériaux, coordination, IDS).
- **Menu** (shell) : boutons Architecture classés dans l'onglet Architecture (`exb-v99r-shell.js`).
- **BCF à deux éléments** + **règles IDS approfondies** (V222) : `exb-bcf.js`, `exb-v209-ids.js`.
- **Filigrane des certificats selon les logos** (V222b) : `exb-certificat-filigrane.js`, `exb-certificat-logos.js`.
- **OCR** (V222c) : `sw.js` préchargement à la demande ; `site/vendor/tesseract/` déjà présent.
- **Affiches Word** (V222e) : déjà dans la V221 fournie (inchangé).
- `sw.js` : cache `v221l-…`, `package.json`, tests et `check.js`.

## NON touché (demande : équipe / licence)
`exb-equipe.js`, `exb-license.js`, `exb-com-sync.js`, `exb-v205-connexion-espace.js` (dépôt propriétaire d'invitation des membres, identiques à la V221), `supabase/migration-v210f-suspension-membres.sql`, et non ajoutés : `migration-v221c-invitation-abonnement-valide.sql`, `migration-v221d-recharger-schema.sql` (avertissement rouge d'abonnement d'équipe, 3 essais d'invitation, bandeau « Réseau coupé » désactivé).

## Toujours absent
Générateur de licences (`owner-app/`, `licence-server/`, `owner-licences/`) : dans aucune archive reçue.

## Vérifications
`check.js` 987 réussis / 0 échec · test-affiches 12/12 · test-coordination 36/36 · test-bcf 30/30 · test-regles-ids 33/33 · coordination-3d 10/10 · analyse-site 28/28 · matériaux 19/19 · IA architecte 9/9 · programme 15/15 · contrôle réglementaire 16/16.
Après déploiement : fermer complètement l'application une fois (nouveau cache).
