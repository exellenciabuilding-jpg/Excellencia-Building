/* V222f — test : l'administrateur voit l'avertissement « abonnement expiré » seulement quand c'est réellement le cas,
 * et le bouton « Connecter le moteur de licences » enregistre bien l'abonnement des invités.
 * Usage : node scripts/test-equipe-licence.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const { clientLicense } = require('./strip-owner.js');
const ROOT = path.join(__dirname, '..', 'site');
const LIC = fs.readFileSync(path.join(ROOT, 'exb-license.js'), 'utf8');
const EQ = fs.readFileSync(path.join(ROOT, 'exb-equipe.js'), 'utf8');
let fail = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) fail++; };
const mk = o => ({ getItem: k => (k in o ? o[k] : null), setItem: (k, v) => { o[k] = String(v); }, removeItem: k => { delete o[k]; } });
const wait = ms => new Promise(r => setTimeout(r, ms));

function boot(opts) {
  const local = Object.assign({}, opts.local || {}), ses = Object.assign({}, opts.session || {});
  const calls = { fetch: [], rpc: [] };
  const equipe = { style: { display: '' }, innerHTML: '', querySelectorAll: () => [] };
  const dummy = () => ({ style: {}, value: '', onclick: null, onchange: null, disabled: false, remove() {}, setAttribute() {}, getAttribute() { return null; }, appendChild() {}, insertAdjacentHTML() {}, textContent: '' });
  const doc = {
    hidden: false, body: { appendChild() {} }, addEventListener() {}, readyState: 'complete', createElement: dummy,
    getElementById: id => id === 'equipe' ? equipe : (id === 'eq_lic' ? (equipe.innerHTML.includes('id="eq_lic"') ? dummy() : null) : dummy())
  };
  const w = {
    crypto: globalThis.crypto, localStorage: mk(local), sessionStorage: mk(ses), document: doc, TextEncoder, TextDecoder, atob, btoa, Uint8Array, JSON, Math, console,
    EXB_LICENSE_CONFIG: { requireToken: true, server: 'https://x.supabase.co/functions/v1/licence', defaultGrace: 7 },
    navigator: { onLine: true, platform: 'Test' }, location: { hash: '', search: '', pathname: '/', reload() {} }, history: { replaceState() {} },
    setInterval: () => 0, setTimeout: () => 0, addEventListener() {}, alert() {}, exbAlert() {},
    fetch: async (url, o) => { calls.fetch.push({ url, key: o && o.headers && o.headers['x-admin-key'], body: o && JSON.parse(o.body) });
      return { status: 200, headers: { get: () => null }, json: async () => opts.server(JSON.parse(o.body)) }; },
    exbSb: { isIn: () => true, cfg: () => ({ email: 'a@b.cd' }),
      api: async (p, o) => { const n = p.split('/').pop(), b = JSON.parse(o.body || '{}'); calls.rpc.push(n); if (n === 'mon_organisation') return { id: 'o1', nom: 'Excellencia Building', role: 'admin' }; if (n === 'equipe_liste') return { membres: [], invitations: [] }; if (n === 'equipe_codes') return []; return { ok: true }; } }
  };
  w.window = w;
  const ctx = vm.createContext(w);
  vm.runInContext(LIC, ctx);
  vm.runInContext(EQ, ctx);
  return { w, local, ses, calls, equipe };
}
const TOK = 'e'.repeat(80) + '.' + 'f'.repeat(40);
const goodServer = b => b.action === 'admin.org_token' ? { ok: true, jeton: TOK } : { ok: true, clients: [] };

(async () => {
  console.log('A. moteur non connecté, jamais enregistré → avertissement + bouton');
  let t = boot({ server: goodServer });
  ok(t.w.EXBLIC.engine() === false, 'engine() = faux sans connexion');
  await t.w.EXB_EQUIPE.reload(); await wait(30);
  ok(/abonnement expiré/.test(t.equipe.innerHTML) && /id="eq_lic"/.test(t.equipe.innerHTML), 'avertissement rouge + bouton affichés');
  ok(!t.calls.rpc.includes('equipe_definir_jeton'), 'rien enregistré sur le serveur');

  console.log('B. moteur connecté (session) → abonnement créé, enregistré, pas d’avertissement');
  t = boot({ server: goodServer, session: { exb_own: JSON.stringify({ url: 'https://x.supabase.co/functions/v1/licence', key: 'adm_secret' }) } });
  ok(t.w.EXBLIC.engine() === true, 'engine() = vrai');
  await t.w.EXB_EQUIPE.reload(); await wait(30);
  ok(t.calls.fetch.some(f => f.body.action === 'admin.org_token' && f.key === 'adm_secret'), 'clé d’administration envoyée au serveur de licences');
  ok(t.calls.rpc.includes('equipe_definir_jeton'), 'abonnement enregistré pour les invités');
  ok(!/abonnement expiré/.test(t.equipe.innerHTML), 'aucun avertissement');
  ok(!!t.local.exb_inv_tok_o1, 'date d’enregistrement mémorisée (renouvellement dans 30 jours)');

  console.log('C. connexion mémorisée durablement (« Rester connecté ») → reconnue après fermeture');
  t = boot({ server: goodServer, local: { exb_own: JSON.stringify({ url: 'https://x.supabase.co/functions/v1/licence', key: 'adm_secret' }) } });
  ok(t.w.EXBLIC.engine() === true, 'engine() = vrai depuis le stockage durable');

  console.log('D. serveur de licences refuse → message d’erreur clair');
  t = boot({ server: () => ({ ok: false, msg: 'Clé d’administration invalide.' }), session: { exb_own: JSON.stringify({ url: 'https://x.supabase.co/functions/v1/licence', key: 'mauvaise' }) } });
  await t.w.EXB_EQUIPE.reload(); await wait(30);
  ok(/Clé d’administration invalide/.test(t.equipe.innerHTML), 'motif du serveur affiché');
  ok(!t.calls.rpc.includes('equipe_definir_jeton'), 'rien enregistré');

  console.log('E. abonnement déjà enregistré il y a moins de 30 jours, moteur non connecté → pas d’alarme inutile');
  t = boot({ server: goodServer, local: { exb_inv_tok_o1: String(Date.now() - 5 * 864e5) } });
  await t.w.EXB_EQUIPE.reload(); await wait(30);
  ok(!/abonnement expiré/.test(t.equipe.innerHTML), 'pas d’avertissement');

  console.log('F. édition client : aucun outil propriétaire');
  const cli = clientLicense(LIC);
  ok(!/ownConn|ownConnect|exb_own|connectEngine|org_token/.test(cli), 'ni connexion au moteur, ni génération de jeton');
  try { new Function(cli); ok(true, 'code client valide'); } catch (e) { ok(false, 'code client invalide : ' + e.message); }

  console.log('\n' + (fail ? fail + ' ÉCHEC(S)' : 'Tout est réussi.'));
  process.exit(fail ? 1 : 0);
})();
