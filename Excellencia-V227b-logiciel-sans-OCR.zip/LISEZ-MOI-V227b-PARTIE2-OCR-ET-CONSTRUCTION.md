# V227b — Fusion de la partie 2 (OCR, site vitrine, captures) + préparation APK / EXE

Base : V227 (logiciel complet) + V222h partie 2.

## Livraison en 2 archives
- **Logiciel** (cette archive) : tout SAUF le moteur OCR.
- **OCR** (`Excellencia-V227b-OCR-moteur.zip`, ≈ 18 Mo) : uniquement `site/vendor/tesseract/`. À dézipper PAR-DESSUS le logiciel (dans le dossier racine, celui qui contient `site/`) avant de construire l'APK/EXE ; sinon l'OCR hors connexion ne fonctionnera pas.

## Ajouté depuis la partie 2
- `site/vendor/tesseract/` (≈ 18 Mo, dans l'archive OCR) : moteur OCR hors connexion (référencé par `exb-ocr.js`, `atelier-mep/exb-doc-ocr.js`, `sw.js`). Il manquait à la V227.
- `site/site-vitrine/` : site vitrine (requis par `tools/check.js` ; jamais embarqué dans l'APK/EXE).
- `site/docs/espaces/`, `site/captures-guichet/` : captures de documentation.
- `guide-V205y/` : guide PDF des liens d'accès personnels.

## Modifié (3 lignes)
`scripts/build-www.js`, `electron/scripts/prepare.js`, `scripts/make-livrables.js` : `docs/` et `captures-guichet/` ne sont plus copiés dans l'APK, l'EXE ni le dépôt client (≈ 8,6 Mo économisés ; aucun code ne les utilise). L'OCR (`vendor/tesseract`) EST embarqué.

## Construction
- Android : GitHub › Actions › « Application Android (APK) » › Run workflow.
- Windows : GitHub › Actions › « Application Windows (EXE) » › Run workflow.
- Les workflows (`.github/workflows/apk-client.yml`, `windows-client.yml`) restent ceux de VOTRE dépôt : cette archive ne les contient pas, ne les écrasez pas.
- Local : `npm install && npm run android:add` (une fois) puis `npm run android:debug` ; Windows : `cd electron && npm install && npm run dist`.

## Vérifié
`node scripts/build-www.js` et `node electron/scripts/prepare.js` : OK (www ≈ 37 Mo, OCR présent, édition client sans outil propriétaire). `tools/check.js` : 982 contrôles OK, 7 échecs déjà présents avant la fusion (voir message de livraison).

## Correctifs des contrôles (tools/check.js : 989/989)
- 5 contrôles de version obsolètes (V218–V221f) acceptent maintenant toute version v2xx.
- Contrôle des colonnes SQL : ne confond plus les libellés « lecture/ecriture » de la migration V226 avec de mauvaises colonnes de `droits_fonction` (la migration V226 était correcte).
- Contrôle des collections sensibles : lit toutes les migrations (V99zn + V224 + V99zzq), pas seulement la V99zn. Le serveur protégeait déjà conges, paie_calculs, paie_reglements.
- `exb-db.js` : `tfl` ajouté à la liste SENS pour refléter le serveur (sans effet aujourd'hui, tfl n'étant pas synchronisé par ce chemin).
- Cache hors-ligne renouvelé : `v227b-…`.

Fermer complètement l'application une fois après installation (cache `v227b-…`).
