# V227 — Modules en page + retour exact

Base : V226. Changent : `site/exb-v99r-shell.js`, `site/exb-v221-pages-modules.js`, `site/exb-auto-devis.js`, `site/sw.js`.

## 1. Retour exact (corrigé)
Fermer un module (← ou ✕) ramenait à l'écran d'accueil. Désormais on revient à l'écran d'où l'on venait (liste « Projets & Chantiers », module précédent…). « Avant » rouvre le module.
Ouvrir une catégorie ou un autre module ferme aussi la page du module précédent (elle restait affichée sous le menu).

## 2. Modules qui s'ouvraient en fenêtre flottante → maintenant en page (27 écrans)
Tâches terrain, Cartouche des plans, Stock : dépôts/inventaires/comparatifs, CRM, Congés & absences, Courrier, Compta (avoirs, échéances), Devis automatique, Administration avancée, Supervision, Supervision des espaces, Documents de chantier, Pièces d'architecture, Pièces écrites, Finance USD/FC, Phases architecture, Pilotage direction, Sécurité & sauvegardes, Continuité, Droits d'action, Journal d'audit, Versions, Synchronisation, Dossier projet, Plans & CAO, Permis, Paie & RH, Maintenance/Facility (V74), Réception de chantier.
(18 autres modules — Environnement, Électricité, VRD, etc. — étaient déjà en page depuis V221.)
Les petites fenêtres de saisie (nouvelle tâche, formulaires, confirmations) restent des fenêtres.

## 3. Vérifié
142 modules ouverts automatiquement : 0 fenêtre flottante restante ; retour exact testé sur 47 pages ; Retour/Avant sans écran blanc (142 modules) ; tests bureaux V213 (24), programme réglementaire (61), divisions, TFL : OK.
Non revalidé après le tout dernier garde-fou (zone de pages invisible → fenêtre d'origine) : relancer `python3 tools/test-auto-devis.py`.
Fermer complètement l'application une fois (cache `v227-…`).
