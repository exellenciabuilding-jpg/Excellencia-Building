# V222e — Éditeur Word : « Toute l’affiche » reprise de la V222 dans la V222d

Base : V222d (V221l + V222 BCF/IDS + V222b filigrane selon logos + V222c OCR). Rien de la V222d n’est retiré.

## Appliqué
- **Éditeur Word des affiches** : nouvelle fonction `EXBAW.editAll` (tous les textes d’une affiche dans un seul document, séparés par un trait ; seuls les textes modifiés sont réécrits).
  - Studio d’affiches : bouton **✍️ Toute l’affiche (Word)**.
  - Affiches Excellencia : **✍️ Toute l’affiche générale (Word)** et **✍️ Toute l’affiche logiciels (Word)**.
- Fichiers repris de la V222 (aucune ligne propre à la V222d n’y était perdue) : `exb-v186d-affiches-word.js`, `exb-v186g-affiches-excellencia.js`, `exb-affiches-studio.js`.
- `sw.js` : suffixe de cache `-v222d-affiches-word-ensemble` (préfixe `v221l-` inchangé). Fermer complètement l’application une fois après déploiement.
- Nouveau test : `node site/tools/test-affiches-word-ensemble.js` (12 contrôles). `check.js` : 987 réussis / 0 échec (avec le dossier `vendor/tesseract` de la partie 2).

## NON appliqué (décision nécessaire) — Word sur les certificats
La V222 reprend la V220 sous la forme « textes modifiables à la main » (+ V221 export .docx du certificat, + V222 « Tout le certificat dans l’éditeur Word »).
La V222d a une **autre V220** : « textes de l’entreprise » (nom, slogan, cachet, Directeur général remplacent les textes dessinés). Les deux modules portent le même nom (`exb-certificat-textes.js`, `window.EXB_CERT_TXT`) mais ont des interfaces différentes : ils ne se copient pas l’un sur l’autre.
Fichiers concernés : `exb-certificat-textes.js`, `exb-certificat-word.js` (absent de la V222d), `exb-v206b-certificat-modele-5.js`, `exb-v206c-certificats-images.js`, tests `e2e-certificat-textes.py`, `e2e-certificat-word.py`, `e2e-ensemble-word.py`.

## NON restauré — générateur de licences
Absent des deux archives : `owner-app/`, `licence-server/`, `owner-licences/`. Les scripts (`build-generateur.js`, `build-editions.js`, `test-licence*.js`, `make-livrables.js`) les référencent mais les dossiers n’y sont pas. À fournir pour restauration.
