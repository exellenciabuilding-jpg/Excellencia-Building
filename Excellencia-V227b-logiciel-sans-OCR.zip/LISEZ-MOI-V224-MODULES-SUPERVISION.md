# V224 — Congés, Courrier et modules manquants branchés à la supervision

Base : V223. **Seuls les fichiers listés ci-dessous changent.**

## 1. À exécuter une fois dans Supabase (SQL Editor)
`site/supabase/migration-v224-modules-supervision.sql` — après v66, v99zn et v223. Réexécutable sans danger. Essayer d'abord sur la copie.

## 2. Nouveaux modules (`site/exb-v224-conges-courrier.js`)
Deux boutons apparaissent dans le menu, sous « Personnel & RH » :
- **🏖️ Congés & absences** : demande, approbation / refus (administrateur, direction, RH), détection de chevauchement, jours calendaires.
- **✉️ Courrier** : registre des courriers entrants / sortants, service concerné, échéance (⚠ si dépassée), statut. Registre manuel, pas une boîte e-mail.

## 3. Données désormais partagées (`site/exb-db.js`) — 36 collections
- **Bureau d'études** : dossiers d'étude, dalles, géotechnique, réserves géotechniques, quantitatifs, liens BIM, électricité, plomberie, topographie, VRD.
- **Chantier** : contrôles, causes, non-conformités, clôtures de projet, présences du personnel.
- **Comptabilité** : avoirs, échéanciers, clôtures mensuelles, écritures OD, immobilisations, TVA achats, paie (calculs, règlements).
- **CRM** : opportunités, relances, contrats, réclamations, satisfaction. **Stock** : dépôts, transferts, inventaires, consultations.
- **Budgets financiers** (budgetfin) : budgets et TVA déductible.
- **RH / Courrier** : congés, courrier.
- Sensibles (invisibles pour « polyvalent ») : congés, paie calculs, paie règlements.

## 4. 🧭 Supervision des espaces : 9 espaces, 167 rubriques (`site/exb-v223-espaces-admin.js`)
Comptabilité · Ingénieur / Chantier · **Bureau d'études** · **Architecte** · Formation · **RH & Courrier** · **Commercial & Stock** · Direction, plus **ERP & Achats** (modules V92 / V93, exploitation et maintenance). Contrôle fait : *toute* collection partagée figure dans le superviseur (avant : 78 collections déjà synchronisées n'y apparaissaient pas). Chaque rubrique montre fiches sur l'appareil, fiches sur le serveur (✓/⚠), dernière fiche et activité des membres.

## 5. Droits
- Congés : direction et RH seulement. Courrier : tous les services (lecture + saisie).
- Bureau d'études : écriture par le bureau d'études et la direction ; lecture chef de projet, conducteur, architecte.
- Compta : direction + comptable. Paie, CRM, stock : copiés des droits existants de « paie », « crm », « stock ».

## 6. Tests
`node site/tools/test-espaces-admin.js` (92) · `node site/tools/test-conges-courrier.js` (21). `sw.js` : cache `v224-…` — fermer complètement l'application une fois.

## Limites
- Non essayé sur un vrai Supabase.
- Un membre ne voit que ce que sa fonction permet : un chef de projet ne voit pas les congés.
- La première synchronisation envoie les fiches existantes de l'appareil administrateur : elle peut prendre un moment.
- Le coût d'analyse de site (architecte) est un simple réglage local : non partagé.

## Ce qui reste volontairement local (réglages, caches, brouillons)
Thème, cartes de visite, sauvegardes, configuration comptable / paie, glossaires, brouillons, journaux techniques, alertes lues : propres à chaque appareil.
Journal d'audit local : le journal des opérations partagées est tenu par le serveur (visible dans l'activité du superviseur).

## Hors synchronisation fiche par fiche (autres mécanismes ou risque)
- **TP / TD de formation** (documents, copies, demandes) : l'écran garde les listes en mémoire ; une fiche reçue d'un collègue pourrait être écrasée. À traiter séparément avec un rafraîchissement d'écran.
- **Honoraires des formateurs** : un seul objet par appareil, pas une liste de fiches.
- **Terrain** (journaux, photos, dépenses, documents), **portail formateur**, **TFL**, **portail client**, **circuits de validation** : tables Supabase dédiées, déjà synchronisées par leurs propres modules.
