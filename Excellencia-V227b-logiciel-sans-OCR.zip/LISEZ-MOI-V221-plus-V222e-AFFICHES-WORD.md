# V221 + modification V222e — « Toute l’affiche (Word) »

Base : V221 (invitation des membres inchangée : exb-equipe.js, exb-license.js, exb-com-sync.js non touchés).

## Appliqué (repris de la V222e)
- `EXBAW.editAll` : tous les textes d’une affiche dans un seul document Word, séparés par un trait ; seuls les textes modifiés sont réécrits.
  - Studio d’affiches : bouton « ✍️ Toute l’affiche (Word) ».
  - Affiches Excellencia : « ✍️ Toute l’affiche générale (Word) » et « ✍️ Toute l’affiche logiciels (Word) ».
- Fichiers remplacés : exb-v186d-affiches-word.js, exb-v186g-affiches-excellencia.js, exb-affiches-studio.js.
- sw.js : cache renouvelé (préfixe `v221-v222e-affiches-word-ensemble-`). Fermer complètement l’application une fois après déploiement.
- Test ajouté : `node site/tools/test-affiches-word-ensemble.js` (12 contrôles).
- `site/vendor/tesseract` (OCR) ajouté depuis la partie 2 de la V209e.

## Vérifications
check.js : 927 réussis / 0 échec. Test affiches : 12 / 0.

## NON inclus
- Générateur de licences (owner-app, licence-server, owner-licences) : absent de toutes les archives reçues.
- Le reste de la V222e (V221f à V221l PDF/modules, V222 BCF/IDS, V222b filigrane, avertissement rouge de l’abonnement d’équipe).
