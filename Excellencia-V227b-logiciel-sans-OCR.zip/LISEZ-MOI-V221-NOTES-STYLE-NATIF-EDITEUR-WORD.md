# V221 — Notes de calcul importées : même présentation que le logiciel + éditeur Word

Correctif à copier par-dessus la V220 (partie 1). `site/vendor/` (partie 2) ne change pas.

## Ce qui change
**Atelier de mise en page › modèle « Notes de calcul »** : une note importée (PDF d'un autre outil) sort maintenant exactement comme une note générée par le logiciel :
- **Couverture** à double cadre bleu/or : nom de l'entreprise, logo, « NOTE DE CALCUL », N° · indice, objet, client, références (norme, établi par, statut), **sommaire** en 2 colonnes (repris des signets du PDF), QR « Vérifier ce document », « Fait à … — Date de délivrance », « Établi par », mention de responsabilité.
- **Bandeau bleu** sous liseré doré sur chaque feuille (logo, société, « Projet · N° », « Feuille x / n ») et **pied de page** avec QR + ligne société / contact / n° · indice · statut + « Scannez le QR… Code XXXX ».
- Si les marges du PDF importé sont occupées, le bandeau et le pied sont ajoutés dans des **bandes au-dessus et en dessous** de la page : rien n'est recouvert, la page d'origine reste intacte.
- Cases à cocher : « Présentation identique aux notes de calcul du logiciel » (décocher = ancienne présentation), couverture, sommaire, filigrane, page de validation (reprise sous la forme « CONCLUSION ET VISAS »).
- Nouveaux champs : **Objet de la note** et **Règlement / norme**. À l'import, le numéro (ex. NCS-2026-001) est repris du nom du fichier s'il y figure (modifiable).

**Éditeur Word branché** : bouton « ✏️ Rédiger avec l'éditeur Word » dans le panneau « Modèle et mise en page ». Il ouvre l'éditeur du logiciel (ruban Fichier · Accueil · Insertion · Mise en page · Références · Révision · Affichage · Aide, export Word .docx). Le texte est ajouté sur des **feuilles supplémentaires** à la suite de la note, avec le même bandeau et le même pied. Titres, sous-titres, listes et gras sont repris ; couleurs, polices et images ne sont pas reportées sur le PDF.

## Principes conservés
Original jamais modifié (SHA-256), rien d'inventé (« À compléter »), « établi / vérifié / approuvé par » uniquement depuis le circuit de validation (aucune signature dessinée), QR enregistré au registre à l'export.

## Fichiers modifiés
`site/atelier-mep/` : `exb-doc-layout.js`, `exb-doc-export.js`, `exb-doc-preview.js`, `exb-cartouche.js`, `app.js`, `LISEZ-MOI.txt` · `site/exb-atelier-mep.js` · `site/sw.js` (cache v221) · `site/tools/check.js`, `site/tools/test-atelier-mep.js`.
Après déploiement : fermer complètement l'application une fois pour renouveler le cache.

## Tests
`node site/tools/test-atelier-mep.js` (50) · `node site/tools/check.js` (927).

## Limite connue
Texte rédigé : polices PDF standard (caractères hors WinAnsi remplacés par « ? » et signalés). Le sommaire de la couverture vient des signets du PDF : sans signets, il est omis.
