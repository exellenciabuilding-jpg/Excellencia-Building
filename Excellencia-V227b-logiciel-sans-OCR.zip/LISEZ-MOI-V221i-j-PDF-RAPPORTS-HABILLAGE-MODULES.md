# V221i / V221j — PDF des modules, double en-tête, habillage des écrans

- **PDF des modules (Électricité, Plomberie, Topographie, VRD, Études P2/Géotechnique, Maintenance, Environnement, Juridique)** : le PDF généré est maintenant enregistré (il n'était jamais téléchargé). Testé : PDF + tous les boutons CSV téléchargent un fichier.
- **Rapports sans popup** (Programme & surfaces, Contrôle réglementaire, Analyse de site, Matériaux, Coordination, Règles IDS) : le rapport passe par l'aperçu commun (Imprimer / Enregistrer en PDF) au lieu d'une fenêtre popup souvent bloquée (`exb-v221-rapport-fenetre.js`).
- **Double en-tête (bulletin de paie, pièces comptables…)** : la détection d'un en-tête existant ne regardait que les 2500 premiers caractères ; un logo en base64 les dépassait, d'où la bannière marine ajoutée en plus (`docengine/bridge.js`).
- **Écrans de modules** : bouton « ← Projets & Chantiers », fil d'Ariane « Accueil › Projets & Chantiers › Module », titre fort, onglets horizontaux avec soulignement doré, sans blocage de l'écran.
- **QR de vérification** (V221k) : toujours en bas de la dernière page, même pour un texte court (comme les pièces écrites).

## V221l — Page de garde au choix et mise en page unique
- À chaque PDF du Centre documentaire (factures, décomptes, bons de commande, checklists, PV, rapports, notes d'études, rapports de modules…), une fenêtre demande **« Avec page de garde »** ou **« Sans (contenu seul) »**. Le dernier choix est présélectionné (Entrée valide) ; case « Ne plus demander » pour le fixer. Réglage : `EXBGARDE.set('avec'|'sans'|'ask')`.
- Contenu : mise en page « pièce » commune (en-tête, Réf./Projet/Date, titre, tableau, visa et signature, QR et pied de page en bas, 1 page si le contenu est court). Avec page de garde : la couverture officielle est ajoutée devant.
- Pièces qui gardent leur forme (reçus de paiement, feuilles de plan) : aucune demande.
- Pièces HTML imprimées sans en-tête : en-tête commun (logo, nom, coordonnées, filet doré) + QR de vérification en bas, à la place de la bannière marine.
