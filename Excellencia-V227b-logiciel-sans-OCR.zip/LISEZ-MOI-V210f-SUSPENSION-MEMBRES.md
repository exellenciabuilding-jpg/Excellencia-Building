# V210f — suspension / réactivation d'un membre + blocage immédiat de son logiciel

Correctif posé sur la V210e (partie 1 sur 2). À copier par-dessus le dossier du logiciel (mêmes chemins), puis **exécuter le SQL** (fichier séparé fourni aussi), redéployer et fermer complètement l'application une fois (cache v210f).

## Constat
- « Retirer » supprimait le membre côté serveur, mais **son logiciel ne s'en rendait pas compte** et restait ouvert avec ses données locales.
- La **suspension n'existait pas du tout**.

## Ce qui change
1. **Serveur (SQL)** — `supabase/migration-v210f-suspension-membres.sql`
   - `equipe_suspendre` : le membre sort de « membres » (plus aucun accès, dans toutes les fonctions existantes) ; sa fiche (nom, rôle, fonction, date d'entrée) est gardée dans `membres_suspendus`. Impossible de se suspendre soi-même ou de suspendre le dernier administrateur.
   - `equipe_reactiver` : remet le membre à l'identique (même rôle, même fonction, même code personnel). Respecte la limite d'utilisateurs de la licence.
   - Un membre suspendu **ne peut pas revenir seul** (ni avec le code d'entreprise, ni par invitation) : déclencheur sur `membres`.
   - `equipe_retirer` fonctionne aussi sur un membre suspendu ; `equipe_liste` renvoie en plus `suspendus`.
   - `mon_statut(org)` → `actif` / `suspendu` / `retire`.
2. **Logiciel du membre** — `site/exb-acces-membre.js` (nouveau), `site/exb-db.js`
   - Contrôle du statut toutes les 30 s, au retour dans l'application, à la reprise du réseau.
   - Statut ≠ actif : la synchronisation s'arrête et un **écran plein écran bloque tout le logiciel** (il revient aussi à la réouverture, même hors ligne, et si on tente de le supprimer).
   - Suspendu : bouton « Vérifier maintenant », l'écran se lève **tout seul** dès la réactivation.
   - Retiré : bouton « Se déconnecter et effacer les données de cet appareil » (efface les copies locales des données synchronisées, après confirmation).
   - En cas de doute (hors ligne, erreur serveur, SQL pas encore exécuté), **il ne bloque jamais**.
3. **Administrateur** — `site/exb-equipe.js` (panneau 👥 Équipe)
   - Boutons **⏸ Suspendre** à côté de « Retirer » ; carte **Membres suspendus** avec **▶ Réactiver** et **Retirer**.

## Fichiers (chemins du dépôt)
`site/supabase/migration-v210f-suspension-membres.sql` (nouveau), `site/exb-acces-membre.js` (nouveau), `site/exb-db.js`, `site/exb-equipe.js`, `site/index.html`, `site/sw.js` (cache v210f), `site/tools/check.js` (+15 contrôles, 1 ancien contrôle de cache assoupli).

## Vérifications
`check.js` : 800 contrôles, 0 échec. Test navigateur réel (Chromium, faux serveur piloté) : actif → rien ; suspendu → écran + contenu inerte ; écran supprimé à la main → reposé ; réactivé → écran levé et synchronisation relancée ; retiré → bouton d'effacement ; erreur serveur / migration absente → aucun blocage. Un défaut trouvé pendant ce test (contenu resté figé après réactivation) a été corrigé.

## À savoir
- **Le SQL n'a pas été exécuté sur un vrai Supabase** (pas d'accès ici) : exécutez-le, puis essayez Suspendre → Réactiver → Retirer sur un compte de test.
- Le blocage du logiciel est une barrière d'interface ; le vrai verrou est le serveur (plus aucune donnée accessible dès la suspension).
- Un membre retiré qui connaît le code d'entreprise partagé peut encore se rattacher avec ce code (comportement d'avant, non modifié) ; pour l'éviter, renouvelez le code d'entreprise ou utilisez « Suspendre ».
- Seule la partie 1 sur 2 a été fournie : rien dans la partie 2 n'a été vérifié.
