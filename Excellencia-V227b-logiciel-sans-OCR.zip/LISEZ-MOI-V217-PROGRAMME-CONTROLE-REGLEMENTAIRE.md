# V217 — Bureau d'architecture : Programme & surfaces + Contrôle réglementaire (cahier des charges §5.2)

Traite la **limite n°1 du LISEZ-MOI V216** (V209e et V209f absents). Livré sous forme de **delta** : copier ces fichiers par-dessus le dépôt V216, redéployer, puis fermer complètement l'application une fois (cache v217).

## Ajouté
- **📋 Programme & surfaces** (`exb-v209-architecture-programme.js`, V209e, expose `EXBARCP`) : locaux (nom, niveau, nature utile / circulation / annexes, nombre, surface unitaire cible, surface dessinée), cadre du projet (terrain, emprise, pays, commune, budget indicatif, tolérance), surface utile / brute, rendement, CES, COS (surface de plancher paramétrable), écart programme/plan par local, variantes (instantané + coût saisi, une seule « retenue », aucune recommandation), import/export CSV (compatible avec le CSV de l'IA Architecte), impression du tableau des surfaces. Emprise non saisie = **estimée** (rez-de-chaussée) et toujours signalée comme telle.
- **⚖ Contrôle réglementaire** (`exb-v209-controle-reglementaire.js`, V209f, expose `EXBARCR`) : **aucune règle ni seuil préenregistré**. Modèles par pays / commune (copie figée dans le projet), règles du projet (CES, COS, emprise, surfaces, niveaux, rendement, surface de locaux par nom, mesure saisie), source, statut, date de fin de validité. Résultats : conforme / non conforme / **à vérifier** — une règle non validée, périmée, sans donnée ou portant sur une emprise estimée n'est **jamais** « conforme ». Historique des contrôles, CSV, rapport.
- `index.html` : 2 balises avant « Coordination ». `sw.js` : 2 entrées de cache, version `v217-`. Boutons ajoutés à côté de « Phases architecture ».
- `site/supabase/migration-v209e-programme.sql` et `migration-v209f-controle-reglementaire.sql` : droits de `arch_programme` et `arch_reglementation` (idempotents, calqués sur V209k). **À exécuter** pour la synchronisation d'entreprise.
- Tests : `test-programme.js` (15), `test-controle-reglementaire.js` (16), `e2e-programme-reglementaire.py` (61), les deux premiers branchés dans `npm run test:architecture` ; 11 contrôles V217 dans `site/tools/check.js`.
- `exb-db.js` : inchangé (les collections `arch_programme` / `arch_reglementation` y étaient déjà déclarées).

## Définitions de CES / COS / surface brute (limite 2 de V216) — paramétrables par projet
- **Surface brute** = utile + circulation + annexes, tous niveaux (inchangée).
- **Surface de plancher** (base du COS) : l'utilisateur choisit les natures comptées et les niveaux exclus (ex. sous-sol, cave) dans « Synthèse › Définitions de calcul de ce projet ». **COS = surface de plancher / terrain.**
- **CES = emprise / terrain** ; emprise saisie, sinon estimée d'après un niveau choisi (défaut : rez-de-chaussée) et signalée comme estimée.
- Tant que la définition n'est pas enregistrée pour le projet, le COS est affiché « (déf. par défaut) » et une règle sur le COS ou la surface de plancher donne **« À vérifier »**, jamais « conforme ». Nouvel indicateur de règle : « Surface de plancher selon la définition du projet ».

## Recette navigateur (limite 1 de V216)
`python3 site/tools/e2e-programme-reglementaire.py` (Chromium + playwright) : **61 vérifications, 0 échec**, en écran mobile (390 px) et PC (1280 px) — boutons, saisie et refus de valeurs invalides, CES/COS, définitions, variantes (une seule retenue), import/export CSV, modèles pays/commune (copie sans doublon, toujours « à valider »), résultats conforme / non conforme / à vérifier, historique, isolation entre projets, aucune erreur JavaScript. Affichage des locaux en fiches (lisible sur téléphone).
**Pas encore fait** : essai dans l'application Android installée (Capacitor) et sur le logiciel complet avec ses vraies données ; la recette ci-dessus se fait sur une page d'essai reproduisant le bouton « Phases architecture ».

## Vérifié
`npm run test:architecture` : 10 + 28 + 19 + 13 + 9 + 15 + 16 tests ; `npm run test:calcul` : 0 échec ; `node tools/check.js` (depuis `site/`) : **900 contrôles réussis, 0 échec**. L'IA Architecte et Matériaux lisent bien `EXBARCP`. Aucun fichier V210f–V216 modifié, hormis `sw.js`, `index.html`, `package.json`, `check.js` (ajouts).

## Limites à connaître
1. Les **valeurs réglementaires** ne sont pas fournies : chaque pays / commune doit saisir ses règles, avec source, puis les valider.
2. **Hauteur, reculs, stationnement** : contrôlés par mesure saisie à la main, non calculés.
3. Le contrôle réglementaire est une **aide**, pas un avis de conformité.
4. Toujours à faire (V216) : recette IDS avec de vrais .ids/.ifc, recette Android installée et serveur Supabase réel.

## Reste à faire côté cahier des charges (§5.2)
Rendu et présentation, dossier permis (le module `exb-v81-permis.js` existant est à examiner avant de décider s'il couvre « liste de pièces, plans, formulaires, suivi des dépôts / retours »).
