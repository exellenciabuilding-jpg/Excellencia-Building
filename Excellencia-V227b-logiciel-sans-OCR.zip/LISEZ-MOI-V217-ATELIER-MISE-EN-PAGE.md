# V217 + Atelier de mise en page (Bureau d'études – Ingénieur)

Paquet complet « partie 1 sur 2 » : la V217 avec l'Atelier intégré. La partie 2 (Tesseract OCR, données françaises) reste inchangée : `site/vendor/` doit rester celui de votre partie 2.

## Déploiement
1. Redéployer le contenu de ce zip (dossier `site/`).
2. Exécuter dans Supabase › SQL Editor, une fois chacun, dans l'ordre : `migration-v209e-programme.sql`, `migration-v209f-controle-reglementaire.sql`, `migration-v217-atelier-mise-en-page.sql` (dossier `site/supabase/`).
3. Fermer complètement l'application une fois pour renouveler le cache.

## Atelier
Bouton « 🖨️ Atelier de mise en page » (Ingénierie & Structure) et action sur l'accueil. Détails : `site/atelier-mep/LISEZ-MOI.txt`.
Tests : `node site/tools/test-atelier-mep.js` (38) ; SQL : `bash site/tools/test-sql-atelier.sh` (PostgreSQL 16).
