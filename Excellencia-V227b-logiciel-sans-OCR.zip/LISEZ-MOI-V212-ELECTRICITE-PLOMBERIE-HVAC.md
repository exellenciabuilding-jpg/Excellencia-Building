# V212 — Bureaux spécialisés (cahier des charges V1.0, §5.8) : Électricité + Plomberie / HVAC

Dépôt complet : la V210f (partie 1 sur 2) + le correctif V211 (Topographie, Géotechnique complémentaire) + la V212 déjà intégrés. Redéployer, puis fermer complètement l'application une fois (cache v212). **Aucun SQL** : données locales (clés `exb_elec`, `exb_plomb`).

## Ajouts
1. **⚡ Électricité** (`site/exb-elec.js`, menu Ingénierie) : référentiel (norme + édition déclarées, tensions, chute de tension max, résistivité, Ks, réserve), table Iz indicative à confirmer par un responsable nommé (toute modification annule la confirmation), circuits (Ib, calibre et section proposés, vérification Ib ≤ In ≤ Iz, chute de tension, PdC ≥ Icc), bilan de puissance par tableau, quantitatif de câbles, rapport PDF, CSV, visa nominatif (vérificateur ≠ auteur), contrôles ELEC-1 à ELEC-9.
2. **🚿 Plomberie / HVAC** (`site/exb-plomb.js`, juste après Électricité) : débit de pointe par simultanéité, tronçons d'eau (vitesse, Reynolds, Darcy-Weisbach / Swamee-Jain, singularités, dénivelée, pression résiduelle, DN proposé), gaines d'air circulaires, charges thermiques (somme de postes saisis), nomenclature d'équipements avec GlobalId IFC contrôlé, CSV, visa nominatif, contrôles PLB-1 à PLB-10.

## Fichiers modifiés / ajoutés
`site/exb-elec.js`, `site/exb-plomb.js` (nouveaux) · `site/index.html` (2 balises) · `site/sw.js` (cache v212 + 2 modules) · `site/tools/check.js` (+16 contrôles, contrôle de cache V211 assoupli) · `site/tools/test-elec.js`, `site/tools/test-plomb.js` (nouveaux).

## Vérifications
`node site/tools/test-elec.js` : 17 OK · `node site/tools/test-plomb.js` : 22 OK · `node site/tools/check.js` : 0 échec · tests V211 (topo 61, géo 24) inchangés.

## À savoir
- Pas d'essai en navigateur dans cette étape : moteurs testés sous Node, branchement vérifié dans index.html / sw.js. Faire une recette sur navigateur, Android et PC.
- Calculs déterministes, qui ne remplacent pas la note d'un ingénieur. Tables Iz et DN préremplies INDICATIVES.
- Hors périmètre (signalé, non simulé) : courts-circuits calculés, sélectivité, groupement/température, schémas unifilaires, bouclage ECS, réseaux maillés, eaux usées/pluviales, psychrométrie.
- Restent au §5.8 : VRD, Environnement, Juridique/contrats, Maintenance/facility. Partie 2 sur 2 non fournie, non vérifiée.
