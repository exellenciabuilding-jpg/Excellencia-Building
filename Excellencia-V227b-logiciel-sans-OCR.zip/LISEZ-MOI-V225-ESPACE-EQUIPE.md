# V225 — Espace Équipe : annuaire (d'après la maquette V205 « Gestion des comptes »)

Base : V223 + V224 (congés, courrier, supervision). **Seuls changent : `site/exb-equipe.js`, `site/sw.js`, `scripts/test-equipe-annuaire.js` (nouveau).** Aucune migration SQL.

## Ce qui est repris de la maquette
- **Statistiques en tête** : Personnes · Accès actifs · Invitations en attente · Suspendus.
- **Annuaire** : recherche (nom, e-mail, fonction, rôle) et filtre par fonction ; filtrage instantané, compteur « n résultats sur N ».
- **Statuts visibles** sur chaque ligne : Actif · En attente · Suspendu.
- **Carte « Règles de sécurité »** (uniquement des règles réellement appliquées par le logiciel).
- Ordre de l'écran : statistiques → annuaire → membres → suspendus → invitations → inviter → liens d'accès → règles.

## Volontairement non repris
- **Permissions par case** (Lecture / Création / Modification / Validation / Export / Administration) et **matricule** : la maquette les simule dans le navigateur ; le serveur gère aujourd'hui trois rôles (Administrateur / Éditeur / Lecteur) et une fonction. Des cases non appliquées par le serveur donneraient une fausse impression de protection. À faire avec une migration SQL + règles côté serveur si vous le souhaitez.
- Création directe d'un compte avec mot de passe : le logiciel passe par invitation + code personnel (plus sûr).

## Tests
`node scripts/test-equipe-annuaire.js` (9) · `node scripts/test-equipe-licence.js` · `node site/tools/test-espaces-admin.js` (92) · `node site/tools/test-conges-courrier.js` (21).
`sw.js` : cache `v225-…` — fermer complètement l'application une fois.
