# V99zzzzzzzzzzzzzzzzzzzzz — Éditeur de plan de maison 2D/3D (usage interne)

Fichiers ajoutés : `plan-editeur/index.html`, `plan-editeur/catalogue.js`, `plan-editeur/symboles.js`, `plan-editeur/vue3d.js`, `exb-plan-editeur.js`.
Fichiers modifiés : `index.html` (1 balise script), `exb-v99r-shell.js` (menu Architecture), `sw.js` (cache + hors connexion, version `plan-editeur-3`).
Pas de SQL : plans enregistrés sur l'appareil (clé `exbPlanEditeur.v1`) ; 💾 Exporter / 📂 Importer (.json) pour les partager. Aucune bibliothèque externe (2D canvas, 3D WebGL natif).

## Rendu « plan d'architecte » (V3)
- Murs pleins quasi noirs ; boutons « Mur 0,20 » et « Cloison 0,10 » dans la fiche d'un mur.
- Portes à battant avec arc d'ouverture et chambranles ; **⇋ Charnière**, **⇅ Sens d'ouverture**, **Porte double** dans la fiche. Fenêtres : châssis vitré à 3 traits dans l'épaisseur du mur.
- Mobilier dessiné en vue de dessus : lits (oreillers, drap replié), canapés, tables avec chaises, bureau, armoire, cuisinière (feux), évier, frigo, WC, lavabo, douche, baignoire, lave-linge… Les meubles « adossés » (lit, armoire, WC, lavabo, cuisine…) se collent et s'orientent seuls contre le mur le plus proche à la pose ; bouton **⇥ Coller au mur** dans la fiche.
- **⬚ Pièce : touchez l'intérieur d'un espace fermé** → la pièce est détectée avec son nom et sa **surface nette** (portes et fenêtres comptées comme fermées). Si l'espace n'est pas fermé, le tracé à la main reste possible. Noms proposés : Salon, Chambre, Douche, Couloir, Terrasse…
- Cotes extérieures automatiques (largeur × profondeur hors tout) ; bouton **📏 Cotes** : aucune / extérieures / toutes. Boutons **▦ Grille** (affichage), **🧲 Accroche** (aimantation), **🎨 Pièces** (couleurs). L'export PNG est sans grille.

## Utilisation (menu Architecture › ✏️ Plan de maison)
- **🧱 Mur** (double-touche pour finir ; revenir au départ ferme le contour) · **⌒ Arc** (départ, fin, point de l'arc ; losange pour courber un mur existant) · **🚪 Porte / 🪟 Fenêtre** (touchez un mur droit).
- **🛋 Mobilier** (22 éléments ; ajouter un meuble = 1 ligne dans `catalogue.js`, son symbole dans `symboles.js`) · **🔌 Électricité** (12 points) · **〰 Câble** (5 circuits).
- **🧊 3D** : murs avec ouvertures découpées, sols, mobilier, points électriques ; Dessus / Perspective / Face ; PNG.
- **➕ Envoyer au métré** : murs, maçonnerie, enduit/peinture, sols, plinthes, portes, fenêtres, équipements cuisine/sanitaire, points électriques, câbles par circuit (+10 %). Mobilier compté seulement si la case est cochée. Renvoyer met à jour les lignes (pas de doublon).


### V4.6 — cotation, coupes et façades, visite virtuelle, meubles (lot B)
- **Cotation complète** (bouton 📏 : non → ext. → toutes → *cotation complète*) : chaîne de cotes sur les 4 façades (trumeaux, ouvertures, axes des refends), cotes nettes des pièces en bleu, repères **P1, F1, F2…** des menuiseries (taille et allège en zoom), hauteur sous plafond (HSP) dans chaque pièce.
- **🧾 Légende** : hachures des sols (carrelage, parquet, béton), légende des murs (épaisseur, métrage), des sols (m²) et **tableau des menuiseries** (dimensions, quantité). Imprimée dans une colonne dédiée de la feuille.
- **📑 Coupes / façades** (`coupes.js`) : façades Nord / Sud / Est / Ouest et **coupe A-A** avec poché des murs et dalles coupés, mobilier, toit, niveaux et altitudes, hauteurs, chaîne de cotes de la coupe. Ligne de coupe tracée sur le plan (✏ Tracer la coupe, 2 points), sens de vue inversable (⇄), repères A/B et flèches sur le plan. Zoom et déplacement ; export PNG ; **5 feuilles supplémentaires à l'impression** (option « Façades et coupe » du cartouche).
- **🚶 Visite virtuelle** : bouton dans la barre 3D, ou outil « Visite ici » sur le plan. Marche à hauteur d'yeux (1,60 m) : joystick tactile, glisser pour regarder, clavier (flèches / WASD, Maj = courir), gyroscope optionnel, collisions murs et meubles, portes franchissables, escaliers montés et descendus automatiquement, boutons d'étage. Plafonds visibles de l'intérieur.
- **Meubles plus fins** : boîtes arrondies, cylindres, cônes, ellipsoïdes ; pieds fuselés, poignées métal, coussins, tiroirs, robinetterie, livres. 8 nouveaux meubles (table ronde, tabouret, commode, buffet, lampadaire, plante, tapis, îlot de cuisine) avec symboles 2D.
- Correction : la base du ciel (droite/haut) était inversée dans la vue orbitale.

### V4.5 — rendu réaliste (lot A)
- **Soleil et ombres portées** : curseur ☀ « heure du soleil » (6 h à 18 h) dans la barre 3D ; ombres douces ; ciel dégradé avec disque solaire, couleurs plus chaudes le matin et le soir ; bouton ◐ Ombres pour les couper (téléphones modestes).
- **Matériaux** : enduit grenu sur les murs, **carrelage à joints**, **parquet à lames**, béton, **tuiles** en rangs décalés, pavés, pelouse, bitume, bois. Le sol de chaque pièce se choisit dans ses propriétés (« Sol (3D) ») ; par défaut selon le nom : chambre ou bureau = parquet, garage, terrasse ou véranda = béton, le reste = carrelage.
- **Fenêtres** : cadre blanc, vitrage transparent avec reflet du ciel, meneau et traverse selon la taille, appui de fenêtre. **Portes** : chambranle, vantail à panneaux, poignée métal, seuil, double porte au-delà de 1,50 m.
- **Toit** : débord de 35 cm, gouttières, faîtière ; toit-terrasse avec acrotère.
- **Extérieur** (bouton 🌳) : pelouse, allée dallée, clôture avec piliers, portail, trottoir, route, arbres. Se désactive pour un rendu sobre.
- Réglages enregistrés avec le plan. Si l'appareil refuse le rendu réaliste, l'ancien éclairage simple prend le relais automatiquement.

## Limites
- Les façades et la coupe sont des dessins schématiques d'aide à la conception (pas de calepinage ni de détails de charpente).
- Visite virtuelle : pas de collision avec les garde-corps ni les rampants de toiture.
- La détection de pièce ignore les piliers isolés au milieu d'une pièce (contour extérieur seul).
- Câbles : longueur au plan +10 %, sans descentes verticales ; pas de schéma unifilaire.
- Quantités indicatives, à contrôler avant chiffrage.
- Retirer le module : supprimer la balise `<script src="exb-plan-editeur.js">` de index.html.


## V4 — points restants traités
- **Portes/fenêtres sur murs courbes** (2D et 3D) : position le long de l'arc, jambages orientés.
- **Étages** : onglets de niveaux (＋ Étage avec copie optionnelle des murs, renommer, supprimer), niveau inférieur en fantôme gris, accrochage sur ses murs. Quantités et lignes de métré par niveau (clés stables `n<i>:`).
- **Dalle / plancher** (surface bâtie), **toiture** (terrasse, 2 pans, 4 pans, pente, débord) avec surface développée et gouttières, **escalier droit** (catalogue « Circulation »), vue 3D multi-niveaux avec sélecteur « jusqu'à ».
- **Poteaux** (catalogue « Structure ») : retirés de la surface nette des pièces ; bouton « ↻ Redétecter » ; surface nette corrigée du biais de trame.
- **Fond de plan** : image à calquer, calage d'échelle (2 points + distance réelle), déplacement, opacité ; stockée sur l'appareil, absente de l'export PNG, incluse dans l'export JSON.
- **Câbles** : cheminement plafond/plinthe, descentes verticales aux points électriques ajoutées, +10 %.
- Anciens plans (sans niveaux) migrés automatiquement.

### V4.1 — escalier / toit
- **Trémie** : l'escalier d'un niveau perce automatiquement la dalle du niveau au-dessus (2D en pointillés, 3D, surface de dalle déduite). Article « Trémie » (catalogue Structure) pour tout autre vide (gaine, puits de lumière).
- **Toit indépendant** : emprise libre tracée sur le plan (« ▭ Tracer l'emprise du toit », 2 coins) ou auto ; sens du faîtage (Auto / X / Y) ; niveau d'appui au choix (annexe plus basse, par exemple).

### V4.2 — toits multiples, escaliers, outils de chantier
- **Toits multiples** : « ▭ Tracer un toit » ou « ⚡ Toit auto » ; chaque toit se sélectionne en touchant son contour pointillé (type, pente, faîtage, niveau d'appui, emprise, surface, gouttières). Lignes de métré par toit.
- **Escaliers** : droit, quart tournant, en U ; tous percent automatiquement la dalle du niveau supérieur.
- **Texte** : annotations libres sur le plan (déplaçables, taille réglable).
- **Client / chantier** enregistrés avec le plan.
- **🖨 Imprimer / PDF** : une page A3 par niveau avec cartouche (client, chantier, niveau, échelle indicative, date) puis les quantités ; « Enregistrer au format PDF » dans la boîte d'impression.
- **⧉ Dupliquer** un plan (variantes, avenants).

### V4.3 — synchronisation et toit libre
- **Synchronisation avec le compte** : chaque plan est une clé exbStorage (`exbPlanEd.p.<id>`), son fond de plan une autre (`exbPlanEd.bg.<id>`). Le circuit existant (exb-sync.js) les envoie et les récupère comme les autres données : on retrouve ses plans, et leur fond, sur un autre appareil connecté au même compte. Un plan modifié ailleurs est rechargé à l'ouverture du module (sauf modifications en cours). Les anciens plans de l'appareil sont migrés automatiquement.
- **Toit libre** (« ⬠ Toit libre ») : terrasse à contour quelconque (L, T, etc.) ; surface, rives et vue 3D calculées sur le contour. Les toits pentus en L/T se font avec plusieurs toits rectangulaires.

### V4.4 — cartouche professionnel
- **Impression / PDF à l'échelle** : une feuille A3 (ou A4) paysage par niveau, avec cadre, **flèche du nord**, **barre d'échelle graphique** et **échelle exacte** (1/20 à 1/1000, « Auto » = la plus grande qui tient), puis une feuille de quantités. À imprimer à 100 %.
- **Cartouche** en 5 blocs : (1) identité d'Excellencia Building reprise de l'application (logo, nom, slogan, adresse, téléphone, e-mail, mentions légales RCCM / ID.NAT / NIF) ; (2) maître d'ouvrage, projet, localisation ; (3) titre du plan, niveau, échelle, format, notes ; (4) n° de plan (auto `EXB-AA-xxxx-NN`), phase (APS, APD, PRO, DCE, EXE, DOE), indice de révision, date, feuille n / N ; (5) dessiné / vérifié / approuvé par (le Directeur Général par défaut, avec **signature et cachet** si configurés).
- Réglages dans « 📋 Cartouche (impression) » du panneau latéral ; enregistrés et synchronisés avec le plan.

### Limites restantes
Les toits à pentes restent rectangulaires (à combiner pour les formes en L ou T) ; le contour d'un toit libre ne se modifie pas point par point ; le nord est supposé vers le haut du plan ; la synchronisation exige d'être connecté.


### V4.6 — lot C : exports, rendu haute résolution, devis relié au plan
Fichiers ajoutés : `plan-editeur/exports.js`. Modifiés : `plan-editeur/index.html`, `plan-editeur/vue3d.js`, `exb-metre.js` (1 ligne : `addLignes` accepte `puSync`, voir plus bas), `sw.js` (cache hors connexion).
- **⬇ DXF (AutoCAD)** : dessin 2D au format DXF R12, lu par AutoCAD, BricsCAD, LibreCAD, QCAD. Un calque par famille (MURS, MURS_AXES, PORTES, FENETRES, PIECES, PIECES_TEXTE, MOBILIER, ESCALIERS, ELECTRICITE, CABLES, TEXTES, COTES), préfixé du nom du niveau s'il y en a plusieurs ; TOIT et CARTOUCHE en calques communs. Murs coupés aux ouvertures, portes avec battant et arc, fenêtres, surfaces des pièces, cotes extérieures, cartouche. Unité au choix (mètres, centimètres, millimètres) dans le panneau latéral. Textes en ASCII avec séquences `\U+XXXX` (accents corrects partout).
- **⬇ 3D · GLB** (glTF binaire : Blender, Windows 3D Viewer, SketchUp via extension) et **⬇ 3D · OBJ** (zip .obj + .mtl : SketchUp, Blender, 3ds Max). Tout le bâtiment, mètres, axe vertical Y ; respecte le bouton 🌳 Extérieur. Un objet par matériau et par couleur. Fonctionne même sans WebGL.
- **📷 4K** (barre 3D) : image PNG dont le grand côté fait 3840 px (réduit automatiquement si l'appareil ne sait pas), même cadrage qu'à l'écran, bandeau projet / client / entreprise / date / heure du soleil. **🎞 Vidéo 360°** : tour complet de 8 s enregistré en MP4 (H.264) ou WebM selon l'appareil.
- **💲 Prix unitaires (devis)** : tableau de prix en $ enregistré avec le plan. Chaque matériau choisi alimente quantités **et** prix : sol carrelage / parquet / béton lissé par pièce, couverture tuiles ou terrasse, portes et fenêtres au m², équipements, points électriques, câbles par circuit. « Envoyer au métré » transmet les prix ; un prix modifié ensuite dans le métré est conservé tant que le prix du plan (ou le matériau) ne change pas. Estimation indicative affichée sous les quantités ; le CSV contient PU et montants. **Les valeurs de départ sont des exemples à ajuster selon votre marché.**
- Retirer le module : supprimer la balise `<script src="exports.js">` ; les boutons d'export se masquent d'eux-mêmes.

Limites V4.6 : DXF 2D uniquement (pas de coupes ni façades) ; contours de murs superposés aux angles (à fusionner avec « Région / Union » si besoin) ; GLB/OBJ en couleurs unies (pas de textures) ; pas d'export IFC ni d'éclairage global ; les murs n'ont pas encore de choix de matériau (enduit + peinture compté) ; l'enregistrement vidéo exige un navigateur récent.
