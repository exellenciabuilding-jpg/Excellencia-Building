/* Exports de l'éditeur de plan — V4.6 « lot C » (aucune bibliothèque externe, fonctionne hors connexion).
 *  EXBEXP.dxf(entites, opts)  → Uint8Array  DXF « R12 » (AC1009) lisible par AutoCAD, BricsCAD, LibreCAD, QCAD, DraftSight…
 *  EXBEXP.glb(scene, opts)    → Uint8Array  glTF binaire (.glb) : Blender, SketchUp (extension), Windows 3D Viewer, Revit via convertisseur…
 *  EXBEXP.objZip(scene, opts) → Uint8Array  archive .zip contenant .obj + .mtl (SketchUp, Blender, 3ds Max…)
 *  EXBEXP.zip(fichiers)       → Uint8Array  zip sans compression
 * « scene » = la scène préparée par l'éditeur pour la vue 3D (même géométrie que ce qu'on voit à l'écran) ; EXB3D._build la convertit en triangles.
 * « entites » (DXF) = liste neutre en mètres, plan x vers la droite, y vers le BAS (comme l'écran) ; l'export retourne y pour le CAO (y vers le haut) :
 *   {t:'poly',l:'CALQUE',pts:[[x,y]…],closed:true|false}  {t:'line',l,a:[x,y],b:[x,y]}  {t:'text',l,x,y,h,s,al:'c'|'l',rot:degrés}  {t:'circle',l,x,y,r}
 * Limites : textures procédurales (carrelage, parquet…) non exportées — chaque matériau part en couleur unie nommée ; le DXF est un dessin 2D (pas de 3D).
 * Pour retirer le module : supprimer la balise <script src="exports.js"> de plan-editeur/index.html (les boutons d'export disparaissent d'eux-mêmes). */
(function(w){'use strict';

/* ------------------------------------------------------------------ utilitaires */
var CP1252={0x20AC:0x80,0x201A:0x82,0x0192:0x83,0x201E:0x84,0x2026:0x85,0x2020:0x86,0x2021:0x87,0x02C6:0x88,0x2030:0x89,0x0160:0x8A,0x2039:0x8B,0x0152:0x8C,0x017D:0x8E,0x2018:0x91,0x2019:0x92,0x201C:0x93,0x201D:0x94,0x2022:0x95,0x2013:0x96,0x2014:0x97,0x02DC:0x98,0x2122:0x99,0x0161:0x9A,0x203A:0x9B,0x0153:0x9C,0x017E:0x9E,0x0178:0x9F};
function enc1252(s){var o=new Uint8Array(s.length),i,c;for(i=0;i<s.length;i++){c=s.charCodeAt(i);o[i]=c<128||(c>=160&&c<256)?c:(CP1252[c]||63)}return o}
function utf8(s){if(typeof TextEncoder!=='undefined')return new TextEncoder().encode(s);var b=unescape(encodeURIComponent(s)),o=new Uint8Array(b.length),i;for(i=0;i<b.length;i++)o[i]=b.charCodeAt(i);return o}
function r(v,n){var k=Math.pow(10,n==null?5:n);return Math.round(v*k)/k}
function clean(s){return String(s==null?'':s).replace(/[\r\n]+/g,' ')}
/* texte DXF en ASCII pur : les caractères accentués deviennent \U+00E9 (lu par AutoCAD, BricsCAD, LibreOffice, QCAD…) */
function dxfText(s){return clean(s).replace(/[^\x20-\x7E]/g,function(c){var h=c.charCodeAt(0).toString(16).toUpperCase();return '\\U+'+('0000'+h).slice(-4)})}

/* ------------------------------------------------------------------ ZIP (stockage, sans compression) */
var CRCT=null;
function crc32(u8){if(!CRCT){CRCT=new Uint32Array(256);for(var n=0,c,k;n<256;n++){c=n;for(k=0;k<8;k++)c=c&1?(0xEDB88320^(c>>>1)):(c>>>1);CRCT[n]=c>>>0}}
 var c2=0xFFFFFFFF,i;for(i=0;i<u8.length;i++)c2=CRCT[(c2^u8[i])&255]^(c2>>>8);return(c2^0xFFFFFFFF)>>>0}
function zip(files){ /* files : [{name, data:Uint8Array}] */
 var d=new Date(),dt=((d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1))&0xFFFF,dd=(((d.getFullYear()-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate())&0xFFFF;
 var parts=[],cen=[],off=0;
 files.forEach(function(f){var nm=utf8(f.name),crc=crc32(f.data),sz=f.data.length;
  var lh=new DataView(new ArrayBuffer(30));lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint16(8,0,true);lh.setUint16(10,dt,true);lh.setUint16(12,dd,true);lh.setUint32(14,crc,true);lh.setUint32(18,sz,true);lh.setUint32(22,sz,true);lh.setUint16(26,nm.length,true);lh.setUint16(28,0,true);
  parts.push(new Uint8Array(lh.buffer),nm,f.data);
  var ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint16(10,0,true);ch.setUint16(12,dt,true);ch.setUint16(14,dd,true);ch.setUint32(16,crc,true);ch.setUint32(20,sz,true);ch.setUint32(24,sz,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
  cen.push(new Uint8Array(ch.buffer),nm);off+=30+nm.length+sz});
 var csz=0;cen.forEach(function(p){csz+=p.length});
 var e=new DataView(new ArrayBuffer(22));e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,csz,true);e.setUint32(16,off,true);
 return cat(parts.concat(cen,[new Uint8Array(e.buffer)]))}
function cat(arr){var n=0,i;arr.forEach(function(a){n+=a.length});var o=new Uint8Array(n);n=0;arr.forEach(function(a){o.set(a,n);n+=a.length});return o}

/* ------------------------------------------------------------------ DXF */
var LCOL={MURS:7,MURS_AXES:8,PORTES:30,FENETRES:5,PIECES:3,PIECES_TEXTE:3,MOBILIER:4,ESCALIERS:6,TREMIES:8,ELECTRICITE:2,CABLES:1,TEXTES:7,COTES:1,TOIT:1,CARTOUCHE:7};
function layerName(l){return String(l||'0').toUpperCase().replace(/[^A-Z0-9_$-]+/g,'_').slice(0,31)||'0'}
function layerColor(l){var k=Object.keys(LCOL).sort(function(x,y){return y.length-x.length}),i;for(i=0;i<k.length;i++){if(l===k[i]||l.slice(-k[i].length-1)==='_'+k[i])return LCOL[k[i]]}return 7}
function dxf(E,o){o=o||{};
 var K=o.unit==='cm'?100:o.unit==='mm'?1000:1,out=[],layers={},ext=[1e18,1e18,-1e18,-1e18];
 function g(c,v){out.push(String(c),String(v))}
 function pt(x,y){var X=r(x*K,4),Y=r(-y*K,4);if(X<ext[0])ext[0]=X;if(Y<ext[1])ext[1]=Y;if(X>ext[2])ext[2]=X;if(Y>ext[3])ext[3]=Y;return[X,Y]}
 function lay(l){var n=layerName(l);layers[n]=layerColor(n);return n}
 var ents=[];
 (E||[]).forEach(function(e){var L=lay(e.l),a=[],i,p,q;
  if(e.t==='poly'&&e.pts&&e.pts.length>=2){a.push('0','POLYLINE','8',L,'66','1','70',e.closed?'1':'0');
   for(i=0;i<e.pts.length;i++){p=pt(e.pts[i][0],e.pts[i][1]);a.push('0','VERTEX','8',L,'10',p[0],'20',p[1],'30','0')}a.push('0','SEQEND','8',L)}
  else if(e.t==='line'){p=pt(e.a[0],e.a[1]);q=pt(e.b[0],e.b[1]);a.push('0','LINE','8',L,'10',p[0],'20',p[1],'30','0','11',q[0],'21',q[1],'31','0')}
  else if(e.t==='circle'){p=pt(e.x,e.y);a.push('0','CIRCLE','8',L,'10',p[0],'20',p[1],'30','0','40',r(e.r*K,4))}
  else if(e.t==='text'&&e.s!=null&&String(e.s)!==''){p=pt(e.x,e.y);var c=e.al==='c';
   a.push('0','TEXT','8',L,'10',p[0],'20',p[1],'30','0','40',r((e.h||0.2)*K,4),'1',dxfText(e.s),'50',r(-(e.rot||0),3));
   if(c)a.push('72','1','11',p[0],'21',p[1],'31','0','73','2')}
  if(a.length)ents.push(a)});
 if(ext[0]>ext[2]){ext=[0,0,10*K,10*K]}
 g(0,'SECTION');g(2,'HEADER');g(9,'$ACADVER');g(1,'AC1009');g(9,'$DWGCODEPAGE');g(3,'ANSI_1252');g(9,'$INSBASE');g(10,0);g(20,0);g(30,0);
 g(9,'$EXTMIN');g(10,ext[0]);g(20,ext[1]);g(30,0);g(9,'$EXTMAX');g(10,ext[2]);g(20,ext[3]);g(30,0);g(9,'$LIMMIN');g(10,ext[0]);g(20,ext[1]);g(9,'$LIMMAX');g(10,ext[2]);g(20,ext[3]);g(0,'ENDSEC');
 g(0,'SECTION');g(2,'TABLES');
 g(0,'TABLE');g(2,'LTYPE');g(70,1);g(0,'LTYPE');g(2,'CONTINUOUS');g(70,0);g(3,'Solid line');g(72,65);g(73,0);g(40,0);g(0,'ENDTAB');
 var names=Object.keys(layers);if(names.indexOf('0')<0)names.unshift('0');
 g(0,'TABLE');g(2,'LAYER');g(70,names.length);
 names.forEach(function(n){g(0,'LAYER');g(2,n);g(70,0);g(62,layers[n]||7);g(6,'CONTINUOUS')});g(0,'ENDTAB');
 g(0,'TABLE');g(2,'STYLE');g(70,1);g(0,'STYLE');g(2,'STANDARD');g(70,0);g(40,0);g(41,1);g(50,0);g(71,0);g(42,0.2);g(3,'txt');g(4,'');g(0,'ENDTAB');
 g(0,'ENDSEC');
 g(0,'SECTION');g(2,'ENTITIES');
 ents.forEach(function(a){for(var i=0;i<a.length;i+=2)g(a[i],a[i+1])});
 g(0,'ENDSEC');g(0,'EOF');
 return enc1252(out.join('\r\n')+'\r\n')}

/* ------------------------------------------------------------------ maillage commun (GLB / OBJ) */
var MATN={0:'Uni',1:'Enduit',2:'Carrelage',3:'Parquet',4:'Pelouse',5:'Tuiles',6:'Verre',7:'Beton',8:'Bois',9:'Paves',10:'Metal',11:'Feuillage',12:'Bitume'};
var MATR={0:[.8,0],1:[.95,0],2:[.3,0],3:[.55,0],4:[1,0],5:[.75,0],6:[.05,0],7:[.9,0],8:[.6,0],9:[.85,0],10:[.35,.9],11:[1,0],12:[.95,0]};
function hex2(v){var n=Math.max(0,Math.min(255,Math.round(v*255)));return(n<16?'0':'')+n.toString(16)}
/* regroupe les triangles par (matériau, couleur) ; sRGB 0..1 */
function groups(S){
 var B=w.EXB3D&&w.EXB3D._build?w.EXB3D._build(S):null;if(!B)throw new Error('Vue 3D indisponible');
 var G={},order=[];
 function scan(a,glass){var n=a.length/10,i,k,base,mt,key,g,j;
  for(i=0;i+2<n;i+=3){base=i*10;mt=glass?6:Math.round(a[base+9]);
   key=(glass?'v':'m')+mt+'_'+hex2(a[base+6])+hex2(a[base+7])+hex2(a[base+8]);
   g=G[key];if(!g){g=G[key]={key:key,mt:mt,glass:glass,col:[a[base+6],a[base+7],a[base+8]],v:[]};order.push(g)}
   for(j=0;j<3;j++){k=base+j*10;g.v.push(a[k],a[k+1],a[k+2],a[k+3],a[k+4],a[k+5])}}}
 scan(B.data,false);scan(B.glass,true);
 order.forEach(function(g){g.name=(MATN[g.mt]||'Mat')+(g.glass?'_vitrage':'')+'_'+g.key.split('_')[1]});
 return{groups:order,bbox:B.bbox}}

/* ------------------------------------------------------------------ GLB */
function lin(c){return Math.pow(Math.max(0,Math.min(1,c)),2.2)}
function glb(S,o){o=o||{};var M=groups(S),bin=[],bv=[],ac=[],mats=[],meshes=[],nodes=[],off=0;
 function pushBuf(f32){var u=new Uint8Array(f32.buffer,f32.byteOffset,f32.byteLength);bin.push(u);var s={buffer:0,byteOffset:off,byteLength:u.length,target:34962};off+=u.length;bv.push(s);return bv.length-1}
 M.groups.forEach(function(g){var n=g.v.length/6,P=new Float32Array(n*3),N=new Float32Array(n*3),i,mn=[1e30,1e30,1e30],mx=[-1e30,-1e30,-1e30],j;
  for(i=0;i<n;i++){for(j=0;j<3;j++){P[i*3+j]=g.v[i*6+j];N[i*3+j]=g.v[i*6+3+j];if(P[i*3+j]<mn[j])mn[j]=P[i*3+j];if(P[i*3+j]>mx[j])mx[j]=P[i*3+j]}}
  var pa=ac.push({bufferView:pushBuf(P),componentType:5126,count:n,type:'VEC3',min:mn,max:mx})-1,na=ac.push({bufferView:pushBuf(N),componentType:5126,count:n,type:'VEC3'})-1;
  var rg=MATR[g.mt]||[.8,0],m={name:g.name,doubleSided:true,pbrMetallicRoughness:{baseColorFactor:[r(lin(g.col[0]),4),r(lin(g.col[1]),4),r(lin(g.col[2]),4),g.glass?0.28:1],metallicFactor:rg[1],roughnessFactor:g.glass?0.05:rg[0]}};
  if(g.glass)m.alphaMode='BLEND';
  mats.push(m);meshes.push({name:g.name,primitives:[{attributes:{POSITION:pa,NORMAL:na},material:mats.length-1,mode:4}]});nodes.push({name:g.name,mesh:meshes.length-1})});
 var total=off,pad=(4-total%4)%4,binU=cat(bin);if(pad)binU=cat([binU,new Uint8Array(pad)]);
 var J={asset:{version:'2.0',generator:'Excellencia Building — éditeur de plan (V4.6)',extras:{plan:o.name||'plan',unite:'mètre',axeVertical:'Y'}},scene:0,scenes:[{name:o.name||'Plan',nodes:nodes.map(function(_,i){return i})}],nodes:nodes,meshes:meshes,materials:mats,accessors:ac,bufferViews:bv,buffers:[{byteLength:binU.length}]};
 var js=utf8(JSON.stringify(J)),jp=(4-js.length%4)%4,jb=new Uint8Array(js.length+jp);jb.set(js);for(var q=0;q<jp;q++)jb[js.length+q]=32;
 var hd=new DataView(new ArrayBuffer(12+8));hd.setUint32(0,0x46546C67,true);hd.setUint32(4,2,true);hd.setUint32(8,12+8+jb.length+8+binU.length,true);hd.setUint32(12,jb.length,true);hd.setUint32(16,0x4E4F534A,true);
 var bh=new DataView(new ArrayBuffer(8));bh.setUint32(0,binU.length,true);bh.setUint32(4,0x004E4942,true);
 return cat([new Uint8Array(hd.buffer),jb,new Uint8Array(bh.buffer),binU])}

/* ------------------------------------------------------------------ OBJ + MTL (dans un .zip) */
function objZip(S,o){o=o||{};var M=groups(S),base=String(o.base||'plan').replace(/[^\w.-]+/g,'_')||'plan',pm={},nm={},pi=0,ni=0,obj=['# Excellencia Building — éditeur de plan (V4.6)','# Unité : mètre · axe vertical : Y','mtllib '+base+'.mtl'],mtl=['# Matériaux (couleurs unies)'];
 function vid(v,map,pre,list){var k=r(v[0],4)+' '+r(v[1],4)+' '+r(v[2],4),id=map[k];if(!id){id=map[k]=++(pre.n);list.push((pre.p)+' '+k)}return id}
 var pc={n:0,p:'v'},nc={n:0,p:'vn'},vlist=[],nlist=[],faces=[];
 M.groups.forEach(function(g){var fl=['o '+g.name,'usemtl '+g.name],i,a=[],b=[];
  mtl.push('newmtl '+g.name,'Kd '+r(g.col[0],4)+' '+r(g.col[1],4)+' '+r(g.col[2],4),'Ka 0 0 0','Ks '+(g.mt===10?'0.5 0.5 0.5':'0.05 0.05 0.05'),'Ns '+(g.mt===10?60:10),g.glass?'d 0.28':'d 1','');
  for(i=0;i<g.v.length;i+=18){var t=[];for(var j=0;j<3;j++){var k=i+j*6;t.push(vid([g.v[k],g.v[k+1],g.v[k+2]],pm,pc,vlist)+'//'+vid([g.v[k+3],g.v[k+4],g.v[k+5]],nm,nc,nlist))}fl.push('f '+t.join(' '))}
  faces.push(fl.join('\n'))});
 var txt=obj.join('\n')+'\n'+vlist.join('\n')+'\n'+nlist.join('\n')+'\n'+faces.join('\n')+'\n';
 return zip([{name:base+'.obj',data:utf8(txt)},{name:base+'.mtl',data:utf8(mtl.join('\n'))}])}

w.EXBEXP={dxf:dxf,glb:glb,objZip:objZip,zip:zip,crc32:crc32,_groups:groups};
})(typeof window!=='undefined'?window:globalThis);
