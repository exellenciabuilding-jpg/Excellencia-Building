# V200d — Pages client à l'identité « maquette » (reportées de la version Netlify V200d)

## Ce qui est reporté (Netlify → GitHub)
- **Nouveaux** : `site/exb-client-mk.css`, `site/exb-client-mk.js` (en-tête, bandeau d'accueil, tuiles et statistiques communs).
- **Modifiés** : `site/demande.html`, `site/exb-demande.js` (tuiles avec images), `site/espace-client.html` (connexion), `site/portail.html` (« Mon dossier »), `site/sw.js` (cache renouvelé : `v200-maquette-client-sans-fond-photo-…`).
- Le reste du dépôt est **inchangé** (base : depot-github-V200-demande-portail-client).

## À faire de votre côté
1. Déposer ce ZIP sur GitHub / redéployer `site`, puis fermer complètement l'application une fois (cache renouvelé).
2. **Aucun nouveau SQL** : la migration `migration-v200-demande-client-compte-auto.sql` de la V200 reste la seule nécessaire (déjà exécutée si vous avez fait la V200).

## Vérifié ici
- `node tools/check.js` : 666 contrôles, 0 échec.
- `e2e-demande`, `e2e-accueil-client` : tout passe, 0 erreur JavaScript. `e2e-espace-client` : déconnexion OK.
- Les 4 images de tuiles et le fond d'accueil existent déjà dans `site/portail-img/`.
**Non testé** : rendu sur un vrai téléphone.
