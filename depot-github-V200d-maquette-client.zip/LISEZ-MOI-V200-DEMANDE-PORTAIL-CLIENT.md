# V200 — Toutes les demandes passent par le portail client (formulaires séparés + compte créé automatiquement)

## Ce que ça change
- **Une seule porte d'entrée** : `demande.html` (aussi `/demande`). Les 4 tuiles de l'accueil, le menu « Nos Services », « Déposer une demande de projet » et « Créer un compte » y mènent. Le formulaire `btp.html` reste en place pour le personnel / les anciens liens.
- **Un formulaire séparé par type** (seuls les champs utiles sont affichés) :
  | Type | Champs propres |
  |---|---|
  | Construction | ouvrage, niveaux, chambres, surface, prestation (gros œuvre / clé en main), finition, début ; **terrain** (L × l, superficie auto, nature, titre, accès, environnement, photos) ; plans existants (dépôt) ou « faire concevoir » ; permis |
  | Architecture | prestations (plan, exécution, 3D, permis, relevé), bâtiment, niveaux, programme (chambres, salons, salles d'eau…), style, images d'inspiration ; **terrain** ; documents ; livrables |
  | Métré & Devis | objet (neuf / rénovation / corps d'état → liste des corps), type de devis ; **plans facultatifs** (« j'ai des plans » → dépôt ; « pas de plans » → surface, niveaux, pièces) ; **postes détaillés** (désignation, quantité, unité) ; finition, matériaux, usage. **Aucune parcelle.** |
  | Rénovation | bien, âge, niveaux, surface ; travaux à cocher ; problèmes constatés ; occupé ? ; visite ? ; photos de l'existant (jusqu'à 8) ; plans existants. **Aucune parcelle.** |
  | Autre | objet, description, photos |
  Tous : budget, délai, message, puis nom, téléphone, e-mail, lieu du projet.
- **Compte client automatique** : à l'envoi, le client choisit un mot de passe (8 caractères mini). Son espace est créé tout de suite : identifiant = numéro client affiché à l'écran de confirmation (= le numéro de suivi de sa demande). Il est connecté automatiquement, **sans code à lui remettre**.
- Un client déjà connecté qui refait une demande : elle est rattachée à son compte, sans nouveau mot de passe. Un téléphone qui a déjà un espace ne crée pas de doublon.
- **Mon dossier** (`portail.html`) : tant que l'entreprise n'a pas publié le suivi de chantier, le client voit ses demandes envoyées et leur état. Après publication, le tableau de bord habituel s'affiche.
- La demande arrive **comme avant** dans la boîte de réception de l'entreprise (mêmes champs `category`, `services`, `state`, `surface`…, avec en plus `type_demande` et le détail dans `note`). Approbation, import client, chantier : inchangés.

## À faire de votre côté (dans l'ordre)
1. Supabase › SQL Editor : exécuter **`site/supabase/migration-v200-demande-client-compte-auto.sql`** (une fois, réexécutable).
2. Déposer le ZIP sur GitHub / redéployer `site` sur Netlify (fermer complètement l'application une fois : cache renouvelé).
3. Essai : `demande.html?type=renovation` → remplir → numéro client affiché → arrivée dans l'espace.
Sans l'étape 1, la page fonctionne quand même (repli sur l'ancien envoi, message « espace activé par l'entreprise »).

## Limites connues
- **Plans PDF / DWG** : seuls les plans en image (JPG / PNG / WebP) se joignent pour l'instant ; la page invite à envoyer PDF / DWG par WhatsApp ou e-mail avec le numéro client. Un vrai dépôt de fichiers demande Supabase Storage (prochaine étape).
- Les champs propres à chaque type sont stockés dans le résumé (`note`) et dans la fiche du dossier ; ils ne sont pas encore des colonnes dédiées dans l'écran d'administration.
- « Réinitialiser l'espace » ou publier le suivi via l'ancienne fonction `client_compte_creer` remet le mot de passe au numéro client (changement obligatoire) : à utiliser seulement pour un mot de passe oublié.
- Le compte est rattaché à la 1re organisation (installation Excellencia = une seule).
- Mot de passe choisi par le client (et non « 1234 » comme les apprenants) : un numéro client est séquentiel, donc devinable ; un mot de passe par défaut ouvrirait les devis et paiements d'autrui.

## Fichiers
Nouveaux : `site/demande.html`, `site/exb-demande.js`, `site/supabase/migration-v200-demande-client-compte-auto.sql`, `site/tools/e2e-demande.py`.
Modifiés : `site/accueil-client.html`, `site/espace-client.html`, `site/portail.html`, `site/sw.js`, `site/_redirects`, `site/tools/check.js`, `site/tools/e2e-accueil-client.py`.

## Vérifié ici
- `tools/e2e-demande.py` : 49 contrôles (5 formulaires, absence de parcelle en métré / rénovation / autre, plans facultatifs, postes de devis, validation, envoi complet avec photo + PDF + connexion automatique, repli sans SQL, client connecté, « Mon dossier », téléphone 390 px, 0 erreur JS) — serveur simulé.
- `node tools/check.js` : 665 contrôles, 0 échec ; `e2e-accueil-client` , `e2e-marque` (40 pages, 0 résidu), `e2e-espace-client` : tout passe.
**Non testé** : le script SQL (pas de Postgres ici : relisez les messages à l'exécution), l'envoi réel vers votre Supabase, un vrai téléphone.
