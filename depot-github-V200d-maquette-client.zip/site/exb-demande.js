/* V200 — Demande de projet sur le portail client : un formulaire SÉPARÉ par type de demande.
   Construction · Architecture · Métré & Devis · Rénovation · Autre.
   À l'envoi : la demande est enregistrée ET le compte client est créé automatiquement (fonction SQL client_demande_envoyer).
   Aucune donnée secrète ici (clé publique + règles côté serveur). */
(function(){
'use strict';
var $=function(i){return document.getElementById(i)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function cfg(){var c=window.EXB_SUPABASE||{};return c.url&&c.key?c:null}

/* ───────────── Listes communes ───────────── */
var OUVRAGES=['Maison / villa','Immeuble (R+n)','Local commercial / boutique','Entrepôt / hangar','Clôture / mur','Autre'];
var NIV=['Rez-de-chaussée','R+1','R+2','R+3 ou plus'];
var FIN=['Économique','Standard','Haut standing'];
var PENTE=['Plat','En pente légère','En forte pente','Je ne sais pas'];
var ETAT_RENO='Maison déjà construite : modification / extension / rénovation';

function terrain(photosLabel){return {title:'Le terrain',fields:[
  {id:'length_m',t:'num',label:'Longueur (m)',half:1,ph:'ex. 25'},
  {id:'width_m',t:'num',label:'Largeur (m)',half:1,ph:'ex. 12'},
  {id:'surface',t:'num',label:'Superficie (m²) — calculée automatiquement, modifiable'},
  {id:'nature',t:'sel',label:'Nature du terrain',opts:PENTE,half:1},
  {id:'titre',t:'sel',label:'Titre de propriété',half:1,opts:['Certificat d’enregistrement','Contrat de location','Autre document','Pas encore de titre']},
  {id:'acces',t:'chk',label:'Accès au terrain',opts:['Route d’accès','Eau','Électricité','Aucun pour l’instant']},
  {id:'environment',t:'area',label:'Environnement',ph:'Voisinage, arbres, cours d’eau, risque d’inondation…'},
  {id:'photos',t:'file',label:photosLabel||'Photos du terrain (facultatif — jusqu’à 5)',max:5}]}}

/* ───────────── Les 5 formulaires ───────────── */
var TYPES={
 construction:{label:'Construction',emoji:'🏗️',sub:'Maison, immeuble, bâtiment',cat:'BTP',color:'#0b2a5b',
  titre:'Demande de construction',intro:'Décrivez l’ouvrage et votre terrain. Nous vous recontactons avec une proposition.',
  groups:[
   {title:'Votre projet de construction',fields:[
     {id:'ouvrage',t:'sel',label:'Type d’ouvrage',req:1,opts:OUVRAGES},
     {id:'niveaux',t:'sel',label:'Nombre de niveaux',half:1,opts:NIV},
     {id:'chambres',t:'num',label:'Nombre de chambres',half:1},
     {id:'surface_bati',t:'num',label:'Surface bâtie souhaitée (m²)',half:1},
     {id:'finition',t:'sel',label:'Niveau de finition',half:1,opts:FIN},
     {id:'prestation',t:'sel',label:'Prestation souhaitée',req:1,opts:['Gros œuvre seul','Gros œuvre + second œuvre','Clé en main (finitions comprises)','Je ne sais pas encore']},
     {id:'demarrage',t:'sel',label:'Début des travaux souhaité',opts:['Dès que possible','Dans 1 à 3 mois','Dans 3 à 6 mois','Dans plus de 6 mois','Pas encore décidé']}]},
   terrain(),
   {title:'Plans et autorisations',fields:[
     {id:'plans_exist',t:'rad',label:'Avez-vous déjà des plans ?',req:1,opts:['Oui, j’ai déjà des plans','Non, pas encore']},
     {id:'plans',t:'file',label:'Joindre vos plans (images JPG / PNG)',max:3,if:function(v){return /^Oui/.test(v.plans_exist||'')}},
     {id:'veut_plans',t:'chk',label:'Conception de vos plans',opts:['Je souhaite aussi faire concevoir mes plans par Excellencia Building'],if:function(v){return /^Non/.test(v.plans_exist||'')}},
     {id:'permis',t:'sel',label:'Permis de construire',opts:['Déjà obtenu','À faire','Je ne sais pas']}]}],
  services:function(v){var s=['Construction d’une maison'];if((v.veut_plans||[]).length)s.push('Plan de maison');if(v.permis==='À faire')s.push('Permis de construire');return s},
  state:function(){return 'Nouveau projet'}},

 architecture:{label:'Architecture',emoji:'📐',sub:'Plans et conception',cat:'Architecture',color:'#12305e',
  titre:'Demande d’architecture',intro:'Plans, 3D, permis : dites-nous ce qu’il vous faut et ce que vous imaginez.',
  groups:[
   {title:'Ce dont vous avez besoin',fields:[
     {id:'prestations',t:'chk',label:'Prestations souhaitées',req:1,opts:['Plan de maison','Plan d’exécution','Modélisation 3D / rendu','Permis de construire','Relevé et plan d’une construction existante']},
     {id:'batiment',t:'sel',label:'Type de bâtiment',req:1,opts:OUVRAGES},
     {id:'niveaux',t:'sel',label:'Nombre de niveaux',half:1,opts:NIV},
     {id:'surface_bati',t:'num',label:'Surface souhaitée (m²)',half:1}]},
   {title:'Programme souhaité',fields:[
     {id:'chambres',t:'num',label:'Chambres',half:1},{id:'salons',t:'num',label:'Salons',half:1},{id:'sdb',t:'num',label:'Salles d’eau',half:1},
     {id:'autres_pieces',t:'area',label:'Autres pièces ou souhaits',ph:'Cuisine, garage, terrasse, bureau, boutique…'},
     {id:'style',t:'area',label:'Style ou inspirations',ph:'Moderne, toit plat, grandes baies vitrées…'},
     {id:'refs',t:'file',label:'Images d’inspiration (facultatif — jusqu’à 3)',max:3}]},
   {title:'Le terrain',fields:[
     {id:'length_m',t:'num',label:'Longueur (m)',half:1,ph:'ex. 25'},{id:'width_m',t:'num',label:'Largeur (m)',half:1,ph:'ex. 12'},
     {id:'surface',t:'num',label:'Superficie (m²) — calculée automatiquement, modifiable'},
     {id:'orientation',t:'sel',label:'Orientation de la façade',half:1,opts:['Nord','Sud','Est','Ouest','Je ne sais pas']},
     {id:'nature',t:'sel',label:'Nature du terrain',half:1,opts:PENTE},
     {id:'docs',t:'chk',label:'Documents que vous avez',opts:['Plan cadastral / titre','Levé topographique','Ancien plan de la maison']},
     {id:'photos',t:'file',label:'Photos du terrain (facultatif — jusqu’à 5)',max:5}]},
   {title:'Ce que vous voulez recevoir',fields:[
     {id:'livrables',t:'chk',label:'Livrables souhaités',opts:['PDF','Fichiers DWG (AutoCAD)','Impression papier','Vues 3D / rendus']}]}],
  services:function(v){return (v.prestations||[]).slice()},
  state:function(v){return (v.prestations||[]).indexOf('Relevé et plan d’une construction existante')>=0?ETAT_RENO:'Nouveau projet'}},

 metre:{label:'Métré & Devis',emoji:'🧮',sub:'Quantification et estimation',cat:'Architecture',color:'#0d3b80',
  titre:'Demande de métré & devis',intro:'Vos plans sont facultatifs : sans plan, décrivez simplement ce que vous voulez faire chiffrer.',
  groups:[
   {title:'Ce que vous voulez faire chiffrer',fields:[
     {id:'objet',t:'sel',label:'Objet du devis',req:1,opts:['Construction neuve','Rénovation / transformation','Un ou plusieurs corps d’état']},
     {id:'corps',t:'chk',label:'Corps d’état concernés',req:1,if:function(v){return /corps/.test(v.objet||'')},
       opts:['Gros œuvre / maçonnerie','Toiture / charpente','Étanchéité','Peinture','Carrelage / sols','Plomberie','Électricité','Menuiserie / vitrerie','Façade / enduit','Autre']},
     {id:'type_devis',t:'rad',label:'Type de devis',opts:['Estimation rapide','Devis détaillé avec métré']}]},
   {title:'Vos plans (facultatif)',fields:[
     {id:'plans_dispo',t:'rad',label:'Avez-vous des plans ?',opts:['J’ai des plans','Je n’ai pas de plans']},
     {id:'plans',t:'file',label:'Joindre vos plans — images JPG / PNG (facultatif)',max:5,hint:'PDF ou DWG ? Envoyez-les-nous par WhatsApp ou e-mail après votre demande, avec votre numéro client.',if:function(v){return /^J’ai/.test(v.plans_dispo||'')}},
     {id:'surface_bati',t:'num',label:'Surface approximative (m²)',half:1,if:function(v){return /^Je n’ai pas/.test(v.plans_dispo||'')}},
     {id:'niveaux',t:'sel',label:'Nombre de niveaux',half:1,opts:NIV,if:function(v){return /^Je n’ai pas/.test(v.plans_dispo||'')}},
     {id:'pieces',t:'num',label:'Nombre de pièces',half:1,if:function(v){return /^Je n’ai pas/.test(v.plans_dispo||'')}}]},
   {title:'Détaillez votre devis (facultatif)',fields:[
     {id:'postes',t:'lines',label:'Postes à chiffrer',hint:'Ex. : « Carrelage salon — 35 m² », « Peinture murs — 120 m² », « Porte en bois — 4 unités ».'},
     {id:'finition',t:'sel',label:'Niveau de finition',half:1,opts:FIN},
     {id:'materiaux',t:'sel',label:'Matériaux',half:1,opts:['Fournis par l’entreprise','Fournis par moi','À discuter']},
     {id:'usage',t:'sel',label:'Ce devis servira pour…',opts:['Mon budget personnel','Un dossier de banque','Un permis de construire','Un chantier à lancer','Autre']}]}],
  services:function(){return ['Devis / estimation / métré']},
  state:function(v){return /Rénovation/.test(v.objet||'')?ETAT_RENO:'Nouveau projet'}},

 renovation:{label:'Rénovation',emoji:'🛠️',sub:'Réhabilitation et entretien',cat:'BTP',color:'#8a5a00',
  titre:'Demande de rénovation',intro:'Cochez les travaux et ajoutez quelques photos : c’est souvent suffisant pour un premier devis.',
  groups:[
   {title:'Le bien à rénover',fields:[
     {id:'bien',t:'sel',label:'Type de bien',req:1,opts:['Maison','Appartement','Immeuble','Commerce / bureau','Autre']},
     {id:'age',t:'sel',label:'Âge approximatif',half:1,opts:['Moins de 5 ans','5 à 15 ans','15 à 30 ans','Plus de 30 ans','Je ne sais pas']},
     {id:'niveaux',t:'sel',label:'Nombre de niveaux',half:1,opts:NIV},
     {id:'surface_reno',t:'num',label:'Surface à rénover (m², approximative)'}]},
   {title:'Travaux souhaités',fields:[
     {id:'travaux',t:'chk',label:'Quels travaux ?',req:1,opts:['Toiture','Étanchéité','Peinture','Carrelage / sols','Plomberie','Électricité','Menuiserie / vitrerie','Façade','Fissures / structure','Extension','Clôture','Autre']},
     {id:'problemes',t:'chk',label:'Problèmes constatés',opts:['Fissures','Infiltrations d’eau','Humidité','Électricité vétuste','Fuites','Autre']}]},
   {title:'Conditions',fields:[
     {id:'occupe',t:'rad',label:'Le bien reste-t-il occupé pendant les travaux ?',opts:['Oui, il reste occupé','Non, il est libre']},
     {id:'visite',t:'rad',label:'Souhaitez-vous une visite sur place ?',opts:['Oui, une visite sur place','Non, pas nécessaire']},
     {id:'dispo',t:'area',label:'Vos disponibilités pour la visite',ph:'Jours et horaires qui vous conviennent',if:function(v){return /^Oui/.test(v.visite||'')}}]},
   {title:'Photos et plans',fields:[
     {id:'photos',t:'file',label:'Photos de l’existant (recommandées — jusqu’à 8)',max:8},
     {id:'plans',t:'file',label:'Plans existants, si vous en avez (images JPG / PNG)',max:3}]}],
  services:function(){return ['Rénovation']},
  state:function(){return ETAT_RENO}},

 autre:{label:'Autre demande',emoji:'💬',sub:'Vitrerie, conseil, expertise…',cat:'Divers',color:'#0f766e',
  titre:'Autre demande',intro:'Pour tout ce qui ne rentre pas dans les autres formulaires.',noCommon:1,
  groups:[{title:'Votre demande',fields:[
     {id:'objet',t:'text',label:'Objet de votre demande',req:1,ph:'ex. Vitrerie d’un commerce, expertise d’un bâtiment…'},
     {id:'note',t:'area',label:'Décrivez votre demande',req:1,ph:'Dites-nous ce dont vous avez besoin.'},
     {id:'photos',t:'file',label:'Photos (facultatif — jusqu’à 5)',max:5}]}],
  services:function(){return []},state:function(){return ''}}
};
var ORDER=['construction','architecture','metre','renovation','autre'];

var COMMON={title:'Budget et délai',fields:[
  {id:'budget',t:'text',label:'Budget estimé (facultatif)',half:1,ph:'ex. 25 000 USD'},
  {id:'delay',t:'sel',label:'Délai souhaité',half:1,opts:['Dès que possible','Sous 1 mois','Sous 3 mois','Sous 6 mois','Pas de contrainte']},
  {id:'note',t:'area',label:'Message / précisions (facultatif)',ph:'Tout ce qui nous aidera à bien comprendre votre besoin.'}]};
var YOU={title:'Vos coordonnées',fields:[
  {id:'name',t:'text',label:'Nom & prénom',req:1,ac:'name'},
  {id:'phone',t:'tel',label:'Téléphone / WhatsApp',req:1,ac:'tel',ph:'+243 …'},
  {id:'email',t:'email',label:'E-mail (facultatif)',ac:'email'},
  {id:'location',t:'text',label:'Lieu du projet (ville, commune, quartier)',req:1,ac:'off'}]};

/* ───────────── État ───────────── */
var cur=null,FILES={},LINES=[],F={},SES='',manualSurf=false;
try{SES=sessionStorage.getItem('exb_cs')||''}catch(e){}
if(!/^cs_[0-9a-f]{48}$/.test(SES))SES='';

/* ───────────── Rendu ───────────── */
function fieldHTML(f){
  var id='f_'+f.id,rq=f.req?' <i class="rq" title="obligatoire">*</i>':'',lab=f.label?'<label'+(f.t==='rad'||f.t==='chk'||f.t==='file'||f.t==='lines'?'':' for="'+id+'"')+'>'+esc(f.label)+rq+'</label>':'',inner='';
  if(f.t==='text'||f.t==='tel'||f.t==='email')inner='<input id="'+id+'" type="'+f.t+'" maxlength="'+(f.t==='email'?120:150)+'"'+(f.ph?' placeholder="'+esc(f.ph)+'"':'')+(f.ac&&f.ac!=='off'?' autocomplete="'+f.ac+'"':' autocomplete="off"')+'>';
  else if(f.t==='num')inner='<input id="'+id+'" type="text" inputmode="decimal" maxlength="10"'+(f.ph?' placeholder="'+esc(f.ph)+'"':'')+' autocomplete="off">';
  else if(f.t==='area')inner='<textarea id="'+id+'" maxlength="1200" rows="3"'+(f.ph?' placeholder="'+esc(f.ph)+'"':'')+'></textarea>';
  else if(f.t==='sel')inner='<select id="'+id+'"><option value="">— Choisir —</option>'+f.opts.map(function(o){return '<option>'+esc(o)+'</option>'}).join('')+'</select>';
  else if(f.t==='rad'||f.t==='chk')inner='<div class="pills" id="'+id+'" role="'+(f.t==='rad'?'radiogroup':'group')+'">'+f.opts.map(function(o){return '<label class="pill"><input type="'+(f.t==='rad'?'radio':'checkbox')+'" name="'+id+'" value="'+esc(o)+'"><span>'+esc(o)+'</span></label>'}).join('')+'</div>';
  else if(f.t==='file')inner='<input id="'+id+'" type="file" accept="image/jpeg,image/png,image/webp" multiple><div class="finfo" id="'+id+'_i">Aucun fichier.</div><div class="fprev" id="'+id+'_p"></div>';
  else if(f.t==='lines')inner='<div id="'+id+'" class="lines"></div><button type="button" class="add" id="'+id+'_add">＋ Ajouter un poste</button>';
  return '<div class="fld'+(f.half?' half':'')+'" data-f="'+f.id+'">'+lab+inner+(f.hint?'<p class="hint">'+esc(f.hint)+'</p>':'')+'<p class="fe" role="alert"></p></div>'
}
function groupHTML(g,k){return '<fieldset class="grp" data-g="'+k+'"><legend>'+esc(g.title)+'</legend><div class="gridf">'+g.fields.map(fieldHTML).join('')+'</div></fieldset>'}

function allFields(){
  var out=[];if(!cur)return out;
  TYPES[cur].groups.forEach(function(g){g.fields.forEach(function(f){out.push(f)})});
  if(!TYPES[cur].noCommon)COMMON.fields.forEach(function(f){out.push(f)});
  YOU.fields.forEach(function(f){out.push(f)});return out
}
function box(f){return document.querySelector('.fld[data-f="'+f.id+'"]')}
function val(f){
  var id='f_'+f.id;
  if(f.t==='rad'){var r=document.querySelector('#'+id+' input:checked');return r?r.value:''}
  if(f.t==='chk')return [].map.call(document.querySelectorAll('#'+id+' input:checked'),function(i){return i.value});
  if(f.t==='file')return FILES[f.id]||[];
  if(f.t==='lines')return LINES.filter(function(l){return l.d.trim()}).map(function(l){return l.d.trim()+(l.q?' — '+l.q+(l.u?' '+l.u:''):'')});
  var e=$(id);return e?String(e.value||'').trim():''
}
function values(){var v={};allFields().forEach(function(f){v[f.id]=val(f)});return v}
function visible(f,v){var b=box(f);return !!b&&(!f.if||!!f.if(v))}

function refresh(){
  var v=values();
  allFields().forEach(function(f){var b=box(f);if(b)b.hidden=!!(f.if&&!f.if(v))});
  /* pas de champs de mot de passe si le client est déjà connecté */
  var pw=$('pwBox');if(pw)pw.hidden=!!SES
}

/* ───────────── Fichiers (photos / plans réduits en JPEG avant envoi) ───────────── */
async function onFiles(f,input){
  var info=$('f_'+f.id+'_i'),prev=$('f_'+f.id+'_p'),fs=[].slice.call(input.files||[]).slice(0,f.max),out=[];
  info.textContent='Préparation…';prev.innerHTML='';
  for(var i=0;i<fs.length;i++){try{out.push(await EXBPdf.fileJpg(fs[i],900,.65))}catch(e){}}
  FILES[f.id]=out;
  info.innerHTML=out.length?'<span class="ok">✓ '+out.length+' image(s) prête(s).</span>'+((input.files||[]).length>f.max?' Maximum '+f.max+' : les premières sont gardées.':''):'Aucun fichier lisible (JPG, PNG ou WebP).';
  out.forEach(function(u){var im=new Image();im.src=u;im.alt='';prev.appendChild(im)})
}

/* ───────────── Postes du devis (métré) ───────────── */
var UNITES=['m²','m³','ml','unité','forfait'];
function drawLines(){
  var c=$('f_postes');if(!c)return;c.innerHTML='';
  LINES.forEach(function(l,i){
    var row=document.createElement('div');row.className='lrow';
    row.innerHTML='<input class="ld" type="text" maxlength="90" placeholder="Désignation (ex. Carrelage salon)" aria-label="Désignation">'
      +'<input class="lq" type="text" inputmode="decimal" maxlength="9" placeholder="Qté" aria-label="Quantité">'
      +'<select class="lu" aria-label="Unité">'+UNITES.map(function(u){return '<option>'+u+'</option>'}).join('')+'</select>'
      +'<button type="button" class="lx" aria-label="Retirer ce poste">✕</button>';
    var d=row.querySelector('.ld'),q=row.querySelector('.lq'),u=row.querySelector('.lu');d.value=l.d;q.value=l.q;u.value=l.u||'m²';
    d.oninput=function(){l.d=d.value};q.oninput=function(){l.q=q.value.replace(',','.')};u.onchange=function(){l.u=u.value};
    row.querySelector('.lx').onclick=function(){LINES.splice(i,1);drawLines()};
    c.appendChild(row)});
  var a=$('f_postes_add');if(a)a.hidden=LINES.length>=15
}

/* ───────────── Construction de la page ───────────── */
function choose(k,push){
  if(!TYPES[k])return;cur=k;FILES={};LINES=[];manualSurf=false;var T=TYPES[k];
  document.documentElement.style.setProperty('--accent',T.color);
  $('choose').hidden=true;$('f').hidden=false;$('done').hidden=true;
  $('tag').textContent=T.emoji+' '+T.label;$('ft').textContent=T.titre;$('fs').textContent=T.intro;
  YOU.fields.forEach(function(f){if(f.id==='location')f.req=(k==='autre')?0:1});
  var h=T.groups.map(function(g,i){return groupHTML(g,'t'+i)}).join('');
  if(!T.noCommon)h+=groupHTML(COMMON,'c');
  h+=groupHTML(YOU,'y');
  $('fields').innerHTML=h;
  /* mot de passe : créé ici, il sert à suivre les travaux depuis l'espace client */
  var y=document.querySelector('[data-g="y"] .gridf');
  y.insertAdjacentHTML('beforeend','<div id="pwBox" class="fld full"><div class="acct"><b>🔐 Votre espace client est créé automatiquement</b><p>Choisissez un mot de passe : avec votre numéro client (donné à l’écran suivant), il vous permet de suivre vos demandes, devis, plans et travaux. Aucun code à recevoir.</p></div>'
    +'<div class="gridf"><div class="fld half"><label for="pwd">Mot de passe <i class="rq">*</i></label><input id="pwd" type="password" minlength="8" maxlength="100" autocomplete="new-password" placeholder="8 caractères minimum"><p class="fe" role="alert"></p></div>'
    +'<div class="fld half"><label for="pwd2">Confirmer le mot de passe <i class="rq">*</i></label><input id="pwd2" type="password" maxlength="100" autocomplete="new-password"><p class="fe" role="alert"></p></div></div></div>');
  if(SES)$('sesNote').hidden=false;else $('sesNote').hidden=true;
  /* événements */
  allFields().forEach(function(f){
    var id='f_'+f.id,e=$(id);if(!e)return;
    if(f.t==='file')e.addEventListener('change',function(){onFiles(f,e)});
    else if(f.t==='rad'||f.t==='chk')e.addEventListener('change',refresh);
    else e.addEventListener(f.t==='sel'?'change':'input',function(){if(f.id==='surface')manualSurf=true;refresh()})
  });
  ['f_length_m','f_width_m'].forEach(function(i){var e=$(i);if(e)e.addEventListener('input',function(){
    var L=parseFloat(String(($('f_length_m')||{}).value||'').replace(',','.')),l=parseFloat(String(($('f_width_m')||{}).value||'').replace(',','.')),s=$('f_surface');
    if(s&&!manualSurf&&L>0&&l>0)s.value=String(Math.round(L*l*100)/100)})});
  var add=$('f_postes_add');if(add){add.onclick=function(){if(LINES.length<15){LINES.push({d:'',q:'',u:'m²'});drawLines()}};LINES.push({d:'',q:'',u:'m²'});drawLines()}
  refresh();$('msg').textContent='';$('send').disabled=false;
  document.title=T.titre+' — Excellencia Building';
  if(push!==false){try{history.replaceState(null,'','?type='+k)}catch(e){}}
  window.scrollTo(0,0)
}

/* ───────────── Validation ───────────── */
function validate(){
  var v=values(),first=null,ok=true;
  document.querySelectorAll('.fe').forEach(function(p){p.textContent=''});
  document.querySelectorAll('.bad').forEach(function(x){x.classList.remove('bad')});
  function bad(b,m){if(!b)return;var p=b.querySelector('.fe');if(p)p.textContent=m;b.classList.add('bad');ok=false;if(!first)first=b}
  allFields().forEach(function(f){
    var b=box(f);if(!b||b.hidden)return;
    var x=v[f.id],vide=(f.t==='chk')?!x.length:(f.t==='file'||f.t==='lines')?false:!x;
    if(f.req&&vide)bad(b,f.t==='chk'||f.t==='rad'?'Choisissez au moins une réponse.':'Ce champ est obligatoire.');
    if(f.id==='phone'&&x&&!/[0-9]{6,}/.test(x.replace(/\D/g,'')))bad(b,'Numéro de téléphone invalide.');
    if(f.id==='email'&&x&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))bad(b,'Adresse e-mail invalide.');
    if(f.id==='name'&&x&&x.length<2)bad(b,'Nom trop court.');
    if(f.t==='num'&&x&&!/^[0-9]+([.,][0-9]+)?$/.test(x))bad(b,'Entrez un nombre (ex. 25 ou 12,5).')
  });
  if(!SES){
    var p1=$('pwd'),p2=$('pwd2');
    if(p1.value.length<8)bad(p1.closest('.fld'),'8 caractères minimum.');
    else if(p1.value===(v.phone||'')||/^(12345678|password|motdepasse)$/i.test(p1.value))bad(p1.closest('.fld'),'Mot de passe trop simple.');
    if(p2.value!==p1.value)bad(p2.closest('.fld'),'Les deux mots de passe sont différents.')
  }
  if(first){first.scrollIntoView({behavior:'smooth',block:'center'});var i=first.querySelector('input,select,textarea');if(i)try{i.focus({preventScroll:true})}catch(e){}}
  return ok
}

/* ───────────── Données envoyées ───────────── */
var MAPPED={name:1,phone:1,email:1,location:1,length_m:1,width_m:1,surface:1,environment:1,budget:1,delay:1,note:1,photos:1,plans:1,refs:1};
function build(){
  var T=TYPES[cur],v=values(),d={type_demande:cur,category:T.cat,services:T.services(v),state:T.state(v),
    name:v.name,phone:v.phone,email:(v.email||'').toLowerCase(),location:v.location||'',
    length_m:v.length_m||'',width_m:v.width_m||'',surface:v.surface||'',environment:v.environment||'',terrain:'',
    budget:v.budget||'',delay:v.delay||'',note:''};
  var lines=[],terr=[],n=0;
  allFields().forEach(function(f){
    if(!visible(f,v))return;var x=v[f.id];
    if(f.t==='file'||f.id==='name'||f.id==='phone'||f.id==='email'||f.id==='location'||f.id==='note')return;
    var txt=Array.isArray(x)?x.join(', '):x;if(!txt)return;
    if(['nature','titre','acces','orientation','docs'].indexOf(f.id)>=0)terr.push(f.label.replace(/ — .*$/,'')+' : '+txt);
    if(!MAPPED[f.id]&&n<30){d[f.id]=Array.isArray(x)?x:txt;n++}
    lines.push(f.label.replace(/ — .*$/,'').replace(/\s*\(.*?\)\s*$/,'')+' : '+txt)});
  d.terrain=terr.join(' · ');
  var up=(v.note||'').trim();
  d.note=((TYPES[cur].label+' — ')+lines.join(' | ')+(up?' | Message : '+up:'')).slice(0,2800);
  return {data:d,lines:lines,v:v}
}

/* ───────────── Envoi ───────────── */
var ERR={mdp_court:'Mot de passe : 8 caractères minimum.',mdp_long:'Mot de passe trop long.',trop_de_demandes:'Le service est momentanément saturé. Réessayez plus tard.',nom_invalide:'Nom invalide.',telephone_invalide:'Numéro de téléphone invalide.',donnees_trop_longues:'Votre demande est trop longue : raccourcissez les textes ou retirez des postes.',donnees_invalides:'Demande invalide.'};
async function rpc(fn,body){
  var c=cfg();if(!c)throw new Error('Le service d’envoi n’est pas encore configuré.');
  var h={apikey:c.key,'Content-Type':'application/json'};if(/^eyJ/.test(c.key))h.Authorization='Bearer '+c.key;
  var r=await fetch(c.url.replace(/\/+$/,'')+'/rest/v1/rpc/'+fn,{method:'POST',headers:h,body:JSON.stringify(body)});
  var j=null;try{j=await r.json()}catch(e){}
  if(!r.ok){var m=(j&&(j.message||j.hint))||'';var e=new Error(ERR[m]||('Envoi impossible (code '+r.status+(m?' : '+m:'')+'). Réessayez.'));e.status=r.status;e.raw=m;e.code=j&&j.code;throw e}
  return j
}
function absent(e){return e&&(e.status===404||e.code==='PGRST202'||/could not find the function|does not exist/i.test(e.raw||''))}

function pdfRows(b,mat){
  var d=b.data,rows=[['Numéro de suivi',mat||'—'],['Type de demande',TYPES[cur].label],['Nom & prénom',d.name],['Téléphone',d.phone],['E-mail',d.email||'—'],['Lieu du projet',d.location||'—']];
  b.lines.forEach(function(l){var i=l.indexOf(' : ');rows.push([l.slice(0,i),l.slice(i+3)])});
  var m=(b.v.note||'').trim();if(m)rows.push(['Message',m]);rows.push(['Date de la demande',new Date().toLocaleDateString('fr-FR')]);return rows
}
async function makePdf(b,mat,images){
  var o=(window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,''));
  var blob=await EXBPdf.make({titre:'FICHE DE DEMANDE — '+TYPES[cur].label.toUpperCase(),sousTitre:'Numéro : '+(mat||'—')+' · émise le '+new Date().toLocaleDateString('fr-FR'),
    rows:pdfRows(b,mat),notes:['Suivez votre demande, vos devis, plans et travaux dans votre espace client : '+o+'espace-client.html','Conservez cette fiche.'],
    sign:false,images:images||[],footer:'Excellencia Building · '+o+'espace-client.html'});
  EXBPdf.save(blob,'Fiche-Demande-'+(mat||'nouvelle')+'.pdf')
}

async function submit(e){
  e.preventDefault();var msg=$('msg'),btn=$('send');msg.textContent='';
  if($('bot_field').value){showDone({fake:1});return}
  if(!validate())return;
  try{var _t=+localStorage.getItem('exb_last_send')||0;if(Date.now()-_t<45000){msg.textContent='Merci de patienter quelques secondes avant un nouvel envoi.';return}}catch(x){}
  btn.disabled=true;btn.textContent='Envoi en cours…';
  var b=build(),pwd=SES?'':$('pwd').value,res=null,fallback=false;
  try{
    try{res=await rpc('client_demande_envoyer',{p_data:b.data,p_mdp:pwd||null,p_session:SES||null})}
    catch(er){
      if(!absent(er))throw er;
      /* SQL V200 pas encore exécuté : on envoie la demande comme avant (sans compte automatique) */
      fallback=true;res=await rpc('demande_projet_envoyer',{p_data:b.data})
    }
    try{localStorage.setItem('exb_last_send',Date.now())}catch(x){}
    var mat=res&&res.matricule||'',imgs=[],vv=values();allFields().forEach(function(f){if(f.t==='file'&&visible(f,vv))imgs=imgs.concat(FILES[f.id]||[])});imgs=imgs.slice(0,8);
    if(mat&&imgs.length){try{await rpc('btp_suivi_enregistrer',{p_matricule:mat,p_phone:b.data.phone,p_name:b.data.name,p_data:b.data,p_photos:imgs})}catch(x){}}
    var logged=false;
    if(res&&res.compte&&mat&&pwd){
      try{var L=await rpc('client_connexion',{p_matricule:mat,p_mdp:pwd});
        if(L&&L.ok&&L.session&&!L.doit_changer){try{sessionStorage.setItem('exb_cs',L.session);sessionStorage.setItem('exb_cm',mat)}catch(x){}logged=true}}catch(x){}
    }
    showDone({mat:mat,compte:!!(res&&res.compte),deja:!!(res&&res.deja),session:!!(res&&res.session),logged:logged,fallback:fallback,b:b,imgs:imgs})
  }catch(er){msg.textContent=(er&&er.message)||'Envoi impossible. Vérifiez votre connexion et réessayez.';btn.disabled=false;btn.textContent='Envoyer ma demande'}
}

function showDone(o){
  $('f').hidden=true;$('choose').hidden=true;$('done').hidden=false;window.scrollTo(0,0);
  if(o.fake)return;
  var matBox=$('dMat'),go=$('dGo'),t=$('dTitle'),tx=$('dText');
  t.textContent='Demande envoyée ✓';
  if(o.session){tx.textContent='Votre demande a été ajoutée à votre espace client. Nous reviendrons vers vous très vite.';matBox.hidden=true;go.textContent='Retour à mon espace';go.href='portail.html'}
  else if(o.compte){
    tx.textContent='Votre espace client est prêt. Retrouvez-y votre demande, puis vos devis, plans, factures et l’avancement des travaux.';
    matBox.hidden=false;$('dMatV').textContent=o.mat;$('dMatH').textContent='Votre numéro client — il sert d’identifiant avec le mot de passe que vous venez de choisir. Notez-le ou gardez la fiche PDF.';
    go.textContent='Accéder à mon espace';go.href=o.logged?'portail.html':'espace-client.html'}
  else if(o.deja){
    tx.textContent='Votre demande est enregistrée. Un espace client existe déjà pour ce numéro de téléphone : connectez-vous avec votre numéro client habituel.';matBox.hidden=true;go.textContent='Me connecter';go.href='espace-client.html'}
  else{
    tx.textContent='Votre demande a bien été reçue. Excellencia Building l’étudiera et vous contactera.'+(o.fallback?' Votre espace client sera activé par l’entreprise.':'');
    matBox.hidden=!o.mat;if(o.mat){$('dMatV').textContent=o.mat;$('dMatH').textContent='Votre numéro de suivi. Conservez-le avec la fiche PDF.'}
    go.textContent='Accéder à l’espace client';go.href='espace-client.html'}
  $('dPdf').onclick=function(){makePdf(o.b,o.mat,o.imgs).catch(function(){$('dPdfE').textContent='Fiche PDF indisponible pour le moment.'})};
  if(o.mat)makePdf(o.b,o.mat,o.imgs).catch(function(){})
}

/* ───────────── Démarrage ───────────── */
function start(){
  var box=$('tiles');
  var IMG={construction:'tuile-construction',architecture:'tuile-architecture',metre:'tuile-metre-devis',renovation:'tuile-renovation'},ARW='<svg class="ic" viewBox="0 0 24 24" style="width:22px;height:22px;stroke-width:2.6"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  box.innerHTML=ORDER.map(function(k){var T=TYPES[k];return '<a class="tile" href="?type='+k+'" data-k="'+k+'">'+(IMG[k]?'<img src="portail-img/'+IMG[k]+'.jpg" alt="" loading="lazy">':'<span class="em" aria-hidden="true">'+T.emoji+'</span>')+(IMG[k]?'':'<span class="txt">')+'<h3>'+esc(T.label)+'</h3><p>'+esc(T.sub)+'</p>'+(IMG[k]?'':'</span>')+'<span class="go" aria-hidden="true">'+ARW+'</span></a>'}).join('');
  [].forEach.call(box.querySelectorAll('.tile'),function(a){a.addEventListener('click',function(ev){ev.preventDefault();choose(a.getAttribute('data-k'))})});
  $('f').addEventListener('submit',submit);
  $('chg').addEventListener('click',function(){$('f').hidden=true;$('choose').hidden=false;cur=null;try{history.replaceState(null,'','demande.html')}catch(e){};window.scrollTo(0,0)});
  $('again').addEventListener('click',function(){location.href='demande.html'});
  var q=(location.search.match(/[?&]type=([a-z]+)/)||[])[1];
  if(q&&TYPES[q])choose(q,false)
}
document.addEventListener('DOMContentLoaded',start);
window.EXBDemande={types:TYPES,build:function(){return build()}};
})();
