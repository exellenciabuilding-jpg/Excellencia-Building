'use strict';
/* Adaptateur Supabase testé contre une imitation en mémoire de PostgREST / Auth / Storage (fidélité limitée :
 * vérifie les appels, les en-têtes, l'appartenance et le flux complet — PAS la sécurité RLS réelle, à valider sur votre projet). */
const test = require('node:test'), assert = require('node:assert/strict'), http = require('http');
const { start, pdfText } = require('./helpers');

function mockSupabase() {
  const users = { tokA: { id: 'u1', email: 'a@x' }, tokB: { id: 'u2', email: 'b@x' }, tokV: { id: 'u3', email: 'v@x' } };
  const membres = [{ org_id: 'org-1', user_id: 'u1', role: 'admin', depuis: 1 }, { org_id: 'org-2', user_id: 'u2', role: 'admin', depuis: 1 }, { org_id: 'org-1', user_id: 'u3', role: 'lecteur', depuis: 2 }];
  const T = { doc_profils: [], doc_parametres: [], doc_modeles: [], doc_historique: [] }, counters = {}, files = {}, calls = [];
  let seq = 0; const state = { expired: false };
  const srv = http.createServer((req, res) => {
    const chunks = []; req.on('data', (c) => chunks.push(c)); req.on('end', () => {
      const raw = Buffer.concat(chunks), url = new URL(req.url, 'http://x'), p = url.pathname, tok = (req.headers.authorization || '').replace('Bearer ', ''), user = users[tok];
      calls.push(req.method + ' ' + p); const J = (s, b) => { res.writeHead(s, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(b)); };
      if (!req.headers.apikey) return J(401, { message: 'no key' });
      if (p === '/auth/v1/user') return user ? J(200, user) : J(401, {});
      if (!user) return J(401, {});
      const mem = membres.filter((m) => m.user_id === user.id).map((m) => m.org_id), eq = (k) => { const v = url.searchParams.get(k); return v && v.startsWith('eq.') ? v.slice(3) : null; };
      if (p === '/rest/v1/rpc/licence_ecriture_ok') return J(200, !state.expired);
      if (p === '/rest/v1/membres') return J(200, membres.filter((m) => m.user_id === eq('user_id')).sort((a, b) => a.depuis - b.depuis).map((m) => ({ org_id: m.org_id, role: m.role })));
      const role = (org) => (membres.find((m) => m.org_id === org && m.user_id === user.id) || {}).role;
      if (p === '/rest/v1/rpc/doc_prochain_numero') { const b = JSON.parse(raw); if (!['admin', 'editeur'].includes(role(b.p_org))) return J(403, { message: 'acces refuse' }); const k = b.p_org + b.p_type + b.p_annee; counters[k] = (counters[k] || 0) + 1; return J(200, counters[k]); }
      const m = /^\/rest\/v1\/(doc_\w+)$/.exec(p);
      if (m) {
        const tb = T[m[1]], body = raw.length ? JSON.parse(raw) : null, org = eq('org_id') || (body && body.org_id);
        if (!mem.includes(org) && !(m[1] === 'doc_historique' && eq('id'))) return J(403, { message: 'rls' });
        if (req.method === 'GET') { let r = tb.filter((x) => (!eq('org_id') || x.org_id === eq('org_id')) && (!eq('id') || x.id === eq('id')) && (!eq('supprime') || String(x.supprime) === eq('supprime'))); return J(200, r); }
        if (req.method === 'POST') { if (!['admin', 'editeur'].includes(role(org))) return J(403, { message: 'rls' }); const key = m[1] === 'doc_modeles' ? ['org_id', 'id'] : ['org_id']; let row = Object.assign({}, body); if (m[1] === 'doc_historique') { row.id = 'doc' + ++seq; row.cree_le = new Date().toISOString(); row.supprime = false; tb.push(row); return J(201, [row]); }
          const i = tb.findIndex((x) => key.every((k) => x[k] === row[k])); if (i >= 0) tb[i] = Object.assign(tb[i], row); else tb.push(row); return J(201, [tb[i >= 0 ? i : tb.length - 1]]); }
        if (req.method === 'PATCH' || req.method === 'DELETE') { const hit = tb.filter((x) => x.org_id === (eq('org_id') || x.org_id) && (!eq('id') || x.id === eq('id'))); if (hit.some((x) => !['admin', 'editeur'].includes(role(x.org_id)))) return J(403, {}); if (req.method === 'PATCH') hit.forEach((x) => Object.assign(x, body)); else hit.forEach((x) => tb.splice(tb.indexOf(x), 1)); return J(200, hit); }
      }
      const s = /^\/storage\/v1\/object\/documents-generes\/(.+)$/.exec(p);
      if (s) { const org = s[1].split('/')[0]; if (!mem.includes(org)) return J(403, {}); if (req.method === 'POST') { files[s[1]] = raw; return J(200, { Key: s[1] }); } if (files[s[1]]) { res.writeHead(200, { 'Content-Type': 'application/pdf' }); return res.end(files[s[1]]); } return J(404, {}); }
      J(404, { message: 'inconnu ' + p });
    });
  });
  return { srv, T, files, calls, state };
}

test('stockage Supabase : profil, numérotation, historique, régénération, isolation', async () => {
  const M = mockSupabase(); await new Promise((r) => M.srv.listen(0, '127.0.0.1', r));
  const S = await start({ dev: false, storage: 'supabase', supabaseUrl: 'http://127.0.0.1:' + M.srv.address().port, supabaseAnonKey: 'anon' });
  try {
    assert.equal((await S.call('GET', '/profile')).status, 401);
    assert.equal((await S.call('GET', '/profile', { token: 'mauvais' })).status, 401);
    const me = await S.call('GET', '/me', { token: 'tokA' }); assert.equal(me.body.org_id, 'org-1'); assert.equal(me.body.role, 'admin');
    assert.equal((await S.call('GET', '/profile', { token: 'tokA', headers: { 'X-Org-Id': 'org-2' } })).status, 403, 'organisation étrangère refusée');
    assert.equal((await S.call('PUT', '/profile', { token: 'tokV', body: { profile: { name: 'X' } } })).status, 403, 'lecteur : pas d’écriture');
    assert.equal((await S.call('PUT', '/profile', { token: 'tokA', body: { profile: { name: 'Org Un', phones: ['+1'] } } })).status, 200);
    assert.equal((await S.call('PUT', '/profile', { token: 'tokB', body: { profile: { name: 'Org Deux' } } })).status, 200);
    const r = await S.call('POST', '/render', { token: 'tokA', body: { type: 'recu', data: { payeur: 'P', montant: 5, motif: 'm' } } }); assert.equal(r.status, 200); assert.match(r.headers.get('x-doc-number'), /^REC-\d{4}-0001$/);
    assert.ok((await pdfText(r.body)).text.includes('Org Un')); assert.equal(Object.keys(M.files).length, 1); assert.ok(Object.keys(M.files)[0].startsWith('org-1/'), 'PDF rangé dans le dossier de l’organisation');
    const id = r.headers.get('x-doc-id'); assert.equal((await S.call('GET', '/documents', { token: 'tokV' })).body.items.length, 1, 'le lecteur consulte l’historique');
    assert.equal((await S.call('GET', '/documents', { token: 'tokB' })).body.items.length, 0, 'org-2 ne voit rien de org-1');
    assert.equal((await S.call('GET', '/documents/' + id + '/pdf', { token: 'tokB' })).status, 404);
    await S.call('PUT', '/profile', { token: 'tokA', body: { profile: { name: 'Org Un Renommée' } } });
    const g = await S.call('POST', '/documents/' + id + '/regenerate', { token: 'tokA' }); assert.equal(g.status, 200); assert.equal(g.headers.get('x-doc-number'), r.headers.get('x-doc-number')); assert.ok((await pdfText(g.body)).text.includes('Org Un Renommée'));
    assert.equal((await S.call('POST', '/render', { token: 'tokV', body: { type: 'recu', data: { payeur: 'P', montant: 5, motif: 'm' } } })).status, 403);
    assert.equal((await S.call('DELETE', '/documents/' + id, { token: 'tokA' })).status, 200); assert.equal((await S.call('GET', '/documents', { token: 'tokA' })).body.items.length, 0);
  } finally { await S.close(); M.srv.close(); }
});

test('licence : expirée = lecture seule (aperçu, historique OK ; création de document et modification bloquées), puis renouvelée', async () => {
  const M = mockSupabase(); await new Promise((r) => M.srv.listen(0, '127.0.0.1', r));
  const S = await start({ dev: false, storage: 'supabase', supabaseUrl: 'http://127.0.0.1:' + M.srv.address().port, supabaseAnonKey: 'anon' });
  const RECU = { type: 'recu', data: { payeur: 'P', montant: 5, motif: 'm' } };
  try {
    assert.equal((await S.call('PUT', '/profile', { token: 'tokA', body: { profile: { name: 'Org Un' } } })).status, 200);
    assert.equal((await S.call('POST', '/render', { token: 'tokA', body: RECU })).status, 200, 'licence valide : PDF fabriqué');
    M.state.expired = true;
    const r = await S.call('POST', '/render', { token: 'tokA', body: RECU });
    assert.equal(r.status, 402, 'licence expirée : création refusée'); assert.match(r.body.error, /Licence expirée/);
    assert.equal((await S.call('POST', '/render', { token: 'tokA', body: Object.assign({ format: 'html' }, RECU) })).status, 200, 'l’aperçu reste possible');
    assert.equal((await S.call('PUT', '/profile', { token: 'tokA', body: { profile: { name: 'Autre' } } })).status, 402, 'profil non modifiable');
    assert.equal((await S.call('GET', '/documents', { token: 'tokA' })).body.items.length, 1, 'l’historique reste consultable');
    assert.equal((await S.call('GET', '/profile', { token: 'tokA' })).status, 200, 'le profil reste lisible');
    M.state.expired = false;
    assert.equal((await S.call('POST', '/render', { token: 'tokA', body: RECU })).status, 200, 'licence renouvelée : tout repart');
  } finally { await S.close(); M.srv.close(); }
});
