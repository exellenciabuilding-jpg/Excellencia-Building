#!/bin/bash
# Sauvegarde manuelle de la base Supabase (ordinateur avec PostgreSQL 15+ installé : client pg_dump).
# Usage :  SUPABASE_DB_URL='postgresql://...' ./scripts/sauvegarde-supabase.sh      → crée sauvegarde-AAAAMMJJ.dump (NON chiffré : rangez-le en lieu sûr)
# Restauration (dans une base VIDE de test, jamais directement sur la production) :
#   pg_restore --no-owner --dbname "$URL_BASE_DE_TEST" sauvegarde-AAAAMMJJ.dump
# Fichier chiffré venant de GitHub :  openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in sauvegarde-AAAAMMJJ.dump.enc -out sauvegarde.dump
set -e
: "${SUPABASE_DB_URL:?Définissez SUPABASE_DB_URL}"
OUT="sauvegarde-$(date -u +%Y%m%d).dump"
pg_dump "$SUPABASE_DB_URL" --schema=public --no-owner --no-privileges --format=custom --file="$OUT"
ls -l "$OUT"
