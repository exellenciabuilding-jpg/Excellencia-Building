# Excellencia Building

Logiciel de gestion pour le BTP, l'architecture, l'ingénierie et la formation — application web/Android/Windows, base partagée Supabase, serveur PDF.

- `site/` — l'application (HTML/JS, hors connexion possible) et les scripts SQL Supabase (`site/supabase/`)
- `docengine-server/` — serveur PDF (Node + Chromium) ; `site/docengine/` — moteur de documents partagé
- `render.yaml` — déploiement du serveur PDF · `.github/workflows/` — contrôles automatiques et sauvegarde nocturne
- **`docs/DEPLOIEMENT-SAAS.md` — mise en service pour vendre à plusieurs entreprises (commencer ici)**
- Autres notes : `LISEZ-MOI-*.md`, `DOCENGINE-LISEZ-MOI.md`

Ne déposez jamais de clé secrète (`service_role`, mot de passe de base) dans ce dépôt.
