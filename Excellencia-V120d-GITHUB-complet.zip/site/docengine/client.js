/* Excellencia Building — MOTEUR DOCUMENTAIRE UNIVERSEL · API navigateur « EXBDoc » (V118)
 *
 * UNE seule porte d'entrée pour tous les modules (Devis, Facturation, Formations, Séances, Géotechnique, Chantiers…) :
 *     EXBDoc.generate('devis', { client_nom:'…', lignes:[…] })            → PDF (serveur Chromium) ou impression locale
 *     EXBDoc.profile.get()                                                → identité documentaire de l'organisation
 *
 * Deux modes, mêmes modèles, même mise en page :
 *   • CONNECTÉ  (adresse du serveur du moteur configurée + compte en ligne) : profil, modèles, numérotation et historique
 *     sont centralisés par organisation ; PDF produit par Chromium/Playwright (champs interactifs, pagination soignée).
 *   • LOCAL     (hors connexion / pas de serveur) : profil et historique sur l'appareil ; le document est envoyé au système
 *     d'impression existant (EXBPrint : PDF direct sous Windows, impression Android, aperçu navigateur).
 * Synchronisation avec l'existant : enregistrer le profil met aussi à jour EXBId (devis, reçus, PDF historiques) et EXB_BRAND.
 */
(function (w) {
  'use strict';
  if (w.EXBDoc) return;
  var C = w.EXBDocCore; if (!C) { console.error('EXBDoc : core.js / templates.js doivent être chargés avant client.js'); return; }
  var K_PROFILE = 'EXB_DOCPROFILE_V1', K_HIST = 'EXB_DOCHIST_V1', K_COUNT = 'EXB_DOCCOUNT_V1', K_MODELS = 'EXB_DOCMODELS_V1', K_URL = 'EXB_DOCENGINE_URL', K_SET = 'EXB_DOCSETTINGS_V1', K_PUB = 'EXB_DOCPUBLIC_V1';
  var listeners = [];

  function lsGet(k, def) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? def : v; } catch (e) { return def; } }
  function lsSet(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function say(m, k) { try { if (typeof w.notify === 'function') return w.notify(m, k || 'info', 6000); } catch (e) {} try { console.log(m); } catch (e2) {} }

  /* ───────── connexion au serveur ───────── */
  function serverUrl() { var u = w.EXB_DOCENGINE_URL || lsGet(K_URL, ''); return String(u || '').replace(/\/+$/, ''); }
  function setServerUrl(u) { lsSet(K_URL, String(u || '').trim().replace(/\/+$/, '')); }
  function token() { try { if (w.EXB_DOC_TOKEN) return typeof w.EXB_DOC_TOKEN === 'function' ? w.EXB_DOC_TOKEN() : w.EXB_DOC_TOKEN; if (w.exbSb && w.exbSb.token) return w.exbSb.token(); var s = lsGet('EXB_SB_TOKEN', null); if (s && s.access_token && (!s.exp || s.exp > Date.now())) return s.access_token; } catch (e) {} return ''; }
  function connected() { return !!(serverUrl() && token() && w.navigator.onLine !== false); }
  function api(method, path, body, raw) {
    var h = { Accept: 'application/json' }, t = token(); if (t) h.Authorization = 'Bearer ' + t; if (body !== undefined) h['Content-Type'] = 'application/json';
    return w.fetch(serverUrl() + '/api/v1' + path, { method: method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) }).then(function (r) {
      if (raw && r.ok) return r;
      return r.text().then(function (tx) { var j = {}; try { j = JSON.parse(tx); } catch (e) {} if (!r.ok) { var e = new Error(j.error || ('Erreur ' + r.status)); e.status = r.status; e.details = j.details; throw e; } return j; });
    });
  }

  /* ───────── profil documentaire : une seule source, réutilisée par TOUS les modules ───────── */
  function legacyIdentity() {
    var I = {}, B = w.EXB_BRAND || {}; try { if (w.EXBId) I = w.EXBId.get(); } catch (e) {}
    var logo = I.logo && I.logo.indexOf('data:') === 0 ? I.logo : (B.logo && String(B.logo).indexOf('data:') === 0 ? B.logo : '');
    return {
      name: I.name || B.name || '', tagline: I.tagline || B.tagline || '', logo: logo,
      address: I.address || B.address || '', city: I.city || '', country: I.country || '',
      phones: [I.phone || B.phone].filter(Boolean), emails: [I.email || B.email].filter(Boolean),
      legal: I.legal || '', colors: { primary: B.primary || '#173565', accent: B.accent || '#c49a38', secondary: B.secondary || '#0f4aa8' },
      signatory: { name: I.dg || '', role: I.dgRole || 'Directeur Général' }
    };
  }
  var cache = null;
  function profileGet() {
    if (cache) return cache;
    var saved = lsGet(K_PROFILE, null);
    cache = C.normalizeProfile(saved && saved.name ? saved : legacyIdentity());
    return cache;
  }
  function pushToLegacy(p) {
    /* synchronisation vers l'identité historique : devis, reçus, certificats et anciens PDF reprennent les nouvelles valeurs */
    try {
      if (w.EXBId && w.EXBId.setExtra) w.EXBId.setExtra({ phone: p.phones[0] || '', email: p.emails[0] || '', address: p.address, legal: p.ids.map(function (i) { return i.label + ' : ' + i.value; }).join('\n') || p.legal, dg: p.signatory.name, dgRole: p.signatory.role, city: p.city });
    } catch (e) {}
    try {
      var raw = lsGet('EXB_BRAND_V1', null) || { brand: {}, done: true }; raw.brand = raw.brand || {};
      Object.assign(raw.brand, { name: p.name || raw.brand.name, tagline: p.tagline, primary: p.colors.primary, accent: p.colors.accent, secondary: p.colors.secondary, phone: p.phones[0] || '', email: p.emails[0] || '', address: p.address });
      if (p.logo) raw.brand.logo = p.logo; lsSet('EXB_BRAND_V1', raw);
      if (w.EXB_BRAND) { Object.assign(w.EXB_BRAND, raw.brand); }
    } catch (e) {}
  }
  function emit() { listeners.slice().forEach(function (f) { try { f(profileGet()); } catch (e) {} }); try { w.dispatchEvent(new CustomEvent('exbdoc:profile', { detail: profileGet() })); } catch (e) {} }
  async function profileSave(p) {
    var n = C.normalizeProfile(p); if (!n.name) throw new Error('Le nom de l’organisation est obligatoire.');
    n.updated_at = new Date().toISOString(); lsSet(K_PROFILE, n); cache = n; pushToLegacy(n);
    var remote = false;
    if (connected()) { try { var r = await api('PUT', '/profile', { profile: n }); cache = C.normalizeProfile(r.profile); lsSet(K_PROFILE, cache); remote = true; } catch (e) { if (e.status === 403) throw e; say('Profil enregistré sur cet appareil ; synchronisation serveur différée (' + e.message + ').', 'warn'); } }
    emit(); return { profile: cache, remote: remote };
  }
  async function profileLoad() {
    if (connected()) { try { var r = await api('GET', '/profile'); if (r.profile && r.profile.name) { cache = C.normalizeProfile(r.profile); lsSet(K_PROFILE, cache); pushToLegacy(cache); emit(); } return { profile: profileGet(), role: r.role, remote: true }; } catch (e) {} }
    return { profile: profileGet(), role: 'admin', remote: false };
  }

  /* ───────── modèles personnalisés, réglages ───────── */
  async function modelsList() { if (connected()) { try { return (await api('GET', '/models')).models; } catch (e) {} } return lsGet(K_MODELS, []); }
  async function modelSave(m) {
    if (connected()) return (await api('PUT', '/models', { model: m })).model;
    var all = lsGet(K_MODELS, []); m.id = m.id || 'm' + Date.now().toString(36); var i = all.findIndex(function (x) { return x.id === m.id; }); if (i >= 0) all[i] = m; else all.push(m); lsSet(K_MODELS, all); return m;
  }
  async function modelDelete(id) { if (connected()) return api('DELETE', '/models/' + encodeURIComponent(id)); lsSet(K_MODELS, lsGet(K_MODELS, []).filter(function (x) { return x.id !== id; })); return { ok: true }; }
  var DEFAULT_SET = { permissions: { profile_edit: ['admin'], models_edit: ['admin', 'editeur'], generate: ['admin', 'editeur'], history_read: ['admin', 'editeur', 'lecteur'], history_delete: ['admin'], settings_edit: ['admin'] }, numbering: { pattern: '{P}-{Y}-{N}', pad: 4, prefixes: {} }, default_layout: 'classique' };
  async function settingsGet() { if (connected()) { try { return (await api('GET', '/settings')).settings; } catch (e) {} } return Object.assign({}, DEFAULT_SET, lsGet(K_SET, {})); }
  async function settingsSave(s) { if (connected()) return (await api('PUT', '/settings', { settings: s })).settings; lsSet(K_SET, s); return s; }

  /* ───────── numérotation et historique locaux ───────── */
  function localNumber(type, st) {
    var d = C.describe(type), y = new Date().getFullYear(), c = lsGet(K_COUNT, {}), k = type + ':' + y; c[k] = (c[k] || 0) + 1; lsSet(K_COUNT, c);
    var prefixes = (st && st.numbering && st.numbering.prefixes) || {};
    return C.numberFormat(prefixes[type] || d.prefix, c[k], y, st && st.numbering);
  }
  function localHistAdd(rec) { var h = lsGet(K_HIST, []); h.unshift(rec); lsSet(K_HIST, h.slice(0, 300)); }

  /* ───────── génération ───────── */
  function download(blob, name) { var a = w.document.createElement('a'); a.href = w.URL.createObjectURL(blob); a.download = name; w.document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); w.URL.revokeObjectURL(a.href); }, 3000); }
  function openBlob(blob) { var u = w.URL.createObjectURL(blob); try { w.open(u, '_blank'); } catch (e) {} setTimeout(function () { w.URL.revokeObjectURL(u); }, 60000); }

  /* generate(type, data, opts)
   *   opts.model_id · opts.options (présentation) · opts.interactive · opts.source ('seances', 'devis'…) · opts.action: 'download'|'open'|'none'|'print'
   *   opts.local: true force le mode local · opts.landscape non nécessaire (déduit du modèle)
   * Retourne { via:'server'|'local', number, filename, blob?, id? } */
  async function generate(type, data, opts) {
    opts = opts || {}; var d = C.describe(type); if (!d) throw new Error('Type de document inconnu : ' + type);
    var action = opts.action || 'download';
    if (!opts.local && connected()) {
      try {
        var res = await api('POST', '/render', { type: type, data: data, model_id: opts.model_id, options: opts.options, interactive: !!opts.interactive, source: opts.source || 'app', save: opts.save, numbering: opts.numbering }, true);
        var blob = await res.blob(), cd = res.headers.get('Content-Disposition') || '', name = (/filename="([^"]+)"/.exec(cd) || [])[1] || type + '.pdf';
        if (action === 'download') download(blob, name); else if (action === 'open' || action === 'print') openBlob(blob);
        return { via: 'server', number: res.headers.get('X-Doc-Number') || '', id: res.headers.get('X-Doc-Id') || '', filename: name, blob: blob };
      } catch (e) { if (e.status && e.status < 500 && e.status !== 0) throw e; say('Serveur documentaire indisponible : génération locale à la place.', 'warn'); }
    }
    return generateLocal(type, data, opts);
  }
  async function generateLocal(type, data, opts) {
    var st = lsGet(K_SET, DEFAULT_SET), model = null, options = Object.assign({ layout: st.default_layout || 'classique' }, opts.options || {});
    if (opts.model_id) { model = lsGet(K_MODELS, []).find(function (m) { return m.id === opts.model_id; }); if (model) options = Object.assign({}, model.options, opts.options || {}); }
    var number = opts.numbering === false || opts.preview ? (opts.preview ? 'APERÇU' : '') : localNumber(type, st);
    var r = C.render(type, data, { profile: profileGet(), options: options, number: number, interactive: false, mode: 'print' });
    if (!opts.preview) localHistAdd({ id: 'l' + Date.now().toString(36), type: type, number: number, title: r.title, subject: (r.data.objet || r.data.titre || r.data.client_nom || r.data.beneficiaire || r.data.formation || ''), created_at: new Date().toISOString(), source: opts.source || 'app', local: true, payload: { data: data, options: options } });
    if (opts.action !== 'none') printHtml(r.title, r.html, r.page && r.page.orientation === 'landscape');
    return { via: 'local', number: number, filename: r.filename, html: r.html, title: r.title };
  }
  function printHtml(title, html, landscape) {
    if (w.EXBPrint && w.EXBPrint.html) return w.EXBPrint.html(title, html, { landscape: landscape });
    var f = w.document.createElement('iframe'); f.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0;z-index:99999;background:#fff'; f.srcdoc = html; w.document.body.appendChild(f);
    f.onload = function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {} }; setTimeout(function () { var b = w.document.createElement('button'); b.textContent = '✕ Fermer'; b.style.cssText = 'position:fixed;top:8px;right:8px;z-index:100000;padding:8px 14px'; b.onclick = function () { f.remove(); b.remove(); }; w.document.body.appendChild(b); }, 200);
  }
  /* Aperçu HTML exact (même rendu que le PDF) — serveur si connecté, sinon local ; n'utilise aucun numéro. */
  async function preview(type, data, opts) {
    opts = opts || {};
    if (!opts.local && connected()) { try { var r = await api('POST', '/render', { type: type, data: data, model_id: opts.model_id, options: opts.options, format: 'html', interactive: false }); return r.html; } catch (e) { if (e.status && e.status < 500) throw e; } }
    var st = lsGet(K_SET, DEFAULT_SET), options = Object.assign({ layout: st.default_layout || 'classique' }, opts.options || {});
    return C.render(type, data, { profile: profileGet(), options: options, number: 'APERÇU', mode: 'screen', lenient: !!opts.lenient }).html;
  }
  async function history(q) {
    if (connected()) { try { var p = new URLSearchParams(q || {}).toString(); var r = await api('GET', '/documents' + (p ? '?' + p : '')); return { items: r.items, total: r.total, remote: true }; } catch (e) {} }
    var h = lsGet(K_HIST, []); if (q && q.type) h = h.filter(function (x) { return x.type === q.type; }); return { items: h, total: h.length, remote: false };
  }
  async function historyOpen(rec, regenerate) {
    if (rec.local) { var o = rec.payload || {}; var st = lsGet(K_SET, DEFAULT_SET); var r = C.render(rec.type, o.data, { profile: profileGet(), options: o.options, number: rec.number, mode: 'print' }); return printHtml(r.title, r.html, r.page && r.page.orientation === 'landscape'); }
    var res = await api(regenerate ? 'POST' : 'GET', '/documents/' + encodeURIComponent(rec.id) + (regenerate ? '/regenerate' : '/pdf'), regenerate ? {} : undefined, true); var blob = await res.blob(); openBlob(blob); return blob;
  }
  async function historyDelete(rec) { if (rec.local) { lsSet(K_HIST, lsGet(K_HIST, []).filter(function (x) { return x.id !== rec.id; })); return { ok: true }; } return api('DELETE', '/documents/' + encodeURIComponent(rec.id)); }

  /* ───────── formulaires publics ───────── */
  function pubUrl() { return serverUrl(); }
  function publicApi(method, path, body, raw) {
    if (!pubUrl()) return Promise.reject(new Error('Serveur documentaire non configuré.'));
    return w.fetch(pubUrl() + '/api/v1/public' + path, { method: method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined }).then(function (r) {
      if (raw && r.ok) return r; return r.json().then(function (j) { if (!r.ok) throw Object.assign(new Error(j.error || 'Erreur ' + r.status), { status: r.status }); return j; });
    });
  }
  var pub = {
    saved: function () { return lsGet(K_PUB, { profile: {}, answers: {} }); }, save: function (o) { return lsSet(K_PUB, o); },
    categories: function () { return publicApi('GET', '/categories').then(function (j) { return j.categories; }).catch(function () { return localCats(); }); },
    forms: function (cat) { return publicApi('GET', '/forms' + (cat ? '?cat=' + encodeURIComponent(cat) : '')).then(function (j) { return j.forms; }).catch(function () { return localForms(cat); }); },
    render: function (slug, profile, data, interactive) { return publicApi('POST', '/forms/' + encodeURIComponent(slug) + '/render', { profile: profile, data: data, interactive: !!interactive }, true).then(function (r) { return r.blob(); }); }
  };
  function localForms(cat) { return C.list().filter(function (t) { return t.public && (!cat || t.public.categories.indexOf(cat) >= 0); }).map(function (t) { return { slug: t.public.slug, type: t.id, title: t.public.title, intro: t.public.intro, categories: t.public.categories, interactive: t.interactive, fields: t.fields, tables: t.tables, signatures: t.signatures }; }); }
  function localCats() { var m = {}; localForms().forEach(function (f) { f.categories.forEach(function (c) { m[c] = (m[c] || 0) + 1; }); }); return Object.keys(m).map(function (c) { return { id: c, forms: m[c] }; }); }

  w.EXBDoc = {
    VERSION: C.VERSION, core: C, templates: function () { return C.list().filter(function (t) { return !t.hidden; }); }, describe: C.describe,
    config: { serverUrl: serverUrl, setServerUrl: setServerUrl, connected: connected, token: token },
    profile: { get: profileGet, save: profileSave, load: profileLoad, onChange: function (f) { listeners.push(f); return function () { listeners = listeners.filter(function (x) { return x !== f; }); }; }, reset: function () { cache = null; } },
    models: { list: modelsList, save: modelSave, remove: modelDelete }, settings: { get: settingsGet, save: settingsSave },
    generate: generate, preview: preview, history: { list: history, open: historyOpen, remove: historyDelete },
    publicForms: pub, api: api, print: printHtml, download: download
  };
  w.EXB_PRINT_ENGINE = w.EXBDoc;
})(window);
