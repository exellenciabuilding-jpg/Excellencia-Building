/* Adresse du serveur du moteur documentaire (Chromium / PDF). Laisser vide = mode local (impression par l'application).
 * Exemple : window.EXB_DOCENGINE_URL = 'https://documents.mon-domaine.com';
 * Modifiable aussi depuis Centre documentaire › Paramètres et permissions. */
window.EXB_DOCENGINE_URL = window.EXB_DOCENGINE_URL || '';

/* V120d — Renouvellement de licence : lien affiché dans la bande « licence » du client (WhatsApp, e-mail ou page).
 * Exemple : window.EXB_LICENCE_CONTACT = 'https://wa.me/243XXXXXXXXX';   Laisser vide = aucun bouton « Renouveler ». */
window.EXB_LICENCE_CONTACT = window.EXB_LICENCE_CONTACT || '';
