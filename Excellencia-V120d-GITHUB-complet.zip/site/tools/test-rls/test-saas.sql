-- Test « vente à plusieurs entreprises » : isolation entre clients, essai automatique, licences, paiements.
-- Lancé par run.sh après les migrations (dont migration-v118 et migration-v120d). Chaque ligne : attendu | obtenu | OK / ECHEC.
\set ON_ERROR_STOP off
\pset tuples_only on
\pset format unaligned
create temp table res_saas(nom text, attendu text, obtenu text);
grant all on res_saas to public;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000f1','f1@x'),('00000000-0000-0000-0000-0000000000f2','f2@x'),('00000000-0000-0000-0000-0000000000f3','f3@x'),
 ('00000000-0000-0000-0000-0000000000f4','f4@x'),('00000000-0000-0000-0000-0000000000f5','f5@x') on conflict do nothing;

-- Exécute une requête en tant qu'utilisateur connecté (rôle « authenticated », sécurité par lignes active). ERREUR si elle échoue.
create or replace function ess2(p_uid text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.uid',p_uid,false); perform set_config('app.role','authenticated',false);
  execute 'set local role authenticated';
  begin execute p_sql into r; exception when others then r:='ERREUR'; end;
  reset role; perform set_config('app.uid','',false); return coalesce(r,'(null)'); end $$;

-- Deux entreprises clientes qui s'inscrivent elles-mêmes (F1 -> Alpha, F2 -> Beta)
select (ess2('00000000-0000-0000-0000-0000000000f1', $q$select creer_organisation('Alpha BTP','F1')::jsonb->>'id'$q$)) as oa \gset
select (ess2('00000000-0000-0000-0000-0000000000f2', $q$select creer_organisation('Beta Ingenierie','F2')::jsonb->>'id'$q$)) as ob \gset
select (code_invitation) as codeb from organisations where id=:'ob' \gset

insert into res_saas select 'S1 inscription autonome : licence d''essai créée automatiquement', 'essai', (select statut from licences_clients where org_id=:'oa');
insert into res_saas select 'S2 essai : 5 utilisateurs maximum', '5', (select max_utilisateurs::text from licences_clients where org_id=:'oa');
insert into res_saas select 'S3 essai : durée de 14 jours (13 à 15)', 'true', (select (expire_le between now()+interval '13 days' and now()+interval '15 days')::text from licences_clients where org_id=:'oa');

-- Données de chaque entreprise
insert into res_saas select 'S4 Alpha écrit ses données', 'true', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select enregistrer(%L,'clients','CA','{"name":"CLIENT SECRET ALPHA"}'::jsonb,0)::jsonb->>'ok'$q$, :'oa'));
insert into res_saas select 'S5 Beta écrit ses données', 'true', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select enregistrer(%L,'clients','CB','{"name":"client beta"}'::jsonb,0)::jsonb->>'ok'$q$, :'ob'));
insert into res_saas select 'S6 Beta ne peut PAS écrire chez Alpha', 'false', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select enregistrer(%L,'clients','PIRATE','{"name":"intrus"}'::jsonb,0)::jsonb->>'ok'$q$, :'oa'));
insert into res_saas select 'S7 Beta ne lit AUCUNE donnée d''Alpha', '0', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select count(*)::text from enregistrements where org_id=%L$q$, :'oa'));
insert into res_saas select 'S8 Beta ne lit pas la fiche entreprise d''Alpha', '0', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select count(*)::text from organisations where id=%L$q$, :'oa'));
insert into res_saas select 'S9 Beta ne voit pas les membres d''Alpha', '0', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select count(*)::text from membres where org_id=%L$q$, :'oa'));

-- Moteur documentaire
insert into res_saas select 'D1 Alpha enregistre son profil documentaire', 'ok', ess2('00000000-0000-0000-0000-0000000000f1', format($q$insert into doc_profils(org_id,profil) values (%L,'{"name":"Alpha BTP"}'::jsonb) returning 'ok'$q$, :'oa'));
insert into res_saas select 'D2 Beta ne lit pas le profil d''Alpha', '0', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select count(*)::text from doc_profils where org_id=%L$q$, :'oa'));
insert into res_saas select 'D3 Beta ne peut pas écrire le profil d''Alpha', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f2', format($q$insert into doc_profils(org_id,profil) values (%L,'{"name":"Intrus"}'::jsonb) returning 'ok'$q$, :'oa'));
insert into res_saas select 'D4 numérotation : Alpha obtient le n° 1', '1', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select doc_prochain_numero(%L,'facture',2026)::text$q$, :'oa'));
insert into res_saas select 'D5 numérotation : Beta ne peut pas utiliser le compteur d''Alpha', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select doc_prochain_numero(%L,'facture',2026)::text$q$, :'oa'));
insert into res_saas select 'D6 numérotation : Beta démarre à 1 chez lui (compteurs séparés)', '1', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select doc_prochain_numero(%L,'facture',2026)::text$q$, :'ob'));

-- Limite d'utilisateurs de l'essai (rejoindre l'entreprise Beta avec son code)
update licences_clients set max_utilisateurs=1 where org_id=:'ob';
insert into res_saas select 'L1 limite d''utilisateurs atteinte : un 2e membre est refusé', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f3', format($q$select rejoindre_organisation(%L,'F3')::text$q$, :'codeb'));
update licences_clients set max_utilisateurs=5 where org_id=:'ob';
insert into res_saas select 'L2 sous la limite : le membre est accepté', 'editeur', ess2('00000000-0000-0000-0000-0000000000f3', format($q$select rejoindre_organisation(%L,'F3')::jsonb->>'role'$q$, :'codeb'));

-- Licence expirée (plus de 7 jours) : lecture seule
update licences_clients set expire_le = now() - interval '10 days', statut='actif' where org_id=:'oa';
insert into res_saas select 'L3 licence expirée : l''écriture des données est refusée', 'true', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select (enregistrer(%L,'clients','CA2','{"name":"x"}'::jsonb,0)::jsonb->>'licence')$q$, :'oa'));
insert into res_saas select 'L4 licence expirée : la consultation reste possible', '1', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select count(*)::text from enregistrements where org_id=%L and id='CA'$q$, :'oa'));
insert into res_saas select 'L5 licence expirée : plus de nouveau numéro de document', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select doc_prochain_numero(%L,'facture',2026)::text$q$, :'oa'));
insert into res_saas select 'L6 licence expirée : le profil documentaire ne se modifie plus', '0', ess2('00000000-0000-0000-0000-0000000000f1', format($q$with u as (update doc_profils set profil='{"name":"Modif"}'::jsonb where org_id=%L returning 1) select count(*)::text from u$q$, :'oa'));
insert into res_saas select 'L7 ma_licence signale la lecture seule', 'true', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select (ma_licence(%L)::jsonb->>'lecture_seule')$q$, :'oa'));
insert into res_saas select 'L8 l''expiration d''Alpha ne touche pas Beta', 'true', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select enregistrer(%L,'clients','CB2','{"name":"b2"}'::jsonb,0)::jsonb->>'ok'$q$, :'ob'));
insert into res_saas select 'L9 un étranger ne lit pas la licence d''Alpha', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select ma_licence(%L)::text$q$, :'oa'));

-- Licence suspendue
update licences_clients set statut='suspendu', expire_le=now()+interval '300 days' where org_id=:'ob';
insert into res_saas select 'L10 licence suspendue : écriture refusée même avant l''échéance', 'true', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select (enregistrer(%L,'clients','CB3','{"name":"b3"}'::jsonb,0)::jsonb->>'licence')$q$, :'ob'));
update licences_clients set statut='actif' where org_id=:'ob';
insert into res_saas select 'L11 licence réactivée : écriture à nouveau possible', 'true', ess2('00000000-0000-0000-0000-0000000000f2', format($q$select enregistrer(%L,'clients','CB3','{"name":"b3"}'::jsonb,0)::jsonb->>'ok'$q$, :'ob'));

-- Paiements : réservés au propriétaire de la plateforme
insert into plateforme_proprietaires(user_id) values ('00000000-0000-0000-0000-0000000000f5') on conflict do nothing;
select (id) as lic_a from licences_clients where org_id=:'oa' \gset
insert into res_saas select 'P1 un client ne peut pas enregistrer de paiement', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f1', format($q$select owner_enregistrer_paiement(%L,50,'USD','mobile_money','REF1',12,null,null)::text$q$, :'lic_a'));
insert into res_saas select 'P2 le propriétaire enregistre un paiement', 'ok', ess2('00000000-0000-0000-0000-0000000000f5', format($q$select case when (owner_enregistrer_paiement(%L,50,'USD','mobile_money','REF1',12,null,'test')::jsonb->>'id') is not null then 'ok' end$q$, :'lic_a'));
insert into res_saas select 'P3 le propriétaire retrouve le paiement dans le journal', '1', ess2('00000000-0000-0000-0000-0000000000f5', format($q$select json_array_length(owner_liste_paiements(%L))::text$q$, :'oa'));
insert into res_saas select 'P4 le client ne lit pas le journal des paiements', '0', ess2('00000000-0000-0000-0000-0000000000f1', $q$select count(*)::text from licences_paiements$q$);
insert into res_saas select 'P5 le client ne lit pas la liste du propriétaire', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f1', $q$select owner_liste_paiements(null)::text$q$);
insert into res_saas select 'P6 le propriétaire enregistre un paiement même pour une licence expirée', 'ok', ess2('00000000-0000-0000-0000-0000000000f5', format($q$select case when (owner_enregistrer_paiement(%L,25,'USD','virement','REF2',6,null,null)::jsonb->>'id') is not null then 'ok' end$q$, :'lic_a'));

-- Propriétaire et limite de création
select ess2('00000000-0000-0000-0000-0000000000f5', $q$select creer_organisation('Entreprise du proprietaire','P')::jsonb->>'id'$q$) as oprop \gset
insert into res_saas select 'O1 le propriétaire crée sa propre entreprise : aucune licence d''essai imposée', '0', (select count(*)::text from licences_clients where org_id = :'oprop'::uuid);
insert into res_saas select 'O2 un compte peut créer 3 entreprises', 'false', ess2('00000000-0000-0000-0000-0000000000f4', $q$select (creer_organisation('E1','F4') is null)::text$q$);
select ess2('00000000-0000-0000-0000-0000000000f4', $q$select creer_organisation('E2','F4')::text$q$) \gset
select ess2('00000000-0000-0000-0000-0000000000f4', $q$select creer_organisation('E3','F4')::text$q$) \gset
insert into res_saas select 'O3 une 4e entreprise créée par le même compte est refusée', 'ERREUR', ess2('00000000-0000-0000-0000-0000000000f4', $q$select creer_organisation('E4','F4')::text$q$);

select nom||'  attendu='||attendu||'  obtenu='||obtenu||'  '||case when attendu=obtenu then 'OK' else 'ECHEC' end from res_saas order by length(nom), nom;
select 'BILAN SAAS '||count(*) filter (where attendu=obtenu)||'/'||count(*) from res_saas;
