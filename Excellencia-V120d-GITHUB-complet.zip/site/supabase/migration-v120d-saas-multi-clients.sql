-- ===== Excellencia Building — V120d : vente à plusieurs entreprises clientes (un seul serveur, données isolées) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : schema-entreprise.sql, migration-v99v-securite-licences.sql, migration-v99zo-securite-serveur.sql
--             et migration-v118-moteur-documentaire.sql déjà exécutés.
-- FAITES D'ABORD UNE SAUVEGARDE (Supabase › Database › Backups).
--
-- Ce que fait ce script
--   1. Inscription autonome : une entreprise qui se crée elle-même (creer_organisation) reçoit AUTOMATIQUEMENT
--      une licence d'essai de 14 jours (5 utilisateurs). Avant, elle n'avait aucune licence donc aucune limite.
--      Limite : 3 entreprises créées par compte. Le propriétaire de la plateforme n'est pas concerné.
--   2. ma_licence(org) : état de la licence pour l'affichage dans l'application (jours restants, lecture seule).
--   3. Journal des paiements de licence (réservé au propriétaire) : licences_paiements + 2 fonctions.
--   4. Le blocage d'écriture après expiration (V99zo) couvre aussi les tables du moteur documentaire (doc_*, créées après V99zo),
--      et la numérotation des documents refuse une licence expirée.
-- Une licence expirée depuis plus de 7 jours, suspendue ou résiliée passe en LECTURE SEULE : le client garde l'accès
-- à ses données (consultation, export) mais ne peut plus rien créer. Une entreprise SANS ligne de licence (cas historique,
-- ex. votre propre entreprise) reste illimitée.

-- ---------- 1. Inscription autonome avec essai ----------
alter table organisations add column if not exists cree_par uuid;

create or replace function creer_organisation(p_nom text, p_nom_user text default null)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations; n int; fin timestamptz; prop boolean;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  prop := est_proprietaire();
  if not prop then
    select count(*) into n from organisations where cree_par = auth.uid();
    if n >= 3 then raise exception 'nombre maximal d''entreprises créées atteint (3) : contactez l''administrateur du logiciel'; end if;
  end if;
  insert into organisations(nom, cree_par) values (coalesce(nullif(trim(p_nom),''),'Mon entreprise'), auth.uid()) returning * into o;
  insert into membres(org_id,user_id,nom,role) values (o.id,auth.uid(),p_nom_user,'admin');
  if not prop then
    fin := now() + interval '14 days';
    insert into licences_clients(org_id, client_nom, plan, statut, max_utilisateurs, essai_fin, expire_le)
      values (o.id, o.nom, 'essai', 'essai', 5, fin, fin);
  end if;
  return json_build_object('id',o.id,'nom',o.nom,'code',o.code_invitation,'role','admin','essai_fin',fin);
end $$;

-- ---------- 2. État de la licence, visible par les membres de l'entreprise ----------
create or replace function ma_licence(p_org uuid)
returns json language plpgsql stable security definer set search_path=public as $$
declare l licences_clients; nb int; jours int;
begin
  if auth.uid() is null or not est_membre(p_org) then raise exception 'accès refusé'; end if;
  select * into l from licences_clients where org_id=p_org order by cree_le desc limit 1;
  if not found then return json_build_object('statut','illimite','lecture_seule',false); end if;
  select count(*) into nb from membres where org_id=p_org;
  if l.expire_le is not null then jours := ceil(extract(epoch from (l.expire_le - now())) / 86400)::int; end if;
  return json_build_object('statut',l.statut,'plan',l.plan,'expire_le',l.expire_le,'jours_restants',jours,
    'max_utilisateurs',l.max_utilisateurs,'nb_membres',nb,'lecture_seule',not licence_ecriture_ok(p_org));
end $$;
revoke execute on function ma_licence(uuid) from public, anon;
grant execute on function ma_licence(uuid) to authenticated;

-- ---------- 3. Journal des paiements de licence (propriétaire uniquement) ----------
create table if not exists licences_paiements(
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organisations(id) on delete cascade,
  licence_id uuid references licences_clients(id) on delete set null,
  montant numeric(14,2) not null check (montant >= 0),
  devise text not null default 'USD' check (devise in ('USD','CDF','EUR')),
  mode text not null default 'mobile_money' check (mode in ('mobile_money','virement','especes','carte','autre')),
  reference text,
  mois int check (mois between 0 and 60),
  periode_fin timestamptz,
  note text,
  enregistre_par uuid,
  cree_le timestamptz not null default now());
create index if not exists licences_paiements_org_idx on licences_paiements(org_id, cree_le desc);
alter table licences_paiements enable row level security;
drop policy if exists lp_proprietaire on licences_paiements;
create policy lp_proprietaire on licences_paiements for all using (est_proprietaire()) with check (est_proprietaire());

create or replace function owner_enregistrer_paiement(p_licence uuid, p_montant numeric, p_devise text default 'USD',
  p_mode text default 'mobile_money', p_ref text default null, p_mois int default null, p_expire timestamptz default null, p_note text default null)
returns json language plpgsql security definer set search_path=public as $$
declare l licences_clients; p licences_paiements;
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  select * into l from licences_clients where id = p_licence;
  if not found then raise exception 'licence introuvable'; end if;
  if coalesce(p_montant,-1) < 0 then raise exception 'montant invalide'; end if;
  insert into licences_paiements(org_id, licence_id, montant, devise, mode, reference, mois, periode_fin, note, enregistre_par)
    values (l.org_id, l.id, p_montant, coalesce(nullif(p_devise,''),'USD'), coalesce(nullif(p_mode,''),'mobile_money'),
            nullif(trim(p_ref),''), p_mois, p_expire, nullif(trim(p_note),''), auth.uid())
    returning * into p;
  return row_to_json(p);
end $$;

create or replace function owner_liste_paiements(p_org uuid default null)
returns json language plpgsql stable security definer set search_path=public as $$
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  return (select coalesce(json_agg(row_to_json(x) order by x.cree_le desc), '[]'::json)
          from (select * from licences_paiements where p_org is null or org_id = p_org order by cree_le desc limit 200) x);
end $$;

revoke execute on function owner_enregistrer_paiement(uuid,numeric,text,text,text,int,timestamptz,text), owner_liste_paiements(uuid) from public, anon;
grant execute on function owner_enregistrer_paiement(uuid,numeric,text,text,text,int,timestamptz,text), owner_liste_paiements(uuid) to authenticated;

-- ---------- 4. Blocage d'écriture après expiration : tables créées après V99zo (moteur documentaire, etc.) ----------
do $$ declare r record; begin
  for r in select distinct c.table_name from information_schema.columns c
           join information_schema.tables t on t.table_schema=c.table_schema and t.table_name=c.table_name and t.table_type='BASE TABLE'
           where c.table_schema='public' and c.column_name='org_id'
             and c.table_name not in ('membres','licences_clients','licences_paiements','invitations_equipe','journal_entreprise','organisations','enregistrements')
  loop
    execute format('drop policy if exists licence_ins on %I', r.table_name);
    execute format('create policy licence_ins on %I as restrictive for insert with check (licence_ecriture_ok(org_id))', r.table_name);
    execute format('drop policy if exists licence_upd on %I', r.table_name);
    execute format('create policy licence_upd on %I as restrictive for update using (licence_ecriture_ok(org_id)) with check (licence_ecriture_ok(org_id))', r.table_name);
    execute format('drop policy if exists licence_del on %I', r.table_name);
    execute format('create policy licence_del on %I as restrictive for delete using (licence_ecriture_ok(org_id))', r.table_name);
  end loop;
end $$;

-- Numérotation : pas de nouveau numéro (donc pas de trou dans la suite FAC-0001…) pour une licence expirée.
create or replace function doc_prochain_numero(p_org uuid, p_type text, p_annee int)
returns int language plpgsql security definer set search_path=public as $$
declare n int;
begin
  if not est_membre(p_org, array['admin','editeur']) then raise exception 'acces refuse' using errcode='42501'; end if;
  if not licence_ecriture_ok(p_org) then raise exception 'licence expiree' using errcode='42501'; end if;
  insert into doc_compteurs(org_id,type,annee,dernier) values (p_org,p_type,p_annee,1)
    on conflict (org_id,type,annee) do update set dernier = doc_compteurs.dernier + 1 returning dernier into n;
  return n;
end $$;
revoke all on function doc_prochain_numero(uuid,text,int) from public, anon;
grant execute on function doc_prochain_numero(uuid,text,int) to authenticated;

-- Contrôles (résultats attendus) :
--   select proname from pg_proc where proname in ('ma_licence','owner_enregistrer_paiement','owner_liste_paiements');  → 3 lignes
--   select count(*) from pg_policies where policyname='licence_ins' and tablename like 'doc\_%';                      → 5
--   select to_regclass('public.licences_paiements');                                                                  → licences_paiements
