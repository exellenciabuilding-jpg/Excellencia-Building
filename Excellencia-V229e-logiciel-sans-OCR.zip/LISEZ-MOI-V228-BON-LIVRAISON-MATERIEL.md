# V228 — Bon de livraison + reçu de matériel

Espace Comptable › Reçus de paiement › carte **📦 Livraison de matériel** (au-dessus du guichet).

- Saisie : entreprise destinataire, chantier, date, devise, jusqu'à 12 lignes (désignation, quantité, unité, prix), payé à ce jour, mode, remarques, nom du réceptionnaire.
- PDF A4 : même en-tête/pied que le reçu client, tableau du matériel, total, payé, **reste à payer** (statut soldé / partiel / non payé), cases « Livré par » et « Reçu par » (signature + cachet), QR de vérification.
- Numérotation BL-AAAA-001…, registre local « exb_livraisons » (sauvegardé avec le reste), liste des 8 derniers bons avec réédition du PDF.
- Aucun SQL à exécuter. Fichier : site/exb-v228-livraison-materiel.js (ajouté à index.html et au cache hors connexion).
- Non fait (idée) : synchronisation du registre entre appareils (demande une migration SQL).

## V229b — bibliothèque BTP dans le bon de livraison
Bouton « 📚 Ajouter depuis la bibliothèque » : désignation, unité et prix repris de la fiche (converti en USD/FC avec le dernier taux Finance ; prix vide si prix ou taux absent), plusieurs articles à la suite, quantités cumulées pour un même article. La référence de la fiche est gardée dans le registre.

## V229c — bon de commande et panier de sélection
- Même carte, menu « Type de bon » : 📦 Bon de livraison (BL-AAAA-001) ou 🛒 Bon de commande fournisseur (BC-AAAA-001 : fournisseur, livraison souhaitée, conditions, acompte, solde ; zones « Commandé par » / « Accepté par le fournisseur »).
- La bibliothèque BTP ouverte depuis cette carte affiche un PANIER (cahier des charges §4) : quantités et prix modifiables, sous-totaux, total par devise ; « ✔ Envoyer au document » transmet toutes les lignes d'un coup. Le Devis rapide, le Stock et l'Achat V51 gardent leur envoi direct.
- Le formulaire « Bon de commande / achat » du Centre de gestion (Enterprise 360) n'est PAS dans l'Espace Comptable (clés du comptable : finances, compta, budget, décomptes, reçus, clients, Métré & devis). Le comptable fait donc ses bons de commande ici, dans Reçus de paiement.

## V229d — Bibliothèque BTP : Génie civil + gestion des familles
- Nouvelle famille « Génie civil » (caniveaux, buses, regards, dalots, géosynthétiques, gabions, enrochements, têtes d'ouvrage) : 9 fiches ajoutées (GEN-001 à 009, sans prix) ; Caniveau préfabriqué, Buse béton et Géotextile de séparation y sont reclassés.
- Catalogues déjà enregistrés : migration automatique une seule fois (ajout de la famille et des fiches, rien n'est écrasé ; reclassement seulement des 3 fiches d'origine non modifiées).
- Paramètres › Familles : boutons ↑ et ↓ pour réordonner (renommer, activer/désactiver, créer, supprimer existaient déjà).
