V229 — Bibliothèque BTP liée au Stock & matériaux et au bon de commande (correctif de la V228 : appliquer la V228 d'abord)

Fichiers à remplacer : exb-bibliotheque-btp.js, bibliotheque-btp.html, sw.js (cache v229). index.html ne change pas par rapport à la V228.
- Stock & matériaux : bouton « 📚 Depuis la bibliothèque » -> crée l'article lié (champs bib + ref, quantité 0, seuil 0 : aucun mouvement ni prix inventé). Un article déjà présent (même fiche, ou même nom + unité) est lié, pas dupliqué.
- Fiche de la bibliothèque (dans le logiciel) : état du stock « En stock / À commander / Hors stock » et bouton « 📦 Au stock ».
- Bon de commande / achat (Centre de gestion V51) : bouton « 📚 Choisir dans la bibliothèque » -> remplit désignation, quantité et prix (converti en USD avec le dernier taux Finance ; prix vide si taux ou prix absent).
- EXB_BIB.pick({title, add(ligne, qté)}) : ouvre la bibliothèque en plein écran pour brancher un autre écran.
Les articles de stock passent par exbSave comme avant : leur synchronisation est celle du stock existant. Le catalogue lui-même reste local (exb_btp_v4*).
Limites : non testé dans un navigateur (logique vérifiée en simulation). Les boutons suivent les écrans Stock / Achats / Devis : ils apparaissent dans un espace (Comptable, Ingénieur…) seulement si ces modules y sont affichés. Unité « tonne » ou autre hors liste du formulaire Stock : à vérifier en modification d'un article.
