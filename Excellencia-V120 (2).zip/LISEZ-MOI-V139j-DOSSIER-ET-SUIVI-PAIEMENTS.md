# V139j — Dossier participant (PDF) et suivi des paiements

## Dossier participant (PDF)
- La rubrique « Documents du participant » et le bouton « Ajouter un document » n'apparaissent plus dans le PDF (ni les autres boutons de l'écran). Ils restent sur l'écran du dossier.
- Bas de page : seul le bloc **La Direction** est conservé (le bloc « Le client / L'intéressé(e) » est retiré). La signature et le cachet sont descendus en bas de page, au-dessus du QR, avec « Fait à …, le … » à gauche et **le nom du directeur** sous « La Direction » (nom saisi une fois dans l'identité de l'entreprise).
- Ne concerne que les PDF « dossier-… ». Les autres documents (contrats, factures, fiches…) gardent leur mise en page.

## Participants › Paiements (qui a payé ?)
- La colonne **Actions** (Reçu, Inscr. non payée, Moitié, Payé en totalité, Historique) est supprimée : l'écran est en lecture seule.
- Il montre qui a payé, qui a payé la moitié et qui n'a pas encore payé ; filtres, recherche, **Excel (CSV)** et **Imprimer / PDF** inchangés.
- Les reçus se génèrent uniquement dans **Reçus de paiement** (liste « À encaisser » : Inscription payée + reçu, Moitié, Total).
