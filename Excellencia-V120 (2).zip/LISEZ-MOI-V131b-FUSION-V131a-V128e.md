# V131b — Fusion de V131a (MODELES-QR) et V128e (PARCOURS)

Les deux archives venaient de deux branches : V131a = V131 (3D assemblages, soudure/feu, té/fendage) + modèles + QR en pied ; V128e = V128 + licence (V128b) + assistant IA approbation (V128c) + Parcours (V128d). Les fichiers communs à V128 étaient identiques, sauf ceux listés ci-dessous.

## Base et apports
Base : **V131a** (la plus récente pour le calcul, le QR et l'impression). Ajouté depuis **V128e** :
- Licence : diagnostic de verrouillage, messages d'activation précis (`site/exb-license.js`, `scripts/test-licence-e2e.mjs`, `package.json`).
- Assistant IA : importer ET approuver, approuver, marquer traité, rejeter, traitement automatique (`site/index.html`, `site/exb-notify-pro.js`, `site/supabase/functions/assistant/index.ts`, `site/tools/e2e-assistant-approbation.py`). **Redéployer la fonction Supabase `assistant`.**
- Parcours : `site/exb-parcours.js`, `site/exb-calc-vers-plans.js`, `site/exb-v81-plans.js` (`addFrom`), `site/tools/test-parcours.js`, `site/tools/e2e-parcours.py`.
- Notes : README-V128d, LISEZ-MOI-V128b, LISEZ-MOI-V128c.

Conservé de **V131a** : tout le reste (calcul de structure V129–V131 dont `exb-robot-3d.js`, QR en pied V128f dans `exb-print.js`, `exb-pdf.js`, `docengine/templates-modules.js`, `check.js`).

## Fichiers fusionnés à la main
`site/sw.js` : cache `v131b-fusion-…` + `exb-parcours.js` et `exb-calc-vers-plans.js` ajoutés à la liste hors ligne (`exb-robot-3d.js` déjà présent).
`site/index.html` : celui de V128e (V131a n'avait rien de plus : mêmes balises, sauf les 2 du Parcours).

## Vérifié
`node tools/check.js` : 545 réussis, 0 échec · `test-parcours` 27/27 · tests licences (client, serveur, provisioning, bout en bout) réussis · tests serveur qr-pied, qr-svg, doc-piece, doc-fiche, fiche-adapter, bridge-habillage, brand-rep réussis · syntaxe de tous les scripts modifiés et des scripts inline d'`index.html`.
**Non vérifié** : ouverture dans un navigateur de la version fusionnée (Parcours + calcul 3D ensemble), `e2e-parcours.py` et `e2e-assistant-approbation.py` (navigateur requis), Supabase réel. Après publication : fermer complètement l'application une fois (nouveau cache).
Retour en arrière : revenir aux deux archives d'origine.
