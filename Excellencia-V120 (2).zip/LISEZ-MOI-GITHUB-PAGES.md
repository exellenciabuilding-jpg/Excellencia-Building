# Publier sur GitHub Pages (sans Netlify)

Oui, c'est possible : GitHub Pages héberge ce site (fichiers statiques). Supabase et le reste ne changent pas.

## Mise en place (une seule fois)
1. Envoyez le projet dans votre dépôt GitHub (le contenu de l'archive, avec les dossiers `site/`, `scripts/`, `clients/`, `.github/`).
2. **Settings › Pages › Build and deployment › Source = « GitHub Actions »**.
3. Dans `clients/<client>/entreprise.json`, mettez **publicUrl** = l'adresse GitHub Pages, par exemple `https://votrecompte.github.io/votredepot` (sans `/` final). Elle sert aux QR codes et aux liens partagés.
4. **Actions › « Site GitHub Pages » › Run workflow**, client = nom du dossier (ex. `demo-excellencia`). L'adresse s'affiche à la fin.
5. Après chaque mise à jour du dépôt, relancez ce workflow.

Ne choisissez pas « Deploy from a branch » : il publierait `site/` tel quel, donc l'édition PROPRIÉTAIRE (générateur de licences). Le workflow publie `dist-site`, l'édition client, comme le workflow Netlify.

## Ce qui change par rapport à Netlify
- **`_headers` est ignoré** : les en-têtes de sécurité (nosniff, X-Frame-Options, HSTS, Permissions-Policy) ne sont plus ajoutés par le serveur. GitHub Pages impose HTTPS.
- **`_redirects` est ignoré** : le script `scripts/pages-redirects.js` recrée les liens courts (/inscription, /verification, /tfl, /suivi…) sous forme de petites pages qui renvoient vers la bonne page en gardant les paramètres.
- **Mises à jour plus lentes** : GitHub garde les fichiers en cache environ 10 minutes. Après une publication, fermez complètement l'application et rouvrez-la.
- **`/api/login`** n'existe pas : la connexion locale prend le relais automatiquement (le code le prévoit).
- Si vous aviez saisi l'adresse Netlify dans **Supabase › Authentication › URL Configuration**, remplacez-la par la nouvelle.

## Attention : dépôt public ou privé
GitHub Pages gratuit exige un dépôt **public**. Ce dépôt contient aussi `scripts/`, `clients/` (identités de vos clients), `owner-app/` et la configuration des applications. Si cela vous gêne : dépôt privé avec un compte GitHub Pro/Team, ou un second dépôt public qui ne contient que le site publié.

## Vérifié / non vérifié
Vérifié ici : le workflow est un YAML valide ; `strip-owner.js` retire bien le générateur ; `pages-redirects.js` crée 31 liens courts (le fichier réel `plans` est conservé, comme sur Netlify) ; dans un navigateur, `/inscription/?ref=abc` mène à `inscription.html?type=apprenant&ref=abc`.
**Non vérifié** : l'exécution réelle sur GitHub Actions et GitHub Pages (impossible depuis ici). Si une étape échoue, envoyez-moi le message d'erreur de l'onglet Actions.
