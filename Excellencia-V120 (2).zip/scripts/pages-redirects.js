/* Excellencia — liens courts pour GitHub Pages (V131c).
 * Netlify lit site/_redirects (/inscription, /verification, /tfl…). GitHub Pages l'ignore : ces adresses donneraient « 404 ».
 * Ce script lit _redirects dans le dossier donné et crée, pour chaque lien court, une petite page qui renvoie vers la vraie page
 * en conservant les paramètres de l'adresse (?id=…). Un fichier réel déjà présent n'est jamais écrasé (comme Netlify).
 * Usage :  node scripts/pages-redirects.js <dossier>      (le dossier = copie de site/, ex. dist-site) */
const fs = require('fs'), path = require('path');
const dir = process.argv[2];
if (!dir || !fs.existsSync(path.join(dir, '_redirects'))) { console.error('pages-redirects : dossier ou _redirects introuvable'); process.exit(1); }
const esc = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
let made = 0, skipped = 0;
fs.readFileSync(path.join(dir, '_redirects'), 'utf8').split(/\r?\n/).forEach(line => {
  line = line.trim(); if (!line || line[0] === '#') return;
  const [from, to] = line.split(/\s+/);
  if (!from || !to || /[*:]/.test(from) || /^https?:/.test(to)) { skipped++; return; }
  const isFile = /\.[a-z0-9]+$/i.test(from);
  const out = isFile ? path.join(dir, from) : path.join(dir, from, 'index.html');
  /* comme Netlify : un fichier réel au même chemin (ex. un fichier « plans ») reste prioritaire */
  const same = path.join(dir, from);
  if (fs.existsSync(same) && fs.statSync(same).isFile()) { skipped++; return; }
  if (isFile && fs.existsSync(out)) { skipped++; return; }
  const depth = from.replace(/^\/+|\/+$/g, '').split('/').length;
  const up = isFile ? '' : '../'.repeat(depth);
  const target = up + to.replace(/^\//, '');
  const html = '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>Redirection…</title>' +
    '<meta http-equiv="refresh" content="0;url=' + esc(target) + '">' +
    '<script>(function(){var t=' + JSON.stringify(target) + ',q=location.search.replace(/^\\?/,"");if(q)t+=(t.indexOf("?")<0?"?":"&")+q;t+=location.hash;location.replace(t)})()</script>' +
    '</head><body><p>Redirection… <a href="' + esc(target) + '">Continuer</a></p></body></html>';
  fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, html); made++;
});
fs.writeFileSync(path.join(dir, '.nojekyll'), '');
console.log('pages-redirects : ' + made + ' lien(s) court(s) créé(s), ' + skipped + ' ignoré(s).');
