# V139f — Confirmer un paiement = reçu automatique

Base : V139e (V139d + saisie liée V134). Fichiers touchés : `site/index.html` (liste « À encaisser » + correctif reçus), `site/sw.js`, `site/tools/check.js`, test `site/tools/e2e-paiement-auto.py`. Aucun SQL.

## Parcours (Réception des reçus › « À encaisser »)
1. L'apprenant s'inscrit sur le site vitrine et déclare son paiement Mobile Money (réseau, n° payeur, référence). **La fiche affiche maintenant ce paiement déclaré** : « 25 USD via Airtel Money · réf. TX778899 ».
2. L'administrateur vérifie, puis clique **« 💰 Inscription payée + reçu »** (ou « 🟡 Moitié + reçu » / « ✅ Total + reçu »).
3. En un seul clic, l'application : approuve et rattache l'apprenant si besoin, **enregistre le paiement** (celui déclaré ; sinon le montant du tarif, signalé « à corriger dans Paiements si différent »), **génère et enregistre le reçu** (numéro, matricule, statuts exacts, QR), mémorise le statut côté serveur, et **retire l'apprenant de « À encaisser »**.
4. L'espace apprenant se met à jour tout seul (reçu, statuts, versement) : compter jusqu'à 30 secondes, la publication ne se lance pas pendant une saisie.

« 🧾 Préparer le reçu » reste disponible pour vérifier un reçu avant de l'enregistrer.

## Garde-fous
- **Pas de doublon** : rejouer la même confirmation ne crée ni second reçu ni second paiement (signalé dans le bandeau).
- Si le reçu ne peut pas être créé (par exemple fiche incomplète), le paiement **n'est pas marqué confirmé** et la raison s'affiche.
- Montant du tarif : prix de la formation du catalogue si renseigné, sinon valeurs du formulaire de reçu (5 000 FC / 20 $ par défaut).

## Défaut corrigé au passage
À chaque nouveau reçu, le **premier** reçu de la liste recevait le matricule et l'identifiant du dernier participant. Corrigé : chaque reçu garde son propre participant.

## Vérifié / non vérifié
- Test navigateur `python3 tools/e2e-paiement-auto.py` (17 contrôles, serveur Supabase simulé) ; `node tools/check.js` : 571 réussis, 0 échec ; tests liaison et saisie liée sans échec.
- **Non testé avec le vrai Supabase** : la règle exacte du filtre « À encaisser » vit dans votre SQL. Le test suppose qu'un apprenant dont l'inscription est payée quitte cette liste, comme l'indique le message d'origine. Si « Total » seul doit aussi le retirer, dites-le-moi.
- La publication vers l'espace apprenant n'a pas été exécutée contre le serveur : j'ai vérifié que reçu, paiement et participant sont prêts, la fonction de publication existante les lit.
