# V133a — Renfort des modèles : pièces écrites, onglet Communication, affiches du Studio libre

Base : v133 (V131c-GitHub : assistant local élargi, GitHub Pages, clic droit, multi-sélection). Rien d’existant n’est modifié ni écrasé ; tout est ajouté.

## Pièces écrites : 746 → 1 016 modèles (+270)
- **Nouvel onglet « Communication et marketing » (124 modèles)** : communiqués de presse (marché remporté, démarrage, livraison, nomination, partenariat, rectificatif, condoléances, crise, rumeur…), publications Facebook / LinkedIn / Instagram, messages WhatsApp Business, réponses aux avis et réclamations, e-mails et SMS, scripts vidéo et radio, textes de flyers, brochures, pages de site et FAQ, plans de communication (annuel, lancement, crise), plan éditorial, briefs, charte, bilans, autorisations de droit à l'image, discours de cérémonie, programmes et check-lists d'événements, lettres de prospection et de fidélisation.
  Il apparaît aussi dans le hub « Documents de chantier » (famille 📣 Communication). Signature par défaut : aucune (les textes portent déjà la leur) ; modifiable pièce par pièce.
- **+146 modèles dans les onglets existants** : lettres (+16), comptes rendus (+10), ordres de service (+10), procès-verbaux (+11), attestations (+11), contrats (+14), notes (+10), rapports (+14), clauses (+13), fiches de contrôle (+17), dossiers (+10), textes libres (+10). Les noms déjà pris n'ont pas été écrasés : ces modèles ont reçu un nom distinct.
- Fichiers : `exb-v131-modeles-com-a.js`, `-com-b.js`, `-d.js`.

## Affiches du Studio libre : 46 → 142 modèles (+96)
Nouveaux groupes : **Prévention & sécurité** (20), **Réseaux sociaux** (22 : publications carrées, stories, citations, compte à rebours, bannières), **Événements & relations** (11), **Commercial & offres** (13), **Emploi & carrière** (8) ; renfort de **Communiqués & avis** (+16 : 22 au total) et **Logiciels & formations** (+9).
Fichiers : `exb-affiches-studio-b.js` (gabarits + 3 groupes), `-c.js` (autres groupes). Le Studio (`exb-affiches-studio.js`) reçoit un point d'extension `EXB_STUDIO.extend()` qui n'écrase jamais un modèle existant.

## Vérifié
`node tools/check.js` : 556 contrôles réussis, 0 échec (dont 5 nouveaux) ; test assistant local 33/33, Parcours 27/27, licences réussis. Les 96 affiches ont été rendues dans Chromium : aucun texte ne dépasse la page ni le pied de page, aucune erreur de script ; l'application complète se charge sans erreur. Planches visuelles contrôlées sur un échantillon représentatif.
**Non vérifié** : lecture humaine de chacun des 270 textes (contenu à relire avant diffusion : chiffres, noms, dates), contrats et clauses à faire valider par votre conseil juridique, rendu sur téléphone réel.
Pour retirer les affiches : supprimer les 2 balises `exb-affiches-studio-b/c.js`. Pour les textes : supprimer les 3 balises `exb-v131-modeles-*.js`.
