/* Excellencia Building — V133b REGISTRE IA : l'assistant connaît TOUS les modules du logiciel, y compris ceux ajoutés plus tard.
 *
 * Sans rien faire de spécial, un NOUVEAU module est pris en compte automatiquement s'il respecte la convention du logiciel :
 *   1. un bouton de menu  onclick="show('monId')"  (le menu est relu à chaque question) ;
 *   2. un panneau  <section id="monId">  avec un titre (h2/h3) et, idéalement, une phrase d'aide (.hint) ;
 *   3. des données sauvegardées par exbStorage dans une clé « exb_… » contenant une liste (tableau) d'objets.
 * L'assistant sait alors : l'ouvrir (« ouvre … »), l'expliquer (« à quoi sert … »), dire où il se trouve (« où faire … »),
 * lister les modules (« quels modules ? ») et répondre sur ses données (« combien de … », « liste des … », « derniers … »).
 *
 * Pour aller plus loin (réponses sur mesure), un module peut s'enregistrer :
 *   EXB_AI.register({
 *     id: 'monId', label: 'Mon module', tab: 'monId',               // onglet (facultatif si le bouton de menu existe)
 *     keywords: ['inspection', 'controle'],                          // mots qui déclenchent le module
 *     description: 'À quoi il sert, en une phrase.',                 // remplace la description automatique
 *     collections: [{ key: 'exb_inspections', name: 'Inspections', aliases: ['inspection'], fields: ['site', 'date', 'statut'] }],
 *     answer: function (raw, q) { return { answer: 'texte', actions: [{ type: 'goto', tab: 'monId' }] }; }   // facultatif
 *   });
 * Lecture seule : l'assistant ne modifie jamais les données ici. Les clés sensibles (licence, session, mots de passe…) sont ignorées. */
(function (w) {
  'use strict';
  if (w.EXB_AI) return;
  var d = w.document, DIRTY = true, CAT = {}, REG = [], COLS = null, COLS_AT = 0;
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  var STOPW = { et: 1, de: 1, du: 1, des: 1, les: 1, la: 1, le: 1, pour: 1, sur: 1, avec: 1, une: 1, aux: 1, mes: 1, mon: 1, par: 1, dans: 1, vers: 1, que: 1, qui: 1, est: 1, son: 1, ses: 1, ces: 1, cet: 1, cette: 1, plus: 1, tout: 1, tous: 1 };
  var GENERIC = { liste: 1, lister: 1, combien: 1, nombre: 1, dernier: 1, derniere: 1, recent: 1, montre: 1, affiche: 1, donne: 1, total: 1, onglet: 1, module: 1, page: 1, ouvre: 1, ouvrir: 1, cherche: 1, trouve: 1, quel: 1, quelle: 1, donnee: 1, enregistrement: 1, exb: 1, data: 1, list: 1, items: 1, item: 1, log: 1, logs: 1, store: 1, cache: 1 };
  function stem(x) { return x.replace(/aux$/, 'al').replace(/[sx]$/, ''); }
  function words(s) { var o = [], seen = {}; norm(String(s).replace(/([a-z])([A-Z])/g, '$1 $2')).split(' ').forEach(function (x) { if (x.length >= 3 && !STOPW[x]) { x = stem(x); if (!seen[x]) { seen[x] = 1; o.push(x); } } }); return o; }
  function wmatch(a, b) { return a === b || (a.length >= 5 && b.length >= 5 && (a.indexOf(b) === 0 || b.indexOf(a) === 0)); }
  function stripIcon(t) { return String(t || '').replace(/^[^A-Za-zÀ-ÿ0-9]+/, '').replace(/\s+/g, ' ').trim(); }
  function iconOf(t) { var m = /^([^A-Za-zÀ-ÿ0-9]+)/.exec(String(t || '')); return m ? m[1].trim() : ''; }

  /* ---------- découverte des onglets ---------- */
  function discover() {
    var out = {}, els;
    try { els = d.querySelectorAll('[onclick*="show("],[data-show],[data-go-tab]'); } catch (e) { els = []; }
    for (var i = 0; i < els.length; i++) {
      var el = els[i], id = '', m = /(?:window\.)?show\(\s*['"]([A-Za-z0-9_\-]+)['"]/.exec(el.getAttribute('onclick') || '');
      id = m ? m[1] : (el.getAttribute('data-show') || el.getAttribute('data-go-tab') || '');
      if (!id || id === '__r' || out[id]) continue;
      var raw = (el.textContent || '').replace(/\s+/g, ' ').trim(); if (!raw) continue;
      var lab = stripIcon(raw).replace(/\s*\(\d+\)\s*$/, ''); if (!lab || lab.length > 60) continue;
      if (!d.getElementById(id)) continue;
      out[id] = { id: id, label: lab, icon: iconOf(raw), auto: true };
    }
    return out;
  }
  function refresh() {
    var f = discover(), k;
    for (k in f) if (!CAT[k]) CAT[k] = f[k];
    for (k in CAT) if (CAT[k].auto && !f[k] && !d.getElementById(k)) delete CAT[k]; /* menu retiré */
    DIRTY = false;
  }
  function sync(AI_TABS) {
    if (DIRTY) refresh();
    var added = 0, k;
    if (AI_TABS) for (k in CAT) { if (!AI_TABS[k]) { AI_TABS[k] = CAT[k].label; added++; } }
    if (AI_TABS) for (k in AI_TABS) { if (!CAT[k]) CAT[k] = { id: k, label: AI_TABS[k], icon: '', auto: false }; }
    return added;
  }
  function catalog() { if (DIRTY) refresh(); return Object.keys(CAT).map(function (k) { return CAT[k]; }); }

  /* ---------- trouver un onglet par son nom ---------- */
  function findTab(q) {
    q = norm(q); if (DIRTY) refresh();
    var qw = words(q); if (!qw.length) return null;
    var best = null, bs = -1, tie = false;
    Object.keys(CAT).forEach(function (id) {
      var e = CAT[id], lw = words(e.label); if (!lw.length) return;
      var mc = lw.filter(function (x) { return qw.some(function (y) { return wmatch(x, y); }); }).length;
      var ok = mc === lw.length || (lw.length >= 3 && mc >= 2 && mc / lw.length >= 0.66);
      if (!ok) return;
      var sc = mc * 10 - lw.length;
      if (sc > bs) { bs = sc; best = id; tie = false; } else if (sc === bs) tie = true;
    });
    return tie ? null : best;
  }
  function ambiguous(q) { /* tous les onglets dont au moins un mot du nom est cité */
    q = norm(q); if (DIRTY) refresh(); var qw = words(q), o = [];
    Object.keys(CAT).forEach(function (id) { var lw = words(CAT[id].label); if (lw.some(function (x) { return qw.some(function (y) { return wmatch(x, y); }); })) o.push(id); });
    return o;
  }

  /* ---------- description automatique d'un module ---------- */
  function describe(id) {
    fresh(); var e = CAT[id], reg = REG.filter(function (r) { return r.id === id || r.tab === id; })[0];
    var label = e ? e.label : id, desc = reg && reg.description ? reg.description : '';
    var el = d.getElementById(id), btn = [], fld = [];
    if (!desc && el) {
      var h = el.querySelector('h1,h2,h3'), hint = el.querySelector('.hint,.muted,.small,.sub,.note,p');
      var ht = h ? stripIcon(h.textContent) : '', pt = hint ? hint.textContent.replace(/\s+/g, ' ').trim() : '';
      if (pt && pt.length > 280) pt = pt.slice(0, 277) + '…';
      desc = (pt || (ht && norm(ht) !== norm(label) ? ht : ''));
    }
    if (el) {
      var seen = {};
      [].slice.call(el.querySelectorAll('button')).forEach(function (b) { var t = stripIcon(b.textContent); if (t && t.length <= 40 && !seen['b' + t] && btn.length < 8) { seen['b' + t] = 1; btn.push(t); } });
      [].slice.call(el.querySelectorAll('label')).forEach(function (l) { var t = stripIcon(l.textContent).replace(/[*:]+$/, '').trim(); if (t && t.length <= 40 && !seen['l' + t] && fld.length < 8) { seen['l' + t] = 1; fld.push(t); } });
    }
    var cols = collections().filter(function (c) { return c.tab === id; });
    var out = (e && e.icon ? e.icon + ' ' : '') + label + (desc ? ' — ' + desc : ' — module du logiciel.');
    if (fld.length) out += '\nChamps : ' + fld.join(', ') + '.';
    if (btn.length) out += '\nBoutons : ' + btn.join(' · ') + '.';
    if (cols.length) out += '\nDonnées : ' + cols.map(function (c) { return c.name + ' (' + c.count + ')'; }).join(', ') + '.';
    return out;
  }

  /* ---------- jeux de données « exb_… » ---------- */
  var SENSITIVE = /(licen|session|pass|token|secret|cred|auth|hash|otp|apikey|private|sign_?key|supabase|login|user|account|cle_|_key$|backup|undo|audit)/i;
  var KNOWN = {
    exb_participants: ['Apprenants', 'participants', ['apprenant', 'participant', 'inscrit', 'eleve', 'etudiant']],
    exb_trainers: ['Formateurs', 'formateurs', ['formateur']], exb_clients: ['Clients', 'clients', ['client']],
    exb_projects: ['Projets', 'projets', ['projet', 'chantier']], exb_quotes: ['Devis', 'metreDevis', ['devis']],
    exb_stock: ['Stock', 'stock', ['stock', 'materiau']], exb_cash: ['Caisse', 'comptabilite', ['caisse', 'tresorerie']],
    exb_hr: ['Personnel', 'rh', ['personnel', 'employe']], exb_schedules: ['Planning', 'planning', ['planning', 'seance']],
    exb_attendance: ['Présences', 'presence', ['presence']], exb_receipts: ['Reçus', 'receipts', ['recu']],
    exb_certificates: ['Certificats', 'certs', ['certificat']], exb_evaluations: ['Évaluations', 'evaluations', ['evaluation', 'note']],
    exb_formations: ['Formations', 'formations', ['formation']]
  };
  var DATEF = ['date', 'created_at', 'updated_at', 'issued_date', 'start', 'debut'];
  function reg_cols() { var o = {}; REG.forEach(function (r) { (r.collections || []).forEach(function (c) { if (c && c.key) o[c.key] = c; }); }); return o; }
  function cap(t) { return t ? t.charAt(0).toUpperCase() + t.slice(1) : t; }
  function humanize(k) { return k.replace(/^exb_/, '').replace(/[_\-]+/g, ' ').trim(); }
  function guessTab(cwords) {
    var best = null, bs = 0;
    Object.keys(CAT).forEach(function (id) { var lw = words(CAT[id].label).concat(words(id)); var sc = 0; cwords.forEach(function (x) { if (lw.some(function (y) { return wmatch(x, y); })) sc++; }); if (sc > bs) { bs = sc; best = id; } });
    return best;
  }
  function fresh() { COLS = null; }
  function collections() {
    var now = Date.now(); if (COLS && now - COLS_AT < 1500) return COLS;
    var out = [], rc = reg_cols(), st = null;
    try { st = (typeof exbStorage !== 'undefined') ? exbStorage : null; } catch (e) {}
    if (st) {
      var keys = []; try { for (var i = 0, n = st.length; i < n; i++) { var k = st.key(i); if (k) keys.push(k); } } catch (e) {}
      Object.keys(rc).forEach(function (k) { if (keys.indexOf(k) < 0) keys.push(k); });
      keys.forEach(function (k) {
        if (!/^exb_/.test(k) || SENSITIVE.test(k)) return;
        var v; try { v = JSON.parse(st.getItem(k)); } catch (e) { return; }
        if (!Array.isArray(v) || !v.length || typeof v[0] !== 'object' || v[0] === null) return;
        var kn = KNOWN[k], r = rc[k] || {};
        var name = r.name || (kn && kn[0]) || cap(humanize(k)), aliases = [].concat(r.aliases || [], kn ? kn[2] : [], words(humanize(k)), words(name));
        var cw = []; aliases.forEach(function (a) { words(a).forEach(function (x) { if (cw.indexOf(x) < 0 && !GENERIC[x]) cw.push(x); }); });
        out.push({ key: k, name: name, count: v.length, items: v, words: cw, fields: r.fields || null, tab: r.tab || (kn && kn[1]) || guessTab(cw) });
      });
    }
    COLS = out; COLS_AT = now; return out;
  }
  function blob(it) { var s = []; Object.keys(it).forEach(function (k) { if (SENSITIVE.test(k)) return; var v = it[k]; if (v != null && typeof v !== 'object') s.push(String(v)); }); return norm(s.join(' ')); }
  var MAIN = ['name', 'full_name', 'title', 'label', 'nom', 'titre', 'client', 'project', 'site', 'subject', 'no', 'number', 'ref', 'reference', 'code', 'description'], EXTRA = ['status', 'statut', 'etat', 'date', 'created_at', 'amount', 'total', 'montant', 'price', 'type', 'phone'];
  function summary(it, fields) {
    function val(k) { var v = it[k]; return v != null && v !== '' && typeof v !== 'object' ? String(v).slice(0, 60) : ''; }
    if (fields && fields.length) return fields.map(val).filter(Boolean).join(' — ') || '(vide)';
    var main = '', i; for (i = 0; i < MAIN.length && !main; i++) main = val(MAIN[i]);
    var ex = []; for (i = 0; i < EXTRA.length && ex.length < 3; i++) { var x = val(EXTRA[i]); if (x && x !== main) ex.push(x.length > 10 && /^\d{4}-\d{2}-\d{2}/.test(x) ? x.slice(0, 10) : x); }
    if (!main) { var ks = Object.keys(it).filter(function (k) { return !/(^id$|_id$|^uid)/i.test(k) && !SENSITIVE.test(k) && val(k); }).slice(0, 3); return ks.map(val).join(' — ') || '(vide)'; }
    return main + (ex.length ? ' — ' + ex.join(' · ') : '');
  }
  function sortLatest(items) { var f = null; DATEF.some(function (k) { if (items.some(function (x) { return x[k]; })) { f = k; return true; } }); if (!f) return items.slice(); return items.slice().sort(function (a, b) { return String(b[f] || '').localeCompare(String(a[f] || '')); }); }
  function collectionAnswer(q) {
    q = norm(q); var qw = words(q).filter(function (x) { return !GENERIC[x]; });
    var C = collections(); if (!C.length || !qw.length) return null;
    var best = null, bs = 0, bw = [];
    C.forEach(function (c) { var m = c.words.filter(function (x) { return qw.some(function (y) { return wmatch(x, y); }); }); if (m.length && m.length > bs) { bs = m.length; best = c; bw = m; } });
    if (!best) { var t = findTab(q); if (t) { var cs = C.filter(function (c) { return c.tab === t; }); if (cs.length === 1) { best = cs[0]; bw = best.words; } } }
    if (!best) return null;
    var wantCount = /\b(combien|nombre)\b/.test(q), wantList = /\b(liste\w*|affiche\w*|montre\w*|donne\w*|tous|toutes|voir)\b/.test(q), wantLast = /\b(derni\w*|recent\w*|nouveau\w*|nouvelle\w*)\b/.test(q), wantFind = /\b(cherche\w*|trouve\w*|recherche\w*)\b/.test(q);
    var rest = qw.filter(function (x) { return !bw.some(function (y) { return wmatch(x, y); }) && ['cherche', 'trouve', 'recherche', 'voir', 'nouveau', 'nouvelle'].indexOf(x) < 0 && !/^derni|^recent/.test(x); });
    if (!(wantCount || wantList || wantLast || wantFind || rest.length)) return null;
    var items = best.items, filt = '';
    if (rest.length) { items = items.filter(function (it) { var b = blob(it); return rest.every(function (x) { return b.indexOf(x) >= 0 || b.split(' ').some(function (y) { return wmatch(x, y); }); }); }); filt = rest.join(' '); }
    var tab = best.tab && CAT[best.tab] ? { type: 'goto', tab: best.tab } : null, acts = tab ? [tab] : [];
    if (!items.length) return { answer: best.name + ' : aucun enregistrement' + (filt ? ' pour « ' + filt + ' »' : '') + ' (sur ' + best.count + ').', actions: acts };
    var show = wantLast ? sortLatest(items).slice(0, 5) : (wantList || filt || wantFind) ? sortLatest(items).slice(0, 10) : sortLatest(items).slice(0, 3);
    var head = best.name + ' : ' + items.length + (filt ? ' correspondant(s) à « ' + filt + ' » (sur ' + best.count + ')' : ' enregistrement(s)');
    return { answer: head + (wantCount && !wantList && !wantLast && !filt ? '' : '') + '\n' + show.map(function (it) { return '• ' + summary(it, best.fields); }).join('\n') + (items.length > show.length ? '\n… et ' + (items.length - show.length) + ' autre(s).' : '') + '\n(Données de cet appareil.)', actions: acts };
  }
  function searchAll(term) {
    fresh(); var tk = words(term); if (!tk.length) return null; var hits = [];
    collections().forEach(function (c) { var l = c.items.filter(function (it) { var b = blob(it); return tk.every(function (x) { return b.split(' ').some(function (y) { return wmatch(x, y); }); }); }); if (l.length) hits.push({ c: c, l: l }); });
    if (!hits.length) return { answer: 'Rien trouvé pour « ' + term + ' » dans les données de cet appareil.', actions: [] };
    var acts = []; hits.forEach(function (h) { if (h.c.tab && CAT[h.c.tab] && acts.length < 3) acts.push({ type: 'goto', tab: h.c.tab }); });
    return { answer: 'Résultats pour « ' + term + ' » :\n' + hits.slice(0, 6).map(function (h) { return '• ' + h.c.name + ' (' + h.l.length + ') : ' + h.l.slice(0, 2).map(function (it) { return summary(it, h.c.fields); }).join(' | '); }).join('\n'), actions: acts };
  }

  /* ---------- enregistrement explicite par un module ---------- */
  function register(spec) {
    if (!spec || typeof spec !== 'object') return false;
    spec.keywords = (spec.keywords || []).map(norm).filter(Boolean);
    REG = REG.filter(function (r) { return r.id !== spec.id; }); REG.push(spec);
    var tab = spec.tab || spec.id;
    if (tab && spec.label) { if (!CAT[tab]) CAT[tab] = { id: tab, label: spec.label, icon: spec.icon || '', auto: false }; }
    COLS = null; DIRTY = true; return true;
  }
  function early(raw, q) {
    q = norm(q || raw); var p = ' ' + q + ' ';
    if (/\b(ouvre\w*|ouvrir|va|vas|aller|emmene\w*|navigue\w*)\b/.test(q)) { var nid = findTab(q); if (nid && words(CAT[nid].label).length >= 2) return { answer: 'Voilà : « ' + CAT[nid].label + ' ».', actions: [{ type: 'goto', tab: nid }] }; }
    for (var i = 0; i < REG.length; i++) {
      var r = REG[i]; if (typeof r.answer !== 'function') continue;
      if (!r.keywords.some(function (k) { return p.indexOf(' ' + k + ' ') >= 0 || p.indexOf(' ' + k) >= 0 && k.length >= 5; })) continue;
      try { var a = r.answer(raw, q); if (a && a.answer) return { answer: a.answer, actions: a.actions || [] }; } catch (e) {}
    }
    return null;
  }

  /* ---------- questions générales sur le logiciel ---------- */
  function modulesList() {
    var L = catalog().map(function (e) { return (e.icon ? e.icon + ' ' : '') + e.label; });
    return { answer: L.length + ' modules dans le menu :\n' + L.join(' · ') + '\n\nDites « ouvre … » pour aller dans l’un d’eux, ou « à quoi sert … ? » pour une explication.', actions: [] };
  }
  function whereIs(q) {
    var qw = words(q).filter(function (x) { return !GENERIC[x] && ['faire', 'trouver', 'peux', 'puis', 'acceder', 'creer', 'ajouter', 'comment', 'quel', 'quelle', 'dans', 'situe', 'trouve', 'rubrique', 'enregistrer', 'saisir', 'remplir', 'lancer', 'utiliser', 'imprimer', 'generer', 'exporter', 'importer', 'modifier', 'supprimer', 'consulter', 'gerer', 'voir', 'est', 'trouve', 'mettre', 'regler', 'suivre'].indexOf(x) < 0; });
    if (!qw.length) return null; if (DIRTY) refresh();
    var sc = [];
    Object.keys(CAT).forEach(function (id) {
      var e = CAT[id], lw = words(e.label).concat(words(id)), s = 0;
      qw.forEach(function (x) { if (lw.some(function (y) { return wmatch(x, y); })) s += 3; });
      if (!s) { var el = d.getElementById(id); if (el) { var t = norm((el.textContent || '').slice(0, 1500)); qw.forEach(function (x) { if (t.indexOf(x) >= 0) s += 1; }); } }
      if (s) sc.push([s, id]);
    });
    if (!sc.length) return null; sc.sort(function (a, b) { return b[0] - a[0]; });
    var top = sc.slice(0, 3);
    return { answer: 'Vous pouvez le faire ici :\n' + top.map(function (t) { return '• ' + (CAT[t[1]].icon ? CAT[t[1]].icon + ' ' : '') + CAT[t[1]].label; }).join('\n'), actions: top.map(function (t) { return { type: 'goto', tab: t[1] }; }) };
  }
  function run(raw, q) {
    fresh(); q = norm(q || raw); if (DIRTY) refresh();
    if (/\b(quels?|quelles?|liste\w*|tous les|toutes les|combien de|que contient|disponibles?)\b/.test(q) && /\b(modules?|onglets?|rubriques?|menus?|fonctionnalites?|ecrans?)\b/.test(q) && !/\b(planning|budget)\b/.test(q)) return modulesList();
    if (/\b(que contient le logiciel|que contient l application|tout ce que (?:tu |vous )?(?:sais|savez|connais)|quoi dans le logiciel)\b/.test(q)) return modulesList();
    var id = null;
    if (/\b(explique\w*|a quoi sert|c.?est quoi|que fait|que contient|presente\w*|decris|dis moi ce que|mode d.?emploi)\b/.test(q)) { id = findTab(q); if (id) return { answer: describe(id), actions: [{ type: 'goto', tab: id }] }; }
    if (/^(?:et )?ou\b|\b(dans quel (?:onglet|module|menu)|quel (?:onglet|module|menu)|comment (?:acceder|trouver|aller))\b/.test(q)) { var wi = whereIs(q); if (wi) return wi; }
    var ca = collectionAnswer(q); if (ca) return ca;
    if (/\b(cherche|recherche|trouve)\w*\b.*\b(partout|toutes? les donnees|dans tout|globale?)\b|\b(recherche globale|cherche partout)\b/.test(q)) {
      var term = q.replace(/\b(cherche\w*|recherche\w*|trouve\w*|partout|globale?|dans|tout|toutes?|les|donnees|le|logiciel|de|du|des|la|l)\b/g, ' ').replace(/\s+/g, ' ').trim();
      if (term.length >= 2) return searchAll(term);
    }
    id = findTab(q);
    if (id && /\b(ouvre\w*|ouvrir|va|vas|aller|affiche\w*|montre\w*|acces|emmene\w*)\b/.test(q)) return { answer: 'Voilà : « ' + CAT[id].label + ' ».', actions: [{ type: 'goto', tab: id }] };
    return null;
  }

  /* ---------- lignes de contexte pour l'IA en ligne ---------- */
  function contextLines() {
    fresh(); var L = [], cat = catalog();
    if (cat.length) L.push('Onglets disponibles (identifiant = nom, utilisables avec l’action goto) : ' + cat.slice(0, 90).map(function (e) { return e.id + ' = ' + e.label; }).join(' ; '));
    var C = collections().filter(function (c) { return !KNOWN[c.key]; });
    if (C.length) L.push('Autres jeux de données de cet appareil : ' + C.slice(0, 30).map(function (c) { return c.name + ' (' + c.count + ')'; }).join(', '));
    return L;
  }

  try { if (d.body && w.MutationObserver) new w.MutationObserver(function () { DIRTY = true; }).observe(d.body, { childList: true, subtree: true }); else d.addEventListener('DOMContentLoaded', function () { try { new w.MutationObserver(function () { DIRTY = true; }).observe(d.body, { childList: true, subtree: true }); } catch (e) {} }); } catch (e) {}
  w.EXB_AI = { version: 'V133b-registre-1', sync: sync, catalog: catalog, findTab: findTab, ambiguous: ambiguous, describe: describe, collections: collections, collectionAnswer: collectionAnswer, searchAll: searchAll, register: register, registered: function () { return REG.slice(); }, early: early, run: run, contextLines: contextLines, _dirty: function () { DIRTY = true; COLS = null; } };
})(window);
