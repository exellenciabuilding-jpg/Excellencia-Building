/* Excellencia Building V131 — Studio libre : nouveaux modèles d’affiches (lot C).
 * Groupes « Événements & relations », « Commercial & offres », « Emploi & carrière » et compléments de « Logiciels & formations ».
 * Utilise les gabarits du lot B (EXB_STUDIO_ARCH). N’écrase aucun modèle existant. */
(function (w) {
  'use strict';
  var S = w.EXB_STUDIO, A = w.EXB_STUDIO_ARCH; if (!S || !S.extend || !S.kit || !A) return;
  var Kt = S.kit, K = Kt.K, head = Kt.head, foot = Kt.foot, flat = Kt.flat, NAVY = '#12305e', INK = '#1c2b45', GOLD = '#c9a227';
  var D = {};
  function def(g, key, label, pal, fmt, f) { D[key] = { g: g, l: label, pal: pal, fmt: fmt, f: f }; }
  function EV(key, label, o) { def('Événements & relations', key, label, 'marine', 'a4p', A.event(o)); }
  function OF(key, label, o) { def('Commercial & offres', key, label, 'blanc', 'a4p', A.offer(o)); }
  function JB(key, label, o) { def('Emploi & carrière', key, label, 'blanc', 'a4p', A.job(o)); }

  /* ===== ÉVÉNEMENTS & RELATIONS ===== */
  EV('ev_inauguration', 'Inauguration', { tag: 'INAUGURATION', title: 'INAUGURATION DE …', body: 'Nous avons l’honneur de vous convier à l’inauguration de …, en présence de ….', info: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …\n👔 Tenue : …' });
  EV('ev_premiere_pierre', 'Pose de la première pierre', { tag: 'CÉRÉMONIE', title: 'POSE DE LA PREMIÈRE PIERRE', body: 'Le maître d’ouvrage et l’entreprise vous invitent à la cérémonie de lancement du projet ….' });
  EV('ev_portes_ouvertes', 'Journée portes ouvertes', { tag: 'PORTES OUVERTES', title: 'VENEZ NOUS RENCONTRER', body: 'Visite des ateliers et d’un chantier, démonstrations, conseils personnalisés, rencontre des équipes.', cta: 'Entrée libre · Inscription souhaitée' });
  EV('ev_conference', 'Conférence / atelier technique', { tag: 'CONFÉRENCE', title: '… : ENJEUX ET SOLUTIONS', body: 'Intervenants : …\nThèmes : …\nUne séance de questions-réponses clôturera la rencontre.', cta: 'Places limitées — réservez la vôtre' });
  EV('ev_remise', 'Remise d’attestations / de diplômes', { tag: 'CÉRÉMONIE', title: 'REMISE DES ATTESTATIONS', body: 'La promotion … recevra ses attestations de formation en présence des formateurs, des familles et des partenaires.', cta: 'Félicitations aux lauréats !' });
  EV('ev_salon', 'Salon / exposition', { tag: 'SALON', title: 'NOUS SERONS AU SALON …', body: 'Retrouvez-nous au stand n° … pour découvrir nos réalisations, nos services et nos formations.', info: '📅 Du … au …\n📍 …\n🏷 Stand n° …', cta: 'Présentez cette affiche : avantage à la clé' });
  EV('ev_info', 'Réunion d’information', { tag: 'RÉUNION D’INFORMATION', title: '…', body: 'Thème : …\nPublic concerné : …\nIntervenants : …', cta: 'Merci de confirmer votre présence' });
  EV('ev_anniversaire', 'Anniversaire de l’entreprise', { tag: 'ANNIVERSAIRE', title: '… ANS DÉJÀ !', tdv: 8, body: 'Merci à nos clients, partenaires et équipes qui nous font confiance depuis …. Rejoignez-nous pour célébrer cette étape.', cta: 'Cocktail offert à tous les invités' });
  EV('ev_partenaires', 'Invitation aux partenaires', { tag: 'INVITATION', title: 'SOIRÉE DES PARTENAIRES', body: 'Nous serions honorés de votre présence pour remercier ceux qui bâtissent avec nous.', cta: 'RSVP avant le … : …' });
  EV('ev_cocktail', 'Cocktail / réception', { tag: 'RÉCEPTION', title: 'COCKTAIL DE …', body: 'Un moment convivial pour célébrer ….', info: '📅 Date : …\n🕘 Accueil : … h\n📍 Lieu : …\n👔 Tenue : …', cta: 'Sur invitation' });
  def('Événements & relations', 'ev_programme', 'Programme d’une journée (horaires)', 'blanc', 'a4p', function (F) {
    var k = K(F);
    return flat([head(F, false), k.L(0.2, GOLD),
      k.T('PROGRAMME', 0.213, 24, GOLD, { b: true, al: 'center', ls: 4 }),
      k.T('… (nom de l’événement)', 0.255, 19, NAVY, { b: true, al: 'center', ff: 3, lh: 1.15 }),
      k.rows([['Accueil des invités', '… h'], ['Mot de bienvenue', '… h'], ['Intervention 1 : …', '… h'], ['Pause', '… h'], ['Intervention 2 : …', '… h'], ['Visite / démonstration', '… h'], ['Clôture et cocktail', '… h']], 0.35, 28, INK, NAVY),
      k.T('📅 … · 📍 …', 0.78, 26, NAVY, { b: true, al: 'center' }), foot(F, false)]);
  });

  /* ===== COMMERCIAL & OFFRES ===== */
  OF('co_pack', 'Pack construction (offre complète)', { title: 'PACK « CLÉ EN MAIN » : …', msg: 'Du plan à la clé avec un seul interlocuteur.', rows: [['Plans et études', 'inclus'], ['Construction', 'inclus'], ['Suivi et contrôle', 'inclus'], ['Garantie', '… mois'], ['À partir de', '… $']] });
  OF('co_parcelle', 'Terrain / parcelle à vendre', { photo: 'Photo du terrain', title: 'TERRAIN À VENDRE', rows: [['Localisation', '…'], ['Superficie', '… m²'], ['Titre', '…'], ['Prix', '… $'], ['Accès', 'route / eau / électricité']], cta: 'Visite sur rendez-vous' });
  OF('co_maison_vendre', 'Maison / villa à vendre', { photo: 'Photo de la maison', title: 'VILLA À VENDRE', rows: [['Quartier', '…'], ['Chambres / salles d’eau', '… / …'], ['Surface', '… m²'], ['Prix', '… $']], cta: 'Visitez dès maintenant' });
  OF('co_maison_louer', 'Maison / bureau à louer', { photo: 'Photo du bien', title: 'À LOUER', rows: [['Adresse', '…'], ['Surface', '… m²'], ['Loyer mensuel', '… $'], ['Caution', '… mois'], ['Disponible dès', '…']], cta: 'Contactez-nous pour visiter' });
  OF('co_bureau_etudes', 'Bureau d’études : nos prestations', { title: 'BUREAU D’ÉTUDES', msg: 'Des études fiables, des ouvrages sûrs.', rows: [['Plans d’architecture', '✔'], ['Calcul de structure', '✔'], ['Métré et devis', '✔'], ['Suivi de chantier', '✔'], ['Dossier de permis', '✔']] });
  OF('co_suivi', 'Suivi et contrôle de chantier', { title: 'FAITES SUIVRE VOTRE CHANTIER', msg: 'Un contrôle indépendant protège votre budget, vos délais et la qualité de vos ouvrages.', rows: [['Visites régulières', '✔'], ['Comptes rendus illustrés', '✔'], ['Contrôle des situations', '✔'], ['Assistance à la réception', '✔']] });
  OF('co_livraison', 'Vente et livraison de matériaux', { title: 'MATÉRIAUX LIVRÉS SUR VOTRE CHANTIER', rows: [['Ciment', '… $ / sac'], ['Sable / gravier', '… $ / m³'], ['Fer à béton', '… $ / barre'], ['Blocs', '… $ / unité']], msg: 'Livraison rapide dans …. Tarifs dégressifs selon la quantité.' });
  OF('co_tarifs', 'Liste de prix / tarifs', { title: 'NOS TARIFS', rows: [['… ', '… $'], ['… ', '… $'], ['… ', '… $'], ['… ', '… $'], ['… ', '… $']], msg: 'Prix hors taxes, valables jusqu’au …', cta: 'Devis gratuit sur demande' });
  def('Commercial & offres', 'co_garantie', 'Nos garanties', 'marine', 'sq', A.social({ tag: 'NOS ENGAGEMENTS', icon: '🛡️', title: 'QUALITÉ GARANTIE', msg: '✔ Matériaux contrôlés\n✔ Équipe qualifiée\n✔ Délais respectés\n✔ Garantie de … mois', cta: 'Demandez votre devis' }));
  def('Commercial & offres', 'co_parrainage', 'Parrainage client', 'jaune', 'sq', A.social({ dark: false, tag: 'PARRAINAGE', icon: '🤝', title: 'PARRAINEZ, GAGNEZ !', tdv: 10, msg: 'Présentez un proche qui a un projet : vous recevez …, il bénéficie de ….', cta: 'Parlez-en autour de vous' }));
  def('Commercial & offres', 'co_paiement', 'Paiement échelonné', 'ciel', 'sq', A.social({ dark: false, tag: 'FACILITÉS DE PAIEMENT', icon: '💳', title: 'PAYEZ EN … FOIS', tdv: 10, msg: 'Un acompte de … % au démarrage, le reste selon l’avancement des travaux.', cta: 'Renseignez-vous' }));
  def('Commercial & offres', 'co_flash', 'Story — vente flash', 'rouge', 'story', A.story({ warm: true, tag: 'VENTE FLASH', icon: '⚡', title: '-… % JUSQU’À CE SOIR', msg: 'Sur …, dans la limite des stocks.', cta: 'Écrivez-nous maintenant' }));
  def('Commercial & offres', 'co_engagements', 'Nos engagements (liste)', 'blanc', 'a4p', A.alert({ icon: '🤝', tag: 'NOS ENGAGEMENTS', band: '#1e5fb4', title: 'CE QUE NOUS VOUS PROMETTONS', pre: '✔ ', items: ['Devis clair et détaillé', 'Respect des délais annoncés', 'Sécurité de nos équipes et de vos biens', 'Compte rendu régulier de l’avancement', 'Réponse sous 24 heures'], msg: 'Votre confiance est notre fondation' }));

  /* ===== EMPLOI & CARRIÈRE ===== */
  JB('rh_stage', 'Offre de stage', { tag: 'STAGE', title: 'STAGE EN … (durée : … mois)', body: 'Profil : étudiant(e) en …\nMissions : …\nEncadrement par un professionnel\nIndemnité : …\n\nCandidature : lettre de motivation + CV' });
  JB('rh_chef_chantier', 'Recrutement chef de chantier', { tag: 'RECRUTEMENT', title: 'CHEF DE CHANTIER', body: 'Missions : organiser les équipes, suivre les délais et la sécurité, rendre compte.\nProfil : … ans d’expérience, diplôme en …, sens du contact.\nContrat : …' });
  JB('rh_ouvriers', 'Recrutement d’ouvriers qualifiés', { tag: 'NOUS RECRUTONS', title: 'MAÇONS · FERRAILLEURS · COFFREURS', body: 'Pour un chantier à …, nous recherchons des ouvriers qualifiés.\nExpérience : … ans minimum\nPièces à présenter : pièce d’identité, références\nDébut : …' });
  JB('rh_ingenieur', 'Recrutement ingénieur / technicien', { tag: 'RECRUTEMENT', title: 'INGÉNIEUR / TECHNICIEN EN …', body: 'Missions : études, métrés, suivi de chantier.\nProfil : diplôme en génie civil ou équivalent, maîtrise d’AutoCAD / Excel.\nContrat : …' });
  JB('rh_spontanee', 'Candidatures spontanées', { tag: 'REJOIGNEZ-NOUS', title: 'ENVOYEZ-NOUS VOTRE CANDIDATURE SPONTANÉE', body: 'Nous sommes toujours à la recherche de talents motivés : ingénieurs, techniciens, ouvriers, administratifs.\n\nEnvoyez votre CV et votre lettre de motivation en précisant le poste visé.' });
  def('Emploi & carrière', 'rh_resultats', 'Résultats de recrutement', 'blanc', 'a4p', A.notice({ tag: 'RÉSULTATS', title: 'LISTE DES CANDIDATS RETENUS — POSTE DE …', body: 'Après examen des dossiers et entretiens, sont retenus :\n1. …\n2. …\n3. …', cta: 'Rendez-vous le … à … h avec vos pièces originales' }));
  def('Emploi & carrière', 'rh_employe_mois', 'Employé du mois', 'marine', 'sq', function (F) {
    var k = K(F), B = k.B;
    return flat([head(F, true), k.T('EMPLOYÉ DU MOIS', 0.245, 22, '#f2c94c', { b: true, al: 'center', ls: 4 }),
      k.P(0.3, 0.3, 0.4, 0.3, 'Photo'), k.T('… (nom)', 0.64, 12, '#ffffff', { b: true, al: 'center', ff: 1 }),
      k.T('Pour son sérieux, son esprit d’équipe et son respect de la sécurité. Bravo et merci !', 0.74, 26, '#cfe3ff', { al: 'center', ff: 3, lh: 1.35 }),
      k.T(B.name, 0.92, 34, '#ffffff', { b: true, al: 'center' })]);
  });
  def('Emploi & carrière', 'rh_formation_interne', 'Formation interne du personnel', 'blanc', 'a4p', A.notice({ tag: 'NOTE AU PERSONNEL', title: 'FORMATION INTERNE : …', body: 'Une session de formation destinée au personnel aura lieu :', rows: [['Thème', '…'], ['Public', '…'], ['Date', '…'], ['Lieu', '…'], ['Formateur', '…']], cta: 'Participation obligatoire / recommandée' }));

  /* ===== FORMATIONS (compléments) ===== */
  var F0 = 'Logiciels & formations';
  def(F0, 'fo_rentree', 'Rentrée de formation', 'marine', 'a4p', A.event({ tag: 'RENTRÉE', title: 'NOUVELLE SESSION : …', body: 'Formations pratiques en … avec attestation. Places limitées, inscrivez-vous tôt.', info: '📅 Début : …\n🕘 Horaires : …\n📍 Lieu : …\n💰 Frais : … $', cta: 'Inscriptions ouvertes' }));
  def(F0, 'fo_weekend', 'Cours du week-end', 'vert', 'sq', A.social({ tag: 'COURS DU WEEK-END', icon: '📚', title: 'SAMEDI & DIMANCHE', tdv: 10, msg: 'Formation en … pour les actifs et les étudiants.\nHoraires : … · Durée : … semaines', cta: 'Inscrivez-vous' }));
  def(F0, 'fo_soir', 'Cours du soir', 'noir', 'sq', A.social({ tag: 'COURS DU SOIR', icon: '🌙', title: 'APRÈS LE TRAVAIL, APPRENEZ', tdv: 12, msg: 'Formation en … les soirs de … à ….', cta: 'Places limitées' }));
  def(F0, 'fo_intensif', 'Programme intensif', 'orange', 'a4p', A.alert({ icon: '🎯', tag: 'INTENSIF', band: '#e8590c', title: 'FORMATION INTENSIVE EN … JOURS', tdv: 15, pre: '✔ ', items: ['Théorie et pratique chaque jour', 'Études de cas réelles', 'Évaluation finale', 'Attestation délivrée', 'Support de cours remis'], msg: 'Début le … · Places : …' }));
  def(F0, 'fo_bourse', 'Bourse / réduction pour étudiants', 'ciel', 'sq', A.social({ dark: false, tag: 'ÉTUDIANTS', icon: '🎓', title: '-… % POUR LES ÉTUDIANTS', tdv: 10, msg: 'Sur présentation de votre carte d’étudiant, jusqu’au ….', cta: 'Renseignez-vous' }));
  def(F0, 'fo_tarifs', 'Tarifs des formations', 'blanc', 'a4p', A.offer({ photo: 'Photo de la salle de formation', title: 'NOS FORMATIONS ET TARIFS', rows: [['… (durée … )', '… $'], ['… (durée … )', '… $'], ['… (durée … )', '… $'], ['Pack …', '… $']], cta: 'Paiement possible en … fois' }));
  def(F0, 'fo_temoignage', 'Témoignage d’un apprenant', 'noir', 'sq', A.quote({ q: 'Grâce à cette formation, j’ai trouvé un emploi en quelques semaines. Les cours sont très pratiques.', by: 'Prénom, apprenant(e) en …' }));
  def(F0, 'fo_dernieres', 'Story — dernières places', 'rouge', 'story', A.story({ warm: true, tag: 'DERNIÈRES PLACES', icon: '⏳', title: 'IL RESTE … PLACES', msg: 'Formation : …\nDébut : …', cta: 'Réservez maintenant' }));

  S.extend(D);
})(window);
