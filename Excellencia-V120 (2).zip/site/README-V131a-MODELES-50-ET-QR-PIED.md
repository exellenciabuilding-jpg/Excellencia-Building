# V131a — V128e + V128f appliqués sur V131 : modèles (≥ 50 par onglet), impression des pièces, QR toujours en bas

Base : Excellencia-V120c-v131. Les fichiers touchés étaient identiques à ceux de V128d : mes versions y ont été copiées telles quelles ; `index.html`, `sw.js` et `tools/check.js` n'ont reçu que les lignes ci-dessous.

## 1. Pièces écrites et hub « 📂 Documents de chantier »
- Impression des pièces : plus de bandeau en double ni de 2ᵉ page blanche ; QR en bas de chaque page (`exb-v81-pieces.js`).
- 796 modèles, au moins 50 dans chaque onglet (CCTP 52 lots, CCAP 50+, lettres 60, comptes rendus 56, ordres de service 57, procès-verbaux 71, attestations 57, contrats 57, notes 68, rapports 63, clauses 62, fiches 83, dossier 56, texte libre 56) : `exb-v122-modeles-a.js`, `-b.js`, `-c.js` (chargés après V122e, n'écrasent jamais un modèle existant).
- Hub : filtre dans chaque famille ; bouton sous « Projet 360° ».

## 2. QR de vérification en bas de chaque page, dans tous les modules qui produisent un PDF
| Chemin | Maintenant |
|---|---|
| EXBPrint.html (reçus, rapports, bordereaux, planning, pilotage, fiches…) | QR « Vérifier ce document » fixé en bas de chaque page (`exb-print.js`) |
| EXBPdf.make | QR en bas de toutes les pages (`exb-pdf.js`) |
| Moteur documentaire serveur (devis, module, pièce, fiche) | QR + ligne légale fixés en bas de chaque page, couverture comprise (`docengine/templates-modules.js`) |
| Pièces écrites, EXBDocs (devis/factures/reçus), reçus TFL, cartes de travail | déjà conformes, pas de doublon |
| Plans / cartes / cartouches / certificats / pleine page (@page marge 0), images seules, affiches | volontairement sans pied QR (option `{qr:false}` disponible) |

## Fichiers
Modifiés : `site/exb-v81-pieces.js` · `site/exb-print.js` · `site/exb-pdf.js` · `site/docengine/templates-modules.js` · `site/exb-v122-docs-chantier.js` · `site/index.html` (3 balises) · `site/sw.js` (cache v131a + hors ligne) · `site/tools/check.js` (+5 contrôles).
Nouveaux : `site/exb-v122-modeles-a.js`, `-b.js`, `-c.js` · `docengine-server/tests/qr-pied.test.js` · ce README (+ README-V128e et README-V128f, détail des mesures).
Retour en arrière : restaurer ces fichiers depuis V131 et retirer les 3 balises `exb-v122-modeles-*`.

## Tests
`node tools/check.js` : 543 réussis, 0 échec. Tests serveur qr-pied, doc-piece, doc-fiche, fiche-adapter, qr-svg, bridge-habillage, brand-rep : réussis.
Chromium sur V131 : 796 modèles ouverts et prévisualisés sans erreur ; hub, filtre, bouton ; pièce courte = 1 page ; rapport, tableau de 3 pages et reçu avec QR en bas de chaque page ; plan et page déjà munie d'un QR ignorés.
Non vérifié : impression réelle depuis chaque module (Android / Windows / serveur PDF configuré), page de plans A3, un vrai projet avec données. Contrats, clauses et CCAP : à faire valider par votre conseil juridique.
