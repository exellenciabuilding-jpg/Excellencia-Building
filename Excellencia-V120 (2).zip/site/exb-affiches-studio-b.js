/* Excellencia Building V131 — Studio libre : nouveaux modèles d’affiches (lot B).
 * Gabarits réutilisables (communiqué, alerte sécurité, réseaux sociaux, story, citation, compte à rebours, bannière, événement, offre, emploi)
 * + groupes « Communiqués & avis », « Prévention & sécurité », « Réseaux sociaux ».
 * N’écrase aucun modèle existant (EXB_STUDIO.extend). Tous les textes restent modifiables ; les « … » sont à remplacer.
 * Pour retirer : supprimer la balise <script src="exb-affiches-studio-b.js"> (et -c) de index.html. */
(function (w) {
  'use strict';
  var S = w.EXB_STUDIO; if (!S || !S.extend || !S.kit) return;
  var Kt = S.kit, K = Kt.K, head = Kt.head, foot = Kt.foot, flat = Kt.flat;
  var G = '#c9a227', NAVY = '#12305e', INK = '#1c2b45';
  var SIGN = 'Fait à Kinshasa, le …\nLa Direction';

  /* ---------- gabarits ---------- */
  var A = {};
  /* communiqué / avis / information (A4 portrait, fond blanc) */
  A.notice = function (o) {
    return function (F) {
      var k = K(F), n = (o.rows || []).length, y = 0.37, out = [head(F, false), k.L(0.2, o.gold || G),
        k.T(o.tag, 0.213, o.tagDv || 24, o.tagCol || G, { b: true, al: 'center', ls: 4 }),
        k.T(o.title, 0.255, o.tdv || 19, NAVY, { b: true, al: 'center', ff: 3, lh: 1.15 })];
      if (o.body) { out.push(k.T(o.body, 0.37, 27, INK, { ff: 3, lh: 1.5 })); y = 0.415 + Math.ceil(o.body.length / 58) * 0.034; }
      if (n) { out.push(k.rows(o.rows, y, 30, INK, NAVY)); y += n * 0.05 + 0.02; }
      if (o.cta) out.push(k.T(o.cta, Math.min(y, 0.74), 26, NAVY, { b: true, al: 'center', bg: '#f2c94c', pad: 16, rad: 14 }));
      if (o.sign !== false && !(o.cta && n >= 4)) out.push(k.T(o.sign || SIGN, 0.79, 28, NAVY, { b: true, al: 'right', ff: 3, lh: 1.4 }));
      out.push(foot(F, false)); return flat(out);
    };
  };
  /* alerte / consignes (bandeau coloré, grand pictogramme, puces) */
  A.alert = function (o) {
    return function (F) {
      var k = K(F), band = o.band || '#c0392b', tc = o.tc || '#ffffff';
      return flat([head(F, false), k.R(0, 0.2, 1, 0.075, band),
        k.T(o.tag || 'AVIS IMPORTANT', 0.2235, 20, tc, { b: true, al: 'center', ls: 5, ff: 1 }),
        k.T(o.icon, 0.295, 6.5, band, { al: 'center' }),
        k.T(o.title, 0.41, o.tdv || 15, o.tcol || band, { b: true, al: 'center', ff: 1, lh: 1.05 }),
        k.T(o.items.map(function (i) { return (o.pre || '• ') + i; }).join('\n'), 0.55, 27, INK, { b: true, lh: 1.6 }),
        o.msg ? k.T(o.msg, 0.78, 24, o.msgc || NAVY, { b: true, al: 'center', bg: o.msgbg || '#f2c94c', pad: 16, rad: 14 }) : [],
        foot(F, false)]);
    };
  };
  /* à faire / à éviter */
  A.dodont = function (o) {
    return function (F) {
      var k = K(F);
      return flat([head(F, false), k.L(0.2, G),
        k.T(o.title, 0.215, 18, NAVY, { b: true, al: 'center', ff: 1, lh: 1.1 }),
        k.R(0.07, 0.34, 0.41, 0.42, '#e6f6ec', { rad: 18, stroke: '#2e8b57', sw: 3 }), k.R(0.52, 0.34, 0.41, 0.42, '#fdeaea', { rad: 18, stroke: '#c0392b', sw: 3 }),
        k.X('✔ À FAIRE', 0.09, 0.355, 0.37, 26, '#1e7a46', { b: true, ff: 1 }), k.X(o.yes.map(function (t) { return '• ' + t; }).join('\n'), 0.09, 0.415, 0.37, 31, INK, { lh: 1.55 }),
        k.X('✖ À ÉVITER', 0.54, 0.355, 0.37, 26, '#b3261e', { b: true, ff: 1 }), k.X(o.no.map(function (t) { return '• ' + t; }).join('\n'), 0.54, 0.415, 0.37, 31, INK, { lh: 1.55 }),
        foot(F, false)]);
    };
  };
  /* publication carrée pour les réseaux sociaux */
  A.social = function (o) {
    return function (F) {
      var k = K(F), B = k.B, d = o.dark !== false, tc = d ? '#ffffff' : NAVY, sc = o.warm ? '#ffffff' : (d ? '#cfe3ff' : '#42526e');
      return flat([head(F, d),
        k.T(o.tag || '', 0.245, 30, o.tagc || (d ? '#f2c94c' : G), { b: true, al: 'center', ls: 4 }),
        k.T(o.icon, 0.295, 7, tc, { al: 'center' }),
        k.T(o.title, 0.43, o.tdv || 11, tc, { b: true, al: 'center', ff: 1, lh: 1.05 }),
        k.T(o.msg, 0.62, 25, sc, { al: 'center', lh: 1.35, ff: 3 }),
        o.cta ? k.T(o.cta, 0.78, 24, d ? NAVY : '#ffffff', { b: true, al: 'center', bg: d ? '#f2c94c' : NAVY, pad: 16, rad: 40 }) : [],
        k.T('📞 ' + B.phone + '   ✉ ' + B.email, 0.91, 34, tc, { b: true, al: 'center' })]);
    };
  };
  /* story / statut vertical */
  A.story = function (o) {
    return function (F) {
      var k = K(F), B = k.B, d = o.dark !== false, tc = d ? '#ffffff' : NAVY, sc = o.warm ? '#ffffff' : (d ? '#cfe3ff' : '#42526e'), out;
      out = [head(F, d), k.T(o.tag || '', 0.155, 28, o.tagc || (d ? '#f2c94c' : G), { b: true, al: 'center', ls: 4 }),
        k.T(o.icon, 0.2, 5, tc, { al: 'center' }), k.T(o.title, 0.35, o.tdv || 9, tc, { b: true, al: 'center', ff: 1, lh: 1.05 }),
        k.T(o.msg, 0.54, 22, sc, { al: 'center', lh: 1.4, ff: 3 })];
      if (o.rows) out.push(k.rows(o.rows, 0.65, 24, tc, d ? '#f2c94c' : NAVY));
      if (o.cta) out.push(k.T(o.cta, 0.81, 20, d ? NAVY : '#ffffff', { b: true, al: 'center', bg: d ? '#f2c94c' : NAVY, pad: 20, rad: 50 }));
      out.push(k.T('📞 ' + B.phone + '\n✉ ' + B.email, 0.915, 26, tc, { b: true, al: 'center', lh: 1.5 }));
      return flat(out);
    };
  };
  /* citation */
  A.quote = function (o) {
    return function (F) {
      var k = K(F), B = k.B, d = o.dark !== false, tc = d ? '#ffffff' : NAVY;
      return flat([head(F, d), k.T('“', 0.2, 6, d ? '#f2c94c' : G, { b: true, ff: 3, al: 'center', lh: 0.9 }),
        k.T(o.q, 0.36, o.dv || 17, tc, { ff: 3, i: true, al: 'center', lh: 1.3 }),
        k.T('— ' + o.by, 0.74, 26, d ? '#f2c94c' : G, { b: true, al: 'center' }),
        k.T(B.name + '  ·  ' + B.phone, 0.91, 34, tc, { al: 'center', b: true })]);
    };
  };
  /* compte à rebours / gros chiffre */
  A.count = function (o) {
    return function (F) {
      var k = K(F), B = k.B, d = o.dark !== false, tc = d ? '#ffffff' : NAVY;
      return flat([head(F, d), k.T(o.tag, 0.245, 26, d ? '#f2c94c' : G, { b: true, al: 'center', ls: 4 }),
        k.E(0.32, 0.28, 0.36, d ? '#ffffff' : NAVY, { stroke: '#f2c94c', sw: 10 }),
        k.X(o.big, 0.32, 0.355, 0.36, 7, d ? NAVY : '#ffffff', { b: true, al: 'center', ff: 1, lh: 1 }),
        k.X(o.unit || '', 0.33, 0.51, 0.34, 32, d ? NAVY : '#ffffff', { b: true, al: 'center' }),
        k.T(o.title, 0.69, 16, tc, { b: true, al: 'center', ff: 1, lh: 1.1 }),
        k.T(o.msg, 0.8, 28, d ? '#cfe3ff' : '#42526e', { al: 'center', lh: 1.4 }),
        k.T('📞 ' + B.phone, 0.92, 34, tc, { b: true, al: 'center' })]);
    };
  };
  /* bannière Facebook / LinkedIn */
  A.banner = function (o) {
    return function (F) {
      var k = K(F), B = k.B, W = F.w, H = F.h, d = o.dark !== false, tc = d ? '#ffffff' : NAVY;
      return flat([
        { t: 'img', src: B.logo, x: Math.round(W * 0.04), y: Math.round(H * 0.07), w: Math.round(W * 0.09), h: Math.round(W * 0.09), fit: 'contain', op: 1, rad: 0 },
        k.X(B.name.toUpperCase(), 0.14, 0.1, 0.5, 40, tc, { b: true, ls: 1 }),
        k.X(o.tag, 0.04, 0.3, 0.6, 38, d ? '#f2c94c' : G, { b: true, ls: 3 }),
        k.X(o.title, 0.04, 0.38, 0.62, o.tdv || 15, tc, { b: true, ff: 1, lh: 1.05 }),
        k.X(o.msg, 0.04, 0.72, 0.62, 36, o.warm ? '#ffffff' : (d ? '#cfe3ff' : '#42526e'), { lh: 1.3 }),
        k.E(0.72, 0.2, 0.24, d ? '#ffffff' : NAVY, { stroke: '#f2c94c', sw: 8 }),
        k.X(o.icon, 0.72, 0.31, 0.24, 7, d ? NAVY : '#ffffff', { al: 'center' }),
        k.X('📞 ' + B.phone + '   ✉ ' + B.email, 0.04, 0.9, 0.9, 52, tc, { b: true })]);
    };
  };
  /* événement / invitation (A4, fond sombre) */
  A.event = function (o) {
    return function (F) {
      var k = K(F);
      return flat([head(F, true), k.T(o.tag, 0.225, 26, '#f2c94c', { b: true, ls: 4 }),
        k.T(o.title, 0.27, o.tdv || 12, '#ffffff', { b: true, ff: 1, lh: 1.05 }),
        k.T(o.body || '', 0.47, 26, '#cfe3ff', { ff: 3, lh: 1.45 }),
        k.T(o.info || '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', 0.6, 24, '#ffffff', { b: true, lh: 1.6 }),
        k.T(o.cta || 'Entrée libre — merci de confirmer votre présence', 0.745, 24, NAVY, { b: true, al: 'center', bg: '#f2c94c', pad: 16, rad: 14 }),
        foot(F, true)]);
    };
  };
  /* offre / vente avec photo */
  A.offer = function (o) {
    return function (F) {
      var k = K(F), n = (o.rows || []).length;
      return flat([head(F, false), k.P(0.07, 0.2, 0.86, 0.15, o.photo || 'Photo ici (bouton « ＋ Photo »)'),
        k.T(o.title, 0.37, o.tdv || 17, NAVY, { b: true, al: 'center', ff: 1, lh: 1.1 }),
        o.msg ? k.T(o.msg, 0.455, 30, INK, { ff: 3, lh: 1.4 }) : [],
        n ? k.rows(o.rows, o.msg ? 0.57 : 0.47, 34, INK, NAVY) : [],
        k.T(o.cta || 'Contactez-nous dès maintenant', 0.8, 24, NAVY, { b: true, al: 'center', bg: '#f2c94c', pad: 16, rad: 14 }),
        foot(F, false)]);
    };
  };
  /* emploi / recrutement */
  A.job = function (o) {
    return function (F) {
      var k = K(F), B = k.B, m = k.m;
      return flat([k.R(0, 0, 1, 0.3, NAVY), head(F, true),
        k.T(o.tag || 'NOUS RECRUTONS', 0.17, 11, '#f2c94c', { b: true, ff: 1, lh: 1.05 }),
        k.T(o.title, 0.35, 17, NAVY, { b: true, lh: 1.2 }),
        k.T(o.body, 0.44, 26, INK, { lh: 1.5 }),
        k.T(o.cta || ('Envoyez votre candidature avant le … à ' + B.email), 0.77, 24, NAVY, { b: true, al: 'center', bg: '#f2c94c', pad: 16, rad: 14 }),
        foot(F, false)]);
    };
  };
  w.EXB_STUDIO_ARCH = A;

  var D = {};
  function def(g, key, label, pal, fmt, f) { D[key] = { g: g, l: label, pal: pal, fmt: fmt, f: f }; }
  function N(g, key, label, o) { def(g, key, label, 'blanc', 'a4p', A.notice(o)); }
  function AL(g, key, label, o) { def(g, key, label, o.pal || 'blanc', 'a4p', A.alert(o)); }
  function SO(g, key, label, pal, o) { if (pal === 'orange' || pal === 'rouge') o.warm = true; def(g, key, label, pal, 'sq', A.social(o)); }
  function ST(g, key, label, pal, o) { if (pal === 'orange' || pal === 'rouge') o.warm = true; def(g, key, label, pal, 'story', A.story(o)); }

  /* ===== COMMUNIQUÉS & AVIS ===== */
  var C = 'Communiqués & avis';
  N(C, 'comm_contrat', 'Communiqué — marché remporté', { tag: 'COMMUNIQUÉ', title: 'NOUS REMPORTONS LE MARCHÉ : …', body: 'La Direction informe ses clients et partenaires que l’entreprise a été retenue pour réaliser … à …, pour le compte de ….', rows: [['Maître d’ouvrage', '…'], ['Nature des travaux', '…'], ['Durée', '… mois'], ['Démarrage prévu', '…']] });
  N(C, 'comm_demarrage', 'Communiqué — démarrage de chantier', { tag: 'COMMUNIQUÉ', title: 'DÉMARRAGE DES TRAVAUX : …', body: 'Nous avons le plaisir d’annoncer le lancement officiel du chantier ….', rows: [['Lieu', '…'], ['Début des travaux', '…'], ['Durée prévue', '… mois'], ['Responsable de chantier', '…']] });
  N(C, 'comm_livraison', 'Communiqué — ouvrage livré', { tag: 'COMMUNIQUÉ', title: 'OUVRAGE LIVRÉ : …', body: 'Après … mois de travaux, l’ouvrage … est achevé et réceptionné. Nous remercions le maître d’ouvrage, nos équipes et nos partenaires.', rows: [['Lieu', '…'], ['Surface / capacité', '…'], ['Date de réception', '…']] });
  N(C, 'comm_partenariat', 'Communiqué — nouveau partenariat', { tag: 'COMMUNIQUÉ', title: 'NOUVEAU PARTENARIAT AVEC …', body: 'L’entreprise annonce la signature d’un partenariat avec … afin de …. Ce rapprochement permettra à nos clients de bénéficier de ….', rows: [['Partenaire', '…'], ['Objet', '…'], ['Durée', '…']] });
  N(C, 'comm_nomination', 'Communiqué — nomination', { tag: 'NOMINATION', title: 'M. / Mme … NOMMÉ(E) …', body: 'À compter du …, M. / Mme … est nommé(e) … au sein de l’entreprise. Fort(e) de … ans d’expérience, il / elle aura pour mission de ….\n\nNous lui souhaitons pleine réussite.' });
  N(C, 'comm_rectif', 'Communiqué — rectificatif', { tag: 'RECTIFICATIF', tagCol: '#c0392b', title: 'ERRATUM / PRÉCISION', body: 'Dans notre communication du …, une information erronée a été diffusée :\n• Information erronée : …\n• Information exacte : …\n\nNous prions nos lecteurs de bien vouloir excuser cette erreur.' });
  N(C, 'avis_coupure', 'Avis de perturbation (circulation, eau, électricité)', { tag: 'AVIS À LA POPULATION', tagCol: '#c0392b', title: 'TRAVAUX : PERTURBATIONS ATTENDUES', body: 'Nous informons les riverains et usagers que des travaux auront lieu et pourront perturber :', rows: [['Nature des travaux', '…'], ['Lieu / tronçon', '…'], ['Période', 'du … au …'], ['Horaires', '… h – … h'], ['Itinéraire conseillé', '…']], cta: 'Merci de votre compréhension' });
  N(C, 'avis_paiement', 'Avis aux fournisseurs — modalités de paiement', { tag: 'AVIS AUX FOURNISSEURS', title: 'MODALITÉS DE PAIEMENT', body: 'Pour accélérer le traitement des règlements, nous vous prions de respecter les règles suivantes :', rows: [['Factures à adresser à', '…'], ['Pièces obligatoires', 'bon de commande, bon de livraison'], ['Délai de paiement', '… jours'], ['Jours de paiement', '…']] });
  N(C, 'avis_reprise', 'Avis de reprise des activités', { tag: 'AVIS', title: 'REPRISE DES ACTIVITÉS LE …', body: 'Après la fermeture du … au …, nous avons le plaisir d’informer notre clientèle que nos bureaux et chantiers reprennent leurs activités normales le … à … h.\n\nNous vous souhaitons une excellente reprise.' });
  N(C, 'avis_conge', 'Avis de congés / fermeture annuelle', { tag: 'AVIS', title: 'FERMETURE ANNUELLE', body: 'Nos bureaux seront fermés du … au … inclus. Les chantiers en cours resteront suivis par ….', rows: [['Reprise', '…'], ['Urgences', '…']], cta: 'Bonnes fêtes à tous' });
  N(C, 'avis_assemblee', 'Convocation à l’assemblée générale', { tag: 'CONVOCATION', title: 'ASSEMBLÉE GÉNÉRALE', body: 'Les associés / membres sont convoqués à l’assemblée générale.\nOrdre du jour : rapport d’activité, comptes de l’exercice, résolutions, divers.', rows: [['Date', '…'], ['Heure', '… h'], ['Lieu', '…']] });
  N(C, 'avis_resultats', 'Avis de résultats (concours, test, sélection)', { tag: 'RÉSULTATS', title: 'LISTE DES CANDIDATS RETENUS', body: 'Après examen des candidatures reçues avant le …, sont retenus :\n1. …\n2. …\n3. …', cta: 'Présentez-vous le … à … h avec vos pièces' });
  N(C, 'avis_tarifs', 'Avis de révision des prix', { tag: 'AVIS À LA CLIENTÈLE', title: 'NOUVEAUX TARIFS À COMPTER DU …', body: 'En raison de l’évolution des coûts des matériaux et du transport, nos tarifs sont révisés. Les devis acceptés avant le … restent valables aux anciens prix.', rows: [['… ', '… $'], ['… ', '… $'], ['… ', '… $']] });
  def(C, 'comm_deuil', 'Avis de condoléances', 'noir', 'a4p', function (F) {
    var k = K(F);
    return flat([head(F, true), k.T('🕊️', 0.24, 6, '#e0b54a', { al: 'center' }),
      k.T('NOUS PRÉSENTONS NOS CONDOLÉANCES', 0.36, 16, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.15 }),
      k.T('C’est avec une profonde tristesse que nous avons appris le décès de …, … (fonction), survenu le ….\n\nLa Direction et l’ensemble du personnel présentent leurs sincères condoléances à sa famille et à ses proches, et les assurent de leur soutien.', 0.5, 27, '#e8edf5', { ff: 3, lh: 1.55, al: 'center' }),
      k.T('La Direction', 0.78, 28, '#e0b54a', { b: true, al: 'center', ff: 3 }), foot(F, true)]);
  });

  /* ===== PRÉVENTION & SÉCURITÉ ===== */
  var P = 'Prévention & sécurité';
  AL(P, 'sec_casque', 'Port du casque obligatoire', { icon: '⛑️', tag: 'SÉCURITÉ', title: 'PORT DU CASQUE OBLIGATOIRE', items: ['Dans toute la zone de chantier', 'Sangle bien réglée', 'Remplacer un casque choqué ou fissuré', 'Aucune exception, pour les visiteurs aussi'], msg: 'Un casque ne protège que s’il est porté' });
  AL(P, 'sec_hauteur', 'Travail en hauteur', { icon: '🪜', tag: 'DANGER — CHUTES', title: 'TRAVAIL EN HAUTEUR', items: ['Harnais accroché à un point solide', 'Garde-corps et plinthes en place', 'Jamais seul en hauteur', 'Pas de travail par vent fort ou sol glissant'], msg: 'La chute de hauteur est la 1re cause d’accident grave' });
  AL(P, 'sec_echafaudage', 'Échafaudage : contrôler avant de monter', { icon: '🏗️', tag: 'SÉCURITÉ', title: 'ÉCHAFAUDAGE : CONTRÔLEZ AVANT DE MONTER', tdv: 17, items: ['Assise stable et calée', 'Ancrages à la façade', 'Planchers jointifs, sans trou', 'Garde-corps complets', 'Ne jamais surcharger'], msg: 'Pas de contrôle visé, pas de montée' });
  AL(P, 'sec_danger_zone', 'Danger — zone interdite', { icon: '⚠️', tag: 'DANGER', title: 'ZONE DANGEREUSE — ACCÈS INTERDIT', tdv: 17, items: ['Réservé au personnel autorisé', 'Risque : …', 'Ne pas franchir le balisage', 'En cas de doute, prévenir le chef de chantier'] });
  AL(P, 'sec_electricite', 'Risque électrique', { icon: '⚡', tag: 'DANGER — ÉLECTRICITÉ', band: '#f5b800', tc: '#12305e', tcol: '#12305e', title: 'RISQUE ÉLECTRIQUE', items: ['Ne jamais toucher un câble dénudé', 'Coffrets fermés et verrouillés', 'Rallonges en bon état, hors de l’eau', 'Seul un électricien habilité intervient'], msg: 'En cas d’électrisation : couper, ne pas toucher, appeler les secours', msgbg: '#fdeaea', msgc: '#b3261e' });
  AL(P, 'sec_hygiene', 'Hygiène sur le chantier', { icon: '🧼', tag: 'HYGIÈNE', band: '#2e8b57', title: 'HYGIÈNE SUR LE CHANTIER', items: ['Se laver les mains avant de manger', 'Eau potable disponible', 'Utiliser les sanitaires', 'Ne pas manger dans les zones de travail', 'Déchets dans les bacs'], msg: 'Un chantier propre est un chantier plus sûr' });
  AL(P, 'sec_routier', 'Circulation des engins', { icon: '🚜', tag: 'CIRCULATION', band: '#e8590c', title: 'ATTENTION : ENGINS EN MANŒUVRE', tdv: 17, items: ['Rester visible : gilet obligatoire', 'Ne jamais passer derrière un engin en marche', 'Respecter la vitesse : … km/h', 'Un guide pour chaque marche arrière'], msg: 'Le conducteur ne voit pas tout : gardez vos distances' });
  AL(P, 'sec_manutention', 'Manutention : protéger son dos', { icon: '📦', tag: 'SANTÉ', band: '#1e5fb4', title: 'MANUTENTION : PROTÉGEZ VOTRE DOS', tdv: 17, items: ['Plier les genoux, dos droit', 'Charge près du corps', 'Ne pas tourner en portant', 'Demander de l’aide au-delà de … kg', 'Utiliser brouette ou chariot'] });
  AL(P, 'sec_incendie', 'Incendie : consignes', { icon: '🧯', tag: 'INCENDIE', title: 'EN CAS D’INCENDIE', items: ['Donner l’alerte : …', 'Couper l’énergie si possible', 'Utiliser l’extincteur seulement si sûr', 'Évacuer sans courir vers le point de rassemblement', 'Ne jamais retourner chercher des affaires'], msg: 'Extincteurs situés : …' });
  AL(P, 'sec_secours', 'Premiers secours', { icon: '🩹', tag: 'SECOURS', band: '#2e8b57', title: 'PREMIERS SECOURS', items: ['Trousse de secours : …', 'Secouristes du chantier : …', 'Numéro d’urgence : …', 'Hôpital / centre de santé le plus proche : …', 'Tout accident est déclaré, même léger'] });
  AL(P, 'sec_interdit_public', 'Chantier interdit au public', { icon: '⛔', tag: 'INTERDIT', title: 'CHANTIER INTERDIT AU PUBLIC', items: ['Danger de mort', 'Entrée réservée au personnel autorisé', 'Visiteurs : se présenter à l’accueil', 'Enfants : tenir à distance'], msg: 'Entreprise : … · Contact : …' });
  AL(P, 'sec_visiteurs', 'Visiteurs : consignes d’accueil', { icon: '🦺', tag: 'BIENVENUE', band: '#1e5fb4', title: 'VISITEURS : CONSIGNES D’ACCUEIL', tdv: 17, items: ['S’annoncer et signer le registre', 'Enfiler casque, gilet et chaussures', 'Rester avec l’accompagnateur', 'Ne pas toucher aux machines', 'Suivre le parcours balisé'] });
  AL(P, 'sec_rassemblement', 'Point de rassemblement', { icon: '🟢', tag: 'URGENCE', band: '#2e8b57', title: 'POINT DE RASSEMBLEMENT', items: ['En cas d’alarme : arrêter le travail', 'Marcher calmement vers ce point', 'Se faire pointer par le chef d’équipe', 'Ne partir qu’avec son accord'], msg: 'Lieu du point de rassemblement : …' });
  AL(P, 'sec_fouilles', 'Fouilles et tranchées', { icon: '🕳️', tag: 'DANGER', band: '#8a4b08', title: 'FOUILLES ET TRANCHÉES', items: ['Étaiement au-delà de … m de profondeur', 'Terres déposées loin du bord', 'Échelle de sortie tous les … m', 'Balisage et garde-corps autour', 'Vérifier réseaux enterrés avant de creuser'] });
  AL(P, 'sec_alcool', 'Tolérance zéro alcool et drogues', { icon: '🚫', tag: 'RÈGLE', title: 'TOLÉRANCE ZÉRO : ALCOOL ET DROGUES', tdv: 17, items: ['Interdits sur le chantier', 'Une personne en état d’ébriété est écartée', 'Les engins et la hauteur ne pardonnent pas', 'Le règlement s’applique à tous'] });
  AL(P, 'sec_meteo', 'Orage et forte pluie : arrêt des travaux', { icon: '⛈️', tag: 'MÉTÉO', band: '#42526e', title: 'ORAGE / FORTE PLUIE : ARRÊT DES TRAVAUX', tdv: 17, items: ['Quitter les hauteurs et les engins', 'S’abriter dans un local fermé', 'Ne pas s’abriter sous une grue ou un arbre', 'Reprise sur ordre du chef de chantier'] });
  def(P, 'sec_zero', 'Compteur « jours sans accident »', 'vert', 'sq', A.count({ tag: 'SÉCURITÉ', big: '…', unit: 'JOURS SANS ACCIDENT', title: 'ZÉRO ACCIDENT : L’AFFAIRE DE TOUS', msg: 'Record : … jours. Objectif : …' }));
  AL(P, 'sec_epi', 'Mes équipements de protection (check-list)', { icon: '🦺', tag: 'CHECK-LIST', band: '#1e5fb4', title: 'MES ÉQUIPEMENTS DE PROTECTION', pre: '☐ ', items: ['Casque', 'Chaussures de sécurité', 'Gilet haute visibilité', 'Gants adaptés', 'Lunettes de protection', 'Bouchons / casque anti-bruit', 'Harnais (travail en hauteur)'], msg: 'Je vérifie avant de commencer' });
  def(P, 'sec_gestes', 'Gestes qui sauvent (à faire / à éviter)', 'blanc', 'a4p', A.dodont({ title: 'LES BONS GESTES SUR LE CHANTIER', yes: ['Porter les EPI', 'Signaler un danger', 'Ranger son poste', 'Respecter le balisage'], no: ['Courir sur le chantier', 'Retirer une protection', 'Utiliser son téléphone en hauteur', 'Travailler fatigué'] }));
  def(P, 'sec_story', 'Story — rappel sécurité du jour', 'orange', 'story', A.story({ warm: true, tag: 'SÉCURITÉ', icon: '⛑️', title: 'LA SÉCURITÉ COMMENCE PAR MOI', msg: 'Casque, gilet, chaussures : 3 réflexes avant d’entrer sur le chantier.', cta: 'Zéro accident : ensemble' }));

  /* ===== RÉSEAUX SOCIAUX ===== */
  var R = 'Réseaux sociaux';
  SO(R, 'rs_lundi', 'Bon lundi', 'marine', { tag: 'NOUVELLE SEMAINE', icon: '☀️', title: 'BON LUNDI !', msg: 'Une nouvelle semaine de chantiers commence. Courage et sécurité à toutes les équipes.' });
  SO(R, 'rs_weekend', 'Bon week-end', 'vert', { tag: 'À LUNDI', icon: '🌿', title: 'BON WEEK-END !', msg: 'Merci à tous pour cette semaine de travail. Reposez-vous, on se retrouve lundi.' });
  SO(R, 'rs_conseil', 'Conseil du jour', 'ciel', { dark: false, tag: 'CONSEIL DU JOUR', icon: '💡', title: '…', msg: 'Pourquoi : …\nÀ éviter : …', cta: 'Une question ? Écrivez-nous' });
  SO(R, 'rs_saviez', 'Le saviez-vous ?', 'noir', { tag: 'LE SAVIEZ-VOUS ?', icon: '🧠', title: '…', msg: 'Explication courte et claire : …' });
  SO(R, 'rs_projet', 'Projet de la semaine', 'marine', { tag: 'PROJET DE LA SEMAINE', icon: '🏗️', title: '…', msg: '📍 Lieu : …\n📅 Avancement : … %\n🔜 Prochaine étape : …', cta: 'Suivez-nous pour la suite' });
  SO(R, 'rs_equipe', 'Présentation d’un membre de l’équipe', 'blanc', { dark: false, tag: 'RENCONTREZ L’ÉQUIPE', icon: '👷', title: '… , …', msg: 'Fonction : …\nDans l’entreprise depuis : …\nSa fierté : …' });
  SO(R, 'rs_offre', 'Offre du mois', 'orange', { tag: 'OFFRE DU MOIS', icon: '🔥', title: '-… %', tdv: 6, msg: 'sur … jusqu’au …', cta: 'Appelez dès maintenant' });
  SO(R, 'rs_sondage', 'Sondage / question à la communauté', 'jaune', { dark: false, tag: 'VOTRE AVIS COMPTE', icon: '📊', title: 'QUE PRÉFÉREZ-VOUS ?', msg: '🅰 …\n🅱 …\nRépondez en commentaire !' });
  SO(R, 'rs_merci', 'Merci à la communauté', 'marine', { tag: 'MERCI', icon: '🙏', title: '… ABONNÉS !', msg: 'Grâce à vous, notre communauté grandit. Merci pour votre confiance.' });
  SO(R, 'rs_travail', '1er mai — Fête du travail', 'rouge', { tag: '1er MAI', icon: '🛠️', title: 'FÊTE DU TRAVAIL', tdv: 10, msg: 'Hommage à toutes celles et ceux qui bâtissent chaque jour. Bonne fête à tous les travailleurs !' });
  SO(R, 'rs_femme', '8 mars — Journée des droits des femmes', 'rouge', { tag: '8 MARS', icon: '🌸', title: 'JOURNÉE INTERNATIONALE DES DROITS DES FEMMES', tdv: 15, msg: 'Merci aux femmes qui construisent à nos côtés : ingénieures, techniciennes, ouvrières, gestionnaires.' });
  SO(R, 'rs_independance', '30 juin — Fête de l’indépendance (RDC)', 'vert', { tag: '30 JUIN', icon: '🎉', title: 'FÊTE DE L’INDÉPENDANCE', tdv: 11, msg: 'Joyeuse fête de l’indépendance à toutes et à tous. Bâtissons ensemble un pays plus fort.' });
  SO(R, 'rs_annee', 'Bonne année', 'noir', { tag: 'MEILLEURS VŒUX', icon: '🎆', title: 'BONNE ANNÉE …', msg: 'Santé, réussite et beaux projets. Merci pour votre confiance : ensemble, bâtissons plus haut.' });
  SO(R, 'rs_nouveau', 'Nouveau service', 'marine', { tag: 'NOUVEAUTÉ', icon: '✨', title: '…', msg: 'Désormais disponible : …\nPour qui : …', cta: 'Demandez votre devis' });
  def(R, 'rs_chiffres', 'Chiffres clés de l’entreprise', 'marine', 'sq', function (F) {
    var k = K(F), B = k.B;
    return flat([head(F, true), k.T('NOS CHIFFRES CLÉS', 0.25, 22, '#f2c94c', { b: true, al: 'center', ls: 4 }),
      k.rows([['Années d’expérience', '…'], ['Chantiers livrés', '…'], ['Personnes formées', '…'], ['Collaborateurs', '…']], 0.34, 18, '#ffffff', '#f2c94c'),
      k.T('📞 ' + B.phone + '   ✉ ' + B.email, 0.91, 34, '#ffffff', { b: true, al: 'center' })]);
  });
  def(R, 'rs_decompte', 'Compte à rebours d’un événement', 'marine', 'sq', A.count({ tag: 'BIENTÔT', big: 'J-…', unit: 'JOURS RESTANTS', title: '… (nom de l’événement)', msg: '📅 Date : …  📍 Lieu : …' }));
  def(R, 'rs_citation', 'Citation de l’équipe / du dirigeant', 'noir', 'sq', A.quote({ q: 'Une citation courte qui reflète nos valeurs : qualité, sécurité, respect des engagements.', by: 'Nom, fonction' }));
  def(R, 'rs_story_recrut', 'Story — nous recrutons', 'noir', 'story', A.story({ tag: 'NOUS RECRUTONS', icon: '📢', title: 'POSTE : …', msg: 'Profil : …\nLieu : …', cta: 'Candidature avant le … : écrivez-nous' }));
  def(R, 'rs_story_projet', 'Story — avancement de chantier', 'marine', 'story', A.story({ tag: 'SUIVI DE CHANTIER', icon: '🚧', title: '…', msg: 'Où en est le projet cette semaine ?', rows: [['Fondations', '… %'], ['Structure', '… %'], ['Finitions', '… %']], cta: 'Suivez nos chantiers' }));
  def(R, 'rs_banniere_recrut', 'Bannière — recrutement', 'marine', 'ban', A.banner({ tag: 'NOUS RECRUTONS', icon: '📢', title: 'REJOIGNEZ L’ÉQUIPE', msg: 'Postes ouverts : … · Candidature avant le …' }));
  def(R, 'rs_banniere_promo', 'Bannière — promotion', 'orange', 'ban', A.banner({ warm: true, tag: 'OFFRE SPÉCIALE', icon: '🔥', title: '-… % JUSQU’AU …', msg: 'Sur … · Dans la limite des stocks' }));
  def(R, 'rs_banniere_evenement', 'Bannière — événement', 'noir', 'ban', A.banner({ tag: 'ÉVÉNEMENT', icon: '📅', title: '… LE …', msg: 'Lieu : … · Entrée libre' }));

  S.extend(D);
})(window);
