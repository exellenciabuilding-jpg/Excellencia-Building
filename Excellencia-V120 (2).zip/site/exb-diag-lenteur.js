/* V121c — diagnostic de lenteur : repère les tâches automatiques (minuteries) qui bloquent l'écran plus de 300 ms.
 * Garde les 30 dernières dans « exb_diag_lent » (sur l'appareil seulement, jamais synchronisé). Aucun contenu saisi n'est lu.
 * Rapport : Ctrl + Alt + L (ou EXBDiag.rapport() dans la console). À charger EN PREMIER (avant les autres scripts). */
(function(w){'use strict';
if(w.EXBDiag)return;
var KEY='exb_diag_lent',SEUIL=300,MAX=30;
function lire(){try{return JSON.parse(w.localStorage.getItem(KEY)||'[]')||[]}catch(e){return []}}
function noter(nom,ms){try{var L=lire();L.push({t:new Date().toISOString(),ms:Math.round(ms),job:nom});w.localStorage.setItem(KEY,JSON.stringify(L.slice(-MAX)))}catch(e){}}
function nom(f){try{return String(f).replace(/\s+/g,' ').slice(0,90)}catch(e){return '?'}}
/* V137 : pendant qu'on tape dans un champ (recherche, nom, saisie), les tâches automatiques répétées (≥ 1 s) sont reportées
   au prochain passage : la frappe n'est plus jamais ralentie par une tâche de fond. */
var derniere=0;
try{['keydown','input','compositionupdate'].forEach(function(ev){w.document.addEventListener(ev,function(){derniere=Date.now()},{capture:true,passive:true})})}catch(e){}
function enSaisie(){try{if(Date.now()-derniere>1500)return false;var a=w.document.activeElement,t=a&&a.tagName;return t==='INPUT'||t==='TEXTAREA'||(a&&a.isContentEditable)||false}catch(e){return false}}
function emballer(f,periodique){
  if(typeof f!=='function'||f.__exbDiag)return f;
  var g=function(){if(periodique&&enSaisie())return;var t0=Date.now();try{return f.apply(this,arguments)}finally{var d=Date.now()-t0;if(d>=SEUIL)noter(nom(f),d)}};
  g.__exbDiag=1;return g}
var si=w.setInterval,st=w.setTimeout;
w.setInterval=function(f,d){var a=Array.prototype.slice.call(arguments);a[0]=emballer(f,(d|0)>=1000);return si.apply(w,a)};
w.setTimeout=function(f,d){var a=Array.prototype.slice.call(arguments);if((d|0)>=1000)a[0]=emballer(f);return st.apply(w,a)};
try{if(w.PerformanceObserver&&(w.PerformanceObserver.supportedEntryTypes||[]).indexOf('longtask')>=0)
  new w.PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.duration>=1000)noter('(blocage écran, source inconnue)',e.duration)})}).observe({entryTypes:['longtask']})}catch(e){}
function rapport(){var L=lire();if(!L.length)return 'Aucun blocage de plus de '+SEUIL+' ms enregistré.';
  var par={};L.forEach(function(x){var p=par[x.job]||(par[x.job]={n:0,max:0,der:''});p.n++;p.max=Math.max(p.max,x.ms);p.der=x.t});
  return Object.keys(par).sort(function(a,b){return par[b].max-par[a].max}).map(function(k){return par[k].max+' ms max · '+par[k].n+' fois · '+k}).join('\n')}
w.EXBDiag={rapport:rapport,effacer:function(){try{w.localStorage.removeItem(KEY)}catch(e){}},version:'V121c'};
w.addEventListener('keydown',function(e){if(e.ctrlKey&&e.altKey&&(e.key==='l'||e.key==='L')){e.preventDefault();w.alert('Tâches qui ont bloqué l\u2019écran :\n\n'+rapport())}});
})(window);
