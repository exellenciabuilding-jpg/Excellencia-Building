/* Excellencia Building V134 — SAISIE LIÉE : on choisit au lieu de ressaisir.
 * Complète la liaison V99 (qui relie les fiches APRÈS coup, par leur nom) en agissant au moment de la SAISIE :
 *   - Projets / clients : devis, bureau d'études, cartouche des plans, pièces écrites, stock → le client, le projet, le lieu et le
 *     maître d'ouvrage sont proposés depuis les fiches Clients et Projets ; choisir un projet remplit son client, choisir un client
 *     ne propose que SES projets.
 *   - Apprenants : TP/TD (matricules), impression groupée (participants d'une formation), TFL (étudiant déjà inscrit), listes de
 *     participants (recherche + filtre par formation) ; les noms corrigés dans la fiche participant sont repris dans les notes et paiements.
 *   - Les deux mondes restent séparés : une liste « apprenants » ne propose jamais de client, une liste « projets » jamais d'apprenant.
 * Principe identique à la liaison : on AJOUTE, on ne remplace aucun écran ; une saisie libre reste possible (elle est signalée) ;
 * rien n'est créé ni supprimé automatiquement ; un champ déjà rempli n'est jamais écrasé sans que vous ayez choisi une fiche. */
(function (w, d) {
  'use strict';
  var VERSION = 'V134-SAISIE-LIEE';

  /* ===================== accès aux données (listes vivantes des écrans, sinon stockage) ===================== */
  function store() { try { if (typeof exbStorage !== 'undefined') return exbStorage; } catch (e) {} return w.exbStorage || w.localStorage; }
  function live(k) {
    try {
      switch (k) {
        case 'exb_clients': return typeof exbClients !== 'undefined' ? exbClients : null;
        case 'exb_projects': return typeof exbProjects !== 'undefined' ? exbProjects : null;
        case 'exb_quotes': return typeof exbQuotes !== 'undefined' ? exbQuotes : null;
        case 'exb_studies': return typeof exbStudies !== 'undefined' ? exbStudies : null;
        case 'exb_participants': return typeof participants !== 'undefined' ? participants : null;
        case 'exb_formations': return typeof formations !== 'undefined' ? formations : null;
        case 'exb_trainers': return typeof trainers !== 'undefined' ? trainers : null;
        case 'exb_hr': return typeof exbHr !== 'undefined' ? exbHr : null;
        case 'exb_stock': return typeof exbStock !== 'undefined' ? exbStock : null;
        case 'exb_evaluations': return typeof evaluations !== 'undefined' ? evaluations : null;
        case 'exb_cotations': return typeof cotations !== 'undefined' ? cotations : null;
        case 'exb_payments': return typeof payments !== 'undefined' ? payments : null;
      }
    } catch (e) {}
    return null;
  }
  function rd(k) {
    var l = live(k);
    if (Array.isArray(l)) return l;
    try {
      if (w.EXBS && typeof w.EXBS.get === 'function') { var v = w.EXBS.get(k); if (Array.isArray(v)) return v; }
      var a = JSON.parse(store().getItem(k) || '[]');
      return Array.isArray(a) ? a : [];
    } catch (e) { return []; }
  }
  function wr(k, v) {
    try {
      if (w.EXBLIEN && w.EXBLIEN.wr) return w.EXBLIEN.wr(k, v);
      if (typeof w.save === 'function') w.save(k, v); else store().setItem(k, JSON.stringify(v));
      return true;
    } catch (e) { return false; }
  }
  function norm(s) {
    s = String(s == null ? '' : s);
    try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) {}
    return s.toLowerCase().replace(/\s+/g, ' ').trim();
  }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function byId(id) { return d.getElementById(id); }
  function uniq(a) { return a.length === 1 ? a[0] : null; }

  /* ===================== annuaires : clients, projets, apprenants, formations, fournisseurs ===================== */
  function cname(c) { return c ? (c.full_name || c.company || c.contact || c.id || '') : ''; }
  function clients() { return rd('exb_clients').filter(function (c) { return c && cname(c); }); }
  function clientKeys(c) { return [c.full_name, c.company, c.contact].map(norm).filter(Boolean); }
  function clientById(id) { return id ? clients().filter(function (c) { return c.id === id; })[0] || null : null; }
  function clientByName(n) {
    var k = norm(n); if (!k) return null;
    return uniq(clients().filter(function (c) { return clientKeys(c).indexOf(k) >= 0; }));
  }
  function projects() { return rd('exb_projects').filter(function (p) { return p && p.name; }); }
  function projectById(id) { return id ? projects().filter(function (p) { return String(p.id) === String(id); })[0] || null : null; }
  function clientOfProject(p) { return p ? (clientById(p.client_id) || clientByName(p.client)) : null; }
  function belongs(p, c) {
    if (!p || !c) return false;
    if (p.client_id) return p.client_id === c.id;
    return clientKeys(c).indexOf(norm(p.client)) >= 0;
  }
  function projectsOfClient(c) { return projects().filter(function (p) { return belongs(p, c); }); }

  function parts() { return rd('exb_participants').filter(function (p) { return p && p.name && p.approval_status !== 'REJETE'; }); }
  function pKey(p) { return p.participant_id || p.id || ''; }
  function allFormations() { return rd('exb_formations').filter(function (f) { return f && f.name; }); }
  function formationOf(p) {
    if (!p) return null;
    var F = allFormations(), f = F.filter(function (x) { return p.formation_id && x.formation_id === p.formation_id; })[0];
    return f || uniq(F.filter(function (x) { return norm(x.name) === norm(p.training); }));
  }
  function participantsOfFormation(f) {
    return parts().filter(function (p) { return (f.formation_id && p.formation_id === f.formation_id) || norm(p.training) === norm(f.name); });
  }
  function suppliers() {
    var seen = {}, out = [];
    function add(n, src) { var k = norm(n); if (!k || seen[k]) return; seen[k] = 1; out.push({ name: String(n).trim(), src: src }); }
    ['exb_suppliers', 'exb_v92_suppliers'].forEach(function (k) { rd(k).forEach(function (s) { add(s.name || s.company || s.nom, 'Fournisseur'); }); });
    rd('exb_stock').forEach(function (s) { add(s.supplier, 'Stock'); });
    ['exb_purchase_orders', 'exb_v92_purchase_orders'].forEach(function (k) { rd(k).forEach(function (o) { add(o.supplier || o.supplier_name, 'Commande'); }); });
    rd('exb_v93_subcontracts').forEach(function (s) { add(s.company || s.name || s.supplier, 'Sous-traitant'); });
    return out;
  }

  /* ===================== récents (confort local à l'appareil, jamais synchronisé) ===================== */
  var MRU_K = 'exb_sl_recent';
  function mruGet() { try { return JSON.parse(w.localStorage.getItem(MRU_K) || '{}') || {}; } catch (e) { return {}; } }
  function mruPush(kind, id) {
    if (!id) return;
    try { var m = mruGet(); m[kind] = [id].concat((m[kind] || []).filter(function (x) { return x !== id; })).slice(0, 6); w.localStorage.setItem(MRU_K, JSON.stringify(m)); } catch (e) {}
  }

  /* ===================== sources de suggestions par type ===================== */
  var KIND = {
    client: {
      label: 'client', none: 'Ce nom n’est pas dans le fichier Clients (saisie libre).',
      items: function () { return clients().map(function (c) { return { id: c.id, label: cname(c), sub: [c.company && c.company !== cname(c) ? c.company : '', c.phone, c.email].filter(Boolean).join(' · '), rec: c }; }); }
    },
    project: {
      label: 'projet', none: 'Ce nom n’est pas dans la liste des projets (saisie libre).',
      items: function () { return projects().map(function (p) { var c = clientOfProject(p); return { id: p.id, label: p.name, sub: [c ? cname(c) : p.client, p.location].filter(Boolean).join(' · '), rec: p }; }); }
    },
    participant: {
      label: 'participant', none: 'Ce nom n’est pas dans la liste des participants.',
      items: function () { return parts().map(function (p) { return { id: pKey(p), label: p.name, sub: [p.matricule || pKey(p), p.training].filter(Boolean).join(' · '), extra: [p.phone, p.email].join(' '), rec: p }; }); }
    },
    formation: {
      label: 'formation', none: 'Cette formation n’est pas dans le catalogue (saisie libre).',
      items: function () { return allFormations().map(function (f) { return { id: f.formation_id || f.name, label: f.name, sub: [f.code, f.duration].filter(Boolean).join(' · '), rec: f }; }); }
    },
    supplier: {
      label: 'fournisseur', none: 'Nouveau fournisseur (il sera proposé la prochaine fois).',
      items: function () { return suppliers().map(function (s) { return { id: s.name, label: s.name, sub: s.src, rec: s }; }); }
    },
    company: {
      label: 'entreprise', none: 'Cette entreprise n’est pas dans vos fichiers (saisie libre).',
      items: function () {
        var seen = {}, out = [];
        function add(label, sub, id) { var k = norm(label); if (!k || seen[k]) return; seen[k] = 1; out.push({ id: id || label, label: label, sub: sub }); }
        clients().forEach(function (c) { add(c.company || cname(c), 'Client', c.id); if (c.company && cname(c) !== c.company) add(cname(c), 'Client', c.id); });
        suppliers().forEach(function (s) { add(s.name, s.src, s.name); });
        return out;
      }
    }
  };

  function score(it, q) {
    var hay = norm([it.label, it.sub, it.extra].join(' ')), lab = norm(it.label), toks = q.split(' ').filter(Boolean), s = 0, i;
    for (i = 0; i < toks.length; i++) {
      if (hay.indexOf(toks[i]) < 0) return -1;
      s += lab.indexOf(toks[i]) === 0 ? 3 : (lab.indexOf(' ' + toks[i]) >= 0 ? 2 : 1);
    }
    return s;
  }
  function search(items, q, limit) {
    q = norm(q);
    if (!q) return items.slice(0, limit);
    var r = [];
    items.forEach(function (it) { var s = score(it, q); if (s >= 0) r.push({ it: it, s: s }); });
    r.sort(function (a, b) { return b.s - a.s || (a.it.label < b.it.label ? -1 : 1); });
    return r.slice(0, limit).map(function (x) { return x.it; });
  }

  /* ===================== fenêtre de suggestions (une seule, partagée) ===================== */
  var pop = null, cur = null, sel = -1, shown = [];
  function css() {
    if (byId('exslCss')) return;
    var s = d.createElement('style'); s.id = 'exslCss';
    s.textContent = '#exslPop{display:none;position:fixed;z-index:2147483000;background:#fff;color:#172033;border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.22);max-height:270px;overflow:auto;font:13px Arial,sans-serif;min-width:230px}' +
      '#exslPop .it{padding:8px 10px;cursor:pointer;border-bottom:1px solid #eef2f7}#exslPop .it:last-child{border-bottom:0}#exslPop .it.on,#exslPop .it:hover{background:#e8f0ff}' +
      '#exslPop .it small{display:block;color:#64748b;font-size:11px;margin-top:1px}#exslPop .hd{padding:5px 10px;font-size:11px;color:#64748b;background:#f8fafc}' +
      '.exsl-b{font-size:11px;margin-top:2px;line-height:1.3}.exsl-b.ok{color:#15803d}.exsl-b.free{color:#b45309}.exsl-b.info{color:#1d4ed8}' +
      '.exsl-flt{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 4px}.exsl-flt input,.exsl-flt select{padding:6px;font-size:12px;border:1px solid #cbd5e1;border-radius:8px;max-width:100%;flex:1 1 140px;box-sizing:border-box}' +
      '.exsl-btn{margin:4px 0;padding:7px 12px;font-size:12px;border:1px solid #93c5fd;background:#eff6ff;color:#1e3a8a;border-radius:8px;cursor:pointer}';
    (d.head || d.documentElement).appendChild(s);
  }
  function ensurePop() {
    if (pop) return pop;
    css();
    pop = d.createElement('div'); pop.id = 'exslPop'; pop.setAttribute('role', 'listbox');
    pop.addEventListener('mousedown', function (e) { e.preventDefault(); });
    pop.addEventListener('click', function (e) { var t = e.target.closest ? e.target.closest('.it') : null; if (t) choose(+t.getAttribute('data-i')); });
    d.body.appendChild(pop);
    w.addEventListener('scroll', function () { if (cur) place(); }, true);
    w.addEventListener('resize', function () { if (cur) place(); });
    return pop;
  }
  function place() {
    if (!cur || !pop) return;
    var r = cur.el.getBoundingClientRect(), vh = w.innerHeight || 700, below = vh - r.bottom, h = Math.min(270, pop.scrollHeight || 200);
    pop.style.minWidth = Math.max(230, r.width) + 'px';
    pop.style.left = Math.max(4, Math.min(r.left, (w.innerWidth || 400) - pop.offsetWidth - 4)) + 'px';
    pop.style.top = (below >= h + 8 || below >= r.top ? r.bottom + 2 : Math.max(4, r.top - h - 2)) + 'px';
  }
  function closePop() { if (pop) pop.style.display = 'none'; cur = null; shown = []; sel = -1; }
  function token(el, spec) {
    if (!spec.multi) return el.value;
    var m = /[^,;\n]*$/.exec(el.value); return (m ? m[0] : '').trim();
  }
  function openPop(el) {
    var spec = el.__exsl; if (!spec) return;
    ensurePop(); cur = { el: el, spec: spec };
    var q = token(el, spec), items = spec.items(), all, recent = [];
    if (spec.filter) items = items.filter(function (it) { try { return spec.filter(it); } catch (e) { return true; } });
    if (!norm(q)) {
      var ids = (mruGet()[spec.kind] || []);
      recent = ids.map(function (id) { return items.filter(function (it) { return it.id === id; })[0]; }).filter(Boolean).slice(0, 4);
    }
    var list = search(items, q, 8);
    if (recent.length) list = recent.concat(list.filter(function (it) { return recent.indexOf(it) < 0; })).slice(0, 10);
    shown = list; sel = list.length ? 0 : -1;
    var html = '';
    if (recent.length) html += '<div class="hd">🕘 Récents</div>';
    list.forEach(function (it, i) { html += '<div class="it' + (i === 0 ? ' on' : '') + '" role="option" data-i="' + i + '"><b>' + esc(it.label) + '</b>' + (it.sub ? '<small>' + esc(it.sub) + '</small>' : '') + '</div>'; });
    if (!list.length) html = '<div class="hd">' + esc(norm(q) ? 'Aucune fiche ne correspond — la saisie libre sera conservée.' : 'Aucune fiche enregistrée pour le moment.') + '</div>';
    pop.innerHTML = html; pop.style.display = 'block'; place();
  }
  function hilite() {
    if (!pop) return;
    [].forEach.call(pop.querySelectorAll('.it'), function (n, i) { n.classList.toggle('on', i === sel); if (i === sel && n.scrollIntoView) n.scrollIntoView({ block: 'nearest' }); });
  }
  function choose(i) {
    if (!cur || !shown[i]) return;
    var el = cur.el, spec = cur.spec, it = shown[i];
    setPicked(el, it, true);
    closePop();
  }

  /* ===================== champs liés ===================== */
  function fire(el) { try { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} }
  function setValue(el, v) {
    if (!el) return;
    el.__exslBusy = 1; el.value = v; fire(el); el.__exslBusy = 0;
    if (el.__exsl) resolve(el);
  }
  function badge(el, cls, txt) {
    var b = el.__exslBadge; if (!b) return;
    b.className = 'exsl-b ' + cls; b.textContent = txt || '';
  }
  function setPicked(el, it, user) {
    var spec = el.__exsl;
    if (spec.multi) {
      var cutAt = Math.max(el.value.lastIndexOf(','), el.value.lastIndexOf(';'), el.value.lastIndexOf('\n'));
      var head = cutAt >= 0 ? el.value.slice(0, cutAt + 1) + ' ' : '';
      el.__exslBusy = 1; el.value = head + (spec.valueOf ? spec.valueOf(it) : it.label) + ', '; fire(el); el.__exslBusy = 0;
      resolve(el);
    } else {
      setValue(el, it.label);
    }
    el.dataset.exslId = it.id || '';
    mruPush(spec.kind, it.id);
    if (spec.onPick) { try { spec.onPick(it, user); } catch (e) {} }
    if (el.focus && user && spec.multi) { try { el.focus(); } catch (e) {} }
  }
  function resolve(el) {
    var spec = el.__exsl; if (!spec) return null;
    if (spec.multi) {
      var toks = el.value.split(/[,;\n]+/).map(function (x) { return x.trim(); }).filter(Boolean);
      if (!toks.length) { badge(el, '', ''); return null; }
      var items = spec.items(), ok = 0, bad = [];
      toks.forEach(function (t) { var k = norm(t); if (items.some(function (it) { return norm(it.label) === k || norm(spec.valueOf ? spec.valueOf(it) : '') === k || norm(it.id) === k; })) ok++; else bad.push(t); });
      badge(el, bad.length ? 'free' : 'ok', (bad.length ? '⚠ ' : '✔ ') + ok + ' reconnu(s)' + (bad.length ? ' · non trouvé : ' + bad.slice(0, 3).join(', ') : ''));
      return null;
    }
    var v = norm(el.value), hit = null;
    if (!v) { el.dataset.exslId = ''; badge(el, '', ''); return null; }
    var all = spec.items(), m = all.filter(function (it) { return norm(it.label) === v; });
    if (m.length > 1 && el.dataset.exslId) m = m.filter(function (it) { return it.id === el.dataset.exslId; });
    hit = uniq(m);
    if (hit) { el.dataset.exslId = hit.id; badge(el, 'ok', '✔ Fiche liée : ' + (hit.sub ? hit.label + ' — ' + hit.sub : hit.label)); }
    else { el.dataset.exslId = m.length > 1 ? (el.dataset.exslId || '') : ''; badge(el, 'free', m.length > 1 ? '⚠ Plusieurs fiches portent ce nom : choisissez-en une dans la liste.' : '⚠ ' + spec.none); }
    return hit;
  }
  function attach(el, spec) {
    if (!el || el.__exsl) return false;
    spec.kind = spec.kind || 'client';
    var K = KIND[spec.kind] || KIND.client;
    spec.items = spec.items || K.items; spec.none = spec.none || K.none;
    el.__exsl = spec; el.setAttribute('autocomplete', 'off');
    var b = d.createElement('div'); b.className = 'exsl-b'; el.__exslBadge = b;
    if (el.parentNode) el.parentNode.insertBefore(b, el.nextSibling);
    el.addEventListener('focus', function () { el.__exslTok = (el.__exslTok || 0) + 1; openPop(el); });
    el.addEventListener('click', function () { if (!pop || pop.style.display === 'none') openPop(el); });
    el.addEventListener('input', function () { if (el.__exslBusy) return; el.dataset.exslId = ''; resolve(el); openPop(el); });
    el.addEventListener('blur', function () { var tok = el.__exslTok = (el.__exslTok || 0) + 1; setTimeout(function () { if (el.__exslTok === tok && cur && cur.el === el) closePop(); }, 160); resolve(el); if (spec.onBlur) { try { spec.onBlur(el); } catch (e) {} } });
    el.addEventListener('keydown', function (e) {
      if (!pop || pop.style.display === 'none' || !cur || cur.el !== el) { if (e.key === 'ArrowDown') openPop(el); return; }
      if (e.key === 'ArrowDown') { sel = Math.min(shown.length - 1, sel + 1); hilite(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); hilite(); e.preventDefault(); }
      else if (e.key === 'Enter' && sel >= 0 && shown[sel]) { choose(sel); e.preventDefault(); }
      else if (e.key === 'Escape') { closePop(); }
    });
    resolve(el);
    return true;
  }

  /* ===================== projets ↔ clients : devis, bureau d'études ===================== */
  var hintTimers = {};
  function hint(el, txt) {
    if (!el || !el.__exslBadge) return;
    var b = el.__exslBadge; b.className = 'exsl-b info'; b.textContent = txt;
    clearTimeout(hintTimers[el.id]); hintTimers[el.id] = setTimeout(function () { if (el.__exsl) resolve(el); }, 4500);
  }
  function pairClientProject(cEl, pEl, extra) {
    extra = extra || {};
    if (!cEl || !pEl || cEl.__exsl || pEl.__exsl) return;
    function chosenClient() { return clientById(cEl.dataset.exslId) || clientByName(cEl.value); }
    attach(cEl, {
      kind: 'client',
      onPick: function (it) {
        if (extra.onClient) { try { extra.onClient(it.rec); } catch (e) {} }
        var c = it.rec, cur = projectById(pEl.dataset.exslId) || uniq(projects().filter(function (p) { return norm(p.name) === norm(pEl.value); }));
        if (pEl.value.trim() && cur && !belongs(cur, c)) { setValue(pEl, ''); pEl.dataset.exslId = ''; hint(pEl, '↻ Projet vidé : « ' + cur.name + ' » n’appartient pas à ce client.'); }
        else if (!pEl.value.trim()) {
          var ps = projectsOfClient(c);
          if (ps.length === 1) { setValue(pEl, ps[0].name); pEl.dataset.exslId = ps[0].id; hint(pEl, '↻ Projet repris de la fiche client : ' + ps[0].name); }
          else if (ps.length > 1) hint(pEl, ps.length + ' projets pour ce client : choisissez-le dans la liste.');
        }
      }
    });
    attach(pEl, {
      kind: 'project',
      filter: function (it) { var c = chosenClient(); return !c || belongs(it.rec, c); },
      onPick: function (it) {
        var c = clientOfProject(it.rec);
        if (extra.onProject) { try { extra.onProject(it.rec, c); } catch (e) {} }
        if (c && (!cEl.value.trim() || chosenClient() !== c)) { setValue(cEl, cname(c)); cEl.dataset.exslId = c.id; hint(cEl, '↻ Client repris du projet : ' + cname(c)); }
        else if (!c && it.rec.client && !cEl.value.trim()) { setValue(cEl, it.rec.client); }
      }
    });
  }
  /* après l'enregistrement : les identifiants exacts choisis dans la liste sont posés sur le document (même si deux clients portent le même nom) */
  function wrapAfter(name, fn) {
    var f = w[name]; if (typeof f !== 'function' || f.__exslw) return false;
    var g = function () { var pre = null; try { pre = fn.pre && fn.pre(); } catch (e) {} var r = f.apply(this, arguments); try { fn.post && fn.post(pre); } catch (e) {} return r; };
    g.__exslw = 1; w[name] = g; return true;
  }
  function stamp(list, key, o, pre) {
    if (!pre || !o) return;
    var ch = false;
    if (pre.cid) { var c = clientById(pre.cid); if (c && norm(o.client) === norm(cname(c)) && o.client_id !== c.id) { o.client_id = c.id; ch = true; } }
    if (pre.pid) { var p = projectById(pre.pid); if (p && norm(o.project) === norm(p.name) && o.project_id !== p.id) { o.project_id = p.id; ch = true; } }
    if (ch) wr(key, list);
  }

  /* ===================== cartouche des plans + pièces écrites : reprise du dossier projet ===================== */
  function projectDefaults(pid) {
    var p = projectById(pid); if (!p) return {};
    var c = clientOfProject(p);
    return { client: c ? cname(c) : (p.client || ''), moa: c ? (c.company || cname(c)) : (p.client || ''), lieu: p.location || (c && c.address) || '' };
  }
  function patchCart() {
    var C = w.EXB81; if (!C || typeof C.cart !== 'function') return false;
    if (C.cart.__exsl) return true;
    var f = C.cart;
    var g = function (pid) {
      var own = f.apply(this, arguments) || {}, df = projectDefaults(pid), out = {};
      Object.keys(own).forEach(function (k) { out[k] = own[k]; });
      ['client', 'moa', 'lieu'].forEach(function (k) { if (!out[k] && df[k]) out[k] = df[k]; });
      return out;
    };
    g.__exsl = 1; C.cart = g; return true;
  }
  function scanCartouche() {
    var ov = byId('exbCart'); if (!ov) return;
    var cl = byId('ctCl'), mo = byId('ctMo'), li = byId('ctLi'), sl = ov.querySelector('select');
    if (!cl || cl.__exsl) return;
    function pid() { return sl ? sl.value : ''; }
    attach(cl, { kind: 'client', onPick: function (it) { if (mo && !mo.value.trim()) { setValue(mo, it.rec.company || cname(it.rec)); hint(mo, '↻ Maître d’ouvrage repris du client'); } } });
    if (mo) attach(mo, { kind: 'company' });
    var df = projectDefaults(pid()), note = [];
    [[cl, df.client, 'client'], [mo, df.moa, 'maître d’ouvrage'], [li, df.lieu, 'lieu']].forEach(function (x) {
      if (x[0] && !x[0].value.trim() && x[1]) { x[0].value = x[1]; x[0].setAttribute('data-exsl-auto', '1'); note.push(x[2]); if (x[0].__exsl) resolve(x[0]); }
    });
    if (note.length && !byId('exslCartNote')) {
      var n = d.createElement('div'); n.id = 'exslCartNote'; n.className = 'exsl-b info'; n.style.margin = '4px 0';
      n.textContent = '↻ Repris du dossier projet / client : ' + note.join(', ') + '. Modifiez si besoin puis « Enregistrer les infos projet ».';
      var host = cl.closest ? cl.closest('div') : null; if (host && host.parentNode) host.parentNode.insertBefore(n, host);
    }
  }

  function fillIfEmpty(el, v) { if (el && v && !String(el.value).trim()) { el.value = v; fire(el); return true; } return false; }
  /* ===================== Métré : en-tête du devis (client, adresse, projet, lieu) ===================== */
  function mbField(k) { return d.querySelector('#mb_panel input[data-h="' + k + '"]'); }
  function noList(el) {
    if (!el || el.__exslNoList) return;
    el.__exslNoList = 1; el.removeAttribute('list');
    el.setAttribute = function (n, v) { if (String(n).toLowerCase() === 'list') return; return Element.prototype.setAttribute.call(this, n, v); };
  }
  function scanMetre() {
    var c = mbField('client'), p = mbField('project');
    if (!c || !p || c.__exsl) return;
    noList(c);
    pairClientProject(c, p, {
      onClient: function (cl) { fillIfEmpty(mbField('address'), cl.address); fillIfEmpty(mbField('phone'), cl.phone); fillIfEmpty(mbField('email'), cl.email); },
      onProject: function (pr, cl) { fillIfEmpty(mbField('place'), pr.location); if (cl) { fillIfEmpty(mbField('address'), cl.address); fillIfEmpty(mbField('phone'), cl.phone); fillIfEmpty(mbField('email'), cl.email); } }
    });
  }

  /* ===================== stock : fournisseur et référence ===================== */
  function scanStock() {
    var s = byId('exb_st_supplier'); if (s && !s.__exsl) attach(s, { kind: 'supplier' });
    var ref = byId('exb_mv_ref'), pr = byId('exbLienMvPrj');
    if (ref && pr && !pr.__exslRef) {
      pr.__exslRef = 1;
      pr.addEventListener('change', function () {
        var p = projectById(pr.value); if (!p) return;
        if (!ref.value.trim()) { ref.value = p.name; fire(ref); }
      });
    }
  }

  /* ===================== pièces écrites : « Entreprise » ===================== */
  function scanPieces() { var e = byId('pEn'); if (e && !e.__exsl) attach(e, { kind: 'company' }); }

  /* ===================== formulaire projet : l'adresse du client sert de lieu par défaut ===================== */
  function scanProjectForm() {
    var c = byId('exb_prj_client'), l = byId('exb_prj_location');
    if (!c || !l || c.__exslLoc) return;
    c.__exslLoc = 1;
    c.addEventListener('change', function () {
      var cl = clientByName(c.value);
      if (cl && cl.address && !l.value.trim()) { l.value = cl.address; fire(l); }
    });
  }

  /* ===================== apprenants entre eux ===================== */
  function scanLearners() {
    var mat = byId('hy_mat');
    if (mat && !mat.__exsl) {
      attach(mat, {
        kind: 'participant', multi: true,
        valueOf: function (it) { return it.rec.matricule || it.id; },
        filter: function (it) {
          var s = byId('tp_subject'), v = s && s.value; if (!v) return true;
          var f = allFormations().filter(function (x) { return norm(x.name) === norm(v); })[0];
          return !f || participantsOfFormation(f).indexOf(it.rec) >= 0 || norm(it.rec.training) === norm(f.name);
        }
      });
    }
    var bt = byId('bulk_training'), bn = byId('bulk_names');
    if (bt && !bt.__exsl) {
      attach(bt, { kind: 'formation' });
      if (bn && !byId('exslBulkBtn')) {
        var b = d.createElement('button'); b.type = 'button'; b.id = 'exslBulkBtn'; b.className = 'exsl-btn';
        b.textContent = '👥 Charger les participants de cette formation';
        b.onclick = function () {
          var f = allFormations().filter(function (x) { return norm(x.name) === norm(bt.value); })[0];
          if (!f) { hint(bt, 'Choisissez d’abord une formation du catalogue.'); return; }
          var P = participantsOfFormation(f).filter(function (p) { return p.approval_status === 'APPROUVE' || (!p.approval_status && p.matricule); });
          if (!P.length) { hint(bt, 'Aucun participant approuvé dans « ' + f.name + ' ».'); return; }
          if (bn.value.trim() && typeof w.confirm === 'function' && !w.confirm('Remplacer la liste actuelle par les ' + P.length + ' participants de « ' + f.name + ' » ?')) return;
          bn.value = P.map(function (p) { return p.name; }).join('\n'); fire(bn);
          hint(bt, '↻ ' + P.length + ' participant(s) chargé(s) — aucune ressaisie.');
        };
        bt.parentNode.insertBefore(b, bt.nextSibling.nextSibling || null);
      }
    }
    var id = byId('insc_def'); if (id && !id.__exsl) attach(id, { kind: 'formation' });
    var tn = byId('tflPnom');
    if (tn && !tn.__exsl) {
      attach(tn, {
        kind: 'participant',
        onPick: function (it) {
          var p = it.rec, t = byId('tflPtel'), m = byId('tflPmail');
          if (t && !t.value.trim() && p.phone) { t.value = p.phone; fire(t); }
          if (m && !m.value.trim() && p.email) { m.value = p.email; fire(m); }
          hint(tn, '↻ Étudiant déjà inscrit comme apprenant (' + (p.matricule || pKey(p)) + ') : coordonnées reprises.');
        }
      });
    }
  }

  /* ===================== grandes listes : recherche + filtre par formation / chantier ===================== */
  var SEL_PART = ['eval_participant', 'cot_participant', 'pay_participant', 'receiptParticipantSelect', 'qcm_participant', 'exb_port_participant', 'exbDocParticipant', 'eval_filter', 'cot_filter', 'eval_total_participant'];
  var SEL_OTHER = [['exbDocProject', 'projet'], ['exbLienMvPrj', 'chantier'], ['exbLienCashPrj', 'chantier'], ['exbAsgPrj', 'chantier'], ['exbAsgHr', 'personne'], ['exbDocHr', 'personne'], ['exbDocTrainer', 'formateur']];
  function applyFilter(s) {
    var f = s.__exslF; if (!f) return;
    var q = norm(f.q.value), fv = f.f ? f.f.value : '', pmap = f.f ? partMap() : null, n = 0;
    [].forEach.call(s.options, function (o) {
      if (!o.value) return;
      var ok = !q || norm(o.textContent).indexOf(q) >= 0;
      if (ok && fv) { var p = pmap[o.value]; ok = !!p && (formationOf(p) ? (formationOf(p).formation_id || formationOf(p).name) === fv : norm(p.training) === norm(fv)); }
      o.hidden = !ok; o.disabled = !ok; if (ok) n++;
    });
    f.cnt.textContent = (q || fv) ? n + ' résultat(s)' : '';
  }
  function partMap() { var m = {}; parts().forEach(function (p) { m[pKey(p)] = p; }); return m; }
  function enhanceSelect(s, isPart, what) {
    if (!s || s.tagName !== 'SELECT') return;
    var big = s.options.length > 12;
    if (s.__exslF) { s.__exslF.box.style.display = big ? '' : 'none'; if (big) applyFilter(s); if (isPart && s.__exslF.f) fillFormationFilter(s); return; }
    if (!big) return;
    var box = d.createElement('div'); box.className = 'exsl-flt';
    var q = d.createElement('input'); q.type = 'search'; q.placeholder = '🔎 Filtrer ' + (what ? 'les ' + what + 's' : 'la liste') + '…'; q.setAttribute('aria-label', 'Filtrer la liste');
    box.appendChild(q);
    var fsel = null;
    if (isPart) { fsel = d.createElement('select'); fsel.setAttribute('aria-label', 'Filtrer par formation'); box.appendChild(fsel); }
    var cnt = d.createElement('span'); cnt.style.cssText = 'font-size:11px;color:#64748b;align-self:center'; box.appendChild(cnt);
    s.parentNode.insertBefore(box, s);
    s.__exslF = { box: box, q: q, f: fsel, cnt: cnt };
    q.addEventListener('input', function () { applyFilter(s); });
    if (fsel) { fillFormationFilter(s); fsel.addEventListener('change', function () { applyFilter(s); }); }
  }
  function fillFormationFilter(s) {
    var f = s.__exslF.f; if (!f) return;
    var used = {}, keep = f.value;
    parts().forEach(function (p) { var fo = formationOf(p), k = fo ? (fo.formation_id || fo.name) : (p.training || ''); if (k) used[k] = fo ? fo.name : p.training; });
    var keys = Object.keys(used).sort(function (a, b) { return norm(used[a]) < norm(used[b]) ? -1 : 1; });
    var sig = keys.join('|'); if (f.__sig === sig) return; f.__sig = sig;
    f.innerHTML = '<option value="">Toutes les formations</option>' + keys.map(function (k) { return '<option value="' + esc(k) + '">' + esc(used[k]) + '</option>'; }).join('');
    f.value = keep;
  }
  function scanSelects() {
    SEL_PART.forEach(function (id) { enhanceSelect(byId(id), true, 'participant'); });
    SEL_OTHER.forEach(function (x) { enhanceSelect(byId(x[0]), false, x[1]); });
  }

  /* ===================== noms corrigés : repris dans les notes et paiements (aucune note ni montant modifié) ===================== */
  function syncNames() {
    var P = parts(), map = {}, res = { evaluations: 0, cotations: 0, paiements: 0 };
    P.forEach(function (p) { map[pKey(p)] = p; });
    [['exb_evaluations', 'evaluations'], ['exb_cotations', 'cotations'], ['exb_payments', 'paiements']].forEach(function (x) {
      var L = rd(x[0]), ch = false;
      L.forEach(function (o) {
        var p = o && o.participant_id ? map[o.participant_id] : null; if (!p) return;
        var mod = false;
        if (o.participant_name != null && o.participant_name !== p.name) { o.participant_name = p.name; mod = true; }
        else if (o.name != null && o.participant_name == null && o.name !== p.name && x[0] === 'exb_cotations') { o.name = p.name; mod = true; }
        if (!o.matricule && p.matricule && 'matricule' in o) { o.matricule = p.matricule; mod = true; }
        if (mod) { res[x[1]]++; ch = true; }
      });
      if (ch) wr(x[0], L);
    });
    return res;
  }

  /* ===================== rapport (contrôle) ===================== */
  function report() {
    var out = { version: VERSION, champsLies: [], listesFiltrables: [], recents: mruGet() };
    ['exb_q_client', 'exb_q_project', 'exb_be_client', 'exb_be_project', 'ctCl', 'ctMo', 'pEn', 'exb_st_supplier', 'hy_mat', 'bulk_training', 'insc_def', 'tflPnom'].forEach(function (id) { var e = byId(id); if (e && e.__exsl) out.champsLies.push(id); });
    SEL_PART.concat(SEL_OTHER.map(function (x) { return x[0]; })).forEach(function (id) { var e = byId(id); if (e && e.__exslF) out.listesFiltrables.push(id); });
    return out;
  }

  /* ===================== branchements ===================== */
  function scan() {
    try { pairClientProject(byId('exb_q_client'), byId('exb_q_project')); } catch (e) {}
    try { pairClientProject(byId('exb_be_client'), byId('exb_be_project')); } catch (e) {}
    try { scanMetre(); } catch (e) {}
    try { scanCartouche(); } catch (e) {}
    try { scanPieces(); } catch (e) {}
    try { scanStock(); } catch (e) {}
    try { scanProjectForm(); } catch (e) {}
    try { scanLearners(); } catch (e) {}
    try { scanSelects(); } catch (e) {}
    try { patchCart(); } catch (e) {}
  }
  function hooks() {
    wrapAfter('saveExbQuote', {
      pre: function () { var c = byId('exb_q_client'), p = byId('exb_q_project'), n = byId('exb_q_no'); return { no: n && n.value, cid: c && c.dataset.exslId, pid: p && p.dataset.exslId }; },
      post: function (pre) { if (!pre || !pre.no) return; var L = rd('exb_quotes'); stamp(L, 'exb_quotes', L.filter(function (q) { return q.no === pre.no; })[0], pre); }
    });
    wrapAfter('saveExbStudy', {
      pre: function () { var c = byId('exb_be_client'), p = byId('exb_be_project'), r = byId('exb_be_ref'), id = byId('exb_be_id'); return { id: id && id.value, ref: r && r.value, pname: p && p.value, cid: c && c.dataset.exslId, pid: p && p.dataset.exslId, before: rd('exb_studies').length }; },
      post: function (pre) {
        if (!pre) return;
        var L = rd('exb_studies'), o = pre.id ? L.filter(function (s) { return s.id === pre.id; })[0] : L[L.length - 1];
        if (o && norm(o.project) === norm(pre.pname)) stamp(L, 'exb_studies', o, pre);
      }
    });
    wrapAfter('saveParticipant', { post: function () { setTimeout(syncNames, 50); } });
    /* l'écran Participants / Chantiers s'ouvre : on rebranche */
    var s = w.show;
    if (typeof s === 'function' && !s.__exsl) { var g = function () { var r = s.apply(this, arguments); setTimeout(scan, 120); return r; }; g.__exsl = 1; w.show = g; }
  }
  var timer = null;
  function later() { clearTimeout(timer); timer = setTimeout(scan, 200); }
  function start() {
    css(); hooks(); scan();
    try { syncNames(); } catch (e) {}
    try { new MutationObserver(later).observe(d.body, { childList: true, subtree: true }); } catch (e) { setInterval(scan, 1500); }
    d.addEventListener('click', function (e) { if (pop && cur && e.target !== cur.el && !pop.contains(e.target)) closePop(); });
  }
  w.EXBSL = { version: VERSION, scan: scan, attach: attach, report: report, syncNames: syncNames, projectDefaults: projectDefaults,
    clients: clients, projects: projects, participants: parts, formations: allFormations, suppliers: suppliers, projectsOfClient: projectsOfClient, participantsOfFormation: participantsOfFormation, clientOfProject: clientOfProject };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(start, 1700); }); else setTimeout(start, 1700);
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { readyState: 'complete', getElementById: function () { return null; }, addEventListener: function () {} });
