/* V136 — Notes de calcul Poteau / Dalle / Plancher / Semelle : modèle, cas de charges, enveloppes.
   (node validation/valider-notes.js)  Les notes sont produites par les fonctions RÉELLES de index.html (harness.js) ;
   les valeurs affichées sont recomptées ici à la main et comparées aux résultats du moteur de calcul. */
const H = require("./harness.js"), g = H.get;
const rows = []; let fail = 0;
function chk(id, grandeur, ref, val, tol, ou) {
  const ecart = ref === 0 ? Math.abs(val) : (val - ref) / ref * 100, ok = Math.abs(ecart) <= tol;
  if (!ok) fail++;
  rows.push({ id, grandeur, ref, val, ecart, tol, ok, ou });
}
const bool = (id, grandeur, cond, ou) => chk(id, grandeur, 1, cond ? 1 : 0, 0, ou);
const secs = h => [...h.matchAll(/<h2>(\d+)\. /g)].map(m => +m[1]);
const seq = a => a.length > 0 && a.every((v, i) => v === i + 1);
const propre = h => !/NaN|undefined|Infinity|\[object/.test(h);
const pages = h => (h.match(/class="pg"/g) || []).length;
const totalPages = h => +(h.match(/Page 1 \/ (\d+)/) || [])[1];
const noteTxt = h => h.replace(/<[^>]+>/g, " ");

for (const norme of ["bael", "ec2"]) {
  H.setNorme(norme); const T = norme.toUpperCase();
  /* ===== S1. Poteau ===== */
  const cas = [
    { sec: "r", b: .3, h: .3, H: 3, k: .7, pp: 1, fc: 25, fe: 500, enr: 3, L: [{ t: "G", l: "G", N: 400, Mx: 20, My: 5 }, { t: "Q", l: "Q", N: 150, Mx: 10, My: 0 }] },
    { sec: "c", b: .4, h: .4, H: 3.2, k: 1, pp: 1, fc: 30, fe: 500, enr: 3, L: [{ t: "G", l: "G", N: 700, Mx: 0, My: 0 }, { t: "Q", l: "Q", N: 250, Mx: 0, My: 0 }] },
    { sec: "r", b: .25, h: .4, H: 2.8, k: .5, pp: 0, fc: 25, fe: 500, enr: 3, L: [{ t: "G", l: "G étage 1", N: 150, Mx: 8, My: 0 }, { t: "G", l: "G étage 2", N: 130, Mx: 6, My: 0 }, { t: "Q", l: "Q", N: 90, Mx: 4, My: 0 }, { t: "Q", l: "Vent W", N: 0, Mx: 12, My: 0 }] },
  ];
  cas.forEach((st, i) => {
    const o = g(`(()=>{const st=${JSON.stringify(st)};const r=poteauCalc(st);if(!(r.T&&r.al!==undefined||r.T))return null;const d=potDetail(st,r),q=nmPotData(st,r);return JSON.stringify({Nu:r.Nu,Ns:r.Ns,Mx:r.Mx,My:r.My,q:{NuF:q.NuFoot,NsF:q.NsFoot,Mx:q.Mx,My:q.My,NuH:q.NuHead,ppG:q.ppG},note:potNote(st,r,d)})})()`);
    if (!o) { bool("S1." + (i + 1), T + " poteau cas " + (i + 1) + " : calcul abouti", false, "—"); return; }
    const v = JSON.parse(o), id = "S1." + (i + 1);
    chk(id, T + " poteau : N ELU au pied de la note = r.Nu (kN)", v.Nu, v.q.NuF, 1e-9, "gG·(G+pp)+gQ·Q");
    chk(id, T + " poteau : N ELS au pied de la note = r.Ns (kN)", v.Ns, v.q.NsF, 1e-9, "G+pp+Q");
    chk(id, T + " poteau : Mx ELU de la note = r.Mx (kN.m)", v.Mx, v.q.Mx, 1e-9, "gG·MxG+gQ·MxQ");
    chk(id, T + " poteau : My ELU de la note = r.My (kN.m)", v.My, v.q.My, 1e-9, "gG·MyG+gQ·MyQ");
    chk(id, T + " poteau : N en tête + poids propre au pied = N au pied (kN)", v.q.NuF, v.q.NuH + 1.35 * v.q.ppG, 1e-9, "équilibre vertical");
    bool(id, T + " poteau : sections 1 à 11 numérotées sans trou", seq(secs(v.note)), "note");
    bool(id, T + " poteau : « Page 1 / n » = nombre de pages", totalPages(v.note) === pages(v.note), "6 pages");
    bool(id, T + " poteau : schéma, cas G et Q, diagramme présents (4 figures)", (v.note.match(/<svg/g) || []).length >= 4, "SVG");
    bool(id, T + " poteau : aucune valeur NaN / undefined", propre(v.note), "note");
    bool(id, T + " poteau : modèle, cas de charges, combinaisons, enveloppe présents", /Modèle de calcul et cas de charges/.test(v.note) && /Cas de charges élémentaires/.test(v.note) && /Combinaisons/.test(v.note) && /Sollicitations de calcul — enveloppe/.test(v.note), "plan V135");
  });
  /* ===== S2. Dalle pleine ===== */
  [{ dir: "u", ax: "s", ay: "s", pq: 0 }, { dir: "b", ax: "e", ay: "s", pq: 0 }, { dir: "u", ax: "e", ay: "e", pq: 40 }].forEach((v0, i) => {
    const id = "S2." + (i + 1), o = JSON.parse(g(`(()=>{const st={...dalleDef(),...${JSON.stringify(v0)}};const r=dalleCalc(st);return JSON.stringify({uni:r.uni,pu:r.pu,ps:r.ps,pp:r.pp,G:st.G,Q:st.Q,Vu:r.Vu,mx0:r.mx0,Xt:r.X.t,Xa:r.X.a,note:noteD(st,r,detailD(st,r))})})()`));
    const N = g("nrm()");
    chk(id, T + " dalle : pu = gG·(G+pp)+gQ·Q (kN/m²)", N.gG * (o.G + o.pp) + N.gQ * o.Q, o.pu, 1e-9, "combinaison ELU");
    chk(id, T + " dalle : ps = G+pp+Q (kN/m²)", o.G + o.pp + o.Q, o.ps, 1e-9, "combinaison ELS");
    const txt = noteTxt(o.note), fmt = x => (+x).toFixed(2);
    bool(id, T + " dalle : pu et ps figurent dans le tableau des combinaisons", txt.includes(fmt(o.pu)) && txt.includes(fmt(o.ps)), "note");
    bool(id, T + " dalle : M0, Mt, Ma figurent dans la note", txt.includes(fmt(o.mx0)) && txt.includes(fmt(o.Xt)) && txt.includes(fmt(o.Xa)), "enveloppe");
    bool(id, T + " dalle : sections 1 à 9 numérotées sans trou", seq(secs(o.note)), "note");
    bool(id, T + " dalle : « Page 1 / n » = nombre de pages", totalPages(o.note) === pages(o.note), "5 pages");
    bool(id, T + " dalle : aucune valeur NaN / undefined", propre(o.note), "note");
    bool(id, T + " dalle : poinçonnement conservé quand une charge concentrée est saisie", v0.pq > 0 ? /Poinçonnement/.test(o.note) : true, "note");
    bool(id, T + " dalle : bande Y et diagramme Y présents seulement si portant dans deux sens", o.uni ? !/bande Y/.test(o.note) : /bande Y/.test(o.note), "bidirectionnel");
  });
  /* ===== S3. Plancher multi-travées ===== */
  [["3.5; 4"], ["3.5; 4; 3.8"], ["3; 3.5; 3.5; 3"]].forEach((c, i) => {
    const id = "S3." + (i + 1), o = JSON.parse(g(`(()=>{const st={...dalleDef(),multi:1,Lx:${JSON.stringify(c[0])}};const r=dalleCalcM(st);return JSON.stringify({ok:r.ok,n:r.Ls.length,tr:r.tr.map(x=>x.M),ap:r.ap.map(x=>x.M),pu:r.pu,note:noteDM(st,r,detailDM(st,r))})})()`));
    const txt = noteTxt(o.note), fmt = x => (+x).toFixed(1);
    bool(id, T + " plancher : sections 1 à 7 numérotées sans trou", seq(secs(o.note)), "note");
    bool(id, T + " plancher : « Page 1 / n » = nombre de pages", totalPages(o.note) === pages(o.note), "5 pages");
    bool(id, T + " plancher : un nœud N1…N" + (o.n + 1) + " et une barre B1…B" + o.n + " décrits", new RegExp("N" + (o.n + 1) + "\\b").test(txt) && new RegExp("B" + o.n + "\\b").test(txt) && !new RegExp("B" + (o.n + 1) + "\\b").test(txt.replace(/B1\d/g, "")), "tableaux");
    bool(id, T + " plancher : tous les moments de travée et d'appui retenus figurent", o.tr.concat(o.ap).every(m => txt.includes(fmt(m))), "enveloppe");
    bool(id, T + " plancher : dispositions de Q dessinées (G, Q, 1, 2" + (o.n > 2 ? ", 3" : "") + ")", /disposition 1/.test(txt) && /disposition 2/.test(txt) && (o.n > 2 ? /disposition 3/.test(txt) : !/disposition 3/.test(txt)), "cas");
    bool(id, T + " plancher : aucune valeur NaN / undefined", propre(o.note), "note");
  });
  /* ===== S4. Semelle isolée ===== */
  [{ A: 1.8, B: 1.8, H: .5, G: .45, Q: .2, MG: .02, MQ: .01, ex: .05 }, { A: 2, B: 1.6, H: .6, G: .5, Q: .2, MG: 0, MQ: 0, ex: 0 }, { A: 1.2, B: 1.2, H: .5, G: .3, Q: .1, MG: .1, MQ: .05, ex: 0 }].forEach((v0, i) => {
    const id = "S4." + (i + 1), o = JSON.parse(g(`(()=>{const st={...semDef(),...${JSON.stringify(v0)}};const r=semelleCalc(st);const q=nmSemData(st,r);return JSON.stringify({smax:r.sol.smax,smin:r.sol.smin,part:r.sol.part,Ns:r.Ns,A:st.A,B:st.B,els:q.els,elu:q.elu,note:noteSem(st,r,semDetail(st,r))})})()`));
    chk(id, T + " semelle : σmax ELS de la note (sens A) = r.sol.smax (MPa)", o.smax, o.els.mx, 1e-9, "q0(1+6e/A) ou surface efficace");
    if (!o.part) chk(id, T + " semelle : σmin ELS de la note = r.sol.smin (MPa)", o.smin, o.els.mn, 1e-9, "q0(1−6e/A)");
    bool(id, T + " semelle : décollement cohérent avec le moteur", !!o.els.part === !!o.part, "r.sol.part");
    bool(id, T + " semelle : ELU plus chargé que ELS", o.elu.mx > o.els.mx, "gG,gQ > 1");
    bool(id, T + " semelle : sections 1 à 10 numérotées sans trou", seq(secs(o.note)), "note");
    bool(id, T + " semelle : « Page 1 / n » = nombre de pages", totalPages(o.note) === pages(o.note), "6 pages");
    bool(id, T + " semelle : modèle, cas G et Q, combinaisons, enveloppes présents", /Modèle de calcul et cas de charges/.test(o.note) && /Cas G/.test(o.note) && /Cas Q/.test(o.note) && /enveloppes ELU et ELS/.test(o.note), "plan V135");
    bool(id, T + " semelle : aucune valeur NaN / undefined", propre(o.note), "note");
  });
  /* ===== S5. V138 : poteau, combinaison à effort normal minimal ; dalle deux sens, tranchants Vx / Vy ===== */
  {
    const base = { sec: "r", b: .3, h: .3, H: 3, k: .7, pp: 1, fc: 25, fe: 500, enr: 3, L: [{ t: "G", l: "G", N: 400, Mx: 20, My: 5 }, { t: "Q", l: "Q", N: 150, Mx: 10, My: 0 }] };
    const run = st => JSON.parse(g(`(()=>{const st=${JSON.stringify(st)};const r=poteauCalc(st);const d=potDetail(st,r);return JSON.stringify({as:r.as,wm:r.wm&&{N:r.wm.Nmin,Mx:r.wm.Mx,My:r.wm.My,ok:r.wm.ok,mode:r.wm.mode},note:potNote(st,r,d)})})()`));
    const a = run(base), w = run({ ...base, L: [...base.L, { t: "W", l: "Vent", N: 30, Mx: 40, My: 0 }] }), t = run({ ...base, L: [{ t: "G", l: "G", N: 300, Mx: 0, My: 0 }, { t: "Q", l: "Q", N: 100, Mx: 0, My: 0 }, { t: "W", l: "Vent", N: 260, Mx: 30, My: 0 }] });
    bool("S5.1", T + " poteau : sans ligne W, aucune combinaison 3", a.wm === null && !/effort normal minimal<\/td>/.test(a.note), "r.wm");
    chk("S5.2", T + " poteau : N min = G + pp − 1,5·|NW| (kN)", 406.75 - 1.5 * 30, w.wm.N, 1e-6, "pp = 6,75");
    chk("S5.3", T + " poteau : Mx min = |MxG| + 1,5·|MxW| (kN.m)", 20 + 1.5 * 40, w.wm.Mx, 1e-9, "vent réversible");
    bool("S5.4", T + " poteau : combinaison 3 vérifiée et présente dans la note", w.wm.ok && /effort normal minimal/.test(w.note), "note");
    bool("S5.5", T + " poteau : traction détectée (N min ≤ 0), contrôle simplifié", t.wm.N < 0 && t.wm.mode === "traction" && t.wm.ok, "N = " + t.wm.N);
    bool("S5.6", T + " poteau : les armatures ne diminuent jamais avec le vent", w.as >= a.as, a.as + " → " + w.as);
    bool("S5.7", T + " poteau : note sans NaN / undefined", propre(w.note) && propre(t.note), "note");
    const d = JSON.parse(g(`(()=>{const st={...dalleDef(),lx:4,ly:5,h:.16,G:1.5,Q:2.5,pp:1,dir:"b",ax:"e",ay:"e"};const r=dalleCalc(st);return JSON.stringify({pu:r.pu,lx:r.lx,ly:r.ly,Vx:r.Vx,Vy:r.Vy,Vu:r.Vu,h:nmDalleEnv(st,r)})})()`));
    chk("S5.8", T + " dalle 2 sens : Vu,x = pu·lx·ly/(2·ly+lx) (kN/m)", d.pu * d.lx * d.ly / (2 * d.ly + d.lx), d.Vx, 1e-9, "BAEL A.5.2");
    chk("S5.9", T + " dalle 2 sens : Vu,y = pu·lx/3 (kN/m)", d.pu * d.lx / 3, d.Vy, 1e-9, "BAEL A.5.2");
    chk("S5.10", T + " dalle 2 sens : Vu retenu = max(Vx ; Vy)", Math.max(d.Vx, d.Vy), d.Vu, 1e-9, "vérification");
    bool("S5.11", T + " dalle 2 sens : tranchant tracé dans les deux sens", /Vu,x/.test(d.h) && /Vu,y/.test(d.h) && propre(d.h), "note");
  }
  /* ===== S6. V139 : béton au feu (EN 1992-1-2) — poteau (méthode A, éq. 5.7), dalle (tableau 5.8), semelle ===== */
  {
    const base = { sec: "r", b: .3, h: .3, H: 3, k: .7, pp: 1, fc: 25, fe: 500, enr: 3, L: [{ t: "G", l: "G", N: 400, Mx: 20, My: 5 }, { t: "Q", l: "Q", N: 150, Mx: 10, My: 0 }] };
    const run = st => JSON.parse(g(`(()=>{const st=${JSON.stringify(st)};const r=poteauCalc(st);const d=r.T?potDetail(st,r):null;return JSON.stringify({feu:r.feu&&{rf:r.feu.rf,R:r.feu.x.R,Ra:r.feu.x.Ra,Rl:r.feu.x.Rl,Rb:r.feu.x.Rb,Rn:r.feu.x.Rn,Rn_:r.feu.x.Rn_,om:r.feu.omega,ok:r.feu.ok},D:r.D.map(x=>x.g+"|"+x.m),note:d?potNote(st,r,d):""})})()`));
    const a = run(base), f60 = run({ ...base, rf: 60 }), f240 = run({ ...base, rf: 240, b: .25, h: .25 });
    bool("S6.1", T + " poteau : sans exigence de feu, aucune section feu dans la note", a.feu === null && !/Résistance au feu \(EN 1992-1-2\)/.test(a.note), "r.feu");
    chk("S6.2", T + " poteau R60 : Ra = 1,6·(a − 30), a = (enrobage + 1,8) cm (min)", 1.6 * (48 - 30), f60.feu.Ra, 1e-9, "a = 48 mm");
    chk("S6.3", T + " poteau R60 : Rl = 9,6·(5 − l0,fi), l0,fi = 0,7·3 = 2,1 m", 9.6 * (5 - 2.1), f60.feu.Rl, 1e-9, "éq. 5.7");
    chk("S6.4", T + " poteau R60 : Rb = 0,09·b', b' = 300 mm", 27, f60.feu.Rb, 1e-9, "b' = 4Ac/u");
    const Rref = 120 * Math.pow((f60.feu.Rn_ + f60.feu.Ra + f60.feu.Rl + f60.feu.Rb + f60.feu.Rn) / 120, 1.8);
    chk("S6.5", T + " poteau R60 : R = 120·[(Rηfi+Ra+Rl+Rb+Rn)/120]^1,8 (min)", Rref, f60.feu.R, 1e-9, "éq. 5.7");
    bool("S6.6", T + " poteau R60 : note avec section feu, sans NaN, pages cohérentes", /Résistance au feu \(EN 1992-1-2\)/.test(f60.note) && propre(f60.note) && totalPages(f60.note) === pages(f60.note), "note");
    bool("S6.7", T + " poteau R240 sur petite section : erreur « insuffisante » cohérente avec R < 240", f240.feu.R < 240 && !f240.feu.ok && f240.D.some(x => /^erreur\|Résistance au feu insuffisante/.test(x)), "R = " + f240.feu.R.toFixed(0));
    const dal = (rf, extra) => JSON.parse(g(`(()=>{const st={...dalleDef(),lx:4,ly:5,h:.16,enr:.03,G:1.5,Q:2.5,pp:1,rf:${rf},...${JSON.stringify(extra)}};const r=dalleCalc(st);return JSON.stringify({feu:r.feu&&{hmin:r.feu.x.hmin,amin:r.feu.x.amin,ok:r.feu.ok},ok:r.ok,D:r.D.map(x=>x.g+"|"+x.m),note:r.ok?noteD(st,r,detailD(st,r)):""})})()`));
    const d0 = dal(0, { dir: "u" }), d60 = dal(60, { dir: "u" }), d120 = dal(120, { dir: "b", ax: "e", ay: "e", ly: 5, lx: 4 }), d240 = dal(240, { dir: "u" });
    bool("S6.8", T + " dalle : sans exigence, r.feu nul", d0.feu === null, "r.feu");
    bool("S6.9", T + " dalle R60 un sens : h ≥ 80 mm et a ≥ 20 mm (tableau 5.8), note présente", d60.feu.hmin === 80 && d60.feu.amin === 20 && d60.feu.ok && /Résistance au feu \(EN 1992-1-2\)/.test(d60.note) && propre(d60.note), "h=160, a=35");
    bool("S6.10", T + " dalle R120 deux sens ly/lx = 1,25 : h ≥ 120 mm, a ≥ 20 mm", d120.feu.hmin === 120 && d120.feu.amin === 20 && d120.feu.ok, "colonne ≤ 1,5");
    bool("S6.11", T + " dalle R240 (h = 160 < 175 mm) : non vérifiée, calcul marqué non conforme", d240.feu.ok === false && d240.ok === false && d240.D.some(x => /^erreur\|Résistance au feu/.test(x)), "r.ok = faux");
    const s = g(`(()=>{const st={...semDef(),A:1.8,B:1.8,H:.5,G:.45,Q:.2,MG:0,MQ:0,ex:0};const r=semelleCalc(st);return noteSem(st,r,semDetail(st,r))})()`);
    bool("S6.12", T + " semelle : mention « sans objet » au feu et note propre", /sans objet pour une fondation enterrée/.test(s) && propre(s), "note");
  }
  /* ===== S7. V139 : rupture en bloc du bois, platine acier (EC5 annexe A) — recomptée à la main ===== */
  {
    const run = o => JSON.parse(g(`JSON.stringify(M.bbloc.run(${JSON.stringify(o)}))`)), val = (r, k) => r.rows.find(x => x[0].startsWith(k))[1];
    const b = { cl: 1, sc: 1, du: 2, d: 12, fu: 400, pl: 0, n: 3, nr: 2, t: 100, a1: 70, a2: 50, a3: 90, F: 20 };
    const r = run(b);
    // C24 : ft0 = 14,5 ; fv = 4 ; ρk = 350 ; kmod = 0,8 ; γM = 1,3 ; d0 = 13 mm
    const d = 12, d0 = 13, fh = .082 * (1 - .01 * d) * 350, My = .3 * 400 * Math.pow(d, 2.6), t = 100;
    const a = .4 * fh * t * d, bb = 1.15 * Math.sqrt(2 * My * fh * d), mode = a < bb ? "a" : "b", tef = mode === "a" ? .4 * t : 1.4 * Math.sqrt(My / (fh * d));
    const Lv = 2 * (90 + 2 * 70 - 2.5 * d0), Lt = 1 * (50 - d0), At = Lt * t, Av = Lv * (Lt + 2 * tef);
    const Rk = Math.max(1.5 * At * 14.5, .7 * Av * 4) / 1000, Rd = .8 * Rk / 1.3;
    const num = s => parseFloat(String(s).replace(",", "."));
    chk("S7.1", "rupture en bloc : Lnet,v = 2·[a3 + (n−1)·a1 − (n−0,5)·d0] (mm)", Lv, num(val(r, "Lnet,v").split("·")[0]), 1e-2, "d0 = d + 1");
    chk("S7.2", "rupture en bloc : Fbs,Rk = max(1,5·Anet,t·ft ; 0,7·Anet,v·fv) (kN)", Rk, num(val(r, "Fbs,Rk")), .1, "annexe A (A.1)");
    chk("S7.3", "rupture en bloc : Fbs,Rd = kmod·Fbs,Rk/γM (kN)", Rd, num(val(r, "Fbs,Rd")), .1, "kmod = 0,8");
    bool("S7.4", "rupture en bloc : mode de ruine « " + mode + " » retenu comme le plus faible", new RegExp("\\(" + mode + "\\)").test(val(r, "Mode")), "plaque mince");
    const k = run({ ...b, F: 2 * Rd }), ok = run({ ...b, F: .5 * Rd });
    bool("S7.5", "rupture en bloc : F > Fbs,Rd → erreur ; F < Fbs,Rd → aucune erreur", k.msgs.some(x => x[0] === "erreur") && !ok.msgs.some(x => x[0] === "erreur"), "taux");
    const e = run({ ...b, a3: 10, a1: 10 });
    bool("S7.6", "rupture en bloc : géométrie incohérente (Lnet,v ≤ 0) signalée", e.msgs.some(x => x[0] === "erreur" && /Géométrie/.test(x[1])), "a3, a1 trop faibles");
    const th = run({ ...b, pl: 1 });
    bool("S7.7", "rupture en bloc : platine épaisse → mode (c), (d) ou (e), résultat fini", /\((c|d|e)\)/.test(val(th, "Mode")) && isFinite(num(val(th, "Fbs,Rk"))), "plaque épaisse");
    bool("S7.8", "rupture en bloc : avertissement « à confirmer sur la norme » toujours présent", r.msgs.some(x => x[0] === "alerte" && /à confirmer/.test(x[1])), "transparence");
  }
}

module.exports = { rows, fail };
if (require.main === module) {
  let n = 0;
  for (const r of rows) { n++; console.log((r.ok ? "OK  " : "ÉCHEC ") + r.id + " " + r.grandeur + (r.ref === 1 && r.tol === 0 ? "" : " : réf. " + (+r.ref).toPrecision(6) + " | note " + (+r.val).toPrecision(6) + " | écart " + r.ecart.toExponential(1) + " %") + "  [" + r.ou + "]"); }
  console.log("\n" + n + " contrôles, " + fail + " écart(s) hors tolérance");
  process.exit(fail ? 1 : 0);
}
