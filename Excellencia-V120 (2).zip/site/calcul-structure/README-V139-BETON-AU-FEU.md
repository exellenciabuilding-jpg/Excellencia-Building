# V139 — Béton au feu (EN 1992-1-2) et rupture en bloc du bois (EC5 annexe A) — point 3

## Ce qui est branché
- **Poteau** : nouveau champ « Résistance au feu exigée » (R30 à R240). Méthode A, §5.3.2, éq. 5.7 : R = 120·[(Rηfi + Ra + Rl + Rb + Rn)/120]^1,8.
  - μfi = 0,7 (sécuritaire) ; ω = As·fyd/(Ac·fcd) avec les armatures retenues par le calcul ; a = enrobage + 1,8 cm (convention du logiciel) ; l0,fi = k·H, au moins 2 m ; b' = 4Ac/u.
  - Résultat dans les messages (erreur si R < R exigé) et dans la note de calcul (section « Résistance au feu », page 5).
- **Dalle pleine** (une travée et multi-travées) : même champ. Tableau 5.8 : épaisseur minimale et distance d'axe des aciers inférieurs (un sens, ou deux sens ly/lx ≤ 1,5 / 1,5 à 2 si bidirectionnelle). Non satisfait : calcul marqué non conforme.
- **Semelle** : mention « sans objet » dans la note (fondation enterrée ; pas de méthode simplifiée dans l'EN 1992-1-2).
- Fichiers : `exb-feu-beton.js` (fonctions pures, `window.EXBF`), `index.html`, `sw.js` (précache), `test-feu-beton.js`, `validation/valider-notes.js` (section S6), `validation/harness.js`.

## Limites (à lire)
- Formule 5.7 recoupée avec l'exemple Dlubal VE1026 (R ≈ 82-83 min) et l'exemple du Concrete Centre ; tableau 5.8 vérifié sur le texte de la norme (adoption DSTU). **Pas relu sur la norme officielle** : conditions d'application de la méthode A (excentricité du 1er ordre, h/b, nombre de barres).
- Dalle continue : valeurs d'une dalle simplement appuyée (colonne ambiguë selon les sources, côté sécurité).
- Le poteau BAEL simple (tuile « Calcul Poteau » de l'écran Calculs) n'est pas concerné ; seul le module Poteau avec descente de charges l'est.
- Rupture en bloc du bois : voir la section ci-dessous (formules à confirmer sur la norme).

## Rupture en bloc du bois (nouveau module « Rupture en bloc du bois — platine acier »)
- Assemblage **acier-bois** (l'annexe A ne traite pas le bois-bois) : platine extérieure, cisaillement simple, un groupe de fixations, effort parallèle au fil.
- Fbs,Rk = max{1,5·Anet,t·ft,0,k ; 0,7·Anet,v·fv,k} ; Anet,t = Lnet,t·t ; Anet,v = Lnet,v·t (mode e) sinon Lnet,v·(Lnet,t + 2·tef) ; Fbs,Rd = kmod·Fbs,Rk/γM (γM = 1,3).
- Lnet,v = 2·[a3,t + (n−1)·a1 − (n−0,5)·d0] ; Lnet,t = (nr−1)·(a2 − d0) ; d0 = d + 1 mm ; tef selon le mode de Johansen (mince : a, b ; épaisse : c, d, e).
- **À confirmer sur le texte officiel EN 1995-1-1:2004+A1:2008** : la géométrie des longueurs nettes, d0 et la forme de tef pour le mode (c) (le « 4 » sous la racine). Le module affiche cet avertissement à chaque calcul. Pour (c), l'expression retenue est la plus prudente.
- Fichiers : `index.html` (module `bbloc`, tuile ajoutée), `../exb-calcul-structure.js` (menu). Les messages des modules Assemblage bois boulonné et Fendage renvoient vers ce module.

## Validation
`npm run test:calcul` : `test-feu-beton.js` (15), valider.js 111, valider-robot.js 206, valider-notes.js 258 (dont S6 : 24, S7 : 8 contrôles par norme × 2), 0 écart.
Retour en arrière : restaurer index.html et sw.js de V139 d'origine, supprimer exb-feu-beton.js.
