/* Tests V139 du module exb-feu-beton.js (node test-feu-beton.js). Cas de référence : exemple Dlubal VE1026 et exemple Concrete Centre. */
const F = require("./exb-feu-beton.js"), assert = require("assert");
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const close = (a, b, t, m) => ok(Math.abs(a - b) <= t, `${m} : ${a} ≠ ${b}`);
// Dlubal VE1026 : μfi=0,57 ω=0,689 a=40 l0,fi=2,1 b'=200 (carré 200×200) 4 barres, αcc=0,85 → Rηfi 35,69 ; Ra 16 ; Rl 27,84 ; Rb 18 ; R ≈ 82-83
let r = F.poteauFeu({ mufi: .57, omega: .689, a: 40, l0fi: 2.1, b: 200, h: 200, n: 4, acc: .85 });
close(r.Rn_, 35.69, .01, "Rηfi Dlubal"); close(r.Ra, 16, 1e-9, "Ra"); close(r.Rl, 27.84, 1e-9, "Rl"); close(r.Rb, 18, 1e-9, "Rb");
close(r.R, 82.6, .3, "R Dlubal (82 à 83 min)");
// Concrete Centre : 300×600, 8 barres... valeurs partielles Ra=27,2 (a=47), Rl=28,8 (l0,fi=2), b'=360, Rb=32,4, Rn=12
r = F.poteauFeu({ mufi: .57, omega: 0, a: 47, l0fi: 2, b: 300, h: 450, n: 6, acc: .85 });
close(r.Ra, 27.2, 1e-9, "Ra CC"); close(r.Rl, 28.8, 1e-9, "Rl CC"); close(r.bp, 360, 1e-9, "b' CC"); close(r.Rb, 32.4, 1e-9, "Rb CC"); close(r.Rn, 12, 0, "Rn n>4");
ok(F.poteauFeu({ mufi: .5, omega: .3, a: 40, l0fi: 7, b: 300, h: 300, n: 4 }).msg.length > 0, "alerte hors domaine");
// Dalle, tableau 5.8
let d = F.dalleFeu({ R: 60, h: 175, a: 25, sens: 1 }); ok(d.ok && d.hmin === 80 && d.amin === 20, "exemple 175 mm R60 : hmin 80, a 20");
d = F.dalleFeu({ R: 90, h: 100, a: 20, sens: 2, ratio: 1.4 }); ok(d.ok && d.amin === 15, "deux sens ≤1,5 R90 : a=15");
d = F.dalleFeu({ R: 120, h: 120, a: 22, sens: 2, ratio: 1.8 }); ok(!d.ok && d.amin === 25, "deux sens 1,5-2 R120 : a=25 non satisfait");
d = F.dalleFeu({ R: 60, h: 150, a: 15, sens: 2, ratio: 1.75 }); ok(d.ok && d.amin === 15, "exemple 7.4 : a=15 (ratio 1,75, R60)");
console.log(n + " contrôles, 0 écart");
