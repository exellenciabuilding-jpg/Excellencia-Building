# V139 — Charges surfaciques propres à chaque dalle (point 2)

Jusqu'ici, G (revêtement, cloisons) et Q (exploitation) étaient définies **par niveau**. On peut maintenant les fixer **dalle par dalle** : balcon, local technique, archives, escalier palier, etc.

## Modèle
- `niveau.sc["i:j"] = { G, Q }` (kN/m²). Champ absent = valeur du niveau. Une valeur saisie égale à celle du niveau n'est pas mémorisée.
- Fonctions (index.html) : `slG(v,i,j)`, `slQ(v,i,j)`, `slOv(v,i,j)` (vrai si la dalle a des charges propres), `scShift` (décalage lors de l'insertion / suppression d'un axe).
- Le poids propre de la dalle reste calculé avec l'épaisseur du niveau (non modifiable par dalle).

## Ce qui en tient compte
| Partie du calcul | Effet |
|---|---|
| Descente de charges des poteaux (`batCalc`) | chaque quart de dalle autour du poteau est pris avec ses propres G et Q |
| Charges des poutres (`batBeams`) | charge équivalente (trapèze / triangle) calculée avec G et Q de chaque dalle bordant la poutre |
| Station d'analyse (portiques) | reprend automatiquement les charges des poutres ci-dessus |
| Dimensionnement des dalles (`batDalles`) | G et Q de la dalle |
| Fondations | via l'effort au pied des poteaux |
| Note de calcul, section 4 | nouveau tableau « Dalles à charges particulières » (affiché seulement s'il y en a) |
| Plan coté (étiquette G / Q de chaque dalle) | valeurs propres de la dalle |
| Axes | insertion : la dalle scindée garde ses charges dans les deux parties ; suppression : la dalle retirée emporte ses charges |

## Interface
- **Station** (disposition Géométrie ou Charges) : cliquer une dalle → panneau Propriétés « Charges de cette dalle » (G, Q, origine, bouton « Reprendre les valeurs du niveau »). Disposition Charges : toutes les dalles affichent « G · Q », en rouge avec * quand elles diffèrent du niveau.
- **Sélection multiple** : plusieurs dalles → saisir G et/ou Q pour toutes en une fois.
- Copier / couper / coller et « copier vers un autre niveau » emportent les charges propres. Annuler / rétablir inclus.
- **Écran Bâtiment** (hors station) : mêmes champs G / Q dans le panneau d'une dalle.

## Validation
`node validation/valider-robot.js` : section R30 (23 contrôles), 206 au total, 0 écart ; `valider-notes.js` 218 et `valider.js` 111 inchangés.
Références recalculées à la main : ΔNu = (γG·ΔG + γQ·ΔQ)·A/4 (× 1,15 pour les poteaux intermédiaires, majoration de continuité du modèle), ΔG linéique d'une poutre = ΔG·c (c = charge équivalente de la dalle), absence d'effet sur les éléments éloignés, valeurs identiques au niveau = résultat inchangé, priorité de la valeur propre quand le niveau change, note sans NaN, décalage des axes.
Interface vérifiée dans Chromium (saisie, sélection multiple, annuler / rétablir, copier-coller, copie vers un autre niveau, remise à la valeur du niveau). Pas encore essayée sur un vrai téléphone.

## Limites
- Charges uniformes par dalle : pas de charge de dalle partielle, linéaire ou ponctuelle sur la dalle.
- Épaisseur toujours par niveau.
- Constat laissé tel quel : `batDalles` calcule l'épaisseur avec `b.hs` (valeur commune) alors que la descente de charges et les poutres utilisent l'épaisseur du niveau (`lvHs`). Aucun écart tant qu'un niveau n'a pas d'épaisseur propre. À aligner dans une prochaine version.
