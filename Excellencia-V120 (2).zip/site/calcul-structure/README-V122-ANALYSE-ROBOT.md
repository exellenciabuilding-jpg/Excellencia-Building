# V122 — Analyse de structure « type Robot » (moteur `exb-robot-analyse.js`)

Nouveau moteur sans DOM (`window.EXBR`, testable sous Node) qui renforce les modules de calcul avec les fonctions de Robot Structural Analysis.

## Fonctionnalités
1. **Combinaisons automatiques** (EN 1990 6.10, 6.10a/b, ELS caractéristique / fréquente / quasi-permanente, accidentelle, sismique ±Ex ± 0,3·Ey ; BAEL 91 : 1,35G + 1,5Q + 1,3ψ0·Qi), coefficients ψ par catégorie, groupes exclusifs (vent +X / −X).
2. **Analyse statique EF de portiques plans** : barres inclinées, articulations, appuis rigides / élastiques / tassements, charges nodales, réparties (trapèze, local/global, projetées), ponctuelles, température ; réactions, détection de mécanisme.
3. **Diagrammes N, V, M, flèches** par barre et **enveloppes** de toutes les combinaisons avec combinaison dominante.
4. **Analyse modale** (condensation statique, Jacobi), masses modales effectives, **spectre EN 1998-1 3.2.2.5**, combinaison SRSS/CQC, effort tranchant à la base, dérive d'étage (dr·ν), sensibilité θ, comparaison avec la méthode des forces latérales.

## Écrans ajoutés (menu Calculs et « Ingénierie & Structure »)
- **Portique 2D — analyse EF** : n étages × m travées, enveloppes ELU/ELS, vent, séisme modal, diagrammes SVG, envoi des géométries et efforts G/Q vers les modules **Poutre** et **Poteau**.
- **Combinaisons d'actions** : liste des combinaisons et valeur dominante pour un effet donné.

## Validation
`node site/calcul-structure/validation/valider-robot.js` : 87 contrôles contre solutions analytiques (RDM, pentes-déflexions, valeurs propres exactes, EN 1990/1998-1) et contre le moteur de poutre continue existant. `npm run test:calcul` les exécute avec les anciens (111 contrôles inchangés).

## Branchement sur les modules existants
- **Portique 2D** : dimensionnement automatique **par niveau** à partir des enveloppes ELU, ELS caractéristique et séisme (G + ψ2·Q ± E) : armatures de travée, d'appui, cadres des poutres (moteur du module Poutre) et armatures des poteaux. Quand le module Poteau ne sait pas traiter la flexion composée (traction partielle), le poteau est dimensionné par un **diagramme d'interaction N–M** (aciers symétriques, bloc 0,8x, excentricité minimale).
- **Module Poutre** : carte « Contrôle par éléments finis » sous les résultats : mêmes chargements alternés et charges spéciales, concordance affichée (écart ≤ 1 % constaté), plus **tassements d'appui** et **appuis élastiques** (ce que le calcul par rotations ne permet pas).

## Station d'analyse du bâtiment (V123)
Module **Bâtiment → « Ouvrir la station d'analyse (type Robot) »** (`exb-robot-station.js`) : espace de travail en panneaux.
- **Dispositions** (comme les « layouts » de Robot) : Géométrie · Charges · Analyse · Résultats · Dimensionnement.
- **Arbre d'objets** (niveaux, 6 portiques X/Y, cas de charges, combinaisons), **vue** plan du niveau / portique avec diagrammes M, V, N, flèches (cliquer une poutre du plan choisit le portique ; cliquer une barre affiche ses efforts, son enveloppe et ses armatures), **propriétés** modifiables (hauteurs, travées, sections, charges G/Q, vent, séisme), **tableaux** (efforts, réactions, combinaisons, modes et dérives, tous les portiques, armatures) avec export CSV, barre d'état. Sur mobile, les panneaux passent en onglets.
- Chaque portique du bâtiment est extrait du modèle (poteaux dimensionnés par la descente de charges, charges des poutres) et analysé par le moteur EXBR ; équivalence vérifiée avec le portique régulier (R16).
- Limites : analyse plane par axe (pas de 3D couplée ni de torsion) ; séisme global (T, Vb, dérives, θ) sans combinaisons sismiques dans le dimensionnement des armatures ; ces cas sont dans l'écran Portique 2D.

## Limites
Linéaire élastique (pas de P-Δ ni fissuration : rigidité brute), Euler-Bernoulli, diaphragme rigide, masses concentrées, pas de torsion ni d'excentricité accidentelle, poteaux N–M sans second ordre (alerte si λ > 25) et en flexion uniaxiale, tassements pris à γ = 1,0. Non comparé à Robot : à compléter dans `COMPARAISON-ROBOT.md`.

## V124 — Palettes fonctionnelles et configuration des axes (Station d'analyse)

Les palettes de la station agissent maintenant sur le modèle du bâtiment (plus de simples maquettes) :

- **Géométrie** : Sélection, Poteau (créer/supprimer, option « tous niveaux »), Poutre (retirer/rétablir un tronçon), Dalle (créer/retirer une case), Axe X/Y (insérer à l'endroit cliqué), Suppr. X/Y (fusionne les deux travées), Axes… (table), Copier niveau, + / − niveau.
- **Charges** : Charge linéaire G/Q ajoutée sur une poutre (prise en compte dans l'analyse des portiques), Effacer.
- **Analyse / Résultats / Dimensionnement** : Analyser, Tous, choix du diagramme (M, V, N, flèches), Recalculer.
- Toutes dispositions : **Annuler / Rétablir** (60 niveaux), zoom + / − / ajuster.
- **Table des axes** (« Axes… ») : position de chaque axe, longueur de travée, insertion, suppression, ajout de travée ; poteaux, poutres, dalles et sections suivent sur tous les niveaux, descente de charges recalculée.
- Panneau Propriétés contextuel : section imposée d'un poteau, section d'une ligne de poutres, charge linéaire, épaisseur de dalle, longueur de travée, position d'axe.

Limite : les charges linéaires ajoutées sont repérées par tronçon ; elles sont effacées quand la grille change (insertion/suppression d'axe).

## V125 — Fondations du bâtiment
`batFond` dimensionne automatiquement toutes les semelles isolées du bâtiment à partir des charges au pied (moteur `semelleCalc` : contrainte au sol ELS, flexion par bielles, rigidité, poinçonnement, effort tranchant). Résultats : carte « Fondations » dans Dimensionnement bâtiment, onglet « Fondations » de la station (disposition Dimensionnement), alertes de chevauchement de semelles (semelle filante / radier à prévoir) et métré béton. Contrainte du sol : champ `b.sig`. Validation R17 (8 contrôles). Limites : semelles carrées centrées, sans moment en pied ni liaison par longrines.

## V126 — Module Poteau renforcé (flexion composée déviée N–M)
Avant : au-delà de la compression centrée, le module Poteau s'arrêtait avec « diagramme d'interaction N-M nécessaire (non couvert ici) » (BAEL : traction partielle ; EC2 : excentricité > 60 %).
Maintenant (sections rectangulaires, BAEL et EC2) :
- dimensionnement par diagramme d'interaction N–M avec aciers répartis sur le pourtour (`EXBR.poteauNM`, `courbeNMc`, `nappes`), flexion déviée (EN 1992-1-1 5.8.9, exposant a), second ordre par courbure nominale (5.8.8) ou formule BAEL A.4.3.5, excentricité minimale ;
- contrôle renforcé du résultat de la méthode forfaitaire, avec alerte et acier nécessaire si le taux N–M dépasse 100 % ;
- carte « Contrôle N–M renforcé » : λ, e0, ei, e2, MEd/MRd par sens, exposant a, taux, diagrammes d'interaction ;
- la note de calcul et le plan d'exécution suivent l'acier retenu.
Validation R18 (12 contrôles). Limites : sections circulaires inchangées ; fluage négligé ; barres supposées réparties en nombre égal sur les quatre faces.

## V127 — Suite : poteau bois en flexion composée, poteaux de la station
- Poteau bois (EC5) : champs My / Mz ; vérification de flexion composée EN 1995-1-1 6.3.2 (éq. 6.23 et 6.24, km = 0,7, kh, flambement kc par axe). Compression centrée inchangée. Validation R19.
- Station d'analyse : le dimensionnement des poteaux passe par le module Poteau renforcé (N–M, flexion déviée, second ordre) dès que les moments sont forts.
Restent hors périmètre : sections de classe 4 (acier), compression perpendiculaire aux fibres et feu (bois), sections circulaires en flexion composée forte.

## V128 — Limites levées
- Acier (EC3) : sections de classe 4 traitées par largeurs efficaces EN 1993-1-5 — poteau (aire efficace Aeff, flambement sur Aeff) et poutre (Weff,min, semelle ρ outstand, âme ψ = −1, une itération). Validation R20.
- Poteau béton circulaire : flexion composée forte par diagramme N–M à n barres régulièrement réparties, moment résultant, second ordre, taux N–M ; carte de contrôle et note de calcul. Validation R21.
- Poteau bois (EC5) : compression perpendiculaire aux fibres au pied sur lisse (6.1.5, kc,90, +30 mm) et résistance au feu R15 à R90 par section réduite (EN 1995-1-2 : βn, d0, k0, kfi = 1,25, ηfi = 0,6). Validation R22.
Limites restantes : voilement par cisaillement de l'âme (classe 4 poutre), assemblages et pieds de poteau au feu, feu des éléments en béton/acier.

## V129 — Limites levées (suite) et vue 3D éditable
- **Vue 3D éditable** dans la Station d'analyse (`exb-robot-3d.js`, onglet « Vue 3D », sans dépendance) : rotation (glisser), déplacement (Maj+glisser, deux doigts), zoom (molette, pincement), vues Iso / Dessus / Face / Côté, isolement du niveau courant, poteaux, poutres, dalles et semelles cliquables. Toutes les palettes agissent aussi en 3D sur le niveau de l'élément cliqué (poteau, poutre, dalle, charge linéaire), avec les repères fantômes des poteaux manquants, sélection et propriétés, annuler/rétablir.
- **Poutre acier** : voilement de l'âme par cisaillement (EN 1993-1-5 §5), interaction M–V complète (§6.2.8), écrasement / voilement de l'âme à l'appui (§6, type c, longueur d'appui saisie).
- **Poteau acier** : platine d'assise (EN 1993-1-8 §6.2.5) vérifiée ou dimensionnée automatiquement.
- **Nouveaux modules** : *Assemblage boulonné acier* (cisaillement, pression diamétrale, section nette, arrachement de bloc, pinces et entraxes, assemblage long) ; *Assemblage boulonné bois* (modes de Johansen, nombre efficace, section nette, espacements).
- Validations R23 à R25.

### Limites restantes (assumées)
- Résistance au feu des poteaux/poutres en béton armé et en acier : les méthodes normatives reposent sur des tables et des courbes de température (EN 1992-1-2, EN 1993-1-2) qui ne sont pas reproduites ici sans pouvoir les vérifier ; non traitée plutôt qu'approximée.
- Assemblages bois : cisaillement simple bois-bois, effort parallèle au fil ; rupture en bloc (annexe A) et fendage non vérifiés ; feu des assemblages non traité.
- Assemblages acier : catégorie A, effort centré ; soudures, effet de levier et assemblages poutre-poteau rigides non traités.

## V130 — Soudures et acier au feu
- Module *Soudure d'angle* (EC3-1-8 §4.5.3) : méthodes simplifiée et directionnelle, cordon long, gorge et longueur minimales.
- Module *Acier au feu* (EC3-1-2 §4.2.4-4.2.5) : température critique, échauffement pas à pas sous courbe ISO 834, profilé nu ou protégé, épaisseur de protection nécessaire. Validation R26.
Restent hors périmètre : feu du béton (EN 1992-1-2, tables et isothermes), assemblages acier rigides / effet de levier, rupture en bloc et fendage du bois.

## V131 — Té équivalent (platine d'about) et fendage du bois
- Module *Platine d'about / té équivalent* (EC3-1-8 §6.2.4) : une rangée de boulons, longueurs efficaces circulaire/non circulaire, Mpl,Rd, modes 1/2/3 avec effet de levier, critère Lb*, mode 1-2 sans effet de levier, poinçonnement Bp,Rd.
- Module *Fendage du bois* (EC5 §8.1.4) : F90,Rk = 14·b·√(he/(1 − he/h)), F90,Rd = kmod·F90,Rk/γM (γM = 1,3). Validation R27.

### Limites restantes (état V131)
- **Béton au feu (EN 1992-1-2)** : non traité. La méthode tabulaire n'a pu être relue dans une source fiable (tableau 5.2a obtenu désaxé) ; je ne reproduis pas un tableau normatif de mémoire.
- **Rupture en bloc du bois (EC5 annexe A)** : non traitée, formule non confirmée par une source consultée.
- **Assemblage rigide complet** : une seule rangée de boulons ; pas d'effet de groupe, d'âme de poteau, de panneau de cisaillement, ni de rigidité Sj,ini.
- Assemblages bois : effort parallèle au fil dans le module boulonné ; feu des assemblages non traité.

## V132 — Station bâtiment : sélection multiple et raccourcis (à la Robot)
- Sélection multiple dans le plan : Maj/Ctrl+clic ou bouton *Multi* ; *Tout sél.* / Ctrl+A (poteaux, poutres, dalles du niveau).
- Actions groupées (panneau Propriétés) : supprimer, rétablir, imposer une section à tous les poteaux, copier la sélection vers un autre niveau. Toutes annulables.
- Raccourcis : Ctrl+Z / Ctrl+Y, Suppr, Échap, PgUp/PgDn (niveau), S/C/P/D (outils sélection, poteau, poutre, dalle), + − 0 (zoom).
- Vérifié par scénarios navigateur (sélection, section, suppression, annulation, copie inter-niveaux, raccourcis) sans erreur JavaScript.

## V133 — Clic droit (plan et 3D), presse-papiers et raccourcis configurables
- **Menu contextuel** (clic droit, ou Maj+F10) dans le plan et la vue 3D : propriétés, copier, couper, coller ici, supprimer, rétablir, copier vers un autre niveau, tout sélectionner, inverser, outils, annuler/rétablir, isoler le niveau, plan ↔ 3D, ajuster, niveaux, raccourcis. Le clic droit sur un élément le sélectionne (la sélection multiple existante est conservée).
- **Presse-papiers** (Ctrl+C / Ctrl+X / Ctrl+V, boutons Copier / Coller de la palette) : poteaux (avec section imposée), poutres (retirées/présentes) et dalles. Le collage se fait au nœud sous le curseur (décalage de trame), ou à la même position sur un autre niveau ; les éléments hors trame sont ignorés et comptés.
- **Raccourcis clavier configurables** (menu → *Raccourcis clavier…* ou bouton ⌨) : 22 commandes, capture de la combinaison, refus des doublons, réinitialisation, enregistrement sur l'appareil.
- En 3D : sélection multiple (Maj+clic) et surbrillance de tous les éléments sélectionnés ; le clic droit ne fait plus pivoter la vue.
- Contrôle de tous les modules de calcul avec leurs valeurs par défaut : 34 modules exécutés sans exception ni valeur non numérique.

## V134 — Poutre : portique intégré et diagrammes d'enveloppe professionnels
- **Module Poutre, modèle « Portique (poutre + poteaux) »** : la poutre est solidaire de poteaux (hauteur sous et au-dessus, section, pied et tête encastrés ou articulés, déplacement latéral empêché ou libre). Analyse plane aux éléments finis, toutes les dispositions de Q (1,35·G + 1,5·Q), mêmes sections de calcul que la poutre continue : le dimensionnement (ELU, tranchant, ELS, flèche, fissuration, note de calcul) repose sur le portique. Les appuis de rive, comprimés par l'encastrement, sont dimensionnés comme des appuis.
- Tableau des poteaux (Nu, Mu, M tête/pied, Vu) et bouton « Dimensionner » qui envoie G, Q et les moments au module Poteau ; comparaison poutre continue / portique.
- **Diagrammes** : enveloppes M et V avec appuis numérotés, portées cotées, hachures, signes (+/−) dans les lobes, valeurs aux extrema et aux appuis, graduation, travée la plus sollicitée repérée, légende et convention de signes. Diagramme du portique : valeurs et signes aux extrema de chaque barre, cadrage sans rognage. Repris dans la note de calcul.
- Validation R28 : moment de nœud d'un portique (formule de la rotation), équilibre vertical, trois moments, régression de la poutre continue, présence des signes et valeurs sur les figures.
- Limites : poids propre des poteaux non inclus dans N ; couple N–M envoyé au module Poteau conservateur (N et M maximaux simultanés) ; une seule file de poteaux (portique plan), sans effort horizontal de vent ni de séisme dans ce module.

## V135 — Note de calcul de la poutre : modèle, cas de charges, enveloppes
Plan inspiré des notes de calcul de type Robot / ARCHE (consultées en ligne : note Robot d'eduscol, note de bureau d'études Enabel). Les pages Scribd n'ont pas pu être consultées (non accessibles depuis l'outil de recherche).
- Nouvelle section « Modèle de calcul et cas de charges » : schéma de la structure avec nœuds et barres numérotés (poutre continue ou portique), tableaux des nœuds (coordonnées, liaisons) et des barres (nœuds, longueur, section), cas élémentaires G, Q et dispositions de Q dessinés, tableau des combinaisons ELU/ELS.
- Nouvelle section « Sollicitations (ELU et ELS) » : tableau aux appuis (Mu, Ms, Vu gauche/droite, réactions Ru/Rs) et en travée (Mu,t max, position x, Ms,t max, Vu max), avec légende de signes.
- Diagrammes : enveloppes M et V (ELU), enveloppe M à l'ELS ; en portique : diagrammes M, V, N du portique et tableau des poteaux.
- La note passe à 7 pages (renumérotation des sections).

## V136 — Portique de la poutre : vent / séisme horizontal
- Champ « Force horizontale (vent / séisme) au niveau de la poutre » (kN) du modèle Portique, active si le déplacement latéral est libre : cas W+ et W− (nœud de tête de la poutre), combinaisons 1,35G + 1,5Q + 1,5·0,6·W, 1,35G + 1,5·0,7·Q + 1,5W et 1,35G + 1,5W, dans les deux sens, pour les moments, tranchants, réactions, ELS et poteaux.
- Le poteau envoyé au module Poteau reçoit en plus un cas « Vent / séisme W » (sens défavorable).
- Validation R29 : poutre rigide, pieds encastrés → M = W·H/4 ; symétrie W+/W− ; effet nul quand le déplacement est empêché.
- Limites : ψ0 fixés (0,6 pour W, 0,7 pour Q) ; une seule force au niveau de la poutre ; pas de combinaison sismique accidentelle spécifique (ψ2) ni de torsion d'ensemble.

## V137 — Notes de calcul Poteau, Dalle, Plancher et Semelle : modèle, cas de charges, enveloppes
Même plan que la note de la poutre (V135), étendu aux quatre autres notes.
- **Poteau** (6 pages) : schéma (nœuds N1/N2, barre B1, liaisons selon k, charges en tête, poids propre), tableaux nœuds/barre, cas élémentaires, dessins des cas G et Q, combinaisons ELU/ELS, diagrammes de N et des moments de 1er ordre, efforts en tête et au pied, moments majorés (EC2).
- **Dalle pleine** (5 pages) : plan avec appuis et bandes de 1 m, cas G/Q, combinaisons, M0/Mt/Ma par sens, diagrammes de moments (tranchant tracé dans les deux cas : Vu = pu·lx/2 pour un sens ; Vu,x = pu·lx·ly/(2·ly+lx) et Vu,y = pu·lx/3 pour deux sens).
- **Plancher multi-travées** (5 pages) : nœuds, barres, dispositions de Q, enveloppes M et V, tableaux appuis/travées.
- **Semelle isolée** (6 pages) : coupe et plan, cas G/Q/poids propre/terres, combinaisons, réaction du sol ELS et ELU (décollement par surface efficace, comme le module).
- Validation : `node site/calcul-structure/validation/valider-notes.js` (196 contrôles), inclus dans `npm run test:calcul`.
- Limites : poteau dimensionné sur la seule combinaison ELU fondamentale (N minimal non examiné) ; allures des diagrammes de dalle schématiques ; non testé sur téléphone ni dans l'export PDF réel (pages denses coupées entre deux lignes de tableau).

## V137 — Notes d'escalier : modèle et diagrammes
- Volée droite, balancé et escalier à palier : la note reçoit le schéma de la paillasse (appuis, charge ELU/ELS, H, L), les combinaisons et les diagrammes de moment et d'effort tranchant de la bande de 1 m (Mt, Ma, Vu retenus). Sections renumérotées (note à 5 pages).
- Les notes Poteau, Dalle, Plancher et Semelle de cette version avaient déjà leurs modèles et enveloppes : elles sont conservées telles quelles.
- Validation R31 (présence des schémas, absence de NaN, M0 = pu·L²/8).

## V137 (suite) — Station Robot autonome
- Nouveau module « 🛰️ Station d'analyse (Robot) » dans le menu Ingénierie & Structure (liste des bâtiments, création, ouverture directe de la station). Le bouton d'ouverture a été retiré du module Bâtiment.
- Plein écran : bouton « ⛶ Plein écran » dans la barre de la station (plein écran navigateur, repli sur toute la fenêtre du logiciel) ; la visionneuse « 3D plein écran » s'ouvrait derrière la station (z-index) : corrigé.
- Navigation : changer de module ferme la station ; changer d'onglet du logiciel quitte le plein écran. Validation R32.

## V137 (suite 2) — Vue 3D qui restait ouverte, saisie interrompue
- La vue 3D plein écran et la station se ferment dès que l'on change de module ou d'écran du logiciel (auparavant la vue 3D restait par-dessus tous les modules).
- Accueil : la météo (champ de recherche de lieu) et le tableau « À faire » ne se reconstruisent plus pendant qu'on tape dedans (rafraîchissement automatique toutes les minutes). Validation R33.
- Blocage périodique signalé (≈ 10 min) : cause non reproduite ici. Pour la cerner : Ctrl + Alt + L affiche les tâches automatiques qui ont bloqué l'écran (diagnostic V121c).
- Saisie qui se bloque par moments : cause non reproduite (test de 7 min de frappe continue sur la recherche + 45 écrans surveillés, sans perte de focus ni blocage). Mesure préventive : pendant qu'on tape dans un champ, les tâches automatiques répétées (≥ 1 s) sont reportées (exb-diag-lenteur.js). Si le blocage persiste : Ctrl + Alt + L affiche les tâches responsables.
- Fenêtre « Devis automatique » : elle restait ouverte par-dessus tous les écrans quand on changeait de module (et faisait échouer tools/e2e-smoke.py). Elle se ferme maintenant au changement d'écran. Validation R34.
