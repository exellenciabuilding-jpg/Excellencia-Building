/* V139 — Béton au feu (EN 1992-1-2) : poteau (méthode A, §5.3.2, éq. 5.7) et dalle pleine (tableau 5.8).
   Fonctions pures, sans DOM : navigateur (window.EXBF) et Node. Unités : mm, m, minutes.
   Sources recoupées : formule 5.7 (BFT, Concrete Centre, exemple Dlubal VE1026) ; tableau 5.8 (texte de la norme, adoption DSTU).
   NON vérifié sur le texte officiel : domaine de validité complet de la méthode A (excentricité, h/b, nombre de barres).
   Calcul d'aide à l'étude : à faire vérifier par un ingénieur. */
(function (root) {
  "use strict";

  /* ---------- poteau : méthode A, éq. 5.7 ----------
     p : { mufi, omega, a, l0fi, b, h, n, acc }
       mufi  = NEd,fi / NRd (≤ 0,7 sécuritaire)   omega = As·fyd / (Ac·fcd)
       a     = distance d'axe des armatures (mm)   l0fi = longueur efficace au feu (m, 2 à 6)
       b, h  = dimensions (mm) → b' = 2·b·h/(b+h) (= 4Ac/u)   n = nombre de barres   acc = αcc (défaut 1,0) */
  function poteauFeu(p) {
    const acc = p.acc || 1, bp = 2 * p.b * p.h / (p.b + p.h), msg = [];
    const Rn_ = 83 * (1 - p.mufi * (1 + p.omega) / (0.85 / acc + p.omega));
    const Ra = 1.6 * (p.a - 30), Rl = 9.6 * (5 - p.l0fi), Rb = 0.09 * bp, Rn = p.n > 4 ? 12 : 0;
    const R = 120 * Math.pow(Math.max(Rn_ + Ra + Rl + Rb + Rn, 0) / 120, 1.8);
    if (p.l0fi < 2 || p.l0fi > 6) msg.push("l0,fi hors du domaine 2 m ≤ l0,fi ≤ 6 m de la méthode A.");
    if (bp < 200 || bp > 450) msg.push("b' = " + bp.toFixed(0) + " mm hors du domaine 200 à 450 mm de la méthode A.");
    return { R, Rn_, Ra, Rl, Rb, Rn, bp, msg };
  }

  /* ---------- dalle pleine : tableau 5.8 (appuyée sur 4 côtés pour les colonnes deux sens) ----------
     Colonnes : [R, h_min, a un sens, a deux sens ly/lx ≤ 1,5, a deux sens 1,5 < ly/lx ≤ 2]. Valeurs avec * : l'enrobage EN 1992-1-1 gouverne en général. */
  const T58 = [[30, 60, 10, 10, 10], [60, 80, 20, 10, 15], [90, 100, 30, 15, 20], [120, 120, 40, 20, 25], [180, 150, 55, 30, 40], [240, 175, 65, 40, 50]];
  /* s : { R, h (mm), a (mm, axe des aciers inférieurs), sens: 1|2, ratio: ly/lx, quatreCotes: bool }
     Dalle continue : valeurs d'une dalle simplement appuyée (colonne ambiguë dans les sources, côté sécurité). */
  function dalleFeu(s) {
    const row = T58.find(r => r[0] >= s.R), msg = [];
    if (!row) return { ok: false, msg: ["Résistance au feu exigée > R240 : hors tableau 5.8."] };
    let col = 2, deux = s.sens === 2 && s.quatreCotes !== false && s.ratio <= 2;
    if (s.sens === 2 && s.quatreCotes === false) msg.push("Dalle deux sens non appuyée sur 4 côtés : traitée comme un sens.");
    if (deux) col = s.ratio <= 1.5 ? 3 : 4;
    const hmin = row[1], amin = row[col];
    const ok = s.h >= hmin && s.a >= amin;
    if (s.h < hmin) msg.push("Épaisseur " + s.h + " mm < " + hmin + " mm exigés pour R" + row[0] + ".");
    if (s.a < amin) msg.push("Distance d'axe " + s.a + " mm < " + amin + " mm exigés pour R" + row[0] + ".");
    return { ok, R: row[0], hmin, amin, msg };
  }

  const api = { poteauFeu, dalleFeu, T58 };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.EXBF = api;
})(typeof window !== "undefined" ? window : globalThis);
