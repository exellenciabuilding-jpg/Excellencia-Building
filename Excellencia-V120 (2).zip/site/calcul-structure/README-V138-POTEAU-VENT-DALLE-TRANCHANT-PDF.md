# V138 — Poteau (effort normal minimal), dalle deux sens (tranchant), export PDF

## Poteau : combinaison 1,0·G + 1,5·W
- Nouveau type de charge **W (vent / action horizontale)** dans la descente de charges (N, Mx, My).
- Sans ligne W : aucun changement. Avec une ligne W : la combinaison à effort normal minimal est vérifiée.
- Hypothèses : G favorable (γG = 1,0, poids propre compris) ; vent réversible, pris dans le sens le plus défavorable : N = G − 1,5·|NW| ; M = |MG| + 1,5·|MW| ; pas de charge Q dans cette combinaison.
- N > 0 : diagramme d'interaction N–M (second ordre et excentricité minimale inclus).
- N ≤ 0 (traction) : contrôle simplifié et sécuritaire, As·fed ≥ |N| + M/(0,9·d) dans chaque sens.
- Si cette combinaison gouverne, les armatures sont augmentées. Résultat dans les messages, le tableau des combinaisons (ligne 3) et la note de calcul.
- Non inclus : 1,35·G + 1,5·W et les coefficients de simultanéité avec Q.

## Dalle deux sens : tranchant
- Sens X : Vu,x = pu·lx·ly/(2·ly + lx) ; sens Y : Vu,y = pu·lx/3 (kN/m). Les deux diagrammes sont tracés dans la note ; la vérification retient le maximum.

## Export PDF
- `exb-pdf-direct.js` : une feuille qui dépasse de 12 % au plus est ramenée sur une seule page (fini les pages quasi vides sur dalle et semelle). Au-delà, coupure entre deux lignes de tableau comme avant.

## Validation
- `node validation/valider-notes.js` : section S5 (22 contrôles), 218 contrôles au total, 0 écart.
- Rendu et export PDF vérifiés dans Chromium en écran de 390 px. Pas encore essayé sur un vrai téléphone.
