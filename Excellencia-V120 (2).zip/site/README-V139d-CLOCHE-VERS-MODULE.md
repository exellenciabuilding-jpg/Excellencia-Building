# V139d — La cloche 🔔 mène au module où se trouvent les nouveautés + fin du message « client » fantôme

## 1. Cloche
- **Une seule nouveauté** : un clic sur la cloche vous amène directement au bon endroit.
  - nouveau message → Messagerie, sur la bonne catégorie ; si une seule conversation est non lue, elle s'ouvre
  - demande d'inscription → Participants · TP/TD ou copie → TP / TD · formateur → Formateurs · client → Clients · personnel → RH · projet → Projets · logiciel → Licences & clients
  - déclaration d'avancement → Portails & signatures › Retours
- **Plusieurs nouveautés** : la fenêtre s'ouvre avec « À traiter » en tête ; chaque ligne mène à son module.
- Les lignes de l'historique commençant par 🔔 sont cliquables ; la page « Notifications » affiche aussi un bloc « À traiter maintenant ».
- La pastille compte les vraies nouveautés encore à traiter.

## 2. Message « il y a un message pour le client » alors qu'il n'y a rien
Cause : le compteur « messages de clients du portail » ne se remettait à zéro que si l'on ouvrait Portails › Retours. Un message lu dans la Messagerie ✉️ restait donc compté, et le rappel sonore/vocal (toutes les 10 min par défaut) le répétait.
Correction : un message lu dans la Messagerie remet l'alerte à zéro ; ouvrir Portails › Retours marque aussi les messages clients comme lus dans la Messagerie ; plus de rappel hors connexion.
Note : les demandes réelles non importées (inscription, client…) et les déclarations « à vérifier » restent comptées tant qu'elles ne sont pas traitées.

## Fichiers
Nouveau : `exb-notif-goto.js`. Modifiés : `exb-notify-pro.js`, `exb-messagerie.js`, `exb-v99zy-portails.js`, `exb-memoire.js`, `exb-v99r-shell.js`, `index.html`, `sw.js`. Aucun SQL.
Testé : Chromium (un seul message, une seule demande, plusieurs sources, remise à zéro de l'alerte). Non testé : APK, installateur Windows, vrai serveur Supabase.
