/* Excellencia Building — V128d ASSISTANT LOCAL ÉLARGI (sans clé, sans internet, lecture seule).
 *   « planning de demain », « quelles formations cette semaine ? »       → séances du planning
 *   « solde de la caisse », « dépenses de ce mois »                       → recettes, dépenses, solde
 *   « stock bas », « stock de ciment »                                    → ruptures et quantités
 *   « liste des projets », « budget du projet Villa », « projets en cours » → projets, budget, avancement
 *   « combien de devis ? », « devis de Marie »                            → devis (total par monnaie)
 *   « qui est absent aujourd'hui ? »                                      → présences enregistrées
 *   « combien de certificats ? », « certificats de Jean »                 → certificats
 *   « qui forme AutoCAD ? »                                               → formateurs par spécialité
 *   « matricule de Jean Kasongo »                                         → matricule (apprenant, formateur, personnel)
 *   « bilan général »                                                     → chiffres clés en une réponse
 *   « TVA 16% sur 1500 », « 20% de 350 », « convertis 5 m en cm », « date dans 45 jours »
 * Rien n'est modifié : aucune autorisation requise. Appelé depuis localAI() de index.html :
 *   var r = EXB_ASSIST_PLUS2.run(texteBrut, texteNormalisé) → {answer, actions} ou null. */
(function (w) {
  'use strict';
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9+#.,%\-²³ ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function jlist(key) {
    var a = null, v;
    try { if (w.EXBS && w.EXBS.get) a = w.EXBS.get(key); } catch (e) {}
    if (!a || !a.length) { try { var st = (typeof exbStorage !== 'undefined') ? exbStorage : null; if (st) { v = JSON.parse(st.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } } catch (e) {} }
    if (!a || !a.length) { try { v = JSON.parse(w.localStorage.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } catch (e) {} }
    return (a || []).filter(function (x) { return x && typeof x === 'object'; });
  }
  function money(n) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 2 }); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function addDays(d, n) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); return x; }
  function dFr(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] : String(s || ''); }
  function num(s) { var t = String(s).replace(/\s/g, '').replace(',', '.'); var n = parseFloat(t); return isFinite(n) ? n : NaN; }
  function title(x) { return String(x).replace(/(^|[\s\-])([a-zà-ÿ])/g, function (m, a, b) { return a + b.toUpperCase(); }); }
  var G = { go: function (t) { return { type: 'goto', tab: t }; } };
  var STOP = /\b(le|la|les|l|de|du|des|d|un|une|au|aux|a|et|pour|sur|dans|en|ce|cette|mes|mon|ma|ses|son|sa|qui|quel|quels|quelle|quelles|est|sont|y|il|ya|combien|liste|lister|montre|affiche|donne|moi|svp|stp|total|tous|toutes|tout|par|avec|chez|cherche|trouve|projet|projets|chantier|chantiers|devis|stock|materiau|materiaux|budget|avancement|matricule|certificat|certificats|formateur|formateurs|forme|enseigne|donne|aujourd|hui|demain|semaine|mois|prochain|prochains|prochaine|planning|formation|formations|caisse|solde|statut|etat|numero|quantite|reste|restant|encore)\b/g;
  function rest(q) { return q.replace(STOP, ' ').replace(/[?!.,;:]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function nameOf(p) { return String(p.name || p.full_name || [p.first_name, p.last_name].filter(Boolean).join(' ') || '').trim(); }
  function has(hay, needle) { return norm(hay).indexOf(needle) >= 0; }
  function allTokens(hay, tokens) { var h = norm(hay); return tokens.every(function (t) { return h.indexOf(t) >= 0; }); }

  /* ---------- planning ---------- */
  function period(q) {
    var t = new Date(), a, b, lab;
    if (/\bdemain\b/.test(q)) { a = b = addDays(t, 1); lab = 'demain (' + dFr(iso(a)) + ')'; }
    else if (/\bapres.?demain\b/.test(q)) { a = b = addDays(t, 2); lab = 'après-demain (' + dFr(iso(a)) + ')'; }
    else if (/\bhier\b/.test(q)) { a = b = addDays(t, -1); lab = 'hier (' + dFr(iso(a)) + ')'; }
    else if (/\b(aujourd|ce jour)\b/.test(q)) { a = b = t; lab = 'aujourd’hui (' + dFr(iso(a)) + ')'; }
    else if (/\bsemaine prochaine\b/.test(q)) { var dow1 = (t.getDay() + 6) % 7; a = addDays(t, 7 - dow1); b = addDays(a, 6); lab = 'la semaine prochaine'; }
    else if (/\b(cette semaine|de la semaine|semaine)\b/.test(q)) { var dow = (t.getDay() + 6) % 7; a = addDays(t, -dow); b = addDays(a, 6); lab = 'cette semaine'; }
    else if (/\b(ce mois|du mois|mois)\b/.test(q)) { a = new Date(t.getFullYear(), t.getMonth(), 1); b = new Date(t.getFullYear(), t.getMonth() + 1, 0); lab = 'ce mois'; }
    else return null;
    return { a: iso(a), b: iso(b), lab: lab };
  }
  function planning(q) {
    var P = period(q), S = jlist('exb_schedules'), tr = jlist('exb_trainers'), today = iso(new Date()), lab;
    var l;
    if (P) { l = S.filter(function (s) { var d = String(s.date || '').slice(0, 10); return d >= P.a && d <= P.b; }); lab = P.lab; }
    else { var lim = iso(addDays(new Date(), 7)); l = S.filter(function (s) { var d = String(s.date || '').slice(0, 10); return d >= today && d <= lim; }); lab = 'les 7 prochains jours'; }
    var f = rest(q.replace(/\b(planning|programme|seances?|cours|sessions?|quelles?|quels?|qu|a|y|il|aujourd|hui|demain|hier|apres|cette|semaine|prochaine|mois)\b/g, ' ')).replace(/\b(a venir|venir)\b/g, '').trim();
    if (f.length >= 3) { var tk = f.split(' ').filter(function (x) { return x.length >= 3; }); if (tk.length) l = l.filter(function (s) { return allTokens([s.training, s.module, s.room].join(' '), tk); }); }
    l.sort(function (x, y) { return (String(x.date) + String(x.start)).localeCompare(String(y.date) + String(y.start)); });
    if (!l.length) return { answer: 'Aucune séance au planning pour ' + lab + (f.length >= 3 ? ' (« ' + f + ' »)' : '') + '.', actions: [G.go('planning')] };
    var lines = l.slice(0, 12).map(function (s) {
      var t = tr.filter(function (x) { return x.trainer_id === s.trainer_id; })[0];
      return '• ' + dFr(s.date) + (s.start ? ' ' + s.start + (s.end ? '–' + s.end : '') : '') + ' · ' + (s.training || '?') + (s.module ? ' — ' + s.module : '') + (s.room ? ' · salle ' + s.room : '') + (t ? ' · ' + t.name : '');
    });
    return { answer: l.length + ' séance(s) pour ' + lab + ' :\n' + lines.join('\n') + (l.length > 12 ? '\n… et ' + (l.length - 12) + ' autre(s).' : ''), actions: [G.go('planning')] };
  }

  /* ---------- caisse ---------- */
  function caisse(q) {
    var C = jlist('exb_cash'), P = period(q), lab = 'depuis le début';
    if (P) { C = C.filter(function (c) { var d = String(c.date || '').slice(0, 10); return d >= P.a && d <= P.b; }); lab = P.lab; }
    if (!C.length) return { answer: 'Aucune opération de caisse enregistrée ' + (P ? 'pour ' + lab : '') + '.', actions: [G.go('comptabilite')] };
    var tin = 0, tout = 0;
    C.forEach(function (c) { var a = Number(c.amount) || 0; if (c.type === 'out') tout += a; else tin += a; });
    var only = /\b(depenses?|sorties?|charges?)\b/.test(q) && !/\b(recettes?|entrees?|solde)\b/.test(q) ? 'out' : /\b(recettes?|entrees?)\b/.test(q) && !/\b(depenses?|sorties?|solde)\b/.test(q) ? 'in' : '';
    var head = only === 'out' ? 'Dépenses (' + lab + ') : ' + money(tout) : only === 'in' ? 'Recettes (' + lab + ') : ' + money(tin)
      : 'Caisse (' + lab + ') :\n• Recettes : ' + money(tin) + '\n• Dépenses : ' + money(tout) + '\n• Solde : ' + money(tin - tout);
    var last = C.slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }).filter(function (c) { return !only || (only === 'out') === (c.type === 'out'); }).slice(0, 5)
      .map(function (c) { return '• ' + dFr(c.date) + ' · ' + (c.type === 'out' ? '−' : '+') + money(c.amount) + ' · ' + (c.label || ''); });
    return { answer: head + '\n\nDernières opérations :\n' + last.join('\n') + '\n(Les montants sont ceux saisis, sans conversion de monnaie.)', actions: [G.go('comptabilite')] };
  }

  /* ---------- stock ---------- */
  function stock(q) {
    var S = jlist('exb_stock');
    if (!S.length) return { answer: 'Le stock est vide : aucun matériau enregistré.', actions: [G.go('stock')] };
    var low = S.filter(function (s) { return Number(s.min) > 0 && Number(s.qty) <= Number(s.min); });
    var fmt = function (s) { return '• ' + s.name + ' : ' + money(s.qty) + (s.unit ? ' ' + s.unit : '') + (Number(s.min) > 0 ? ' (minimum ' + money(s.min) + ')' : '') + (s.supplier ? ' · ' + s.supplier : ''); };
    if (/\b(bas|rupture|ruptures|faible|commander|minimum|manque|epuise\w*|presque)\b/.test(q)) {
      return low.length ? { answer: low.length + ' matériau(x) au minimum ou en dessous :\n' + low.slice(0, 15).map(fmt).join('\n'), actions: [G.go('stock')] } : { answer: 'Aucun matériau sous son seuil minimum. ✅', actions: [G.go('stock')] };
    }
    var f = rest(q.replace(/\b(stock|restant|reste|quantite|combien|il|a|y|en)\b/g, ' '));
    if (f.length >= 3) {
      var tk = f.split(' ').filter(function (x) { return x.length >= 3; });
      var hit = S.filter(function (s) { return allTokens(s.name, tk); });
      if (hit.length) return { answer: hit.slice(0, 10).map(fmt).join('\n'), actions: [G.go('stock')] };
      return { answer: 'Aucun matériau « ' + f + ' » dans le stock.', actions: [G.go('stock')] };
    }
    return { answer: 'Stock : ' + S.length + ' matériau(x) enregistré(s), dont ' + low.length + ' au minimum ou en dessous.' + (low.length ? '\n' + low.slice(0, 5).map(fmt).join('\n') : ''), actions: [G.go('stock')] };
  }

  /* ---------- projets ---------- */
  function projets(q) {
    var Pj = jlist('exb_projects');
    if (!Pj.length) return { answer: 'Aucun projet enregistré.', actions: [G.go('projets')] };
    var fmt = function (p) { return '• ' + p.name + (p.client ? ' (' + p.client + ')' : '') + ' — ' + (p.status || '?') + ', avancement ' + (Number(p.progress) || 0) + ' %' + (Number(p.budget) ? ', budget ' + money(p.budget) : '') + (p.end ? ', fin prévue ' + dFr(p.end) : ''); };
    var f = rest(q.replace(/\b(en cours|termine\w*|planifie\w*|suspendu\w*|actifs?|combien|liste\w*|quels?|quelles?|sont|nos|nombre|existe\w*)\b/g, ' '));
    if (f.length >= 3) {
      var tk = f.split(' ').filter(function (x) { return x.length >= 3; });
      var hit = Pj.filter(function (p) { return allTokens([p.name, p.client, p.location].join(' '), tk); });
      if (hit.length) return { answer: hit.slice(0, 6).map(fmt).join('\n'), actions: [G.go('projets')] };
    }
    var l = Pj, lab = 'Projets';
    if (/\ben cours\b/.test(q)) { l = Pj.filter(function (p) { return has(p.status, 'cours'); }); lab = 'Projets en cours'; }
    else if (/\btermine/.test(q)) { l = Pj.filter(function (p) { return has(p.status, 'termin'); }); lab = 'Projets terminés'; }
    else if (/\bplanifie/.test(q)) { l = Pj.filter(function (p) { return has(p.status, 'planif'); }); lab = 'Projets planifiés'; }
    if (/\bcombien|nombre\b/.test(q)) return { answer: lab + ' : ' + l.length + (l === Pj ? '' : ' sur ' + Pj.length) + '.', actions: [G.go('projets')] };
    if (!l.length) return { answer: 'Aucun projet dans cette catégorie.', actions: [G.go('projets')] };
    var tb = l.reduce(function (a, p) { return a + (Number(p.budget) || 0); }, 0);
    return { answer: lab + ' (' + l.length + ') :\n' + l.slice(0, 10).map(fmt).join('\n') + (l.length > 10 ? '\n…' : '') + (tb ? '\nBudget cumulé : ' + money(tb) : ''), actions: [G.go('projets')] };
  }

  /* ---------- devis ---------- */
  function devis(q) {
    var D = jlist('exb_quotes');
    if (!D.length) return { answer: 'Aucun devis enregistré dans Métré et devis.', actions: [G.go('metreDevis')] };
    var f = rest(q.replace(/\b(montant|derniers?|recents?|combien|nombre|liste\w*)\b/g, ' '));
    var l = D;
    if (f.length >= 3) { var tk = f.split(' ').filter(function (x) { return x.length >= 3; }); l = D.filter(function (d) { return allTokens([d.client, d.project, d.no].join(' '), tk); }); if (!l.length) return { answer: 'Aucun devis trouvé pour « ' + f + ' ».', actions: [G.go('metreDevis')] }; }
    var by = {}; l.forEach(function (d) { var c = d.currency || ''; by[c] = (by[c] || 0) + (Number(d.total) || 0); });
    var tot = Object.keys(by).map(function (c) { return money(by[c]) + (c ? ' ' + c : ''); }).join(' + ');
    var last = l.slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }).slice(0, 5).map(function (d) { return '• ' + (d.no || d.id) + ' · ' + (d.client || '?') + (d.date ? ' · ' + dFr(d.date) : '') + ' · ' + money(d.total) + (d.currency ? ' ' + d.currency : ''); });
    return { answer: l.length + ' devis' + (f.length >= 3 ? ' pour « ' + f + ' »' : '') + ' — total : ' + tot + '\n' + last.join('\n'), actions: [G.go('metreDevis')] };
  }

  /* ---------- présences ---------- */
  function presences(q) {
    var A = jlist('exb_attendance'), Pp = jlist('exb_participants'), P = period(q) || { a: iso(new Date()), b: iso(new Date()), lab: 'aujourd’hui (' + dFr(iso(new Date())) + ')' };
    var l = A.filter(function (x) { var d = String(x.date || '').slice(0, 10); return d >= P.a && d <= P.b; });
    if (!l.length) return { answer: 'Aucune présence enregistrée pour ' + P.lab + '. Ouvrez « Présence » pour faire l’appel.', actions: [G.go('presence')] };
    var nm = function (id) { var p = Pp.filter(function (x) { return x.participant_id === id; })[0]; return p ? p.name : id; };
    var want = /\babsent/.test(q) ? 'ABSENT' : /\bretard/.test(q) ? 'RETARD' : /\bpresent/.test(q) ? 'PRESENT' : '';
    var cnt = { PRESENT: 0, ABSENT: 0, RETARD: 0 }; l.forEach(function (x) { if (cnt[x.status] != null) cnt[x.status]++; });
    var head = 'Présences ' + P.lab + ' : ' + cnt.PRESENT + ' présent(s), ' + cnt.ABSENT + ' absent(s), ' + cnt.RETARD + ' en retard.';
    if (want) { var names = l.filter(function (x) { return x.status === want; }).map(function (x) { return nm(x.participant_id); }); return { answer: head + (names.length ? '\n' + ({ ABSENT: 'Absents', RETARD: 'En retard', PRESENT: 'Présents' })[want] + ' : ' + names.slice(0, 25).join(', ') + (names.length > 25 ? '…' : '') : ''), actions: [G.go('presence')] }; }
    return { answer: head, actions: [G.go('presence')] };
  }

  /* ---------- certificats ---------- */
  function certificats(q) {
    var C = jlist('exb_certificates');
    if (!C.length) return { answer: 'Aucun certificat enregistré.', actions: [G.go('certs')] };
    var f = rest(q.replace(/\b(combien|nombre|delivre\w*|emis|valides?)\b/g, ' '));
    if (f.length >= 3) {
      var tk = f.split(' ').filter(function (x) { return x.length >= 3; });
      var hit = C.filter(function (c) { return allTokens([c.holder, c.training, c.cert_no].join(' '), tk); });
      return hit.length ? { answer: hit.length + ' certificat(s) pour « ' + f + ' » :\n' + hit.slice(0, 8).map(function (c) { return '• ' + (c.cert_no || '?') + ' · ' + (c.holder || '?') + ' · ' + (c.training || '?') + (c.status ? ' · ' + c.status : ''); }).join('\n'), actions: [G.go('certs')] } : { answer: 'Aucun certificat pour « ' + f + ' ».', actions: [G.go('certs')] };
    }
    var by = {}; C.forEach(function (c) { var k = c.training || '?'; by[k] = (by[k] || 0) + 1; });
    return { answer: C.length + ' certificat(s) au total.\n' + Object.keys(by).sort(function (a, b) { return by[b] - by[a]; }).slice(0, 6).map(function (k) { return '• ' + k + ' : ' + by[k]; }).join('\n'), actions: [G.go('certs')] };
  }

  /* ---------- formateurs par spécialité ---------- */
  function formateurs(q) {
    var T = jlist('exb_trainers'), f = rest(q.replace(/\b(qui|forme|enseigne|donne|cours|specialite|specialites|competent|maitrise|connait|sait|utilise)\b/g, ' '));
    if (f.length < 2) return null;
    var tk = f.split(' ').filter(function (x) { return x.length >= 2; });
    var hit = T.filter(function (t) { return allTokens([t.specialty].concat(t.specialties || []).join(' '), tk); });
    if (!hit.length) return { answer: 'Aucun formateur enregistré avec la spécialité « ' + f + ' ».', actions: [G.go('formateurs')] };
    return { answer: hit.length + ' formateur(s) pour « ' + f + ' » :\n' + hit.slice(0, 10).map(function (t) { return '• ' + t.name + (t.phone ? ' · ' + t.phone : '') + (t.approval_status && t.approval_status !== 'APPROUVE' ? ' (non approuvé)' : ''); }).join('\n'), actions: [G.go('formateurs')] };
  }

  /* ---------- matricule d'une personne ---------- */
  function matricule(q) {
    var f = rest(q.replace(/\b(quel|quelle|est|numero|de|du|donne|mon|son|sa|cherche|trouve|retrouve|le|la)\b/g, ' '));
    if (f.length < 3) return null;
    var tk = f.split(' ').filter(function (x) { return x.length >= 2; });
    var src = [['Apprenant', jlist('exb_participants')], ['Formateur', jlist('exb_trainers')], ['Personnel', jlist('exb_hr')]], out = [];
    src.forEach(function (s) { s[1].forEach(function (p) { if (allTokens(nameOf(p), tk)) out.push({ k: s[0], n: nameOf(p), m: p.matricule, st: p.approval_status }); }); });
    if (!out.length) return { answer: 'Aucune personne trouvée pour « ' + f + ' ». Essayez « cherche ' + title(f) + ' » (recherche tolérante aux fautes).', actions: [] };
    return { answer: out.slice(0, 8).map(function (o) { return '• ' + o.k + ' · ' + o.n + ' : ' + (o.m ? 'matricule ' + o.m : 'pas encore de matricule' + (o.st && o.st !== 'APPROUVE' ? ' (dossier ' + String(o.st).toLowerCase() + ')' : '')); }).join('\n'), actions: [] };
  }

  /* ---------- bilan général ---------- */
  function bilan() {
    var Pp = jlist('exb_participants'), T = jlist('exb_trainers'), Cl = jlist('exb_clients'), Pj = jlist('exb_projects'), D = jlist('exb_quotes'), C = jlist('exb_cash'), S = jlist('exb_stock'), Sc = jlist('exb_schedules');
    var ok = function (o) { return o.approval_status === 'APPROUVE' || (!o.approval_status && o.matricule); };
    var tin = 0, tout = 0; C.forEach(function (c) { var a = Number(c.amount) || 0; if (c.type === 'out') tout += a; else tin += a; });
    var low = S.filter(function (s) { return Number(s.min) > 0 && Number(s.qty) <= Number(s.min); }).length, today = iso(new Date());
    return { answer: 'Bilan (données de cet appareil) :\n• Apprenants : ' + Pp.length + ' (' + Pp.filter(ok).length + ' approuvés, ' + (Pp.length - Pp.filter(ok).length) + ' en attente)\n• Formateurs : ' + T.length + '\n• Clients : ' + Cl.length + '\n• Projets : ' + Pj.length + ' (' + Pj.filter(function (p) { return has(p.status, 'cours'); }).length + ' en cours)\n• Devis : ' + D.length + '\n• Caisse : solde ' + money(tin - tout) + '\n• Stock : ' + low + ' matériau(x) sous le minimum\n• Séances aujourd’hui : ' + Sc.filter(function (s) { return String(s.date).slice(0, 10) === today; }).length, actions: [G.go('dashboard')] };
  }

  /* ---------- calculs : TVA, pourcentages, unités, dates ---------- */
  var UN = { mm: ['L', 0.001], cm: ['L', 0.01], dm: ['L', 0.1], m: ['L', 1], km: ['L', 1000], 'm2': ['A', 1], 'cm2': ['A', 0.0001], 'ha': ['A', 10000], 'm3': ['V', 1], 'l': ['V', 0.001], 'litre': ['V', 0.001], 'litres': ['V', 0.001], 'g': ['M', 0.001], 'kg': ['M', 1], 't': ['M', 1000], 'tonne': ['M', 1000], 'tonnes': ['M', 1000] };
  function unit(x) { x = String(x).replace('²', '2').replace('³', '3'); return UN[x] ? x : null; }
  function calc(raw, q) {
    var m, n, r;
    if ((m = /(\d[\d\s]*(?:[.,]\d+)?)\s*(?:%|pour ?cent)\s*(?:de|d|sur)\s*(\d[\d\s]*(?:[.,]\d+)?)/.exec(q)) && !/tva/.test(q)) {
      var p = num(m[1]), b = num(m[2]); if (isFinite(p) && isFinite(b)) {
        if (/\b(augment\w*|hausse|majore\w*|plus)\b/.test(q)) return { answer: b + ' + ' + p + ' % = ' + money(b * (1 + p / 100)), actions: [] };
        if (/\b(remise|reduction|baisse|diminu\w*|moins|rabais)\b/.test(q)) return { answer: b + ' − ' + p + ' % = ' + money(b * (1 - p / 100)), actions: [] };
        return { answer: p + ' % de ' + money(b) + ' = ' + money(b * p / 100), actions: [] };
      }
    }
    if (/\btva\b/.test(q) && (m = /(\d[\d\s]*(?:[.,]\d+)?)/g.exec(q.replace(/(\d+(?:[.,]\d+)?)\s*%/g, ' ')))) {
      var rate = (/(\d+(?:[.,]\d+)?)\s*%/.exec(q) || /tva\s*(?:de|a|au|:)?\s*(\d+(?:[.,]\d+)?)/.exec(q) || [])[1];
      var amtM = q.replace(/(\d+(?:[.,]\d+)?)\s*%/g, ' ').replace(/tva\s*(?:de|a|au|:)?\s*\d+(?:[.,]\d+)?/g, ' ').match(/\d[\d\s]*(?:[.,]\d+)?/), amt = num(amtM ? amtM[0] : '');
      var t = rate != null ? num(rate) : 16;
      if (isFinite(amt) && isFinite(t)) {
        if (/\b(ttc|toutes taxes|inclus\w*)\b/.test(q) && !/\bhors\b|\bht\b/.test(q)) { var ht = amt / (1 + t / 100); return { answer: 'TTC ' + money(amt) + ' avec TVA ' + t + ' % :\n• HT : ' + money(ht) + '\n• TVA : ' + money(amt - ht), actions: [] }; }
        return { answer: 'HT ' + money(amt) + ' avec TVA ' + t + ' % :\n• TVA : ' + money(amt * t / 100) + '\n• TTC : ' + money(amt * (1 + t / 100)) + (rate == null ? '\n(Taux de 16 % pris par défaut : précisez-le, ex. « TVA 18 % sur 1 500 ».)' : ''), actions: [] };
      }
    }
    if ((m = /(?:convertis\w*|convertir|combien (?:font|fait|de)|transforme\w*)?\s*(\d[\d\s]*(?:[.,]\d+)?)\s*(mm|cm|dm|km|m2|m²|cm2|cm²|ha|m3|m³|litres?|l|kg|tonnes?|t|g|m)\s*(?:en|vers|=|font|dans)\s*(mm|cm|dm|km|m2|m²|cm2|cm²|ha|m3|m³|litres?|l|kg|tonnes?|t|g|m)\b/.exec(q))) {
      var a = unit(m[2]), z = unit(m[3]); n = num(m[1]);
      if (a && z && isFinite(n) && UN[a][0] === UN[z][0]) { r = n * UN[a][1] / UN[z][1]; return { answer: money(n) + ' ' + m[2] + ' = ' + (Math.round(r * 1e6) / 1e6).toLocaleString('fr-FR') + ' ' + m[3], actions: [] }; }
      if (a && z && isFinite(n)) return { answer: 'Je ne peux pas convertir « ' + m[2] + ' » en « ' + m[3] + ' » : ce ne sont pas des unités du même type (longueur, surface, volume, masse).', actions: [] };
    }
    if ((m = /\b(?:date )?dans (\d+)\s*(jours?|semaines?|mois)\b/.exec(q)) && /\b(date|quel|quelle|jour|sera|serons)\b/.test(q)) {
      n = parseInt(m[1], 10); var d = new Date();
      if (/mois/.test(m[2])) d = new Date(d.getFullYear(), d.getMonth() + n, d.getDate()); else d = addDays(d, /semaine/.test(m[2]) ? 7 * n : n);
      return { answer: 'Dans ' + n + ' ' + m[2] + ' : ' + d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }) + '.', actions: [] };
    }
    if (/\b(quel jour|quelle date|date d.?aujourd|on est quel|nous sommes quel|sommes.?nous)\b/.test(q))
      return { answer: 'Nous sommes le ' + new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }) + '.', actions: [] };
    return null;
  }

  /* ---------- aiguillage ---------- */
  var NOHOW = /\b(comment|pourquoi|explique\w*|c.?est quoi|a quoi sert|mode d.?emploi|que faire|corrige\w*|erreur|bug|marche pas|fonctionne pas)\b/;
  var NAV = /\b(ouvre\w*|ouvrir|va|vas|aller|emmene\w*|navigue\w*)\b/;
  function run(raw, q) {
    q = q || norm(raw);
    if (NOHOW.test(q)) return null;
    var c = calc(raw, q); if (c) return c;
    if (/\b(bilan general|situation generale|tableau de bord|statistiques?|chiffres? cles?|vue d.?ensemble|etat general)\b/.test(q) && !NAV.test(q)) return bilan();
    if (/\bmatricule\b/.test(q) && !/\b(genere\w*|attribu\w*|carte|imprim\w*|approuv\w*|import\w*|sans|pas de|n a pas|aucun|qui|combien|liste\w*|nombre)\b/.test(q)) return matricule(q);
    if (/\bqui\b.*\b(forme|enseigne|donne les cours|maitrise|connait)\b|\bformateurs?\s+(?:de|en|pour|d)\s+\w+/.test(q)) return formateurs(q);
    if (/\b(absents?|presents?|retards?|presences?)\b/.test(q) && /\b(qui|combien|liste|aujourd|hier|demain|semaine|ce jour|nombre)\b/.test(q) && !/\b(chantier|projet|cpi|spi)\b/.test(q)) return presences(q);
    if (/\bcertificats?\b/.test(q) && /\b(combien|nombre|liste|de|pour|delivre\w*|emis|cherche\w*|trouve\w*)\b/.test(q) && !/\b(genere\w*|cree\w*|imprim\w*|nouveau)\b/.test(q)) return certificats(q);
    if (/\bdevis\b/.test(q) && /\b(combien|total|liste|derniers?|montant|nombre|de|pour|cherche\w*|trouve\w*)\b/.test(q) && !/\b(cree\w*|genere\w*|fais|etabli\w*|redige\w*|imprim\w*|relance\w*|nouveau|auto)\b/.test(q)) return devis(q);
    if (/\b(stock|materiaux|materiau|ruptures?)\b/.test(q) && !NAV.test(q) && !/\b(ajout\w*|cree\w*|enregistr\w*|mouvement)\b/.test(q)) return stock(q);
    if (/\b(caisse|tresorerie|recettes?|depenses?|solde|entrees d.?argent|sorties d.?argent)\b/.test(q) && !NAV.test(q) && !/\b(chantier|projet|budget)\b/.test(q)) return caisse(q);
    if (/\b(projets?)\b/.test(q) && !NAV.test(q) && !/\b(retard|derive|cpi|spi|pilotage|eac|evm|ajout\w*|cree\w*|nouveau|enregistr\w*)\b/.test(q) && /\b(liste\w*|combien|nombre|en cours|termine\w*|planifie\w*|budget|avancement|quels?|quelles?|montre\w*|affiche\w*|donne\w*|cherche\w*|trouve\w*|du projet|le projet)\b/.test(q)) return projets(q);
    if (/\b(planning|programme|seances?|sessions?)\b/.test(q) || (/\bformations?\b/.test(q) && period(q) && /\b(quelles?|quels?|y a.?t.?il|a venir|prevue?s?|aujourd|demain)\b/.test(q))) {
      if (NAV.test(q) && !period(q)) return null;
      if (/\b(cree\w*|ajout\w*|nouveau|nouvelle|planifie\w*)\b/.test(q)) return null;
      return planning(q);
    }
    return null;
  }
  w.EXB_ASSIST_PLUS2 = { run: run, version: 'V128d-assistant-plus2-1', _calc: calc };
})(window);
