/* Excellencia Building — V131d ASSISTANT LOCAL RENFORCÉ (sans clé, sans internet, lecture seule).
 *   « téléphone de Jean Kasongo », « e-mail de Paul »        → coordonnées (+ boutons Appeler / WhatsApp / E-mail)
 *   « appelle Paul Mbuyi », « WhatsApp à Marie »              → prépare l'appel ou le message (rien n'est envoyé sans votre tap)
 *   « fiche de Jean Kasongo », « qui est le comptable ? »     → fiche complète (matricule, paiements, notes, présences)
 *   « prix de Revit », « durée de AutoCAD », « liste des formations » → catalogue des formations
 *   « combien a payé Jean ? », « reste à payer de Marie », « total des reçus » → paiements
 *   « note de Jean », « moyenne AutoCAD », « meilleur élève », « qui a plus de 15 ? » → évaluations
 *   « apprenants sans téléphone », « sans matricule », « approuvés », « apprenants d'AutoCAD » → listes filtrées
 *   « que dois-je faire aujourd'hui ? », « priorités », « alertes » → résumé de la journée
 *   « et demain ? », « et pour Revit ? »                      → questions de suite (retient le sujet précédent)
 *   rescue() : corrige les fautes de frappe (« aprouve », « planing ») et propose des phrases proches quand rien n'est compris.
 * Appelé depuis localAI() de index.html :  EXB_ASSIST_PLUS3.run(texteBrut, texteNormalisé) → {answer, actions} ou null. */
(function (w) {
  'use strict';
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9+#.,%\-@ ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function jlist(key) {
    var a = null, v;
    try { if (w.EXBS && w.EXBS.get) a = w.EXBS.get(key); } catch (e) {}
    if (!a || !a.length) { try { var st = (typeof exbStorage !== 'undefined') ? exbStorage : null; if (st) { v = JSON.parse(st.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } } catch (e) {} }
    if (!a || !a.length) { try { v = JSON.parse(w.localStorage.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } catch (e) {} }
    return (a || []).filter(function (x) { return x && typeof x === 'object'; });
  }
  function money(n) { return Number(n || 0).toLocaleString('fr-FR', { maximumFractionDigits: 2 }); }
  function amount(s) { var m = String(s == null ? '' : s).replace(/\s/g, '').replace(',', '.').match(/-?\d+(?:\.\d+)?/); return m ? parseFloat(m[0]) : 0; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function nm(r) { return String(r.name || r.full_name || r.company || [r.first_name, r.last_name].filter(Boolean).join(' ') || '').trim(); }
  function isPaid(st) { return /^pay/.test(norm(st)); }
  function pend(o) { return !(o.approval_status === 'APPROUVE' || o.approval_status === 'REJETE' || (!o.approval_status && o.matricule)); }
  var G = function (t) { return { type: 'goto', tab: t }; };
  var STOP = /\b(le|la|les|l|de|du|des|d|un|une|au|aux|a|et|pour|sur|dans|en|ce|cette|mes|mon|ma|son|sa|ses|qui|quel|quels|quelle|quelles|est|sont|y|il|ya|combien|liste|lister|montre|affiche|donne|dis|moi|svp|stp|total|tous|toutes|tout|par|avec|chez|cherche|trouve|retrouve|telephone|tel|numero|gsm|portable|contact|joindre|mail|email|e-mail|courriel|adresse|fiche|infos?|informations?|profil|dossier|renseignements?|apprenant|apprenants|participant|participants|formateur|formateurs|client|clients|personnel|employe|employes|eleve|eleves|etudiant|etudiants|inscrit|inscrits|paye|payer|payes|paiement|paiements|reste|restant|solde|doit|dette|verse|regle|note|notes|moyenne|resultat|resultats|score|formation|formations|cours|prix|cout|coute|tarif|duree|appelle|appeler|sms|texto|whatsapp|envoie|ecris|ecrire|message|numero|s|n|y|a|t)\b/g;
  function subject(q) { return q.replace(STOP, ' ').replace(/[?!.,;:]+/g, ' ').replace(/\s+/g, ' ').trim(); }

  /* ---------- annuaire ---------- */
  function P(kind, tab, r) { var n = nm(r); return { kind: kind, tab: tab, r: r, name: n, n: norm(n + ' ' + (r.company || '')), phone: r.phone || r.telephone || r.tel || '', email: r.email || '', mat: r.matricule || '', st: r.approval_status || '', role: r.role || r.specialty || r.type || '', training: r.training || '' }; }
  function people() {
    var o = [];
    jlist('exb_participants').forEach(function (r) { o.push(P('Apprenant', 'participants', r)); });
    jlist('exb_trainers').forEach(function (r) { o.push(P('Formateur', 'formateurs', r)); });
    jlist('exb_hr').forEach(function (r) { o.push(P('Personnel', 'rh', r)); });
    jlist('exb_clients').forEach(function (r) { o.push(P('Client', 'clients', r)); });
    return o.filter(function (p) { return p.name; });
  }
  function find(sub) {
    var toks = norm(sub).split(' ').filter(function (x) { return x.length >= 2; });
    if (!toks.length) return { hits: [], fuzzy: false };
    var all = people(), ex = all.filter(function (p) { return toks.every(function (t) { return p.n.indexOf(t) >= 0; }); });
    if (ex.length) return { hits: ex, fuzzy: false };
    try {
      var f = w.EXB_ASSIST_PLUS && w.EXB_ASSIST_PLUS.fuzzy ? w.EXB_ASSIST_PLUS.fuzzy(sub) : [];
      var labels = {}; f.forEach(function (x) { labels[norm(x.label)] = 1; });
      var h = all.filter(function (p) { return labels[norm(p.name)]; });
      if (h.length) return { hits: h.slice(0, 6), fuzzy: true };
    } catch (e) {}
    return { hits: [], fuzzy: false };
  }
  function phoneNorm(p) { var raw = String(p || ''), dg = raw.replace(/\D/g, ''), cc = '243'; try { cc = w.localStorage.getItem('exb_cc') || '243'; } catch (e) {} if (!dg) return ''; if (/^\s*\+/.test(raw)) return dg; if (dg.indexOf('00') === 0) return dg.slice(2); if (dg.charAt(0) === '0') return cc + dg.slice(1); return dg; }
  function line(p) { return '• ' + p.kind + ' · ' + p.name + (p.mat ? ' — ' + p.mat : '') + (p.phone ? ' · 📞 ' + p.phone : '') + (p.email ? ' · ✉️ ' + p.email : '') + (p.training ? ' · ' + p.training : (p.role ? ' · ' + p.role : '')) + (p.st && p.st !== 'APPROUVE' ? ' · ' + String(p.st).toLowerCase() : ''); }
  function contactActs(p, only) {
    var a = [], num = phoneNorm(p.phone);
    if (num && (!only || only === 'call')) a.push({ type: 'contact', mode: 'call', name: p.name, value: '+' + num });
    if (num && (!only || only === 'sms')) a.push({ type: 'contact', mode: 'sms', name: p.name, value: '+' + num });
    if (num && (!only || only === 'wa')) a.push({ type: 'contact', mode: 'wa', name: p.name, value: num });
    if (p.email && (!only || only === 'mail')) a.push({ type: 'contact', mode: 'mail', name: p.name, value: p.email });
    return a;
  }
  function notFound(sub, fz) { return { answer: 'Je ne trouve personne qui s’appelle « ' + sub + ' » (apprenants, formateurs, personnel, clients).' + (fz ? '' : ' Essayez « cherche ' + sub + ' » (recherche tolérante aux fautes).'), actions: [] }; }
  function pick(sub, extraNote) { /* renvoie {p} si une seule personne, sinon {res} réponse prête */
    var f = find(sub);
    if (!f.hits.length) return { res: notFound(sub) };
    if (f.hits.length > 1) return { res: { answer: (f.fuzzy ? 'Je ne trouve pas exactement « ' + sub + ' ». Vous pensiez à :\n' : f.hits.length + ' personnes correspondent à « ' + sub + ' » — précisez le nom :\n') + f.hits.slice(0, 6).map(line).join('\n'), actions: [] } };
    return { p: f.hits[0], fz: f.fuzzy };
  }

  /* ---------- contact : coordonnées et actions ---------- */
  function contact(q, sub) {
    var wantMail = /\b(e.?mail|mail|courriel)\b/.test(q), wantAddr = /\badresse\b/.test(q);
    var k = pick(sub); if (k.res) return k.res; var p = k.p, r = p.r;
    var head = (k.fz ? '(Je suppose que vous parlez de ' + p.name + '.)\n' : '');
    var txt;
    if (wantAddr) txt = r.address ? p.name + ' : ' + r.address : 'Aucune adresse enregistrée pour ' + p.name + '.';
    else if (wantMail) txt = p.email ? p.name + ' : ' + p.email : 'Aucun e-mail enregistré pour ' + p.name + '.';
    else txt = p.phone ? p.name + ' : ' + p.phone : 'Aucun numéro enregistré pour ' + p.name + '.';
    return { answer: head + txt + '\n(' + p.kind + (p.mat ? ' ' + p.mat : '') + ')', actions: contactActs(p, wantMail ? 'mail' : '').slice(0, 4), base: wantMail ? 'email de' : wantAddr ? 'adresse de' : 'telephone de' };
  }
  function action(q, mode, sub) {
    var k = pick(sub); if (k.res) return k.res; var p = k.p, a = contactActs(p, mode);
    if (!a.length) return { answer: (mode === 'mail' ? 'Aucun e-mail' : 'Aucun numéro') + ' enregistré pour ' + p.name + '.', actions: [] };
    var lab = { call: 'l’appel', sms: 'le SMS', wa: 'WhatsApp', mail: 'l’e-mail' }[mode];
    return { answer: 'Je prépare ' + lab + ' pour ' + p.name + ' (' + (mode === 'mail' ? p.email : p.phone) + '). Touchez le bouton : rien n’est envoyé sans votre action.', actions: a, base: 'telephone de' };
  }

  /* ---------- paiements ---------- */
  function recus() { return jlist('exb_receipts'); }
  function payPerson(sub) {
    var toks = norm(sub).split(' ').filter(function (x) { return x.length >= 2; });
    var R = recus().filter(function (r) { var n = norm(r.participant); return toks.every(function (t) { return n.indexOf(t) >= 0; }); });
    if (!R.length) { var f = find(sub); if (f.hits.length === 1) { var n2 = norm(f.hits[0].name); R = recus().filter(function (r) { return norm(r.participant) === n2; }); sub = f.hits[0].name; } }
    if (!R.length) return { answer: 'Aucun reçu trouvé pour « ' + sub + ' ».', actions: [G('receipts')] };
    var paid = 0, due = 0, L = [];
    R.forEach(function (r) {
      var a1 = amount(r.registration_fee), a2 = amount(r.training_fee), p1 = isPaid(r.registration_status), p2 = isPaid(r.training_status);
      paid += (p1 ? a1 : 0) + (p2 ? a2 : 0); due += (p1 ? 0 : a1) + (p2 ? 0 : a2);
      L.push('• ' + (r.training || '?') + ' — inscription ' + (r.registration_fee || '0') + (p1 ? ' ✓ payée' : ' ✗ non payée') + ' · formation ' + (r.training_fee || '0') + (p2 ? ' ✓ payée' : ' ✗ non payée') + (r.receipt_no ? ' [' + r.receipt_no + ']' : ''));
    });
    return { answer: R[0].participant + ' : payé ' + money(paid) + ', reste à payer ' + money(due) + '.\n' + L.slice(0, 5).join('\n') + '\n(Montants tels que saisis sur les reçus, sans conversion de monnaie.)', actions: [G('receipts')], base: 'reste a payer de' };
  }
  function payGlobal(q) {
    var R = recus(); if (!R.length) return { answer: 'Aucun reçu enregistré.', actions: [G('receipts')] };
    var paid = 0, due = 0, full = 0, none = 0, part = 0;
    R.forEach(function (r) { var a1 = amount(r.registration_fee), a2 = amount(r.training_fee), p1 = isPaid(r.registration_status), p2 = isPaid(r.training_status); paid += (p1 ? a1 : 0) + (p2 ? a2 : 0); due += (p1 ? 0 : a1) + (p2 ? 0 : a2); if (p1 && p2) full++; else if (!p1 && !p2) none++; else part++; });
    return { answer: R.length + ' reçu(s) :\n• Entièrement payés : ' + full + '\n• Partiellement payés : ' + part + '\n• Non payés : ' + none + '\n• Encaissé : ' + money(paid) + '\n• Reste à encaisser : ' + money(due) + '\n(Montants tels que saisis, sans conversion de monnaie.)', actions: [G('receipts')] };
  }

  /* ---------- évaluations ---------- */
  function evals() { return jlist('exb_evaluations'); }
  function pct(e) { var p = parseFloat(e.percent); if (isFinite(p)) return p; var s = parseFloat(e.score), m = parseFloat(e.max); if (!(m > 0)) m = 20; /* barème /20 par défaut */ return isFinite(s) ? s / m * 100 : NaN; }
  var PN = null;
  function pnames() { PN = {}; jlist('exb_participants').forEach(function (p) { if (p.participant_id) PN[p.participant_id] = p.name || ''; }); return PN; }
  function ename(e) { var n = e.participant_name || (PN || pnames())[e.participant_id] || ''; return n; }
  function avgBy(list) {
    var by = {};
    list.forEach(function (e) { var p = pct(e); if (!isFinite(p)) return; var k = e.participant_id || norm(e.participant_name); (by[k] = by[k] || { name: ename(e) || k, training: e.training || '', s: 0, n: 0 }); by[k].s += p; by[k].n++; });
    return Object.keys(by).map(function (k) { var x = by[k]; return { name: x.name, training: x.training, avg: x.s / x.n, n: x.n }; });
  }
  function trainingOf(q) {
    var names = {}; jlist('exb_formations').forEach(function (f) { if (f.name) names[f.name] = 1; }); evals().forEach(function (e) { if (e.training) names[e.training] = 1; });
    var hit = Object.keys(names).filter(function (t) { return q.indexOf(norm(t)) >= 0; }).sort(function (a, b) { return b.length - a.length; });
    return hit[0] || '';
  }
  function notes(q) {
    PN = null; var E = evals(); if (!E.length) return { answer: 'Aucune évaluation enregistrée pour le moment.', actions: [G('evaluations')] };
    var tr = trainingOf(q), list = tr ? E.filter(function (e) { return norm(e.training) === norm(tr); }) : E;
    var s20 = function (p) { return Math.round(p / 5 * 10) / 10; };
    var th = /\b(?:plus de|superieur\w* a|au dessus de|depasse\w*|au moins|>=?)\s*(\d+(?:[.,]\d+)?)/.exec(q), tl = /\b(?:moins de|inferieur\w* a|en dessous de|sous|<=?)\s*(\d+(?:[.,]\d+)?)/.exec(q);
    var A = avgBy(list);
    if (th || tl) {
      var v = parseFloat((th || tl)[1].replace(',', '.')), l = A.filter(function (x) { return th ? s20(x.avg) >= v : s20(x.avg) <= v; }).sort(function (a, b) { return b.avg - a.avg; });
      return { answer: l.length + ' apprenant(s) avec une moyenne ' + (th ? '≥ ' : '≤ ') + v + '/20' + (tr ? ' en ' + tr : '') + ' :\n' + l.slice(0, 12).map(function (x) { return '• ' + x.name + ' — ' + s20(x.avg) + '/20'; }).join('\n') + '\n(Moyenne de toutes ses évaluations, ramenée sur 20.)', actions: [G('evaluations')] };
    }
    if (/\b(meilleur\w*|premier|classement|top|major)\b/.test(q)) {
      var top = A.slice().sort(function (a, b) { return b.avg - a.avg; }).slice(0, 5);
      return top.length ? { answer: 'Classement' + (tr ? ' ' + tr : '') + ' (moyenne ramenée sur 20) :\n' + top.map(function (x, i) { return (i + 1) + '. ' + x.name + ' — ' + s20(x.avg) + '/20 (' + x.n + ' éval.)'; }).join('\n'), actions: [G('evaluations')] } : { answer: 'Pas assez de notes pour établir un classement.', actions: [G('evaluations')] };
    }
    if (/\b(admis|reussi\w*|echoue\w*|recale\w*)\b/.test(q)) {
      var ok = A.filter(function (x) { return x.avg >= 50; }), ko = A.length - ok.length;
      return { answer: 'Sur ' + A.length + ' apprenant(s) évalué(s)' + (tr ? ' en ' + tr : '') + ' : ' + ok.length + ' avec moyenne ≥ 10/20, ' + ko + ' en dessous.\n(Seuil de 10/20 pris par défaut.)', actions: [G('evaluations')] };
    }
    var sub = subject(q.replace(norm(tr), ' '));
    if (sub.length >= 2 && !/\b(generale|globale|classe)\b/.test(sub)) {
      var f = find(sub); if (f.hits.length !== 1) return f.hits.length ? { answer: 'Précisez la personne :\n' + f.hits.slice(0, 5).map(line).join('\n'), actions: [] } : notFound(sub);
      var p = f.hits[0], mine = E.filter(function (e) { return (e.participant_id && p.r.participant_id && e.participant_id === p.r.participant_id) || norm(ename(e)) === norm(p.name); });
      if (!mine.length) return { answer: 'Aucune évaluation enregistrée pour ' + p.name + '.', actions: [G('evaluations')] };
      var av = avgBy(mine)[0];
      return { answer: p.name + ' — moyenne ' + (av ? s20(av.avg) + '/20' : '?') + ' (' + mine.length + ' évaluation(s)) :\n' + mine.slice(0, 6).map(function (e) { return '• ' + (e.date || '') + ' · ' + (e.type || 'éval.') + (e.subject ? ' — ' + e.subject : '') + ' : ' + (e.score != null ? e.score + '/' + (e.max || 20) : '?'); }).join('\n'), actions: [G('evaluations')], base: 'note de' };
    }
    if (!A.length) return { answer: 'Aucune note exploitable' + (tr ? ' pour ' + tr : '') + '.', actions: [G('evaluations')] };
    var m = A.reduce(function (a, x) { return a + x.avg; }, 0) / A.length;
    return { answer: 'Moyenne' + (tr ? ' en ' + tr : ' générale') + ' : ' + s20(m) + '/20 sur ' + A.length + ' apprenant(s) (' + list.length + ' évaluation(s)).', actions: [G('evaluations')], base: 'moyenne' };
  }

  /* ---------- formations ---------- */
  function formations(q) {
    var F = jlist('exb_formations'), P0 = jlist('exb_participants');
    if (!F.length) return { answer: 'Aucune formation enregistrée dans le catalogue.', actions: [G('formations')] };
    var cnt = function (f) { return P0.filter(function (p) { return norm(p.training) === norm(f.name); }).length; };
    var fmt = function (f) { return '• ' + f.name + (f.code ? ' (' + f.code + ')' : '') + (f.price != null && f.price !== '' ? ' — prix ' + f.price : '') + (f.duration ? ' — ' + f.duration : '') + ' — ' + cnt(f) + ' inscrit(s)'; };
    var hit = F.filter(function (f) { return q.indexOf(norm(f.name)) >= 0 || (f.code && q.split(' ').indexOf(norm(f.code)) >= 0); }).sort(function (a, b) { return b.name.length - a.name.length; });
    if (hit.length) {
      var f = hit[0];
      if (/\b(duree|dure|combien de temps|heures)\b/.test(q)) return { answer: f.name + ' : ' + (f.duration || 'durée non renseignée') + '.', actions: [G('formations')], base: 'duree de' };
      if (/\b(prix|cout|coute|tarif|frais|combien)\b/.test(q) && !/\b(inscrits?|apprenants?|participants?)\b/.test(q)) return { answer: f.name + ' : ' + (f.price != null && f.price !== '' ? f.price : 'prix non renseigné') + '.', actions: [G('formations')], base: 'prix de' };
      var tr = jlist('exb_trainers').filter(function (t) { return norm([t.specialty].concat(t.specialties || []).join(' ')).indexOf(norm(f.name)) >= 0; }).map(function (t) { return t.name; });
      var today = iso(new Date()), nx = jlist('exb_schedules').filter(function (s) { return norm(s.training) === norm(f.name) && String(s.date).slice(0, 10) >= today; }).sort(function (a, b) { return String(a.date).localeCompare(String(b.date)); })[0];
      return { answer: fmt(f) + (tr.length ? '\nFormateur(s) : ' + tr.slice(0, 4).join(', ') : '') + (nx ? '\nProchaine séance : ' + String(nx.date).slice(0, 10) + (nx.start ? ' ' + nx.start : '') + (nx.module ? ' — ' + nx.module : '') : ''), actions: [G('formations')], base: 'formation' };
    }
    return { answer: F.length + ' formation(s) :\n' + F.slice(0, 15).map(fmt).join('\n'), actions: [G('formations')] };
  }

  /* ---------- listes filtrées ---------- */
  function filtres(q) {
    var kind = /\b(formateurs?)\b/.test(q) ? ['Formateurs', 'exb_trainers', 'formateurs'] : /\b(personnel|employes?|staff)\b/.test(q) ? ['Personnel', 'exb_hr', 'rh'] : /\b(clients?)\b/.test(q) ? ['Clients', 'exb_clients', 'clients'] : ['Apprenants', 'exb_participants', 'participants'];
    var L = jlist(kind[1]), lab = [], f = L;
    var no = function (s) { return new RegExp('\\b(?:sans|pas de|n a pas de|na pas de|aucun)\\s+(?:' + s + ')\\b').test(q); };
    if (no('telephone|numero|tel|gsm')) { f = f.filter(function (r) { return !(r.phone || r.telephone || r.tel); }); lab.push('sans téléphone'); }
    if (no('mail|email|e-mail|courriel')) { f = f.filter(function (r) { return !r.email; }); lab.push('sans e-mail'); }
    if (no('matricule')) { f = f.filter(function (r) { return !r.matricule; }); lab.push('sans matricule'); }
    if (/\b(en attente|non approuves?|pas approuves?|pas encore approuves?|a approuver)\b/.test(q)) { f = f.filter(pend); lab.push('en attente d’approbation'); }
    else if (/\bapprouves?\b/.test(q)) { f = f.filter(function (r) { return !pend(r); }); lab.push('approuvés'); }
    var tr = kind[0] === 'Apprenants' ? trainingOf(q) : ''; if (tr) { f = f.filter(function (r) { return norm(r.training) === norm(tr); }); lab.push('en ' + tr); }
    if (!lab.length) return null;
    var names = f.slice(0, 15).map(function (r) { return '• ' + nm(r) + (r.matricule ? ' — ' + r.matricule : '') + (r.phone ? ' — ' + r.phone : ''); });
    return { answer: kind[0] + ' ' + lab.join(', ') + ' : ' + f.length + (f.length ? '\n' + names.join('\n') + (f.length > 15 ? '\n…' : '') : ''), actions: [G(kind[2])] };
  }

  /* ---------- qui est… (rôle) et fiche ---------- */
  function role(q) {
    var m = /\bqui est (?:le |la |l |notre |mon |ma )?(.+)$/.exec(q); if (!m) return null;
    var r = norm(m[1]).replace(/\b(de l.?entreprise|chez nous)\b/, '').trim(); if (r.length < 3) return null;
    var H = jlist('exb_hr').concat(jlist('exb_trainers')), hit = H.filter(function (x) { return norm(x.role || x.specialty || x.post || '').indexOf(r) >= 0; });
    if (!hit.length) return null;
    return { answer: hit.slice(0, 6).map(function (x) { return '• ' + nm(x) + ' — ' + (x.role || x.specialty) + (x.phone ? ' · 📞 ' + x.phone : ''); }).join('\n'), actions: [G('rh')] };
  }
  function fiche(sub) {
    var k = pick(sub); if (k.res) return k.res; var p = k.p, r = p.r, out = [(k.fz ? '(Je suppose que vous parlez de ' + p.name + '.)\n' : '') + line(p)];
    if (p.kind === 'Apprenant') {
      var pay = payPerson(p.name); if (!/Aucun reçu/.test(pay.answer)) out.push(pay.answer.split('\n')[0]);
      PN = null; var ev = avgBy(evals().filter(function (e) { return (e.participant_id && e.participant_id === r.participant_id) || norm(ename(e)) === norm(p.name); }))[0];
      if (ev) out.push('Moyenne : ' + (Math.round(ev.avg / 5 * 10) / 10) + '/20');
      var at = jlist('exb_attendance').filter(function (x) { return x.participant_id === r.participant_id; }), ab = at.filter(function (x) { return x.status === 'ABSENT'; }).length;
      if (at.length) out.push('Présences : ' + (at.length - ab) + '/' + at.length + ' (' + ab + ' absence(s))');
    }
    if (r.address) out.push('Adresse : ' + r.address);
    return { answer: out.join('\n'), actions: [G(p.tab)].concat(contactActs(p).slice(0, 2)), base: 'fiche de' };
  }

  /* ---------- résumé de la journée ---------- */
  function jour() {
    var today = iso(new Date()), L = [], acts = [];
    var S = jlist('exb_schedules').filter(function (s) { return String(s.date).slice(0, 10) === today; });
    if (S.length) L.push('📅 ' + S.length + ' séance(s) aujourd’hui : ' + S.slice(0, 3).map(function (s) { return (s.start || '') + ' ' + (s.training || '?'); }).join(', '));
    var inbox = 0; try { inbox = w.EXB_INBOX && w.EXB_INBOX.pending ? Number(w.EXB_INBOX.pending()) || 0 : 0; } catch (e) {}
    if (inbox) { L.push('📥 ' + inbox + ' demande(s) en ligne à traiter'); acts.push(G('participantForm')); }
    [['insc', 'exb_participants', 'apprenant(s)'], ['form', 'exb_trainers', 'formateur(s)'], ['pers', 'exb_hr', 'membre(s) du personnel']].forEach(function (k) {
      var n = jlist(k[1]).filter(pend).length; if (n) { L.push('✋ ' + n + ' ' + k[2] + ' à approuver'); acts.push({ type: 'approve', target: k[0] }); }
    });
    var unpaid = recus().filter(function (r) { return !(isPaid(r.registration_status) && isPaid(r.training_status)); }).length;
    if (unpaid) { L.push('💰 ' + unpaid + ' reçu(s) avec un paiement en attente'); }
    var low = jlist('exb_stock').filter(function (s) { return Number(s.min) > 0 && Number(s.qty) <= Number(s.min); }).length;
    if (low) { L.push('📦 ' + low + ' matériau(x) sous le minimum'); }
    var late = jlist('exb_projects').filter(function (p) { return p.end && String(p.end).slice(0, 10) < today && !/termin/.test(norm(p.status)); }).length;
    if (late) { L.push('🏗️ ' + late + ' projet(s) au-delà de la date de fin prévue'); }
    var ab = jlist('exb_attendance').filter(function (x) { return String(x.date).slice(0, 10) === today && x.status === 'ABSENT'; }).length;
    if (ab) L.push('🙋 ' + ab + ' absent(s) enregistré(s) aujourd’hui');
    if (!L.length) return { answer: 'Rien d’urgent d’après les données de cet appareil. ✅', actions: [] };
    return { answer: 'Point du jour (données de cet appareil) :\n' + L.join('\n'), actions: acts.slice(0, 4) };
  }

  /* ---------- aiguillage + mémoire de conversation ---------- */
  var CTX = { raw: '', base: '' }, busyF = false;
  var NOHOW = /\b(comment|pourquoi|explique\w*|c.?est quoi|a quoi sert|mode d.?emploi|que faire pour|marche pas|fonctionne pas|erreur)\b/;
  var PER = /\b(demain|hier|aujourd|apres.?demain|semaine|mois|ce jour)\b/;
  function remember(raw, r) { CTX.raw = raw; CTX.base = (r && r.base) || ''; return r; }
  function followUp(raw, q) {
    if (!/^(et|et pour|et si|et alors|idem|pareil|meme chose)\b/.test(q) || q.split(' ').length > 6 || !CTX.raw || busyF) return null;
    var rest = q.replace(/^(et pour|et si|et alors|et|idem|pareil|meme chose)\s*/, '').replace(/[?!.]+$/, '').replace(/^(le|la|les|l|pour|de|du|d)\s+/, '').trim();
    var next = '';
    var pm = PER.exec(rest);
    if (pm && /\b(planning|seances?|programme|caisse|depenses?|recettes?|entrees?|sorties?|presences?|absents?|presents?|retards?|formations?|cours|sessions?)\b/.test(norm(CTX.raw))) next = norm(CTX.raw).replace(new RegExp(PER.source, 'g'), ' ').replace(/\s+/g, ' ').trim() + ' ' + rest;
    else if (CTX.base && rest.length >= 2) next = CTX.base + ' ' + rest;
    if (!next || !w.exbLocalAI) return null;
    busyF = true; try { var r = w.exbLocalAI(next); return r && !/^(Je n’ai pas compris|Je ne trouve personne|Aucun)/.test(r.answer) ? r : null; } finally { busyF = false; }
  }
  function run(raw, q) {
    q = q || norm(raw);
    var fu = followUp(raw, q); if (fu) return fu;
    if (NOHOW.test(q)) { return null; }
    var r = dispatch(raw, q);
    if (r) { remember(raw, r); return r; }
    if (!/^(et|idem|pareil)\b/.test(q)) CTX.raw = raw, CTX.base = '';
    return null;
  }
  function dispatch(raw, q) {
    if (/\b(relance\w*|rappel\w*|bienvenue|confirmation|remerciement|modele|redige\w*|texte)\b/.test(q)) return null; /* gérés par les modèles de messages existants */
    if (/\b(ouvre\w*|ouvrir|va|vas|aller|emmene\w*|navigue\w*|ajout\w*|cree\w*|creer|nouveau|nouvelle|enregistr\w*|saisi\w*|rempli\w*|remplir|supprim\w*|efface\w*|modifi\w*|licence|abonnement)\b/.test(q)) return null; /* navigation, création, licences : règles existantes */
    var sub = subject(q);
    /* actions de contact */
    if (/\b(appelle\w*|appeler|telephoner|passe\w* un appel)\b/.test(q) && sub.length >= 2) return action(q, 'call', sub);
    if (/\b(sms|texto)\b/.test(q) && /\b(envoie\w*|ecris\w*|manda\w*|un|a)\b/.test(q) && sub.length >= 2 && !/\bnumero|telephone\b/.test(q)) return action(q, 'sms', sub);
    if (/\bwhatsapp\b/.test(q) && sub.length >= 2 && !/\b(lien|formulaire|partag\w*)\b/.test(q)) return action(q, 'wa', sub);
    if (/\b(envoie\w*|ecris\w*)\b.*\b(e.?mail|mail|courriel)\b/.test(q) && sub.length >= 2) return action(q, 'mail', sub);
    /* résumé de la journée */
    if (/\b(que dois.?je faire|quoi faire|a faire|priorites?|priorite|resume\w* (?:ma |la )?journee|ma journee|alertes?|urgent\w*|point du jour|rien a signaler|a surveiller)\b/.test(q) && !/\b(formulaire|fiche|licence)\b/.test(q)) return jour();
    /* qui est le comptable */
    var rl = role(q); if (rl) return rl;
    /* coordonnées */
    if (/\b(telephone|tel|numero|gsm|portable|joindre|contact|e.?mail|mail|courriel|adresse)\b/.test(q) && sub.length >= 2 && !/\b(licence|serveur|whatsapp|recus?|certificats?|facture|devis|matricule)\b/.test(q) && !/\b(sans|pas de|n a pas)\b/.test(q)) return contact(q, sub);
    /* fiche */
    if (/\b(fiche|profil|infos?|informations?|renseignements?|dossier)\b/.test(q) && sub.length >= 2 && !/\b(formation|formulaire|licence)\b/.test(q)) return fiche(sub);
    if (/^qui est\b/.test(q) && sub.length >= 2) return fiche(sub);
    /* paiements */
    if (/\b(paye|payer|payes|paiements?|reste|doit|dette|verse|regle|encaisse\w*)\b/.test(q) && !/\b(sans|pas de|stock|caisse|budget|projet|chantier|materiau\w*|devis)\b/.test(q)) {
      if (sub.length >= 2 && !/\b(combien d|combien de|nombre)\b/.test(q)) return payPerson(sub);
      if (/\b(total|recus?|encaisse\w*|combien)\b/.test(q) && !/\bqui\b/.test(q)) return payGlobal(q);
    }
    if (/\b(total|bilan|etat|statistiques?)\b.*\brecus?\b|\brecus?\b.*\b(total|combien)\b/.test(q)) return payGlobal(q);
    /* notes */
    if (/\b(notes?|moyenne|resultats?|score|classement|meilleur\w*|premier|admis|reussi\w*|echoue\w*|recale\w*|major)\b/.test(q) && !/\b(tp|td|qcm|copies?|epreuves?|cotation|bulletin|certificat)\b/.test(q)) return notes(q);
    /* formations */
    if (!PER.test(q) && !/\b(planning|seances?|calendrier|ajout\w*|cree\w*|nouvelle|modifi\w*)\b/.test(q)) {
      var known = jlist('exb_formations').some(function (f) { return q.indexOf(norm(f.name)) >= 0; });
      if (/\b(prix|cout|coute|tarif|duree|frais de formation)\b/.test(q) && (known || /\b(formations?|cours|stage)\b/.test(q))) return formations(q);
      if (/^(liste\w* )?(des |les |nos )?formations?$/.test(q) || /\b(quelles?|nos|catalogue|liste\w*) (?:sont )?(?:les |des |nos )?formations?\b/.test(q)) return formations(q);
      var F = formations(q); if (F && /\b(formation|cours|details?|infos?)\b/.test(q) && !/Aucune formation/.test(F.answer) && jlist('exb_formations').some(function (f) { return q.indexOf(norm(f.name)) >= 0; })) return F;
    }
    /* listes filtrées */
    if (/\b(combien|nombre|liste\w*|quels?|quelles?|qui)\b|^(les )?(apprenants|participants|inscrits|formateurs|clients|personnel)\b/.test(q)) { var fl = filtres(q); if (fl) return fl; }
    return null;
  }

  /* ---------- rattrapage : fautes de frappe + suggestions ---------- */
  var VOC = ['approuve', 'approuver', 'importe', 'importer', 'planning', 'formation', 'formations', 'apprenant', 'apprenants', 'participant', 'participants', 'formateur', 'formateurs', 'telephone', 'paiement', 'paiements', 'moyenne', 'stock', 'caisse', 'projet', 'projets', 'devis', 'certificat', 'certificats', 'presence', 'presences', 'absents', 'recus', 'clients', 'personnel', 'matricule', 'doublons', 'relance', 'impayes', 'resume', 'bilan', 'marque', 'traite', 'cherche', 'trouve', 'ouvre', 'demande', 'demandes', 'combien', 'liste', 'aujourd', 'demain', 'semaine', 'notes', 'evaluation', 'evaluations', 'approuves', 'attente', 'rejette', 'appelle', 'whatsapp', 'inscrits', 'tableau', 'finances', 'comptabilite', 'planing'];
  var busyR = false;
  function osa(a, b, max) {
    var la = a.length, lb = b.length; if (Math.abs(la - lb) > max) return max + 1;
    var m = [], i, j; for (i = 0; i <= la; i++) m[i] = [i]; for (j = 1; j <= lb; j++) m[0][j] = j;
    for (i = 1; i <= la; i++) for (j = 1; j <= lb; j++) {
      m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      if (i > 1 && j > 1 && a.charAt(i - 1) === b.charAt(j - 2) && a.charAt(i - 2) === b.charAt(j - 1)) m[i][j] = Math.min(m[i][j], m[i - 2][j - 2] + 1);
    }
    return m[la][lb];
  }
  function fixTypos(q) {
    var known = {}; people().forEach(function (p) { p.n.split(' ').forEach(function (t) { known[t] = 1; }); });
    var changed = false, out = q.split(' ').map(function (t) {
      if (t.length < 5 || VOC.indexOf(t) >= 0 || known[t]) return t;
      var best = null, bd = 9;
      VOC.forEach(function (v) { if (Math.abs(v.length - t.length) > 1) return; var d = osa(t, v, 1); if (d <= 1 && d < bd) { bd = d; best = v; } });
      if (best) { changed = true; return best; } return t;
    });
    return changed ? out.join(' ') : null;
  }
  var SUG = [
    [/\b(paye|payer|paiement|argent|recu|doit|dette)\w*/, ['« reste à payer de Jean Kasongo »', '« qui n’a pas payé ? »', '« total des reçus »']],
    [/\b(note|moyenne|resultat|examen|eval)\w*/, ['« note de Jean Kasongo »', '« moyenne AutoCAD »', '« meilleur élève »']],
    [/\b(telephone|numero|joindre|appel|contact|mail)\w*/, ['« téléphone de Jean Kasongo »', '« appelle Paul Mbuyi »', '« e-mail de Marie »']],
    [/\b(formation|cours|prix|duree|tarif)\w*/, ['« liste des formations »', '« prix de Revit »', '« planning de demain »']],
    [/\b(apprenant|participant|eleve|inscrit|etudiant)\w*/, ['« apprenants sans téléphone »', '« apprenants d’AutoCAD »', '« fiche de Jean Kasongo »']],
    [/\b(chantier|projet|budget|devis)\w*/, ['« liste des projets »', '« combien de devis ? »', '« budget du projet Villa »']],
    [/\b(demande|inscription|attente|approuv)\w*/, ['« importe et approuve les demandes »', '« qui est à approuver ? »', '« que dois-je faire aujourd’hui ? »']]
  ];
  function rescue(raw, q) {
    q = q || norm(raw);
    if (busyR) return null;
    var fx = fixTypos(q);
    if (fx && w.exbLocalAI) {
      busyR = true;
      try { var r = w.exbLocalAI(fx); if (r && r.answer && !/^Je n’ai pas compris/.test(r.answer)) return { answer: '(J’ai compris : « ' + fx + ' »)\n' + r.answer, actions: r.actions || [] }; } finally { busyR = false; }
    }
    for (var i = 0; i < SUG.length; i++) if (SUG[i][0].test(q)) return { answer: 'Je n’ai pas bien compris. Sur ce sujet, essayez par exemple :\n' + SUG[i][1].map(function (s) { return '• ' + s; }).join('\n') + '\nOu dites « que sais-tu faire ? » pour voir toutes mes possibilités.', actions: [] };
    return null;
  }
  w.EXB_ASSIST_PLUS3 = { run: run, rescue: rescue, version: 'V131d-assistant-plus3-1', _ctx: CTX };
})(window);
