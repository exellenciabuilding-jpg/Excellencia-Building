const test = require('node:test'), assert = require('node:assert/strict');
const C = require('../../site/docengine/core.js'); require('../../site/docengine/templates.js'); require('../../site/docengine/templates-modules.js');
const prof = (C.normalizeProfile || C.normProfile || (x => x))({ name: 'ACME BTP', city: 'Goma', phones: ['+243 1'], emails: ['a@b.c'] });
const qr = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><rect width="10" height="10"/></svg>').toString('base64');
const ctx = { profile: prof, options: {}, number: 'N-1', mode: 'print' };
test('QR de vérification fixé en bas de chaque page (piece, module avec couverture, fiche)', () => {
  const cas = [['doc-piece', { kind: 'doc', titre: 'T', body: '# T\n\nTexte.', sign: 'dg', qr, hash: 'ABC123' }],
    ['doc-module', { titre: 'R', rows: [['a', 'b']], cover: true, qr, hash: 'ABC123' }]];
  cas.forEach(([t, doc]) => {
    const h = C.render(t, { doc }, ctx).html;
    assert.match(h, /class="xqrf"><div class="xqr"><img src="data:image\/svg\+xml/, t + ' : QR dans le pied fixé');
    assert.match(h, /@media print\{\.xm \.xqrf\{position:fixed;left:0;right:0;bottom:0/, t);
    assert.match(h, /<tfoot><tr><td><div class="xpsp">/, t + ' : espace réservé à chaque page');
  });
  const m = C.render('doc-module', { doc: { titre: 'R', rows: [['a', 'b']], cover: true, qr, hash: 'ABC' } }, ctx).html;
  assert.ok(m.indexOf('class="cov"') > m.indexOf('<table class="xpw">'), 'la couverture est dans le bloc à pied fixe (QR aussi sur la couverture)');
  assert.doesNotMatch(C.render('doc-piece', { doc: { kind: 'doc', titre: 'T', body: 'x', sign: 'dg' } }, ctx).html, /xqrf"><div class="xqr"/, 'sans QR fourni : aucun bloc QR vide');
});
