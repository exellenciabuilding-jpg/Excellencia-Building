# Ajouter un module au logiciel sans oublier l'assistant IA

Depuis V133b, l'assistant (local et en ligne) **découvre tout seul** les modules : il relit le menu à chaque question. Il n'y a plus de liste à tenir à jour à la main.

## Ce qu'il faut faire pour qu'un nouveau module soit pris en compte automatiquement
1. **Un bouton de menu** : `<button onclick="show('monId')">🛡️ Mon module</button>` (c'est déjà la convention du logiciel).
2. **Un panneau** : `<section id="monId">` avec un titre (`h2`/`h3`) et, de préférence, une phrase d'aide (`<p class="hint">…</p>`). Cette phrase sert d'explication (« à quoi sert Mon module ? »).
3. **Des données** : sauvegardées avec `exbStorage.setItem('exb_mes_donnees', JSON.stringify([ {…}, {…} ]))` (une liste d'objets). Les champs `name`, `title`, `client`, `date`, `status`… sont repris dans les réponses.

Résultat sans écrire une ligne de plus : « ouvre mon module », « à quoi sert mon module ? », « où faire une inspection ? », « quels modules ? », « combien de mes données ? », « liste des … », « derniers … », « … de Villa Kasai », « cherche partout Kasai ».

## Pour des réponses sur mesure (facultatif)
```js
EXB_AI.register({
  id: 'monId', label: 'Mon module', tab: 'monId',
  keywords: ['inspection', 'controle'],
  description: 'Contrôles de sécurité sur chantier.',
  collections: [{ key: 'exb_inspections', name: 'Inspections', aliases: ['inspection'], fields: ['site', 'date', 'statut'] }],
  answer: function (raw, q) { return { answer: 'Texte…', actions: [{ type: 'goto', tab: 'monId' }] }; }
});
```
`answer` est facultatif (mettez-le seulement pour une logique spéciale) ; il reçoit le texte brut et le texte normalisé (sans accents, en minuscules) et renvoie `{answer, actions}` ou `null`.

## À ne pas oublier
- **Fichier JS neuf** : l'ajouter à `index.html` ET à la liste de `sw.js` (hors ligne), puis changer le nom de cache `const V=` de `sw.js`.
- **Lecture seule** : l'assistant lit et ouvre ; il ne crée ni ne modifie rien dans votre module (sauf actions déjà prévues : import, approbation…).
- **Données sensibles** : les clés contenant `licen`, `session`, `pass`, `token`, `secret`, `user`, `auth`, `hash`, `backup`, `audit`… ne sont jamais lues.
- **IA en ligne** : elle reçoit automatiquement la liste des onglets (identifiant = nom) et les jeux de données ; aucune mise à jour de la fonction Supabase n'est nécessaire pour un nouveau module.
- **Contrôle** : `python3 site/tools/e2e-ia-modules.py` ajoute un faux module à chaud et vérifie que l'assistant le connaît ; `node site/tools/check.js` vérifie que le registre est bien branché.
