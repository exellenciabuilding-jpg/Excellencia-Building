# V131c — Assistant LOCAL élargi, sur la base V131b-FUSION

V131b contenait déjà l'import + approbation automatique (V128c). Cette version y ajoute l'assistant local élargi (sans clé, sans internet, lecture seule). Aucune autorisation requise, rien n'est modifié.

| Vous dites | Il répond |
|---|---|
| « planning de demain », « quelles formations cette semaine ? » | séances (heure, module, salle, formateur) |
| « solde de la caisse », « dépenses de ce mois » | recettes, dépenses, solde, dernières opérations |
| « stock bas », « stock de sable » | matériaux au minimum ; quantité d'un matériau |
| « liste des projets », « projets en cours », « budget du projet Villa » | projets, avancement, budget |
| « combien de devis ? », « devis de Marie » | nombre et total par monnaie |
| « qui est absent aujourd'hui ? » | présences enregistrées |
| « combien de certificats ? », « certificats de Jean » | certificats |
| « qui forme AutoCAD ? » | formateurs par spécialité |
| « matricule de Jean Kasongo » | matricule (apprenant, formateur, personnel) |
| « bilan général » | chiffres clés en une réponse |
| « TVA 16 % sur 1500 », « 1740 TTC TVA 16 % » | HT, TVA, TTC (16 % si le taux n'est pas précisé) |
| « 20 % de 350 », « augmentation de 10 % sur 200 » | pourcentages, remises |
| « convertis 5 m en cm », « 2 m3 en litres » | longueurs, surfaces, volumes, masses |
| « date dans 45 jours », « quel jour sommes-nous ? » | dates |

Limites : données de **cet appareil** seulement ; montants de la caisse affichés tels que saisis (pas de conversion de monnaie). « comment… ? » reste traité par l'aide intégrée, « chantiers en retard » par le pilotage des chantiers.

## Fichiers
Nouveaux : `site/exb-assistant-plus2.js`, `site/tools/test-assistant-plus2.js`.
Modifiés : `site/index.html` (balise script, branchement dans `localAI`, message d'aide), `site/sw.js` (cache `v131c-…`, fichier ajouté à la liste hors ligne), `site/tools/e2e-assistant-approbation.py` (18 contrôles au lieu de 15).
Aucun SQL. Rien à redéployer côté Supabase pour cette version.

## Vérifié
`node tools/check.js` : 546 réussis, 0 échec · `node tools/test-assistant-plus2.js` : 33/33 · `python3 tools/e2e-assistant-approbation.py` : 18/18 (navigateur, faux Supabase) · syntaxe de tous les scripts inline d'`index.html`.
**Non vérifié** : avec vos vraies données et votre vrai Supabase. Après publication : fermer complètement l'application une fois (nouveau cache).
Retour en arrière : restaurer `index.html` et `sw.js` de V131b et supprimer `exb-assistant-plus2.js`.
