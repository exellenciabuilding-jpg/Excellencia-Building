# V134 — Saisie liée : on choisit au lieu de ressaisir

Base : V133b. Un seul fichier ajouté (`site/exb-saisie-liee.js`), une balise dans `index.html`, une ligne dans `sw.js` (hors ligne), des contrôles dans `tools/check.js`, un test navigateur (`tools/e2e-saisie-liee.py`). **Aucun SQL. Aucune fonction existante remplacée ni supprimée.**

## Pourquoi
La liaison V99 relie les fiches *après* l'enregistrement, par le nom. Il restait des écrans où l'on retapait encore le client, le projet, le lieu ou le matricule. V134 agit au moment de la saisie.

## Ce qui change, écran par écran
| Écran | Avant | Maintenant |
|---|---|---|
| **Devis** (client, projet) | texte libre | liste avec recherche (sans accent ni casse), « récents » ; **le projet n'affiche que les projets du client choisi** ; choisir un projet **reprend son client** ; changer de client retire un projet qui ne lui appartient pas |
| **Bureau d'études** | texte libre | idem |
| **Métré** (en-tête du devis) | liste du navigateur (clients seulement) | client **et** projet liés ; choisir un client reprend adresse, téléphone, e-mail ; choisir un projet reprend le lieu |
| **Cartouche des plans** | client, maître d'ouvrage, lieu à retaper pour chaque projet | **repris du projet et du client** à l'ouverture (modifiable, « Enregistrer » inchangé) |
| **Pièces écrites, permis, etc.** (variables `{{client}}`, `{{moa}}`, `{{lieu}}`) | vides si le cartouche n'avait pas été rempli | complétés depuis le projet/client ; une valeur saisie à la main reste prioritaire ; le stockage du cartouche n'est jamais modifié |
| **Pièces écrites** (champ « Entreprise ») | texte libre | liste clients + fournisseurs + sous-traitants |
| **Stock** | fournisseur libre ; référence à retaper | fournisseurs déjà connus proposés ; choisir le chantier remplit la référence si elle est vide |
| **Projet** (formulaire) | — | choisir le client reprend son adresse comme lieu si vide |
| **TP / TD** (matricules) | matricule à retaper | recherche d'apprenants (plusieurs à la suite), limitée à la formation choisie ; **jamais de client dans cette liste** |
| **Impression groupée** | noms à coller | bouton « Charger les participants de cette formation » (approuvés uniquement, confirmation avant de remplacer) |
| **Import d'inscriptions, TFL** | formation / étudiant libres | formation du catalogue ; étudiant TFL déjà apprenant → coordonnées reprises |
| **Listes de participants** (évaluations, cotations, paiements, reçus, QCM, portail, documents) et listes de chantiers / personnel | longue liste à dérouler | **champ de recherche + filtre par formation** au-dessus de la liste (dès 12 entrées) |
| **Fiche participant corrigée** | l'ancien nom restait dans notes, cotations, paiements | nom repris (montants, notes, reçus et certificats déjà émis **jamais** touchés) |

À l'enregistrement d'un devis ou d'une étude, les **identifiants exacts** choisis dans la liste sont posés sur le document : deux clients homonymes ne sont plus confondus (testé : deux « Marie Kabongo », le bon est retenu).

## Règles
- Deux mondes séparés : une liste d'apprenants ne propose que des apprenants, une liste de projets que des projets/clients.
- Saisie libre toujours possible : elle est signalée en orange (« absent du fichier Clients »), jamais bloquée.
- Un champ déjà rempli n'est jamais écrasé, sauf quand **vous choisissez** une fiche.
- « Récents » : mémorisés sur l'appareil seulement (non synchronisés).
- Rien n'est créé ni supprimé automatiquement.

## Vérifié
- `python3 tools/e2e-saisie-liee.py` : 25 contrôles dans Chromium (devis, Métré, bureau d'études, cartouche, pièces, stock, TP/TD, impression groupée, filtres, noms corrigés, aucune erreur JavaScript).
- `node tools/check.js` : 568 contrôles réussis, 0 échec (565 + 3 nouveaux).
- `e2e-liaison`, `-3`, `-4`, `-edu` : sans échec.
- Le test a fait corriger un défaut de ma première version (menu qui se fermait à tort quand on passait vite d'un champ à l'autre).

## Non vérifié / limites
- `tools/e2e-smoke.py` s'arrête sur un délai dépassé (`button[data-a="v"]`) : **le même arrêt existe dans l'archive V133b d'origine**, il n'est pas causé par V134. Non corrigé.
- Non testé sur téléphone réel ni avec un vrai Supabase.
- Sur iPhone/Safari, une option filtrée apparaît grisée au lieu d'être masquée (limite du navigateur).
- Écrans dont la saisie passe par une fenêtre `prompt()` ou des formulaires que je n'ai pas ouverts un par un (tâches terrain, réception de chantier, permis, paie…) : les listes « Chantier » y étaient déjà des sélecteurs ; les champs texte libre éventuels ne sont pas encore branchés.
- Pour ajouter un autre champ : `EXBSL.attach(document.getElementById('monChamp'), {kind:'client'})` (types : `client`, `project`, `participant`, `formation`, `supplier`, `company`).

## Retirer V134
Supprimer la balise `<script src="exb-saisie-liee.js">` dans `index.html` : tout revient à V133b (aucune donnée n'a changé de forme).
