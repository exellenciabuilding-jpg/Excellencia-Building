#!/usr/bin/env node
/* Test du lot 8 (réception intelligente) : VRAI moteur + lots 7 et 8 + réception simulée (EXB_INBOX, approveEntity).
 * Usage (depuis le dossier du site) :  node tools/test-intelligence-8.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.resolve(__dirname, '..'), R = f => fs.readFileSync(path.join(root, f), 'utf8');
let pass = 0, fail = 0;
const ok = (c, m, d) => { if (c) { pass++; console.log('  OK   ' + m); } else { fail++; console.log('  FAIL ' + m + (d ? ' — ' + d : '')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
function mkStorage(init) { const m = Object.assign({}, init || {}); return { _m: m, get length() { return Object.keys(m).length; }, key: i => Object.keys(m)[i] || null, getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } }; }
const iso = (min) => new Date(Date.now() - min * 60000).toISOString();
const J = (S, k) => JSON.parse(S.getItem(k) || 'null');

function session(S, rowsByType, opt) {
  opt = opt || {}; const ROWS = { insc: [], tptd: [], form: [], cli: [], pers: [], soft: [], btp: [] }; Object.assign(ROWS, rowsByType || {});
  const doc = { readyState: 'complete', hidden: false, head: { appendChild() {} }, body: { appendChild() {} }, documentElement: {}, getElementById: () => null,
    createElement: () => { const el = { style: {}, handlers: {}, inner: { innerHTML: '' }, setAttribute() {}, appendChild() {}, remove() { win.__removed = true; }, addEventListener(t, f) { el.handlers[t] = f; }, querySelector: () => el.inner }; Object.defineProperty(el, 'innerHTML', { set(v) { el._h = v; }, get() { return el._h; } }); win.__els.push(el); return el; }, querySelectorAll: () => [], addEventListener() {} };
  const calls = { importRows: [], approve: [] }; let n = 0;
  const win = { __els: [], localStorage: S, document: doc, location: { origin: 'https://x.test', href: 'https://x.test/' }, addEventListener() {}, notify() {}, URL, Date, JSON, Math, Blob: function () {},
    setTimeout: () => 0, setInterval: () => 0, clearInterval() {}, clearTimeout() {} };
  win.window = win;
  win.EXB_INBOX = { on: () => opt.offline !== true, reload: () => Promise.resolve(),
    rows: t => ROWS[t].map(r => ({ t, id: r.id, created_at: r.created_at, imported: !!r.imported, hasPhoto: false, d: JSON.parse(JSON.stringify(r.d)) })),
    importRows: async (t, ids) => { calls.importRows.push([t, ids.slice()]); let c = 0;
      ROWS[t].filter(r => !r.imported && ids.indexOf(String(r.id)) >= 0).forEach(r => { r.imported = true; c++;
        const arr = J(S, { insc: 'exb_participants', form: 'exb_trainers', pers: 'exb_hr', cli: 'exb_clients', tptd: 'exb_tp_td_requests' }[t]) || [];
        const rec = Object.assign({}, r.d, { approval_status: 'EN ATTENTE', source: 'INSCRIPTION_EN_LIGNE', participant_id: 'PART-' + (++n), trainer_id: 'FORMT-' + n, id: 'HR-' + n }); arr.push(rec);
        S.setItem({ insc: 'exb_participants', form: 'exb_trainers', pers: 'exb_hr', cli: 'exb_clients', tptd: 'exb_tp_td_requests' }[t], JSON.stringify(arr)); });
      return c; } };
  win.approveEntity = (type, id) => { calls.approve.push([type, id]); const key = { participant: 'exb_participants', trainer: 'exb_trainers', hr: 'exb_hr' }[type], idf = { participant: 'participant_id', trainer: 'trainer_id', hr: 'id' }[type];
    const arr = J(S, key) || [], o = arr.filter(x => x[idf] === id)[0]; if (!o) return false; o.approval_status = 'APPROUVE'; o.matricule = 'M-' + id; S.setItem(key, JSON.stringify(arr)); return true; };
  const ctx = vm.createContext(win);
  vm.runInContext(R('exb-intelligence.js'), ctx); vm.runInContext(R('exb-intelligence-7.js'), ctx); vm.runInContext(R('exb-intelligence-8.js'), ctx);
  const I = win.EXBI; I.confirm = () => Promise.resolve(true);
  return { win, I, ROWS, calls };
}
const row = (id, d, min) => ({ id, created_at: iso(min == null ? 5 : min), imported: false, d });
const good = (i, extra) => row('r' + i, Object.assign({ name: 'Apprenant ' + i, phone: '+2577900' + (1000 + i), email: 'a' + i + '@x.com', training: 'Autocad', insc_payee: true }, extra || {}));
const cfgSet = (S, c) => S.setItem('exb_perm_inbox', JSON.stringify(c));

(async () => {
  console.log('\n# 1. Vérification des demandes');
  let S = mkStorage({ exb_participants: JSON.stringify([{ participant_id: 'P0', name: 'Déjà Là', phone: '+25779000001', approval_status: 'APPROUVE', matricule: 'M0' }]) });
  let s = session(S, { insc: [good(1), good(2, { phone: '' }), good(3, { name: '<img src=x onerror=alert(1)>' }), good(4, { phone: '+25779000001' }), good(5, { email: 'pas-un-mail' }), good(6, { phone: '+25779001001' })],
    tptd: [row('t1', { matricule: 'INCONNU', work_type: 'TP' }), row('t2', { matricule: 'M0', work_type: 'TP Autocad' })] });
  s.I.intake.scan(); const by = {}; ['insc', 'tptd'].forEach(t => s.I.intake.scan() && 0);
  const items = (() => { s.I.intake.scan(); return null; })();
  const vet = (t, r) => s.I.intake.vet(t, r, { P: JSON.parse(S.getItem('exb_participants')), T: [], C: [], H: [], seen: {}, flood: {} });
  ok(vet('insc', s.ROWS.insc[0]).ok, 'demande complète : conforme');
  ok(/téléphone/.test(vet('insc', s.ROWS.insc[1]).why.join()), 'téléphone manquant détecté');
  const inj = vet('insc', s.ROWS.insc[2]); ok(!inj.ok && inj.sec, 'code suspect : non conforme + marqué sécurité');
  ok(/doublon/.test(vet('insc', s.ROWS.insc[3]).why.join()), 'doublon avec un apprenant existant détecté');
  ok(/e-mail/.test(vet('insc', s.ROWS.insc[4]).why.join()), 'e-mail invalide détecté');
  ok(/matricule introuvable/.test(vet('tptd', s.ROWS.tptd[0]).why.join()), 'TP/TD : matricule inconnu détecté');
  ok(vet('tptd', s.ROWS.tptd[1]).ok, 'TP/TD : matricule approuvé accepté');
  const ctx = { P: [], T: [], C: [], H: [], seen: {}, flood: {} }; s.I.intake.vet('insc', s.ROWS.insc[0], ctx);
  ok(/plusieurs fois/.test(s.I.intake.vet('insc', good(1, { name: 'Autre' }), ctx).why.join()), 'même téléphone envoyé deux fois : détecté');
  const flood = Array.from({ length: 16 }, (_, i) => good(100 + i)); const sf = session(mkStorage(), { insc: flood }); sf.I.intake.scan();
  ok(sf.I.intake.pending(true) === 0 && sf.I.intake.pending(false) === 16, 'afflux (16 demandes en 10 min) : aucune n’est « conforme »');

  console.log('\n# 2. Par défaut : rien d’automatique');
  S = mkStorage(); s = session(S, { insc: [good(1), good(2)] }); s.I.intake.scan(); s.I.intake.tick(); await sleep(30);
  ok(s.calls.importRows.length === 0 && s.calls.approve.length === 0, 'mode « Demander » par défaut : aucun import ni approbation sans vous');
  ok(s.I.recommendations().some(r => /2 demande\(s\) en attente \(2 conforme/.test(r.t)), 'recommandation « 2 demandes en attente (2 conformes) »');

  console.log('\n# 3. Traitement validé par vous (importer + approuver)');
  s.I.intake.scan(); const ids = ['r1', 'r2']; let res = await s.I.intake.process('insc', ids, true, 'manuel');
  ok(res.imp === 2 && res.app === 2 && s.calls.approve.length === 2, '2 importées, 2 approuvées par approveEntity');
  ok(J(S, 'exb_participants').every(p => p.approval_status === 'APPROUVE' && p.matricule), 'fiches approuvées avec matricule (via la fonction existante)');
  const log = J(S, 'exb_ai_log'); ok(log.length === 2 && log.every(l => !/Apprenant \d|a1@x|2577900/.test(JSON.stringify(l))), 'journal exb_ai_log écrit, sans nom ni téléphone');

  console.log('\n# 4. Mode automatique : seulement conforme (+ payé)');
  S = mkStorage(); cfgSet(S, { imp: { insc: 'auto' }, app: { insc: 'auto' }, paid: true, max: 10 });
  s = session(S, { insc: [good(1), good(2, { insc_payee: false }), good(3, { phone: '' }), good(4, { name: '<script>x</script>' })] });
  s.I.intake.scan(); s.I.intake.tick(); await sleep(60);
  ok(JSON.stringify(s.calls.importRows[0]) === JSON.stringify(['insc', ['r1', 'r2']]), 'seules les 2 conformes sont importées (pas la 3 incomplète ni la 4 piégée)', JSON.stringify(s.calls.importRows));
  ok(s.calls.approve.length === 1, 'une seule approuvée : celle dont l’inscription est payée', JSON.stringify(s.calls.approve));
  ok(J(S, 'exb_participants').filter(p => p.approval_status === 'APPROUVE').length === 1 && J(S, 'exb_participants').filter(p => p.approval_status === 'EN ATTENTE').length === 1, 'l’autre reste « EN ATTENTE » pour vous');
  ok(s.I.findings().some(f => f.rule === 'inbox.suspect' && /code suspect/.test(f.msg)), 'la demande piégée remonte comme constat de sécurité');

  console.log('\n# 5. Plafond horaire');
  S = mkStorage(); cfgSet(S, { imp: { insc: 'auto' }, app: { insc: 'auto' }, paid: true, max: 3 });
  s = session(S, { insc: Array.from({ length: 6 }, (_, i) => good(10 + i)) }); s.I.intake.scan(); s.I.intake.tick(); await sleep(60);
  ok(s.calls.approve.length === 3, '6 conformes : 3 approuvées puis plafond atteint (max 3/h)', String(s.calls.approve.length));
  ok(s.I.findings().some(f => /Plafond/.test(f.msg)), 'alerte « plafond atteint » (afflux inhabituel)');

  console.log('\n# 6. Garde-fous des réglages');
  S = mkStorage(); cfgSet(S, { imp: { form: 'auto', pers: 'auto', insc: 'ask' }, app: { form: 'auto', pers: 'auto', insc: 'auto' } });
  s = session(S, {}); const c = s.I.intake.config();
  ok(c.app.form === 'ask' && c.app.pers === 'ask', 'approbation automatique des formateurs/personnel refusée (forcée à « Demander »)');
  ok(c.app.insc === 'ask', 'approbation automatique impossible si l’import n’est pas automatique');
  S = mkStorage(); cfgSet(S, { imp: { insc: 'auto' }, app: { insc: 'auto' } }); S.setItem('exb_ai_perm', JSON.stringify({ on: false }));
  s = session(S, { insc: [good(1)] }); s.I.intake.scan(); s.I.intake.tick(); await sleep(40);
  ok(s.calls.importRows.length === 0, 'assistant désactivé : rien d’automatique');
  S = mkStorage(); cfgSet(S, { imp: { insc: 'auto' } }); S.setItem('exb_ai_perm', JSON.stringify({ on: true, lv: { import: 'forbid' } }));
  s = session(S, { insc: [good(1)] }); s.I.intake.scan(); s.I.intake.tick(); await sleep(40);
  ok(s.calls.importRows.length === 0, '« Interdit » dans Assistant IA › import : respecté');
  S = mkStorage(); cfgSet(S, { imp: { insc: 'auto' } }); s = session(S, { insc: [good(1)] }, { offline: true }); s.I.intake.tick(); await sleep(40);
  ok(s.calls.importRows.length === 0, 'non connecté à la réception : rien ne se passe, sans erreur');

  console.log('\n# 7. Formateurs : import auto possible, approbation par vous');
  S = mkStorage(); cfgSet(S, { imp: { form: 'auto' }, app: { form: 'auto' } });
  s = session(S, { form: [row('f1', { name: 'Jean Formateur', phone: '+25779123456' })] }); s.I.intake.scan(); s.I.intake.tick(); await sleep(60);
  ok(s.calls.importRows.length === 1 && s.calls.approve.length === 0, 'formateur importé, jamais approuvé automatiquement');

  console.log('\n# 8. Assistant local et cohérence avec le lot 7');
  S = mkStorage(); s = session(S, {});
  cfgSet(S, { imp: { insc: 'ask' } }); s.I.intake.config(); const sA = session(S, {}); sA.I.sec.accept('exb_perm_inbox');
  const sB = session(S, {}); ok(!sB.I.findings().some(f => f.rule === 'sec.integrite' && /exb_perm_inbox/.test(f.msg)), 'réglage de la réception validé auprès du lot 7 : pas de fausse alerte d’intégrité');
  S.setItem('exb_perm_inbox', JSON.stringify({ imp: { insc: 'auto' }, app: { insc: 'auto' } }));
  const sC = session(S, {}); ok(sC.I.findings().some(f => f.rule === 'sec.integrite' && /exb_perm_inbox/.test(f.msg)), 'réglage de la réception modifié hors application : alerte du lot 7');

  console.log('\n# 9. Interface (fenêtre, échappement, clic)');
  S = mkStorage(); s = session(S, { insc: [good(1), good(2, { name: '<b onclick=x>Piégé</b>', phone: '' })] });
  s.I.intake.open(); await sleep(20); const el = s.win.__els[s.win.__els.length - 1], html = el.inner.innerHTML;
  ok(/Réception intelligente/.test(el._h) && /2 en attente \(1 conforme\)/.test(html), 'fenêtre ouverte : « 2 en attente (1 conforme) »', html.slice(0, 200));
  ok(!/<b onclick=x>/.test(html) && /&lt;b onclick=x&gt;/.test(html), 'nom piégé affiché échappé (jamais interprété comme HTML)');
  ok(/Importer \+ approuver/.test(html) && /Plafond d’approbations/.test(html), 'boutons et réglages présents');
  const btn = { getAttribute: a => ({ 'data-a': 'ok', 'data-t': 'insc', 'data-ap': '1' }[a]) };
  el.handlers.click({ target: { closest: () => btn } }); await sleep(60);
  ok(s.calls.importRows.length === 1 && s.calls.approve.length === 1 && J(S, 'exb_participants').length === 1, 'clic « Importer + approuver » : 1 importée et approuvée, la piégée reste');
  const sel = { getAttribute: a => ({ 'data-s': 'max', 'data-t': null }[a]), value: '5' }; el.handlers.change({ target: sel });
  ok(J(S, 'exb_perm_inbox').max === 5, 'réglage enregistré depuis la fenêtre');
  console.log('\n' + pass + ' réussis, ' + fail + ' échecs'); process.exit(fail ? 1 : 0);
})();
