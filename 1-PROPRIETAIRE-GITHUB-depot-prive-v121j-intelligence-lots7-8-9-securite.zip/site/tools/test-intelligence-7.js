#!/usr/bin/env node
/* Test du lot 7 (sécurité) : charge le VRAI exb-intelligence.js + exb-intelligence-7.js dans un navigateur simulé.
 * Usage (depuis le dossier du site) :  node tools/test-intelligence-7.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.resolve(__dirname, '..'), R = f => fs.readFileSync(path.join(root, f), 'utf8');
let pass = 0, fail = 0;
const ok = (c, m, d) => { if (c) { pass++; console.log('  OK   ' + m); } else { fail++; console.log('  FAIL ' + m + (d ? ' — ' + d : '')); } };

function mkStorage(init) {
  const m = Object.assign({}, init || {});
  return { _m: m, get length() { return Object.keys(m).length; }, key: i => Object.keys(m)[i] || null,
    getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; }, clear: () => { Object.keys(m).forEach(k => delete m[k]); } };
}
/* une « session » = un chargement de page ; le stockage persiste d'une session à l'autre */
function session(store, pre) {
  const timers = [], listeners = {}, doc = {
    readyState: 'complete', hidden: false, body: { appendChild() {} }, documentElement: {},
    getElementById: () => null, createElement: () => ({ style: {}, setAttribute() {}, appendChild() {}, remove() {} }),
    querySelectorAll: () => [], addEventListener() {} };
  const win = { localStorage: store, document: doc, location: { origin: 'https://exemple.test', href: 'https://exemple.test/' },
    addEventListener: (t, f) => { (listeners[t] = listeners[t] || []).push(f); }, notify() {}, URL, Date, JSON, Math, Blob: function () {},
    setTimeout: (f, t) => { timers.push(f); return timers.length; }, setInterval: () => 0, clearInterval() {}, clearTimeout() {} };
  win.window = win; win.self = win; win.document = doc; win.URL = URL; win.location = win.location;
  const ctx = vm.createContext(win);
  if (pre) pre(win);
  vm.runInContext(R('exb-intelligence.js'), ctx, { filename: 'exb-intelligence.js' });
  vm.runInContext(R('exb-intelligence-7.js'), ctx, { filename: 'exb-intelligence-7.js' });
  const I = win.EXBI; I.confirm = () => Promise.resolve(true);
  return { win, I, listeners, run: () => { I.run(); return I.findings().filter(f => f.mod && f.mod.indexOf('Sécurité') === 0); } };
}
const sec = (arr, rule) => arr.filter(f => f.rule === rule);
const cleanClients = n => JSON.stringify(Array.from({ length: n }, (_, i) => ({ id: 'c' + i, name: 'Client ' + i, phone: '+25779000' + (100 + i) })));
const nowIso = (minAgo) => new Date(Date.now() - minAgo * 60000).toISOString();

console.log('\n# 1. Données saines — aucune fausse alerte');
let S = mkStorage({ exb_clients: cleanClients(12), exb_pass_h: 'abc', exb_ai_perm: '{"a":1}', exb_lic_token: 'T1', exb_last_backup: String(Date.now()),
  exb_cash: JSON.stringify(Array.from({ length: 10 }, (_, i) => ({ id: 'k' + i, amount: 100 + i, date: '2026-01-01' }))),
  exb_audit: JSON.stringify([{ at: nowIso(1), action: 'CONNEXION', details: 'ok' }, { at: nowIso(30), action: 'CONNEXION', details: 'ok' }]),
  exb_projects: JSON.stringify([{ id: 'p1', name: 'Notes online = oui, condition = 5', client: 'x' }]) });
let s1 = session(S); let f = s1.run();
ok(f.length === 0, 'première analyse : 0 constat de sécurité', JSON.stringify(f.map(x => x.msg)));
ok(s1.I.sec.score() === 100, 'indice de sécurité = 100');
ok(!!S.getItem('exb_intel_sec_base') && !/abc|T1/.test(S.getItem('exb_intel_sec_base')), 'référence enregistrée sans aucune valeur sensible');
let s1b = session(S); f = s1b.run();
ok(f.length === 0, 'deuxième session sans changement : 0 constat');

console.log('\n# 2. Réglage protégé modifié entre deux sessions');
S.setItem('exb_ai_perm', '{"a":2}'); S.setItem('exb_lic_token', 'T-PIRATE');
let s2 = session(S); f = s2.run();
ok(sec(f, 'sec.integrite').length === 2, '2 réglages modifiés détectés (assistant + licence)', JSON.stringify(f.map(x => x.msg)));
ok(f.every(x => !/T-PIRATE|"a":2/.test(x.msg)), 'aucune valeur sensible dans les messages');
const fx = sec(f, 'sec.integrite').filter(x => /licence/.test(x.msg))[0];
ok(fx && fx.fix && fx.fix.label === 'Valider ce changement', 'correctif « Valider ce changement » proposé');
fx.fix.run().then(() => {
  const f2 = s2.run(); ok(sec(f2, 'sec.integrite').length === 1, 'après validation : 1 seul constat reste (assistant)');
  part3();
});

function part3() {
  console.log('\n# 3. Réglage supprimé');
  S.removeItem('exb_pass_h'); let s3 = session(S); let f3 = s3.run();
  ok(sec(f3, 'sec.integrite').some(x => /supprimé/.test(x.msg) && /identifiants/.test(x.msg)), 'suppression du mot de passe détectée');

  console.log('\n# 4. Horloge reculée');
  const b = JSON.parse(S.getItem('exb_intel_sec_base')); b.clock = Date.now() + 3 * 3600000; S.setItem('exb_intel_sec_base', JSON.stringify(b));
  let s4 = session(S); let f4 = s4.run();
  ok(sec(f4, 'sec.horloge').some(x => x.sev === 'erreur' && /horloge/i.test(x.msg)), 'horloge reculée de ~3 h détectée (erreur)');
  b.clock = Date.now() - 1000; S.setItem('exb_intel_sec_base', JSON.stringify(b));

  console.log('\n# 5. Suppression massive de fiches');
  const bb = JSON.parse(S.getItem('exb_intel_sec_base')); bb.counts.exb_clients = 12; S.setItem('exb_intel_sec_base', JSON.stringify(bb));
  S.setItem('exb_clients', cleanClients(4));
  let s5 = session(S); let f5 = s5.run(); const m = sec(f5, 'sec.suppression');
  ok(m.length === 1 && /8 fiche/.test(m[0].msg) && m[0].sev === 'erreur', '12 → 4 clients : suppression massive signalée', JSON.stringify(m.map(x => x.msg)));
  m[0].fix.run(); ok(sec(s5.run(), 'sec.suppression').length === 0, 'correctif « C’est normal » accepté');
  S.setItem('exb_clients', cleanClients(11)); ok(sec(session(S).run(), 'sec.suppression').length === 0, 'suppression de 1 fiche : pas d’alerte');

  console.log('\n# 6. Connexions : rafale d’échecs puis réussite');
  const au = []; for (let i = 0; i < 6; i++) au.unshift({ at: nowIso(10 - i), action: 'CONNEXION_ÉCHEC', details: 'Tentative ' + (i + 1) });
  S.setItem('exb_audit', JSON.stringify(au)); let f6 = session(S).run();
  ok(sec(f6, 'sec.connexion').some(x => /6 échecs/.test(x.msg)), '6 échecs en 15 min : alerte');
  au.unshift({ at: nowIso(1), action: 'CONNEXION', details: 'ok' }); S.setItem('exb_audit', JSON.stringify(au));
  f6 = session(S).run(); ok(sec(f6, 'sec.connexion').some(x => /réussi juste après 6/.test(x.msg)), 'connexion réussie après 6 échecs : alerte');
  for (let i = 0; i < 5; i++) au.unshift({ at: nowIso(0.5), action: 'CONNEXION_ÉCHEC', details: 'x' }); S.setItem('exb_audit', JSON.stringify(au));
  ok(sec(session(S).run(), 'sec.connexion').some(x => x.sev === 'erreur'), '11 échecs : gravité erreur');
  S.setItem('exb_audit', JSON.stringify([{ at: nowIso(1), action: 'CONNEXION', details: '' }]));

  console.log('\n# 7. Journal d’audit vidé / désordonné / futur');
  const bc = JSON.parse(S.getItem('exb_intel_sec_base')); bc.audN = 100; S.setItem('exb_intel_sec_base', JSON.stringify(bc));
  let f7 = session(S).run(); ok(sec(f7, 'sec.audit').some(x => /vidé/.test(x.msg)), 'journal passé de 100 à 1 entrée : détecté');
  bc.audN = 1; S.setItem('exb_intel_sec_base', JSON.stringify(bc));
  S.setItem('exb_audit', JSON.stringify([{ at: nowIso(60), action: 'A' }, { at: nowIso(5), action: 'B' }]));
  ok(sec(session(S).run(), 'sec.audit').some(x => /désordre/.test(x.msg)), 'entrées dans le désordre : détecté');
  S.setItem('exb_audit', JSON.stringify([{ at: new Date(Date.now() + 86400000).toISOString(), action: 'A' }]));
  ok(sec(session(S).run(), 'sec.horloge').some(x => /futur/.test(x.msg)), 'entrée d’audit datée du futur : détectée');
  S.setItem('exb_audit', JSON.stringify([{ at: nowIso(1), action: 'CONNEXION' }]));

  console.log('\n# 8. Injection dans les fiches');
  const cl = JSON.parse(cleanClients(11)); cl[3].name = '<img src=x onerror=alert(1)>'; cl[5].notes = 'voir javascript:alert(1)'; cl[7].id = "c7');alert(1);//"; cl[8].name = 'Café online = ok';
  S.setItem('exb_clients', JSON.stringify(cl)); const bd = JSON.parse(S.getItem('exb_intel_sec_base')); bd.counts.exb_clients = 11; S.setItem('exb_intel_sec_base', JSON.stringify(bd));
  const f8 = session(S).run(), inj = sec(f8, 'sec.injection');
  ok(inj.some(x => /2 fiche\(s\) contiennent du code/.test(x.msg) && x.sev === 'erreur'), '2 fiches avec code suspect détectées (et pas la fiche « online = ok »)', JSON.stringify(inj.map(x => x.msg)));
  ok(inj.some(x => /1 identifiant/.test(x.msg)), 'identifiant piégé détecté');
  ok(f8.every(x => !/alert\(1\)/.test(x.msg)), 'la charge piégée n’est jamais recopiée dans le message');
  S.setItem('exb_clients', cleanClients(11));

  console.log('\n# 9. Montants aberrants et factures payées modifiées');
  const cash = JSON.parse(S.getItem('exb_cash')); cash.push({ id: 'kx', amount: 50000, date: '2026-01-02' }); S.setItem('exb_cash', JSON.stringify(cash));
  ok(sec(session(S).run(), 'sec.montants').some(x => /20 fois/.test(x.msg)), 'écriture de caisse 50 000 vs médiane ~105 : signalée');
  S.setItem('exb_invoices', JSON.stringify([{ id: 'i1', no: 'F-1', lines: [{ q: 1, pu: 100 }], tva: 0, payments: [{ amount: 100 }] }]));
  S.setItem('exb_intel_history', JSON.stringify([{ at: nowIso(1), op: 'modification', col: 'exb_invoices', l: 'Factures', id: 'i1', name: 'F-1', fields: [{ f: 'lines', a: '[]', b: '[]' }] }]));
  ok(sec(session(S).run(), 'sec.historique').some(x => /déjà payée puis modifiée/.test(x.msg)), 'facture payée puis modifiée : signalée');
  S.setItem('exb_intel_history', JSON.stringify(Array.from({ length: 26 }, (_, i) => ({ at: nowIso(0.2), op: 'modification', col: 'exb_clients', l: 'Clients', id: 'c' + i, name: 'x', fields: [] }))));
  ok(sec(session(S).run(), 'sec.historique').some(x => /26 modifications/.test(x.msg)), 'rafale de 26 modifications en 2 min : signalée');
  S.setItem('exb_intel_history', JSON.stringify(Array.from({ length: 6 }, (_, i) => ({ at: nowIso(0.2), op: 'suppression', col: 'exb_clients', l: 'Clients', id: 'c' + i, name: 'x', fields: [] }))));
  ok(sec(session(S).run(), 'sec.historique').some(x => /6 suppressions/.test(x.msg) && x.sev === 'erreur'), '6 suppressions en 2 min : erreur');
  S.setItem('exb_intel_history', '[]'); S.removeItem('exb_invoices');

  console.log('\n# 10. Autre onglet, assistant local, rapport, recommandations');
  let s10 = session(S, w => { w.localAI = () => ({ answer: 'ancien', actions: [] }); });
  s10.listeners.storage[0]({ key: 'exb_ai_perm' });
  ok(s10.I.sec.journal().some(l => /autre onglet/.test(l.msg)), 'modification depuis un autre onglet journalisée');
  s10.win.localAI.__sec || (s10.listeners = s10.listeners); /* le branchement se fait par minuterie : on force */
  vm.runInContext('0', vm.createContext({}));
  const rep = s10.I.sec.report(); ok(/Rapport de sécurité/.test(rep) && !/T-PIRATE/.test(rep), 'rapport de sécurité HTML généré, sans valeur sensible');
  ok(s10.I.recommendations().some(r => /Indice de sécurité/.test(r.t)), 'recommandation « indice de sécurité » présente');
  S.removeItem('exb_last_backup'); ok(session(S).I.recommendations().some(r => /sauvegarde/i.test(r.t)), 'recommandation de sauvegarde si aucune récente');

  console.log('\n# 11. Script étranger (simulé) et robustesse');
  const s11 = session(S, w => { w.MutationObserver = function (cb) { w.__cb = cb; this.observe = () => {}; }; });
  const fake = { nodeType: 1, tagName: 'SCRIPT', src: 'https://pirate.example/x.js', querySelectorAll: () => [] };
  s11.win.__cb([{ addedNodes: [fake] }]);
  ok(sec(s11.run(), 'sec.dom').length === 1, 'script d’une origine inconnue détecté (erreur)');
  s11.win.__cb([{ addedNodes: [{ nodeType: 1, tagName: 'SCRIPT', src: 'https://exemple.test/a.js', querySelectorAll: () => [] }] }]);
  ok(sec(s11.run(), 'sec.dom').length === 1, 'script de votre propre site : pas d’alerte supplémentaire');
  const bad = mkStorage({ exb_intel_sec_base: '{corrompu', exb_intel_sec_log: 'nimporte quoi', exb_audit: 'xx', exb_clients: '{"pas":"un tableau"}', exb_cash: '[{"amount":"abc"},{"amount":null}]' });
  let thrown = null, fb; try { fb = session(bad).run(); } catch (e) { thrown = e; }
  ok(!thrown, 'données corrompues (référence, journal, audit, fiches) : aucune exception', thrown && thrown.message);

  console.log('\n' + pass + ' réussis, ' + fail + ' échecs'); process.exit(fail ? 1 : 0);
}
