# V119e — Fusion V118 → V119d : un seul moteur pour les anciens modules

## Ce qui a été repris de V118
V118 et V119d contenaient deux moteurs documentaires différents. **Le moteur de V119d est conservé tel quel.** De V118, on reprend ce qui manquait à V119d :
le branchement des circuits PDF historiques sur le moteur (V119d ne branchait que le planning des Séances).

| Circuit historique | Avant (V119d) | Maintenant |
|---|---|---|
| `EXBDocs.build` — devis, factures, reçus du métré | écrivain local seul | **moteur** (modèle `doc-devis`) avec profil de l'organisation ; repli local |
| `EXBPdf.make` — ~22 appels (bon de commande, rapport de chantier, décompte, PV, fiches…) | écrivain local seul | **moteur** (modèle `doc-module`) ; repli local |
| `EXBPrint.full` — impression d'un HTML complet | absent | ajouté (comportement de `EXBPrint.html` inchangé) |

Aucun module appelant n'est modifié. Sans serveur documentaire, hors connexion, ou si le serveur échoue : l'ancien écrivain local produit le PDF comme avant.

## Pont avec le logiciel (reprise de V118, fichier `docengine/bridge.js`)
- `exbDocument(modèle, données, options)` : point d'entrée unique pour tous les modules (impression, `mode:'blob'`, `mode:'html'`).
- Les impressions `EXBPrint.html` (paiements, Gantt, QCM, reçus TFL, plans, cartes…) et les PDF-captures `savePdf` sont inscrits à l'historique commun ; leur mise en page reste celle de chaque module.
- Option « habillage » (désactivée par défaut) : `EXBDocHabillage(true)` ajoute l'en-tête du profil aux impressions.
- Retrait : supprimer la balise `<script>` de `bridge.js`.

## Fichiers
Nouveaux : `site/docengine/bridge.js` · `site/docengine/templates-modules.js` (modèles `doc-devis`, `doc-module`, masqués du catalogue) · `site/docengine/legacy-adapters.js` (`window.EXBDocEngine`).
Modifiés : `exb-pdf.js` (`make` → `makeLocal` + point d'entrée), `exb-docs.js` (`build` → `buildLocal` + point d'entrée), `exb-print.js` (`EXBPrint.full`), `docengine/core.js` (modèles « passthrough », champ `hidden`, titre), `docengine/client.js` (catalogue sans modèles masqués), `docengine-server/lib/service.js` (charge les nouveaux modèles, catalogue), `index.html`, `centre-documentaire.html`, `formulaires-publics.html`, `sw.js` (cache hors ligne).
Conservés de V119d (non écrasés par V118) : QR sur la page de garde, `EXB_BRAND`, `exbLogoSrc`, Pièces écrites V119, identité entreprise.

## Non repris de V118 (doublons de V119d)
Le Centre documentaire de V118 (`centre-documentaire.html`, `documents-publics.html`, `docengine/exb-docengine*.js`, `docengine/server/`, migration SQL V118) : V119d a son propre équivalent, plus complet (serveur `docengine-server/`, 9 rubriques, migration `migration-v118-moteur-documentaire.sql`). Les deux ne peuvent pas coexister (mêmes URL, mêmes tables).
Aussi non repris : le bouton flottant 📄 (V119d a déjà « Ouvrir le Centre documentaire » dans Paramètres, et le bouton gênerait les boutons déplaçables).

## Différence visible (avec le serveur)
Devis/factures/reçus et pièces des modules suivent la mise en page du moteur (bleu/or, en-tête et pied du profil, signature + cachet du profil, numéro de page) au lieu de l'ancien écrivain. Montants, QR de vérification et codes sont identiques. Le numéro de document reste celui des modules (la numérotation du moteur n'est pas consommée).

## Tests
- `node tools/check.js` : 509 contrôles, 0 échec (identique à V119d).
- Serveur, test de bout en bout avec Chromium : devis (2 pages avec garde), facture avec acompte/solde, reçu, pièce de module, historique commun, catalogue masqué, charge > 6 Mo refusée, lecteur refusé. HTML injecté dans les données échappé.
- Adaptateur navigateur : repli local sans serveur, passage par le moteur avec serveur, repli automatique si le serveur échoue, lignes `{k,c}` et filigrane transmis.
- Non exécutable ici : `npm test` complet du serveur (le paquet `pdfjs-dist` est absent et le réseau coupé ; mêmes échecs sur la V119d d'origine). Non testé : Supabase réel, APK, installateur Windows.
