/* Excellencia Building — Cartes de travail / cartes de membre + option « contour » (même style que la page de garde des devis).
 * 1) EXB_FRAME : contour (cadre) activable ou non — Studio libre, deux affiches Excellencia, cartes.
 * 2) Onglet « Cartes » (Affiches) : une carte est créée AUTOMATIQUEMENT dès qu'une personne reçoit son matricule
 *    (participant, formateur, personnel, étudiant ou encadreur TFL) ; carte de travail pour le personnel, carte de membre
 *    pour les autres catégories. Création manuelle possible pour un autre membre (matricule généré comme les autres).
 * Données : clés exb_cartes_travail, exb_cartes_opts, exb_poster_frame (stockage de l'appareil). Aucun SQL.
 * Pour retirer : supprimer la balise <script src="exb-carte-travail.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_CARTES) return;
  var K_CARDS = 'exb_cartes_travail', K_OPT = 'exb_cartes_opts', K_FR = 'exb_poster_frame';
  var $ = function (i) { return d.getElementById(i); };
  function S() { try { return typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) { return null; } }
  function rd(k, def) { try { var v = (S() && S().getItem(k)) || localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function wr(k, v) { try { if (S()) S().setItem(k, JSON.stringify(v)); else localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function note(t, k, ms) { try { w.notify && w.notify(t, k || 'ok', ms || 4000); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function css(id, txt) { if ($(id)) return; var s = d.createElement('style'); s.id = id; s.textContent = txt; d.head.appendChild(s); }
  function download(blob, name) { var u = URL.createObjectURL(blob), a = d.createElement('a'); a.href = u; a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 5000); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function addYears(iso, n) { var t = new Date(iso + 'T00:00:00'); t.setFullYear(t.getFullYear() + n); return t.toISOString().slice(0, 10); }
  function frDate(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (iso || '—'); }
  function brand() {
    var I = null; try { I = w.EXBId && w.EXBId.get ? w.EXBId.get() : null; } catch (e) {}
    I = I || {};
    var has = !!I.name; return { name: I.name || 'Excellencia Building', tagline: has ? (I.tagline || '') : 'Ingénierie & Construction', phone: has ? (I.phone || '') : '+243 810 644 554', email: has ? (I.email || '') : 'Excellenciabuilding@gmail.com', address: has ? (I.address || '') : 'Kinshasa, RDC', logo: I.logo || 'icon-192.png', dg: I.dg || '', dgRole: I.dgRole || 'Directeur Général' };
  }

  /* =====================================================================
   *  1) CONTOUR (cadre) — mêmes filets que la page de garde des devis : bleu épais, or, bande or pâle, filet fin
   * ===================================================================== */
  var FRAME_STYLES = { classique: 'Classique bleu et or (comme les devis)', or: 'Double filet or', simple: 'Filet simple', fin: 'Filet fin' };
  function frameDefaults() { return { on: false, style: 'classique', c1: '#12305e', c2: '#c9a227' }; }
  function frameNorm(o) { var f = frameDefaults(); o = o || {}; return { on: !!o.on, style: FRAME_STYLES[o.style] ? o.style : f.style, c1: /^#[0-9a-f]{6}$/i.test(o.c1 || '') ? o.c1 : f.c1, c2: /^#[0-9a-f]{6}$/i.test(o.c2 || '') ? o.c2 : f.c2 }; }
  /* couches : [décalage depuis le bord, épaisseur, couleur] en « unités » (595 = largeur d'une page A4 de devis) */
  function frameLayers(o) {
    switch (o.style) {
      case 'or': return [[16, 3.2, o.c2], [25, 1, o.c2]];
      case 'simple': return [[16, 6, o.c1]];
      case 'fin': return [[18, 1.6, o.c1]];
      default: return [[14, 9, o.c1], [24, 2.4, o.c2], [33, 9, '#ede0b8'], [46, 1, o.c2], [49, 0.4, '#e6d39a']];
    }
  }
  /* dessine le contour dans host (position:relative) de W×H px ; u = taille d'une unité en px ; renvoie l'élément ou null */
  function frame(host, W, H, u, cfg) {
    var o = frameNorm(cfg), old = host.querySelectorAll ? host.querySelectorAll(':scope > [data-frame]') : [];
    Array.prototype.forEach.call(old, function (x) { x.remove(); });
    if (!o.on) return null;
    var g = d.createElement('div'); g.setAttribute('data-frame', '1');
    g.style.cssText = 'position:absolute;left:0;top:0;width:' + W + 'px;height:' + H + 'px;pointer-events:none;z-index:60';
    frameLayers(o).forEach(function (L) {
      var b = L[1] * u, off = (L[0] - L[1] / 2) * u, e = d.createElement('div');
      e.style.cssText = 'position:absolute;box-sizing:border-box;left:' + off + 'px;top:' + off + 'px;width:' + (W - 2 * off) + 'px;height:' + (H - 2 * off) + 'px;border:' + b + 'px solid ' + L[2];
      g.appendChild(e);
    });
    host.appendChild(g); return g;
  }
  /* panneau de réglage (case + style + couleurs) ; get/set manipulent un objet {on,style,c1,c2} ; onChange() après chaque modification */
  function framePanel(box, get, set, onChange, idp) {
    var o = frameNorm(get());
    box.innerHTML =
      '<label style="display:flex;gap:8px;align-items:center;font:700 13px Arial,sans-serif;color:#12305e;cursor:pointer"><input type="checkbox" id="' + idp + 'on"' + (o.on ? ' checked' : '') + ' style="width:20px;height:20px"> Afficher un contour (cadre)</label>' +
      '<div id="' + idp + 'opt" style="' + (o.on ? '' : 'opacity:.45;pointer-events:none') + '">' +
      '<label class="exbs-l">Style du contour</label><select id="' + idp + 'st" class="exbs-in">' + Object.keys(FRAME_STYLES).map(function (k) { return '<option value="' + k + '"' + (k === o.style ? ' selected' : '') + '>' + FRAME_STYLES[k] + '</option>'; }).join('') + '</select>' +
      '<div class="exbs-2"><div><label class="exbs-l">Couleur principale</label><input type="color" id="' + idp + 'c1" value="' + o.c1 + '" class="exbs-in"></div><div><label class="exbs-l">Couleur or / filet</label><input type="color" id="' + idp + 'c2" value="' + o.c2 + '" class="exbs-in"></div></div></div>';
    function read() { return { on: $(idp + 'on').checked, style: $(idp + 'st').value, c1: $(idp + 'c1').value, c2: $(idp + 'c2').value }; }
    function ch(live) { var v = read(); $(idp + 'opt').style.cssText = v.on ? '' : 'opacity:.45;pointer-events:none'; set(v); onChange(live); }
    $(idp + 'on').onchange = function () { ch(false); }; $(idp + 'st').onchange = function () { ch(false); };
    ['c1', 'c2'].forEach(function (k) { $(idp + k).oninput = function () { ch(true); }; $(idp + k).onchange = function () { ch(false); }; });
  }
  w.EXB_FRAME = { draw: frame, norm: frameNorm, defaults: frameDefaults, styles: FRAME_STYLES, panel: framePanel };

  /* ---- contour des deux affiches Excellencia (onglet « Affiches Excellencia ») ---- */
  function posterFrames() {
    var o = frameNorm(rd(K_FR, null));
    [['posterPaper'], ['softwarePosterPaper']].forEach(function (a) {
      var p = $(a[0]); if (!p) return;
      var cs = w.getComputedStyle(p); if (cs.position === 'static') p.style.position = 'relative';
      frame(p, p.offsetWidth || 1024, p.offsetHeight || 1536, (p.offsetWidth || 1024) / 595, o);
    });
  }
  function posterFrameCard() {
    var sec = $('affiches'); if (!sec || $('exbFrameCard')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    css('exbcCssL', '.exbs-l{display:block;font:700 12px Arial,sans-serif;color:#12305e;margin:8px 0 3px}.exbs-in{width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial,sans-serif;background:#fff;color:#172033}input[type=color].exbs-in{padding:2px;height:38px}.exbs-2{display:grid;grid-template-columns:1fr 1fr;gap:8px}');
    var card = d.createElement('div'); card.className = 'card no-print'; card.id = 'exbFrameCard'; card.style.gridColumn = '1/-1';
    card.innerHTML = '<h2>🔲 Contour des affiches</h2><p style="font-size:12.5px;color:#5e6877;margin:-4px 0 10px">Mettez ou retirez un contour (cadre) sur les deux affiches (générale et logiciels), dans le même style que la page de garde des devis.</p><div id="exbFrameBox"></div>';
    var lc = $('exbLogoCard'); if (lc && lc.nextSibling) grid.insertBefore(card, lc.nextSibling); else grid.insertBefore(card, grid.firstChild);
    framePanel($('exbFrameBox'), function () { return rd(K_FR, null); }, function (v) { wr(K_FR, v); }, posterFrames, 'exbPf');
    posterFrames();
  }
  function wrapPosterRender() {
    ['renderPoster', 'renderSoftwarePoster'].forEach(function (n) {
      var f = w[n]; if (typeof f !== 'function' || f.__exbFrame) return;
      var g = function () { var r = f.apply(this, arguments); try { setTimeout(posterFrames, 30); } catch (e) {} return r; };
      g.__exbFrame = 1; for (var k in f) { try { g[k] = f[k]; } catch (e) {} } w[n] = g;
    });
  }

  /* =====================================================================
   *  2) CARTES DE TRAVAIL / DE MEMBRE
   * ===================================================================== */
  var CAT = {
    personnel: { l: 'Personnel', title: 'CARTE DE TRAVAIL', col: '#c9a227', code: 'PER', valid: 2 },
    formateur: { l: 'Formateur', title: 'CARTE DE MEMBRE', col: '#1e5fb4', code: 'FOR', valid: 1 },
    participant: { l: 'Participant / Apprenant', title: 'CARTE DE MEMBRE', col: '#2e8b57', code: 'APP', valid: 1 },
    etudiant: { l: 'Étudiant TFL', title: 'CARTE DE MEMBRE', col: '#c2283d', code: 'ETU', valid: 1 },
    encadreur: { l: 'Encadreur TFL', title: 'CARTE DE MEMBRE', col: '#7b3fa0', code: 'ENC', valid: 1 },
    membre: { l: 'Autre membre / partenaire', title: 'CARTE DE MEMBRE', col: '#e8590c', code: 'MEM', valid: 1 }
  };
  var CW = 1011, CH = 638; /* 85,6 × 54 mm à 300 dpi */
  function cards() { var a = rd(K_CARDS, []); return Array.isArray(a) ? a : []; }
  function saveCards(a) { if (!wr(K_CARDS, a)) { note('Stockage plein : carte non enregistrée.', 'error', 6000); return false; } return true; }
  function opts() { var o = rd(K_OPT, null) || {}; return { frame: frameNorm(o.frame), qr: o.qr !== false }; }
  function setOpts(o) { wr(K_OPT, o); }

  /* personnes ayant déjà un matricule, par catégorie */
  function sources() {
    var out = [];
    function add(cat, key, name, fonction, phone, photo, mat, date) { if (mat && name) out.push({ cat: cat, key: key, name: name, fonction: fonction, phone: phone || '', photo: photo || '', matricule: mat, date: date || '' }); }
    try { if (typeof participants !== 'undefined') participants.forEach(function (p) { if (p) add('participant', 'p:' + p.participant_id, p.name, p.training || 'Participant', p.phone, p.photo, p.matricule, p.registration_date); }); } catch (e) {}
    try { if (typeof trainers !== 'undefined') trainers.forEach(function (t) { if (t && (!t.approval_status || t.approval_status === 'APPROUVE')) add('formateur', 't:' + t.trainer_id, t.name, t.specialty || 'Formateur', t.phone, t.photo, t.matricule); }); } catch (e) {}
    try { (w.exbHr || []).forEach(function (h) { if (h && (!h.approval_status || h.approval_status === 'APPROUVE')) add('personnel', 'h:' + h.id, h.name, h.role || 'Personnel', h.phone, h.photo, h.matricule); }); } catch (e) {}
    try { (rd('exb_tfl_etudiants', []) || []).forEach(function (e) { if (e) add('etudiant', 'e:' + e.id, e.nom, 'Étudiant — ' + (e.filiere || e.faculte || e.departement || 'TFL'), e.telephone, e.photo, e.matricule); }); } catch (e) {}
    try { (rd('exb_tfl_encadreurs', []) || []).forEach(function (e) { if (e) add('encadreur', 'c:' + e.id, e.nom, e.specialite || e.fonction || 'Encadreur TFL', e.telephone, e.photo, e.matricule); }); } catch (e) {}
    return out;
  }
  function srcByKey(k) { var L = sources(); for (var i = 0; i < L.length; i++) if (L[i].key === k) return L[i]; return null; }
  /* carte + données actuelles de la personne (nom, photo, matricule à jour) */
  function resolve(c) {
    var s = c.key ? srcByKey(c.key) : null;
    return { name: (s && s.name) || c.name || '', fonction: c.fonction || (s && s.fonction) || '', phone: (s && s.phone) || c.phone || '', photo: (s && s.photo) || c.photo || '', matricule: (s && s.matricule) || c.matricule || '' };
  }
  function nextNo(all) {
    var y = new Date().getFullYear(), pre = 'EXB-CT-' + y + '-', max = 0;
    all.forEach(function (c) { if (String(c.no || '').indexOf(pre) === 0) { var n = parseInt(String(c.no).slice(pre.length), 10); if (n > max) max = n; } });
    return pre + String(max + 1).padStart(4, '0');
  }
  function usedMat() {
    var s = {}; sources().forEach(function (x) { s[x.matricule] = 1; }); cards().forEach(function (c) { if (c.matricule) s[c.matricule] = 1; });
    try { (w.exbApprovals || []).forEach(function (x) { if (x && x.matricule) s[x.matricule] = 1; }); } catch (e) {}
    return s;
  }
  function genMat() {
    var used = usedMat(), i, n, m;
    for (i = 0; i < 1000; i++) { n = Array.from({ length: 9 }, function () { return Math.floor(Math.random() * 10); }).join(''); m = n.slice(0, 3) + '-' + n.slice(3, 6) + '-' + n.slice(6, 9); if (!used[m]) return m; }
    return String(Date.now()).slice(-9).replace(/(\d{3})(\d{3})(\d{3})/, '$1-$2-$3');
  }
  /* crée les cartes manquantes ; renvoie les cartes créées */
  function sync() {
    var all = cards(), have = {}, made = [];
    all.forEach(function (c) { if (c.key) have[c.key] = 1; });
    sources().forEach(function (s) {
      if (have[s.key]) return;
      var iss = today(), c = { id: 'ct' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), no: nextNo(all), key: s.key, cat: s.cat, matricule: s.matricule, name: s.name, fonction: s.fonction, phone: s.phone, issued: iss, expires: addYears(iss, CAT[s.cat].valid), auto: true };
      all.push(c); made.push(c); have[s.key] = 1;
    });
    if (made.length) saveCards(all);
    return made;
  }

  /* ---------- rendu d'une face de carte (élément HTML de CW×CH px) ---------- */
  function T(p, css0, txt) { var e = d.createElement('div'); e.style.cssText = 'position:absolute;box-sizing:border-box;' + css0; if (txt != null) e.textContent = txt; p.appendChild(e); return e; }
  function cardUrl(c, r) {
    try { if (w.EXBVerif && w.EXBVerif.fiche) { var k = w.EXBVerif.fiche(r.matricule, r.name, (CAT[c.cat] || CAT.membre).l + ' — carte ' + c.no, c.issued); if (k && k.url) return k.url; } } catch (e) {}
    return 'EXCELLENCIA BUILDING|' + c.no + '|' + r.matricule + '|' + r.name;
  }
  function qrData(url) { try { return w.EXBVerif && w.EXBVerif.qrPng ? w.EXBVerif.qrPng(url) : ''; } catch (e) { return ''; } }
  function fit(txt, big, small, lim) { return String(txt).length > lim ? small : big; }
  function silhouette(p, x, y, w0, h0, col) {
    var b = T(p, 'left:' + x + 'px;top:' + y + 'px;width:' + w0 + 'px;height:' + h0 + 'px;background:#dfe6f0;border-radius:14px;border:4px solid ' + col + ';overflow:hidden');
    T(b, 'left:' + (w0 * 0.3) + 'px;top:' + (h0 * 0.18) + 'px;width:' + (w0 * 0.4) + 'px;height:' + (w0 * 0.4) + 'px;border-radius:50%;background:#9fb0c8');
    T(b, 'left:' + (w0 * 0.12) + 'px;top:' + (h0 * 0.58) + 'px;width:' + (w0 * 0.76) + 'px;height:' + (h0 * 0.6) + 'px;border-radius:50% 50% 0 0;background:#9fb0c8');
  }
  function cardFace(c, side, o, logoSrc) {
    var B = brand(), r = resolve(c), cat = CAT[c.cat] || CAT.membre, fr = o.frame.on, m = fr ? 42 : 0, f = 'Arial,Helvetica,sans-serif';
    var root = d.createElement('div');
    root.style.cssText = 'position:relative;width:' + CW + 'px;height:' + CH + 'px;overflow:hidden;font-family:' + f + ';background:linear-gradient(135deg,#ffffff 0%,#eef4fc 60%,#e1eaf7 100%);color:#12305e';
    if (logoSrc) { var wm = d.createElement('img'); wm.src = logoSrc; wm.alt = ''; wm.style.cssText = 'position:absolute;right:30px;bottom:60px;width:360px;height:360px;object-fit:contain;opacity:.06'; root.appendChild(wm); }
    var X0 = m + 36, name = String(r.name).toUpperCase();
    if (side === 'front') {
      var band = T(root, 'left:' + m + 'px;top:' + m + 'px;width:' + (CW - 2 * m) + 'px;height:120px;background:linear-gradient(90deg,#0f2a56,#1e5fb4)');
      var lb = T(band, 'left:22px;top:18px;width:84px;height:84px;background:#fff;border-radius:12px;padding:6px');
      if (logoSrc) { var li = d.createElement('img'); li.src = logoSrc; li.alt = ''; li.style.cssText = 'width:100%;height:100%;object-fit:contain;display:block'; lb.appendChild(li); }
      T(band, 'left:124px;top:22px;width:520px;font:800 31px ' + f + ';color:#fff;letter-spacing:1px;white-space:nowrap', B.name.toUpperCase());
      T(band, 'left:124px;top:66px;width:520px;font:italic 16px Georgia,serif;color:#cfe3ff', B.tagline);
      T(band, 'right:24px;top:26px;width:330px;text-align:right;font:800 25px ' + f + ';color:#f2c94c;letter-spacing:2px;line-height:1.15', cat.title);
      T(band, 'right:24px;top:70px;width:330px;text-align:right;font:700 15px ' + f + ';color:#ffffff;letter-spacing:1px', cat.l.toUpperCase());
      T(root, 'left:' + m + 'px;top:' + (m + 120) + 'px;width:' + (CW - 2 * m) + 'px;height:10px;background:' + cat.col);
      var py = m + 172;
      if (r.photo) { var pb = T(root, 'left:' + X0 + 'px;top:' + py + 'px;width:220px;height:290px;border-radius:14px;border:4px solid ' + cat.col + ';overflow:hidden;background:#dfe6f0'); var im = d.createElement('img'); im.src = r.photo; im.alt = ''; im.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block'; pb.appendChild(im); }
      else silhouette(root, X0, py, 220, 290, cat.col);
      T(root, 'left:' + X0 + 'px;top:' + (py + 296) + 'px;width:220px;padding:7px 4px;text-align:center;border-radius:20px;background:' + cat.col + ';color:#fff;font:800 14px ' + f + ';letter-spacing:1px', cat.l.toUpperCase());
      var FX = m + 296, FW = CW - FX - m - 30;
      function fld(x, y, wd, label, val, vcss) { T(root, 'left:' + x + 'px;top:' + y + 'px;width:' + wd + 'px;font:700 13px ' + f + ';color:#6b7a99;letter-spacing:1.2px', label); T(root, 'left:' + x + 'px;top:' + (y + 20) + 'px;width:' + wd + 'px;' + vcss, val); }
      fld(FX, py, FW, 'NOM ET PRÉNOM', name, 'font:800 ' + fit(name, 34, name.length > 30 ? 21 : 26, 18) + 'px ' + f + ';color:#12305e;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis');
      var fo = r.fonction || '—';
      fld(FX, py + 84, FW, 'FONCTION / CATÉGORIE', fo, 'font:700 ' + fit(fo, 27, 20, 28) + 'px ' + f + ';color:#1c2b45;line-height:1.15;max-height:64px;overflow:hidden');
      fld(FX, py + 168, FW, 'N° MATRICULE', r.matricule || '—', 'font:800 40px "Courier New",monospace;color:' + (c.cat === 'personnel' ? '#8a6d0a' : '#12305e') + ';letter-spacing:2px');
      fld(FX, py + 252, 220, 'DÉLIVRÉE LE', frDate(c.issued), 'font:700 24px ' + f + ';color:#1c2b45');
      fld(FX + 250, py + 252, 220, 'EXPIRE LE', frDate(c.expires), 'font:700 24px ' + f + ';color:#1c2b45');
      var ft = T(root, 'left:' + m + 'px;top:' + (CH - m - 44) + 'px;width:' + (CW - 2 * m) + 'px;height:44px;background:#12305e;color:#fff;text-align:center;font:700 16px ' + f + ';line-height:44px', '📞 ' + B.phone + '    ✉ ' + B.email + '    📍 ' + B.address);
      ft.style.whiteSpace = 'nowrap'; ft.style.overflow = 'hidden';
    } else {
      T(root, 'left:' + m + 'px;top:' + m + 'px;width:' + (CW - 2 * m) + 'px;height:64px;background:linear-gradient(90deg,#0f2a56,#1e5fb4);color:#fff;text-align:center;font:800 26px ' + f + ';line-height:64px;letter-spacing:2px', B.name.toUpperCase());
      T(root, 'left:' + m + 'px;top:' + (m + 64) + 'px;width:' + (CW - 2 * m) + 'px;height:8px;background:' + cat.col);
      var qx = m + 40, qy = m + 98;
      if (o.qr) {
        var qb = T(root, 'left:' + qx + 'px;top:' + qy + 'px;width:230px;height:230px;background:#fff;border:2px solid #c9d3df;border-radius:10px;padding:8px'), qd = qrData(cardUrl(c, r));
        if (qd) { var qi = d.createElement('img'); qi.src = qd; qi.alt = 'QR'; qi.style.cssText = 'width:100%;height:100%;display:block;image-rendering:pixelated'; qb.appendChild(qi); }
        T(root, 'left:' + qx + 'px;top:' + (qy + 238) + 'px;width:230px;text-align:center;font:700 13px ' + f + ';color:#42526e', 'Scannez pour vérifier la carte');
      }
      var rx = m + (o.qr ? 320 : 40), rw = CW - rx - m - 36;
      T(root, 'left:' + rx + 'px;top:' + (m + 94) + 'px;width:' + rw + 'px;font:17px/1.4 ' + f + ';color:#1c2b45', 'Cette carte est strictement personnelle et reste la propriété de ' + B.name + '. Elle doit être présentée à toute demande et restituée en fin de fonction ou d’appartenance.');
      T(root, 'left:' + rx + 'px;top:' + (m + 190) + 'px;width:' + rw + 'px;font:700 17px/1.4 ' + f + ';color:#12305e', 'En cas de perte ou de découverte, prière de contacter :\n' + B.phone + ' · ' + B.email + '\n' + B.address).style.whiteSpace = 'pre-line';
      var sy = CH - m - 215;
      T(root, 'left:' + rx + 'px;top:' + sy + 'px;width:' + Math.round(rw * 0.46) + 'px;height:2px;background:#42526e');
      T(root, 'left:' + rx + 'px;top:' + (sy + 8) + 'px;width:' + Math.round(rw * 0.46) + 'px;font:700 13px ' + f + ';color:#42526e', 'Signature du titulaire');
      var sx2 = rx + Math.round(rw * 0.54);
      T(root, 'left:' + sx2 + 'px;top:' + sy + 'px;width:' + Math.round(rw * 0.46) + 'px;height:2px;background:#42526e');
      T(root, 'left:' + sx2 + 'px;top:' + (sy + 8) + 'px;width:' + Math.round(rw * 0.46) + 'px;font:700 13px ' + f + ';color:#42526e', 'La Direction' + (B.dg ? ' — ' + B.dg : ''));
      var mrz = ('EXB<<' + cat.code + '<<' + String(r.matricule).replace(/-/g, '') + '<<' + String(r.name).toUpperCase().replace(/[^A-Z0-9]+/g, '<')).slice(0, 52);
      while (mrz.length < 52) mrz += '<';
      T(root, 'left:' + m + 'px;top:' + (CH - m - 104) + 'px;width:' + (CW - 2 * m) + 'px;height:52px;background:#eef2f8;text-align:center;font:700 22px/52px "Courier New",monospace;color:#42526e;letter-spacing:3px;white-space:nowrap;overflow:hidden', mrz);
      T(root, 'left:' + m + 'px;top:' + (CH - m - 44) + 'px;width:' + (CW - 2 * m) + 'px;height:44px;background:#12305e;color:#fff;text-align:center;font:700 16px/44px ' + f, 'Carte n° ' + c.no + '  ·  Délivrée le ' + frDate(c.issued) + '  ·  Valable jusqu’au ' + frDate(c.expires));
    }
    frame(root, CW, CH, 0.85, o.frame);
    return root;
  }
  /* logo → data URL (évite les images externes bloquées à l'export) */
  var logoCache = null;
  function logoData(cb) {
    var src = brand().logo; if (/^data:/.test(src)) return cb(src);
    if (logoCache && logoCache.s === src) return cb(logoCache.d);
    var im = new Image(); im.onload = function () { try { var cv = d.createElement('canvas'); cv.width = im.naturalWidth; cv.height = im.naturalHeight; cv.getContext('2d').drawImage(im, 0, 0); logoCache = { s: src, d: cv.toDataURL('image/png') }; cb(logoCache.d); } catch (e) { cb(src); } };
    im.onerror = function () { cb(''); }; im.src = src;
  }
  function renderCanvas(c, side, cb) {
    if (typeof w.html2canvas !== 'function') { note('Export impossible : le moteur d’image n’est pas chargé.', 'error', 7000); return; }
    logoData(function (lg) {
      var host = d.createElement('div'); host.style.cssText = 'position:fixed;left:-100000px;top:0'; var el = cardFace(c, side, opts(), lg); host.appendChild(el); d.body.appendChild(host);
      var imgs = Array.prototype.slice.call(el.querySelectorAll('img')), n = imgs.length, go = function () { setTimeout(function () { w.html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: false, logging: false, width: CW, height: CH }).then(function (cv) { host.remove(); cb(cv); }, function (e) { host.remove(); note('Export impossible : ' + (e && e.message || e), 'error', 8000); }); }, 120); };
      if (!n) return go(); imgs.forEach(function (im) { var f = function () { if (--n === 0) go(); }; if (im.complete) f(); else { im.onload = f; im.onerror = f; } });
    });
  }
  function fname(c, sfx) { return (resolve(c).name || 'carte').replace(/[\\/:*?"<>|]+/g, '-').trim() + ' - carte ' + c.no + (sfx || ''); }
  function exportPng(c, side) { renderCanvas(c, side, function (cv) { cv.toBlob(function (b) { if (b) { download(b, fname(c, ' ' + (side === 'front' ? 'recto' : 'verso')) + '.png'); note('✓ Image enregistrée.', 'ok'); } }, 'image/png'); }); }
  function exportPdf(c) {
    var J = w.jspdf && w.jspdf.jsPDF; if (!J) { note('Export PDF impossible : le moteur PDF n’est pas chargé.', 'error', 7000); return; }
    renderCanvas(c, 'front', function (a) { renderCanvas(c, 'back', function (b) {
      var pdf = new J({ orientation: 'l', unit: 'mm', format: [85.6, 54], compress: true });
      pdf.addImage(a.toDataURL('image/jpeg', 0.93), 'JPEG', 0, 0, 85.6, 54); pdf.addPage([85.6, 54], 'l'); pdf.addImage(b.toDataURL('image/jpeg', 0.93), 'JPEG', 0, 0, 85.6, 54);
      download(pdf.output('blob'), fname(c) + '.pdf'); note('✓ PDF enregistré (recto + verso, format carte 85,6 × 54 mm).', 'ok');
    }); });
  }
  function printCard(c) {
    renderCanvas(c, 'front', function (a) { renderCanvas(c, 'back', function (b) {
      w.EXBPrint.html('Carte — ' + fname(c),'<!doctype html><title>Carte</title><style>@page{size:A4;margin:12mm}body{margin:0;text-align:center}img{width:85.6mm;height:54mm;display:block;margin:6mm auto;border:1px dashed #999}</style><img src="' + a.toDataURL('image/png') + '"><img src="' + b.toDataURL('image/png') + '">');
    }); });
  }
  function waLink(c) {
    var r = resolve(c), cat = CAT[c.cat] || CAT.membre, B = brand(), ph = String(r.phone || '').replace(/\D+/g, '');
    if (/^0\d{9}$/.test(ph)) ph = '243' + ph.slice(1);
    var msg = 'Bonjour ' + r.name + ',\nVotre ' + cat.title.toLowerCase().replace('carte', 'carte') + ' ' + B.name + ' (' + cat.l + ') est prête.\nMatricule : ' + r.matricule + '\nCarte n° ' + c.no + ' · valable jusqu’au ' + frDate(c.expires) + '\nVérification : ' + cardUrl(c, r) + '\nMerci.';
    return { url: 'https://wa.me/' + ph + '?text=' + encodeURIComponent(msg), msg: msg, hasPhone: !!ph };
  }

  /* ---------- interface ---------- */
  var root = null, selId = null, filt = { cat: '', q: '' };
  function readImg(file, cb) {
    var rr = new FileReader(); rr.onload = function () { var im = new Image(); im.onload = function () { var k = Math.min(1, 480 / Math.max(im.naturalWidth, im.naturalHeight)), cv = d.createElement('canvas'); cv.width = Math.round(im.naturalWidth * k); cv.height = Math.round(im.naturalHeight * k); var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.drawImage(im, 0, 0, cv.width, cv.height); cb(cv.toDataURL('image/jpeg', 0.85)); }; im.onerror = function () { note('Image illisible.', 'error'); }; im.src = rr.result; }; rr.readAsDataURL(file);
  }
  function list() {
    var q = filt.q.toLowerCase();
    return cards().filter(function (c) { var r = resolve(c); return (!filt.cat || c.cat === filt.cat) && (!q || [r.name, r.matricule, c.no, r.fonction].join(' ').toLowerCase().indexOf(q) >= 0); }).sort(function (a, b) { return (b.created || b.issued || '').localeCompare(a.created || a.issued || '') || String(b.no).localeCompare(String(a.no)); });
  }
  function drawList() {
    var el = $('exbcList'); if (!el) return; var L = list(), all = cards();
    $('exbcCount').textContent = all.length + ' carte(s)' + (L.length !== all.length ? ' · ' + L.length + ' affichée(s)' : '');
    el.innerHTML = L.length ? L.map(function (c) { var r = resolve(c), cat = CAT[c.cat] || CAT.membre; return '<div class="exbc-it' + (c.id === selId ? ' on' : '') + '" data-id="' + c.id + '"><span class="exbc-dot" style="background:' + cat.col + '"></span><div><b>' + esc(r.name) + '</b><span>' + esc(cat.l) + ' · ' + esc(r.matricule) + '</span></div></div>'; }).join('') : '<p class="exbs-hint">Aucune carte. Les cartes se créent toutes seules dès qu’une personne reçoit son matricule (participants, formateurs, personnel, TFL) ; vous pouvez aussi créer celle d’un autre membre.</p>';
    Array.prototype.forEach.call(el.querySelectorAll('[data-id]'), function (x) { x.onclick = function () { selId = x.getAttribute('data-id'); drawList(); drawPreview(); }; });
  }
  function drawPreview() {
    var box = $('exbcPrev'), c = cards().filter(function (x) { return x.id === selId; })[0]; if (!box) return;
    if (!c) { box.innerHTML = '<p class="exbs-hint">Choisissez une carte dans la liste pour la voir, l’exporter ou l’envoyer.</p>'; $('exbcAct').style.display = 'none'; return; }
    $('exbcAct').style.display = '';
    var avail = Math.max(260, Math.min(CW, ($('exbcPrevWrap').clientWidth || 600) - 8)), sc = Math.min(1, avail / CW), o = opts();
    logoData(function (lg) {
      box.innerHTML = '';
      ['front', 'back'].forEach(function (s) {
        var wrap = d.createElement('div'); wrap.style.cssText = 'width:' + CW * sc + 'px;height:' + CH * sc + 'px;margin:0 auto 12px;box-shadow:0 3px 14px #0004;border-radius:10px;overflow:hidden;background:#fff';
        var el = cardFace(c, s, o, lg); el.style.transform = 'scale(' + sc + ')'; el.style.transformOrigin = 'top left'; wrap.appendChild(el); box.appendChild(wrap);
      });
    });
    var r = resolve(c), cat = CAT[c.cat] || CAT.membre;
    $('exbcInfo').innerHTML = '<b>' + esc(r.name) + '</b> — ' + esc(cat.title) + ' · ' + esc(cat.l) + '<br>Matricule <b>' + esc(r.matricule) + '</b> · carte n° ' + esc(c.no) + (c.auto ? ' · <i>générée automatiquement</i>' : ' · créée manuellement');
    $('exbcExp').value = c.expires || '';
    var wa = waLink(c); $('exbcWa').style.opacity = wa.hasPhone ? 1 : .55;
  }
  function frameBox() {
    framePanel($('exbcFr'), function () { return opts().frame; }, function (v) { var o = opts(); o.frame = v; setOpts(o); }, function () { drawPreview(); }, 'exbcF');
  }
  function newForm() {
    var b = $('exbcNew'); b.style.display = b.style.display === 'none' ? '' : 'none';
  }
  function ui() {
    css('exbcCss',
      '#exbcRoot{display:none}#exbcRoot.on{display:block}.exbc-grid{display:grid;grid-template-columns:330px minmax(0,1fr);gap:14px;align-items:start}@media(max-width:980px){.exbc-grid{grid-template-columns:1fr}}' +
      '.exbc-it{display:flex;gap:9px;align-items:center;border:1px solid #e3e9f2;border-radius:10px;padding:8px 10px;margin:6px 0;cursor:pointer;background:#fff}.exbc-it.on{border-color:#12305e;background:#eef4fc}.exbc-it b{display:block;font-size:13px;color:#12305e}.exbc-it span{font-size:11.5px;color:#6b7a99}.exbc-dot{width:12px;height:12px;border-radius:50%;flex:none}' +
      '#exbcList{max-height:560px;overflow:auto}@media print{#exbcRoot{display:none!important}}');
    var sec = $('affiches'); if (!sec || $('exbcRoot')) return;
    var tabs = sec.querySelector('.exbs-tabs'), grid = sec.querySelector('.grid'); if (!tabs || !grid || !$('exbsRoot')) return;
    var tb = d.createElement('button'); tb.id = 'exbsT3'; tb.textContent = '🪪 Cartes de travail / membre'; tabs.appendChild(tb);
    root = d.createElement('div'); root.id = 'exbcRoot'; root.className = 'no-print';
    root.innerHTML =
      '<div class="exbs-card" style="margin-bottom:12px"><h3>🪪 Cartes de travail et cartes de membre</h3>' +
      '<p class="exbs-hint" style="margin-top:0">La carte est créée <b>automatiquement</b> dès qu’une personne reçoit son matricule, selon sa catégorie : <b>carte de travail</b> pour le personnel d’Excellencia Building, <b>carte de membre</b> pour les formateurs, participants, étudiants et encadreurs TFL et les autres membres. Elle se télécharge (image ou PDF recto-verso), s’imprime ou s’envoie par WhatsApp.</p>' +
      '<div class="exbs-bar"><button class="p" id="exbcMk">＋ Carte d’un autre membre</button><button id="exbcSync">🔄 Créer les cartes manquantes</button></div>' +
      '<div id="exbcNew" style="display:none;border-top:1px solid #e3e9f2;padding-top:8px"><div class="exbs-2"><div><label class="exbs-l">Nom et prénom *</label><input id="exbcN" class="exbs-in"></div><div><label class="exbs-l">Fonction / qualité</label><input id="exbcF2" class="exbs-in" placeholder="ex. Partenaire, Stagiaire, Sous-traitant…"></div></div>' +
      '<div class="exbs-2"><div><label class="exbs-l">Catégorie</label><select id="exbcC" class="exbs-in">' + Object.keys(CAT).map(function (k) { return '<option value="' + k + '"' + (k === 'membre' ? ' selected' : '') + '>' + CAT[k].l + '</option>'; }).join('') + '</select></div><div><label class="exbs-l">Téléphone (WhatsApp)</label><input id="exbcP" class="exbs-in" placeholder="+243…"></div></div>' +
      '<label class="exbs-l">Photo</label><input type="file" id="exbcPh" accept="image/png,image/jpeg,image/webp"><div class="exbs-bar" style="margin-top:8px"><button class="g" id="exbcOk">✓ Générer le matricule et la carte</button></div></div></div>' +
      '<div class="exbc-grid"><div><div class="exbs-card"><h3>Cartes <small id="exbcCount" style="font-weight:400;color:#6b7a99"></small></h3>' +
      '<div class="exbs-2"><select id="exbcFc" class="exbs-in"><option value="">Toutes les catégories</option>' + Object.keys(CAT).map(function (k) { return '<option value="' + k + '">' + CAT[k].l + '</option>'; }).join('') + '</select><input id="exbcQ" class="exbs-in" placeholder="Rechercher…"></div><div id="exbcList" style="margin-top:6px"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Contour de la carte</h3><div id="exbcFr"></div><label style="display:flex;gap:8px;align-items:center;font:700 13px Arial,sans-serif;color:#12305e;margin-top:10px;cursor:pointer"><input type="checkbox" id="exbcQr" style="width:20px;height:20px"> QR de vérification au verso</label></div></div>' +
      '<div class="exbs-card" id="exbcPrevWrap"><div id="exbcInfo" class="exbs-hint" style="margin-top:0"></div><div id="exbcPrev"></div>' +
      '<div id="exbcAct" style="display:none"><div class="exbs-bar"><button class="g" id="exbcPng1">⬇ Recto (PNG)</button><button class="g" id="exbcPng2">⬇ Verso (PNG)</button><button class="g" id="exbcPdf">📄 PDF recto-verso</button><button id="exbcPr">🖨 Imprimer</button></div>' +
      '<div class="exbs-bar"><button class="p" id="exbcWa">💬 Envoyer par WhatsApp</button><button id="exbcCp">⧉ Copier le message</button></div>' +
      '<div class="exbs-2"><div><label class="exbs-l">Valable jusqu’au</label><input type="date" id="exbcExp" class="exbs-in"></div><div><label class="exbs-l">&nbsp;</label><button id="exbcRen" class="exbs-mini" style="padding:10px;border-radius:9px;border:1px solid #c9d3df;background:#f4f7fb;color:#12305e;font:700 13px Arial,sans-serif;cursor:pointer;width:100%">♻ Renouveler</button></div></div>' +
      '<div class="exbs-bar" style="margin-top:8px"><button id="exbcDel" style="color:#b42318">🗑 Supprimer cette carte</button></div></div></div></div>';
    sec.appendChild(root);
    var T1 = $('exbsT1'), T2 = $('exbsT2');
    function hideMine() { root.classList.remove('on'); tb.classList.remove('on'); }
    T1.addEventListener('click', hideMine); T2.addEventListener('click', hideMine);
    tb.onclick = function () {
      grid.style.display = 'none'; var sr = $('exbsRoot'); if (sr) sr.classList.remove('on'); T1.classList.remove('on'); T2.classList.remove('on'); tb.classList.add('on'); root.classList.add('on');
      sync(); drawList(); drawPreview();
    };
    $('exbcMk').onclick = newForm;
    $('exbcSync').onclick = function () { var m = sync(); note(m.length ? '✓ ' + m.length + ' carte(s) créée(s).' : 'Toutes les personnes ayant un matricule ont déjà leur carte.', m.length ? 'ok' : 'info'); drawList(); };
    $('exbcFc').onchange = function () { filt.cat = this.value; drawList(); }; $('exbcQ').oninput = function () { filt.q = this.value; drawList(); };
    $('exbcQr').checked = opts().qr; $('exbcQr').onchange = function () { var o = opts(); o.qr = this.checked; setOpts(o); drawPreview(); };
    var photo = '';
    $('exbcPh').onchange = function () { var f = this.files && this.files[0]; if (f) readImg(f, function (u) { photo = u; note('Photo prête.', 'info', 1500); }); };
    $('exbcOk').onclick = function () {
      var nm = $('exbcN').value.trim(); if (!nm) { note('Le nom est obligatoire.', 'warn'); return; }
      var all = cards(), cat = $('exbcC').value, iss = today(), c = { id: 'ct' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), no: nextNo(all), key: '', cat: cat, matricule: genMat(), name: nm, fonction: $('exbcF2').value.trim() || CAT[cat].l, phone: $('exbcP').value.trim(), photo: photo, issued: iss, expires: addYears(iss, CAT[cat].valid), auto: false, created: new Date().toISOString() };
      all.push(c); if (!saveCards(all)) return; selId = c.id; photo = ''; ['exbcN', 'exbcF2', 'exbcP', 'exbcPh'].forEach(function (i) { $(i).value = ''; }); $('exbcNew').style.display = 'none';
      note('✓ Carte créée — matricule ' + c.matricule, 'ok'); drawList(); drawPreview();
    };
    function cur() { return cards().filter(function (x) { return x.id === selId; })[0]; }
    $('exbcPng1').onclick = function () { var c = cur(); if (c) exportPng(c, 'front'); };
    $('exbcPng2').onclick = function () { var c = cur(); if (c) exportPng(c, 'back'); };
    $('exbcPdf').onclick = function () { var c = cur(); if (c) exportPdf(c); };
    $('exbcPr').onclick = function () { var c = cur(); if (c) printCard(c); };
    $('exbcWa').onclick = function () { var c = cur(); if (!c) return; var wa = waLink(c); if (!wa.hasPhone) { note('Pas de téléphone pour cette personne : message copié, collez-le dans WhatsApp.', 'warn', 6000); try { navigator.clipboard.writeText(wa.msg); } catch (e) {} return; } note('Téléchargez d’abord la carte (PNG ou PDF) puis joignez-la au message dans WhatsApp.', 'info', 7000); w.open(wa.url, '_blank'); };
    $('exbcCp').onclick = function () { var c = cur(); if (!c) return; try { navigator.clipboard.writeText(waLink(c).msg); note('✓ Message copié.', 'ok'); } catch (e) { note('Copie impossible.', 'error'); } };
    $('exbcExp').onchange = function () { var all = cards(), c = all.filter(function (x) { return x.id === selId; })[0]; if (!c || !this.value) return; c.expires = this.value; saveCards(all); drawPreview(); };
    $('exbcRen').onclick = function () { var all = cards(), c = all.filter(function (x) { return x.id === selId; })[0]; if (!c) return; c.issued = today(); c.expires = addYears(c.issued, (CAT[c.cat] || CAT.membre).valid); saveCards(all); note('✓ Carte renouvelée jusqu’au ' + frDate(c.expires) + '.', 'ok'); drawPreview(); };
    $('exbcDel').onclick = function () { var c = cur(); if (!c) return; if (!confirm('Supprimer cette carte ? (la personne et son matricule ne sont pas supprimés ; la carte sera recréée automatiquement si la personne existe encore)')) return; saveCards(cards().filter(function (x) { return x.id !== selId; })); selId = null; drawList(); drawPreview(); };
    frameBox(); drawList(); drawPreview();
    w.addEventListener('resize', function () { if (root.classList.contains('on')) drawPreview(); });
  }

  function start() {
    try { posterFrameCard(); } catch (e) { try { console.error('contour affiches', e); } catch (x) {} }
    try { ui(); } catch (e) { try { console.error('cartes de travail', e); } catch (x) {} }
    wrapPosterRender();
  }
  var first = true;
  function auto() {
    try {
      var m = sync();
      if (m.length) {
        if (first || m.length > 3) note('🪪 ' + m.length + ' carte(s) de travail / membre créée(s) automatiquement (Affiches › Cartes).', 'ok', 6000);
        else m.forEach(function (c) { note('🪪 Carte générée pour ' + resolve(c).name + ' (' + (CAT[c.cat] || CAT.membre).l + ')', 'ok', 6000); });
        if (root && root.classList.contains('on')) drawList();
      }
    } catch (e) {} first = false;
  }
  w.EXB_CARTES = { version: 'V99-cartes-1', sync: sync, cards: cards, categories: CAT, resolve: resolve, face: function (c, side) { return cardFace(c, side, opts(), brand().logo); }, genMat: genMat };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(start, 200); }); else setTimeout(start, 200);
  var n = 0, iv = setInterval(function () { if ($('exbcRoot') && $('exbFrameCard')) { clearInterval(iv); return; } if (++n > 40) { clearInterval(iv); return; } try { posterFrameCard(); ui(); wrapPosterRender(); } catch (e) {} }, 1600);
  setTimeout(auto, 3500); setInterval(function () { if (!d.hidden) auto(); }, 8000);
})(window, document);
