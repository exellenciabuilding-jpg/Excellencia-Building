# V119c — Aciers imposés (module de calcul de structure)

Principe repris de Robot Structural Analysis : l'utilisateur impose le diamètre des barres, le calcul n'utilise que ce diamètre et indique quoi faire si la section d'acier fournie est inférieure à la section requise.

## Où régler
- Poutre : carte « Aciers imposés » (Ø longitudinal, Ø cadres).
- Poteau : carte « Aciers imposés » (Ø longitudinal, Ø cadres).
- Plus d'options : les quatre réglages. Le Bâtiment les utilise aussi (poutres et poteaux).
- « Automatique » = comportement précédent (diamètre le plus économique).

## Ce que fait le calcul
- Poutre : As requise comparée à As fournie (nombre de barres limité par la largeur et l'espacement libre ≥ max(Ø ; 25 mm)).
- Si insuffisant, message de solutions chiffrées : diamètre supérieur, deux lits, largeur b, hauteur h.
- Cadres imposés : contrôle φt ≥ φl/3 (BAEL) ou ≥ max(6 ; φl/4) (EC2) et φt ≤ maximum admis.
- Poteau : mêmes principes, avec solution « élargir la section » (BAEL et EC2).

## Extension (étriers, épingles, dalle, semelle, escalier)
- Poutre : Ø des étriers, nombre de brins (2 à 4), espacement imposé (alerte s'il dépasse le maximum calculé).
- Poteau : Ø des cadres, espacement imposé, Ø des épingles (utilisé dans le métré et sur le plan).
- Dalle et plancher multi-travées : Ø et espacement des nappes. Escalier : Ø et espacement des nappes. Semelle : Ø des nappes.
- Si la disposition imposée ne suffit pas : message avec solutions chiffrées (diamètre supérieur, espacement réduit, épaisseur ou hauteur).

## Limites connues
- Étriers à 3 ou 4 brins : calcul pris en compte, mais le plan d'exécution dessine encore un cadre simple.
- Les solutions « h » et « section » recalculent avec les charges saisies (poids propre non recalculé pour la poutre) : relancer le calcul avec la nouvelle valeur pour confirmer.
- Calcul d'aide à l'étude : à faire vérifier par un ingénieur.
