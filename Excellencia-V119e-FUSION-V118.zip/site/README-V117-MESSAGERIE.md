# V117 — Messagerie unique, séparée par catégories

Fichiers : `exb-messagerie.js` (nouveau), `index.html` (balise script), `sw.js` (cache), `exb-v99zy-portails.js` (copie des messages clients à l'actualisation). Vider le cache puis recharger.

Bouton flottant ✉️ (pastille = messages non lus) → ouvre la boîte de réception avec 6 onglets, chacun avec son compteur :
- **Clients** : messages des portails clients (une conversation par lien), copiés à chaque « Actualiser » du module Portails.
- **Apprenants** : messages TFL envoyés par les étudiants (une conversation par dossier).
- **Encadreurs** : messages TFL des encadreurs (commentaires, progression, validation).
- **Formateurs** : messages des formateurs (retours formateurs).
- **Rapports** : rapports de séance des formateurs + déclarations d'avancement des sous-traitants.
- **Autres** : messages saisis à la main (WhatsApp, appel, courrier) via « ＋ Ajouter ».

Fonctions : recherche par onglet, conversations regroupées, « Tout lu », statut lu/non lu mémorisé (exb_msg_lus). Lecture seule : la réponse se fait dans le module d'origine. Les modules existants ne sont pas modifiés (sauf la copie côté Portails).
API : `EXBMessagerie.open('clients')`, `EXBMessagerie.nonLus()`.
Limite : les messages clients n'apparaissent qu'après un « Actualiser » dans Portails (connexion en ligne requise).

## V117b — Messagerie dans les modules + réponses directes
- **Tuile « ✉️ Messagerie »** dans chaque catégorie de l'accueil : Entreprise, Formation, Clients & CRM, Architecture, Ingénierie, Projets, Finance, Achats, Rapports (ouvre l'onglet utile : Formation → Apprenants, Clients → Clients, Rapports → Rapports). Le bouton « ← » ferme la messagerie et revient à la catégorie d'où l'on vient. Le bouton flottant ✉️ reste disponible.
- **Réponse directe** dans chaque conversation :
  - Apprenants / Encadreurs : message de l'administration enregistré dans le dossier TFL puis publié vers le portail (si hors ligne : à publier depuis TFL › Portails).
  - Clients : réponse envoyée au client via le portail (connexion en ligne requise).
  - Formateurs : réponse envoyée dans l'espace du formateur (connexion au serveur requise).
  - Autres : réponse enregistrée dans la conversation (note interne).
  - Déclarations d'avancement (Rapports) : pas de réponse ; accepter/refuser reste dans Portails.
- Fichiers modifiés : `exb-messagerie.js`, `exb-v99r-shell.js` (la tuile porte sa catégorie), `exb-formateur-retours.js` (`EXBFormateurRepondre`), `exb-v99zy-portails.js` (`EXBPortailRepondre`), `sw.js`.
- Test : Chromium (tuiles, réponses TFL/clients/formateurs, retour à la catégorie) avec des modules simulés ; non testé dans l'application complète ni sur un vrai Supabase.
