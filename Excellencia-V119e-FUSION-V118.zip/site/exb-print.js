/* Excellencia Building — impression universelle (V117d)
 *
 * PROBLÈME CORRIGÉ : les modules ouvraient une fenêtre vide (window.open('')) puis y écrivaient le document.
 *   - Android (application) : les fenêtres pop-up n'existent pas → écran blanc, rien ne s'imprime ;
 *   - Windows (application) : la fenêtre s'ouvrait blanche ;
 *   - navigateur : pop-up bloquée.
 * SOLUTION : plus aucune fenêtre pop-up. Tous les modules appellent EXBPrint.html(titre, html, options) :
 *   1. Windows (Electron)   → PDF créé directement (« Enregistrer sous ») puis ouvert dans le lecteur PDF ;
 *   2. Android (APK ≥ V117d) → boîte d'impression d'Android (« Enregistrer au format PDF » / imprimante) ;
 *   3. navigateur / ancien APK → aperçu plein écran dans l'application, avec les boutons Imprimer / PDF,
 *      Enregistrer (.html) et Fermer (impression automatique sur ordinateur).
 * API : EXBPrint.html(titre, html, {landscape}) · EXBPrint.page() (imprime l'écran courant) · EXBPrint.blob(blob, nom).
 */
(function (w, d) {
  'use strict';
  if (w.EXBPrint) return;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function say(m, k) { try { if (typeof w.notify === 'function') { w.notify(m, k || 'info', 6000); return; } } catch (e) {} try { alert(m); } catch (e2) {} }
  function isCap() { try { return !!(w.Capacitor && w.Capacitor.isNativePlatform && w.Capacitor.isNativePlatform()); } catch (e) { return false; } }
  function hasDesktop() { return !!(w.exbDesktop && typeof w.exbDesktop.print === 'function'); }
  function hasAndroid() { return !!w.ExbAndroidPrint; }
  function baseUrl() { try { var u = String(w.location.href).split('#')[0]; return /^(https?|app):/i.test(u) ? u : ''; } catch (e) { return ''; } }

  /* ---------- fabrique un document HTML complet, sans script (les anciens modules y mettaient « print() ») ---------- */
  function build(title, html, o) {
    o = o || {};
    var h = String(html == null ? '' : html).replace(/<script[\s\S]*?<\/script>/gi, '');
    var land = o.landscape || /size\s*:[^;}]*landscape/i.test(h);
    var inj = '<meta charset="utf-8">' + (baseUrl() && !/<base[\s>]/i.test(h) ? '<base href="' + esc(baseUrl()) + '">' : '') +
      (/<title[\s>]/i.test(h) ? '' : '<title>' + esc(title || 'Document') + '</title>') +
      '<style>*{-webkit-print-color-adjust:exact;print-color-adjust:exact}' + (/@page/i.test(h) ? '' : '@page{size:A4' + (land ? ' landscape' : '') + ';margin:12mm}') + '</style>';
    var m;
    if ((m = /<head[^>]*>/i.exec(h))) return h.slice(0, m.index + m[0].length) + inj + h.slice(m.index + m[0].length);
    if ((m = /<html[^>]*>/i.exec(h))) return h.slice(0, m.index + m[0].length) + '<head>' + inj + '</head>' + h.slice(m.index + m[0].length);
    if ((m = /<!doctype[^>]*>/i.exec(h))) return h.slice(0, m.index + m[0].length) + inj + h.slice(m.index + m[0].length);
    return '<!doctype html><html lang="fr"><head>' + inj + '</head><body>' + h + '</body></html>';
  }

  /* ---------- Android : images et feuilles de style intégrées au document (le moteur d'impression ne voit pas les fichiers de l'application) ---------- */
  function toDataUrl(url) {
    return Promise.race([
      fetch(url).then(function (r) { return r.blob(); }).then(function (b) { return new Promise(function (ok, ko) { var f = new FileReader(); f.onload = function () { ok(f.result); }; f.onerror = ko; f.readAsDataURL(b); }); }),
      new Promise(function (_, ko) { setTimeout(function () { ko(new Error('délai')); }, 6000); })
    ]);
  }
  function inlineAssets(html) {
    try {
      var doc = new DOMParser().parseFromString(html, 'text/html'), jobs = [], here = baseUrl() || w.location.href;
      Array.prototype.forEach.call(doc.querySelectorAll('img[src]'), function (im) {
        var s = im.getAttribute('src'); if (!s || /^data:/i.test(s)) return;
        var abs; try { abs = new URL(s, here).href; } catch (e) { return; }
        jobs.push(toDataUrl(abs).then(function (u) { im.setAttribute('src', u); }, function () {}));
      });
      Array.prototype.forEach.call(doc.querySelectorAll('link[rel~="stylesheet"][href]'), function (ln) {
        var abs; try { abs = new URL(ln.getAttribute('href'), here).href; } catch (e) { return; }
        jobs.push(Promise.race([fetch(abs).then(function (r) { return r.text(); }), new Promise(function (_, ko) { setTimeout(ko, 6000); })]).then(function (css) {
          var st = doc.createElement('style'); st.textContent = css; ln.parentNode.replaceChild(st, ln);
        }, function () {}));
      });
      return Promise.all(jobs).then(function () { return '<!doctype html>' + doc.documentElement.outerHTML; });
    } catch (e) { return Promise.resolve(html); }
  }

  /* ---------- aperçu plein écran (navigateur, ancien APK) ---------- */
  function preview(title, full, auto) {
    var old = d.getElementById('exbPrintView'); if (old) old.remove();
    var o = d.createElement('div'); o.id = 'exbPrintView'; o.className = 'no-print';
    o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:#e9edf3;display:flex;flex-direction:column;font-family:Arial,sans-serif';
    var bs = 'padding:10px 14px;border:0;border-radius:9px;font:700 14px Arial;cursor:pointer;';
    o.innerHTML = '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:8px 10px;background:#12254a;color:#fff">' +
      '<b style="flex:1;min-width:120px;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(title || 'Aperçu') + '</b>' +
      '<button data-a="print" style="' + bs + 'background:#e8590c;color:#fff">🖨 Imprimer / PDF</button>' +
      '<button data-a="save" style="' + bs + 'background:#fff;color:#12254a">⬇ Enregistrer</button>' +
      '<button data-a="close" style="' + bs + 'background:#334155;color:#fff">✕ Fermer</button></div>' +
      '<iframe style="flex:1;border:0;background:#fff;width:100%"></iframe>';
    d.body.appendChild(o);
    var fr = o.querySelector('iframe');
    function doPrint() {
      try { fr.contentWindow.focus(); fr.contentWindow.print(); }
      catch (e) { say('Impression impossible ici. Utilisez « Enregistrer » puis ouvrez le fichier pour l’imprimer.', 'warn'); }
      if (isCap()) say('Si rien ne s’ouvre : installez la dernière version de l’application (impression Android intégrée), ou utilisez « Enregistrer ».', 'info');
    }
    function save() {
      try {
        var b = new Blob([full], { type: 'text/html;charset=utf-8' }), a = d.createElement('a');
        a.href = URL.createObjectURL(b); a.download = String(title || 'document').replace(/[\\/:*?"<>|\r\n]+/g, ' ').trim().slice(0, 80) + '.html';
        a.style.display = 'none'; d.body.appendChild(a); a.click();
        setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 4000);
      } catch (e) { say('Enregistrement impossible : ' + (e.message || e), 'error'); }
    }
    function close() { d.removeEventListener('keydown', kd, true); o.remove(); }
    function kd(e) { if (e.key === 'Escape') { e.preventDefault(); close(); } }
    o.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('button[data-a]'); if (!b) return;
      var a = b.getAttribute('data-a'); if (a === 'print') doPrint(); else if (a === 'save') save(); else close();
    });
    d.addEventListener('keydown', kd, true);
    fr.addEventListener('load', function () {
      if (auto && !isCap()) {
        var im = []; try { im = Array.prototype.slice.call(fr.contentDocument.images || []); } catch (e) {}
        Promise.all(im.map(function (i) { return i.decode ? i.decode().catch(function () {}) : Promise.resolve(); })).then(function () { setTimeout(doPrint, 300); });
      }
    });
    fr.srcdoc = full;
    return Promise.resolve(true);
  }

  /* ---------- point d'entrée ---------- */
  function html(title, body, o) {
    o = o || {};
    var full;
    try { full = build(title, body, o); } catch (e) { say('Impression impossible : ' + (e.message || e), 'error'); return Promise.resolve(false); }
    return dispatch(title, full, o);
  }
  /* V118 : document HTML COMPLET déjà prêt (produit par le Centre documentaire) — même chemin que html(), sans ré-habillage */
  function dispatch(title, full, o) {
    o = o || {};
    title = String(title || 'Document');
    if (hasDesktop()) {
      return w.exbDesktop.print({ html: full, title: title }).then(function (r) {
        if (r && r.canceled) return false;
        if (r && (r.fallback || r.error)) { if (r.error) say('Le PDF n’a pas pu être créé (' + (r.step || '?') + ' : ' + r.error + '). Aperçu ouvert à la place.', 'warn'); return preview(title, full, true); }
        return true;
      }, function (e) { say('PDF impossible : ' + (e && e.message || e), 'warn'); return preview(title, full, true); });
    }
    if (hasAndroid() && o.native !== false) {
      return inlineAssets(full).then(function (f2) {
        try { w.ExbAndroidPrint.print(f2, title, baseUrl() || 'https://localhost/'); return true; }
        catch (e) { return preview(title, f2, false); }
      });
    }
    return preview(title, full, true);
  }

  /* imprime l'écran courant (copie du document, sans scripts) — utilisé pour window.print() dans l'application Android */
  function snap(doc) {
    doc = doc || d;
    var cs = doc.querySelectorAll('canvas'), root = doc.documentElement.cloneNode(true), cc = root.querySelectorAll('canvas');
    for (var i = 0; i < cc.length && i < cs.length; i++) {
      try { var im = d.createElement('img'); im.src = cs[i].toDataURL('image/png'); im.setAttribute('style', cs[i].getAttribute('style') || ''); im.width = cs[i].width; im.height = cs[i].height; im.className = cs[i].className; cc[i].parentNode.replaceChild(im, cc[i]); } catch (e) {}
    }
    var src = doc.querySelectorAll('input,textarea,select'), dst = root.querySelectorAll('input,textarea,select');
    for (var j = 0; j < dst.length && j < src.length; j++) {
      var a = src[j], b = dst[j];
      try {
        if (b.tagName === 'TEXTAREA') b.textContent = a.value;
        else if (b.tagName === 'SELECT') { for (var k = 0; k < b.options.length; k++) { if (a.options[k] && a.options[k].selected) b.options[k].setAttribute('selected', ''); else b.options[k].removeAttribute('selected'); } }
        else if (b.type === 'checkbox' || b.type === 'radio') { if (a.checked) b.setAttribute('checked', ''); else b.removeAttribute('checked'); }
        else b.setAttribute('value', a.value);
      } catch (e2) {}
    }
    Array.prototype.forEach.call(root.querySelectorAll('script,iframe,noscript,#exbPrintView,#exbPrintChoice'), function (n) { n.remove(); });
    return '<!DOCTYPE html>' + root.outerHTML;
  }
  function page() {
    var s;
    try { w.dispatchEvent(new Event('beforeprint')); s = snap(d); } catch (e) { return Promise.reject(e); }
    return html(d.title || 'Document', s, {}).then(function (r) { try { w.dispatchEvent(new Event('afterprint')); } catch (e) {} return r; });
  }

  /* PDF déjà fabriqué (Blob) : Windows → fichier ouvert ; Android → partage ; navigateur → onglet */
  function blob(b, name) {
    try {
      var a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name || 'document.pdf'; a.style.display = 'none';
      d.body.appendChild(a); a.click(); setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 4000);
      return true;
    } catch (e) { say('Enregistrement impossible : ' + (e.message || e), 'error'); return false; }
  }

  w.EXBPrint = { html: html, page: page, blob: blob, build: build, snap: snap, preview: preview, full: dispatch };

  /* Android : window.print() fonctionne enfin (il ne faisait rien dans l'application) */
  if ((hasAndroid() || isCap()) && !hasDesktop()) {
    var orig = w.print ? w.print.bind(w) : function () {};
    w.print = function () {
      if (!hasAndroid()) { try { orig(); } catch (e) {} return; }
      page().catch(function () { try { orig(); } catch (e) {} });
    };
  }
})(window, document);
