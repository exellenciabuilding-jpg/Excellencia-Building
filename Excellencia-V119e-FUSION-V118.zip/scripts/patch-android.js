/* Ajoute dans le projet Android (dossier android/) les autorisations de stockage nécessaires au dossier Documents. */
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(f)) { console.log('android/ absent : lancez d’abord « npm run android:add ».'); process.exit(0); }
let x = fs.readFileSync(f, 'utf8');
const perms = [
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
  '<uses-permission android:name="android.permission.RECORD_AUDIO" />' /* assistant : écoute de la voix */
];
perms.forEach(p => { if (!x.includes(p.split(' ')[1])) x = x.replace('</manifest>', '    ' + p + '\n</manifest>'); });
if (!x.includes('requestLegacyExternalStorage')) x = x.replace('<application', '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(f, x);
console.log('AndroidManifest.xml : autorisations de stockage ajoutées.');

/* Icône de l'application : remplace les icônes Capacitor par défaut par le logo Excellencia Building
 * (resources/android-res/mipmap-* → android/app/src/main/res/mipmap-*). */
(function () {
  const src = path.join(__dirname, '..', 'resources', 'android-res');
  const dst = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res');
  if (!fs.existsSync(src) || !fs.existsSync(dst)) { console.log('Icônes : dossier source ou res/ absent, ignoré.'); return; }
  let n = 0;
  (function copy(a, b) {
    fs.mkdirSync(b, { recursive: true });
    for (const e of fs.readdirSync(a, { withFileTypes: true })) {
      if (e.isDirectory()) copy(path.join(a, e.name), path.join(b, e.name));
      else { fs.copyFileSync(path.join(a, e.name), path.join(b, e.name)); n++; }
    }
  })(src, dst);
  /* fond de l'icône adaptative : blanc, comme le logo */
  const bg = path.join(dst, 'values', 'ic_launcher_background.xml');
  fs.mkdirSync(path.dirname(bg), { recursive: true });
  fs.writeFileSync(bg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFFFFF</color>\n</resources>\n');
  /* icônes adaptatives (Android 8+) : on force la référence vers notre premier plan */
  const any = path.join(dst, 'mipmap-anydpi-v26'); fs.mkdirSync(any, { recursive: true });
  const ad = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  fs.writeFileSync(path.join(any, 'ic_launcher.xml'), ad); fs.writeFileSync(path.join(any, 'ic_launcher_round.xml'), ad);
  console.log('Icônes Excellencia Building installées (' + n + ' fichiers).');
})();

/* Clavier : la fenêtre se redimensionne au-dessus du clavier (les champs de saisie restent visibles). */
(function () {
  const f2 = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
  if (!fs.existsSync(f2)) return;
  let m = fs.readFileSync(f2, 'utf8');
  if (!m.includes('windowSoftInputMode')) { m = m.replace('<activity', '<activity android:windowSoftInputMode="adjustResize"'); fs.writeFileSync(f2, m); console.log('AndroidManifest.xml : adjustResize ajouté.'); }
})();

/* Impression Android (V117d) : pont natif « ExbAndroidPrint » → boîte d'impression d'Android (Enregistrer au format PDF / imprimante).
 * Sans lui, les fenêtres d'impression du logiciel restaient blanches dans l'application. Écrit ExbPrint.java et branche MainActivity.java. */
(function () {
  const javaDir = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'java', 'com', 'excellencia', 'building');
  const main = path.join(javaDir, 'MainActivity.java');
  if (!fs.existsSync(main)) { console.log('Impression Android : MainActivity.java absent, ignoré.'); return; }
  const java = [
    'package com.excellencia.building;',
    '',
    'import android.app.Activity;',
    'import android.content.Context;',
    'import android.print.PrintAttributes;',
    'import android.print.PrintDocumentAdapter;',
    'import android.print.PrintManager;',
    'import android.webkit.JavascriptInterface;',
    'import android.webkit.WebView;',
    'import android.webkit.WebViewClient;',
    '',
    '/** Pont JavaScript → impression Android. Appelé par exb-print.js : ExbAndroidPrint.print(html, titre, urlDeBase). */',
    'public class ExbPrint {',
    '    private final Activity act;',
    '    private WebView keep; // garde la page vivante pendant la création du PDF',
    '    public ExbPrint(Activity a) { act = a; }',
    '',
    '    @JavascriptInterface',
    '    public void print(final String html, final String title, final String base) {',
    '        act.runOnUiThread(new Runnable() {',
    '            @Override public void run() {',
    '                try {',
    '                    final String name = (title == null || title.trim().isEmpty()) ? "Document" : title.trim();',
    '                    final boolean land = html != null && html.toLowerCase().contains("landscape");',
    '                    final WebView wv = new WebView(act);',
    '                    wv.getSettings().setJavaScriptEnabled(false);',
    '                    keep = wv;',
    '                    wv.setWebViewClient(new WebViewClient() {',
    '                        private boolean done = false;',
    '                        @Override public void onPageFinished(WebView v, String url) {',
    '                            if (done) return; done = true;',
    '                            try {',
    '                                PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);',
    '                                PrintDocumentAdapter ad = v.createPrintDocumentAdapter(name);',
    '                                PrintAttributes.Builder b = new PrintAttributes.Builder();',
    '                                b.setMediaSize(land ? PrintAttributes.MediaSize.ISO_A4.asLandscape() : PrintAttributes.MediaSize.ISO_A4);',
    '                                pm.print(name, ad, b.build());',
    '                            } catch (Exception e) { /* silencieux */ }',
    '                        }',
    '                    });',
    '                    wv.loadDataWithBaseURL(base == null || base.isEmpty() ? "https://localhost/" : base, html == null ? "" : html, "text/html", "UTF-8", null);',
    '                } catch (Exception e) { /* silencieux */ }',
    '            }',
    '        });',
    '    }',
    '}',
    ''
  ].join('\n');
  fs.mkdirSync(javaDir, { recursive: true });
  fs.writeFileSync(path.join(javaDir, 'ExbPrint.java'), java);
  let m = fs.readFileSync(main, 'utf8');
  if (m.includes('ExbAndroidPrint')) { console.log('Impression Android : MainActivity.java déjà branché.'); return; }
  const hook = '        try { getBridge().getWebView().addJavascriptInterface(new ExbPrint(this), "ExbAndroidPrint"); } catch (Exception e) { }\n';
  if (/super\.onCreate\([^)]*\);/.test(m)) {
    m = m.replace(/(super\.onCreate\([^)]*\);)/, '$1\n' + hook);
  } else {
    if (!/import android\.os\.Bundle;/.test(m)) m = m.replace(/(package [^;]+;)/, '$1\n\nimport android.os.Bundle;');
    const method = '\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n        super.onCreate(savedInstanceState);\n' + hook + '    }\n';
    m = m.replace(/\}\s*$/, method + '}\n');
  }
  fs.writeFileSync(main, m);
  console.log('Impression Android : ExbPrint.java ajouté et branché dans MainActivity.java.');
})();
