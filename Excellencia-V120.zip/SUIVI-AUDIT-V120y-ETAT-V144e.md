# Suivi de l'audit V120y — état dans la V144e

Légende : ✅ fait et vérifié en banc d'essai Chromium · 🟡 fait, à confirmer sur votre poste · ⏳ dépend d'une mesure chez vous

| Point de l'audit | État | Détail / preuve |
|---|---|---|
| 4.1 / P0 Dialogues natifs, rejeu de clic | ✅ | ≈ 55 appels migrés vers `await exbConfirm/exbPrompt`, rejeu supprimé. 2 `alert()` natifs volontaires (session expirée). Devis en double : « demande → réponse → enregistrement » sans exécution double (testé). |
| 4.2 Bouton `v77lift` (prompt 5,6 s) | ✅ | Plus de `prompt` dans `exb-v77.js` (formulaire intégré). |
| 4.3 / P2 Observateurs DOM | ✅ | v77 : ne traite que les nœuds ajoutés ; bigstore : idem, **et** ne se déconnecte plus (correction d'un défaut : photos affichées après le chargement gardaient un jeton `exbidb:`). Aucun balayage global. |
| 4.4 / P3 Démarrage | 🟡 | Mesuré : 16 tâches longues (max 289 ms, 3,5 s) → 8 (max 130 ms, 1,8 s) sur 800 clients / 400 chantiers / 1 500 écritures. `defer` en masse **non** appliqué (l'audit le déconseille : ordre des scripts). Chargement à la demande des modules secondaires : non fait, risque d'ordre ; à décider après vos mesures. |
| 4.5 / P4 IndexedDB | 🟡 | Lecture par curseur ; compaction seulement après 5 s sans saisie et au repos ; `EXBBIG.perf()` journalise lecture/écriture/compactage (≥ 300 ms → rapport de lenteur). Test stockage : photo 430 Ko compactée, plus de `data:` dans localStorage, restituée à l'écran après rechargement. |
| 4.6 / P5 Métré, FAB, listes | ✅ / 🟡 | Formateurs de nombres réutilisés ; listes limitées à 150 lignes + « Afficher plus » ; recherche client retardée. Métré : 10 lignes saisies → enregistrées → rechargement = valeurs identiques (testé). 100 lignes : ≈ 100 à 150 ms par modification (seuil audit 200 ms). |
| P1 Blocage « source inconnue » 4,8 s | ⏳ | Non reproduit ici. Diagnostic prêt (Ctrl + Alt + T puis Ctrl + Alt + L). |
| Seuil recherche < 300 ms | ✅ | 20 recherches successives : 280–292 ms anti-rebond compris. |
| Seuil tâche > 1 000 ms | ✅ | Aucune pendant le parcours testé. |
| Tests de réception Windows / Android, endurance 60 min, PDF avec photos | ⏳ | À faire chez vous (voir ci-dessous). |

## Après installation — ce qu'il faut m'envoyer
1. **Essai de 10 minutes** : Ctrl + Alt + T, travailler normalement (recherche, fiche client, devis, Métré), puis Ctrl + Alt + L → capture(s) du rapport.
2. **IndexedDB** : F12 → Console → `EXBBIG.perf()` → copier le résultat ; ajouter `EXBBIG.usage()`.
3. **Si un blocage persiste** : onglet Performance (F12), enregistrer pendant le blocage, exporter le profil (.json) ou capture.
4. **Matrice de réception** (cocher OK / KO + remarque) :
   - Recherche : client, projet, devis, apprenant, 20 fois de suite.
   - Fiche client : créer / modifier / annuler / enregistrer, saisie rapide puis lente, changement d'onglet.
   - Chantier : création (une seule), membres, étapes, notifications non bloquantes.
   - Équipement : QR, code manuel, annulation puis validation (caméra libérée).
   - Suppression : annuler (aucun effet), puis confirmer sur une copie.
   - Devis déjà existant (même client + projet) : « Mettre à jour » puis « Nouveau devis ».
   - Réception d'un bon de commande : saisie des quantités par ligne.
   - Métré : 100 lignes, modifier quantités/prix, enregistrer, fermer, rouvrir.
   - Images / plans : importer, attendre la compaction, fermer/rouvrir, **générer un PDF avec photo (fiche client, reçu)**, exporter et restaurer sur une copie.
   - Endurance 60 min, réseau coupé puis rétabli.
5. **Avant déploiement** : sauvegarde complète exportée, version précédente conservée (retour arrière).

## Point d'attention connu (non bloquant)
Les listes en mémoire (`exbClients`, etc.) peuvent contenir un jeton `exbidb:` tant qu'elles n'ont pas été relues ; l'affichage à l'écran est maintenant résolu automatiquement, mais **la génération de PDF/export directement depuis ces listes n'a pas pu être testée ici** : c'est le premier point à vérifier (photo sur fiche/reçu PDF).

## Consommation du forfait internet (signalée après l'audit)
Causes identifiées dans le code :
1. **Synchronisation en ligne (`exb-sync.js`)** : toutes les 60 s, 2 requêtes (licence + liste des clés du compte), en permanence, y compris application en arrière-plan ou rien de modifié. → V144e : aucune requête en arrière-plan ; vérification du serveur au plus toutes les 5 min quand rien n'a changé localement ; envoi dans la minute quand une donnée locale change ; reprise immédiate au retour au premier plan, au retour du réseau et via « Synchroniser ».
2. **Mises à jour de l'application** : chaque nouvelle version change le cache hors-ligne (`sw.js`, 282 fichiers, 13,6 Mo au total) ; le téléchargement dépend des fichiers modifiés (jusqu'à plusieurs Mo par appareil et par version). → Éviter d'installer chaque petite version sur les téléphones sur forfait ; regrouper les mises à jour.
3. **Envoi de données volumineuses** : toute clé modifiée est renvoyée en entier (ex. liste clients avec photos). Les photos lourdes augmentent le volume à chaque modification.
4. Météo de l'accueil : mise en cache, au plus 1 appel par période de rafraîchissement ; faible volume.
À vérifier chez vous : Paramètres Android / Windows → consommation de données par application, avant et après installation, pour confirmer le gain.
