/* Excellencia Building V205p — 🏦 GUICHET du comptable (V205n + recherche par nom + fonctionnement À DISTANCE avec compte de travail).
 * Pour les clients et apprenants qui paient SUR PLACE (sans téléphone, sans Mobile Money). Placé en tête de l'Espace Comptable › 🧾 Reçus de paiement.
 * Le comptable choisit le TYPE de paiement ; le payeur est choisi dans la bonne liste et ses coordonnées se chargent toutes seules :
 *   🎓 Formation TFL → apprenant (matricule, téléphone, formation, frais) ; reçu TFL habituel, statuts PAYÉ / MOITIÉ PAYÉE.
 *   📄 Devis / 🧾 Facture → client, projet, total convenu, déjà payé, reste ; reçu client (acompte / avancement / solde).
 *   🏗️ Client / chantier et ➕ Autre → coordonnées de la fiche client (ou saisie libre pour une personne de passage) ; reçu client.
 * Chaque encaissement est inscrit dans le registre local « exb_guichet » (caisse du jour). Pour les paiements de clients/devis, le chantier
 * (Conducteur + Chef de projet) est prévenu automatiquement par la messagerie privée, reçu PDF joint (si compte en ligne).
 * Les annonces « je passerai payer au guichet » faites par les clients en ligne (lot 9 SQL) sont listées plus bas. */
(function (w, d) {
  'use strict';
  var KEY = 'exb_guichet';
  var $ = function (i) { return d.getElementById(i); };
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function dg(v) { return String(v || '').replace(/\D/g, ''); }
  function lc(v) { return String(v || '').trim().toLowerCase(); }
  function num(v) { var n = parseFloat(String(v == null ? '' : v).replace(/[\s\u00a0]/g, '').replace(',', '.')); return isFinite(n) ? n : 0; }
  function r2(n) { return Math.round(n * 100) / 100; }
  function dev(x) { return String(x || '').toUpperCase() === 'FC' ? 'FC' : 'USD'; }
  function fmt(n, dv) { return Number(n || 0).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' ' + (dev(dv) === 'FC' ? 'FC' : '$'); }
  function today() { var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
  /* lecture / écriture par le pont de stockage commun (clés préfixées, repérées pour la sauvegarde et la synchronisation) */
  function rd(k) {
    try { if (w.EXBS && w.EXBS.get) return w.EXBS.get(k); } catch (e) { /* ignoré */ }
    try { if (typeof load === 'function') { var a = load(k, []); if (Array.isArray(a)) return a; } } catch (e) { /* ignoré */ }
    return [];
  }
  function wr(k, v) {
    try { if (w.EXBS && w.EXBS.set) return w.EXBS.set(k, v) !== false; } catch (e) { /* ignoré */ }
    try { if (typeof save === 'function') return save(k, v) !== false; } catch (e) { /* ignoré */ }
    return false;
  }
  function P() { try { return typeof participants !== 'undefined' && participants || []; } catch (e) { return []; } }
  function online() { try { return !!(w.exbSb && w.exbSb.isIn && w.exbSb.isIn()); } catch (e) { return false; } }
  function orgId() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info() || {}).org || ''; } catch (e) { return ''; } }
  function cName(c) { return String(c && (c.name || c.company || c.nom || c.client) || '').trim(); }

  var TYPES = [
    ['tfl', '🎓 Formation TFL (inscription / formation)'],
    ['devis', '📄 Devis (acompte, avancement, solde)'],
    ['facture', '🧾 Facture client'],
    ['client', '🏗️ Client / chantier (autre paiement)'],
    ['autre', '➕ Autre paiement (saisie libre)']
  ];
  var TFL_QUOI = [['insc', 'Inscription seule'], ['moitie', 'Moitié de la formation'], ['total', 'Formation en totalité'], ['insc_moitie', 'Inscription + moitié de la formation'], ['insc_total', 'Inscription + formation en totalité']];
  var MODES = [['caisse', 'Espèces'], ['mobile_money', 'Mobile Money (au guichet)'], ['banque', 'Virement / banque'], ['cheque', 'Chèque']];
  var S = { type: 'tfl', src: [], last: null, picked: null, hits: [] };

  /* ---------- V205p : TRAVAIL À DISTANCE (chacun son espace, son compte, sa synchronisation) ----------
   * Les apprenants et les étudiants TFL ne sont PAS dans la base centrale : ils restent dans la copie du compte qui les a saisis (Formation / Direction).
   * Un comptable qui se connecte à son propre espace ne les voit donc pas. Solution légère : un « ANNUAIRE du guichet » (collection partagée
   * « annuaire_guichet », clé locale exb_annuaire_guichet) où chaque compte qui détient des apprenants publie, automatiquement (photo : simple vignette de ≈150 px, V205r),
   * seulement : nom, matricule, téléphone, e-mail, formation, dossier approuvé ou non. Le comptable le lit après synchronisation.
   * Les clients, devis, factures, projets et le CRM sont déjà dans la base centrale. Le registre des encaissements (exb_guichet) l'est aussi
   * (collection « guichet_encaissements ») : la caisse du jour et le « déjà payé » sont les mêmes sur tous les appareils. SQL : lot 10. */
  var ANN = 'exb_annuaire_guichet';
  function canW(c) { try { return !!(w.EXBDB && w.EXBDB.can && w.EXBDB.can(c, 'ecrire')); } catch (e) { return false; } }
  function annuaire() { return rd(ANN).filter(function (x) { return x && x.nom; }); }
  function annSig(e) { return [e.kind, e.nom, e.matricule, e.tel, e.email, e.formation, e.approuve ? 1 : 0, e.ecole || '', (e.photo || '').length].join('|'); }
  /* V205r : photo de l'apprenant dans l'annuaire = simple VIGNETTE (≈150 px, JPEG léger, quelques Ko), pour que le reçu établi par le comptable porte la photo.
   * Calculée en arrière-plan puis publiée au passage suivant ; jamais l'original. Une photo qui n'est pas une image intégrée (data:) est ignorée. */
  var THUMB = {}, THUMB_BUSY = {};
  function vignette(p) {
    var src = String(p.photo || '').trim(); if (!/^data:image\/(jpe?g|png|webp|gif);base64,/i.test(src)) return '';
    var key = p.participant_id + '|' + src.length; if (THUMB[key] !== undefined) return THUMB[key];
    if (!THUMB_BUSY[key]) {
      THUMB_BUSY[key] = 1;
      try {
        var im = new Image();
        im.onload = function () {
          try { var k = Math.min(150 / im.naturalWidth, 190 / im.naturalHeight, 1), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
            var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
            var u = c.toDataURL('image/jpeg', .68); THUMB[key] = u.length <= 24000 ? u : ''; } catch (e) { THUMB[key] = ''; }
          setTimeout(publierAnnuaire, 50);
        };
        im.onerror = function () { THUMB[key] = ''; };
        im.src = src;
      } catch (e) { THUMB[key] = ''; }
    }
    return '';
  }
  function publierAnnuaire() {
    try {
      if (!online() || !orgId() || !canW('annuaire_guichet')) return 0;
      var cur = rd(ANN), by = {}, n = 0; cur.forEach(function (x) { if (x && x.id) by[x.id] = x; });
      function put(e) { var o = by[e.id]; if (o && annSig(o) === annSig(e)) return; if (o) { cur[cur.indexOf(o)] = e; } else { cur.push(e); } by[e.id] = e; n++; }
      P().forEach(function (p) {
        if (!p || !p.participant_id || !p.name) return;
        var ent = { id: 'APP-' + p.participant_id, kind: 'apprenant', nom: p.name, participant_id: p.participant_id, matricule: p.matricule_en_ligne || p.matricule || '', tel: p.phone || '', email: p.email || '', formation: p.training || '', approuve: p.approval_status === 'APPROUVE', statut: p.approval_status || '' }, vg = vignette(p); if (vg) ent.photo = vg; put(ent);
      });
      rd('exb_tfl_etudiants').forEach(function (e) {
        if (!e || !e.nom) return;
        put({ id: 'ETU-' + (e.id || norm(e.nom).replace(/\W+/g, '-')), kind: 'etudiant', nom: e.nom, matricule: e.matricule || '', tel: e.telephone || '', email: e.email || '', formation: '', ecole: e.universite || '', approuve: true });
      });
      if (n) wr(ANN, cur);
      return n;
    } catch (e) { return 0; }
  }
  /* l'apprenant de l'annuaire, rendu sous la forme d'un dossier (pour le reçu TFL) */
  function annP(e) { return { participant_id: e.participant_id || e.id, name: e.nom, phone: e.tel, email: e.email, training: e.formation, matricule: e.matricule, matricule_en_ligne: e.matricule, approval_status: e.approuve ? 'APPROUVE' : (e.statut || 'EN ATTENTE'), photo: e.photo || '', distant: true }; }
  function annLocal(e) { return P().some(function (p) { return (e.participant_id && p.participant_id === e.participant_id) || (norm(p.name) === norm(e.nom) && (p.matricule_en_ligne || p.matricule || '') === (e.matricule || '')); }); }

  /* ---------- V205o : RECHERCHE PAR NOM dans toute la base ----------
   * Le comptable tape quelques lettres (nom, prénom, matricule, téléphone, n° de devis/facture) : apprenants, clients, devis, factures,
   * prospects du CRM et étudiants TFL sont cherchés d'un coup. Un clic remplit le type de paiement et toutes les coordonnées.
   * Une personne absente de la base (de passage) est enregistrée comme client au premier encaissement : plus de ressaisie ensuite. */
  function norm(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function pushHit(L, seen, h) { var k = h.type + '|' + norm(h.nom) + '|' + (h.ref || ''); if (seen[k]) return; seen[k] = 1; L.push(h); }
  function buildHits(q) {
    var words = norm(q).split(' ').filter(Boolean), L = [], seen = {}; if (!words.length) return L;
    function ok(hay) { hay = norm(hay); return words.every(function (w2) { return hay.indexOf(w2) >= 0; }); }
    P().forEach(function (p, i) {
      if (ok([p.name, p.matricule, p.matricule_en_ligne, p.participant_id, p.phone, p.email, p.training].join(' ')))
        pushHit(L, seen, { type: 'tfl', badge: '🎓 Apprenant', nom: p.name || '—', ref: p.participant_id || String(i), sub: [p.training, p.matricule_en_ligne || p.matricule, p.phone].filter(Boolean).join(' · ') + (p.approval_status && p.approval_status !== 'APPROUVE' ? ' · ⚠ dossier non approuvé' : ''), item: { k: String(i), lib: p.name, p: p } });
    });
    annuaire().forEach(function (e) {
      if (!ok([e.nom, e.matricule, e.tel, e.email, e.formation, e.ecole].join(' '))) return;
      if (e.kind === 'apprenant') { if (annLocal(e)) return; var pp = annP(e);
        pushHit(L, seen, { type: 'tfl', badge: '🎓 Apprenant ☁', nom: e.nom, ref: pp.participant_id, sub: [e.formation, e.matricule, e.tel].filter(Boolean).join(' · ') + (e.approuve ? '' : ' · ⚠ dossier non approuvé'), item: { k: 'a:' + e.id, lib: e.nom, p: pp } }); }
      else pushHit(L, seen, { type: 'client', badge: '🎓 Étudiant TFL ☁', nom: e.nom, sub: [e.matricule, e.ecole, e.tel].filter(Boolean).join(' · '), item: { k: 'x', lib: e.nom, c: { name: e.nom, phone: e.tel || '', email: e.email || '', matricule: e.matricule || '' } } });
    });
    rd('exb_clients').forEach(function (c, i) {
      if (cName(c) && ok([cName(c), c.matricule, c.phone, c.tel, c.email, c.contact].join(' ')))
        pushHit(L, seen, { type: 'client', badge: '🏗️ Client', nom: cName(c), sub: [c.matricule, c.phone || c.tel, c.email].filter(Boolean).join(' · '), item: { k: String(i), lib: cName(c), c: c } });
    });
    rd('exb_finance').forEach(function (f, i) {
      if (f && (f.type === 'devis' || f.type === 'facture') && ok([f.no, f.client, f.title, f.label].join(' ')))
        pushHit(L, seen, { type: f.type, badge: f.type === 'devis' ? '📄 Devis' : '🧾 Facture', nom: f.client || '—', ref: f.no || String(i), sub: (f.no || '') + (Number(f.ttc) > 0 ? ' · ' + fmt(f.ttc, f.cur) : '') + (f.title || f.label ? ' · ' + (f.title || f.label) : ''), item: { k: String(i), lib: f.no, f: f } });
    });
    /* prospects / contacts du CRM et étudiants TFL : pas de liste dédiée au guichet, ils sont encaissés comme « client » */
    [['exb_crm_opps', 'client'], ['exb_crm', 'name'], ['exb_v92_crm', 'name']].forEach(function (src) {
      rd(src[0]).forEach(function (x) {
        var nm = String(x && (x.client || x.name || x.nom || x.company) || '').trim();
        if (nm && ok([nm, x.contact, x.phone, x.tel, x.email].join(' ')))
          pushHit(L, seen, { type: 'client', badge: '📇 Prospect / contact', nom: nm, sub: [x.contact, x.phone || x.tel, x.email].filter(Boolean).join(' · '), item: { k: 'x', lib: nm, c: { name: nm, phone: x.phone || x.tel || '', email: x.email || '', matricule: '' } } });
      });
    });
    rd('exb_tfl_etudiants').forEach(function (e) {
      if (e && e.nom && ok([e.nom, e.matricule, e.telephone, e.universite].join(' ')))
        pushHit(L, seen, { type: 'client', badge: '🎓 Étudiant TFL', nom: e.nom, sub: [e.matricule, e.universite, e.telephone].filter(Boolean).join(' · '), item: { k: 'x', lib: e.nom, c: { name: e.nom, phone: e.telephone || '', email: e.email || '', matricule: e.matricule || '' } } });
    });
    var rank = { tfl: 0, client: 1, devis: 2, facture: 3 };
    L.sort(function (a, b) { var A = norm(a.nom).indexOf(words[0]) === 0 ? 0 : 1, B = norm(b.nom).indexOf(words[0]) === 0 ? 0 : 1; return A - B || (rank[a.type] - rank[b.type]) || a.nom.localeCompare(b.nom); });
    return L;
  }
  function drawHits() {
    var box = $('gHits'); if (!box) return; var q = ($('gSearch') || {}).value || '';
    if (norm(q).length < 2) { box.innerHTML = ''; S.hits = []; return; }
    S.hits = buildHits(q); var L = S.hits.slice(0, 25);
    box.innerHTML = L.length ? '<div style="border:1px solid #d5dbe5;border-radius:10px;max-height:300px;overflow:auto">' + L.map(function (h, i) {
      return '<div data-ghit="' + i + '" role="button" tabindex="0" style="padding:8px 10px;border-bottom:1px solid #e5e9f0;cursor:pointer"><b>' + esc(h.nom) + '</b> <span class="hint">' + esc(h.badge) + '</span><div class="hint">' + esc(h.sub || '') + '</div></div>';
    }).join('') + (S.hits.length > L.length ? '<div class="hint" style="padding:6px 10px">+ ' + (S.hits.length - L.length) + ' autres : précisez la recherche.</div>' : '') + '</div>'
      : '<p class="hint">Personne trouvée avec « ' + esc(q) + ' » : aucune. C’est une personne de passage : choisissez le type de paiement ci-dessous et saisissez ses coordonnées (elle sera enregistrée dans la base clients pour la prochaine fois).</p>';
  }
  function pickHit(i) {
    var h = S.hits[Number(i)]; if (!h) return;
    S.type = h.type; $('gType').value = h.type; drawPick();
    S.picked = { type: h.type, item: h.item };
    var sel = $('gWho'); if (sel) { var opt = Array.prototype.filter.call(sel.options, function (o) { return o.value === h.item.k; })[0]; if (opt) { sel.value = h.item.k; S.picked = null; } }
    drawFields(details(h.type, h.item));
    $('gHits').innerHTML = ''; $('gSearch').value = h.nom;
    say('✓ ' + esc(h.nom) + ' chargé(e) depuis la base (' + esc(h.badge) + ') : vérifiez, saisissez le montant puis « Encaisser ».', true);
    $('gResult').innerHTML = '';
  }

  /* ---------- coordonnées chargées selon le modèle de paiement ---------- */
  function clientFiche(nom) { var n = lc(nom); return n ? (rd('exb_clients').filter(function (c) { return lc(cName(c)) === n; })[0] || null) : null; }
  function parseFee(s) { var t = String(s || ''); return { n: num(t.replace(/[^\d,.\s\u00a0]/g, '')), dev: /fc|cdf/i.test(t) ? 'FC' : 'USD', txt: t.trim() }; }
  function sources(type) {
    if (type === 'tfl') { var L0 = P().map(function (p, i) { return { k: String(i), lib: (p.name || '—') + (p.training ? ' · ' + p.training : ''), p: p }; });
      annuaire().filter(function (e) { return e.kind === 'apprenant' && !annLocal(e); }).forEach(function (e) { L0.push({ k: String(L0.length), lib: e.nom + (e.formation ? ' · ' + e.formation : '') + ' ☁', p: annP(e) }); }); return L0; }
    if (type === 'devis' || type === 'facture') return rd('exb_finance').filter(function (x) { return x && x.type === type; }).map(function (x, i) { return { k: String(i), lib: (x.no || '—') + ' · ' + (x.client || '—') + (Number(x.ttc) > 0 ? ' · ' + fmt(x.ttc, x.cur) : ''), f: x }; });
    if (type === 'client') return rd('exb_clients').map(function (c, i) { return { k: String(i), lib: cName(c) || '—', c: c }; }).filter(function (x) { return x.lib !== '—'; });
    return [];
  }
  function details(type, item) {
    var o = { nom: '', mat: '', tel: '', adr: '', proj: '', projId: '', ref: '', total: '', dev: 'USD' };
    if (!item) return o;
    if (type === 'tfl') { var p = item.p; o.nom = p.name || ''; o.mat = p.matricule_en_ligne || p.matricule || p.participant_id || ''; o.tel = p.phone || ''; o.adr = p.email || ''; o.proj = p.training || ''; o.ref = p.participant_id || p.matricule || ''; }
    else if (type === 'devis' || type === 'facture') {
      var f = item.f, c = clientFiche(f.client) || {}, pr = rd('exb_projects').filter(function (x) { return f.project && x.id === f.project; })[0] || {};
      o.nom = f.client || cName(c); o.mat = c.matricule || ''; o.tel = c.phone || c.tel || ''; o.adr = c.email || c.address || ''; o.proj = pr.name || f.title || f.label || ''; o.projId = pr.id || f.project || '';
      o.ref = (type === 'devis' ? 'Devis ' : 'Facture ') + (f.no || ''); o.total = Number(f.ttc) > 0 ? String(f.ttc) : ''; o.dev = dev(f.cur);
    } else if (type === 'client') { var q = item.c; o.nom = cName(q); o.mat = q.matricule || ''; o.tel = q.phone || q.tel || ''; o.adr = q.email || q.address || ''; }
    return o;
  }
  function projetsDe(nom) { var n = lc(nom); return rd('exb_projects').filter(function (p) { return n && lc(p.client) === n; }); }
  function dejaPaye(type, o, dv) {
    return rd(KEY).filter(function (x) { return x.statut !== 'annule' && x.type !== 'tfl' && x.devise === dv && (o.ref ? (x.ref === o.ref && lc(x.nom) === lc(o.nom)) : (lc(x.nom) === lc(o.nom) && (x.projet || '') === (o.proj || ''))); })
      .reduce(function (s, x) { return s + (Number(x.montant) || 0); }, 0);
  }

  /* ---------- interface ---------- */
  function opts(a, sel) { return a.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === sel ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }
  function mount() {
    var sec = $('receipts'); if (!sec || $('exbGuiCard')) return;
    var c = d.createElement('div'); c.id = 'exbGuiCard'; c.className = 'card no-print'; c.style.marginBottom = '14px';
    c.innerHTML = '<h2>🏦 Guichet — encaisser un paiement sur place</h2>' +
      '<p class="hint" style="margin:0 0 8px">Pour les clients et apprenants qui paient au guichet (sans téléphone). Choisissez le type de paiement : la liste et les coordonnées se chargent selon le modèle, puis « Encaisser » fait le reçu adapté.</p>' +
      '<label>🔎 Rechercher la personne qui paie (nom, matricule, téléphone, n° de devis/facture)</label><input id="gSearch" maxlength="80" autocomplete="off" placeholder="Tapez quelques lettres du nom…"/><div id="gHits" style="margin:4px 0 8px"></div>' +
      '<label>Type de paiement</label><select id="gType">' + opts(TYPES, S.type) + '</select>' +
      '<div id="gPick"></div><div id="gFields"></div>' +
      '<div class="actions" style="margin-top:8px"><button type="button" class="primary" id="gGo">💵 Encaisser et faire le reçu</button><button type="button" class="muted" id="gReset">Effacer</button></div>' +
      '<div id="gBanner" class="msg"></div><div id="gResult"></div>' +
      '<details style="margin-top:10px"><summary><b>📒 Caisse du guichet (aujourd’hui)</b></summary><div id="gCaisse" style="margin-top:6px"></div></details>' +
      '<details style="margin-top:6px" id="gAnnBox"><summary><b>📡 Clients qui ont annoncé leur passage (en ligne)</b> <span id="gAnnCnt" class="hint"></span></summary><div id="gAnn" style="margin-top:6px"></div><button type="button" class="muted" id="gAnnRef">↻ Actualiser</button></details>';
    sec.insertBefore(c, sec.firstChild);
    $('gType').onchange = function () { S.type = this.value; S.picked = null; drawPick(); };
    $('gHits').addEventListener('click', function (e) { var r = e.target.closest && e.target.closest('[data-ghit]'); if (r) pickHit(r.getAttribute('data-ghit')); });
    $('gHits').addEventListener('keydown', function (e) { if (e.key === 'Enter') { var r = e.target.closest && e.target.closest('[data-ghit]'); if (r) pickHit(r.getAttribute('data-ghit')); } });
    $('gGo').onclick = go; $('gReset').onclick = function () { S.picked = null; $('gSearch').value = ''; $('gHits').innerHTML = ''; drawPick(); $('gBanner').innerHTML = ''; $('gResult').innerHTML = ''; };
    $('gAnnRef').onclick = loadAnn; $('gAnn').addEventListener('click', annClick);
    c.addEventListener('input', onInput); c.addEventListener('change', onInput);
    drawPick(); drawCaisse();
  }
  function drawPick() {
    S.src = sources(S.type); var box = $('gPick'); if (!box) return;
    var vide = { tfl: 'Apprenant de passage (saisir)', devis: 'Client de passage (saisir)', facture: 'Client de passage (saisir)', client: 'Client de passage (saisir)' }[S.type];
    box.innerHTML = S.type === 'autre' ? '' :
      '<label>' + ({ tfl: 'Apprenant', devis: 'Devis', facture: 'Facture', client: 'Client' }[S.type]) + '</label><select id="gWho"><option value="">— ' + vide + ' —</option>' +
      S.src.map(function (x) { return '<option value="' + esc(x.k) + '">' + esc(x.lib) + '</option>'; }).join('') + '</select>' +
      (S.src.length ? '' : '<p class="hint">Aucun enregistrement dans cette liste : saisissez les coordonnées à la main.</p>');
    drawFields(details(S.type, null));
  }
  function drawFields(o) {
    var t = S.type, h = '<div class="two"><div><label>Nom &amp; prénom</label><input id="gNom" maxlength="120"/></div><div><label>Matricule</label><input id="gMat" maxlength="40"/></div></div>' +
      '<div class="two"><div><label>Téléphone</label><input id="gTel" maxlength="30" inputmode="tel"/></div><div><label>' + (t === 'tfl' ? 'E-mail' : 'Adresse / e-mail') + '</label><input id="gAdr" maxlength="160"/></div></div>' +
      '<label>' + (t === 'tfl' ? 'Formation' : (t === 'autre' ? 'Objet du paiement' : 'Projet / chantier')) + '</label><input id="gProj" maxlength="160"/>';
    if (t !== 'tfl' && t !== 'autre') h += '<div id="gProjSel"></div>';
    if (t === 'tfl') h += '<label>Ce qu’il paie</label><select id="gQuoi">' + opts(TFL_QUOI, 'insc') + '</select><div id="gTflInfo" class="hint" style="margin:4px 0"></div>';
    else h += '<div class="two"><div><label>Montant encaissé</label><input id="gMontant" inputmode="decimal"/></div><div><label>Devise</label><select id="gDev"><option>USD</option><option>FC</option></select></div></div>' +
      '<div class="two"><div><label>Total convenu (facultatif)</label><input id="gTotal" inputmode="decimal"/></div><div><label>Motif</label><select id="gMotif"><option value="auto">Automatique</option><option value="acompte">Acompte</option><option value="avancement">Avancement</option><option value="solde">Solde</option><option value="autre">Autre</option></select></div></div><div id="gReste" class="hint" style="margin:4px 0"></div>';
    h += '<div class="two"><div><label>Mode de paiement</label><select id="gMode">' + opts(MODES, 'caisse') + '</select></div><div><label>Référence / n° de transaction (si Mobile Money, banque, chèque)</label><input id="gRef2" maxlength="80"/></div></div>' +
      '<label>Guichetier (personne qui encaisse)</label><input id="gGuich" maxlength="80"/>';
    if (t !== 'tfl') h += '<label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" id="gChantier" checked style="width:auto"/> Prévenir automatiquement le chantier (Conducteur + Chef de projet)</label>';
    $('gFields').innerHTML = h;
    $('gNom').value = o.nom; $('gMat').value = o.mat; $('gTel').value = o.tel; $('gAdr').value = o.adr; $('gProj').value = o.proj;
    var g = ''; try { g = w.localStorage.getItem('EXB_GUICHETIER') || ''; } catch (e) { /* ignoré */ } $('gGuich').value = g;
    if (t !== 'tfl') { $('gDev').value = o.dev; $('gTotal').value = o.total; }
    if (t !== 'tfl' && t !== 'autre') projSel(o);
    calc();
  }
  function projSel(o) {
    var box = $('gProjSel'); if (!box) return; var L = projetsDe($('gNom').value);
    box.innerHTML = L.length > 1 || (L.length === 1 && !$('gProj').value) ? '<label>Projets de ce client</label><select id="gProjPick"><option value="">— choisir —</option>' + L.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.name || p.id) + '</option>'; }).join('') + '</select>' : '';
    if (L.length === 1 && !$('gProj').value) { $('gProj').value = L[0].name || ''; }
  }
  function tflLignes() {
    var q = ($('gQuoi') || {}).value || 'insc', ins = parseFee(($('registration_fee') || {}).value), frm = parseFee(($('training_fee') || {}).value), L = [];
    if (/^insc/.test(q) && ins.txt) L.push({ lib: 'Inscription', txt: ins.txt, n: ins.n, dev: ins.dev });
    if (q === 'moitie' || q === 'insc_moitie') L.push({ lib: 'Formation (moitié)', txt: fmt(frm.n / 2, frm.dev), n: r2(frm.n / 2), dev: frm.dev });
    if (q === 'total' || q === 'insc_total') L.push({ lib: 'Formation', txt: frm.txt, n: frm.n, dev: frm.dev });
    return L;
  }
  function calc() {
    if (S.type === 'tfl') {
      var i = $('gTflInfo'); if (!i) return; var L = tflLignes();
      i.innerHTML = L.length ? 'À encaisser : <b>' + L.map(function (x) { return esc(x.lib + ' ' + x.txt); }).join(' + ') + '</b> <span class="hint">(tarifs du formulaire de reçu ci-dessous)</span>' : 'Aucun tarif trouvé : renseignez les frais dans « Générer un reçu de paiement ».';
      return;
    }
    var r = $('gReste'); if (!r) return; var dv = $('gDev').value, tot = num($('gTotal').value), m = num($('gMontant').value);
    var o = { nom: $('gNom').value, proj: $('gProj').value, ref: curRef() }, avant = dejaPaye(S.type, o, dv);
    r.innerHTML = tot > 0 ? 'Déjà payé au guichet : <b>' + fmt(avant, dv) + '</b> · Reste après ce paiement : <b>' + fmt(Math.max(0, r2(tot - avant - m)), dv) + '</b>' : '';
  }
  function curItem() { var s = $('gWho'); if (s && s.value !== '') return S.src[Number(s.value)]; return S.picked && S.picked.type === S.type ? S.picked.item : null; }
  function curRef() { var it = curItem(); return it ? details(S.type, it).ref : ''; }
  function onInput(e) {
    var id = e.target && e.target.id;
    if (id === 'gSearch') { if (e.type === 'input') drawHits(); return; }   /* pas sur « change » : il part au clic sur un résultat et redessinerait la liste avant le clic */
    if (id === 'gWho') { S.picked = null; drawFields(details(S.type, curItem())); return; }
    if (id === 'gProjPick') { var p = rd('exb_projects').filter(function (x) { return x.id === e.target.value; })[0]; if (p) $('gProj').value = p.name || ''; return; }
    if (id === 'gNom' && S.type !== 'tfl' && S.type !== 'autre') projSel();
    if (/^g(Montant|Dev|Total|Quoi|Nom|Proj)$/.test(id || '')) calc();
  }

  /* ---------- encaisser ---------- */
  function nextNo(list) {
    var y = new Date().getFullYear(), pre = 'REC-GUI-' + y + '-', m = 0;
    list.forEach(function (x) { if (x.recu_no && x.recu_no.indexOf(pre) === 0) m = Math.max(m, parseInt(x.recu_no.slice(pre.length), 10) || 0); });
    return pre + ('0000' + (m + 1)).slice(-4);
  }
  function say(h, ok) { var b = $('gBanner'); if (b) b.innerHTML = '<span class="' + (ok ? 'valid' : 'ann') + '">' + h + '</span>'; }
  function modeLib(m) { return (MODES.filter(function (x) { return x[0] === m; })[0] || [0, m])[1]; }
  async function go() {
    var btn = $('gGo'); if (btn.disabled) return;
    var nom = $('gNom').value.trim(); if (!nom) return say('Indiquez le nom de la personne qui paie.');
    var g = $('gGuich').value.trim(); try { if (g) w.localStorage.setItem('EXB_GUICHETIER', g); } catch (e) { /* ignoré */ }
    btn.disabled = true;
    try { if (S.type === 'tfl') await goTfl(nom, g); else await goClient(nom, g); }
    catch (err) { say('Échec : ' + esc(err && err.message || err)); }
    btn.disabled = false;
  }
  function audit(a, t) { try { if (typeof w.audit === 'function') w.audit(a, t); } catch (e) { /* ignoré */ } }
  async function goTfl(nom, g) {
    var L = tflLignes(); if (!L.length) return say('Aucun tarif à encaisser : renseignez les frais dans « Générer un reçu de paiement ».');
    if (typeof w.prepareReceiptFromParticipant !== 'function' || typeof w.saveReceipt !== 'function') return say('Module de reçu TFL indisponible dans cette copie.');
    var it = curItem();
    if (!it) return say('Choisissez l’apprenant dans la liste : son dossier doit exister dans Formation › Apprenants (le reçu TFL est lié au dossier).');
    var p = it.p; nom = p.name || nom;
    if (p.approval_status !== 'APPROUVE') return say('Le dossier de <b>' + esc(nom) + '</b> doit d’abord être approuvé (Formation › Apprenants) avant de faire son reçu.');
    /* apprenant venu de l'annuaire partagé (compte distant) : le reçu TFL exige un dossier dans la copie locale → dossier minimal, approuvé à la source */
    if (p.distant && !P().some(function (x) { return x.participant_id === p.participant_id; })) {
      try { var stub = { participant_id: p.participant_id, name: p.name, phone: p.phone || '', email: p.email || '', training: p.training || '', matricule: p.matricule || '', matricule_en_ligne: p.matricule || '', approval_status: 'APPROUVE', photo: p.photo || '', created_at: new Date().toISOString(), source: 'annuaire_guichet' };
        participants.push(stub); save('exb_participants', participants); p = stub; } catch (e) { return say('Impossible de créer le dossier local de ' + esc(nom) + ' : ' + esc(e && e.message || e)); }
    }
    else if (p.distant && p.photo) { try { var loc = P().filter(function (x) { return x.participant_id === p.participant_id; })[0]; if (loc && !String(loc.photo || '').trim()) { loc.photo = p.photo; save('exb_participants', participants); } } catch (e) { /* photo facultative */ } }
    var q = $('gQuoi').value;
    w.prepareReceiptFromParticipant(p);
    $('registration_status').value = /^insc/.test(q) ? 'PAYÉ' : $('registration_status').value;
    $('training_status').value = (q === 'moitie' || q === 'insc_moitie') ? 'MOITIÉ PAYÉE' : (q === 'total' || q === 'insc_total') ? 'PAYÉ' : $('training_status').value;
    if ($('guichetier')) $('guichetier').value = g;
    var sel = $('receiptParticipantSelect');   /* le reçu TFL est lié au dossier choisi dans ce sélecteur */
    if (sel) { var pid = p.participant_id || ''; if (!Array.prototype.some.call(sel.options, function (o) { return o.value === pid; })) sel.add(new Option(nom, pid)); sel.value = pid; }
    /* le reçu TFL exige un paiement enregistré pour l'apprenant (Finances › Paiements) : le guichet le crée, comme le ferait le comptable à la main */
    try {
      var mt0 = L.reduce(function (s0, x) { return s0 + x.n; }, 0);
      if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.unshift({ payment_id: 'PAY-' + String(Date.now()), participant_id: p.participant_id, participant_name: nom, training: p.training || '', amount: r2(mt0), date: today(), method: modeLib($('gMode').value),
          reference: $('gRef2').value.trim() || (typeof w.generatePaymentReference === 'function' ? w.generatePaymentReference(p.participant_id) : 'GUI-' + Date.now()), note: 'Guichet — ' + L.map(function (x) { return x.lib + ' ' + x.txt; }).join(' + '), created_at: new Date().toISOString() });
        save('exb_payments', payments);
      }
    } catch (e) { /* le reçu dira ce qui manque */ }
    var before = rd('exb_receipts').length; w.saveReceipt();
    if (rd('exb_receipts').length <= before) return say('Aucun nouveau reçu créé (un reçu identique existe peut-être déjà, ou le formulaire de reçu ci-dessous est incomplet).');
    var no = $('receipt_no').value, mixed = L.some(function (x) { return x.dev !== L[0].dev; }), mt = L.reduce(function (s, x) { return s + x.n; }, 0);
    var rec = { id: 'GUI-' + no, type: 'tfl', date: today(), at: new Date().toISOString(), nom: nom, matricule: $('gMat').value.trim(), tel: $('gTel').value.trim(), ref: it ? details('tfl', it).ref : '', projet: p.training || '', quoi: q,
      lignes: L.map(function (x) { return x.lib + ' ' + x.txt; }), montant: mixed ? null : r2(mt), devise: mixed ? '' : L[0].dev, mode: $('gMode').value, reference: $('gRef2').value.trim(), guichetier: g, recu_no: no, statut: 'ok' };
    var all = rd(KEY); all.push(rec); wr(KEY, all); audit('GUICHET_ENCAISSÉ', 'TFL ' + no + ' — ' + nom);
    say('✓ Encaissé : ' + esc(nom) + ' — ' + esc(rec.lignes.join(' + ')) + '. Reçu TFL n° <b>' + esc(no) + '</b> enregistré (statuts mis à jour).', true);
    $('gResult').innerHTML = '<div class="actions"><button type="button" class="gold" id="gPdfTfl">📄 Exporter le reçu en PDF</button></div><p class="hint">Le reçu est aussi visible dans « Prévisualisation du reçu » plus bas.</p>';
    $('gPdfTfl').onclick = function () { if (typeof w.exportReceiptPdf === 'function') w.exportReceiptPdf(); };
    drawCaisse();
  }
  async function goClient(nom, g) {
    var dv = $('gDev').value, m = r2(num($('gMontant').value)); if (!(m > 0)) return say('Indiquez le montant encaissé.');
    if (!w.EXBRecuClient || !w.EXBRecuClient.make) return say('Module de reçu client indisponible dans cette copie.');
    var it = curItem(), det = it ? details(S.type, it) : { ref: '' }, all = rd(KEY), proj = $('gProj').value.trim(), tot = r2(num($('gTotal').value)) || null;
    var o = { nom: nom, proj: proj, ref: det.ref || '' }, avant = dejaPaye(S.type, o, dv), solde = tot ? Math.max(0, r2(tot - avant - m)) : null;
    var mo = $('gMotif').value, motif = mo !== 'auto' ? mo : (solde != null && solde <= 0.005 ? 'solde' : avant > 0 ? 'avancement' : 'acompte');
    var mode = $('gMode').value, ref2 = $('gRef2').value.trim(), no = nextNo(all);
    var data = { recu_no: no, date: today(), devise: dv, client: nom, matricule: $('gMat').value.trim(), tel: $('gTel').value.trim(), adresse: $('gAdr').value.trim(), projet: proj,
      contrat: det.ref || (S.type === 'autre' ? '' : ''), motif: motif, motifAutre: motif === 'autre' ? (S.type === 'autre' ? proj : '') : '', montant: m, mode: mode === 'cheque' ? 'autre' : mode,
      reference: (mode === 'cheque' ? 'Chèque ' : '') + ref2, trans_no: ref2, total: tot, dejaPaye: tot ? avant : null, solde: solde, caisse: g, agence: 'Guichet' };
    var blob = await w.EXBRecuClient.make(data);
    var nouveau = enregistrerClient(nom, data);
    var rec = { id: no, type: S.type, date: today(), at: new Date().toISOString(), nom: nom, matricule: data.matricule, tel: data.tel, ref: det.ref || '', projet: proj, projetId: det.projId || '', motif: motif, montant: m, devise: dv, total: tot, solde: solde,
      mode: mode, reference: ref2, guichetier: g, recu_no: no, statut: 'ok' };
    all.push(rec); wr(KEY, all); audit('GUICHET_ENCAISSÉ', no + ' — ' + nom + ' — ' + fmt(m, dv));
    var url = URL.createObjectURL(blob), fn = no + '.pdf';
    say('✓ Encaissé : <b>' + esc(fmt(m, dv)) + '</b> de ' + esc(nom) + ' (' + esc(motif) + '). Reçu n° <b>' + esc(no) + '</b>' + (solde != null ? ' · reste ' + esc(fmt(solde, dv)) : '') + '.' + (nouveau ? ' <i>' + esc(nom) + ' est maintenant dans la base clients : on le retrouvera par la recherche.</i>' : ''), true);
    $('gResult').innerHTML = '<div class="actions"><a class="gold" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + url + '" target="_blank" rel="noopener">📄 Ouvrir le reçu</a> <a class="muted" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + url + '" download="' + esc(fn) + '">⬇️ Télécharger</a> <button type="button" class="muted" id="gMsgDoc">✉️ Envoyer à un autre espace</button></div><div id="gNotif" class="hint" style="margin-top:6px"></div>';
    $('gMsgDoc').onclick = function () { if (w.EXBMessagerie && w.EXBMessagerie.envoyerDocument) w.EXBMessagerie.envoyerDocument(blob, { titre: 'Reçu ' + no + ' — ' + nom, filename: fn }); };
    drawCaisse();
    var chk = $('gChantier'); if (chk && chk.checked) await prevenirChantier(rec, blob, fn);
  }
  /* personne de passage (absente de la base) : fiche créée dans « exb_clients » pour ne plus jamais la ressaisir */
  function enregistrerClient(nom, data) {
    try {
      if (clientFiche(nom)) return false;
      var L = rd('exb_clients'), mail = /@/.test(data.adresse || '');
      L.push({ id: 'CLI-GUI-' + Date.now(), name: nom, phone: data.tel || '', email: mail ? data.adresse : '', address: mail ? '' : (data.adresse || ''), matricule: data.matricule || '', source: 'guichet', created_at: new Date().toISOString() });
      return wr('exb_clients', L);
    } catch (e) { return false; }
  }
  async function prevenirChantier(rec, blob, fn) {
    var n = $('gNotif'); if (!n) return;
    if (!w.EXBMessagerie || !w.EXBMessagerie.notifier) { n.textContent = '⚠ Chantier non prévenu : messagerie indisponible dans cette copie.'; return; }
    var txt = 'Le client ' + rec.nom + ' a payé ' + fmt(rec.montant, rec.devise) + ' au guichet du comptable (' + rec.motif + (rec.ref ? ', ' + rec.ref : '') + (rec.projet ? ', projet ' + rec.projet : '') + ').' +
      (rec.solde != null ? ' Reste à payer : ' + fmt(rec.solde, rec.devise) + '.' : '') + ' Reçu n° ' + rec.recu_no + (rec.guichetier ? ' — encaissé par ' + rec.guichetier : '') + '.';
    try { var how = await w.EXBMessagerie.notifier(['conducteur', 'chef_projet'], '💰 Paiement client — ' + rec.nom, txt, blob, fn); n.textContent = how === 'srv' ? '✓ Chantier prévenu (Conducteur + Chef de projet), reçu joint.' : '✓ Chantier prévenu sur cet appareil seulement (sans compte en ligne, le message ne part pas vers les autres comptes).'; }
    catch (e) { n.textContent = '⚠ Chantier non prévenu : ' + (e && e.message || e); }
  }

  /* ---------- caisse du jour ---------- */
  function drawCaisse() {
    var box = $('gCaisse'); if (!box) return; var t = today(), L = rd(KEY).filter(function (x) { return x.date === t && x.statut !== 'annule'; }), tot = {};
    L.forEach(function (x) { if (x.montant != null && x.devise) tot[x.devise] = (tot[x.devise] || 0) + Number(x.montant); });
    box.innerHTML = L.length ? '<p><b>' + (Object.keys(tot).map(function (k) { return esc(fmt(tot[k], k)); }).join(' · ') || '—') + '</b> encaissés · ' + L.length + ' opération(s)</p>' +
      L.slice().reverse().slice(0, 15).map(function (x) { return '<div class="hint" style="border-bottom:1px solid #e5e9f0;padding:3px 0">' + esc(x.recu_no) + ' · ' + esc(x.nom) + ' · ' + esc(x.type === 'tfl' ? (x.lignes || []).join(' + ') : fmt(x.montant, x.devise)) + ' · ' + esc(modeLib(x.mode)) + '</div>'; }).join('') : '<p class="hint">Aucun encaissement au guichet aujourd’hui.</p>';
  }

  /* ---------- annonces des clients en ligne (lot 9 SQL) ---------- */
  var ann = [];
  async function loadAnn() {
    var L = $('gAnn'); if (!L) return;
    if (!online() || !orgId() || !(w.EXBDB && w.EXBDB.rpc)) { L.innerHTML = '<p class="hint">Connectez-vous (en ligne) pour voir les clients qui ont annoncé leur passage au guichet.</p>'; return; }
    try { var r = await w.EXBDB.rpc('client_guichet_a_encaisser', { p_org: orgId() }); ann = Array.isArray(r) ? r : []; drawAnn(); }
    catch (e) { L.innerHTML = '<p class="ann">Lecture impossible : ' + esc(e && e.message || e) + ' — exécutez migration-v205-lot9-guichet-comptable-notif-chantier.sql dans Supabase.</p>'; }
  }
  function drawAnn() {
    var L = $('gAnn'); if (!L) return; $('gAnnCnt').textContent = ann.length ? '(' + ann.length + ')' : '';
    L.innerHTML = ann.length ? ann.map(function (x) {
      return '<div style="border:1px solid #d5dbe5;border-radius:10px;padding:8px;margin:6px 0" data-id="' + esc(x.id) + '"><b>' + esc(x.client || x.portail || '—') + '</b> · <b>' + esc(fmt(x.montant, x.devise)) + '</b>' + (x.facture ? ' · facture ' + esc(x.facture) : '') +
        ' <small class="hint">' + esc(new Date(x.cree_le).toLocaleString('fr-FR')) + ' · annonce ' + esc(x.annonce || '') + '</small><div style="margin-top:6px"><button type="button" data-gann="ok" style="background:#18733b;color:#fff">✓ Il a payé — encaissé</button></div></div>';
    }).join('') : '<p class="hint">Aucune annonce en attente.</p>';
  }
  async function annClick(e) {
    var b = e.target.closest && e.target.closest('button[data-gann]'); if (!b) return;
    var h = b.closest('[data-id]'), id = h && h.getAttribute('data-id'), x = ann.filter(function (a) { return String(a.id) === String(id); })[0]; if (!x) return;
    b.disabled = true;
    try {
      var r = await w.EXBDB.rpc('client_guichet_encaisser', { p_org: orgId(), p_id: id, p_montant: null });
      say('✓ Encaissé : ' + esc(fmt(x.montant, x.devise)) + ' de ' + esc(x.client || '') + (r && r.recu_no ? ' (reçu ' + esc(r.recu_no) + ')' : '') + '. Le chantier a été prévenu automatiquement par le serveur. Le reçu PDF se fait dans Portails &amp; signatures › Paiements.', true);
      await loadAnn();
    } catch (err) { b.disabled = false; say('Échec : ' + esc(err && err.message || err)); }
  }

  /* publication de l'annuaire : à l'ouverture, puis toutes les 45 s (ne fait rien si rien n'a changé, ni sans droit d'écriture) */
  try { setTimeout(publierAnnuaire, 9000); setInterval(function () { if (!d.hidden) publierAnnuaire(); }, 45000); } catch (e) { /* ignoré */ }

  var _show = w.show;
  if (typeof _show === 'function') w.show = function (x) { var r = _show.apply(this, arguments); if (x === 'receipts') { try { mount(); if ($('gType')) { drawCaisse(); if (!$('gNom') || !$('gNom').value) drawPick(); } loadAnn(); publierAnnuaire(); } catch (e) { /* ignoré */ } } return r; };
  w.exbGuichet = { mount: mount, load: loadAnn, publierAnnuaire: publierAnnuaire, annuaire: annuaire };
})(window, document);
