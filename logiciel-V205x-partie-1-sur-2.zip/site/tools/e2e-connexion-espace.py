# V205l — Écran de connexion d'espace (/comptable, /ingenieur…) : connexion, première connexion, mot de passe oublié,
# rattachement à l'entreprise, contrôle de la fonction. Serveur Supabase SIMULÉ (aucun appel réseau réel).
import http.server, threading, functools, os, sys, json, re
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)

# ---------- faux serveur ----------
class Fake:
    def __init__(self):
        self.users = {}      # email -> {pw, confirmed, org(dict|None)}
        self.autoconfirm = True
        self.invites = {'mail-compta@x.cd': 'comptable'}   # e-mail invité -> fonction
        self.codes = {'abcd1234': 'comptable'}
        self.calls = []
    def org(self, fonction, role='editeur'):
        return {'id': 'ORG-1', 'nom': 'Entreprise Test', 'role': role, 'fonction': fonction, 'code': 'abcd1234'}
F = Fake()
CORS = {'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*'}
def token_of(email): return 'tok-' + email
def email_of(auth):
    m = re.match(r'Bearer tok-(.+)', auth or ''); return m.group(1) if m else None
def handler(route, request):
    u = request.url; m = request.method
    if m == 'OPTIONS': return route.fulfill(status=204, headers=CORS)
    path = u.split('.supabase.co', 1)[1]; F.calls.append(m + ' ' + path.split('?')[0])
    try: body = json.loads(request.post_data or '{}')
    except Exception: body = {}
    def J(obj, status=200): return route.fulfill(status=status, headers=dict(CORS, **{'content-type': 'application/json'}), body=json.dumps(obj))
    if path.startswith('/auth/v1/token'):
        us = F.users.get(body.get('email'))
        if not us or us['pw'] != body.get('password'): return J({'error': 'invalid_grant', 'error_description': 'Invalid login credentials'}, 400)
        if not us['confirmed']: return J({'error': 'invalid_grant', 'error_description': 'Email not confirmed'}, 400)
        return J({'access_token': token_of(body['email']), 'refresh_token': 'ref', 'expires_in': 3600})
    if path.startswith('/auth/v1/signup'):
        em = body.get('email')
        if em in F.users: return J({'id': 'x', 'email': em, 'identities': []})
        F.users[em] = {'pw': body.get('password'), 'confirmed': F.autoconfirm, 'org': None, 'name': (body.get('data') or {}).get('full_name')}
        if F.autoconfirm: return J({'access_token': token_of(em), 'refresh_token': 'ref', 'expires_in': 3600, 'user': {'email': em}})
        return J({'id': 'u1', 'email': em, 'identities': [{'id': 'i'}]})
    if path.startswith('/auth/v1/recover'): return J({})
    if path.startswith('/auth/v1/user'):
        em = email_of(request.headers.get('authorization'))
        if not em or em not in F.users: return J({'msg': 'bad jwt'}, 401)
        if m == 'PUT':
            if body.get('password') == F.users[em]['pw']: return J({'error_code': 'same_password', 'msg': 'New password should be different from the old password.'}, 422)
            F.users[em]['pw'] = body.get('password'); return J({'email': em})
        return J({'id': 'u-' + em, 'email': em})
    if path.startswith('/rest/v1/rpc/'):
        em = email_of(request.headers.get('authorization')); fn = path.split('/rpc/')[1].split('?')[0]
        if not em or em not in F.users: return J({'message': 'JWT invalid'}, 401)
        us = F.users[em]
        if fn == 'equipe_reclamer':
            if not us['org'] and em in F.invites: us['org'] = F.org(F.invites[em])
            return J({'ok': True})
        if fn == 'mon_organisation': return J(us['org'])
        if fn == 'rejoindre_organisation':
            f = F.codes.get(body.get('p_code'))
            if not f: return J({'message': 'Code invalide'}, 400)
            us['org'] = F.org(f); return J(us['org'])
        return J({})
    return J([])   # enregistrements, droits_fonction, membres… : listes vides

def new_page(b, js_errs):
    ctx = b.new_context(viewport={'width': 390, 'height': 800}); pg = ctx.new_page()
    pg.route('**/*.supabase.co/**', handler)
    pg.on('pageerror', lambda e: js_errs.append(str(e)[:200]))
    pg.add_init_script("try{sessionStorage.removeItem('exb_gate_bypass')}catch(e){}")
    return ctx, pg
def open_space(pg, url='comptable.html'):
    pg.goto(BASE + url); pg.wait_for_timeout(2500)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')
def gate_text(pg): return pg.evaluate("(document.getElementById('exbGate')||{}).innerText||''")
def fill_login(pg, em, pw):
    pg.fill('#gm', em); pg.fill('#gp', pw); pg.click('#gok'); pg.wait_for_timeout(1800)
def app_open(pg): return pg.evaluate("(()=>{const a=document.getElementById('app');return !!a&&getComputedStyle(a).display!=='none'&&!document.getElementById('exbGate')})()")

with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    F.users['compta@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': F.org('comptable')}
    F.users['magasin@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': F.org('magasinier')}
    F.users['admin@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': F.org('polyvalent', 'admin')}
    F.users['seul@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': None}
    F.users['poly@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': F.org('polyvalent')}

    # 1. l'écran apparaît à la place de la connexion locale
    ctx, pg = new_page(b, errs); open_space(pg)
    gt = gate_text(pg)
    t(pg.evaluate("!!document.getElementById('exbGate')"), 'le lien /comptable affiche l\'écran de connexion d\'espace')
    t('Espace Comptable' in gt and 'Gestion financière' in gt, 'l\'écran annonce « Espace Comptable » et son rôle')
    t('Se connecter' in gt and 'Première connexion' in gt and 'Mot de passe oublié' in gt, 'onglets Se connecter / Première connexion et lien Mot de passe oublié')
    t(pg.evaluate("document.getElementById('loginScreen').hasAttribute('inert')&&document.getElementById('app').hasAttribute('inert')"), 'l\'appli et la connexion locale sont inertes derrière l\'écran')
    t(pg.evaluate("document.getElementById('gp').getAttribute('autocomplete')") == 'current-password' and pg.evaluate("document.getElementById('gm').getAttribute('autocomplete')") == 'username', 'champs compatibles gestionnaires de mots de passe')
    pg.click('#gok'); t('Saisissez votre adresse e-mail' in gate_text(pg), 'champs vides : message clair')
    fill_login(pg, 'compta@x.cd', 'mauvais'); t('incorrect' in gate_text(pg), 'mauvais mot de passe : « E-mail ou mot de passe incorrect »')
    t(pg.evaluate("!!document.getElementById('exbGate')") and not app_open(pg), 'la porte reste fermée après un échec')
    fill_login(pg, 'compta@x.cd', 'Secret#2026')
    t(app_open(pg), 'le comptable rattaché entre dans son espace')
    t(pg.evaluate("EXBDB.info().fonction") == 'comptable' and pg.evaluate("EXBDB.info().on") is True, 'le compte est adopté : entreprise + fonction « comptable »')
    t(pg.evaluate("EXB_SHELL.espace()") == 'comptable' and pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'l\'Espace Comptable est actif et accessible')
    t('EXB_SB_TOKEN' in pg.evaluate("Object.keys(localStorage).join(',')"), 'la session en ligne est conservée')
    t('Secret#2026' not in pg.evaluate("JSON.stringify(Object.assign({},localStorage))+JSON.stringify(Object.assign({},sessionStorage))"), 'aucun mot de passe n\'est stocké')
    t(any('mon_organisation' in c for c in F.calls) and any('equipe_reclamer' in c for c in F.calls), 'rattachement demandé au serveur (equipe_reclamer, mon_organisation)')
    # session ouverte : rechargement sans nouvelle porte
    pg.reload(); pg.wait_for_timeout(2500)
    t(not pg.evaluate("!!document.getElementById('exbGate')"), 'rechargement avec session valide : pas de nouvel écran de connexion')
    # déconnexion : la porte se referme
    pg.evaluate("logout()"); pg.wait_for_timeout(3000); pg.add_style_tag(content='#exbLicLock{display:none!important}')
    t(pg.evaluate("!!document.getElementById('exbGate')") and not pg.evaluate("localStorage.getItem('EXB_SB_TOKEN')"), 'après déconnexion : session en ligne effacée et écran de connexion de l\'espace de nouveau affiché')
    t('compta@x.cd' in pg.evaluate("document.getElementById('gm').value"), 'l\'adresse e-mail est préremplie (pas le mot de passe)')
    ctx.close()

    # 2. fonction non admise
    ctx, pg = new_page(b, errs); open_space(pg)
    fill_login(pg, 'magasin@x.cd', 'Secret#2026'); gt = gate_text(pg)
    t('Accès refusé à cet espace' in gt and 'Magasinier' in gt and 'Comptable' in gt, 'un magasinier est refusé dans l\'Espace Comptable (fonction et fonctions admises affichées)')
    t(pg.evaluate("document.querySelector('[data-go]').getAttribute('data-go')") == 'magasin.html', 'bouton « Ouvrir mon espace » vers /magasin')
    t(not app_open(pg), 'l\'application reste fermée')
    pg.click('[data-act="out"]'); pg.wait_for_timeout(400)
    t('Se connecter' in gate_text(pg) and not pg.evaluate("localStorage.getItem('EXB_SB_TOKEN')"), 'se déconnecter / changer de compte : retour à la connexion, session effacée')
    fill_login(pg, 'poly@x.cd', 'Secret#2026'); t('Aucun espace dédié' in gate_text(pg), 'fonction « polyvalent » : message sans bouton trompeur')
    ctx.close()

    # 2b. V205v : la fonction vient de l'invitation (pas de l'espace) ; l'administrateur corrige, la personne touche « réessayer »
    ctx, pg = new_page(b, errs); open_space(pg)
    fill_login(pg, 'magasin@x.cd', 'Secret#2026'); gt = gate_text(pg)
    t('pas choisie par l’espace' in gt and 'Équipe › Fonction' in gt and pg.query_selector('[data-act="retry"]') is not None, 'accès refusé : explique que la fonction vient de l\'invitation de l\'administrateur + bouton « réessayer »')
    F.users['magasin@x.cd']['org']['fonction'] = 'comptable'      # l'administrateur corrige la fonction dans Équipe
    pg.click('[data-act="retry"]'); pg.wait_for_timeout(2500)
    t(app_open(pg) and pg.evaluate("EXBDB.info().fonction") == 'comptable', 'après correction : « réessayer » ouvre l\'espace sans recréer le compte')
    F.users['magasin@x.cd']['org']['fonction'] = 'magasinier'
    ctx.close()

    # 3. l'administrateur passe partout
    ctx, pg = new_page(b, errs); open_space(pg, 'magasin.html'); t('Espace Magasin' in gate_text(pg), 'le lien /magasin annonce l\'Espace Magasin')
    fill_login(pg, 'admin@x.cd', 'Secret#2026'); t(app_open(pg), 'l\'administrateur entre dans n\'importe quel espace')
    ctx.close()

    # 4. compte sans entreprise : code d'invitation
    ctx, pg = new_page(b, errs); open_space(pg)
    fill_login(pg, 'seul@x.cd', 'Secret#2026'); gt = gate_text(pg)
    t('Compte non rattaché' in gt and 'seul@x.cd' in gt, 'compte sans entreprise : explication et champ « code d\'invitation »')
    pg.fill('#gi', 'faux-code'); pg.click('#gok'); pg.wait_for_timeout(500); t('lettres et chiffres uniquement' in gate_text(pg), 'code mal formé refusé avant l\'envoi')
    pg.fill('#gi', 'fauxcode'); pg.click('#gok'); pg.wait_for_timeout(1800); t('Compte non rattaché' in gate_text(pg) and 'Code invalide' in gate_text(pg), 'mauvais code refusé par le serveur')
    pg.fill('#gi', 'ABCD1234'); pg.click('#gok'); pg.wait_for_timeout(2000); t(app_open(pg), 'bon code d\'invitation (casse ignorée) : rattaché et entré')
    ctx.close()

    # 5. première connexion (confirmation désactivée) avec l'e-mail invité
    ctx, pg = new_page(b, errs); open_space(pg)
    pg.click('[data-v="first"]'); pg.wait_for_timeout(300)
    t('adresse e-mail indiquée dans votre invitation' in gate_text(pg), 'onglet « Première connexion » : consigne claire')
    pg.fill('#gn', 'Mireille K.'); pg.fill('#gm', 'mail-compta@x.cd'); pg.fill('#gp', 'court'); pg.fill('#gc', 'court'); pg.click('#gok')
    t('8 caractères minimum' in gate_text(pg), 'mot de passe trop court refusé avant l\'envoi')
    pg.fill('#gp', 'NouveauPass#1'); pg.fill('#gc', 'Autre#1'); pg.click('#gok'); t('pas identiques' in gate_text(pg), 'confirmation différente refusée')
    pg.fill('#gc', 'NouveauPass#1'); pg.click('#gok'); pg.wait_for_timeout(2200)
    t(app_open(pg) and pg.evaluate("EXBDB.info().fonction") == 'comptable', 'compte créé avec l\'e-mail invité : rattaché automatiquement avec la fonction « comptable »')
    t(F.users['mail-compta@x.cd']['name'] == 'Mireille K.', 'le nom complet est transmis au serveur')
    ctx.close()

    # 6. première connexion avec confirmation par e-mail, puis lien de confirmation
    F.autoconfirm = False
    ctx, pg = new_page(b, errs); open_space(pg)
    pg.click('[data-v="first"]'); pg.fill('#gn', 'Test'); pg.fill('#gm', 'nouveau@x.cd'); pg.fill('#gp', 'NouveauPass#1'); pg.fill('#gc', 'NouveauPass#1'); pg.click('#gok'); pg.wait_for_timeout(1800)
    t('Confirmez votre adresse e-mail' in gate_text(pg) and 'nouveau@x.cd' in gate_text(pg), 'confirmation par e-mail requise : écran d\'attente explicite')
    pg.click('[data-v="login"]'); fill_login(pg, 'nouveau@x.cd', 'NouveauPass#1'); t('pas encore confirmée' in gate_text(pg), 'connexion avant confirmation : message en français')
    F.users['nouveau@x.cd']['confirmed'] = True; F.invites['nouveau@x.cd'] = 'comptable'
    pg.goto(BASE + 'comptable.html#access_token=tok-nouveau@x.cd&refresh_token=r&expires_in=3600&type=signup'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')
    t(app_open(pg), 'le lien de confirmation reçu par e-mail connecte directement à l\'espace')
    t('access_token' not in pg.url, 'le jeton est retiré de l\'adresse')
    pg.evaluate("logout()"); pg.wait_for_timeout(3000); pg.add_style_tag(content='#exbLicLock{display:none!important}')
    # adresse déjà inscrite (serveur qui masque l'existence du compte)
    pg.wait_for_timeout(1500); pg.click('[data-v="first"]'); pg.fill('#gn', 'Autre'); pg.fill('#gm', 'compta@x.cd'); pg.fill('#gp', 'NouveauPass#1'); pg.fill('#gc', 'NouveauPass#1'); pg.click('#gok'); pg.wait_for_timeout(1800)
    t('a peut-être déjà un compte' in gate_text(pg) and pg.evaluate("document.querySelector('[data-v=\"login\"]').classList.contains('on')"), 'adresse déjà inscrite : renvoi vers « Se connecter »')
    F.autoconfirm = True
    ctx.close()

    # 7. mot de passe oublié + lien de réinitialisation
    ctx, pg = new_page(b, errs); open_space(pg)
    pg.click('[data-v="forgot"]'); pg.fill('#gm', 'inconnu@x.cd'); pg.click('#gok'); pg.wait_for_timeout(1200)
    t('Vérifiez votre boîte e-mail' in gate_text(pg) and 'Si un compte existe' in gate_text(pg), 'mot de passe oublié : même réponse que le compte existe ou non')
    t(any('/auth/v1/recover' in c for c in F.calls), 'demande envoyée au serveur')
    pg.goto(BASE + 'comptable.html#access_token=tok-compta@x.cd&refresh_token=r&expires_in=3600&type=recovery'); pg.wait_for_timeout(3000)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')
    t('Nouveau mot de passe' in gate_text(pg), 'lien de réinitialisation : écran « Nouveau mot de passe » dans le même espace')
    pg.fill('#gp', 'Secret#2026'); pg.fill('#gc', 'Secret#2026'); pg.click('#gok'); pg.wait_for_timeout(1200)
    t('différent' in gate_text(pg), 'même mot de passe que l\'ancien : message en français')
    pg.fill('#gp', 'Reinit#2026a'); pg.fill('#gc', 'Reinit#2026a'); pg.click('#gok'); pg.wait_for_timeout(2500)
    t(app_open(pg) and F.users['compta@x.cd']['pw'] == 'Reinit#2026a', 'nouveau mot de passe enregistré, puis entrée dans l\'espace')
    pg.goto(BASE + 'comptable.html#error_code=otp_expired&error_description=Email+link+is+invalid+or+has+expired'); pg.wait_for_timeout(2500)
    t('a expiré' in gate_text(pg), 'lien expiré : message clair')
    ctx.close()

    # 8. verrouillage local après 5 échecs
    ctx, pg = new_page(b, errs); open_space(pg)
    for _ in range(5): fill_login(pg, 'compta@x.cd', 'faux')
    pg.fill('#gm', 'compta@x.cd'); pg.fill('#gp', 'faux'); pg.click('#gok'); pg.wait_for_timeout(300)
    t('Trop d’échecs' in gate_text(pg), 'après 5 échecs : attente imposée avant un nouvel essai')
    ctx.close()

    # 9. ingénieur : autre espace, même écran
    F.users['ing@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': F.org('bureau_etudes')}
    ctx, pg = new_page(b, errs); open_space(pg, 'ingenieur.html'); t('Espace Ingénieur' in gate_text(pg), 'le lien /ingenieur annonce l\'Espace Ingénieur')
    fill_login(pg, 'ing@x.cd', 'Secret#2026'); t(app_open(pg) and pg.evaluate("EXB_SHELL.espace()") == 'ingenieur', 'un bureau d\'études entre dans l\'Espace Ingénieur')
    ctx.close()
    # formation : lien espace-formation.html
    F.users['form@x.cd'] = {'pw': 'Secret#2026', 'confirmed': True, 'org': F.org('formateur')}
    ctx, pg = new_page(b, errs); open_space(pg, 'espace-formation.html'); t('Espace Formation' in gate_text(pg), 'le lien /espace-formation annonce l\'Espace Formation')
    fill_login(pg, 'form@x.cd', 'Secret#2026'); t(app_open(pg), 'un formateur entre dans l\'Espace Formation')
    ctx.close()

    # 10. accès administrateur de l'appareil (écran local conservé) + sans espace : aucune porte
    ctx, pg = new_page(b, errs); open_space(pg)
    pg.click('[data-act="local"]'); pg.wait_for_timeout(400)
    t(not pg.evaluate("!!document.getElementById('exbGate')") and pg.evaluate("!document.getElementById('loginScreen').hasAttribute('inert')"), '« Accès administrateur de cet appareil » : retour à l\'écran de connexion local')
    ctx.close()
    ctx, pg = new_page(b, errs); pg.goto(BASE + 'index.html'); pg.wait_for_timeout(2500)
    t(not pg.evaluate("!!document.getElementById('exbGate')") and pg.evaluate("EXBGATE.needGate()") is False, 'sans espace demandé : aucun changement (connexion locale habituelle)')
    ctx.close()

    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
