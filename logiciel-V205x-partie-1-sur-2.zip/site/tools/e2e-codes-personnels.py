# V205v — panneau « Équipe » : un code d'activation PERSONNEL par membre (serveur simulé, mêmes règles que migration-v205v-codes-personnels.sql)
import http.server, threading, functools, os, sys, json
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
H = functools.partial(Q, directory=ROOT)
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
MOCK = r"""
window.__SRV = {org: {id: 'o1', nom: 'Excellencia', role: 'admin', code: 'abcd1234'}, inv: [], mem: [{user_id: 'u0', nom: 'Admin', email: 'admin@t.com', role: 'admin', fonction: 'polyvalent', depuis: '2026-01-01'}], codes: {}, n: 0, noMig: false};
function gen() { window.__SRV.n++; return ('kx' + window.__SRV.n + 'mnpq').slice(0, 8); }
window.exbSb = {isIn: function () { return true; }, cfg: function () { return {email: 'admin@t.com'}; }, api: async function (path, o) {
  var n = path.split('/rpc/')[1], b = JSON.parse((o && o.body) || '{}'), S = window.__SRV;
  if (n === 'mon_organisation') return S.org;
  if (n === 'equipe_liste') return {membres: S.mem, invitations: S.inv};
  if (n === 'equipe_definir_jeton') return {ok: true};
  if (n === 'equipe_inviter') { S.inv.push({id: 'i' + S.inv.length, email: b.p_email, nom: b.p_nom, role: b.p_role, fonction: b.p_fonction, cree_le: '2026-11-20'}); return {statut: 'invite', email: b.p_email}; }
  if (n === 'equipe_code_membre' || n === 'equipe_regenerer_code') {
    if (S.noMig) throw new Error('function equipe_code_membre does not exist 42883');
    var e = b.p_email, c = S.codes[e];
    if (!c || n === 'equipe_regenerer_code') c = S.codes[e] = {email: e, code: gen(), utilise: false, revoque: false};
    return c;
  }
  if (n === 'equipe_codes') { if (S.noMig) throw new Error('function equipe_codes does not exist 42883'); return Object.values(S.codes); }
  throw new Error('rpc inconnue ' + n);
}};
"""
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 430, 'height': 900}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto(BASE + 'index.html'); pg.wait_for_timeout(5000)
    pg.add_style_tag(content='#app{display:block !important} #loginScreen,#exbLicLock{display:none !important}')
    pg.evaluate(MOCK)
    pg.evaluate("document.body.insertAdjacentHTML('beforeend','<section id=\"equipe\"></section>');EXB_EQUIPE.reload()"); pg.wait_for_timeout(1200)
    print('   panneau :', pg.inner_text('#equipe')[:80].replace('\n',' '))
    def inviter(nom, em, fn):
        pg.fill('#eq_nom', nom); pg.fill('#eq_em', em); pg.select_option('#eq_fn', fn); pg.click('#eq_go'); pg.wait_for_timeout(900)
        txt = pg.input_value('#eq_msg'); pg.click('#eq_x'); pg.wait_for_timeout(200); return txt
    # V205v : la fonction doit être choisie explicitement (plus de « Polyvalent » par défaut)
    t(pg.input_value('#eq_fn') == '', 'le formulaire d\'invitation n\'a plus de fonction par défaut')
    pg.fill('#eq_nom', 'Sans Fonction'); pg.fill('#eq_em', 'sf@t.com'); pg.click('#eq_go'); pg.wait_for_timeout(500)
    t('Choisissez la fonction' in pg.inner_text('#equipe') and pg.evaluate("window.__SRV.inv.length") == 0, 'sans fonction choisie : invitation refusée avec un message clair, rien d\'enregistré')
    m1 = inviter('Compta Un', 'compta1@t.com', 'comptable')
    m2 = inviter('Compta Deux', 'compta2@t.com', 'comptable')
    m3 = inviter('Ing Trois', 'ing@t.com', 'bureau_etudes')
    import re
    def code(m): x = re.search(r'PERSONNEL[^:]*: (\w+)', m); return x.group(1) if x else None
    c1, c2, c3 = code(m1), code(m2), code(m3)
    t(c1 and c2 and c3 and len({c1, c2, c3}) == 3, 'trois invités = trois codes personnels différents : %s %s %s' % (c1, c2, c3))
    t('mot de passe habituel' not in m1 and 'Première connexion' in m1 and 'vous choisissez vous-même votre mot de passe' in m1 and 'Mot de passe oublié' in m1, 'le message explique la première connexion (choisir son mot de passe) ET le cas du compte déjà existant')
    t('fonction : Comptable' in m1 and 'vous n’avez rien à choisir' in m1, 'le message rappelle la fonction attribuée par l\'administrateur')
    t(all('abcd1234' not in m for m in (m1, m2, m3)), 'le code commun de l’entreprise n’apparaît plus dans les messages')
    t('lié à votre adresse e-mail' in m1 and 'compta1@t.com' in m1 and 'comptable.html' in m1, 'le message dit que le code est personnel et donne le lien de l’espace comptable')
    t('ingenieur.html' in m3, 'l’ingénieur reçoit le lien de son propre espace')
    tab = pg.inner_text('#equipe')
    t(c1 in tab and c2 in tab and 'pas encore utilisé' in tab, 'le panneau montre le code de chaque personne et son état')
    # re-ouvrir le message d'une invitation : même code
    pg.click('button[data-msg="0"]'); pg.wait_for_timeout(600)
    t(code(pg.input_value('#eq_msg')) == c1, 'rouvrir le message redonne le MÊME code à la même personne')
    # nouveau code
    pg.once('dialog', lambda d: d.accept())
    pg.click('#eq_nc'); pg.wait_for_timeout(800)
    try: pg.click('.exb-ui-ok, [data-exbui="ok"], button:has-text("Nouveau code") >> nth=-1', timeout=1500)
    except Exception: pass
    pg.wait_for_timeout(800)
    n1 = code(pg.input_value('#eq_msg')) if pg.query_selector('#eq_msg') else None
    t(n1 and n1 != c1, 'bouton « Nouveau code » : l’ancien code est remplacé (%s → %s)' % (c1, n1))
    # membre existant : lien avec code personnel
    pg.evaluate("window.__SRV.mem.push({user_id:'u9',nom:'Marc',email:'marc@t.com',role:'editeur',fonction:'comptable',depuis:'2026-02-01'}); EXB_EQUIPE.reload()"); pg.wait_for_timeout(700)
    pg.evaluate("document.getElementById('exbEqModal')?.remove()")
    pg.click('button[data-lk="1"]'); pg.wait_for_timeout(700)
    mm = pg.input_value('#eq_msg')
    t('PERSONNEL' in mm and code(mm) not in (None, c1, c2, c3), 'un membre déjà présent reçoit lui aussi SON code (%s)' % code(mm))
    pg.evaluate("window.__SRV.mem.push({user_id:'u8',nom:'Zoé',email:'zoe@t.com',role:'editeur',fonction:'polyvalent',depuis:'2026-03-01'}); EXB_EQUIPE.reload()"); pg.wait_for_timeout(700)
    t('fonction à choisir' in pg.inner_text('#equipe'), 'un membre resté « Polyvalent » (par défaut) est signalé à l\'administrateur')
    # serveur sans la migration : repli sur l'ancien code d'entreprise
    pg.evaluate("document.getElementById('exbEqModal')?.remove();window.__SRV.noMig=true;window.__SRV.codes={};EXB_EQUIPE.reload()"); pg.wait_for_timeout(600)
    mx = inviter('Sans Migration', 'sm@t.com', 'rh')
    t('abcd1234' in mx and 'PERSONNEL' not in mx, 'migration non installée : repli propre sur le code de l’entreprise (rien ne casse)')
    t(not errs, 'aucune erreur JS %s' % errs[:2])
    b.close()
print('\n%d OK, %d échec' % (ok, fail)); sys.exit(1 if fail else 0)
