/* Excellencia Building V206d — HORS CONNEXION : finances et validations, bail de présence, verrouillage.
 *
 * RÈGLES (appliquées seulement quand l'appareil est relié à la base partagée de l'entreprise ; en mode local, propriétaire seul : rien ne change)
 *  1. FINANCES ET VALIDATIONS = CONNEXION OBLIGATOIRE. Encaisser, payer, facturer, passer une écriture de caisse ou de paie, valider une paie,
 *     approuver ou refuser un dossier du Workflow, valider un visa… est refusé si l'appareil est hors connexion OU si le serveur n'a pas confirmé
 *     l'accès de la personne depuis plus de 15 minutes (un membre suspendu ou retiré n'a donc pas 15 minutes de marge pour un encaissement).
 *     Le refus est franc : rien n'est enregistré, le message explique pourquoi, et chaque refus entre dans le journal d'audit.
 *     Deux niveaux : (a) les fonctions d'action (factures, caisse, bons de commande, paiements, paie, décisions du Workflow) refusent
 *     avant de toucher aux données ; (b) filet de sécurité : toute écriture dans une collection financière est bloquée au niveau du stockage.
 *  2. BAIL DE PRÉSENCE. Chaque confirmation du serveur (exb-db.js, toutes les 5 min en ligne) renouvelle un bail de 7 jours (comme la licence).
 *     Sans confirmation pendant 7 jours (hors connexion prolongée, compte déconnecté, horloge reculée) l'écran se verrouille
 *     jusqu'à une vérification réussie : c'est ce qui borne le temps pendant lequel un accès révoqué peut passer inaperçu hors ligne.
 *  3. APRÈS UNE RÉVOCATION (exb-db.js, au premier contact avec le serveur) :
 *       • suspendu → l'écran se verrouille (ce fichier), plus de synchronisation ni d'écriture ; les données restent sur l'appareil, non lisibles
 *         par l'application, et reviennent à la réactivation ;
 *       • retiré → les données de l'entreprise sont EFFACÉES de l'appareil (fiches, file hors ligne du chantier, images) ; seules les données du
 *         compte personnel de la personne restent.
 *  Réglages (facultatifs, avant le chargement de ce script) : window.EXB_OFFLINE_CONFIG = { finTtlMin:15, leaseDays:7, finKeys:[…], exemptKeys:[…] }.
 *  Limite : contrôles d'application, pas de chiffrement des données locales (voir exb-db.js). Retirer : supprimer la balise du script. */
(function (w, d) {
  'use strict';
  if (w.EXBOFF) return;
  var C = Object.assign({ finTtlMin: 15, leaseDays: 7, finKeys: [], exemptKeys: [] }, w.EXB_OFFLINE_CONFIG || {});

  /* collections financières / de validation : toute écriture exige la connexion (filet de sécurité au niveau du stockage) */
  var FIN = {};
  ['exb_cash', 'exb_finance', 'exb_invoices', 'exb_decomptes', 'exb_guichet', 'exb_situations', 'exb_approvals', 'exb_payroll', 'exb_bank_reconciliation',
    'exb_v92_bank', 'exb_v92_bank_tx', 'exb_v92_payroll', 'exb_v92_supplier_invoices', 'exb_v93_payment_methods', 'exb_v93_payments', 'exb_v93_cash_operations',
    'exb_receipts', 'exb_payments', 'exb_paie_runs', 'exb_paie_cfg', 'exb_od', 'exb_immo', 'exb_stock_val', 'exb_wf_dossiers', 'exb_v94_visas', 'exb_cde_workflows']
    .concat(C.finKeys || []).forEach(function (k) { FIN[k] = 1; });
  (C.exemptKeys || []).forEach(function (k) { delete FIN[k]; });

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function DB() { return w.EXBDB || null; }
  function linked() { try { var i = DB() && DB().info && DB().info(); return !!(i && i.on); } catch (e) { return false; } }
  function acc() { try { return DB().acces(); } catch (e) { return { etat: 'actif', okAt: 0, motif: '' }; } }
  /* âge de la dernière confirmation du serveur ; une horloge reculée (âge négatif) vaut « bail expiré » */
  function age() { var a = acc(); if (!a.okAt) return Infinity; var x = Date.now() - a.okAt; return x < 0 ? Infinity : x; }
  function online() { return w.navigator.onLine !== false; }
  function signedIn() { try { return !!(w.exbSb && w.exbSb.isIn && w.exbSb.isIn()); } catch (e) { return false; } }

  var lastRe = 0;
  function recheck() { var t = Date.now(); if (t - lastRe < 20000) return; lastRe = t; try { if (DB() && DB().recheck && signedIn() && online()) DB().recheck().then(paintLock, paintLock); } catch (e) { } }

  /* { ok, code, why } : peut-on faire une opération financière / une validation maintenant ? */
  function state() {
    if (!linked()) return { ok: true };
    var a = acc();
    if (a.etat === 'suspendu') return { ok: false, code: 'suspendu', why: 'Votre accès est suspendu par l’administrateur.' };
    if (!online()) return { ok: false, code: 'hors', why: 'L’appareil est hors connexion.' };
    if (age() > C.finTtlMin * 60000) { recheck(); return { ok: false, code: 'verif', why: signedIn() ? 'Votre accès vient d’être revérifié auprès du serveur : réessayez dans quelques secondes.' : 'Votre compte en ligne est déconnecté : reconnectez-vous.' }; }
    return { ok: true };
  }

  var lastToast = 0;
  function say(m) { try { if (typeof w.notify === 'function') return w.notify(m, 'warn', 8000); } catch (e) { } try { w.alert(m); } catch (e) { } }
  function refuse(what, st) {
    var m = 'Action refusée : les opérations financières et les validations exigent une connexion (le serveur doit confirmer votre accès). ' + st.why + ' Rien n’a été enregistré.';
    try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log('hors_ligne.refus', String(what || '').slice(0, 60), { raison: st.code }); } catch (e) { }
    var t = Date.now(); if (t - lastToast > 4000) { lastToast = t; say(m); }
    return m;
  }

  /* ---------- niveau 2 : filet de sécurité au niveau du stockage ---------- */
  function hookStorage() {
    var S; try { S = exbStorage; } catch (e) { return false; }
    if (!S || typeof S.setItem !== 'function') return false;
    if (S.__off) return true;
    S.__off = 1;
    function gate(k) {
      if (!FIN[k] || !linked()) return false;
      try { if (DB().applying && DB().applying()) return false; } catch (e) { }   /* données reçues du serveur : toujours acceptées */
      var st = state(); if (st.ok) return false;
      refuse('stockage ' + k, st);
      try { if (DB().revert) DB().revert(k); } catch (e) { }
      return true;
    }
    var oSet = S.setItem, oRem = S.removeItem;
    S.setItem = function (k) { if (gate(k)) return; return oSet.apply(this, arguments); };
    if (typeof oRem === 'function') S.removeItem = function (k) { if (gate(k)) return; return oRem.apply(this, arguments); };
    return true;
  }

  /* ---------- niveau 1 : fonctions d'action (refus avant de toucher aux données) ---------- */
  /* mode : 'toast' = ne rien renvoyer ; 'throw' = lever une erreur ; 'error' = { error } ; 'okerr' = { ok:false, error } */
  var GUARDS = [
    ['EXBCH', ['newInv', 'saveD', 'delI', 'fromQuote', 'pay', 'addE', 'delE'], 'toast'],
    ['EXBTR', ['payPo', 'payT', 'sitInv', 'saveSit', 'addAv'], 'toast'],
    ['EXB_PAYMENTS', ['addMethod', 'recordPayment', 'confirmPayment', 'cashOperation'], 'throw'],
    ['EXBCOMPTA_PAIE', ['createRun', 'editLine', 'validateRun', 'payRun', 'cancelRun', 'addOd', 'cancelOd', 'addImmo', 'saveCfg', 'addStockVal'], 'error'],
    ['EXBWF', ['decide'], 'okerr'],
    ['exbPayTrack', ['setPay'], 'toast']
  ];
  var done = {};
  function wrapAll() {
    var left = 0;
    GUARDS.forEach(function (g) {
      var o = w[g[0]]; if (!o || typeof o !== 'object') { if (!done[g[0]]) left++; return; }
      g[1].forEach(function (n) {
        var f = o[n]; if (typeof f !== 'function' || f.__off) return;
        var wrapped = function () {
          var st = state(); if (st.ok) return f.apply(this, arguments);
          var m = refuse(g[0] + '.' + n, st);
          if (g[2] === 'throw') throw new Error(m);
          if (g[2] === 'error') return { error: m };
          if (g[2] === 'okerr') return { ok: false, error: m };
        };
        wrapped.__off = 1; try { o[n] = wrapped; } catch (e) { }
      });
      done[g[0]] = 1;
    });
    return left === 0;
  }

  /* ---------- écran de verrouillage : accès suspendu, ou bail de présence expiré ---------- */
  function lockSpec() {
    if (!linked()) return null;
    var a = acc();
    if (a.etat === 'suspendu') return { k: 'susp', t: '⏸ Accès suspendu', btn: 'Vérifier maintenant',
      m: 'L’administrateur a suspendu votre accès à l’entreprise' + (a.motif ? ' (motif : ' + esc(a.motif) + ')' : '') + '. Vos données restent sur cet appareil mais ne sont plus accessibles. Elles vous seront rendues dès la réactivation de votre accès.' };
    if (age() > C.leaseDays * 864e5) return { k: 'bail', t: '📶 Vérification requise', btn: 'Réessayer maintenant', login: !signedIn(),
      m: 'Cet appareil n’a pas pu confirmer votre accès à l’entreprise depuis plus de ' + C.leaseDays + ' jours. ' + (online() ? (signedIn() ? 'Le serveur va être interrogé : patientez un instant ou touchez « Réessayer ».' : 'Reconnectez-vous à votre compte en ligne ci-dessous.') : 'Connectez-vous à internet : le logiciel se déverrouillera tout seul dès que le serveur aura confirmé votre accès.') };
    return null;
  }
  var shownKey = '';
  function paintLock() {
    var sp = lockSpec(), o = d.getElementById('exbOffLock');
    if (!sp) { if (o) o.remove(); shownKey = ''; return; }
    var key = sp.k + '|' + sp.m + '|' + (sp.login ? 1 : 0) + '|' + (online() ? 1 : 0);
    if (o && shownKey === key) return;
    var keep = o && o.querySelector('#exbOffEm') ? { e: o.querySelector('#exbOffEm').value, p: (o.querySelector('#exbOffPw') || {}).value } : null;
    if (!o) { o = d.createElement('div'); o.id = 'exbOffLock'; d.body.appendChild(o); }
    shownKey = key;
    o.style.cssText = 'position:fixed;inset:0;z-index:99990;background:#173565;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;font:17px system-ui;overflow:auto';
    var em = ''; try { em = (w.exbSb && w.exbSb.cfg && w.exbSb.cfg().email) || ''; } catch (e) { }
    var inp = 'width:100%;box-sizing:border-box;border-radius:10px;border:0;padding:10px;color:#000;margin-top:8px';
    o.innerHTML = '<div style="max-width:440px"><div style="font-size:48px">🔒</div><h2 style="color:#fff">' + sp.t + '</h2><p>' + sp.m + '</p>'
      + (sp.login ? '<div style="text-align:left;margin:12px 0"><input id="exbOffEm" type="email" inputmode="email" autocapitalize="none" placeholder="E-mail du compte" style="' + inp + '" value="' + esc(keep ? keep.e : em) + '"><input id="exbOffPw" type="password" placeholder="Mot de passe" autocomplete="current-password" style="' + inp + '" value="' + esc(keep ? keep.p : '') + '"><button id="exbOffGo" style="margin-top:10px;padding:12px 20px;border:0;border-radius:10px;background:#fcd34d;color:#000;font-weight:700;width:100%">Se connecter</button></div>' : '')
      + '<button id="exbOffRe" style="margin-top:8px;padding:12px 20px;border:0;border-radius:10px;background:' + (sp.login ? 'transparent;color:#fff;border:1px solid #fff8' : '#fcd34d;color:#000') + ';font-weight:700">' + sp.btn + '</button><div id="exbOffMsg" style="margin-top:12px;font-size:14px;color:#fecaca"></div></div>';
    var msg = d.getElementById('exbOffMsg');
    d.getElementById('exbOffRe').onclick = async function () {
      this.disabled = true; msg.textContent = 'Vérification…';
      try { lastRe = 0; if (DB() && DB().recheck) await DB().recheck(); } catch (e) { }
      this.disabled = false; msg.textContent = lockSpec() ? (online() ? 'Le serveur n’a pas encore confirmé votre accès. Réessayez dans un instant.' : 'Aucune connexion détectée.') : ''; paintLock();
    };
    var go = d.getElementById('exbOffGo');
    if (go) go.onclick = async function () {
      var e = d.getElementById('exbOffEm').value.trim(), p = d.getElementById('exbOffPw').value;
      if (!e || !p) { msg.textContent = 'Saisissez l’e-mail et le mot de passe.'; return; }
      var c = {}; try { c = w.exbSb.cfg(); } catch (x) { }
      if (!c.url || !c.key) { msg.textContent = 'Serveur non configuré : ouvrez le logiciel avec votre lien d’activation.'; return; }
      go.disabled = true; msg.textContent = 'Connexion…';
      try {
        var r = await fetch(c.url + '/auth/v1/token?grant_type=password', { method: 'POST', headers: { apikey: c.key, 'Content-Type': 'application/json' }, body: JSON.stringify({ email: e, password: p }) });
        var j = await r.json().catch(function () { return {}; });
        if (!r.ok || !j.access_token) throw new Error(j.error_description || j.msg || 'E-mail ou mot de passe incorrect.');
        w.exbSb.set({ access_token: j.access_token, refresh_token: j.refresh_token, exp: Date.now() + (j.expires_in || 3600) * 1000 });
        try { var ck = JSON.parse(localStorage.getItem('EXB_SB_CFG') || 'null'); if (ck && typeof ck === 'object') { ck.email = e; localStorage.setItem('EXB_SB_CFG', JSON.stringify(ck)); } } catch (x) { }
        lastRe = 0; if (DB() && DB().recheck) await DB().recheck();
        msg.textContent = ''; paintLock();
      } catch (x) { msg.textContent = String(x && x.message || x); }
      go.disabled = false;
    };
  }

  /* ---------- démarrage ---------- */
  var tries = 0, tm = setInterval(function () { var a = hookStorage(), b = wrapAll(); if ((a && b) || ++tries > 120) clearInterval(tm); }, 500);
  d.addEventListener('DOMContentLoaded', function () { hookStorage(); wrapAll(); paintLock(); });
  setInterval(function () { if (!d.hidden) { paintLock(); if (linked() && signedIn() && online() && age() > C.finTtlMin * 60000) recheck(); } }, 30000);
  ['online', 'offline', 'exb-access', 'exb-rights'].forEach(function (ev) { w.addEventListener(ev, function () { if (ev === 'online') { lastRe = 0; recheck(); } paintLock(); }); });
  d.addEventListener('visibilitychange', function () { if (!d.hidden) { paintLock(); recheck(); } });
  setTimeout(paintLock, 1500);

  w.EXBOFF = {
    version: 'V206d', config: C,
    finKeys: function () { return Object.keys(FIN); },
    /* diagnostic : { lie, enLigne, ageMin, financesOk, etat } */
    status: function () { var s = state(); return { lie: linked(), enLigne: online(), ageMin: isFinite(age()) ? Math.round(age() / 60000) : null, financesOk: s.ok, raison: s.code || '', etat: acc().etat }; },
    guard: function (what) { var s = state(); if (s.ok) return true; refuse(what, s); return false; },   /* pour les futurs modules : if(!EXBOFF.guard('mon action')) return; */
    paint: paintLock
  };
})(window, document);
