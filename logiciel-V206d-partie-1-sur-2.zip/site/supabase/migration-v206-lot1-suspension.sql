-- ===== Excellencia Building — V206 lot 1 : SUSPENSION d'un membre + état d'accès de l'appareil =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v99w-equipe.sql et migration-v205v-codes-personnels.sql
-- (et les migrations v205-lot4 / lot5 qui ajoutent les fonctions « architecte » et « formateur »). Réexécutable sans danger.
--
-- PRINCIPE : suspendre un membre = le sortir de la table « membres » et le ranger dans « membres_suspendus » (rôle, fonction, nom,
-- date d'entrée conservés). Toutes les règles existantes du serveur (est_membre, peut(), enregistrer(), politiques RLS, stockage,
-- fonctions v99v / v99zzf / v205…) testent la présence dans « membres » : un membre suspendu perd donc TOUT accès d'un coup,
-- sans qu'aucune de ces règles ait besoin d'être modifiée (aucun chemin d'accès oublié). « Réactiver » le remet dans « membres »
-- avec le même rôle et la même fonction. Son code personnel (v205v) reste valable : une suspension n'est pas un retrait.
--
-- Fonctions ajoutées :
--   equipe_suspendre(p_org, p_user, p_suspendre, p_motif)  — administrateur uniquement
--   mon_acces(p_org)  — état d'accès de l'appareil connecté : 'actif' | 'suspendu' | 'aucun' (retiré ou jamais membre).
--                        L'application s'en sert pour verrouiller (suspendu) ou effacer (aucun) les données locales.
-- Fonctions adaptées (même contrat, plus les membres suspendus) : equipe_liste, equipe_modifier, equipe_retirer.

create table if not exists membres_suspendus(
  org_id uuid not null references organisations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  nom text,
  role text not null,
  fonction text not null default 'polyvalent',
  depuis timestamptz not null default now(),
  suspendu_le timestamptz not null default now(),
  suspendu_par uuid,
  suspendu_motif text,
  primary key(org_id, user_id));
alter table membres_suspendus enable row level security;
revoke all on membres_suspendus from anon, authenticated;   -- aucun accès direct : uniquement par les fonctions ci-dessous

-- Une personne suspendue ne peut pas se « réinscrire » avec le code de l'entreprise, une invitation ou un code personnel.
create or replace function membres_bloquer_suspendu() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if exists(select 1 from membres_suspendus where org_id=new.org_id and user_id=new.user_id) then
    raise exception 'accès suspendu : contactez l''administrateur de l''entreprise';
  end if;
  return new;
end $$;
drop trigger if exists trg_membres_bloquer_suspendu on membres;
create trigger trg_membres_bloquer_suspendu before insert on membres for each row execute function membres_bloquer_suspendu();

-- v205v : « membre retiré = code révoqué ». Une suspension (marquée par exb.suspension) ne révoque PAS le code personnel.
do $mig$ begin
  if to_regprocedure('codes_membres_revoquer()') is not null then
    execute $f$
      create or replace function codes_membres_revoquer() returns trigger language plpgsql security definer set search_path=public as $b$
      begin
        if coalesce(current_setting('exb.suspension', true), '') = '1' then return old; end if;
        update codes_membres set revoque_le=now() where org_id=old.org_id and (user_id=old.user_id or email=(select lower(email) from auth.users where id=old.user_id));
        return old;
      end $b$ $f$;
  end if;
end $mig$;

-- ---------- Suspendre / réactiver ----------
create or replace function equipe_suspendre(p_org uuid, p_user uuid, p_suspendre boolean default true, p_motif text default null) returns json
language plpgsql security definer set search_path=public as $$
declare m membres; s membres_suspendus; admins int; mx int; n int;
begin
  if auth.uid() is null or not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if p_user = auth.uid() then raise exception 'vous ne pouvez pas vous suspendre vous-même'; end if;
  if coalesce(p_suspendre, true) then
    select * into m from membres where org_id=p_org and user_id=p_user for update;
    if not found then
      if exists(select 1 from membres_suspendus where org_id=p_org and user_id=p_user) then return json_build_object('ok', true, 'deja', true); end if;
      raise exception 'membre introuvable';
    end if;
    select count(*) into admins from membres where org_id=p_org and role='admin';
    if m.role='admin' and admins<=1 then raise exception 'impossible : c''est le dernier administrateur'; end if;
    perform set_config('exb.suspension', '1', true);   -- limité à cette transaction
    delete from membres where org_id=p_org and user_id=p_user;
    insert into membres_suspendus(org_id,user_id,nom,role,fonction,depuis,suspendu_par,suspendu_motif)
      values (p_org,p_user,m.nom,m.role,m.fonction,m.depuis,auth.uid(),nullif(left(btrim(coalesce(p_motif,'')),200),''))
      on conflict (org_id,user_id) do update set suspendu_le=now(), suspendu_par=auth.uid(), suspendu_motif=excluded.suspendu_motif;
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),'membres',p_user::text,'suspension membre',0);
    return json_build_object('ok', true);
  end if;
  -- réactivation
  select * into s from membres_suspendus where org_id=p_org and user_id=p_user for update;
  if not found then raise exception 'membre introuvable ou non suspendu'; end if;
  if to_regclass('public.licences_clients') is not null then
    execute 'select max_utilisateurs from licences_clients where org_id=$1 order by cree_le desc limit 1' into mx using p_org;
    select count(*) into n from membres where org_id=p_org;
    if mx is not null and n >= mx then raise exception 'nombre maximal d''utilisateurs atteint (%)', mx; end if;
  end if;
  delete from membres_suspendus where org_id=p_org and user_id=p_user;
  insert into membres(org_id,user_id,nom,role,fonction,depuis) values (p_org,p_user,s.nom,s.role,s.fonction,s.depuis);
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),'membres',p_user::text,'réactivation membre',0);
  return json_build_object('ok', true);
end $$;

-- ---------- État d'accès de l'appareil connecté ----------
create or replace function mon_acces(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
declare m membres; s membres_suspendus;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  select * into m from membres where org_id=p_org and user_id=auth.uid();
  if found then return json_build_object('etat','actif','role',m.role,'fonction',m.fonction); end if;
  select * into s from membres_suspendus where org_id=p_org and user_id=auth.uid();
  if found then return json_build_object('etat','suspendu','motif',s.suspendu_motif,'depuis',s.suspendu_le); end if;
  return json_build_object('etat','aucun');
end $$;

-- ---------- Équipe : la liste montre aussi les membres suspendus ----------
create or replace function equipe_liste(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  return json_build_object(
    'membres', (select coalesce(json_agg(t.x order by t.depuis),'[]'::json) from (
                  select json_build_object('user_id',m.user_id,'nom',m.nom,'email',u.email,'role',m.role,'fonction',m.fonction,'depuis',m.depuis,
                         'suspendu_le',null,'suspendu_motif',null) as x, m.depuis
                    from membres m left join auth.users u on u.id=m.user_id where m.org_id=p_org
                  union all
                  select json_build_object('user_id',s.user_id,'nom',s.nom,'email',u.email,'role',s.role,'fonction',s.fonction,'depuis',s.depuis,
                         'suspendu_le',s.suspendu_le,'suspendu_motif',s.suspendu_motif), s.depuis
                    from membres_suspendus s left join auth.users u on u.id=s.user_id where s.org_id=p_org) t),
    'invitations', (select coalesce(json_agg(json_build_object('id',i.id,'email',i.email,'nom',i.nom,'role',i.role,
                  'fonction',i.fonction,'cree_le',i.cree_le) order by i.cree_le),'[]'::json)
                from invitations_equipe i where i.org_id=p_org and i.utilise_le is null));
end $$;

-- ---------- Équipe : modifier / retirer un membre suspendu ----------
-- Les versions en vigueur sont conservées sous un autre nom (une seule fois) puis enveloppées.
do $mig$ begin
  if to_regprocedure('equipe_modifier_base(uuid,uuid,text,text)') is null then
    alter function equipe_modifier(uuid,uuid,text,text) rename to equipe_modifier_base; end if;
  if to_regprocedure('equipe_retirer_base(uuid,uuid)') is null then
    alter function equipe_retirer(uuid,uuid) rename to equipe_retirer_base; end if;
end $mig$;

create or replace function equipe_modifier(p_org uuid, p_user uuid, p_role text, p_fonction text) returns json
language plpgsql security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if exists(select 1 from membres_suspendus where org_id=p_org and user_id=p_user) then
    if p_role not in ('admin','editeur','lecteur') then raise exception 'rôle invalide'; end if;
    if p_fonction not in ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','architecte','formateur','comptable','rh','magasinier') then
      raise exception 'fonction invalide'; end if;
    update membres_suspendus set role=p_role, fonction=p_fonction where org_id=p_org and user_id=p_user;
    return json_build_object('ok', true);
  end if;
  return equipe_modifier_base(p_org, p_user, p_role, p_fonction);
end $$;

create or replace function equipe_retirer(p_org uuid, p_user uuid) returns json
language plpgsql security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if exists(select 1 from membres_suspendus where org_id=p_org and user_id=p_user) then
    delete from membres_suspendus where org_id=p_org and user_id=p_user;
    if to_regclass('public.codes_membres') is not null then   -- retiré = code personnel révoqué (comme pour un membre actif)
      execute 'update codes_membres set revoque_le=now() where org_id=$1 and (user_id=$2 or email=(select lower(email) from auth.users where id=$2))' using p_org, p_user;
    end if;
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),'membres',p_user::text,'retrait membre suspendu',0);
    return json_build_object('ok', true);
  end if;
  return equipe_retirer_base(p_org, p_user);
end $$;

revoke execute on function equipe_modifier_base(uuid,uuid,text,text), equipe_retirer_base(uuid,uuid) from public, anon, authenticated;
revoke execute on function equipe_suspendre(uuid,uuid,boolean,text), mon_acces(uuid), equipe_liste(uuid), equipe_modifier(uuid,uuid,text,text), equipe_retirer(uuid,uuid) from public, anon;
grant  execute on function equipe_suspendre(uuid,uuid,boolean,text), mon_acces(uuid), equipe_liste(uuid), equipe_modifier(uuid,uuid,text,text), equipe_retirer(uuid,uuid) to authenticated;
