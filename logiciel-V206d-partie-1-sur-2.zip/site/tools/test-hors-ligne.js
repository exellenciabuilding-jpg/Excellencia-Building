const fs=require('fs'),vm=require('vm');
let now=Date.now(),on=true,meta={on:true},acces={etat:'actif',okAt:now,motif:''},applying=false,store={},notes=[];
const listeners={};
const doc={hidden:false,body:{appendChild(){}},getElementById:()=>null,createElement:()=>({style:{},querySelector(){},remove(){}}),addEventListener(){}};
const win={navigator:{get onLine(){return on}},addEventListener(){},
 EXBDB:{info:()=>meta,acces:()=>acces,applying:()=>applying,revert(){notes.push('revert')},recheck:()=>Promise.resolve()},
 exbSb:{isIn:()=>true,cfg:()=>({})},notify:m=>notes.push(m),EXB_OFFLINE_CONFIG:{},
 EXBCH:{pay(){return 'paid'}},EXB_PAYMENTS:{recordPayment(){return 'rec'}},EXBWF:{decide(){return {ok:true}}},EXBCOMPTA_PAIE:{payRun(){return {ok:1}}}};
win.window=win;win.document=doc;
win.exbStorage={setItem(k,v){store[k]=v},removeItem(k){delete store[k]}};
const ctx=vm.createContext(Object.assign(win,{setInterval:f=>{try{f()}catch(e){console.log('IV',e.message)};return 0},setTimeout:()=>0,clearInterval(){},Date,Promise,Object,String,Array,JSON,Math,isFinite,Error,localStorage:{getItem:()=>null,setItem(){}},exbStorage:win.exbStorage}));
vm.runInContext(fs.readFileSync('exb-v206d-hors-ligne.js','utf8'),ctx);
let ok=0,ko=0;const T=(n,c)=>{console.log((c?'OK  ':'ECHEC ')+n);c?ok++:ko++};
const O=win.EXBOFF;
T('en ligne + frais : finances OK',O.status().financesOk&&win.EXBCH.pay()==='paid');
win.exbStorage.setItem('exb_cash','1');T('écriture caisse en ligne acceptée',store.exb_cash==='1');
on=false;
T('hors ligne : EXBCH.pay refusé',win.EXBCH.pay()===undefined);
let thr=false;try{win.EXB_PAYMENTS.recordPayment()}catch(e){thr=true}T('hors ligne : paiement lève une erreur',thr);
T('hors ligne : décision workflow {ok:false}',win.EXBWF.decide().ok===false);
T('hors ligne : paie {error}',!!win.EXBCOMPTA_PAIE.payRun().error);
win.exbStorage.setItem('exb_cash','2');T('hors ligne : écriture caisse bloquée',store.exb_cash==='1');
win.exbStorage.setItem('exb_clients','x');T('hors ligne : collection non financière libre',store.exb_clients==='x');
applying=true;win.exbStorage.setItem('exb_cash','3');applying=false;T('données reçues du serveur acceptées hors ligne',store.exb_cash==='3');
on=true;acces.okAt=now-20*60000;T('en ligne mais confirmation > 15 min : refusé',win.EXBCH.pay()===undefined);
acces.okAt=Date.now()+3600e3;T('horloge reculée : refusé',!O.status().financesOk);
acces.okAt=Date.now();acces.etat='suspendu';T('suspendu : refusé',win.EXBCH.pay()===undefined);
acces.etat='actif';meta.on=false;T('mode local (non relié) : tout permis hors ligne',(on=false,win.EXBCH.pay()==='paid'));
console.log(ok+'/'+(ok+ko));process.exit(ko?1:0)
