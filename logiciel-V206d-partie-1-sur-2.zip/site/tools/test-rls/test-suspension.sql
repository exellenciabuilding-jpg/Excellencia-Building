-- V206 lot 1 — test de la suspension (migration-v206-lot1-suspension.sql). Même mécanique que test-rls.sql.
-- Chaque ligne affiche  attendu | obtenu | OK / ECHEC.
\set ON_ERROR_STOP off
\pset tuples_only on
\pset format unaligned
create temp table res(n text, attendu text, obtenu text);
grant all on res to public;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','adm@x'),('00000000-0000-0000-0000-0000000000a2','compta@x'),('00000000-0000-0000-0000-0000000000a3','edit@x'),
 ('00000000-0000-0000-0000-0000000000a4','autre@x.fr') on conflict do nothing;
select set_config('app.uid','00000000-0000-0000-0000-0000000000a1',false);
select (creer_organisation('OrgS','Adm')::jsonb->>'id') as o1 \gset
insert into membres(org_id,user_id,role,fonction) values
 (:'o1','00000000-0000-0000-0000-0000000000a2','editeur','comptable'),
 (:'o1','00000000-0000-0000-0000-0000000000a3','editeur','polyvalent');
select enregistrer(:'o1','caisse','K1','{"montant":100}'::jsonb,0) \gset
select code_invitation as codeorg from organisations where id=:'o1' \gset

create or replace function essai(p_uid text, p_role text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.uid',coalesce(p_uid,''),false); perform set_config('app.role',p_role,false);
  execute 'set local role '||p_role;
  begin execute p_sql into r; exception when others then r:='ERREUR:'||sqlerrm; end;
  reset role; return coalesce(r,'(null)'); end $$;

-- état initial
insert into res select 'S1 comptable actif : mon_acces = actif', 'actif', essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select (mon_acces('$q$||:'o1'||$q$')::jsonb)->>'etat'$q$);
insert into res select 'S2 comptable actif lit la caisse', '1', essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select count(*)::text from enregistrements where org_id='$q$||:'o1'||$q$'$q$);
-- suspension par un non-admin : refusée
insert into res select 'S3 un éditeur ne peut pas suspendre', 'ERREUR:réservé à l''administrateur', essai('00000000-0000-0000-0000-0000000000a3','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a2',true,'x')::text$q$);
-- l'administrateur ne peut pas se suspendre lui-même
insert into res select 'S4 l''admin ne peut pas se suspendre lui-même', 'ERREUR:vous ne pouvez pas vous suspendre vous-même', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a1',true,'x')::text$q$);
-- suspension du comptable
insert into res select 'S5 admin suspend le comptable', 'true', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select ((equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a2',true,'départ en congé')::jsonb)->>'ok')$q$);
insert into res select 'S6 comptable suspendu : mon_acces = suspendu', 'suspendu', essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select (mon_acces('$q$||:'o1'||$q$')::jsonb)->>'etat'$q$);
insert into res select 'S7 comptable suspendu : plus aucune fiche lisible (RLS)', '0', essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select count(*)::text from enregistrements where org_id='$q$||:'o1'||$q$'$q$);
insert into res select 'S8 comptable suspendu : écriture refusée (enregistrer)', 'refus', case when essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','caisse','K2','{"montant":999}'::jsonb,0)::text$q$) ~ '"refus"\s*:\s*true|droits insuffisants' then 'refus' else 'ACCEPTE' end;
insert into res select 'S9 la fiche K2 n''existe pas', '0', (select count(*)::text from enregistrements where org_id=:'o1' and id='K2');
insert into res select 'S10 suspendu ne peut pas se réinscrire avec le code de l''entreprise', 'ERREUR:accès suspendu : contactez l''administrateur de l''entreprise',
  essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select rejoindre_organisation('$q$||:'codeorg'||$q$','X')::text$q$);
insert into res select 'S11 equipe_liste montre le suspendu avec son motif', 'départ en congé', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select (select x->>'suspendu_motif' from json_array_elements((equipe_liste('$q$||:'o1'||$q$')::json)->'membres') x where x->>'email'='compta@x')$q$);
insert into res select 'S12 equipe_liste : 3 membres (admin, éditeur, suspendu)', '3', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select json_array_length((equipe_liste('$q$||:'o1'||$q$')::json)->'membres')::text$q$);
insert into res select 'S13 modifier la fonction d''un suspendu (-> direction)', 'true', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select ((equipe_modifier('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a2','editeur','direction')::jsonb)->>'ok')$q$);
-- réactivation
insert into res select 'S14 réactivation', 'true', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select ((equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a2',false,null)::jsonb)->>'ok')$q$);
insert into res select 'S15 réactivé : retrouve rôle + fonction modifiée (direction) et la lecture', 'direction|1', essai('00000000-0000-0000-0000-0000000000a2','authenticated',$q$select (mon_acces('$q$||:'o1'||$q$')::jsonb)->>'fonction'||'|'||(select count(*)::text from enregistrements where org_id='$q$||:'o1'||$q$')$q$);
-- retrait d'un membre suspendu
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a3',true,null)::text$q$) as _r16a \gset
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_retirer('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a3')::text$q$) as _r16b \gset
insert into res select 'S16 éditeur suspendu puis retiré : mon_acces = aucun', 'aucun', essai('00000000-0000-0000-0000-0000000000a3','authenticated',$q$select (mon_acces('$q$||:'o1'||$q$')::jsonb)->>'etat'$q$);
insert into res select 'S16b retiré : plus dans la liste (2 membres)', '2', essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select json_array_length((equipe_liste('$q$||:'o1'||$q$')::json)->'membres')::text$q$);
insert into res select 'S17 étranger : mon_acces = aucun', 'aucun', essai('00000000-0000-0000-0000-0000000000a4','authenticated',$q$select (mon_acces('$q$||:'o1'||$q$')::jsonb)->>'etat'$q$);
insert into res select 'S18 étranger ne peut pas suspendre', 'ERREUR:réservé à l''administrateur', essai('00000000-0000-0000-0000-0000000000a4','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a3',true,'x')::text$q$);
insert into res select 'S19 anonyme : mon_acces refusé', 'ERREUR:permission denied for function mon_acces', essai(null,'anon',$q$select mon_acces('$q$||:'o1'||$q$')::text$q$);

-- code personnel (v205v) : survit à une suspension, révoqué par un retrait
insert into membres(org_id,user_id,role,fonction) values (:'o1','00000000-0000-0000-0000-0000000000a4','editeur','magasinier');
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_code_membre('$q$||:'o1'||$q$','autre@x.fr')::text$q$) as _c \gset
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a4',true,null)::text$q$) as _s \gset
insert into res select 'S20 suspension : le code personnel n''est PAS révoqué', 'null', (select coalesce(revoque_le::text,'null') from codes_membres where org_id=:'o1' and email='autre@x.fr');
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a4',false,null)::text$q$) as _r \gset
insert into res select 'S21 réactivation : membre de retour, code intact', 'actif|null', essai('00000000-0000-0000-0000-0000000000a4','authenticated',$q$select (mon_acces('$q$||:'o1'||$q$')::jsonb)->>'etat'$q$)||'|'||(select coalesce(revoque_le::text,'null') from codes_membres where org_id=:'o1' and email='autre@x.fr');
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_suspendre('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a4',true,null)::text$q$) as _s2 \gset
select essai('00000000-0000-0000-0000-0000000000a1','authenticated',$q$select equipe_retirer('$q$||:'o1'||$q$','00000000-0000-0000-0000-0000000000a4')::text$q$) as _t \gset
insert into res select 'S22 retrait d''un suspendu : code personnel révoqué', 'revoque', (select case when revoque_le is not null then 'revoque' else 'actif' end from codes_membres where org_id=:'o1' and email='autre@x.fr');
insert into res select 'S23 journal : suspension + réactivation tracées', '3', (select count(*)::text from journal_entreprise where org_id=:'o1' and action in ('suspension membre','réactivation membre') and rec_id='00000000-0000-0000-0000-0000000000a4');

select n||'  |  attendu='||attendu||'  |  obtenu='||obtenu||'  |  '||case when attendu=obtenu then 'OK' else 'ECHEC' end from res order by n;
select 'BILAN '||count(*) filter (where attendu=obtenu)||'/'||count(*) from res;
