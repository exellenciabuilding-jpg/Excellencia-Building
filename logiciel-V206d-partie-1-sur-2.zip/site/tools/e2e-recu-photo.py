# V205z — le reçu (logiciel central, espace comptable) porte la photo même quand elle est rangée par le grand stockage (jeton exbidb:, photos > 40 Ko).
# Reproduit le cas réel : la fiche participant est relue après rechargement et contient un jeton, pas l'image. Aucun appel réseau.
import http.server, threading, functools, os, random, base64, io, sys
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
random.seed(1); im = Image.new('RGB', (480, 600)); px = im.load()
for x in range(480):
    for y in range(600): px[x, y] = (random.randint(0, 255) if (x // 7 + y // 7) % 3 == 0 else 120 + x % 100, 90 + y % 120, 150)
b = io.BytesIO(); im.save(b, 'JPEG', quality=88); PHOTO = 'data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode()
RECU = """async()=>{const rec={receipt_no:'REC-2026-0006',participant:'IBWAMPERE NGWALA LOUIS',participant_id:'P1',matricule:'011-580-937',training:'ArchiCAD',issued_date:'2026-11-21'};
 const p=participants.find(x=>x.participant_id==='P1'),o=await recuModeleLogiciel(rec);return {fiche:(p&&p.photo||'').slice(0,7),recu:(o&&o.photo||'').length}}"""
with sync_playwright() as pw:
    br = pw.chromium.launch(); pg = br.new_context(viewport={'width': 390, 'height': 800}).new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto(BASE + 'index.html'); pg.wait_for_timeout(3000); pg.add_style_tag(content='#exbLicLock{display:none!important}')
    pg.evaluate("p=>{participants.push({participant_id:'P1',name:'IBWAMPERE NGWALA LOUIS',matricule:'011-580-937',training:'ArchiCAD',approval_status:'APPROUVE',photo:p});save('exb_participants',participants)}", PHOTO)
    pg.wait_for_timeout(1500)
    r = pg.evaluate(RECU); t(r['recu'] > 1000, 'même session : le reçu porte la photo')
    pg.reload(); pg.wait_for_timeout(3000); pg.add_style_tag(content='#exbLicLock{display:none!important}')
    r = pg.evaluate(RECU); t(r['fiche'] == 'exbidb:', 'après rechargement : la fiche contient un jeton « exbidb: » (cas réel des photos lourdes)')
    t(r['recu'] > 1000, 'après rechargement : le reçu du logiciel central porte quand même la photo')
    pg.evaluate("()=>{window.exbSb.isIn=()=>true;window.EXBDB.info=()=>({org:'ORG',on:true});window.EXBDB.can=()=>true}")
    for _ in range(4): pg.evaluate("exbGuichet.publierAnnuaire()"); pg.wait_for_timeout(800)
    a = pg.evaluate("exbGuichet.annuaire().filter(x=>x.nom==='IBWAMPERE NGWALA LOUIS').map(x=>(x.photo||'').length)")
    t(a and 1000 < a[0] <= 24000, 'espace comptable : la vignette de l\'apprenant est publiée dans l\'annuaire (photo lourde comprise)')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
