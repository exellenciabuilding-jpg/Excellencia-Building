const fs=require('fs'),vm=require('vm');
const ls=new Map();const localStorage={getItem:k=>ls.has(k)?ls.get(k):null,setItem:(k,v)=>ls.set(k,String(v)),removeItem:k=>ls.delete(k),get length(){return ls.size},key:i=>[...ls.keys()][i]};
let verdict={etat:'actif'},calls=[],alerts=[],reloaded=0,released=[];
const exbStorage={getItem:k=>localStorage.getItem('P_'+k),setItem:(k,v)=>localStorage.setItem('P_'+k,v),removeItem:k=>localStorage.removeItem('P_'+k)};
const el=()=>({style:{},innerHTML:'',appendChild(){},addEventListener(){},querySelector:()=>null,remove(){}});
const win={localStorage,exbStorage,exbAlert:m=>{alerts.push(m);return Promise.resolve()},
 exbSb:{isIn:()=>true,cfg:()=>({}),api:async(p,o)=>{calls.push(p);if(/mon_acces/.test(p)){if(verdict.err)throw new Error(verdict.err);return verdict}
   if(/mon_organisation/.test(p))return{id:'ORG1',role:'admin',fonction:'direction',nom:'Soc'};if(/rpc\/droits|droits/.test(p))return null;return []}},
 EXBBIG:{release:t=>released.push(...t)},addEventListener(){},dispatchEvent(){},Event:function(n){this.type=n},navigator:{onLine:true}};
win.window=win;
const doc={hidden:false,readyState:'complete',getElementById:()=>null,createElement:el,body:el(),addEventListener(){},head:el()};
win.document=doc;
const ctx=vm.createContext(Object.assign(win,{document:doc,setInterval:()=>0,setTimeout:(f,t)=>{if(t>=2000&&t<=3500&&f.toString().includes('autoJoin')){return 0}return setTimeout(f,Math.min(t||0,50))},clearTimeout,Date,Promise,Object,String,Array,JSON,Math,Error,RegExp,Set,Map,Event:win.Event,location:{reload(){reloaded++}},exbStorage,localStorage,console}));
ls.set('EXB_DB_META',JSON.stringify({org:'ORG1',role:'admin',fonction:'direction',nom:'Soc',rec:{clients:{c1:{v:1,h:'x'}}},conf:[],since:'',dAt:0,okAt:Date.now()-1e6}));
ls.set('P_exb_clients',JSON.stringify([{id:'c1',name:'A'},{id:'c2',name:'B'}]));
ls.set('P_exb_cash',JSON.stringify([{id:'k1'}]));
ls.set('P_exb_perso',JSON.stringify([{id:'z'}]));
ls.set('exb_v73_offline_queue','[1]');
vm.runInContext(fs.readFileSync('exb-db.js','utf8'),ctx);
const D=win.EXBDB;let ok=0,ko=0;const T=(n,c)=>{console.log((c?'OK  ':'ECHEC ')+n);c?ok++:ko++};
(async()=>{
 await D.recheck();
 T('actif : etat actif + bail renouvelé',D.acces().etat==='actif'&&Date.now()-D.acces().okAt<5000);
 verdict={etat:'suspendu',motif:'congé'};await D.recheck();
 T('suspendu : etat + motif',D.acces().etat==='suspendu'&&D.acces().motif==='congé');
 T('suspendu : aucun droit (can=false)',D.can('clients','lire')===false&&D.can('caisse','ecrire')===false);
 T('suspendu : données conservées',JSON.parse(ls.get('P_exb_clients')).length===2);
 verdict={etat:'actif'};await D.recheck();
 T('réactivé : droits rendus',D.acces().etat==='actif'&&D.can('clients','lire')!==false);
 verdict={err:'network'};const before=D.acces().okAt;await D.recheck();
 T('panne réseau : rien ne change, bail non renouvelé',D.acces().etat==='actif'&&D.acces().okAt===before&&JSON.parse(ls.get('P_exb_clients')).length===2);
 verdict={etat:'aucun'};await D.recheck();
 T('retiré : collections de l’entreprise effacées',JSON.parse(ls.get('P_exb_clients')).length===0&&JSON.parse(ls.get('P_exb_cash')).length===0);
 T('retiré : file chantier hors ligne effacée',!ls.has('exb_v73_offline_queue'));
 T('retiré : données hors base partagée conservées',ls.get('P_exb_perso')==='[{"id":"z"}]');
 T('retiré : délié de l’entreprise',D.info().on===false);
 T('retiré : journal de purge + message + rechargement',!!ls.get('exb_purge_log')&&alerts.length===1&&/retiré/.test(alerts[0])&&reloaded===1);
 console.log(JSON.parse(ls.get('exb_purge_log')));
 console.log(ok+'/'+(ok+ko));process.exit(ko?1:0)})();
