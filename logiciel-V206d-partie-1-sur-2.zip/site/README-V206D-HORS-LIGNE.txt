EXCELLENCIA BUILDING V206d — Équipe (suspension) + HORS CONNEXION + RÉVOCATION
================================================================================
CE QUI CHANGE
1. exb-equipe.js : nouvelle version (boutons « Suspendre / Réactiver », « 📌 Projets », carte « Affectation des projets »).
2. supabase/migration-v206-lot1-suspension.sql  (À EXÉCUTER UNE FOIS, après v99w, v205-lot4/5 et v205v) :
   suspension d'un membre (il sort de « membres » : toutes les règles du serveur le refusent d'un coup), réactivation, mon_acces(),
   liste d'équipe avec les suspendus, retrait d'un suspendu. Son code personnel survit à une suspension, pas à un retrait.
3. exb-v206d-hors-ligne.js (nouveau) + exb-db.js + exb-bigstore.js : règles ci-dessous.

RÈGLES (uniquement quand l'appareil est relié à la base partagée ; mode local seul : rien ne change)
 A. FINANCES ET VALIDATIONS : connexion obligatoire. Refusées si hors connexion, ou si le serveur n'a pas confirmé l'accès depuis plus de
    15 minutes. Couvre : factures, caisse, bons de commande/paiements, paie (créer/valider/payer), paiements apprenants, décisions du Workflow
    + filet au niveau du stockage pour 26 collections financières (EXBOFF.finKeys()). Refus journalisé, rien d'enregistré.
 B. BAIL DE PRÉSENCE : 7 jours sans confirmation du serveur (ou horloge reculée) => écran verrouillé jusqu'à une vérification réussie
    (formulaire de reconnexion intégré à l'écran).
 C. APRÈS RÉVOCATION (au premier contact avec le serveur, vérification toutes les 5 min en ligne) :
    - SUSPENDU : écran verrouillé, plus de synchro ni d'écriture, données conservées (rendues à la réactivation).
    - RETIRÉ   : données de l'entreprise EFFACÉES de l'appareil (collections partagées, file chantier hors ligne, images IndexedDB
                 devenues orphelines). Message à l'utilisateur ; journal exb_purge_log (nombre de fiches, dont non envoyées).
                 L'effacement exige deux réponses « retiré » concordantes à 2,5 s d'intervalle.
    Données du compte personnel (hors base partagée) : non touchées.
 Réglages : window.EXB_OFFLINE_CONFIG = {finTtlMin:15, leaseDays:7, finKeys:[], exemptKeys:[]}.
 Mise à jour d'un appareil déjà relié : son bail démarre à la première ouverture (pas de verrouillage immédiat).
 Sans la migration lot 1 : détection du retrait par lecture de « membres » (effacement OK) ; la suspension n'existe pas.

LIMITES (honnêtes)
 - Contrôles d'application, sans chiffrement des données locales : quelqu'un qui reste hors ligne en permanence garde l'accès technique aux
   données de son navigateur jusqu'à la fin du bail ; le chiffrement local serait un chantier à part.
 - « Affectation des projets » (affectation_regle) : la fonction serveur du lot 2 n'existe pas dans ce dépôt ; la carte et le bouton Projets
   restent masqués tant qu'elle n'est pas installée (aucune erreur).
 - Les migrations v205-lot4/5 ou v99w ré-exécutées APRÈS le lot 1 écraseraient equipe_modifier / equipe_retirer : ré-exécuter alors le lot 1.

TESTS : node tools/test-hors-ligne.js (13) · node tools/test-acces-db.js (11) · psql … tools/test-rls/test-suspension.sql (24)
