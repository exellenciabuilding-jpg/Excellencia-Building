/* Excellencia Building V141p — Notes de calcul et plans d'exécution publiés sur le portail client (même portail que les plans et les devis : adresse /plan).
 * Depuis l'aperçu d'une note de calcul (NCS-…) ou d'un plan d'exécution (PEX-…) du module « Calcul de structure » :
 *   - le PDF est envoyé dans l'espace public « exb-calcul-publics », dossier au nom ALÉATOIRE ;
 *   - le serveur (fonction calcul_public_publier) attribue une référence EXN-AAAA-NNN (note) ou EXE-AAAA-NNN (plan d'exécution) et un code d'accès ;
 *   - le client reçoit un QR / un lien (référence + code), scanne, voit la fiche du document et télécharge le PDF.
 * Republier le même document (même numéro NCS-/PEX-) garde la même référence et le même code : le QR déjà remis reste valable,
 * seul le PDF est remplacé par la version la plus récente (nouvel indice, nouveau statut…). Une empreinte évite de republier un PDF inchangé.
 * Hors connexion : le PDF est gardé sur l'appareil puis publié tout seul au retour de la connexion (comme les devis, V141o).
 * Prérequis : supabase/migration-v141p-calcul-publics.sql exécuté ; connexion au serveur (☁️) ; droit « plans_fichiers » (écriture).
 * Pour désactiver la publication automatique : « 🌐 Publiés » > case « Publier automatiquement ».
 * Appelé par calcul-structure/exb-calcul-doc.js (iframe) via window.parent.EXBCALCPUB. */
(function (w, d) {
  'use strict';
  if (w.EXBCALCPUB) return;
  var BK = 'exb-calcul-publics', MAPK = 'exb_calcpub_map', AUTOK = 'exb_calcpub_auto', QK = 'exb_calcpub_queue', MAXQ = 25;
  var cfgErr = false, lastErr = '', warned = false, INFL = {};

  /* ---------- libellés par type de document ---------- */
  var G = {
    note: { nom: 'Note de calcul', court: 'note de calcul', ico: '🧮', fichier: 'note-de-calcul.pdf', dl: 'Télécharger la Note de calcul', label: 'VOTRE NOTE DE CALCUL', sub: 'Note de calcul à consulter et à télécharger en ligne', scan: 'Scannez pour accéder à votre note de calcul', how: 'COMMENT TÉLÉCHARGER VOTRE NOTE DE CALCUL', step3: 'Touchez « Télécharger la Note de calcul » pour obtenir votre note en PDF.', pngPre: 'QR-Note-' },
    pex: { nom: 'Plan d’exécution', court: 'plan d’exécution', ico: '📐', fichier: 'plan-execution.pdf', dl: 'Télécharger le Plan d’exécution', label: 'VOTRE PLAN D’EXÉCUTION', sub: 'Plan d’exécution à consulter et à télécharger en ligne', scan: 'Scannez pour accéder à votre plan d’exécution', how: 'COMMENT TÉLÉCHARGER VOTRE PLAN D’EXÉCUTION', step3: 'Touchez « Télécharger le Plan d’exécution » pour obtenir votre plan en PDF.', pngPre: 'QR-PlanExecution-' }
  };
  function gk(g) { return g === 'pex' ? 'pex' : 'note'; }

  /* ---------- petits outils ---------- */
  function ls(k, def) { try { return JSON.parse(localStorage.getItem(k)) || def; } catch (e) { return def; } }
  function ss(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* stockage plein */ } }
  function org() { try { return (w.EXBDB && w.EXBDB.org && w.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function online() { return !!(org() && w.exbSb && w.exbSb.isIn && w.exbSb.isIn() && navigator.onLine); }
  function api(p, o) { return w.exbSb.api(p, o); }
  function rpc(n, b) { return api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function frDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function say(m, t, ms) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', ms || 4500); } catch (e) { /* repli */ } try { console.log(m); } catch (e) { /* rien */ } }
  function size(n) { n = Number(n) || 0; return n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function rnd32() { var a = new Uint8Array(16); (w.crypto || w.msCrypto).getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function fmtCode(c) { c = String(c || ''); return c.length === 10 ? c.slice(0, 5) + '-' + c.slice(5) : c; }
  function baseUrl() { try { if (w.EXBVerif && w.EXBVerif.vbase) return w.EXBVerif.vbase(); } catch (e) { /* repli */ } return location.origin + '/'; }
  function linkOf(ref, code) { return baseUrl() + 'plan?ref=' + encodeURIComponent(ref) + '&k=' + encodeURIComponent(code); }
  function util() { return (w.EXBPUB && w.EXBPUB.util) || null; }
  function brand() { var E = {}; try { E = (w.EXBEntreprise && w.EXBEntreprise.get && w.EXBEntreprise.get()) || {}; } catch (e) { /* repli */ } var B = w.EXB_BRAND || {}; return String(E.name || B.name || 'Excellencia Building'); }
  function autoOn() { try { return localStorage.getItem(AUTOK) !== '0'; } catch (e) { return true; } }
  function canW() { try { return !w.EXB81 || !w.EXB81.can || w.EXB81.can('plans_fichiers', 'ecrire'); } catch (e) { return true; } }
  /* disponible = connecté à une entreprise et module chargé (utilisé par l'iframe pour afficher ou non les boutons) */
  function available() { return !!(w.exbSb && w.exbSb.api); }
  function digits(p) { p = String(p || '').replace(/[^\d+]/g, ''); if (/^0\d{9}$/.test(p)) return '243' + p.slice(1); return p.replace(/\D/g, ''); }

  /* ---------- PDF en attente (hors connexion) : conservés dans IndexedDB ---------- */
  function idb(fn) {
    return new Promise(function (ok, ko) {
      var q = indexedDB.open('exb81', 1);
      q.onupgradeneeded = function () { q.result.createObjectStore('blobs'); };
      q.onsuccess = function () { try { fn(q.result, ok, ko); } catch (e) { ko(e); } };
      q.onerror = function () { ko(q.error); };
    });
  }
  function blobPut(k, b) { return idb(function (db, ok, ko) { var t = db.transaction('blobs', 'readwrite'); t.objectStore('blobs').put(b, k); t.oncomplete = function () { ok(); }; t.onerror = function () { ko(t.error); }; }); }
  function blobGet(k) { return idb(function (db, ok, ko) { var g = db.transaction('blobs').objectStore('blobs').get(k); g.onsuccess = function () { ok(g.result || null); }; g.onerror = function () { ko(g.error); }; }); }
  function blobDel(k) { return idb(function (db, ok, ko) { var t = db.transaction('blobs', 'readwrite'); t.objectStore('blobs').delete(k); t.oncomplete = function () { ok(); }; t.onerror = function () { ko(t.error); }; }).catch(function () { /* non bloquant */ }); }
  function enqueue(m, blob) {
    return blobPut('calcpub:' + m.no, blob).then(function () {
      var q = ls(QK, {}); q[m.no] = m; var ks = Object.keys(q);
      if (ks.length > MAXQ) { ks.sort(function (a, b) { return (q[a].t || 0) - (q[b].t || 0); }); ks.slice(0, ks.length - MAXQ).forEach(function (k) { delete q[k]; blobDel('calcpub:' + k); }); }
      ss(QK, q);
    }).catch(function () { /* stockage indisponible : l'utilisateur pourra republier à la main */ });
  }
  function dequeue(m) { var q = ls(QK, {}); if (q[m.no] && q[m.no].hash === m.hash) { delete q[m.no]; ss(QK, q); blobDel('calcpub:' + m.no); } }

  /* ---------- espace public ---------- */
  function up(o, token, name, blob) {
    return api('/storage/v1/object/' + BK + '/' + o + '/' + token + '/' + name, { method: 'POST', headers: { 'Content-Type': blob.type || 'application/pdf', 'x-upsert': 'true' }, body: blob });
  }
  function purge(o, token) {
    if (!/^[a-f0-9]{32}$/.test(String(token || ''))) return Promise.resolve();
    var pre = o + '/' + token + '/';
    return api('/storage/v1/object/list/' + BK, { method: 'POST', body: JSON.stringify({ prefix: pre, limit: 20 }) })
      .then(function (L) { var n = (L || []).map(function (x) { return pre + x.name; }); if (!n.length) return null; return api('/storage/v1/object/' + BK, { method: 'DELETE', body: JSON.stringify({ prefixes: n }) }); })
      .catch(function () { /* suppression non bloquante */ });
  }
  function nice(e) {
    var msg = (e && e.message) || String(e);
    if (/function .*calcul_public|schema cache|PGRST202/i.test(msg)) { cfgErr = true; return 'Fonction serveur absente : exécutez supabase/migration-v141p-calcul-publics.sql (Supabase › SQL Editor).'; }
    if (/bucket not found|not found/i.test(msg)) { cfgErr = true; msg += ' — le script supabase/migration-v141p-calcul-publics.sql est-il exécuté ?'; }
    return msg;
  }

  /* ---------- données du document → fiche publique (m vient de l'iframe, on borne tout) ---------- */
  function meta(m) {
    m = m || {};
    return {
      genre: gk(m.genre), no: String(m.no || '').trim().slice(0, 60), titre: String(m.titre || '').slice(0, 160), projet: String(m.projet || '').slice(0, 160),
      client: String(m.client || '').slice(0, 120), etabli: String(m.etabli || '').slice(0, 120), indice: String(m.indice || '').slice(0, 12), norme: String(m.norme || '').slice(0, 120),
      statut: String(m.statut || '').slice(0, 30), date: String(m.date || '').slice(0, 10), hash: String(m.hash || '').slice(0, 80), t: Date.now()
    };
  }

  /* ---------- publication ---------- */
  function publishNow(m, blob) {
    var o = org(), token = rnd32(), U = util(), g = G[m.genre];
    return (U ? U.thumb(blob, 'pdf') : Promise.resolve('')).catch(function () { return ''; }).then(function (ap) {
      var docs = [{ nom: g.nom + ' N° ' + m.no + (m.projet ? ' — ' + m.projet : ''), fichier: o + '/' + token + '/' + g.fichier, format: 'PDF', taille: size(blob.size), kind: m.genre }];
      return up(o, token, g.fichier, blob).then(function () {
        return rpc('calcul_public_publier', { p_org: o, p_genre: m.genre, p_no: m.no, p_titre: m.titre, p_projet: m.projet, p_client: m.client, p_etabli: m.etabli, p_indice: m.indice, p_norme: m.norme, p_statut: m.statut, p_date: m.date, p_empreinte: m.hash, p_apercu: ap || null, p_docs: docs, p_token: token });
      }).then(function (res) {
        if (!res || !res.ok) { purge(o, token); throw new Error((res && res.erreur) || 'Publication refusée par le serveur.'); }
        if (res.ancien_token) purge(o, res.ancien_token);
        return { ref: res.ref, code: res.code, hash: m.hash, no: m.no, genre: m.genre, fresh: true };
      });
    });
  }
  /* Publie (ou retrouve) le document ; renvoie {ref, code, no, hash, genre} ou null (hors connexion : mis en attente ; erreur : lastError()). */
  function ensure(m, blob) {
    if (!m || !m.no || !blob) return Promise.resolve(null);
    var cur = ls(MAPK, {})[m.no];
    if (cur && cur.hash && cur.hash === m.hash) return Promise.resolve(cur);
    if (INFL[m.no] && INFL[m.no].hash === m.hash) return INFL[m.no].p;
    var prev = INFL[m.no] ? INFL[m.no].p.catch(function () { return null; }) : Promise.resolve(null);
    var p = prev.then(function () {
      var again = ls(MAPK, {})[m.no]; if (again && again.hash === m.hash) return again;
      if (cfgErr) return null;
      if (!online()) return enqueue(m, blob).then(function () { return null; });
      return publishNow(m, blob).then(function (x) {
        var map = ls(MAPK, {}); map[m.no] = { ref: x.ref, code: x.code, hash: m.hash, no: m.no, genre: m.genre, titre: m.titre, projet: m.projet, client: m.client, t: Date.now() }; ss(MAPK, map);
        dequeue(m); lastErr = ''; return x;
      }, function (e) { lastErr = nice(e); if (!cfgErr) enqueue(m, blob); return null; });
    });
    INFL[m.no] = { hash: m.hash, p: p };
    var clear = function () { if (INFL[m.no] && INFL[m.no].p === p) delete INFL[m.no]; };
    p.then(clear, clear);
    return p;
  }
  /* Appelée par l'iframe après chaque PDF de note / de plan d'exécution : publication automatique, sans bloquer. */
  function auto(raw, blob) {
    try {
      /* V141r : si ce document a déjà été envoyé à des chantiers, ils reçoivent la nouvelle version (indépendant du portail client) */
      try { if (raw && blob && raw.no && w.EXBCHDOCS) w.EXBCHDOCS.autoUpdate(meta(raw), blob); } catch (e) { /* non bloquant */ }
      if (!raw || !blob || !raw.no || !autoOn() || !canW()) return Promise.resolve(null);
      var m = meta(raw);
      return ensure(m, blob).then(function (x) {
        if (x && x.fresh) say('🌐 ' + G[m.genre].nom + ' ' + m.no + ' publié sur le portail client (réf. ' + x.ref + ') — touchez « 🌐 Portail client » pour envoyer le QR / lien.', 'success', 6500);
        else if (!x && lastErr && !warned) { warned = true; say('Publication au portail client impossible : ' + lastErr, 'warn', 9000); }
        return x;
      });
    } catch (e) { return Promise.resolve(null); /* ne jamais gêner la génération du PDF */ }
  }
  function info(no) { var x = ls(MAPK, {})[no]; return x ? { ref: x.ref, code: x.code, url: linkOf(x.ref, x.code), no: no, genre: x.genre } : null; }
  /* Publication demandée explicitement (bouton) : renvoie {ref, code, url, no, genre} ou null. */
  function publishResult(raw, blob) {
    if (!raw || !blob) return Promise.resolve(null);
    var m = meta(raw); lastErr = '';
    return ensure(m, blob).then(function (x) { return x ? { ref: x.ref, code: x.code, url: linkOf(x.ref, x.code), no: m.no, genre: m.genre } : null; });
  }

  /* ---------- envoi du lien au client ---------- */
  function message(c, x) {
    var g = G[gk(x.genre || c.genre)];
    return 'Bonjour' + (c.client ? ' ' + c.client : '') + ', votre ' + g.court + ' N° ' + c.no + (c.projet ? ' (' + c.projet + ')' : '') + ' est disponible en ligne. ' +
      'Ouvrez ce lien (ou scannez le QR code) pour le consulter et le télécharger en PDF : ' + x.url + '\n' +
      'Référence : ' + x.ref + ' · Code d’accès : ' + fmtCode(x.code) + ' — ' + brand();
  }
  function sendLink(mode, c, x) {
    var msg = message(c, x), g = G[gk(x.genre || c.genre)];
    if (mode === 'mail') { w.open('mailto:' + encodeURIComponent(c.email || '') + '?subject=' + encodeURIComponent('Votre ' + g.court + ' N° ' + c.no + ' — ' + brand()) + '&body=' + encodeURIComponent(msg), '_blank'); return 'mail'; }
    if (mode === 'share' && navigator.share) { try { navigator.share({ title: g.nom + ' N° ' + c.no, text: msg }); return 'shared'; } catch (e) { /* repli WhatsApp */ } }
    w.open('https://wa.me/' + digits(c.phone) + '?text=' + encodeURIComponent(msg), '_blank'); return 'wa';
  }

  /* ---------- fenêtre : QR / lien du document ---------- */
  function ov(title, body, maxw) {
    var old = d.getElementById('exbCalcPub'); if (old) old.remove();
    var o = d.createElement('div'); o.id = 'exbCalcPub'; o.style.cssText = 'position:fixed;inset:0;z-index:2147483100;background:rgba(15,23,42,.6);display:flex;align-items:flex-start;justify-content:center;padding:12px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;max-width:' + (maxw || 560) + 'px;width:100%;padding:16px;margin-top:20px;font-family:Arial,sans-serif;color:#172033';
    c.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b style="font-size:16px;color:#173565">' + title + '</b><button id="cpX" style="border:0;border-radius:10px;padding:9px 12px;background:#e8edf5;color:#173565;font-weight:700;cursor:pointer">✕</button></div>' + body;
    o.appendChild(c); d.body.appendChild(o); c.querySelector('#cpX').onclick = function () { o.remove(); }; return c;
  }
  var BT = 'border:1px solid #cbd5e1;border-radius:10px;padding:9px 12px;background:#f1f5f9;color:#173565;font-weight:700;font-size:13px;cursor:pointer;text-decoration:none;display:inline-block;';
  function show(x, c) {
    c = c || {}; var gen = gk(x.genre || c.genre), g = G[gen], url = x.url || linkOf(x.ref, x.code), png = ''; try { png = w.EXBVerif && w.EXBVerif.qrPng ? w.EXBVerif.qrPng(url) : ''; } catch (e) { /* QR indisponible */ }
    var h = '<p style="background:#effaf3;border:1px solid #b5e1c5;color:#176b3d;padding:10px;border-radius:10px;margin:10px 0"><b>✓ ' + esc(g.nom) + ' ' + esc(x.no || c.no || '') + ' en ligne</b> — le client peut le consulter et télécharger son PDF.</p>' +
      '<div style="display:flex;flex-wrap:wrap;gap:16px;align-items:center">' + (png ? '<img src="' + png + '" alt="QR Code du document" style="width:200px;height:200px;image-rendering:pixelated;border:1px solid #dce4ef;border-radius:8px">' : '') +
      '<div style="flex:1;min-width:200px;font-size:14px"><div><span style="color:#64748b">Référence</span><br><b style="font-size:20px;color:#082653">' + esc(x.ref) + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:#64748b">Code d’accès</span><br><b style="font-size:20px;letter-spacing:1px">' + esc(fmtCode(x.code)) + '</b></div>' +
      '<div style="font-size:12px;color:#64748b;margin-top:8px">Le client scanne le QR avec l’appareil photo de son téléphone, ou ouvre l’adresse du portail et saisit la référence et le code.</div></div></div>' +
      '<p style="margin:12px 0 4px"><input id="cpLink" readonly value="' + esc(url) + '" style="width:100%;padding:8px;box-sizing:border-box;font-size:12px;border:1px solid #cbd5e1;border-radius:8px"></p>' +
      '<div style="display:flex;flex-wrap:wrap;gap:6px;margin:8px 0"><button id="cpCp" style="' + BT + '">📋 Copier le lien</button>' +
      '<button id="cpWa" style="' + BT + 'background:#dcfce7">💬 WhatsApp</button><button id="cpMl" style="' + BT + '">✉️ E-mail</button>' +
      (png ? '<a href="' + png + '" download="QR-' + esc(x.ref) + '.png" style="' + BT + '">⬇ QR (PNG)</a>' : '') +
      (png && w.EXBPUB && w.EXBPUB.print ? '<button id="cpPr" style="' + BT + '">🖨 Imprimer la fiche QR</button>' : '') +
      '<button id="cpLs" style="' + BT + '">🌐 Documents publiés</button></div>';
    var cc = ov('🌐 Portail client — ' + esc(g.nom.toLowerCase()) + ' ' + esc(x.no || c.no || ''), h, 560);
    var $ = function (i) { return cc.querySelector('#' + i); };
    var cx = { no: x.no || c.no, client: c.client, projet: c.projet, phone: c.phone, email: c.email, genre: gen };
    $('cpCp').onclick = function () { var e = $('cpLink'); e.select(); try { navigator.clipboard.writeText(e.value); } catch (z) { d.execCommand('copy'); } say('Lien copié.', 'success'); };
    $('cpWa').onclick = function () { sendLink('wa', cx, { url: url, ref: x.ref, code: x.code, genre: gen }); };
    $('cpMl').onclick = function () { sendLink('mail', cx, { url: url, ref: x.ref, code: x.code, genre: gen }); };
    $('cpLs').onclick = list;
    if ($('cpPr')) $('cpPr').onclick = function () { printSheet(x, c); };
  }
  function printSheet(x, c) {
    c = c || {}; if (!w.EXBPUB || !w.EXBPUB.print) return;
    var gen = gk(x.genre || c.genre), g = G[gen];
    w.EXBPUB.print(x.ref, x.code, g.nom + ' N° ' + (x.no || c.no || '') + (c.projet ? ' — ' + c.projet : (c.client ? ' — ' + c.client : '')), { label: g.label, sub: g.sub, scan: g.scan, how: g.how, step3: g.step3, file: g.pngPre });
  }

  /* ---------- liste des documents publiés ---------- */
  function list() {
    if (!online()) { say('Connectez-vous au serveur (☁️) pour voir les documents publiés.', 'warn'); return; }
    rpc('calcul_public_lister', { p_org: org() }).then(function (L) {
      L = Array.isArray(L) ? L : [];
      var h = '<label style="display:flex;gap:8px;align-items:center;margin:10px 0;font-size:13px"><input type="checkbox" id="cpAuto"' + (autoOn() ? ' checked' : '') + '> Publier automatiquement chaque PDF de note de calcul / de plan d’exécution</label>' +
        (L.length ? '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><tr style="text-align:left;background:#f1f5fb"><th style="padding:6px">Référence</th><th>Document</th><th>Mis à jour</th><th>État</th><th></th></tr>' +
        L.map(function (x, i) {
          var g = G[gk(x.genre)];
          return '<tr style="border-bottom:1px solid #e2e8f0;' + (x.actif ? '' : 'opacity:.55') + '"><td style="padding:6px"><b>' + esc(x.ref) + '</b></td><td>' + g.ico + ' ' + esc(x.doc_no) + (x.indice ? ' · ind. ' + esc(x.indice) : '') + '<br><small>' + esc(x.projet || x.titre || '') + (x.client ? ' · ' + esc(x.client) : '') + '</small></td><td>' + frDate(String(x.maj_le || '').slice(0, 10)) + '</td><td>' + (x.actif ? '✅ En ligne' : '⛔ Retiré') + '</td><td>' +
            (x.actif ? '<button data-i="' + i + '" class="cpQ" style="' + BT + 'padding:6px 8px">QR / lien</button> <button data-r="' + esc(x.ref) + '" class="cpR" style="' + BT + 'padding:6px 8px">Retirer</button>' : '') + '</td></tr>';
        }).join('') + '</table></div>' : '<p style="color:#64748b">Aucun document publié pour le moment. Générez le PDF d’une note de calcul ou d’un plan d’exécution : il est publié automatiquement.</p>') +
        (w.EXBESPACE ? '<p style="margin:12px 0 0"><button id="cpEsp" style="' + BT + '">🗄 Espace serveur (archiver et libérer de la place)</button></p>' : '');
      var cc = ov('🌐 Notes de calcul et plans d’exécution publiés', h, 780);
      if (cc.querySelector('#cpEsp')) cc.querySelector('#cpEsp').onclick = function () { w.EXBESPACE.open(); };
      cc.querySelector('#cpAuto').onchange = function () { try { localStorage.setItem(AUTOK, this.checked ? '1' : '0'); } catch (e) { /* rien */ } say(this.checked ? 'Publication automatique activée.' : 'Publication automatique désactivée : utilisez « 🌐 Portail client » pour publier un document.', 'info'); };
      cc.querySelectorAll('.cpQ').forEach(function (b) { b.onclick = function () { var x = L[Number(b.getAttribute('data-i'))]; show({ ref: x.ref, code: x.code, no: x.doc_no, genre: x.genre }, { no: x.doc_no, client: x.client, projet: x.projet, genre: x.genre }); }; });
      cc.querySelectorAll('.cpR').forEach(function (b) { b.onclick = function () { retire(b.getAttribute('data-r')); }; });
    }).catch(function (e) { say(nice(e) || 'Liste indisponible.', 'error', 7000); });
  }
  function retire(ref) {
    if (!w.confirm('Retirer ' + ref + ' ? Le client ne pourra plus consulter ni télécharger ce document (le QR remis cessera de fonctionner).')) return;
    var o = org();
    rpc('calcul_public_retirer', { p_org: o, p_ref: ref }).then(function (r) {
      if (!r || !r.ok) throw new Error((r && r.erreur) || 'Retrait refusé.');
      var m = ls(MAPK, {}); Object.keys(m).forEach(function (k) { if (m[k].ref === ref) delete m[k]; }); ss(MAPK, m);
      return purge(o, r.token);
    }).then(function () { say('Document retiré du portail.', 'success'); list(); }).catch(function (e) { say((e && e.message) || 'Retrait impossible.', 'error'); });
  }

  /* ---------- reprise automatique des documents en attente ---------- */
  var FL = false;
  function flush() {
    if (FL || cfgErr || !online()) return Promise.resolve(0);
    var q = ls(QK, {}), nos = Object.keys(q), n = 0; if (!nos.length) return Promise.resolve(0);
    FL = true;
    return nos.reduce(function (pr, no) {
      return pr.then(function () {
        var m = q[no];
        return blobGet('calcpub:' + no).then(function (b) {
          if (!b) { dequeue(m); return null; }
          return ensure(m, b).then(function (x) { if (x) { n++; dequeue(m); } });
        });
      });
    }, Promise.resolve()).catch(function () { /* nouvel essai au prochain passage */ }).then(function () { FL = false; if (n) say('🌐 ' + n + ' document' + (n > 1 ? 's' : '') + ' de calcul publié' + (n > 1 ? 's' : '') + ' sur le portail client.', 'success'); return n; });
  }
  try {
    setInterval(flush, 30000);
    w.addEventListener('online', function () { setTimeout(flush, 1500); });
    setTimeout(flush, 11000);
  } catch (e) { /* rien */ }

  w.EXBCALCPUB = { auto: auto, ensure: ensure, publishResult: publishResult, sendLink: sendLink, show: show, list: list, retire: retire, info: info, flush: flush, printSheet: printSheet, autoOn: autoOn, available: available, canWrite: canW, online: online, lastError: function () { return lastErr; }, pending: function () { return Object.keys(ls(QK, {})).length; } };
})(window, document);
