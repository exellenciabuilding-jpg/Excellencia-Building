/* Excellencia Building V122 — « Documents de chantier » : UN SEUL LIEU pour tous les documents d’un chantier.
 * Rapports, procès-verbaux, comptes rendus, ordres de service, clauses, fiches de contrôle, lettres, contrats, attestations,
 * notes, dossier de chantier : choisir le chantier (projet), puis la famille de document, puis le modèle.
 * Les documents sont enregistrés comme les « Pièces écrites » (même stockage exb_pieces) : PDF officiel bleu et or,
 * en-tête, pied de page, QR code de vérification sur chaque page, signature et cachet du Directeur Général.
 * Le bouton est placé à côté de « Projet 360° » (module chantier). */
(function (w, d) {
  'use strict';
  var C = w.EXB81, P = w.EXBPIE, D = w.EXBPIE_DATA;
  if (!C || !P || !D) return;

  var KEY = 'exb_pieces', COL = 'pieces', NAVY = '#173565', GOLD = '#c49a38', CREAM = '#fffbeb';
  var st = { pid: '', cat: '', q: '', etat: '' }, REG = [], fromHub = false;

  /* familles de documents : [code, icône, nom, types de pièces concernés] */
  var CATS = [
    ['rapport', '📊', 'Rapports de chantier', ['rapport']],
    ['pv', '📝', 'Procès-verbaux', ['pv']],
    ['cr', '🗒️', 'Comptes rendus de réunion', ['cr']],
    ['os', '📣', 'Ordres de service', ['os']],
    ['clause', '⚖️', 'Clauses de chantier', ['clause', 'ccap']],
    ['fiche', '🧾', 'Fiches, contrôles et formulaires', ['fiche']],
    ['lettre', '✉️', 'Lettres et correspondance', ['lettre']],
    ['contrat', '🤝', 'Contrats et avenants', ['contrat']],
    ['attest', '🏅', 'Attestations', ['attest']],
    ['note', '📋', 'Notes, plans et méthodes', ['note']],
    ['dossier', '📂', 'Dossier de chantier', ['dossier']],
    ['cctp', '📐', 'CCTP (lots techniques)', ['cctp']],
    ['libre', '✍️', 'Texte libre', ['libre']]
  ];

  function esc(s) { return C.esc(s); }
  function L() { return w.EXBS.get(KEY); }
  function S(a) { return w.EXBS.set(KEY, a); }
  function canW() { return C.can(COL, 'ecrire'); }
  function lib(t) { return t === 'ccap' ? (D.ccap || {}) : (D.models[t] || {}); }
  function ty(t) { return D.types[t] || [String(t || '?').toUpperCase().slice(0, 3), String(t || 'Pièce'), '📄']; }
  function docs(pid) { return L().filter(function (x) { return !x.modele && String(x.project) === String(pid); }); }
  function catOf(k) { return CATS.filter(function (c) { return c[0] === k; })[0]; }
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
  function snip(b) {
    var l = String(b || '').split(/\n/).filter(function (s) { return s.trim() && !/^#|^\|/.test(s) && !/^(Objet|Réf|Projet|Maître)/.test(s); })[0] || '';
    l = l.replace(/\*\*|\{\{\w+\}\}/g, '…');
    return l.length > 100 ? l.slice(0, 100) + '…' : l;
  }

  /* ---------- couleurs : même thème bleu et or que le PDF officiel ---------- */
  function css() {
    if (d.getElementById('exbDchCss')) return;
    var s = d.createElement('style'); s.id = 'exbDchCss';
    s.textContent =
      '#exbDch>div,#exbPie>div{border-top:5px solid ' + GOLD + '}' +
      '#exbDch>div>div:first-child,#exbPie>div>div:first-child{background:linear-gradient(135deg,' + NAVY + ',#0f2549);color:#fff;margin:-16px -16px 12px;padding:12px 16px;border-radius:9px 9px 0 0;border-bottom:3px solid ' + GOLD + ';align-items:center}' +
      '#exbDch>div>div:first-child b,#exbPie>div>div:first-child b{color:#fff}' +
      '#exbDch>div>div:first-child button,#exbPie>div>div:first-child button{background:' + GOLD + ';color:' + NAVY + ';border:0;border-radius:8px;padding:6px 11px;font-weight:bold}' +
      '#exbDch .dt{display:block;text-align:left;border:1px solid #e6d9b0;border-left:6px solid ' + GOLD + ';border-radius:10px;background:#fff;padding:10px;color:' + NAVY + '}' +
      '#exbDch .dt small{color:#64748b;display:block;margin-top:2px}' +
      '#exbDch .dm{display:block;width:100%;text-align:left;margin:4px 0;padding:9px;border:1px solid #cdd6e6;border-left:5px solid ' + NAVY + ';border-radius:9px;background:#f8fafc;color:#172033}' +
      '#exbDch .dm small{display:block;color:#64748b;margin-top:2px}' +
      '#exbDch .db{padding:10px 14px;background:' + NAVY + ';color:#fff;border:0;border-radius:8px;border-bottom:3px solid ' + GOLD + ';font-weight:bold}' +
      '#exbDch .dg{padding:10px 14px;background:' + CREAM + ';color:' + NAVY + ';border:1px solid ' + GOLD + ';border-radius:8px}' +
      '#exbDch h4{margin:14px 0 6px;color:' + NAVY + ';border-bottom:2px solid ' + GOLD + ';padding-bottom:3px}' +
      '#exbDch .st{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:bold}' +
      '#exbDch table{width:100%;border-collapse:collapse}#exbDch th{text-align:left;background:#e8edf5;color:' + NAVY + ';padding:6px}#exbDch td{padding:6px;border-bottom:1px solid #e2e8f0;vertical-align:top}';
    d.head.appendChild(s);
  }

  function badge(s) {
    var sty = s === 'signé' ? 'background:' + GOLD + ';color:' + NAVY : (s === 'émis' ? 'background:' + NAVY + ';color:#fff' : 'background:' + CREAM + ';color:#8a6a1c;border:1px solid ' + GOLD);
    return '<span class="st" style="' + sty + '">' + esc(s || 'brouillon') + '</span>';
  }

  function table(A) {
    if (!A.length) return '<p style="color:#64748b">Aucun document pour le moment.</p>';
    return '<div style="overflow-x:auto"><table><tr><th>N°</th><th>Document</th><th>Date</th><th>État</th><th></th></tr>' +
      A.map(function (x) {
        return '<tr><td>' + ty(x.type)[2] + ' ' + esc(x.no) + '</td><td>' + esc(x.title) + (x.model ? '<br><small style="color:#64748b">' + esc(x.model) + '</small>' : '') + '</td><td>' + C.frDate(x.date) + '</td><td>' + badge(x.status) + '</td><td><button class="dg" onclick="EXBDCH.edit(\'' + esc(x.id) + '\')">✏️ Ouvrir</button></td></tr>';
      }).join('') + '</table></div>';
  }

  function head() {
    var A = docs(st.pid), n = function (e) { return A.filter(function (x) { return (x.status || 'brouillon') === e; }).length; };
    var box = function (l, v, bg) { return '<div style="flex:1 1 22%;background:' + bg + ';border-radius:10px;padding:8px;border:1px solid #e6d9b0"><div style="font-size:12px;color:#64748b">' + l + '</div><b style="color:' + NAVY + ';font-size:17px">' + v + '</b></div>'; };
    return '<p style="margin:0 0 6px;color:#64748b;font-size:12px">' + esc(C.brand()) + ' · tous les documents du chantier au même endroit · PDF officiel bleu et or avec QR code de vérification.</p>' +
      '<p style="margin:6px 0">' + C.projSelect('EXBDCH.proj', st.pid) + '</p>' +
      '<div style="display:flex;flex-wrap:wrap;gap:6px;margin:8px 0">' + box('Documents', A.length, '#eef2fa') + box('Brouillons', n('brouillon'), CREAM) + box('Émis', n('émis'), '#eef2fa') + box('Signés', n('signé'), CREAM) + '</div>';
  }

  /* ---------- écran d’accueil : familles + recherche ---------- */
  function home() {
    css(); REG = [];
    if (!st.pid) st.pid = C.firstProject();
    st.cat = ''; var A = docs(st.pid);
    var cnt = function (types) { return A.filter(function (x) { return types.indexOf(x.type) >= 0; }).length; };
    var mcount = function (types) { return types.reduce(function (n, t) { return n + (t === 'cctp' ? Object.keys(D.lots || {}).length : Object.keys(lib(t)).length); }, 0); };
    var h = head() +
      '<p style="margin:8px 0"><input id="dchQ" oninput="EXBDCH.q(this.value)" placeholder="🔎 Chercher un modèle : réception, béton, retard, sécurité…" value="' + esc(st.q) + '" style="width:100%;box-sizing:border-box;padding:10px;border:2px solid ' + GOLD + ';border-radius:10px"></p>' +
      '<div id="dchRes"></div>' +
      '<div id="dchGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:8px">' +
      CATS.map(function (c) {
        var m = mcount(c[3]);
        return '<button class="dt" onclick="EXBDCH.cat(\'' + c[0] + '\')"><span style="font-size:22px">' + c[1] + '</span> <b>' + esc(c[2]) + '</b><small>' + m + (c[0] === 'cctp' ? ' lots' : ' modèles') + ' · ' + cnt(c[3]) + ' document' + (cnt(c[3]) > 1 ? 's' : '') + ' ici</small></button>';
      }).join('') + '</div>' +
      '<p style="margin-top:12px"><button class="db" onclick="EXBDCH.all()">📚 Tous les documents du chantier (' + A.length + ')</button> ' +
      '<button class="dg" onclick="EXBDCH.somm()">📂 Générer le sommaire du dossier</button> ' +
      '<button class="dg" onclick="EXBDCH.mods()">⭐ Mes modèles</button></p>' +
      '<p style="font-size:12px;color:#64748b">Les modèles sont des bases courantes à adapter ; faites valider les clauses contractuelles (pénalités, garanties, assurances) par votre conseil juridique.</p>';
    C.overlay('exbDch', '📂 Documents de chantier', h, 960);
    if (st.q) q(st.q);
  }

  /* ---------- recherche transversale ---------- */
  function q(v) {
    st.q = v || ''; var r = d.getElementById('dchRes'), g = d.getElementById('dchGrid'); if (!r) return;
    var k = norm(st.q).trim();
    if (!k) { r.innerHTML = ''; if (g) g.style.display = ''; return; }
    var out = [];
    CATS.forEach(function (c) {
      c[3].forEach(function (t) {
        if (t === 'cctp') return;
        Object.keys(lib(t)).forEach(function (n, i) { if (norm(n).indexOf(k) >= 0 || norm(ty(t)[1]).indexOf(k) >= 0) out.push({ t: t, i: i, n: n }); });
      });
    });
    if (g) g.style.display = 'none';
    r.innerHTML = out.length ? '<h4>' + out.length + ' modèle' + (out.length > 1 ? 's' : '') + ' trouvé' + (out.length > 1 ? 's' : '') + '</h4>' + out.slice(0, 40).map(modelBtn).join('') : '<p style="color:#64748b">Aucun modèle trouvé. Essayez un autre mot, ou ouvrez une famille.</p>';
  }

  function modelBtn(m) {
    REG.push(m); var body = lib(m.t)[m.n];
    return '<button class="dm" onclick="EXBDCH.go(' + (REG.length - 1) + ')"><b>' + ty(m.t)[2] + ' ' + esc(m.n) + '</b> <small style="display:inline;color:#8a6a1c">(' + esc(ty(m.t)[1]) + ')</small><small>' + esc(snip(body)) + '</small></button>';
  }

  /* ---------- une famille : modèles + documents existants ---------- */
  function cat(k) {
    css(); REG = []; st.cat = k; var c = catOf(k); if (!c) return home();
    var A = docs(st.pid).filter(function (x) { return c[3].indexOf(x.type) >= 0; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var h = '<p style="margin:0 0 6px"><button class="dg" onclick="EXBDCH.open()">← Familles</button></p>' +
      '<p style="margin:6px 0;color:#64748b">Chantier : <b style="color:' + NAVY + '">' + esc(C.pn(st.pid)) + '</b></p>';
    h += '<h4>' + c[1] + ' Documents existants (' + A.length + ')</h4>' + table(A);
    h += '<h4>➕ Créer un document — choisir un modèle</h4>';
    h += '<p style="margin:6px 0"><input id="dchF" oninput="EXBDCH.f(this.value)" placeholder="🔎 Filtrer les modèles de cette famille…" style="width:100%;box-sizing:border-box;padding:9px;border:2px solid ' + GOLD + ';border-radius:10px"></p><div id="dchM">';
    c[3].forEach(function (t) {
      if (t === 'cctp') { h += '<button class="dm" onclick="EXBDCH.cctp()"><b>📐 CCTP à la carte</b><small>Cochez les lots techniques à inclure (' + Object.keys(D.lots || {}).length + ' lots disponibles)</small></button>'; return; }
      Object.keys(lib(t)).forEach(function (n, i) { h += modelBtn({ t: t, i: i, n: n }); });
    });
    h += '</div>';
    if (k !== 'cctp') h += '<p><button class="dg" onclick="EXBDCH.blank(\'' + c[3][0] + '\')">✍️ Texte vierge : je rédige moi-même</button></p>';
    C.overlay('exbDch', c[1] + ' ' + esc(c[2]), h, 960);
  }

  /* ---------- tous les documents du chantier ---------- */
  function all(fl) {
    css(); if (fl !== undefined) st.etat = fl;
    var A = docs(st.pid).filter(function (x) { return !st.etat || (x.status || 'brouillon') === st.etat; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var chip = function (v, l) { return '<button class="' + (st.etat === v ? 'db' : 'dg') + '" onclick="EXBDCH.all(\'' + v + '\')" style="margin:2px">' + l + '</button>'; };
    var h = '<p style="margin:0 0 6px"><button class="dg" onclick="EXBDCH.open()">← Familles</button></p>' +
      '<p style="margin:6px 0">' + C.projSelect('EXBDCH.proj2', st.pid) + '</p><p>' + chip('', 'Tous') + chip('brouillon', 'Brouillons') + chip('émis', 'Émis') + chip('signé', 'Signés') + '</p>' + table(A);
    C.overlay('exbDch', '📚 Tous les documents du chantier', h, 960);
  }

  /* ---------- lancement dans l’éditeur des pièces écrites ---------- */
  function launch(t, idx, id) {
    if (!id && !canW()) return C.say('Écriture non autorisée.', 'error');
    var o = d.getElementById('exbDch'); if (o) o.remove();
    fromHub = true; P.proj(st.pid);
    if (id) { P.edit(id); return; }
    P.ct(t); if (idx >= 0) P.use(idx);
  }

  /* ---------- sommaire automatique du dossier de chantier ---------- */
  function nextNo(t) {
    var y = new Date().getFullYear(), p = ty(t)[0] + '-' + y;
    return p + '-' + String(L().filter(function (x) { return !x.modele && x.type === t && String(x.no || '').indexOf(p) === 0; }).length + 1).padStart(3, '0');
  }
  function somm() {
    if (!canW()) return C.say('Écriture non autorisée.', 'error');
    var A = docs(st.pid).filter(function (x) { return x.type !== 'dossier'; }).sort(function (a, b) { return a.date > b.date ? 1 : -1; });
    if (!A.length) return C.say('Aucun document à lister : créez d’abord des documents pour ce chantier.', 'error');
    var cell = function (s) { return String(s == null ? '' : s).replace(/\|/g, '/').replace(/\s+/g, ' ').trim() || '—'; };
    var nb = function (e) { return A.filter(function (x) { return (x.status || 'brouillon') === e; }).length; };
    var body = '# SOMMAIRE DU DOSSIER DE CHANTIER\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{societe}}\nDate d’édition : {{date}}\n## Documents du dossier\n| N° | Famille | Titre | Date | État |\n' +
      A.map(function (x) { return '| ' + cell(x.no) + ' | ' + cell(ty(x.type)[1]) + ' | ' + cell(x.title) + ' | ' + cell(C.frDate(x.date)) + ' | ' + cell(x.status || 'brouillon') + ' |'; }).join('\n') +
      '\n## Récapitulatif\n- ' + A.length + ' documents : ' + nb('signé') + ' signés, ' + nb('émis') + ' émis, ' + nb('brouillon') + ' brouillons.\nChaque page du PDF porte un QR code de vérification : son scan ouvre la page publique d’authenticité du document.';
    var x = { id: C.uid('PIE'), type: 'dossier', project: st.pid, no: nextNo('dossier'), date: C.today(), status: 'brouillon', title: 'Sommaire du dossier de chantier — ' + C.pn(st.pid), dest: '', entreprise: '', lot: '', objet: '', effet: '', model: 'Sommaire automatique', sign: '', body: body };
    var a = L(); a.push(x); S(a);
    launch('', -1, x.id);
  }

  /* ---------- ouverture ---------- */
  function open() {
    if (!C.can(COL, 'lire')) return C.say('Accès non autorisé.', 'error');
    st.q = ''; home();
  }

  /* retour « ← Liste » de l’éditeur : revient au hub quand on en vient */
  var ob = P.back;
  P.back = function () { if (fromHub && d.getElementById('exbPie')) { fromHub = false; var o = d.getElementById('exbPie'); if (o) o.remove(); return home(); } fromHub = false; return ob.apply(this, arguments); };
  try { new MutationObserver(function () { if (fromHub && !d.getElementById('exbPie')) fromHub = false; }).observe(d.body || d.documentElement, { childList: true }); } catch (e) {}

  w.EXBDCH = {
    open: open,
    proj: function (v) { st.pid = v; home(); },
    proj2: function (v) { st.pid = v; all(); },
    q: q,
    cat: cat,
    all: all,
    somm: somm,
    mods: function () { var o = d.getElementById('exbDch'); if (o) o.remove(); fromHub = true; P.proj(st.pid); P.mods(); },
    go: function (i) { var m = REG[i]; if (m) launch(m.t, m.i); },
    cctp: function () { launch('cctp', -1); },
    f: function (v) { var k = norm(v).trim(); [].forEach.call(d.querySelectorAll('#dchM .dm'), function (b) { b.style.display = !k || norm(b.textContent).indexOf(k) >= 0 ? '' : 'none'; }); },
    blank: function (t) { if (!canW()) return C.say('Écriture non autorisée.', 'error'); var o = d.getElementById('exbDch'); if (o) o.remove(); fromHub = true; P.proj(st.pid); P.ct(t); P.blank(); },
    edit: function (id) { launch('', -1, id); }
  };

  /* thème bleu et or aussi pour les pièces écrites ouvertes depuis le hub */
  css();

  /* bouton : à côté du module chantier (« Projet 360° »), sinon à côté de « Pièces écrites » */
  C.addButton('exbDchBtn', '📂 Documents de chantier', open, COL);
  function place() {
    var b = d.getElementById('exbDchBtn'), r = d.getElementById('bv67') || d.getElementById('exbV73Btn') || d.getElementById('exbPieBtn');
    if (b && r && r.parentNode === b.parentNode && r.nextSibling !== b) r.parentNode.insertBefore(b, r.nextSibling);
  }
  try { new MutationObserver(place).observe(d.documentElement, { childList: true, subtree: true }); } catch (e) {}
  d.addEventListener('DOMContentLoaded', place); place();
})(window, document);
