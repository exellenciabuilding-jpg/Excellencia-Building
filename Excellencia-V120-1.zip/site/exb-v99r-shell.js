/* Excellencia Building V99r — nouveau cadre : barre du haut (recherche, notifications, profil administrateur avec photo),
 * menu latéral par catégories (un clic = uniquement les éléments de la catégorie), accueil avec bannière photo.
 * AUCUN écran, AUCUNE donnée ni fonction existante n'est modifié : le menu d'origine (#app .tabs) reste dans la page (masqué)
 * et chaque carte du nouveau menu déclenche le bouton d'origine. Photos et nom du profil : enregistrés sur cet appareil. */
(function(w,d){'use strict';
var VERSION=w.EXB_VERSION='V99',BAN=['assets/accueil/banniere-1.jpg','assets/accueil/banniere-2.jpg','assets/accueil/banniere-3.jpg','assets/accueil/banniere-4.jpg'];
var CATS=[
 {k:'home',i:'🏠',t:'Accueil'},
 {k:'ent',i:'🏢',t:'Entreprise',d:'Direction, personnel, communication, documents'},
 {k:'for',i:'🎓',t:'Formation',d:'Du dossier de l’apprenant jusqu’au certificat'},
 {k:'crm',i:'👥',t:'Clients & CRM',d:'Clients, licences et demandes'},
 {k:'arc',i:'📐',t:'Architecture',d:'Études, plans, BIM et diagnostic'},
 {k:'ing',i:'🧮',t:'Ingénierie & Structure',d:'Métrés, béton armé et devis'},
 {k:'prj',i:'🏗️',t:'Projets & Chantiers',d:'Suivi de projets, chantiers et terrain'},
 {k:'fin',i:'💰',t:'Finance',d:'Paiements, encaissements et comptabilité'},
 {k:'ach',i:'🛒',t:'Achats & Stocks',d:'Matériaux, entrées et sorties'},
 {k:'rap',i:'📊',t:'Rapports',d:'Statistiques, registre et sauvegardes'},
 {k:'set',i:'⚙️',t:'Paramètres',d:'Identité, logos, administration et réglages'}];
var MAP={tflSec:'for',btfl:'for',decomptes:'fin',bdec:'fin',budgetfin:'fin',bbfin:'fin',chantierctl:'prj',bctl:'prj',plangantt:'prj',bplan:'prj',pilotprojet:'prj',bpilot:'prj',dashboard:'home',direction:'ent',enterprise360:'ent',rh:'ent',communication:'ent',documents:'ent',
 participantForm:'for',receipts:'for',participants:'for',cards:'for',formations:'for',formateurs:'for',planning:'for',presence:'for',tpTd:'for',evaluations:'for',cotation:'for',certs:'for',bulk:'for',portailApprenant:'for',
 clients:'crm',bportails:'crm',bureauEtudes:'arc',architecture:'arc',etudes3:'arc',metreDevis:'ing',calcStructure:'ing',planEditeur:'arc',bplanedit:'arc',bcs_pre:'ing',bcs_sfi:'ing',bcs_rad:'ing',bcs_mur:'ing',bcs_bat:'ing',bcs_pou:'ing',bcs_sem:'ing',bcs_esc:'ing',bcs_dos:'ing',bcs_pot:'ing',bcs_dal:'ing',bcs_mor:'ing',bcs_vol:'ing',bcs_cof:'ing',bcs_fer:'ing',bcs_mom:'ing',bcs_cou:'ing',bcs_agg:'ing',bcs_dev:'ing',bcs_ven:'ing',bcs_sei:'ing',bcs_por:'ing',bcs_cmb:'ing',bcs_rob:'ing',bcs_pie:'ing',bcs_mac:'ing',bcs_apo:'ing',bcs_apt:'ing',bcs_bpo:'ing',bcs_bpt:'ing',projets:'prj',chantiers:'prj',terrain:'prj',
 finances:'fin',comptabilite:'fin',stock:'ach',reports:'rap',registry:'rap',
 logoexb:'set',logordc:'set',affiches:'set',administration:'set',settings:'set',cloudSync:'set',proprietaire:'set',equipe:'set',vitrine:'set'};
var DESC={bcs_rob:'Analyse de structure (Robot) : modèle, charges, résultats',budgetfin:'Budget mensuel, comparatif, TVA, fiche client',bbfin:'Budget mensuel, comparatif, TVA, fiche client',decomptes:'Décomptes, retenues, cautions',chantierctl:'Checklists, causeries, non-conformités',plangantt:'Gantt, chemin critique, budget',pilotprojet:'Coût, délai et alertes par chantier',bpilot:'Coût, délai et alertes par chantier',equipe:'Invitations, rôles et fonctions',bportails:'Portails client et sous-traitant, e-signature, relances',proprietaire:'Clients, licences et essais',participantForm:'Demandes et fiches',receipts:'Reçus et QR',participants:'Liste et profils',cards:'Cartes professionnelles',formations:'Catalogue des formations',formateurs:'Équipe pédagogique',planning:'Sessions et calendrier',presence:'Pointage',tpTd:'Copies et épreuves',evaluations:'Notes et résultats',cotation:'Cotations',certs:'Certificats PDF',bulk:'Impression par lots',portailApprenant:'Espace apprenant',
 direction:'Pilotage et indicateurs',enterprise360:'Vue globale',rh:'Paie, congés, permis',communication:'Messages et annonces',documents:'Pièces et archives',clients:'Fiches et licences',bureauEtudes:'Plans, BIM, CDE',metreDevis:'Béton armé, devis, matériaux',calcStructure:'Tous les calculs béton armé',planEditeur:'Plans 2D/3D, mobilier, électricité',bplanedit:'Plans 2D/3D, mobilier, électricité',bcs_pre:'Dalle, poutre, poteau, semelle',bcs_bat:'Descente de charges, 3D, plans',bcs_pou:'Poutre continue BAEL / EC2',bcs_sem:'Semelle et fondation',bcs_esc:'Droit, balancé, va-et-vient',bcs_dos:'Ciment, sable, gravier, eau',bcs_pot:'Poteau béton armé, ferraillage',bcs_dal:'Dalle et plancher, aciers',bcs_mor:'Dosage du mortier',bcs_vol:'Volumes de béton',bcs_cof:'Surfaces de coffrage',bcs_fer:'Aciers, barres et cadres',bcs_mom:'Moment fléchissant maximal',bcs_cou:'Coût des ouvrages',bcs_agg:'Agglos et maçonnerie',bcs_dev:'Devis quantitatif et estimatif',bcs_ven:'Pression et efforts du vent',bcs_sei:'Forces sismiques par niveau',bcs_pie:'Capacité portante et armatures',bcs_mac:'Mur porteur en agglos, EN 1996',bcs_apo:'Profilé IPE / HEA, EN 1993',bcs_apt:'Flambement, EN 1993',bcs_bpo:'Bois massif, EN 1995',bcs_bpt:'Flambement bois, EN 1995',projets:'Suivi, planning, budget',finances:'Paiements et encaissements',comptabilite:'Écritures et bilans',stock:'Entrées / sorties',reports:'Statistiques',registry:'Export / import',administration:'Utilisateurs et journal',settings:'Réglages',logoexb:'Identité',logordc:'Identité',affiches:'Affiches',cloudSync:'Synchronisation'};
var $=function(i){return d.getElementById(i)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function sget(k,df){try{var v=w.localStorage.getItem(k);return v==null?df:v}catch(e){return df}}
function sset(k,v){try{w.localStorage.setItem(k,v);return true}catch(e){return false}}
function sdel(k){try{w.localStorage.removeItem(k)}catch(e){}}
function g(f,df){try{var v=f();return v==null?df:v}catch(e){return df}}
function cat(k){return CATS.filter(function(c){return c.k===k})[0]}
function guess(t){t=String(t).toLowerCase();
 if(/chantier|terrain|projet/.test(t))return 'prj';if(/architect|plan|bim|étude|etude/.test(t))return 'arc';if(/métr|metr|devis|structure|béton|beton/.test(t))return 'ing';
 if(/financ|paie|compta|caisse|factur/.test(t))return 'fin';if(/stock|achat|fournis/.test(t))return 'ach';if(/rapport|registre|sauvegarde/.test(t))return 'rap';
 if(/client|licence|crm/.test(t))return 'crm';if(/logo|param|réglage|reglage|admin|sync/.test(t))return 'set';if(/appren|forma|certif|cours|présen|presen|éval|eval/.test(t))return 'for';return 'ent'}
/* Éléments du menu d'origine encore visibles (droits par fonction respectés) */
function items(){var out=[],seen={};
 Array.prototype.forEach.call(d.querySelectorAll('#app .tabs button'),function(b){
  var oc=b.getAttribute('onclick')||'';if(/focusExbGlobalSearch/.test(oc))return;
  var m=oc.match(/show\('([A-Za-z0-9_]+)'\)/),key=m?m[1]:(b.id||oc.slice(0,40));
  if(key==='dashboard'||key==='notifications'||seen[key])return;
  var grp=b.closest('.exb-nav-group');
  if(b.hidden||w.getComputedStyle(b).display==='none'||(grp&&w.getComputedStyle(grp).display==='none'))return;
  var tx=(b.textContent||'').replace(/\s+/g,' ').trim(),mm=tx.match(/^([^\sA-Za-z0-9À-ÿ]+)\s+(.+)$/u);
  seen[key]=1;out.push({key:key,btn:b,ic:mm?mm[1]:'▫️',label:mm?mm[2]:tx,cat:MAP[key]||b.getAttribute('data-exb-cat')||guess(tx),d:DESC[key]||b.getAttribute('data-exb-desc')||''})});
 return out}
function catOf(x){if(MAP[x])return MAP[x];var it=items().filter(function(i){return i.key===x})[0];return it?it.cat:null}
var hubFlag=false,orig=null,curCat='home',hist=[],hi=-1,navBusy=false,rescued=[],lastKey='dashboard';
/* V99za : définie ici (et non dans install) — openCat() l'appelle depuis la navigation : « hideRescued is not defined » à l'ouverture d'un menu */
function hideRescued(){rescued.forEach(function(id){var e=$(id);if(e&&id!==lastKey)e.style.display='none'})}

/* ---------- Styles ---------- */
var CSS='\
#app{display:grid;grid-template-columns:248px minmax(0,1fr);padding-bottom:38px;background:#f3f6fc}\
#app>*{grid-column:2;min-width:0}#app>header{grid-column:1/-1}#app>.wrap.no-print{display:none!important}\
#exbNavBar{display:none!important}\
#app>header{position:sticky;top:0;z-index:60;background:#0f2e66;gap:14px;padding:8px 16px;box-shadow:0 2px 10px #0f2e6633}\
#app>header .brand{display:flex;align-items:center;gap:10px;flex:none}#app>header .brand b{font-size:17px;letter-spacing:.4px}#app>header .brand small{opacity:.8}\
#app>header .logout{display:none}\
#app>header .exb-pro-search{position:relative;top:auto;background:transparent;padding:0;flex:1;max-width:640px;margin:0 auto 0 14px;z-index:5}\
#app>header .exb-pro-search input{border-radius:9px;padding:11px 14px;background:#fff;color:#12254a}\
#app>header .exb-pro-search button{background:#ffffff22;color:#fff;border:0;border-radius:9px;padding:10px 12px}\
#app>header .exb-search-results{left:0;right:0;top:48px}\
#xbTop{display:flex;align-items:center;gap:10px;flex:none}\
.xb{position:relative;background:transparent;border:0;color:#fff;font-size:20px;cursor:pointer;padding:6px 8px;border-radius:9px}.xb:hover{background:#ffffff1f}\
.xb i{position:absolute;top:0;right:0;background:#e5352f;color:#fff;border-radius:9px;font:700 10px/16px Arial;min-width:16px;text-align:center;padding:0 3px;font-style:normal}.xb i:empty{display:none}\
.xprof{position:relative;border-left:1px solid #ffffff44;padding-left:12px}\
#xbProf{display:flex;align-items:center;gap:9px;background:transparent;border:0;color:#fff;cursor:pointer;text-align:left;padding:2px 4px;border-radius:10px}#xbProf:hover{background:#ffffff1f}\
.xav{width:42px;height:42px;border-radius:50%;object-fit:cover;background:#c49a38;color:#fff;display:grid;place-items:center;font:700 18px Arial;border:2px solid #ffffff88;flex:none}\
.xpn b{display:block;font-size:13px}.xpn small{font-size:12px;opacity:.85}\
.xmenu{display:none;position:absolute;right:0;top:56px;background:#fff;color:#12254a;border-radius:12px;box-shadow:0 14px 36px #0003;min-width:220px;padding:6px;z-index:80}.xmenu.on{display:block}\
.xmenu button{display:block;width:100%;text-align:left;background:none;border:0;padding:11px 12px;border-radius:8px;font:600 14px Arial;color:#12254a;cursor:pointer}.xmenu button:hover{background:#e8f0fe}\
#exbSide{grid-column:1;grid-row:2/span 500;align-self:start;position:sticky;top:60px;height:calc(100vh - 98px);overflow:auto;background:#fff;border-right:1px solid #e3e9f4;padding:12px;display:flex;flex-direction:column}\
#exbSide .xs{display:flex;align-items:center;gap:12px;width:100%;border:0;background:none;color:#12254a;padding:12px;border-radius:10px;font:600 14px Arial;text-align:left;cursor:pointer;margin-bottom:3px}\
#exbSide .xs span.ic{width:24px;text-align:center;font-size:18px}#exbSide .xs span.ch{margin-left:auto;color:#8b98b3}\
#exbSide .xs:hover{background:#f1f5fc}#exbSide .xs.on{background:#e3edfd;color:#1f6feb}\
.xpar{display:flex;gap:4px;margin:2px 4px 8px;padding:3px;background:#eef2fa;border-radius:10px}.xpar button{flex:1;border:0;background:transparent;color:#12254a;font:700 12px Arial;padding:7px 4px;border-radius:8px;cursor:pointer}.xpar button.on{background:#12254a;color:#fff}.xsf{margin-top:auto;padding:12px 6px 4px;border-top:1px solid #e3e9f4;font-size:12px;color:#6b7a99}.xsf b{display:block;color:#12254a}\
#exbBurger{display:none;background:transparent;border:0;color:#fff;font-size:24px;cursor:pointer}\
#exbCrumb{display:none;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 15px 0;color:#6b7a99;font-size:13px;max-width:1500px;margin:0 auto;width:100%}\
#exbCrumb button{background:#e3edfd;color:#1f6feb;border:0;border-radius:8px;padding:7px 12px;font-weight:700;cursor:pointer}\
.xh{max-width:1500px;margin:0 auto;padding:15px;width:100%;color:#12254a}\
.xh-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px}.xh-head h1{margin:2px 0;font-size:28px;color:#12254a}.xh-head p{margin:0;color:#6b7a99}.xh-crumb{color:#6b7a99;font-size:13px}\
.xh-date{background:#fff;border:1px solid #e3e9f4;border-radius:10px;padding:10px 14px;font-weight:600;white-space:nowrap}\
.xh-hero{position:relative;display:flex;border-radius:16px;overflow:hidden;background:#0f2e66;color:#fff;min-height:170px;margin-bottom:14px;box-shadow:0 8px 24px #0f2e6626}\
.xh-hl{position:relative;z-index:2;padding:24px 26px;flex:1;background:linear-gradient(90deg,#0f2e66d9 0%,#0f2e66a6 38%,#0f2e6600 72%)}\
.xh-hl small{font-size:15px}.xh-hl h2{margin:4px 0 8px;font-size:28px;color:#fff;border:0;padding:0}.xh-hl p{margin:0 0 14px;font-size:14px;max-width:400px;opacity:.92}\
.xh-btn{background:#1f6feb;color:#fff;border:0;border-radius:9px;padding:11px 18px;font:700 14px Arial;cursor:pointer}.xh-btn:hover{background:#3a82f2}\
.xh-img{position:absolute;inset:0;width:100%;background-size:cover;background-position:center}\
.xh-tag{position:absolute;right:24px;bottom:18px;z-index:3;max-width:220px;font-weight:700;font-size:15px;text-shadow:0 2px 10px #000a}\
.xh-cam{position:absolute;right:14px;top:12px;z-index:4;background:#0f2e66bb;color:#fff;border:1px solid #ffffff55;border-radius:9px;padding:7px 11px;font:600 12px Arial;cursor:pointer}\
.xh-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:14px}\
.xh-card,.xh-k{background:#fff;border:1px solid #e3e9f4;border-radius:14px;padding:16px;box-shadow:0 2px 10px #12254a0d}\
.xh-k{display:flex;gap:14px;align-items:center;cursor:pointer}.xh-k:hover,.xh-qa .q:hover{border-color:#1f6feb}\
.xh-bx{width:52px;height:52px;border-radius:14px;display:grid;place-items:center;font-size:24px;color:#fff;flex:none}\
.xh-k small{color:#6b7a99;display:flex;justify-content:space-between;gap:8px}.xh-k small a{color:#1f6feb;font-size:11px}.xh-k b{display:block;font-size:30px;line-height:1.1}.xh-k em{font-style:normal;font-size:12px;color:#6b7a99}\
.xh-cols{display:grid;grid-template-columns:1.6fr 1fr;gap:12px;margin-bottom:14px}\
.xh-card h3{margin:0 0 12px;font-size:16px;display:flex;justify-content:space-between;color:#12254a}.xh-card h3 a{font:12px Arial;color:#1f6feb;cursor:pointer}\
.xh-chart{display:flex;gap:14px;flex-wrap:wrap;align-items:center}.xh-chart svg{flex:1;min-width:240px}\
.xh-lg{width:170px;background:#f3f6fc;border-radius:10px;padding:10px}.xh-lg div{display:flex;align-items:center;gap:8px;padding:5px 0;font-size:13px}.xh-lg i{width:9px;height:9px;border-radius:50%}.xh-lg b{margin-left:auto}\
.xh-act{display:flex;gap:10px;align-items:center;padding:9px 0;border-bottom:1px solid #eef1f6}.xh-act:last-child{border:0}.xh-act .ci{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;flex:none;background:#dbeafe}.xh-act small{color:#6b7a99;display:block}.xh-act time{margin-left:auto;color:#6b7a99;font-size:12px;white-space:nowrap}\
.xh-qa{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}.xh-qa .q{border:1px solid #e3e9f4;border-radius:12px;padding:12px;cursor:pointer;display:flex;gap:10px;align-items:center;background:#fff}.xh-qa .q small{display:block;color:#6b7a99;font-size:11px}\
.xh-empty{color:#6b7a99;font-size:13px;padding:8px 0}\
#exbHub{max-width:1500px;margin:0 auto;padding:15px;width:100%;color:#12254a}#exbHub h1{margin:2px 0 4px;font-size:28px}\
.xg{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px;margin-top:14px}\
.xg .c{background:#fff;border:1px solid #e3e9f4;border-radius:14px;padding:16px;display:flex;gap:12px;align-items:center;cursor:pointer;text-align:left;font:inherit;color:#12254a;box-shadow:0 2px 10px #12254a0d}\
.xg .c:hover{border-color:#1f6feb;transform:translateY(-1px)}.xg .c i{font-style:normal;font-size:26px}.xg .c b{display:block;font-size:15px}.xg .c small{color:#6b7a99}\
#exbStatus{position:fixed;left:0;right:0;bottom:0;z-index:40;background:#fff;border-top:1px solid #e3e9f4;padding:7px 16px;font-size:12px;color:#6b7a99;display:flex;gap:16px;flex-wrap:wrap;align-items:center}#exbStatus b{color:#0f2e66}.xok{color:#16a34a;font-weight:700}.xko{color:#e5352f;font-weight:700}\
.xm{position:fixed;inset:0;background:#0008;z-index:200;display:grid;place-items:center;padding:14px}.xm-b{background:#fff;color:#12254a;border-radius:16px;max-width:520px;width:100%;max-height:88vh;overflow:auto;padding:16px}.xm-h{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.xm-x{border:0;background:#eef1f6;border-radius:8px;padding:6px 10px;cursor:pointer}\
.xm-g{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.xm-g button{border:2px solid #e3e9f4;border-radius:10px;padding:0;overflow:hidden;cursor:pointer;background:#fff;height:90px}.xm-g button.on{border-color:#1f6feb}.xm-g img{width:100%;height:100%;object-fit:cover;display:block}\
.xm-r{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.xm-r button{border:0;border-radius:9px;padding:10px 14px;font-weight:700;cursor:pointer;background:#e3edfd;color:#1f6feb}\
@media(max-width:900px){#app{display:block}#exbBurger{display:block}\
 #app>header .brand small,.xpn,#xbHelp,.xh-date{display:none}#app>header{gap:8px;padding:8px 10px}#app>header .exb-pro-search{margin-left:0}#app>header .exb-pro-search button{display:none}\
 .xprof{border:0;padding:0}\
 #exbSide{position:fixed;left:0;top:0;bottom:0;height:auto;width:280px;z-index:150;transform:translateX(-105%);transition:transform .2s;box-shadow:0 0 30px #0006;padding-top:64px}#exbSide.on{transform:none}\
 .xh-cols{grid-template-columns:1fr}.xh-hl{background:linear-gradient(180deg,#0f2e66d9,#0f2e6699 70%,#0f2e6633)}.xh-tag{position:relative;right:auto;bottom:auto;margin:0 26px 18px;max-width:none}.xh-hero{flex-direction:column;min-height:260px}.xh-cam{top:auto;bottom:12px;right:12px}\
 #exbStatus .xs2{display:none}}\
@media print{#exbSide,#exbStatus,#exbCrumb,#exbHome,#exbHub,#exbBurger,#xbTop{display:none!important}#app{display:block;padding:0}#app>header{display:none}}';
var ICO={l:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
 r:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>'};
var CSS2=[
/* le conteneur de contenu occupait seulement la largeur de son contenu (marge auto) : les modules s empilaient en colonne étroite */
'#app>.wrap{width:100%;justify-self:stretch}#exbModBar{min-width:0}',
'#xbNav{display:flex;gap:6px;flex:none;align-items:center}',
'.xnb{width:36px;height:36px;border-radius:10px;border:1px solid #ffffff33;background:#ffffff14;color:#fff;cursor:pointer;display:grid;place-items:center;padding:0;transition:background .15s,opacity .15s,transform .1s}',
'.xnb:hover:not(:disabled){background:#ffffff2e}.xnb:active:not(:disabled){transform:scale(.94)}.xnb:disabled{opacity:.35;cursor:default}',
'.xnb:focus-visible,.xb:focus-visible,#xbProf:focus-visible{outline:2px solid #8fb8ff;outline-offset:2px}',
'#xbTheme{display:grid;place-items:center;width:38px;height:38px;padding:0}#xbTheme svg{display:block}',
/* barre horizontale des modules */
'#exbModBar{display:none;position:relative;max-width:1500px;margin:0 auto;padding:10px 15px 0;width:100%}',
'#exbModBar .mb-in{position:relative;display:flex;flex-direction:row;gap:8px;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x proximity;padding:4px 2px 10px;scrollbar-width:thin;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain}',
'#exbModBar .mb{flex:none;display:flex;align-items:center;gap:8px;padding:9px 15px;border-radius:999px;border:1px solid #e3e9f4;background:#fff;color:#12254a;font:600 13px Arial,sans-serif;cursor:pointer;white-space:nowrap;scroll-snap-align:start;transition:background .15s,border-color .15s,color .15s,box-shadow .15s}',
'#exbModBar .mb:hover{border-color:#1f6feb;color:#1f6feb}#exbModBar .mb i{font-style:normal;font-size:16px;line-height:1}',
'#exbModBar .mb.on{background:#1f6feb;border-color:#1f6feb;color:#fff;box-shadow:0 4px 12px #1f6feb44}',
'#exbModBar .mb:focus-visible{outline:2px solid #1f6feb;outline-offset:2px}',
'#exbModBar .mb-ar{display:none;position:absolute;top:10px;z-index:3;width:34px;height:38px;border:1px solid #e3e9f4;background:#fff;color:#12254a;border-radius:10px;cursor:pointer;font:700 20px/1 Arial;place-items:center;box-shadow:0 2px 10px #12254a22;padding:0}',
'#exbModBar.ov .mb-in{padding-left:42px;padding-right:42px;scroll-padding:0 42px}#exbModBar .mb-ar.l{left:15px}#exbModBar .mb-ar.r{right:15px}#exbModBar.ov .mb-ar{display:grid}#exbModBar .mb-ar:hover{border-color:#1f6feb;color:#1f6feb}',
/* modules côte à côte (page d une catégorie) */
'.xg{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));grid-auto-flow:row}',
'.xg .c{flex-direction:row;min-height:78px;transition:border-color .15s,transform .15s,box-shadow .15s}.xg .c:hover{box-shadow:0 8px 20px #12254a1a}',
'.xg .c:focus-visible{outline:2px solid #1f6feb;outline-offset:2px}.xg .c>div{min-width:0}.xg .c small{display:block;line-height:1.3}',
'@media(max-width:600px){.xg{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.xg .c{flex-direction:column;align-items:flex-start;text-align:left;gap:8px;padding:14px 12px}.xg .c i{font-size:28px}.xg .c b{font-size:14px}',
' #exbModBar{padding:8px 10px 0}#xbNav{gap:4px}.xnb{width:32px;height:32px}#xbTheme{width:34px;height:34px}#app>header .brand b{display:none}}',
'@media(max-width:900px){#exbModBar .mb-ar{display:none!important}}',
'@media print{#exbModBar,#xbNav,#xbTheme{display:none!important}}'
].join('');
function injectCss(){if($('exbShellCss'))return;var s=d.createElement('style');s.id='exbShellCss';s.textContent=CSS+CSS2;d.head.appendChild(s)}

/* ---------- Profil administrateur (photo modifiable) ---------- */
function prof(){try{return JSON.parse(sget('exb_admin_profile','{}'))||{}}catch(e){return {}}}
function saveProf(p){if(!sset('exb_admin_profile',JSON.stringify(p)))alert('Impossible d’enregistrer la photo : l’espace de stockage de ce navigateur est plein.')}
function roleLabel(){return g(function(){return w.EXBDB.info().label},'')}
function renderProfile(){var p=prof(),nm=p.name||'Admin',av=$('xbAv'),n=$('xbName'),r=$('xbRole');if(!av)return;
 av.outerHTML=p.photo?'<img id="xbAv" class="xav" alt="" src="'+p.photo+'">':'<span id="xbAv" class="xav">'+esc(nm.charAt(0).toUpperCase())+'</span>';
 n.textContent=nm;r.textContent=p.role||roleLabel()||'Administrateur'}
function readImg(file,max,square,done){var fr=new FileReader();fr.onload=function(){var im=new Image();im.onload=function(){
  var sw=im.width,sh=im.height,sx=0,sy=0,tw,th;
  if(square){var m=Math.min(sw,sh);sx=(sw-m)/2;sy=(sh-m)/2;sw=sh=m;tw=th=max}else{var k=Math.min(1,max/sw);tw=Math.round(sw*k);th=Math.round(sh*k)}
  var c=d.createElement('canvas');c.width=tw;c.height=th;c.getContext('2d').drawImage(im,sx,sy,sw,sh,0,0,tw,th);done(c.toDataURL('image/jpeg',square?.88:.8))};
  im.onerror=function(){alert('Ce fichier n’est pas une image lisible.')};im.src=fr.result};fr.readAsDataURL(file)}
function pickFile(cb){var i=d.createElement('input');i.type='file';i.accept='image/*';i.onchange=function(){if(i.files&&i.files[0])cb(i.files[0])};i.click()}
function profMenu(){var m=$('xbMenu');if(m)m.classList.toggle('on')}
function changePhoto(){profMenu();pickFile(function(f){readImg(f,192,true,function(u){var p=prof();p.photo=u;saveProf(p);renderProfile()})})}
function removePhoto(){profMenu();var p=prof();delete p.photo;saveProf(p);renderProfile()}
function editName(){profMenu();var p=prof(),n=w.prompt('Nom affiché :',p.name||'Admin');if(n===null)return;var r=w.prompt('Fonction affichée :',p.role||roleLabel()||'Administrateur');if(r===null)return;
 p.name=n.trim().slice(0,40)||'Admin';p.role=r.trim().slice(0,40);saveProf(p);renderProfile()}
function doLogout(){profMenu();if(typeof w.logout==='function')w.logout()}

/* ---------- Fenêtres ---------- */
function modal(title,html){closeModal();var m=d.createElement('div');m.className='xm';m.id='xbModal';
 m.innerHTML='<div class="xm-b"><div class="xm-h"><b>'+title+'</b><button class="xm-x" onclick="EXB_SHELL.closeModal()">✕</button></div>'+html+'</div>';
 m.addEventListener('click',function(e){if(e.target===m)closeModal()});d.body.appendChild(m)}
function closeModal(){var m=$('xbModal');if(m)m.remove()}
function help(){modal('Aide rapide','<ul style="line-height:1.7;padding-left:18px;margin:0"><li><b>Menu de gauche</b> : cliquez sur une catégorie pour voir uniquement ce qui la concerne.</li><li><b>Recherche</b> : participant, certificat, reçu, projet, devis, document…</li><li><b>Votre photo</b> : cliquez sur votre nom en haut à droite pour la changer.</li><li><b>Bannière de l’accueil</b> : bouton « 📷 Changer la photo » sur la bannière.</li><li>Photos et nom sont enregistrés sur cet appareil.</li></ul>')}

/* ---------- Bannière ---------- */
function bannerSrc(){var v=sget('exb_home_banner','v:0');if(v.indexOf('data:')===0)return v;var n=parseInt(v.slice(2),10);return BAN[n>=0&&n<BAN.length?n:0]}
function setBanner(v){if(!sset('exb_home_banner',v)){alert('Impossible d’enregistrer cette photo : espace de stockage plein.');return}paintHero();closeModal()}
function bannerPicker(){var cur=sget('exb_home_banner','v:0');
 modal('Photo de la bannière','<div class="xm-g">'+BAN.map(function(s,i){return '<button class="'+(cur==='v:'+i?'on':'')+'" onclick="EXB_SHELL.setBanner(\'v:'+i+'\')"><img alt="" src="'+s+'"></button>'}).join('')+'</div><div class="xm-r"><button onclick="EXB_SHELL.importBanner()">📷 Importer ma photo</button><button onclick="EXB_SHELL.setBanner(\'v:0\')">↺ Photo par défaut</button></div><p style="font-size:12px;color:#6b7a99">Photos issues du site vitrine. Votre photo importée reste sur cet appareil.</p>')}
function importBanner(){pickFile(function(f){readImg(f,1400,false,function(u){setBanner(u)})})}
function paintHero(){var i=$('xhImg');if(i)i.style.backgroundImage='url("'+bannerSrc()+'")'}

/* ---------- Accueil ---------- */
function P(){return g(function(){return exbProjects},[])}
function Cl(){return g(function(){return exbClients},[])}
function Pa(){return g(function(){return participants},[])}
function ym(){return new Date().toISOString().slice(0,7)}
function dateOf(o){return String(o&&(o.created_at||o.start||o.date||o.createdAt)||'')}
function delta(list){var any=list.some(function(o){return dateOf(o)});if(!any)return '';var n=list.filter(function(o){return dateOf(o).slice(0,7)===ym()}).length;return n?'↗ +'+n+' ce mois':'Aucun ce mois'}
function stg(p){var s=String(p.status||'').toLowerCase();return /annul/.test(s)?'x':/termin|clôtur|cloture/.test(s)?'t':/cours/.test(s)?'c':'a'}
function renderHome(){var h=$('exbHome');if(!h)return;
 var brand=g(function(){return $('brandNameHeader').textContent.trim()},'Excellencia Building');$('xhBrand').textContent=brand;
 var dt=new Date().toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});$('xhDate').textContent='📅 '+dt.charAt(0).toUpperCase()+dt.slice(1);
 var prj=P(),cl=Cl(),pa=Pa(),unp=parseInt(g(function(){return $('dashUnpaid').textContent},'0'),10)||0,run=prj.filter(function(p){return stg(p)==='c'}).length;
 var pc=parcours(),fo=g(function(){return formations},[]),ce=g(function(){return certs},[]),fin=prj.filter(function(p){return stg(p)==='t'}).length;
 var K=pc==='btp'?[['Projets en cours',run,delta(prj),'#1f6feb','📁','projets'],['Projets terminés',fin,'Livrés','#16a34a','✅','projets'],['Clients',cl.length,delta(cl),'#7c3aed','👥','clients'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','finances']]
 :pc==='for'?[['Apprenants',pa.length,delta(pa),'#7c3aed','🎓','participants'],['Formations',fo.length,'Catalogue','#1f6feb','📚','formations'],['Certificats',ce.length,delta(ce),'#16a34a','📜','certs'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','receipts']]
 :[['Projets en cours',run,delta(prj),'#1f6feb','📁','projets'],['Clients',cl.length,delta(cl),'#16a34a','👥','clients'],['Apprenants',pa.length,delta(pa),'#7c3aed','🎓','participants'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','receipts']];
 $('xhK').innerHTML=K.map(function(k){return '<div class="xh-k" onclick="show(\''+k[5]+'\')"><div class="xh-bx" style="background:'+k[3]+'">'+k[4]+'</div><div style="flex:1"><small>'+k[0]+'<a>Voir tout →</a></small><b>'+(k[1]<10&&k[1]>0?'0'+k[1]:k[1])+'</b><em>'+esc(k[2])+'</em></div></div>'}).join('');
 /* graphique : cumul des projets créés depuis janvier */
 var forMode=parcours()==='for';if(forMode)prj=pa;
 var yr=String(new Date().getFullYear()),mo=['Jan','Fév','Mar','Avr','Mai','Juin','Juil','Août','Sep','Oct','Nov','Déc'],cm=new Date().getMonth(),dated=prj.filter(function(p){return dateOf(p).slice(0,4)===yr}),
  cnt={c:0,t:0,a:0,x:0};prj.forEach(function(p){cnt[stg(p)]++});
 var leg='<div class="xh-lg"><div><i style="background:#1f6feb"></i>En cours<b>'+cnt.c+'</b></div><div><i style="background:#16a34a"></i>Terminés<b>'+cnt.t+'</b></div><div><i style="background:#f59e0b"></i>En attente<b>'+cnt.a+'</b></div><div><i style="background:#e5352f"></i>Annulés<b>'+cnt.x+'</b></div></div>',svg='';
 if(forMode)leg='<div class="xh-lg"><div><i style="background:#7c3aed"></i>Apprenants inscrits<b>'+pa.length+'</b></div></div>';
 if(dated.length){var pts=[],mx=1,i;for(i=0;i<=cm;i++){var n=dated.filter(function(p){return parseInt(dateOf(p).slice(5,7),10)-1<=i}).length;pts.push(n);if(n>mx)mx=n}
  var st=cm?540/cm:0,XY=pts.map(function(v,i){return [30+i*st,130-v/mx*110]}),L=XY.map(function(a){return a.join(',')}).join(' ');
  svg='<svg viewBox="0 0 600 160"><polygon points="30,130 '+L+' '+XY[XY.length-1][0]+',130" fill="#1f6feb22"/><polyline points="'+L+'" fill="none" stroke="#1f6feb" stroke-width="2"/>'+XY.map(function(a,i){return '<circle cx="'+a[0]+'" cy="'+a[1]+'" r="3.5" fill="#fff" stroke="#1f6feb" stroke-width="2"/><text x="'+a[0]+'" y="150" font-size="11" text-anchor="middle" fill="#6b7a99">'+mo[i]+'</text>'}).join('')+'</svg>'}
 else svg='<div class="xh-empty" style="flex:1">'+(prj.length?'Les dates de création ne sont pas renseignées : la courbe apparaîtra pour les prochains enregistrements.':(forMode?'Aucun apprenant enregistré pour le moment.':'Aucun projet enregistré pour le moment.'))+'</div>';
 $('xhChart').innerHTML='<div class="xh-chart">'+svg+leg+'</div>';
 var al=g(function(){return auditLog},[]).slice(0,5);
 $('xhAct').innerHTML=al.length?al.map(function(a){var t=new Date(a.at),hh=isNaN(t)?'':t.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});return '<div class="xh-act"><div class="ci">'+(/factur|re[cç]u|paiement/i.test(a.action)?'📄':/projet|chantier/i.test(a.action)?'👷':/certif|particip|inscri/i.test(a.action)?'🎓':'🕒')+'</div><div><b>'+esc(a.action)+'</b><small>'+esc(String(a.details||'').slice(0,70))+'</small></div><time>'+hh+'</time></div>'}).join(''):'<div class="xh-empty">Aucune opération enregistrée.</div>';
 var vis={};items().forEach(function(i){vis[i.key]=i});
 var Q=[['bureauEtudes','📐','Bureau d’études','Plans, BIM, CDE'],['metreDevis','🧮','Métré & devis','Études, estimation, chiffrage'],['projets','🏗️','Projets & chantiers','Avancement, suivi, équipes'],['certs','🎓','Apprenants & certificats','Formations, évaluations, diplômes'],['finances','💰','Finance & paiements','Encaissements, moyens de paiement'],['clients','👥','Clients & CRM','Fiches et licences']].filter(function(q){return vis[q[0]]&&!(parcours()==='btp'&&q[0]==='certs')&&!(parcours()==='for'&&['bureauEtudes','metreDevis','projets'].indexOf(q[0])>=0)});
 $('xhQA').innerHTML=Q.map(function(q){return '<div class="q" onclick="show(\''+q[0]+'\')"><span style="font-size:22px">'+q[1]+'</span><div><b>'+q[2]+'</b><small>'+q[3]+'</small></div></div>'}).join('')||'<div class="xh-empty">Aucun raccourci disponible pour votre profil.</div>';
 applyParcours();paintHero();updateBadge()}


/* V99zt : focalisation produit — l'accueil, la bannière et la recherche suivent le parcours choisi (Construction / Formation). */
var TXT={
 btp:{sub:'Vue d’ensemble de vos chantiers, études et finances',lead:'Pilotez vos projets de construction, d’architecture et d’ingénierie : devis, chantiers, plans et suivi financier.',go:'Voir mes projets →',goKey:'projets',tag:'Construire aujourd’hui le monde de demain.',chart:'📊 Évolution des projets',ph:'Rechercher projet, client, devis, plan, document ou référence…',hdr:'Construction · Architecture · Ingénierie'},
 for:{sub:'Vue d’ensemble de votre centre de formation',lead:'Gérez vos apprenants, formations, évaluations et certificats, du dossier d’inscription jusqu’au diplôme.',go:'Voir les apprenants →',goKey:'participants',tag:'Former aujourd’hui les bâtisseurs de demain.',chart:'📊 Évolution des inscriptions',ph:'Rechercher participant, certificat, reçu, paiement, formation ou référence…',hdr:'Centre de formation'},
 all:{sub:'Vue d’ensemble de votre activité',lead:'Votre solution complète pour la gestion de vos projets de construction, d’architecture et d’ingénierie.',go:'Voir mes projets →',goKey:'projets',tag:'Plus qu’un logiciel, une vision pour bâtir l’avenir.',chart:'📊 Évolution des projets',ph:'Rechercher participant, certificat, reçu, paiement, formation, projet, devis, document ou référence…',hdr:''}};
function applyParcours(){var pc=parcours(),t=TXT[pc]||TXT.all;
 function set(id,v){var e=$(id);if(e)e.textContent=v}
 set('xhSub',t.sub);set('xhLead',t.lead);set('xhGo',t.go);set('xhTag',t.tag);set('xhChartT',t.chart);
 var gb=$('xhGo');if(gb)gb.setAttribute('onclick',"show('"+t.goKey+"')");
 var si=$('exbGlobalSearch');if(si)si.placeholder=t.ph;
 var hb=$('brandSubHeader');if(hb){if(!hb.getAttribute('data-orig'))hb.setAttribute('data-orig',hb.textContent);if(t.hdr)hb.textContent=t.hdr;else hb.textContent=hb.getAttribute('data-orig')}
 /* choix du parcours au premier lancement : bandeau non bloquant, une seule fois */
 var pk=$('xhPick');if(pk){var asked=g(function(){return localStorage.getItem('exb_parcours_ask')},null)||roleParcours();
  pk.innerHTML=asked?'':'<div class="xh-card" style="margin:0 0 14px;border-left:4px solid #1f6feb"><h3>🧭 Que souhaitez-vous utiliser ?</h3><p style="margin:0 0 10px;color:#6b7a99;font-size:13px">Choisissez votre parcours : le menu et l’accueil n’afficheront que ce qui vous concerne. Vous pourrez changer à tout moment en haut du menu.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="primary" onclick="EXB_SHELL.pickParcours(\'btp\')">🏗️ Construction / Architecture</button><button class="primary" onclick="EXB_SHELL.pickParcours(\'for\')">🎓 Formation</button><button class="muted" onclick="EXB_SHELL.pickParcours(\'all\')">Tout afficher</button></div></div>'}}

/* V99zt : la recherche globale ne montre que les résultats du parcours (Formation : sans projets/devis ; Construction : sans apprenants/certificats/reçus/formations). */
var OUT={btp:['Participant','Certificat','Reçu','Formation'],for:['Projet','Devis']};
function filterSearch(){var box=$('exbGlobalResults');if(!box)return;var out=OUT[parcours()]||[];
 Array.prototype.forEach.call(box.querySelectorAll('.exb-search-item'),function(el){var t=el.querySelector('.exb-search-type');el.style.display=(t&&out.indexOf(t.textContent.trim())>=0)?'none':''})}
function watchSearch(){var box=$('exbGlobalResults');if(!box||box.__exbWatch)return;box.__exbWatch=true;try{new MutationObserver(filterSearch).observe(box,{childList:true})}catch(e){}}
function pickParcours(p){try{localStorage.setItem('exb_parcours_ask','1')}catch(e){}setParcours(p)}
/* ---------- Menu latéral, catégories, fil d'Ariane ---------- */
/* V99zg : deux parcours de menu (audit interne) — Construction / Architecture et Formation. « Tout » = comportement d'origine. */
var HIDE={btp:['for'],for:['arc','ing','prj','ach']};
/* V99zt : sans choix explicite, le parcours découle de la fonction de l'utilisateur (formateur → Formation ; conducteur, chef de projet, bureau d'études → Construction) */
function roleParcours(){var r=String(roleLabel()||'').toLowerCase();if(/formateur|apprenant/.test(r))return 'for';if(/conducteur|chef de projet|bureau d|ing[eé]nieur|architect/.test(r))return 'btp';return ''}
function parcours(){var p=g(function(){return localStorage.getItem('exb_parcours')},'');if(p==='btp'||p==='for'||p==='all')return p;return roleParcours()||'all'}
function setParcours(p){try{localStorage.setItem('exb_parcours',p)}catch(e){}if(HIDE[p]&&HIDE[p].indexOf(curCat)>=0)curCat='home';renderSide();try{renderHome()}catch(e){}}
function visCats(){var h=HIDE[parcours()]||[];return CATS.filter(function(c){return h.indexOf(c.k)<0})}
function renderSide(){var s=$('exbSide');if(!s)return;var pc=parcours();
 s.innerHTML='<div class="xpar">'+[['all','Tout'],['btp','🏗️ Construction'],['for','🎓 Formation']].map(function(x){return '<button class="'+(pc===x[0]?'on':'')+'" onclick="EXB_SHELL.setParcours(\''+x[0]+'\')">'+x[1]+'</button>'}).join('')+'</div>'+visCats().map(function(c){return '<button class="xs'+(c.k===curCat?' on':'')+'" onclick="EXB_SHELL.openCat(\''+c.k+'\')"><span class="ic">'+c.i+'</span>'+esc(c.t)+(c.k==='home'?'':'<span class="ch">›</span>')+'</button>'}).join('')+
  '<div class="xsf"><b>'+esc(g(function(){return $('brandNameHeader').textContent.trim()},'Excellencia Building'))+'</b>'+esc(g(function(){var I=EXBId.get();return I.name.toLowerCase()==='excellencia building'?'Construire aujourd’hui — le monde de demain':I.tagline},''))+'</div>'}
function setActive(k){curCat=k;renderSide()}
function closeDrawer(){var s=$('exbSide');if(s)s.classList.remove('on')}
/* ---------- Historique (Retour / Avant) ---------- */
function navBtns(){var b=$('xbBack'),f=$('xbFwd');if(b)b.disabled=hi<=0;if(f)f.disabled=hi>=hist.length-1}
function rec(st){if(navBusy)return;var c=hist[hi];if(c&&c.t===st.t&&c.v===st.v)return;
 hist=hist.slice(0,hi+1);hist.push(st);if(hist.length>60)hist.shift();hi=hist.length-1;navBtns()}
function restore(st){navBusy=true;try{if(st.t==='c')openCat(st.v);else if(st.t==='b')goKey(st.v);else w.show(st.v)}catch(e){}finally{navBusy=false}navBtns();try{w.scrollTo(0,0)}catch(e){}}
function back(){if(hi>0){hi--;restore(hist[hi])}}
function forward(){if(hi<hist.length-1){hi++;restore(hist[hi])}}
/* ---------- Barre horizontale des modules de la catégorie ---------- */
function barOverflow(){var mb=$('exbModBar');if(!mb)return;var i=mb.querySelector('.mb-in');mb.classList.toggle('ov',!!i&&i.scrollWidth>i.clientWidth+4)}
function renderModBar(k,x){var mb=$('exbModBar');if(!mb)return;
 var list=(!k||k==='home')?[]:items().filter(function(i){return i.cat===k});
 if(list.length<2||!x){mb.style.display='none';mb.innerHTML='';mb.classList.remove('ov');return}
 mb.innerHTML='<button class="mb-ar l" type="button" aria-label="Modules précédents" onclick="EXB_SHELL.scrollBar(-1)">‹</button><div class="mb-in" role="tablist" aria-label="Modules">'+
  list.map(function(i,n){var on=i.key===x;return '<button class="mb'+(on?' on':'')+'" type="button" role="tab" aria-selected="'+on+'" onclick="EXB_SHELL.go('+n+',\''+k+'\')"><i>'+esc(i.ic)+'</i>'+esc(i.label)+'</button>'}).join('')+
  '</div><button class="mb-ar r" type="button" aria-label="Modules suivants" onclick="EXB_SHELL.scrollBar(1)">›</button>';
 mb.style.display='block';
 var inn=mb.querySelector('.mb-in'),on=mb.querySelector('.mb.on');
 if(inn&&on)inn.scrollLeft=Math.max(0,on.offsetLeft-(inn.clientWidth-on.offsetWidth)/2);
 barOverflow()}
function scrollBar(dir){var i=d.querySelector('#exbModBar .mb-in');if(i)i.scrollBy({left:dir*Math.max(180,i.clientWidth*.6),behavior:'smooth'})}
function openCat(k){closeDrawer();if(k==='home'){w.show('dashboard');return}
 var c=cat(k),list=items().filter(function(i){return i.cat===k}),hub=$('exbHub');if(!hub||!orig)return;
 hub.innerHTML='<div class="xh-crumb">Accueil › '+esc(c.t)+'</div><h1>'+c.i+' '+esc(c.t)+'</h1><p style="margin:0;color:#6b7a99">'+esc(c.d||'')+'</p><div class="xg">'+
  (list.length?list.map(function(i,n){return '<button class="c" onclick="EXB_SHELL.go('+n+',\''+k+'\')"><i>'+esc(i.ic)+'</i><div><b>'+esc(i.label)+'</b><small>'+esc(i.d)+'</small></div></button>'}).join(''):'<div class="xh-empty">Rien à afficher ici pour votre profil.</div>')+'</div>';
 hubFlag=true;try{orig.call(w,'exbHub')}finally{hubFlag=false}
 Array.prototype.forEach.call(hub.parentNode.children,function(el){if(el.tagName==='SECTION'&&el!==hub)el.style.display='none'});
 var hm=$('exbHome');if(hm)hm.style.display='none';var cr=$('exbCrumb');if(cr)cr.style.display='none';
 hub.style.display='';lastKey='exbHub';hideRescued();renderModBar(null,null);setActive(k);rec({t:'c',v:k});w.scrollTo(0,0)}
function goItem(it,k){if(!it)return;
 var direct=!/show\('/.test(it.btn.getAttribute('onclick')||'');
 if(!direct){it.btn.click();return}
 /* module qui affiche sa page lui-même (V67–V72…) : on masque d'abord les autres pages, puis on le laisse s'afficher */
 hubFlag=true;try{orig('exbHub')}catch(e){}hubFlag=false;
 rescued.forEach(function(id){var e=$(id);if(e)e.style.display='none'});lastKey=it.key;
 it.btn.click();
 var hub=$('exbHub'),hm=$('exbHome');if(hub)hub.style.display='none';if(hm)hm.style.display='none';
 setActive(k||curCat);renderCrumb(it.key,k);renderModBar(k,it.key);closeDrawer();rec({t:'b',v:it.key});try{w.scrollTo(0,0)}catch(e){}}
function go(n,k){var list=items().filter(function(i){return i.cat===k});if(list[n])goItem(list[n],k)}
function goKey(key){var it=items().filter(function(i){return i.key===key})[0];if(it)goItem(it,it.cat)}
function renderCrumb(x,k){var cr=$('exbCrumb');if(!cr)return;
 if(x==='dashboard'||!k){cr.style.display='none';return}
 var c=cat(k),it=items().filter(function(i){return i.key===x})[0];
 cr.innerHTML='<button onclick="EXB_SHELL.openCat(\''+k+'\')">← '+esc(c.t)+'</button><span>Accueil › '+esc(c.t)+(it?' › '+esc(it.label):'')+'</span>';cr.style.display='flex'}
function after(x){if(hubFlag)return;var hub=$('exbHub');if(hub)hub.style.display='none';var hm=$('exbHome');
 if(x==='notifications'){sset('exb_notif_seen',String(Date.now()));updateBadge();setActive('home');var cr=$('exbCrumb');if(cr){cr.innerHTML='<button onclick="show(\'dashboard\')">← Accueil</button><span>Accueil › Notifications</span>';cr.style.display='flex'}if(hm)hm.style.display='none';renderModBar(null,null);return}
 if(hm)hm.style.display=x==='dashboard'?'':'none';if(x==='dashboard')renderHome();
 var k=x==='dashboard'?'home':catOf(x);setActive(k||curCat);renderCrumb(x,k==='home'?null:k);renderModBar(k==='home'?null:k,x);closeDrawer()}

/* ---------- Notifications, état du système ---------- */
function updateBadge(){var b=$('xbBadge');if(!b)return;var seen=parseInt(sget('exb_notif_seen','0'),10)||0,
 n=g(function(){return exbNotifications},[]).filter(function(x){var t=Date.parse(x&&(x.at||x.date||x.time||x.ts||x.created_at));return t&&t>seen}).length;b.textContent=n?(n>99?'99+':String(n)):''}
function lastBackup(){var v=sget('exb_last_backup','');if(!v)return 'jamais';var t=/^\d+$/.test(v)?new Date(+v):new Date(v);if(isNaN(t))return '—';
 var td=new Date(),hh=t.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});return t.toDateString()===td.toDateString()?'Aujourd’hui à '+hh:t.toLocaleDateString('fr-FR')+' à '+hh}
function renderStatus(){var s=$('exbStatus');if(!s)return;var on=w.navigator.onLine!==false;
 s.innerHTML='<span class="'+(on?'xok':'xko')+'">● '+(on?'Système opérationnel':'Hors connexion (données conservées sur cet appareil)')+'</span><span class="xs2">Dernière sauvegarde : '+esc(lastBackup())+'</span><span>Version : '+VERSION+'</span><span class="xs2" style="margin-left:auto"><b>Excellencia Building</b> – Ensemble vers l’excellence</span>'}

/* ---------- Installation ---------- */
function build(){var app=$('app'),hd=app&&app.querySelector(':scope > header'),dash=$('dashboard');if(!app||!hd||!dash||$('exbSide'))return false;
 injectCss();
 var burger=d.createElement('button');burger.id='exbBurger';burger.type='button';burger.setAttribute('aria-label','Menu');burger.textContent='☰';burger.onclick=function(){var s=$('exbSide');if(s)s.classList.toggle('on')};hd.insertBefore(burger,hd.firstChild);
 var sr=d.querySelector('.exb-pro-search');if(sr){hd.insertBefore(sr,hd.querySelector('.logout'));var inp=sr.querySelector('input');if(inp)inp.placeholder='Rechercher un participant, un projet, un document…'}
 var top=d.createElement('div');top.id='xbTop';
 top.innerHTML='<button class="xb" id="xbBell" type="button" aria-label="Notifications" onclick="show(\'notifications\')">🔔<i id="xbBadge"></i></button><button class="xb" id="xbHelp" type="button" aria-label="Aide" onclick="EXB_SHELL.help()">❓</button><button class="xb" id="xbTheme" type="button" aria-label="Changer de thème" title="Changer de thème" onclick="window.EXB_THEME&&EXB_THEME.toggle()"></button>'+
  '<div class="xprof"><button id="xbProf" type="button" onclick="EXB_SHELL.profMenu()"><span id="xbAv" class="xav"></span><span class="xpn"><b id="xbName"></b><small id="xbRole"></small></span><span>⌄</span></button>'+
  '<div class="xmenu" id="xbMenu"><button onclick="EXB_SHELL.changePhoto()">📷 Changer ma photo</button><button onclick="EXB_SHELL.removePhoto()">🗑️ Retirer ma photo</button><button onclick="EXB_SHELL.editName()">✏️ Modifier mon nom</button><button onclick="EXB_SHELL.logout()">🚪 Déconnexion</button></div></div>';
 hd.insertBefore(top,hd.querySelector('.logout'));
 var nav=d.createElement('div');nav.id='xbNav';nav.className='no-print';
 nav.innerHTML='<button class="xnb" id="xbBack" type="button" aria-label="Retour" title="Retour (Alt + ←)" disabled onclick="EXB_SHELL.back()">'+ICO.l+'</button><button class="xnb" id="xbFwd" type="button" aria-label="Avant" title="Avant (Alt + →)" disabled onclick="EXB_SHELL.forward()">'+ICO.r+'</button>';
 hd.insertBefore(nav,sr||top);
 var side=d.createElement('nav');side.id='exbSide';side.className='no-print';side.setAttribute('aria-label','Menu principal');hd.parentNode.insertBefore(side,hd.nextSibling);
 var wrap=dash.parentNode,cr=d.createElement('div');cr.id='exbCrumb';cr.className='no-print';wrap.insertBefore(cr,dash);
 var mbar=d.createElement('nav');mbar.id='exbModBar';mbar.className='no-print';mbar.setAttribute('aria-label','Modules de la catégorie');wrap.insertBefore(mbar,dash);
 var home=d.createElement('section');home.id='exbHome';home.className='xh no-print';home.style.display='none';
 home.innerHTML='<div class="xh-head"><div><div class="xh-crumb">Accueil</div><h1>Tableau de bord</h1><p id="xhSub">Vue d’ensemble de votre activité</p></div><div class="xh-date" id="xhDate"></div></div><div id="xhPick"></div>'+
  '<div class="xh-hero"><div class="xh-hl"><small>Bienvenue dans</small><img id="xhLogo" alt="" src="'+esc(g(function(){return w.exbLogoSrc?w.exbLogoSrc():'icon-192.png'},'icon-192.png'))+'" style="width:54px;height:54px;object-fit:contain;background:#fff;border-radius:12px;padding:4px;margin:6px 0"><h2 id="xhBrand">Excellencia Building</h2><p id="xhLead">Votre solution complète pour la gestion de vos projets de construction, d’architecture et d’ingénierie.</p><button class="xh-btn" id="xhGo" type="button" onclick="show(\'projets\')">Voir mes projets →</button></div><div class="xh-img" id="xhImg"></div><div class="xh-tag" id="xhTag">Plus qu’un logiciel, une vision pour bâtir l’avenir.</div><button class="xh-cam" type="button" onclick="EXB_SHELL.bannerPicker()">📷 Changer la photo</button></div>'+
  '<div class="xh-kpis" id="xhK"></div><div class="xh-cols"><div class="xh-card"><h3 id="xhChartT">📊 Évolution des projets</h3><div id="xhChart"></div></div><div class="xh-card"><h3>🕒 Activité récente <a onclick="show(\'notifications\')">Voir tout →</a></h3><div id="xhAct"></div></div></div>'+
  '<div class="xh-card"><h3>⚡ Accès rapide</h3><div class="xh-qa" id="xhQA"></div></div>';
 wrap.insertBefore(home,dash);
 var hub=d.createElement('section');hub.id='exbHub';hub.className='no-print';hub.style.display='none';wrap.insertBefore(hub,dash);
 var st=d.createElement('div');st.id='exbStatus';st.className='no-print';app.appendChild(st);
 d.addEventListener('click',function(e){var m=$('xbMenu');if(m&&m.classList.contains('on')&&!e.target.closest('.xprof'))m.classList.remove('on');var s=$('exbSide');if(s&&s.classList.contains('on')&&!e.target.closest('#exbSide,#exbBurger'))s.classList.remove('on')});
 w.addEventListener('online',renderStatus);w.addEventListener('offline',renderStatus);w.addEventListener('resize',barOverflow);
 d.addEventListener('keydown',function(e){if(!e.altKey||e.ctrlKey||e.metaKey||e.shiftKey)return;if(e.key==='ArrowLeft'){e.preventDefault();back()}else if(e.key==='ArrowRight'){e.preventDefault();forward()}});
 renderProfile();renderSide();renderStatus();updateBadge();if(w.EXB_THEME&&w.EXB_THEME.refresh)w.EXB_THEME.refresh();return true}
function install(){if(w.__exbShellV99r||typeof w.show!=='function')return;if(!build())return;w.__exbShellV99r=true;
 orig=w.show;w.show=function(x){var r=orig.apply(this,arguments);try{if(!hubFlag&&x){lastKey=String(x);hideRescued()}}catch(e){}try{after(x)}catch(e){}try{if(!hubFlag&&x)rec({t:'v',v:String(x)})}catch(e){}return r};
 rec({t:'v',v:'dashboard'});watchSearch();
 /* V99y : les modules V67–V72 (Projet 360°, Priorité 2 CDE/BIM/EVM, Intelligence BTP, Plans & Structure, Feuilles de plans, Plans/PDF) ajoutent leur page dans le premier .wrap,
    devenu le conteneur masqué des onglets : leurs pages restaient invisibles. On les replace dans la zone de contenu (sans modifier ces modules). */
 function rescue(){try{var dh=$('dashboard'),host=dh&&dh.parentNode,tb=d.querySelector('#app>.wrap.no-print');if(!host||!tb||tb===host)return;[].slice.call(tb.children).forEach(function(c){if(c.tagName==='SECTION'){host.appendChild(c);if(c.id&&rescued.indexOf(c.id)<0)rescued.push(c.id)}});hideRescued()}catch(e){}}
 rescue();try{var tw=d.querySelector('#app>.wrap.no-print');if(tw)new MutationObserver(rescue).observe(tw,{childList:true})}catch(e){}
 try{var mo=new MutationObserver(function(){clearTimeout(mo.t);mo.t=setTimeout(function(){renderSide()},300)});var tb=d.querySelector('#app .tabs');if(tb)mo.observe(tb,{attributes:true,subtree:true,childList:true,attributeFilter:['style','hidden','class']})}catch(e){}
 var dsh=$('dashboard');if(dsh&&dsh.style.display!=='none'){var hm=$('exbHome');if(hm)hm.style.display='';renderHome()}
 setInterval(function(){renderStatus();updateBadge()},60000)}
w.EXB_SHELL={filterSearch:filterSearch,roleParcours:roleParcours,pickParcours:pickParcours,applyParcours:applyParcours,setParcours:setParcours,parcours:parcours,install:install,openCat:openCat,go:go,goKey:goKey,back:back,forward:forward,scrollBar:scrollBar,help:help,profMenu:profMenu,changePhoto:changePhoto,removePhoto:removePhoto,editName:editName,logout:doLogout,bannerPicker:bannerPicker,updateBadge:updateBadge,setBanner:setBanner,importBanner:importBanner,closeModal:closeModal,version:VERSION};
function start(){setTimeout(install,350)}
if(d.readyState==='complete')start();else w.addEventListener('load',start)
})(window,document);
