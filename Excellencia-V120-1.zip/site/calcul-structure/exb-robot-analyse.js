/* V122 — Moteur d'analyse de structure « type Robot Structural Analysis » (fonctions pures, window.EXBR).
   Sans dépendance au DOM : utilisable dans le navigateur et sous Node.  Unités : m, kN, kPa, MPa (E en kN/m² = 1000·MPa),
   masses en tonnes (kN·s²/m), moments en kN.m, rotations en rad.

   Fonctionnalités reprises de Robot :
   1. Cas de charges et COMBINAISONS automatiques (EN 1990 : 6.10, 6.10a/b, ELS caractéristique / fréquente / quasi-permanente,
      accidentelle, sismique ; BAEL 91 : 1,35G + 1,5Q + 1,3·ψ0·Qi) avec familles de cas exclusifs (vent +X / −X).
   2. Analyse statique linéaire de portiques / poutres PLANS par éléments finis (Euler-Bernoulli, 3 ddl par nœud) : barres
      inclinées, articulations (relâchements), appuis rigides, ÉLASTIQUES (ressorts) et TASSEMENTS d'appui, charges nodales,
      réparties (trapèze, repère local/global, projetées), ponctuelles, température uniforme ; réactions, vérification de l'équilibre.
   3. Diagrammes N, V, M et déformée par barre, ENVELOPPES de toutes les combinaisons (valeurs extrêmes et combinaison dominante).
   4. Analyse MODALE (valeurs propres, condensation statique des ddl sans masse), masses modales effectives, spectre de calcul
      EN 1998-1 §3.2.2.5, combinaison SRSS / CQC, effort tranchant à la base, déplacements d'étage, contrôle des déplacements
      relatifs (dr·ν) et de la sensibilité au second ordre θ (EN 1998-1 §4.4.2.2).
   5. Constructeur de portique plan régulier (n étages × m travées) pour l'écran « Portique 2D ».

   Calcul d'aide à l'étude : à faire vérifier par un ingénieur.  Pas de non-linéarité géométrique (P-Δ) ni de plastification ;
   déformations par effort tranchant négligées (poutres élancées). */
(function (root) {
  "use strict";
  const GRAV = 9.81;

  /* ====================================================================== algèbre linéaire dense */
  /* Factorisation LU avec pivot partiel (copie de A) ; lève une erreur si la matrice est (quasi) singulière. */
  function luFactor(A) {
    const n = A.length, a = A.map(r => Float64Array.from(r)), piv = new Int32Array(n);
    let amax = 0;
    for (let i = 0; i < n; i++) amax = Math.max(amax, Math.abs(a[i][i]));
    const tol = Math.max(amax, 1) * 1e-13;
    for (let k = 0; k < n; k++) {
      let p = k, m = Math.abs(a[k][k]);
      for (let i = k + 1; i < n; i++) if (Math.abs(a[i][k]) > m) { m = Math.abs(a[i][k]); p = i; }
      if (m < tol) { const e = new Error("Structure instable (mécanisme) : vérifier les appuis et les articulations."); e.code = "MECANISME"; e.ddl = k; throw e; }
      piv[k] = p;
      if (p !== k) { const t = a[k]; a[k] = a[p]; a[p] = t; }
      const d = a[k][k];
      for (let i = k + 1; i < n; i++) {
        const f = a[i][k] / d;
        if (f === 0) continue;
        a[i][k] = f;
        const ai = a[i], ak = a[k];
        for (let j = k + 1; j < n; j++) ai[j] -= f * ak[j];
      }
    }
    return { a, piv, n };
  }
  function luSolve(lu, b) {
    const { a, piv, n } = lu, x = Float64Array.from(b);
    /* permutations (échanges de lignes entières, convention LAPACK) puis descente avec L à diagonale unité */
    for (let k = 0; k < n; k++) { const p = piv[k]; if (p !== k) { const t = x[k]; x[k] = x[p]; x[p] = t; } }
    for (let k = 0; k < n; k++) for (let i = k + 1; i < n; i++) x[i] -= a[i][k] * x[k];
    for (let i = n - 1; i >= 0; i--) { let s = x[i]; for (let j = i + 1; j < n; j++) s -= a[i][j] * x[j]; x[i] = s / a[i][i]; }
    return x;
  }
  function solveSmall(A, b) { return Array.from(luSolve(luFactor(A), b)); }

  /* Valeurs / vecteurs propres d'une matrice symétrique (Jacobi cyclique). Retourne {vals, vecs} (vecs[j] = vecteur j). */
  function jacobi(S) {
    const n = S.length, A = S.map(r => Float64Array.from(r)), V = Array.from({ length: n }, (_, i) => { const r = new Float64Array(n); r[i] = 1; return r; });
    for (let sweep = 0; sweep < 100; sweep++) {
      let off = 0, tot = 0;
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { tot += A[i][j] * A[i][j]; if (i !== j) off += A[i][j] * A[i][j]; }
      if (off <= 1e-26 * Math.max(tot, 1e-300)) break;
      for (let p = 0; p < n - 1; p++) for (let q = p + 1; q < n; q++) {
        const apq = A[p][q];
        if (Math.abs(apq) < 1e-300) continue;
        const th = (A[q][q] - A[p][p]) / (2 * apq), t = Math.sign(th || 1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), s = t * c;
        for (let k = 0; k < n; k++) { const akp = A[k][p], akq = A[k][q]; A[k][p] = c * akp - s * akq; A[k][q] = s * akp + c * akq; }
        for (let k = 0; k < n; k++) { const apk = A[p][k], aqk = A[q][k]; A[p][k] = c * apk - s * aqk; A[q][k] = s * apk + c * aqk; }
        for (let k = 0; k < n; k++) { const vkp = V[k][p], vkq = V[k][q]; V[k][p] = c * vkp - s * vkq; V[k][q] = s * vkp + c * vkq; }
      }
    }
    const idx = Array.from({ length: n }, (_, i) => i).sort((i, j) => A[i][i] - A[j][j]);
    return { vals: idx.map(i => A[i][i]), vecs: idx.map(i => Array.from({ length: n }, (_, k) => V[k][i])) };
  }

  /* ====================================================================== combinaisons d'actions */
  /* Coefficients ψ0, ψ1, ψ2 (EN 1990 tableau A1.1) par catégorie d'action variable. */
  const PSI = {
    A: { nom: "Habitation, résidentiel (cat. A)", p: [.7, .5, .3] }, B: { nom: "Bureaux (cat. B)", p: [.7, .5, .3] },
    C: { nom: "Lieux de réunion (cat. C)", p: [.7, .7, .6] }, D: { nom: "Commerces (cat. D)", p: [.7, .7, .6] },
    E: { nom: "Stockage (cat. E)", p: [1, .9, .8] }, F: { nom: "Circulation, véhicules ≤ 30 kN (cat. F)", p: [.7, .7, .6] },
    G: { nom: "Circulation, 30 à 160 kN (cat. G)", p: [.7, .5, .3] }, H: { nom: "Toitures (cat. H)", p: [0, 0, 0] },
    S: { nom: "Neige (site ≤ 1000 m)", p: [.5, .2, 0] }, S2: { nom: "Neige (site > 1000 m)", p: [.7, .5, .2] },
    W: { nom: "Vent", p: [.6, .2, 0] }, T: { nom: "Température (hors incendie)", p: [.6, .5, 0] }
  };
  const f2 = (x, d = 2) => (Number.isFinite(x) ? x.toFixed(d) : "—");
  const nombre = x => String(+x.toFixed(3));

  /* actions : [{ n:"G", type:"G" }, { n:"Q", type:"Q", cat:"B" }, { n:"Wx+", type:"W", group:"Wx" }, { n:"Ex", type:"E", dir:"x" }, { n:"A", type:"A" }]
     type G = permanente, Q/S/W/T = variable (cat → ψ), A = accidentelle, E = sismique (sans signe, ±1 et 0,3 des deux directions).
     opt : { norme:"EC"|"BAEL", gGsup:1.35, gGinf:1, gQ:1.5, xi:.85, sixab:false, els:true, accid:true, sism:true, psiE:null }.
     Retourne [{ id, famille, f:{cas:facteur}, expr }]. */
  function combinaisons(actions, opt) {
    const o = Object.assign({ norme: "EC", gGsup: 1.35, gGinf: 1, gQ: 1.5, xi: .85, sixab: false, els: true, accid: true, sism: true, psiE: null }, opt || {});
    const bael = o.norme === "BAEL";
    const psi = a => { const t = PSI[a.cat || (a.type === "Q" ? "B" : a.type === "T" ? "T" : a.type)] || PSI.B; return a.psi ? a.psi : t.p; };
    const P = actions.filter(a => a.type === "G"), V = actions.filter(a => ["Q", "S", "W", "T"].includes(a.type)),
      Ac = actions.filter(a => a.type === "A"), E = actions.filter(a => a.type === "E");
    const out = [], seen = new Set();
    const add = (famille, f, tag) => {
      const ks = Object.keys(f).filter(k => Math.abs(f[k]) > 1e-12);
      if (!ks.length) return;
      const key = famille + "|" + ks.map(k => k + ":" + f[k].toFixed(6)).sort().join(",");
      if (seen.has(key)) return; seen.add(key);
      const expr = ks.map((k, i) => { const v = f[k]; return (i ? (v < 0 ? " − " : " + ") : (v < 0 ? "−" : "")) + (Math.abs(Math.abs(v) - 1) < 1e-9 ? "" : nombre(Math.abs(v)) + "·") + k; }).join("");
      out.push({ id: "", famille, tag: tag || "", f: Object.fromEntries(ks.map(k => [k, f[k]])), expr });
    };
    /* ensembles de variables compatibles : 1 seule action par groupe exclusif */
    const sous = (lead, sel) => {
      const grp = new Set(lead ? [lead.group || lead.n] : []), r = [];
      for (const a of sel) { const g = a.group || a.n; if (grp.has(g)) continue; grp.add(g); r.push(a); }
      return r;
    };
    const Gset = (g, fn) => { const f = {}; P.forEach(a => { f[a.n] = g; }); return f; };
    const leaders = V.length ? V : [null];
    for (const g of [o.gGsup, o.gGinf]) {
      if (g === o.gGinf && !P.length) continue;
      for (const L of leaders) {
        const acc = sous(L, V.filter(a => a !== L));
        const base = Gset(g);
        if (o.sixab && !bael && g === o.gGsup) {
          /* 6.10a : 1,35 G + 1,5 ψ0,1 Q1 + Σ 1,5 ψ0,i Qi ; 6.10b : ξ·1,35 G + 1,5 Q1 + Σ 1,5 ψ0,i Qi */
          const fa = { ...base }; if (L) fa[L.n] = o.gQ * psi(L)[0]; acc.forEach(a => { fa[a.n] = o.gQ * psi(a)[0]; }); add("ELU", fa, "6.10a");
          const fb = {}; P.forEach(a => { fb[a.n] = o.xi * g; }); if (L) fb[L.n] = o.gQ; acc.forEach(a => { fb[a.n] = o.gQ * psi(a)[0]; }); add("ELU", fb, "6.10b");
        } else {
          const f = { ...base };
          if (L) f[L.n] = o.gQ;
          acc.forEach(a => { f[a.n] = (bael ? 1.3 : o.gQ) * psi(a)[0]; });
          add("ELU", f, g === o.gGinf ? "G favorable" : "");
        }
      }
    }
    if (o.els) {
      const fcar = Gset(1), ffreq = Gset(1), fqp = Gset(1);
      V.forEach(a => { fqp[a.n] = psi(a)[2]; });
      add("ELS-QP", fqp);
      for (const L of leaders) {
        const acc = sous(L, V.filter(a => a !== L)), c = Gset(1), q = Gset(1);
        if (L) { c[L.n] = 1; q[L.n] = psi(L)[1]; }
        acc.forEach(a => { c[a.n] = psi(a)[0]; q[a.n] = psi(a)[2]; });
        add("ELS-CAR", c); add("ELS-FREQ", q);
      }
      if (!V.length) { add("ELS-CAR", fcar); add("ELS-FREQ", ffreq); }
    }
    if (o.accid && Ac.length) for (const A of Ac) for (const L of leaders) {
      const acc = sous(L, V.filter(a => a !== L)), f = Gset(1); f[A.n] = 1;
      if (L) f[L.n] = psi(L)[1]; acc.forEach(a => { f[a.n] = psi(a)[2]; }); add("ACC", f);
    }
    if (o.sism && E.length) {
      const dirs = [...new Set(E.map(e => e.dir || "x"))], fq = {};
      for (const sg of [1, -1]) for (const d of dirs) for (const d2 of dirs) {
        const f = Gset(1), e1 = E.find(e => (e.dir || "x") === d), e2 = E.find(e => (e.dir || "x") === d2);
        if (d === d2) { f[e1.n] = sg; } else { f[e1.n] = sg; f[e2.n] = .3 * (sg); }
        V.forEach(a => { f[a.n] = (o.psiE != null ? o.psiE : psi(a)[2]); });
        add("SISM", f);
        if (d !== d2) { const f2b = { ...f }; f2b[e2.n] = -f2b[e2.n]; add("SISM", f2b); }
      }
    }
    const cpt = {};
    out.forEach(c => { cpt[c.famille] = (cpt[c.famille] || 0) + 1; c.id = c.famille + " " + cpt[c.famille]; });
    return out;
  }

  /* Combine des effets (scalaires ou tableaux) déjà calculés par cas : effets = { G:x, Q:y, ... }. */
  function combiner(effets, combo) {
    const ks = Object.keys(combo.f);
    if (Array.isArray(effets[ks[0]])) { const n = effets[ks[0]].length; return Array.from({ length: n }, (_, i) => ks.reduce((s, k) => s + combo.f[k] * (effets[k] ? effets[k][i] : 0), 0)); }
    return ks.reduce((s, k) => s + combo.f[k] * (effets[k] || 0), 0);
  }

  /* ====================================================================== éléments finis : barres planes */
  const GL = [[-.8611363115940526, .3478548451374538], [-.3399810435848563, .6521451548625461], [.3399810435848563, .6521451548625461], [.8611363115940526, .3478548451374538]];
  const hermite = (x, L) => { const s = x / L; return [1 - 3 * s * s + 2 * s ** 3, L * (s - 2 * s * s + s ** 3), 3 * s * s - 2 * s ** 3, L * (-s * s + s ** 3)]; };

  function kLocal(E, A, I, L) {
    const EA = E * A / L, a = 12 * E * I / L ** 3, b = 6 * E * I / L ** 2, c = 4 * E * I / L, d = 2 * E * I / L;
    return [[EA, 0, 0, -EA, 0, 0], [0, a, b, 0, -a, b], [0, b, c, 0, -b, d], [-EA, 0, 0, EA, 0, 0], [0, -a, -b, 0, a, -b], [0, b, d, 0, -b, c]];
  }
  /* charge répartie linéaire sur [a,b] (composantes locales qx, qy trapèze) → charges nodales équivalentes cohérentes */
  function eqDist(it, L) {
    const f = [0, 0, 0, 0, 0, 0], len = it.b - it.a;
    if (len <= 0) return f;
    for (const [g, w] of GL) {
      const s = it.a + len * (g + 1) / 2, t = (s - it.a) / len, wt = w * len / 2, qy = it.qy1 + (it.qy2 - it.qy1) * t, qx = it.qx1 + (it.qx2 - it.qx1) * t, N = hermite(s, L);
      f[0] += qx * (1 - s / L) * wt; f[3] += qx * (s / L) * wt;
      f[1] += qy * N[0] * wt; f[2] += qy * N[1] * wt; f[4] += qy * N[2] * wt; f[5] += qy * N[3] * wt;
    }
    return f;
  }
  function eqPoint(it, L) {
    const N = hermite(it.a, L), s = it.a / L;
    return [it.Px * (1 - s), it.Py * N[0], it.Py * N[1], it.Px * s, it.Py * N[2], it.Py * N[3]];
  }

  /* model : { nodes:[{x,y}], members:[{i,j,E,A,I,relI,relJ,alpha}], supports:[{n,ux,uy,rz,dx,dy,drz}],
               E en kN/m² (E MPa × 1000) ; ux/uy/rz : true = bloqué, nombre = ressort (kN/m ou kN.m/rad) ; dx,dy,drz = tassement imposé }.
     loads (par cas) : { nodes:[{n,fx,fy,m}], members:[{m,type:"dist"|"point"|"temp", dir:"L"|"X"|"Y", q1,q2,a,b,proj | P,a | dT}] } */
  function frame(model) {
    const nodes = model.nodes, nn = nodes.length, nd = 3 * nn, mem = model.members;
    if (!nn || !mem.length) throw new Error("Modèle vide : ajoutez des nœuds et des barres.");
    const geo = mem.map((m, k) => {
      const a = nodes[m.i], b = nodes[m.j], dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy);
      if (!(L > 1e-9)) throw new Error(`Barre ${k + 1} de longueur nulle.`);
      if (!(m.E > 0 && m.A > 0 && m.I > 0)) throw new Error(`Barre ${k + 1} : E, A et I doivent être > 0.`);
      const c = dx / L, s = dy / L, kl = kLocal(m.E, m.A, m.I, L), R = [];
      /* matrice de rotation globale → locale, 6×6 */
      const T = [[c, s, 0, 0, 0, 0], [-s, c, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [0, 0, 0, c, s, 0], [0, 0, 0, -s, c, 0], [0, 0, 0, 0, 0, 1]];
      const rel = [], free = [];
      if (m.relI) rel.push(2); if (m.relJ) rel.push(5);
      for (let q = 0; q < 6; q++) if (!rel.includes(q)) free.push(q);
      let kc = kl, kRRinv = null;
      if (rel.length) {
        const kRR = rel.map(r => rel.map(c2 => kl[r][c2])), kFR = free.map(r => rel.map(c2 => kl[r][c2])), kFF = free.map(r => free.map(c2 => kl[r][c2]));
        const inv = rel.length === 1 ? [[1 / kRR[0][0]]] : (() => { const d = kRR[0][0] * kRR[1][1] - kRR[0][1] * kRR[1][0]; return [[kRR[1][1] / d, -kRR[0][1] / d], [-kRR[1][0] / d, kRR[0][0] / d]]; })();
        kRRinv = inv;
        const corr = kFR.map(row => rel.map((_, c2) => row.reduce((s, v, j) => s + v * inv[j][c2], 0)));
        const kFFc = kFF.map((row, i) => row.map((v, j) => v - corr[i].reduce((s, cv, c2) => s + cv * kFR[j][c2], 0)));
        kc = Array.from({ length: 6 }, () => new Array(6).fill(0));
        free.forEach((r, i) => free.forEach((c2, j) => { kc[r][c2] = kFFc[i][j]; }));
      }
      const kg = Array.from({ length: 6 }, (_, i) => Array.from({ length: 6 }, (_, j) => { let s = 0; for (let p = 0; p < 6; p++) if (T[p][i]) for (let q = 0; q < 6; q++) if (T[q][j]) s += T[p][i] * kc[p][q] * T[q][j]; return s; }));
      return { L, c, s, T, kl, kc, kg, rel, free, kRRinv, dofs: [3 * m.i, 3 * m.i + 1, 3 * m.i + 2, 3 * m.j, 3 * m.j + 1, 3 * m.j + 2] };
    });
    /* assemblage */
    const K = Array.from({ length: nd }, () => new Float64Array(nd));
    mem.forEach((m, k) => { const g = geo[k]; for (let i = 0; i < 6; i++) for (let j = 0; j < 6; j++) K[g.dofs[i]][g.dofs[j]] += g.kg[i][j]; });
    /* appuis */
    const fixed = new Array(nd).fill(false), presc = new Float64Array(nd), spr = new Float64Array(nd);
    (model.supports || []).forEach(s => {
      const set = (d, v, dv) => { if (v === true) { fixed[d] = true; presc[d] = dv || 0; } else if (typeof v === "number" && v > 0) { spr[d] += v; presc[d] += dv || 0; } };
      set(3 * s.n, s.ux, s.dx); set(3 * s.n + 1, s.uy, s.dy); set(3 * s.n + 2, s.rz, s.drz);
    });
    /* rotation d'un nœud dont toutes les barres sont articulées : raideur nulle, ddl sans effet → bloqué (comme Robot) */
    let kmax = 0; for (let d = 0; d < nd; d++) kmax = Math.max(kmax, K[d][d]);
    const auto = [];
    for (let d = 2; d < nd; d += 3) if (!fixed[d] && K[d][d] + spr[d] < 1e-10 * kmax) { fixed[d] = true; presc[d] = 0; auto.push(d); }
    const freeD = []; for (let d = 0; d < nd; d++) if (!fixed[d]) freeD.push(d);
    if (!fixed.some(Boolean) && !spr.some(v => v > 0)) throw new Error("Aucun appui : la structure n'est pas stable.");
    const Kff = freeD.map(i => freeD.map(j => K[i][j] + (i === j ? spr[i] : 0)));
    const lu = freeD.length ? luFactor(Kff) : null;
    const fpos = new Map(freeD.map((d, i) => [d, i]));

    /* charges d'une barre en repère local → vecteur équivalent complet (6), avant condensation */
    function memberLoad(k, items) {
      const g = geo[k], m = mem[k], L = g.L, f = [0, 0, 0, 0, 0, 0], loc = [];
      for (const it of items) {
        if (it.type === "temp") {
          const N0 = m.E * m.A * (m.alpha == null ? 1e-5 : m.alpha) * it.dT; f[0] += -N0; f[3] += N0; loc.push({ type: "temp" }); continue;
        }
        const fac = it.dir === "L" ? [1, 0] : it.dir === "X" ? [g.c, -g.s] : [g.s, g.c]; /* composantes locales d'une charge unitaire globale */
        const pr = it.proj ? (it.dir === "Y" ? Math.abs(g.c) : it.dir === "X" ? Math.abs(g.s) : 1) : 1;
        if (it.type === "point") {
          const P = (it.P || 0) * pr, a = Math.min(Math.max(it.a || 0, 0), L), item = { type: "point", a, Px: it.dir === "L" ? 0 : P * fac[0], Py: it.dir === "L" ? P : P * fac[1] };
          const e = eqPoint(item, L); for (let q = 0; q < 6; q++) f[q] += e[q]; loc.push(item);
        } else {
          const q1 = (it.q1 || 0) * pr, q2 = (it.q2 == null ? it.q1 : it.q2) * pr, a = Math.max(it.a || 0, 0), b = Math.min(it.b == null ? L : it.b, L);
          const sc = x => it.dir === "L" ? [0, x] : [x * fac[0], x * fac[1]];
          const item = { type: "dist", a, b, qx1: sc(q1)[0], qx2: sc(q2)[0], qy1: sc(q1)[1], qy2: sc(q2)[1] };
          const e = eqDist(item, L); for (let q = 0; q < 6; q++) f[q] += e[q]; loc.push(item);
        }
      }
      return { f, loc };
    }

    /* résolution d'un cas de charges */
    function solveCase(loads) {
      loads = loads || {};
      const F = new Float64Array(nd);
      (loads.nodes || []).forEach(n => { F[3 * n.n] += n.fx || 0; F[3 * n.n + 1] += n.fy || 0; F[3 * n.n + 2] += n.m || 0; });
      const byMember = mem.map(() => []); (loads.members || []).forEach(it => { if (byMember[it.m]) byMember[it.m].push(it); });
      const ml = mem.map((_, k) => memberLoad(k, byMember[k]));
      const Fnodal = Float64Array.from(F);
      ml.forEach((x, k) => {
        const g = geo[k]; let f = x.f;
        if (g.rel.length) { /* f* = fF − kFR kRR⁻¹ fR */
          const fR = g.rel.map(r => f[r]), tmp = g.kRRinv.map(row => row.reduce((s, v, j) => s + v * fR[j], 0)), fs = f.slice();
          g.free.forEach(r => { fs[r] = f[r] - g.rel.reduce((s, c2, j) => s + g.kl[r][c2] * tmp[j], 0); });
          g.rel.forEach(r => { fs[r] = 0; }); f = fs;
        }
        for (let q = 0; q < 6; q++) { let s = 0; for (let p = 0; p < 6; p++) if (g.T[p][q]) s += g.T[p][q] * f[p]; F[g.dofs[q]] += s; }
        x.fc = f;
      });
      /* second membre : F − Kfp·up (tassements) + ressorts·tassement */
      /* tassements propres au cas (loads.settle) ajoutés à ceux déclarés sur les appuis */
      const pr = Float64Array.from(presc);
      (loads.settle || []).forEach(t => { pr[3 * t.n] += t.dx || 0; pr[3 * t.n + 1] += t.dy || 0; pr[3 * t.n + 2] += t.drz || 0; });
      const rhs = freeD.map(d => {
        let r = F[d] + spr[d] * pr[d];
        if (!fixed[d]) { for (let p = 0; p < nd; p++) if (fixed[p] && pr[p] !== 0) r -= K[d][p] * pr[p]; }
        return r;
      });
      const xf = freeD.length ? luSolve(lu, rhs) : new Float64Array(0), u = new Float64Array(nd);
      freeD.forEach((d, i) => { u[d] = xf[i]; });
      for (let d = 0; d < nd; d++) if (fixed[d]) u[d] = pr[d];
      /* réactions : K·u − F sur ddl bloqués ; ressorts : −k (u − tassement) */
      const R = new Float64Array(nd);
      for (let d = 0; d < nd; d++) {
        if (fixed[d]) { let s = -F[d]; for (let j = 0; j < nd; j++) s += K[d][j] * u[j]; R[d] = s; }
        else if (spr[d] > 0) R[d] = -spr[d] * (u[d] - pr[d]);
      }
      /* efforts d'extrémité en repère local (forces exercées par les nœuds sur la barre) */
      const fe = [], ul = [];
      mem.forEach((m, k) => {
        const g = geo[k], ug = g.dofs.map(d => u[d]), u6 = g.T.map(row => row.reduce((s, v, j) => s + v * ug[j], 0));
        if (g.rel.length) { /* récupération des rotations relâchées : uR = kRR⁻¹ (fR − kRF uF) */
          const rhsR = g.rel.map(r => ml[k].f[r] - g.free.reduce((s, c2) => s + g.kl[r][c2] * u6[c2], 0)), uR = g.kRRinv.map(row => row.reduce((s, v, j) => s + v * rhsR[j], 0));
          g.rel.forEach((r, j) => { u6[r] = uR[j]; });
        }
        const e = g.kl.map((row, i) => row.reduce((s, v, j) => s + v * u6[j], 0) - ml[k].f[i]);
        g.rel.forEach(r => { e[r] = 0; });
        fe.push(e); ul.push(u6);
      });
      return { u, R, fe, ul, loc: ml.map(x => x.loc), F: Fnodal };
    }
    return { model, nn, nd, geo, K, fixed, spr, freeD, fpos, solveCase, lu, presc, auto };
  }

  /* ---------------------------------------------------------------- efforts intérieurs le long d'une barre
     spec : [{ c: résultat de cas, f: facteur }] (combinaison linéaire). Retourne { x[], N[], V[], M[], v[] }.
     N > 0 traction ; V : convention de la RDM (V = dM/dx) ; M > 0 si fibre inférieure tendue (repère local, y vers le haut). */
  function stationsOf(fr, k, spec, n) {
    const L = fr.geo[k].L, xs = new Set();
    for (let i = 0; i <= n; i++) xs.add(+(L * i / n).toFixed(9));
    spec.forEach(sp => sp.c.loc[k].forEach(it => { if (it.type === "point") xs.add(+it.a.toFixed(9)); else if (it.type === "dist") { xs.add(+it.a.toFixed(9)); xs.add(+it.b.toFixed(9)); } }));
    return [...xs].sort((a, b) => a - b);
  }
  function effortsBarre(fr, k, spec, n, ctx) {
    n = n || 20;
    const g = fr.geo[k], m = fr.model.members[k], L = g.L, xs = ctx ? ctx.xs : stationsOf(fr, k, spec, n), out = { x: [], N: [], V: [], M: [], v: [], dx: [] };
    const fe = [0, 0, 0, 0, 0, 0], ue = [0, 0, 0, 0, 0, 0];
    spec.forEach(sp => { for (let q = 0; q < 6; q++) { fe[q] += sp.f * sp.c.fe[k][q]; ue[q] += sp.f * sp.c.ul[k][q]; } });
    const val = (x, side) => {
      let N = -fe[0], V = fe[1], M = -fe[2] + x * fe[1];
      for (const sp of spec) for (const it of sp.c.loc[k]) {
        const w = sp.f;
        if (it.type === "point") { if (x > it.a + 1e-12 || (side > 0 && x >= it.a - 1e-12)) { N -= w * it.Px; V += w * it.Py; M += w * it.Py * (x - it.a); } }
        else if (it.type === "dist") {
          const t = Math.min(x, it.b) - it.a; if (t <= 0) continue;
          const len = it.b - it.a, ky = (it.qy2 - it.qy1) / len, kx = (it.qx2 - it.qx1) / len;
          const Wy = it.qy1 * t + ky * t * t / 2, Wx = it.qx1 * t + kx * t * t / 2;
          V += w * Wy; N -= w * Wx; M += w * ((x - it.a) * Wy - (it.qy1 * t * t / 2 + ky * t ** 3 / 3));
        }
      }
      return [N, V, M];
    };
    xs.forEach((x, i) => {
      const hasPt = ctx ? ctx.pts.some(a => Math.abs(a - x) < 1e-9) : spec.some(sp => sp.c.loc[k].some(it => it.type === "point" && Math.abs(it.a - x) < 1e-9));
      const sides = hasPt ? [-1, 1] : [1];
      sides.forEach(sd => { const [N, V, M] = val(x, sd); out.x.push(x); out.N.push(N); out.V.push(V); out.M.push(M); });
    });
    /* flèche locale par double intégration des courbures (M/EI), recalée sur les déplacements nodaux */
    const nI = 200, EI = m.E * m.I, v = [ue[1]], th = [ue[2]], dxs = L / nI;
    let vv = ue[1], tt = ue[2]; const vs = [vv];
    for (let i = 1; i <= nI; i++) { const x0 = (i - 1) * dxs, x1 = i * dxs, k0 = val(x0 + 1e-12, 1)[2] / EI, k1 = val(x1 - 1e-12, -1)[2] / EI; const t1 = tt + (k0 + k1) / 2 * dxs; vv += (tt + t1) / 2 * dxs; tt = t1; vs.push(vv); }
    const corr = ue[4] - vs[nI];
    const vAt = x => { const p = x / dxs, i = Math.min(Math.floor(p), nI - 1), r = p - i; return vs[i] * (1 - r) + vs[i + 1] * r + corr * x / L; };
    out.x.forEach(x => { out.v.push(vAt(x)); out.dx.push(ue[0] + (ue[3] - ue[0]) * x / L); });
    out.L = L;
    return out;
  }

  /* Enveloppe de plusieurs combinaisons sur toutes les barres (mêmes abscisses pour toutes les combinaisons).
     cases : { nom: résultat de solveCase } ; combos : [{id,f}] ;
     retourne { barres:[{x, Nmax,Nmin,Vmax,Vmin,Mmax,Mmin,vmax,vmin, cMmax,cMmin,… , L}], R:{ddl:{max,min,cmax,cmin}} } */
  function enveloppe(fr, cases, combos, n) {
    const nb = fr.model.members.length, barres = [], allc = Object.keys(cases).map(c => ({ c: cases[c], f: 0 }));
    for (let k = 0; k < nb; k++) {
      const xs = stationsOf(fr, k, allc, n || 20), pts = [];
      allc.forEach(sp => sp.c.loc[k].forEach(it => { if (it.type === "point") pts.push(it.a); }));
      const ctx = { xs, pts }; let env = null;
      combos.forEach(cb => {
        const spec = Object.keys(cb.f).filter(c => cases[c]).map(c => ({ c: cases[c], f: cb.f[c] })), r = effortsBarre(fr, k, spec, n, ctx);
        if (!env) { env = { x: r.x, L: r.L }; for (const q of ["N", "V", "M", "v"]) { env[q + "max"] = r[q].slice(); env[q + "min"] = r[q].slice(); env["c" + q + "max"] = r.x.map(() => cb.id); env["c" + q + "min"] = r.x.map(() => cb.id); } return; }
        for (const q of ["N", "V", "M", "v"]) r.x.forEach((_, i) => {
          if (r[q][i] > env[q + "max"][i]) { env[q + "max"][i] = r[q][i]; env["c" + q + "max"][i] = cb.id; }
          if (r[q][i] < env[q + "min"][i]) { env[q + "min"][i] = r[q][i]; env["c" + q + "min"][i] = cb.id; }
        });
      });
      barres.push(env);
    }
    const R = {};
    combos.forEach(cb => {
      const ks = Object.keys(cb.f).filter(c => cases[c]);
      for (let d = 0; d < fr.nd; d++) {
        if (!(fr.fixed[d] || fr.spr[d] > 0)) continue;
        const v = ks.reduce((s, c) => s + cb.f[c] * cases[c].R[d], 0), e = R[d] = R[d] || { max: v, min: v, cmax: cb.id, cmin: cb.id };
        if (v > e.max) { e.max = v; e.cmax = cb.id; } if (v < e.min) { e.min = v; e.cmin = cb.id; }
      }
    });
    return { barres, R };
  }


  /* ====================================================================== poteau en flexion composée (diagramme d'interaction N–M) */
  /* o : { b, h (m), enr (m, axe des aciers), fc, fe (MPa), acc (0,85 BAEL / 1 EC2), gb, gs, N (kN, compression > 0), M (kN.m), l0 (m, longueur de flambement) }
     Section rectangulaire, aciers symétriques (As/2 sur chaque face), bloc rectangulaire 0,8x, pivots B (3,5 ‰) et C (2 ‰ à 3h/7), acier élasto-plastique.
     Retourne { As (cm²), Med, e0, courbe:[{N,M}], ok, lam }. Pas d'effets du second ordre (alerte si λ > 25). */
  function courbeNM(o, AsCm2) {
    const b = o.b, h = o.h, ds = o.enr, fbu = (o.acc == null ? .85 : o.acc) * o.fc / (o.gb || 1.5) * 1000, fed = o.fe / (o.gs || 1.15) * 1000, Es = 2e8, A = AsCm2 / 1e4 / 2, pts = [];
    for (let i = 0; i <= 240; i++) {
      const x = h * .02 * Math.pow(1000, i / 240) /* 0,02h … 20h */, lam = Math.min(.8 * x, h);
      const eps = y => (x <= h ? 3.5e-3 * (x - y) / x : 2e-3 * (x - y) / (x - 3 * h / 7)), sg = y => Math.max(-fed, Math.min(fed, Es * eps(y)));
      const Fc = fbu * b * lam, s1 = sg(ds), s2 = sg(h - ds);
      pts.push({ x, N: Fc + A * (s1 + s2), M: Fc * (h / 2 - lam / 2) + A * s1 * (h / 2 - ds) + A * s2 * (h / 2 - (h - ds)) });
    }
    return pts;
  }
  function momentResistant(pts, N) {
    if (N > pts[pts.length - 1].N) return -1;
    for (let i = 1; i < pts.length; i++) if (pts[i].N >= N) { const a = pts[i - 1], c = pts[i], t = (N - a.N) / (c.N - a.N || 1); return a.M + t * (c.M - a.M); }
    return pts[0].M;
  }
  function colonneNM(o) {
    const h = o.h, N = o.N, lam = (o.l0 || 0) / (h / Math.sqrt(12)), e0 = Math.max(h / 30, .02), Med = Math.max(Math.abs(o.M), N * e0), B = o.b * h * 1e4;
    const Amin = Math.max(.002 * B, 0), Amax = .05 * B, ok = A => momentResistant(courbeNM(o, A), N) >= Med;
    const base = { Med, e0, lam, Amin, Amax };
    if (!(N > 0)) return Object.assign(base, { ok: false, As: Infinity, err: "Effort normal de compression nul ou négatif : poteau tendu, non traité." });
    let lo = 0, hi = Amax;
    if (!ok(hi)) return Object.assign(base, { ok: false, As: Infinity, err: "Section insuffisante même avec 5 % d'acier : augmenter la section ou fc28." });
    if (ok(0)) hi = 0; else for (let i = 0; i < 40; i++) { const mid = (lo + hi) / 2; if (ok(mid)) hi = mid; else lo = mid; }
    return Object.assign(base, { ok: true, As: Math.max(hi, Amin), AsCalc: hi });
  }



  /* ====================================================================== poteau rectangulaire : flexion composée déviée, aciers répartis, second ordre */
  /* courbe d'interaction à armatures réparties en nappes : layers = [{y (m depuis la fibre la plus comprimée), A (m²)}] */
  function courbeNMc(o, layers) {
    const b = o.b, h = o.h, fbu = (o.acc == null ? .85 : o.acc) * o.fc / (o.gb || 1.5) * 1000, fed = o.fe / (o.gs || 1.15) * 1000, Es = 2e8, pts = [];
    for (let i = 0; i <= 240; i++) {
      const x = h * .02 * Math.pow(1000, i / 240), lam = Math.min(.8 * x, h);
      const eps = y => (x <= h ? 3.5e-3 * (x - y) / x : 2e-3 * (x - y) / (x - 3 * h / 7)), sg = y => Math.max(-fed, Math.min(fed, Es * eps(y)));
      const Fc = fbu * b * lam; let N = Fc, M = Fc * (h / 2 - lam / 2);
      layers.forEach(l => { const f = l.A * sg(l.y); N += f; M += f * (h / 2 - l.y); });
      pts.push({ x, N, M });
    }
    return pts;
  }
  /* nappes pour une section h (sens de flexion) × w, avec k barres par face (k ≥ 2) ; As total en m² ; ds = enrobage à l'axe */
  function nappes(h, ds, AsM2, k) {
    k = Math.max(2, Math.round(k)); const tot = 4 * k - 4, a = AsM2 / tot, L = [{ y: ds, A: a * k }, { y: h - ds, A: a * k }];
    for (let i = 1; i <= k - 2; i++) L.push({ y: ds + i * (h - 2 * ds) / (k - 1), A: 2 * a });
    return L;
  }
  /* o : { a, b (m : dimensions), ds (m), fc, fe, acc, gb, gs, N (kN), Ma, Mb (kN.m, moments de flexion dans le sens de a et de b), l0a, l0b (m), ec (bool), alpha (G/(G+Q), BAEL) }
     As : si fixé (o.As cm², o.k barres/face) → vérification ; sinon dimensionnement par dichotomie.  */
  function poteauNM(o) {
    if (o.circ) return poteauNMcirc(o);
    const N = o.N, fcd = (o.acc == null ? .85 : o.acc) * o.fc / (o.gb || 1.5), fyd = o.fe / (o.gs || 1.15), Ac = o.a * o.b, Es = 2e5;
    const ax = [{ h: o.a, w: o.b, M: Math.abs(o.Ma || 0), l0: o.l0a || 0 }, { h: o.b, w: o.a, M: Math.abs(o.Mb || 0), l0: o.l0b || 0 }];
    const lamLim = N > 0 ? 20 * .7 * 1.1 * .7 / Math.sqrt(Math.max(N / 1000 / (Ac * fcd), .01)) : 0;
    const ex = (q, As) => {
      const lam = q.l0 / (q.h / Math.sqrt(12)), emin = Math.max(q.h / 30, .02), e0 = q.M / N, ei = o.ec ? q.l0 / 400 : 0;
      let e2 = 0;
      if (o.ec && lam > lamLim) {
        const d = q.h - o.ds, om = As / 1e4 * fyd / (Ac * fcd), nu = 1 + om, n = N / 1000 / (Ac * fcd), Kr = Math.max(0, Math.min(1, (nu - n) / (nu - .4)));
        e2 = Kr * (fyd / Es) / (.45 * d) * q.l0 * q.l0 / 10;
      } else if (!o.ec && lam > 25) { const al = o.alpha == null ? 1 : o.alpha; e2 = 3 * q.l0 * q.l0 * (2 + al * 2) / (1e4 * q.h); }
      const e = Math.max(e0 + ei, emin) + e2;
      return { lam, emin, e0, ei, e2, e, Med: N * e };
    };
    const curve = (q, As, k) => courbeNMc({ b: q.w, h: q.h, fc: o.fc, fe: o.fe, acc: o.acc, gb: o.gb, gs: o.gs }, nappes(q.h, o.ds, As / 1e4, k));
    const evalAs = (As, k) => {
      const E = ax.map(q => ex(q, As)), C = ax.map(q => curve(q, As, k)), MR = ax.map((q, i) => momentResistant(C[i], N));
      const NRd = (Ac * fcd + As / 1e4 * fyd) * 1000, r = N / NRd, a = r <= .1 ? 1 : r >= 1 ? 2 : r <= .7 ? 1 + (r - .1) / .6 * .5 : 1.5 + (r - .7) / .3 * .5;
      if (MR.some(m => m < 0)) return { ok: false, ratio: Infinity, E, C, MR, a, NRd };
      const rt = E.reduce((s, e, i) => s + Math.pow(e.Med / Math.max(MR[i], 1e-9), a), 0);
      return { ok: rt <= 1, ratio: rt, E, C, MR, a, NRd };
    };
    const B = Ac * 1e4, Amin = Math.max(.002 * B, o.ec ? .1 * N / 1000 / fyd * 1e4 : 0), Amax = (o.ec ? .04 : .05) * B;
    if (!(N > 0)) return { ok: false, err: "Effort normal de compression nul ou négatif.", Amin, Amax, lamLim };
    if (o.As != null) { const r = evalAs(o.As, o.k || 4); return Object.assign(r, { As: o.As, Amin, Amax, lamLim, lam: r.E.map(e => e.lam) }); }
    const k0 = 4; let hi = Amax, r = evalAs(hi, k0);
    if (!r.ok) return Object.assign(r, { ok: false, As: Infinity, Amin, Amax, lamLim, err: "Section insuffisante même avec " + (o.ec ? "4" : "5") + " % d'acier : augmenter la section ou fc28." });
    let lo = 0; for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (evalAs(m, k0).ok) hi = m; else lo = m; }
    const AsC = hi, As = Math.max(AsC, Amin), f = evalAs(As, k0);
    return Object.assign(f, { ok: true, As, AsCalc: AsC, Amin, Amax, lamLim, lam: f.E.map(e => e.lam) });
  }


  /* ====================================================================== poteau circulaire : courbe N–M, n barres régulièrement réparties */
  function courbeNMcirc(o, n, AsM2) {
    const D = o.D, R = D / 2, rs = R - o.ds, fbu = (o.acc == null ? .85 : o.acc) * o.fc / (o.gb || 1.5) * 1000, fed = o.fe / (o.gs || 1.15) * 1000, Es = 2e8, a1 = AsM2 / n, pts = [];
    for (let i = 0; i <= 240; i++) {
      const x = D * .02 * Math.pow(1000, i / 240), lam = Math.min(.8 * x, D);
      const eps = y => (x <= D ? 3.5e-3 * (x - y) / x : 2e-3 * (x - y) / (x - 3 * D / 7)), sg = y => Math.max(-fed, Math.min(fed, Es * eps(y)));
      const al = 2 * Math.acos(Math.max(-1, Math.min(1, (R - lam) / R))), Ac = R * R / 2 * (al - Math.sin(al)), yc = Ac > 1e-12 ? 4 * R * Math.pow(Math.sin(al / 2), 3) / (3 * (al - Math.sin(al))) : 0;
      let N = Ac * fbu, M = Ac * fbu * yc;
      for (let k = 0; k < n; k++) { const ph = 2 * Math.PI * k / n, y = R - rs * Math.cos(ph), f = a1 * sg(y); N += f; M += f * rs * Math.cos(ph); }
      pts.push({ x, N, M });
    }
    return pts;
  }
  function poteauNMcirc(o) {
    const N = o.N, fcd = (o.acc == null ? .85 : o.acc) * o.fc / (o.gb || 1.5), fyd = o.fe / (o.gs || 1.15), D = o.D, Ac = Math.PI * D * D / 4, Es = 2e5, M0 = Math.hypot(o.Ma || 0, o.Mb || 0), l0 = Math.max(o.l0a || 0, o.l0b || 0);
    const lamLim = N > 0 ? 20 * .7 * 1.1 * .7 / Math.sqrt(Math.max(N / 1000 / (Ac * fcd), .01)) : 0, lam = l0 / (D / 4);
    const ex = As => {
      const emin = Math.max(D / 30, .02), e0 = M0 / N, ei = o.ec ? l0 / 400 : 0; let e2 = 0;
      if (o.ec && lam > lamLim) { const d = D - o.ds, om = As / 1e4 * fyd / (Ac * fcd), nu = 1 + om, nn = N / 1000 / (Ac * fcd), Kr = Math.max(0, Math.min(1, (nu - nn) / (nu - .4))); e2 = Kr * (fyd / Es) / (.45 * d) * l0 * l0 / 10; }
      else if (!o.ec && lam > 25) { const al = o.alpha == null ? 1 : o.alpha; e2 = 3 * l0 * l0 * (2 + al * 2) / (1e4 * D); }
      const e = Math.max(e0 + ei, emin) + e2; return { lam, emin, e0, ei, e2, e, Med: N * e };
    };
    const evalAs = (As, n) => { const E = ex(As), C = courbeNMcirc(o, n, As / 1e4), MR = momentResistant(C, N); return { ok: MR >= E.Med && MR > 0, ratio: MR > 0 ? E.Med / MR : Infinity, E: [E], C: [C], MR: [MR], a: 1, NRd: (Ac * fcd + As / 1e4 * fyd) * 1000 }; };
    const B = Ac * 1e4, Amin = Math.max(.002 * B, o.ec ? .1 * N / 1000 / fyd * 1e4 : 0), Amax = (o.ec ? .04 : .05) * B;
    if (!(N > 0)) return { ok: false, err: "Effort normal de compression nul ou négatif.", Amin, Amax, lamLim };
    if (o.As != null) { const r = evalAs(o.As, o.k || 8); return Object.assign(r, { As: o.As, Amin, Amax, lamLim, lam: [lam] }); }
    let hi = Amax, r = evalAs(hi, 12);
    if (!r.ok) return Object.assign(r, { ok: false, As: Infinity, Amin, Amax, lamLim, err: "Section insuffisante même avec " + (o.ec ? "4" : "5") + " % d'acier : augmenter le diamètre ou fc28." });
    let lo = 0; for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (evalAs(m, 12).ok) hi = m; else lo = m; }
    const As = Math.max(hi, Amin), f = evalAs(As, 12);
    return Object.assign(f, { ok: true, As, AsCalc: hi, Amin, Amax, lamLim, lam: [lam] });
  }

  /* ====================================================================== poutre continue : contrôle / extension par éléments finis */
  /* o : { Ls[], b, h (m), fc, G[], Q[] (kN/m par travée), sp:[{n:"G"|"Q", s, t:"p"|"u", a, v, c}], gG, gQ, tass:[mm par appui], ksup:[kN/m par appui, 0 = rigide] }
     Retourne { Mt[], Ma[], V[], R[], base:{…sans tassement}, avecTass:{Mt,Ma,V,R}|null }.  Chargements alternés : toutes les combinaisons de travées chargées en Q. */
  function poutreContinueFE(o) {
    const Ls = o.Ls, n = Ls.length, E = Ecm(o.fc) * 1000, A = o.b * o.h, I = o.b * Math.pow(o.h, 3) / 12, gG = o.gG || 1.35, gQ = o.gQ || 1.5;
    const nodes = [{ x: 0, y: 0 }]; Ls.forEach(L => nodes.push({ x: nodes[nodes.length - 1].x + L, y: 0 }));
    const members = Ls.map((_, i) => ({ i, j: i + 1, E, A, I }));
    const supports = nodes.map((_, i) => ({ n: i, ux: i === 0 ? true : undefined, uy: (o.ksup && o.ksup[i] > 0) ? o.ksup[i] : true }));
    const fr = frame({ nodes, members, supports });
    const items = (c, sp) => { const out = []; (o[c] || []).forEach((w, i) => { if (w > 0) out.push({ m: i, type: "dist", dir: "Y", q1: -w }); }); (o.sp || []).forEach(x => { if (x.n !== c || x.s >= n) return; const L = Ls[x.s], a = Math.min(x.a, L);
      if (x.t === "p") out.push({ m: x.s, type: "point", dir: "Y", P: -x.v, a }); else out.push({ m: x.s, type: "dist", dir: "Y", q1: -x.v, a, b: Math.min(a + x.c, L) }); }); return out; };
    const cases = { G: fr.solveCase({ members: items("G") }) }; const names = [];
    const dedupQ = i => { const out = []; if ((o.Q || [])[i] > 0) out.push({ m: i, type: "dist", dir: "Y", q1: -o.Q[i] }); (o.sp || []).forEach(x => { if (x.n !== "Q" || x.s !== i) return; const L = Ls[i], a = Math.min(x.a, L); out.push(x.t === "p" ? { m: i, type: "point", dir: "Y", P: -x.v, a } : { m: i, type: "dist", dir: "Y", q1: -x.v, a, b: Math.min(a + x.c, L) }); }); return out; };
    for (let i = 0; i < n; i++) { cases["Q" + i] = fr.solveCase({ members: dedupQ(i) }); names.push("Q" + i); }
    const subsets = []; const nn = Math.min(n, 8);
    for (let mask = 1; mask < (1 << nn); mask++) { const f = { G: gG }; for (let i = 0; i < nn; i++) if (mask & (1 << i)) f["Q" + i] = gQ; subsets.push({ id: "ELU Q" + mask.toString(2), f }); }
    if (n > nn) { const f = { G: gG }; for (let i = 0; i < n; i++) f["Q" + i] = gQ; subsets.push({ id: "ELU tout", f }); }
    const reduce = (env, extra) => {
      const Mt = [], Ma = [], V = [];
      env.barres.forEach((b, s) => { Mt.push(Math.max(0, ...b.Mmax)); V.push(Math.max(...b.Vmax.map(Math.abs), ...b.Vmin.map(Math.abs))); });
      for (let j = 1; j < n; j++) Ma.push(Math.max(0, -Math.min(env.barres[j - 1].Mmin[env.barres[j - 1].Mmin.length - 1], env.barres[j].Mmin[0])));
      const Rr = nodes.map((_, i) => (env.R[3 * i + 1] ? env.R[3 * i + 1].max : 0));
      return { Mt, Ma, V, R: Rr };
    };
    const base = reduce(enveloppe(fr, cases, subsets, 20));
    let avecTass = null;
    if ((o.tass || []).some(t => t)) {
      cases.D = fr.solveCase({ settle: nodes.map((_, i) => ({ n: i, dy: -((o.tass || [])[i] || 0) / 1000 })) });
      avecTass = reduce(enveloppe(fr, cases, subsets.map(c => ({ id: c.id + "+D", f: Object.assign({}, c.f, { D: 1 }) })).concat(subsets.map(c => ({ id: c.id + "−D", f: Object.assign({}, c.f, { D: -1 }) }))), 20));
    }
    return Object.assign({}, base, { base, avecTass, fr, cases });
  }

  /* ====================================================================== EN 1998-1 : spectres */
  const SOLS = {
    1: { A: [1, .15, .4, 2], B: [1.2, .15, .5, 2], C: [1.15, .2, .6, 2], D: [1.35, .2, .8, 2], E: [1.4, .15, .5, 2] },
    2: { A: [1, .05, .25, 1.2], B: [1.35, .05, .25, 1.2], C: [1.5, .1, .25, 1.2], D: [1.8, .1, .3, 1.2], E: [1.6, .05, .25, 1.2] }
  };
  /* p : { ag (m/s², déjà γI·agR), type:1|2, sol:"A".."E", q, xi (%) , beta:.2 } */
  function spectre(p) {
    const t = (SOLS[p.type] || SOLS[1])[p.sol || "B"] || SOLS[1].B, S = t[0], TB = t[1], TC = t[2], TD = t[3], ag = p.ag, q = p.q || 1, beta = p.beta == null ? .2 : p.beta,
      eta = Math.max(Math.sqrt(10 / (5 + (p.xi == null ? 5 : p.xi))), .55);
    const Se = T => T <= TB ? ag * S * (1 + T / TB * (eta * 2.5 - 1)) : T <= TC ? ag * S * eta * 2.5 : T <= TD ? ag * S * eta * 2.5 * TC / T : ag * S * eta * 2.5 * TC * TD / (T * T);
    const Sd = T => { let v; if (T <= TB) v = ag * S * (2 / 3 + T / TB * (2.5 / q - 2 / 3)); else if (T <= TC) v = ag * S * 2.5 / q; else if (T <= TD) v = Math.max(ag * S * 2.5 / q * TC / T, beta * ag); else v = Math.max(ag * S * 2.5 / q * TC * TD / (T * T), beta * ag); return v; };
    return { S, TB, TC, TD, eta, Se, Sd, ag, q };
  }

  /* ====================================================================== analyse modale */
  /* masses : [{n, mx, my}] tonnes (kN·s²/m) ; la condensation statique élimine les ddl non massifs (rotations, ddl sans masse).
     Retourne { modes:[{k, omega, f, T, phi:{dof:valeur}, gx, gy, mex, mey, phiFull}], Mx, My (masses totales), nm } */
  function modale(fr, masses, nModes) {
    const mdof = new Map();
    masses.forEach(m => { [[3 * m.n, m.mx], [3 * m.n + 1, m.my]].forEach(([d, v]) => { if (v > 0 && !fr.fixed[d]) mdof.set(d, (mdof.get(d) || 0) + v); }); });
    const a = [...mdof.keys()].sort((x, y) => x - y);
    if (!a.length) throw new Error("Aucune masse sur un ddl libre : analyse modale impossible.");
    const b = fr.freeD.filter(d => !mdof.has(d));
    const Kfull = (i, j) => fr.K[i][j] + (i === j ? fr.spr[i] : 0);
    const Kaa = a.map(i => a.map(j => Kfull(i, j)));
    let Kred = Kaa, Tmat = null;
    if (b.length) {
      const Kbb = b.map(i => b.map(j => Kfull(i, j))), lub = luFactor(Kbb);
      /* X = Kbb⁻¹ Kba  (colonne par colonne) */
      const cols = a.map(j => Array.from(luSolve(lub, b.map(i => Kfull(i, j)))));
      Tmat = cols; /* Tmat[ja][ib] = X[ib][ja] ; φb = −X φa */
      Kred = a.map((i, ia) => a.map((j, ja) => Kaa[ia][ja] - b.reduce((s, bi, ib) => s + Kfull(i, bi) * cols[ja][ib], 0)));
    }
    const m = a.map(d => mdof.get(d)), na = a.length;
    const S = Kred.map((row, i) => row.map((v, j) => v / Math.sqrt(m[i] * m[j])));
    for (let i = 0; i < na; i++) for (let j = i + 1; j < na; j++) { const s = (S[i][j] + S[j][i]) / 2; S[i][j] = S[j][i] = s; }
    const eg = jacobi(S), nm = Math.min(nModes || na, na), modes = [];
    const Mx = a.reduce((s, d, i) => s + (d % 3 === 0 ? m[i] : 0), 0), My = a.reduce((s, d, i) => s + (d % 3 === 1 ? m[i] : 0), 0);
    let cx = 0, cy = 0;
    for (let k = 0; k < nm; k++) {
      const w2 = eg.vals[k]; if (!(w2 > 0)) continue;
      const phi = eg.vecs[k].map((y, i) => y / Math.sqrt(m[i]));
      const gx = phi.reduce((s, v, i) => s + (a[i] % 3 === 0 ? m[i] * v : 0), 0), gy = phi.reduce((s, v, i) => s + (a[i] % 3 === 1 ? m[i] * v : 0), 0);
      const phiFull = new Float64Array(fr.nd); a.forEach((d, i) => { phiFull[d] = phi[i]; });
      if (b.length) b.forEach((d, ib) => { phiFull[d] = -a.reduce((s, _, ia) => s + Tmat[ia][ib] * phi[ia], 0); });
      const mex = gx * gx, mey = gy * gy; cx += mex; cy += mey;
      modes.push({ k: k + 1, omega: Math.sqrt(w2), f: Math.sqrt(w2) / (2 * Math.PI), T: 2 * Math.PI / Math.sqrt(w2), gx, gy, mex, mey, rx: Mx ? cx / Mx : 0, ry: My ? cy / My : 0, phiFull, phi });
    }
    return { modes, Mx, My, a, m };
  }

  /* Combinaison modale : SRSS si les périodes sont bien séparées (Tj ≤ 0,9 Ti), sinon CQC (ξ en %). vals[k] = effet du mode k. */
  function combinaisonModale(vals, T, xi) {
    const n = vals.length, z = (xi == null ? 5 : xi) / 100; let s = 0, cqc = false;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const r = T[j] / T[i], rho = i === j ? 1 : 8 * z * z * (1 + r) * Math.pow(r, 1.5) / ((1 - r * r) ** 2 + 4 * z * z * r * (1 + r) ** 2);
      s += vals[i] * vals[j] * rho;
      if (i !== j && rho > .02) cqc = true;
    }
    return { v: Math.sqrt(Math.max(s, 0)), methode: cqc ? "CQC" : "SRSS" };
  }

  /* Analyse spectrale d'un modèle de portique : dir "x" (horizontale) ; retourne forces modales, déplacements, cisaillements d'étage.
     floors : [{ nodes:[n...], y }] du bas vers le haut. */
  function spectrale(fr, md, spec, dir, opt) {
    opt = opt || {}; const q = spec.q || 1, d0 = dir === "y" ? 1 : 0, nmodes = md.modes.filter(m => (dir === "y" ? m.mey : m.mex) > 1e-12);
    /* mode retenu : ceux nécessaires pour ≥ 90 % de la masse (et au moins 3 ou tous) */
    const tot = dir === "y" ? md.My : md.Mx; let cum = 0, sel = [];
    for (const m of nmodes) { sel.push(m); cum += dir === "y" ? m.mey : m.mex; if (cum >= .9 * tot && sel.length >= Math.min(3, nmodes.length)) break; }
    /* chaque mode : charges modales Fi = mi φi Γ Sd(T) appliquées statiquement */
    const per = sel.map(mo => {
      const G = dir === "y" ? mo.gy : mo.gx, sd = spec.Sd(mo.T), nodesL = [];
      md.a.forEach((d, i) => { if (d % 3 === d0) nodesL.push({ n: (d - d0) / 3, [d0 === 0 ? "fx" : "fy"]: md.m[i] * mo.phi[i] * G * sd }); });
      const res = fr.solveCase({ nodes: nodesL });
      const Vb = nodesL.reduce((s, x) => s + (x.fx || x.fy || 0), 0);
      return { mode: mo, sd, G, Fnodes: nodesL, res, Vb };
    });
    const T = sel.map(m => m.T);
    return { per, T, sel, cumul: tot ? cum / tot : 0, q, d0, tot };
  }

  /* ====================================================================== portique plan régulier */
  const Ecm = fc => 22000 * Math.pow((fc + 8) / 10, .3);
  /* p : { ns, nb, L, h, bc, hc (poteau, cm), bp, hp (poutre, cm), fc, G, Q, pp (1 = poids propre), Wx (kN/étage), base:"enc"|"art",
           ksol (kN/m ressort horizontal, 0 = aucun), tass (mm tassement au dernier appui), psiE, ... } */
  function portique(p) {
    const o = Object.assign({ ns: 3, nb: 2, L: 5, h: 3.2, bc: 30, hc: 30, bp: 25, hp: 50, fc: 25, G: 15, Q: 8, pp: 1, Wx: 0, base: "enc", diaph: 1, cat: "B", ksol: 0, tass: 0, rho: 25 }, p);
    const ns = Math.min(20, Math.max(1, Math.round(o.ns))), nb = Math.min(10, Math.max(1, Math.round(o.nb))), E = Ecm(o.fc) * 1000, nodes = [], members = [], idx = (i, j) => j * (nb + 1) + i;
    for (let j = 0; j <= ns; j++) for (let i = 0; i <= nb; i++) nodes.push({ x: i * o.L, y: j * o.h });
    const Ac = o.bc * o.hc / 1e4, Ic = o.bc * Math.pow(o.hc, 3) / 12 / 1e8, Ap = o.bp * o.hp / 1e4, Ip = o.bp * Math.pow(o.hp, 3) / 12 / 1e8, kd = o.diaph ? 1e3 : 1;
    const cols = [], beams = [];
    for (let j = 0; j < ns; j++) for (let i = 0; i <= nb; i++) { cols.push(members.length); members.push({ i: idx(i, j), j: idx(i, j + 1), E, A: Ac, I: Ic, type: "c", niv: j + 1, ax: i }); }
    for (let j = 1; j <= ns; j++) for (let i = 0; i < nb; i++) { beams.push(members.length); members.push({ i: idx(i, j), j: idx(i + 1, j), E, A: Ap * kd, I: Ip, type: "p", niv: j, ax: i }); }
    const supports = []; for (let i = 0; i <= nb; i++) supports.push({ n: idx(i, 0), ux: o.ksol > 0 ? o.ksol : true, uy: true, rz: o.base === "enc" ? true : false, dy: i === nb ? -o.tass / 1000 : 0 });
    const fr = frame({ nodes, members, supports }), gp = o.pp ? o.rho * Ap : 0, gc = o.pp ? o.rho * Ac : 0;
    const colW = []; if (o.pp) cols.forEach(m => { const L = Math.hypot(nodes[members[m].j].x - nodes[members[m].i].x, nodes[members[m].j].y - nodes[members[m].i].y); colW.push({ n: members[m].i, fy: -gc * L / 2 }, { n: members[m].j, fy: -gc * L / 2 }); });
    const cases = {
      G: fr.solveCase({ members: beams.map(m => ({ m, type: "dist", dir: "Y", q1: -(o.G + gp) })), nodes: colW }),
      Q: fr.solveCase({ members: beams.map(m => ({ m, type: "dist", dir: "Y", q1: -o.Q })) })
    };
    if (o.Wx) cases.W = fr.solveCase({ nodes: Array.from({ length: ns }, (_, j) => ({ n: idx(0, j + 1), fx: o.Wx })) });
    return { o, fr, nodes, members, cols, beams, cases, idx, ns, nb, E, Ac, Ic, Ap, Ip, gp, gc };
  }


  /* ====================================================================== analyse complète d'un portique plan */
  const SOLK = { 1: "A", 2: "B", 3: "C", 4: "D", 5: "E" };
  /* p : paramètres de portique() + { cat, ag (agR m/s²), gI, tsp, sol (1..5), qf, seis (1/0), psiE, dlim, nu, wdl (limite dérive vent = h/…) } */
  function analysePortique(p) {
    const o0 = Object.assign({ cat: "B", ag: 1.5, gI: 1, tsp: 1, sol: 2, qf: 3, seis: 1, dlim: .005, nu: .5, wlim: 300 }, p), pq = portique(o0), o = Object.assign({}, o0, pq.o);
    const catKey = typeof o.cat === "number" ? ({ 1: "A", 2: "B", 3: "C", 4: "D", 5: "E", 6: "H" })[o.cat] || "B" : o.cat;
    const fr = pq.fr, ns = pq.ns, nb = pq.nb, cases = Object.assign({}, pq.cases), idx = pq.idx;
    const acts = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: catKey }];
    if (o.Wx > 0) { acts.push({ n: "W+", type: "W", group: "W" }, { n: "W-", type: "W", group: "W" }); cases["W+"] = cases.W; cases["W-"] = fr.solveCase({ nodes: Array.from({ length: ns }, (_, j) => ({ n: idx(0, j + 1), fx: -o.Wx })) }); delete cases.W; }
    const combos = combinaisons(acts, { norme: o.norme || "EC", sism: false, accid: false });
    const elu = combos.filter(c => c.famille === "ELU"), els = combos.filter(c => c.famille === "ELS-CAR");
    const env = enveloppe(fr, cases, elu, 20), envS = enveloppe(fr, cases, els, 20);
    const psi2 = o.psiE != null ? o.psiE : (PSI[catKey] || PSI.B).p[2];
    const L = o.L, h = o.h, H = ns * h, A = {};
    /* ---- dimensionnement : valeurs extrêmes par famille d'éléments ---- */
    const ext = { poutre: { Mt: 0, Ma: 0, V: 0, cMt: "", cMa: "", cV: "", k: -1 }, poteau: { N: 0, M: 0, Nc: "", Mc: "", k: -1, kN: -1 } };
    pq.beams.forEach(k => { const b = env.barres[k]; b.x.forEach((x, i) => {
      if (b.Mmax[i] > ext.poutre.Mt) { ext.poutre.Mt = b.Mmax[i]; ext.poutre.cMt = b.cMmax[i]; ext.poutre.kt = k; }
      if (-b.Mmin[i] > ext.poutre.Ma) { ext.poutre.Ma = -b.Mmin[i]; ext.poutre.cMa = b.cMmin[i]; ext.poutre.ka = k; }
      const v = Math.max(Math.abs(b.Vmax[i]), Math.abs(b.Vmin[i])); if (v > ext.poutre.V) { ext.poutre.V = v; ext.poutre.cV = Math.abs(b.Vmax[i]) >= Math.abs(b.Vmin[i]) ? b.cVmax[i] : b.cVmin[i]; ext.poutre.kV = k; } }); });
    pq.cols.forEach(k => { const b = env.barres[k]; b.x.forEach((x, i) => {
      const n = -b.Nmin[i]; if (n > ext.poteau.N) { ext.poteau.N = n; ext.poteau.Nc = b.cNmin[i]; ext.poteau.kN = k; }
      const m = Math.max(Math.abs(b.Mmax[i]), Math.abs(b.Mmin[i])); if (m > ext.poteau.M) { ext.poteau.M = m; ext.poteau.Mc = Math.abs(b.Mmax[i]) >= Math.abs(b.Mmin[i]) ? b.cMmax[i] : b.cMmin[i]; ext.poteau.k = k; } }); });
    const reac = []; for (let i = 0; i <= nb; i++) { const d = 3 * idx(i, 0); reac.push({ i, Ry: env.R[d + 1] ? env.R[d + 1].max : 0, Rx: env.R[d] ? env.R[d].max : 0, Rxmin: env.R[d] ? env.R[d].min : 0, M: env.R[d + 2] ? env.R[d + 2].max : 0, Mmin: env.R[d + 2] ? env.R[d + 2].min : 0 }); }
    /* ---- ELS : flèche des poutres (caractéristique) ---- */
    let vmin = 0, kv = -1; pq.beams.forEach(k => { const b = envS.barres[k]; const m = Math.min(...b.vmin); if (m < vmin) { vmin = m; kv = k; } });
    /* flèche relative à la corde (déplacements nodaux verticaux de la combinaison déduits), au pire de toutes les combinaisons ELS */
    let fRel = 0;
    pq.beams.forEach(k => { const m = fr.model.members[k];
      els.forEach(cb => { const ks = Object.keys(cb.f).filter(q => cases[q]), spec = ks.map(q => ({ c: cases[q], f: cb.f[q] })), d = effortsBarre(fr, k, spec, 20),
        ui = ks.reduce((s, q) => s + cb.f[q] * cases[q].u[3 * m.i + 1], 0), uj = ks.reduce((s, q) => s + cb.f[q] * cases[q].u[3 * m.j + 1], 0);
        d.x.forEach((x, i) => { const f = d.v[i] - (ui + (uj - ui) * x / d.L); if (f < fRel) fRel = f; }); }); });
    /* ---- vent : dérive d'étage ---- */
    let dW = null;
    if (o.Wx > 0) { const c = cases["W+"], dr = []; for (let j = 1; j <= ns; j++) dr.push(Math.abs(c.u[3 * idx(0, j)] - (j > 1 ? c.u[3 * idx(0, j - 1)] : 0))); dW = { dr, max: Math.max(...dr), top: Math.abs(c.u[3 * idx(0, ns)]) }; }
    /* ---- masses et analyse modale ---- */
    const gB = o.pp ? o.rho * pq.Ap : 0, wl = (o.G + gB + psi2 * o.Q) * nb * L, gcol = o.pp ? o.rho * pq.Ac * h * (nb + 1) : 0, Wf = [];
    for (let j = 1; j <= ns; j++) Wf.push(wl + gcol * (.5 + (j < ns ? .5 : 0)));
    /* diaphragme rigide : une seule masse horizontale par plancher (les autres ddl horizontaux sont condensés) */
    const masses = []; for (let j = 1; j <= ns; j++) masses.push({ n: idx(0, j), mx: Wf[j - 1] / GRAV, my: 0 });
    const md = modale(fr, masses, Math.min(12, masses.length)), Wtot = Wf.reduce((s, x) => s + x, 0);
    const T1 = md.modes[0].T, T1app = .075 * Math.pow(H, .75), seisme = o.seis > 0 && o.ag > 0;
    let sp = null, spc = null, amort = 5;
    if (seisme) {
      const spec = spectre({ ag: o.gI * o.ag, type: o.tsp, sol: SOLK[o.sol] || "B", q: o.qf, xi: amort });
      sp = spectrale(fr, md, spec, "x");
      const nm = sp.per.length, T = sp.T;
      const Vb = combinaisonModale(sp.per.map(q => q.Vb), T, amort);
      /* effort tranchant d'étage et déplacement de chaque étage (CQC) */
      const floorF = sp.per.map(q => { const a = Array(ns).fill(0); q.Fnodes.forEach(nd => { for (let j = 1; j <= ns; j++) for (let i = 0; i <= nb; i++) if (idx(i, j) === nd.n) a[j - 1] += nd.fx || 0; }); return a; });
      const Vst = Array.from({ length: ns }, (_, st) => combinaisonModale(floorF.map(a => { let s = 0; for (let j = st; j < ns; j++) s += a[j]; return s; }), T, amort).v);
      const dFl = Array.from({ length: ns }, (_, j) => combinaisonModale(sp.per.map(q => q.res.u[3 * idx(0, j + 1)]), T, amort).v);
      const dr = dFl.map((d, j) => Math.abs(d - (j ? dFl[j - 1] : 0)) * o.qf), drLim = dr.map(() => o.dlim * h / o.nu);
      /* sensibilité au second ordre θ = Ptot·dr / (Vtot·h) avec Ptot = poids au-dessus et dans l'étage */
      const theta = dr.map((d, st) => { let P = 0; for (let j = st; j < ns; j++) P += Wf[j]; return Vst[st] > 0 ? P * d / (Vst[st] * h) : 0; });
      const lam = T1 <= 2 * spec.TC && ns > 2 ? .85 : 1, Fb = spec.Sd(T1) * Wtot / GRAV * lam;
      spc = { spec, Vb: Vb.v, methode: Vb.methode, Vst, dFl, dr, drLim, theta, Fb, lam, nm, cumul: sp.cumul, T };
      /* efforts sismiques dans les barres : CQC point par point, puis combinaisons G + ψ2·Q ± E */
      const allc = Object.keys(cases).map(c => ({ c: cases[c], f: 0 }));
      spc.barres = fr.model.members.map((_, k) => {
        const xs = stationsOf(fr, k, allc, 20), ctx = { xs, pts: [] };
        const mode = sp.per.map(q => effortsBarre(fr, k, [{ c: q.res, f: 1 }], 20, ctx));
        const comb = key => xs.map((_, i) => combinaisonModale(mode.map(m => m[key][i]), T, amort).v);
        const base = effortsBarre(fr, k, [{ c: cases.G, f: 1 }, { c: cases.Q, f: psi2 }], 20, ctx);
        return { x: xs, Ne: comb("N"), Ve: comb("V"), Me: comb("M"), Nb: base.N, Vb: base.V, Mb: base.M };
      });
      spc.ext = { Mt: 0, Ma: 0, V: 0, Nc: 0, Mcol: 0 };
      pq.beams.forEach(k => { const b = spc.barres[k]; b.x.forEach((_, i) => { spc.ext.Mt = Math.max(spc.ext.Mt, b.Mb[i] + b.Me[i]); spc.ext.Ma = Math.max(spc.ext.Ma, -(b.Mb[i] - b.Me[i])); spc.ext.V = Math.max(spc.ext.V, Math.abs(b.Vb[i]) + b.Ve[i]); }); });
      pq.cols.forEach(k => { const b = spc.barres[k]; b.x.forEach((_, i) => { spc.ext.Nc = Math.max(spc.ext.Nc, -(b.Nb[i]) + b.Ne[i]); spc.ext.Mcol = Math.max(spc.ext.Mcol, Math.abs(b.Mb[i]) + b.Me[i]); }); });
    }
    /* ---- sollicitations de dimensionnement PAR NIVEAU (ELU, ELS caractéristique, séisme) : poutres et poteaux ---- */
    const niv = [];
    for (let j = 1; j <= ns; j++) {
      const n = { j, Mt: 0, Ma: 0, V: 0, MsT: 0, MsA: 0, N: 0, M: 0, Ns: 0, sism: false, cMt: "", cMa: "", cV: "", cN: "", cM: "" };
      pq.beams.forEach(k => { if (members_niv(pq, k) !== j) return; const b = env.barres[k], bs = envS.barres[k];
        b.x.forEach((x, i) => {
          if (b.Mmax[i] > n.Mt) { n.Mt = b.Mmax[i]; n.cMt = b.cMmax[i]; } if (-b.Mmin[i] > n.Ma) { n.Ma = -b.Mmin[i]; n.cMa = b.cMmin[i]; }
          const v = Math.max(Math.abs(b.Vmax[i]), Math.abs(b.Vmin[i])); if (v > n.V) { n.V = v; n.cV = Math.abs(b.Vmax[i]) >= Math.abs(b.Vmin[i]) ? b.cVmax[i] : b.cVmin[i]; }
          n.MsT = Math.max(n.MsT, bs.Mmax[i]); n.MsA = Math.max(n.MsA, -bs.Mmin[i]);
        });
        if (spc) { const q = spc.barres[k]; q.x.forEach((_, i) => {
          if (q.Mb[i] + q.Me[i] > n.Mt) { n.Mt = q.Mb[i] + q.Me[i]; n.cMt = "SISM"; n.sism = true; } if (-(q.Mb[i] - q.Me[i]) > n.Ma) { n.Ma = -(q.Mb[i] - q.Me[i]); n.cMa = "SISM"; n.sism = true; }
          const v = Math.abs(q.Vb[i]) + q.Ve[i]; if (v > n.V) { n.V = v; n.cV = "SISM"; n.sism = true; } }); }
      });
      pq.cols.forEach(k => { if (members_niv(pq, k) !== j) return; const b = env.barres[k], bs = envS.barres[k];
        b.x.forEach((x, i) => {
          if (-b.Nmin[i] > n.N) { n.N = -b.Nmin[i]; n.cN = b.cNmin[i]; }
          const m = Math.max(Math.abs(b.Mmax[i]), Math.abs(b.Mmin[i])); if (m > n.M) { n.M = m; n.cM = Math.abs(b.Mmax[i]) >= Math.abs(b.Mmin[i]) ? b.cMmax[i] : b.cMmin[i]; }
          n.Ns = Math.max(n.Ns, -bs.Nmin[i]);
        });
        if (spc) { const q = spc.barres[k]; q.x.forEach((_, i) => {
          if (-q.Nb[i] + q.Ne[i] > n.N) { n.N = -q.Nb[i] + q.Ne[i]; n.cN = "SISM"; n.sism = true; }
          if (Math.abs(q.Mb[i]) + q.Me[i] > n.M) { n.M = Math.abs(q.Mb[i]) + q.Me[i]; n.cM = "SISM"; n.sism = true; } }); }
      });
      niv.push(n);
    }
    /* ---- transfert vers les modules Poutre / Poteau : valeurs caractéristiques G et Q de la barre dimensionnante ---- */
    const kc = ext.poteau.kN >= 0 ? ext.poteau.kN : pq.cols[0], eg = effortsBarre(fr, kc, [{ c: cases.G, f: 1 }], 10), eq = effortsBarre(fr, kc, [{ c: cases.Q, f: 1 }], 10);
    const mx = a => a.reduce((m, v) => Math.abs(v) > Math.abs(m) ? v : m, 0), tr = { Ng: -Math.min(...eg.N), Nq: -Math.min(...eq.N), Mg: Math.abs(mx(eg.M)), Mq: Math.abs(mx(eq.M)), H: h };
    return { niv, o, pq, fr, cases, combos, elu, els, env, envS, ext, reac, vmin, fRel, dW, md, T1, T1app, Wtot, Wf, psi2, seisme, spc, tr, H, catKey };
  }

  const members_niv = (pq, k) => pq.members[k].niv;

  /* Mise en forme française du résultat (lignes, messages, formules) pour l'écran « Portique 2D ». */
  function resumePortique(a) {
    const o = a.o, rows = [], msgs = [], F = [], f = (x, d = 2) => f2(x, d), u = (t, m, r) => msgs.push([t, m, r]);
    const ex = a.ext, L = o.L;
    rows.push(["Modèle", `${a.pq.ns} étage(s) × ${a.pq.nb} travée(s) · ${a.fr.nn} nœuds · ${a.fr.model.members.length} barres · ${a.fr.freeD.length} ddl`]);
    rows.push(["Combinaisons ELU / ELS carac. générées", `${a.elu.length} / ${a.els.length}`]);
    rows.push(["Poutres : M travée max (ELU)", `${f(ex.poutre.Mt)} kN.m  (${ex.poutre.cMt || "—"})`]);
    rows.push(["Poutres : M appui max (ELU)", `${f(ex.poutre.Ma)} kN.m  (${ex.poutre.cMa || "—"})`]);
    rows.push(["Poutres : V max (ELU)", `${f(ex.poutre.V)} kN  (${ex.poutre.cV || "—"})`]);
    rows.push(["Poteaux : N max compression (ELU)", `${f(ex.poteau.N)} kN  (${ex.poteau.Nc || "—"})`]);
    rows.push(["Poteaux : |M| max (ELU)", `${f(ex.poteau.M)} kN.m  (${ex.poteau.Mc || "—"})`]);
    rows.push(["Flèche des poutres (ELS caract., /corde)", `${f(Math.abs(a.fRel) * 1000, 1)} mm  (L/${f(L / Math.max(Math.abs(a.fRel), 1e-9), 0)})`]);
    const Rt = a.reac.reduce((s, r) => s + r.Ry, 0);
    rows.push(["Réaction verticale totale à la base (ELU max)", `${f(Rt, 0)} kN`]);
    rows.push(["Période fondamentale T1 (valeurs propres)", `${f(a.T1, 3)} s  (Ct·H^0,75 = ${f(a.T1app, 3)} s)`]);
    rows.push(["Périodes T1 / T2 / T3", a.md.modes.slice(0, 3).map(m => f(m.T, 3)).join(" / ") + " s"]);
    rows.push(["Masse modale effective cumulée (x), 3 premiers modes", `${f((a.md.modes[Math.min(2, a.md.modes.length - 1)].rx) * 100, 1)} %`]);
    rows.push(["Poids sismique W = Σ(G + ψ2·Q)", `${f(a.Wtot, 0)} kN`]);
    if (a.dW) rows.push(["Vent : dérive d'étage max / déplacement en tête (ELS)", `${f(a.dW.max * 1000, 1)} mm (h/${f(o.h / Math.max(a.dW.max, 1e-9), 0)}) / ${f(a.dW.top * 1000, 1)} mm (H/${f(a.H / Math.max(a.dW.top, 1e-9), 0)})`]);
    if (a.spc) {
      const s = a.spc;
      rows.push(["Séisme : spectre de calcul (ag·S, TC, q)", `${f(s.spec.ag * s.spec.S, 2)} m/s² · TC ${f(s.spec.TC, 2)} s · q ${f(s.spec.q, 2)}`]);
      rows.push(["Séisme : modes retenus / masse cumulée / méthode", `${s.nm} / ${f(s.cumul * 100, 1)} % / ${s.methode}`]);
      rows.push(["Séisme : effort tranchant à la base Vb (modal)", `${f(s.Vb, 0)} kN  (${f(s.Vb / a.Wtot * 100, 1)} % de W)`]);
      rows.push(["Séisme : Fb forces latérales (EN 1998-1 4.3.3.2)", `${f(s.Fb, 0)} kN  (Vb modal / Fb = ${f(s.Vb / s.Fb, 2)})`]);
      rows.push(["Séisme : dérive d'étage max dr (= q·de)", `${f(Math.max(...s.dr) * 1000, 1)} mm  (limite ${f(Math.min(...s.drLim) * 1000, 1)} mm)`]);
      rows.push(["Séisme : θ max (second ordre)", f(Math.max(...s.theta), 3)]);
      rows.push(["Séisme : M travée / appui, V poutres (G+ψ2Q ± E)", `${f(s.ext.Mt)} / ${f(s.ext.Ma)} kN.m · ${f(s.ext.V)} kN`]);
      rows.push(["Séisme : N / M max des poteaux (G+ψ2Q ± E)", `${f(s.ext.Nc)} kN · ${f(s.ext.Mcol)} kN.m`]);
    }
    /* messages */
    if (a.fRel && Math.abs(a.fRel) > L / 250) u("erreur", `Flèche ${f(Math.abs(a.fRel) * 1000, 1)} mm > L/250 = ${f(L / .25, 0)} mm : augmenter la hauteur des poutres ou réduire la portée.`, "EN 1992-1-1 7.4.1(4)");
    else if (a.fRel && Math.abs(a.fRel) > L / 500) u("alerte", `Flèche > L/500 : vérifier la part nuisible après cloisons (flèche quasi-permanente avec fluage, module 7.4 / BAEL B.6.5).`, "EN 1992-1-1 7.4.1(5)");
    if (a.dW && a.dW.max > o.h / o.wlim) u("alerte", `Dérive d'étage sous vent ${f(a.dW.max * 1000, 1)} mm > h/${o.wlim} : à confronter au critère du marché ou de l'annexe nationale.`);
    if (a.T1 > 4 * (a.spc ? a.spc.spec.TC : .5) && a.seisme) u("alerte", "T1 > 4·TC : longue période, vérifier la stabilité d'ensemble et les effets du second ordre.", "EN 1998-1 4.3.3.2.1");
    if (a.seisme) {
      const s = a.spc;
      if (s.cumul < .9) u("alerte", `Masse modale cumulée ${f(s.cumul * 100, 1)} % < 90 % : augmenter le nombre de modes.`, "EN 1998-1 4.3.3.3.1(3)");
      const th = Math.max(...s.theta);
      if (th > .2) u("erreur", `θ = ${f(th, 3)} > 0,2 : structure trop souple, inacceptable.`, "EN 1998-1 4.4.2.2(2)");
      else if (th > .1) u("alerte", `0,1 < θ = ${f(th, 3)} ≤ 0,2 : majorer les effets sismiques par 1/(1 − θ) = ${f(1 / (1 - th), 2)}.`, "EN 1998-1 4.4.2.2(3)");
      if (s.dr.some((d, i) => d > s.drLim[i])) u("erreur", `Dérive d'étage sismique ${f(Math.max(...s.dr) * 1000, 1)} mm > ${f(Math.min(...s.drLim) * 1000, 1)} mm : augmenter la rigidité (poteaux).`, "EN 1998-1 4.4.3.2");
      if (s.Vb / s.Fb < .85) u("info", "Vb modal < 0,85·Fb : cohérent si la masse participante est inférieure à 85 % (EN 1998-1 permet de ne pas tenir compte de λ).");
      u("alerte", "Séisme : analyse modale plane, diaphragme rigide, masses concentrées aux nœuds, excentricité accidentelle et torsion non traitées. agR vient du zonage officiel du site.", "EN 1998-1 4.3.3.3");
    }
    u("info", "Barres de Euler-Bernoulli (déformations d'effort tranchant négligées), traverses axialement rigides (diaphragme), analyse linéaire élastique, fissuration du béton non prise en compte (section brute).");
    u("alerte", "Rigidité des sections brute : pour le séisme, EN 1998-1 4.3.1(7) autorise 50 % de la rigidité en flexion des éléments fissurés ; à appliquer si nécessaire.", "EN 1998-1 4.3.1(7)");
    u("info", "Valeurs d'envoi vers les modules Poutre et Poteau : utiliser les boutons sous les résultats.");
    F.push("Combinaisons : ELU 1,35·G + 1,5·Q1 + Σ1,5·ψ0,i·Qi (EN 1990 6.10) ; ELS caractéristique G + Q1 + Σψ0,i·Qi");
    F.push("Éléments finis : barres à 3 ddl/nœud, K = Σ TᵀkT, charges réparties par forces nodales cohérentes (fonctions de forme d'Hermite)");
    F.push("Modes : (K* − ω²M)φ = 0, K* = Kaa − Kab·Kbb⁻¹·Kba (condensation statique), Jacobi sur M^-½K*M^-½");
    F.push("Spectre : Sd(T) = ag·S·[2/3 + T/TB·(2,5/q − 2/3)] … (EN 1998-1 3.2.2.5) ; Fk,i = mi·φi,k·Γk·Sd(Tk) ; CQC : ρ = 8ξ²(1+r)r^1,5 / [(1−r²)² + 4ξ²r(1+r)²]");
    F.push("Second ordre : θ = Ptot·dr / (Vtot·h) ; dr = q·(de,i − de,i−1)");
    return { rows, msgs, F };
  }

  /* Dessin SVG d'un diagramme de portique : kind = "M" | "V" | "N" | "def" ; env = enveloppe ELU (a.env) ou cas {c} ; échelle automatique. */
  function svgPortique(a, kind, sel) {
    const fr = a.fr, mem = fr.model.members, nodes = fr.model.nodes, W = 760, pad = 56;
    const xs = nodes.map(n => n.x), ys = nodes.map(n => n.y), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    const sc = Math.min((W - 2 * pad) / Math.max(x1 - x0, 1), 520 / Math.max(y1 - y0, 1)), Hh = (y1 - y0) * sc + 2 * pad, X = x => pad + (x - x0) * sc, Y = y => Hh - pad - (y - y0) * sc;
    const key = kind === "def" ? "v" : kind, data = kind === "def" ? a.envS : a.env;
    let amp = 1e-9; data.barres.forEach(b => { for (const q of [key + "max", key + "min"]) b[q].forEach(v => { amp = Math.max(amp, Math.abs(v)); }); });
    const size = Math.min(a.o.L, a.o.h) * sc * .3, k = size / amp, out = [`<svg viewBox="0 0 ${W} ${Hh.toFixed(0)}" role="img" aria-label="Diagramme ${kind}" style="width:100%;height:auto;background:#fff;border:1px solid #d5dae1;border-radius:10px">`];
    mem.forEach((m, i) => { const l = `x1="${X(nodes[m.i].x)}" y1="${Y(nodes[m.i].y)}" x2="${X(nodes[m.j].x)}" y2="${Y(nodes[m.j].y)}"`; out.push(`<line ${l} stroke="${sel === i ? "#ff9800" : "#14284b"}" stroke-width="${sel === i ? 4 : 2}"/><line ${l} data-m="${i}" stroke="transparent" stroke-width="14" style="cursor:pointer"/>`); });
    mem.forEach((m, i) => {
      const g = fr.geo[i], b = data.barres[i];
      /* le moment est tracé du côté de la fibre tendue : côté −y local (sagging positif → vers le bas) */
      const side = kind === "M" ? -1 : 1;
      for (const [q, col] of [[key + "max", "#e8590c"], [key + "min", "#1b6fb3"]]) {
        const line = b.x.map((x, j) => { const t = b[q][j] * k * side, px = nodes[m.i].x + g.c * x - g.s * t / sc, py = nodes[m.i].y + g.s * x + g.c * t / sc; return `${X(px).toFixed(1)},${Y(py).toFixed(1)}`; });
        const base = b.x.map(x => `${X(nodes[m.i].x + g.c * x).toFixed(1)},${Y(nodes[m.i].y + g.s * x).toFixed(1)}`).reverse();
        out.push(`<polygon points="${line.join(" ")} ${base.join(" ")}" fill="${col}" fill-opacity=".18" stroke="${col}" stroke-width="1.2"/>`);
      }
    });
    /* valeurs aux extrema de chaque barre (max en orange, min en bleu) avec le signe */
    if (kind !== "def") mem.forEach((m, i) => { const g = fr.geo[i], b = data.barres[i], side = kind === "M" ? -1 : 1, fmt = v => (v < 0 ? "−" : "+") + Math.abs(v).toFixed(kind === "N" ? 0 : 1).replace(".", ",");
      for (const [q, col, pick] of [[key + "max", "#c2410c", 1], [key + "min", "#1b6fb3", -1]]) { let bi = 0; b[q].forEach((v, j) => { if (pick * v > pick * b[q][bi]) bi = j; }); const v = b[q][bi]; if (Math.abs(v) < amp * .12) continue; if (pick === -1 && Math.abs(v - Math.max(...b[key + "max"])) < 1e-6 * Math.max(1, Math.abs(v))) continue;
        const t = v * k * side, px = nodes[m.i].x + g.c * b.x[bi] - g.s * t / sc, py = nodes[m.i].y + g.s * b.x[bi] + g.c * t / sc, tx = X(px) + (g.s !== 0 ? (side * g.s > 0 ? 8 : -8) : 0), ty = Y(py) + (g.s === 0 ? (t * side * -1 >= 0 ? -6 : 13) : 4), txt = fmt(v), w = txt.length * 6 + 6;
        out.push(`<rect x="${(tx - (g.s !== 0 ? (tx > X(px) ? 0 : w) : w / 2)).toFixed(1)}" y="${(ty - 10).toFixed(1)}" width="${w}" height="13" rx="3" fill="#fff" fill-opacity=".9" stroke="${col}" stroke-width=".7"/><text x="${(tx - (g.s !== 0 ? (tx > X(px) ? -w / 2 : w / 2) : 0)).toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" font-size="10" font-weight="700" fill="${col}">${txt}</text>`); } });
    nodes.forEach(n => out.push(`<circle cx="${X(n.x)}" cy="${Y(n.y)}" r="2.5" fill="#14284b"/>`));
    /* cadrage : la fenêtre englobe exactement les diagrammes, les étiquettes et le titre (rien n'est rogné) */
    const body = out.slice(1).join(""); let bx0 = 1e9, bx1 = -1e9, by0 = 1e9, by1 = -1e9; const upd = (x, y) => { if (x < bx0) bx0 = x; if (x > bx1) bx1 = x; if (y < by0) by0 = y; if (y > by1) by1 = y; };
    for (const m of body.matchAll(/points="([^"]+)"/g)) m[1].split(" ").forEach(pt => { const [x, y] = pt.split(",").map(Number); if (isFinite(x) && isFinite(y)) upd(x, y); });
    for (const m of body.matchAll(/<rect x="([-\d.]+)" y="([-\d.]+)" width="([-\d.]+)" height="([-\d.]+)"/g)) { upd(+m[1], +m[2]); upd(+m[1] + +m[3], +m[2] + +m[4]); }
    for (const m of body.matchAll(/<line x1="([-\d.]+)" y1="([-\d.]+)" x2="([-\d.]+)" y2="([-\d.]+)"/g)) { upd(+m[1], +m[2]); upd(+m[3], +m[4]); }
    const vx0 = bx0 - 14, vy0 = by0 - 34, vw = bx1 - bx0 + 28, vh = by1 - by0 + 34 + 16;
    out[0] = out[0].replace(/viewBox="[^"]+"/, `viewBox="${vx0.toFixed(0)} ${vy0.toFixed(0)} ${vw.toFixed(0)} ${vh.toFixed(0)}"`);
    out.push(`<text x="${(vx0 + 10).toFixed(0)}" y="${(vy0 + 18).toFixed(0)}" font-size="12" fill="#5b6779">${({ M: "Moments M (kN.m) — enveloppe ELU", V: "Efforts tranchants V (kN) — enveloppe ELU", N: "Efforts normaux N (kN) — enveloppe ELU", def: "Flèches des barres (mm, repère local) — enveloppe ELS caractéristique" })[kind]} · max ${(amp * (kind === "def" ? 1000 : 1)).toFixed(kind === "def" ? 2 : 0)}</text></svg>`);
    return out.join("");
  }



  /* ====================================================================== portique extrait d'un modèle de bâtiment (axe quelconque) */
  /* m : { xs[] abscisses des axes (m), z[] cotes des planchers (m, z[0] = sol), col[k][i] = {b,h} (m) ou null : poteau du niveau k à l'axe i,
           beams:[{k, t0, t1, b, h, Gs[], Qs[], nom}] poutre(s) continue(s) en tête du niveau k entre axes t0 et t1 (charges linéiques par travée),
           fc, base:"enc"|"art", pp (1/0), cat, Wx (kN par niveau), seis:{on, ag, gI, tsp, sol, q, dlim, nu} }
     Retourne le modèle EF, les enveloppes, les sollicitations par élément et les résultats dynamiques. */
  function analyseModele(m) {
    const o = Object.assign({ fc: 25, base: "enc", pp: 1, rho: 25, cat: "B", Wx: 0, diaph: 1 }, m), E = Ecm(o.fc) * 1000, nodes = [], key = new Map(), members = [], meta = [], nL = o.z.length - 1;
    const nid = (i, L) => { const k = i + ":" + L; if (!key.has(k)) { key.set(k, nodes.length); nodes.push({ x: o.xs[i], y: o.z[L], i, L }); } return key.get(k); };
    const cols = [], beams = [], colW = [], catKey = typeof o.cat === "number" ? ({ 1: "A", 2: "B", 3: "C", 4: "D", 5: "E", 6: "H" })[o.cat] || "B" : o.cat, psi2 = o.psiE != null ? o.psiE : (PSI[catKey] || PSI.B).p[2];
    for (let k = 0; k < nL; k++) for (let i = 0; i < o.xs.length; i++) { const c = o.col[k] && o.col[k][i]; if (!c) continue;
      const a = nid(i, k), b2 = nid(i, k + 1), A = c.b * c.h, I = c.b * Math.pow(c.h, 3) / 12, Lc = o.z[k + 1] - o.z[k];
      cols.push(members.length); meta.push({ type: "c", k, i, nom: `Poteau ${c.nom || i} · niv. ${k + 1}`, b: c.b, h: c.h }); members.push({ i: a, j: b2, E, A, I });
      if (o.pp) { colW.push({ n: a, fy: -o.rho * A * Lc / 2 }, { n: b2, fy: -o.rho * A * Lc / 2 }); } }
    const gB = []; const Wf = Array(nL + 1).fill(0), wBeam = [];
    (o.beams || []).forEach((bm, q) => { const A = bm.b * bm.h, I = bm.b * Math.pow(bm.h, 3) / 12, gp = o.pp ? o.rho * A : 0;
      for (let s = bm.t0; s < bm.t1; s++) { const a = nid(s, bm.k + 1), b2 = nid(s + 1, bm.k + 1), len = o.xs[s + 1] - o.xs[s];
        beams.push(members.length); meta.push({ type: "p", k: bm.k, t: s, nom: `${bm.nom || "Poutre"} · travée ${s - bm.t0 + 1}`, b: bm.b, h: bm.h, q, len });
        members.push({ i: a, j: b2, E, A: A * (o.diaph ? 1e3 : 1), I });
        wBeam.push({ m: members.length - 1, G: (bm.Gs[s - bm.t0] || 0) + gp, Q: bm.Qs[s - bm.t0] || 0, len, L: bm.k + 1 }); } });
    if (!members.length) throw new Error("Aucune barre : ajoutez des poteaux et des poutres sur cet axe.");
    const supports = nodes.map((n, id) => (n.L === 0 ? { n: id, ux: true, uy: true, rz: o.base === "enc" } : null)).filter(Boolean);
    if (!supports.length) throw new Error("Aucun poteau au niveau du sol sur cet axe.");
    const fr = frame({ nodes, members, supports });
    const cases = { G: fr.solveCase({ members: wBeam.map(w => ({ m: w.m, type: "dist", dir: "Y", q1: -w.G })), nodes: colW }), Q: fr.solveCase({ members: wBeam.map(w => ({ m: w.m, type: "dist", dir: "Y", q1: -w.Q })) }) };
    const levelNode = L => { let best = -1; nodes.forEach((n, id) => { if (n.L === L && (best < 0 || n.i < nodes[best].i)) best = id; }); return best; };
    const acts = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: catKey }];
    if (o.Wx > 0) { acts.push({ n: "W+", type: "W", group: "W" }, { n: "W-", type: "W", group: "W" });
      const ln = []; for (let L = 1; L <= nL; L++) { const id = levelNode(L); if (id >= 0) ln.push({ n: id, fx: o.Wx }); }
      cases["W+"] = fr.solveCase({ nodes: ln }); cases["W-"] = fr.solveCase({ nodes: ln.map(x => ({ n: x.n, fx: -x.fx })) }); }
    const combos = combinaisons(acts, { norme: o.norme || "EC", sism: false, accid: false }), elu = combos.filter(c => c.famille === "ELU"), els = combos.filter(c => c.famille === "ELS-CAR");
    const env = enveloppe(fr, cases, elu, 20), envS = enveloppe(fr, cases, els, 20);
    /* sollicitations par élément */
    const elements = meta.map((mt, k) => { const b = env.barres[k], bs = envS.barres[k], last = b.x.length - 1, e = Object.assign({ id: k }, mt);
      e.V = Math.max(...b.Vmax.map(Math.abs), ...b.Vmin.map(Math.abs));
      if (mt.type === "p") { e.Mt = Math.max(0, ...b.Mmax); e.Ma0 = Math.max(0, -b.Mmin[0]); e.Ma1 = Math.max(0, -b.Mmin[last]); e.MsT = Math.max(0, ...bs.Mmax); e.MsA = Math.max(0, -bs.Mmin[0], -bs.Mmin[last]); e.Ma = Math.max(e.Ma0, e.Ma1); e.fl = Math.min(0, ...bs.vmin); }
      else { e.N = Math.max(0, -Math.min(...b.Nmin)); e.Nt = Math.max(0, Math.max(...b.Nmax)); e.M = Math.max(...b.Mmax.map(Math.abs), ...b.Mmin.map(Math.abs)); e.Ns = Math.max(0, -Math.min(...bs.Nmin)); }
      return e; });
    const reac = []; nodes.forEach((n, id) => { if (n.L !== 0) return; const d = 3 * id, g = k => env.R[d + k] || { max: 0, min: 0 }; reac.push({ i: n.i, x: n.x, Ry: g(1).max, Rymin: g(1).min, Rx: g(0).max, Rxmin: g(0).min, M: g(2).max, Mmin: g(2).min }); });
    /* déplacements d'étage sous vent (ELS) */
    let sway = null; if (cases["W+"]) { const lv = []; for (let L = 1; L <= nL; L++) { const id = levelNode(L); if (id >= 0) lv.push({ L, d: Math.abs(cases["W+"].u[3 * id]) }); } sway = lv.map((q, j) => ({ L: q.L, d: q.d, dr: Math.abs(q.d - (j ? lv[j - 1].d : 0)), h: o.z[q.L] - o.z[j ? lv[j - 1].L : 0] })); }
    /* masses et dynamique */
    const masses = []; const fl = [];
    for (let L = 1; L <= nL; L++) { const id = levelNode(L); if (id < 0) continue; let W = 0;
      wBeam.filter(w => w.L === L).forEach(w => { W += (w.G + psi2 * w.Q) * w.len; });
      cols.forEach(c => { const mt = meta[c]; const Lc = o.z[mt.k + 1] - o.z[mt.k], w = o.pp ? o.rho * mt.b * mt.h * Lc : 0; if (mt.k + 1 === L) W += w / 2; if (mt.k === L) W += w / 2; });
      fl.push({ L, id, W }); masses.push({ n: id, mx: W / GRAV, my: 0 }); }
    let md = null, T1 = null, seis = null, Wtot = fl.reduce((s2, x) => s2 + x.W, 0);
    if (masses.length && masses.some(q => q.mx > 0)) {
      try { md = modale(fr, masses, Math.min(10, masses.length)); T1 = md.modes[0].T; } catch (e) { md = null; }
      const sc = o.seis;
      if (md && sc && sc.on && sc.ag > 0) {
        const spec = spectre({ ag: (sc.gI || 1) * sc.ag, type: sc.tsp || 1, sol: SOLK[sc.sol] || "B", q: sc.q || 3, xi: 5 }), sp = spectrale(fr, md, spec, "x"), T = sp.T;
        const Vb = combinaisonModale(sp.per.map(q => q.Vb), T, 5), nf = fl.length;
        const dFl = fl.map(f => combinaisonModale(sp.per.map(q => q.res.u[3 * f.id]), T, 5).v);
        const floorF = sp.per.map(q => fl.map(f => { const nd = q.Fnodes.find(x => x.n === f.id); return nd ? nd.fx || 0 : 0; }));
        const Vst = fl.map((_, st) => combinaisonModale(floorF.map(a => { let s2 = 0; for (let j = st; j < nf; j++) s2 += a[j]; return s2; }), T, 5).v);
        const dr = dFl.map((d, j) => Math.abs(d - (j ? dFl[j - 1] : 0)) * (sc.q || 3)), hs = fl.map((f, j) => o.z[f.L] - o.z[j ? fl[j - 1].L : 0]), lim = hs.map(h => (sc.dlim || .005) * h / (sc.nu || .5));
        const theta = dr.map((d, st) => { let P = 0; for (let j = st; j < nf; j++) P += fl[j].W; return Vst[st] > 0 ? P * d / (Vst[st] * hs[st]) : 0; });
        const lam = md.modes[0].T <= 2 * spec.TC && nf > 2 ? .85 : 1;
        seis = { spec, Vb: Vb.v, methode: Vb.methode, Vst, dr, lim, theta, hs, Fb: spec.Sd(md.modes[0].T) * Wtot / GRAV * lam, cumul: sp.cumul, nm: sp.per.length, floors: fl.map(f => f.L) };
      }
    }
    const spans = (o.beams || []).map(b => o.xs[b.t1] - o.xs[b.t0]), Lmin = Math.min(...meta.filter(q => q.type === "p").map(q => q.len), 5), hmin = Math.min(...o.z.slice(1).map((v, i) => v - o.z[i]));
    return { o: Object.assign({}, o, { L: Lmin, h: hmin }), fr, nodes, members, meta, cases, combos, elu, els, env, envS, elements, reac, sway, md, T1, seis, Wtot, fl };
  }

  /* Écran « Combinaisons d'actions » : effets saisis par action (valeurs ≥ 0), retourne lignes / messages / formules. */
  function resumeCombi(v) {
    const cat = ({ 1: "A", 2: "B", 3: "C", 4: "D", 5: "E", 6: "H" })[v.cat] || "B", acts = [{ n: "G", type: "G" }], val = { G: v.G, Q: v.Q };
    acts.push({ n: "Q", type: "Q", cat });
    if (v.S > 0) { acts.push({ n: "S", type: "S", cat: v.alt ? "S2" : "S" }); val.S = v.S; }
    if (v.W > 0) { acts.push({ n: "W+", type: "W", group: "W" }, { n: "W-", type: "W", group: "W" }); val["W+"] = v.W; val["W-"] = -v.W; }
    if (v.A > 0) { acts.push({ n: "Ad", type: "A" }); val.Ad = v.A; }
    if (v.E > 0) { acts.push({ n: "E", type: "E", dir: "x" }); val.E = v.E; }
    const cb = combinaisons(acts, { norme: v.norme ? "BAEL" : "EC", sixab: !!v.sixab });
    const rows = [], msgs = [], by = {};
    cb.forEach(c => { const x = Object.keys(c.f).reduce((s, k) => s + c.f[k] * (val[k] || 0), 0); (by[c.famille] = by[c.famille] || []).push({ c, x }); });
    const nom = { ELU: "ELU", "ELS-CAR": "ELS caractéristique", "ELS-FREQ": "ELS fréquente", "ELS-QP": "ELS quasi-permanente", ACC: "Accidentelle", SISM: "Sismique" };
    Object.keys(by).forEach(fam => {
      const l = by[fam], mx = l.reduce((m, e) => e.x > m.x ? e : m, l[0]), mn = l.reduce((m, e) => e.x < m.x ? e : m, l[0]);
      rows.push([`${nom[fam] || fam} — dominante (${mx.c.id}${mx.c.tag ? " " + mx.c.tag : ""})`, `${f2(mx.x)}  =  ${mx.c.expr}`]);
      if (l.length > 1 && mn !== mx && mn.x < 0 !== mx.x < 0) rows.push([`${nom[fam] || fam} — minimale (${mn.c.id})`, `${f2(mn.x)}  =  ${mn.c.expr}`]);
    });
    rows.push(["Nombre total de combinaisons", String(cb.length)]);
    const detail = []; cb.forEach(c => detail.push(`${c.id}${c.tag ? " (" + c.tag + ")" : ""} : ${c.expr}  →  ${f2(Object.keys(c.f).reduce((s, k) => s + c.f[k] * (val[k] || 0), 0))}`));
    msgs.push(["info", "Saisissez la même grandeur d'effet pour toutes les actions (moment, effort tranchant, réaction…), en valeur positive pour G, Q, S, Ad et E ; le vent est automatiquement pris dans les deux sens (W+ / W−) et le séisme en ±E."]);
    msgs.push(["info", `Coefficients ψ0 / ψ1 / ψ2 de la catégorie ${cat} : ${(PSI[cat] || PSI.B).p.join(" / ")} (EN 1990 tableau A1.1) ; neige : ${PSI.S.p.join(" / ")} ; vent : ${PSI.W.p.join(" / ")}.`, "EN 1990 A1.1"]);
    if (v.norme) msgs.push(["alerte", "BAEL : combinaisons 1,35·G + 1,5·Q1 + Σ1,3·ψ0i·Qi (A.3.3,21) ; le vent et la neige ont leurs propres coefficients dans les règles NV/N84 non reprises ici.", "BAEL A.3.3,21"]);
    msgs.push(["alerte", "Charges de neige et de vent : valeurs de l'annexe nationale du site. Combinaisons ELU STR/GEO (approche 2 pour GEO non traitée).", "EN 1990 6.4.3.2"]);
    return { rows, msgs, F: detail };
  }


  /* ====================================================================== poutre solidaire de poteaux (portique à une file) */
  /* o : { Ls[], b, h, fc, cb, ch (poteaux, m), Hb, Ha (hauteurs sous / au-dessus de la poutre, m, 0 = absent), base:"enc"|"art", top:"enc"|"art",
           braced (1 = nœuds maintenus latéralement), ldG[s] = [{t:"u",w}|{t:"p",a,P}], ldQ[s], gG, gQ }
     Retourne, pour chaque cas élémentaire, les moments et tranchants de la poutre aux NS+1 points de chaque travée (mêmes abscisses que la poutre continue),
     les réactions verticales, l'enveloppe ELU des poteaux et le modèle EF pour le dessin. */
  function poutrePortiqueFE(o) {
    const Ls = o.Ls, n = Ls.length, E = Ecm(o.fc) * 1000, A = o.b * o.h, I = o.b * Math.pow(o.h, 3) / 12, Ac = o.cb * o.ch, Ic = o.cb * Math.pow(o.ch, 3) / 12, gG = o.gG || 1.35, gQ = o.gQ || 1.5;
    const Hb = o.Hb > 0 ? o.Hb : 0, Ha = o.Ha > 0 ? o.Ha : 0, NSS = 20;
    const nodes = [{ x: 0, y: 0 }]; Ls.forEach(L => nodes.push({ x: nodes[nodes.length - 1].x + L, y: 0 }));
    const members = Ls.map((_, i) => ({ i, j: i + 1, E, A, I })), supports = [], cols = [];
    for (let i = 0; i <= n; i++) {
      if (o.braced !== 0 || (!Hb && !Ha)) supports.push({ n: i, ux: i === 0 || o.braced !== 0 ? true : undefined, uy: (!Hb && !Ha) ? true : undefined });
      if (Hb) { const nb = nodes.length; nodes.push({ x: nodes[i].x, y: -Hb }); cols.push({ k: members.length, i, pos: "b", H: Hb }); members.push({ i: nb, j: i, E, A: Ac, I: Ic }); supports.push({ n: nb, ux: true, uy: true, rz: o.base !== "art" }); }
      if (Ha) { const nt = nodes.length; nodes.push({ x: nodes[i].x, y: Ha }); cols.push({ k: members.length, i, pos: "t", H: Ha }); members.push({ i, j: nt, E, A: Ac, I: Ic }); supports.push({ n: nt, ux: true, uy: true, rz: o.top !== "art" }); }
    }
    /* un même nœud peut recevoir deux entrées de appui : on fusionne */
    const sm = new Map(); supports.forEach(q => { const e = sm.get(q.n) || { n: q.n }; Object.keys(q).forEach(k => { if (q[k] !== undefined) e[k] = q[k]; }); sm.set(q.n, e); });
    const fr = frame({ nodes, members, supports: [...sm.values()] });
    const it = ld => { const out = []; (ld || []).forEach((l, s) => (l || []).forEach(q => { if (q.t === "u") out.push({ m: s, type: "dist", dir: "Y", q1: -q.w }); else out.push({ m: s, type: "point", dir: "Y", P: -q.P, a: q.a }); })); return out; };
    const cases = { G: fr.solveCase({ members: it(o.ldG) }) }, names = [], Wf = o.braced === 0 && o.W > 0 ? o.W : 0;
    if (Wf) { cases.Wp = fr.solveCase({ nodes: [{ n: 0, fx: Wf }] }); cases.Wm = fr.solveCase({ nodes: [{ n: 0, fx: -Wf }] }); }
    for (let s = 0; s < n; s++) { const l = Array.from({ length: n }, () => []); l[s] = (o.ldQ && o.ldQ[s]) || []; cases["Q" + s] = fr.solveCase({ members: it(l) }); names.push("Q" + s); }
    const grid = (env, k, key) => { const b = env.barres[k], L = fr.geo[k].L, out = []; for (let q = 0; q <= NSS; q++) { const x = L * q / NSS; let bi = 0, d = 1e9; b.x.forEach((v, i) => { if (Math.abs(v - x) < d) { d = Math.abs(v - x); bi = i; } }); out.push(b[key][bi]); } return out; };
    const one = c => enveloppe(fr, cases, [{ id: c, f: { [c]: 1 } }], NSS);
    const pack = c => { const e = one(c), M = [], V = []; for (let s = 0; s < n; s++) { M.push(grid(e, s, "Mmax")); V.push(grid(e, s, "Vmax")); } return { M, V }; };
    const Gp = pack("G"), Qp = names.map(pack), envC = { G: one("G") }, Wp = Wf ? [pack("Wp"), pack("Wm")] : null; names.forEach(c => { envC[c] = one(c); }); if (Wf) { envC.Wp = one("Wp"); envC.Wm = one("Wm"); }
    /* enveloppes ELU / ELS (toutes dispositions de Q) pour les poteaux et pour le dessin */
    const nn = Math.min(n, 8), mk = (fG, fQ, tag) => { const sub = []; for (let mask = 1; mask < (1 << nn); mask++) { const f = { G: fG }; for (let i = 0; i < nn; i++) if (mask & (1 << i)) f["Q" + i] = fQ; sub.push({ id: tag + mask.toString(2), f }); }
      if (n > nn) { const f = { G: fG }; for (let i = 0; i < n; i++) f["Q" + i] = fQ; sub.push({ id: tag + "tout", f }); } return sub; };
    /* vent / séisme horizontal W (±) : Q dominante avec ψ0·W, W dominante avec ψ0·Q (ψ0,W = 0,6 ; ψ0,Q = 0,7), et G + W seul */
    const mkW = (fG, fQ, tag) => { const base = mk(fG, fQ, tag), out = base.slice(); if (!Wf) return out; const wn = ["Wp", "Wm"];
      wn.forEach(w => { out.push({ id: tag + w + "0", f: { G: fG, [w]: fQ } }); base.forEach((c, q) => { const f1 = Object.assign({}, c.f), f2 = Object.assign({}, c.f); Object.keys(f1).forEach(k => { if (k !== "G") { f2[k] = f1[k] * .7; } }); f1[w] = fQ * .6; f2[w] = fQ; out.push({ id: tag + w + "a" + q, f: f1 }); out.push({ id: tag + w + "b" + q, f: f2 }); }); }); return out; };
    const envU = enveloppe(fr, cases, mkW(gG, gQ, "ELU "), NSS), envS = enveloppe(fr, cases, mkW(1, 1, "ELS "), NSS);
    const colRes = cols.map(c => { const b = envU.barres[c.k], last = b.x.length - 1; return Object.assign({}, c, { Nu: Math.max(0, -Math.min(...b.Nmin)), Mu: Math.max(...b.Mmax.map(Math.abs), ...b.Mmin.map(Math.abs)), Mext: [Math.max(Math.abs(b.Mmax[0]), Math.abs(b.Mmin[0])), Math.max(Math.abs(b.Mmax[last]), Math.abs(b.Mmin[last]))], Vu: Math.max(...b.Vmax.map(Math.abs), ...b.Vmin.map(Math.abs)) }); });
    /* effets de chaque cas élémentaire en tête / pied de chaque poteau (compression N > 0), pour l'envoi au module Poteau */
    colRes.forEach(c => { const get = e => { const b = e.barres[c.k], last = b.x.length - 1, M0 = b.Mmax[0], M1 = b.Mmax[last]; return { N: -b.Nmax[0], Mh: c.pos === "b" ? M1 : M0, Mf: c.pos === "b" ? M0 : M1 }; };
      c.G = get(envC.G); c.Q = names.map(nm => get(envC[nm])); if (Wf) c.W = [get(envC.Wp), get(envC.Wm)]; });
    return { G: Gp, Q: Qp, W: Wp, cols: colRes, fr, nodes, members, envU, envS, cases, Ls, o };
  }

  /* ====================================================================== diagrammes d'enveloppe de poutre — présentation « bureau d'études » */
  /* o : { Ls[], A[s][k] (max), B[s][k] (min), kind:"M"|"V", unit, title, nameSupport? }
     M : positif (fibres inférieures tendues) tracé vers le bas ; V : positif tracé vers le haut. Signes dans les lobes, valeurs aux extrema et aux appuis,
     travée la plus sollicitée repérée, graduation et légende. */
  function svgEnvPoutre(o) {
    const Ls = o.Ls, n = Ls.length, A = o.A, B = o.B, N = A[0].length - 1, kind = o.kind, W = 760, pl = 58, pr = 26, T = Ls.reduce((a, b) => a + b, 0), sc = (W - pl - pr) / T;
    const id = (svgEnvPoutre.c = (svgEnvPoutre.c || 0) + 1), cum = [0]; Ls.forEach(L => cum.push(cum[cum.length - 1] + L));
    const fm = v => (Math.abs(v) < 0.05 ? "0,0" : (v < 0 ? "−" : "+") + Math.abs(v).toFixed(1).replace(".", ",")), fa = v => Math.abs(v).toFixed(1).replace(".", ",");
    let pos = 0, neg = 0; A.forEach((a, s) => a.forEach((v, k) => { pos = Math.max(pos, v, B[s][k]); neg = Math.max(neg, -v, -B[s][k]); }));
    const dirM = kind === "M" ? 1 : -1, up = kind === "M" ? neg : pos, dn = kind === "M" ? pos : neg, ext = Math.max(up + dn, 1e-9), kk = (kind === "M" ? 220 : 190) / ext;
    const yd = 112, y0 = yd + up * kk + 26, yb = y0 + dn * kk + 26, X = (s, k) => pl + (cum[s] + Ls[s] * k / N) * sc, XS = j => pl + cum[j] * sc, Y = v => y0 + dirM * v * kk;
    const nice = ext0 => { const r = ext0 / 4, p = Math.pow(10, Math.floor(Math.log10(r))), m = r / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; }, step = nice(ext);
    /* travée la plus sollicitée */
    let best = 0, bv = -1; for (let s = 0; s < n; s++) { const v = kind === "M" ? Math.max(0, ...A[s]) : Math.max(...A[s].map(Math.abs), ...B[s].map(Math.abs)); if (v > bv) { bv = v; best = s; } }
    const out = [`<svg viewBox="0 0 ${W} ${(yb + 74).toFixed(0)}" role="img" aria-label="${o.title}" style="width:100%;height:auto;background:#fff;border:1px solid #d5dae1;border-radius:8px;font-family:system-ui,Arial,sans-serif">`];
    out.push(`<defs><pattern id="ha${id}" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)"><rect width="6" height="6" fill="#fff4ec"/><line x1="0" y1="0" x2="0" y2="6" stroke="#e8590c" stroke-width="1.1" stroke-opacity=".7"/></pattern><pattern id="hb${id}" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(-45)"><rect width="6" height="6" fill="#eef5ff"/><line x1="0" y1="0" x2="0" y2="6" stroke="#1b6fb3" stroke-width="1.1" stroke-opacity=".7"/></pattern></defs>`);
    out.push(`<text x="${pl}" y="20" font-size="14" font-weight="700" fill="#14284b">${o.title}</text>`);
    /* bandeau : schéma de la poutre, portées et appuis */
    out.push(`<rect x="${XS(0)}" y="52" width="${T * sc}" height="9" fill="#bbdefb" stroke="#0d47a1" stroke-width="1.5"/>`);
    for (let j = 0; j <= n; j++) out.push(`<path d="M${XS(j)} 61l-8 12h16z" fill="#14284b"/><circle cx="${XS(j)}" cy="88" r="9" fill="#fff" stroke="#14284b" stroke-width="1.4"/><text x="${XS(j)}" y="92" text-anchor="middle" font-size="11" font-weight="700" fill="#14284b">${(o.sup && o.sup[j]) || j + 1}</text>`);
    for (let s = 0; s < n; s++) { const a = XS(s), b = XS(s + 1); out.push(`<line x1="${a + 4}" y1="42" x2="${b - 4}" y2="42" stroke="#5b6779" stroke-width="1"/><path d="M${a + 4} 42l7-3v6zM${b - 4} 42l-7-3v6z" fill="#5b6779"/><text x="${(a + b) / 2}" y="38" text-anchor="middle" font-size="11" fill="#14284b">${(o.names && o.names[s]) || "T" + (s + 1)} · L = ${Ls[s].toFixed(2).replace(".", ",")} m</text>`); }
    /* repère de la travée la plus sollicitée */
    out.push(`<rect x="${XS(best) + 1}" y="${yd - 8}" width="${Ls[best] * sc - 2}" height="${yb - yd + 8}" fill="#fff8d6" fill-opacity=".85" stroke="#e0b400" stroke-dasharray="4 3"/><text x="${XS(best) + 6}" y="${yd + 4}" font-size="10" fill="#8a6d00" font-weight="700">▲ travée la plus sollicitée</text>`);
    /* graduation */
    for (let v = step; v <= up + 1e-9; v += step) { const y = Y(kind === "M" ? -v : v); out.push(`<line x1="${pl}" y1="${y}" x2="${W - pr}" y2="${y}" stroke="#e1e6ee" stroke-dasharray="2 3"/><text x="${pl - 6}" y="${y + 3}" text-anchor="end" font-size="9" fill="#7a86a0">${kind === "M" ? "−" : "+"}${fa(v)}</text>`); }
    for (let v = step; v <= dn + 1e-9; v += step) { const y = Y(kind === "M" ? v : -v); out.push(`<line x1="${pl}" y1="${y}" x2="${W - pr}" y2="${y}" stroke="#e1e6ee" stroke-dasharray="2 3"/><text x="${pl - 6}" y="${y + 3}" text-anchor="end" font-size="9" fill="#7a86a0">${kind === "M" ? "+" : "−"}${fa(v)}</text>`); }
    for (let j = 0; j <= n; j++) out.push(`<line x1="${XS(j)}" y1="73" x2="${XS(j)}" y2="${yb}" stroke="#9aa6bb" stroke-dasharray="5 4"/>`);
    /* enveloppes : surfaces hachurées + courbes */
    const poly = (D, fill, col) => { let pts = "", base = ""; for (let s = 0; s < n; s++) { const a = [], b2 = []; for (let k = 0; k <= N; k++) { a.push(`${X(s, k).toFixed(1)},${Y(D[s][k]).toFixed(1)}`); b2.unshift(`${X(s, k).toFixed(1)},${y0.toFixed(1)}`); } out.push(`<polygon points="${a.join(" ")} ${b2.join(" ")}" fill="${fill}" stroke="none"/>`); out.push(`<polyline points="${a.join(" ")}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round"/>`); } };
    poly(B, `url(#hb${id})`, "#1b6fb3"); poly(A, `url(#ha${id})`, "#e8590c");
    out.push(`<line x1="${pl}" y1="${y0}" x2="${W - pr}" y2="${y0}" stroke="#14284b" stroke-width="1.8"/>`);
    /* étiquettes */
    const lab = (x, y, txt, col, anc) => { const w = txt.length * 6.3 + 8, x0 = anc === "end" ? x - w : anc === "middle" ? x - w / 2 : x; out.push(`<rect x="${x0.toFixed(1)}" y="${(y - 10).toFixed(1)}" width="${w.toFixed(1)}" height="14" rx="3" fill="#fff" fill-opacity=".92" stroke="${col}" stroke-width=".8"/><text x="${(x0 + w / 2).toFixed(1)}" y="${(y + 0.5).toFixed(1)}" text-anchor="middle" font-size="10.5" font-weight="700" fill="${col}">${txt}</text>`); };
    const badge = (x, y, plus, col) => out.push(`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="8" fill="#fff" stroke="${col}" stroke-width="1.4"/><text x="${x.toFixed(1)}" y="${(y + 4.2).toFixed(1)}" text-anchor="middle" font-size="13" font-weight="700" fill="${col}">${plus ? "+" : "−"}</text>`);
    const thr = ext * .035;
    if (kind === "M") {
      for (let s = 0; s < n; s++) { let mv = 0, mk2 = 0; A[s].forEach((v, k) => { if (v > mv) { mv = v; mk2 = k; } });
        if (mv > thr) { lab(X(s, mk2), Y(mv) + 17, fm(mv) + " kN·m", "#c2410c", "middle"); badge((X(s, 0) + X(s, N)) / 2 + (mk2 < N / 2 ? 30 : mk2 > N / 2 ? -30 : 30), y0 + dirM * Math.min(mv * .45, mv - 14 / kk) * kk, true, "#c2410c"); } }
      for (let j = 0; j <= n; j++) { const v = Math.min(j > 0 ? B[j - 1][N] : 0, j < n ? B[j][0] : 0);
        if (v < -thr) { lab(XS(j), Y(v) - 8, fm(v) + " kN·m", "#1b6fb3", j === 0 ? "start" : j === n ? "end" : "middle"); badge(XS(j) + (j === n ? -18 : 18), y0 + dirM * v * .5 * kk, false, "#1b6fb3"); } }
    } else {
      for (let s = 0; s < n; s++) { const a0 = A[s][0], b0 = B[s][N], a1 = A[s][N], b1 = B[s][0];
        if (Math.abs(a0) > thr) lab(X(s, 0) + 4, Y(a0) - 8, fm(a0) + " kN", "#c2410c", "start");
        if (Math.abs(b0) > thr) lab(X(s, N) - 4, Y(b0) + 17, fm(b0) + " kN", "#1b6fb3", "end");
        if (a0 > thr) badge(X(s, 0) + Ls[s] * sc * .18, y0 - Math.min(a0 * .5, a0 - 12 / kk) * kk, true, "#c2410c"); if (b0 < -thr) badge(X(s, N) - Ls[s] * sc * .18, y0 - Math.max(b0 * .5, b0 + 12 / kk) * kk, false, "#1b6fb3"); }
    }
    const ex = kind === "M" ? [`Mt,max = ${fm(Math.max(0, ...A.flat())).replace("+", "")} kN·m (${(o.names && o.names[best]) || "T" + (best + 1)})`, `Ma,max = ${fm(Math.min(0, ...B.flat())).replace("−", "")} kN·m (appui)`] : [`|V|max = ${fa(Math.max(...A.flat().map(Math.abs), ...B.flat().map(Math.abs)))} kN`];
    out.push(`<text x="${W - pr}" y="20" text-anchor="end" font-size="11" fill="#5b6779">${ex.join("  ·  ")}</text>`);
    /* légende */
    const ly = yb + 24; out.push(`<rect x="${pl}" y="${ly - 9}" width="18" height="11" fill="url(#ha${id})" stroke="#e8590c"/><text x="${pl + 24}" y="${ly}" font-size="10.5" fill="#14284b">Maximum (enveloppe de toutes les dispositions de Q)</text><rect x="${pl + 300}" y="${ly - 9}" width="18" height="11" fill="url(#hb${id})" stroke="#1b6fb3"/><text x="${pl + 324}" y="${ly}" font-size="10.5" fill="#14284b">Minimum</text>`);
    out.push(`<text x="${pl}" y="${ly + 18}" font-size="10" fill="#5b6779">${kind === "M" ? "Convention : M > 0 = fibres inférieures tendues (tracé vers le bas) ; M < 0 sur appui (fibres supérieures tendues)." : "Convention : V > 0 = tracé vers le haut (réaction d'appui gauche positive)."} Unités : ${o.unit}.</text><text x="${pl}" y="${ly + 32}" font-size="10" fill="#5b6779">Graduation : ${fa(step)} ${o.unit} · Les enveloppes regroupent toutes les dispositions de charges variables.</text></svg>`);
    return out.join("");
  }

  const api = { analyseModele, poutreContinueFE, poutrePortiqueFE, svgEnvPoutre, colonneNM, courbeNM, courbeNMc, courbeNMcirc, nappes, poteauNM, momentResistant, resumeCombi, analysePortique, resumePortique, svgPortique, PSI, luFactor, luSolve, solveSmall, jacobi, combinaisons, combiner, frame, effortsBarre, enveloppe, spectre, SOLS, modale, combinaisonModale, spectrale, portique, Ecm, GRAV };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.EXBR = api;
})(typeof window !== "undefined" ? window : globalThis);
