# V122 — Analyse de structure « type Robot » (moteur `exb-robot-analyse.js`)

Nouveau moteur sans DOM (`window.EXBR`, testable sous Node) qui renforce les modules de calcul avec les fonctions de Robot Structural Analysis.

## Fonctionnalités
1. **Combinaisons automatiques** (EN 1990 6.10, 6.10a/b, ELS caractéristique / fréquente / quasi-permanente, accidentelle, sismique ±Ex ± 0,3·Ey ; BAEL 91 : 1,35G + 1,5Q + 1,3ψ0·Qi), coefficients ψ par catégorie, groupes exclusifs (vent +X / −X).
2. **Analyse statique EF de portiques plans** : barres inclinées, articulations, appuis rigides / élastiques / tassements, charges nodales, réparties (trapèze, local/global, projetées), ponctuelles, température ; réactions, détection de mécanisme.
3. **Diagrammes N, V, M, flèches** par barre et **enveloppes** de toutes les combinaisons avec combinaison dominante.
4. **Analyse modale** (condensation statique, Jacobi), masses modales effectives, **spectre EN 1998-1 3.2.2.5**, combinaison SRSS/CQC, effort tranchant à la base, dérive d'étage (dr·ν), sensibilité θ, comparaison avec la méthode des forces latérales.

## Écrans ajoutés (menu Calculs et « Ingénierie & Structure »)
- **Portique 2D — analyse EF** : n étages × m travées, enveloppes ELU/ELS, vent, séisme modal, diagrammes SVG, envoi des géométries et efforts G/Q vers les modules **Poutre** et **Poteau**.
- **Combinaisons d'actions** : liste des combinaisons et valeur dominante pour un effet donné.

## Validation
`node site/calcul-structure/validation/valider-robot.js` : 87 contrôles contre solutions analytiques (RDM, pentes-déflexions, valeurs propres exactes, EN 1990/1998-1) et contre le moteur de poutre continue existant. `npm run test:calcul` les exécute avec les anciens (111 contrôles inchangés).

## Branchement sur les modules existants
- **Portique 2D** : dimensionnement automatique **par niveau** à partir des enveloppes ELU, ELS caractéristique et séisme (G + ψ2·Q ± E) : armatures de travée, d'appui, cadres des poutres (moteur du module Poutre) et armatures des poteaux. Quand le module Poteau ne sait pas traiter la flexion composée (traction partielle), le poteau est dimensionné par un **diagramme d'interaction N–M** (aciers symétriques, bloc 0,8x, excentricité minimale).
- **Module Poutre** : carte « Contrôle par éléments finis » sous les résultats : mêmes chargements alternés et charges spéciales, concordance affichée (écart ≤ 1 % constaté), plus **tassements d'appui** et **appuis élastiques** (ce que le calcul par rotations ne permet pas).

## Station d'analyse du bâtiment (V123)
Module **Bâtiment → « Ouvrir la station d'analyse (type Robot) »** (`exb-robot-station.js`) : espace de travail en panneaux.
- **Dispositions** (comme les « layouts » de Robot) : Géométrie · Charges · Analyse · Résultats · Dimensionnement.
- **Arbre d'objets** (niveaux, 6 portiques X/Y, cas de charges, combinaisons), **vue** plan du niveau / portique avec diagrammes M, V, N, flèches (cliquer une poutre du plan choisit le portique ; cliquer une barre affiche ses efforts, son enveloppe et ses armatures), **propriétés** modifiables (hauteurs, travées, sections, charges G/Q, vent, séisme), **tableaux** (efforts, réactions, combinaisons, modes et dérives, tous les portiques, armatures) avec export CSV, barre d'état. Sur mobile, les panneaux passent en onglets.
- Chaque portique du bâtiment est extrait du modèle (poteaux dimensionnés par la descente de charges, charges des poutres) et analysé par le moteur EXBR ; équivalence vérifiée avec le portique régulier (R16).
- Limites : analyse plane par axe (pas de 3D couplée ni de torsion) ; séisme global (T, Vb, dérives, θ) sans combinaisons sismiques dans le dimensionnement des armatures ; ces cas sont dans l'écran Portique 2D.

## Limites
Linéaire élastique (pas de P-Δ ni fissuration : rigidité brute), Euler-Bernoulli, diaphragme rigide, masses concentrées, pas de torsion ni d'excentricité accidentelle, poteaux N–M sans second ordre (alerte si λ > 25) et en flexion uniaxiale, tassements pris à γ = 1,0. Non comparé à Robot : à compléter dans `COMPARAISON-ROBOT.md`.

## V124 — Palettes fonctionnelles et configuration des axes (Station d'analyse)

Les palettes de la station agissent maintenant sur le modèle du bâtiment (plus de simples maquettes) :

- **Géométrie** : Sélection, Poteau (créer/supprimer, option « tous niveaux »), Poutre (retirer/rétablir un tronçon), Dalle (créer/retirer une case), Axe X/Y (insérer à l'endroit cliqué), Suppr. X/Y (fusionne les deux travées), Axes… (table), Copier niveau, + / − niveau.
- **Charges** : Charge linéaire G/Q ajoutée sur une poutre (prise en compte dans l'analyse des portiques), Effacer.
- **Analyse / Résultats / Dimensionnement** : Analyser, Tous, choix du diagramme (M, V, N, flèches), Recalculer.
- Toutes dispositions : **Annuler / Rétablir** (60 niveaux), zoom + / − / ajuster.
- **Table des axes** (« Axes… ») : position de chaque axe, longueur de travée, insertion, suppression, ajout de travée ; poteaux, poutres, dalles et sections suivent sur tous les niveaux, descente de charges recalculée.
- Panneau Propriétés contextuel : section imposée d'un poteau, section d'une ligne de poutres, charge linéaire, épaisseur de dalle, longueur de travée, position d'axe.

Limite : les charges linéaires ajoutées sont repérées par tronçon ; elles sont effacées quand la grille change (insertion/suppression d'axe).

## V125 — Fondations du bâtiment
`batFond` dimensionne automatiquement toutes les semelles isolées du bâtiment à partir des charges au pied (moteur `semelleCalc` : contrainte au sol ELS, flexion par bielles, rigidité, poinçonnement, effort tranchant). Résultats : carte « Fondations » dans Dimensionnement bâtiment, onglet « Fondations » de la station (disposition Dimensionnement), alertes de chevauchement de semelles (semelle filante / radier à prévoir) et métré béton. Contrainte du sol : champ `b.sig`. Validation R17 (8 contrôles). Limites : semelles carrées centrées, sans moment en pied ni liaison par longrines.

## V126 — Module Poteau renforcé (flexion composée déviée N–M)
Avant : au-delà de la compression centrée, le module Poteau s'arrêtait avec « diagramme d'interaction N-M nécessaire (non couvert ici) » (BAEL : traction partielle ; EC2 : excentricité > 60 %).
Maintenant (sections rectangulaires, BAEL et EC2) :
- dimensionnement par diagramme d'interaction N–M avec aciers répartis sur le pourtour (`EXBR.poteauNM`, `courbeNMc`, `nappes`), flexion déviée (EN 1992-1-1 5.8.9, exposant a), second ordre par courbure nominale (5.8.8) ou formule BAEL A.4.3.5, excentricité minimale ;
- contrôle renforcé du résultat de la méthode forfaitaire, avec alerte et acier nécessaire si le taux N–M dépasse 100 % ;
- carte « Contrôle N–M renforcé » : λ, e0, ei, e2, MEd/MRd par sens, exposant a, taux, diagrammes d'interaction ;
- la note de calcul et le plan d'exécution suivent l'acier retenu.
Validation R18 (12 contrôles). Limites : sections circulaires inchangées ; fluage négligé ; barres supposées réparties en nombre égal sur les quatre faces.

## V127 — Suite : poteau bois en flexion composée, poteaux de la station
- Poteau bois (EC5) : champs My / Mz ; vérification de flexion composée EN 1995-1-1 6.3.2 (éq. 6.23 et 6.24, km = 0,7, kh, flambement kc par axe). Compression centrée inchangée. Validation R19.
- Station d'analyse : le dimensionnement des poteaux passe par le module Poteau renforcé (N–M, flexion déviée, second ordre) dès que les moments sont forts.
Restent hors périmètre : sections de classe 4 (acier), compression perpendiculaire aux fibres et feu (bois), sections circulaires en flexion composée forte.

## V128 — Limites levées
- Acier (EC3) : sections de classe 4 traitées par largeurs efficaces EN 1993-1-5 — poteau (aire efficace Aeff, flambement sur Aeff) et poutre (Weff,min, semelle ρ outstand, âme ψ = −1, une itération). Validation R20.
- Poteau béton circulaire : flexion composée forte par diagramme N–M à n barres régulièrement réparties, moment résultant, second ordre, taux N–M ; carte de contrôle et note de calcul. Validation R21.
- Poteau bois (EC5) : compression perpendiculaire aux fibres au pied sur lisse (6.1.5, kc,90, +30 mm) et résistance au feu R15 à R90 par section réduite (EN 1995-1-2 : βn, d0, k0, kfi = 1,25, ηfi = 0,6). Validation R22.
Limites restantes : voilement par cisaillement de l'âme (classe 4 poutre), assemblages et pieds de poteau au feu, feu des éléments en béton/acier.

## V140c — Semelle : semelle filante et glacis fonctionnels
Module **Semelle** : les boutons « Semelle filante » et « Avec glacis » sont actifs.
- **Semelle filante** (par mètre linéaire, mur continu) : moteur `EXBO.semelleFilante` (bielles / moments, rigidité, tranchant, sol ELS avec décollement), note de calcul professionnelle (`noteSemF`, 4 pages avec coupe), plan d'exécution, vue 3D, DXF et IFC.
- **Glacis** (isolée et filante) : champ « Hauteur de rive h0 — patin » ; volume réel (tronc de pyramide / de prisme), poids propre, tranchant et poinçonnement avec la hauteur utile réduite à d du nu, alertes (h0 < 15 cm, pente > 30°) ; coupes, plan, 3D et IFC dessinent le glacis.
- Le module « Semelle filante » du menu Ouvrages gagne h0, hauteur de terre et γ des terres, et sa note de calcul est la même note professionnelle.
- Validation : suite R23 de `validation/valider-robot.js`.

## V140d — Station Robot de la V137 reportée
Voir `LISEZ-MOI-V140d-STATION-ROBOT.md` : vue 3D, sélection multiple / clic droit / raccourcis, charges par dalle, note de station, module autonome.

## V141m — Blocage de la saisie (rapport Ctrl+Alt+L)
Le rapport pointait `sync()` de `exb-topbar-hub.js` (546 ms) puis `flush`. Cause : toutes les 1,2 s la barre du haut redessinait le menu flottant (`EXB_FAB.render`, mesures de mise en page forcées) même sans changement et même pendant la frappe. Désormais : rendu seulement si une icône change, jamais pendant la saisie ni fenêtre masquée ; rendu régulier et observateur du `<body>` de `exb-fab.js` calmés. Le diagnostic distingue les pauses ≥ 5 s (boîte de dialogue, impression/PDF, veille) des vrais blocages. Reprise des correctifs V137 : fermeture de « Devis automatique » à la navigation, pas de reconstruction de l'accueil pendant la saisie.

## V141n — Navigation robuste + notes de semelle (pression, M, V)
- Cause du blocage « Bâtiment → Robot → Poutre » : l'entrée `robot` était ignorée par `ouvrir(k)`. Corrigé ; module inconnu → message « Module introuvable ».
- Menu parent : accusé de réception (`opened`), nouvel essai après 2,2 s, puis rechargement de l'iframe en dernier recours.
- Rendu protégé : une erreur dans un module affiche une carte de secours (Réessayer / Accueil / Réinitialiser le module) au lieu de figer la page ; erreurs globales signalées par toast limité.
- Notes de semelle (isolée et filante) : nouvelle page avec diagrammes de pression du sol, moment fléchissant et effort tranchant (section à d du nu), tableaux pas à pas, vérification par bielles/flexion, poinçonnement.
- Tests : suites R23 et R37 (187 contrôles) + fuzz de 160 navigations aléatoires sans erreur.
## V141o — Modules de quantités complétés, accès chantier
- Suppression des tuiles « bientôt » : Planning, Gestion de chantier, Indice des prix / décomptes, Journal de chantier, Contrôle béton / qualité, Situations de travaux ouvrent désormais les modules réels de l'application (message `goto` du cadre vers l'application).
- Dosage béton : E/C, sable/gravier, pertes, sacs 25/50 kg, tonnes, résistance indicative, alertes (EN 206).
- Volumes : parallélépipède ou cylindre, pertes, masse, acier, nombre de toupies.
- Coffrage : poutre, poteau, dalle, voile, semelle ; panneaux, planches, étais.
- Ferraillage minimal : hauteur utile, %, masse d'acier, cadres. Agglos : formats/épaisseurs, rangées, ciment/sable du mortier, poids du mur. Mortier : usages, eau, brouettes. Coûts : coffrage, frais généraux, coût par m³.
- Texte « semelle commune : bientôt » remplacé par une consigne (semelle filante / radier).
- Tests : suite R38 (9 contrôles), 196 contrôles, 0 écart.

## V141s — Notes d'escalier : diagrammes et calcul pas à pas
- Volée droite et balancée : 5 pages (nouvelle page : charge, effort tranchant, moment, puis μ → α → z → As en travée et sur appui).
- Escalier à palier (va-et-vient, quart tournant) : 7 pages (diagrammes et calculs pas à pas des deux volées, puis du palier avec charge linéaire des volées).
- Tests : suite R39 (6 contrôles) ; 202 contrôles, 0 écart.

## V141s (suite) — Recalcul automatique
- Poutre, poteau, dalle, semelle, semelle filante, escalier : après un premier calcul, toute modification d'une donnée ou d'un acier imposé relance le calcul (≈ 0,5 s après la saisie). Le résultat est grisé pendant l'attente ; si les données sont invalides, un avis « Données incomplètes ou invalides » remplace le silence.
- Le nombre de barres suit donc le diamètre ou la section imposés (ex. 3 HA25 → 6 HA10 → 6 HA20), sans devoir relancer le calcul.
