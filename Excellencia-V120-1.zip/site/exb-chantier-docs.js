/* Excellencia Building V141r — Envoi des PLANS, NOTES DE CALCUL et PLANS D'EXÉCUTION au chantier.
 * Le PDF est déposé dans l'espace PRIVÉ « exb-chantier-docs » (dossier = identifiant du chantier) et enregistré par la fonction
 * chantier_doc_publier. Seuls l'administrateur et les membres du chantier peuvent le lister / l'ouvrir (aucun lien public).
 * Un document = une ligne par chantier : renvoyer le même numéro REMPLACE le fichier (nouvel indice / nouveau statut).
 * Prérequis : supabase/migration-v141r-documents-chantier.sql exécuté ; compte administrateur connecté (☁️).
 * Appelé par : exb-plans-publics.js (bouton 🏗️ d'un plan), calcul-structure/exb-calcul-doc.js (via window.parent.EXBCHDOCS),
 * exb-calc-publics.js (mise à jour automatique des notes déjà envoyées). */
(function (w, d) {
  'use strict';
  if (w.EXBCHDOCS) return;
  var BK = 'exb-chantier-docs', MAPK = 'exb_chdocs_map', AUTOK = 'exb_chdocs_auto';
  var lastErr = '', cfgErr = false, SITES = null;
  var G = {
    plan: { nom: 'Plan', ico: '📐', fichier: 'plan' },
    note: { nom: 'Note de calcul', ico: '🧮', fichier: 'note-de-calcul' },
    pex: { nom: 'Plan d’exécution', ico: '🏗️', fichier: 'plan-execution' }
  };
  function gk(g) { return g === 'pex' ? 'pex' : g === 'plan' ? 'plan' : 'note'; }

  /* ---------- outils ---------- */
  function ls(k, def) { try { return JSON.parse(localStorage.getItem(k)) || def; } catch (e) { return def; } }
  function ss(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* stockage plein */ } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t, ms) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', ms || 4500); } catch (e) { /* repli */ } try { console.log(m); } catch (e) { /* rien */ } }
  function size(n) { n = Number(n) || 0; return n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function rnd32() { var a = new Uint8Array(16); (w.crypto || w.msCrypto).getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function available() { return !!(w.exbSb && w.exbSb.api); }
  function online() { return !!(available() && w.exbSb.isIn && w.exbSb.isIn() && navigator.onLine); }
  function api(p, o) { return w.exbSb.api(p, o); }
  function rpc(n, b) { return api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  function autoOn() { try { return localStorage.getItem(AUTOK) !== '0'; } catch (e) { return true; } }
  function norm(s) { return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function nice(e) {
    var msg = (e && e.message) || String(e);
    if (/function .*chantier_doc|schema cache|PGRST202/i.test(msg)) { cfgErr = true; return 'Fonction serveur absente : exécutez supabase/migration-v141r-documents-chantier.sql (Supabase › SQL Editor).'; }
    if (/bucket not found/i.test(msg)) { cfgErr = true; return 'Espace de stockage absent : exécutez supabase/migration-v141r-documents-chantier.sql (Supabase › SQL Editor).'; }
    if (/Réservé aux administrateurs|row-level security|violates/i.test(msg)) return 'Réservé au compte administrateur : connectez-vous avec le compte administrateur (☁️).';
    return msg;
  }

  /* ---------- fichiers (espace privé) ---------- */
  function ext(blob, m) {
    if (m.genre !== 'plan') return 'pdf';
    var t = String((blob && blob.type) || '').toLowerCase();
    return /png/.test(t) ? 'png' : /jpe?g/.test(t) ? 'jpg' : /webp/.test(t) ? 'webp' : 'pdf';
  }
  function up(site, token, name, blob) {
    return api('/storage/v1/object/' + BK + '/' + site + '/' + token + '/' + name, { method: 'POST', headers: { 'Content-Type': blob.type || 'application/pdf', 'x-upsert': 'true' }, body: blob });
  }
  function purge(path) {
    if (!/^[0-9a-f-]{36}\/[a-f0-9]{32}\/[\w.-]+$/i.test(String(path || ''))) return Promise.resolve();
    return api('/storage/v1/object/' + BK, { method: 'DELETE', body: JSON.stringify({ prefixes: [path] }) }).catch(function () { /* suppression non bloquante */ });
  }

  /* ---------- chantiers ---------- */
  function sites(force) {
    if (SITES && !force) return Promise.resolve(SITES);
    return rpc('chantier_liste', {}).then(function (L) {
      SITES = (Array.isArray(L) ? L : []).map(function (x) { return { id: x.id, name: x.name || '', code: x.code || '' }; });
      return SITES;
    });
  }
  function meta(m) {
    m = m || {};
    return {
      genre: gk(m.genre), no: String(m.no || '').trim().slice(0, 60), titre: String(m.titre || '').slice(0, 160), projet: String(m.projet || '').slice(0, 160),
      indice: String(m.indice || '').slice(0, 30), statut: String(m.statut || '').slice(0, 30), hash: String(m.hash || '').slice(0, 80)
    };
  }
  function remembered(no) { var x = ls(MAPK, {})[no]; return x && x.sites ? x : { sites: {} }; }
  function remember(no, siteId, hash, path) {
    var map = ls(MAPK, {}); map[no] = map[no] || { sites: {} };
    map[no].sites[siteId] = { hash: hash, path: path, t: Date.now() };
    ss(MAPK, map);
  }
  function forget(no, siteId) { var map = ls(MAPK, {}); if (map[no] && map[no].sites) { delete map[no].sites[siteId]; ss(MAPK, map); } }

  /* ---------- envoi ---------- */
  function sendOne(m, blob, siteId, note) {
    var token = rnd32(), name = G[m.genre].fichier + '.' + ext(blob, m), path = siteId + '/' + token + '/' + name;
    return up(siteId, token, name, blob).then(function () {
      return rpc('chantier_doc_publier', { p_site: siteId, p_genre: m.genre, p_no: m.no, p_titre: m.titre, p_projet: m.projet, p_indice: m.indice, p_statut: m.statut, p_fichier: path, p_taille: size(blob.size), p_empreinte: m.hash, p_note: note || null });
    }).then(function (res) {
      if (!res || !res.ok) { purge(path); throw new Error((res && res.erreur) || 'Envoi refusé par le serveur.'); }
      if (res.ancien_fichier) purge(res.ancien_fichier);
      remember(m.no, siteId, m.hash, path);
      return true;
    });
  }
  /* Envoie le document à plusieurs chantiers (un par un). Renvoie {ok: [ids], ko: [{id, erreur}]}. */
  function send(raw, blob, siteIds, note) {
    var m = meta(raw), out = { ok: [], ko: [] };
    lastErr = '';
    if (!m.no || !blob || !siteIds || !siteIds.length) return Promise.resolve(out);
    if (!online()) { lastErr = 'Connectez-vous au serveur (☁️) avec le compte administrateur.'; siteIds.forEach(function (id) { out.ko.push({ id: id, erreur: lastErr }); }); return Promise.resolve(out); }
    return siteIds.reduce(function (pr, id) {
      return pr.then(function () {
        return sendOne(m, blob, id, note).then(function () { out.ok.push(id); }, function (e) { var t = nice(e); lastErr = t; out.ko.push({ id: id, erreur: t }); });
      });
    }, Promise.resolve()).then(function () { return out; });
  }
  /* Mise à jour silencieuse : renvoie le PDF aux chantiers où CE document a déjà été envoyé, si son contenu a changé. */
  function autoUpdate(raw, blob) {
    try {
      var m = meta(raw); if (!m.no || !blob || !autoOn() || cfgErr || !online()) return Promise.resolve(null);
      var r = remembered(m.no), ids = Object.keys(r.sites || {}).filter(function (id) { return r.sites[id].hash !== m.hash; });
      if (!ids.length) return Promise.resolve(null);
      return send(m, blob, ids).then(function (res) {
        if (res.ok.length) say('🏗️ ' + G[m.genre].nom + ' ' + m.no + ' mis à jour sur ' + res.ok.length + ' chantier' + (res.ok.length > 1 ? 's' : '') + '.', 'success', 5500);
        if (res.ko.length) say('Mise à jour du chantier impossible : ' + res.ko[0].erreur, 'warn', 8000);
        return res;
      });
    } catch (e) { return Promise.resolve(null); /* ne jamais gêner la génération du PDF */ }
  }
  function info(no) { var r = remembered(no); return { sites: Object.keys(r.sites || {}) }; }

  /* ---------- fenêtre ---------- */
  var BT = 'border:1px solid #cbd5e1;border-radius:10px;padding:9px 12px;background:#f1f5f9;color:#173565;font-weight:700;font-size:13px;cursor:pointer;';
  function ov(title, maxw) {
    var old = d.getElementById('exbChDocs'); if (old) old.remove();
    var o = d.createElement('div'); o.id = 'exbChDocs'; o.style.cssText = 'position:fixed;inset:0;z-index:2147483100;background:rgba(15,23,42,.6);display:flex;align-items:flex-start;justify-content:center;padding:12px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;max-width:' + (maxw || 560) + 'px;width:100%;padding:16px;margin-top:20px;font-family:Arial,sans-serif;color:#172033';
    c.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b style="font-size:16px;color:#173565">' + title + '</b><button type="button" id="chX" style="' + BT + '">✕</button></div><div id="chBody" style="margin-top:10px;font-size:14px"></div>';
    o.appendChild(c); d.body.appendChild(o); c.querySelector('#chX').onclick = function () { o.remove(); };
    return c.querySelector('#chBody');
  }

  /* pick(meta, getBlob) : choisir les chantiers puis envoyer. getBlob() renvoie une promesse de Blob (créé seulement à l'envoi). */
  function pick(raw, getBlob) {
    var m = meta(raw), g = G[m.genre];
    if (!m.no) { say('Document sans numéro : impossible de l’envoyer au chantier.', 'warn'); return; }
    if (!online()) { say('Connectez-vous au serveur (☁️) avec le compte administrateur pour envoyer au chantier.', 'warn', 6000); return; }
    var body = ov('🏗️ Envoyer au chantier — ' + esc(g.nom.toLowerCase()) + ' ' + esc(m.no), 600);
    body.innerHTML = '<p style="color:#64748b">Chargement des chantiers…</p>';
    sites().then(function (L) {
      if (!L.length) { body.innerHTML = '<p>Aucun chantier trouvé. Créez-en un dans « Demandes reçues › 🏗️ Chantiers terrain », puis rattachez-y l’équipe.</p>'; return; }
      var rem = remembered(m.no).sites, pj = norm(m.projet);
      body.innerHTML = '<p style="margin:0 0 8px;color:#475569">Seuls l’administrateur et l’équipe rattachée au chantier verront ce document dans le logiciel chantier. ' +
        'Renvoyer le même numéro remplace la version précédente.</p>' +
        '<div style="max-height:46vh;overflow:auto;border:1px solid #e2e8f0;border-radius:10px">' +
        L.map(function (s) {
          var on = rem[s.id] ? true : (pj && (norm(s.name) === pj));
          return '<label style="display:flex;gap:10px;align-items:center;padding:10px;border-bottom:1px solid #eef2f7;cursor:pointer"><input type="checkbox" class="chS" value="' + esc(s.id) + '"' + (on ? ' checked' : '') + '> ' +
            '<span><b>' + esc(s.name || s.code) + '</b>' + (s.code ? ' <small style="color:#64748b">· ' + esc(s.code) + '</small>' : '') + (rem[s.id] ? '<br><small style="color:#15803d">✓ déjà envoyé — sera mis à jour</small>' : '') + '</span></label>';
        }).join('') + '</div>' +
        '<p style="margin:10px 0 4px"><input id="chNote" maxlength="300" placeholder="Message pour l’équipe (facultatif) — ex. : version à appliquer dès demain" style="width:100%;box-sizing:border-box;padding:9px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px"></p>' +
        '<label style="display:flex;gap:8px;align-items:center;font-size:13px;margin:8px 0"><input type="checkbox" id="chAuto"' + (autoOn() ? ' checked' : '') + '> Mettre à jour automatiquement les chantiers déjà servis quand une nouvelle version du PDF est créée</label>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" id="chGo" style="' + BT + 'background:#082653;color:#fff;border:0">🏗️ Envoyer</button><button type="button" id="chLs" style="' + BT + '">Documents déjà envoyés</button></div>' +
        '<div id="chSt" style="margin-top:10px;font-size:13px"></div>';
      var $ = function (i) { return body.querySelector('#' + i); };
      $('chAuto').onchange = function () { try { localStorage.setItem(AUTOK, this.checked ? '1' : '0'); } catch (e) { /* rien */ } };
      $('chLs').onclick = manage;
      $('chGo').onclick = function () {
        var ids = Array.prototype.map.call(body.querySelectorAll('.chS:checked'), function (x) { return x.value; }), st = $('chSt');
        if (!ids.length) { st.style.color = '#b42318'; st.textContent = 'Choisissez au moins un chantier.'; return; }
        $('chGo').disabled = true; st.style.color = '#334155'; st.textContent = 'Création du PDF…';
        Promise.resolve().then(function () { return getBlob(); }).then(function (blob) {
          if (!blob) throw new Error('PDF impossible : ouvrez d’abord le document.');
          st.textContent = 'Envoi (' + size(blob.size) + ') à ' + ids.length + ' chantier' + (ids.length > 1 ? 's' : '') + '…';
          return send(m, blob, ids, ($('chNote').value || '').trim());
        }).then(function (res) {
          var names = {}; L.forEach(function (s) { names[s.id] = s.name || s.code; });
          var h = '';
          if (res.ok.length) h += '<p style="background:#effaf3;border:1px solid #b5e1c5;color:#176b3d;padding:10px;border-radius:10px"><b>✓ Envoyé</b> : ' + res.ok.map(function (id) { return esc(names[id]); }).join(', ') + '. L’équipe le voit dans le logiciel chantier.</p>';
          if (res.ko.length) h += '<p style="background:#fef3f2;border:1px solid #fecdca;color:#b42318;padding:10px;border-radius:10px"><b>Non envoyé</b> : ' + res.ko.map(function (x) { return esc(names[x.id]) + ' (' + esc(x.erreur) + ')'; }).join(' ; ') + '</p>';
          st.innerHTML = h; $('chGo').disabled = false;
        }).catch(function (e) { st.style.color = '#b42318'; st.textContent = nice(e); $('chGo').disabled = false; });
      };
    }).catch(function (e) { body.innerHTML = '<p style="color:#b42318">' + esc(nice(e)) + '</p>'; });
  }

  /* Documents déjà envoyés à un chantier (liste + retrait). */
  function manage() {
    if (!online()) { say('Connectez-vous au serveur (☁️) pour voir les documents du chantier.', 'warn'); return; }
    var body = ov('🏗️ Documents envoyés aux chantiers', 760);
    body.innerHTML = '<p style="color:#64748b">Chargement…</p>';
    sites().then(function (L) {
      if (!L.length) { body.innerHTML = '<p>Aucun chantier.</p>'; return; }
      body.innerHTML = '<label style="font-size:13px">Chantier<br><select id="chSel" style="width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:8px;margin-top:4px">' +
        L.map(function (s) { return '<option value="' + esc(s.id) + '">' + esc(s.name || s.code) + '</option>'; }).join('') + '</select></label><div id="chList" style="margin-top:10px"></div>';
      var sel = body.querySelector('#chSel');
      function load() {
        var box = body.querySelector('#chList'); box.innerHTML = '<p style="color:#64748b">Chargement…</p>';
        rpc('chantier_docs_liste', { p_site: sel.value }).then(function (D) {
          D = Array.isArray(D) ? D : [];
          if (!D.length) { box.innerHTML = '<p style="color:#64748b">Aucun document envoyé à ce chantier.</p>'; return; }
          box.innerHTML = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><tr style="text-align:left;background:#f1f5fb"><th style="padding:6px">Document</th><th>Indice / statut</th><th>Mis à jour</th><th></th></tr>' +
            D.map(function (x, i) {
              var g = G[gk(x.genre)];
              return '<tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px">' + g.ico + ' <b>' + esc(x.doc_no) + '</b><br><small>' + esc(x.titre || x.projet || '') + '</small></td><td>' + esc(x.indice || '—') + (x.statut ? ' · ' + esc(x.statut) : '') + '</td><td>' + esc(String(x.maj_le || '').slice(0, 10).split('-').reverse().join('/')) + '</td>' +
                '<td><button type="button" class="chR" data-i="' + i + '" style="' + BT + 'padding:6px 8px">Retirer</button></td></tr>';
            }).join('') + '</table></div>';
          box.querySelectorAll('.chR').forEach(function (b) {
            b.onclick = function () {
              var x = D[Number(b.getAttribute('data-i'))];
              if (!w.confirm('Retirer ' + x.doc_no + ' de ce chantier ? L’équipe ne pourra plus l’ouvrir.')) return;
              rpc('chantier_doc_retirer', { p_site: sel.value, p_no: x.doc_no }).then(function (r) {
                if (!r || !r.ok) throw new Error((r && r.erreur) || 'Retrait refusé.');
                forget(x.doc_no, sel.value); return purge(r.fichier);
              }).then(function () { say('Document retiré du chantier.', 'success'); load(); }).catch(function (e) { say(nice(e), 'error', 7000); });
            };
          });
        }).catch(function (e) { box.innerHTML = '<p style="color:#b42318">' + esc(nice(e)) + '</p>'; });
      }
      sel.onchange = load; load();
    }).catch(function (e) { body.innerHTML = '<p style="color:#b42318">' + esc(nice(e)) + '</p>'; });
  }

  w.EXBCHDOCS = { available: available, online: online, pick: pick, send: send, autoUpdate: autoUpdate, manage: manage, sites: sites, info: info, autoOn: autoOn, lastError: function () { return lastErr; } };
})(window, document);
