/* Excellencia Building V209k — ARCHITECTURE / BIM : règles IDS (buildingSMART Information Delivery Specification 1.0).
 * Cahier des charges Évolution ERP V1.0 : « Approfondir ... les règles IDS ».
 *  • IMPORT .ids / .xml (spécifications, applicabilité, exigences ; facettes entité, attribut, propriété, matériau, classification, partie de ;
 *    valeurs simples, énumérations, motifs, bornes ; cardinalité requis / facultatif / interdit) ; ÉDITION sans XML ; EXPORT .ids.
 *  • VÉRIFICATION sur les modèles IFC du projet (ceux de « Coordination IFC / BCF », conservés sur l'appareil) ou des fichiers IFC ajoutés ici :
 *    par spécification, éléments concernés / conformes / non conformes / non vérifiables, avec le motif précis de chaque écart.
 *    Une facette que le lecteur ne sait pas lire est déclarée NON VÉRIFIABLE (jamais « conforme ») ; la spécification est alors « incomplète ».
 *  • Résultats conservés (collection exb_arch_ids -> arch_ids), export CSV, rapport imprimable.
 *  • Lecture IFC : lecteur STEP intégré à ce module (exb-ifc3d.js n'est utilisé que pour ouvrir .ifczip / décoder le texte) : propriétés, matériaux,
 *    classifications, niveau, propriétés du type.
 *  • Limites assumées : seuls les éléments des classes listées (ENT) sont examinés ; attributs gérés : Name, Description, ObjectType, Tag, GlobalId,
 *    PredefinedType (repéré comme 1re énumération à partir du 9e attribut : approximation) ; « partie de » : niveau (IfcBuildingStorey) uniquement ;
 *    types de données IFC (dataType) non contrôlés ; l'export suit la structure IDS 1.0 mais doit être validé avec un outil tiers avant diffusion contractuelle.
 *  • Fonctions pures (parseXml, parseIDS, toXML, matchValue, verify, elementsFromIFC) testées dans tools/test-regles-ids.js. */
(function (w, d) {
  'use strict';
  if (w.EXBIDS) return;
  var KEY = 'exb_arch_ids', COL = 'arch_ids', KC = 'exb_arch_coord', MAXXML = 1048576, MAXIFC = 80 * 1048576, MAXFAIL = 200, MAXREC = 600;
  var st = { pid: '', tab: 'regles', run: null, busy: '', files: [], sel: {} };
  var ENT = ['IFCWALL', 'IFCSLAB', 'IFCDOOR', 'IFCWINDOW', 'IFCCOLUMN', 'IFCBEAM', 'IFCSPACE', 'IFCROOF', 'IFCSTAIR', 'IFCCOVERING', 'IFCFURNISHINGELEMENT', 'IFCRAILING', 'IFCFOOTING', 'IFCPLATE', 'IFCMEMBER', 'IFCBUILDINGELEMENTPROXY'];
  var FT = [['entity', 'Entité (classe IFC)'], ['attribute', 'Attribut'], ['property', 'Propriété'], ['material', 'Matériau'], ['classification', 'Classification'], ['partOf', 'Partie de (niveau)']];
  var CARD = [['required', 'Requis'], ['optional', 'Facultatif'], ['prohibited', 'Interdit']];
  var ATTRS = ['Name', 'Description', 'ObjectType', 'Tag', 'GlobalId', 'PredefinedType'];
  var AMAP = { Name: 'name', Description: 'desc', ObjectType: 'objType', Tag: 'tag', GlobalId: 'gid', PredefinedType: 'predef' };
  var NS = 'http://standards.buildingsmart.org/IDS';
  var LBL = { conforme: 'Conforme', non_conforme: 'Non conforme', non_verifiable: 'Non vérifiable (incomplète)', sans_element: 'Aucun élément concerné' };

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function s(v, n) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); } catch (e) { } }
  function canR() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'lire'); } catch (e) { return true; } }
  function canW() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'ecrire'); } catch (e) { return true; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function projs() { try { return w.EXBS.projects() || []; } catch (e) { return []; } }
  function load() { try { return w.EXBS.get(KEY) || []; } catch (e) { return []; } }
  function save(a) { return w.EXBS.set(KEY, a); }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction)) || ''; } catch (e) { return ''; } }
  function pname(id) { var n = ''; projs().forEach(function (p) { if (String(p.id) === String(id)) n = p.nom || p.name || p.titre || p.title || ''; }); return n || id || ''; }

  /* ================= XML ================= */
  function parseXml(t) {
    t = String(t || '');
    if (t.length > MAXXML) throw new Error('Fichier trop volumineux (> 1 Mo).');
    if (/<!DOCTYPE|<!ENTITY/i.test(t)) throw new Error('Déclaration DOCTYPE/ENTITY refusée.');
    var doc = new DOMParser().parseFromString(t, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('XML invalide.');
    return doc;
  }
  function kids(n, name) { var r = [], c = n ? n.children : []; for (var i = 0; i < c.length; i++) if (c[i].localName === name) r.push(c[i]); return r; }
  function kid(n, name) { return kids(n, name)[0] || null; }
  function parseValue(n) {
    if (!n) return null;
    var sv = kid(n, 'simpleValue'); if (sv) return { k: 'simple', v: s(sv.textContent, 500) };
    var r = kid(n, 'restriction'); if (!r) return null;
    var en = kids(r, 'enumeration');
    if (en.length) return { k: 'enum', v: en.map(function (e) { return s(e.getAttribute('value'), 500); }) };
    var p = kid(r, 'pattern'); if (p) return { k: 'pattern', v: s(p.getAttribute('value'), 500) };
    var b = { k: 'bounds' };
    ['minInclusive', 'maxInclusive', 'minExclusive', 'maxExclusive'].forEach(function (x) { var e = kid(r, x); if (e) b[x] = Number(e.getAttribute('value')); });
    return b;
  }
  function parseFacets(node) {
    var out = [];
    if (!node) return out;
    for (var i = 0; i < node.children.length; i++) {
      var c = node.children[i], t = c.localName, card = c.getAttribute('cardinality') || 'required';
      if (t === 'entity') out.push({ t: t, name: parseValue(kid(c, 'name')), predef: parseValue(kid(c, 'predefinedType')), card: card });
      else if (t === 'attribute') out.push({ t: t, name: parseValue(kid(c, 'name')), value: parseValue(kid(c, 'value')), card: card });
      else if (t === 'property') out.push({ t: t, pset: parseValue(kid(c, 'propertySet')), base: parseValue(kid(c, 'baseName')), value: parseValue(kid(c, 'value')), dataType: c.getAttribute('dataType') || '', card: card });
      else if (t === 'material') out.push({ t: t, value: parseValue(kid(c, 'value')), card: card });
      else if (t === 'classification') out.push({ t: t, value: parseValue(kid(c, 'value')), system: parseValue(kid(c, 'system')), card: card });
      else if (t === 'partOf') out.push({ t: t, relation: c.getAttribute('relation') || '', entity: { name: parseValue(kid(kid(c, 'entity'), 'name')) }, card: card });
    }
    return out;
  }
  function parseIDS(text) {
    var doc = parseXml(text), root = doc.documentElement;
    if (!root || root.localName !== 'ids') throw new Error('Ce fichier n\'est pas un IDS (balise <ids> absente).');
    var info = kid(root, 'info'), title = info && kid(info, 'title') ? s(kid(info, 'title').textContent, 200) : 'Règles IDS';
    var specs = [];
    kids(kid(root, 'specifications'), 'specification').slice(0, MAXREC).forEach(function (n, i) {
      var ap = kid(n, 'applicability'), rq = kid(n, 'requirements');
      specs.push({ id: uid('spec'), name: s(n.getAttribute('name'), 200) || 'Spécification ' + (i + 1), ifcVersion: s(n.getAttribute('ifcVersion'), 40) || 'IFC4', description: s(n.getAttribute('description'), 500), minOccurs: ap ? Number(ap.getAttribute('minOccurs') || 0) || 0 : 0, app: parseFacets(ap), req: parseFacets(rq) });
    });
    return { title: title, specs: specs };
  }
  function valXML(v, tag) {
    if (!v) return '';
    var o = '<' + tag + '>';
    if (v.k === 'simple') o += '<simpleValue>' + esc(v.v) + '</simpleValue>';
    else if (v.k === 'enum') o += '<xs:restriction base="xs:string">' + v.v.map(function (x) { return '<xs:enumeration value="' + esc(x) + '"/>'; }).join('') + '</xs:restriction>';
    else if (v.k === 'pattern') o += '<xs:restriction base="xs:string"><xs:pattern value="' + esc(v.v) + '"/></xs:restriction>';
    else if (v.k === 'bounds') o += '<xs:restriction base="xs:double">' + ['minInclusive', 'maxInclusive', 'minExclusive', 'maxExclusive'].filter(function (x) { return v[x] != null && !isNaN(v[x]); }).map(function (x) { return '<xs:' + x + ' value="' + v[x] + '"/>'; }).join('') + '</xs:restriction>';
    return o + '</' + tag + '>';
  }
  function facXML(f, req) {
    var c = req ? ' cardinality="' + esc(f.card) + '"' : '';
    if (f.t === 'entity') return '<entity>' + valXML(f.name, 'name') + valXML(f.predef, 'predefinedType') + '</entity>';
    if (f.t === 'attribute') return '<attribute' + c + '>' + valXML(f.name, 'name') + valXML(f.value, 'value') + '</attribute>';
    if (f.t === 'property') return '<property' + c + ' dataType="' + esc(f.dataType || 'IFCLABEL') + '">' + valXML(f.pset, 'propertySet') + valXML(f.base, 'baseName') + valXML(f.value, 'value') + '</property>';
    if (f.t === 'material') return '<material' + c + '>' + valXML(f.value, 'value') + '</material>';
    if (f.t === 'classification') return '<classification' + c + '>' + valXML(f.value, 'value') + valXML(f.system, 'system') + '</classification>';
    if (f.t === 'partOf') return '<partOf' + c + ' relation="' + esc(f.relation || 'IfcRelContainedInSpatialStructure') + '"><entity>' + valXML(f.entity && f.entity.name, 'name') + '</entity></partOf>';
    return '';
  }
  function toXML(ids) {
    var o = '<?xml version="1.0" encoding="UTF-8"?>\n<ids xmlns="' + NS + '" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="' + NS + ' http://standards.buildingsmart.org/IDS/1.0/ids.xsd">\n';
    o += '<info><title>' + esc(ids.title) + '</title><date>' + today() + '</date></info>\n<specifications>\n';
    ids.specs.forEach(function (sp) {
      o += '<specification name="' + esc(sp.name) + '" ifcVersion="' + esc(sp.ifcVersion || 'IFC4') + '"' + (sp.description ? ' description="' + esc(sp.description) + '"' : '') + '>\n';
      o += '<applicability minOccurs="' + (sp.minOccurs || 0) + '" maxOccurs="unbounded">' + sp.app.map(function (f) { return facXML(f, false); }).join('') + '</applicability>\n';
      o += '<requirements>' + sp.req.map(function (f) { return facXML(f, true); }).join('') + '</requirements>\n</specification>\n';
    });
    return o + '</specifications>\n</ids>\n';
  }

  /* ================= LECTURE IFC (STEP) ================= */
  function splitArgs(a) {
    var out = [], dep = 0, q = false, cur = '';
    for (var i = 0; i < a.length; i++) {
      var c = a.charAt(i);
      if (q) { cur += c; if (c === "'") { if (a.charAt(i + 1) === "'") { cur += "'"; i++; } else q = false; } continue; }
      if (c === "'") { q = true; cur += c; } else if (c === '(') { dep++; cur += c; } else if (c === ')') { dep--; cur += c; } else if (c === ',' && dep === 0) { out.push(cur.trim()); cur = ''; } else cur += c;
    }
    out.push(cur.trim());
    return out;
  }
  function sval(a) { /* 'abc' → abc ; IFCLABEL('abc') → abc ; .T. → TRUE ; nombre → nombre ; $ ou * → '' */
    if (a == null) return '';
    a = String(a).trim();
    var m = /^[A-Z0-9_]+\((.*)\)$/i.exec(a); if (m) a = m[1].trim();
    if (a === '$' || a === '*' || a === '') return '';
    if (a === '.T.') return 'TRUE'; if (a === '.F.') return 'FALSE';
    if (a.charAt(0) === "'") return a.slice(1, -1).replace(/''/g, "'").replace(/\\X2\\([0-9A-F]+)\\X0\\/g, function (x, h) { var o = ''; for (var i = 0; i + 3 < h.length + 1; i += 4) o += String.fromCharCode(parseInt(h.substr(i, 4), 16)); return o; });
    return a;
  }
  function ref(a) { var m = /^#(\d+)$/.exec(String(a || '').trim()); return m ? m[1] : ''; }
  function refs(a) { var o = [], re = /#(\d+)/g, m; a = String(a || ''); while ((m = re.exec(a))) o.push(m[1]); return o; }
  function elementsFromIFC(text) {
    var E = {}, re = /#(\d+)\s*=\s*([A-Z0-9_]+)\s*\(([\s\S]*?)\)\s*;/g, m;
    text = String(text || ''); var i0 = text.indexOf('DATA;'); if (i0 >= 0) text = text.slice(i0);
    while ((m = re.exec(text))) E[m[1]] = { t: m[2], a: null, raw: m[3] };
    function A(id) { var e = E[id]; if (!e) return []; if (!e.a) e.a = splitArgs(e.raw); return e.a; }
    var byEl = {}, ids = Object.keys(E);
    function slot(id) { return byEl[id] || (byEl[id] = { props: {}, mats: [], cl: [], level: '', typeId: '' }); }
    function matNames(id, dep, out) {
      var e = E[id]; if (!e || dep > 5) return;
      if (e.t === 'IFCMATERIAL') { var n = sval(A(id)[0]); if (n) out.push(n); return; }
      if (/^IFCMATERIAL/.test(e.t)) A(id).forEach(function (x) { refs(x).forEach(function (r) { matNames(r, dep + 1, out); }); });
    }
    function readPset(id, into) {
      var e = E[id]; if (!e || e.t !== 'IFCPROPERTYSET') return;
      var a = A(id), pn = sval(a[2]); into[pn] = into[pn] || {};
      refs(a[4]).forEach(function (pid) { var p = E[pid]; if (p && p.t === 'IFCPROPERTYSINGLEVALUE') { var pa = A(pid); into[pn][sval(pa[0])] = sval(pa[2]); } });
    }
    ids.forEach(function (id) {
      var e = E[id], a, objs;
      if (e.t === 'IFCRELDEFINESBYPROPERTIES') { a = A(id); refs(a[4]).forEach(function (o) { readPset(ref(a[5]), slot(o).props); }); }
      else if (e.t === 'IFCRELDEFINESBYTYPE') { a = A(id); refs(a[4]).forEach(function (o) { slot(o).typeId = ref(a[5]); }); }
      else if (e.t === 'IFCRELASSOCIATESMATERIAL') { a = A(id); var mn = []; matNames(ref(a[5]), 0, mn); refs(a[4]).forEach(function (o) { slot(o).mats = slot(o).mats.concat(mn); }); }
      else if (e.t === 'IFCRELASSOCIATESCLASSIFICATION') { a = A(id); var cr = ref(a[5]), c = E[cr], ca = A(cr), src = c && c.t === 'IFCCLASSIFICATIONREFERENCE' ? ref(ca[3]) : '', sysn = src && E[src] ? sval(A(src)[3]) : (c && c.t === 'IFCCLASSIFICATION' ? sval(ca[3]) : ''); refs(a[4]).forEach(function (o) { slot(o).cl.push({ sys: sysn, ref: c && c.t === 'IFCCLASSIFICATIONREFERENCE' ? sval(ca[1]) : '' }); }); }
      else if (e.t === 'IFCRELCONTAINEDINSPATIALSTRUCTURE') { a = A(id); var sp = ref(a[5]); if (E[sp] && E[sp].t === 'IFCBUILDINGSTOREY') refs(a[4]).forEach(function (o) { slot(o).level = sval(A(sp)[2]) || '(niveau sans nom)'; }); }
    });
    var els = [];
    ids.forEach(function (id) {
      var e = E[id], cls = e.t.replace(/(STANDARDCASE|ELEMENTEDCASE)$/, '');
      if (ENT.indexOf(cls) < 0) return;
      var a = A(id), sl = byEl[id] || { props: {}, mats: [], cl: [], level: '', typeId: '' }, pre = '';
      for (var k = 8; k < a.length; k++) if (/^\.[A-Z_0-9]+\.$/.test(a[k])) { pre = a[k].slice(1, -1); break; }
      var props = {}; Object.keys(sl.props).forEach(function (p) { props[p] = Object.assign({}, sl.props[p]); });
      if (sl.typeId && E[sl.typeId]) { var ta = A(sl.typeId); refs(ta[5]).forEach(function (pid) { var tmp = {}; readPset(pid, tmp); Object.keys(tmp).forEach(function (p) { props[p] = Object.assign({}, tmp[p], props[p] || {}); }); }); }
      els.push({ id: '#' + id, cls: cls, name: sval(a[2]), desc: sval(a[3]), objType: sval(a[4]), tag: sval(a[7]), gid: sval(a[0]), predef: pre, level: sl.level, mats: sl.mats, cl: sl.cl, props: props });
    });
    return els;
  }

  /* ================= VÉRIFICATION ================= */
  function matchValue(v, actual) {
    var a = actual == null ? '' : String(actual);
    if (!v) return a !== '';
    if (v.k === 'simple') { var n1 = Number(a), n2 = Number(v.v); return (a !== '' && v.v !== '' && !isNaN(n1) && !isNaN(n2)) ? n1 === n2 : a === v.v; }
    if (v.k === 'enum') return v.v.indexOf(a) >= 0;
    if (v.k === 'pattern') { try { return new RegExp('^(?:' + v.v + ')$').test(a); } catch (e) { return false; } }
    if (v.k === 'bounds') {
      var n = Number(a); if (a === '' || isNaN(n)) return false;
      return !((v.minInclusive != null && n < v.minInclusive) || (v.maxInclusive != null && n > v.maxInclusive) || (v.minExclusive != null && n <= v.minExclusive) || (v.maxExclusive != null && n >= v.maxExclusive));
    }
    return false;
  }
  function vtxt(v) { return !v ? '*' : v.k === 'simple' ? v.v : v.k === 'enum' ? v.v.join('|') : v.k === 'pattern' ? '/' + v.v + '/' : 'bornes'; }
  function up(v) { return v && v.k === 'simple' ? { k: 'simple', v: v.v.toUpperCase() } : v && v.k === 'enum' ? { k: 'enum', v: v.v.map(function (x) { return x.toUpperCase(); }) } : v; }
  function fdesc(f) {
    if (f.t === 'entity') return 'entité ' + vtxt(f.name) + (f.predef ? ' / type ' + vtxt(f.predef) : '');
    if (f.t === 'attribute') return 'attribut ' + vtxt(f.name) + ' = ' + vtxt(f.value);
    if (f.t === 'property') return 'propriété ' + vtxt(f.pset) + '.' + vtxt(f.base) + ' = ' + vtxt(f.value);
    if (f.t === 'material') return 'matériau ' + vtxt(f.value);
    if (f.t === 'classification') return 'classification ' + vtxt(f.value) + ' (' + vtxt(f.system) + ')';
    return 'partie de ' + vtxt(f.entity && f.entity.name);
  }
  function unreadable(f) { /* motif si la facette dépasse ce que le lecteur sait lire, sinon '' */
    if (f.t === 'attribute') return (f.name && f.name.k === 'simple' && AMAP[f.name.v]) ? '' : 'attribut « ' + vtxt(f.name) + ' » non géré (gérés : ' + ATTRS.join(', ') + ')';
    if (f.t === 'partOf') { var rel = String(f.relation || '').toUpperCase(), en = f.entity && f.entity.name; return ((!rel || rel === 'IFCRELCONTAINEDINSPATIALSTRUCTURE' || rel === 'IFCRELAGGREGATES') && en && en.k === 'simple' && en.v.toUpperCase() === 'IFCBUILDINGSTOREY') ? '' : '« partie de » : seul le niveau (IfcBuildingStorey) est lu'; }
    return '';
  }
  function hit(f, el) {
    if (f.t === 'entity') return matchValue(up(f.name), String(el.cls || '').toUpperCase()) && (!f.predef || matchValue(f.predef, el.predef));
    if (f.t === 'attribute') return matchValue(f.value, el[AMAP[f.name.v]]);
    if (f.t === 'property') { var ps = el.props || {}; return Object.keys(ps).some(function (p) { return matchValue(f.pset, p) && Object.keys(ps[p]).some(function (b) { return matchValue(f.base, b) && matchValue(f.value, ps[p][b]); }); }); }
    if (f.t === 'material') return (el.mats || []).some(function (m) { return matchValue(f.value, m); });
    if (f.t === 'classification') return (el.cl || []).some(function (c) { return matchValue(f.value, c.ref) && (!f.system || matchValue(f.system, c.sys)); });
    if (f.t === 'partOf') return !!el.level;
    return false;
  }
  function verify(spec, els) {
    var nv = [], app = [], fails = [], pass = 0, over = 0, un = {};
    spec.app.forEach(function (f) { var m = unreadable(f); if (m) nv.push('Applicabilité : ' + m); });
    if (nv.length) return { status: 'non_verifiable', n: 0, pass: 0, nfail: 0, fails: [], nv: nv };
    els.forEach(function (el) { if (spec.app.every(function (f) { return hit(f, el); })) app.push(el); });
    app.forEach(function (el) {
      var bad = [];
      spec.req.forEach(function (f) {
        var m = unreadable(f); if (m) { un[fdesc(f) + ' — ' + m] = 1; return; }
        var h = hit(f, el);
        if (f.card === 'prohibited' ? h : (f.card === 'required' && !h)) bad.push((f.card === 'prohibited' ? 'Présent à tort : ' : 'Manquant : ') + fdesc(f));
      });
      if (bad.length) { if (fails.length < MAXFAIL) fails.push({ id: el.id, name: el.name || el.gid || '', why: bad.join(' ; ') }); else over++; } else pass++;
    });
    nv = Object.keys(un).map(function (k) { return 'Facette non lisible : ' + k; });
    var nfail = app.length - pass, status;
    if (!app.length) status = spec.minOccurs >= 1 ? 'non_conforme' : 'sans_element';
    else if (nfail) status = 'non_conforme';
    else status = nv.length ? 'non_verifiable' : 'conforme';
    if (!app.length && spec.minOccurs >= 1) fails.push({ id: '', name: '', why: 'Aucun élément concerné alors qu\'au moins un est exigé' });
    return { status: status, n: app.length, pass: pass, nfail: nfail, over: over, fails: fails, nv: nv };
  }
  function verifyAll(ids, els) { return { date: new Date().toISOString(), examined: els.length, results: ids.specs.map(function (sp) { return { id: sp.id, name: sp.name, r: verify(sp, els) }; }) }; }
  function csvText(run) {
    var rows = [['Spécification', 'Statut', 'Concernés', 'Conformes', 'Élément', 'Motif']];
    function cell(c) { c = String(c == null ? '' : c); if (/^[=+\-@]/.test(c)) c = "'" + c; return '"' + c.replace(/"/g, '""') + '"'; }
    ((run && run.results) || []).forEach(function (x) {
      if (!x.r.fails.length && !x.r.nv.length) rows.push([x.name, LBL[x.r.status], x.r.n, x.r.pass, '', '']);
      x.r.fails.forEach(function (f) { rows.push([x.name, LBL[x.r.status], x.r.n, x.r.pass, f.id + ' ' + f.name, f.why]); });
      x.r.nv.forEach(function (m) { rows.push([x.name, LBL[x.r.status], x.r.n, x.r.pass, '', m]); });
    });
    return '\ufeff' + rows.map(function (r) { return r.map(cell).join(';'); }).join('\r\n');
  }

  /* ================= DONNÉES ================= */
  function rules() { return load().filter(function (x) { return x.type === 'regles'; })[0] || { id: uid('RG'), type: 'regles', title: 'Règles IDS', specs: [] }; }
  function saveRules(r) { if (!canW()) { say('Écriture non autorisée.', 'error'); return false; } r.maj = today(); r.par = who(); var a = load().filter(function (x) { return x.id !== r.id; }); a.push(r); save(a); return true; }
  function runs() { return load().filter(function (x) { return x.type === 'run' && (!st.pid || String(x.project) === String(st.pid)); }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }); }
  function models() { try { return (w.EXBS.get(KC) || []).filter(function (x) { return x.type === 'model' && String(x.project) === String(st.pid); }); } catch (e) { return []; } }
  function idbGet(id) { return new Promise(function (ok, ko) { var r = indexedDB.open('exb209coord', 1); r.onupgradeneeded = function () { r.result.createObjectStore('ifc'); }; r.onsuccess = function () { var q = r.result.transaction('ifc').objectStore('ifc').get(id); q.onsuccess = function () { ok(q.result); }; q.onerror = function () { ko(q.error); }; }; r.onerror = function () { ko(r.error); }; }); }
  function toText(buf, name) {
    if (typeof buf === 'string') return Promise.resolve(buf);
    if (buf && buf.arrayBuffer) return buf.arrayBuffer().then(function (b) { return toText(b, name); });
    if (w.EXB_IFC3D && w.EXB_IFC3D.ifcTextOf) return w.EXB_IFC3D.ifcTextOf(buf, name);
    return Promise.resolve(new TextDecoder('utf-8').decode(buf));
  }
  function download(name, text, mime) { var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime })); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
  function parseVal(t) { t = s(t, 500); if (!t) return null; if (/^re:/i.test(t)) return { k: 'pattern', v: t.slice(3) }; if (t.indexOf('|') >= 0) return { k: 'enum', v: t.split('|').map(function (x) { return x.trim(); }) }; return { k: 'simple', v: t }; }

  /* ================= INTERFACE ================= */
  function btn(t, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + t + '</button>'; }
  function sel(id, list, cur) { return '<select id="' + id + '" style="padding:6px;width:100%">' + list.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (o[0] === cur ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select>'; }
  function inp(id, ph) { return '<input id="' + id + '" placeholder="' + esc(ph || '') + '" style="width:100%;padding:6px;box-sizing:border-box">'; }
  function box() { return d.getElementById('exbIdsBox'); }
  function tabHtml() {
    var R = rules(), h = '';
    if (st.tab === 'regles') {
      h += '<p style="font-size:12.5px;color:#475569">IDS 1.0 : exigences d\'information lisibles par machine. <b>' + esc(R.title) + '</b> — ' + R.specs.length + ' spécification(s).</p>';
      h += btn('📥 Importer .ids', 'imp', null, '#0369a1') + '<input type="file" id="exbIdsFile" accept=".ids,.xml" hidden>' + btn('📤 Exporter .ids', 'exp', null, '#475569');
      h += '<ol style="font-size:12.5px;padding-left:20px">' + R.specs.map(function (sp) { return '<li style="margin:6px 0"><b>' + esc(sp.name) + '</b><br>Concerne : ' + esc(sp.app.map(fdesc).join(' ET ') || '—') + '<br>Exige : ' + esc(sp.req.map(function (f) { return f.card + ' ' + fdesc(f); }).join(' ; ') || '—') + ' ' + btn('Supprimer', 'del', sp.id, '#b91c1c') + '</li>'; }).join('') + '</ol>';
      h += '<h4>Nouvelle règle</h4><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">'
        + '<label>Nom' + inp('nrNom', 'Murs : indice de résistance au feu') + '</label><label>Classe IFC' + sel('nrCls', ENT.map(function (e) { return [e, e]; }), 'IFCWALL') + '</label>'
        + '<label>Type d\'exigence' + sel('nrFt', FT.filter(function (x) { return x[0] !== 'entity'; }), 'property') + '</label><label>Cardinalité' + sel('nrCard', CARD, 'required') + '</label>'
        + '<label>Jeu de propriétés / attribut / système' + inp('nrA', 'Pset_WallCommon') + '</label><label>Propriété / référence' + inp('nrB', 'FireRating') + '</label>'
        + '<label>Valeur (vide = présente ; a|b = liste ; re:motif)' + inp('nrV', '') + '</label></div>' + btn('➕ Ajouter la règle', 'add');
    } else if (st.tab === 'verif') {
      h += '<label>Projet <select id="exbIdsPid" style="padding:6px"><option value="">—</option>' + projs().map(function (p) { return '<option value="' + esc(p.id) + '"' + (String(p.id) === String(st.pid) ? ' selected' : '') + '>' + esc(p.nom || p.name || p.titre || p.title || p.id) + '</option>'; }).join('') + '</select></label>';
      var M = st.pid ? models() : [];
      h += '<p style="font-size:12.5px">Modèles IFC conservés (Coordination IFC / BCF) : ' + (M.length ? '' : '<i>aucun</i>') + '</p>' + M.map(function (m) { return '<label style="display:block;font-size:12.5px"><input type="checkbox" data-m="' + esc(m.id) + '"' + (st.sel[m.id] !== false ? ' checked' : '') + '> ' + esc(m.name || m.id) + '</label>'; }).join('');
      h += '<p style="font-size:12.5px">Ou ajouter des fichiers IFC : <input type="file" id="exbIdsIfc" accept=".ifc,.ifczip,.zip" multiple></p>' + btn('▶ Vérifier', 'run');
      if (st.busy) h += '<p style="color:#b45309">' + esc(st.busy) + '</p>';
      if (st.run) {
        h += '<h4>Résultat du ' + esc(st.run.date.slice(0, 16).replace('T', ' ')) + ' — ' + st.run.examined + ' élément(s) examiné(s)</h4>';
        h += st.run.results.map(function (x) { var c = x.r.status === 'conforme' ? '#15803d' : x.r.status === 'non_conforme' ? '#b91c1c' : '#b45309'; return '<div style="border-top:1px solid #e2e8f0;padding:6px 0;font-size:12.5px"><b>' + esc(x.name) + '</b> — <b style="color:' + c + '">' + LBL[x.r.status] + '</b> (' + x.r.pass + '/' + x.r.n + ')' + x.r.fails.slice(0, 20).map(function (f) { return '<br>• ' + esc(f.id + ' ' + f.name + ' : ' + f.why); }).join('') + (x.r.nfail > 20 ? '<br>… ' + (x.r.nfail - 20) + ' autre(s) (voir CSV)' : '') + x.r.nv.map(function (m) { return '<br>⚠ ' + esc(m); }).join('') + '</div>'; }).join('');
        h += btn('CSV', 'csv', null, '#475569') + btn('🖨 Rapport', 'print', null, '#0369a1');
      }
    } else {
      h += '<table style="font-size:12.5px;border-collapse:collapse;width:100%"><tr><th align="left">Date</th><th align="left">Par</th><th align="left">Modèles</th><th align="left">Résumé</th></tr>' + runs().slice(0, 50).map(function (r) { return '<tr style="border-top:1px solid #e2e8f0"><td>' + esc(String(r.date).slice(0, 16).replace('T', ' ')) + '</td><td>' + esc(r.par || '') + '</td><td>' + esc((r.models || []).join(', ')) + '</td><td>' + (r.res || []).map(function (x) { return esc(x.name + ' : ' + LBL[x.status]); }).join('<br>') + '</td></tr>'; }).join('') + '</table>';
    }
    return h;
  }
  function paint() {
    var b = box(); if (!b) return;
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><b style="align-self:center;margin-right:8px">📐 Règles IDS</b>' + [['regles', 'Règles'], ['verif', 'Vérification'], ['histo', 'Historique']].map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:8px;background:' + (st.tab === t[0] ? '#0f766e;color:#fff' : '#e2e8f0') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + tabHtml();
  }
  function runCheck() {
    var R = rules(); if (!R.specs.length) { st.busy = 'Aucune règle : importez un fichier .ids ou ajoutez une règle.'; return paint(); }
    var jobs = [], names = [], b = box();
    models().forEach(function (m) { if (b.querySelector('[data-m="' + m.id + '"]') && b.querySelector('[data-m="' + m.id + '"]').checked) { names.push(m.name || m.id); jobs.push(idbGet(m.id).then(function (buf) { if (!buf) throw new Error('Modèle « ' + (m.name || m.id) + ' » absent de l\'appareil : rechargez-le dans la coordination.'); return toText(buf, m.name || 'm.ifc'); })); } });
    var fi = d.getElementById('exbIdsIfc'); if (fi && fi.files) for (var i = 0; i < fi.files.length; i++) { if (fi.files[i].size > MAXIFC) { st.busy = fi.files[i].name + ' : fichier trop volumineux.'; return paint(); } names.push(fi.files[i].name); jobs.push(toText(fi.files[i], fi.files[i].name)); }
    if (!jobs.length) { st.busy = 'Choisissez au moins un modèle IFC.'; return paint(); }
    st.busy = 'Lecture des modèles…'; paint();
    Promise.all(jobs).then(function (T) {
      var els = []; T.forEach(function (t) { els = els.concat(elementsFromIFC(t)); });
      st.run = verifyAll(R, els); st.busy = '';
      if (canW()) { var a = load(); a.push({ id: uid('RUN'), type: 'run', project: st.pid, date: st.run.date, par: who(), title: R.title, models: names, examined: els.length, res: st.run.results.map(function (x) { return { name: x.name, status: x.r.status, n: x.r.n, pass: x.r.pass }; }) }); var runsOnly = a.filter(function (x) { return x.type === 'run'; }); if (runsOnly.length > MAXREC) { var drop = runsOnly.slice(0, runsOnly.length - MAXREC).map(function (x) { return x.id; }); a = a.filter(function (x) { return drop.indexOf(x.id) < 0; }); } save(a); }
      say('Vérification terminée'); paint();
    }).catch(function (e) { st.busy = 'Échec : ' + (e && e.message || e); paint(); });
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i'), R;
    if (a === 'close') { var o = d.getElementById('exbIds'); if (o) o.remove(); return; }
    if (a === 'tab') { st.tab = i; return paint(); }
    if (a === 'imp') { var f = d.getElementById('exbIdsFile'); return f && f.click(); }
    if (a === 'exp') return download('regles-' + today() + '.ids', toXML(rules()), 'application/xml');
    if (a === 'del') { R = rules(); R.specs = R.specs.filter(function (x) { return x.id !== i; }); if (saveRules(R)) paint(); return; }
    if (a === 'add') {
      var g = function (id) { return d.getElementById(id).value; }, ft = g('nrFt'), A = parseVal(g('nrA')), B = parseVal(g('nrB')), V = parseVal(g('nrV')), card = g('nrCard'), fac;
      if (!s(g('nrNom'), 200)) return say('Nom obligatoire.', 'error');
      if (ft === 'property') { if (!A || !B) return say('Jeu de propriétés et propriété obligatoires.', 'error'); fac = { t: 'property', pset: A, base: B, value: V, dataType: 'IFCLABEL', card: card }; }
      else if (ft === 'attribute') { if (!A || A.k !== 'simple' || !AMAP[A.v]) return say('Attribut parmi : ' + ATTRS.join(', '), 'error'); fac = { t: 'attribute', name: A, value: V, card: card }; }
      else if (ft === 'material') fac = { t: 'material', value: V || A, card: card };
      else if (ft === 'classification') fac = { t: 'classification', value: V || B, system: A, card: card };
      else fac = { t: 'partOf', relation: 'IfcRelContainedInSpatialStructure', entity: { name: { k: 'simple', v: 'IFCBUILDINGSTOREY' } }, card: card };
      R = rules(); R.specs.push({ id: uid('spec'), name: s(g('nrNom'), 200), ifcVersion: 'IFC4', description: '', minOccurs: 0, app: [{ t: 'entity', name: { k: 'simple', v: g('nrCls') }, predef: null, card: 'required' }], req: [fac] }); if (saveRules(R)) paint(); return;
    }
    if (a === 'run') return runCheck();
    if (a === 'csv') return download('verification-ids-' + today() + '.csv', csvText(st.run), 'text/csv');
    if (a === 'print') {
      var win = w.open('', '_blank'); if (!win) return say('Fenêtre bloquée par le navigateur.', 'error');
      win.document.write('<html><head><meta charset="utf-8"><title>Vérification IDS</title><style>body{font:12px Arial;margin:20px}td,th{border:1px solid #999;padding:3px 7px;text-align:left}table{border-collapse:collapse;width:100%}</style></head><body><h2>Vérification des règles IDS — ' + esc(pname(st.pid)) + '</h2><p>' + esc(st.run.date.slice(0, 16).replace('T', ' ')) + ' — ' + st.run.examined + ' élément(s) examiné(s)</p><table><tr><th>Spécification</th><th>Statut</th><th>Conformes / concernés</th><th>Écarts et limites</th></tr>'
        + st.run.results.map(function (x) { return '<tr><td>' + esc(x.name) + '</td><td>' + LBL[x.r.status] + '</td><td>' + x.r.pass + '/' + x.r.n + '</td><td>' + x.r.fails.slice(0, 50).map(function (f) { return esc(f.id + ' ' + f.name + ' : ' + f.why); }).join('<br>') + x.r.nv.map(function (m) { return '<br>⚠ ' + esc(m); }).join('') + '</td></tr>'; }).join('')
        + '</table><p style="font-size:11px">Contrôle automatique limité aux facettes lues par l\'application ; une facette non lue est signalée « non vérifiable ». Ne remplace pas la validation par un outil IDS tiers ni par l\'architecte.</p></body></html>'); win.document.close();
    }
  }
  function onChange(ev) {
    var t = ev.target;
    if (t.id === 'exbIdsPid') { st.pid = t.value; st.run = null; return paint(); }
    if (t.getAttribute && t.getAttribute('data-m')) { st.sel[t.getAttribute('data-m')] = t.checked; return; }
    if (t.id === 'exbIdsFile' && t.files[0]) {
      if (!canW()) return say('Écriture non autorisée.', 'error');
      var fr = new FileReader();
      fr.onload = function () { try { var P = parseIDS(fr.result), R = rules(); R.title = P.title; R.specs = P.specs; if (saveRules(R)) say(P.specs.length + ' spécification(s) importée(s)'); } catch (e) { say(e.message, 'error'); } paint(); };
      fr.readAsText(t.files[0]);
    }
  }
  function open() {
    if (!canR()) return say('Accès non autorisé.', 'error');
    if (!st.pid) { var P = projs(); st.pid = (function () { try { return localStorage.getItem('exb_active_project'); } catch (e) { return ''; } })() || (P[0] && P[0].id) || ''; }
    var o = d.getElementById('exbIds'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbIds'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbIdsBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('click', onClick); c.addEventListener('change', onChange); paint();
  }
  var API = { open: open, parseXml: parseXml, parseIDS: parseIDS, toXML: toXML, matchValue: matchValue, verify: verify, verifyAll: verifyAll, elementsFromIFC: elementsFromIFC, csvText: csvText, ENT: ENT };
  w.EXBIDS = API;
  function ui() {
    var b = d.getElementById('exbMatBtn') || d.getElementById('exbSiteBtn') || d.getElementById('exbCoordBtn') || d.getElementById('exbArcPBtn') || d.getElementById('exbArcBtn');
    if (!b || d.getElementById('exbIdsBtn')) return;
    var k = d.createElement('button'); k.id = 'exbIdsBtn'; k.className = 'muted'; k.textContent = '📐 Règles IDS'; k.onclick = open; if (!canR()) k.setAttribute('data-exbrole', 'hide'); b.parentNode.appendChild(k);
  }
  if (d.documentElement && w.MutationObserver) { new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true }); d.addEventListener('DOMContentLoaded', ui); }
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'arch_ids', name: 'Règles IDS', version: '1.0.0', area: 'Architecture', deps: [], collections: [KEY] }); } catch (e) { }
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { documentElement: null, getElementById: function () { return null; }, addEventListener: function () { } });
