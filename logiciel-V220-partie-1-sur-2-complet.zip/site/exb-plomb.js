/* Excellencia Building — BUREAU PLOMBERIE / HVAC V212 (cahier des charges V1.0, §5.8)
 * Fonctions du cahier : réseaux, débits, pertes de charge, équipements, nomenclatures, coordination BIM.
 *   1. EAU (plomberie) : débit de pointe par simultanéité (Qp = k·Σq/√(n−1), borné), tronçons : vitesse, Reynolds, perte de charge linéaire
 *      (Darcy-Weisbach, frottement de Swamee-Jain) + singularités (majoration saisie) + dénivelée, pression résiduelle au bout du réseau,
 *      diamètre proposé selon la vitesse maximale. La table des diamètres est INDICATIVE et à confirmer ; k, vitesse max, rugosité, viscosité,
 *      pression disponible et pression minimale sont SAISIS par le projet (aucune valeur normative n'est imposée par le logiciel).
 *   2. AIR (HVAC) : gaines circulaires : vitesse, perte de charge (Pa), diamètre proposé selon la vitesse maximale.
 *   3. CHARGES THERMIQUES : SOMME de postes saisis (enveloppe U·A·ΔT, charges internes en W, air neuf ρ·cp·Q·ΔT) — aucune ratio caché.
 *   4. ÉQUIPEMENTS : nomenclature (repère, désignation, local, quantité, puissance électrique, GlobalId IFC contrôlé), CSV, total électrique.
 * Hors périmètre de cette étape (signalé, jamais simulé) : bouclage ECS, réseaux maillés, eaux usées/pluviales, psychrométrie, bilan thermique réglementaire.
 * Garde-fou : moteurs déterministes, aucune IA ; visa nominatif (vérificateur ≠ auteur). Données : clé exb_plomb.
 * Pour retirer : supprimer la balise <script src="exb-plomb.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBPlomb) return;
  var K = 'exb_plomb', G = 9.81, RGUID = /^[0-9A-Za-z_$]{22}$/;
  var DN0 = '15;13\n20;16\n25;20\n32;26\n40;32\n50;40\n63;51\n75;61\n90;73\n110;90';
  var GA0 = '100\n125\n160\n200\n250\n315\n400\n500\n630\n800\n1000';

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function num(v, def) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : (def === undefined ? NaN : def); }
  function fx(v, n) { return isFinite(v) ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: n, maximumFractionDigits: n }) : '—'; }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function who() { return ask('Votre nom (signature nominative, non qualifiée) :', '').then(function (v) { return String(v || '').trim(); }); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id) }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function san(t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/→/g, '->').replace(/²/g, '2').replace(/³/g, '3').replace(/×/g, 'x').replace(/√/g, 'rac ').replace(/·/g, '.').replace(/Δ/g, 'delta ').replace(/ρ/g, 'rho '); }
  function csv(rows, name) { var t = '\ufeff' + rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); try { var b = new Blob([t], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = (w.URL || w.webkitURL).createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); } catch (e) { toast('Export impossible : ' + e.message, 'error'); } }
  function pdf(o) { if (!w.EXBPdf) return toast('Module PDF indisponible.', 'error'); try { return w.EXBPdf.make(o); } catch (e) { toast('PDF impossible : ' + e.message, 'error'); } }

  /* ========================================================== MOTEURS ========================================================== */
  function lignes(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return l && l.charAt(0) !== '#'; }); }
  function champs(l) { return l.split(/[;\t]/).map(function (x) { return x.trim(); }); }
  /* Frottement (Darcy) : laminaire 64/Re ; turbulent : Swamee-Jain. D en m, eps en m. */
  function frottement(Re, D, eps) { if (!(Re > 0)) return 0; if (Re < 2000) return 64 / Re; var a = Math.log10(eps / (3.7 * D) + 5.74 / Math.pow(Re, 0.9)); return 0.25 / (a * a); }
  /* Tronçon fluide : Q (m³/s), D (m), L (m), K (somme des coefficients de singularité), rho (kg/m³), nu (m²/s), eps (m) → v, Re, f, dP (Pa). */
  function troncon(o) {
    var A = Math.PI * o.D * o.D / 4, v = o.Q / A, Re = v * o.D / o.nu, f = frottement(Re, o.D, o.eps), dyn = o.rho * v * v / 2, lin = f * o.L / o.D * dyn, sing = (o.K || 0) * dyn;
    return { v: v, Re: Re, f: f, dyn: dyn, lin: lin, sing: sing, dP: lin + sing };
  }
  /* Appareils : « appareil ; débit de base l/s ; nombre » → Σq, n, Qp. Qp = k·Σq/√(n−1) (n ≥ 2), jamais < plus gros appareil ni > Σq. */
  function parseAppareils(t) { var A = [], err = []; lignes(t).forEach(function (l, i) { var f = champs(l), q = num(f[1]), n = f[2] === '' || f[2] === undefined ? 1 : num(f[2]); if (!f[0] || !(q > 0) || !(n >= 1) || n !== Math.floor(n)) err.push('Appareils ligne ' + (i + 1) + ' : « appareil ; débit l/s > 0 ; nombre entier ≥ 1 ».'); else A.push({ nom: f[0], q: q, n: n }); }); return { app: A, erreurs: err }; }
  function debitPointe(A, k) {
    var s = 0, n = 0, mx = 0; A.forEach(function (a) { s += a.q * a.n; n += a.n; mx = Math.max(mx, a.q); });
    if (!n) return { ok: false, msg: 'Aucun appareil.' };
    var kk = isFinite(k) && k > 0 ? k : 1, qp = n >= 2 ? kk * s / Math.sqrt(n - 1) : s; qp = Math.min(s, Math.max(mx, qp));
    return { ok: true, somme: s, n: n, qp: qp, plusGros: mx, k: kk };
  }
  function parseDN(t) { var m = [], err = []; lignes(t).forEach(function (l, i) { var f = champs(l).map(num); if (!(f[0] > 0) || !(f[1] > 0)) err.push('Table des diamètres ligne ' + (i + 1) + ' illisible.'); else m.push({ dn: f[0], di: f[1] }); }); m.sort(function (a, b) { return a.di - b.di; }); return { rows: m, erreurs: err }; }
  /* Tronçons d'eau (un seul trajet depuis la source) : « nom ; Q l/s (ou Qp) ; L m ; DN (fac.) ; ΔZ m (+ = montée, fac.) » */
  function parseTronc(t, qp) {
    var T = [], err = [];
    lignes(t).forEach(function (l, i) {
      var f = champs(l), q = /^qp$/i.test(f[1] || '') ? qp : num(f[1]), c = { nom: f[0], q: q, L: num(f[2]), dn: f[3] ? num(f[3]) : null, dz: f[4] ? num(f[4]) : 0, ligne: i + 1 };
      var m = !c.nom ? 'nom manquant' : !(c.q > 0) ? 'débit invalide (nombre en l/s ou « Qp »' + (isFinite(qp) ? '' : ' — aucun appareil saisi') + ')' : !(c.L > 0) ? 'longueur invalide' : (c.dn !== null && !(c.dn > 0)) ? 'DN invalide' : !isFinite(c.dz) ? 'dénivelée invalide' : '';
      if (m) err.push({ ligne: i + 1, msg: m }); else T.push(c);
    });
    return { tronc: T, erreurs: err };
  }
  function reseauEau(T, DN, p) {
    var rows = [], cum = 0, dz = 0;
    T.forEach(function (c) {
      var di = null, dn = c.dn, prop = false;
      if (dn !== null) { var r = DN.filter(function (x) { return x.dn === dn; })[0]; di = r ? r.di : null; }
      else { for (var i = 0; i < DN.length; i++) { var vv = (c.q / 1000) / (Math.PI * Math.pow(DN[i].di / 1000, 2) / 4); if (vv <= p.vmax + 1e-9) { dn = DN[i].dn; di = DN[i].di; prop = true; break; } } }
      if (di === null) { rows.push({ c: c, ok: false, msg: dn === null ? 'Aucun diamètre de la table ne respecte la vitesse maximale.' : 'DN ' + dn + ' absent de la table des diamètres.' }); return; }
      var t = troncon({ Q: c.q / 1000, D: di / 1000, L: c.L, K: 0, rho: p.rho, nu: p.nu, eps: p.eps }), maj = t.lin * (1 + p.maj / 100), dp = maj, hz = c.dz * p.rho * G;
      cum += dp + hz; dz += c.dz;
      rows.push({ c: c, dn: dn, di: di, prop: prop, v: t.v, Re: t.Re, f: t.f, dPlin: t.lin, dP: dp, dPcum: cum, ok: t.v <= p.vmax + 1e-9, msg: t.v > p.vmax + 1e-9 ? 'Vitesse ' + fx(t.v, 2) + ' m/s > ' + fx(p.vmax, 2) + ' m/s.' : '' });
    });
    var bad = rows.some(function (r) { return r.dPcum === undefined; });
    return { rows: rows, perte: cum, pRes: bad ? NaN : p.pDispo - cum / 1000, dz: dz };
  }
  /* Gaines : « nom ; Q m³/h ; L m ; D mm (fac.) ; K (fac.) » */
  function parseGaines(t) {
    var T = [], err = [];
    lignes(t).forEach(function (l, i) { var f = champs(l), c = { nom: f[0], Q: num(f[1]), L: num(f[2]), D: f[3] ? num(f[3]) : null, K: f[4] ? num(f[4]) : 0 }, m = !c.nom ? 'nom manquant' : !(c.Q > 0) ? 'débit m³/h invalide' : !(c.L > 0) ? 'longueur invalide' : (c.D !== null && !(c.D > 0)) ? 'diamètre invalide' : !(c.K >= 0) ? 'K invalide' : ''; if (m) err.push({ ligne: i + 1, msg: m }); else T.push(c); });
    return { gaines: T, erreurs: err };
  }
  function reseauAir(T, diam, p) {
    var rows = [], cum = 0;
    T.forEach(function (c) {
      var D = c.D, prop = false, q = c.Q / 3600;
      if (D === null) { for (var i = 0; i < diam.length; i++) { var vv = q / (Math.PI * Math.pow(diam[i] / 1000, 2) / 4); if (vv <= p.vmaxA + 1e-9) { D = diam[i]; prop = true; break; } } }
      if (D === null) { rows.push({ c: c, ok: false, msg: 'Aucun diamètre de la liste ne respecte la vitesse maximale.' }); return; }
      var t = troncon({ Q: q, D: D / 1000, L: c.L, K: c.K, rho: p.rhoA, nu: p.nuA, eps: p.epsA }); cum += t.dP;
      rows.push({ c: c, D: D, prop: prop, v: t.v, Re: t.Re, f: t.f, dP: t.dP, dPcum: cum, ok: t.v <= p.vmaxA + 1e-9, msg: t.v > p.vmaxA + 1e-9 ? 'Vitesse ' + fx(t.v, 2) + ' m/s > ' + fx(p.vmaxA, 2) + ' m/s.' : '' });
    });
    return { rows: rows, perte: cum };
  }
  /* Charges thermiques : enveloppe « libellé ; U W/m²K ; A m² ; ΔT K », internes « libellé ; W », air neuf « libellé ; Q m³/h ; ΔT K » */
  function charges(env, int, air, p) {
    var o = { env: [], int: [], air: [], erreurs: [], total: 0 }, add = function (t, id, v) { o[t].push(v); o.total += v.W; };
    lignes(env).forEach(function (l, i) { var f = champs(l), U = num(f[1]), A = num(f[2]), dT = num(f[3]); if (!f[0] || !(U >= 0) || !(A > 0) || !isFinite(dT)) o.erreurs.push('Enveloppe ligne ' + (i + 1) + ' : « libellé ; U ; A ; ΔT ».'); else add('env', i, { nom: f[0], W: U * A * dT }); });
    lignes(int).forEach(function (l, i) { var f = champs(l), W = num(f[1]); if (!f[0] || !isFinite(W)) o.erreurs.push('Charges internes ligne ' + (i + 1) + ' : « libellé ; W ».'); else add('int', i, { nom: f[0], W: W }); });
    lignes(air).forEach(function (l, i) { var f = champs(l), Q = num(f[1]), dT = num(f[2]); if (!f[0] || !(Q > 0) || !isFinite(dT)) o.erreurs.push('Air neuf ligne ' + (i + 1) + ' : « libellé ; Q m³/h ; ΔT ».'); else add('air', i, { nom: f[0], W: p.rhoA * p.cpA * 1000 * (Q / 3600) * dT }); });
    return o;
  }
  /* Équipements : « repère ; désignation ; local ; quantité ; kW électrique (fac.) ; GlobalId IFC (fac.) » */
  function parseEquip(t) {
    var E = [], err = [], seen = {};
    lignes(t).forEach(function (l, i) { var f = champs(l), q = num(f[3]), kw = f[4] ? num(f[4]) : 0, m = !f[0] ? 'repère manquant' : !f[1] ? 'désignation manquante' : !(q > 0) ? 'quantité invalide' : !(kw >= 0) ? 'puissance invalide' : seen[f[0]] ? 'repère « ' + f[0] + ' » en double' : (f[5] && !RGUID.test(f[5])) ? 'GlobalId IFC invalide (22 caractères [0-9A-Za-z_$])' : ''; if (m) err.push({ ligne: i + 1, msg: m }); else { seen[f[0]] = 1; E.push({ rep: f[0], des: f[1], local: f[2] || '', q: q, kw: kw, guid: f[5] || '' }); } });
    var tot = 0; E.forEach(function (e) { tot += e.q * e.kw; });
    return { equip: E, erreurs: err, totalKw: tot };
  }

  /* ========================================================== DOSSIER ========================================================== */
  function all() { return rd(K); }
  function find(id) { return all().filter(function (x) { return x.id === id; })[0]; }
  function saveDos(x) { var a = all(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i < 0) a.push(x); else a[i] = x; return wr(K, a); }
  function nouveau() { var n = all().length + 1, y = new Date().getFullYear(); return { id: uid('PLB'), no: 'PLB-' + y + '-' + String(n).padStart(3, '0'), statut: 'Brouillon', titre: '', project_id: '', site: '', date: new Date().toISOString().slice(0, 10), auteur: '', norme: { nom: '', edition: '' },
    par: { rho: '1000', nu: '0,000001', eps: '0,0015', vmax: '', maj: '', pDispo: '', pMin: '', k: '', rhoA: '1,2', nuA: '0,000015', epsA: '0,09', vmaxA: '', cpA: '1,006' }, dnTxt: DN0, dnConf: null, gaTxt: GA0, appTxt: '', troncTxt: '', airTxt: '', envTxt: '', intTxt: '', neufTxt: '', eqTxt: '', histo: [], cree: Date.now() }; }
  function params(x) { var q = x.par; return { rho: num(q.rho, 1000), nu: num(q.nu, 1e-6), eps: num(q.eps, 0.0015) / 1000, vmax: num(q.vmax), maj: num(q.maj, 0), pDispo: num(q.pDispo), pMin: num(q.pMin), k: num(q.k), rhoA: num(q.rhoA, 1.2), nuA: num(q.nuA, 1.5e-5), epsA: num(q.epsA, 0.09) / 1000, vmaxA: num(q.vmaxA), cpA: num(q.cpA, 1.006) }; }
  function calc(x) {
    var p = params(x), ap = parseAppareils(x.appTxt), qp = debitPointe(ap.app, p.k), dn = parseDN(x.dnTxt), tr = parseTronc(x.troncTxt, qp.ok ? qp.qp : NaN), gaD = lignes(x.gaTxt).map(num).filter(function (v) { return v > 0; }).sort(function (a, b) { return a - b; }), ga = parseGaines(x.airTxt);
    return { p: p, ap: ap, qp: qp, dn: dn, tr: tr, eau: isFinite(p.vmax) ? reseauEau(tr.tronc, dn.rows, p) : null, ga: ga, air: isFinite(p.vmaxA) ? reseauAir(ga.gaines, gaD, p) : null, ch: charges(x.envTxt, x.intTxt, x.neufTxt, p), eq: parseEquip(x.eqTxt) };
  }
  function verif(x) {
    var a = [], add = function (n, id, m) { a.push({ niveau: n, id: id, msg: m }); }, k = calc(x), p = k.p;
    if (!k.tr.tronc.length && !k.ga.gaines.length && !k.ch.total && !k.eq.equip.length) add('bloquant', 'PLB-1', 'Aucun réseau, charge ni équipement saisi : rien à vérifier.');
    if (!String(x.norme.nom || '').trim() || !String(x.norme.edition || '').trim()) add('bloquant', 'PLB-2', 'Norme et édition non déclarées pour ce dossier.');
    if (!String(x.auteur || '').trim()) add('bloquant', 'PLB-3', 'Auteur de la note de calcul non renseigné.');
    if (k.tr.tronc.length && !isFinite(p.vmax)) add('bloquant', 'PLB-4', 'Vitesse maximale de l’eau non fixée par le projet.');
    if (k.ga.gaines.length && !isFinite(p.vmaxA)) add('bloquant', 'PLB-4', 'Vitesse maximale de l’air non fixée par le projet.');
    if (k.tr.tronc.length && !x.dnConf) add('bloquant', 'PLB-5', 'Table des diamètres non confirmée par un responsable nommé (valeurs préremplies indicatives).');
    if (k.eau) { k.eau.rows.forEach(function (r) { if (!r.ok) add('bloquant', 'PLB-6', 'Eau / ' + r.c.nom + ' : ' + r.msg); else if (r.prop) add('alerte', 'PLB-7', 'Eau / ' + r.c.nom + ' : DN ' + r.dn + ' PROPOSÉ par le calcul, non imposé — à valider.'); });
      if (isFinite(p.pDispo) && isFinite(p.pMin)) { if (isFinite(k.eau.pRes) && k.eau.pRes < p.pMin - 1e-9) add('bloquant', 'PLB-8', 'Pression résiduelle ' + fx(k.eau.pRes, 1) + ' kPa < pression minimale ' + fx(p.pMin, 1) + ' kPa.'); } else if (k.tr.tronc.length) add('alerte', 'PLB-8', 'Pression disponible ou pression minimale non saisie : pression résiduelle non jugée.'); }
    if (k.air) k.air.rows.forEach(function (r) { if (!r.ok) add('bloquant', 'PLB-6', 'Air / ' + r.c.nom + ' : ' + r.msg); else if (r.prop) add('alerte', 'PLB-7', 'Air / ' + r.c.nom + ' : diamètre ' + r.D + ' mm PROPOSÉ par le calcul, non imposé — à valider.'); });
    k.ap.erreurs.concat(k.dn.erreurs, k.ch.erreurs).forEach(function (m) { add('alerte', 'PLB-9', m); });
    k.tr.erreurs.concat(k.ga.erreurs, k.eq.erreurs).forEach(function (e) { add('alerte', 'PLB-9', 'Ligne ' + e.ligne + ' : ' + e.msg); });
    if (k.qp.ok && !(isFinite(p.k) && p.k > 0)) add('alerte', 'PLB-10', 'Coefficient de simultanéité k non fixé : 1 retenu.');
    return a;
  }
  function bloque(x) { return verif(x).filter(function (v) { return v.niveau === 'bloquant'; }); }

  /* ========================================================== INTERFACE ========================================================== */
  var TAB = 'ref', GID = null;
  function box() { return d.getElementById('exbPlombBox'); }
  function ro(x) { return x.statut !== 'Brouillon'; }
  function btn(l, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + l + '</button>'; }
  function lab(t, h) { return '<label style="display:block;font-size:12.5px;color:#334155">' + t + h + '</label>'; }
  function inp(f, v, dis) { return '<input data-f="' + f + '" value="' + esc(v) + '"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px;box-sizing:border-box">'; }
  function ta(f, v, dis, rows, ph) { return '<textarea data-f="' + f + '" rows="' + (rows || 5) + '"' + (dis ? ' disabled' : '') + ' placeholder="' + esc(ph || '') + '" style="width:100%;box-sizing:border-box;padding:6px;font:12.5px monospace">' + esc(v) + '</textarea>'; }
  function table(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr>' + h.map(function (c) { return '<th style="text-align:left;border-bottom:1px solid #cbd5e1;padding:4px 8px">' + c + '</th>'; }).join('') + '</tr>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="border-bottom:1px solid #e2e8f0;padding:4px 8px">' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</table></div>'; }
  function alertesHtml(A) { return A.length ? '<ul style="margin:6px 0;padding-left:18px;font-size:12.5px">' + A.map(function (a) { return '<li style="color:' + (a.niveau === 'bloquant' ? '#b91c1c' : '#b45309') + '">' + esc(a.id) + ' — ' + esc(a.msg) + '</li>'; }).join('') + '</ul>' : '<p style="color:#15803d;font-size:12.5px">Aucune alerte.</p>'; }
  function grid(h) { return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + h + '</div>'; }
  function errs(k) { var e = k.map(function (m) { return typeof m === 'string' ? m : 'Ligne ' + m.ligne + ' : ' + m.msg; }); return e.length ? '<ul style="font-size:12.5px;color:#b45309;padding-left:18px">' + e.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>' : ''; }
  function liste0() { var a = all(); return '<h3 style="margin:6px 0">🚿 Plomberie / HVAC</h3><p style="font-size:12.5px;color:#475569">Débits, pertes de charge, gaines, charges thermiques et nomenclature des équipements. Calculs déterministes : ils ne remplacent pas la note d’un ingénieur.</p>' + btn('➕ Nouveau dossier plomberie / HVAC', 'new') + (a.length ? table(['N°', 'Titre', 'Projet', 'Statut', ''], a.map(function (r) { return [esc(r.no), esc(r.titre || '—'), esc(pnom(r.project_id)), esc(r.statut), btn('Ouvrir', 'open', r.id)]; })) : '<p>Aucun dossier.</p>'); }
  function tabRef(x, dis) {
    var q = x.par, h = grid(lab('Norme (nom)', inp('norme.nom', x.norme.nom, dis)) + lab('Édition / année', inp('norme.edition', x.norme.edition, dis)));
    h += '<h4 style="margin:10px 0 4px">Eau</h4>' + grid(lab('Masse volumique (kg/m³)', inp('par.rho', q.rho, dis)) + lab('Viscosité cinématique (m²/s)', inp('par.nu', q.nu, dis)) + lab('Rugosité (mm)', inp('par.eps', q.eps, dis)) + lab('Vitesse max (m/s) — projet', inp('par.vmax', q.vmax, dis)) + lab('Majoration singularités (%)', inp('par.maj', q.maj, dis)) + lab('Pression disponible (kPa)', inp('par.pDispo', q.pDispo, dis)) + lab('Pression minimale (kPa)', inp('par.pMin', q.pMin, dis)) + lab('Coefficient de simultanéité k', inp('par.k', q.k, dis)));
    h += '<h4 style="margin:10px 0 4px">Air</h4>' + grid(lab('Masse volumique (kg/m³)', inp('par.rhoA', q.rhoA, dis)) + lab('Viscosité cinématique (m²/s)', inp('par.nuA', q.nuA, dis)) + lab('Rugosité gaine (mm)', inp('par.epsA', q.epsA, dis)) + lab('Vitesse max (m/s) — projet', inp('par.vmaxA', q.vmaxA, dis)) + lab('Chaleur massique (kJ/kg·K)', inp('par.cpA', q.cpA, dis)));
    h += '<h4 style="margin:10px 0 4px">Diamètres de tuyaux : DN ; diamètre intérieur (mm)</h4><p style="font-size:12px;color:#b45309">Table INDICATIVE : le diamètre intérieur dépend de la matière et de la série de vos tuyaux. Remplacez par vos références puis confirmez.</p>' + ta('dnTxt', x.dnTxt, dis, 6);
    h += '<p style="font-size:12.5px">' + (x.dnConf ? '<span style="color:#15803d">Table confirmée par ' + esc(x.dnConf.par) + '</span>' : '<span style="color:#b91c1c">Table non confirmée</span>') + '</p>' + (!dis && !x.dnConf ? btn('Confirmer cette table', 'confdn', null, '#7c3aed') : '');
    h += lab('Diamètres de gaines circulaires disponibles (mm, un par ligne)', ta('gaTxt', x.gaTxt, dis, 4));
    return h;
  }
  function tabEau(x, dis) {
    var k = calc(x), h = lab('Appareils (un par ligne : appareil ; débit de base l/s ; nombre)', ta('appTxt', x.appTxt, dis, 4, 'Lavabo;0,1;6\nDouche;0,2;4\nWC;0,1;6')) + errs(k.ap.erreurs);
    if (k.qp.ok) h += '<p style="font-size:12.5px">Σ débits : ' + fx(k.qp.somme, 2) + ' l/s — ' + k.qp.n + ' appareil(s) — <b>débit de pointe Qp : ' + fx(k.qp.qp, 3) + ' l/s</b> (méthode k·Σq/√(n−1), k = ' + fx(k.qp.k, 2) + ', borné au plus gros appareil et à Σq).</p>';
    h += lab('Tronçons d’un même trajet depuis la source (un par ligne : nom ; débit l/s ou Qp ; L m ; [DN] ; [ΔZ m, + = montée])', ta('troncTxt', x.troncTxt, dis, 5, 'Colonne;Qp;12;;3\nDérivation;0,3;8;20;0')) + errs(k.tr.erreurs);
    if (k.eau && k.eau.rows.length) { h += table(['Tronçon', 'Q (l/s)', 'DN', 'v (m/s)', 'Re', 'ΔP lin. (kPa)', 'ΔP cumulée (kPa)', 'Contrôle'], k.eau.rows.map(function (r) { return r.dn === undefined ? [esc(r.c.nom), fx(r.c.q, 3), '—', '—', '—', '—', '—', '<b style="color:#b91c1c">' + esc(r.msg) + '</b>'] : [esc(r.c.nom), fx(r.c.q, 3), r.dn + (r.prop ? ' <i>(proposé)</i>' : ''), fx(r.v, 2), fx(r.Re, 0), fx(r.dP / 1000, 2), fx(r.dPcum / 1000, 2), r.ok ? '<b style="color:#15803d">OK</b>' : '<b style="color:#b91c1c">' + esc(r.msg) + '</b>']; }));
      h += '<p>Perte totale (avec dénivelée) : <b>' + fx(k.eau.perte / 1000, 2) + ' kPa</b>' + (isFinite(k.eau.pRes) && isFinite(k.p.pDispo) ? ' — pression résiduelle : <b>' + fx(k.eau.pRes, 1) + ' kPa</b>' + (isFinite(k.p.pMin) ? (k.eau.pRes >= k.p.pMin ? ' <span style="color:#15803d">≥ minimale</span>' : ' <span style="color:#b91c1c">< minimale ' + fx(k.p.pMin, 1) + ' kPa</span>') : '') : '') + '.</p>'; }
    else if (!isFinite(k.p.vmax) && k.tr.tronc.length) h += '<p style="color:#b45309">Fixez la vitesse maximale de l’eau dans le Référentiel.</p>';
    return h;
  }
  function tabAir(x, dis) {
    var k = calc(x), h = lab('Gaines circulaires (un par ligne : nom ; débit m³/h ; L m ; [D mm] ; [K singularités])', ta('airTxt', x.airTxt, dis, 5, 'Gaine principale;1800;15;;1,5')) + errs(k.ga.erreurs);
    if (k.air && k.air.rows.length) h += table(['Gaine', 'Q (m³/h)', 'D (mm)', 'v (m/s)', 'ΔP (Pa)', 'ΔP cumulée (Pa)', 'Contrôle'], k.air.rows.map(function (r) { return r.D === undefined ? [esc(r.c.nom), fx(r.c.Q, 0), '—', '—', '—', '—', '<b style="color:#b91c1c">' + esc(r.msg) + '</b>'] : [esc(r.c.nom), fx(r.c.Q, 0), r.D + (r.prop ? ' <i>(proposé)</i>' : ''), fx(r.v, 2), fx(r.dP, 1), fx(r.dPcum, 1), r.ok ? '<b style="color:#15803d">OK</b>' : '<b style="color:#b91c1c">' + esc(r.msg) + '</b>']; })) + '<p>Perte de charge totale : <b>' + fx(k.air.perte, 1) + ' Pa</b>.</p>';
    else if (!isFinite(k.p.vmaxA) && k.ga.gaines.length) h += '<p style="color:#b45309">Fixez la vitesse maximale de l’air dans le Référentiel.</p>';
    return h;
  }
  function tabTh(x, dis) {
    var k = calc(x), c = k.ch, h = lab('Enveloppe (libellé ; U W/m²·K ; surface m² ; ΔT K)', ta('envTxt', x.envTxt, dis, 3, 'Mur nord;1,8;24;8')) + lab('Charges internes (libellé ; W)', ta('intTxt', x.intTxt, dis, 3, 'Occupants (10 × 100 W);1000\nÉclairage;600')) + lab('Air neuf (libellé ; débit m³/h ; ΔT K)', ta('neufTxt', x.neufTxt, dis, 2, 'Renouvellement;300;8')) + errs(c.erreurs);
    var rows = c.env.map(function (r) { return ['Enveloppe', esc(r.nom), fx(r.W, 0)]; }).concat(c.int.map(function (r) { return ['Interne', esc(r.nom), fx(r.W, 0)]; }), c.air.map(function (r) { return ['Air neuf', esc(r.nom), fx(r.W, 0)]; }));
    if (rows.length) h += table(['Poste', 'Libellé', 'Puissance (W)'], rows) + '<p><b>Total : ' + fx(c.total, 0) + ' W (' + fx(c.total / 1000, 2) + ' kW)</b></p><p style="font-size:12px;color:#475569">Somme des postes saisis, au signe donné (ΔT positif = apport). Ce n’est pas un bilan thermique réglementaire.</p>';
    return h;
  }
  function tabEq(x, dis) {
    var k = calc(x), e = k.eq, h = lab('Équipements (un par ligne : repère ; désignation ; local ; quantité ; [kW électrique] ; [GlobalId IFC])', ta('eqTxt', x.eqTxt, dis, 6, 'CH-01;Chauffe-eau;Local technique;1;3;')) + errs(e.erreurs);
    if (e.equip.length) h += table(['Repère', 'Désignation', 'Local', 'Qté', 'kW', 'IFC'], e.equip.map(function (r) { return [esc(r.rep), esc(r.des), esc(r.local), fx(r.q, 0), fx(r.kw, 2), r.guid ? '✔' : '—']; })) + '<p>Puissance électrique totale : <b>' + fx(e.totalKw, 2) + ' kW</b> — ' + e.equip.filter(function (r) { return r.guid; }).length + '/' + e.equip.length + ' lié(s) à un objet IFC.</p>' + btn('⬇️ Nomenclature CSV', 'csve', null, '#475569');
    return h;
  }
  function tabRap(x) {
    var A = verif(x), h = '<h4 style="margin:6px 0">Contrôles</h4>' + alertesHtml(A) + '<h4 style="margin:10px 0 4px">Visa</h4><p style="font-size:12.5px">Statut : <b>' + esc(x.statut) + '</b>' + (x.verifie ? ' — vérifié par ' + esc(x.verifie.par) : '') + (x.vise ? ' — visé par ' + esc(x.vise.par) : '') + '</p>';
    if (x.statut === 'Brouillon') h += btn('Marquer comme vérifié', 'verifier', null, '#7c3aed'); if (x.statut === 'Vérifié') h += btn('Viser le dossier', 'viser', null, '#7c3aed'); if (x.statut !== 'Brouillon') h += btn('Rouvrir (motif obligatoire)', 'rouvrir', null, '#475569');
    h += '<div style="margin-top:8px">' + btn('📄 Note de calcul PDF', 'pdf', null, '#0369a1') + '</div>';
    if (x.histo.length) h += '<h4 style="margin:10px 0 4px">Historique</h4><ul style="font-size:12px;padding-left:18px">' + x.histo.map(function (e) { return '<li>' + esc(new Date(e.t).toLocaleString('fr-FR')) + ' — ' + esc(e.msg) + '</li>'; }).join('') + '</ul>';
    return h;
  }
  function paint() {
    var b = box(); if (!b) return; var x = GID ? find(GID) : null;
    if (!x) { b.innerHTML = '<div style="display:flex"><button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + liste0(); return; }
    var dis = ro(x), tabs = [['ref', '📚 Référentiel'], ['eau', '🚿 Eau'], ['air', '🌬️ Air'], ['th', '🌡️ Charges'], ['eq', '🧰 Équipements'], ['rap', '✅ Rapport']];
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><button data-a="back" style="padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">← Dossiers</button>' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:999px;background:' + (TAB === t[0] ? '#0f766e' : '#e2e8f0') + ';color:' + (TAB === t[0] ? '#fff' : '#0f172a') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' +
      grid(lab('Titre', inp('titre', x.titre, dis)) + lab('Projet', '<select data-f="project_id"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="">—</option>' + projets().map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === x.project_id ? ' selected' : '') + '>' + esc(p.nom) + '</option>'; }).join('') + '</select>') + lab('Site / bâtiment', inp('site', x.site, dis)) + lab('Auteur de la note de calcul', inp('auteur', x.auteur, dis))) + '<p style="font-size:12px;color:#475569;margin:6px 0">' + esc(x.no) + ' — ' + esc(x.statut) + (dis ? ' (verrouillé : rouvrir pour modifier)' : '') + '</p><div id="exbPlombTab">' + ({ ref: tabRef, eau: tabEau, air: tabAir, th: tabTh, eq: tabEq, rap: tabRap }[TAB])(x, dis) + '</div>';
  }
  function setPath(x, f, v) { var p = f.split('.'), o = x; while (p.length > 1) o = o[p.shift()]; o[p[0]] = v; }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), x = GID ? find(GID) : null; if (!f || !x || ro(x)) return;
    setPath(x, f, t.value); if (f === 'dnTxt' && x.dnConf) { x.dnConf = null; x.histo.push({ t: Date.now(), msg: 'Table des diamètres modifiée : confirmation annulée' }); } saveDos(x); if (t.tagName === 'SELECT' || t.tagName === 'TEXTAREA' || f === 'dnTxt' || /^par\./.test(f)) paint();
  }
  function jrn(x, m) { x.histo.push({ t: Date.now(), msg: m }); }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i'), x = GID ? find(GID) : null;
    if (a === 'close') { var o = d.getElementById('exbPlomb'); if (o) o.remove(); return; }
    if (a === 'new') { var n = nouveau(); saveDos(n); GID = n.id; TAB = 'ref'; audit('plb.nouveau', n.no, {}); return paint(); }
    if (a === 'open') { GID = i; TAB = 'ref'; return paint(); }
    if (a === 'back') { GID = null; return paint(); }
    if (a === 'tab') { TAB = i; return paint(); }
    if (!x) return;
    if (a === 'confdn') return who().then(function (par) { if (!par) return; x.dnConf = { par: par, t: Date.now() }; jrn(x, 'Table des diamètres confirmée par ' + par); saveDos(x); audit('plb.dn.confirmee', x.no, { par: par }); paint(); });
    if (a === 'verifier') { var bl = bloque(x); if (bl.length) return toast('Vérification impossible : ' + bl.map(function (v) { return v.id; }).filter(function (v, j, s) { return s.indexOf(v) === j; }).join(', ') + ' (voir Rapport).', 'warn'); return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le vérificateur doit être une autre personne que l’auteur.', 'warn'); x.statut = 'Vérifié'; x.verifie = { par: par, t: Date.now() }; jrn(x, 'Vérifié par ' + par); saveDos(x); audit('plb.verifie', x.no, { par: par }); paint(); }); }
    if (a === 'viser') return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le visa ne peut pas être donné par l’auteur.', 'warn'); x.statut = 'Visé'; x.vise = { par: par, t: Date.now() }; jrn(x, 'Visé par ' + par); saveDos(x); audit('plb.vise', x.no, { par: par }); paint(); });
    if (a === 'rouvrir') return ask('Motif de la réouverture (obligatoire) :', '').then(function (m) { m = String(m || '').trim(); if (!m) return toast('Motif obligatoire.', 'warn'); jrn(x, 'Rouvert en brouillon — ' + m); x.statut = 'Brouillon'; delete x.verifie; delete x.vise; saveDos(x); audit('plb.rouvert', x.no, { motif: m }); paint(); });
    if (a === 'csve') return csv([['Repère', 'Désignation', 'Local', 'Quantité', 'kW électrique', 'GlobalId IFC']].concat(parseEquip(x.eqTxt).equip.map(function (r) { return [r.rep, r.des, r.local, r.q, r.kw, r.guid]; })), x.no + '-equipements.csv');
    if (a === 'pdf') {
      var k = calc(x), rows = [['Dossier', x.no + ' — ' + (x.titre || '—') + ' — statut : ' + x.statut], ['Projet / site', pnom(x.project_id) + ' — ' + (x.site || '—')], ['Auteur / date', (x.auteur || '—') + ' — ' + (x.date || '—')], ['Norme', (x.norme.nom || '—') + ' ' + (x.norme.edition || '')], ['Table des diamètres', x.dnConf ? 'confirmée par ' + x.dnConf.par : 'NON confirmée']];
      if (k.qp.ok) rows.push(['Débit de pointe eau', fx(k.qp.qp, 3) + ' l/s (somme ' + fx(k.qp.somme, 2) + ' l/s, ' + k.qp.n + ' appareils, k = ' + fx(k.qp.k, 2) + ')']);
      if (k.eau) { k.eau.rows.forEach(function (r) { rows.push(['Eau / ' + r.c.nom, r.dn === undefined ? r.msg : 'Q ' + fx(r.c.q, 3) + ' l/s — DN ' + r.dn + ' — v ' + fx(r.v, 2) + ' m/s — dP ' + fx(r.dP / 1000, 2) + ' kPa — ' + (r.ok ? 'OK' : r.msg)]); }); rows.push(['Eau : total', 'perte ' + fx(k.eau.perte / 1000, 2) + ' kPa — pression résiduelle ' + fx(k.eau.pRes, 1) + ' kPa']); }
      if (k.air) k.air.rows.forEach(function (r) { rows.push(['Air / ' + r.c.nom, r.D === undefined ? r.msg : 'Q ' + fx(r.c.Q, 0) + ' m3/h — D ' + r.D + ' mm — v ' + fx(r.v, 2) + ' m/s — dP ' + fx(r.dP, 1) + ' Pa — ' + (r.ok ? 'OK' : r.msg)]); });
      if (k.ch.total) rows.push(['Charges thermiques', fx(k.ch.total, 0) + ' W (somme des postes saisis)']);
      if (k.eq.equip.length) rows.push(['Équipements', k.eq.equip.length + ' repère(s) — ' + fx(k.eq.totalKw, 2) + ' kW électriques']);
      verif(x).forEach(function (v) { rows.push(['Contrôle ' + v.id, v.niveau + ' : ' + v.msg]); });
      return pdf({ titre: 'NOTE DE CALCUL PLOMBERIE / HVAC', sousTitre: san(x.no + ' — ' + (x.titre || '')), rows: rows.map(function (r) { return [san(r[0]), san(r[1])]; }), notes: ['Calculs deterministes - ne remplacent pas la note d\'un ingenieur. Parametres, vitesses maximales et tables fixes par le projet.'], footer: san(x.no + ' — ' + x.statut) });
    }
  }
  function ouvrir(tab) {
    if (tab) TAB = tab; var o = d.getElementById('exbPlomb'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbPlomb'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbPlombBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('change', onChange); c.addEventListener('click', onClick); paint();
  }
  function ui() {
    var b = d.getElementById('exbElecBtn') || d.getElementById('exbGeoPlusBtn') || d.getElementById('exbTopoBtn') || d.getElementById('exbBeDalBtn') || d.getElementById('exbBeP2Btn') || d.getElementById('exbBeBtn'); if (!b || d.getElementById('exbPlombBtn')) return;
    var k = d.createElement('button'); k.id = 'exbPlombBtn'; k.setAttribute('data-exb-cat', 'ing'); k.setAttribute('data-exb-desc', 'Débits, pertes de charge, gaines, charges thermiques, équipements'); k.className = b.className; k.textContent = '🚿 Plomberie / HVAC'; k.onclick = function () { ouvrir('ref'); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined' && d.documentElement && d.documentElement.nodeType) new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'plomb', name: 'Bureau plomberie / HVAC', version: '1.0.0', area: 'Technique', deps: [], collections: [K] }); } catch (e) {}

  w.EXBPlomb = { open: ouvrir, frottement: frottement, troncon: troncon, parseAppareils: parseAppareils, debitPointe: debitPointe, parseDN: parseDN, parseTronc: parseTronc, reseauEau: reseauEau, parseGaines: parseGaines, reseauAir: reseauAir, charges: charges, parseEquip: parseEquip, verif: verif, nouveau: nouveau, calc: calc, DN0: DN0 };
  if (typeof module !== 'undefined' && module.exports) module.exports = w.EXBPlomb;
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { addEventListener: function () {}, documentElement: {} });
