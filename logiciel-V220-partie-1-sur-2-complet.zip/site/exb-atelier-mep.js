/* Excellencia Building V209 — ATELIER DE MISE EN PAGE (module du Bureau d'études ingénieur).
 * Habille des PDF techniques (plans, notes de calcul, rapports, dossiers complets) SANS modifier l'original : import archivé par empreinte SHA-256,
 * analyse des pages, cartouche / couverture / sommaire / pagination, aperçu avant-après, circuit de validation, versions et journal d'audit.
 * Le module vit dans atelier-mep/index.html (cadre de la page, même origine) : il lit l'identité (EXBId), les projets (exb_projects), les droits (EXBAction)
 * et le stockage (exbStorage). Aucune fonction existante n'est modifiée.
 * Pour retirer le module : supprimer la balise <script src="exb-atelier-mep.js"> de index.html. */
(function (w, d) {
  'use strict';
  var URL_ED = 'atelier-mep/index.html', $ = function (i) { return d.getElementById(i); };
  function exposeStorage() { try { if (!w.exbStorage && typeof exbStorage !== 'undefined') w.exbStorage = exbStorage; } catch (e) { /* inaccessible */ } }
  exposeStorage();
  function css() {
    if ($('exbAtelierMepCss')) return; var s = d.createElement('style'); s.id = 'exbAtelierMepCss';
    s.textContent = '#atelierMep .am-wrap{border:1px solid #d5dbe5;border-radius:14px;overflow:hidden;background:#f4f4f4;box-shadow:0 6px 24px #0f2e6618}'
      + '#atelierMep iframe{display:block;width:100%;height:calc(100vh - 150px);min-height:680px;border:0;background:#fff}'
      + '@media(max-width:700px){#atelierMep iframe{height:calc(100vh - 130px);min-height:620px}}';
    d.head.appendChild(s);
  }
  function build() {
    var sec = d.createElement('section'); sec.id = 'atelierMep'; sec.style.display = 'none';
    sec.innerHTML = '<div class="card"><h2>🖨️ Atelier de mise en page</h2><p class="hint">Plans, notes de calcul, rapports et dossiers PDF : cartouche, couverture, sommaire, pagination et validation — le contenu technique d’origine n’est jamais modifié.</p><div class="am-wrap"><iframe id="exbAtelierMepFrame" title="Atelier de mise en page" loading="lazy" allow="fullscreen"></iframe></div></div>';
    return sec;
  }
  function mount() {
    exposeStorage();
    if ($('atelierMep')) return;
    var ref = $('planCartouche') || $('planEditeur') || $('calcStructure') || $('bureauEtudes') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, sec = build(); css();
    if (ref && ref.parentNode) ref.parentNode.insertBefore(sec, ref.nextSibling); else host.appendChild(sec);
    var anchor = $('bplancart') || $('bplanedit') || $('bbet') || $('bdev'), par = anchor && anchor.parentNode;
    if (par && !$('batelier')) { var b = d.createElement('button'); b.id = 'batelier'; b.type = 'button'; b.textContent = '🖨️ Atelier de mise en page'; b.setAttribute('onclick', "show('atelierMep')"); par.insertBefore(b, anchor.nextSibling); }
    var os = w.show;
    if (typeof os === 'function' && !w.__exbAtelierMepShow) {
      w.__exbAtelierMepShow = 1;
      w.show = function (x) {
        var r = os.apply(this, arguments), e = $('atelierMep');
        if (e) {
          e.style.display = (x === 'atelierMep') ? '' : 'none';
          if (x === 'atelierMep') { var f = $('exbAtelierMepFrame'); if (f && !f.getAttribute('src')) f.setAttribute('src', URL_ED); else if (f) { try { var E = f.contentWindow.EXBATELIER; if (E && E.refresh) E.refresh(); } catch (er) {} } }
        }
        var b2 = $('batelier'); if (b2) b2.classList.toggle('active', x === 'atelierMep'); return r;
      };
    }
  }
  w.EXBATELIERMEP = { open: function () { exposeStorage(); if (!$('atelierMep')) mount(); if (typeof w.show === 'function') w.show('atelierMep'); try { w.scrollTo(0, 0); } catch (e) {} }, version: 'V209' };
  function start() { setTimeout(mount, 950); }
  if (d.readyState === 'complete') start(); else w.addEventListener('load', start);
})(window, document);
