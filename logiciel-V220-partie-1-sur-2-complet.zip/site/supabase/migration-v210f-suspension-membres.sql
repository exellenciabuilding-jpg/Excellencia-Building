-- ===== Excellencia Building  V210f : SUSPENSION / RÉACTIVATION D'UN MEMBRE + DÉTECTION IMMÉDIATE D'UN ACCÈS RETIRÉ =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : schema-entreprise.sql, migration-v66-roles.sql, migration-v99w-equipe.sql et migration-v205v-codes-personnels.sql déjà exécutés.
--
-- Avant : « Retirer » supprimait le membre côté serveur, mais son logiciel restait ouvert avec ses données locales ; la suspension n'existait pas.
-- Maintenant :
--   • SUSPENDRE : le membre sort de « membres » (donc plus AUCUN accès serveur, dans toutes les fonctions existantes) mais sa fiche
--     (nom, rôle, fonction, date d'entrée) est gardée dans « membres_suspendus ». RÉACTIVER la remet à l'identique, avec son code personnel.
--   • Un membre suspendu ne peut pas revenir tout seul (ni avec le code d'entreprise, ni par invitation) : seul l'administrateur le réactive.
--   • mon_statut(org) : le logiciel du membre demande « actif / suspendu / retire » et se bloque aussitôt si ce n'est plus « actif ».
--   • « Retirer » fonctionne aussi sur un membre suspendu.

create table if not exists membres_suspendus(
  org_id uuid not null references organisations(id) on delete cascade,
  user_id uuid not null,
  nom text,
  role text not null,
  fonction text not null default 'polyvalent',
  depuis timestamptz,
  suspendu_le timestamptz not null default now(),
  suspendu_par uuid,
  motif text,
  primary key(org_id,user_id));
alter table membres_suspendus enable row level security;   -- aucune lecture/écriture directe : fonctions seulement

-- Un membre suspendu ne peut pas se ré-inscrire seul (code d'entreprise, invitation, equipe_inviter…) : seule equipe_reactiver() passe.
create or replace function membres_bloquer_suspendus() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if coalesce(current_setting('exb.reactivation', true),'') <> '1'
     and exists(select 1 from membres_suspendus where org_id=new.org_id and user_id=new.user_id) then
    raise exception 'compte suspendu : demandez à l''administrateur de vous réactiver';
  end if;
  return new;
end $$;
drop trigger if exists trg_membres_bloquer_suspendus on membres;
create trigger trg_membres_bloquer_suspendus before insert on membres for each row execute function membres_bloquer_suspendus();

-- Suspendre un membre (administrateur uniquement ; pas soi-même ; pas le dernier administrateur).
create or replace function equipe_suspendre(p_org uuid, p_user uuid, p_motif text default null) returns json
language plpgsql security definer set search_path=public as $$
declare m membres; admins int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if p_user = auth.uid() then raise exception 'impossible de vous suspendre vous-même'; end if;
  select * into m from membres where org_id=p_org and user_id=p_user;
  if not found then raise exception 'membre introuvable'; end if;
  select count(*) into admins from membres where org_id=p_org and role='admin';
  if m.role='admin' and admins<=1 then raise exception 'impossible : c''est le dernier administrateur'; end if;
  insert into membres_suspendus(org_id,user_id,nom,role,fonction,depuis,suspendu_par,motif)
    values (p_org,p_user,m.nom,m.role,m.fonction,m.depuis,auth.uid(),nullif(trim(p_motif),''))
    on conflict (org_id,user_id) do update set nom=excluded.nom, role=excluded.role, fonction=excluded.fonction,
      depuis=excluded.depuis, suspendu_le=now(), suspendu_par=excluded.suspendu_par, motif=excluded.motif;
  delete from membres where org_id=p_org and user_id=p_user;   -- coupe tout accès (le code personnel est révoqué par le déclencheur v205v)
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),'equipe',p_user::text,'suspension',0);
  return json_build_object('ok',true);
end $$;

-- Réactiver un membre suspendu : même rôle, même fonction, même date d'entrée, même code personnel.
create or replace function equipe_reactiver(p_org uuid, p_user uuid) returns json
language plpgsql security definer set search_path=public as $$
declare s membres_suspendus; mx int; n int; em text;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  select * into s from membres_suspendus where org_id=p_org and user_id=p_user;
  if not found then raise exception 'membre suspendu introuvable'; end if;
  if to_regclass('public.licences_clients') is not null then
    execute 'select max_utilisateurs from licences_clients where org_id=$1 order by cree_le desc limit 1' into mx using p_org;
    select count(*) into n from membres where org_id=p_org;
    if mx is not null and n>=mx then raise exception 'nombre maximal d''utilisateurs atteint (%)', mx; end if;
  end if;
  perform set_config('exb.reactivation','1',true);
  insert into membres(org_id,user_id,nom,role,fonction,depuis) values (p_org,p_user,s.nom,s.role,s.fonction,coalesce(s.depuis,now()))
    on conflict (org_id,user_id) do nothing;
  perform set_config('exb.reactivation','',true);
  delete from membres_suspendus where org_id=p_org and user_id=p_user;
  select lower(email) into em from auth.users where id=p_user;
  update codes_membres set revoque_le=null where org_id=p_org and (user_id=p_user or email=em);
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),'equipe',p_user::text,'réactivation',0);
  return json_build_object('ok',true);
end $$;

-- Retirer : fonctionne aussi pour un membre suspendu (version v99w + cette branche).
create or replace function equipe_retirer(p_org uuid, p_user uuid) returns json
language plpgsql security definer set search_path=public as $$
declare cur text; admins int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if exists(select 1 from membres_suspendus where org_id=p_org and user_id=p_user) then
    delete from membres_suspendus where org_id=p_org and user_id=p_user;
    update codes_membres set revoque_le=coalesce(revoque_le,now())
      where org_id=p_org and (user_id=p_user or email=(select lower(email) from auth.users where id=p_user));
    return json_build_object('ok',true);
  end if;
  select role into cur from membres where org_id=p_org and user_id=p_user;
  if cur is null then raise exception 'membre introuvable'; end if;
  select count(*) into admins from membres where org_id=p_org and role='admin';
  if cur='admin' and admins<=1 then raise exception 'impossible : c''est le dernier administrateur'; end if;
  delete from membres where org_id=p_org and user_id=p_user;
  return json_build_object('ok',true);
end $$;

-- Liste de l'équipe : ajoute « suspendus » (les anciens appareils ignorent cette clé).
create or replace function equipe_liste(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  return json_build_object(
    'membres', (select coalesce(json_agg(json_build_object('user_id',m.user_id,'nom',m.nom,'email',u.email,
                  'role',m.role,'fonction',m.fonction,'depuis',m.depuis) order by m.depuis),'[]'::json)
                from membres m left join auth.users u on u.id=m.user_id where m.org_id=p_org),
    'suspendus', (select coalesce(json_agg(json_build_object('user_id',s.user_id,'nom',s.nom,'email',u.email,
                  'role',s.role,'fonction',s.fonction,'depuis',s.depuis,'suspendu_le',s.suspendu_le,'motif',s.motif) order by s.suspendu_le),'[]'::json)
                from membres_suspendus s left join auth.users u on u.id=s.user_id where s.org_id=p_org),
    'invitations', (select coalesce(json_agg(json_build_object('id',i.id,'email',i.email,'nom',i.nom,'role',i.role,
                  'fonction',i.fonction,'cree_le',i.cree_le) order by i.cree_le),'[]'::json)
                from invitations_equipe i where i.org_id=p_org and i.utilise_le is null));
end $$;

-- Statut du compte connecté dans une entreprise : 'actif' | 'suspendu' | 'retire' (null si non connecté).
create or replace function mon_statut(p_org uuid) returns text
language sql stable security definer set search_path=public as $$
  select case
    when auth.uid() is null then null
    when exists(select 1 from membres where org_id=p_org and user_id=auth.uid()) then 'actif'
    when exists(select 1 from membres_suspendus where org_id=p_org and user_id=auth.uid()) then 'suspendu'
    else 'retire' end $$;

revoke execute on function equipe_suspendre(uuid,uuid,text), equipe_reactiver(uuid,uuid), equipe_retirer(uuid,uuid),
  equipe_liste(uuid), mon_statut(uuid) from public, anon;
grant execute on function equipe_suspendre(uuid,uuid,text), equipe_reactiver(uuid,uuid), equipe_retirer(uuid,uuid),
  equipe_liste(uuid), mon_statut(uuid) to authenticated;
