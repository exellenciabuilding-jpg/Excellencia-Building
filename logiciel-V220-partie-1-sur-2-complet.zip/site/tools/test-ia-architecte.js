// Test de l'IA Architecte déterministe (node tools/test-ia-architecte.js)
var vm=require('vm'),fs=require('fs'),a=require('assert');
var w={document:{documentElement:null,getElementById:function(){return null}},addEventListener:function(){},console:console,setTimeout:setTimeout};w.window=w;w.globalThis=w;vm.createContext(w);
vm.runInContext(fs.readFileSync(__dirname+'/../exb-v209-ia-architecte.js','utf8'),w,{});
var X=w.EXBIAARCH,Q=[];function t(n,f){Q.push([n,f])}
t('parseProgramme : « 3 chambres 12 m² », « Salon : 30 m² », lignes ignorées',()=>{
 var R=X.parseProgramme('3 chambres 12 m²\nSalon : 30 m²\nUne phrase sans surface');
 a.strictEqual(R.rooms.length,2);a.strictEqual(R.rooms[0].qty,3);a.strictEqual(R.rooms[0].total,36);a.strictEqual(R.rooms[1].surface,30);a.strictEqual(R.ignored.length,1)});
t('parseProgramme : virgule décimale et texte vide',()=>{a.strictEqual(X.parseProgramme('Cuisine = 9,5 m²').rooms[0].surface,9.5);a.strictEqual(X.parseProgramme('').rooms.length,0)});
t('variantes : écart au programme et champs manquants signalés, sans recommandation',()=>{
 var D={pid:'p',prog:[{type:'variante',nom:'A',surface:120,cout:1000,ces:.4,cos:.8,rendement:.8},{type:'variante',nom:'B',surface:''}],rooms:[{cible:100}]};
 var V=X.variantes(D);a.strictEqual(V.length,2);a.strictEqual(V[0].ecart,20);a.ok(V[1].alertes.length>0);a.ok(!V.some(v=>'recommande' in v||'meilleure' in v))});
t('variantes : module non accessible → null',()=>{a.strictEqual(X.variantes({prog:null}),null)});
t('omissions : module non accessible ni lu ni commenté',()=>{
 var D={pid:'p',prog:null,site:[],reg:[],coord:[],mat:[],ids:null,specs:[],rooms:null,regles:null,runs:null,mats:[]};
 var O=X.omissions(D);a.ok(O.some(o=>/non accessible/.test(o.titre)&&/Programme/.test(o.titre)));a.ok(O.some(o=>/IDS/.test(o.titre)&&/non accessible/.test(o.titre)))});
t('omissions : programme vide, règles manquantes, collisions ouvertes, triées par importance',()=>{
 var D={pid:'p',prog:[],site:[],reg:[],coord:[{type:'clash',statut:'ouvert'}],mat:[],ids:[],specs:[],rooms:null,regles:{specs:[]},runs:[],mats:[]};
 var O=X.omissions(D);a.ok(O.some(o=>/Aucun programme/.test(o.titre)));a.ok(O.some(o=>/collision/.test(o.titre)));a.ok(O.some(o=>/Aucune règle réglementaire/.test(o.titre)));
 for(var i=1;i<O.length;i++)a.ok(O[i-1].imp>=O[i].imp);O.forEach(o=>a.ok(o.src&&o.action,'source et action présentes'))});
t('omissions : écarts IDS non conformes signalés',()=>{
 var D={pid:'p',prog:null,site:null,reg:null,coord:null,mat:null,ids:[],specs:null,rooms:null,regles:{specs:[{}]},runs:[{date:'2026-11-22',res:[{status:'non_conforme'}]}],mats:null};
 a.ok(X.omissions(D).some(o=>/écarts constatés/.test(o.titre)))});
t('synthèse : chaque ligne porte sa source ; module inaccessible indiqué',()=>{
 var D={pid:'p',prog:null,site:[],reg:[],coord:[],mat:[],ids:[],specs:[],rooms:null,regles:{specs:[]},runs:[],mats:[]};
 var S=X.synthese(D);a.strictEqual(S.length,6);S.forEach(s=>a.ok(s.src));a.ok(/non accessible/.test(S[0].txt))});
t('lecture seule : aucune écriture dans le module',()=>{var src=fs.readFileSync(__dirname+'/../exb-v209-ia-architecte.js','utf8');a.ok(!/EXBS\.set\(|fetch\(|XMLHttpRequest/.test(src))});
(async()=>{var ok=0;for(var q of Q){try{await q[1]();ok++}catch(e){console.log('ÉCHEC',q[0],'\n  ',e.message)}}console.log(ok+'/'+Q.length+' tests passés');process.exit(ok===Q.length?0:1)})();
