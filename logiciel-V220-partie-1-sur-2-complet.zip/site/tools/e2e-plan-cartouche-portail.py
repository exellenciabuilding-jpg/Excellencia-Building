# Test navigateur du parcours unique V140 + V129 : mise en page du plan -> réservation de la référence -> envoi au portail
# -> rangement dans Plans & fichiers CAO -> finalisation avec la même référence ; puis ré-export (même QR, ancienne version retirée).
import json, os, re, base64, threading, http.server, functools, tempfile
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8795),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
def mkpdf():
    o=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 1684 1190] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
    body=b'BT /F1 60 Tf 100 600 Td (PLAN ARC-01 RDC) Tj ET 100 100 800 400 re S'; o.append(b'<< /Length %d >>\nstream\n'%len(body)+body+b'\nendstream')
    out=b'%PDF-1.4\n'; offs=[]
    for i,x in enumerate(o,1): offs.append(len(out)); out+=b'%d 0 obj\n'%i+x+b'\nendobj\n'
    xr=len(out); out+=b'xref\n0 %d\n0000000000 65535 f \n'%(len(o)+1)+b''.join(b'%010d 00000 n \n'%f for f in offs)
    return out+b'trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF'%(len(o)+1,xr)
PDF=os.path.join(tempfile.gettempdir(),'plan_a2_test.pdf'); open(PDF,'wb').write(mkpdf())
ORG='11111111-2222-3333-4444-555555555555'
res=[]
def check(nom,cond,info=''): res.append(bool(cond)); print(('OK   ' if cond else 'ÉCHEC'),nom,info)
STUB="""async(a)=>{
  window.__calls=[];window.__srv={tok:null};
  window.EXBDB.org=()=>a.org; window.EXBDB.can=()=>true; window.exbSb.isIn=()=>true;
  window.exbSb.api=async(path,opt)=>{opt=opt||{};let body=opt.body;if(body&&typeof body==='object'&&typeof body.size==='number'&&typeof body.arrayBuffer==='function')body={octets:body.size,type:body.type};else if(typeof body==='string'){try{body=JSON.parse(body)}catch(e){}}
    window.__calls.push({path,method:opt.method||'GET',body});
    if(/rpc\\/plan_public_publier/.test(path)){const b=body,S=window.__srv;if(!b.p_ref){S.tok=b.p_token;return{ok:true,ref:'EXB-2026-007',code:'A1B2C3D4E5'}}const old=S.tok;S.tok=b.p_token;return{ok:true,ref:b.p_ref,code:'A1B2C3D4E5',ancien_token:old}}
    if(/rpc\\/plan_public_retirer/.test(path))return{ok:true,token:window.__srv.tok};
    return{}};
  window.EXBS.set('exb_projects',[{id:'P1',nom:'Immeuble R+3',name:'Immeuble R+3',client:'Client Officiel',maitre_ouvrage:'Client Officiel'}]);
  localStorage.setItem('exb_active_project','P1');
}"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1300,'height':1000},accept_downloads=True); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('dialog',lambda d:d.accept())
    exbui_auto(pg)
    pg.goto('http://127.0.0.1:8795/index.html'); pg.wait_for_timeout(3000)
    pg.add_style_tag(content='#exbLicLock,#exbLock{display:none!important}#app{display:block!important}')   # écran de licence du logiciel : hors sujet pour ce test
    pg.evaluate(STUB,{'org':ORG})
    check('module Plan Editor présent dans la V129',pg.evaluate("typeof EXBPLANCARTOUCHE")=='object' and pg.evaluate("typeof EXBPUB")=='object' and pg.evaluate("typeof EXBPLN.addFrom")=='function')
    pg.evaluate("EXBPLANCARTOUCHE.open()"); pg.wait_for_selector('#exbPlanCartFrame',timeout=8000); pg.wait_for_timeout(2500)
    fr=pg.frame_locator('#exbPlanCartFrame')
    check('menu « Mise en page des plans »',pg.locator('#bplancart').count()==1)
    fr.locator('#fileIn').set_input_files(PDF); pg.wait_for_timeout(2500)
    fr.locator('#iProj').select_option('P1'); pg.wait_for_timeout(300)
    check('cartouche rempli depuis le projet',fr.locator('#iTitre').input_value()!='' ,fr.locator('#iTitre').input_value())
    fr.locator('#go').click(); pg.wait_for_timeout(1500)
    def export():
        pg.evaluate("window.__calls.length=0;['exbPln','exbPub'].forEach(i=>{const e=document.getElementById(i);e&&e.remove()})")   # la liste « Plans & fichiers CAO » s'ouvre après l'envoi : on la ferme
        with pg.expect_download(timeout=90000) as dl: fr.locator('#exp').click()
        pg.wait_for_timeout(1500); return dl.value, pg.evaluate("window.__calls")
    d1,c1=export()
    pubs=[c for c in c1 if 'plan_public_publier' in c['path']]; ups=[c for c in c1 if '/storage/v1/object/exb-plans-publics/' in c['path'] and c['method']=='POST']
    check('1er export : réservation puis finalisation (2 appels publier)',len(pubs)==2 and pubs[0]['body']['p_ref'] is None and pubs[1]['body']['p_ref']=='EXB-2026-007',str([x['body']['p_ref'] for x in pubs]))
    check('même jeton pour réservation, envoi et finalisation',pubs[0]['body']['p_token']==pubs[1]['body']['p_token'] and len(ups)==1 and pubs[0]['body']['p_token'] in ups[0]['path'])
    order=[('publier' if 'plan_public_publier' in c['path'] else 'envoi' if '/object/exb-plans-publics/' in c['path'] else '?') for c in c1]; order=[x for x in order if x!='?']
    check('ordre : réservation → envoi du PDF → finalisation',order==['publier','envoi','publier'],str(order))
    check('PDF final téléchargé et valide',d1.suggested_filename.endswith('.pdf') and open(d1.path(),'rb').read(5)==b'%PDF-',d1.suggested_filename)
    check('PDF final envoyé > 10 Ko (plan + cartouche + QR)',ups[0]['body']['octets']>10000,str(ups[0]['body']['octets']))
    check('plan rangé dans Plans & fichiers CAO',pg.evaluate("(EXBS.get('exb_plan_files')||[]).filter(x=>/EXB-2026-007/i.test(x.name)).length")==1)
    check('aperçu envoyé au portail',str(pubs[1]['body']['p_apercu']).startswith('data:image/jpeg;base64,'))
    check('numéro unique : le fichier porte la référence du serveur',d1.suggested_filename.upper().startswith('EXB-2026-007'),d1.suggested_filename)
    old=pubs[1]['body']['p_token']
    # 2e export du même plan : même référence, ancienne version retirée du portail
    fr.locator('#iRef').fill('EXB-2026-007'); fr.locator('#iRef').dispatch_event('change'); fr.locator('#iInd').fill('B'); pg.wait_for_timeout(500)   # nouvel indice du même plan = même référence
    d2,c2=export()
    pubs2=[c for c in c2 if 'plan_public_publier' in c['path']]
    check('2e export : même référence réutilisée (même QR de téléchargement)',len(pubs2)>=1 and all(x['body']['p_ref']=='EXB-2026-007' for x in pubs2),str([x['body']['p_ref'] for x in pubs2]))
    dels=[c for c in c2 if c['method']=='DELETE' and c['path'].endswith('/exb-plans-publics')]
    check('2e export : fichiers de la version précédente supprimés du portail',any(old in json.dumps(x['body']) for x in dels),str([x['body'] for x in dels])[:160])
    new=pubs2[-1]['body']['p_token']
    check('2e export : la nouvelle version n\'est PAS supprimée',not any(new in json.dumps(x['body']) for x in dels))
    check('pas d\'erreur JS',not errs,str(errs[:2])); b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
