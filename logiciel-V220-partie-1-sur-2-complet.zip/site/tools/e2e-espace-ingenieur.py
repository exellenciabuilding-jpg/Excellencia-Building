# V205 lot 2 — Espace Comptable : lien /comptable, menu limité, accès par fonction, T03 (paiement confirmé) et T04 (devis sans paiement)
import http.server, threading, functools, os, sys, datetime
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
TODAY = datetime.date.today().isoformat()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    boot('ingenieur.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'ingenieur', 'le lien /ingenieur ouvre l\'Espace Ingénieur')
    pg.evaluate("exbProjects=[{id:'P1',name:'Villa Test',status:'En cours'},{id:'P2',name:'Ecole',status:'Terminé'}]")
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(700)
    mt = ' | '.join(pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)"))
    t('Projets' in mt and 'Métré' in mt, 'le menu contient Projets et Métré & devis')
    t(not any(x in mt for x in ['Finances', 'Comptabilité', 'Reçus', 'Stock', 'Apprenants', 'Formation', 'Paie']), 'le menu ne contient ni finance, ni stock, ni RH, ni formation')
    h = pg.evaluate("document.getElementById('xhK').innerText")
    t('Projets en cours' in h and 'Villa Test' in pg.evaluate("document.getElementById('xhChart').innerText"), 'le tableau de bord liste les projets en cours')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(500)
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False and 'Accès refusé' in pg.evaluate("document.getElementById('xhK').innerText"), 'un comptable est refusé dans l\'Espace Ingénieur')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'bureau_etudes',label:'Bureau d\\'études'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is True, 'un bureau d\'études est accepté')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'magasinier',label:'Magasinier'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'un magasinier est refusé')
    pg.evaluate("EXB_SHELL.quitEspace()"); pg.wait_for_timeout(3500)
    t(pg.evaluate("localStorage.getItem('exb_espace')") is None, 'quitter l\'espace restaure le menu complet')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
