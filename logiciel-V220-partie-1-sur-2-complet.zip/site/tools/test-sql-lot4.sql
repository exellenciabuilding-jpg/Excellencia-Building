\set ON_ERROR_STOP 0
\pset tuples_only on
create temp table r(t text, ok boolean);
insert into auth.users values ('00000000-0000-0000-0000-00000000000a','admin@t.com'),('00000000-0000-0000-0000-00000000000e','archi@t.com'),('00000000-0000-0000-0000-00000000000d','compta@t.com');
insert into organisations(id,nom) values ('11111111-1111-1111-1111-111111111111','Org test');
\set org '''11111111-1111-1111-1111-111111111111'''
-- 1. la fonction « architecte » est acceptée en base, une fonction inconnue reste refusée
insert into membres(org_id,user_id,nom,role,fonction) values
 (:org,'00000000-0000-0000-0000-00000000000a','Admin','admin','polyvalent'),
 (:org,'00000000-0000-0000-0000-00000000000d','Compta','editeur','comptable');
insert into r select 'un membre peut avoir la fonction « architecte »', (select count(*) from (select 1 where true) x)=1 and exists(select 1 from pg_constraint where conname='membres_fonction_chk' and pg_get_constraintdef(oid) like '%architecte%');
do $$ begin
  begin insert into membres(org_id,user_id,nom,role,fonction) values ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000e','X','editeur','astronaute'); insert into r values('une fonction inconnue est refusée',false);
  exception when check_violation then insert into r values('une fonction inconnue est refusée',true); end; end $$;
-- 2. l'administrateur invite un architecte, puis change la fonction d'un membre
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000a'; set request.jwt.claims='{"aal":"aal1"}';
select (equipe_inviter(:org,'archi@t.com','Archi','editeur','architecte')::jsonb->>'statut') as i1 \gset
select (equipe_modifier(:org,'00000000-0000-0000-0000-00000000000d','editeur','architecte')::jsonb->>'ok') as m1 \gset
reset role;
insert into r select 'equipe_inviter accepte « architecte » (compte existant : ajouté)', :'i1'='ajoute' and exists(select 1 from membres where user_id='00000000-0000-0000-0000-00000000000e' and fonction='architecte');
insert into r select 'equipe_modifier accepte « architecte »', :'m1'='true';
do $$ declare e text; begin
  set local role authenticated; perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-00000000000a',true);
  begin perform equipe_inviter('11111111-1111-1111-1111-111111111111','z@t.com','Z','editeur','astronaute'); e:='aucune erreur';
  exception when others then e:=sqlerrm; end;
  reset role; insert into r values('equipe_inviter refuse toujours une fonction inconnue ('||e||')', e='fonction invalide'); end $$;
-- un non-administrateur (l'architecte) ne peut pas inviter
do $$ declare e text; begin
  set local role authenticated; perform set_config('request.jwt.claim.sub','00000000-0000-0000-0000-00000000000e',true);
  begin perform equipe_inviter('11111111-1111-1111-1111-111111111111','y@t.com','Y','editeur','architecte'); e:='aucune erreur';
  exception when others then e:=sqlerrm; end;
  reset role; insert into r values('un architecte ne peut pas inviter (réservé à l''administrateur)', e like '%administrateur%'); end $$;
-- 3. droits serveur : l'architecte écrit plans/études, ne fait que lire les notes de calcul, n'a ni caisse ni factures
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000e';
select peut(:org,'plans',true) as d1, peut(:org,'etudes',true) as d2, peut(:org,'notes_calcul',false) as d3, peut(:org,'notes_calcul',true) as d4,
       peut(:org,'caisse',false) as d5, peut(:org,'factures',false) as d6, peut(:org,'personnel',false) as d7 \gset
reset role;
insert into r select 'l''architecte écrit les plans et les études', :'d1'='t' and :'d2'='t';
insert into r select 'l''architecte lit les notes de calcul mais ne les modifie pas', :'d3'='t' and :'d4'='f';
insert into r select 'l''architecte n''a accès ni à la caisse, ni aux factures, ni au personnel', :'d5'='f' and :'d6'='f' and :'d7'='f';
insert into r select 'les droits de l''architecte couvrent les mêmes collections que le bureau d''études', (select count(*) from droits_fonction where fonction='architecte')=(select count(*) from droits_fonction where fonction='bureau_etudes');
-- 4. validation d'un calcul : être architecte n'autorise pas
set role authenticated; set request.jwt.claim.sub='00000000-0000-0000-0000-00000000000e'; set request.jwt.claims='{"aal":"aal2"}';
select (calcul_valider(:org,'P1','Poutre','NC-001','A','digest-aaaa','valide','ok',true)::jsonb->>'refus') as v \gset
reset role;
insert into r select 'un architecte non habilité ne peut pas valider un calcul ('||:'v'||')', :'v'='ingenieur_habilite_requis';
-- 5. droits personnalisés conservés au second passage
update droits_fonction set ecrire=false where fonction='architecte' and collection='plans';
\i :HERE_LOT4
insert into r select 'un droit personnalisé n''est pas écrasé par la réexécution', (select ecrire from droits_fonction where fonction='architecte' and collection='plans')=false;
\echo ----- RÉSULTAT -----
select case when ok then 'OK   ' else 'FAIL ' end || t from r;
select 'Résultat : '||count(*) filter (where ok)||' OK, '||count(*) filter (where not ok)||' échec(s)' from r;
