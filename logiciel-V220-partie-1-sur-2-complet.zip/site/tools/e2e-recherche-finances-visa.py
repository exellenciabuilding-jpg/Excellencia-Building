#!/usr/bin/env python3
"""V205r : (1) la barre de recherche trouve les devis du module Finances (exb_finance) ; (2) export du reçu sans visa : message central persistant.
Usage : python3 tools/e2e-recherche-finances-visa.py"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200]))
    exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200);")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(5000)
    # --- 1. recherche
    a.evaluate("""()=>{EXBS.set('exb_projects',[{id:'P-LUK',nom:'Villa Lukuni Gombe'}]);
      EXBS.set('exb_finance',[{id:'FIN-1',type:'devis',no:'DEV-2026-001',project:'P-LUK',client:'Famille Mukendi',ttc:1200,cur:'USD',date:'2026-11-01'},
        {id:'FIN-2',type:'devis',no:'D-2026-002',project:'P-LUK',ttc:300,cur:'USD',date:'2026-11-02'},
        {id:'FIN-T',type:'taux',date:'2026-11-01',rate:2800}]);}""")
    def cherche(q):
        a.evaluate("q=>{const s=document.getElementById('exbGlobalSearch');s.value=q;runExbGlobalSearch(q)}",q); a.wait_for_timeout(900)
        return a.inner_text('#exbGlobalResults')
    t=cherche('DEV-2026-001').lower(); ok('dev-2026-001' in t and 'devis (finances)' in t,'recherche du numéro DEV-2026-001 → devis Finances trouvé')
    t=cherche('lukuni').lower(); ok(t.count('devis (finances)')==2 and 'villa lukuni gombe' in t,'recherche « lukuni » (nom du PROJET) → les 2 devis Finances trouvés')
    t=cherche('mukendi'); ok('DEV-2026-001' in t,'recherche par nom du client → trouvé')
    t=cherche('2800'); ok('finances' not in t.lower(),'la ligne « taux du jour » n\'est pas listée')
    a.evaluate("q=>{runExbGlobalSearch(q)}",'lukuni'); a.wait_for_timeout(900)
    a.evaluate("[...document.querySelectorAll('#exbGlobalResults .exb-search-item[data-i]')].find(e=>/Finances/i.test(e.textContent)).click()"); a.wait_for_timeout(600)
    ok(a.is_visible('#exbFin'),'un clic ouvre le module Finances (USD / FC)')
    a.evaluate("document.getElementById('exbFin')?.remove()")
    # --- 1b. annuaire du guichet (apprenant publié par un autre compte)
    a.evaluate("""()=>{EXBS.set('exb_annuaire_guichet',[{id:'APP-X9',kind:'apprenant',nom:'Beatrice Kasongo',participant_id:'X9',matricule:'M-77',tel:'0812',formation:'AutoCAD',approuve:true},
       {id:'APP-PA1',kind:'apprenant',nom:'Doublon Local',participant_id:'PA1',formation:'F'}]);EXBS.set('exb_participants',[{participant_id:'PA1',name:'Doublon Local'}])}""")
    t=cherche('kasongo').lower(); ok('apprenant (annuaire)' in t and 'beatrice kasongo' in t,'apprenant publié par un autre compte : trouvé par la barre')
    t=cherche('doublon').lower(); ok('annuaire' not in t,'apprenant déjà présent sur l\'appareil : pas listé deux fois')
    # --- 2. export du reçu sans visa
    a.evaluate("""()=>{try{EXBSign.setAdmin({auto:false,sig:'',stamp:'none'})}catch(e){}
      participants.splice(0);payments.splice(0);receipts.splice(0);
      participants.push({participant_id:'PA1',name:'Test Apprenant',phone:'1',training:'Formation X',approval_status:'APPROUVE'});
      payments.push({payment_id:'PY1',participant_id:'PA1',participant_name:'Test Apprenant',amount:10});
      document.getElementById('exbGuide')?.remove();}""")
    a.evaluate("document.getElementById('receipt_no').value='REC-TEST-1'")
    a.evaluate("exportReceiptPdf()"); a.wait_for_timeout(500)
    g=a.evaluate("(()=>{const e=document.getElementById('exbGuide');return e?{txt:e.innerText,cls:e.className,r:e.getBoundingClientRect().toJSON()}:null})()")
    if g and 'PDF n’a pas été généré' not in g['txt']:
        print('   (message vu :',g['txt'][:160].replace('\n',' '),')')
    ok(bool(g) and 'PDF n’a pas été généré' in g['txt'] and 'grave' in g['cls'],'sans visa : carte « PDF non généré » affichée')
    if g: ok(abs((g['r']['x']+g['r']['width']/2)-210)<6 and 100<g['r']['y']<500,'… au centre de l\'écran (pas en bas)')
    ok(a.is_visible('#exbGuideBg'),'… avec un fond qui attire l\'œil')
    a.wait_for_timeout(16500)
    ok(a.is_visible('#exbGuide'),'… et elle reste après 16 s (plus de disparition automatique)')
    a.click('#exbGuide .ok'); a.wait_for_timeout(200)
    ok(not a.query_selector('#exbGuide') and not a.query_selector('#exbGuideBg'),'« Compris » ferme la carte et le fond')
    # --- 3. visa du Directeur publié : le comptable n'est plus bloqué
    a.evaluate("localStorage.setItem('EXB_VISA_REMOTE','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')")
    a.evaluate("document.getElementById('exbGuide')?.remove();document.getElementById('exbGuideBg')?.remove();exportReceiptPdf()"); a.wait_for_timeout(800)
    ok(not a.evaluate("/signature|cachet|PDF n’a pas/i.test(document.getElementById('exbGuide')?.innerText||'')"),'visa publié présent : plus aucun blocage « signature / cachet » (reste seulement le champ de test non rempli)')
    # --- 4. chacun signe avec SON profil : compte comptable (non administrateur)
    PNG="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
    a.evaluate("document.getElementById('exbGuide')?.remove();document.getElementById('exbGuideBg')?.remove();EXBDB.info=()=>({org:'O',on:true,role:'membre',fonction:'comptable',label:'Comptable'});try{localStorage.removeItem('EXB_OPERATEUR_V1')}catch(e){}")
    a.evaluate("exportReceiptPdf()"); a.wait_for_timeout(600)
    g=a.evaluate("document.getElementById('exbGuide')?.innerText||''")
    ok('PDF n’a pas été généré' in g and 'Mon profil opérateur' in g,'comptable SANS profil : bloqué, même si le visa du Directeur est publié ; le message renvoie vers « Mon profil opérateur »')
    ok(a.evaluate("EXBSign.anyVisa('png')").__class__ is str and a.evaluate("EXBSign.anyVisa('png')")=='','comptable : le visa du Directeur n\'est jamais posé sur ses documents')
    a.evaluate("document.getElementById('exbGuide')?.remove();document.getElementById('exbGuideBg')?.remove()")
    a.evaluate("async p=>{await EXBOperateur.save({nom:'Jean Comptable',fonction:'Comptable',sig:p,stamp:'none'})}",PNG); a.wait_for_timeout(600)
    mine=a.evaluate("EXBOperateur.get().visa")
    ok(bool(mine) and a.evaluate("EXBSign.visa('png')")==mine and a.evaluate("EXBSign.anyVisa('png')")==mine,'comptable AVEC profil : sa signature sort sur ses documents (EXBSign.visa / anyVisa)')
    ok(a.evaluate("EXBSign.active()") is True and a.evaluate("EXBOperateur.remplace()") is True,'… le blocage « signature manquante » est levé, et ses PDF / pièces écrites utilisent sa signature')
    a.evaluate("exportReceiptPdf()"); a.wait_for_timeout(600)
    ok(not a.evaluate("/signature|cachet|PDF n’a pas/i.test(document.getElementById('exbGuide')?.innerText||'')"),'… plus de message de blocage sur l\'export du reçu')
    # administrateur : visa du Directeur, comme avant
    a.evaluate("EXBDB.info=()=>({org:'O',on:true,role:'admin',fonction:'polyvalent',label:'Administrateur'});EXBSign.setAdmin({auto:true,sig:'"+PNG+"',stamp:'none'})"); a.wait_for_timeout(200)
    adm=a.evaluate("EXBSign.visa('png')")
    ok(bool(adm) and adm!=mine,'administrateur / direction : le visa du Directeur est conservé (pas celui d\'un opérateur)')
    ok(not ae,'aucune erreur JS '+str(ae[:2]))
    b.close()
print('ÉCHECS :',fails); sys.exit(1 if fails else 0)
