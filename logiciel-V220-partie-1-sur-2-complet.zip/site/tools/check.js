#!/usr/bin/env node
/* Excellencia Building — contrôle automatique avant livraison.
 * Usage (depuis le dossier du site) :  node tools/check.js
 * Vérifie : syntaxe de tous les scripts, fichiers chargés par index.html, cache hors ligne (sw.js), colonnes et collections SQL,
 * puis teste le comportement des modules (stockage, hors ligne, maintenance, QR, réception). Code de sortie 1 en cas d'échec. */
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');const R=f=>fs.readFileSync(path.join(root,f),'utf8');
let fails=0,passes=0;
const ok=(c,m,detail)=>{if(c){passes++;console.log('  OK   '+m)}else{fails++;console.log('  FAIL '+m+(detail?' — '+detail:''))}};
const title=t=>console.log('\n# '+t);

title('1. Syntaxe');
const jsFiles=fs.readdirSync(root).filter(f=>f.endsWith('.js')).concat(fs.existsSync(path.join(root,'modules'))?fs.readdirSync(path.join(root,'modules')).map(f=>'modules/'+f):[]);
jsFiles.forEach(f=>{try{new vm.Script(R(f),{filename:f});passes++}catch(e){fails++;console.log('  FAIL '+f+' : '+e.message)}});
console.log('  '+jsFiles.length+' fichiers JS analysés');
const html=R('index.html');
const inline=[...html.matchAll(/<script(?![^>]*\bsrc\b)[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).filter(s=>s.trim().length>50);
let inlineBad=0;inline.forEach((s,i)=>{try{new vm.Script(s)}catch(e){inlineBad++;console.log('  FAIL script inline #'+i+' : '+e.message)}});
ok(inlineBad===0,inline.length+' scripts inline de index.html valides');
if(inlineBad)fails+=0;

title('2. Fichiers chargés et cache hors ligne');
const tags=[...html.matchAll(/<script[^>]*\ssrc="([^"]+)"/g)].map(m=>m[1]).filter(s=>!/^https?:/.test(s));
const uniq=[...new Set(tags)];
const missing=uniq.filter(f=>!fs.existsSync(path.join(root,f)));
ok(missing.length===0,'tous les scripts de index.html existent',missing.join(', '));
const sw=R('sw.js');
const notCached=uniq.filter(f=>!sw.includes("'./"+f+"'"));
ok(notCached.length===0,'tous les scripts sont dans le cache hors ligne (sw.js)',notCached.join(', '));
const swV=(/const V='([^']+)'/.exec(sw)||[])[1];
ok(!!swV&&swV!=='exb-v66-roles','nom de cache à jour : '+swV);
const orphans=fs.readdirSync(root).filter(f=>/^exb-.*\.js$/.test(f)&&!uniq.includes(f));
console.log('  (info) scripts non chargés par index.html : '+(orphans.join(', ')||'aucun'));

title('3. Synchronisation et droits SQL');
const dbSrc=R('exb-db.js');const colsLine=dbSrc.split('\n').find(l=>l.includes('COLS={'))||'';
const COLS={};for(const m of colsLine.matchAll(/(exb_[a-z0-9_]+):'([a-z_]+)'/g))COLS[m[1]]=m[2];
ok(Object.keys(COLS).length>=50,Object.keys(COLS).length+' collections synchronisées');
const sqlDir=path.join(root,'supabase');const sqlFiles=fs.readdirSync(sqlDir).filter(f=>f.endsWith('.sql'));
const allSql=sqlFiles.map(f=>fs.readFileSync(path.join(sqlDir,f),'utf8')).join('\n');
const noRights=Object.values(COLS).filter(c=>!allSql.includes("'"+c+"'"));
ok(noRights.length===0,'chaque collection a des droits dans le SQL',noRights.join(', '));
const badCols=sqlFiles.filter(f=>/peut_lire|peut_ecrire|\blecture\b|\becriture\b/.test(fs.readFileSync(path.join(sqlDir,f),'utf8').replace(/--.*$/gm,'')));
ok(badCols.length===0,'colonnes SQL conformes (fonction, collection, lire, ecrire)',badCols.join(', '));
const ins=sqlFiles.filter(f=>/insert\s+into\s+droits_fonction\s*\(([^)]*)\)/i.test(fs.readFileSync(path.join(sqlDir,f),'utf8'))).filter(f=>{const m=/insert\s+into\s+droits_fonction\s*\(([^)]*)\)/i.exec(fs.readFileSync(path.join(sqlDir,f),'utf8'));return m[1].replace(/\s/g,'')!=='fonction,collection,lire,ecrire'});
ok(ins.length===0,'insertions droits_fonction avec les bonnes colonnes',ins.join(', '));

/* ---------- environnement simulé ---------- */
function env(opts){opts=opts||{};const store={},ls={getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}};
 const doc={addEventListener(){},getElementById(){return null},createElement(){return {style:{},appendChild(){}}},body:{appendChild(){}},head:{appendChild(){}},querySelector(){return null}};
 const marks=[],said=[];const win={localStorage:ls,document:doc,head:{appendChild(){}},navigator:{onLine:opts.online!==false},location:{href:'https://exemple.com/app/index.html',hash:''},addEventListener(){},notify(m,t){said.push([m,t])},setInterval(){},setTimeout(){},console,unescape,encodeURIComponent,decodeURIComponent};
 Object.assign(win,{MutationObserver:function(){this.observe=function(){}}},opts.extra||{});
 win.EXBDB={can:opts.can||(()=>true),mark:k=>marks.push(k)};win.window=win;
 win.exbStorage={getItem:k=>ls.getItem('P::'+k),setItem:(k,v)=>ls.setItem('P::'+k,v)};
 const ctx=vm.createContext(win);ctx.__marks=marks;ctx.__said=said;ctx.__ls=ls;
 (opts.load||[]).forEach(f=>vm.runInContext(R(f),ctx,{filename:f}));return ctx}
const today=()=>{const d=new Date();return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2)};

title('4. Pont de stockage');
{const w=env({load:['exb-storage-bridge.js']});w.__ls.setItem('exb_facility_assets',JSON.stringify([{id:'A1'}]));
 ok(w.EXBS.get('exb_facility_assets').length===1,'migration des anciennes données brutes');
 ok(w.__ls.getItem('P::exb_facility_assets')!==null,'données placées dans la zone synchronisée');
 w.EXBS.set('exb_x',[{id:1}]);ok(w.__marks.includes('exb_x'),'notification de synchronisation (mark)')}

title('5. QR code');
{const w=env({load:['exb-qr.js']});const m=w.EXBQR.matrix('EXB-ASSET:CLIM-001');
 ok(m.length===25,'version 2 attendue pour un texte court (taille '+m.length+')');
 let finder=true;for(let i=0;i<7;i++){finder=finder&&m[0][i]&&m[6][i]&&m[i][0]&&m[i][6]}ok(finder,'motif de repérage haut-gauche présent');
 ok(/^<svg/.test(w.EXBQR.svg('x')),'sortie SVG');
 let thrown=false;try{w.EXBQR.matrix('z'.repeat(214))}catch(e){thrown=true}ok(thrown,'texte trop long refusé proprement');
 ok(w.EXBQR.matrix('é'.repeat(100)).length===57,'texte UTF-8 de 200 octets encodé (version 10)')}
console.log('  (le décodage réel des QR a été vérifié avec OpenCV lors du développement : voir README-V76)');

title('6. Chantier hors ligne');
{const w=env({online:false,load:['exb-storage-bridge.js','exb-v73-offline.js'],can:c=>c!=='journal'});
 w.EXBS.set('exb_hr',[{id:'H1',name:'Jean'}]);
 let o=w.exbV73.enqueue('rfi',{id:'RFIS-1',project:'P1',question:'Q?',status:'Ouverte',photos:['data:x']});
 ok(o.status==='synced'&&w.EXBS.get('exb_rfis').length===1,'RFI enregistrée hors ligne dans exb_rfis');
 ok(w.exbV73.queue().every(q=>q.status!=='synced'||Object.keys(q.record).length===1),'file allégée après enregistrement (photos non dupliquées)');
 w.EXBS.set('exb_reserves',[{id:'R0'}]);w.exbV73.enqueue('reserve',{id:'RES-1',project:'P1',name:'n',status:'Ouverte'});
 ok(w.EXBS.get('exb_reserves').length===2,'fusion par fiche (aucun écrasement)');
 const ts={id:'TS-1',worker_id:'H1',project_id:'P1',date:'2026-10-06'};w.exbV73.enqueue('pointage',ts);
 ok(w.exbV73.enqueue('pointage',Object.assign({},ts,{id:'TS-2'})).status==='conflict','doublon de pointage détecté');
 const j=w.exbV73.enqueue('journal',{id:'JR-1',project_id:'P1',work:'x'});ok(j.status==='conflict'&&w.EXBS.get('exb_site_journal').length===0,'droit insuffisant : rien d\u2019écrit');
 const w2=env({online:false,load:['exb-storage-bridge.js','exb-v73-offline.js']});w2.EXBS.set('exb_hr',[{id:'H9',name:'Paul'}]);w2.EXBS.get('exb_hr');
 vm.runInContext("exbV73.enqueue('pointage',{id:'TS-9',worker_id:'H9',project_id:'P',date:'2026-10-06'})",w2);
 ok(w2.EXBS.get('exb_timesheets').length===1,'pointage enregistré')}

title('7. Maintenance : récurrence, planification, import');
{const w=env({load:['exb-storage-bridge.js','exb-qr.js','exb-v74-facility.js']});const F=w.EXBV74;
 ok(F.addPeriod('2026-01-31','mensuelle')==='2026-02-28','fin de mois gérée (31 janv. + 1 mois)');
 ok(F.addPeriod('2026-10-06','annuelle')==='2027-10-06','récurrence annuelle');
 ok(F.addPeriod('2026-11-30','trimestrielle')==='2027-02-28','récurrence trimestrielle');
 const rec={id:'W1',asset_code:'CL1',type:'préventive',due_date:'2026-01-31',status:'terminée',recurrence:'mensuelle'};const a=[rec];
 ok(F.followUp(a,rec)===1&&a.length===2&&a[1].due_date==='2026-02-28'&&a[1].status==='à faire','intervention terminée → prochaine échéance créée');
 ok(F.followUp(a,rec)===0&&a.length===2,'pas de doublon à la 2e validation');
 const enCours={id:'W9',asset_code:'CL9',type:'préventive',due_date:'2026-03-10',status:'en cours',recurrence:'mensuelle'},a2=[enCours];ok(F.followUp(a2,enCours)===0&&a2.length===1,'pas d\u2019échéance suivante tant que l\u2019intervention n\u2019est pas terminée');
 w.EXBS.set('exb_facility_workorders',[{id:'W2',asset_code:'GE1',type:'préventive',due_date:today(),status:'à faire',recurrence:'trimestrielle'}]);
 F.planify();const n1=w.EXBS.get('exb_facility_workorders').length;
 ok(n1>=4&&n1<=5,'planification sur 12 mois (trimestrielle) : '+(n1-1)+' échéances créées');
 F.planify();ok(w.EXBS.get('exb_facility_workorders').length===n1,'planification idempotente (aucun doublon)');
 w.EXBS.set('exb_maintenance',[{id:'M1',title:'Bétonnière',type:'Corrective',due:'2026-11-01',status:'En retard',project:'P1'},{id:'M2',title:'Grue',type:'Préventive',due:'',status:'Clôturé'}]);
 F.importV68();const wo=w.EXBS.get('exb_facility_workorders').filter(x=>x.source);ok(wo.length===2&&wo[0].type==='corrective'&&wo[1].status==='terminée','import du matériel V68');
 F.importV68();ok(w.EXBS.get('exb_facility_workorders').filter(x=>x.source).length===2,'import sans doublon');
 ok(/^https:\/\/exemple\.com\/app\/index\.html#asset=CL%201/.test(F.linkFor('CL 1')),'lien QR direct vers l\u2019équipement');
 ok(F.linkFor('x'.repeat(300)).startsWith('EXB-ASSET:'),'lien trop long → code seul')}

title('8. Réception de chantier');
{const w=env({load:['exb-storage-bridge.js','exb-v76-reception.js']});let got=null,saved=null;
 w.EXBPdf={make:o=>{got=o;return Promise.resolve({blob:1})},save:(b,n)=>{saved=n}};
 w.EXBS.set('exb_projects',[{id:'P1',nom:'Villa Test'}]);
 w.EXBS.set('exb_reserves',[{id:'R1',project:'P1',name:'Fissure mur nord',status:'Ouverte',photos:['d1']},{id:'R2',project:'P1',name:'Peinture',status:'Clôturée'},{id:'R3',project:'P2',name:'Autre projet',status:'Ouverte'}]);
 w.EXBS.set('exb_receptions',[{id:'REC-1',project:'P1',kind:'provisoire',date:'2026-10-06',decision:'avec réserves',lift_deadline:'2026-12-01',present:'A, MOA',doe:{plans:true}}]);
 w.EXBREC.pdf('REC-1');
 ok(got&&got.titre.includes('RÉCEPTION'),'PV généré');
 const txt=JSON.stringify(got);ok(txt.includes('Fissure mur nord')&&!txt.includes('Peinture')&&!txt.includes('Autre projet'),'seules les réserves ouvertes du projet sont listées');
 ok(txt.includes('01/12/2026')&&txt.includes('[x] Plans de récolement')&&txt.includes('[ ] Notices'),'délai de levée et DOE présents');
 ok(got.images.length===1,'photos des réserves jointes');
 setTimeout(()=>{ok(!!saved&&/^PV-reception-Villa_Test/.test(saved),'fichier PDF nommé : '+saved);v81tests().then(end,e=>{ok(false,'tests V81 interrompus : '+(e&&e.stack||e));end()})},20)}

async function v81tests(){
 const near=(a,b)=>Math.abs(a-b)<0.01;
 const wc=require('crypto').webcrypto;
 const crypt={crypto:wc,TextEncoder,TextDecoder,btoa,atob};

 title('9. V78 à V80 : chargement (contrôle de base)');
 for(const [f,g] of [['exb-v78-finance.js','EXBFIN'],['exb-v79-architecture.js','EXBARC'],['exb-v80-cartouche.js','EXBCART']]){
  try{const w=env({load:['exb-storage-bridge.js',f]});ok(!!w[g],f+' se charge et définit '+g)}catch(e){ok(false,f+' se charge sans erreur',e.message)}}

 title('10. V81 Pilotage : consolidation V61 + V78, retards, impayés');
 {const w=env({load:['exb-storage-bridge.js','exb-v81-pilotage.js'],extra:{URL}}),t=today(),past='2020-01-01';
  w.EXBS.set('exb_projects',[{id:'P1',name:'Villa Test',client:'Mr Kasongo',budget:10000,progress:20,start:'2020-01-01',end:'2021-01-01',status:'En cours'}]);
  w.EXBS.set('exb_invoices',[{id:'I1',no:'FAC-1',project_id:'P1',client:'Mr Kasongo',date:past,due:past,tva:16,currency:'USD',lines:[{q:1,pu:1000}],payments:[{amount:500}]}]);
  w.EXBS.set('exb_finance',[{id:'T1',type:'taux',date:past,rate:2800},{id:'F1',type:'facture',project:'P1',no:'F-2026-001',cur:'FC',rate:2800,ht:2800000,ttc:2800000,tva:0,date:t},{id:'PA1',type:'paiement',parent:'F1',cur:'FC',rate:2800,ttc:1400000,date:t}]);
  w.EXBS.set('exb_cash',[{id:'C1',type:'out',amount:300,project_id:'P1'},{id:'C2',type:'in',amount:500,project_id:'P1'}]);
  const c=w.EXBPIL._calc(),r=c.rows[0];
  ok(c.I.length===2,'les factures V61 et V78 sont consolidées');
  ok(near(c.T.ttc,2160)&&near(c.T.paid,1000)&&near(c.T.reste,1160),'totaux en USD (FC converti au taux de la pièce)',JSON.stringify(c.T));
  ok(c.T.lateN===1&&near(c.T.late,660),'un seul impayé échu (la facture V78 n’a pas d’échéance)');
  ok(near(c.T.dep,300)&&near(c.T.marge,700),'dépenses et marge réelle');
  ok(near(r.margeReelle,700)&&near(r.margePrevue,1700),'marge réelle et prévue du projet');
  ok(r.alerts.some(x=>/fin dépassée/.test(x))&&r.alerts.some(x=>/Impayés/.test(x)),'alertes retard et impayés',r.alerts.join('|'));
  ok(c.late[0].no==='FAC-1','liste de relance triée');
  w.EXBS.set('exb_finance',[]);w.EXBS.set('exb_invoices',[{id:'I2',no:'FAC-2',project_id:'P1',date:past,currency:'FC',tva:0,lines:[{q:1,pu:100000}],payments:[]}]);
  const c2=w.EXBPIL._calc();ok(c2.T.missing===1&&c2.T.ttc===0,'pièce en FC sans taux : signalée et non comptée');
  const csv=w.EXBPIL._csv([{a:'=1+1',b:'x;y',c:12.5,d:'say "hi"'}],['a','b','c','d']);
  ok(csv.charCodeAt(0)===0xFEFF&&csv.includes("'=1+1"),'CSV : BOM Excel et protection contre les formules');
  ok(csv.includes('"x;y"')&&csv.includes(';12,5;')&&csv.includes('"say ""hi"""'),'CSV : séparateur ; guillemets et virgule décimale');
  w.EXBS.set('exb_cash',[{id:'C9',type:'out',amount:5,note:'data:image/png;base64,AAAA'}]);
  ok(w.EXBPIL._exports.caisse.t().rows[0].note==='[fichier non exporté]','CSV : les fichiers intégrés ne sont pas exportés');
  ok(w.EXBPIL._phone('0812345678')==='243812345678'&&w.EXBPIL._phone('+243 81 234 5678')==='243812345678'&&w.EXBPIL._phone('0033612345678')==='33612345678'&&w.EXBPIL._phone('812345678')==='243812345678','numéros WhatsApp normalisés (indicatif 243 par défaut)');
  const msg=w.EXBPIL._message({no:'FAC-1',project:'P1',client:'Mr Kasongo',reste:660,due:past,lateDays:10});
  ok(msg.includes('FAC-1')&&msg.includes('660')&&msg.includes('Mr Kasongo'),'message de rappel préparé');
  w.EXBS.set('exb_cash',[{id:'C1',type:'out',amount:300,project_id:'P1'}]);
  w.EXBS.set('exb_site_journal',[{id:'J1',project_id:'P1',date:t,work:'Dalle R+1',photos:['data:image/jpeg;base64,AAAA','sb:chemin/p.jpg']}]);
  w.EXBS.set('exb_situations',[{id:'S1',no:'S01',project_id:'P1',date:t,pct:30}]);
  const h=w.EXBPIL._reportHtml('P1');
  ok(h.includes('Villa Test')&&h.includes('Dalle R+1')&&h.includes('S01')&&h.includes('<img src="data:image/jpeg'),'rapport client : avancement, journal, situation, photo');
  ok(!/Marge|300,00|Dépenses/.test(h),'rapport client : aucun coût ni marge');
  ok(/1 autre\(s\) photo/.test(h),'rapport client : photo en ligne signalée');}

 title('11. V81 Sécurité : chiffrement, sauvegarde, test de restauration, quota');
 {const mkStore=()=>{const o={};return{get length(){return Object.keys(o).length},key:i=>Object.keys(o)[i],getItem:k=>k in o?o[k]:null,setItem:(k,v)=>{o[k]=String(v)},_o:o}};
  const w=env({load:['exb-storage-bridge.js','exb-v81-securite.js'],extra:crypt}),S=w.EXBSEC,pw='motdepasse-long-123';
  const fails=async f=>{try{await f();return false}catch(e){return true}};
  const sealed=await S._seal('secret',pw,1000);
  ok(!sealed.includes('secret')&&(await S._unseal(sealed,pw))==='secret','chiffrement AES-GCM : aller-retour');
  ok(await fails(()=>S._unseal(sealed,'mauvais-mot-de-passe')),'mauvais mot de passe refusé');
  const o=JSON.parse(sealed);o.ct=o.ct.slice(0,-4)+(o.ct.slice(-4)==='AAAA'?'BBBB':'AAAA');
  ok(await fails(()=>S._unseal(JSON.stringify(o),pw)),'fichier modifié refusé');
  const st=mkStore();st._o.exb_projects='[{"id":"P1"},{"id":"P2"}]';st._o.exb_clients='[]';st._o.exb_cash='[{"id":"C1"}]';
  const before=JSON.stringify(st._o);
  const b=await S._makeBackup('',st),r=await S._verify(b,'',st);
  ok(r.ok&&r.rows.length===3&&r.rows.find(x=>x.key==='exb_projects').backup===2,'sauvegarde valide : 3 jeux de données, 2 projets');
  ok(JSON.stringify(st._o)===before,'le test de restauration ne modifie rien');
  const bad=JSON.parse(b);bad.keys.exb_projects='[{"id":"P1"}]';
  const rb=await S._verify(JSON.stringify(bad),'',st);ok(!rb.ok&&rb.errors.some(x=>/Somme de contrôle/.test(x)),'sauvegarde altérée détectée');
  const be=await S._makeBackup(pw,st);
  ok(!(await S._verify(be,'',st)).ok&&(await S._verify(be,pw,st)).ok&&!(await S._verify(be,'faux',st)).ok,'sauvegarde chiffrée : mot de passe exigé');
  ok(!(await S._verify('pas du json','',st)).ok&&!(await S._verify('{"a":1}','',st)).ok,'fichier étranger refusé');
  const st2=mkStore(),rv=await S._verify(b,'',st2);S._restoreInto(rv.payload,st2);
  const srt=o=>JSON.stringify(Object.keys(o).sort().map(k=>[k,o[k]]));ok(srt(st2._o)===srt(st._o),'restauration : données identiques à la source');
  w.__ls.setItem('exb_lic_priv',JSON.stringify({d:'abc',x:'XX'}));
  w.EXBLIC={isAdmin:()=>{try{const p=JSON.parse(w.__ls.getItem('exb_lic_priv')||'null');return !!(p&&p.d&&p.x==='XX')}catch(e){return false}}};
  ok(await fails(()=>S._exportKey('court')),'export de clé : mot de passe trop court refusé');
  const kf=await S._exportKey(pw);ok(!kf.includes('abc'),'clé exportée chiffrée (la valeur n’apparaît pas)');
  w.__ls.removeItem('exb_lic_priv');await S._restoreKey(kf,pw);ok(w.EXBLIC.isAdmin(),'clé admin restaurée depuis le fichier chiffré');
  ok(await fails(()=>S._restoreKey(kf,'faux-mot-de-passe-1')),'restauration de clé : mauvais mot de passe refusé');
  w.EXBLIC={isAdmin:()=>false};w.__ls.setItem('exb_lic_priv',JSON.stringify({d:'old',x:'YY'}));
  ok(await fails(()=>S._restoreKey(kf,pw))&&JSON.parse(w.__ls.getItem('exb_lic_priv')).d==='old','clé non reconnue : refusée, ancienne clé conservée');
  w.EXBDB={can:()=>true,info:()=>({on:true,role:'editeur'})};ok(S._canRestore()===false,'restauration refusée à un éditeur de la base partagée');
  w.EXBDB={can:()=>true,info:()=>({on:true,role:'admin'})};ok(S._canRestore()===true,'restauration permise à l’administrateur');}
 {const w=env({load:['exb-storage-bridge.js','exb-v81-securite.js'],extra:Object.assign({},crypt,{Response,fetch:()=>Promise.resolve('reel')})});
  let last,i=0;for(;i<40;i++)last=await w.fetch('https://x.supabase.co/functions/v1/assistant');
  ok(last==='reel'&&w.EXBSEC.quota().n===40,'quota IA : 40 demandes passent');
  const r=await w.fetch('https://x.supabase.co/functions/v1/assistant');
  ok(r.status===429,'quota IA : la 41e est refusée localement (429)');
  ok(await w.fetch('https://x.supabase.co/rest/v1/autre')==='reel','quota IA : les autres appels ne sont pas comptés');}
 {const sql=R('supabase/migration-v81-securite.sql'),ts=R('supabase/functions/assistant/index.ts');
  ok(/exb_assistant_quota/.test(sql)&&/security definer/.test(sql)&&/enable row level security/.test(sql),'SQL V81 : fonction de quota sécurisée');
  ok(/exb_assistant_quota/.test(ts)&&/429/.test(ts),'fonction assistant : quota appliqué côté serveur');
  ok(/requireToken:(true|false)\s*→/.test(R('licence-config.js')),'licence-config : commentaire cohérent');}

 title('12. Devis rapide : même gabarit A4 que le devis maître');
 {const w=env({load:['exb-storage-bridge.js','exb-metre.js']});
  w.document.createElement=()=>({style:{},appendChild(){},remove(){},getBoundingClientRect:()=>({height:24})});
  const M=w.EXBMetre,sq=t=>String(t).replace(/[\s\u202f\u00a0]/g,'');
  ok(!!M&&typeof M.quotePdf==='function'&&typeof M.quotePrint==='function','le module Métré expose quotePdf et quotePrint');
  const q0={no:'DEV-2026-001',client:'Mr Kasongo',project:'Villa',date:'2026-10-07',currency:'USD',lines:[{designation:'Ciment',unit:'sac',qty:2,pu:50},{designation:'Sable',unit:'m3',qty:1,pu:30}]};
  const e0=M._quoteDoc(Object.assign({},q0,{currency:'CDF'}));ok(!!e0.error,'devis en CDF sans taux : refusé avec un message clair');
  w.EXBS.set('exb_finance',[{type:'taux',date:'2026-01-01',rate:2800}]);
  vm.runInContext('var exbClients=[{full_name:"Mr Kasongo",address:"Av. du Commerce 12",phone:"0812345678",email:"k@ex.cd"}]',w);
  const d=M._quoteDoc(q0);
  ok(near(d.T.sub,130)&&near(d.T.totfc,364000)&&near(d.lines[0][4],100)&&d.noImp,'devis en USD : montants $ et FC calculés au taux');
  const dc=M._quoteDoc(Object.assign({},q0,{currency:'CDF',lines:[{designation:'Dalle',unit:'m2',qty:1,pu:28000}]}));
  ok(near(dc.T.sub,10)&&near(dc.T.totfc,28000)&&near(dc.lines[0][3],10),'devis en CDF : converti en $ avec le même taux');
  const r=M._quotePages(q0),h=r.pages.join('');
  ok(r.pages.length===1&&/DEVIS/.test(h)&&h.includes('TOTAL GÉNÉRAL')&&h.includes('Signature du client')&&h.includes('Page 1 / 1'),'gabarit du maître : en-tête DEVIS, total général, signatures, pied de page');
  ok(h.includes('DÉTAIL DU DEVIS')&&h.includes('Mr Kasongo')&&h.includes('Av. du Commerce 12')&&h.includes('0812345678'),'client et coordonnées repris de la fiche client');
  ok(!h.includes('Divers &amp; imprévus')&&sq(h).includes('364000'),'pas de ligne « Divers & imprévus » vide ; total en FC présent');
  ok(M._quotePages(q0).pages.join('')===h,'le rendu est reproductible (aucun état résiduel)');
  const big=Object.assign({},q0,{lines:Array.from({length:60},(_,i)=>({designation:'Article '+(i+1),unit:'u',qty:1,pu:10}))});
  const rb=M._quotePages(big),hb=rb.pages.join('');
  ok(rb.pages.length>1,'devis long : plusieurs pages A4 ('+rb.pages.length+')');
  ok((hb.match(/Désignation<\/th>/g)||[]).length===rb.pages.length,'en-tête du tableau répété sur chaque page');
  ok((hb.match(/TOTAL GÉNÉRAL/g)||[]).length===1&&hb.lastIndexOf('TOTAL GÉNÉRAL')>hb.lastIndexOf('Article 60')-1,'total général et signatures une seule fois, en dernière page');
  ok(rb.pages.every((p,k)=>p.includes('Page '+(k+1)+' / '+rb.pages.length)),'pieds de page numérotés « Page x / y »');
  const html=R('index.html');
  ok(html.includes('EXBMetre.quotePdf')&&html.includes('printExbQuote')&&html.includes('exbQuotePdfById')&&html.includes('exportExbQuotePdfSimple'),'Devis rapide branché sur le gabarit du maître (ancien gabarit gardé en secours)');
  /* main d'œuvre, imprévus, note */
  const qm=Object.assign({},q0,{imp:10,note:'Validité 30 jours. Paiement 50 % à la commande.',lines:[{designation:'Ciment',unit:'sac',qty:2,pu:50,cat:'mat'},{designation:'Maçon',unit:'jour',qty:5,pu:40,cat:'mo'},{designation:'Aide-maçon',unit:'jour',qty:5,pu:20,cat:'mo'}]});
  const dm=M._quoteDoc(qm),hm=M._quotePages(qm).pages.join('');
  ok(near(dm.T.sub,400)&&near(dm.T.impv,40)&&near(dm.T.tot,440)&&near(dm.T.totfc,440*2800),'main d’œuvre + matériaux + imprévus 10 % : totaux exacts ($ et FC)');
  ok(hm.includes('MATÉRIAUX')&&hm.includes('MAIN D’ŒUVRE')&&hm.includes('Sous-total matériaux')&&hm.includes('Sous-total main d’œuvre'),'PDF : sections et sous-totaux séparés matériaux / main d’œuvre');
  ok(sq(hm).includes('300,00')&&sq(hm).includes('100,00'),'PDF : sous-total main d’œuvre (300 $) et matériaux (100 $) affichés');
  ok(hm.includes('Divers &amp; imprévus (10 %)')&&hm.includes('Paiement 50 % à la commande'),'PDF : ligne imprévus (%) et note / conditions imprimées');
  ok(!h.includes('MAIN D’ŒUVRE')&&!h.includes('Sous-total matériaux'),'un devis sans main d’œuvre garde l’aspect du devis maître (pas de sections)');
  ok(dm.lines.filter(r=>r.k).length===4&&dm.lines.filter(r=>!r.k).length===3,'lignes d’article et lignes de section/sous-total bien distinguées');
  const html2=R('index.html'),ch=R('exb-chantiers.js');
  ok(['exb_q_imp','exb_q_note','addExbQuoteLabour','exbCatOpts'].every(k=>html2.includes(k)),'formulaire Devis rapide : type de ligne, main d’œuvre, imprévus, note');
  ok(ch.includes("d.currency=/^(FC|CDF)$/i.test(q.currency||'')?'FC':'USD'")&&ch.includes('Divers & imprévus ('),'devis → facture : devise CDF reconnue et imprévus repris');}
}

title('17. V81 Gestion : paie, plans CAO, pièces écrites, permis');
{const w=env({load:['exb-storage-bridge.js','exb-v81-core.js','exb-v81-pieces-modeles.js','exb-v122-pieces-chantier.js','exb-v122e-modeles-complementaires.js','exb-v122-modeles-a.js','exb-v122-modeles-b.js','exb-v122-modeles-c.js','exb-v81-pieces.js','exb-v122-docs-chantier.js','exb-v81-plans.js','exb-v81-permis.js','exb-v81-paie.js']});
 const P=w.EXBPAY.defaults,c1=w.EXBPAY.calc(1400000,{...P,deductInss:false,iprCap:0},0);
 ok(Math.round(c1.ipr)===190560,'IPR : 1 400 000 FC → 190 560 FC (barème progressif)',String(c1.ipr));
 const c2=w.EXBPAY.calc(2240000,{...P,deductInss:false,iprCap:0},0);ok(Math.round(c2.ipr)===382560,'IPR : 2 240 000 FC → 382 560 FC (3 tranches)',String(c2.ipr));
 const c3=w.EXBPAY.calc(1000000,P,0);ok(Math.round(c3.inssE)===50000&&Math.round(c3.inssP)===130000,'INSS : 5 % salarié, 13 % employeur');
 const c4=w.EXBPAY.calc(1000000,P,3),c5=w.EXBPAY.calc(1000000,P,0);ok(c4.ipr<c5.ipr&&Math.abs(c4.ipr/c5.ipr-0.94)<1e-9,'réduction de 2 % par personne à charge');
 ok(w.EXBPAY.calc(100000,P,0).ipr>0&&w.EXBPAY.calc(0,P,0).ipr===0,'IPR nul sans revenu');
 const dxf=['0','SECTION','2','ENTITIES','0','LINE','8','MUR','10','0','20','0','11','1000','21','0','0','CIRCLE','8','POT','10','500','20','500','40','50','0','ENDSEC','0','EOF'].join('\n');
 const s1=w.EXBPLN.parseDxf(dxf);ok(s1.ents.length===2&&s1.layers.MUR===1&&s1.layers.POT===1,'DXF : lignes, cercles et calques lus');
 const dxf2=dxf.replace('11\n1000','11\n1200');const s2=w.EXBPLN.parseDxf(dxf2),df=w.EXBPLN.diffDxf(s1,s2);ok(df.add.length===1&&df.rem.length===1&&df.same.length===1,'DXF : comparaison (1 ajouté, 1 supprimé, 1 inchangé)');
 const blk=['0','SECTION','2','BLOCKS','0','BLOCK','2','B1','10','0','20','0','0','LINE','8','0','10','0','20','0','11','10','21','0','0','ENDBLK','0','ENDSEC','0','SECTION','2','ENTITIES','0','INSERT','2','B1','8','0','10','100','20','100','41','2','42','2','50','0','0','ENDSEC','0','EOF'].join('\n');
 const s3=w.EXBPLN.parseDxf(blk);ok(s3.ents.length===1&&s3.ents[0].p[2]===120&&s3.ents[0].p[3]===100,'DXF : bloc inséré avec échelle et position');
 let thr=false;try{w.EXBPLN.parseDxf('AC1032 binaire')}catch(e){thr=true}ok(thr,'DXF vide/binaire refusé proprement');
 const ifc="ISO-10303-21;\nHEADER;\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n#1=IFCPROJECT('0abc',#2,'Villa',$,$,$,$,$,#3);\n#10=IFCBUILDINGSTOREY('s1',#2,'RDC',$,$,#4,$,$,.ELEMENT.,0.);\n#20=IFCWALLSTANDARDCASE('w1',#2,'Mur A',$,$,#4,#5,$);\n#21=IFCWALL('w2',#2,'Mur B',$,$,#4,#5,$);\n#22=IFCDOOR('d1',#2,'Porte',$,$,#4,#5,$,2.1,0.9);\nENDSEC;\nEND-ISO-10303-21;";
 const si=w.EXBPLN.parseIfc(ifc);ok(si.schema==='IFC4'&&si.project==='Villa'&&si.storeys.length===1&&si.cnt['Murs']===2&&si.cnt['Portes']===1,'IFC : schéma, niveaux et éléments lus');
 ok(typeof w.EXBPIE.open==='function'&&typeof w.EXBPER.open==='function','modules pièces écrites et autorisations chargés')
 {const DD=w.EXBPIE_DATA,M=DD.models;
  ok(['rapport','clause','fiche'].every(k=>DD.types[k]&&Object.keys(M[k]||{}).length>=8)&&Object.keys(DD.types).pop()==='libre','V122 : types Rapport / Clauses / Fiches de chantier présents, « Texte libre » reste en dernier');
  ok(Object.keys(M.pv).length>=15&&M.pv['Réception de la partie']===undefined&&M.pv['Réception provisoire']&&M.pv['Refus de réception']&&M.pv['Essais et contrôles'],'V122 : procès-verbaux enrichis, anciens PV conservés');
  ok(M.lettre['Transmission de documents']&&M.pv['Réception provisoire'].indexOf('RÉCEPTION PROVISOIRE')>0&&M.contrat['Contrat de sous-traitance']&&M.contrat['Avenant au marché'],'V122 : aucun modèle existant écrasé');
  const known=['projet','client','moa','lieu','permis','societe','societe_rep','phase','date','date_effet','entreprise','lot','objet','no','destinataire','dg','dg_role','ville','tel','email','adresse','tagline','pays'];
  const bad=[];Object.keys(M).forEach(t=>Object.keys(M[t]).forEach(n=>(String(M[t][n]).match(/\{\{(\w+)\}\}/g)||[]).forEach(m=>{if(!known.includes(m.slice(2,-2)))bad.push(t+'/'+n+':'+m)})));
  ok(bad.length===0,'V122 : aucune variable {{…}} inconnue dans les modèles',bad.join(', '));
  ok(DD.sign.clause==='none'&&DD.sign.rapport==='dg'&&DD.sign.fiche==='none','V122 : signatures par type (rapport = DG, clauses et fiches = aucune)');}
 ok(w.EXBDCH&&['open','cat','go','somm','all','q','edit'].every(k=>typeof w.EXBDCH[k]==='function'),'V122 : module « Documents de chantier » chargé');
 {const DD=w.EXBPIE_DATA,cnt=t=>t==='cctp'?Object.keys(DD.lots).length:t==='ccap'?Object.keys(DD.ccap).length:Object.keys(DD.models[t]||{}).length;
  const low=Object.keys(DD.types).filter(t=>cnt(t)<50).map(t=>t+':'+cnt(t));
  ok(low.length===0,'V128e : au moins 50 modèles dans chaque onglet des pièces écrites',low.join(', '));
  const pj=R('exb-v81-pieces.js');
  ok(/nativeLayout:true/.test(pj)&&/data-exb-habillage=/.test(pj)&&/@media print\{\.wrap\{height:auto\}/.test(pj)&&/\.wrap>tfoot \.ftw\{position:fixed/.test(pj),'V128e : impression des pièces sans bandeau en double, sans page blanche, QR toujours en bas de page');}
 ok(w.EXBPIE_V122E&&w.EXBPIE_V122E.added>=90&&Object.keys(w.EXBPIE_DATA.models).reduce((n,k)=>n+Object.keys(w.EXBPIE_DATA.models[k]).length,0)>=280,'V122e : au moins 90 modèles complémentaires ajoutés (≥ 280 au total)');
 ok(Object.keys(w.EXBPIE_DATA.models).reduce((n,k)=>n+Object.keys(w.EXBPIE_DATA.models[k]).length,0)>=180&&w.EXBPIE_DATA.types.dossier,'V122 : au moins 180 modèles de documents, type « Dossier de chantier » présent');
  const idx=R('index.html'),swt=R('sw.js'),dbj=R('exb-db.js');
  ok(['core','pieces','plans','permis','paie'].every(n=>idx.includes('exb-v81-'+n+'.js')),'unifié : modules V81 Gestion chargés par index.html');
  ok(['core','pieces','plans','permis','paie'].every(n=>swt.includes("'./exb-v81-"+n+".js'")),'unifié : modules V81 Gestion dans le cache hors ligne');
  ok(['pieces','plans_fichiers','plans_annotations','autorisations','paie'].every(k=>new RegExp(":'"+k+"'").test(dbj)),'unifié : collections pièces, plans, permis et paie synchronisées');
  ok(/'rh','paie'/.test(R('supabase/migration-v81-gestion.sql'))&&/'direction','paie',true,false/.test(R('supabase/migration-v81-gestion.sql')),'unifié : droits SQL de la paie (lecture direction, écriture RH/comptabilité)');
  ok(/BTP|btp/.test(idx)&&idx.includes('exb-v81-pilotage.js')&&idx.includes('exb-v81-securite.js')&&idx.includes('exb-v97-integration.js'),'unifié : pilotage, sécurité et couche Enterprise toujours chargés');
  ok(/ressources humaines/.test(R('supabase/migration-v98-unifie.sql'))&&/on conflict \(fonction,collection\) do nothing/.test(R('supabase/migration-v98-unifie.sql')),'unifié : migration V98 alignant les noms de rôles (rh, chef_projet, conducteur)');
  ok(/exb_q_imp/.test(R('index.html'))&&/sections et sous-totaux|MAIN D/.test(R('exb-metre.js')),'unifié : devis rapide avec main d’œuvre et imprévus restauré');}

title('18. Navigation mobile : une seule partie à l’écran');
{const calls=[],bars={};const tabsEl={style:{display:''},parentNode:{insertBefore(n){bars.n=n}}};
 const sb={innerWidth:400,history:{pushState(){calls.push('push')},back(){calls.push('back')}},scrollTo(){calls.push('top')},addEventListener(){},setTimeout:()=>0};
 sb.window=sb;sb.document={readyState:'loading',querySelector:()=>tabsEl,getElementById:id=>bars.n&&bars.n.id===id?bars.n:null,
  createElement:()=>({style:{},children:[],appendChild(c){this.children.push(c)}})};
 sb.show=function(x){calls.push('show:'+x)};
 vm.runInNewContext(R('exb-v98-nav.js'),sb);sb.EXB_NAV_V98.install();
 sb.show('receipts');
 ok(tabsEl.style.display==='none'&&bars.n&&bars.n.style.display==='block','téléphone : le menu se replie et la barre « ⬅ Menu » apparaît');
 ok(calls.includes('push')&&calls.includes('top'),'téléphone : retour en haut de l’écran + bouton Retour géré');
 sb.show('finances');ok(calls.filter(c=>c==='push').length===1,'pas d’entrée d’historique en double');
 sb.show('dashboard');
 ok(tabsEl.style.display===''&&bars.n.style.display==='none','retour au tableau de bord : menu complet de nouveau visible');
 sb.innerWidth=1400;sb.show('receipts');
 ok(tabsEl.style.display==='','ordinateur : le menu reste affiché (comportement inchangé)');
 const ix=R('index.html');ok(ix.includes('exb-v98-nav.js'),'module de navigation chargé par index.html');
 ok(/sync:!!\(w\.exbSync/.test(R('exb-v97-integration.js'))&&/w\.exbSync\|\|w\.EXBSYNC/.test(R('core/index.js')),'alerte « Intégration V97 incomplète » corrigée (exbSync reconnu)');
 ok(/r\.ok\|\|r\.status<500/.test(ix),'diagnostic : serveur Supabase joignable si une réponse HTTP est reçue');}

function end(){
title('13. V90 Enterprise : socle et intégration');
{const v90=R('exb-v90-enterprise.js');
 ok(/EXB90/.test(v90),'module V90 présent et expose EXB90');
 ok(html.includes('exb-v90-enterprise.js'),'V90 chargé par index.html');
 ok(sw.includes("'./exb-v90-enterprise.js'"),'V90 présent dans le cache PWA');
 ok(/enterprise360/.test(html),'onglet Enterprise 360° présent');
 const c90=['achats','sous_traitants','dqe','contrats_rh','validations','signatures','cde_workflows','rapprochement_bancaire','paie','conformite','actifs_entreprise','plans_actions'];
 const colsSrc=R('exb-db.js');
 ok(c90.every(c=>colsSrc.includes("'"+c+"'")),'12 nouvelles collections Enterprise déclarées');
 const sql90=R('supabase/migration-v90-enterprise.sql');
 ok(c90.every(c=>sql90.includes("'"+c+"'")),'droits SQL V90 présents pour toutes les collections');
 ok(/on conflict \(fonction,collection\)/i.test(sql90),'migration V90 idempotente sur les droits');
}


title('15. V94 Architecture / BIM / CDE Enterprise');
{const v94=R('exb-v94-architecture.js'),sql94=R('supabase/migration-v94-architecture-bim-cde.sql');
 ok(/EXB_ARCH/.test(v94)&&/V94-Architecture-BIM-CDE/.test(v94),'module V94 Architecture/BIM/CDE présent');
 ok(html.includes('exb-v94-architecture.js'),'V94 chargé par index.html');
 ok(sw.includes("'./exb-v94-architecture.js'"),'V94 présent dans le cache PWA');
 const c94=['etudes_v94','plans_v94','revisions_plans_v94','visas_v94','documents_cde_v94','bim_models_v94','bim_issues_v94','diffusions_v94'];
 ok(c94.every(c=>sql94.includes('create table if not exists '+c)),'8 tables Architecture/BIM/CDE V94 présentes');
 ok(c94.every(c=>dbSrc.includes("'"+c+"'")),'8 collections V94 déclarées dans le stockage');
 ok(/enable row level security/.test(sql94)&&/est_membre\(org_id\)/.test(sql94),'RLS V94 activée par organisation');
 const w=env({load:['exb-v94-architecture.js']});
 ok(w.EXB_ARCH&&w.EXB_ARCH.kpis().pendingVisas===0,'service V94 initialise correctement');
 const dr=w.EXB_ARCH.createDrawing({code:'A-101',title:'Plan RDC',discipline:'architecture'});
 const rv=w.EXB_ARCH.createRevision(dr.id,{description:'Première émission'});
 const vi=w.EXB_ARCH.requestVisa(rv.id,{reviewer:'BE'});
 ok(rv.revision==='R1'&&vi.status==='pending','révision R1 et visa en attente créés');
 w.EXB_ARCH.decideVisa(vi.id,'approved','Validé pour diffusion');
 ok(w.EXB_ARCH.kpis().pendingVisas===0&&w.EXB_ARCH.kpis().revisions===1,'visa approuvé et historique conservé');
 const bm=w.EXB_ARCH.registerBimModel({name:'Modele coordination',format:'IFC',version:'01'});
 const issue=w.EXB_ARCH.createBimIssue({model_id:bm.id,title:'Collision niveau 1',priority:'high'});
 ok(bm.format==='IFC'&&issue.status==='open','modèle BIM et issue BIM créés');
 w.EXB_ARCH.distribute(rv.id,['client@example.com'],{channel:'portal'});
 ok(w.EXB_ARCH.kpis().distributions===1,'diffusion contrôlée enregistrée');
 {const v68=R('exb-v68.js'),et=R('exb-etudes.js'),v81=R('exb-v81-plans.js');
  ok(/EXB_ARCH\.addCde/.test(v68)&&/EXB_ARCH\.cdeRows/.test(v68)&&/EXB_ARCH\.bimRows/.test(v68),'source unique : CDE et issues BIM (V68) lisent/écrivent le modèle V94');
  ok(/plansNested/.test(et)&&/savePlanNested/.test(et)&&/deletePlan/.test(et),'source unique : plans du Bureau d\'études = modèle V94');
  ok(/linkPlanFile/.test(v81),'source unique : fichiers de plans V81 rattachés à une révision V94');
  ok(/migrateLegacy/.test(v94)&&R('supabase/migration-v99-source-unique-plans-bim.sql').includes('droits_fonction'),'source unique : migration des anciennes données et des droits');}
 {const sy=R('exb-sync.js'),db=R('exb-db.js'),v94s=R('exb-v94-architecture.js');
  ok(/handles:function\(k\)/.test(db)&&/skip\(k\)/.test(sy)&&/skips:skip/.test(sy),'synchro : exb-sync ignore les clés gérées par la base partagée (un seul circuit par donnée)');
  ok(/registerIfcModel/.test(v94s)&&/unlinkPlanFile/.test(v94s)&&/element_guid/.test(v94s),'flux : IFC -> modèle BIM, liens détachés à la suppression, observation liée au GlobalId');}
}

title('16. V95-V97 Formation / IA / intégration');
{const h=html, swx=sw;
 ok(h.includes('exb-v95-formation.js')&&h.includes('exb-v96-ai.js')&&h.includes('exb-v97-integration.js'),'modules V95/V96/V97 chargés par index.html');
 ok(swx.includes("'./exb-v95-formation.js'")&&swx.includes("'./exb-v96-ai.js'")&&swx.includes("'./exb-v97-integration.js'"),'modules V95/V96/V97 présents dans le cache PWA');
 ok(fs.existsSync(path.join(root,'supabase','migration-v97-integration.sql')),'migration SQL V97 présente');
 const sql97=R('supabase/migration-v97-integration.sql');
 ok(['core_workflow_links','formation_workflows','ai_insights','core_approval_queue'].every(c=>sql97.includes('create table if not exists '+c)),'tables d’intégration V97 présentes');
 const w=env({load:['core/index.js','exb-v95-formation.js','exb-v96-ai.js','exb-v97-integration.js']});
 ok(w.EXB_FORMATION_V95&&w.EXB_FORMATION_V95.stages.length===7,'workflow Formation V95 : 7 étapes');
 const f=w.EXB_FORMATION_V95.upsert({participant_id:'P1',stage:'learner'});w.EXB_FORMATION_V95.advance(f.id,'evaluation',{score:82});ok(w.EXB_FORMATION_V95.get(f.id).stage==='evaluation','parcours apprenant progressif');
 const ai=w.EXB_AI_V96.propose('project_risk',{avancement:20,expected:50,budget:100,spent:40});ok(ai.requires_human_validation===true&&ai.actions.length>0,'IA : recommandation sans écriture automatique');
 const st=w.EXB_V97.status();ok(st.version==='V97-Enterprise'&&st.flow.length>=18,'V97 : flux transverse déclaré');
}

title('14. V92 ERP Enterprise : flux intégrés et sécurité');
{const v92=R('exb-v92-erp.js'),sql92=R('supabase/migration-v92-erp.sql'),erp=R('erp/index.js');
 ok(/EXB_ERP/.test(v92)&&/V92-ERP-Enterprise/.test(v92),'module V92 ERP présent');
 ok(html.includes('exb-v92-erp.js'),'V92 ERP chargé par index.html');
 ok(sw.includes("'./exb-v92-erp.js'"),'V92 ERP présent dans le cache PWA');
 ok(/V92-ERP-Enterprise/.test(erp)&&/purchase-to-pay/.test(erp),'registre ERP V92 et flux purchase-to-pay déclarés');
 const tabs=['erp_contacts','erp_fournisseurs','erp_demandes_achat','erp_commandes_achat','erp_receptions','erp_factures_fournisseurs','erp_mouvements_stock','erp_comptes_bancaires','erp_transactions_bancaires','erp_employes','erp_contrats_rh','erp_paies'];
 ok(tabs.every(t=>sql92.includes('create table if not exists '+t)),'12 tables ERP V92 présentes');
 ok(/enable row level security/.test(sql92)&&/est_membre\(org_id\)/.test(sql92),'RLS ERP V92 activée par organisation');
 ok(/droits_fonction/.test(sql92)&&/achats/.test(sql92)&&/stocks/.test(sql92)&&/rh/.test(sql92)&&/comptabilite/.test(sql92),'droits métiers ERP V92 déclarés');
 const w=env({load:['exb-v92-erp.js']});
 ok(w.EXB_ERP&&typeof w.EXB_ERP.kpis==='function'&&w.EXB_ERP.kpis().commandes===0,'service ERP V92 initialise correctement');
 w.EXB_ERP.createPurchaseOrder({numero:'CMD-TEST',amount:1250});
 ok(w.EXB_ERP.kpis().commandes===1&&w.EXB_ERP.kpis().engagements===1250,'commande ERP créée et engagement calculé');
 w.EXB_ERP.receiveOrder({order_id:'CMD-TEST',item_id:'ART-1',quantity:10});
 ok(w.EXB_ERP.kpis().stockNet===10,'réception ERP alimente le stock');
 w.EXB_ERP.createSupplierInvoice({numero:'FF-TEST',amount:500,status:'unpaid'});
 ok(w.EXB_ERP.kpis().dettesFournisseurs===500,'facture fournisseur alimente les dettes');
}

title('V99o. QR de vérification public');
{
  const vh=fs.existsSync(path.join(root,'verification.html'))?R('verification.html'):'';
  ok(!!vh,'verification.html présent');
  ok(!/index\.html|exb-license|licence-config/.test(vh),'verification.html : aucun lien vers le logiciel ni la licence');
  ok(fs.existsSync(path.join(root,'exb-verif.js')),'exb-verif.js présent');
  ok(sw.includes("'./verification.html'")&&sw.includes("'./exb-verif.js'")&&sw.includes("'./exb-docs.js'"),'page de vérification dans le cache hors ligne');
  ok(/\/verification\s+\/verification\.html/.test(R('_redirects')),'_redirects : /verification');
  const sq=R('supabase/migration-v99o-qr-public.sql');
  ok(/'document'/.test(sq)&&/exb_doc_registry/.test(sq),'migration V99o : type « document » ajouté');
}

title('V99zn. Synchronisation des modules ERP / BTP / paiements et données sensibles');
{
  const db=R('exb-db.js'),sq=R('supabase/migration-v99zn-synchro-modules.sql');
  const keys=[...R('exb-v92-erp.js').matchAll(/'(exb_v92_[a-z_]+)'/g)].map(m=>m[1]).concat([...R('exb-v93-btp.js').matchAll(/'(exb_v93_[a-z_]+)'/g)].map(m=>m[1]),[...R('exb-v93-payments.js').matchAll(/'(exb_v93_[a-z_]+)'/g)].map(m=>m[1]));
  const colsLine=(db.match(/COLS=\{[^\n]*\};/)||[''])[0];
  const absent=[...new Set(keys)].filter(k=>colsLine.indexOf(k+':')<0);
  ok(keys.length>=22&&absent.length===0,'toutes les clés V92 / V93 (ERP, BTP, paiements) sont synchronisées par exb-db.js',absent.join(', '));
  ok(/exb_formation_workflow_v95:/.test(colsLine)&&/exb_workflow_links_v97:/.test(colsLine),'workflow formation V95 et liens V97 synchronisés');
  const cols=[...colsLine.matchAll(/(exb_[a-z0-9_]+):'([a-z0-9_]+)'/g)].map(m=>m[2]);
  ok(new Set(cols).size===cols.length,'aucun nom de collection en double dans exb-db.js');
  const need=['v92_crm','v92_commandes','v92_employes','v92_paies','v92_banques','v93_projets','v93_paiements','v93_operations_caisse','v95_formation_workflow','v97_liens_flux'];
  ok(need.every(c=>sq.indexOf("'"+c+"'")>=0),'migration V99zn : droits déclarés pour les nouvelles collections');
  ok(/create or replace function peut\(/.test(sq)&&/collections_sensibles/.test(sq),'migration V99zn : fonction peut() réécrite avec les collections sensibles');
  ok(/delete from droits_fonction[\s\S]*fonction='polyvalent'/.test(sq),'migration V99zn : droits « polyvalent » retirés sur les collections sensibles');
  const sens=(db.match(/var SENS=\{([^}]*)\}/)||['',''])[1].split(',').map(x=>x.split(':')[0].trim()).filter(Boolean);
  const sensSql=[...(sq.match(/insert into collections_sensibles[\s\S]*?on conflict/)||[''])[0].matchAll(/\('([a-z0-9_]+)'\)/g)].map(m=>m[1]);
  ok(sens.length>=9&&sens.slice().sort().join()===sensSql.slice().sort().join(),'liste des collections sensibles identique côté navigateur et côté serveur',sens.join()+' / '+sensSql.join());
  ok(/PM-/.test(R('exb-v93-payments.js'))&&/function dedupe/.test(R('exb-v93-payments.js')),'moyens de paiement par défaut : identifiants fixes et dédoublonnage');
  ok(fs.existsSync(path.join(root,'tools/test-synchro/test.py')),'test de synchro multi-appareils présent (tools/test-synchro)');
}

title('V99zo. Sécurité côté serveur : licence à l\'écriture, appels anonymes, anti-spam');
{
  const sq=R('supabase/migration-v99zo-securite-serveur.sql'),db=R('exb-db.js');
  ok(/create or replace function licence_ecriture_ok/.test(sq)&&/licence_ecriture_ok\(p_org\)/.test(sq),'migration V99zo : licence suspendue / échue refusée à l\'écriture (enregistrer)');
  ok(/as restrictive for insert/.test(sq)&&/as restrictive for update/.test(sq)&&/as restrictive for delete/.test(sq),'migration V99zo : même règle sur les tables dédiées (politiques restrictives)');
  ok(/revoke execute on function %s from public, anon/.test(sq)&&/'exb_generer_recurrences\(uuid\)'/.test(sq)&&/'enregistrer\(uuid,text,text,jsonb,integer,boolean\)'/.test(sq),'migration V99zo : appel anonyme retiré des fonctions d\'API (dont les récurrences)');
  ok(/>= 300/.test(sq)&&/paiement_declarer/.test(sq),'migration V99zo : plafond global sur la déclaration publique de paiement');
  ok(!/exb_doc_verify/.test((sq.match(/revoke execute[\s\S]*?end \$\$;/)||[''])[0]),'migration V99zo : la vérification publique de documents reste ouverte');
  ok(/licDeny/.test(db)&&/Licence suspendue ou expirée/.test(db),'application : message clair quand le serveur refuse pour cause de licence');
  ok(fs.existsSync(path.join(root,'tools/test-rls/run.sh'))&&fs.existsSync(path.join(root,'tools/test-rls/test-rls.sql')),'test des politiques RLS présent (tools/test-rls)');
}

title('V99zz. Politiques RLS : droits par fonction sur les tables dédiées sensibles');
{
  const sq=R('supabase/migration-v99zz-droits-tables-dediees.sql'),rs=R('tools/test-rls/run.sh'),tt=R('tools/test-rls/test-rls.sql'),au=R('tools/rls-audit.py');
  ['erp_paies','erp_contrats_rh','erp_employes','erp_comptes_bancaires','erp_transactions_bancaires','moyens_paiement','paiements','operations_caisse'].forEach(t=>ok(sq.includes("'"+t+"'"),'migration V99zz : table '+t+' alignée sur peut() (droits par fonction)'));
  ok(/peut\(org_id,%L,false\)/.test(sq)&&/peut\(org_id,%L,true\)/.test(sq)&&!/est_membre/.test(sq.replace(/--[^\n]*/g,'')),'migration V99zz : lecture et écriture par peut(), plus de contrôle par le seul rôle');
  ok(!/drop policy[^;]*licence_/.test(sq.replace(/--[^\n]*/g,'')),'migration V99zz : les politiques de licence (V99zo) ne sont pas touchées');
  ok(rs.includes('migration-v99zz-droits-tables-dediees')&&/ECHEC migration/.test(rs),'banc d\'essai RLS : migration V99zz chargée, échecs de migration affichés (plus avalés)');
  ok(/T34/.test(tt)&&/T40/.test(tt),'tests RLS T34 à T40 : paie et paiements inaccessibles sans le droit de la fonction');
  ok(/def add_stmt/.test(au)&&/foreach/.test(au),'audit statique des politiques RLS présent (tools/rls-audit.py)');
}

title('V99zp. Double authentification (2FA / TOTP)');
{ const sq=fs.readFileSync('supabase/migration-v99zp-double-authentification.sql','utf8'), mj=fs.readFileSync('exb-mfa.js','utf8'), ix=fs.readFileSync('index.html','utf8');
  ok(/function mfa_ok/.test(sq)&&/auth\.mfa_factors/.test(sq)&&/aal2/.test(sq),'migration V99zp : mfa_ok() exige aal2 si un facteur TOTP est vérifié');
  ok(/select mfa_ok\(\) and exists/.test(sq),'migration V99zp : peut() impose la 2FA (lecture et écriture)');
  ok(/revoke execute on function mfa_ok\(\) from public, anon/.test(sq),'migration V99zp : mfa_ok non appelable en anonyme');
  ok(/\/auth\/v1\/factors/.test(mj)&&/challenge/.test(mj)&&/verify/.test(mj),'exb-mfa.js : enrôlement, défi et vérification TOTP');
  ok(/exb-mfa\.js/.test(ix)&&sw.includes("'./exb-mfa.js'"),'exb-mfa.js chargé et dans le cache PWA');
  ok(fs.existsSync('tools/test-mfa/test.py'),'test client 2FA présent (tools/test-mfa)'); }

title('V99zv. Suivi d\'erreurs et métriques d\'usage');
{ const sq=fs.readFileSync('supabase/migration-v99zv-suivi-erreurs.sql','utf8'), mj=fs.readFileSync('exb-errors.js','utf8'), ix=fs.readFileSync('index.html','utf8');
  ok(/create or replace function erreur_signaler/.test(sq)&&/if uid is null then raise exception/.test(sq),'migration V99zv : erreur_signaler exige une connexion');
  ok(/enable row level security/.test(sq)&&/revoke all on exb_erreurs/.test(sq),'migration V99zv : tables fermées (RLS sans politique, aucun droit direct)');
  ok(/est_proprietaire\(\)/.test(sq)&&/revoke execute on function erreur_signaler/.test(sq),'migration V99zv : lecture réservée au propriétaire, appel anonyme retiré');
  ok(/>= 200/.test(sq)&&/left\(/.test(sq),'migration V99zv : plafond horaire et tailles limitées');
  ok(/unhandledrejection/.test(mj)&&/addEventListener\('error'/.test(mj)&&/erreur_signaler/.test(mj),'exb-errors.js : erreurs, promesses rejetées et envoi serveur');
  ok(ix.indexOf('exb-errors.js')>-1&&ix.indexOf('exb-errors.js')<ix.indexOf('exb-keyguard.js')&&sw.includes("'./exb-errors.js'"),'exb-errors.js chargé en premier et dans le cache PWA');
  ok(fs.existsSync('tools/test-errors.js'),'test du module d\'erreurs présent (tools/test-errors.js)'); }

title('V99zw. BIM (lecteur IFC 3D) et plans partagés');
{ const ij=fs.readFileSync('exb-ifc3d.js','utf8'), pj=fs.readFileSync('exb-v81-plans.js','utf8'), sq=fs.readFileSync('supabase/migration-v99zw-plans-partages.sql','utf8'), ix=fs.readFileSync('index.html','utf8');
  ok(/EXB_IFC3D/.test(ij)&&/openText/.test(ij),'lecteur IFC 3D présent (API openText)');
  ok(/exb-ifc3d\.js/.test(ix)&&sw.includes("'./exb-ifc3d.js'"),'lecteur IFC 3D chargé et dans le cache PWA');
  ok(/exb-plans/.test(pj)&&/storage\/v1\/object/.test(pj),'plans : fichiers envoyés dans l\'espace partagé Supabase Storage');
  ok(/'exb-plans','exb-plans',false/.test(sq),'migration V99zw : bucket exb-plans privé');
  ok(/peut\(org_du_chemin\(name\),'plans_fichiers',true\) and licence_ecriture_ok/.test(sq),'migration V99zw : écriture soumise aux droits, à la licence et à la 2FA (via peut)');
  ok(fs.existsSync('tools/test-bim/test.py'),'test navigateur du lecteur 3D présent (tools/test-bim)'); }

{ const ij=fs.readFileSync('exb-ifc3d.js','utf8');
  ok(/function quantities/.test(ij)&&/IFCRELVOIDSELEMENT/.test(ij)&&/volScale/.test(ij),'V99zw : quantités IFC (ouvertures déduites, unités de surface/volume déclarées)');
  ok(/ifQty/.test(ij)&&/function csv/.test(ij),'V99zw : tableau des quantités et export CSV dans le lecteur');
  ok(fs.existsSync('tools/test-bim/test-quantites.js'),'V99zw : test des quantités présent'); }

{ const mj=fs.readFileSync('exb-metre.js','utf8'), ij=fs.readFileSync('exb-ifc3d.js','utf8');
  ok(/function addLignes/.test(mj)&&/addLignes,/.test(mj),'V99zw : le métré reçoit des lignes externes (EXBMetre.addLignes, sans doublon)');
  ok(/qMet/.test(ij)&&/EXBMetre/.test(ij)&&/addLignes/.test(ij),'V99zw : bouton « Envoyer au métré » dans les quantités IFC'); }

title('V99zy. Portails client / sous-traitant, e-signature, relances');
{ const pj=fs.readFileSync('exb-v99zy-portails.js','utf8'), ph=fs.readFileSync('portail.html','utf8'), sq=fs.readFileSync('supabase/migration-v99zy-portails.sql','utf8'), ix=fs.readFileSync('index.html','utf8'), db=fs.readFileSync('exb-db.js','utf8'), rl=fs.readFileSync('exb-roles.js','utf8'), sh=fs.readFileSync('exb-v99r-shell.js','utf8');
  ok(/exb-v99zy-portails\.js/.test(ix)&&sw.includes("'./exb-v99zy-portails.js'"),'portails : module chargé et dans le cache PWA');
  ok(/bportails:'crm'/.test(sh),'portails : tuile dans Clients & CRM');
  ok(/exb_portails:'portails',exb_esign:'esign',exb_msg_queue:'relances'/.test(db)&&/portails:\{b:'bportails'/.test(rl),'portails : collections synchronisées et droits par fonction');
  ok(/peut\(p_org, 'portails', true\)/.test(sq)&&/licence_ecriture_ok\(p_org\)/.test(sq),'migration V99zy : publication soumise aux droits, à la licence et à la 2FA (via peut)');
  ok(/code_hash text not null/.test(sq)&&!/\n\s+code text/.test(sq)&&/bloque_jusqua/.test(sq),'migration V99zy : code d\'accès haché, blocage après essais ratés');
  ok(/enable row level security/.test(sq)&&!/create policy[^;]*to anon/.test(sq),'migration V99zy : RLS active, aucune lecture anonyme directe');
  ok(/innerHTML/.test(ph)&&/function esc\(/.test(ph)&&!/eval\(/.test(ph),'portail.html : échappement du contenu affiché');
  ok(!/exb_portails[^;]*code:/.test(pj)||/delete r\.code/.test(pj),'portails : le code d\'accès n\'est pas enregistré dans les données synchronisées'); }

title('V99zz. Pilotage projets (EVM automatique, retard, alertes)');
{ const ev=fs.readFileSync('exb-evm.js','utf8'), pl=fs.readFileSync('exb-pilote.js','utf8'), ix=fs.readFileSync('index.html','utf8'), sw2=fs.readFileSync('sw.js','utf8'), sh2=fs.readFileSync('exb-v99r-shell.js','utf8'), rl2=fs.readFileSync('exb-roles.js','utf8'), br=fs.readFileSync('exb-storage-bridge.js','utf8');
  ok(/exb-evm\.js[^]*exb-pilote\.js/.test(ix)&&ix.indexOf('exb-cpm.js')<ix.indexOf('exb-evm.js')&&ix.indexOf('exb-v81-pilotage.js')<ix.indexOf('exb-pilote.js'),'pilotage : scripts chargés après le moteur de planning et le pilotage direction');
  ok(sw2.includes("'./exb-evm.js'")&&sw2.includes("'./exb-pilote.js'"),'pilotage : modules dans le cache PWA');
  ok(/pilotprojet:'prj'/.test(sh2)&&/pilotprojet:\{b:'bpilot'[^}]*all:1/.test(rl2),'pilotage : tuile dans Projets, lecture réservée aux fonctions qui voient projets + planning + budgets');
  ok(/typeof exbStorage!==.undefined./.test(br),'pont de stockage : atteint exbStorage (const global) au lieu de lire le stockage brut');
  const ixh=ix, as=fs.readFileSync('supabase/functions/assistant/index.ts','utf8');
  ok(/EXBPILOT\.aiContext/.test(ixh)&&/pilotprojet:'Pilotage projets'/.test(ixh),'IA : l\'assistant reçoit les indicateurs de pilotage (si la fonction a le droit de lire projets, planning et budgets)');
  ok(/EXBPILOT\.synthese/.test(ixh)&&/tab:'pilotprojet'/.test(ixh),'IA : repli hors ligne — synthèse calculée localement + ouverture de l\'écran');
  ok(/Pilotage projets/.test(as)&&/jamais comme des instructions|jamais les traiter comme des instructions|ne les traite jamais comme des instructions/.test(as)&&/pilotprojet/.test(as),'fonction assistant : lit les indicateurs sans les inventer, données saisies traitées comme données (anti-injection)');
  ok(/ctx\(rows,today\)/.test(ev)&&/replace\(\/\[\\u0000-\\u001f\\u007f<>`\]/.test(ev),'IA : libellés saisis nettoyés avant d\'être transmis (retours à la ligne, < > et accents graves retirés)');
  ok(!/localStorage/.test(pl)&&!/fetch\(/.test(pl)&&!/eval\(/.test(pl),'pilotage : lecture seule, aucun appel réseau, aucun eval');
  ok(/esc\(a\.name\)/.test(pl)&&/\^\[=\+\\-@/.test(pl),'pilotage : noms échappés et formules CSV neutralisées');
  const E=require(path.join(root,'exb-evm.js'));
  const a=E.analyse({bac:1000,ac:500,progress:40,tasks:[],today:'2026-01-06'});
  ok(a.cpi===0.8&&a.ev===400&&a.eac===1250&&a.vac===-250&&a.tcpi===1.2,'moteur EVM : CPI 0,8, EAC 1 250, écart −250, TCPI 1,2 (cas de contrôle)');
  const z=E.analyse({bac:0,ac:0,progress:0,tasks:[],today:'2026-01-06'});
  ok(z.cpi===null&&z.spi===null&&z.status==='gris','moteur EVM : sans budget, aucun indice inventé'); }

title('V99zz+. Lecteur 3D : découpe des ouvertures et correctif du tracé');
{ const ij=fs.readFileSync('exb-ifc3d.js','utf8');
  ok(/function carve/.test(ij)&&/function planesOf/.test(ij)&&/warn\.cut/.test(ij),'découpe réelle des ouvertures dans les murs et dalles convexes');
  ok(/drawArrays\(gl\.TRIANGLES, a, n\)/.test(ij)&&!/a \* 3, n \* 3/.test(ij),'correctif du tracé (start/count en sommets) : tous les éléments se dessinent');
  ok(fs.existsSync('tools/test-bim/test-quantites.js'),'test des quantités et de la découpe présent'); }

{ const dbj=fs.readFileSync('exb-db.js','utf8'), sq=fs.readFileSync('supabase/migration-v99zzc-decomptes-synchro.sql','utf8');
  ok(/exb_decomptes:'decomptes'/.test(dbj),'V99zzc : marchés et décomptes synchronisés par le moteur versionné (exb-db.js)');
  ok(/'decomptes'/.test(sq)&&/collection = 'finance'/.test(sq),'V99zzc : migration — droits « decomptes » copiés de « finance »'); }

title('V99zzf. Pilotage : seuils d\'alerte réglables, rapport PDF de chantier');
{ const ev=fs.readFileSync('exb-evm.js','utf8'), pl=fs.readFileSync('exb-pilote.js','utf8'), pd=fs.readFileSync('exb-pdf.js','utf8');
  ok(/function thFor\(/.test(ev)&&/function validateTh\(/.test(ev)&&/sane\(th\)/.test(ev),'seuils : validation, priorité chantier > général > défauts, valeurs incohérentes ignorées');
  ok(/exb_pilot_th/.test(pl)&&/canW\(\)/.test(pl)&&/validateTh/.test(pl),'seuils : modification réservée à l\'écriture des budgets, validée avant enregistrement');
  ok(/imagesTitle/.test(pd)&&/o\.imagesTitle\|\|'PHOTOS'/.test(pd),'PDF : titre de la section d\'images configurable (PHOTOS par défaut, autres modules inchangés)');
  ok(/function pdfReport\(/.test(pl)&&/RAPPORT DE PILOTAGE DE CHANTIER/.test(pl)&&/Décision à prendre/.test(pl),'rapport PDF : état, tendance, points d\'attention, décisions, graphiques');
  ok(!/\u2265/.test(pl.slice(pl.indexOf('function reportOpts'),pl.indexOf('function pdfReport'))),'rapport PDF : aucun caractère que le moteur PDF ne sait pas écrire');
  ok(/D2\(cpi\)/.test(ev)&&!/\+r2\(cpi\)\+'/.test(ev),'messages d\'alerte : décimales avec virgule'); }

{ const vs=fs.readFileSync('supabase/migration-v99zzf-validation-ingenieur.sql','utf8'), vd=fs.readFileSync('calcul-structure/exb-calcul-doc.js','utf8'), vb=fs.readFileSync('exb-db.js','utf8'), rs=fs.readFileSync('tools/test-rls/run.sh','utf8');
  ok(/create table if not exists validations_calcul/.test(vs)&&/create or replace function calcul_valider/.test(vs)&&/create or replace function calcul_verifier/.test(vs),'V99zzf validation ingénieur : table et fonctions serveur présentes');
  ok(/before update or delete on validations_calcul/.test(vs)&&/before truncate on validations_calcul/.test(vs)&&/revoke insert, update, delete, truncate on validations_calcul/.test(vs),'V99zzf journal des validations en ajout seul (déclencheurs + droits retirés)');
  ok(/aal2/.test(vs)&&/session_2fa_requise/.test(vs)&&/ingenieur_habilite_requis/.test(vs)&&/licence_ecriture_ok\(p_org\)/.test(vs),'V99zzf valider exige 2FA, ingénieur habilité et licence active');
  ok(/'calcul_valider'/.test(vd)&&/'calcul_journal'/.test(vd)&&/src: S \? 'serveur' : 'local'/.test(vd)&&/non probant/.test(vd),'V99zzf note de calcul : validation enregistrée sur le serveur, repli local signalé non probant');
  ok(/habiliter:async/.test(vb)&&/org:function\(\)/.test(vb)&&/ingenieur_designer/.test(vb),'V99zzf équipe : désignation des ingénieurs habilités');
  ok(/migration-v99zzf-validation-ingenieur/.test(rs)&&/test-validation\.sql/.test(rs),'V99zzf test SQL branché dans run.sh'); }
{ const vs2=fs.readFileSync('supabase/migration-v99zzf-validation-ingenieur.sql','utf8'), vh=fs.readFileSync('verification.html','utf8'), vd2=fs.readFileSync('calcul-structure/exb-calcul-doc.js','utf8');
  ok(/create table if not exists validations_qr/.test(vs2)&&/create or replace function calcul_lier_qr/.test(vs2)&&/create or replace function calcul_verifier\(p_no text, p_code text\)/.test(vs2)&&/validation_serveur_absente/.test(vs2),'V99zzf QR : table de liaison, fonction de lien et vérification par code');
  ok(/'calcul_lier_qr'/.test(vd2)&&/p_code: String\(q\.code\.hash\)/.test(vd2),'V99zzf impression : le code du QR est lié à la validation serveur');
  ok(/rpc\('calcul_verifier'/.test(vh)&&/id="ing"/.test(vh)&&/Document non conforme/.test(vh)&&/Ancienne version du calcul/.test(vh),'V99zzf verification.html affiche la validation serveur (conforme / périmée / non conforme)'); }
title('V99zzt. TFL : portails étudiant / encadreur avec connexion');
{ const ps=R('supabase/migration-v99zzt-tfl-portails.sql'),pg=R('tfl-portail.html'),tj=R('exb-tfl.js'),sw2=R('sw.js'),rd=R('_redirects');
  const F=['tfl_portail_publier','tfl_portail_revoquer','tfl_portail_liste','tfl_portail_retours','tfl_portail_retours_traiter','tfl_portail_connexion','tfl_portail_changer','tfl_portail_envoyer'];
  ok(F.every(f=>new RegExp('create or replace function public\\.'+f+'\\(').test(ps)),'V99zzt SQL : les 8 fonctions des portails TFL sont définies');
  ok(/alter table public\.tfl_acces enable row level security/.test(ps)&&/alter table public\.tfl_messages enable row level security/.test(ps)&&/revoke all on public\.tfl_acces from anon, authenticated/.test(ps)&&/revoke all on public\.tfl_messages from anon, authenticated/.test(ps)&&!/create policy/.test(ps),'V99zzt SQL : tables fermées (RLS sans politique, aucun droit direct)');
  ok(['publier','revoquer','liste','retours','retours_traiter'].every(n=>{const m=new RegExp('create or replace function public\\.tfl_portail_'+n+'\\([\\s\\S]*?end \\$\\$;').exec(ps);return m&&/tfl_admin_ok\(\)/.test(m[0])&&new RegExp('revoke all on function public\\.tfl_portail_'+n+'\\([^)]*\\) from public, anon;').test(ps)&&!new RegExp('grant execute on function public\\.tfl_portail_'+n+'\\([^)]*\\) to anon').test(ps)}),'V99zzt SQL : publication, révocation, liste et retours réservés à l’administrateur (fermés à l’anonyme)');
  ok(['connexion','changer','envoyer'].every(n=>new RegExp('grant execute on function public\\.tfl_portail_'+n+'\\([^)]*\\) to anon, authenticated;').test(ps)),'V99zzt SQL : connexion, changement de mot de passe et envoi ouverts au visiteur (identifiant + mot de passe exigés)');
  ok(/essais \+ 1 >= 5/.test(ps)&&/interval '15 minutes'/.test(ps)&&/v_err := 'code'; return; end if;   -- même message/.test(ps),'V99zzt SQL : blocage 15 min après 5 essais, identifiant inconnu = même message');
  ok(/length\(v_n\) < 8/.test(ps)&&/doit_changer = false/.test(ps)&&/'code', 'changer'/.test(ps)||/'code', 'changer'/.test(ps),'V99zzt SQL : mot de passe de départ à changer (8 caractères minimum) avant tout envoi');
  ok(/v_ok := v_d <> '' and v_d = coalesce\(a\.contenu->>'numero',''\)/.test(ps)&&/x->>'numero' = v_d/.test(ps)&&/>= 30 then/.test(ps),'V99zzt SQL : écriture limitée au dossier de l’étudiant / de l’encadreur, 30 envois par heure');
  ok(ps.split('\n').filter(l=>/security definer/.test(l)&&!/^--/.test(l)).every(l=>/set search_path = public/.test(l))&&/security definer/.test(ps),'V99zzt SQL : chaque fonction « security definer » fixe son search_path');
  ok(!/localStorage|sessionStorage|indexedDB|document\.cookie/.test(pg)&&/autocomplete="current-password"/.test(pg)&&/noindex/.test(pg),'V99zzt page : mot de passe gardé en mémoire seulement, page non indexée');
  ok(sw2.includes("'./tfl-portail.html'")&&/const V='(?:exb-)?v(?:99|[12]\d\d)[\w-]*'/.test(sw2),'V99zzt page dans le cache PWA (cache exb-v99zzv-tfl-sujets)');
  ok(/tfl_portail_publier/.test(tj)&&/tfl_portail_retours_traiter/.test(tj)&&/exb_tfl_codes/.test(tj)&&/tfl-portail\.html\?role=/.test(tj),'V99zzt module TFL : publication, retours, liens, mots de passe de départ hors sauvegarde');
  ok(/\/tfl-etudiant\s+\/tfl-portail\.html\?role=etudiant/.test(rd)&&/\/tfl-encadreur\s+\/tfl-portail\.html\?role=encadreur/.test(rd),'V99zzt liens courts /tfl-etudiant et /tfl-encadreur'); }
{ const tj=R('exb-tfl.js'),sw2=R('sw.js');
  ok(/exb_tfl_biblio/.test(tj)&&/indexedDB\.open\('exb_tfl_biblio'/.test(tj)&&/function bibAjouter/.test(tj)&&/function bibVersDossier/.test(tj)&&/function bibDepuisDossier/.test(tj),'V99zzu bibliothèque TFL : fiches (sauvegarde) + fichiers (IndexedDB), sujet → dossier, dossier clos → bibliothèque');
  ok(/data-v="biblio"/.test(tj)&&/data-tfl="bAjouter"/.test(tj)&&/data-tfl="bDepuisDos"/.test(tj)&&/'pdf', 'doc', 'docx'/.test(tj)&&/25 \* 1024 \* 1024/.test(tj),'V99zzu écran Bibliothèque : onglets TFL résolus / Sujets reçus, formats PDF et autres, 25 Mo');
  ok(/const V='(?:exb-)?v(?:99|[12]\d\d)[\w-]*'/.test(sw2),'V99zzu cache PWA mis à jour (exb-v99zzv-tfl-sujets)'); }
{ const sq=R('supabase/migration-v99zzv-tfl-sujets.sql'),pg=R('tfl-sujets.html'),tj=R('exb-tfl.js'),sw2=R('sw.js'),rd=R('_redirects');
  const F=['tfl_sujets_publier','tfl_sujet_retirer','tfl_sujets_etat','tfl_sujets_publics','tfl_sujet_choisir'];
  ok(F.every(n=>new RegExp('create or replace function public\\.'+n+'\\(').test(sq)),'V99zzv SQL : les 5 fonctions du catalogue (publier, retirer, état, lecture publique, choisir)');
  ok(/alter table public\.tfl_sujets enable row level security/.test(sq)&&/revoke all on public\.tfl_sujets from anon, authenticated/.test(sq)&&!/create policy/.test(sq),'V99zzv SQL : table des sujets fermée (RLS sans politique, accès par fonctions)');
  ok(['publier','retirer','etat'].every(n=>{const m=new RegExp('create or replace function public\\.tfl_sujet'+(n==='retirer'?'_':'s_')+n+'\\([\\s\\S]*?end \\$\\$;|create or replace function public\\.tfl_sujets_'+n+'\\([\\s\\S]*?end \\$\\$;').exec(sq);return m&&/tfl_sujets_admin_ok\(\)/.test(m[0])}),'V99zzv SQL : publier, retirer et état réservés à l’administrateur');
  ok(/from public\.tfl_sujets where ref = [^;]*for update/.test(sq)&&/sujet_deja_reserve/.test(sq)&&/grant execute on function public\.tfl_sujet_choisir\([^)]*\) to anon, authenticated/.test(sq),'V99zzv SQL : « Choisir » verrouille la ligne (un seul étudiant sur un sujet exclusif) et reste ouvert au visiteur');
  ok(!/reserve_tel/.test((/create or replace function public\.tfl_sujets_publics\(\)[\s\S]*?\$\$;/.exec(sq)||[''])[0]),'V99zzv SQL : la lecture publique ne renvoie aucun téléphone');
  ok(/tfl_sujets_publics/.test(pg)&&/tfl_sujet_choisir/.test(pg)&&/tfl-sujets\.json/.test(pg)&&/EXB_TFL/.test(pg)&&/sujet_ref/.test(pg),'V99zzv page publique : liste, choix en ligne, repli fichier JSON et fichier de candidature');
  ok(/exb_tfl_sujets/.test(tj)&&/function sujetAjouter/.test(tj)&&/function sujetLierDossier/.test(tj)&&/function synchroSujets/.test(tj)&&/EXB-TFL-BTP-/.test(tj)&&/data-v=\"sujets\"/.test(tj),'V99zzv module TFL : catalogue, réservation exclusive, synchronisation, écran Sujets');
  ok(/consultation/.test(tj)&&/pas un travail à recopier/.test(tj),'V99zzv bibliothèque : consultation autorisée + mention « pas un travail à recopier »');
  ok(sw2.includes("'./tfl-sujets.html'")&&/\/tfl-sujets\s+\/tfl-sujets\.html/.test(rd),'V99zzv page publique dans le cache PWA et lien court /tfl-sujets'); }
{ const sq=R('supabase/migration-v99zzw-tfl-banque-sujets.sql'),pg=R('tfl-sujets.html'),tj=R('exb-tfl.js'),sw2=R('sw.js'),bj=JSON.parse(R('tfl-banque.json'));
  ok(bj.sujets.length===4300&&bj.domaines.length===30&&bj.form==='EXB_TFL_BANQUE','V99zzw banque : 4 300 sujets, 30 domaines (tfl-banque.json)');
  ok((sq.match(/\('(?:[A-Z]+-TFL-\d{4}|EXB-BTP-\d{4})','/g)||[]).length===4300&&/on conflict \(ref\) do nothing/.test(sq)&&/false, true, 'disponible'/.test(sq),'V99zzw SQL : 4 300 sujets chargés non publiés, sans écraser les fiches existantes');
  ok(['tfl_sujets_publics_page','tfl_sujets_facettes','tfl_sujets_publier_lot','tfl_norm'].every(n=>new RegExp('create or replace function public\\.'+n+'\\(').test(sq)),'V99zzw SQL : lecture paginée, facettes, publication par lot, normalisation');
  ok(/tfl_sujets_admin_ok\(\)/.test((/create or replace function public\.tfl_sujets_publier_lot[\s\S]*?end \$\$;/.exec(sq)||[''])[0])&&/limit least\(greatest\(coalesce\(p_limit,30\), 1\), 60\)/.test(sq)&&/limit 300/.test(sq),'V99zzw SQL : publication par lot réservée à l’administrateur (300 au plus), page publique limitée à 60 fiches');
  ok(!/reserve_tel/.test((/create or replace function public\.tfl_sujets_publics_page[\s\S]*?\$\$;/.exec(sq)||[''])[0]),'V99zzw SQL : la lecture paginée ne renvoie aucun téléphone');
  ok(sq.split('\n').filter(l=>/security definer/.test(l)&&!/^--/.test(l)).every(l=>/set search_path = public/.test(l)),'V99zzw SQL : chaque fonction « security definer » fixe son search_path');
  ok(/tfl_sujets_publics_page/.test(pg)&&/tfl_sujets_facettes/.test(pg)&&/tfl_sujets_publics'/.test(pg)&&/Voir plus de sujets/.test(pg),'V99zzw page publique : lecture paginée avec repli sur l’ancienne fonction');
  ok(/function banqueAdopter/.test(tj)&&/function banqueChercher/.test(tj)&&/tfl-banque\.json/.test(tj)&&/data-tfl=\"bqAdd\"/.test(tj)&&/ci \+= 300/.test(tj),'V99zzw module TFL : banque (recherche, adoption, 300 au plus), synchronisation par lots de 300');
  ok(/const V='(?:exb-)?v(?:99|[12]\d\d)[\w-]*'/.test(sw2),'V99zzw cache PWA mis à jour (exb-v99zzw-tfl-banque)'); }
{ const fi=R('tfl-fiche.html'),sj=R('tfl-sujets.html'),tj=R('exb-tfl.js'),sq=R('supabase/migration-v99zzx-tfl-fiche-etudiant.sql'),sw2=R('sw.js'),rd=R('_redirects');
  ok(/annee_academique/.test(fi)&&/promotion/.test(fi)&&/filiere/.test(fi)&&/id="photo"/.test(fi)&&/tfl_fiche_etudiant_envoyer/.test(fi)&&/EXB_TFL/.test(fi),'V99zzx fiche étudiante : photo, année académique, promotion, spécialité, envoi en ligne ou fichier');
  ok(/ouvrirFiche/.test(sj)&&/window\.open\(u,'_blank'\)/.test(sj)&&/tfl-fiche\.html\?r=/.test(sj),'V99zzx après « Choisir ce sujet » : la fiche s’ouvre dans un nouvel onglet (lien de secours si bloqué)');
  ok(/tfl_fiche_etudiant_envoyer/.test(sq)&&/security definer set search_path/.test(sq)&&/choix_introuvable/.test(sq)&&/photo_trop_lourde/.test(sq),'V99zzx SQL : fonction sécurisée, refuse une fiche sans choix préalable');
  ok(/function ficheEtudiant/.test(tj)&&/annee_academique/.test(tj)&&/memeSujet/.test(tj),'V99zzx module TFL : fiche complète affichée, pas de doublon de dossier pour le même sujet');
  ok(/exb-verif\.js/.test(fi)&&/exb-qr\.js/.test(fi)&&/exb-form\.js/.test(fi)&&/faireFiche/.test(fi)&&/EXBVerif\.qrPng/.test(fi)&&/exb_doc_declare|EXBVerif\.declare/.test(fi)&&/pdfBlobAsync/.test(fi),'V99zzx fiche PDF avec photo, QR de vérification et enregistrement au registre (même système que les fiches d’inscription)');
  ok(/EXBVerif/.test(tj)&&/docUrl/.test(tj)&&/qr: qr/.test(tj),'V99zzx attestation de dépôt côté administrateur : QR de vérification');
  ok(sw2.includes("'./tfl-fiche.html'")&&/\/tfl-fiche\s+\/tfl-fiche\.html/.test(rd),'V99zzx page dans le cache PWA et lien court /tfl-fiche'); }
{ const sq=R('supabase/migration-v99zzy-securite-tfl-qr.sql'),fi=R('tfl-fiche.html'),sj=R('tfl-sujets.html'),vp=R('verification.html'),ev=R('exb-verif.js'),sw2=R('sw.js'),rs=R('tools/test-rls/run.sh');
  ok(/fiche_token_hash/.test(sq)&&/jeton_requis/.test(sq)&&/jeton_invalide/.test(sq)&&/p_token text default null/.test(sq)&&/drop function if exists public\.tfl_fiche_etudiant_envoyer\(text, jsonb, text\)/.test(sq),'V99zzy SQL : fiche étudiante protégée par un jeton (anciens choix sans jeton acceptés)');
  ok(/'token', v_token/.test(sq)&&/renvoi de la même demande : aucun nouveau jeton/.test(sq),'V99zzy SQL : jeton remis une seule fois, jamais ré-émis au renvoi');
  ok(/trop_de_reservations/.test(sq)&&/v_jours constant int := 14/.test(sq)&&/exb_ip_limite\('tfl_choisir'/.test(sq)&&/exb_ip_limite\('tfl_fiche'/.test(sq),'V99zzy SQL : 2 réservations au plus par numéro, expiration 14 jours, limite par IP');
  ok(/add column if not exists anon boolean/.test(sq)&&/'confirmed', not r\.anon/.test(sq)&&/not anon order by created_at desc/.test(sq)&&/exb_doc_confirmer/.test(sq),'V99zzy SQL : dépôts publics « non confirmés », ne déclassent plus un document officiel');
  ok(sq.split('\n').filter(l=>/security definer/.test(l)&&!/^--/.test(l)).every(l=>/set search_path = public/.test(l)),'V99zzy SQL : chaque fonction « security definer » fixe son search_path');
  ok(/p_token:CHOIX\.token/.test(fi)&&/jeton_requis/.test(fi)&&/ouvrirFiche\(s,d,rep&&rep\.token\)/.test(sj),'V99zzy pages : jeton transmis du choix à la fiche, messages clairs');
  ok(/r\.confirmed===false/.test(vp)&&/r\.confirmed === false/.test(ev),'V99zzy vérification publique : « Fiche déposée, non confirmée » au lieu de « authentique »');
  ok(/const V='(?:exb-)?v(?:99|[12]\d\d)[\w-]*'/.test(sw2)&&/migration-v99zzy-securite-tfl-qr/.test(rs)&&fs.existsSync(path.join(root,'tools/test-rls/test-tfl-qr.sql')),'V99zzy cache PWA mis à jour + tests d’attaque ajoutés au banc RLS'); }
{ const sq=R('supabase/migration-v99zzz-tfl-sans-limite.sql'),sj=R('tfl-sujets.html'),sw2=R('sw.js'),rs=R('tools/test-rls/run.sh'),tq=R('tools/test-rls/test-tfl-qr.sql');
  ok(!/trop_de_reservations/.test(sq)&&!/v_max_res|v_jours/.test(sq)&&!/exb_ip_limite/.test(sq)&&!/'telephone' = v_tel and created_at/.test(sq),'V99zzz SQL : plus de plafond de sujets, plus d’expiration, plus de limite par numéro ni par adresse IP');
  ok(/jeton_requis/.test(sq)&&/jeton_invalide/.test(sq)&&/'token', v_token/.test(sq)&&/renvoi de la même demande : aucun nouveau jeton/.test(sq),'V99zzz SQL : le jeton de la fiche étudiante (V99zzy) est conservé');
  ok((sq.match(/s\.publie and \(s\.statut = 'disponible' or \(not s\.exclusif and s\.statut = 'reserve'\)\)/g)||[]).length===3,'V99zzz SQL : liste, liste paginée et facettes masquent un sujet exclusif déjà choisi');
  ok(sq.split('\n').filter(l=>/security definer/.test(l)&&!/^--/.test(l)).every(l=>/set search_path = public/.test(l)),'V99zzz SQL : chaque fonction « security definer » fixe son search_path');
  ok(/function visible\(s\)/.test(sj)&&/SUJETS\.filter\(visible\)/.test(sj)&&!/value=\"reserve\"/.test(sj)&&!/trop_de_reservations/.test(sj),'V99zzz page : un sujet exclusif déjà choisi n’est plus affiché (même sans la migration), plus de filtre « Réservés »');
  ok(/const V='(?:exb-)?v(?:99|[12]\d\d)[\w-]*'/.test(sw2)&&/migration-v99zzz-tfl-sans-limite/.test(rs)&&/V1 sujets exclusifs réservés/.test(tq),'V99zzz cache PWA mis à jour + tests ajoutés au banc RLS'); }
/*CTB*/
{ const sqc=fs.readFileSync('supabase/migration-v99zzzzzz-tfl-contributions.sql','utf8'), pg=fs.readFileSync('tfl-contribution.html','utf8');
  const sqNoCom=sqc.split('\n').filter(l=>!/^\s*--/.test(l)).join('\n');
  ok(sqNoCom.split('\n').filter(l=>/security definer/.test(l)).every(l=>/set search_path = public/.test(l)),'V99zzzzzzz contributions SQL : chaque fonction « security definer » fixe son search_path');
  ok(/revoke all on public\.tfl_contributions from anon, authenticated/.test(sqc)&&/enable row level security/.test(sqc)&&(sqc.match(/<> all \(array\[/g)||[]).length===3,'V99zzzzzzz contributions SQL : table fermée, liste / fichier / « traitée » réservés aux administrateurs');
  ok(sqc.indexOf("'dup', true")>-1&&sqc.indexOf("'dup', true")<sqc.indexOf("interval '1 hour'"),'V99zzzzzzz contributions SQL : un renvoi déjà enregistré est reconnu avant les limites horaires');
  ok(/where not c\.imported order by c\.created_at desc limit 300/.test(sqc),'V99zzzzzzz contributions SQL : la liste ne renvoie que les contributions à traiter');
  ok(/var SUB=new Date\(\)\.toISOString\(\)/.test(pg)&&/p_submitted:SUB/.test(pg)&&!/p_submitted:new Date/.test(pg),'V99zzzzzzz page : instant d’envoi fixé une fois par formulaire (pas de doublon au renvoi)');
  ok(/tfl-contribution/.test(fs.readFileSync('_redirects','utf8'))&&/deposer-tfl/.test(fs.readFileSync('_redirects','utf8'))&&fs.readFileSync('sw.js','utf8').includes("'./tfl-contribution.html'"),'V99zzzzzzz page : liens courts et cache PWA'); }

{ const cv=fs.readFileSync('carte-visite.html','utf8'), sw=fs.readFileSync('sw.js','utf8'), ix=fs.readFileSync('index.html','utf8');
  ok(['recto-fond.jpg','verso-cadre.webp','photo-defaut.jpg','logo-defaut.jpg'].every(f=>fs.existsSync('assets/carte/'+f)&&cv.includes('assets/carte/'+f)&&sw.includes('./assets/carte/'+f)),'V99zzzzzzzzzzzz carte de visite : images du modèle présentes et en cache hors ligne');
  ok(['nom','fonction','tel','email','adresse','site','slogan','vtitre','script','bandeau','qrLeg'].every(k=>cv.includes('id="'+k+'"')),'V99zzzzzzzzzzzz carte de visite : tous les textes sont modifiables');
  ok(/EXBVerif\.docRec/.test(cv)&&/exb-qr\.js/.test(cv)&&/exb-verif\.js/.test(cv)&&/EXBVerif\.publish/.test(cv),'V99zzzzzzzzzzzz carte de visite : QR de vérification du système + enregistrement au registre');
  ok(/exb-carte\.js/.test(ix)&&sw.includes('./carte-visite.html')&&/carte-visite/.test(fs.readFileSync('_redirects','utf8')),'V99zzzzzzzzzzzz carte de visite : bouton dans Affiches, cache et lien court'); }

{ const tf=fs.readFileSync('exb-tfl.js','utf8');
  ok(['sjSel','sjSelTous','sjSelAucun','sjLotPub','sjLotRet','sjPubTout','tflFq','tflFp','tflFc','tflFauto'].every(k=>tf.includes(k)),'V99zzzzzzzzzzzzz sujets TFL : sélection multiple, filtres et boutons de publication en groupe');
  ok(/function sujetsPublierLot/.test(tf)&&/publierLot: sujetsPublierLot/.test(tf)&&/incomplets\.push/.test(tf),'V99zzzzzzzzzzzzz sujets TFL : publication en lot en une écriture, fiches incomplètes écartées');
  ok(/Confirmez qu’elles ont été relues/.test(tf),'V99zzzzzzzzzzzzz sujets TFL : confirmation avant de publier des modèles de la banque');
  ok(fs.existsSync('tools/test-tfl/test-lot.js')&&fs.existsSync('tools/test-tfl/e2e-lot.py'),'V99zzzzzzzzzzzzz sujets TFL : tests de la publication en groupe présents'); }

{ const ix=fs.readFileSync('index.html','utf8'), im=fs.readFileSync('exb-images.js','utf8'), sw=fs.readFileSync('sw.js','utf8');
  const head=ix.slice(0,ix.indexOf('<div class="loginwrap" id="loginScreen">'));
  ok(head.includes('id="exbPosterClean"')&&/transparent!important/.test(head),'V99zzzzzzzzzzzzzzzz affiches : textes modifiables sans cadre de couleur, définis dans l’en-tête de la page');
  ok(['spv_session','spv_fee_title','spv_address','spv_footer'].every(k=>ix.includes('id="'+k+'"'))&&['sp_session','sp_fee_title','sp_address','sp_footer'].every(k=>ix.includes('id="'+k+'"')&&ix.includes('"'+k+'"')),'V99zzzzzzzzzzzzzzzz affiches : les textes qui étaient figés dans l’image sont maintenant modifiables');
  ok(/exb-affiches\.js/.test(ix)&&sw.includes('./exb-affiches.js')&&/exbFitPosters/.test(ix)&&fs.existsSync('exb-affiches.js'),'V99zzzzzzzzzzzzzzzz affiches : ajustement automatique de la taille des textes, en cache hors ligne');
  ok(/POSTER_BG_DEFAULT="data:image\/jpeg;base64,/.test(im)&&/SOFTWARE_POSTER_DEFAULT="data:image\/jpeg;base64,/.test(im)&&!/pc_tagline_company\.textContent="— "/.test(ix),'V99zzzzzzzzzzzzzzzz affiches : fonds sans texte, plus de tirets en double sur le slogan'); }
{ /* V99 : lecteur IFC (.ifczip, géométries), BCF, dégression */
  const ixh=fs.readFileSync('index.html','utf8'),swj=fs.readFileSync('sw.js','utf8'),ifj=fs.readFileSync('exb-ifc3d.js','utf8'),v68=fs.readFileSync('exb-v68.js','utf8'),v94=fs.readFileSync('exb-v94-architecture.js','utf8'),cs=fs.readFileSync('calcul-structure/index.html','utf8');
  ok(/exb-zip\.js[\s\S]*exb-ifc3d\.js[\s\S]*exb-bcf\.js/.test(ixh.slice(ixh.indexOf('exb-zip.js')-5,ixh.indexOf('exb-bcf.js')+30))&&swj.includes("'./exb-zip.js'")&&swj.includes("'./exb-bcf.js'"),'V99 BCF / ZIP : scripts chargés dans le bon ordre et en cache hors ligne');
  ok(/IFCREVOLVEDAREASOLID/.test(ifj)&&/IFCSWEPTDISKSOLID/.test(ifj)&&/IFCEXTRUDEDAREASOLIDTAPERED/.test(ifj)&&/IfcHalfSpace|IFCHALFSPACESOLID/i.test(ifj)&&/ifczip/.test(ifj),'V99 lecteur IFC : révolution, disque balayé, extrusion conique, demi-espace, .ifczip');
  ok(/v68BcfOut/.test(v68)&&/v68BcfIn/.test(v68)&&/data-noguide/.test(v68)&&/importBcf/.test(v94)&&!/n’existe pas/.test(v68+v94),'V99 BCF : boutons export / import dans BIM / Issues, plus d\'avis « n\'existe pas »');
  ok(/b\.deg===0/.test(cs)&&/id="bdg"/.test(cs),'V99 bâtiment : dégression des charges d\'exploitation réglable');
}

title('V99 liaison : interconnexion des modules');
{ const li=fs.readFileSync('exb-liaison.js','utf8');
  ok(/exb-liaison\.js/.test(fs.readFileSync('index.html','utf8'))&&/exb-liaison\.js/.test(fs.readFileSync('sw.js','utf8')),'liaison : script chargé par index.html et mis en cache hors ligne');
  ok(/recordPayment/.test(li)&&/idem/.test(li)&&/client_snapshot/.test(li)&&/status!=='confirmed'/.test(li),'liaison : paiement unique sans doublon, nom d’origine conservé, seuls les paiements confirmés comptent');
  const r=require('child_process').spawnSync(process.execPath,['tools/test-liaison.js'],{encoding:'utf8'});
  ok(r.status===0,'liaison : parcours complets (rattachement, registre financier, paiement, modification, hors connexion)',(r.stdout||'').split('\n').filter(l=>/FAIL/.test(l)).join(' | ')); }
  ok(/exb-liaison-edu\.js/.test(fs.readFileSync('index.html','utf8'))&&/exb-liaison-edu\.js/.test(fs.readFileSync('sw.js','utf8')),'liaison formation/TFL : script chargé et mis en cache hors ligne');
  ok(/exb-liaison-3\.js/.test(fs.readFileSync('index.html','utf8'))&&/exb-liaison-3\.js/.test(fs.readFileSync('sw.js','utf8')),'liaison tranche 3 : script chargé et mis en cache hors ligne');
  ok(/exb-liaison-4\.js/.test(fs.readFileSync('index.html','utf8'))&&/exb-liaison-4\.js/.test(fs.readFileSync('sw.js','utf8')),'liaison tranche 4 : script chargé et mis en cache hors ligne');
  ok(/exb-auto-devis\.js/.test(fs.readFileSync('index.html','utf8'))&&/exb-auto-devis\.js/.test(fs.readFileSync('sw.js','utf8')),'devis automatique : script chargé et mis en cache hors ligne');
  { const r=require('child_process').spawnSync('node',['tools/test-auto-devis.js'],{encoding:'utf8'}); ok(r.status===0,'devis automatique : quantités IFC → lignes de devis (21 contrôles)',(r.stdout||'').split('\n').filter(l=>/ECHEC/.test(l)).join(' | ')); }
  const r2=require('child_process').spawnSync(process.execPath,['tools/test-liaison-edu.js'],{encoding:'utf8'});
  ok(r2.status===0,'liaison formation/TFL : parcours participants, paiements, reçus, certificats, étudiants et encadreurs TFL',(r2.stdout||'').split('\n').filter(l=>/FAIL/.test(l)).join(' | '));
  const r3=require('child_process').spawnSync(process.execPath,['tools/test-liaison-3.js'],{encoding:'utf8'});
  ok(r3.status===0,'liaison tranche 3 : pédagogie, stock, caisse, métrés, résultat par chantier, intégrité des modifications',(r3.stdout||'').split('\n').filter(l=>/FAIL/.test(l)).join(' | '));
  const r4=require('child_process').spawnSync(process.execPath,['tools/test-liaison-4.js'],{encoding:'utf8'});
  ok(r4.status===0,'liaison tranche 4 : chantiers V93, bureau d’études, dossier chantier, fusion des clients en double',(r4.stdout||'').split('\n').filter(l=>/FAIL/.test(l)).join(' | '));
title('Sécurité : en-têtes HTTP');
{ for(const f of ['_headers','site-vitrine/_headers']){ const h=R(f);
    ok(/X-Content-Type-Options:\s*nosniff/.test(h)&&/X-Frame-Options:\s*SAMEORIGIN/.test(h)&&/Referrer-Policy:/.test(h)&&/Strict-Transport-Security:/.test(h),f+' : en-têtes de sécurité présents');
    ok(/Permissions-Policy:[^\n]*camera=\(self\)[^\n]*microphone=\(self\)/.test(h),f+' : caméra et micro gardés pour le logiciel (scan QR, voix)'); }
  ok(/\/sw\.js\s*\n\s*Cache-Control:\s*no-cache/.test(R('_headers')),'sw.js jamais mis en cache (mises à jour fiables)'); }

title('Sécurité : pas d\'installation depuis le navigateur');
{ /* V186d : l'éditeur Word est branché sur les affiches (Studio libre) */
  const ix=R('index.html'),sw=R('sw.js'),aw=R('exb-v186d-affiches-word.js'),st=R('exb-affiches-studio.js'),ed=R('exb-v123-editeur.js');
  title('V186d : éditeur Word dans les affiches');
  ok(/exb-v130-docx\.js[\s\S]*exb-affiches-studio\.js"><\/script><script src="exb-v186d-affiches-word\.js"/.test(ix)&&sw.includes("'./exb-v186d-affiches-word.js'"),'V186d affiches Word : module chargé après le Studio et l’éditeur, en cache hors ligne');
  ok(/function attach\(x, ro, opts\)/.test(ed)&&/opts\.noIdentity/.test(ed)&&/opts\.forceWord/.test(ed)&&/detach: detach/.test(ed),'V186d affiches Word : l’éditeur Word est réutilisable hors des pièces écrites (attach avec options)');
  ok(/w\.EXBAW\.paint\(el, e\)/.test(st)&&/pp_word/.test(st)&&/ad_w/.test(st)&&/ex_docx/.test(st)&&/api: \{ find: find/.test(st),'V186d affiches Word : boutons Éditer avec Word / Texte Word / Word (.docx) et passerelle dans le Studio');
  ok(/EXBPIE_ED\.attach|ED\(\)\.attach/.test(aw)&&/EXBDocx\.build/.test(aw)&&/e\.rt = md/.test(aw)&&/e\.tx = plain/.test(aw),'V186d affiches Word : texte riche (rt) + texte simple (tx), export .docx');
  ok(fs.existsSync('tools/e2e-affiches-word.py'),'V186d affiches Word : test navigateur présent'); }
{ /* V197 : aperçu du nouveau reçu dans l'espace apprenant + photo dans l'export du logiciel */
  const ea=fs.readFileSync('espace-apprenant.html','utf8'),ix=fs.readFileSync('index.html','utf8'),sw=fs.readFileSync('sw.js','utf8');
  title('V197 : reçu apprenant (aperçu) + photo logiciel');
  ok(/async function recuModele/.test(ea)&&/async function apercusRecus/.test(ea)&&/class="rcv"/.test(ea)&&/apercusRecus\(\);/.test(ea),'V197 : espace apprenant : « Mes reçus » affiche le nouveau modèle (aperçu) et le PDF utilise le même objet');
  ok(/o\.photo=\/\^data:image/.test(ix)&&/x\.participant_id===sid/.test(ix)&&/cand\.find\(x=>String\(x\.photo/.test(ix),'V197 : logiciel : la photo de la fiche participant est posée sur le reçu exporté');
  ok(/v197-recu-apercu-photo/.test(sw),'V197 : cache hors connexion renouvelé');
  ok(/pdfBlob/.test(fs.readFileSync('exb-recu-tfl.js','utf8'))&&/EXBRecuTFL\.pdfBlob/.test(ea)&&/EXBRecuTFL\.pdfBlob/.test(ix),'V197 : vrai PDF direct (apprenant et logiciel), plus de fichier .html');
  ok(/receipts\[receipts\.length-1\]/.test(ix)&&!/const last=receipts\[0\]/.test(ix),'V197 : logiciel : le reçu qui vient d\'être créé (et non le plus ancien) reçoit le lien participant');
  ok(/exbApercuRecu/.test(ix)&&/recuModeleApercu/.test(ix)&&/repairReceiptLinks/.test(ix),'V197 : logiciel : aperçu à l\'écran au nouveau modèle + réparation des liens écrasés');
  ok(fs.existsSync('tools/e2e-recu-photo-apercu.py'),'V197 : test navigateur présent'); }
{ /* V198 : signature + cachet des pièces écrites : une seule fois, en bas de la 1re page */
  const pi=fs.readFileSync('exb-v81-pieces.js','utf8'), sw2=fs.readFileSync('sw.js','utf8');
  title('V198 : signature + cachet une seule fois, en bas de la 1re page');
  ok(/\.wrap>tfoot \.sgw\{position:absolute;left:0;right:0;bottom:27mm/.test(pi),'V198 : impression : le visa est posé en absolu (une seule fois, page 1), plus dans le pied fixe répété');
  ok(/<div class="ftw">'\+foot\+'<\/div><\/td>/.test(pi)&&!/<div class="ftw">'\+\(sig\?/.test(pi),'V198 : le visa est sorti du pied de page fixe');
  ok(/\.pg\{min-height:0\}/.test(pi),'V198 : plus de page 2 quasi vide sur un document court');
  ok(/n===0&&cs/.test(pi)&&!/last&&cs/.test(pi),'V198 : PDF direct : signature sur la 1re page seulement');
  ok(/v198-resizeobserver-signature-premiere-page/.test(sw2),'V198 : cache hors connexion renouvelé');
  ok(fs.existsSync('tools/e2e-signature-premiere-page.py'),'V198 : test navigateur présent'); }
{ /* V199 : accueil + connexion client (lot « V190-portail-client » fusionné) */
  const ix=fs.readFileSync('index.html','utf8'), sw3=fs.readFileSync('sw.js','utf8'), br=fs.readFileSync('exb-brand.js','utf8'), rd=fs.readFileSync('_redirects','utf8');
  title('V199 : accueil + connexion client, identifiants stables, identité contacts');
  ok(fs.existsSync('accueil-client.html')&&fs.existsSync('portail-img/hero-batiment.jpg')&&fs.existsSync('portail-img/connexion-equipe.jpg'),'V199 : page d\'accueil client et ses images présentes');
  ok(/\/accueil\s+\/accueil-client\.html/.test(rd),'V199 : adresse /accueil redirigée');
  ok(/exb-core-ids\.js/.test(ix)&&/exb-core-ids\.js/.test(sw3)&&fs.existsSync('exb-core-ids.js'),'V199 : module d\'identifiants stables chargé et mis en cache');
  ok(/contactChanged/.test(br)&&/!\/excellencia\/i\.test\(String\(B\.name/.test(br),'V199 : identité contacts (V190) + correctif fond V196 conservés');
  ok(/portail-img\/connexion-equipe\.jpg/.test(fs.readFileSync('espace-client.html','utf8')),'V199 : espace-client.html au nouveau design');
  ok(/^const V='v2\d\d[a-z]?-/.test(sw3)&&/v199-/.test(sw3),'V199 : cache hors connexion renouvelé');
  ok(fs.existsSync('tools/e2e-accueil-client.py'),'V199 : test navigateur présent'); }

{ /* V200 : demande de projet sur le portail client (formulaires séparés) + compte client créé automatiquement */
  title('V200 : demande sur le portail client, compte automatique');
  const sw3=fs.readFileSync('sw.js','utf8');
  const dm=fs.existsSync('demande.html')?fs.readFileSync('demande.html','utf8'):'',dj=fs.existsSync('exb-demande.js')?fs.readFileSync('exb-demande.js','utf8'):'',ac=fs.readFileSync('accueil-client.html','utf8'),sq=fs.existsSync('supabase/migration-v200-demande-client-compte-auto.sql')?fs.readFileSync('supabase/migration-v200-demande-client-compte-auto.sql','utf8'):'';
  ok(/exb-demande\.js/.test(dm)&&/id="tiles"/.test(dm),'V200 : page de demande (choix du type + formulaire)');
  ok(['construction','architecture','metre','renovation','autre'].every(k=>new RegExp('\\b'+k+':\\{label').test(dj)),'V200 : 5 formulaires séparés');
  ok(['type=construction','type=architecture','type=metre','type=renovation'].every(k=>ac.indexOf('demande.html?'+k)>=0)&&!/btp\.html\?type=projet/.test(ac),'V200 : tuiles de l\'accueil → formulaires séparés');
  const m=dj.slice(dj.indexOf('metre:{'),dj.indexOf('renovation:{')),r=dj.slice(dj.indexOf('renovation:{'),dj.indexOf('autre:{'));
  ok(!/terrain\(|length_m|environment/.test(m)&&!/terrain\(|length_m|environment/.test(r),'V200 : métré et rénovation sans dimensions de parcelle');
  ok(/client_demande_envoyer/.test(dj)&&/create or replace function public\.client_demande_envoyer/.test(sq)&&/create or replace function public\.client_dossier/.test(sq),'V200 : fonctions SQL client_demande_envoyer / client_dossier');
  ok(/crypt\(left\(p_mdp, 200\)/.test(sq)&&!/raise notice[^;]*p_mdp/.test(sq),'V200 : mot de passe haché, jamais journalisé');
  ok(/demande\.html/.test(sw3)&&/exb-demande\.js/.test(sw3)&&/^const V='v2\d\d[a-z]?-/.test(sw3),'V200 : mis en cache hors connexion, cache renouvelé');
  ok(fs.existsSync('tools/e2e-demande.py'),'V200 : test navigateur présent'); }
{ /* V200e : liens à envoyer aux clients + demandes en ligne aussi dans le module Clients */
  const lp=R('exb-liens-profils.js'),ix=R('index.html');
  title('V200e : liens clients + passation vers le module Clients');
  ok(/clients: \{ titre: '🔗 Liens à envoyer aux clients'/.test(lp)&&['demande.html?type=construction','demande.html?type=architecture','demande.html?type=metre','demande.html?type=renovation','espace-client.html'].every(k=>lp.indexOf(k)>=0),'V200e : encadré « Liens à envoyer aux clients » (4 types + espace client)');
  ok(/"projet": "demande\.html"/.test(ix)&&!/"projet": "btp\.html"/.test(ix),'V200e : « Copier le lien du formulaire » BTP = portail client');
  ok(/hc\.querySelector\(':scope > \.exbInbox\[data-t="btp"\]'\)/.test(ix),'V200e : demandes en ligne BTP aussi affichées dans le module Clients');
  ok(/Espace client '\+r\.m/.test(ix),'V200e : import : matricule de l’espace client noté dans la fiche'); }
{ /* V200f : le client arrive sur le nouveau tableau de bord dès sa demande, sans code de suivi */
  const pt=R('portail.html'),dj=R('exb-demande.js'),dh=R('demande.html'),sw3=R('sw.js');
  title('V200f : tableau de bord client dès la demande, sans code de suivi');
  ok(/dossier:true/.test(pt)&&/D=\{ok:true,kind:'client',dossier:true/.test(pt)&&/render\(\);return true\}/.test(pt)&&!/class=\\?"dos\\?"/.test(pt.split('function sigOf')[0].split('async function loadDossier')[1]||''),'V200f : « Mon dossier » remplacé par le tableau de bord');
  ok(/function demandesCard\(\)/.test(pt)&&/data-a="newd"/.test(pt)&&/if\(D\.dossier\)\{var E0=/.test(pt),'V200f : demandes dans « Mon projet », messagerie = contacts avant lancement');
  ok(!/uméro de suivi|code de suivi à saisir[^']*uméro/.test(dj)&&!/uméro client/.test(dj+dh)&&/Identifiant de votre espace/.test(dj),'V200f : plus de « numéro de suivi » : identifiant du compte');
  ok(/^const V='v2\d\d[a-z]?-/.test(sw3),'V200f : cache hors connexion renouvelé'); }


{ /* V201 : fiche de demande client au style des pièces écrites */
  const pd=R('exb-pdf.js'),dj=R('exb-demande.js'),bj=R('exb-btp.js'),dh=R('demande.html'),sw4=R('sw.js');
  title('V201 : fiche de demande client au style des pièces écrites');
  ok(/style==='piece'/.test(pd)&&/function drawPiece/.test(pd)&&/Vérifier ce document/.test(pd)&&/Helvetica-Oblique/.test(pd),'V201 : moteur PDF — style « pièce écrite » (en-tête, encadré, QR, Directeur Général)');
  ok(/style:'piece'/.test(dj)&&/sign:true/.test(dj)&&/style:'piece'/.test(bj),'V201 : fiches de demande (portail client + BTP) au style des pièces, visa activé');
  ok(['exb-identite.js','exb-sign.js','exb-qr.js','exb-verif.js'].every(k=>dh.indexOf(k)>=0)&&dh.indexOf('exb-sign.js')<dh.indexOf('exb-pdf.js'),'V201 : demande.html charge identité, visa, QR et vérification avant le PDF');
  ok(/^const V='v2\d\d[a-z]?-/.test(sw4),'V201 : cache hors connexion renouvelé'); }
{ /* V202 : divisions sans écran de Direction & pilotage ; Parcours TFL à part */
  title('V202 : divisions et espace TFL');
  const sh=R('exb-v99r-shell.js'),swv=R('sw.js');
  ok(!/exbV69Btn:'dv_con'|exbV74Btn:'dv_con'|exbPieBtn:'dv_con'|exbPerBtn:'dv_con'|inscBatch:'dv_for'|qcm:'dv_for'/.test(sh),'V202 : plus d\'écran de Direction & pilotage reclassé vers Ingénierie / Formation');
  ok(/function openEspace/.test(sh)&&/function goTfl/.test(sh)&&/TFL_VUES/.test(sh)&&/Parcours TFL/.test(sh),'V202 : Parcours TFL — page dédiée, entrée de menu, accès direct à chaque vue');
  ok(/t:'Ingénierie et architecture'/.test(sh)&&!/t:'Ingénierie et construction'/.test(sh),'V202 : la division s\'appelle « Ingénierie et architecture »');
  ok(/^const V='v2\d\d[a-z]?-/.test(swv),'V202 : cache hors connexion renouvelé'); }
{ ok(!/<link[^>]+rel=["']manifest["']/i.test(R('index.html')),'index.html : aucun manifeste lié (pas de bouton « Installer » du navigateur)'); }
title('V210f : suspension / réactivation des membres + blocage immédiat');
{ const sq=R('supabase/migration-v210f-suspension-membres.sql'), eq=R('exb-equipe.js'), am=R('exb-acces-membre.js'), db=R('exb-db.js'), ix=R('index.html'), swt=R('sw.js');
  ['equipe_suspendre','equipe_reactiver','equipe_retirer','equipe_liste','mon_statut','membres_suspendus','membres_bloquer_suspendus'].forEach(f=>ok(sq.includes(f),'V210f SQL : '+f));
  ok(/before insert on membres/.test(sq),'V210f SQL : un membre suspendu ne peut pas se ré-inscrire seul');
  ok(/revoque_le=null/.test(sq),'V210f SQL : la réactivation rend son code personnel');
  ok(/data-sp=/.test(eq)&&/data-rv=/.test(eq)&&/equipe_suspendre/.test(eq)&&/equipe_reactiver/.test(eq),'V210f : boutons Suspendre / Réactiver dans le panneau Équipe');
  ok(/mon_statut/.test(am)&&/EXBDB/.test(am)&&/suspendu/.test(am)&&/retire/.test(am),'V210f : le logiciel du membre contrôle son statut');
  ok(/if\(meta\.blk\)return true/.test(db)&&/bloquer:function/.test(db)&&/detacher:function/.test(db),'V210f : exb-db.js arrête la synchronisation quand l\'accès est bloqué');
  ok(ix.includes('exb-acces-membre.js'),'V210f : exb-acces-membre.js chargé par index.html');
  ok(swt.includes("'./exb-acces-membre.js'")&&/^const V='v2[12]\d[a-z]?-/.test(swt)&&swt.includes('v210f-'),'V210f : cache hors connexion renouvelé (v210f)'); }
console.log('\nRésultat : '+passes+' contrôles réussis, '+fails+' échec(s).');process.exit(fails?1:0)}

ok(/EXB_PAYMENTS/.test(fs.readFileSync('exb-v93-payments.js','utf8')),'V93 moteur de paiements présent');
ok(/EXB_BTP/.test(fs.readFileSync('exb-v93-btp.js','utf8')),'V93 BTP présent');
ok(sw.includes("'./exb-v93-payments.js'")&&sw.includes("'./exb-v93-btp.js'"),'V93 modules dans le cache PWA');
const v93sql=fs.readFileSync('supabase/migration-v93-btp-payments.sql','utf8');
ok(/create table if not exists paiements/.test(v93sql)&&/moyens_paiement/.test(v93sql),'V93 moyens de paiement SQL présents');
ok(/btp_projets/.test(v93sql)&&/btp_chantiers/.test(v93sql)&&/btp_qhse_incidents/.test(v93sql),'V93 tables BTP présentes');
ok(/Mobile Money/.test(fs.readFileSync('exb-v93-payments.js','utf8'))&&/bank_transfer/.test(fs.readFileSync('exb-v93-payments.js','utf8')),'V93 moyens Mobile Money et virement présents');
{ const sq=fs.readFileSync('supabase/migration-v99zzzzzzzzzzzzzzz-espace-client.sql','utf8'), ec=fs.readFileSync('espace-client.html','utf8'), pt=fs.readFileSync('portail.html','utf8');
  console.log('\n# Espace client (comptes matricule)');
  ok(/crypt\(/.test(sq)&&/doit_changer/.test(sq)&&/restreint/.test(sq),'espace client : mot de passe haché, changement obligatoire à la première connexion');
  ok(/client_connexion/.test(ec)&&/client_changer_mdp/.test(ec)&&/portail\.html/.test(ec),'espace client : page de connexion branchée sur le serveur');
  ok(/calCard/.test(pt)&&/actCard/.test(pt)&&/client_deconnexion/.test(pt),'portail : calendrier, activité et déconnexion du compte client'); }
{ const sq=fs.readFileSync('supabase/migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql','utf8'), pt=fs.readFileSync('portail.html','utf8'), pj=fs.readFileSync('exb-v99zy-portails.js','utf8');
  ok(/client_plan_publier/.test(sq)&&/client_plan_lire/.test(sq)&&/vu_le/.test(sq)&&/Plan modifié/.test(sq),'plans client : version, message au client et suivi « vu le »');
  ok(/plansCard/.test(pt)&&/planBanner/.test(pt)&&/pPlan/.test(pj),'plans client : bandeau, rubrique Plans et envoi depuis l’application'); }
{ const cs=fs.readFileSync('calcul-structure/index.html','utf8'), pl=fs.readFileSync('exb-v81-plans.js','utf8');
  ok(/exbInject/.test(cs)&&/EXB-REF=/.test(cs)&&/readTag/.test(pl)&&/fileSel/.test(pl),'références automatiques : export marqué, ajout dans Plans prérempli'); }
{ const cl=fs.readFileSync('client.html','utf8'), vi=fs.readFileSync('site-vitrine/index.html','utf8');
  ok(/id="espBox"/.test(cl)&&/espace-client\.html/.test(cl)&&(vi.match(/data-app="espace-client\.html"/g)||[]).length>=2,'espace client : lien à la confirmation de la demande et sur le site vitrine'); }
{ const id=fs.readFileSync('exb-identite.js','utf8'), ix=fs.readFileSync('index.html','utf8'), dc=fs.readFileSync('exb-docs.js','utf8'), pd=fs.readFileSync('exb-pdf.js','utf8');
  ok(/exbIdDg/.test(id)&&/applyDg/.test(id)&&(ix.match(/class="exb-dg"/g)||[]).length===2&&/g\.dg/.test(dc)&&/ID\.dg/.test(pd),'nom du Directeur Général : une saisie dans l’identité, reprise par reçus, certificats, devis et PDF'); }
{ const g=n=>fs.readFileSync(n,'utf8'); ok(/ID\(\)\.dg/.test(g('exb-metre.js'))&&/EXBId&&EXBId\.get\(\)\.dg/.test(g('exb-form.js'))&&/ident\(\)\.dg/.test(g('exb-v99zy-portails.js'))&&/societe_rep/.test(g('exb-v81-pieces.js'))&&/direct\/i/.test(g('exb-pdf.js')),'nom du Directeur Général : tous les modules (métré, fiches, portail, pièces de marché, PDF)'); }
{ const fx=fs.readFileSync('exb-form-ux.js','utf8'); const pages=['client','inscription','btp','formateur','personnel','logiciel','demande-tp-td','tfl-formulaire','tfl-encadreur-formulaire'];
  ok(/judge/.test(fx)&&pages.every(p=>fs.readFileSync(p+'.html','utf8').includes('exb-form-ux.js'))&&fs.readFileSync('sw.js','utf8').includes("'./exb-form-ux.js'"),'formulaires : photo et signature sous le nom, nom validé en direct (9 pages)'); }
{ ok(fs.readFileSync('apprenant.html','utf8').includes('exb-sign.js')&&fs.readFileSync('resultats.html','utf8').includes('exb-sign.js'),'signature + cachet : aussi sur le récapitulatif apprenant et les résultats BTP'); }

{ /* V186e : raccourcis clavier et édition directe dans le Studio libre */
  const st=R('exb-affiches-studio.js');
  title('V186e : raccourcis clavier du Studio libre');
  ok(/function redo\(\)/.test(st)&&/fut = \[\]/.test(st)&&/Ctrl\+Y|k === 'y'/.test(st),'V186e Studio : annuler (Ctrl+Z) et rétablir (Ctrl+Y / Ctrl+Maj+Z)');
  ok(/mod && k === 's'/.test(st)&&/saveCur\(\)/.test(st),'V186e Studio : Ctrl+S enregistre l’affiche');
  ok(/addEventListener\('copy'/.test(st)&&/addEventListener\('cut'/.test(st)&&/addEventListener\('paste'/.test(st)&&/k === 'd'/.test(st),'V186e Studio : copier, couper, coller, dupliquer');
  ok(/addEventListener\('dblclick'/.test(st)&&/getElementById\('exbawModal'\)\) return/.test(st),'V186e Studio : double-clic = éditeur Word, et le clavier du Studio ne touche pas à l’éditeur Word ouvert');
  ok(fs.existsSync('tools/e2e-affiches-clavier.py'),'V186e Studio : test navigateur présent'); }
{ /* V186f : sélection multiple dans le Studio libre */
  const st=R('exb-affiches-studio.js');
  title('V186f : sélection multiple du Studio libre');
  ok(/function selIds\(\)/.test(st)&&/function multiProps\(/.test(st)&&/mode: 'marquee'/.test(st),'V186f Studio : sélection multiple (Maj+clic, cadre) et panneau de groupe');
  ok(/data-m=\"DH\"/.test(st)&&/data-m=\"DV\"/.test(st)&&/data-m=\"L\"/.test(st),'V186f Studio : aligner et répartir les éléments sélectionnés');
  ok(/mod && k === 'a'/.test(st)&&/items: group/.test(st),'V186f Studio : Ctrl+A et déplacement de groupe');
  ok(fs.existsSync('tools/e2e-affiches-multi.py'),'V186f Studio : test navigateur présent'); }
{ /* V186g : éditeur Word et raccourcis sur les affiches Excellencia (onglet 1) */
  const ix=R('index.html'),sw=R('sw.js'),m=R('exb-v186g-affiches-excellencia.js'),aw=R('exb-v186d-affiches-word.js');
  title('V186g : affiches Excellencia (éditeur Word + clavier)');
  ok(/exb-v186d-affiches-word\.js"><\/script><script src="exb-v186g-affiches-excellencia\.js"/.test(ix)&&sw.includes("'./exb-v186g-affiches-excellencia.js'"),'V186g : module chargé après l’éditeur Word des affiches, en cache hors ligne');
  ok(/function editText\(e, opt\)/.test(aw)&&/opt\.api/.test(aw),'V186g : l’éditeur Word des affiches accepte une passerelle personnalisée');
  ok(/MAP = \{/.test(m)&&/p_hero_white/.test(m)&&/sp_title/.test(m)&&/exb_poster_rt/.test(m),'V186g : champs des deux affiches Excellencia branchés, texte mis en forme enregistré');
  ok(/mod && k === 's'/.test(m)&&/function undo\(\)/.test(m)&&/addEventListener\('dblclick'/.test(m),'V186g : Ctrl+S, Ctrl+Z / Ctrl+Y et double-clic sur l’aperçu');
  ok(fs.existsSync('tools/e2e-affiches-excellencia.py'),'V186g : test navigateur présent'); }
{ /* V186h : pièces écrites sans chantier + impression Windows par copie propre */
  const pi=R('exb-v81-pieces.js'),pre=fs.readFileSync(path.join(root,'..','electron','preload.js'),'utf8'),ma=fs.readFileSync(path.join(root,'..','electron','main.js'),'utf8');
  title('V186h : pièces sans chantier, impression Windows');
  ok(/function projOpts\(/.test(pi)&&/Sans chantier \(courriers libres\)/.test(pi)&&/st\.pid==null/.test(pi),'V186h : sélecteur « Sans chantier » dans les pièces écrites');
  ok(/id="pPj"/.test(pi)&&/x\.project=pj\.value/.test(pi),'V186h : chantier modifiable / retirable dans chaque pièce');
  ok(!/\+' — '\+C\.pn\(st\.pid\)/.test(pi)&&/function sfx\(\)/.test(pi),'V186h : titres sans nom de chantier quand il n’y en a pas');
  ok(/exb:print-native/.test(ma)&&/printNative/.test(pre)&&/window\.exbPrintNative\(\)/.test(pre),'V186h : « Imprimer (boîte Windows) » passe par la copie du document, plus par l’écran de l’application');
  ok(fs.existsSync('tools/e2e-pieces-sans-chantier.py'),'V186h : test navigateur présent'); }
{ /* V186i : BI — « Imprimer » = document du rapport, direct à l'imprimante Windows */
  const bi=R('exb-bi.js'),pr=R('exb-print.js'),rm=R('exb-rapport-marque.js');
  title('V186i : BI Imprimer = rapport, pas l’écran');
  ok(/rapport\(\{ imprimer: true \}\)/.test(bi)&&/imprimer: IMP/.test(bi)&&!/EXBRapport\.screen\('Tableau de bord BI Direction', \{ prefix: 'BI' \}\); else w\.print\(\); \} catch \(e\) \{ try \{ w\.print/.test(bi),'V186i : le bouton Imprimer de la BI imprime le document du rapport');
  ok(/wantsPrint\(o\) && typeof w\.exbDesktop\.printNative/.test(pr)&&/print: !!\(o && o\.imprimer\)/.test(rm),'V186i : option « imprimer » → imprimante Windows (repli PDF)');
  ok(fs.existsSync('tools/e2e-bi-imprimer.py'),'V186i : test navigateur présent'); }
{ /* V186i : « Imprimer » direct à l'imprimante Windows pour tout le logiciel */
  const pr=R('exb-print.js'),me=R('exb-metre.js');
  title('V186i : Imprimer = imprimante Windows (tout le logiciel)');
  ok(/function wantsPrint\(o\)/.test(pr)&&/imprimer\|/.test(pr)&&/pdf\|enregistr/.test(pr)&&/wantsPrint\(o\) && typeof w\.exbDesktop\.printNative/.test(pr),'V186i : un bouton « Imprimer » envoie à l’imprimante, un bouton « PDF » enregistre un PDF');
  ok((me.match(/__exbPrintMode='native'/g)||[]).length===2,'V186i : Métré et Devis rapide : impression directe sous Windows');
  ok(fs.existsSync('tools/e2e-imprimer-partout.py'),'V186i : test navigateur « imprimer partout » présent'); }
{ /* V192b : rattachement des pièces écrites choisi dès la création, choix mémorisé */
  const pi=R('exb-v81-pieces.js');
  title('V192b : pièces écrites — rattachement dès la création');
  ok(/function attSel\(/.test(pi)&&/function setPid\(/.test(pi)&&/EXBPIE\.att/.test(pi)&&/att:function\(v\)/.test(pi),'V192b Pièces : menu « Rattachée à » sur les écrans de création (type, modèle)');
  ok(/exb_pie_none/.test(pi),'V192b Pièces : dernier choix « Sans chantier » mémorisé');
  ok(/np=!p\.project&&keep/.test(pi),'V192b Pièces : données de chantier à compléter (____) pour une pièce sans chantier');
  ok(fs.existsSync('tools/e2e-pieces-rattachement.py'),'V192b Pièces : test navigateur présent'); }
{ /* V194 : reçu d'inscription / de formation au modèle + nom du guichetier */
  const rt=R('exb-recu-tfl.js'),ea=R('espace-apprenant.html'),ix=R('index.html'),tj=R('exb-tfl.js'),pg=R('tfl-portail.html'),sq=R('supabase/migration-v194-guichetier.sql');
  title('V194 : reçu apprenant au modèle + guichetier');
  ok(/depuisApprenant/.test(rt)&&/o\.bas/.test(rt)&&/o\.lignes/.test(rt)&&/class="gn"/.test(rt),'V194 : gabarit : lignes adaptables (formation), nom du guichetier dans la case de signature');
  ok(/EXBRecuTFL/.test(ea)&&/exb-recu-tfl\.js/.test(ea)&&/exb-print\.js/.test(ea)&&/depuisApprenant/.test(ea)&&/landscape:true/.test(ea),'V194 : espace apprenant : « Télécharger PDF » = nouveau modèle (anciens PDF en secours)');
  ok(/depuisApprenant/.test(ix)&&/id="guichetier"/.test(ix)&&/guichetier:x\.guichetier/.test(ix),'V194 : logiciel : champ Guichetier, export au même modèle, synchronisation vers l\'espace apprenant');
  ok(/p_guichetier/.test(tj)&&/id="tflGu"/.test(tj)&&/guichetierNomme/.test(tj)&&/p\.guichetier/.test(tj)&&/p\.guichetier/.test(pg),'V194 : TFL : nom du guichetier saisi, envoyé au serveur, imprimé sur le reçu (administration et étudiant)');
  ok(/add column if not exists guichetier text/.test(sq)&&/guichetier_email/.test(sq)&&/drop function if exists public\.tfl_paiement_admin_decider/.test(sq)&&/p_guichetier/.test(sq)&&sq.split('$$').length%2===1,'V194 : SQL : colonnes, anciennes signatures retirées, $$ équilibrés');
  ok(fs.existsSync('tools/e2e-recu-apprenant-modele.py'),'V194 : test navigateur du reçu apprenant présent'); }
{ /* V193 : reçu TFL au format modèle (carte paysage) */
  const rt=R('exb-recu-tfl.js'),pg=R('tfl-portail.html'),tj=R('exb-tfl.js'),ix=R('index.html'),sw3=R('sw.js');
  title('V193 : reçu TFL au format modèle');
  ok(/REÇU DE PAIEMENT DES FRAIS/.test(rt)&&/GUICHET D’APUREMENT DES FRAIS/.test(rt)&&/size:A4 landscape/.test(rt)&&/class="cd"/.test(rt),'V193 : gabarit « reçu de paiement des frais » (paysage, QR + code, signatures)');
  ok(/EXBRecuTFL/.test(pg)&&/exb-recu-tfl\.js/.test(pg)&&/R\.html\(o\),\{landscape:true\}/.test(pg),'V193 : espace étudiant : bouton « Reçu » = nouveau modèle');
  ok(/recuDonnees\(p, d\)/.test(tj)&&/R\.html\(o\), \{ landscape: true \}/.test(tj)&&/exb-recu-tfl\.js/.test(ix),'V193 : écran administrateur : même modèle');
  ok(/exb-recu-tfl\.js/.test(sw3),'V193 : service worker : gabarit mis en cache hors connexion');
  ok(fs.existsSync('tools/e2e-recu-tfl-modele.py'),'V193 : test navigateur du reçu présent'); }
{ /* V205 : onglets Affiches propres + Gestion & finances sans Personnel/Portails */
  title('V205 : onglets Affiches, Gestion & finances');
  const sh5=R('exb-v99r-shell.js'), st5=R('exb-affiches-studio.js'), ct5=R('exb-carte-travail.js');
  ok(!/rh:'dv_ges'/.test(sh5)&&!/portails:'dv_ges'/.test(sh5),'V205 : Personnel & RH et Portails & signatures ne sont plus classés dans Gestion & finances');
  ok(/exbs-alt>\.softwarePosterCard/.test(st5)&&/classList\.add\('exbs-alt'\)/.test(st5)&&/classList\.remove\('exbs-alt'\)/.test(st5),'V205 : l\'affiche logiciels est masquée hors de l\'onglet « Affiches Excellencia »');
  const sh6=R('exb-v99r-shell.js'), rd6=R('_redirects'), ht6=R('comptable.html');
  ok(/ESPACES=\{comptable:/.test(sh6)&&/function espaceFilter/.test(sh6)&&/function espaceHome/.test(sh6),'V205 lot 2 : l\'Espace Comptable existe (menu filtré + tableau de bord)');
  ok(/fonctions:\['comptable','direction'\]/.test(sh6)&&!/keys:\[[^\]]*exbPayBtn/.test(sh6.slice(sh6.indexOf('ESPACES={comptable:'),sh6.indexOf(' ingenieur:{'))),'V205 lot 2 : réservé comptable / direction / administrateur ; sans Paie & RH');
  ok(/^\/comptable\s+\/comptable\.html/m.test(rd6)&&/exb_espace/.test(ht6)&&/\.\/comptable\.html/.test(R('sw.js')),'V205 lot 2 : lien /comptable (redirection, page, cache hors connexion)');
  ok(/ingenieur:\{/.test(sh6)&&/fonctions:\['bureau_etudes','chef_projet','conducteur','direction'\]/.test(sh6)&&/function ingHome/.test(sh6),'V205 lot 3 : l\'Espace Ingénieur existe (menu techniques, sans finance/stock/RH)');
  ok(/^\/ingenieur\s+\/ingenieur\.html/m.test(rd6)&&/exb_espace/.test(R('ingenieur.html'))&&/\.\/ingenieur\.html/.test(R('sw.js')),'V205 lot 3 : lien /ingenieur (redirection, page, cache hors connexion)');
  ok(/architecte:\{/.test(sh6)&&/fonctions:\['architecte','chef_projet','bureau_etudes','direction'\]/.test(sh6)&&/dash:'arc'/.test(sh6)&&!/keys:\[[^\]]*'(finances|stock|rh)'/.test(sh6.slice(sh6.indexOf('architecte:{'),sh6.indexOf('formation:{t:'))),'V205 lot 4 : l\'Espace Architecture existe (plans, BIM, projets ; sans finance, stock, RH, calcul de structure)');
  ok(/^\/architecte\s+\/architecte\.html/m.test(rd6)&&/exb_espace/.test(R('architecte.html'))&&/\.\/architecte\.html/.test(R('sw.js')),'V205 lot 4 : lien /architecte (redirection, page, cache hors connexion)');
  { const m5=R('supabase/migration-v205-lot5-formateur.sql'), eq5=R('exb-equipe.js');
    ok(/'formateur'/.test(m5)&&/'architecte'/.test(m5)&&/equipe_inviter/.test(m5)&&/on conflict \(fonction, collection\) do nothing/.test(m5)&&!/'(caisse|factures|personnel)'/.test(m5.split('insert into droits_fonction')[1].split('on conflict')[0]),'V205 lot 5 : migration additive (fonction formateur, droits minimaux sans finance/personnel, architecte conservé)');
    ok(/\['formateur','Formateur'\]/.test(eq5)&&/espace-formateur\.html/.test(eq5)&&/formateur:'Formateur'/.test(R('exb-db.js'))&&/\['formateur', 'Formateur'\]/.test(R('exb-droits-actions.js')),'V205 lot 5 : « formateur » proposé dans Équipe (lien vers l\'espace formateur existant)');
    ok(/^\/espace-formation\s+\/espace-formation\.html/m.test(R('_redirects'))&&/^\/espace-formateur\s+\/espace-formateur\.html/m.test(R('_redirects'))&&!/^\/formateur\s/m.test(R('_redirects')),'V205 lot 5 : /espace-formation = Espace Formation ; /espace-formateur (matricule) conservé ; le formulaire public /formateur n\'est pas détourné');
    { const sh=R('exb-v99r-shell.js'), fb=sh.slice(sh.indexOf('formation:{t:')); 
      ok(/formation:\{t:'Espace Formation'/.test(sh)&&/cats:\['for'\]/.test(fb.slice(0,400))&&/hors:\['receipts'\]/.test(fb.slice(0,400))&&/fonctions:\['formateur','direction'\]/.test(fb.slice(0,400)),'V205 lot 5b : Espace Formation = toute la catégorie Formation SAUF les reçus de paiement');
      ok(/keys:\[[^\]]*'receipts'/.test(sh.slice(sh.indexOf('ESPACES={comptable:'),sh.indexOf('ingenieur:{'))),'V205 lot 5b : les reçus de paiement restent dans l\'Espace Comptable');
      ok(/espaceRefuse\(String\(x\)\)/.test(sh)&&/espaceRefuse\('receipts'\)/.test(R('index.html')),'V205 lot 5b : ouverture d\'un reçu refusée dans l\'Espace Formation (menu, recherche, bouton apprenant)');
      { const sh2=R('exb-v99r-shell.js'), cz=sh2.slice(sh2.indexOf('chantier:{t:'),sh2.indexOf('direction:{t:')), dz=sh2.slice(sh2.indexOf('direction:{t:'),sh2.indexOf('administration:{t:')), az=sh2.slice(sh2.indexOf('administration:{t:'),sh2.indexOf('function espaceKey'));
        ok(/cats:\['prj'\]/.test(cz)&&/fonctions:\['conducteur','chef_projet','direction'\]/.test(cz)&&!/'rh'|exbPayBtn|'finances'/.test(cz),'V205 lot 6 : Espace Chantier seul (catégorie Projets & Chantiers ; sans RH, paie ni finances)');
        ok(/fonctions:\['direction'\]/.test(dz)&&/cats:\['crm'\]/.test(dz)&&/'exbbi'/.test(dz)&&/'bcrmp'|cats:\['crm'\]/.test(dz),'V205 lot 6 : Espace Direction = Direction + Commercial (CRM, clients, portails, devis)');
        ok(/fonctions:\['rh','direction'\]/.test(az)&&/'rh'/.test(az)&&/exbPayBtn/.test(az)&&/reserve:\{fonctions:\['direction'\]/.test(az)&&/'exbAuBtn'/.test(az.slice(az.indexOf('reserve:'))),'V205 lot 6 : Espace Administration = Administration + RH ; sécurité/sauvegardes/paramètres réservés administrateur et direction');
        ok(['chantier','direction','administration','magasin'].every(n=>/exb_espace/.test(R(n+'.html'))&&new RegExp('^/'+n+'\\s+/'+n+'\\.html','m').test(R('_redirects'))&&R('sw.js').includes('./'+n+'.html')),'V205 lot 6 : liens /chantier /direction /administration (pages, redirections, cache)'); }
      { const sh3=R('exb-v99r-shell.js'), mz=sh3.slice(sh3.indexOf('magasin:{t:'),sh3.indexOf('function espaceKey'));
        ok(/fonctions:\['magasinier','direction'\]/.test(mz)&&/cats:\['ach'\]/.test(mz)&&!/'rh'|exbPayBtn|'finances'|'projets'/.test(mz)&&/magasin\.html/.test(R('exb-equipe.js')),'V205 lot 7 : Espace Magasin (stock, inventaires, achats ; sans finance, RH, projets) et lien d\'invitation'); }
      { const mj=R('supabase/migration-v205-lot5b-paiements-comptable.sql'), jd=R('exb-v205-paiements-declares.js');
        ok(/est_comptable_direction/.test(mj)&&/'comptable','direction'/.test(mj)&&/paiements_lire/.test(mj)&&/paiements_modifier/.test(mj)&&!/'formateur'/.test(mj.split('create or replace function')[1]||''),'V205 lot 5b : migration — le comptable/direction lit et vérifie les paiements déclarés (pas le formateur), e-mails d\'origine conservés');
        ok(/paiements_declares\?type=eq\.apprenant/.test(jd)&&/prepareReceiptFromParticipant/.test(jd)&&/exb-v205-paiements-declares\.js/.test(R('index.html'))&&/\.\/exb-v205-paiements-declares\.js/.test(R('sw.js')),'V205 lot 5b : paiements déclarés visibles dans Reçus de paiement (confirmer → reçu, rejeter), module chargé et en cache'); }
      ok(/exb_espace/.test(R('espace-formation.html'))&&/\.\/espace-formation\.html/.test(R('sw.js')),'V205 lot 5b : page /espace-formation et cache hors connexion'); } }
  { const m4=R('supabase/migration-v205-lot4-architecture.sql');
    ok(/membres_fonction_chk/.test(m4)&&/'architecte'/.test(m4)&&/equipe_inviter/.test(m4)&&/equipe_modifier/.test(m4)&&/on conflict \(fonction, collection\) do nothing/.test(m4),'V205 lot 4 : migration additive (fonction architecte, droits, équipe), droits personnalisés conservés');
    ok(/architecte/.test(R('exb-db.js'))&&/\['architecte','Architecte'\]/.test(R('exb-equipe.js'))&&/architecte\.html/.test(R('exb-equipe.js'))&&/\['architecte', 'Architecte'\]/.test(R('exb-droits-actions.js')),'V205 lot 4 : « architecte » proposé dans Équipe, libellés et profils de droits'); }
  ok(/affectations_projets/.test(R('supabase/migration-v205-lot3-ingenierie.sql'))&&/calcul_couverture/.test(R('supabase/migration-v205-lot3-ingenierie.sql')),'V205 lot 3 : migration SQL (affectations, couverture de validation, refus journalisés)');
  ok(/function projetsCartes/.test(R('exb-bi.js'))&&/h \+= projetsCartes\(\) \+ projetsHtml\(\)/.test(R('exb-bi.js')),'V205 : BI Direction affiche le tableau de bord des projets en tête');
  ok(/sec\.classList\.add\('exbs-alt'\)/.test(ct5),'V205 : l\'onglet Cartes masque aussi l\'affiche logiciels');
}
{ /* V205l : écran de connexion d'espace */
  title('V205l : écran de connexion d\'espace');
  const cg=R('exb-v205-connexion-espace.js'), sh9=R('exb-v99r-shell.js'), ix9=R('index.html'), sw9=R('sw.js'), eq9=R('exb-equipe.js'), db9=R('exb-db.js');
  ok(/espaces:function\(\)\{return ESPACES\}/.test(sh9)&&/EXB_SHELL\.espaces\(\)/.test(cg),'V205l : l\'écran lit les espaces et leurs fonctions admises dans le menu (aucune liste en double)');
  ok(/exb-v205-connexion-espace\.js/.test(ix9)&&/\.\/exb-v205-connexion-espace\.js/.test(sw9),'V205l : module chargé par index.html et mis en cache hors connexion');
  ok(/\/auth\/v1\/token\?grant_type=password/.test(cg)&&/\/auth\/v1\/signup/.test(cg)&&/\/auth\/v1\/recover/.test(cg)&&/type === 'recovery'/.test(cg),'V205l : connexion, première connexion, mot de passe oublié et lien de réinitialisation');
  ok(/equipe_reclamer/.test(cg)&&/mon_organisation/.test(cg)&&/rejoindre_organisation/.test(cg)&&/sp\.fonctions\.indexOf\(f\) < 0/.test(cg)&&/o\.role !== 'admin'/.test(cg),'V205l : rattachement à l\'entreprise puis contrôle de la fonction (l\'administrateur passe)');
  ok(!/localStorage\.setItem\([^)]*(pw|pass)/i.test(cg)&&!/setItem\('[^']*',\s*(pw|pass)/.test(cg),'V205l : aucun mot de passe n\'est enregistré par l\'écran');
  ok(/adopt:function\(o\)/.test(db9)&&/exbFinishLogin=function\(label\)/.test(ix9),'V205l : exb-db adopte l\'entreprise ; la connexion locale accepte un libellé d\'audit');
  const redir=['comptable','ingenieur','architecte','chantier','direction','administration','magasin','espace-formation'].every(f=>/location\.replace\('index\.html\?espace=[a-z]+'(\+\(\/\[\?&\]inv=\/[^;]*?\))?\+location\.hash\)/.test(R(f+'.html')));
  ok(redir,'V205l : les 8 pages d\'espace gardent le #jeton des liens reçus par e-mail (confirmation, réinitialisation)');
  ok(/orgMember\(\)/.test(R('exb-sync.js'))&&/!l\.statut&&orgMember\(\)/.test(R('exb-sync.js')),'V205y : un membre invité (sans licence par compte) n\'est plus bloqué par « Aucune licence associée à ce compte »');
  ok(/Première connexion/.test(eq9)&&!/Créez votre compte en ligne avec CETTE/.test(eq9),'V205l : le message d\'invitation renvoie vers « Première connexion »');
  ok(/^const V='(v205[l-z]|v2[1-9]\d[a-z]?)-/.test(sw9),'V205l : cache hors connexion renouvelé');
  { /* V205z : mot de passe oublié par CODE reçu par e-mail (plus de lien obligatoire) */
    title('V205z : mot de passe oublié par code');
    const tpl=R('supabase/email-template-mot-de-passe-oublie.html');
    ok(/\/auth\/v1\/verify/.test(cg)&&/type: 'recovery', email: em, token: code/.test(cg)&&/async function doCode/.test(cg)&&/case 'code':/.test(cg),'V205z : le code reçu est vérifié (/auth/v1/verify, type recovery) puis le nouveau mot de passe est enregistré');
    ok(/autocomplete="one-time-code"/.test(cg)&&/inputmode="numeric"/.test(cg)&&/replace\(\/\\D\/g, ''\)/.test(cg),'V205z : champ « code » numérique (clavier chiffres, remplissage automatique du code, espaces ignorés)');
    ok(!/case 'sent':/.test(cg)&&/Envoyer le code/.test(cg)&&!/Envoyer le lien/.test(cg),'V205z : « Mot de passe oublié » envoie un code (plus de message « ouvrez ce lien »)');
    ok(/resendAt/.test(cg)&&/Patientez/.test(cg)&&/fails >= 5/.test(cg.slice(cg.indexOf('async function doCode'))),'V205z : renvoi du code limité à 60 s, essais limités');
    ok(/var h = configured\(\) \? readHash\(\) : null;/.test(cg)&&/if \(h\) \{ fromLink\(h\); return; \}/.test(cg)&&/if \(key\(\) && o\.role !== 'admin'/.test(cg),'V205z : un lien de réinitialisation / confirmation ouvert sans espace connu (autre navigateur) est accepté : fini l\'écran bleu « licence » au retour');
    ok(/\{\{ \.Token \}\}/.test(tpl)&&!/ConfirmationURL/.test(tpl),'V205z : modèle d\'e-mail Supabase « Reset Password » fourni (code {{ .Token }}, sans lien)');
    { const ixr=R('index.html'), gu=R('exb-v205-guichet.js'), tf=R('exb-tfl.js');
      ok(/ph\.indexOf\("exbidb:"\)>=0&&window\.EXBBIG&&EXBBIG\.unpack/.test(ixr),'V205z : reçu du logiciel central — la photo rangée par le grand stockage (jeton exbidb:) est relue avant d\'être posée sur le reçu');
      ok(/function realPhoto/.test(gu)&&/var src = realPhoto\(p\.photo\)/.test(gu)&&/vignette\(\{ participant_id: eid, photo: e\.photo \}\)/.test(gu),'V205z : espace comptable — la vignette de l\'annuaire est produite aussi pour les grandes photos et pour les étudiants TFL');
      ok(/photo: photoReelle\(e\.photo\)/.test(tf)&&/function photoReelle/.test(tf),'V205z : reçu TFL de l\'administration — la photo de l\'étudiant est posée (cadre vide avant)'); }
    ok(/^const V='(v205z|v2[1-9]\d[a-z]?)-/.test(sw9),'V205z : cache hors connexion renouvelé'); }
}
{ /* V204 : demandes clients dans Portails & signatures + chantier automatique */
  title('V204 : demandes clients, chantier automatique');
  const ix=R('index.html'), pt=R('exb-v99zy-portails.js'), sq=R('supabase/migration-v204-demandes-clients-portails.sql'), sw4=R('sw.js');
  ok(/req:key,from_request:true/.test(ix)&&/exbProjects\.some\(x=>x\.req===key\)/.test(ix),'V204 : importer une demande crée aussi le chantier (une seule fois par demande)');
  ok(/AUTOBTP/.test(ix)&&/importBtp\(nv\)/.test(ix),'V204 : création automatique fiche client + chantier à la réception');
  ok(/ORDER\.filter\(t=>HOST\[t\]&&t!=='btp'\)/.test(ix),'V204 : les demandes clients ne sont plus dans Inscriptions (formation)');
  ok(/\['dem', '📨 Demandes clients'/.test(pt)&&/function viewDem/.test(pt)&&/client_comptes_suivi/.test(pt),'V204 : onglet « Demandes clients » dans Portails & signatures');
  ok(/demDevis/.test(pt)&&/client_doc_publier/.test(pt)&&/payOk/.test(pt.split('function viewDem')[1]||''),'V204 : paiements à confirmer et devis à annexer depuis la demande');
  ok(/data-id="clients"/.test(pt)&&/data-id="projets"/.test(pt),'V204 : interconnexion Clients & CRM et Projets & chantiers');
  ok(/client_comptes_suivi/.test(sq)&&/client_lien_brouillon/.test(sq)&&/portail_lire/.test(sq),'V204 : migration SQL (inclut V203, réexécutable)');
  ok(/^const V='v2\d\d[a-z]?-/.test(sw4),'V204 : cache hors connexion renouvelé'); }

{ /* V205n : Workflow par espace + messagerie d'équipe privée (pièces jointes, choix d'une personne, suppression des fichiers, envoi depuis les écrans PDF) */
  title('V205n : messagerie d\'équipe privée et Workflow par espace');
  const sh=R('exb-v99r-shell.js'), ms=R('exb-messagerie.js'), db=R('exb-db.js'), sq=R('supabase/migration-v205-lot8-messagerie-privee.sql'), sw=R('sw.js'), pc=R('exb-v81-pieces.js'), pd=R('exb-pdf.js');
  const blkE=sh.slice(sh.indexOf('var ESPACES='), sh.indexOf('function espaceRefuse'));
  ok((blkE.match(/'exbwf'/g)||[]).length>=8,'V205n : le Workflow (exbwf) est dans les 8 espaces');
  ok(!/messages_equipe/.test(db),'V205n : les messages d\'équipe ne passent PAS par une collection partagée lisible de tous');
  ok(/equipe_envoyer/.test(ms)&&/equipe_lire/.test(ms)&&/equipe_piece/.test(ms)&&/equipe_membres/.test(ms)&&/equipe_supprimer_piece/.test(ms)&&/function envoyerDocument/.test(ms)&&/function proposerEnvoi/.test(ms)&&/function panneauPieces/.test(ms),'V205n : messagerie via les fonctions serveur (envoi, lecture, pièce, membres, suppression, panneau administrateur)');
  ok(/EXBMessagerie\.proposerEnvoi/.test(pd),'V205n : tout PDF enregistré par le moteur commun propose « Envoyer à un autre espace »');
  ok(/Envoyer à un autre espace/.test(pc)&&/envoyerDocument/.test(pc),'V205n : pièces écrites — bouton « Envoyer à un autre espace »');
  ok(/enable row level security/.test(sq)&&/revoke all on equipe_messages from anon, authenticated/.test(sq)&&!/create policy/.test(sq),'V205n : SQL — table fermée (RLS sans politique), accès par fonctions seulement');
  ok(/function equipe_visible/.test(sq)&&/x\.role='admin'/.test(sq)&&/m\.de_user=auth\.uid\(\)/.test(sq)&&/m\.a_user=auth\.uid\(\)/.test(sq)&&/m\.a_fonction=x\.fonction/.test(sq),'V205n : SQL — visible seulement de l\'expéditeur, du destinataire (personne ou fonction) et de l\'administrateur');
  ok(/8500000/.test(sq)&&/fichier_trop_lourd/.test(sq),'V205n : SQL — pièce jointe limitée à 6 Mo, types acceptés');
  ok(/function equipe_supprimer_piece/.test(sq)&&/piece_data=null, piece_supprimee=true/.test(sq)&&/piece_auto/.test(sq)&&/function equipe_membres/.test(sq),'V205n : SQL — suppression du fichier (texte conservé), usage unique, liste des membres');
  ok(/delete from droits_fonction where collection='messages_equipe'/.test(sq)&&/delete from enregistrements where collection='messages_equipe'/.test(sq),'V205n : SQL — reprise et suppression de l\'ancienne collection partagée');
  ok(/^const V='(v205[n-z]|v2[1-9]\d[a-z]?)-/.test(sw),'V205n : cache hors connexion renouvelé'); }

{ /* V205q : profil opérateur (identité, signature, sceau) rattaché au compte */
  title('V205q : profil opérateur');
  const sh=R('exb-v99r-shell.js'), op=R('exb-operateur.js'), sw=R('sw.js'), pd=R('exb-pdf.js'), mg=R('supabase/migration-v205k-profil-operateur.sql');
  ok(/EXBOperateur\s*=/.test(op)&&/EXB_OPERATEUR_V1/.test(op)&&/\.\/exb-operateur\.js/.test(sw)&&/exb-operateur\.js/.test(R('index.html')),'V205q : module Profil opérateur chargé et mis en cache');
  ok(/EXBOperateur\.line\(\)/.test(pd)&&/EXBOperateur\.remplace\(\)/.test(pd)&&/EXBOperateur\.visa\('jpg'\)/.test(pd)&&/EXBOperateur\.sigLabel\(\)/.test(pd),'V205q : PDF — « Établi par », signature et sceau de l\'opérateur');
  ok(/EXBOperateur\.remplace\(\)/.test(R('exb-v81-pieces.js'))&&/EXBOperateur\.blockHtml/.test(R('exb-rapport-marque.js')),'V205q : pièces écrites et rapports utilisent le profil opérateur');
  ok(/Mon profil opérateur/.test(sh)&&(sh.match(/EXBOperateur&&EXBOperateur\.open\(\)/g)||[]).length>=2,'V205q : bouton « Mon profil opérateur » (menu du profil + menu de chaque espace)');
  ok(/operateur_profils/.test(mg)&&/enable row level security/.test(mg)&&(mg.match(/user_id = auth\.uid\(\)/g)||[]).length>=5&&/revoke all on public\.operateur_profils from anon/.test(mg),'V205q : migration — une ligne par compte, RLS, rien pour anon');
  ok(/operateur_profils\?on_conflict=user_id/.test(op)&&/function pull\(/.test(op),'V205q : le profil suit le compte (envoi, récupération, version la plus récente)');
  ok(/^const V='(v205[q-z]|v2[1-9]\d[a-z]?)-/.test(sw),'V205q : cache hors connexion renouvelé');
  /* V205r : recherche des devis Finances + message « PDF non généré » visible */
  { const rg=fs.readFileSync('exb-recherche-globale.js','utf8'),gd=fs.readFileSync('exb-guide.js','utf8');
    ok(/k: 'exb_finance'/.test(rg)&&/keep: function/.test(rg)&&/prep: function/.test(rg),'V205r : la recherche globale indexe exb_finance (taux exclus, nom du projet inclus)');
    ok(/st\.grave=1/.test(gd)&&/PDF n’a pas été généré/.test(gd)&&/if\(!grave\)hideT/.test(gd),'V205r : sans visa, carte centrale persistante « PDF non généré »');
    ok(/exb_annuaire_guichet/.test(rg)&&/visaPublie\(\)/.test(gd)&&/anyVisa\|\|EXBSign\.visa/.test(R('index.html')),'V205r : annuaire du guichet cherché ; visa publié accepté pour le reçu');
    ok(/opS\s*=\s*null/.test(R('exb-v142c-recu-client.js'))&&/signeSeul/.test(R('exb-v142c-recu-client.js')),'V205r : reçu client : nom et fonction du signataire (comptable…) au lieu du Directeur Général');
    ok(/function vignette\(p\)/.test(R('exb-v205-guichet.js'))&&/photo: e\.photo/.test(R('exb-v205-guichet.js')),'V205r : annuaire du guichet : vignette de la photo reprise sur le reçu du comptable distant');
    { const eq=R('exb-equipe.js'),sq=R('supabase/migration-v205v-codes-personnels.sql');
      ok(/function getCode\(/.test(eq)&&/equipe_code_membre/.test(eq)&&/equipe_regenerer_code/.test(eq)&&/CODE\(i\)/.test(eq)&&!/\(ORG&&ORG\.code\|\|''\)/.test(eq),'V205v : panneau Équipe : un code d\'activation personnel par membre (repli sur le code entreprise si la migration manque)');
      ok(/create table if not exists codes_membres/.test(sq)&&/function activer_par_invitation\(/.test(sq)&&/function rejoindre_organisation\(/.test(sq)&&/ce code est personnel/.test(sq)&&/trg_codes_membres_revoquer/.test(sq),'V205v : migration SQL des codes personnels (liés à l\'e-mail, révoqués au retrait)'); }
    { const eq=R('exb-equipe.js'),gt=R('exb-v205-connexion-espace.js');
      ok(!/mot de passe habituel/.test(eq)&&/vous choisissez vous-même votre mot de passe/.test(eq)&&/Mot de passe oublié/.test(eq),'V205w : message d\'invitation : plus de « mot de passe habituel » ; première connexion (on choisit son mot de passe) ou compte existant');
      ok(/Choisir la fonction/.test(eq)&&/Choisissez la fonction de cette personne/.test(eq)&&/fonction à choisir/.test(eq),'V205w : invitation : fonction à choisir obligatoirement (plus de « Polyvalent » par défaut), membres « Polyvalent » signalés');
      ok(/data-act="retry"/.test(gt)&&/pas choisie par l’espace/.test(gt),'V205w : accès refusé : explique l\'origine de la fonction + bouton « réessayer »'); }
    ok(/^const V='(v205[r-z]|v2[1-9]\d[a-z]?)-/.test(sw),'V205r : cache hors connexion renouvelé'); } }

{ /* V210c : listes déroulantes stables (messagerie d'équipe, menu des modules) */
  title('V210c : listes déroulantes stables');
  const ms=R('exb-messagerie.js'), dk=R('exb-module-dock.js'), sw=R('sw.js');
  ok(/!ST\.thread && !ST\.form && !ST\.pjs && !ST\.busy && !\(d\.activeElement && \/\^\(INPUT\|TEXTAREA\|SELECT\)\$\/\.test/.test(ms),'V210c : le rafraîchissement de 30 s ne reconstruit plus la messagerie pendant un formulaire, une saisie ou une liste ouverte');
  ok(/function formDraft/.test(ms)&&/restoreDraft\(dr\)/.test(ms),'V210c : destinataire, objet et message saisis sont conservés si le panneau est reconstruit');
  ok(/pop && pop\.contains\(e\.target\)\) return;/.test(dk),'V210c : choisir une valeur dans le panneau du menu des modules ne cache plus la barre');
  ok(/if \(!r\.width && !r\.height\) return;/.test(dk),'V210c : le panneau du menu des modules ne sort plus de l\'écran quand la barre est masquée');
  ok(/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v210c-'),'V210c : cache hors connexion renouvelé'); }
{ /* V211 : bureau de topographie (cahier des charges §5.8) */
  title('V211 : bureau de topographie');
  const tp=R('exb-topo.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-topo.js"></script>')&&ix.indexOf('exb-be-dalles.js')<ix.indexOf('exb-topo.js'),'V211 : topographie chargée après le bureau d\'études');
  ok(sw.includes("'./exb-topo.js'")&&/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v211-'),'V211 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_topo/.test(tp)&&/vérificateur ≠ opérateur|Le vérificateur doit être une autre personne/.test(tp),'V211 : visa nominatif, vérificateur différent de l\'opérateur');
  ok(!/fetch\(|XMLHttpRequest/.test(tp),'V211 : aucun appel réseau (données locales)');
  const T=require(path.join(root,'exb-topo.js'));
  ok(Math.abs(T.surface([{x:0,y:0},{x:10,y:0},{x:10,y:10},{x:0,y:10}]).aire-100)<1e-9,'V211 : aire d\'un carré 10 × 10 = 100 m²');
  ok(Math.abs(T.cubGrille({pas:10,zp:10,G:[[9,10,11],[9,10,11],[9,10,11]]}).deblai-100)<1e-6,'V211 : cubature en grille, passage déblai / remblai exact'); }

{ /* V211 : géotechnique, compléments (stratigraphie, réserves) */
  title('V211 : géotechnique — stratigraphie et réserves');
  const gp=R('exb-geo-plus.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-geo-plus.js"></script>')&&ix.indexOf('exb-topo.js')<ix.indexOf('exb-geo-plus.js'),'V211 : géotechnique complémentaire chargée après la topographie');
  ok(sw.includes("'./exb-geo-plus.js'"),'V211 : module géotechnique dans le cache hors connexion');
  ok(/La preuve de levée est obligatoire/.test(gp)&&/signature nominative/.test(gp),'V211 : une réserve ne se lève qu\'avec une preuve et un nom');
  ok(!/setItem\(KG|wr\(KG/.test(gp),'V211 : les rapports de sol (P2) ne sont jamais modifiés par ce module');
  const GP=require(path.join(root,'exb-geo-plus.js'));
  ok(GP.etat({echeance:'2026-01-01',levee:null},'2026-11-22')==='En retard','V211 : réserve dépassée = « En retard » (état calculé)'); }

{ /* V212 : bureau d'électricité (cahier des charges §5.8) */
  title('V212 : bureau d\'électricité');
  const el=R('exb-elec.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-elec.js"></script>')&&ix.indexOf('exb-geo-plus.js')<ix.indexOf('exb-elec.js'),'V212 : électricité chargée après la géotechnique complémentaire');
  ok(sw.includes("'./exb-elec.js'")&&/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v212-'),'V212 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_elec/.test(el)&&/Le vérificateur doit être une autre personne que l’auteur/.test(el),'V212 : visa nominatif, vérificateur différent de l\'auteur');
  ok(/izConf = null/.test(el)||/x\.izConf = null/.test(el),'V212 : modifier la table Iz annule sa confirmation');
  ok(!/fetch\(|XMLHttpRequest/.test(el),'V212 : aucun appel réseau (données locales)');
  const E=require(path.join(root,'exb-elec.js'));
  ok(Math.abs(E.ib({P:2.4,Ku:0.8,cos:0.95,type:'mono'},{u1:230,u3:400})-8.7872)<1e-3,'V212 : courant d\'emploi monophasé Ib = P·Ku/(U·cos φ)');
  ok(E.calibre(8.8)===10&&E.calibre(1700)===null,'V212 : calibre normalisé supérieur, null au-delà de la série'); }

{ /* V212 : bureau de plomberie / HVAC (cahier des charges §5.8) */
  title('V212 : bureau de plomberie / HVAC');
  const pl=R('exb-plomb.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-plomb.js"></script>')&&ix.indexOf('exb-elec.js')<ix.indexOf('exb-plomb.js'),'V212 : plomberie / HVAC chargée après l\'électricité');
  ok(sw.includes("'./exb-plomb.js'"),'V212 : module plomberie / HVAC dans le cache hors connexion');
  ok(/exb_plomb/.test(pl)&&/Le vérificateur doit être une autre personne que l’auteur/.test(pl),'V212 : visa nominatif, vérificateur différent de l\'auteur');
  ok(!/fetch\(|XMLHttpRequest/.test(pl),'V212 : aucun appel réseau (données locales)');
  const P=require(path.join(root,'exb-plomb.js'));
  ok(Math.abs(P.frottement(1000,0.02,1.5e-6)-0.064)<1e-9,'V212 : frottement laminaire 64/Re');
  ok(Math.abs(P.debitPointe([{nom:'a',q:0.1,n:5}],1).qp-0.25)<1e-9,'V212 : débit de pointe k·Σq/√(n−1) = 0,25 l/s pour 5 × 0,1 l/s');
  ok(Math.abs(P.charges('','','R;300;8',{rhoA:1.2,cpA:1.006}).total-1.2*1006*(300/3600)*8)<1e-6,'V212 : charge d\'air neuf ρ·cp·Q·ΔT'); }

{ /* V213 : bureau VRD (cahier des charges §5.8) */
  title('V213 : bureau VRD');
  const m=R('exb-vrd.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-vrd.js"></script>')&&ix.indexOf('exb-plomb.js')<ix.indexOf('exb-vrd.js'),'V213 : vrd chargé après exb-plomb.js');
  ok(sw.includes("'./exb-vrd.js'")&&/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v213-'),'V213 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_vrd/.test(m)&&!/fetch\(|XMLHttpRequest/.test(m),'V213 : données locales (clé exb_vrd), aucun appel réseau');
  ok(/Le vérificateur doit être une autre personne que l’auteur/.test(m)&&/dnConf = null/.test(m),'V213 : visa nominatif ; modifier la table des diamètres annule la confirmation');
  const X=require(path.join(root,'exb-vrd.js')), q=X.qps(0.4,0.01,0.013);
  ok(Math.abs(X.remplissage(q/2,0.4,0.01,0.013).hD-0.5)<1e-9,'V213 : Manning, demi-remplissage pour Q = Qps/2');
  ok(Math.abs(X.terrass(X.parseSections('0;4;0\n20;2;2').rows,20).deblai-60)<1e-9,'V213 : terrassements, volume par aires moyennes');
  }

{ /* V213 : bureau environnement (cahier des charges §5.8) */
  title('V213 : bureau environnement');
  const m=R('exb-env.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-env.js"></script>')&&ix.indexOf('exb-vrd.js')<ix.indexOf('exb-env.js'),'V213 : env chargé après exb-vrd.js');
  ok(sw.includes("'./exb-env.js'")&&/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v213-'),'V213 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_env/.test(m)&&!/fetch\(|XMLHttpRequest/.test(m),'V213 : données locales (clé exb_env), aucun appel réseau');
  ok(/preuve ET nom|PREUVE et un NOM/.test(m),'V213 : une clôture exige une preuve et un nom');
  const X=require(path.join(root,'exb-env.js'));
  ok(X.parseNuis('2026-11-12;Bruit;N;71;dB(A);70').rows[0].depasse===true,'V213 : dépassement du seuil saisi détecté');
  ok(X.parseInc('A;2026-11-01;d;Faible;;;2026-11-15;;;','2026-11-22').rows[0].etat==='En retard','V213 : incident non clos après échéance = « En retard »');
  }

{ /* V213 : bureau juridique / contrats (cahier des charges §5.8) */
  title('V213 : bureau juridique / contrats');
  const m=R('exb-jur.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-jur.js"></script>')&&ix.indexOf('exb-env.js')<ix.indexOf('exb-jur.js'),'V213 : jur chargé après exb-env.js');
  ok(sw.includes("'./exb-jur.js'")&&/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v213-'),'V213 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_jur/.test(m)&&!/fetch\(|XMLHttpRequest/.test(m),'V213 : données locales (clé exb_jur), aucun appel réseau');
  ok(/Le vérificateur doit être une autre personne que l’auteur/.test(m),'V213 : validation nominative, vérificateur différent du rédacteur');
  const X=require(path.join(root,'exb-jur.js'));
  ok(X.synthese({montant:'1000',fin:'2026-12-31',debut:'',signature:''},X.parseAv('A;o;2026-01-01;100;10;Signé\nB;o;2026-01-01;900;10;Brouillon').rows).actuel===1100,'V213 : seuls les avenants signés modifient le montant');
  ok(X.validite('2026-11-21','2026-11-22',30)==='Expirée','V213 : garantie ou assurance dépassée = « Expirée »');
  }

{ /* V213 : bureau maintenance / facility (cahier des charges §5.8) */
  title('V213 : bureau maintenance / facility');
  const m=R('exb-maint.js'), ix=R('index.html'), sw=R('sw.js');
  ok(ix.includes('<script src="exb-maint.js"></script>')&&ix.indexOf('exb-jur.js')<ix.indexOf('exb-maint.js'),'V213 : maint chargé après exb-jur.js');
  ok(sw.includes("'./exb-maint.js'")&&/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v213-'),'V213 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_maint/.test(m)&&!/fetch\(|XMLHttpRequest/.test(m),'V213 : données locales (clé exb_maint), aucun appel réseau');
  ok(/Aucun doublon|jamais de doublon/.test(m)||/dup/.test(m),'V213 : génération des OT sans doublon');
  const X=require(path.join(root,'exb-maint.js'));
  ok(X.parseEq('A;b;;;;;court').erreurs.length===1&&X.parseEq('A;b;;;;;ABCDEFGHIJKLMNOPQRSTUV').rows.length===1,'V213 : GlobalId IFC contrôlé (22 caractères)');
  ok(X.parsePlan('A;t;30;;').rows[0].per===30,'V213 : périodicité en jours saisie');
  }

{ /* V215 : bureau d'architecture — coordination, 3D, analyse de site, matériaux (cahier des charges §5.2) */
  title('V215 : bureau d\'architecture (V209g à V209j)');
  const ix=R('index.html'), sw=R('sw.js'), db=R('exb-db.js');
  ['exb-v209-coordination.js','exb-v209-coordination-3d.js','exb-v209-analyse-site.js','exb-v209-materiaux.js'].forEach(f=>{
    ok(ix.includes('<script src="'+f+'"></script>')&&fs.existsSync(path.join(root,f)),'V215 : '+f+' présent et chargé par index.html');
    ok(sw.includes("'./"+f+"'"),'V215 : '+f+' dans le cache hors connexion'); });
  ok(/^const V='v2[12]\d[a-z]?-/.test(sw)&&sw.includes('v215-'),'V215 : cache renouvelé');
  ok(['exb_arch_coord','exb_arch_site','exb_arch_mat','exb_arch_prog','exb_arch_reg'].every(k=>db.includes(k+":'")),'V215 : collections d\'architecture déclarées dans exb-db.js');
  ok(db.includes('meta.blk')&&db.includes("exb_hr:'personnel'"),'V215 : exb-db.js conserve la suspension des membres (V210f)');
  ok(R('exb-ifc3d.js').includes('this.ghost'),'V215 : visionneuse 3D — passe de rendu « fantôme » des collisions');
  ok(['exb-v209-coordination.js','exb-v209-analyse-site.js','exb-v209-materiaux.js'].every(f=>R(f).includes("getElementById('exbArcBtn')")),'V215 : boutons ancrés à « Phases architecture » si « Programme & surfaces » est absent');
  ok(!/fetch\(|XMLHttpRequest/.test(R('exb-v209-materiaux.js')+R('exb-v209-analyse-site.js')),'V215 : analyse de site et matériaux sans appel réseau');
  }

{ /* V216 : règles IDS + IA Architecte (cahier des charges §5.2 et §7) */
  title('V216 : règles IDS et IA Architecte (V209k, V209l)');
  const ix=R('index.html'), sw=R('sw.js'), db=R('exb-db.js');
  ['exb-v209-ids.js','exb-v209-ia-architecte.js'].forEach(f=>{
    ok(ix.includes('<script src="'+f+'"></script>')&&fs.existsSync(path.join(root,f)),'V216 : '+f+' présent et chargé par index.html');
    ok(sw.includes("'./"+f+"'"),'V216 : '+f+' dans le cache hors connexion'); });
  ok(sw.includes('v216-'),'V216 : cache renouvelé');
  ok(db.includes("exb_arch_ids:'arch_ids'"),'V216 : collection arch_ids déclarée dans exb-db.js');
  ok(fs.existsSync(path.join(root,'supabase/migration-v209k-regles-ids.sql'))&&R('supabase/migration-v209k-regles-ids.sql').includes("'arch_ids'"),'V216 : migration des droits arch_ids fournie');
  ok(!/fetch\(|XMLHttpRequest/.test(R('exb-v209-ids.js')+R('exb-v209-ia-architecte.js')),'V216 : IDS et IA Architecte sans appel réseau (aucune donnée envoyée)');
  ok(!/EXBS\.set\(/.test(R('exb-v209-ia-architecte.js')),'V216 : IA Architecte en lecture seule');
  ok(ix.indexOf('exb-v209-materiaux.js')<ix.indexOf('exb-v209-ids.js')&&ix.indexOf('exb-v209-ids.js')<ix.indexOf('exb-v209-ia-architecte.js'),'V216 : ordre de chargement (matériaux, IDS, IA Architecte)');
  }

{ /* V217 : programme & surfaces + contrôle réglementaire (cahier des charges §5.2, limite 1 de V216) */
  title('V217 : programme & surfaces, contrôle réglementaire (V209e, V209f)');
  const ix=R('index.html'), sw=R('sw.js'), db=R('exb-db.js');
  ['exb-v209-architecture-programme.js','exb-v209-controle-reglementaire.js'].forEach(f=>{
    ok(ix.includes('<script src="'+f+'"></script>')&&fs.existsSync(path.join(root,f)),'V217 : '+f+' présent et chargé par index.html');
    ok(sw.includes("'./"+f+"'"),'V217 : '+f+' dans le cache hors connexion'); });
  ok(sw.includes('v217-'),'V217 : cache renouvelé');
  ok(db.includes("exb_arch_prog:'arch_programme'")&&db.includes("exb_arch_reg:'arch_reglementation'"),'V217 : collections arch_programme et arch_reglementation déclarées');
  ok(fs.existsSync(path.join(root,'supabase/migration-v209e-programme.sql'))&&R('supabase/migration-v209e-programme.sql').includes("'arch_programme'"),'V217 : migration des droits arch_programme fournie');
  ok(fs.existsSync(path.join(root,'supabase/migration-v209f-controle-reglementaire.sql'))&&R('supabase/migration-v209f-controle-reglementaire.sql').includes("'arch_reglementation'"),'V217 : migration des droits arch_reglementation fournie');
  ok(!/fetch\(|XMLHttpRequest/.test(R('exb-v209-architecture-programme.js')+R('exb-v209-controle-reglementaire.js')),'V217 : aucun appel réseau');
  ok(ix.indexOf('exb-v209-architecture-programme.js')<ix.indexOf('exb-v209-controle-reglementaire.js')&&ix.indexOf('exb-v209-controle-reglementaire.js')<ix.indexOf('exb-v209-coordination.js'),'V217 : ordre de chargement (programme, contrôle réglementaire, coordination)');
  ok(R('exb-v209-materiaux.js').includes('EXBARCP.calc')&&R('exb-v209-architecture-programme.js').includes('w.EXBARCP = API'),'V217 : EXBARCP exposé comme attendu par Matériaux et l’IA Architecte');
}

{ /* V218 : logos personnalisés sur les modèles de certificat 1 à 5 */
  title('V218 : logos personnalisés sur les modèles de certificat');
  const lg=R('exb-certificat-logos.js'), ix=R('index.html'), sw=R('sw.js'), c6=R('exb-v206c-certificats-images.js'), m5=R('exb-v206b-certificat-modele-5.js');
  ok(ix.includes('<script src="exb-certificat-logos.js"></script>')&&ix.indexOf('exb-certificat-logos.js')<ix.indexOf('exb-v206-certificat-modeles.js'),'V218 : module des logos chargé avant les modèles de certificat');
  ok(sw.includes("'./exb-certificat-logos.js'")&&/^const V='v2(1[89]|20)-/.test(sw)&&sw.includes('v218-logos-certificats'),'V218 : module dans le cache hors connexion, cache renouvelé');
  ok(/exb_logo/.test(lg)&&/rdc_logo/.test(lg)&&/EXB_BRAND/.test(lg),'V218 : lit le logo Excellencia (ou de la marque) et le logo RDC enregistrés');
  ok(['m1','m2','m3','m4','m5'].every(m=>new RegExp('"'+m+'":\\{"E":\\{[^}]*"kind"[^}]*\\},"R":\\{').test(lg)),'V218 : zones Excellencia et RDC prévues pour les 5 modèles');
  ok(/EXB_CERT_LOGOS\.draw\(root, k\)/.test(c6)&&/EXB_CERT_LOGOS\.draw\(root, KEY\)/.test(m5),'V218 : modèles 1 à 4 et modèle 5 appellent le module');
  ok(/applyLogos/.test(lg)&&!/fetch\(|XMLHttpRequest/.test(lg),'V218 : redessin au changement de logo, aucun appel réseau'); }

{ /* V219 : filigrane au choix sur les modèles de certificat 1 à 5 */
  title('V219 : filigrane au choix sur les modèles de certificat');
  const fl=R('exb-certificat-filigrane.js'), ix=R('index.html'), sw=R('sw.js'), c6=R('exb-v206c-certificats-images.js'), m5=R('exb-v206b-certificat-modele-5.js');
  ok(ix.includes('<script src="exb-certificat-filigrane.js"></script>')&&ix.indexOf('exb-certificat-filigrane.js')<ix.indexOf('exb-v206-certificat-modeles.js'),'V219 : module du filigrane chargé avant les modèles de certificat');
  ok(sw.includes("'./exb-certificat-filigrane.js'")&&/^const V='v2(19|20)-/.test(sw),'V219 : module dans le cache hors connexion, cache renouvelé (v219)');
  ok(['none','exb','rdc','text'].every(m=>fl.includes("['"+m+"'")),'V219 : choix Aucun / logo Excellencia / filigrane RDC / texte personnalisé');
  ok(/EXB_CERT_WM\.draw\(root, k\)/.test(c6)&&/EXB_CERT_WM\.draw\(root, KEY\)/.test(m5),'V219 : modèles 1 à 4 et modèle 5 appellent le module');
  ok(/exb-wm-pick/.test(fl)&&/bulk_background/.test(fl)&&/exb_cert_wm_v219/.test(fl),'V219 : réglage dans le certificat individuel et l\'impression groupée, mémorisé');
  ok(/mode: DEF\.mode/.test(fl)&&/mode: 'none'/.test(fl),'V219 : sans choix, aucun filigrane (rendu d\'origine inchangé)');
  ok(!/fetch\(|XMLHttpRequest/.test(fl),'V219 : aucun appel réseau'); }

{ /* V220 : textes personnalisés sur les modèles de certificat 1 à 5 */
  title('V220 : textes de l\'entreprise sur les modèles de certificat');
  const tx=R('exb-certificat-textes.js'), ix=R('index.html'), sw=R('sw.js'), c6=R('exb-v206c-certificats-images.js'), m5=R('exb-v206b-certificat-modele-5.js');
  ok(ix.includes('<script src="exb-certificat-textes.js"></script>')&&ix.indexOf('exb-certificat-textes.js')<ix.indexOf('exb-v206-certificat-modeles.js'),'V220 : module des textes chargé avant les modèles de certificat');
  ok(sw.includes("'./exb-certificat-textes.js'")&&/^const V='v220-/.test(sw),'V220 : module dans le cache hors connexion, cache renouvelé (v220)');
  ok(/EXB_CERT_TXT\.draw\(root, k, ov, el\)/.test(c6)&&/EXB_CERT_TXT\.draw\(root, KEY, ov, el\)/.test(m5),'V220 : modèles 1 à 4 et modèle 5 appellent le module');
  ok(/changed: N\(name\) !== N\(ORIG\.name\)/.test(tx)&&/if \(id\.changed\)/.test(tx),'V220 : entreprise d\'origine = rendu d\'origine inchangé');
  ok(/stampSvg/.test(tx)&&/certifie que/.test(tx)&&/logoBlock/.test(tx)&&/dgName/.test(tx),'V220 : nom, slogan, cachet, phrase du modèle 5, Directeur général');
  ok(!/fetch\(|XMLHttpRequest/.test(tx),'V220 : aucun appel réseau'); }
