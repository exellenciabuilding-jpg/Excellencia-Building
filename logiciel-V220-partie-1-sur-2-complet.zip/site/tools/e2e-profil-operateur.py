# V205q — Profil opérateur (identité, signature, sceau → PDF / rapports), testé depuis l'Espace Magasin et les autres espaces
import http.server, threading, functools, os, sys, re
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    def menu():
        pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(500)
        return ' | '.join(pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)"))
    def who(f, role='editeur'):
        pg.evaluate("window.EXBDB.info=()=>({on:true,role:'%s',fonction:'%s',label:'%s'})" % (role, f, f))
    # ---- Espace Magasin
    boot('magasin.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'magasin', '/magasin ouvre l\'Espace Magasin')
    m = menu()
    t('Mon profil opérateur' in m, 'Magasin : bouton « Mon profil opérateur » dans le menu de l\'espace')
    who('magasinier'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Magasin : un magasinier est accepté')
    who('direction'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Magasin : la direction est acceptée')
    who('admin', 'admin'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Magasin : l\'administrateur est accepté')
    for f in ['comptable', 'rh', 'conducteur', 'formateur']:
        who(f); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Magasin : %s refusé' % f)
    who('magasinier'); pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(400)
    # ---- Profil opérateur : ouverture depuis l'espace
    pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].find(b=>/profil opérateur/.test(b.textContent)).click()"); pg.wait_for_timeout(500)
    t(pg.locator('#op_ov').count() == 1, 'Profil opérateur : la fiche s\'ouvre depuis le menu de l\'espace')
    pg.fill('#op_nom', 'Ndaye Mbuyi Alice'); pg.fill('#op_mat', 'MAG-014'); pg.fill('#op_tel', '+243 810 000 111'); pg.fill('#op_lieu', 'Dépôt central')
    pg.select_option('#op_stamp', 'auto')
    # signature dessinée
    box = pg.locator('#op_pad').bounding_box()
    pg.mouse.move(box['x'] + 30, box['y'] + 80); pg.mouse.down(); pg.mouse.move(box['x'] + 120, box['y'] + 30, steps=8); pg.mouse.move(box['x'] + 220, box['y'] + 90, steps=8); pg.mouse.up()
    pg.wait_for_timeout(200)
    t('Ndaye Mbuyi Alice' in pg.inner_text('#op_prev') and 'Mat. MAG-014' in pg.inner_text('#op_prev'), 'Profil opérateur : aperçu « Établi par » avec nom et matricule')
    pg.check('#op_rempl')
    pg.click('#op_save'); pg.wait_for_timeout(900)
    t(pg.locator('#op_ov').count() == 0, 'Profil opérateur : fenêtre fermée après enregistrement')
    P = pg.evaluate("EXBOperateur.get()")
    t(P.get('nom') == 'Ndaye Mbuyi Alice' and P.get('matricule') == 'MAG-014' and P.get('lieu') == 'Dépôt central', 'Profil opérateur : identité enregistrée')
    t(str(P.get('sig', '')).startswith('data:image/png'), 'Profil opérateur : signature dessinée enregistrée (PNG)')
    t(str(P.get('stampPng', '')).startswith('data:image/png'), 'Profil opérateur : sceau automatique généré (PNG)')
    t(str(P.get('visa', '')).startswith('data:image/png'), 'Profil opérateur : visa composé (signature + sceau)')
    t(pg.evaluate("EXBOperateur.remplace()") is True, 'Profil opérateur : option « à la place du visa du Directeur » active')
    line = pg.evaluate("EXBOperateur.line()")
    t(line.startswith('Établi par : Ndaye Mbuyi Alice') and 'MAG-014' in line and 'Dépôt central' in line and 'magasinier' in line, 'Profil opérateur : ligne « Établi par » (nom, fonction, matricule, lieu) : ' + line)
    t('data-exb-operateur' in pg.evaluate("EXBOperateur.blockHtml()"), 'Profil opérateur : bloc HTML « Établi par » pour les rapports')
    # ---- sortie dans un rapport (état du stock)
    html = pg.evaluate("(function(){var r=EXBRapport&&EXBRapport.build?EXBRapport.build('Essai',{html:'<p>x</p>'}):'';return r})()")
    t('Établi par' in html and 'Ndaye Mbuyi Alice' in html and 'Signature et sceau' in html, 'Rapport : « Établi par », signature et sceau présents')
    # ---- sortie dans le PDF généré (EXBPdf)
    res = pg.evaluate("""async()=>{const b=await EXBPdf.make({titre:'BON DE SORTIE',sousTitre:'Essai',rows:[['Article','Ciment'],['Quantité','20']],sigLabels:['Le bénéficiaire','Le Directeur Général'],signBlock:true});
      const buf=new Uint8Array(await b.arrayBuffer());let s='';for(let i=0;i<buf.length;i++)s+=String.fromCharCode(buf[i]);
      return {size:buf.length,head:s.slice(0,5),opline:s.indexOf('Etabli par')>=0||s.indexOf('\\\\311tabli par')>=0||s.indexOf('tabli par')>=0,nom:s.indexOf('Ndaye Mbuyi Alice')>=0,label:s.indexOf('magasinier')>=0}}""")
    t(res['head'] == '%PDF-' and res['size'] > 2000, 'PDF : généré (%d octets)' % res['size'])
    t(res['opline'] and res['nom'], 'PDF : pied « Établi par » avec le nom de l\'opérateur')
    t(res['label'], 'PDF : libellé de signature = fonction de l\'opérateur (au lieu du Directeur Général)')
    # ---- sans option : le visa du Directeur reste
    pg.evaluate("(function(){var p=EXBOperateur.get();p.remplace=false;var o=JSON.parse(localStorage.getItem('EXB_OPERATEUR_V1'));o[EXBOperateur.account()]=p;localStorage.setItem('EXB_OPERATEUR_V1',JSON.stringify(o))})()")
    # V205r : un compte non administrateur signe TOUJOURS avec son propre profil (la case n'est plus nécessaire) ; l'administrateur garde le visa du Directeur
    t(pg.evaluate("EXBOperateur.remplace()") is True, 'V205r : compte non administrateur : sa signature est utilisée même case décochée')
    who('administrateur', 'admin')
    t(pg.evaluate("EXBOperateur.remplace()") is False, 'Administrateur, option décochée : le visa du Directeur reste utilisé')
    who('magasinier')
    # ---- un autre compte n'hérite pas du profil
    pg.evaluate("window.EXB_ACCT={id:'autre@exemple.com'}")
    t(pg.evaluate("EXBOperateur.get().nom||''") == '' and pg.evaluate("EXBOperateur.line()") == '', 'Compte différent : aucun profil hérité, aucune ligne « Établi par »')
    pg.evaluate("window.EXB_ACCT=null")
    # ---- effacer
    pg.evaluate("EXBOperateur.clear()")
    t(pg.evaluate("EXBOperateur.line()") == '' and pg.evaluate("EXBOperateur.blockHtml()") == '', 'Profil effacé : plus rien dans les documents')
    # ---- autres espaces : bouton présent partout
    for url, k in [('chantier.html', 'chantier'), ('comptable.html', 'comptable'), ('administration.html', 'administration'), ('direction.html', 'direction')]:
        boot(url); t('Mon profil opérateur' in menu(), '%s : bouton « Mon profil opérateur » dans le menu' % k)
    # ---- menu du profil de l'application principale
    boot('index.html'); pg.wait_for_timeout(1500)
    t('Mon profil opérateur' in (pg.evaluate("(document.getElementById('xbMenu')||{}).textContent||''")), 'Application complète : « Mon profil opérateur » dans le menu du profil')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
