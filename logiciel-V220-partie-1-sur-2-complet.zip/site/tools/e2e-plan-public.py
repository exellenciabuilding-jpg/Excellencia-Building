# Test navigateur du portail public plan.html (serveur simulé) : QR, saisie, mauvais code, injection, démo, mobile.
import json, os, threading, http.server, functools, re
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8793),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
ORG='11111111-2222-3333-4444-555555555555'; TOK='a'*32
DOSSIER={'ref':'EXB-2026-001','titre':'Immeuble R+3','date':'2026-11-08','type_doc':'Plans architecturaux – RDC','maitre_oeuvre':'Excellencia Building','maitre_ouvrage':'Client Officiel','concepteur':'Service Technique','echelle':'1/100','indice':'Indice A · Feuille 01/01','apercu':PNG,
 'docs':[{'nom':'Plan – RDC','fichier':f'{ORG}/{TOK}/plan.pdf','format':'PDF','taille':'2,3 Mo','kind':'plan'},{'nom':'Fiche descriptive','fichier':f'{ORG}/{TOK}/fiche.pdf','format':'PDF','taille':'0,2 Mo','kind':'fiche'},{'nom':'Piégé','fichier':'../../etc/passwd','format':'PDF','taille':'','kind':'plan'}]}
calls=[]
def rpc(route):
    body=json.loads(route.request.post_data or '{}'); calls.append(body)
    ok = body.get('p_ref')=='EXB-2026-001' and body.get('p_code')=='A1B2C3D4E5'
    route.fulfill(status=200,content_type='application/json',body=json.dumps(DOSSIER if ok else None))
def pdf(route): route.fulfill(status=200,headers={'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="plan.pdf"','Access-Control-Allow-Origin':'*'},body=b'%PDF-1.4\n%%EOF')
def newpage(b,w=1200):
    pg=b.new_page(viewport={'width':w,'height':900},accept_downloads=True); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"sb_publishable_test"}'))
    pg.route('http://x.test/rest/v1/rpc/plan_public_get',rpc); pg.route('http://x.test/storage/**',pdf)
    return pg,errs
T=lambda pg,i:pg.inner_text(i)
res=[]
def check(nom,cond,info=''): res.append(bool(cond)); print(('OK   ' if cond else 'ÉCHEC'),nom,info)
with sync_playwright() as p:
    b=p.chromium.launch()
    # 1) QR valide
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8793/plan.html?ref=EXB-2026-001&k=A1B2C-3D4E5'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('QR valide : titre et détails',T(pg,'#title')=='Immeuble R+3' and T(pg,'#ref')=='EXB-2026-001' and T(pg,'#date')=='08/11/2026' and T(pg,'#client')=='Client Officiel' and T(pg,'#scale')=='1/100')
    check('aperçu image affiché',pg.locator('#preview img').count()==1)
    check('2 documents (le chemin piégé est ignoré)',pg.locator('#docList .dlbig').count()==2)
    check('statut succès',T(pg,'#status').startswith('✓') and 'trouvé avec succès' in T(pg,'#status'))
    with pg.expect_download(timeout=8000) as dl: pg.click('#docList .dlbig:first-child')
    check('téléchargement du plan',dl.value.suggested_filename.endswith('.pdf'),dl.value.suggested_filename)
    check('code envoyé normalisé au serveur',calls[-1]=={'p_ref':'EXB-2026-001','p_code':'A1B2C3D4E5'},str(calls[-1]))
    check('aucun scanner caméra pour les clients',pg.locator('video,#reader,[data-scan]').count()==0 and 'getUserMedia' not in pg.content())
    check('pas d\'erreur JS',not errs,str(errs[:2])); pg.close()
    # 2) mauvais code
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8793/plan.html?ref=EXB-2026-001&k=ZZZZZZZZZZ'); pg.wait_for_selector('#empty:not([hidden])',timeout=8000)
    check('mauvais code : dossier introuvable, rien d\'affiché',pg.locator('#projectCard').is_hidden() and 'introuvable' in T(pg,'#status').lower()); pg.close()
    # 3) injection par l'adresse
    pg,errs=newpage(b); pg.on('dialog',lambda d:(res.append(False),print('ÉCHEC alerte déclenchée'),d.dismiss()))
    exbui_auto(pg)
    pg.goto('http://127.0.0.1:8793/plan.html?ref='+'%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E'+'&k=A1B2C3D4E5'); pg.wait_for_timeout(1500)
    check('injection HTML neutralisée',pg.locator('#status img, main img[src="x"]').count()==0); pg.close()
    # 4) saisie manuelle
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8793/plan.html'); pg.wait_for_timeout(600)
    check('sans paramètre : invitation neutre',T(pg,'#status').startswith('i') and pg.locator('#projectCard').is_hidden())
    pg.fill('#inRef','exb-2026-001'); pg.fill('#inCode','a1b2c-3d4e5'); pg.click('#inBtn'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('saisie manuelle : référence + code',T(pg,'#title')=='Immeuble R+3' and 'k=A1B2C3D4E5' in pg.url,pg.url[-40:])
    pg.close()
    # 5) référence sans code
    pg,errs=newpage(b); pg.goto('http://127.0.0.1:8793/plan.html?ref=EXB-2026-001'); pg.wait_for_timeout(800)
    check('référence sans code : code d\'accès demandé',"Code d’accès requis" in T(pg,'#status') and pg.locator('#projectCard').is_hidden()); pg.close()
    # 6) démo + mobile
    pg,errs=newpage(b,390); pg.goto('http://127.0.0.1:8793/plan.html?demo=1&ref=EXB-2026-001&k=DEMO'); pg.wait_for_selector('#projectCard:not([hidden])',timeout=8000)
    check('mode démo (?demo=1)',T(pg,'#title').startswith('Projet'))
    check('mobile 390 px : pas de défilement horizontal',pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')); pg.close()
    b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
