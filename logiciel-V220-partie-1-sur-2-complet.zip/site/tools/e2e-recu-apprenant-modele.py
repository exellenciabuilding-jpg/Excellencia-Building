# V194 : reçu d'inscription / de formation au modèle « reçu de paiement des frais » + nom du guichetier (rendu Chromium, PDF 1 page A4 paysage)
import os, sys, re
from playwright.sync_api import sync_playwright
HERE = os.path.dirname(os.path.abspath(__file__)); SITE = os.path.dirname(HERE)
ok = 0; ko = 0
def chk(c, m):
    global ok, ko
    if c: ok += 1; print('  OK  ', m)
    else: ko += 1; print('  FAIL', m)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1200, 'height': 860})
    pg.set_content('<html><body></body></html>')
    pg.add_script_tag(path=SITE + '/exb-recu-tfl.js')
    res = pg.evaluate("""() => {
      const R = window.EXBRecuTFL;
      const full = R.depuisApprenant({no:'REC-0007', date:'2026-11-14', formation:'La Grande Formation sur Robot Structural Analysis', participant:'MUKENDI KALALA JEAN', matricule:'378-734-477', debut:'01/12/2026', lieu:'Salle 2, Kinshasa',
        distinction:'Certification Excellencia Building', inscription:{montant:'50 USD', statut:'PAYÉ'}, formation_frais:{montant:'200 USD', statut:'MOITIÉ PAYÉE'}, guichetier:'Marie Kabasele',
        url:'https://x.test/verification.html?c=r~REC-0007~2026-11-14~0~USD~ABCD123456'});
      const mini = R.depuisApprenant({no:'REC-0008', date:'2026-11-15', formation:'Initiation AutoCAD', participant:'A B', inscription:{montant:'30 USD', statut:'PAYÉ'}});
      return {full:R.html(full), mini:R.html(mini), fo:full, mo:mini};
    }""")
    h = res['full']
    chk('REÇU DE PAIEMENT DES FRAIS' in h and 'Marie Kabasele' in h and 'Frais de formation' in h and 'MOITIÉ PAYÉE' in res['full'], 'reçu complet : titre, nom du guichetier, frais d’inscription et de formation')
    chk(res['fo']['code'] == 'ABCD123456'[:10] and 'class="cd"' in h, 'code de vérification dérivé du lien de vérification (cases)')
    chk('Année Académique' not in h and 'Participant' in h, 'pas d’année académique pour une formation ; libellé « Participant »')
    chk('Frais de formation' not in res['mini'] and 'Frais d’inscription' in res['mini'] and 'Administration Excellencia Building' in res['mini'], 'reçu minimal : lignes absentes non affichées ; sans guichetier → « Administration Excellencia Building »')
    for nom, html in (('complet', h), ('minimal', res['mini'])):
        pg.set_content(html, wait_until='domcontentloaded'); pg.wait_for_timeout(300)
        pdf = pg.pdf(prefer_css_page_size=True, print_background=True)
        n = len(re.findall(rb'/Type\s*/Page[^s]', pdf))
        chk(n == 1, 'PDF %s : 1 page (%d)' % (nom, n))
        if nom == 'complet': pg.screenshot(path='/tmp/recu-apprenant.png')
    b.close()
print('\nRésultat : %d réussis, %d échec(s)' % (ok, ko)); sys.exit(1 if ko else 0)
