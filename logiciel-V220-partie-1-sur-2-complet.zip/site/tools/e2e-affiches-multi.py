# Test navigateur V186f : sélection multiple dans le Studio libre (Maj+clic, cadre, Ctrl+A, groupe).
# Lancer :  python3 tools/e2e-affiches-multi.py   (Chromium + Playwright)
import http.server, threading, functools, os
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8896), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
fails = []
def ok(c, m):
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails.append(m)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1300, 'height': 900}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:300]))
    pg.goto('http://127.0.0.1:8896/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("show('affiches')"); pg.wait_for_timeout(600); pg.click('#exbsT2'); pg.wait_for_timeout(400)
    pg.evaluate("EXB_STUDIO.applyTemplate(EXB_STUDIO.templates()[60])"); pg.wait_for_timeout(500)
    S = "EXB_STUDIO.state()"
    ids = pg.evaluate(S + ".els.filter(x=>x.t==='text').slice(0,3).map(x=>x.id)")
    n0 = pg.evaluate(S + ".els.length")
    ok(len(ids) == 3, 'le modèle contient au moins 3 textes')
    def down(id, shift=False):
        pg.evaluate("([id,sh])=>{const s=document.querySelector('#exbsStage');s.querySelector('[data-id=\"'+id+'\"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,shiftKey:sh}));s.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}))}", [id, shift]); pg.wait_for_timeout(200)
    def pos(id): return pg.evaluate("(id)=>{const e=" + S + ".els.find(x=>x.id===id);return [e.x,e.y]}", id)
    down(ids[0]); down(ids[1], True); down(ids[2], True)
    ok(pg.locator('#exbsProps').inner_text().startswith('3 éléments'), 'Maj+clic : 3 éléments sélectionnés, panneau « plusieurs éléments »')
    ok(pg.locator('#exbsStage [data-h]').count() == 0, 'pas de poignée de taille en sélection multiple')
    down(ids[1], True)
    ok(pg.locator('#exbsProps').inner_text().startswith('2 éléments'), 'Maj+clic sur un élément sélectionné : il est retiré')
    # déplacement du groupe aux flèches + annulation
    p0 = [pos(i) for i in ids]
    pg.evaluate("document.activeElement&&document.activeElement.blur()"); pg.keyboard.press('Shift+ArrowRight'); pg.wait_for_timeout(150)
    p1 = [pos(i) for i in ids]
    ok(p1[0][0] == p0[0][0] + 20 and p1[2][0] == p0[2][0] + 20 and p1[1] == p0[1], 'flèches : seul le groupe sélectionné bouge')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(150)
    ok([pos(i) for i in ids] == p0, 'Ctrl+Z annule le déplacement du groupe')
    # Ctrl+A, aligner à gauche
    pg.keyboard.press('Control+a'); pg.wait_for_timeout(200)
    ok(pg.locator('#exbsProps').inner_text().startswith('%d éléments' % n0), 'Ctrl+A sélectionne tous les éléments')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
    down(ids[0]); down(ids[2], True)
    pg.click('#exbsProps [data-m="L"]'); pg.wait_for_timeout(200)
    ok(pos(ids[0])[0] == pos(ids[2])[0], 'Aligner à gauche')
    pg.click('#exbsProps [data-m="DE"]'); pg.wait_for_timeout(200)
    ok(pg.evaluate(S + ".els.length") == n0 - 2, 'Supprimer : le groupe entier est supprimé')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    ok(pg.evaluate(S + ".els.length") == n0, 'Ctrl+Z ramène le groupe')
    # copier / coller de groupe
    ids = pg.evaluate(S + ".els.filter(x=>x.t==='text').slice(0,2).map(x=>x.id)"); down(ids[0]); down(ids[1], True)
    pg.evaluate("document.dispatchEvent(new ClipboardEvent('copy',{bubbles:true,cancelable:true,clipboardData:new DataTransfer()}))")
    pg.evaluate("document.dispatchEvent(new ClipboardEvent('paste',{bubbles:true,cancelable:true,clipboardData:new DataTransfer()}))"); pg.wait_for_timeout(200)
    ok(pg.evaluate(S + ".els.length") == n0 + 2, 'copier / coller un groupe : 2 copies décalées')
    ok(pg.locator('#exbsProps').inner_text().startswith('2 éléments'), 'les copies sont sélectionnées ensemble')
    # cadre de sélection sur le fond
    pg.keyboard.press('Escape'); pg.wait_for_timeout(100)
    bx = pg.locator('#exbsStage').bounding_box()
    pg.mouse.move(bx['x'] + 2, bx['y'] + 2); pg.mouse.down(); pg.mouse.move(bx['x'] + bx['width'] - 2, bx['y'] + bx['height'] - 2, steps=6); pg.mouse.up(); pg.wait_for_timeout(250)
    ok(pg.evaluate("document.querySelector('#exbsMq')") is None, 'le cadre disparaît à la fin')
    ok(pg.locator('#exbsProps').inner_text().split(' ')[0].isdigit() and int(pg.locator('#exbsProps').inner_text().split(' ')[0]) >= 2, 'cadre de sélection tracé sur le fond : plusieurs éléments pris')
    ok(not errs, 'aucune erreur JavaScript' + (' : ' + errs[0] if errs else ''))
    b.close()
print('\n%s' % ('TOUT EST OK' if not fails else '%d ÉCHEC(S)' % len(fails)))
raise SystemExit(1 if fails else 0)
