# V205 lot 5b — paiement déclaré par l'apprenant → comptable → reçu → liste « payé / pas payé » de la Formation
import http.server, threading, functools, os, sys, json
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    boot('comptable.html')
    # apprenant local + paiement déclaré simulé côté serveur
    pg.evaluate("""()=>{ participants.splice(0,participants.length,{participant_id:'P1',name:'Marie Test',phone:'+243900111222',training:'AutoCAD',matricule:'EXB-001',approval_status:'APPROUVE'});
      window.__calls=[]; window.__decl=[{id:7,type:'apprenant',nom:'Marie Test',telephone:'+243900111222',matricule:'EXB-001',montant:50,devise:'USD',reseau:'M-Pesa',numero_payeur:'+243900111222',reference:'MP123456',statut:'a_verifier',doublon:false,created_at:new Date().toISOString()}];
      window.exbSb={isIn:()=>true,api:async(u,o)=>{window.__calls.push({u:u,m:(o&&o.method)||'GET',b:(o&&o.body)||''});if(/paiements_declares\\?type/.test(u))return window.__decl.filter(x=>x.statut==='a_verifier');return []}};
      window.__prep=[]; const op=window.prepareReceiptFromParticipant; window.prepareReceiptFromParticipant=function(p){window.__prep.push(p.name);return op.apply(this,arguments)}; }""")
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(900)
    t(pg.evaluate("!!document.getElementById('exbDeclCard')"), 'le comptable voit « Paiements déclarés par les apprenants » dans Reçus de paiement')
    txt = pg.evaluate("document.getElementById('exbDeclList').innerText")
    t('Marie Test' in txt and 'MP123456' in txt and '50' in txt, 'la déclaration (nom, montant, référence) est visible')
    pg.click('#exbDeclList button[data-dact="confirme"]'); pg.wait_for_timeout(700)
    calls = pg.evaluate("window.__calls")
    t(any(c['m'] == 'PATCH' and 'confirme' in c['b'] and 'id=eq.7' in c['u'] for c in calls), 'Confirmer enregistre le statut « confirmé » côté serveur')
    t(pg.evaluate("window.__prep") == ['Marie Test'], 'le reçu est préparé pour l\'apprenant (formulaire des reçus)')
    t(pg.evaluate("document.getElementById('participant').value") == 'Marie Test', 'le formulaire de reçu est pré-rempli')
    # reçu enregistré -> la liste Formation indique « payé »
    pg.evaluate("receipts.push({receipt_no:'REC-1',participant:'Marie Test',matricule:'EXB-001',training:'AutoCAD',created_at:new Date().toISOString(),registration_status:'PAYÉ',training_status:'PAYÉ'})")
    st = pg.evaluate("JSON.stringify(exbPayTrack.status(participants[0]))")
    t('"insc":true' in st and '"form":"total"' in st, 'après le reçu, la liste Formation donne Marie « payée » (%s)' % st)
    pg.evaluate("participants.push({participant_id:'P2',name:'Paul Sans',phone:'+243900333444',training:'AutoCAD',matricule:'EXB-002',approval_status:'APPROUVE'})")
    st2 = pg.evaluate("JSON.stringify(exbPayTrack.status(participants[1]))")
    t('"insc":false' in st2 and '"form":"non_paye"' in st2, 'un apprenant sans reçu reste « pas encore payé »')
    # rejet
    pg.evaluate("window.__decl.push({id:8,type:'apprenant',nom:'Paul Sans',telephone:'+243900333444',montant:10,devise:'USD',reference:'ZZZ999',statut:'a_verifier',created_at:new Date().toISOString()})")
    pg.evaluate("exbDeclPaiements.load()"); pg.wait_for_timeout(500)
    pg.click('#exbDeclList [data-id="8"] button[data-dact="rejete"]'); pg.wait_for_timeout(600)
    t(any(c['m'] == 'PATCH' and 'rejete' in c['b'] and 'id=eq.8' in c['u'] for c in pg.evaluate("window.__calls")), 'Rejeter enregistre le statut « rejeté »')
    # dans l'Espace Formation : pas de carte reçus, mais la liste payé / pas payé existe
    pg.evaluate("localStorage.setItem('exb_espace','formation')"); boot('index.html')
    pg.evaluate("show('participants')"); pg.wait_for_timeout(600)
    t(pg.evaluate("!!document.getElementById('exbPayBar')"), 'l\'Espace Formation garde l\'onglet « Paiements (qui a payé ?) » des apprenants')
    t(pg.evaluate("document.getElementById('receipts').style.display") == 'none', 'l\'Espace Formation n\'ouvre pas les reçus')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
