#!/bin/bash
# V205 lot 5b — teste migration-v205-lot5b-paiements-comptable.sql sur un PostgreSQL local (schéma Supabase simulé).
# Usage : bash tools/test-sql-lot5b.sh   (PostgreSQL 16, utilisateur « postgres »)
set -u
HERE="$(cd "$(dirname "$0")/.." && pwd)"; PGBIN=/usr/lib/postgresql/16/bin
D=$(mktemp -d /tmp/pgx.XXXXXX); chown postgres "$D"; PORT=54$((RANDOM%900+100))
run(){ su postgres -c "$*"; }
run "$PGBIN/initdb -D $D/data -A trust >/dev/null" || exit 2
run "$PGBIN/pg_ctl -D $D/data -o '-p $PORT -k $D' -l $D/log -w start >/dev/null" || { cat $D/log; exit 2; }
P="psql -h $D -p $PORT -U postgres -v ON_ERROR_STOP=1 -q -X"
trap 'run "$PGBIN/pg_ctl -D $D/data -m immediate stop >/dev/null"; rm -rf $D' EXIT
cat > $D/stub.sql <<'SQL'
create role anon nologin; create role authenticated nologin; create role service_role nologin;
create schema auth; grant usage on schema auth to anon, authenticated, service_role;
create table auth.users(id uuid primary key, email text);
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
create function auth.jwt() returns jsonb language sql stable as $$ select coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb,'{}'::jsonb) $$;
grant execute on function auth.uid(), auth.jwt() to anon, authenticated, service_role;
grant usage on schema public to anon, authenticated, service_role;
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
create table membres(org_id uuid, user_id uuid, nom text, role text, fonction text default 'polyvalent');
SQL
su postgres -c "$P -f $D/stub.sql" || exit 2
cp $HERE/supabase/migration-v99g-paiements.sql $HERE/supabase/migration-v205-lot5b-paiements-comptable.sql $D/ && chmod -R a+rX $D; su postgres -c "$P -f $D/migration-v99g-paiements.sql" || exit 2
su postgres -c "$P -f $D/migration-v205-lot5b-paiements-comptable.sql" || exit 2
su postgres -c "$P -f $D/migration-v205-lot5b-paiements-comptable.sql" || { echo "FAIL réexécution"; exit 1; }
ok=0; fail=0
t(){ if [ "$2" = "$3" ]; then ok=$((ok+1)); echo "OK   $1"; else fail=$((fail+1)); echo "FAIL $1 (attendu $3, obtenu $2)"; fi; }
O=00000000-0000-0000-0000-0000000000a0
U_C=00000000-0000-0000-0000-0000000000c1; U_F=00000000-0000-0000-0000-0000000000f1; U_A=00000000-0000-0000-0000-0000000000a1; U_D=00000000-0000-0000-0000-0000000000d1
su postgres -c "$P -c \"insert into membres values ('$O','$U_C','C','editeur','comptable'),('$O','$U_F','F','editeur','formateur'),('$O','$U_A','A','admin','polyvalent'),('$O','$U_D','D','editeur','direction');
 insert into paiements_declares(type,nom,telephone,montant,reference) values ('apprenant','Apprenant','+243900000000',50,'REF123');\""
as(){ su postgres -c "$P -t -A -c \"set role authenticated; select set_config('request.jwt.claim.sub','$1',false); select set_config('request.jwt.claims','{\\\"email\\\":\\\"$2\\\"}',false); $3\"" 2>&1 | tail -1; }
t "comptable lit les paiements déclarés"   "$(as $U_C c@x.com 'select count(*) from paiements_declares')" 1
t "direction lit les paiements déclarés"   "$(as $U_D d@x.com 'select count(*) from paiements_declares')" 1
t "administrateur lit les paiements déclarés" "$(as $U_A a@x.com 'select count(*) from paiements_declares')" 1
t "formateur NE lit PAS les paiements"     "$(as $U_F f@x.com 'select count(*) from paiements_declares')" 0
t "e-mail administrateur d'origine conservé" "$(as 00000000-0000-0000-0000-0000000000e9 excellenciabuilding@gmail.com 'select count(*) from paiements_declares')" 1
t "comptable confirme un paiement"          "$(as $U_C c@x.com "with u as (update paiements_declares set statut='confirme' where id=1 returning 1) select count(*) from u")" 1
t "formateur NE peut PAS modifier"          "$(as $U_F f@x.com "with u as (update paiements_declares set statut='rejete' where id=1 returning 1) select count(*) from u")" 0
t "anonyme NE lit PAS (déclarer seulement)" "$(su postgres -c "$P -t -A -c \"set role anon; select count(*) from paiements_declares\"" 2>&1 | tail -1 | grep -c 'permission\|^0$')" 1
echo "Résultat : $ok OK, $fail échec(s)"; [ $fail -eq 0 ]
