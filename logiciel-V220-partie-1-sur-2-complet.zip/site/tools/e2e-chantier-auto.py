#!/usr/bin/env python3
"""V204 — Passation : une demande reçue crée fiche client + chantier, une seule fois, et ils RESTENT dans le logiciel
après déconnexion du compte serveur et rechargement de la page (comme les apprenants). Serveur Supabase simulé."""
import http.server, threading, socketserver, os, functools, sys, json
from playwright.sync_api import sync_playwright
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from _exbui import exbui_auto
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
STATE={'traitees':[]}
ROW={'id':'d1','created_at':'2026-11-17T10:00:00Z','statut':'nouvelle','matricule':'BTP-2026-0015','data':{'name':'Jean Kabila','phone':'+243810000001','category':'Construction maison','location':'Lemba','budget':'50000 USD','services':['Plans']}}
def route(r):
    u=r.request.url; body='[]'
    if 'ma_licence' in u: body='{"admin":true}'
    elif 'demandes_projet_liste' in u: body=json.dumps([] if STATE['traitees'] else [ROW])
    elif 'demande_projet_traiter' in u: STATE['traitees'].append(1); body='null'
    r.fulfill(status=200,content_type='application/json',body=body)
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':1100,'height':900}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:160])); exbui_auto(a)
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.route('https://x.supabase.co/**',route)
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    a.evaluate("window.exbStorage.setItem('exb_sb',JSON.stringify({url:'https://x.supabase.co',key:'k'}));EXB_SB_SET=1")
    a.evaluate("exbSb.set({access_token:'t',refresh_token:'r',exp:Date.now()+3600000})")
    a.evaluate("EXB_INBOX.reload()"); a.wait_for_timeout(3500)
    n=a.evaluate("JSON.parse(window.exbStorage.getItem('exb_projects')||'[]')")
    c=a.evaluate("JSON.parse(window.exbStorage.getItem('exb_clients')||'[]')")
    ok(len(c)==1 and c[0]['full_name']=='Jean Kabila','fiche client créée automatiquement '+str([x.get('full_name') for x in c]))
    ok(len(n)==1 and n[0].get('req')=='BTP-2026-0015' and n[0]['client']=='Jean Kabila' and n[0]['budget']==50000,'chantier créé automatiquement et rattaché au client '+str([(x.get('name'),x.get('budget')) for x in n]))
    a.evaluate("EXB_INBOX.reload()"); a.wait_for_timeout(1500)
    ok(a.evaluate("JSON.parse(window.exbStorage.getItem('exb_projects')||'[]').length")==1,'pas de doublon au second rechargement')
    # déconnexion du compte serveur + rechargement de la page : le chantier reste
    a.evaluate("exbSb.set(null)"); a.reload(); a.wait_for_timeout(3000)
    n2=a.evaluate("JSON.parse(window.exbStorage.getItem('exb_projects')||'[]')"); c2=a.evaluate("JSON.parse(window.exbStorage.getItem('exb_clients')||'[]')")
    ok(len(n2)==1 and len(c2)==1,'hors connexion serveur, après rechargement : chantier et fiche client toujours là')
    ok(not ae,'aucune erreur JavaScript '+str(ae))
    b.close()
print('Résultat :', 'OK' if not fails else f'{fails} échec(s)'); sys.exit(1 if fails else 0)
