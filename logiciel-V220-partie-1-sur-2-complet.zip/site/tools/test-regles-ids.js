// Test des règles IDS (node tools/test-regles-ids.js) — fonctions pures sans DOM
var vm=require('vm'),fs=require('fs'),a=require('assert');
var w={document:{documentElement:null,getElementById:function(){return null}},addEventListener:function(){},console:console,setTimeout:setTimeout};w.window=w;w.globalThis=w;vm.createContext(w);
vm.runInContext(fs.readFileSync(__dirname+'/../exb-v209-ids.js','utf8'),w,{});
var X=w.EXBIDS,Q=[];function t(n,f){Q.push([n,f])}
var S=function(v){return{k:'simple',v:v}};
var els=[{id:'1',name:'M1',cls:'IfcWall',props:{Pset_WallCommon:{FireRating:'REI60',IsExternal:'T'}},mats:['Béton'],cl:[],level:'RDC'},
 {id:'2',name:'M2',cls:'IfcWall',props:{},mats:[],cl:[],level:''},
 {id:'3',name:'D1',cls:'IfcDoor',props:{},mats:[],cl:[],level:'RDC'}];
function spec(req,app,min){return{id:'s',name:'S',minOccurs:min==null?0:min,app:app||[{t:'entity',name:S('IFCWALL')}],req:req}}
t('matchValue : simple, nombre, énumération, motif, bornes',()=>{
 a.ok(X.matchValue(S('A'),'A'));a.ok(!X.matchValue(S('A'),'B'));a.ok(X.matchValue(S('2'),'2.0'));
 a.ok(X.matchValue({k:'enum',v:['A','B']},'B'));a.ok(!X.matchValue({k:'enum',v:['A']},'C'));
 a.ok(X.matchValue({k:'pattern',v:'REI\\d+'},'REI60'));a.ok(!X.matchValue({k:'pattern',v:'REI\\d+'},'EI30'));
 a.ok(X.matchValue({k:'bounds',minInclusive:1,maxExclusive:5},'1'));a.ok(!X.matchValue({k:'bounds',minInclusive:1,maxExclusive:5},'5'));a.ok(!X.matchValue({k:'bounds',minInclusive:1},'abc'))});
t('requis : un élément conforme, un non conforme avec motif',()=>{
 var r=X.verify(spec([{t:'property',card:'required',pset:S('Pset_WallCommon'),base:S('FireRating'),value:null}]),els);
 a.strictEqual(r.status,'non_conforme');a.strictEqual(r.n,2);a.strictEqual(r.pass,1);a.strictEqual(r.nfail,1);a.ok(/Manquant/.test(r.fails[0].why))});
t('tous conformes',()=>{var r=X.verify(spec([{t:'entity',card:'required',name:S('IFCWALL')}]),els);a.strictEqual(r.status,'conforme')});
t('interdit : présent à tort',()=>{var r=X.verify(spec([{t:'material',card:'prohibited',value:S('Béton')}]),els);a.strictEqual(r.status,'non_conforme');a.ok(/à tort/.test(r.fails[0].why))});
t('facultatif : jamais en échec',()=>{var r=X.verify(spec([{t:'material',card:'optional',value:S('Acier')}]),els);a.strictEqual(r.status,'conforme')});
t('niveau (partie de)',()=>{var r=X.verify(spec([{t:'partOf',card:'required',relation:'IfcRelContainedInSpatialStructure',entity:{name:S('IFCBUILDINGSTOREY')}}]),els);a.strictEqual(r.nfail,1)});
t('facette non lisible : non vérifiable, jamais conforme',()=>{var r=X.verify(spec([{t:'attribute',card:'required',name:S('Inconnu'),value:null}]),els.slice(0,1));a.strictEqual(r.status,'non_verifiable');a.ok(r.nv.length)});
t('aucun élément concerné : sans_element, ou non conforme si exigé',()=>{
 var ap=[{t:'entity',name:S('IFCBEAM')}];
 a.strictEqual(X.verify(spec([],ap,0),els).status,'sans_element');a.strictEqual(X.verify(spec([],ap,1),els).status,'non_conforme')});
t('verifyAll : synthèse par spécification',()=>{var R=X.verifyAll({specs:[spec([])]},els);a.strictEqual(R.examined,3);a.strictEqual(R.results.length,1)});
t('toXML : structure IDS 1.0 et échappement',()=>{var x=X.toXML({title:'A & <B>',specs:[spec([{t:'material',card:'required',value:S('a"b')}])]});a.ok(/<ids/.test(x)&&/specification/.test(x));a.ok(!/A & <B>/.test(x))});
t('parseXml : DOCTYPE/ENTITY refusés, fichier > 1 Mo refusé',()=>{
 a.throws(()=>X.parseXml('<!DOCTYPE x [<!ENTITY a "b">]><x/>'),/DOCTYPE/);a.throws(()=>X.parseXml('x'.repeat(1048577)),/volumineux/)});
t('elementsFromIFC : classe, nom, propriété, matériau, niveau',()=>{
 var ifc='DATA;\n#1=IFCBUILDINGSTOREY(\'g1\',$,\'RDC\',$,$,$,$,$,.ELEMENT.,0.);\n#2=IFCWALL(\'gw\',$,\'Mur A\',$,$,$,$,\'T1\',.STANDARD.);\n#3=IFCMATERIAL(\'Béton\');\n#4=IFCRELASSOCIATESMATERIAL(\'r\',$,$,$,(#2),#3);\n#5=IFCRELCONTAINEDINSPATIALSTRUCTURE(\'c\',$,$,$,(#2),#1);\nENDSEC;';
 var E=X.elementsFromIFC(ifc);E=E.elements||E;var m=E.filter(function(e){return /WALL/i.test(e.cls)})[0];a.ok(m,'mur lu');a.strictEqual(m.name,'Mur A');a.ok((m.mats||[]).indexOf('Béton')>=0);a.strictEqual(m.level,'RDC')});
t('csvText : injection de formule neutralisée',()=>{var c=X.csvText({date:'2026-11-22',examined:1,results:[{id:'s',name:'=CMD()',r:{status:'conforme',n:1,pass:1,nfail:0,fails:[],nv:[]}}]});a.ok(!/(^|;)=CMD/m.test(c))});
(async()=>{var ok=0;for(var q of Q){try{await q[1]();ok++}catch(e){console.log('ÉCHEC',q[0],'\n  ',e.message)}}console.log(ok+'/'+Q.length+' tests passés');process.exit(ok===Q.length?0:1)})();
