# Test navigateur du module « Publier aux clients » (logiciel central) avec serveur Supabase simulé.
import json, os, re, base64, threading, http.server, functools
from playwright.sync_api import sync_playwright
import sys as _s, os as _o; _s.path.insert(0,_o.path.dirname(_o.path.abspath(__file__)))
from _exbui import exbui_auto
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=D); H.log_message=lambda *a,**k:None
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8794),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
def mkpdf():
    o=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 400] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
    body=b'BT /F1 40 Tf 60 200 Td (PLAN ARC-01) Tj ET'; o.append(b'<< /Length %d >>\nstream\n'%len(body)+body+b'\nendstream')
    out=b'%PDF-1.4\n'; offs=[]
    for i,x in enumerate(o,1): offs.append(len(out)); out+=b'%d 0 obj\n'%i+x+b'\nendobj\n'
    xr=len(out); out+=b'xref\n0 %d\n0000000000 65535 f \n'%(len(o)+1)+b''.join(b'%010d 00000 n \n'%f for f in offs)
    return out+b'trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF'%(len(o)+1,xr)
PDF=base64.b64encode(mkpdf()).decode()
ORG='11111111-2222-3333-4444-555555555555'
res=[]
def check(nom,cond,info=''): res.append(bool(cond)); print(('OK   ' if cond else 'ÉCHEC'),nom,info)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':900,'height':900}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('dialog',lambda d:d.accept())
    exbui_auto(pg)
    pg.goto('http://127.0.0.1:8794/index.html'); pg.wait_for_timeout(2500)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')   # écran de licence du logiciel : hors sujet pour ce test
    pg.evaluate("""async(a)=>{
      window.__calls=[];
      window.EXBDB.org=()=>a.org; window.EXBDB.can=()=>true;
      window.exbSb.isIn=()=>true;
      window.exbSb.api=async(path,opt)=>{opt=opt||{};let body=opt.body;if(body instanceof Blob)body={blob:body.size+' octets',type:body.type};else if(typeof body==='string'){try{body=JSON.parse(body)}catch(e){}}
        window.__calls.push({path,method:opt.method||'GET',body});
        if(/rpc\\/plan_public_publier/.test(path))return{ok:true,ref:'EXB-2026-001',code:'A1B2C3D4E5',ancien_token:null};
        if(/rpc\\/plan_public_lister/.test(path))return[{ref:'EXB-2026-001',code:'A1B2C3D4E5',titre:'Immeuble R+3',ref_plan:'ARC-01',actif:true,maj_le:'2026-11-08T10:00:00Z',nb_docs:1}];
        if(/rpc\\/plan_public_retirer/.test(path))return{ok:true,token:'b'.repeat(32)};
        if(/object\\/list\\//.test(path))return[{name:'plan.pdf'}];
        return{}};
      window.confirm=()=>true;
      const bin=Uint8Array.from(atob(a.pdf),c=>c.charCodeAt(0));
      await new Promise((ok,ko)=>{const q=indexedDB.open('exb81',1);q.onupgradeneeded=()=>q.result.createObjectStore('blobs');q.onsuccess=()=>{const t=q.result.transaction('blobs','readwrite');t.objectStore('blobs').put(new Blob([bin],{type:'application/pdf'}),'pl1');t.oncomplete=ok;t.onerror=()=>ko(t.error)}});
      window.EXBS.set('exb_plan_files',[{id:'pl1',project:'p1',ref:'ARC-01',ver:'A',name:'plan.pdf',ext:'pdf',size:bin.length,date:'2026-11-08'}]);
      localStorage.setItem('exb_active_project','p1');
      window.EXBPLN.open();
    }""",{'org':ORG,'pdf':PDF})
    pg.wait_for_selector('#exbPln .exbPubBtn',timeout=8000)
    check('bouton 🌐 sur le plan PDF',pg.locator('#exbPln .exbPubBtn:has-text("🌐")').count()==1)
    check('bouton « Plans publiés aux clients »',pg.locator('#exbPln .exbPubTop').count()==1)
    pg.click('#exbPln .exbPubBtn'); pg.wait_for_selector('#pbGo',timeout=5000)
    marque=pg.evaluate("(window.EXB_BRAND&&window.EXB_BRAND.name)||'Excellencia Building'")   # édition « marque blanche » : le nom de l'entreprise est remplacé automatiquement
    check('formulaire prérempli',pg.input_value('#pbMoe') in ('Excellencia Building',marque) and pg.input_value('#pbConc')=='Service Technique' and pg.input_value('#pbInd')=='Indice A')
    pg.fill('#pbTitre','Immeuble R+3'); pg.fill('#pbMo','Client Officiel'); pg.fill('#pbEch','1/100')
    pg.click('#pbGo'); pg.wait_for_selector('#pbQr',timeout=20000)
    calls=pg.evaluate('window.__calls')
    up=[c for c in calls if '/storage/v1/object/exb-plans-publics/' in c['path']]
    check('plan envoyé dans <org>/<jeton 32 car.>/plan.pdf',len(up)==1 and re.fullmatch(r'/storage/v1/object/exb-plans-publics/'+ORG+r'/[a-f0-9]{32}/plan\.pdf',up[0]['path']),up[0]['path'][-50:] if up else '')
    rp=[c for c in calls if 'plan_public_publier' in c['path']][0]['body']
    check('appel serveur : titre, client, échelle',rp['p_titre']=='Immeuble R+3' and rp['p_mo']=='Client Officiel' and rp['p_echelle']=='1/100' and rp['p_org']==ORG and rp['p_ref'] is None)
    check('aperçu JPEG généré depuis la 1re page du PDF',str(rp['p_apercu']).startswith('data:image/jpeg;base64,') and len(rp['p_apercu'])>2000,str(len(rp['p_apercu'] or '')))
    check('le chemin du document correspond au jeton',rp['p_docs'][0]['fichier']==ORG+'/'+rp['p_token']+'/plan.pdf' and rp['p_docs'][0]['kind']=='plan')
    txt=pg.inner_text('#exbPub')
    check('résultat : référence + code formaté',('EXB-2026-001' in txt) and ('A1B2C-3D4E5' in txt))
    lk=pg.input_value('#pbLink'); check('lien du QR = /plan?ref=…&k=…',re.fullmatch(r'https?://[^ ]+/plan\?ref=EXB-2026-001&k=A1B2C3D4E5',lk) is not None,lk)
    check('QR image générée',pg.evaluate("document.getElementById('pbQr').src.startsWith('data:image/png')"))
    check('référence mémorisée pour republier avec le même QR',pg.evaluate("JSON.parse(localStorage.getItem('exb_pub_map')).pl1.ref")=='EXB-2026-001')
    # republication : même référence envoyée au serveur
    pg.evaluate("window.__calls.length=0;window.EXBPUB.open('pl1')"); pg.wait_for_selector('#pbGo'); pg.click('#pbGo'); pg.wait_for_selector('#pbQr',timeout=20000)
    rp2=[c for c in pg.evaluate('window.__calls') if 'plan_public_publier' in c['path']][0]['body']
    check('republication : même référence réutilisée (QR imprimé toujours valable)',rp2['p_ref']=='EXB-2026-001')
    # liste + retrait
    pg.evaluate("window.__calls.length=0;window.EXBPUB.list()"); pg.wait_for_selector('#exbPub table',timeout=5000)
    check('liste des plans publiés',('EXB-2026-001' in pg.inner_text('#exbPub')) and ('En ligne' in pg.inner_text('#exbPub')))
    pg.click('#exbPub button:has-text("Retirer")'); pg.wait_for_timeout(1500)
    names=[c['path'] for c in pg.evaluate('window.__calls')]
    check('retrait : fonction serveur + suppression des fichiers publics',any('plan_public_retirer' in n for n in names) and any('object/list/exb-plans-publics' in n for n in names) and any(n=='/storage/v1/object/exb-plans-publics' for n in names))
    check('pas d\'erreur JS',not errs,str(errs[:2])); b.close()
print('\nRésultat :',sum(res),'/',len(res)); raise SystemExit(0 if all(res) else 1)
