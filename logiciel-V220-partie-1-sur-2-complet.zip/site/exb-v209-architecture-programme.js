/* Excellencia Building V209e — ARCHITECTURE : programme architectural et tableau des surfaces.
 * Cahier des charges Évolution ERP V1.0, §5.2 : « Programme architectural » (P1), « Tableau des surfaces — surface utile, brute, circulation, emprise, ratios et
 * comparaison programme/projet » (P1), « Gestion des variantes » (P2, partie surfaces).
 *
 *  • LOCAUX (par projet) : nom, niveau, nature (utile / circulation / annexes et locaux techniques), nombre, surface unitaire CIBLE (programme du client),
 *    surface DESSINÉE (celle du plan, saisie ou reportée à la main). Cible de la ligne = surface unitaire × nombre.
 *  • CADRE (par projet) : superficie du terrain, emprise projetée, pays, commune (utilisés par V209f pour choisir les modèles de règles), budget indicatif, tolérance d’écart (%).
 *  • CALCULS : surface utile, circulation, annexes, brute = somme (dessinée si renseignée, sinon cible) ; rendement = utile / brute ; part de circulation ;
 *    CES = emprise / terrain ; COS = surface de plancher / terrain ; écart programme/projet par local et au total. Aucun seuil réglementaire n’est préenregistré (voir V209f).
 *    Emprise non saisie : ESTIMÉE par la somme des locaux du niveau rez-de-chaussée, et signalée comme telle (jamais présentée comme une valeur saisie).
 *  • VARIANTES (comparaison, SANS recommandation) : instantané du programme courant (surface, rendement, CES, COS) + coût saisi à la main ; une seule variante « retenue ».
 *  • Import / export CSV (compatible avec le CSV de l’IA Architecte), impression du tableau des surfaces.
 *  Stockage : exb_arch_prog (collection serveur « arch_programme », migration-v209e-programme.sql). Aucune donnée existante touchée.
 *  Lu par : Matériaux & finitions (EXBARCP.calc), Analyse de site (report de la superficie), IA Architecte, Contrôle réglementaire (V209f).
 *  Les fonctions pures (calc, parseCsv, snapshot) sont testées dans tools/test-programme.js. */
(function (w, d) {
  'use strict';
  var KEY = 'exb_arch_prog', COL = 'arch_programme';
  var NAT = [['utile', 'Surface utile'], ['circulation', 'Circulation'], ['annexe', 'Annexes / locaux techniques']];
  var st = { pid: '', tab: 'locaux' };

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function hasNum(v) { return v !== '' && v != null && !isNaN(Number(String(v).replace(',', '.'))); }
  function num(v, def) { return hasNum(v) ? Number(String(v).replace(',', '.')) : (def === undefined ? 0 : def); }
  function fm(n, dg) { return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: dg == null ? 1 : dg }).format(n || 0); }
  function s(v, n) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n); }
  function r2(n) { return Math.round(n * 100) / 100; }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); } catch (e) { } }
  function canR() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'lire'); } catch (e) { return true; } }
  function canW() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'ecrire'); } catch (e) { return true; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function projs() { try { return w.EXBS.projects() || []; } catch (e) { return []; } }
  function load() { try { return w.EXBS.get(KEY) || []; } catch (e) { return []; } }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction)) || ''; } catch (e) { return ''; } }
  function lab(L, k) { for (var i = 0; i < L.length; i++) if (L[i][0] === k) return L[i][1]; return k || ''; }
  function norm(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); }
  function csvCell(c) { c = String(c == null ? '' : c); if (/^[=+\-@\t\r]/.test(c)) c = "'" + c; return '"' + c.replace(/"/g, '""') + '"'; }

  /* ================= CALCUL (pur) =================
   * items : lignes exb_arch_prog DU PROJET (types 'cadre', 'local', 'variante'). mode : réservé ('base'). */
  function calc(items, mode) {
    items = items || [];
    var cadre = items.filter(function (x) { return x.type === 'cadre'; })[0] || {};
    var tol = hasNum(cadre.tol) && num(cadre.tol) >= 0 ? num(cadre.tol) : 5;
    var defDefaut = !String(cadre.plancher_nat || '').trim();
    var incl = (defDefaut ? 'utile,circulation,annexe' : String(cadre.plancher_nat)).split(',').map(norm), excl = String(cadre.plancher_excl || '').split(/[;,]/).map(norm).filter(Boolean);
    var rows = [], tot = { cible: 0, proj: 0, brut: 0, plancher: 0, utile: 0, circulation: 0, annexe: 0 }, al = [], seen = {};
    items.filter(function (x) { return x.type === 'local'; }).forEach(function (x) {
      var nb = hasNum(x.nb) && num(x.nb) > 0 ? num(x.nb) : 1;
      var cible = hasNum(x.surf) ? num(x.surf) * nb : (hasNum(x.cible) ? num(x.cible) : 0);
      var proj = hasNum(x.proj) ? num(x.proj) : null;
      var nature = NAT.some(function (n) { return n[0] === x.nature; }) ? x.nature : 'utile';
      var eff = proj !== null ? proj : cible, ecart = proj !== null ? proj - cible : null, pct = ecart !== null && cible > 0 ? ecart / cible * 100 : null;
      var etat = proj === null ? 'non_dessine' : cible <= 0 ? 'sans_cible' : Math.abs(pct) > tol ? 'ecart' : 'ok';
      var pl = incl.indexOf(nature) >= 0 && !excl.some(function (m) { return norm(x.niveau).indexOf(m) >= 0; }) ? eff : 0;
      rows.push({ id: x.id, nom: s(x.nom, 120), niveau: s(x.niveau, 40), nature: nature, nb: nb, surf: hasNum(x.surf) ? num(x.surf) : null, cible: cible, proj: proj, eff: eff, plancher: pl, ecart: ecart, pct: pct, etat: etat });
      tot.cible += cible; if (proj !== null) tot.proj += proj; tot.brut += eff; tot.plancher += pl; tot[nature] += eff;
      if (cible <= 0) al.push('« ' + (x.nom || 'local sans nom') + ' » : surface cible nulle ou absente.');
      var k = norm(x.nom) + '|' + norm(x.niveau); if (x.nom && seen[k]) al.push('« ' + x.nom + ' » apparaît plusieurs fois au même niveau (doublon ?).'); seen[k] = 1;
      if (etat === 'ecart') al.push('« ' + x.nom + ' » : écart de ' + fm(pct, 1) + ' % entre le plan et le programme (tolérance ' + fm(tol, 1) + ' %).');
    });
    var terrain = hasNum(cadre.terrain) && num(cadre.terrain) > 0 ? num(cadre.terrain) : null;
    var empSaisie = hasNum(cadre.emprise) && num(cadre.emprise) > 0, emprise = null, estimee = false;
    if (empSaisie) emprise = num(cadre.emprise);
    else { var nm = norm(cadre.niv_emprise), rdc = rows.filter(function (r) { return nm ? norm(r.niveau).indexOf(nm) === 0 : /^(rdc|rez|niveau 0|0$|sol)/.test(norm(r.niveau)); }); if (rdc.length) { emprise = rdc.reduce(function (a, r) { return a + r.eff; }, 0); estimee = true; } }
    var C = {
      rows: rows, cadre: cadre, tol: tol, tot: tot, terrain: terrain, emprise: emprise, empriseEstimee: estimee,
      rendement: tot.brut > 0 ? tot.utile / tot.brut : null, circPct: tot.brut > 0 ? tot.circulation / tot.brut * 100 : null,
      ces: terrain && emprise != null ? emprise / terrain : null, cos: terrain && tot.plancher > 0 ? tot.plancher / terrain : null, defDefaut: defDefaut,
      ecartTotal: tot.proj > 0 ? { proj: tot.proj, cible: rows.filter(function (r) { return r.proj !== null; }).reduce(function (a, r) { return a + r.cible; }, 0) } : null,
      nbDessines: rows.filter(function (r) { return r.proj !== null; }).length, alertes: al
    };
    if (!rows.length) al.push('Aucun local dans le programme.');
    if (!terrain) al.push('Superficie du terrain non renseignée : CES et COS non calculables.');
    if (defDefaut && rows.length) al.push('Définition de la surface de plancher (COS) non choisie : par défaut toutes les natures et tous les niveaux sont comptés. À confirmer avec la réglementation locale.');
    if (estimee) al.push('Emprise non saisie : estimée d’après les locaux du rez-de-chaussée (' + fm(emprise) + ' m²). Saisir l’emprise projetée.');
    if (terrain && emprise != null && emprise > terrain) al.push('Emprise supérieure à la superficie du terrain.');
    if (hasNum(cadre.budget) && num(cadre.budget) > 0 && tot.brut > 0) C.coutM2 = num(cadre.budget) / tot.brut;
    return C;
  }

  /* Instantané du programme courant pour une variante (pur). */
  function snapshot(C, nom) {
    return { nom: s(nom, 120) || 'Variante', surface: r2(C.tot.brut), rendement: C.rendement == null ? '' : Math.round(C.rendement * 1000) / 1000,
      ces: C.ces == null ? '' : Math.round(C.ces * 1000) / 1000, cos: C.cos == null ? '' : Math.round(C.cos * 1000) / 1000, cout: '' };
  }

  /* ================= IMPORT CSV (pur) =================
   * Colonnes reconnues (ordre libre) : Local/Nom, Niveau, Nature, Quantité/Nb, Surface unitaire (m2), Total (m2)/Surface cible. */
  function parseCsv(text) {
    var out = { items: [], erreurs: [] }, t = String(text || '').replace(/^\ufeff/, '');
    var lines = t.split(/\r?\n/).filter(function (l) { return l.trim() !== ''; });
    if (lines.length < 2) { out.erreurs.push('Fichier vide ou sans ligne de données.'); return out; }
    if (lines.length > 501) { out.erreurs.push('Plus de 500 lignes : import refusé.'); return out; }
    var sep = (lines[0].match(/;/g) || []).length >= (lines[0].match(/,/g) || []).length ? ';' : ',';
    function split(l) { var r = [], c = '', q = false; for (var i = 0; i < l.length; i++) { var ch = l[i]; if (q) { if (ch === '"') { if (l[i + 1] === '"') { c += '"'; i++; } else q = false; } else c += ch; } else if (ch === '"') q = true; else if (ch === sep) { r.push(c); c = ''; } else c += ch; } r.push(c); return r; }
    var H = split(lines[0]).map(norm), ix = {};
    H.forEach(function (h, i) {
      if (/^(local|nom|designation)/.test(h)) ix.nom = i; else if (/^niveau|^etage/.test(h)) ix.niveau = i; else if (/^nature|^type/.test(h)) ix.nature = i;
      else if (/^(quantite|nb|nombre)/.test(h)) ix.nb = i; else if (/unitaire/.test(h)) ix.surf = i; else if (/^(total|surface cible|cible)/.test(h)) ix.total = i;
    });
    if (ix.nom === undefined || (ix.surf === undefined && ix.total === undefined)) { out.erreurs.push('Colonnes attendues : Local, et Surface unitaire ou Total.'); return out; }
    for (var i = 1; i < lines.length; i++) {
      var c = split(lines[i]).map(function (v) { return v.replace(/^'(?=[=+\-@])/, '').trim(); }), ln = i + 1, nom = s(c[ix.nom], 120);
      if (!nom) { out.erreurs.push('Ligne ' + ln + ' : nom vide.'); continue; }
      var nb = ix.nb !== undefined && c[ix.nb] !== '' ? c[ix.nb] : 1, surf = ix.surf !== undefined ? c[ix.surf] : '', tot = ix.total !== undefined ? c[ix.total] : '';
      if (!hasNum(nb) || num(nb) <= 0) { out.erreurs.push('Ligne ' + ln + ' : quantité invalide.'); continue; }
      if (!hasNum(surf) && hasNum(tot)) surf = num(tot) / num(nb);
      if (!hasNum(surf) || num(surf) <= 0) { out.erreurs.push('Ligne ' + ln + ' : surface invalide ou absente.'); continue; }
      var nat = ix.nature !== undefined ? c[ix.nature] : '', natK = NAT.filter(function (n) { return n[0] === norm(nat) || norm(n[1]) === norm(nat); })[0];
      if (nat && !natK) out.erreurs.push('Ligne ' + ln + ' : nature « ' + nat + ' » inconnue → surface utile.');
      out.items.push({ nom: nom, niveau: s(ix.niveau !== undefined ? c[ix.niveau] : '', 40), nature: natK ? natK[0] : 'utile', nb: num(nb), surf: r2(num(surf)) });
    }
    return out;
  }
  function csvLocaux(C) {
    var rows = [['Local', 'Niveau', 'Nature', 'Quantité', 'Surface unitaire m2', 'Total m2', 'Surface dessinée m2', 'Écart m2', 'Écart %']].concat(C.rows.map(function (r) {
      return [r.nom, r.niveau, lab(NAT, r.nature), r.nb, r.surf == null ? '' : r.surf, r.cible, r.proj == null ? '' : r.proj, r.ecart == null ? '' : r2(r.ecart), r.pct == null ? '' : r2(r.pct)]; }));
    return '\ufeff' + rows.map(function (r) { return r.map(csvCell).join(';'); }).join('\r\n');
  }

  /* ================= INTERFACE ================= */
  var API = { calc: calc, snapshot: snapshot, parseCsv: parseCsv, csvLocaux: csvLocaux, open: open };
  function mine() { return load().filter(function (x) { return String(x.project) === String(st.pid); }); }
  function edit(fn) { if (!canW()) { say('Écriture non autorisée.', 'error'); return false; } var all = load(); if (fn(all) === false) return false; try { w.EXBS.set(KEY, all); } catch (e) { say('Enregistrement impossible.', 'error'); return false; } return true; }
  function cadreOf(a) { var c = a.filter(function (x) { return x.type === 'cadre' && String(x.project) === String(st.pid); })[0]; if (!c) { c = { id: uid('AC'), type: 'cadre', project: st.pid }; a.push(c); } return c; }
  function pname() { var n = ''; projs().forEach(function (p) { if (String(p.id) === String(st.pid)) n = p.nom || p.name || p.titre || p.title || ''; }); return n; }
  function box() { return d.getElementById('exbProgBox'); }
  var IN = 'style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"';
  function inp(f, id, v, t, extra) { return '<input ' + IN + ' data-f="' + f + '" data-i="' + esc(id) + '" value="' + esc(v == null ? '' : v) + '"' + (t === 'n' ? ' inputmode="decimal"' : '') + (canW() ? '' : ' disabled') + (extra || '') + '>'; }
  function kpi(t, v) { return '<div style="background:#f1f5f9;border-radius:10px;padding:8px 12px;min-width:120px"><div style="font-size:11px;color:#64748b">' + esc(t) + '</div><b>' + esc(v) + '</b></div>'; }
  var ETAT = { ok: ['✔ conforme au programme', '#166534'], ecart: ['⚠ écart', '#b45309'], non_dessine: ['— non dessiné', '#64748b'], sans_cible: ['⚠ sans cible', '#b45309'] };

  function paint() {
    var b = box(); if (!b) return; var C = calc(mine(), 'base'), W = canW(), h = '';
    var tabs = [['locaux', 'Locaux'], ['synthese', 'Synthèse & cadre'], ['variantes', 'Variantes']];
    h += '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><b style="align-self:center;margin-right:8px">📋 Programme & surfaces</b>' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:8px;background:' + (st.tab === t[0] ? '#0f766e;color:#fff' : '#e2e8f0') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>';
    h += '<p style="margin:4px 0">Projet : <select id="pgPid">' + projs().map(function (p) { return '<option value="' + esc(p.id) + '"' + (String(p.id) === String(st.pid) ? ' selected' : '') + '>' + esc(p.nom || p.name || p.titre || p.title || p.id) + '</option>'; }).join('') + '</select></p>';
    if (st.tab === 'locaux') {
      function lbl(t, x) { return '<label style="font-size:11px;color:#475569">' + t + x + '</label>'; }
      C.rows.forEach(function (r) {
        var e = ETAT[r.etat];
        h += '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin:6px 0"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:6px">'
          + lbl('Local', inp('nom', r.id, r.nom)) + lbl('Niveau', inp('niveau', r.id, r.niveau))
          + lbl('Nature', '<select ' + IN + ' data-f="nature" data-i="' + esc(r.id) + '"' + (W ? '' : ' disabled') + '>' + NAT.map(function (n) { return '<option value="' + n[0] + '"' + (n[0] === r.nature ? ' selected' : '') + '>' + n[1] + '</option>'; }).join('') + '</select>')
          + lbl('Nombre', inp('nb', r.id, r.nb, 'n')) + lbl('Surface unitaire cible (m²)', inp('surf', r.id, r.surf, 'n')) + lbl('Surface dessinée totale (m²)', inp('proj', r.id, r.proj, 'n')) + '</div>'
          + '<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:6px;font-size:12.5px"><span>Cible : <b>' + fm(r.cible) + ' m²</b></span>' + (r.ecart == null ? '' : '<span>Écart : <b>' + fm(r.ecart) + ' m² (' + fm(r.pct, 1) + ' %)</b></span>') + '<span style="color:' + e[1] + '">' + e[0] + '</span>' + (W ? '<button data-a="del" data-i="' + esc(r.id) + '" title="Supprimer" style="margin-left:auto">🗑</button>' : '') + '</div></div>';
      });
      h += '<p style="border-top:2px solid #94a3b8;padding-top:6px"><b>Total</b> : cible ' + fm(C.tot.cible) + ' m² · dessinée ' + fm(C.tot.proj) + ' m² · brute ' + fm(C.tot.brut) + ' m²</p>';
      h += '<p>' + (W ? '<button data-a="add">+ Local</button> <label style="cursor:pointer;padding:6px 10px;background:#e2e8f0;border-radius:8px">⬆ Importer CSV<input type="file" accept=".csv,text/csv" data-a="imp" hidden></label> ' : '') + '<button data-a="csv">⬇ CSV</button> <button data-a="print">🖨 Tableau des surfaces</button></p>';
      h += '<p style="font-size:12px;color:#64748b">Cible de la ligne = surface unitaire × nombre. « Dessinée » = surface totale relevée sur le plan (vide tant que non dessinée). Les surfaces dessinées sont utilisées en priorité pour les totaux.</p>';
    } else if (st.tab === 'synthese') {
      var c = C.cadre, T = C.tot;
      h += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0">' + kpi('Surface utile', fm(T.utile) + ' m²') + kpi('Circulation', fm(T.circulation) + ' m²' + (C.circPct == null ? '' : ' (' + fm(C.circPct, 1) + ' %)')) + kpi('Annexes', fm(T.annexe) + ' m²') + kpi('Surface brute', fm(T.brut) + ' m²') + kpi('Rendement utile/brute', C.rendement == null ? '—' : fm(C.rendement, 2)) + kpi('Emprise' + (C.empriseEstimee ? ' (estimée)' : ''), C.emprise == null ? '—' : fm(C.emprise) + ' m²') + kpi('CES', C.ces == null ? '—' : fm(C.ces, 2)) + kpi('Surface de plancher', fm(T.plancher) + ' m²') + kpi('COS' + (C.defDefaut ? ' (déf. par défaut)' : ''), C.cos == null ? '—' : fm(C.cos, 2)) + (C.coutM2 ? kpi('Budget / m² brut', fm(C.coutM2, 0)) : '') + '</div>';
      if (C.ecartTotal) h += '<p>Programme vs plan (' + C.nbDessines + ' local(aux) dessiné(s)) : ' + fm(C.ecartTotal.proj) + ' m² dessinés pour ' + fm(C.ecartTotal.cible) + ' m² programmés, écart ' + fm(C.ecartTotal.proj - C.ecartTotal.cible) + ' m².</p>';
      h += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + [['terrain', 'Terrain (m²)'], ['emprise', 'Emprise projetée (m²)'], ['pays', 'Pays'], ['commune', 'Commune'], ['budget', 'Budget indicatif'], ['tol', 'Tolérance d’écart (%)']].map(function (f) { return '<label style="font-size:12px">' + f[1] + inp('cadre', f[0], c[f[0]] == null ? '' : c[f[0]], /^(terrain|emprise|budget|tol)$/.test(f[0]) ? 'n' : '') + '</label>'; }).join('') + '</div>';
      if (C.alertes.length) h += '<ul style="color:#b45309;font-size:13px">' + C.alertes.map(function (a) { return '<li>' + esc(a) + '</li>'; }).join('') + '</ul>';
      var inc = String(c.plancher_nat || 'utile,circulation,annexe').split(',');
      h += '<fieldset style="margin-top:10px;border:1px solid #cbd5e1;border-radius:10px;padding:8px"><legend style="font-size:12px"><b>Définitions de calcul de ce projet</b></legend><div style="font-size:13px">Surface de plancher (pour le COS) = somme des surfaces de : ' + NAT.map(function (n) { return '<label style="margin-right:10px"><input type="checkbox" data-f="plancher" data-i="' + n[0] + '"' + (inc.indexOf(n[0]) >= 0 ? ' checked' : '') + (W ? '' : ' disabled') + '> ' + n[1] + '</label>'; }).join('') + '</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;margin-top:6px"><label style="font-size:12px">Niveaux exclus de la surface de plancher (ex. sous-sol, cave)' + inp('cadre', 'plancher_excl', c.plancher_excl || '') + '</label><label style="font-size:12px">Niveau retenu pour l’emprise estimée (défaut : RDC)' + inp('cadre', 'niv_emprise', c.niv_emprise || '') + '</label></div><p style="font-size:12px;color:' + (C.defDefaut ? '#b45309' : '#64748b') + ';margin:6px 0 0">' + (C.defDefaut ? 'Définition non choisie : valeurs par défaut (tout compté). Confirmer ces choix avec la réglementation locale ; une règle sur le COS reste « à vérifier » tant que ce n’est pas fait. Cochez/décochez pour enregistrer le choix.' : 'Définition enregistrée pour ce projet.') + ' Brute = utile + circulation + annexes (tous niveaux) · CES = emprise / terrain · COS = surface de plancher / terrain.</p></fieldset>';
    } else {
      var V = mine().filter(function (x) { return x.type === 'variante'; });
      h += '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr><th align="left">Variante</th><th>Surface</th><th>Rendement</th><th>CES</th><th>COS</th><th>Coût</th><th>Retenue</th><th></th></tr>' + V.map(function (v) {
        return '<tr style="border-top:1px solid #e2e8f0"><td>' + inp('vnom', v.id, v.nom) + '</td>' + ['surface', 'rendement', 'ces', 'cos', 'cout'].map(function (k) { return '<td style="width:90px">' + inp('v_' + k, v.id, v[k], 'n') + '</td>'; }).join('') + '<td align="center"><input type="radio" name="ret" data-f="vret" data-i="' + esc(v.id) + '"' + (v.retenue ? ' checked' : '') + (W ? '' : ' disabled') + '></td><td>' + (W ? '<button data-a="del" data-i="' + esc(v.id) + '">🗑</button>' : '') + '</td></tr>'; }).join('') + '</table></div>';
      h += '<p>' + (W ? '<button data-a="snap">+ Variante depuis le programme actuel</button> ' : '') + '</p><p style="font-size:12px;color:#64748b">Comparaison brute : aucune variante n’est recommandée. Le coût est saisi à la main ; la décision revient à l’architecte et au client.</p>';
    }
    b.innerHTML = h;
  }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), id = t.getAttribute && t.getAttribute('data-i'), v = t.value;
    if (t.id === 'pgPid') { st.pid = v; return paint(); }
    if (t.getAttribute && t.getAttribute('data-a') === 'imp') return importCsv(t);
    if (f === 'plancher') {
      var bxs = box().querySelectorAll('input[data-f="plancher"]'), sel = []; for (var q = 0; q < bxs.length; q++) if (bxs[q].checked) sel.push(bxs[q].getAttribute('data-i'));
      if (!sel.length) { say('Choisir au moins une nature.', 'error'); return paint(); }
      edit(function (a) { cadreOf(a).plancher_nat = sel.join(','); }); return setTimeout(paint, 0);
    }
    if (!f) return;
    var numeric = /^(nb|surf|proj|v_surface|v_rendement|v_ces|v_cos|v_cout)$/.test(f) || (f === 'cadre' && /^(terrain|emprise|budget|tol)$/.test(id));
    if (numeric && v !== '' && (!hasNum(v) || num(v) < 0)) { say('Nombre positif attendu.', 'error'); return paint(); }
    if (f === 'nb' && v !== '' && num(v) <= 0) { say('Le nombre doit être supérieur à 0.', 'error'); return paint(); }
    edit(function (a) {
      if (f === 'cadre') { cadreOf(a)[id] = numeric ? (v === '' ? '' : num(v)) : s(v, 80); return; }
      var x = a.filter(function (z) { return z.id === id; })[0]; if (!x) return false;
      if (f === 'vret') { a.forEach(function (z) { if (z.type === 'variante' && String(z.project) === String(st.pid)) z.retenue = false; }); x.retenue = true; return; }
      if (f === 'vnom') { x.nom = s(v, 120); return; }
      if (/^v_/.test(f)) { x[f.slice(2)] = v === '' ? '' : num(v); return; }
      x[f] = /^(nb|surf|proj)$/.test(f) ? (v === '' ? '' : num(v)) : s(v, f === 'nom' ? 120 : 40);
      if (f === 'surf') delete x.cible; x.maj = today(); x.par = who();
    }); setTimeout(paint, 0);
  }
  function importCsv(el) {
    var f = el.files && el.files[0]; el.value = ''; if (!f || !canW()) return; if (f.size > 1048576) return say('Fichier trop volumineux (1 Mo max).', 'error');
    var rd = new FileReader(); rd.onload = function () {
      var p = parseCsv(String(rd.result)); if (p.erreurs.length) say(p.erreurs.length + ' problème(s) : ' + p.erreurs.slice(0, 3).join(' | '), 'error');
      if (!p.items.length || !w.confirm('Ajouter ' + p.items.length + ' local(aux) au programme de ce projet ?')) return;
      edit(function (a) { p.items.forEach(function (x) { a.push(Object.assign({ id: uid('AL'), type: 'local', project: st.pid, proj: '', maj: today(), par: who() }, x)); }); }); paint();
    }; rd.readAsText(f);
  }
  function dl(name, txt, type) { var l = d.createElement('a'); l.href = URL.createObjectURL(new Blob([txt], { type: type })); l.download = name; d.body.appendChild(l); l.click(); setTimeout(function () { URL.revokeObjectURL(l.href); l.remove(); }, 500); }
  function printTab() {
    var C = calc(mine(), 'base'), win = w.open('', '_blank'); if (!win) return say('Autorisez les fenêtres pour imprimer.', 'error'); var T = C.tot;
    win.document.write('<html><head><meta charset="utf-8"><title>Tableau des surfaces</title><style>body{font:12px Arial;margin:20px}table{border-collapse:collapse;width:100%;margin-bottom:10px}td,th{border:1px solid #999;padding:3px 7px;text-align:left}td.n{text-align:right}</style></head><body><h2>Tableau des surfaces — ' + esc(pname()) + '</h2><p>Édité le ' + esc(today()) + '</p><table><tr><th>Local</th><th>Niveau</th><th>Nature</th><th>Nb</th><th>Cible m²</th><th>Dessinée m²</th><th>Écart</th></tr>'
      + C.rows.map(function (r) { return '<tr><td>' + esc(r.nom) + '</td><td>' + esc(r.niveau) + '</td><td>' + esc(lab(NAT, r.nature)) + '</td><td class="n">' + r.nb + '</td><td class="n">' + fm(r.cible) + '</td><td class="n">' + (r.proj == null ? '' : fm(r.proj)) + '</td><td class="n">' + (r.pct == null ? '' : fm(r.pct, 1) + ' %') + '</td></tr>'; }).join('')
      + '</table><p>Utile <b>' + fm(T.utile) + '</b> m² · circulation <b>' + fm(T.circulation) + '</b> m² · annexes <b>' + fm(T.annexe) + '</b> m² · brute <b>' + fm(T.brut) + '</b> m² · rendement ' + (C.rendement == null ? '—' : fm(C.rendement, 2)) + ' · CES ' + (C.ces == null ? '—' : fm(C.ces, 2)) + (C.empriseEstimee ? ' (emprise estimée)' : '') + ' · plancher ' + fm(T.plancher) + ' m² · COS ' + (C.cos == null ? '—' : fm(C.cos, 2)) + (C.defDefaut ? ' (définition par défaut)' : '') + '</p>'
      + (C.alertes.length ? '<ul>' + C.alertes.map(function (a) { return '<li>' + esc(a) + '</li>'; }).join('') + '</ul>' : '') + '</body></html>'); win.document.close(); setTimeout(function () { try { win.print(); } catch (e) { } }, 300);
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t || t.tagName === 'INPUT') return; var a = t.getAttribute('data-a'), id = t.getAttribute('data-i');
    if (a === 'close') { var o = d.getElementById('exbProg'); if (o) o.remove(); return; }
    if (a === 'tab') { st.tab = id; return paint(); }
    if (a === 'add') { edit(function (x) { x.push({ id: uid('AL'), type: 'local', project: st.pid, nom: 'Nouveau local', niveau: 'RDC', nature: 'utile', nb: 1, surf: '', proj: '', maj: today(), par: who() }); }); return paint(); }
    if (a === 'del') { if (!w.confirm('Supprimer cette ligne ?')) return; edit(function (x) { var i = x.findIndex(function (z) { return z.id === id; }); if (i < 0) return false; x.splice(i, 1); }); return paint(); }
    if (a === 'snap') { var n = w.prompt('Nom de la variante :', 'Variante ' + (mine().filter(function (x) { return x.type === 'variante'; }).length + 1)); if (n === null) return; edit(function (x) { x.push(Object.assign({ id: uid('AV'), type: 'variante', project: st.pid, retenue: false }, snapshot(calc(x.filter(function (z) { return String(z.project) === String(st.pid); }), 'base'), n))); }); return paint(); }
    if (a === 'csv') return dl('programme-' + String(st.pid).replace(/[^\w-]/g, '') + '.csv', csvLocaux(calc(mine(), 'base')), 'text/csv;charset=utf-8');
    if (a === 'print') return printTab();
  }
  function open() {
    if (!canR()) return say('Accès refusé.', 'error');
    if (!st.pid) { var P = projs(); st.pid = (function () { try { return localStorage.getItem('exb_active_project'); } catch (e) { return ''; } })() || (P[0] && P[0].id) || ''; }
    var o = d.getElementById('exbProg'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbProg'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbProgBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:1020px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('click', onClick); c.addEventListener('change', onChange); paint();
  }
  w.EXBARCP = API;

  function ui() {
    var b = d.getElementById('exbArcBtn'); if (!b || d.getElementById('exbArcPBtn')) return;
    var k = d.createElement('button'); k.id = 'exbArcPBtn'; k.className = 'muted'; k.textContent = '📋 Programme & surfaces'; k.onclick = open; if (!canR()) k.setAttribute('data-exbrole', 'hide'); b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (d.documentElement && w.MutationObserver) { new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true }); d.addEventListener('DOMContentLoaded', ui); }
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { documentElement: null, getElementById: function () { return null; }, addEventListener: function () { } });
