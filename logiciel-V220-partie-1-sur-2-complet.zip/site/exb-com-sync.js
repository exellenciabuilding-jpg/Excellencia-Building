/* Excellencia Building — COM-09 « Synchronisation » V207
 * Exigence : gestion des conflits, reprise après coupure, état de synchronisation et sauvegarde vérifiable.
 * S'appuie sur la base partagée existante (exb-db.js : version serveur par fiche, la version distante est gardée, la vôtre est mise de côté
 * dans « Conflits ») et ajoute, sans la remplacer :
 *   · un écran « 🔄 Synchronisation » : connexion, dernière synchro, modifications locales EN ATTENTE d'envoi (par collection), conflits ;
 *   · pour chaque conflit : comparaison champ par champ « ma version / version gardée », puis choix explicite
 *     (restaurer la mienne, ou garder celle du serveur) — plus rien n'est écarté sans que l'utilisateur voie ce qui change ;
 *   · reprise après coupure : au retour du réseau, une synchronisation est relancée automatiquement ; un bandeau signale une coupure ;
 *   · sauvegarde vérifiable : date de la dernière copie et lancement du test de restauration (exb-continuite.js) si présent ;
 *   · chaque résolution de conflit est inscrite au journal d'audit commun.
 * Limites : sans base partagée (mode local) il n'y a ni file d'envoi ni conflit : l'écran l'indique. Le serveur reste l'autorité.
 * Pour retirer : supprimer la balise <script src="exb-com-sync.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBComSync) return;
  var HEAVY = /^(photo|photos|signature|logo|image|img|file|b64|base64|blob|cachet|password|pass|mdp|token|key|cle)/i;
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function st() { try { return w.EXBDB && w.EXBDB.status ? w.EXBDB.status() : null; } catch (e) { return null; } }
  function short(v) { if (v == null) return ''; var s = typeof v === 'object' ? JSON.stringify(v) : String(v); return s.length > 160 ? s.slice(0, 160) + '…' : s; }
  function fdate(t) { try { return new Date(t).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return String(t || '—'); } }
  function diff(a, b) {
    a = a || {}; b = b || {}; var keys = {}, out = [];
    Object.keys(a).forEach(function (k) { keys[k] = 1; }); Object.keys(b).forEach(function (k) { keys[k] = 1; });
    Object.keys(keys).sort().forEach(function (k) { if (HEAVY.test(k)) return; if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) out.push({ champ: k, mine: short(a[k]), serveur: short(b[k]) }); });
    return out;
  }
  function audit(action, obj, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(action, obj, det); } catch (e) {} }
  var BT = 'border:1px solid #cbd5e1;background:#fff;border-radius:8px;padding:6px 10px;cursor:pointer;font:13px Arial';

  function paint() {
    var c = d.querySelector('#exbComS > div'); if (!c) return;
    var s = st(), online = w.navigator ? w.navigator.onLine : true, h = '<div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">🔄 État de synchronisation</h3><button style="' + BT + '" onclick="document.getElementById(\'exbComS\').remove()">✕ Fermer</button></div>';
    if (!s || !s.on) {
      h += '<p>Ce poste travaille en <b>mode local</b> (pas de base partagée) : il n’y a ni file d’envoi ni conflit possible. Les données restent sur cet appareil : faites des sauvegardes régulières.</p>';
    } else {
      h += '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px;margin:8px 0;font-size:13px">'
        + 'Réseau : <b style="color:' + (online ? '#15803d' : '#b91c1c') + '">' + (online ? 'connecté' : 'COUPÉ — vos modifications restent sur l’appareil') + '</b> · Compte en ligne : ' + (s.online ? 'ouvert' : '<b style="color:#b45309">fermé</b>') + '<br>'
        + 'Base : ' + esc(s.org || '—') + ' · votre rôle : ' + esc(s.role || '—') + '<br>Dernière synchronisation : ' + (s.last ? esc(fdate(s.last)) : 'aucune depuis l’ouverture') + (s.busy ? ' · ⏳ en cours' : '') + '<br>' + esc(s.msg || '') + '</div>';
      var cols = Object.keys(s.pendingByCol);
      h += '<h4 style="margin:10px 0 4px">Modifications en attente d’envoi : ' + s.pending + '</h4>' + (cols.length ? '<ul style="margin:4px 0;font-size:13px">' + cols.map(function (k) { return '<li>' + esc(k) + ' : ' + s.pendingByCol[k] + '</li>'; }).join('') + '</ul>' : '<p style="font-size:13px;color:#15803d;margin:4px 0">Tout est envoyé : aucune modification locale en attente.</p>');
      h += '<p><button style="' + BT + '" onclick="EXBComSync.now()">🔄 Synchroniser maintenant</button></p>';
      h += '<h4 style="margin:10px 0 4px">Conflits à examiner : ' + s.conflicts.length + '</h4>';
      if (!s.conflicts.length) h += '<p style="font-size:13px;color:#15803d;margin:4px 0">Aucun conflit : personne n’a modifié en même temps la même fiche que vous.</p>';
      else {
        h += '<p style="font-size:12px;color:#64748b">Quelqu’un a modifié la même fiche que vous : la version du serveur a été gardée et la vôtre mise de côté. Comparez, puis choisissez.</p>';
        h += s.conflicts.map(function (cf) {
          var df = diff(cf.mine, cf.current), lab = cf.mine && (cf.mine.no || cf.mine.name || cf.mine.title || cf.mine.client || cf.id);
          return '<div style="border:1px solid #fcd34d;background:#fffbeb;border-radius:10px;padding:8px;margin:6px 0"><b>' + esc(cf.col) + ' · ' + esc(lab) + '</b> <span style="color:#64748b;font-size:12px">détecté le ' + esc(fdate(cf.at)) + '</span>'
            + (!cf.current ? '<p style="font-size:12px;margin:4px 0">Cette fiche a été <b>supprimée</b> par un collègue ; votre version est conservée ici.</p>' : '')
            + (df.length ? '<table style="border-collapse:collapse;font-size:12px;width:100%;margin-top:4px"><thead><tr style="background:#fef3c7;text-align:left"><th style="padding:4px">Champ</th><th style="padding:4px">Ma version</th><th style="padding:4px">Version gardée (serveur)</th></tr></thead><tbody>' + df.slice(0, 25).map(function (r) { return '<tr style="border-top:1px solid #fde68a"><td style="padding:4px"><b>' + esc(r.champ) + '</b></td><td style="padding:4px">' + esc(r.mine || '—') + '</td><td style="padding:4px">' + esc(r.serveur || '—') + '</td></tr>'; }).join('') + '</tbody></table>' : (cf.current ? '<p style="font-size:12px;margin:4px 0">Aucune différence visible (champs textes ou volumineux exclus).</p>' : ''))
            + '<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap"><button style="' + BT + '" onclick="EXBComSync.restore(' + cf.i + ')">↩ Restaurer ma version</button><button style="' + BT + '" onclick="EXBComSync.keep(' + cf.i + ')">✔ Garder celle du serveur</button></div></div>';
        }).join('');
      }
    }
    h += '<h4 style="margin:12px 0 4px">Sauvegarde vérifiable</h4><div id="exbComSB" style="font-size:13px">Lecture de l’état des sauvegardes…</div>'
      + '<p style="margin:4px 0">' + (w.EXBContinuite ? '<button style="' + BT + '" onclick="EXBContinuite.open()">🛡 Continuité & test de restauration</button>' : '') + '</p>';
    c.innerHTML = h; backup();
  }
  function backup() {
    var e = d.getElementById('exbComSB'); if (!e) return;
    var done = function (last, test) {
      var el = d.getElementById('exbComSB'); if (!el) return;
      var tt = test && (test.t || test.at || test.date), tx = test ? ((test.ok === false ? 'ÉCHEC' : 'réussi') + (tt ? ' le ' + fdate(tt) : '')) : '';
      el.innerHTML = 'Dernière copie : ' + (last ? esc(fdate(last.t || last)) : '<b style="color:#b45309">aucune enregistrée</b>') + '<br>Dernier test de restauration : ' + (test ? esc(tx) : '<b style="color:#b45309">jamais testé</b>');
    };
    if (w.EXBContinuite && w.EXBContinuite.status) { w.EXBContinuite.status().then(function (r) { done(r && r.last, r && r.test); }, function () { done(null, null); }); } else done(null, null);
  }
  function open() {
    var o = d.getElementById('exbComS'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbComS'; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto'; o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;padding:16px;max-width:900px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o); paint();
  }
  function conf(i) { var s = st(); return s && s.conflicts.filter(function (c) { return c.i === i; })[0]; }
  function restore(i) {
    var c = conf(i); if (!c) return;
    try { w.EXBDB.restore(i); audit('sync.conflit.restaure', c.col + ':' + c.id, { choix: 'ma version' }); } catch (e) {}
    setTimeout(paint, 300);
  }
  function keep(i) {
    var c = conf(i); if (!c) return;
    try { w.EXBDB.drop(i); audit('sync.conflit.serveur', c.col + ':' + c.id, { choix: 'version serveur' }); } catch (e) {}
    setTimeout(paint, 100);
  }
  function now() { try { w.EXBDB.now(); } catch (e) {} setTimeout(paint, 1500); }

  /* reprise après coupure + bandeau */
  var wasOff = false;
  function banner(show) {
    var b = d.getElementById('exbComOff');
    if (!show) { if (b) b.remove(); return; }
    if (b) return; b = d.createElement('div'); b.id = 'exbComOff'; b.textContent = '⚠ Réseau coupé — vos saisies sont gardées sur l’appareil et seront envoyées au retour de la connexion.';
    b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99990;background:#b45309;color:#fff;font:12px Arial;padding:4px 8px;text-align:center'; d.body.appendChild(b);
  }
  w.addEventListener('offline', function () { wasOff = true; banner(true); audit('sync.coupure', 'reseau', {}); });
  w.addEventListener('online', function () { banner(false); if (wasOff) { wasOff = false; audit('sync.reprise', 'reseau', {}); try { var s = st(); if (s && s.on) w.EXBDB.now(); } catch (e) {} } });
  if (w.navigator && w.navigator.onLine === false) { wasOff = true; d.addEventListener('DOMContentLoaded', function () { banner(true); }); }

  function ui() {
    var b = d.getElementById('exbComBtnV') || d.getElementById('exbAuBtn') || d.getElementById('exbSecBtn'); if (!b || d.getElementById('exbComBtnS')) return;
    var k = d.createElement('button'); k.id = 'exbComBtnS'; k.setAttribute('data-exb-cat', 'rap'); k.setAttribute('data-exb-desc', 'Conflits, envois en attente et reprise après coupure'); k.className = b.className; k.textContent = '🔄 Synchronisation'; k.onclick = open; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'comSync', name: 'Synchronisation COM-09', version: '1.0.0', area: 'Transverse', provides: ['etat-synchro', 'conflits'] }); } catch (e) {}
  w.EXBComSync = { open: open, restore: restore, keep: keep, now: now, diff: diff, status: st };
})(window, document);
