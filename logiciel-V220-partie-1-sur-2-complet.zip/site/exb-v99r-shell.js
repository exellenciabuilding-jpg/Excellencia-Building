/* Excellencia Building V99r — nouveau cadre : barre du haut (recherche, notifications, profil administrateur avec photo),
 * menu latéral par catégories (un clic = uniquement les éléments de la catégorie), accueil avec bannière photo.
 * AUCUN écran, AUCUNE donnée ni fonction existante n'est modifié : le menu d'origine (#app .tabs) reste dans la page (masqué)
 * et chaque carte du nouveau menu déclenche le bouton d'origine. Photos et nom du profil : enregistrés sur cet appareil. */
(function(w,d){'use strict';
var VERSION=w.EXB_VERSION=(w.EXB_BUILD||'V120'),BAN=['assets/accueil/banniere-1.jpg','assets/accueil/banniere-2.jpg','assets/accueil/banniere-3.jpg','assets/accueil/banniere-4.jpg'];
var CATS=[
 {k:'home',i:'🏠',t:'Accueil'},
 {k:'ent',i:'🏢',t:'Entreprise',d:'Direction, personnel, communication, documents'},
 {k:'for',i:'🎓',t:'Formation',d:'Du dossier de l’apprenant jusqu’au certificat'},
 {k:'crm',i:'👥',t:'Clients & CRM',d:'Clients, licences et demandes'},
 {k:'arc',i:'📐',t:'Architecture',d:'Études, plans, BIM et diagnostic'},
 {k:'ing',i:'🧮',t:'Ingénierie & Structure',d:'Métrés, béton armé et devis'},
 {k:'prj',i:'🏗️',t:'Projets & Chantiers',d:'Suivi de projets, chantiers et terrain'},
 {k:'fin',i:'💰',t:'Finance',d:'Paiements, encaissements et comptabilité'},
 {k:'ach',i:'🛒',t:'Achats & Stocks',d:'Matériaux, entrées et sorties'},
 {k:'rap',i:'📊',t:'Rapports',d:'Statistiques, registre et sauvegardes'},
 {k:'set',i:'⚙️',t:'Paramètres',d:'Identité, logos, administration et réglages'}];
var MAP={tflSec:'for',btfl:'for',decomptes:'fin',bdec:'fin',budgetfin:'fin',bbfin:'fin',chantierctl:'prj',bctl:'prj',plangantt:'prj',bplan:'prj',pilotprojet:'prj',bpilot:'prj',dashboard:'home',direction:'ent',enterprise360:'ent',rh:'ent',communication:'ent',documents:'ent',
 participantForm:'for',receipts:'for',participants:'for',cards:'for',formations:'for',formateurs:'for',planning:'for',presence:'for',tpTd:'for',evaluations:'for',cotation:'for',certs:'for',bulk:'for',portailApprenant:'for',
 clients:'crm',bportails:'crm',bureauEtudes:'arc',architecture:'arc',etudes3:'arc',metreDevis:'ing',calcStructure:'ing',planEditeur:'arc',bplanedit:'arc',atelierMep:'ing',batelier:'ing',bcs_pre:'ing',bcs_sfi:'ing',bcs_rad:'ing',bcs_mur:'ing',bcs_bat:'ing',bcs_pou:'ing',bcs_sem:'ing',bcs_esc:'ing',bcs_dos:'ing',bcs_pot:'ing',bcs_dal:'ing',bcs_mor:'ing',bcs_vol:'ing',bcs_cof:'ing',bcs_fer:'ing',bcs_mom:'ing',bcs_cou:'ing',bcs_agg:'ing',bcs_dev:'ing',bcs_ven:'ing',bcs_sei:'ing',bcs_por:'ing',bcs_cmb:'ing',bcs_rob:'ing',bcs_pie:'ing',bcs_mac:'ing',bcs_apo:'ing',bcs_apt:'ing',bcs_bpo:'ing',bcs_bpt:'ing',projets:'prj',chantiers:'prj',terrain:'prj',
 finances:'fin',comptabilite:'fin',stock:'ach',reports:'rap',registry:'rap',
 logoexb:'set',logordc:'set',affiches:'set',administration:'set',settings:'set',cloudSync:'set',proprietaire:'set',equipe:'set',vitrine:'set'};
var DESC={tflSec:'Sujets, candidatures, banque, bibliothèque',bcs_rob:'Analyse de structure (Robot) : modèle, charges, résultats',budgetfin:'Budget mensuel, comparatif, TVA, fiche client',bbfin:'Budget mensuel, comparatif, TVA, fiche client',decomptes:'Décomptes, retenues, cautions',chantierctl:'Checklists, causeries, non-conformités',plangantt:'Gantt, chemin critique, budget',pilotprojet:'Coût, délai et alertes par chantier',bpilot:'Coût, délai et alertes par chantier',equipe:'Invitations, rôles et fonctions',bportails:'Portails client et sous-traitant, e-signature, relances',proprietaire:'Clients, licences et essais',participantForm:'Demandes et fiches',receipts:'Reçus et QR',participants:'Liste et profils',cards:'Cartes professionnelles',formations:'Catalogue des formations',formateurs:'Équipe pédagogique',planning:'Sessions et calendrier',presence:'Pointage',tpTd:'Copies et épreuves',evaluations:'Notes et résultats',cotation:'Cotations',certs:'Certificats PDF',bulk:'Impression par lots',portailApprenant:'Espace apprenant',
 direction:'Pilotage et indicateurs',enterprise360:'Vue globale',rh:'Paie, congés, permis',communication:'Messages et annonces',documents:'Pièces et archives',clients:'Fiches et licences',bureauEtudes:'Plans, BIM, CDE',metreDevis:'Béton armé, devis, matériaux',calcStructure:'Tous les calculs béton armé',planEditeur:'Plans 2D/3D, mobilier, électricité',bplanedit:'Plans 2D/3D, mobilier, électricité',bcs_pre:'Dalle, poutre, poteau, semelle',bcs_bat:'Descente de charges, 3D, plans',bcs_pou:'Poutre continue BAEL / EC2',bcs_sem:'Semelle et fondation',bcs_esc:'Droit, balancé, va-et-vient',bcs_dos:'Ciment, sable, gravier, eau',bcs_pot:'Poteau béton armé, ferraillage',bcs_dal:'Dalle et plancher, aciers',bcs_mor:'Dosage du mortier',bcs_vol:'Volumes de béton',bcs_cof:'Surfaces de coffrage',bcs_fer:'Aciers, barres et cadres',bcs_mom:'Moment fléchissant maximal',bcs_cou:'Coût des ouvrages',bcs_agg:'Agglos et maçonnerie',bcs_dev:'Devis quantitatif et estimatif',bcs_ven:'Pression et efforts du vent',bcs_sei:'Forces sismiques par niveau',bcs_pie:'Capacité portante et armatures',bcs_mac:'Mur porteur en agglos, EN 1996',bcs_apo:'Profilé IPE / HEA, EN 1993',bcs_apt:'Flambement, EN 1993',bcs_bpo:'Bois massif, EN 1995',bcs_bpt:'Flambement bois, EN 1995',projets:'Suivi, planning, budget',finances:'Paiements et encaissements',comptabilite:'Écritures et bilans',stock:'Entrées / sorties',reports:'Statistiques',registry:'Export / import',administration:'Utilisateurs et journal',settings:'Réglages',logoexb:'Identité',logordc:'Identité',affiches:'Affiches',cloudSync:'Synchronisation'};
/* V168 — §1 du cahier unifié V1.0 : 5 divisions = regroupement d'AFFICHAGE du menu. Aucun module n'est modifié ni déplacé : chaque écran garde sa clé, sa catégorie et son code.
 * Une division regroupe des écrans (par défaut ceux de ses catégories ; DIV_ITEM reclasse quelques écrans de « Entreprise » / « Paramètres » / « Rapports » vers leur vraie division). */
var DIVS=[
 {k:'dv_dir',i:'🧭',t:'Direction & pilotage',d:'Business Intelligence, Workflow, Administration et pilotage exécutif',cats:['ent','rap','set']},
 {k:'dv_con',i:'🏗️',t:'Ingénierie et architecture',d:'Plan Editor, Project Manager, études, ingénierie et suivi de chantier',cats:['arc','ing','prj']},
 {k:'dv_ges',i:'💼',t:'Gestion & finances',d:'CRM, Finances & Comptabilité, Stock & Procurement',cats:['crm','fin','ach']},
 {k:'dv_for',i:'🎓',t:'Formation & académie',d:'Portail TFL, formations, apprenants, évaluations, encadreurs et Certificats',cats:['for']},
 {k:'dv_inf',i:'🖥️',t:'Infrastructure numérique',d:'EXCELLENCIA CORE, Server, Licences, Scanner, Archives, sécurité et services techniques',cats:[]}];
var CAT_DIV={};DIVS.forEach(function(v){v.cats.forEach(function(c){CAT_DIV[c]=v.k})});
var DIV_ITEM={exbar:'dv_inf',exbsc:'dv_inf',documents:'dv_inf',dataStorage:'dv_inf',exbContBtn:'dv_inf',exbSecBtn:'dv_inf',registry:'dv_inf',cloudSync:'dv_inf',exbAuBtn:'dv_inf',proprietaire:'dv_inf',bv51:'dv_inf',
 exbPayBtn:'dv_ges'};
/* V205 : « Personnel & RH » et « Portails & signatures » (catégorie Entreprise) ne sont plus dans Gestion & finances : ils restent dans Direction & pilotage. */
/* V202 : Intelligence BTP, Pièces écrites, Permis & autorisations, Maintenance / Facility (ex-dv_con) et Import inscriptions, QCM logiciels (ex-dv_for) restent dans « Direction & pilotage » : les divisions Ingénierie et architecture / Formation & académie n'affichent que leurs propres catégories. */
function divOf(it){return DIV_ITEM[it.key]||CAT_DIV[it.cat]||'dv_dir'}
/* V185c : un écran reclassé vers une division (DIV_ITEM) ne s'affiche QUE dans cette division, jamais en double dans la page de sa catégorie d'origine (ex. Entreprise) */
function catList(k){return items().filter(function(i){return i.cat===k&&(!DIV_ITEM[i.key]||DIV_ITEM[i.key]===CAT_DIV[k])})}
function divInfo(k){return DIVS.filter(function(v){return v.k===k})[0]}
/* V202 : « Parcours TFL » a son propre côté (menu latéral + page dédiée) ; chaque vue du module TFL s'ouvre directement. */
var TFL_VUES=[['dossiers','📥','Dossiers & candidatures','Candidatures reçues, statuts et numéros de dossier'],['tableau','📊','Tableau de bord TFL','Chiffres clés et rapport CSV'],['sujets','📋','Sujets','Sujets proposés, réservés et attribués'],['biblio','📚','Bibliothèque','Sujets et travaux de référence'],['encadreurs','👨‍🏫','Encadreurs','Encadreurs, matricules et sujets proposés'],['propositions','🧑‍🏫','Propositions d’encadreurs','Formulaire encadreur et sujets proposés'],['frais','💰','Frais TFL','Frais à vérifier et paiements'],['portails','🔐','Portails étudiant et encadreur','Identifiants, mots de passe et messages'],['liens','🔗','Liens à envoyer','Liens du TFL (étudiants et encadreurs)'],['plans','📐','Plans','Plans des travaux de fin de licence'],['signatures','✍️','Signatures','Signatures et validations']];
function tflTiles(){return '<button class="c" onclick="EXB_SHELL.goKey(\'tflSec\')"><i>🎓</i><div><b>TFL</b><small>Module complet : dossiers, candidatures, encadreurs, sujets</small></div></button>'+
 TFL_VUES.map(function(v){return '<button class="c" onclick="EXB_SHELL.goTfl(\''+v[0]+'\')"><i>'+v[1]+'</i><div><b>'+esc(v[2])+'</b><small>'+esc(v[3])+'</small></div></button>'}).join('')}
function espBtn(){return '<button class="xs sub esp'+(curCat==='esp_tfl'?' on':'')+'" onclick="EXB_SHELL.openEspace(\'tfl\')"><span class="ic">🎯</span>Parcours TFL<span class="ch">›</span></button>'}
var $=function(i){return d.getElementById(i)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function sget(k,df){try{var v=w.localStorage.getItem(k);return v==null?df:v}catch(e){return df}}
function sset(k,v){try{w.localStorage.setItem(k,v);return true}catch(e){return false}}
function sdel(k){try{w.localStorage.removeItem(k)}catch(e){}}
function g(f,df){try{var v=f();return v==null?df:v}catch(e){return df}}
function cat(k){return CATS.filter(function(c){return c.k===k})[0]}
function guess(t){t=String(t).toLowerCase();
 if(/chantier|terrain|projet/.test(t))return 'prj';if(/architect|plan|bim|étude|etude/.test(t))return 'arc';if(/métr|metr|devis|structure|béton|beton/.test(t))return 'ing';
 if(/financ|paie|compta|caisse|factur/.test(t))return 'fin';if(/stock|achat|fournis/.test(t))return 'ach';if(/rapport|registre|sauvegarde/.test(t))return 'rap';
 if(/client|licence|crm/.test(t))return 'crm';if(/logo|param|réglage|reglage|admin|sync/.test(t))return 'set';if(/appren|forma|certif|cours|présen|presen|éval|eval/.test(t))return 'for';return 'ent'}
/* Éléments du menu d'origine encore visibles (droits par fonction respectés) */
function items(){var out=[],seen={};
 Array.prototype.forEach.call(d.querySelectorAll('#app .tabs button'),function(b){
  var oc=b.getAttribute('onclick')||'';if(/focusExbGlobalSearch/.test(oc))return;
  var m=oc.match(/show\('([A-Za-z0-9_]+)'\)/),key=m?m[1]:(b.id||oc.slice(0,40));
  if(key==='dashboard'||key==='notifications'||seen[key])return;
  var grp=b.closest('.exb-nav-group');
  if(b.hidden||w.getComputedStyle(b).display==='none'||(grp&&w.getComputedStyle(grp).display==='none'))return;
  var tx=(b.textContent||'').replace(/\s+/g,' ').trim(),mm=tx.match(/^([^\sA-Za-z0-9À-ÿ]+)\s+(.+)$/u);
  seen[key]=1;out.push({key:key,btn:b,ic:mm?mm[1]:'▫️',label:mm?mm[2]:tx,cat:MAP[key]||b.getAttribute('data-exb-cat')||guess(tx),d:DESC[key]||b.getAttribute('data-exb-desc')||''})});
 return espaceFilter(out)}
function catOf(x){if(MAP[x])return MAP[x];var it=items().filter(function(i){return i.key===x})[0];return it?it.cat:null}
var hubFlag=false,orig=null,curCat='home',hist=[],hi=-1,navBusy=false,rescued=[],lastKey='dashboard';
/* V99za : définie ici (et non dans install) — openCat() l'appelle depuis la navigation : « hideRescued is not defined » à l'ouverture d'un menu */
function hideRescued(){rescued.forEach(function(id){var e=$(id);if(e&&id!==lastKey)e.style.display='none'})}

/* ---------- Styles ---------- */
var CSS='\
#app{display:grid;grid-template-columns:248px minmax(0,1fr);padding-bottom:26px;background:#f3f6fc}\
#app>*{grid-column:2;min-width:0}#app>header{grid-column:1/-1}#app>.wrap.no-print{display:none!important}\
#exbNavBar{display:none!important}\
#app>header{position:sticky;top:0;z-index:60;background:#0f2e66;gap:14px;padding:8px 16px;box-shadow:0 2px 10px #0f2e6633}\
#app>header .brand{display:flex;align-items:center;gap:10px;flex:none}#app>header .brand b{font-size:17px;letter-spacing:.4px}#app>header .brand small{opacity:.8}\
#app>header .logout{display:none}\
#app>header .exb-pro-search{position:relative;top:auto;background:transparent;padding:0;flex:1;max-width:640px;margin:0 auto 0 14px;z-index:5}\
#app>header .exb-pro-search input{border-radius:9px;padding:11px 14px;background:#fff;color:#12254a}\
#app>header .exb-pro-search button{background:#ffffff22;color:#fff;border:0;border-radius:9px;padding:10px 12px}\
#app>header .exb-search-results{left:0;right:0;top:48px}\
#xbTop{display:flex;align-items:center;gap:10px;flex:none}\
.xb{position:relative;background:transparent;border:0;color:#fff;font-size:20px;cursor:pointer;padding:6px 8px;border-radius:9px}.xb:hover{background:#ffffff1f}\
.xb i{position:absolute;top:0;right:0;background:#e5352f;color:#fff;border-radius:9px;font:700 10px/16px Arial;min-width:16px;text-align:center;padding:0 3px;font-style:normal}.xb i:empty{display:none}\
.xprof{position:relative;border-left:1px solid #ffffff44;padding-left:12px}\
#xbProf{display:flex;align-items:center;gap:9px;background:transparent;border:0;color:#fff;cursor:pointer;text-align:left;padding:2px 4px;border-radius:10px}#xbProf:hover{background:#ffffff1f}\
.xav{width:42px;height:42px;border-radius:50%;object-fit:cover;background:#c49a38;color:#fff;display:grid;place-items:center;font:700 18px Arial;border:2px solid #ffffff88;flex:none}\
.xpn b{display:block;font-size:13px}.xpn small{font-size:12px;opacity:.85}\
.xmenu{display:none;position:absolute;right:0;top:56px;background:#fff;color:#12254a;border-radius:12px;box-shadow:0 14px 36px #0003;min-width:220px;padding:6px;z-index:80}.xmenu.on{display:block}\
.xmenu button{display:block;width:100%;text-align:left;background:none;border:0;padding:11px 12px;border-radius:8px;font:600 14px Arial;color:#12254a;cursor:pointer}.xmenu button:hover{background:#e8f0fe}\
#exbSide{grid-column:1;grid-row:2/span 500;align-self:start;position:sticky;top:60px;height:calc(100vh - 98px);overflow:auto;background:#fff;border-right:1px solid #e3e9f4;padding:12px;display:flex;flex-direction:column}\
#exbSide .xs{display:flex;align-items:center;gap:12px;width:100%;border:0;background:none;color:#12254a;padding:12px;border-radius:10px;font:600 14px Arial;text-align:left;cursor:pointer;margin-bottom:3px}\
#exbSide .xs span.ic{width:24px;text-align:center;font-size:18px}#exbSide .xs span.ch{margin-left:auto;color:#8b98b3}\
#exbSide .xs:hover{background:#f1f5fc}#exbSide .xs.on{background:#e3edfd;color:#1f6feb}\
#exbSide .xd{display:flex;align-items:center;gap:10px;width:100%;border:0;background:none;color:var(--stx,#c9d6ee)!important;padding:10px 10px 6px;margin-top:10px;border-radius:8px;font:800 12px Arial;letter-spacing:.6px;text-transform:uppercase;text-align:left;cursor:pointer;opacity:.92}#exbSide .xd:hover{background:#ffffff22!important}#exbSide .xd.on{background:var(--dk-acc,#c8962e)!important;color:#fff!important;opacity:1}#exbSide .xd .ic{width:24px;text-align:center;font-size:15px}#exbSide .xs.sub{padding-left:22px}\
.xdg{margin:18px 0 6px;font:800 12px Arial;letter-spacing:.5px;text-transform:uppercase;color:#6b7a99}\
.xpar{display:flex;gap:4px;margin:2px 4px 8px;padding:3px;background:#eef2fa;border-radius:10px}.xpar button{flex:1;border:0;background:transparent;color:#12254a;font:700 12px Arial;padding:7px 4px;border-radius:8px;cursor:pointer}.xpar button.on{background:#12254a;color:#fff}.xsf{margin-top:auto;padding:12px 6px 4px;border-top:1px solid #e3e9f4;font-size:12px;color:#6b7a99}.xsf b{display:block;color:#12254a}\
#exbBurger{display:none;background:transparent;border:0;color:#fff;font-size:24px;cursor:pointer}\
#exbCrumb{display:none;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 15px 0;color:#6b7a99;font-size:13px;max-width:1500px;margin:0 auto;width:100%}\
#exbCrumb button{background:#e3edfd;color:#1f6feb;border:0;border-radius:8px;padding:7px 12px;font-weight:700;cursor:pointer}\
.xh{max-width:1500px;margin:0 auto;padding:15px;width:100%;color:#12254a}\
.xh-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px}.xh-head h1{margin:2px 0;font-size:28px;color:#12254a}.xh-head p{margin:0;color:#6b7a99}.xh-crumb{color:#6b7a99;font-size:13px}\
.xh-date{background:#fff;border:1px solid #e3e9f4;border-radius:10px;padding:10px 14px;font-weight:600;white-space:nowrap}\
.xh-hero{position:relative;display:flex;border-radius:16px;overflow:hidden;background:#0f2e66;color:#fff;min-height:170px;margin-bottom:14px;box-shadow:0 8px 24px #0f2e6626}\
.xh-hl{position:relative;z-index:2;padding:24px 26px;flex:1;background:linear-gradient(90deg,#0f2e66d9 0%,#0f2e66a6 38%,#0f2e6600 72%)}\
.xh-hl small{font-size:15px}.xh-hl h2{margin:4px 0 8px;font-size:28px;color:#fff;border:0;padding:0}.xh-hl p{margin:0 0 14px;font-size:14px;max-width:400px;opacity:.92}\
.xh-btn{background:#1f6feb;color:#fff;border:0;border-radius:9px;padding:11px 18px;font:700 14px Arial;cursor:pointer}.xh-btn:hover{background:#3a82f2}\
.xh-img{position:absolute;inset:0;width:100%;background-size:cover;background-position:center}\
.xh-tag{position:absolute;right:24px;bottom:18px;z-index:3;max-width:220px;font-weight:700;font-size:15px;text-shadow:0 2px 10px #000a}\
.xh-cam{position:absolute;right:14px;top:12px;z-index:4;background:#0f2e66bb;color:#fff;border:1px solid #ffffff55;border-radius:9px;padding:7px 11px;font:600 12px Arial;cursor:pointer}\
.xh-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:14px}\
.xh-card,.xh-k{background:#fff;border:1px solid #e3e9f4;border-radius:14px;padding:16px;box-shadow:0 2px 10px #12254a0d}\
.xh-k{display:flex;gap:14px;align-items:center;cursor:pointer}.xh-k:hover,.xh-qa .q:hover{border-color:#1f6feb}\
.xh-bx{width:52px;height:52px;border-radius:14px;display:grid;place-items:center;font-size:24px;color:#fff;flex:none}\
.xh-k small{color:#6b7a99;display:flex;justify-content:space-between;gap:8px}.xh-k small a{color:#1f6feb;font-size:11px}.xh-k b{display:block;font-size:30px;line-height:1.1}.xh-k em{font-style:normal;font-size:12px;color:#6b7a99}\
.xh-cols{display:grid;grid-template-columns:1.6fr 1fr;gap:12px;margin-bottom:14px}\
.xh-card h3{margin:0 0 12px;font-size:16px;display:flex;justify-content:space-between;color:#12254a}.xh-card h3 a{font:12px Arial;color:#1f6feb;cursor:pointer}\
.xh-chart{display:flex;gap:14px;flex-wrap:wrap;align-items:center}.xh-chart svg{flex:1;min-width:240px}\
.xh-lg{width:170px;background:#f3f6fc;border-radius:10px;padding:10px}.xh-lg div{display:flex;align-items:center;gap:8px;padding:5px 0;font-size:13px}.xh-lg i{width:9px;height:9px;border-radius:50%}.xh-lg b{margin-left:auto}\
.xh-act{display:flex;gap:10px;align-items:center;padding:9px 0;border-bottom:1px solid #eef1f6}.xh-act:last-child{border:0}.xh-act .ci{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;flex:none;background:#dbeafe}.xh-act small{color:#6b7a99;display:block}.xh-act time{margin-left:auto;color:#6b7a99;font-size:12px;white-space:nowrap}\
.xh-qa{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}.xh-qa .q{border:1px solid #e3e9f4;border-radius:12px;padding:12px;cursor:pointer;display:flex;gap:10px;align-items:center;background:#fff}.xh-qa .q small{display:block;color:#6b7a99;font-size:11px}\
.xh-empty{color:#6b7a99;font-size:13px;padding:8px 0}\
#exbHub{max-width:1500px;margin:0 auto;padding:15px;width:100%;color:#12254a}#exbHub h1{margin:2px 0 4px;font-size:28px}\
.xg{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px;margin-top:14px}\
.xg .c{background:#fff;border:1px solid #e3e9f4;border-radius:14px;padding:16px;display:flex;gap:12px;align-items:center;cursor:pointer;text-align:left;font:inherit;color:#12254a;box-shadow:0 2px 10px #12254a0d}\
.xg .c:hover{border-color:#1f6feb;transform:translateY(-1px)}.xg .c i{font-style:normal;font-size:26px}.xg .c b{display:block;font-size:15px}.xg .c small{color:#6b7a99}\
#exbStatus{position:fixed;left:0;right:0;bottom:0;z-index:40;background:#fff;border-top:1px solid #e3e9f4;padding:3px 16px;font-size:12px;line-height:1.25;color:#6b7a99;display:flex;gap:14px;flex-wrap:nowrap;align-items:center;white-space:nowrap;overflow:hidden;min-height:0;max-height:28px}#exbStatus>*{flex:none;margin:0}#exbStatus button{margin:0!important;padding:0 6px!important;min-height:0!important;height:auto!important;line-height:inherit!important;font-size:inherit!important;background:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important}#exbStatus b{color:#0f2e66}.xok{color:#16a34a;font-weight:700}.xko{color:#e5352f;font-weight:700}\
.xm{position:fixed;inset:0;background:#0008;z-index:200;display:grid;place-items:center;padding:14px}.xm-b{background:#fff;color:#12254a;border-radius:16px;max-width:520px;width:100%;max-height:88vh;overflow:auto;padding:16px}.xm-h{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.xm-x{border:0;background:#eef1f6;border-radius:8px;padding:6px 10px;cursor:pointer}\
.xm-g{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.xm-g button{border:2px solid #e3e9f4;border-radius:10px;padding:0;overflow:hidden;cursor:pointer;background:#fff;height:90px}.xm-g button.on{border-color:#1f6feb}.xm-g img{width:100%;height:100%;object-fit:cover;display:block}\
.xm-r{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.xm-r button{border:0;border-radius:9px;padding:10px 14px;font-weight:700;cursor:pointer;background:#e3edfd;color:#1f6feb}\
@media(max-width:900px){#app{display:block}#exbBurger{display:block}\
 #app>header .brand small,.xpn,#xbHelp,.xh-date{display:none}#app>header{gap:8px;padding:8px 10px}#app>header .exb-pro-search{margin-left:0}#app>header .exb-pro-search button{display:none}\
 .xprof{border:0;padding:0}\
 #exbSide{position:fixed;left:0;top:0;bottom:0;height:auto;width:280px;z-index:150;transform:translateX(-105%);transition:transform .2s;box-shadow:0 0 30px #0006;padding-top:64px}#exbSide.on{transform:none}\
 .xh-cols{grid-template-columns:1fr}.xh-hl{background:linear-gradient(180deg,#0f2e66d9,#0f2e6699 70%,#0f2e6633)}.xh-tag{position:relative;right:auto;bottom:auto;margin:0 26px 18px;max-width:none}.xh-hero{flex-direction:column;min-height:260px}.xh-cam{top:auto;bottom:12px;right:12px}\
 #exbStatus .xs2,#exbStatus #exbBkcBtn{display:none}}\
@media print{#exbSide,#exbStatus,#exbCrumb,#exbHome,#exbHub,#exbBurger,#xbTop{display:none!important}#app{display:block;padding:0}#app>header{display:none}}';
var ICO={l:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
 r:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>'};
var CSS2=[
/* le conteneur de contenu occupait seulement la largeur de son contenu (marge auto) : les modules s empilaient en colonne étroite */
'#app>.wrap{width:100%;justify-self:stretch}#exbModBar{min-width:0}',
'#xbNav{display:flex;gap:6px;flex:none;align-items:center}',
'.xnb{width:36px;height:36px;border-radius:10px;border:1px solid #ffffff33;background:#ffffff14;color:#fff;cursor:pointer;display:grid;place-items:center;padding:0;transition:background .15s,opacity .15s,transform .1s}',
'.xnb:hover:not(:disabled){background:#ffffff2e}.xnb:active:not(:disabled){transform:scale(.94)}.xnb:disabled{opacity:.35;cursor:default}',
'.xnb:focus-visible,.xb:focus-visible,#xbProf:focus-visible{outline:2px solid #8fb8ff;outline-offset:2px}',
'#xbTheme{display:grid;place-items:center;width:38px;height:38px;padding:0}#xbTheme svg{display:block}',
/* barre horizontale des modules */
'#exbModBar{display:none;position:relative;max-width:1500px;margin:0 auto;padding:10px 15px 0;width:100%}',
'#exbModBar .mb-in{position:relative;display:flex;flex-direction:row;gap:8px;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x proximity;padding:4px 2px 10px;scrollbar-width:thin;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain}',
'#exbModBar .mb{flex:none;display:flex;align-items:center;gap:8px;padding:9px 15px;border-radius:999px;border:1px solid #e3e9f4;background:#fff;color:#12254a;font:600 13px Arial,sans-serif;cursor:pointer;white-space:nowrap;scroll-snap-align:start;transition:background .15s,border-color .15s,color .15s,box-shadow .15s}',
'#exbModBar .mb:hover{border-color:#1f6feb;color:#1f6feb}#exbModBar .mb i{font-style:normal;font-size:16px;line-height:1}',
'#exbModBar .mb.on{background:#1f6feb;border-color:#1f6feb;color:#fff;box-shadow:0 4px 12px #1f6feb44}',
'#exbModBar .mb:focus-visible{outline:2px solid #1f6feb;outline-offset:2px}',
'#exbModBar .mb-ar{display:none;position:absolute;top:10px;z-index:3;width:34px;height:38px;border:1px solid #e3e9f4;background:#fff;color:#12254a;border-radius:10px;cursor:pointer;font:700 20px/1 Arial;place-items:center;box-shadow:0 2px 10px #12254a22;padding:0}',
'#exbModBar.ov .mb-in{padding-left:42px;padding-right:42px;scroll-padding:0 42px}#exbModBar .mb-ar.l{left:15px}#exbModBar .mb-ar.r{right:15px}#exbModBar.ov .mb-ar{display:grid}#exbModBar .mb-ar:hover{border-color:#1f6feb;color:#1f6feb}',
/* modules côte à côte (page d une catégorie) */
'.xg{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));grid-auto-flow:row}',
'.xg .c{flex-direction:row;min-height:78px;transition:border-color .15s,transform .15s,box-shadow .15s}.xg .c:hover{box-shadow:0 8px 20px #12254a1a}',
'.xg .c:focus-visible{outline:2px solid #1f6feb;outline-offset:2px}.xg .c>div{min-width:0}.xg .c small{display:block;line-height:1.3}',
'@media(max-width:600px){.xg{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.xg .c{flex-direction:column;align-items:flex-start;text-align:left;gap:8px;padding:14px 12px}.xg .c i{font-size:28px}.xg .c b{font-size:14px}',
' #exbModBar{padding:8px 10px 0}#xbNav{gap:4px}.xnb{width:32px;height:32px}#xbTheme{width:34px;height:34px}#app>header .brand b{display:none}}',
'@media(max-width:900px){#exbModBar .mb-ar{display:none!important}}',
'@media print{#exbModBar,#xbNav,#xbTheme{display:none!important}}',
/* V205t : dans un espace, le « Tableau de bord local » hérité (compteurs de tous les métiers) est masqué. Retirer cette ligne pour le réafficher. */
'html.exb-espace #dashboard{display:none!important}',
'.xh-k small a{white-space:nowrap}'
].join('');
function injectCss(){if($('exbShellCss'))return;var s=d.createElement('style');s.id='exbShellCss';s.textContent=CSS+CSS2;d.head.appendChild(s)}

/* ---------- Profil administrateur (photo modifiable) ---------- */
function prof(){try{return JSON.parse(sget('exb_admin_profile','{}'))||{}}catch(e){return {}}}
function saveProf(p){if(!sset('exb_admin_profile',JSON.stringify(p)))exbAlert('Impossible d’enregistrer la photo : l’espace de stockage de ce navigateur est plein.')}
function roleLabel(){return g(function(){return w.EXBDB.info().label},'')}
function renderProfile(){var p=prof(),nm=p.name||'Admin',av=$('xbAv'),n=$('xbName'),r=$('xbRole');if(!av)return;
 av.outerHTML=p.photo?'<img id="xbAv" class="xav" alt="" src="'+p.photo+'">':'<span id="xbAv" class="xav">'+esc(nm.charAt(0).toUpperCase())+'</span>';
 n.textContent=nm;r.textContent=p.role||roleLabel()||'Administrateur'}
function readImg(file,max,square,done){var fr=new FileReader();fr.onload=function(){var im=new Image();im.onload=function(){
  var sw=im.width,sh=im.height,sx=0,sy=0,tw,th;
  if(square){var m=Math.min(sw,sh);sx=(sw-m)/2;sy=(sh-m)/2;sw=sh=m;tw=th=max}else{var k=Math.min(1,max/sw);tw=Math.round(sw*k);th=Math.round(sh*k)}
  var c=d.createElement('canvas');c.width=tw;c.height=th;c.getContext('2d').drawImage(im,sx,sy,sw,sh,0,0,tw,th);done(c.toDataURL('image/jpeg',square?.88:.8))};
  im.onerror=function(){exbAlert('Ce fichier n’est pas une image lisible.')};im.src=fr.result};fr.readAsDataURL(file)}
function pickFile(cb){var i=d.createElement('input');i.type='file';i.accept='image/*';i.onchange=function(){if(i.files&&i.files[0])cb(i.files[0])};i.click()}
function profMenu(){var m=$('xbMenu');if(m)m.classList.toggle('on')}
function changePhoto(){profMenu();pickFile(function(f){readImg(f,192,true,function(u){var p=prof();p.photo=u;saveProf(p);renderProfile()})})}
function removePhoto(){profMenu();var p=prof();delete p.photo;saveProf(p);renderProfile()}
function editName(){profMenu();var p=prof(),P=function(m,v){return w.EXBUI?w.EXBUI.prompt(m,v):Promise.resolve(w.prompt(m,v))};P('Nom affiché :',p.name||'Admin').then(function(n){if(n===null)return;return P('Fonction affichée :',p.role||roleLabel()||'Administrateur').then(function(r){if(r===null)return;editName2(p,n,r)})})}
function editName2(p,n,r){
 p.name=n.trim().slice(0,40)||'Admin';p.role=r.trim().slice(0,40);saveProf(p);renderProfile()}
function doLogout(){profMenu();if(typeof w.logout==='function')w.logout()}

/* ---------- Fenêtres ---------- */
function modal(title,html){closeModal();var m=d.createElement('div');m.className='xm';m.id='xbModal';
 m.innerHTML='<div class="xm-b"><div class="xm-h"><b>'+title+'</b><button class="xm-x" onclick="EXB_SHELL.closeModal()">✕</button></div>'+html+'</div>';
 m.addEventListener('click',function(e){if(e.target===m)closeModal()});d.body.appendChild(m)}
function closeModal(){var m=$('xbModal');if(m)m.remove()}
function help(){modal('Aide rapide','<ul style="line-height:1.7;padding-left:18px;margin:0"><li><b>Menu de gauche</b> : cliquez sur une catégorie pour voir uniquement ce qui la concerne.</li><li><b>Recherche</b> : participant, certificat, reçu, projet, devis, document…</li><li><b>Votre photo</b> : cliquez sur votre nom en haut à droite pour la changer.</li><li><b>Bannière de l’accueil</b> : bouton « 📷 Changer la photo » sur la bannière.</li><li>Photos et nom sont enregistrés sur cet appareil.</li></ul>')}

/* ---------- Bannière ---------- */
function bannerSrc(){var v=sget('exb_home_banner','v:0');if(v.indexOf('data:')===0)return v;var n=parseInt(v.slice(2),10);return BAN[n>=0&&n<BAN.length?n:0]}
function setBanner(v){if(!sset('exb_home_banner',v)){exbAlert('Impossible d’enregistrer cette photo : espace de stockage plein.');return}paintHero();closeModal()}
function bannerPicker(){var cur=sget('exb_home_banner','v:0');
 modal('Photo de la bannière','<div class="xm-g">'+BAN.map(function(s,i){return '<button class="'+(cur==='v:'+i?'on':'')+'" onclick="EXB_SHELL.setBanner(\'v:'+i+'\')"><img alt="" src="'+s+'"></button>'}).join('')+'</div><div class="xm-r"><button onclick="EXB_SHELL.importBanner()">📷 Importer ma photo</button><button onclick="EXB_SHELL.setBanner(\'v:0\')">↺ Photo par défaut</button></div><p style="font-size:12px;color:#6b7a99">Photos issues du site vitrine. Votre photo importée reste sur cet appareil.</p>')}
function importBanner(){pickFile(function(f){readImg(f,1400,false,function(u){setBanner(u)})})}
function paintHero(){var i=$('xhImg');if(i)i.style.backgroundImage='url("'+bannerSrc()+'")'}

/* ---------- Accueil ---------- */
function P(){return g(function(){return exbProjects},[])}
function Cl(){return g(function(){return exbClients},[])}
function Pa(){return g(function(){return participants},[])}
function ym(){return new Date().toISOString().slice(0,7)}
function dateOf(o){return String(o&&(o.created_at||o.start||o.date||o.createdAt)||'')}
function delta(list){var any=list.some(function(o){return dateOf(o)});if(!any)return '';var n=list.filter(function(o){return dateOf(o).slice(0,7)===ym()}).length;return n?'↗ +'+n+' ce mois':'Aucun ce mois'}
function stg(p){var s=String(p.status||'').toLowerCase();return /annul/.test(s)?'x':/termin|clôtur|cloture/.test(s)?'t':/cours/.test(s)?'c':'a'}
function euro(v){return (Math.round((Number(v)||0)*100)/100).toLocaleString('fr-FR')+' $'}
/* V205t : rendu commun des espaces = maquette de l'Espace Formation / Administration (libellé + « Ouvrir → », valeur facultative, sous-titre).
 * L'ouverture passe par goKey (même chemin que le menu latéral) : elle fonctionne aussi pour les modules à bouton spécial (Paie & RH, Réception…). */
function openKey(k){var ok=false;try{ok=items().some(function(i){return i.key===k})}catch(e){}if(ok)goKey(k);else w.show(k)}
function kpiHtml(K){return K.map(function(x){return '<div class="xh-k" onclick="EXB_SHELL.openKey(\''+x[5]+'\')"><div class="xh-bx" style="background:'+x[3]+'">'+x[4]+'</div><div style="flex:1"><small>'+esc(x[0])+'<a>Ouvrir →</a></small>'+((x[1]===''||x[1]==null)?'':'<b style="font-size:24px">'+esc(String(x[1]))+'</b>')+'<em>'+esc(x[2])+'</em></div></div>'}).join('')}
function qaHtml(){return items().filter(function(i){return !/^(exbMsgrTile_|bcs_)/.test(i.key)}).map(function(i){return '<div class="q" onclick="EXB_SHELL.openKey(\''+i.key+'\')"><span style="font-size:22px">'+esc(i.ic)+'</span><div><b>'+esc(i.label)+'</b><small>'+esc(DESC[i.key]||'')+'</small></div></div>'}).join('')}
/* Activité récente propre à l'espace : entrées du journal qui concernent le métier de l'espace (sinon le message d'origine reste affiché). */
function espaceActivity(E){var a=$('xhAct');if(!a||!E||!E.home||!E.home.act)return;
 var al=g(function(){return auditLog},[]).filter(function(x){return x&&E.home.act.test(String(x.action||'')+' '+String(x.details||''))}).slice(0,5);
 if(!al.length)return;
 a.innerHTML=al.map(function(x){var t=new Date(x.at),hh=isNaN(t)?'':t.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});return '<div class="xh-act"><div class="ci">'+esc(E.home.ic||'🕒')+'</div><div><b>'+esc(x.action)+'</b><small>'+esc(String(x.details||'').slice(0,70))+'</small></div><time>'+hh+'</time></div>'}).join('')}
function espaceHome(){var E=espace();if(!E)return;var ac=espaceAcces(),h1=d.querySelector('#exbHome h1');if(h1)h1.textContent=E.ic+' '+E.t;var sub=$('xhSub');if(sub)sub.textContent=E.sub;
 var pk=$('xhPick');if(pk)pk.innerHTML='';var ld=$('xhLead');if(ld)ld.textContent='Suivez vos encaissements, vos dépenses, la caisse et les clôtures, avec un justificatif pour chaque opération.';
 var gb=$('xhGo');if(gb){gb.textContent='Voir les finances →';gb.setAttribute('onclick',"EXB_SHELL.openKey('finances')")}
 if(!ac.ok){$('xhK').innerHTML='<div class="xh-card" style="grid-column:1/-1;border-left:4px solid #b42318"><h3>⛔ Accès refusé à cet espace</h3><p>Votre fonction'+(ac.fonction?' (« '+esc(ac.fonction)+' »)':'')+' n’est pas autorisée dans l’'+esc(E.t)+'. Demandez à la direction de modifier votre fonction, ou ouvrez votre propre espace.</p><button class="xs" onclick="EXB_SHELL.quitEspace()">⎋ Quitter l’espace</button></div>';
  ['xhChart','xhAct','xhQA'].forEach(function(i){var e=$(i);if(e)e.innerHTML=''});return}
 if(E.dash==='ing'||E.dash==='arc'){ingHome(E);espaceActivity(E);return}
 if(E.dash==='for'){forHome(E);espaceActivity(E);return}
 if(E.dash==='chn'||E.dash==='dir'||E.dash==='adm'||E.dash==='mag'){simpleHome(E);espaceActivity(E);return}
 var B=w.EXBBI,L=null,n=new Date(),dd=function(x){return x.getFullYear()+'-'+('0'+(x.getMonth()+1)).slice(-2)+'-'+('0'+x.getDate()).slice(-2)};
 try{L=B&&B.compute(B.gather(),{range:{a:dd(new Date(n.getFullYear(),n.getMonth(),1)),b:dd(n),lab:'Ce mois'},pid:'',dept:''})}catch(e){L=null}
 var k=(L&&L.kpi&&L.kpi.USD)||{},unp=parseInt(g(function(){return $('dashUnpaid').textContent},'0'),10)||0;
 var K=[['Recettes du mois',euro(k.encaisse),'Encaissé ce mois','#1f6feb','📈','finances'],['Dépenses du mois',euro(k.depenses),'Sorties de caisse','#16a34a','👛','finances'],['Solde du mois',euro(k.resultat),'Recettes − dépenses','#f59e0b','🤝','comptabilite'],['Paiements en attente',unp,'À encaisser','#7c3aed','📄','receipts']];
 $('xhK').innerHTML=kpiHtml(K);
 var t=$('xhChartT');if(t)t.textContent='📊 Évolution des finances (12 derniers mois)';
 var T=(L&&L.tendance&&L.tendance.USD)||[],mx=1;T.forEach(function(s){mx=Math.max(mx,s.enc||0,s.dep||0)});
 $('xhChart').innerHTML=T.some(function(s){return s.enc||s.dep})?'<svg viewBox="0 0 600 160">'+T.map(function(s,i){var bw=560/T.length,x=20+i*bw,h1=(s.enc||0)/mx*110,h2=(s.dep||0)/mx*110;return '<rect x="'+(x+2).toFixed(1)+'" y="'+(130-h1).toFixed(1)+'" width="'+(bw/2-3).toFixed(1)+'" height="'+h1.toFixed(1)+'" fill="#1f6feb"/><rect x="'+(x+bw/2).toFixed(1)+'" y="'+(130-h2).toFixed(1)+'" width="'+(bw/2-3).toFixed(1)+'" height="'+h2.toFixed(1)+'" fill="#f59e0b"/><text x="'+(x+bw/2).toFixed(1)+'" y="150" font-size="10" text-anchor="middle" fill="#6b7a99">'+esc(String(s.m||'').slice(-5))+'</text>'}).join('')+'</svg><div class="xh-lg"><div><i style="background:#1f6feb"></i>Recettes</div><div><i style="background:#f59e0b"></i>Dépenses</div></div>':'<div class="xh-empty" style="flex:1">Aucune opération financière enregistrée sur 12 mois.</div>';
 var rows=g(function(){return w.EXBLIEN.ledger().rows.slice().sort(function(a,b){return String(b.date).localeCompare(String(a.date))}).slice(0,5)},[]);
 var act=$('xhAct');if(act)act.innerHTML=rows.length?rows.map(function(r){return '<div class="xh-act"><div class="ci">⬆️</div><div><b>Paiement reçu · +'+esc(euro(r.amount).replace(' $',' '+(r.currency==='CDF'?'FC':'$')))+'</b><small>'+esc(r.date||'')+' · '+esc(r.source||'')+(r.method?' · '+esc(r.method):'')+'</small></div></div>'}).join(''):'<div class="xh-empty">Aucun paiement confirmé pour le moment.</div>';
 var qa=$('xhQA');if(qa)qa.innerHTML=qaHtml()}
/* V205 lot 6 : tableaux de bord des espaces Chantier, Direction, Administration (tuiles + liste + accès rapides ; les droits réels restent côté serveur). */
function simpleHome(E){var ot=g(function(){return w.EXBTT.list().filter(function(x){return x.status!=='Terminée'&&x.status!=='Validée'}).length},0),prj=P(),run=prj.filter(function(p){return stg(p)==='c'}),fin=prj.filter(function(p){return stg(p)==='t'}),nom=function(p){return p.name||p.nom||p.title||p.id||'Projet'},pa=Pa(),cl=Cl(),
 unp=g(function(){return pa.filter(function(q){var t=w.exbPayTrack.status(q);return !(t.insc&&t.form==='total')}).length},parseInt(g(function(){return $('dashUnpaid').textContent},'0'),10)||0),K,lead,go,lt,list,emp,act;
 if(E.dash==='chn'){lead='Suivez vos projets et chantiers : planning, budget, terrain, contrôles de sécurité et réception.';go=['Voir les projets →','projets'];
  K=[['Projets en cours',run.length,'Chantiers actifs','#1f6feb','🏗️','projets'],['Projets terminés',fin.length,'Livrés','#16a34a','✅','projets'],['Tâches terrain',ot,'À terminer','#7c3aed','✅','exbTTbtn'],['Contrôles & sécurité','','Checklists, causeries','#f59e0b','🦺','chantierctl']];
  lt='🏗️ Projets en cours';list=run.slice(0,8).map(function(p){return ['🏗️',nom(p),(p.status||'')+(p.client?' · '+p.client:'')]});emp='Aucun projet en cours.';act='Les événements de chantier apparaissent dans le journal de l’entreprise.'}
 else if(E.dash==='mag'){var st=g(function(){return exbStock},[]),mv=g(function(){return exbStockMoves},[]),low=st.filter(function(x){return Number(x.min)>0&&Number(x.qty)<=Number(x.min)});
  lead='Suivez le stock et les matériaux : entrées, sorties, dépôts, inventaires et achats de chantier.';go=['Ouvrir le stock →','stock'];
  K=[['Articles en stock',st.length,'Matériaux référencés','#1f6feb','📦','stock'],['À réapprovisionner',low.length,low.length?'Sous le seuil minimum':'Aucun article sous le seuil','#dc2626','⚠️','stock'],['Mouvements',mv.length,'Entrées et sorties','#16a34a','🔁','stock'],['Dépôts & inventaires','','Comparatifs, écarts','#7c3aed','🏬','bstkp']];
  lt=low.length?'⚠️ Articles à réapprovisionner':'📦 Derniers articles';list=(low.length?low:st.slice(-8).reverse()).slice(0,8).map(function(x){return [low.length?'⚠️':'📦',x.name||'Article',(x.qty!=null?x.qty:'—')+' '+(x.unit||'')+(x.min?' · seuil '+x.min:'')]});emp='Aucun article en stock pour le moment.';act='Les mouvements de stock sont journalisés par le serveur.'}
 else if(E.dash==='dir'){lead='Pilotez l’entreprise : indicateurs, workflow, clients et relations commerciales.';go=['Ouvrir la BI Direction →','exbbi'];
  K=[['Projets en cours',run.length,'Vue Enterprise 360°','#1f6feb','🏗️','enterprise360'],['Clients',cl.length,'Fiches et CRM','#16a34a','👥','clients'],['Apprenants',pa.length,'Formation','#7c3aed','🎓','enterprise360'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','exbbi']];
  lt='👥 Derniers clients';list=cl.slice(-8).reverse().map(function(c){return ['👥',c.name||c.nom||c.company||'Client',c.phone||c.email||'']});emp='Aucun client enregistré.';act='Suivez l’activité dans Supervision et dans le journal de l’entreprise.'}
 else{var hr=g(function(){return exbHr},[]),act1=hr.filter(function(x){return !/inactif|parti|sorti|termin|démis|demis|suspend/i.test(String(x.status||''))});
  lead='Gérez le personnel et la paie, les documents, la sécurité, les sauvegardes et les paramètres de l’entreprise.';go=['Personnel & RH →','rh'];
  K=[['Personnel',hr.length,act1.length+' en activité','#1f6feb','👷','rh'],['Paie & RH','','Salaires et paie','#16a34a','💵','exbPayBtn'],['Documents','','Pièces et archives','#7c3aed','🗂️','documents'],['Paramètres','','Identité, réglages','#f59e0b','⚙️','settings']];
  lt='👷 Personnel';list=hr.slice(-8).reverse().map(function(x){return ['👷',x.name||x.nom||'Employé',(x.role||x.poste||'')+(x.status?' · '+x.status:'')]});emp='Aucun employé enregistré pour le moment.';act='Les actions sensibles (paie, réglages) sont journalisées.'}
 var ld=$('xhLead');if(ld)ld.textContent=lead;var gb=$('xhGo');if(gb){gb.textContent=go[0];gb.setAttribute('onclick',"EXB_SHELL.openKey('"+go[1]+"')")}
 $('xhK').innerHTML=kpiHtml(K);
 var t=$('xhChartT');if(t)t.textContent=lt;var c=$('xhChart');if(c)c.innerHTML=list.length?list.map(function(r){return '<div class="xh-act"><div class="ci">'+r[0]+'</div><div><b>'+esc(r[1])+'</b><small>'+esc(r[2])+'</small></div></div>'}).join(''):'<div class="xh-empty" style="flex:1">'+esc(emp)+'</div>';
 var a=$('xhAct');if(a)a.innerHTML='<div class="xh-empty">'+esc(act)+'</div>';
 var qa=$('xhQA');if(qa)qa.innerHTML=qaHtml()}
/* V205 lot 5b : tableau de bord de l'Espace Formation (aucun encaissement ni reçu : c'est le métier du comptable). */
function forHome(E){var pa=Pa(),fo=g(function(){return formations},[]),ce=g(function(){return certs},[]),se=g(function(){return JSON.parse(w.localStorage.getItem('exb_schedules')||'[]')},[]);
 var ld=$('xhLead');if(ld)ld.textContent='Gérez les apprenants, les formations, les sessions, les évaluations et les certificats. Les reçus de paiement sont établis par le comptable.';
 var gb=$('xhGo');if(gb){gb.textContent='Voir les apprenants →';gb.setAttribute('onclick',"EXB_SHELL.openKey('participants')")}
 var K=[['Apprenants',pa.length,delta(pa),'#7c3aed','🎓','participants'],['Formations',fo.length,'Catalogue','#1f6feb','📚','formations'],['Sessions',se.length,'Planning','#f59e0b','🗓️','planning'],['Certificats',ce.length,delta(ce),'#16a34a','📜','certs']];
 $('xhK').innerHTML=kpiHtml(K);
 var t=$('xhChartT');if(t)t.textContent='🎓 Derniers apprenants';
 var c=$('xhChart');if(c)c.innerHTML=pa.length?pa.slice(-8).reverse().map(function(p){return '<div class="xh-act"><div class="ci">🎓</div><div><b>'+esc(p.name||'Apprenant')+'</b><small>'+esc(p.training||'')+'</small></div></div>'}).join(''):'<div class="xh-empty" style="flex:1">Aucun apprenant enregistré pour le moment.</div>';
 var act=$('xhAct');if(act)act.innerHTML='<div class="xh-empty">Pour un reçu de paiement, adressez-vous au comptable.</div>';
 var qa=$('xhQA');if(qa)qa.innerHTML=qaHtml()}
/* V205 lot 3 : tableau de bord de l'Espace Ingénieur (projets, études). « Mes projets » = filtre d'affichage fondé sur affectations_projets (mes_projets) ; ce n'est PAS un contrôle d'accès aux données. */
function ingHome(E){var prj=P(),run=prj.filter(function(p){return stg(p)==='c'}),fin=prj.filter(function(p){return stg(p)==='t'}),nom=function(p){return p.name||p.nom||p.title||p.id||'Projet'};
 var arc=E&&E.dash==='arc';
 var ld=$('xhLead');if(ld)ld.textContent=arc?'Suivez vos projets, vos plans et vos études d’architecture. Les calculs de structure et leur validation restent le métier de l’ingénieur habilité.':'Suivez vos projets, vos études et vos calculs. Les validations de calcul exigent une habilitation d’ingénieur.';
 var gb=$('xhGo');if(gb){gb.textContent='Voir les projets →';gb.setAttribute('onclick',"EXB_SHELL.openKey('projets')")}
 var K=arc?[['Projets en cours',run.length,'Chantiers actifs','#1f6feb','🏗️','projets'],['Plan Editor','','Dessin, cartouches, export','#16a34a','✏️','planEditeur'],['Études & plans','','Bureau d’études, BIM, CDE','#7c3aed','📐','bureauEtudes'],['Clients',Cl().length,'Maîtres d’ouvrage','#f59e0b','👥','clients']]
 :[['Projets en cours',run.length,'Chantiers actifs','#1f6feb','🏗️','projets'],['Projets terminés',fin.length,'Livrés','#16a34a','✅','projets'],['Études & calculs','','Bureau d’études','#7c3aed','📐','bureauEtudes'],['Métré & devis','','Quantités et prix','#f59e0b','🧮','metreDevis']];
 $('xhK').innerHTML=kpiHtml(K);
 var t=$('xhChartT');if(t)t.textContent='🏗️ Projets en cours';
 var c=$('xhChart');if(c)c.innerHTML=run.length?'<div id="exbMesProj" style="width:100%"></div>'+run.slice(0,8).map(function(p){return '<div class="xh-act"><div class="ci">🏗️</div><div><b>'+esc(nom(p))+'</b><small>'+esc(p.status||'')+(p.client?' · '+esc(p.client):'')+'</small></div></div>'}).join(''):'<div class="xh-empty" style="flex:1">Aucun projet en cours.</div>';
 var act=$('xhAct');if(act)act.innerHTML='<div class="xh-empty">'+(arc?'Les modifications de plans et d’études apparaissent dans le journal de l’entreprise.':'Les événements de calcul et de validation apparaissent dans le journal de l’entreprise.')+'</div>';
 var qa=$('xhQA');if(qa)qa.innerHTML=qaHtml();
 /* « Mes projets » : seulement si connecté et si la fonction RPC répond */
 try{var I=w.EXBDB&&w.EXBDB.info&&w.EXBDB.info();if(I&&I.on&&I.org&&w.EXBDB.rpc){w.EXBDB.rpc('mes_projets',{p_org:I.org}).then(function(r){var d0=r&&r.data||r;if(!d0||d0.tous)return;var ids=d0.projets||[],box=$('exbMesProj');if(box)box.innerHTML='<p style="margin:0 0 6px"><b>Mes projets</b> : '+(ids.length?ids.map(esc).join(', '):'aucun projet ne vous est encore affecté')+'</p>'}).catch(function(){})}}catch(e){}}
function renderHome(){var h=$('exbHome');if(!h)return;
 var brand=g(function(){return $('brandNameHeader').textContent.trim()},'Excellencia Building');$('xhBrand').textContent=brand;
 var dt=new Date().toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});$('xhDate').textContent='📅 '+dt.charAt(0).toUpperCase()+dt.slice(1);
 var prj=P(),cl=Cl(),pa=Pa(),unp=parseInt(g(function(){return $('dashUnpaid').textContent},'0'),10)||0,run=prj.filter(function(p){return stg(p)==='c'}).length;
 var pc=parcours(),fo=g(function(){return formations},[]),ce=g(function(){return certs},[]),fin=prj.filter(function(p){return stg(p)==='t'}).length;
 var K=pc==='btp'?[['Projets en cours',run,delta(prj),'#1f6feb','📁','projets'],['Projets terminés',fin,'Livrés','#16a34a','✅','projets'],['Clients',cl.length,delta(cl),'#7c3aed','👥','clients'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','finances']]
 :pc==='for'?[['Apprenants',pa.length,delta(pa),'#7c3aed','🎓','participants'],['Formations',fo.length,'Catalogue','#1f6feb','📚','formations'],['Certificats',ce.length,delta(ce),'#16a34a','📜','certs'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','receipts']]
 :[['Projets en cours',run,delta(prj),'#1f6feb','📁','projets'],['Clients',cl.length,delta(cl),'#16a34a','👥','clients'],['Apprenants',pa.length,delta(pa),'#7c3aed','🎓','participants'],['Paiements en attente',unp,'À encaisser','#f59e0b','📄','receipts']];
 $('xhK').innerHTML=K.map(function(k){return '<div class="xh-k" onclick="show(\''+k[5]+'\')"><div class="xh-bx" style="background:'+k[3]+'">'+k[4]+'</div><div style="flex:1"><small>'+k[0]+'<a>Voir tout →</a></small><b>'+(k[1]<10&&k[1]>0?'0'+k[1]:k[1])+'</b><em>'+esc(k[2])+'</em></div></div>'}).join('');
 /* graphique : cumul des projets créés depuis janvier */
 var forMode=parcours()==='for';if(forMode)prj=pa;
 var yr=String(new Date().getFullYear()),mo=['Jan','Fév','Mar','Avr','Mai','Juin','Juil','Août','Sep','Oct','Nov','Déc'],cm=new Date().getMonth(),dated=prj.filter(function(p){return dateOf(p).slice(0,4)===yr}),
  cnt={c:0,t:0,a:0,x:0};prj.forEach(function(p){cnt[stg(p)]++});
 var leg='<div class="xh-lg"><div><i style="background:#1f6feb"></i>En cours<b>'+cnt.c+'</b></div><div><i style="background:#16a34a"></i>Terminés<b>'+cnt.t+'</b></div><div><i style="background:#f59e0b"></i>En attente<b>'+cnt.a+'</b></div><div><i style="background:#e5352f"></i>Annulés<b>'+cnt.x+'</b></div></div>',svg='';
 if(forMode)leg='<div class="xh-lg"><div><i style="background:#7c3aed"></i>Apprenants inscrits<b>'+pa.length+'</b></div></div>';
 if(dated.length){var pts=[],mx=1,i;for(i=0;i<=cm;i++){var n=dated.filter(function(p){return parseInt(dateOf(p).slice(5,7),10)-1<=i}).length;pts.push(n);if(n>mx)mx=n}
  var st=cm?540/cm:0,XY=pts.map(function(v,i){return [30+i*st,130-v/mx*110]}),L=XY.map(function(a){return a.join(',')}).join(' ');
  svg='<svg viewBox="0 0 600 160"><polygon points="30,130 '+L+' '+XY[XY.length-1][0]+',130" fill="#1f6feb22"/><polyline points="'+L+'" fill="none" stroke="#1f6feb" stroke-width="2"/>'+XY.map(function(a,i){return '<circle cx="'+a[0]+'" cy="'+a[1]+'" r="3.5" fill="#fff" stroke="#1f6feb" stroke-width="2"/><text x="'+a[0]+'" y="150" font-size="11" text-anchor="middle" fill="#6b7a99">'+mo[i]+'</text>'}).join('')+'</svg>'}
 else svg='<div class="xh-empty" style="flex:1">'+(prj.length?'Les dates de création ne sont pas renseignées : la courbe apparaîtra pour les prochains enregistrements.':(forMode?'Aucun apprenant enregistré pour le moment.':'Aucun projet enregistré pour le moment.'))+'</div>';
 $('xhChart').innerHTML='<div class="xh-chart">'+svg+leg+'</div>';
 var al=g(function(){return auditLog},[]).slice(0,5);
 $('xhAct').innerHTML=al.length?al.map(function(a){var t=new Date(a.at),hh=isNaN(t)?'':t.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});return '<div class="xh-act"><div class="ci">'+(/factur|re[cç]u|paiement/i.test(a.action)?'📄':/projet|chantier/i.test(a.action)?'👷':/certif|particip|inscri/i.test(a.action)?'🎓':'🕒')+'</div><div><b>'+esc(a.action)+'</b><small>'+esc(String(a.details||'').slice(0,70))+'</small></div><time>'+hh+'</time></div>'}).join(''):'<div class="xh-empty">Aucune opération enregistrée.</div>';
 var vis={};items().forEach(function(i){vis[i.key]=i});
 var Q=[['bureauEtudes','📐','Bureau d’études','Plans, BIM, CDE'],['metreDevis','🧮','Métré & devis','Études, estimation, chiffrage'],['projets','🏗️','Projets & chantiers','Avancement, suivi, équipes'],['certs','🎓','Apprenants & certificats','Formations, évaluations, diplômes'],['finances','💰','Finance & paiements','Encaissements, moyens de paiement'],['clients','👥','Clients & CRM','Fiches et licences']].filter(function(q){return vis[q[0]]&&!(parcours()==='btp'&&q[0]==='certs')&&!(parcours()==='for'&&['bureauEtudes','metreDevis','projets'].indexOf(q[0])>=0)});
 $('xhQA').innerHTML=Q.map(function(q){return '<div class="q" onclick="show(\''+q[0]+'\')"><span style="font-size:22px">'+q[1]+'</span><div><b>'+q[2]+'</b><small>'+q[3]+'</small></div></div>'}).join('')||'<div class="xh-empty">Aucun raccourci disponible pour votre profil.</div>';
 applyParcours();try{espaceHome()}catch(e){try{console.error('espace',e)}catch(x){}}paintHero();updateBadge()}


/* V99zt : focalisation produit — l'accueil, la bannière et la recherche suivent le parcours choisi (Construction / Formation). */
var TXT={
 btp:{sub:'Vue d’ensemble de vos chantiers, études et finances',lead:'Pilotez vos projets de construction, d’architecture et d’ingénierie : devis, chantiers, plans et suivi financier.',go:'Voir mes projets →',goKey:'projets',tag:'Construire aujourd’hui le monde de demain.',chart:'📊 Évolution des projets',ph:'Rechercher projet, client, devis, plan, document ou référence…',hdr:'Construction · Architecture · Ingénierie'},
 for:{sub:'Vue d’ensemble de votre centre de formation',lead:'Gérez vos apprenants, formations, évaluations et certificats, du dossier d’inscription jusqu’au diplôme.',go:'Voir les apprenants →',goKey:'participants',tag:'Former aujourd’hui les bâtisseurs de demain.',chart:'📊 Évolution des inscriptions',ph:'Rechercher participant, certificat, reçu, paiement, formation ou référence…',hdr:'Centre de formation'},
 all:{sub:'Vue d’ensemble de votre activité',lead:'Votre solution complète pour la gestion de vos projets de construction, d’architecture et d’ingénierie.',go:'Voir mes projets →',goKey:'projets',tag:'Plus qu’un logiciel, une vision pour bâtir l’avenir.',chart:'📊 Évolution des projets',ph:'Rechercher participant, certificat, reçu, paiement, formation, projet, devis, document ou référence…',hdr:''}};
function applyParcours(){var pc=parcours(),t=TXT[pc]||TXT.all,E0=espace();if(E0&&E0.txt)t=Object.assign({},TXT.all,E0.txt);
 function set(id,v){var e=$(id);if(e)e.textContent=v}
 set('xhSub',t.sub);set('xhLead',t.lead);set('xhGo',t.go);set('xhTag',t.tag);set('xhChartT',t.chart);
 var gb=$('xhGo');if(gb)gb.setAttribute('onclick',"show('"+t.goKey+"')");
 var si=$('exbGlobalSearch');if(si)si.placeholder=t.ph;
 var hb=$('brandSubHeader');if(hb){if(!hb.getAttribute('data-orig'))hb.setAttribute('data-orig',hb.textContent);if(t.hdr)hb.textContent=t.hdr;else hb.textContent=hb.getAttribute('data-orig')}
 /* choix du parcours au premier lancement : bandeau non bloquant, une seule fois */
 var pk=$('xhPick');if(pk){var asked=g(function(){return localStorage.getItem('exb_parcours_ask')},null)||roleParcours();
  pk.innerHTML=asked?'':'<div class="xh-card" style="margin:0 0 14px;border-left:4px solid #1f6feb"><h3>🧭 Que souhaitez-vous utiliser ?</h3><p style="margin:0 0 10px;color:#6b7a99;font-size:13px">Choisissez votre parcours : le menu et l’accueil n’afficheront que ce qui vous concerne. Vous pourrez changer à tout moment en haut du menu.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="primary" onclick="EXB_SHELL.pickParcours(\'btp\')">🏗️ Construction / Architecture</button><button class="primary" onclick="EXB_SHELL.pickParcours(\'for\')">🎓 Formation</button><button class="muted" onclick="EXB_SHELL.pickParcours(\'all\')">Tout afficher</button></div></div>'}}

/* V99zt : la recherche globale ne montre que les résultats du parcours (Formation : sans projets/devis ; Construction : sans apprenants/certificats/reçus/formations). */
var OUT={btp:['Participant','Certificat','Reçu','Formation'],for:['Projet','Devis']};
function filterSearch(){var box=$('exbGlobalResults');if(!box)return;var E0=espace(),out=(E0&&E0.out)?E0.out:(OUT[parcours()]||[]);
 Array.prototype.forEach.call(box.querySelectorAll('.exb-search-item'),function(el){var t=el.querySelector('.exb-search-type');el.style.display=(t&&out.indexOf(t.textContent.trim())>=0)?'none':''})}
function watchSearch(){var box=$('exbGlobalResults');if(!box||box.__exbWatch)return;box.__exbWatch=true;try{new MutationObserver(filterSearch).observe(box,{childList:true})}catch(e){}}
function pickParcours(p){try{localStorage.setItem('exb_parcours_ask','1')}catch(e){}setParcours(p)}
/* ---------- Menu latéral, catégories, fil d'Ariane ---------- */
/* V99zg : deux parcours de menu (audit interne) — Construction / Architecture et Formation. « Tout » = comportement d'origine. */
var HIDE={btp:['for'],for:['arc','ing','prj','ach']};
/* V205 (cahier Multi-Espaces, lot 2) : « Espace » métier avec lien propre (/comptable). Menu et tableau de bord limités au métier.
 * Les droits restent appliqués par le SERVEUR (droits_fonction, enregistrer) : ici, seulement le menu, le tableau de bord et le message « accès refusé ». */
/* V205t : types de résultats de la recherche globale masqués dans chaque espace (confort d'affichage : les droits réels restent côté serveur). */
var OUT_EDU=['Participant','Certificat','Formation','Formateur'],OUT_FIN=['Reçu','Paiement','Facture','Avoir','Échéancier'];
var ESPACES={comptable:{t:'Espace Comptable',sub:'Gestion financière et transactions',ic:'🧮',fonctions:['comptable','direction'],
 keys:['finances','exbFinBtn','comptabilite','bcpt','budgetfin','bbfin','decomptes','bdec','receipts','clients','metreDevis','exbMsgrTile_fin','exbwf'],
 txt:{tag:TXT.all.tag,ph:'Rechercher reçu, paiement, facture, client, devis ou référence…',hdr:'Comptabilité & finances'},out:OUT_EDU.concat(['Plan','Étude','Risque','Personnel','Pointage','Stock']),
 home:{ic:'🧾',act:/factur|re[cç]u|paiement|d[ée]pense|caisse|compta|d[ée]compte|encaiss|cl[oô]ture|budget|avoir/i,paste:true,actions:['recu','depense','facture','ecriture','decompte','budget'],todo:['late','unpaid','anom']}},
 ingenieur:{t:'Espace Ingénieur',sub:'Études, calculs et suivi technique des projets',ic:'📐',fonctions:['bureau_etudes','chef_projet','conducteur','direction'],cats:['ing','arc','prj'],dash:'ing',keys:['exbwf'],
 txt:{tag:TXT.btp.tag,ph:'Rechercher projet, client, devis, plan, étude ou référence…',hdr:'Ingénierie & structure'},out:OUT_EDU.concat(OUT_FIN,['Personnel','Pointage','Stock']),
 home:{ic:'📐',act:/calcul|[ée]tude|plan|projet|chantier|structure|devis|m[ée]tr|valid|b[ée]ton/i,actions:['calcul','etude','plan','devis','projet','tache'],todo:['task','docs','anom']}},
 /* V205 lot 4 : Espace Architecture. Même mécanisme ; fonction « architecte » (migration-v205-lot4-architecture.sql). Pas de calcul de structure, ni finance, stock, RH, formation. */
 architecte:{t:'Espace Architecture',sub:'Conception, plans, BIM et suivi architectural des projets',ic:'🏛️',fonctions:['architecte','chef_projet','bureau_etudes','direction'],cats:['arc','prj'],dash:'arc',
 keys:['clients','documents','metreDevis','exbwf'],hors:['bchan','bterr','plangantt','pilotprojet','exbMsgrTile_prj'],
 txt:{tag:TXT.btp.tag,ph:'Rechercher projet, plan, client, devis, document ou référence…',hdr:'Architecture & BIM'},out:OUT_EDU.concat(OUT_FIN,['Personnel','Pointage','Stock','Fournisseur']),
 home:{ic:'🏛️',act:/plan|projet|[ée]tude|cartouche|bim|architect|document|client|devis/i,paste:true,actions:['plan','pdfplan','cartouche','etude','devis','client'],todo:['task','docs','anom']}},
 /* V205 lot 5b : Espace Formation = TOUT le module Formation (catégorie « for » : apprenants, formations, formateurs, sessions, présences, évaluations, certificats, TFL, portail apprenant…)
  * SAUF le reçu de paiement, établi par le comptable (Espace Comptable › Reçus de paiement). Le formateur de terrain garde son portail à matricule (/espace-formateur). */
 formation:{t:'Espace Formation',sub:'Apprenants, formations, sessions, évaluations et certificats',ic:'🎓',fonctions:['formateur','direction'],cats:['for'],dash:'for',keys:['exbwf'],hors:['receipts'],
 txt:{tag:TXT.for.tag,ph:TXT.for.ph,hdr:TXT.for.hdr},out:['Projet','Devis','Client','Métré','Plan','Étude','Risque','Stock','Fournisseur','Personnel','Pointage'].concat(OUT_FIN),
 home:{ic:'🎓',act:/particip|inscri|certif|formation|[ée]valu|pr[ée]sence|session|planning|apprenant|cotation|formateur|tfl|tp\b|td\b|matricule/i,actions:['inscription','session','presence','evaluation','certificat','formation'],todo:['sessions','anom']},
 horsMsg:'Le reçu de paiement est établi par le comptable (Espace Comptable › Reçus de paiement).'},
 /* V205 lot 6 : Espace Chantier (seul) — conducteur de travaux, chef de projet. Toute la catégorie Projets & Chantiers + permis, pièces écrites, maintenance, stock. */
 chantier:{t:'Espace Chantier',sub:'Projets, chantiers, planning, terrain, contrôles et réception',ic:'🏗️',fonctions:['conducteur','chef_projet','direction'],cats:['prj'],dash:'chn',
  keys:['exbPerBtn','exbPieBtn','exbV74Btn','stock','bstkp','documents','exbMsgrTile_prj','exbwf'],
  txt:{tag:TXT.btp.tag,ph:'Rechercher projet, chantier, plan, document ou référence…',hdr:'Projets & chantiers'},out:OUT_EDU.concat(OUT_FIN,['Personnel','Devis','Métré','Client']),
  home:{ic:'🏗️',act:/chantier|projet|terrain|contr[oô]le|r[ée]ception|stock|permis|maintenance|t[aâ]che|planning/i,actions:['projet','tache','controle','reception','planning','stock'],todo:['task','docs','anom']}},
 /* V205 lot 6 : Espace Direction = Direction + Commercial (clients, CRM, portails, site vitrine, devis). */
 direction:{t:'Espace Direction',sub:'Pilotage, indicateurs, clients et relations commerciales',ic:'🧭',fonctions:['direction'],cats:['crm'],dash:'dir',
  keys:['direction','enterprise360','exbbi','exbwf','exbPilBtn','bsup','exbV69Btn','reports','communication','exbActBtn','portails','bvit','inscBatch','metreDevis','bcs_dev','bautodevis','exbMsgrTile_ent','exbMsgrTile_crm'],
  txt:{tag:TXT.all.tag,ph:'Rechercher projet, client, devis, apprenant, paiement ou référence…',hdr:'Direction & pilotage'},out:[],
  home:{ic:'🧭',act:null,paste:true,actions:['bi','rapport','crm','workflow','client','devis'],todo:['late','unpaid','licences','sessions','anom']}},
 /* V205 lot 6 : Espace Administration = Administration + RH. Le personnel & la paie pour la fonction RH ; les réglages, sauvegardes et audit
  * ne sont montrés qu'à l'administrateur et à la direction (liste « reserve »). */
 administration:{t:'Espace Administration',sub:'Personnel, paie, documents, sécurité et paramètres',ic:'🛡️',fonctions:['rh','direction'],cats:[],dash:'adm',
  keys:['rh','exbPayBtn','documents','communication','exbMsgrTile_ent','exbwf','exbar','exbsc','dataStorage','exbContBtn','exbAuBtn','registry','exbSecBtn','cloudSync','bv51','logoexb','logordc','affiches','administration','badm2','settings'],
  reserve:{fonctions:['direction'],keys:['exbar','exbsc','dataStorage','exbContBtn','exbAuBtn','registry','exbSecBtn','cloudSync','bv51','logoexb','logordc','affiches','administration','badm2','settings']},
  txt:{tag:TXT.all.tag,ph:TXT.all.ph,hdr:''},out:[],
  home:{ic:'🛡️',act:/personnel|paie|salari|sauvegard|param[eè]tre|s[ée]curit|archive|document|connexion|utilisateur|[ée]quipe|licence|restaur/i,actions:['personnel','paie','doc','sauvegarde','parametres'],todo:['docs','licences','anom']}},
 /* V205 lot 7 : Espace Magasin — magasinier. Stock, dépôts, inventaires, comparatifs, achats de terrain, documents. */
 magasin:{t:'Espace Magasin',sub:'Stock, mouvements, inventaires, achats et approvisionnement',ic:'📦',fonctions:['magasinier','direction'],cats:['ach'],dash:'mag',keys:['bterr','documents','exbMsgrTile_ach','exbwf'],
  txt:{tag:TXT.btp.tag,ph:'Rechercher article, matériau, fournisseur, document ou référence…',hdr:'Stock & approvisionnement'},out:OUT_EDU.concat(OUT_FIN,['Projet','Devis','Métré','Client','Plan','Étude','Risque','Personnel']),
  home:{ic:'📦',act:/stock|mat[ée]riau|inventaire|d[ée]p[oô]t|achat|fournisseur|mouvement|approvision|livraison/i,actions:['stock','depot','achat','doc'],todo:['docs','anom']}}};
/* Écran interdit dans l'espace actif (ex. reçu de paiement dans l'Espace Formation) : refus + message. Confort d'affichage : les droits réels restent côté serveur. */
function espaceRefuse(k){var e=espace();if(!e||!e.hors||e.hors.indexOf(k)<0||!e.horsMsg)return false;try{w.notify(e.horsMsg,'warn',6000)}catch(x){}return true}
function espaceKey(){var k='';try{k=w.localStorage.getItem('exb_espace')||''}catch(e){}return ESPACES[k]?k:''}
function espace(){var k=espaceKey();return k?ESPACES[k]:null}
function setEspace(k){try{if(k&&ESPACES[k])w.localStorage.setItem('exb_espace',k);else w.localStorage.removeItem('exb_espace')}catch(e){}markEspace()}
function markEspace(){try{d.documentElement.classList.toggle('exb-espace',!!espaceKey())}catch(e){}}
function espaceAcces(){var e=espace();if(!e)return {ok:true};var i=g(function(){return w.EXBDB.info()},{on:false});
 if(!i.on||i.role==='admin')return {ok:true};return e.fonctions.indexOf(i.fonction)>=0?{ok:true}:{ok:false,fonction:i.label||i.fonction||''}}
function espaceReserve(e,k){if(!e.reserve||e.reserve.keys.indexOf(k)<0)return false;var i=g(function(){return w.EXBDB.info()},{on:false});
 if(!i.on||i.role==='admin')return false;return e.reserve.fonctions.indexOf(i.fonction)<0}
function espaceFilter(out){var e=espace();if(!e)return out;if(!espaceAcces().ok)return [];return out.filter(function(i){return !(e.hors&&e.hors.indexOf(i.key)>=0)&&!espaceReserve(e,i.key)&&(e.keys.indexOf(i.key)>=0||(e.cats&&e.cats.indexOf(i.cat)>=0))})}
function quitEspace(){setEspace('');try{w.location.replace('index.html')}catch(e){w.location.href='index.html'}}
/* V99zt : sans choix explicite, le parcours découle de la fonction de l'utilisateur (formateur → Formation ; conducteur, chef de projet, bureau d'études → Construction) */
function roleParcours(){var r=String(roleLabel()||'').toLowerCase();if(/formateur|apprenant/.test(r))return 'for';if(/conducteur|chef de projet|bureau d|ing[eé]nieur|architect/.test(r))return 'btp';return ''}
function parcours(){var p=g(function(){return localStorage.getItem('exb_parcours')},'');if(p==='btp'||p==='for'||p==='all')return p;return roleParcours()||'all'}
function setParcours(p){try{localStorage.setItem('exb_parcours',p)}catch(e){}if(HIDE[p]&&HIDE[p].indexOf(curCat)>=0)curCat='home';renderSide();try{renderHome()}catch(e){}}
function visCats(){var h=HIDE[parcours()]||[];return CATS.filter(function(c){return h.indexOf(c.k)<0})}
function catBtn(c,sub){return '<button class="xs'+(sub?' sub':'')+(c.k===curCat?' on':'')+'" onclick="EXB_SHELL.openCat(\''+c.k+'\')"><span class="ic">'+c.i+'</span>'+esc(c.t)+(c.k==='home'?'':'<span class="ch">›</span>')+'</button>'}
function divBtn(v){return '<button class="xd'+(v.k===curCat?' on':'')+'" onclick="EXB_SHELL.openDiv(\''+v.k+'\')"><span class="ic">'+v.i+'</span>'+esc(v.t)+'</button>'}
function sideBody(){var E=espace();
 if(E){var ac=espaceAcces(),hm=CATS[0];
  if(!ac.ok)return '<button class="xs on" onclick="EXB_SHELL.openCat(\'home\')"><span class="ic">🏠</span>Accueil</button><button class="xs" onclick="EXB_SHELL.quitEspace()"><span class="ic">⎋</span>Quitter l’espace</button>';
  return catBtn(hm,false)+items().map(function(i){return '<button class="xs'+(i.key===lastKey?' on':'')+'" onclick="EXB_SHELL.goKey(\''+i.key+'\')"><span class="ic">'+esc(i.ic)+'</span>'+esc(i.label)+'</button>'}).join('')+'<button class="xs" onclick="window.EXBOperateur&&EXBOperateur.open()"><span class="ic">🪪</span>Mon profil opérateur</button><button class="xs" onclick="EXB_SHELL.quitEspace()"><span class="ic">⎋</span>Quitter l’espace</button>'}
 var vc=visCats(),h='';
 vc.filter(function(c){return c.k==='home'}).forEach(function(c){h+=catBtn(c,false)});
 DIVS.forEach(function(v){var cs=vc.filter(function(c){return v.cats.indexOf(c.k)>=0});
  if(v.cats.length&&!cs.length)return;h+=divBtn(v)+cs.map(function(c){return catBtn(c,true)}).join('')+(v.k==='dv_for'?espBtn():'')});
 return h}
function renderSide(){var s=$('exbSide');if(!s)return;var pc=parcours();
 s.innerHTML=(espace()?'<div class="xpar"><button class="on" disabled>'+esc(espace().ic+' '+espace().t)+'</button></div>':'<div class="xpar">'+[['all','Tout'],['btp','🏗️ Construction'],['for','🎓 Formation']].map(function(x){return '<button class="'+(pc===x[0]?'on':'')+'" onclick="EXB_SHELL.setParcours(\''+x[0]+'\')">'+x[1]+'</button>'}).join('')+'</div>')+sideBody()+
  '<div class="xsf"><b>'+esc(g(function(){return $('brandNameHeader').textContent.trim()},'Excellencia Building'))+'</b>'+esc(g(function(){var I=EXBId.get();return I.name.toLowerCase()==='excellencia building'?'Construire aujourd’hui — le monde de demain':I.tagline},''))+'</div>'}
function setActive(k){curCat=k;renderSide()}
function closeDrawer(){var s=$('exbSide');if(s)s.classList.remove('on')}
/* ---------- Historique (Retour / Avant) ---------- */
function navBtns(){var b=$('xbBack'),f=$('xbFwd');if(b)b.disabled=hi<=0;if(f)f.disabled=hi>=hist.length-1}
function rec(st){if(navBusy)return;var c=hist[hi];if(c&&c.t===st.t&&c.v===st.v)return;
 hist=hist.slice(0,hi+1);hist.push(st);if(hist.length>60)hist.shift();hi=hist.length-1;navBtns()}
function restore(st){navBusy=true;try{if(st.t==='c')openCat(st.v);else if(st.t==='d')openDiv(st.v);else if(st.t==='e')openEspace(st.v);else if(st.t==='b')goKey(st.v);else w.show(st.v)}catch(e){}finally{navBusy=false}navBtns();try{w.scrollTo(0,0)}catch(e){}}
function back(){if(hi>0){hi--;restore(hist[hi])}}
function forward(){if(hi<hist.length-1){hi++;restore(hist[hi])}}
/* ---------- Barre horizontale des modules de la catégorie ---------- */
function barOverflow(){var mb=$('exbModBar');if(!mb)return;var i=mb.querySelector('.mb-in');mb.classList.toggle('ov',!!i&&i.scrollWidth>i.clientWidth+4)}
function renderModBar(k,x){var mb=$('exbModBar');if(!mb)return;
 var list=(!k||k==='home')?[]:catList(k);
 if(list.length<2||!x||!list.some(function(i){return i.key===x})){mb.style.display='none';mb.innerHTML='';mb.classList.remove('ov');return}
 mb.innerHTML='<button class="mb-ar l" type="button" aria-label="Modules précédents" onclick="EXB_SHELL.scrollBar(-1)">‹</button><div class="mb-in" role="tablist" aria-label="Modules">'+
  list.map(function(i,n){var on=i.key===x;return '<button class="mb'+(on?' on':'')+'" type="button" role="tab" aria-selected="'+on+'" onclick="EXB_SHELL.go('+n+',\''+k+'\')"><i>'+esc(i.ic)+'</i>'+esc(i.label)+'</button>'}).join('')+
  '</div><button class="mb-ar r" type="button" aria-label="Modules suivants" onclick="EXB_SHELL.scrollBar(1)">›</button>';
 mb.style.display='block';
 var inn=mb.querySelector('.mb-in'),on=mb.querySelector('.mb.on');
 if(inn&&on)inn.scrollLeft=Math.max(0,on.offsetLeft-(inn.clientWidth-on.offsetWidth)/2);
 barOverflow()}
function scrollBar(dir){var i=d.querySelector('#exbModBar .mb-in');if(i)i.scrollBy({left:dir*Math.max(180,i.clientWidth*.6),behavior:'smooth'})}
function openCat(k){closeDrawer();if(k==='home'){w.show('dashboard');return}
 var c=cat(k),list=catList(k),hub=$('exbHub');if(!hub||!orig)return;
 hub.innerHTML='<div class="xh-crumb">Accueil › '+esc(c.t)+'</div><h1>'+c.i+' '+esc(c.t)+'</h1><p style="margin:0;color:#6b7a99">'+esc(c.d||'')+'</p><div class="xg">'+
  (list.length?list.map(function(i,n){return '<button class="c" onclick="EXB_SHELL.go('+n+',\''+k+'\')"><i>'+esc(i.ic)+'</i><div><b>'+esc(i.label)+'</b><small>'+esc(i.d)+'</small></div></button>'}).join(''):'<div class="xh-empty">Rien à afficher ici pour votre profil.</div>')+'</div>';
 hubFlag=true;try{orig.call(w,'exbHub')}finally{hubFlag=false}
 Array.prototype.forEach.call(hub.parentNode.children,function(el){if(el.tagName==='SECTION'&&el!==hub)el.style.display='none'});
 var hm=$('exbHome');if(hm)hm.style.display='none';var cr=$('exbCrumb');if(cr)cr.style.display='none';
 hub.style.display='';lastKey='exbHub';hideRescued();renderModBar(null,null);setActive(k);rec({t:'c',v:k});w.scrollTo(0,0)}
function openDiv(k){closeDrawer();var v=divInfo(k),hub=$('exbHub');if(!v||!hub||!orig)return;
 var hid=HIDE[parcours()]||[],seenL={},list=items().filter(function(i){return divOf(i)===k&&hid.indexOf(i.cat)<0&&!/^exbMsgrTile_/.test(i.key)});
 var order=CATS.map(function(c){return c.k}),cats=order.filter(function(ck){return list.some(function(i){return i.cat===ck})}),body='';
 /* V186 — cahier §Formation : deux espaces fonctionnels (formations classiques / parcours TFL) + module Certificats dédié */
 if(k==='dv_for'){var SP=[['cls','📚','Formations classiques','Inscriptions, participants, formations, planning, présences, évaluations'],['tfl','🎯','Parcours TFL','Travaux de fin de licence : sujets, candidatures, banque, bibliothèque, contributions'],['cer','📜','Certificats','Certificats, statuts (valide, suspendu, révoqué), impression groupée']];
  var spOf=function(i){return /^(certs|bulk)$/.test(i.key)?'cer':(/^tflSec$/.test(i.key)||/\bTFL\b/.test(i.label||''))?'tfl':'cls'};
  SP.forEach(function(sp){var li=list.filter(function(i){return spOf(i)===sp[0]});if(!li.length)return;
   body+='<div class="xdg" data-espace="'+sp[0]+'">'+sp[1]+' '+sp[2]+' <span style="text-transform:none;font-weight:400;letter-spacing:0">— '+esc(sp[3])+'</span></div>'+(sp[0]==='tfl'?'<div class="xg">'+tflTiles()+'</div>':'<div class="xg">'+li.map(function(i){return '<button class="c" onclick="EXB_SHELL.goKey(\''+i.key+'\')"><i>'+esc(i.ic)+'</i><div><b>'+esc(i.label)+'</b><small>'+esc(i.d)+'</small></div></button>'}).join('')+'</div>')});
  cats=[]}
 cats.forEach(function(ck){var c=cat(ck);body+=(cats.length>1?'<div class="xdg">'+c.i+' '+esc(c.t)+'</div>':'')+'<div class="xg">'+list.filter(function(i){return i.cat===ck}).map(function(i){return '<button class="c" onclick="EXB_SHELL.goKey(\''+i.key+'\')"><i>'+esc(i.ic)+'</i><div><b>'+esc(i.label)+'</b><small>'+esc(i.d)+'</small></div></button>'}).join('')+'</div>'});
 hub.innerHTML='<div class="xh-crumb">Accueil › '+esc(v.t)+'</div><h1>'+v.i+' '+esc(v.t)+'</h1><p style="margin:0;color:#6b7a99">'+esc(v.d)+'</p>'+(body||'<div class="xg"><div class="xh-empty">Rien à afficher ici pour votre profil.</div></div>');
 hubFlag=true;try{orig.call(w,'exbHub')}finally{hubFlag=false}
 Array.prototype.forEach.call(hub.parentNode.children,function(el){if(el.tagName==='SECTION'&&el!==hub)el.style.display='none'});
 var hm=$('exbHome');if(hm)hm.style.display='none';var cr=$('exbCrumb');if(cr)cr.style.display='none';
 hub.style.display='';lastKey='exbHub';hideRescued();renderModBar(null,null);setActive(k);rec({t:'d',v:k});w.scrollTo(0,0)}
function openEspace(e){closeDrawer();if(e!=='tfl')return;var hub=$('exbHub');if(!hub||!orig)return;
 hub.innerHTML='<div class="xh-crumb">Accueil › Formation &amp; académie › Parcours TFL</div><h1>🎯 Parcours TFL</h1><p style="margin:0;color:#6b7a99">Travaux de fin de licence : dossiers et candidatures, sujets, bibliothèque, encadreurs, frais, portails et signatures.</p><div class="xdg" data-espace="tfl">🎯 Parcours TFL</div><div class="xg">'+tflTiles()+'</div>';
 hubFlag=true;try{orig.call(w,'exbHub')}finally{hubFlag=false}
 Array.prototype.forEach.call(hub.parentNode.children,function(el){if(el.tagName==='SECTION'&&el!==hub)el.style.display='none'});
 var hm=$('exbHome');if(hm)hm.style.display='none';var cr=$('exbCrumb');if(cr)cr.style.display='none';
 hub.style.display='';lastKey='exbHub';hideRescued();renderModBar(null,null);setActive('esp_tfl');rec({t:'e',v:e});w.scrollTo(0,0)}
function goTfl(vue){try{if(typeof w.exbTflOpen==='function')w.exbTflOpen({vue:vue})}catch(e){}goKey('tflSec')}
function goItem(it,k){if(!it)return;
 var direct=!/show\('/.test(it.btn.getAttribute('onclick')||'');
 if(!direct){it.btn.click();return}
 /* module qui affiche sa page lui-même (V67–V72…) : on masque d'abord les autres pages, puis on le laisse s'afficher */
 hubFlag=true;try{orig('exbHub')}catch(e){}hubFlag=false;
 rescued.forEach(function(id){var e=$(id);if(e)e.style.display='none'});lastKey=it.key;
 it.btn.click();
 var hub=$('exbHub'),hm=$('exbHome');if(hub)hub.style.display='none';if(hm)hm.style.display='none';
 setActive(k||curCat);renderCrumb(it.key,k);renderModBar(k,it.key);closeDrawer();rec({t:'b',v:it.key});try{w.scrollTo(0,0)}catch(e){}}
function go(n,k){var list=catList(k);if(list[n])goItem(list[n],k)}
function goKey(key){var it=items().filter(function(i){return i.key===key})[0];if(it)goItem(it,it.cat)}
function renderCrumb(x,k){var cr=$('exbCrumb');if(!cr)return;
 if(x==='dashboard'||!k){cr.style.display='none';return}
 var E0=espace();if(E0&&espaceAcces().ok){var it0=items().filter(function(i){return i.key===x})[0];cr.innerHTML='<button onclick="show(\'dashboard\')">← Accueil</button><span>Accueil › '+esc(E0.t)+(it0?' › '+esc(it0.label):'')+'</span>';cr.style.display='flex';return}
 var c=cat(k),it=items().filter(function(i){return i.key===x})[0],dv=DIV_ITEM[x]&&DIV_ITEM[x]!==CAT_DIV[k]?divInfo(DIV_ITEM[x]):null;
 if(x==='tflSec'){cr.innerHTML='<button onclick="EXB_SHELL.openEspace(\'tfl\')">← Parcours TFL</button><span>Accueil › Formation &amp; académie › Parcours TFL › TFL</span>';cr.style.display='flex';return}
 if(dv){cr.innerHTML='<button onclick="EXB_SHELL.openDiv(\''+dv.k+'\')">← '+esc(dv.t)+'</button><span>Accueil › '+esc(dv.t)+(it?' › '+esc(it.label):'')+'</span>';cr.style.display='flex';return}
 cr.innerHTML='<button onclick="EXB_SHELL.openCat(\''+k+'\')">← '+esc(c.t)+'</button><span>Accueil › '+esc(c.t)+(it?' › '+esc(it.label):'')+'</span>';cr.style.display='flex'}
function after(x){if(hubFlag)return;var hub=$('exbHub');if(hub)hub.style.display='none';var hm=$('exbHome');
 if(x==='notifications'){sset('exb_notif_seen',String(Date.now()));updateBadge();setActive('home');var cr=$('exbCrumb');if(cr){cr.innerHTML='<button onclick="show(\'dashboard\')">← Accueil</button><span>Accueil › Notifications</span>';cr.style.display='flex'}if(hm)hm.style.display='none';renderModBar(null,null);return}
 if(hm)hm.style.display=x==='dashboard'?'':'none';if(x==='dashboard')renderHome();
 var k=x==='dashboard'?'home':catOf(x);setActive(k||curCat);renderCrumb(x,k==='home'?null:k);renderModBar(k==='home'?null:k,x);closeDrawer()}

/* ---------- Notifications, état du système ---------- */
function updateBadge(){var b=$('xbBadge');if(!b)return;var seen=parseInt(sget('exb_notif_seen','0'),10)||0,
 n=g(function(){return exbNotifications},[]).filter(function(x){var t=Date.parse(x&&(x.at||x.date||x.time||x.ts||x.created_at));return t&&t>seen}).length;b.textContent=n?(n>99?'99+':String(n)):''}
function lastBackup(){var v=sget('exb_last_backup','');if(!v)return 'jamais';var t=/^\d+$/.test(v)?new Date(+v):new Date(v);if(isNaN(t))return '—';
 var td=new Date(),hh=t.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});return t.toDateString()===td.toDateString()?'Aujourd’hui à '+hh:t.toLocaleDateString('fr-FR')+' à '+hh}
function renderStatus(){var s=$('exbStatus');if(!s)return;var on=w.navigator.onLine!==false;
 s.innerHTML='<span class="'+(on?'xok':'xko')+'">● '+(on?'Système opérationnel':'Hors connexion (données conservées sur cet appareil)')+'</span><span class="xs2">Dernière sauvegarde : '+esc(lastBackup())+'</span><span>Version : '+VERSION+'</span><span class="xs2" style="margin-left:auto"><b>Excellencia Building</b> – Ensemble vers l’excellence</span>'}

/* ---------- Installation ---------- */
function build(){var app=$('app'),hd=app&&app.querySelector(':scope > header'),dash=$('dashboard');if(!app||!hd||!dash||$('exbSide'))return false;
 injectCss();
 var burger=d.createElement('button');burger.id='exbBurger';burger.type='button';burger.setAttribute('aria-label','Menu');burger.textContent='☰';burger.onclick=function(){var s=$('exbSide');if(s)s.classList.toggle('on')};hd.insertBefore(burger,hd.firstChild);
 var sr=d.querySelector('.exb-pro-search');if(sr){hd.insertBefore(sr,hd.querySelector('.logout'));var inp=sr.querySelector('input');if(inp)inp.placeholder='Rechercher un participant, un projet, un document…'}
 var top=d.createElement('div');top.id='xbTop';
 top.innerHTML='<button class="xb" id="xbBell" type="button" aria-label="Notifications" onclick="show(\'notifications\')">🔔<i id="xbBadge"></i></button><button class="xb" id="xbHelp" type="button" aria-label="Aide" onclick="EXB_SHELL.help()">❓</button><button class="xb" id="xbTheme" type="button" aria-label="Changer de thème" title="Changer de thème" onclick="window.EXB_THEME&&EXB_THEME.toggle()"></button>'+
  '<div class="xprof"><button id="xbProf" type="button" onclick="EXB_SHELL.profMenu()"><span id="xbAv" class="xav"></span><span class="xpn"><b id="xbName"></b><small id="xbRole"></small></span><span>⌄</span></button>'+
  '<div class="xmenu" id="xbMenu"><button onclick="EXB_SHELL.changePhoto()">📷 Changer ma photo</button><button onclick="EXB_SHELL.removePhoto()">🗑️ Retirer ma photo</button><button onclick="EXB_SHELL.editName()">✏️ Modifier mon nom</button><button onclick="window.EXBOperateur&&EXBOperateur.open();this.parentNode.classList.remove(\'on\')">🪪 Mon profil opérateur</button><button onclick="EXB_SHELL.logout()">🚪 Déconnexion</button></div></div>';
 hd.insertBefore(top,hd.querySelector('.logout'));
 var nav=d.createElement('div');nav.id='xbNav';nav.className='no-print';
 nav.innerHTML='<button class="xnb" id="xbBack" type="button" aria-label="Retour" title="Retour (Alt + ←)" disabled onclick="EXB_SHELL.back()">'+ICO.l+'</button><button class="xnb" id="xbFwd" type="button" aria-label="Avant" title="Avant (Alt + →)" disabled onclick="EXB_SHELL.forward()">'+ICO.r+'</button>';
 hd.insertBefore(nav,sr||top);
 var side=d.createElement('nav');side.id='exbSide';side.className='no-print';side.setAttribute('aria-label','Menu principal');hd.parentNode.insertBefore(side,hd.nextSibling);
 var wrap=dash.parentNode,cr=d.createElement('div');cr.id='exbCrumb';cr.className='no-print';wrap.insertBefore(cr,dash);
 var mbar=d.createElement('nav');mbar.id='exbModBar';mbar.className='no-print';mbar.setAttribute('aria-label','Modules de la catégorie');wrap.insertBefore(mbar,dash);
 var home=d.createElement('section');home.id='exbHome';home.className='xh no-print';home.style.display='none';
 home.innerHTML='<div class="xh-head"><div><div class="xh-crumb">Accueil</div><h1>Tableau de bord</h1><p id="xhSub">Vue d’ensemble de votre activité</p></div><div class="xh-date" id="xhDate"></div></div><div id="xhPick"></div>'+
  '<div class="xh-hero"><div class="xh-hl"><small>Bienvenue dans</small><img id="xhLogo" alt="" src="'+esc(g(function(){return w.exbLogoSrc?w.exbLogoSrc():'icon-192.png'},'icon-192.png'))+'" style="width:54px;height:54px;object-fit:contain;background:#fff;border-radius:12px;padding:4px;margin:6px 0"><h2 id="xhBrand">Excellencia Building</h2><p id="xhLead">Votre solution complète pour la gestion de vos projets de construction, d’architecture et d’ingénierie.</p><button class="xh-btn" id="xhGo" type="button" onclick="show(\'projets\')">Voir mes projets →</button></div><div class="xh-img" id="xhImg"></div><div class="xh-tag" id="xhTag">Plus qu’un logiciel, une vision pour bâtir l’avenir.</div><button class="xh-cam" type="button" onclick="EXB_SHELL.bannerPicker()">📷 Changer la photo</button></div>'+
  '<div class="xh-kpis" id="xhK"></div><div class="xh-cols"><div class="xh-card"><h3 id="xhChartT">📊 Évolution des projets</h3><div id="xhChart"></div></div><div class="xh-card"><h3>🕒 Activité récente <a onclick="show(\'notifications\')">Voir tout →</a></h3><div id="xhAct"></div></div></div>'+
  '<div class="xh-card"><h3>⚡ Accès rapide</h3><div class="xh-qa" id="xhQA"></div></div>';
 wrap.insertBefore(home,dash);
 var hub=d.createElement('section');hub.id='exbHub';hub.className='no-print';hub.style.display='none';wrap.insertBefore(hub,dash);
 var st=d.createElement('div');st.id='exbStatus';st.className='no-print';app.appendChild(st);
 d.addEventListener('click',function(e){var m=$('xbMenu');if(m&&m.classList.contains('on')&&!e.target.closest('.xprof'))m.classList.remove('on');var s=$('exbSide');if(s&&s.classList.contains('on')&&!e.target.closest('#exbSide,#exbBurger'))s.classList.remove('on')});
 w.addEventListener('online',renderStatus);w.addEventListener('offline',renderStatus);w.addEventListener('resize',barOverflow);
 d.addEventListener('keydown',function(e){if(!e.altKey||e.ctrlKey||e.metaKey||e.shiftKey)return;if(e.key==='ArrowLeft'){e.preventDefault();back()}else if(e.key==='ArrowRight'){e.preventDefault();forward()}});
 renderProfile();renderSide();renderStatus();updateBadge();if(w.EXB_THEME&&w.EXB_THEME.refresh)w.EXB_THEME.refresh();return true}
function install(){if(w.__exbShellV99r||typeof w.show!=='function')return;
 try{var qe=new URLSearchParams(w.location.search);if(qe.has('espace')){setEspace(qe.get('espace'));w.history.replaceState(null,'',w.location.pathname+w.location.hash)}}catch(e){}
 markEspace();if(!build())return;w.__exbShellV99r=true;
 orig=w.show;w.show=function(x){if(!hubFlag&&x&&espaceRefuse(String(x)))return;var r=orig.apply(this,arguments);try{if(!hubFlag&&x){lastKey=String(x);hideRescued()}}catch(e){}try{after(x)}catch(e){}try{if(!hubFlag&&x)rec({t:'v',v:String(x)})}catch(e){}return r};
 rec({t:'v',v:'dashboard'});watchSearch();
 /* V99y : les modules V67–V72 (Projet 360°, Priorité 2 CDE/BIM/EVM, Intelligence BTP, Plans & Structure, Feuilles de plans, Plans/PDF) ajoutent leur page dans le premier .wrap,
    devenu le conteneur masqué des onglets : leurs pages restaient invisibles. On les replace dans la zone de contenu (sans modifier ces modules). */
 function rescue(){try{var dh=$('dashboard'),host=dh&&dh.parentNode,tb=d.querySelector('#app>.wrap.no-print');if(!host||!tb||tb===host)return;[].slice.call(tb.children).forEach(function(c){if(c.tagName==='SECTION'){host.appendChild(c);if(c.id&&rescued.indexOf(c.id)<0)rescued.push(c.id)}});hideRescued()}catch(e){}}
 rescue();try{var tw=d.querySelector('#app>.wrap.no-print');if(tw)new MutationObserver(rescue).observe(tw,{childList:true})}catch(e){}
 try{var mo=new MutationObserver(function(){clearTimeout(mo.t);mo.t=setTimeout(function(){renderSide()},300)});var tb=d.querySelector('#app .tabs');if(tb)mo.observe(tb,{attributes:true,subtree:true,childList:true,attributeFilter:['style','hidden','class']})}catch(e){}
 var dsh=$('dashboard');if(dsh&&dsh.style.display!=='none'){var hm=$('exbHome');if(hm)hm.style.display='';renderHome()}
 setInterval(function(){renderStatus();updateBadge()},60000)}
w.EXB_SHELL={openKey:openKey,espaceCfg:function(){var e=espace();return e&&e.home?{key:espaceKey(),actions:(e.home.actions||[]).slice(),todo:(e.home.todo||[]).slice(),paste:!!e.home.paste}:null},espaceHas:function(k){try{return items().some(function(i){return i.key===k})}catch(e){return false}},espaces:function(){return ESPACES},espace:function(){return espaceKey()},espaceRefuse:espaceRefuse,setEspace:setEspace,quitEspace:quitEspace,espaceAcces:espaceAcces,items:items,filterSearch:filterSearch,roleParcours:roleParcours,pickParcours:pickParcours,applyParcours:applyParcours,setParcours:setParcours,parcours:parcours,install:install,openCat:openCat,openDiv:openDiv,openEspace:openEspace,goTfl:goTfl,divisions:function(){return DIVS.map(function(v){return {k:v.k,t:v.t,cats:v.cats.slice()}})},divOf:divOf,go:go,goKey:goKey,back:back,forward:forward,scrollBar:scrollBar,help:help,profMenu:profMenu,changePhoto:changePhoto,removePhoto:removePhoto,editName:editName,logout:doLogout,bannerPicker:bannerPicker,updateBadge:updateBadge,setBanner:setBanner,importBanner:importBanner,closeModal:closeModal,version:VERSION};
function start(){setTimeout(install,350)}
if(d.readyState==='complete')start();else w.addEventListener('load',start)
})(window,document);
