/* Excellencia Building V209f — ARCHITECTURE : contrôle réglementaire paramétrable.
 * Cahier des charges Évolution ERP V1.0, §5.2 : « Contrôle réglementaire — règles paramétrables par pays / commune / projet ; signalement des points à vérifier » (P2).
 *
 *  • AUCUNE règle, aucun seuil, aucune valeur légale n’est préenregistré : tout est saisi par l’utilisateur, avec sa SOURCE (texte, article, lien), son statut
 *    (à valider / validée / obsolète) et sa date de fin de validité.
 *  • MODÈLES (bibliothèque commune de l’entreprise, par pays ou par commune) : réutilisables ; « Appliquer au projet » COPIE les modèles correspondant au pays /
 *    à la commune du cadre de V209e. La copie est un instantané : modifier un modèle ne change jamais silencieusement un contrôle déjà fait.
 *  • RÈGLES DU PROJET : indicateur (CES, COS, emprise, surface brute / utile, terrain, nombre de niveaux, rendement, surface d’un local selon son nom, ou MESURE
 *    saisie à la main : hauteur, recul…), opérateur (≤, ≥, =, entre), seuil.
 *  • CONTRÔLE : trois résultats seulement — CONFORME, NON CONFORME, À VÉRIFIER. Une règle non validée, périmée, sans seuil, sans donnée, ou portant sur une emprise
 *    estimée donne toujours « À VÉRIFIER », jamais « conforme » (un écart apparent est alors signalé dans le détail). Les règles obsolètes sont ignorées.
 *  • Historique : chaque contrôle enregistré (date, auteur, résultats) est conservé ; export CSV et rapport imprimable.
 *  Aide au contrôle uniquement : ne vaut pas avis de conformité ni autorisation ; la vérification par l’autorité compétente et l’architecte reste obligatoire.
 *  Stockage : exb_arch_reg (collection « arch_reglementation », migration-v209f-controle-reglementaire.sql). Les indicateurs viennent de EXBARCP.calc (V209e).
 *  Fonctions pures (indicateurs, evalRegle, controle, selectModeles) testées dans tools/test-controle-reglementaire.js. */
(function (w, d) {
  'use strict';
  var KEY = 'exb_arch_reg', COL = 'arch_reglementation', KP = 'exb_arch_prog';
  var INDIC = [['ces', 'CES — emprise / terrain (ratio, ex. 0,40)'], ['cos', 'COS — surface de plancher / terrain (ratio)'], ['emprise', 'Emprise au sol (m²)'], ['brut', 'Surface brute totale, tous niveaux (m²)'], ['plancher', 'Surface de plancher selon la définition du projet (m²)'], ['utile', 'Surface utile (m²)'],
    ['terrain', 'Superficie du terrain (m²)'], ['niveaux', 'Nombre de niveaux'], ['rendement', 'Rendement utile / brute (ratio)'], ['local', 'Surface de chaque local dont le nom contient le motif (m²)'], ['manuel', 'Mesure saisie à la main (hauteur, recul…)']];
  var OPS = [['<=', '≤ au plus'], ['>=', '≥ au moins'], ['=', '= égal à'], ['entre', 'entre']];
  var NIV = [['pays', 'Pays'], ['commune', 'Commune'], ['projet', 'Projet']];
  var STAT = [['a_valider', 'À valider'], ['valide', 'Validée'], ['obsolete', 'Obsolète']];
  var RES = { conforme: ['✔ Conforme', '#166534'], non_conforme: ['✖ Non conforme', '#b91c1c'], a_verifier: ['⚠ À vérifier', '#b45309'], obsolete: ['— Ignorée (obsolète)', '#64748b'] };
  var st = { pid: '', tab: 'controle', last: null };

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function hasNum(v) { return v !== '' && v != null && !isNaN(Number(String(v).replace(',', '.'))); }
  function num(v, def) { return hasNum(v) ? Number(String(v).replace(',', '.')) : (def === undefined ? 0 : def); }
  function fm(n, dg) { return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: dg == null ? 2 : dg }).format(n || 0); }
  function s(v, n) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n); }
  function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); } catch (e) { } }
  function canR() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'lire'); } catch (e) { return true; } }
  function canW() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'ecrire'); } catch (e) { return true; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function projs() { try { return w.EXBS.projects() || []; } catch (e) { return []; } }
  function load() { try { return w.EXBS.get(KEY) || []; } catch (e) { return []; } }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction)) || ''; } catch (e) { return ''; } }
  function lab(L, k) { for (var i = 0; i < L.length; i++) if (L[i][0] === k) return L[i][1]; return k || ''; }
  function norm(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); }
  function dateOk(v) { return v === '' || v == null || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(Date.parse(v))); }
  function urlOk(u) { u = String(u || '').trim(); return u === '' || /^https?:\/\/[^\s<>"']+$/i.test(u) || !/^[a-z][a-z0-9+.-]*:/i.test(u); }   /* source : texte libre ou http(s), jamais javascript: / data: */
  function csvCell(c) { c = String(c == null ? '' : c); if (/^[=+\-@\t\r]/.test(c)) c = "'" + c; return '"' + c.replace(/"/g, '""') + '"'; }

  /* ================= CALCUL (pur) ================= */
  /* Indicateurs du projet à partir de EXBARCP.calc(...) (C). Retourne null si le programme est indisponible. */
  function indicateurs(C) {
    if (!C || !C.rows) return null;
    var nv = {}; C.rows.forEach(function (r) { if (norm(r.niveau)) nv[norm(r.niveau)] = 1; });
    return { ces: C.ces, cos: C.cos, emprise: C.emprise, brut: C.tot.brut > 0 ? C.tot.brut : null, plancher: C.tot.plancher > 0 ? C.tot.plancher : null, defDefaut: !!C.defDefaut, utile: C.tot.utile > 0 ? C.tot.utile : null, terrain: C.terrain,
      niveaux: Object.keys(nv).length || null, rendement: C.rendement, empriseEstimee: !!C.empriseEstimee, rows: C.rows };
  }
  function test(r, v) {
    var a = num(r.val), e = 1e-9;
    if (r.op === '<=') return v <= a + e; if (r.op === '>=') return v >= a - e; if (r.op === '=') return Math.abs(v - a) <= 1e-6 * Math.max(1, Math.abs(a));
    if (r.op === 'entre') { var b = num(r.val2); return v >= Math.min(a, b) - e && v <= Math.max(a, b) + e; }
    return false;
  }
  function textCible(r) { var u = r.unite ? ' ' + r.unite : ''; return r.op === 'entre' ? 'entre ' + r.val + ' et ' + r.val2 + u : (r.op || '?') + ' ' + r.val + u; }
  /* Évalue UNE règle. I : indicateurs (ou null) ; now : 'AAAA-MM-JJ'. */
  function evalRegle(r, I, now) {
    now = now || today();
    var out = { id: r.id, nom: r.nom || '(sans nom)', source: r.source || '', exigence: textCible(r), statut: 'a_verifier', detail: '', mesures: [] };
    if (r.statut === 'obsolete') { out.statut = 'obsolete'; out.detail = 'Règle obsolète : ignorée.'; return out; }
    var raisons = [], vals = [];
    if (r.statut !== 'valide') raisons.push('règle non validée');
    if (r.fin && r.fin < now) raisons.push('règle périmée depuis le ' + r.fin);
    if (!hasNum(r.val) || (r.op === 'entre' && !hasNum(r.val2)) || OPS.every(function (o) { return o[0] !== r.op; })) raisons.push('seuil ou opérateur non renseigné');
    if (r.indic === 'manuel') { if (hasNum(r.mesure)) vals.push({ l: '', v: num(r.mesure) }); }
    else if (r.indic === 'local') {
      var m = norm(r.motif); if (!m) raisons.push('motif de local non renseigné');
      else ((I && I.rows) || []).forEach(function (x) { if (norm(x.nom).indexOf(m) >= 0) vals.push({ l: x.nom, v: x.eff }); });
      if (m && !vals.length) raisons.push('aucun local ne correspond au motif « ' + r.motif + ' »');
    } else if (I && I[r.indic] != null && !isNaN(I[r.indic])) vals.push({ l: '', v: I[r.indic] });
    if (!vals.length && r.indic !== 'local') raisons.push(r.indic === 'manuel' ? 'mesure non saisie' : I ? 'donnée non disponible dans le programme' : 'module « Programme & surfaces » indisponible');
    if (I && I.empriseEstimee && (r.indic === 'ces' || r.indic === 'emprise')) raisons.push('emprise estimée, non saisie');
    if (I && I.defDefaut && (r.indic === 'cos' || r.indic === 'plancher')) raisons.push('définition de la surface de plancher non choisie pour ce projet');
    var bad = [];
    if (hasNum(r.val) && OPS.some(function (o) { return o[0] === r.op; })) vals.forEach(function (x) { if (!(r.op === 'entre' && !hasNum(r.val2)) && !test(r, x.v)) bad.push(x); });
    out.mesures = vals.map(function (x) { return (x.l ? x.l + ' : ' : '') + fm(x.v); });
    var mes = out.mesures.length ? 'Valeur : ' + out.mesures.join(' ; ') + '. ' : '';
    if (raisons.length) { out.statut = 'a_verifier'; out.detail = mes + (bad.length ? 'Écart apparent. ' : '') + 'À vérifier : ' + raisons.join(', ') + '.'; }
    else if (bad.length) { out.statut = 'non_conforme'; out.detail = mes + 'Exigence ' + out.exigence + ' non respectée' + (bad.length < vals.length || vals.length > 1 ? ' (' + bad.map(function (x) { return x.l || 'valeur'; }).join(', ') + ')' : '') + '.'; }
    else { out.statut = 'conforme'; out.detail = mes + 'Exigence ' + out.exigence + ' respectée.'; }
    return out;
  }
  /* Contrôle d’un jeu de règles (types 'regle' du projet). */
  function controle(regles, I, now) {
    var res = (regles || []).filter(function (r) { return r.type === 'regle'; }).map(function (r) { var o = evalRegle(r, I, now); o.indic = r.indic; return o; });
    var n = { conforme: 0, non_conforme: 0, a_verifier: 0, obsolete: 0 }; res.forEach(function (x) { n[x.statut]++; });
    n.total = res.length - n.obsolete; return { res: res, n: n };
  }
  /* Modèles à copier dans un projet : même pays / même commune que le cadre, pas déjà copiés (origine). Pur. */
  function selectModeles(models, regles, cadre) {
    var pays = norm(cadre && cadre.pays), com = norm(cadre && cadre.commune), deja = {}; (regles || []).forEach(function (r) { if (r.origine) deja[r.origine] = 1; });
    return (models || []).filter(function (m) {
      if (m.type !== 'modele' || m.statut === 'obsolete' || deja[m.id]) return false;
      return (m.niveau === 'pays' && pays && norm(m.lieu) === pays) || (m.niveau === 'commune' && com && norm(m.lieu) === com);
    });
  }
  function csvControle(C) {
    var rows = [['Règle', 'Indicateur', 'Exigence', 'Résultat', 'Détail', 'Source']].concat(C.res.map(function (x) { return [x.nom, lab(INDIC, x.indic).split(' (')[0], x.exigence, RES[x.statut][0], x.detail, x.source]; }));
    return '\ufeff' + rows.map(function (r) { return r.map(csvCell).join(';'); }).join('\r\n');
  }

  /* ================= INTERFACE ================= */
  var API = { indicateurs: indicateurs, evalRegle: evalRegle, controle: controle, selectModeles: selectModeles, csvControle: csvControle, open: open };
  function pname() { var n = ''; projs().forEach(function (p) { if (String(p.id) === String(st.pid)) n = p.nom || p.name || p.titre || p.title || ''; }); return n; }
  function regles() { return load().filter(function (x) { return x.type === 'regle' && String(x.project) === String(st.pid); }); }
  function modeles() { return load().filter(function (x) { return x.type === 'modele'; }); }
  function histo() { return load().filter(function (x) { return x.type === 'controle' && String(x.project) === String(st.pid); }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }); }
  function progItems() { try { return (w.EXBS.get(KP) || []).filter(function (x) { return String(x.project) === String(st.pid); }); } catch (e) { return []; } }
  function cadre() { return progItems().filter(function (x) { return x.type === 'cadre'; })[0] || {}; }
  function ind() { try { return w.EXBARCP && w.EXBARCP.calc ? indicateurs(w.EXBARCP.calc(progItems(), 'base')) : null; } catch (e) { return null; } }
  function edit(fn) { if (!canW()) { say('Écriture non autorisée.', 'error'); return false; } var all = load(); if (fn(all) === false) return false; try { w.EXBS.set(KEY, all); } catch (e) { say('Enregistrement impossible.', 'error'); return false; } return true; }
  function box() { return d.getElementById('exbRegBox'); }
  var IN = 'style="width:100%;box-sizing:border-box;padding:6px;border:1px solid #cbd5e1;border-radius:6px"';
  function inp(f, id, v, ph) { return '<input ' + IN + ' data-f="' + f + '" data-i="' + esc(id) + '" value="' + esc(v == null ? '' : v) + '"' + (ph ? ' placeholder="' + esc(ph) + '"' : '') + (canW() ? '' : ' disabled') + '>'; }
  function sel(f, id, L, v) { return '<select data-f="' + f + '" data-i="' + esc(id) + '"' + (canW() ? '' : ' disabled') + '>' + L.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === v ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>'; }
  function ruleCard(r, isModel) {
    var h = '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin:6px 0"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:6px">'
      + '<label style="font-size:11px">Nom' + inp('nom', r.id, r.nom) + '</label>'
      + (isModel ? '<label style="font-size:11px">Niveau' + sel('niveau', r.id, [NIV[0], NIV[1]], r.niveau) + '</label><label style="font-size:11px">Pays / commune' + inp('lieu', r.id, r.lieu) + '</label>' : '')
      + '<label style="font-size:11px">Indicateur' + sel('indic', r.id, INDIC, r.indic) + '</label>'
      + (r.indic === 'local' ? '<label style="font-size:11px">Motif (nom du local)' + inp('motif', r.id, r.motif, 'ex. chambre') + '</label>' : '')
      + '<label style="font-size:11px">Opérateur' + sel('op', r.id, OPS, r.op) + '</label><label style="font-size:11px">Seuil' + inp('val', r.id, r.val) + '</label>'
      + (r.op === 'entre' ? '<label style="font-size:11px">Seuil haut' + inp('val2', r.id, r.val2) + '</label>' : '')
      + '<label style="font-size:11px">Unité' + inp('unite', r.id, r.unite, 'm², m, ratio') + '</label>'
      + (!isModel && r.indic === 'manuel' ? '<label style="font-size:11px">Mesure relevée' + inp('mesure', r.id, r.mesure) + '</label>' : '')
      + '<label style="font-size:11px">Statut' + sel('statut', r.id, STAT, r.statut) + '</label><label style="font-size:11px">Valable jusqu’au' + inp('fin', r.id, r.fin, 'AAAA-MM-JJ') + '</label>'
      + '<label style="font-size:11px;grid-column:span 2">Source (texte, article, lien)' + inp('source', r.id, r.source) + '</label></div>'
      + (canW() ? '<button data-a="del" data-i="' + esc(r.id) + '" style="margin-top:4px">🗑 Supprimer</button>' : '') + '</div>';
    return h;
  }
  function paint() {
    var b = box(); if (!b) return; var W = canW(), h = '', I = ind();
    h += '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><b style="align-self:center;margin-right:8px">⚖ Contrôle réglementaire</b>' + [['controle', 'Contrôle'], ['regles', 'Règles du projet'], ['modeles', 'Modèles pays / commune'], ['histo', 'Historique']].map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:8px;background:' + (st.tab === t[0] ? '#0f766e;color:#fff' : '#e2e8f0') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>';
    h += '<p style="margin:4px 0">Projet : <select id="rgPid">' + projs().map(function (p) { return '<option value="' + esc(p.id) + '"' + (String(p.id) === String(st.pid) ? ' selected' : '') + '>' + esc(p.nom || p.name || p.titre || p.title || p.id) + '</option>'; }).join('') + '</select></p>';
    h += '<p style="font-size:12px;color:#b45309;margin:4px 0">Aide au contrôle : aucune règle n’est préenregistrée et ce résultat ne vaut pas avis de conformité. Une règle non validée donne toujours « À vérifier ».</p>';
    if (st.tab === 'controle') {
      var C = controle(load().filter(function (x) { return String(x.project) === String(st.pid); }), I); st.last = C;
      if (!I) h += '<p style="color:#b91c1c">Le module « Programme & surfaces » est indisponible : seules les mesures saisies à la main peuvent être contrôlées.</p>';
      h += '<p><b>' + C.n.conforme + '</b> conforme(s) · <b>' + C.n.non_conforme + '</b> non conforme(s) · <b>' + C.n.a_verifier + '</b> à vérifier · ' + C.n.obsolete + ' ignorée(s)</p>';
      if (!C.res.length) h += '<p>Aucune règle pour ce projet. Ajoutez-en dans « Règles du projet » ou appliquez un modèle pays / commune.</p>';
      else h += '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr><th align="left">Règle</th><th align="left">Exigence</th><th align="left">Résultat</th><th align="left">Détail</th></tr>' + C.res.map(function (x) { var e = RES[x.statut]; return '<tr style="border-top:1px solid #e2e8f0;vertical-align:top"><td>' + esc(x.nom) + (x.source ? '<div style="font-size:11px;color:#64748b">' + esc(x.source) + '</div>' : '') + '</td><td>' + esc(x.exigence) + '</td><td style="color:' + e[1] + ';white-space:nowrap"><b>' + e[0] + '</b></td><td>' + esc(x.detail) + '</td></tr>'; }).join('') + '</table></div>';
      h += '<p>' + (W && C.res.length ? '<button data-a="save">💾 Enregistrer ce contrôle</button> ' : '') + (C.res.length ? '<button data-a="csv">⬇ CSV</button> <button data-a="print">🖨 Rapport</button>' : '') + '</p>';
    } else if (st.tab === 'regles') {
      var c = cadre();
      h += '<p style="font-size:12px">Pays : <b>' + esc(c.pays || '— non renseigné') + '</b> · commune : <b>' + esc(c.commune || '— non renseignée') + '</b> (à renseigner dans « Programme & surfaces › Synthèse »)</p>' + regles().map(function (r) { return ruleCard(r, false); }).join('') + (regles().length ? '' : '<p>Aucune règle pour ce projet.</p>');
      h += '<p>' + (W ? '<button data-a="add">+ Règle</button> <button data-a="apply">⬇ Appliquer les modèles du pays / de la commune</button>' : '') + '</p>';
    } else if (st.tab === 'modeles') {
      h += modeles().map(function (r) { return ruleCard(r, true); }).join('') + (modeles().length ? '' : '<p>Aucun modèle. Un modèle sert à réutiliser des règles d’un pays ou d’une commune dans plusieurs projets.</p>') + '<p>' + (W ? '<button data-a="addm">+ Modèle</button>' : '') + '</p>';
    } else {
      h += histo().map(function (x) { return '<div style="border-top:1px solid #e2e8f0;padding:6px 0"><b>' + esc(String(x.date).slice(0, 10)) + '</b> · ' + esc(x.par || '') + ' — ' + x.n.conforme + ' conforme(s), ' + x.n.non_conforme + ' non conforme(s), ' + x.n.a_verifier + ' à vérifier</div>'; }).join('') || '<p>Aucun contrôle enregistré.</p>';
    }
    b.innerHTML = h;
  }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), id = t.getAttribute && t.getAttribute('data-i'), v = t.value;
    if (t.id === 'rgPid') { st.pid = v; return paint(); }
    if (!f) return;
    if (/^(val|val2|mesure)$/.test(f) && v !== '' && !hasNum(v)) { say('Nombre attendu.', 'error'); return paint(); }
    if (f === 'fin' && !dateOk(v)) { say('Date invalide (AAAA-MM-JJ).', 'error'); return paint(); }
    if (f === 'source' && !urlOk(v)) { say('Source : texte libre ou lien http(s).', 'error'); return paint(); }
    edit(function (a) { var x = a.filter(function (z) { return z.id === id; })[0]; if (!x) return false; x[f] = /^(val|val2|mesure)$/.test(f) ? (v === '' ? '' : num(v)) : s(v, f === 'source' ? 400 : 120); x.maj = today(); x.par = who(); }); setTimeout(paint, 0);
  }
  function dl(name, txt, type) { var l = d.createElement('a'); l.href = URL.createObjectURL(new Blob([txt], { type: type })); l.download = name; d.body.appendChild(l); l.click(); setTimeout(function () { URL.revokeObjectURL(l.href); l.remove(); }, 500); }
  function printRapport() {
    var C = st.last || controle(regles(), ind()), win = w.open('', '_blank'); if (!win) return say('Autorisez les fenêtres pour imprimer.', 'error');
    win.document.write('<html><head><meta charset="utf-8"><title>Contrôle réglementaire</title><style>body{font:12px Arial;margin:20px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #999;padding:3px 7px;text-align:left;vertical-align:top}</style></head><body><h2>Contrôle réglementaire — ' + esc(pname()) + '</h2><p>Édité le ' + esc(today()) + ' · ' + C.n.conforme + ' conforme(s), ' + C.n.non_conforme + ' non conforme(s), ' + C.n.a_verifier + ' à vérifier</p><table><tr><th>Règle</th><th>Exigence</th><th>Résultat</th><th>Détail</th><th>Source</th></tr>'
      + C.res.map(function (x) { return '<tr><td>' + esc(x.nom) + '</td><td>' + esc(x.exigence) + '</td><td><b>' + esc(RES[x.statut][0]) + '</b></td><td>' + esc(x.detail) + '</td><td>' + esc(x.source) + '</td></tr>'; }).join('')
      + '</table><p style="font-size:11px">Aide au contrôle d’après les règles saisies et validées par l’utilisateur ; ne vaut pas avis de conformité réglementaire. Vérification par l’architecte et l’autorité compétente obligatoire.</p></body></html>'); win.document.close(); setTimeout(function () { try { win.print(); } catch (e) { } }, 300);
  }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), id = t.getAttribute('data-i');
    if (a === 'close') { var o = d.getElementById('exbReg'); if (o) o.remove(); return; }
    if (a === 'tab') { st.tab = id; return paint(); }
    if (a === 'add') { edit(function (x) { x.push({ id: uid('RG'), type: 'regle', project: st.pid, nom: 'Nouvelle règle', indic: 'ces', op: '<=', val: '', val2: '', unite: '', statut: 'a_valider', source: '', fin: '', maj: today(), par: who() }); }); return paint(); }
    if (a === 'addm') { edit(function (x) { x.push({ id: uid('MR'), type: 'modele', project: '', niveau: 'commune', lieu: '', nom: 'Nouveau modèle', indic: 'ces', op: '<=', val: '', val2: '', unite: '', statut: 'a_valider', source: '', fin: '', maj: today(), par: who() }); }); return paint(); }
    if (a === 'del') { if (!w.confirm('Supprimer cette règle ?')) return; edit(function (x) { var i = x.findIndex(function (z) { return z.id === id; }); if (i < 0) return false; x.splice(i, 1); }); return paint(); }
    if (a === 'apply') {
      var all = load(), M = selectModeles(all.filter(function (x) { return x.type === 'modele'; }), regles(), cadre());
      if (!M.length) return say('Aucun nouveau modèle ne correspond au pays / à la commune du projet.', 'error');
      if (!w.confirm('Copier ' + M.length + ' règle(s) dans ce projet ? Copie figée : les règles arrivent « à valider » et ne donnent que « à vérifier » tant que vous ne les validez pas pour ce projet.')) return;
      edit(function (x) { M.forEach(function (m) { x.push({ id: uid('RG'), type: 'regle', project: st.pid, origine: m.id, nom: m.nom, indic: m.indic, motif: m.motif || '', op: m.op, val: m.val, val2: m.val2, unite: m.unite, statut: 'a_valider', source: m.source, fin: m.fin || '', maj: today(), par: who() }); }); }); return paint();
    }
    if (a === 'save') { var C = st.last; if (!C) return; edit(function (x) { x.push({ id: uid('CT'), type: 'controle', project: st.pid, date: new Date().toISOString(), par: who(), n: C.n, res: C.res.map(function (r) { return { nom: r.nom, statut: r.statut, detail: r.detail }; }) }); }); say('Contrôle enregistré.'); return paint(); }
    if (a === 'csv') return dl('controle-reglementaire.csv', csvControle(st.last || controle(regles(), ind())), 'text/csv;charset=utf-8');
    if (a === 'print') return printRapport();
  }
  function open() {
    if (!canR()) return say('Accès refusé.', 'error');
    if (!st.pid) { var P = projs(); st.pid = (function () { try { return localStorage.getItem('exb_active_project'); } catch (e) { return ''; } })() || (P[0] && P[0].id) || ''; }
    var o = d.getElementById('exbReg'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbReg'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbRegBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:1020px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('click', onClick); c.addEventListener('change', onChange); paint();
  }
  w.EXBARCR = API;

  function ui() {
    var b = d.getElementById('exbArcPBtn') || d.getElementById('exbArcBtn'); if (!b || d.getElementById('exbArcRBtn')) return;
    var k = d.createElement('button'); k.id = 'exbArcRBtn'; k.className = 'muted'; k.textContent = '⚖ Contrôle réglementaire'; k.onclick = open; if (!canR()) k.setAttribute('data-exbrole', 'hide'); b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (d.documentElement && w.MutationObserver) { new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true }); d.addEventListener('DOMContentLoaded', ui); }
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { documentElement: null, getElementById: function () { return null; }, addEventListener: function () { } });
