/* Excellencia Building — ATELIER DE MISE EN PAGE · app.js (interface). Assemble les modules EXBDOC : import → analyse → classement → modèle → configuration → aperçu → export → archivage. */
(function () {
  'use strict';
  var D = window.EXBDOC, C = D.cartouche, L = D.layout, V = D.version, X = D.exporter, AN = D.analysis, IM = D.importer, PV = D.preview, OC = D.ocr, PL = window.PDFLib;
  var $ = function (i) { return document.getElementById(i); }, host = null; try { host = parent !== window ? parent : null; } catch (e) { host = null; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var S = { screen: 'atelier', cur: null, sel: {}, mem: {}, vue: 'apres', page: 0, zoom: 1, rot: 0, plan: null, after: null, afterPdf: null, origPdf: {}, pdfjs: null, tok: 0, dtok: 0, logo: null, ent: { nom: 'Excellencia Building', slogan: '' }, tm: null, busy: '', lastWarns: [] };
  var ST = { 'Brouillon': 'st-Brouillon', 'Pour vérification': 'st-Pour', 'À corriger': 'st-Acorr', 'Approuvé': 'st-Appr', 'Émis': 'st-Emis' };

  /* ---------------------------------------------------------------- utilitaires ---------------------------------------------------------------- */
  function toast(m, k) { var t = document.createElement('div'); t.className = 'toast ' + (k || ''); t.textContent = m; t.setAttribute('role', 'status'); document.body.appendChild(t); setTimeout(function () { t.remove(); }, k === 'err' ? 7000 : 3500); }
  function jget(k, def) { try { var S0 = host && host.exbStorage; var r = S0 ? S0.getItem(k) : localStorage.getItem(k); return r ? JSON.parse(r) : def; } catch (e) { return def; } }
  function fdate(t) { try { var d = new Date(t); return C.dateFr(t) + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); } catch (e) { return ''; } }
  function fsize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function chip(st) { return '<span class="chip ' + (ST[st] || '') + '">' + esc(st) + '</span>'; }
  function cur() { return S.cur ? V.getDoc(S.cur) : null; }
  function liste() { return V.docs().filter(V.visible).sort(function (a, b) { return b.importeLe - a.importeLe; }); }
  function locked(d) { return !!d && d.statut !== 'Brouillon' && d.statut !== 'À corriger'; }
  function modal(titre, html, boutons) {
    return new Promise(function (res) {
      var dlg = $('dlg'), f = $('dform'), fini = false;
      f.innerHTML = '<h3>' + esc(titre) + '</h3>' + html + '<div class="acts" style="justify-content:flex-end">' + boutons.map(function (b, i) { return '<button class="btn ' + (b.c || '') + '" type="button" data-i="' + i + '">' + esc(b.t) + '</button>'; }).join('') + '</div>';
      function done(i) { if (fini) return; fini = true; var v = {}; f.querySelectorAll('[name]').forEach(function (el) { v[el.name] = el.type === 'checkbox' ? el.checked : el.value; }); try { dlg.close(); } catch (e) {} res({ i: i, v: v }); }
      f.querySelectorAll('button[data-i]').forEach(function (b) { b.onclick = function () { done(+b.getAttribute('data-i')); }; });
      dlg.oncancel = function (e) { e.preventDefault(); done(-1); }; dlg.showModal();
    });
  }
  function dl(bytes, name, type) { var b = new Blob([bytes], { type: type || 'application/pdf' }), u = URL.createObjectURL(b), a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 4000); }
  function slug(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, ''); }
  async function pdfjs() { if (S.pdfjs) return S.pdfjs; var m = await import('../pdfjs/pdf.min.mjs'); m.GlobalWorkerOptions.workerSrc = '../pdfjs/pdf.worker.min.mjs'; S.pdfjs = m; return m; }
  function progress(txt, p) { var n = $('vNote'); if (n) n.innerHTML = txt ? esc(txt) + (p != null ? '<div class="pbar"><i style="width:' + Math.round(p * 100) + '%"></i></div>' : '') : ''; }
  async function nomActeur(titre) {
    var a = V.actor().nom; if (a) return a;
    var r = await modal(titre || 'Identification', '<label class="f">Votre nom et fonction (mention nominative, pas une signature électronique)<input name="n" value="" autocomplete="name" placeholder="Ir Prénom Nom"></label>', [{ t: 'Annuler' }, { t: 'Valider', c: 'pri' }]);
    var n = r.i === 1 ? String(r.v.n || '').trim() : ''; if (n) V.setNom(n); return n;
  }

  /* ---------------------------------------------------------------- identité, logo, projets ---------------------------------------------------------------- */
  async function chargerIdentite() {
    var I = {}; try { I = (host && host.EXBId && host.EXBId.get()) || {}; } catch (e) {}
    var nm = I.name || 'Excellencia Building', eb = /excellencia\s+building/i.test(nm), url = I.logo || (eb ? '../assets/carte/logo-officiel.jpg' : '');
    S.ent = { nom: nm, slogan: I.tagline || 'Bureau d’études — Ingénieur' };
    if (!url) return; try {
      var abs = /^(data:|https?:|blob:)/.test(url) ? url : new URL(url, (host && host.location) ? host.location.href : location.href).href;
      var buf = new Uint8Array(await (await fetch(abs)).arrayBuffer()), png = buf[0] === 0x89 && buf[1] === 0x50, jpg = buf[0] === 0xFF && buf[1] === 0xD8;
      if (!png && !jpg) { var im = new Image(); im.src = abs; await im.decode(); var cv = document.createElement('canvas'); cv.width = im.naturalWidth || 300; cv.height = im.naturalHeight || 150; cv.getContext('2d').drawImage(im, 0, 0); var bl = await new Promise(function (r) { cv.toBlob(r, 'image/png'); }); buf = new Uint8Array(await bl.arrayBuffer()); png = true; }
      S.logo = { bytes: buf, type: jpg ? 'jpg' : 'png' }; var el = $('logo'); el.src = abs; el.hidden = false;
    } catch (e) { S.logo = null; }
  }
  function projets() { var p = jget('exb_projects', []); return Array.isArray(p) ? p : []; }
  function pNom(p) { return p.nom || p.name || p.titre || p.title || ''; }

  /* ---------------------------------------------------------------- données en mémoire d'un document ---------------------------------------------------------------- */
  async function ensure(d, silencieux) {
    var m = S.mem[d.id] || (S.mem[d.id] = {});
    if (!m.bytes) { m.bytes = await V.getFile(d.sha256); if (!m.bytes) throw new Error('Original introuvable dans l’archive (' + d.nom + ').'); }
    if (!m.grilles) {
      var js = await pdfjs(), r = await AN.analyser(js, m.bytes, { motDePasse: m.pw, progress: function (i, n) { if (!silencieux) progress('Analyse de « ' + d.nom + ' » : page ' + i + ' / ' + n, i / n); } });
      if (r.besoinMotDePasse) {
        var q = await modal('PDF protégé — ' + d.nom, '<p class="note">' + (r.incorrect ? 'Mot de passe incorrect. ' : '') + 'Le mot de passe sert uniquement à l’analyse et à l’aperçu de cette session ; il n’est pas conservé. L’habillage d’un PDF chiffré reste impossible.</p><label class="f">Mot de passe<input name="pw" type="password" autocomplete="off"></label>', [{ t: 'Annuler' }, { t: 'Ouvrir', c: 'pri' }]);
        if (q.i !== 1) throw new Error('Mot de passe requis pour lire « ' + d.nom + ' ».'); m.pw = q.v.pw; return ensure(d, silencieux);
      }
      if (r.erreur) throw new Error(r.erreur);
      r.analyse.signe = !!d.signe; m.analyse = r.analyse; m.grilles = r.grilles; d.analyse = r.analyse; V.putDoc(d); progress('');
    }
    return m;
  }
  function devinerType(nom, an) {
    if (/note|calcul|\bnc[-_ ]/i.test(nom)) return 'note'; if (/rapport|report|etude|étude/i.test(nom)) return 'rapport'; if (/plan|coffrage|ferraillage|archi|detail|détail|pl[-_]/i.test(nom)) return 'plan';
    var p = an && an.pages && an.pages[0]; return p && p.format === 'A4' && p.texte ? 'note' : 'plan';
  }

  /* ---------------------------------------------------------------- import ---------------------------------------------------------------- */
  async function importer(files) {
    if (!V.act('creer')) return toast('Votre profil n’a pas le droit d’importer des documents.', 'err');
    var log = $('impLog'), rows = []; function paint() { log.innerHTML = '<table><tr><th>Fichier</th><th>Résultat</th></tr>' + rows.map(function (r) { return '<tr><td>' + esc(r.nom) + '</td><td style="color:var(--' + (r.ok ? 'ok' : 'err') + ')">' + esc(r.msg) + '</td></tr>'; }).join('') + '</table>'; } 
    var js = await pdfjs(), last = null;
    for (var i = 0; i < files.length; i++) {
      var f = files[i], r = await IM.lire(f); if (!r.ok) { rows.push({ nom: r.nom, ok: false, msg: 'Refusé — ' + r.erreur }); paint(); continue; }
      rows.push({ nom: r.nom, ok: true, msg: 'Analyse…' }); paint(); var row = rows[rows.length - 1], pw = '', an = await AN.analyser(js, r.bytes, { progress: function (p, n) { row.msg = 'Analyse : page ' + p + ' / ' + n; paint(); } });
      while (an.besoinMotDePasse) {
        var q = await modal('PDF protégé — ' + r.nom, '<p class="note">' + (an.incorrect ? 'Mot de passe incorrect. ' : '') + 'Saisissez le mot de passe pour analyser et prévisualiser ce document (non conservé). Il ne pourra pas être habillé tant qu’il est chiffré.</p><label class="f">Mot de passe<input name="pw" type="password" autocomplete="off"></label>', [{ t: 'Refuser ce fichier' }, { t: 'Ouvrir', c: 'pri' }]);
        if (q.i !== 1) break; pw = q.v.pw; an = await AN.analyser(js, r.bytes, { motDePasse: pw });
      }
      if (an.besoinMotDePasse) { row.ok = false; row.msg = 'Refusé — PDF protégé par mot de passe, non fourni.'; paint(); continue; }
      if (an.erreur) { row.ok = false; row.msg = 'Refusé — ' + an.erreur; paint(); continue; }
      an.analyse.signe = r.signe; var d = await V.creerDoc({ nom: r.nom, bytes: r.bytes, analyse: an.analyse });
      d.protege = !!(r.chiffre || pw); d.signe = r.signe; d.classement.type = devinerType(r.nom, an.analyse); d.config.modele = d.classement.type === 'note' ? 'note' : d.classement.type === 'rapport' ? 'rapport' : 'plan';
      d.config.champs = C.prefill({}, null, an.analyse, 0); V.putDoc(d); S.mem[d.id] = { bytes: r.bytes, analyse: an.analyse, grilles: an.grilles, pw: pw }; last = d;
      var fl = []; if (d.protege) fl.push('protégé (aperçu seul, export refusé)'); if (r.signe) fl.push('signature numérique'); if (an.analyse.scannes) fl.push(an.analyse.scannes + ' page(s) scannée(s)'); if (an.analyse.formatsMixtes) fl.push('formats mixtes'); if (an.analyse.pages.some(function (p) { return p.cartouche.detecte; })) fl.push('cartouche existant détecté');
      row.msg = 'Archivé (' + an.analyse.nbPages + ' page(s), ' + fsize(r.bytes.length) + ', SHA-256 ' + d.sha256.slice(0, 10) + '…)' + (fl.length ? ' — ' + fl.join(', ') : ''); paint();
    }
    if (last) { S.cur = last.id; toast(files.length > 1 ? 'Import terminé.' : 'Document importé.', 'ok'); go('atelier'); } else renderAll();
  }

  /* ---------------------------------------------------------------- travail préparatoire : job, plan, aperçu ---------------------------------------------------------------- */
  async function entree(d, dec) { var m = await ensure(d, true); return { id: d.id, nom: d.nom, sha: d.sha256, type: d.classement.type, bytes: m.bytes, analyse: Object.assign({}, m.analyse, { signe: !!d.signe }), grilles: m.grilles, cartoucheExistant: dec || '' }; }
  /* V214 : QR de vérification — même mécanisme que devis, reçus et plans (registre EXBVerif). Le code dépend du document, de l'indice, du statut et de la version :
     l'aperçu et l'export portent donc exactement le même QR ; il n'est publié au registre qu'à l'export réussi. */
  function qrPour(d, statut, tag) {
    try {
      var VF = host && host.EXBVerif, QR = host && host.EXBQR; if (!VF || !VF.docRec || !QR || !QR.matrix) return null;
      var ch = d.config.champs || {}, date = new Date().toISOString().slice(0, 10), no = ch.numero || ('MEP-' + String(d.id).slice(-8).toUpperCase());
      var o = VF.docRec({ no: no, prefix: 'MEP', date: date, title: ch.titre || d.nom, sub: (ch.indice ? 'ind. ' + ch.indice + ' · ' : '') + tag + ' · ' + statut, digest: [d.sha256, ch.indice || '', statut, tag].join('|'), nom: ch.client || '', detail: [ch.projet, ch.reference, d.config.modele].filter(Boolean).join(' · ') });
      o.rec.status = statut === 'Émis' ? 'valide' : 'brouillon';
      return { url: o.code.url, code: String(o.code.hash).toUpperCase(), matrix: QR.matrix(o.code.url), rec: o.rec };
    } catch (e) { return null; }
  }
  async function jobPour(d, apercu) {
    var cfg = d.config, tpl = C.modele(cfg.modele, V.modelesPerso()) || C.modele('plan'); if (cfg.position) tpl.position = cfg.position; if (+cfg.marge > 0) tpl.marge = +cfg.marge;
    var docs = [await entree(d, cfg.cartoucheExistant)];
    if (cfg.modele === 'dossier') { var ids = Object.keys(S.sel).filter(function (k) { return S.sel[k] && k !== d.id; }); for (var i = 0; i < ids.length; i++) { var o = V.getDoc(ids[i]); if (o) docs.push(await entree(o, o.config.cartoucheExistant || cfg.cartoucheExistant)); } }
    return { modele: cfg.modele, tpl: tpl, champs: cfg.champs, statut: d.statut, workflow: d.workflow, logo: !!S.logo, logoImage: S.logo, entreprise: S.ent, docs: docs, options: Object.assign({ mode: cfg.mode || 'auto' }, cfg.options || {}), meta: { auteur: V.actor().nom || d.workflow.auteur || '', version: 'v' + (V.versions(d.id).length + 1) }, qr: qrPour(d, d.statut, 'v' + (V.versions(d.id).length + 1)), apercu: !!apercu };
  }
  function refresh(now) { clearTimeout(S.tm); S.tm = setTimeout(recalcul, now ? 0 : 450); }
  async function recalcul() {
    var d = cur(); if (!d) { renderWarns([]); draw(); return; }
    var tok = ++S.tok; S.after = null; S.afterPdf = null; S.plan = null;
    try {
      if (d.protege && !(S.mem[d.id] && S.mem[d.id].pw) && d.signe === undefined) { /* rien */ }
      await ensure(d); if (tok !== S.tok) return; var job = await jobPour(d, true), plan = L.plan(job); S.plan = plan; S.lastWarns = plan.avertissements.slice(); renderWarns(S.lastWarns); renderSteps();
      if (d.protege) { S.lastWarns.unshift({ niv: 'bloquant', msg: 'PDF protégé (chiffré) : aperçu de l’original seulement. L’habillage est refusé : demandez une copie non chiffrée au propriétaire du document.' }); renderWarns(S.lastWarns); S.vue = 'avant'; draw(); return; }
      progress('Calcul de l’aperçu…'); var r = await X.build(PL, job, plan); if (tok !== S.tok) return; S.after = r; S.afterPdf = await PV.ouvrir(await pdfjs(), r.bytes); S.lastWarns = plan.avertissements.concat(r.notes); renderWarns(S.lastWarns); progress('');
    } catch (e) { progress(''); S.lastWarns = [{ niv: 'bloquant', msg: String(e && e.message || e) }]; renderWarns(S.lastWarns); }
    if (tok === S.tok) { S.page = Math.min(S.page, Math.max(0, total() - 1)); draw(); renderSteps(); }
  }
  function total() { return S.after ? S.after.map.length : ((S.mem[S.cur] && S.mem[S.cur].analyse && S.mem[S.cur].analyse.nbPages) || 0); }
  async function origHandle(docIdx) {
    var key = S.cur + ':' + docIdx; if (S.origPdf[key]) return S.origPdf[key]; var docs = S.plan && S.plan.docs, dd = docs && docs[docIdx]; if (!dd) return null;
    var h = await PV.ouvrir(await pdfjs(), dd.bytes, (S.mem[dd.id] || {}).pw); S.origPdf[key] = h; return h;
  }
  async function draw() {
    var st = $('stage'), tok = ++S.dtok, d = cur(); if (!d) { st.innerHTML = '<div class="empty">Sélectionnez un document.</div>'; $('pInfo').textContent = '—'; return; }
    var n = total(), p = S.page, mode = S.vue, avail = Math.max(260, st.clientWidth - 30), panes = [];
    $('pInfo').textContent = n ? 'Page ' + (p + 1) + ' / ' + n : '—'; $('zInfo').textContent = Math.round(S.zoom * 100) + ' %';
    var ent = S.after ? S.after.map[p] : null, srcDoc = ent && ent.kind === 'orig' ? ent.doc : 0, srcPage = ent ? (ent.kind === 'orig' ? ent.page : null) : p;
    var wantAfter = (mode === 'apres' || mode === 'cote') && S.afterPdf, wantBefore = mode === 'avant' || mode === 'cote' || !S.afterPdf, w1 = mode === 'cote' ? avail / 2 - 8 : avail;
    st.innerHTML = '';
    function pane(titre) { var c = document.createElement('canvas'), w = document.createElement('div'); w.className = 'pane'; w.innerHTML = '<b>' + esc(titre) + '</b>'; w.appendChild(c); st.appendChild(w); return c; }
    try {
      if (wantBefore) { var h = await origHandle(srcDoc); if (srcPage == null) { var m0 = document.createElement('div'); m0.className = 'empty'; m0.textContent = 'Page générée (' + (ent && ent.kind) + ') : pas d’original.'; st.appendChild(m0); } else if (h) { var c1 = pane('Avant (original intact)'); await PV.rendre(h, srcPage, c1, { maxW: w1, zoom: S.zoom, rotation: S.rot }); } }
      if (tok !== S.dtok) return;
      if (wantAfter) { var c2 = pane('Après (version habillée' + (ent && ent.mode ? ' — ' + ({ overlay: 'cartouche sur zone libre', band: 'bande ajoutée', conserve: 'cartouche existant conservé', intact: 'page intacte' }[ent.mode] || ent.mode) : '') + ')'); await PV.rendre(S.afterPdf, p, c2, { maxW: w1, zoom: S.zoom, rotation: S.rot }); }
      else if (!S.afterPdf && !d.protege && S.plan && S.plan.bloquants.length) { var m1 = document.createElement('div'); m1.className = 'empty'; m1.textContent = 'Aperçu « après » indisponible tant que les points bloquants ci-dessous ne sont pas traités.'; st.appendChild(m1); }
    } catch (e) { if (tok === S.dtok) st.innerHTML += '<div class="empty">Aperçu impossible : ' + esc(e && e.message || e) + '</div>'; }
    var th = $('thumbs'); th.innerHTML = ''; for (var i = 0; i < Math.min(n, 200); i++) { var b = document.createElement('button'); b.textContent = String(i + 1); b.className = i === p ? 'on' : ''; b.setAttribute('data-p', i); th.appendChild(b); }
  }

  /* ---------------------------------------------------------------- avertissements ---------------------------------------------------------------- */
  function renderWarns(ws) {
    var d = cur(), a = (ws || []).slice(), m = d ? C.manquants(d.config.champs) : []; if (m.length) a.push({ niv: 'attention', msg: 'Champs obligatoires à compléter avant de soumettre : ' + m.map(function (x) { return x.libelle; }).join(', ') + '.' });
    var ord = { bloquant: 0, attention: 1, info: 2 }; a.sort(function (x, y) { return ord[x.niv] - ord[y.niv]; }); var seen = {}; a = a.filter(function (x) { var k = x.niv + x.msg; if (seen[k]) return false; seen[k] = 1; return true; });
    $('warns').innerHTML = a.length ? a.slice(0, 40).map(function (x) { return '<div class="w ' + x.niv + '"><b>' + ({ bloquant: 'Bloquant', attention: 'Attention', info: 'Info' }[x.niv]) + ' — </b>' + esc(x.msg) + '</div>'; }).join('') : '<div class="w info">Aucun point à signaler : aucun contenu recouvert, marges respectées.</div>';
    var bl = a.filter(function (x) { return x.niv === 'bloquant'; }).length; $('ctl').querySelector('h2').textContent = 'Contrôles' + (bl ? ' — ' + bl + ' bloquant(s)' : a.length ? ' — ' + a.length + ' point(s)' : ' — conforme');
  }

  /* ---------------------------------------------------------------- panneau de propriétés ---------------------------------------------------------------- */
  function opt(v, cur0, t) { return '<option value="' + esc(v) + '"' + (String(v) === String(cur0) ? ' selected' : '') + '>' + esc(t == null ? v : t) + '</option>'; }
  function renderProps() {
    var d = cur(), P = $('props'); if (!d) { P.innerHTML = '<div class="card"><h2>Propriétés</h2><div class="body"><div class="empty">Aucun document sélectionné.</div></div></div>'; return; }
    var cfg = d.config, an = (S.mem[d.id] && S.mem[d.id].analyse) || d.analyse || { pages: [] }, dis = locked(d) || !V.act('modifier') ? ' disabled' : '', tplx = C.modele(cfg.modele, V.modelesPerso()) || {}, pr = projets(), isPlan = cfg.modele === 'plan' || (cfg.modele === 'dossier' && d.classement.type === 'plan');
    var det = an.pages.some(function (p) { return p.cartouche && p.cartouche.detecte; }), flags = [];
    if (d.protege) flags.push('🔒 protégé'); if (d.signe) flags.push('✍️ signé numériquement'); if (an.scannes) flags.push('🖨️ ' + an.scannes + ' page(s) scannée(s)'); if (an.formatsMixtes) flags.push('formats mixtes'); if (det) flags.push('cartouche existant');
    var h = '';
    h += '<details class="card" open><summary>1 · Document et classement</summary><div class="body"><div><b>' + esc(d.nom) + '</b><div class="note">' + (an.nbPages || 0) + ' page(s) — ' + esc(C.formatResume(an) || '') + ' — ' + fsize(d.taille) + '<br>Original : SHA-256 ' + esc(d.sha256.slice(0, 16)) + '… ' + (flags.length ? '<br>' + esc(flags.join(' · ')) : '') + '</div></div>'
      + '<label class="f">Projet<select data-k="projet_id"' + dis + '><option value="">— choisir —</option>' + pr.map(function (p) { return opt(p.id, d.classement.projet_id, pNom(p)); }).join('') + '</select></label>'
      + '<div class="row2"><label class="f">Type de document<select data-k="type"' + dis + '>' + Object.keys(C.TYPES).map(function (k) { return opt(k, d.classement.type, C.TYPES[k]); }).join('') + '</select></label><label class="f">Discipline<select data-c="champs.discipline"' + dis + '><option value="">—</option>' + C.DISCIPLINES.map(function (x) { return opt(x, cfg.champs.discipline); }).join('') + '</select></label></div>'
      + '<label class="f">Accès restreint à (noms ou « fonction: bureau_etudes », séparés par des virgules ; vide = tous)<input data-k="acces" value="' + esc((d.acces || []).join(', ')) + '"' + (V.act('administrer') ? '' : ' disabled') + '></label></div></details>';
    h += '<details class="card" open><summary>2 · Modèle et mise en page</summary><div class="body"><label class="f">Modèle<select data-c="modele"' + dis + '>' + C.MODELES.concat(V.modelesPerso()).map(function (m) { return opt(m.id, cfg.modele, m.nom + (m.integre ? '' : ' (personnalisé)')); }).join('') + '</select></label><div class="note">' + esc(tplx.desc || '') + '</div>';
    if (isPlan) {
      h += '<label class="f">Placement du cartouche<select data-c="mode"' + dis + '>' + opt('auto', cfg.mode || 'auto', 'Automatique (zone libre, sinon bande)') + opt('overlay', cfg.mode, 'Sur la page (zone libre)') + opt('band', cfg.mode, 'Bande ajoutée sous la page (rien n’est recouvert)') + opt('sheet', cfg.mode, 'Feuille de présentation distincte') + '</select></label>'
        + '<div class="row2"><label class="f">Position<select data-c="position"' + dis + '>' + opt('br', cfg.position || tplx.position, 'Bas droite') + opt('bl', cfg.position || tplx.position, 'Bas gauche') + opt('tr', cfg.position || tplx.position, 'Haut droite') + opt('tl', cfg.position || tplx.position, 'Haut gauche') + '</select></label><label class="f">Marge (mm)<input type="number" min="0" max="60" data-c="marge" value="' + esc(cfg.marge || tplx.marge || 10) + '"' + dis + '></label></div>';
      if (det) h += '<div class="w attention"><b>Cartouche existant détecté.</b> Que faire ?<br>' + [['conserver', 'Conserver (ne rien ajouter)'], ['remplacer', 'Remplacer (le nouveau recouvre l’ancien)'], ['ignorer', 'Ignorer (ajouter selon la zone libre)']].map(function (o) { return '<label class="chk"><input type="radio" name="cx" data-c="cartoucheExistant" value="' + o[0] + '"' + (cfg.cartoucheExistant === o[0] ? ' checked' : '') + dis + '>' + o[1] + '</label>'; }).join('') + '</div>';
      h += '<label class="chk"><input type="checkbox" data-o="accepteRecouvrement"' + (cfg.options && cfg.options.accepteRecouvrement ? ' checked' : '') + dis + '>J’accepte que le cartouche recouvre du contenu si je force « Sur la page »</label>';
    } else {
      [['couverture', 'Page de couverture'], ['sommaire', 'Sommaire'], ['pagination', 'Pagination, en-têtes et pieds de page'], ['filigrane', 'Filigrane de statut (discret)'], ['validation', 'Page de validation']].forEach(function (o) { var v = cfg.options && cfg.options[o[0]] != null ? cfg.options[o[0]] : tplx[o[0]]; h += '<label class="chk"><input type="checkbox" data-o="' + o[0] + '"' + (v ? ' checked' : '') + dis + '>' + o[1] + '</label>'; });
      if (cfg.modele === 'dossier') h += '<div class="note">Dossier complet : cochez dans la liste les autres documents à inclure (notes, plans, annexes).</div>';
    }
    if (d.signe) h += '<label class="chk"><input type="checkbox" data-o="accepteSignature"' + (cfg.options && cfg.options.accepteSignature ? ' checked' : '') + dis + '>Je comprends que la signature numérique sera invalidée dans la nouvelle version (l’original signé reste archivé).</label>';
    h += '</div></details>';
    h += '<details class="card" open><summary>3 · Cartouche et informations</summary><div class="body">';
    C.CHAMPS.forEach(function (c) { var k = c[0], v = cfg.champs[k] || '', ro = (k === 'format') ? '' : dis; if (k === 'discipline') return; h += '<label class="f' + (c[2] && !v ? ' miss' : '') + '">' + esc(c[1]) + (c[2] ? ' *' : '') + '<input data-c="champs.' + k + '" value="' + esc(v) + '" placeholder="' + (k === 'format' ? C.formatResume(an) : C.A_COMPLETER) + '"' + ro + '></label>'; });
    h += '<div class="acts"><button class="btn sm" type="button" data-a="proj"' + dis + '>↻ Reprendre les données du projet</button><button class="btn sm" type="button" data-a="nomfic"' + dis + '>Titre = nom du fichier</button><button class="btn sm" type="button" data-a="ocr">🔎 OCR (propositions)</button></div>'
      + '<div class="note">* obligatoire pour soumettre. Un champ vide reste affiché « À compléter » sur le document : rien n’est inventé. Les mentions dessiné / vérifié / approuvé viennent uniquement du circuit de validation.</div></div></details>';
    h += '<details class="card" open><summary>4 · Validation et export</summary><div class="body"><div>' + chip(d.statut) + ' <span class="note">' + esc(wfTxt(d)) + '</span></div><div class="acts">' + wfBtns(d) + '</div><hr style="border:0;border-top:1px solid var(--line);width:100%">'
      + '<div class="acts"><button class="btn gold" data-a="exp" type="button"' + (d.protege ? ' disabled' : '') + '>⬇️ Exporter ' + (d.statut === 'Émis' ? 'une copie' : 'un brouillon') + ' (PDF)</button>' + (V.peutEmettre(d) ? '<button class="btn ok" data-a="emettre" type="button">✅ Émettre (PDF final)</button>' : '') + '</div>'
      + '<div class="note">Chaque export crée une nouvelle version archivée ; l’original n’est jamais écrasé. Contrôle d’intégrité automatique (image et texte) hors zone ajoutée.</div></div></details>';
    P.innerHTML = h; bindProps(P);
  }
  function wfTxt(d) { var w = d.workflow || {}, a = []; if (w.auteur) a.push('Auteur : ' + w.auteur); if (w.verif) a.push('Visé par ' + w.verif.par + ' (' + C.dateFr(w.verif.t) + ')'); if (w.approuve) a.push('Approuvé par ' + w.approuve.par + ' (' + C.dateFr(w.approuve.t) + ')'); if (w.rejet && d.statut === 'À corriger') a.push('Motif : ' + w.rejet.motif); if (w.emis) a.push('Émis le ' + C.dateFr(w.emis.t)); return a.join(' · '); }
  function wfBtns(d) {
    var b = '';
    if (d.statut === 'Brouillon' || d.statut === 'À corriger') b += '<button class="btn pri" data-w="soumettre" type="button">📤 Soumettre à vérification</button>';
    if (d.statut === 'Pour vérification') { if (!d.workflow.verif) b += '<button class="btn pri" data-w="verifier" type="button">🔍 Viser (vérifier)</button><button class="btn err" data-w="corriger" type="button">↩️ Demander des corrections</button>'; else b += '<button class="btn ok" data-w="approuver" type="button">✔️ Approuver</button><button class="btn err" data-w="refuser" type="button">✖️ Refuser</button>'; }
    if (d.statut === 'Émis') b += '<button class="btn" data-w="revision" type="button">🆕 Nouvelle révision</button>';
    return b;
  }
  async function workflow(w) {
    var d = cur(); if (!d) return; var r;
    if (w === 'revision') { var q0 = await modal('Nouvelle révision', '<label class="f">Motif de la révision (obligatoire)<textarea name="t" rows="3"></textarea></label>', [{ t: 'Annuler' }, { t: 'Créer', c: 'pri' }]); if (q0.i !== 1) return; var n0 = await nomActeur('Identification'); r = V.nouvelleRevision(d, n0, q0.v.t); if (r.ok) { S.cur = r.doc.id; toast('Révision ' + C.indiceDe(r.doc.rev) + ' créée en brouillon.', 'ok'); } else toast(r.msg, 'err'); return renderAll(); }
    var nom = await nomActeur(w === 'soumettre' ? 'Soumettre à vérification' : 'Identification'); if (!nom) return;
    if (w === 'soumettre') r = V.soumettre(d, nom);
    else { var ok = w === 'verifier' || w === 'approuver', need = !(w === 'approuver'), titre = { verifier: 'Viser', corriger: 'Demander des corrections', approuver: 'Approuver', refuser: 'Refuser' }[w]; var q = await modal(titre, '<label class="f">' + (ok ? (w === 'verifier' ? 'Ce qui a été contrôlé (obligatoire)' : 'Commentaire (facultatif)') : 'Motif (obligatoire)') + '<textarea name="t" rows="3"></textarea></label>', [{ t: 'Annuler' }, { t: titre, c: ok ? 'ok' : 'err' }]); if (q.i !== 1) return; r = (w === 'verifier' || w === 'corriger') ? V.verifier(d, nom, w === 'verifier', q.v.t) : V.approuver(d, nom, w === 'approuver', q.v.t); }
    if (r.ok) { V.setNom(nom); toast('Statut : ' + d.statut + '.', 'ok'); } else toast(r.msg, 'err'); renderAll();
  }
  function bindProps(P) {
    P.querySelectorAll('[data-k],[data-c],[data-o]').forEach(function (el) {
      el.addEventListener(el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'radio' ? 'change' : 'input', function () {
        var d = cur(); if (!d || (locked(d) && !el.hasAttribute('data-k'))) return; var rerender = false;
        if (el.hasAttribute('data-k')) {
          var k = el.getAttribute('data-k');
          if (k === 'acces') d.acces = el.value.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
          else if (k === 'projet_id') { var p = projets().filter(function (x) { return String(x.id) === el.value; })[0]; d.classement.projet_id = el.value; d.classement.projet = p ? pNom(p) : ''; if (p) { d.config.champs = C.prefill(d.config.champs, p, d.analyse, d.rev); rerender = true; } }
          else { d.classement[k] = el.value; if (k === 'type') { var mm = { plan: 'plan', note: 'note', rapport: 'rapport', annexe: 'rapport' }[el.value]; if (d.config.modele !== 'dossier') d.config.modele = mm; rerender = true; } }
        } else if (el.hasAttribute('data-o')) { d.config.options = d.config.options || {}; d.config.options[el.getAttribute('data-o')] = el.checked; }
        else { var path = el.getAttribute('data-c').split('.'), val = el.type === 'radio' ? el.value : el.value; if (path[0] === 'champs') d.config.champs[path[1]] = val; else { d.config[path[0]] = val; if (path[0] === 'modele') { d.config.options = {}; rerender = true; } if (path[0] === 'mode' || path[0] === 'cartoucheExistant') rerender = true; } if (path[0] === 'champs') { var lab = el.closest('label'); if (lab) lab.classList.toggle('miss', !val && /\*/.test(lab.textContent)); } }
        V.putDoc(d); if (rerender) { renderProps(); renderList(); } refresh(); renderSteps();
      });
    });
    P.querySelectorAll('[data-a]').forEach(function (b) { b.onclick = function () { action(b.getAttribute('data-a')); }; });
    P.querySelectorAll('[data-w]').forEach(function (b) { b.onclick = function () { workflow(b.getAttribute('data-w')); }; });
  }
  async function action(a) {
    var d = cur(); if (!d) return;
    if (a === 'proj') { var p = projets().filter(function (x) { return String(x.id) === String(d.classement.projet_id); })[0]; if (!p) return toast('Choisissez d’abord un projet.', 'err'); ['projet', 'reference', 'client', 'localisation'].forEach(function (k) { d.config.champs[k] = ''; }); d.config.champs = C.prefill(d.config.champs, p, d.analyse, d.rev); V.putDoc(d); renderProps(); refresh(); }
    else if (a === 'nomfic') { d.config.champs.titre = d.nom.replace(/\.pdf$/i, '').replace(/[_]+/g, ' '); V.putDoc(d); renderProps(); refresh(); }
    else if (a === 'exp') exporter(false); else if (a === 'emettre') exporter(true); else if (a === 'ocr') ocr();
  }

  /* ---------------------------------------------------------------- OCR facultatif ---------------------------------------------------------------- */
  async function ocr() {
    var d = cur(); if (!d) return; if (!(await OC.disponible())) return modal('OCR indisponible', '<p>Les fichiers de reconnaissance de texte (Tesseract, français) ne sont pas installés avec cette application (dossier <code>vendor/tesseract/</code>). La saisie manuelle des champs reste possible ; l’OCR ne modifie jamais le PDF.</p>', [{ t: 'Fermer', c: 'pri' }]);
    try {
      var m = await ensure(d), cvs = [], n = Math.min(3, m.analyse.nbPages), h = await PV.ouvrir(await pdfjs(), m.bytes, m.pw); for (var i = 0; i < n; i++) { var c = document.createElement('canvas'); await PV.rendre(h, i, c, { maxW: 1800 }); cvs.push(c); }
      progress('Reconnaissance du texte…', 0); var r = await OC.lire(cvs, function (p) { progress('Reconnaissance du texte…', p); }); progress('');
      var ch = r.champs, lines = Object.keys(ch).map(function (k) { return '<label class="f">' + esc((C.CHAMPS.filter(function (x) { return x[0] === k; })[0] || [k, k])[1]) + '<input name="' + k + '" value="' + esc(ch[k]) + '"></label>'; }).join('');
      var q = await modal('Propositions de l’OCR — à vérifier', '<p class="note">Texte lu automatiquement : il peut contenir des erreurs. Corrigez avant d’appliquer ; seuls les champs encore vides seront remplis.</p>' + (lines || '<p>Aucune valeur reconnue.</p>') + '<label class="f">Texte reconnu (modifiable)<textarea rows="5" name="_t">' + esc(r.texte.slice(0, 3000)) + '</textarea></label>', [{ t: 'Fermer' }, { t: 'Appliquer aux champs vides', c: 'pri' }]);
      d.ocr = { t: Date.now(), texte: r.texte.slice(0, 2000) }; if (q.i === 1) { Object.keys(ch).forEach(function (k) { if (!d.config.champs[k] && q.v[k]) d.config.champs[k] = q.v[k]; }); V.log('ocr', d, { champs: Object.keys(ch) }); }
      V.putDoc(d); renderProps(); refresh();
    } catch (e) { progress(''); toast('OCR impossible : ' + (e && e.message || e), 'err'); }
  }

  /* ---------------------------------------------------------------- export, intégrité, archivage ---------------------------------------------------------------- */
  function nomSortie(d, statut, n) { var st = { 'Brouillon': 'BROUILLON', 'Pour vérification': 'POUR-VERIF', 'À corriger': 'A-CORRIGER', 'Approuvé': 'APPROUVE', 'Émis': 'EMIS' }[statut] || 'BROUILLON'; return slug(d.nom.replace(/\.pdf$/i, '')) + '_ind' + (d.config.champs.indice || 'A') + '_' + st + '_v' + n + '.pdf'; }
  async function exporter(emettre, dd, lot) {
    var d = dd || cur(); if (!d) return { ok: false, msg: 'Aucun document.' }; function ko(m) { if (!lot) toast(m, 'err'); return { ok: false, msg: m }; }
    if (!V.act('exporter')) return ko('Votre profil n’a pas le droit d’exporter.'); if (d.protege) return ko('PDF protégé : habillage refusé.');
    if (emettre && !V.peutEmettre(d)) return ko('Émission impossible : le document doit être approuvé et vous devez être habilité.');
    if (emettre) { var mq = C.manquants(d.config.champs); if (mq.length) return ko('Champs obligatoires à compléter : ' + mq.map(function (x) { return x.libelle; }).join(', ') + '.'); }
    var prev = S.cur; try {
      var job = await jobPour(d, false); if (emettre) { job.statut = 'Émis'; job.workflow = Object.assign({}, d.workflow, { emis: { par: V.actor().nom, t: Date.now() } }); job.qr = qrPour(d, 'Émis', job.meta.version); }
      var plan = L.plan(job); if (plan.bloquants.length) { if (!lot && d.id === S.cur) { S.lastWarns = plan.avertissements; renderWarns(S.lastWarns); } return ko(plan.bloquants[0].msg); }
      progress('Génération du PDF…'); var r = await X.build(PL, job, plan);
      progress('Contrôle d’intégrité…', 0); var ig = await PV.integrite(await pdfjs(), plan.docs.map(function (x) { return x.bytes; }), r.bytes, r.map, function (i, n) { progress('Contrôle d’intégrité : page ' + i + ' / ' + n, i / n); }); progress('');
      if (!ig.ok) {
        var det = ig.pages.filter(function (x) { return !x.ok; }).slice(0, 6).map(function (x) { return 'page ' + x.page + ' : ' + x.pixelsDifferents + ' px différents, ' + x.textesPerdus + ' texte(s) manquant(s)'; }).join(' ; ');
        if (emettre || lot) return ko('Contrôle d’intégrité en échec (' + det + ') — ' + (emettre ? 'émission refusée.' : 'fichier non enregistré.'));
        var q = await modal('Contrôle d’intégrité', '<p>Des différences ont été détectées entre l’original et la version habillée, en dehors de la zone ajoutée :</p><p class="note">' + esc(det) + '</p><p>Enregistrer quand même ce brouillon ?</p>', [{ t: 'Annuler' }, { t: 'Enregistrer le brouillon', c: 'pri' }]); if (q.i !== 1) return { ok: false, msg: 'Annulé.' };
      }
      var nom = V.actor().nom || (await nomActeur('Identification')); if (!nom) return ko('Identification requise pour tracer l’export.');
      var last = V.versions(d.id).slice(-1)[0], statut = emettre ? 'Émis' : d.statut, n = V.versions(d.id).length + 1, fic = nomSortie(d, statut, n);
      var v = await V.ajouterVersion(d, { bytes: r.bytes, statut: statut, nomFichier: fic, nbPages: r.map.length, par: nom, notes: r.notes.concat(plan.avertissements.filter(function (x) { return x.niv !== 'info'; })).map(function (x) { return x.msg; }).slice(0, 30), integrite: { ok: ig.ok, echantillon: ig.echantillon, total: ig.total }, champsModifies: V.champsModifies(last ? last.champs : {}, d.config.champs) });
      if (job.qr && job.qr.rec) { try { host.EXBVerif.publish(job.qr.rec); V.log('qr', d, { ref: job.qr.code, detail: 'QR de vérification enregistré — code ' + job.qr.code }); } catch (e) {} }
      dl(r.bytes, fic); if (emettre) await deposerArchives(d, r.bytes, fic, v);
      if (!lot) { toast((emettre ? 'Version émise ' : 'Version ') + v.tag + ' enregistrée et téléchargée — intégrité ' + (ig.ok ? 'contrôlée (' + ig.echantillon + ' page(s))' : 'avec écarts signalés') + '.', ig.ok ? 'ok' : 'err'); renderAll(); }
      return { ok: true, msg: v.tag + ' — ' + fic + (ig.ok ? '' : ' (écarts d’intégrité)') };
    } catch (e) { progress(''); return ko(String(e && e.message || e)); }
  }
  async function deposerArchives(d, bytes, fic, v) {
    try { var AR = host && host.EXBAR; if (!AR || !AR.add || bytes.length > 14 * 1048576) return; var r = await AR.add({ fichier: new Blob([bytes], { type: 'application/pdf' }), nom: fic, mime: 'application/pdf', titre: (d.config.champs.titre || d.nom).slice(0, 150), type: ({ plan: 'plan', note: 'note', rapport: 'rapport' }[d.classement.type] || 'autre'), projet: d.classement.projet || d.config.champs.projet || '', client: d.config.champs.client || '', source: 'atelier-mep', note: 'Version émise ' + v.tag + ' — Atelier de mise en page' }); if (r && r.ok) toast('Copie déposée dans les Archives.', 'ok'); } catch (e) { /* facultatif */ }
  }
  async function exporterLot() {
    var ids = Object.keys(S.sel).filter(function (k) { return S.sel[k]; }); if (ids.length < 2) return; var rows = [];
    for (var i = 0; i < ids.length; i++) { var d = V.getDoc(ids[i]); if (!d) continue; progress('Lot : ' + (i + 1) + ' / ' + ids.length + ' — ' + d.nom); var r = await exporter(false, d, true); rows.push({ nom: d.nom, r: r }); await new Promise(function (ok) { setTimeout(ok, 450); }); }
    progress(''); await modal('Résultat du traitement par lot', '<table><tr><th>Document</th><th>Résultat</th></tr>' + rows.map(function (x) { return '<tr><td>' + esc(x.nom) + '</td><td style="color:var(--' + (x.r.ok ? 'ok' : 'err') + ')">' + esc(x.r.ok ? 'OK — ' + x.r.msg : 'Échec — ' + x.r.msg) + '</td></tr>'; }).join('') + '</table><p class="note">Chaque document échoue ou réussit séparément ; un échec n’arrête pas le lot.</p>', [{ t: 'Fermer', c: 'pri' }]); renderAll();
  }

  /* ---------------------------------------------------------------- écrans ---------------------------------------------------------------- */
  function renderList() {
    var a = liste(), L0 = $('list'); if (!a.length) { L0.innerHTML = '<div class="empty">Aucun document. Importez un PDF.</div>'; $('lotBar').hidden = true; return; }
    L0.innerHTML = a.map(function (d) { var c = d.config.modele === 'dossier' && d.id !== S.cur; return '<div class="ditem' + (d.id === S.cur ? ' on' : '') + '" data-id="' + esc(d.id) + '"><input type="checkbox" data-sel="' + esc(d.id) + '"' + (S.sel[d.id] ? ' checked' : '') + ' aria-label="Sélectionner ' + esc(d.nom) + '"><div style="min-width:0"><div class="t">' + esc(d.nom) + '</div><div class="m">' + chip(d.statut) + ' ' + esc(C.TYPES[d.classement.type] || '') + ' · ' + ((d.analyse && d.analyse.nbPages) || '?') + ' p.' + (d.protege ? ' 🔒' : '') + (d.signe ? ' ✍️' : '') + '</div></div></div>'; }).join('');
    var n = Object.keys(S.sel).filter(function (k) { return S.sel[k]; }).length, cd = cur(), dossier = cd && cd.config.modele === 'dossier', lb = $('lotBar'); lb.hidden = !n;
    lb.innerHTML = dossier ? '<div class="note">' + n + ' document(s) coché(s) seront inclus dans le dossier complet.</div>' : '<div class="note">' + n + ' document(s) coché(s).</div><button class="btn sm gold" id="lotGo" type="button"' + (n < 2 ? ' disabled' : '') + '>⬇️ Exporter le lot (brouillons)</button>';
    var lg = $('lotGo'); if (lg) lg.onclick = exporterLot;
  }
  function renderDash() {
    var a = liste(), cnt = function (s) { return a.filter(function (d) { return d.statut === s; }).length; }, vs = V.versions().length, att = a.filter(function (d) { return d.statut === 'Pour vérification'; }), j = V.journal().slice(0, 8);
    $('s-dash').innerHTML = '<div class="kpis"><div class="kpi"><b>' + a.length + '</b><span>Documents importés</span></div><div class="kpi"><b>' + cnt('Brouillon') + '</b><span>Brouillons</span></div><div class="kpi"><b>' + cnt('Pour vérification') + '</b><span>À vérifier / approuver</span></div><div class="kpi"><b>' + cnt('À corriger') + '</b><span>À corriger</span></div><div class="kpi"><b>' + cnt('Approuvé') + '</b><span>Approuvés</span></div><div class="kpi"><b>' + cnt('Émis') + '</b><span>Émis</span></div><div class="kpi"><b>' + vs + '</b><span>Versions produites</span></div></div>'
      + '<div class="card" style="margin-bottom:12px"><h2>En attente de validation</h2><div class="body">' + (att.length ? '<table><tr><th>Document</th><th>Auteur</th><th></th></tr>' + att.map(function (d) { return '<tr><td>' + esc(d.nom) + '</td><td>' + esc(d.workflow.auteur || '') + '</td><td><button class="btn sm" data-open="' + esc(d.id) + '" type="button">Ouvrir</button></td></tr>'; }).join('') + '</table>' : '<div class="note">Rien en attente.</div>') + '</div></div>'
      + '<div class="card"><h2>Dernières actions</h2><div class="body">' + (j.length ? '<table><tr><th>Date</th><th>Qui</th><th>Action</th><th>Document</th></tr>' + j.map(function (e) { return '<tr><td>' + fdate(e.t) + '</td><td>' + esc(e.par) + '</td><td>' + esc(e.action) + '</td><td>' + esc(e.nom) + '</td></tr>'; }).join('') + '</table>' : '<div class="note">Aucune action enregistrée.</div>') + '</div></div>';
    $('s-dash').querySelectorAll('[data-open]').forEach(function (b) { b.onclick = function () { S.cur = b.getAttribute('data-open'); go('atelier'); }; });
  }
  function renderModeles() {
    var adm = V.act('administrer'), all = C.MODELES.concat(V.modelesPerso()), cfg = V.config();
    $('s-modeles').innerHTML = '<div class="kpis">' + all.map(function (m) { return '<div class="card"><h2>' + esc(m.nom) + (m.integre ? '' : ' · perso') + '</h2><div class="body"><div class="note">' + esc(m.desc || '') + '</div><div class="note">Position ' + esc(m.position) + ' · marge ' + esc(m.marge) + ' mm' + (m.couverture ? ' · couverture' : '') + (m.sommaire ? ' · sommaire' : '') + (m.pagination ? ' · pagination' : '') + (m.filigrane ? ' · filigrane' : '') + (m.validation ? ' · validation' : '') + '</div><div class="acts">' + (adm ? '<button class="btn sm" data-dup="' + esc(m.id) + '" type="button">Dupliquer</button>' : '') + (adm && !m.integre ? '<button class="btn sm" data-edit="' + esc(m.id) + '" type="button">Modifier</button><button class="btn sm err" data-del="' + esc(m.id) + '" type="button">Supprimer</button>' : '') + '</div></div></div>'; }).join('') + '</div>'
      + '<div class="card"><h2>Paramètres</h2><div class="body"><label class="f">Durée de conservation des versions produites (années)<input type="number" min="1" max="99" id="cfgAns" value="' + esc(cfg.conservationAns) + '"' + (adm ? '' : ' disabled') + '></label><div class="note">Les modèles personnalisés et les paramètres sont réservés aux administrateurs (droit « administrer »). Les versions ne sont jamais supprimées : la durée indique l’échéance de conservation.</div></div></div>';
    var an = $('cfgAns'); if (an) an.onchange = function () { V.setConfig({ conservationAns: +an.value || 10 }); V.log('parametres', null, { detail: 'conservation ' + an.value + ' ans' }); toast('Paramètre enregistré.', 'ok'); };
    $('s-modeles').querySelectorAll('[data-dup]').forEach(function (b) { b.onclick = async function () { var m = C.modele(b.getAttribute('data-dup'), V.modelesPerso()), q = await modal('Dupliquer le modèle', '<label class="f">Nom du nouveau modèle<input name="n" value="' + esc(m.nom + ' (copie)') + '"></label>', [{ t: 'Annuler' }, { t: 'Créer', c: 'pri' }]); if (q.i !== 1 || !q.v.n.trim()) return; m.id = 'perso-' + Date.now().toString(36); m.nom = q.v.n.trim(); m.integre = false; var p = V.modelesPerso(); p.push(m); V.setModeles(p); V.log('modele', null, { detail: 'création ' + m.nom }); renderModeles(); }; });
    $('s-modeles').querySelectorAll('[data-del]').forEach(function (b) { b.onclick = function () { var id = b.getAttribute('data-del'); V.setModeles(V.modelesPerso().filter(function (m) { return m.id !== id; })); V.log('modele', null, { detail: 'suppression ' + id }); renderModeles(); }; });
    $('s-modeles').querySelectorAll('[data-edit]').forEach(function (b) { b.onclick = async function () { var id = b.getAttribute('data-edit'), p = V.modelesPerso(), m = p.filter(function (x) { return x.id === id; })[0]; if (!m) return; var q = await modal('Modifier « ' + m.nom + ' »', '<label class="f">Nom<input name="nom" value="' + esc(m.nom) + '"></label><div class="row2"><label class="f">Position<select name="position">' + ['br', 'bl', 'tr', 'tl'].map(function (x) { return opt(x, m.position); }).join('') + '</select></label><label class="f">Marge (mm)<input name="marge" type="number" value="' + esc(m.marge) + '"></label></div><label class="f">Largeur du cartouche (mm, 0 = automatique)<input name="largeur" type="number" value="' + esc(m.largeur || 0) + '"></label><label class="f">Texte d’en-tête<input name="enteteTexte" value="' + esc(m.enteteTexte || '') + '"></label><label class="f">Texte de pied de page<input name="piedTexte" value="' + esc(m.piedTexte || '') + '"></label><div class="note">Variables : {projet} {titre} {numero} {indice} {client} {reference} {date}</div>' + ['couverture', 'sommaire', 'pagination', 'filigrane', 'validation'].map(function (k) { return '<label class="chk"><input type="checkbox" name="' + k + '"' + (m[k] ? ' checked' : '') + '>' + k + '</label>'; }).join(''), [{ t: 'Annuler' }, { t: 'Enregistrer', c: 'pri' }]); if (q.i !== 1) return; Object.keys(q.v).forEach(function (k) { m[k] = (k === 'marge' || k === 'largeur') ? +q.v[k] || 0 : q.v[k]; }); V.setModeles(p); V.log('modele', null, { detail: 'modification ' + m.nom }); renderModeles(); }; });
  }
  function renderHisto() {
    var a = liste(), f = S.hf || '', vs = V.versions(f || undefined).slice().reverse(), j = V.journal(f || undefined).slice(0, 200);
    $('s-histo').innerHTML = '<div class="card" style="margin-bottom:12px"><h2>Versions et originaux</h2><div class="body"><label class="f">Document<select id="hf"><option value="">Tous</option>' + a.map(function (d) { return opt(d.id, f, d.nom); }).join('') + '</select></label>'
      + (vs.length ? '<div style="overflow:auto"><table><tr><th>Date</th><th>Document</th><th>Version</th><th>Statut</th><th>Par</th><th>Pages</th><th>Taille</th><th>SHA-256</th><th>Conservé jusqu’au</th><th></th></tr>' + vs.map(function (v) { var d = V.getDoc(v.doc); return '<tr><td>' + fdate(v.t) + '</td><td>' + esc(d ? d.nom : v.doc) + '</td><td>' + esc(v.tag) + '</td><td>' + chip(v.statut) + '</td><td>' + esc(v.par) + '</td><td>' + v.nbPages + '</td><td>' + fsize(v.taille) + '</td><td title="' + esc(v.sha256) + '">' + esc(v.sha256.slice(0, 10)) + '…</td><td>' + esc(v.conserveJusquau || '') + '</td><td style="white-space:nowrap"><button class="btn sm" data-dv="' + esc(v.id) + '" type="button">⬇️</button> <button class="btn sm" data-iv="' + esc(v.sha256) + '" type="button">Intégrité</button></td></tr>'; }).join('') + '</table></div>' : '<div class="note">Aucune version produite.</div>')
      + (a.length ? '<div class="note">Originaux (jamais modifiés) :</div><div style="overflow:auto"><table><tr><th>Document</th><th>Importé</th><th>SHA-256</th><th></th></tr>' + a.filter(function (d) { return !f || d.id === f; }).map(function (d) { return '<tr><td>' + esc(d.nom) + '</td><td>' + fdate(d.importeLe) + ' — ' + esc(d.importePar || '') + '</td><td title="' + esc(d.sha256) + '">' + esc(d.sha256.slice(0, 12)) + '…</td><td style="white-space:nowrap"><button class="btn sm" data-do="' + esc(d.id) + '" type="button">⬇️ Original</button> <button class="btn sm" data-iv="' + esc(d.sha256) + '" type="button">Intégrité</button></td></tr>'; }).join('') + '</table></div>' : '') + '</div></div>'
      + '<div class="card"><h2>Journal d’audit (ajout seul)</h2><div class="body"><div style="overflow:auto"><table><tr><th>Date</th><th>Qui</th><th>Action</th><th>Document</th><th>Statut</th><th>Détail</th></tr>' + j.map(function (e) { return '<tr><td>' + fdate(e.t) + '</td><td>' + esc(e.par) + '</td><td>' + esc(e.action) + '</td><td>' + esc(e.nom) + '</td><td>' + esc(e.statut) + '</td><td>' + esc((e.detail || '') + (e.champs && e.champs.length ? ' [champs : ' + e.champs.join(', ') + ']' : '')) + '</td></tr>'; }).join('') + '</table></div></div></div>';
    var hf = $('hf'); hf.onchange = function () { S.hf = hf.value; renderHisto(); };
    $('s-histo').querySelectorAll('[data-dv]').forEach(function (b) { b.onclick = async function () { var v = V.versions().filter(function (x) { return x.id === b.getAttribute('data-dv'); })[0], by = v && await V.getFile(v.sha256); if (!by) return toast('Fichier introuvable.', 'err'); if (!V.act('exporter')) return toast('Droit « exporter » requis.', 'err'); dl(by, v.nom); V.log('telechargement', V.getDoc(v.doc), { ref: v.sha256, detail: v.tag }); }; });
    $('s-histo').querySelectorAll('[data-do]').forEach(function (b) { b.onclick = async function () { var d = V.getDoc(b.getAttribute('data-do')), by = d && await V.getFile(d.sha256); if (!by) return toast('Original introuvable.', 'err'); dl(by, d.nom); V.log('telechargement', d, { ref: d.sha256, detail: 'original' }); }; });
    $('s-histo').querySelectorAll('[data-iv]').forEach(function (b) { b.onclick = async function () { var r = await V.verifierIntegrite(b.getAttribute('data-iv')); toast(r.ok ? 'Empreinte SHA-256 conforme : fichier inchangé.' : 'ALERTE : ' + r.msg, r.ok ? 'ok' : 'err'); }; });
  }
  var STEPS = ['Importer', 'Analyser', 'Classer', 'Modèle', 'Configurer', 'Prévisualiser', 'Exporter', 'Archiver'];
  function renderSteps() {
    var d = cur(), a = liste(), vs = d ? V.versions(d.id).length : 0, done = [a.length > 0, !!(d && d.analyse), !!(d && d.classement.projet_id && d.classement.type), !!d, !!(d && !C.manquants(d.config.champs).length), !!S.after, vs > 0, vs > 0], first = done.indexOf(false);
    $('steps').innerHTML = STEPS.map(function (s, i) { return '<li class="' + (done[i] ? 'done' : i === first ? 'on' : '') + '"><span class="n">' + (done[i] ? '✓' : i + 1) + '</span>' + s + '</li>'; }).join('');
  }
  function renderAll() { $('who').textContent = V.actor().nom || 'Non identifié'; renderList(); renderProps(); renderDash(); renderModeles(); renderHisto(); renderSteps(); refresh(true); }
  function go(s) {
    S.screen = s; document.body.classList.toggle('wide', s === 'apercu'); var real = s === 'apercu' ? 'atelier' : s;
    document.querySelectorAll('.scr').forEach(function (e) { e.classList.toggle('on', e.id === 's-' + real); }); document.querySelectorAll('#tabs button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-s') === s); });
    if (s === 'dash') renderDash(); if (s === 'modeles') renderModeles(); if (s === 'histo') renderHisto(); if (s === 'atelier' || s === 'apercu') { renderAll(); } try { window.scrollTo(0, 0); } catch (e) {}
  }

  /* ---------------------------------------------------------------- événements ---------------------------------------------------------------- */
  function init() {
    try { var t = host && host.document.documentElement.getAttribute('data-theme'); if (t) document.documentElement.setAttribute('data-theme', t); } catch (e) {}
    $('tabs').addEventListener('click', function (e) { var b = e.target.closest('button[data-s]'); if (b) go(b.getAttribute('data-s')); });
    $('bImp').onclick = function () { go('import'); }; $('bMod').onclick = function () { go('modeles'); }; $('bSave').onclick = function () { var d = cur(); if (d) { V.putDoc(d); V.log('enregistre', d, { detail: 'configuration' }); toast('Configuration enregistrée.', 'ok'); } else toast('Aucun document.', 'err'); };
    $('bExp').onclick = function () { exporter(false); };
    var dr = $('drop'), fi = $('file'); $('pick').onclick = function () { fi.click(); }; fi.onchange = function () { if (fi.files.length) importer(Array.prototype.slice.call(fi.files)); fi.value = ''; };
    ['dragenter', 'dragover'].forEach(function (ev) { dr.addEventListener(ev, function (e) { e.preventDefault(); dr.classList.add('over'); }); }); ['dragleave', 'drop'].forEach(function (ev) { dr.addEventListener(ev, function (e) { e.preventDefault(); dr.classList.remove('over'); }); });
    dr.addEventListener('drop', function (e) { var fs = Array.prototype.slice.call(e.dataTransfer.files).filter(function (f) { return /\.pdf$/i.test(f.name) || f.type === 'application/pdf'; }); if (fs.length) importer(fs); });
    $('list').addEventListener('click', function (e) { var c = e.target.closest('[data-sel]'); if (c) { S.sel[c.getAttribute('data-sel')] = c.checked; renderList(); if (cur() && cur().config.modele === 'dossier') refresh(); return; } var it = e.target.closest('.ditem'); if (it) { S.cur = it.getAttribute('data-id'); S.page = 0; S.origPdf = {}; renderAll(); } });
    $('vmode').addEventListener('click', function (e) { var b = e.target.closest('button[data-m]'); if (!b) return; S.vue = b.getAttribute('data-m'); document.querySelectorAll('#vmode button').forEach(function (x) { x.classList.toggle('on', x === b); }); draw(); });
    $('pPrev').onclick = function () { if (S.page > 0) { S.page--; draw(); } }; $('pNext').onclick = function () { if (S.page < total() - 1) { S.page++; draw(); } };
    $('zIn').onclick = function () { S.zoom = Math.min(4, S.zoom * 1.25); draw(); }; $('zOut').onclick = function () { S.zoom = Math.max(0.25, S.zoom / 1.25); draw(); }; $('rot').onclick = function () { S.rot = (S.rot + 90) % 360; draw(); };
    $('thumbs').addEventListener('click', function (e) { var b = e.target.closest('button[data-p]'); if (b) { S.page = +b.getAttribute('data-p'); draw(); } });
    var rt; window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(draw, 250); });
    chargerIdentite().then(function () { renderAll(); });
    /* V214 : envoi des fichiers PDF au serveur (espace privé) dès qu'une connexion est disponible */
    try { V.syncFichiers(); setInterval(function () { V.syncFichiers(); }, 60000); window.addEventListener('online', function () { V.syncFichiers(); }); } catch (e) {}
    var a = liste(); if (a.length) S.cur = a[0].id; renderAll();
  }
  window.EXBATELIER = { refresh: function () { renderAll(); }, importer: importer, version: 'V209-atelier-mep' };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
