/* Excellencia Building — ATELIER DE MISE EN PAGE · exb-doc-layout (règles de mise en page).
 * Module PUR : à partir de l'analyse des pages (formats, orientations, encre par zone) et de la configuration, décide où chaque élément est posé
 * et produit la liste des pages de sortie avec leurs éléments dessinables (rectangles, traits, textes, logo), en millimètres, origine en haut à gauche.
 * Principe : la page d'origine n'est jamais modifiée ni redimensionnée. Un cartouche est (1) posé sur une zone LIBRE de la page,
 * (2) ou ajouté dans une BANDE sous la page (la page d'origine reste intacte, en haut), (3) ou placé sur une FEUILLE DE PRÉSENTATION distincte.
 * Aucun cartouche n'est posé sur du contenu sans que l'utilisateur l'ait accepté (alors signalé « bloquant » tant que non confirmé). */
(function (g) {
  'use strict';
  var NS = g.EXBDOC = g.EXBDOC || {}, C = NS.cartouche || (typeof require !== 'undefined' ? require('./exb-cartouche.js') : null);
  var NAVY = '#0B2A5B', GOLD = '#E3A900', GREY = '#56667F', LINE = '#0B2A5B', WARN = '#B26A00', INK = '#0F1D36';
  var STCOL = { 'Brouillon': '#6b7280', 'Pour vérification': '#1d4ed8', 'À corriger': '#C23030', 'Approuvé': '#15803d', 'Émis': '#0f766e' };
  var A4 = { W: 210, H: 297 };
  var FORMATS = [['A0', 841, 1189], ['A1', 594, 841], ['A2', 420, 594], ['A3', 297, 420], ['A4', 210, 297], ['A5', 148, 210]];
  var LIBRE_MEAN = 0.012, LIBRE_MAX = 0.10;     /* zone « libre » : encre moyenne ≤ 1,2 % et aucune cellule > 10 % */

  function round1(n) { return Math.round(n * 10) / 10; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  /* ------------------------------------------------------------------ format / orientation ------------------------------------------------------------------ */
  function detectFormat(wmm, hmm) {
    var lo = Math.min(wmm, hmm), hi = Math.max(wmm, hmm), best = null;
    FORMATS.forEach(function (f) { var e = Math.max(Math.abs(lo - f[1]) / f[1], Math.abs(hi - f[2]) / f[2]); if (!best || e < best.e) best = { nom: f[0], e: e }; });
    var orient = Math.abs(wmm - hmm) / hi < 0.01 ? 'carré' : (wmm > hmm ? 'paysage' : 'portrait'), nom, exact = false;
    if (best.e <= 0.015) { nom = best.nom; exact = true; } else if (best.e <= 0.05) nom = '≈' + best.nom; else nom = 'Perso ' + Math.round(lo) + '×' + Math.round(hi);
    return { nom: nom, base: best.e <= 0.05 ? best.nom : '', exact: exact, orient: orient, wmm: round1(wmm), hmm: round1(hmm) };
  }

  /* ------------------------------------------------------------------ encre par zone ------------------------------------------------------------------ */
  /* grille = { n, data: Uint8Array(n*n) } ; chaque cellule = fraction d'encre × 255 ; couvre toute la page (W×H mm). */
  function rectInk(grid, W, H, r) {
    if (!grid || !grid.data) return null;
    var n = grid.n, cw = W / n, ch = H / n, x0 = clamp(r.x, 0, W), y0 = clamp(r.y, 0, H), x1 = clamp(r.x + r.w, 0, W), y1 = clamp(r.y + r.h, 0, H), sum = 0, area = 0, max = 0;
    if (x1 <= x0 || y1 <= y0) return { mean: 0, max: 0 };
    for (var j = Math.floor(y0 / ch); j <= Math.min(n - 1, Math.floor((y1 - 1e-9) / ch)); j++) for (var i = Math.floor(x0 / cw); i <= Math.min(n - 1, Math.floor((x1 - 1e-9) / cw)); i++) {
      var ox = Math.min(x1, (i + 1) * cw) - Math.max(x0, i * cw), oy = Math.min(y1, (j + 1) * ch) - Math.max(y0, j * ch); if (ox <= 0 || oy <= 0) continue;
      var v = grid.data[j * n + i] / 255; sum += v * ox * oy; area += ox * oy; if (v > max) max = v;
    }
    return area ? { mean: sum / area, max: max } : { mean: 0, max: 0 };
  }
  function libre(ink) { return !!ink && ink.mean <= LIBRE_MEAN && ink.max <= LIBRE_MAX; }

  /* ------------------------------------------------------------------ géométrie du cartouche ------------------------------------------------------------------ */
  function cartSize(W, H, tpl, qr) {
    var w = tpl && +tpl.largeur > 0 ? +tpl.largeur : clamp(Math.max(W, H) * 0.25, 120, 200);
    w = Math.min(w, Math.max(60, W - 2 * ((tpl && tpl.marge) || 10)));
    var u = w / 120, hh = Math.max(12, 0.115 * w), rh = Math.max(5.2, 0.052 * w);
    var qh = qr ? round1(Math.max(16, 0.15 * w)) : 0;
    return { w: round1(w), h: round1(hh + rh * 7.8 + qh), hh: hh, rh: rh, u: u, qh: qh };
  }
  function placeRect(pos, W, H, sz, m) {
    var x = /l$/.test(pos) ? m : W - m - sz.w, y = /^t/.test(pos) ? m : H - m - sz.h;
    return { x: round1(x), y: round1(y), w: sz.w, h: sz.h };
  }

  /* Cartouche Excellencia Building : éléments relatifs à (x0, y0). */
  function cartouche(x0, y0, sz, o) {
    var E = [], w = sz.w, hh = sz.hh, rh = sz.rh, ch = o.champs || {}, V = C.visas(o.workflow, o.statut), y = y0, lbl = Math.max(1.7, rh * 0.26), val = clamp(rh * 0.40, 2.2, 4.2), lw = 0.25;
    E.push({ t: 'rect', x: x0, y: y0, w: w, h: sz.h, fill: '#FFFFFF' });
    /* en-tête : logo + nom */
    var lw1 = w * 0.30;
    E.push({ t: 'rect', x: x0, y: y0, w: lw1, h: hh, stroke: LINE, lw: lw });
    if (o.logo) E.push({ t: 'img', key: 'logo', x: x0 + 1.2, y: y0 + 1.2, w: lw1 - 2.4, h: hh - 2.4 }); else E.push({ t: 'text', s: 'LOGO À FOURNIR', x: x0 + lw1 / 2, y: y0 + hh / 2 + 1, size: lbl, align: 'c', color: WARN, font: 'i', maxW: lw1 - 2 });
    E.push({ t: 'rect', x: x0 + lw1, y: y0, w: w - lw1, h: hh, stroke: LINE, lw: lw });
    E.push({ t: 'text', s: String((o.entreprise && o.entreprise.nom) || 'Excellencia Building').toUpperCase(), x: x0 + lw1 + 2, y: y0 + hh * 0.46, size: clamp(hh * 0.27, 2.6, 5.4), font: 'b', color: NAVY, maxW: w - lw1 - 4 });
    E.push({ t: 'text', s: String((o.entreprise && o.entreprise.slogan) || (C && 'Bureau d’études — Ingénieur')), x: x0 + lw1 + 2, y: y0 + hh * 0.80, size: clamp(hh * 0.17, 1.8, 3.2), font: 'i', color: GREY, maxW: w - lw1 - 4 });
    E.push({ t: 'line', x1: x0, y1: y0 + hh, x2: x0 + w, y2: y0 + hh, lw: 0.8, color: GOLD });
    y += hh;
    function cell(x, yy, cw, chh, label, field, bold) {
      var v = typeof field === 'string' ? C.valeur(ch, field) : field;
      E.push({ t: 'rect', x: x, y: yy, w: cw, h: chh, stroke: LINE, lw: lw });
      E.push({ t: 'text', s: label, x: x + 1, y: yy + lbl + 0.5, size: lbl, color: GREY, maxW: cw - 2 });
      E.push({ t: 'text', s: v.v, x: x + 1.2, y: yy + chh - Math.max(0.9, chh * 0.16), size: bold ? val * 1.1 : val, font: v.manque ? 'i' : 'b', color: v.manque ? WARN : INK, maxW: cw - 2.4, fit: true, champ: label });
    }
    function row(h, cells) { var x = x0; cells.forEach(function (c) { var cw = w * c[0]; cell(x, y, cw, h, c[1], c[2], c[3]); x += cw; }); y += h; }
    row(rh, [[0.68, 'Projet', 'projet'], [0.32, 'Référence du projet', 'reference']]);
    row(rh, [[0.50, 'Client / maître d’ouvrage', 'client'], [0.50, 'Localisation', 'localisation']]);
    row(rh * 1.5, [[1, 'Titre du document', 'titre', true]]);
    row(rh, [[0.42, 'Discipline', 'discipline'], [0.38, 'N° du document', 'numero'], [0.20, 'Indice', 'indice']]);
    row(rh, [[0.34, 'Format', 'format'], [0.33, 'Échelle', 'echelle'], [0.33, 'Date', 'date']]);
    var vv = function (o2) { return o2 ? { v: o2.nom + (o2.date ? ' — ' + o2.date : ''), manque: false } : { v: C.A_COMPLETER, manque: true }; };
    row(rh * 1.3, [[0.34, 'Dessiné par', vv(V.dessine)], [0.33, 'Vérifié par', vv(V.verifie)], [0.33, 'Approuvé par', vv(V.approuve)]]);
    /* statut + feuille */
    var sw = w * 0.5, fx = x0 + sw;
    E.push({ t: 'rect', x: x0, y: y, w: sw, h: rh, fill: STCOL[V.statut] || '#6b7280', stroke: LINE, lw: lw });
    E.push({ t: 'text', s: 'STATUT : ' + V.statut.toUpperCase(), x: x0 + sw / 2, y: y + rh * 0.64, size: clamp(rh * 0.36, 2, 3.8), font: 'b', color: '#FFFFFF', align: 'c', maxW: sw - 2 });
    E.push({ t: 'rect', x: fx, y: y, w: w - sw, h: rh, stroke: LINE, lw: lw });
    E.push({ t: 'text', s: 'Feuille ' + o.feuille + ' / ' + o.feuilles, x: fx + (w - sw) / 2, y: y + rh * 0.64, size: clamp(rh * 0.38, 2.1, 4), font: 'b', color: INK, align: 'c', maxW: w - sw - 2 });
    y += rh;
    if (sz.qh && o.qr) {   /* V214 : QR de vérification (vectoriel) + code lisible */
      var qs = sz.qh - 3, tx = x0 + qs + 4.5, tw = w - qs - 6.5, ls = clamp(rh * 0.36, 2, 3.8);
      E.push({ t: 'rect', x: x0, y: y, w: w, h: sz.qh, stroke: LINE, lw: lw });
      E.push({ t: 'qr', x: x0 + 1.5, y: y + 1.5, s: qs });
      E.push({ t: 'text', s: 'VÉRIFICATION DU DOCUMENT', x: tx, y: y + qs * 0.26, size: ls, font: 'b', color: NAVY, maxW: tw });
      E.push({ t: 'text', s: 'Scannez le QR code pour contrôler', x: tx, y: y + qs * 0.46, size: ls * 0.82, color: GREY, maxW: tw });
      E.push({ t: 'text', s: 'l’authenticité et la version en vigueur.', x: tx, y: y + qs * 0.62, size: ls * 0.82, color: GREY, maxW: tw });
      E.push({ t: 'text', s: 'Code : ' + (o.qr.code || ''), x: tx, y: y + qs * 0.88, size: ls, font: 'b', color: INK, maxW: tw });
      y += sz.qh;
    }
    E.push({ t: 'rect', x: x0, y: y0, w: w, h: y - y0, stroke: LINE, lw: 0.6 });
    return { els: E, h: y - y0 };
  }

  /* ------------------------------------------------------------------ en-tête / pied de page (notes, rapports) ------------------------------------------------------------------ */
  function enteteEtPied(W, H, f, m, o, hdrAt, ftAt) {
    var E = [], sz = 2.5 * f, ch = o.champs || {}, tpl = o.tpl || {}, nom = (o.entreprise && o.entreprise.nom) || 'Excellencia Building';
    var left = C.gabarit(tpl.enteteTexte, ch), foot = C.gabarit(tpl.piedTexte, ch);
    if (o.qr && o.qr.code) foot = (foot ? foot + '  ·  ' : '') + 'Vérif. ' + o.qr.code;
    if (left || nom) {
      E.push({ t: 'text', s: left, x: m, y: hdrAt, size: sz, font: 'b', color: NAVY, maxW: (W - 2 * m) * 0.62 });
      E.push({ t: 'text', s: nom, x: W - m, y: hdrAt, size: sz, color: GREY, align: 'r', maxW: (W - 2 * m) * 0.36 });
      E.push({ t: 'line', x1: m, y1: hdrAt + 1.3 * f, x2: W - m, y2: hdrAt + 1.3 * f, lw: 0.25, color: GOLD });
    }
    E.push({ t: 'line', x1: m, y1: ftAt - sz - 0.8 * f, x2: W - m, y2: ftAt - sz - 0.8 * f, lw: 0.25, color: GOLD });
    if (foot) E.push({ t: 'text', s: foot, x: m, y: ftAt, size: sz, color: GREY, maxW: (W - 2 * m) * 0.7 });
    if (tpl.pagination) E.push({ t: 'text', s: 'Page ' + o.num + ' / ' + o.total, x: W - m, y: ftAt, size: sz, font: 'b', color: NAVY, align: 'r', maxW: (W - 2 * m) * 0.28 });
    return E;
  }

  /* ------------------------------------------------------------------ pages générées ------------------------------------------------------------------ */
  function enTeteMarque(E, o, title, sub) {
    var W = A4.W, nm = String((o.entreprise && o.entreprise.nom) || 'Excellencia Building');
    E.push({ t: 'rect', x: 0, y: 0, w: W, h: 38, fill: NAVY });
    E.push({ t: 'rect', x: 0, y: 38, w: W, h: 1.6, fill: GOLD });
    if (o.logo) { E.push({ t: 'rect', x: 12, y: 7, w: 40, h: 24, fill: '#FFFFFF' }); E.push({ t: 'img', key: 'logo', x: 13.5, y: 8.5, w: 37, h: 21 }); }
    var qw = o.qr ? 36 : 0;
    if (o.qr) {   /* V214 : QR de vérification dans le bandeau */
      E.push({ t: 'rect', x: W - 14 - 29, y: 4.5, w: 29, h: 29, fill: '#FFFFFF' }); E.push({ t: 'qr', x: W - 14 - 29, y: 4.5, s: 29 });
      E.push({ t: 'text', s: 'Vérifier : ' + (o.qr.code || ''), x: W - 14, y: 36.4, size: 2.3, font: 'b', color: '#F5CB45', align: 'r', maxW: 60 });
    }
    E.push({ t: 'text', s: nm.toUpperCase(), x: o.logo ? 58 : 14, y: 19, size: 7, font: 'b', color: '#FFFFFF', maxW: W - 70 - qw });
    E.push({ t: 'text', s: String((o.entreprise && o.entreprise.slogan) || 'Bureau d’études — Ingénieur'), x: o.logo ? 58 : 14, y: 27, size: 3.4, font: 'i', color: '#F5CB45', maxW: W - 70 - qw });
    if (title) E.push({ t: 'text', s: title, x: 14, y: 62, size: 9, font: 'b', color: NAVY, maxW: W - 28 });
    if (sub) E.push({ t: 'text', s: sub, x: 14, y: 71, size: 4, color: GREY, maxW: W - 28 });
  }
  function tableauInfos(E, x, y, w, rows, rh) {
    rows.forEach(function (r, i) {
      var yy = y + i * rh, v = r[1] ? { v: r[1], manque: false } : { v: C.A_COMPLETER, manque: true };
      E.push({ t: 'rect', x: x, y: yy, w: w * 0.32, h: rh, fill: '#EDF1F7', stroke: LINE, lw: 0.25 });
      E.push({ t: 'rect', x: x + w * 0.32, y: yy, w: w * 0.68, h: rh, stroke: LINE, lw: 0.25 });
      E.push({ t: 'text', s: r[0], x: x + 2, y: yy + rh * 0.66, size: 3, color: GREY, maxW: w * 0.32 - 4 });
      E.push({ t: 'text', s: v.v, x: x + w * 0.32 + 2, y: yy + rh * 0.68, size: 3.6, font: v.manque ? 'i' : 'b', color: v.manque ? WARN : INK, maxW: w * 0.68 - 4, fit: true, champ: r[0] });
    });
    return y + rows.length * rh;
  }
  var MENTION = 'Habillage documentaire : le contenu technique d’origine (calculs, dimensions, résultats, annotations, dessins) n’est pas modifié. Cette mise en page ne certifie ni l’exactitude des calculs, ni la conformité réglementaire, ni la qualité de conception ; la responsabilité technique demeure celle de l’ingénieur compétent.';
  function para(E, s, x, y, w, size, color, lines) { E.push({ t: 'para', s: s, x: x, y: y, w: w, size: size, color: color || GREY, lines: lines || 4, lead: size * 1.35 }); }

  function pageCouverture(o, titreDoc, nbDocs) {
    var E = [], ch = o.champs || {}, V = C.visas(o.workflow, o.statut);
    enTeteMarque(E, o, titreDoc || 'Document technique', (o.tplNom || '') + (nbDocs > 1 ? ' — ' + nbDocs + ' documents' : ''));
    tableauInfos(E, 14, 90, 182, [['Projet', ch.projet], ['Référence du projet', ch.reference], ['Client / maître d’ouvrage', ch.client], ['Localisation', ch.localisation], ['Discipline', ch.discipline], ['N° du document', ch.numero], ['Indice de révision', ch.indice], ['Date', ch.date], ['Statut', V.statut]], 10);
    para(E, MENTION, 14, 250, 182, 2.9, GREY, 5);
    return { kind: 'cover', W: A4.W, H: A4.H, els: E };
  }
  function pagesSommaire(o, entries) {
    var per = 24, n = Math.max(1, Math.ceil(entries.length / per)), out = [];
    for (var p = 0; p < n; p++) {
      var E = [], y = 72; enTeteMarque(E, o, p ? 'Sommaire (suite)' : 'Sommaire', '');
      E.push({ t: 'rect', x: 14, y: y, w: 182, h: 7.5, fill: NAVY });
      [['N°', 16, 'l'], ['Désignation', 28, 'l'], ['Type', 128, 'l'], ['Format', 156, 'l'], ['Pages', 194, 'r']].forEach(function (c) { E.push({ t: 'text', s: c[0], x: c[1], y: y + 5.2, size: 3.2, font: 'b', color: '#FFFFFF', align: c[2] }); });
      entries.slice(p * per, (p + 1) * per).forEach(function (e, i) {
        var yy = y + 7.5 + i * 8.2; if (i % 2) E.push({ t: 'rect', x: 14, y: yy, w: 182, h: 8.2, fill: '#F4F7FB' });
        var ind = e.niveau > 1 ? 5 : 0;
        E.push({ t: 'text', s: e.n || '', x: 16, y: yy + 5.5, size: 3.2, font: e.niveau > 1 ? '' : 'b', color: INK });
        E.push({ t: 'text', s: e.titre, x: 28 + ind, y: yy + 5.5, size: 3.3, font: e.niveau > 1 ? '' : 'b', color: INK, maxW: 96 - ind, fit: true });
        E.push({ t: 'text', s: e.type || '', x: 128, y: yy + 5.5, size: 3, color: GREY, maxW: 26 });
        E.push({ t: 'text', s: e.format || '', x: 156, y: yy + 5.5, size: 3, color: GREY, maxW: 30 });
        E.push({ t: 'text', s: e.pages, x: 194, y: yy + 5.5, size: 3.2, font: 'b', color: NAVY, align: 'r' });
      });
      out.push({ kind: 'toc', W: A4.W, H: A4.H, els: E });
    }
    return out;
  }
  function pageValidation(o, docs) {
    var E = [], ch = o.champs || {}, V = C.visas(o.workflow, o.statut);
    enTeteMarque(E, o, 'Page de validation', (ch.titre || '') + (ch.numero ? ' — ' + ch.numero : '') + (ch.indice ? ' ind. ' + ch.indice : ''));
    var y = tableauInfos(E, 14, 82, 182, [['Projet', ch.projet], ['Titre du document', ch.titre], ['N° / indice', (ch.numero || '') + (ch.indice ? ' / ' + ch.indice : '')], ['Statut', V.statut]], 9);
    y += 8;
    [['Établi (dessiné) par', V.dessine], ['Vérifié par', V.verifie], ['Approuvé par', V.approuve]].forEach(function (b, i) {
      var x = 14 + i * 61;
      E.push({ t: 'rect', x: x, y: y, w: 60, h: 40, stroke: LINE, lw: 0.3 });
      E.push({ t: 'rect', x: x, y: y, w: 60, h: 7, fill: '#EDF1F7' });
      E.push({ t: 'text', s: b[0], x: x + 2, y: y + 4.8, size: 3.2, font: 'b', color: NAVY, maxW: 56 });
      E.push({ t: 'text', s: b[1] ? b[1].nom : C.A_COMPLETER, x: x + 2, y: y + 14, size: 3.4, font: b[1] ? 'b' : 'i', color: b[1] ? INK : WARN, maxW: 56, fit: true });
      E.push({ t: 'text', s: b[1] && b[1].date ? b[1].date : '', x: x + 2, y: y + 19, size: 3, color: GREY, maxW: 56 });
      E.push({ t: 'text', s: 'Visa / signature', x: x + 2, y: y + 37, size: 2.6, font: 'i', color: GREY });
    });
    y += 48;
    E.push({ t: 'text', s: 'Documents d’origine conservés (empreintes SHA-256)', x: 14, y: y, size: 3.6, font: 'b', color: NAVY }); y += 3;
    docs.slice(0, 14).forEach(function (d, i) {
      var yy = y + i * 7; E.push({ t: 'rect', x: 14, y: yy, w: 182, h: 7, stroke: LINE, lw: 0.2 });
      E.push({ t: 'text', s: d.nom, x: 16, y: yy + 4.8, size: 2.9, color: INK, maxW: 92, fit: true });
      E.push({ t: 'text', s: (d.sha || '').slice(0, 32) + (d.sha ? '…' : ''), x: 194, y: yy + 4.8, size: 2.6, color: GREY, align: 'r', maxW: 84 });
    });
    para(E, MENTION, 14, 262, 182, 2.9, GREY, 5);
    para(E, 'Les mentions « établi / vérifié / approuvé » sont nominatives, issues du circuit de validation de l’Atelier ; elles ne constituent pas une signature électronique qualifiée.', 14, 281, 182, 2.7, GREY, 2);
    return { kind: 'valid', W: A4.W, H: A4.H, els: E };
  }
  function feuillePresentation(o, W, H, doc, pageInfos) {
    var E = [], ch = o.champs || {}, sz = cartSize(W, H, o.tpl, !!o.qr), m = (o.tpl && o.tpl.marge) || 10, r = placeRect((o.tpl && o.tpl.position) || 'br', W, H, sz, m);
    var f = clamp(Math.max(W, H) / 297, 1, 3);
    E.push({ t: 'rect', x: m, y: m, w: W - 2 * m, h: 16 * f, fill: NAVY });
    E.push({ t: 'text', s: 'FEUILLE DE PRÉSENTATION', x: m + 4 * f, y: m + 8 * f, size: 6 * f, font: 'b', color: '#FFFFFF', maxW: W - 2 * m - 8 * f });
    E.push({ t: 'text', s: doc.nom, x: m + 4 * f, y: m + 13.5 * f, size: 3.2 * f, font: 'i', color: '#F5CB45', maxW: W - 2 * m - 8 * f, fit: true });
    var yy = m + 22 * f, ln = Math.min(pageInfos.length, 30);
    E.push({ t: 'text', s: 'Pages du document d’origine (conservées intactes à la suite de cette feuille)', x: m, y: yy, size: 3.4 * f, font: 'b', color: NAVY, maxW: W - 2 * m });
    pageInfos.slice(0, ln).forEach(function (p, i) { E.push({ t: 'text', s: 'Page ' + p.n + ' — ' + p.format + ' ' + p.orient + (p.scan ? ' — scannée' : ''), x: m, y: yy + (i + 1.6) * 5.2 * f, size: 3 * f, color: INK, maxW: W - 2 * m - sz.w - 6 }); });
    if (pageInfos.length > ln) E.push({ t: 'text', s: '… et ' + (pageInfos.length - ln) + ' autre(s) page(s).', x: m, y: yy + (ln + 1.6) * 5.2 * f, size: 3 * f, font: 'i', color: GREY });
    var cw = cartouche(r.x, r.y, sz, { champs: ch, workflow: o.workflow, statut: o.statut, logo: o.logo, entreprise: o.entreprise, qr: o.qr, feuille: 1, feuilles: pageInfos.length + 1 });
    return { kind: 'sheet', W: W, H: H, els: E.concat(cw.els) };
  }

  /* ------------------------------------------------------------------ plan complet ------------------------------------------------------------------ */
  /* job = { modele, tpl, champs, statut, workflow, logo (booléen), entreprise,
   *         docs: [{ id, nom, sha, type, analyse:{pages:[…], signe, outline}, grilles:[grille|null], cartoucheExistant:'conserver|remplacer|ignorer' }],
   *         options: { mode:'auto|overlay|band|sheet', accepteRecouvrement, accepteSignature, couverture, sommaire, validation, pagination, filigrane } } */
  function plan(job) {
    var tpl = job.tpl || {}, op = Object.assign({ mode: 'auto' }, job.options || {}), W = [], pages = [], avert = [];
    function warn(niv, msg, extra) { avert.push(Object.assign({ niv: niv, msg: msg }, extra || {})); }
    var order = { note: 0, plan: 1, rapport: 2, annexe: 3 }, docs = (job.docs || []).slice();
    if (job.modele === 'dossier') docs = docs.map(function (d, i) { return { d: d, i: i }; }).sort(function (a, b) { return (order[a.d.type] - order[b.d.type]) || (a.i - b.i); }).map(function (x) { return x.d; });
    if (!docs.length) { warn('bloquant', 'Aucun document à mettre en page.'); return { pages: [], avertissements: avert, bloquants: avert.slice(), resume: {} }; }
    var wantCover = op.couverture != null ? op.couverture : tpl.couverture, wantToc = op.sommaire != null ? op.sommaire : tpl.sommaire, wantVal = op.validation != null ? op.validation : tpl.validation;
    var pag = op.pagination != null ? op.pagination : tpl.pagination, wm = op.filigrane != null ? op.filigrane : tpl.filigrane;
    var base = { champs: job.champs, workflow: job.workflow, statut: job.statut, logo: job.logo, entreprise: job.entreprise, qr: job.qr || null, tpl: Object.assign({}, tpl, { pagination: pag }), tplNom: tpl.nom };
    var qrDone = false;

    /* 1. sections : une par document, avec le nombre de pages de sortie qu'elle occupe */
    var sections = docs.map(function (d) {
      var an = d.analyse || { pages: [] }, nb = an.pages.length, useSheet = false, style = job.modele === 'plan' || (job.modele === 'dossier' && d.type === 'plan') ? 'plan' : 'texte';
      if (style === 'plan' && op.mode === 'sheet') useSheet = true;
      if (an.signe && !op.accepteSignature) warn('bloquant', '« ' + d.nom + ' » porte une signature numérique : toute modification l’invalide. L’original signé est conservé ; confirmez pour produire une nouvelle version sans cette validité.', { doc: d.id });
      if (an.signe && op.accepteSignature) warn('attention', '« ' + d.nom + ' » : signature numérique invalidée dans la nouvelle version (l’original signé reste archivé).', { doc: d.id });
      if (!nb) warn('bloquant', '« ' + d.nom + ' » : aucune page analysée.', { doc: d.id });
      var det = (an.pages || []).some(function (p) { return p.cartouche && p.cartouche.detecte; });
      if (style === 'plan' && det && !d.cartoucheExistant) warn('bloquant', '« ' + d.nom + ' » : un cartouche existant a été détecté — choisissez de le conserver, le remplacer ou l’ignorer.', { doc: d.id });
      var fm = {}; (an.pages || []).forEach(function (p) { fm[p.format] = 1; }); if (Object.keys(fm).length > 1) warn('info', '« ' + d.nom + ' » : formats mixtes (' + Object.keys(fm).join(', ') + ') — chaque page est traitée selon son propre format.', { doc: d.id });
      return { d: d, nb: nb, style: style, useSheet: useSheet };
    });
    var entries = [], tocPages = 0;
    sections.forEach(function (s, i) { entries.push({ s: s, niveau: 1 }); if (s.d.type === 'note' && s.d.analyse && s.d.analyse.outline) s.d.analyse.outline.slice(0, 40).forEach(function (o) { entries.push({ s: s, niveau: 2, o: o }); }); });
    if (wantToc) tocPages = Math.max(1, Math.ceil(entries.length / 24));
    var pre = (wantCover ? 1 : 0) + tocPages, cur = pre + 1, total = 0;
    sections.forEach(function (s) { s.out1 = cur; cur += s.nb + (s.useSheet ? 1 : 0); s.out2 = cur - 1; });
    total = cur - 1 + (wantVal ? 1 : 0);

    /* 2. pages générées avant */
    var titre = (job.champs && job.champs.titre) || (docs.length === 1 ? docs[0].nom.replace(/\.pdf$/i, '') : 'Dossier technique');
    if (wantCover) pages.push(Object.assign(pageCouverture(base, titre, docs.length), { numero: pages.length + 1 }));
    if (wantToc) {
      var tocE = entries.map(function (e, i) {
        var s = e.s, first = e.niveau === 1;
        return first ? { n: String(sections.indexOf(s) + 1), titre: s.d.nom.replace(/\.pdf$/i, ''), type: C.TYPES[s.d.type] || '', format: C.formatResume(s.d.analyse || { pages: [] }), pages: s.out1 === s.out2 ? String(s.out1) : s.out1 + '–' + s.out2, niveau: 1 }
          : { n: '', titre: e.o.titre, type: '', format: '', pages: String(Math.min(s.out2, s.out1 + (s.useSheet ? 1 : 0) + Math.max(0, (e.o.page || 1) - 1))), niveau: 2 };
      });
      pagesSommaire(base, tocE).forEach(function (p) { pages.push(Object.assign(p, { numero: pages.length + 1 })); });
    }

    /* 3. pages des documents */
    sections.forEach(function (s, si) {
      var d = s.d, an = d.analyse || { pages: [] }, nbp = an.pages.length;
      if (s.useSheet) {
        var p0 = an.pages[0] || { wmm: A4.W, hmm: A4.H }, infos = an.pages.map(function (p, i) { return { n: i + 1, format: p.format, orient: p.orient, scan: p.scan }; });
        pages.push(Object.assign(feuillePresentation(base, p0.wmm, p0.hmm, d, infos), { numero: pages.length + 1, doc: si }));
      }
      an.pages.forEach(function (pg, j) {
        var Wp = pg.wmm, Hp = pg.hmm, grid = d.grilles && d.grilles[j], out = { kind: 'orig', doc: si, page: j, W: Wp, H: Hp, band: null, els: [], numero: pages.length + 1, mode: 'intact', format: pg.format };
        var pnum = pages.length + 1, label = '« ' + d.nom + ' » p.' + (j + 1);
        if (pg.scan) warn('info', label + ' : page scannée — le cartouche est ajouté en couche vectorielle ; le contenu scanné reste inchangé.', { doc: d.id, page: pnum });
        if (s.style === 'plan' && !s.useSheet) {
          var dec = d.cartoucheExistant, hasOld = pg.cartouche && pg.cartouche.detecte;
          if (hasOld && dec === 'conserver') { out.mode = 'conserve'; warn('info', label + ' : cartouche existant conservé — aucun cartouche ajouté.', { doc: d.id, page: pnum }); }
          else {
            var sz = cartSize(Wp, Hp, tpl, !!job.qr), m = tpl.marge || 10, rect = placeRect(tpl.position || 'br', Wp, Hp, sz, m), tooSmall = sz.w > Wp - 2 * m + 0.1 || sz.h > (Hp - 2 * m) * 0.55;
            var ink = grid ? rectInk(grid, Wp, Hp, rect) : null, fits = !tooSmall && libre(ink), md = op.mode === 'auto' ? ((fits || (hasOld && dec === 'remplacer')) && !tooSmall ? 'overlay' : 'band') : op.mode;
            if (tooSmall && md === 'overlay') { md = 'band'; warn('attention', label + ' : page trop petite pour le cartouche — bande ajoutée sous la page.', { doc: d.id, page: pnum }); }
            if (!grid && op.mode === 'auto') warn('info', label + ' : zone non mesurée — bande ajoutée par prudence (page d’origine intacte).', { doc: d.id, page: pnum });
            var feuille = j + 1, feuilles = nbp, cov = null;
            if (md === 'overlay') {
              var rr = rect;
              if (hasOld && dec === 'remplacer') {
                var ob = pg.cartouche.bbox || [rect.x, rect.y, rect.x + rect.w, rect.y + rect.h], ux0 = Math.min(rect.x, ob[0]), uy0 = Math.min(rect.y, ob[1]), ux1 = Math.max(rect.x + rect.w, ob[2]), uy1 = Math.max(rect.y + rect.h, ob[3]);
                cov = { x: ux0, y: uy0, w: ux1 - ux0, h: uy1 - uy0 }; rr = { x: Math.min(Wp - m - sz.w, Math.max(m, ux1 - sz.w)), y: Math.min(Hp - m - sz.h, Math.max(m, uy1 - sz.h)), w: sz.w, h: sz.h };
                var ink2 = grid ? rectInk(grid, Wp, Hp, cov) : null; out.recouvre = true;
                warn('attention', label + ' : l’ancien cartouche est recouvert par le nouveau (' + Math.round((ink2 ? ink2.mean : 0) * 100) + ' % d’encre sous la zone). L’original reste intact dans l’archive.', { doc: d.id, page: pnum });
              } else if (!fits) {
                out.recouvre = true;
                warn(op.accepteRecouvrement ? 'attention' : 'bloquant', label + ' : le cartouche recouvrirait du contenu (' + Math.round((ink ? ink.mean : 1) * 100) + ' % d’encre dans la zone)' + (op.accepteRecouvrement ? ' — accepté par l’utilisateur.' : ' — choisissez la bande ajoutée, la feuille de présentation ou confirmez.'), { doc: d.id, page: pnum });
              }
              if (cov) out.els.push({ t: 'rect', x: cov.x, y: cov.y, w: cov.w, h: cov.h, fill: '#FFFFFF' });
              out.els = out.els.concat(cartouche(rr.x, rr.y, sz, Object.assign({}, base, { feuille: feuille, feuilles: feuilles })).els); out.mode = 'overlay'; out.zone = cov || rr;
            } else if (md === 'band') {
              var pad = 3, bh = round1(sz.h + 2 * pad), pos = tpl.position || 'br', bx = /l$/.test(pos) ? m : Wp - m - sz.w;
              out.band = { h: bh }; out.H = round1(Hp + bh); out.mode = 'band';
              out.els.push({ t: 'rect', x: 0, y: Hp, w: Wp, h: bh, fill: '#FFFFFF' }, { t: 'line', x1: 0, y1: Hp + 0.25, x2: Wp, y2: Hp + 0.25, lw: 0.35, color: NAVY });
              out.els = out.els.concat(cartouche(bx, Hp + pad, sz, Object.assign({}, base, { feuille: feuille, feuilles: feuilles })).els);
              out.zone = { x: 0, y: Hp, w: Wp, h: bh };
            } else out.mode = 'intact';
            if (md !== 'sheet' && Wp < 100) warn('attention', label + ' : très petit format.', { doc: d.id, page: pnum });
          }
        } else if (s.style === 'texte') {
          var f = clamp(Math.max(Wp, Hp) / 297, 1, 2.2), m2 = tpl.marge || 8, hz = { x: m2, y: 1.5, w: Wp - 2 * m2, h: 9 * f }, fz = { x: m2, y: Hp - 10 * f, w: Wp - 2 * m2, h: 9 * f };
          var hi = grid ? rectInk(grid, Wp, Hp, hz) : null, fi = grid ? rectInk(grid, Wp, Hp, fz) : null, okZ = libre(hi) && libre(fi);
          var go = { champs: job.champs, tpl: base.tpl, entreprise: job.entreprise, num: pnum, total: total, qr: job.qr || null }, needQr = !!job.qr && !qrDone && !wantCover && !wantVal;
          if (okZ && !needQr) { out.els = enteteEtPied(Wp, Hp, f, m2, go, 1.5 + 6 * f, Hp - 3.2 * f); out.mode = 'overlay'; out.zone = { x: 0, y: 0, w: Wp, h: Hp }; }
          else {
            var bh2 = round1(13 * f + (needQr ? 28 : 0)); out.band = { h: bh2 }; out.H = round1(Hp + bh2); out.mode = 'band';
            out.els.push({ t: 'rect', x: 0, y: Hp, w: Wp, h: bh2, fill: '#FFFFFF' });
            out.els = out.els.concat(enteteEtPied(Wp, out.H, f, m2, go, Hp + 4.5 * f, out.H - 2.2 * f).filter(function (e) { return true; })); out.zone = { x: 0, y: Hp, w: Wp, h: bh2 };
            if (needQr) {   /* V214 : ni couverture ni page de validation : le QR de vérification est placé dans la bande de la première page */
              qrDone = true; var qy = Hp + 6.8 * f;
              out.els.push({ t: 'qr', x: m2, y: qy, s: 24 }, { t: 'text', s: 'VÉRIFICATION DU DOCUMENT', x: m2 + 28, y: qy + 8, size: 3.2, font: 'b', color: NAVY, maxW: Wp - 2 * m2 - 30 }, { t: 'text', s: 'Scannez le QR code : authenticité et version en vigueur.', x: m2 + 28, y: qy + 13, size: 2.8, color: GREY, maxW: Wp - 2 * m2 - 30 }, { t: 'text', s: 'Code : ' + job.qr.code, x: m2 + 28, y: qy + 18, size: 3.2, font: 'b', color: INK, maxW: Wp - 2 * m2 - 30 });
            }
            warn('info', label + (okZ ? ' : bande ajoutée sous la première page pour le QR de vérification (rien n’est recouvert).' : ' : le contenu occupe les marges — en-tête et pied de page placés dans une bande ajoutée sous la page (rien n’est recouvert).'), { doc: d.id, page: pnum });
          }
          if (wm) out.els.push({ t: 'wm', s: (C.visas(job.workflow, job.statut).statut === 'Émis' ? '' : C.visas(job.workflow, job.statut).statut.toUpperCase()), cx: Wp / 2, cy: Hp / 2, size: Math.min(Wp, Hp) * 0.11, alpha: 0.07 });
        }
        pages.push(out);
      });
    });
    if (wantVal) pages.push(Object.assign(pageValidation(base, docs.map(function (d) { return { nom: d.nom, sha: d.sha }; })), { numero: pages.length + 1 }));
    pages.forEach(function (p) { if (p.kind === 'orig' && p.els) p.els = p.els.filter(function (e) { return !(e.t === 'wm' && !e.s); }); });
    return { pages: pages, docs: docs, avertissements: avert, bloquants: avert.filter(function (a) { return a.niv === 'bloquant'; }), resume: { total: pages.length, sections: sections.length, entreesSommaire: entries.length } };
  }

  NS.layout = { FORMATS: FORMATS, A4: A4, LIBRE_MEAN: LIBRE_MEAN, LIBRE_MAX: LIBRE_MAX, detectFormat: detectFormat, rectInk: rectInk, libre: libre, cartSize: cartSize, placeRect: placeRect, cartouche: cartouche, plan: plan, MENTION: MENTION, COUL: { NAVY: NAVY, GOLD: GOLD, GREY: GREY, STCOL: STCOL } };
  if (typeof module !== 'undefined' && module.exports) module.exports = NS.layout;
})(typeof window !== 'undefined' ? window : globalThis);
