/* Excellencia Building — BUREAU D'ÉLECTRICITÉ V212 (cahier des charges V1.0, §5.8)
 * Fonctions du cahier : bilan de puissance, tableaux, câbles, protections, notes de calcul / quantitatifs.
 *   1. RÉFÉRENTIEL : norme et édition choisies explicitement par le dossier ; tensions, chute de tension maximale, résistivité, Ks et réserve SAISIS.
 *      Table des courants admissibles Iz : valeurs INDICATIVES préremplies (cuivre, PVC, mode de pose C) à CONFIRMER par un responsable nommé
 *      avant tout visa — modifier la table annule la confirmation. Le logiciel n'impose aucune norme à la place du projet.
 *   2. CIRCUITS : courant d'emploi Ib, calibre proposé (série normalisée), section proposée (Iz ≥ In et chute de tension ≤ limite), puis
 *      VÉRIFICATION des valeurs imposées : Ib ≤ In ≤ Iz, chute de tension, pouvoir de coupure ≥ Icc (si saisis).
 *   3. BILAN : puissance installée, utilisée (Ku), appelée par tableau (Ks), totale, cos φ moyen, apparente, courant triphasé, quantitatif de câbles.
 * Hors périmètre de cette étape (signalé, jamais simulé) : courts-circuits calculés, sélectivité, coefficients de groupement/température,
 * schémas unifilaires dessinés. Garde-fou : moteurs déterministes, aucune IA ; visa nominatif (vérificateur ≠ auteur).
 * Données : clé exb_elec. Pour retirer : supprimer la balise <script src="exb-elec.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBElec) return;
  var K = 'exb_elec', SERIE = [6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600];
  var IZ0 = '1,5;19,5;17,5\n2,5;27;24\n4;36;32\n6;46;41\n10;63;57\n16;85;76\n25;112;96\n35;138;119\n50;168;144\n70;213;184\n95;258;223\n120;299;259\n150;344;299\n185;392;341\n240;461;403\n300;530;464';

  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function rd(k) { try { var S = store(), v = JSON.parse((S ? S.getItem(k) : w.localStorage.getItem(k)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, a) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(a)); else w.localStorage.setItem(k, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
  function num(v, def) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : (def === undefined ? NaN : def); }
  function fx(v, n) { return isFinite(v) ? Number(v).toLocaleString('fr-FR', { minimumFractionDigits: n, maximumFractionDigits: n }) : '—'; }
  function audit(a, o, det) { try { if (w.EXBCore && w.EXBCore.audit) w.EXBCore.audit.log(a, o, det); } catch (e) {} }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 5000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function ask(m, v) { return typeof w.exbPrompt === 'function' ? w.exbPrompt(m, v || '') : Promise.resolve(w.prompt(m, v || '')); }
  function who() { return ask('Votre nom (signature nominative, non qualifiée) :', '').then(function (v) { return String(v || '').trim(); }); }
  function projets() { var s = {}, o = []; rd('exb_projects').concat(rd('exb_v93_projects')).forEach(function (p) { if (p && p.id != null && !s[p.id]) { s[p.id] = 1; o.push({ id: String(p.id), nom: String(p.name || p.nom || p.title || p.titre || p.id) }); } }); return o; }
  function pnom(id) { var p = projets().filter(function (x) { return x.id === String(id); })[0]; return p ? p.nom : (id || '—'); }
  function san(t) { return String(t == null ? '' : t).replace(/≥/g, '>=').replace(/≤/g, '<=').replace(/−/g, '-').replace(/→/g, '->').replace(/²/g, '2').replace(/³/g, '3').replace(/×/g, 'x').replace(/√/g, 'rac ').replace(/·/g, '.').replace(/φ/g, 'phi ').replace(/Δ/g, 'delta '); }
  function csv(rows, name) { var t = '\ufeff' + rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); try { var b = new Blob([t], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = (w.URL || w.webkitURL).createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); } catch (e) { toast('Export impossible : ' + e.message, 'error'); } }
  function pdf(o) { if (!w.EXBPdf) return toast('Module PDF indisponible.', 'error'); try { return w.EXBPdf.make(o); } catch (e) { toast('PDF impossible : ' + e.message, 'error'); } }

  /* ========================================================== MOTEURS ========================================================== */
  function lignes(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) { return l && l.charAt(0) !== '#'; }); }
  function parseIz(t) { var m = [], err = []; lignes(t).forEach(function (l, i) { var f = l.split(/[;\t]/).map(num); if (!(f[0] > 0) || !(f[1] > 0) || !(f[2] > 0)) err.push('Table Iz ligne ' + (i + 1) + ' illisible.'); else m.push({ s: f[0], i2: f[1], i3: f[2] }); }); m.sort(function (a, b) { return a.s - b.s; }); return { rows: m, erreurs: err }; }
  /* Circuits : tableau ; nom ; mono|tri ; P kW ; cos φ ; Ku ; L m ; section mm² (facultatif) ; calibre A (facultatif) ; Icc kA (fac.) ; PdC kA (fac.) */
  function parseCircuits(t) {
    var C = [], err = [];
    lignes(t).forEach(function (l, i) {
      var f = l.split(/[;\t]/).map(function (x) { return x.trim(); }), ty = String(f[2] || '').toLowerCase(), c = { tab: f[0] || 'TGBT', nom: f[1] || '', type: ty, P: num(f[3]), cos: num(f[4]), Ku: f[5] === '' || f[5] === undefined ? 1 : num(f[5]), L: num(f[6]), s: f[7] ? num(f[7]) : null, In: f[8] ? num(f[8]) : null, Icc: f[9] ? num(f[9]) : null, pdc: f[10] ? num(f[10]) : null, ligne: i + 1 };
      var m = !c.nom ? 'nom manquant' : (ty !== 'mono' && ty !== 'tri') ? 'type : « mono » ou « tri »' : !(c.P > 0) ? 'puissance P (kW) invalide' : !(c.cos > 0 && c.cos <= 1) ? 'cos φ entre 0 et 1' : !(c.Ku > 0 && c.Ku <= 1) ? 'Ku entre 0 et 1' : !(c.L > 0) ? 'longueur L (m) invalide' : (c.s !== null && !(c.s > 0)) ? 'section invalide' : (c.In !== null && !(c.In > 0)) ? 'calibre invalide' : '';
      if (m) err.push({ ligne: i + 1, msg: m }); else C.push(c);
    });
    return { circuits: C, erreurs: err };
  }
  function ib(c, p) { var Pe = c.P * c.Ku * 1000; return c.type === 'tri' ? Pe / (Math.sqrt(3) * p.u3 * c.cos) : Pe / (p.u1 * c.cos); }
  function dU(c, S, I, p) { var b = c.type === 'tri' ? 1 : 2, sn = Math.sqrt(Math.max(0, 1 - c.cos * c.cos)), v = b * (p.rho * c.L / S * c.cos + p.lambda * c.L * sn) * I; return { volts: v, pct: v / p.u1 * 100 }; }
  function calibre(I) { for (var i = 0; i < SERIE.length; i++) if (SERIE[i] >= I - 1e-9) return SERIE[i]; return null; }
  function izDe(rows, s, type) { var r = rows.filter(function (x) { return Math.abs(x.s - s) < 1e-9; })[0]; return r ? (type === 'tri' ? r.i3 : r.i2) : null; }
  function sectionMin(c, In, p, rows) { for (var i = 0; i < rows.length; i++) { var iz = izDe(rows, rows[i].s, c.type); if (iz >= In - 1e-9 && dU(c, rows[i].s, ib(c, p), p).pct <= p.dUmax + 1e-9) return rows[i].s; } return null; }
  function circuit(c, p, rows) {
    var I = ib(c, p), o = { ib: I, msgs: [], ok: true, propose: {} }, In = c.In;
    if (In == null) { In = calibre(I); o.propose.In = In; }
    if (In === null) { o.ok = false; o.msgs.push('Aucun calibre normalisé ≥ Ib (' + fx(I, 1) + ' A) dans la série prévue : étudier un départ dédié.'); }
    o.In = In; var S = c.s;
    if (S == null && In !== null) { S = sectionMin(c, In, p, rows); o.propose.s = S; if (S === null) { o.ok = false; o.msgs.push('Aucune section de la table ne respecte Iz ≥ ' + In + ' A et la chute de tension maximale.'); } }
    o.s = S;
    if (In !== null && S !== null) {
      o.iz = izDe(rows, S, c.type); o.dU = dU(c, S, I, p);
      if (o.iz === null) { o.ok = false; o.msgs.push('Section ' + fx(S, 1) + ' mm² absente de la table Iz.'); }
      else { if (In > o.iz + 1e-9) { o.ok = false; o.msgs.push('Calibre ' + In + ' A > Iz ' + fx(o.iz, 1) + ' A : le câble n’est pas protégé.'); } }
      if (I > In + 1e-9) { o.ok = false; o.msgs.push('Ib ' + fx(I, 1) + ' A > calibre ' + In + ' A.'); }
      if (o.dU.pct > p.dUmax + 1e-9) { o.ok = false; o.msgs.push('Chute de tension ' + fx(o.dU.pct, 2) + ' % > ' + fx(p.dUmax, 2) + ' %.'); }
    }
    if (c.Icc != null && c.pdc != null && c.pdc < c.Icc - 1e-9) { o.ok = false; o.msgs.push('Pouvoir de coupure ' + fx(c.pdc, 1) + ' kA < Icc ' + fx(c.Icc, 1) + ' kA.'); }
    return o;
  }
  /* Bilan : Ks par tableau (texte « tableau ; Ks »), Ks global et réserve (%). */
  function parseKs(t) { var m = {}, err = []; lignes(t).forEach(function (l, i) { var f = l.split(/[;\t]/), k = num(f[1]); if (!f[0].trim() || !(k > 0 && k <= 1)) err.push('Ks ligne ' + (i + 1) + ' : « tableau ; Ks entre 0 et 1 ».'); else m[f[0].trim()] = k; }); return { ks: m, erreurs: err }; }
  function bilan(C, ksTab, ksG, res, p) {
    var T = {}, ordre = [];
    C.forEach(function (c) { var t = T[c.tab] = T[c.tab] || (ordre.push(c.tab), { nom: c.tab, Pn: 0, Pu: 0, Q: 0, n: 0 }); t.Pn += c.P; t.Pu += c.P * c.Ku; t.Q += c.P * c.Ku * Math.tan(Math.acos(c.cos)); t.n++; });
    var rows = ordre.map(function (n) { var t = T[n], k = ksTab[n] === undefined ? 1 : ksTab[n]; return { nom: n, n: t.n, Pn: t.Pn, Pu: t.Pu, ks: k, Pc: t.Pu * k, Qc: t.Q * k }; });
    var P = 0, Q = 0, Pn = 0; rows.forEach(function (r) { P += r.Pc; Q += r.Qc; Pn += r.Pn; });
    var kg = isFinite(ksG) ? ksG : 1, rz = 1 + (isFinite(res) ? res : 0) / 100; P *= kg * rz; Q *= kg * rz;
    var S = Math.sqrt(P * P + Q * Q);
    return { rows: rows, Pn: Pn, P: P, Q: Q, S: S, cos: S > 0 ? P / S : null, I3: S * 1000 / (Math.sqrt(3) * p.u3), ksG: kg, reserve: isFinite(res) ? res : 0 };
  }
  function quantCables(C, R) { var q = {}; C.forEach(function (c, i) { var s = R[i].s; if (s === null || s === undefined) return; var k = (c.type === 'tri' ? '5G' : '3G') + fx(s, 1).replace(',0', ''); q[k] = (q[k] || 0) + c.L; }); return Object.keys(q).sort().map(function (k) { return { cable: k, metres: q[k] }; }); }

  /* ========================================================== DOSSIER ========================================================== */
  function all() { return rd(K); }
  function find(id) { return all().filter(function (x) { return x.id === id; })[0]; }
  function saveDos(x) { var a = all(), i = a.findIndex(function (y) { return y.id === x.id; }); if (i < 0) a.push(x); else a[i] = x; return wr(K, a); }
  function nouveau() { var n = all().length + 1, y = new Date().getFullYear(); return { id: uid('ELEC'), no: 'ELEC-' + y + '-' + String(n).padStart(3, '0'), statut: 'Brouillon', titre: '', project_id: '', site: '', date: new Date().toISOString().slice(0, 10), auteur: '', norme: { nom: '', edition: '' }, par: { u1: '230', u3: '400', dUmax: '', rho: '0,0225', lambda: '0,00008', ksG: '', reserve: '' }, izTxt: IZ0, izConf: null, ksTxt: '', circTxt: '', histo: [], cree: Date.now() }; }
  function params(x) { var q = x.par; return { u1: num(q.u1, 230), u3: num(q.u3, 400), dUmax: num(q.dUmax), rho: num(q.rho, 0.0225), lambda: num(q.lambda, 0.00008) }; }
  function calc(x) { var p = params(x), iz = parseIz(x.izTxt), pc = parseCircuits(x.circTxt), R = pc.circuits.map(function (c) { return isFinite(p.dUmax) ? circuit(c, p, iz.rows) : { ib: ib(c, p), ok: false, msgs: ['Chute de tension maximale non fixée.'], propose: {} }; }), ks = parseKs(x.ksTxt); return { p: p, iz: iz, pc: pc, R: R, ks: ks, B: bilan(pc.circuits, ks.ks, num(x.par.ksG), num(x.par.reserve), p) }; }
  function verif(x) {
    var a = [], add = function (n, id, m) { a.push({ niveau: n, id: id, msg: m }); }, k = calc(x);
    if (!k.pc.circuits.length) add('bloquant', 'ELEC-1', 'Aucun circuit valide : un dossier sans circuit ne peut pas être vérifié.');
    if (!String(x.norme.nom || '').trim() || !String(x.norme.edition || '').trim()) add('bloquant', 'ELEC-2', 'Norme et édition non déclarées pour ce dossier.');
    if (!isFinite(k.p.dUmax) || !(k.p.dUmax > 0)) add('bloquant', 'ELEC-3', 'Chute de tension maximale (%) non fixée : à définir selon la norme choisie.');
    if (!x.izConf) add('bloquant', 'ELEC-4', 'Table des courants admissibles non confirmée par un responsable nommé (valeurs préremplies indicatives).');
    if (!String(x.auteur || '').trim()) add('bloquant', 'ELEC-5', 'Auteur de la note de calcul non renseigné.');
    k.iz.erreurs.concat(k.ks.erreurs).forEach(function (m) { add('alerte', 'ELEC-6', m); });
    k.pc.erreurs.forEach(function (e) { add('alerte', 'ELEC-6', 'Circuits ligne ' + e.ligne + ' : ' + e.msg); });
    k.R.forEach(function (r, i) { var c = k.pc.circuits[i]; r.msgs.forEach(function (m) { add('bloquant', 'ELEC-7', c.tab + ' / ' + c.nom + ' : ' + m); }); if (r.propose && (r.propose.In || r.propose.s)) add('alerte', 'ELEC-8', c.tab + ' / ' + c.nom + ' : calibre ou section PROPOSÉS par le calcul, non imposés — à valider.'); });
    if (!isFinite(num(x.par.ksG))) add('alerte', 'ELEC-9', 'Facteur de simultanéité global non fixé : 1 retenu.');
    return a;
  }
  function bloque(x) { return verif(x).filter(function (v) { return v.niveau === 'bloquant'; }); }

  /* ========================================================== INTERFACE ========================================================== */
  var TAB = 'ref', GID = null;
  function box() { return d.getElementById('exbElecBox'); }
  function ro(x) { return x.statut !== 'Brouillon'; }
  function btn(l, a, i, c) { return '<button data-a="' + a + '"' + (i != null ? ' data-i="' + esc(i) + '"' : '') + ' style="padding:8px 12px;border:0;border-radius:8px;background:' + (c || '#0f766e') + ';color:#fff;margin:2px 4px 2px 0">' + l + '</button>'; }
  function lab(t, h) { return '<label style="display:block;font-size:12.5px;color:#334155">' + t + h + '</label>'; }
  function inp(f, v, dis) { return '<input data-f="' + f + '" value="' + esc(v) + '"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px;box-sizing:border-box">'; }
  function ta(f, v, dis, rows, ph) { return '<textarea data-f="' + f + '" rows="' + (rows || 6) + '"' + (dis ? ' disabled' : '') + ' placeholder="' + esc(ph || '') + '" style="width:100%;box-sizing:border-box;padding:6px;font:12.5px monospace">' + esc(v) + '</textarea>'; }
  function table(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;font-size:12.5px;min-width:100%"><tr>' + h.map(function (c) { return '<th style="text-align:left;border-bottom:1px solid #cbd5e1;padding:4px 8px">' + c + '</th>'; }).join('') + '</tr>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td style="border-bottom:1px solid #e2e8f0;padding:4px 8px">' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</table></div>'; }
  function alertesHtml(A) { return A.length ? '<ul style="margin:6px 0;padding-left:18px;font-size:12.5px">' + A.map(function (a) { return '<li style="color:' + (a.niveau === 'bloquant' ? '#b91c1c' : '#b45309') + '">' + esc(a.id) + ' — ' + esc(a.msg) + '</li>'; }).join('') + '</ul>' : '<p style="color:#15803d;font-size:12.5px">Aucune alerte.</p>'; }
  function grid(h) { return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">' + h + '</div>'; }
  function liste0() { var a = all(); return '<h3 style="margin:6px 0">⚡ Électricité</h3><p style="font-size:12.5px;color:#475569">Bilan de puissance, circuits, câbles et protections. Calculs déterministes : ils ne remplacent pas la note de calcul d’un ingénieur électricien.</p>' + btn('➕ Nouveau dossier électrique', 'new') + (a.length ? table(['N°', 'Titre', 'Projet', 'Statut', ''], a.map(function (r) { return [esc(r.no), esc(r.titre || '—'), esc(pnom(r.project_id)), esc(r.statut), btn('Ouvrir', 'open', r.id)]; })) : '<p>Aucun dossier.</p>'); }
  function tabRef(x, dis) {
    var q = x.par, k = parseIz(x.izTxt), h = grid(lab('Norme (nom)', inp('norme.nom', x.norme.nom, dis)) + lab('Édition / année', inp('norme.edition', x.norme.edition, dis)) + lab('Tension monophasée (V)', inp('par.u1', q.u1, dis)) + lab('Tension triphasée (V)', inp('par.u3', q.u3, dis)) + lab('Chute de tension max (%) — selon la norme', inp('par.dUmax', q.dUmax, dis)) + lab('Résistivité cuivre (Ω·mm²/m)', inp('par.rho', q.rho, dis)) + lab('Réactance linéique (Ω/m)', inp('par.lambda', q.lambda, dis)) + lab('Ks global (0 à 1)', inp('par.ksG', q.ksG, dis)) + lab('Réserve d’extension (%)', inp('par.reserve', q.reserve, dis)));
    h += '<h4 style="margin:10px 0 4px">Courants admissibles Iz (cuivre) — section ; Iz 2 conducteurs chargés ; Iz 3 conducteurs chargés</h4><p style="font-size:12px;color:#b45309">Valeurs préremplies INDICATIVES (cuivre, PVC, mode de pose C). Comparez-les à la table de votre norme et corrigez : le mode de pose, la température et le groupement de votre chantier peuvent les changer.</p>' + ta('izTxt', x.izTxt, dis, 8);
    h += '<p style="font-size:12.5px">' + (x.izConf ? '<span style="color:#15803d">Table confirmée par ' + esc(x.izConf.par) + ' le ' + esc(new Date(x.izConf.t).toLocaleDateString('fr-FR')) + '</span>' : '<span style="color:#b91c1c">Table non confirmée</span>') + ' — ' + k.rows.length + ' section(s).</p>' + (!dis && !x.izConf ? btn('Confirmer cette table', 'confiz', null, '#7c3aed') : '');
    return h;
  }
  function tabCirc(x, dis) {
    var k = calc(x), h = lab('Circuits (un par ligne : tableau ; nom ; mono|tri ; P kW ; cos φ ; Ku ; L m ; [section mm²] ; [calibre A] ; [Icc kA] ; [PdC kA])', ta('circTxt', x.circTxt, dis, 7, 'TGBT;Éclairage RDC;mono;2,4;0,95;0,8;35\nTGBT;Climatiseur;tri;7,5;0,85;1;48;;32'));
    h += lab('Facteur de simultanéité par tableau (une ligne : tableau ; Ks)', ta('ksTxt', x.ksTxt, dis, 2, 'TGBT;0,8'));
    if (k.pc.erreurs.length) h += '<ul style="font-size:12.5px;color:#b45309;padding-left:18px">' + k.pc.erreurs.map(function (e) { return '<li>Ligne ' + e.ligne + ' : ' + esc(e.msg) + '</li>'; }).join('') + '</ul>';
    if (k.pc.circuits.length) h += table(['Tableau', 'Circuit', 'Ib (A)', 'Calibre', 'Section (mm²)', 'Iz (A)', 'ΔU (%)', 'Contrôle'], k.pc.circuits.map(function (c, i) { var r = k.R[i], pI = r.propose && r.propose.In, pS = r.propose && r.propose.s; return [esc(c.tab), esc(c.nom), fx(r.ib, 1), r.In === null || r.In === undefined ? '—' : r.In + (pI ? ' <i>(proposé)</i>' : ''), r.s == null ? '—' : fx(r.s, 1) + (pS ? ' <i>(proposée)</i>' : ''), r.iz == null ? '—' : fx(r.iz, 1), r.dU ? fx(r.dU.pct, 2) : '—', r.ok ? '<b style="color:#15803d">OK</b>' : '<b style="color:#b91c1c">' + esc(r.msgs.join(' ')) + '</b>']; }));
    return h;
  }
  function tabBil(x) {
    var k = calc(x), B = k.B; if (!k.pc.circuits.length) return '<p>Saisissez d’abord des circuits.</p>';
    var h = table(['Tableau', 'Circuits', 'P installée (kW)', 'P utilisée (kW)', 'Ks', 'P appelée (kW)'], B.rows.map(function (r) { return [esc(r.nom), r.n, fx(r.Pn, 2), fx(r.Pu, 2), fx(r.ks, 2), '<b>' + fx(r.Pc, 2) + '</b>']; }));
    h += '<p style="margin-top:8px">Puissance installée : ' + fx(B.Pn, 2) + ' kW — Ks global ' + fx(B.ksG, 2) + ', réserve ' + fx(B.reserve, 0) + ' %.<br><b>Puissance appelée : ' + fx(B.P, 2) + ' kW</b> — apparente : <b>' + fx(B.S, 2) + ' kVA</b> — cos φ moyen : ' + fx(B.cos, 3) + ' — courant triphasé équivalent : <b>' + fx(B.I3, 1) + ' A</b>.</p>';
    var q = quantCables(k.pc.circuits, k.R); if (q.length) h += '<h4 style="margin:10px 0 4px">Quantitatif de câbles (hors chutes et raccordements)</h4>' + table(['Câble (conducteurs × section mm²)', 'Longueur (m)'], q.map(function (r) { return [esc(r.cable), fx(r.metres, 1)]; }));
    return h + '<p style="font-size:12px;color:#475569">Bilan par somme des puissances utilisées avec les facteurs saisis ; courant équivalent supposé équilibré.</p>';
  }
  function tabRap(x) {
    var A = verif(x), h = '<h4 style="margin:6px 0">Contrôles</h4>' + alertesHtml(A) + '<h4 style="margin:10px 0 4px">Visa</h4><p style="font-size:12.5px">Statut : <b>' + esc(x.statut) + '</b>' + (x.verifie ? ' — vérifié par ' + esc(x.verifie.par) : '') + (x.vise ? ' — visé par ' + esc(x.vise.par) : '') + '</p>';
    if (x.statut === 'Brouillon') h += btn('Marquer comme vérifié', 'verifier', null, '#7c3aed'); if (x.statut === 'Vérifié') h += btn('Viser le dossier', 'viser', null, '#7c3aed'); if (x.statut !== 'Brouillon') h += btn('Rouvrir (motif obligatoire)', 'rouvrir', null, '#475569');
    h += '<div style="margin-top:8px">' + btn('📄 Note de calcul PDF', 'pdf', null, '#0369a1') + btn('⬇️ Circuits CSV', 'csvc', null, '#475569') + '</div>';
    if (x.histo.length) h += '<h4 style="margin:10px 0 4px">Historique</h4><ul style="font-size:12px;padding-left:18px">' + x.histo.map(function (e) { return '<li>' + esc(new Date(e.t).toLocaleString('fr-FR')) + ' — ' + esc(e.msg) + '</li>'; }).join('') + '</ul>';
    return h;
  }
  function paint() {
    var b = box(); if (!b) return; var x = GID ? find(GID) : null;
    if (!x) { b.innerHTML = '<div style="display:flex"><button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' + liste0(); return; }
    var dis = ro(x), tabs = [['ref', '📚 Référentiel'], ['circ', '🔌 Circuits'], ['bil', '📊 Bilan'], ['rap', '✅ Rapport']];
    b.innerHTML = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px"><button data-a="back" style="padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">← Dossiers</button>' + tabs.map(function (t) { return '<button data-a="tab" data-i="' + t[0] + '" style="padding:8px 12px;border:0;border-radius:999px;background:' + (TAB === t[0] ? '#0f766e' : '#e2e8f0') + ';color:' + (TAB === t[0] ? '#fff' : '#0f172a') + '">' + t[1] + '</button>'; }).join('') + '<button data-a="close" style="margin-left:auto;padding:8px 12px;border:0;border-radius:8px;background:#e2e8f0">✕</button></div>' +
      grid(lab('Titre', inp('titre', x.titre, dis)) + lab('Projet', '<select data-f="project_id"' + (dis ? ' disabled' : '') + ' style="width:100%;padding:6px"><option value="">—</option>' + projets().map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === x.project_id ? ' selected' : '') + '>' + esc(p.nom) + '</option>'; }).join('') + '</select>') + lab('Site / bâtiment', inp('site', x.site, dis)) + lab('Auteur de la note de calcul', inp('auteur', x.auteur, dis))) + '<p style="font-size:12px;color:#475569;margin:6px 0">' + esc(x.no) + ' — ' + esc(x.statut) + (dis ? ' (verrouillé : rouvrir pour modifier)' : '') + '</p><div id="exbElecTab">' + ({ ref: tabRef, circ: tabCirc, bil: tabBil, rap: tabRap }[TAB])(x, dis) + '</div>';
  }
  function setPath(x, f, v) { var p = f.split('.'), o = x; while (p.length > 1) o = o[p.shift()]; o[p[0]] = v; }
  function onChange(ev) {
    var t = ev.target, f = t.getAttribute && t.getAttribute('data-f'), x = GID ? find(GID) : null; if (!f || !x || ro(x)) return;
    setPath(x, f, t.value); if (f === 'izTxt' && x.izConf) { x.izConf = null; x.histo.push({ t: Date.now(), msg: 'Table Iz modifiée : confirmation annulée' }); } saveDos(x); if (t.tagName === 'SELECT' || t.tagName === 'TEXTAREA' || f === 'izTxt') paint();
  }
  function jrn(x, m) { x.histo.push({ t: Date.now(), msg: m }); }
  function onClick(ev) {
    var t = ev.target.closest ? ev.target.closest('[data-a]') : null; if (!t) return; var a = t.getAttribute('data-a'), i = t.getAttribute('data-i'), x = GID ? find(GID) : null;
    if (a === 'close') { var o = d.getElementById('exbElec'); if (o) o.remove(); return; }
    if (a === 'new') { var n = nouveau(); saveDos(n); GID = n.id; TAB = 'ref'; audit('elec.nouveau', n.no, {}); return paint(); }
    if (a === 'open') { GID = i; TAB = 'ref'; return paint(); }
    if (a === 'back') { GID = null; return paint(); }
    if (a === 'tab') { TAB = i; return paint(); }
    if (!x) return;
    if (a === 'confiz') return who().then(function (par) { if (!par) return; x.izConf = { par: par, t: Date.now() }; jrn(x, 'Table Iz confirmée par ' + par); saveDos(x); audit('elec.iz.confirmee', x.no, { par: par }); paint(); });
    if (a === 'verifier') { var bl = bloque(x); if (bl.length) return toast('Vérification impossible : ' + bl.map(function (v) { return v.id; }).filter(function (v, j, s) { return s.indexOf(v) === j; }).join(', ') + ' (voir Rapport).', 'warn'); return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le vérificateur doit être une autre personne que l’auteur.', 'warn'); x.statut = 'Vérifié'; x.verifie = { par: par, t: Date.now() }; jrn(x, 'Vérifié par ' + par); saveDos(x); audit('elec.verifie', x.no, { par: par }); paint(); }); }
    if (a === 'viser') return who().then(function (par) { if (!par) return; if (par.toLowerCase() === String(x.auteur).trim().toLowerCase()) return toast('Le visa ne peut pas être donné par l’auteur.', 'warn'); x.statut = 'Visé'; x.vise = { par: par, t: Date.now() }; jrn(x, 'Visé par ' + par); saveDos(x); audit('elec.vise', x.no, { par: par }); paint(); });
    if (a === 'rouvrir') return ask('Motif de la réouverture (obligatoire) :', '').then(function (m) { m = String(m || '').trim(); if (!m) return toast('Motif obligatoire.', 'warn'); jrn(x, 'Rouvert en brouillon — ' + m); x.statut = 'Brouillon'; delete x.verifie; delete x.vise; saveDos(x); audit('elec.rouvert', x.no, { motif: m }); paint(); });
    if (a === 'csvc') { var k = calc(x); return csv([['Tableau', 'Circuit', 'Type', 'P kW', 'cos phi', 'Ku', 'L m', 'Ib A', 'Calibre A', 'Section mm2', 'Iz A', 'Chute %', 'Contrôle']].concat(k.pc.circuits.map(function (c, j) { var r = k.R[j]; return [c.tab, c.nom, c.type, c.P, c.cos, c.Ku, c.L, fx(r.ib, 2), r.In == null ? '' : r.In, r.s == null ? '' : r.s, r.iz == null ? '' : r.iz, r.dU ? fx(r.dU.pct, 2) : '', r.ok ? 'OK' : r.msgs.join(' ')]; })), x.no + '-circuits.csv'); }
    if (a === 'pdf') {
      var k2 = calc(x), B = k2.B, rows = [['Dossier', x.no + ' — ' + (x.titre || '—') + ' — statut : ' + x.statut], ['Projet / site', pnom(x.project_id) + ' — ' + (x.site || '—')], ['Auteur / date', (x.auteur || '—') + ' — ' + (x.date || '—')], ['Norme', (x.norme.nom || '—') + ' ' + (x.norme.edition || '')], ['Table Iz', x.izConf ? 'confirmée par ' + x.izConf.par : 'NON confirmée'], ['Circuits', String(k2.pc.circuits.length)], ['Puissance installée', fx(B.Pn, 2) + ' kW'], ['Puissance appelée', fx(B.P, 2) + ' kW (Ks global ' + fx(B.ksG, 2) + ', réserve ' + fx(B.reserve, 0) + ' %)'], ['Puissance apparente', fx(B.S, 2) + ' kVA — cos phi ' + fx(B.cos, 3) + ' — I3 ' + fx(B.I3, 1) + ' A']];
      k2.pc.circuits.forEach(function (c, j) { var r = k2.R[j]; rows.push([c.tab + ' / ' + c.nom, 'Ib ' + fx(r.ib, 1) + ' A — ' + (r.In == null ? '—' : r.In + ' A') + ' — ' + (r.s == null ? '—' : fx(r.s, 1) + ' mm2') + ' — dU ' + (r.dU ? fx(r.dU.pct, 2) + ' %' : '—') + ' — ' + (r.ok ? 'OK' : r.msgs.join(' '))]); });
      verif(x).forEach(function (v) { rows.push(['Contrôle ' + v.id, v.niveau + ' : ' + v.msg]); });
      return pdf({ titre: 'NOTE DE CALCUL ELECTRIQUE', sousTitre: san(x.no + ' — ' + (x.titre || '')), rows: rows.map(function (r) { return [san(r[0]), san(r[1])]; }), notes: ['Calculs deterministes - ne remplacent pas la note d\'un ingenieur electricien. Table Iz et chute de tension maximale fixees par le projet.'], footer: san(x.no + ' — ' + x.statut) });
    }
  }
  function ouvrir(tab) {
    if (tab) TAB = tab; var o = d.getElementById('exbElec'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbElec'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.id = 'exbElecBox'; c.style.cssText = 'background:#fff;border-radius:14px;padding:14px;max-width:980px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o);
    c.addEventListener('change', onChange); c.addEventListener('click', onClick); paint();
  }
  function ui() {
    var b = d.getElementById('exbGeoPlusBtn') || d.getElementById('exbTopoBtn') || d.getElementById('exbBeDalBtn') || d.getElementById('exbBeP2Btn') || d.getElementById('exbBeBtn'); if (!b || d.getElementById('exbElecBtn')) return;
    var k = d.createElement('button'); k.id = 'exbElecBtn'; k.setAttribute('data-exb-cat', 'ing'); k.setAttribute('data-exb-desc', 'Bilan de puissance, circuits, câbles, protections'); k.className = b.className; k.textContent = '⚡ Électricité'; k.onclick = function () { ouvrir('ref'); }; b.parentNode.insertBefore(k, b.nextSibling);
  }
  if (typeof MutationObserver !== 'undefined' && d.documentElement && d.documentElement.nodeType) new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  try { if (w.EXBCore && w.EXBCore.modules) w.EXBCore.modules.register({ id: 'elec', name: 'Bureau d’électricité', version: '1.0.0', area: 'Technique', deps: [], collections: [K] }); } catch (e) {}

  w.EXBElec = { open: ouvrir, parseIz: parseIz, parseCircuits: parseCircuits, parseKs: parseKs, ib: ib, dU: dU, calibre: calibre, sectionMin: sectionMin, circuit: circuit, bilan: bilan, quantCables: quantCables, verif: verif, nouveau: nouveau, calc: calc, IZ0: IZ0 };
  if (typeof module !== 'undefined' && module.exports) module.exports = w.EXBElec;
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { addEventListener: function () {}, documentElement: {} });
