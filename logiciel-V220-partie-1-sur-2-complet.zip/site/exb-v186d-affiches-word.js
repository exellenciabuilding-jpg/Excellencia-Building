/* Excellencia Building V186d — l'éditeur « Word » est branché sur les affiches (Studio libre).
 * 1) Chaque texte d'une affiche peut s'éditer dans le VRAI éditeur Word du logiciel (ruban complet : polices, tailles, couleurs, gras/italique/souligné,
 *    listes, tableaux, images, bandeaux colorés, alignements, interligne, rechercher/remplacer…) : bouton « ✍️ Éditer avec Word » ou « ✍️ Texte Word ».
 * 2) Le texte mis en forme est enregistré dans l'élément (champ « rt », même balisage que les pièces écrites) ; « tx » garde la version texte simple.
 *    Il s'affiche sur l'affiche et dans les exports PNG / PDF. Les affiches enregistrées avant cette version restent intactes.
 * 3) « 📝 Word (.docx) » : tous les textes et images de l'affiche, dans l'ordre de lecture, dans un document Word (via exb-v130-docx.js).
 * Dépend de : exb-v81-pieces.js (EXBPIE_X), exb-v123-editeur.js (EXBPIE_ED), exb-v130-docx.js (EXBDocx), exb-affiches-studio.js (EXB_STUDIO.api).
 * Retrait : supprimer la balise <script> de ce fichier — les textes mis en forme s'affichent alors en texte simple (tx), rien n'est perdu. */
(function (w, d) {
  'use strict';
  var BASE_PT = 11; /* taille « 11 » de l'éditeur = taille du texte de l'élément ; les autres tailles sont proportionnelles */
  function X() { return w.EXBPIE_X; }
  function ED() { return w.EXBPIE_ED; }
  function API() { return w.EXB_STUDIO && w.EXB_STUDIO.api; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function note(t, k, ms) { try { (API() && API().note || w.notify)(t, k || 'ok', ms || 4000); } catch (e) {} }

  /* ───────── style des textes riches sur l'affiche ───────── */
  function css() {
    if (d.getElementById('exbawCss')) return;
    var s = d.createElement('style'); s.id = 'exbawCss';
    s.textContent =
      '.exbaw p{margin:0 0 .3em;text-align:inherit}.exbaw p.sp{margin:0;min-height:1em}.exbaw h2,.exbaw h3,.exbaw h4{margin:.25em 0 .2em;color:inherit;border:0;padding:0;text-align:inherit;text-transform:none;line-height:1.15}' +
      '.exbaw h2{font-size:1.6em}.exbaw h3{font-size:1.3em}.exbaw h4{font-size:1.12em}.exbaw ul,.exbaw ol{margin:.2em 0 .4em;padding-left:1.3em}.exbaw li{margin:0 0 .12em}' +
      '.exbaw hr{border:0;border-top:.08em solid currentColor;margin:.4em 0}.exbaw table{border-collapse:collapse;width:100%;margin:.2em 0}.exbaw td,.exbaw th{border:.06em solid currentColor;padding:.15em .4em;vertical-align:top;text-align:left}.exbaw th{font-weight:700}' +
      '.exbaw img{max-width:100%;height:auto}.exbaw .pb{display:none}.exbaw a{color:inherit;text-decoration:underline}' +
      '#exbawModal{position:fixed;inset:0;z-index:100500;background:rgba(15,23,42,.6);display:flex;align-items:stretch;justify-content:center;padding:10px}' +
      '#exbawBox{background:#dfe6f2;border-radius:12px;width:min(1180px,100%);display:flex;flex-direction:column;min-height:0;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.45)}' +
      '#exbawBar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#12305e;color:#fff;padding:8px 12px;font:700 14px Arial,sans-serif}#exbawBar span{flex:1;min-width:160px}' +
      '#exbawBar button{padding:9px 14px;border-radius:9px;border:1px solid #fff5;background:#ffffff1a;color:#fff;font:700 13px Arial,sans-serif;cursor:pointer}#exbawBar button.ok{background:#c9a227;border-color:#c9a227;color:#12254a}' +
      '#exbawHint{background:#fff8e1;color:#5d4b0a;font:12.5px Arial,sans-serif;padding:6px 12px;border-bottom:1px solid #e6d9a2}' +
      '#exbawBody{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden}#exbawBody #exbEd{margin:0;border:0;border-radius:0;flex:1;min-height:0;display:flex;flex-direction:column}#exbawBody #exbEdWrap{flex:1;max-height:none;min-height:0}' +
      '@media print{#exbawModal{display:none!important}}';
    (d.head || d.documentElement).appendChild(s);
  }

  /* ───────── balisage → HTML pour l'affiche ───────── */
  function htmlFor(md) {
    var h = '';
    try { h = X().rd(String(md || '')); } catch (e) { h = esc(md); }
    /* tailles en pt de l'éditeur → proportionnelles à la taille de l'élément (BASE_PT = taille de l'élément) */
    h = h.replace(/font-size:\s*(\d+(?:\.\d+)?)pt/g, function (m, n) { return 'font-size:' + (+n / BASE_PT).toFixed(3) + 'em'; });
    return h;
  }
  function paint(el, e) {
    css(); el.classList.add('exbaw');
    el.innerHTML = htmlFor(e.rt);
    [].forEach.call(el.querySelectorAll('img'), function (im) { im.draggable = false; im.style.pointerEvents = 'none'; });
    [].forEach.call(el.querySelectorAll('a'), function (a) { a.removeAttribute('href'); });
  }
  /* HTML → texte simple (garde les sauts de ligne entre paragraphes) */
  function plain(html) {
    var t = d.createElement('div'); t.innerHTML = html;
    [].forEach.call(t.querySelectorAll('p,h2,h3,h4,li,tr,hr,div'), function (n) { n.appendChild(d.createTextNode('\n')); });
    [].forEach.call(t.querySelectorAll('td,th'), function (n) { n.appendChild(d.createTextNode(' \t')); });
    return t.textContent.replace(/\u200b/g, '').replace(/\u00a0/g, ' ').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  /* texte simple de l'élément → balisage de départ pour l'éditeur (le gras / l'italique de l'élément sont conservés) */
  function seed(e) {
    if (e.rt) return e.rt;
    return String(e.tx == null ? '' : e.tx).split(/\r?\n/).map(function (l) {
      if (!l.trim()) return '[~]';
      l = l.replace(/^(\s*)(#|\||---|>>|<<|<=|==|\[|[-*•]\s|\d+[.)]\s)/, '$1​$2'); /* évite qu'un texte ordinaire soit pris pour un repère */
      if (e.i) l = '[i]' + l + '[/i]';
      if (e.b) l = '**' + l + '**';
      return l;
    }).join('\n');
  }

  /* ───────── fenêtre d'édition ───────── */
  var modal = null;
  function closeModal() { try { ED().detach(); } catch (x) {} if (modal) { modal.remove(); modal = null; } }
  function editText(e, opt) {
    var api = (opt && opt.api) || API(); if (!api || !ED() || !X()) { note('Éditeur Word indisponible dans cette installation.', 'error', 6000); return; }
    if (modal) return;
    if (d.getElementById('exbEd')) { note('Fermez d’abord la pièce écrite en cours d’édition (Pièces écrites), puis réessayez.', 'error', 7000); return; }
    css();
    modal = d.createElement('div'); modal.id = 'exbawModal';
    modal.innerHTML = '<div id="exbawBox" role="dialog" aria-label="Éditeur Word — texte de l’affiche"><div id="exbawBar"><span>✍️ Texte de l’affiche — éditeur Word</span><button type="button" id="exbawCancel">Annuler</button><button type="button" class="ok" id="exbawOk">✓ Appliquer à l’affiche</button></div>' +
      '<div id="exbawHint">La taille « ' + BASE_PT + ' » correspond à la taille actuelle du texte sur l’affiche ; une taille 22 est deux fois plus grande. Les couleurs que vous ne choisissez pas gardent la couleur du texte de l’affiche.</div>' +
      '<div id="exbawBody"><textarea id="exbawTa" style="display:none"></textarea></div></div>';
    d.body.appendChild(modal);
    var ta = d.getElementById('exbawTa'), start = seed(e); ta.value = start;
    var done = false;
    function apply() {
      if (done) return; done = true;
      try { ED().sync(); } catch (x) {}
      var md = ta.value, html = htmlFor(md);
      api.push(); e.rt = md; e.tx = plain(html) || ' ';
      closeModal(); api.refresh();
      note('✓ Texte mis en forme appliqué à l’affiche.', 'ok', 3000);
    }
    async function cancel() {
      try { ED().sync(); } catch (x) {}
      if (ta.value !== start && typeof w.exbConfirm === 'function' && !(await w.exbConfirm('Fermer sans appliquer vos modifications ?'))) return;
      closeModal();
    }
    d.getElementById('exbawOk').onclick = apply;
    d.getElementById('exbawCancel').onclick = cancel;
    modal.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && !d.getElementById('exbEdPop') && !d.getElementById('exbEdFind').contains(d.activeElement)) { ev.stopPropagation(); cancel(); } });
    ED().attach({ fmt: 'A4', ori: 'portrait' }, false, {
      ta: ta, noIdentity: true, forceWord: true, fileName: (api.name() || 'affiche') + '-texte',
      hide: ['print', 'saveMod', 'dup', 'fillv', 'back', 'mode'],
      actions: { save: apply }
    });
    var sv = modal.querySelector('button[data-c="save"]'); if (sv) { sv.title = 'Appliquer à l’affiche (Ctrl+S)'; var lb = sv.querySelector('.lb,span:last-child'); if (lb && /nregistrer/.test(lb.textContent)) lb.textContent = 'Appliquer'; }
  }

  /* ───────── export Word de l'affiche ───────── */
  function lum(c) { var m = /^#?([0-9a-f]{6})$/i.exec(String(c || '').trim()) || (function () { var t = /^#?([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(String(c || '').trim()); return t ? [0, t[1] + t[1] + t[2] + t[2] + t[3] + t[3]] : null; })(); if (!m) return 0; var h = m[1]; return 0.299 * parseInt(h.slice(0, 2), 16) + 0.587 * parseInt(h.slice(2, 4), 16) + 0.114 * parseInt(h.slice(4, 6), 16); }
  function hex6(c) { var t = String(c || '').trim(); var m = /^#([0-9a-f]{6})$/i.exec(t); if (m) return t.toLowerCase(); m = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(t); return m ? ('#' + m[1] + m[1] + m[2] + m[2] + m[3] + m[3]).toLowerCase() : ''; }
  function exportDocx() {
    var api = API(), ST = w.EXB_STUDIO && w.EXB_STUDIO.state && w.EXB_STUDIO.state();
    if (!api || !ST) return;
    if (!w.EXBDocx) { note('Export Word indisponible (exb-v130-docx.js absent).', 'error', 6000); return; }
    var F = api.fmt(), W = 640, sc = W / F.w, els = ST.els.filter(function (e) { return (e.t === 'text' && String(e.tx || '').trim()) || (e.t === 'img' && e.src); });
    if (!els.length) { note('Cette affiche ne contient encore ni texte ni image.', 'info', 4000); return; }
    els.sort(function (a, b) { return (a.y - b.y) || (a.x - b.x); });
    var darkBg = hex6(ST.bg && ST.bg.c1) && lum(ST.bg.c1) < 150 ? hex6(ST.bg.c1) : '#12305e';
    var host = d.createElement('div'); host.style.cssText = 'position:fixed;left:-100000px;top:0;width:' + W + 'px;font:11pt Arial,sans-serif;color:#111;background:#fff';
    host.id = 'exbawDocx';
    els.forEach(function (e) {
      var box = d.createElement('div');
      if (e.t === 'img') {
        var pct = Math.max(8, Math.min(100, Math.round(e.w / F.w * 100))), p = d.createElement('p'), im = d.createElement('img');
        im.src = e.src; im.setAttribute('data-w', pct); im.style.width = pct + '%'; p.style.textAlign = e.x + e.w / 2 > F.w * 0.6 && e.x > F.w * 0.5 ? 'right' : (e.x < F.w * 0.15 ? 'left' : 'center'); p.appendChild(im); host.appendChild(p); return;
      }
      var fs = Math.max(13, Math.round(e.fs * sc * 10) / 10), light = lum(e.col) > 185 && !e.bg, bg = e.bg ? hex6(e.bg) : (light ? darkBg : '');
      box.style.cssText = 'font-family:' + api.fontCss(e) + ';font-size:' + fs + 'px;color:' + (hex6(e.col) || '#111111') + ';text-align:' + (e.al || 'left') + ';line-height:' + (e.lh || 1.2) + (e.up ? ';text-transform:uppercase' : '');
      if (e.rt) box.innerHTML = htmlFor(e.rt);
      else box.innerHTML = String(e.tx).split(/\r?\n/).map(function (l) { return '<p>' + (l.trim() ? (e.i ? '<i>' : '') + (e.b ? '<b>' : '') + esc(l) + (e.b ? '</b>' : '') + (e.i ? '</i>' : '') : '<br>') + '</p>'; }).join('');
      if (e.up) [].forEach.call(box.querySelectorAll('p,h2,h3,h4,li'), function (n) { [].forEach.call(n.childNodes, function (c) { if (c.nodeType === 3) c.nodeValue = c.nodeValue.toUpperCase(); }); });
      if (bg) [].forEach.call(box.querySelectorAll('p,h2,h3,h4,li'), function (n) { if (!n.getAttribute('data-bg')) n.setAttribute('data-bg', bg); });
      [].forEach.call(box.querySelectorAll('img'), function (im) { if (!im.getAttribute('data-w')) im.setAttribute('data-w', (im.style.width || '60%').replace('%', '')); });
      host.appendChild(box);
    });
    d.body.appendChild(host);
    note('Création du document Word…', 'info', 2500);
    var imgs = [].slice.call(host.querySelectorAll('img')), left = imgs.length, fired = false;
    function go() {
      if (fired) return; fired = true;
      var blob, I = {}; try { I = (w.EXBId && w.EXBId.get && w.EXBId.get()) || {}; } catch (x) {}
      try { blob = w.EXBDocx.build(host, { name: I.name || '', tagline: I.tagline || '', fmt: 'A4', ori: F.w > F.h ? 'landscape' : 'portrait' }); }
      catch (x) { host.remove(); note('Export Word impossible : ' + (x && x.message || x), 'error', 8000); return; }
      host.remove();
      var fn = (api.name() || 'affiche') + '.docx', url = URL.createObjectURL(blob), a = d.createElement('a');
      a.href = url; a.download = fn; d.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      note('✓ Document Word « ' + fn + ' » prêt.', 'ok', 5000);
    }
    if (!left) return go();
    imgs.forEach(function (im) { var f = function () { if (--left === 0) go(); }; if (im.complete) f(); else { im.onload = f; im.onerror = f; } });
    setTimeout(go, 6000);
  }

  w.EXBAW = { version: 'V186d', paint: paint, htmlFor: htmlFor, plain: plain, seed: seed, editText: editText, exportDocx: exportDocx };
})(window, document);
