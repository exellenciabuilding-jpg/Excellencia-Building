/* Excellencia Building V186g — l'éditeur « Word » et les raccourcis clavier sont aussi branchés sur les AFFICHES EXCELLENCIA
 * (onglet « Affiches Excellencia » : affiche générale et affiche « logiciels », à côté du Studio libre).
 * 1) À côté de chaque champ de texte : « ✍️ Word » ouvre le vrai éditeur Word ; double-clic sur un texte de l'aperçu = même chose.
 *    Le texte mis en forme s'affiche dans l'aperçu et dans les exports PNG / PDF ; il est enregistré (clé « exb_poster_rt »).
 *    Le champ texte garde la version simple (affiches enregistrées avant cette version intactes ; si ce fichier est retiré, texte simple).
 * 2) Raccourcis : Ctrl+S enregistre les deux affiches ; Ctrl+Z / Ctrl+Y annulent / rétablissent les modifications faites avec Word
 *    (dans un champ de saisie, Ctrl+Z annule la frappe comme d'habitude).
 * Dépend de : exb-v186d-affiches-word.js (EXBAW). Retrait : supprimer la balise <script> de ce fichier. */
(function (w, d) {
  'use strict';
  var K = 'exb_poster_rt';
  /* champ de saisie → zone de l'aperçu (seuls les textes simples ; les zones composées — nom en 2 couleurs, cartes de programme — restent en texte simple) */
  var MAP = {
    p_tagline_top: 'pc_tagline_top', p_tagline_company: 'pc_tagline_company', p_services_line: 'pc_services_line', p_hero_white: 'pc_hero_white', p_hero_blue: 'pc_hero_blue',
    p_services_title: 'pc_services_title', p_quote: 'pc_quote', p_ensemble: 'pc_ensemble', p_contact_label: 'pc_contact_label', p_contact_address: 'pc_contact_address', p_contact_phone: 'pc_contact_phone', p_contact_email: 'pc_contact_email',
    sp_tagline: 'spv_tagline', sp_title: 'spv_title', sp_session: 'spv_session', sp_desc: 'spv_desc', sp_program_title: 'spv_program_title', sp_structure_title: 'spv_structure_title', sp_structure_points: 'spv_structure_body',
    sp_objective_title: 'spv_objective_title', sp_objective: 'spv_objective_body', sp_fee: 'spv_fee', sp_fee_label: 'spv_fee_label', sp_fee_title: 'spv_fee_title', sp_cta: 'spv_cta', sp_availability: 'spv_availability',
    sp_phone: 'spv_phone', sp_email: 'spv_email', sp_address: 'spv_address', sp_footer: 'spv_footer'
  };
  var i; for (i = 1; i <= 6; i++) MAP['p_srv' + i] = 'pc_srv' + i;
  for (i = 1; i <= 4; i++) { MAP['p_cap' + i] = 'pc_cap' + i; MAP['p_badge' + i] = 'pc_badge' + i; MAP['sp_badge' + i] = 'spv_badge' + i; }
  var REV = {}; Object.keys(MAP).forEach(function (k) { REV[MAP[k]] = k; });
  function $(x) { return d.getElementById(x); }
  function note(t, k, ms) { try { w.notify && w.notify(t, k || 'ok', ms || 3500); } catch (e) {} }
  function ld() { try { return (w.load ? w.load(K, {}) : JSON.parse(w.localStorage.getItem(K) || '{}')) || {}; } catch (e) { return {}; } }
  var RT = ld(), hist = [], fut = [];
  function persist() { try { if (w.save) w.save(K, RT); else w.localStorage.setItem(K, JSON.stringify(RT)); } catch (e) {} }
  function isSoft(id) { return id.indexOf('sp_') === 0; }

  /* ───────── affichage du texte mis en forme dans l'aperçu ───────── */
  function paintEl(id) {
    var el = $(MAP[id]); if (!el || !w.EXBAW) return;
    var md = RT[id];
    if (!md) { if (el.getAttribute('data-exb-rt')) el.removeAttribute('data-exb-rt'); return; }
    if (el.getAttribute('data-exb-rt') === md && el.firstElementChild && el.firstElementChild.classList.contains('exbaw')) return;
    var box = d.createElement('div'); w.EXBAW.paint(box, { rt: md });
    box.style.cssText = 'width:100%;white-space:normal;text-align:inherit';
    el.innerHTML = ''; el.appendChild(box); el.setAttribute('data-exb-rt', md);
  }
  function paintAll() { Object.keys(MAP).forEach(function (id) { if (RT[id]) paintEl(id); }); }
  function rerender(id) { try { if (isSoft(id)) w.renderSoftwarePoster && w.renderSoftwarePoster(); else w.renderPoster && w.renderPoster(); } catch (e) {} paintAll(); }
  function wrapRender() {
    ['renderPoster', 'renderSoftwarePoster'].forEach(function (n) {
      var f = w[n]; if (typeof f !== 'function' || f.__exbrt) return;
      var g = function () { var r = f.apply(this, arguments); try { paintAll(); } catch (e) {} return r; }; g.__exbrt = 1;
      try { w[n] = g; } catch (e) {}
    });
  }

  /* ───────── boutons à côté des champs ───────── */
  function css() {
    if ($('exbprCss')) return;
    var s = d.createElement('style'); s.id = 'exbprCss';
    s.textContent = '.exbpr{display:flex;gap:6px;flex-wrap:wrap;margin:2px 0 8px}.exbpr button{padding:5px 10px;border-radius:8px;border:1px solid #c9d3df;background:#f4f7fb;color:#12305e;font:700 12px Arial,sans-serif;cursor:pointer}.exbpr button.on{background:#12305e;color:#fff;border-color:#12305e}' +
      '.exbpr-note{font-size:12px;color:#5e6877;margin:2px 0 8px}#posterPaper [data-exb-rt],#softwarePosterPaper [data-exb-rt]{cursor:text}@media print{.exbpr,.exbpr-note{display:none!important}}';
    (d.head || d.documentElement).appendChild(s);
  }
  function controls(id) {
    var inp = $(id); if (!inp) return;
    var bar = inp.nextElementSibling && inp.nextElementSibling.classList && inp.nextElementSibling.classList.contains('exbpr') ? inp.nextElementSibling : null;
    if (!bar) { bar = d.createElement('div'); bar.className = 'exbpr no-print'; inp.insertAdjacentElement('afterend', bar); }
    bar.innerHTML = '<button type="button" class="on" data-w="1" title="Mettre en forme ce texte avec l’éditeur Word (polices, couleurs, tailles…)">✍️ Word</button>' + (RT[id] ? '<button type="button" data-s="1" title="Retirer la mise en forme Word de ce texte">Texte simple</button>' : '');
    bar.firstChild.onclick = function () { edit(id); };
    var sb = bar.querySelector('[data-s]'); if (sb) sb.onclick = function () { snap(id); delete RT[id]; applied(id, true); };
    inp.readOnly = !!RT[id]; inp.title = RT[id] ? 'Texte mis en forme avec Word : utilisez « ✍️ Word » pour le modifier' : inp.title;
  }
  function setup() {
    css(); var any = false;
    Object.keys(MAP).forEach(function (id) { if ($(id)) { any = true; if (!($(id).nextElementSibling && $(id).nextElementSibling.classList.contains('exbpr'))) controls(id); } });
    var h2 = d.querySelector('#affiches .grid > .card h2');
    if (h2 && !$('exbprNote')) { var n = d.createElement('p'); n.id = 'exbprNote'; n.className = 'exbpr-note no-print'; n.innerHTML = '✍️ <b>Word</b> à côté d’un champ (ou double-clic sur un texte de l’aperçu) : mise en forme comme dans Word. <b>Ctrl+S</b> enregistre · <b>Ctrl+Z / Ctrl+Y</b> annulent / rétablissent.'; h2.insertAdjacentElement('afterend', n); }
    wrapRender(); paintAll(); return any;
  }

  /* ───────── édition, annuler / rétablir ───────── */
  function snap(id) { hist.push({ id: id, rt: RT[id] || '', val: ($(id) || {}).value }); if (hist.length > 40) hist.shift(); fut = []; }
  function applied(id, quiet) { /* après un changement : rafraîchit, enregistre */
    persist(); controls(id); rerender(id);
    try { if (isSoft(id)) w.saveSoftwarePosterData && w.saveSoftwarePosterData(); else w.savePosterData && w.savePosterData(); } catch (e) {}
    paintAll(); if (!quiet) note('✓ Texte mis en forme appliqué à l’affiche.', 'ok', 2500);
  }
  function edit(id) {
    var inp = $(id); if (!inp) return;
    if (!w.EXBAW || !w.EXBPIE_ED) { note('Éditeur Word indisponible dans cette installation.', 'error', 5000); return; }
    var multi = inp.tagName === 'TEXTAREA', stub = { tx: inp.value, rt: RT[id] || '' }, before = { id: id, rt: RT[id] || '', val: inp.value };
    var api = { push: function () {}, name: function () { return 'affiche'; }, note: note, fontCss: function () { return 'Arial,sans-serif'; },
      refresh: function () {
        var v = multi ? String(stub.tx || '').trim() : String(stub.tx || '').replace(/\s*\n+\s*/g, ' ').trim();
        hist.push(before); if (hist.length > 40) hist.shift(); fut = [];
        RT[id] = stub.rt; inp.value = v; applied(id);
      } };
    w.EXBAW.editText(stub, { api: api });
  }
  function restore(s, other) {
    var id = s.id, inp = $(id); if (!inp) return;
    other.push({ id: id, rt: RT[id] || '', val: inp.value });
    if (s.rt) RT[id] = s.rt; else delete RT[id];
    inp.value = s.val == null ? '' : s.val; applied(id, true);
  }
  function undo() { var s = hist.pop(); if (!s) { note('Rien à annuler.', 'info', 1500); return; } restore(s, fut); note('↶ Annulé', 'info', 1200); }
  function redo() { var s = fut.pop(); if (!s) { note('Rien à rétablir.', 'info', 1500); return; } restore(s, hist); note('↷ Rétabli', 'info', 1200); }
  function saveAll() { try { w.savePosterData && w.savePosterData(); } catch (e) {} try { w.saveSoftwarePosterData && w.saveSoftwarePosterData(); } catch (e) {} persist(); note('✓ Affiches enregistrées (Ctrl+S).', 'ok', 2500); }

  function active() { var sec = $('affiches'); if (!sec || w.getComputedStyle(sec).display === 'none') return false; var r = $('exbsRoot'); if (r && r.classList.contains('on')) return false; return !$('exbawModal'); }
  d.addEventListener('keydown', function (ev) {
    if (!active()) return;
    var mod = ev.ctrlKey || ev.metaKey, k = String(ev.key || '').toLowerCase();
    if (mod && k === 's') { ev.preventDefault(); saveAll(); return; }
    var t = ev.target || {}, ty = String(t.type || '').toLowerCase();
    if (t.isContentEditable || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || (t.tagName === 'INPUT' && !/^(range|color|checkbox|radio|button|file)$/.test(ty))) return;
    if (mod && k === 'z' && !ev.shiftKey) { ev.preventDefault(); undo(); return; }
    if (mod && (k === 'y' || (k === 'z' && ev.shiftKey))) { ev.preventDefault(); redo(); }
  });
  d.addEventListener('dblclick', function (ev) {
    if (!active()) return;
    var el = ev.target && ev.target.closest && ev.target.closest('#posterPaper [id^="pc_"],#softwarePosterPaper [id^="spv_"]'); if (!el) return;
    var id = REV[el.id]; if (!id) return; ev.preventDefault(); edit(id);
  });
  /* une frappe dans un champ relance l'affichage de l'aperçu : on remet le texte mis en forme juste après */
  d.addEventListener('input', function (ev) { if (ev.target && MAP[ev.target.id]) setTimeout(paintAll, 0); }, true);

  var n = 0, iv = setInterval(function () { var ok = false; try { ok = setup(); } catch (e) {} if ((ok && ++n > 4) || n > 30) clearInterval(iv); else if (!ok) n++; }, 800);
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(function () { try { setup(); } catch (e) {} }, 0); }); else setTimeout(function () { try { setup(); } catch (e) {} }, 0);
  d.addEventListener('exb-images-ready', function () { setTimeout(function () { try { wrapRender(); paintAll(); } catch (e) {} }, 100); });
  w.EXBPR = { version: 'V186g', fields: function () { return Object.keys(MAP); }, edit: edit, undo: undo, redo: redo, paintAll: paintAll, rt: function () { return RT; } };
})(window, document);
