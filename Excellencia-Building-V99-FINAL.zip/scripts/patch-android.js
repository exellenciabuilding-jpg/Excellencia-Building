/* Ajoute dans le projet Android (dossier android/) les autorisations de stockage nécessaires au dossier Documents. */
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(f)) { console.log('android/ absent : lancez d’abord « npm run android:add ».'); process.exit(0); }
let x = fs.readFileSync(f, 'utf8');
const perms = [
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />'
];
perms.forEach(p => { if (!x.includes(p.split(' ')[1])) x = x.replace('</manifest>', '    ' + p + '\n</manifest>'); });
if (!x.includes('requestLegacyExternalStorage')) x = x.replace('<application', '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(f, x);
console.log('AndroidManifest.xml : autorisations de stockage ajoutées.');

/* Icône de l'application : remplace les icônes Capacitor par défaut par le logo Excellencia Building
 * (resources/android-res/mipmap-* → android/app/src/main/res/mipmap-*). */
(function () {
  const src = path.join(__dirname, '..', 'resources', 'android-res');
  const dst = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res');
  if (!fs.existsSync(src) || !fs.existsSync(dst)) { console.log('Icônes : dossier source ou res/ absent, ignoré.'); return; }
  let n = 0;
  (function copy(a, b) {
    fs.mkdirSync(b, { recursive: true });
    for (const e of fs.readdirSync(a, { withFileTypes: true })) {
      if (e.isDirectory()) copy(path.join(a, e.name), path.join(b, e.name));
      else { fs.copyFileSync(path.join(a, e.name), path.join(b, e.name)); n++; }
    }
  })(src, dst);
  /* fond de l'icône adaptative : blanc, comme le logo */
  const bg = path.join(dst, 'values', 'ic_launcher_background.xml');
  fs.mkdirSync(path.dirname(bg), { recursive: true });
  fs.writeFileSync(bg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFFFFF</color>\n</resources>\n');
  /* icônes adaptatives (Android 8+) : on force la référence vers notre premier plan */
  const any = path.join(dst, 'mipmap-anydpi-v26'); fs.mkdirSync(any, { recursive: true });
  const ad = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  fs.writeFileSync(path.join(any, 'ic_launcher.xml'), ad); fs.writeFileSync(path.join(any, 'ic_launcher_round.xml'), ad);
  console.log('Icônes Excellencia Building installées (' + n + ' fichiers).');
})();

/* Clavier : la fenêtre se redimensionne au-dessus du clavier (les champs de saisie restent visibles). */
(function () {
  const f2 = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
  if (!fs.existsSync(f2)) return;
  let m = fs.readFileSync(f2, 'utf8');
  if (!m.includes('windowSoftInputMode')) { m = m.replace('<activity', '<activity android:windowSoftInputMode="adjustResize"'); fs.writeFileSync(f2, m); console.log('AndroidManifest.xml : adjustResize ajouté.'); }
})();
