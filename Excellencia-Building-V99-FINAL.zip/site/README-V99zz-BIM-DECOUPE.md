# V99zz (complément) — Lecteur 3D : découpe des ouvertures + correctif du tracé

Fichier modifié : `exb-ifc3d.js` (+ tests `tools/test-bim/*`, `sw.js` cache `exb-v99zz-bim-decoupe-1`). Aucun nouveau SQL.

## Correctif important
Avant, seul le **premier élément** de la maquette se dessinait correctement : les autres n'apparaissaient que par débordement du tracé (risque d'écran vide sur certaines cartes graphiques) et la sélection au clic pouvait se tromper. Corrigé ; un test vérifie que **chaque élément se dessine seul**.

## Découpe réelle des ouvertures
Les portes et fenêtres reliées à un mur ou une dalle sont **découpées dans la 3D** (trou avec parois), même si l'ouverture est plus épaisse que le mur ou descend au sol. Le volume net des quantités en découle exactement, sans double déduction (volume brut conservé).
Limite : éléments droits (convexes) uniquement ; un mur courbe ou en L reste plein (signalé dans « Limites de cette lecture »), son volume net reste déduit.

## Tests
`node tools/test-bim/test-quantites.js` (13/13 : mur A 2,58 m³, mur C 2,84 m³), `python3 tools/test-bim/test.py` (14/14).
