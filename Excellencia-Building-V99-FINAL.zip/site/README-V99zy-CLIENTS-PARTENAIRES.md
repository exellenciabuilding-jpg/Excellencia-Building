# V99zy — Clients et partenaires (audit P2), intégré à V99zx

Repris de ma version V99zn (portails) et adapté au modèle de V99zx : organisation, droits par fonction, synchronisation, 2FA, licence.
Nouveaux fichiers : `portail.html`, `exb-v99zy-portails.js`, `supabase/migration-v99zy-portails.sql`.
Modifiés : `index.html` (1 balise script), `exb-v99r-shell.js` (tuile Clients & CRM, version), `exb-db.js` (3 collections synchronisées), `exb-roles.js` (droits de la section), `sw.js` (cache `exb-v99zy-portails-1`), `tools/check.js` (+8 contrôles), `tools/test-rls/run.sh` (charge la migration).

## À faire une fois
1. Supabase › SQL Editor : exécuter `supabase/migration-v99zy-portails.sql` **après** `migration-v99zp-double-authentification.sql` (réexécutable). Sauvegarde d'abord, essai sur un projet de recette.
2. Publier `portail.html` avec le reste du site (il utilise `supabase-config.js`, comme `apprenant.html`).
3. Pour publier : être connecté au compte en ligne et appartenir à une organisation (⚙️ Administration › Équipe).

## Ce que ça fait
**Clients & CRM › 🔗 Portails & signatures** (4 onglets) :
- **Portails** : publication d'un instantané choisi (avancement, jalons, photos, journal, factures et reste à payer, lots, documents à signer) sous un lien secret + code à 6 chiffres. Portail client et portail sous-traitant (sans photos ni factures du client, avec déclaration d'avancement par lot). Mise à jour, révocation, QR, envoi du lien et du code en deux messages séparés. Incidents, notes internes, coûts et marges ne sont jamais publiés.
- **Signatures** : modèles (contrat de travaux, sous-traitance, avenant, ordre de service, PV de réception, devis accepté), empreinte SHA-256, signature de l'entreprise dans l'application (ou signature + cachet enregistrés), signature du client / sous-traitant dans le portail, attestation imprimable. Texte verrouillé une fois publié (nouvelle version pour modifier).
- **Retours** : signatures (fusionnées dans les documents), messages avec réponse, déclarations à accepter / refuser, visites.
- **Relances** : messages WhatsApp / SMS / e-mail préparés automatiquement (facture non soldée, situation non facturée, signature en attente, projet en retard, mise à jour publiée) ; envoi d'un appui.

## Ce qui change par rapport à V99zn
- Portails rattachés à l'**organisation** (plus à un utilisateur) : un collègue autorisé peut mettre à jour, répondre ou révoquer. Droits = fonction (collection « portails », copiés depuis « clients »), 2FA et licence appliquées par le serveur via `peut()` et `licence_ecriture_ok()`.
- Les documents à signer (`esign`), les portails (`portails`) et les relances (`relances`) sont **synchronisés** entre les appareils comme le reste.
- Le **code d'accès ne quitte jamais l'appareil** (clé locale `exb_portail_codes`) : sur un autre appareil, « Envoyer le code » propose d'en générer un nouveau (l'ancien cesse de fonctionner).
- La tuile et les droits suivent le menu et les parcours de V99zt (visible en Construction et en Formation).

## Sécurité côté serveur
Jeton aléatoire de 96 bits ; code haché (SHA-256 salé par le jeton) ; blocage 15 min après 5 codes faux ; limites de volume ; lien révocable et expirable ; aucune table lisible en direct par un visiteur ; signature acceptée seulement pour un document publié et pour le bon rôle. Les 4 fonctions visiteur sont ouvertes à l'anonyme volontairement (jeton + code obligatoires).

## Limites
- **Le script SQL n'a pas pu être exécuté sur un vrai PostgreSQL ici** : à passer dans `tools/test-rls/run.sh` et à tester sur un projet de recette (publier, lire, révoquer avec un compte autorisé et un compte « lecteur »).
- Le portail est un instantané : mis à jour seulement à « Publier / Mettre à jour ».
- Signature électronique simple : valeur juridique en RDC à confirmer par un juriste ; modèles de contrat indicatifs.
- Pas d'envoi automatique WhatsApp / SMS / e-mail (passerelle payante à ajouter).
- Lots du sous-traitant saisis à la main ; ses situations de paiement ne sont pas modélisées.

## Contrôles
`tools/check.js` : 304 / 304. Tests existants (`test-controles`, `test-cpm`, `test-errors`) : OK. Parcours de bout en bout dans Chromium avec un serveur Supabase simulé : 45 / 45 (publication, ouverture, mauvais code, signature, message, déclaration, acceptation, révocation, relances, organisation transmise au serveur, code absent des données synchronisées) + refus de publier sans organisation.

Retour en arrière : retirer la balise script de `index.html`, restaurer `exb-db.js`, `exb-roles.js`, `exb-v99r-shell.js`, `sw.js`, `tools/check.js`, `tools/test-rls/run.sh` de V99zx.
