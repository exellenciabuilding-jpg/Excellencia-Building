/* Excellencia Building V99zzq — Module TFL (Travaux de Fin de Licence), MODE LOCAL AUTONOME.
 * Fonctionne sans serveur, comme les apprenants :
 *   1) vous préparez le formulaire (tfl-formulaire.html) pour un étudiant et vous lui envoyez le fichier ;
 *   2) l'étudiant le remplit sans Internet et vous renvoie un fichier .json ;
 *   3) vous l'importez : la copie est enregistrée, le dossier reçoit son numéro (TFL-AAAA-0001) et vous attribuez le matricule.
 * Les données restent sur cet appareil (sauvegarde exportable). Les noms de champs reprennent migration-v99zzq-tfl.sql
 * (tfl_etudiants, tfl_dossiers, tfl_encadreurs) pour une synchronisation ultérieure avec le serveur. */
(function (root) {
  'use strict';
  var K = { etu: 'exb_tfl_etudiants', dos: 'exb_tfl_dossiers', enc: 'exb_tfl_encadreurs', cpt: 'exb_tfl_compteurs',
            done: 'exb_tfl_done', his: 'exb_tfl_historique', prep: 'exb_tfl_prepares', acc: 'exb_tfl_acces', msg: 'exb_tfl_messages', bib: 'exb_tfl_biblio', suj: 'exb_tfl_sujets', plans: 'exb_tfl_plans' };
  var STATUTS = [['recu', 'Reçu'], ['en_verification', 'En vérification'], ['complement_demande', 'Complément demandé'],
                 ['accepte', 'Accepté'], ['refuse', 'Refusé'], ['clos', 'Clos']];
  var DOMAINES = [['genie_civil', 'Génie civil'], ['architecture', 'Architecture'], ['gestion_travaux', 'Gestion des travaux'], ['autre', 'Autre']];
  var SUJET = [['a_etudier', 'À étudier'], ['accepte', 'Accepté'], ['a_reviser', 'À réviser'], ['refuse', 'Refusé']];
  var UNIV = [['non_demandee', 'Non demandée'], ['en_attente', 'En attente'], ['accordee', 'Accordée'], ['refusee', 'Refusée']];
  var ETAPES = [[1, 'Candidature reçue'], [2, 'Vérification administrative'], [3, 'Décision administrative'], [4, 'Ouverture du dossier d’encadrement'], [5, 'Affectation d’un encadreur'],
                [6, 'Recherche et rédaction'], [7, 'Contrôle final'], [8, 'Préparation de la défense'], [9, 'Clôture du dossier']];
  var CRITERES = [['pertinence', 'Pertinence'], ['faisabilite', 'Faisabilité'], ['delimitation', 'Délimitation du sujet'], ['donnees', 'Disponibilité des données']];
  var LBL = function (list, v) { var r = list.filter(function (x) { return x[0] === v; })[0]; return r ? r[1] : (v || ''); };

  /* ---------- utilitaires ---------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function norm(v) { return String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function digits(v) { return String(v || '').replace(/\D/g, ''); }
  /* Même numéro écrit avec ou sans indicatif (081…, +243 81…) : on compare les 9 derniers chiffres. */
  function meme(a, b) { var x = digits(a), y = digits(b); if (x.length < 6 || y.length < 6) return false; return x === y || (x.length >= 9 && y.length >= 9 && x.slice(-9) === y.slice(-9)); }
  function cut(v, n) { return String(v == null ? '' : v).trim().slice(0, n || 200); }
  function rid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  /* Signature manuscrite de l'étudiant (PNG/JPEG en data URL, taille bornée). */
  function okSig(u) { return typeof u === 'string' && u.length <= 150000 && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u); }
  function okPhoto(u) { return /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u || ''); }
  function now() { return new Date().toISOString(); }
  function $(i) { return document.getElementById(i); }

  /* ---------- stockage (fonction save/load du logiciel si présente, sinon localStorage) ---------- */
  /* pour les tests : root.EXBTFL_MEM = {} remplace le stockage */
  function get(k, d) {
    if (root.EXBTFL_MEM) return root.EXBTFL_MEM[k] !== undefined ? JSON.parse(JSON.stringify(root.EXBTFL_MEM[k])) : d;
    try { if (typeof root.load === 'function') { var v = root.load(k, d); return v == null ? d : v; } } catch (e) { /* repli */ }
    try { var s = root.localStorage.getItem(k); return s == null ? d : JSON.parse(s); } catch (e) { return d; }
  }
  function put(k, v) {
    if (root.EXBTFL_MEM) { root.EXBTFL_MEM[k] = JSON.parse(JSON.stringify(v)); return true; }
    try { if (typeof root.save === 'function') return root.save(k, v) !== false; } catch (e) { /* repli */ }
    try { root.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; }
  }
  function say(m, t) { try { if (typeof root.notify === 'function') root.notify(m, t || 'info', 6000); } catch (e) { /* silencieux */ } }
  function trace(a, d) { try { if (typeof root.audit === 'function') root.audit(a, d); } catch (e) { /* silencieux */ } }

  var L = { etu: function () { return get(K.etu, []); }, dos: function () { return get(K.dos, []); }, enc: function () { return get(K.enc, []); } };
  function history(dossier, action, avant, apres) {
    var h = get(K.his, []); h.unshift({ dossier_id: dossier, at: now(), action: action, avant: avant || null, apres: apres || null, par: operateur() });
    put(K.his, h.slice(0, 800));
  }

  /* ---------- numéros ---------- */
  function nextNumero(dossiers) {
    var y = new Date().getFullYear(), c = get(K.cpt, {}), max = Number(c[y] || 0), re = new RegExp('^TFL-' + y + '-(\\d{4,})$');
    dossiers.forEach(function (d) { var m = re.exec(d.numero || ''); if (m) max = Math.max(max, parseInt(m[1], 10)); });
    c[y] = max + 1; put(K.cpt, c);
    return 'TFL-' + y + '-' + String(max + 1).padStart(4, '0');
  }
  function usedMatricules() {
    var s = {}, add = function (a) { (a || []).forEach(function (x) { if (x && x.matricule) s[String(x.matricule).trim()] = 1; if (x && x.matricule_en_ligne) s[String(x.matricule_en_ligne).trim()] = 1; }); };
    add(L.etu()); add(L.enc());
    try { if (typeof participants !== 'undefined') add(participants); } catch (e) { /* absent */ }
    try { if (typeof trainers !== 'undefined') add(trainers); } catch (e) { /* absent */ }
    try { if (typeof exbHr !== 'undefined') add(exbHr); } catch (e) { /* absent */ }
    try { add(root.exbApprovals); } catch (e) { /* absent */ }
    return s;
  }
  function newMatricule() {
    var used = usedMatricules(), i, n, m;
    for (i = 0; i < 2000; i++) {
      n = ''; for (var j = 0; j < 9; j++) n += Math.floor(Math.random() * 10);
      m = n.slice(0, 3) + '-' + n.slice(3, 6) + '-' + n.slice(6, 9);
      if (!used[m]) return m;
    }
    return String(Date.now()).slice(-9).replace(/(\d{3})(\d{3})(\d{3})/, '$1-$2-$3');
  }
  /* Un apprenant déjà inscrit (même téléphone ou e-mail) garde SON matricule : on ne crée pas un second numéro pour la même personne. */
  function matriculeConnu(e) {
    var em = String(e.email || '').toLowerCase(), found = null;
    try {
      if (typeof participants !== 'undefined') participants.forEach(function (p) {
        if (found || !p || !p.matricule) return;
        if (meme(p.phone, e.telephone) || (em && String(p.email || '').toLowerCase() === em)) found = p;
      });
    } catch (x) { /* absent */ }
    return found;
  }

  /* ---------- IMPORT d'une copie remplie ---------- */
  function importer(o) {
    if (!o || o.form !== 'EXB_TFL' || !o.d) throw new Error('ce fichier n’est pas une candidature TFL Excellencia Building.');
    var d = o.d, nom = cut(d.nom, 120), tel = cut(d.telephone, 40), titre = cut(d.sujet_titre, 250);
    if (!nom || !tel) throw new Error('nom ou téléphone manquant.');
    if (!titre || !cut(d.problematique, 3000) || !cut(d.objectifs, 3000)) throw new Error('sujet incomplet (titre, problématique et objectifs obligatoires).');
    var domaine = DOMAINES.some(function (x) { return x[0] === d.domaine; }) ? d.domaine : 'autre';
    /* Même envoi reçu par fichier OU en ligne (le serveur écrit la date autrement) : on compare des dates normalisées. */
    var sub = ''; if (o.submitted_at) { var dt = new Date(o.submitted_at); sub = isNaN(dt.getTime()) ? String(o.submitted_at) : dt.toISOString(); }
    var sig = ['tfl', sub, digits(tel) || norm(nom)].join('|'), done = get(K.done, []);
    if (sub && done.indexOf(sig) >= 0) return { dup: true, nom: nom };

    var etus = L.etu(), dos = L.dos(), em = cut(d.email, 120).toLowerCase(), nn = norm(nom);
    var e = etus.filter(function (x) { var xe = String(x.email || '').toLowerCase(); return meme(x.telephone, tel) || (em && xe === em); })[0];
    var nouvelEtu = !e;
    if (!e) { e = { id: 'TFLE-' + rid(), matricule: '', created_at: now() }; etus.push(e); }
    e.nom = nom; e.telephone = tel; e.email = em || e.email || '';
    e.universite = cut(d.universite, 150) || e.universite || ''; e.promotion = cut(d.promotion, 60) || e.promotion || ''; e.filiere = cut(d.filiere, 100) || e.filiere || '';
    if (okPhoto(o.photo)) e.photo = o.photo; else e.photo = e.photo || '';
    { var sgn = o.signature || d.signature; if (okSig(sgn)) e.signature = sgn; }
    /* Le matricule indiqué par l'étudiant est seulement AFFICHÉ : c'est l'administration qui attribue ou confirme le numéro. */
    if (cut(d.matricule_existant, 40)) e.matricule_declare = cut(d.matricule_existant, 40);
    /* Fiche étudiante complète (page tfl-fiche.html ouverte après le choix d'un sujet) : on ne remplace une valeur que si une nouvelle est fournie. */
    [['annee_academique', 20], ['faculte', 100], ['niveau', 20], ['date_naissance', 20], ['lieu_naissance', 100], ['nationalite', 60], ['adresse', 150], ['matricule_univ', 40], ['remarques', 1000]].forEach(function (c) { var v = cut(d[c[0]], c[1]); if (v) e[c[0]] = v; });

    /* Un étudiant à qui l'on a demandé un complément renvoie le même dossier : on le met à jour au lieu d'en créer un second. */
    var compl = dos.filter(function (x) { return x.etudiant_id === e.id && x.statut === 'complement_demande'; })[0], dossier, maj = false;
    var champs = { domaine: domaine, sujet_titre: titre, problematique: cut(d.problematique, 3000), objectifs: cut(d.objectifs, 3000),
                   methodologie: cut(d.methodologie, 3000), recherches_deja: cut(d.recherches_deja, 3000), sujet_ref: cut(d.sujet_ref, 40), encadreur_pressenti: cut(d.encadreur_pressenti, 150) };
    var memeSujet = (!compl && champs.sujet_ref) ? dos.filter(function (x) { return x.etudiant_id === e.id && x.sujet_ref === champs.sujet_ref; })[0] : null;
    if (memeSujet) {
      /* Même étudiant, même sujet : la fiche complète met à jour le dossier existant (statut et décision inchangés). */
      dossier = memeSujet; maj = true;
      Object.keys(champs).forEach(function (k) { if (champs[k]) dossier[k] = champs[k]; }); dossier.updated_at = now();
      history(dossier.id, 'complement_recu', { statut: dossier.statut }, { statut: dossier.statut });
    } else if (compl) {
      dossier = compl; maj = true; var avant = dossier.statut; Object.keys(champs).forEach(function (k) { dossier[k] = champs[k]; });
      dossier.statut = 'recu'; dossier.depose_le = now(); dossier.updated_at = now();
      history(dossier.id, 'complement_recu', { statut: avant }, { statut: 'recu' });
    } else {
      dossier = { id: 'TFLD-' + rid(), numero: nextNumero(dos), etudiant_id: e.id, encadreur_id: '', statut: 'recu', etape: 1, progression: 0,
                  motif_decision: '', depose_le: now(), decide_le: '', sujet_statut: 'a_etudier', validation_exb: false, validation_univ: 'non_demandee',
                  observation_encadreur: '', source: 'FORMULAIRE_HORS_CONNEXION', ref: cut(o.ref, 40), created_at: now(), updated_at: now() };
      Object.keys(champs).forEach(function (k) { dossier[k] = champs[k]; });
      dos.push(dossier); history(dossier.id, 'creation', null, { statut: 'recu', numero: dossier.numero });
    }
    if (!put(K.etu, etus) || !put(K.dos, dos)) throw new Error('enregistrement local refusé (espace plein ?) : exportez une sauvegarde puis libérez de l’espace.');
    if (o.submitted_at) { done.push(sig); put(K.done, done.slice(-800)); }
    /* V99zzzzzzzzzzzzzz — matricule AUTOMATIQUE dès la réception : celui donné par le serveur à la soumission, sinon un nouveau numéro unique. */
    var matAuto = false, conflit = '';
    if (!e.matricule) {
      var mo = cut(d.matricule_en_ligne, 40), u0 = usedMatricules();
      if (mo && !u0[mo]) {
        var etus2 = L.etu(), e2 = etus2.filter(function (x) { return x.id === e.id; })[0];
        if (e2) { e2.matricule = mo; put(K.etu, etus2); e.matricule = mo; matAuto = true; L.dos().filter(function (x) { return x.etudiant_id === e.id; }).forEach(function (x) { history(x.id, 'matricule', { matricule: '' }, { matricule: mo }); }); trace('TFL_MATRICULE', e.nom + ' → ' + mo + ' (attribué à la soumission)'); }
      } else { if (mo) conflit = mo; var rm = attribuerMatricule(e.id); e.matricule = rm.matricule; matAuto = true; }
    }
    if (o.ref) { var pr = get(K.prep, []); pr.forEach(function (p) { if (p.ref === o.ref) { p.retour = now(); p.numero = dossier.numero; } }); put(K.prep, pr); }
    var lien = dossier.sujet_ref ? sujetLierDossier(dossier) : null;
    trace('TFL_IMPORT', dossier.numero + ' — ' + nom);
    return { dup: false, nom: nom, numero: dossier.numero, dossier: dossier, etudiant: e, nouvelEtu: nouvelEtu, maj: maj, sujet: lien, matricule: e.matricule || '', matriculeAuto: matAuto, conflit: conflit };
  }

  /* ---------- MATRICULE ---------- */
  function attribuerMatricule(etuId, force) {
    var etus = L.etu(), e = etus.filter(function (x) { return x.id === etuId; })[0];
    if (!e) throw new Error('étudiant introuvable.');
    if (e.matricule && !force) return { matricule: e.matricule, deja: true };
    var p = matriculeConnu(e), m = p ? String(p.matricule).trim() : '';
    if (!m) m = newMatricule();
    var avant = e.matricule || ''; e.matricule = m;
    put(K.etu, etus);
    L.dos().filter(function (x) { return x.etudiant_id === e.id; }).forEach(function (x) { history(x.id, 'matricule', { matricule: avant }, { matricule: m }); });
    trace('TFL_MATRICULE', e.nom + ' → ' + m);
    return { matricule: m, deja: false, repris: !!p };
  }
  function fixerMatricule(etuId, valeur) {
    var m = cut(valeur, 40); if (!m) throw new Error('matricule vide.');
    var etus = L.etu(), e = etus.filter(function (x) { return x.id === etuId; })[0];
    if (!e) throw new Error('étudiant introuvable.');
    var u = usedMatricules(); if (u[m] && e.matricule !== m) {
      var p = matriculeConnu(e); if (!(p && String(p.matricule).trim() === m)) throw new Error('ce matricule est déjà utilisé par quelqu’un d’autre.');
    }
    e.matricule = m; put(K.etu, etus); trace('TFL_MATRICULE_MANUEL', e.nom + ' → ' + m); return m;
  }

  /* ---------- DÉCISIONS ---------- */
  function avancer(d, n) { if ((d.etape || 1) < n) d.etape = n; }
  function setStatut(dosId, statut, motif) {
    if (!STATUTS.some(function (x) { return x[0] === statut; })) throw new Error('statut inconnu.');
    var dos = L.dos(), d = dos.filter(function (x) { return x.id === dosId; })[0]; if (!d) throw new Error('dossier introuvable.');
    if ((statut === 'refuse' || statut === 'complement_demande') && !cut(motif, 2000)) throw new Error('indiquez le motif (il sera communiqué à l’étudiant).');
    var avant = d.statut, mat = null;
    d.statut = statut; if (motif != null && cut(motif, 2000)) d.motif_decision = cut(motif, 2000);
    if (statut === 'accepte' || statut === 'refuse' || statut === 'complement_demande') d.decide_le = now();
    if (statut === 'accepte') { d.sujet_statut = d.sujet_statut === 'a_etudier' ? 'accepte' : d.sujet_statut; d.validation_exb = true; }
    if (statut === 'en_verification') avancer(d, 2); if (statut === 'refuse' || statut === 'complement_demande') avancer(d, 3); if (statut === 'accepte') avancer(d, 4); if (statut === 'clos') d.etape = 9;
    d.updated_at = now(); put(K.dos, dos);
    history(d.id, 'statut', { statut: avant }, { statut: statut, motif: d.motif_decision });
    if (statut === 'accepte') { var e = L.etu().filter(function (x) { return x.id === d.etudiant_id; })[0]; if (e && !e.matricule) mat = attribuerMatricule(e.id); }
    if (d.sujet_ref) sujetSelonDecision(d, statut);
    trace('TFL_STATUT', d.numero + ' : ' + avant + ' → ' + statut); planifierStatuts();
    return { dossier: d, matricule: mat };
  }
  function affecter(dosId, encId) {
    var dos = L.dos(), d = dos.filter(function (x) { return x.id === dosId; })[0]; if (!d) throw new Error('dossier introuvable.');
    if (!encId) { var av = d.encadreur_id; d.encadreur_id = ''; d.updated_at = now(); put(K.dos, dos); history(d.id, 'affectation', { encadreur: av }, { encadreur: '' }); return d; }
    if (d.statut !== 'accepte' && d.statut !== 'en_verification') throw new Error('le dossier doit être « En vérification » (pour demander l’avis de l’encadreur) ou accepté.');
    var enc = L.enc().filter(function (x) { return x.id === encId; })[0]; if (!enc) throw new Error('encadreur introuvable.');
    if (enc.disponible === false) throw new Error('cet encadreur est marqué indisponible.');
    if (enc.valide === false) throw new Error('cet encadreur s’est inscrit par formulaire : validez-le d’abord (TFL › Encadreurs › Formulaire).');
    var n = dos.filter(function (x) { return x.encadreur_id === encId && x.statut === 'accepte' && x.id !== d.id; }).length;
    if (n >= Number(enc.max_etudiants || 8)) throw new Error('cet encadreur a atteint sa charge maximale (' + (enc.max_etudiants || 8) + ').');
    var avant = d.encadreur_id; d.encadreur_id = encId; if (d.statut === 'accepte') avancer(d, 5); d.updated_at = now(); put(K.dos, dos);
    history(d.id, 'affectation', { encadreur: avant }, { encadreur: encId }); trace('TFL_AFFECTATION', d.numero + ' → ' + enc.nom); return d;
  }
  function basculerEncadreur(id) { var a = L.enc(), e = a.filter(function (x) { return x.id === id; })[0]; if (!e) return; e.disponible = e.disponible === false; put(K.enc, a); return e.disponible; }
  function patchDossier(dosId, patch) {
    var dos = L.dos(), d = dos.filter(function (x) { return x.id === dosId; })[0]; if (!d) return;
    var avant = { sujet: d.sujet_statut, exb: d.validation_exb, univ: d.validation_univ };
    Object.keys(patch).forEach(function (k) { d[k] = patch[k]; });
    if (d.etape < 1) d.etape = 1; if (d.etape > 9) d.etape = 9; if (d.progression < 0) d.progression = 0; if (d.progression > 100) d.progression = 100;
    d.updated_at = now(); put(K.dos, dos);
    if ('sujet_statut' in patch || 'validation_exb' in patch || 'validation_univ' in patch) history(d.id, 'validation_sujet', avant, { sujet: d.sujet_statut, exb: d.validation_exb, univ: d.validation_univ });
  }
  function ajouterEncadreur(o) {
    var nom = cut(o.nom, 120); if (!nom) throw new Error('nom de l’encadreur manquant.');
    var a = L.enc(); a.push({ id: 'TFLC-' + rid(), nom: nom, email: cut(o.email, 120), telephone: cut(o.telephone, 40), domaines: (o.domaines || []).filter(function (x) { return DOMAINES.some(function (y) { return y[0] === x; }); }), specialites: cut(o.specialites, 200), disponible: true, max_etudiants: Math.max(1, parseInt(o.max_etudiants, 10) || 8), actif: true, created_at: now() });
    put(K.enc, a); return a[a.length - 1];
  }

  /* ---------- PORTAILS étudiant / encadreur avec connexion (V99zzt) ----------
   * Le serveur ne garde qu'un instantané publié (ce que la personne peut voir) et sa boîte de messages ; les dossiers restent ici.
   * Étudiant : identifiant = matricule. Encadreur : identifiant = son matricule (accès ouvert dès qu'il est validé). Mot de passe de départ à 6 chiffres, changé à la 1re connexion. */
  var KC = 'exb_tfl_codes'; /* mots de passe de départ : cet appareil seulement, absents des sauvegardes */
  function normId(v) { return String(v || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase(); }
  function genCode() { var n; try { var a = new Uint32Array(1); root.crypto.getRandomValues(a); n = a[0] % 1000000; } catch (e) { n = Math.floor(Math.random() * 1000000); } return ('000000' + n).slice(-6); }
  var HISTO = { creation: 'Dossier créé', complement_recu: 'Complément reçu', matricule: 'Matricule attribué', affectation: 'Encadreur affecté ou changé', validation_sujet: 'Validation du sujet mise à jour', progression_encadreur: 'Progression mise à jour' };
  function libelleHisto(h) {
    if (h.action === 'statut') return 'Statut : ' + LBL(STATUTS, (h.apres || {}).statut);
    return HISTO[h.action] || h.action;
  }
  function msgsLocaux() { return get(K.msg, []); }
  function ajouterMessage(m) { var a = msgsLocaux(); a.push(m); put(K.msg, a.slice(-1500)); return m; }
  /* message de l'administration visible dans un portail : pour = etudiant | encadreur | tous */
  function messageAdmin(numero, pour, texte) {
    var d = L.dos().filter(function (x) { return x.numero === numero; })[0]; if (!d) throw new Error('dossier introuvable.');
    var t = cut(texte, 1500); if (t.length < 2) throw new Error('écrivez le message.');
    pour = ['etudiant', 'encadreur', 'tous'].indexOf(pour) >= 0 ? pour : 'tous';
    var m = ajouterMessage({ id: 'TFLM-' + rid(), at: now(), de: 'admin', pour: pour, dossier: numero, type: 'message', texte: t, lu: true });
    history(d.id, 'message_portail', null, { pour: pour }); return m;
  }
  function msgAdminPour(numero, qui) {
    return msgsLocaux().filter(function (m) { return m.de === 'admin' && m.dossier === numero && (m.pour === 'tous' || m.pour === qui); })
      .map(function (m) { return { at: m.at, texte: m.texte, dossier: m.dossier }; });
  }
  function snapEtudiant(d) {
    var e = L.etu().filter(function (x) { return x.id === d.etudiant_id; })[0] || {}, enc = L.enc().filter(function (x) { return x.id === d.encadreur_id; })[0] || null;
    var H = get(K.his, []).filter(function (h) { return h.dossier_id === d.id && h.action !== 'message_portail'; }).slice(0, 15);
    return { nom: e.nom || '', matricule: e.matricule || '', numero: d.numero, domaine: LBL(DOMAINES, d.domaine), statut: d.statut, statut_label: LBL(STATUTS, d.statut),
      etape: d.etape || 1, etape_label: LBL(ETAPES, d.etape || 1), progression: d.progression || 0, sujet_titre: d.sujet_titre || '', motif_decision: d.motif_decision || '',
      sujet_label: LBL(SUJET, d.sujet_statut), univ_label: LBL(UNIV, d.validation_univ), validation_label: valLabel(d.validation_encadreur), validation_code: d.validation_encadreur || '',
      encadreur: enc && d.statut === 'accepte' ? { nom: enc.nom, telephone: enc.telephone || '' } : null,
      historique: H.map(function (h) { return { at: h.at, label: libelleHisto(h) }; }), messages_admin: msgAdminPour(d.numero, 'etudiant'), maj: now() };
  }
  function snapEncadreur(enc) {
    var etus = L.etu(), D = L.dos().filter(function (d) { return d.encadreur_id === enc.id && (d.statut === 'accepte' || d.statut === 'en_verification'); });
    var props = sujets().filter(function (s) { return s.encadreur_id === enc.id && s.source === 'encadreur'; }).map(function (s) { return { ref: s.ref, titre: s.titre, label: LBL(PROP, s.proposition || 'recu'), statut: s.proposition || 'recu', motif: s.motif_proposition || '' }; });
    return { nom: enc.nom, max_etudiants: enc.max_etudiants || 8, maj: now(), matricule: enc.matricule || '', propositions: props,
      dossiers: D.map(function (d) { var e = etus.filter(function (x) { return x.id === d.etudiant_id; })[0] || {};
        return { numero: d.numero, etudiant: e.nom || '', matricule: e.matricule || '', telephone: e.telephone || '', universite: e.universite || '', domaine: LBL(DOMAINES, d.domaine),
                 sujet_titre: d.sujet_titre || '', problematique: d.problematique || '', objectifs: d.objectifs || '', methodologie: d.methodologie || '',
                 etape: d.etape || 1, etape_label: LBL(ETAPES, d.etape || 1), progression: d.progression || 0, avis: d.statut === 'en_verification', validation_label: valLabel(d.validation_encadreur), validation_code: d.validation_encadreur || '' }; }),
      messages_admin: D.reduce(function (acc, d) { return acc.concat(msgAdminPour(d.numero, 'encadreur')); }, []) };
  }
  /* V99… : l'identifiant de connexion d'un encadreur est son MATRICULE (attribué ici s'il n'en a pas encore). Un ancien code ENC-xxxx est remplacé :
     l'ancien accès est désactivé à la prochaine publication (voir « identifiant changé »). */
  function encIdent(enc) {
    var all0 = L.enc(), cur0 = all0.filter(function (x) { return x.id === enc.id; })[0] || enc;
    if (!cur0.matricule) { cur0.matricule = newMatricule(); cur0.matricule_le = now(); }
    if (cur0.portail_id !== cur0.matricule) { cur0.portail_id = cur0.matricule; if (all0.indexOf(cur0) >= 0) put(K.enc, all0); }
    enc.matricule = cur0.matricule; enc.portail_id = cur0.matricule;
    return cur0.matricule;
  }
  function encIdentAncien(enc) { /* code ENC-xxxx unique (ancien mode, conservé pour mémoire) */
    if (enc.portail_id) return enc.portail_id;
    var all = L.enc(), used = {}; all.forEach(function (x) { if (x.portail_id) used[normId(x.portail_id)] = 1; });
    var id; do { id = 'ENC-' + ('0000' + Math.floor(Math.random() * 10000)).slice(-4); } while (used[normId(id)]);
    var cur = all.filter(function (x) { return x.id === enc.id; })[0]; if (cur) { cur.portail_id = id; put(K.enc, all); }
    enc.portail_id = id; return id;
  }
  /* Ce qui doit exister sur le serveur : un accès par étudiant accepté AYANT un matricule, un par encadreur ayant des dossiers acceptés (ou déjà ouvert). */
  function accesAPublier() {
    var etus = L.etu(), out = [], sans = [];
    L.dos().forEach(function (d) {
      if (d.statut !== 'accepte' && d.statut !== 'clos') return;
      var e = etus.filter(function (x) { return x.id === d.etudiant_id; })[0]; if (!e) return;
      if (!e.matricule) { sans.push(e.nom || d.numero); return; }
      out.push({ role: 'etudiant', ref: e.id, ident: e.matricule, nom: e.nom || '', contenu: snapEtudiant(d), tel: e.telephone || '' });
    });
    var enc0 = L.enc(), D = L.dos();
    enc0.forEach(function (x) {
      if (x.actif === false) return;
      var n = D.filter(function (d) { return d.encadreur_id === x.id && (d.statut === 'accepte' || d.statut === 'en_verification'); }).length;
      /* accès ouvert dès que l'encadreur est validé (ou a déjà un accès / des dossiers) : plus besoin d'attendre une affectation */
      var valide = x.matricule && x.valide !== false;
      if (x.valide === false) return;
      if (!n && !x.portail_id && !valide) return;
      out.push({ role: 'encadreur', ref: x.id, ident: encIdent(x), nom: x.nom, contenu: snapEncadreur(L.enc().filter(function (y) { return y.id === x.id; })[0] || x), tel: x.telephone || '' });
    });
    return { acces: out, sans_matricule: sans };
  }
  function cleAcces(role, ident) { return role + ':' + normId(ident); }
  /* Applique les messages reçus du serveur (liste tfl_portail_retours). Renvoie les identifiants à marquer « traités ». */
  function appliquerRetours(rows) {
    var dos = L.dos(), etus = L.etu(), encs = L.enc(), msgs = msgsLocaux(), vus = {}, res = { recus: 0, refuses: 0, dup: 0, ids: [] };
    msgs.forEach(function (m) { if (m.remote_id) vus[m.remote_id] = 1; });
    (rows || []).forEach(function (r) {
      res.ids.push(r.id);
      if (vus[r.id]) { res.dup++; return; }
      var d = dos.filter(function (x) { return x.numero === r.dossier; })[0], ok = false;
      if (d && r.role === 'etudiant') { var e = etus.filter(function (x) { return x.id === d.etudiant_id; })[0]; ok = !!(e && e.matricule && normId(e.matricule) === normId(r.identifiant)); }
      if (d && r.role === 'encadreur') { var c = encs.filter(function (x) { return x.id === d.encadreur_id; })[0]; ok = !!(c && (d.statut === 'accepte' || d.statut === 'en_verification') && ((c.matricule && normId(c.matricule) === normId(r.identifiant)) || (c.portail_id && normId(c.portail_id) === normId(r.identifiant)))); }
      var type = ['message', 'commentaire', 'progression', 'validation'].indexOf(r.type) >= 0 ? r.type : 'message';
      if (r.role === 'etudiant') type = 'message';
      if (!ok) { res.refuses++; return; }
      var v = type === 'progression' ? Math.max(0, Math.min(100, parseInt(r.valeur, 10) || 0)) : (type === 'validation' ? Math.max(1, Math.min(3, parseInt(r.valeur, 10) || 2)) : null);
      msgs.push({ id: 'TFLM-' + rid(), remote_id: r.id, at: r.cree_le || now(), de: r.role, de_nom: cut(r.nom, 120), dossier: r.dossier, type: type, texte: cut(r.texte, 1500), valeur: v, lu: false, appliquee: false });
      vus[r.id] = 1; res.recus++;
    });
    if (!put(K.msg, msgs.slice(-1500))) throw new Error('enregistrement local refusé (espace plein ?) : exportez une sauvegarde puis libérez de l’espace.');
    return res;
  }
  /* Progression proposée par l'encadreur : appliquée seulement quand l'administration le décide. */
  function appliquerProgression(msgId) {
    var msgs = msgsLocaux(), m = msgs.filter(function (x) { return x.id === msgId; })[0]; if (!m || m.type !== 'progression') throw new Error('proposition introuvable.');
    var d = L.dos().filter(function (x) { return x.numero === m.dossier; })[0]; if (!d) throw new Error('dossier introuvable.');
    var avant = d.progression || 0; patchDossier(d.id, { progression: m.valeur });
    history(d.id, 'progression_encadreur', { progression: avant }, { progression: m.valeur });
    m.appliquee = true; m.lu = true; put(K.msg, msgs); return d;
  }
  function marquerLus(numero) {
    var msgs = msgsLocaux(), ch = false; msgs.forEach(function (m) { if (m.dossier === numero && m.de !== 'admin' && !m.lu) { m.lu = true; ch = true; } });
    if (ch) put(K.msg, msgs);
  }
  function nonLus() { return msgsLocaux().filter(function (m) { return m.de !== 'admin' && !m.lu; }).length; }


  /* ---------- BIBLIOTHÈQUE (V99zzu) : TFL résolus gardés + sujets reçus de ceux qui veulent être encadrés ---------- */
  /* Fiches (métadonnées) : clé exb_tfl_biblio, incluse dans la sauvegarde. Fichiers (PDF, Word, etc.) : IndexedDB de cet appareil
     (base « exb_tfl_biblio »), PAS dans la sauvegarde JSON. Pour les tests : root.EXBTFL_FILES = {} remplace IndexedDB. */
  var BTYPES = [['tfl', 'TFL résolu'], ['sujet', 'Sujet reçu']];
  var BEXT = ['pdf', 'doc', 'docx', 'odt', 'rtf', 'txt', 'ppt', 'pptx', 'xls', 'xlsx', 'csv', 'zip', 'jpg', 'jpeg', 'png'];
  var BMAX = 25 * 1024 * 1024;
  function bext(n) { var m = /\.([A-Za-z0-9]{1,6})$/.exec(String(n || '')); return m ? m[1].toLowerCase() : ''; }
  function bbase(n) { return String(n || '').replace(/\.[A-Za-z0-9]{1,6}$/, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function bidb() {
    return new Promise(function (ok, ko) {
      try {
        var r = root.indexedDB.open('exb_tfl_biblio', 1);
        r.onupgradeneeded = function () { r.result.createObjectStore('f'); };
        r.onsuccess = function () { ok(r.result); };
        r.onerror = function () { ko(r.error || new Error('stockage des fichiers indisponible sur cet appareil.')); };
      } catch (e) { ko(new Error('stockage des fichiers indisponible sur cet appareil.')); }
    });
  }
  function bop(mode, id, blob) {
    if (root.EXBTFL_FILES) {
      if (mode === 'put') root.EXBTFL_FILES[id] = blob; else if (mode === 'del') delete root.EXBTFL_FILES[id];
      return Promise.resolve(mode === 'get' ? root.EXBTFL_FILES[id] : undefined);
    }
    return bidb().then(function (db) {
      return new Promise(function (ok, ko) {
        var t = db.transaction('f', mode === 'get' ? 'readonly' : 'readwrite'), st = t.objectStore('f'), rq = mode === 'put' ? st.put(blob, id) : mode === 'del' ? st.delete(id) : st.get(id);
        t.oncomplete = function () { db.close(); ok(mode === 'get' ? rq.result : undefined); };
        t.onerror = t.onabort = function () { db.close(); ko(t.error || new Error('enregistrement du fichier refusé (espace plein ?).')); };
      });
    });
  }
  function biblio() { return get(K.bib, []); }
  function bverifFichier(f) {
    if (!f) return;
    var e = bext(f.name), n = f.size || 0;
    if (BEXT.indexOf(e) < 0) throw new Error('« ' + f.name + ' » : format non accepté (' + BEXT.join(', ') + ').');
    if (!n) throw new Error('« ' + f.name + ' » : fichier vide.');
    if (n > BMAX) throw new Error('« ' + f.name + ' » : fichier trop lourd (25 Mo maximum).');
  }
  function bAnnee(v) { var n = parseInt(v, 10); return (n >= 1950 && n <= new Date().getFullYear() + 1) ? String(n) : ''; }
  async function bibAjouter(o, f) {
    o = o || {}; var type = BTYPES.some(function (x) { return x[0] === o.type; }) ? o.type : '';
    if (!type) throw new Error('type inconnu (TFL résolu ou sujet reçu).');
    bverifFichier(f);
    var titre = cut(o.titre, 250); if (titre.length < 3 && f) titre = cut(bbase(f.name), 250);
    if (titre.length < 3) throw new Error('indiquez un titre, ou choisissez un fichier.');
    var auteur = cut(o.auteur, 120);
    if (type === 'sujet' && auteur.length < 2) throw new Error('indiquez le nom de la personne qui envoie le sujet.');
    var all = biblio();
    if (f && all.some(function (x) { return x.type === type && x.fichier_nom === f.name && x.fichier_taille === f.size; })) return { dup: true, titre: titre };
    var domaine = DOMAINES.some(function (x) { return x[0] === o.domaine; }) ? o.domaine : 'autre';
    var en = { id: 'TFLB-' + rid(), type: type, titre: titre, auteur: auteur, annee: bAnnee(o.annee), universite: cut(o.universite, 150), domaine: domaine,
               encadreur: cut(o.encadreur, 120), mots_cles: cut(o.mots_cles, 200), resume: cut(o.resume, 2000), telephone: cut(o.telephone, 40),
               statut: type === 'sujet' ? 'a_etudier' : '', consultation: type === 'tfl' ? ((o.consultation === 'oui' || o.consultation === true) ? 'oui' : 'non') : '', dossier_numero: cut(o.dossier_numero, 30), source: o.source === 'dossier' ? 'dossier' : 'import',
               fichier_nom: f ? cut(f.name, 200) : '', fichier_type: f ? bext(f.name) : '', fichier_taille: f ? f.size : 0, created_at: now() };
    if (f) await bop('put', en.id, f);
    all.push(en);
    if (!put(K.bib, all)) { if (f) { try { await bop('del', en.id); } catch (e) { /* ignoré */ } } throw new Error('enregistrement local refusé (espace plein ?) : exportez une sauvegarde puis libérez de l’espace.'); }
    trace('TFL_BIBLIO_AJOUT', en.id + ' — ' + titre);
    return { dup: false, entree: en };
  }
  var BCHAMPS = ['titre', 'auteur', 'annee', 'universite', 'domaine', 'encadreur', 'mots_cles', 'resume', 'telephone', 'consultation'];
  var BMENTION = 'Référence méthodologique, pas un travail à recopier.';
  function bibModifier(id, patch) {
    var all = biblio(), e = all.filter(function (x) { return x.id === id; })[0]; if (!e) throw new Error('fiche introuvable.');
    BCHAMPS.forEach(function (k) {
      if (patch[k] === undefined) return;
      if (k === 'consultation') e.consultation = (patch[k] === 'oui' || patch[k] === true) ? 'oui' : 'non'; else if (k === 'annee') e.annee = bAnnee(patch[k]); else if (k === 'domaine') e.domaine = DOMAINES.some(function (x) { return x[0] === patch[k]; }) ? patch[k] : e.domaine;
      else e[k] = cut(patch[k], k === 'resume' ? 2000 : k === 'titre' ? 250 : 200);
    });
    if (e.titre.length < 3) throw new Error('le titre doit avoir au moins 3 caractères.');
    put(K.bib, all); return e;
  }
  function bibStatut(id, statut) {
    var all = biblio(), e = all.filter(function (x) { return x.id === id; })[0]; if (!e) throw new Error('fiche introuvable.');
    if (e.type !== 'sujet') throw new Error('le statut ne concerne que les sujets reçus.');
    if (!SUJET.some(function (x) { return x[0] === statut; })) throw new Error('statut inconnu.');
    e.statut = statut; e.statut_le = now(); put(K.bib, all); return e;
  }
  async function bibSupprimer(id) {
    var all = biblio(), e = all.filter(function (x) { return x.id === id; })[0]; if (!e) throw new Error('fiche introuvable.');
    if (e.fichier_nom) { try { await bop('del', id); } catch (x) { /* le fichier n'existe peut-être plus */ } }
    put(K.bib, all.filter(function (x) { return x.id !== id; })); trace('TFL_BIBLIO_SUPPR', id); return true;
  }
  async function bibFichier(id) {
    var e = biblio().filter(function (x) { return x.id === id; })[0]; if (!e || !e.fichier_nom) throw new Error('cette fiche n’a pas de fichier.');
    var b = await bop('get', id);
    if (!b) throw new Error('fichier absent de cet appareil (la sauvegarde JSON ne contient pas les fichiers) : importez-le de nouveau.');
    return b;
  }
  /* Un dossier terminé (clos ou étape 9) est gardé dans la bibliothèque comme TFL résolu (fiche seule : le document se joint ensuite). */
  function bibDepuisDossier(dosId) {
    var d = L.dos().filter(function (x) { return x.id === dosId; })[0]; if (!d) throw new Error('dossier introuvable.');
    if (d.statut !== 'clos' && (d.etape || 1) < 9) throw new Error('seul un dossier terminé (statut Clos ou étape 9) peut être gardé dans la bibliothèque.');
    if (biblio().some(function (x) { return x.type === 'tfl' && x.dossier_numero === d.numero; })) throw new Error('ce dossier est déjà dans la bibliothèque.');
    var e = L.etu().filter(function (x) { return x.id === d.etudiant_id; })[0] || {}, enc = L.enc().filter(function (x) { return x.id === d.encadreur_id; })[0];
    var all = biblio(), en = { id: 'TFLB-' + rid(), type: 'tfl', titre: cut(d.sujet_titre, 250), auteur: cut(e.nom, 120), annee: bAnnee((d.decide_le || d.updated_at || now()).slice(0, 4)), universite: cut(e.universite, 150),
      domaine: d.domaine || 'autre', encadreur: enc ? cut(enc.nom, 120) : '', mots_cles: '', resume: cut(d.problematique, 2000), telephone: '', statut: '', consultation: 'non', dossier_numero: d.numero, source: 'dossier',
      fichier_nom: '', fichier_type: '', fichier_taille: 0, created_at: now() };
    all.push(en); put(K.bib, all); trace('TFL_BIBLIO_DOSSIER', d.numero); return en;
  }
  /* Un sujet reçu en document devient un dossier de candidature (étape 1) : il faut le téléphone ; problématique et objectifs restent « à compléter ». */
  function bibVersDossier(id) {
    var all = biblio(), en = all.filter(function (x) { return x.id === id; })[0]; if (!en) throw new Error('fiche introuvable.');
    if (en.type !== 'sujet') throw new Error('seul un sujet reçu peut devenir un dossier de candidature.');
    if (en.dossier_numero) throw new Error('ce sujet a déjà un dossier : ' + en.dossier_numero + '.');
    if (!en.auteur || !digits(en.telephone)) throw new Error('renseignez le nom et le téléphone (modifier la fiche) avant de créer le dossier.');
    var att = en.fichier_nom ? ' — voir le document « ' + en.fichier_nom + ' » de la bibliothèque' : '';
    var r = importer({ form: 'EXB_TFL', version: 1, submitted_at: en.created_at, ref: 'BIB-' + en.id, d: { nom: en.auteur, telephone: en.telephone, universite: en.universite, domaine: en.domaine,
      sujet_titre: en.titre, problematique: en.resume || ('À compléter' + att), objectifs: 'À compléter' + att } });
    if (r.dup) throw new Error('un dossier existe déjà pour ce sujet.');
    en.dossier_numero = r.numero; put(K.bib, all); return r;
  }
  async function bibJoindre(id, f) {
    var all = biblio(), e = all.filter(function (x) { return x.id === id; })[0]; if (!e) throw new Error('fiche introuvable.');
    if (!f) throw new Error('aucun fichier choisi.');
    if (e.fichier_nom) throw new Error('cette fiche a déjà un fichier : supprimez-la puis réimportez le document.');
    bverifFichier(f); await bop('put', id, f);
    e.fichier_nom = cut(f.name, 200); e.fichier_type = bext(f.name); e.fichier_taille = f.size;
    if (!put(K.bib, all)) { try { await bop('del', id); } catch (x) { /* ignoré */ } throw new Error('enregistrement local refusé (espace plein ?).'); }
    return e;
  }
  function bibChercher(q, type, domaine) {
    var n = norm(q);
    return biblio().filter(function (x) {
      if (type && x.type !== type) return false; if (domaine && domaine !== 'tous' && x.domaine !== domaine) return false;
      return !n || norm([x.titre, x.auteur, x.annee, x.universite, x.encadreur, x.mots_cles, x.resume, x.fichier_nom, x.dossier_numero].join(' ')).indexOf(n) >= 0;
    }).sort(function (a, b) { return String(b.created_at).localeCompare(String(a.created_at)); });
  }
  function bibCsv() {
    var c = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var cols = [['type', 'Type'], ['titre', 'Titre'], ['auteur', 'Auteur'], ['annee', 'Année'], ['universite', 'Université'], ['domaine', 'Domaine'], ['encadreur', 'Encadreur'], ['mots_cles', 'Mots-clés'], ['statut', 'Statut du sujet'], ['consultation', 'Consultation autorisée'], ['dossier_numero', 'Dossier'], ['fichier_nom', 'Fichier']];
    return '\ufeff' + cols.map(function (k) { return c(k[1]); }).join(';') + '\r\n' + biblio().map(function (x) {
      return cols.map(function (k) { var v = x[k[0]]; if (k[0] === 'type') v = LBL(BTYPES, v); else if (k[0] === 'domaine') v = LBL(DOMAINES, v); else if (k[0] === 'statut') v = x.type === 'sujet' ? LBL(SUJET, v) : ''; else if (k[0] === 'consultation') v = x.type === 'tfl' ? (v === 'oui' ? 'Oui' : 'Non') : ''; return c(v); }).join(';');
    }).join('\r\n');
  }


  /* ---------- CATALOGUE DES SUJETS (V99zzv) ---------- */
  /* Fiches publiées par l'administrateur : référence EXB-TFL-BTP-0001, intitulé, catégorie, filière, problématique, objectifs, méthodologie,
     livrables, compétences, encadrement, disponibilité. Clé locale exb_tfl_sujets (incluse dans la sauvegarde). La page publique
     tfl-sujets.html lit la copie publiée sur le serveur (migration-v99zzv-tfl-sujets.sql) ou, sans serveur, le fichier tfl-sujets.json. */
  var CATS = [['structures', 'Structures et béton armé'], ['voirie', 'Routes et voirie'], ['hydraulique', 'Hydraulique et assainissement'], ['geotechnique', 'Géotechnique et fondations'],
              ['architecture', 'Architecture et conception'], ['gestion', 'Gestion de projet et de chantier'], ['materiaux', 'Matériaux de construction'], ['numerique', 'BIM et outils numériques'],
              ['agriculture', 'Génie rural et agriculture'], ['topographie', 'Topographie et géomatique'], ['electricite', 'Électricité et énergie'], ['mecanique', 'Mécanique et équipements'],
              ['informatique', 'Informatique et systèmes d’information'], ['hse', 'Hygiène, sécurité, environnement et qualité'], ['durabilite', 'Développement durable et autres secteurs'], ['autre', 'Autre']];
  var DISPO = [['disponible', 'Disponible'], ['reserve', 'Réservé'], ['attribue', 'Attribué'], ['ferme', 'Fermé']];
  var SCHAMPS = ['titre', 'categorie', 'domaine', 'filiere', 'niveau', 'problematique', 'objectifs', 'methodologie', 'livrables', 'competences', 'encadrement', 'mots_cles'];
  var SMAX = { titre: 250, categorie: 80, domaine: 40, filiere: 100, niveau: 60, problematique: 3000, objectifs: 3000, methodologie: 3000, livrables: 2000, competences: 1000, encadrement: 1000, mots_cles: 200 };
  function sujets() { return get(K.suj, []); }
  function sujetDe(ref) { return sujets().filter(function (x) { return x.ref === ref; })[0] || null; }
  function sujetRefSuivante(all) {
    var n = 0; all.forEach(function (x) { var m = /^EXB-TFL-BTP-(\d{4,})$/.exec(x.ref || ''); if (m) n = Math.max(n, parseInt(m[1], 10)); });
    return 'EXB-TFL-BTP-' + ('0000' + (n + 1)).slice(-4);
  }
  function sujetNettoyer(o, e) {
    SCHAMPS.forEach(function (k) {
      if (o[k] === undefined) return;
      var v = cut(o[k], SMAX[k]);
      if (k === 'categorie') v = CATS.some(function (c) { return c[0] === v; }) ? v : (e[k] || 'autre');
      if (k === 'domaine') v = DOMAINES.some(function (c) { return c[0] === v; }) ? v : (e[k] || 'autre');
      e[k] = v;
    });
  }
  function sujetAjouter(o) {
    o = o || {}; var all = sujets(), e = { ref: '', titre: '', categorie: 'autre', domaine: 'genie_civil', filiere: '', niveau: '', problematique: '', objectifs: '', methodologie: '', livrables: '', competences: '', encadrement: '', mots_cles: '',
                                          publie: false, exclusif: o.exclusif !== false, statut: 'disponible', dossier_numero: '', push: false, serveur: false, created_at: now(), updated_at: now() };
    sujetNettoyer(o, e);
    if (e.titre.length < 3) throw new Error('indiquez l’intitulé du sujet (3 caractères au moins).');
    if (e.problematique.length < 3 || e.objectifs.length < 3) throw new Error('la problématique et les objectifs sont obligatoires : ils deviennent le contenu du dossier de l’étudiant.');
    var ref = cut(o.ref, 40);
    if (ref) { if (!/^[A-Za-z0-9._-]{3,40}$/.test(ref)) throw new Error('référence invalide (lettres, chiffres, point, tiret ; 3 à 40 caractères).'); if (all.some(function (x) { return x.ref === ref; })) throw new Error('la référence ' + ref + ' existe déjà.'); }
    e.ref = ref || sujetRefSuivante(all);
    all.push(e); if (!put(K.suj, all)) throw new Error('enregistrement local refusé (espace plein ?).');
    trace('TFL_SUJET_AJOUT', e.ref + ' — ' + e.titre); return e;
  }
  function sujetModifier(ref, patch) {
    var all = sujets(), e = all.filter(function (x) { return x.ref === ref; })[0]; if (!e) throw new Error('sujet introuvable.');
    sujetNettoyer(patch || {}, e);
    if (e.titre.length < 3) throw new Error('indiquez l’intitulé du sujet (3 caractères au moins).');
    if (e.problematique.length < 3 || e.objectifs.length < 3) throw new Error('la problématique et les objectifs sont obligatoires.');
    if (patch && patch.exclusif !== undefined) e.exclusif = !!patch.exclusif;
    e.updated_at = now(); put(K.suj, all); return e;
  }
  function sujetPublier(ref, oui) {
    var all = sujets(), e = all.filter(function (x) { return x.ref === ref; })[0]; if (!e) throw new Error('sujet introuvable.');
    if (oui && (e.titre.length < 3 || e.problematique.length < 3 || e.objectifs.length < 3)) throw new Error('fiche incomplète : impossible de publier.');
    e.publie = !!oui; e.updated_at = now(); put(K.suj, all); return e;
  }
  /* Publication ou retrait EN GROUPE : une seule écriture pour toutes les fiches. Les fiches incomplètes ne sont jamais publiées (elles sont listées). */
  function sujetsPublierLot(refs, oui) {
    var all = sujets(), want = {}, r = { ok: 0, deja: 0, incomplets: [], inconnus: 0 };
    (refs || []).forEach(function (x) { want[x] = 1; });
    all.forEach(function (e) {
      if (!want[e.ref]) return; delete want[e.ref];
      if (oui && (String(e.titre || '').length < 3 || String(e.problematique || '').length < 3 || String(e.objectifs || '').length < 3)) { r.incomplets.push(e.ref); return; }
      if (!!e.publie === !!oui) { r.deja++; return; }
      e.publie = !!oui; e.updated_at = now(); r.ok++;
    });
    r.inconnus = Object.keys(want).length;
    if (r.ok) {
      if (!put(K.suj, all)) throw new Error('enregistrement local refusé (espace du navigateur plein ?).');
      trace('TFL_SUJETS_LOT', (oui ? 'publiés ' : 'retirés ') + r.ok);
    }
    return r;
  }
  function fNorm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
  /* Mes fiches filtrées (plus récentes d'abord) : recherche, état de publication, catégorie. */
  function mesFichesFiltre(liste) {
    var S = (typeof ST !== 'undefined' && ST && ST.sj) || {}, q = fNorm(S.fq || '');
    return (liste || sujets()).slice().reverse().filter(function (x) {
      if (S.fp === 'non' && x.publie) return false;
      if (S.fp === 'oui' && !x.publie) return false;
      if (S.fc && S.fc !== 'tous' && x.categorie !== S.fc) return false;
      if (q && fNorm([x.ref, x.titre, x.filiere, x.niveau].join(' ')).indexOf(q) < 0) return false;
      return true;
    });
  }
  /* Décision de l'administrateur sur la disponibilité : libérer, attribuer, fermer. push = à envoyer au serveur à la prochaine synchronisation. */
  function sujetStatut(ref, statut, dossierNumero) {
    if (!DISPO.some(function (x) { return x[0] === statut; })) throw new Error('disponibilité inconnue.');
    var all = sujets(), e = all.filter(function (x) { return x.ref === ref; })[0]; if (!e) throw new Error('sujet introuvable.');
    e.statut = statut; e.push = true; e.updated_at = now();
    if (statut === 'disponible') e.dossier_numero = ''; else if (dossierNumero) e.dossier_numero = dossierNumero;
    put(K.suj, all); trace('TFL_SUJET_STATUT', ref + ' → ' + statut); return e;
  }
  function sujetSupprimer(ref) {
    var all = sujets(), e = all.filter(function (x) { return x.ref === ref; })[0]; if (!e) throw new Error('sujet introuvable.');
    if (e.dossier_numero && (e.statut === 'reserve' || e.statut === 'attribue')) throw new Error('ce sujet est lié au dossier ' + e.dossier_numero + ' : libérez-le d’abord (ou fermez-le).');
    put(K.suj, all.filter(function (x) { return x.ref !== ref; })); trace('TFL_SUJET_SUPPR', ref); return { retirerServeur: !!e.serveur };
  }
  /* Une candidature qui porte la référence d'un sujet (page publique ou fichier) : le sujet est réservé pour ce dossier s'il est exclusif et libre. */
  function sujetLierDossier(dossier) {
    var all = sujets(), e = all.filter(function (x) { return x.ref === dossier.sujet_ref; })[0]; if (!e) return { ref: dossier.sujet_ref, inconnu: true };
    var autre = e.exclusif && e.dossier_numero && e.dossier_numero !== dossier.numero && (e.statut === 'reserve' || e.statut === 'attribue');
    if (autre) { dossier.sujet_conflit = true; var dd = L.dos(); dd.forEach(function (x) { if (x.id === dossier.id) x.sujet_conflit = true; }); put(K.dos, dd); return { ref: e.ref, conflit: true, dossier_numero: e.dossier_numero }; }
    if (e.exclusif && e.statut === 'disponible') { e.statut = 'reserve'; e.dossier_numero = dossier.numero; e.updated_at = now(); put(K.suj, all); }
    else if (e.exclusif && e.statut === 'reserve' && !e.dossier_numero) { e.dossier_numero = dossier.numero; e.updated_at = now(); put(K.suj, all); }
    return { ref: e.ref, reserve: e.exclusif };
  }
  /* Décision sur le dossier : accepté → sujet attribué ; refusé → sujet de nouveau disponible pour les autres étudiants. */
  function sujetSelonDecision(d, statut) {
    var all = sujets(), e = all.filter(function (x) { return x.ref === d.sujet_ref; })[0]; if (!e || !e.exclusif || e.dossier_numero !== d.numero) return;
    if (statut === 'accepte') { e.statut = 'attribue'; e.push = true; }
    else if (statut === 'refuse') { e.statut = 'disponible'; e.dossier_numero = ''; e.push = true; }
    else return;
    e.updated_at = now(); put(K.suj, all);
  }
  /* Réservations vues par le serveur (tfl_sujets_etat) : un sujet réservé en ligne apparaît « Réservé » ici avant même l'import de la candidature. */
  function sujetsAppliquerEtat(rows) {
    var all = sujets(), n = 0;
    (rows || []).forEach(function (r) {
      var e = all.filter(function (x) { return x.ref === r.ref; })[0]; if (!e) return;
      if (e.push) return;
      if (r.statut === 'reserve' && e.statut === 'disponible') { e.statut = 'reserve'; n++; }
      else if (r.statut === 'disponible' && e.statut === 'reserve' && !e.dossier_numero) { e.statut = 'disponible'; n++; }
    });
    if (n) put(K.suj, all); return n;
  }
  function sujetsPourServeur() {
    return sujets().filter(function (e) { return e.publie || e.serveur; }).map(function (e) {
      var o = { ref: e.ref, publie: !!e.publie, exclusif: e.exclusif !== false, statut: e.statut, push_statut: !!e.push }; SCHAMPS.forEach(function (k) { o[k] = e[k] || ''; }); return o;
    });
  }
  /* Fichier pour la page publique sans serveur : à déposer à côté de tfl-sujets.html sous le nom tfl-sujets.json. */
  function sujetsJsonPublic() {
    return { form: 'EXB_TFL_SUJETS', version: 1, at: now(), sujets: sujets().filter(function (e) { return e.publie && e.statut !== 'ferme'; }).map(function (e) {
      var o = { ref: e.ref, exclusif: e.exclusif !== false, statut: e.statut }; SCHAMPS.forEach(function (k) { o[k] = e[k] || ''; }); return o; }) };
  }
  function sujetsCsv() {
    var c = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var cols = [['ref', 'Référence'], ['titre', 'Intitulé'], ['categorie', 'Catégorie'], ['filiere', 'Filière'], ['statut', 'Disponibilité'], ['publie', 'Publié'], ['exclusif', 'Exclusif'], ['dossier_numero', 'Dossier']];
    return '\ufeff' + cols.map(function (k) { return c(k[1]); }).join(';') + '\r\n' + sujets().map(function (x) {
      return cols.map(function (k) { var v = x[k[0]]; if (k[0] === 'categorie') v = LBL(CATS, v); else if (k[0] === 'statut') v = LBL(DISPO, v); else if (k[0] === 'publie' || k[0] === 'exclusif') v = v ? 'Oui' : 'Non'; return c(v); }).join(';'); }).join('\r\n');
  }

  /* ---------- BANQUE DE SUJETS (V99zzw) ---------- */
  /* 4 300 propositions (tfl-banque.json : 2 600 du catalogue général + 1 700 du catalogue BTP exécution). Ce sont des intitulés à contextualiser :
     la fiche (problématique, objectifs, méthodologie, livrables) est un modèle selon l'angle d'étude, identique à celui de
     supabase/migration-v99zzw-tfl-banque-sujets.sql. La banque reste hors de exb_tfl_sujets (limite de stockage du navigateur) : on « adopte » les
     sujets voulus, 300 au plus à la fois ; l'adoption copie la fiche dans vos sujets (non publiée). */
  var BQ = { data: null, items: null, comptes: [] }, BQ_URL = 'tfl-banque.json', BQ_PAGE = 25, BQ_LOT = 300;
  function banqueInit(j) {
    if (!j || j.form !== 'EXB_TFL_BANQUE' || !Array.isArray(j.sujets) || !Array.isArray(j.domaines) || !Array.isArray(j.angles)) throw new Error('fichier de banque invalide.');
    BQ.data = j; BQ.comptes = j.domaines.map(function () { return 0; });
    BQ.items = j.sujets.map(function (x) { var d = j.domaines[x[2]] || {}; BQ.comptes[x[2]]++; return { ref: x[0], titre: x[1], di: x[2], ai: x[3], n: norm(x[0] + ' ' + x[1] + ' ' + (d.nom || '')) }; });
  }
  function banqueCharger(obj) {
    if (obj) { banqueInit(obj); return Promise.resolve(BQ.data); }
    if (BQ.data) return Promise.resolve(BQ.data);
    if (typeof fetch !== 'function') return Promise.reject(new Error('chargement impossible dans cet environnement.'));
    return fetch(BQ_URL, { cache: 'no-cache' }).then(function (r) { if (!r.ok) throw new Error('fichier ' + BQ_URL + ' introuvable (code ' + r.status + ') : déposez-le à côté de index.html.'); return r.json(); }).then(function (j) { banqueInit(j); return BQ.data; });
  }
  function banqueFiche(it) {
    var d = BQ.data.domaines[it.di], a = BQ.data.angles[it.ai], theme = it.titre.split(' : ')[0];
    return { ref: it.ref, titre: it.titre, categorie: d.cat, filiere: d.nom, domaine: d.dom, niveau: 'À préciser',
             problematique: 'Sur le thème « ' + theme + ' » : comment ' + a.f + ' ?', objectifs: a.o, methodologie: a.m, livrables: a.l, competences: '',
             encadrement: 'À définir : fiche issue du catalogue, à contextualiser et à valider par un encadreur avant attribution.', mots_cles: '' };
  }
  /* Recherche : tous les mots (sans accents) dans la référence, le titre ou la filière ; dom = clé de domaine ; cat = catégorie. */
  function banqueChercher(o) {
    o = o || {}; if (!BQ.items) return [];
    var mots = norm(o.q).split(' ').filter(Boolean);
    return BQ.items.filter(function (it) {
      if (o.dom && BQ.data.domaines[it.di].k !== o.dom) return false;
      if (o.cat && BQ.data.domaines[it.di].cat !== o.cat) return false;
      for (var i = 0; i < mots.length; i++) if (it.n.indexOf(mots[i]) < 0) return false;
      return true;
    });
  }
  function banqueAdopter(refs) {
    if (!BQ.items) throw new Error('la banque n’est pas chargée.');
    refs = (refs || []).filter(function (r, i, a) { return a.indexOf(r) === i; });
    if (!refs.length) throw new Error('aucun sujet choisi.');
    if (refs.length > BQ_LOT) throw new Error('au plus ' + BQ_LOT + ' sujets à la fois.');
    var all = sujets(), have = {}, idx = {}, n = 0, deja = 0, t = now();
    all.forEach(function (x) { have[x.ref] = 1; }); BQ.items.forEach(function (it) { idx[it.ref] = it; });
    refs.forEach(function (r) {
      var it = idx[r]; if (!it) return; if (have[r]) { deja++; return; }
      var e = { ref: r, titre: '', categorie: 'autre', domaine: 'genie_civil', filiere: '', niveau: '', problematique: '', objectifs: '', methodologie: '', livrables: '', competences: '', encadrement: '', mots_cles: '',
                publie: false, exclusif: true, statut: 'disponible', dossier_numero: '', push: false, serveur: false, source: 'banque', created_at: t, updated_at: t };
      sujetNettoyer(banqueFiche(it), e); all.push(e); have[r] = 1; n++;
    });
    if (n && !put(K.suj, all)) throw new Error('enregistrement local refusé (espace du navigateur plein ?). Publiez ou supprimez des fiches, ou sauvegardez puis libérez de la place.');
    if (n) trace('TFL_SUJET_BANQUE', n + ' sujet(s) adopté(s) depuis la banque');
    return { ajoutes: n, deja: deja };
  }

  /* ---------- V99zzzzzzz : suivi du TFL — 06 chapitres et corrections, 07 rendez-vous et échéances, 08 défense, 09 tableau de bord ----------
     Tout reste dans le dossier (clés chapitres, rdv, defense de exb_tfl_dossiers) : inclus dans la sauvegarde JSON, aucun serveur nécessaire. */
  var CH_STAT = [['a_faire', 'À faire'], ['en_cours', 'En cours'], ['remis', 'Remis'], ['a_corriger', 'À corriger'], ['valide', 'Validé']];
  var CH_POIDS = { a_faire: 0, en_cours: 30, remis: 70, a_corriger: 50, valide: 100 };
  var PLAN_TYPE = ['Introduction générale', 'Revue de la littérature / état de l’art', 'Méthodologie et données', 'Résultats et analyse', 'Conclusion et perspectives'];
  var DEF_CHECK = [['memoire', 'Mémoire final remis à l’encadreur'], ['autorisation', 'Autorisation de dépôt / soutenance de l’université'], ['jury', 'Jury constitué et prévenu'], ['diaporama', 'Diaporama de soutenance prêt'], ['repetition', 'Répétition de la défense faite'], ['exemplaires', 'Exemplaires imprimés et reliés'], ['convocation', 'Convocation envoyée à l’étudiant']];
  function okDate(v) { v = String(v || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false; var t = new Date(v + 'T00:00:00Z'); return !isNaN(t.getTime()) && t.toISOString().slice(0, 10) === v; }
  function okHeure(v) { return /^([01]\d|2[0-3]):[0-5]\d$/.test(String(v || '')); }
  function dateFr(v) { return okDate(v) ? v.slice(8, 10) + '/' + v.slice(5, 7) + '/' + v.slice(0, 4) : ''; }
  function sdoss(dosId, fn) {
    var dos = L.dos(), d = dos.filter(function (x) { return x.id === dosId; })[0]; if (!d) throw new Error('dossier introuvable.');
    var r = fn(d); d.updated_at = now();
    if (!put(K.dos, dos)) throw new Error('enregistrement local refusé (espace plein ?) : exportez une sauvegarde puis libérez de l’espace.');
    return r;
  }
  function chap(d, chId) { var c = (d.chapitres || []).filter(function (x) { return x.id === chId; })[0]; if (!c) throw new Error('chapitre introuvable.'); return c; }
  function chapitreAjouter(dosId, titre, echeance) {
    titre = cut(titre, 120); if (titre.length < 2) throw new Error('indiquez le titre du chapitre.');
    echeance = cut(echeance, 10); if (echeance && !okDate(echeance)) throw new Error('date d’échéance invalide.');
    return sdoss(dosId, function (d) {
      d.chapitres = d.chapitres || []; if (d.chapitres.length >= 30) throw new Error('30 chapitres au maximum par dossier.');
      var c = { id: 'CH-' + rid(), titre: titre, statut: 'a_faire', echeance: echeance, remis_le: '', corrections: [] }; d.chapitres.push(c);
      history(d.id, 'chapitre_ajoute', null, { titre: titre }); return c;
    });
  }
  function chapitrePlanType(dosId) {
    return sdoss(dosId, function (d) {
      if ((d.chapitres || []).length) throw new Error('un plan existe déjà pour ce dossier.');
      d.chapitres = PLAN_TYPE.map(function (t) { return { id: 'CH-' + rid(), titre: t, statut: 'a_faire', echeance: '', remis_le: '', corrections: [] }; });
      history(d.id, 'plan_type', null, { chapitres: d.chapitres.length }); return d.chapitres.length;
    });
  }
  function chapitreStatut(dosId, chId, statut) {
    if (!CH_STAT.some(function (s) { return s[0] === statut; })) throw new Error('statut de chapitre inconnu.');
    return sdoss(dosId, function (d) { var c = chap(d, chId), av = c.statut; c.statut = statut; if (statut === 'remis') c.remis_le = now(); history(d.id, 'chapitre_statut', { titre: c.titre, statut: av }, { titre: c.titre, statut: statut }); return c; });
  }
  function chapitreSupprimer(dosId, chId) { return sdoss(dosId, function (d) { var c = chap(d, chId); d.chapitres = d.chapitres.filter(function (x) { return x.id !== chId; }); history(d.id, 'chapitre_supprime', { titre: c.titre }, null); }); }
  function correctionAjouter(dosId, chId, texte) {
    texte = cut(texte, 1000); if (texte.length < 3) throw new Error('écrivez la correction demandée.');
    return sdoss(dosId, function (d) {
      var c = chap(d, chId); c.corrections = c.corrections || []; if (c.corrections.length >= 50) throw new Error('50 corrections au maximum par chapitre.');
      c.corrections.push({ id: 'CO-' + rid(), at: now(), texte: texte, fait: false }); c.statut = 'a_corriger';
      history(d.id, 'correction_demandee', { titre: c.titre }, { texte: texte.slice(0, 80) }); return c;
    });
  }
  function correctionBasculer(dosId, chId, coId) {
    return sdoss(dosId, function (d) { var c = chap(d, chId), k = (c.corrections || []).filter(function (x) { return x.id === coId; })[0]; if (!k) throw new Error('correction introuvable.'); k.fait = !k.fait; return k; });
  }
  function progressionAuto(dosId) {
    return sdoss(dosId, function (d) {
      var ch = d.chapitres || []; if (!ch.length) throw new Error('ajoutez d’abord les chapitres (ou le plan type).');
      var p = Math.round(ch.reduce(function (s, c) { return s + (CH_POIDS[c.statut] || 0); }, 0) / ch.length); d.progression = p;
      if (p > 0 && (d.etape || 1) < 6) d.etape = 6; return p;
    });
  }
  function rdvAjouter(dosId, o) {
    o = o || {}; var date = cut(o.date, 10), heure = cut(o.heure, 5), objet = cut(o.objet, 150);
    if (!okDate(date)) throw new Error('choisissez une date de rendez-vous valide.');
    if (heure && !okHeure(heure)) throw new Error('heure invalide (format 14:30).');
    if (objet.length < 2) throw new Error('indiquez l’objet du rendez-vous.');
    return sdoss(dosId, function (d) {
      d.rdv = d.rdv || []; if (d.rdv.length >= 80) throw new Error('80 rendez-vous au maximum par dossier.');
      var r = { id: 'RV-' + rid(), date: date, heure: heure, objet: objet, lieu: cut(o.lieu, 150), fait: false }; d.rdv.push(r);
      d.rdv.sort(function (a, b) { return (a.date + (a.heure || '')).localeCompare(b.date + (b.heure || '')); }); history(d.id, 'rdv_ajoute', null, { date: date, objet: objet }); return r;
    });
  }
  function rdvBasculer(dosId, rvId) { return sdoss(dosId, function (d) { var r = (d.rdv || []).filter(function (x) { return x.id === rvId; })[0]; if (!r) throw new Error('rendez-vous introuvable.'); r.fait = !r.fait; return r; }); }
  function rdvSupprimer(dosId, rvId) { return sdoss(dosId, function (d) { d.rdv = (d.rdv || []).filter(function (x) { return x.id !== rvId; }); }); }
  function icsT(v) { return String(v == null ? '' : v).replace(/\\/g, '\\\\').replace(/[,;]/g, function (c) { return '\\' + c; }).replace(/\r?\n/g, '\\n'); }
  function rdvIcs(d, r) {
    var e = etuOf(d), ds = r.date.replace(/-/g, ''), L2 = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Excellencia Building//TFL//FR', 'BEGIN:VEVENT', 'UID:' + r.id + '@excellencia-building', 'DTSTAMP:' + now().replace(/[-:]/g, '').slice(0, 15) + 'Z'];
    if (r.heure) { var h = r.heure.replace(':', '') + '00', fin = ('0' + ((parseInt(r.heure.slice(0, 2), 10) + 1) % 24)).slice(-2) + r.heure.slice(3, 5) + '00'; L2.push('DTSTART:' + ds + 'T' + h, 'DTEND:' + ds + 'T' + fin); } else L2.push('DTSTART;VALUE=DATE:' + ds);
    L2.push('SUMMARY:' + icsT('TFL — ' + r.objet + ' (' + (e.nom || d.numero) + ')'));
    if (r.lieu) L2.push('LOCATION:' + icsT(r.lieu)); L2.push('DESCRIPTION:' + icsT('Dossier ' + d.numero + ' — ' + (d.sujet_titre || '')), 'END:VEVENT', 'END:VCALENDAR');
    return L2.join('\r\n') + '\r\n';
  }
  function defenseEnregistrer(dosId, o) {
    o = o || {}; var date = cut(o.date, 10), heure = cut(o.heure, 5);
    if (date && !okDate(date)) throw new Error('date de défense invalide.'); if (heure && !okHeure(heure)) throw new Error('heure invalide (format 14:30).');
    var check = {}; DEF_CHECK.forEach(function (c) { check[c[0]] = !!(o.check && o.check[c[0]]); });
    return sdoss(dosId, function (d) {
      d.defense = { date: date, heure: heure, lieu: cut(o.lieu, 150), president: cut(o.president, 120), jury: cut(o.jury, 500), note: cut(o.note, 1000), check: check };
      if (date && (d.etape || 1) < 8) d.etape = 8; history(d.id, 'defense_enregistree', null, { date: date }); return d.defense;
    });
  }
  function defFaits(d) { var c = (d.defense || {}).check || {}; return DEF_CHECK.filter(function (x) { return c[x[0]]; }).length; }
  function actifs() { return L.dos().filter(function (d) { return d.statut !== 'refuse' && d.statut !== 'clos'; }); }
  /* Échéances : retards d'abord, puis ce qui arrive dans « jours » jours (rendez-vous non faits, chapitres non remis, défenses). */
  function echeances(jours) {
    var today = now().slice(0, 10), lim = new Date(Date.now() + (jours || 14) * 864e5).toISOString().slice(0, 10), out = [];
    actifs().forEach(function (d) {
      var nom = etuOf(d).nom || '', add = function (type, date, label) { if (okDate(date) && date <= lim) out.push({ type: type, date: date, label: label, numero: d.numero, nom: nom, dosId: d.id, retard: date < today }); };
      (d.rdv || []).forEach(function (r) { if (!r.fait) add('rdv', r.date, r.objet + (r.heure ? ' à ' + r.heure : '')); });
      (d.chapitres || []).forEach(function (c) { if (c.statut !== 'valide' && c.statut !== 'remis') add('chapitre', c.echeance, 'Chapitre « ' + c.titre + ' »'); });
      if ((d.defense || {}).date) add('defense', d.defense.date, 'Défense' + (d.defense.heure ? ' à ' + d.defense.heure : ''));
    });
    return out.sort(function (a, b) { return a.date.localeCompare(b.date); });
  }
  function tableau() {
    var D = L.dos(), t = { total: D.length, statut: {}, etape: {}, actifs: 0, progMoyenne: 0, sansEncadreur: 0, sansMatricule: 0, defenses: 0, correctionsOuvertes: 0, retards: 0, encadreurs: [] }, somme = 0, nb = 0, charge = {};
    STATUTS.forEach(function (s) { t.statut[s[0]] = 0; }); ETAPES.forEach(function (x) { t.etape[x[0]] = 0; });
    D.forEach(function (d) {
      t.statut[d.statut] = (t.statut[d.statut] || 0) + 1;
      if (d.statut === 'refuse' || d.statut === 'clos') return;
      t.actifs++; t.etape[d.etape || 1] = (t.etape[d.etape || 1] || 0) + 1;
      if (d.statut === 'accepte') { somme += Number(d.progression) || 0; nb++; if (!d.encadreur_id) t.sansEncadreur++; }
      if (!etuOf(d).matricule) t.sansMatricule++;
      if ((d.defense || {}).date && d.defense.date >= now().slice(0, 10)) t.defenses++;
      (d.chapitres || []).forEach(function (c) { (c.corrections || []).forEach(function (k) { if (!k.fait) t.correctionsOuvertes++; }); });
      if (d.encadreur_id) charge[d.encadreur_id] = (charge[d.encadreur_id] || 0) + 1;
    });
    t.progMoyenne = nb ? Math.round(somme / nb) : 0; t.retards = echeances(0).filter(function (x) { return x.retard; }).length;
    t.encadreurs = L.enc().filter(function (e) { return e.actif !== false; }).map(function (e) { return { nom: e.nom, n: charge[e.id] || 0, max: Number(e.max_etudiants) || 0 }; });
    return t;
  }
  function rapportCsv() {
    var c = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; }, today = now().slice(0, 10);
    var cols = ['N° dossier', 'Étudiant', 'Matricule', 'Téléphone', 'Université', 'Domaine', 'Sujet', 'Statut', 'Étape', 'Progression %', 'Encadreur', 'Chapitres validés', 'Corrections ouvertes', 'Prochain rendez-vous', 'Date de défense', 'Mis à jour le'];
    return '\ufeff' + cols.map(c).join(';') + '\r\n' + L.dos().sort(function (a, b) { return String(a.numero).localeCompare(String(b.numero)); }).map(function (d) {
      var e = etuOf(d), enc = encOf(d), ch = d.chapitres || [], ouv = 0, nx = (d.rdv || []).filter(function (r) { return !r.fait && r.date >= today; })[0];
      ch.forEach(function (x) { (x.corrections || []).forEach(function (k) { if (!k.fait) ouv++; }); });
      return [d.numero, e.nom, e.matricule, e.telephone, e.universite, LBL(DOMAINES, d.domaine), d.sujet_titre, LBL(STATUTS, d.statut), d.etape, d.progression, enc ? enc.nom : '', ch.length ? ch.filter(function (x) { return x.statut === 'valide'; }).length + '/' + ch.length : '', ouv, nx ? dateFr(nx.date) + (nx.heure ? ' ' + nx.heure : '') : '', (d.defense || {}).date ? dateFr(d.defense.date) : '', String(d.updated_at || '').slice(0, 10)].map(c).join(';');
    }).join('\r\n');
  }
  function telecharger(nom, texte, type) { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([texte], { type: type || 'text/plain;charset=utf-8' })); a.download = nom; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500); }

  /* ----- écrans ----- */
  function blocSuivi(d) {
    var e = etuOf(d), chs = d.chapitres || [], R = d.rdv || [], DF = d.defense || {}, today = now().slice(0, 10);
    var btn = function (a, label, attrs) { return '<button type="button" class="muted" data-tfl="' + a + '" ' + (attrs || '') + ' style="padding:6px 10px">' + label + '</button>'; };
    var H = function (t) { return '<h4 style="margin:18px 0 6px">' + t + '</h4>'; };
    var card = 'border:1px solid #dce3ed;border-radius:10px;padding:8px;margin:6px 0;background:#fff';
    var s = '<div id="tflSuivi" style="border-top:3px solid #c9a227;margin-top:18px;padding-top:4px"><h3 style="margin:10px 0 0">📌 Suivi de la rédaction</h3>';
    s += H('📑 Chapitres et corrections') + (chs.length ? chs.map(function (c) {
      var retard = c.echeance && c.echeance < today && c.statut !== 'valide' && c.statut !== 'remis';
      return '<div style="' + card + '"><div style="display:flex;justify-content:space-between;gap:6px;align-items:flex-start"><b>' + esc(c.titre) + '</b>' + btn('chDel', '🗑', 'data-ch="' + esc(c.id) + '"') + '</div>'
        + (c.echeance ? '<small style="color:' + (retard ? '#b91c1c' : '#667085') + '">Échéance : ' + dateFr(c.echeance) + (retard ? ' — en retard' : '') + '</small>' : '')
        + '<div style="display:flex;gap:4px;flex-wrap:wrap;margin:6px 0">' + CH_STAT.map(function (x) { return '<button type="button" data-tfl="chStatut" data-ch="' + esc(c.id) + '" data-v="' + x[0] + '" style="padding:4px 8px;font-size:12px;border-radius:8px;border:1px solid #173565;cursor:pointer;background:' + (c.statut === x[0] ? '#173565;color:#fff' : '#fff;color:#173565') + '">' + esc(x[1]) + '</button>'; }).join('') + '</div>'
        + (c.corrections || []).map(function (k) { return '<div style="display:flex;gap:6px;align-items:flex-start;font-size:13px;margin:3px 0"><button type="button" data-tfl="coBasc" data-ch="' + esc(c.id) + '" data-co="' + esc(k.id) + '" style="border:0;background:none;cursor:pointer;font-size:16px">' + (k.fait ? '✅' : '⬜') + '</button><span style="' + (k.fait ? 'text-decoration:line-through;color:#667085' : '') + '">' + esc(k.texte) + ' <small style="color:#98a2b3">' + esc(String(k.at).slice(0, 10)) + '</small></span></div>'; }).join('')
        + '<div style="display:flex;gap:6px;margin-top:4px"><input id="tflCo-' + esc(c.id) + '" placeholder="Correction demandée…" style="flex:1;min-width:0">' + btn('coAdd', '➕ Ajouter', 'data-ch="' + esc(c.id) + '"') + '</div></div>';
    }).join('') : '<p class="hint">Aucun chapitre : ajoutez-les un par un ou prenez le plan type (5 chapitres).</p>')
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px"><input id="tflChT" placeholder="Titre du chapitre"><input id="tflChD" type="date" title="Échéance"></div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button type="button" class="primary" data-tfl="chAdd">➕ Ajouter le chapitre</button>' + (chs.length ? '' : btn('chPlan', '📋 Plan type')) + (chs.length ? btn('progAuto', '🧮 Calculer la progression') : '') + '</div>';
    s += H('📅 Rendez-vous et échéances') + (R.length ? R.map(function (r) {
      var retard = !r.fait && r.date < today, msg = 'Bonjour ' + (e.nom || '') + ', rappel de notre rendez-vous TFL (' + d.numero + ') : ' + r.objet + ' le ' + dateFr(r.date) + (r.heure ? ' à ' + r.heure : '') + (r.lieu ? ', ' + r.lieu : '') + '. Excellencia Building';
      return '<div style="' + card + ';display:flex;gap:6px;align-items:flex-start"><button type="button" data-tfl="rdvBasc" data-r="' + esc(r.id) + '" style="border:0;background:none;cursor:pointer;font-size:18px">' + (r.fait ? '✅' : '⬜') + '</button><div style="flex:1;min-width:0;' + (r.fait ? 'color:#667085' : '') + '"><b>' + dateFr(r.date) + (r.heure ? ' ' + esc(r.heure) : '') + '</b> — ' + esc(r.objet) + (r.lieu ? ' <small>(' + esc(r.lieu) + ')</small>' : '') + (retard ? ' <small style="color:#b91c1c">en retard</small>' : '')
        + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px">' + (e.telephone ? '<a target="_blank" rel="noopener" href="' + esc(waLink(e.telephone, msg)) + '" style="padding:4px 8px;border-radius:8px;background:#eef2f7;color:#173565;text-decoration:none;font-size:13px">💬 Rappel</a>' : '') + btn('rdvIcs', '📆 Agenda', 'data-r="' + esc(r.id) + '"') + btn('rdvDel', '🗑', 'data-r="' + esc(r.id) + '"') + '</div></div></div>';
    }).join('') : '<p class="hint">Aucun rendez-vous planifié.</p>')
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px"><input id="tflRvD" type="date"><input id="tflRvH" type="time"><input id="tflRvO" placeholder="Objet (ex. relecture chapitre 2)"><input id="tflRvL" placeholder="Lieu (facultatif)"></div>'
      + '<div style="margin-top:6px"><button type="button" class="primary" data-tfl="rdvAdd">➕ Planifier le rendez-vous</button></div>';
    s += H('🎤 Préparation de la défense' + (DF.date ? ' — ' + dateFr(DF.date) : '')) + '<div style="' + card + '"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px"><input id="tflDfD" type="date" value="' + esc(DF.date || '') + '"><input id="tflDfH" type="time" value="' + esc(DF.heure || '') + '"><input id="tflDfL" placeholder="Lieu" value="' + esc(DF.lieu || '') + '"><input id="tflDfP" placeholder="Président du jury" value="' + esc(DF.president || '') + '"></div>'
      + '<textarea id="tflDfJ" placeholder="Membres du jury" style="width:100%;min-height:48px;margin-top:6px">' + esc(DF.jury || '') + '</textarea>'
      + '<div style="margin-top:6px">' + DEF_CHECK.map(function (c) { return '<label style="display:flex;gap:8px;align-items:center;margin:4px 0;font-size:14px"><input type="checkbox" class="tflDefC" data-k="' + c[0] + '"' + (((DF.check || {})[c[0]]) ? ' checked' : '') + ' style="width:auto"> ' + esc(c[1]) + '</label>'; }).join('') + '</div>'
      + '<textarea id="tflDfN" placeholder="Notes de préparation" style="width:100%;min-height:48px;margin-top:6px">' + esc(DF.note || '') + '</textarea>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;align-items:center"><button type="button" class="primary" data-tfl="defSave">💾 Enregistrer la préparation</button><small class="hint">' + defFaits(d) + '/' + DEF_CHECK.length + ' points prêts</small>'
      + (DF.date && e.telephone ? '<a target="_blank" rel="noopener" href="' + esc(waLink(e.telephone, 'Bonjour ' + (e.nom || '') + ', votre défense de TFL (' + d.numero + ') est fixée au ' + dateFr(DF.date) + (DF.heure ? ' à ' + DF.heure : '') + (DF.lieu ? ', ' + DF.lieu : '') + '. Excellencia Building')) + '" style="padding:6px 10px;border-radius:8px;background:#eef2f7;color:#173565;text-decoration:none">💬 Convocation WhatsApp</a>' : '') + '</div></div></div>';
    return s;
  }
  function vueTableau() {
    var t = tableau(), E = echeances(14), bar = function (n, max) { return '<div style="background:#eef2f7;border-radius:6px;height:10px;overflow:hidden"><div style="height:10px;width:' + (max ? Math.round(n / max * 100) : 0) + '%;background:#173565"></div></div>'; };
    var kpi = function (n, l, warn) { return '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;background:#fff"><b style="font-size:22px;color:' + (warn && n ? '#b91c1c' : '#173565') + '">' + n + '</b><br><small>' + esc(l) + '</small></div>'; };
    var maxE = Math.max.apply(null, ETAPES.map(function (x) { return t.etape[x[0]] || 0; }).concat([1]));
    return '<div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button><button type="button" class="primary" data-tfl="csvRapport">⬇ Rapport CSV (tous les dossiers)</button></div><h3>📊 Tableau de bord TFL</h3>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px">' + kpi(t.total, 'dossiers') + kpi(t.actifs, 'dossiers actifs') + kpi(t.progMoyenne + ' %', 'progression moyenne (acceptés)') + kpi(t.sansEncadreur, 'acceptés sans encadreur', 1) + kpi(t.sansMatricule, 'sans matricule', 1) + kpi(t.correctionsOuvertes, 'corrections à faire', 1) + kpi(t.defenses, 'défenses à venir') + kpi(t.retards, 'échéances en retard', 1) + '</div>'
      + '<h4 style="margin:16px 0 6px">Répartition par étape (dossiers actifs)</h4>' + ETAPES.map(function (x) { return '<div style="display:grid;grid-template-columns:minmax(120px,40%) 1fr 28px;gap:8px;align-items:center;font-size:13px;margin:3px 0"><span>' + x[0] + ' — ' + esc(x[1]) + '</span>' + bar(t.etape[x[0]] || 0, maxE) + '<b>' + (t.etape[x[0]] || 0) + '</b></div>'; }).join('')
      + '<h4 style="margin:16px 0 6px">Charge des encadreurs</h4>' + (t.encadreurs.length ? t.encadreurs.map(function (x) { return '<div style="font-size:14px;margin:3px 0">' + esc(x.nom) + ' : <b>' + x.n + '</b>' + (x.max ? ' / ' + x.max : '') + (x.max && x.n > x.max ? ' <span style="color:#b91c1c">⚠ surcharge</span>' : '') + '</div>'; }).join('') : '<p class="hint">Aucun encadreur actif.</p>')
      + '<h4 style="margin:16px 0 6px">Échéances (retards + 14 prochains jours)</h4>' + (E.length ? E.map(function (x) { return '<div data-tfl="ouvrirDos" data-id="' + esc(x.dosId) + '" style="border:1px solid #dce3ed;border-radius:8px;padding:6px 8px;margin:4px 0;font-size:14px;cursor:pointer;background:#fff"><b style="color:' + (x.retard ? '#b91c1c' : '#173565') + '">' + dateFr(x.date) + (x.retard ? ' (retard)' : '') + '</b> — ' + esc(x.label) + '<br><small style="color:#667085">' + esc(x.nom) + ' · ' + esc(x.numero) + '</small></div>'; }).join('') : '<p class="hint">Rien de prévu dans les 14 jours.</p>');
  }

  /* ---------- V99zzzzzzzzzzzzzz : ENCADREURS (formulaire), matricule automatique, sujets proposés, validation, statuts publics ---------- */
  var PROP = [['recu', 'Reçu — en cours d’étude'], ['en_verification', 'En vérification'], ['retenu', 'Retenu'], ['refuse', 'Refusé'], ['complement', 'Complément demandé'], ['retire', 'Retiré à la demande']];
  var VALID_ENC = [['', 'En attente de validation par l’encadreur'], ['valide', 'Sujet validé par l’encadreur'], ['a_corriger', 'À corriger (demandé par l’encadreur)'], ['refuse', 'Sujet refusé par l’encadreur']];
  function valLabel(k) { return LBL(VALID_ENC, k || ''); }

  /* Formulaire d'un encadreur (fichier hors ligne ou envoi en ligne) : fiche d'encadreur + sujets proposés, matricule attribué tout de suite. */
  function importerEncadreur(o) {
    if (!o || o.form !== 'EXB_TFL_ENC' || !o.d) throw new Error('ce fichier n’est pas un formulaire d’encadreur TFL Excellencia Building.');
    var d = o.d, nom = cut(d.nom, 120), tel = cut(d.telephone, 40);
    if (!nom || !tel) throw new Error('nom ou téléphone manquant.');
    var subj = (Array.isArray(d.sujets) ? d.sujets : []).slice(0, 5).filter(function (x) { return x && cut(x.titre, 250).length >= 3 && cut(x.problematique, 3000).length >= 3 && cut(x.objectifs, 3000).length >= 3; });
    if (!subj.length) throw new Error('aucun sujet complet (titre, problématique et objectifs obligatoires).');
    var sub = ''; if (o.submitted_at) { var dt = new Date(o.submitted_at); sub = isNaN(dt.getTime()) ? String(o.submitted_at) : dt.toISOString(); }
    var sig = ['tflenc', sub, digits(tel) || norm(nom)].join('|'), done = get(K.done, []);
    if (sub && done.indexOf(sig) >= 0) return { dup: true, nom: nom };
    var encs = L.enc(), em = cut(d.email, 120).toLowerCase();
    var c = encs.filter(function (x) { return meme(x.telephone, tel) || (em && String(x.email || '').toLowerCase() === em); })[0], nouveau = !c;
    if (!c) { c = { id: 'TFLC-' + rid(), disponible: true, actif: true, valide: false, created_at: now() }; encs.push(c); }
    c.nom = nom; c.telephone = tel; c.email = em || c.email || '';
    c.grade = cut(d.grade, 60) || c.grade || ''; c.institution = cut(d.institution, 150) || c.institution || ''; c.specialites = cut(d.specialites, 200) || c.specialites || '';
    c.experience = cut(d.experience, 60) || c.experience || ''; c.source = c.source || 'formulaire';
    var doms = (Array.isArray(d.domaines) ? d.domaines : []).filter(function (x) { return DOMAINES.some(function (y) { return y[0] === x; }); }); if (doms.length) c.domaines = doms;
    var mx = parseInt(d.max_etudiants, 10); if (mx > 0) c.max_etudiants = Math.min(30, mx); else c.max_etudiants = c.max_etudiants || 8;
    if (okPhoto(o.photo)) c.photo = o.photo; { var sg = o.signature || d.signature; if (okSig(sg)) c.signature = sg; }
    /* matricule AUTOMATIQUE : celui donné par le serveur à la soumission, sinon un nouveau numéro unique */
    var conflit = '';
    if (!c.matricule) {
      var mo = cut(d.matricule_en_ligne, 40), u = usedMatricules();
      if (mo && !u[mo]) c.matricule = mo; else { if (mo) conflit = mo; c.matricule = newMatricule(); }
      c.matricule_le = now();
    }
    if (!put(K.enc, encs)) throw new Error('enregistrement local refusé (espace plein ?) : exportez une sauvegarde puis libérez de l’espace.');
    var ajoutes = [];
    subj.forEach(function (x) {
      var t = cut(x.titre, 250), deja = sujets().filter(function (s) { return s.encadreur_id === c.id && norm(s.titre) === norm(t); })[0]; if (deja) return;
      var f = sujetAjouter({ titre: t, categorie: x.categorie, domaine: x.domaine, filiere: x.filiere, niveau: x.niveau, problematique: x.problematique, objectifs: x.objectifs,
                             methodologie: x.methodologie, livrables: x.livrables, competences: '', mots_cles: x.mots_cles, exclusif: true });
      var all = sujets(), s2 = all.filter(function (s) { return s.ref === f.ref; })[0];
      s2.source = 'encadreur'; s2.encadreur_id = c.id; s2.encadreur_nom = c.nom; s2.proposition = 'recu'; s2.motif_proposition = ''; s2.proposition_le = now(); s2.publie = false; s2.statut = 'ferme';
      put(K.suj, all); ajoutes.push(s2);
    });
    if (sub) { done.push(sig); put(K.done, done.slice(-800)); }
    trace('TFL_ENCADREUR_IMPORT', c.nom + ' — ' + c.matricule + ' — ' + ajoutes.length + ' sujet(s)');
    return { dup: false, nom: nom, matricule: c.matricule, sujets: ajoutes.length, nouveau: nouveau, conflit: conflit, encadreur: c };
  }
  function encadreurValider(encId, oui) {
    var a = L.enc(), c = a.filter(function (x) { return x.id === encId; })[0]; if (!c) throw new Error('encadreur introuvable.');
    c.valide = oui !== false; if (c.valide && !c.matricule) { c.matricule = newMatricule(); c.matricule_le = now(); } put(K.enc, a); trace('TFL_ENCADREUR_VALIDE', c.nom + ' : ' + (c.valide ? 'oui' : 'non')); return c;
  }
  /* Décision de l'administration sur un sujet proposé par un encadreur : retenu = publié au catalogue, sinon reste fermé. */
  function propositionDecider(ref, decision, motif) {
    if (!PROP.some(function (x) { return x[0] === decision; })) throw new Error('décision inconnue.');
    if ((decision === 'refuse' || decision === 'complement') && cut(motif, 1500).length < 3) throw new Error('indiquez le motif : il sera communiqué à l’encadreur.');
    var all = sujets(), s = all.filter(function (x) { return x.ref === ref; })[0]; if (!s) throw new Error('sujet introuvable.');
    s.proposition = decision; s.proposition_le = now(); s.decide_par = operateur(); if (motif != null) s.motif_proposition = cut(motif, 1500);
    if (decision === 'retenu') { if (s.titre.length < 3 || s.problematique.length < 3 || s.objectifs.length < 3) throw new Error('fiche incomplète : impossible de retenir.'); s.statut = 'disponible'; s.publie = true; }
    else { s.statut = 'ferme'; s.publie = false; }
    s.updated_at = now(); put(K.suj, all); trace('TFL_PROPOSITION', ref + ' → ' + decision); planifierStatuts(); return s;
  }
  /* Validation du sujet par l'encadreur : il l'envoie depuis son portail ; elle s'applique au dossier quand l'administration clique « Appliquer ». */
  function appliquerValidation(msgId) {
    var msgs = msgsLocaux(), m = msgs.filter(function (x) { return x.id === msgId; })[0]; if (!m || m.type !== 'validation') throw new Error('validation introuvable.');
    var d = L.dos().filter(function (x) { return x.numero === m.dossier; })[0]; if (!d) throw new Error('dossier introuvable.');
    var code = ['', 'valide', 'a_corriger', 'refuse'][m.valeur] || 'a_corriger', patch = { validation_encadreur: code, validation_encadreur_le: now(), validation_encadreur_motif: cut(m.texte, 1500) };
    if (m.texte) patch.observation_encadreur = cut(m.texte, 2000);
    patch.sujet_statut = { valide: 'accepte', a_corriger: 'a_reviser', refuse: 'refuse' }[code];
    patchDossier(d.id, patch); m.appliquee = true; m.lu = true; put(K.msg, msgs); trace('TFL_VALIDATION_ENCADREUR', d.numero + ' → ' + code); planifierStatuts(); return L.dos().filter(function (x) { return x.id === d.id; })[0];
  }
  function validationMsgHtml(m) {
    var lib = valLabel({ 1: 'valide', 2: 'a_corriger', 3: 'refuse' }[m.valeur]);
    return 'Validation du sujet : <b>' + esc(lib) + '</b>' + (m.texte ? '<br>' + esc(m.texte).replace(/\n/g, '<br>') : '') + (m.appliquee ? ' <span style="color:#15803d">(appliquée)</span>' : ' <button type="button" class="primary" data-tfl="appliquerVal" data-id="' + esc(m.id) + '" style="padding:4px 10px">Appliquer</button>');
  }
  /* Statuts consultables par matricule (page tfl-statut.html) : un lot par personne, publié sur le serveur. */
  function statutsAPublier() {
    var out = [], etus = L.etu(), D = L.dos(), encs = L.enc(), S = sujets();
    etus.forEach(function (e) {
      if (!e.matricule) return;
      var items = D.filter(function (d) { return d.etudiant_id === e.id; }).map(function (d) {
        var enc = encs.filter(function (x) { return x.id === d.encadreur_id; })[0];
        return { ref: d.numero, titre: d.sujet_titre || '', statut: d.statut, label: LBL(STATUTS, d.statut), motif: d.motif_decision || '', encadreur: enc && d.statut === 'accepte' ? enc.nom : '',
                 validation: d.validation_encadreur ? valLabel(d.validation_encadreur) : '', maj: String(d.updated_at || '').slice(0, 10) };
      });
      out.push({ matricule: e.matricule, role: 'etudiant', nom: e.nom || '', tel: e.telephone || '', items: items });
    });
    encs.forEach(function (c) {
      if (!c.matricule) return;
      var items = S.filter(function (s) { return s.encadreur_id === c.id && s.source === 'encadreur'; }).map(function (s) {
        return { ref: s.ref, titre: s.titre, statut: s.proposition || 'recu', label: LBL(PROP, s.proposition || 'recu'), motif: s.motif_proposition || '', encadreur: '', validation: '', maj: String(s.updated_at || '').slice(0, 10) };
      });
      out.push({ matricule: c.matricule, role: 'encadreur', nom: c.nom || '', tel: c.telephone || '', items: items });
    });
    return out;
  }
  async function publierStatuts(silencieux) {
    var lot = statutsAPublier(); if (!lot.length) { if (!silencieux) say('Aucun matricule à publier pour le moment.', 'info'); return { n: 0 }; }
    for (var i = 0; i < lot.length; i += 40) await adminRpc('tfl_statut_publier', { p_lot: lot.slice(i, i + 40) });
    if (!silencieux) say(lot.length + ' matricule(s) publié(s) : chacun peut vérifier son statut sur la page de suivi.', 'success');
    return { n: lot.length };
  }
  /* Après une décision, les statuts partent tout seuls vers le serveur si l'administrateur y est connecté (sinon : bouton « Publier les statuts »). */
  var __statutsTimer = null;
  function planifierStatuts() {
    if (typeof document === 'undefined') return;
    try { if (!(root.exbSb && root.exbSb.isIn && root.exbSb.isIn())) return; } catch (e) { return; }
    clearTimeout(__statutsTimer); __statutsTimer = setTimeout(function () { publierStatuts(true).catch(function () { /* le bouton manuel reste disponible */ }); }, 2000);
  }

  /* ---------- Informer par WhatsApp · demandes de modification/retrait · avis avant acceptation ---------- */
  function lienStatut() { var b = ''; try { b = baseSite(); } catch (e) { b = ''; } return b ? b + 'tfl-statut.html' : 'la page de suivi (tfl-statut.html) du site Excellencia Building'; }
  function texteMatricule(nom, mat, role) {
    return 'Bonjour ' + (nom || '') + ', Excellencia Building a bien reçu votre ' + (role === 'encadreur' ? 'formulaire d’encadreur' : 'dossier TFL') + '.\nVotre MATRICULE : ' + mat + '\nAvec ce matricule et votre numéro de téléphone, vous pouvez vérifier à tout moment si votre sujet est retenu, refusé ou en cours : ' + lienStatut();
  }
  function texteDecisionDossier(d, e) {
    var st = d.statut, t = 'Bonjour ' + ((e && e.nom) || '') + ', votre sujet « ' + (d.sujet_titre || d.numero) + ' » : ';
    if (st === 'accepte') t += 'ACCEPTÉ ✅. Un encadreur vous sera communiqué.';
    else if (st === 'refuse') t += 'REFUSÉ.' + (d.motif_decision ? ' Motif : ' + d.motif_decision : '');
    else if (st === 'complement_demande') t += 'un COMPLÉMENT est demandé.' + (d.motif_decision ? ' ' + d.motif_decision : '');
    else if (st === 'en_verification') t += 'en cours de vérification.';
    else if (st === 'clos') t += 'dossier clos.' + (d.motif_decision ? ' ' + d.motif_decision : '');
    else t += 'bien reçu.';
    return t + '\nSuivi avec votre matricule' + (e && e.matricule ? ' (' + e.matricule + ')' : '') + ' : ' + lienStatut();
  }
  function texteDecisionProp(s, c) {
    var t = 'Bonjour ' + ((c && c.nom) || '') + ', votre sujet « ' + s.titre + ' » : ', p = s.proposition || 'recu';
    if (p === 'retenu') t += 'RETENU ✅ : il est proposé aux étudiants.';
    else if (p === 'refuse') t += 'REFUSÉ.' + (s.motif_proposition ? ' Motif : ' + s.motif_proposition : '');
    else if (p === 'complement') t += 'un COMPLÉMENT est demandé.' + (s.motif_proposition ? ' ' + s.motif_proposition : '');
    else if (p === 'retire') t += 'RETIRÉ à votre demande.';
    else if (p === 'en_verification') t += 'en cours de vérification.';
    else t += 'bien reçu.';
    return t + '\nSuivi avec votre matricule' + (c && c.matricule ? ' (' + c.matricule + ')' : '') + ' : ' + lienStatut();
  }
  /* Demande de modification ou de retrait envoyée depuis la page de suivi (matricule + téléphone) : l'administration l'applique en un clic. */
  function demandeAppliquer(dem) {
    var ref = cut(dem.ref, 60), type = dem.type === 'retirer' ? 'retirer' : 'modifier', txt = cut(dem.texte, 600), d = L.dos().filter(function (x) { return x.numero === ref; })[0];
    if (d) {
      if (type === 'retirer') setStatut(d.id, 'clos', 'Retiré à la demande de l’étudiant.');
      else setStatut(d.id, 'complement_demande', 'Modification demandée : ' + (txt || 'à préciser') + ' — renvoyez votre dossier corrigé.');
      return { cible: 'dossier', ref: d.numero };
    }
    var all = sujets(), s = all.filter(function (x) { return x.ref === ref && x.source === 'encadreur'; })[0];
    if (!s) throw new Error('élément introuvable : s’il vient d’être déposé, importez d’abord le dossier ou le formulaire.');
    s.proposition = type === 'retirer' ? 'retire' : 'complement'; s.motif_proposition = type === 'retirer' ? 'Retiré à la demande de l’encadreur.' : 'Modification demandée : ' + (txt || 'à préciser') + ' — renvoyez votre formulaire corrigé.';
    s.proposition_le = now(); s.updated_at = now(); s.publie = false; s.statut = 'ferme'; put(K.suj, all); trace('TFL_DEMANDE', ref + ' → ' + s.proposition); planifierStatuts();
    return { cible: 'sujet', ref: s.ref };
  }
  function ouvrirWa(tel, texte) { root.open(tel ? waLink(tel, texte) : 'https://wa.me/?text=' + encodeURIComponent(texte), '_blank'); }
  function personneParMatricule(mat) {
    var m = normId(mat), e = L.etu().filter(function (x) { return x.matricule && normId(x.matricule) === m; })[0];
    if (e) return { role: 'etudiant', p: e };
    var c = L.enc().filter(function (x) { return x.matricule && normId(x.matricule) === m; })[0];
    return c ? { role: 'encadreur', p: c } : null;
  }
  var DEM = [];
  async function demandesEnLigne() {
    var sb = root.exbSb;
    if (!sb || !sb.isIn || !sb.isIn()) { ST.msg = '<b style="color:#b91c1c">Non connecté au serveur</b> : connectez-vous (compte administrateur).'; refresh(); return; }
    try { DEM = await sb.api('/rest/v1/rpc/tfl_demandes_liste', { method: 'POST', body: '{}' }) || []; ST.msg = DEM.length ? '' : 'Aucune demande de modification ou de retrait en attente.'; }
    catch (e) { ST.msg = '<b style="color:#b91c1c">' + esc(erreurServeur(e)) + '</b>'; }
    refresh();
  }
  async function demandeTraiter(id, appliquer) {
    var dem = DEM.filter(function (x) { return x.id === id; })[0]; if (!dem) return;
    try {
      var info = '';
      if (appliquer) { var r = demandeAppliquer(dem); info = ' appliquée (' + r.ref + ').'; } else info = ' ignorée.';
      await root.exbSb.api('/rest/v1/rpc/tfl_demande_traiter', { method: 'POST', body: JSON.stringify({ p_id: id }) });
      DEM = DEM.filter(function (x) { return x.id !== id; });
      ST.msg = '<b style="color:#15803d">✓ Demande' + info + '</b>' + (appliquer ? ' <button type="button" class="muted" data-tfl="demWa" data-k="' + esc(dem.matricule) + '" data-ref="' + esc(dem.ref) + '" style="padding:3px 8px">💬 Informer la personne</button>' : '');
    } catch (e) { ST.msg = '<b style="color:#b91c1c">' + esc(e.message || erreurServeur(e)) + '</b>'; }
    refresh();
  }
  /* ---------- V99… : attestation d'encadrement, historique « par qui », rappel de sauvegarde ---------- */
  /* Adresse e-mail de l'administrateur connecté (lue dans son jeton de session), pour savoir QUI a décidé. */
  function operateur() {
    try {
      var raw = root.localStorage && root.localStorage.getItem('EXB_SB_TOKEN'); if (!raw) return '';
      var t = JSON.parse(raw).access_token, p = String(t || '').split('.')[1]; if (!p) return '';
      var j = JSON.parse(decodeURIComponent(escape(atob(p.replace(/-/g, '+').replace(/_/g, '/')))));
      return cut(j.email || '', 120);
    } catch (e) { return ''; }
  }
  async function encadrementPdf(encId) {
    var c = L.enc().filter(function (x) { return x.id === encId; })[0]; if (!c) return say('Encadreur introuvable.', 'error');
    if (!root.EXBForm || !root.EXBForm.pdfBlobAsync) return say('Module PDF indisponible.', 'error');
    var etus = L.etu(), D = L.dos().filter(function (d) { return d.encadreur_id === c.id && (d.statut === 'accepte' || d.statut === 'clos'); });
    if (!D.length) return say('Aucun étudiant encadré pour le moment : l’attestation n’a pas lieu d’être délivrée.', 'warn');
    var lignes = [['Encadreur', [c.grade, c.nom].filter(Boolean).join(' ')], ['Matricule', c.matricule || 'à attribuer'], ['Institution', c.institution || ''], ['Spécialités', c.specialites || ''],
                  ['Étudiants encadrés', String(D.length)], ['Délivrée le', now().slice(0, 10)]];
    var liste = D.map(function (d, i) { var e = etus.filter(function (x) { return x.id === d.etudiant_id; })[0] || {}; return (i + 1) + '. ' + (e.nom || '—') + ' — ' + d.numero + ' — ' + (d.sujet_titre || '') + ' (' + LBL(STATUTS, d.statut) + ')'; }).join('\n');
    var qr = '', code = '';
    try { var V = root.EXBVerif; if (V && V.docUrl && V.qrPng) { var cc = V.docUrl({ prefix: 'ENC', title: 'Attestation d’encadrement TFL', sub: c.matricule || c.nom, nom: c.nom || '', matricule: c.matricule || '', date: now().slice(0, 10), digest: [c.matricule, c.nom, D.length].join('|') }); qr = V.qrPng(cc.url); code = String(cc.hash || '').toUpperCase(); } } catch (x) { qr = ''; }
    var blob = await root.EXBForm.pdfBlobAsync({ titre: 'ATTESTATION D’ENCADREMENT — TFL', sousTitre: (c.matricule || '') + (code ? ' · Code ' + code : ''), qr: qr || undefined, matricule: c.matricule || '', lignes: lignes,
      notes: ['Excellencia Building atteste que la personne ci-dessus encadre les Travaux de Fin de Licence listés en annexe (page 2).'], sections: [['Travaux encadrés', liste]], titreAnnexe: 'ANNEXE — TRAVAUX ENCADRÉS',
      pied: 'TFL — Excellencia Building · encadrement', photo: c.photo || null, signature: okSig(c.signature) ? c.signature : undefined, logo: 'icon-192.png' });
    root.EXBForm.download(blob, 'Attestation-encadrement-' + String(c.nom || 'encadreur').replace(/[^A-Za-z0-9]+/g, '-').slice(0, 40) + '.pdf');
  }
  /* Rappel de sauvegarde : les données TFL vivent sur cet appareil ; sans sauvegarde récente, un téléphone perdu = tout perdu. */
  function dernierSauvegarde() { try { return (root.localStorage && root.localStorage.getItem('exb_tfl_last_backup')) || ''; } catch (e) { return ''; } }
  function joursDepuisSauvegarde() { var t = dernierSauvegarde(); if (!t) return null; var dt = new Date(t); return isNaN(dt.getTime()) ? null : Math.floor((Date.now() - dt.getTime()) / 86400000); }
  function bandeauSauvegarde() {
    if (!L.dos().length && !L.enc().length) return '';
    var j = joursDepuisSauvegarde(); if (j !== null && j < 7) return '';
    return '<div style="margin:8px 0;padding:10px 12px;border-radius:10px;background:#fff7e6;border:1px solid #f0c36d;color:#7a4b00;font-size:13px"><b>💾 ' + (j === null ? 'Aucune sauvegarde faite sur cet appareil.' : 'Dernière sauvegarde il y a ' + j + ' jours.') + '</b> Vos données TFL sont sur cet appareil : sauvegardez-les maintenant.'
      + ' <button type="button" class="primary" data-tfl="export" style="padding:5px 10px;margin-left:6px">💾 Sauvegarder</button></div>';
  }

  /* ---------- API publique (testable) ---------- */
  var CORE = { importer: importer, attribuerMatricule: attribuerMatricule, fixerMatricule: fixerMatricule, setStatut: setStatut, affecter: affecter,
               patchDossier: patchDossier, basculerEncadreur: basculerEncadreur, ajouterEncadreur: ajouterEncadreur, etudiants: L.etu, dossiers: L.dos, encadreurs: L.enc, K: K,
               portail: { accesAPublier: accesAPublier, snapEtudiant: snapEtudiant, snapEncadreur: snapEncadreur, appliquerRetours: appliquerRetours, appliquerProgression: appliquerProgression,
                          messageAdmin: messageAdmin, messages: msgsLocaux, nonLus: nonLus, marquerLus: marquerLus, normId: normId, genCode: genCode, cle: cleAcces, KC: KC } };
  CORE.biblio = { liste: biblio, ajouter: bibAjouter, modifier: bibModifier, statut: bibStatut, supprimer: bibSupprimer, fichier: bibFichier, joindre: bibJoindre, depuisDossier: bibDepuisDossier, versDossier: bibVersDossier, chercher: bibChercher, csv: bibCsv, EXT: BEXT, MAX: BMAX };
  CORE.sujets = { liste: sujets, ajouter: sujetAjouter, modifier: sujetModifier, publier: sujetPublier, publierLot: sujetsPublierLot, filtrer: mesFichesFiltre, statut: sujetStatut, supprimer: sujetSupprimer, appliquerEtat: sujetsAppliquerEtat, pourServeur: sujetsPourServeur, jsonPublic: sujetsJsonPublic, csv: sujetsCsv, CATS: CATS, DISPO: DISPO, MENTION: BMENTION };
  CORE.banque_sujets = { charger: banqueCharger, chercher: banqueChercher, fiche: banqueFiche, adopter: banqueAdopter, items: function () { return BQ.items || []; }, domaines: function () { return BQ.data ? BQ.data.domaines : []; }, LOT: BQ_LOT, PAGE: BQ_PAGE };
  CORE.suivi = { chapitreAjouter: chapitreAjouter, planType: chapitrePlanType, chapitreStatut: chapitreStatut, chapitreSupprimer: chapitreSupprimer, correctionAjouter: correctionAjouter, correctionBasculer: correctionBasculer, progressionAuto: progressionAuto,
                 rdvAjouter: rdvAjouter, rdvBasculer: rdvBasculer, rdvSupprimer: rdvSupprimer, rdvIcs: rdvIcs, defenseEnregistrer: defenseEnregistrer, echeances: echeances, tableau: tableau, rapportCsv: rapportCsv };
  CORE.encadreur = { attestation: encadrementPdf, operateur: operateur, joursDepuisSauvegarde: joursDepuisSauvegarde, demandeAppliquer: demandeAppliquer, texteDecisionDossier: texteDecisionDossier, texteDecisionProp: texteDecisionProp, texteMatricule: texteMatricule, importer: importerEncadreur, valider: encadreurValider, decider: propositionDecider, appliquerValidation: appliquerValidation, statuts: statutsAPublier, PROP: PROP, VALID_ENC: VALID_ENC };
  root.EXBTFL = CORE;
  root.exbTflImport = function (o) { var r = importer(o); refresh(); return r; };
  if (typeof document === 'undefined') return;

  /* ---------- INTERFACE ---------- */
  var ST = { ctb: { rows: [], busy: false, err: '', msg: '', n: 0 }, sel: '', q: '', f: 'tous', vue: 'dossiers', msg: '', bib: { onglet: 'tfl', q: '', dom: 'tous', msg: '', busy: false, edit: '' }, sj: { edit: '', ouvert: false, busy: false, err: '', msg: '', at: '', max: 40, sel: {}, fq: '', fp: 'tous', fc: 'tous', auto: true }, bq: { ouvert: false, q: '', dom: '', page: 0, err: '', msg: '' }, en: { n: 0, err: '', busy: false, at: '' }, pt: { busy: false, err: '', msg: '', liste: {}, at: '' } };
  /* points d'entrée de l'écran, utilisés par les tests (tools/test-tfl/test-portail.js) */
  CORE.ui = { state: ST, publierPortails: publierPortails, recupererRetours: recupererRetours, revoquerAcces: revoquerAcces, listeServeur: listeServeur, vuePortails: vuePortails, blocMessages: blocMessages, lienPortail: lienPortail };
  function etuOf(d) { return L.etu().filter(function (x) { return x.id === d.etudiant_id; })[0] || {}; }
  function encOf(d) { return L.enc().filter(function (x) { return x.id === d.encadreur_id; })[0] || null; }
  function waLink(tel, texte) {
    var n = digits(tel); if (/^0\d{8,9}$/.test(n)) n = '243' + n.slice(1);
    return 'https://wa.me/' + n + '?text=' + encodeURIComponent(texte);
  }
  function badge(s) {
    var c = { recu: '#2563eb', en_verification: '#b45309', complement_demande: '#9333ea', accepte: '#15803d', refuse: '#b91c1c', clos: '#475569' }[s] || '#475569';
    return '<span style="display:inline-block;padding:2px 9px;border-radius:99px;background:' + c + ';color:#fff;font-size:12px;font-weight:700">' + esc(LBL(STATUTS, s)) + '</span>';
  }
  function opts(list, cur) { return list.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === cur ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }

  function fileText(f) { return new Promise(function (ok, ko) { var r = new FileReader(); r.onload = function () { ok(r.result); }; r.onerror = function () { ko(new Error('lecture impossible.')); }; r.readAsText(f); }); }
  async function importFiles(files) {
    files = [].slice.call(files || []); if (!files.length) return;
    var ok = [], dup = [], fail = [];
    for (var i = 0; i < files.length; i++) {
      try {
        var o; try { o = JSON.parse(await fileText(files[i])); } catch (e) { throw new Error('fichier illisible (ce n’est pas un fichier JSON).'); }
        if (o && o.form === 'EXB_TFL_ENC') { var re = importerEncadreur(o); if (re.dup) dup.push(files[i].name); else ok.push(esc(re.nom) + ' → encadreur, matricule ' + esc(re.matricule) + ' · ' + re.sujets + ' sujet(s) <button type="button" class="muted" data-tfl="matWa" data-k="enc" data-id="' + esc(re.encadreur.id) + '" style="padding:3px 8px">💬 Envoyer le matricule</button>'); continue; }
        var r = importer(o); if (r.dup) dup.push(files[i].name); else ok.push(esc(r.nom) + ' → ' + esc(r.numero) + ' · matricule ' + esc(r.matricule) + (r.maj ? ' (complément)' : '') + ' <button type="button" class="muted" data-tfl="matWa" data-k="etu" data-id="' + esc(r.etudiant.id) + '" style="padding:3px 8px">💬 Envoyer le matricule</button>');
      } catch (e) { fail.push(esc(files[i].name) + ' : ' + esc(e.message || e)); }
    }
    ST.msg = (ok.length ? '<b style="color:#15803d">✓ ' + ok.length + ' copie(s) enregistrée(s)</b><br>' + ok.join('<br>') + '<br><span class="hint">Le matricule est attribué automatiquement ; ouvrez chaque dossier pour décider.</span>' : '')
      + (dup.length ? '<br><span class="hint">Déjà importé(s) : ' + dup.map(esc).join(', ') + '</span>' : '') + (fail.length ? '<br><b style="color:#b91c1c">✗ ' + fail.join('<br>✗ ') + '</b>' : '');
    if (ok.length) say(ok.length + ' candidature(s) TFL enregistrée(s).', 'success');
    refresh();
  }

  /* ---------- MODE EN LIGNE (Supabase) : lien Internet + réception des candidatures ---------- */
  function cfgServeur() {
    try { if (root.exbSb && root.exbSb.cfg) { var c = root.exbSb.cfg(); if (c && c.url && c.key) return c; } } catch (e) { /* repli */ }
    var f = root.EXB_SUPABASE || {}; return f.url && f.key ? { url: String(f.url).replace(/\/+$/, ''), key: f.key } : null;
  }
  /* Adresse publique du formulaire : même dossier que le logiciel (Netlify…). */
  function baseSite() {
    if (!/^https?:$/.test((root.location || {}).protocol || '')) return '';
    return root.location.origin + root.location.pathname.replace(/[^\/]*$/, '');
  }
  function lienInternet(o) {
    var b = baseSite(); if (!b) return ''; var q = [];
    if (o && o.nom) q.push('n=' + encodeURIComponent(cut(o.nom, 120)));
    if (o && o.tel) q.push('t=' + encodeURIComponent(cut(o.tel, 40)));
    if (o && o.mail) q.push('e=' + encodeURIComponent(cut(o.mail, 120)));
    if (o && o.univ) q.push('u=' + encodeURIComponent(cut(o.univ, 150)));
    if (o && o.ref) q.push('r=' + encodeURIComponent(o.ref));
    return b + 'tfl-formulaire.html' + (q.length ? '?' + q.join('&') : '');
  }
  function saisiePrep() {
    var nom = cut(($('tflPnom') || {}).value, 120), tel = cut(($('tflPtel') || {}).value, 40), mail = cut(($('tflPmail') || {}).value, 120), univ = cut(($('tflPuniv') || {}).value, 150);
    return { nom: nom, tel: tel, mail: mail, univ: univ, ref: nom || tel ? 'REF-' + rid().slice(-6).toUpperCase() : '' };
  }
  async function copier(t) {
    try { await navigator.clipboard.writeText(t); return true; } catch (e) {
      try { var a = document.createElement('textarea'); a.value = t; a.style.position = 'fixed'; a.style.opacity = '0'; document.body.appendChild(a); a.select(); var ok = document.execCommand('copy'); a.remove(); return ok; } catch (x) { return false; }
    }
  }
  async function lienInternetAction(mode) {
    var o = saisiePrep(), url = lienInternet(o);
    if (!url) return say('Le lien Internet n’existe qu’une fois le logiciel hébergé en ligne (adresse https://…, par exemple Netlify). Ouvrez le logiciel depuis son adresse web puis réessayez.', 'warn');
    if (o.ref) { var p = get(K.prep, []); p.unshift({ ref: o.ref, nom: o.nom, telephone: o.tel, email: o.mail, at: now(), mode: 'internet' }); put(K.prep, p.slice(0, 300)); }
    var txt = 'Bonjour' + (o.nom ? ' ' + o.nom : '') + ', voici le lien pour déposer votre candidature TFL (Travail de Fin de Licence) : ' + url + '\nVous pouvez le remplir avec ou sans Internet.';
    if (mode === 'wa') { if (o.tel) root.open(waLink(o.tel, txt), '_blank'); else if (navigator.share) { try { await navigator.share({ title: 'Candidature TFL — Excellencia Building', text: txt }); } catch (e) { /* annulé */ } } else root.open('https://wa.me/?text=' + encodeURIComponent(txt), '_blank'); return; }
    ST.lien = url; say((await copier(url)) ? 'Lien Internet copié : collez-le dans WhatsApp, SMS ou e-mail.' : 'Lien prêt ci-dessous : copiez-le manuellement.', 'success'); refresh();
  }
  function erreurServeur(e) {
    var m = String((e && e.message) || e || '');
    if (/tfl_candidatures|schema cache|Could not find|does not exist|404/i.test(m)) return 'Le service TFL en ligne n’est pas encore activé : exécutez supabase/migration-v99zzr-tfl-en-ligne.sql dans Supabase (SQL Editor).';
    return m || 'erreur inconnue.';
  }
  /* V99zzy : l'importation d'une fiche étudiante par l'administrateur confirme son QR au registre (« Fiche déposée, non confirmée » → authentique).
     Le numéro est recalculé comme sur la fiche (téléphone + sujet) ; sans effet si la migration V99zzy n'est pas exécutée. */
  function confirmerFiche(sb, d) {
    try {
      var V = root.EXBVerif; d = d || {};
      if (!V || !V.sha256 || !d.annee_academique || !d.sujet_ref || !d.telephone) return;
      var tel = String(d.telephone).replace(/\D/g, ''), no = 'TFL-' + tel.slice(-4) + '-' + V.sha256(d.sujet_ref + '|' + tel).slice(0, 5).toUpperCase();
      Promise.resolve(sb.api('/rest/v1/rpc/exb_doc_confirmer', { method: 'POST', body: JSON.stringify({ p_no: no, p_nom: d.nom || null }) })).catch(function () {});
    } catch (e) { /* facultatif */ }
  }

  /* Interroge le serveur ; importe = true crée les dossiers, sinon compte seulement les nouvelles candidatures. */
  async function candidaturesEnLigne(importe) {
    var sb = root.exbSb;
    if (!sb || !sb.isIn || !sb.isIn()) { ST.en.err = 'Non connecté au serveur : ouvrez Inscription › Demandes reçues et connectez-vous (compte administrateur).'; ST.en.n = 0; refresh(); return { ok: false }; }
    if (ST.en.busy) return { ok: false };
    ST.en.busy = true; ST.en.err = '';
    try {
      var rows = await sb.api('/rest/v1/rpc/tfl_candidatures_liste', { method: 'POST', body: '{}' }) || [], neuves = rows.filter(function (r) { return !r.imported; });
      ST.en.n = neuves.length; ST.en.at = now();
      if (!importe) return { ok: true, n: neuves.length };
      var ok = [], dup = [], fail = [];
      for (var i = 0; i < neuves.length; i++) {
        var r = neuves[i];
        try {
          var res = importer({ form: 'EXB_TFL', version: 1, submitted_at: r.submitted_at || r.created_at, ref: r.ref || '', d: r.data || {}, photo: r.photo || '' });
          if (res.dup) dup.push(res.nom); else ok.push(esc(res.nom) + ' → ' + esc(res.numero) + ' · matricule ' + esc(res.matricule) + (res.maj ? ' (complément)' : '') + ' <button type="button" class="muted" data-tfl="matWa" data-k="etu" data-id="' + esc(res.etudiant.id) + '" style="padding:3px 8px">💬 Envoyer le matricule</button>');
          await sb.api('/rest/v1/rpc/tfl_candidature_traiter', { method: 'POST', body: JSON.stringify({ p_id: r.id }) });
          confirmerFiche(sb, r.data);
        } catch (e) { fail.push(esc((r.data && r.data.nom) || r.id) + ' : ' + esc(e.message || e)); }
      }
      ST.en.n = fail.length;
      ST.msg = (ok.length ? '<b style="color:#15803d">✓ ' + ok.length + ' candidature(s) reçue(s) en ligne et enregistrée(s)</b><br>' + ok.join('<br>') + '<br><span class="hint">Le matricule est attribué automatiquement ; ouvrez chaque dossier pour décider.</span>' : '')
        + (dup.length ? '<br><span class="hint">Déjà importé(s) : ' + dup.map(esc).join(', ') + '</span>' : '') + (fail.length ? '<br><b style="color:#b91c1c">✗ ' + fail.join('<br>✗ ') + '</b>' : '')
        + (!ok.length && !dup.length && !fail.length ? 'Aucune nouvelle candidature en ligne.' : '');
      if (ok.length) say(ok.length + ' candidature(s) TFL reçue(s) en ligne.', 'success');
      return { ok: true, n: ok.length };
    } catch (e) { ST.en.err = erreurServeur(e); return { ok: false }; }
    finally { ST.en.busy = false; refresh(); }
  }

  async function formulaireHtml(prefill, page) {
    var r = await fetch(page || 'tfl-formulaire.html', { cache: 'no-store' }); if (!r.ok) throw new Error('formulaire introuvable');
    var t = await r.text();
    var js = JSON.stringify(prefill || {}).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
    t = t.replace(/\/\*PREFILL\*\/[\s\S]*?\/\*END\*\//, function () { return '/*PREFILL*/' + js + '/*END*/'; });
    /* Clé PUBLIQUE du serveur incluse dans le fichier : l'étudiant pourra aussi l'envoyer en ligne s'il a Internet. */
    var c = cfgServeur(); if (c) { var cj = JSON.stringify({ url: c.url, key: c.key }).replace(/</g, '\\u003c'); t = t.replace(/\/\*SBCFG\*\/[\s\S]*?\/\*ENDSB\*\//, function () { return '/*SBCFG*/' + cj + '/*ENDSB*/'; }); }
    return t;
  }
  async function envoyerFormulaire(partager) {
    var nom = cut(($('tflPnom') || {}).value, 120), tel = cut(($('tflPtel') || {}).value, 40), mail = cut(($('tflPmail') || {}).value, 120), univ = cut(($('tflPuniv') || {}).value, 150);
    var ref = nom || tel ? 'REF-' + rid().slice(-6).toUpperCase() : '';
    try {
      var html = await formulaireHtml(ref ? { ref: ref, d: { nom: nom, telephone: tel, email: mail, universite: univ } } : {});
      var fn = 'Excellencia-Building-TFL' + (nom ? '-' + nom.replace(/[^a-z0-9]+/gi, '-').slice(0, 30) : '') + '.html', f = new File([new Blob([html], { type: 'text/html' })], fn, { type: 'text/html' });
      if (ref) { var p = get(K.prep, []); p.unshift({ ref: ref, nom: nom, telephone: tel, email: mail, at: now() }); put(K.prep, p.slice(0, 300)); }
      if (partager && navigator.canShare && navigator.canShare({ files: [f] })) {
        await navigator.share({ files: [f], title: 'Excellencia Building — Candidature TFL', text: 'Ouvrez ce fichier, remplissez votre candidature TFL (sans Internet) puis renvoyez-moi le fichier créé.' });
      } else {
        var a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = fn; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500);
        if (tel && partager) window.open(waLink(tel, 'Bonjour ' + nom + ', voici votre formulaire de candidature TFL (fichier joint). Remplissez-le sans Internet puis renvoyez-moi le fichier créé.'), '_blank');
        say('Formulaire TFL ' + (partager ? 'prêt : joignez-le dans WhatsApp ou par e-mail.' : 'téléchargé.'), 'success');
      }
      refresh();
    } catch (e) { if (e && e.name === 'AbortError') return; say('Impossible de préparer le formulaire : ' + (e.message || e) + ' (ouvrez le logiciel une fois en ligne : il sera ensuite disponible hors connexion).', 'error'); }
  }

  /* Sections du sujet pour le PDF : uniquement celles qui sont renseignées, dans l'ordre problématique → objectifs → méthodologie. */
  function sectionsSujet(d) {
    var out = [], defs = [['Titre du sujet', d.sujet_titre], ['Problématique', d.problematique], ['Objectifs', d.objectifs], ['Méthodologie', d.methodologie], ['Recherches déjà faites', d.recherches_deja]];
    defs.forEach(function (x) { var t = String(x[1] == null ? '' : x[1]).trim(); if (t) out.push([x[0], t]); });
    return out.length > 1 ? out : [];
  }

  async function fichePdf(d) {
    var e = etuOf(d), enc = encOf(d);
    if (!root.EXBForm || !root.EXBForm.pdfBlobAsync) return say('Module PDF indisponible.', 'error');
    var lignes = [['Numéro de dossier', d.numero], ['Étudiant', e.nom || ''], ['Matricule', e.matricule || 'à attribuer'], ['Université', e.universite || ''], ['Promotion / filière', [e.promotion, e.filiere].filter(Boolean).join(' — ')],
                  ['Domaine', LBL(DOMAINES, d.domaine)], ['Sujet', d.sujet_titre], ['Statut', LBL(STATUTS, d.statut)], ['Encadreur', enc ? enc.nom : 'non affecté'], ['Reçu le', String(d.depose_le || '').slice(0, 10)]];
    if (d.motif_decision) lignes.push(['Motif / observation', d.motif_decision]);
    /* QR de vérification (même système que les certificats et reçus) : enregistré au registre en ligne si l'administrateur est connecté. */
    var qr = '', code = '';
    try { var V = root.EXBVerif; if (V && V.docUrl && V.qrPng) { var cc = V.docUrl({ prefix: 'TFL', title: 'Attestation de dépôt TFL', sub: d.numero, nom: e.nom || '', matricule: e.matricule || '', date: String(d.depose_le || '').slice(0, 10) || undefined, digest: [d.numero, e.nom, d.sujet_titre].join('|') }); qr = V.qrPng(cc.url); code = String(cc.hash || '').toUpperCase(); } } catch (x) { qr = ''; }
    /* Contenu du sujet : problématique, objectifs, méthodologie (et recherches déjà faites) sur la page d'annexe de l'attestation. */
    var sections = sectionsSujet(d), notes = ['Cette attestation confirme la réception de la candidature. Elle ne vaut pas validation du sujet par l’université.'];
    if (sections.length) notes.push('Problématique, objectifs et méthodologie du sujet : voir la page 2 (annexe).');
    var blob = await root.EXBForm.pdfBlobAsync({ titre: 'ATTESTATION DE DÉPÔT — TFL', sousTitre: d.numero + (code ? ' · Code ' + code : ''), qr: qr || undefined, matricule: e.matricule || '', lignes: lignes,
      notes: notes, sections: sections, titreAnnexe: 'ANNEXE — SUJET DU TFL', pied: 'TFL — Excellencia Building · ' + d.numero, photo: e.photo || null, signature: okSig(e.signature) ? e.signature : undefined, logo: 'icon-192.png' });
    root.EXBForm.download(blob, d.numero + '.pdf');
  }

  function messageEtudiant(d, e) {
    var t = 'Bonjour ' + (e.nom || '') + ', votre candidature TFL est enregistrée.\nN° de dossier : ' + d.numero + '\n' + (e.matricule ? 'Matricule : ' + e.matricule + '\n' : '') + 'Statut : ' + LBL(STATUTS, d.statut);
    if (d.motif_decision && (d.statut === 'refuse' || d.statut === 'complement_demande')) t += '\nMotif : ' + d.motif_decision;
    return t + '\nExcellencia Building';
  }

  function header() {
    var D = L.dos(), c = {}; STATUTS.forEach(function (s) { c[s[0]] = 0; }); D.forEach(function (d) { c[d.statut] = (c[d.statut] || 0) + 1; });
    var prep = get(K.prep, []).filter(function (p) { return !p.retour; });
    return '<div class="exb-module-head"><div><h2>🎓 TFL — Travaux de Fin de Licence</h2><p class="exb-muted">Avec ou sans Internet, comme les apprenants : l’étudiant remplit le formulaire en ligne (lien) ou sans Internet (fichier), vous recevez sa candidature, elle est enregistrée avec son numéro de dossier et vous lui attribuez son matricule.</p></div></div>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(104px,1fr));gap:8px;margin:10px 0">' + STATUTS.map(function (s) {
        return '<button type="button" data-tfl="filtre" data-v="' + s[0] + '" style="padding:10px;border:1px solid #cbd5e1;border-radius:10px;background:' + (ST.f === s[0] ? '#173565;color:#fff' : '#fff;color:#173565') + ';text-align:left;cursor:pointer"><b style="font-size:20px">' + (c[s[0]] || 0) + '</b><br><small>' + esc(s[1]) + '</small></button>'; }).join('') + '</div>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>① Préparer et envoyer le formulaire</b><p class="localhint">Renseignez l’étudiant pour pré-remplir son formulaire (facultatif), puis choisissez comment l’envoyer : <b>lien Internet</b> (il envoie directement en ligne) ou <b>fichier hors ligne</b> (il le remplit sans Internet).</p>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px"><input id="tflPnom" placeholder="Nom de l’étudiant"><input id="tflPtel" type="tel" placeholder="Téléphone / WhatsApp"><input id="tflPmail" type="email" placeholder="E-mail"><input id="tflPuniv" placeholder="Université"></div>'
      + '<div style="margin-top:10px"><b>🌐 Lien Internet</b> <span class="hint">— le formulaire s’ouvre dans le navigateur ; s’il y a Internet l’étudiant envoie directement, sinon il garde le fichier.</span></div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button type="button" class="primary" data-tfl="lienCopier">🔗 Copier le lien</button><button type="button" class="muted" data-tfl="lienWa">💬 Envoyer par WhatsApp</button></div>'
      + (ST.lien ? '<input readonly onclick="this.select()" value="' + esc(ST.lien) + '" style="margin-top:6px;width:100%">' : '')
      + (baseSite() ? '' : '<div class="hint" style="margin-top:4px">Le lien Internet apparaît quand le logiciel est ouvert depuis son adresse web (https://…).</div>')
      + '<div style="margin-top:10px"><b>📴 Fichier hors ligne</b> <span class="hint">— à joindre dans WhatsApp ou par e-mail ; fonctionne sans aucune connexion.</span></div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button type="button" class="primary" data-tfl="envoyer">📤 Envoyer le fichier (WhatsApp…)</button><button type="button" class="muted" data-tfl="telecharger">⬇ Télécharger le fichier</button></div>'
      + (prep.length ? '<div class="hint" style="margin-top:6px">En attente de retour : ' + prep.slice(0, 6).map(function (p) { return esc(p.nom || p.telephone || p.ref); }).join(', ') + (prep.length > 6 ? '…' : '') + '</div>' : '') + '</div>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>② Recevoir les candidatures</b>'
      + '<p class="localhint"><b>En ligne :</b> les candidatures envoyées par le lien Internet arrivent sur le serveur ; récupérez-les ici (connexion administrateur requise : Inscription › Demandes reçues).</p>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><button type="button" class="primary" data-tfl="enligne"' + (ST.en.busy ? ' disabled' : '') + '>📡 Récupérer les candidatures en ligne' + (ST.en.n ? ' (' + ST.en.n + ' nouvelle' + (ST.en.n > 1 ? 's' : '') + ')' : '') + '</button>'
      + (ST.en.at ? '<span class="hint">vérifié à ' + esc(ST.en.at.slice(11, 16)) + ' UTC</span>' : '') + '</div>'
      + (ST.en.err ? '<div class="hint" style="margin-top:6px;color:#b91c1c">' + esc(ST.en.err) + '</div>' : '')
      + '<p class="localhint" style="margin-top:10px"><b>Hors ligne :</b> choisissez un ou plusieurs fichiers .json reçus des étudiants. Un fichier déjà importé n’est pas créé deux fois.</p><input type="file" id="tflFiles" accept="application/json,.json" multiple><div id="tflMsg" style="margin-top:8px;font-size:14px">' + ST.msg + '</div></div>';
  }

  function listeDossiers() {
    var q = norm(ST.q), D = L.dos().filter(function (d) {
      if (ST.f !== 'tous' && d.statut !== ST.f) return false;
      var e = etuOf(d); return !q || norm([d.numero, d.sujet_titre, e.nom, e.matricule, e.telephone, e.universite].join(' ')).indexOf(q) >= 0;
    }).sort(function (a, b) { return String(b.created_at).localeCompare(String(a.created_at)); });
    return '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0"><input id="tflQ" placeholder="Rechercher : nom, matricule, n° de dossier, sujet…" value="' + esc(ST.q) + '" style="flex:2;min-width:200px">'
      + (ST.f !== 'tous' ? '<button type="button" class="muted" data-tfl="filtre" data-v="tous">Tous les statuts</button>' : '') + '<button type="button" class="muted" data-tfl="vue" data-v="tableau">📊 Tableau de bord</button><button type="button" class="muted" data-tfl="vue" data-v="encadreurs">👨‍🏫 Encadreurs</button><button type="button" class="muted" data-tfl="vue" data-v="portails">🔐 Portails' + (nonLus() ? ' (' + nonLus() + ')' : '') + '</button><button type="button" class="muted" data-tfl="vue" data-v="biblio">📚 Bibliothèque' + (sujetsAEtudier() ? ' (' + sujetsAEtudier() + ' à étudier)' : '') + '</button><button type="button" class="muted" data-tfl="vue" data-v="sujets">📋 Sujets' + (sujetsReserves() ? ' (' + sujetsReserves() + ' réservé' + (sujetsReserves() > 1 ? 's' : '') + ')' : '') + '</button><button type="button" class="muted" data-tfl="vue" data-v="plans">📐 Plans' + (plansReserves() ? ' (' + plansReserves() + ' réservé' + (plansReserves() > 1 ? 's' : '') + ')' : '') + '</button><button type="button" class="muted" data-tfl="vue" data-v="signatures">✍️ Signatures</button><button type="button" class="muted" data-tfl="export">⬇ Sauvegarde</button><label class="muted" style="cursor:pointer;padding:8px 12px;border-radius:8px;background:#eef2f7;margin:0">⬆ Restaurer<input type="file" id="tflRest" accept=".json" hidden></label></div>'
      + (D.length ? D.map(function (d) {
        var e = etuOf(d); return '<div data-tfl="ouvrir" data-id="' + esc(d.id) + '" style="display:flex;gap:10px;align-items:center;border:1px solid ' + (ST.sel === d.id ? '#173565' : '#dce3ed') + ';border-radius:10px;padding:10px;margin:6px 0;cursor:pointer;background:#fff">'
          + (okPhoto(e.photo) ? '<img src="' + e.photo + '" alt="" style="width:44px;height:54px;object-fit:cover;border-radius:6px">' : '<div style="width:44px;height:54px;border-radius:6px;background:#eef2f7;display:flex;align-items:center;justify-content:center">🎓</div>')
          + '<div style="flex:1;min-width:0"><b>' + esc(e.nom || '—') + '</b> <small style="color:#667085">' + esc(d.numero) + ' · ' + (e.matricule ? 'matricule ' + esc(e.matricule) : '<span style="color:#b45309">sans matricule</span>') + '</small><br><span style="font-size:13px;color:#334155">' + esc(d.sujet_titre) + '</span></div>' + badge(d.statut) + '</div>'; }).join('')
        : '<div class="hint" style="padding:14px;text-align:center">Aucun dossier' + (ST.f !== 'tous' || q ? ' pour ce filtre' : ' pour le moment — importez une copie reçue') + '.</div>');
  }

  /* Fiche étudiante complète : photo + année académique, promotion, spécialité et autres informations. */
  function ficheEtudiant(e) {
    var R = [['Année académique', e.annee_academique], ['Promotion', e.promotion], ['Spécialité / filière', e.filiere], ['Faculté / département', e.faculte], ['Niveau', e.niveau], ['Université', e.universite],
             ['Matricule universitaire', e.matricule_univ], ['Date de naissance', e.date_naissance], ['Lieu de naissance', e.lieu_naissance], ['Nationalité', e.nationalite], ['Adresse', e.adresse]].filter(function (r) { return r[1]; });
    if (!R.length && !okPhoto(e.photo) && !okSig(e.signature)) return '';
    return '<div id="tflFiche" style="display:flex;gap:12px;flex-wrap:wrap;border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:8px 0;background:#fff"><div>'
      + (okPhoto(e.photo) ? '<img src="' + e.photo + '" alt="" style="width:96px;height:120px;object-fit:cover;border-radius:8px">' : '<div style="width:96px;height:120px;border-radius:8px;background:#f1f4f9;display:flex;align-items:center;justify-content:center;font-size:12px;color:#667085;text-align:center">Pas de photo</div>') + '</div>'
      + '<div style="flex:1;min-width:200px"><b>Fiche étudiante</b><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:6px 12px;margin-top:6px;font-size:14px">'
      + R.map(function (r) { return '<div><small style="color:#667085">' + esc(r[0]) + '</small><br><b>' + esc(r[1]) + '</b></div>'; }).join('') + '</div>'
      + (e.remarques ? '<p style="margin:8px 0 0;font-size:14px"><small style="color:#667085">Remarques</small><br>' + esc(e.remarques) + '</p>' : '')
      + (okSig(e.signature) ? '<p style="margin:8px 0 0"><small style="color:#667085">Signature de l’étudiant</small><br><img src="' + e.signature + '" alt="Signature" style="max-width:200px;max-height:70px;background:#fff;border:1px solid #e3e8f0;border-radius:6px;padding:4px"></p>' : '<p style="margin:8px 0 0;font-size:13px;color:#98a2b3">Signature de l’étudiant : non reçue</p>') + '</div></div>';
  }

  function detail(d) {
    var e = etuOf(d), enc = encOf(d), encs = L.enc().filter(function (x) { return x.actif !== false; }), H = get(K.his, []).filter(function (h) { return h.dossier_id === d.id; }).slice(0, 12);
    var F = function (l, v) { return v ? '<p style="margin:8px 0"><b>' + l + '</b><br>' + esc(v).replace(/\n/g, '<br>') + '</p>' : ''; };
    return '<div style="border:2px solid #173565;border-radius:12px;padding:14px;margin:10px 0;background:#fbfcfe" id="tflDetail">'
      + '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><div><h3 style="margin:0">' + esc(e.nom || '') + '</h3><small>' + esc(d.numero) + ' · ' + esc(LBL(DOMAINES, d.domaine)) + ' · ' + esc(e.universite || '') + (e.promotion ? ' · ' + esc(e.promotion) : '') + (e.filiere ? ' · ' + esc(e.filiere) : '') + '</small><br>' + badge(d.statut) + '</div>'
      + '<button type="button" class="muted" data-tfl="fermer">✕</button></div>'
      + (d.sujet_ref ? '<div style="margin:8px 0;padding:8px 10px;border-radius:8px;font-size:14px;background:' + (d.sujet_conflit ? '#fee2e2' : '#eef6ff') + '">📋 Sujet du catalogue : <b>' + esc(d.sujet_ref) + '</b>' + (d.sujet_conflit ? '<br><b>⚠ Ce sujet exclusif est déjà réservé pour un autre dossier.</b> Décidez entre les deux demandes ou proposez un autre sujet.' : '') + '</div>' : '')
      + ficheEtudiant(e)
      + '<p style="margin:8px 0;font-size:14px">📞 ' + esc(e.telephone || '') + (e.email ? ' · ✉ ' + esc(e.email) : '') + '</p>'
      + '<div style="border:1px dashed #c9a227;border-radius:10px;padding:10px;margin:8px 0;background:#fffdf4"><b>Matricule</b> : ' + (e.matricule ? '<span style="font-size:18px;font-weight:800;color:#173565">' + esc(e.matricule) + '</span>' : '<span style="color:#b45309">non attribué</span>' + (e.matricule_declare ? ' <small>(l’étudiant indique : ' + esc(e.matricule_declare) + ')</small>' : ''))
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">' + (e.matricule ? '' : '<button type="button" class="primary" data-tfl="matricule" data-e="' + esc(e.id) + '">🔢 Attribuer le matricule</button>')
      + '<input id="tflMat" placeholder="Saisir un matricule" style="max-width:190px" value="' + esc(e.matricule || '') + '"><button type="button" class="muted" data-tfl="matriculeMan" data-e="' + esc(e.id) + '">Enregistrer ce matricule</button></div></div>'
      + F('Encadreur pressenti', d.encadreur_pressenti) + F('Validation par l’encadreur', d.validation_encadreur ? valLabel(d.validation_encadreur) : '')
      + F('Titre du sujet', d.sujet_titre) + F('Problématique', d.problematique) + F('Objectifs', d.objectifs) + F('Méthodologie', d.methodologie) + F('Recherches déjà faites', d.recherches_deja)
      + '<h4 style="margin:14px 0 6px">Décision</h4><textarea id="tflMotif" placeholder="Motif (obligatoire pour « Refusé » et « Complément demandé »)" style="width:100%;min-height:62px">' + esc(d.motif_decision || '') + '</textarea>'
      + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">' + STATUTS.map(function (s) { return '<button type="button" data-tfl="statut" data-v="' + s[0] + '" style="padding:8px 11px;border-radius:8px;border:1px solid #173565;background:' + (d.statut === s[0] ? '#173565;color:#fff' : '#fff;color:#173565') + ';cursor:pointer">' + esc(s[1]) + '</button>'; }).join('') + '</div><div style="margin-top:8px"><button type="button" class="muted" data-tfl="infoDos">💬 Informer l’étudiant du statut (WhatsApp)</button></div>'
      + '<h4 style="margin:14px 0 6px">Encadreur</h4><div style="display:flex;gap:8px;flex-wrap:wrap"><select id="tflEnc" style="flex:1;min-width:180px"><option value="">— Non affecté —</option>' + encs.slice().sort(function (a, b) { return ((b.domaines || []).indexOf(d.domaine) >= 0) - ((a.domaines || []).indexOf(d.domaine) >= 0); }).map(function (x) { var ok = (x.domaines || []).indexOf(d.domaine) >= 0, n = L.dos().filter(function (y) { return y.encadreur_id === x.id && y.statut === 'accepte'; }).length; return '<option value="' + esc(x.id) + '"' + (x.id === d.encadreur_id ? ' selected' : '') + (x.disponible === false ? ' disabled' : '') + '>' + (ok ? '★ ' : '') + esc(x.nom) + ' (' + n + '/' + esc(x.max_etudiants || 8) + ')' + (x.disponible === false ? ' — indisponible' : '') + '</option>'; }).join('') + '</select><button type="button" class="muted" data-tfl="affecter">Affecter</button></div>'
      + (enc ? '<small>Affecté à ' + esc(enc.nom) + '</small>' : (encs.length ? '' : '<small class="hint">Aucun encadreur : ajoutez-en via « 👨‍🏫 Encadreurs ».</small>'))
      + '<h4 style="margin:14px 0 6px">Analyse du sujet</h4><div style="display:flex;gap:12px;flex-wrap:wrap">' + CRITERES.map(function (c) { return '<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" class="tflCrit" data-c="' + c[0] + '"' + ((d.analyse || {})[c[0]] ? ' checked' : '') + ' style="width:auto"> ' + esc(c[1]) + '</label>'; }).join('') + '</div>'
      + '<textarea id="tflAnalyse" placeholder="Corrections à demander sur le sujet" style="width:100%;min-height:54px;margin-top:6px">' + esc((d.analyse || {}).notes || '') + '</textarea>'
      + '<h4 style="margin:14px 0 6px">Validation du sujet et avancement</h4><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">'
      + '<div><small>Sujet</small><select id="tflSujet">' + opts(SUJET, d.sujet_statut) + '</select></div><div><small>Validation université</small><select id="tflUniv">' + opts(UNIV, d.validation_univ) + '</select></div>'
      + '<div><small>Étape du parcours</small><select id="tflEtape">' + ETAPES.map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === d.etape ? ' selected' : '') + '>' + x[0] + ' — ' + esc(x[1]) + '</option>'; }).join('') + '</select></div><div><small>Progression (%)</small><input id="tflProg" type="number" min="0" max="100" value="' + esc(d.progression) + '"></div></div>'
      + '<p class="hint" style="margin:6px 0">« Validé par l’université » ne se coche qu’avec une validation réellement accordée par l’établissement ; ne jamais présenter un sujet comme validé officiellement sans cela.' + (d.domaine === 'genie_civil' || d.domaine === 'architecture' ? ' Pour les calculs de structure, dimensionnements et conceptions : contrôle technique par un professionnel qualifié.' : '') + '</p>'
      + '<label style="display:flex;gap:8px;align-items:center;margin:8px 0"><input type="checkbox" id="tflExb"' + (d.validation_exb ? ' checked' : '') + ' style="width:auto"> Validé par Excellencia Building</label>'
      + '<textarea id="tflObs" placeholder="Observation de l’encadreur" style="width:100%;min-height:54px">' + esc(d.observation_encadreur || '') + '</textarea><button type="button" class="primary" data-tfl="suivi" style="margin-top:6px">Enregistrer le suivi</button>'
      + blocSuivi(d)
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px"><button type="button" class="muted" data-tfl="pdf">📄 Attestation de dépôt (PDF)</button>' + ((d.statut === 'clos' || (d.etape || 1) >= 9) ? '<button type="button" class="muted" data-tfl="bDepuisDos">📚 Garder dans la bibliothèque</button>' : '') + ''
      + (e.telephone ? '<a class="muted" target="_blank" rel="noopener" href="' + esc(waLink(e.telephone, messageEtudiant(d, e))) + '" style="padding:10px 14px;border-radius:8px;background:#eef2f7;color:#173565;text-decoration:none;font-weight:700">💬 Informer l’étudiant (WhatsApp)</a>' : '') + '</div>'
      + blocMessages(d)
      + (H.length ? '<h4 style="margin:14px 0 6px">Historique</h4><div style="font-size:12px;color:#475569">' + H.map(function (h) { return esc(h.at.slice(0, 16).replace('T', ' ')) + ' — ' + esc(h.action) + (h.apres ? ' → ' + esc(Object.keys(h.apres).map(function (k) { return h.apres[k]; }).filter(Boolean).join(' · ')) : '') + (h.par ? ' <i>(par ' + esc(h.par) + ')</i>' : ''); }).join('<br>') + '</div>' : '')
      + '</div>';
  }

  function vueEncadreurs() {
    var D = L.dos();
    return '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>👨‍🏫 Encadreurs</h3><div style="margin:6px 0"><button type="button" class="primary" data-tfl="vue" data-v="propositions">🧑‍🏫 Formulaire encadreur, matricule et sujets proposés</button></div>'
      + (L.enc().map(function (x) { var n = D.filter(function (d) { return d.encadreur_id === x.id && d.statut === 'accepte'; }).length;
        return '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:6px 0"><b>' + esc(x.nom) + '</b> <small>' + esc(x.telephone || '') + ' ' + esc(x.email || '') + '</small><br><small>' + esc((x.domaines || []).map(function (k) { return LBL(DOMAINES, k); }).join(', ') || 'domaines non précisés') + (x.specialites ? ' · ' + esc(x.specialites) : '') + '</small><br><small>Charge : ' + n + ' / ' + esc(x.max_etudiants) + ' dossier(s) accepté(s)</small> <button type="button" class="muted" data-tfl="dispo" data-id="' + esc(x.id) + '">' + (x.disponible === false ? '⛔ Indisponible — rendre disponible' : '✅ Disponible — rendre indisponible') + '</button></div>'; }).join('') || '<div class="hint">Aucun encadreur enregistré.</div>')
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin-top:10px"><b>Ajouter un encadreur</b><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:8px"><input id="tflCn" placeholder="Nom *"><input id="tflCt" type="tel" placeholder="Téléphone"><input id="tflCe" type="email" placeholder="E-mail"><input id="tflCm" type="number" min="1" value="8" title="Nombre maximal d’étudiants"><input id="tflCs" placeholder="Spécialités (structures, routes…)"></div><div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px">' + DOMAINES.map(function (x) { return '<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" class="tflDom" value="' + x[0] + '" style="width:auto"> ' + esc(x[1]) + '</label>'; }).join('') + '</div><button type="button" class="primary" data-tfl="addEnc" style="margin-top:8px">Ajouter</button></div>';
  }

  /* ---------- PORTAILS : serveur et écran (V99zzt) ---------- */
  function lienPortail(role) { var b = baseSite(); return b ? b + 'tfl-portail.html?role=' + role : ''; }
  async function adminRpc(fn, body) {
    var sb = root.exbSb;
    if (!sb || !sb.isIn || !sb.isIn()) throw new Error('Non connecté au serveur : ouvrez Inscription › Demandes reçues et connectez-vous (compte administrateur).');
    return sb.api('/rest/v1/rpc/' + fn, { method: 'POST', body: JSON.stringify(body || {}) });
  }
  function erreurPortail(e) {
    var m = String((e && e.message) || e || '');
    if (/tfl_portail|tfl_acces|tfl_messages|schema cache|Could not find|does not exist|404/i.test(m)) return 'Les portails TFL ne sont pas encore activés : exécutez supabase/migration-v99zzt-tfl-portails.sql dans Supabase (SQL Editor).';
    if (/non autoris/i.test(m)) return 'Compte non autorisé : connectez-vous avec un e-mail administrateur.';
    return m || 'erreur inconnue.';
  }
  function telDe(a) {
    var r = a.role === 'etudiant' ? L.etu() : L.enc(), x = r.filter(function (y) { return y.id === a.ref; })[0]; return x ? (x.telephone || '') : '';
  }
  async function publierPortails(opts) {
    opts = opts || {}; if (ST.pt.busy) return; ST.pt.busy = true; ST.pt.err = ''; ST.pt.msg = ''; refresh();
    try {
      var r = accesAPublier(), acc = get(K.acc, []), codes = get(KC, {}), nouveaux = [], maj = 0, ko = [], rev = 0;
      for (var i = 0; i < r.acces.length; i++) {
        var a = r.acces[i], cle = cleAcces(a.role, a.ident), ex = acc.filter(function (x) { return x.cle === cle; })[0], code = (!ex || opts.reset === cle) ? genCode() : '';
        try {
          /* même étudiant ou encadreur, identifiant changé : l'ancien accès est désactivé */
          for (var j = acc.length - 1; j >= 0; j--) {
            if (acc[j].ref === a.ref && acc[j].role === a.role && acc[j].cle !== cle) {
              await adminRpc('tfl_portail_revoquer', { p_role: acc[j].role, p_ident: acc[j].ident }); delete codes[acc[j].cle]; acc.splice(j, 1); rev++;
            }
          }
          try { await adminRpc('tfl_portail_publier', { p_role: a.role, p_ident: a.ident, p_nom: a.nom, p_code: code, p_contenu: a.contenu }); }
          catch (e1) {
            if (!code && /code_requis/.test(String((e1 && e1.message) || e1))) { code = genCode(); await adminRpc('tfl_portail_publier', { p_role: a.role, p_ident: a.ident, p_nom: a.nom, p_code: code, p_contenu: a.contenu }); }
            else throw e1;
          }
          var rec = { cle: cle, role: a.role, ident: a.ident, nom: a.nom, ref: a.ref, publie_le: now(), actif: true };
          if (ex) { rec.cree_le = ex.cree_le; } else rec.cree_le = now();
          if (code) { codes[cle] = code; rec.code_le = now(); nouveaux.push(rec); } else { rec.code_le = ex ? ex.code_le : ''; maj++; }
          var k = acc.map(function (x) { return x.cle; }).indexOf(cle); if (k >= 0) acc[k] = rec; else acc.push(rec);
        } catch (e) { ko.push(esc(a.nom || a.ident) + ' : ' + esc(erreurPortail(e))); if (/pas encore activés|non autoris|Non connecté/.test(erreurPortail(e))) { ST.pt.err = erreurPortail(e); break; } }
      }
      put(K.acc, acc); put(KC, codes);
      ST.pt.at = now();
      ST.pt.msg = '<b style="color:#15803d">✓ ' + (nouveaux.length + maj) + ' accès publié(s) ou mis à jour</b>' + (nouveaux.length ? ' dont ' + nouveaux.length + ' nouveau(x) : envoyez-leur le lien et le mot de passe de départ (boutons ci-dessous).' : '.')
        + (rev ? '<br>' + rev + ' ancien(s) accès désactivé(s) (identifiant changé).' : '')
        + (r.sans_matricule.length ? '<br><span style="color:#b45309">Sans matricule (pas d’accès) : ' + r.sans_matricule.map(esc).join(', ') + '. Attribuez-leur un matricule puis republiez.</span>' : '')
        + (ko.length ? '<br><b style="color:#b91c1c">✗ ' + ko.join('<br>✗ ') + '</b>' : '')
        + (!r.acces.length ? '<br>Aucun accès à publier : il faut un dossier accepté avec matricule, ou un encadreur affecté.' : '');
      if (!ST.pt.err) { try { await listeServeur(true); } catch (e) { /* facultatif */ } }
      if (nouveaux.length) say(nouveaux.length + ' nouvel accès TFL publié.', 'success');
      trace('TFL_PORTAILS', (nouveaux.length + maj) + ' accès');
    } catch (e) { ST.pt.err = erreurPortail(e); }
    finally { ST.pt.busy = false; refresh(); }
  }
  async function listeServeur(silencieux) {
    var rows = await adminRpc('tfl_portail_liste', {}) || [], m = {}; rows.forEach(function (x) { m[cleAcces(x.role, x.identifiant)] = x; }); ST.pt.liste = m; return m;
  }
  async function recupererRetours() {
    if (ST.pt.busy) return; ST.pt.busy = true; ST.pt.err = ''; ST.pt.msg = ''; refresh();
    try {
      var rows = await adminRpc('tfl_portail_retours', {}) || [];
      if (!rows.length) { ST.pt.msg = 'Aucun nouveau message.'; return; }
      var res = appliquerRetours(rows);
      await adminRpc('tfl_portail_retours_traiter', { p_ids: res.ids });
      ST.pt.msg = '<b style="color:#15803d">✓ ' + res.recus + ' message(s) reçu(s)</b>' + (res.dup ? '<br>' + res.dup + ' déjà reçu(s).' : '')
        + (res.refuses ? '<br><span style="color:#b45309">' + res.refuses + ' message(s) ignoré(s) : dossier ou accès ne correspondant plus aux données de cet appareil.</span>' : '')
        + '<br><span class="hint">Ouvrez le dossier concerné pour lire et répondre.</span>';
      if (res.recus) say(res.recus + ' message(s) TFL reçu(s) des portails.', 'success');
    } catch (e) { ST.pt.err = erreurPortail(e); }
    finally { ST.pt.busy = false; refresh(); }
  }
  async function revoquerAcces(cle) {
    var acc = get(K.acc, []), a = acc.filter(function (x) { return x.cle === cle; })[0]; if (!a) return;
    if (typeof root.confirm === 'function' && !root.confirm('Désactiver l’accès de ' + (a.nom || a.ident) + ' ? Il ne pourra plus se connecter (vous pourrez le republier plus tard).')) return;
    try { await adminRpc('tfl_portail_revoquer', { p_role: a.role, p_ident: a.ident }); a.actif = false; put(K.acc, acc); var c = get(KC, {}); delete c[cle]; put(KC, c); say('Accès désactivé.', 'success'); }
    catch (e) { ST.pt.err = erreurPortail(e); }
    refresh();
  }
  function envoiAcces(cle, mode) {
    var a = get(K.acc, []).filter(function (x) { return x.cle === cle; })[0]; if (!a) return;
    var tel = telDe(a), url = lienPortail(a.role), code = get(KC, {})[cle], t;
    if (mode === 'code') { if (!code) return say('Mot de passe de départ inconnu sur cet appareil : utilisez « Nouveau mot de passe ».', 'warn'); t = 'Mot de passe de départ de votre espace TFL : ' + code + '\nVous devrez le remplacer dès votre première connexion. Ne le partagez pas.'; }
    else { if (!url) return say('Le lien n’existe qu’une fois le logiciel ouvert depuis son adresse web (https://…).', 'warn'); t = 'Bonjour ' + (a.nom || '') + ', votre espace TFL ' + (a.role === 'encadreur' ? 'encadreur' : 'étudiant') + ' est ouvert.\nLien : ' + url + '\nIdentifiant : ' + a.ident + '\nLe mot de passe de départ vous est envoyé dans un message séparé.\nExcellencia Building'; }
    root.open(tel ? waLink(tel, t) : 'https://wa.me/?text=' + encodeURIComponent(t), '_blank');
  }
  async function copierLienPortail(role) {
    var u = lienPortail(role); if (!u) return say('Le lien n’existe qu’une fois le logiciel ouvert depuis son adresse web (https://…).', 'warn');
    say((await copier(u)) ? 'Lien copié.' : 'Copiez-le manuellement : ' + u, 'success');
  }
  function vuePortails() {
    var acc = get(K.acc, []), codes = get(KC, {}), srv = ST.pt.liste || {}, nl = nonLus(), D = L.dos(), etus = L.etu();
    var sans = D.filter(function (d) { var e = etus.filter(function (x) { return x.id === d.etudiant_id; })[0]; return d.statut === 'accepte' && e && !e.matricule; }).length;
    var lignes = acc.sort(function (a, b) { return a.role === b.role ? String(a.nom).localeCompare(String(b.nom)) : (a.role < b.role ? -1 : 1); }).map(function (a) {
      var s = srv[a.cle], etat = a.actif === false ? '<span style="color:#b91c1c">⛔ désactivé</span>' : (s ? (s.actif === false ? '<span style="color:#b91c1c">⛔ désactivé</span>' : (s.doit_changer ? '<span style="color:#b45309">mot de passe de départ pas encore changé</span>' : '<span style="color:#15803d">✓ actif · ' + esc(s.connexions) + ' connexion(s)</span>')) : '<span class="hint">état non vérifié</span>');
      return '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:6px 0"><b>' + esc(a.nom || '—') + '</b> <small>' + (a.role === 'encadreur' ? '👨‍🏫 encadreur' : '🎓 étudiant') + ' · identifiant <b>' + esc(a.ident) + '</b></small><br><small>' + etat + (s && s.derniere_connexion ? ' · dernière connexion ' + esc(String(s.derniere_connexion).slice(0, 16).replace('T', ' ')) : '') + ' · publié le ' + esc(String(a.publie_le || '').slice(0, 10)) + '</small>'
        + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px"><button type="button" class="muted" data-tfl="ptWaLien" data-k="' + esc(a.cle) + '">💬 Lien + identifiant</button>'
        + (codes[a.cle] ? '<button type="button" class="muted" data-tfl="ptWaCode" data-k="' + esc(a.cle) + '">💬 Mot de passe de départ</button>' : '')
        + '<button type="button" class="muted" data-tfl="ptReset" data-k="' + esc(a.cle) + '">🔑 Nouveau mot de passe</button>'
        + (a.actif === false ? '' : '<button type="button" class="muted" data-tfl="ptRevoquer" data-k="' + esc(a.cle) + '">⛔ Désactiver</button>') + '</div></div>';
    }).join('');
    return '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>🔐 Portails étudiant et encadreur</h3>'
      + '<p class="localhint">Chaque étudiant accepté (avec matricule) et chaque encadreur affecté a un espace en ligne avec <b>connexion</b> : l’étudiant suit son dossier, son avancement et ses messages ; l’encadreur voit ses étudiants, envoie commentaires et propose la progression. Le serveur ne garde qu’une copie de ce qu’ils ont le droit de voir : vos dossiers restent sur cet appareil. Republiez après chaque changement important.</p>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><button type="button" class="primary" data-tfl="ptPublier"' + (ST.pt.busy ? ' disabled' : '') + '>📡 Publier / mettre à jour les portails</button>'
      + '<button type="button" class="primary" data-tfl="ptRetours"' + (ST.pt.busy ? ' disabled' : '') + '>📥 Récupérer les messages reçus' + (nl ? ' (' + nl + ' non lu' + (nl > 1 ? 's' : '') + ')' : '') + '</button>'
      + '<button type="button" class="muted" data-tfl="ptListe"' + (ST.pt.busy ? ' disabled' : '') + '>🔄 Vérifier l’état des accès</button></div>'
      + (sans ? '<div class="hint" style="margin-top:6px;color:#b45309">' + sans + ' dossier(s) accepté(s) sans matricule : pas d’accès tant que le matricule n’est pas attribué.</div>' : '')
      + (ST.pt.err ? '<div class="hint" style="margin-top:6px;color:#b91c1c">' + esc(ST.pt.err) + '</div>' : '')
      + (ST.pt.msg ? '<div style="margin-top:8px;font-size:14px">' + ST.pt.msg + '</div>' : '')
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:10px 0"><b>Liens de connexion</b>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><button type="button" class="muted" data-tfl="ptLien" data-v="etudiant">🔗 Lien étudiant</button><button type="button" class="muted" data-tfl="ptLien" data-v="encadreur">🔗 Lien encadreur</button></div>'
      + (baseSite() ? '<div class="hint" style="margin-top:4px">' + esc(lienPortail('etudiant')) + '<br>' + esc(lienPortail('encadreur')) + '</div>' : '<div class="hint" style="margin-top:4px">Les liens apparaissent quand le logiciel est ouvert depuis son adresse web (https://…).</div>') + '</div>'
      + '<h4 style="margin:12px 0 4px">Accès ouverts (' + acc.length + ')</h4>' + (lignes || '<div class="hint">Aucun accès publié pour le moment.</div>')
      + '<p class="hint">Le mot de passe de départ (6 chiffres) est généré ici et reste sur cet appareil ; envoyez-le dans un message séparé du lien. La personne le remplace à sa première connexion : vous ne pouvez plus le lire ensuite, seulement en générer un nouveau.</p>';
  }

  /* ---------- V99zzzzzz : Contributions d'anciens (lien public → sujet + TFL résolu → bibliothèque) ---------- */
  var CTB_MIME = { pdf: 'application/pdf', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', odt: 'application/vnd.oasis.opendocument.text', rtf: 'application/rtf', txt: 'text/plain', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', zip: 'application/zip', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png' };
  function lienContrib() { var b = baseSite(); return b ? b + 'tfl-contribution.html' : ''; }
  async function contribLienAction(mode) {
    var url = lienContrib();
    if (!url) return say('Le lien Internet n’existe qu’une fois le logiciel hébergé en ligne (adresse https://…). Ouvrez le logiciel depuis son adresse web puis réessayez.', 'warn');
    var tel = cut(($('tflCtel') || {}).value, 40), nom = cut(($('tflCnom') || {}).value, 120);
    if (tel || nom) url += '?' + [nom ? 'n=' + encodeURIComponent(nom) : '', tel ? 't=' + encodeURIComponent(tel) : ''].filter(Boolean).join('&');
    var txt = 'Bonjour' + (nom ? ' ' + nom : '') + ', si vous avez déjà terminé votre TFL, déposez ici votre sujet et votre travail : ' + url + '\nIls serviront de guide méthodologique aux futurs étudiants (Excellencia Building).';
    if (mode === 'wa') { if (tel) root.open(waLink(tel, txt), '_blank'); else if (navigator.share) { try { await navigator.share({ title: 'Déposer mon TFL — Excellencia Building', text: txt }); } catch (e) { /* annulé */ } } else root.open('https://wa.me/?text=' + encodeURIComponent(txt), '_blank'); return; }
    ST.ctb.lien = url; say((await copier(url)) ? 'Lien copié : collez-le dans WhatsApp, SMS ou e-mail.' : 'Lien prêt ci-dessous : copiez-le manuellement.', 'success'); refresh();
  }
  function erreurContrib(e) {
    var m = String((e && e.message) || e || '');
    if (/tfl_contribution|schema cache|Could not find|does not exist|404/i.test(m)) return 'Le service des contributions n’est pas encore activé : exécutez supabase/migration-v99zzzzzz-tfl-contributions.sql dans Supabase (SQL Editor).';
    return m || 'erreur inconnue.';
  }
  async function contribRecuperer() {
    var sb = root.exbSb, C = ST.ctb;
    if (!sb || !sb.isIn || !sb.isIn()) { C.err = 'Non connecté au serveur : ouvrez Inscription › Demandes reçues et connectez-vous (compte administrateur).'; refresh(); return; }
    if (C.busy) return; C.busy = true; C.err = ''; C.msg = ''; refresh();
    try { C.rows = (await sb.api('/rest/v1/rpc/tfl_contributions_liste', { method: 'POST', body: '{}' }) || []).filter(function (r) { return !r.imported; }); C.n = C.rows.length; C.msg = C.rows.length ? '' : 'Aucune nouvelle contribution.'; }
    catch (e) { C.err = erreurContrib(e); }
    finally { C.busy = false; refresh(); }
  }
  async function contribGarder(id) {
    var sb = root.exbSb, C = ST.ctb, r = C.rows.filter(function (x) { return String(x.id) === String(id); })[0]; if (!r || C.busy) return;
    C.busy = true; C.err = ''; C.msg = 'Téléchargement du fichier…'; refresh();
    try {
      var d = r.data || {}, f = null;
      if (r.fichier_nom) {
        var b64 = await sb.api('/rest/v1/rpc/tfl_contribution_fichier', { method: 'POST', body: JSON.stringify({ p_id: r.id }) });
        if (!b64) throw new Error('le fichier n’est plus sur le serveur : ajoutez la fiche seule ou joignez le fichier reçu par WhatsApp.');
        var bin = atob(b64), u8 = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        f = new File([u8], r.fichier_nom, { type: CTB_MIME[bext(r.fichier_nom)] || 'application/octet-stream' });
      }
      var res = await bibAjouter({ type: 'tfl', titre: d.titre, auteur: d.nom, annee: d.annee, universite: d.universite, domaine: d.domaine, encadreur: d.encadreur, mots_cles: d.mots_cles, resume: d.resume, telephone: d.telephone, consultation: d.consultation }, f);
      await sb.api('/rest/v1/rpc/tfl_contribution_traiter', { method: 'POST', body: JSON.stringify({ p_id: r.id }) });
      C.rows = C.rows.filter(function (x) { return x !== r; }); C.n = C.rows.length;
      C.msg = res.dup ? 'Ce fichier était déjà dans la bibliothèque : contribution marquée traitée.' : '✓ « ' + esc(d.titre) + ' » ajouté aux TFL résolus de la bibliothèque.';
      say(res.dup ? 'Déjà dans la bibliothèque.' : 'Contribution ajoutée à la bibliothèque.', 'success');
    } catch (e) { C.err = erreurContrib(e); C.msg = ''; }
    finally { C.busy = false; refresh(); }
  }
  function vueContrib() {
    var C = ST.ctb, tout = biblio(), nT = tout.filter(function (x) { return x.type === 'tfl'; }).length, nS = tout.filter(function (x) { return x.type === 'sujet'; }).length;
    var tab = function (k, t) { return '<button type="button" data-tfl="bOnglet" data-v="' + k + '" style="padding:9px 14px;border-radius:10px;border:1px solid #173565;cursor:pointer;background:' + (k === 'contrib' ? '#173565;color:#fff' : '#fff;color:#173565') + '">' + t + '</button>'; };
    var card = function (r) {
      var d = r.data || {}, meta = [d.nom, d.annee, d.universite, LBL(DOMAINES, d.domaine), d.encadreur ? 'encadreur : ' + d.encadreur : ''].filter(Boolean).map(esc).join(' · ');
      return '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:6px 0;background:#fff"><b>📕 ' + esc(d.titre) + '</b><br><small style="color:#667085">' + meta + '</small>'
        + (d.resume ? '<div style="font-size:13px;color:#334155;margin-top:4px">' + esc(String(d.resume).slice(0, 240)) + (String(d.resume).length > 240 ? '…' : '') + '</div>' : '')
        + '<div style="margin-top:4px"><small style="color:#667085">' + (r.fichier_nom ? esc(r.fichier_nom) + ' · ' + tailleTxt(r.fichier_taille) : 'aucun fichier joint') + ' · ' + (d.consultation === 'oui' ? '👁 autorise le partage' : '🔒 archivage seulement') + '</small></div>'
        + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button type="button" class="primary" data-tfl="cGarder" data-id="' + esc(r.id) + '"' + (C.busy ? ' disabled' : '') + ' style="padding:6px 10px">📚 Garder dans la bibliothèque</button>'
        + (d.telephone ? '<a class="muted" target="_blank" rel="noopener" href="' + esc(waLink(d.telephone, 'Bonjour ' + (d.nom || '') + ', nous avons bien reçu votre TFL « ' + (d.titre || '') + ' ». Merci pour votre contribution !')) + '" style="padding:6px 10px;border-radius:8px;background:#eef2f7;color:#173565;text-decoration:none">💬 Remercier</a>' : '') + '</div></div>';
    };
    return '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>📚 Bibliothèque TFL</h3>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">' + tab('tfl', '🎓 TFL résolus (' + nT + ')') + tab('sujet', '📥 Sujets reçus (' + nS + ')') + tab('contrib', '🤝 Contributions' + (C.n ? ' (' + C.n + ' nouvelle' + (C.n > 1 ? 's' : '') + ')' : '')) + '</div>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>🔗 Inviter des anciens à déposer leur TFL</b>'
      + '<p class="localhint">Envoyez ce lien à ceux qui ont déjà résolu leur sujet : ils y déposent leur <b>sujet</b>, leur <b>travail</b> (PDF, Word…, 3 Mo max.) et disent s’ils autorisent le partage. Vous le gardez ensuite dans la bibliothèque, pour les années à venir.</p>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px"><input class="tflB" id="tflCnom" placeholder="Nom (facultatif)"><input class="tflB" id="tflCtel" type="tel" placeholder="Téléphone WhatsApp (facultatif)"></div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button type="button" class="primary" data-tfl="cLien">🔗 Copier le lien</button><button type="button" class="muted" data-tfl="cWa">💬 Envoyer par WhatsApp</button></div>'
      + (C.lien ? '<div style="margin-top:6px;word-break:break-all;font-size:13px"><b>' + esc(C.lien) + '</b></div>' : '') + '</div>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>📥 Contributions reçues en ligne</b>'
      + '<div style="margin-top:8px"><button type="button" class="primary" data-tfl="cRecup"' + (C.busy ? ' disabled' : '') + '>' + (C.busy ? '⏳ En cours…' : '📡 Récupérer les contributions') + '</button></div>'
      + (C.err ? '<p class="err" style="color:#b91c1c;font-weight:700">' + esc(C.err) + '</p>' : '') + (C.msg ? '<p class="hint">' + C.msg + '</p>' : '')
      + C.rows.map(card).join('') + '</div>'
      + '<p class="localhint">Les fiches gardées passent dans <b>🎓 TFL résolus</b> : vous y gérez la mention « consultation autorisée » et pouvez télécharger ou envoyer le document à d’autres apprenants. Le fichier est conservé sur <b>cet appareil</b> (voir la note de la bibliothèque) ; il est retiré du serveur une fois gardé.</p>';
  }

  /* ---------- Écran « Bibliothèque » ---------- */
  function sujetsAEtudier() { return biblio().filter(function (x) { return x.type === 'sujet' && x.statut === 'a_etudier'; }).length; }
  function tailleTxt(n) { n = n || 0; return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function bibAccept() { return BEXT.map(function (e) { return '.' + e; }).join(','); }
  function bibEdition(x) {
    var I = function (id, l, v, t) { return '<div><small>' + l + '</small><input id="' + id + '" ' + (t ? 'type="' + t + '" ' : '') + 'value="' + esc(v) + '"></div>'; };
    return '<div style="border:1px dashed #173565;border-radius:10px;padding:10px;margin-top:8px;background:#f8fafc"><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">'
      + I('tflEt', 'Titre', x.titre) + I('tflEa', x.type === 'sujet' ? 'Nom' : 'Auteur', x.auteur) + (x.type === 'sujet' ? I('tflEtel', 'Téléphone / WhatsApp', x.telephone, 'tel') : I('tflEe', 'Encadreur', x.encadreur)) + I('tflEy', 'Année', x.annee, 'number')
      + (x.type === 'tfl' ? '<div><small>Consultation autorisée</small><select id="tflEc"><option value="non"' + (x.consultation === 'oui' ? '' : ' selected') + '>Non</option><option value="oui"' + (x.consultation === 'oui' ? ' selected' : '') + '>Oui</option></select></div>' : '')
      + I('tflEu', 'Université', x.universite) + '<div><small>Domaine</small><select id="tflEd">' + opts(DOMAINES, x.domaine) + '</select></div>' + I('tflEk', 'Mots-clés', x.mots_cles) + '</div>'
      + '<small>' + (x.type === 'sujet' ? 'Résumé / problématique' : 'Résumé') + '</small><textarea id="tflEr" style="width:100%;min-height:54px">' + esc(x.resume) + '</textarea>'
      + '<div style="display:flex;gap:8px;margin-top:6px"><button type="button" class="primary" data-tfl="bEditOk">Enregistrer</button><button type="button" class="muted" data-tfl="bEditAnnule">Annuler</button></div></div>';
  }
  function bibLigne(x) {
    var sujet = x.type === 'sujet', ouvrable = ['pdf', 'jpg', 'jpeg', 'png', 'txt'].indexOf(x.fichier_type) >= 0, dos = x.dossier_numero ? L.dos().filter(function (d) { return d.numero === x.dossier_numero; })[0] : null;
    var btn = function (a, t) { return '<button type="button" class="muted" data-tfl="' + a + '" data-id="' + esc(x.id) + '" style="padding:6px 10px">' + t + '</button>'; };
    var meta = [x.auteur, x.annee, x.universite, LBL(DOMAINES, x.domaine), x.encadreur ? 'encadreur : ' + x.encadreur : ''].filter(Boolean).map(esc).join(' · ');
    var msg = 'Bonjour ' + (x.auteur || '') + ', nous avons bien reçu votre sujet « ' + x.titre + ' » (TFL — Excellencia Building). Statut : ' + LBL(SUJET, x.statut) + '.' + (x.dossier_numero ? ' Votre dossier : ' + x.dossier_numero + '.' : '');
    return '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:6px 0;background:#fff">'
      + '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><div style="min-width:0"><b>' + (x.fichier_type === 'pdf' ? '📕 ' : x.fichier_nom ? '📎 ' : '📝 ') + esc(x.titre) + '</b><br><small style="color:#667085">' + meta + '</small></div>'
      + (sujet ? '<span style="padding:3px 9px;border-radius:99px;background:#eef2f7;font-size:12px;white-space:nowrap">' + esc(LBL(SUJET, x.statut)) + '</span>' : '') + '</div>'
      + (!sujet ? '<div style="margin-top:4px"><span style="padding:2px 8px;border-radius:99px;font-size:12px;background:' + (x.consultation === 'oui' ? '#dcfce7;color:#166534' : '#fee2e2;color:#991b1b') + '">' + (x.consultation === 'oui' ? '👁 Consultation autorisée' : '🔒 Consultation non autorisée') + '</span></div>' : '')
      + (x.mots_cles ? '<div style="margin-top:4px"><small>🏷 ' + esc(x.mots_cles) + '</small></div>' : '')
      + (x.resume ? '<div style="font-size:13px;color:#334155;margin-top:4px">' + esc(x.resume.slice(0, 240)) + (x.resume.length > 240 ? '…' : '') + '</div>' : '')
      + '<div style="margin-top:4px"><small style="color:#667085">' + (x.fichier_nom ? esc(x.fichier_nom) + ' · ' + tailleTxt(x.fichier_taille) : 'aucun fichier joint') + (x.dossier_numero ? ' · dossier ' + esc(x.dossier_numero) : '') + '</small></div>'
      + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">'
      + (x.fichier_nom ? (ouvrable ? btn('bOuvrir', '👁 Ouvrir') : '') + btn('bTelecharger', '⬇ Télécharger')
          : '<label class="muted" style="cursor:pointer;padding:6px 10px;border-radius:8px;background:#eef2f7;margin:0">📎 Joindre un fichier<input type="file" class="tflBjoin" data-id="' + esc(x.id) + '" accept="' + bibAccept() + '" style="display:none"></label>')
      + (sujet ? SUJET.map(function (st) { return '<button type="button" data-tfl="bStatut" data-id="' + esc(x.id) + '" data-v="' + st[0] + '" style="padding:6px 10px;border-radius:8px;border:1px solid #173565;cursor:pointer;background:' + (x.statut === st[0] ? '#173565;color:#fff' : '#fff;color:#173565') + '">' + esc(st[1]) + '</button>'; }).join('') : '')
      + (sujet && !x.dossier_numero ? btn('bVersDossier', '➡ Créer le dossier') : '')
      + (dos ? '<button type="button" class="muted" data-tfl="bOuvrirDos" data-n="' + esc(dos.numero) + '" style="padding:6px 10px">📂 Dossier ' + esc(dos.numero) + '</button>' : '')
      + (sujet && x.telephone ? '<a class="muted" target="_blank" rel="noopener" href="' + esc(waLink(x.telephone, msg)) + '" style="padding:6px 10px;border-radius:8px;background:#eef2f7;color:#173565;text-decoration:none">💬 WhatsApp</a>' : '')
      + (!sujet ? btn('bConsult', x.consultation === 'oui' ? '🔒 Retirer la consultation' : '👁 Autoriser la consultation') : '')
      + btn('bEdit', '✏ Modifier') + btn('bSuppr', '🗑 Supprimer') + '</div>'
      + (ST.bib.edit === x.id ? bibEdition(x) : '') + '</div>';
  }
  function vueBiblio() {
    if (ST.bib.onglet === 'contrib') return vueContrib();
    var B = ST.bib, tout = biblio(), nT = tout.filter(function (x) { return x.type === 'tfl'; }).length, nS = tout.filter(function (x) { return x.type === 'sujet'; }).length, sujet = B.onglet === 'sujet';
    var liste = bibChercher(B.q, B.onglet, B.dom);
    var tab = function (k, t) { return '<button type="button" data-tfl="bOnglet" data-v="' + k + '" style="padding:9px 14px;border-radius:10px;border:1px solid #173565;cursor:pointer;background:' + (B.onglet === k ? '#173565;color:#fff' : '#fff;color:#173565') + '">' + t + '</button>'; };
    var I = function (id, ph, t) { return '<input class="tflB" id="' + id + '" ' + (t ? 'type="' + t + '" ' : '') + 'placeholder="' + ph + '">'; };
    return '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>📚 Bibliothèque TFL</h3>'
      + '<div style="background:#fff8e1;border:1px solid #e6c65a;border-radius:8px;padding:8px 10px;font-size:13px">⚠ ' + esc(BMENTION) + ' Chaque travail réalisé porte une mention « consultation autorisée » (oui / non).</div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">' + tab('tfl', '🎓 TFL résolus (' + nT + ')') + tab('sujet', '📥 Sujets reçus (' + nS + (sujetsAEtudier() ? ', ' + sujetsAEtudier() + ' à étudier' : '') + ')') + tab('contrib', '🤝 Contributions') + '</div>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>' + (sujet ? '📥 Recevoir un sujet' : '⬆ Importer un TFL résolu') + '</b>'
      + '<p class="localhint">' + (sujet ? 'Une personne veut être encadrée : elle vous envoie son sujet (WhatsApp, e-mail…) en <b>PDF, Word, photo</b> ou autre format. Enregistrez le fichier reçu ici, étudiez-le, répondez-lui par WhatsApp, puis créez son dossier de candidature.'
          : 'Gardez ici les TFL déjà résolus (PDF, Word…) avec une fiche pour les retrouver. Vous pouvez choisir <b>plusieurs fichiers</b> à la fois : le titre est alors pris dans le nom de chaque fichier.') + '</p>'
      + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">' + I('tflBt', 'Titre' + (sujet ? ' du sujet' : '')) + I('tflBa', sujet ? 'Nom de la personne *' : 'Auteur') + (sujet ? I('tflBtel', 'Téléphone / WhatsApp', 'tel') : I('tflBe', 'Encadreur'))
      + I('tflBy', 'Année', 'number') + I('tflBu', 'Université') + '<select class="tflB" id="tflBd">' + opts(DOMAINES, 'genie_civil') + '</select>' + (sujet ? '' : '<select class="tflB" id="tflBc" title="Consultation autorisée"><option value="non">Consultation : non</option><option value="oui">Consultation : oui</option></select>') + I('tflBk', 'Mots-clés (béton, route, fondation…)') + '</div>'
      + '<textarea class="tflB" id="tflBr" placeholder="' + (sujet ? 'Résumé ou problématique (facultatif)' : 'Résumé (facultatif)') + '" style="width:100%;min-height:54px;margin-top:8px"></textarea>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px"><input type="file" id="tflBf" multiple accept="' + bibAccept() + '" style="flex:1;min-width:180px"><button type="button" class="primary" data-tfl="bAjouter"' + (B.busy ? ' disabled' : '') + '>' + (B.busy ? 'Enregistrement…' : 'Ajouter à la bibliothèque') + '</button></div>'
      + '<div class="hint" style="margin-top:4px">Formats : ' + BEXT.join(', ') + ' · 25 Mo maximum par fichier · sans fichier, la fiche seule est enregistrée.</div>'
      + '<div id="tflBmsg" style="margin-top:8px;font-size:14px">' + B.msg + '</div></div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0"><input id="tflBq" placeholder="Rechercher : titre, auteur, année, mots-clés…" value="' + esc(B.q) + '" style="flex:2;min-width:200px"><select id="tflBdom" style="min-width:140px"><option value="tous">Tous les domaines</option>' + opts(DOMAINES, B.dom) + '</select><button type="button" class="muted" data-tfl="bCsv">⬇ Catalogue (CSV)</button></div>'
      + (liste.length ? liste.map(bibLigne).join('') : '<div class="hint" style="padding:14px;text-align:center">' + (B.q || B.dom !== 'tous' ? 'Aucun résultat pour cette recherche.' : sujet ? 'Aucun sujet reçu pour le moment.' : 'Aucun TFL résolu pour le moment — importez vos fichiers ci-dessus.') + '</div>')
      + '<div class="hint" style="margin-top:8px">Les fichiers restent sur <b>cet appareil</b> (ils ne sont pas dans « ⬇ Sauvegarde », qui garde seulement les fiches) : conservez aussi vos originaux.</div>';
  }
  function bibMsg(ok, dup, fail) {
    return (ok.length ? '<b style="color:#15803d">✓ ' + ok.length + ' ajouté(s)</b><br>' + ok.map(esc).join('<br>') : '') + (dup.length ? '<br><span class="hint">Déjà dans la bibliothèque : ' + dup.map(esc).join(', ') + '</span>' : '')
      + (fail.length ? '<br><b style="color:#b91c1c">✗ ' + fail.map(esc).join('<br>✗ ') + '</b>' : '');
  }
  async function bibAjouterAction() {
    var B = ST.bib, val = function (i) { var e = $(i); return e ? e.value : ''; }, fi = $('tflBf'), files = fi && fi.files ? [].slice.call(fi.files) : [];
    if (B.busy) return;
    var base = { type: B.onglet, titre: val('tflBt'), auteur: val('tflBa'), annee: val('tflBy'), universite: val('tflBu'), domaine: val('tflBd'), encadreur: val('tflBe'), mots_cles: val('tflBk'), resume: val('tflBr'), telephone: val('tflBtel'), consultation: val('tflBc') };
    var ok = [], dup = [], fail = [];
    try { files.forEach(bverifFichier); } catch (e) { say(e.message || String(e), 'error'); var m0 = $('tflBmsg'); if (m0) m0.innerHTML = '<b style="color:#b91c1c">✗ ' + esc(e.message || e) + '</b>'; return; }
    B.busy = true; var bt = document.querySelector('[data-tfl="bAjouter"]'); if (bt) { bt.disabled = true; bt.textContent = 'Enregistrement…'; }
    try {
      var liste = files.length ? files : [null];
      for (var i = 0; i < liste.length; i++) {
        var o = {}; Object.keys(base).forEach(function (k) { o[k] = base[k]; }); if (liste.length > 1) o.titre = '';
        try { var r = await bibAjouter(o, liste[i]); if (r.dup) dup.push(liste[i].name); else ok.push(r.entree.titre); } catch (e) { fail.push((liste[i] ? liste[i].name + ' : ' : '') + (e.message || e)); }
      }
    } finally { B.busy = false; }
    B.msg = bibMsg(ok, dup, fail);
    if (ok.length) { ['tflBt', 'tflBr', 'tflBk', 'tflBtel'].concat(B.onglet === 'sujet' ? ['tflBa'] : []).forEach(function (i) { var e = $(i); if (e) e.value = ''; }); say(ok.length + ' élément(s) ajouté(s) à la bibliothèque.', 'success'); }
    if (ok.length || dup.length) refresh(); else { var m1 = $('tflBmsg'); if (m1) m1.innerHTML = B.msg; var b2 = document.querySelector('[data-tfl="bAjouter"]'); if (b2) { b2.disabled = false; b2.textContent = 'Ajouter à la bibliothèque'; } }
  }
  async function bibJoindreAction(id, f) {
    try { await bibJoindre(id, f); say('Fichier joint à la fiche.', 'success'); } catch (e) { say(e.message || String(e), 'error'); try { alert(e.message || e); } catch (x) { /* ignoré */ } }
    refresh();
  }
  async function bibOuvrir(id, telecharger) {
    var en = biblio().filter(function (x) { return x.id === id; })[0], w = null;
    try {
      if (!en) throw new Error('fiche introuvable.');
      if (!telecharger) w = root.open('', '_blank');
      var blob = await bibFichier(id), url = URL.createObjectURL(blob);
      if (w) w.location.href = url; else { var a = document.createElement('a'); a.href = url; a.download = en.fichier_nom; document.body.appendChild(a); a.click(); a.remove(); }
      setTimeout(function () { URL.revokeObjectURL(url); }, 120000);
    } catch (e) { if (w) { try { w.close(); } catch (x) { /* ignoré */ } } say(e.message || String(e), 'error'); try { alert(e.message || e); } catch (x) { /* ignoré */ } }
  }
  function bibTelechargerCsv() {
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bibCsv()], { type: 'text/csv;charset=utf-8' })); a.download = 'bibliotheque-TFL-' + now().slice(0, 10) + '.csv'; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500);
  }


  /* ---------- Écran « Sujets » (catalogue) ---------- */
  function sujetsReserves() { return sujets().filter(function (x) { return x.statut === 'reserve'; }).length; }
  function lienSujets() { var b = baseSite(); return b ? b + 'tfl-sujets.html' : ''; }
  function sujetForm(x) {
    x = x || {}; var I = function (id, l, v, t, ph) { return '<div><small>' + l + '</small><input class="tflS" id="' + id + '" ' + (t ? 'type="' + t + '" ' : '') + 'value="' + esc(v || '') + '"' + (ph ? ' placeholder="' + esc(ph) + '"' : '') + '></div>'; };
    var T = function (id, l, v) { return '<div style="grid-column:1/-1"><small>' + l + '</small><textarea class="tflS" id="' + id + '" style="width:100%;min-height:62px">' + esc(v || '') + '</textarea></div>'; };
    return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">'
      + (x.ref ? '<div><small>Référence</small><input id="tflSref" value="' + esc(x.ref) + '" disabled></div>' : I('tflSref', 'Référence (vide = automatique)', '', '', 'EXB-TFL-BTP-0001'))
      + '<div style="grid-column:1/-1"><small>Intitulé *</small><input class="tflS" id="tflSt" value="' + esc(x.titre || '') + '" style="width:100%"></div>'
      + '<div><small>Catégorie</small><select class="tflS" id="tflSc">' + opts(CATS, x.categorie || 'autre') + '</select></div>'
      + '<div><small>Domaine</small><select class="tflS" id="tflSd">' + opts(DOMAINES, x.domaine || 'genie_civil') + '</select></div>'
      + I('tflSf', 'Filière', x.filiere) + I('tflSn', 'Niveau', x.niveau, '', 'Ex. L3') + I('tflSk', 'Mots-clés', x.mots_cles)
      + T('tflSp', 'Problématique *', x.problematique) + T('tflSo', 'Objectifs *', x.objectifs) + T('tflSm', 'Méthodologie', x.methodologie)
      + T('tflSl', 'Livrables attendus', x.livrables) + T('tflSq', 'Compétences visées', x.competences) + T('tflSe', 'Encadrement prévu', x.encadrement)
      + '<div><small>Exclusif ?</small><select class="tflS" id="tflSx"><option value="1"' + (x.exclusif === false ? '' : ' selected') + '>Oui : un seul étudiant à la fois</option><option value="0"' + (x.exclusif === false ? ' selected' : '') + '>Non : plusieurs étudiants possibles</option></select></div></div>'
      + '<div style="display:flex;gap:8px;margin-top:8px"><button type="button" class="primary" data-tfl="sjOk">' + (x.ref ? 'Enregistrer' : 'Ajouter au catalogue') + '</button>' + (x.ref || ST.sj.ouvert ? '<button type="button" class="muted" data-tfl="sjAnnule">Annuler</button>' : '') + '</div>';
  }
  function sujetSaisie() {
    var v = function (i) { return ($(i) || {}).value; };
    return { ref: v('tflSref'), titre: v('tflSt'), categorie: v('tflSc'), domaine: v('tflSd'), filiere: v('tflSf'), niveau: v('tflSn'), mots_cles: v('tflSk'), problematique: v('tflSp'), objectifs: v('tflSo'), methodologie: v('tflSm'),
             livrables: v('tflSl'), competences: v('tflSq'), encadrement: v('tflSe'), exclusif: v('tflSx') !== '0' };
  }
  function sujetLigne(x) {
    var btn = function (a, t, v) { return '<button type="button" class="muted" data-tfl="' + a + '" data-id="' + esc(x.ref) + '"' + (v ? ' data-v="' + v + '"' : '') + ' style="padding:6px 10px">' + t + '</button>'; };
    var couleur = { disponible: '#dcfce7;color:#166534', reserve: '#fef3c7;color:#92400e', attribue: '#dbeafe;color:#1e40af', ferme: '#e5e7eb;color:#374151' }[x.statut] || '#eef2f7;color:#173565';
    var dos = x.dossier_numero ? L.dos().filter(function (d) { return d.numero === x.dossier_numero; })[0] : null;
    return '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:6px 0;background:#fff">'
      + '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><div style="display:flex;gap:10px;min-width:0"><input type="checkbox" data-tfl="sjSel" data-id="' + esc(x.ref) + '"' + (ST.sj.sel && ST.sj.sel[x.ref] ? ' checked' : '') + ' aria-label="Sélectionner cette fiche" style="width:22px;height:22px;flex:none;margin:2px 0 0"><div style="min-width:0"><small style="color:#667085">' + esc(x.ref) + '</small><br><b>' + esc(x.titre) + '</b><br><small style="color:#667085">' + [LBL(CATS, x.categorie), x.filiere, x.niveau].filter(Boolean).map(esc).join(' · ') + '</small></div></div>'
      + '<span style="padding:3px 9px;border-radius:99px;font-size:12px;white-space:nowrap;background:' + couleur + '">' + esc(LBL(DISPO, x.statut)) + '</span></div>'
      + '<div style="margin-top:4px;font-size:12px;color:#667085">' + (x.publie ? '🌐 Publié' : '🔒 Non publié') + ' · ' + (x.exclusif === false ? 'plusieurs étudiants possibles' : 'exclusif') + (x.dossier_numero ? ' · dossier ' + esc(x.dossier_numero) : '') + (x.push ? ' · <b>à synchroniser</b>' : '') + '</div>'
      + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">'
      + btn('sjPublie', x.publie ? '🔒 Retirer du public' : '🌐 Publier')
      + (x.statut !== 'disponible' ? btn('sjStatut', '↩ Libérer', 'disponible') : '') + (x.statut === 'reserve' && x.exclusif !== false ? btn('sjStatut', '✔ Attribuer', 'attribue') : '') + (x.statut !== 'ferme' ? btn('sjStatut', '⛔ Fermer', 'ferme') : '')
      + (dos ? '<button type="button" class="muted" data-tfl="bOuvrirDos" data-n="' + esc(dos.numero) + '" style="padding:6px 10px">📂 Dossier ' + esc(dos.numero) + '</button>' : '')
      + btn('sjEdit', '✏ Modifier') + btn('sjSuppr', '🗑 Supprimer') + '</div>'
      + (ST.sj.edit === x.ref ? '<div style="border:1px dashed #173565;border-radius:10px;padding:10px;margin-top:8px;background:#f8fafc">' + sujetForm(x) + '</div>' : '') + '</div>';
  }
  function vueBanque() {
    var B = ST.bq, card = function (h) { return '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0">' + h + '</div>'; };
    if (!B.ouvert) return card('<button type="button" class="primary" data-tfl="bqOuvrir">📚 Banque de 4 300 sujets proposés</button><div class="hint" style="margin-top:6px">2 600 sujets (13 domaines) + 1 700 sujets BTP (17 domaines). Cherchez, ajoutez à vos fiches, contextualisez, faites valider par un encadreur, puis publiez.</div>');
    if (!BQ.items) return card('<b>📚 Banque de sujets</b><div style="margin-top:6px">' + (B.err ? '<span style="color:#b91c1c">✗ ' + esc(B.err) + '</span><br><button type="button" class="muted" data-tfl="bqOuvrir" style="margin-top:6px">Réessayer</button>' : 'Chargement de la banque…') + '</div><button type="button" class="muted" data-tfl="bqFermer" style="margin-top:6px">Fermer</button>');
    var D = BQ.data.domaines, liste = banqueChercher({ q: B.q, dom: B.dom }), pages = Math.max(1, Math.ceil(liste.length / BQ_PAGE)), have = {};
    if (B.page >= pages) B.page = pages - 1; if (B.page < 0) B.page = 0;
    sujets().forEach(function (x) { have[x.ref] = 1; });
    var libres = liste.filter(function (it) { return !have[it.ref]; }), vue = liste.slice(B.page * BQ_PAGE, (B.page + 1) * BQ_PAGE), srcs = [];
    D.forEach(function (d) { if (srcs.indexOf(d.src) < 0) srcs.push(d.src); });
    var sel = '<option value="">Tous les domaines (' + BQ.items.length + ')</option>' + srcs.map(function (sr) {
      return '<optgroup label="' + esc(sr) + '">' + D.map(function (d, i) { return d.src === sr ? '<option value="' + esc(d.k) + '"' + (B.dom === d.k ? ' selected' : '') + '>' + esc(d.nom) + ' (' + BQ.comptes[i] + ')</option>' : ''; }).join('') + '</optgroup>'; }).join('');
    var btnP = function (t, v, off) { return '<button type="button" class="muted" data-tfl="bqPage" data-v="' + v + '"' + (off ? ' disabled' : '') + ' style="padding:6px 10px">' + t + '</button>'; };
    return card('<div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>📚 Banque de sujets</b><button type="button" class="muted" data-tfl="bqFermer" style="padding:6px 10px">Fermer</button></div>'
      + '<p class="localhint">Ce sont des <b>propositions d’intitulés</b>, pas des sujets validés ni des mémoires réalisés. La fiche ajoutée est un modèle : contextualisez-la, vérifiez l’originalité et les données disponibles, et faites-la valider par un encadreur avant de la publier.</p>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap"><input id="tflGq" placeholder="Rechercher : béton, route, drainage, BIM…" value="' + esc(B.q) + '" style="flex:2;min-width:180px"><select id="tflGd" style="flex:1;min-width:170px">' + sel + '</select></div>'
      + '<div class="hint" style="margin:8px 0">' + liste.length + ' sujet' + (liste.length > 1 ? 's' : '') + ' · ' + libres.length + ' non encore ajouté' + (libres.length > 1 ? 's' : '') + ' à vos fiches (' + (liste.length - libres.length) + ' déjà ajouté' + (liste.length - libres.length > 1 ? 's' : '') + ')</div>'
      + (B.msg ? '<div style="margin:6px 0;font-size:14px">' + B.msg + '</div>' : '')
      + (libres.length && (B.q || B.dom) ? '<button type="button" class="muted" data-tfl="bqAddAll" style="margin-bottom:8px">➕ Ajouter ' + Math.min(libres.length, BQ_LOT) + ' résultat' + (Math.min(libres.length, BQ_LOT) > 1 ? 's' : '') + ' à mes fiches' + (libres.length > BQ_LOT ? ' (' + BQ_LOT + ' au plus par fois)' : '') + '</button>' : '')
      + (vue.length ? vue.map(function (it) {
          var d = D[it.di];
          return '<div style="border:1px solid #e5eaf1;border-radius:10px;padding:8px 10px;margin:5px 0;display:flex;gap:8px;align-items:flex-start;justify-content:space-between"><div style="min-width:0"><small style="color:#667085">' + esc(it.ref) + ' · ' + esc(d.nom) + '</small><br>' + esc(it.titre) + '</div>'
            + (have[it.ref] ? '<span style="font-size:12px;color:#166534;white-space:nowrap">✓ Ajouté</span>' : '<button type="button" class="muted" data-tfl="bqAdd" data-id="' + esc(it.ref) + '" style="padding:6px 10px;white-space:nowrap">➕ Ajouter</button>') + '</div>'; }).join('')
        : '<div class="hint" style="padding:12px;text-align:center">Aucun sujet pour cette recherche.</div>')
      + '<div style="display:flex;gap:8px;align-items:center;justify-content:center;margin-top:8px">' + btnP('◀', '-1', B.page <= 0) + '<span class="hint">Page ' + (B.page + 1) + ' / ' + pages + '</span>' + btnP('▶', '1', B.page >= pages - 1) + '</div>');
  }
  function vueMesFiches(liste) {
    var S = ST.sj; S.sel = S.sel || {};
    if (!liste.length) return '<div class="hint" style="padding:14px;text-align:center">Aucune fiche pour le moment : ajoutez-en depuis la banque ci-dessus ou créez-en une.</div>';
    var f = mesFichesFiltre(liste), max = S.max || 40, nSel = f.filter(function (x) { return S.sel[x.ref]; }).length,
        nNon = f.filter(function (x) { return !x.publie; }).length, nOui = f.length - nNon,
        opt = function (v, t, cur) { return '<option value="' + v + '"' + (cur === v ? ' selected' : '') + '>' + t + '</option>'; },
        cats = opt('tous', 'Toutes les catégories', S.fc || 'tous') + CATS.map(function (c) { return opt(c[0], esc(c[1]), S.fc); }).join(''),
        bt = function (a, t, cls, off) { return '<button type="button" class="' + cls + '" data-tfl="' + a + '"' + (off ? ' disabled' : '') + ' style="padding:8px 12px">' + t + '</button>'; };
    return '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>📦 Publier en groupe</b>'
      + '<div class="hint" style="margin:4px 0 8px">Filtrez, cochez les fiches voulues (ou « Sélectionner les résultats »), puis publiez-les ou retirez-les d’un seul geste. Les fiches incomplètes ne sont jamais publiées.</div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap"><input id="tflFq" placeholder="Filtrer : béton, route, référence…" value="' + esc(S.fq || '') + '" style="flex:2;min-width:170px">'
      + '<select id="tflFp" style="flex:1;min-width:130px">' + opt('tous', 'Toutes', S.fp || 'tous') + opt('non', 'Non publiées', S.fp) + opt('oui', 'Publiées', S.fp) + '</select>'
      + '<select id="tflFc" style="flex:1;min-width:160px">' + cats + '</select></div>'
      + '<div class="hint" style="margin:8px 0">' + f.length + ' fiche' + (f.length > 1 ? 's' : '') + ' · ' + nNon + ' non publiée' + (nNon > 1 ? 's' : '') + ' · ' + nOui + ' publiée' + (nOui > 1 ? 's' : '') + ' · <b>' + nSel + ' sélectionnée' + (nSel > 1 ? 's' : '') + '</b></div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap">' + bt('sjSelTous', '☑ Sélectionner les ' + f.length + ' résultat' + (f.length > 1 ? 's' : ''), 'muted', !f.length) + bt('sjSelAucun', '☐ Tout désélectionner', 'muted', !nSel) + '</div>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">' + bt('sjLotPub', '🌐 Publier la sélection (' + nSel + ')', 'primary', !nSel) + bt('sjLotRet', '🔒 Retirer la sélection (' + nSel + ')', 'muted', !nSel) + '</div>'
      + '<div style="margin-top:8px">' + bt('sjPubTout', '🌐 Publier toutes les non publiées affichées (' + nNon + ')', 'muted', !nNon) + '</div>'
      + '<label style="display:flex;gap:8px;align-items:center;margin-top:10px;font-size:14px"><input type="checkbox" id="tflFauto"' + (S.auto !== false ? ' checked' : '') + ' style="width:18px;height:18px"> Envoyer aussitôt au serveur (page publique)</label></div>'
      + '<div class="hint" style="margin:8px 0 2px">Mes fiches (' + liste.length + ') — les plus récentes d’abord</div>'
      + (f.length ? f.slice(0, max).map(sujetLigne).join('') + (f.length > max ? '<button type="button" class="muted" data-tfl="sjPlus" style="width:100%;margin-top:6px">Afficher plus (' + (f.length - max) + ' autres)</button>' : '')
        : '<div class="hint" style="padding:14px;text-align:center">Aucune fiche ne correspond à ce filtre.</div>');
  }
  function sujetsLotAction(a) {
    var S = ST.sj, oui = a !== 'sjLotRet', f = mesFichesFiltre(sujets()),
        cibles = a === 'sjPubTout' ? f.filter(function (x) { return !x.publie; }) : f.filter(function (x) { return S.sel && S.sel[x.ref]; });
    if (!cibles.length) { say('Aucune fiche à traiter.', 'warn'); return; }
    var banque = oui ? cibles.filter(function (x) { return x.source === 'banque'; }).length : 0,
        txt = (oui ? 'Publier ' : 'Retirer du public ') + cibles.length + ' fiche' + (cibles.length > 1 ? 's' : '') + ' ?' + (banque ? '\n\n' + banque + ' viennent de la banque : ce sont des modèles génériques. Confirmez qu’elles ont été relues et validées par un encadreur.' : '');
    if (typeof root.confirm === 'function' && !root.confirm(txt)) return;
    var r = sujetsPublierLot(cibles.map(function (x) { return x.ref; }), oui);
    S.sel = {}; S.err = '';
    var note = r.incomplets.length ? '<br><span style="color:#b45309">' + r.incomplets.length + ' ignorée' + (r.incomplets.length > 1 ? 's' : '') + ' car incomplète' + (r.incomplets.length > 1 ? 's' : '') + ' (problématique ou objectifs manquants) : ' + r.incomplets.slice(0, 5).map(esc).join(', ') + (r.incomplets.length > 5 ? '…' : '') + '</span>' : '';
    S.msg = '<b style="color:#15803d">✓ ' + r.ok + ' fiche' + (r.ok > 1 ? 's' : '') + (oui ? ' publiée' : ' retirée') + (r.ok > 1 ? 's' : '') + '</b>' + (r.deja ? ' · ' + r.deja + ' déjà dans cet état' : '') + note;
    var sb = root.exbSb;
    if (r.ok && S.auto !== false && sb && sb.isIn && sb.isIn()) { refresh(); synchroSujets().then(function () { if (note) { S.msg += note; refresh(); } }); return; }
    if (r.ok) S.msg += '<br>Touchez « 🔄 Synchroniser avec le serveur » pour mettre à jour la page publique.';
    say(r.ok + ' fiche(s) ' + (oui ? 'publiée(s)' : 'retirée(s)') + '.', r.ok ? 'success' : 'warn'); refresh();
  }
  /* Plans architecturaux : l'administration est tfl-plans-admin.html, affichée ici (même origine : mêmes données locales exb_tfl_plans). */
  function plansReserves() { return get(K.plans, []).filter(function (x) { return x.statut === 'reserve'; }).length; }
  function vuePlans() {
    var pl = get(K.plans, []), nPub = pl.filter(function (x) { return x.publie; }).length;
    return '<div style="display:flex;gap:8px;margin:10px 0;flex-wrap:wrap"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button><a class="muted" style="padding:8px 12px;border-radius:8px;background:#eef2f7;text-decoration:none" href="tfl-plans.html" target="_blank" rel="noopener">🔗 Page publique des plans</a></div><h3>📐 Plans architecturaux</h3>'
      + '<p class="localhint">' + pl.length + ' plan(s), ' + nPub + ' publié(s), ' + plansReserves() + ' réservé(s). Un plan choisi disparaît de la page publique ; libérez-le pour le remettre. N’ajoutez que des plans dont vous avez les droits (dessinés par vous, autorisation écrite ou licence libre).</p>'
      + '<iframe src="tfl-plans-admin.html" title="Administration des plans" style="width:100%;height:80vh;border:1px solid #ccd4df;border-radius:12px;background:#fff"></iframe>';
  }
  function vueSujets() {
    var S = ST.sj, liste = sujets(), nPub = liste.filter(function (x) { return x.publie; }).length, url = lienSujets(), c = cfgServeur();
    return '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>📋 Catalogue des sujets</h3>'
      + '<p class="localhint">Publiez des fiches de sujets : les étudiants les consultent sans compte sur une page publique et touchent « Choisir ce sujet ». Leur demande arrive comme candidature dans vos dossiers. Un sujet <b>exclusif</b> ne peut être réservé que par un seul étudiant tant que vous n’avez pas décidé.</p>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>🌐 Page publique</b> <span class="hint">(' + nPub + ' sujet' + (nPub > 1 ? 's' : '') + ' publié' + (nPub > 1 ? 's' : '') + ')</span>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button type="button" class="primary" data-tfl="sjSync"' + (S.busy ? ' disabled' : '') + '>' + (S.busy ? 'Synchronisation…' : '🔄 Synchroniser avec le serveur') + '</button>'
      + '<button type="button" class="muted" data-tfl="sjLien">🔗 Copier le lien public</button><button type="button" class="muted" data-tfl="sjJson">⬇ Fichier sans serveur (tfl-sujets.json)</button><button type="button" class="muted" data-tfl="sjCsv">⬇ Liste (CSV)</button></div>'
      + (url ? '<div class="hint" style="margin-top:6px">Lien : ' + esc(url) + '</div>' : '<div class="hint" style="margin-top:6px">Le lien public apparaît quand le logiciel est ouvert depuis son adresse web (https://…).</div>')
      + (c ? '' : '<div class="hint" style="margin-top:4px">Serveur non configuré : utilisez le fichier tfl-sujets.json (déposé à côté de tfl-sujets.html) ; les étudiants enverront alors un fichier au lieu d’une demande en ligne.</div>')
      + (S.err ? '<div style="color:#b91c1c;margin-top:6px;font-size:14px">✗ ' + esc(S.err) + '</div>' : '') + (S.msg ? '<div style="margin-top:6px;font-size:14px">' + S.msg + '</div>' : '') + '</div>'
      + '<div class="card" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0">' + (S.ouvert ? '<b>➕ Nouvelle fiche</b>' + sujetForm() : '<button type="button" class="primary" data-tfl="sjNouveau">➕ Nouvelle fiche de sujet</button>') + '</div>'
      + vueBanque()
      + vueMesFiches(liste);
  }
  async function synchroSujets() {
    var sb = root.exbSb, S = ST.sj;
    if (!sb || !sb.isIn || !sb.isIn()) { S.err = 'Non connecté au serveur : ouvrez Inscription › Demandes reçues et connectez-vous (compte administrateur).'; S.msg = ''; refresh(); return { ok: false }; }
    if (S.busy) return { ok: false };
    S.busy = true; S.err = ''; S.msg = ''; refresh();
    try {
      var etat = await sb.api('/rest/v1/rpc/tfl_sujets_etat', { method: 'POST', body: '{}' }) || [], nouv = sujetsAppliquerEtat(etat);
      var retirer = sujets().filter(function (x) { return !x.publie && x.serveur; });
      for (var i = 0; i < retirer.length; i++) await sb.api('/rest/v1/rpc/tfl_sujet_retirer', { method: 'POST', body: JSON.stringify({ p_ref: retirer[i].ref }) });
      var pay = sujetsPourServeur().filter(function (o) { return o.publie; });
      for (var ci = 0; ci < pay.length; ci += 300) await sb.api('/rest/v1/rpc/tfl_sujets_publier', { method: 'POST', body: JSON.stringify({ p_sujets: pay.slice(ci, ci + 300) }) });
      var all = sujets(); all.forEach(function (x) { if (x.publie) { x.serveur = true; x.push = false; } else if (x.serveur) { x.serveur = false; x.push = false; } }); put(K.suj, all);
      S.at = now(); S.msg = '<b style="color:#15803d">✓ ' + pay.length + ' sujet(s) publié(s)</b>' + (nouv ? '<br>' + nouv + ' réservation(s) reçue(s) du serveur : récupérez les candidatures en ligne pour créer les dossiers.' : '');
      say('Catalogue synchronisé.', 'success');
      return { ok: true, n: pay.length, reservations: nouv };
    } catch (e) {
      var m = String((e && e.message) || e || '');
      S.err = /tfl_sujets|schema cache|Could not find|does not exist|404/i.test(m) ? 'Le service « sujets » n’est pas encore activé : exécutez supabase/migration-v99zzv-tfl-sujets.sql dans Supabase (SQL Editor).' : (m || 'erreur inconnue.');
      return { ok: false };
    } finally { S.busy = false; refresh(); }
  }
  function sujetsTelecharger() {
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(sujetsJsonPublic(), null, 1)], { type: 'application/json' })); a.download = 'tfl-sujets.json'; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500);
  }
  function sujetsTelechargerCsv() {
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([sujetsCsv()], { type: 'text/csv;charset=utf-8' })); a.download = 'catalogue-sujets-TFL-' + now().slice(0, 10) + '.csv'; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500);
  }

  function blocMessages(d) {
    var M = msgsLocaux().filter(function (m) { return m.dossier === d.numero; }).sort(function (a, b) { return String(a.at).localeCompare(String(b.at)); });
    var qui = { admin: 'Vous (administration)', etudiant: 'Étudiant', encadreur: 'Encadreur' };
    return '<h4 style="margin:14px 0 6px">💬 Messages des portails</h4>'
      + (M.length ? '<div style="max-height:260px;overflow:auto;border:1px solid #e3e8f0;border-radius:10px;padding:8px;background:#fff">' + M.map(function (m) {
        var t = m.type === 'validation' ? validationMsgHtml(m) : m.type === 'progression' ? 'Progression proposée : <b>' + esc(m.valeur) + ' %</b>' + (m.appliquee ? ' <span style="color:#15803d">(appliquée)</span>' : ' <button type="button" class="primary" data-tfl="appliquerProg" data-id="' + esc(m.id) + '" style="padding:4px 10px">Appliquer</button>') : (m.type === 'commentaire' ? '<i>Commentaire</i> — ' : '') + esc(m.texte).replace(/\n/g, '<br>');
        return '<div style="margin:6px 0;padding:6px 9px;border-radius:8px;background:' + (m.de === 'admin' ? '#fdf3d9' : '#eef2f7') + '"><small style="color:#667085">' + esc(qui[m.de] || m.de) + (m.de_nom ? ' — ' + esc(m.de_nom) : '') + (m.de === 'admin' ? ' → ' + esc({ etudiant: 'étudiant', encadreur: 'encadreur', tous: 'étudiant et encadreur' }[m.pour] || '') : '') + ' · ' + esc(String(m.at).slice(0, 16).replace('T', ' ')) + '</small><br>' + t + '</div>'; }).join('') + '</div>'
        : '<div class="hint">Aucun message pour ce dossier.</div>')
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><select id="tflMsgPour"><option value="tous">À l’étudiant et à l’encadreur</option><option value="etudiant">À l’étudiant seulement</option><option value="encadreur">À l’encadreur seulement</option></select></div>'
      + '<textarea id="tflMsgTxt" placeholder="Message visible dans le portail (après « Publier »)" style="width:100%;min-height:54px;margin-top:6px"></textarea><button type="button" class="primary" data-tfl="msgPortail" style="margin-top:6px">Ajouter le message</button>'
      + '<div class="hint">Le message apparaît dans le portail à la prochaine publication (📡 Publier).</div>';
  }

  /* ---------- Onglet « Signatures » : signature + cachet de l'administration (partagés avec Paramètres › Logo Excellencia Building) ---------- */
  var SIGPAD = null, SGMSG = '';
  function vueSignatures() {
    var S = root.EXBSign, back = '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>✍️ Signatures et cachet</h3>';
    if (!S) return back + '<p class="localhint">Module de signature indisponible sur cet appareil.</p>';
    var a = S.getAdmin(), etus = L.etu(), nb = etus.filter(function (e) { return okSig(e.signature); }).length;
    var cv = 'width:100%;height:150px;border:2px dashed #173565;border-radius:10px;background:#fafcff;display:block;touch-action:none';
    return back
      + '<p class="localhint">Enregistrez <b>une seule fois</b> votre signature et le cachet Excellencia Building : ils se placent ensuite <b>automatiquement</b> dans la case « Cachet et visa » de chaque attestation de dépôt (et des fiches de formulaire éditées sur cet appareil). Ce sont les mêmes réglages que Paramètres › Logo Excellencia Building. Ils restent sur cet appareil.</p>'
      + '<div style="display:flex;gap:16px;flex-wrap:wrap">'
      + '<div style="flex:1 1 320px"><label>Votre signature (au doigt ou à la souris)</label><canvas id="tflSigCanvas" style="' + cv + '"></canvas>'
      + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button type="button" class="primary" data-tfl="sigSave">✍️ Enregistrer cette signature</button><button type="button" class="muted" data-tfl="sigClear">🗑 Effacer le cadre</button>' + (a.sig ? '<button type="button" class="muted" data-tfl="sigDel">Supprimer ma signature</button>' : '') + '</div>'
      + '<label style="margin-top:10px">Pas d’écran tactile ? Importer une image de ma signature</label><input type="file" id="tflSigFile" accept="image/png,image/jpeg,image/webp"></div>'
      + '<div style="flex:1 1 280px"><label>Cachet</label><select id="tflStampMode"><option value="default"' + (a.stamp === 'default' ? ' selected' : '') + '>Cachet Excellencia Building par défaut</option><option value="custom"' + (a.stamp !== 'default' && a.stamp !== 'none' ? ' selected' : '') + '>Mon propre cachet (image importée)</option><option value="none"' + (a.stamp === 'none' ? ' selected' : '') + '>Aucun cachet</option></select>'
      + '<input type="file" id="tflStampFile" accept="image/png,image/jpeg,image/webp" hidden>'
      + '<label style="display:flex;gap:8px;align-items:center;font-weight:600;margin-top:12px"><input type="checkbox" id="tflSigAuto" style="width:auto"' + (a.auto ? ' checked' : '') + '> Poser mon visa automatiquement sur les documents</label>'
      + '<label style="margin-top:12px">Aperçu du visa (signature + cachet)</label><div style="border:1px solid #dce3ed;border-radius:10px;background:#fff;padding:8px;min-height:110px;display:flex;align-items:center;justify-content:center"><img id="tflVisaPrev" alt="" style="max-width:100%;max-height:130px"></div>'
      + '<div style="margin-top:10px"><button type="button" class="muted" data-tfl="sigTest">📄 Voir un exemple d’attestation avec mon visa</button></div></div></div>'
      + (SGMSG ? '<p class="hint" style="margin:10px 0;font-weight:700;color:#18733b">' + esc(SGMSG) + '</p>' : '')
      + '<h4 style="margin:18px 0 6px;color:#173565">Signatures des étudiants</h4><p class="localhint">L’étudiant signe dans sa fiche (page « Ma fiche étudiante » ou formulaire de candidature). Sa signature s’affiche à gauche de l’attestation de dépôt. ' + nb + ' étudiant(s) sur ' + etus.length + ' ont signé.</p>'
      + (etus.length ? etus.slice(0, 40).map(function (e) { return '<div style="display:flex;gap:10px;align-items:center;border:1px solid #e3e8f0;border-radius:10px;padding:8px 10px;margin:5px 0;background:#fff"><div style="flex:1;min-width:0"><b>' + esc(e.nom || '—') + '</b><br><small style="color:#667085">' + esc(e.matricule || 'matricule à attribuer') + '</small></div>' + (okSig(e.signature) ? '<img src="' + e.signature + '" alt="Signature" style="max-width:150px;max-height:50px">' : '<small style="color:#98a2b3">non reçue</small>') + '</div>'; }).join('') : '<p class="localhint">Aucun étudiant enregistré pour le moment.</p>');
  }
  function sigInit() {
    var S = root.EXBSign; if (!S) return;
    var cv = $('tflSigCanvas'); SIGPAD = cv ? S.pad(cv, { color: '#10285a' }) : null;
    var f = $('tflSigFile'); if (f) f.onchange = async function () { var fl = this.files[0]; this.value = ''; if (!fl) return; try { S.setAdmin({ sig: await S.cleanImage(fl, 800) }); SGMSG = '✓ Signature importée (fond blanc retiré).'; } catch (e) { SGMSG = 'Image illisible.'; } render(); };
    var sf = $('tflStampFile'); if (sf) sf.onchange = async function () { var fl = this.files[0]; this.value = ''; if (!fl) return render(); try { S.setAdmin({ stamp: await S.cleanImage(fl, 700) }); SGMSG = '✓ Cachet importé.'; } catch (e) { SGMSG = 'Image illisible.'; } render(); };
    var sm = $('tflStampMode'); if (sm) sm.onchange = function () { if (this.value === 'custom') { var x = $('tflStampFile'); if (x) x.click(); return; } S.setAdmin({ stamp: this.value }); SGMSG = '✓ Cachet mis à jour.'; render(); };
    var au = $('tflSigAuto'); if (au) au.onchange = function () { S.setAdmin({ auto: this.checked }); SGMSG = this.checked ? '✓ Visa automatique activé.' : 'Visa automatique désactivé : les documents partiront sans signature ni cachet.'; render(); };
    S.visa('png').then(function (u) { var im = $('tflVisaPrev'); if (!im) return; if (u) im.src = u; else { im.removeAttribute('src'); im.alt = 'Aucun visa enregistré'; } });
  }
  async function sigExemple() {
    if (!root.EXBForm || !root.EXBForm.pdfBlobAsync) return say('Module PDF indisponible.', 'error');
    var blob = await root.EXBForm.pdfBlobAsync({ titre: 'ATTESTATION DE DÉPÔT — TFL', sousTitre: 'TFL-EXEMPLE-0001', matricule: '000-000-000',
      lignes: [['Numéro de dossier', 'TFL-EXEMPLE-0001'], ['Étudiant', 'Nom Prénom (exemple)'], ['Matricule', '000-000-000'], ['Statut', 'Accepté'], ['Reçu le', new Date().toISOString().slice(0, 10)]],
      notes: ['Exemple : le visa enregistré apparaît dans la case « Cachet et visa Excellencia Building ».'], pied: 'TFL — Excellencia Building', logo: 'icon-192.png' });
    root.EXBForm.download(blob, 'Exemple-attestation-TFL-avec-visa.pdf');
  }

  function render() {
    var box = $('tflBox'); if (!box) return;
    var keep = ST.vue === 'dossiers' ? (document.activeElement && document.activeElement.id === 'tflQ') : false;
    var d = L.dos().filter(function (x) { return x.id === ST.sel; })[0];
    var PV = ['tflPnom', 'tflPtel', 'tflPmail', 'tflPuniv'].map(function (i) { var e = $(i); return e ? e.value : null; });
    var BV = {}; [].forEach.call(document.querySelectorAll('#tflBox .tflB, #tflBox .tflS'), function (e) { BV[e.id] = e.value; }); var keepB = ST.vue === 'biblio' && document.activeElement && document.activeElement.id === 'tflBq'; var keepG = ST.vue === 'sujets' && document.activeElement && document.activeElement.id === 'tflGq'; var keepF = ST.vue === 'sujets' && document.activeElement && document.activeElement.id === 'tflFq';
    var fk = ST.sj.edit || (ST.sj.ouvert ? '+' : ''); if (fk !== ST.sj.fk) { Object.keys(BV).forEach(function (i) { if (/^tflS/.test(i)) delete BV[i]; }); ST.sj.fk = fk; }
    box.innerHTML = header() + bandeauSauvegarde() + (ST.vue === 'encadreurs' ? vueEncadreurs() : ST.vue === 'propositions' ? vuePropositions() : ST.vue === 'portails' ? vuePortails() : ST.vue === 'biblio' ? vueBiblio() : ST.vue === 'sujets' ? vueSujets() : ST.vue === 'plans' ? vuePlans() : ST.vue === 'signatures' ? vueSignatures() : ST.vue === 'tableau' ? vueTableau() : listeDossiers() + (d ? detail(d) : ''));
    if (ST.vue === 'signatures') sigInit();
    Object.keys(BV).forEach(function (i) { var e = $(i); if (e && BV[i] !== '') e.value = BV[i]; });
    [].forEach.call(document.querySelectorAll('.tflBjoin'), function (i) { i.onchange = function () { var f = this.files[0], id = this.getAttribute('data-id'); this.value = ''; bibJoindreAction(id, f); }; });
    var bd = $('tflBdom'); if (bd) bd.onchange = function () { ST.bib.dom = this.value; render(); };
    var bq = $('tflBq'); if (bq) { bq.oninput = function () { ST.bib.q = this.value; var pos = this.selectionStart; render(); var n = $('tflBq'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* ignoré */ } } }; if (keepB) bq.focus(); }
    var gq = $('tflGq'); if (gq) { gq.oninput = function () { ST.bq.q = this.value; ST.bq.page = 0; ST.bq.msg = ''; var pos = this.selectionStart; render(); var n = $('tflGq'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* ignoré */ } } }; if (keepG) gq.focus(); }
    var fq = $('tflFq'); if (fq) { fq.oninput = function () { ST.sj.fq = this.value; ST.sj.max = 40; var pos = this.selectionStart; render(); var n = $('tflFq'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* ignoré */ } } }; if (keepF) fq.focus(); }
    var fp = $('tflFp'); if (fp) fp.onchange = function () { ST.sj.fp = this.value; ST.sj.max = 40; render(); };
    var fc = $('tflFc'); if (fc) fc.onchange = function () { ST.sj.fc = this.value; ST.sj.max = 40; render(); };
    var fa = $('tflFauto'); if (fa) fa.onchange = function () { ST.sj.auto = this.checked; };
    var gd = $('tflGd'); if (gd) gd.onchange = function () { ST.bq.dom = this.value; ST.bq.page = 0; ST.bq.msg = ''; render(); };
    ['tflPnom', 'tflPtel', 'tflPmail', 'tflPuniv'].forEach(function (i, n) { var e = $(i); if (e && PV[n]) e.value = PV[n]; });
    var fi = $('tflFiles'); if (fi) fi.onchange = function () { importFiles(this.files); this.value = ''; };
    var fe = $('tflEncFiles'); if (fe) fe.onchange = function () { importFiles(this.files); this.value = ''; };
    var rs = $('tflRest'); if (rs) rs.onchange = function () { restaurer(this.files[0]); this.value = ''; };
    var q = $('tflQ'); if (q) { q.oninput = function () { ST.q = this.value; var pos = this.selectionStart; render(); var n = $('tflQ'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* ignoré */ } } }; if (keep) q.focus(); }
  }
  function refresh() { try { render(); } catch (e) { /* l'écran n'est pas ouvert */ } }

  function exporter() {
    var o = { form: 'EXB_TFL_SAUVEGARDE', version: 1, at: now() }; Object.keys(K).forEach(function (k) { o[k] = get(K[k], k === 'cpt' ? {} : []); });
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(o)], { type: 'application/json' })); a.download = 'sauvegarde-TFL-' + now().slice(0, 10) + '.json'; a.click(); try { root.localStorage.setItem('exb_tfl_last_backup', now()); } catch (e) { /* ignoré */ } setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500);
  }
  async function restaurer(f) {
    if (!f) return;
    try {
      var o = JSON.parse(await fileText(f)); if (o.form !== 'EXB_TFL_SAUVEGARDE') throw new Error('ce n’est pas une sauvegarde TFL.');
      if (!confirm('Restaurer cette sauvegarde ? Les données TFL actuelles de cet appareil seront remplacées.')) return;
      Object.keys(K).forEach(function (k) { if (o[k] !== undefined) put(K[k], o[k]); }); say('Sauvegarde TFL restaurée.', 'success'); render();
    } catch (e) { say('Restauration impossible : ' + (e.message || e), 'error'); }
  }

  function analyseSaisie() { var o = { notes: cut(($('tflAnalyse') || {}).value, 2000) }; [].forEach.call(document.querySelectorAll('.tflCrit'), function (c) { o[c.getAttribute('data-c')] = c.checked; }); return o; }
  function act(a, b) {
    var d = L.dos().filter(function (x) { return x.id === ST.sel; })[0], v = b.getAttribute('data-v'), val = function (i) { return ($(i) || {}).value; };
    try {
      if (a === 'filtre') { ST.f = v; ST.sel = ''; }
      else if (a === 'vue') { ST.vue = v; }
      else if (a === 'sigSave') { var su = SIGPAD && SIGPAD.png(); if (!su) return say('Signez d’abord dans le cadre.', 'warn'); root.EXBSign.setAdmin({ sig: su }); SGMSG = '✓ Signature enregistrée sur cet appareil : elle sera posée automatiquement.'; }
      else if (a === 'sigClear') { if (SIGPAD) SIGPAD.clear(); return; }
      else if (a === 'sigDel') { root.EXBSign.clearSig(); SGMSG = 'Signature supprimée.'; }
      else if (a === 'sigTest') { sigExemple(); return; }
      else if (a === 'ouvrir') { ST.sel = b.getAttribute('data-id'); var od = L.dos().filter(function (x) { return x.id === ST.sel; })[0]; if (od) marquerLus(od.numero); }
      else if (a === 'fermer') { ST.sel = ''; }
      else if (a === 'envoyer') { envoyerFormulaire(true); return; }
      else if (a === 'telecharger') { envoyerFormulaire(false); return; }
      else if (a === 'lienCopier') { lienInternetAction('copier'); return; }
      else if (a === 'lienWa') { lienInternetAction('wa'); return; }
      else if (a === 'enligne') { candidaturesEnLigne(true); return; }
      else if (a === 'cLien') { contribLienAction('copie'); return; }
      else if (a === 'cWa') { contribLienAction('wa'); return; }
      else if (a === 'cRecup') { contribRecuperer(); return; }
      else if (a === 'cGarder') { contribGarder(b.getAttribute('data-id')); return; }
      else if (a === 'ptPublier') { publierPortails(); return; }
      else if (a === 'ptRetours') { recupererRetours(); return; }
      else if (a === 'ptListe') { ST.pt.err = ''; listeServeur().then(function () { ST.pt.msg = 'État des accès actualisé.'; refresh(); }, function (e) { ST.pt.err = erreurPortail(e); refresh(); }); return; }
      else if (a === 'ptReset') { publierPortails({ reset: b.getAttribute('data-k') }); return; }
      else if (a === 'ptRevoquer') { revoquerAcces(b.getAttribute('data-k')); return; }
      else if (a === 'ptWaLien') { envoiAcces(b.getAttribute('data-k'), 'lien'); return; }
      else if (a === 'ptWaCode') { envoiAcces(b.getAttribute('data-k'), 'code'); return; }
      else if (a === 'ptLien') { copierLienPortail(v); return; }
      else if (a === 'msgPortail' && d) { messageAdmin(d.numero, val('tflMsgPour'), val('tflMsgTxt')); say('Message ajouté : il sera visible après la prochaine publication des portails.', 'success'); }
      else if (a === 'appliquerProg') { var pd = appliquerProgression(b.getAttribute('data-id')); say('Progression du dossier ' + pd.numero + ' mise à jour.', 'success'); }
      else if (a === 'bOnglet') { ST.bib.onglet = v; ST.bib.edit = ''; ST.bib.msg = ''; }
      else if (a === 'bAjouter') { bibAjouterAction(); return; }
      else if (a === 'bConsult') { var bc = biblio().filter(function (x) { return x.id === b.getAttribute('data-id'); })[0]; if (bc) bibModifier(bc.id, { consultation: bc.consultation === 'oui' ? 'non' : 'oui' }); }
      else if (a === 'bOuvrir') { bibOuvrir(b.getAttribute('data-id'), false); return; }
      else if (a === 'bTelecharger') { bibOuvrir(b.getAttribute('data-id'), true); return; }
      else if (a === 'bStatut') { bibStatut(b.getAttribute('data-id'), v); }
      else if (a === 'bSuppr') { if (!confirm('Supprimer cette fiche et son fichier de cet appareil ?')) return; bibSupprimer(b.getAttribute('data-id')).then(function () { say('Fiche supprimée.', 'success'); refresh(); }, function (e) { say(e.message || String(e), 'error'); }); return; }
      else if (a === 'bEdit') { ST.bib.edit = b.getAttribute('data-id'); }
      else if (a === 'bEditAnnule') { ST.bib.edit = ''; }
      else if (a === 'bEditOk') { bibModifier(ST.bib.edit, { titre: val('tflEt'), auteur: val('tflEa'), telephone: val('tflEtel'), encadreur: val('tflEe'), annee: val('tflEy'), universite: val('tflEu'), domaine: val('tflEd'), mots_cles: val('tflEk'), resume: val('tflEr'), consultation: val('tflEc') || undefined }); ST.bib.edit = ''; say('Fiche mise à jour.', 'success'); }
      else if (a === 'bVersDossier') { var bd2 = bibVersDossier(b.getAttribute('data-id')); say('Dossier ' + bd2.numero + ' créé (étape 1) : complétez la problématique et les objectifs.', 'success'); }
      else if (a === 'bOuvrirDos') { var dd = L.dos().filter(function (x) { return x.numero === b.getAttribute('data-n'); })[0]; if (dd) { ST.vue = 'dossiers'; ST.f = 'tous'; ST.q = ''; ST.sel = dd.id; marquerLus(dd.numero); } }
      else if (a === 'bCsv') { bibTelechargerCsv(); return; }
      else if (a === 'bDepuisDos' && d) { bibDepuisDossier(d.id); say('Dossier gardé dans la bibliothèque (TFL résolus).', 'success'); }
      else if (a === 'sjNouveau') { ST.sj.ouvert = true; ST.sj.edit = ''; }
      else if (a === 'sjAnnule') { ST.sj.ouvert = false; ST.sj.edit = ''; }
      else if (a === 'sjOk') { var so = sujetSaisie(); if (ST.sj.edit) { sujetModifier(ST.sj.edit, so); ST.sj.edit = ''; say('Fiche mise à jour.', 'success'); } else { var ns = sujetAjouter(so); ST.sj.ouvert = false; say('Fiche ' + ns.ref + ' ajoutée au catalogue (non publiée).', 'success'); } }
      else if (a === 'sjEdit') { ST.sj.edit = b.getAttribute('data-id'); ST.sj.ouvert = false; }
      else if (a === 'sjPublie') { var sx = sujetDe(b.getAttribute('data-id')); if (sx) { sujetPublier(sx.ref, !sx.publie); say(sx.publie ? 'Sujet retiré du public (au prochain « Synchroniser »).' : 'Sujet publié (touchez « Synchroniser » pour l’envoyer au serveur).', 'success'); } }
      else if (a === 'sjStatut') { sujetStatut(b.getAttribute('data-id'), v); say('Disponibilité mise à jour (touchez « Synchroniser » pour la répercuter sur la page publique).', 'success'); }
      else if (a === 'sjSuppr') { if (!confirm('Supprimer cette fiche du catalogue de cet appareil ?')) return; sujetSupprimer(b.getAttribute('data-id')); say('Fiche supprimée. Si elle était publiée, retirez-la d’abord du public puis synchronisez.', 'success'); }
      else if (a === 'sjSync') { synchroSujets(); return; }
      else if (a === 'sjSel') { var rf = b.getAttribute('data-id'); ST.sj.sel = ST.sj.sel || {}; if (ST.sj.sel[rf]) delete ST.sj.sel[rf]; else ST.sj.sel[rf] = 1; }
      else if (a === 'sjSelTous') { ST.sj.sel = ST.sj.sel || {}; mesFichesFiltre(sujets()).forEach(function (x) { ST.sj.sel[x.ref] = 1; }); }
      else if (a === 'sjSelAucun') { ST.sj.sel = {}; }
      else if (a === 'sjLotPub' || a === 'sjLotRet' || a === 'sjPubTout') { sujetsLotAction(a); return; }
      else if (a === 'sjPlus') { ST.sj.max = (ST.sj.max || 40) + 60; }
      else if (a === 'bqOuvrir') { ST.bq.ouvert = true; ST.bq.err = ''; if (!BQ.items) banqueCharger().then(refresh, function (e) { ST.bq.err = e.message || String(e); refresh(); }); }
      else if (a === 'bqFermer') { ST.bq.ouvert = false; ST.bq.msg = ''; }
      else if (a === 'bqPage') { ST.bq.page = Math.max(0, ST.bq.page + (parseInt(v, 10) || 0)); }
      else if (a === 'bqAdd') { banqueAdopter([b.getAttribute('data-id')]); ST.bq.msg = '<b style="color:#15803d">✓ Sujet ajouté à vos fiches</b> (non publié). Contextualisez-le avant publication.'; }
      else if (a === 'bqAddAll') {
        var bl = banqueChercher({ q: ST.bq.q, dom: ST.bq.dom }), bh = {}; sujets().forEach(function (x) { bh[x.ref] = 1; });
        var br = bl.filter(function (it) { return !bh[it.ref]; }).slice(0, BQ_LOT).map(function (it) { return it.ref; });
        if (!br.length) return say('Tous ces sujets sont déjà dans vos fiches.', 'warn');
        if (!confirm('Ajouter ' + br.length + ' sujet(s) à vos fiches ? Ils ne seront pas publiés.')) return;
        var bres = banqueAdopter(br); ST.bq.msg = '<b style="color:#15803d">✓ ' + bres.ajoutes + ' sujet(s) ajouté(s) à vos fiches</b> (non publiés).';
      }
      else if (a === 'sjLien') { var ls = lienSujets(); if (!ls) return say('Le lien public n’existe qu’une fois le logiciel hébergé en ligne (adresse https://…).', 'warn'); copier(ls).then(function (okc) { say(okc ? 'Lien de la page publique copié.' : 'Copiez le lien affiché.', okc ? 'success' : 'warn'); }); return; }
      else if (a === 'sjJson') { sujetsTelecharger(); return; }
      else if (a === 'sjCsv') { sujetsTelechargerCsv(); return; }
      else if (a === 'export') { exporter(); return; }
      else if (a === 'matricule') { var r = attribuerMatricule(b.getAttribute('data-e')); say('Matricule ' + r.matricule + (r.repris ? ' (déjà inscrit comme apprenant : matricule repris)' : ' attribué') + '.', 'success'); }
      else if (a === 'matriculeMan') { say('Matricule ' + fixerMatricule(b.getAttribute('data-e'), val('tflMat')) + ' enregistré.', 'success'); }
      else if (a === 'statut' && d) {
        var MA = { recu: 'Candidature reçue par Excellencia Building.', en_verification: 'Candidature en cours de vérification par Excellencia Building.', accepte: 'Sujet accepté par Excellencia Building.', clos: 'Dossier clos.' },
            MD = { refuse: 'Sujet refusé. Motif : ', complement_demande: 'Complément demandé : ' }, mt = String(val('tflMotif') || '').trim(), autos = [];
        Object.keys(MA).forEach(function (k) { autos.push(MA[k]); }); Object.keys(MD).forEach(function (k) { autos.push(MD[k].trim()); });
        var auto = !mt || autos.indexOf(mt) >= 0 || (mt === String(d.motif_decision || '').trim() && (d.statut === 'refuse' || d.statut === 'complement_demande') && v !== d.statut);
        if (v === 'refuse' || v === 'complement_demande') {
          if (auto) { var ta = $('tflMotif'); if (ta) { ta.value = MD[v]; ta.focus(); try { ta.setSelectionRange(ta.value.length, ta.value.length); } catch (x2) { /* ignoré */ } } return say('Complétez le motif, puis appuyez de nouveau sur « ' + LBL(STATUTS, v) + ' ».', 'warn'); }
        } else if (auto) mt = MA[v];
        var s = setStatut(d.id, v, mt); say('Dossier ' + d.numero + ' : ' + LBL(STATUTS, v) + (s.matricule ? ' — matricule ' + s.matricule.matricule + ' attribué' : '') + '.', 'success'); }
      else if (a === 'affecter' && d) { affecter(d.id, val('tflEnc')); say('Affectation enregistrée.', 'success'); }
      else if (a === 'suivi' && d) { patchDossier(d.id, { sujet_statut: val('tflSujet'), validation_univ: val('tflUniv'), etape: parseInt(val('tflEtape'), 10) || 1, analyse: analyseSaisie(), progression: parseInt(val('tflProg'), 10) || 0, validation_exb: !!($('tflExb') || {}).checked, observation_encadreur: cut(val('tflObs'), 2000) }); say('Suivi enregistré.', 'success'); }
      else if (a === 'pdf' && d) { fichePdf(d); return; }
      else if (a === 'ouvrirDos') { ST.vue = 'dossiers'; ST.f = 'tous'; ST.sel = b.getAttribute('data-id'); }
      else if (a === 'csvRapport') { telecharger('rapport-TFL-' + now().slice(0, 10) + '.csv', rapportCsv(), 'text/csv;charset=utf-8'); say('Rapport téléchargé.', 'success'); }
      else if (a === 'chAdd' && d) { chapitreAjouter(d.id, val('tflChT'), val('tflChD')); say('Chapitre ajouté.', 'success'); }
      else if (a === 'chPlan' && d) { say('Plan type ajouté (' + chapitrePlanType(d.id) + ' chapitres).', 'success'); }
      else if (a === 'chStatut' && d) { chapitreStatut(d.id, b.getAttribute('data-ch'), v); }
      else if (a === 'chDel' && d) { if (!confirm('Supprimer ce chapitre et ses corrections ?')) return; chapitreSupprimer(d.id, b.getAttribute('data-ch')); }
      else if (a === 'coAdd' && d) { correctionAjouter(d.id, b.getAttribute('data-ch'), val('tflCo-' + b.getAttribute('data-ch'))); say('Correction enregistrée : le chapitre passe « À corriger ».', 'success'); }
      else if (a === 'coBasc' && d) { correctionBasculer(d.id, b.getAttribute('data-ch'), b.getAttribute('data-co')); }
      else if (a === 'progAuto' && d) { say('Progression calculée : ' + progressionAuto(d.id) + ' %.', 'success'); }
      else if (a === 'rdvAdd' && d) { rdvAjouter(d.id, { date: val('tflRvD'), heure: val('tflRvH'), objet: val('tflRvO'), lieu: val('tflRvL') }); say('Rendez-vous planifié.', 'success'); }
      else if (a === 'rdvBasc' && d) { rdvBasculer(d.id, b.getAttribute('data-r')); }
      else if (a === 'rdvDel' && d) { rdvSupprimer(d.id, b.getAttribute('data-r')); }
      else if (a === 'rdvIcs' && d) { var rv = (d.rdv || []).filter(function (x) { return x.id === b.getAttribute('data-r'); })[0]; if (rv) telecharger('rendez-vous-' + d.numero + '-' + rv.date + '.ics', rdvIcs(d, rv), 'text/calendar;charset=utf-8'); return; }
      else if (a === 'defSave' && d) { var ck = {}; [].forEach.call(document.querySelectorAll('.tflDefC'), function (c) { ck[c.getAttribute('data-k')] = c.checked; }); defenseEnregistrer(d.id, { date: val('tflDfD'), heure: val('tflDfH'), lieu: val('tflDfL'), president: val('tflDfP'), jury: val('tflDfJ'), note: val('tflDfN'), check: ck }); say('Préparation de la défense enregistrée.', 'success'); }
      else if (a === 'dispo') { basculerEncadreur(b.getAttribute('data-id')); }
      else if (a === 'infoDos' && d) { var ei = L.etu().filter(function (x) { return x.id === d.etudiant_id; })[0] || {}; ouvrirWa(ei.telephone, texteDecisionDossier(d, ei)); return; }
      else if (a === 'propWa') { var sp = sujets().filter(function (x) { return x.ref === b.getAttribute('data-ref'); })[0], cp = sp && L.enc().filter(function (x) { return x.id === sp.encadreur_id; })[0]; if (!sp) throw new Error('sujet introuvable.'); ouvrirWa(cp && cp.telephone, texteDecisionProp(sp, cp)); return; }
      else if (a === 'matWa') { var kk = b.getAttribute('data-k'), pid = b.getAttribute('data-id'), pp = (kk === 'enc' ? L.enc() : L.etu()).filter(function (x) { return x.id === pid; })[0]; if (!pp || !pp.matricule) throw new Error('matricule introuvable.'); ouvrirWa(pp.telephone, texteMatricule(pp.nom, pp.matricule, kk === 'enc' ? 'encadreur' : 'etudiant')); return; }
      else if (a === 'demRecevoir') { demandesEnLigne(); return; }
      else if (a === 'demOk') { demandeTraiter(b.getAttribute('data-v'), true); return; }
      else if (a === 'demNon') { demandeTraiter(b.getAttribute('data-v'), false); return; }
      else if (a === 'demWa') { var pe = personneParMatricule(b.getAttribute('data-k')); if (!pe) throw new Error('personne introuvable (matricule non enregistré ici).'); var rf2 = b.getAttribute('data-ref'), dd2 = L.dos().filter(function (x) { return x.numero === rf2; })[0], ss2 = sujets().filter(function (x) { return x.ref === rf2; })[0]; ouvrirWa(pe.p.telephone, dd2 ? texteDecisionDossier(dd2, pe.p) : (ss2 ? texteDecisionProp(ss2, pe.p) : texteMatricule(pe.p.nom, pe.p.matricule, pe.role))); return; }
      else if (a === 'appliquerVal') { appliquerValidation(b.getAttribute('data-id')); say('Validation du sujet appliquée au dossier.', 'success'); }
      else if (a === 'propDec') { var rf = b.getAttribute('data-ref'), s3 = propositionDecider(rf, b.getAttribute('data-v'), val('tflPm_' + rf)); say('Sujet ' + s3.ref + ' : ' + LBL(PROP, s3.proposition) + (s3.proposition === 'retenu' ? ' — publié au catalogue (touchez « Synchroniser » dans Sujets).' : '.'), 'success'); }
      else if (a === 'encValider') { var cv = encadreurValider(b.getAttribute('data-v'), true); say(cv.nom + ' est validé : il peut être affecté. Son accès au portail (identifiant = matricule ' + (cv.matricule || '') + ') s’ouvre à la prochaine publication : TFL › Portails › Publier.', 'success'); }
      else if (a === 'encAttest') { encadrementPdf(b.getAttribute('data-v')); return; }
      else if (a === 'encRecevoir') { encadreursEnLigne(); return; }
      else if (a === 'statutsPub') { publierStatuts(false).catch(function (e) { say(erreurServeur(e), 'error'); }); return; }
      else if (a === 'encLienCopier') { var le = lienEncadreurForm(); if (!le) throw new Error('le lien n’existe que lorsque le logiciel est ouvert depuis son adresse web (https://…).'); Promise.resolve(navigator.clipboard && navigator.clipboard.writeText(le)).then(function () { say('Lien du formulaire encadreur copié.', 'success'); }).catch(function () { prompt('Copiez ce lien :', le); }); }
      else if (a === 'encLienWa') { var le2 = lienEncadreurForm(); if (!le2) throw new Error('le lien n’existe que lorsque le logiciel est ouvert depuis son adresse web (https://…).'); window.open('https://wa.me/?text=' + encodeURIComponent('Bonjour, voici le formulaire encadreur TFL Excellencia Building : remplissez votre fiche et proposez vos sujets. Vous recevrez votre matricule dès l’envoi.\n' + le2), '_blank'); }
      else if (a === 'encFichier') { encFormulaireFichier(false); return; }
      else if (a === 'addEnc') { ajouterEncadreur({ nom: val('tflCn'), telephone: val('tflCt'), email: val('tflCe'), max_etudiants: val('tflCm'), specialites: val('tflCs'), domaines: [].map.call(document.querySelectorAll('.tflDom:checked'), function (c) { return c.value; }) }); say('Encadreur ajouté.', 'success'); }
    } catch (e) { say(e.message || String(e), 'error'); try { alert(e.message || e); } catch (x) { /* ignoré */ } }
    render();
  }

  /* ---------- V99zzzzzzzzzzzzzz : écran « Encadreurs & sujets proposés » ---------- */
  function lienEncadreurForm() { var b = baseSite(); return b ? b + 'tfl-encadreur-formulaire.html' : ''; }
  async function encadreursEnLigne() {
    var sb = root.exbSb;
    if (!sb || !sb.isIn || !sb.isIn()) { ST.msg = '<b style="color:#b91c1c">Non connecté au serveur</b> : ouvrez Inscription › Demandes reçues et connectez-vous (compte administrateur).'; refresh(); return; }
    try {
      var rows = await sb.api('/rest/v1/rpc/tfl_encadreurs_liste', { method: 'POST', body: '{}' }) || [], neuves = rows.filter(function (r) { return !r.imported; }), ok = [], dup = [], fail = [];
      for (var i = 0; i < neuves.length; i++) {
        var r = neuves[i];
        try {
          var res = importerEncadreur({ form: 'EXB_TFL_ENC', version: 1, submitted_at: r.submitted_at || r.created_at, ref: r.ref || '', d: r.data || {}, photo: r.photo || '' });
          if (res.dup) dup.push(res.nom); else ok.push(esc(res.nom) + ' → matricule ' + esc(res.matricule) + ' · ' + res.sujets + ' sujet(s) <button type="button" class="muted" data-tfl="matWa" data-k="enc" data-id="' + esc(res.encadreur.id) + '" style="padding:3px 8px">💬 Envoyer le matricule</button>' + (res.conflit ? ' <span style="color:#b45309">(le numéro ' + esc(res.conflit) + ' était déjà pris : nouveau numéro, à lui communiquer)</span>' : ''));
          await sb.api('/rest/v1/rpc/tfl_encadreur_traiter', { method: 'POST', body: JSON.stringify({ p_id: r.id }) });
        } catch (e) { fail.push(esc((r.data && r.data.nom) || r.id) + ' : ' + esc(e.message || e)); }
      }
      ST.msg = (ok.length ? '<b style="color:#15803d">✓ ' + ok.length + ' formulaire(s) d’encadreur reçu(s)</b><br>' + ok.join('<br>') : 'Aucun nouveau formulaire d’encadreur en ligne.')
        + (dup.length ? '<br><span class="hint">Déjà importé(s) : ' + dup.map(esc).join(', ') + '</span>' : '') + (fail.length ? '<br><b style="color:#b91c1c">✗ ' + fail.join('<br>✗ ') + '</b>' : '');
      if (ok.length) planifierStatuts();
    } catch (e) { ST.msg = '<b style="color:#b91c1c">' + esc(erreurServeur(e)) + '</b>'; }
    refresh();
  }
  function vuePropositions() {
    var encs = L.enc().filter(function (c) { return c.source === 'formulaire' || c.matricule; }), S = sujets().filter(function (s) { return s.source === 'encadreur'; }), lien = lienEncadreurForm();
    var btn = function (a, v, t, cls, extra) { return '<button type="button" class="' + (cls || 'muted') + '" data-tfl="' + a + '"' + (v ? ' data-v="' + esc(v) + '"' : '') + (extra || '') + '>' + t + '</button>'; };
    var h = '<div style="display:flex;gap:8px;margin:10px 0"><button type="button" class="muted" data-tfl="vue" data-v="dossiers">← Dossiers</button></div><h3>🧑‍🏫 Encadreurs : formulaire, matricule et sujets proposés</h3>'
      + '<p class="localhint">L’encadreur remplit <b>son formulaire</b> (fiche + un ou plusieurs sujets). Dès l’envoi, il reçoit <b>son matricule automatiquement</b> ; avec ce matricule et son téléphone il vérifie sur la page de suivi si chaque sujet est <b>retenu, refusé</b> ou en cours. Les étudiants qui proposent leur propre sujet reçoivent aussi leur matricule dès l’envoi.</p>'
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>① Envoyer le formulaire à un encadreur</b><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">'
      + btn('encLienCopier', '', '🔗 Copier le lien', 'primary') + btn('encLienWa', '', '💬 WhatsApp') + btn('encFichier', '', '⬇ Fichier hors ligne') + '</div>'
      + (lien ? '<input readonly onclick="this.select()" value="' + esc(lien) + '" style="margin-top:6px;width:100%">' : '<div class="hint" style="margin-top:6px">Le lien apparaît quand le logiciel est ouvert depuis son adresse web (https://…).</div>') + '</div>'
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>② Recevoir les formulaires</b><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">' + btn('encRecevoir', '', '📡 Récupérer les formulaires en ligne', 'primary')
      + '<label class="muted" style="padding:8px 12px;border-radius:8px;cursor:pointer">📥 Importer des fichiers (.json)<input id="tflEncFiles" type="file" accept=".json,application/json" multiple style="display:none"></label></div>'
      + (ST.msg ? '<div style="margin-top:8px">' + ST.msg + '</div>' : '') + '</div>'
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>③ Statuts consultables par matricule</b><p class="localhint">Les décisions partent seules vers le serveur quand vous y êtes connecté ; sinon utilisez ce bouton. Page publique : <code>tfl-statut.html</code> (lien court <code>/tfl-statut</code>).</p>'
      + btn('statutsPub', '', '📡 Publier les statuts maintenant', 'primary') + '</div>'
      + '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:8px 0"><b>④ Demandes de modification ou de retrait</b><p class="localhint">Un étudiant ou un encadreur peut, depuis la page de suivi, demander à modifier ou retirer un sujet. Vous l’appliquez ici en un clic.</p>'
      + btn('demRecevoir', '', '📡 Récupérer les demandes', 'primary')
      + DEM.map(function (q) { return '<div style="margin:8px 0;padding:8px;border-radius:8px;background:#f8fafc"><b>' + esc(q.nom || '') + '</b> <small>(' + esc(q.matricule) + ' · ' + esc(q.role) + ')</small><br><b>' + (q.type === 'retirer' ? '🗑 Retrait' : '✎ Modification') + '</b> — ' + esc(q.titre || q.ref) + ' <small>(' + esc(q.ref) + ')</small>' + (q.texte ? '<div class="hint">' + esc(q.texte) + '</div>' : '') + '<div style="display:flex;gap:6px;margin-top:6px">' + btn('demOk', q.id, '✔ Appliquer', 'primary') + btn('demNon', q.id, 'Ignorer', 'muted') + '</div></div>'; }).join('') + '</div>'
      + '<h4 style="margin:14px 0 6px;color:#173565">Encadreurs inscrits par formulaire (' + encs.length + ')</h4>';
    if (!encs.length) h += '<p class="localhint">Aucun encadreur pour le moment.</p>';
    encs.forEach(function (c) {
      var mes = S.filter(function (s) { return s.encadreur_id === c.id; });
      h += '<div style="border:1px solid #dce3ed;border-radius:10px;padding:10px;margin:6px 0"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">'
        + (c.photo ? '<img src="' + c.photo + '" alt="" style="width:46px;height:56px;object-fit:cover;border-radius:6px">' : '')
        + '<div style="flex:1;min-width:180px"><b>' + esc((c.grade ? c.grade + ' ' : '') + c.nom) + '</b><br><small style="color:#667085">' + esc([c.institution, c.specialites, c.telephone].filter(Boolean).join(' · ')) + '</small><br><small>Matricule : <b style="color:#173565">' + esc(c.matricule || 'à attribuer') + '</b> · '
        + (c.valide === false ? '<span style="color:#b45309">encadreur non encore validé</span>' : '<span style="color:#15803d">validé</span>') + '</small></div>'
        + (c.valide === false ? btn('encValider', c.id, '✔ Valider cet encadreur', 'primary') : btn('encAttest', c.id, '📄 Attestation d’encadrement', 'muted')) + '</div>';
      mes.forEach(function (s) {
        var col = { recu: '#2563eb', en_verification: '#b45309', retenu: '#15803d', refuse: '#b91c1c', complement: '#9333ea' }[s.proposition || 'recu'] || '#475569';
        h += '<div style="margin:8px 0 0;padding:8px;border-radius:8px;background:#f8fafc"><b>' + esc(s.titre) + '</b> <small>(' + esc(s.ref) + ')</small> <span style="display:inline-block;padding:2px 9px;border-radius:99px;background:' + col + ';color:#fff;font-size:12px;font-weight:700">' + esc(LBL(PROP, s.proposition || 'recu')) + '</span>'
          + (s.decide_par || s.proposition_le ? '<div class="hint">Dernière décision : ' + esc(String(s.proposition_le || '').slice(0, 16).replace('T', ' ')) + (s.decide_par ? ' par ' + esc(s.decide_par) : '') + '</div>' : '')
          + '<div class="hint" style="margin-top:4px"><b>Problématique :</b> ' + esc(s.problematique.slice(0, 220)) + (s.problematique.length > 220 ? '…' : '') + '</div>'
          + '<input id="tflPm_' + esc(s.ref) + '" placeholder="Motif (obligatoire pour refuser ou demander un complément)" value="' + esc(s.motif_proposition || '') + '" style="width:100%;margin-top:6px">'
          + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">' + btn('propDec', 'retenu', '✔ Retenir', 'primary', ' data-ref="' + esc(s.ref) + '"') + btn('propDec', 'en_verification', '🔎 En vérification', 'muted', ' data-ref="' + esc(s.ref) + '"')
          + btn('propDec', 'complement', '✎ Complément', 'muted', ' data-ref="' + esc(s.ref) + '"') + btn('propDec', 'refuse', '✖ Refuser', 'muted', ' data-ref="' + esc(s.ref) + '"') + btn('propWa', '', '💬 Informer', 'muted', ' data-ref="' + esc(s.ref) + '"') + '</div></div>';
      });
      h += '</div>';
    });
    return h;
  }
  async function encFormulaireFichier(partager) {
    try {
      var html = await formulaireHtml({}, 'tfl-encadreur-formulaire.html'), f = new File([new Blob([html], { type: 'text/html' })], 'Excellencia-Building-Formulaire-Encadreur-TFL.html', { type: 'text/html' });
      if (partager && navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: 'Excellencia Building — Formulaire encadreur TFL', text: 'Ouvrez ce fichier, remplissez le formulaire (sans Internet) puis renvoyez-moi le fichier créé.' }); return; }
      var a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2500); say('Formulaire encadreur téléchargé.', 'success');
    } catch (e) { if (e && e.name === 'AbortError') return; say('Impossible de préparer le formulaire : ' + (e.message || e) + ' (ouvrez le logiciel une fois en ligne).', 'error'); }
  }

  function mount() {
    if ($('tflSec')) return;
    var ref = $('tpTd') || $('projets') || document.querySelector('section'), host = document.querySelector('.wrap') || document.querySelector('main') || document.body, s = document.createElement('section');
    s.id = 'tflSec'; s.className = 'no-print'; s.style.display = 'none';
    s.innerHTML = '<div class="card" id="tflBox"></div>';
    if (ref && ref.parentNode) ref.parentNode.insertBefore(s, ref.nextSibling); else host.appendChild(s);
    s.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-tfl]'); if (!b || !s.contains(b)) return; if (b.tagName === 'A') return; act(b.getAttribute('data-tfl'), b); });
    var bt = $('btp') || $('bfor') || $('bprj');
    if (bt && !$('btfl')) { var n = document.createElement('button'); n.id = 'btfl'; n.textContent = '🎓 TFL'; n.setAttribute('onclick', "show('tflSec')"); bt.parentNode.insertBefore(n, bt.nextSibling); }
    var os = root.show;
    if (typeof os === 'function' && !root.__exbTflShow) {
      root.__exbTflShow = 1;
      root.show = function (x) { var r = os.apply(this, arguments), e = $('tflSec'); if (e) e.style.display = (x === 'tflSec') ? '' : 'none'; var b = $('btfl'); if (b) b.classList.toggle('active', x === 'tflSec'); if (x === 'tflSec') { render(); candidaturesEnLigne(false).then(refresh); } return r; };
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(mount, 1200); }); else setTimeout(mount, 1200);
})(typeof window !== 'undefined' ? window : globalThis);
