# V99zzi — L'assistant vocal contrôle les champs dans TOUS les écrans (pas seulement les PDF)

**Aucun SQL.** Fichiers modifiés : `exb-guide.js`, `exb-generator.html` (1 balise), `sw.js` (cache `exb-v99zzi-guide-tous-ecrans-1`), `exb-v99r-shell.js` (version), `tools/e2e-guide.py`. Cumule V99zzh (approbations, TP/TD, chantier, lecture des erreurs).

## Principe : contrôle au CLIC
Quand vous touchez **Enregistrer, Sauvegarder, Exporter, Imprimer, Générer, Valider, Approuver, Créer, Envoyer, Publier, Confirmer, Télécharger, Importer, Émettre, Clôturer, Encaisser, PDF**, l'assistant vérifie les champs de l'écran. Si un champ obligatoire est vide : l'action est suspendue, la voix dit quoi remplir (« Veuillez d'abord renseigner le champ « Nom & prénom » avant d'enregistrer… »), le champ est surligné en rouge et reçoit le curseur. Une fois rempli, l'action se fait normalement.
Il fonctionne dans l'écran principal, dans le **générateur de licences clients** (🔑) et dans l'écran **Calcul de structure**.

## Qui est « obligatoire » ?
1. **Règles propres** (déjà listées en V99zzg/V99zzh) pour les fonctions principales.
2. **Tout champ déjà marqué dans le logiciel** : étoile *, mot « obligatoire », attribut required (78 libellés marqués à l'audit). Un champ marqué « facultatif / optionnel » est ignoré.
3. **Mode « tous les champs »** (Paramètres › Assistant guidé & voix, désactivé par défaut) : au clic, tout champ visible laissé vide est réclamé, sauf « facultatif » et les barres de recherche. À activer pour que « rien ne soit oublié » ; à désactiver si un formulaire a des champs volontairement vides.

## Licences clients (générateur 🔑)
Avant « Générer la licence et les liens » : nom du client, adresse de chaque logiciel coché (https://…), date de fin, au moins un logiciel ; et (mode strict) WhatsApp du client, e-mail du compte du logiciel principal, identifiant du compte chantier ; mot de passe / code provisoire dès qu'un e-mail est saisi. Le mode strict (Paramètres) assouplit ces champs « facultatifs » d'origine si besoin.

## Visa, cachet, identité avant tout document client
Avant d'exporter ou d'imprimer un **devis, un reçu, un certificat (y compris en lot) ou une facture de chantier** : l'assistant exige (mode strict) la signature + le cachet (Paramètres › Logo Excellencia Building) et l'identité de l'entreprise (téléphone, e-mail, adresse). Sinon : voix + bouton « ➡ Ouvrir Paramètres ».
**Note de calcul** : avant « Imprimer » : client, projet, lieu, ingénieur ; (mode strict) vérificateur ; et validation par un ingénieur avec cachet, ou case « Brouillon » cochée.

## Limites (à lire)
- Un formulaire sans aucun champ marqué obligatoire n'est contrôlé que si vous activez le mode « tous les champs » : l'application ne sait pas, seule, quel champ vous jugez indispensable. Dites-moi les champs de chaque écran pour que je les marque.
- Le mode « tous les champs » peut réclamer un champ que vous laissez volontairement vide : mettez « (facultatif) » dans son libellé, ou désactivez le mode.
- L'écran est identifié par le bouton cliqué et le bloc qui le contient : deux formulaires dans le même bloc partagent leurs champs obligatoires.
- Les boutons « Ajouter / Appliquer / Modifier / Supprimer » ne sont pas contrôlés (ils ne finalisent rien).
- La voix dépend du navigateur ; sans voix, carte et surlignage restent. Une action lancée par du code (sans clic) n'est contrôlée que par les règles propres.

## Tests
`python3 tools/e2e-guide.py` (clic générique, mode « tous les champs », visa/cachet, générateur de licences dans sa page, note de calcul dans l'iframe) · `node tools/check.js` (355) · `tools/e2e-smoke.py`.
Retour en arrière : restaurer `exb-guide.js`, `exb-generator.html`, `sw.js`, `exb-v99r-shell.js` de V99zzh.
