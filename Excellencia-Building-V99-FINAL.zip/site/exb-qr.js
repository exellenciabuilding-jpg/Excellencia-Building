/* Excellencia Building V76 — générateur de QR code 100 % hors ligne (octets, correction M, versions 1 à 10, jusqu'à 213 caractères).
 * EXBQR.matrix(texte) -> tableau de lignes de booléens ; EXBQR.svg(texte, {px, quiet}) -> chaîne SVG. */
(function(w){'use strict';
var ECC=[10,16,26,18,24,16,18,22,22,26], NB=[1,1,1,2,2,4,4,4,5,5]; /* octets ECC par bloc / nombre de blocs, niveau M, versions 1..10 */
function gfMul(x,y){var z=0;for(var i=7;i>=0;i--){z=(z<<1)^((z>>>7)*0x11D);z^=((y>>>i)&1)*x}return z&255}
function rsDiv(deg){var r=[],i,j;for(i=0;i<deg-1;i++)r.push(0);r.push(1);var root=1;for(i=0;i<deg;i++){for(j=0;j<r.length;j++){r[j]=gfMul(r[j],root);if(j+1<r.length)r[j]^=r[j+1]}root=gfMul(root,2)}return r}
function rsRem(data,div){var r=div.map(function(){return 0});data.forEach(function(b){var f=b^r.shift();r.push(0);div.forEach(function(c,i){r[i]^=gfMul(c,f)})});return r}
function rawModules(v){var r=(16*v+128)*v+64;if(v>=2){var a=Math.floor(v/7)+2;r-=(25*a-10)*a-55;if(v>=7)r-=36}return r}
function dataCw(v){return Math.floor(rawModules(v)/8)-ECC[v-1]*NB[v-1]}
function utf8(s){return Array.from(unescape(encodeURIComponent(s))).map(function(c){return c.charCodeAt(0)})}
function bit(x,i){return ((x>>>i)&1)!==0}
function encode(text){var b=utf8(String(text)),v,i;
 for(v=1;v<=10;v++){var cc=v<=9?8:16;if(4+cc+8*b.length<=dataCw(v)*8)break}
 if(v>10)throw new Error('Texte trop long pour le QR ('+b.length+' octets, max 213).');
 var bits=[];function put(val,n){for(var k=n-1;k>=0;k--)bits.push((val>>>k)&1)}
 put(4,4);put(b.length,v<=9?8:16);b.forEach(function(x){put(x,8)});
 var cap=dataCw(v)*8;put(0,Math.min(4,cap-bits.length));while(bits.length%8)bits.push(0);
 var data=[];for(i=0;i<bits.length;i+=8){var o=0;for(var k=0;k<8;k++)o=(o<<1)|bits[i+k];data.push(o)}
 for(var pad=0xEC;data.length<dataCw(v);pad^=0xEC^0x11)data.push(pad);
 var nb=NB[v-1],el=ECC[v-1],raw=Math.floor(rawModules(v)/8),ns=nb-raw%nb,sl=Math.floor(raw/nb),blocks=[],div=rsDiv(el),k2=0;
 for(i=0;i<nb;i++){var dat=data.slice(k2,k2+sl-el+(i<ns?0:1));k2+=dat.length;var ecc=rsRem(dat,div);if(i<ns)dat.push(0);blocks.push(dat.concat(ecc))}
 var res=[];for(i=0;i<blocks[0].length;i++)blocks.forEach(function(bl,j){if(i!==sl-el||j>=ns)res.push(bl[i])});
 return {ver:v,cw:res}}
function build(text){var e=encode(text),ver=e.ver,size=ver*4+17,m=[],f=[],x,y,i,j;
 for(y=0;y<size;y++){m.push(new Array(size).fill(false));f.push(new Array(size).fill(false))}
 function setF(x,y,d){m[y][x]=d;f[y][x]=true}
 for(i=0;i<size;i++){setF(6,i,i%2===0);setF(i,6,i%2===0)}
 function finder(cx,cy){for(var dy=-4;dy<=4;dy++)for(var dx=-4;dx<=4;dx++){var d=Math.max(Math.abs(dx),Math.abs(dy)),xx=cx+dx,yy=cy+dy;if(xx>=0&&xx<size&&yy>=0&&yy<size)setF(xx,yy,d!==2&&d!==4)}}
 finder(3,3);finder(size-4,3);finder(3,size-4);
 var pos=[];if(ver>1){var na=Math.floor(ver/7)+2,step=Math.ceil((ver*4+4)/(na*2-2))*2;pos=[6];for(var p=size-7;pos.length<na;p-=step)pos.splice(1,0,p)}
 for(i=0;i<pos.length;i++)for(j=0;j<pos.length;j++){if((i===0&&j===0)||(i===0&&j===pos.length-1)||(i===pos.length-1&&j===0))continue;
  for(var dy=-2;dy<=2;dy++)for(var dx=-2;dx<=2;dx++)setF(pos[i]+dx,pos[j]+dy,Math.max(Math.abs(dx),Math.abs(dy))!==1)}
 function fmt(mask){var i,d=(0<<3)|mask,r=d;for(i=0;i<10;i++)r=(r<<1)^((r>>>9)*0x537);var bits=((d<<10)|r)^0x5412;
  for(i=0;i<=5;i++)setF(8,i,bit(bits,i));setF(8,7,bit(bits,6));setF(8,8,bit(bits,7));setF(7,8,bit(bits,8));for(i=9;i<15;i++)setF(14-i,8,bit(bits,i));
  for(i=0;i<8;i++)setF(size-1-i,8,bit(bits,i));for(i=8;i<15;i++)setF(8,size-15+i,bit(bits,i));setF(8,size-8,true)}
 fmt(0);
 if(ver>=7){var r=ver;for(i=0;i<12;i++)r=(r<<1)^((r>>>11)*0x1F25);var vb=(ver<<12)|r;for(i=0;i<18;i++){var c=bit(vb,i),a=size-11+i%3,b=Math.floor(i/3);setF(a,b,c);setF(b,a,c)}}
 var k=0,cw=e.cw;for(var right=size-1;right>=1;right-=2){if(right===6)right=5;for(var vert=0;vert<size;vert++)for(j=0;j<2;j++){x=right-j;var up=((right+1)&2)===0;y=up?size-1-vert:vert;if(!f[y][x]&&k<cw.length*8){m[y][x]=bit(cw[k>>>3],7-(k&7));k++}}}
 function mask(n){for(y=0;y<size;y++)for(x=0;x<size;x++){var inv;switch(n){case 0:inv=(x+y)%2===0;break;case 1:inv=y%2===0;break;case 2:inv=x%3===0;break;case 3:inv=(x+y)%3===0;break;case 4:inv=(Math.floor(x/3)+Math.floor(y/2))%2===0;break;case 5:inv=x*y%2+x*y%3===0;break;case 6:inv=(x*y%2+x*y%3)%2===0;break;default:inv=((x+y)%2+x*y%3)%2===0}if(!f[y][x]&&inv)m[y][x]=!m[y][x]}}
 function penalty(){var s=0,dark=0,a,b;
  for(a=0;a<size;a++){var rr=1,cr=1;for(b=1;b<size;b++){if(m[a][b]===m[a][b-1]){rr++;if(rr===5)s+=3;else if(rr>5)s++}else rr=1;if(m[b][a]===m[b-1][a]){cr++;if(cr===5)s+=3;else if(cr>5)s++}else cr=1}}
  for(a=0;a<size-1;a++)for(b=0;b<size-1;b++){var c=m[a][b];if(c===m[a][b+1]&&c===m[a+1][b]&&c===m[a+1][b+1])s+=3}
  for(a=0;a<size;a++)for(b=0;b<size;b++)if(m[a][b])dark++;
  var tot=size*size;s+=(Math.ceil(Math.abs(dark*20-tot*10)/tot)-1)*10;return s}
 var best=0,bp=1e9;for(i=0;i<8;i++){mask(i);fmt(i);var pn=penalty();if(pn<bp){bp=pn;best=i}mask(i)}
 mask(best);fmt(best);return m}
function svg(text,o){o=o||{};var m=build(text),q=o.quiet==null?4:o.quiet,n=m.length,t=n+2*q,px=o.px||160,d='';
 for(var y=0;y<n;y++)for(var x=0;x<n;x++)if(m[y][x])d+='M'+(x+q)+','+(y+q)+'h1v1h-1z';
 return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+t+' '+t+'" width="'+px+'" height="'+px+'" shape-rendering="crispEdges"><rect width="'+t+'" height="'+t+'" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>'}
w.EXBQR={matrix:build,svg:svg,maxBytes:213};
})(typeof window!=='undefined'?window:this);
