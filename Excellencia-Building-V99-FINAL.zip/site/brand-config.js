/* Réglages par défaut de l'édition standard.
 * setupRequired:true  → au premier lancement, l'entreprise cliente voit l'écran de configuration.
 * setupRequired:false → pas d'écran (utile pour VOTRE propre exemplaire, avec vos valeurs ci-dessous). */
window.EXB_BRAND_DEFAULT = {
  setupRequired: true
  /* Exemple d'exemplaire préconfiguré (décommentez et adaptez, puis mettez setupRequired:false) :
  , name:'Ma Société SARL', short:'Ma Société', chantier:'Ma Société Chantier',
  primary:'#173565', secondary:'#0f4aa8', accent:'#c49a38', phone:'+243…', email:'contact@…', address:'…' */
};
