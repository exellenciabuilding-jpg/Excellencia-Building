/* Excellencia Building V96 — AI/Copilot local orchestration, permission-aware */
(function(w){'use strict';
function can(action){try{if(w.EXB_CORE&&typeof w.EXB_CORE.can==='function')return !!w.EXB_CORE.can(action,'ecrire')}catch(e){} try{if(w.EXBDB&&typeof w.EXBDB.can==='function')return !!w.EXBDB.can(action,'ecrire')}catch(e){} return true}
function insight(kind,context){const c=context||{};const out={kind:String(kind||'analyse'),created_at:new Date().toISOString(),confidence:0.65,requires_human_validation:true,actions:[]};
 if(kind==='project_risk'){const av=Number(c.avancement||0),budget=Number(c.budget||0),spent=Number(c.spent||0);out.confidence=0.78;out.actions=spent>budget?[{type:'alert',label:'Dépassement budgétaire à vérifier',severity:'high'}]:av<Number(c.expected||av)?[{type:'review',label:'Retard potentiel : revoir planning et ressources',severity:'medium'}]:[{type:'monitor',label:'Projet dans la trajectoire déclarée',severity:'low'}]}
 else if(kind==='procurement'){out.confidence=0.72;out.actions=[{type:'compare',label:'Comparer fournisseurs, délai et coût total',severity:'medium'},{type:'approval',label:'Soumettre la commande à validation humaine',severity:'high'}]}
 else if(kind==='training'){out.confidence=0.74;out.actions=[{type:'review',label:'Identifier les apprenants à risque selon présence/évaluation',severity:'medium'},{type:'certificate',label:'Vérifier les critères avant certification',severity:'high'}]}
 else {out.actions=[{type:'review',label:'Analyse proposée — aucune écriture automatique',severity:'low'}]}
 return out}
function propose(kind,context){const r=insight(kind,context);try{if(w.EXB_CORE&&w.EXB_CORE.audit)w.EXB_CORE.audit('AI_PROPOSITION',kind,'ai','')}catch(e){}return r}
function execute(action,context){if(!can(action))throw new Error('Droit insuffisant pour cette action.');return {accepted:true,action,requires_human_validation:true,context:context||{},at:new Date().toISOString()}}
function dashboard(data){const d=data||{};return {alerts:(d.alerts||[]).length,risks:(d.risks||[]).length,pendingApprovals:(d.pendingApprovals||[]).length,recommendations:(d.recommendations||[]).length}}
w.EXB_AI_V96={version:'V96-Enterprise',propose,execute,insight,dashboard,policy:'L’IA propose et explique ; les actions sensibles restent soumises à validation humaine.'};
})(window);
