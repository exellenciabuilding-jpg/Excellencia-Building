EXCELLENCIA BUILDING V90 — ARCHITECTURE ENTERPRISE

Architecture cible:
CORE / ERP / BTP / ARCHITECTURE / FORMATION / AI.

La migration est progressive et non destructive. Le noyau V81 reste compatible; le shell Enterprise expose les domaines et réutilise les modules existants. Les nouveaux modules doivent passer par les services Core (droits, audit, synchronisation) avant écriture des données critiques.

Ordre recommandé des prochaines migrations:
1. Core transversal
2. ERP: CRM, Finance, Achats, Stocks, RH, Comptabilité
3. BTP: Projets, Chantiers, Planning, QHSE, Matériel, Sous-traitance
4. Architecture: Études, Plans, BIM, CDE
5. Formation
6. AI: Copilot, Prévisions, Analyse, Reporting
