/* exb-mfa.js — V99zp : double authentification (TOTP : Google Authenticator, Microsoft Authenticator, Authy…).
 * - À la connexion : si le compte a un facteur TOTP vérifié, un code à 6 chiffres est demandé (session aal2).
 * - Bouton « 🔐 2FA » (en bas à gauche, une fois connecté) : activer / désactiver.
 * - Le serveur impose la règle (fonction mfa_ok() dans migration-v99zp) ; ce fichier ne fait que l'interface.
 * Les comptes en connexion automatique par lien (exb-account) n'utilisent pas la 2FA : réservez-la aux comptes administrateur. */
(function () {
  'use strict';
  var sb = window.exbSb; if (!sb || window.exbMfa) return;
  var origSet = sb.set, busy = false, lastTok = null;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); };
  function aalOf(tok) { try { var p = tok.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'); return JSON.parse(atob(p + '==='.slice((p.length + 3) % 4))).aal || 'aal1'; } catch (e) { return 'aal1'; } }
  function cfg() { return sb.cfg(); }
  function call(path, method, body, tok) {
    var c = cfg();
    return fetch(c.url + path, { method: method || 'GET', headers: { apikey: c.key, 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: body ? JSON.stringify(body) : undefined })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) throw new Error(d.msg || d.message || d.error_description || ('Erreur ' + r.status)); return d; }); });
  }
  function tok() { try { var s = JSON.parse(localStorage.getItem('EXB_SB_TOKEN') || 'null'); return s && s.access_token; } catch (e) { return null; } }
  function totpFactor(user) { var f = (user && user.factors) || []; for (var i = 0; i < f.length; i++) if (f[i].factor_type === 'totp' && f[i].status === 'verified') return f[i]; return null; }
  function setSession(d) { origSet.call(sb, { access_token: d.access_token, refresh_token: d.refresh_token, exp: Date.now() + (d.expires_in || 3600) * 1000 }); }

  function modal(html) {
    var o = $('exbMfaUI'); if (o) o.remove();
    o = document.createElement('div'); o.id = 'exbMfaUI';
    o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.72);display:flex;align-items:center;justify-content:center;padding:14px;font:15px system-ui,sans-serif;color:#172033';
    o.innerHTML = '<div style="background:#fff;border-radius:14px;padding:20px;max-width:380px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,.35)">' + html + '</div>';
    document.body.appendChild(o); return o;
  }
  var BTN = 'width:100%;padding:11px;border:0;border-radius:9px;font-size:15px;font-weight:600;cursor:pointer;margin-top:8px;';
  var INP = 'width:100%;box-sizing:border-box;padding:11px;border:1px solid #cbd5e1;border-radius:9px;font-size:22px;letter-spacing:6px;text-align:center;margin-top:8px';

  /* demande du code à la connexion */
  function challenge(factorId, token) {
    return new Promise(function (res, rej) {
      var o = modal('<h2 style="margin:0 0 4px;color:#173565">Code de sécurité</h2><p style="margin:0;color:#64748b;font-size:13px">Saisissez le code à 6 chiffres de votre application d’authentification.</p>' +
        '<input id="mfaC" inputmode="numeric" autocomplete="one-time-code" maxlength="6" style="' + INP + '" placeholder="······"><div id="mfaM" style="color:#b91c1c;font-size:13px;min-height:18px;margin-top:6px"></div>' +
        '<button id="mfaOk" style="' + BTN + 'background:#0f4aa8;color:#fff">Valider</button><button id="mfaNo" style="' + BTN + 'background:#eef2f7;color:#173565">Annuler (se déconnecter)</button>');
      var inp = o.querySelector('#mfaC'), msg = o.querySelector('#mfaM'); inp.focus();
      function go() {
        var code = inp.value.replace(/\s/g, ''); if (!/^\d{6}$/.test(code)) { msg.textContent = 'Le code comporte 6 chiffres.'; return; }
        msg.style.color = '#64748b'; msg.textContent = 'Vérification…';
        call('/auth/v1/factors/' + factorId + '/challenge', 'POST', {}, token)
          .then(function (ch) { return call('/auth/v1/factors/' + factorId + '/verify', 'POST', { challenge_id: ch.id, code: code }, token); })
          .then(function (d) { o.remove(); res(d); })
          .catch(function (e) { msg.style.color = '#b91c1c'; msg.textContent = /invalid|expired|incorrect/i.test(e.message) ? 'Code incorrect ou expiré. Réessayez.' : e.message; inp.value = ''; inp.focus(); });
      }
      o.querySelector('#mfaOk').onclick = go; inp.onkeydown = function (e) { if (e.key === 'Enter') go(); };
      o.querySelector('#mfaNo').onclick = function () { o.remove(); rej(new Error('annulé')); };
    });
  }

  /* contrôle après chaque ouverture de session */
  function gate(token) {
    if (busy || !token || aalOf(token) === 'aal2') return;
    busy = true;
    call('/auth/v1/user', 'GET', null, token).then(function (u) {
      var f = totpFactor(u); if (!f) return;
      return challenge(f.id, token).then(function (d) { setSession(d); try { location.reload(); } catch (e) {} }, function () { origSet.call(sb, null); try { location.reload(); } catch (e) {} });
    }).catch(function () {}).then(function () { busy = false; });
  }
  sb.set = function (v) { origSet.call(sb, v); if (v && v.access_token && v.access_token !== lastTok) { lastTok = v.access_token; if (aalOf(v.access_token) !== 'aal2') gate(v.access_token); } };
  setTimeout(function () { var t = tok(); if (t) gate(t); }, 1200);

  /* activation / désactivation */
  function panel() {
    var t = tok(); if (!t) return;
    call('/auth/v1/user', 'GET', null, t).then(function (u) {
      var f = totpFactor(u);
      if (f) {
        var o = modal('<h2 style="margin:0 0 6px;color:#173565">🔐 Double authentification</h2><p style="margin:0;color:#15803d;font-weight:600">Activée sur ce compte.</p><p style="color:#64748b;font-size:13px">Pour la désactiver, un code actuel est exigé.</p>' +
          '<input id="mfaC" inputmode="numeric" maxlength="6" style="' + INP + '" placeholder="······"><div id="mfaM" style="color:#b91c1c;font-size:13px;min-height:18px"></div>' +
          '<button id="mfaOff" style="' + BTN + 'background:#b91c1c;color:#fff">Désactiver</button><button id="mfaX" style="' + BTN + 'background:#eef2f7;color:#173565">Fermer</button>');
        o.querySelector('#mfaX').onclick = function () { o.remove(); };
        o.querySelector('#mfaOff').onclick = function () {
          var code = o.querySelector('#mfaC').value.trim(), m = o.querySelector('#mfaM');
          call('/auth/v1/factors/' + f.id + '/challenge', 'POST', {}, t).then(function (ch) { return call('/auth/v1/factors/' + f.id + '/verify', 'POST', { challenge_id: ch.id, code: code }, t); })
            .then(function (d) { return call('/auth/v1/factors/' + f.id, 'DELETE', null, d.access_token).then(function () { setSession(d); o.remove(); alert('Double authentification désactivée.'); }); })
            .catch(function (e) { m.textContent = e.message; });
        };
      } else {
        call('/auth/v1/factors', 'POST', { factor_type: 'totp', friendly_name: 'Excellencia ' + Date.now() }, t).then(function (e) {
          var qr = e.totp && e.totp.qr_code || '', src = /^data:/.test(qr) ? qr : 'data:image/svg+xml;utf-8,' + encodeURIComponent(qr);
          var o = modal('<h2 style="margin:0 0 6px;color:#173565">🔐 Activer la 2FA</h2><p style="margin:0;color:#64748b;font-size:13px">1. Scannez ce QR code avec Google Authenticator, Microsoft Authenticator ou Authy.<br>2. Saisissez le code à 6 chiffres affiché.</p>' +
            '<div style="text-align:center"><img alt="QR" src="' + esc(src) + '" style="width:180px;height:180px;margin:8px auto"></div><p style="font-size:12px;color:#64748b;word-break:break-all;margin:0">Saisie manuelle : <b>' + esc(e.totp && e.totp.secret) + '</b></p>' +
            '<input id="mfaC" inputmode="numeric" maxlength="6" style="' + INP + '" placeholder="······"><div id="mfaM" style="color:#b91c1c;font-size:13px;min-height:18px"></div>' +
            '<button id="mfaOk" style="' + BTN + 'background:#0f4aa8;color:#fff">Activer</button><button id="mfaX" style="' + BTN + 'background:#eef2f7;color:#173565">Annuler</button>');
          o.querySelector('#mfaX').onclick = function () { call('/auth/v1/factors/' + e.id, 'DELETE', null, t).catch(function () {}); o.remove(); };
          o.querySelector('#mfaOk').onclick = function () {
            var code = o.querySelector('#mfaC').value.trim(), m = o.querySelector('#mfaM');
            call('/auth/v1/factors/' + e.id + '/challenge', 'POST', {}, t).then(function (ch) { return call('/auth/v1/factors/' + e.id + '/verify', 'POST', { challenge_id: ch.id, code: code }, t); })
              .then(function (d) { setSession(d); o.remove(); alert('Double authentification activée. Notez le code de secours (secret) en lieu sûr.'); })
              .catch(function (er) { m.textContent = /invalid|expired/i.test(er.message) ? 'Code incorrect. Réessayez.' : er.message; });
          };
        }).catch(function (e) { alert('2FA indisponible : ' + e.message + '\nVérifiez que « Multi-Factor / TOTP » est activé dans Supabase › Authentication.'); });
      }
    }).catch(function (e) { alert(e.message); });
  }
  window.exbMfa = { open: panel, aalOf: aalOf };

  function btn() {
    var b = $('exbMfaBtn'), on = !!tok();
    if (!b) { b = document.createElement('button'); b.id = 'exbMfaBtn'; b.textContent = '🔐 2FA'; b.title = 'Double authentification';
      b.style.cssText = 'position:fixed;left:10px;bottom:10px;z-index:9990;padding:7px 11px;border:0;border-radius:18px;background:#173565;color:#fff;font:600 13px system-ui;opacity:.85;cursor:pointer;display:none';
      b.onclick = panel; document.body.appendChild(b); }
    b.style.display = on ? '' : 'none';
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', btn); else btn();
  setInterval(btn, 4000);
})();
