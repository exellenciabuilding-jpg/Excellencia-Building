/* EXCELLENCIA BUILDING — V92 ERP Enterprise
 * Flux ERP transversal : CRM → Achats → Réception → Stock → Facture → Finance/Comptabilité → RH/Paie.
 * Mode local robuste + adaptateur Supabase prêt lorsque EXBS est connecté.
 */
(function(w,d){'use strict';
  const VERSION='V92-ERP-Enterprise';
  const K={crm:'exb_v92_crm',suppliers:'exb_v92_suppliers',requests:'exb_v92_purchase_requests',orders:'exb_v92_purchase_orders',receipts:'exb_v92_receipts',invoices:'exb_v92_supplier_invoices',stock:'exb_v92_stock',moves:'exb_v92_stock_moves',bank:'exb_v92_bank',bankTx:'exb_v92_bank_tx',employees:'exb_v92_employees',contracts:'exb_v92_contracts',payroll:'exb_v92_payroll'};
  const uid=p=>(p||'ERP')+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
  const store=()=>w.exbStorage||localStorage;
  function get(k){try{const v=JSON.parse(store().getItem(k)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}}
  function put(k,v){try{store().setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function add(k,row){const a=get(k);a.unshift(Object.assign({id:uid('ERP'),created_at:new Date().toISOString()},row));put(k,a);return a[0]}
  function audit(a,d,c,id){try{if(w.EXB_CORE&&w.EXB_CORE.audit)w.EXB_CORE.audit(a,d,c,id)}catch(e){}}
  function notify(t,type){try{if(w.EXB_CORE&&w.EXB_CORE.notify)w.EXB_CORE.notify(t,type||'info')}catch(e){}}
  function can(c,m){try{return !w.EXB_CORE||!w.EXB_CORE.can||w.EXB_CORE.can(c,m||'lire')}catch(e){return true}}
  function sum(a,f){return a.reduce((s,x)=>s+(Number(x[f])||0),0)}
  function kpis(){
    const orders=get(K.orders), invoices=get(K.invoices), moves=get(K.moves), employees=get(K.employees), req=get(K.requests);
    const committed=sum(orders,'amount'), supplierDue=sum(invoices.filter(x=>x.status!=='paid'),'amount'), stockIn=sum(moves.filter(x=>x.type==='in'),'quantity'), stockOut=sum(moves.filter(x=>x.type==='out'),'quantity');
    return {prospects:get(K.crm).length,fournisseurs:get(K.suppliers).length,demandes:req.filter(x=>x.status!=='closed').length,commandes:orders.length,engagements:committed,facturesFournisseurs:invoices.length,dettesFournisseurs:supplierDue,stockMouvements:moves.length,stockNet:stockIn-stockOut,salaries:employees.length,banques:get(K.bank).length};
  }
  async function server(table,payload,method){
    try{if(!(w.exbSb&&w.exbSb.isIn&&w.exbSb.isIn()&&typeof w.exbSb.api==='function'))return null;return await w.exbSb.api('/rest/v1/'+table,{method:method||'POST',body:JSON.stringify(payload),headers:{'Content-Type':'application/json','Prefer':'return=representation'}})}catch(e){return null}
  }
  function createPurchaseRequest(data){if(!can('achats','ecrire'))throw Error('Droits insuffisants');const r=add(K.requests,Object.assign({status:'draft'},data));audit('purchase_request_created','Demande d’achat '+r.id,'achats',r.id);return r}
  function createPurchaseOrder(data){if(!can('achats','ecrire'))throw Error('Droits insuffisants');const r=add(K.orders,Object.assign({status:'pending_approval'},data));audit('purchase_order_created','Commande '+r.id,'achats',r.id);notify('Nouvelle commande à valider','warn');return r}
  function receiveOrder(data){if(!can('achats','ecrire'))throw Error('Droits insuffisants');const r=add(K.receipts,Object.assign({status:'received'},data));if(data.item_id&&data.quantity){add(K.moves,{item_id:data.item_id,type:'in',quantity:Number(data.quantity),reference:r.id,order_id:data.order_id||''})}audit('purchase_received','Réception '+r.id,'achats',r.id);return r}
  function createSupplierInvoice(data){if(!can('achats','ecrire'))throw Error('Droits insuffisants');const r=add(K.invoices,Object.assign({status:'unpaid'},data));audit('supplier_invoice_created','Facture fournisseur '+r.id,'achats',r.id);notify('Nouvelle facture fournisseur','warn');return r}
  function stockMovement(data){if(!can('stocks','ecrire'))throw Error('Droits insuffisants');const r=add(K.moves,data);audit('stock_movement','Mouvement '+r.type+' '+r.quantity,'stocks',r.id);return r}
  function addEmployee(data){if(!can('rh','ecrire'))throw Error('Droits insuffisants');const r=add(K.employees,Object.assign({status:'active'},data));audit('employee_created','Salarié '+r.id,'rh',r.id);return r}
  function addContract(data){if(!can('contrats_rh','ecrire'))throw Error('Droits insuffisants');const r=add(K.contracts,data);audit('employee_contract_created','Contrat '+r.id,'contrats_rh',r.id);return r}
  function createPayroll(data){if(!can('paie','ecrire'))throw Error('Droits insuffisants');const r=add(K.payroll,Object.assign({status:'draft'},data));audit('payroll_created','Paie '+r.id,'paie',r.id);return r}
  function addBankTransaction(data){if(!can('rapprochement_bancaire','ecrire'))throw Error('Droits insuffisants');const r=add(K.bankTx,Object.assign({reconciled:false},data));audit('bank_transaction','Transaction bancaire '+r.id,'rapprochement_bancaire',r.id);return r}
  function render(){
    const host=d.getElementById('exb92_erp_root');if(!host)return;const p=kpis();
    const cards=[['CRM',p.prospects,'prospects'],['Fournisseurs',p.fournisseurs,'fournisseurs'],['Achats ouverts',p.demandes,'demandes'],['Commandes',p.commandes,'commandes'],['Engagements',p.engagements.toFixed(2),'engagements'],['Factures fournisseurs',p.facturesFournisseurs,'factures'],['Dettes fournisseurs',p.dettesFournisseurs.toFixed(2),'dettes'],['Salariés',p.salaries,'salaries']];
    host.innerHTML='<div class="exb92-head"><div><h3>ERP Enterprise</h3><p>Flux unifié CRM → Achats → Stocks → Finance → RH → Comptabilité.</p></div><span class="exb92-badge">V92</span></div><div class="exb92-kpis">'+cards.map(c=>'<div class="exb92-kpi"><b>'+c[1]+'</b><span>'+c[0]+'</span></div>').join('')+'</div><div class="exb92-flow"><div><strong>Flux achats</strong><span>Demande → Validation → Commande → Réception → Facture → Paiement</span></div><div><strong>Flux RH</strong><span>Employé → Contrat → Présence → Paie → Comptabilité</span></div><div><strong>Flux stock</strong><span>Commande → Réception → Stock → Sortie chantier → Coût projet</span></div></div>';
  }
  function mount(){
    if(!d.getElementById('exb92ERPStyles')){const s=d.createElement('style');s.id='exb92ERPStyles';s.textContent='.exb92-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin:12px 0}.exb92-head h3{margin:0}.exb92-head p{margin:4px 0;color:#64748b}.exb92-badge{background:#173565;color:#fff;border-radius:999px;padding:5px 10px;font-weight:700}.exb92-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px}.exb92-kpi{padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff}.exb92-kpi b{display:block;font-size:22px}.exb92-kpi span{color:#64748b;font-size:12px}.exb92-flow{display:grid;gap:10px;margin-top:14px}.exb92-flow div{padding:12px;border-radius:11px;background:#f7f9fc;border:1px solid #e4e9f0}.exb92-flow strong,.exb92-flow span{display:block}.exb92-flow span{margin-top:4px;color:#475569;font-size:13px}';d.head.appendChild(s)}
    const root=d.getElementById('exb90_root');if(root&&!d.getElementById('exb92_erp_root')){const x=d.createElement('div');x.id='exb92_erp_root';root.parentNode.insertBefore(x,root)}
    render();
  }
  w.EXB_ERP=Object.assign(w.EXB_ERP||{},{version:VERSION,keys:K,kpis,refresh:render,createPurchaseRequest,createPurchaseOrder,receiveOrder,createSupplierInvoice,stockMovement,addEmployee,addContract,createPayroll,addBankTransaction,syncServer:server});
  w.addEventListener('exb:erp-refresh',render);if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',()=>setTimeout(mount,0));else setTimeout(mount,0);
})(window,document);
