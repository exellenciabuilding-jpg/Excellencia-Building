# EXCELLENCIA INTELLIGENCE — lot 2 : corrections guidées, annulation, documents

Nouveau : `exb-intelligence-2.js` (chargé après `exb-intelligence.js`). Modifiés : `exb-intelligence.js` (extensions + correction), `index.html` (1 balise), `sw.js` (cache).

## Correction du lot 1
Les devis n'ont pas de champ « statut » dans votre logiciel : la recommandation « devis accepté sans facture » ne pouvait jamais se déclencher. Elle est remplacée par **« devis de plus de 15 jours sans facture liée »** (à vérifier : un devis facturé sans lien peut y figurer). « Préparer : <devis> » ouvre Chantiers & finances avec la facture pré-remplie par la fonction existante (EXBCH.fromQuote) ; rien n'est enregistré avant votre validation.

## Corrections guidées (toujours avec confirmation + inscription au journal)
- **Stock en double** : fusion (quantités additionnées, seuil le plus élevé, mouvements rattachés). **Annulable.**
- **Factures de même numéro** (le numéro automatique se base sur le nombre de factures, d'où les doublons après suppression) : la plus récente reçoit le prochain numéro libre ; les paiements restent rattachés. **Annulable.**
- **Clients en double** : fusion via la fonction existante de la liaison (EXBLIEN.dup.merge) ; la fiche supprimée reste dans le journal de la liaison. Non annulable depuis ce panneau.
- Doublons de projets, de participants et de devis : détectés et signalés, **pas de fusion automatique** (trop de modules en dépendent : certificats, reçus, chantiers).

## Documents automatiques
- **Relances prêtes** : un message par facture en retard (client, téléphone, n°, reste, échéance), copiables d'un appui.
- **Rapport de situation** (HTML, hors ligne) : facturation par devise, factures en retard, stock à réapprovisionner, résultat du contrôle.

## Historique
Les opérations annulables ont un bouton « ↩ Annuler cette opération » dans l'onglet Historique (confirmation demandée).

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-2.js">` de index.html.

## À confirmer sur vos appareils
Noms de droits utilisés : `stock` et `budgets_chantier` (EXB_CORE.can). Essayer d'abord sur une copie des données (sauvegarde ZIP existante).
