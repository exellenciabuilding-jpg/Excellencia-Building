/* Excellencia — licence à échéance (hors ligne, signée). Le client ne peut pas modifier la date : le code est signé par la clé privée de l'administrateur. */
(function(w){'use strict';
var PUB={"kty":"EC","crv":"P-256","x":"gCpjrY7LwHWYrCh9gdvZyC2wgFF7ghdI4vRWdXHfh0c","y":"99QF0mj8LF9emZjQvRcjSKooAqP0tSZBOD-T-IdtgJ4"};
var CFG=Object.assign({requireToken:false,warnDays:7,defaultGrace:7,contact:'l’administrateur Excellencia Building'},w.EXB_LICENSE_CONFIG||{});
var KT='exb_lic_token',KS='exb_lic_seen',KP='exb_lic_priv',subtle=w.crypto&&w.crypto.subtle,enc=new TextEncoder(),dec=new TextDecoder();
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){return null}}
function b64u(buf){var b=new Uint8Array(buf),s='';for(var i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function unb64u(s){s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';var r=atob(s),u=new Uint8Array(r.length);for(var i=0;i<r.length;i++)u[i]=r.charCodeAt(i);return u}
async function verify(tok){try{var a=String(tok||'').trim().split('.');if(a.length!==2)return null;var k=await subtle.importKey('jwk',PUB,{name:'ECDSA',namedCurve:'P-256'},false,['verify']),pl=unb64u(a[0]);
  var ok=await subtle.verify({name:'ECDSA',hash:'SHA-256'},k,unb64u(a[1]),pl);return ok?JSON.parse(dec.decode(pl)):null}catch(e){return null}}
/* Heure de confiance : jamais en arrière de la dernière heure vue ; recalée sur le serveur quand le réseau est disponible. */
var srv=0,srvAt=0;
function now(){var d=Date.now(),s=Number(ls(KS))||0,t=srv?srv+(d-srvAt):Math.max(d,s);if(!srv&&t<s)t=s;ls(KS,String(t));return t}
async function syncTime(){try{var c=w.EXB_SUPABASE||w.EXB_FIELD_CONFIG||{},u=c.url||c.supabaseUrl,k=c.key||c.supabaseKey;if(!u||!navigator.onLine)return;
  var r=await fetch(u+'/auth/v1/health',{headers:{apikey:k||''}}),d=r.headers.get('Date');if(d){var t=Date.parse(d);if(t>0){srv=t;srvAt=Date.now();ls(KS,String(t))}}}catch(e){}}
function isAdmin(){try{var p=JSON.parse(ls(KP)||'null');return !!(p&&p.d&&p.x===PUB.x)}catch(e){return false}}
async function state(){
  if(isAdmin())return{mode:'admin'};
  var tok=ls(KT);if(!tok)return CFG.requireToken?{mode:'locked',reason:'none'}:{mode:'free'};
  var p=await verify(tok);if(!p)return{mode:'locked',reason:'invalid'};
  var t=now(),exp=Date.parse(p.exp),g=(p.grace==null?CFG.defaultGrace:Number(p.grace))*864e5,left=exp-t;
  var info={name:p.name||'',exp:p.exp,graceDays:g/864e5,daysLeft:Math.ceil(left/864e5),blockAt:new Date(exp+g).toISOString()};
  if(left>CFG.warnDays*864e5)return Object.assign({mode:'ok'},info);
  if(left>0)return Object.assign({mode:'warn'},info);
  if(left+g>0)return Object.assign({mode:'grace',daysToBlock:Math.ceil((left+g)/864e5)},info);
  return Object.assign({mode:'locked',reason:'expired'},info)}
function fmt(iso){try{return new Date(iso).toLocaleString('fr-FR',{dateStyle:'long',timeStyle:'short'})}catch(e){return iso}}
function banner(h,bg){var b=document.getElementById('exbLicBar');if(!h){if(b)b.remove();return}if(!b){b=document.createElement('div');b.id='exbLicBar';document.body.appendChild(b)}
  b.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:99998;padding:10px 14px;font:14px system-ui;text-align:center;color:#fff;background:'+bg;b.innerHTML=h}
function lock(msg){var d=document.getElementById('exbLicLock');if(d&&d.getAttribute('data-msg')===msg)return;if(!d){d=document.createElement('div');d.id='exbLicLock';document.body.appendChild(d)}
  d.style.cssText='position:fixed;inset:0;z-index:100000;background:#173565;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;font:17px system-ui;overflow:auto';
  d.setAttribute('data-msg',msg);d.innerHTML='<div style="max-width:420px"><div style="font-size:48px">🔒</div><h2>Logiciel verrouillé</h2><p>'+msg+'</p><p style="font-size:14px;opacity:.85">Vous avez été invité(e) ? Saisissez <b>uniquement votre code d’invitation</b> (8 caractères, reçu dans le message). Sinon, contactez '+CFG.contact+' pour obtenir un code d’activation (ou ouvrez le lien reçu).</p><textarea id="exbLicIn" placeholder="Code d’invitation ou d’activation" autocapitalize="none" autocomplete="off" spellcheck="false" style="width:100%;min-height:70px;border-radius:10px;border:0;padding:10px;color:#000"></textarea><button id="exbLicGo" style="margin-top:10px;padding:12px 20px;border:0;border-radius:10px;background:#f5a623;font-weight:700">Activer</button><div id="exbLicMsg" style="margin-top:10px;color:#fecaca"></div></div>';
  document.getElementById('exbLicGo').onclick=async function(){var v=document.getElementById('exbLicIn').value.trim(),m=document.getElementById('exbLicMsg'),g=document.getElementById('exbLicGo');if(!v){m.textContent='Saisissez votre code.';return}g.disabled=true;m.textContent='Vérification…';var r=isInvCode(v)?await viaInvite(v):await apply(v);g.disabled=false;m.textContent=r.ok?'':r.msg;if(r.ok){if(r.reload)location.reload();else check()}};
  adminUI(d)}
/* V99zzzk — accès administrateur depuis l'écran de verrouillage (nouvelle installation, nouvel appareil).
 * Accepte : sauvegarde chiffrée (SAUVEGARDE-CLE-LICENCE-*.json + mot de passe) ou clé brute (CLE-PRIVEE-ADMIN.txt).
 * La clé n'est acceptée que si elle signe un code que la clé publique intégrée reconnaît. */
function unb64s(x){var b=atob(x),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
async function decBackup(f,pass){var m=await subtle.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);
  var k=await subtle.deriveKey({name:'PBKDF2',salt:unb64s(f.salt),iterations:f.iter||250000,hash:'SHA-256'},m,{name:'AES-GCM',length:256},false,['decrypt']);
  try{return dec.decode(await subtle.decrypt({name:'AES-GCM',iv:unb64s(f.iv)},k,unb64s(f.data)))}catch(e){throw new Error('Mot de passe incorrect ou fichier modifié.')}}
async function keyOk(j){try{if(!j||!j.d||j.x!==PUB.x)return false;var k=await subtle.importKey('jwk',j,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
  var b=enc.encode(JSON.stringify({v:1,name:'test',exp:new Date(Date.now()+864e5).toISOString(),grace:0,id:'test'})),sg=await subtle.sign({name:'ECDSA',hash:'SHA-256'},k,b);
  return !!(await verify(b64u(b)+'.'+b64u(sg)))}catch(e){return false}}
async function adminUnlock(text,pass,keep){
  var j;try{j=JSON.parse(String(text||'').trim())}catch(e){return{ok:false,msg:'Contenu illisible : choisissez le bon fichier ou collez la clé complète.'}}
  if(j&&j.app==='excellencia-licence-key'){if(!pass)return{ok:false,msg:'Saisissez le mot de passe de la sauvegarde.'};try{j=JSON.parse(await decBackup(j,pass))}catch(e){return{ok:false,msg:e.message||'Sauvegarde illisible.'}}}
  if(!await keyOk(j))return{ok:false,msg:'Cette clé ne correspond pas à ce logiciel.'};
  try{if(keep)localStorage.setItem('exb_lic_keep','1');else localStorage.removeItem('exb_lic_keep')}catch(e){}
  ls(KP,JSON.stringify(j));
  return isAdmin()?{ok:true}:{ok:false,msg:'Impossible d’enregistrer la clé sur cet appareil.'}}
function adminUI(d){var box=d.firstChild;if(!box)return;var wr=document.createElement('div');
  wr.style.cssText='margin-top:22px;border-top:1px solid rgba(255,255,255,.25);padding-top:14px';
  var inp='width:100%;box-sizing:border-box;border-radius:10px;border:0;padding:10px;color:#000;margin-top:8px';
  wr.innerHTML='<a href="#" id="exbAdmLnk" style="color:#fcd34d;font-size:14px;text-decoration:underline">🔑 Accès administrateur</a>'
   +'<div id="exbAdmBox" style="display:none;margin-top:12px;text-align:left;font-size:14px">'
   +'<p style="opacity:.85;margin:0">Choisissez votre <b>sauvegarde chiffrée</b> (SAUVEGARDE-CLE-LICENCE-….json) ou <b>CLE-PRIVEE-ADMIN.txt</b>, ou collez la clé.</p>'
   +'<input type="file" id="exbAdmFile" accept=".json,.txt,application/json,text/plain" style="width:100%;margin-top:8px;color:#fff">'
   +'<textarea id="exbAdmTxt" placeholder="…ou collez ici la clé privée" autocapitalize="none" autocomplete="off" spellcheck="false" style="'+inp+';min-height:60px"></textarea>'
   +'<input type="password" id="exbAdmPw" placeholder="Mot de passe de la sauvegarde (fichier chiffré)" autocomplete="off" style="'+inp+'">'
   +'<label style="display:block;margin-top:10px"><input type="checkbox" id="exbAdmKeep" checked> Garder la clé sur cet appareil <span style="opacity:.75">(appareil personnel uniquement)</span></label>'
   +'<button id="exbAdmGo" style="margin-top:10px;padding:12px 20px;border:0;border-radius:10px;background:#fcd34d;color:#000;font-weight:700;width:100%">Déverrouiller en administrateur</button>'
   +'<div id="exbAdmMsg" style="margin-top:10px;color:#fecaca;text-align:center"></div></div>';
  box.appendChild(wr);
  var $=function(i){return document.getElementById(i)},fileText='';
  $('exbAdmLnk').onclick=function(e){e.preventDefault();var b=$('exbAdmBox');b.style.display=b.style.display==='none'?'block':'none'};
  $('exbAdmFile').onchange=function(){var f=this.files&&this.files[0];if(!f){fileText='';return}var r=new FileReader();r.onload=function(){fileText=String(r.result||'');$('exbAdmMsg').style.color='#bbf7d0';$('exbAdmMsg').textContent='Fichier chargé : '+f.name}; r.onerror=function(){$('exbAdmMsg').textContent='Lecture du fichier impossible.'};r.readAsText(f)};
  $('exbAdmGo').onclick=async function(){var m=$('exbAdmMsg'),g=this;m.style.color='#fecaca';var t=(fileText||$('exbAdmTxt').value||'').trim();if(!t){m.textContent='Choisissez un fichier ou collez la clé.';return}
    g.disabled=true;m.textContent='Vérification…';var r=await adminUnlock(t,$('exbAdmPw').value,$('exbAdmKeep').checked);g.disabled=false;
    if(r.ok){m.style.color='#bbf7d0';m.textContent='✓ Appareil administrateur activé.';setTimeout(function(){location.reload()},600)}else m.textContent=r.msg}}
function unlock(){var d=document.getElementById('exbLicLock');if(d)d.remove()}
async function apply(tok){tok=String(tok||'').trim();var p=await verify(tok);if(!p)return{ok:false,msg:'Code invalide ou modifié.'};
  var cur=ls(KT),c=cur?await verify(cur):null;if(c&&Date.parse(c.exp)>Date.parse(p.exp)&&Date.parse(c.exp)>now())return{ok:false,msg:'Ce code est plus ancien que votre abonnement actuel.'};
  if(Date.parse(p.exp)+(p.grace==null?CFG.defaultGrace:p.grace)*864e5<=now())return{ok:false,msg:'Ce code est déjà expiré.'};
  ls(KT,tok);try{if(p.brand){var bo={};try{bo=JSON.parse(ls('EXB_BRAND_V1')||'{}')}catch(e){}var nb=Object.assign({},(bo&&bo.brand)||{},p.brand);ls('EXB_BRAND_V1',JSON.stringify({done:true,fixed:!!p.lockBrand,brand:nb}))}if(p.srv&&p.srv.url&&p.srv.key){var b2={};try{b2=JSON.parse(ls('EXB_BRAND_V1')||'{}')}catch(e){}b2.brand=Object.assign({},b2.brand||{},{supabaseUrl:p.srv.url,supabaseKey:p.srv.key});b2.done=true;ls('EXB_BRAND_V1',JSON.stringify(b2))}if(p.acct&&p.acct.id&&(p.acct.pw||p.acct.first))ls('EXB_ACCT_LOCK',JSON.stringify({id:p.acct.id,pw:p.acct.pw||'',first:!!p.acct.first,jid:p.id||''}));else ls('EXB_ACCT_LOCK',null)}catch(e){}return{ok:true,payload:p,reload:!!(p.brand||p.acct||p.srv)}}
async function check(){await syncTime();var s=await state();w.EXBLIC.last=s;
  if(s.mode==='locked'){banner(null);lock(s.reason==='none'?'Ce logiciel nécessite un code d’activation.':s.reason==='invalid'?'Code d’activation invalide.':'Votre abonnement a expiré le '+fmt(s.exp)+'.');return s}
  unlock();
  if(s.mode==='warn')banner('⏳ Votre abonnement expire le <b>'+fmt(s.exp)+'</b> (dans '+s.daysLeft+' jour(s)). Pensez à le renouveler.','#b45309');
  else if(s.mode==='grace')banner('⚠️ Abonnement expiré. Renouvelez-le : le logiciel sera <b>bloqué le '+fmt(s.blockAt)+'</b> (dans '+s.daysToBlock+' jour(s)).','#b91c1c');
  else banner(null);return s}
/* ---- Administrateur : génération de codes ---- */
async function make(o){var prv=JSON.parse(ls(KP)||'null');if(!prv||!prv.d)throw new Error('Clé privée absente.');var k=await subtle.importKey('jwk',prv,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
  var p={v:1,name:o.name||'',exp:new Date(o.exp).toISOString(),grace:o.grace==null?CFG.defaultGrace:Number(o.grace),iat:new Date().toISOString(),id:Math.random().toString(36).slice(2,9)},b=enc.encode(JSON.stringify(p)),sg=await subtle.sign({name:'ECDSA',hash:'SHA-256'},k,b);
  return b64u(b)+'.'+b64u(sg)}
async function adminDialog(){
  if(!isAdmin()){var k=prompt('Collez ici votre CLÉ PRIVÉE administrateur (fichier CLE-PRIVEE-ADMIN.txt). Elle reste sur cet appareil :');if(!k)return;try{var j=JSON.parse(k.trim());if(!j.d||j.x!==PUB.x)throw 0;ls(KP,JSON.stringify(j));alert('✓ Appareil administrateur activé : aucun blocage ne s’applique ici.')}catch(e){alert('Clé privée invalide.');return}}
  var name=prompt('Nom du client / centre :','');if(name===null)return;
  var d0=new Date(Date.now()+30*864e5),def=d0.getFullYear()+'-'+String(d0.getMonth()+1).padStart(2,'0')+'-'+String(d0.getDate()).padStart(2,'0')+' 23:59';
  var e=prompt('Date et heure d’expiration (AAAA-MM-JJ HH:MM) :',def);if(!e)return;var t=new Date(e.trim().replace(' ','T'));if(isNaN(t))return alert('Date invalide.');
  var g=prompt('Jours de tolérance après expiration (avertissement, puis blocage) :',String(CFG.defaultGrace));if(g===null)return;
  var tok=await make({name:name,exp:t,grace:Number(g)||0}),link=location.origin+location.pathname.replace(/[^\/]*$/,'')+'#lic='+tok;
  try{await navigator.clipboard.writeText(link)}catch(x){}
  prompt('✓ Lien copié. Envoyez-le au client (il active l’abonnement jusqu’au '+t.toLocaleString('fr-FR')+', blocage '+(Number(g)||0)+' jour(s) après) :',link)}
/* V99zzj — activation par CODE D'INVITATION seul : le serveur renvoie l'abonnement signé de l'entreprise. */
function srvCfg(){var c=w.EXB_SUPABASE||{},u=c.url,k=c.key;try{var b=JSON.parse(ls('EXB_BRAND_V1')||'{}'),br=(b&&b.brand)||{};if(br.supabaseUrl&&br.supabaseKey){u=br.supabaseUrl;k=br.supabaseKey}}catch(e){}return{u:u,k:k}}
function isInvCode(v){v=String(v||'').trim();return v.indexOf('.')<0&&/^[a-z0-9]{4,32}$/i.test(v)}
async function viaInvite(code){code=String(code||'').trim().toLowerCase();var s=srvCfg();
  if(!s.u||!s.k)return{ok:false,msg:'Serveur non configuré : demandez un lien d’activation à l’administrateur.'};
  if(navigator.onLine===false)return{ok:false,msg:'Connexion internet requise pour utiliser un code d’invitation.'};
  try{var r=await fetch(s.u+'/rest/v1/rpc/activer_par_invitation',{method:'POST',headers:{'Content-Type':'application/json',apikey:s.k},body:JSON.stringify({p_code:code})});
    var j=null;try{j=await r.json()}catch(e){}
    if(!r.ok){var t=JSON.stringify(j||'');if(/activer_par_invitation|42883|PGRST202|schema cache/i.test(t))return{ok:false,msg:'Le service d’invitation n’est pas encore installé sur le serveur (migration v99zzj). Prévenez l’administrateur.'};return{ok:false,msg:'Serveur indisponible, réessayez dans un instant.'}}
    if(!j||!j.ok)return{ok:false,msg:(j&&j.msg)||'Code d’invitation invalide.'};
    var a=await apply(j.jeton);
    if(!a.ok)return{ok:false,msg:a.msg==='Code invalide ou modifié.'?'L’abonnement de cette entreprise n’est pas valide. Prévenez l’administrateur.':a.msg};
    ls('exb_inv_code',code);
    try{sessionStorage.setItem('exb_lic_msg','✓ Accès activé. Créez maintenant votre compte avec l’adresse e-mail indiquée dans votre invitation : vous rejoindrez l’entreprise automatiquement.')}catch(e){}
    a.reload=true;return a}
  catch(e){return{ok:false,msg:'Impossible de joindre le serveur. Vérifiez votre connexion.'}}}
w.EXBLIC={viaInvite:viaInvite,verify:verify,state:state,check:check,apply:apply,adminDialog:adminDialog,isAdmin:isAdmin,make:make,CFG:CFG,last:null};
/* Démarrage : activation par lien #lic=..., puis contrôle régulier */
(async function(){try{var m=/[#&]lic=([^&]+)/.exec(location.hash||'');if(m){var r=await apply(decodeURIComponent(m[1]));try{history.replaceState(null,'',location.pathname+location.search)}catch(e){}if(r.ok){try{sessionStorage.setItem('exb_lic_msg','✓ Abonnement activé jusqu’au '+fmt(r.payload.exp)+'.')}catch(e){}if(r.reload){location.reload();return}setTimeout(function(){alert('✓ Abonnement activé jusqu’au '+fmt(r.payload.exp)+'.')},600)}}}catch(e){}
  try{var mm=sessionStorage.getItem('exb_lic_msg');if(mm){sessionStorage.removeItem('exb_lic_msg');setTimeout(function(){alert(mm)},900)}}catch(e){}check();setInterval(check,60000);document.addEventListener('visibilitychange',function(){if(!document.hidden)check()});w.addEventListener('online',check)})();
})(window);
