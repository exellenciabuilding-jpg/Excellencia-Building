/* Excellencia Building — PLEIN ÉCRAN DE TRAVAIL pour TOUS les modules (Formation, Architecture, Clients, Finance, Rapports…).
 * - Bouton « ⛶ » dans la barre du haut : agrandit le module (cache l'en-tête, le menu de gauche, le fil d'Ariane, la barre d'état et la barre des modules)
 *   et demande aussi le plein écran de la fenêtre. Un bouton « ✕ Quitter le plein écran » reste en haut à droite ; la touche Échap (ou F) quitte aussi.
 * - Calcul de structure et Éditeur de plans gardent leur propre bouton « Agrandir » (même principe, à l'intérieur du module).
 * - Aucune donnée ni fonction existante n'est modifiée. Pour retirer : supprimer la balise <script src="exb-focus.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_FOCUS) return;
  var $ = function (i) { return d.getElementById(i); }, on = false, btn = null, out = null;
  function inFS() { return !!(d.fullscreenElement || d.webkitFullscreenElement); }
  function css() {
    if ($('exbFocusCss')) return;
    var s = d.createElement('style'); s.id = 'exbFocusCss';
    s.textContent =
      '#exbFocusBtn{display:grid;place-items:center;width:38px;height:38px;padding:0;border-radius:9px;border:1px solid #ffffff33;background:#ffffff14;color:#fff;font:700 19px/1 Arial,sans-serif;cursor:pointer}#exbFocusBtn:hover{background:#ffffff2e}' +
      '#exbFocusOut{display:none;position:fixed;top:8px;right:12px;z-index:99998;height:38px;padding:0 14px;border-radius:999px;border:0;background:#14284b;color:#fff;font:700 13px Arial,sans-serif;box-shadow:0 3px 12px #0005;opacity:.93;cursor:pointer}#exbFocusOut:hover{opacity:1}' +
      'html.exb-focus #exbFocusOut{display:block}' +
      'html.exb-focus #app>header,html.exb-focus #exbSide,html.exb-focus #exbCrumb,html.exb-focus #exbStatus,html.exb-focus #exbModBar,html.exb-focus #exbDock,html.exb-focus #exbBurger{display:none!important}' +
      'html.exb-focus #app{display:block!important;padding:0!important}html.exb-focus #app>*{grid-column:auto}' +
      'html.exb-focus body{padding:0!important}html.exb-focus #app>.wrap,html.exb-focus #app>section,html.exb-focus #app>main{max-width:none!important;width:100%;padding-top:48px}' +
      'html.exb-focus #calcStructure iframe,html.exb-focus #planEditeur iframe{height:calc(100vh - 110px)!important}' +
      '@media print{#exbFocusBtn,#exbFocusOut{display:none!important}}';
    d.head.appendChild(s);
  }
  function set(v) {
    on = !!v; css();
    d.documentElement.classList.toggle('exb-focus', on);
    if (on) {
      try { var r = d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen; if (r && !inFS()) Promise.resolve(r.call(d.documentElement)).catch(function () {}); } catch (e) {}
      try { w.scrollTo(0, 0); } catch (e) {}
    } else if (inFS()) { try { (d.exitFullscreen || d.webkitExitFullscreen).call(d); } catch (e) {} }
    try { w.dispatchEvent(new Event('resize')); } catch (e) {}
  }
  function mount() {
    css();
    if (!out) {
      out = d.createElement('button'); out.id = 'exbFocusOut'; out.type = 'button'; out.className = 'no-print';
      out.textContent = '✕ Quitter le plein écran'; out.title = 'Revenir à l’affichage normal (Échap)'; out.onclick = function () { set(false); };
      d.body.appendChild(out);
    }
    var top = $('xbTop');
    if (top && !$('exbFocusBtn')) {
      btn = d.createElement('button'); btn.id = 'exbFocusBtn'; btn.type = 'button'; btn.className = 'xb no-print';
      btn.textContent = '⛶'; btn.title = 'Agrandir l’écran de travail (plein écran) — Échap pour quitter'; btn.setAttribute('aria-label', 'Plein écran');
      btn.onclick = function () { set(!on); };
      top.insertBefore(btn, top.firstChild);
    }
  }
  d.addEventListener('fullscreenchange', function () { if (!inFS() && on) set(false); });
  d.addEventListener('keydown', function (e) {
    var t = e.target && e.target.tagName;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === 'Escape' && on) { set(false); return; }
    if (t === 'INPUT' || t === 'SELECT' || t === 'TEXTAREA' || (e.target && e.target.isContentEditable)) return;
    if (on && (e.key === 'f' || e.key === 'F')) set(false);
  });
  w.EXB_FOCUS = { on: function () { set(true); }, off: function () { set(false); }, toggle: function () { set(!on); }, active: function () { return on; }, version: 'V99zzzzzzzzzzzzzzzzzzzzzz' };
  function start() { mount(); setInterval(mount, 1500); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
