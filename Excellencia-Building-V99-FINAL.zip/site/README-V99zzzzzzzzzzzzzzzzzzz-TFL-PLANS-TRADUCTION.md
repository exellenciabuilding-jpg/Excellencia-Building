# TFL — Traduction anglais → français des plans (convertisseur)

## Ce qui change
Le convertisseur (`tfl-plans-convertir.html`, bouton 🗜 dans l'administration des plans) traduit maintenant en français les textes écrits en anglais **au moment de la conversion**. Le PDF ressorti (et le brouillon ajouté au catalogue) est donc directement lisible par les apprenants.

Fichiers : `exb-plans-traduction.js` (nouveau), `tfl-plans-convertir.html` (modifié), `sw.js` (cache `exb-v99zzzzzzzzzzzzzzzzzzz-tfl-plans-traduction-1`, fichier ajouté). Pas de SQL.

## Utilisation
1. Ouvrir le convertisseur, choisir le PDF ou le DXF.
2. Laisser coché **🌍 Traduire en français les textes écrits en anglais** (coché par défaut).
3. **Convertir**. Un rapport indique combien de textes ont été lus et traduits.
4. **Revoir les traductions** : chaque texte avec sa traduction ; corrigez une case, puis **💾 Enregistrer et reconvertir**. Vos corrections sont mémorisées sur l'appareil pour tous les plans suivants.
5. **⬇ PDF**, ou **➕ Ajouter au catalogue** (la version traduite est alors prise même si elle est plus lourde que l'original ; le nom du fichier se termine par `-fr`).

## Comment ça traduit
- **Glossaire intégré (hors connexion)** : environ 2 000 mots et expressions de plans (pièces, ouvertures, structure, béton armé, toiture, finitions, électricité, plomberie, cartouche : « MASTER BEDROOM » → « CHAMBRE PARENTS », « FIRST FLOOR PLAN » → « PLAN DU 1ER ÉTAGE », « SQ FT » → « pi² »…). Les expressions les plus longues passent d'abord ; la casse d'origine (MAJUSCULES, etc.) est respectée.
- **Mon glossaire** : ajoutez vos propres mots (`anglais=français`, une ligne chacun). Pour étendre durablement la base, ajoutez des lignes `'anglais|français'` dans `exb-plans-traduction.js`.
- **Complément en ligne (facultatif, décoché)** : seules les phrases que le glossaire ne couvre pas entièrement sont envoyées au service gratuit MyMemory (limite quotidienne du service). Ne pas cocher pour un plan confidentiel. Résultats mémorisés pour éviter de renvoyer le même texte.
- Cotes, repères (D-01, A-A, 10'-6"), adresses web, e-mails, « © » et mentions de droits d'auteur ne sont **jamais** modifiés (le cartouche d'origine reste intact, comme exigé pour les plans sous licence).

## Ce que ça gère
- **PDF avec texte sélectionnable** (export de logiciel de DAO) : le texte anglais est effacé puis remplacé par le français à la même place (fond détecté, texte incliné géré, texte ajusté à la largeur d'origine, gras conservé). Le PDF ressort en image comme avant (résolution et qualité au choix).
- **DXF** : les textes TEXT/MTEXT sont traduits dans le JSON compact, puis dans le PDF vectoriel. Un texte français plus long est légèrement réduit.
- **JSON déjà converti** (DXF) : peut être retraduit au rechargement.

## Limites
- **Plan scanné ou photo** : le texte est lu par OCR (voir plus bas). La lecture n'est jamais parfaite sur une image floue : le rapport signale « par lecture automatique : relisez-les » et « Revoir les traductions » permet de corriger. Un texte vertical ou très petit n'est pas lu.
- Les mots non présents dans le glossaire restent en anglais ; ils sont listés dans « Revoir les traductions » quand ils ressemblent à de l'anglais.
- Les textes sur plusieurs lignes (« MASTER » puis « BEDROOM » sur deux lignes) sont traduits ligne par ligne ; ajoutez le mot à « Mon glossaire » si besoin.
- Traduction par glossaire : pas de grammaire (articles, accords). Relisez les notes longues avant publication aux apprenants.
- **Non testé sur un téléphone** ; testé dans Chromium sur un PDF d'exemple (pièces, texte incliné, pièces colorées), un DXF, un PDF scanné, le glossaire personnel, les corrections et l'ajout au catalogue.
- Le DWG n'est toujours pas lisible dans le navigateur (enregistrer en DXF).
- Ouvrez l'application une fois avec Internet après la mise à jour pour que le nouveau fichier soit mémorisé hors connexion.


## V99zzzzzzzzzzzzzzzzzzzz — Plans flous, scannés ou photographiés (lisibilité + OCR)
Fichiers : `exb-plans-nettete.js` (nouveau), `tfl-plans-convertir.html`, `sw.js` (cache …-traduction-2).

### Rendre le plan plus lisible
Liste **✨ Rendre le plan plus lisible** : *Automatique* (seulement si le plan est une image, un PDF vectoriel n'est pas touché), *Toujours*, *Toujours renforcé* (plan très flou), *Jamais*. Le moteur aplanit les ombres et l'éclairage inégal, blanchit le papier gris ou jauni, adoucit le grain, puis affine les traits et les chiffres. Les couleurs des pièces sont conservées. Il fonctionne **sans Internet**, sur l'appareil.
Essai : un plan volontairement flou, gris, ombré et bruité devient net sur fond blanc ; la lecture automatique y trouve 10 mots sur 12 attendus, contre 1 sur 12 sans l'amélioration.

### Photos et scans
Le convertisseur accepte aussi les fichiers **JPG / PNG / WebP** (photo d'un plan sur papier, capture d'écran). Une petite image est agrandie (jusqu'à 2400 px) avant l'amélioration.

### OCR (lecture du texte des images)
Case **Lire aussi le texte des plans scannés ou en image (OCR)**, cochée par défaut, utilisée quand le plan n'a pas de texte sélectionnable. Moteur : tesseract.js 5.1.1 (anglais).
- **Par défaut** il est chargé depuis Internet au premier usage (≈ 15 Mo), puis le navigateur le garde.
- **Hors connexion** : créez un dossier `tesseract/` à côté de `tfl-plans-convertir.html` avec `tesseract.min.js` et `worker.min.js` (paquet npm `tesseract.js@5.1.1`, dossier `dist/`), les fichiers `tesseract-core*.wasm.js` (paquet `tesseract.js-core@5.1.1`) et `lang/eng.traineddata.gz`. Le convertisseur les détecte seul.
- Si le moteur est introuvable, la conversion continue : le plan est quand même amélioré, sans traduction, et un message l'explique.
- Les textes lus par OCR sont remplacés par leur traduction sur un fond de même couleur. Vérifiez toujours : une image floue donne des erreurs de lecture (« GROUND FLOOR PLAN » peut devenir « GRIUND FLOOR FLAN »).

### Limites de cette version
- **Le moteur tesseract.js lui-même n'a pas pu être testé ici** (téléchargement bloqué dans l'environnement de développement). Je l'ai testé avec le moteur Tesseract de bureau (même famille) branché à la place : la chaîne améliorer → lire → traduire → redessiner fonctionne, mais le chargement réel de tesseract.js dans le navigateur reste à vérifier sur votre appareil.
- Plan en couleurs foncées ou très chargé : essayez « Toujours » plutôt que « renforcé ».
- Un plan trop flou (texte illisible à l'œil) ne peut pas être récupéré.
