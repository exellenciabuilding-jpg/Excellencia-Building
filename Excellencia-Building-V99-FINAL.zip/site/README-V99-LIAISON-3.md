# V99 — Liaison, tranche 3 (pédagogie, stock, caisse, métrés, résultat par chantier)

Fichier : `exb-liaison-3.js` (chargé après `exb-liaison.js` et `exb-liaison-edu.js`, mis en cache hors ligne). Aucun SQL à exécuter.
Principe inchangé : on **ajoute** des identifiants ; rien n'est renommé ni supprimé ; aucun lien n'est deviné quand plusieurs candidats existent
(il est alors signalé dans « points à vérifier ») ; aucun paiement ni mouvement de stock n'est créé automatiquement.

## Ce qui est maintenant relié
| Donnée | Reliée à | Comment |
|---|---|---|
| Séance du planning | Formation (`formation_id`) | nom de formation unique dans le catalogue |
| Présence | Formation, séance (`schedule_id`) | via le participant ; séance seulement si une seule séance de cette formation ce jour-là |
| Cotation | Formation, formateur (`trainer_id`) | formateur seulement si un seul formateur enseigne ce module |
| Évaluation | Formation, cotation (`cotation_id`) | cotation du même participant et du même module |
| Demande TP/TD | Formation | via le participant, sinon nom de formation unique |
| Mouvement de stock | Bon de commande, chantier, client | référence = n° de commande, ou nom exact d'un chantier unique ; sinon chantier choisi dans le formulaire |
| Dépense de caisse | Bon de commande, chantier, client | idem ; les entrées de caisse restent gérées par la tranche 1 |
| Métré | Client, chantier | nom du client / du projet du devis (unique) |

## Nouveaux écrans
- Sélecteur « 🏗 Chantier (facultatif) » sous le champ Référence des formulaires **Stock** (mouvement) et **Caisse**.
- Panneau Direction : **Pédagogie par formation** (séances, taux de présence, évaluations, cotations) et **Résultat par chantier**
  (budget, versé, dépenses par devise, main-d'œuvre pointée non payée, versé − dépenses, frais généraux hors chantier).

## Contrôles ajoutés (« points à vérifier »)
Présences/notes de participants introuvables ou refusés ; séance sans formation, module absent du programme, formateur introuvable ;
formateur ou salle réservés deux fois sur des horaires qui se chevauchent ; demande TP/TD d'un inconnu ; stock négatif ;
mouvement sur un matériau inexistant ; pointage d'une personne absente du personnel ou marqué payé sans écriture de caisse ;
bon de commande sans chantier ; plan dont le chantier n'existe plus ; dépenses supérieures au budget (USD).

## Correctif d'intégrité
Modifier une **dépense de caisse**, un **matériau** ou un **projet** depuis son écran remplaçait toute la fiche et faisait perdre
chantier, commande, catégorie, client… Ces champs sont maintenant conservés (sauf le client d'un projet dont on retire volontairement le client).

## Pas encore couvert
Liens entre sites (Supabase) testés seulement en local. La suite (V93, BIM, notes de calcul, clients en double) est dans `README-V99-LIAISON-4.md`.

## Tests
`node tools/test-liaison-3.js` (58 contrôles), `python3 tools/e2e-liaison-3.py` (navigateur réel), `node tools/check.js` (473 contrôles).
