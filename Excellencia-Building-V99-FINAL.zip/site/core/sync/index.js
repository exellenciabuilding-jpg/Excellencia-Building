/* V91 Core Sync adapter. */
(function(w){'use strict';w.EXB_CORE_SYNC={run:function(force){return w.EXB_CORE&&w.EXB_CORE.sync?w.EXB_CORE.sync(force):null}};})(window);
