/* V91 Core Permissions adapter — point d'entrée unique vers EXBDB/EXBROLES. */
(function(w){'use strict';w.EXB_CORE_PERMISSIONS={can:function(collection,mode){return !w.EXB_CORE||w.EXB_CORE.can(collection,mode||'lire')}};})(window);
