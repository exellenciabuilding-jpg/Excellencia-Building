/* EXCELLENCIA BUILDING — Core Enterprise V91
 * Socle runtime commun : Auth, Permissions, Organisation, Notifications, Audit, Sync.
 * Compatible avec le noyau V81/V90 et le pont EXBS existant.
 */
(function(w,d){'use strict';
  var VERSION='V91-Core-Enterprise';
  var key={audit:'exb_core_audit',notifications:'exb_core_notifications',settings:'exb_core_settings'};
  function arr(k){try{var v=JSON.parse((w.exbStorage||localStorage).getItem(k)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}}
  function save(k,v){try{(w.exbStorage||localStorage).setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function uid(p){return (p||'EXB')+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8)}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function currentUser(){try{return {id:(w.EXB_ACCT&&w.EXB_ACCT.id)||localStorage.getItem('exb_user')||'',nom:(w.EXBDB&&w.EXBDB.info&&w.EXBDB.info.nom)||'',role:(w.EXBDB&&w.EXBDB.info&&w.EXBDB.info.role)||'',fonction:(w.EXBDB&&w.EXBDB.info&&w.EXBDB.info.fonction)||''}}catch(e){return {id:'',nom:'',role:'',fonction:''}}}
  function can(collection,mode){try{if(w.EXBDB&&typeof w.EXBDB.can==='function')return !!w.EXBDB.can(collection,mode||'lire');}catch(e){} return true}
  function audit(action,detail,collection,recId){
    var u=currentUser(), row={id:uid('AUD'),when:new Date().toISOString(),user_id:u.id,user_name:u.nom,action:String(action||''),detail:String(detail||''),collection:collection||'',record_id:recId||''};
    var a=arr(key.audit);a.unshift(row);save(key.audit,a.slice(0,2000));
    try{if(w.EXBDB&&typeof w.EXBDB.mark==='function')w.EXBDB.mark('__core_audit')}catch(e){}
    try{if(w.exbSb&&w.exbSb.isIn&&w.exbSb.isIn()&&typeof w.exbSb.api==='function')w.exbSb.api('/rest/v1/rpc/journaliser',{method:'POST',body:JSON.stringify({p_action:action,p_detail:detail||''})}).catch(function(){})}catch(e){}
    return row;
  }
  function notify(title,type,meta){
    var n={id:uid('NOT'),when:new Date().toISOString(),title:String(title||''),type:type||'info',read:false,meta:meta||{}};
    var a=arr(key.notifications);a.unshift(n);save(key.notifications,a.slice(0,500));renderBell();
    try{if(typeof w.notify==='function')w.notify(n.title,n.type,5000)}catch(e){}
    return n;
  }
  function markRead(id){var a=arr(key.notifications);a.forEach(function(n){if(n.id===id)n.read=true});save(key.notifications,a);renderBell()}
  function clearRead(){save(key.notifications,arr(key.notifications).filter(function(n){return !n.read}));renderBell()}
  function settings(){var s=arr(key.settings);return s[0]||{}}
  function setSettings(v){save(key.settings,[Object.assign({},settings(),v)]);audit('organisation_settings','Mise à jour des paramètres organisationnels','organisation','settings')}
  async function organisation(){
    try{if(w.EXBDB&&typeof w.EXBDB.now==='function')w.EXBDB.now();}catch(e){}
    try{if(w.exbSb&&w.exbSb.isIn&&w.exbSb.isIn()&&typeof w.exbSb.api==='function'){var r=await w.exbSb.api('/rest/v1/rpc/mon_organisation',{method:'POST',body:'{}'});if(r&&r[0]){save('EXB_CORE_ORG',[r[0]]);return r[0]}}}catch(e){}
    try{return JSON.parse(localStorage.getItem('EXB_CORE_ORG')||'null')}catch(e){return null}
  }
  function sync(force){
    audit('sync_request',force?'Synchronisation forcée':'Synchronisation demandée','sync','');
    try{if(w.EXBDB&&typeof w.EXBDB.now==='function')return w.EXBDB.now(force); }catch(e){}
    try{var SY=w.exbSync||w.EXBSYNC;if(SY&&typeof SY.run==='function')return SY.run(force);}catch(e){}
    notify('Synchronisation indisponible hors connexion','warn');
  }
  function renderBell(){
    var host=d.getElementById('exbCoreNotifications');if(!host)return;
    var ns=arr(key.notifications),unread=ns.filter(function(n){return !n.read}).length;
    host.innerHTML='<button type="button" class="exb-core-bell" title="Notifications">🔔 <b>'+unread+'</b></button>';
    host.querySelector('button').onclick=function(){
      var box=d.getElementById('exbCoreNotificationPanel');if(box){box.remove();return}
      box=d.createElement('div');box.id='exbCoreNotificationPanel';box.className='exb-core-notif-panel';
      box.innerHTML='<div class="exb-core-notif-head"><strong>Notifications</strong><button type="button" class="muted" id="exbCoreClearRead">Nettoyer lues</button></div>'+
        (ns.length?ns.slice(0,30).map(function(n){return '<button type="button" class="exb-core-notif '+(n.read?'read':'unread')+'" data-n="'+esc(n.id)+'"><span>'+esc(n.title)+'</span><small>'+new Date(n.when).toLocaleString('fr-FR')+'</small></button>'}).join(''):'<p class="exb-muted" style="padding:14px">Aucune notification.</p>');
      d.body.appendChild(box);box.querySelector('#exbCoreClearRead').onclick=clearRead;box.querySelectorAll('[data-n]').forEach(function(b){b.onclick=function(){markRead(b.dataset.n)}});
    };
  }
  function mount(){
    if(!d.getElementById('exbCoreNotifications')){var h=d.createElement('div');h.id='exbCoreNotifications';h.style.cssText='position:fixed;right:14px;top:14px;z-index:8000';d.body.appendChild(h)}
    if(!d.getElementById('exbCoreStyles')){var s=d.createElement('style');s.id='exbCoreStyles';s.textContent='.exb-core-bell{border:1px solid #d7dee9;background:#fff;border-radius:999px;padding:8px 12px;box-shadow:0 3px 14px rgba(0,0,0,.12);cursor:pointer}.exb-core-bell b{font-size:11px}.exb-core-notif-panel{position:fixed;right:14px;top:58px;width:min(380px,calc(100vw - 28px));max-height:70vh;overflow:auto;background:#fff;border:1px solid #d8e0eb;border-radius:14px;box-shadow:0 18px 45px rgba(15,23,42,.2);padding:8px}.exb-core-notif-head{display:flex;justify-content:space-between;align-items:center;padding:8px;border-bottom:1px solid #edf0f5}.exb-core-notif{display:block;width:100%;text-align:left;border:0;background:#fff;padding:10px;border-radius:9px;margin-top:4px;cursor:pointer}.exb-core-notif:hover{background:#f4f7fb}.exb-core-notif.unread{font-weight:700}.exb-core-notif.read{opacity:.7}.exb-core-notif small{display:block;font-weight:400;color:#64748b;margin-top:3px}';d.head.appendChild(s)}
    renderBell();
  }
  w.EXB_CORE={version:VERSION,services:{auth:'runtime-account',permissions:'EXBDB',organisation:'organisation()',notifications:'local+server-ready',audit:'audit()',sync:'EXBDB.now'},user:currentUser,can:can,audit:audit,notify:notify,notifications:function(){return arr(key.notifications)},markNotificationRead:markRead,clearReadNotifications:clearRead,organisation:organisation,settings:settings,setSettings:setSettings,sync:sync,mount:mount};
  w.exbCoreAudit=audit;w.exbCoreNotify=notify;
  w.addEventListener('online',function(){notify('Connexion réseau rétablie','success')});
  if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',mount);else mount();
})(window,document);
