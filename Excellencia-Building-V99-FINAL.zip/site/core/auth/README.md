# core/auth

Enterprise module namespace. Existing V81 implementation remains the runtime source until the module is fully migrated.
