/* V91 Core Auth adapter — conserve le mécanisme de compte V81. */
(function(w){'use strict';w.EXB_CORE_AUTH={version:'V91',current:function(){return w.EXB_CORE&&w.EXB_CORE.user?w.EXB_CORE.user():{}}};})(window);
