/* V91 Core Notifications adapter. */
(function(w){'use strict';w.EXB_CORE_NOTIFICATIONS={push:function(t,type,meta){return w.EXB_CORE&&w.EXB_CORE.notify?w.EXB_CORE.notify(t,type,meta):null},all:function(){return w.EXB_CORE?w.EXB_CORE.notifications():[]}};})(window);
