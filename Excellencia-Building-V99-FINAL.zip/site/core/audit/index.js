/* V91 Core Audit adapter. */
(function(w){'use strict';w.EXB_CORE_AUDIT={record:function(a,d,c,id){return w.EXB_CORE&&w.EXB_CORE.audit?w.EXB_CORE.audit(a,d,c,id):null}};})(window);
