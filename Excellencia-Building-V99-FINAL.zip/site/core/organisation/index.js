/* V91 Core Organisation adapter. */
(function(w){'use strict';w.EXB_CORE_ORGANISATION={get:function(){return w.EXB_CORE&&w.EXB_CORE.organisation?w.EXB_CORE.organisation():null},settings:function(){return w.EXB_CORE&&w.EXB_CORE.settings?w.EXB_CORE.settings():{}}};})(window);
