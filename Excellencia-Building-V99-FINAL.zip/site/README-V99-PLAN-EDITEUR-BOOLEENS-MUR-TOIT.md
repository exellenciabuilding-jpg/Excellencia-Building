# V99 — Éditeur de plan : opération booléenne « mur coupé par le toit »

Fichiers modifiés : `plan-editeur/vue3d.js`, `plan-editeur/coupes.js`, `plan-editeur/index.html`. Clé facultative `tr` sur un mur : un plan existant s'ouvre comme avant.

- Fiche d'un mur › **✂ Couper par le toit** (bouton bascule, « retirer » pour annuler).
- En 3D, la tête du mur suit la sous-face de la toiture du même niveau, aux endroits où le mur passe sous le toit : le mur est **prolongé** jusqu'au toit (pignon sous un toit 2 pans, mur sous un 4 pans) ou **coupé** s'il le dépasse. Hors de l'emprise du toit, la hauteur du mur ne change pas.
- Fonctionne avec les murs droits et courbes, ouvertures comprises (échantillonnage tous les 10 cm).

Suite (limites levées) : la hauteur coupée est reprise dans les **coupes et façades** (sommet du mur suivant le toit, par tronçons de 10 cm) et dans le **métré** (hauteur moyenne du mur pour surfaces et volumes ; déduction des ouvertures sur cette hauteur).

Suite 2 : 
- **Terrasses** (toits plats, contour libre compris) : un mur coupé par le toit s'arrête sous la dalle de la terrasse.
- **Voûte en berceau** : un mur passant sous une voûte est prolongé jusqu'à son intrados (arc) ; au bord de la voûte il s'arrête à la naissance de l'arc. Même fonction pour la 3D, les coupes et façades, le métré.
- **Nomenclature des murs** : hauteur moyenne, surfaces et volumes tenant compte de la coupe.
- Exports OBJ / GLB / DXF 3D : déjà coupés (générés depuis la 3D). Le plan 2D et le DXF 2D ne portent pas de hauteur, donc rien à changer. L'éditeur n'exporte pas d'IFC (l'IFC vient du module de calcul).

Suite 3 — **trou du toit sous la lucarne** (`vue3d.js`) : en 3D, chaque lucarne perce les versants du toit de son niveau (2 pans et 4 pans) sur son emprise (largeur moins les joues, profondeur entière, rotation prise en compte). Les versants sont découpés en cellules d'environ 12 cm dans la zone concernée seulement ; le reste du toit n'est pas touché. Plusieurs lucarnes possibles.

Limites : le trou suit l'emprise de la lucarne en plan (pas de raccord noue / solin autour) ; coupes et façades montrent toujours le toit plein ; terrasses non percées ; un mur ne s'ajuste pas à une lucarne ; la lucarne doit être à l'altitude du toit pour s'y raccorder (réglage « altitude du bas »). Toits 2 pans et 4 pans à rectangle uniquement. Voûte : demi-ellipse, coque 20 cm. Testé sous Node (aucun triangle de toit dans l'emprise, 3D de scène sans erreur) ; pas de test visuel WebGL ni sur appareil.
