# V99zc — Calcul de structure : tout sur un seul écran

Fichiers modifiés : `calcul-structure/index.html`, `exb-calcul-structure.js`, `sw.js` (cache `exb-v99zc-ecran-complet-1`).

- Module Bâtiment : nouvel onglet **« Tout afficher »** (ouvert par défaut) qui affiche d'un coup Général, Axes & modélisation et Calcul, sans changer d'onglet. Les onglets d'origine restent disponibles.
- Lancer le calcul ne ramène plus à l'onglet « Calcul » quand « Tout afficher » est actif.
- Largeur : le calculateur n'est plus limité à 680/760 px, il occupe toute la largeur de l'écran.
- Retour en arrière : restaurer l'ancien `calcul-structure/index.html` et `exb-calcul-structure.js`.
