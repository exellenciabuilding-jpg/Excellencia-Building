# V99u — Modules côte à côte, Retour/Avant, thème clair/sombre

Fichiers : `exb-v99r-shell.js` (modifié), `exb-theme.js` (nouveau), `index.html` (2 lignes), `sw.js` (cache `exb-v99u-ui-1`).
Aucune donnée ni fonction métier modifiée.

- **Modules côte à côte** : les pages de catégorie affichent les modules en grille (2 colonnes sur téléphone). Dans un module, une barre horizontale
  défilable permet de passer à un autre module de la catégorie sans revenir en arrière. Cause corrigée : le conteneur central se rétrécissait (marge auto).
- **Retour / Avant** : deux boutons dans l'en-tête (aussi Alt + ← et Alt + →), historique de 60 écrans.
- **Thème clair / sombre** : bouton soleil/lune dans l'en-tête, choix mémorisé sur l'appareil. L'impression et les PDF restent toujours clairs.

## V99v — Typographie et ajustements (exb-typo.js)
- Police Inter / Segoe UI / police système (Arial en secours, fonctionne hors connexion). Échelle uniforme : texte 15 px, champs et tableaux 14 px, étiquettes 13 px, aides 12,5 px, titres 18 px.
- Réglage « Taille du texte » (Petit / Normal / Grand) dans le menu du profil (clic sur le nom en haut à droite), mémorisé sur l'appareil.
- Boutons uniformes (40 px, coins 9 px) ; champs de même hauteur. Colonnes des formulaires/listes corrigées (plus de débordement à droite).
- Bandeau « Connectez votre compte » compact, fermé = absent 24 h. Boutons flottants (? et robot) décalés, sans superposition.
- Téléphone : la recherche devient une icône qui ouvre le champ pleine largeur.
- Écran uniquement : certificats, reçus, affiches, impression et PDF inchangés. Cache : exb-v99v-typo-1.
