# Excellencia Building V94 — Architecture / BIM / CDE

## Périmètre
- Études techniques
- Plans et révisions
- Workflow WIP → Shared → Review → Approved → Archived
- Visas et décisions
- Gestion documentaire CDE
- Modèles BIM (IFC et autres formats)
- Issues BIM
- Diffusion contrôlée
- Audit Core et permissions

## API locale
`EXB_ARCH.createStudy`, `createDrawing`, `createRevision`, `requestVisa`, `decideVisa`, `registerDocument`, `registerBimModel`, `createBimIssue`, `distribute`, `kpis`.

## Supabase
Exécuter `supabase/migration-v94-architecture-bim-cde.sql` après les migrations précédentes.

## V99 — Source de vérité unique (plans, CDE, observations BIM)
**Constat.** Deux modèles coexistaient : l'ancien (`exb_plans` + `exb_plan_files` pour les plans, `exb_cde` pour les documents, `exb_bim_issues` pour les observations) et V94 (plans, révisions, visas, diffusions, documents, modèles et issues BIM). De plus, les 8 tables SQL dédiées V94 n'ont jamais reçu de données : toute la synchronisation passe par la table générique `enregistrements` (une collection = un nom).

**Décision : le modèle V94 est la seule source de vérité**, sous forme de collections `plans_v94`, `revisions_plans_v94`, `visas_v94`, `diffusions_v94`, `documents_cde_v94`, `bim_models_v94`, `bim_issues_v94`.
- **Bureau d'études › Plans** : l'écran ne change pas ; il lit et écrit V94 (un plan = un plan V94, chaque indice = une révision, chaque envoi = un visa + une diffusion).
- **Priorité 2 › CDE Documents et BIM / Issues** : mêmes écrans, mêmes libellés ; données dans `documents_cde_v94` et `bim_issues_v94` (statuts et priorités convertis dans les deux sens).
- **Plans (fichiers)** : chaque fichier est rattaché à une révision V94 (`drawing_id`, `revision_id` sur la fiche ; `file_id` sur la révision). Le stockage des fichiers et les annotations restent inchangés.
- **Persistance** : V94 passe maintenant par le pont de stockage commun (`EXBS`) : ses données sont enfin sauvegardées et synchronisées avec les autres modules (avant, elles restaient dans le `localStorage` brut de l'appareil).
- **Migration** (`EXB_ARCH.migrateLegacy`, automatique à l'ouverture) : idempotente, identifiants déterministes (`DOC-…`, `ISS-…`, plan = même id), sans doublon si relancée. Les anciennes collections restent en place, **en lecture seule**, comme sauvegarde.
- **Droits** : `supabase/migration-v99-source-unique-plans-bim.sql` reporte les droits des anciennes collections (`plans`, `cde`, `bim_issues`) sur les collections V94 (le plus large des deux est gardé) et marque les 8 tables dédiées V94 comme obsolètes (aucune suppression).

**Mise en service.** 1) Sauvegarde Supabase. 2) Exécuter la migration SQL V99. 3) Déployer. 4) Sur un premier appareil (administrateur) : Base partagée › Synchroniser maintenant, puis laisser migrer ; ensuite seulement ouvrir les autres appareils (après leur synchronisation, ils verront les mêmes identifiants et ne recréeront rien).

**Tests.** `node tools/test-bim/test-source-unique.js` (17 contrôles : migration, idempotence, aller-retour exact des plans, visas/diffusions, CDE, BIM, fichiers, suppression) ; `node tools/check.js` (436 + 4 contrôles).

**Limites.** Non testé sur un vrai Supabase ni sur téléphone. Si deux appareils migrent avant d'avoir synchronisé, les lignes migrées ont le même identifiant : le moteur de synchro les signale en conflit (la version du collègue est gardée, la vôtre va dans « Conflits »), sans perte. Les modules `exb_cde_workflows` (V90) et `exb_drawings_v70` / `drawing_sheets_v71` (coupes et planches de structure) ne font pas partie de cette fusion.
