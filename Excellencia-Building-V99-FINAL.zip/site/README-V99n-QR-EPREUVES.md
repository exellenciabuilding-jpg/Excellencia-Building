# V99n — QR par apprenant pour les épreuves en ligne (TD / TP / examens)

Où ? Panneau des épreuves en ligne (là où vous publiez une épreuve) › bouton **🔳 QR par apprenant**.
- Choisissez l'épreuve : une carte par apprenant destinataire (nom, matricule, formation, QR).
- Le QR ouvre `epreuve.html?m=MATRICULE&e=ID` : l'apprenant arrive directement sur son épreuve (plus besoin de saisir le matricule).
- Il peut travailler en ligne, ou « 🖨 Imprimer / enregistrer en PDF » sa copie, puis la joindre et « 📤 Envoyer ma copie » plus tard (fonctions déjà présentes ; brouillon conservé sur son téléphone).
- Boutons : 🖨 Imprimer / PDF (feuille de QR), 📋 Copier tous les liens, Copier / WhatsApp par apprenant (si téléphone connu), 🔳 QR général (sans matricule : à projeter, l'apprenant saisit son matricule).
- L'adresse est nettoyée après l'ouverture (le matricule ne reste pas visible dans la barre d'adresse).

Rien n'est modifié dans la publication des épreuves ni dans les copies TP/TD existantes. Pages ajoutées : exb-epreuve-qr.js ; epreuve.html lit maintenant ?m= et ?e= (sans eux, comportement inchangé).
Sécurité : le QR contient le matricule (seul identifiant de epreuve.html) : le remettre à l'apprenant concerné uniquement.
