# V99zzzzzzzzzzzzzzzzzzzz — Page de garde sobre et standard (devis, factures, reçus)
Fichiers modifiés : `exb-docs.js`, `sw.js` (cache renouvelé). Recharger l'application après mise à jour.

- **Page de garde = mise en page précédente (bandeau bleu officiel + filet or, logo, DEVIS, titre du projet, blocs Client / Prestataire)**, sans récapitulatif ni conditions générales sur cette page. Les montants et les conditions générales restent dans les pages de détail.
- **Une seule page de garde standard pour tous les documents** : devis, factures et reçus. Contenu : logo et identité de l'entreprise (nom, slogan, coordonnées), type de document, n°, date (et validité pour le devis), dossier, objet/projet, bloc Client et bloc Prestataire en texte simple, « Fait à … le … », signatures.
- **Cachet + signature collés au nom** : l'image du cachet/signature descend sur la ligne de signature et recouvre le nom et la fonction du signataire (texte lisible par-dessus), côté prestataire et côté client.
- **Pages suivantes** : en-tête discret (logo, nom, type + n°), « DÉTAIL … », tableau, totaux, conditions générales.
- **Pied de page sobre sur toutes les pages** : coordonnées, mentions légales, « Page i / N », code et QR de vérification.
- Retour à l'ancienne mise en page sans page de garde possible avec `build(d, { cover: false })`.

## Mise à jour : page de garde au style du certificat
- Contour identique au certificat (filet bleu épais, filet or, bande or pâle, filet fin intérieur), agrandi pour la page de garde. Couleurs officielles : bleu #173565, or #c49a38.
- Ordre : nom de l'entreprise en haut, logo grand en dessous, titre en grand (DEVIS / FACTURE / REÇU + n°), titre du projet, coordonnées du client.
- Plus de signature du client : seulement celle de l'entreprise, cachet et signature posés sur le nom du signataire.
- « Date de délivrance » affichée au-dessus de la signature.
- Certificat (`index.html`) non modifié.

## Mise à jour : page de garde sur tous les PDF générés par EXBPdf (`exb-pdf.js`)
- Même page de garde (contour du certificat agrandi, nom en haut, logo grand, titre, coordonnées du client, date de délivrance, signature de l'entreprise avec cachet sur le nom, sans signature du client) sur : fiches BTP, clients, terrain, planning, études, notes de calcul (études), réception, décomptes, bons de commande, factures de chantier, rapports de pilotage, fiche du personnel, résultats, etc.
- Les coordonnées affichées viennent du nom du client et des lignes « Téléphone / E-mail / Adresse / Contact » du document.
- Désactivation ponctuelle : `EXBPdf.make({ ..., cover: false })`.
- **Non modifiés** : reçus/fiches d'inscription (`exb-form.js`), certificats (`index.html`), notes de calcul de structure (`calcul-structure/exb-calcul-doc.js`).

## Mise à jour : notes de calcul de structure (`calcul-structure/exb-calcul-doc.js`)
- Page de garde des notes de calcul au même style : contour du certificat agrandi, nom en haut, logo grand, titre NOTE DE CALCUL + n° et indice, objet, client / maître d'ouvrage et projet, références de calcul (norme, établi par, statut, validation), sommaire, QR de vérification, date de délivrance, signature de l'entreprise avec cachet posé sur le nom.
- Plus de signature du maître d'ouvrage sur la page de garde ; la validation de l'ingénieur reste dans les références et dans les visas de la dernière feuille.
- Les plans d'exécution (cartouche) et les calculs ne sont pas modifiés.
- **Certificat : aucun changement** (`index.html` identique).

## Mise à jour : marge de sécurité d'impression (`exb-docs.js`, `exb-pdf.js`)
- Cause du décalage constaté à l'impression : bandeaux et contour collés au bord de la feuille, que les imprimantes ne peuvent pas imprimer (zone non imprimable ≈ 4 à 6 mm), d'où des bords coupés ou une page décalée.
- Tout le contenu de chaque page est maintenant réduit à 94 % et centré : marge blanche d'environ 6 mm sur les quatre côtés. Les PDF restent en A4 (595 × 842 pt).
- Le PDF demande l'impression à taille réelle (/PrintScaling /None).
- Réglage d'impression conseillé : papier A4, échelle « 100 % / Taille réelle » (ne pas choisir « Ajuster à la page »), marges « par défaut ».
