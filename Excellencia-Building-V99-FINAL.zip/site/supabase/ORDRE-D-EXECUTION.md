# Ordre d'exécution des scripts SQL (Supabase › SQL Editor › New query › coller › Run)

Tous sont **réexécutables sans danger**. Après chaque script, lancez la requête de contrôle : si le résultat est celui attendu, passez au suivant. **Aucun de ces scripts n'a été exécuté sur un vrai Supabase par moi** : faites un essai (candidature, sujet, contribution fictifs) avant d'ouvrir les liens au public.

| # | Script | Active | Contrôle (résultat attendu) |
|---|---|---|---|
| 1 | `migration-v99zzzz-formulaires.sql` | Formulaires en ligne **formateur, client, personnel, TP/TD** (message « pas encore activés ») | `select to_regclass('public.formulaires');` → `formulaires` |
| 2 | `migration-v99zzr-tfl-en-ligne.sql` | Candidatures TFL par lien | `select proname from pg_proc where proname in ('tfl_candidature_envoyer','tfl_candidatures_liste','tfl_candidature_traiter');` → **3 lignes** |
| 3 | `migration-v99zzt-tfl-portails.sql` | Portails étudiant et encadreur | `select proname from pg_proc where proname like 'tfl_portail_%';` → **8 lignes** |
| 4 | `migration-v99zzv-tfl-sujets.sql` | Catalogue de sujets public | `select proname from pg_proc where proname in ('tfl_sujets_publier','tfl_sujet_retirer','tfl_sujets_etat','tfl_sujets_publics','tfl_sujet_choisir');` → **5 lignes** |
| 5 | `migration-v99zzw-tfl-banque-sujets.sql` (≈ 620 Ko, 3 lots) | Banque de 4 300 sujets | `select count(*) from public.tfl_sujets;` → **4300** · `select proname from pg_proc where proname in ('tfl_sujets_publics_page','tfl_sujets_facettes','tfl_sujets_publier_lot','tfl_norm');` → **4 lignes** |
| 6 | `migration-v99zzx-tfl-fiche-etudiant.sql` | Fiche étudiante complète (photo…) | pas de requête dédiée : le script se termine sans erreur |
| 7 | `migration-v99zzy-securite-tfl-qr.sql` | Jeton anti-usurpation + limite par IP | `select proname from pg_proc where proname in ('exb_ip_limite','exb_doc_confirmer');` → **2 lignes** |
| 8 | `migration-v99zzz-tfl-sans-limite.sql` | Sujets sans plafond de réservations | `select proname from pg_proc where proname = 'tfl_sujet_choisir' and prosrc ilike '%_reservations%';` → **0 ligne** |
| 9 | `migration-v99zzzzzz-tfl-contributions.sql` | Contributions d'anciens (TFL résolus) | `select proname from pg_proc where proname in ('tfl_contribution_envoyer','tfl_contributions_liste','tfl_contribution_fichier','tfl_contribution_traiter');` → **4 lignes** |
| 10 | `migration-v99zzzzzzzzzz-tfl-signature.sql` | Signature de l'étudiant conservée à l'envoi en ligne (sans lui, l'envoi marche mais la signature est ignorée) | pas de requête dédiée : le script se termine sans erreur (à exécuter après le n° 8) |
| 11 | `migration-v99zzzzzzzzzzzzzz-tfl-matricule-suivi.sql` | Matricule automatique à la soumission, suivi du statut par matricule, formulaire encadreur, validation du sujet par l'encadreur (**à exécuter après le n° 10**) | `select proname from pg_proc where proname in ('tfl_statut_consulter','tfl_statut_publier','tfl_encadreur_envoyer','tfl_encadreurs_liste','tfl_encadreur_traiter','tfl_matricule_nouveau');` → **6 lignes** |
| 12 | `migration-v99zzzzzzzzzzzzzz-LOT8-demandes.sql` | Demandes de modification/retrait d'un sujet depuis la page de suivi (après les lots 1 à 7 du n° 11) | `select proname from pg_proc where proname in ('tfl_statut_demande','tfl_demandes_liste','tfl_demande_traiter');` → **3 lignes** |

## À savoir
- **Ordre** : respectez-le (4 avant 5 ; 6 après 4 ; 7 après 6 ; 8 après 7 ; 10 après 8 ; 11 après 10). Le 2 est indépendant ; le 3 reprend les mêmes e-mails administrateur que le 2.
- **E-mails administrateur** : les scripts 2, 3 et 9 contiennent la liste des e-mails autorisés. Vérifiez qu'elle contient bien **votre** adresse de connexion (en minuscules) avant d'exécuter.
- **Le n° 5 est lourd** (≈ 620 Ko) : à coller depuis un **ordinateur**, pas depuis un téléphone. Il est découpé en 3 lots (`-- Lot 1/3`, `2/3`, `3/3`) : si l'éditeur refuse, exécutez les lots un par un.
- **Le n° 7 et les nouvelles pages** : déployez le ZIP sur Netlify et exécutez le SQL **dans la même journée**.
- `migration-v99zzq-tfl.sql` (gros script TFL d'origine) **n'est pas nécessaire**.
- Déjà exécutés par ailleurs ? Les contrôles ci-dessus le disent : si le résultat est déjà le bon, sautez le script.

## Plans architecturaux (V99zzzzzzzzzzzzzzzzzz)
Après `migration-v99zzt-tfl-portails.sql` (obligatoire avant) : exécuter `migration-v99zzzzzzzzzzzzzzzzzz-tfl-plans.sql`. Contrôle : `select proname from pg_proc where proname like 'tfl_plan%' or proname like 'tfl_esquisse%';` → environ 13 lignes. Voir `README-V99zzzzzzzzzzzzzzzzzz-TFL-PLANS.md`.

## Espace client avec compte (V99zzzzzzzzzzzzzzz)
Après `migration-v99zy-portails.sql` : exécuter `migration-v99zzzzzzzzzzzzzzz-espace-client.sql`. Contrôle : `select proname from pg_proc where proname like 'client_%';` → 6 lignes.

Après la migration de l'espace client : `migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql` (plans envoyés au client).

## Source unique plans / CDE / BIM (V99)
Après `migration-v94-architecture-bim-cde.sql` (et les migrations de rôles V66/V68) : exécuter `migration-v99-source-unique-plans-bim.sql` (réexécutable). Il reporte les droits des anciennes collections (`plans`, `cde`, `bim_issues`) sur les collections V94 et marque les tables dédiées V94 comme obsolètes. Contrôle : `select collection, count(*) from droits_fonction where collection in ('plans_v94','revisions_plans_v94','visas_v94','diffusions_v94','documents_cde_v94','bim_issues_v94','bim_models_v94') group by 1;` → 7 lignes. Voir `README-V94-ARCHITECTURE-BIM-CDE.md` (section V99).
