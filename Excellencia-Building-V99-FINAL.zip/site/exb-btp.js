/* Formulaire BTP : photos (max 5, facultatives), dimensions, PDF client, enregistrement du suivi */
window.EXBBtp=(function(){
  var PH=[],MAXP=5,cfg=function(){return window.EXB_SUPABASE||{}};
  function $(i){return document.getElementById(i)}
  function num(v){var n=parseFloat(String(v||'').replace(',','.'));return isFinite(n)&&n>0?n:0}
  function calc(){var L=num($('b_len').value),l=num($('b_wid').value);if(L&&l){$('b_surface').value=(Math.round(L*l*100)/100).toString()}}
  function wire(){
    if(!$('b_len'))return;
    ['b_len','b_wid'].forEach(function(i){$(i).addEventListener('input',calc)});
    $('b_photos').addEventListener('change',async function(){
      var fs=[].slice.call(this.files||[]).slice(0,MAXP),info=$('b_photoInfo');PH=[];info.textContent='Préparation des photos…';
      for(var i=0;i<fs.length;i++){try{PH.push(await EXBPdf.fileJpg(fs[i],1000,.7))}catch(e){}}
      if((this.files||[]).length>MAXP)info.textContent='Maximum '+MAXP+' photos : seules les '+MAXP+' premières sont gardées.';
      else info.innerHTML=PH.length?'<span class="ok">✓ '+PH.length+' photo(s) prête(s).</span>':'Aucune photo (facultatif).';
      var g=$('b_photoPrev');g.innerHTML='';PH.forEach(function(u){var im=new Image();im.src=u;im.style.cssText='width:64px;height:64px;object-fit:cover;border-radius:8px;margin:3px';g.appendChild(im)})})
  }
  function ligneDims(d){return (d.length_m?('Longueur '+d.length_m+' m'):'—')+' × '+(d.width_m?('Largeur '+d.width_m+' m'):'—')+' = '+(d.surface?d.surface+' m²':'—')}
  function origin(){return location.origin+location.pathname.replace(/[^\/]*$/,'')}
  async function pdf(d,mat,sig){
    var blob=await EXBPdf.make({titre:'FICHE DE DEMANDE — BTP · ARCHITECTURE · DIVERS',sousTitre:'Numéro de suivi : '+mat+' · émise le '+new Date().toLocaleDateString('fr-FR'),
      rows:[['Numéro de suivi',mat],['Nom & prénom',d.name],['Téléphone',d.phone],['E-mail',d.email||'—'],['Besoin',d.category],['Services souhaités',(d.services||[]).join(', ')||'—'],['Situation du projet',d.state||'—'],
        ['Lieu du projet',d.location||'—'],['Dimensions de la parcelle',ligneDims(d)],['Situation environnementale',d.environment||'—'],['Description du terrain',d.terrain||'—'],
        ['Budget estimé',d.budget||'—'],['Délai souhaité',d.delay||'—'],['Votre demande',d.note||'—']],
      notes:['Suivez nos réponses (devis, plans) sur '+origin()+'resultats.html : entrez votre numéro de suivi '+mat+' et votre numéro de téléphone.','Conservez cette fiche.'],
      sign:true,clientSig:sig||'',clientName:d.name||'',images:PH,footer:'Excellencia Building · '+origin()+'resultats.html'});
    EXBPdf.save(blob,'Fiche-Demande-'+mat+'.pdf')}
  async function afterSend(d,mat){
    var c=cfg(),h={apikey:c.key,'Content-Type':'application/json'};if(/^eyJ/.test(c.key))h.Authorization='Bearer '+c.key;
    try{var r=await fetch(c.url.replace(/\/+$/,'')+'/rest/v1/rpc/btp_suivi_enregistrer',{method:'POST',headers:h,body:JSON.stringify({p_matricule:mat,p_phone:d.phone,p_name:d.name,p_data:d,p_photos:PH})});return r.ok}catch(e){return false}}
  return {wire:wire,pdf:pdf,afterSend:afterSend}
})();
