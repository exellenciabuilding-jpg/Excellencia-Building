(function(w){'use strict';w.EXB_FORMATION={version:'V97-Enterprise',modules:['apprenants','formations','certifications']};})(window);
