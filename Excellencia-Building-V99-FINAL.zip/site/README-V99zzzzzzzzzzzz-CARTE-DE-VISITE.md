# V99zzzzzzzzzzzz — Cartes de visite personnalisables (sur la version « TFL Suivi »)

Modèle « crème et or » (recto : logo, nom, contacts, QR ; verso : services + photo). **Format 90 × 42 mm** (proportions de la maquette validée).

## Utilisation
Logiciel › **Affiches** › bouton **🪪 Cartes de visite** (ou adresse `/carte-visite`). Les textes d'origine ont été **effacés de l'image** : ce que vous tapez apparaît à l'endroit exact où ils se trouvaient.
- **Recto** : nom, fonction, téléphone, e-mail, adresse, site (une ligne vide disparaît, icône comprise), slogan, 3 spécialités, texte sous le QR.
- **Verso** : titre, 4 services (titre + détail), phrase manuscrite, bandeau sur la photo.
- **Images** : logo (recto) et photo (verso) remplaçables ; boutons « d'origine ».
- Un texte trop long est **réduit automatiquement** pour rester dans sa zone.
- Les textes (et images) sont gardés sur l'appareil ; « Remettre tous les textes d'origine » les efface.
- **Export** : PDF recto + verso (90 × 42 mm), ou PNG haute définition de chaque face.

## QR de vérification
Même mécanisme que les devis, reçus et certificats (`verification.html?c=…`, numéro `CARTE-AAAAMMJJ-XXXXX` + code). La page publique affiche le nom, la fonction et le numéro, jamais le téléphone ni l'e-mail. Le numéro change quand le nom, la fonction ou le téléphone changent.
**Enregistrer au registre** : le bouton fonctionne quand la page est ouverte depuis le logiciel, connecté en administrateur. Sans cet enregistrement, le QR affiche « document introuvable ». À faire avant l'impression de chaque carte.

## Déploiement
Aucun SQL. Déployer le ZIP (cache `exb-v99zzz-tfl-sans-limite-signatures-suivi-8-carte`), ouvrir le logiciel deux fois. Rien d'existant n'est retiré (TFL suivi, signatures, habillage public et liens séparés inchangés).

## Limites
- Le fond du recto/verso est une image : le papier et les bandes dorées ne changent pas (seuls textes, logo et photo se personnalisent).
- Photo : recadrée pour remplir la fenêtre (le haut de l'image est conservé).
- Le site affiché par défaut est `excellenciabuildingsarlu.netlify.app` (la maquette montrait `www.excellenciabuilding.com`) : à modifier si vous avez un autre domaine.
- Police manuscrite : celle de l'appareil (rendu légèrement différent d'un téléphone à l'autre) ; le PDF/PNG exporté fige le rendu de l'appareil qui l'exporte.
- QR : environ 9 mm de côté ; imprimer sur papier mat et tester le scan avant un gros tirage.
