/* EXCELLENCIA INTELLIGENCE — lot 4 : formation, personnel (RH) et paie.
 * Extension (à charger APRÈS exb-intelligence.js). LECTURE SEULE : aucune donnée n'est modifiée par ce fichier.
 * Complète — sans la dupliquer — la liaison formation existante (EXBLIEN.edu : paiements ↔ participants ↔ reçus ↔ certificats, TFL, séances, formateurs).
 *  • Formations : dates incohérentes, formateur absent/introuvable, effectif > capacité, formation terminée encore active, doublons.
 *  • Reçus et certificats : numéros en double, montants nuls.
 *  • Personnel : doublons, salaire/contact manquants. Contrats : expirés, bientôt échus, dates inversées. Paie : retenues > brut, brut nul, doublon employé/période, paie du mois manquante, écart avec le salaire de la fiche.
 *  • Documents : relances de solde des participants, rapport formation, récapitulatif de paie (HTML, hors ligne).
 *  • Les fiches RH/paie ne sont contrôlées que si l'utilisateur a le droit de lecture « rh ». Pour retirer : supprimer la balise <script src="exb-intelligence-4.js">. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot4) return; I.lot4 = true;
    var H = I.helpers, list = H.list, lab = H.lab, num = H.num, norm = H.norm, digits = H.digits, esc = H.esc, toast = H.toast, X = function () { return w.EXBLIEN; };
    function money(x) { return (Math.round(x * 100) / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
    function canR(c) { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can(c, 'lire') !== false; } catch (e) { return true; } }
    function F(sev, mod, msg, col, id, extra) { var o = { sev: sev, mod: mod, msg: msg, ref: { col: col, id: id } }; if (extra) for (var k in extra) o[k] = extra[k]; return o; }
    function dupBy(arr, keyFn, col, mod, what, sev, idf) {
      var seen = {}, out = []; arr.forEach(function (o) { var k = keyFn(o); if (!k) return; if (seen[k]) out.push(F(sev || 'alerte', mod, 'Doublon possible (' + what + ') : « ' + lab(seen[k]) + ' » et « ' + lab(o) + ' »', col, o[idf || 'id'])); else seen[k] = o; });
      return out;
    }
    var t0 = function () { return H.today(); }, in30 = function () { return new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10); };
    function act(p) { return p.approval_status !== 'REJETE'; }
    function belongs(p, f) { return (p.formation_id && p.formation_id === f.formation_id) || (!p.formation_id && p.training && norm(p.training) === norm(f.name)); }

    /* ---- moteurs spécialisés ---- */
    I.calc.net = function (p) { return num(p.gross) + num(p.bonus) - num(p.deductions); };
    I.calc.soldeParticipant = function (pid) { try { return X() && X().edu && X().edu.situation ? X().edu.situation(pid) : null; } catch (e) { return null; } };
    I.registerEngine('calcul.paie', 'Contrôle du personnel, des contrats et de la paie (net = brut + primes − retenues)', function () { return []; });
    I.registerEngine('calcul.formation', 'Contrôle des formations, reçus et certificats (complète la liaison formation)', function () { return []; });

    /* ---- formations ---- */
    I.addRule({ id: 'edu.formations', check: function () {
      var out = [], F0 = list('exb_formations'), P = list('exb_participants').filter(act), T = list('exb_trainers'), t = t0();
      F0.forEach(function (f) {
        var id = f.formation_id || f.id, add = function (s, m) { out.push(F(s, 'Formation', 'Formation « ' + lab(f) + ' » : ' + m, 'exb_formations', id)); }, n = P.filter(function (p) { return belongs(p, f); }).length, active = /active|cours|ouvert/i.test(f.status || 'ACTIVE');
        if (f.start && f.end && f.end < f.start) add('erreur', 'date de fin (' + f.end + ') avant la date de début (' + f.start + ')');
        if (num(f.capacity) > 0 && n > num(f.capacity)) add('alerte', n + ' participants pour une capacité de ' + num(f.capacity));
        if (active && f.end && f.end < t) add('alerte', 'terminée le ' + f.end + ' mais encore active');
        if (active && !f.trainer_id && (!f.end || f.end >= t) && f.start && f.start <= in30()) add('alerte', 'aucun formateur affecté alors qu’elle démarre bientôt ou est en cours');
        if (f.trainer_id && !T.some(function (x) { return (x.trainer_id || x.id) === f.trainer_id; })) add('erreur', 'formateur affecté introuvable');
      });
      return out.concat(dupBy(F0, function (f) { return f.name ? norm(f.name) : ''; }, 'exb_formations', 'Formation', 'même nom', 'alerte', 'formation_id')); } });

    /* ---- reçus et certificats ---- */
    I.addRule({ id: 'edu.documents', check: function () {
      var out = [], R = list('exb_receipts'), C = list('exb_certificates'), t = t0();
      R.forEach(function (r) { var tot = num(r.registration_fee) + num(r.training_fee); if ((r.registration_fee != null || r.training_fee != null) && tot <= 0) out.push(F('alerte', 'Reçus', 'Reçu ' + (r.receipt_no || r.id) + ' : montant nul', 'exb_receipts', r.id)); if (r.date && String(r.date).slice(0, 10) > t) out.push(F('alerte', 'Reçus', 'Reçu ' + (r.receipt_no || r.id) + ' : date dans le futur', 'exb_receipts', r.id)); });
      out = out.concat(dupBy(R, function (r) { return r.receipt_no ? norm(r.receipt_no) : ''; }, 'exb_receipts', 'Reçus', 'même numéro de reçu', 'erreur'));
      out = out.concat(dupBy(C, function (c) { return c.cert_no ? norm(c.cert_no) : ''; }, 'exb_certificates', 'Certificats', 'même numéro de certificat', 'erreur'));
      return out; } });

    /* ---- personnel, contrats, paie ---- */
    I.addRule({ id: 'rh.personnel', check: function () {
      if (!canR('rh')) return [];
      var out = [], HR = list('exb_hr');
      HR.forEach(function (e) { var on = /actif|active/i.test(e.status || 'Actif'); if (on && 'salary' in e && num(e.salary) <= 0) out.push(F('info', 'Personnel', '« ' + lab(e) + ' » : salaire non renseigné', 'exb_hr', e.id)); if (on && !digits(e.phone) && !e.email) out.push(F('info', 'Personnel', '« ' + lab(e) + ' » : aucun moyen de contact', 'exb_hr', e.id)); });
      return out.concat(dupBy(HR, function (e) { var p = digits(e.phone); return p.length >= 8 ? 'T' + p.slice(-9) : e.name ? 'N' + norm(e.name) : ''; }, 'exb_hr', 'Personnel', 'même nom ou même téléphone')); } });
    I.addRule({ id: 'rh.contrats', check: function () {
      if (!canR('rh')) return [];
      var out = [], HR = list('exb_hr'), C = list('hrContracts'), t = t0(), lim = in30(), byName = {}; HR.forEach(function (e) { byName[norm(lab(e))] = e; });
      C.forEach(function (c) {
        var e = byName[norm(c.employee)], on = !e || /actif|active/i.test(e.status || 'Actif'), nm = '« ' + (c.employee || '?') + ' »', id = c.id;
        if (c.start && c.end && c.end < c.start) out.push(F('erreur', 'Contrats', 'Contrat de ' + nm + ' : fin avant le début', 'hrContracts', id));
        else if (c.end && c.end < t && on) out.push(F('alerte', 'Contrats', 'Contrat de ' + nm + ' expiré le ' + c.end + ' (personnel encore actif)', 'hrContracts', id));
        else if (c.end && c.end <= lim && c.end >= t) out.push(F('info', 'Contrats', 'Contrat de ' + nm + ' : fin le ' + c.end + ' (dans 30 jours ou moins)', 'hrContracts', id));
        if (c.employee && HR.length && !e) out.push(F('info', 'Contrats', 'Contrat de ' + nm + ' : personne absente de la liste du personnel', 'hrContracts', id));
      }); return out; } });
    I.addRule({ id: 'rh.paie', check: function () {
      if (!canR('rh')) return [];
      var out = [], P = list('payroll'), HR = list('exb_hr'), byName = {}, ym = t0().slice(0, 7); HR.forEach(function (e) { byName[norm(lab(e))] = e; });
      P.forEach(function (p) {
        var nm = '« ' + (p.employee || '?') + ' » (' + (p.period || '?') + ')', e = byName[norm(p.employee)];
        if (num(p.deductions) > num(p.gross) + num(p.bonus)) out.push(F('erreur', 'Paie', 'Paie ' + nm + ' : retenues supérieures au brut et aux primes', 'payroll', p.id));
        if (num(p.gross) <= 0) out.push(F('alerte', 'Paie', 'Paie ' + nm + ' : brut nul ou négatif', 'payroll', p.id));
        if (p.employee && HR.length && !e) out.push(F('info', 'Paie', 'Paie ' + nm + ' : employé absent de la liste du personnel', 'payroll', p.id));
        if (e && num(e.salary) > 0 && num(p.gross) > 0 && Math.abs(num(p.gross) - num(e.salary)) / num(e.salary) > 0.1) out.push(F('info', 'Paie', 'Paie ' + nm + ' : brut différent de plus de 10 % du salaire de la fiche personnel', 'payroll', p.id));
      });
      out = out.concat(dupBy(P, function (p) { return p.employee && p.period ? norm(p.employee) + '|' + p.period : ''; }, 'payroll', 'Paie', 'même employé et même période', 'erreur'));
      if (P.length) { var miss = HR.filter(function (e) { return /actif|active/i.test(e.status || 'Actif') && num(e.salary) > 0 && !P.some(function (p) { return String(p.period || '').indexOf(ym) === 0 && norm(p.employee) === norm(lab(e)); }); }).length; if (miss) out.push({ sev: 'info', mod: 'Paie', msg: 'Paie de ' + ym + ' non saisie pour ' + miss + ' employé(s) actif(s)', ref: { col: 'payroll', id: 'periode-' + ym } }); }
      return out; } });

    /* ---- documents ---- */
    function relances() {
      var out = [], x = X(); if (!x || !x.edu || !x.edu.situation) return out;
      list('exb_participants').filter(act).forEach(function (p) { var s = x.edu.situation(p.participant_id); if (s && s.solde > 0.005 && s.prix > 0) out.push({ p: p, s: s }); });
      return out;
    }
    function relancesText() {
      return relances().slice(0, 200).map(function (r) { return 'Pour : ' + r.s.nom + (r.p.phone ? ' (' + r.p.phone + ')' : '') + '\nBonjour ' + r.s.nom + ', il reste ' + money(r.s.solde) + ' à régler pour la formation « ' + r.s.formation + ' » (versé : ' + money(r.s.verse) + ' sur ' + money(r.s.prix) + '). Merci de régulariser. Cordialement, Excellencia Building.'; }).join('\n\n— — —\n\n');
    }
    function formationHtml() {
      var x = X(), P = list('exb_participants').filter(act), C = list('exb_certificates'), rows = list('exb_formations').map(function (f) {
        var ps = P.filter(function (p) { return belongs(p, f); }), tot = 0, verse = 0;
        ps.forEach(function (p) { var s = x && x.edu && x.edu.situation ? x.edu.situation(p.participant_id) : null; if (s) { tot += s.prix; verse += s.verse; } });
        var nc = C.filter(function (c) { return ps.some(function (p) { return p.participant_id === c.participant_id; }); }).length;
        return '<tr><td>' + esc(lab(f)) + '</td><td>' + esc(f.start || '') + ' → ' + esc(f.end || '') + '</td><td>' + ps.length + ' / ' + (num(f.capacity) || '—') + '</td><td align="right">' + money(verse) + ' / ' + money(tot) + '</td><td>' + nc + '</td></tr>';
      }).join('');
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Rapport formation</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Rapport formation</h1><p>' + t0() + '</p><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Formation</th><th>Période</th><th>Inscrits / capacité</th><th>Encaissé / dû</th><th>Certificats</th></tr>' + (rows || '<tr><td colspan="5">Aucune formation</td></tr>') + '</table></body></html>';
    }
    function paieHtml(period) {
      var P = list('payroll').filter(function (p) { return String(p.period || '').indexOf(period) === 0; }), g = 0, b = 0, de = 0, nt = 0;
      var rows = P.map(function (p) { var n = I.calc.net(p); g += num(p.gross); b += num(p.bonus); de += num(p.deductions); nt += n; return '<tr><td>' + esc(p.employee) + '</td><td align="right">' + money(num(p.gross)) + '</td><td align="right">' + money(num(p.bonus)) + '</td><td align="right">' + money(num(p.deductions)) + '</td><td align="right"><b>' + money(n) + '</b></td></tr>'; }).join('');
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Récapitulatif de paie</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Récapitulatif de paie — ' + esc(period) + '</h1><p>Document confidentiel. Net = brut + primes − retenues.</p><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Employé</th><th>Brut</th><th>Primes</th><th>Retenues</th><th>Net</th></tr>' + (rows || '<tr><td colspan="5">Aucune paie pour cette période</td></tr>') + '<tr><td><b>Total</b></td><td align="right">' + money(g) + '</td><td align="right">' + money(b) + '</td><td align="right">' + money(de) + '</td><td align="right"><b>' + money(nt) + '</b></td></tr></table></body></html>';
    }
    function dl(name, html, what) { try { var b = new Blob([html], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); I.log('document', what); } catch (e) { toast('Export impossible.'); } }
    I.docs.relancesParticipants = relancesText; I.docs.formation = formationHtml; I.docs.paie = paieHtml;
    I.addReco(function () {
      var r = [], rl = relances(), t = t0(), lim = in30();
      if (rl.length) r.push({ ic: '🎓', t: rl.length + ' participant(s) avec un solde à régler', x: 'Total dû : ' + money(rl.reduce(function (a, z) { return a + z.s.solde; }, 0)) + '. Un message par participant est prêt.', acts: [{ l: 'Copier les relances', f: function () { if (H.copy(relancesText())) { I.log('document', 'Relances participants copiées (' + rl.length + ')'); toast(rl.length + ' relance(s) copiée(s).'); } else toast('Copie impossible.'); } }, { l: 'Ouvrir les participants', f: function () { H.go('participants'); } }] });
      if (list('exb_formations').length) r.push({ ic: '📊', t: 'Rapport formation', x: 'Inscrits, capacité, encaissé / dû et certificats par formation.', acts: [{ l: 'Télécharger le rapport', f: function () { dl('rapport-formation-' + t + '.html', formationHtml(), 'Rapport formation exporté'); } }] });
      if (canR('rh')) {
        var cs = list('hrContracts').filter(function (c) { return c.end && c.end >= t && c.end <= lim; }).length;
        if (cs) r.push({ ic: '📄', t: cs + ' contrat(s) à renouveler sous 30 jours', x: 'Anticipez les renouvellements ou les fins de contrat.', acts: [{ l: 'Ouvrir le personnel', f: function () { H.go('rh'); } }] });
        if (list('payroll').length) r.push({ ic: '💼', t: 'Récapitulatif de paie du mois', x: 'Brut, primes, retenues et net par employé (confidentiel).', acts: [{ l: 'Télécharger ' + t.slice(0, 7), f: function () { dl('paie-' + t.slice(0, 7) + '.html', paieHtml(t.slice(0, 7)), 'Récapitulatif de paie exporté (' + t.slice(0, 7) + ')'); } }] });
      }
      return r;
    });
    I.run();
  }
  boot(0);
})(window, document);
