/* Excellencia Building V99 — LIAISON, tranche 3 (extension de exb-liaison.js / exb-liaison-edu.js).
 * PÉDAGOGIE : planning ↔ formation ↔ formateur ; présences ↔ séance ; évaluations ↔ cotations ; demandes TP/TD ↔ formation.
 * OPÉRATIONS : stock (mouvements, réceptions de commandes) ↔ chantier ; dépenses de caisse ↔ chantier ; métrés ↔ client/chantier ;
 *              pointages ↔ personnel ; résultat par chantier (versé − dépenses, budget).
 * Même principe que les tranches 1 et 2 : on AJOUTE des identifiants, on ne renomme ni ne supprime rien, aucun lien n'est deviné
 * quand plusieurs candidats existent (il est alors signalé), aucun paiement ni mouvement n'est créé automatiquement.
 * Correctif d'intégrité : modifier une dépense, un matériau ou un projet depuis son écran ne fait plus perdre les identifiants déjà posés. */
(function (w, d) {
  'use strict';
  function boot(tries) {
    var X = w.EXBLIEN;
    if (!X || !X.extend || !X.edu) { if ((tries || 0) > 80) return; return setTimeout(function () { boot((tries || 0) + 1); }, 400); }
    var wr = X.wr, norm = X.norm, esc = X.esc, num = X.num, r2 = X.r2, fmt = X.fmt;
    var K = { att: 'exb_attendance', eva: 'exb_evaluations', cot: 'exb_cotations', sch: 'exb_schedules', tpr: 'exb_tp_td_requests',
      par: 'exb_participants', form: 'exb_formations', trn: 'exb_trainers', hr: 'exb_hr', stk: 'exb_stock', mv: 'exb_stock_moves',
      cash: 'exb_cash', po: 'exb_purchase_orders', ts: 'exb_timesheets', prj: 'exb_projects', met: 'exb_metre', pf: 'exb_plan_files' };

    /* listes gardées en mémoire par les écrans : on travaille dessus (sinon leur prochaine sauvegarde effacerait nos liens) */
    function live(k) {
      try {
        switch (k) {
          case 'exb_attendance': return typeof attendance !== 'undefined' ? attendance : null;
          case 'exb_evaluations': return typeof evaluations !== 'undefined' ? evaluations : null;
          case 'exb_cotations': return typeof cotations !== 'undefined' ? cotations : null;
          case 'exb_schedules': return typeof schedules !== 'undefined' ? schedules : null;
          case 'exb_tp_td_requests': return typeof tpRequests !== 'undefined' ? tpRequests : null;
          case 'exb_stock': return typeof exbStock !== 'undefined' ? exbStock : null;
          case 'exb_stock_moves': return typeof exbStockMoves !== 'undefined' ? exbStockMoves : null;
        }
      } catch (e) {}
      return null;
    }
    function rd(k) { var l = live(k); return Array.isArray(l) ? l : X.rd(k); }
    function uniq(a) { return a.length === 1 ? a[0] : null; }
    function setIf(o, k, v) { if (v && !o[k]) { o[k] = v; return true; } return false; }
    function tid(t) { return t && (t.trainer_id || t.id); }

    /* ======================= PÉDAGOGIE ======================= */
    function fIndex() {
      var F = rd(K.form), P = rd(K.par), T = rd(K.trn);
      return { F: F, P: P, T: T,
        fById: Object.fromEntries(F.map(function (f) { return [f.formation_id, f]; })),
        pById: Object.fromEntries(P.map(function (p) { return [p.participant_id, p]; })),
        tById: Object.fromEntries(T.map(function (t) { return [tid(t), t]; })) };
    }
    function formationByName(n, ix) { if (!n) return null; return uniq(ix.F.filter(function (f) { return norm(f.name) === norm(n); })); }
    function formationOfParticipant(p, ix) { if (!p) return null; if (p.formation_id && ix.fById[p.formation_id]) return ix.fById[p.formation_id]; return formationByName(p.training, ix); }
    function sameFormation(s, f) { return !!f && (s.formation_id === f.formation_id || norm(s.training) === norm(f.name)); }

    function linkPedagogie() {
      var ix = fIndex(), res = { planning: 0, presences: 0, evaluations: 0, cotations: 0, tptd: 0 };
      var S = rd(K.sch), chS = false;
      S.forEach(function (s) { if (s.formation_id && ix.fById[s.formation_id]) return; var f = formationByName(s.training, ix); if (f && setIf(s, 'formation_id', f.formation_id)) { res.planning++; chS = true; } });
      if (chS) wr(K.sch, S);
      var byDate = {}; S.forEach(function (s) { (byDate[s.date] = byDate[s.date] || []).push(s); });
      var A = rd(K.att), chA = false;
      A.forEach(function (a) {
        var p = ix.pById[a.participant_id], f = formationOfParticipant(p, ix), mod = false;
        if (f && setIf(a, 'formation_id', f.formation_id)) mod = true;
        if (f && !a.schedule_id) { var s = uniq((byDate[a.date] || []).filter(function (x) { return sameFormation(x, f); })); if (s && setIf(a, 'schedule_id', s.schedule_id)) mod = true; }
        if (mod) { res.presences++; chA = true; }
      });
      if (chA) wr(K.att, A);
      var C = rd(K.cot), chC = false;
      C.forEach(function (c) {
        var p = ix.pById[c.participant_id], f = formationOfParticipant(p, ix) || formationByName(c.training, ix), mod = false;
        if (f && setIf(c, 'formation_id', f.formation_id)) mod = true;
        if (f && !c.trainer_id) {
          var tr = {}; S.filter(function (s) { return sameFormation(s, f) && norm(s.module) === norm(c.module) && s.trainer_id; }).forEach(function (s) { tr[s.trainer_id] = 1; });
          var ks = Object.keys(tr); if (ks.length === 1 && setIf(c, 'trainer_id', ks[0])) mod = true;
        }
        if (mod) { res.cotations++; chC = true; }
      });
      if (chC) wr(K.cot, C);
      var E = rd(K.eva), chE = false;
      E.forEach(function (e) {
        var p = ix.pById[e.participant_id], f = formationOfParticipant(p, ix) || formationByName(e.training, ix), mod = false;
        if (f && setIf(e, 'formation_id', f.formation_id)) mod = true;
        if (!e.cotation_id && e.participant_id && e.subject) {
          var c = uniq(C.filter(function (x) { return x.participant_id === e.participant_id && norm(x.module) === norm(e.subject); }));
          if (c && setIf(e, 'cotation_id', c.cotation_id)) mod = true;
        }
        if (mod) { res.evaluations++; chE = true; }
      });
      if (chE) wr(K.eva, E);
      var R = rd(K.tpr), chR = false;
      R.forEach(function (r) {
        var p = ix.pById[r.participant_id], f = formationOfParticipant(p, ix) || formationByName(r.training, ix);
        if (f && setIf(r, 'formation_id', f.formation_id)) { res.tptd++; chR = true; }
      });
      if (chR) wr(K.tpr, R);
      res.total = res.planning + res.presences + res.evaluations + res.cotations + res.tptd;
      if (res.total) X.log('liaison_pedagogie', res, res.total + ' fiche(s) pédagogiques rattachée(s)');
      return res;
    }

    function tmin(t) { var m = /^(\d{1,2}):(\d{2})/.exec(String(t || '')); return m ? (+m[1]) * 60 + (+m[2]) : null; }
    function overlap(a, b) { var a1 = tmin(a.start), a2 = tmin(a.end), b1 = tmin(b.start), b2 = tmin(b.end); if (a1 == null || a2 == null || b1 == null || b2 == null) return false; return a1 < b2 && b1 < a2; }
    function modNames(f) { return (f && f.modules || []).map(function (m) { return typeof m === 'string' ? m : (m && (m.name || m.title || m.module)) || ''; }).filter(Boolean); }
    function cap(list, label) { if (list.length <= 8) return list; return list.slice(0, 8).concat([label + ' : ' + (list.length - 8) + ' autre(s) cas du même type non listé(s)']); }

    function anomaliesPedagogie() {
      var ix = fIndex(), a = [], S = rd(K.sch), A = rd(K.att), C = rd(K.cot), E = rd(K.eva), R = rd(K.tpr);
      var miss = {}; A.forEach(function (x) { if (!ix.pById[x.participant_id]) miss[x.participant_id] = 1; });
      if (Object.keys(miss).length) a.push(Object.keys(miss).length + ' participant(s) ont des présences enregistrées mais n’existent plus dans la liste des participants');
      var rej = A.filter(function (x) { var p = ix.pById[x.participant_id]; return p && p.approval_status === 'REJETE'; });
      if (rej.length) a.push(rej.length + ' présence(s) enregistrée(s) pour des participants refusés');
      var m2 = {}; C.concat(E).forEach(function (x) { if (x.participant_id && !ix.pById[x.participant_id]) m2[x.participant_id] = 1; });
      if (Object.keys(m2).length) a.push(Object.keys(m2).length + ' participant(s) ont des notes (évaluations/cotations) mais n’existent plus dans la liste des participants');
      var l = [];
      S.forEach(function (s) {
        var f = s.formation_id ? ix.fById[s.formation_id] : formationByName(s.training, ix), nm = (s.training || '?') + ' — ' + (s.module || '?') + ' (' + (s.date || '?') + ')';
        if (!f) { l.push('Séance ' + nm + ' : formation absente du catalogue'); return; }
        var mods = modNames(f); if (s.module && mods.length && !mods.some(function (m) { return norm(m) === norm(s.module); })) l.push('Séance ' + nm + ' : module absent du programme de la formation');
        if (s.trainer_id && !ix.tById[s.trainer_id]) l.push('Séance ' + nm + ' : formateur introuvable');
      });
      var seen = {};
      S.forEach(function (s) { var key = s.date; (seen[key] = seen[key] || []).push(s); });
      Object.keys(seen).forEach(function (dt) {
        var L = seen[dt];
        for (var i = 0; i < L.length; i++) for (var j = i + 1; j < L.length; j++) {
          var p = L[i], q = L[j]; if (!overlap(p, q)) continue;
          if (p.trainer_id && p.trainer_id === q.trainer_id) l.push('Formateur ' + ((ix.tById[p.trainer_id] || {}).name || p.trainer_id) + ' : deux séances se chevauchent le ' + dt + ' (' + p.module + ' / ' + q.module + ')');
          else if (p.room && norm(p.room) === norm(q.room)) l.push('Salle « ' + p.room + ' » : deux séances se chevauchent le ' + dt + ' (' + p.module + ' / ' + q.module + ')');
        }
      });
      a = a.concat(cap(l, 'Planning'));
      var tp = R.filter(function (r) { return r.participant_id && !ix.pById[r.participant_id]; });
      if (tp.length) a.push(tp.length + ' demande(s) TP/TD d’un participant introuvable');
      return a;
    }

    function htmlPedagogie() {
      var ix = fIndex(), S = rd(K.sch), A = rd(K.att), C = rd(K.cot), E = rd(K.eva), rows = [];
      ix.F.forEach(function (f) {
        var s = S.filter(function (x) { return sameFormation(x, f); }).length, at = A.filter(function (x) { return x.formation_id === f.formation_id; }),
          pr = at.filter(function (x) { return /^pres/i.test(String(x.status || '')); }).length,
          ev = E.filter(function (x) { return x.formation_id === f.formation_id; }).length, co = C.filter(function (x) { return x.formation_id === f.formation_id; }).length;
        if (!s && !at.length && !ev && !co) return;
        rows.push('<tr><td>' + esc(f.name) + '</td><td style="text-align:right">' + s + '</td><td style="text-align:right">' + (at.length ? Math.round(pr / at.length * 100) + ' %' : '—') + '</td><td style="text-align:right">' + ev + '</td><td style="text-align:right">' + co + '</td></tr>');
      });
      if (!rows.length) return '';
      return '<h4 style="margin:14px 0 6px">📚 Pédagogie par formation</h4><div style="overflow-x:auto"><table class="exb-table"><thead><tr><th>Formation</th><th>Séances</th><th>Présence</th><th>Évaluations</th><th>Cotations</th></tr></thead><tbody>' + rows.join('') + '</tbody></table></div>';
    }

    /* ======================= OPÉRATIONS ======================= */
    function pIndex() {
      var P = rd(K.prj), byId = {}, byName = {};
      P.forEach(function (p) { byId[p.id] = p; var k = norm(p.name); if (k) (byName[k] = byName[k] || []).push(p); });
      return { P: P, byId: byId, byName: byName };
    }
    function projectOfText(t, pi) { if (!t) return null; if (pi.byId[t]) return pi.byId[t]; var h = pi.byName[norm(t)]; return h && h.length === 1 ? h[0] : null; }
    function poIndex() { var O = rd(K.po), byId = {}, byNo = {}; O.forEach(function (o) { byId[o.id] = o; if (o.no) (byNo[o.no] = byNo[o.no] || []).push(o); }); return { O: O, byId: byId, byNo: byNo }; }

    function linkOperations() {
      var pi = pIndex(), oi = poIndex(), res = { stock: 0, caisse: 0, metres: 0 };
      var M = rd(K.mv), chM = false;
      M.forEach(function (m) {
        var mod = false, po = m.po_id ? oi.byId[m.po_id] : uniq(oi.byNo[m.ref] || []), p = m.project_id ? pi.byId[m.project_id] : null;
        if (po) { if (setIf(m, 'po_id', po.id)) mod = true; if (!p && po.project_id && pi.byId[po.project_id]) { p = pi.byId[po.project_id]; if (setIf(m, 'project_id', p.id)) mod = true; } }
        if (!p) { p = projectOfText(m.ref, pi); if (p && setIf(m, 'project_id', p.id)) mod = true; }
        if (p && p.client_id && setIf(m, 'client_id', p.client_id)) mod = true;
        if (mod) { res.stock++; chM = true; }
      });
      if (chM) wr(K.mv, M);
      var C = rd(K.cash), chC = false;
      C.forEach(function (x) {
        if (x.type !== 'out') return;
        var mod = false, po = x.po_id ? oi.byId[x.po_id] : uniq(oi.byNo[x.ref] || []), p = x.project_id ? pi.byId[x.project_id] : null;
        if (po) { if (setIf(x, 'po_id', po.id)) mod = true; if (!p && po.project_id && pi.byId[po.project_id]) { p = pi.byId[po.project_id]; if (setIf(x, 'project_id', p.id)) mod = true; } }
        if (!p) { p = projectOfText(x.ref, pi); if (p && setIf(x, 'project_id', p.id)) mod = true; }
        if (p && p.client_id && setIf(x, 'client_id', p.client_id)) mod = true;
        if (mod) { res.caisse++; chC = true; }
      });
      if (chC) wr(K.cash, C);
      var MT = X.rd(K.met), chT = false;
      if (Array.isArray(MT)) MT.forEach(function (m) {
        var h = m && m.hdr; if (!h) return; var mod = false, c = null;
        if (m.client_id) c = X.resolveClient(m.client_id); else if (h.client) { c = X.resolveClient(h.client); if (c && setIf(m, 'client_id', c.id)) mod = true; }
        var p = m.project_id ? pi.byId[m.project_id] : null;
        if (!p && h.project) { var hs = (pi.byName[norm(h.project)] || []).filter(function (x) { return !c || !x.client_id || x.client_id === c.id; }); p = uniq(hs); if (p && setIf(m, 'project_id', p.id)) mod = true; }
        if (p && !m.client_id && p.client_id && setIf(m, 'client_id', p.client_id)) mod = true;
        if (mod) { res.metres++; chT = true; }
      });
      if (chT) wr(K.met, MT);
      res.total = res.stock + res.caisse + res.metres;
      if (res.total) X.log('liaison_operations', res, res.total + ' fiche(s) rattachée(s) à leur chantier / client (stock, caisse, métrés)');
      return res;
    }

    /* résultat par chantier : versé (registre) − dépenses (caisse) ; main-d'œuvre pointée mais non payée ; budget */
    function resultat() {
      var pi = pIndex(), cash = rd(K.cash), ts = rd(K.ts), out = {}, horsChantier = {};
      function row(pid) { return out[pid] = out[pid] || { project_id: pid, nom: (pi.byId[pid] || {}).name || pid, budget: num((pi.byId[pid] || {}).budget), dep: {}, cat: {}, mo: 0, verse: {} }; }
      cash.forEach(function (x) {
        if (x.type !== 'out') return; var cur = x.currency || 'USD', amt = num(x.amount);
        if (!x.project_id || !pi.byId[x.project_id]) { horsChantier[cur] = r2((horsChantier[cur] || 0) + amt); return; }
        var r = row(x.project_id); r.dep[cur] = r2((r.dep[cur] || 0) + amt); var c = x.category || 'Autres'; r.cat[c] = r2((r.cat[c] || 0) + amt);
      });
      ts.forEach(function (t) { if (!t.cash_id && t.project_id && pi.byId[t.project_id]) row(t.project_id).mo = r2(row(t.project_id).mo + num(t.cost)); });
      pi.P.forEach(function (p) { var s = X.situation({ projectId: p.id }); Object.keys(s.total).forEach(function (c) { if (s.total[c].verse || s.total[c].facture) row(p.id).verse[c] = s.total[c].verse; }); });
      return { chantiers: Object.keys(out).map(function (k) { return out[k]; }), horsChantier: horsChantier };
    }

    function anomaliesOperations() {
      var pi = pIndex(), oi = poIndex(), a = [], l = [];
      var stk = rd(K.stk), ids = {}; stk.forEach(function (s) { ids[s.id] = s; if (num(s.qty) < 0) l.push('Stock « ' + s.name + ' » : quantité négative (' + s.qty + ')'); });
      rd(K.mv).forEach(function (m) { if (!ids[m.item]) l.push('Mouvement de stock ' + (m.id || '') + ' : matériau introuvable'); if (m.project_id && !pi.byId[m.project_id]) l.push('Mouvement de stock ' + (m.id || '') + ' : chantier introuvable'); });
      var hrs = {}; rd(K.hr).forEach(function (h) { hrs[h.id] = h; });
      var cashIds = {}; rd(K.cash).forEach(function (c) { cashIds[c.id] = c; if (c.project_id && !pi.byId[c.project_id]) l.push('Caisse « ' + (c.label || c.id) + ' » : chantier introuvable'); });
      rd(K.ts).forEach(function (t) {
        if (t.worker_id && !hrs[t.worker_id]) l.push('Pointage du ' + (t.date || '?') + ' (' + (t.worker_name || t.worker_id) + ') : personne introuvable dans la fiche personnel');
        if (t.project_id && !pi.byId[t.project_id]) l.push('Pointage du ' + (t.date || '?') + ' (' + (t.worker_name || '?') + ') : chantier introuvable');
        if (t.cash_id && !cashIds[t.cash_id]) l.push('Pointage du ' + (t.date || '?') + ' (' + (t.worker_name || '?') + ') : marqué payé mais l’écriture de caisse n’existe plus');
      });
      oi.O.forEach(function (o) { if (!o.project_id || !pi.byId[o.project_id]) l.push('Bon de commande ' + (o.no || o.id) + ' : chantier ' + (o.project_id ? 'introuvable' : 'non renseigné')); });
      rd(K.pf).forEach(function (f) { var p = f && (f.project_id || f.project); if (p && !pi.byId[p]) l.push('Plan « ' + (f.name || f.id || '?') + ' » : chantier introuvable'); });
      var R = resultat();
      R.chantiers.forEach(function (r) { if (r.budget > 0 && num(r.dep.USD) > r.budget + 0.005) l.push('Chantier « ' + r.nom + ' » : dépenses (' + fmt(r.dep.USD) + ' USD) supérieures au budget (' + fmt(r.budget) + ')'); });
      return a.concat(cap(l, 'Opérations'));
    }

    function htmlOperations() {
      var R = resultat(); if (!R.chantiers.length) return '';
      function cur(o) { var ks = Object.keys(o); return ks.length ? ks.map(function (c) { return fmt(o[c]) + ' ' + c; }).join('<br>') : '—'; }
      var rows = R.chantiers.map(function (r) {
        var sol = Object.keys(r.verse).map(function (c) { return fmt(r2(num(r.verse[c]) - num(r.dep[c]))) + ' ' + c; }).join('<br>') || '—';
        return '<tr><td>' + esc(r.nom) + '</td><td style="text-align:right">' + (r.budget ? fmt(r.budget) : '—') + '</td><td style="text-align:right">' + cur(r.verse) + '</td><td style="text-align:right">' + cur(r.dep) + '</td><td style="text-align:right">' + (r.mo ? fmt(r.mo) : '—') + '</td><td style="text-align:right">' + sol + '</td></tr>';
      }).join('');
      var hc = Object.keys(R.horsChantier).length ? '<p class="exb-muted" style="font-size:12px">Dépenses de caisse sans chantier (frais généraux ou à rattacher) : ' + Object.keys(R.horsChantier).map(function (c) { return fmt(R.horsChantier[c]) + ' ' + c; }).join(' · ') + '</p>' : '';
      return '<h4 style="margin:14px 0 6px">🏗 Résultat par chantier</h4><div style="overflow-x:auto"><table class="exb-table"><thead><tr><th>Chantier</th><th>Budget</th><th>Versé</th><th>Dépenses</th><th>M.O. à payer</th><th>Versé − dépenses</th></tr></thead><tbody>' + rows + '</tbody></table></div>' + hc;
    }

    function link() { try { linkPedagogie(); } catch (e) {} try { linkOperations(); } catch (e) {} }
    X.extend({ link: link, anomalies: function () { return anomaliesPedagogie().concat(anomaliesOperations()); }, html: function () { return htmlPedagogie() + htmlOperations(); } });
    X.ops = { linkPedagogie: linkPedagogie, linkOperations: linkOperations, anomaliesPedagogie: anomaliesPedagogie, anomaliesOperations: anomaliesOperations, resultat: resultat, htmlPedagogie: htmlPedagogie, htmlOperations: htmlOperations };

    /* ---------- sélecteur « Chantier » sur les formulaires Stock et Caisse ---------- */
    function projOptions(cur) { return '<option value="">— Aucun chantier —</option>' + rd(K.prj).map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === cur ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join(''); }
    function mountSelect(refId, selId) {
      var ref = d.getElementById(refId); if (!ref || !ref.parentNode) return;
      var s = d.getElementById(selId);
      if (!s) { var wrap = d.createElement('div'); wrap.id = selId + '_wrap'; wrap.style.cssText = 'margin-top:6px'; wrap.innerHTML = '<label style="display:block;font-size:12px">🏗 Chantier (facultatif)</label><select id="' + selId + '" style="max-width:100%"></select>'; ref.parentNode.insertBefore(wrap, ref.nextSibling); s = d.getElementById(selId); }
      var cur = s.value, html = projOptions(cur); if (s.getAttribute('data-sig') !== html) { s.innerHTML = html; s.setAttribute('data-sig', html); s.value = cur; }
    }
    function mount() { try { mountSelect('exb_mv_ref', 'exbLienMvPrj'); mountSelect('exb_cash_ref', 'exbLienCashPrj'); } catch (e) {} }
    function sel(id) { var e = d.getElementById(id); return e ? e.value : ''; }
    function applyProject(rec, pid) { var p = pIndex().byId[pid]; if (!rec || !p) return false; rec.project_id = p.id; if (p.client_id) rec.client_id = p.client_id; return true; }

    /* ---------- branchements sur les écrans existants (sans les remplacer) ---------- */
    function around(name, before, after) {
      var f = w[name]; if (typeof f !== 'function' || f.__lien3) return;
      var g = function () { var ctx = null; try { ctx = before.apply(null, arguments); } catch (e) {} var r = f.apply(this, arguments); try { after(ctx, r); } catch (e) {} return r; };
      g.__lien3 = 1; w[name] = g;
    }
    function keepExtras(list, id, old, skip) {
      if (!old) return; var cur = list.filter(function (x) { return x && x.id === id; })[0]; if (!cur) return;
      Object.keys(old).forEach(function (k) { if (!(k in cur) && !(skip && skip.indexOf(k) >= 0)) cur[k] = old[k]; });
    }
    function hook() {
      /* mouvement de stock : chantier choisi (sinon déduit de la référence) */
      around('saveExbStockMovement', function () { return { n: rd(K.mv).length, pid: sel('exbLienMvPrj') }; }, function (c) {
        var M = rd(K.mv); if (M.length > c.n) { var m = M[M.length - 1]; if (c.pid) applyProject(m, c.pid); wr(K.mv, M); var s = d.getElementById('exbLienMvPrj'); if (s) s.value = ''; }
        X.refresh();
      });
      /* caisse : chantier choisi ; une modification ne fait plus perdre les identifiants déjà posés (chantier, client, commande, catégorie…) */
      around('saveExbCash', function () {
        var id = sel('exb_cash_id'), C = rd(K.cash), old = id ? C.filter(function (x) { return x.id === id; })[0] : null;
        var ok = String(sel('exb_cash_label')).trim() && num(sel('exb_cash_amount')) > 0;
        return { id: id, old: old ? Object.assign({}, old) : null, n: C.length, pid: sel('exbLienCashPrj'), ok: !!ok };
      }, function (c) {
        if (!c.ok) return; var C = rd(K.cash), rec;
        if (c.id) { keepExtras(C, c.id, c.old); rec = C.filter(function (x) { return x.id === c.id; })[0]; } else if (C.length > c.n) rec = C[C.length - 1];
        if (rec && c.pid) applyProject(rec, c.pid);
        if (rec) { wr(K.cash, C); var s = d.getElementById('exbLienCashPrj'); if (s) s.value = ''; }
        X.refresh();
      });
      around('saveExbStockItem', function () { var id = sel('exb_st_id'), L = rd(K.stk), o = id ? L.filter(function (x) { return x.id === id; })[0] : null; return { id: id, old: o ? Object.assign({}, o) : null }; }, function (c) {
        if (c.id && c.old) { var L = rd(K.stk); keepExtras(L, c.id, c.old); wr(K.stk, L); }
      });
      around('saveExbProject', function () { var id = sel('exb_prj_id'), L = rd(K.prj), o = id ? L.filter(function (x) { return x.id === id; })[0] : null; return { id: id, old: o ? Object.assign({}, o) : null }; }, function (c) {
        if (c.id && c.old) { var L = rd(K.prj); keepExtras(L, c.id, c.old, ['client_id', 'client_snapshot']); wr(K.prj, L); }
        X.refresh();
      });
      ['saveSchedule', 'saveAttendance', 'saveEvaluation', 'saveCotation'].forEach(function (n) { around(n, function () { return null; }, function () { X.refresh(); }); });
    }
    var tick = 0;
    function start() { hook(); mount(); link(); try { X.refresh(); } catch (e) {} }
    start();
    setInterval(function () { mount(); if (++tick % 5 === 0) hook(); }, 4000);
    w.addEventListener && w.addEventListener('exb-liaison-change', mount);
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 2500); }); else setTimeout(boot, 2500);
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { readyState: 'complete', getElementById: function () { return null; }, addEventListener: function () {} });
