/* Excellencia Building V99 — Site vitrine : photos publiées depuis le logiciel + adresses modifiables.
 * Les photos et les adresses sont envoyées dans Supabase Storage (bucket public « vitrine »). Le site les lit à l'ouverture :
 * plus besoin de redéployer sur Netlify pour une photo ou un changement d'adresse. Réglages enregistrés via exbStorage. */
(function(w,d){'use strict';
var KEY='exb_vitrine_cfg',BUCKET='vitrine',LOCAL='site-vitrine/',I=[],loaded=false,busy=false;
var CAT=[['arch','Architecture 3D'],['chantier','Chantiers'],['fer','Ferraillage']];
function $(i){return d.getElementById(i)}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function cfgGet(){try{return JSON.parse((w.exbStorage&&w.exbStorage.getItem(KEY))||localStorage.getItem(KEY)||'{}')||{}}catch(e){return{}}}
function cfgSet(c){var s=JSON.stringify(c);try{if(w.exbStorage)w.exbStorage.setItem(KEY,s);else localStorage.setItem(KEY,s)}catch(e){}}
function sb(){return(w.exbSb&&w.exbSb.cfg&&w.exbSb.cfg())||{}}
function pub(){var c=sb();return c.url?c.url+'/storage/v1/object/public/'+BUCKET+'/':''}
function org(u){u=norm(u);try{return new URL(u).origin+'/'}catch(e){return u}}
function norm(u){u=String(u||'').trim();if(!u)return'';if(!/^https?:\/\//i.test(u))u='https://'+u;return u.replace(/\/+$/,'')+'/'}
function msg(t,k){var m=$('vt_msg');if(!m)return;m.className=k||'';m.textContent=t}
function src(x){return x.blobUrl||(/^https?:/.test(x.f)?x.f:LOCAL+x.f)}
function getJ(u){return fetch(u+(u.indexOf('?')<0?'?':'&')+'t='+Date.now(),{cache:'no-store'}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()})}

/* ---------- interface ---------- */
var HTML='<div class="card"><h2>🌐 Site vitrine</h2><p class="exb-muted">Publiez ici les photos de vos travaux et gérez les adresses : le site se met à jour tout seul, sans redéployer sur Netlify.</p>'
+'<h3>1. Adresses</h3>'
+'<label>Adresse du site vitrine (celle que les gens ouvrent)</label><input id="vt_site" placeholder="https://mon-site-vitrine.netlify.app/">'
+'<label>Adresse du logiciel (reçoit les demandes de devis et les inscriptions)</label><input id="vt_app" placeholder="https://excellenciabuildingsarlu.netlify.app/">'
+'<label>WhatsApp (avec l\'indicatif, sans +)</label><input id="vt_wa" placeholder="243810644554">'
+'<p><button type="button" id="vt_save">💾 Enregistrer les adresses</button> <button type="button" id="vt_open">↗ Ouvrir le site</button> <button type="button" id="vt_copy">📋 Copier les liens</button></p>'
+'<p class="exb-muted">Votre identité (nom, logo, couleurs, contacts), réglée une seule fois dans ❓ › Personnaliser, est publiée avec les photos : les visiteurs ne voient jamais d\'écran de configuration.</p><p class="exb-muted">Après un changement, touchez « Publier sur le site » plus bas : le site utilise alors les nouvelles adresses immédiatement.</p>'
+'<h3>2. Paiement en ligne (Mobile Money)</h3><label><input type="checkbox" id="vp_on"> Activer le paiement sur les formulaires</label>'+'<label>Devise</label><select id="vp_dev"><option>USD</option><option>CDF</option></select>'+'<label>Numéros qui reçoivent l\'argent (jusqu\'à 3)</label><div id="vp_acc"></div>'+'<label>Montants (0 = pas de paiement pour ce formulaire)</label><div id="vp_typ"></div>'+'<p class="exb-muted">Le visiteur envoie l\'argent à vos numéros puis indique son numéro et la référence de la transaction. Vérifiez chaque paiement dans votre relevé Mobile Money avant de valider.</p>'
+'<h3>3. Photos du site</h3><p id="vt_msg" class="exb-muted">Chargement de la galerie…</p>'
+'<p><label class="btn" style="display:inline-block;cursor:pointer;padding:10px 14px;border-radius:8px;background:#173565;color:#fff;font-weight:700">+ Ajouter des photos<input id="vt_add" type="file" accept="image/*" multiple hidden></label> <button type="button" id="vt_reload">↻ Recharger</button></p>'
+'<div id="vt_list"></div>'
+'<p style="position:sticky;bottom:0;background:#fff;padding:8px 0"><button type="button" id="vt_pub" style="background:#18733b;color:#fff;font-weight:700">🚀 Publier sur le site</button> <button type="button" id="vt_zip">⬇ Site complet (ZIP)</button></p>'
+'<h3>4. Paiements reçus <span id="vp_cnt"></span></h3><p><button type="button" id="vp_ref">↻ Actualiser</button></p><div id="vp_list" class="exb-muted">Connectez-vous au serveur pour voir les paiements.</div>'
+'<h3>5. Authenticité des documents</h3><p class="exb-muted">Devis, factures, reçus, certificats et fiches d\'inscription portent un QR : le scan affiche les repères enregistrés (nom, matricule, formation, date, montant, statut), jamais les contacts.</p><p><button type="button" id="vd_pub">📤 Publier les documents existants</button> <button type="button" id="vd_chk">🔎 Vérifier un document</button></p>'
+'<details><summary>Première mise en place (une seule fois)</summary><ol class="exb-muted"><li>Supabase › SQL Editor : exécutez <b>supabase/migration-v99-vitrine.sql</b> (après avoir mis votre e-mail administrateur dedans).</li><li>Ici : connectez-vous au serveur (Inscriptions › Demandes reçues), puis touchez « Publier sur le site ».</li><li>Touchez « Site complet (ZIP) », décompressez, puis déposez le dossier sur Netlify (Deploys › glisser). Cette fois seulement.</li></ol><p class="exb-muted">Ensuite, photos, légendes, ordre et adresses se changent depuis cet écran, sans nouveau déploiement.</p></details></div>';


var OPS=['M-Pesa','Airtel Money','Orange Money','Africell Money','Autre'],TY=[['apprenant','Apprenant (frais d\'inscription)'],['logiciel','Demande de logiciel (acompte)'],['projet','BTP · Architecture (acompte)']];
function payUI(p){p=p||{};var a=p.comptes||[];$('vp_on').checked=!!p.actif;$('vp_dev').value=p.devise||'USD';
  $('vp_acc').innerHTML=[0,1,2].map(function(i){var c=a[i]||{};return'<div style="display:flex;gap:6px;margin:4px 0;flex-wrap:wrap"><select id="vpo'+i+'">'+OPS.map(function(o){return'<option'+(o===c.op?' selected':'')+'>'+o+'</option>'}).join('')+'</select><input id="vpn'+i+'" value="'+esc(c.num||'')+'" placeholder="Numéro" inputmode="tel" style="flex:1;min-width:120px"><input id="vpm'+i+'" value="'+esc(c.nom||'')+'" placeholder="Nom du compte" style="flex:1;min-width:120px"></div>'}).join('');
  $('vp_typ').innerHTML=TY.map(function(t){var x=(p.types||{})[t[0]]||{};return'<div style="display:flex;gap:6px;margin:4px 0;align-items:center;flex-wrap:wrap"><span style="min-width:200px">'+t[1]+'</span><input id="vt_m_'+t[0]+'" type="number" min="0" step="any" value="'+(x.montant||0)+'" style="width:90px"><label><input type="checkbox" id="vt_o_'+t[0]+'"'+(x.obligatoire?' checked':'')+'> obligatoire</label></div>'}).join('')}
function payRead(){var cs=[0,1,2].map(function(i){return{op:$('vpo'+i).value,num:$('vpn'+i).value.trim(),nom:$('vpm'+i).value.trim()}}).filter(function(c){return c.num}),ty={};
  TY.forEach(function(t){var m=parseFloat($('vt_m_'+t[0]).value)||0;if(m>0)ty[t[0]]={montant:m,obligatoire:$('vt_o_'+t[0]).checked}});
  return{actif:$('vp_on').checked&&cs.length>0,devise:$('vp_dev').value,comptes:cs,types:ty}}

async function payList(){var L=$('vp_list');if(!L)return;
  if(!w.exbSb||!w.exbSb.isIn||!w.exbSb.isIn()){L.textContent='Connectez-vous au serveur pour voir les paiements.';return}
  try{var r=await w.exbSb.api('/rest/v1/paiements_declares?select=*&order=created_at.desc&limit=50');r=Array.isArray(r)?r:[];
    var n=r.filter(function(x){return x.statut==='a_verifier'}).length;$('vp_cnt').textContent=n?'('+n+' à vérifier)':'';
    L.innerHTML=r.length?r.map(function(x){var col=x.statut==='confirme'?'#18733b':x.statut==='rejete'?'#b91c1c':'#b45309',lib=x.statut==='confirme'?'Confirmé':x.statut==='rejete'?'Rejeté':'À vérifier';
      return'<div class="card" style="margin:6px 0"><b>'+esc(x.nom||'—')+'</b> · '+esc(x.type)+' · '+esc(x.telephone||'')+(x.matricule?' · '+esc(x.matricule):'')+'<br>'+esc(x.montant)+' '+esc(x.devise)+' · '+esc(x.reseau||'')+' · payeur '+esc(x.numero_payeur||'')+'<br>Réf. <b>'+esc(x.reference)+'</b>'+(x.doublon?' <span style="color:#b91c1c">⚠ référence déjà utilisée</span>':'')+'<br><small>'+new Date(x.created_at).toLocaleString('fr-FR')+'</small> <span style="color:'+col+';font-weight:700">'+lib+'</span>'
       +(x.statut==='a_verifier'?'<div><button type="button" data-pid="'+x.id+'" data-ps="confirme" style="background:#18733b;color:#fff">✓ Confirmer</button> <button type="button" data-pid="'+x.id+'" data-ps="rejete" style="background:#fee2e2;color:#b91c1c">✗ Rejeter</button></div>':'')+'</div>'}).join(''):'Aucun paiement déclaré pour le moment.'
  }catch(e){L.textContent='Impossible de lire les paiements : '+(e&&e.message||e)+' (exécutez migration-v99g-paiements.sql dans Supabase).'}}
async function payAct(id,s){try{await w.exbSb.api('/rest/v1/paiements_declares?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{'Content-Type':'application/json','Prefer':'return=representation'},body:JSON.stringify({statut:s,verifie_le:new Date().toISOString()})});payList()}catch(e){msg('Échec : '+(e&&e.message||e),'er')}}
function build(){
  if($('vitrine'))return;
  var sec=d.createElement('section');sec.id='vitrine';sec.style.display='none';sec.innerHTML=HTML;
  var ref=$('portailApprenant')||$('communication');
  if(ref&&ref.parentNode)ref.parentNode.insertBefore(sec,ref.nextSibling);else(d.querySelector('main')||d.body).appendChild(sec);
  var bc=$('bcom')||$('bport'),b=d.createElement('button');b.id='bvit';b.textContent='🌐 Site vitrine';b.onclick=function(){w.show('vitrine')};
  if(bc&&bc.parentNode)bc.parentNode.insertBefore(b,bc.nextSibling);
  $('vt_save').onclick=saveAddr;$('vd_pub').onclick=function(){if(w.EXBVerif)w.EXBVerif.publishAll()};$('vd_chk').onclick=function(){if(w.EXBVerif)w.EXBVerif.search()};$('vp_ref').onclick=payList;$('vp_list').addEventListener('click',function(e){var b=e.target.closest('button[data-pid]');if(b&&confirm(b.getAttribute('data-ps')==='confirme'?'Confirmer ce paiement ?':'Rejeter ce paiement ?'))payAct(b.getAttribute('data-pid'),b.getAttribute('data-ps'))});$('vt_open').onclick=function(){var u=norm($('vt_site').value);if(u)w.open(u,'_blank');else msg('Saisissez d\'abord l\'adresse du site.','ann')};
  $('vt_copy').onclick=copyLinks;$('vt_reload').onclick=function(){load(true)};$('vt_pub').onclick=publish;$('vt_zip').onclick=zipSite;
  $('vt_add').onchange=addFiles;
  $('vt_list').addEventListener('input',function(e){var t=e.target,i=t.getAttribute('data-i');if(i!=null)I[i][t.getAttribute('data-k')]=t.value});
  $('vt_list').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var i=+b.getAttribute('data-i'),a=b.getAttribute('data-a');
    if(a==='rm'){if(!confirm('Supprimer cette photo du site ?'))return;I.splice(i,1)}
    else if(a==='up'&&i>0)I.splice(i-1,0,I.splice(i,1)[0]);
    else if(a==='dn'&&i<I.length-1)I.splice(i+1,0,I.splice(i,1)[0]);
    draw()});
  var c=cfgGet();payUI(c.pay);$('vt_site').value=c.site_url||'https://excellenciacenter01.netlify.app/';$('vt_app').value=c.logiciel_url||'https://excellenciabuildingsarlu.netlify.app/';$('vt_wa').value=c.whatsapp||'243810644554';
}
function draw(){
  $('vt_list').innerHTML=I.map(function(x,i){return'<div class="card" style="display:flex;gap:10px;align-items:flex-start"><img src="'+esc(src(x))+'" alt="" style="width:92px;height:92px;object-fit:cover;border-radius:8px;flex:none"><div style="flex:1;min-width:0">'
   +'<input data-i="'+i+'" data-k="t" value="'+esc(x.t)+'" maxlength="90" placeholder="Légende">'
   +'<select data-i="'+i+'" data-k="c">'+CAT.map(function(c){return'<option value="'+c[0]+'"'+(c[0]===x.c?' selected':'')+'>'+c[1]+'</option>'}).join('')+'</select>'
   +'<div><button type="button" data-a="up" data-i="'+i+'">↑</button> <button type="button" data-a="dn" data-i="'+i+'">↓</button> <button type="button" data-a="rm" data-i="'+i+'" style="background:#fee2e2;color:#b91c1c">Supprimer</button></div></div></div>'}).join('')}

/* ---------- adresses ---------- */
function saveAddr(){var c=cfgGet();c.site_url=norm($('vt_site').value);c.logiciel_url=org($('vt_app').value);c.whatsapp=String($('vt_wa').value||'').replace(/\D/g,'');c.pay=payRead();cfgSet(c);
  $('vt_site').value=c.site_url;$('vt_app').value=c.logiciel_url;msg('✓ Adresses enregistrées. Touchez « Publier sur le site » pour que le site les utilise.','valid')}
function copyLinks(){var c=cfgGet(),t='Site : '+(c.site_url||'—')+'\nLogiciel : '+(c.logiciel_url||'—')+'\nDemande de devis : '+(c.logiciel_url?c.logiciel_url+'btp.html':'—')+'\nInscription formation : '+(c.logiciel_url?c.logiciel_url+'inscription.html':'—');
  try{navigator.clipboard.writeText(t).then(function(){msg('✓ Liens copiés.','valid')},function(){prompt('Copiez :',t)})}catch(e){prompt('Copiez :',t)}}

/* ---------- galerie ---------- */
async function load(force){
  if(loaded&&!force){draw();return}
  msg('Chargement de la galerie…');var j=null,P=pub();
  if(P){try{j=await getJ(P+'galerie.json')}catch(e){j=null}}
  if(!j){try{j=await getJ(LOCAL+'galerie.json')}catch(e){j=null}}
  if(!Array.isArray(j)){msg('Galerie introuvable.','ann');return}
  I=j.map(function(x){return{f:x.f,c:x.c,t:x.t}});loaded=true;draw();
  msg(I.length+' photo(s). Ajoutez, légendez, classez puis touchez « Publier sur le site ».')}
function shrink(f){return new Promise(function(ok,ko){var u=URL.createObjectURL(f),im=new Image();im.onload=function(){var r=Math.min(900/im.naturalWidth,1),c=d.createElement('canvas');c.width=Math.round(im.naturalWidth*r);c.height=Math.round(im.naturalHeight*r);var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);c.toBlob(function(b){URL.revokeObjectURL(u);b?ok(b):ko()},'image/jpeg',.74)};im.onerror=function(){ko()};im.src=u})}
async function addFiles(e){var fs=[].slice.call(e.target.files),n=0;for(var k=0;k<fs.length;k++){try{var b=await shrink(fs[k]);I.push({c:'chantier',t:'Nouvelle photo',blob:b,blobUrl:URL.createObjectURL(b)});n++}catch(x){}}e.target.value='';draw();msg(n+' photo(s) ajoutée(s) : ajoutez une légende puis touchez « Publier sur le site ».','valid')}

/* ---------- publication (Supabase Storage) ---------- */
async function put(path,blob,type,cache){await w.exbSb.api('/storage/v1/object/'+BUCKET+'/'+path,{method:'POST',headers:{'Content-Type':type,'x-upsert':'true','cache-control':cache||'max-age=3600'},body:blob})}
function jsonBlob(o){return new Blob([JSON.stringify(o,null,1)],{type:'application/json'})}
async function publish(){
  if(busy)return;var c=sb();
  if(!c.url||!c.key){msg('Le serveur Supabase n\'est pas configuré (Inscriptions › Demandes reçues).','er');return}
  if(!w.exbSb||!w.exbSb.isIn||!w.exbSb.isIn()){msg('Connectez-vous d\'abord au serveur avec le compte administrateur (Inscriptions › Demandes reçues).','er');return}
  if(!I.length&&!confirm('La galerie est vide : le site n\'affichera aucune photo. Continuer ?'))return;
  busy=true;$('vt_pub').disabled=true;var P=pub(),out=[],k=0,warn=0;
  try{
    saveAddr();var ac=cfgGet();
    for(var i=0;i<I.length;i++){var x=I[i];msg('Envoi '+(i+1)+' / '+I.length+'…');var f=x.f;
      if(x.blob){f='images/photo-'+Date.now().toString(36)+'-'+(k++)+'.jpg';await put(f,x.blob,'image/jpeg','max-age=31536000');f=P+f}
      else if(f.indexOf(P)!==0){var base=f.split('/').pop();
        try{var r=await fetch(/^https?:/.test(f)?f:LOCAL+f);if(!r.ok)throw 0;var b=await r.blob();await put('images/'+base,b,'image/jpeg','max-age=31536000');f=P+'images/'+base}catch(e){warn++}}
      out.push({f:f,c:x.c,t:x.t})}
    await put('galerie.json',jsonBlob(out),'application/json','max-age=30');
    await put('config.json',jsonBlob({logiciel_url:ac.logiciel_url||'',whatsapp:ac.whatsapp||'',maj:new Date().toISOString()}),'application/json','max-age=30');
    if(ac.pay)await put('paiement.json',jsonBlob(ac.pay),'application/json','max-age=30');
    var BR=w.EXB_BRAND||{};if(BR.name){var pb={};['name','short','chantier','tagline','primary','secondary','accent','logo','phone','email','address'].forEach(function(k){if(BR[k]!=null)pb[k]=BR[k]});await put('brand.json',jsonBlob(pb),'application/json','max-age=30')}
    try{if(w.EXBSign&&EXBSign.active&&EXBSign.active()){var vp=await EXBSign.visa('png');if(vp){var vb=await (await fetch(vp)).blob();await put('visa.png',vb,'image/png','max-age=30')}}}catch(e){warn++}
    I=out.map(function(x){return{f:x.f,c:x.c,t:x.t}});draw();
    msg('✓ Publié. Le site affiche déjà ces '+out.length+' photo(s), ces adresses, votre identité et le paiement.'+(warn?' ('+warn+' photo(s) du site d\'origine n\'ont pas pu être copiées.)':''),'valid')
  }catch(e){var t=e&&e.message||String(e);msg('Échec : '+t+(/Bucket not found|not found/i.test(t)?' — exécutez d\'abord migration-v99-vitrine.sql dans Supabase.':/row-level|violat|refus/i.test(t)?' — votre e-mail administrateur n\'est pas autorisé dans migration-v99-vitrine.sql.':''),'er')}
  finally{busy=false;$('vt_pub').disabled=false}}

/* ---------- ZIP du site complet (déploiement Netlify) ---------- */
function crc(u){var t=crc.t;if(!t){t=crc.t=[];for(var n=0,c,k;n<256;n++){c=n;for(k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}}var c=-1;for(var i=0;i<u.length;i++)c=t[(c^u[i])&255]^(c>>>8);return(c^-1)>>>0}
function zip(fl){var P=[],C=[],o=0,te=new TextEncoder();fl.forEach(function(f){var nb=te.encode(f.n),c=crc(f.d),h=new DataView(new ArrayBuffer(30));h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x800,true);h.setUint16(12,0x21,true);h.setUint32(14,c,true);h.setUint32(18,f.d.length,true);h.setUint32(22,f.d.length,true);h.setUint16(26,nb.length,true);P.push(h.buffer,nb,f.d);
 var e=new DataView(new ArrayBuffer(46));e.setUint32(0,0x02014b50,true);e.setUint16(4,20,true);e.setUint16(6,20,true);e.setUint16(8,0x800,true);e.setUint16(14,0x21,true);e.setUint32(16,c,true);e.setUint32(20,f.d.length,true);e.setUint32(24,f.d.length,true);e.setUint16(28,nb.length,true);e.setUint32(42,o,true);C.push(e.buffer,nb);o+=30+nb.length+f.d.length});
 var cs=0;C.forEach(function(x){cs+=x.byteLength!=null?x.byteLength:x.length});var n=new DataView(new ArrayBuffer(22));n.setUint32(0,0x06054b50,true);n.setUint16(8,fl.length,true);n.setUint16(10,fl.length,true);n.setUint32(12,cs,true);n.setUint32(16,o,true);return new Blob(P.concat(C,[n.buffer]),{type:'application/zip'})}
async function bytes(r){return new Uint8Array(await r.arrayBuffer())}
async function zipSite(){
  try{msg('Préparation du site…');var ac=cfgGet(),P=pub(),fl=[],js=[],k=0;
    for(var i=0;i<I.length;i++){var x=I[i],f=x.f;
      if(x.blob){f='images/photo-'+Date.now().toString(36)+'-'+(k++)+'.jpg';fl.push({n:f,d:new Uint8Array(await x.blob.arrayBuffer())})}
      else if(!/^https?:/.test(f)){fl.push({n:f,d:await bytes(await fetch(LOCAL+f))})}
      js.push({f:f,c:x.c,t:x.t})}
    fl.push({n:'galerie.json',d:new TextEncoder().encode(JSON.stringify(js,null,1))});
    fl.push({n:'config.json',d:new TextEncoder().encode(JSON.stringify({logiciel_url:ac.logiciel_url||'',whatsapp:ac.whatsapp||'',remote:P},null,1))});
    var rest=['index.html','admin.html','_headers','netlify.toml'];for(var q=0;q<rest.length;q++){var r=await fetch(LOCAL+rest[q],{cache:'no-store'});if(r.ok)fl.push({n:rest[q],d:await bytes(r)})}
    var a=d.createElement('a');a.href=URL.createObjectURL(zip(fl));a.download='site-excellencia-building.zip';a.click();
    msg('✓ Site téléchargé. Décompressez-le puis déposez le dossier sur Netlify (Deploys › glisser le dossier).'+(P?'':' Attention : serveur non configuré, le site utilisera seulement ses propres fichiers.'),'valid')
  }catch(e){msg('Échec : '+(e&&e.message||e),'er')}}

/* ---------- branchement sur la navigation ---------- */
function install(){
  build();if(w.__exbVitrine||typeof w.show!=='function')return;w.__exbVitrine=true;var os=w.show;
  w.show=function(x){var r=os.apply(this,arguments);try{var el=$('vitrine');if(el)el.style.display=x==='vitrine'?'':'none';var b=$('bvit');if(b){if(x==='vitrine')b.classList.add('active');else b.classList.remove('active')}if(x==='vitrine'){load(false);payList()}}catch(e){}return r}}
w.EXB_VITRINE={install:install,load:load,publish:publish};
if(d.readyState==='complete')setTimeout(install,400);else w.addEventListener('load',function(){setTimeout(install,400)});
})(window,document);
