/* Excellencia Building V99zzzzzzzzzzzzzz — QCM à côté de TP / TD : génère des questions QCM dans le générateur TP / TD.
   Format écrit dans « Questions / exercices » (lu par epreuve.html et par la publication en ligne) :
     énoncé
     A) …   B) …   C) …   D) …
     Réponse : B
     Explication : …
   Les blocs sont séparés par une ligne vide. */
(function (w) {
  'use strict';
  var LETTRES = 'ABCDEF';
  function $(i) { return document.getElementById(i); }
  function banques() { return w.EXBQCM_BANKS || null; }
  function mel(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function une(t) { return String(t == null ? '' : t).replace(/\s*\r?\n\s*/g, ' ').trim(); }
  function remplirLogiciels() {
    var sel = $('tp_qcm_soft'), B = banques(); if (!sel) return;
    if (!B) { sel.innerHTML = '<option value="">Banque QCM indisponible</option>'; return; }
    var avant = sel.value, noms = (B.all && B.all.length ? B.all : Object.keys(B.data || {}));
    sel.innerHTML = noms.filter(function (n) { return B.count && B.count(n) > 0; }).map(function (n) { return '<option value="' + n.replace(/"/g, '&quot;') + '">' + n + ' (' + B.count(n) + ' questions)</option>'; }).join('') || '<option value="">Aucune banque remplie</option>';
    if (avant) sel.value = avant;
  }
  function reservoir(nom, niveau) {
    var B = banques(), d = (B && B.data && B.data[nom]) || {}, out = [];
    (niveau === 'tous' ? ['debutant', 'intermediaire', 'avance'] : [niveau]).forEach(function (k) { (d[k] || []).forEach(function (q) { out.push(q); }); });
    return out;
  }
  /* q = [énoncé, [options], index de la bonne réponse, explication] */
  function bloc(q) {
    var opts = (q[1] || []).slice(0, 6), bonne = Number(q[2]) || 0;
    if (opts.length < 2 || bonne < 0 || bonne >= opts.length) return '';
    var ordre = mel(opts.map(function (o, i) { return i; })), lignes = [une(q[0])], rep = '';
    ordre.forEach(function (idx, pos) { lignes.push(LETTRES[pos] + ') ' + une(opts[idx])); if (idx === bonne) rep = LETTRES[pos]; });
    lignes.push('Réponse : ' + rep);
    if (une(q[3])) lignes.push('Explication : ' + une(q[3]));
    return lignes.join('\n');
  }
  function aDesQcm(t) { return /(^|\n)\s*r[ée]ponses?\s*:/i.test(String(t || '')); }
  function sansQcm(t) { /* ne garde que les blocs qui ne sont pas des QCM */
    return String(t || '').split(/\r?\n\s*\r?\n/).map(function (b) { return b.trim(); }).filter(function (b) { return b && !aDesQcm(b); }).join('\n\n');
  }
  function msg(h, ok) { var m = $('tp_qcm_msg'); if (m) m.innerHTML = '<span class="' + (ok ? 'valid' : 'ann') + '">' + h + '</span>'; }
  function generer(mode) {
    var nom = ($('tp_qcm_soft') || {}).value, niv = ($('tp_qcm_level') || {}).value || 'debutant', n = parseInt(($('tp_qcm_n') || {}).value, 10) || 30, zone = $('tp_questions');
    if (!zone) return;
    if (!nom) return msg('Choisissez un logiciel dans la banque QCM.', false);
    n = Math.max(1, Math.min(100, n));
    var pool = mel(reservoir(nom, niv)), blocs = [], vus = {};
    pool.forEach(function (q) { if (blocs.length >= n) return; var k = une(q[0]); if (vus[k]) return; var b = bloc(q); if (b) { vus[k] = 1; blocs.push(b); } });
    if (!blocs.length) return msg('Aucune question disponible pour ' + nom + ' (' + niv + ').', false);
    var reste = (mode === 'remplacer') ? '' : String(zone.value || '').trim();
    /* des questions libres écrites une par ligne deviennent des blocs séparés par une ligne vide, sinon elles fusionneraient */
    if (reste && !aDesQcm(reste)) reste = reste.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean).join('\n\n');
    zone.value = (reste ? reste + '\n\n' : '') + blocs.join('\n\n');
    var dur = ($('tp_qcm_dur') || {}).value, champ = $('tp_duration'); if (dur && champ && !champ.value) champ.value = dur;
    try { zone.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { /* ancien navigateur */ }
    msg('✓ ' + blocs.length + ' question(s) QCM de « ' + nom + ' » ajoutée(s). Chaque apprenant en recevra 10 au hasard. Publiez l’épreuve en ligne pour la correction automatique.' + (blocs.length < n ? ' (La banque n’en contient pas davantage à ce niveau.)' : ''), true);
  }
  function vider() {
    var zone = $('tp_questions'); if (!zone) return;
    zone.value = sansQcm(zone.value);
    /* sans QCM, les questions libres redeviennent « une par ligne » */
    zone.value = zone.value.split(/\n\s*\n/).join('\n');
    msg('Les QCM ont été retirés ; vos autres questions sont conservées.', true);
  }
  function init() { remplirLogiciels(); var s = $('tp_qcm_soft'); if (s) s.addEventListener('focus', remplirLogiciels); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  w.addEventListener('load', remplirLogiciels);
  w.EXBTpQcm = { generer: generer, vider: vider, bloc: bloc, remplir: remplirLogiciels, reservoir: reservoir };
})(window);
