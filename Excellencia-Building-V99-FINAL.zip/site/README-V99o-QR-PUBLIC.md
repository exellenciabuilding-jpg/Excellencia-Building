# V99o — QR de vérification public (sans l'application)

Le QR de tous les documents ouvre `verification.html` : page autonome (sans connexion, sans licence, sans lien vers le logiciel) qui affiche seulement les informations du document.
Format : `<site>/verification.html?c=type~numéro~date~montant~devise~code~nom`.

- Couvre : devis, factures, reçus, certificats, reçus d'inscription, fiches d'inscription, rapport d'activité et tous les PDF du moteur commun (EXBPdf).
- QR moins dense (lien court, modules à taille entière, 120 px sur certificat/reçu).
- Anciens devis (`#verify=`) : l'application redirige vers la nouvelle page.
- « Authentique » = confirmé par le registre en ligne ; sinon « non confirmé » ou « confirmation indisponible ».

## Mise en place
1. Déployer le projet (avec verification.html).
2. Supabase › SQL Editor : `supabase/migration-v99o-qr-public.sql`.
3. Logiciel › Site vitrine › 5 › « Publier les documents existants ».
4. Regénérer les PDF des certificats/reçus déjà imprimés (anciens QR illisibles).
