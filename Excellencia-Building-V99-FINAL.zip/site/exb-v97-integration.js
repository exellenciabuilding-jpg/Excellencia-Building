/* Excellencia Building V97 — Global integration & health */
(function(w,d){'use strict';
const VERSION='V97-Enterprise';
const flow=['CRM','CONTRAT','PROJET','ETUDE','PLAN/BIM/CDE','DQE/DEVIS','ACHATS','RECEPTION','STOCK','CHANTIER','RH/MATERIEL/SOUS-TRAITANCE','COUTS_REELS','FACTURE','PAIEMENT','COMPTABILITE','REPORTING','CLIENT','IA'];
function status(){const checks={core:!!w.EXB_CORE,formation:!!w.EXB_FORMATION_V95,ai:!!w.EXB_AI_V96,pdf:!!w.EXBPdf,db:!!w.EXBDB,sync:!!(w.exbSync||w.EXBSYNC)};return {version:VERSION,checks,ok:Object.values(checks).every(Boolean),flow:flow.slice(),timestamp:new Date().toISOString()}}
function link(type,id,meta){const row={id:id||('LINK-'+Date.now().toString(36)),type:String(type||''),meta:meta||{},created_at:new Date().toISOString()};try{const key='exb_workflow_links_v97',a=JSON.parse(localStorage.getItem(key)||'[]');a.unshift(row);localStorage.setItem(key,JSON.stringify(a.slice(0,1000)))}catch(e){}try{w.EXB_CORE?.audit?.('WORKFLOW_LINK',row.type,'workflow',row.id)}catch(e){}return row}
function validate(){const s=status();try{w.EXB_CORE?.notify?.(s.ok?'Intégration Enterprise V97 prête':'Intégration V97 incomplète',s.ok?'success':'warn',s)}catch(e){}return s}
function mount(){if(!d.getElementById('exbV97Badge')){const b=d.createElement('div');b.id='exbV97Badge';b.textContent='V97 Enterprise';b.style.cssText='position:fixed;left:10px;bottom:10px;z-index:7000;background:#fff;border:1px solid #d8e0ea;border-radius:999px;padding:5px 9px;font:600 11px Arial;color:#334155;box-shadow:0 2px 10px rgba(0,0,0,.08)';d.body.appendChild(b)}}
w.EXB_V97={version:VERSION,flow,status,link,validate,mount};
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',()=>{mount();setTimeout(validate,0)});else{mount();setTimeout(validate,0)}
})(window,document);
