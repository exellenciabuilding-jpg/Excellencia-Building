# V99r — Copie PDF de l'apprenant + import des questionnaires
- epreuve.html : la feuille/copie n'utilise plus l'impression du navigateur. PDF professionnel (bandeau, informations, consignes, questions numérotées, lignes de réponse, pagination), même charte que les autres documents. Nouveau module : exb-copie-pdf.js.
- Après l'envoi (et via « Voir ma copie ») : bouton « Télécharger ma copie (PDF) » avec réponses, bonnes/mauvaises réponses QCM, explications et score.
- Import des questions (onglet TP/TD/Examens) : PDF, Word (.docx) et TXT lus localement par exb-import-docs.js (fonctionne hors connexion). Un PDF scanné (image) n'a pas de texte : coller le texte à la main.
- sw.js : version du cache incrémentée. Vider le cache / recharger l'app après mise à jour.
- **QR de vérification des copies** : la copie rendue (PDF téléchargé après l'envoi) porte en bas de la dernière page un QR (type « Copie d'épreuve », n° COP-matricule-épreuve) qui ouvre verification.html.
  * Le serveur VÉRIFIE qu'une copie a réellement été remise (table `reponses`) avant d'enregistrer ; numéro, titre, date et nom viennent du serveur.
  * Le nom de l'apprenant est repris du registre (fiche d'inscription, reçu ou certificat du même matricule) et imprimé sur la copie.
  * Le code intègre une empreinte des réponses (imprimée sur la copie et visible sur la page de vérification). La première déclaration fait foi.
  * Limite : le QR atteste la REMISE de la copie, pas la note ; un PDF modifié à la main avec le QR d'origine n'est pas détecté (comparer l'empreinte).
  MISE EN PLACE : Supabase › SQL Editor › exécuter `supabase/migration-v99r-copies-epreuves.sql` (après v99o ; tables epreuves et reponses requises).
- **Feuille de QR par apprenant** (🔳 QR par apprenant) : bouton « Télécharger en PDF » (cartes avec nom, matricule, formation, QR) au lieu de l'impression du navigateur.
