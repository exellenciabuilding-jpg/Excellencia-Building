/* Excellencia Building V81 — Permis de bâtir et autorisations administratives : dossier, pièces à fournir, statut, échéances, alertes.
 * Stockage : exb_permits (collection « autorisations »). Lorsqu'un permis de bâtir est accordé, son numéro est repris dans le cartouche des plans (V80). */
(function(w,d){'use strict';var C=w.EXB81,KEY='exb_permits',COL='autorisations',st={pid:'',id:''};
var TY={
'Permis / autorisation de bâtir':['Titre de propriété ou certificat d’enregistrement','Plan de situation / plan cadastral','Plans architecturaux signés par un architecte agréé','Plans et note de calcul de structure','Étude géotechnique (si exigée)','Quittance des frais et taxes de dossier','Attestation fiscale du demandeur','Pièce d’identité du demandeur'],
'Permis de démolir':['Titre de propriété','Plan de situation','Motif et méthode de démolition','Quittance des frais'],
'Étude / certificat environnemental':['Termes de référence','Rapport d’étude d’impact (ou notice)','Plan de gestion environnementale et sociale','Quittance des frais'],
'Autorisation d’occupation de voirie / domaine public':['Plan d’emprise','Durée et motif de l’occupation','Plan de signalisation et de sécurité','Quittance des redevances'],
'Raccordement eau (distributeur)':['Plan de situation','Estimation des besoins','Demande signée','Quittance'],
'Raccordement électricité (distributeur)':['Plan de situation','Puissance souscrite estimée','Schéma de l’installation','Demande signée','Quittance'],
'Avis sécurité incendie':['Plans de l’ouvrage','Dispositif de sécurité et d’évacuation','Demande signée'],
'Déclaration d’ouverture de chantier':['Copie de l’autorisation de bâtir','Identité de l’entreprise et du maître d’œuvre','Planning prévisionnel'],
'Autre autorisation':[]};
var STS=['à constituer','déposé','en instruction','pièces complémentaires','accordé','refusé','expiré'],INSTR=60,ALERT=60;
function L(){return w.EXBS.get(KEY)}function S(a){return w.EXBS.set(KEY,a)}function canW(){return C.can(COL,'ecrire')}
function flag(x){var o=[];if(x.status==='accordé'&&x.validite){var j=C.daysTo(x.validite);if(j!=null){if(j<0)o.push(['⛔ Autorisation expirée depuis '+(-j)+' j','#fde8e8']);else if(j<=ALERT)o.push(['⏰ Expire dans '+j+' j','#fff7e6'])}}
 if((x.status==='déposé'||x.status==='en instruction'||x.status==='pièces complémentaires')&&x.depot){var j2=-C.daysTo(x.depot);if(j2>INSTR)o.push(['⏳ Instruction : '+j2+' j depuis le dépôt (relancer l’administration)','#fff7e6'])}
 if(x.status==='à constituer'){var m=(x.check||[]).filter(function(c){return!c.done}).length;if(m)o.push(['📎 '+m+' pièce(s) à réunir','#eef2ff'])}return o}
function open(){if(!C.can(COL,'lire'))return C.say('Accès non autorisé.','error');if(!st.pid)st.pid=C.firstProject();list()}
function bannerChantier(){var ph=C.phase(st.pid),ok=L().some(function(x){return String(x.project)===String(st.pid)&&/^Permis/.test(x.type)&&x.status==='accordé'&&(!x.validite||C.daysTo(x.validite)>=0)});
 return(/chantier|DCE|Réception/i.test(ph)&&!ok)?'<div style="background:#fde8e8;padding:8px;border-radius:10px;margin:8px 0">⚠ La phase en cours est « '+C.esc(ph)+' » mais aucun permis de bâtir valide n’est enregistré pour ce projet.</div>':''}
function list(){var A=L().filter(function(x){return String(x.project)===String(st.pid)}),all=L(),nAl=all.reduce(function(a,x){return a+flag(x).filter(function(f){return f[1]!=='#eef2ff'}).length},0);
 var h='<p>'+C.projSelect('EXBPER.proj',st.pid)+(canW()?' <button onclick="EXBPER.neu()">➕ Nouvelle autorisation</button>':'')+'</p>'+bannerChantier()+C.kpis([['Dossiers du projet',A.length],['Accordées',A.filter(function(x){return x.status==='accordé'}).length,'#e6f6ea'],['En cours',A.filter(function(x){return/déposé|instruction|complémentaires/.test(x.status)}).length],['Alertes (tous projets)',nAl,nAl?'#fff7e6':'#f1f5fb']]);
 h+=A.length?A.map(function(x){var fl=flag(x);return '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:9px;margin-bottom:6px"><b>'+C.esc(x.type)+'</b>'+(x.ref?' · n° '+C.esc(x.ref):'')+'<br><small>'+C.esc(x.autorite||'Autorité non renseignée')+' · <b>'+C.esc(x.status)+'</b>'+(x.depot?' · déposé le '+C.frDate(x.depot):'')+(x.validite?' · valable jusqu’au '+C.frDate(x.validite):'')+'</small>'+fl.map(function(f){return '<div style="background:'+f[1]+';padding:4px 8px;border-radius:8px;margin-top:4px;font-size:12px">'+f[0]+'</div>'}).join('')+'<p style="margin:6px 0 0"><button onclick="EXBPER.edit(\''+x.id+'\')">✏️ Ouvrir</button></p></div>'}).join(''):'<p style="color:#64748b">Aucune autorisation enregistrée pour ce projet.</p>';
 C.overlay('exbPer','🏛 Permis & autorisations',h+'<p style="font-size:12px;color:#64748b">Les listes de pièces sont indicatives : adaptez-les aux exigences de votre commune ou administration.</p>',820)}
function edit(id){var x=L().find(function(q){return q.id===id});if(!x)return;st.id=id;var ro=!canW(),dis=ro?' disabled':'';
 var h='<p style="color:#64748b;margin:4px 0">'+C.esc(x.type)+' · '+C.esc(C.pn(x.project))+'</p>'+flag(x).map(function(f){return '<div style="background:'+f[1]+';padding:6px 9px;border-radius:8px;margin-bottom:4px">'+f[0]+'</div>'}).join('')
 +'<div style="display:flex;flex-wrap:wrap;gap:6px">'+C.field('peRe','N° de l’autorisation',x.ref,'',30)+C.field('peAu','Autorité (commune, service…)',x.autorite,'',60)+C.field('peDe','Date de dépôt',x.depot,'date',30)+C.field('peDc','Date de décision',x.decision,'date',30)+C.field('peVa','Valable jusqu’au',x.validite,'date',30)+C.field('peFr','Frais payés ($)',x.frais,'number',30)+'</div>'
 +'<p><select id="peSt" style="padding:7px"'+dis+'>'+STS.map(function(s){return '<option'+(s===x.status?' selected':'')+'>'+s+'</option>'}).join('')+'</select></p>'
 +'<b>Pièces du dossier</b><div>'+(x.check||[]).map(function(c,i){return '<label style="display:block;padding:3px 0"><input type="checkbox" '+(c.done?'checked ':'')+dis+' onchange="EXBPER.chk('+i+',this.checked)"> '+C.esc(c.label)+'</label>'}).join('')+(canW()?'<button onclick="EXBPER.addPiece()" style="margin-top:4px">➕ Pièce</button>':'')+'</div>'
 +'<p><textarea id="peNo" '+(ro?'readonly ':'')+'placeholder="Notes, échanges avec l’administration, observations…" style="width:100%;box-sizing:border-box;min-height:12vh;padding:8px">'+C.esc(x.note||'')+'</textarea></p>'
 +(x.hist&&x.hist.length?'<div style="font-size:12px;color:#64748b">Historique : '+x.hist.map(function(q){return C.frDate(q.d)+' → '+C.esc(q.s)}).join(' · ')+'</div>':'')
 +'<p><button onclick="EXBPER.save()" '+(ro?'disabled ':'')+'style="padding:9px 14px">💾 Enregistrer</button> '+(ro?'':'<button onclick="EXBPER.del()">🗑</button> ')+'<button onclick="EXBPER.back()">← Liste</button></p>';
 C.overlay('exbPer','🏛 '+C.esc(x.type),h,820)}
function A2(f){return function(){if(!canW())return C.say('Écriture non autorisée.','error');return f.apply(null,arguments)}}
function pick(){var k=Object.keys(TY),m=k.map(function(t,i){return(i+1)+'. '+t}).join('\n'),n=parseInt(w.prompt('Type d’autorisation (numéro) :\n'+m,'1'),10);return k[n-1]}
function sync(x){if(/^Permis \/ autorisation de bâtir$/.test(x.type)&&x.status==='accordé'&&x.ref){try{var a=w.EXBS.get('exb_cartouches'),c=a.find(function(q){return String(q.project)===String(x.project)});if(!c){c={id:'CART-'+Date.now().toString(36),project:x.project};a.push(c)}if(c.permis!==x.ref){c.permis=x.ref;w.EXBS.set('exb_cartouches',a)}}catch(e){}}}
w.EXBPER={open:open,back:list,edit:edit,proj:function(v){st.pid=v;list()},
 neu:A2(function(){var t=pick();if(!t)return;var x={id:C.uid('AUT'),project:st.pid,type:t,ref:'',autorite:'',status:'à constituer',depot:'',decision:'',validite:'',frais:'',note:'',check:TY[t].map(function(l){return{label:l,done:false}}),hist:[{d:C.today(),s:'à constituer'}]};var a=L();a.push(x);S(a);edit(x.id)}),
 chk:A2(function(i,v){var a=L(),x=a.find(function(q){return q.id===st.id});if(x&&x.check[i]){x.check[i].done=v;S(a)}}),
 addPiece:A2(function(){var n=w.prompt('Intitulé de la pièce');if(!n)return;var a=L(),x=a.find(function(q){return q.id===st.id});x.check=x.check||[];x.check.push({label:n,done:false});S(a);edit(x.id)}),
 save:A2(function(){var a=L(),x=a.find(function(q){return q.id===st.id});if(!x)return;var ns=C.val('peSt');x.ref=C.val('peRe');x.autorite=C.val('peAu');x.depot=C.val('peDe');x.decision=C.val('peDc');x.validite=C.val('peVa');x.frais=C.val('peFr');x.note=d.getElementById('peNo').value;
  if(ns!==x.status){x.status=ns;(x.hist=x.hist||[]).push({d:C.today(),s:ns});if(ns==='déposé'&&!x.depot)x.depot=C.today();if(/^(accordé|refusé)$/.test(ns)&&!x.decision)x.decision=C.today()}
  S(a);sync(x);C.say('Autorisation enregistrée.');edit(x.id)}),
 del:A2(function(){if(!w.confirm('Supprimer cette autorisation ?'))return;S(L().filter(function(q){return q.id!==st.id}));list()})};
C.addButton('exbPerBtn','🏛 Permis & autorisations',open,COL);
})(window,document);
