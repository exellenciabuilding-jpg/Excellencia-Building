# V99zzzzzzzzzz — TFL : onglet « Signatures », visa automatique, signature de l'étudiant

## Côté administrateur (TFL › ✍️ Signatures)
- Nouvel onglet **Signatures** dans l'espace TFL (à côté de Encadreurs, Portails, Bibliothèque, Sujets) : vous signez au doigt, importez une image de signature, choisissez le cachet (par défaut Excellencia Building, le vôtre ou aucun) et voyez l'aperçu du visa.
- Mêmes réglages que Paramètres › Logo Excellencia Building (une seule signature pour tout le logiciel, gardée sur CET appareil).
- Le visa (signature + cachet) se pose **automatiquement** dans la case « Cachet et visa Excellencia Building » de l'**attestation de dépôt TFL** et de toute fiche éditée par `exb-form.js` sur cet appareil. Sans signature enregistrée : la case garde « À valider par l'administration ».
- Bouton « Voir un exemple d'attestation avec mon visa » pour contrôler le rendu.
- Liste « Signatures des étudiants » (qui a signé, qui non) ; la signature apparaît aussi dans la fiche étudiante du dossier.

## Côté étudiant
- Zone de signature (doigt / souris) ajoutée à `tfl-fiche.html` (Ma fiche étudiante) et `tfl-formulaire.html` (candidature), comme pour les inscriptions. Facultative, recommandée.
- Elle est réduite (≤ 480 px), transmise avec l'envoi en ligne ou le fichier .json, importée dans la fiche de l'étudiant et placée à gauche de l'attestation de dépôt.
- Le PDF de l'étudiant ne reçoit **jamais** le visa de l'administration (`visa:false`) : il reste « À valider par l'administration ».

## Fichiers modifiés
`exb-form.js` (visa auto, paramètre `visa:false`), `exb-tfl.js` (onglet, import, attestation, fiche étudiante), `tfl-fiche.html`, `tfl-formulaire.html`, `sw.js` (cache `exb-v99zzz-tfl-signatures-7`).

## SQL (fichier séparé : `supabase/migration-v99zzzzzzzzzz-tfl-signature.sql`)
À exécuter une fois, après `migration-v99zzz-tfl-sans-limite.sql`. Aucune nouvelle table : les fonctions `tfl_fiche_etudiant_envoyer` et `tfl_candidature_envoyer` gardent la signature (image ≤ 150 000 caractères, format vérifié). Sans ce SQL, l'envoi en ligne marche toujours, mais la signature est ignorée ; l'envoi par fichier la transmet déjà.

## Limites
- Les attestations déjà éditées ne changent pas : régénérez-les après avoir enregistré votre signature.
- Les étudiants déjà importés n'ont pas de signature tant qu'ils n'ont pas renvoyé leur fiche.
- Ouvrir le logiciel deux fois après déploiement (cache PWA).
