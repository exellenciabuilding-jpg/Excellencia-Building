(function(w){'use strict';w.EXB_ARCH={version:'V97-Enterprise',modules:['etudes','plans','bim','cde']};})(window);
