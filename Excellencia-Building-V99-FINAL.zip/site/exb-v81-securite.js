/* Excellencia Building V81 — Sécurité et sauvegardes.
 * · Clé privée administrateur : copie chiffrée (AES-GCM, mot de passe → PBKDF2) à garder HORS de l'appareil.
 * · Sauvegarde complète des données de l'appareil (JSON, chiffrée si un mot de passe est saisi), avec somme de contrôle.
 * · Test de restauration : lit une sauvegarde, vérifie son intégrité et compare avec les données actuelles, SANS rien écrire.
 * · Restauration (après test, avec copie de sécurité automatique et confirmation).
 * · Rappel si la dernière sauvegarde est trop ancienne.
 * · Quota quotidien de l'assistant IA en ligne (confort local ; la vraie limite est appliquée par le serveur : migration-v81-securite.sql). */
(function(w,d){'use strict';
var KP='exb_lic_priv',LB='exb_last_backup',LQ='exb_ai_quota_',ITER=250000;
var subtle=w.crypto&&w.crypto.subtle,enc=new TextEncoder(),dec=new TextDecoder();
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}}
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v)}catch(e){return null}}
function today(){return new Date().toISOString().slice(0,10)}
function b64(buf){var b=new Uint8Array(buf),s='';for(var i=0;i<b.length;i++)s+=String.fromCharCode(b[i]);return btoa(s)}
function unb64(s){var r=atob(s),u=new Uint8Array(r.length);for(var i=0;i<r.length;i++)u[i]=r.charCodeAt(i);return u}
function hex(buf){return Array.prototype.map.call(new Uint8Array(buf),function(x){return('0'+x.toString(16)).slice(-2)}).join('')}
async function derive(pass,salt,iter){var mat=await subtle.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);return subtle.deriveKey({name:'PBKDF2',salt:salt,iterations:iter,hash:'SHA-256'},mat,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
async function seal(text,pass,iter){iter=iter||ITER;var salt=w.crypto.getRandomValues(new Uint8Array(16)),iv=w.crypto.getRandomValues(new Uint8Array(12)),k=await derive(pass,salt,iter),ct=await subtle.encrypt({name:'AES-GCM',iv:iv},k,enc.encode(text));
  return JSON.stringify({exb:'enc',v:1,alg:'AES-GCM/PBKDF2-SHA256',iter:iter,salt:b64(salt),iv:b64(iv),ct:b64(ct)})}
async function unseal(str,pass){var o;try{o=JSON.parse(str)}catch(e){throw new Error('Fichier illisible.')}if(!o||o.exb!=='enc')throw new Error('Ce fichier n’est pas chiffré.');
  try{var k=await derive(pass,unb64(o.salt),o.iter),pt=await subtle.decrypt({name:'AES-GCM',iv:unb64(o.iv)},k,unb64(o.ct));return dec.decode(pt)}catch(e){throw new Error('Mot de passe incorrect ou fichier modifié.')}}
function isEnc(str){try{var o=JSON.parse(str);return !!(o&&o.exb==='enc')}catch(e){return false}}
function saveFile(name,text,type){try{var b=new Blob([text],{type:type||'application/json'}),a=d.createElement('a');a.href=URL.createObjectURL(b);a.download=name;d.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1500);return true}catch(e){return false}}

/* ---------- clé privée administrateur ---------- */
function hasKey(){try{var p=JSON.parse(ls(KP)||'null');return !!(p&&p.d&&p.x)}catch(e){return false}}
async function exportKey(pass){if(!hasKey())throw new Error('Aucune clé administrateur sur cet appareil.');if(String(pass||'').length<10)throw new Error('Mot de passe trop court (10 caractères minimum).');
  return seal(JSON.stringify({exb:'adminkey',at:new Date().toISOString(),key:ls(KP)}),pass)}
async function restoreKey(str,pass){var o=JSON.parse(await unseal(str,pass));if(o.exb!=='adminkey'||!o.key)throw new Error('Ce fichier ne contient pas de clé administrateur.');var old=ls(KP);ls(KP,o.key);
  if(w.EXBLIC&&w.EXBLIC.isAdmin&&!w.EXBLIC.isAdmin()){ls(KP,old);throw new Error('Cette clé n’appartient pas à ce logiciel.')}return true}

/* ---------- sauvegarde complète ---------- */
function collect(store){var s=store||w.exbStorage,o={};if(!s||s.length==null)return o;var ks=[];for(var i=0;i<s.length;i++){var k=s.key(i);if(k)ks.push(k)}ks.sort().forEach(function(k){var v=s.getItem(k);if(v!=null)o[k]=v});return o}
async function sum(keys){return hex(await subtle.digest('SHA-256',enc.encode(JSON.stringify(keys))))}
async function makeBackup(pass,store){var keys=collect(store),p={exb:'backup',v:'V81',app:'Excellencia Building',at:new Date().toISOString(),n:Object.keys(keys).length,sum:await sum(keys),keys:keys},t=JSON.stringify(p);return pass?seal(t,pass):t}
function count(v){try{var x=JSON.parse(v);return Array.isArray(x)?x.length:(x&&typeof x==='object'?Object.keys(x).length:1)}catch(e){return -1}}
async function verify(text,pass,store){var r={ok:false,errors:[],rows:[],at:'',encrypted:false},t=text;
  try{if(isEnc(t)){r.encrypted=true;if(!pass){r.errors.push('Mot de passe requis.');return r}t=await unseal(t,pass)}
    var p=JSON.parse(t);if(!p||p.exb!=='backup'||!p.keys||typeof p.keys!=='object'){r.errors.push('Ce fichier n’est pas une sauvegarde Excellencia.');return r}
    r.at=p.at||'';r.version=p.v||'';
    if(p.sum!==await sum(p.keys))r.errors.push('Somme de contrôle incorrecte : la sauvegarde est altérée ou incomplète.');
    var cur=collect(store);
    Object.keys(p.keys).forEach(function(k){var n=count(p.keys[k]);if(n<0)r.errors.push('Données illisibles : '+k);r.rows.push({key:k,backup:n,current:cur[k]!=null?count(cur[k]):null})});
    r.payload=p;r.ok=r.errors.length===0}catch(e){r.errors.push(e.message||String(e))}
  return r}
function restoreInto(payload,store){var s=store||w.exbStorage,n=0;Object.keys(payload.keys).forEach(function(k){s.setItem(k,payload.keys[k]);n++});return n}
function canRestore(){try{var i=w.EXBDB&&w.EXBDB.info&&w.EXBDB.info();if(i&&i.on&&i.role!=='admin')return false}catch(e){}return true}
function lastBackup(){return ls(LB)||''}
function ageDays(){var l=lastBackup();return l?Math.floor((Date.now()-Date.parse(l))/864e5):null}

/* ---------- quota de l'assistant IA (confort local) ---------- */
function qMax(){var n=Number(ls('exb_ai_max'))||Number(w.EXB_AI_QUOTA)||40;try{if(w.EXBLIC&&w.EXBLIC.isAdmin&&w.EXBLIC.isAdmin())n=Math.max(n,200)}catch(e){}return n}
function quota(){var k=LQ+today(),n=Number(ls(k))||0,mx=qMax();return{n:n,max:mx,ok:n<mx}}
function consume(){var q=quota();if(q.ok)ls(LQ+today(),String(q.n+1));return q}
(function(){var of=w.fetch;if(typeof of!=='function'||of.__exbq)return;
  w.fetch=function(u){try{var url=String(u&&u.url||u);if(url.indexOf('/functions/v1/assistant')>=0){var q=consume();if(!q.ok)return Promise.resolve(new Response(JSON.stringify({error:'Quota quotidien de l’assistant atteint ('+q.max+' demandes). Réessayez demain : l’assistant local reste disponible.'}),{status:429,headers:{'Content-Type':'application/json'}}))}}catch(e){}return of.apply(this,arguments)};w.fetch.__exbq=1})();

/* ---------- écrans ---------- */
var last=null;
function open(){draw()}
function draw(){var o=d.getElementById('exbSec');if(!o){o=d.createElement('div');o.id='exbSec';o.style.cssText='position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';o.onclick=function(e){if(e.target===o)o.remove()};d.body.appendChild(o)}
  var a=ageDays(),q=quota(),inp='padding:8px;width:100%;box-sizing:border-box;margin:3px 0',bt='padding:9px 12px;margin:3px 3px 3px 0';
  o.innerHTML='<div style="background:#fff;border-radius:14px;padding:16px;max-width:720px;width:100%;font:14px Arial;color:#172033"><div style="display:flex;justify-content:space-between"><b style="font-size:17px">🛡 Sécurité et sauvegardes</b><button onclick="document.getElementById(\'exbSec\').remove()">✕</button></div>'
   +'<h3 style="margin:12px 0 4px">1. Sauvegarde complète</h3><p style="font-size:12px;color:#64748b">Dernière sauvegarde : <b>'+(a==null?'jamais':(a===0?'aujourd’hui':'il y a '+a+' j'))+'</b>. Gardez le fichier hors de l’appareil (e-mail à vous-même, clé USB, autre cloud).</p>'
   +'<input id="secBp" type="password" placeholder="Mot de passe de chiffrement (facultatif, conseillé)" style="'+inp+'"><button style="'+bt+'" onclick="EXBSEC.backup()">⬇ Sauvegarder maintenant</button>'
   +'<h3 style="margin:12px 0 4px">2. Tester une sauvegarde (rien n’est modifié)</h3><input id="secTf" type="file" accept=".json,.exbbak" style="'+inp+'"><input id="secTp" type="password" placeholder="Mot de passe (si chiffrée)" style="'+inp+'"><button style="'+bt+'" onclick="EXBSEC.test()">🔍 Vérifier</button><div id="secRes"></div>'
   +(hasKey()?'<h3 style="margin:12px 0 4px">3. Clé privée administrateur</h3><p style="font-size:12px;color:#64748b">Sans cette clé vous ne pouvez plus signer de licences. Exportez-la chiffrée et gardez-la hors de cet appareil.</p><input id="secKp" type="password" placeholder="Mot de passe (10 caractères minimum)" style="'+inp+'"><button style="'+bt+'" onclick="EXBSEC.key()">🔑 Exporter la clé (chiffrée)</button>':'')
   +'<h3 style="margin:12px 0 4px">'+(hasKey()?'4':'3')+'. Retrouver la clé sur un autre appareil</h3><input id="secKf" type="file" accept=".exbkey,.json" style="'+inp+'"><input id="secKq" type="password" placeholder="Mot de passe de la clé" style="'+inp+'"><button style="'+bt+'" onclick="EXBSEC.keyRestore()">♻ Restaurer la clé</button>'
   +'<h3 style="margin:12px 0 4px">Assistant IA</h3><p style="font-size:13px">Aujourd’hui sur cet appareil : <b>'+q.n+' / '+q.max+'</b> demandes. La limite réelle est appliquée par le serveur (voir migration-v81-securite.sql).</p></div>'}
function val(i){var e=d.getElementById(i);return e?e.value:''}
function file(i){var e=d.getElementById(i);return e&&e.files&&e.files[0]}
async function backup(){try{var p=val('secBp'),t=await makeBackup(p),name=(p?'SAUVEGARDE-EXB-CHIFFREE-':'SAUVEGARDE-EXB-')+today()+(p?'.exbbak':'.json');if(!saveFile(name,t))return say('Téléchargement impossible sur cet appareil.','error');ls(LB,new Date().toISOString());say('Sauvegarde téléchargée.');draw()}catch(e){say(e.message||String(e),'error')}}
async function test(){var f=file('secTf'),o=d.getElementById('secRes');if(!f)return say('Choisissez un fichier.','warn');
  try{var t=await f.text(),r=await verify(t,val('secTp'));last=r.ok?{r:r}:null;
    o.innerHTML=(r.ok?'<p style="color:#15803d"><b>✅ Sauvegarde valide</b> du '+esc((r.at||'').slice(0,16).replace('T',' '))+' — '+r.rows.length+' jeux de données. Aucune donnée n’a été modifiée.</p>':'<p style="color:#b91c1c"><b>⛔ Sauvegarde non valide</b><br>'+r.errors.map(esc).join('<br>')+'</p>')
     +(r.rows.length?'<div style="max-height:220px;overflow:auto"><table style="border-collapse:collapse;font-size:12px;width:100%"><tr style="background:#f1f5f9"><th style="border:1px solid #e2e8f0;padding:3px;text-align:left">Données</th><th style="border:1px solid #e2e8f0;padding:3px">Sauvegarde</th><th style="border:1px solid #e2e8f0;padding:3px">Actuel</th></tr>'+r.rows.map(function(x){return'<tr><td style="border:1px solid #e2e8f0;padding:3px">'+esc(x.key)+'</td><td style="border:1px solid #e2e8f0;padding:3px;text-align:center">'+x.backup+'</td><td style="border:1px solid #e2e8f0;padding:3px;text-align:center">'+(x.current==null?'—':x.current)+'</td></tr>'}).join('')+'</table></div>':'')
     +(r.ok?(canRestore()?'<p><button style="padding:9px 12px;background:#b91c1c;color:#fff;border:0;border-radius:8px" onclick="EXBSEC.restore()">⚠ Restaurer sur cet appareil</button></p><p style="font-size:12px;color:#64748b">Remplace les données de cet appareil. Une copie de sécurité est téléchargée avant.</p>':'<p style="color:#b45309">Restauration réservée à l’administrateur de la base partagée.</p>'):'')}
  catch(e){o.innerHTML='<p style="color:#b91c1c">'+esc(e.message||String(e))+'</p>'}}
async function restore(){if(!last||!last.r.ok)return say('Testez d’abord une sauvegarde.','warn');if(!canRestore())return say('Restauration réservée à l’administrateur.','error');
  if(!w.confirm('Remplacer les données de cet appareil par la sauvegarde du '+(last.r.at||'').slice(0,10)+' ? Une copie de sécurité va d’abord être téléchargée.'))return;
  try{var snap=await makeBackup('');if(!saveFile('AVANT-RESTAURATION-EXB-'+today()+'.json',snap))return say('Copie de sécurité impossible : restauration annulée.','error');
    var n=restoreInto(last.r.payload);say(n+' jeux de données restaurés. Rechargez la page.');last=null;try{w.setTimeout(function(){w.location.reload()},1500)}catch(e){}}catch(e){say(e.message||String(e),'error')}}
async function key(){try{var t=await exportKey(val('secKp'));if(!saveFile('CLE-ADMIN-CHIFFREE-'+today()+'.exbkey',t))return say('Téléchargement impossible.','error');say('Clé chiffrée téléchargée. Gardez-la hors de cet appareil.')}catch(e){say(e.message||String(e),'error')}}
async function keyRestore(){var f=file('secKf');if(!f)return say('Choisissez le fichier .exbkey.','warn');try{await restoreKey(await f.text(),val('secKq'));say('Clé administrateur restaurée sur cet appareil.');draw()}catch(e){say(e.message||String(e),'error')}}

/* ---------- rappel de sauvegarde ---------- */
function reminder(){try{if(w.sessionStorage&&w.sessionStorage.getItem('exb_bk_seen'))return;var days=Number(ls('exb_backup_days'))||7,a=ageDays();
  var has=(function(){try{return (w.EXBS.get('exb_projects').length+w.EXBS.get('exb_clients').length)>0}catch(e){return false}})();if(!has||(a!=null&&a<days))return;
  if(w.sessionStorage)w.sessionStorage.setItem('exb_bk_seen','1');if(d.getElementById('exbBkBar'))return;var b=d.createElement('div');b.id='exbBkBar';b.style.cssText='position:fixed;top:0;left:0;right:0;z-index:99997;background:#fef3c7;color:#78350f;padding:8px 12px;font:13px Arial;text-align:center;box-shadow:0 2px 6px #0003';
  b.innerHTML='💾 '+(a==null?'Aucune sauvegarde enregistrée.':'Dernière sauvegarde il y a '+a+' jours.')+' <button onclick="EXBSEC.open();this.parentNode.remove()" style="padding:4px 8px">Sauvegarder</button> <button onclick="this.parentNode.remove()" style="padding:4px 8px">✕</button>';d.body.appendChild(b)}catch(e){}}

w.EXBSEC={open:open,backup:backup,test:test,restore:restore,key:key,keyRestore:keyRestore,quota:quota,
  _seal:seal,_unseal:unseal,_exportKey:exportKey,_restoreKey:restoreKey,_collect:collect,_makeBackup:makeBackup,_verify:verify,_restoreInto:restoreInto,_consume:consume,_ageDays:ageDays,_canRestore:canRestore};
function ui(){var b=d.getElementById('badm');if(!b||d.getElementById('exbSecBtn'))return;var k=d.createElement('button');k.id='exbSecBtn';k.className='muted';k.textContent='🛡 Sécurité & sauvegardes';k.onclick=open;b.parentNode.appendChild(k)}
if(typeof MutationObserver!=='undefined')new MutationObserver(ui).observe(d.documentElement,{childList:true,subtree:true});
d.addEventListener('DOMContentLoaded',function(){ui();try{w.setTimeout(reminder,4000)}catch(e){}});
})(window,document);
