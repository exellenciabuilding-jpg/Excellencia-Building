/* Excellencia Building — Convertisseur de plans PDF (Architecture › Plan PDF → plan modifiable).
 * Affiche plan-editeur/import-pdf.html dans la page, à côté de « Plan de maison ». Le plan converti est transmis à l'éditeur
 * (EXBPLANED) : il s'ouvre directement, avec le PDF en fond calé à l'échelle. Aucune fonction existante n'est modifiée.
 * Pour retirer le module : supprimer la balise <script src="exb-import-plan-pdf.js"> de index.html. */
(function(w,d){'use strict';
var URL_IMP='plan-editeur/import-pdf.html',URL_ED='plan-editeur/index.html';
var $=function(i){return d.getElementById(i)};
function css(){if($('exbImpPdfCss'))return;var s=d.createElement('style');s.id='exbImpPdfCss';
 s.textContent='#planPdf .pe-wrap{border:1px solid #d5dbe5;border-radius:14px;overflow:hidden;background:#f4f6fb;box-shadow:0 6px 24px #0f2e6618}'
 +'#planPdf iframe{display:block;width:100%;height:calc(100vh - 150px);min-height:560px;border:0;background:#fff}'
 +'#planPdf .pe-note{margin:10px auto 0;font-size:12px;color:#6b7a99;text-align:center}'
 +'@media(max-width:700px){#planPdf iframe{height:calc(100vh - 130px);min-height:520px}}';d.head.appendChild(s)}
function build(){var sec=d.createElement('section');sec.id='planPdf';sec.style.display='none';
 sec.innerHTML='<div class="card"><h2>📄 Plan PDF → plan modifiable</h2><div class="pe-wrap"><iframe id="exbImpPdfFrame" title="Convertisseur de plans PDF" loading="lazy"></iframe></div>'
 +'<p class="pe-note">La détection des murs est indicative : à vérifier et compléter dans l’éditeur de plan avant tout chiffrage.</p></div>';return sec}
function mount(){if($('planPdf'))return;
 var ref=$('planEditeur')||$('calcStructure')||$('metreDevis')||$('projets'),host=d.querySelector('.wrap')||d.querySelector('main')||d.body,sec=build();css();
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(sec,ref.nextSibling);else host.appendChild(sec);
 var anchor=$('bplanedit')||$('bbet')||$('bdev'),par=anchor&&anchor.parentNode;
 if(par&&!$('bplanpdf')){var b=d.createElement('button');b.id='bplanpdf';b.type='button';b.textContent='📄 Plan PDF → éditeur';b.setAttribute('onclick',"show('planPdf')");par.insertBefore(b,anchor.nextSibling)}
 var os=w.show;
 if(typeof os==='function'&&!w.__exbImpPdfShow){w.__exbImpPdfShow=1;
  w.show=function(x){var r=os.apply(this,arguments),e=$('planPdf');
   if(e){e.style.display=(x==='planPdf')?'':'none';
    if(x==='planPdf'){var f=$('exbImpPdfFrame');if(f&&!f.getAttribute('src'))f.setAttribute('src',URL_IMP)}}
   var b2=$('bplanpdf');if(b2)b2.classList.toggle('active',x==='planPdf');return r}}}
function open(){if(!$('planPdf'))mount();if(typeof w.show==='function')w.show('planPdf');try{w.scrollTo(0,0)}catch(e){}}
/* plan converti → éditeur : transmis par le stockage commun, l'éditeur est rechargé pour le lire au démarrage */
function toEditor(plan){try{localStorage.setItem('exbPlanEd.handoff',JSON.stringify(plan))}catch(e){alert('Plan trop volumineux pour être transmis : utilisez « Télécharger le JSON » puis « Importer » dans l’éditeur.');return}
 if(!$('planEditeur')&&w.EXBPLANED)w.EXBPLANED.open();
 var f=$('exbPlanEdFrame');if(f)f.setAttribute('src',URL_ED+'?t='+Date.now());
 if(w.EXBPLANED)w.EXBPLANED.open();else if(typeof w.show==='function')w.show('planEditeur')}
w.EXBIMPPDF={open:open,toEditor:toEditor,version:'V99zzzzzzzzzzzzzzzzzzzzzz'};
function start(){setTimeout(mount,1000)}
if(d.readyState==='complete')start();else w.addEventListener('load',start);
})(window,document);
