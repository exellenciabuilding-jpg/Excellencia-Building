/* V244 — Sécurisation serveur (étape 3) : contrôle statique de migration-v244-securisation-ecriture.sql. Lancer : node tools/test-v244-securisation.js
 * Limite : relecture du texte SQL seulement (aucun serveur Postgres ici). Le vrai contrôle : exécuter le fichier sur la copie de recette et lire la section 4 (S3, S4, S4b, S4c, S11). */
const fs = require('fs'), path = require('path');
const sql = fs.readFileSync(path.join(__dirname, '..', 'supabase', 'migration-v244-securisation-ecriture.sql'), 'utf8');
const code = sql.replace(/--.*$/mg, '');
let ko = 0, n = 0; function t(nom, ok) { n++; if (!ok) ko++; console.log((ok ? '  OK   ' : '  FAIL ') + nom); }
t('aperçu par défaut : confirmer = NON, application seulement si OUI', /set_config\('exb\.confirmer', 'NON'/.test(code) && /<> 'OUI'/.test(code) && /return;/.test(code));
t('garde-fou : enregistrer() doit être SECURITY DEFINER sinon exception', /prosecdef/.test(code) && /raise exception 'V244 : enregistrer\(\) n''est pas SECURITY DEFINER/.test(code));
t('garde-fou : la lecture enr_lire (peut()) doit exister', /policyname = 'enr_lire' and qual ilike '%peut\(%'/.test(code) && /raise exception 'V244 : la politique de lecture/.test(code));
t('ne supprime que les politiques INSERT/UPDATE/DELETE/ALL (jamais SELECT)', /cmd in \('INSERT', 'UPDATE', 'DELETE', 'ALL'\) loop/.test(code) && !/cmd = 'SELECT'[^;]*drop|drop policy[^;]*enr_lire/i.test(code));
t('sauvegarde des politiques avant toute suppression, protégée par RLS', /create table if not exists politiques_sauv_v244/.test(code) && /politiques_sauv_v244 enable row level security/.test(code) && code.indexOf('politiques_sauv_v244(') < code.indexOf('drop policy'));
t('retire les privilèges d’écriture directe pour anon / authenticated seulement', /revoke insert, update, delete, truncate on public\.enregistrements from anon, authenticated/.test(code) && !/service_role/.test(code.split('revoke')[1].split(';')[0]));
t('retour arrière documenté (grant + recréation des politiques)', /grant insert, update, delete on public\.enregistrements to authenticated/.test(sql) && /create policy %I on public\.enregistrements/.test(sql));
t('re-contrôle S3, S4, S4b, S4c, S11 en fin de fichier', ['S3', 'S4', 'S4b', 'S4c', 'S11'].every(s => new RegExp("\\('" + s + "'").test(code)));
t('ne touche ni « polyvalent », ni les lecteurs, ni droits_fonction, ne crée aucune fonction', !/'polyvalent'|'lecteur'/.test(code.split('-- 4')[0]) && !/(update|delete from|insert into) droits_fonction/i.test(code) && !/create (or replace )?function/i.test(code));
console.log('\n' + (ko ? ko + ' échec(s) sur ' + n : 'Tout est réussi (' + n + ' contrôles)')); process.exit(ko ? 1 : 0);
