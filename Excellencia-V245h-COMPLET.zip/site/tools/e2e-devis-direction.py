# V237g — devis, clients et bons de commande réservés à la Direction (retirés du comptable)
import http.server, threading, functools, os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
VIS = "(id)=>{const e=document.getElementById(id);return !!e&&e.getClientRects().length>0}"
OPT = "[...document.querySelectorAll('#lvType option')].filter(o=>!o.disabled).map(o=>o.value).join()"
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    def boot(url):
        pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page()
        pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")
        pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
        pg.goto(BASE + url); pg.wait_for_timeout(4500)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
        pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(900)
        return pg
    menu = lambda pg: pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent).join(' | ')")
    # --- comptable
    pg = boot('comptable.html'); m = menu(pg)
    t('Clients' not in m and 'devis' not in m.lower(), 'Comptable : menu sans Clients ni Métré & devis (%s)' % m)
    t('Reçus de paiement' in m and 'Comptabilité' in m, 'Comptable : reçus et comptabilité conservés')
    home = pg.evaluate("document.getElementById('exbHome').innerText")
    t('Nouveau devis' not in home and 'Nouveau client' not in home, 'Comptable : accueil sans action devis / client')
    for k in ('clients', 'metreDevis'):
        pg.evaluate("show('%s')" % k); pg.wait_for_timeout(400)
        t(not pg.evaluate(VIS, k), 'Comptable : accès direct à « %s » refusé' % k)
    pg.evaluate("show('receipts')"); pg.wait_for_timeout(800)
    t(pg.evaluate(OPT) == 'livraison', 'Comptable : seul le bon de livraison est proposé')
    t('commande' not in pg.evaluate("document.getElementById('exbLivCard').innerText").lower(), 'Comptable : carte sans mention du bon de commande')
    pg.evaluate("EXBFIN.open()"); pg.wait_for_timeout(500)
    t('Nouveau devis' not in pg.evaluate("(document.getElementById('exbFin')||{}).innerText||''"), 'Comptable : Finance USD/FC sans « Nouveau devis »')
    pg.evaluate("EXBFIN.form('devis')"); t(not pg.evaluate("!!document.getElementById('exbFinF')"), 'Comptable : création de devis refusée')
    # --- compte de fonction comptable hors espace
    pg = boot('index.html')
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    pg.evaluate("show('clients')"); pg.wait_for_timeout(400)
    t(not pg.evaluate(VIS, 'clients'), 'Compte comptable hors espace : Clients refusé')
    t(pg.evaluate("!EXB_SHELL.espaceHas('clients')&&!EXB_SHELL.espaceHas('metreDevis')"), 'Compte comptable hors espace : absents du menu')
    # --- direction
    # V245 (partage V241) : Clients et Métré & devis s'ouvrent dans l'Espace Commercial, accessible à la Direction
    pg = boot('commercial.html'); m = menu(pg)
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'direction',label:'Direction'})")
    t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Direction : accès à l\'Espace Commercial')
    t('Clients' in m and 'devis' in m.lower(), 'Espace Commercial : Clients et Métré & devis présents')
    for k in ('clients', 'metreDevis'):
        pg.evaluate("show('%s')" % k); pg.wait_for_timeout(600)
        t(pg.evaluate(VIS, k), 'Direction : « %s » s\'ouvre' % k)
    pg.evaluate("window.EXBDB.info=()=>({on:true,role:'editeur',fonction:'comptable',label:'Comptable'})")
    t(not pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Comptable : refusé dans l\'Espace Commercial')
    pg = boot('direction.html')
    pg.evaluate("show('direction')"); pg.wait_for_timeout(900)
    t(pg.evaluate(VIS, 'exbLivCard') and pg.evaluate(OPT) == 'commande', 'Direction : carte « Bons de commande » visible')
    pg.fill('#lvEnt', 'Fournisseur Test'); pg.fill('.lv-des', 'Ciment'); pg.fill('.lv-qte', '10'); pg.fill('.lv-pu', '12'); pg.click('#lvGo'); pg.wait_for_timeout(6000)
    bn = pg.evaluate("document.getElementById('lvBanner').innerText")
    t('BC' in bn, 'Direction : bon de commande créé (%s)' % bn)
    pg.screenshot(path='/tmp/dir.png', full_page=False)
    pg.evaluate("EXBFIN.open();EXBFIN.form('devis')"); t(pg.evaluate("!!document.getElementById('exbFinF')"), 'Direction : peut créer un devis Finance')
    # --- hors espace, administrateur : inchangé
    pg = boot('index.html'); pg.evaluate("show('receipts')"); pg.wait_for_timeout(800)
    t(pg.evaluate(OPT) == 'livraison,commande', 'Administrateur : les deux types de bons restent disponibles')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
