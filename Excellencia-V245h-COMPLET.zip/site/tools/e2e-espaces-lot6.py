# V205 lot 6 — Espaces Chantier, Direction (+Commercial), Administration (+RH)
import http.server, threading, functools, os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")  # V205l : ces tests pilotent l'appli sans passer par l'écran de connexion d'espace
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    def boot(url):
        pg.goto(BASE + url); pg.wait_for_timeout(4000)
        pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    def menu():
        pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(500)
        return ' | '.join(pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent)"))
    def who(f, role='editeur'):
        pg.evaluate("window.EXBDB.info=()=>({on:true,role:'%s',fonction:'%s',label:'%s'})" % (role, f, f))
    # ---- Chantier
    boot('chantier.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'chantier', '/chantier ouvre l\'Espace Chantier')
    m = menu()
    t(all(k in m for k in ['Projets & chantiers', 'Planning & budget', 'Contrôles & sécurité', 'Réception de chantier', 'Stock']), 'Chantier : projets, planning, contrôles, réception, stock')
    t(not any(k in m for k in ['Personnel', 'Paie', 'Finances', 'Comptabilité', 'Clients', 'Apprenants', 'Reçus']), 'Chantier : ni RH, ni paie, ni finances, ni clients, ni formation')
    who('conducteur'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Chantier : un conducteur est accepté')
    who('chef_projet'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Chantier : un chef de projet est accepté')
    who('rh'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Chantier : un RH est refusé')
    who('admin', 'admin'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Chantier : l\'administrateur est accepté')
    # ---- Direction + Commercial
    boot('direction.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'direction', '/direction ouvre l\'Espace Direction')
    m = menu()
    t(all(k in m for k in ['BI Direction', 'Workflow', 'Enterprise 360', 'Supervision', 'Journal d’audit', 'Registre & sauvegarde', 'Paramètres']), 'Direction (V241) : pilotage, workflow, supervision, audit, sauvegardes, paramètres')
    t(not any(k in m for k in ['Personnel', 'Paie', 'Planning & budget', 'Stock', 'Reçus', 'Apprenants', 'Clients', 'CRM']), 'Direction (V241) : ni RH/paie, ni chantier, ni stock, ni formation, ni clients/CRM (Espace Commercial)')
    who('direction'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Direction : la direction est acceptée')
    who('comptable'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Direction : un comptable est refusé')
    # ---- Administration + RH
    boot('administration.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'administration', '/administration ouvre l\'Espace Administration')
    m = menu()
    t(all(k in m for k in ['Personnel & RH', 'Paie & RH', 'Congés']), 'Espace RH (V241) : personnel, paie, congés')
    who('rh'); m = menu()
    t('Personnel & RH' in m and 'Paie & RH' in m and 'Documents' in m, 'Espace RH : le RH voit Personnel, Paie, Documents')
    t(not any(k in m for k in ['Journal d’audit', 'Registre', 'Synchronisation', 'Scanner', 'Base partagée']), 'Espace RH : le RH ne voit NI audit, NI sauvegardes, NI synchronisation (Paramètres = réglages personnels, comme dans les autres espaces)')
    who('direction'); m = menu()
    t('Personnel & RH' in m, 'Espace RH : la direction y a accès')
    who('magasinier'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Administration : un magasinier est refusé')
    # ---- Commercial (V241)
    boot('commercial.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'commercial', '/commercial ouvre l\'Espace Commercial')
    m = menu()
    t(all(k in m for k in ['Clients', 'CRM', 'Métré & devis', 'Portails', 'Site vitrine']), 'Commercial : clients, CRM, devis, portails, site vitrine')
    t(not any(k in m for k in ['Finances', 'Paie', 'Personnel', 'Stock', 'Projets & chantiers', 'Apprenants', 'Reçus']), 'Commercial : ni finances, ni RH, ni stock, ni chantier, ni formation')
    who('direction'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Commercial : la direction est acceptée')
    who('magasinier'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Commercial : un magasinier est refusé')
    # ---- Achats (V241)
    boot('achats.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'achats', '/achats ouvre l\'Espace Achats')
    m = menu()
    t(all(k in m for k in ['Terrain & achats', 'Fournisseurs & dettes', 'Stock & matériaux']), 'Achats : demandes terrain, fournisseurs, stock')
    t(not any(k in m for k in ['Finances', 'Paie', 'Personnel', 'Clients', 'Apprenants', 'Reçus', 'Projets & chantiers']), 'Achats : ni finances, ni RH, ni clients, ni formation, ni chantier')
    who('magasinier'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Achats : un magasinier est accepté')
    who('comptable'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Achats : un comptable est refusé')
    # ---- Magasin
    boot('magasin.html')
    t(pg.evaluate("EXB_SHELL.espace()") == 'magasin', '/magasin ouvre l\'Espace Magasin')
    m = menu()
    t(all(k in m for k in ['Stock & matériaux', 'Stock : dépôts, inventaires', 'Terrain & achats', 'Documents']), 'Magasin : stock, dépôts/inventaires, achats, documents')
    t(not any(k in m for k in ['Finances', 'Personnel', 'Paie', 'Projets & chantiers', 'Clients', 'Apprenants', 'Reçus']), 'Magasin : ni finances, ni RH, ni projets, ni clients, ni formation')
    who('magasinier'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok"), 'Magasin : un magasinier est accepté')
    who('comptable'); t(pg.evaluate("EXB_SHELL.espaceAcces().ok") is False, 'Magasin : un comptable est refusé')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
