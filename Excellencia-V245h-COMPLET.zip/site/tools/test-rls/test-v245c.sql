-- V245c — périmètre : noms réels des champs, fiche parente, affectation par nom ou identifiant. Lancer après run-complet.sh + migration-v245c.
\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000c1','a@c'),('00000000-0000-0000-0000-0000000000c2','n@c'),('00000000-0000-0000-0000-0000000000c3','i@c'),('00000000-0000-0000-0000-0000000000c4','z@c') on conflict do nothing;
select set_config('app.uid','00000000-0000-0000-0000-0000000000c1',false) \gset x_
select (creer_organisation('Org245c','Adm')::jsonb->>'id') as o \gset
insert into membres(org_id,user_id,role,fonction) values (:'o','00000000-0000-0000-0000-0000000000c2','editeur','conducteur'),(:'o','00000000-0000-0000-0000-0000000000c3','editeur','chef_projet'),(:'o','00000000-0000-0000-0000-0000000000c4','editeur','conducteur');
insert into enregistrements(org_id,collection,id,data,version) values
 (:'o','projets','P1','{"name":"Villa Alpha"}',1),(:'o','projets','P2','{"name":"Immeuble Beta"}',1),
 (:'o','v93_projets','V1','{"name":"Alpha BTP","core_project_id":"P1"}',1),
 (:'o','planning_chantier','G1','{"project_id":"P1"}',1),(:'o','planning_chantier','G2','{"project_id":"P2"}',1),(:'o','planning_chantier','G0','{}',1),
 (:'o','plans_v94','D1','{"project_id":"P1"}',1),(:'o','plans_v94','D2','{"project_id":"P2"}',1),
 (:'o','revisions_plans_v94','R1','{"drawing_id":"D1"}',1),(:'o','revisions_plans_v94','R2','{"drawing_id":"D2"}',1),
 (:'o','v93_chantiers','S1','{"project_id":"V1"}',1),(:'o','v93_chantiers','S2','{"project_id":"P2"}',1),
 (:'o','v93_taches','K1','{"site_id":"S1"}',1),(:'o','v93_taches','K2','{"site_id":"S2"}',1),
 (:'o','bons_paiement','B1','{"projet":"Villa Alpha","projetId":"P1"}',1);
insert into affectations_projets(org_id,projet,user_id,actif) values (:'o','Villa Alpha','00000000-0000-0000-0000-0000000000c2',true),(:'o','P2','00000000-0000-0000-0000-0000000000c3',true);
select perimetre_projet_definir(:'o',true) \gset x_
create or replace function vu(p_uid text, p_org uuid) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.uid',p_uid,false); perform set_config('app.role','authenticated',false); perform set_config('app.aal','aal1',false);
  execute 'set local role authenticated';
  select string_agg(id, ',' order by id) into r from enregistrements where org_id=p_org and collection in ('planning_chantier','plans_v94','revisions_plans_v94','v93_chantiers','v93_taches','bons_paiement','projets');
  reset role; return coalesce(r,'(rien)'); end $$;
select 'nom → identifiant (conducteur affecté à « Villa Alpha ») : ' || r || ' | attendu B1,D1,G0,G1,K1,P1,R1,S1 : ' || case when r='B1,D1,G0,G1,K1,P1,R1,S1' then 'OK' else 'ECHEC' end from (select vu('00000000-0000-0000-0000-0000000000c2', :'o') r) q;
select 'identifiant P2 (chef de projet ; bons_paiement selon ses droits) : ' || r || ' : ' || case when regexp_replace(r,'B\d,?','','g')='D2,G0,G2,K2,P2,R2,S2' then 'OK' else 'ECHEC' end from (select vu('00000000-0000-0000-0000-0000000000c3', :'o') r) q;
select 'sans affectation : ' || r || ' | attendu G0 : ' || case when r='G0' then 'OK' else 'ECHEC' end from (select vu('00000000-0000-0000-0000-0000000000c4', :'o') r) q;
select set_config('app.uid','00000000-0000-0000-0000-0000000000c1',false) \gset x_
select 'diagnostic : non classées hors fiche vide = ' || s || ' : ' || case when s=1 then 'OK' else 'ECHEC' end
  from (select sum((c->>'non_classees')::int) s from json_array_elements(perimetre_diagnostic(:'o')->'collections') c) q;
