-- V245 — Tests de COMPORTEMENT sur PostgreSQL (imitation de Supabase) : fonctions commercial/achats, droit d'export serveur, périmètre par projet,
-- séparation préparateur/encaisseur. Lancé par run-complet.sh APRÈS toutes les migrations (dont migration-v245). Chaque ligne : attendu | obtenu | OK / ECHEC.
\set ON_ERROR_STOP off
\pset tuples_only on
\pset format unaligned
create temp table res(n text, attendu text, obtenu text);
grant all on res to public;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000b1','adm@x'),('00000000-0000-0000-0000-0000000000b2','cond1@x'),('00000000-0000-0000-0000-0000000000b3','cond2@x'),
 ('00000000-0000-0000-0000-0000000000b4','compta@x'),('00000000-0000-0000-0000-0000000000b5','com@x'),('00000000-0000-0000-0000-0000000000b6','ach@x'),
 ('00000000-0000-0000-0000-0000000000b7','lect@x'),('00000000-0000-0000-0000-0000000000b8','poly@x'),('00000000-0000-0000-0000-0000000000b9','dir@x'),
 ('00000000-0000-0000-0000-0000000000ba','autre@x') on conflict do nothing;
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (creer_organisation('Org245','Adm')::jsonb->>'id') as o \gset
select set_config('app.uid','00000000-0000-0000-0000-0000000000ba',false);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (creer_organisation('OrgAutre','Autre')::jsonb->>'id') as oa \gset
insert into membres(org_id,user_id,role,fonction) values
 (:'o','00000000-0000-0000-0000-0000000000b2','editeur','conducteur'),
 (:'o','00000000-0000-0000-0000-0000000000b3','editeur','conducteur'),
 (:'o','00000000-0000-0000-0000-0000000000b4','editeur','comptable'),
 (:'o','00000000-0000-0000-0000-0000000000b5','editeur','commercial'),
 (:'o','00000000-0000-0000-0000-0000000000b6','editeur','achats'),
 (:'o','00000000-0000-0000-0000-0000000000b7','lecteur','comptable'),
 (:'o','00000000-0000-0000-0000-0000000000b8','editeur','polyvalent'),
 (:'o','00000000-0000-0000-0000-0000000000b9','editeur','direction');

-- jeu de fiches (insérées par le propriétaire de la base, hors API)
insert into enregistrements(org_id,collection,id,data,version) values
 (:'o','projets','P1','{"nom":"Villa Alpha"}',1),(:'o','projets','P2','{"nom":"Immeuble Beta"}',1),
 (:'o','planning_chantier','T1','{"projet":"P1","t":"coffrage"}',1),(:'o','planning_chantier','T2','{"projet":"P2","t":"fondations"}',1),
 (:'o','planning_chantier','T3','{"t":"sans projet"}',1),
 (:'o','caisse','C1','{"m":100}',1),(:'o','paie','PA1','{"m":1}',1);

create or replace function essai(p_uid text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.uid',coalesce(p_uid,''),false); perform set_config('app.role','authenticated',false); perform set_config('app.aal','aal1',false);
  execute 'set local role authenticated';
  begin execute p_sql into r; exception when others then r:='ERREUR:'||left(sqlerrm,80); end;
  reset role; return coalesce(r,'(null)'); end $$;
\set U '00000000-0000-0000-0000-0000000000'

-- ---------- 1. Fonctions commercial / achats ----------
insert into res select 'F1 commercial écrit un client', 'true', essai(:'U'||'b5', $q$select (enregistrer('$q$||:'o'||$q$','clients','K1','{"nom":"Client"}',0))::jsonb->>'ok'$q$);
insert into res select 'F2 commercial ne lit pas la caisse', '0', essai(:'U'||'b5', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='caisse'$q$);
insert into res select 'F3 commercial ne peut pas écrire un paiement', 'false', essai(:'U'||'b5', $q$select (enregistrer('$q$||:'o'||$q$','paiements','X1','{}',0))::jsonb->>'ok'$q$);
insert into res select 'F4 achats crée une demande d''achat', 'true', essai(:'U'||'b6', $q$select (enregistrer('$q$||:'o'||$q$','v92_demandes_achat','D1','{"a":1}',0))::jsonb->>'ok'$q$);
insert into res select 'F5 achats ne lit ni la paie ni la caisse', '0', essai(:'U'||'b6', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection in ('paie','caisse')$q$);
insert into res select 'F6 achats ne voit pas les clients (hors matrice)', '0', essai(:'U'||'b6', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='clients'$q$);
insert into res select 'F7 la liste de fonctions de equipe_inviter accepte commercial et achats', 'true',
  (select (pg_get_functiondef('equipe_inviter(uuid,text,text,text,text)'::regprocedure) like '%''commercial'',''achats''%')::text);
insert into res select 'F8 une fonction inconnue reste refusée', 'ERREUR',
  left(essai(:'U'||'b1', $q$select equipe_modifier('$q$||:'o'||$q$','00000000-0000-0000-0000-0000000000b8','editeur','pirate')::text$q$),6);

-- ---------- 2. Droits d'action côté serveur ----------
insert into res select 'E1 direction peut exporter', 'true', essai(:'U'||'b9', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
insert into res select 'E2 comptable peut exporter', 'true', essai(:'U'||'b4', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
insert into res select 'E3 conducteur ne peut pas exporter (refus par défaut)', 'false', essai(:'U'||'b2', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
insert into res select 'E4 polyvalent ne peut pas exporter', 'false', essai(:'U'||'b8', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
insert into res select 'E5 lecteur ne peut pas exporter', 'false', essai(:'U'||'b7', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
insert into res select 'E6 administrateur peut tout', 'true', essai(:'U'||'b1', $q$select peut_action('$q$||:'o'||$q$','administration')::text$q$);
insert into res select 'E7 la Direction n''a pas l''administration technique', 'false', essai(:'U'||'b9', $q$select peut_action('$q$||:'o'||$q$','administration')::text$q$);
insert into res select 'E8 on n''exporte pas ce qu''on ne peut pas lire (comptable → plans)', 'false', essai(:'U'||'b4', $q$select peut_action('$q$||:'o'||$q$','export','plans')::text$q$);
insert into res select 'E9 validation : direction oui, comptable non', 'true|false',
  essai(:'U'||'b9', $q$select peut_action('$q$||:'o'||$q$','validation')::text$q$)||'|'||essai(:'U'||'b4', $q$select peut_action('$q$||:'o'||$q$','validation')::text$q$);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (equipe_definir_permissions(:'o','00000000-0000-0000-0000-0000000000b4',true,true,true,true,false))::text \gset
insert into res select 'E10 permission d''export retirée au membre → refus serveur', 'false', essai(:'U'||'b4', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
insert into res select 'E11 exporter_controle refuse', 'false', essai(:'U'||'b4', $q$select (exporter_controle('$q$||:'o'||$q$','factures','test'))::jsonb->>'ok'$q$);
insert into res select 'E11b le refus d''export est journalisé', '1', (select count(*) from journal_entreprise where org_id=:'o' and action='refus export')::text;
insert into res select 'E12 exporter_controle accepte (direction)', 'true', essai(:'U'||'b9', $q$select (exporter_controle('$q$||:'o'||$q$','factures','test'))::jsonb->>'ok'$q$);
insert into res select 'E12b l''export accepté est journalisé', '1', (select count(*) from journal_entreprise where org_id=:'o' and action='export')::text;
insert into res select 'E13 un non-administrateur ne modifie pas la matrice d''actions', 'ERREUR',
  left(essai(:'U'||'b9', $q$select definir_action_fonction('$q$||:'o'||$q$','conducteur','export',true)::text$q$),6);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (definir_action_fonction(:'o','conducteur','export',true))::text \gset
insert into res select 'E14 l''administrateur autorise l''export au conducteur → appliqué par le serveur', 'true', essai(:'U'||'b2', $q$select peut_action('$q$||:'o'||$q$','export')::text$q$);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (definir_action_fonction(:'o','conducteur','export',false))::text \gset

-- ---------- 3. Périmètre par projet ----------
insert into res select 'P1 périmètre désactivé : le conducteur voit tout le planning', '3', essai(:'U'||'b2', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);
insert into res select 'P2 un non-administrateur ne peut pas activer le périmètre', 'ERREUR', left(essai(:'U'||'b9', $q$select perimetre_projet_definir('$q$||:'o'||$q$',true)::text$q$),6);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (perimetre_projet_definir(:'o',true))::text \gset
insert into res select 'P3 périmètre actif, sans affectation : seule la fiche sans projet reste visible', '1', essai(:'U'||'b2', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (affecter_projet(:'o','P1','00000000-0000-0000-0000-0000000000b2'))::text \gset
insert into res select 'P4 affecté à P1 : voit P1 + fiche sans projet', '2', essai(:'U'||'b2', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);
insert into res select 'P5 le conducteur non affecté ne voit que la fiche sans projet', '1', essai(:'U'||'b3', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);
insert into res select 'P6 écriture dans son projet : acceptée', 'true', essai(:'U'||'b2', $q$select (enregistrer('$q$||:'o'||$q$','planning_chantier','T1','{"projet":"P1","t":"coffrage v2"}',1))::jsonb->>'ok'$q$);
insert into res select 'P7 modifier une fiche d''un projet non affecté : refus', 'true', essai(:'U'||'b2', $q$select (enregistrer('$q$||:'o'||$q$','planning_chantier','T2','{"projet":"P2","t":"x"}',1))::jsonb->>'perimetre'$q$);
insert into res select 'P8 créer une fiche rangée dans un projet non affecté : refus', 'true', essai(:'U'||'b2', $q$select (enregistrer('$q$||:'o'||$q$','planning_chantier','T9','{"projet":"P2","t":"y"}',0))::jsonb->>'perimetre'$q$);
insert into res select 'P9 la Direction voit tout (hors périmètre)', '3', essai(:'U'||'b9', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);
insert into res select 'P10 l''administrateur voit tout', '3', essai(:'U'||'b1', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (affecter_projet(:'o','Villa Alpha','00000000-0000-0000-0000-0000000000b3'))::text \gset
insert into res select 'P11 affectation par NOM de projet : la fiche « projets » P1 devient visible', '1', essai(:'U'||'b3', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='projets'$q$);
insert into res select 'P12 diagnostic réservé à l''administrateur', 'ERREUR', left(essai(:'U'||'b9', $q$select perimetre_diagnostic('$q$||:'o'||$q$')::text$q$),6);
insert into res select 'P13 diagnostic : 1 fiche de planning non classée', '1',
  essai(:'U'||'b1', $q$select (select (x->>'non_classees') from json_array_elements(perimetre_diagnostic('$q$||:'o'||$q$')->'collections') x where x->>'collection'='planning_chantier')$q$);
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (affecter_projet(:'o','P1','00000000-0000-0000-0000-0000000000b2',false))::text \gset
insert into res select 'P14 retrait d''affectation appliqué immédiatement : retour à 1 fiche visible', '1', essai(:'U'||'b2', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='planning_chantier'$q$);

-- ---------- 4. Séparation préparateur / encaisseur ----------
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (perimetre_projet_definir(:'o',false))::text \gset
select set_config('app.uid','00000000-0000-0000-0000-0000000000b1',false);
select (affecter_projet(:'o','P1','00000000-0000-0000-0000-0000000000b2'))::text \gset
insert into res select 'S1 le conducteur prépare un bon de paiement', 'true', essai(:'U'||'b2', $q$select (enregistrer('$q$||:'o'||$q$','bons_paiement','B1','{"statut":"à payer","projet":"P1"}',0))::jsonb->>'ok'$q$);
insert into res select 'S2 le préparateur ne peut pas marquer son bon « payé »', 'true', essai(:'U'||'b2', $q$select (enregistrer('$q$||:'o'||$q$','bons_paiement','B1','{"statut":"payé","projet":"P1"}',1))::jsonb->>'separation'$q$);
insert into res select 'S3 le comptable encaisse (statut payé)', 'true', essai(:'U'||'b4', $q$select (enregistrer('$q$||:'o'||$q$','bons_paiement','B1','{"statut":"payé","projet":"P1"}',1))::jsonb->>'ok'$q$);
insert into res select 'S4 le refus est journalisé', '1', (select count(*) from journal_entreprise where org_id=:'o' and action='refus séparation des tâches')::text;

-- ---------- 5. Non-régression ----------
insert into res select 'R1 un lecteur n''écrit toujours pas', 'true', essai(:'U'||'b7', $q$select (enregistrer('$q$||:'o'||$q$','factures','F1','{}',0))::jsonb->>'refus'$q$);
insert into res select 'R2 le conflit de version est toujours détecté', 'true', essai(:'U'||'b5', $q$select (enregistrer('$q$||:'o'||$q$','clients','K1','{"nom":"autre"}',7))::jsonb->>'conflit'$q$);
insert into res select 'R3 une autre organisation ne voit rien', '0', essai(:'U'||'ba', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$'$q$);
insert into res select 'R4 polyvalent : toujours refusé sur la paie', '0', essai(:'U'||'b8', $q$select count(*) from enregistrements where org_id='$q$||:'o'||$q$' and collection='paie'$q$);
insert into res select 'R5 anonyme : rien', '0', essai('', $q$select count(*) from enregistrements$q$);
insert into res select 'R6 écriture directe sur enregistrements toujours fermée', 'ERREUR', left(essai(:'U'||'b2', $q$insert into enregistrements(org_id,collection,id,data) values ('$q$||:'o'||$q$','planning_chantier','Z','{}') returning 'ok'$q$),6);

select n || '  attendu=' || attendu || '  obtenu=' || obtenu || '  ' || case when attendu = obtenu then 'OK' else 'ECHEC' end from res order by n;
select 'BILAN V245 ' || count(*) filter (where attendu = obtenu) || '/' || count(*) from res;
