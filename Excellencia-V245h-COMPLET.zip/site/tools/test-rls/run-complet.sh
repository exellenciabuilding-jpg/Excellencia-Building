#!/bin/bash
# Charge TOUTES les migrations, dans l'ordre de ordre-migrations.txt (la référence unique d'exécution), sur une base de recette vide.
# Usage : tools/test-rls/run-complet.sh [base]    (PostgreSQL 14+ ; imitation de l'authentification Supabase, pas un vrai projet)
D="$(cd "$(dirname "$0")/../../supabase" && pwd)"; T="$(cd "$(dirname "$0")" && pwd)"; DB="${1:-rls_complet}"
psql postgres -qc "drop database if exists $DB" -c "create database $DB" >/dev/null 2>&1
psql $DB -q -f "$T/stub-supabase.sql" >/dev/null 2>&1
n=0; ko=0
while read -r f; do [ -z "$f" ] && continue; n=$((n+1))
  [ -f "$D/$f.sql" ] || { echo "MANQUANTE : $f"; ko=$((ko+1)); continue; }
  psql $DB -q -v ON_ERROR_STOP=1 -f "$D/$f.sql" >/dev/null 2>/tmp/err_mig.txt || { echo "ECHEC $f : $(grep -m1 -i 'error' /tmp/err_mig.txt | head -c 240)"; ko=$((ko+1)); }
done < "$T/ordre-migrations.txt"
echo "MIGRATIONS : $n chargées, $ko en échec (base $DB)"
