# V237h — la liste des chantiers de « Décomptes » suit la base partagée (simulée) et dit si le poste n'est pas relié
import http.server, threading, functools, os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:%d/' % srv.server_address[1]
ok = fail = 0
def t(c, m):
    global ok, fail
    if c: ok += 1; print('OK  ', m)
    else: fail += 1; print('FAIL', m)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1366, 'height': 900}).new_page(); errs = []
    pg.add_init_script("try{sessionStorage.setItem('exb_gate_bypass','1')}catch(e){}")
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto(BASE + 'comptable.html'); pg.wait_for_timeout(4500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    box = lambda: pg.evaluate("document.getElementById('exbdec_box').innerText")
    opts = lambda: pg.evaluate("[...document.querySelectorAll('#exbdec_box select option')].map(o=>o.textContent).join('|')")
    pg.evaluate("show('decomptes')"); pg.wait_for_timeout(600)
    t('n’est pas relié' in box() or "n'est pas relié" in box(), 'poste non relié : message explicite')
    pg.evaluate("window.EXBDB.info=()=>({on:true,org:'o',role:'editeur',fonction:'comptable'});window.EXBDB.can=()=>true;window.EXBDB.now=async()=>{exbProjects=[{id:'P1',name:'Chantier Gombe'},{id:'P2',name:'Chantier Limete'}]};show('decomptes')"); pg.wait_for_timeout(500)
    t('Aucun chantier reçu' in box(), 'relié sans chantier : message et bouton')
    pg.click('#dec_sync button'); pg.wait_for_timeout(500)
    t('Chantier Gombe' in opts() and '2 chantier' in box(), 'bouton « Actualiser » : les chantiers apparaissent (%s)' % opts())
    pg.evaluate("exbProjects.push({id:'P3',name:'Chantier Ngaliema'});EXBDEC.sync(['exb_projects'])"); pg.wait_for_timeout(300)
    t('Chantier Ngaliema' in opts(), 'arrivée par synchronisation : la liste se met à jour sans rouvrir')
    pg.evaluate("window.EXBDB.can=()=>false;show('decomptes')"); pg.wait_for_timeout(300)
    t('pas le droit' in box(), 'sans droit de lecture : message clair')
    t(not errs, 'aucune erreur JavaScript %s' % errs)
    # menu de l'espace selon le parcours mémorisé sur l'appareil
    pg.evaluate("localStorage.setItem('exb_parcours','btp')"); pg.reload(); pg.wait_for_timeout(4500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("EXB_SHELL.openCat('home')"); pg.wait_for_timeout(700)
    print('INFO menu (parcours btp) :', pg.evaluate("[...document.querySelectorAll('#exbSide .xs')].map(b=>b.textContent).join(' | ')"))
    b.close()
print('Résultat : %d OK, %d échec(s)' % (ok, fail)); sys.exit(1 if fail else 0)
