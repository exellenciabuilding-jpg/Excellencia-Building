# Fusion V103 (emballage APK / Windows) + V111 (site)
- Base : Excellencia-V103 (electron/, native/, scripts/, resources/, package.json, capacitor.config.json).
- `site/` : remplacé par le contenu de l'archive V111 (site Netlify). V111 contient tous les fichiers de V103 plus 33 nouveaux et 22 mis à jour (TFL blocs 1-5, espaces formateur/apprenant, carte de vérification, vérification QR, etc.). Aucun fichier de V103 supprimé.
- Désormais UN SEUL logiciel : le dossier `site/` est la source unique. Netlify publie `site/` ; l'APK et Windows le copient via `npm run build:www`. Pour toute modification, changer `site/` seulement, puis republier Netlify et reconstruire les applications.
- Vérifié : `node scripts/build-www.js` OK ; tous les .js de site/ passent `node --check`.
- Non vérifié : compilation APK/Windows et test sur appareil.
- Adresse publique des QR (hors ligne / application) : https://excellenciabuildingsarlu01.netlify.app/ (exb-verif.js, tfl-portail.html).
