# V99zzzzzzzzzzzzzzzzzzzzzzz — Éditeur de plan, lot 1 « édition »

Fichier modifié : `plan-editeur/index.html` (et `sw.js` déjà versionné pour l'interface). Aucun changement de format de plan (une seule clé facultative : `meta.joinOff`).

Déjà présents avant ce lot (inchangés) : copier / couper / coller, dupliquer, déplacer avec ΔX ΔY saisis, déplacer / copier par deux points, copie avec translation (réseau), rotation. Menu : clic droit ou appui long.

Ajoutés (menu Édition › Modifier, clic droit / appui long, fiche de sélection multiple) :
- **⇋ Miroir…** : axe vertical ou horizontal, au centre de la sélection ou à une position saisie (m), avec ou sans conservation de l'original. Murs (courbes inversées), pièces, hachures, meubles, électricité, câbles, textes, cotes, toits. Les portes et fenêtres suivent leur mur, sens d'ouverture inversé. Escaliers en L / U : position et rotation seulement, la forme n'est pas inversée (message affiché).
- **⧈ Décaler…** : copie parallèle à distance saisie (m). Murs droits : côté Nord / Sud / Est / Ouest ou extérieur / intérieur de la sélection ; les angles entre copies de murs qui se touchaient sont refermés. Pièces, hachures, toits libres et rectangulaires : extérieur / intérieur. Murs courbes non décalés (message).
- **⌐ Raccorder les murs…** : ferme les angles et pose les T (prolonge ou coupe les extrémités proches d'un autre mur), sur la sélection ou tout le niveau, tolérance saisie (30 cm par défaut). Les portes et fenêtres gardent leur position réelle.
- **🔗 Raccord auto** (oui / non, enregistré avec le plan) : à chaque mur tracé, ajuste ses extrémités si un autre mur est à moins de 15 cm.

Limites : murs courbes exclus du décalage et du raccord ; murs quasi parallèles (< 3°) ignorés par le raccord ; testé dans un navigateur (angle avec petit écart, T, miroir avec porte et lit, décalage extérieur), non testé sur téléphone réel.
