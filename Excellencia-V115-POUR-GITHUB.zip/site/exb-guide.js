/* Excellencia Building V99zzg/V99zzh — Assistant guidé avec voix (V99zzh : approbations, TP/TD, chantier, lecture des messages d'erreur ; V99zzi : contrôle au clic dans tous les écrans, licences clients, note de calcul, visa/cachet/identité avant tout document).
 * Avant d'enregistrer ou d'exporter, le logiciel vérifie que les étapes PRÉCÉDENTES sont faites (client créé avant le devis,
 * participant et paiement avant le reçu, reçu enregistré avant l'export PDF…). S'il manque quelque chose :
 *   - l'action est suspendue (rien n'est enregistré ni exporté à moitié) ;
 *   - une voix française explique quoi faire : « Veuillez d'abord renseigner le client avant d'enregistrer le devis » ;
 *   - une carte liste les étapes manquantes, avec un bouton qui ouvre la bonne section, et les champs concernés sont surlignés.
 * Après un enregistrement réussi, la voix indique la prochaine étape. Tous les messages d'avertissement déjà existants
 * (notify / alert) sont aussi lus à voix haute. Réglages : Paramètres › « Assistant guidé & voix ».
 * Aucune donnée n'est créée ni modifiée : seules des préférences d'affichage sont gardées sur l'appareil (EXB_GUIDE_CFG). */
(function(w,d){'use strict';
var CK='EXB_GUIDE_CFG',CFG={on:true,voice:true,next:true,strict:true,all:false,vol:0.9};
try{Object.assign(CFG,JSON.parse(w.localStorage.getItem(CK)||'{}'))}catch(e){}
function saveCfg(){try{w.localStorage.setItem(CK,JSON.stringify(CFG))}catch(e){}}
var CD=d;
var $=function(i){return CD&&CD.getElementById?CD.getElementById(i):null};
var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var norm=function(s){return String(s==null?'':s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim()};
function LD(k){try{var v=load(k,[]);return Array.isArray(v)?v:[]}catch(e){return[]}}
function V(id){var e=$(id);return e&&e.value!=null?String(e.value).trim():''}
function NUM(id){var x=parseFloat(String(V(id)).replace(',','.'));return isNaN(x)?0:x}
/* données vivantes de l'application (tableaux globaux), sinon lecture du stockage */
var DS={
 clients:function(){try{return exbClients}catch(e){return LD('exb_clients')}},
 projects:function(){try{return exbProjects}catch(e){return LD('exb_projects')}},
 participants:function(){try{return participants}catch(e){return LD('exb_participants')}},
 formations:function(){try{return formations}catch(e){return LD('exb_formations')}},
 schedules:function(){try{return schedules}catch(e){return LD('exb_schedules')}},
 payments:function(){try{return payments}catch(e){return LD('exb_payments')}},
 attendance:function(){try{return attendance}catch(e){return LD('exb_attendance')}},
 stock:function(){try{return exbStock}catch(e){return LD('exb_stock')}},
 qlines:function(){try{return exbQuoteLines}catch(e){return[]}}
};
function clientKnown(name){var n=norm(name);if(!n)return false;return DS.clients().some(function(c){return[c.full_name,c.company,((c.first_name||'')+' '+(c.last_name||'')).trim()].map(norm).filter(function(x){return x.length>2}).some(function(x){return x===n||n.indexOf(x)>-1||x.indexOf(n)>-1})})}
function hasPayment(name){var n=norm(name);return !!n&&DS.payments().some(function(p){return norm(p.participant_name)===n})}

/* ---------- constructeurs de contrôles ---------- */
function F(need,field,when,soft){return{k:'field',need:need,field:field,when:when||function(){return !V(field)},soft:soft}}
function S(need,when,go,label,field,soft){return{k:'step',need:need,when:when,go:go,label:label,field:field,soft:soft}}
var NO_CLIENT=S('créer la fiche du client dans la section Clients',function(){return !DS.clients().length},'clients','Clients');
var NO_PART=S('enregistrer l’apprenant dans la section Participants',function(){return !DS.participants().length},'participants','Participants');
var NO_FORM=S('créer la formation dans la section Formations',function(){return !DS.formations().length},'formations','Formations');
var NO_PROJ=S('créer le projet dans la section Projets',function(){return !DS.projects().length},'projets','Projets');
function idStep(){return S('compléter l’identité de l’entreprise (téléphone, e-mail, adresse) dans Paramètres › Logo Excellencia Building',function(){try{var I=w.EXBId&&w.EXBId.get();return !!I&&(!I.phone||!I.email||!I.address)}catch(e){return false}},'settings','Paramètres','exbIdPhone',true)}
function visaStep(){return S('mettre votre signature et votre cachet dans Paramètres › Logo Excellencia Building (le document ne doit pas partir sans visa)',function(){try{return !!w.EXBSign&&!w.EXBSign.active()}catch(e){return false}},'settings','Paramètres','exbSignAuto',true)}
function docChecks(){return[idStep(),visaStep()]}
function quoteChecks(){return[NO_CLIENT,
 F('le nom du client','exb_q_client',function(){return !V('exb_q_client')&&DS.clients().length>0}),
 S('enregistrer la fiche de ce client dans la section Clients (le client saisi n’a pas de fiche)',function(){return !!V('exb_q_client')&&DS.clients().length>0&&!clientKnown(V('exb_q_client'))},'clients','Clients','exb_q_client',true),
 S('ajouter au moins une ligne au devis',function(){return !DS.qlines().length})]}
function selPart(){var id=V('receiptParticipantSelect');return id?DS.participants().filter(function(p){return p.participant_id===id})[0]||null:null}
function paidBy(p){return !!p&&DS.payments().some(function(x){return (x.participant_id&&x.participant_id===p.participant_id)||(norm(x.participant_name)&&norm(x.participant_name)===norm(p.name))})}
function receiptChecks(){return[NO_PART,
 F('le participant dans la liste « Choisir un participant »','receiptParticipantSelect',function(){return !V('receiptParticipantSelect')&&DS.participants().length>0}),
 S('faire approuver ce participant dans la section Participants',function(){var p=selPart();return !!p&&p.approval_status!=='APPROUVE'},'participants','Participants','receiptParticipantSelect'),
 F('la formation suivie','rtraining'),
 S('indiquer au moins un montant (frais d’inscription ou de formation)',function(){return !V('registration_fee')&&!V('training_fee')},null,null,'registration_fee'),
 S('enregistrer le paiement de cet apprenant dans la section Paiements',function(){var p=selPart();return !!p&&!paidBy(p)},'finances','Paiements','receiptParticipantSelect',true)]}
function certChecks(){return[NO_PART,
 F('le nom du titulaire','holder'),F('la formation suivie','training'),F('la durée de la formation','duration'),F('le lieu de la formation','place'),F('la date de délivrance','issued_date'),
 S('enregistrer ce titulaire dans la section Participants (aucun participant de ce nom)',function(){return !!V('holder')&&DS.participants().length>0&&!DS.participants().some(function(p){return norm(p.name)===norm(V('holder'))})},'participants','Participants','holder',true)]}

/* V99zzh : approbations — on contrôle la FICHE elle-même (nom, téléphone, formation / spécialité / fonction) avant d'attribuer un matricule */
function entOf(t,id){try{
 if(t==='participant')return DS.participants().filter(function(p){return p.participant_id===id})[0]||null;
 if(t==='trainer')return(typeof trainers!=='undefined'?trainers:LD('exb_trainers')).filter(function(x){return x.trainer_id===id})[0]||null;
 return(w.exbHr||(typeof exbHr!=='undefined'?exbHr:[])).filter(function(h){return h.id===id})[0]||null}catch(e){return null}}
function EM(type,need,get,go,label){return S(need,function(t,id,o){if(t!==type||(o&&o.silent))return false;var e=entOf(t,id);if(!e)return false;var v=get(e);return !String(v==null?'':v).trim()},go,label)}
var APPROVE_CHECKS=[
 S('créer la formation dans la section Formations (le participant doit être rattaché à une formation)',function(t,id,o){return t==='participant'&&!(o&&o.silent)&&!DS.formations().length},'formations','Formations'),
 EM('participant','renseigner le nom de l’apprenant dans sa fiche Participants',function(e){return e.name},'participants','Participants'),
 EM('participant','renseigner le téléphone de l’apprenant dans sa fiche Participants',function(e){return e.phone},'participants','Participants'),
 EM('participant','indiquer la formation de l’apprenant dans sa fiche Participants',function(e){return e.training},'participants','Participants'),
 EM('trainer','renseigner le nom du formateur dans sa fiche Formateurs',function(e){return e.name},'formateurs','Formateurs'),
 EM('trainer','indiquer la spécialité du formateur dans sa fiche Formateurs',function(e){return e.specialty},'formateurs','Formateurs'),
 EM('trainer','renseigner le téléphone du formateur dans sa fiche Formateurs',function(e){return e.phone},'formateurs','Formateurs'),
 EM('hr','renseigner le nom de la personne dans sa fiche Ressources humaines',function(e){return e.name},'rh','Ressources humaines'),
 EM('hr','indiquer la fonction de la personne dans sa fiche Ressources humaines',function(e){return e.role},'rh','Ressources humaines'),
 EM('hr','renseigner le téléphone de la personne dans sa fiche Ressources humaines',function(e){return e.phone},'rh','Ressources humaines')];

/* ---------- règles : fonction → action + contrôles (+ message de la prochaine étape) ---------- */
var RULES={
 saveExbClient:{act:'enregistrer le client',key:'exb_clients',next:'Fiche client enregistrée. Prochaine étape : créer le projet ou établir le devis.',
  checks:[S('renseigner le nom du client',function(){return !(V('exb_cli_full')||V('exb_cli_first')||V('exb_cli_last'))},null,null,'exb_cli_first'),F('le numéro de téléphone du client','exb_cli_phone')]},
 saveExbProject:{act:'enregistrer le projet',key:'exb_projects',next:'Projet enregistré. Vous pouvez maintenant établir le devis, le planning ou la facturation du chantier.',
  checks:[NO_CLIENT,F('le nom du projet','exb_prj_name'),F('le client du projet','exb_prj_client',function(){return !V('exb_prj_client')&&DS.clients().length>0})]},
 saveExbQuote:{act:'enregistrer le devis',key:'exb_quotes',next:'Devis enregistré. Vous pouvez maintenant l’exporter en PDF ou le transformer en facture.',checks:quoteChecks()},
 exportExbQuotePdf:{act:'exporter le devis en PDF',checks:quoteChecks().concat(docChecks())},
 exportExbQuotePdfSimple:{act:'exporter le devis en PDF',checks:quoteChecks().concat(docChecks())},
 printExbQuote:{act:'imprimer le devis',checks:quoteChecks().concat(docChecks())},
 saveExbCash:{act:'enregistrer l’opération de caisse',checks:[F('le libellé de l’opération','exb_cash_label'),S('saisir un montant supérieur à zéro',function(){return NUM('exb_cash_amount')<=0},null,null,'exb_cash_amount')]},
 saveExbStockItem:{act:'enregistrer le matériau',checks:[F('le nom du matériau','exb_st_name')]},
 saveExbStockMovement:{act:'enregistrer le mouvement de stock',checks:[S('enregistrer le matériau dans la section Stock',function(){return !DS.stock().length},'stock','Stock'),F('le matériau concerné','exb_mv_item',function(){return !V('exb_mv_item')&&DS.stock().length>0}),S('saisir une quantité supérieure à zéro',function(){return NUM('exb_mv_qty')<=0},null,null,'exb_mv_qty')]},
 saveExbStudy:{act:'enregistrer l’étude',checks:[F('le projet de l’étude','exb_be_project')]},
 saveParticipant:{act:'enregistrer le participant',key:'exb_participants',next:'Participant enregistré. Prochaine étape : enregistrer son paiement, puis établir son reçu.',checks:[F('le nom du participant','p_name'),F('la formation du participant','p_training')]},
 saveFormation:{act:'enregistrer la formation',key:'exb_formations',next:'Formation enregistrée. Vous pouvez maintenant planifier les séances et inscrire des participants.',checks:[F('le nom de la formation','for_name')]},
 saveTrainer:{act:'enregistrer le formateur',checks:[F('le nom du formateur','frm_name'),F('la spécialité du formateur','frm_specialty')]},
 saveSchedule:{act:'enregistrer la séance',checks:[NO_FORM,F('la formation de la séance','pl_training',function(){return !V('pl_training')&&DS.formations().length>0}),F('le module','pl_module'),F('la date de la séance','pl_date')]},
 exportPlanningPdf:{act:'exporter le planning en PDF',checks:[S('créer les séances dans la section Planning',function(){return !DS.schedules().length},'planning','Planning')]},
 saveAttendance:{act:'enregistrer les présences',checks:[NO_PART,S('choisir la formation pour afficher la liste des participants à pointer',function(){return DS.participants().length>0&&!d.querySelectorAll('.attStatus').length},null,null,'att_training')]},
 exportAttendancePdf:{act:'exporter la feuille de présence en PDF',checks:[NO_PART,S('enregistrer les présences de cette date',function(){var dt=V('att_date')||new Date().toISOString().slice(0,10);return !DS.attendance().some(function(x){return x.date===dt})},'presence','Présences','att_date')]},
 savePayment:{act:'enregistrer le paiement',key:'exb_payments',next:'Paiement enregistré. Vous pouvez maintenant établir le reçu de l’apprenant.',
  checks:[NO_PART,F('le participant concerné','pay_participant',function(){return !V('pay_participant')&&DS.participants().length>0}),S('saisir un montant supérieur à zéro',function(){return NUM('pay_amount')<=0},null,null,'pay_amount')]},
 saveReceipt:{act:'enregistrer le reçu',key:'exb_receipts',next:'Reçu enregistré. Vous pouvez maintenant l’exporter en PDF.',checks:receiptChecks()},
 exportReceiptPdf:{act:'exporter le reçu en PDF',async:true,checks:receiptChecks().concat([S('enregistrer le reçu pour obtenir son numéro définitif',function(){var n=$('receipt_no');return !(n&&n.value)},null,null,null)]).concat(docChecks())},
 saveCert:{act:'enregistrer le certificat',key:'exb_certificates',next:'Certificat enregistré. Vous pouvez maintenant l’exporter en PDF.',checks:certChecks()},
 exportCertPdf:{act:'exporter le certificat en PDF',async:true,checks:certChecks().concat([S('enregistrer le certificat pour obtenir son numéro et son QR Code',function(){var n=$('cert_no'),v=$('vn');return !(n&&n.value)||(v&&/attribuer/i.test(v.textContent))},null,null,null)]).concat(docChecks())},
 generateSelectedCertificatesPdf:{act:'générer les certificats sélectionnés',async:true,checks:[NO_PART,S('cocher au moins un participant dans la liste',function(){try{return !getSelectedCertParticipantIds().length}catch(e){return false}},null,null,null),F('la durée','duration'),F('le lieu','place'),F('la date de délivrance','issued_date')].concat(docChecks())},
 saveCotation:{act:'enregistrer la cotation',checks:[NO_PART,F('le participant','cot_participant',function(){return !V('cot_participant')&&DS.participants().length>0}),F('le module','cot_module'),S('ajouter au moins une activité à la cotation',function(){try{return !currentCotationLines.length}catch(e){return false}},null,null,null)]},
 exportCotationPdf:{act:'exporter la cotation en PDF',checks:[S('choisir le participant et le module de la cotation',function(id){return !id&&(!V('cot_participant')||!V('cot_module'))},null,null,'cot_participant')]},
 saveEvaluation:{act:'enregistrer l’évaluation',checks:[NO_PART,F('le participant','eval_participant',function(){return !V('eval_participant')&&DS.participants().length>0}),F('la matière','eval_subject'),F('la note obtenue','eval_score'),F('la note maximale','eval_max')]},
 exportParticipantsPdf:{act:'exporter la liste des participants en PDF',checks:[NO_PART]},
 'EXBCH.newInv':{act:'créer la facture',checks:[NO_PROJ,NO_CLIENT]},
 /* V99zzh : approbations, enregistrement + approbation directe, TP / TD, chantier (dépense, facture, PDF) */
 approveEntity:{act:'approuver ce dossier',checks:APPROVE_CHECKS},
 saveAndApproveParticipant:{act:'enregistrer et approuver le participant',key:'exb_participants',next:'Participant approuvé. Prochaine étape : enregistrer son paiement, puis établir son reçu.',
  checks:[NO_FORM,F('le nom du participant','p_name'),F('le numéro de téléphone du participant','p_phone'),F('la formation du participant','p_training')]},
 saveTpTd:{act:'enregistrer le TP / TD',key:'exb_tp_td_docs',next:'TP ou TD enregistré. Vous pouvez maintenant l’aperçu, l’imprimer ou le générer en PDF.',
  checks:[F('le titre du TP ou du TD','tp_title'),F('la matière','tp_subject'),F('les questions ou exercices','tp_questions')]},
 'EXBCH.addE':{act:'enregistrer la dépense du chantier',checks:[F('le libellé de la dépense','exbch_el'),S('saisir un montant supérieur à zéro',function(){return NUM('exbch_ea')<=0},null,null,'exbch_ea')]},
 'EXBCH.saveD':{act:'enregistrer la facture',checks:[NO_PROJ,NO_CLIENT]},
 'EXBCH.pdf':{act:'exporter la facture en PDF',checks:docChecks()}
};

/* ---------- rédaction des messages ---------- */
function phr(c){return c.k==='field'?'renseigner '+c.need:c.need}
function de(act){return /^[aeiouyhéèêàâîïôû]/i.test(act)?'d’'+act:'de '+act}
function cap(s){return s.charAt(0).toUpperCase()+s.slice(1)}
function compose(R,pb){
 if(pb.length===1)return'Veuillez d’abord '+phr(pb[0])+' avant '+de(R.act)+'.';
 var ord=['D’abord','Ensuite','Puis','Enfin'],parts=pb.slice(0,4).map(function(c,i){return ord[i]+' : '+phr(c)+'.'});
 return'Avant '+de(R.act)+', il reste '+pb.length+' étapes. '+parts.join(' ')+(pb.length>4?' Et '+(pb.length-4)+' autre(s).':'')}

/* ---------- voix ---------- */
var last={t:'',at:0};
function clean(t){return String(t==null?'':t).replace(/<[^>]*>/g,' ').replace(/[\u{1F300}-\u{1FAFF}\u2600-\u27BF\uFE0F]/gu,'').replace(/\s+/g,' ').trim()}
function speak(text,force){
 try{if(!force&&!(CFG.on&&CFG.voice))return false;var S_=w.speechSynthesis;if(!S_||!w.SpeechSynthesisUtterance)return false;var t=clean(text);if(!t)return false;
  var now=Date.now();if(!force&&t===last.t&&now-last.at<3500)return true;last={t:t,at:now};
  S_.cancel();var u=new w.SpeechSynthesisUtterance(t);u.lang='fr-FR';u.volume=Math.max(0.1,Math.min(1,CFG.vol));u.rate=0.98;
  var v=(S_.getVoices()||[]).filter(function(x){return /^fr/i.test(x.lang)})[0];if(v)u.voice=v;S_.speak(u);return true}catch(e){return false}}

/* ---------- carte d'étapes manquantes + surlignage ---------- */
var inGuide=false,hideT=null,markT=null;
function css(doc){doc=doc||d;if(doc.getElementById('exbGuideCss'))return;var s=doc.createElement('style');s.id='exbGuideCss';
 s.textContent='#exbGuide{position:fixed;left:50%;bottom:76px;transform:translateX(-50%);z-index:100000;width:min(94vw,460px);background:#fff;color:#172033;border-left:6px solid #e0a100;border-radius:12px;box-shadow:0 10px 34px #0003;padding:12px 14px;font:14px/1.4 Arial,sans-serif}'+
 '#exbGuide b.t{display:block;margin-bottom:4px;color:#8a5a00}#exbGuide ol{margin:6px 0 8px 20px;padding:0}#exbGuide li{margin:3px 0}#exbGuide .bt{display:flex;gap:8px;flex-wrap:wrap}#exbGuide button{border:0;border-radius:8px;padding:8px 12px;cursor:pointer;font:600 13px Arial}#exbGuide .go{background:#2f6fed;color:#fff}#exbGuide .ok{background:#eef1f6;color:#172033}'+
 '.exb-guide-miss{outline:3px solid #e5352f!important;outline-offset:1px;animation:exbGuideShake .4s 1}@keyframes exbGuideShake{25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}';(doc.head||doc.documentElement).appendChild(s)}
function closeCard(){var c=$('exbGuide');if(c)c.remove();clearTimeout(hideT)}
var MARKED=[];
function unmark(){[].forEach.call(d.querySelectorAll('.exb-guide-miss'),function(e){e.classList.remove('exb-guide-miss')});MARKED.forEach(function(e){try{e.classList.remove('exb-guide-miss')}catch(x){}});MARKED=[]}
function report(R,pb){
 inGuide=true;try{
  css();closeCard();unmark();
  var text=compose(R,pb),go=pb.filter(function(c){return c.go}),seen={},btn='';
  go.forEach(function(c){if(seen[c.go])return;seen[c.go]=1;btn+='<button class="go" data-go="'+esc(c.go)+'">➡ Ouvrir « '+esc(c.label||c.go)+' »</button>'});
  var card=d.createElement('div');card.id='exbGuide';card.setAttribute('role','alert');
  card.innerHTML='<b class="t">🧭 '+(pb.length>1?pb.length+' étapes à faire avant '+de(R.act):'Une étape à faire avant '+de(R.act))+'</b><ol>'+pb.map(function(c){return'<li>'+esc(cap(phr(c)))+'</li>'}).join('')+'</ol><div class="bt">'+btn+'<button class="ok">Compris</button></div>';
  d.body.appendChild(card);
  card.querySelector('.ok').onclick=closeCard;
  [].forEach.call(card.querySelectorAll('[data-go]'),function(b){b.onclick=function(){var k=b.getAttribute('data-go');closeCard();try{show(k)}catch(e){}}});
  hideT=setTimeout(closeCard,15000);
  var first=null;pb.forEach(function(c){var e=c.el||(c.field&&$(c.field));if(e){e.classList.add('exb-guide-miss');MARKED.push(e);if(!first)first=e}});
  if(first){try{first.scrollIntoView({block:'center',behavior:'smooth'});if(first.focus)first.focus({preventScroll:true})}catch(e){}}
  clearTimeout(markT);markT=setTimeout(unmark,7000);
  speak(text)}finally{inGuide=false}}
if(d&&d.addEventListener)d.addEventListener('input',function(e){if(e.target&&e.target.classList)e.target.classList.remove('exb-guide-miss')},true);

/* ---------- V99zzi : contrôle au CLIC, dans tous les écrans (y compris licences clients et note de calcul) ----------
 * Quand on clique sur Enregistrer / Exporter / Imprimer / Générer / Valider / Approuver…, on vérifie les champs obligatoires de l'écran :
 *  - règles explicites (CLICKRULES) pour les écrans qui ont leurs propres champs (générateur de licences, note de calcul) ;
 *  - sinon, tout champ marqué obligatoire dans le logiciel (étoile *, « obligatoire », attribut required) et vide est réclamé. */
function C(id){var e=$(id);return !!(e&&e.checked)}
var CLICKRULES=[
 {sel:'#go',act:'générer la licence et les liens',checks:[
  F('le nom du client','cn'),
  F('le numéro WhatsApp du client','cw',null,true),
  S('cocher au moins un logiciel (principal ou chantier)',function(){return !C('wc')&&!C('wf')},null,null,'wc'),
  F('l’adresse du logiciel principal (https://…)','u1',function(){return C('wc')&&!V('u1')}),
  F('l’adresse du logiciel chantier (https://…)','u2',function(){return C('wf')&&!V('u2')}),
  F('la date de fin de la licence','d1'),
  F('l’e-mail du compte du logiciel principal','ae',function(){return C('wc')&&!V('ae')},true),
  F('le mot de passe du compte du logiciel principal (🎲 pour en générer un)','ap',function(){return C('wc')&&!!V('ae')&&!V('ap')}),
  F('l’identifiant (e-mail) du compte du logiciel chantier','fe',function(){return C('wf')&&!V('fe')},true),
  F('le code provisoire du compte du logiciel chantier (🎲 pour en générer un)','fp',function(){return C('wf')&&!!V('fe')&&!V('fp')})]},
 {sel:'#dp',act:'imprimer la note de calcul',checks:[
  F('le client / maître d’ouvrage','exf_moa'),F('le nom du projet','exf_projet'),F('le lieu du chantier','exf_site'),F('l’ingénieur qui établit la note','exf_ing'),
  F('le vérificateur (« Vérifié par »)','exf_verif',null,true),
  S('faire valider la note par un ingénieur (statut « Validé » avec son cachet) avant de l’imprimer, ou cocher « Brouillon »',function(){var s=$('exv_s'),dr=$('exf_draft');return !!s&&!(dr&&dr.checked)&&!/^(valide|reserves)$/.test(String(s.value))},null,null,'exv_s',true)]}];
var ACTION=/^(enregistr|sauvegard|export|imprim|gener|valid|approuv|creer|envoyer|soumettre|publier|confirmer|telecharg|pdf|importer|emettre|cloturer|encaisser)/;
function btnTxt(b){return String(b.textContent||b.value||'').replace(/[\u{1F300}-\u{1FAFF}\u2600-\u27BF\uFE0F]/gu,'').replace(/\s+/g,' ').replace(/^[^A-Za-zÀ-ÿ]+/,'').trim()}
function visible(e){return !!e&&!e.disabled&&e.type!=='hidden'&&e.type!=='file'&&e.type!=='checkbox'&&e.type!=='radio'&&(e.offsetParent!==null||(e.getClientRects&&e.getClientRects().length>0))}
function lblOf(f){var doc=f.ownerDocument,l=null;try{if(f.id)l=doc.querySelector('label[for="'+f.id+'"]')}catch(e){}
 if(!l){var p=f.parentElement;if(p&&p.tagName==='LABEL')l=p;else{var q=f.previousElementSibling;if(q&&q.tagName==='LABEL')l=q}}return l}
function reqInfo(f){var l=lblOf(f),t=((l&&l.textContent)||'').replace(/\s+/g,' ').trim(),ph=f.getAttribute('placeholder')||'';
 if(/facultatif|optionnel|optional/i.test(t+' '+ph))return null;
 var m=f.required||f.getAttribute('aria-required')==='true'||/\*\s*$/.test(t)||/obligatoire/i.test(t+' '+ph);
 if(!m&&CFG.all&&!f.readOnly&&f.type!=='search'&&f.type!=='button'&&f.type!=='submit'&&f.type!=='range'&&f.type!=='color'&&!/search|recherche|filtre|filter/i.test((f.id||'')+' '+ph+' '+(f.name||'')))m=true;
 if(!m)return null;
 var nm=t.replace(/\*/g,'').replace(/\(\s*obligatoire[^)]*\)/i,'').trim()||ph||f.name||f.id;return{name:nm}}
function missingIn(root){var out=[];[].forEach.call(root.querySelectorAll('input,select,textarea'),function(f){if(!visible(f))return;var ri=reqInfo(f);if(!ri)return;if(String(f.value==null?'':f.value).trim()==='')out.push({k:'field',need:'le champ « '+ri.name+' »',el:f,field:f.id||''})});return out}
function hasReq(root){var n=0;[].forEach.call(root.querySelectorAll('input,select,textarea'),function(f){if(visible(f)&&reqInfo(f))n++});return n}
function scopeOf(b){var e=b.parentElement,n=0;while(e&&e.tagName!=='BODY'&&e.tagName!=='HTML'&&n<8){
  if(e.tagName==='SECTION'&&e.querySelectorAll('input,select,textarea').length>40)return null;
  if(hasReq(e))return e;e=e.parentElement;n++}return null}
function actPhrase(b){var t=btnTxt(b).toLowerCase();if(!t)return'continuer';return t.length>46?t.slice(0,46).replace(/\s+\S*$/,''):t}
function onClickGuard(ev){
 if(!CFG.on||inGuide)return;
 var t=ev.target,b=t&&t.closest&&t.closest('button,input[type=button],input[type=submit],[role=button]');
 if(!b||b.disabled||(b.closest&&b.closest('#exbGuide,#exbGuidePanel,[data-noguide]')))return;
 var doc=b.ownerDocument,pb=[],R=null,rule=null;
 CLICKRULES.forEach(function(r){if(!rule&&b.matches&&b.matches(r.sel)&&doc.querySelector(r.sel)===b)rule=r});
 var prev=CD;CD=doc;
 try{
  if(rule){R=rule;pb=run(rule,[])}
  else{
   var oc=String(b.getAttribute('onclick')||''),mm=/^\s*([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)?)\s*\(/.exec(oc);
   if(mm&&RULES[mm[1]])return;
   if(!ACTION.test(norm(btnTxt(b))))return;
   var sc=scopeOf(b);if(!sc)return;
   pb=missingIn(sc);R={act:actPhrase(b)}}
  pb=pb.map(function(c){var x={};for(var k in c)x[k]=c[k];if(!x.el&&x.field)x.el=doc.getElementById(x.field);return x})
 }catch(e){pb=[]}finally{CD=prev}
 if(pb.length){ev.stopImmediatePropagation();ev.preventDefault();if(doc!==d)css(doc);report(R,pb)}}
function bindClicks(doc){if(!doc||doc.__exbGuideClick||!doc.addEventListener)return false;doc.__exbGuideClick=1;doc.addEventListener('click',onClickGuard,true);return true}

/* ---------- pose des gardes ---------- */
function snap(key){try{return JSON.stringify(load(key,[]))}catch(e){return''}}
function run(R,args){return R.checks.filter(function(c){try{return !!c.when.apply(null,args)&&(!c.soft||CFG.strict)}catch(e){return false}})}
function wrapFn(owner,name,R){var orig=owner[name];if(typeof orig!=='function'||orig.__guide)return false;
 var f=function(){
  if(!CFG.on)return orig.apply(this,arguments);
  var pb=run(R,arguments);if(pb.length){report(R,pb);return R.async?Promise.resolve():undefined}
  var before=R.key?snap(R.key):null,res=orig.apply(this,arguments);
  if(R.next&&R.key){var chk=function(){try{if(CFG.on&&CFG.next&&snap(R.key)!==before)speak(R.next)}catch(e){}};if(res&&typeof res.then==='function')res.then(chk);else chk()}
  return res};
 f.__guide=1;f.__orig=orig;owner[name]=f;return true}
function install(){var n=0;Object.keys(RULES).forEach(function(k){var p=k.split('.'),o=w;try{for(var i=0;i<p.length-1;i++)o=o&&o[p[i]];if(o&&wrapFn(o,p[p.length-1],RULES[k]))n++}catch(e){}});return n}
/* tous les avertissements existants sont lus à voix haute */
var WARN=/obligatoire|d.abord|choisissez|sélectionnez|selectionnez|complétez|impossible|veuillez|aucun/i;
function relay(){
 var on=w.notify;if(typeof on==='function'&&!on.__guide){var f=function(msg,type){try{if(!inGuide&&CFG.on&&CFG.voice&&String(msg).charAt(0)!=='🔔'&&(type==='warn'||type==='error'||(type!=='success'&&type!=='info'&&WARN.test(String(msg)))))speak(msg)}catch(e){}return on.apply(this,arguments)};f.__guide=1;w.notify=f}
 var oa=w.alert;if(typeof oa==='function'&&!oa.__guide){var g=function(msg){try{if(!inGuide&&CFG.on&&CFG.voice)speak(msg)}catch(e){}return oa.apply(this,arguments)};g.__guide=1;w.alert=g}}

/* ---------- V99zzh : filet de sécurité — les messages d'erreur écrits dans une zone de message (sans notification) sont aussi lus ----------
 * Couvre tous les formulaires de l'application et l'écran « Calcul de structure » (iframe de même origine). */
var MSGRE=/obligatoire|impossible|invalide|manquant|incomplet|veuillez|d.abord|renseign|indiquez|choisissez|s[ée]lectionnez|ajoutez au moins|introuvable|refus|non valable|habilit/i;
function isMsgEl(e){return !!e&&e.nodeType===1&&((e.classList&&e.classList.contains('msg'))||/(^|_)msg$/i.test(e.id||'')||e.id==='pm_local')}
function watch(doc){
 if(!doc||doc.__exbGuideWatch||!doc.body||typeof MutationObserver==='undefined')return false;doc.__exbGuideWatch=1;
 new MutationObserver(function(ms){
  if(inGuide||!(CFG.on&&CFG.voice))return;
  for(var i=0;i<ms.length;i++){
   var n=ms[i].target,el=n&&n.nodeType===1?n:(n&&n.parentNode);
   while(el&&el!==doc.body&&!isMsgEl(el))el=el.parentNode;
   if(!el||el===doc.body)continue;
   var raw=String(el.textContent||'').trim();if(!raw||raw.length>240)continue;
   if(/^[✓✔✅]/.test(raw))continue;
   var cls=String(el.className||''),bad=/^[✕✗❌⚠]/.test(raw)||/(^|\s)(ko|ann|warn|err|error)(\s|$)/.test(cls)||!!(el.querySelector&&el.querySelector('.ann,.ko'));
   if(bad||MSGRE.test(raw)){speak(raw);break}}
 }).observe(doc.body,{childList:true,characterData:true,subtree:true});
 return true}
function watchFrame(){try{var f=$('exbCalcFrame');if(!f)return;
 if(!f.__exbGuideLoad){f.__exbGuideLoad=1;f.addEventListener('load',function(){setTimeout(watchFrame,800)})}
 if(f.contentDocument&&f.contentDocument.body){watch(f.contentDocument);bindClicks(f.contentDocument);css(f.contentDocument)}}catch(e){}}

/* ---------- réglages ---------- */
function panelHtml(){return'<div class="pgroup" id="exbGuidePanel" data-nokeep="1"><b class="pgtitle">🧭 Assistant guidé & voix</b>'+
 '<div class="hint">Avant d’enregistrer ou d’exporter, le logiciel vérifie que les étapes précédentes sont faites (ex. créer le client avant le devis, enregistrer le reçu avant son PDF). S’il manque quelque chose, il le dit à voix haute et vous ouvre la bonne section.</div>'+
 '<label class="ea-row"><input type="checkbox" id="eg_on"'+(CFG.on?' checked':'')+'> <b>Activer l’assistant guidé</b></label>'+
 '<label class="ea-row"><input type="checkbox" id="eg_voice"'+(CFG.voice?' checked':'')+'> Lire les messages à voix haute (français)</label>'+
 '<label class="ea-row"><input type="checkbox" id="eg_next"'+(CFG.next?' checked':'')+'> Annoncer la prochaine étape après un enregistrement réussi</label>'+
 '<label class="ea-row"><input type="checkbox" id="eg_all"'+(CFG.all?' checked':'')+'> <b>Mode « tous les champs »</b> : au clic sur Enregistrer / Exporter / Imprimer / Générer, tout champ visible laissé vide est réclamé (sauf ceux marqués « facultatif » et les barres de recherche)</label>'+
 '<label class="ea-row"><input type="checkbox" id="eg_strict"'+(CFG.strict?' checked':'')+'> Mode strict : exiger les fiches liées (client du devis, paiement du reçu, titulaire du certificat enregistré)</label>'+
 '<div><label>Volume de la voix <span id="eg_volv">'+Math.round(CFG.vol*100)+' %</span></label><input type="range" id="eg_vol" min="10" max="100" value="'+Math.round(CFG.vol*100)+'"></div>'+
 '<div style="margin-top:8px"><button class="muted" id="eg_test">🔊 Tester la voix</button></div></div>'}
function mount(){var st=$('settings');if(!st||$('exbGuidePanel'))return;css();
 var al=$('exbAlertPanel');if(al)al.insertAdjacentHTML('beforebegin',panelHtml());else st.insertAdjacentHTML('beforeend',panelHtml());
 var set=function(id,k){var e=$(id);if(e)e.onchange=function(){CFG[k]=this.checked;saveCfg()}};set('eg_on','on');set('eg_voice','voice');set('eg_next','next');set('eg_strict','strict');set('eg_all','all');
 $('eg_vol').oninput=function(){$('eg_volv').textContent=this.value+' %'};$('eg_vol').onchange=function(){CFG.vol=this.value/100;saveCfg();speak('Voix réglée.',true)};
 $('eg_test').onclick=function(){if(!speak('Veuillez d’abord renseigner le client avant d’enregistrer le devis.',true)){try{notify('La voix n’est pas disponible sur ce navigateur.','warn')}catch(e){}}}}
function wrapShow(){if(typeof w.show!=='function'||w.show.__guide)return;var os=w.show,f=function(x){var r=os.apply(this,arguments);if(x==='settings'){try{mount()}catch(e){}}if(x==='calcStructure'){setTimeout(watchFrame,600);setTimeout(watchFrame,2500)}return r};f.__guide=1;w.show=f}

w.EXBGUIDE={cfg:CFG,rules:RULES,compose:compose,speak:speak,install:install,_run:run,_clientKnown:clientKnown,_hasPayment:hasPayment,_watch:watch,_watchFrame:watchFrame,_entOf:entOf,clickRules:CLICKRULES,_missingIn:missingIn};
function init(){relay();install();wrapShow();watch(d);bindClicks(d);watchFrame();var n=0,iv=setInterval(function(){n++;relay();install();wrapShow();if(n>16)clearInterval(iv)},1500)}
if(d&&d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(init,900)});else setTimeout(init,900);
})(typeof window!=='undefined'?window:globalThis,typeof document!=='undefined'?document:null);
