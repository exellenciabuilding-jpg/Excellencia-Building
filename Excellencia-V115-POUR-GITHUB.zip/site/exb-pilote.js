/* Excellencia Building V99zt — Pilotage projets : tableau de bord EVM, retard (chemin critique) et alertes automatiques.
 * Lecture seule : ne modifie aucune donnée. Les calculs sont dans exb-evm.js. */
(function(w,d){'use strict';
var E=w.EXBEVM;if(!E)return;
var $=function(i){return d.getElementById(i)},st={pid:'',hideClosed:true};
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'info',4500)}catch(e){}}
function G(k){try{if(w.EXBS&&w.EXBS.get)return w.EXBS.get(k)||[]}catch(e){}try{var a=typeof w.load==='function'?w.load(k,[]):[];return Array.isArray(a)?a:[]}catch(e){return[]}}
function can(c){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(c,'lire')}catch(e){return true}}
function canW(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can('budgets_chantier','ecrire')}catch(e){return true}}
function put(k,a){try{return w.EXBS&&w.EXBS.set?w.EXBS.set(k,a):false}catch(e){return false}}
function allowed(){return can('projets')&&can('planning_chantier')&&can('budgets_chantier')}
function today(){return new Date().toISOString().slice(0,10)}
function fx(n,dd){return Number(n||0).toLocaleString('fr-FR',{minimumFractionDigits:dd==null?0:dd,maximumFractionDigits:dd==null?0:dd}).replace(/[\u202f\u00a0]/g,' ')}
function usd(n){return fx(n,0)+' $'}
function idx(v){return v==null?'—':Number(v).toFixed(2).replace('.',',')}
function frd(s){return s?String(s).split('-').reverse().join('/'):'—'}
var COL={rouge:'#b91c1c',orange:'#d97706',vert:'#15803d',gris:'#6b7280'},LAB={rouge:'À traiter',orange:'À surveiller',vert:'Sous contrôle',gris:'Données insuffisantes'},DOT={rouge:'🔴',orange:'🟠',vert:'🟢',gris:'⚪'};
function ic(v,lo,hi){return v==null?'#6b7280':v>=hi?'#15803d':v>=lo?'#d97706':'#b91c1c'}

/* ---------- calcul de tous les projets ---------- */
function compute(){
  var t=today(),P=G('exb_projects'),Gs=G('exb_gantt'),Bs=G('exb_budgets'),C=G('exb_cash'),CF=G('exb_pilot_th'),late={};
  try{if(w.EXBPIL&&w.EXBPIL._calc&&can('factures'))w.EXBPIL._calc().rows.forEach(function(r){late[String(r.id)]=r.late})}catch(e){}
  return P.map(function(p){
    var g=Gs.filter(function(x){return String(x.project_id)===String(p.id)})[0],b=Bs.filter(function(x){return String(x.project_id)===String(p.id)})[0],
        rowsC=C.filter(function(c){return String(c.project_id)===String(p.id)}),
        cash=rowsC.reduce(function(a,c){return c.type==='out'?a+(+c.amount||0):a},0);
    var a=E.analyseProject(p,g,b,cash,t,late[String(p.id)]||0,E.thFor(CF,p.id),rowsC);a.id=p.id;a.week1=g&&g.date||'';a.custom=CF.some(function(c){return c&&String(c.id)===String(p.id)});a.name=p.name||p.nom||p.id;a.client=p.client||'';a.statut=p.status||'';return a})}


/* ---------- historique hebdomadaire (V99zz+) ---------- */
var HK='exb_pilot_hist';
function histGet(){try{if(w.EXBS&&w.EXBS.get)return w.EXBS.get(HK)||[]}catch(e){}return []}
/* Enregistre (ou met à jour) le point de la semaine pour chaque projet actif, à l'ouverture du pilotage. N'écrit que si quelque chose a changé. Lecture seule pour les autres données. */
function recordHist(rows){try{if(!allowed()||!w.EXBS||!w.EXBS.set)return;var t=today(),h=histGet(),snaps=(rows||compute()).map(function(a){return E.snap(a,t)}).filter(Boolean);if(!snaps.length)return;
  var nh=E.mergeHistory(h,snaps);if(JSON.stringify(nh)!==JSON.stringify(h))w.EXBS.set(HK,nh)}catch(e){}}
function arrow(t){if(!t||!t.dir)return '';var c=t.dir==='up'?'#15803d':t.dir==='down'?'#b91c1c':'#6b7280',s=t.dir==='up'?'↗':t.dir==='down'?'↘':'→';
  return ' <span title="'+(t.delta>=0?'+':'')+idx(t.delta)+' depuis la semaine précédente" style="color:'+c+';font-weight:700">'+s+'</span>'}
function trendChart(s,pdf){var n=s.length,W=600,H=200,L=40,R=14,T=14,B=30,vals=[];s.forEach(function(p){if(p.cpi!=null)vals.push(p.cpi);if(p.spi!=null)vals.push(p.spi)});
  var lo=Math.min(.6,Math.floor(Math.min.apply(null,vals)*10)/10),hi=Math.max(1.2,Math.ceil(Math.max.apply(null,vals)*10)/10),
  X=function(i){return L+(W-L-R)*(n>1?i/(n-1):.5)},Y=function(v){return T+(H-T-B)*(1-(v-lo)/(hi-lo))},
  svg=pdf?'<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'" font-family="Arial,Helvetica,sans-serif"><rect width="'+W+'" height="'+H+'" fill="#fff"/>':'<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;max-width:680px;height:auto" role="img" aria-label="Tendance hebdomadaire du CPI et du SPI">';
  [lo,1,hi].forEach(function(g){svg+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+Y(g)+'" y2="'+Y(g)+'" stroke="'+(g===1?'#94a3b8':'#e2e8f0')+'" stroke-width="'+(g===1?1.2:.6)+'" '+(g===1?'stroke-dasharray="4 3"':'')+'/><text x="'+(L-6)+'" y="'+(Y(g)+4)+'" font-size="10" text-anchor="end" fill="#64748b">'+idx(g)+'</text>'});
  var step=Math.max(1,Math.ceil(n/8));s.forEach(function(p,i){if(i%step===0||i===n-1)svg+='<text x="'+X(i)+'" y="'+(H-10)+'" font-size="10" text-anchor="middle" fill="#64748b">'+frd(p.week).slice(0,5)+'</text>'});
  [['cpi','#1a3a6b'],['spi','#d97706']].forEach(function(k){var pts=[];s.forEach(function(p,i){if(p[k[0]]!=null)pts.push(X(i)+','+Y(p[k[0]]))});
    if(pts.length>1)svg+='<polyline fill="none" stroke="'+k[1]+'" stroke-width="2.2" points="'+pts.join(' ')+'"/>';
    s.forEach(function(p,i){if(p[k[0]]!=null)svg+='<circle cx="'+X(i)+'" cy="'+Y(p[k[0]])+'" r="3.2" fill="'+k[1]+'"/>'})});
  if(pdf)return svg+'<text x="'+(L+6)+'" y="'+(T+12)+'" font-size="10" fill="#1a3a6b">● CPI (coût)</text><text x="'+(L+90)+'" y="'+(T+12)+'" font-size="10" fill="#d97706">● SPI (délai)</text></svg>';
  return svg+'</svg><div style="font-size:12px;margin-top:4px"><span style="color:#1a3a6b">●</span> CPI (coût) &nbsp; <span style="color:#d97706">●</span> SPI (délai) &nbsp; <span style="color:#94a3b8">┄</span> 1,00 = conforme au plan</div>'}
function vTrend(a){var s=E.series(histGet(),a.id),h='<h3 style="margin:14px 0 6px">Tendance hebdomadaire</h3>';
  if(s.length<2)return h+'<p class="exb-muted">Historique en cours de constitution : un relevé est enregistré chaque semaine à l\'ouverture du pilotage ('+s.length+' relevé'+(s.length>1?'s':'')+' pour ce projet). La tendance apparaît dès le deuxième.</p>';
  var t=E.trend(histGet(),a.id),last=s.slice(-8).reverse();
  return h+'<p style="margin:4px 0">CPI '+idx(t.cpi&&t.cpi.v)+arrow(t.cpi)+' &nbsp; SPI '+idx(t.spi&&t.spi.v)+arrow(t.spi)+' <small class="exb-muted">(vs semaine du '+frd(t.from)+')</small></p>'+trendChart(s.slice(-26))
   +'<div class="exb-scroll" style="overflow-x:auto"><table class="exb-table" style="min-width:420px"><thead><tr><th>Semaine du</th><th>Avanc.</th><th>CPI</th><th>SPI</th><th>Coût réel</th><th>Retard</th></tr></thead><tbody>'
   +last.map(function(p){return '<tr><td>'+frd(p.week)+'</td><td>'+fx(p.progress,0)+' %</td><td>'+idx(p.cpi)+'</td><td>'+idx(p.spi)+'</td><td>'+usd(p.ac)+'</td><td>'+(p.retard?'+'+p.retard+' sem.':'0')+'</td></tr>'}).join('')+'</tbody></table></div>'
   +'<p class="exb-muted" style="font-size:12px">Un point par semaine (le dernier relevé de la semaine est conservé), 2 ans au plus. Flèche : écart de 0,02 ou plus sur l\'indice depuis le relevé précédent. Les relevés ne sont créés que lorsque quelqu\'un ouvre le pilotage : une semaine sans ouverture n\'a pas de point.</p>'}

/* ---------- pièces d'affichage ---------- */
function card(big,small,color){return '<div class="exb-card"><b style="font-size:19px;color:'+(color||'inherit')+'">'+big+'</b><br><small>'+small+'</small></div>'}
function badge(s){return '<span style="display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:700;color:#fff;background:'+COL[s]+'">'+LAB[s]+'</span>'}
function sevIcon(s){return s==='high'?'⛔':s==='medium'?'⚠️':'ℹ️'}

function chart(a,pdf){
  if(!a.curve)return '<p class="exb-muted">Courbe disponible avec un planning Gantt daté (date de la semaine 1).</p>';
  var W=600,H=230,L=44,R=14,T=14,B=30,nW=a.weeks,ymax=Math.max(100,a.bac>0?Math.ceil(a.ac/a.bac*100/10)*10:100),
      X=function(wk){return L+(W-L-R)*wk/nW},Y=function(p){return T+(H-T-B)*(1-p/ymax)},cw=a.cw>0?Math.min(a.cw-1,nW):0,
      cwx=X(Math.max(0,(Date.parse(today())-Date.parse(a.week1||today()))/6048e5)),
      s=pdf?'<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'" font-family="Arial,Helvetica,sans-serif"><rect width="'+W+'" height="'+H+'" fill="#fff"/>':'<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;max-width:680px;height:auto" role="img" aria-label="Courbe en S : planifié, avancement et coût réel">';
  for(var g=0;g<=ymax;g+=ymax>100?20:25)s+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+Y(g)+'" y2="'+Y(g)+'" stroke="#cbd5e1" stroke-width=".6"/><text x="'+(L-6)+'" y="'+(Y(g)+4)+'" font-size="10" text-anchor="end" fill="#64748b">'+g+'%</text>';
  var step=Math.max(1,Math.ceil(nW/10));for(var k=0;k<=nW;k+=step)s+='<text x="'+X(k)+'" y="'+(H-10)+'" font-size="10" text-anchor="middle" fill="#64748b">S'+k+'</text>';
  s+='<polyline fill="none" stroke="#1a3a6b" stroke-width="2.4" points="'+a.curve.map(function(p,i){return X(i)+','+Y(p)}).join(' ')+'"/>';
  s+='<line x1="'+cwx+'" x2="'+cwx+'" y1="'+T+'" y2="'+(H-B)+'" stroke="#d97706" stroke-dasharray="4 3"/><text x="'+cwx+'" y="'+(T-3)+'" font-size="10" text-anchor="middle" fill="#d97706">aujourd\'hui</text>';
  s+='<circle cx="'+cwx+'" cy="'+Y(a.progress)+'" r="6" fill="#15803d"/><circle cx="'+cwx+'" cy="'+Y(a.bac>0?a.ac/a.bac*100:0)+'" r="6" fill="#b91c1c"/>';
  if(pdf)return s+'<text x="'+(L+6)+'" y="'+(T+12)+'" font-size="10" fill="#1a3a6b">- planifié</text><text x="'+(L+70)+'" y="'+(T+12)+'" font-size="10" fill="#15803d">● avancement acquis</text><text x="'+(L+190)+'" y="'+(T+12)+'" font-size="10" fill="#b91c1c">● coût réel (% du budget)</text></svg>';
  s+='</svg><div style="font-size:12px;margin-top:4px"><span style="color:#1a3a6b">━</span> Planifié (PV) &nbsp; <span style="color:#15803d">●</span> Avancement acquis (EV) '+fx(a.progress,0)+' % &nbsp; <span style="color:#b91c1c">●</span> Coût réel (AC) '+(a.bac>0?fx(a.ac/a.bac*100,0):'—')+' % du budget</div>';
  return s}

/* ---------- synthèse hebdomadaire (texte calculé localement) ---------- */
function synthText(rows){return E.synthese(rows||compute(),today())}
function synthBlock(rows){var t=synthText(rows);if(!t)return '';return '<details style="margin:10px 0"><summary><b>📝 Synthèse de la semaine</b> (texte prêt à envoyer)</summary><div style="white-space:pre-wrap;border:1px solid #cbd5e1;border-radius:10px;padding:10px;margin:8px 0;font-size:13px">'+esc(t)+'</div><button class="muted" onclick="EXBPILOT.copy()">📋 Copier</button></details>'}
function copySynth(){var t=synthText();if(!t)return say('Rien à copier.','warn');try{navigator.clipboard.writeText(t).then(function(){say('Synthèse copiée.','success')},function(){say('Copie impossible : sélectionnez le texte.','warn')})}catch(e){say('Copie impossible : sélectionnez le texte.','warn')}}
/* contexte transmis à l'assistant IA : réservé aux fonctions autorisées à lire projets, planning et budgets */
function aiContext(){try{if(!allowed())return '';return E.ctx(compute(),today())}catch(e){return ''}}

/* ---------- vue portefeuille ---------- */
/* ---------- seuils d'alerte ---------- */
var TH_F=[['cpiRed','CPI rouge si <',1,'x'],['cpiAmber','CPI orange si <',1,'x'],['spiRed','SPI rouge si <',1,'x'],['spiAmber','SPI orange si <',1,'x'],['vacRed','Dépassement final rouge si >',100,'%'],['vacAmber','Dépassement final orange si >',100,'%'],['delayRed','Retard rouge si ≥',1,'s'],['delayAmber','Retard orange si ≥',1,'s'],['burn','Budget consommé : vigilance dès',100,'%']];
function thPanel(scope,cur,custom){
  var sid=scope==='global'?'global':String(scope).replace(/[^\w.\-]/g,''),ro=!canW();
  return '<details style="margin:10px 0"><summary><b>⚙ Seuils d\'alerte '+(scope==='global'?'(tous les chantiers)':'de ce chantier'+(custom?' — personnalisés':''))+'</b></summary><div style="margin:8px 0">'
   +TH_F.map(function(f){var v=Math.round(cur[f[0]]*f[2]*100)/100;return '<label style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin:4px 0;font-size:13px"><span>'+esc(f[1])+'</span><span style="white-space:nowrap"><input type="number" step="any" data-thk="'+f[0]+'" value="'+v+'" '+(ro?'disabled ':'')+'style="width:80px;min-width:0"> '+(f[3]==='%'?'%':f[3]==='s'?'sem.':'')+'</span></label>'}).join('')
   +(ro?'<p class="exb-muted">Modification réservée aux fonctions qui peuvent écrire les budgets.</p>':'<div class="exb-actions"><button class="primary" onclick="EXBPILOT.thSave(\''+sid+'\',this)">Enregistrer</button><button class="muted" onclick="EXBPILOT.thReset(\''+sid+'\')">'+(scope==='global'?'Valeurs par défaut':'Reprendre les seuils généraux')+'</button></div>')
   +'<p class="exb-muted" style="font-size:12px">Le seuil rouge doit être plus sévère que l\'orange. '+(scope==='global'?'Un chantier peut avoir ses propres seuils (dans son détail).':'Ces seuils remplacent les seuils généraux pour ce chantier seulement.')+'</p></div></details>'}
function thSave(sid,btn){
  if(!allowed()||!canW())return say('Modification non autorisée.','error');
  var box=btn.closest('details'),o={};box.querySelectorAll('[data-thk]').forEach(function(i){var f=TH_F.filter(function(x){return x[0]===i.getAttribute('data-thk')})[0];if(i.value!=='')o[f[0]]=(+i.value)/f[2]});
  var v=E.validateTh(o);if(!v.ok)return say(v.errors[0],'warn');
  var cf=G('exb_pilot_th').filter(function(c){return c&&String(c.id)!==sid});cf.push({id:sid,th:o});put('exb_pilot_th',cf);say('Seuils enregistrés.','success');render()}
function thReset(sid){if(!allowed()||!canW())return say('Modification non autorisée.','error');
  put('exb_pilot_th',G('exb_pilot_th').filter(function(c){return c&&String(c.id)!==sid}));say('Seuils rétablis.','success');render()}
function globalTh(){return E.thFor(G('exb_pilot_th'),'__aucun__')}

function vList(){
  var all=compute(),rows=E.tri(all.filter(function(a){return !(st.hideClosed&&a.closed)})),T=E.consolidate(rows);
  if(!all.length)return '<p class="exb-muted">Aucun projet. Créez un projet puis son planning et son budget dans « Planning &amp; budget ».</p>';
  var h='<div class="exb-grid">'
    +card(T.rouge+' / '+T.orange+' / '+T.vert,'Projets à traiter / à surveiller / sous contrôle'+(T.gris?' ('+T.gris+' sans données)':''),T.rouge?COL.rouge:T.orange?COL.orange:COL.vert)
    +card(idx(T.cpi),'CPI du portefeuille (coût)',ic(T.cpi,.85,.95))
    +card(idx(T.spi),'SPI du portefeuille (délai)',ic(T.spi,.85,.95))
    +card(usd(T.bac),'Budget total (BAC)')
    +card(usd(T.ac),'Coût réel (AC) — '+fx(T.bac>0?T.ac/T.bac*100:0,0)+' % du budget')
    +card(usd(T.eac),'Coût final estimé (EAC)'+(T.vac<0?' — dépassement '+usd(-T.vac):''),T.vac<0?COL.rouge:'inherit')
    +'</div>'
    +'<div class="exb-actions" style="align-items:center"><label style="display:inline-flex;gap:6px;align-items:center"><input type="checkbox" style="width:auto;min-width:0;margin:0" '+(st.hideClosed?'checked':'')+' onchange="EXBPILOT.hide(this.checked)"> Masquer les projets terminés</label><button class="muted" onclick="EXBPILOT.csv()">⬇ Export CSV</button><button class="muted" onclick="EXBPILOT.pdf()">📄 PDF</button></div>'
    +synthBlock(rows)
    +'<div class="exb-scroll" style="overflow-x:auto"><table class="exb-table" style="min-width:680px"><thead><tr><th>Projet</th><th>État</th><th>Avanc.</th><th>Planifié</th><th>CPI</th><th>SPI</th><th>Retard</th><th>EAC</th><th>Alertes</th></tr></thead><tbody>'
    +rows.map(function(a){var n=a.alerts.filter(function(x){return x.sev!=='low'}).length;
      return '<tr style="cursor:pointer" onclick="EXBPILOT.open(\''+esc(String(a.id).replace(/[^\w.\-]/g,''))+'\')"><td><b>'+esc(a.name)+'</b>'+(a.closed?' <small>(terminé)</small>':'')+'<br><small class="exb-muted">'+esc(a.client)+'</small></td><td>'+DOT[a.status]+' '+LAB[a.status]+'</td><td>'+fx(a.progress,0)+' %</td><td>'+(a.planned==null?'—':fx(a.planned,0)+' %')+'</td><td style="color:'+ic(a.cpi,.85,.95)+';font-weight:700">'+idx(a.cpi)+arrow(E.trend(histGet(),a.id).cpi)+'</td><td style="color:'+ic(a.spi,.85,.95)+';font-weight:700">'+idx(a.spi)+arrow(E.trend(histGet(),a.id).spi)+'</td><td>'+(a.finPrevue==null?'—':a.retard?'<b style="color:'+COL.rouge+'">+'+a.retard+' sem.</b>':'0')+'</td><td>'+(a.eac==null?'—':usd(a.eac))+'</td><td>'+(n?'<b>'+n+'</b>':'✅')+'</td></tr>'}).join('')
    +'</tbody></table></div><p class="exb-muted">Touchez un projet pour le détail. CPI et SPI &lt; 1 = dérive de coût / de délai. Les indices du portefeuille sont pondérés par les montants.</p>'+thPanel('global',globalTh(),false);
  var al=[];rows.forEach(function(a){a.alerts.forEach(function(x){if(x.sev==='high')al.push({n:a.name,x:x,id:a.id})})});
  if(al.length)h+='<h3 style="margin:14px 0 6px">Alertes prioritaires</h3>'+al.slice(0,12).map(function(o){return '<div style="border-left:4px solid '+COL.rouge+';padding:6px 10px;margin:6px 0;background:rgba(185,28,28,.06)"><b>'+esc(o.n)+'</b> — '+esc(o.x.msg)+(o.x.hint?'<br><small class="exb-muted">'+esc(o.x.hint)+'</small>':'')+'</div>'}).join('');
  return h}

/* ---------- vue projet ---------- */
function find(id){return compute().filter(function(a){return String(a.id)===String(id)})[0]}
function vDetail(a){
  var G_=a.week1,h='<div class="exb-actions"><button class="muted" onclick="EXBPILOT.back()">← Tous les projets</button><button class="muted" onclick="EXBPILOT.pdf(\''+esc(String(a.id).replace(/[^\w.\-]/g,''))+'\')">📄 Rapport PDF</button></div>'
    +'<h3 style="margin:8px 0">'+esc(a.name)+' '+badge(a.status)+(a.closed?' <small>(terminé)</small>':'')+'</h3>'
    +'<div class="exb-grid">'
    +card(fx(a.progress,0)+' %','Avancement acquis'+(a.planned==null?'':' · planifié '+fx(a.planned,0)+' %'))
    +card(idx(a.cpi),'CPI — coût ('+(a.cv==null?'—':(a.cv>=0?'+':'')+usd(a.cv))+')',ic(a.cpi,.85,.95))
    +card(idx(a.spi),'SPI — délai ('+(a.sv==null?'—':(a.sv>=0?'+':'')+usd(a.sv))+')',ic(a.spi,.85,.95))
    +card(a.finPrevue==null?'—':(a.retard?'+'+a.retard+' sem.':'0'),'Retard prévisionnel (chemin critique)'+(a.finPrev?' — fin prévue le '+frd(a.finPrev):''),a.retard?COL.rouge:a.finPrevue==null?'inherit':COL.vert)
    +card(usd(a.bac),'Budget (BAC)')+card(usd(a.ac),'Coût réel (AC)'+(a.bac>0?' — '+fx(a.ac/a.bac*100,0)+' %':''))
    +card(a.eac==null?'—':usd(a.eac),'Coût final estimé (EAC)',a.vac!=null&&a.vac<0?COL.rouge:'inherit')
    +card(a.vac==null?'—':(a.vac>=0?'+':'')+usd(a.vac),'Écart final (VAC)',a.vac!=null&&a.vac<0?COL.rouge:COL.vert)
    +card(a.tcpi==null?'—':idx(a.tcpi),'TCPI — CPI à tenir sur le reste'+(a.tcpi>1.1?' (difficile)':''),a.tcpi>1.1?COL.rouge:'inherit')
    +'</div><h3 style="margin:14px 0 6px">Courbe en S</h3>'+chart(a)+vTrend(a)
    +'<h3 style="margin:14px 0 6px">Alertes ('+a.alerts.length+')</h3>'
    +(a.alerts.length?a.alerts.map(function(x){var c=x.sev==='high'?COL.rouge:x.sev==='medium'?COL.orange:COL.gris;return '<div style="border-left:4px solid '+c+';padding:6px 10px;margin:6px 0">'+sevIcon(x.sev)+' '+esc(x.msg)+(x.hint?'<br><small class="exb-muted">→ '+esc(x.hint)+'</small>':'')+'</div>'}).join(''):'<p>Aucune alerte. ✅</p>')
    +(a.critiques&&a.critiques.length?'<p class="exb-muted">Chemin critique : tâches '+a.critiques.join(' → ')+(a.critRetard?' — <b>'+a.critRetard+' en retard</b>':'')+'. '+a.tachesRetard+' tâche(s) en retard au total.</p>':'')
    +(a.anomalies&&a.anomalies.length?'<h3 style="margin:14px 0 6px">Anomalies de coûts à vérifier ('+a.anomalies.length+')</h3>'+a.anomalies.map(function(x){var c=x.sev==='high'?COL.rouge:x.sev==='medium'?COL.orange:COL.gris;return '<div style="border-left:4px solid '+c+';padding:6px 10px;margin:6px 0">🔎 '+esc(x.msg)+'</div>'}).join('')+'<p class="exb-muted" style="font-size:12px">Détection par règles (poste sans budget, poste à 150 % ou plus, doublons de caisse, montants hors norme) : ce sont des pistes à vérifier, pas des erreurs prouvées.</p>':'')
    +thPanel(a.id,a.thr,a.custom)
    +'<details style="margin-top:10px"><summary>Comment ces chiffres sont calculés</summary><p class="exb-muted" style="font-size:12px">Budget : '+esc(a.sources.bac==='budget'?'budget détaillé (Planning & budget)':a.sources.bac==='projet'?'budget du projet':'non renseigné')+'. Coût réel : '+esc(a.sources.ac==='budget'?'coût réel saisi dans le budget':a.sources.ac==='caisse'?'dépenses de caisse du projet':'aucun')+' (le plus élevé des deux est retenu). Avancement : '+esc(a.sources.progress)+'. Planifié : '+esc(a.sources.planned)+'. EV = BAC × avancement ; PV = BAC × planifié ; CPI = EV/AC ; SPI = EV/PV ; EAC = BAC/CPI. Les tâches n\'ont pas de coût propre : les pondérations utilisent les durées. Ces indicateurs aident à décider ; ils ne remplacent pas le jugement du conducteur de travaux.</p></details>';
  return h}

function render(){var b=$('exbpilot_box');if(!b)return;
  if(!allowed()){b.innerHTML='<p class="exb-muted">Accès réservé aux fonctions qui peuvent lire les projets, plannings et budgets.</p>';return}
  recordHist();var a=st.pid?find(st.pid):null;b.innerHTML=a?vDetail(a):vList()}

/* ---------- exports ---------- */
function cell(v){if(typeof v==='number')return String(v).replace('.',',');var s=String(v==null?'':v);if(/^[=+\-@\t\r]/.test(s))s="'"+s;if(/[;"\n\r]/.test(s))s='"'+s.replace(/"/g,'""')+'"';return s}
function csvRows(rows){var cols=['Projet','Client','Statut','Budget USD','Cout reel USD','Avancement %','Planifie %','CPI','SPI','Retard semaines','Fin planifiee','Fin prevue','EAC USD','VAC USD','Tendance CPI','Tendance SPI','Alertes'];
  var HC=histGet(),WD={up:'amelioration',down:'degradation',flat:'stable'},lines=[cols.map(cell).join(';')];rows.forEach(function(a){var tq=E.trend(HC,a.id);lines.push([a.name,a.client,LAB[a.status],a.bac,a.ac,a.progress,a.planned==null?'':a.planned,a.cpi==null?'':a.cpi,a.spi==null?'':a.spi,a.finPrevue==null?'':a.retard,a.finPlan,a.finPrev,a.eac==null?'':a.eac,a.vac==null?'':a.vac,tq.cpi?WD[tq.cpi.dir]:'',tq.spi?WD[tq.spi.dir]:'',a.alerts.filter(function(x){return x.sev!=='low'}).map(function(x){return x.msg}).join(' | ')].map(cell).join(';'))});
  return '\ufeff'+lines.join('\r\n')}
function exportCsv(){if(!allowed())return say('Accès non autorisé.','error');var rows=E.tri(compute());if(!rows.length)return say('Rien à exporter.','warn');var txt=csvRows(rows);
  try{var b=new Blob([txt],{type:'text/csv;charset=utf-8'}),a=d.createElement('a');a.href=URL.createObjectURL(b);a.download='EXB-pilotage-projets-'+today()+'.csv';d.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1500);say('Export CSV prêt ('+rows.length+' projets).','success')}catch(e){say('Export impossible sur cet appareil.','error')}return txt}
function trTxt(k,t){if(!t||!t.dir)return '';return k+' '+idx(t.v)+' '+(t.dir==='up'?'en amélioration':t.dir==='down'?'en dégradation':'stable')+' ('+(t.delta>=0?'+':'')+idx(t.delta)+')'}
function signed(v){return v==null?'—':(v>=0?'+':'-')+usd(Math.abs(v))}
function svgUrl(x){return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(x)}
function slug(t){return String(t||'projet').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'projet'}
/* le moteur PDF ne sait pas écrire ≥ ni les flèches : formulations en toutes lettres */
function thLine(t){return 'Seuils appliqués : CPI rouge sous '+idx(t.cpiRed)+', orange sous '+idx(t.cpiAmber)+' ; SPI rouge sous '+idx(t.spiRed)+', orange sous '+idx(t.spiAmber)+' ; dépassement final rouge au-delà de '+Math.round(t.vacRed*100)+' %, orange au-delà de '+Math.round(t.vacAmber*100)+' % ; retard rouge à partir de '+t.delayRed+' semaine(s), orange à partir de '+t.delayAmber+' semaine(s)'}
function reportOpts(a){
  var HH=histGet(),tr=E.trend(HH,a.id),ser=E.series(HH,a.id),
  rows=[['Chantier',a.name+(a.closed?' (terminé)':'')],['Client',a.client||'—'],['Date du rapport',frd(today())],['État global',LAB[a.status]],
    ['Avancement','Acquis '+fx(a.progress,0)+' %  /  planifié '+(a.planned==null?'non disponible':fx(a.planned,0)+' %')],
    ['Coût','Budget '+usd(a.bac)+'  |  Coût réel '+usd(a.ac)+(a.bac>0?' ('+fx(a.ac/a.bac*100,0)+' %)':'')+'  |  CPI '+idx(a.cpi)],
    ['Coût final estimé',a.eac==null?'Non calculable':usd(a.eac)+'  —  écart final '+signed(a.vac)],
    ['Délai','SPI '+idx(a.spi)+'  |  retard prévisionnel '+(a.finPrevue==null?'non calculable':a.retard+' sem.')+(a.finPrev?'  |  fin prévue le '+frd(a.finPrev):'')]];
  if(tr.n>=2){var tt=[trTxt('CPI',tr.cpi),trTxt('SPI',tr.spi)].filter(Boolean).join(' | ');if(tt)rows.push(['Tendance',tt+' | depuis la semaine du '+frd(tr.from)])}
  else rows.push(['Tendance','Historique insuffisant : un relevé est enregistré chaque semaine à l\'ouverture du pilotage.']);
  var pts=a.alerts.filter(function(x){return x.sev!=='low'});
  if(!pts.length)rows.push(['Points d\'attention','Aucun point d\'attention majeur.']);
  pts.forEach(function(x,i){rows.push(['Point d\'attention '+(i+1)+(x.sev==='high'?' (prioritaire)':''),x.msg])});
  (a.anomalies||[]).forEach(function(x,i){rows.push(['Anomalie à vérifier '+(i+1),x.msg])});
  var dec=[];pts.forEach(function(x){if(x.hint&&dec.indexOf(x.hint)<0)dec.push(x.hint)});
  dec.forEach(function(h,i){rows.push(['Décision à prendre '+(i+1),h])});
  ser.slice(-6).reverse().forEach(function(p){rows.push(['Semaine du '+frd(p.week),'Avancement '+fx(p.progress,0)+' % | CPI '+idx(p.cpi)+' | SPI '+idx(p.spi)+' | Réel '+usd(p.ac)+' | Retard '+(p.retard?p.retard+' sem.':'0')])});
  var imgs=[];if(a.curve)imgs.push(svgUrl(chart(a,true)));if(ser.length>1)imgs.push(svgUrl(trendChart(ser.slice(-26),true)));
  return {titre:'RAPPORT DE PILOTAGE DE CHANTIER',sousTitre:a.name+' — '+frd(today()),rows:rows,images:imgs,imagesTitle:'GRAPHIQUES',sigLabels:['Le Conducteur de travaux','Le Directeur'],
    notes:['Valeur acquise = budget x avancement ; CPI = valeur acquise / coût réel ; SPI = valeur acquise / valeur planifiée ; coût final estimé = budget / CPI. Avancement et planifié pondérés par les durées des tâches du planning ; coût réel = le plus élevé du coût saisi au budget et des dépenses de caisse.',thLine(a.thr)+(a.custom?' (seuils propres à ce chantier).':'.'),'Indicateurs calculés automatiquement : à valider par le conducteur de travaux avant diffusion. Les anomalies sont des pistes à vérifier, pas des erreurs prouvées.'],
    footer:'Rapport de pilotage — '+a.name+' — Excellencia Building'}}
function pdfReport(a){return w.EXBPdf.make(reportOpts(a)).then(function(x){w.EXBPdf.save(x,'rapport-pilotage-'+slug(a.name)+'.pdf');return x})}
function pdf(id){if(!allowed())return say('Accès non autorisé.','error');if(!w.EXBPdf)return say('Module PDF indisponible.','warn');
  var list=id?[find(id)].filter(Boolean):E.tri(compute());if(!list.length)return say('Rien à imprimer.','warn');if(id)return pdfReport(list[0]);var rows=[];
  var HH=histGet();
  if(!id&&list.length>1){var T=E.consolidate(list);rows.push(['Portefeuille',T.n+' projet(s) dont '+T.actifs+' en cours : '+T.rouge+' à traiter, '+T.orange+' à surveiller, '+T.vert+' sous contrôle'+(T.gris?', '+T.gris+' sans données':'')]);
    rows.push(['Indices globaux','CPI '+idx(T.cpi)+' | SPI '+idx(T.spi)+' | Budget '+usd(T.bac)+' | Réel '+usd(T.ac)+' | Coût final estimé '+usd(T.eac)])}
  list.forEach(function(a){rows.push([a.name+(a.closed?' (terminé)':''),LAB[a.status]+' — avancement '+fx(a.progress,0)+' %'+(a.planned==null?'':' / planifié '+fx(a.planned,0)+' %')]);
    rows.push(['Coût','Budget '+usd(a.bac)+' | Réel '+usd(a.ac)+' | CPI '+idx(a.cpi)+' | EAC '+(a.eac==null?'—':usd(a.eac))+' | Écart final '+(a.vac==null?'—':usd(a.vac))]);
    rows.push(['Délai','SPI '+idx(a.spi)+' | Retard prévisionnel '+(a.finPrevue==null?'—':a.retard+' sem.')+(a.finPrev?' | Fin prévue '+frd(a.finPrev):'')]);
    var tr=E.trend(HH,a.id);if(tr.n>=2){var tt=[trTxt('CPI',tr.cpi),trTxt('SPI',tr.spi)].filter(Boolean).join(' | ');if(tt)rows.push(['Tendance',tt+' | depuis la semaine du '+frd(tr.from)])}
    if(id){E.series(HH,a.id).slice(-6).reverse().forEach(function(p){rows.push(['Semaine du '+frd(p.week),'Avancement '+fx(p.progress,0)+' % | CPI '+idx(p.cpi)+' | SPI '+idx(p.spi)+' | Réel '+usd(p.ac)+' | Retard '+(p.retard?p.retard+' sem.':'0')])})}
    a.alerts.filter(function(x){return x.sev!=='low'}).forEach(function(x){rows.push([x.sev==='high'?'Alerte':'Vigilance',(x.hint?x.msg.replace(/[.\s]+$/,'')+'. Action : '+x.hint:x.msg)])})});
  w.EXBPdf.make({titre:'PILOTAGE PROJETS',sousTitre:(id?list[0].name+' — ':'')+'édité le '+frd(today()),rows:rows,notes:['CPI = valeur acquise / coût réel ; SPI = valeur acquise / valeur planifiée ; EAC = budget / CPI.','Indicateurs calculés automatiquement à partir du planning, du budget et de la caisse : à valider par le conducteur de travaux.','Tendance : écart de 0,02 ou plus sur l\'indice depuis le relevé hebdomadaire précédent ; un relevé est enregistré à l\'ouverture du pilotage.'],footer:'Pilotage projets — Excellencia Building'}).then(function(x){w.EXBPdf.save(x,'pilotage-projets.pdf')})}

w.EXBPILOT={thSave:thSave,thReset:thReset,_report:function(id){var a=find(id);return a&&reportOpts(a)},synthese:function(){try{return allowed()?synthText():''}catch(e){return ''}},aiContext:aiContext,copy:copySynth,render:render,open:function(id){st.pid=id;render()},back:function(){st.pid='';render()},hide:function(v){st.hideClosed=!!v;render()},csv:exportCsv,pdf:pdf,_compute:compute,_hist:histGet,_record:recordHist,_csv:csvRows};

/* ---------- montage : section + bouton de menu ---------- */
function mount(){if($('pilotprojet'))return;var ref=$('chantierctl')||$('plangantt')||$('terrain')||$('chantiers')||$('projets'),host=d.querySelector('.wrap')||d.querySelector('main')||d.body,s=d.createElement('section');s.id='pilotprojet';s.style.display='none';
  s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>📈 Pilotage projets</h2><p class="exb-muted">Coût, délai et alertes de chaque chantier, calculés automatiquement à partir du planning, du budget et de la caisse.</p></div></div><div id="exbpilot_box"></div></div>';
  if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
  var b=$('bctl')||$('bplan')||$('bprj');if(b&&!$('bpilot')){var n=d.createElement('button');n.id='bpilot';n.textContent='📈 Pilotage projets';n.setAttribute('onclick',"show('pilotprojet')");if(!allowed())n.setAttribute('data-exbrole','hide');b.parentNode.insertBefore(n,b.nextSibling)}
  var os=w.show;if(typeof os==='function'&&!w.__exbPilShow){w.__exbPilShow=1;w.show=function(x){var r=os.apply(this,arguments),e=$('pilotprojet');if(e)e.style.display=(x==='pilotprojet')?'':'none';if(x==='pilotprojet'){st.pid='';render()}return r}}}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(mount,1400)});else setTimeout(mount,1400);
})(window,document);
