# V100 — Confort d'usage

**Aucun SQL.** Nouveau fichier : `exb-ux-v100.js` (balise dans `index.html`, cache dans `sw.js`). Modifié : `exb-focus.js`.

1. **Devis déjà enregistrés en double** : même numéro et même projet = même devis, on garde le plus récent. Même numéro mais autre projet = renumérotation. Contenu identique sous deux numéros = un seul gardé. Nettoyage automatique à l'ouverture, copie de sauvegarde, bouton « 🧹 Nettoyer » et « ↩ Annuler le nettoyage » au-dessus de la liste des devis.
2. **Menu de gauche** : bleu foncé et doré, comme la barre des modules.
3. **Menu masqué** après le choix d'un module (ordinateur) : il reste les onglets du module. Bouton ☰ pour rouvrir le menu ; il revient seul sur l'accueil.
4. **Accueil personnalisable** : bouton « 🧩 Organiser » → glisser ⠿ ou ▲ ▼, 👁 masquer, ↺ réinitialiser. Mémorisé sur l'appareil.
5. **Plein écran** : plus de barre « Quitter » ; petit bouton rond ✕ discret sur le bord droit (déplaçable), Échap ou F quitte aussi. La barre des modules reste visible.
