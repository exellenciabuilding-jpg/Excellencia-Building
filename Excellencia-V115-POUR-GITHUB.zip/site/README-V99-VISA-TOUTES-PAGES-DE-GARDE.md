# Visa (cachet + signature) posé sur toutes les pages de garde

Fichiers modifiés : exb-pdf.js, exb-docs.js, calcul-structure/exb-calcul-doc.js, sw.js (nouvelle version de cache). Aucun SQL à exécuter.

- Page de garde (PDF génériques, devis / facture / reçu, note de calcul) : le cachet et la signature sont posés en bas de page et le cachet touche le libellé et le nom du Directeur (« Le Directeur Général », « Le prestataire », « Établi par »), comme un cachet apposé à la main ; la date de délivrance est au-dessus du visa.
- PDF génériques (budget, fiches, rapports) : si la page de garde porte le visa, le bloc cachet/signature en bas de la dernière page disparaît ; seul le QR de vérification suit, sur chaque page suivante. « Le Client » n'est gardé (seul) que si le client a signé ou si un cadre de signature est demandé ; pour les documents à libellés propres (fiche du personnel, rapport de pilotage), seul le premier cadre reste.
- Note de calcul : le bloc « Conclusion et visas » (établi / validé / maître d'ouvrage) est conservé tel quel.
