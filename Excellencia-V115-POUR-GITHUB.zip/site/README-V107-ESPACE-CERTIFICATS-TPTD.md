# V107 — Espace apprenant : certificats (QR + PDF) et TP / TD

**Mes certificats** (`espace-apprenant.html`)
- Chaque certificat délivré dans le logiciel (Formation › Certificats) est publié à l'apprenant avec son lien de vérification officiel : le QR est exactement celui du certificat imprimé et ouvre `verification.html`.
- Bouton « Télécharger PDF » (titulaire, matricule, formation, mention, n°, date, code de vérification, QR) et bouton « Vérifier ».
- Un certificat annulé reste visible, badge ANNULÉ, sans téléchargement.
- **À faire une fois :** reconnecter le logiciel au serveur ; la publication automatique de l'espace envoie les certificats toute seule (ou republier : Formation › Évaluations › 📢 Publier l'espace apprenant). `index.html` ajoute `certificats` aux données de chaque apprenant.

**Mes TP et TD**
- Lit les épreuves du matricule avec la fonction serveur existante `epreuves_pour_matricule` (aucune nouvelle fonction SQL).
- Onglets « Mes épreuves » (à faire / pas encore ouverte / clôturée) et « Réponses envoyées ».
- « Commencer » ouvre `epreuve.html?m=<matricule>&e=<épreuve>` : l'épreuve s'ouvre directement, matricule déjà renseigné.
- « Demander un TP / TD » ouvre `demande-tp-td.html?type=tp_td&m=<matricule>` avec le matricule prérempli.

Fichiers modifiés : `espace-apprenant.html`, `index.html`, `demande-tp-td.html`, `sw.js`.
Limites : non testé sur un vrai Supabase ; le QR du certificat n'est vérifiable que si le certificat a été publié au registre (logiciel connecté en administrateur).
