EXCELLENCIA BUILDING V72 — PLANS / PDF / IMPRESSION

Ajouts :
- aperçu et impression des feuilles de plans ;
- formats A4, A3, A2, A1, A0 ;
- cartouche projet / discipline / référence / indice / visa / statut ;
- impression multi-feuilles avec saut de page ;
- export fiche de contrôle PDF A4 ;
- les contenus longs ne sont pas forcés sur une seule page ;
- migration Supabase : supabase/migration-v75-droits-v69-v74.sql (V75)

Important : pour les grands formats, le navigateur propose « Imprimer / Enregistrer en PDF » avec le format de la feuille. Le dessin source reste dans le CDE.
