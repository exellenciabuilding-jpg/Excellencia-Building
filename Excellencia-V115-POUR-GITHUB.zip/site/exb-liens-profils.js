/* Excellencia Building V110g — « 🔗 Liens à envoyer » à côté de chaque profil :
   Formateurs (section Formateurs) et Apprenants (section Participants). Les liens TFL restent dans l'onglet TFL. */
(function (w) {
  'use strict';
  var GROUPES = {
    formateurs: { titre: '🔗 Liens à envoyer aux formateurs', note: 'Chaque formateur reçoit son formulaire, puis se connecte à son espace.', liens: [
      ['Formulaire formateur (candidature)', 'formateur.html', 'Voici le formulaire pour devenir formateur à Excellencia Building'],
      ['Espace formateur (connexion)', 'espace-formateur.html', 'Voici votre espace formateur : connectez-vous avec vos identifiants']
    ] },
    participants: { titre: '🔗 Liens à envoyer aux apprenants', note: 'L’apprenant s’inscrit, reçoit son matricule, puis se connecte à son espace.', liens: [
      ['Inscription apprenant', 'inscription.html?type=apprenant', 'Voici le lien pour vous inscrire à la formation Excellencia Building'],
      ['Espace apprenant (matricule + mot de passe)', 'espace-apprenant.html', 'Voici votre espace apprenant : connectez-vous avec votre matricule'],
      ['Épreuves en ligne (QCM)', 'epreuve.html', 'Voici le lien pour passer votre épreuve en ligne'],
      ['Résultats / suivi', 'resultats.html', 'Consultez vos résultats avec votre numéro de suivi'],
      ['Demande de TP / TD', 'demande-tp-td.html', 'Voici le lien pour votre demande de TP / TD']
    ] }
  };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function base() {
    try { if (typeof w.exbBase === 'function') { var b = w.exbBase(); if (b) return b; } } catch (e) { /* repli */ }
    try { if (/^https?:$/.test(w.location.protocol)) return w.location.origin + w.location.pathname.replace(/[^\/]*$/, ''); } catch (e) { /* aucun */ }
    return '';
  }
  function copier(t) {
    return (navigator.clipboard ? navigator.clipboard.writeText(t).then(function () { return true; }, function () { return false; }) : Promise.resolve(false)).then(function (ok) {
      if (ok) return true;
      try { var a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(a); a.select(); var r = document.execCommand('copy'); a.remove(); return r; } catch (e) { return false; }
    });
  }
  function dire(m, t) { try { if (typeof w.notify === 'function') w.notify(m, t || 'info', 5000); } catch (e) { /* silencieux */ } }
  function carte(id) {
    var g = GROUPES[id], b = base();
    var h = '<div class="card exb-liens-profil" style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:10px 0"><h3 style="margin:0 0 4px">' + g.titre + '</h3><p class="exb-muted" style="margin:0 0 6px">' + esc(g.note) + '</p>';
    if (!b) h += '<div class="hint" style="color:#b45309">Adresse du site introuvable : renseignez EXB_PUBLIC_URL dans brand-config.js.</div>';
    g.liens.forEach(function (x) {
      var u = b ? b + x[1] : '';
      h += '<div style="border-top:1px solid #eef2f7;margin-top:8px;padding-top:8px"><b>' + esc(x[0]) + '</b>'
        + (u ? '<input readonly onclick="this.select()" value="' + esc(u) + '" style="width:100%;margin:4px 0"><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="primary" data-exbl="copy" data-u="' + esc(u) + '">📋 Copier</button><button type="button" class="muted" data-exbl="share" data-u="' + esc(u) + '" data-t="' + esc(x[2]) + '">💬 WhatsApp / Partager</button></div>' : '')
        + '</div>';
    });
    return h + '</div>';
  }
  function injecter() {
    Object.keys(GROUPES).forEach(function (id) {
      var sec = document.getElementById(id); if (!sec || sec.querySelector('.exb-liens-profil')) return;
      var d = document.createElement('div'); d.innerHTML = carte(id); sec.insertBefore(d.firstChild, sec.firstChild);
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-exbl]') : null; if (!b) return;
    var u = b.getAttribute('data-u'), t = b.getAttribute('data-t') || '';
    if (b.getAttribute('data-exbl') === 'copy') { copier(u).then(function (ok) { dire(ok ? '✓ Lien copié : collez-le dans WhatsApp, SMS ou e-mail.' : 'Copiez le lien affiché manuellement.', ok ? 'success' : 'warn'); }); return; }
    var m = (t ? t + ' : ' : '') + u;
    if (navigator.share) navigator.share({ title: 'Excellencia Building', text: m }).catch(function () { /* annulé */ });
    else w.open('https://wa.me/?text=' + encodeURIComponent(m), '_blank');
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injecter); else injecter();
  setTimeout(injecter, 1500);
})(window);
