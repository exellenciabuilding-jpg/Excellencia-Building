/* Excellencia Building — bouton « Cartes de visite » dans l'onglet Affiches (ouvre carte-visite.html, qui garde l'accès à la session pour enregistrer la carte au registre). */
(function(){'use strict';
function add(){var h=document.querySelector('#affiches .card h2');if(!h||document.getElementById('exbCarteBtn'))return;
 var b=document.createElement('button');b.id='exbCarteBtn';b.type='button';b.textContent='🪪 Cartes de visite';b.style.cssText='margin-left:10px;font-size:13px;padding:6px 10px;vertical-align:middle';
 b.onclick=function(){window.open('carte-visite.html','exbCarte')};h.appendChild(b)}
if(document.readyState!=='loading')add();else document.addEventListener('DOMContentLoaded',add)})();
