# Visa (cachet + signature) sur la page de garde, QR seul sur les pages suivantes

Fichiers modifiés : exb-pdf.js, sw.js (nouvelle version de cache). Aucun SQL à exécuter.

1. Page de garde : le cachet et la signature du Directeur Général sont posés sur la ligne, juste au-dessus de « Le Directeur Général » (plus de chevauchement avec le texte). La date de délivrance se place au-dessus du visa.
2. Pages suivantes : si la page de garde porte déjà le visa, il n'est plus répété. Le bloc « Le Client / Le Directeur Général » en bas de la dernière page disparaît ; seul le QR de vérification (avec son code) reste, sur chaque page suivante.
3. Si le client a réellement signé (signature client fournie), sa signature reste affichée seule (« Le Client »), sans bloc Directeur.
4. Documents avec libellés de signature personnalisés (Fiche du personnel, Rapport de pilotage) : inchangés.

Test : rendu Chromium (Playwright) avant/après du « Budget mensuel », sans erreur. Pas testé avec le vrai visa.png ni sur votre Supabase.
