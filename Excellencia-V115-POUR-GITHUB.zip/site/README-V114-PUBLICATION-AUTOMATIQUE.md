# V114 — Publication automatique (espace formateur + registre des documents)

## 1. Planning -> espace formateur (automatique)
Quand vous associez un formateur à une séance (Planning), ou changez un formateur, une formation ou un inscrit,
l'espace formateur est republié tout seul (2,5 s après l'enregistrement, puis contrôle toutes les 30 s, à la reconnexion et au démarrage).
- Il faut être connecté au serveur (Inscriptions > Demandes reçues) et en ligne. Sinon la publication part dès que c'est possible.
- Une empreinte évite de republier si rien n'a changé. Un message « Espace formateur mis à jour automatiquement » confirme.
- Le bouton « Publier l'espace formateur » reste disponible (forcer / changer le WhatsApp). Si jamais publié avant, la 1re publication auto utilise le WhatsApp de l'espace apprenant.
- Seuls les formateurs APPROUVÉS avec matricule sont publiés (inchangé).

## 2. Documents -> registre de vérification (automatique)
Devis, factures, reçus, certificats, reçus de formation : à la génération, le document est publié ; s'il échoue (hors ligne, non connecté),
il est mis en file (`exb_verif_pending`) et republié automatiquement (démarrage +8 s, reconnexion, toutes les 30 s).
- Une seule fois, les documents déjà émis sont aussi publiés en silence (équivalent de « Publier les documents existants »).
- Les boutons « Publier les documents existants » et « Vérifier un document » restent utilisables.

## Fichiers modifiés
`index.html`, `exb-verif.js`, `sw.js` (cache). Vider le cache / recharger l'application après mise à jour.

## Non vérifié
Syntaxe JS contrôlée (`node --check`) ; aucun test sur un vrai serveur Supabase ni sur appareil. Tester : créer une séance avec un formateur, attendre ~3 s, ouvrir son espace.

## Correctifs V114b
- **Imprimer le reçu (TFL > Frais et paiements)** : l'erreur « R is not defined » venait d'une variable non déclarée dans `exb-tfl.js` (`recuHtml`). Corrigé.
- **Copier le lien** : l'erreur « Failed to execute 'writeText' on 'Clipboard': Document is not focused » est évitée : repli automatique sur la copie classique (`index.html`).
- **Espace formateur** : la publication automatique inclut les apprenants (matricule requis) des formations du formateur.
