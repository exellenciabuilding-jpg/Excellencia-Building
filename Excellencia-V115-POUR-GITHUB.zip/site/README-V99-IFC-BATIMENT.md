# V99 — Export IFC du bâtiment : un vrai modèle BIM

Fichiers modifiés : `calcul-structure/index.html` (nouvelle fonction `ifcBat`, encodage IFC des accents), `sw.js` (version du cache).
Tests : `node tools/test-bim/test-ifc-batiment.js` (+ exemple `tools/test-bim/batiment-3-niveaux.ifc`). Aucun nouveau SQL.

## Avant
Un bâtiment de 3 niveaux sortait en 2 objets génériques (`IFCBUILDINGELEMENTPROXY`), dans un seul niveau « Niveau 0 », en coque ouverte (`IFCOPENSHELL`) : pas de volume, pas de matériau, pas de propriétés.

## Maintenant (menu « Format DXF / BIM » → « Modèle BIM (IFC) » du bâtiment)
- **Un niveau par étage** (`IFCBUILDINGSTOREY`, nom et cote du niveau), rattachés au bâtiment et au site.
- **Un objet par élément** : `IFCCOLUMN` (un par poteau et par niveau), `IFCBEAM` (un par travée, extrudée le long de son axe), `IFCSLAB` (un par panneau ; `ROOF` au dernier niveau, `FLOOR` ailleurs). Poutres retirées et panneaux de dalle supprimés ne sont pas exportés.
- **Volumes fermés** (`IFCEXTRUDEDAREASOLID`, section rectangulaire réelle de chaque élément), avec couleurs.
- **Matériau** : béton armé (fc28 du bâtiment, `Pset_MaterialConcrete`).
- **Propriétés** : `Pset_ColumnCommon` / `Pset_BeamCommon` / `Pset_SlabCommon` (référence, porteur, intérieur) + jeu « Excellencia » (sections, portée, épaisseur, armatures longitudinales du poteau si calculées).
- **Quantités** : `Qto_ColumnBaseQuantities`, `Qto_BeamBaseQuantities`, `Qto_SlabBaseQuantities` (longueur, section, surface, volume net).
- Accents conservés (encodage IFC `\X2\…\X0\`), y compris dans les exports IFC des autres éléments (poutre, poteau, dalle, semelle, escalier).

## Convention et limites
- Chaque niveau regroupe ses poteaux (de sa base à son plancher) et son plancher haut ; la cote du niveau est celle de sa base.
- Les armatures des poteaux sont exportées en propriété (nombre et diamètre), pas en barres 3D : le calcul du bâtiment ne produit pas leur tracé détaillé.
- Les dalles recouvrent le dessus des poutres (même cote haute) : de légers scintillements d'affichage sont possibles dans certains lecteurs.

## Identifiants stables (GlobalId) — comparer deux versions
Avant : chaque export tirait des `GlobalId` au hasard (`Math.random`) ; deux exports du même bâtiment n'avaient aucun identifiant en commun.
Maintenant : le `GlobalId` (22 caractères IFC) est **calculé** à partir de l'identité de l'objet — fonction `ifcGidMaker` :
- **graine** = identifiant interne du bâtiment (`b.id`, créé une fois et conservé) ; renommer le bâtiment ne change donc aucun identifiant ;
- **clé de l'objet** = classe IFC + référence métier : poteau `A1.k` (axe + niveau), poutre `P1.AB.k`, dalle `DA1.k`, niveau `STO.k` ;
- jeux de propriétés, quantités et relations : clé de l'élément + nom du jeu (indépendante de la numérotation `#n` du fichier, qui, elle, bouge).
Résultat : même bâtiment, mêmes éléments → mêmes `GlobalId` à chaque export ; un élément ajouté, retiré ou modifié n'affecte pas les autres. Un doublon éventuel est résolu de façon déterministe.
L'export d'un élément isolé (poutre, poteau, semelle…) utilise la même méthode (graine = type + nom).
Limites : ajouter/retirer un axe ou un niveau décale les références (lettres/numéros) et donc les identifiants des éléments concernés ; la date dans l'en-tête `FILE_NAME` change à chaque export (normal).
Tests : `node tools/test-bim/test-ifc-batiment.js` (5 contrôles ajoutés : validité, unicité, stabilité entre deux exports, stabilité après modification, séparation entre bâtiments).

## BCF
Pris en charge depuis la V99 : voir `README-V99-BCF-LECTEUR-IFC.md` (export et import des observations « BIM / Issues », BCF 2.1).

## Limites du calcul du bâtiment (affichées dans l'application et la note de calcul)
- Les axes sont toujours orthogonaux.
- Les poteaux sont carrés, avec des sections par niveau seulement.
- La dégression des charges d'exploitation est appliquée par défaut (valable seulement pour l'habitation et les bureaux) ; elle se désactive par une case de l'onglet Général du bâtiment (voir `README-V99-BCF-LECTEUR-IFC.md`).
- Gravité : moyenne. La validation des calculs dans la durée reste possible grâce au journal des versions et à la validation par l'ingénieur (README-V99zl).
- Essais IFC : aucun fichier réel issu d'autres logiciels (Revit, ArchiCAD, Tekla…) n'a été testé ; les essais portent sur des maquettes synthétiques, `ifcopenshell` n'étant pas installable dans l'environnement de test. À confirmer avec des fichiers réels avant tout usage en production.
