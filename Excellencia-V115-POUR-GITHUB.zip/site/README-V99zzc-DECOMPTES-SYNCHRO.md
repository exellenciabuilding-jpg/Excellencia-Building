# V99zzc — Marchés et décomptes : synchronisation sécurisée

Avant : les marchés et décomptes (Finance › Décomptes) étaient enregistrés avec l'ancienne synchronisation individuelle (par compte). Désormais ils passent dans le **stockage versionné** de l'entreprise, comme les autres modules : partage avec l'équipe selon les droits de chaque fonction, détection de conflit, journal, licence et double authentification appliquées par le serveur.

**Installation** : 1) déployer le zip ; 2) exécuter `supabase/migration-v99zzc-decomptes-synchro.sql` (Supabase › SQL Editor › Run ; court, réexécutable ; copie les droits de « finance »).
Les décomptes déjà saisis sur un appareil sont envoyés au serveur à la première connexion qui suit.
Tests : `tools/test-rls` (43/43, dont T41 à T43 : comptable écrit, magasinier refusé, autre entreprise ne lit pas).
