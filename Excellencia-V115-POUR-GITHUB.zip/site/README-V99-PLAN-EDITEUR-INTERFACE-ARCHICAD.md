# V99 — Éditeur de plan : interface « Excellencia Arch » façon ArchiCAD 29

Fichiers modifiés : `plan-editeur/index.html` (balisage, 1 feuille de style `ac-ui`, 1 script `ac-ui-js` en fin de page) et `sw.js` (version du cache). Le moteur (dessin 2D, 3D, coupes, charpente, métré, exports) n'est pas touché : tous les boutons gardent leurs `id` et leurs gestionnaires ; les nouveaux boutons ne font que relayer les boutons existants.

Ordinateur et tablette (écran de plus de 820 px), de haut en bas et de gauche à droite :
- **Menus** : Fichier · Édition · Vue · Dessin (architecture + structure réunies) · Documentation · Options · Partage · Fenêtres · Aide.
- **Barre d'outils principale** : Flèche, annuler / rétablir / supprimer, outil actif, étage (liste + ＋), fenêtre / mode / tout de la sélection, miroir / décaler / raccorder, cadrer, 3D.
- **Palette d'outils** : Flèche, Mur, Porte, Fenêtre, Poutre, Poteau, Dalle, Toiture, Escalier, Garde-corps, Objet, Zone, Maillage — puis Cotation, Texte, Hachure, Coupe, Élévation, Détail, Document.
- **Onglets de vues** au-dessus du dessin (Plan RDC, Coupe A-A, Façade Sud, 3D…) : un onglet s'ouvre à chaque vue visitée, se ferme avec ×.
- **Navigateur du projet** (arbre : Terrain, Étages du plus haut au plus bas, Toiture, Coupes, Façades Nord / Sud / Est / Ouest, 3D) au-dessus du panneau **Propriétés et réglages**, dans une colonne de droite.
- **Barre d'état** : aide contextuelle, échelle, Cadrer, grille, ortho, accrochage.
- Menu Fenêtres : masquer / afficher palette, onglets, navigateur et propriétés, barre d'état ; plein écran de travail.

Téléphone (820 px ou moins) : disposition d'origine conservée (navigateur sous le plan, propriétés en dessous) ; les onglets de vues s'ajoutent au-dessus du plan.

Représentés mais pas encore dans le moteur (grisés, marqués « bientôt », à traiter ensuite) : **Poutre**, **Maillage**, **Élévation**, **Détail**.

Testé dans Chromium sans écran (1366 × 800 et 390 × 800) : ouverture des 8 menus, outils, onglets, étages, fenêtres, masquage des panneaux ; aucune erreur de console. Non testé sur appareil réel.
