# Cartes de travail / de membre + option « Contour »

**Aucun SQL.** Nouveau fichier : `exb-carte-travail.js` (balise ajoutée dans `index.html`, cache dans `sw.js`). `exb-affiches-studio.js` : panneau « Contour ».

## 1. Contour (cadre) : oui / non
Même style que la page de garde des devis (filet bleu épais, filet or, bande or pâle, filet fin). Une case « Afficher un contour » + choix du style (classique, double filet or, simple, fin) et des couleurs :
- **Affiches › Affiches Excellencia** : carte « Contour des affiches » (les deux affiches).
- **Affiches › Studio libre** : carte « Contour » (enregistré avec chaque affiche, exporté en PNG/PDF).
- **Affiches › Cartes** : contour des cartes.

## 2. Onglet « 🪪 Cartes de travail / membre » (Affiches)
- **Création automatique** : dès qu'une personne a un matricule (participants, formateurs, personnel approuvés, étudiants et encadreurs TFL), sa carte est créée toute seule (avec une notification). Bouton « Créer les cartes manquantes » pour les anciens matricules.
- **Catégories** : Personnel → **CARTE DE TRAVAIL** ; Formateur, Participant/Apprenant, Étudiant TFL, Encadreur TFL, Autre membre → **CARTE DE MEMBRE** (couleur et libellé propres à chaque catégorie, validité 2 ans pour le personnel, 1 an pour les autres, modifiable).
- **Autre membre** : bouton « Carte d'un autre membre » → nom, fonction, catégorie, téléphone, photo ; le matricule est généré comme les autres (NNN-NNN-NNN, sans doublon).
- Recto : photo, nom, fonction, matricule, dates. Verso : QR de vérification, consignes, signatures, ligne d'identification, n° de carte.
- **Remise** : image PNG (recto / verso), PDF recto-verso au format carte (85,6 × 54 mm), impression, message WhatsApp prêt (la carte se joint après téléchargement).
- La photo, le nom et le matricule suivent la fiche de la personne ; on peut renouveler, changer la date d'expiration ou supprimer une carte (la personne reste).

Cette carte est une carte **interne** d'Excellencia Building : elle ne reprend ni l'en-tête ni les armoiries d'un document de l'État.
