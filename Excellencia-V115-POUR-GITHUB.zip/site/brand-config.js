/* Réglages par défaut de l'édition standard.
 * setupRequired:true  → au premier lancement, l'entreprise cliente voit l'écran de configuration.
 * setupRequired:false → pas d'écran (utile pour VOTRE propre exemplaire, avec vos valeurs ci-dessous). */
window.EXB_BRAND_DEFAULT = {
  setupRequired: true
  /* Exemple d'exemplaire préconfiguré (décommentez et adaptez, puis mettez setupRequired:false) :
  , name:'Ma Société SARL', short:'Ma Société', chantier:'Ma Société Chantier',
  primary:'#173565', secondary:'#0f4aa8', accent:'#c49a38', phone:'+243…', email:'contact@…', address:'…' */
};

/* ── Adresse publique du logiciel ─────────────────────────────────────────────
 * Les liens envoyés aux apprenants, formateurs, clients… doivent toujours pointer vers le site en ligne.
 * Dans l'application Android / Windows, l'adresse interne est « https://localhost » ou « app://… » :
 * on la remplace alors par l'adresse publique ci-dessous. Sur le site en ligne, rien ne change. */
window.EXB_PUBLIC_URL = 'https://excellenciabuildingsarlu01.netlify.app';
window.exbOrigin = function () {
  try {
    var l = location, local = /^(localhost|127\.|0\.0\.0\.0|\[::1\]|::1)/i.test(l.hostname || '');
    if (/^https?:$/.test(l.protocol) && l.hostname && !local) return l.origin;
  } catch (e) {}
  return String(window.EXB_PUBLIC_URL || '').replace(/\/+$/, '');
};
window.exbBase = function () {
  try {
    var l = location, local = /^(localhost|127\.|0\.0\.0\.0|\[::1\]|::1)/i.test(l.hostname || '');
    if (/^https?:$/.test(l.protocol) && l.hostname && !local) return l.origin + l.pathname.replace(/[^\/]*$/, '');
  } catch (e) {}
  return window.exbOrigin() + '/';
};
