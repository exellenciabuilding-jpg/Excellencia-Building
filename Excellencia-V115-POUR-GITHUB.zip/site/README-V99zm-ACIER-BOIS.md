# V99zm — Ingénierie P3 : acier et bois

Construit sur V99zl (validation ingénieur, déjà en place, non modifiée) et V99zk (vent, séisme, pieux, maçonnerie).
Fichiers modifiés : `calcul-structure/index.html`, `exb-calcul-structure.js`, `exb-v99r-shell.js`, `sw.js` (cache `exb-v99zm-acier-bois-1`).

Quatre nouveaux modules, en tuiles dans « Ingénierie & Structure » et dans la barre des modules (24 tuiles au total) :

- **Poutre acier (EC3)** : profilés IPE 100–400 et HEA 100–300, nuances S235 / S275 / S355. Classe de section, flexion, cisaillement, déversement (Mcr, χLT) si la semelle n'est pas maintenue, flèche ELS.
- **Poteau acier (EC3)** : flambement selon les deux axes (courbes a/b/c), longueurs de flambement et maintiens intermédiaires, taux de travail.
- **Poutre bois (EC5)** : C18, C24, C30, D30 ; classes de service, durée de charge (kmod), kh, déversement (kcrit), cisaillement, flèches instantanée et finale (fluage kdef).
- **Poteau bois (EC5)** : flambement (λrel, kc) sur les deux axes, résistance de calcul avec kmod.

Limites (affichées dans chaque module) :
- Poutres isostatiques en charge répartie ; poteaux en compression centrée seule (pas de flexion composée).
- Acier : sections de classe 4, assemblages, appuis (voilement d'âme) non traités. Propriétés des profilés = valeurs de catalogue courantes, à confirmer avec la fiche du fournisseur.
- Bois : flèche de cisaillement, compression perpendiculaire aux fibres, entailles, assemblages, vibrations, feu non traités.
- Calculs contrôlés à la main (Mc,Rd IPE 300 = 147,6 kN.m ; Mcr à 8 m ≈ 71 kN.m) et testés dans Chromium ; non revus par un ingénieur.

Reste dans « Ingénierie P3 » : vérification par éléments finis.
Retour en arrière : restaurer les 4 fichiers de V99zl.
