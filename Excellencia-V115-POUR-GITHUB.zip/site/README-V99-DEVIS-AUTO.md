# V99 — Devis automatique depuis un plan (IFC ou PDF)

Fichiers : `exb-auto-devis.js` (nouveau), `plan-editeur/import-pdf.html` (bouton « 💰 Devis direct »), `index.html` (1 balise), `sw.js` (cache hors ligne), `tools/test-auto-devis.js`, `tools/test-auto-devis.py`, `tools/test-bim/plan-test.pdf`, `tools/check.js` (2 contrôles). **Aucun nouveau SQL.**

## Ce que ça fait
Les trois briques existaient séparément (lecteur IFC → quantités, convertisseur PDF → plan, plan → métré) mais demandaient une dizaine de gestes et aucun prix. Le bouton **🤖 Devis automatique** (à côté de « Plan PDF → éditeur ») les enchaîne, avec un écran de contrôle avant tout envoi.

**Maquette IFC / IFCZIP** : choisir le fichier → quantités par niveau et catégorie → lignes de devis avec prix de départ → contrôle → « ✅ Créer le devis dans le métré » (lignes dans *Matériaux ajoutés*, onglet Devis ouvert, nom du projet pré-rempli si vide).

**Plan PDF / image** : « 📄 Ouvrir le convertisseur » → caler l’échelle → « 🔍 Détecter les murs » → **« 💰 Devis direct »**. Le plan est chiffré avec le **même calcul et les mêmes prix que l’éditeur de plan** (murs, maçonnerie, enduit, dalle bâtie, portes, fenêtres), puis écran de contrôle. Le plan converti est aussi enregistré dans l’éditeur (comme avec « Ouvrir dans l’éditeur »), pour le compléter plus tard.

Écran de contrôle : une carte par ligne (case, désignation, quantité et prix modifiables, montant), total en direct, alertes. Fond jaune = prix à saisir (ces lignes ne sont pas comptées dans le total tant que le prix est vide). Le dernier prix validé pour chaque poste est proposé la fois suivante. Renvoyer la même maquette met les lignes à jour sans doublon.

## Règles de chiffrage IFC (modifiables à l’écran)
| Catégorie IFC | Ligne de devis | Prix de départ |
|---|---|---|
| Murs | maçonnerie, surface nette 1 face (m²) + enduit/peinture 2 faces | 14 $/m² et 7 $/m² (valeurs de l’éditeur de plan) |
| Dalles | dalle / plancher béton armé, surface en plan (m²) | 38 $/m² |
| Portes / Fenêtres | nombre, au standard 0,90 × 2,10 m et 1,20 × 1,20 m | 75 et 95 $/m² → 141,75 et 136,80 $ la pièce |
| Toitures | surface en plan, hors pente et débord (m²) | 32 $/m² |
| Poteaux, poutres, fondations, escaliers | volume (m³) | **aucun prix : à saisir** (non inventé) |
| Autres catégories | non chiffrées, signalées en alerte | — |

## À savoir avant de s’en servir
- **Tout est indicatif** : le devis n’est jamais envoyé au client automatiquement ; client, validité et prix restent à vérifier.
- **Murs IFC** : surface estimée sur la géométrie (chants et retours d’ouverture inclus) ; mesurée à +7 % sur la maquette de test. Les dimensions de portes et fenêtres sont supposées (l’IFC ne fournit ici que le nombre).
- **PDF** : un PDF n’a pas de géométrie exacte. La détection lit des murs pleins (noirs / gris foncé) sur une image ; l’échelle doit être calée sur une cote. Pièces, sols, toiture et équipements ne sont pas détectés. Un PDF scanné ou en double trait donnera un devis incomplet (l’alerte l’indique).
- Les prix de départ sont ceux de l’éditeur de plan, en dollars ; ils sont à ajuster à votre marché.

## Tests
- `node tools/test-auto-devis.js` : 21/21 (surface de mur ≤ +12 % du réel, prix, ordre des lignes, unités mm corrigées, maquette vide, catégories sans règle, lignes du plan).
- `python3 tools/test-auto-devis.py` : 21/21 dans un vrai navigateur (IFC villa → contrôle → métré → onglet Devis ; renvoi sans doublon ; prix mémorisé ; PDF généré → détection → devis direct : murs 32,97 ml, dalle 47,92 m², porte détectée ; aucune erreur JavaScript).
- `node tools/check.js` : 488 réussis, 5 échecs **déjà présents dans l’archive d’origine** (anciens noms de cache `exb-v99zzv-tfl-sujets`, `…-tfl-banque`, etc. : contrôles périmés, sans lien avec ce lot).
- Non testé : vrai téléphone Android, vrai PDF d’architecte, maquette IFC de grande taille, appli avec code d’activation (le test retire l’écran de verrouillage).
