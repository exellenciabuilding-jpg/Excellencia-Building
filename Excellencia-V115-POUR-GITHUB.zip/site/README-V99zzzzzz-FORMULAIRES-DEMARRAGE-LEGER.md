# V99zzzzzz — Formulaires séparés (un fichier chacun) + démarrage léger en ligne

## 1. Lenteur (8 à 10 min) quand la connexion est ouverte
Cause : à l'ouverture, le logiciel connecté à Supabase téléchargeait TOUTES les demandes en ligne AVEC leurs photos (jusqu'à 200 inscriptions + 500 autres fiches, photos en base64 = plusieurs dizaines de Mo). Hors connexion, ce téléchargement n'a pas lieu, d'où l'ouverture rapide.
- La liste des demandes se charge SANS photos (quelques Ko). Les photos arrivent ensuite, 2 par 2, seulement pour l'onglet ouvert et les demandes non importées (20 max). Elles sont aussi chargées au moment de « Importer » / « Remplir ».
- Rien n'est demandé au serveur pendant les 6 premières secondes (demandes) et 12 premières secondes (synchronisation).
- Service worker : plus de revalidation de ~140 fichiers à chaque ouverture ; la vérification des mises à jour se fait en arrière-plan, 2 fichiers à la fois.

## 2. Formulaires qui montraient toujours « Apprenant »
Chaque formulaire a maintenant son PROPRE fichier, sans dépendre de `?type=` ni d'une redirection Netlify :
| Profil | Lien |
|---|---|
| Apprenant | /inscription.html |
| TP / TD | /demande-tp-td.html |
| Formateur | /formateur.html |
| Client | /client.html |
| Personnel | /personnel.html |
| Demande de logiciel | /logiciel.html |
| BTP · Architecture · Divers | /btp.html |
Les boutons « copier / envoyer le lien » du logiciel et du site vitrine utilisent ces liens. Les anciens liens `inscription.html?type=...` fonctionnent toujours. `_redirects` ne redirige plus ces adresses.

## Après mise à jour
1. Déposer le ZIP sur Netlify. Pas de SQL.
2. Ouvrir le logiciel deux fois (la première fois, les fichiers se retéléchargent une fois).
3. Recopier les NOUVEAUX liens depuis chaque onglet (Formateurs, Clients…) : l'ancien lien déjà envoyé reste valable.
Contrôles : `node tools/check.js` (412 réussis).
