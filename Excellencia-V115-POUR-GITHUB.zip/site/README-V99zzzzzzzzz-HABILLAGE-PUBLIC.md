# V99zzzzzzzzz — Habillage des pages publiques (image Excellencia Building en fond)

Nouvelle feuille de style commune `exb-public.css`, liée dans : inscription, client, formateur, personnel, btp, logiciel, demande-tp-td (formulaires), epreuve (Mes épreuves), resultats (Résultats clients) et apprenant (Mes résultats).

- **Fond** : l'image Excellencia Building (`splash-fond.jpg`) derrière la page, au lieu du fond blanc.
- **Carte centrée** presque blanche, liseré bleu / or en haut, logo à gauche, grand titre « Bienvenue à Excellencia Building », sous-titre « Espace sécurisé », champs larges, gros bouton bleu (même esprit que la page de l'institut, avec l'identité Excellencia Building).
- Espace apprenant : logo + titre de bienvenue dans la carte de connexion, bandeau translucide.
- Impression des épreuves inchangée (le fond ne s'applique qu'à l'écran).
- Aucun SQL. Cache PWA : `exb-v99zzz-tfl-sans-limite-habillage-5` ; ouvrir le logiciel deux fois après déploiement.
- Non modifiés : portail client à jeton (`portail.html`), pages TFL, vérification de documents.

## Suite : autres pages habillées
Portail de suivi client (`portail.html`, thème clair forcé), espace TFL (`tfl-portail.html`), candidature TFL, sujets TFL, fiche étudiante, dépôt de TFL résolu, vérification de document et formulaire hors connexion : même image de fond et même carte. Les bandeaux marine existants sont conservés ; un logo est ajouté quand il n'y en avait pas.
