# V99zzq — Module TFL en mode local autonome

Le module TFL (Travaux de Fin de Licence) fonctionne **sans serveur ni SQL**, exactement comme les apprenants : tout reste sur l'appareil de l'administration.

## Parcours
1. **Préparer et envoyer** — onglet **🎓 TFL** (menu Formation). Saisissez le nom/téléphone de l'étudiant (facultatif, pré-remplit son formulaire) puis « 📤 Envoyer le formulaire » (WhatsApp…) ou « ⬇ Télécharger ». Le fichier envoyé est `tfl-formulaire.html`.
2. **L'étudiant remplit sans Internet** et touche « Enregistrer et envoyer » : un fichier `EXB-TFL-Nom.json` est créé. Ses réponses sont gardées sur son appareil tant qu'il n'a pas envoyé.
3. **Vous importez la copie** — « ② Importer les copies reçues » (un ou plusieurs .json). Un fichier déjà importé n'est pas recréé. Les anciens boutons « Formulaires hors connexion » acceptent aussi ces fichiers.
   - la copie est enregistrée, le dossier reçoit son numéro **TFL-AAAA-0001** (compteur par année) et le statut **Reçu** ;
   - si l'étudiant renvoie sa copie après une demande de complément, le **même dossier** est mis à jour.
4. **Matricule** — dans le dossier : « 🔢 Attribuer le matricule » (format 000-000-000, unique parmi apprenants, formateurs, personnel et étudiants TFL). Un étudiant déjà inscrit comme apprenant (même téléphone ou e-mail) **garde son matricule**. Saisie manuelle possible (refusée si déjà pris). L'acceptation d'un dossier attribue le matricule s'il manque. Le matricule que l'étudiant écrit dans son formulaire est seulement affiché : c'est vous qui décidez.
5. **Décision** — Reçu → En vérification → Complément demandé / Accepté / Refusé / Clos (motif obligatoire pour refus et complément). **Encadreur** : affectation seulement après acceptation, charge maximale respectée. Validation du sujet (Excellencia Building / université), étape 1–9, progression, historique daté.
6. **Sorties** — attestation de dépôt en PDF (numéro + matricule + photo), message WhatsApp à l'étudiant, sauvegarde/restauration JSON de toutes les données TFL.

## Données (clés locales)
`exb_tfl_etudiants`, `exb_tfl_dossiers`, `exb_tfl_encadreurs`, `exb_tfl_compteurs`, `exb_tfl_done`, `exb_tfl_historique`, `exb_tfl_prepares`. Les noms de champs reprennent `supabase/migration-v99zzq-tfl.sql` (matricule inclus) pour une synchronisation ultérieure.

## Limites
- Données sur l'appareil : faites des sauvegardes (« ⬇ Sauvegarde »). Pas de pièces jointes (chapitres, plans) en mode local : elles relèvent du mode serveur (bucket `tfl-documents`).
- Pas de compte étudiant/encadreur en mode local (ce sont les portails du mode serveur, migration SQL non exécutée à ce jour).
- Le numéro WhatsApp commençant par 0 est converti en +243.

## Contrôles
`node tools/test-tfl/test.js` (logique) · `node tools/check.js` (ensemble, 357 contrôles). Vider le cache / recharger l'application après mise à jour (cache `exb-v99zzq-tfl-local`).

## Alignement sur l'architecture TFL (14 images)
- Parcours en 9 étapes nommées (candidature reçue → clôture), avancées automatiquement par les décisions et l'affectation.
- Module 03 : analyse du sujet (pertinence, faisabilité, délimitation, données) + corrections à demander.
- Module 04 : encadreurs avec domaines (génie civil, architecture, travaux, autres), spécialités, disponibilité et charge ; les spécialistes du domaine du sujet sont proposés en premier (★).
- Rappel affiché : « validé par l'université » seulement si réellement accordé ; contrôle technique par un professionnel qualifié pour les calculs de structure.
- Pas encore en local : bibliothèque de documents (05), corrections par chapitre (06), rendez-vous/échéances (07), défense (08), tableau de bord et rapports (09), portails étudiant/encadreur (mode serveur).
