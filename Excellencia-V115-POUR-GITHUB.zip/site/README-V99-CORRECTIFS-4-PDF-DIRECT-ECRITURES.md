# V99 correctifs 4 — PDF direct du calcul de structure + choix de la taille des écritures

## PDF direct (Windows, navigateur)
Le bouton « 📄 PDF » du calcul de structure ne passe plus par la boîte d'impression Windows (« Microsoft Print to PDF », sans aperçu). `calcul-structure/exb-pdf-direct.js` fabrique le PDF dans la page : page de garde, pages de calcul A4, plans A4/A3 paysage, pied de page et filigrane BROUILLON sur chaque feuille, coupures entre deux lignes de tableau. Windows : « Enregistrer sous » puis ouverture dans le lecteur PDF. Android : le moteur « téléphone » existant est conservé. Le bouton « Imprimer » garde l'impression classique.
Les textes du PDF sont des images haute résolution (non sélectionnables).

## Écritures
`calcul-structure/exb-calcul-lisible.js` : sélecteur « Écritures : Normal / Grand / Très grand » dans la barre de l'aperçu (Grand par défaut), pour les notes (texte, tableaux, titres, page de garde) et les plans (cotes, légendes, tableau des aciers, cartouche, traits).

## Affiches
Aucun changement : le logo modifiable et le « Studio libre » (exb-affiches-studio.js) de la version précédente sont conservés.

Fichiers : calcul-structure/exb-pdf-direct.js, exb-calcul-lisible.js (nouveaux), exb-calcul-doc.js, calcul-structure/index.html, sw.js, electron/preload.js, electron/main.js (ouverture du PDF enregistré).
Retour en arrière : retirer les deux balises <script> ajoutées dans calcul-structure/index.html.
