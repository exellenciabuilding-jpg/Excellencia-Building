# Fusion : V99 (LOT 9 trou de toit / lucarne) + dossier de travail V104-106

Base : Excellencia-Building-V99-PLAN-EDITEUR-LOT9-TROU-TOIT-LUCARNE (emballage Android/Windows, tout le site, éditeur de plan).
Apporté depuis V104-106 : un seul fichier différait, `site/plan-editeur/index.html`.
Aucune ligne de la V99 n'a été supprimée : le dossier V104-106 ne fait qu'ajouter deux blocs à la fin du script de l'éditeur.

## Relecture et corrections faites lors de la fusion (testé dans un vrai navigateur)
1. Bug du dossier V104-106 : le bloc V100 était placé APRÈS la fermeture du script principal, donc il ne trouvait aucune fonction (erreur « snapPt is not defined » au chargement, panneau affiché mais mort). Corrigé : la fermeture est déplacée après V100.
2. V101 gardait en mémoire l'ancienne liste de groupes : après annuler / ouverture d'un autre plan, les groupes auraient été perdus ou rattachés au mauvais plan. Corrigé : la liste est relue dans le plan courant à chaque fois.
3. Les deux panneaux (V100 et V101) sont repliés par défaut, pour ne pas masquer les réglages sur téléphone.
4. Les deux panneaux sont déplaçables : glisser leur titre ; clic = ouvrir/fermer ; double-clic = retour à la position d'origine. La position est mémorisée et le panneau reste toujours atteignable (jamais entièrement hors écran).

## Ce qui est ajouté dans l'éditeur de plan
- V100 (lots 10-13) : panneau « Dessin intelligent » (en bas à droite) — baguette (Espace + clic), choix de ce qu'elle crée, modes de pose, verrouillage de direction, application aux outils mur/pièce/toit/cote.
- V101 (lots 14-15) : panneau « Retouche et sélection » (en bas à gauche) — retouche géométrique sur la sélection courante (distances en mètres), groupes, sélection par critères (type, épaisseur).
- Les données V99 sont lues telles quelles (pas de migration) ; les groupes sont gardés dans `D.meta.v101groups`.

## Testé : chargement sans erreur, baguette (mur, contour fermé, création de zone), pose rectangle, tracé relatif, raccorder, diviser, grouper, dégrouper, recherche par critères, annuler.

## Non fait / à tester (voir ETAT-V104-V106.md)
Aucun test interactif n'a été fait. Les critères V104 (import DXF/PDF vectoriel, dalle BIM indépendante), V105 (couches, profils, hachures) et V106 (mur-rideau, voûte, lucarne, fenêtre d'angle) ne sont pas validés.

5. Maj sur les murs et menu des modules latéral personnalisable : voir README-V99-MENU-MODULES-LATERAL-COULEURS.md.
