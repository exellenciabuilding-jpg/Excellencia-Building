# V99zv — Suivi d'erreurs et métriques d'usage

**Ce que ça change** : l'application note toute seule les erreurs qui surviennent chez vous et chez vos clients (erreur JavaScript, promesse rejetée, script qui ne se charge pas, `console.error`) et les remonte au serveur. Vous voyez ce qui casse, sur quelle version, sur combien d'appareils, sans attendre qu'un client appelle.

**Installation**
1. Déployer les fichiers de cette version (nouveau fichier `exb-errors.js`, chargé en premier dans `index.html`).
2. Supabase › SQL Editor : exécuter `supabase/migration-v99zv-suivi-erreurs.sql` (une seule fois, réexécutable).
3. Ouvrir l'application : Espace propriétaire › carte « 🐞 Erreurs et usage ».

**Fonctionnement**
- Chaque appareil garde un journal local de 50 erreurs distinctes (clé `exb_errlog`, hors synchronisation et hors sauvegarde).
- Envoi automatique quand l'appareil est **en ligne et connecté** (au plus toutes les 30 s, 40 erreurs par session). Hors ligne ou non connecté : le journal attend.
- Une même erreur n'est pas dupliquée : elle augmente un compteur (empreinte = type + message + première ligne de la pile).
- Une erreur marquée « Résolue » qui revient est rouverte automatiquement.
- Métriques par jour et par utilisateur : sessions, erreurs, écrans ouverts (compteurs seulement).

**Vie privée** : aucun contenu saisi (clients, montants, notes) n'est lu. Les messages sont nettoyés : e-mails, jetons, nombres de 6 chiffres ou plus et paramètres d'adresse sont remplacés. Pile limitée à 900 caractères.

**Sécurité serveur** : les tables n'ont aucune politique d'accès direct ; tout passe par `erreur_signaler` (utilisateurs connectés, 200 signalements par heure, tailles plafonnées), `owner_erreurs` et `owner_erreur_resoudre` (propriétaire de la plateforme seulement). Purge automatique : 90 jours (erreurs), 180 jours (usage).

**Sur chaque appareil** (Espace propriétaire › Erreurs et usage) : voir le journal local, « Copier le journal » (à envoyer pour dépanner un téléphone), « Envoyer maintenant », « Vider ».

**Limites connues** : les erreurs survenant avant la connexion restent sur l'appareil jusqu'à la connexion. Le SQL n'a pas été exécuté sur un vrai Supabase : le tester d'abord sur le projet de recette. Pas de remontée des erreurs du site vitrine ni du calculateur de structure (autres pages).

**Tests** : `node tools/test-errors.js` (18/18), `node tools/check.js` (283/283).
**Retour en arrière** : retirer la balise `exb-errors.js` de `index.html`.
