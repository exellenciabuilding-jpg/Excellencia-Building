/* Excellencia Building V98 — navigation mobile : une seule partie à l'écran.
 * Sur téléphone / petite fenêtre (≤ 900 px) : dès qu'on ouvre une partie (Inscriptions, Reçus, Finances…), le menu se replie,
 * seule la partie ouverte reste affichée en haut de l'écran, avec un bouton « ⬅ Menu ». Le bouton Retour du téléphone ramène au menu.
 * Sur ordinateur (> 900 px) : rien ne change. */
(function(w,d){'use strict';
var MAXW=900,BAR_ID='exbNavBar',pushed=false,busy=false;
function small(){return (w.innerWidth||1200)<=MAXW}
function tabs(){return d.querySelector('#app .tabs')}
function bar(){
  var b=d.getElementById(BAR_ID);if(b)return b;
  var t=tabs();if(!t||!t.parentNode)return null;
  b=d.createElement('div');b.id=BAR_ID;b.className='no-print';
  b.style.cssText='display:none;position:sticky;top:0;z-index:900;background:#173565;padding:8px 10px;margin:0 0 10px;border-radius:0 0 12px 12px;box-shadow:0 2px 8px rgba(0,0,0,.18)';
  var k=d.createElement('button');k.type='button';k.id=BAR_ID+'Btn';k.textContent='⬅ Menu';
  k.style.cssText='background:#fff;color:#173565;border:0;border-radius:10px;padding:10px 16px;font:700 16px Arial,sans-serif;width:100%;text-align:left';
  k.onclick=function(){goMenu()};
  b.appendChild(k);t.parentNode.insertBefore(b,t);return b}
function setMode(inSection){
  var t=tabs(),b=bar();if(!t)return;
  if(inSection&&small()){t.style.display='none';if(b)b.style.display='block'}
  else{t.style.display='';if(b)b.style.display='none'}}
function goMenu(){
  if(typeof w.show==='function'){busy=true;try{w.show('dashboard')}finally{busy=false}}
  if(pushed){pushed=false;try{w.history.back()}catch(e){}}
  try{w.scrollTo(0,0)}catch(e){}}
function install(){
  if(w.__exbNavV98||typeof w.show!=='function')return;w.__exbNavV98=true;
  var orig=w.show;
  w.show=function(x){
    var r=orig.apply(this,arguments);
    try{
      var inSection=!!x&&x!=='dashboard';
      setMode(inSection);
      if(inSection&&small()){
        if(!pushed&&!busy){try{w.history.pushState({exbNav:1},'');pushed=true}catch(e){}}
        w.scrollTo(0,0)}
    }catch(e){}
    return r};
  w.addEventListener('popstate',function(){
    var t=tabs();
    if(pushed&&t&&t.style.display==='none'){pushed=false;busy=true;try{orig.call(w,'dashboard');setMode(false)}finally{busy=false}}});
  w.addEventListener('resize',function(){var t=tabs();if(t&&!small()){t.style.display='';var b=d.getElementById(BAR_ID);if(b)b.style.display='none'}});}
w.EXB_NAV_V98={install:install,setMode:setMode,goMenu:goMenu,small:small};
if(d.readyState==='complete')setTimeout(install,0);else w.addEventListener('load',function(){setTimeout(install,0)});
})(window,document);
