# V99zzd — Correctif des volumes IFC (dalles, éléments en altitude)
Le sens des faces des solides extrudés (dalles, murs…) était incohérent : le volume du panneau « Quantités » était faux pour les grandes dalles ou les éléments situés en hauteur (ex. dalle de toiture 402 m³ au lieu de 19,8 m³). Corrigé dans `exb-ifc3d.js` ; test de non-régression dans `tools/test-bim/test.py` avec la maquette `tools/test-bim/villa.ifc` (villa R+1) et le plan `villa-RDC.dxf`.
Aussi : cases à cocher des catégories du lecteur 3D mieux alignées. Aucun SQL.
