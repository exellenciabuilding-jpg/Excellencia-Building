# V99zzzz — Activer les formulaires TP/TD, formateur, client, personnel

Cause du message « ne sont pas encore activés sur le serveur » : la table `formulaires` (et ses fonctions d'envoi) n'existe pas dans Supabase.

1. Supabase › SQL Editor › New query › coller `supabase/migration-v99zzzz-formulaires.sql` › Run (réexécutable sans danger).
2. Dans le logiciel, touchez ↻ Actualiser : le message disparaît.
3. Chaque demande arrive dans son onglet (Clients, RH, Formateurs, TP/TD). « ⬇ Importer » crée la fiche : la personne apparaît ensuite dans toutes les listes de choix de l'application.

## Démarrage plus rapide
- L'écran de chargement ne reste plus 2,4 s de plus après le chargement : il disparaît dès que l'application est prête (maximum 4 s).
- Ouverture : si le serveur met plus de 2,5 s à répondre, la version déjà enregistrée sur l'appareil s'ouvre tout de suite (la nouvelle se met à jour en arrière-plan).
- Installation hors connexion plus solide : un fichier manquant n'empêche plus l'installation.
- Après mise à jour : ouvrir le logiciel deux fois (le cache passe en `exb-v99zzz-tfl-sans-limite-rapide`).
