# V99 — Éditeur de plan, Priorité 3 / lot 1 : mur-rideau, voûte, lucarne, fenêtre d'angle

Fichiers modifiés : `plan-editeur/index.html`, `vue3d.js`, `coupes.js`, `catalogue.js`, `symboles.js`, `sw.js` (version du cache).
Clés facultatives ajoutées au plan : `mx`, `my` (modules d'un mur-rideau) et `cg` (jumelage d'une fenêtre d'angle) sur une ouverture. Un plan existant s'ouvre et se calcule comme avant.
Base : archive V99-GUIDES-XYZ avec le lot « murs composites + angles » (V99-PLAN-EDITEUR-LOT3) désormais intégré.

## Mur-rideau
- Menu Documentation/Ouvertures › **🏢 Mur-rideau** : touchez un mur, il pose une façade vitrée de 3 m de large, du sol à 10 cm sous le plafond. Ou bien fiche d'une ouverture › Type › Mur-rideau.
- Fiche : largeur, hauteur, allège, **module horizontal** et **module vertical** (défaut 1,20 × 1,50 m). Les meneaux et traverses sont répartis pour tomber juste.
- Plan 2D : bande vitrée et trait de meneau à chaque module. 3D : cadre, meneaux, traverses, vitrage. Façades et coupes : quadrillage des modules.
- Nomenclatures : repère **MR1, MR2…** ; menus Type avec « Mur-rideau ». Quantités : rubrique « Mur-rideau … (modules …) » ; devis : ligne propre, prix indicatif 320 / m² modifiable dans Prix.

## Fenêtre d'angle
- Sélectionnez une fenêtre ou un mur-rideau près d'un angle en L, puis **⌐ Fenêtre d'angle** (menu Ouvertures ou fiche). Une jumelle de mêmes dimensions est posée sur l'autre mur et les deux sont collées à l'angle : le vitrage tourne l'angle sans poteau.
- Refus avec message si l'angle est en T ou à trois murs, si le mur est courbe, ou si une autre ouverture occupe déjà l'angle.
- Les deux ouvertures restent indépendantes (taille, allège) ; elles sont comptées comme 2 fenêtres, avec la mention « dont fenêtres d'angle (paires) » dans les quantités.

## Voûte en berceau
- Menu Structure › **⌓ Voûte**. Demi-ellipse sur la largeur, extrudée sur la profondeur, coque de 20 cm. Réglages : largeur, profondeur, hauteur (flèche), rotation, **altitude du bas** (par défaut : sommet des murs).
- Plan : rectangle avec nervures et axe en pointillé. 3D : coque avec intrados. Coupes : arc.

## Lucarne
- Menu Structure › **⌂ Lucarne** : lucarne à deux versants (joues, façade vitrée, toit à faîtage perpendiculaire à la pente). Réglages : largeur, profondeur, hauteur, rotation, **altitude du bas** (défaut : sommet des murs + 30 cm, à ajuster sur la pente du toit).
- Plan : rectangle avec faîtage et fenêtre côté façade. 3D et coupes : toit triangulaire.

## Limites
- La voûte et la lucarne sont des objets posés (comme le mobilier) : elles ne découpent pas encore le toit ni les murs. Les opérations booléennes (priorité suivante) permettront de couper un toit ou un mur par une lucarne ou une voûte.
- Voûte : profil demi-ellipse uniquement (pas d'arc brisé ni segmentaire). Lucarne : deux versants seulement (pas de lucarne rampante ou à croupe).
- Mur-rideau : un seul panneau rectangulaire par ouverture, sans vantaux ouvrants ni remplissages pleins. Modules en vue de coupe partielle comptés sur la portion visible.
- Fenêtre d'angle : angles en L de murs droits uniquement.
- Testé sous Chromium sans écran : pose et jumelage par la fonction, plan 2D, rendu 3D (WebGL), façades Nord et Sud, coupe A-A, aucune erreur de console. Non testé sur appareil Android / Windows réel ni exports IFC / DXF de ces nouveaux objets.
