/* Excellencia Building V99zze — Mémoire du travail + alertes sonores.
 * 1) MÉMOIRE : quand vous quittez un onglet (devis, architecture, finance…) puis y revenez — ou rechargez la page —
 *    ce que vous aviez saisi sans l'enregistrer est remis tel quel. Brouillons gardés 14 jours sur cet appareil, effacés à la déconnexion.
 *    Option : rouvrir la dernière page consultée (dans les 12 h).
 * 2) ALERTES : son (carillon / bip / cloche), annonce vocale et notification du navigateur dès qu'une demande arrive
 *    (inscription d'apprenant, TP/TD, client, formateur, personnel, demande de logiciel ou de projet, portail, copies d'évaluation).
 * Aucun serveur, aucun SQL : tout est local ; les demandes sont lues par la réception en ligne déjà existante. */
(function (w, d) {
  'use strict';
  var KEEP = 'exb_keep_v1', CFG = 'exb_alert_cfg', SEEN = 'exb_alert_seen', LAST = 'exb_last_page', MEMC = 'exb_mem_cfg';
  var DAY = 864e5;
  function lg(k, def) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function ls(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  function $(i) { return d.getElementById(i); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ====================== 1. MÉMOIRE DU TRAVAIL ====================== */
  function mcfg() { var c = lg(MEMC, {}); return { keep: c.keep !== false, reopen: c.reopen !== false }; }
  function secOf(el) { return el.closest && el.closest('section[id]'); }
  function eligible(el) {
    if (!el || el.disabled || el.readOnly) return false;
    var t = (el.type || '').toLowerCase();
    if (el.tagName === 'INPUT' && /^(password|file|hidden|button|submit|reset|image)$/.test(t)) return false;
    if (el.closest('[data-nokeep],.exb-nokeep')) return false;
    var s = secOf(el); if (!s || s.closest('#loginScreen')) return false;
    return true;
  }
  function fields(sec) { return [].slice.call(sec.querySelectorAll('input,select,textarea')).filter(eligible); }
  function sigOf(el) { return String(el.placeholder || el.getAttribute('aria-label') || (el.labels && el.labels[0] && el.labels[0].textContent) || '').trim().slice(0, 40); }
  function keysOf(sec) {
    var n = 0, out = [];
    fields(sec).forEach(function (el) { out.push({ el: el, k: el.id ? '#' + el.id : (el.name ? 'n:' + el.name + ':' + (el.type === 'radio' || el.type === 'checkbox' ? el.value : '') : '@' + (n++) + ':' + el.tagName + ':' + (el.type || '')) }); });
    return out;
  }
  function defSel(el) { var i = 0; [].forEach.call(el.options, function (o, j) { if (o.defaultSelected) i = j; }); return i; }
  function isDirty(el) {
    var t = (el.type || '').toLowerCase();
    if (el.tagName === 'SELECT') return !el.multiple && el.selectedIndex !== defSel(el);
    if (t === 'checkbox' || t === 'radio') return el.checked !== el.defaultChecked;
    return el.value !== el.defaultValue;
  }
  function valOf(el) { var t = (el.type || '').toLowerCase(); return (t === 'checkbox' || t === 'radio') ? !!el.checked : el.value; }
  function store() { var s = lg(KEEP, {}), now = Date.now(); Object.keys(s).forEach(function (k) { if (!s[k] || now - s[k].t > 14 * DAY) delete s[k]; }); return s; }
  function save(s) {
    var txt = JSON.stringify(s);
    while (txt.length > 400000) { var ks = Object.keys(s).sort(function (a, b) { return s[a].t - s[b].t; }); if (!ks.length) break; delete s[ks[0]]; txt = JSON.stringify(s); }
    try { localStorage.setItem(KEEP, txt); } catch (e) { }
  }
  function visibleSections() { return [].slice.call(d.querySelectorAll('section[id]')).filter(function (s) { return s.style.display !== 'none' && s.offsetParent !== null && !s.closest('#loginScreen'); }); }
  /* V110 : contexte (vue / dossier ouvert) fourni par les écrans qui se redessinent entièrement (ex. TFL) */
  function kid(sec) { var c = ''; try { c = w.EXB_KEEPCTX ? String(w.EXB_KEEPCTX(sec.id) || '') : ''; } catch (e) { } return sec.id + (c ? '|' + c : ''); }
  function fsig(sec) { var t = keysOf(sec).map(function (o) { return o.k; }).join(','), h = 0, i; for (i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) | 0; return String(h); }
  var act = {};
  function snapshot(sec) {
    if (!sec || !mcfg().keep) return;
    var f = {}, n = 0;
    keysOf(sec).forEach(function (o) { if (isDirty(o.el)) { var v = valOf(o.el); if (typeof v === 'string' && v.length > 20000) return; f[o.k] = { v: v, s: sigOf(o.el) }; n++; } });
    var s = store(), K = kid(sec), g = fsig(sec);
    if (n) s[K] = { t: Date.now(), f: f, g: g };
    else if (!s[K] || !s[K].g || s[K].g === g) delete s[K]; /* écran remplacé par un autre : on garde le brouillon de l'ancien */
    save(s);
  }
  function snapshotVisible() { visibleSections().forEach(snapshot); }
  var touched = {};
  function restore(sec, force) {
    if (!sec || !mcfg().keep || (touched[sec.id] && !force)) return 0;
    var rec = store()[kid(sec)]; if (!rec) return 0;
    var n = 0;
    keysOf(sec).forEach(function (o) {
      var r = rec.f[o.k]; if (!r || isDirty(o.el)) return;
      if (r.s && sigOf(o.el) && r.s !== sigOf(o.el)) return;
      var el = o.el, t = (el.type || '').toLowerCase();
      if (t === 'checkbox' || t === 'radio') { if (el.checked === !!r.v) return; el.checked = !!r.v; }
      else if (el.tagName === 'SELECT') { var ok = [].some.call(el.options, function (op) { return op.value === r.v; }); if (!ok) return; el.value = r.v; }
      else { if (el.value === r.v) return; el.value = r.v; }
      n++; try { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { }
    });
    return n;
  }
  function restoreVisible() { visibleSections().forEach(function (s) { var n = restore(s); if (n && !s.__memNote) { s.__memNote = 1; try { w.notify && w.notify('↩️ Votre travail en cours a été retrouvé (' + n + ' champ' + (n > 1 ? 's' : '') + ').', 'info', 3500); } catch (e) { } } }); }
  function clearKeep() { try { localStorage.removeItem(KEEP); } catch (e) { } }

  var tm = null;
  function later(fn, ms) { clearTimeout(tm); tm = setTimeout(fn, ms); }
  d.addEventListener('input', function (e) { var s = secOf(e.target); if (!s) return; touched[s.id] = 1; act[s.id] = Date.now(); later(function () { snapshot(s); }, 1200); }, true);
  d.addEventListener('change', function (e) { var s = secOf(e.target); if (!s) return; touched[s.id] = 1; act[s.id] = Date.now(); later(function () { snapshot(s); }, 600); }, true);
  d.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('button,[role=button]'); var s = b && secOf(b); if (s) { act[s.id] = Date.now(); setTimeout(function () { snapshot(s); }, 700); } }, true);
  w.addEventListener('pagehide', snapshotVisible); w.addEventListener('beforeunload', snapshotVisible);
  d.addEventListener('visibilitychange', function () { if (d.hidden) snapshotVisible(); });

  function wrapShow() {
    if (typeof w.show !== 'function' || w.show.__mem) return;
    var os = w.show;
    var f = function (x) {
      try { snapshotVisible(); } catch (e) { }
      if (typeof x === 'string') { try { ls(LAST, { p: x, t: Date.now() }); } catch (e) { } }
      Object.keys(touched).forEach(function (k) { delete touched[k]; }); act = {};
      var r = os.apply(this, arguments);
      if (x === 'settings') { try { mount(); refreshPanel(); } catch (e) { } }
      [0, 350, 1400].forEach(function (ms) { setTimeout(function () { try { restoreVisible(); } catch (e) { } }, ms); });
      return r;
    };
    f.__mem = 1; w.show = f;
  }

  /* V110 : un écran qui se redessine tout seul (chargement en ligne, actualisation) efface ce qui était saisi :
     on le remet, sauf si l'utilisateur est en train d'écrire ou vient de valider (8 s), et au plus 3 fois par 20 s. */
  var rcount = {}, mt = null, dirty = {};
  function onMut(list) {
    list.forEach(function (m) { var t = m.target && (m.target.nodeType === 1 ? m.target : m.target.parentElement), s = t && secOf(t); if (s && s.id) dirty[s.id] = 1; });
    clearTimeout(mt); mt = setTimeout(function () {
      var ids = Object.keys(dirty); dirty = {};
      ids.forEach(function (id) {
        var sec = $(id); if (!sec || sec.offsetParent === null || !mcfg().keep) return;
        if (Date.now() - (act[id] || 0) < 8000) return;
        var c = rcount[id] || (rcount[id] = { n: 0, t: Date.now() }); if (Date.now() - c.t > 20000) { c.n = 0; c.t = Date.now(); } if (c.n >= 3) return;
        if (!store()[kid(sec)]) return;
        var n = restore(sec, true); if (n) { c.n++; try { w.notify && w.notify('↩️ Votre travail en cours a été retrouvé (' + n + ' champ' + (n > 1 ? 's' : '') + ').', 'info', 3000); } catch (e) { } }
      });
    }, 500);
  }
  try { new MutationObserver(onMut).observe(d.documentElement, { childList: true, subtree: true }); } catch (e) { }
  w.EXB_KEEP = { restore: function (id) { var s = $(id); return s ? restore(s, true) : 0; }, version: 'V110' };

  /* rouvrir la dernière page (une seule fois, après connexion, si récente) */
  var reopened = false;
  function reopen() {
    if (reopened) return; var app = $('app'); if (!app || app.style.display === 'none') return;
    reopened = true;
    var c = mcfg(), l = lg(LAST, null); if (!c.reopen || !l || !l.p || l.p === 'dashboard' || Date.now() - l.t > 12 * 3600e3) { setTimeout(restoreVisible, 300); return; }
    try { if (typeof w.show === 'function' && $(l.p)) w.show(l.p); } catch (e) { }
  }
  var rt = setInterval(function () { reopen(); if (reopened) clearInterval(rt); }, 800); setTimeout(function () { clearInterval(rt); }, 30000);

  /* confidentialité : on efface les brouillons à la déconnexion */
  (function () { var ol = w.logout; if (typeof ol === 'function' && !ol.__mem) { w.logout = function () { clearKeep(); try { localStorage.removeItem(LAST); localStorage.removeItem('exb_tfl_nav'); } catch (e) { } return ol.apply(this, arguments); }; w.logout.__mem = 1; } })();

  /* ====================== 2. ALERTES SONORES ====================== */
  var A = { IA: ['l’importer et l’approuver', 'les importer et les approuver'], EA: ['l’examiner et l’approuver', 'les examiner et les approuver'], TR: ['la traiter', 'les traiter'], CO: ['la corriger', 'les corriger'], RE: ['y répondre', 'y répondre'], VE: ['la vérifier', 'les vérifier'] };
  var KINDS = {
    insc: { t: 'Inscriptions d’apprenants', one: 'une demande d’inscription d’un apprenant', many: 'demandes d’inscription d’apprenants', act: A.IA },
    tptd: { t: 'Demandes de TP / TD', one: 'une demande de TP ou TD d’un apprenant', many: 'demandes de TP ou TD d’apprenants', act: A.IA },
    cli: { t: 'Demandes de clients', one: 'une demande d’un client', many: 'demandes de clients', act: A.IA },
    btp: { t: 'Demandes de projet (clients)', one: 'une demande de projet d’un client', many: 'demandes de projet de clients', act: A.EA },
    form: { t: 'Fiches de formateurs', one: 'une fiche de formateur', many: 'fiches de formateurs', act: A.IA },
    pers: { t: 'Fiches du personnel', one: 'une fiche du personnel', many: 'fiches du personnel', act: A.IA },
    soft: { t: 'Demandes de logiciel', one: 'une demande de logiciel', many: 'demandes de logiciel', act: A.TR },
    copies: { t: 'Copies d’évaluation reçues', one: 'une copie d’évaluation d’un apprenant', many: 'copies d’évaluation d’apprenants', act: A.CO },
    pt_msg: { t: 'Messages du portail client', one: 'un message d’un client sur le portail', many: 'messages de clients sur le portail', act: A.RE },
    pt_decl: { t: 'Déclarations d’avancement (portail)', one: 'une déclaration d’avancement à vérifier', many: 'déclarations d’avancement à vérifier', act: A.VE }
  };
  var DEF = { on: false, vol: 0.8, tone: 'carillon', voice: true, sys: false, every: 60, remind: 10, kinds: {} };
  function cfg() { var c = lg(CFG, {}), o = {}; Object.keys(DEF).forEach(function (k) { o[k] = c[k] != null ? c[k] : DEF[k]; }); o.kinds = c.kinds || {}; return o; }
  function setCfg(p) { var c = cfg(); Object.keys(p).forEach(function (k) { c[k] = p[k]; }); ls(CFG, c); schedule(); }
  function kindOn(c, k) { return c.kinds[k] !== false; }

  var AC = null;
  function ctx() { try { if (!AC) { var C = w.AudioContext || w.webkitAudioContext; if (C) AC = new C(); } if (AC && AC.state === 'suspended') AC.resume(); } catch (e) { } return AC; }
  ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) { d.addEventListener(ev, function () { if (cfg().on) ctx(); }, { once: false, passive: true }); });
  function note(a, f, t0, dur, vol, type) {
    var o = a.createOscillator(), g = a.createGain(); o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(a.destination); o.start(t0); o.stop(t0 + dur + 0.05);
  }
  var TONES = {
    carillon: { n: 'Carillon', play: function (a, v) { var t = a.currentTime; [659.25, 783.99, 1046.5].forEach(function (f, i) { note(a, f, t + i * 0.18, 0.9, v * 0.5); note(a, f * 2, t + i * 0.18, 0.5, v * 0.12); }); } },
    bip: { n: 'Bip double', play: function (a, v) { var t = a.currentTime; [0, 0.22].forEach(function (o) { note(a, 880, t + o, 0.16, v * 0.45, 'square'); }); } },
    cloche: { n: 'Cloche', play: function (a, v) { var t = a.currentTime; [523.25, 1046.5, 1567.98, 2093].forEach(function (f, i) { note(a, f, t, 1.6 / (i + 1) + 0.4, v * 0.45 / (i + 1)); }); } },
    urgent: { n: 'Alerte (3 bips)', play: function (a, v) { var t = a.currentTime; [0, 0.2, 0.4].forEach(function (o) { note(a, 1000, t + o, 0.13, v * 0.5, 'triangle'); }); } }
  };
  function playTone(name, vol) { var a = ctx(); if (!a) return false; try { (TONES[name] || TONES.carillon).play(a, Math.max(0.05, Math.min(1, vol))); return true; } catch (e) { return false; } }
  function speak(text, vol) {
    try { var S = w.speechSynthesis; if (!S || !w.SpeechSynthesisUtterance) return false; S.cancel(); var u = new w.SpeechSynthesisUtterance(text); u.lang = 'fr-FR'; u.volume = Math.max(0.1, Math.min(1, vol)); u.rate = 0.98;
      var v = (S.getVoices() || []).filter(function (x) { return /^fr/i.test(x.lang); })[0]; if (v) u.voice = v; S.speak(u); return true; } catch (e) { return false; }
  }
  function sysNotify(title, body) {
    try { if (!('Notification' in w) || Notification.permission !== 'granted') return; var n = new Notification(title, { body: body, tag: 'exb-demande', renotify: true }); n.onclick = function () { try { w.focus(); } catch (e) { } n.close(); }; } catch (e) { }
  }
  function phrase(kind, n) {
    var K = KINDS[kind]; if (!K) return '';
    return n > 1 ? 'Vous avez reçu ' + n + ' ' + K.many + '. Veuillez ' + K.act[1] + '.' : 'Vous avez reçu ' + K.one + '. Veuillez ' + K.act[0] + '.';
  }

  var seen = lg(SEEN, {}), pending = {}, lastRing = 0, queue = [], qt = null;
  function ring(items, reminder) {
    var c = cfg(); if (!c.on) return;
    var text = items.map(function (it) { return it.text; }).join(' ');
    if (reminder) text = 'Rappel. ' + text;
    try { w.notify && w.notify('🔔 ' + items.map(function (it) { return it.short; }).join(' · '), 'warn', 12000); } catch (e) { }
    playTone(c.tone, c.vol);
    if (c.voice) setTimeout(function () { speak(text, c.vol); }, 1400);
    if (c.sys && d.hidden) sysNotify('Excellencia Building', items.map(function (it) { return it.short; }).join('\n'));
    lastRing = Date.now();
  }
  function flush() { qt = null; var it = queue.splice(0); if (it.length) ring(it, false); }
  function signal(kind, n) {
    n = Math.max(0, Number(n) || 0); pending[kind] = n; title();
    var prev = seen[kind] == null ? 0 : seen[kind], c = cfg();
    if (n !== prev) { seen[kind] = n; ls(SEEN, seen); }
    if (!c.on || !kindOn(c, kind) || n <= prev || !KINDS[kind]) return;
    var add = n - prev;
    queue.push({ text: phrase(kind, add), short: add + ' ' + (add > 1 ? KINDS[kind].many : KINDS[kind].one.replace(/^une? /, '')) });
    if (!qt) qt = setTimeout(flush, 1500);
    refreshPanel();
  }
  function totalPending() { var c = cfg(), t = 0; Object.keys(pending).forEach(function (k) { if (kindOn(c, k)) t += pending[k] || 0; }); return t; }
  var baseTitle = null;
  function title() { if (baseTitle == null) baseTitle = d.title.replace(/^\(\d+\)\s*/, ''); var t = totalPending(); d.title = (t ? '(' + t + ') ' : '') + baseTitle; }

  /* réception : demandes en ligne (index.html expose EXB_INBOX) */
  w.addEventListener('exb-inbox', function (e) { var c = e.detail || {}; Object.keys(c).forEach(function (k) { signal(k, c[k]); }); });
  function inboxOn() { return !!(w.EXB_INBOX && w.EXB_INBOX.on && w.EXB_INBOX.on()); }
  function poll() {
    var c = cfg(); if (!c.on) return Promise.resolve();
    var jobs = [];
    if (inboxOn()) jobs.push(Promise.resolve(w.EXB_INBOX.reload()).catch(function () { }));
    try { if (kindOn(c, 'copies') && typeof w.exbPullOnline === 'function' && !w.__exbCopiesWrapped) { var o = w.exbPullOnline; w.exbPullOnline = function () { var b = 0; try { b = w.exbLoadResps().length; } catch (e) { } var r = o.apply(this, arguments); Promise.resolve(r).then(function () { try { var a = w.exbLoadResps().length; if (a > b) { var n = a - b; queue.push({ text: phrase('copies', n), short: n + ' copie(s) d’évaluation' }); if (!qt) qt = setTimeout(flush, 1500); } } catch (e) { } }); return r; }; w.__exbCopiesWrapped = 1; } } catch (e) { }
    try { if ((kindOn(c, 'pt_msg') || kindOn(c, 'pt_decl')) && w.EXB_PORTAILS && w.EXBS && w.EXBS.get('exb_portails').length) jobs.push(Promise.resolve(w.EXB_PORTAILS.pull(true)).catch(function () { })); } catch (e) { }
    return Promise.all(jobs).then(function () {
      if (c.remind > 0 && totalPending() > 0 && Date.now() - lastRing > c.remind * 60000 && !qt) {
        var items = []; Object.keys(pending).forEach(function (k) { if (kindOn(c, k) && pending[k] > 0 && KINDS[k]) items.push({ text: phrase(k, pending[k]), short: pending[k] + ' ' + (pending[k] > 1 ? KINDS[k].many : KINDS[k].one.replace(/^une? /, '')) }); });
        if (items.length) ring(items.slice(0, 3), true);
      }
    });
  }
  var pt = null;
  function schedule() { clearInterval(pt); var c = cfg(); if (c.on) { pt = setInterval(poll, Math.max(30, Number(c.every) || 60) * 1000); setTimeout(poll, 4000); } }

  /* ====================== PANNEAU DANS PARAMÈTRES ====================== */
  function panelHtml() {
    var c = cfg(), m = mcfg();
    var kinds = Object.keys(KINDS).map(function (k) { return '<label class="ea-row"><input type="checkbox" data-ea-kind="' + k + '"' + (kindOn(c, k) ? ' checked' : '') + '> ' + esc(KINDS[k].t) + ' <small id="ea_n_' + k + '" style="color:#b54708"></small></label>'; }).join('');
    var tones = Object.keys(TONES).map(function (k) { return '<option value="' + k + '"' + (c.tone === k ? ' selected' : '') + '>' + TONES[k].n + '</option>'; }).join('');
    return '<div class="pgroup" id="exbAlertPanel" data-nokeep="1"><b class="pgtitle">🔔 Alertes sonores des demandes</b>'
      + '<div class="hint">Quand un apprenant, un client ou un portail vous envoie une demande, le logiciel sonne et l’annonce à voix haute (« Vous avez reçu une demande… veuillez l’importer et l’approuver »). L’application doit rester ouverte et connectée (Participants › Demandes en ligne).</div>'
      + '<label class="ea-row"><input type="checkbox" id="ea_on"' + (c.on ? ' checked' : '') + '> <b>Activer les alertes sonores</b></label>'
      + '<div class="two"><div><label>Sonnerie</label><select id="ea_tone">' + tones + '</select></div><div><label>Volume <span id="ea_volv">' + Math.round(c.vol * 100) + ' %</span></label><input type="range" id="ea_vol" min="10" max="100" value="' + Math.round(c.vol * 100) + '"></div></div>'
      + '<label class="ea-row"><input type="checkbox" id="ea_voice"' + (c.voice ? ' checked' : '') + '> Annonce vocale en français</label>'
      + '<label class="ea-row"><input type="checkbox" id="ea_sys"' + (c.sys ? ' checked' : '') + '> Notification du navigateur quand l’onglet est en arrière-plan <button class="muted smallbtn" id="ea_perm" type="button">Autoriser</button></label>'
      + '<div class="two"><div><label>Vérifier les nouvelles demandes toutes les</label><select id="ea_every">' + [30, 60, 120, 300].map(function (s) { return '<option value="' + s + '"' + (Number(c.every) === s ? ' selected' : '') + '>' + (s < 60 ? s + ' secondes' : s / 60 + ' minute' + (s > 60 ? 's' : '')) + '</option>'; }).join('') + '</select></div>'
      + '<div><label>Rappel s’il reste des demandes non traitées</label><select id="ea_remind">' + [0, 5, 10, 30, 60].map(function (s) { return '<option value="' + s + '"' + (Number(c.remind) === s ? ' selected' : '') + '>' + (s ? 'toutes les ' + s + ' min' : 'jamais') + '</option>'; }).join('') + '</select></div></div>'
      + '<b style="font-size:13px">Me prévenir pour :</b><div class="ea-grid">' + kinds + '</div>'
      + '<div class="actions"><button class="primary" id="ea_test" type="button">🔊 Tester le son</button><button class="muted" id="ea_testv" type="button">🗣️ Tester la voix</button><button class="muted" id="ea_now" type="button">↻ Vérifier maintenant</button></div>'
      + '<div class="hint" id="ea_state"></div></div>'
      + '<div class="pgroup" id="exbMemPanel" data-nokeep="1"><b class="pgtitle">🧠 Mémoire du travail</b>'
      + '<div class="hint">Quand vous quittez un onglet (devis, architecture, finance…) et que vous y revenez, ou que vous rechargez la page, ce que vous aviez saisi sans l’enregistrer est retrouvé. Les brouillons restent sur cet appareil (14 jours max) et sont effacés à la déconnexion.</div>'
      + '<label class="ea-row"><input type="checkbox" id="em_keep"' + (m.keep ? ' checked' : '') + '> Retrouver mon travail en cours dans chaque onglet</label>'
      + '<label class="ea-row"><input type="checkbox" id="em_reopen"' + (m.reopen ? ' checked' : '') + '> Rouvrir la dernière page consultée après une reconnexion ou un rechargement (dans les 12 h)</label>'
      + '<div class="actions"><button class="muted" id="em_clear" type="button">🗑️ Effacer les brouillons enregistrés</button></div><div class="hint" id="em_state"></div></div>';
  }
  function refreshPanel() {
    var s = $('ea_state'); if (!s) return;
    Object.keys(KINDS).forEach(function (k) { var e = $('ea_n_' + k); if (e) e.textContent = pending[k] ? '(' + pending[k] + ' en attente)' : ''; });
    s.innerHTML = (inboxOn() ? '✅ Réception en ligne connectée.' : '⚠️ Réception en ligne non connectée : connectez-vous dans <b>Participants › Demandes en ligne</b> pour être alerté.') + ' Total en attente : <b>' + totalPending() + '</b>.' + (cfg().on ? '' : ' <i>Alertes désactivées.</i>');
    var ms = $('em_state'); if (ms) { var n = Object.keys(store()).length; ms.textContent = n ? n + ' onglet(s) avec un travail en cours mémorisé.' : 'Aucun brouillon mémorisé.'; }
  }
  function mount() {
    var st = $('settings'); if (!st || $('exbAlertPanel')) return;
    var anchor = [].slice.call(st.querySelectorAll('.pgtitle')).filter(function (x) { return /Sécurité/.test(x.textContent); })[0];
    var html = panelHtml(), host = anchor && anchor.parentNode;
    if (host) host.insertAdjacentHTML('beforebegin', html); else st.insertAdjacentHTML('beforeend', html);
    if (!$('exbAlertCss')) { var css = d.createElement('style'); css.id = 'exbAlertCss'; css.textContent = '.ea-row{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:14px}.ea-row input[type=checkbox]{width:auto;height:auto;margin:0}.ea-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:2px 14px;margin:4px 0 10px}#ea_vol{width:100%}'; d.head.appendChild(css); }
    var P = $('exbAlertPanel');
    $('ea_on').onchange = function () { var on = this.checked; setCfg({ on: on }); if (on) { ctx(); playTone(cfg().tone, cfg().vol); try { if (cfg().voice) setTimeout(function () { speak('Les alertes sonores sont activées.', cfg().vol); }, 1000); } catch (e) { } poll(); } refreshPanel(); };
    $('ea_tone').onchange = function () { setCfg({ tone: this.value }); ctx(); playTone(this.value, cfg().vol); };
    $('ea_vol').oninput = function () { $('ea_volv').textContent = this.value + ' %'; };
    $('ea_vol').onchange = function () { setCfg({ vol: this.value / 100 }); ctx(); playTone(cfg().tone, cfg().vol); };
    $('ea_voice').onchange = function () { setCfg({ voice: this.checked }); };
    $('ea_sys').onchange = function () { setCfg({ sys: this.checked }); if (this.checked) askPerm(); };
    $('ea_perm').onclick = askPerm;
    $('ea_every').onchange = function () { setCfg({ every: Number(this.value) }); };
    $('ea_remind').onchange = function () { setCfg({ remind: Number(this.value) }); };
    [].forEach.call(P.querySelectorAll('[data-ea-kind]'), function (b) { b.onchange = function () { var k = cfg().kinds; k[this.getAttribute('data-ea-kind')] = this.checked; setCfg({ kinds: k }); title(); }; });
    $('ea_test').onclick = function () { ctx(); playTone(cfg().tone, cfg().vol); };
    $('ea_testv').onclick = function () { ctx(); if (!speak(phrase('insc', 1), cfg().vol)) { try { w.notify('La voix n’est pas disponible sur ce navigateur.', 'warn'); } catch (e) { } } };
    $('ea_now').onclick = function () { var c = cfg(); if (!c.on) { try { w.notify('Activez d’abord les alertes sonores.', 'warn'); } catch (e) { } return; } poll().then(refreshPanel); };
    $('em_keep').onchange = function () { var c = mcfg(); c.keep = this.checked; ls(MEMC, c); if (!c.keep) clearKeep(); refreshPanel(); };
    $('em_reopen').onchange = function () { var c = mcfg(); c.reopen = this.checked; ls(MEMC, c); };
    $('em_clear').onclick = function () { clearKeep(); refreshPanel(); try { w.notify('Brouillons effacés.', 'success'); } catch (e) { } };
    refreshPanel();
  }
  function askPerm() { try { if (!('Notification' in w)) return w.notify('Ce navigateur ne gère pas les notifications système.', 'warn'); Notification.requestPermission().then(function (p) { w.notify(p === 'granted' ? 'Notifications du navigateur autorisées.' : 'Autorisation refusée : réglez-la dans les paramètres du site.', p === 'granted' ? 'success' : 'warn'); }); } catch (e) { } }

  function init() { wrapShow(); mount(); schedule(); setInterval(function () { wrapShow(); }, 3000); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(init, 600); }); else setTimeout(init, 600);

  w.EXBALERT = { signal: signal, ring: function (kind, n) { queue.push({ text: phrase(kind, n || 1), short: (n || 1) + ' ' + (KINDS[kind] ? KINDS[kind].one.replace(/^une? /, '') : kind) }); flush(); }, cfg: cfg, setCfg: setCfg, poll: poll, pending: function () { return Object.assign({}, pending); }, phrase: phrase, tones: Object.keys(TONES) };
  w.EXBMEM = { snapshot: snapshotVisible, restore: restoreVisible, store: store, clear: clearKeep, cfg: mcfg, version: 'V99zze' };
})(window, document);
