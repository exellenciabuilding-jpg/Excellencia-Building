/* Excellencia Building — V94 Architecture / BIM / CDE Enterprise */
(function(w,d){'use strict';
const K={studies:'exb_v94_studies',drawings:'exb_v94_drawings',revisions:'exb_v94_revisions',visas:'exb_v94_visas',documents:'exb_v94_documents',bimModels:'exb_v94_bim_models',bimIssues:'exb_v94_bim_issues',distributions:'exb_v94_distributions'};
const store=()=>{try{return typeof exbStorage!=='undefined'?exbStorage:(w.exbStorage||localStorage)}catch(e){return w.exbStorage||localStorage}};
const uid=p=>(p||'V94')+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
/* Lecture/écriture par le pont commun EXBS : même zone de stockage que les autres modules, donc sauvegardée et synchronisée (collections *_v94). */
function get(k){try{if(w.EXBS)return w.EXBS.get(k);const v=JSON.parse(store().getItem(k)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}}
function put(k,v){if(w.EXBS)return w.EXBS.set(k,v);store().setItem(k,JSON.stringify(v));return true}
function add(k,row){const r=Object.assign({id:uid('V94'),created_at:new Date().toISOString()},row);const a=get(k);a.unshift(r);put(k,a);try{w.EXB_CORE&&w.EXB_CORE.audit&&w.EXB_CORE.audit('v94_record_created',r.id,k,r.id)}catch(e){}return r}
function can(c){try{return !w.EXB_CORE||!w.EXB_CORE.can||w.EXB_CORE.can(c,'ecrire')}catch(e){return true}}
function createStudy(data){if(!can('etudesTechniques'))throw Error('Droits insuffisants');return add(K.studies,Object.assign({status:'draft'},data))}
function createDrawing(data){if(!can('plansVersions'))throw Error('Droits insuffisants');return add(K.drawings,Object.assign({status:'wip',discipline:data.discipline||'architecture'},data))}
function createRevision(drawingId,data){if(!can('plansVersions'))throw Error('Droits insuffisants');const revs=get(K.revisions).filter(x=>x.drawing_id===drawingId);const next=revs.length+1;return add(K.revisions,Object.assign({drawing_id:drawingId,revision:'R'+next,status:'review',revision_number:next},data))}
function requestVisa(revisionId,data){if(!can('approvals'))throw Error('Droits insuffisants');return add(K.visas,Object.assign({revision_id:revisionId,status:'pending'},data))}
function decideVisa(id,decision,comment){if(!can('approvals'))throw Error('Droits insuffisants');const a=get(K.visas),i=a.findIndex(x=>x.id===id);if(i<0)throw Error('Visa introuvable');a[i]=Object.assign({},a[i],{status:decision==='approved'?'approved':decision==='rejected'?'rejected':'pending',decision_comment:comment||'',decided_at:new Date().toISOString()});put(K.visas,a);try{w.EXB_CORE&&w.EXB_CORE.audit&&w.EXB_CORE.audit('v94_visa_decided',id,'visa',id)}catch(e){}return a[i]}
function registerDocument(data){if(!can('documents'))throw Error('Droits insuffisants');return add(K.documents,Object.assign({status:'shared'},data))}
function registerBimModel(data){if(!can('cdeWorkflow'))throw Error('Droits insuffisants');return add(K.bimModels,Object.assign({status:'review',format:data.format||'IFC'},data))}
function createBimIssue(data){if(!can('cdeWorkflow'))throw Error('Droits insuffisants');return add(K.bimIssues,Object.assign({status:'open',priority:data.priority||'medium'},data))}
function distribute(revisionId,recipients,data){if(!can('cdeWorkflow'))throw Error('Droits insuffisants');return add(K.distributions,Object.assign({revision_id:revisionId,recipients:Array.isArray(recipients)?recipients:[],distributed_at:new Date().toISOString()},data))}
function kpis(){return {studies:get(K.studies).length,drawings:get(K.drawings).length,revisions:get(K.revisions).length,pendingVisas:get(K.visas).filter(x=>x.status==='pending').length,documents:get(K.documents).length,bimModels:get(K.bimModels).length,openBimIssues:get(K.bimIssues).filter(x=>x.status!=='closed').length,distributions:get(K.distributions).length}}
function render(){const host=d.getElementById('enterprise360')||d.getElementById('exb90_root');if(!host)return;let root=d.getElementById('exb94_arch_root');if(!root){root=d.createElement('div');root.id='exb94_arch_root';host.appendChild(root)}const p=kpis();root.innerHTML='<div class="exb94-head"><div><h3>Architecture · BIM · CDE</h3><p>Études, plans, révisions, visas, modèles BIM et diffusion contrôlée.</p></div><b>V94</b></div><div class="exb94-grid">'+[['Études',p.studies],['Plans',p.drawings],['Révisions',p.revisions],['Visas en attente',p.pendingVisas],['Documents',p.documents],['Modèles BIM',p.bimModels],['Issues BIM',p.openBimIssues],['Diffusions',p.distributions]].map(x=>'<div><strong>'+x[1]+'</strong><span>'+x[0]+'</span></div>').join('')+'</div><div class="exb94-flow">WIP → Shared → Review → Approved → Archived · Toute révision peut être visée, rejetée, historisée et diffusée.</div><div class="exb94-flow">BCF 2.1 pris en charge : export et import des observations BIM (Priorité 2 › BIM / Issues), avec le GlobalId de l’élément.</div>'}
function mount(){if(!d.getElementById('exb94CSS')){const s=d.createElement('style');s.id='exb94CSS';s.textContent='.exb94-head{display:flex;justify-content:space-between;margin:12px 0}.exb94-head h3{margin:0}.exb94-head p{margin:4px 0;color:#64748b}.exb94-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}.exb94-grid div{padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff}.exb94-grid strong,.exb94-grid span{display:block}.exb94-grid strong{font-size:21px}.exb94-grid span{font-size:12px;color:#64748b}.exb94-flow{margin-top:10px;padding:12px;border-radius:10px;background:#f8fafc;color:#334155;font-size:13px}';d.head.appendChild(s)}render()}

/* ===== V99-SOURCE-UNIQUE : le modèle V94 est la seule source de vérité plans / CDE / BIM =====
   Anciens stockages (exb_plans, exb_cde, exb_bim_issues, exb_plan_files) : migrés une fois (idempotent, identifiants déterministes),
   puis conservés en lecture seule comme sauvegarde ; les écrans (Bureau d'études, V68, Plans V81) lisent et écrivent ici. */
const LEG={plans:'exb_plans',cde:'exb_cde',bim:'exb_bim_issues',files:'exb_plan_files'};
const DOC_ST={WIP:'wip',Shared:'shared',Review:'review',Approved:'approved',Published:'published',Superseded:'archived'},DOC_LB=inv(DOC_ST);
const PRI={Normale:'medium',Haute:'high',Critique:'critical'},PRI_LB=inv(PRI);
const ISS={'Ouvert':'open','Assigné':'assigned','En correction':'in_progress','À vérifier':'to_verify','Clôturé':'closed'},ISS_LB=inv(ISS);
const VIS={'En attente':'pending','Pour information':'info','Visé sans observation':'approved','Visé avec observations':'approved_with_comments','Refusé':'rejected'},VIS_LB=inv(VIS);
function inv(o){const r={};Object.keys(o).forEach(k=>r[o[k]]=k);return r}
const raw=k=>{try{return w.EXBS?w.EXBS.get(k):[]}catch(e){return[]}};
const has=(a,id)=>a.some(x=>x.id===id);
const slug=x=>String(x==null?'':x).replace(/[^A-Za-z0-9._-]+/g,'_');
function writeAll(m){Object.keys(m).forEach(k=>put(k,m[k]))}

/* --- Plans BE (vue imbriquée : plan > indices > diffusions/visas) <-> V94 (plan, révisions, visas, diffusions) --- */
function nestedToRows(p){
 const dr={id:p.id,project_id:p.project_id||'',code:p.no||'',title:p.title||'',discipline:p.disc||'Architecture',scale:p.scale||'',status:'wip',current_revision:'',created_at:p.created_at||new Date().toISOString()};
 const oldR=get(K.revisions).filter(x=>x.drawing_id===p.id),oldV=get(K.visas),revs=[],visas=[],dist=[];
 (p.versions||[]).forEach((v,i)=>{
  const last=i===(p.versions.length-1),prev=oldR.find(x=>x.revision===v.ind),rid=prev?prev.id:p.id+':'+slug(v.ind);
  revs.push(Object.assign({},prev||{},{id:rid,drawing_id:p.id,revision:v.ind,revision_number:i+1,description:v.desc||'',date:v.date||'',author:v.by||'',status:last?'review':'superseded',created_at:(prev&&prev.created_at)||(v.date?v.date+'T00:00:00.000Z':new Date().toISOString())}));
  if(last)dr.current_revision=v.ind;
  (v.sent||[]).forEach((x,j)=>{
   const pv=oldV.filter(o=>o.revision_id===rid)[j];
   visas.push(Object.assign({},pv||{},{id:pv?pv.id:rid+':v'+j,revision_id:rid,reviewer:x.to||'',role:x.role||'',status:VIS[x.visa]||'pending',visa_label:x.visa||'En attente',sent_date:x.date||'',decided_at:x.vdate||'',decision_comment:x.obs||'',created_at:(pv&&pv.created_at)||new Date().toISOString()}));
   dist.push({id:rid+':d'+j,revision_id:rid,recipients:[x.to||''],distributed_at:x.date||'',channel:'bordereau',role:x.role||''})});
 });
 dr.status=revs.length?(visas.some(x=>x.status==='rejected'&&revs.length&&x.revision_id===revs[revs.length-1].id)?'rejected':'review'):'wip';
 return{dr,revs,visas,dist}}
function savePlanNested(p){
 const R=nestedToRows(p),oldRevIds=get(K.revisions).filter(x=>x.drawing_id===p.id).map(x=>x.id),inOld=id=>oldRevIds.indexOf(id)>=0;
 const prevD=get(K.drawings),i=prevD.findIndex(x=>x.id===p.id);
 const dr=Object.assign({},i>=0?prevD[i]:{},R.dr);if(i>=0)prevD[i]=dr;else prevD.unshift(dr);
 const m={};m[K.drawings]=prevD;
 m[K.revisions]=get(K.revisions).filter(x=>x.drawing_id!==p.id).concat(R.revs);
 m[K.visas]=get(K.visas).filter(x=>!inOld(x.revision_id)).concat(R.visas);
 m[K.distributions]=get(K.distributions).filter(x=>!inOld(x.revision_id)).concat(R.dist);
 writeAll(m);return dr}
function deletePlan(id){
 const ids=get(K.revisions).filter(x=>x.drawing_id===id).map(x=>x.id),m={};
 m[K.drawings]=get(K.drawings).filter(x=>x.id!==id);m[K.revisions]=get(K.revisions).filter(x=>x.drawing_id!==id);
 m[K.visas]=get(K.visas).filter(x=>ids.indexOf(x.revision_id)<0);m[K.distributions]=get(K.distributions).filter(x=>ids.indexOf(x.revision_id)<0);writeAll(m);
 try{const fl=raw(LEG.files);let c=false;fl.forEach(f=>{if(f.drawing_id===id){delete f.drawing_id;delete f.revision_id;c=true}});if(c)w.EXBS.set(LEG.files,fl)}catch(e){}
 try{const ms=get(K.bimModels);let c=false;ms.forEach(md=>{if(md.drawing_id===id){md.drawing_id='';c=true}});if(c)put(K.bimModels,ms)}catch(e){}
 return true}
function plansNested(){
 const revs=get(K.revisions),vis=get(K.visas);
 return get(K.drawings).map(d=>({id:d.id,project_id:d.project_id||'',no:d.code||'',title:d.title||'',disc:d.discipline||'',scale:d.scale||'',
  versions:revs.filter(r=>r.drawing_id===d.id).sort((a,b)=>(a.revision_number||0)-(b.revision_number||0)).map(r=>({ind:r.revision,date:r.date||String(r.created_at||'').slice(0,10),desc:r.description||'',by:r.author||'',
   sent:vis.filter(v=>v.revision_id===r.id).map(v=>({to:v.reviewer||'',role:v.role||'',date:v.sent_date||'',visa:v.visa_label||VIS_LB[v.status]||'En attente',vdate:v.decided_at||'',obs:v.decision_comment||''}))}))}))}

/* --- CDE (V68) : documents V94 vus avec les libellés et champs de l'écran V68 --- */
function cdeRows(){return get(K.documents).map(x=>({id:x.id,project:x.project_id||'',title:x.title||'',disc:x.discipline||'',rev:x.version||'',status:DOC_LB[x.status]||x.status||'',author:x.author||'',note:x.note||'',createdAt:x.created_at||''})).reverse()}
function addCde(o){return registerDocument({project_id:o.project||'',title:o.title||'',discipline:o.disc||'',version:o.rev||'',status:DOC_ST[o.status]||'wip',author:o.author||'',note:o.note||'',source:'cde'})}
/* --- Issues BIM (V68) --- */
function bimRows(){return get(K.bimIssues).map(x=>({id:x.id,project:x.project_id||'',title:x.title||'',disc:x.disc||'',disc2:x.disc2||'',loc:x.location||'',guid:x.element_guid||'',model:x.model_id||'',priority:PRI_LB[x.priority]||x.priority||'',owner:x.owner||'',status:ISS_LB[x.status]||x.status||'',createdAt:x.created_at||'',modifiedAt:x.updated_at||'',bcf:x.bcf_guid||''})).reverse()}
function addBim(o){return createBimIssue({project_id:o.project||'',title:o.title||'',priority:PRI[o.priority]||'medium',status:ISS[o.status]||'open',disc:o.disc||'',disc2:o.disc2||'',location:o.loc||'',owner:o.owner||'',element_guid:o.guid||'',model_id:o.model||'',description:o.title||'',bcf_guid:o.bcf||''})}
/* V99 : import BCF — une observation déjà connue (même identifiant BCF) est mise à jour, jamais dupliquée ; la description d'une observation existante n'est pas réécrite */
function importBcf(list,opts){opts=opts||{};if(!can('cdeWorkflow'))throw Error('Droits insuffisants');const a=get(K.bimIssues),models=get(K.bimModels);let created=0,updated=0,same=0;
 (list||[]).forEach(t=>{if(!t||!t.bcf)return;const i=a.findIndex(x=>(x.bcf_guid&&x.bcf_guid===t.bcf)||x.id===t.bcf||(opts.uuidOf&&opts.uuidOf(x.id)===t.bcf)),mn=String(t.model||'').replace(/\.ifc$/i,''),m=mn?models.find(q=>q.name===t.model||q.name===mn):null,
  f={title:t.title||'Observation BCF',priority:PRI[t.priority]||'medium',status:ISS[t.status]||'open',owner:t.owner||'',disc:t.disc||'',disc2:t.disc2||'',location:t.loc||'',element_guid:t.guid||'',bcf_guid:t.bcf};if(m)f.model_id=m.id;
  if(i>=0){const cur=a[i];if(Object.keys(f).some(k=>k!=='bcf_guid'&&String(cur[k]||'')!==String(f[k]||''))){a[i]=Object.assign({},cur,f,{updated_at:new Date().toISOString()});updated++}else same++}
  else{a.unshift(Object.assign({id:uid('V94'),created_at:t.createdAt||new Date().toISOString(),project_id:opts.project||'',description:t.description||f.title},f));created++}});
 put(K.bimIssues,a);try{w.EXB_CORE&&w.EXB_CORE.audit&&w.EXB_CORE.audit('v94_bcf_import','bcf',K.bimIssues,created+'+'+updated)}catch(e){}return{created,updated,same}}

/* --- Fichiers de plans (V81) : chaque fichier est rattaché à une révision V94 --- */
function linkPlanFile(m){
 if(!m||!m.ref)return m;const drs=get(K.drawings),revs=get(K.revisions),pid=m.project||'';
 let dr=drs.find(x=>(x.project_id||'')===pid&&x.code===m.ref),mk={};
 if(!dr){dr={id:'DRW-'+slug(pid)+'-'+slug(m.ref),project_id:pid,code:m.ref,title:m.ref,discipline:'architecture',status:'wip',current_revision:m.ver||'',created_at:new Date().toISOString()};drs.unshift(dr);mk[K.drawings]=drs}
 let rv=revs.find(x=>x.drawing_id===dr.id&&x.revision===m.ver);
 if(!rv){rv={id:dr.id+':'+slug(m.ver),drawing_id:dr.id,revision:m.ver||'',revision_number:revs.filter(x=>x.drawing_id===dr.id).length+1,description:m.note||'',date:m.date||'',status:'review',created_at:new Date().toISOString()};revs.push(rv);mk[K.revisions]=revs}
 else if(rv.file_id!==m.id){rv.file_id=m.id;mk[K.revisions]=revs}
 rv.file_id=m.id;rv.file_url=m.path||rv.file_url||'';rv.file_name=m.name||'';mk[K.revisions]=revs;
 if(dr.current_revision!==m.ver){dr.current_revision=m.ver;mk[K.drawings]=drs}
 writeAll(mk);m.drawing_id=dr.id;m.revision_id=rv.id;
 if(String(m.ext||'').toLowerCase()==='ifc'||/\.ifc$/i.test(m.name||''))registerIfcModel(m,dr);
 return m}
/* Un fichier IFC rattaché à un plan = une version du modèle BIM correspondant (1 modèle par projet + référence ; id déterministe). */
function registerIfcModel(m,dr){
 const id='MOD-'+slug(m.project||'')+'-'+slug(m.ref),all=get(K.bimModels);let md=all.find(x=>x.id===id);
 if(!md){md={id,project_id:m.project||'',name:m.ref,format:'IFC',status:'review',drawing_id:dr.id,versions:[],created_at:new Date().toISOString()};all.unshift(md)}
 md.versions=(md.versions||[]).filter(v=>v.file_id!==m.id).concat([{ver:m.ver||'',file_id:m.id,revision_id:m.revision_id||'',date:m.date||'',file_url:m.path||''}]);
 md.version=m.ver||md.version||'';md.file_id=m.id;md.file_url=m.path||md.file_url||'';put(K.bimModels,all);return md}
/* Fichier supprimé dans Plans : plus de lien orphelin côté V94 (révision, version de modèle BIM). */
function unlinkPlanFile(fileId){
 const revs=get(K.revisions);let ch=false;
 revs.forEach(r=>{if(r.file_id===fileId){delete r.file_id;delete r.file_url;delete r.file_name;ch=true}});
 if(ch)put(K.revisions,revs);
 const ms=get(K.bimModels),iss=get(K.bimIssues);let mc=false;
 const keep=ms.filter(md=>{if(!(md.versions||[]).some(v=>v.file_id===fileId))return true;md.versions=md.versions.filter(v=>v.file_id!==fileId);mc=true;
  const last=md.versions[md.versions.length-1];md.file_id=last?last.file_id:'';md.file_url=last?last.file_url:'';md.version=last?last.ver:'';
  if(md.versions.length)return true;return iss.some(i=>i.model_id===md.id)?(md.status='archived',true):false});
 if(mc)put(K.bimModels,keep);return ch||mc}

/* --- Migration unique des anciens stockages (idempotente : relançable sans doublon) --- */
function migrateLegacy(){
 const out={plans:0,cde:0,bim:0,files:0};
 try{
  const lp=raw(LEG.plans),dr0=get(K.drawings);
  lp.forEach(p=>{if(p&&p.id&&!has(dr0,p.id)){savePlanNested(p);out.plans++}});
  const ld=raw(LEG.cde),docs=get(K.documents),nd=[];
  ld.forEach(x=>{const id='DOC-'+x.id;if(x&&x.id&&!has(docs,id)&&!has(nd,id))nd.push({id,legacy_id:x.id,project_id:x.project||'',title:x.title||'',discipline:x.disc||'',version:x.rev||'',status:DOC_ST[x.status]||'wip',author:x.author||'',note:x.note||'',source:'cde',confidentiality:'internal',created_at:x.createdAt||new Date().toISOString()})});
  if(nd.length){nd.reverse();/* V94 : plus récent en premier */put(K.documents,nd.concat(docs));out.cde=nd.length}
  const lb=raw(LEG.bim),iss=get(K.bimIssues),ni=[];
  lb.forEach(x=>{const id='ISS-'+x.id;if(x&&x.id&&!has(iss,id)&&!has(ni,id))ni.push({id,legacy_id:x.id,project_id:x.project||'',title:x.title||'',priority:PRI[x.priority]||'medium',status:ISS[x.status]||'open',disc:x.disc||'',disc2:x.disc2||'',location:x.loc||'',owner:x.owner||'',description:x.title||'',created_at:x.createdAt||new Date().toISOString()})});
  if(ni.length){ni.reverse();put(K.bimIssues,ni.concat(iss));out.bim=ni.length}
  const fl=raw(LEG.files);let ch=0;
  fl.forEach(m=>{if(m&&m.id&&m.ref&&!m.revision_id){linkPlanFile(m);ch++}});
  if(ch){w.EXBS.set(LEG.files,fl);out.files=ch}
 }catch(e){out.error=String(e&&e.message||e)}
 return out}
w.EXB_ARCH={version:'V94-Architecture-BIM-CDE',keys:K,legacyKeys:LEG,plansNested,savePlanNested,deletePlan,cdeRows,addCde,bimRows,addBim,importBcf,linkPlanFile,unlinkPlanFile,registerIfcModel,bimModels:()=>get(K.bimModels),migrateLegacy,createStudy,createDrawing,createRevision,requestVisa,decideVisa,registerDocument,registerBimModel,createBimIssue,distribute,kpis,refresh:render};const boot=()=>{mount();setTimeout(()=>{try{migrateLegacy()}catch(e){}},1500);setTimeout(()=>{try{migrateLegacy()}catch(e){}},9000)};
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',()=>setTimeout(boot,0));else setTimeout(boot,0);
})(window,document);
