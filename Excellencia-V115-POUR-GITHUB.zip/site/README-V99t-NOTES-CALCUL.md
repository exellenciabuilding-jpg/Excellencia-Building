# V99t — Notes de calcul de structure : présentation Excellencia Building

Ajouts : `calcul-structure/exb-calcul-doc.js`. Modifiés : `calcul-structure/index.html` (1 balise script + 1 appel dans `openDoc`),
`verification.html` et `exb-verif.js` (affichent « Note de calcul de structure »), `sw.js` (cache `exb-v99t-notes-calcul-1`).
Aucun calcul n'est modifié. Aucun SQL à exécuter (le type de registre « document » existe depuis V99o).

## Ce que voit l'utilisateur
Dans chaque module (poteau, poutre, dalle, plancher, semelle, escalier, bâtiment), « Note de calcul » ouvre l'aperçu avec :
- une **fiche à remplir** : client / maître d'ouvrage, projet, lieu, établi par, vérifié par, indice, n° de la note, date, case **Brouillon** ;
  les champs client / projet / lieu / ingénieur sont les mêmes que « Plus d'options » (une seule saisie) ;
- une **page de garde** identique aux devis : bandeau marine + filet doré, logo, nom, slogan, téléphone, e-mail, adresse, mentions légales
  (repris de l'identité unique `EXBId`), titre « NOTE DE CALCUL », n°, date, indice, cadres Client / Projet / Références de calcul (norme),
  « Fait à … le … », signature + cachet de l'administrateur, case « Vérifié par — visa », **QR de vérification** et code ;
- en-tête marine + logo sur chaque page de calcul, pied de page (nom, contacts, n° · indice) et filigrane BROUILLON si coché ;
- numéro automatique **NCS-AAAA-NNN** : un même calcul garde son numéro (modifiable dans la fiche) ;
- nom de fichier PDF proposé : « NCS-2026-001 — Note de calcul — Projet ».

## QR et registre
Le QR ouvre `verification.html` (page publique) et affiche : type « Note de calcul de structure », numéro, client, projet, date, statut, code.
À l'impression, la note est publiée au registre si le compte administrateur est connecté ; sinon elle est mise en attente et publiée à la
prochaine ouverture d'une note (le QR affiche « non confirmé » d'ici là). Modifier le calcul ou l'indice change le code : l'ancienne version
apparaît alors comme « remplacée ».

## Limites
- Les plans d'exécution (feuilles A3/A4 avec cartouche) gardent leur cartouche d'origine.
- Ouvert seul (`calcul-structure/index.html` hors du logiciel) : même mise en page, mais sans QR ni signature, et sans identité (nom « Bureau d'Études »).
- Testé : `node tools/check.js` (242 contrôles), test navigateur de l'aperçu (autonome et avec le logiciel central simulé : QR généré,
  publication au registre) et PDF A4 (page de garde, 1 note par page, pied de page, filigrane). Rendu sur tous les modules réels et sur téléphone
  à confirmer sur vos appareils. Pour revenir en arrière : retirer la balise `exb-calcul-doc.js` de `calcul-structure/index.html`.
- Vider le cache / recharger après la mise à jour.

## Ajout — cartouche des plans d'exécution
Les plans d'exécution (poteau, poutre, dalle, plancher, semelle, escalier, bâtiment) reçoivent le même habillage : la fiche « Informations du document »
s'affiche au-dessus et le cartouche d'origine est remplacé, dans le dessin, par un cartouche Excellencia Building rempli automatiquement :
identité (logo, nom, slogan, téléphone, e-mail, adresse), client, projet, lieu, établi par, vérifié par, norme, élément dessiné et ses données
(béton, acier, échelle…), signature + cachet de l'administrateur, QR de vérification + code, n° PEX-AAAA-NNN, date, indice, page i / N.
Le QR publie le plan au registre (« Plan d'exécution de structure »). Le filigrane BROUILLON s'applique aussi.
Limite : les exports DXF / BIM gardent l'ancien cartouche. Testé sur semelle, poutre, poteau, plancher, escalier ; bâtiment (plusieurs feuilles) non testé en navigateur.

## Ajout — finition professionnelle des notes
- Page de garde : **sommaire** (sections et n° de feuille) en plus des cadres Client / Projet / Références.
- Pages de calcul : titres de section marine + filet doré, tableaux à en-tête marine et lignes alternées, lignes jamais coupées entre deux pages,
  verdicts « Vérifié / OK » en vert et « Non vérifié » en rouge, numérotation réelle « Feuille i / N » (l'ancien « Page i / 6 » était figé).
- Dernière feuille : bloc **Conclusion et visas** (Établi par avec signature + cachet, Vérifié par, Maître d'ouvrage « Lu et approuvé »).

## V99za — correctif
- `exb-v99r-shell.js` : `hideRescued` était définie dans `install()` mais appelée par `openCat()` (menu latéral : Paramètres, etc.) → message
  « Cette action n'a pas pu aboutir : hideRescued is not defined ». La fonction est maintenant au niveau du module.
- `sw.js` : cache `exb-v99za-correctif-notes-1` (recharger / vider le cache pour récupérer la mise à jour).
