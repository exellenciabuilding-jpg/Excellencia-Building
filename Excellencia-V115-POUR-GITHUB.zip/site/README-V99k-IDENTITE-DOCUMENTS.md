# V99k — Identité automatique sur tous les documents remis au client
- Nouveau module exb-identite.js : une seule identité (nom, slogan, téléphone, e-mail, adresse, ville de signature, mentions légales RCCM / Id.Nat. / impôt / banque).
  À renseigner une fois : menu « Logo Excellencia Building » > bloc « Identité imprimée sur les devis, fiches et documents clients ».
- Devis (métré, devis rapide, PDF et impression) : en-tête complet (logo, coordonnées, mentions légales), « Fait à / Le », signature + cachet de l'administrateur, pied de page avec coordonnées.
  Correction : l'ancien e-mail codé en dur dans le devis (« excelenciabuilding », une seule « l ») n'est plus utilisé.
- Fiche du personnel : bouton « 📄 Fiche PDF » dans Ressources humaines (sans salaire), zones de signature de l'intéressé(e) et de la Direction.
- Fiches / dossiers participants (fiche-*, dossier-*, attestation, contrat, facture…) : bloc « Fait à… le… » + signature et cachet ajoutés automatiquement ; coordonnées complètes dans l'en-tête.
- Moteur EXBPdf (fiches BTP, clients, terrain, études…) : nom, logo et coordonnées de l'entreprise, pied de page avec mentions légales.
- Penser à vider le cache / recharger l'application après la mise à jour.
