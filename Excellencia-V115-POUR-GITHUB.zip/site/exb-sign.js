/* exb-sign.js (V99j) — Signature manuscrite (doigt / souris), import d'image de signature, cachet Excellencia Building.
 * Les données de l'administrateur restent sur CET appareil (localStorage). Aucune donnée n'est envoyée en ligne. */
window.EXBSign=(function(){
  'use strict';
  var KEY='EXB_SIGN_V1';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){return {}}}
  function save(o){try{localStorage.setItem(KEY,JSON.stringify(o));return true}catch(e){return false}}
  var STAMP_SVG='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 300 300" width="600" height="600"><defs><path id="t" d="M 36,150 A 114,114 0 0 1 264,150"/><path id="b" d="M 28,150 A 122,122 0 0 0 272,150"/></defs><g fill="none" stroke="#173a8a" stroke-width="5"><circle cx="150" cy="150" r="140"/><circle cx="150" cy="150" r="132" stroke-width="1.8"/><circle cx="150" cy="150" r="88" stroke-width="2.5"/></g><g fill="#173a8a" font-family="Arial,Helvetica,sans-serif" font-weight="bold"><text font-size="21" letter-spacing="1.5"><textPath xlink:href="#t" href="#t" startOffset="50%" text-anchor="middle">EXCELLENCIA BUILDING</textPath></text><text font-size="17" letter-spacing="3"><textPath xlink:href="#b" href="#b" startOffset="50%" text-anchor="middle">KINSHASA · RDC</textPath></text><text x="27" y="158" font-size="18" text-anchor="middle">★</text><text x="273" y="158" font-size="18" text-anchor="middle">★</text><text x="150" y="132" font-size="13" text-anchor="middle" letter-spacing="2">CONSTRUCTION</text><g transform="translate(150,150) scale(.8)"><rect x="-36" y="-8" width="14" height="38"/><rect x="-18" y="-26" width="16" height="56"/><rect x="0" y="-16" width="14" height="46"/><rect x="18" y="-2" width="14" height="32"/></g><text x="150" y="198" font-size="12" text-anchor="middle" letter-spacing="2">FORMATION</text></g></svg>';
  function loadImg(src){return new Promise(function(ok){var im=new Image();im.onload=function(){ok(im)};im.onerror=function(){ok(null)};im.src=src})}
  var stampCache=null;
  function stampPng(){if(stampCache)return Promise.resolve(stampCache);
    return loadImg('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(STAMP_SVG)).then(function(im){
      if(!im)return '';var c=document.createElement('canvas');c.width=c.height=480;c.getContext('2d').drawImage(im,0,0,480,480);stampCache=c.toDataURL('image/png');return stampCache})}
  /* image importée -> PNG transparent (fond blanc retiré), réduite */
  function cleanImage(file,maxW){return new Promise(function(ok,ko){
    var r=new FileReader();r.onerror=function(){ko(new Error('lecture'))};
    r.onload=function(){loadImg(r.result).then(function(im){
      if(!im){ko(new Error('image'));return}
      var k=Math.min(1,(maxW||700)/im.naturalWidth),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.naturalWidth*k));c.height=Math.max(1,Math.round(im.naturalHeight*k));
      var x=c.getContext('2d');x.drawImage(im,0,0,c.width,c.height);
      try{var d=x.getImageData(0,0,c.width,c.height),p=d.data;
        for(var i=0;i<p.length;i+=4){var m=Math.min(p[i],p[i+1],p[i+2]);if(p[i+3]===0)continue;
          if(m>=238)p[i+3]=0;else if(m>190)p[i+3]=Math.round(p[i+3]*(238-m)/48)}
        x.putImageData(d,0,0)}catch(e){}
      ok(trim(c).toDataURL('image/png'))})};
    r.readAsDataURL(file)})}
  function trim(c){var x=c.getContext('2d'),w=c.width,h=c.height,p;try{p=x.getImageData(0,0,w,h).data}catch(e){return c}
    var x0=w,y0=h,x1=-1,y1=-1;for(var y=0;y<h;y++)for(var xx=0;xx<w;xx++)if(p[(y*w+xx)*4+3]>12){if(xx<x0)x0=xx;if(xx>x1)x1=xx;if(y<y0)y0=y;if(y>y1)y1=y}
    if(x1<0)return c;var pad=6;x0=Math.max(0,x0-pad);y0=Math.max(0,y0-pad);x1=Math.min(w-1,x1+pad);y1=Math.min(h-1,y1+pad);
    var o=document.createElement('canvas');o.width=x1-x0+1;o.height=y1-y0+1;o.getContext('2d').drawImage(c,x0,y0,o.width,o.height,0,0,o.width,o.height);return o}
  /* zone de signature au doigt / à la souris */
  function pad(canvas,opts){opts=opts||{};
    var ctx=canvas.getContext('2d'),drawing=false,dirty=false,last=null,color=opts.color||'#111827';
    function size(){var r=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;if(!r.width)return;
      if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){var keep=dirty?canvas.toDataURL():null;canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);
        ctx.setTransform(dpr,0,0,dpr,0,0);ctx.lineWidth=2.6;ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=color;
        if(keep){loadImg(keep).then(function(im){if(im)ctx.drawImage(im,0,0,r.width,r.height)})}}}
    function pt(e){var r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top}}
    canvas.style.touchAction='none';size();
    canvas.addEventListener('pointerdown',function(e){size();drawing=true;last=pt(e);try{canvas.setPointerCapture(e.pointerId)}catch(x){}
      ctx.beginPath();ctx.arc(last.x,last.y,1.2,0,6.3);ctx.fillStyle=color;ctx.fill();dirty=true;if(opts.onChange)opts.onChange();e.preventDefault()});
    canvas.addEventListener('pointermove',function(e){if(!drawing)return;var p=pt(e);ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p;e.preventDefault()});
    function up(){drawing=false}
    canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);canvas.addEventListener('pointerleave',up);
    window.addEventListener('resize',size);
    return {clear:function(){ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.restore();dirty=false;if(opts.onChange)opts.onChange()},
      isEmpty:function(){return !dirty},resize:size,
      png:function(){if(!dirty)return '';return trim(canvas).toDataURL('image/png')},
      /* JPEG fond blanc (pour les PDF vectoriels) */
      jpg:function(){if(!dirty)return '';var t=trim(canvas),c=document.createElement('canvas');c.width=t.width;c.height=t.height;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(t,0,0);return c.toDataURL('image/jpeg',.92)}}}
  /* configuration de l'administrateur */
  function getAdmin(){var s=load();return {sig:s.sig||'',stamp:s.stamp||'default',auto:s.auto!==false&&(s.configured===true)}}
  function setAdmin(p){var s=load();Object.keys(p).forEach(function(k){s[k]=p[k]});s.configured=true;return save(s)}
  function clearSig(){var s=load();delete s.sig;return save(s)}
  function active(){var a=getAdmin();return a.auto&&(a.sig||a.stamp!=='none')}
  /* visa = signature + cachet superposé, prêt à poser sur un document. fmt : 'png' (transparent) ou 'jpg' (fond blanc) */
  function visa(fmt){var a=getAdmin();if(!a.auto||(!a.sig&&a.stamp==='none'))return Promise.resolve('');
    var W=520,H=260,c=document.createElement('canvas');c.width=W;c.height=H;var x=c.getContext('2d');
    var sp=a.sig?loadImg(a.sig):Promise.resolve(null);
    var tp=a.stamp==='none'?Promise.resolve(null):(a.stamp==='default'?stampPng().then(loadImg):loadImg(a.stamp));
    return Promise.all([sp,tp]).then(function(r){var sg=r[0],st=r[1],stSize=200;
      if(sg){var k=Math.min((W*.62)/sg.naturalWidth,(H*.78)/sg.naturalHeight),w=sg.naturalWidth*k,h=sg.naturalHeight*k;x.drawImage(sg,st?10:(W-w)/2,H-h-20,w,h)}
      if(st){x.save();x.globalAlpha=.86;x.translate(W-stSize/2-10,H/2+8);x.rotate(-.14);x.drawImage(st,-stSize/2,-stSize/2,stSize,stSize);x.restore()}
      if(!sg&&!st)return '';var t=trim(c);if(fmt==='jpg'){var f=document.createElement('canvas');f.width=t.width;f.height=t.height;var fx=f.getContext('2d');fx.fillStyle='#fff';fx.fillRect(0,0,f.width,f.height);fx.drawImage(t,0,0);return f.toDataURL('image/jpeg',.92)}
      return t.toDataURL('image/png')})}
  /* V99zzzzzzzzzzzzzzzzzzzz — visa PUBLIC : l'administrateur le publie (Site vitrine › Publier) dans vitrine/visa.png ;
   * les pages des clients (fiche de demande BTP, etc.) le lisent pour poser cachet + signature du Directeur Général. */
  var RKEY='EXB_VISA_REMOTE';
  function remoteRaw(){var c=window.EXB_SUPABASE||{},cached='';try{cached=localStorage.getItem(RKEY)||''}catch(e){}
    if(!c.url||typeof fetch!=='function')return Promise.resolve(cached);
    return fetch(String(c.url).replace(/\/+$/,'')+'/storage/v1/object/public/vitrine/visa.png?t='+Date.now()).then(function(r){if(!r.ok)throw 0;return r.blob()})
      .then(function(b){return new Promise(function(ok,ko){var fr=new FileReader();fr.onload=function(){ok(String(fr.result))};fr.onerror=ko;fr.readAsDataURL(b)})})
      .then(function(u){if(!/^data:image\//.test(u))throw 0;try{localStorage.setItem(RKEY,u)}catch(e){}return u}).catch(function(){return cached})}
  function remoteVisa(fmt){return remoteRaw().then(function(u){if(!u)return '';if(fmt!=='jpg')return u;
    return loadImg(u).then(function(im){if(!im)return '';var f=document.createElement('canvas');f.width=im.naturalWidth;f.height=im.naturalHeight;var x=f.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,f.width,f.height);x.drawImage(im,0,0);return f.toDataURL('image/jpeg',.92)})})}
  /* visa local (appareil de l'administrateur) sinon visa public publié */
  function anyVisa(fmt){try{if(active())return visa(fmt).then(function(u){return u||remoteVisa(fmt)})}catch(e){}return remoteVisa(fmt)}
  /* pose l'image de visa dans les certificats / reçus visibles (aperçu + export) */
  function inject(root){root=root||document;
    var targets=[].slice.call(root.querySelectorAll('.cert .signs .sig:last-child, .rsign .seal'));
    if(!targets.length)return Promise.resolve();
    return visa('png').then(function(u){targets.forEach(function(t){var im=t.querySelector(':scope > img.exb-visa');
      var sg=t.closest&&t.closest('.signs');if(sg)sg.classList.toggle('has-visa',!!u);if(!u){if(im)im.remove();return}
      if(!im){im=document.createElement('img');im.className='exb-visa';im.alt='';t.insertBefore(im,t.firstChild)}
      if(im.getAttribute('src')!==u)im.setAttribute('src',u)})})}
  return {pad:pad,cleanImage:cleanImage,stampPng:stampPng,getAdmin:getAdmin,setAdmin:setAdmin,clearSig:clearSig,active:active,visa:visa,remoteVisa:remoteVisa,anyVisa:anyVisa,inject:inject,loadImg:loadImg}
})();
