/* Excellencia Building V99 — P1 Terrain : journal + QHSE + réserves + RFI sur un même modèle de données.
 * Problèmes corrigés : (1) le journal utilisait « project_id », QHSE/réserves/RFI « project » ; (2) la saisie hors ligne écrivait « name »
 * alors que la liste Projet 360° affiche « title » (fiches au titre vide) ; (3) statuts différents selon l'écran (Levée/En cours…) ;
 * (4) un incident noté dans le journal n'ouvrait aucune fiche QHSE.
 * Migration automatique, idempotente, additive : on ajoute les champs manquants et on conserve l'ancien statut dans « status_orig ».
 * Un petit fichier de retour arrière (avant/après des champs modifiés) est gardé dans exb_terrain_unif_undo. Sans perte, sans doublon. */
(function(w,d){'use strict';
var OFF='exb_terrain_unif_off',KJ='exb_site_journal',KR='exb_reserves',KQ='exb_qhse',KF='exb_rfis',UNDO='exb_terrain_unif_undo';
var CLOSED=/cl[oô]tur|lev[ée]e?\b|solde|r[ée]solu|ferm/i;
var MAP={reserve:{'levée':'Clôturée','levee':'Clôturée','en cours':'En correction'},qhse:{'levée':'Clôturée','levee':'Clôturée','en cours':'Action'}};
function S(){return w.EXBS}
function get(k){try{return S().get(k)}catch(e){return[]}}
function set(k,a){try{return S().set(k,a)}catch(e){return false}}
function str(v){return v==null?'':String(v)}
function canon(kind,st){var s=str(st).trim();if(!s)return s;var m=MAP[kind];return (m&&m[s.toLowerCase()])||s}
/* un enregistrement réserve / QHSE / RFI : alias projet, alias titre, statut canonique */
function fix(kind,r,undo,key){var b={},ch=false;
  function ch_(f,v){if(r[f]!==v){b[f]=r[f]===undefined?null:r[f];r[f]=v;ch=true}}
  var p=str(r.project)||str(r.project_id);if(p){if(r.project!==p)ch_('project',p);if(r.project_id!==p)ch_('project_id',p)}
  if(kind!=='rfi'){var t=str(r.title)||str(r.name);if(t){if(r.title!==t)ch_('title',t);if(r.name!==t)ch_('name',t)}
    var ns=canon(kind,r.status);if(ns!==str(r.status)&&r.status!==undefined){if(r.status_orig===undefined)ch_('status_orig',r.status);ch_('status',ns)}}
  if(ch&&undo)undo.push({k:key,id:r.id,before:b});return ch}
function off(){try{return localStorage.getItem(OFF)==='1'}catch(e){return false}}
function unify(){if(!S()||off())return{changed:0,created:0};var undo=[],changed=0,created=0;
  var J=get(KJ),R=get(KR),Q=get(KQ),F=get(KF),dj=false,dr=false,dq=false,df=false;
  J.forEach(function(j){var p=str(j.project_id)||str(j.project);if(p){if(j.project_id!==p){undo.push({k:KJ,id:j.id,before:{project_id:j.project_id===undefined?null:j.project_id}});j.project_id=p;dj=true;changed++}
    if(j.project!==p){undo.push({k:KJ,id:j.id,before:{project:j.project===undefined?null:j.project}});j.project=p;dj=true;changed++}}});
  R.forEach(function(r){if(fix('reserve',r,undo,KR)){dr=true;changed++}});
  Q.forEach(function(r){if(fix('qhse',r,undo,KQ)){dq=true;changed++}});
  F.forEach(function(r){if(fix('rfi',r,undo,KF)){df=true;changed++}});
  /* incident du journal => fiche QHSE (une seule fois par journal, même si la fiche est supprimée ensuite) */
  var have={};Q.forEach(function(q){if(q.from_journal)have[q.from_journal]=1});
  J.forEach(function(j){var inc=str(j.incident).trim();if(!inc||inc==='—'||j.qhse_done)return;
    if(!have[j.id]){var t='Incident chantier : '+inc.slice(0,110),p=str(j.project_id);
      Q.push({id:'QHSE-J-'+j.id,createdAt:new Date().toISOString(),project:p,project_id:p,type:'Sécurité',title:t,name:t,status:'Ouverte',note:'Issu du journal du '+str(j.date)+(j.work?' — '+str(j.work).slice(0,200):''),action:'',from_journal:j.id});dq=true;created++}
    j.qhse_done=true;dj=true});
  if(dj)set(KJ,J);if(dr)set(KR,R);if(dq)set(KQ,Q);if(df)set(KF,F);
  if(undo.length){try{var old=JSON.parse(localStorage.getItem(UNDO)||'[]');if(!Array.isArray(old))old=[];localStorage.setItem(UNDO,JSON.stringify(old.concat(undo).slice(-3000)))}catch(e){}}
  return{changed:changed,created:created}}
/* retour arrière : restaure les anciennes valeurs des champs modifiés (les fiches créées depuis un journal sont conservées) */
function undo(){try{localStorage.setItem(OFF,'1')}catch(e){}var u;try{u=JSON.parse(localStorage.getItem(UNDO)||'[]')}catch(e){u=[]}if(!u.length)return 0;
  var by={};u.slice().reverse().forEach(function(x){(by[x.k]=by[x.k]||[]).push(x)});var n=0;
  Object.keys(by).forEach(function(k){var L=get(k);by[k].forEach(function(x){var r=L.find(function(y){return y.id===x.id});if(!r)return;Object.keys(x.before).forEach(function(f){if(x.before[f]===null)delete r[f];else r[f]=x.before[f]});n++});set(k,L)});
  try{localStorage.removeItem(UNDO)}catch(e){}return n}
function isClosed(r){try{return w.EXB77&&w.EXB77.isLifted?w.EXB77.isLifted(r.status):CLOSED.test(str(r.status))}catch(e){return CLOSED.test(str(r.status))}}
/* lecteurs : tous les écrans passent par ces fonctions (champ projet unique, ouvert/clos cohérent) */
function forProject(kind,pid){var k=kind==='journal'?KJ:kind==='reserves'?KR:kind==='qhse'?KQ:KF;return get(k).filter(function(r){return str(r.project_id||r.project)===str(pid)})}
function openCount(kind,pid){return forProject(kind,pid).filter(function(r){return !isClosed(r)}).length}
function enable(){try{localStorage.removeItem(OFF)}catch(e){}return unify()}
w.EXBTerrain={unify:unify,undo:undo,enable:enable,isClosed:isClosed,forProject:forProject,openCount:openCount};
var busy=false;function run(){if(busy)return;busy=true;try{unify()}catch(e){}busy=false}
/* relance : au démarrage, au retour du réseau, au retour sur l'onglet, et après chaque écriture dans ces 4 collections */
function hook(){if(!S()||S().__unif)return;var os=S().set;S().__unif=true;
  S().set=function(k,a){var r=os.apply(this,arguments);if(!busy&&(k===KJ||k===KR||k===KQ||k===KF))setTimeout(run,0);return r}}
function start(){hook();run()}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(start,800)});else setTimeout(start,800);
w.addEventListener('online',run);d.addEventListener('visibilitychange',function(){if(!d.hidden)run()});
})(window,document);
