/* Réglages de la licence à échéance.
   requireToken:false → les appareils SANS code fonctionnent encore (déploiement progressif).
   requireToken:true  → sans code d'activation valide, le logiciel reste verrouillé (à activer quand tous vos clients ont reçu leur lien). */
window.EXB_LICENSE_CONFIG = { requireToken:true, warnDays:7, defaultGrace:7, contact:'l’administrateur du logiciel' };
