# V99w — Équipe : invitations par e-mail, rôles et fonctions (option « pré-inscription »)
Fichiers : `supabase/migration-v99w-equipe.sql` (nouveau), `exb-equipe.js` (nouveau), `exb-db.js` (1 appel automatique après connexion), `exb-v99r-shell.js` (menu), `index.html`, `sw.js` (cache `exb-v99z-poutres-3`).
Correctif : `supabase/migration-v99v-securite-licences.sql` renvoie de nouveau la *fonction* dans `rejoindre_organisation` (comme avant).

## Mise en service
1. Supabase › SQL Editor : exécuter `migration-v99w-equipe.sql` (après v66 et v99v). Réexécutable sans danger.
2. Déployer les fichiers. Paramètres › « 👥 Équipe » (visible seulement pour l'administrateur de l'entreprise en ligne).
3. Inviter : nom, e-mail, rôle, fonction → message prêt (copier / WhatsApp). La personne crée son compte avec cet e-mail : elle rejoint l'entreprise avec le bon rôle et la bonne fonction (automatiquement après connexion, ou en saisissant le code d'invitation).
- Si la personne a déjà un compte, elle est ajoutée immédiatement. Le dernier administrateur ne peut pas être retiré ni rétrogradé. Limite d'utilisateurs de la licence respectée.
