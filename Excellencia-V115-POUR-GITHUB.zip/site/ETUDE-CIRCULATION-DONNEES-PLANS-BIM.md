# Étude — circulation des données : calcul → export → plans → BIM/CDE → synchronisation

Méthode : lecture du code de chaque maillon + test de bout en bout dans l'application réelle (navigateur) : `python3 tools/test-flux/test.py` (14 contrôles), en plus de `tools/test-refs`, `tools/test-bim/*` et `tools/check.js`.

## Le trajet et son état
| Maillon | Avant cette étude | Maintenant |
|---|---|---|
| Calcul de structure → fichier (DXF / IFC) | OK : référence stable `STR-<OUVRAGE>-<TYPE>`, GlobalId IFC stables | inchangé |
| Fichier → module Plans (V81) | OK mais **manuel** (téléchargement puis « Ajouter un fichier ») | inchangé (voir « Reste à faire ») |
| Plans (V81) → registre V94 (plan, révision) | OK (V99 source unique) | OK, testé 3 fichiers → 2 plans / 3 révisions, `file_id` ↔ `revision_id` |
| Registre V94 → Bureau d'études (indices, diffusions, visas) | OK | OK, testé y compris après rechargement |
| Fichier IFC → modèle BIM V94 | **cassé** : aucun modèle BIM n'était créé, « Modèles BIM » restait à 0 et une observation ne pouvait pas viser un modèle | un IFC devient une version d'un modèle BIM (id déterministe par projet + référence) |
| Observation BIM ↔ élément | **absent** : seulement un texte « localisation » | l'observation peut viser le modèle IFC et le **GlobalId** de l'élément (22 caractères validés) : suivi dans le temps possible grâce aux GlobalId stables |
| Suppression d'un fichier / d'un plan | **liens orphelins** (révision → fichier disparu ; fichier → plan disparu) | liens détachés proprement |
| Synchronisation (base partagée `enregistrements`) | OK pour V94 et plans | OK |
| Synchronisation (copie par compte `exb-sync`) | **défaut systémique** : 85 collections sur 108 (dont plans, CDE, BIM, V94) passaient par les deux circuits ; l'ancien instantané pouvait écraser des fiches récentes | quand la base partagée est active, `exb-sync` ignore toute clé gérée par `exb-db` (envoi, réception et suppression) |

## Reste à faire (non traité ici, à décider)
1. **Calcul → Plans** : toujours deux gestes manuels. Un bouton « Envoyer vers Plans » (même origine) supprimerait l'étape de re-sélection du fichier.
2. **Espace client** : les plans publiés au client (`client_plans`) sont une copie : ni lien avec la révision V94, ni diffusion enregistrée, aucun retour de visa vers V94. À relier si le client doit viser.
3. **Parallèles hors périmètre** : `exb_cde_workflows`, `exb_approvals`, `exb_signatures` (V90) et les planches/coupes de structure (V70/V71) vivent à côté de V94.
4. **Numérotation** : un plan créé au Bureau d'études (`PL-2026-001`) et un fichier exporté (`STR-…-PLAN`) donnent deux plans V94 distincts tant que la référence n'est pas la même.
5. Les KPI de l'onglet « Enterprise 360° » se recalculent à l'ouverture, pas en direct.
6. **Non testé** sur un vrai Supabase ni en multi-appareils pour ces collections (le banc `tools/test-synchro` existant n'a pas été étendu).
