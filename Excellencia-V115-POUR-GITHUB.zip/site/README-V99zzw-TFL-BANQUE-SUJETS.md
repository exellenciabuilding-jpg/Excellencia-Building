# V99zzw — TFL : banque de 4 300 sujets (étude de la bibliothèque + intégration)

## Ce que contenait la bibliothèque envoyée
| Fichier | Contenu constaté |
|---|---|
| `Excellencia_Building_Catalogue_2600_Sujets_TFL.pdf` | 2 600 intitulés, 13 domaines × 200, références `BTP-TFL-0001` … `DUR-TFL-2600` |
| `Excellencia_Building_Catalogue_Sujets_BTP.pdf` | 1 700 intitulés BTP « exécution », 17 domaines × 100, références `EXB-BTP-0001` … `EXB-BTP-1700` |
| `Excellencia_Building_Bibliotheque_TFL.html` | application autonome contenant les mêmes 1 700 sujets BTP (+ comptes de démonstration) |

Total : **4 300 intitulés uniques**, aucun doublon de référence ni d'intitulé, aucun recoupement entre les deux catalogues.

## Constats de l'étude
1. **Peu de thèmes réels** : 600 thèmes distincts (260 + 340), déclinés en 10 ou 5 « angles » d'étude identiques (étude de cas, comparaison, diagnostic…). Les 4 300 sujets sont donc 600 thèmes × variantes.
2. **Angles génériques mal adaptés à certains thèmes** : « étude de cas dans une commune urbaine » ou « quartier en forte croissance » appliqués à des thèmes de génie rural (ex. GR-TFL-1061 : piste de desserte agricole en commune urbaine). À relire avant publication.
3. **Aucune fiche** : ni problématique, ni objectifs, ni niveau (« À préciser » partout). Le logiciel exige problématique et objectifs pour publier : la banque génère donc une fiche modèle par angle, à contextualiser.
4. **Intitulés tronqués dans les PDF** : 118 intitulés du catalogue 2 600 et 29 du catalogue BTP sont coupés par la mise en page. Ils ont été reconstitués (2 600 : séquence fixe des 10 angles) ou repris du fichier HTML (1 700).
5. **Les catalogues eux-mêmes disent** que ce sont des propositions, pas des mémoires réalisés ni des sujets approuvés, à valider par un encadreur avant publication : le logiciel les charge donc **non publiés**.
6. **Application HTML autonome** : elle contient des identifiants de démonstration en clair (`admin / ExB2026!`). Ne pas la déployer telle quelle ; les sujets sont repris dans le logiciel, pas cette application.
7. **Catégories** : la liste du logiciel (9) ne couvrait pas électricité, mécanique, informatique, HSE, génie rural, topographie, durabilité. 7 catégories ajoutées ; la filière affiche le domaine d'origine (30 filières).

## À faire (mode Internet)
1. Supabase › SQL Editor : exécuter `supabase/migration-v99zzv-tfl-sujets.sql` (si pas déjà fait), puis **`supabase/migration-v99zzw-tfl-banque-sujets.sql`** (≈ 620 Ko, réexécutable ; 3 lots d'insertion).
2. Déployer le ZIP, recharger une fois.
3. Vérifier : `select count(*) from public.tfl_sujets;` → 4 300 ; `select count(*) from public.tfl_sujets where publie;` → 0.
4. **TFL › 📋 Sujets › 📚 Banque** : chercher, ajouter à vos fiches (300 au plus à la fois), contextualiser, faire valider, **Publier**, puis **Synchroniser**.

## Ce que fait le SQL V99zzw
- Charge les 4 300 sujets dans `tfl_sujets` (publie = false, disponible, exclusif) ; `on conflict do nothing` : aucune fiche existante n'est écrasée.
- `tfl_sujets_publics_page` : lecture publique paginée (30 par page, 60 au plus) avec recherche sans accents et filtres côté serveur — l'ancienne `tfl_sujets_publics` plafonne à 500 lignes.
- `tfl_sujets_facettes` : catégories/filières pour les filtres. `tfl_sujets_publier_lot(préfixe, oui)` : publier/retirer un lot (admin, 300 au plus par appel ; à n'utiliser qu'après relecture).

## Logiciel
- Banque (`tfl-banque.json`, 556 Ko) hors du stockage local ; seules les fiches adoptées sont copiées dans `exb_tfl_sujets` (~1,4 Ko chacune ; le navigateur limite le stockage : adoptez ce dont vous avez besoin, pas les 4 300).
- Mes fiches : plus récentes d'abord, 40 affichées puis « Afficher plus ». Synchronisation par lots de 300.
- Page publique : mode paginé automatique ; sans la migration V99zzw elle retombe sur l'ancienne fonction, sans serveur sur `tfl-sujets.json` (50 affichés puis « Voir plus »).

## Limites
- **Le SQL n'a pas été exécuté sur un vrai PostgreSQL/Supabase** (indisponible ici) : contrôles de syntaxe lexicaux seulement. Testez dans un projet d'essai ou relisez avant la production.
- Les fiches générées sont des **modèles génériques** ; elles n'ont aucune valeur académique tant qu'un encadreur ne les a pas contextualisées.
- Le tri public est par référence (pas par pertinence). Ajouter les sujets les plus pertinents en premier demande de les publier en premier.
- Testé dans Chromium (390 px) avec serveur simulé ; non testé sur un vrai téléphone ni dans l'application complète.

## Fichiers
Nouveaux : `tfl-banque.json`, `supabase/migration-v99zzw-tfl-banque-sujets.sql`, `tools/test-tfl/test-banque.js`, `e2e-banque.py`, `e2e-sujets-pagine.py`. Modifiés : `exb-tfl.js`, `tfl-sujets.html`, `sw.js` (cache `exb-v99zzw-tfl-banque`), `tools/check.js` (+9).
Contrôles : `node tools/test-tfl/test-banque.js` · `python3 tools/test-tfl/e2e-banque.py` · `python3 tools/test-tfl/e2e-sujets-pagine.py` · `node tools/check.js` (390).
Retour en arrière : restaurer `exb-tfl.js`, `tfl-sujets.html`, `sw.js`, `tools/check.js` de V99zzv. Les fiches adoptées restent dans `exb_tfl_sujets`.
