/* Excellencia Building V99v — ESPACE PROPRIÉTAIRE (visible uniquement sur l'appareil qui détient la clé privée de licence).
 * 1) Sauvegarde / restauration de la clé privée de licence : fichier chiffré (mot de passe → PBKDF2 250 000 tours → AES-256-GCM).
 * 2) Clients et licences : créer une entreprise cliente en essai, émettre/renouveler une licence (code signé),
 *    suspendre, suivre échéances, utilisateurs et activité. Nécessite supabase/migration-v99v-securite-licences.sql
 *    et votre compte en ligne déclaré « propriétaire » (voir l'en-tête du script SQL).
 * Aucune donnée existante n'est modifiée. */
(function(w,d){'use strict';
var KP='exb_lic_priv',KB='exb_lic_backup_at',ITER=250000;
var $=function(i){return d.getElementById(i)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function ls(k,v){try{if(v===undefined)return w.localStorage.getItem(k);if(v===null)w.localStorage.removeItem(k);else w.localStorage.setItem(k,v)}catch(e){return null}}
function fr(t){if(!t)return '—';var x=new Date(t);return isNaN(x)?'—':x.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})}
function days(t){return t?Math.ceil((new Date(t).getTime()-Date.now())/864e5):null}
function b64(u){var s='';u=new Uint8Array(u);for(var i=0;i<u.length;i++)s+=String.fromCharCode(u[i]);return btoa(s)}
function unb64(s){var b=atob(s),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
var sub=w.crypto&&w.crypto.subtle,enc=new TextEncoder(),dec=new TextDecoder();

/* ---------- chiffrement de la sauvegarde ---------- */
async function derive(pass,salt,iter){var m=await sub.importKey('raw',enc.encode(pass),'PBKDF2',false,['deriveKey']);
 return sub.deriveKey({name:'PBKDF2',salt:salt,iterations:iter,hash:'SHA-256'},m,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
async function encryptText(text,pass){var salt=w.crypto.getRandomValues(new Uint8Array(16)),iv=w.crypto.getRandomValues(new Uint8Array(12)),k=await derive(pass,salt,ITER);
 var ct=await sub.encrypt({name:'AES-GCM',iv:iv},k,enc.encode(text));
 return {app:'excellencia-licence-key',v:1,kdf:'PBKDF2-SHA256',iter:ITER,salt:b64(salt),iv:b64(iv),data:b64(ct),date:new Date().toISOString()}}
async function decryptText(file,pass){if(!file||file.app!=='excellencia-licence-key')throw new Error('Ce fichier n’est pas une sauvegarde de clé de licence.');
 var k=await derive(pass,unb64(file.salt),file.iter||ITER);
 try{var pt=await sub.decrypt({name:'AES-GCM',iv:unb64(file.iv)},k,unb64(file.data));return dec.decode(pt)}catch(e){throw new Error('Mot de passe incorrect ou fichier modifié.')}}
/* Une clé n'est acceptée que si elle signe des codes que le logiciel reconnaît (clé publique intégrée). */
async function keyWorks(jwk){try{var k=await sub.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 var p={v:1,name:'test',exp:new Date(Date.now()+864e5).toISOString(),grace:0,iat:new Date().toISOString(),id:'test'},b=enc.encode(JSON.stringify(p)),sg=await sub.sign({name:'ECDSA',hash:'SHA-256'},k,b);
 var tok=b64url(b)+'.'+b64url(sg);return !!(w.EXBLIC&&await w.EXBLIC.verify(tok))}catch(e){return false}}
function b64url(u){return b64(u).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function download(name,text){var a=d.createElement('a'),u=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.href=u;a.download=name;d.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},1500)}

async function backupKey(){var raw=ls(KP);if(!raw)return alert('Aucune clé privée sur cet appareil.');
 var p1=prompt('Choisissez un mot de passe de sauvegarde (10 caractères minimum).\nSans lui, la sauvegarde est inutilisable : notez-le ailleurs que dans le même fichier.');if(p1===null)return;
 if(p1.length<10)return alert('Mot de passe trop court (10 caractères minimum).');
 var p2=prompt('Retapez le mot de passe pour confirmer :');if(p2!==p1)return alert('Les deux mots de passe ne correspondent pas.');
 try{var f=await encryptText(raw,p1);download('SAUVEGARDE-CLE-LICENCE-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify(f,null,1));ls(KB,new Date().toISOString());
  alert('✓ Sauvegarde créée.\nConservez ce fichier dans au moins 2 endroits sûrs (clé USB, e-mail privé, coffre) et le mot de passe séparément.');render()}
 catch(e){alert('Sauvegarde impossible : '+(e.message||e))}}
async function restoreKey(file){if(!file)return;var f;try{f=JSON.parse(await file.text())}catch(e){return alert('Fichier illisible.')}
 var p=prompt('Mot de passe de la sauvegarde :');if(p===null)return;
 try{var t=await decryptText(f,p),j=JSON.parse(t);if(!j.d||!await keyWorks(j))throw new Error('Cette clé ne correspond pas à ce logiciel.');
  ls(KP,JSON.stringify(j));alert('✓ Clé restaurée : cet appareil est de nouveau administrateur des licences.');render()}
 catch(e){alert('Restauration impossible : '+(e.message||e))}}

/* ---------- serveur ---------- */
function isIn(){return !!(w.exbSb&&w.exbSb.isIn&&w.exbSb.isIn())}
function rpc(n,b){return w.exbSb.api('/rest/v1/rpc/'+n,{method:'POST',body:JSON.stringify(b||{})})}
function srvErr(e){var m=String(e&&e.message||e);if(/propri[eé]taire|42883|404|function/i.test(m))return 'Espace non activé : exécutez supabase/migration-v99v-securite-licences.sql dans Supabase, puis déclarez votre e-mail comme propriétaire (voir l’en-tête du script). ('+m+')';return m}
var CLIENTS=[],LOADING=false,ERR='';
async function load(){if(!isIn()){CLIENTS=[];ERR='';return}LOADING=true;ERR='';render();
 try{var r=await rpc('owner_liste');CLIENTS=Array.isArray(r)?r:[]}catch(e){ERR=srvErr(e);CLIENTS=[]}LOADING=false;render()}

function etat(c){var now=Date.now(),ex=c.expire_le?new Date(c.expire_le).getTime():null;
 if(c.statut==='resilie')return {t:'Résilié',k:'off'};if(c.statut==='suspendu')return {t:'Suspendu',k:'off'};
 if(ex&&ex<now)return {t:'Expiré',k:'off'};
 var j=days(c.expire_le);if(c.statut==='essai')return {t:'Essai'+(j!=null?' · J-'+Math.max(0,j):''),k:'warn'};
 return {t:'Actif'+(j!=null&&j<=15?' · J-'+j:''),k:j!=null&&j<=15?'warn':'ok'}}

/* ---------- fenêtres ---------- */
function modal(html,onOpen){var o=$('exbOwnModal');if(o)o.remove();o=d.createElement('div');o.id='exbOwnModal';o.className='no-print';
 o.style.cssText='position:fixed;inset:0;z-index:100005;background:#0009;display:grid;place-items:center;padding:14px';
 o.innerHTML='<div class="card" style="width:min(520px,100%);max-height:92vh;overflow:auto;margin:0">'+html+'</div>';
 o.addEventListener('click',function(e){if(e.target===o)o.remove()});d.body.appendChild(o);if(onOpen)onOpen(o);return o}
function close(){var o=$('exbOwnModal');if(o)o.remove()}
async function copy(t){try{await navigator.clipboard.writeText(t);return true}catch(e){return false}}
function link(tok){return (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,''))+'#lic='+tok}

function newClient(){modal('<h2>➕ Nouveau client (essai)</h2><label>Nom du client / de l’entreprise</label><input id="owc_nom" placeholder="Ex. Bureau d’études Kasa"><label>Contact (e-mail ou téléphone)</label><input id="owc_ct"><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div><label>Durée de l’essai (jours)</label><input id="owc_j" type="number" min="1" max="90" value="14"></div><div><label>Utilisateurs maximum</label><input id="owc_m" type="number" min="1" max="1000" value="5"></div></div><p class="hint">Une entreprise vide est créée sur le serveur. Le premier compte qui saisit son code d’invitation en devient l’administrateur.</p><div id="owc_msg" class="hint"></div><div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px"><button class="muted" id="owc_x">Annuler</button><button class="primary" id="owc_go">Créer et générer l’essai</button></div>',function(){
  $('owc_x').onclick=close;$('owc_go').onclick=async function(){var nom=$('owc_nom').value.trim();if(!nom){$('owc_msg').textContent='Le nom est obligatoire.';return}
   $('owc_go').disabled=true;$('owc_msg').textContent='Création…';
   try{var r=await rpc('owner_creer_client',{p_nom:nom,p_contact:$('owc_ct').value.trim()||null,p_jours_essai:+$('owc_j').value||14,p_max:+$('owc_m').value||5});
    var tok=await w.EXBLIC.make({name:nom,exp:new Date(r.essai_fin),grace:3});try{await rpc('owner_maj_licence',{p_id:r.licence_id,p_jeton:tok})}catch(e){}
    var lk=link(tok);await copy(lk);
    modal('<h2>✓ Client créé</h2><p><b>'+esc(nom)+'</b> — essai jusqu’au <b>'+esc(fr(r.essai_fin))+'</b>.</p><label>1) Lien d’activation du logiciel (copié)</label><input readonly value="'+esc(lk)+'" onclick="this.select()"><label>2) Code d’invitation de l’entreprise</label><input readonly value="'+esc(r.code)+'" onclick="this.select()"><p class="hint">Le client ouvre le lien, crée son compte en ligne, puis saisit le code d’invitation : il devient administrateur de son entreprise et invite ensuite ses collègues.</p><div style="text-align:right"><button class="primary" id="owc_ok">Terminé</button></div>',function(){$('owc_ok').onclick=function(){close();load()}})}
   catch(e){$('owc_go').disabled=false;$('owc_msg').textContent='Erreur : '+srvErr(e)}}})}

function licence(c){var base=c.expire_le&&new Date(c.expire_le)>new Date()?new Date(c.expire_le):new Date();
 modal('<h2>🔑 Licence — '+esc(c.client_nom)+'</h2><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div><label>Formule</label><select id="owl_p"><option value="standard"'+(c.plan==='standard'?' selected':'')+'>Standard</option><option value="pro"'+(c.plan==='pro'?' selected':'')+'>Pro</option></select></div><div><label>Durée à ajouter</label><select id="owl_d"><option value="1">1 mois</option><option value="3">3 mois</option><option value="6">6 mois</option><option value="12" selected>12 mois</option></select></div><div><label>Utilisateurs maximum</label><input id="owl_m" type="number" min="1" max="1000" value="'+(+c.max_utilisateurs||5)+'"></div><div><label>Tolérance après échéance (jours)</label><input id="owl_g" type="number" min="0" max="30" value="7"></div></div><p class="hint" id="owl_h"></p><div id="owl_msg" class="hint"></div><div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px"><button class="muted" id="owl_x">Annuler</button><button class="primary" id="owl_go">Émettre le code</button></div>',function(){
  function upd(){var e=new Date(base);e.setMonth(e.getMonth()+(+$('owl_d').value));$('owl_h').textContent='Nouvelle échéance : '+fr(e)+' (calculée à partir de '+(base>new Date()?'l’échéance actuelle':'aujourd’hui')+').'}
  $('owl_d').onchange=upd;upd();$('owl_x').onclick=close;
  $('owl_go').onclick=async function(){$('owl_go').disabled=true;$('owl_msg').textContent='Émission…';
   try{var e=new Date(base);e.setMonth(e.getMonth()+(+$('owl_d').value));e.setHours(23,59,0,0);
    var tok=await w.EXBLIC.make({name:c.client_nom,exp:e,grace:+$('owl_g').value||0});
    await rpc('owner_maj_licence',{p_id:c.id,p_statut:'actif',p_plan:$('owl_p').value,p_expire:e.toISOString(),p_max:+$('owl_m').value||5,p_jeton:tok});
    var lk=link(tok);await copy(lk);
    modal('<h2>✓ Licence émise</h2><p>Valable jusqu’au <b>'+esc(fr(e))+'</b> (lien copié). Envoyez-le au client : il suffit de l’ouvrir sur chaque appareil.</p><input readonly value="'+esc(lk)+'" onclick="this.select()"><div style="text-align:right;margin-top:12px"><button class="primary" id="owl_ok">Terminé</button></div>',function(){$('owl_ok').onclick=function(){close();load()}})}
   catch(er){$('owl_go').disabled=false;$('owl_msg').textContent='Erreur : '+srvErr(er)}}})}

async function toggle(c){var susp=c.statut==='suspendu';
 if(!confirm(susp?'Réactiver « '+c.client_nom+' » ?':'Suspendre « '+c.client_nom+' » ?\nLes nouveaux comptes ne pourront plus rejoindre l’entreprise. Les appareils déjà activés restent valables jusqu’à l’échéance de leur code.'))return;
 try{await rpc('owner_maj_licence',{p_id:c.id,p_statut:susp?(c.plan==='essai'?'essai':'actif'):'suspendu'});load()}catch(e){alert(srvErr(e))}}
async function inviteCode(c){if(await copy(c.code_invitation))alert('Code d’invitation copié : '+c.code_invitation);else prompt('Code d’invitation :',c.code_invitation)}

/* ---------- affichage ---------- */
function render(){var el=$('proprietaire');if(!el||el.style.display==='none')return;
 var has=!!ls(KP),bk=ls(KB);
 var keyCard='<div class="card"><h2>🗝️ Clé privée de licence</h2><p>'+(has?'<span class="valid">✓ Présente'+(w.EXBKEY&&w.EXBKEY.persistent()?' — ⚠ conservée durablement sur cet appareil : créez la sauvegarde chiffrée, la clé sera ensuite retirée du stockage de l’appareil':' pour cette session (effacée à la fermeture ; restaurez-la depuis la sauvegarde chiffrée au besoin)')+'</span>':'<span class="ann">Absente de cet appareil — restaurez-la depuis la sauvegarde chiffrée</span>')+'</p><p class="hint">Cette clé signe tous les codes de licence. <b>Si elle est perdue, plus aucun code ne peut être émis.</b> '+(bk?'Dernière sauvegarde : '+esc(fr(bk))+'.':'<b>Aucune sauvegarde enregistrée.</b>')+'</p><label style="display:block;margin-top:8px"><input type="checkbox" id="owp_keep"> Garder la clé sur cet appareil (ne plus la redemander)</label><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">'+(has?'<button class="primary" id="owp_bk">💾 Sauvegarder la clé (chiffrée)</button>':'')+'<button class="muted" id="owp_rs">📂 Restaurer depuis une sauvegarde</button><input type="file" id="owp_f" accept=".json,application/json" style="display:none"></div></div>';
 var rows=CLIENTS.map(function(c,i){var s=etat(c);return '<tr><td><b>'+esc(c.client_nom)+'</b><br><span class="hint">'+esc(c.contact||'')+'</span></td><td><span class="tag '+s.k+'">'+esc(s.t)+'</span></td><td>'+esc(fr(c.expire_le))+'</td><td>'+(+c.nb_membres||0)+' / '+(+c.max_utilisateurs||0)+'</td><td>'+esc(fr(c.derniere_activite))+'</td><td style="white-space:nowrap"><button class="primary" data-a="lic" data-i="'+i+'">🔑 Licence</button> <button class="muted" data-a="code" data-i="'+i+'">📋 Code</button> <button class="muted" data-a="tg" data-i="'+i+'">'+(c.statut==='suspendu'?'▶ Réactiver':'⏸ Suspendre')+'</button></td></tr>'}).join('');
 var tot=CLIENTS.length,act=CLIENTS.filter(function(c){return etat(c).k==='ok'}).length,ess=CLIENTS.filter(function(c){return c.statut==='essai'&&etat(c).k!=='off'}).length,exp=CLIENTS.filter(function(c){var j=days(c.expire_le);return etat(c).k!=='off'&&j!=null&&j<=15}).length;
 var cl='<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h2 style="margin:0">🏢 Clients et licences</h2><div style="display:flex;gap:8px"><button class="muted" id="owp_rf">↻ Actualiser</button><button class="primary" id="owp_nw">➕ Nouveau client</button></div></div>'+
  (!isIn()?'<p class="hint" style="margin-top:12px">Connectez-vous à votre compte en ligne (Paramètres › Synchronisation) pour gérer les clients.</p>':
   LOADING?'<p class="hint" style="margin-top:12px">Chargement…</p>':ERR?'<p class="ann" style="margin-top:12px">'+esc(ERR)+'</p>':
   '<p class="hint" style="margin:10px 0">'+tot+' client(s) · '+act+' actif(s) · '+ess+' en essai · '+exp+' à renouveler sous 15 jours</p>'+(tot?'<div class="tablewrap"><table class="tbl"><thead><tr><th>Client</th><th>Statut</th><th>Échéance</th><th>Utilisateurs</th><th>Dernière activité</th><th>Actions</th></tr></thead><tbody>'+rows+'</tbody></table></div>':'<p class="hint">Aucun client pour le moment. Cliquez sur « Nouveau client » pour créer un essai.</p>'))+'</div>';
 el.innerHTML='<div class="card"><h2>👑 Espace propriétaire</h2><p class="hint">Visible uniquement sur l’appareil qui détient la clé de licence.</p></div>'+keyCard+cl+'<div id="owp_err"></div>';
 try{if(w.EXBERR)w.EXBERR.panel($('owp_err'),true)}catch(e){}
 var kp=$('owp_keep');if(kp&&w.EXBKEY){kp.checked=w.EXBKEY.keep();kp.onchange=function(){w.EXBKEY.keep(kp.checked);render()}}var b=$('owp_bk');if(b)b.onclick=backupKey;$('owp_rs').onclick=function(){$('owp_f').click()};$('owp_f').onchange=function(e){restoreKey(e.target.files[0]);e.target.value=''};
 var rf=$('owp_rf');if(rf)rf.onclick=load;var nw=$('owp_nw');if(nw)nw.onclick=function(){if(!isIn())return alert('Connectez-vous d’abord à votre compte en ligne.');newClient()};
 el.querySelectorAll('button[data-a]').forEach(function(x){x.onclick=function(){var c=CLIENTS[+x.dataset.i],a=x.dataset.a;if(a==='lic')licence(c);else if(a==='code')inviteCode(c);else toggle(c)}})}

/* ---------- montage : bouton + section, seulement pour le propriétaire de la clé ---------- */
var tries=0;
function mount(){if($('proprietaire')||!w.EXBLIC||!w.EXBLIC.isAdmin||!w.EXBLIC.isAdmin())return;
 var adm=$('administration'),b=$('badm');if(!adm||!b)return;
 var anc=$('exbModBar')||$('exbCrumb');if(!anc&&++tries<12)return;
 (anc||adm).insertAdjacentHTML('afterend','<section id="proprietaire" class="no-print" style="display:none"></section>');
 b.insertAdjacentHTML('afterend',' <button id="bprop" onclick="show(\'proprietaire\')">👑 Espace propriétaire</button>');
 var os=w.show;w.show=function(x){var r=os.apply(this,arguments);var el=$('proprietaire');if(el)el.style.display=x==='proprietaire'?'':'none';if(x==='proprietaire'){render();load()}return r}}
setInterval(mount,1500);
w.EXB_OWNER={backup:backupKey,restore:restoreKey,_enc:encryptText,_dec:decryptText,_keyWorks:keyWorks,reload:load,version:'V99v'};
})(window,document);
