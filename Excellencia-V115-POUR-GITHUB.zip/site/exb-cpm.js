/* Excellencia Building V99zq — Moteur de planning : dépendances, marges et chemin critique (audit interne : « Planning de chantier », P1).
 * Unité : la semaine (comme le Gantt existant). Liens fin → début avec décalage (lag) en semaines.
 * Saisie des prédécesseurs : « 1, 3+1, 5-1 » = après la tâche n° 1 ; après la 3 avec 1 semaine de décalage ; après la 5 avec 1 semaine de chevauchement.
 * Début saisi (« Début ») = « ne pas commencer avant » (contrainte). */
(function(root){'use strict';
var N=function(x){x=+x;return isFinite(x)?x:0};
function parsePred(str,n,self){var out=[],bad=[];String(str==null?'':str).split(/[,;]/).forEach(function(tok){tok=tok.trim();if(!tok)return;
  var m=/^(\d+)\s*([+-]\s*\d+)?$/.exec(tok);if(!m){bad.push(tok);return}
  var i=parseInt(m[1],10)-1,lag=m[2]?parseInt(m[2].replace(/\s/g,''),10):0;
  if(i<0||i>=n||i===self){bad.push(tok);return}
  out.push({i:i,lag:lag})});return {list:out,bad:bad}}
/* tasks : [{start,dur,pct,pred}] ; cw : semaine en cours (0 = inconnue) */
function compute(tasks,cw){
  var n=tasks.length,T=tasks.map(function(t,i){var p=parsePred(t.pred,n,i);return {i:i,start:Math.max(1,N(t.start)||1),dur:Math.max(1,N(t.dur)||1),pct:Math.min(100,Math.max(0,N(t.pct))),preds:p.list,bad:p.bad}});
  var succ=T.map(function(){return[]}),indeg=T.map(function(t){return t.preds.length});
  T.forEach(function(t){t.preds.forEach(function(p){succ[p.i].push({i:t.i,lag:p.lag})})});
  /* ordre topologique + détection de cycle */
  var q=[],order=[];indeg.forEach(function(d,i){if(!d)q.push(i)});
  while(q.length){var a=q.shift();order.push(a);succ[a].forEach(function(s){if(--indeg[s.i]===0)q.push(s.i)})}
  if(order.length<n){var cyc=[];indeg.forEach(function(d,i){if(d>0)cyc.push(i+1)});return {error:'cycle',cycle:cyc,tasks:[]}}
  /* passe avant */
  var ES=[],EF=[],need=[];
  order.forEach(function(i){var t=T[i],req=1;t.preds.forEach(function(p){req=Math.max(req,EF[p.i]+1+p.lag)});need[i]=req;ES[i]=Math.max(t.start,req);EF[i]=ES[i]+t.dur-1});
  var end=EF.length?Math.max.apply(null,EF):0;
  /* passe arrière */
  var LF=[],LS=[];
  order.slice().reverse().forEach(function(i){var lf=end;succ[i].forEach(function(s){lf=Math.min(lf,LS[s.i]-1-s.lag)});LF[i]=lf;LS[i]=lf-T[i].dur+1});
  /* prévision avec l'avancement réel (retard) */
  var F=null,delay=0,Fs=[],Fe=[];
  if(cw>0){order.forEach(function(i){var t=T[i];
      if(t.pct>=100){Fs[i]=ES[i];Fe[i]=EF[i];return}
      var begin=t.start;t.preds.forEach(function(p){begin=Math.max(begin,Fe[p.i]+1+p.lag)});
      var remaining=Math.max(1,Math.ceil(t.dur*(1-t.pct/100)-1e-9));
      if(t.pct>0||ES[i]<cw)begin=Math.max(begin,cw);
      Fs[i]=begin;Fe[i]=begin+remaining-1});
    var fe=Fe.length?Math.max.apply(null,Fe):0;F=fe;delay=Math.max(0,fe-end)}
  var out=T.map(function(t,i){var fl=LS[i]-ES[i];return {num:i+1,es:ES[i],ef:EF[i],ls:LS[i],lf:LF[i],marge:fl,critique:fl===0,
    conflit:t.start<need[i]&&need[i]>1?need[i]:0,pred_invalides:t.bad,
    fin_prevue:F===null?null:Fe[i],retard:F===null?0:Math.max(0,Fe[i]-EF[i])}});
  var crit=out.filter(function(o){return o.critique}).map(function(o){return o.num});
  return {error:null,tasks:out,fin:end,finPrevue:F,retardProjet:delay,critiques:crit,conflits:out.filter(function(o){return o.conflit}).map(function(o){return o.num})}}
/* recale les débuts selon les dépendances (début = début au plus tôt) */
function recaler(tasks){var r=compute(tasks,0);if(r.error)return r;return {error:null,starts:r.tasks.map(function(o){return o.es})}}
/* enchaîne les tâches dans l'ordre : chaque tâche sans prédécesseur dépend de la précédente */
function enchainer(tasks){return tasks.map(function(t,i){return(i>0&&!String(t.pred||'').trim())?String(i):String(t.pred||'')})}
/* renumérotation des prédécesseurs après suppression de la tâche n° k (1-based) */
function apresSuppression(tasks,k){return tasks.map(function(t){var out=[];String(t.pred||'').split(/[,;]/).forEach(function(tok){tok=tok.trim();var m=/^(\d+)\s*([+-]\s*\d+)?$/.exec(tok);if(!m)return;var i=parseInt(m[1],10);if(i===k)return;out.push((i>k?i-1:i)+(m[2]?m[2].replace(/\s/g,''):''))});return out.join(', ')})}
var API={parsePred:parsePred,compute:compute,recaler:recaler,enchainer:enchainer,apresSuppression:apresSuppression};
root.EXBCPM=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
