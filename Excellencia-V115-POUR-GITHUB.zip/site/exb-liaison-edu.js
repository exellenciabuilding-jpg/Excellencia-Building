/* Excellencia Building V99 — LIAISON FORMATION & TFL (extension de exb-liaison.js).
 * Formation : participant ↔ formation ↔ paiements ↔ reçus ↔ certificats (identifiants, solde, incohérences).
 * TFL : étudiant TFL ↔ participant (même personne), encadreur TFL ↔ formateur/personnel, contrôles de cohérence du dossier.
 * Principe identique : on AJOUTE des identifiants ; on ne modifie ni ne supprime aucune donnée existante, aucun reçu ni certificat déjà émis,
 * et on ne crée jamais de paiement automatiquement (un reçu non rapproché est signalé, le rapprochement se fait sur confirmation). */
(function(w,d){'use strict';
function boot(){var X=w.EXBLIEN;if(!X||!X.extend){return setTimeout(boot,300)}
var rd=X.rd,wr=X.wr,norm=X.norm,digits=X.digits,esc=X.esc,num=X.num,r2=X.r2,fmt=X.fmt;
var K={par:'exb_participants',form:'exb_formations',pay:'exb_payments',rec:'exb_receipts',cert:'exb_certificates',trn:'exb_trainers',hr:'exb_hr',etu:'exb_tfl_etudiants',dos:'exb_tfl_dossiers',enc:'exb_tfl_encadreurs'};
function amount(v){var n=parseFloat(String(v==null?'':v).replace(/\s/g,'').replace(',','.').replace(/[^0-9.\-]/g,''));return isFinite(n)?n:0}
function same(a,b){var x=digits(a),y=digits(b);if(x.length<6||y.length<6)return false;return x===y||(x.length>=9&&y.length>=9&&x.slice(-9)===y.slice(-9))}
function uniq(a){return a.length===1?a[0]:null}
var DONE_ST=/(valid|termin|achev|obten|r[eé]ussi)/i;

/* ================= FORMATION ================= */
function indexes(){var F=rd(K.form),P=rd(K.par);return{F:F,P:P,fById:Object.fromEntries(F.map(function(f){return[f.formation_id,f]})),pById:Object.fromEntries(P.map(function(p){return[p.participant_id,p]}))}}
function formationOf(p,ix){if(!p)return null;if(p.formation_id&&ix.fById[p.formation_id])return ix.fById[p.formation_id];var h=ix.F.filter(function(f){return norm(f.name)===norm(p.training)});return uniq(h)}
function receiptTotal(r){return amount(r.registration_fee)+amount(r.training_fee)}
function findParticipantForReceipt(r,ix){if(r.participant_id&&ix.pById[r.participant_id])return ix.pById[r.participant_id];
 if(r.matricule){var m=ix.P.filter(function(p){return p.matricule&&String(p.matricule).trim()===String(r.matricule).trim()});if(m.length===1)return m[0]}
 var byName=ix.P.filter(function(p){return norm(p.name)===norm(r.participant)}),withTr=byName.filter(function(p){return !r.training||norm(p.training)===norm(r.training)});return uniq(withTr)||uniq(byName)}
function linkFormation(){var ix=indexes(),res={participants:0,payments:0,receipts:0,rapproches:0,certs:0},pay=rd(K.pay),rec=rd(K.rec),cert=rd(K.cert);
 var chP=false;ix.P.forEach(function(p){if(p.formation_id)return;var f=formationOf(p,ix);if(f){p.formation_id=f.formation_id;res.participants++;chP=true}});if(chP)wr(K.par,ix.P);
 var chY=false;pay.forEach(function(y){var p=ix.pById[y.participant_id];if(p&&!y.formation_id&&p.formation_id){y.formation_id=p.formation_id;res.payments++;chY=true}});
 var chR=false;rec.forEach(function(r){var p=findParticipantForReceipt(r,ix),mod=false;if(p&&!r.participant_id){r.participant_id=p.participant_id;mod=true}if(p&&!r.formation_id&&p.formation_id){r.formation_id=p.formation_id;mod=true}
  var t=receiptTotal(r);if(p&&t>0&&!r.payment_id){var linked={};rec.forEach(function(x){if(x.payment_id)linked[x.payment_id]=1});
   var c=pay.filter(function(y){return y.participant_id===p.participant_id&&!linked[y.payment_id]&&!y.receipt_no&&Math.abs(num(y.amount)-t)<0.005});
   var y1=uniq(c);if(y1){r.payment_id=y1.payment_id;y1.receipt_no=r.receipt_no;res.rapproches++;mod=true;chY=true}}
  if(mod){res.receipts++;chR=true}});
 if(chY)wr(K.pay,pay);if(chR)wr(K.rec,rec);
 var chC=false;cert.forEach(function(c){if(c.participant_id&&ix.pById[c.participant_id])return;var m=ix.P.filter(function(p){return norm(p.name)===norm(c.holder)&&(!c.training||norm(p.training)===norm(c.training))}),p=uniq(m);if(p){c.participant_id=p.participant_id;res.certs++;chC=true}});if(chC)wr(K.cert,cert);
 res.total=res.participants+res.payments+res.receipts+res.certs;if(res.total)X.log('liaison_formation',res,res.total+' fiche(s) de formation rattachée(s)');return res}

function situation(pid){var ix=indexes(),p=ix.pById[pid];if(!p)return null;var f=formationOf(p,ix),price=f?num(f.price):0,pay=rd(K.pay).filter(function(y){return y.participant_id===pid}),verse=r2(pay.reduce(function(a,y){return a+num(y.amount)},0)),
 recs=rd(K.rec).filter(function(r){return r.participant_id===pid}),nonRap=recs.filter(function(r){return receiptTotal(r)>0&&!r.payment_id&&!pay.length});
 var st=price>0?(verse>=price?'total':verse>=price/2?'moitie':verse>0?'partiel':'non_paye'):(verse>0?'partiel':'non_paye');
 return{participant_id:pid,nom:p.name,formation:f?f.name:(p.training||''),prix:price,verse:verse,solde:r2(Math.max(0,price-verse)),statut:st,nbPaiements:pay.length,recusNonRapproches:nonRap.length}}
function totals(){var ix=indexes(),out={};ix.P.filter(function(p){return p.approval_status!=='REJETE'}).forEach(function(p){var s=situation(p.participant_id);if(!s)return;var o=out[s.formation||'(sans formation)']=out[s.formation||'(sans formation)']||{formation:s.formation||'(sans formation)',inscrits:0,attendu:0,verse:0,solde:0,soldes:0};o.inscrits++;o.attendu+=s.prix;o.verse+=s.verse;o.solde+=s.solde;if(s.solde>0)o.soldes++});
 return Object.keys(out).map(function(k){var o=out[k];o.attendu=r2(o.attendu);o.verse=r2(o.verse);o.solde=r2(o.solde);return o})}
function anomaliesFormation(){var ix=indexes(),a=[],pay=rd(K.pay),rec=rd(K.rec),cert=rd(K.cert);
 pay.forEach(function(y){if(!ix.pById[y.participant_id])a.push('Paiement formation '+(y.reference||y.payment_id)+' ('+y.amount+') : participant introuvable')});
 rec.forEach(function(r){var t=receiptTotal(r);if(t<=0)return;if(!r.participant_id)a.push('Reçu '+(r.receipt_no||'')+' : participant non identifié de façon sûre ('+(r.participant||'?')+')');else if(!r.payment_id&&!pay.some(function(y){return y.participant_id===r.participant_id}))a.push('Reçu '+(r.receipt_no||'')+' ('+t+') sans aucun paiement enregistré pour '+(r.participant||'?')+' : enregistrez le paiement dans Finances')});
 cert.forEach(function(c){if(!c.participant_id)return;var s=situation(c.participant_id);if(s&&s.prix>0&&s.solde>0&&(c.status||'VALIDE')==='VALIDE')a.push('Certificat '+(c.cert_no||'')+' délivré à '+(c.holder||s.nom)+' alors qu’il reste '+fmt(s.solde)+' à payer')});
 ix.P.forEach(function(p){if(p.approval_status==='REJETE')return;var f=formationOf(p,ix);if(p.training&&!f)a.push('Participant '+(p.name||p.participant_id)+' : formation « '+p.training+' » absente du catalogue des formations');
  var s=situation(p.participant_id);if(s&&p.pay&&p.pay.form==='total'&&s.prix>0&&s.statut!=='total'&&s.nbPaiements>0)a.push('Participant '+p.name+' : marqué « payé » mais les paiements enregistrés ('+fmt(s.verse)+') n’atteignent pas le prix ('+fmt(s.prix)+')')});
 ix.F.forEach(function(f){if(!num(f.price)&&ix.P.some(function(p){return p.approval_status!=='REJETE'&&(p.formation_id===f.formation_id||norm(p.training)===norm(f.name))}))a.push('Formation « '+f.name+' » : prix non renseigné (le solde des participants ne peut pas être calculé)')});
 var seen={};ix.P.forEach(function(p){var k=digits(p.phone).slice(-9)||String(p.email||'').toLowerCase();if(!k||k.length<6)return;if(seen[k])a.push('Participants en double possible : « '+seen[k]+' » et « '+p.name+' » (même téléphone/e-mail)');else seen[k]=p.name});
 return a}

/* ================= TFL ================= */
function linkTfl(){var res={etudiants:0,encadreurs:0},P=rd(K.par),E=rd(K.etu),C=rd(K.enc),T=rd(K.trn),H=rd(K.hr);
 var chE=false,chP=false;E.forEach(function(e){if(e.participant_id&&P.some(function(p){return p.participant_id===e.participant_id}))return;
  var m=[];if(e.matricule)m=P.filter(function(p){return p.matricule&&String(p.matricule).trim()===String(e.matricule).trim()});
  if(m.length!==1)m=P.filter(function(p){return (e.telephone&&same(p.phone,e.telephone))||(e.email&&p.email&&String(p.email).toLowerCase()===String(e.email).toLowerCase())});
  var p=uniq(m);if(p){e.participant_id=p.participant_id;res.etudiants++;chE=true;if(!p.tfl_etudiant_id){p.tfl_etudiant_id=e.id;chP=true}}});
 if(chE)wr(K.etu,E);if(chP)wr(K.par,P);
 var chC=false;C.forEach(function(c){if(c.trainer_id||c.hr_id)return;var t=uniq(T.filter(function(x){return (c.telephone&&same(x.phone||x.telephone,c.telephone))||(c.email&&x.email&&String(x.email).toLowerCase()===String(c.email).toLowerCase())})),h=uniq(H.filter(function(x){return (c.telephone&&same(x.phone,c.telephone))||(c.email&&x.email&&String(x.email).toLowerCase()===String(c.email).toLowerCase())}));
  var mod=false;if(t){c.trainer_id=t.id||t.trainer_id;mod=true}if(h){c.hr_id=h.id;mod=true}if(mod){res.encadreurs++;chC=true}});if(chC)wr(K.enc,C);
 var n=res.etudiants+res.encadreurs;if(n)X.log('liaison_tfl',res,n+' fiche(s) TFL rattachée(s)');return res}
function anomaliesTfl(){var a=[],E=rd(K.etu),D=rd(K.dos),C=rd(K.enc),P=rd(K.par),eById=Object.fromEntries(E.map(function(e){return[e.id,e]})),cById=Object.fromEntries(C.map(function(c){return[c.id,c]}));
 D.forEach(function(x){if(!eById[x.etudiant_id])a.push('Dossier TFL '+(x.numero||x.id)+' : étudiant introuvable');if(x.encadreur_id&&!cById[x.encadreur_id])a.push('Dossier TFL '+(x.numero||x.id)+' : encadreur affecté introuvable');
  if(x.encadreur_id&&x.statut==='refuse')a.push('Dossier TFL '+(x.numero||x.id)+' : refusé mais encore affecté à un encadreur')});
 C.forEach(function(c){var n=D.filter(function(x){return x.encadreur_id===c.id&&x.statut==='accepte'}).length,mx=num(c.max_etudiants);if(mx>0&&n>mx)a.push('Encadreur '+(c.nom||c.id)+' : '+n+' dossiers acceptés pour un maximum de '+mx)});
 var seen={};E.forEach(function(e){if(!e.matricule)return;var m=String(e.matricule).trim();if(seen[m]&&seen[m]!==e.id)a.push('Matricule '+m+' porté par deux étudiants TFL');seen[m]=e.id;
  var p=P.filter(function(x){return x.matricule&&String(x.matricule).trim()===m})[0];if(p&&e.telephone&&p.phone&&!same(e.telephone,p.phone)&&!(e.email&&p.email&&String(e.email).toLowerCase()===String(p.email).toLowerCase()))a.push('Matricule '+m+' : étudiant TFL « '+(e.nom||e.id)+' » et participant « '+p.name+' » ont des coordonnées différentes')});
 D.forEach(function(x){if(x.statut!=='accepte')return;var e=eById[x.etudiant_id];if(!e||!e.participant_id)return;var s=situation(e.participant_id);if(s&&s.prix>0&&s.solde>0)a.push('Dossier TFL '+(x.numero||x.id)+' accepté : l’étudiant a encore '+fmt(s.solde)+' à payer pour sa formation')});
 return a}

/* ================= affichage ================= */
var LBL={total:'Soldé',moitie:'Moitié payée',partiel:'Partiel',non_paye:'Non payé'};
function html(){var T=totals();if(!T.length)return'';var rows=T.map(function(o){return'<tr><td>'+esc(o.formation)+'</td><td style="text-align:right">'+o.inscrits+'</td><td style="text-align:right">'+fmt(o.attendu)+'</td><td style="text-align:right">'+fmt(o.verse)+'</td><td style="text-align:right"><b>'+fmt(o.solde)+'</b></td></tr>'}).join('');
 return'<h4 style="margin:14px 0 6px">🎓 Formations : attendu / versé</h4><div style="overflow-x:auto"><table class="exb-table"><thead><tr><th>Formation</th><th>Inscrits</th><th>Attendu</th><th>Versé</th><th>Solde</th></tr></thead><tbody>'+rows+'</tbody></table></div><p class="exb-muted" style="font-size:12px">Montants de formation : devise non précisée dans les fiches (à confirmer).</p>'}
function link(){try{linkFormation()}catch(e){}try{linkTfl()}catch(e){}}
X.extend({link:link,anomalies:function(){return anomaliesFormation().concat(anomaliesTfl())},html:html});
X.edu={linkFormation:linkFormation,linkTfl:linkTfl,situation:situation,totals:totals,anomaliesFormation:anomaliesFormation,anomaliesTfl:anomaliesTfl,html:html,labels:LBL};

/* ---------- branchements sur les écrans existants ---------- */
function after(name,fn){var f=w[name];if(typeof f!=='function'||f.__lienedu)return;var g=function(){var r=f.apply(this,arguments);try{fn.apply(null,arguments)}catch(e){}return r};g.__lienedu=1;w[name]=g}
function hook(){['saveParticipant','savePayment','saveReceipt','saveFormation'].forEach(function(n){after(n,function(){X.refresh()})});
 var f=w.saveCert;if(typeof f==='function'&&!f.__lienedu){var g=function(){try{var pid=(d.getElementById('cert_participant_id')||{}).value,nm=(d.getElementById('holder')||{}).value,P=rd(K.par),p=P.filter(function(x){return x.participant_id===pid})[0]||uniq(P.filter(function(x){return norm(x.name)===norm(nm)}));
   if(p){var s=situation(p.participant_id);if(s&&s.prix>0&&s.solde>0&&typeof w.confirm==='function'&&!w.confirm('Attention : '+s.nom+' a encore '+fmt(s.solde)+' à payer pour cette formation. Délivrer le certificat quand même ?'))return}}catch(e){}
   var r=f.apply(this,arguments);try{X.refresh()}catch(e){}return r};g.__lienedu=1;w.saveCert=g}}
hook();setTimeout(hook,3000);link();try{X.refresh()}catch(e){}
}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(boot,2000)});else setTimeout(boot,2000);
})(typeof window!=='undefined'?window:globalThis,typeof document!=='undefined'?document:{readyState:'complete',getElementById:function(){return null},addEventListener:function(){}});
