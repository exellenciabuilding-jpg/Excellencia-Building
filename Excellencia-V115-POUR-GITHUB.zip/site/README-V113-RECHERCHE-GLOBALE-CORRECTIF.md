# V113b — Correctif recherche globale + planning formateur

## 1. Barre de recherche qui ne trouvait plus rien
Cause : `exb-recherche-globale.js` lisait `window.exbStorage`, qui n'existe pas (`const exbStorage` dans index.html).
Le module retombait sur le localStorage brut, dont les clés n'ont pas le préfixe du logiciel → liste toujours vide.
Correctif : lecture via `exbStorage` (nom global), puis `EXBS.get`, puis localStorage en dernier recours.

## 2. Planning du formateur
Avant : une séance n'était publiée au formateur que si le champ « Formateur » de la séance était rempli.
Maintenant : si ce champ est vide, la séance est rattachée au formateur de la formation (même intitulé de formation).
index.html › fmBuild.

## À faire
Ouvrir le logiciel (nouvelle version de cache), puis **📢 Publier l'espace formateur** pour que les formateurs voient planning et apprenants.
Pas de nouveau SQL.
