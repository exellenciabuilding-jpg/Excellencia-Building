# V109 — Espace apprenant : images, icônes et fonctionnement professionnel

**Images**
- Photos du projet (`assets/accueil/banniere-1..4.jpg`) : carte de bienvenue, bandeau en pied de tableau de bord, et un bandeau illustré en tête de chaque page (frais, planning, formation, résultats, TP/TD, certificats, carte, messages).
- Icônes dessinées en SVG (même rendu sur tous les téléphones) pour les tuiles de services, la barre du bas, le menu et les cartes de chiffres.
- Illustrations pour les pages vides (aucun message, aucune séance, aucun certificat…) et chargement en « squelette » à la place du texte.

**Fonctionnement**
- Bouton ↻ « Actualiser » en haut ; actualisation automatique au retour sur l'application après 5 minutes.
- Mode hors connexion : si « Garder ma connexion » est coché, les dernières données sont mémorisées sur l'appareil et s'affichent sans Internet (bandeau d'avertissement) ; elles sont effacées à la déconnexion.
- Notifications discrètes (toasts) à la place des fenêtres d'alerte ; bouton « Installer l'application » dans Paramètres.
- Heure de dernière mise à jour affichée sur le tableau de bord.

Fichiers modifiés : `espace-apprenant.html`, `sw.js`. Aucune nouvelle fonction SQL.
