# V99 — correctifs 3

## PDF et lisibilité (calcul de structure)
- Les plans d'exécution s'impriment sur une page A3 paysage (la règle de page était ignorée : plan minuscule sur A4 portrait).
- La fiche de validation (formulaire) n'est plus imprimée en première page ; la page de garde ouvre le PDF.
- Écritures agrandies : notes de calcul, plans d'exécution, cartouche.
- Windows : l'export PDF attend les images, enregistre dans Documents si la fenêtre « Enregistrer sous » échoue, et affiche un message d'erreur clair.
  Journal des erreurs : `exb-print.log` (dossier de données de l'application).

## Affiches
- Carte « Logo des affiches » : remplace le logo des deux affiches (taille et position réglables ; retour au logo d'origine possible).
- Onglet « Studio libre » : affiches pour tout autre contenu (6 formats, 5 modèles, textes, photos, logo, formes, fond, enregistrement, export PNG/PDF).
- Fichier : `exb-affiches-studio.js`. Pour le retirer : supprimer sa balise dans index.html.

## Téléphone (Android)
- Les boutons « PDF » et « Imprimer » des notes de calcul et plans d'exécution créent un vrai PDF sur téléphone : chaque feuille est assemblée
  (A4, plan en A3 paysage), enregistrée dans Documents/ExcellenciaBuilding/Fichiers, puis le menu Partager s'ouvre (ouvrir, WhatsApp, Drive…).
