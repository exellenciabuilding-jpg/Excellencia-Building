# V99 — Orthographe renforcée, doublons renforcés, nouvelles tâches de l'assistant

Nouveaux fichiers : `exb-orthographe.js`, `exb-assistant-plus.js`. Modifiés : `exb-doublons.js`, `exb-menu-contextuel.js`, `index.html` (2 balises, 1 appel dans l'assistant, 1 garde-fou dans l'import), `sw.js` (cache hors connexion). **Aucun SQL.**

## 1. Correction de fond (important)
`exb-doublons.js` lisait les données dans `localStorage` brut, alors que le logiciel les range dans `exbStorage` (préfixe `EXB_V28__`). Les règles de détection pouvaient donc ne rien voir sur vos vraies données. La lecture suit maintenant celle du logiciel (pont `EXBS`, puis `exbStorage`, puis `localStorage`).
Même défaut corrigé ailleurs : `exb-intelligence.js` (repli de `list()`) et `exb-home-pro.js` (`stor()`, qui alimente les compteurs de l'accueil : factures, conformité). Les réglages et l'historique de ces modules, qui s'écrivent et se lisent eux-mêmes dans `localStorage`, n'ont pas été touchés.

## 2. Orthographe
- Dictionnaire passé d'environ 140 à environ 560 corrections (BTP, formation, administration, finance) : accents oubliés, doubles lettres, fautes fréquentes (« terasement », « ferrailage », « paiment »…) et expressions (« rez-de-chaussée », « maître d'ouvrage », « carte d'identité »).
- Les mots qui existent aussi sans accent (marche/marché, tache/tâche, sur/sûr, paye/payé, cote/côté…) ne sont **jamais** corrigés.
- **Faute possible** : clic droit sur un mot proche d'un mot connu (1 lettre de différence) → « Faute possible : x → y ». Jamais appliqué automatiquement.
- **🔎 Signaler les fautes possibles** (clic droit dans un champ) : liste les fautes sans rien modifier.
- La correction automatique douce à la sortie des champs utilise le dictionnaire élargi (fautes sûres uniquement).
- Les noms propres (mot capitalisé au milieu d'une phrase) ne sont pas vérifiés.

## 3. Doublons
Nouveaux cas signalés (avertissement seulement) :
- prénom et nom inversés dans la même formation (« Kasongo Jean » / « Jean Kasongo ») ;
- même nom + même date de naissance ;
- nom presque identique (1 faute de frappe, noms d'au moins 8 caractères) dans la même formation, ou avec le même téléphone / e-mail ;
- formateurs : nom inversé aussi.
Nouveaux garde-fous :
- **Demandes reçues** (importation des inscriptions, formateurs, clients) : une seule fenêtre liste les demandes qui ressemblent à une fiche existante ou à une autre demande du même lot. *OK* = tout importer ; *Annuler* = importer seulement les autres (les demandes écartées restent en attente, rien n'est supprimé).
- **Nouveau formateur** et **nouveau client** : fenêtre d'avertissement avant l'enregistrement (modifier une fiche existante ne déclenche rien).

## 4. Assistant (texte ou voix, lecture seule, sans autorisation à régler)
- « y a-t-il des doublons ? » → synthèse (erreurs / alertes / infos) et ouverture de l'accueil.
- « vérifie l'orthographe de mes fiches » → fautes sûres dans les textes libres (notes, spécialités, adresses, projets…), sans rien modifier.
- « liste les inscrits à AutoCAD » / « répartition par formation » → noms et chiffres de cet appareil.
- « qui n'a pas payé ? » → reçus dont l'inscription ou la formation est « NON PAYÉ ».

## 5. Recherche tolérante et relances de paiement (assistant)
- **« cherche Kasonga »** : si aucun nom ne correspond exactement, l'assistant propose les noms proches (« Vous pensiez à : … ») en comparant fautes de frappe, lettres doublées et sons voisins (k/c/q, ou/u, ph/f, a/o finales…). Il propose d'ouvrir l'onglet, avec la validation habituelle (réglage « Ouvrir un écran »). Utile aussi quand la reconnaissance vocale se trompe sur un nom.
- **« relance les impayés »** : un message de rappel par reçu impayé (nom, formation, montants, téléphone retrouvé dans la fiche participant), prêt à copier. **« relance Jean Kasongo »** : un seul message. Rien n'est envoyé par l'assistant. Jusqu'à 15 messages sont affichés par réponse (un par reçu impayé) ; au-delà, un renvoi invite à dire « relance » suivi du nom.
- « rédige un message de rappel » (sans mot « impayés ») garde le modèle générique d'avant.

## Limites
- Testé avec des données simulées : règles de doublons, garde-fou d'import, dictionnaire et suggestions, 12 phrases de l'assistant, syntaxe des 16 scripts de `index.html`. **Non testé** dans le logiciel avec vos vraies données ni dans un navigateur réel (clic droit, fenêtres, import réel).
- Le contrôle automatique du projet (`node tools/check.js`) donne 500 réussites et 0 échec (5 assertions périmées sur l’ancien nom du cache TFL ont été mises à jour pour accepter le format actuel `v99-…`).
- Ce n'est pas un vrai correcteur : il ne connaît que ses listes. Le soulignement du navigateur reste le complément pour les autres mots.
- Non couverts : l'import en lot de fichiers (déjà limité à nom + téléphone identiques), les travaux (TFL, TP/TD), les demandes de type projet / personnel.
- « Qui n'a pas payé ? » se base uniquement sur l'état saisi sur les reçus : un participant sans reçu n'apparaît pas.
- Les montants ne sont pas additionnés (devise non connue) ; ils sont repris tels que saisis sur les reçus.
- Recherche tolérante : un nom très différent (ou de moins de 3 lettres) ne sera pas rapproché ; elle ne sert que quand aucun résultat exact n'existe.

Retour en arrière : supprimer les balises `exb-orthographe.js` et `exb-assistant-plus.js` dans `index.html`, restaurer `exb-doublons.js`, `exb-menu-contextuel.js` et le bloc « V99 doublons » de `importMany` (sans lui, l'import fonctionne comme avant).
