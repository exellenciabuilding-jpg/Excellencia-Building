# V99 — Éditeur de plan : Maillage (terrain)

Fichiers : nouveau `plan-editeur/terrain.js` ; modifiés `plan-editeur/index.html`, `plan-editeur/vue3d.js`, `sw.js` (cache hors connexion + version).

- **Outil Maillage** (palette de gauche) : réglez l'altitude du prochain point (m ; 0 = niveau du RDC), touchez le plan pour poser un point coté. Touchez un point existant pour changer son altitude ; double-touche sur un point pour le supprimer ; « Effacer le maillage » vide tout. Annuler / rétablir fonctionnent.
- **2D** : triangulation de Delaunay (3 points minimum), teinte par altitude, courbes de niveau (pas 0,25 / 0,5 / 1 m selon le relief, courbes maîtresses plus épaisses), altitudes affichées. Masquable : Fenêtres → Calques → « Terrain (maillage) ».
- **3D** : surface du terrain colorée selon l'altitude ; le sol plat est abaissé sous le point le plus bas. Avec un maillage, la rue, la clôture et les arbres décoratifs ne sont pas affichés (ils flotteraient sur le relief).
- **Volumes** (affichés dans la barre de l'outil) : surface, déblai (terrain au-dessus du niveau 0) et remblai (en dessous) par rapport au niveau 0 du RDC, calculés par échantillonnage de chaque triangle. Valeurs indicatives, hors foisonnement, hors fondations ; pas encore transmis au métré.

Limites : le terrain n'est pas découpé sous la maison (le RDC reste à la cote 0) ; pas de plateforme ni de talus automatiques ; absent des coupes, façades et exports DXF / glTF. Maillage reste « Élévation » et « Détail » grisés.
Testé dans Chromium sans écran : pose / modification / suppression de points, 2D, 3D, aucune erreur de console. Non testé sur appareil réel.
