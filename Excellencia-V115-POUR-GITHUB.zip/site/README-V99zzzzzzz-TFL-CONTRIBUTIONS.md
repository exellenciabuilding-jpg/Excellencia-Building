# V99zzzzzzz — TFL : contributions d'anciens (sujet + travail déjà résolu → bibliothèque)

## Principe
Vous envoyez un lien à des amis / anciens qui ont déjà terminé leur TFL. Ils y déposent leur **sujet** et leur **travail** ; vous les gardez dans la bibliothèque pour les années à venir et, si l'auteur l'autorise, comme **guide** pour d'autres apprenants.

## Dans le logiciel : 🎓 TFL › 📚 Bibliothèque › 🤝 Contributions (nouvel onglet)
1. **Inviter** : « 🔗 Copier le lien » ou « 💬 Envoyer par WhatsApp » (nom / téléphone facultatifs, pré-remplis dans le formulaire). Lien : `https://votre-site/tfl-contribution.html` (alias : `/deposer-tfl`).
2. **Recevoir** : « 📡 Récupérer les contributions » (connexion administrateur requise, comme pour les candidatures TFL).
3. **Garder** : « 📚 Garder dans la bibliothèque » crée la fiche dans **🎓 TFL résolus** avec le fichier, puis marque la contribution « traitée » et **retire le fichier du serveur** (quota Supabase 500 Mo).
4. Dans « TFL résolus » : mention « consultation autorisée » reprise du choix de l'auteur, ouvrir / télécharger / envoyer à d'autres apprenants.

## Page publique `tfl-contribution.html`
Nom, téléphone, e-mail, université, année, domaine, encadreur, titre, mots-clés, résumé, fichier (PDF, Word, ODT, RTF, TXT, PowerPoint, ZIP, JPG, PNG — **3 Mo max.**), case « J'autorise le partage aux autres apprenants ». Avertissement : ne déposer que son propre travail, comme référence méthodologique.

## À faire UNE FOIS
1. Supabase › SQL Editor : exécuter `supabase/migration-v99zzzzzz-tfl-contributions.sql` (6 Ko, réexécutable — **à ré-exécuter même si vous aviez déjà lancé la version précédente** : elle contient les corrections ci-dessous). Contrôle : 4 fonctions `tfl_contribution*`.
2. Déployer le ZIP sur Netlify (cache `exb-v99zzz-tfl-sans-limite-contributions-2`) ; ouvrir le logiciel deux fois.
Tant que le SQL n'est pas exécuté, la page affiche « service pas encore activé » (rien n'est perdu) et le logiciel explique quoi faire.

## Sécurité
Table sans politique (personne ne la lit directement) ; envoi public limité (100 / heure au total, 3 / heure par téléphone) ; champs filtrés ; extension et taille du fichier contrôlées côté serveur ; liste, téléchargement du fichier et « traitée » réservés aux e-mails administrateur. **La liste ne contient jamais les fichiers** (téléchargés un par un à la demande) : elle reste légère, même sur connexion lente.

## Corrections apportées (révision)
1. **Renvoi sans doublon** : la page fixait l'instant d'envoi à chaque clic, donc un renvoi après une coupure (fiche déjà enregistrée, réponse perdue) créait une 2e contribution. L'instant est maintenant fixé une fois par formulaire.
2. **Renvoi jamais refusé à tort** : côté SQL, la reconnaissance d'un renvoi se fait désormais **avant** les limites horaires (avant, le 4e essai d'un même numéro pouvait être refusé alors que la fiche était déjà reçue).
3. **Liste complète** : `tfl_contributions_liste()` ne renvoie plus que les contributions **non traitées** (avant : les 300 plus récentes, traitées comprises ; au-delà de 300 contributions, les plus anciennes à traiter n'apparaissaient plus).
4. **Cache PWA** relevé pour que la page corrigée soit retéléchargée.
5. **Contrôles** : `tools/check.js` couvre maintenant les contributions (+6, soit 418 réussis) ; le README citait ce script sans qu'il vérifie quoi que ce soit sur ce module.

## Limites
- **Le SQL n'a pas été exécuté sur un vrai Supabase** : testez avec une contribution d'essai. Le reste est testé dans un navigateur avec un serveur simulé.
- Fichier > 3 Mo : l'ancien envoie seulement la fiche puis le document par WhatsApp ; vous le joignez avec « 📎 Joindre un fichier » dans la bibliothèque.
- Le fichier gardé est stocké sur **cet appareil** (IndexedDB), pas dans la sauvegarde JSON : conservez vos originaux (voir README-V99zzu).
- Le partage « aux autres apprenants » se fait par téléchargement / envoi manuel depuis la bibliothèque ; pas encore d'espace de consultation pour les apprenants.

## Contrôles
`python3 tools/test-tfl/e2e-contributions.py` (16 contrôles) · `node tools/test-tfl/test.js` · `node tools/check.js` (418 contrôles).
