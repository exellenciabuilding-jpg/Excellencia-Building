# V99 — Reçu court + certificat remis en page

- **Reçu d'inscription** : le PDF a de nouveau la taille du reçu (105 mm de large, page courte), plus une page A4 avec le reçu minuscule au centre.
- **Certificat** : police du texte réduite (20 px au lieu de 23 px), date, titres et noms plus petits.
- **Bloc visa** : signature + cachet de l'administrateur posés AU-DESSUS de la ligne du Directeur ; le nom et « LE DIRECTEUR » restent lisibles dessous ; le bloc est ancré en bas et ne chevauche plus la date, le QR ni son texte.
- Fichier modifié : index.html (CSS .cert + elementToPdf), sw.js (version du cache).

## Éditeur de plan (V4 intégrée)
Le dossier `plan-editeur/` (index.html, catalogue.js, symboles.js, vue3d.js) et son README viennent de la version PLAN-EDITEUR-V4 : étages, dalle, toiture, murs courbes avec portes/fenêtres, poteaux, escalier droit, fond de plan à l'échelle, câbles. Le reste de l'application est resté tel quel (reçu court, certificat remis en page, visa, espace client…).

## Icône de l'application avec le nom
Icônes `icon-192/512/maskable-512.png` (site) et `resources/android-res/mipmap-*` (Android : ic_launcher, round, foreground) refaites à partir du logo complet : dessin + « Excellencia Building » dessous (l'accroche, illisible en petit, est retirée). Fond blanc ; version « maskable » avec marge de sécurité.
