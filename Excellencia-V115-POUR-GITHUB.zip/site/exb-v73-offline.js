/* Excellencia Building V76 — Chantier hors ligne (refonte du module V73)
 * Saisie terrain => enregistrée tout de suite dans les vrais modules (journal, HSE/QHSE, RFI, réserves, pointage) via EXBS.
 * La synchronisation serveur est assurée par exb-db.js dès que le réseau revient. Fusion par fiche, détection de doublons/conflits. */
(function(w,d){'use strict';
var QK='exb_v73_offline_queue';
function lq(){try{var a=JSON.parse(localStorage.getItem(QK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function sq(a){try{localStorage.setItem(QK,JSON.stringify(a.slice(-300)));return true}catch(e){return false}}
function uid(p){return p+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7)}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function net(){return navigator.onLine!==false}
function today(){return new Date().toISOString().slice(0,10)}
function activeP(){try{return localStorage.getItem('exb_active_project')||''}catch(e){return''}}
function hr(){var a=w.EXBS.get('exb_hr');if(a.length){try{localStorage.setItem('exb_v73_hr',JSON.stringify(a.map(function(h){return {id:h.id,name:h.name}})))}catch(e){}return a}try{var c=JSON.parse(localStorage.getItem('exb_v73_hr')||'[]');return Array.isArray(c)?c:[]}catch(e){return[]}}
function canW(col){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(col,'ecrire')}catch(e){return true}}
/* type -> collection locale + serveur, champs du formulaire, fabrication de la fiche, règle anti-doublon */
var T={
 journal:{l:'📝 Journal',key:'exb_site_journal',col:'journal',f:[{k:'work',l:'Travaux réalisés',ta:1,r:1},{k:'crew',l:'Effectif',n:1},{k:'incident',l:'Incident (facultatif)'},{k:'photos',l:'Photos (3 max)',ph:1}],
  mk:function(v,p){return {id:uid('JR'),project_id:p,project:p,date:today(),weather:'—',crew:+v.crew||0,work:v.work,incident:v.incident||'',notes:'(saisi hors ligne)',photos:v.photos||[]}}},
 hse:{l:'🦺 HSE',key:'exb_qhse',col:'qhse',f:[{k:'name',l:'Observation sécurité',ta:1,r:1},{k:'status',l:'Statut',t:['Ouverte','Action','Vérification','Clôturée'],def:'Ouverte'},{k:'photos',l:'Photos (3 max)',ph:1}],
  mk:function(v,p){return {id:uid('QHSE'),createdAt:new Date().toISOString(),project:p,project_id:p,title:v.name,name:v.name,status:v.status,type:'Sécurité',note:'(saisi hors ligne)',photos:v.photos||[]}}},
 rfi:{l:'❓ RFI',key:'exb_rfis',col:'rfis',f:[{k:'question',l:'Question / demande d\u2019information',ta:1,r:1},{k:'priority',l:'Priorité',t:['Normale','Haute','Urgente'],def:'Normale'},{k:'photos',l:'Photos (3 max)',ph:1}],
  mk:function(v,p){return {id:uid('RFIS'),createdAt:new Date().toISOString(),project:p,project_id:p,question:v.question,priority:v.priority,status:'Ouverte',photos:v.photos||[]}}},
 reserve:{l:'📌 Réserve',key:'exb_reserves',col:'reserves',f:[{k:'name',l:'Réserve constatée',ta:1,r:1},{k:'status',l:'Statut',t:['Ouverte','En correction','À vérifier','Clôturée'],def:'Ouverte'},{k:'photos',l:'Photos (3 max)',ph:1}],
  mk:function(v,p){return {id:uid('RESERVES'),createdAt:new Date().toISOString(),project:p,project_id:p,title:v.name,name:v.name,status:v.status,photos:v.photos||[]}}},
 pointage:{l:'👷 Pointage',key:'exb_timesheets',col:'pointages',f:[{k:'worker',l:'Ouvrier',w:1,r:1},{k:'days',l:'Jours travaillés',t:['1','0.5'],def:'1'},{k:'rate',l:'Taux journalier',n:1,r:1}],
  mk:function(v,p){var h=hr().find(function(x){return x.id===v.worker});var cost=+(+v.rate*+v.days).toFixed(2);return {id:uid('TS'),worker_id:v.worker,worker_name:h?h.name:'',project_id:p,date:today(),days:+v.days,rate:+v.rate,cost:cost,cash_id:''}},
  dup:function(list,r){return list.some(function(t){return t.worker_id===r.worker_id&&t.date===r.date&&t.project_id===r.project_id})}}
};
function enqueue(type,record){var t=T[type];if(!t)return null;var o={id:uid('OFF'),type:type,key:t.key,col:t.col,record:record,created_at:new Date().toISOString(),status:'pending',attempts:0};var q=lq();q.push(o);sq(q);flush();var r=lq().find(function(x){return x.id===o.id});return r||o}
/* Applique chaque opération en attente : fusion par identifiant (jamais d'écrasement de la liste) */
function flush(){var q=lq(),n=0;q.forEach(function(x){if(x.status!=='pending')return;x.attempts=(x.attempts||0)+1;var t=T[x.type];
  if(!canW(x.col)){x.status='conflict';x.error='Droits insuffisants pour cette section.';return}
  try{var list=w.EXBS.get(x.key),i=list.findIndex(function(r){return r.id===x.record.id});
   if(i>=0){x.status='conflict';x.error='Cette fiche existe déjà.';return}
   if(t&&t.dup&&t.dup(list,x.record)){x.status='conflict';x.error='Doublon : déjà enregistré pour ce jour et ce chantier.';return}
   list.push(x.record);if(w.EXBS.set(x.key,list)){x.status='synced';x.synced_at=new Date().toISOString();x.record={id:x.record.id};n++}else{x.error='Stockage plein.'}
  }catch(e){x.error=String(e&&e.message||e)}});
 sq(q);try{stats()}catch(e){}return n}
function pending(){return lq().filter(function(x){return x.status==='pending'}).length}
/* compat V73 : enregistre une fiche dans une collection connue */
function writeLocal(key,record){var type=Object.keys(T).find(function(k){return T[k].key===key});return type?enqueue(type,record):null}
function ui(){var badm=d.getElementById('badm');if(!badm||d.getElementById('exbV73Btn'))return;var b=d.createElement('button');b.id='exbV73Btn';b.className='muted';b.textContent='📱 Chantier hors ligne';b.onclick=panel;badm.parentNode.appendChild(b)}
function stats(){var e=d.getElementById('exbV73Stats');if(!e)return;var a=lq(),p=a.filter(function(z){return z.status==='pending'}).length,s=a.filter(function(z){return z.status==='synced'}).length,c=a.filter(function(z){return z.status==='conflict'});
 e.innerHTML='<b>'+p+'</b> en attente · <b>'+s+'</b> enregistrées · <b>'+c.length+'</b> à vérifier'+(c.length?'<div style="margin-top:6px;font-size:12px;color:#b00020">'+c.slice(-5).map(function(x){return esc(T[x.type].l)+' : '+esc(x.error||'')+' <a href="#" data-ign="'+esc(x.id)+'">ignorer</a>'}).join('<br>')+'</div>':'');
 var st=d.getElementById('exbV73Net');if(st)st.textContent=net()?'🟢 En ligne':'🔴 Hors ligne — la saisie reste sur l\u2019appareil'}
function panel(){var old=d.getElementById('exbV73Panel');if(old){old.remove();return}var x=d.createElement('div');x.id='exbV73Panel';x.style.cssText='position:fixed;right:16px;bottom:16px;z-index:99999;max-width:520px;width:calc(100% - 32px);max-height:85vh;overflow:auto;background:#fff;color:#111;border:1px solid #ddd;border-radius:14px;box-shadow:0 12px 40px #0002;padding:16px';
 x.innerHTML='<b>📱 Chantier hors ligne</b> <button class="muted smallbtn" id="exbV73X" style="float:right">✕</button><div id="exbV73Net" style="font-size:12px;margin:4px 0"></div><hr><div id="exbV73Stats"></div><div id="exbV73Btns" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px"></div><div id="exbV73Out" style="margin-top:10px"></div>';d.body.appendChild(x);
 d.getElementById('exbV73X').onclick=function(){x.remove()};
 x.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-ign]');if(!a)return;e.preventDefault();sq(lq().filter(function(o){return o.id!==a.getAttribute('data-ign')}));stats()});
 var bt=d.getElementById('exbV73Btns');Object.keys(T).forEach(function(k){var b=d.createElement('button');b.className='muted smallbtn';b.textContent=T[k].l;b.onclick=function(){form(k)};bt.appendChild(b)});stats()}
function inp(f){var id='v73f_'+f.k,s='width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:8px;margin-top:3px';
 if(f.ph)return '<input id="'+id+'" type="file" accept="image/*" multiple style="'+s+'">';
 if(f.w){var hr=hr();return '<select id="'+id+'" style="'+s+'"><option value="">— choisir —</option>'+hr.map(function(h){return '<option value="'+esc(h.id)+'">'+esc(h.name)+'</option>'}).join('')+'</select>'}
 if(f.t)return '<select id="'+id+'" style="'+s+'">'+f.t.map(function(o){return '<option'+(o===f.def?' selected':'')+'>'+esc(o)+'</option>'}).join('')+'</select>';
 if(f.ta)return '<textarea id="'+id+'" rows="3" style="'+s+'"></textarea>';
 return '<input id="'+id+'" type="'+(f.n?'number':'text')+'" '+(f.n?'min="0" step="any" inputmode="decimal"':'')+' style="'+s+'">'}
function form(type){var t=T[type],out=d.getElementById('exbV73Out'),ps=w.EXBS.projects(),ap=activeP();
 out.innerHTML='<b>'+t.l+'</b><label style="display:block;margin-top:6px;font-size:13px">Projet *<select id="v73p" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:8px;margin-top:3px"><option value="">— choisir —</option>'+ps.map(function(p){return '<option value="'+esc(p.id)+'"'+(String(p.id)===ap?' selected':'')+'>'+esc(p.nom||p.name||p.titre||p.title||p.id)+'</option>'}).join('')+'</select></label>'+(type==='pointage'&&!hr().length?'<div style="color:#b00020;font-size:13px;margin-top:6px">Aucun personnel enregistré sur cet appareil : ouvrez l\u2019application une fois en ligne (onglet Personnel) pour le charger.</div>':'')+t.f.map(function(f){return '<label style="display:block;margin-top:6px;font-size:13px">'+esc(f.l)+(f.r?' *':'')+inp(f)+'</label>'}).join('')+'<div id="v73e" style="color:#b00020;font-size:13px;min-height:16px;margin-top:4px"></div><button class="primary smallbtn" id="v73add">Enregistrer</button>';
 d.getElementById('v73add').onclick=function(){var p=d.getElementById('v73p').value,v={},err='';if(!p)err='Choisissez un projet.';t.f.forEach(function(f){if(f.ph)return;var val=(d.getElementById('v73f_'+f.k).value||'').trim();if(f.r&&!val&&!err)err='Champ obligatoire : '+f.l;v[f.k]=val});
  if(!err&&type==='pointage'&&!(+v.rate>0))err='Indiquez un taux journalier positif.';
  if(err){d.getElementById('v73e').textContent=err;return}
  var pf=d.getElementById('v73f_photos'),files=pf&&pf.files?Array.prototype.slice.call(pf.files,0,3):[],btn=d.getElementById('v73add');btn.disabled=true;
  Promise.all(files.map(function(f){return (w.EXBPdf&&w.EXBPdf.fileJpg)?w.EXBPdf.fileJpg(f,800,.6):Promise.resolve('')})).then(function(ph){
   v.photos=ph.filter(Boolean);var o=enqueue(type,t.mk(v,p));stats();out.innerHTML=o&&o.status==='synced'?'✓ Enregistré dans le module correspondant'+(v.photos.length?' avec '+v.photos.length+' photo(s)':'')+'. Synchronisation automatique au retour du réseau.':'⚠ Non enregistré : '+esc(o&&o.error||'voir « à vérifier » ci-dessus')+'.'
  }).catch(function(){btn.disabled=false;d.getElementById('v73e').textContent='Photo illisible.'})}}
w.exbV73={enqueue:enqueue,flush:flush,pending:pending,writeLocal:writeLocal,queue:lq};
w.addEventListener('online',function(){flush();stats()});w.addEventListener('offline',stats);
d.addEventListener('DOMContentLoaded',function(){setTimeout(ui,900);setTimeout(hr,2500);setInterval(function(){flush()},30000)});
})(window,document);
