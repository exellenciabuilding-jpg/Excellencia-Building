# V99z — Calcul de structure : section réglable par file de poutres

Fichiers modifiés : `calcul-structure/index.html` (module Bâtiment), `sw.js` (cache `exb-v99z-poutres-1`), libellé de version du cadre.
Sans réglage, rien ne change : les sections restent celles du niveau (V99y) puis celles du bâtiment.

## Ce qui s'ajoute
- Onglet « Axes & modélisation » : touchez une poutre → fiche avec **b et h de la file** (cm ; champ vide = section du niveau). La section s'applique à toute la file de l'axe, à ce niveau (une poutre continue a une seule section). Boutons « Même section à tous les niveaux » et « Section du niveau ».
- Pris en compte partout : poids propre sur les poteaux, dimensionnement de chaque file, vue 3D (largeur et hauteur de chaque poutre), plans d'exécution, coffrage, plans de dalles, élévation, quantités de béton et de coffrage, tableaux, note de calcul (section de chaque poutre ; liste des files dont la section diffère du niveau).
- Insérer ou supprimer un axe décale correctement ces sections.
- « Copier ce niveau vers tous » copie aussi les sections de files.

## Limites
- Une section par file et par niveau (pas de section différente entre deux travées d'une même poutre continue).
- Poteaux carrés ; dalle d'épaisseur commune par niveau. Calculs indicatifs, à faire vérifier par un ingénieur.
- Retour en arrière : restaurer l'ancien `calcul-structure/index.html`.
