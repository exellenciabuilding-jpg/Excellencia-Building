# V99 — Assistant IA : autorisations réglables, partout, réponses étendues

Fichiers modifiés : `index.html` (assistant, section Paramètres), `sw.js` (nouvelle version du cache). Aucun SQL. Aucun nouveau fichier à déployer.

## 1. Paramètres › « 🤖 Assistant IA — autorisations »
- Interrupteurs : assistant activé ; bouton 🤖 visible sur tous les écrans ; IA en ligne utilisée quand elle est disponible (sinon assistant local).
- Un niveau par action, au choix : **🔒 Interdit** (il explique seulement), **✋ Demander** (il prépare, vous touchez « Appliquer ») ou **✅ Automatique** (il exécute seul et note l'action).
- Actions réglables : ouvrir un écran, ouvrir les demandes reçues, pré-remplir une fiche (sans l'enregistrer), importer les nouvelles demandes en ligne.
- **Verrouillé** : « préparer un lien de licence » ne peut jamais passer en automatique (Demander ou Interdit seulement). Une action inconnue est toujours refusée. Les actions proposées par l'IA en ligne passent par les mêmes règles.
- Par défaut tout est sur « Demander » : le comportement d'avant ne change pas tant que vous ne réglez rien.
- Journal des 200 dernières actions (date, mode : validé / automatique / refusé / annulé, action). Boutons « Vider le journal » et « Réglages par défaut ».
- Bouton « ↩ Annuler » après une action automatique d'ouverture d'écran ou de pré-remplissage. L'import de demandes ne s'annule pas : laissez-le sur « Demander » si vous voulez le contrôler.

## 2. Partout
- Le bouton 🤖 passe au-dessus des fenêtres superposées (Paie & RH, Finance, Enterprise 360°, modules…). Il est masqué sur l'écran de connexion.
- Les formulaires publics (apprenant, TFL, client…) n'ont volontairement pas d'assistant : il agit sur le logiciel de l'administrateur.

## 3. Réponses étendues
- Base locale élargie : TFL (sujets, encadreurs, attestation, QCM, contributions, historique), vérification par QR, devis/facture/reçu, Budget & pilotage, Pilotage projets (CPI/SPI), calcul de structure, métré béton armé, paiements Mobile Money, sauvegardes, thèmes, guide vocal, sécurité.
- Si aucune règle ne correspond, l'assistant cherche dans cette base avant de dire qu'il n'a pas compris.
- L'IA en ligne reçoit en plus la liste des actions autorisées : elle ne propose pas ce qui est interdit.

## 4. Synchronisation entre appareils
- Les réglages (clé `exb_ai_perm`) sont enregistrés comme le reste des données de l'application : quand l'appareil est connecté à la Base partagée (☁️ Synchronisation) avec le même compte, ils sont envoyés au serveur et récupérés sur les autres appareils, au rythme habituel de la synchronisation (quelques secondes après une modification). Il n'y a rien à installer ni à configurer.
- Un appareil jamais connecté garde ses réglages locaux. En cas de modification sur deux appareils en même temps, le mécanisme habituel s'applique : la version du collègue est gardée, la vôtre va dans « Conflits ».
- Le **journal** reste volontairement propre à chaque appareil (exclu de la synchronisation) et ne contient plus ni noms ni numéros : seulement la date, le mode et le type d'action (ex. « Pré-remplir le formulaire Formateur »).

## Limites
- Testé : syntaxe des 16 scripts de index.html et logique des autorisations (niveaux, verrouillage, journal, réglages corrompus) en bac à sable. **Non testé** dans un navigateur sur vos vraies données ni avec la fonction Supabase « assistant ».
- Non vérifié sur votre vrai Supabase : la synchronisation des réglages (voir ci-dessous) n'a été contrôlée que dans le code, pas avec un serveur réel.
- Les réponses locales étendues sont des explications rédigées d'avance : elles ne remplacent pas l'IA en ligne pour les questions libres.

Retour en arrière : restaurer `index.html` et `sw.js` de la version précédente.
