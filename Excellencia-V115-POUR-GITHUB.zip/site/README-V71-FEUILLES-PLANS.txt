EXCELLENCIA BUILDING V71 — FEUILLES & DOSSIERS DE PLANS

Ajouts:
- feuilles de plans : référence, titre, projet, discipline, type, niveau, échelle, indice, format, visa, calcul, date et statut CDE;
- dossiers/jeux de plans;
- filtre dédié aux plans de structure;
- préparation du workflow de publication et de révision;
- droits Supabase.

Migration : supabase/migration-v75-droits-v69-v74.sql (V75)
