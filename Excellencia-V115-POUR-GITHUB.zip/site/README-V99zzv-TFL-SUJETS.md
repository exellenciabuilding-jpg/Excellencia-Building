# V99zzv — TFL : catalogue des sujets, page publique, « Choisir ce sujet »

Nouveau : onglet **🎓 TFL › 📋 Sujets** (vous), page publique **`tfl-sujets.html`** (étudiants, sans compte), et deux ajouts à la **📚 Bibliothèque**.

## Ce que fait chaque partie
| | Qui | Quoi |
|---|---|---|
| 📋 Sujets | vous | fiches : référence **EXB-TFL-BTP-0001** (automatique), intitulé, catégorie, domaine, filière, niveau, problématique, objectifs, méthodologie, livrables, compétences, encadrement, mots-clés, **disponibilité** (Disponible · Réservé · Attribué · Fermé), **exclusif oui/non**, publié oui/non |
| Page publique | étudiant | liste + recherche (sans accents) + filtres catégorie / filière / disponibilité ; « Voir la fiche » ; « Choisir ce sujet » (nom, téléphone, université…) |
| Choisir ce sujet | étudiant → vous | la demande arrive comme **candidature** (récupération habituelle « 📡 Récupérer les candidatures en ligne ») : dossier **TFL-AAAA-0001** déjà rempli avec la fiche du sujet, lié à sa référence |
| Sujet exclusif | — | dès le premier choix il passe **Réservé** ; un 2ᵉ étudiant reçoit « déjà réservé » tant que vous n’avez pas décidé |
| Décision | vous | dossier **accepté** → sujet **Attribué** ; dossier **refusé** → sujet de nouveau **Disponible** ; ou boutons ↩ Libérer · ✔ Attribuer · ⛔ Fermer |
| Bibliothèque | vous | champ **Consultation autorisée (oui/non)** sur chaque TFL résolu (par défaut **non**), bouton pour basculer, colonne dans le CSV, bandeau **« Référence méthodologique, pas un travail à recopier. »** |

## À faire UNE FOIS (mode Internet)
1. Supabase › SQL Editor : exécuter **`supabase/migration-v99zzv-tfl-sujets.sql`** (réexécutable). Idéalement après `migration-v99zzr-tfl-en-ligne.sql` (sinon la table des candidatures est créée ici).
2. Déployer le ZIP (Netlify), recharger une fois.
3. Vérifier : `select proname from pg_proc where proname in ('tfl_sujets_publier','tfl_sujet_retirer','tfl_sujets_etat','tfl_sujets_publics','tfl_sujet_choisir');` → 5 lignes.
4. Dans 📋 Sujets : créer les fiches, « 🌐 Publier », puis **« 🔄 Synchroniser avec le serveur »** (connecté en administrateur). Lien public : « 🔗 Copier le lien » (ou `/tfl-sujets`, `/sujets-tfl`).

Après chaque changement de fiche ou de disponibilité, touchez de nouveau « Synchroniser » : le catalogue de l’appareil est la référence, le serveur est la copie publique. La synchronisation reprend aussi les **réservations** faites par les étudiants (« Réservé » apparaît avant même la récupération des candidatures).

## Sans serveur
« ⬇ Fichier sans serveur » produit `tfl-sujets.json` : déposez-le à côté de `tfl-sujets.html` sur le site. La page l’utilise si le serveur n’est pas configuré ou injoignable. Le bouton devient alors « Choisir ce sujet (fichier à envoyer) » : l’étudiant obtient un `.json` de candidature (WhatsApp / e-mail) que vous importez comme d’habitude. **Limite : sans serveur, rien n’est réservé tant que le fichier n’est pas reçu** ; deux fichiers pour un même sujet exclusif donnent un 2ᵉ dossier marqué « ⚠ déjà réservé » (à trancher).

## Sécurité (ce que fait le script)
- Table `tfl_sujets` sans politique : aucun accès direct. Publier / retirer / état : administrateurs seulement (mêmes e-mails que V99zzr).
- Lecture publique : fiche + disponibilité, **aucun téléphone ni nom**.
- « Choisir » : ligne verrouillée (`for update`) → deux étudiants simultanés ne peuvent pas réserver le même sujet exclusif ; la fiche du sujet est copiée **côté serveur** ; limite 200 demandes/h au total, 5/h par numéro.

## Limites
- **Le SQL n’a pas été exécuté sur un vrai PostgreSQL/Supabase** (indisponible ici) : relisez-le et testez avec un sujet d’essai (publier → choisir depuis un autre navigateur → synchroniser).
- Les **catégories** (Structures, Voirie, Hydraulique, Géotechnique, Architecture, Gestion de projet, Matériaux, BIM, Autre) sont ma proposition : je n’avais pas le schéma sous les yeux. Elles sont dans `CATS` (exb-tfl.js) et `CATS` (tfl-sujets.html) ; dites-moi les vôtres.
- « Consultation autorisée » est pour l’instant une **marque dans votre bibliothèque** : elle ne commande pas encore d’accès étudiant (il n’y a pas d’espace étudiant pour la bibliothèque).
- Un étudiant qui choisit deux fois le même sujet exclusif après import de sa première demande crée un second dossier (cas rare).
- **Pas fait : dépôt des chapitres et corrections par chapitre** (stockage de fichiers serveur = bucket Supabase + autre migration).
- Testé dans Chromium (390 px) avec serveur simulé ; non testé sur un vrai téléphone ni dans l’application complète.

## Fichiers
Nouveaux : `tfl-sujets.html`, `tfl-sujets.json` (vide), `supabase/migration-v99zzv-tfl-sujets.sql`, `tools/test-tfl/e2e-sujets.py`, `tools/test-tfl/e2e-sujets-admin.py`. Modifiés : `exb-tfl.js`, `sw.js` (cache `exb-v99zzv-tfl-sujets`), `_redirects`, `tools/check.js` (+9), `tools/test-tfl/test.js` (+29).

## Contrôles
`node tools/test-tfl/test.js` · `python3 tools/test-tfl/e2e-sujets.py` · `python3 tools/test-tfl/e2e-sujets-admin.py` · `node tools/check.js` (381 contrôles).
Retour en arrière : restaurer `exb-tfl.js`, `sw.js`, `_redirects`, `tools/check.js`, `tools/test-tfl/test.js` de V99zzu. Les fiches saisies restent dans `exb_tfl_sujets`.
