# V99 — LIAISON : première tranche de l'interconnexion des modules

Fichier ajouté : `exb-liaison.js` (+ `tools/test-liaison.js`, `tools/e2e-liaison.py`). Modifiés : `index.html` (1 balise script), `sw.js` (cache), `tools/check.js`. **Aucun SQL à exécuter. Aucune fonction existante supprimée ou réécrite.**

## Ce qui est connecté (chaîne complète testée)
Client → chantier/projet → devis → étude technique → facture → paiement.
- Les fiches existantes reçoivent des identifiants (`client_id`, `project_id`) retrouvés par le nom (sans tenir compte des majuscules/accents ; raison sociale et contact acceptés). Rien n'est renommé ni effacé. Un nom porté par plusieurs clients n'est **jamais deviné** : il est signalé dans « points à vérifier ».
- Le nom d'origine est conservé dans `client_snapshot` (devis, factures).
- **Registre financier central** = vue calculée (aucune copie, donc aucun doublon) à partir des paiements de factures, de la caisse et des paiements V93 **confirmés**. Distingue : devis / facturé / versé / solde à payer / reste à facturer, par devise (USD et CDF jamais mélangés). Un devis ne crée jamais de versement.
- Paiement saisi dans Finances/Chantiers (écran existant) ou ailleurs : le même paiement vu par la facture et la caisse n'est compté qu'une fois (identifiant `pay_id`).
- Nouvelle entrée unique `EXBLIEN.recordPayment({...})` : refuse montant ≤ 0, paiement sans client ni chantier, dépassement du solde de facture, utilisateur sans droit « paiements » ; clé `idem` pour qu'un rejeu ne crée pas de doublon.
- Modification de la fiche client : le nouveau nom est répercuté sur chantiers, études et devis **brouillons**. Les devis émis/approuvés et les factures gardent leur version d'origine (reliés par identifiant).
- Écrans : panneau « 🔗 Dossier client connecté » (page Clients) et « 🔗 Situation financière consolidée » (Direction), avec la liste des anomalies.
- Fiche client en double (même téléphone ou e-mail) : confirmation demandée avant de créer une deuxième fiche.
- Hors connexion / multi-appareils : les liens sont déterministes (deux appareils calculent les mêmes) et écrits par `save()`, donc envoyés par la synchronisation existante.

## Tests
- `node tools/check.js` : 460 contrôles réussis, 0 échec (456 d'origine + 4).
- `node tools/test-liaison.js` : 31 contrôles (rattachement, registre, paiement, modification, hors connexion).
- `python3 tools/e2e-liaison.py` : parcours réel dans Chromium (saveExbClient, saveExbProject, saveExbQuote, saveExbStudy, paiement, panneaux, modification du client) : tout OK. `e2e-smoke.py` et `e2e-liens.py` toujours OK.
- Le test navigateur a révélé et fait corriger deux défauts de ma première version (stockage préfixé `exbStorage`, listes gardées en mémoire par les écrans).

## NON fait dans cette tranche (à ne pas considérer comme livré)
Participants/formations (leurs paiements ne sont que des statuts, sans montant ni client/chantier), formateurs/personnel ↔ chantiers et planning, présences, TP/TD/examens/certificats, TFL, métrés (le client reste un nom saisi), plans/BIM/calcul de structure, stock et tâches terrain, chantiers V93 (`exb_v93_sites`, distincts des projets), reçus/comptabilité, notifications. Il n'y a pas encore d'écran pour résoudre un nom ambigu ni de bouton « Nouveau paiement » appuyé sur `recordPayment` (les écrans de paiement existants continuent à servir et alimentent le registre).

## Limites
- **Non testé sur un vrai Supabase ni sur plusieurs vrais appareils** (simulation seulement).
- Les paiements de facture sont considérés validés à la saisie ; seuls les paiements V93 « confirmés » comptent.
- Le journal `exb_liaison_journal` est local à l'appareil (non synchronisé) ; la piste d'audit centrale (`EXB_CORE.audit`) reçoit aussi les opérations.
- Les devis n'ayant pas de champ de statut officiel, « émis » = marqué émis/approuvé/validé/envoyé/signé ; à confirmer.
