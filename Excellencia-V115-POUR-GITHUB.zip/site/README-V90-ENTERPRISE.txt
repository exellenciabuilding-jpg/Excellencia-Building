EXCELLENCIA BUILDING V90 — ENTERPRISE CONSOLIDATION

OBJECTIF
V90 consolide V81 vers un socle entreprise sans supprimer les modules historiques.

NOUVEAUTÉS
- Enterprise 360° dans le menu PÔLES ENTREPRISE.
- Achats & approvisionnements.
- Sous-traitance.
- DQE / BPU / DPGF (registre de lignes).
- Contrats RH.
- Workflows de validation et signatures (registre préparatoire).
- CDE et révisions documentaires.
- Rapprochement bancaire.
- Paie / rémunération.
- Conformité et documents expirants.
- Plans d’actions.
- Droits serveur ajoutés pour les nouvelles collections.

INSTALLATION SUPABASE
1. Garder schema-entreprise.sql et les migrations précédentes.
2. Exécuter supabase/migration-v90-enterprise.sql après V81.
3. Redéployer tout le dossier.
4. Vider/actualiser le cache PWA si nécessaire.
5. Exécuter node tools/check.js avant livraison.

IMPORTANT
Cette V90 ajoute le socle métier et les registres Enterprise. Les workflows juridiques/comptables (paie réglementaire, signature qualifiée, rapprochement bancaire automatisé, fiscalité) doivent être paramétrés selon le pays et validés avant production.

PDF / IMPRESSION
Aucun ancien moteur PDF n’est remplacé par V90. Les corrections A4 existantes sont conservées. Les modules Enterprise pourront ensuite être branchés aux gabarits PDF communs.
