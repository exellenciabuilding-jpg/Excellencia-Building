# V99zzz — TFL : aucune limite par étudiant + un sujet déjà choisi disparaît de la liste

## Ce qui change
| Avant (V99zzy) | Maintenant (V99zzz) |
|---|---|
| 2 sujets réservés au plus par numéro | **Aucune limite** de sujets par étudiant |
| Une réservation sans fiche complétée expirait après 14 jours | **N'expire plus** : seul l'administrateur libère un sujet |
| Limite par adresse IP (40 choix / 40 fiches par heure) et 5 demandes par numéro et par heure | **Supprimées** (un campus partageant une même connexion n'est plus bloqué) |
| Un sujet réservé restait affiché « Réservé » | **Un sujet exclusif déjà choisi disparaît** de la liste, de la recherche et des filtres |

Reste en place : le jeton secret de la fiche étudiante (V99zzy), les dépôts QR « non confirmés », et un **plafond global très haut** (2000 demandes par heure) contre une inondation automatique. Un sujet « plusieurs étudiants possibles » reste affiché.

## À faire
1. Supabase › SQL Editor : exécuter **`supabase/migration-v99zzz-tfl-sans-limite.sql`** (après `migration-v99zzy`, réexécutable).
2. Déployer ce ZIP (cache `exb-v99zzz-tfl-sans-limite`), recharger une fois.
3. Vérifier : `select proname from pg_proc where proname = 'tfl_sujet_choisir' and prosrc ilike '%_reservations%';` → **0 ligne**.

La page masque déjà un sujet choisi même si le SQL n'est pas encore exécuté ; mais les limites ne sautent qu'avec le SQL.

## À savoir
- **Libérer un sujet** : si un étudiant abandonne, le sujet reste caché tant que l'administrateur ne le libère pas (module TFL › sujets › statut « Disponible », puis publication). Refuser un dossier remet aussi le sujet à disposition.
- **Risque assumé** : sans plafond, une seule personne peut réserver beaucoup de sujets exclusifs et les cacher aux autres (le numéro de téléphone n'est pas vérifié). Surveillez les dossiers reçus ; la vérification par SMS/WhatsApp reste la vraie réponse.
- **Non exécuté sur un vrai PostgreSQL ici** : la migration et les tests SQL (`tools/test-rls/test-tfl-qr.sql`, ajustés et complétés V1 à V4) sont à lancer avec `tools/test-rls/run.sh` sur votre machine.

## Tests passés ici
`node tools/check.js` : 411/411 · `test.js`, `test-banque.js`, `test-portail.js` · `e2e-sujets.py`, `e2e-jeton.py`, `e2e-banque.py`, `e2e-sujets-admin.py`, `e2e-sujets-pagine.py` : tous OK.

Fichiers : nouveau `supabase/migration-v99zzz-tfl-sans-limite.sql` ; modifiés `tfl-sujets.html`, `sw.js`, `tools/check.js`, `tools/test-rls/run.sh`, `tools/test-rls/test-tfl-qr.sql`, `tools/test-tfl/e2e-sujets.py`.
Retour en arrière : restaurer ces fichiers de V99zzy et ré-exécuter `migration-v99zzy`, `migration-v99zzw` (fonctions de liste) et `migration-v99zzv`.
