# V99y — Correctif : pages de modules invisibles + biométrie

## Problème corrigé
Projet 360° (V67), Priorité 2 CDE/BIM/EVM (V68), Intelligence BTP (V69), Plans & Structure (V70), Feuilles de plans (V71) et Plans / PDF (V72)
s'ouvraient sur une page vide : leurs pages étaient ajoutées dans le conteneur des onglets, que le nouveau cadre de navigation masque.
- `exb-v99r-shell.js` : ces pages sont replacées dans la zone de contenu ; une seule page est affichée à la fois ; fil d'Ariane, barre des modules et Retour/Avant fonctionnent aussi pour elles.
- `exb-v69.js` : le bouton « Intelligence BTP » était imbriqué dans le bouton « Administration » (cliquer l'un ouvrait l'autre).
- `exb-typo.js` / `exb-theme.js` : boutons et tableaux de ces pages mis en forme (clair et sombre).
Les modules V67 à V72 eux-mêmes ne sont pas modifiés (hors le bouton V69).

## Inclus aussi
Connexion par empreinte / visage (V99x), Équipe (V99w), Espace propriétaire (V99v), Navigation / thème / typographie.
