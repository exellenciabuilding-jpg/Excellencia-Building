/* Excellencia Building — lecture des fichiers de questions (PDF, Word .docx, TXT)
   100 % local : aucune bibliothèque externe obligatoire, fonctionne hors connexion.
   API : EXBImport.readFile(File) -> Promise<string> ; EXBImport.pdfText(ArrayBuffer) ; EXBImport.docxText(ArrayBuffer)
   Si pdf.js / mammoth sont déjà présents dans la page (window.pdfjsLib / window.mammoth), ils sont utilisés en premier. */
window.EXBImport=(function(){
  'use strict';
  var TD=typeof TextDecoder!=='undefined'?new TextDecoder('latin1'):null;

  function u8ToBin(u){var s='',n=u.length,i=0,CH=8192;for(;i<n;i+=CH)s+=String.fromCharCode.apply(null,u.subarray(i,Math.min(n,i+CH)));return s}
  function binToU8(s){var u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i)&255;return u}
  async function inflate(u8,fmt){
    if(typeof DecompressionStream==='undefined')throw new Error('Ce navigateur ne sait pas décompresser le fichier. Collez le texte dans la zone Questions.');
    var ds=new DecompressionStream(fmt),w=ds.writable.getWriter();
    w.write(u8).catch(function(){});w.close().catch(function(){});
    var r=ds.readable.getReader(),ch=[],tot=0;
    for(;;){var x=await r.read();if(x.done)break;ch.push(x.value);tot+=x.value.length}
    var out=new Uint8Array(tot),p=0;ch.forEach(function(c){out.set(c,p);p+=c.length});return out
  }
  async function inflateSafe(u8,fmt){try{return await inflate(u8,fmt)}catch(e){
    /* flux tronqué ou suffixe parasite : on tente en retirant les 4 derniers octets, puis on abandonne */
    if(u8.length>8){try{return await inflate(u8.subarray(0,u8.length-4),fmt)}catch(e2){}}
    return null}}

  /* ============================== PDF ============================== */
  /* Mini-analyseur d'objets PDF (dictionnaires, tableaux, noms, nombres, références, chaînes) */
  function P(src){this.s=src;this.i=0}
  P.prototype.ws=function(){var s=this.s,c;for(;;){c=s.charCodeAt(this.i);if(c===32||c===10||c===13||c===9||c===12||c===0)this.i++;else if(c===37){while(this.i<s.length&&s.charCodeAt(this.i)!==10&&s.charCodeAt(this.i)!==13)this.i++}else break}};
  P.prototype.val=function(){
    this.ws();var s=this.s,c=s[this.i];if(c===undefined)return undefined;
    if(c==='<'&&s[this.i+1]==='<'){this.i+=2;var d={};for(;;){this.ws();if(s[this.i]==='>'&&s[this.i+1]==='>'){this.i+=2;break}if(this.i>=s.length)break;var k=this.val();if(!k||k.n===undefined){break}var v=this.val();d[k.n]=v}return d}
    if(c==='['){this.i++;var a=[];for(;;){this.ws();if(s[this.i]===']'){this.i++;break}if(this.i>=s.length)break;var e=this.val();if(e===undefined)break;a.push(e)}return a}
    if(c==='/'){var j=this.i+1;while(j<s.length&&!/[\s\/\[\]<>()%]/.test(s[j]))j++;var nm=s.slice(this.i+1,j).replace(/#([0-9a-fA-F]{2})/g,function(m,h){return String.fromCharCode(parseInt(h,16))});this.i=j;return {n:nm}}
    if(c==='('){return this.lit()}
    if(c==='<'){var e2=s.indexOf('>',this.i);var h=s.slice(this.i+1,e2).replace(/\s+/g,'');this.i=e2+1;if(h.length%2)h+='0';var o='';for(var q=0;q<h.length;q+=2)o+=String.fromCharCode(parseInt(h.substr(q,2),16));return {str:o}}
    var m=/^[+-]?(?:\d+\.?\d*|\.\d+)/.exec(s.substr(this.i,24));
    if(m){this.i+=m[0].length;var num=parseFloat(m[0]);
      if(/^\d+$/.test(m[0])){var sv=this.i;this.ws();var m2=/^(\d+)\s+R(?![A-Za-z])/.exec(s.substr(this.i,24));if(m2){this.i+=m2[0].length;return {ref:num}}this.i=sv}
      return num}
    var j2=this.i;while(j2<s.length&&!/[\s\/\[\]<>()%]/.test(s[j2]))j2++;if(j2===this.i)j2++;var w=s.slice(this.i,j2);this.i=j2;
    if(w==='true')return true;if(w==='false')return false;if(w==='null')return null;return {op:w}
  };
  P.prototype.lit=function(){
    var s=this.s,i=this.i+1,d=1,o='';
    while(i<s.length&&d>0){var c=s[i];
      if(c==='\\'){var n=s[i+1];i+=2;
        if(n==='n')o+='\n';else if(n==='r')o+='\r';else if(n==='t')o+='\t';else if(n==='b')o+='\b';else if(n==='f')o+='\f';
        else if(n>='0'&&n<='7'){var oc=n;while(oc.length<3&&s[i]>='0'&&s[i]<='7'){oc+=s[i];i++}o+=String.fromCharCode(parseInt(oc,8)&255)}
        else if(n==='\r'){if(s[i]==='\n')i++}else if(n==='\n'){}else o+=n;continue}
      if(c==='(')d++;else if(c===')'){d--;if(d===0){i++;break}}
      o+=c;i++}
    this.i=i;return {str:o}
  };

  function parseCMap(txt){
    var map={},maxLen=1,m,re;
    function hx(h){var o='';for(var i=0;i+3<=h.length;i+=4)o+=String.fromCharCode(parseInt(h.substr(i,4),16));if(h.length<=2)o=String.fromCharCode(parseInt(h,16));return o}
    var cs=/begincodespacerange([\s\S]*?)endcodespacerange/g;
    while((m=cs.exec(txt))){var r=/<([0-9a-fA-F]+)>/.exec(m[1]);if(r)maxLen=Math.max(maxLen,r[1].length/2)}
    re=/beginbfchar([\s\S]*?)endbfchar/g;
    while((m=re.exec(txt))){var pr=/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]*)>/g,x;while((x=pr.exec(m[1]))){map[parseInt(x[1],16)]=hx(x[2]);maxLen=Math.max(maxLen,x[1].length/2)}}
    re=/beginbfrange([\s\S]*?)endbfrange/g;
    while((m=re.exec(txt))){
      var rr=/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(?:<([0-9a-fA-F]*)>|\[([^\]]*)\])/g,y;
      while((y=rr.exec(m[1]))){var a=parseInt(y[1],16),b=parseInt(y[2],16);if(b-a>70000)continue;maxLen=Math.max(maxLen,y[1].length/2);
        if(y[3]!==undefined){var base=hx(y[3]),last=base.charCodeAt(base.length-1);for(var c=a;c<=b;c++)map[c]=base.slice(0,-1)+String.fromCharCode(last+(c-a))}
        else{var L=y[4].match(/<([0-9a-fA-F]*)>/g)||[];for(var c2=a;c2<=b&&c2-a<L.length;c2++)map[c2]=hx(L[c2-a].slice(1,-1))}}}
    return {map:map,len:maxLen}
  }

  async function pdfText(ab){
    var bin=u8ToBin(new Uint8Array(ab));
    if(bin.indexOf('%PDF')<0)throw new Error('Ce fichier n’est pas un PDF valide.');
    if(/\/Encrypt\b/.test(bin.slice(-4096))||/\/Encrypt\s+\d+\s+\d+\s+R/.test(bin.slice(-8192)))throw new Error('Ce PDF est protégé par un mot de passe. Collez le texte dans la zone Questions.');
    var objs={},streams={};
    /* 1) objets directs */
    var re=/(?:^|[\r\n\s])(\d+)\s+(\d+)\s+obj\b/g,m,heads=[];
    while((m=re.exec(bin)))heads.push({id:+m[1],at:m.index+m[0].length});
    for(var h=0;h<heads.length;h++){
      var st=heads[h].at,en=bin.indexOf('endobj',st);if(en<0)en=bin.length;
      var body=bin.slice(st,en),si=body.search(/>>\s*stream\r?\n?/);
      var dictTxt=body,raw=null;
      if(si>=0){
        var sm=/>>\s*stream(\r\n|\n|\r)?/.exec(body);dictTxt=body.slice(0,sm.index+2);
        var ds=st+sm.index+sm[0].length,de=bin.lastIndexOf('endstream',en);if(de<0)de=en;
        raw=bin.slice(ds,de).replace(/(\r\n|\n|\r)$/,'')}
      var p=new P(dictTxt),v=p.val();objs[heads[h].id]=v;if(raw!==null)streams[heads[h].id]=raw}
    function get(v){var g=0;while(v&&v.ref!==undefined&&g++<20)v=objs[v.ref];return v}
    async function data(id){
      var o=objs[id],raw=streams[id];if(raw===undefined||!o||typeof o!=='object')return null;
      var f=get(o.Filter),fl=Array.isArray(f)?f.map(function(x){return (get(x)||{}).n}):(f?[f.n]:[]);
      var u=binToU8(raw);
      for(var i=0;i<fl.length;i++){
        if(fl[i]==='FlateDecode'||fl[i]==='Fl'){u=await inflateSafe(u,'deflate');if(!u)return null;
          var dp=get(o.DecodeParms);if(Array.isArray(dp))dp=get(dp[i]);
          if(dp&&dp.Predictor>=10)u=unpredict(u,dp)}
        else if(fl[i]==='ASCIIHexDecode'){var hx=u8ToBin(u).replace(/[^0-9a-fA-F]/g,'');u=binToU8(hx.replace(/../g,function(x){return String.fromCharCode(parseInt(x,16))}))}
        else if(fl[i]==='ASCII85Decode'){u=a85(u8ToBin(u))}
        else return null}
      return u8ToBin(u)}
    function unpredict(u,dp){
      var cols=get(dp.Columns)||1,bpp=Math.max(1,Math.ceil(((get(dp.Colors)||1)*(get(dp.BitsPerComponent)||8))/8)),rl=Math.ceil(cols*(get(dp.Colors)||1)*(get(dp.BitsPerComponent)||8)/8),out=new Uint8Array(Math.floor(u.length/(rl+1))*rl),prev=new Uint8Array(rl);
      for(var r=0,o=0;r+rl<u.length;r+=rl+1,o+=rl){var t=u[r],cur=new Uint8Array(rl);
        for(var i=0;i<rl;i++){var x=u[r+1+i],a=i>=bpp?cur[i-bpp]:0,b=prev[i],c=i>=bpp?prev[i-bpp]:0,v;
          if(t===0)v=x;else if(t===1)v=x+a;else if(t===2)v=x+b;else if(t===3)v=x+((a+b)>>1);else{var pp=a+b-c,pa=Math.abs(pp-a),pb=Math.abs(pp-b),pc=Math.abs(pp-c);v=x+(pa<=pb&&pa<=pc?a:(pb<=pc?b:c))}
          cur[i]=v&255}
        out.set(cur,o);prev=cur}
      return out}
    function a85(s){s=s.replace(/\s+/g,'');if(s.slice(0,2)==='<~')s=s.slice(2);var e=s.indexOf('~>');if(e>=0)s=s.slice(0,e);var o=[],g=[];
      for(var i=0;i<s.length;i++){var c=s[i];if(c==='z'&&!g.length){o.push(0,0,0,0);continue}g.push(s.charCodeAt(i)-33);
        if(g.length===5){var n=0;g.forEach(function(d){n=n*85+d});o.push((n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255);g=[]}}
      if(g.length>1){var k=g.length;while(g.length<5)g.push(84);var n2=0;g.forEach(function(d){n2=n2*85+d});var b=[(n2>>>24)&255,(n2>>>16)&255,(n2>>>8)&255,n2&255];o=o.concat(b.slice(0,k-1))}
      return new Uint8Array(o)}
    /* 2) flux d'objets (PDF 1.5+) */
    for(var id in streams){
      var o=objs[id];if(!o||!o.Type||o.Type.n!=='ObjStm')continue;
      var d=await data(id);if(d===null)continue;
      var N=get(o.N),F=get(o.First),hp=new P(d.slice(0,F)),nums=[];
      for(var q=0;q<N*2;q++){var nv=hp.val();if(typeof nv!=='number')break;nums.push(nv)}
      for(var k=0;k<nums.length;k+=2){var begin=F+nums[k+1],end=k+2<nums.length?F+nums[k+3]:d.length;var sub=new P(d.slice(begin,end));if(!(nums[k] in objs))objs[nums[k]]=sub.val()}}
    /* 3) polices : correspondance code -> texte */
    var fontCache={};
    async function fontOf(ref){
      var key=ref&&ref.ref!==undefined?ref.ref:null;if(key!==null&&fontCache[key])return fontCache[key];
      var f=get(ref),info={map:null,len:1,two:false};
      if(f&&typeof f==='object'){
        var sub=(get(f.Subtype)||{}).n;info.two=sub==='Type0';
        var tu=f.ToUnicode;if(tu&&tu.ref!==undefined){var dd=await data(tu.ref);if(dd){var cm=parseCMap(dd);info.map=cm.map;info.len=cm.len;if(Object.keys(cm.map).length===0)info.map=null}}
        if(info.two&&info.len<2)info.len=2;
        /* Differences simples (ex. /eacute) */
        var en=get(f.Encoding);if(en&&typeof en==='object'&&!Array.isArray(en)&&en.Differences){var df=get(en.Differences),code=0,dm={};df.forEach(function(x){if(typeof x==='number')code=x;else if(x&&x.n){dm[code++]=glyph(x.n)}});info.diff=dm}}
      if(key!==null)fontCache[key]=info;return info}
    var GL={space:' ',eacute:'é',egrave:'è',ecircumflex:'ê',edieresis:'ë',agrave:'à',acircumflex:'â',adieresis:'ä',ccedilla:'ç',icircumflex:'î',idieresis:'ï',ocircumflex:'ô',odieresis:'ö',ugrave:'ù',ucircumflex:'û',udieresis:'ü',Eacute:'É',Egrave:'È',Agrave:'À',Ccedilla:'Ç',quoteright:'’',quoteleft:'‘',quotedblleft:'“',quotedblright:'”',endash:'–',emdash:'—',bullet:'•',ellipsis:'…',degree:'°',hyphen:'-',period:'.',comma:',',colon:':',semicolon:';',parenleft:'(',parenright:')',slash:'/',question:'?',exclam:'!',fi:'fi',fl:'fl',oe:'œ',OE:'Œ',Euro:'€',percent:'%',plus:'+',equal:'=',underscore:'_',quotesingle:"'",asterisk:'*',numbersign:'#',ampersand:'&',zero:'0',one:'1',two:'2',three:'3',four:'4',five:'5',six:'6',seven:'7',eight:'8',nine:'9'};
    function glyph(n){if(GL[n]!==undefined)return GL[n];if(n.length===1)return n;var u=/^uni([0-9A-Fa-f]{4})$/.exec(n);if(u)return String.fromCharCode(parseInt(u[1],16));return ''}
    var CP='€\u0000‚ƒ„…†‡ˆ‰Š‹Œ\u0000Ž\u0000\u0000‘’“”•–—˜™š›œ\u0000žŸ'.split('');
    function decode(str,f){
      if(!f)return str;var o='';
      if(f.map&&f.len>=2){for(var i=0;i+1<str.length;i+=2){var c=str.charCodeAt(i)*256+str.charCodeAt(i+1);o+=f.map[c]!==undefined?f.map[c]:''}return o}
      for(var j=0;j<str.length;j++){var c1=str.charCodeAt(j);
        if(f.map&&f.map[c1]!==undefined)o+=f.map[c1];else if(f.diff&&f.diff[c1]!==undefined)o+=f.diff[c1];else if(!f.two)o+=(c1>=128&&c1<160)?(CP[c1-128]||''):String.fromCharCode(c1)}
      return o}
    /* 4) pages dans l'ordre */
    var pages=[];
    function walk(node,inh,depth){
      node=get(node);if(!node||typeof node!=='object'||depth>40)return;
      var res=node.Resources!==undefined?node.Resources:inh,t=(get(node.Type)||{}).n;
      if(t==='Pages'||node.Kids){(get(node.Kids)||[]).forEach(function(k){walk(k,res,depth+1)})}
      else pages.push({node:node,res:res})}
    var root=null;for(var oid in objs){var ob=objs[oid];if(ob&&ob.Type&&ob.Type.n==='Catalog'){root=ob;break}}
    if(root&&root.Pages)walk(root.Pages,undefined,0);
    if(!pages.length){for(var pid in objs){var po=objs[pid];if(po&&po.Type&&po.Type.n==='Page')pages.push({node:po,res:po.Resources})}}
    /* 5) texte de chaque page */
    var out=[];
    for(var pi=0;pi<pages.length;pi++){
      var pg=pages[pi],cont=get(pg.node.Contents),list=Array.isArray(cont)?cont:(pg.node.Contents?[pg.node.Contents]:[]),code='';
      for(var ci=0;ci<list.length;ci++){var cid=list[ci]&&list[ci].ref;if(cid===undefined)continue;var cd=await data(cid);if(cd)code+=cd+'\n'}
      var res=get(pg.res)||{},fonts=get(res.Font)||{};
      out.push(await pageText(code,fonts,res,0))}
    async function pageText(code,fonts,res,depth){
      var p=new P(code),stack=[],cur=null,text='',lastY=null,x=0,y=0,lead=0,fcache={};
      async function fnt(name){if(fcache[name]!==undefined)return fcache[name];var r=fonts[name];fcache[name]=r?await fontOf(r):null;return fcache[name]}
      function nl(){if(text&&text[text.length-1]!=='\n')text+='\n'}
      function show(a){
        var o='';
        if(a&&a.str!==undefined)o=decode(a.str,cur);
        else if(Array.isArray(a)){a.forEach(function(e){if(e&&e.str!==undefined)o+=decode(e.str,cur);else if(typeof e==='number'&&e<-250&&o&&o[o.length-1]!==' ')o+=' '})}
        text+=o}
      var guard=0;
      for(;;){
        p.ws();if(p.i>=code.length||guard++>2000000)break;
        /* lire les opérandes jusqu'à l'opérateur */
        var args=[],v;
        for(;;){v=p.val();if(v===undefined)break;if(v&&v.op!==undefined)break;args.push(v);if(args.length>400)args.shift()}
        if(v===undefined)break;var op=v.op;
        if(op==='BI'){var ei=code.indexOf('EI',p.i);p.i=ei<0?code.length:ei+2;continue}
        switch(op){
          case 'Tf':cur=args[0]&&args[0].n!==undefined?await fnt(args[0].n):cur;break;
          case 'Tj':show(args[0]);break;
          case 'TJ':show(args[0]);break;
          case "'":nl();show(args[0]);break;
          case '"':nl();show(args[2]);break;
          case 'T*':nl();break;
          case 'TL':lead=args[0]||0;break;
          case 'Td':case 'TD':{var ty=args[1]||0,tx=args[0]||0;if(ty!==0)nl();else if(tx>0&&text&&!/\s$/.test(text))text+=' ';break}
          case 'Tm':{var ny=args[5];if(lastY!==null&&ny!==undefined&&Math.abs(ny-lastY)>2)nl();else if(lastY!==null&&text&&!/\s$/.test(text)&&args[4]>x+1)text+=' ';lastY=ny;x=args[4]||0;break}
          case 'BT':lastY=null;x=0;break;
          case 'ET':nl();break;
          case 'Do':{var xo=get(res.XObject)||{},nm=args[0]&&args[0].n,xr=xo[nm];if(xr&&xr.ref!==undefined&&depth<3){var xobj=objs[xr.ref];if(xobj&&xobj.Subtype&&xobj.Subtype.n==='Form'){var xd=await data(xr.ref);if(xd){var xres=get(xobj.Resources)||res;text+=await pageText(xd,get(xres.Font)||fonts,xres,depth+1)}}}break}
          default:break}
      }
      return text}
    var all=out.map(function(t){return t.replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim()}).filter(Boolean).join('\n\n');
    return all.replace(/ /g,' ').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'')
  }

  /* ============================== DOCX ============================== */
  async function docxText(ab){
    var u=new Uint8Array(ab),dv=new DataView(ab),n=u.length,eo=-1;
    for(var i=n-22;i>=Math.max(0,n-70000);i--){if(dv.getUint32(i,true)===0x06054b50){eo=i;break}}
    if(eo<0)throw new Error('Ce fichier Word est illisible.');
    var cnt=dv.getUint16(eo+10,true),cd=dv.getUint32(eo+16,true),found=null,p=cd;
    for(var k=0;k<cnt;k++){
      if(dv.getUint32(p,true)!==0x02014b50)break;
      var meth=dv.getUint16(p+10,true),csz=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),nm=u8ToBin(u.subarray(p+46,p+46+nl));
      if(nm==='word/document.xml'){found={meth:meth,csz:csz,lo:lo};break}
      p+=46+nl+el+cl}
    if(!found)throw new Error('Ce fichier n’est pas un document Word (.docx) valide.');
    var lh=found.lo,lnl=dv.getUint16(lh+26,true),lel=dv.getUint16(lh+28,true),ds=lh+30+lnl+lel,comp=u.subarray(ds,ds+found.csz),xml;
    if(found.meth===0)xml=comp;else if(found.meth===8){xml=await inflateSafe(comp,'deflate-raw');if(!xml)throw new Error('Contenu Word illisible.')}else throw new Error('Compression Word non prise en charge.');
    var s=new TextDecoder('utf-8').decode(xml);
    s=s.replace(/<w:tab\b[^>]*\/>/g,'\t').replace(/<w:(?:br|cr)\b[^>]*\/>/g,'\n').replace(/<\/w:p>/g,'\n').replace(/<w:p[ >][^>]*>/g,function(m){return m}).replace(/<[^>]+>/g,'');
    s=s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#(\d+);/g,function(m,d){return String.fromCharCode(+d)}).replace(/&#x([0-9a-fA-F]+);/g,function(m,d){return String.fromCharCode(parseInt(d,16))}).replace(/&amp;/g,'&');
    return s.replace(/\n{3,}/g,'\n\n').trim()
  }

  /* ============================ Point d'entrée ============================ */
  function withTimeout(pr,ms){return new Promise(function(ok,ko){var t=setTimeout(function(){ko(new Error('délai'))},ms);pr.then(function(v){clearTimeout(t);ok(v)},function(e){clearTimeout(t);ko(e)})})}
  async function viaPdfJs(ab){
    var L=window.pdfjsLib;if(!L)return '';
    try{
      var pdf=await withTimeout(L.getDocument({data:new Uint8Array(ab.slice(0))}).promise,20000),t=[];
      for(var i=1;i<=pdf.numPages;i++){var pg=await pdf.getPage(i),c=await pg.getTextContent(),line=[],lastY=null;
        c.items.forEach(function(x){var y=x.transform?x.transform[5]:null;if(lastY!==null&&y!==null&&Math.abs(y-lastY)>2)line.push('\n');line.push(x.str);lastY=y});
        t.push(line.join(''))}
      return t.join('\n\n')}catch(e){return ''}
  }
  async function readFile(file){
    if(!file)return '';
    var name=String(file.name||'').toLowerCase(),ab;
    if(/\.txt$/.test(name)||file.type==='text/plain')return await file.text();
    ab=await file.arrayBuffer();
    if(/\.docx$/.test(name)){
      if(window.mammoth){try{var o=await window.mammoth.extractRawText({arrayBuffer:ab.slice(0)});if(o&&o.value&&o.value.trim())return o.value}catch(e){}}
      return await docxText(ab)}
    if(/\.doc$/.test(name))throw new Error('Ancien format Word (.doc) non pris en charge : enregistrez-le en .docx ou PDF, ou collez le texte.');
    if(/\.pdf$/.test(name)||file.type==='application/pdf'){
      var t=await viaPdfJs(ab);
      if(!t||!t.trim()){try{t=await pdfText(ab)}catch(e){if(!t)throw e}}
      if(!t||!t.trim())throw new Error('Ce PDF ne contient pas de texte lisible (probablement un scan ou une photo). Collez le texte dans la zone Questions ou utilisez un fichier Word/TXT.');
      return t}
    throw new Error('Format non pris en charge. Utilisez PDF, DOCX ou TXT.')
  }
  return {readFile:readFile,pdfText:pdfText,docxText:docxText}
})();
