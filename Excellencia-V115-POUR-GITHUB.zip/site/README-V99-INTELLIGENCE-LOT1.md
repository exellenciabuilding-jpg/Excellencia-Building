# EXCELLENCIA INTELLIGENCE — lot 1 : le moteur central

Nouveau fichier : `exb-intelligence.js`. Modifiés : `index.html` (1 balise script), `sw.js` (cache), `exb-home-pro.js` (ligne « Anomalies détectées » sur l'accueil).
Aucune donnée ni fonction existante modifiée. S'appuie sur ce qui existe : EXBLIEN (liaison), assistant IA, journal d'audit.

## Ce que fait le lot 1
1. **Communication entre modules** : bus d'événements `EXBI.bus` (`change`, `update`, `history`) ; la liaison EXBLIEN est branchée comme moteur.
2. **Sans nouvelle saisie** : lecture seule des fiches déjà enregistrées (clients, projets, devis, factures, caisse, stock, mouvements, personnel, études, participants).
3. **Erreurs, incohérences, doublons** : 12 règles (doublons projets/factures/devis/participants/stock ; facture sans ligne, prix négatif, échéance avant date, TVA inhabituelle ; projet fin avant début, projet terminé avec solde dû ; caisse nulle ou future ; stock négatif ou sous seuil ; téléphone/e-mail invalides) + toutes les anomalies de EXBLIEN.
4. **Calculs** : moteur `EXBI.calc.invoice` (HT/TTC/reste). Les autres moteurs techniques s'enregistrent via `EXBI.registerEngine`.
5. **Recommandations** : factures à relancer (message copiable), devis accepté sans facture, matériaux à réapprovisionner, clients sans contact, liaison automatique.
6. **Actualisation** : toute modification (même reçue de la base partagée) relance les contrôles ; l'accueil et le bouton 🧠 se mettent à jour.
7. **Rapport** : export HTML du rapport de contrôle (hors ligne).
8. **Historique** : qui / quand / champ avant → après, 1000 entrées (clé `exb_intel_history`). Limite : seules les modifications faites pendant que l'application est ouverte sont journalisées.
9. **Confirmation** : `EXBI.confirm()` avant toute opération critique (la relance de la liaison l'utilise) ; chaque action est inscrite au journal d'audit.

## Hybride
- Local : tout ce qui précède fonctionne sans Internet.
- IA : l'assistant existant reçoit le contexte du moteur ; hors connexion, les questions « anomalies / doublons / recommandations » sont traitées localement.
- Synchronisation : le moteur ne synchronise pas lui-même ; il constate les changements que la base partagée existante apporte.

## Accès
Bouton 🧠 dans l'en-tête (pastille = erreurs + alertes) et ligne « Anomalies détectées » dans « À faire aujourd'hui ».

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence.js">` de index.html.

## À confirmer sur vos appareils
Les noms de champs (qty, min, status, quote_id…) ont été lus dans le code ; les règles ignorent un champ absent. Tester avec vos vraies données et signaler les faux positifs (bouton « Ignorer » disponible).
