/* Excellencia Building V75 — pont de stockage commun.
 * Tous les modules V70-V74 lisent/écrivent via exbStorage (préfixé), la seule zone lue par la synchronisation
 * (exb-db.js) et par la sauvegarde. Les anciennes données stockées en direct (localStorage brut) sont migrées une fois. */
(function(w){'use strict';
/* exbStorage est déclaré avec « const » dans index.html : il n'existe pas sur window. On l'atteint par son nom global (V99zz). */
function st(){if(w.exbStorage)return w.exbStorage;try{return typeof exbStorage!=='undefined'?exbStorage:null}catch(e){return null}}
function parse(s){try{var a=JSON.parse(s||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function migrate(k){try{var s=st();if(!s||s.getItem(k)!=null)return;var raw=localStorage.getItem(k);if(raw&&parse(raw).length)s.setItem(k,raw)}catch(e){}}
w.EXBS={
 get:function(k){var s=st();if(!s)return parse(localStorage.getItem(k));migrate(k);return parse(s.getItem(k))},
 set:function(k,a){var s=st(),v=JSON.stringify(a);try{if(s)s.setItem(k,v);else localStorage.setItem(k,v)}catch(e){try{w.notify&&w.notify('Stockage plein : enregistrement impossible.','warn')}catch(x){}return false}
  try{if(w.EXBDB&&w.EXBDB.mark)w.EXBDB.mark(k)}catch(e){}return true},
 projects:function(){return w.EXBS.get('exb_projects')}
};
})(window);
