# EXCELLENCIA INTELLIGENCE — lot 6 : plan-éditeur ↔ métré, structure ↔ métré, BIM/IFC, chantier

Nouveau : `exb-intelligence-6.js` (après `exb-intelligence.js`). Modifiés : `index.html` (1 balise), `sw.js` (cache + version). **Lecture seule** : ce lot ne modifie aucune donnée.

## Contrôles ajoutés
- **Plan-éditeur** : murs de longueur nulle (comptés à tort dans les quantités), plan vide, plans de même nom.
- **Plan ↔ métré** : lignes du métré issues d'un plan supprimé, lignes de plan en double, plan modifié après l'enregistrement du métré (renvoyer les quantités).
- **Structure ↔ métré** : section des poteaux des notes de calcul du projet comparée aux « Amorces de poteaux » du métré (tolérance 5 %, orientation indifférente).
- **BIM** : modèle en double (même référence/projet), dessin ou projet introuvable ; point BIM sans modèle, identifiant BCF en double, point urgent ouvert > 30 jours, point sans responsable.
- **Chantier** : bons de commande (payé > total, reçu > commandé, livraison avant commande, fournisseur/projet introuvable, numéro en double) ; situations (% hors 0–100, avancement décroissant, marché nul, retenue inhabituelle, numéro en double) ; pointages (doublon, jours hors ]0;1], coût ≠ taux × jours, date future) ; rapports de chantier (date future, deux le même jour) ; tâches terrain (en retard, 100 % non clôturée, sans responsable).

## Moteurs et documents
`EXBI.calc.planStats`, `.sectionPoteau`, `.bc`, `.situation`. Document : « Rapport chantier par projet » (HTML, hors ligne). Recommandations : plan jamais envoyé au métré, métré béton sans note de calcul, tâches en retard.

## Tests réalisés (navigateur, vraies pages)
Données avec erreurs volontaires : les 23 constats attendus sont produits. Données propres : 0 constat (pas de faux positif). Aucune donnée : 0 constat. Constats des lots 1 à 5 identiques avec et sans ce lot, aucune erreur JavaScript, fonctionne hors connexion. `node tools/check.js` : 485 réussis ; les 5 échecs sont déjà présents dans l'archive d'origine (anciens contrôles de noms de cache PWA).

## Réserves
- **Structure ↔ métré** : seules les sections de poteaux sont comparées. Les dimensions des semelles, poutres et le ferraillage ne sont pas comparés (leurs champs ne sont pas exposés de façon fiable par le module de calcul). Les cases du métré non modifiées (valeurs par défaut du modèle Excel) ne sont pas lues.
- **Plan modifié après le métré** : repose sur la date d'enregistrement ; c'est un indice, pas une preuve de différence de quantités (les quantités du plan se calculent dans l'éditeur).
- **BIM** : contrôle des fiches et points BCF ; le contenu des fichiers IFC n'est pas analysé. Les noms de champs (`project_id`/`project`, `priority`, `created_at`, `bcf_guid`) sont lus dans le code ; les règles ignorent un champ absent.
- **Chantier** : le seuil de retenue (20 %) est un repère à ajuster. Réserves, RFI et QHSE ne sont pas contrôlés (déjà normalisés par le module terrain unifié).
- Non testé sur téléphone ni avec la base partagée réelle.

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-6.js">` de index.html.
