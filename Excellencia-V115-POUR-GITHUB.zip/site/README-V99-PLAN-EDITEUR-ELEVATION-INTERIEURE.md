# V99 — Éditeur de plan : Élévation intérieure

Fichiers modifiés : `plan-editeur/index.html`, `plan-editeur/coupes.js`, `sw.js` (version du cache).

- **Outil Élévation** (palette de gauche) : touchez le point A puis le point B, dans la pièce, le long du mur à regarder. La vue s'ouvre aussitôt (onglet « Élévation int. »).
- **Contenu** : le mur visé et tout ce qui est devant (portes, fenêtres avec leurs cotes, meubles), vus de l'intérieur, sur la largeur A–B et sur une **profondeur réglable** (champ « Profondeur », 6 m par défaut). Pas de toiture. Altitudes et cotes comme pour les façades.
- **Sens de vue** : bouton « ⇄ Sens de vue » (la vue regarde à gauche du sens A→B ; la flèche verte sur le plan l'indique). « ✏ Tracer l'élévation » pour la retracer.
- **Plan** : ligne verte « Élév. int. » avec flèche de direction. Enregistrée avec le plan (plusieurs élévations intérieures par plan).

## Mise à jour : plusieurs élévations, exports, navigateur

- **Plusieurs élévations par plan** : « ＋ Nouvelle élévation » ajoute une élévation (A–B, sens, profondeur propres) ; la liste déroulante choisit celle qui s'affiche ; « 🗑 Élévation » supprime la courante. Sur le plan, chaque ligne est numérotée « Élév. int. 1, 2… » (la courante est en vert foncé). Les plans déjà enregistrés avec l'ancienne élévation unique sont migrés automatiquement (`D.ei` → `D.eis`).
- **Export DXF** : chaque élévation a sa ligne de repère (calque `ELEV_INT_n`) et sa vue rangée sous le plan (calques `ELEVINTn_…`, titre dans `TITRES`).
- **PDF de documentation** : une feuille par élévation intérieure, après la coupe A-A.
- **Navigateur de projet** : rubrique « Élévations int. » avec une ligne par élévation ; chaque élévation a aussi son onglet de vue.
- **Correctif** : `printPlan` ne transmettait pas son mode (`pm`) à `doPrint` → « pm is not defined » au moment d'imprimer / d'exporter en PDF ; corrigé.

Limites : murs courbes vus en projection simple. Détail reste grisé « bientôt », sans fausse fonction.
Testé dans Chromium sans écran : deux tracés, sélection, sens/profondeur, suppression, rechargement, DXF, PDF, navigateur et onglets, aucune erreur de console. Non testé sur appareil réel.
