# Notifications WhatsApp, matricule après import, avis anticipé, demandes de retrait

1. **Informer par WhatsApp** : bouton « 💬 Informer l'étudiant du statut » dans chaque dossier ; bouton « 💬 Informer » sous chaque sujet d'encadreur. Le message (accepté, refusé + motif, complément, retenu…) est préparé avec le lien de suivi ; vous n'avez qu'à envoyer.
2. **Matricule hors connexion** : après chaque import de fichier (ou de dépôt en ligne), un bouton « 💬 Envoyer le matricule » prépare le message au demandeur, avec le lien de suivi.
3. **Avis de l'encadreur avant acceptation** : un dossier « En vérification » peut être affecté à un encadreur pour avis ; il le voit dans son portail (« avis demandé ») et valide, demande une correction ou refuse. L'affectation d'un dossier simplement « Reçu » reste refusée.
4. **Modification / retrait** : sur la page de suivi, bouton « ✎ Demander une modification ou un retrait » (matricule + téléphone vérifiés). Côté administration : TFL › Encadreurs › Formulaire › ④ « Récupérer les demandes » puis « ✔ Appliquer » (dossier → complément demandé ou clos ; sujet d'encadreur → complément ou retiré) et « 💬 Informer la personne ».

SQL : exécuter `supabase/migration-v99zzzzzzzzzzzzzz-LOT8-demandes.sql` (n° 12 de ORDRE-D-EXECUTION.md) après les lots 1 à 7. Sans lui, les points 1 à 3 fonctionnent ; le point 4 affiche « service non activé ».
