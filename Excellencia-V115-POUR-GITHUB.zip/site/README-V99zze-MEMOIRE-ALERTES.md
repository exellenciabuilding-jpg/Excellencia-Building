# V99zze — Mémoire du travail + alertes sonores des demandes
**Aucun SQL.** Nouveau fichier `exb-memoire.js` (chargé par index.html, ajouté au cache hors-ligne).

## Mémoire du travail
- Quand vous quittez un onglet (devis, architecture, finance…) et y revenez, ou rechargez la page, ce que vous aviez saisi sans l'enregistrer est remis.
- Brouillons gardés sur l'appareil 14 jours, effacés à la déconnexion ; mots de passe et fichiers jamais mémorisés.
- Après un enregistrement, le brouillon est remplacé (pas de donnée périmée qui revient).
- Option : rouvrir la dernière page consultée (dans les 12 h).
- Réglages : Paramètres › « Mémoire du travail ».

## Alertes sonores (Paramètres › « Alertes sonores des demandes »)
- Désactivées par défaut. Choix de la sonnerie (carillon, bip double, cloche, alerte), volume, annonce vocale en français, notification du navigateur si l'onglet est en arrière-plan, fréquence de vérification (30 s à 5 min), rappel si des demandes restent en attente.
- Exemple annoncé : « Vous avez reçu une demande d'inscription d'un apprenant. Veuillez l'importer et l'approuver. »
- Types : inscriptions, TP/TD, clients, demandes de projet, formateurs, personnel, demandes de logiciel, copies d'évaluation, messages et déclarations du portail.
- Le nombre de demandes en attente s'affiche dans le titre de l'onglet du navigateur.
- Condition : application ouverte et connectée au compte en ligne (Participants › Demandes en ligne). Le navigateur exige un premier clic dans la page pour autoriser le son.
Tests : `python3 tools/test-memoire/test.py` (21 contrôles).
