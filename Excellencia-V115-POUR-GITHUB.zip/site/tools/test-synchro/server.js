// Faux serveur Supabase : reproduit enregistrer(), peut() et le filtrage de lecture de la migration V99zf.
const http=require('http'),fs=require('fs'),path=require('path'),url=require('url');
const ROOT=process.argv[2],PORT=8777;
if(!ROOT){console.log('Faux serveur Supabase pour test.py (ne pas lancer seul). Usage : node server.js <dossier-du-site>');process.exit(0)}
const members={A:{role:'admin',fonction:'polyvalent'},B:{role:'editeur',fonction:'polyvalent'},C:{role:'editeur',fonction:'comptable'}};
const sens=new Set(['personnel','paie','contrats_rh','rapprochement_bancaire','v92_employes','v92_contrats_rh','v92_paies','v92_banques','v92_transactions_bancaires']);
const droits=[['comptable','v92_paies',1,1],['comptable','v92_banques',1,1],['comptable','v92_commandes',1,1]];
const rows=new Map(); let clock=Date.now();
function peut(u,col,w){const m=members[u];if(!m)return false;if(m.role==='admin')return true;if(w&&m.role!=='editeur')return false;
  if(m.fonction==='polyvalent'&&!sens.has(col))return true;
  return droits.some(d=>d[0]===m.fonction&&d[1]===col&&(w?d[3]:d[2]))}
const send=(res,c,b)=>{res.writeHead(c,{'content-type':'application/json'});res.end(JSON.stringify(b))};
const mime={'.js':'text/javascript','.html':'text/html','.json':'application/json'};
http.createServer((req,res)=>{
 const u=url.parse(req.url,true),user=req.headers['x-user']||'';let body='';
 req.on('data',d=>body+=d);req.on('end',()=>{
  const p=u.pathname;
  if(p.startsWith('/rest/v1/rpc/')){const n=p.split('/').pop(),a=body?JSON.parse(body):{},m=members[user];
   if(n==='equipe_reclamer')return send(res,200,null);
   if(n==='mon_organisation')return send(res,200,{id:'O1',nom:'Test SARL',role:m.role,fonction:m.fonction,code:m.role==='admin'?'abc123':null});
   if(n==='enregistrer'){
    if(!peut(user,a.p_col,true)){return send(res,200,{ok:false,refus:true})}
    const k=a.p_col+'|'+a.p_id,cur=rows.get(k);
    if(cur){if(cur.version!==a.p_base)return send(res,200,{ok:false,conflit:true,version:cur.version,data:cur.data,supprime:cur.supprime});
      rows.set(k,{collection:a.p_col,id:a.p_id,data:a.p_data,version:cur.version+1,supprime:!!a.p_supprime,maj:new Date(++clock).toISOString()});return send(res,200,{ok:true,version:cur.version+1})}
    if(a.p_base!==0)return send(res,200,{ok:false,conflit:true,version:0,data:null,supprime:true});
    rows.set(k,{collection:a.p_col,id:a.p_id,data:a.p_data,version:1,supprime:!!a.p_supprime,maj:new Date(++clock).toISOString()});return send(res,200,{ok:true,version:1})}
   return send(res,404,{message:'rpc inconnue '+n})}
  if(p==='/rest/v1/droits_fonction'){const f=(u.query.fonction||'').replace('eq.','');return send(res,200,droits.filter(d=>d[0]===f).map(d=>({collection:d[1],lire:!!d[2],ecrire:!!d[3]})))}
  if(p==='/rest/v1/enregistrements'){const g=u.query.maj?u.query.maj.replace('gt.',''):'';
   const out=[...rows.values()].filter(r=>peut(user,r.collection,false)&&(!g||r.maj>g)).sort((a,b)=>a.maj<b.maj?-1:1);return send(res,200,out)}
  if(p==='/__rows')return send(res,200,[...rows.values()].map(r=>({c:r.collection,id:r.id,v:r.version})));
  if(p==='/__reset'){rows.clear();return send(res,200,{})}
  let f=p==='/h.html'?path.join(__dirname,'h.html'):path.join(ROOT,p.replace(/^\/proj\//,''));
  fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('nf')}res.writeHead(200,{'content-type':mime[path.extname(f)]||'application/octet-stream'});res.end(d)})})
}).listen(PORT,()=>console.log('up'));
