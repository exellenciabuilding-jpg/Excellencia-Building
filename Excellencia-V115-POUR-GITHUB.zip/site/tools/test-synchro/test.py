import json,subprocess,sys,time
from playwright.sync_api import sync_playwright
ROOT=sys.argv[1]
srv=subprocess.Popen(['node','server.js',ROOT],stdout=subprocess.PIPE);srv.stdout.readline()
B='http://localhost:8777'
res=[]
def ok(name,cond,info=''):
    res.append(cond);print(('  OK   ' if cond else '  ECHEC'),name,('' if cond else '→ '+str(info)))
try:
  with sync_playwright() as p:
    br=p.chromium.launch()
    pg={}
    for u in 'ABC':
        pg[u]=br.new_context().new_page()
        pg[u].on('pageerror',lambda e,u=u:print('  pageerror',u,e))
        pg[u].goto(f'{B}/h.html?u={u}')
    time.sleep(4)  # liaison automatique à l'entreprise
    sync=lambda u:(pg[u].evaluate('EXBDB.now()'),time.sleep(.6),pg[u].evaluate('EXBDB.cycle()'),time.sleep(.6))
    get=lambda u,k:json.loads(pg[u].evaluate(f"localStorage.getItem('{k}')||'[]'"))
    ok('A, B et C sont reliés à l\'entreprise',all(pg[u].evaluate('EXBDB.info().on') for u in 'ABC'))
    # 1. commande créée sur A, reçue sur B
    pg['A'].evaluate("EXB_ERP.createPurchaseOrder({amount:1000,supplier:'Ciment SA'})");sync('A');sync('B')
    ob=get('B','exb_v92_purchase_orders')
    ok('commande V92 créée sur A visible sur B',len(ob)==1 and ob[0]['amount']==1000,ob)
    # 2. moyens de paiement par défaut : 6 identiques partout
    for u in 'ABC':sync(u)
    for u in 'ABC':sync(u)
    nm={u:len(get(u,'exb_v93_payment_methods')) for u in 'ABC'}
    ok('moyens de paiement par défaut : 6 sur chaque appareil, sans doublon',set(nm.values())=={6},nm)
    # 3. doublons hérités (ids aléatoires) réduits à un seul
    pg['A'].evaluate("""(()=>{const a=JSON.parse(localStorage.getItem('exb_v93_payment_methods'));a.push({id:'PAY-zzz',code:'cash',label:'Espèces',active:true});a.push({id:'PAY-aaa',code:'cash',label:'Espèces',active:true});localStorage.setItem('exb_v93_payment_methods',JSON.stringify(a));EXB_PAYMENTS.refresh()})()""")
    ids=[m['id'] for m in get('A','exb_v93_payment_methods') if m['code']=='cash']
    ok('doublons « Espèces » réduits au moyen PM-cash',ids==['PM-cash'],ids)
    # 4. conflit : A et B modifient la même commande
    oid=ob[0]['id']
    pg['A'].evaluate(f"(()=>{{const a=JSON.parse(localStorage.getItem('exb_v92_purchase_orders'));a[0].status='approved_A';localStorage.setItem('exb_v92_purchase_orders',JSON.stringify(a))}})()")
    pg['B'].evaluate(f"(()=>{{const a=JSON.parse(localStorage.getItem('exb_v92_purchase_orders'));a[0].status='approved_B';localStorage.setItem('exb_v92_purchase_orders',JSON.stringify(a))}})()")
    pg['A'].evaluate('EXBDB.cycle()');time.sleep(.8);pg['B'].evaluate('EXBDB.cycle()');time.sleep(.8)
    conf=pg['B'].evaluate('EXBDB._meta().conf.length');st=get('B','exb_v92_purchase_orders')[0]['status']
    ok('conflit détecté : version de A gardée sur B, version de B conservée dans « Conflits »',conf>=1 and st=='approved_A',(conf,st))
    # 5. données sensibles
    pg['B'].evaluate("EXB_ERP.addEmployee({name:'Jean Kasongo',salary:900})");time.sleep(.3)
    ok('B (polyvalent) ne peut pas créer un salarié V92 (bloqué sur l\'appareil)',get('B','exb_v92_employees')==[],get('B','exb_v92_employees'))
    pg['C'].evaluate("EXB_ERP.addEmployee({name:'Marie Mbuyi',salary:1200})");sync('C');sync('A');sync('B')
    ok('C (comptable) n\'a pas le droit sur v92_employes (personnel) : refusé par le serveur',not any(r['c']=='v92_employes' for r in json.loads(pg['A'].evaluate("fetch('/__rows').then(r=>r.text())"))),'')
    # paie : comptable autorisé, polyvalent non
    pg['C'].evaluate("(()=>{localStorage.setItem('exb_v92_payroll',JSON.stringify([{id:'PAY-1',month:'2026-10',net:500}]))})()");sync('C');sync('A');sync('B')
    ok('paie V92 saisie par le comptable arrive chez l\'administrateur',len(get('A','exb_v92_payroll'))==1,get('A','exb_v92_payroll'))
    ok('paie V92 JAMAIS reçue par le membre polyvalent B',get('B','exb_v92_payroll')==[],get('B','exb_v92_payroll'))
    leak=pg['B'].evaluate("fetch('/rest/v1/enregistrements?org_id=eq.O1&select=collection',{headers:{'x-user':'B'}}).then(r=>r.json())")
    ok('lecture directe côté serveur : B ne voit aucune collection sensible',not any(r['collection'] in ('v92_paies','v92_employes','v92_banques') for r in leak),[r['collection'] for r in leak])
    forced=pg['B'].evaluate("fetch('/rest/v1/rpc/enregistrer',{method:'POST',headers:{'x-user':'B','content-type':'application/json'},body:JSON.stringify({p_org:'O1',p_col:'v92_paies',p_id:'X',p_data:{},p_base:0})}).then(r=>r.json())")
    ok('écriture directe côté serveur par B sur la paie : refusée',forced.get('refus') is True,forced)
    # 6. BTP et paiements
    pg['A'].evaluate("EXB_BTP.createProject({name:'Immeuble R+4'})");sync('A');sync('B')
    ok('projet BTP V93 synchronisé de A vers B',len(get('B','exb_v93_projects'))==1,get('B','exb_v93_projects'))
    br.close()
finally:
    srv.terminate()
print();print('Résultat :',sum(res),'/',len(res),'réussis');sys.exit(0 if all(res) else 1)
