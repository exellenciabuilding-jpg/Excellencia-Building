// Test du devis automatique (partie calcul, sans navigateur). Depuis la racine : node tools/test-auto-devis.js
const fs=require('fs'),I=require('../exb-ifc3d.js'),A=require('../exb-auto-devis.js');let ok=0,tot=0;
const chk=(n,c)=>{tot++;ok+=!!c;console.log((c?'OK    ':'ECHEC ')+n)};
const near=(a,b,e)=>Math.abs(a-b)<=(e==null?0.01:e);
(async()=>{
 const rd=f=>I.parse(fs.readFileSync('tools/test-bim/'+f,'utf8')).then(m=>I.quantities(m));
 // --- petite maquette de référence : 2 murs de 5 × 3 × 0,2 m (ouverture dans chacun), 1 dalle 5 × 4, 1 poteau
 const Q=await rd('quantites.ifc'),R=A.ifcLignes(Q,'ref'),by=k=>R.lines.find(l=>l.k===k);
 chk('murs : surface nette 1 face proche du réel (27,1 m² = volume net / épaisseur), jamais sous-estimée, surestimation ≤ 12 %',by('murs-m2')&&by('murs-m2').q>=27.1-0.01&&by('murs-m2').q<=27.1*1.12);
 chk('enduit = 2 × la surface de mur',near(by('murs-enduit').q,2*by('murs-m2').q,0.01));
 chk('murs : prix de départ = prix de l’éditeur de plan (maçonnerie 14 $/m², enduit 7 $/m²)',by('murs-m2').pu===14&&by('murs-enduit').pu===7);
 chk('dalle : surface en plan 20 m² à 38 $/m²',near(by('dalle').q,20)&&by('dalle').pu===38&&by('dalle').u==='m²');
 chk('poteau : volume 9,99 m³ repris, prix laissé vide (à saisir, jamais inventé)',near(by('poteaux').q,9.99)&&by('poteaux').pu===''&&by('poteaux').u==='m³');
 chk('alerte « postes sans prix » présente',R.warnings.some(w=>/sans prix/.test(w)));
 chk('chaque ligne a une clé stable « autoifc:… » (renvoi sans doublon dans le métré)',R.lines.every(l=>/^autoifc:ref:/.test(l.src))&&new Set(R.lines.map(l=>l.src)).size===R.lines.length);
 chk('désignation : niveau et nom de la maquette indiqués',/Rez-de-chaussée/.test(by('dalle').d)&&/maquette IFC ref/.test(by('dalle').d));
 // --- villa : portes / fenêtres comptées, niveaux séparés, ordre chantier
 const V=A.ifcLignes(await rd('villa.ifc'),'villa'),pt=V.lines.filter(l=>l.k==='portes'),fe=V.lines.filter(l=>l.k==='fenetres');
 chk('villa : portes et fenêtres comptées par niveau (4 + 4 portes, 7 + 7 fenêtres)',pt.length===2&&pt.every(l=>l.q===4)&&fe.length===2&&fe.every(l=>l.q===7));
 chk('portes : 0,90 × 2,10 m × 75 $/m² = 141,75 $ ; fenêtres : 1,20 × 1,20 m × 95 $/m² = 136,80 $',pt[0].pu===141.75&&fe[0].pu===136.8);
 chk('hypothèse de dimensions signalée sur les portes et fenêtres',pt[0].hyp&&fe[0].hyp&&/supposé/.test(pt[0].d));
 const ks=V.lines.map(l=>l.k),iR=ks.indexOf('poteaux'),iM=ks.indexOf('murs-m2');
 chk('ordre : par niveau puis poteaux → poutres → dalles → murs → portes → fenêtres',iR<iM&&ks.indexOf('poutres')<ks.indexOf('dalle')&&ks.indexOf('dalle')<iM&&ks.indexOf('portes')<ks.indexOf('fenetres'));
 // --- bâtiment 3 niveaux (export Excellencia) : béton armé seulement
 const B=A.ifcLignes(await rd('batiment-3-niveaux.ifc'),'bat');
 chk('bâtiment 3 niveaux : 3 lignes poteaux (RDC, Étage 1, Terrasse) sans prix, volumes cohérents',B.lines.filter(l=>l.k==='poteaux').length===3&&near(B.lines.filter(l=>l.k==='poteaux').reduce((s,l)=>s+l.q,0),2.43+1.692+1.08,0.01));
 // --- prix personnalisés
 const R2=A.ifcLignes(Q,'ref',{maco:20,dalle:50});
 chk('prix personnalisés pris en compte (maçonnerie 20, dalle 50)',R2.lines.find(l=>l.k==='murs-m2').pu===20&&R2.lines.find(l=>l.k==='dalle').pu===50);
 // --- cas limites
 const E=A.ifcLignes([],'vide');chk('maquette vide : aucune ligne et alerte explicite',E.lines.length===0&&E.warnings.some(w=>/rien à chiffrer/i.test(w)));
 const U=A.ifcLignes([{cat:'Mobilier',storey:'RDC',vol:1,aire:1,plan:1,ouvertures:0,src:'géométrie'}],'x');
 chk('catégorie sans règle (Mobilier) : non chiffrée mais signalée',U.lines.length===0&&U.skipped[0].cat==='Mobilier'&&U.warnings.some(w=>/Non chiffrés.*Mobilier/.test(w)));
 const src=fs.readFileSync('tools/test-bim/quantites.ifc','utf8'),Qm=I.quantities(await I.parse(src.replace('.LENGTHUNIT.,.MILLI.','.LENGTHUNIT.,$')));
 chk('unité corrigée automatiquement (mm → m) : alerte et quantités en mètres',A.ifcLignes(Qm,'mm').warnings.some(w=>/unité corrigée/.test(w))&&near(A.ifcLignes(Qm,'mm').lines.find(l=>l.k==='dalle').q,20));
 const Z=A.ifcLignes([{cat:'Dalles',storey:'—',vol:0,aire:0,plan:0,ouvertures:0,src:''}],'z');
 chk('quantité nulle : aucune ligne à 0',Z.lines.length===0);
 const S=A.ifcLignes([{cat:'Dalles',storey:'—',vol:1,aire:2,plan:10,ouvertures:0,src:''}],'s');
 chk('élément sans niveau : pas de « — — » dans la désignation',!/— —/.test(S.lines[0].d)&&!/ — \(/.test(S.lines[0].d));
 // --- plan converti (lignes de l'éditeur de plan)
 const P=A.planLignes([{d:'Murs — longueur totale',u:'ml',q:20,src:'p:murs-ml'},{d:'Maçonnerie',u:'m²',q:50.5,pu:14,pk:'maco',src:'p:murs-m2'},{d:'Charpente chevrons',u:'ml',q:9,info:1,src:'p:cha'},{d:'Vide',u:'u',q:0,src:'p:vide'}]);
 chk('plan : lignes d’information (charpente) et quantités nulles écartées',P.length===2&&!P.some(l=>/Charpente|Vide/.test(l.d)));
 chk('plan : prix de l’éditeur conservé ; poste sans prix laissé vide',P[1].pu===14&&P[0].pu==='');
 console.log('BILAN '+ok+'/'+tot);process.exit(ok===tot?0:1);
})();
