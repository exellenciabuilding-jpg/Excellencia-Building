#!/usr/bin/env node
/* Test des parcours formation + TFL (bac à sable Node, stockage simulé). Usage : node tools/test-liaison-edu.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');let fails=0,passes=0;
const ok=(c,m,d)=>{if(c){passes++;console.log('  OK   '+m)}else{fails++;console.log('  FAIL '+m+(d?' — '+d:''))}};
const J=o=>JSON.stringify(o);
function boot(seed){const mem=Object.assign({},seed);const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
 const w={localStorage:ls,exbStorage:ls,save:(k,v)=>{ls.setItem(k,JSON.stringify(v))},dispatchEvent(){},confirm:()=>true,setInterval:()=>0,setTimeout:f=>{try{f()}catch(e){}return 0}};
 w.window=w;w.globalThis=w;const ctx=vm.createContext(w);vm.runInContext('Event=function(){}',ctx);
 ['exb-liaison.js','exb-liaison-edu.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f}));
 return{w,mem,X:w.EXBLIEN,get:k=>JSON.parse(mem[k]||'[]')}}
const seed=()=>({
 exb_formations:J([{formation_id:'F1',name:'AutoCAD',price:300},{formation_id:'F2',name:'Revit',price:0}]),
 exb_participants:J([{participant_id:'P1',name:'Jean Mbala',phone:'+243 81 111 1111',email:'jean@x.cd',training:'AutoCAD',matricule:'111-111-111',approval_status:'APPROUVE',pay:{form:'total',insc:true}},
   {participant_id:'P2',name:'Marie Lutu',phone:'0822222222',training:'autocad',approval_status:'APPROUVE'},
   {participant_id:'P3',name:'Paul Ngoy',phone:'0833333333',training:'Formation Inconnue'},
   {participant_id:'P4',name:'Paul Ngoy bis',phone:'+243833333333',training:'Revit'}]),
 exb_payments:J([{payment_id:'Y1',participant_id:'P1',amount:100,date:'2026-10-01'},{payment_id:'Y2',participant_id:'P1',amount:50,date:'2026-10-05'},{payment_id:'Y3',participant_id:'PX',amount:20,reference:'R-X'}]),
 exb_receipts:J([{receipt_no:'REC-1',participant:'Jean Mbala',training:'AutoCAD',registration_fee:'50',training_fee:'100'},{receipt_no:'REC-2',participant:'Marie Lutu',training:'AutoCAD',registration_fee:'0',training_fee:'300'},{receipt_no:'REC-3',participant:'Jean Mbala',training:'AutoCAD',registration_fee:'',training_fee:'100'},{receipt_no:'REC-4',participant:'Inconnu Total',training:'AutoCAD',training_fee:'10'}]),
 exb_certificates:J([{cert_no:'EXB-FP-1',holder:'Jean Mbala',training:'AutoCAD',participant_id:'P1',status:'VALIDE'},{cert_no:'EXB-FP-2',holder:'Marie Lutu',training:'AutoCAD',status:'VALIDE'}]),
 exb_trainers:J([{id:'TR-1',name:'Ir Kasa',phone:'0844444444',email:'kasa@x.cd'}]),
 exb_tfl_etudiants:J([{id:'E1',nom:'Jean Mbala',telephone:'081 111 1111',matricule:'111-111-111'},{id:'E2',nom:'Zoé',telephone:'0855555555',matricule:'222-222-222'},{id:'E3',nom:'Zoé bis',telephone:'0866666666',matricule:'222-222-222'}]),
 exb_tfl_encadreurs:J([{id:'C1',nom:'Ir Kasa',telephone:'+243 84 444 4444',max_etudiants:1}]),
 exb_tfl_dossiers:J([{id:'D1',numero:'TFL-2026-0001',etudiant_id:'E1',encadreur_id:'C1',statut:'accepte'},{id:'D2',numero:'TFL-2026-0002',etudiant_id:'E2',encadreur_id:'C1',statut:'accepte'},{id:'D3',numero:'TFL-2026-0003',etudiant_id:'E3',encadreur_id:'CX',statut:'recu'}])});

console.log('\n# Formation — rattachement par identifiant');
let t=boot(seed());const E=t.X.edu;
ok(t.get('exb_participants')[0].formation_id==='F1'&&t.get('exb_participants')[1].formation_id==='F1','participants rattachés à leur formation (casse ignorée)');
ok(!t.get('exb_participants')[2].formation_id,'formation inconnue : aucun rattachement deviné');
ok(t.get('exb_payments').slice(0,2).every(y=>y.formation_id==='F1'),'paiements rattachés à la formation du participant');
const R=t.get('exb_receipts');
ok(R[0].participant_id==='P1'&&R[1].participant_id==='P2','reçus rattachés au bon participant (nom + formation)');
ok(R[2].payment_id==='Y1'&&t.get('exb_payments')[0].receipt_no==='REC-3','reçu REC-3 (100) rapproché du paiement Y1 (100), unique candidat');
ok(!R[0].payment_id&&!R[1].payment_id,'reçus sans candidat unique : aucun rapprochement forcé');
ok(!R[3].participant_id,'reçu d’un inconnu : non rattaché');
ok(t.get('exb_certificates')[1].participant_id==='P2','certificat sans identifiant rattaché au participant (nom + formation)');
ok(t.get('exb_participants')[0].name==='Jean Mbala'&&t.get('exb_receipts')[0].participant==='Jean Mbala','aucun nom ni montant existant modifié');
const b=J([t.get('exb_participants'),t.get('exb_payments'),t.get('exb_receipts')]);E.linkFormation();E.linkTfl();
ok(J([t.get('exb_participants'),t.get('exb_payments'),t.get('exb_receipts')])===b,'idempotent : un 2e passage ne change rien');

console.log('\n# Formation — situation financière et anomalies');
let s=E.situation('P1');ok(s.prix===300&&s.verse===150&&s.solde===150&&s.statut==='moitie','P1 : prix 300 / versé 150 / solde 150 / moitié',J(s));
s=E.situation('P2');ok(s.verse===0&&s.solde===300&&s.statut==='non_paye','P2 : rien versé malgré le reçu REC-2 (aucun versement fictif)',J(s));
const T=E.totals().find(x=>x.formation==='AutoCAD');ok(T&&T.inscrits===2&&T.attendu===600&&T.verse===150&&T.solde===450,'total AutoCAD : 2 inscrits, attendu 600, versé 150, solde 450',J(T));
const A=E.anomaliesFormation().join('\n');
ok(/Y3|R-X/.test(A)&&/introuvable/.test(A),'paiement orphelin signalé');
ok(/REC-2/.test(A)&&/sans aucun paiement/.test(A),'reçu sans paiement enregistré signalé');
ok(/REC-4/.test(A),'reçu à participant non identifié signalé');
ok(/EXB-FP-1.*reste/.test(A)&&/EXB-FP-2/.test(A),'certificats délivrés avec solde impayé signalés');
ok(/Jean Mbala.*payé.*n’atteignent pas/.test(A),'statut manuel « payé » incohérent avec les montants signalé');
ok(/Formation Inconnue/.test(A)&&/Revit.*prix non renseigné/.test(A),'formation absente du catalogue et prix manquant signalés');
ok(/en double possible/.test(A),'participants en double (même téléphone) signalés');
t.get('exb_payments');const yy=t.get('exb_payments');yy.push({payment_id:'Y9',participant_id:'P1',amount:150});t.mem.exb_payments=J(yy);
ok(E.situation('P1').statut==='total'&&E.situation('P1').solde===0,'après un paiement de 150 : P1 soldé');
ok(!E.anomaliesFormation().some(x=>/EXB-FP-1/.test(x)),'plus d’alerte certificat pour P1 une fois soldé');

console.log('\n# TFL — liens étudiant / participant / encadreur / formateur');
ok(t.get('exb_tfl_etudiants')[0].participant_id==='P1'&&t.get('exb_participants')[0].tfl_etudiant_id==='E1','étudiant TFL = participant (même matricule, téléphone écrit différemment)');
ok(!t.get('exb_tfl_etudiants')[1].participant_id,'étudiant sans correspondance : pas de lien deviné');
ok(t.get('exb_tfl_encadreurs')[0].trainer_id==='TR-1','encadreur TFL relié au formateur (même téléphone)');
const U=E.anomaliesTfl().join('\n');
ok(/TFL-2026-0003.*encadreur affecté introuvable/.test(U),'dossier avec encadreur introuvable signalé');
ok(/Ir Kasa.*2 dossiers acceptés pour un maximum de 1/.test(U),'dépassement de charge d’un encadreur signalé');
ok(/222-222-222.*deux étudiants/.test(U),'matricule partagé entre deux étudiants signalé');
const t2=boot(seed());ok(/TFL-2026-0001 accepté.*à payer/.test(t2.X.edu.anomaliesTfl().join('\n')),'dossier TFL accepté avec solde de formation impayé signalé');
ok(t.X.anomalies().length>=10,'toutes ces anomalies remontent dans le panneau direction ('+t.X.anomalies().length+')');
ok(/Formations : attendu/.test(t.X.edu.html())&&/AutoCAD/.test(t.X.edu.html()),'bloc « Formations : attendu / versé » généré pour le panneau direction');
console.log('\nRésultat liaison formation/TFL : '+passes+' contrôles réussis, '+fails+' échec(s).');process.exit(fails?1:0);
