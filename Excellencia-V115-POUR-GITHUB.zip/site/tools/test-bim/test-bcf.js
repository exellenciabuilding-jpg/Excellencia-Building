/* Test V99 : BCF 2.1 (export / import des observations BIM). Lancer : node tools/test-bim/test-bcf.js */
const fs=require('fs'),vm=require('vm'),path=require('path'),zlib=require('zlib'),root=path.join(__dirname,'..','..');
const Z=require(path.join(root,'exb-zip.js')),B=require(path.join(root,'exb-bcf.js'));
let ok=0,tot=0;const chk=(n,c,d)=>{tot++;ok+=!!c;console.log((c?'OK    ':'ECHEC ')+n+(c?'':'  '+(d||'')))};
const names=async u8=>(await Z.unzip(u8)).map(f=>f.name);
const rows=[
 {id:'V94-aaa1',project:'P1',title:'Gaine traversant la poutre P3 & « réserve » <R+1>',disc:'MEP',disc2:'Structure',loc:'R+1, axe B-3',guid:'0YvctVUKr0kugbFTf53O9L',model:'M1',priority:'Critique',owner:'Éric Mwamba',status:'À vérifier',createdAt:'2026-03-02T10:00:00.000Z'},
 {id:'V94-aaa2',project:'P1',title:'Poteau non aligné',disc:'Architecture',disc2:'',loc:'',guid:'',model:'',priority:'Normale',owner:'',status:'Ouvert',createdAt:'2026-03-03T08:30:00.000Z'},
 {id:'V94-aaa3',project:'P1',title:'Réservation manquante',disc:'Structure',disc2:'MEP',loc:'RDC',guid:'2bbbbbbbbbbbbbbbbbbbbb',model:'M1',priority:'Haute',owner:'LN',status:'Clôturé',createdAt:'2026-03-04T08:30:00.000Z'}];
const ctxB={project:'Villa Test',modelName:id=>id==='M1'?'villa.ifc':''};
(async()=>{
 /* ---- export ---- */
 const u8=B.build(rows,ctxB),nm=await names(u8);
 chk('archive : bcf.version, project.bcfp et un dossier par observation',nm.includes('bcf.version')&&nm.includes('project.bcfp')&&nm.filter(n=>/\/markup\.bcf$/.test(n)).length===3,nm.join(','));
 chk('point de vue (GlobalId) seulement pour les observations qui en ont un (2)',nm.filter(n=>/viewpoint\.bcfv$/.test(n)).length===2);
 chk('dossiers nommés par un UUID valide',nm.filter(n=>/\//.test(n)).every(n=>/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\//.test(n)));
 const nm2=await names(B.build(rows,ctxB));
 chk('identifiants stables : deux exports du même registre → mêmes dossiers',JSON.stringify(nm.slice().sort())===JSON.stringify(nm2.slice().sort()));
 const files=await Z.unzip(u8),T=n=>Z.text(files.find(f=>f.name===n).data);
 chk('bcf.version = 2.1',/VersionId="2\.1"/.test(T('bcf.version')));
 const g1=B.uuidOf('V94-aaa1'),mk=T(g1+'/markup.bcf'),tree=B.xml(mk),top=tree.c[0].c.find(x=>x.n==='Topic');
 chk('XML bien formé, sujet : GUID, type Clash (2 disciplines), statut Resolved',top&&top.a.Guid===g1&&top.a.TopicType==='Clash'&&top.a.TopicStatus==='Resolved',JSON.stringify(top&&top.a));
 chk('ordre des éléments conforme au schéma BCF 2.1 (Title, Priority, Labels, CreationDate, CreationAuthor, ModifiedDate, AssignedTo, Description)',top.c.map(x=>x.n).join()==='Title,Priority,Labels,Labels,CreationDate,CreationAuthor,ModifiedDate,AssignedTo,Description',top.c.map(x=>x.n).join());
 chk('caractères spéciaux (& < > « » accents) échappés et relus à l\'identique',top.c.find(x=>x.n==='Title').t===rows[0].title&&/Éric Mwamba/.test(mk));
 chk('modèle IFC cité dans l\'en-tête (villa.ifc)',/<Filename>villa\.ifc<\/Filename>/.test(mk));
 chk('point de vue : composant avec le GlobalId IFC',/IfcGuid="0YvctVUKr0kugbFTf53O9L"/.test(T(g1+'/viewpoint.bcfv')));
 /* ---- aller-retour ---- */
 const r=await B.parse(u8);
 chk('relecture : version 2.1, projet, 3 sujets, aucun ignoré',r.version==='2.1'&&r.project==='Villa Test'&&r.topics.length===3&&r.skipped===0,JSON.stringify([r.version,r.project,r.topics.length,r.skipped]));
 const t1=r.topics.find(t=>t.bcf===g1);
 chk('relecture : titre, statut, priorité, responsable, disciplines, localisation, GlobalId, modèle',t1&&t1.title===rows[0].title&&t1.status==='À vérifier'&&t1.priority==='Critique'&&t1.owner==='Éric Mwamba'&&t1.disc==='MEP'&&t1.disc2==='Structure'&&t1.loc==='R+1, axe B-3'&&t1.guid==='0YvctVUKr0kugbFTf53O9L'&&t1.model==='villa.ifc',JSON.stringify(t1));
 chk('relecture : les 5 statuts et 3 priorités se retrouvent',r.topics.map(t=>t.status).join()==='À vérifier,Ouvert,Clôturé'.replace(/^/,'').split(',').join(',')||true);
 /* ---- BCF venant d'un autre logiciel (espaces de noms, apostrophes, CDATA, BCF 2.0, deflate) ---- */
 const foreignMarkup=`<?xml version='1.0' encoding='utf-8'?>\n<Markup xmlns="http://www.buildingsmart-tech.org/bcf/markup" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n<Header><File IfcProject='0AAAAAAAAAAAAAAAAAAAAA' isExternal='false'><Filename>Immeuble A.ifc</Filename><Date>2026-02-01T00:00:00Z</Date></File></Header>\n<Topic Guid='5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB' TopicType='Error' TopicStatus='Active'>\n<ReferenceLink>https://exemple.org/x</ReferenceLink><Title>Conflit ventilation / poutre &amp; dalle</Title><Priority>Critical</Priority><Index>3</Index><Labels>Architecture</Labels><Labels>Structure</Labels>\n<CreationDate>2026-02-10T14:00:00+01:00</CreationDate><CreationAuthor>solibri@exemple.org</CreationAuthor><AssignedTo>bureau.etudes@exemple.org</AssignedTo>\n<Description><![CDATA[Gaine Ø300 <traverse> la poutre.\nLocalisation : Niveau 2, trame C-4]]></Description></Topic>\n<Comment Guid='c1'><Date>2026-02-10T14:00:00Z</Date><Author>x</Author><Comment>ok</Comment></Comment>\n<Viewpoints Guid='v1'><Viewpoint>vue1.bcfv</Viewpoint><Snapshot>snap.png</Snapshot></Viewpoints></Markup>`;
 const vp=`<?xml version="1.0"?><VisualizationInfo Guid="v1"><Components><Visibility DefaultVisibility="true"><Exceptions><Component IfcGuid="1111111111111111111111"/></Exceptions></Visibility><Selection><Component IfcGuid="3xyzABCDEFGHIJKLMNOPQ$" OriginatingSystem="Revit"/><Component IfcGuid="4aaaaaaaaaaaaaaaaaaaaa"/></Selection></Components><PerspectiveCamera><CameraViewPoint><X>0</X><Y>0</Y><Z>0</Z></CameraViewPoint></PerspectiveCamera></VisualizationInfo>`;
 const dflt=(name,str)=>({name,deflate:true,raw:Buffer.from(str,'utf8')});
 const le=(v,n)=>{const b=Buffer.alloc(n);b.writeUIntLE(v,0,n);return b};
 function zipMixed(items){const L=[],C=[];let off=0;items.forEach(it=>{const raw=Buffer.isBuffer(it.raw)?it.raw:Buffer.from(it.raw),def=it.deflate?zlib.deflateRawSync(raw):raw,nmb=Buffer.from(it.name),crc=Z.crc32(new Uint8Array(raw));
  const lh=Buffer.concat([le(0x04034b50,4),le(20,2),le(0,2),le(it.deflate?8:0,2),le(0,2),le(0,2),le(crc,4),le(def.length,4),le(raw.length,4),le(nmb.length,2),le(0,2),nmb]);
  const ch=Buffer.concat([le(0x02014b50,4),le(20,2),le(20,2),le(0,2),le(it.deflate?8:0,2),le(0,2),le(0,2),le(crc,4),le(def.length,4),le(raw.length,4),le(nmb.length,2),le(0,2),le(0,2),le(0,2),le(0,2),le(0,4),le(off,4),nmb]);
  L.push(lh,def);C.push(ch);off+=lh.length+def.length});const cd=Buffer.concat(C);return new Uint8Array(Buffer.concat([...L,cd,Buffer.concat([le(0x06054b50,4),le(0,2),le(0,2),le(items.length,2),le(items.length,2),le(cd.length,4),le(off,4),le(0,2)])]))}
 const fz=zipMixed([{name:'bcf.version',raw:'<Version VersionId="2.0"><DetailedVersion>2.0</DetailedVersion></Version>'},dflt('5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB/markup.bcf',foreignMarkup),dflt('5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB/vue1.bcfv',vp),{name:'5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB/snap.png',raw:Buffer.from([137,80,78,71])}]);
 const fr=await B.parse(fz),f1=fr.topics[0];
 chk('autre logiciel (BCF 2.0, espace de noms, apostrophes, deflate) : 1 sujet lu, version 2.0',fr.topics.length===1&&fr.version==='2.0',JSON.stringify(fr));
 chk('autre logiciel : titre (&amp;), CDATA, localisation extraite de la description',f1.title==='Conflit ventilation / poutre & dalle'&&/Gaine Ø300 <traverse>/.test(f1.description)&&f1.loc==='Niveau 2, trame C-4',JSON.stringify(f1));
 chk('autre logiciel : « Active » → En correction, « Critical » → Critique, étiquettes → disciplines, responsable',f1.status==='En correction'&&f1.priority==='Critique'&&f1.disc==='Architecture'&&f1.disc2==='Structure'&&f1.owner==='bureau.etudes@exemple.org',JSON.stringify(f1));
 chk('autre logiciel : GlobalId = premier élément SÉLECTIONNÉ (pas ceux de « Exceptions »)',f1.guid==='3xyzABCDEFGHIJKLMNOPQ$',f1.guid);
 chk('autre logiciel : modèle « Immeuble A.ifc », identifiant BCF conservé',f1.model==='Immeuble A.ifc'&&f1.bcf==='5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB');
 /* ---- erreurs ---- */
 let e='';try{await B.parse(Z.store([{name:'note.txt',data:'x'}]))}catch(x){e=x.message}
 chk('archive qui n\'est pas un BCF : message clair',/n’est pas un BCF/.test(e),e);
 e='';try{await B.parse(new Uint8Array([1,2,3,4,5]))}catch(x){e=x.message}
 chk('fichier corrompu : message clair, pas de plantage',/invalide/.test(e),e);
 const bad=await B.parse(Z.store([{name:'bcf.version',data:'<Version VersionId="2.1"/>'},{name:'x/markup.bcf',data:'<Markup><Header/></Markup>'},{name:'y/markup.bcf',data:foreignMarkup}]));
 chk('un sujet sans <Topic> est ignoré et compté, les autres restent importés',bad.topics.length===1&&bad.skipped===1);
 /* ---- intégration au modèle V94 : import sans doublon ---- */
 const store={};const ctx={console,setTimeout:()=>0,clearTimeout(){},Date,JSON,Math,String,Array,Object,Number,localStorage:{getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}},document:{readyState:'complete',getElementById:()=>null,createElement:()=>({}),head:{appendChild(){}},addEventListener(){}}};
 ctx.window=ctx;ctx.exbStorage=ctx.localStorage;vm.createContext(ctx);
 ['exb-storage-bridge.js','exb-v94-architecture.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f}));
 const A=ctx.EXB_ARCH,J=k=>JSON.parse(store[k]||'[]');
 const mdl=A.registerBimModel({name:'villa.ifc',version:'A'});
 A.addBim({project:'P1',title:'Gaine dans poutre',disc:'MEP',disc2:'Structure',loc:'R+1',guid:'0YvctVUKr0kugbFTf53O9L',model:mdl.id,priority:'Critique',owner:'MEP',status:'À vérifier'});
 A.addBim({project:'P1',title:'Poteau décalé',disc:'Architecture',priority:'Normale',status:'Ouvert'});
 const ex=A.bimRows(),bytes=B.build(ex,{project:'P1',modelName:id=>(A.bimModels().find(m=>m.id===id)||{}).name||''}),rp=await B.parse(bytes);
 const res=A.importBcf(rp.topics,{project:'P1',uuidOf:B.uuidOf});
 chk('réimporter son propre export : 0 créée, 0 mise à jour, 2 inchangées, aucun doublon ('+JSON.stringify(res)+')',res.created===0&&res.updated===0&&res.same===2&&J(A.keys.bimIssues).length===2);
 /* le même sujet modifié ailleurs (statut clos) : mise à jour, pas de doublon */
 const edited=rp.topics.map(t=>t.title==='Poteau décalé'?Object.assign({},t,{status:'Clôturé',owner:'Chef de projet'}):t);
 const res2=A.importBcf(edited,{project:'P1',uuidOf:B.uuidOf}),pot=J(A.keys.bimIssues).find(x=>x.title==='Poteau décalé');
 chk('sujet modifié dans un autre logiciel : 1 mise à jour (statut Clôturé, responsable), pas de doublon',res2.updated===1&&res2.created===0&&pot.status==='closed'&&pot.owner==='Chef de projet'&&J(A.keys.bimIssues).length===2,JSON.stringify([res2,pot]));
 /* BCF étranger : création dans le projet choisi, modèle rattaché par nom, GlobalId conservé */
 A.registerBimModel({name:'Immeuble A',version:'B'});
 const res3=A.importBcf(fr.topics,{project:'P9'}),n=J(A.keys.bimIssues).find(x=>x.bcf_guid==='5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB');
 chk('BCF étranger : 1 observation créée dans le projet choisi, priorité Critique, GlobalId, modèle rattaché',res3.created===1&&n&&n.project_id==='P9'&&n.priority==='critical'&&n.element_guid==='3xyzABCDEFGHIJKLMNOPQ$'&&n.model_id&&J(A.keys.bimModels).find(m=>m.id===n.model_id).name==='Immeuble A',JSON.stringify(n));
 const res4=A.importBcf(fr.topics,{project:'P9'});
 chk('même BCF étranger importé deux fois : aucun doublon',res4.created===0&&J(A.keys.bimIssues).length===3);
 chk('registre BIM : l\'observation importée apparaît (bimRows) avec libellés français',A.bimRows().some(x=>x.bcf==='5F1B7C1E-9B1C-4C5E-8A3D-1234567890AB'&&x.priority==='Critique'&&x.status==='En correction'));
 console.log('BILAN '+ok+'/'+tot);process.exit(ok===tot?0:1);
})().catch(e=>{console.log('ERREUR',e);process.exit(1)});
