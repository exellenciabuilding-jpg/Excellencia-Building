# Test navigateur : mesure de distances en 3D (lecteur IFC). Depuis la racine : python3 tools/test-bim/test-mesure.py
import threading, http.server, socketserver, functools, sys, math
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
txt=open('tools/test-bim/quantites.ifc',encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']); pg=b.new_page(viewport={'width':1100,'height':760}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200])); pg.on('dialog',lambda d:d.accept())
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function("window.EXB_IFC3D&&window.EXB_IFC3D.openText",timeout=15000)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')
    pg.evaluate("t=>window.EXB_IFC3D.openText(t,'Maquette mesure')",txt); pg.wait_for_selector('#ifCv',timeout=15000); pg.wait_for_timeout(1500)
    chk('bouton « Mesurer » présent', pg.query_selector('#ifMes') is not None)
    chk('panneau « Mesures 3D » affiché (titre sans code parasite)', 'Mesures 3D' in pg.inner_text('#ifMeas') and 'U0001' not in pg.inner_text('#ifMeas'))
    # deux sommets visibles et accrochables (le rayon de visée touche bien le sommet)
    pts=pg.evaluate("""()=>{const v=window.EXB_IFC3D_VIEWER,P=v.model.positions,M=v.matrices(),cv=document.getElementById('ifCv'),w=cv.clientWidth,h=cv.clientHeight,out=[];
      v.model.els.filter(e=>!e.hidden0&&e.type!=='IFCOPENINGELEMENT').forEach(e=>{for(let t=0;t<e.count&&out.length<400;t+=3*7){const o=(e.start+t)*3,V=[P[o],P[o+1],P[o+2]];
        const c=[M[0]*V[0]+M[4]*V[1]+M[8]*V[2]+M[12],M[1]*V[0]+M[5]*V[1]+M[9]*V[2]+M[13],M[3]*V[0]+M[7]*V[1]+M[11]*V[2]+M[15]];
        const sx=(c[0]/c[2]*.5+.5)*w,sy=(.5-c[1]/c[2]*.5)*h; if(sx<30||sy<30||sx>w-30||sy>h-30)continue;
        const q=v.pickPoint(sx,sy); if(q&&q.snap&&Math.hypot(q.p[0]-V[0],q.p[1]-V[1],q.p[2]-V[2])<1e-9)out.push({sx,sy,V})}});
      out.sort((a,b)=>Math.hypot(...a.V.map((x,i)=>x-out[0].V[i]))-Math.hypot(...b.V.map((x,i)=>x-out[0].V[i])));return [out[0],out[out.length-1]]}""")
    A,B=pts; dist=math.dist(A['V'],B['V'])
    chk('deux sommets visibles trouvés (%.2f m les sépare)'%dist, dist>1)
    pg.click('#ifMes'); chk('mode mesure activé (consigne affichée)', 'Touchez le point' in pg.inner_text('#ifMeas'))
    box=pg.query_selector('#ifCv').bounding_box()
    def click(pt): pg.mouse.click(box['x']+pt['sx'],box['y']+pt['sy']); pg.wait_for_timeout(250)
    click(A); chk('1er point posé : pas encore de mesure', pg.evaluate("window.EXB_IFC3D_VIEWER.meas.length")==0 and pg.evaluate("!!window.EXB_IFC3D_VIEWER.mp"))
    click(B); m=pg.evaluate("window.EXB_IFC3D_VIEWER.meas")
    chk('2e point : une mesure créée', len(m)==1)
    k=pg.evaluate("window.EXB_IFC3D_VIEWER.measInfo(window.EXB_IFC3D_VIEWER.meas[0])")
    chk('distance 3D exacte (%.3f m attendu %.3f)'%(k['d3'],dist), abs(k['d3']-dist)<1e-6)
    chk('horizontal² + vertical² = 3D²', abs(k['dh']**2+k['dv']**2-k['d3']**2)<1e-9)
    chk('sélection inchangée pendant la mesure', pg.evaluate("window.EXB_IFC3D_VIEWER.selected()")==-1)
    pnl=pg.inner_text('#ifMeas'); chk('panneau : distance, horizontal, vertical, total', ('%.2f'%k['d3']).replace('.',',')+' m' in pnl and 'horiz.' in pnl and 'vert.' in pnl and 'Total' in pnl)
    from PIL import Image; import io
    im=Image.open(io.BytesIO(pg.query_selector('#ifCv').screenshot())).convert('RGB')
    ov=pg.evaluate("(()=>{const c=document.querySelector('#exbIfcUI .cv canvas:nth-of-type(2)');if(!c)return 0;const g=c.getContext('2d'),d=g.getImageData(0,0,c.width,c.height).data;let n=0;for(let i=3;i<d.length;i+=4)if(d[i]>0)n++;return n})()")
    chk('trait et étiquette dessinés sur le modèle (%d pixels)'%ov, ov>200)
    pg.click('#ifMM'); pg.wait_for_timeout(500)
    ex=pg.evaluate("window.EXBMetre.state().extra"); l=[e for e in ex if e['d'].startswith('Mesure 3D 1')]
    chk('envoi au métré : ligne en ml (%.2f)'%(l[0]['q'] if l else -1), bool(l) and l[0]['u']=='ml' and abs(l[0]['q']-round(dist,2))<0.011)
    pg.click('#ifMM'); pg.wait_for_timeout(300); chk('renvoi : pas de doublon', len([e for e in pg.evaluate("window.EXBMetre.state().extra") if e['d'].startswith('Mesure 3D 1')])==1)
    chk('boutons sans code parasite', 'U0001' not in pg.inner_text('#ifMeas'))
    pg.click('#ifMU'); chk('retirer la dernière mesure', pg.evaluate("window.EXB_IFC3D_VIEWER.meas.length")==0)
    click(A); click(B); click(A); click(B); chk('plusieurs mesures : 2', pg.evaluate("window.EXB_IFC3D_VIEWER.meas.length")==2)
    pg.click('#ifMC'); chk('tout effacer', pg.evaluate("window.EXB_IFC3D_VIEWER.meas.length")==0)
    pg.click('#ifMes'); click(A)
    chk('mode mesure désactivé : le clic sélectionne de nouveau un élément', pg.evaluate("window.EXB_IFC3D_VIEWER.selected()")>=0 and pg.evaluate("window.EXB_IFC3D_VIEWER.meas.length")==0)
    chk('aucune erreur JavaScript '+str(errs[:2]), not errs)
    b.close()
print('\n%d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
