// Test des quantités IFC (sans navigateur). Depuis la racine : node tools/test-bim/test-quantites.js
const fs=require('fs'),I=require('../../exb-ifc3d.js');let ok=0,tot=0;
const chk=(n,c)=>{tot++;ok+=!!c;console.log((c?'OK    ':'ECHEC ')+n)};
(async()=>{
 const m=await I.parse(fs.readFileSync('tools/test-bim/quantites.ifc','utf8')),Q=I.quantities(m),by=n=>Q.find(r=>r.name===n);
 const near=(a,b)=>Math.abs(a-b)<0.01;
 chk('mur : volume brut 3 m³ (5 × 0,2 × 3)',by('Mur A')&&near(by('Mur A').volBrut,3));
 chk('mur : ouverture reliée détectée (1)',by('Mur A').ouvertures===1);
 chk('mur : volume net = 3 − 0,42 = 2,58 m³',near(by('Mur A').vol,2.58));
 chk('dalle : volume 4 m³ et surface en plan 20 m²',near(by('Dalle B').vol,4)&&near(by('Dalle B').plan,20));
 chk('mur : longueur 5 m',near(by('Mur A').lg,5));
 chk('poteau : volume déclaré (Qto) 9,99 m³ prioritaire',near(by('Poteau P1').vol,9.99)&&/IFC/.test(by('Poteau P1').src));
 chk('l\'ouverture n\'est pas comptée comme élément',!by('Ouverture porte'));
 const wa=m.els.find(x=>x.name==='Mur A'),wc=m.els.find(x=>x.name==='Mur C');
 chk('découpe réelle : mur A (porte jusqu\'au sol, même épaisseur) découpé',wa.carved===true);
 chk('découpe réelle : mur C (fenêtre plus épaisse que le mur, en hauteur) : volume net 2,84 m³',wc.carved===true&&near(by('Mur C').vol,2.84)&&near(by('Mur C').volBrut,3));
 chk('mur découpé : maillage fermé (le volume géométrique donne le net sans double déduction)',near(by('Mur A').vol,2.58));
 chk('mur découpé : plus de triangles que le bloc plein (12)',wa.count>12*3);
 const S=I.synthese(Q);chk('synthèse par niveau et catégorie',S.length>=3&&S.every(r=>r.storey));
 const c=I.csv(Q);chk('CSV : en-têtes et virgule décimale',/Volume net/.test(c)&&/2,58/.test(c)&&c.split('\r\n').length===Q.length+1);
 // --- unités et export Excel (V99 : valeurs en mm³ affichées comme des m³) ---
 const src=fs.readFileSync('tools/test-bim/quantites.ifc','utf8');
 const Qm=I.quantities(await I.parse(src.replace('.LENGTHUNIT.,.MILLI.','.LENGTHUNIT.,$'))),am=Qm.find(r=>r.name==='Mur A');
 chk('unité mal déclarée (coordonnées en mm, « mètre » annoncé) : volume net 2,58 m³ et non 2 580 000 000',near(am.vol,2.58)&&near(am.volBrut,3)&&/corrigée/.test(am.src));
 const Qd=I.quantities(await I.parse(src.replace('9.99','270000000'))),pd=Qd.find(r=>r.name==='Poteau P1');
 chk('quantité déclarée en mm³ (270 000 000) : ramenée à 0,27 m³',near(pd.vol,0.27)&&/corrigée/.test(pd.src));
 chk('quantité déclarée normale : jamais modifiée (9,99 m³)',near(by('Poteau P1').vol,9.99)&&!/corrigée/.test(by('Poteau P1').src));
 const X=I.xlsx(Q);chk('Excel : fichier .xlsx valide (signature ZIP « PK », feuilles Quantités et Synthèse)',X[0]===0x50&&X[1]===0x4b&&Buffer.from(X).includes('Quantités')&&Buffer.from(X).includes('Synthèse'));
 chk('lignes triées par niveau, catégorie, élément',I.sortRows(Q).map(r=>r.cat+r.name).join()===I.sortRows(Q.slice().reverse()).map(r=>r.cat+r.name).join());
 console.log('BILAN '+ok+'/'+tot);process.exit(ok===tot?0:1);
})();
