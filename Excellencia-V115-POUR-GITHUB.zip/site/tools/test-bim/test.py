# Test navigateur : lecteur IFC 3D (rendu WebGL non vide, sélection, propriétés). Depuis la racine : python3 tools/test-bim/test.py
import threading, http.server, socketserver, functools, sys, io
from playwright.sync_api import sync_playwright
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory='.'); H.log_message=lambda *a:None
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',8767),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
txt=open('tools/test-bim/maquette.ifc',encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']); pg=b.new_page(viewport={'width':1100,'height':760}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8767/index.html'); pg.wait_for_function("window.EXB_IFC3D&&window.EXB_IFC3D.openText",timeout=15000)
    chk('lecteur 3D chargé dans l\'application', True)
    pg.evaluate("t=>window.EXB_IFC3D.openText(t,'Maquette test')",txt); pg.wait_for_selector('#ifCv',timeout=15000); pg.wait_for_timeout(1500)
    shot=pg.screenshot(); open('/tmp/claude-0/ifc3d.png','wb').write(shot) if False else None
    from PIL import Image
    cv=pg.query_selector('#ifCv'); im=Image.open(io.BytesIO(cv.screenshot())).convert('RGB'); cols=set(im.getdata()); chk('rendu 3D non vide (%d couleurs)'%len(cols), len(cols)>6)
    box=cv.bounding_box(); pg.mouse.click(box['x']+box['width']/2, box['y']+box['height']/2); pg.wait_for_timeout(600)
    body=pg.inner_text('body'); chk('niveau « Rez-de-chaussée » listé', 'Rez-de-chaussée' in body)
    chk('éléments Mur A / Dalle B présents', 'Mur A' in body or 'Dalle B' in body or 'Murs' in body)
    pg.evaluate("t=>window.EXB_IFC3D.openText(t,'Quantités')",open('tools/test-bim/quantites.ifc',encoding='utf-8').read()); pg.wait_for_selector('#ifQty',timeout=15000); pg.wait_for_timeout(1200); pg.evaluate("document.getElementById('ifQty').click()"); pg.wait_for_selector('#exbIfcQ table',timeout=5000)
    tx=pg.inner_text('#exbIfcQ'); chk('tableau des quantités affiché (murs, dalles, poteaux)', 'Murs' in tx and 'Dalles' in tx and 'Poteaux' in tx and '5,42' in tx)
    with pg.expect_download() as dl: pg.evaluate("document.getElementById('qCsv').click()")
    chk('export CSV téléchargé', dl.value.suggested_filename.endswith('.csv'))
    with pg.expect_download() as dx: pg.evaluate("document.getElementById('qXlsx').click()")
    xp=dx.value.path(); chk('export Excel (.xlsx) téléchargé et valide (signature ZIP)', dx.value.suggested_filename.endswith('.xlsx') and open(xp,'rb').read(2)==b'PK')
    # chaque élément doit se dessiner seul (régression : seul le 1er élément s'affichait)
    pg.add_style_tag(content='#exbLicLock{display:none!important}')
    pg.evaluate("t=>window.EXB_IFC3D.openText(t,'Quantités')",open('tools/test-bim/quantites.ifc',encoding='utf-8').read()); pg.wait_for_selector('#ifCv',timeout=15000); pg.wait_for_timeout(1500)
    names=pg.evaluate("window.EXB_IFC3D_VIEWER.model.els.filter(e=>!e.hidden0).map(e=>e.name)"); okall=True
    for nm in names:
        pg.evaluate("n=>{const v=window.EXB_IFC3D_VIEWER;v.model.els.forEach((e,i)=>{v.vis[i]=(e.name===n)});v.invalidate()}",nm); pg.wait_for_timeout(500)
        im=Image.open(io.BytesIO(pg.query_selector('#ifCv').screenshot())).convert('RGB'); bg=im.getpixel((2,2))
        cnt=sum(1 for px in im.getdata() if sum(abs(px[i]-bg[i]) for i in range(3))>30)
        if cnt<5000: okall=False; print('   élément non dessiné :',nm,cnt)
    chk('chaque élément visible se dessine seul (%d éléments)'%len(names), okall)
    # envoi vers le métré
    pg.evaluate("document.getElementById('ifQty').click()"); pg.wait_for_selector('#exbIfcQ table',timeout=5000)
    pg.evaluate("document.getElementById('qMet').click()"); pg.wait_for_timeout(800)
    n1=pg.evaluate("window.EXBMetre.state().extra.length"); ex=pg.evaluate("window.EXBMetre.state().extra")
    chk('lignes envoyées dans « Matériaux ajoutés » (%d)'%n1, n1>=3)
    chk('ligne mur : 2,58 m³ avec unité', any(e['d'].startswith('Murs') and e['u']=='m³' and abs(e['q']-5.42)<0.01 for e in ex))
    chk('visionneuse refermée après envoi', pg.query_selector('#exbIfcUI') is None)
    pg.evaluate("window.EXBMetre.state().extra.forEach(e=>{if(e.d.startsWith('Murs'))e.pu=100})")
    pg.evaluate("t=>window.EXB_IFC3D.openText(t,'Quantités')",open('tools/test-bim/quantites.ifc',encoding='utf-8').read()); pg.wait_for_selector('#ifQty',timeout=15000); pg.wait_for_timeout(1000)
    pg.evaluate("document.getElementById('ifQty').click()"); pg.wait_for_selector('#exbIfcQ table',timeout=5000); pg.evaluate("document.getElementById('qMet').click()"); pg.wait_for_timeout(600)
    ex2=pg.evaluate("window.EXBMetre.state().extra")
    chk('renvoi : pas de doublon (%d lignes)'%len(ex2), len(ex2)==n1)
    chk('renvoi : prix unitaire déjà saisi conservé', any(e['d'].startswith('Murs') and e['pu']==100 for e in ex2))
    chk('total devis tient compte des lignes envoyées (542 $ = 5,42 × 100)', abs(pg.evaluate("window.EXBMetre.totals().xs")-542)<0.5)
    # volumes exacts quelle que soit l'altitude et la forme (villa R+1 : dalles de 19,8 / 16 / 18,23 / 3,2 m³)
    pg.evaluate("t=>window.EXB_IFC3D.openText(t,'Villa')",open('tools/test-bim/villa.ifc',encoding='utf-8').read()); pg.wait_for_selector('#ifCv',timeout=15000); pg.wait_for_timeout(800)
    vols=pg.evaluate("Object.fromEntries(window.EXB_IFC3D.quantities(window.EXB_IFC3D_VIEWER.model).filter(r=>r.cat==='Dalles').map(r=>[r.name,r.vol]))")
    chk('volume des dalles juste (toiture 19,80 m³, plancher 16,00 m³, terre-plein 18,23 m³)', abs(vols['Dalle de toiture']-19.8)<0.05 and abs(vols['Plancher haut RDC']-16)<0.05 and abs(vols['Dalle sur terre-plein']-18.232)<0.05)
    chk('aucune erreur JavaScript', not errs)
    if errs: print(errs[:3])
    b.close()
print('BILAN %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
