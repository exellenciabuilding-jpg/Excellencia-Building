# Test navigateur : boutons BCF du registre « BIM / Issues » (export, réimport sans doublon, import d'un BCF étranger). Depuis la racine : python3 tools/test-bim/test-bcf-ui.py
import threading, http.server, socketserver, functools, io, zipfile, sys
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c,info=''):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n+((' -> '+str(info)) if (info and not c) else ''))
def foreign():
    m="""<?xml version="1.0" encoding="UTF-8"?><Markup xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><Header><File><Filename>Immeuble.ifc</Filename></File></Header><Topic Guid="7f3a2c10-1111-4222-8333-444455556666" TopicType="Issue" TopicStatus="Open"><Title>Clash gaine / poutre niveau 3</Title><Priority>High</Priority><Labels>MEP</Labels><CreationDate>2026-05-01T09:00:00Z</CreationDate><CreationAuthor>a@b.c</CreationAuthor><Description>Gaine dans la poutre.
Localisation : N3 trame B-2</Description></Topic><Viewpoints Guid="v"><Viewpoint>v.bcfv</Viewpoint></Viewpoints></Markup>"""
    vp='<VisualizationInfo Guid="v"><Components><Selection><Component IfcGuid="0YvctVUKr0kugbFTf53O9L"/></Selection></Components></VisualizationInfo>'
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('bcf.version','<Version VersionId="2.1"><DetailedVersion>2.1</DetailedVersion></Version>'); z.writestr('7f3a2c10-1111-4222-8333-444455556666/markup.bcf',m); z.writestr('7f3a2c10-1111-4222-8333-444455556666/v.bcfv',vp)
    return b.getvalue()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800},accept_downloads=True); errs=[]; dialogs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},150)")
    def on_dialog(d):
        dialogs.append((d.type,d.message[:120]))
        d.accept('TestLocal#2026' if d.type=='prompt' else None)
    pg.on('dialog',on_dialog)
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function("window.EXB_BCF&&window.EXB_ZIP&&window.EXB_ARCH&&!!window.exbV68Open",timeout=20000)
    chk('modules BCF et ZIP chargés dans l\'application',True)
    pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(2500)
    pg.evaluate("EXB_ARCH.addBim({project:'',title:'Gaine dans poutre',disc:'MEP',disc2:'Structure',loc:'R+1',guid:'0YvctVUKr0kugbFTf53O9L',priority:'Critique',owner:'MEP',status:'À vérifier'})")
    pg.evaluate("EXB_ARCH.addBim({project:'',title:'Poteau décalé',disc:'Architecture',priority:'Normale',status:'Ouvert'})")
    pg.evaluate("exbV68Open()"); pg.wait_for_selector('#exbV68Body',timeout=5000)
    pg.click("text=🧩 BIM / Issues"); pg.wait_for_selector('#v68BcfOut',timeout=5000)
    body=pg.inner_text('#exbV68Body')
    chk('le registre ne dit plus « le BCF n\'existe pas » et propose export / import',('n’existe pas' not in body) and pg.is_visible('#v68BcfOut') and pg.is_visible('#v68BcfIn'))
    with pg.expect_download() as dl: pg.click('#v68BcfOut')
    path=dl.value.path(); name=dl.value.suggested_filename; z=zipfile.ZipFile(path); nm=z.namelist()
    chk('export : fichier .bcfzip avec bcf.version et 2 dossiers d\'observation',name.endswith('.bcfzip') and 'bcf.version' in nm and len([n for n in nm if n.endswith('markup.bcf')])==2,(name,nm))
    n0=pg.evaluate("EXB_ARCH.bimRows().length")
    with pg.expect_file_chooser() as fc: pg.click('#v68BcfIn')
    fc.value.set_files(path); pg.wait_for_timeout(1200)
    chk('réimport de son propre export : aucun doublon ('+str(n0)+' → '+str(pg.evaluate("EXB_ARCH.bimRows().length"))+')',pg.evaluate("EXB_ARCH.bimRows().length")==n0 and any('Importer 2' in m for t,m in dialogs),dialogs)
    pg.click("text=🧩 BIM / Issues"); pg.wait_for_selector('#v68BcfIn',timeout=5000)
    with pg.expect_file_chooser() as fc: pg.click('#v68BcfIn')
    fc.value.set_files({'name':'solibri.bcfzip','mimeType':'application/octet-stream','buffer':foreign()}); pg.wait_for_timeout(1200)
    rows=pg.evaluate("EXB_ARCH.bimRows()"); r=[x for x in rows if x['title'].startswith('Clash gaine')]
    chk('import d\'un BCF d\'un autre logiciel : observation créée (priorité Haute, GlobalId, localisation)',len(rows)==n0+1 and len(r)==1 and r[0]['priority']=='Haute' and r[0]['guid']=='0YvctVUKr0kugbFTf53O9L' and r[0]['loc']=='N3 trame B-2',r)
    pg.click("text=🧩 BIM / Issues"); pg.wait_for_selector('#v68BcfIn',timeout=5000)
    chk('le registre affiche l\'observation importée',pg.inner_text('#exbV68Body').count('Clash gaine')>=1)
    with pg.expect_file_chooser() as fc: pg.click('#v68BcfIn')
    fc.value.set_files({'name':'faux.bcfzip','mimeType':'application/octet-stream','buffer':b'ceci n\'est pas un zip'}); pg.wait_for_timeout(800)
    chk('fichier invalide : aucune donnée modifiée, pas d\'erreur de page',pg.evaluate("EXB_ARCH.bimRows().length")==n0+1 and not errs,errs)
    print('BILAN %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
