# Test V99 : option « Dégression des charges d'exploitation » du bâtiment. Depuis la racine : python3 tools/test-bim/test-degression.py
import threading, http.server, socketserver, functools, sys
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c,info=''):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n+((' -> '+str(info)) if (info and not c) else ''))
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(f'http://127.0.0.1:{PORT}/calcul-structure/index.html'); pg.wait_for_timeout(2000)
    r=pg.evaluate("""()=>{const run=d=>{const bb=batDef();if(d!==undefined)bb.deg=d;batFit(bb);const r=batCalc(bb),c=r.cols.find(c=>c.i==1&&c.j==1);bb.res=r;const n=batNote(bb);return{Q:c.rows.map(x=>x.Q),nu:r.nu,txtOff:/non appliquée/.test(n),txtOn:/selon le nombre de niveaux supportés/.test(n)}};return{def:run(),on:run(1),off:run(0)}}""")
    chk('par défaut (champ absent) : dégression appliquée, résultats identiques à avant (Q au pied = 104,9 kN)',abs(r['def']['Q'][0]-104.9)<0.1 and r['def']['Q']==r['on']['Q'] and r['def']['nu']==r['on']['nu'],r)
    chk('dégression décochée : charges d\'exploitation cumulées en totalité (19 m² × 1,15 × (2,5 + 1,5 + 1,0) = 109,25 kN au pied)',abs(r['off']['Q'][0]-109.25)<0.05,r['off'])
    chk('dégression décochée : la charge totale ultime augmente',r['off']['nu']>r['on']['nu'])
    chk('note de calcul : le texte suit l\'option',r['on']['txtOn'] and not r['on']['txtOff'] and r['off']['txtOff'] and not r['off']['txtOn'],r)
    src=open('calcul-structure/index.html',encoding='utf-8').read()
    chk('onglet Général : case « Dégression » présente et reliée au bâtiment','id="bdg"' in src and '$("#bdg").onchange' in src)
    chk('aucune erreur de page',not errs,errs)
    print('BILAN %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
