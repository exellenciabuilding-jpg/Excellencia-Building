// Test du lecteur IFC : géométries ajoutées en V99 + fichiers compressés. Depuis la racine : node tools/test-bim/test-lecteur-geometries.js
const zlib=require('zlib');require('../../exb-zip.js');const I=require('../../exb-ifc3d.js');
let ok=0,tot=0;const chk=(n,c,d)=>{tot++;ok+=!!c;console.log((c?'OK    ':'ECHEC ')+n+(c?'':'  '+(d||'')))};
const near=(a,b,tol)=>Math.abs(a-b)<=tol*Math.max(1,Math.abs(b));
/* maquette minimale : un élément (IfcBuildingElementProxy) dont la représentation est donnée */
function ifc(items,extraUnits){const H=`ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('ViewDefinition [CoordinationView]'),'2;1');\nFILE_NAME('t.ifc','2026-01-01T00:00:00',(''),(''),'','','');\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n`;
 return H+`#1=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);\n#2=IFCSIUNIT(*,.AREAUNIT.,$,.SQUARE_METRE.);\n#3=IFCSIUNIT(*,.VOLUMEUNIT.,$,.CUBIC_METRE.);\n${extraUnits||''}#4=IFCUNITASSIGNMENT((#1,#2,#3));\n#5=IFCPROJECT('0YvctVUKr0kugbFTf53O9L',$,'P',$,$,$,$,$,#4);\n#10=IFCCARTESIANPOINT((0.,0.,0.));\n#11=IFCDIRECTION((0.,0.,1.));\n#12=IFCDIRECTION((1.,0.,0.));\n#13=IFCAXIS2PLACEMENT3D(#10,#11,#12);\n#14=IFCLOCALPLACEMENT($,#13);\n#15=IFCBUILDINGSTOREY('1aaaaaaaaaaaaaaaaaaaaa',$,'N0',$,$,#14,$,$,.ELEMENT.,0.);\n#16=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#13,$);\n`+items+`#900=IFCSHAPEREPRESENTATION(#16,'Body','SweptSolid',(#100));\n#901=IFCPRODUCTDEFINITIONSHAPE($,$,(#900));\n#902=IFCBUILDINGELEMENTPROXY('2bbbbbbbbbbbbbbbbbbbbb',$,'Obj',$,$,#14,#901,$,$);\n#903=IFCRELCONTAINEDINSPATIALSTRUCTURE('3ccccccccccccccccccccc',$,$,$,(#902),#15);\nENDSEC;\nEND-ISO-10303-21;\n`}
const rect=(id,x,y)=>`#${id}=IFCRECTANGLEPROFILEDEF(.AREA.,$,$,${x}.,${y}.);\n`;
const geo=async(txt)=>{const m=await I.parse(txt);const el=m.els.find(e=>e.name==='Obj');const Q=I.quantities(m).find(r=>r.name==='Obj');return{m,el,Q,vol:Q&&Q.vol}};
(async()=>{
 /* 1. extrusion conique : tronc de pyramide 2×2 → 1×1, hauteur 3 : V = h/3·(A1+A2+√(A1A2)) = 7 */
 let g=await geo(ifc(rect(20,2,2)+rect(21,1,1)+`#30=IFCEXTRUDEDAREASOLIDTAPERED(#20,#13,#11,3.,#21);\n#100=IFCEXTRUDEDAREASOLIDTAPERED(#20,#13,#11,3.,#21);\n`.replace('#30=IFCEXTRUDEDAREASOLIDTAPERED(#20,#13,#11,3.,#21);\n','')));
 chk('extrusion conique : volume 7,00 m³ (tronc 2×2 → 1×1, h = 3)',g.el&&near(g.vol,7,0.005),g.vol);
 chk('extrusion conique : non signalée comme non prise en charge',!Object.keys(g.m.warn.unsupported).length);
 /* 2. révolution complète : rectangle x∈[1,2], z∈[0,3] autour de Z : V = π(2²−1²)·3 = 28,274 */
 const prof=`#20=IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,$,#22);\n#22=IFCPOLYLINE((#23,#24,#25,#26,#23));\n#23=IFCCARTESIANPOINT((1.,0.));\n#24=IFCCARTESIANPOINT((2.,0.));\n#25=IFCCARTESIANPOINT((2.,3.));\n#26=IFCCARTESIANPOINT((1.,3.));\n`;
 /* profil dans le plan XY local ; l'axe est la droite y-direction → on place le profil (x,y) et on tourne autour de l'axe Y du profil */
 const axY=``;
 const rv=(ang)=>prof+`#31=IFCCARTESIANPOINT((0.,0.,0.));\n#32=IFCDIRECTION((0.,1.,0.));\n#29=IFCAXIS1PLACEMENT(#31,#32);\n#100=IFCREVOLVEDAREASOLID(#20,#13,#29,${ang});\n`;
 g=await geo(ifc(rv('6.283185307179586')));
 chk('révolution complète : volume ≈ 28,27 m³ (anneau 1–2 m, h = 3)',g.el&&near(g.vol,28.274,0.01),g.vol);
 g=await geo(ifc(rv('3.141592653589793')));
 chk('révolution demi-tour : volume ≈ 14,14 m³ (fermé par deux faces)',g.el&&near(g.vol,14.137,0.01),g.vol);
 g=await geo(ifc(rv('180.'),`#7=IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.);\n#8=IFCMEASUREWITHUNIT(IFCPLANEANGLEMEASURE(0.017453292519943295),#7);\n#9=IFCCONVERSIONBASEDUNIT(#6,.PLANEANGLEUNIT.,'DEGREE',#8);\n#6=IFCDIMENSIONALEXPONENTS(0,0,0,0,0,0,0);\n`));
 chk('révolution : angle déclaré en degrés (180°) correctement converti',g.el&&near(g.vol,14.137,0.01),g.vol);
 /* 3. disque balayé : barre droite L = 4, r = 0,1 → π·0,01·4 = 0,1257 (polygone à 16 côtés : −1,3 %) */
 const sd=(poly,r)=>`${poly}#100=IFCSWEPTDISKSOLID(#40,${r},$,$,$);\n`;
 g=await geo(ifc(sd(`#41=IFCCARTESIANPOINT((0.,0.,0.));\n#42=IFCCARTESIANPOINT((4.,0.,0.));\n#40=IFCPOLYLINE((#41,#42));\n`,'0.1')));
 chk('disque balayé : barre droite, volume ≈ 0,1257 m³ (π·0,1²·4)',g.el&&near(g.vol,Math.PI*0.01*4,0.03),g.vol);
 g=await geo(ifc(sd(`#41=IFCCARTESIANPOINT((0.,0.,0.));\n#42=IFCCARTESIANPOINT((2.,0.,0.));\n#43=IFCCARTESIANPOINT((2.,0.,2.));\n#40=IFCPOLYLINE((#41,#42,#43));\n`,'0.05')));
 chk('disque balayé : barre coudée (L, 2 + 2 m), volume ≈ π·0,05²·4',g.el&&near(g.vol,Math.PI*0.0025*4,0.06),g.vol);
 /* polycourbe 3D avec arc (étrier) */
 g=await geo(ifc(sd(`#41=IFCCARTESIANPOINTLIST3D(((0.,0.,0.),(1.,0.,0.),(1.5,0.,0.5),(1.5,0.,1.5)));\n#40=IFCINDEXEDPOLYCURVE(#41,(IFCLINEINDEX((1,2)),IFCARCINDEX((2,3,4))),$);\n`,'0.01')));
 chk('disque balayé : polycourbe indexée avec arc → volume > 0 et élément dessiné',g.el&&g.vol>0&&g.el.count>0,g.vol);
 /* 4. découpe par demi-espace : bloc 4×1×2, coupé par le plan z = 1 + 0,25·x (garde en dessous) → V = 1·1,5·4 = 6 */
 const nz=1/Math.hypot(0.25,1),nx=-0.25*nz;
 const clip=(flag,poly)=>rect(20,4,1)+`#21=IFCCARTESIANPOINT((0.,0.,1.));\n#22=IFCDIRECTION((${nx},0.,${nz}));\n#23=IFCAXIS2PLACEMENT3D(#21,#22,#12);\n#24=IFCPLANE(#23);\n#25=IFCAXIS2PLACEMENT3D(#10,#11,#12);\n#26=IFCEXTRUDEDAREASOLID(#20,#13,#11,2.);\n`+(poly?`#27=IFCPOLYLINE((#50,#51,#52,#53,#50));\n#50=IFCCARTESIANPOINT((-100.,-100.));\n#51=IFCCARTESIANPOINT((100.,-100.));\n#52=IFCCARTESIANPOINT((100.,100.));\n#53=IFCCARTESIANPOINT((-100.,100.));\n#28=IFCPOLYGONALBOUNDEDHALFSPACE(#24,${flag},#13,#27);\n`:`#28=IFCHALFSPACESOLID(#24,${flag});\n`)+`#100=IFCBOOLEANCLIPPINGRESULT(.DIFFERENCE.,#26,#28);\n`;
 /* le bloc part de (0,0) au centre du profil : on décale le profil pour qu'il couvre x∈[0,4] */
 const fix=t=>t.replace('#13=IFCAXIS2PLACEMENT3D(#10,#11,#12);','#13=IFCAXIS2PLACEMENT3D(#10,#11,#12);\n#19=IFCCARTESIANPOINT((2.,0.5,0.));').replace('#20=IFCRECTANGLEPROFILEDEF(.AREA.,$,$,4.,1.);','#20=IFCRECTANGLEPROFILEDEF(.AREA.,$,#19b,4.,1.);').replace('#19b','#19pos');
 const base=(flag,poly)=>ifc(clip(flag,poly)).replace('#20=IFCRECTANGLEPROFILEDEF(.AREA.,$,$,4.,1.);','#18=IFCCARTESIANPOINT((2.,0.5));\n#19=IFCAXIS2PLACEMENT2D(#18,$);\n#20=IFCRECTANGLEPROFILEDEF(.AREA.,$,#19,4.,1.);');
 g=await geo(base('.F.',false));
 chk('découpe par plan (IfcHalfSpaceSolid, côté matière au-dessus) : volume 6,00 m³',g.el&&near(g.vol,6,0.005),g.vol);
 chk('découpe par plan : comptée comme réalisée (pas « apparaît plein »)',g.m.warn.clip===1&&g.m.warn.bool===0,JSON.stringify(g.m.warn));
 g=await geo(base('.F.',true));
 chk('découpe par plan à contour (IfcPolygonalBoundedHalfSpace englobant) : volume 6,00 m³',g.el&&near(g.vol,6,0.005),g.vol);
 g=await geo(base('.T.',false));
 chk('découpe par plan, indicateur inversé : garde l\'autre côté, volume 2,00 m³',g.el&&near(g.vol,2,0.005),g.vol);
 /* contour trop petit : la découpe n'est pas appliquée, élément plein signalé */
 g=await geo(base('.F.',true).replace(/\(-100\.,-100\.\)/,'(-0.5,-0.5)').replace(/\(100\.,-100\.\)/,'(0.5,-0.5)').replace(/\(100\.,100\.\)/,'(0.5,0.5)').replace(/\(-100\.,100\.\)/,'(-0.5,0.5)'));
 chk('contour de demi-espace trop petit : découpe non appliquée et signalée (bloc plein 8 m³)',g.el&&near(g.vol,8,0.005)&&g.m.warn.bool===1,g.vol+' '+JSON.stringify(g.m.warn));
 /* plan qui ne coupe pas : volume inchangé */
 g=await geo(base('.F.',false).replace('#21=IFCCARTESIANPOINT((0.,0.,1.));','#21=IFCCARTESIANPOINT((0.,0.,50.));'));
 chk('plan qui ne coupe pas l\'élément : volume inchangé (8 m³)',g.el&&near(g.vol,8,0.005),g.vol);
 /* arc exact : quart de cercle de rayon 1 (p1=(1,0,0), p2=(0,7071,0,0,7071), p3=(0,0,1)), r = 0,01 → V = π·0,01²·π/2 */
 g=await geo(ifc(sd(`#41=IFCCARTESIANPOINTLIST3D(((1.,0.,0.),(0.7071067811865476,0.,0.7071067811865476),(0.,0.,1.)));\n#40=IFCINDEXEDPOLYCURVE(#41,(IFCARCINDEX((1,2,3))),$);\n`,'0.01')));
 chk('disque balayé : quart de cercle (arc 3 points) → longueur π/2, volume ≈ 4,93·10⁻⁴ m³',g.el&&near(g.vol,Math.PI*1e-4*Math.PI/2,0.04),g.vol);
 /* cylindre (profil circulaire) coupé par un plan oblique z = 1 + 0,5·x : V = π·r²·1 = π */
 const cyl=ifc(`#20=IFCCIRCLEPROFILEDEF(.AREA.,$,$,1.);\n#26=IFCEXTRUDEDAREASOLID(#20,#13,#11,2.);\n#21=IFCCARTESIANPOINT((0.,0.,1.));\n#22=IFCDIRECTION((-0.4472135954999579,0.,0.8944271909999159));\n#23=IFCAXIS2PLACEMENT3D(#21,#22,#12);\n#24=IFCPLANE(#23);\n#28=IFCHALFSPACESOLID(#24,.F.);\n#100=IFCBOOLEANCLIPPINGRESULT(.DIFFERENCE.,#26,#28);\n`);
 g=await geo(cyl);
 chk('cylindre coupé par un plan oblique : volume ≈ π m³ (coupe elliptique refermée)',g.el&&near(g.vol,Math.PI*0.9886,0.02)&&g.m.warn.clip===1,g.vol+' '+JSON.stringify(g.m.warn));
 /* deux coupes successives (toiture à deux pans) : booléen imbriqué */

 /* 5. archives ZIP : .ifczip stocké et deflate */
 const txt=ifc(rect(20,2,2)+`#100=IFCEXTRUDEDAREASOLID(#20,#13,#11,3.);\n`);
 const Z=require('../../exb-zip.js'),raw=Buffer.from(txt,'utf8');
 const zs=Z.store([{name:'modele.ifc',data:raw},{name:'LISEZ.txt',data:'x'}]);
 let t=await I.ifcTextOf(zs,'m.ifczip');chk('.ifczip (stocké) : IFC retrouvé à l\'identique',t===txt);
 const defl=zlib.deflateRawSync(raw),nm=Buffer.from('a.ifc');
 // archive « deflate » fabriquée à la main
 const le=(v,n)=>{const b=Buffer.alloc(n);b.writeUIntLE(v,0,n);return b};
 const crc=Z.crc32(new Uint8Array(raw));
 const lh=Buffer.concat([le(0x04034b50,4),le(20,2),le(0,2),le(8,2),le(0,2),le(0,2),le(crc,4),le(defl.length,4),le(raw.length,4),le(nm.length,2),le(0,2),nm]);
 const ch=Buffer.concat([le(0x02014b50,4),le(20,2),le(20,2),le(0,2),le(8,2),le(0,2),le(0,2),le(crc,4),le(defl.length,4),le(raw.length,4),le(nm.length,2),le(0,2),le(0,2),le(0,2),le(0,2),le(0,4),le(0,4),nm]);
 const eo=Buffer.concat([le(0x06054b50,4),le(0,2),le(0,2),le(1,2),le(1,2),le(ch.length,4),le(lh.length+defl.length,4),le(0,2)]);
 const zd=new Uint8Array(Buffer.concat([lh,defl,ch,eo]));
 t=await I.ifcTextOf(zd,'m.ifczip');chk('.ifczip (compressé deflate) : IFC retrouvé à l\'identique',t===txt);
 const m2=await I.parse(t);chk('.ifczip : maquette lisible (1 élément)',m2.els.some(e=>e.name==='Obj'));
 let err='';try{await I.ifcTextOf(Z.store([{name:'a.txt',data:'x'}]),'x.zip')}catch(e){err=e.message}
 chk('archive sans .ifc : message clair',/Aucun fichier \.ifc/.test(err),err);
 err='';try{await I.ifcTextOf(new Uint8Array([0x50,0x4b,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]),'x.ifczip')}catch(e){err=e.message}
 chk('archive corrompue : message clair, pas de plantage',/invalide/.test(err),err);
 t=await I.ifcTextOf(raw,'m.ifc');chk('.ifc simple : inchangé',t===txt);
 console.log('BILAN '+ok+'/'+tot);process.exit(ok===tot?0:1);
})().catch(e=>{console.log('ERREUR',e);process.exit(1)});
