/* Test V99 : plans / CDE / BIM = une seule source de vérité (modèle V94). Lancer : node tools/test-bim/test-source-unique.js */
const fs=require('fs'),vm=require('vm'),path=require('path'),root=path.join(__dirname,'..','..');
let ko=0;const chk=(n,c)=>{console.log((c?'OK   ':'FAIL ')+n);if(!c)ko=1};
const store={};const ctx={console,setTimeout:()=>0,clearTimeout(){},Date,JSON,Math,String,Array,Object,Number,
 localStorage:{getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}},
 document:{readyState:'complete',getElementById:()=>null,createElement:()=>({}),head:{appendChild(){}},addEventListener(){}}};
ctx.window=ctx;ctx.exbStorage=ctx.localStorage;vm.createContext(ctx);
['exb-storage-bridge.js','exb-v94-architecture.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f}));
const A=ctx.EXB_ARCH,J=k=>JSON.parse(store[k]||'[]'),set=(k,v)=>{store[k]=JSON.stringify(v)};

/* anciennes données */
const legPlan={id:'PL-1',project_id:'P1',no:'PL-2026-001',title:'Plan coffrage RDC',disc:'Structure',scale:'1/50 — A1',versions:[
 {ind:'A',date:'2026-03-01',desc:'Première émission',by:'BE',sent:[{to:'Client SA',role:'Client',date:'2026-03-02',visa:'Visé avec observations',vdate:'2026-03-05',obs:'Revoir poteau P3'}]},
 {ind:'B',date:'2026-03-10',desc:'Reprise poteau P3',by:'BE',sent:[{to:'Client SA',role:'Client',date:'2026-03-11',visa:'En attente',vdate:'',obs:''},{to:'Bureau de contrôle',role:'Bureau de contrôle',date:'2026-03-11',visa:'Refusé',vdate:'2026-03-12',obs:'Note manquante'}]}]};
set('exb_plans',[legPlan]);
set('exb_cde',[{id:'CDE-1',project:'P1',title:'CCTP lot gros œuvre',disc:'Structure',rev:'B',status:'Review',author:'LN',note:'n',createdAt:'2026-02-01T00:00:00.000Z'},{id:'CDE-2',project:'P1',title:'PV réunion 4',disc:'Général',rev:'A',status:'Superseded',author:'',note:'',createdAt:'2026-02-02T00:00:00.000Z'}]);
set('exb_bim_issues',[{id:'BIM-1',project:'P1',title:'Gaine dans poutre',disc:'MEP',disc2:'Structure',loc:'R+1',priority:'Critique',owner:'MEP',status:'À vérifier',createdAt:'2026-02-03T00:00:00.000Z'}]);
set('exb_plan_files',[{id:'PLF-1',project:'P1',ref:'PL-2026-001',ver:'B',name:'coffrage.pdf',ext:'pdf',date:'2026-03-10'},{id:'PLF-2',project:'P1',ref:'A-200',ver:'A',name:'facade.dxf',ext:'dxf',date:'2026-03-12'}]);
const before={p:store.exb_plans,c:store.exb_cde,b:store.exb_bim_issues};

const r1=A.migrateLegacy();
chk('migration : 1 plan, 2 documents CDE, 1 issue BIM, 2 fichiers rattachés ('+JSON.stringify(r1)+')',r1.plans==1&&r1.cde==2&&r1.bim==1&&r1.files==2&&!r1.error);
const cnt=()=>[A.keys.drawings,A.keys.revisions,A.keys.visas,A.keys.distributions,A.keys.documents,A.keys.bimIssues].map(k=>J(k).length).join(',');
const c1=cnt();const r2=A.migrateLegacy();
chk('migration idempotente (2e passage : rien de plus, aucun doublon)',r2.plans+r2.cde+r2.bim+r2.files==0&&cnt()==c1);
chk('anciens stockages intacts (sauvegarde en lecture seule)',store.exb_plans===before.p&&store.exb_cde===before.c&&store.exb_bim_issues===before.b);

const n=A.plansNested(),p=n.find(x=>x.id==='PL-1');
chk('plan BE relu depuis V94 identique à l\'ancien (indices, diffusions, visas, libellés)',JSON.stringify({no:p.no,title:p.title,disc:p.disc,scale:p.scale,v:p.versions})===JSON.stringify({no:legPlan.no,title:legPlan.title,disc:legPlan.disc,scale:legPlan.scale,v:legPlan.versions}));
const rv=J(A.keys.revisions).filter(x=>x.drawing_id==='PL-1');
chk('V94 : 2 révisions, B = en cours, A = périmée',rv.length==2&&rv.find(x=>x.revision=='B').status=='review'&&rv.find(x=>x.revision=='A').status=='superseded');
chk('V94 : 3 visas (1 refusé en cours) et 3 diffusions',J(A.keys.visas).length==3&&J(A.keys.visas).filter(x=>x.status=='rejected').length==1&&J(A.keys.distributions).length==3);

/* écriture via l'écran Bureau d'études */
p.versions[1].sent[0].visa='Visé sans observation';p.versions[1].sent[0].vdate='2026-03-20';
p.versions.push({ind:'C',date:'2026-03-25',desc:'Indice C',by:'BE',sent:[]});A.savePlanNested(p);
const p2=A.plansNested().find(x=>x.id==='PL-1');
chk('modification (visa + nouvel indice) enregistrée dans V94, sans doublon',p2.versions.length==3&&p2.versions[1].sent[0].visa=='Visé sans observation'&&J(A.keys.drawings).filter(x=>x.id=='PL-1').length==1&&J(A.keys.visas).length==3);
chk('ids de visas conservés d\'un enregistrement à l\'autre',J(A.keys.visas).map(x=>x.id).join()==J(A.keys.visas).map(x=>x.id).join());
chk('KPI V94 cohérents avec l\'écran (visas en attente)',A.kpis().pendingVisas==0&&A.kpis().revisions==4/* 3 de PL-1 + 1 du plan A-200 créé par le fichier V81 */);

/* CDE / BIM (V68) */
const cr=A.cdeRows();
chk('CDE V68 = documents V94 avec libellés d\'origine',cr.length==2&&cr[0].status=='Review'&&cr[1].status=='Superseded'&&cr[0].title.startsWith('CCTP'));
A.addCde({project:'P1',title:'Nouveau doc',disc:'MEP',rev:'A',status:'Approved'});
chk('nouveau document CDE écrit dans V94',J(A.keys.documents).length==3&&J(A.keys.documents)[0].status=='approved'&&A.cdeRows().length==3&&!JSON.parse(store.exb_cde).some(x=>x.title=='Nouveau doc'));
const bi=A.bimRows()[0];
chk('issue BIM V68 relue avec priorité/statut d\'origine',bi.priority=='Critique'&&bi.status=='À vérifier'&&bi.loc=='R+1');
A.addBim({project:'P1',title:'Clash dalle',priority:'Haute',status:'Ouvert'});
chk('nouvelle issue BIM écrite dans V94 (KPI issues ouvertes = 2)',J(A.keys.bimIssues).length==2&&A.kpis().openBimIssues==2);

/* fichiers V81 */
const fl=J('exb_plan_files'),f1=fl.find(x=>x.id=='PLF-1');
chk('fichier V81 rattaché à la révision V94 (PL-2026-001 ind. B)',f1.drawing_id=='PL-1'&&J(A.keys.revisions).find(x=>x.id==f1.revision_id).file_id=='PLF-1');
chk('fichier d\'un plan inconnu : plan + révision V94 créés',J(A.keys.drawings).some(x=>x.code=='A-200')&&J(A.keys.revisions).some(x=>x.file_id=='PLF-2'));
const m3={id:'PLF-3',project:'P1',ref:'A-200',ver:'B',name:'f2.dxf'};A.linkPlanFile(m3);
chk('nouveau fichier : nouvel indice sur le même plan',J(A.keys.revisions).filter(x=>x.drawing_id==m3.drawing_id).length==2&&J(A.keys.drawings).filter(x=>x.code=='A-200').length==1);

A.deletePlan('PL-1');
chk('suppression d\'un plan : révisions, visas et diffusions supprimés',!J(A.keys.drawings).some(x=>x.id=='PL-1')&&!J(A.keys.revisions).some(x=>x.drawing_id=='PL-1')&&J(A.keys.visas).length==0&&J(A.keys.distributions).length==0);
process.exitCode=ko;
