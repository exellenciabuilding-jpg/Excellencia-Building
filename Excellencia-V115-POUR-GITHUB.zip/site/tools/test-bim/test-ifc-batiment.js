// Test : export IFC du bâtiment (ifcBat). Depuis la racine : node tools/test-bim/test-ifc-batiment.js
const fs=require('fs');const s=fs.readFileSync(__dirname+'/../../calcul-structure/index.html','utf8');
const grab=(re)=>{const m=s.match(re);if(!m)throw new Error('absent '+re);return m[0]};
let code=[
 grab(/const letter=i=>[^\n]*\n/).split(',nname')[0]+';',
 grab(/const bOn=[^\n]*\n/),
 grab(/const lvBm=[^\n]*\n/),
 grab(/function bsec\([^\n]*\n/),
 grab(/function ifcGidMaker[\s\S]*?return"'"\+g\+"'"\}\}\n/),
 grab(/function ifcEsc[^\n]*\n/),
 grab(/function ifcBat[\s\S]*?END-ISO-10303-21;\\n"}\n/)
].join('\n');
const matb=(w,h,v)=>Array.from({length:w},()=>Array(h).fill(v));
const niv=(nom,h)=>({nom,h,G:2,Q:2,cols:matb(3,3,1),sl:matb(2,2,1)});
const b={id:'k9x2test',nom:"Villa Étage « test »",xs:[4.5,5],ys:[4,4],niv:[niv("RDC",3),niv("Étage 1",3),niv("Terrasse",3)],bm:.25,bh:.4,hs:.16,fc:25,fe:500};
b.niv[1].sl[1][1]=0; b.niv[2].bo={"X1:0":0};
const cols=[];for(let i=0;i<3;i++)for(let j=0;j<3;j++)cols.push({name:String.fromCharCode(65+i)+(j+1),i,j,rows:[0,1,2].map(k=>({k,a:30-5*k,T:{n:4,phi:12},as:4.5}))});
b.res={cols};
eval(code+';globalThis.ifcBat=ifcBat;');
const out=ifcBat(b);fs.writeFileSync(__dirname+'/batiment-3-niveaux.ifc',out);
const ents=[...out.matchAll(/^#(\d+)=([A-Z0-9]+)\(/gm)];const ids=new Set(ents.map(e=>+e[1]));
const cnt={};ents.forEach(e=>cnt[e[2]]=(cnt[e[2]]||0)+1);let bad=0;for(const m of out.matchAll(/#(\d+)/g)){}
const body=out.split('DATA;')[1];for(const l of body.split('\n')){const self=+(l.match(/^#(\d+)=/)||[])[1];for(const m of l.slice(l.indexOf('=')+1).matchAll(/#(\d+)/g)){if(!ids.has(+m[1])||+m[1]>=self&&self){bad++;if(bad<5)console.log('ref KO',l.slice(0,90))}}}

console.log('entités',ents.length,'refs invalides',bad);let ko=0;const chk=(n,c)=>{if(!c){ko++;console.log('ECHEC',n)}else console.log('OK   ',n)};chk('références STEP valides',bad==0);chk('3 niveaux',cnt['IFCBUILDINGSTOREY']==3);chk('27 poteaux',cnt['IFCCOLUMN']==27);chk('35 poutres (1 retirée)',cnt['IFCBEAM']==35);chk('11 dalles (1 retirée)',cnt['IFCSLAB']==11);chk('volumes extrudés fermés (pas de coque ouverte)',!/IFCOPENSHELL/.test(out)&&cnt['IFCEXTRUDEDAREASOLID']==73);chk('matériau + propriétés + quantités',cnt['IFCMATERIAL']==1&&cnt['IFCPROPERTYSET']>0&&cnt['IFCELEMENTQUANTITY']==73);chk('accents encodés',/\\X2\\00C9\\X0\\/.test(out));for(const k of['IFCBUILDINGSTOREY','IFCCOLUMN','IFCBEAM','IFCSLAB','IFCEXTRUDEDAREASOLID','IFCMATERIAL','IFCPROPERTYSET','IFCELEMENTQUANTITY','IFCRELCONTAINEDINSPATIALSTRUCTURE'])console.log(k,cnt[k]);
console.log(out.match(/Villa[^']*'/)[0],'|',(out.match(/IFCBUILDINGSTOREY\([^\n]*/g)||[]).map(x=>x.split("'")[3]+' '+x.split(',').pop()).join(' ; '));

/* ===== Identifiants stables (GlobalId) ===== */
const gids=o=>[...o.matchAll(/^#\d+=([A-Z0-9]+)\('([0-9A-Za-z_$]{22})'/gm)].map(m=>m[2]);
const out2=ifcBat(b),g1=gids(out),g2=gids(out2);
chk('GlobalId valides (22 car., 1er car. 0-3)',g1.length>300&&g1.every(g=>/^[0-3]/.test(g)));
chk('GlobalId tous uniques',new Set(g1).size==g1.length);
chk('deux exports identiques => mêmes GlobalId',JSON.stringify(g1)==JSON.stringify(g2));
const byRef=o=>{const m={};for(const l of o.split('\n')){const r=l.match(/^#\d+=(IFC(?:COLUMN|BEAM|SLAB))\('([^']+)',\$,'((?:[^']|'')*)'/);if(r)m[r[1]+'|'+r[3]]=r[2]}return m};
const b3=JSON.parse(JSON.stringify(b));b3.niv[0].sl[0][0]=0;b3.niv[1].bo={"X0:1":0};b3.nom='Villa renommée';
const A=byRef(out),B=byRef(ifcBat(b3));let common=0,diff=0;for(const k in A)if(k in B){common++;if(A[k]!==B[k])diff++}
chk('élément modifié/retiré/projet renommé => les autres gardent leur GlobalId ('+common+' communs)',common>60&&diff==0);
const b4=JSON.parse(JSON.stringify(b));b4.id='autre';const g4=gids(ifcBat(b4));
chk('autre bâtiment (autre id) => GlobalId différents',g4.filter((g,i)=>g==g1[i]).length==0);
process.exitCode=ko?1:0;
