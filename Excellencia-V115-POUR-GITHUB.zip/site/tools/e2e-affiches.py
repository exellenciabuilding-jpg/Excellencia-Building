"""Test navigateur des deux affiches (textes effacés de l'image, textes modifiables à l'emplacement d'origine) : python3 tools/e2e-affiches.py"""
import os, sys, http.server, socketserver, threading, functools
from playwright.sync_api import sync_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
fails = 0
def ok(c, m):
    global fails
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails += 1
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=ROOT)); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1100, 'height': 1000}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto(f'http://127.0.0.1:{port}/index.html'); pg.wait_for_timeout(4000)
    pg.evaluate("window.exbLoadImages&&window.exbLoadImages()"); pg.wait_for_timeout(2000)
    pg.evaluate("""(function(){['loginScreen','app','exbLicLock'].forEach(function(i){var x=document.getElementById(i);if(x)x.style.setProperty('display','none','important')});
      [document.getElementById('posterPaper'),document.querySelector('.softwarePosterPaper')].forEach(function(e){e.parentElement.removeChild(e);document.body.appendChild(e)});renderPoster();renderSoftwarePoster()})()""")
    pg.wait_for_timeout(1500)
    ov = "document.querySelectorAll('#posterPaper .pchip,.softwarePosterPaper .sp-overlay')"
    ok(pg.evaluate(f"{ov}.length") >= 50, 'zones de texte présentes sur les deux affiches (%s)' % pg.evaluate(f"{ov}.length"))
    ok(pg.evaluate(f"[...{ov}].every(e=>{{var c=getComputedStyle(e).backgroundColor;return c==='rgba(0, 0, 0, 0)'||c==='transparent'}})"), 'aucune zone de texte n’a de cadre de couleur : seul le texte apparaît sur le fond sans texte')
    ok(pg.evaluate("document.getElementById('spv_session').textContent")=='SESSION DE FORMATION' and pg.evaluate("document.getElementById('spv_footer').textContent").startswith('« Former'), 'les textes d’avant figés dans l’image (session, phrase du bas…) sont des champs')
    ok(pg.evaluate("document.getElementById('pc_tagline_company').textContent").startswith('L') , 'slogan sans tirets en double')
    # personnalisation : textes courts et textes très longs
    pg.evaluate("""(function(){document.getElementById('sp_session').value='FORMATION 2027';document.getElementById('sp_fee').value='35$';
      document.getElementById('sp_address').value='Gombe, Kinshasa';document.getElementById('p_srv1').value='Gros œuvre, fondations spéciales, terrassement et génie civil';
      document.getElementById('p_contact_email').value='direction.technique@excellenciabuilding.com';
      document.getElementById('sp_a_title').value='AutoCAD Architecture Avancé';renderPoster();renderSoftwarePoster()})()""")
    pg.wait_for_timeout(800)
    ok(pg.evaluate("document.getElementById('spv_session').textContent")=='FORMATION 2027' and pg.evaluate("document.getElementById('spv_fee').textContent")=='35$' and pg.evaluate("document.getElementById('spv_address').textContent")=='Gombe, Kinshasa', 'les textes saisis apparaissent à la place des anciens')
    ok(pg.evaluate("document.getElementById('pc_srv1').textContent").startswith('Gros'), 'texte de l’affiche générale modifié')
    over = pg.evaluate(f"[...{ov}].filter(e=>{{var k=['justify-content','align-items'];var s=k.map(x=>[x,e.style.getPropertyValue(x),e.style.getPropertyPriority(x)]);k.forEach(x=>e.style.setProperty(x,'flex-start','important'));var r=e.scrollWidth>e.clientWidth+2||e.scrollHeight>e.clientHeight+2;s.forEach(x=>x[1]?e.style.setProperty(x[0],x[1],x[2]):e.style.removeProperty(x[0]));return r}}).map(e=>e.id)")
    ok(over == [], 'les textes trop longs se réduisent pour rester dans leur zone ' + str(over))
    ok(pg.evaluate("parseFloat(getComputedStyle(document.getElementById('pc_contact_email')).fontSize)") < 21, 'e-mail très long : police réduite automatiquement')
    ok(errs == [], 'aucune erreur JavaScript ' + str(errs))
    b.close()
srv.shutdown()
print('\nÉCHECS : %d' % fails if fails else '\nTout est OK'); sys.exit(1 if fails else 0)
