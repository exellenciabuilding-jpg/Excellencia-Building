# Test navigateur : références automatiques des plans exportés (DXF / IFC) -> module Plans. Depuis la racine : python3 tools/test-refs/test.py
import threading, http.server, socketserver, functools, sys
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
answers=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.goto(f'http://127.0.0.1:{PORT}/calcul-structure/index.html'); pg.wait_for_timeout(1200)
    r=pg.evaluate("""()=>{window.__exbBat='Résidence A';const d=exbInject('batiment_plan_2d.dxf','0\\nSECTION\\n2\\nENTITIES\\n0\\nENDSEC\\n0\\nEOF\\n'),
      i=exbInject('batiment.ifc',"ISO-10303-21;\\nHEADER;\\nFILE_DESCRIPTION(('ViewDefinition [CoordinationView]'),'2;1');\\nENDSEC;"),
      e=exbRef('poteau.ifc'),e2=exbRef('batiment_coffrage.dxf');return {d,i,e,e2,r1:exbRef('batiment_plan_2d.dxf').ref,r2:exbRef('batiment_plan_2d.dxf').ref}}""")
    chk('DXF : référence en commentaire 999 au début', r['d'].startswith('999\nEXB-REF=STR-RESIDENCE-A-PLAN;TITRE=Plan d’exécution 2D;OUVRAGE=Résidence A;DATE='))
    chk('IFC : référence dans FILE_DESCRIPTION', "'ViewDefinition [CoordinationView]','EXB-REF=STR-RESIDENCE-A-BIM;" in r['i'])
    chk('référence stable entre deux exports', r['r1']==r['r2'])
    chk('autres ouvrages : référence par nom', r['e']['ref']=='STR-POTEAU-BIM' and r['e2']['ref']=='STR-RESIDENCE-A-COFF')
    dxf=r['d']; ifc=r['i']
    pg2=b.new_page(viewport={'width':1100,'height':800}); pg2.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg2.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},150)")
    pg2.on('dialog',lambda d:d.accept(answers.pop(0) if (d.type=='prompt' and answers) else (d.default_value if d.type=='prompt' else None)))
    pg2.goto(f'http://127.0.0.1:{PORT}/index.html'); pg2.wait_for_function("window.EXBPLN&&window.EXBS",timeout=20000)
    answers.append('TestLocal#2026'); pg2.fill('#li_user','admin'); pg2.fill('#li_pass','admin'); pg2.click('text=Se connecter'); pg2.wait_for_timeout(2500)
    pg2.evaluate("EXBPLN.open()"); pg2.wait_for_selector('#plFile',timeout=5000)
    pg2.set_input_files('#plFile',{'name':'export1.dxf','mimeType':'application/dxf','buffer':dxf.encode()}); pg2.wait_for_timeout(600)
    chk('Plans : référence remplie automatiquement', pg2.input_value('#plRef')=='STR-RESIDENCE-A-PLAN')
    chk('Plans : note remplie (titre · date)', pg2.input_value('#plNote').startswith("Plan d’exécution 2D"))
    chk('Plans : message « indice suivant A »', 'Indice suivant : A' in pg2.inner_text('#plAuto'))
    pg2.evaluate("EXBPLN.add()"); pg2.wait_for_timeout(900)
    pg2.set_input_files('#plFile',{'name':'export2.dxf','mimeType':'application/dxf','buffer':dxf.encode()}); pg2.wait_for_timeout(600)
    pg2.evaluate("EXBPLN.add()"); pg2.wait_for_timeout(900)
    L=pg2.evaluate("EXBS.get('exb_plan_files').map(x=>[x.ref,x.ver])")
    chk('rechargement : même référence, indice A puis B sans rien saisir', L[-2:]==[['STR-RESIDENCE-A-PLAN','A'],['STR-RESIDENCE-A-PLAN','B']])
    pg2.set_input_files('#plFile',{'name':'Plan Ancien.dxf','mimeType':'application/dxf','buffer':b'0\nSECTION\n2\nENTITIES\n0\nENDSEC\n0\nEOF\n'}); pg2.wait_for_timeout(500)
    chk('fichier sans référence : déduite du nom', pg2.input_value('#plRef')=='PLAN-ANCIEN')
    pg2.evaluate("document.getElementById('plRef').value='';document.getElementById('plRef').dataset.auto=''")
    pg2.evaluate("EXBPLN.add()"); pg2.wait_for_timeout(800)
    chk('ajout possible sans référence saisie', pg2.evaluate("EXBS.get('exb_plan_files').slice(-1)[0].ref")=='PLAN-ANCIEN')
    pg2.set_input_files('#plFile',{'name':'b.ifc','mimeType':'text/plain','buffer':ifc.encode()}); pg2.wait_for_timeout(500)
    chk('IFC : référence reconnue', pg2.input_value('#plRef')=='STR-RESIDENCE-A-BIM')
    chk('aucune erreur JavaScript', not errs); 
    if errs: print(errs)
    b.close()
print('BILAN RÉFÉRENCES %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
