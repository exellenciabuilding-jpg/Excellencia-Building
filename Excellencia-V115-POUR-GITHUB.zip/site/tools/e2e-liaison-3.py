#!/usr/bin/env python3
"""Test navigateur de la tranche 3 : vraies listes en mémoire, vrais écrans Stock / Caisse / Projets, panneau Direction.
Usage : python3 tools/e2e-liaison-3.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m,d=''):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m+('' if c or not d else ' — '+str(d)))
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.on('dialog',lambda d:d.accept())
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(5000)
    ok(not errs,'chargement sans erreur JavaScript',errs[:2])
    ok(pg.evaluate("()=>!!(window.EXBLIEN&&EXBLIEN.ops)"),'extension tranche 3 chargée')
    pg.evaluate("""()=>{
      exbClients.push({id:'CLI-1',full_name:'Marie Kabongo',phone:'0810000001'});save('exb_clients',exbClients);
      exbProjects.push({id:'PRJ1',name:'Villa Gombe',client:'Marie Kabongo',budget:1000},{id:'PRJ2',name:'Tour Lemba',client:''});save('exb_projects',exbProjects);
      exbStock.push({id:'STK1',name:'Ciment',unit:'sac',qty:10,min:2,supplier:''});save('exb_stock',exbStock);
      exbCash.push({id:'CA1',date:'2026-10-20',type:'out',label:'Achat BC-1',amount:300,method:'',ref:'BC-1',category:'Matériaux',project_id:'PRJ1',po_id:'PO1'});save('exb_cash',exbCash);
      exbStockMoves.push({id:'MV0',item:'STK1',type:'in',qty:10,ref:'Tour Lemba',date:'2026-10-19'});save('exb_stock_moves',exbStockMoves);
      formations.push({formation_id:'F1',name:'Formation Test Liaison',price:300,modules:['Bases']});save('exb_formations',formations);
      participants.push({participant_id:'P1',name:'Jean',training:'Formation Test Liaison',approval_status:'APPROUVE'});save('exb_participants',participants);
      schedules.push({schedule_id:'S1',training:'Formation Test Liaison',module:'Bases',date:'2026-10-20',start:'08:00',end:'10:00'});save('exb_schedules',schedules);
      attendance.push({date:'2026-10-20',participant_id:'P1',status:'PRESENT'});save('exb_attendance',attendance);
      EXBLIEN.refresh();
    }""")
    pg.wait_for_timeout(500)
    r=pg.evaluate("()=>({mv:exbStockMoves[0],att:attendance[0],sch:schedules[0],has:!!document.getElementById('exbLienCashPrj'),has2:!!document.getElementById('exbLienMvPrj'),opts:(document.getElementById('exbLienCashPrj')||{options:[]}).options.length})")
    ok(r['mv'].get('project_id')=='PRJ2','mouvement de stock relié au chantier (référence = nom exact)',r['mv'])
    ok(r['att'].get('formation_id')=='F1' and r['att'].get('schedule_id')=='S1','présence reliée à la formation et à la séance',r['att'])
    ok(r['sch'].get('formation_id')=='F1','séance reliée à la formation')
    ok(r['has'] and r['has2'] and r['opts']==3,'sélecteurs « Chantier » ajoutés aux formulaires Caisse et Stock',r)
    # vraie modification d'une dépense depuis l'écran
    pg.evaluate("""()=>{const s=(i,v)=>{document.getElementById(i).value=v};
      s('exb_cash_id','CA1');s('exb_cash_date','2026-10-20');s('exb_cash_type','out');s('exb_cash_label','Achat BC-1 corrigé');s('exb_cash_amount','310');s('exb_cash_method','');s('exb_cash_ref','BC-1');
      saveExbCash();}""")
    c1=pg.evaluate("()=>exbCash.find(x=>x.id==='CA1')")
    ok(c1['label']=='Achat BC-1 corrigé' and c1['amount']==310,'modification appliquée',c1)
    ok(c1.get('project_id')=='PRJ1' and c1.get('category')=='Matériaux' and c1.get('po_id')=='PO1','dépense modifiée : chantier, catégorie et commande conservés',c1)
    # nouvelle dépense avec chantier choisi
    pg.evaluate("""()=>{const s=(i,v)=>{document.getElementById(i).value=v};
      s('exb_cash_id','');s('exb_cash_date','2026-10-21');s('exb_cash_type','out');s('exb_cash_label','Transport');s('exb_cash_amount','80');s('exb_cash_ref','');s('exbLienCashPrj','PRJ2');
      saveExbCash();}""")
    c2=pg.evaluate("()=>exbCash.find(x=>x.label==='Transport')")
    ok(c2 and c2.get('project_id')=='PRJ2','nouvelle dépense : chantier choisi enregistré',c2)
    # nouveau mouvement de stock avec chantier choisi
    pg.evaluate("""()=>{renderExbStock();const s=(i,v)=>{document.getElementById(i).value=v};
      s('exb_mv_item','STK1');s('exb_mv_type','out');s('exb_mv_qty','2');s('exb_mv_ref','');s('exbLienMvPrj','PRJ1');saveExbStockMovement();}""")
    m=pg.evaluate("()=>exbStockMoves[exbStockMoves.length-1]")
    ok(m.get('project_id')=='PRJ1' and m.get('client_id')=='CLI-1','sortie de stock : chantier choisi et client du chantier enregistrés',m)
    # modification d'un projet depuis l'écran : le client reste relié
    pg.evaluate("""()=>{const s=(i,v)=>{const e=document.getElementById(i);if(e)e.value=v};
      s('exb_prj_id','PRJ1');s('exb_prj_name','Villa Gombe');s('exb_prj_client','Marie Kabongo');saveExbProject();}""")
    pj=pg.evaluate("()=>exbProjects.find(x=>x.id==='PRJ1')")
    ok(pj.get('client_id')=='CLI-1','projet modifié : client toujours relié',pj)
    # panneau Direction
    pg.evaluate("()=>EXBLIEN.refresh()"); pg.wait_for_timeout(300)
    h=pg.evaluate("()=>{const e=document.getElementById('exbLienDir');return e?e.innerText:''}")
    ok('Résultat par chantier' in h and 'Villa Gombe' in h,'panneau Direction : « Résultat par chantier » affiché',h[:200])
    ok('Pédagogie par formation' in h and 'Formation Test Liaison' in h,'panneau Direction : « Pédagogie par formation » affiché')
    ok(not errs,'aucune erreur JavaScript pendant tout le parcours',errs[:3])
    b.close()
print('\nRésultat e2e tranche 3 :','tout est OK' if not fails else f'{fails} échec(s)')
raise SystemExit(1 if fails else 0)
