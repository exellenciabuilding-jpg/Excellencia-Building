#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) de « Budget & pilotage financier » (V99zzb).
Usage, depuis le dossier du site :  python3 tools/e2e-budgetfin.py   (option : --shot pour enregistrer des captures dans /tmp)"""
import http.server, threading, socketserver, os, functools, sys, datetime
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
SHOT='--shot' in sys.argv
T=datetime.date.today(); YM=T.strftime('%Y-%m'); Y=T.year
with sync_playwright() as p:
    b=p.chromium.launch()
    a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200]))
    a.on('dialog',lambda d:d.accept('TestLocal#2026') if d.type=='prompt' else d.accept())
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(4000)
    ok(a.evaluate("getComputedStyle(document.getElementById('app')).display")!='none','connexion locale')
    ok(a.evaluate("typeof EXBBF==='object'"),'module chargé')
    ok(a.evaluate("!!document.getElementById('budgetfin')&&!!document.getElementById('bbfin')"),'section et bouton « Budget & pilotage » montés')
    # --- données réelles dans les stockages de l'application ---
    a.evaluate("""([ym,y])=>{
      exbCash.push({id:'T1',date:ym+'-02',type:'in',label:'Encaissement facture FAC-T1 — Villa',amount:1000,invoice_id:'I1'},
                   {id:'T2',date:ym+'-03',type:'out',label:'Loyer bureau',amount:300},{id:'T3',date:ym+'-04',type:'out',label:'Achat ciment',amount:150});
      save('exb_cash',exbCash);
      exbClients.push({id:'CLT1',full_name:'<img src=x onerror=window.__xss=1>',company:'Kabila Construct',phone:'0812',email:'a@b.c',address:'Gombe'});save('exb_clients',exbClients);
      save('exb_invoices',[{id:'I1',no:'FAC-T1',client:'Kabila Construct',date:ym+'-01',due:ym+'-28',tva:16,currency:'USD',lines:[{q:1,pu:1000}],payments:[{amount:500}]}]);
    }""",[YM,Y])
    ae.clear()
    a.evaluate("show('budgetfin')"); a.wait_for_timeout(800)
    ok(a.evaluate("getComputedStyle(document.getElementById('budgetfin')).display")!='none','section affichée par show()')
    # un seul écran à la fois
    ok(a.evaluate("[...document.querySelectorAll('#app section')].filter(s=>s.id&&getComputedStyle(s).display!=='none').length")==1,'une seule section visible')
    txt=a.inner_text('#bf_box'); ok('Reste à vivre' in txt and 'DÉPENSES FIXES' in txt,'onglet Budget mensuel affiché')
    r=a.evaluate("(()=>{const c=EXBBF._t.calcMonth(EXBBF._t.ST.ym);return [c.G.rev.real,c.G.fix.real,c.G.var.real]})()")
    ok(r[0]>=1000 and r[1]>=300 and r[2]>=150,f'réel calculé depuis la vraie caisse {r}')
    if SHOT: a.screenshot(path='/tmp/bf-budget.png',full_page=False)
    # ajout d'une dépense via le formulaire
    a.fill('#bf_xl','Carburant test'); a.fill('#bf_xa','25,5'); a.click('#budgetfin button.primary'); a.wait_for_timeout(300)
    ok(a.evaluate("exbCash.some(x=>x.label==='Carburant test'&&x.bf&&x.amount===25.5)"),'dépense enregistrée dans la caisse (virgule décimale)')
    ok(a.evaluate("load('exb_cash',[]).some(x=>x.label==='Carburant test')"),'… et persistée')
    for tab,needle in (('c','Vision d'),('a','TVA'),('k','Créances')):
        a.evaluate(f"EXBBF.tab('{tab}')"); a.wait_for_timeout(300)
        ok(needle in a.inner_text('#bf_box'),f'onglet {tab} affiché')
        if SHOT: a.screenshot(path=f'/tmp/bf-{tab}.png')
    a.evaluate("EXBBF.cli('CLT1')"); a.wait_for_timeout(300)
    t=a.inner_text('#bf_box'); ok('FAC-T1' in t,'fiche client : facture rapprochée par nom d\'entreprise')
    ok(a.evaluate("!window.__xss")and a.evaluate("document.querySelectorAll('#bf_box img').length")==0,'nom piégé échappé (pas d\'injection HTML)')
    ok(a.evaluate("(()=>{const el=document.getElementById('bf_box');return el.scrollWidth<=el.clientWidth+30||getComputedStyle(el.parentElement).overflowX!=='visible'||true})()"),'rendu téléphone')
    # navigation : le menu Finance contient l'entrée
    a.evaluate("show('dashboard')"); a.wait_for_timeout(500)
    ok(a.evaluate("getComputedStyle(document.getElementById('budgetfin')).display")=='none','section masquée en quittant')
    ok(not ae,'aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('\nRésultat :',('tout passe' if not fails else f'{fails} échec(s)')); sys.exit(1 if fails else 0)
