# Test navigateur : photo + signature sous le nom, nom validé en direct. Depuis la racine : python3 tools/test-formulaires-ux/test.py
import threading, http.server, socketserver, functools, sys
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); P=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':800}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
    for page,nameid,kind in [('inscription.html?type=apprenant','a_name','apprenant'),('formateur.html','f_name','formateur'),('personnel.html','p_name','personnel'),('client.html','c_last','client'),('btp.html','b_name','projet'),('logiciel.html','l_name','logiciel')]:
        pg.goto(f'http://127.0.0.1:{P}/{page}'); pg.wait_for_timeout(1200)
        pos=pg.evaluate("""(id)=>{const n=document.getElementById(id);if(!n)return null;const s=document.getElementById('sigBox'),ph=document.getElementById('photoBox');const f=document.getElementById('f');const all=[...f.querySelectorAll('input,textarea,select,canvas')].filter(e=>e.offsetParent!==null);return {sig:s&&s.offsetParent!==null?all.indexOf(s.querySelector('canvas')):-1,name:all.indexOf(n),total:all.length,after:!!(s&&(s.compareDocumentPosition(n)&Node.DOCUMENT_POSITION_PRECEDING)),sigY:s?Math.round(s.getBoundingClientRect().top+scrollY):-1,sendY:Math.round(document.getElementById('send').getBoundingClientRect().top+scrollY)}}""",nameid)
        chk(f'{kind} : signature juste après le nom (rang {pos["name"]}→{pos["sig"]} sur {pos["total"]} champs)', pos and pos['after'] and 0<pos['sig']-pos['name']<=4 and pos['sigY']<pos['sendY']-150)
    # validation du nom en direct
    pg.goto(f'http://127.0.0.1:{P}/inscription.html?type=apprenant'); pg.wait_for_timeout(1000)
    pg.fill('#a_name','Jean'); pg.dispatch_event('#a_name','blur'); chk('un seul mot : message « nom ET prénom »','prénom' in pg.inner_text('#a_name + .exb-nv'))
    pg.fill('#a_name','Jean 123'); pg.dispatch_event('#a_name','blur'); chk('chiffres refusés', 'lettres' in pg.inner_text('#a_name + .exb-nv'))
    chk('champ invalide : formulaire bloqué', pg.evaluate("!document.getElementById('a_name').checkValidity()"))
    pg.fill('#a_name','Jean Mukendi'); chk('nom valide : ✔ affiché', '✔' in pg.inner_text('#a_name + .exb-nv'))
    chk('nom valide : champ accepté', pg.evaluate("document.getElementById('a_name').checkValidity()"))
    # TFL
    for page,nid in [('tfl-formulaire.html','nom'),('tfl-encadreur-formulaire.html','nom')]:
        pg.goto(f'http://127.0.0.1:{P}/{page}'); pg.wait_for_timeout(1200)
        r=pg.evaluate("""()=>{const n=document.getElementById('nom'),c=document.getElementById('sigCanvas'),on=document.getElementById('online');return {afterName:!!(n.compareDocumentPosition(c)&Node.DOCUMENT_POSITION_FOLLOWING),y:c.getBoundingClientRect().top+scrollY-n.getBoundingClientRect().top-scrollY,btnY:on.getBoundingClientRect().top+scrollY-c.getBoundingClientRect().top-scrollY}}""")
        chk(f'{page} : signature sous le nom (écart {int(r["y"])} px), boutons plus bas', r['afterName'] and r['y']<700 and r['btnY']>150)
        pg.fill('#nom','Jean'); pg.dispatch_event('#nom','blur'); chk(f'{page} : nom validé en direct','prénom' in pg.inner_text('#nom + .exb-nv'))
    chk('aucune erreur JavaScript', not errs)
    if errs: print(errs)
    b.close()
print('BILAN FORMULAIRES %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
