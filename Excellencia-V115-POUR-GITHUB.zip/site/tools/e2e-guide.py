#!/usr/bin/env python3
"""Test navigateur de l'Assistant guidé avec voix (V99zzg / V99zzh). Usage : python3 tools/e2e-guide.py [--shot]
La synthèse vocale est remplacée par un enregistreur : on vérifie ce que le logiciel DIT, pas le son."""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
SHOT='--shot' in sys.argv
with sync_playwright() as p:
    b=p.chromium.launch(); a=b.new_page(viewport={'width':420,'height':850}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:200]))
    a.on('dialog',lambda d:d.accept('TestLocal#2026') if d.type=='prompt' else d.accept())
    a.add_init_script("""setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200);
      window.__said=[];Object.defineProperty(window,'speechSynthesis',{value:{speak:u=>window.__said.push(u.text),cancel(){},getVoices:()=>[]},configurable:true});
      window.SpeechSynthesisUtterance=function(t){this.text=t};""")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(5000)
    ok(a.evaluate("typeof EXBGUIDE==='object'")and a.evaluate("saveExbQuote.__guide===1&&savePayment.__guide===1"),'assistant chargé, gardes posées')
    said=lambda:a.evaluate("window.__said.slice()")
    last=lambda:(said() or [''])[-1]
    def reset(): a.evaluate("window.__said.length=0;document.getElementById('exbGuide')?.remove()")
    # état propre
    a.evaluate("""()=>{exbClients.splice(0);exbQuotes.splice(0);participants.splice(0);payments.splice(0);receipts.splice(0);exbQuoteLines.splice(0);
      document.getElementById('exb_q_client').value='Kabila Construct'}""")
    # 1. devis sans aucun client
    reset(); n0=a.evaluate("exbQuotes.length"); a.evaluate("saveExbQuote()")
    ok('créer la fiche du client dans la section Clients' in last() and 'enregistrer le devis' in last(),'devis sans client : la voix dit de créer le client d\'abord → '+last()[:90])
    ok(a.evaluate("exbQuotes.length")==n0,'… et rien n\'est enregistré')
    ok(a.is_visible('#exbGuide')and 'Clients' in a.inner_text('#exbGuide'),'carte affichée avec bouton vers Clients')
    if SHOT: a.screenshot(path='/tmp/guide-card.png')
    a.click('#exbGuide .go'); a.wait_for_timeout(600)
    ok(a.evaluate("getComputedStyle(document.getElementById('clients')).display")!='none','le bouton ouvre la section Clients')
    # 2. client saisi non enregistré (autre client existe)
    a.evaluate("exbClients.push({id:'C1',full_name:'Marie Mbuyi',company:'Mbuyi SARL',phone:'1'});document.getElementById('exb_q_client').value='Kabila Construct'")
    reset(); a.evaluate("saveExbQuote()")
    ok('fiche de ce client' in last(),'client inconnu : demande de créer sa fiche → '+last()[:80])
    a.evaluate("document.getElementById('exb_q_client').value='Mbuyi SARL'"); reset(); a.evaluate("saveExbQuote()")
    ok('au moins une ligne' in last(),'client connu mais devis vide : demande d\'ajouter une ligne')
    reset(); a.evaluate("exportExbQuotePdf()"); ok('exporter le devis en PDF' in last(),'export PDF du devis bloqué avec le bon libellé')
    a.evaluate("exbQuoteLines.push({designation:'Béton',unit:'m3',qty:2,pu:100})"); reset(); n0=a.evaluate("exbQuotes.length"); a.evaluate("saveExbQuote()")
    ok(a.evaluate("exbQuotes.length")==n0+1,'devis complet : enregistré normalement')
    ok('Devis enregistré' in last() and 'PDF' in last(),'prochaine étape annoncée → '+last()[:80])
    # 3. reçu d'un apprenant
    reset(); a.evaluate("saveReceipt()"); ok('Participants' in last(),'reçu sans participant enregistré : renvoi vers Participants')
    a.evaluate("""()=>{participants.push({participant_id:'P1',name:'KAMANGO Alain',training:'Métré',approval_status:'EN ATTENTE'});
      const s=document.getElementById('receiptParticipantSelect');s.innerHTML='<option value=\"\">—</option><option value=\"P1\">KAMANGO Alain</option>';
      document.getElementById('rtraining').value='Métré';document.getElementById('registration_fee').value='50'}""")
    reset(); a.evaluate("saveReceipt()"); ok('participant dans la liste' in last(),'reçu sans participant choisi : demande de le choisir → '+last()[:80])
    a.evaluate("document.getElementById('receiptParticipantSelect').value='P1'")
    reset(); a.evaluate("saveReceipt()"); ok('approuver' in last(),'participant non approuvé : demande de l\'approuver d\'abord → '+last()[:80])
    a.evaluate("participants[0].approval_status='APPROUVE'")
    reset(); a.evaluate("saveReceipt()"); ok('paiement' in last(),'reçu sans paiement enregistré : demande d\'enregistrer le paiement → '+last()[:90])
    a.evaluate("payments.push({payment_id:'PAY1',participant_id:'P1',participant_name:'KAMANGO Alain',amount:50,date:'2026-10-01'})")
    reset(); n0=a.evaluate("receipts.length"); a.evaluate("saveReceipt()"); ok(a.evaluate("receipts.length")==n0+1,'reçu complet : enregistré')
    a.evaluate("document.getElementById('receipt_no').value=''"); reset(); a.evaluate("exportReceiptPdf()")
    ok('enregistrer le reçu' in last(),'export PDF du reçu sans numéro : « enregistrer le reçu d\'abord » → '+last()[:90])
    # 4. relais des avertissements existants
    reset(); a.evaluate("notify('Choisissez d’abord un chantier.','warn')"); ok('chantier' in last(),'avertissement existant lu à voix haute')
    reset(); a.evaluate("notify('Enregistré avec succès','success')"); ok(not said(),'message de succès non lu')
    # 5. réglages
    a.evaluate("show('settings')"); a.wait_for_timeout(700)
    ok(a.evaluate("!!document.getElementById('exbGuidePanel')"),'panneau « Assistant guidé & voix » dans Paramètres')
    a.evaluate("document.getElementById('eg_strict').click()")
    a.evaluate("document.getElementById('exb_q_client').value='Client sans fiche'"); reset(); n0=a.evaluate("exbQuotes.length"); a.evaluate("saveExbQuote()")
    ok(a.evaluate("exbQuotes.length")==n0+1,'mode strict désactivé : devis pour un client sans fiche accepté')
    a.evaluate("document.getElementById('eg_strict').click();document.getElementById('eg_on').click()")
    a.evaluate("document.getElementById('exb_q_client').value=''"); reset(); a.evaluate("saveExbQuote()")
    ok(not a.is_visible('#exbGuide'),'assistant désactivé : aucune carte, comportement d\'origine')
    a.evaluate("document.getElementById('eg_on').click()")
    ok(a.evaluate("EXBGUIDE.cfg.on===true"),'réactivation')
    # 6. V99zzh : approbations (la fiche doit être complète avant d'attribuer un matricule)
    a.evaluate("""()=>{formations.length=0;formations.push({formation_id:'F1',name:'Métré'});
      participants.push({participant_id:'P2',name:'MUKENDI Paul',phone:'',training:'Métré',approval_status:'EN ATTENTE'})}""")
    reset(); a.evaluate("approveEntity('participant','P2')")
    ok('téléphone' in last() and 'approuver' in last(),'approbation d\'un apprenant sans téléphone : la voix dit de le renseigner → '+last()[:90])
    ok(a.evaluate("participants.find(x=>x.participant_id==='P2').approval_status")=='EN ATTENTE','… et le dossier n\'est PAS approuvé')
    ok('Participants' in a.inner_text('#exbGuide'),'carte avec bouton vers Participants')
    a.evaluate("participants.find(x=>x.participant_id==='P2').phone='0812345678'")
    reset(); a.evaluate("approveEntity('participant','P2')")
    ok(a.evaluate("participants.find(x=>x.participant_id==='P2').approval_status")=='APPROUVE','fiche complète : approbation normale')
    a.evaluate("trainers.push({trainer_id:'T9',name:'Jean KASONGO',phone:'0811111111',specialty:''})")
    reset(); a.evaluate("approveEntity('trainer','T9')")
    ok('spécialité' in last(),'formateur sans spécialité : approbation bloquée → '+last()[:90])
    reset(); a.evaluate("approveEntity('participant','P2',{silent:true})"); ok(not a.is_visible('#exbGuide'),'appel automatique (silent) : jamais bloqué par la carte')
    # 7. TP / TD
    a.evaluate("show('tptd')") if False else None
    reset(); a.evaluate("saveTpTd()"); ok('titre' in last() and 'TP' in last(),'TP/TD sans titre : la voix le demande → '+last()[:90])
    # 8. filet de sécurité : message d'erreur écrit dans une zone de message (sans notification) → lu aussi
    reset(); a.evaluate("(()=>{let e=document.getElementById('pm_local');e.textContent='Le nom du participant est obligatoire.'})()"); a.wait_for_timeout(300)
    ok('obligatoire' in last(),'message d\'erreur d\'un formulaire lu à voix haute → '+last()[:70])
    reset(); a.evaluate('''document.getElementById('pm_local').innerHTML="<span class='valid'>✓ Participant enregistré : P9</span>"'''); a.wait_for_timeout(300)
    ok(not said(),'message de réussite non lu')
    # 9. écran « Calcul de structure » (iframe) : un message d'erreur du module est lu aussi
    a.evaluate("show('calcStructure')"); a.wait_for_timeout(4500)
    reset()
    a.evaluate("""()=>{const d=document.getElementById('exbCalcFrame').contentDocument;const m=d.createElement('div');m.id='exv_m_test';m.className='msg ko';d.body.appendChild(m);
      setTimeout(()=>{m.textContent='Indiquez le nom de l’ingénieur et son numéro d’inscription pour valider.'},100)}""")
    a.wait_for_timeout(900)
    ok('ingénieur' in last(),'calcul de structure : message d\'erreur du module lu à voix haute → '+last()[:80])
    # 10. V99zzi : contrôle au clic générique (champ marqué * obligatoire) — dans tous les écrans
    a.evaluate("""()=>{const c=document.createElement('div');c.className='card';c.id='zzTest';c.style.cssText='position:fixed;top:10px;left:10px;z-index:9;background:#fff';
      c.innerHTML="<label>Nom du chantier *</label><input id='zz1'><label>Note (facultatif)</label><input id='zz2'><button id='zzBtn'>💾 Enregistrer le chantier test</button>";
      document.body.appendChild(c);window.__zzRan=0;document.getElementById('zzBtn').addEventListener('click',()=>{window.__zzRan++})}""")
    reset(); a.click('#zzBtn'); a.wait_for_timeout(200)
    ok('Nom du chantier' in last() and 'enregistrer le chantier test' in last(),'clic sur Enregistrer avec un champ * vide : la voix le réclame → '+last()[:95])
    ok(a.evaluate("window.__zzRan")==0,'… et l\'action n\'a PAS été exécutée')
    ok('Note' not in last(),'champ « facultatif » ignoré')
    a.fill('#zz1','Chantier Gombe'); reset(); a.click('#zzBtn'); a.wait_for_timeout(200)
    ok(a.evaluate("window.__zzRan")==1 and not a.is_visible('#exbGuide'),'champ rempli : l\'action s\'exécute normalement')
    a.evaluate("document.getElementById('zzTest').remove()")
    # 10b. mode « tous les champs » (réglage) : un champ sans étoile est aussi réclamé
    a.evaluate("""()=>{EXBGUIDE.cfg.all=true;const c=document.createElement('div');c.className='card';c.id='zzAll';c.style.cssText='position:fixed;top:10px;left:10px;z-index:9;background:#fff';
      c.innerHTML="<label>Adresse du site</label><input id='zz3'><label>Mention (facultatif)</label><input id='zz4'><button id='zzB2'>Exporter le dossier test</button>";document.body.appendChild(c);window.__zz2=0;document.getElementById('zzB2').addEventListener('click',()=>{window.__zz2++})}""")
    reset(); a.click('#zzB2'); a.wait_for_timeout(200)
    ok('Adresse du site' in last() and a.evaluate("window.__zz2")==0,'mode « tous les champs » : champ sans étoile réclamé, action suspendue → '+last()[:90])
    ok('Mention' not in last(),'mode « tous les champs » : champ facultatif ignoré')
    a.evaluate("EXBGUIDE.cfg.all=false;document.getElementById('zzAll').remove()")
    # 11. visa / cachet / identité avant un document client
    a.evaluate("""()=>{exbClients.splice(0);exbClients.push({id:'C9',full_name:'Mbuyi SARL',company:'Mbuyi SARL',phone:'1'});exbQuoteLines.splice(0);exbQuoteLines.push({designation:'Béton',unit:'m3',qty:1,pu:10});
      document.getElementById('exb_q_client').value='Mbuyi SARL';EXBSign.setAdmin({auto:false})}""")
    reset(); a.evaluate("exportExbQuotePdf()")
    ok('signature' in last() and 'cachet' in last(),'export du devis sans signature/cachet : la voix renvoie vers les Paramètres → '+last()[:100])
    # 12. générateur de licences (écran séparé)
    g=b.new_page(viewport={'width':420,'height':900}); ge=[]
    g.on('pageerror',lambda e:ge.append(str(e)[:200]))
    g.add_init_script("""window.__said=[];Object.defineProperty(window,'speechSynthesis',{value:{speak:u=>window.__said.push(u.text),cancel(){},getVoices:()=>[]},configurable:true});window.SpeechSynthesisUtterance=function(t){this.text=t};""")
    g.goto(f'http://127.0.0.1:{PORT}/exb-generator.html?self=c'); g.wait_for_timeout(2500)
    gl=lambda:(g.evaluate("window.__said.slice()") or [''])[-1]
    ok(g.evaluate("typeof EXBGUIDE==='object'"),'générateur de licences : assistant chargé')
    g.evaluate("window.__said.length=0"); g.click('#go'); g.wait_for_timeout(300)
    ok('nom du client' in gl() and 'générer la licence' in gl(),'licence sans nom de client : la voix le réclame → '+gl()[:100])
    g.fill('#cn','Bâtiment Plus SARL'); g.fill('#cw','+243810000000'); g.fill('#u1',''); g.fill('#u2',''); g.evaluate("window.__said.length=0"); g.click('#go'); g.wait_for_timeout(300)
    ok('adresse du logiciel principal' in gl(),'licence sans liens : la voix réclame les adresses → '+gl()[:110])
    g.fill('#u1','https://principal.netlify.app/'); g.fill('#u2','https://chantier.netlify.app/'); g.evaluate("window.__said.length=0"); g.click('#go'); g.wait_for_timeout(300)
    ok('e-mail' in gl(),'licence sans e-mail du compte : la voix le réclame → '+gl()[:110])
    g.fill('#ae','client@exemple.com'); g.fill('#ap','Secret#2026'); g.fill('#fe','chantier@exemple.com'); g.fill('#fp','CODE2026')
    g.evaluate("window.__said.length=0;document.getElementById('exbGuide')?.remove()"); g.click('#go'); g.wait_for_timeout(400)
    ok(not g.is_visible('#exbGuide') and ('clé privée' in g.inner_text('#msg')),'tout rempli : la génération continue (étape clé privée de l\'écran) → '+g.inner_text('#msg')[:60])
    ok(not ge,'générateur : aucune erreur JavaScript '+str(ge[:2]))
    # 13. note de calcul (iframe) : bouton Imprimer gardé
    a.evaluate("show('calcStructure')"); a.wait_for_timeout(3500); reset()
    a.evaluate("""()=>{const D=document.getElementById('exbCalcFrame').contentDocument;const w=D.createElement('div');w.id='zzDoc';
      w.innerHTML="<input id='exf_moa'><input id='exf_projet'><input id='exf_site'><input id='exf_ing'><input id='exf_verif'><input type='checkbox' id='exf_draft'><button id='dp'>Imprimer</button>";D.body.appendChild(w);window.__dpRan=0;D.getElementById('dp').addEventListener('click',()=>{window.parent.__dpRan++})}""")
    a.evaluate("document.getElementById('exbCalcFrame').contentDocument.getElementById('dp').click()"); a.wait_for_timeout(300)
    ok('client' in last() and 'imprimer la note de calcul' in last(),'note de calcul sans client/projet : impression bloquée à voix haute → '+last()[:100])
    ok(a.evaluate("window.__dpRan||0")==0,'… impression non lancée')
    ok(not ae,'aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('\nRésultat :',('tout passe' if not fails else f'{fails} échec(s)')); sys.exit(1 if fails else 0)
