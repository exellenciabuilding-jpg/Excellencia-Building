-- Test de sécurité des politiques RLS (PostgreSQL 16 + imitation de l'authentification Supabase, voir run.sh).
-- Chaque ligne « T… » affiche  attendu  |  obtenu  |  OK / ECHEC.
\set ON_ERROR_STOP off
\pset tuples_only on
\pset format unaligned
create temp table res(n text, attendu text, obtenu text);
grant all on res to public;
-- Comptes : U1 admin org1, U2 éditeur polyvalent org1, U3 lecteur org1, U4 admin org2, U5 comptable org1
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-000000000001','u1@x'),('00000000-0000-0000-0000-000000000002','u2@x'),('00000000-0000-0000-0000-000000000003','u3@x'),
 ('00000000-0000-0000-0000-000000000004','u4@x'),('00000000-0000-0000-0000-000000000005','u5@x') on conflict do nothing;
select set_config('app.uid','00000000-0000-0000-0000-000000000001',false);
select (creer_organisation('Org1','U1')::jsonb->>'id') as o1 \gset
select set_config('app.uid','00000000-0000-0000-0000-000000000004',false);
select (creer_organisation('Org2','U4')::jsonb->>'id') as o2 \gset
insert into membres(org_id,user_id,role,fonction) values
 (:'o1','00000000-0000-0000-0000-000000000002','editeur','polyvalent'),
 (:'o1','00000000-0000-0000-0000-000000000003','lecteur','polyvalent'),
 (:'o1','00000000-0000-0000-0000-000000000005','editeur','comptable');
-- données de l'org2 (secrètes pour l'org1)
select set_config('app.uid','00000000-0000-0000-0000-000000000004',false);
select enregistrer(:'o2','clients','C2','{"name":"CLIENT SECRET ORG2"}'::jsonb,0) \gset
select set_config('app.uid','00000000-0000-0000-0000-000000000001',false);
select enregistrer(:'o1','clients','C1','{"name":"client org1"}'::jsonb,0) \gset
-- ordre de travail récurrent dans l'org1 (pour le test de la génération automatique)
select enregistrer(:'o1','facility_workorders','WO1','{"status":"terminée","due_date":"2026-01-10","recurrence":"mensuelle","next_generated":false}'::jsonb,0) \gset

-- helper : exécute une requête sous un rôle/utilisateur et renvoie le résultat texte (ou ERREUR:...)
create or replace function essai(p_uid text, p_role text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.uid',coalesce(p_uid,''),false); perform set_config('app.role',p_role,false);
  execute 'set local role '||p_role;
  begin execute p_sql into r; exception when others then r:='ERREUR:'||sqlerrm; end;
  reset role; return coalesce(r,'(null)'); end $$;

insert into res select 'T1 U1 (org1) ne lit aucune fiche de l''org2', '0', essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select count(*)::text from enregistrements where org_id='$q$||:'o2'||$q$'$q$);
insert into res select 'T2 U1 lit ses propres fiches', '2', essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select count(*)::text from enregistrements where org_id='$q$||:'o1'||$q$'$q$);
insert into res select 'T3 U1 ne peut pas écrire dans l''org2 (enregistrer)', 'refus', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o2'||$q$','clients','HACK','{"x":1}'::jsonb,0)::text$q$) ~ 'refus|erreur|ERREUR|droits' then 'refus' else 'ECRIT' end;
insert into res select 'T4 U1 n''a pas pu se déplacer vers l''org2 (update membres.org_id) : reste membre de l''org1 seulement', '1', (select count(*)::text from membres where user_id='00000000-0000-0000-0000-000000000001');
insert into res select 'T5 U2 (éditeur) ne peut pas se promouvoir admin', '0', essai('00000000-0000-0000-0000-000000000002','authenticated',$q$with u as (update membres set role='admin' where user_id='00000000-0000-0000-0000-000000000002' returning 1) select count(*)::text from u$q$);
insert into res select 'T6 U2 ne peut pas s''ajouter lui-même à l''org2 (insert membres)', 'refus', case when essai('00000000-0000-0000-0000-000000000002','authenticated',$q$with u as (insert into membres(org_id,user_id,role) values ('$q$||:'o2'||$q$','00000000-0000-0000-0000-000000000002','admin') returning 1) select count(*)::text from u$q$) like 'ERREUR%' then 'refus' else 'AJOUTE' end;
insert into res select 'T7 U3 (lecteur) ne peut pas écrire', 'refus', case when essai('00000000-0000-0000-0000-000000000003','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','L1','{"x":1}'::jsonb,0)::text$q$) like '%"refus" : true%' then 'refus' else 'ECRIT' end;
insert into res select 'T8 U2 (polyvalent) ne lit pas la paie', 'false', essai('00000000-0000-0000-0000-000000000002','authenticated',$q$select peut('$q$||:'o1'||$q$','paie',false)::text$q$);
insert into res select 'T9 U5 (comptable) lit la paie', 'true', essai('00000000-0000-0000-0000-000000000005','authenticated',$q$select peut('$q$||:'o1'||$q$','paie',false)::text$q$);
insert into res select 'T10 anonyme : aucune fiche lisible', '0', essai(null,'anon','select count(*)::text from enregistrements');
insert into res select 'T11 anonyme : ne peut pas lancer la génération automatique des récurrences', 'refus', case when essai(null,'anon','select exb_generer_recurrences(null)::text') like 'ERREUR%' then 'refus' else 'EXECUTE' end;
insert into res select 'T12 anonyme : ne peut pas appeler enregistrer', 'refus', case when essai(null,'anon',$q$select enregistrer('$q$||:'o1'||$q$','clients','ANON','{"x":1}'::jsonb,0)::text$q$) like '%"ok" : true%' then 'ECRIT' else 'refus' end;
insert into res select 'T13 anonyme : lecture de membres / organisations vide', '0', essai(null,'anon','select ((select count(*) from membres)+(select count(*) from organisations))::text');
insert into res select 'T14 anonyme : peut vérifier un document public (fonction ouverte voulue)', 'ok', case when essai(null,'anon',$q$select exb_doc_verify('ZZZ-000','AAAAAA')::text$q$) like 'ERREUR%' then 'bloque' else 'ok' end;
-- licence : suspension et expiration appliquées à l'écriture
insert into licences_clients(org_id,client_nom,statut,expire_le) values (:'o1','Client Org1','actif', now()+interval '30 days');
insert into res select 'T15 licence active : U1 écrit', 'ok', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','L-OK','{"x":1}'::jsonb,0)::text$q$) like '%"ok" : true%' then 'ok' else 'refus' end;
update licences_clients set statut='suspendu' where org_id=:'o1';
insert into res select 'T16 licence SUSPENDUE : U1 ne peut plus écrire', 'refus', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','L-SUSP','{"x":1}'::jsonb,0)::text$q$) like '%"ok" : true%' then 'ECRIT' else 'refus' end;
insert into res select 'T17 licence suspendue : U1 peut encore LIRE ses données (export possible)', 'lisible', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select count(*)::text from enregistrements where org_id='$q$||:'o1'||$q$'$q$)::int >= 2 then 'lisible' else 'ILLISIBLE' end;
update licences_clients set statut='actif', expire_le=now()-interval '30 days' where org_id=:'o1';
insert into res select 'T18 licence EXPIRÉE depuis 30 jours : écriture refusée', 'refus', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','L-EXP','{"x":1}'::jsonb,0)::text$q$) like '%"ok" : true%' then 'ECRIT' else 'refus' end;
update licences_clients set expire_le=now()-interval '2 days' where org_id=:'o1';
insert into res select 'T19 licence expirée depuis 2 jours (tolérance 7 jours) : écriture encore permise', 'ok', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','L-GRACE','{"x":1}'::jsonb,0)::text$q$) like '%"ok" : true%' then 'ok' else 'refus' end;
update licences_clients set statut='actif', expire_le=now()+interval '30 days' where org_id=:'o1';
insert into res select 'T20 org sans licence enregistrée (ex. essai local) : écriture permise', 'ok', case when essai('00000000-0000-0000-0000-000000000004','authenticated',$q$select enregistrer('$q$||:'o2'||$q$','clients','C2b','{"x":1}'::jsonb,0)::text$q$) like '%"ok" : true%' then 'ok' else 'refus' end;
insert into paiements_declares(type,nom,telephone,matricule,montant,devise,reseau,numero_payeur,reference,doublon)
  select 'apprenant','x','0','m',10,'USD','mpesa','+2438'||lpad(g::text,8,'0'),'REF-'||g,false from generate_series(1,300) g;
insert into res select 'T21 déclaration publique de paiement : plafond global atteint → refusée', 'refus', case when essai(null,'anon',$q$select paiement_declarer('{"type":"apprenant","montant":10,"reference":"NEWREF1","numero":"+243812345678","nom":"t"}'::jsonb)::text$q$) like '%trop_de_demandes%' then 'refus' else 'ACCEPTE' end;
-- 2FA : un compte avec facteur TOTP vérifié exige une session aal2
insert into auth.mfa_factors(user_id,status) values ('00000000-0000-0000-0000-000000000001','verified');
select set_config('app.aal','aal1',false);
insert into res select 'T22 2FA activée, session sans code (aal1) : U1 ne lit plus rien', 'false', essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select peut('$q$||:'o1'||$q$','clients',false)::text$q$);
insert into res select 'T23 2FA activée, aal1 : écriture refusée', 'refus', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','MFA1','{"x":1}'::jsonb,0)::text$q$) like '%"ok": true%' or essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','clients','MFA2','{"x":1}'::jsonb,0)::text$q$) like '%"ok":true%' then 'ok' else 'refus' end;
select set_config('app.aal','aal2',false);
insert into res select 'T24 2FA activée, session aal2 (code saisi) : U1 lit', 'true', essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select peut('$q$||:'o1'||$q$','clients',false)::text$q$);
select set_config('app.aal','aal1',false);
insert into res select 'T25 autre compte SANS 2FA (U5) : aucun changement, aal1 suffit', 'true', essai('00000000-0000-0000-0000-000000000005','authenticated',$q$select peut('$q$||:'o1'||$q$','paie',false)::text$q$);
insert into res select 'T26 anonyme : ne peut pas appeler mfa_ok', 'refus', case when essai(null,'anon','select mfa_ok()::text') like 'ERREUR%' then 'refus' else 'ok' end;
-- plans partagés (stockage) : droits de la collection plans_fichiers, licence, 2FA
alter table storage.objects enable row level security; grant select,insert,update,delete on storage.objects to authenticated, anon;
select set_config('app.aal','aal2',false);
insert into droits_fonction(fonction,collection,lire,ecrire) values ('comptable','plans_fichiers',true,false) on conflict do nothing;
insert into res select 'T27 U1 (admin) envoie un plan dans le dossier de son entreprise', 'ok', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$insert into storage.objects(name,bucket_id) values ('$q$||:'o1'||$q$/plans/P1-a.ifc','exb-plans') returning 'ok'$q$) like 'ERREUR%' then 'refus' else 'ok' end;
insert into res select 'T28 U1 ne peut pas envoyer dans le dossier de l''org2', 'refus', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$insert into storage.objects(name,bucket_id) values ('$q$||:'o2'||$q$/plans/X.ifc','exb-plans') returning 'ok'$q$) like 'ERREUR%' then 'refus' else 'ok' end;
insert into res select 'T29 U4 (org2) ne voit pas les plans de l''org1', '0', essai('00000000-0000-0000-0000-000000000004','authenticated',$q$select count(*)::text from storage.objects where bucket_id='exb-plans'$q$);
insert into res select 'T30 U5 (comptable, lecture seule sur plans) voit le plan mais ne peut pas en envoyer', '1/refus', essai('00000000-0000-0000-0000-000000000005','authenticated',$q$select count(*)::text from storage.objects where bucket_id='exb-plans'$q$)||'/'||case when essai('00000000-0000-0000-0000-000000000005','authenticated',$q$insert into storage.objects(name,bucket_id) values ('$q$||:'o1'||$q$/plans/P2.ifc','exb-plans') returning 'ok'$q$) like 'ERREUR%' then 'refus' else 'ok' end;
insert into res select 'T31 anonyme : aucun plan visible', '0', essai(null,'anon',$q$select count(*)::text from storage.objects where bucket_id='exb-plans'$q$);
update licences_clients set statut='suspendu' where org_id=:'o1';
insert into res select 'T32 licence suspendue : envoi de plan refusé', 'refus', case when essai('00000000-0000-0000-0000-000000000001','authenticated',$q$insert into storage.objects(name,bucket_id) values ('$q$||:'o1'||$q$/plans/P3.ifc','exb-plans') returning 'ok'$q$) like 'ERREUR%' then 'refus' else 'ok' end;
update licences_clients set statut='actif' where org_id=:'o1';
select set_config('app.aal','aal1',false);
insert into res select 'T33 2FA activée sans code (aal1) : U1 ne voit plus les plans', '0', essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select count(*)::text from storage.objects where bucket_id='exb-plans'$q$);
delete from auth.mfa_factors; -- fin des tests 2FA : les tests suivants portent sur les droits, pas sur la 2FA
-- ===== V99zz : droits par fonction sur les tables dédiées sensibles (migration-v99zz-droits-tables-dediees.sql) =====
-- U6 : éditeur « magasinier » (aucun droit sur la paie ni la caisse) ; donnée de test insérée en administrateur de base de données
insert into auth.users(id,email) values ('00000000-0000-0000-0000-000000000006','u6@x') on conflict do nothing;
insert into membres(org_id,user_id,role,fonction) values (:'o1','00000000-0000-0000-0000-000000000006','editeur','magasinier');
insert into erp_paies(org_id,periode_debut,periode_fin,montant_brut) values (:'o1','2026-10-01','2026-10-31',1000);
insert into moyens_paiement(org_id,code,label) values (:'o1','CASH','Espèces');
insert into res select 'T34 U6 (magasinier) ne lit pas la paie par l''API', '0', essai('00000000-0000-0000-0000-000000000006','authenticated',$q$select count(*)::text from erp_paies$q$);
insert into res select 'T35 U2 (polyvalent) ne lit pas la paie par l''API (collection sensible)', '0', essai('00000000-0000-0000-0000-000000000002','authenticated',$q$select count(*)::text from erp_paies$q$);
insert into res select 'T36 U5 (comptable) lit la paie par l''API', '1', essai('00000000-0000-0000-0000-000000000005','authenticated',$q$select count(*)::text from erp_paies$q$);
insert into res select 'T37 U1 (admin) lit la paie par l''API', '1', essai('00000000-0000-0000-0000-000000000001','authenticated',$q$select count(*)::text from erp_paies$q$);
insert into res select 'T38 U6 (magasinier) ne peut pas écrire dans la paie', 'refus', case when essai('00000000-0000-0000-0000-000000000006','authenticated',$q$with i as (insert into erp_paies(org_id,periode_debut,periode_fin) values ('$q$||:'o1'||$q$','2026-11-01','2026-11-30') returning 1) select count(*)::text from i$q$) like 'ERREUR:%' then 'refus' else 'ECRIT' end;
insert into res select 'T39 U3 (lecteur) ne peut pas écrire dans la paie', 'refus', case when essai('00000000-0000-0000-0000-000000000003','authenticated',$q$with i as (insert into erp_paies(org_id,periode_debut,periode_fin) values ('$q$||:'o1'||$q$','2026-11-01','2026-11-30') returning 1) select count(*)::text from i$q$) like 'ERREUR:%' then 'refus' else 'ECRIT' end;
insert into res select 'T40 U6 (magasinier) ne lit pas les moyens de paiement', '0', essai('00000000-0000-0000-0000-000000000006','authenticated',$q$select count(*)::text from moyens_paiement$q$);
-- décomptes : droits copiés de « finance » par migration-v99zzc-decomptes-synchro
insert into res select 'T41 U5 (comptable) peut écrire un marché/décompte (droits copiés de finance)', 'ok', case when essai('00000000-0000-0000-0000-000000000005','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','decomptes','DEC-T1','{"n":1}'::jsonb,0)::text$q$) ~ '"ok" ?: ?true' then 'ok' else 'refus' end;
insert into res select 'T42 U6 (magasinier) ne peut pas écrire un décompte', 'refus', case when essai('00000000-0000-0000-0000-000000000006','authenticated',$q$select enregistrer('$q$||:'o1'||$q$','decomptes','DEC-T2','{"n":1}'::jsonb,0)::text$q$) ~ '"ok" ?: ?true' then 'ok' else 'refus' end;
insert into res select 'T43 org2 (U4) ne lit pas les décomptes de l''org1', '0', essai('00000000-0000-0000-0000-000000000004','authenticated',$q$select count(*)::text from enregistrements where collection='decomptes' and org_id='$q$||:'o1'||$q$'$q$);
select format('%-4s %-92s attendu=%-8s obtenu=%-10s %s', split_part(n,' ',1), substr(n,length(split_part(n,' ',1))+2), attendu, left(obtenu,10), case when obtenu=attendu then 'OK' else 'ECHEC' end) from res;
select 'BILAN '||count(*) filter (where obtenu=attendu)||'/'||count(*) from res;
