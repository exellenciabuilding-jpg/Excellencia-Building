-- Tests V99zzy + V99zzz : fiche étudiante (jeton), registre QR (non confirmé), réservations. À lancer après les migrations (voir run.sh).
\set ON_ERROR_STOP off
\pset format unaligned
\pset tuples_only on
create table if not exists res_tfl(n int generated always as identity, nom text, attendu text, obtenu text);
truncate res_tfl;
create or replace function essai2(p_role text, p_email text, p_hdr text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.email', coalesce(p_email,''), false);
  perform set_config('request.headers', coalesce(p_hdr,''), false);
  execute 'set local role '||p_role;
  begin execute p_sql into r; exception when others then r:='ERREUR:'||sqlerrm; end;
  reset role; return coalesce(r,'(null)'); end $$;

-- préparation : 3 sujets publiés (2 exclusifs + 1), comme le ferait l'administrateur
delete from tfl_candidatures; delete from tfl_sujets where ref like 'TST-%';
insert into tfl_sujets(ref,data,publie,exclusif,statut) values
 ('TST-001','{"titre":"A","problematique":"p","objectifs":"o"}',true,true,'disponible'),
 ('TST-002','{"titre":"B","problematique":"p","objectifs":"o"}',true,true,'disponible'),
 ('TST-003','{"titre":"C","problematique":"p","objectifs":"o"}',true,true,'disponible');

-- ===== Fiche étudiante =====
select set_config('t.tok', (essai2('anon','', '', $q$select public.tfl_sujet_choisir('TST-001','{"nom":"Marie Kabila","telephone":"0812345678","universite":"UNIKIN"}'::jsonb)->>'token'$q$)), false);
insert into res_tfl(nom,attendu,obtenu) select 'F1 le choix renvoie un jeton de 64 caractères', '64', length(current_setting('t.tok'))::text;
insert into res_tfl(nom,attendu,obtenu) select 'F2 fiche sans jeton : refusée', 'ERREUR:jeton_requis',
  essai2('anon','','',$q$select public.tfl_fiche_etudiant_envoyer('TST-001','{"nom":"PIRATE","telephone":"0812345678","annee_academique":"1900"}'::jsonb,null)::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'F3 fiche avec un mauvais jeton : refusée', 'ERREUR:jeton_invalide',
  essai2('anon','','',$q$select public.tfl_fiche_etudiant_envoyer('TST-001','{"nom":"PIRATE","telephone":"0812345678","annee_academique":"1900"}'::jsonb,null,'zzz')::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'F4 la fiche de l''étudiant avec son jeton : acceptée', '{"ok": true}',
  essai2('anon','','',format($q$select public.tfl_fiche_etudiant_envoyer('TST-001','{"nom":"Marie Kabila","telephone":"0812345678","annee_academique":"2025-2026","promotion":"L3"}'::jsonb,null,%L)::text$q$, current_setting('t.tok')));
insert into res_tfl(nom,attendu,obtenu) select 'F5 la fiche a bien été enregistrée (pas écrasée par le pirate)', 'Marie Kabila|2025-2026',
  (select data->>'nom'||'|'||(data->>'annee_academique') from tfl_candidatures where data->>'sujet_ref'='TST-001');
insert into res_tfl(nom,attendu,obtenu) select 'F6 renvoyer le même choix ne donne PAS de nouveau jeton', '(null)',
  essai2('anon','','',$q$select public.tfl_sujet_choisir('TST-001','{"nom":"Marie Kabila","telephone":"0812345678","universite":"UNIKIN"}'::jsonb)->>'token'$q$);
-- ancien choix sans jeton (avant la migration) : reste accepté
insert into tfl_candidatures(ref,data) values ('SUJET-OLD','{"sujet_ref":"TST-OLD","telephone":"0899000111","nom":"Ancien Etudiant"}');
insert into res_tfl(nom,attendu,obtenu) select 'F7 choix antérieur sans jeton : fiche encore acceptée', '{"ok": true}',
  essai2('anon','','',$q$select public.tfl_fiche_etudiant_envoyer('TST-OLD','{"nom":"Ancien Etudiant","telephone":"0899000111","annee_academique":"2024-2025"}'::jsonb,null)::text$q$);

-- ===== Réservations =====
insert into res_tfl(nom,attendu,obtenu) select 'R1 2e sujet pour le même numéro : accepté', 'true',
  essai2('anon','','',$q$select (public.tfl_sujet_choisir('TST-002','{"nom":"Marie Kabila","telephone":"0812345678","universite":"UNIKIN"}'::jsonb)->>'ok')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'R2 3e sujet pour le même numéro : accepté (V99zzz : plus de plafond par étudiant)', 'true',
  essai2('anon','','',$q$select (public.tfl_sujet_choisir('TST-003','{"nom":"Marie Kabila","telephone":"0812345678","universite":"UNIKIN"}'::jsonb)->>'ok')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'R3 un autre numéro ne prend pas un sujet réservé récemment', 'ERREUR:sujet_deja_reserve',
  essai2('anon','','',$q$select public.tfl_sujet_choisir('TST-002','{"nom":"Autre","telephone":"0777000111","universite":"X"}'::jsonb)::text$q$);
-- TST-002 : réservation vieille de 20 jours, fiche jamais complétée → V99zzz : n'expire plus (l'administrateur libère)
update tfl_sujets set reserve_at = now() - interval '20 days' where ref='TST-002';
insert into res_tfl(nom,attendu,obtenu) select 'R4 réservation ancienne (20 j) : n''expire plus, un autre étudiant ne la prend pas', 'ERREUR:sujet_deja_reserve',
  essai2('anon','','',$q$select public.tfl_sujet_choisir('TST-002','{"nom":"Autre","telephone":"0777000111","universite":"X"}'::jsonb)::text$q$);
-- TST-001 : réservation vieille mais fiche COMPLÈTE (F4) → ne doit pas expirer
update tfl_sujets set reserve_at = now() - interval '40 days' where ref='TST-001';
insert into res_tfl(nom,attendu,obtenu) select 'R5 réservation avec fiche complétée : n''expire pas', 'ERREUR:sujet_deja_reserve',
  essai2('anon','','',$q$select public.tfl_sujet_choisir('TST-001','{"nom":"Autre","telephone":"0777000111","universite":"X"}'::jsonb)::text$q$);
-- renvoyer son propre choix ne prolonge pas la réservation
update tfl_sujets set reserve_at = now() - interval '5 days' where ref='TST-002';
select essai2('anon','','',$q$select public.tfl_sujet_choisir('TST-002','{"nom":"Marie Kabila","telephone":"0812345678","universite":"UNIKIN"}'::jsonb)::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'R6 renvoyer son choix ne rallonge pas la réservation', 'true',
  (select (reserve_at < now() - interval '4 days')::text from tfl_sujets where ref='TST-002');

-- ===== Limite par IP =====
delete from tfl_candidatures where ref like 'SUJET-IP%'; delete from exb_limites_ip;
insert into tfl_sujets(ref,data,publie,exclusif,statut) values ('TST-IP','{"titre":"IP"}',true,false,'disponible') on conflict (ref) do nothing;
do $$ declare i int; r text; ko int := 0; begin
  for i in 1..45 loop
    r := essai2('anon','','{"x-forwarded-for":"10.1.1.1, 203.0.113.7"}', format($q$select public.tfl_sujet_choisir('TST-IP','{"nom":"Spam %s","telephone":"07%s","universite":"x"}'::jsonb)::text$q$, i, lpad(i::text,8,'0')));
    if r like 'ERREUR:trop_de_demandes%' then ko := ko + 1; end if;
  end loop;
  insert into res_tfl(nom,attendu,obtenu) values ('I1 même IP : plus de limite (V99zzz) — 45 choix, 0 refus', '0', ko::text);
end $$;
insert into res_tfl(nom,attendu,obtenu) select 'I2 une autre IP n''est pas bloquée', 'true',
  essai2('anon','','{"x-forwarded-for":"198.51.100.9"}',$q$select (public.tfl_sujet_choisir('TST-IP','{"nom":"Autre IP","telephone":"0766000999","universite":"x"}'::jsonb)->>'ok')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'I3 sans en-têtes (appel interne) : pas de limite par IP', 'true',
  essai2('anon','','',$q$select (public.tfl_sujet_choisir('TST-IP','{"nom":"Interne","telephone":"0766000888","universite":"x"}'::jsonb)->>'ok')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'I4 la table des limites n''est pas lisible par le public', 'ERREUR:permission denied for table exb_limites_ip',
  essai2('anon','','',$q$select count(*)::text from exb_limites_ip$q$);

-- ===== Liste publique : un sujet exclusif déjà choisi disparaît (V99zzz) =====
insert into res_tfl(nom,attendu,obtenu) select 'V1 sujets exclusifs réservés (TST-001, TST-002, TST-003) : absents de la liste publique', '0',
  essai2('anon','','',$q$select count(*)::text from public.tfl_sujets_publics_page() where ref in ('TST-001','TST-002','TST-003')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'V2 sujet non exclusif : reste affiché', '1',
  essai2('anon','','',$q$select count(*)::text from public.tfl_sujets_publics_page() where ref = 'TST-IP'$q$);
insert into res_tfl(nom,attendu,obtenu) select 'V3 l''ancienne lecture publique (500 lignes) masque aussi les sujets choisis', '0',
  essai2('anon','','',$q$select count(*)::text from public.tfl_sujets_publics() where ref in ('TST-001','TST-002','TST-003')$q$);
select essai2('authenticated','excellenciabuilding@gmail.com','',$q$select public.tfl_sujets_publier('[{"ref":"TST-001","titre":"Sujet un","publie":true,"exclusif":true,"statut":"disponible","push_statut":true}]'::jsonb)::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'V4 l''administrateur libère TST-001 : il réapparaît dans la liste', '1',
  essai2('anon','','',$q$select count(*)::text from public.tfl_sujets_publics_page() where ref = 'TST-001'$q$);

-- ===== Registre QR =====
delete from exb_doc_registry where no like 'TSTQR-%';
select essai2('authenticated','excellenciabuilding@gmail.com','',$q$select public.exb_doc_publish2('TSTQR-OFF','inscription','aaaaaa1111',current_date,0,'','valide','Vrai Etudiant','M-1','Fiche officielle','')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q1 document publié par l''administrateur : confirmé et dernière version', 'true|true',
  essai2('anon','','',$q$select (public.exb_doc_verify2('TSTQR-OFF','aaaaaa1111')->>'confirmed')||'|'||(public.exb_doc_verify2('TSTQR-OFF','aaaaaa1111')->>'latest')$q$);
select essai2('anon','','',$q$select public.exb_doc_declare('{"no":"TSTQR-OFF","hash":"bbbbbb2222","nom":"Faux","libelle":"Faux"}'::jsonb)::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q2 un faux dépôt sur le même numéro ne déclasse pas le vrai document', 'true',
  essai2('anon','','',$q$select (public.exb_doc_verify2('TSTQR-OFF','aaaaaa1111')->>'latest')$q$);
select essai2('anon','','',$q$select public.exb_doc_declare('{"no":"TSTQR-DEPOT","hash":"cccccc3333","nom":"Etudiant Depose","libelle":"Fiche"}'::jsonb)::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q3 un dépôt public s''affiche « non confirmé » (confirmed=false)', 'false',
  essai2('anon','','',$q$select (public.exb_doc_verify2('TSTQR-DEPOT','cccccc3333')->>'confirmed')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q4 le faux dépôt ne se fait pas passer pour une fiche reçue par Excellencia', 'false',
  essai2('anon','','',$q$select (public.exb_doc_verify2('TSTQR-DEPOT','cccccc3333')->>'detail' ilike '%reçue par Excellencia%')::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q5 le public ne peut pas confirmer un dépôt', 'ERREUR:permission denied for function exb_doc_confirmer',
  essai2('anon','','',$q$select public.exb_doc_confirmer('TSTQR-DEPOT')::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q6 un utilisateur connecté non administrateur ne peut pas confirmer', 'ERREUR:non autorisé',
  essai2('authenticated','intrus@example.com','',$q$select public.exb_doc_confirmer('TSTQR-DEPOT')::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q6b confirmer avec un autre nom : rien n''est confirmé', '0',
  essai2('authenticated','excellenciabuilding@gmail.com','',$q$select public.exb_doc_confirmer('TSTQR-DEPOT', null, 'Quelqu un d autre')::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q7 l''administrateur confirme le dépôt', '1',
  essai2('authenticated','excellenciabuilding@gmail.com','',$q$select public.exb_doc_confirmer('TSTQR-DEPOT')::text$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q8 après confirmation : authentique', 'true',
  essai2('anon','','',$q$select (public.exb_doc_verify2('TSTQR-DEPOT','cccccc3333')->>'confirmed')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q9 la recherche par numéro indique « confirmé »', 'true',
  essai2('anon','','',$q$select (public.exb_doc_search('TSTQR-DEPOT')->'items'->0->>'confirmed')$q$);
insert into res_tfl(nom,attendu,obtenu) select 'Q10 l''ancienne vérification (V99l) ne confirme plus un dépôt public', 'non confirmé',
  (select public.exb_doc_verify('TSTQR-OFF','bbbbbb2222')->>'status');
insert into res_tfl(nom,attendu,obtenu) select 'Q11 le public ne peut pas publier au registre', 'ERREUR:permission denied for function exb_doc_publish2',
  essai2('anon','','',$q$select public.exb_doc_publish2('TSTQR-X','inscription','dddddd4444',current_date,0,'','valide','X','','','')::text$q$);

select nom||'  attendu='||attendu||'  obtenu='||obtenu||'  '||case when attendu=obtenu then 'OK' else 'ECHEC' end from res_tfl order by n;
select 'BILAN TFL/QR '||count(*) filter (where attendu=obtenu)||'/'||count(*) from res_tfl;
