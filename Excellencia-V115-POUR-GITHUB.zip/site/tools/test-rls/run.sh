#!/bin/bash
# Usage : PGHOST=… PGPORT=… PGUSER=… tools/test-rls/run.sh   (PostgreSQL 14+ ; crée la base « rls_test », l'imitation de l'authentification Supabase, charge toutes les migrations, puis lance test-rls.sql)
set -e
D="$(cd "$(dirname "$0")/../../supabase" && pwd)"; T="$(cd "$(dirname "$0")" && pwd)"
psql postgres -qc "drop database if exists rls_test" -c "create database rls_test" >/dev/null 2>&1
psql rls_test -q -f "$T/stub-supabase.sql" >/dev/null 2>&1
for f in schema-entreprise migration-v66-roles migration-v67-btp migration-v68-priorite2 migration-v75-droits-v69-v74 migration-v76-droits-reception migration-v77-photos-recurrence migration-v78-finance migration-v79-architecture migration-v80-cartouche migration-v81-securite migration-v81-gestion migration-v90-enterprise migration-v91-core migration-v92-erp migration-v93-btp-payments migration-v94-architecture-bim-cde migration-v97-integration migration-v98-unifie migration-v99-vitrine migration-v99g-paiements migration-v99l-documents migration-v99m-verification migration-v99o-qr-public migration-v99r-copies-epreuves migration-v99v-securite-licences migration-v99w-equipe migration-v99zn-synchro-modules migration-v99zo-securite-serveur migration-v99zp-double-authentification migration-v99zv-suivi-erreurs migration-v99zw-plans-partages migration-v99zy-portails migration-v99zz-droits-tables-dediees migration-v99zzc-decomptes-synchro migration-v99zzf-validation-ingenieur migration-v99zzj-activation-invitation migration-v99zzr-tfl-en-ligne migration-v99zzt-tfl-portails migration-v99zzv-tfl-sujets migration-v99zzw-tfl-banque-sujets migration-v99zzx-tfl-fiche-etudiant migration-v99zzy-securite-tfl-qr migration-v99zzz-tfl-sans-limite migration-v99zzzzzzzzzzzzzzz-espace-client migration-v99zzzzzzzzzzzzzzzz-espace-client-plans; do
  [ -f "$D/$f.sql" ] || { echo "MIGRATION MANQUANTE : $f"; continue; }
  psql rls_test -q -v ON_ERROR_STOP=1 -f "$D/$f.sql" >/dev/null 2>/tmp/rls_err.txt || echo "ECHEC migration $f : $(head -c 220 /tmp/rls_err.txt | tr '\n' ' ')"; done
psql rls_test -f "$T/test-rls.sql" 2>&1 | grep -v "^$\|^INSERT\|^SET\|^UPDATE\|^GRANT\|^CREATE\|^RESET\|^set_config\|^0000\|^[0-9a-f]\{8\}-\|^enregistrer\|^{" 
psql rls_test -f "$T/test-validation.sql" 2>&1 | grep -v "^$\|^INSERT\|^SET\|^UPDATE\|^GRANT\|^CREATE\|^RESET\|^set_config\|^DO\|^[0-9a-f]\{8\}-\|^enregistrer\|^{"
psql rls_test -f "$T/test-tfl-qr.sql" 2>&1 | grep -E "OK$|ECHEC$|^BILAN|ERROR"
psql rls_test -f "$T/test-espace-client.sql" 2>&1 | grep -E "OK$|ECHEC$|^BILAN|ERROR"
