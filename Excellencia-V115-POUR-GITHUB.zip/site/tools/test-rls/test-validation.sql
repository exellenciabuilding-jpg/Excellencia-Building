-- Tests de la validation des calculs côté serveur (V99zzf). Lancé par run.sh après test-rls.sql (même base « rls_test »).
-- Chaque ligne « V… » : attendu | obtenu | OK / ECHEC.
\set ON_ERROR_STOP off
\pset tuples_only on
\pset format unaligned
create temp table resv(n text, attendu text, obtenu text);
grant all on resv to public;
insert into auth.users(id,email) values
 ('00000000-0000-0000-0000-0000000000a1','adm@x'),('00000000-0000-0000-0000-0000000000a2','ing@x'),
 ('00000000-0000-0000-0000-0000000000a3','edi@x'),('00000000-0000-0000-0000-0000000000a4','lec@x'),
 ('00000000-0000-0000-0000-0000000000a5','autre@x') on conflict do nothing;
-- A1 admin org V1 ; A2 éditeur (futur ingénieur) ; A3 éditeur simple ; A4 lecteur ; A5 admin d'une autre entreprise
select set_config('app.uid','00000000-0000-0000-0000-0000000000a1',false);
select (creer_organisation('OrgV1','A1')::jsonb->>'id') as ov1 \gset
select set_config('app.uid','00000000-0000-0000-0000-0000000000a5',false);
select (creer_organisation('OrgV2','A5')::jsonb->>'id') as ov2 \gset
insert into membres(org_id,user_id,role,fonction) values
 (:'ov1','00000000-0000-0000-0000-0000000000a2','editeur','polyvalent'),
 (:'ov1','00000000-0000-0000-0000-0000000000a3','editeur','polyvalent'),
 (:'ov1','00000000-0000-0000-0000-0000000000a4','lecteur','polyvalent');

create or replace function essai_v(p_uid text, p_aal text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.uid',coalesce(p_uid,''),false); perform set_config('app.role','authenticated',false); perform set_config('app.aal',p_aal,false);
  execute 'set local role authenticated';
  begin execute p_sql into r; exception when others then r:='ERREUR:'||sqlerrm; end;
  reset role; return coalesce(r,'(null)'); end $$;

-- Désignation de l'ingénieur
insert into resv select 'V1 un éditeur ne peut pas désigner un ingénieur habilité', 'administrateur_requis',
  essai_v('00000000-0000-0000-0000-0000000000a3','aal1',$q$select (ingenieur_designer('$q$||:'ov1'||$q$','00000000-0000-0000-0000-0000000000a3','Faux Ingenieur','OI-0','true'::boolean))::jsonb->>'refus'$q$);
insert into resv select 'V2 l''administrateur désigne A2 ingénieur habilité', 'true',
  essai_v('00000000-0000-0000-0000-0000000000a1','aal1',$q$select (ingenieur_designer('$q$||:'ov1'||$q$','00000000-0000-0000-0000-0000000000a2','Ing. Jean Mukendi','OI-1234',true))::jsonb->>'ok'$q$);
insert into resv select 'V3 l''administrateur d''une autre entreprise ne peut pas désigner dans l''org V1', 'administrateur_requis',
  essai_v('00000000-0000-0000-0000-0000000000a5','aal1',$q$select (ingenieur_designer('$q$||:'ov1'||$q$','00000000-0000-0000-0000-0000000000a2','X Y Z','OI-9',true))::jsonb->>'refus'$q$);

-- Dépôt « Émis » / « Soumis » par un éditeur
insert into resv select 'V4 un éditeur peut soumettre à vérification', 'true',
  essai_v('00000000-0000-0000-0000-0000000000a3','aal1',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','verif','',false))::jsonb->>'ok'$q$);
insert into resv select 'V5 un lecteur ne peut rien déposer', 'ecriture_interdite',
  essai_v('00000000-0000-0000-0000-0000000000a4','aal1',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','verif','',false))::jsonb->>'refus'$q$);
insert into resv select 'V6 un non-membre ne peut rien déposer', 'non_membre',
  essai_v('00000000-0000-0000-0000-0000000000a5','aal1',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','verif','',false))::jsonb->>'refus'$q$);

-- Validation
insert into resv select 'V7 un éditeur non habilité ne peut pas valider', 'ingenieur_habilite_requis',
  essai_v('00000000-0000-0000-0000-0000000000a3','aal2',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','valide','',true))::jsonb->>'refus'$q$);
insert into resv select 'V8 l''ingénieur habilité sans 2FA (aal1) ne peut pas valider', 'session_2fa_requise',
  essai_v('00000000-0000-0000-0000-0000000000a2','aal1',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','valide','',true))::jsonb->>'refus'$q$);
insert into resv select 'V9 sans déclaration de responsabilité : refus', 'declaration_requise',
  essai_v('00000000-0000-0000-0000-0000000000a2','aal2',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','valide','',false))::jsonb->>'refus'$q$);
insert into resv select 'V10 « avec réserves » sans commentaire : refus', 'commentaire_requis',
  essai_v('00000000-0000-0000-0000-0000000000a2','aal2',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','reserves','',true))::jsonb->>'refus'$q$);
insert into resv select 'V11 validation correcte (aal2, habilité, déclaration)', 'true',
  essai_v('00000000-0000-0000-0000-0000000000a2','aal2',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-001','A','abcdef123456','valide','',true))::jsonb->>'ok'$q$);
insert into resv select 'V12 le nom inscrit vient du serveur, pas du navigateur', 'Ing. Jean Mukendi|OI-1234',
  (select ing_nom||'|'||ing_ordre from validations_calcul where statut='valide' and org_id=:'ov1');
select essai_v('00000000-0000-0000-0000-0000000000a1','aal1',$q$select (ingenieur_designer('$q$||:'ov1'||$q$','00000000-0000-0000-0000-0000000000a2','Ing. Jean Mukendi','OI-1234',false))::jsonb->>'ok'$q$) as _retrait \gset
insert into resv select 'V13 le retrait de l''habilitation bloque aussitôt la validation', 'ingenieur_habilite_requis',
  essai_v('00000000-0000-0000-0000-0000000000a2','aal2',$q$select (calcul_valider('$q$||:'ov1'||$q$','Projet X','Poutre','NCS-2026-002','A','999999aaaaaa','valide','',true))::jsonb->>'refus'$q$);

-- Journal non modifiable
insert into resv select 'V14 le journal ne peut pas être modifié (update direct)', 'refus',
  case when essai_v('00000000-0000-0000-0000-0000000000a1','aal2',$q$with u as (update validations_calcul set statut='refuse' returning 1) select count(*)::text from u$q$) in ('0') or essai_v('00000000-0000-0000-0000-0000000000a1','aal2',$q$with u as (update validations_calcul set statut='refuse' returning 1) select count(*)::text from u$q$) like 'ERREUR%' then 'refus' else 'MODIFIE' end;
insert into resv values ('V15 le journal ne peut pas être effacé, même par le propriétaire de la table', 'journal des validations en ajout seul', 'SUPPRIME');
do $$ begin begin delete from validations_calcul; exception when others then update resv set obtenu=sqlerrm where n like 'V15%'; end; end $$;
insert into resv select 'V16 aucune écriture directe en insert pour un membre', 'refus',
  case when essai_v('00000000-0000-0000-0000-0000000000a1','aal2',$q$insert into validations_calcul(org_id,no,digest,type_calcul,statut,user_id) values ('$q$||:'ov1'||$q$','X','abcdef12','Poutre','valide','00000000-0000-0000-0000-0000000000a1') returning 'ok'$q$) like 'ERREUR%' then 'refus' else 'INSERE' end;
insert into resv select 'V17 l''autre entreprise ne lit pas le journal', '0',
  essai_v('00000000-0000-0000-0000-0000000000a5','aal2',$q$select count(*)::text from validations_calcul$q$);
insert into resv select 'V18 un membre lit le journal de son entreprise', '2',
  essai_v('00000000-0000-0000-0000-0000000000a3','aal1',$q$select count(*)::text from validations_calcul$q$);

-- Lien QR ↔ validation (à l'impression) puis vérification publique
insert into resv select 'V19 impression : lien QR enregistré pour l''exemplaire validé', 'true',
  essai_v('00000000-0000-0000-0000-0000000000a3','aal1',$q$select (calcul_lier_qr('$q$||:'ov1'||$q$','NCS-2026-001','CODE0001AB','abcdef123456','A','valide'))::jsonb->>'ok'$q$);
insert into resv select 'V20 on ne peut pas imprimer « validé » une empreinte que le serveur n''a pas validée', 'validation_serveur_absente',
  essai_v('00000000-0000-0000-0000-0000000000a3','aal1',$q$select (calcul_lier_qr('$q$||:'ov1'||$q$','NCS-2026-001','CODE0002CD','eeeeee111111','A','valide'))::jsonb->>'refus'$q$);
insert into resv select 'V21 un non-membre ne peut pas lier un QR', 'non_membre',
  essai_v('00000000-0000-0000-0000-0000000000a5','aal1',$q$select (calcul_lier_qr('$q$||:'ov1'||$q$','NCS-2026-001','CODE0003EF','abcdef123456','A','valide'))::jsonb->>'refus'$q$);
insert into resv select 'V22 aucune écriture directe dans validations_qr', 'refus',
  case when essai_v('00000000-0000-0000-0000-0000000000a1','aal2',$q$insert into validations_qr(org_id,no,code,digest,statut_imprime,user_id) values ('$q$||:'ov1'||$q$','X','CODE9999ZZ','abcdef12','valide','00000000-0000-0000-0000-0000000000a1') returning 'ok'$q$) like 'ERREUR%' then 'refus' else 'INSERE' end;
insert into resv select 'V23 anonyme : le QR de la version validée renvoie « valide » et « dernière version »', 'valide|true|valide',
  essai_v(null,'aal1',$q$select (calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->>'statut'||'|'||((calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->>'derniere_version')||'|'||((calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->>'statut_imprime')$q$);
insert into resv select 'V24 la vérification renvoie le nom et le n° d''ordre issus du serveur', 'Ing. Jean Mukendi|OI-1234',
  essai_v(null,'aal1',$q$select (calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->>'ing_nom'||'|'||((calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->>'ing_ordre')$q$);
-- le calcul change : nouvelle empreinte soumise → l'ancien QR n'est plus la version actuelle
select set_config('app.uid','00000000-0000-0000-0000-0000000000a3',false), set_config('app.aal','aal1',false) \gset
select calcul_valider(:'ov1','Projet X','Poutre','NCS-2026-001','B','fedcba654321','verif','',false) \gset
insert into resv select 'V25 après modification, l''ancien QR est signalé « ancienne version »', 'false|B',
  essai_v(null,'aal1',$q$select ((calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->>'derniere_version')||'|'||(((calcul_verifier('NCS-2026-001','CODE0001AB'))::jsonb->'version_actuelle')->>'indice')$q$);
insert into resv select 'V26 code inconnu : non trouvé', 'false',
  essai_v(null,'aal1',$q$select ((calcul_verifier('NCS-2099-999','ZZZZZZZZZZ'))::jsonb->>'found')$q$);
insert into resv select 'V27 un code valable pour un autre numéro ne confirme rien', 'false',
  essai_v(null,'aal1',$q$select ((calcul_verifier('NCS-2026-777','CODE0001AB'))::jsonb->>'found')$q$);
insert into resv select 'V28 la vérification publique ne renvoie aucun identifiant interne', '0',
  essai_v(null,'aal1',$q$select (case when (calcul_verifier('NCS-2026-001','CODE0001AB'))::text ~ '(user_id|org_id|digest)' then 1 else 0 end)::text$q$);

select n||'  |  attendu='||attendu||'  |  obtenu='||obtenu||'  |  '||case when attendu=obtenu then 'OK' else 'ECHEC' end from resv order by (regexp_replace(n,'^V(\d+).*','\1'))::int;
select 'RÉSULTAT : '||count(*) filter (where attendu=obtenu)||' OK / '||count(*) filter (where attendu<>obtenu)||' ECHEC' from resv;
