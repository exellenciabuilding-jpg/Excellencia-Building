-- Test de l'espace client (comptes matricule + mot de passe). Lancé par run.sh après les migrations.
\set ON_ERROR_STOP off
\pset tuples_only on
\pset format unaligned
create temp table res_ec(nom text, attendu text, obtenu text);
grant all on res_ec to public;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000e1','ec1@x'),('00000000-0000-0000-0000-0000000000e2','ec2@x') on conflict do nothing;
select set_config('app.uid','00000000-0000-0000-0000-0000000000e1',false);
select (creer_organisation('OrgEC','E1')::jsonb->>'id') as oa \gset
select set_config('app.uid','00000000-0000-0000-0000-0000000000e2',false);
select (creer_organisation('OrgEC2','E2')::jsonb->>'id') as ob \gset
select set_config('app.uid','00000000-0000-0000-0000-0000000000e1',false);
select (portail_publier(:'oa', null, 'client', 'Villa Test', 'M. Client', '123456',
  '{"projet":{"nom":"Villa","avancement":40},"documents":[{"id":"D1","titre":"Contrat","hash":"abc","roles":["client"]}]}'::jsonb, null)::jsonb->>'token') as tok \gset
create or replace function ess(p_role text, p_sql text) returns text language plpgsql as $$
declare r text; begin
  perform set_config('app.role',p_role,false);
  execute 'set local role '||p_role;
  begin execute p_sql into r; exception when others then r:='ERREUR:'||sqlerrm; end;
  reset role; return coalesce(r,'(null)'); end $$;
insert into res_ec select 'E1 création du compte (matricule en minuscules accepté)', 'true', (client_compte_creer(:'oa','cli-2026-0001','M. Client',:'tok')::jsonb->>'ok');
insert into res_ec select 'E2 mot de passe par défaut = matricule : connexion acceptée', 'true', ess('anon', $q$select (client_connexion('CLI-2026-0001','CLI-2026-0001')::jsonb->>'ok')$q$);
select (client_connexion('cli-2026-0001','CLI-2026-0001')::jsonb->>'session') as s1 \gset
insert into res_ec select 'E3 premier accès : changement de mot de passe exigé', 'true', (client_connexion('CLI-2026-0001','CLI-2026-0001')::jsonb->>'doit_changer');
insert into res_ec select 'E4 session restreinte : contenu refusé tant que le mot de passe n''est pas changé', 'changer', (portail_lire(:'s1','')::jsonb->>'code');
insert into res_ec select 'E5 nouveau mot de passe = matricule refusé', 'identique', (client_changer_mdp(:'s1','CLI-2026-0001','cli-2026-0001')::jsonb->>'code');
insert into res_ec select 'E6 nouveau mot de passe trop court refusé', 'court', (client_changer_mdp(:'s1','CLI-2026-0001','abc')::jsonb->>'code');
insert into res_ec select 'E7 ancien mot de passe faux refusé', 'ancien', (client_changer_mdp(:'s1','faux','MotDePasse#2026')::jsonb->>'code');
insert into res_ec select 'E8 changement accepté', 'true', (client_changer_mdp(:'s1','CLI-2026-0001','MotDePasse#2026')::jsonb->>'ok');
insert into res_ec select 'E9 après changement : le client voit son projet', '40', (portail_lire(:'s1','')::jsonb->'contenu'->'projet'->>'avancement');
insert into res_ec select 'E10 le client signe son document (compte)', 'true', (portail_signer(:'s1','','D1','client','Jean Client','data:image/png;base64,AAAA','t')::jsonb->>'ok');
insert into res_ec select 'E11 le client envoie un message', 'true', (portail_message(:'s1','','Bonjour')::jsonb->>'ok');
insert into res_ec select 'E12 l''ancien mot de passe (matricule) ne marche plus', 'identifiants', (client_connexion('CLI-2026-0001','CLI-2026-0001')::jsonb->>'code');
insert into res_ec select 'E13 matricule inconnu : même message que mot de passe faux', 'identifiants', (client_connexion('CLI-0000','x')::jsonb->>'code');
select client_connexion('CLI-2026-0001','a'), client_connexion('CLI-2026-0001','b'), client_connexion('CLI-2026-0001','c'), client_connexion('CLI-2026-0001','d') \gset
insert into res_ec select 'E14 5e essai raté : blocage 15 min', 'bloque', (client_connexion('CLI-2026-0001','e')::jsonb->>'code');
insert into res_ec select 'E15 même le bon mot de passe est refusé pendant le blocage', 'bloque', (client_connexion('CLI-2026-0001','MotDePasse#2026')::jsonb->>'code');
update client_comptes set bloque_jusqua = null;
insert into res_ec select 'E16 jeton de session inventé refusé', 'session', (portail_lire('cs_'||repeat('0',48),'')::jsonb->>'code');
insert into res_ec select 'E17 le lien + code d''origine fonctionne toujours', '40', (portail_lire(:'tok','123456')::jsonb->'contenu'->'projet'->>'avancement');
insert into res_ec select 'E18 une autre organisation ne peut pas créer un compte relié au portail d''autrui', 'portail_introuvable', (select case when ess2 ~ 'portail_introuvable' then 'portail_introuvable' else ess2 end from (select ess('authenticated', format($f$select set_config('app.uid','00000000-0000-0000-0000-0000000000e2',false)||client_compte_creer(%L,'CLI-2026-0002','X',%L)::text$f$, :'ob', :'tok')) as ess2) z);
select set_config('app.uid','00000000-0000-0000-0000-0000000000e2',false);
insert into res_ec select 'E19 un autre utilisateur ne peut pas créer de compte dans l''org1', 'refus', (select case when t ~ 'non autorisé' then 'refus' else t end from (select ess('authenticated', format($f$select client_compte_creer(%L,'CLI-2026-0003','X',null)::text$f$, :'oa')) as t) z);
select set_config('app.uid','00000000-0000-0000-0000-0000000000e1',false);
insert into res_ec select 'E20 le public ne peut pas créer de compte', 'refus', (select case when t ~ 'permission denied' then 'refus' else t end from (select ess('anon', format($f$select client_compte_creer(%L,'CLI-2026-0004','X',null)::text$f$, :'oa')) as t) z);
insert into res_ec select 'E21 le public ne lit pas les comptes', 'refus', (select case when t ~ 'permission denied' then 'refus' else t end from (select ess('anon', 'select count(*)::text from client_comptes') as t) z);
insert into res_ec select 'E22 le mot de passe haché n''est lisible par personne côté API', 'refus', (select case when t ~ 'permission denied' then 'refus' else t end from (select ess('authenticated', 'select pw_hash from client_comptes') as t) z);
insert into res_ec select 'E23 mot de passe stocké haché (pas en clair)', 'true', (select (pw_hash like '$2%' and pw_hash <> 'CLI-2026-0001')::text from client_comptes where matricule='CLI-2026-0001');
select client_compte_creer(:'oa','CLI-2026-0001','M. Client',null) \gset
insert into res_ec select 'E24 réinitialisation : session ancienne coupée', 'session', (portail_lire(:'s1','')::jsonb->>'code');
insert into res_ec select 'E25 réinitialisation : le matricule redevient le mot de passe', 'true', (client_connexion('CLI-2026-0001','CLI-2026-0001')::jsonb->>'doit_changer');
select client_compte_etat(:'oa','CLI-2026-0001', false) \gset
insert into res_ec select 'E26 compte désactivé : connexion refusée', 'desactive', (client_connexion('CLI-2026-0001','CLI-2026-0001')::jsonb->>'code');
select portail_revoquer(:'tok') \gset
select client_compte_etat(:'oa','CLI-2026-0001', true) \gset
select (client_connexion('CLI-2026-0001','CLI-2026-0001')::jsonb->>'session') as s2 \gset
select client_changer_mdp(:'s2','CLI-2026-0001','AutreMotDePasse9') \gset
select (client_connexion('CLI-2026-0001','AutreMotDePasse9')::jsonb->>'session') as s3 \gset
insert into res_ec select 'E27 portail révoqué : le compte client n''y accède plus', 'revoque', (portail_lire(:'s3','')::jsonb->>'code');
select nom||'  attendu='||attendu||'  obtenu='||obtenu||'  '||case when attendu=obtenu then 'OK' else 'ECHEC' end from res_ec order by length(nom), nom;
select 'BILAN ESPACE CLIENT '||count(*) filter (where attendu=obtenu)||'/'||count(*) from res_ec;
-- ===== Plans envoyés au client =====
\pset format unaligned
create temp table res_pl(nom text, attendu text, obtenu text);
grant all on res_pl to public;
select set_config('app.uid','00000000-0000-0000-0000-0000000000e1',false);
select (portail_publier(:'oa', null, 'client', 'Villa Plans', 'M. Plan', '654321', '{"projet":{"nom":"V","avancement":10}}'::jsonb, null)::jsonb->>'token') as tk2 \gset
select client_compte_creer(:'oa','CLI-2026-0100','M. Plan',:'tk2') \gset
select (client_connexion('CLI-2026-0100','CLI-2026-0100')::jsonb->>'session') as sp \gset
select client_changer_mdp(:'sp','CLI-2026-0100','MotDePasse#2026') \gset
insert into res_pl select 'P1 envoi d''un plan (version 1)', '1', (client_plan_publier(:'oa',:'tk2','Plan R+1','Rez-de-chaussée','data:application/pdf;base64,JVBERi0xLjQK')::jsonb->>'version');
insert into res_pl select 'P2 même titre = plan modifié (version 2)', '2', (client_plan_publier(:'oa',:'tk2','plan  r+1','Poteaux déplacés','data:application/pdf;base64,JVBERi0xLjUK')::jsonb->>'version');
insert into res_pl select 'P3 le client voit 2 versions, la dernière est « courante »', '2|1', (select jsonb_array_length(x->'plans')::text||'|'||(select count(*) from jsonb_array_elements(x->'plans') e where (e->>'courant')='true') from (select client_plans_liste(:'sp','')::jsonb x) z);
insert into res_pl select 'P4 les deux sont signalés « nouveaux »', '2', (select count(*)::text from jsonb_array_elements(client_plans_liste(:'sp','')::jsonb->'plans') e where (e->>'nouveau')='true');
insert into res_pl select 'P5 le client est prévenu dans sa messagerie (plan modifié)', '1', (select count(*)::text from portail_messages m join portail_liens l on l.id=m.lien_id where l.token=:'tk2' and m.de='entreprise' and m.texte like '%Plan modifié%');
select (client_plans_liste(:'sp','')::jsonb->'plans'->0->>'id') as pid1 \gset
insert into res_pl select 'P6 le client télécharge le plan', 'application/pdf', (client_plan_lire(:'sp','',:'pid1'::uuid)::jsonb->>'mime');
insert into res_pl select 'P7 après ouverture : plus « nouveau »', '1', (select count(*)::text from jsonb_array_elements(client_plans_liste(:'sp','')::jsonb->'plans') e where (e->>'nouveau')='true');
insert into res_pl select 'P8 l''entreprise voit « vu le … »', '1', (select count(*)::text from jsonb_array_elements(client_plans_suivi(:'oa')) e where e->>'vu_le' is not null);
insert into res_pl select 'P9 le lien + code d''origine donne aussi accès', '2', (select jsonb_array_length(client_plans_liste(:'tk2','654321')::jsonb->'plans')::text);
insert into res_pl select 'P10 mauvais code : refus', 'code', (client_plans_liste(:'tk2','000000')::jsonb->>'code');
insert into res_pl select 'P11 fichier non autorisé (exécutable) refusé', 'ERREUR', (select case when t ~ 'fichier_invalide' then 'ERREUR' else t end from (select ess('authenticated', format($f$select client_plan_publier(%L,%L,'X1','', 'data:application/x-msdownload;base64,AAAA')::text$f$, :'oa', :'tk2')) as t) z);
insert into res_pl select 'P12 le public ne peut pas envoyer de plan', 'refus', (select case when t ~ 'permission denied' then 'refus' else t end from (select ess('anon', format($f$select client_plan_publier(%L,%L,'X2','', 'data:application/pdf;base64,AAAA')::text$f$, :'oa', :'tk2')) as t) z);
insert into res_pl select 'P13 le public ne lit pas la table des plans', 'refus', (select case when t ~ 'permission denied' then 'refus' else t end from (select ess('anon', 'select count(*)::text from client_plans') as t) z);
insert into res_pl select 'P14 le contenu des fichiers n''est pas lisible côté API', 'refus', (select case when t ~ 'permission denied' then 'refus' else t end from (select ess('authenticated', 'select data from client_plans') as t) z);
select set_config('app.uid','00000000-0000-0000-0000-0000000000e2',false);
insert into res_pl select 'P15 une autre organisation ne peut pas envoyer sur ce portail', 'refus', (select case when t ~ 'non autorisé' then 'refus' else t end from (select ess('authenticated', format($f$select client_plan_publier(%L,%L,'X3','', 'data:application/pdf;base64,AAAA')::text$f$, :'oa', :'tk2')) as t) z);
select set_config('app.uid','00000000-0000-0000-0000-0000000000e1',false);
select (client_connexion('CLI-2026-0001','AutreMotDePasse9')::jsonb->>'session') as sautre \gset
insert into res_pl select 'P16 un autre client ne voit pas les plans de ce portail', '0', (select coalesce(jsonb_array_length(client_plans_liste(:'sautre','')::jsonb->'plans'),0)::text);
select nom||'  attendu='||attendu||'  obtenu='||obtenu||'  '||case when attendu=obtenu then 'OK' else 'ECHEC' end from res_pl order by length(nom), nom;
select 'BILAN PLANS CLIENT '||count(*) filter (where attendu=obtenu)||'/'||count(*) from res_pl;
