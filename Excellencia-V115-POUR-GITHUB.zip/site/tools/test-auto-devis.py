# Test navigateur : devis automatique (IFC et PDF → devis). Depuis la racine : python3 tools/test-auto-devis.py
import sys, threading, http.server, socketserver, functools
from playwright.sync_api import sync_playwright
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory='.'); H.log_message=lambda *a:None
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',8768),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0;tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
villa=open('tools/test-bim/villa.ifc',encoding='utf-8').read()
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844}); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('dialog',lambda d:d.accept('') )
    pg.goto('http://127.0.0.1:8768/index.html'); pg.wait_for_function("window.EXBAutoDevis&&window.EXBMetre&&window.EXB_IFC3D",timeout=20000)
    chk('module chargé dans l’application',True)
    pg.wait_for_timeout(2500)
    chk('bouton « 🤖 Devis automatique » monté',pg.evaluate("!!document.getElementById('bautodevis')"))
    # ---- IFC
    pg.evaluate("t=>window.EXBAutoDevis.fromIfcFile(new File([t],'villa.ifc'))",villa)
    pg.wait_for_selector('#exbAd .ln',timeout=20000)
    rows=pg.evaluate("document.querySelectorAll('#exbAd .ln').length")
    chk('écran de contrôle : %d lignes proposées'%rows,rows>=10)
    chk('alertes affichées',pg.evaluate("document.querySelectorAll('#exbAd .w').length")>=2)
    tot0=pg.inner_text('#adTot'); chk('total chiffré affiché : '+tot0,'$' in tot0)
    # saisir un prix pour les poteaux
    pg.evaluate("""()=>{const tr=[...document.querySelectorAll('#exbAd .ln')].find(r=>/Poteaux/.test(r.querySelector('.dd').value));const i=tr.querySelector('.pp');i.value='420';i.dispatchEvent(new Event('input',{bubbles:true}))}""")
    tot1=pg.inner_text('#adTot'); chk('le prix saisi change le total',tot1!=tot0)
    # décocher une ligne (toiture/dalle toiture)
    pg.evaluate("()=>{const tr=[...document.querySelectorAll('#exbAd .ln')].find(r=>/Toiture \\(maquette/.test(r.querySelector('.dd').value));if(tr){tr.querySelector('.on').click()}}")
    pg.click('#adOk'); pg.wait_for_timeout(800)
    st=pg.evaluate("window.EXBMetre.state().extra.map(x=>({d:x.d,u:x.u,q:x.q,pu:x.pu,src:x.src}))")
    chk('lignes arrivées dans « Matériaux ajoutés » (%d)'%len(st),len(st)>=10)
    pot=[x for x in st if 'Poteaux' in x['d']]
    chk('prix saisi des poteaux conservé (420)',pot and float(pot[0]['pu'])==420)
    chk('murs : prix de départ 14 $/m²',any('Maçonnerie' in x['d'] and float(x['pu'])==14 for x in st))
    chk('nom du projet pré-rempli',pg.evaluate("window.EXBMetre.state().hdr.project")=='villa')
    chk('onglet Devis ouvert',pg.evaluate("!!document.querySelector('#mb_panel .mbsec, #mb_panel [data-h=\"client\"]')"))
    T=pg.evaluate("window.EXBMetre.totals()"); chk('totaux du métré calculés (> 0) : '+str(round(T['xs'],2)),T['xs']>0)
    # ---- renvoi sans doublon, prix conservé
    n1=len(st)
    pg.evaluate("t=>window.EXBAutoDevis.fromIfcFile(new File([t],'villa.ifc'))",villa); pg.wait_for_selector('#exbAd .ln',timeout=20000)
    pu_pot=pg.evaluate("[...document.querySelectorAll('#exbAd .ln')].find(r=>/Poteaux/.test(r.querySelector('.dd').value)).querySelector('.pp').value")
    chk('prix déjà validé proposé de nouveau (420)',pu_pot=='420')
    pg.click('#adOk'); pg.wait_for_timeout(600)
    n2=pg.evaluate("window.EXBMetre.state().extra.length"); chk('renvoi : aucun doublon (%d → %d lignes ; +1 attendue pour la toiture décochée la 1re fois)'%(n1,n2),n2<=n1+1)
    # ---- PDF → plan → devis direct
    pg.evaluate("document.querySelectorAll('#exbLicLock').forEach(e=>e.remove())")
    pg.evaluate("""()=>{const f=document.createElement('iframe');f.id='tstPdf';f.src='plan-editeur/import-pdf.html';f.style.cssText='position:fixed;left:0;top:0;width:900px;height:900px;z-index:2147481000;border:0;background:#fff';document.body.appendChild(f)}""")
    pg.wait_for_timeout(2500)
    fr=[f for f in pg.frames if 'import-pdf' in f.url][0]
    fr.set_input_files('#f','tools/test-bim/plan-test.pdf'); fr.wait_for_function("document.getElementById('msg').textContent.includes('chargée')",timeout=30000)
    fr.click('#det'); fr.wait_for_function("/murs détectés/.test(document.getElementById('msg').textContent)",timeout=30000)
    msg=fr.inner_text('#msg'); print('   détection :',msg[:110])
    chk('détection : murs trouvés',not msg.startswith('0 murs'))
    fr.click('#dd'); pg.wait_for_selector('#exbAd .ln',timeout=40000)
    rows=pg.evaluate("[...document.querySelectorAll('#exbAd .ln')].map(r=>[r.querySelector('.dd').value,r.querySelector('.qq').value,r.querySelector('.pp').value])")
    ml=[r for r in rows if r[0].startswith('Murs — longueur')]
    chk('plan : longueur totale des murs ≈ 33 m (périmètre 28 m + cloison 5,6 m)',ml and 30<=float(ml[0][1])<=36)
    chk('plan : surface de maçonnerie chiffrée au prix de l’éditeur (14 $/m²)',any(r[0].startswith('Murs — surface nette') and r[2]=='14' for r in rows))
    chk('plan : porte détectée dans l’ouverture',any(r[0].startswith('Porte') for r in rows))
    chk('alerte « détection automatique à vérifier »',pg.evaluate("[...document.querySelectorAll('#exbAd .w')].some(w=>/détection automatique/.test(w.textContent))"))
    nb=pg.evaluate("window.EXBMetre.state().extra.length")
    pg.click('#adOk'); pg.wait_for_timeout(800)
    chk('plan : lignes ajoutées au métré',pg.evaluate("window.EXBMetre.state().extra.length")>nb)
    chk('aucune erreur JavaScript : '+str(errs[:2]),not errs)
    print('BILAN %d/%d'%(ok,tot)); b.close(); sys.exit(0 if ok==tot else 1)
