#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) du tableau de bord « Pilotage projets » (V99zz).
Usage, depuis le dossier du site :  python3 tools/e2e-pilote.py
Vérifie : écran ouvert depuis le menu, calculs EVM sur de vraies données saisies par les modules Planning/Budget,
alertes, détail projet + courbe en S, exports CSV, protection contre l'injection HTML, absence d'erreur JavaScript."""
import http.server, threading, socketserver, os, functools, sys, datetime
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
S1=(datetime.date.today()-datetime.timedelta(days=21)).isoformat()   # 3 semaines écoulées, semaine en cours = S4
with sync_playwright() as p:
    b=p.chromium.launch()
    a=b.new_page(viewport={'width':420,'height':850}); ae=[]   # format téléphone
    a.on('pageerror',lambda e:ae.append(str(e)[:160]))
    a.on('dialog',lambda d:d.accept('TestLocal#2026') if d.type=='prompt' else d.accept())
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    ok(a.evaluate("getComputedStyle(document.getElementById('app')).display")!='none','connexion locale')
    a.wait_for_timeout(2000)
    ok(a.evaluate("typeof EXBEVM==='object'&&typeof EXBPILOT==='object'"),'modules EVM et Pilotage chargés')
    ok(a.evaluate("!!document.getElementById('bpilot')"),'bouton « Pilotage projets » présent dans le menu Projets')

    # --- données : un chantier en dérive (coût et délai) et un chantier vide au nom piégé ---
    ae.clear()
    a.evaluate("""(s1)=>{
      const P=[{id:'PRJ_EV1',name:'Immeuble Gombe',client:'Client A',currency:'USD'},{id:'PRJ_EV2',name:'<img src=x onerror=window.__xss=1>',client:'<b>x</b>',currency:'USD'}];
      P.forEach(p=>{if(!exbProjects.some(x=>x.id===p.id))exbProjects.push(p)});save(EXB_ECO_KEYS.projects,exbProjects);
      save('exb_gantt',[{id:'GA_EV1',project_id:'PRJ_EV1',date:s1,tasks:[{id:'t1',name:'Fondations',start:1,dur:2,pct:100,pred:''},{id:'t2',name:'Élévation',start:3,dur:2,pct:0,pred:'1'}]}]);
      save('exb_budgets',[{id:'BU_EV1',project_id:'PRJ_EV1',alea:0,postes:[{label:'Gros œuvre',b:100000,r:60000},{label:'Toiture',b:0,r:0}]}]);
    }""",S1)
    r=a.evaluate("""()=>{const x=EXBPILOT._compute().find(a=>a.id==='PRJ_EV1');return x&&{bac:x.bac,ac:x.ac,prog:x.progress,plan:x.planned,cpi:x.cpi,spi:x.spi,ret:x.retard,st:x.status,codes:x.alerts.map(a=>a.code)}}""")
    ok(r and r['bac']==100000 and r['ac']==60000 and r['prog']==50 and r['plan']==75,'EVM lu depuis le Gantt et le budget : BAC 100 000, AC 60 000, avancement 50 %, planifié 75 % '+str(r))
    ok(r and r['cpi']==0.83 and r['spi']==0.67,'CPI 0,83 et SPI 0,67 '+str(r))
    ok(r and r['ret']==1 and r['st']=='rouge' and {'CPI','SPI','RETARD'}<=set(r['codes']),'retard prévisionnel +1 semaine, statut rouge, alertes CPI / SPI / RETARD '+str(r))

    # --- écran ---
    a.evaluate("show('pilotprojet')"); a.wait_for_timeout(400)
    box=a.evaluate("document.getElementById('exbpilot_box').innerText")
    ok('Immeuble Gombe' in box and 'CPI du portefeuille' in box and 'Alertes prioritaires' in box,'portefeuille : cartes, tableau et alertes prioritaires affichés')
    ok(a.evaluate("getComputedStyle(document.getElementById('pilotprojet')).display")!='none','section visible')
    ok(a.evaluate("document.documentElement.scrollWidth<=window.innerWidth+2"),'téléphone (420 px) : la page ne défile pas latéralement (tableau dans son propre défilement)')
    ok(a.evaluate("window.__xss")!=1 and a.evaluate("!document.querySelector('#exbpilot_box img')"),'nom de projet piégé : affiché en texte, aucune injection HTML')
    a.evaluate("EXBPILOT.open('PRJ_EV1')"); a.wait_for_timeout(300)
    box=a.evaluate("document.getElementById('exbpilot_box').innerText")
    ok('Courbe en S' in box and 'Retard prévisionnel' in box and 'EAC' in box and 'Comment ces chiffres' in box,'détail projet : indicateurs, courbe, alertes, méthode')
    ok(a.evaluate("!!document.querySelector('#exbpilot_box svg polyline')"),'courbe en S dessinée (SVG)')
    ok('+1 sem' in box.replace('\u00a0',' '),'retard de +1 semaine affiché')
    a.evaluate("EXBPILOT.back()")
    csv=a.evaluate("EXBPILOT.csv()")
    ok(csv and 'Immeuble Gombe' in csv and 'CPI' in csv and "'<img" not in csv.replace('"',"'")[:0],'export CSV produit')
    ok(a.evaluate("EXBPILOT._csv([{name:'=cmd',client:'',status:'vert',bac:1,ac:1,progress:1,planned:null,cpi:null,spi:null,finPrevue:null,finPlan:'',finPrev:'',eac:null,vac:null,alerts:[]}]).indexOf(\"'=cmd\")>0"),'export CSV : formule neutralisée (=cmd)')
    # --- IA locale : anomalies, synthèse, contexte de l'assistant, repli hors ligne ---
    a.evaluate("""()=>{save('exb_cash',[{id:'c1',date:'2026-10-12',type:'out',label:'Ciment',amount:500,project_id:'PRJ_EV1'},{id:'c2',date:'2026-10-12',type:'out',label:'Ciment',amount:500,project_id:'PRJ_EV1'}]);
      save('exb_budgets',[{id:'BU_EV1',project_id:'PRJ_EV1',alea:0,postes:[{label:'Gros œuvre',b:100000,r:60000},{label:'Toiture',b:0,r:1200}]}]);show('pilotprojet')}""")
    a.wait_for_timeout(300)
    ok('Synthèse de la semaine' in a.evaluate("document.getElementById('exbpilot_box').innerText"),'portefeuille : bloc « Synthèse de la semaine » présent')
    a.evaluate("EXBPILOT.open('PRJ_EV1')"); a.wait_for_timeout(300)
    box=a.evaluate("document.getElementById('exbpilot_box').innerText")
    ok('Anomalies de coûts' in box and 'double saisie' in box and 'hors budget' in box.lower(),'détail : anomalies (doublon de caisse, dépense hors budget) listées')
    a.evaluate("EXBPILOT.back()")
    cx=a.evaluate("EXBPILOT.aiContext()")
    ok(cx.startswith('Pilotage projets') and 'Immeuble Gombe' in cx and '[rouge]' in cx and '<' not in cx,'contexte transmis à l\'assistant : indicateurs du chantier, sans HTML')
    a.evaluate("exbAssistant()"); a.wait_for_timeout(500)
    a.fill('#exbAIq','Quels chantiers sont en retard ou en dérive ?'); a.click('#exbAIgo'); a.wait_for_timeout(1500)
    log=a.evaluate("document.getElementById('exbAIlog').innerText")
    ok('Synthèse des chantiers' in log and 'Immeuble Gombe' in log,'assistant hors ligne : répond avec la synthèse calculée (sans réseau)')
    ok('Pilotage projets' in log and 'Ouvrir l' in log,'assistant : propose d\'ouvrir l\'écran Pilotage projets')
    a.evaluate("document.querySelector('#exbAI')&&document.querySelector('#exbAI').remove()")
    # --- historique hebdomadaire : relevé à l'ouverture, tendance, courbe ---
    ae.clear()
    a.evaluate("""()=>{const t=new Date(Date.now()-7*864e5).toISOString().slice(0,10);
      const mon=d=>{const x=new Date(d+'T00:00:00Z');x.setUTCDate(x.getUTCDate()-((x.getUTCDay()+6)%7));return x.toISOString().slice(0,10)};
      EXBS.set('exb_pilot_hist',[{pid:'PRJ_EV1',week:mon(t),date:t,progress:20,planned:40,cpi:0.5,spi:0.4,ac:30000,bac:100000,eac:200000,retard:2,status:'rouge'}])}""")
    a.evaluate("EXBPILOT.back();EXBPILOT.render()"); a.wait_for_timeout(400)
    h=a.evaluate("EXBPILOT._hist().filter(x=>x.pid==='PRJ_EV1').length")
    ok(h==2,'ouverture du pilotage : relevé de la semaine ajouté au relevé de la semaine précédente ('+str(h)+' points)')
    a.evaluate("EXBPILOT.render();EXBPILOT.render()")
    ok(a.evaluate("EXBPILOT._hist().filter(x=>x.pid==='PRJ_EV1').length")==2,'réouvertures : un seul point par semaine (pas de doublon)')
    ok(a.evaluate("EXBPILOT._hist().every(x=>x.pid!=='PRJ_EV2')"),'projet sans budget : aucun relevé inventé')
    ok(a.evaluate("document.getElementById('exbpilot_box').innerText").count('↗')>=1,'liste : flèche de tendance (amélioration depuis la semaine précédente)')
    a.evaluate("EXBPILOT.open('PRJ_EV1')"); a.wait_for_timeout(400)
    det=a.evaluate("document.getElementById('exbpilot_box').innerText")
    ok('Tendance hebdomadaire' in det and a.evaluate("!!document.querySelector('#exbpilot_box svg[aria-label^=\"Tendance\"]')"),'détail : section « Tendance hebdomadaire » avec courbe CPI / SPI')
    ok('Semaine du' in det and a.evaluate("document.querySelectorAll('#exbpilot_box table tbody tr').length")>=2,'détail : tableau des relevés hebdomadaires')
    a.evaluate("EXBPILOT.back()")
    ok(not ae and a.evaluate("window.__xss")!=1,'historique : aucune erreur JavaScript ni injection '+str(ae[:2]))
    # --- PDF du pilotage : mise en page Excellencia Building + tendance ---
    import base64
    a.evaluate("""()=>{window.__pdfs=[];const o=EXBPdf.save;EXBPdf.save=async function(b,n){window.__pdfs.push({n:n,b:b});return}}""")
    def grab(call):
        a.evaluate("window.__pdfs.length=0"); a.evaluate(call); a.wait_for_timeout(2500)
        return a.evaluate("""async()=>{const x=window.__pdfs[0];if(!x)return null;const u=new Uint8Array(await x.b.arrayBuffer());let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)}""")
    one=grab("EXBPILOT.pdf('PRJ_EV1')"); allp=grab("EXBPILOT.pdf()")
    ok(bool(one) and base64.b64decode(one)[:4]==b'%PDF','PDF d\'un projet généré (fichier PDF valide)')
    ok(bool(allp) and base64.b64decode(allp)[:4]==b'%PDF','PDF du portefeuille généré (fichier PDF valide)')
    if one: open('/tmp/pilot-projet.pdf','wb').write(base64.b64decode(one))
    if allp: open('/tmp/pilot-portefeuille.pdf','wb').write(base64.b64decode(allp))
    ok(not ae,'PDF pilotage : aucune erreur JavaScript '+str(ae[:2]))
    # --- V99zzc : seuils d'alerte réglables, rapport PDF complet ---
    ae.clear()
    a.evaluate("""()=>{const mk=n=>{const x=new Date();x.setDate(x.getDate()-n);return EXBEVM.monday(x.toISOString().slice(0,10))};
      const h=EXBS.get('exb_pilot_hist')||[];[[14,0.6,0.5],[7,0.7,0.6]].forEach(([n,c,s])=>{const wk=mk(n);if(!h.some(x=>x.pid==='PRJ_EV1'&&x.week===wk))h.push({pid:'PRJ_EV1',week:wk,date:wk,cpi:c,spi:s,eac:140000,bac:100000,ac:50000,progress:40,planned:60,retard:2,status:'rouge'})});
      EXBS.set('exb_pilot_hist',h);show('pilotprojet');EXBPILOT.open('PRJ_EV1')}""")
    a.wait_for_timeout(300)
    ok(a.evaluate("(()=>{const c=document.querySelector('#exbpilot_box svg line[stroke-dasharray=\"4 3\"]');return !!c&&+c.getAttribute('x1')>44})()"),'courbe en S : le repère « aujourd\'hui » est à la bonne semaine (et non à S0)')
    def setth(vals):
        a.evaluate("""(v)=>{const d=[...document.querySelectorAll('#exbpilot_box details')].find(x=>x.querySelector('[data-thk]')&&x.querySelector('summary').innerText.includes('ce chantier'));
          d.open=true;Object.keys(v).forEach(k=>{d.querySelector('[data-thk="'+k+'"]').value=v[k]});d.querySelector('button.primary').click()}""",vals)
        a.wait_for_timeout(250)
    codes=lambda: a.evaluate("EXBPILOT._compute().find(x=>x.id==='PRJ_EV1').alerts.map(x=>x.code)")
    nth=lambda: a.evaluate("(EXBS.get('exb_pilot_th')||[]).length")
    ok({'CPI','SPI'}<=set(codes()),'seuils par défaut : alertes CPI et SPI')
    setth({'cpiRed':95,'cpiAmber':90}); ok(nth()==0,'seuils : valeur hors limites refusée, rien d\'enregistré')
    setth({'cpiRed':0.9,'cpiAmber':0.8}); ok(nth()==0,'seuils : rouge plus tolérant qu\'orange refusé')
    setth({'cpiRed':0.6,'cpiAmber':0.8,'spiRed':0.5,'spiAmber':0.6,'vacRed':50,'vacAmber':30,'delayRed':5,'delayAmber':3})
    c=codes()
    ok(nth()==1 and not ({'CPI','SPI','RETARD','EAC'}&set(c)),'seuils du chantier enregistrés : plus d\'alerte CPI / SPI / retard / EAC '+str(c))
    ok('personnalisés' in a.evaluate("document.getElementById('exbpilot_box').innerText"),'détail : mention des seuils personnalisés')
    a.evaluate("EXBPILOT.thReset('PRJ_EV1')"); a.wait_for_timeout(200)
    ok({'CPI','SPI'}<=set(codes()) and nth()==0,'rétablissement : les seuils généraux s\'appliquent à nouveau')
    a.evaluate("EXBPILOT.back()"); a.wait_for_timeout(150)
    a.evaluate("""()=>{const d=[...document.querySelectorAll('#exbpilot_box details')].find(x=>x.querySelector('[data-thk]'));d.open=true;d.querySelector('[data-thk="cpiAmber"]').value=0.8;d.querySelector('[data-thk="cpiRed"]').value=0.7;d.querySelector('button.primary').click()}""")
    a.wait_for_timeout(250)
    ok(a.evaluate("EXBS.get('exb_pilot_th')[0].id")=='global' and 'CPI' not in codes(),'seuils généraux : enregistrés et appliqués (CPI 0,83 au-dessus de 0,80)')
    a.evaluate("EXBPILOT.thReset('global')"); a.wait_for_timeout(150)
    ok(a.evaluate("EXBPILOT._compute().find(x=>x.id==='PRJ_EV1').alerts.some(x=>/0,8\\d/.test(x.msg)&&!/0\\.8\\d/.test(x.msg))"),'messages d\'alerte : décimales avec virgule')
    a.evaluate("EXBPdf.save=function(){}")
    rp=a.evaluate("EXBPILOT._report('PRJ_EV1')"); lab=[r[0] for r in rp['rows']]
    ok(rp['titre']=='RAPPORT DE PILOTAGE DE CHANTIER' and 'État global' in lab and 'Tendance' in lab and any(l.startswith('Décision à prendre') for l in lab) and any(l.startswith('Point d\'attention') for l in lab),'rapport : état, tendance, points d\'attention et décisions à prendre')
    ok(len(rp['images'])==2 and all(i.startswith('data:image/svg+xml') for i in rp['images']) and rp['imagesTitle']=='GRAPHIQUES','rapport : courbe en S et courbe de tendance jointes, section « GRAPHIQUES »')
    ok(any('Seuils appliqués' in n for n in rp['notes']) and not any('≥' in n for n in rp['notes']),'rapport : seuils mentionnés, sans caractère illisible dans le PDF')
    pdf=a.evaluate("""async()=>{const b=await EXBPILOT.pdf('PRJ_EV1');return {size:b.size,head:await b.slice(0,5).text()}}""")
    ok(pdf['head']=='%PDF-' and pdf['size']>15000,'rapport PDF réellement généré (%PDF, '+str(pdf['size'])+' octets, avec graphiques)')
    ok(not ae,'V99zzc : aucune erreur JavaScript '+str(ae[:2]))
    a.evaluate("window.EXBDB=Object.assign({},window.EXBDB,{can:(c,m)=>m!=='ecrire'})")
    a.evaluate("EXBPILOT.open('PRJ_EV1')"); a.wait_for_timeout(200)
    ok(a.evaluate("[...document.querySelectorAll('#exbpilot_box [data-thk]')].every(i=>i.disabled)&&!document.querySelector('#exbpilot_box button.primary')"),'sans droit d\'écriture : seuils en lecture seule, bouton Enregistrer absent')
    a.evaluate("EXBPILOT.thReset('PRJ_EV1')"); ok(nth()==0,'sans droit d\'écriture : action directe refusée')
    a.evaluate("window.EXBDB=Object.assign({},window.EXBDB,{can:()=>true})")

    # --- droits : une fonction sans lecture du budget ne voit ni le bouton ni les chiffres ---
    a.evaluate("window.EXBDB=Object.assign({},window.EXBDB,{can:(c)=>c!=='budgets_chantier'})")
    a.evaluate("EXBPILOT.render()")
    ok('Accès réservé' in a.evaluate("document.getElementById('exbpilot_box').innerText"),'sans droit de lecture du budget : écran refusé, aucun chiffre')
    ok(a.evaluate("EXBPILOT.aiContext()==='' && EXBPILOT.synthese()===''"),'sans droit : rien n\'est transmis à l\'assistant ni synthétisé')
    ok(not ae,'pilotage : aucune erreur JavaScript '+str(ae[:2]))
    b.close()
print('\nRésultat :','ÉCHEC' if fails else 'tout passe'); sys.exit(1 if fails else 0)
