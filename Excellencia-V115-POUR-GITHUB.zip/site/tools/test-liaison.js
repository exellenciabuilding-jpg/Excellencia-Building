#!/usr/bin/env node
/* Test des parcours d'interconnexion (bac à sable Node, stockage simulé). Usage : node tools/test-liaison.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');let fails=0,passes=0;
const ok=(c,m,d)=>{if(c){passes++;console.log('  OK   '+m)}else{fails++;console.log('  FAIL '+m+(d?' — '+d:''))}};
function boot(seed){const mem=Object.assign({},seed||{});const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
 const saves=[];const w={localStorage:ls,exbStorage:ls,save:(k,v)=>{saves.push(k);ls.setItem(k,JSON.stringify(v))},dispatchEvent(){},Event:function(){},confirm:()=>true,setInterval:()=>0,setTimeout:()=>0};
 w.window=w;w.globalThis=w;const ctx=vm.createContext(w);
 vm.runInContext('Event=function(){}',ctx);
 vm.runInContext(fs.readFileSync(path.join(root,'exb-liaison.js'),'utf8'),ctx,{filename:'exb-liaison.js'});return{w,mem,saves,L:w.EXBLIEN,get:k=>JSON.parse(mem[k]||'[]')}}
const J=o=>JSON.stringify(o);
const clients=[{id:'CLI-1',full_name:'Marie Kabongo',phone:'+243 81 000 0001',email:'marie@ex.cd'},{id:'CLI-2',full_name:'Société Beta',company:'Beta SARL',phone:'0990000002'},{id:'CLI-3',full_name:'Jean Doe',phone:'111'},{id:'CLI-4',full_name:'Jean Doe',phone:'222'}];
const seed=()=>({exb_clients:J(clients),
 exb_projects:J([{id:'PRJ-1',name:'Villa Gombe',client:'marie kabongo'},{id:'PRJ-2',name:'Entrepôt Limete',client:'Beta SARL'},{id:'PRJ-3',name:'Chantier Z',client:'Jean Doe'}]),
 exb_quotes:J([{id:'DEV-1',no:'D-001',client:'Marie Kabongo',project:'Villa Gombe',currency:'USD',total:10000,lines:[]},{id:'DEV-2',no:'D-002',client:'Beta SARL',project:'Entrepôt Limete',currency:'USD',total:5000},{id:'DEV-3',no:'D-003',client:'Marie Kabongo',project:'Villa Gombe',currency:'CDF',total:2000000,approved:true}]),
 exb_studies:J([{id:'BE-1',project:'Villa Gombe',client:'Marie Kabongo'}]),
 exb_invoices:J([{id:'FAC-1',no:'F-001',project_id:'PRJ-1',client:'Marie Kabongo',currency:'USD',tva:0,lines:[{q:1,pu:4000}],payments:[{id:'PAY-A',date:'2026-10-01',amount:1000,method:'cash'}]}]),
 exb_cash:J([{id:'CASH-A',date:'2026-10-01',type:'in',label:'Encaissement facture F-001',amount:1000,project_id:'PRJ-1',invoice_id:'FAC-1',pay_id:'PAY-A'},{id:'CASH-X',date:'2026-10-02',type:'in',label:'Don libre',amount:50}]),
 exb_v93_payments:J([{id:'P93-1',direction:'in',status:'pending',amount:700,currency:'USD',project_id:'PRJ-2'},{id:'P93-2',direction:'in',status:'confirmed',amount:300,currency:'USD',project_id:'PRJ-2',confirmed_at:'2026-10-03T10:00:00Z'}])});
console.log('\n# Parcours 1 — rattachement automatique (client ↔ chantier ↔ devis ↔ études ↔ factures)');
let t=boot(seed());let r=t.L.linkAll();
ok(t.get('exb_projects')[0].client_id==='CLI-1'&&t.get('exb_projects')[1].client_id==='CLI-2','projets rattachés à leur client (insensible à la casse, via raison sociale)');
ok(!t.get('exb_projects')[2].client_id&&r.ambigus.length>=1,'nom de client ambigu (2 « Jean Doe ») : aucun rattachement deviné, anomalie signalée');
ok(t.get('exb_quotes').every(q=>q.client_id&&q.project_id),'devis : client_id et project_id renseignés');
ok(t.get('exb_studies')[0].client_id==='CLI-1'&&t.get('exb_studies')[0].project_id==='PRJ-1','étude technique reliée au client et au chantier');
ok(t.get('exb_invoices')[0].client_id==='CLI-1'&&t.get('exb_invoices')[0].client_snapshot==='Marie Kabongo','facture : client_id + nom d’origine conservé');
ok(t.get('exb_cash')[0].client_id==='CLI-1','encaissement de caisse rattaché au client via la facture');
ok(t.get('exb_v93_payments')[1].client_id==='CLI-2','paiement V93 rattaché au client via le chantier');
const before=J([t.get('exb_projects'),t.get('exb_quotes')]);const r2=t.L.linkAll();
ok(r2.total===0&&J([t.get('exb_projects'),t.get('exb_quotes')])===before,'idempotent : 2e passage ne modifie rien (pas de boucle de synchronisation)');
ok(t.get('exb_projects')[0].name==='Villa Gombe'&&t.get('exb_quotes')[0].client==='Marie Kabongo','aucun nom ni montant existant modifié');

console.log('\n# Parcours 2 — registre financier : devis ≠ paiement, sans doublon');
let s=t.L.situation({clientId:'CLI-1'}).total;
ok(s.USD.devis===10000&&s.USD.facture===4000&&s.USD.verse===1000&&s.USD.solde===3000&&s.USD.aFacturer===6000,'USD : devis 10000 / facturé 4000 / versé 1000 / solde 3000 / reste à facturer 6000',J(s.USD));
ok(s.CDF.devis===2000000&&s.CDF.verse===0,'devise CDF séparée, aucun versement fictif depuis le devis');
ok(t.L.ledger().rows.filter(x=>x.invoice_id==='FAC-1').length===1,'même paiement vu par facture + caisse : compté une seule fois');
let b=t.L.situation({clientId:'CLI-2'}).total;
ok(b.USD.verse===300,'paiement V93 : seul le « confirmé » (300) compte, le « en attente » (700) est exclu',J(b.USD));
ok(t.L.ledger().nonRattaches.length===1,'« Don libre » sans client ni chantier signalé comme non rattaché');

console.log('\n# Parcours 3 — paiement saisi une seule fois, mis à jour partout');
t.L.recordPayment({invoice_id:'FAC-1',amount:1500,method:'bank',date:'2026-10-10',idem:'IDEM-1'});
s=t.L.situation({clientId:'CLI-1'}).total;ok(s.USD.verse===2500&&s.USD.solde===1500,'versé 2500, solde 1500 après paiement',J(s.USD));
let dup=t.L.recordPayment({invoice_id:'FAC-1',amount:1500,idem:'IDEM-1'});
ok(dup.duplicate===true&&t.L.situation({clientId:'CLI-1'}).total.USD.verse===2500,'rejeu du même paiement (même clé) : aucun doublon');
ok(t.get('exb_invoices')[0].payments.length===2&&t.get('exb_cash').filter(x=>x.invoice_id==='FAC-1').length===2,'facture et caisse alimentées ensemble, avec le même identifiant de paiement');
ok(t.L.situation({projectId:'PRJ-1'}).total.USD.verse===2500,'situation du chantier actualisée');
let e1='';try{t.L.recordPayment({invoice_id:'FAC-1',amount:9999})}catch(e){e1=e.message}ok(/dépasse/.test(e1),'versement supérieur au solde de la facture refusé');
e1='';try{t.L.recordPayment({amount:10})}catch(e){e1=e.message}ok(/rattaché/.test(e1),'paiement sans client ni chantier refusé');
e1='';try{t.L.recordPayment({invoice_id:'FAC-1',amount:-5})}catch(e){e1=e.message}ok(/invalide/.test(e1),'montant négatif refusé');
const t2=boot(seed());t2.w.EXB_CORE={can:()=>false};e1='';try{t2.L.recordPayment({client_id:'CLI-1',amount:5})}catch(e){e1=e.message}ok(/Droits/.test(e1),'utilisateur sans droit « paiements » : refusé');

console.log('\n# Parcours 4 — modification client répercutée, documents émis préservés');
t=boot(seed());t.L.linkAll();let cl=t.get('exb_clients');cl[0].full_name='Marie Kabongo-Tshala';t.mem.exb_clients=J(cl);let pr=t.L.propagateClient('CLI-1');
ok(t.get('exb_projects')[0].client==='Marie Kabongo-Tshala'&&t.get('exb_studies')[0].client==='Marie Kabongo-Tshala','nouveau nom répercuté sur chantier et étude');
ok(t.get('exb_quotes').find(q=>q.id==='DEV-1').client==='Marie Kabongo-Tshala'&&t.get('exb_quotes').find(q=>q.id==='DEV-3').client==='Marie Kabongo','devis brouillon mis à jour ; devis approuvé conserve sa version d’origine');
ok(t.get('exb_invoices')[0].client==='Marie Kabongo'&&t.get('exb_invoices')[0].client_id==='CLI-1','facture émise inchangée, toujours reliée par identifiant');
ok(t.get('exb_quotes').find(q=>q.id==='DEV-1').client_snapshot==='Marie Kabongo','nom d’origine gardé dans client_snapshot');
ok(t.L.situation({clientId:'CLI-1'}).total.USD.devis===10000,'après renommage, la situation financière suit toujours le bon client');
ok(t.L.journal().length>=1,'historique des opérations conservé');

console.log('\n# Parcours 5 — cohérence / hors connexion');
t=boot(seed());t.L.linkAll();const A=t.mem.exb_projects;const t3=boot(seed());t3.L.linkAll();
ok(t3.mem.exb_projects===A&&t3.mem.exb_quotes===t.mem.exb_quotes,'deux appareils partant des mêmes données obtiennent exactement les mêmes liens (pas de conflit à la synchronisation)');
const off=boot(seed());off.L.linkAll();off.L.recordPayment({invoice_id:'FAC-1',amount:100,idem:'OFF-1'});const sv=off.saves.slice();
ok(sv.includes('exb_invoices')&&sv.includes('exb_cash'),'paiement hors connexion : écrit via save() donc pris en charge par la synchronisation existante');
ok(t.L.anomalies().some(x=>/Jean Doe/.test(x)),'anomalies listées pour la direction (nom ambigu)');
console.log('\nRésultat liaison : '+passes+' contrôles réussis, '+fails+' échec(s).');process.exit(fails?1:0);
