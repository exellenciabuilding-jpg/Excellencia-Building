/* Tests du moteur de planning (node tools/test-cpm.js) — réseaux dessinés à la main. */
const C=require('../exb-cpm.js');let ko=0;
const eq=(a,b,m)=>{const ok=JSON.stringify(a)===JSON.stringify(b);console.log((ok?'  OK   ':'  FAIL ')+m+(ok?'':` (obtenu ${JSON.stringify(a)}, attendu ${JSON.stringify(b)})`));if(!ok)ko++};
// Réseau : 1(2s) → 2(3s) → 4(1s) ; 1 → 3(1s) → 4 ; la branche 2 est critique (2+3+1=6), la branche 3 a 2 sem. de marge
let t=[{start:1,dur:2,pct:0,pred:''},{start:1,dur:3,pct:0,pred:'1'},{start:1,dur:1,pct:0,pred:'1'},{start:1,dur:1,pct:0,pred:'2, 3'}];
let r=C.compute(t,0);
eq(r.fin,6,'durée du projet = 6 semaines');eq(r.critiques,[1,2,4],'chemin critique = 1 → 2 → 4');
eq(r.tasks.map(x=>x.marge),[0,0,2,0],'marges : 0, 0, 2, 0');eq([r.tasks[1].es,r.tasks[1].ef],[3,5],'tâche 2 : semaines 3 à 5');eq(r.tasks[3].es,6,'tâche 4 commence à la semaine 6');
// décalage (lag) et chevauchement
r=C.compute([{start:1,dur:2,pred:''},{start:1,dur:2,pred:'1+1'}],0);eq(r.tasks[1].es,4,'lag +1 : 2e tâche en semaine 4');
r=C.compute([{start:1,dur:3,pred:''},{start:1,dur:2,pred:'1-1'}],0);eq(r.tasks[1].es,3,'lag −1 (chevauchement) : 2e tâche en semaine 3');
// contrainte « ne pas commencer avant »
r=C.compute([{start:1,dur:1,pred:''},{start:5,dur:1,pred:'1'}],0);eq(r.tasks[1].es,5,'début saisi = « pas avant la semaine 5 »');
// conflit : début saisi trop tôt par rapport aux dépendances
r=C.compute([{start:1,dur:3,pred:''},{start:2,dur:1,pred:'1'}],0);eq(r.conflits,[2],'conflit détecté : tâche 2 commence avant la fin de la 1');
// cycle
r=C.compute([{start:1,dur:1,pred:'2'},{start:1,dur:1,pred:'1'}],0);eq([r.error,r.cycle],['cycle',[1,2]],'cycle détecté (1 ↔ 2)');
// prédécesseurs invalides
eq(C.parsePred('1, x, 9, 2+1',3,2).bad,['x','9'],'prédécesseurs invalides signalés (texte, n° inexistant)');eq(C.parsePred('1',3,0).bad,['1'],'une tâche ne peut pas dépendre d\'elle-même');eq(C.parsePred('1, 3-1',4,1).list,[{i:0,lag:0},{i:2,lag:-1}],'lecture « 1, 3-1 »');
// retard prévisionnel : semaine 3, tâche 1 (2 sem.) à 0 % → doit commencer maintenant
r=C.compute([{start:1,dur:2,pct:0,pred:''},{start:3,dur:2,pct:0,pred:'1'}],3);eq([r.fin,r.finPrevue,r.retardProjet],[4,6,2],'retard prévisionnel : +2 semaines');
r=C.compute([{start:1,dur:2,pct:100,pred:''},{start:3,dur:2,pct:50,pred:'1'}],4);eq(r.retardProjet,0,'à l\'heure : aucun retard');
r=C.compute([{start:1,dur:4,pct:25,pred:''},{start:5,dur:1,pct:0,pred:'1'}],3);eq(r.retardProjet,1,'tâche 1 à 25 % en S3 : 3 sem. restantes → fin S5, +1');
// recalage et enchaînement
eq(C.recaler([{start:1,dur:2,pred:''},{start:1,dur:3,pred:'1'}]).starts,[1,3],'recalage : débuts au plus tôt selon les liens');
eq(C.enchainer([{pred:''},{pred:''},{pred:'1'}]),['','1','1'],'enchaîner : chaque tâche sans lien suit la précédente');
eq(C.apresSuppression([{pred:''},{pred:'1'},{pred:'2, 1+1'}],2).join('|'),'|1|1+1','suppression de la tâche 2 : liens renumérotés');
console.log('\nRésultat :',ko?ko+' échec(s)':'tout passe');process.exit(ko?1:0);
