#!/usr/bin/env python3
"""Test navigateur de la tranche 4 : carte « Clients en double » (fusion par clic), « Dossier chantier connecté », chantiers V93.
Usage : python3 tools/e2e-liaison-4.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m,d=''):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m+('' if c or not d else ' — '+str(d)))
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.on('dialog',lambda d:d.accept())
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(5000)
    ok(not errs,'chargement sans erreur JavaScript',errs[:2])
    ok(pg.evaluate("()=>!!(window.EXBLIEN&&EXBLIEN.dup&&EXBLIEN.v4)"),'extension tranche 4 chargée')
    pg.evaluate("""()=>{
      exbClients.push({id:'CLI-1',full_name:'Marie Kabongo',phone:'0810000001'},{id:'CLI-2',full_name:'Marie K.',phone:'+243 81 000 0001',email:'m@x.cd',address:'Gombe'},{id:'CLI-3',full_name:'Autre',phone:'0899999999'});save('exb_clients',exbClients);
      exbProjects.push({id:'PRJ1',name:'Villa Gombe',client:'Marie Kabongo',client_id:'CLI-1',budget:1000});save('exb_projects',exbProjects);
      exbStorage.setItem('exb_v93_projects',JSON.stringify([{id:'V1',name:'Villa Gombe'}]));
      exbStorage.setItem('exb_v93_tasks',JSON.stringify([{id:'T1',project_id:'V1',progress:40}]));
      exbStorage.setItem('exb_calc_notes',JSON.stringify([{id:'N1',project_id:'PRJ1'}]));
      EXBLIEN.refresh();
    }""")
    pg.wait_for_timeout(6500)
    r=pg.evaluate("""()=>({v93:JSON.parse(exbStorage.getItem('exb_v93_projects'))[0],task:JSON.parse(exbStorage.getItem('exb_v93_tasks'))[0],note:JSON.parse(exbStorage.getItem('exb_calc_notes'))[0],
      dup:!!document.getElementById('exbLienDup'),dupTxt:(document.getElementById('exbLienDup')||{}).innerText||'',prj:!!document.getElementById('exbLienPrj'),btns:document.querySelectorAll('#exbLienDup [data-keep]').length})""")
    ok(r['v93'].get('core_project_id')=='PRJ1' and r['task'].get('core_project_id')=='PRJ1','projet et tâche V93 reliés au projet du logiciel',r)
    ok(r['note'].get('client_id')=='CLI-1','note de calcul reliée au client du chantier',r['note'])
    ok(r['dup'] and r['prj'],'cartes « Clients en double » et « Dossier chantier » ajoutées aux écrans Clients et Projets')
    ok('Clients en double' in r['dupTxt'] and r['btns']==2,'les deux fiches du même téléphone sont proposées (2 boutons)',r['dupTxt'][:160])
    # fusion par clic : garder CLI-2
    pg.evaluate("()=>{document.querySelector('#exbLienDup [data-keep=\"CLI-2\"]').click()}")
    pg.wait_for_timeout(600)
    r=pg.evaluate("()=>({ids:exbClients.map(c=>c.id),prj:exbProjects.find(p=>p.id==='PRJ1').client_id,note:JSON.parse(exbStorage.getItem('exb_calc_notes'))[0].client_id,jr:EXBLIEN.journal().filter(j=>j.op==='client_fusion').length,txt:document.getElementById('exbLienDup').innerText})")
    ok('CLI-1' not in r['ids'] and 'CLI-2' in r['ids'] and 'CLI-3' in r['ids'],'après le clic : la fiche CLI-1 est fusionnée dans CLI-2, CLI-3 intacte',r['ids'])
    ok(r['prj']=='CLI-2' and r['note']=='CLI-2','chantier et note de calcul rattachés au client conservé',r)
    ok(r['jr']==1 and 'Aucun doublon' in r['txt'],'fusion journalisée et carte mise à jour (« Aucun doublon »)',r['txt'][:120])
    # dossier chantier
    pg.evaluate("""()=>{const s=document.getElementById('exbLienPrjSel');s.value='PRJ1';s.onchange()}""")
    t=pg.evaluate("()=>document.getElementById('exbLienPrjOut').innerText")
    ok('Villa Gombe' in t and 'Marie K.' in t and 'Tâches V93' in t,'dossier chantier : nom, client (après fusion) et tuiles V93 affichés',t[:200])
    ok(not errs,'aucune erreur JavaScript pendant tout le parcours',errs[:3])
    b.close()
print('\nRésultat e2e tranche 4 :','tout est OK' if not fails else f'{fails} échec(s)')
raise SystemExit(1 if fails else 0)
