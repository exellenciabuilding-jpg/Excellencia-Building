// Test de l'affichage de la validation sur verification.html (réponses serveur simulées). Usage : node tools/test-verification/test-ing.js (depuis le dossier du site)
const fs=require('fs'),h=fs.readFileSync('verification.html','utf8');
const js=[...h.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).join('\n');
const els={};const mk=id=>els[id]||(els[id]={id,innerHTML:'',className:'',textContent:'',value:'',addEventListener(){},click(){},onclick(){}});
let resp=null;
const env={document:{getElementById:mk},window:{EXB_SUPABASE:{url:'http://x',key:'k'}},location:{search:'',hash:''},URLSearchParams,setTimeout,Promise,fetch:()=>Promise.resolve({ok:true,json:()=>Promise.resolve(resp)}),AbortController:undefined};
const src=js.replace(/\nrun\(\);\n\}\)\(\);/,'\nglobalThis.__ing=ing;})();').replace(/^\(function\(\)\{/m,'(function(){');
const f=new Function(...Object.keys(env),src+';return {ing:globalThis.__ing};');
const {ing}=f(...Object.values(env));
// remplace rpc par un simulacre
const cases=[
 ['validé, dernière version, imprimé validé',{found:true,statut:'valide',statut_imprime:'valide',indice:'A',ing_nom:'Ing. X',ing_ordre:'OI-1',derniere_version:true,date:'2026-10-16T10:00:00Z'},/Validé par un ingénieur/,'ban ok'],
 ['imprimé validé mais serveur refusé',{found:true,statut:'refuse',statut_imprime:'valide',indice:'A',derniere_version:true},/non conforme/,'ban ko'],
 ['ancienne version',{found:true,statut:'valide',statut_imprime:'valide',indice:'A',derniere_version:false,version_actuelle:{indice:'B',statut:'verif'}},/Ancienne version/,'ban wn'],
 ['imprimé avant validation',{found:true,statut:'valide',statut_imprime:'emis',indice:'A',derniere_version:true},/avant la validation|imprimé avant/,'ban wn'],
 ['non validé',{found:true,statut:'emis',statut_imprime:'emis',indice:'A',derniere_version:true},/Non validé/,'ban wn'],
];
(async()=>{let bad=0;
 for(const [n,r,re,k] of cases){resp=r;els.ban=mk('ban');els.ban.innerHTML='';
  // reconstruit avec la même source pour que rpc lise resp
  const g=new Function(...Object.keys(env),src+';return {ing:globalThis.__ing};');
  const {ing:ing2}=g(...Object.values(env));
  ing2({kc:'g',no:'NCS-2026-001',hash:'CODE0001AB'});
  await new Promise(r=>setTimeout(r,20));
  const okk=re.test(els.ban.innerHTML)&&els.ban.className.includes(k.split(' ')[1]);
  console.log(okk?'OK  ':'ECHEC',n,'->',els.ban.className,'|',els.ban.innerHTML.slice(0,70));if(!okk)bad++;}
 // doc non-calcul : aucun appel
 const g=new Function(...Object.keys(env),src+';return {ing:globalThis.__ing};');els.ing=mk('ing');els.ing.innerHTML='';resp={found:true,statut:'valide'};g(...Object.values(env)).ing({kc:'d',no:'F-1',hash:'x'});await new Promise(r=>setTimeout(r,20));
 console.log(els.ing.innerHTML===''?'OK   kc≠g : bloc absent':'ECHEC kc≠g');process.exit(bad?1:0)})();
