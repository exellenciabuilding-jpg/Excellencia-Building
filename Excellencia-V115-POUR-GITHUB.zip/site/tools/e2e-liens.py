import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
EXP={'formateurs':'formateur.html','clients':'client.html','rh':'personnel.html','tpTd':'demande-tp-td.html','participants':'inscription.html','projets':'btp.html'}
with sync_playwright() as p:
    b=p.chromium.launch()
    a=b.new_page(viewport={'width':1100,'height':900}); errs=[]
    a.on('pageerror',lambda e:errs.append(str(e)[:200]))
    got=[]
    a.on('dialog',lambda d:(got.append(d.message+' '+(d.default_value or '')),d.accept('TestLocal#2026')) if d.type=='prompt' else d.accept())
    a.route('**/rest/v1/**',lambda r:r.fulfill(status=200,content_type='application/json',body='[]'))
    a.route('**/auth/**',lambda r:r.fulfill(status=400,body='{}'))
    a.add_init_script("""setInterval(()=>{['exbLicLock','exbLock'].forEach(i=>{const d=document.getElementById(i);if(d)d.remove()})},200);
      Object.defineProperty(navigator,'clipboard',{value:{writeText:t=>{window.__clip=t;return Promise.resolve()}},configurable:true});
      try{localStorage.setItem('EXB_SB_TOKEN',JSON.stringify({access_token:'x',refresh_token:'y',expires_at:9999999999,user:{email:'admin@test.com'}}))}catch(e){}""")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    ok(not errs,'aucune erreur JS '+str(errs[:2]))
    # 1) boutons exbUnifiedLink de chaque onglet
    for sec,f in EXP.items():
        if sec in('projets',):continue
        a.evaluate("s=>{window.show(s)}",sec); a.wait_for_timeout(300)
        a.evaluate("()=>{window.__clip=''}")
        # clic réel sur le bouton « Copier le lien » visible dans la section
        btn=a.locator(f'#{sec} button[onclick^="exbUnifiedLink(0"]').first
        if sec=='participants':
            a.evaluate("s=>window.show(s)",'participantForm'); a.wait_for_timeout(300)
            btn=a.locator('#participantForm button[onclick^="exbUnifiedLink(0"]').first
        if btn.count()==0: ok(False,f'{sec}: bouton introuvable'); continue
        btn.click(); a.wait_for_timeout(300)
        clip=a.evaluate("()=>window.__clip")
        ok(clip.endswith('/'+f),f'{sec}: lien copié = {clip}')
    # 2) boutons des boîtes « Demandes en ligne »
    TYPES={'participants':'inscription.html','tpTd':'demande-tp-td.html','formateurs':'formateur.html','clients':'client.html','rh':'personnel.html','projets':'btp.html'}
    for sec,f in TYPES.items():
        a.evaluate("s=>window.show(s)",sec); a.wait_for_timeout(500)
        a.evaluate("()=>{window.__clip=''}")
        btn=a.locator(f'#{sec} .exbInbox button[data-act="copy"]').first
        if btn.count()==0: print('  ..   boîte absente pour',sec,'(non connecté ?)'); continue
        btn.click(); a.wait_for_timeout(300)
        clip=a.evaluate("()=>window.__clip")
        ok(clip.endswith('/'+f),f'boîte {sec}: lien copié = {clip}')
    b.close()
print('ÉCHECS:',fails)
