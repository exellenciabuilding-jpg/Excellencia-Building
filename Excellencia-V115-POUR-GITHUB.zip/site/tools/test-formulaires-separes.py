#!/usr/bin/env python3
"""Chaque lien = un seul formulaire (inscription.html?type=…, fichier hors ligne par profil). python3 tools/test-formulaires-separes.py"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails; print(('  OK   ' if c else '  FAIL ')+m); fails+= 0 if c else 1
B=f'http://127.0.0.1:{PORT}'
FS="()=>[...document.querySelectorAll('fieldset[data-k]')].filter(f=>!f.hidden&&!f.disabled).map(f=>f.getAttribute('data-k'))"
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':400,'height':800}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
    print('# Formulaire en ligne : un lien = un formulaire')
    for k in ['apprenant','tp_td','formateur','client','personnel','logiciel','projet']:
        pg.goto(f'{B}/inscription.html?type={k}'); pg.wait_for_timeout(250)
        ok(pg.evaluate(FS)==[k] and not pg.is_visible('#kinds') and not pg.is_visible('#chooser'),f'?type={k} : seul son formulaire, aucun menu des autres profils')
    pg.goto(f'{B}/inscription.html'); pg.wait_for_timeout(250)
    ok(pg.evaluate(FS)==['apprenant'] and not pg.is_visible('#chooser'),'ancien lien sans type : formulaire apprenant seul (plus de menu)')
    ok('Mes épreuves' not in pg.inner_text('body') and 'Mes résultats' not in pg.inner_text('body'),'aucun lien vers épreuves / résultats dans un formulaire')
    pg.goto(f'{B}/inscription.html?type=choix'); pg.wait_for_timeout(250)
    ok(pg.is_visible('#chooser'),'menu complet seulement via ?type=choix (personnel)')
    print('# Fichier hors connexion par profil')
    pg.goto(f'{B}/formulaire-hors-connexion.html?type=formateur'); pg.wait_for_timeout(250)
    ok(not pg.is_visible('#kinds') and 'Fiche formateur' in pg.inner_text('#tag'),'hors ligne ?type=formateur : seul le formulaire formateur')
    pg.goto(f'{B}/formulaire-hors-connexion.html'); pg.wait_for_timeout(250)
    ok(pg.is_visible('#kinds'),'fichier générique inchangé (menu) tant qu’aucun profil n’est fixé')
    pg.set_content(open('formulaire-hors-connexion.html',encoding='utf-8').read().replace("/*ONLY*/''/*ENDONLY*/","/*ONLY*/\"client\"/*ENDONLY*/")); pg.wait_for_timeout(250)
    ok(not pg.is_visible('#kinds') and 'Fiche client' in pg.inner_text('#tag'),'fichier préparé pour « client » : seul le formulaire client')
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2]))
    b.close()
print('\n'+(str(fails)+' ÉCHEC(S)' if fails else 'Tout est OK')); sys.exit(1 if fails else 0)
