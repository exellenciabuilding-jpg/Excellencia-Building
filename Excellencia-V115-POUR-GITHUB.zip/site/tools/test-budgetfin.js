/* Test du module Budget & pilotage financier (V99zzb) : node tools/test-budgetfin.js */
const assert=require('assert');let n=0;const ok=(c,m)=>{assert(c,m);n++};const eq=(a,b,m)=>{assert.deepStrictEqual(a,b,m+' : '+JSON.stringify(a)+' ≠ '+JSON.stringify(b));n++};const near=(a,b,m)=>{assert(Math.abs(a-b)<0.005,m+' : '+a+' ≠ '+b);n++};
const store={};global.window=global;global.localStorage={getItem:k=>store['LS'+k]||null,setItem:(k,v)=>{store['LS'+k]=v}};
global.load=(k,d)=>store[k]!==undefined?JSON.parse(JSON.stringify(store[k])):d;global.save=(k,v)=>{store[k]=JSON.parse(JSON.stringify(v));return true};
global.notify=()=>{};global.exbId=p=>p+'-'+Math.random().toString(36).slice(2,8);
global.document={getElementById:()=>null,readyState:'complete',body:null,querySelector:()=>null};
const Y=new Date().getFullYear(),ym=Y+'-03',pm=Y+'-02';
global.exbCash=[
 {id:'c1',date:ym+'-02',type:'in',label:'Encaissement facture FAC-1 — Villa',amount:1000,invoice_id:'i1'},
 {id:'c2',date:ym+'-05',type:'in',label:'Vente matériel ancien',amount:200},
 {id:'c3',date:ym+'-06',type:'out',label:'Loyer bureau mars',amount:300},
 {id:'c4',date:ym+'-07',type:'out',label:'Achat ciment 20 sacs',amount:150},
 {id:'c5',date:ym+'-08',type:'out',label:'Carburant groupe',amount:50,cat:'Transport & carburant',bf:1},
 {id:'c6',date:ym+'-09',type:'out',label:'Réparation imprévue',amount:40},
 {id:'c7',date:pm+'-10',type:'out',label:'Salaire ouvriers',amount:500}];
global.exbSave=(k,v)=>save(k,v);
store.exb_payments=[{amount:120,date:ym+'-03',participant_name:'Jean',training:'Métré'}];
store.exb_finance=[{type:'taux',rate:2800,date:'2020-01-01'}];
store.exb_clients=[{id:'cl1',full_name:'Marie Kabila',company:'Kabila Construct',phone:'1',email:'a@b.c',address:'Kin'}];
store.exb_projects=[{id:'p1',name:'Villa Kabila',client:'Kabila Construct'}];
store.exb_invoices=[
 {id:'i1',no:'FAC-1',client:'Kabila Construct',date:ym+'-01',due:ym+'-28',tva:16,currency:'USD',lines:[{q:1,pu:1000}],payments:[{amount:1160}]},
 {id:'i2',no:'FAC-2',client:'Marie Kabila',date:ym+'-10',due:'2000-01-01',tva:16,currency:'USD',lines:[{q:2,pu:500}],payments:[{amount:100}]},
 {id:'i3',no:'FAC-3',client:'Kabila Construct',date:ym+'-12',tva:0,currency:'FC',lines:[{q:1,pu:2800000}],payments:[]},
 {id:'i4',no:'FAC-4',client:'Autre SA',date:ym+'-15',tva:16,currency:'USD',lines:[{q:1,pu:100}],payments:[],annule:true}];
require('../exb-budgetfin.js');const T=window.EXBBF._t;
/* entrées */
const E=T.entries();eq(E.length,8,'8 mouvements (7 caisse + 1 apprenant)');
eq(E.find(e=>e.lab.startsWith('Encaissement')).cat,'Encaissements factures chantier','cat facture');
eq(E.find(e=>/ciment/.test(e.lab)).cat,'Matériaux','cat ciment');
/* budget mensuel */
const c=T.calcMonth(ym,E);
near(c.G.rev.real+c.unIn,1320,'revenus réels = 1000+200+120');
const L=n=>c.lines.find(l=>l.label===n);
near(L('Encaissements factures chantier').auto,1000,'ligne factures');near(L('Formations (apprenants)').auto,120,'ligne formations');
near(L('Loyer & charges').auto,300,'loyer');near(L('Matériaux').auto,150,'matériaux');near(L('Transport & carburant').auto,50,'carburant via cat');
near(c.unOut,40,'dépense non classée');near(c.unIn,0,'recette classée');near(L('Autres recettes').auto,200,'Autres recettes');
near(c.depR,540,'dépenses totales = 300+150+50+40');near(c.resteR,1320-540,'reste à vivre');
/* surcharge manuelle + budget */
const b=T.getB(ym);b.lines.find(l=>l.label==='Matériaux').manual='400';b.lines.find(l=>l.label==='Matériaux').budget=500;store.exb_bf_budgets=[b];
const c2=T.calcMonth(ym,E);near(c2.G.var.real,400+50,'manuel remplace auto');near(c2.G.var.budget,500,'budget');
/* aucune double comptabilisation : somme des lignes + non classé = total des mouvements */
const tot=E.filter(e=>e.d.slice(0,7)===ym&&e.t==='out').reduce((s,e)=>s+e.a,0);
const c3=T.calcMonth(pm,E);near(c3.G.fix.real,500,'salaire = dépense fixe du mois précédent');
const sumLines=T.calcMonth(ym,E).lines.filter(l=>l.g!=='rev').reduce((s,l)=>s+l.auto,0)+T.calcMonth(ym,E).unOut;near(sumLines,tot,'pas de double comptage');
/* agrégats */
const a=T.agg(ym+'-01',ym+'-31',E);near(a.in,1320,'agg in');near(a.out,540,'agg out');near(a.res,780,'agg res');near(a.marge,780/1320*100,'marge');
/* devises */
near(T.toUSD(2800000,'FC'),1000,'FC→USD');
/* factures */
const I=store.exb_invoices;eq(T.iStat(I[0]),'Payée','payée');eq(T.iStat(I[1]),'En retard','en retard');eq(T.iStat(I[3]),'Annulée','annulée');
const cl=store.exb_clients[0];ok(T.cMatch(cl,'Kabila Construct')&&T.cMatch(cl,'marie kabila')&&!T.cMatch(cl,'Autre SA'),'rapprochement client');
const R=T.recap(I.filter(i=>T.cMatch(cl,i.client)),Y+'-01-01',Y+'-12-31');
eq(R.n,3,'3 factures du client');eq(R.paid,1,'1 payée');eq(R.unpaid,2,'2 à encaisser');near(R.ttc,1160+1160+1000,'TTC en USD');near(R.pay,1160+100,'encaissé');near(R.due,1060+1000,'reste dû');
/* annuel + TVA */
const AN=T.annual(Y);const m3=AN.rows[2];near(m3.tc,160+160+0,'TVA facturée mars (annulée exclue)');near(m3.in,1320,'annuel recettes mars');
store.exb_bf_tva=[{id:'T',ym:ym,deductible:60}];near(T.annual(Y).rows[2].tv,260,'TVA à reverser');
/* rendu : aucune exception, HTML non vide */
let html={};const box={innerHTML:''};document.getElementById=id=>id==='bf_box'?box:null;
['b','c','a','k'].forEach(t=>{T.ST.tab=t;if(t==='k')T.ST.cid='cl1';T.render();ok(box.innerHTML.length>500&&!/Erreur d'affichage/.test(box.innerHTML),'rendu onglet '+t)});
/* actions : ajout d'une dépense via la caisse */
const before=exbCash.length;document.getElementById=id=>({bf_xd:{value:ym+'-20'},bf_xl:{value:'Test'},bf_xc:{value:'Matériaux'},bf_xa:{value:'12,5'},bf_xm:{value:'Espèces'},bf_box:box})[id]||null;
T.ST.ym=ym;T.ST.tab='b';window.EXBBF.addExp();eq(exbCash.length,before+1,'dépense ajoutée à la caisse');near(exbCash[exbCash.length-1].amount,12.5,'virgule décimale');
global.confirm=()=>true;window.EXBBF.delExp(exbCash[exbCash.length-1].id);eq(exbCash.length,before,'dépense supprimée');ok(exbCash.some(x=>x.id==='c6'),'les autres entrées de caisse restent intactes');
console.log('OK —',n,'contrôles');
