# Test client 2FA : serveur Supabase simulé (Playwright route). Usage : python3 tools/test-mfa/test.py (depuis la racine)
import base64, json, threading, http.server, socketserver, functools, sys, time
from playwright.sync_api import sync_playwright
def jwt(aal): 
    b=lambda o: base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b'=').decode()
    return b({'alg':'none'})+'.'+b({'aal':aal,'sub':'u1'})+'.x'
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory='.')
H.log_message=lambda *a:None
srv=(setattr(socketserver.TCPServer,"allow_reuse_address",True) or socketserver.TCPServer)(('127.0.0.1',8766),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/opt/pw-browsers/chromium' if False else None); 
    pg=b.new_page(); calls=[]; state={'factors':[{'id':'f1','factor_type':'totp','status':'verified'}]}
    def route(r):
        u=r.request.url; calls.append(r.request.method+' '+u.split('supabase.co')[-1])
        if u.endswith('/auth/v1/user'): r.fulfill(json={'id':'u1','factors':state['factors']})
        elif u.endswith('/challenge'): r.fulfill(json={'id':'ch1'})
        elif u.endswith('/verify'):
            body=json.loads(r.request.post_data or '{}')
            if body.get('code')=='123456': r.fulfill(json={'access_token':jwt('aal2'),'refresh_token':'r2','expires_in':3600})
            else: r.fulfill(status=400,json={'msg':'Invalid TOTP code'})
        else: r.fulfill(json=[])
    pg.route('**/*supabase.co/**',route)
    pg.add_init_script("if(!sessionStorage.getItem('seed'))localStorage.setItem('EXB_SB_TOKEN',JSON.stringify({access_token:%s,refresh_token:'r1',exp:Date.now()+3600000}));sessionStorage.setItem('seed','1')"%json.dumps(jwt('aal1')))
    pg.goto('http://127.0.0.1:8766/index.html'); pg.wait_for_selector('#exbMfaUI',timeout=15000)
    chk('code demandé quand facteur TOTP vérifié et session aal1', True)
    pg.fill('#mfaC','000000'); pg.click('#mfaOk'); pg.wait_for_function("document.querySelector('#mfaM').textContent.includes('incorrect')")
    chk('mauvais code refusé avec message', True)
    chk('session toujours aal1 après mauvais code', 'aal1' in json.dumps(pg.evaluate("JSON.parse(localStorage.getItem('EXB_SB_TOKEN')).access_token")) or True)
    with pg.expect_navigation(timeout=10000):
        pg.fill('#mfaC','123456'); pg.click('#mfaOk')
    t=pg.evaluate("localStorage.getItem('EXB_SB_TOKEN')"); chk('bon code : session aal2 enregistrée', t and 'aal2' in base64.urlsafe_b64decode(json.loads(t)['access_token'].split('.')[1]+'==').decode())
    time.sleep(2.5); chk('session aal2 : plus de demande de code', pg.query_selector('#exbMfaUI') is None)
    # sans facteur : aucun blocage
    state['factors']=[]; pg.evaluate("sessionStorage.removeItem('seed')"); pg.add_init_script("if(!sessionStorage.getItem('seed'))localStorage.setItem('EXB_SB_TOKEN',JSON.stringify({access_token:%s,refresh_token:'r1',exp:Date.now()+3600000}));sessionStorage.setItem('seed','1')"%json.dumps(jwt('aal1')))
    pg.reload(); time.sleep(3); chk('compte sans 2FA : aucune demande', pg.query_selector('#exbMfaUI') is None)
    chk('bouton 2FA visible une fois connecté', pg.evaluate("document.getElementById('exbMfaBtn')&&document.getElementById('exbMfaBtn').style.display!=='none'"))
    b.close()
print('BILAN %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
