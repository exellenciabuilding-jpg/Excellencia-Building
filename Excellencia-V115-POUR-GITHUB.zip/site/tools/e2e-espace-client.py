import json, threading, http.server, functools
from playwright.sync_api import sync_playwright
H=functools.partial(http.server.SimpleHTTPRequestHandler,directory=__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'..'))
srv=http.server.ThreadingHTTPServer(('127.0.0.1',8765),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
S='cs_'+'a'*48
content={"ok":True,"kind":"client","titre":"Villa Test","destinataire":"M. Client","publie_le":"2026-10-20T10:00:00Z",
 "contenu":{"entreprise":{"nom":"Excellencia"},"projet":{"nom":"Villa","avancement":40,"debut":"2026-01-10","fin":"2026-12-30"},"documents":[],"finances":[],"journal":[{"d":"2026-10-19","travaux":"Dalle R+1"}]},
 "signatures":[],"messages":[{"de":"entreprise","texte":"Bienvenue","cree_le":"2026-10-20T09:00:00Z"}],"declarations":[]}
calls=[]
def handle(route):
    u=route.request.url; fn=u.split('/rpc/')[-1]; b=json.loads(route.request.post_data or '{}'); calls.append((fn,b))
    r={'client_connexion':{"ok":True,"session":S,"doit_changer":True},'client_changer_mdp':{"ok":True},'portail_lire':content,'client_plans_liste':{'ok':True,'plans':[{'id':'p2','titre':'Plan R+1','version':2,'note':'Poteaux déplacés','mime':'application/pdf','taille':20480,'publie_le':'2026-10-20T12:00:00Z','nouveau':True,'courant':True},{'id':'p1','titre':'Plan R+1','version':1,'note':'','mime':'application/pdf','taille':20000,'publie_le':'2026-10-10T12:00:00Z','nouveau':False,'courant':False}]},'client_plan_lire':{'ok':True,'titre':'Plan R+1','version':2,'mime':'application/pdf','data':'data:application/pdf;base64,JVBERi0xLjQK'}}.get(fn,{"ok":True})
    route.fulfill(status=200,content_type='application/json',body=json.dumps(r))
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page()
    pg.route('**/supabase-config.js',lambda r:r.fulfill(content_type='application/javascript',body='window.EXB_SUPABASE={url:"http://x.test",key:"k"}'))
    pg.route('http://x.test/**',handle)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8765/espace-client.html')
    pg.fill('#mat','cli-2026-0001'); pg.fill('#pw','cli-2026-0001'); pg.click('#bLogin')
    pg.wait_for_selector('#fChange:not([hidden])')
    pg.fill('#pw1','Nouveau#2026x'); pg.fill('#pw2','Nouveau#2026x'); pg.click('#bChange')
    pg.wait_for_url('**/portail.html'); pg.wait_for_selector('#vApp:not([hidden])')
    t=pg.inner_text('#vApp'); print('Calendrier' in t, 'Activité récente' in t, 'Se déconnecter' in t, '40' in t)
    print([c[0] for c in calls], calls[-1][1].get('p_token','')[:6], errs)
    print('plans', 'nouveau' in t.lower() and 'Plans' in t and 'Modifié' in t, 'version 2' in t)
    with pg.expect_download() as dl: pg.click('[data-plan="p2"]')
    print('download', dl.value.suggested_filename, 'client_plan_lire' in [c[0] for c in calls])
    pg.click('#bOut'); pg.wait_for_url('**/espace-client.html'); print('logout ok', pg.evaluate("sessionStorage.getItem('exb_cs')"))
    b.close()
