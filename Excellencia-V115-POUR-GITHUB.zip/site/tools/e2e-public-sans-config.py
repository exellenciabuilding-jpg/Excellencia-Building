#!/usr/bin/env python3
"""Régression : les pages publiques (liens envoyés aux apprenants, formateurs, clients, personnel) ne doivent JAMAIS afficher
l'écran « Bienvenue — configurez le logiciel à votre entreprise » (réservé à l'administrateur et à la page des demandeurs du logiciel : logiciel.html).
Usage : python3 tools/e2e-public-sans-config.py"""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch()
    for f,attendu in [('inscription',False),('apprenant',False),('demande-tp-td',False),('formateur',False),('client',False),('personnel',False),('epreuve',False),('resultats',False),('logiciel',True)]:
        c=b.new_context(); pg=c.new_page()   # contexte neuf = appareil d'un visiteur qui n'a jamais configuré le logiciel
        pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith('http://127.0.0.1') else r.abort())
        pg.goto(f'http://127.0.0.1:{PORT}/{f}.html'); pg.wait_for_timeout(1200)
        v=pg.evaluate("!!document.getElementById('exbBrandUI')")
        ok(v==attendu, f+'.html : '+('écran de configuration présent (page des demandeurs du logiciel)' if attendu else 'aucun écran de configuration pour le visiteur'))
        c.close()
    b.close()
print('Résultat :','tout passe' if not fails else str(fails)+' échec(s)'); sys.exit(1 if fails else 0)
