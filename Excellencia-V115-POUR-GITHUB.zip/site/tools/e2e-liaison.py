#!/usr/bin/env python3
"""Test navigateur de l'interconnexion : vraies fonctions de l'application (saveExbClient, saveExbProject, saveExbQuote, saveExbStudy) puis paiement et panneaux.
Usage : python3 tools/e2e-liaison.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m,d=''):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m+('' if c or not d else ' — '+str(d)))
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200])); pg.on('dialog',lambda d:d.accept())
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(4000)
    ok(not errs,'chargement sans erreur JavaScript',errs[:2])
    ok(pg.evaluate("()=>!!(window.EXBLIEN&&window.EXBLIEN.version)"),'module de liaison chargé')
    r=pg.evaluate("""()=>{
      const set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v};
      set('exb_cli_id','');set('exb_cli_first','Marie');set('exb_cli_last','Kabongo');set('exb_cli_phone','+243810000001');set('exb_cli_email','marie@ex.cd');
      if(typeof clientFullName==='function'){} saveExbClient();
      const cid=exbClients[0]&&exbClients[0].id,nm=exbClients[0]&&exbClients[0].full_name;
      set('exb_prj_id','');set('exb_prj_name','Villa Gombe');const sel=document.getElementById('exb_prj_client');if(sel){sel.innerHTML='<option value="'+nm+'">'+nm+'</option>';sel.value=nm}
      saveExbProject();
      set('exb_q_id','');set('exb_q_client',nm);set('exb_q_project','Villa Gombe');set('exb_q_no','D-001');exbQuoteLines.length=0;exbQuoteLines.push({cat:'Matériaux',d:'Béton',u:'m3',q:10,pu:1000,lot:''});saveExbQuote();
      set('exb_be_id','');set('exb_be_project','Villa Gombe');set('exb_be_client',nm);saveExbStudy();
      return {cid,nm,prj:exbProjects.map(x=>({n:x.name,c:x.client_id})),qt:exbQuotes.map(x=>({c:x.client_id,p:x.project_id})),st:exbStudies.map(x=>({c:x.client_id,p:x.project_id}))}}""")
    print('   ',json.dumps(r,ensure_ascii=False)[:300])
    ok(bool(r['cid']),'client créé via saveExbClient')
    ok(r['prj'] and r['prj'][0]['c']==r['cid'],'projet saisi par nom : client_id ajouté automatiquement')
    ok(r['qt'] and r['qt'][0]['c']==r['cid'] and r['qt'][0]['p'],'devis : client et chantier reliés',r['qt'])
    ok(r['st'] and r['st'][0]['c']==r['cid'] and r['st'][0]['p'],'étude technique : client et chantier reliés',r['st'])
    r=pg.evaluate("""()=>{const pid=exbProjects[0].id,cid=exbClients[0].id;
      exbStorage.setItem('exb_invoices',JSON.stringify([{id:'FAC-T',no:'F-T',project_id:pid,client:exbClients[0].full_name,currency:'USD',tva:0,lines:[{q:1,pu:4000}],payments:[]}]));
      EXBLIEN.linkAll();const a=EXBLIEN.recordPayment({invoice_id:'FAC-T',amount:1000,idem:'E2E-1'});const b=EXBLIEN.recordPayment({invoice_id:'FAC-T',amount:1000,idem:'E2E-1'});
      return {a,b,s:EXBLIEN.situation({clientId:cid}).total,cash:JSON.parse(exbStorage.getItem('exb_cash')||'[]').length}}""")
    ok(r['s'].get('USD',{}).get('verse')==1000 and r['s']['USD']['facture']==4000 and r['s']['USD']['solde']==3000,'paiement : versé 1000, facturé 4000, solde 3000',r['s'])
    ok(r['b']['duplicate'] and r['cash']==1,'rejeu du même paiement : une seule ligne de caisse')
    pg.evaluate("show('clients')");pg.wait_for_timeout(500)
    ok(pg.evaluate("()=>!!document.getElementById('exbLienClient')"),'panneau « Dossier client connecté » présent dans Clients')
    pg.evaluate("()=>{const s=document.getElementById('exbLienSel');s.value=exbClients[0].id;s.onchange()}");pg.wait_for_timeout(300)
    t=pg.evaluate("document.getElementById('exbLienOut').innerText")
    ok('Villa Gombe' in t and '3' in t,'le panneau affiche le chantier et le solde du client',t[:120])
    ok(pg.evaluate("()=>!!document.getElementById('exbLienDir')"),'panneau « Situation financière consolidée » présent côté direction')
    pg.evaluate("""()=>{document.getElementById('exb_cli_id').value=exbClients[0].id;document.getElementById('exb_cli_first').value='Marie';document.getElementById('exb_cli_last').value='Tshala';document.getElementById('exb_cli_phone').value='+243810000001';saveExbClient()}""")
    n=pg.evaluate("()=>({p:exbProjects[0].client,q:exbQuotes[0].client,pc:exbProjects[0].client_id})")
    ok('Tshala' in (n['p'] or ''),'modification de la fiche client répercutée sur le chantier',n)
    ok(not errs,'toujours aucune erreur JavaScript en fin de parcours',errs[:2])
    b.close()
print('\nRésultat e2e liaison :',('ÉCHEC' if fails else 'tout est OK')); raise SystemExit(1 if fails else 0)
