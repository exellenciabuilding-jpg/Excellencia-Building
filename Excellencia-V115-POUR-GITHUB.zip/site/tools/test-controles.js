/* Tests de la logique des contrôles de chantier (node tools/test-controles.js). */
const C=require('../exb-controles.js');let ko=0;
const eq=(a,b,m)=>{const ok=JSON.stringify(a)===JSON.stringify(b);console.log((ok?'  OK   ':'  FAIL ')+m+(ok?'':` (obtenu ${JSON.stringify(a)}, attendu ${JSON.stringify(b)})`));if(!ok)ko++};
let it=r=>r.map(x=>({t:'p',r:x}));
eq(C.resultat(it(['ok','ok','nok','na'])),{ok:2,nok:1,na:1,vide:0,pct:66.7,statut:'Non conforme'},'2 OK, 1 NOK, 1 N/A → 66,7 % non conforme');
eq(C.resultat(it(['ok','ok','na'])).statut,'Conforme','tout contrôlé sans NOK → Conforme');
eq(C.resultat(it(['ok','','na'])).statut,'En cours','un point non contrôlé → En cours');
eq(C.resultat([]).pct,0,'checklist vide → 0 %');
eq(C.ncDepuis({items:[{t:'Aplomb',r:'nok',rem:'écart 3 cm'},{t:'Joints',r:'ok'},{t:'Linteaux',r:'nok',nc:true}]}),[{desc:'Aplomb — écart 3 cm',item:'Aplomb'}],'seuls les NOK sans NC existante créent une non-conformité');
eq([C.enRetard({statut:'ouverte',echeance:'2026-10-01'},'2026-10-14'),C.enRetard({statut:'levee',echeance:'2026-10-01'},'2026-10-14'),C.enRetard({statut:'ouverte',echeance:''},'2026-10-14')],[true,false,false],'retard : échéance dépassée et non levée');
eq(Object.keys(C.MODELES).length>=4&&Object.values(C.MODELES).every(m=>m.items.length>=7),true,'4 modèles de checklist de 7 points ou plus');
console.log('\nRésultat :',ko?ko+' échec(s)':'tout passe');process.exit(ko?1:0);
