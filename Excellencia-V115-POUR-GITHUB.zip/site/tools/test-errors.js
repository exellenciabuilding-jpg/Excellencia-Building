#!/usr/bin/env node
/* Test de exb-errors.js dans un faux navigateur : capture, nettoyage, dédoublonnage, envoi, panneau. Usage : node tools/test-errors.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
let pass=0,fail=0;const ok=(c,m)=>{if(c){pass++;console.log('  OK   '+m)}else{fail++;console.log('  FAIL '+m)}};
function mk(opts){
  opts=opts||{};const store={},L={},calls=[];
  const ls={getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}};
  const w={localStorage:ls,location:{pathname:'/app/index.html',hash:'#devis?x=1'},navigator:{onLine:opts.online!==false,userAgent:'Mozilla/5.0 (Linux; Android 13) Chrome/120.0'},innerWidth:390,innerHeight:800,
    document:{visibilityState:'visible'},console:{error:()=>{}},setTimeout:()=>0,clearTimeout:()=>{},
    addEventListener:(t,f)=>{(L[t]=L[t]||[]).push(f)},
    exbSb:{isIn:()=>opts.in!==false,api:(p,o)=>{calls.push({p,b:JSON.parse(o.body)});return opts.fail?Promise.reject(new Error('x')):Promise.resolve({ok:true})}}};
  w.window=w;const ctx=vm.createContext(w);ctx.setTimeout=(f)=>{return 1};
  vm.runInContext(fs.readFileSync(path.join(__dirname,'..','exb-errors.js'),'utf8'),ctx);
  return {w,store,L,calls,fire:(t,e)=>(L[t]||[]).forEach(f=>f(e))};
}
(async()=>{
console.log('# exb-errors.js');
let t=mk();
ok(!!t.w.EXBERR,'module chargé');
t.fire('error',{error:new Error('Boom jean@exemple.com 123456789 Bearer abc.def'),message:'Boom',target:t.w});
let log=t.w.EXBERR.log();
ok(log.length===1&&log[0].k==='erreur','une erreur capturée');
ok(!/jean@|123456789|abc\.def/.test(log[0].m),'e-mail, nombre long et jeton retirés du message : '+log[0].m);
t.fire('error',{error:new Error('Boom jean@exemple.com 987654321 Bearer zzz.yyy'),target:t.w});
ok(t.w.EXBERR.log().length===1&&t.w.EXBERR.log()[0].n===2,'même erreur dédoublonnée (compteur = 2)');
t.fire('unhandledrejection',{reason:new Error('Promesse KO')});
ok(t.w.EXBERR.log().some(e=>e.k==='promesse'),'promesse rejetée capturée');
t.fire('error',{message:'ResizeObserver loop limit exceeded',target:t.w});
ok(!t.w.EXBERR.log().some(e=>/ResizeObserver/.test(e.m)),'bruit connu ignoré');
t.fire('error',{target:{tagName:'SCRIPT',src:'https://x.test/a.js?token=SECRET'}});
const res=t.w.EXBERR.log().find(e=>e.k==='ressource');
ok(res&&!/SECRET/.test(res.m),'script non chargé noté, sans paramètres d\'adresse');
ok(Object.keys(t.store).every(k=>!/^EXB_V28__/.test(k)),'journal hors zone synchronisée (préfixe EXB_V28__)');
for(let i=0;i<80;i++)t.w.EXBERR.record('erreur','Erreur distincte numéro '+i+' '+'x'.repeat(i),'');
ok(t.w.EXBERR.log().length<=50,'journal limité à 50 entrées');
ok(t.w.EXBERR.usage()[Object.keys(t.w.EXBERR.usage())[0]].sessions===1,'session comptée');

console.log('# envoi');
let r=await t.w.EXBERR.flush();
ok(r===true&&t.calls.length===1&&/erreur_signaler/.test(t.calls[0].p),'envoi via erreur_signaler');
ok(t.calls[0].b.p_items.length<=20,'au plus 20 erreurs par envoi');
ok(!JSON.stringify(t.calls[0].b).match(/jean@|SECRET/),'rien de sensible dans la requête');
ok(t.calls[0].b.p_usage.length===1,'usage du jour envoyé');
const before=t.w.EXBERR.log().filter(e=>!e.s).length;
ok(before<t.w.EXBERR.log().length,'entrées envoyées marquées');
let h=mk({online:false});h.fire('error',{error:new Error('hors ligne'),target:h.w});
ok(await h.w.EXBERR.flush()===false&&h.calls.length===0,'hors ligne : rien envoyé, journal conservé ('+h.w.EXBERR.log().length+')');
let n=mk({in:false});n.fire('error',{error:new Error('non connecté'),target:n.w});
ok(await n.w.EXBERR.flush()===false&&n.calls.length===0,'non connecté : rien envoyé');
let f=mk({fail:true});f.fire('error',{error:new Error('échec réseau'),target:f.w});
ok(await f.w.EXBERR.flush()===false&&f.w.EXBERR.log()[0].s===0,'échec serveur : l\'entrée reste en attente');
console.log('\nRésultat : '+pass+' réussis, '+fail+' échec(s).');process.exit(fail?1:0);
})();
