# Test de bout en bout (navigateur) : circulation des données calcul -> export -> Plans -> V94 -> Bureau d'études -> CDE/BIM -> synchro.
# Depuis la racine : python3 tools/test-flux/test.py
import threading, http.server, socketserver, functools, json
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c,info=''):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n+((' -> '+str(info)) if (info and not c) else ''))
IFC="ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('ViewDefinition [CoordinationView]','EXB-REF=STR-RES-BIM;TITRE=Maquette'),'2;1');\nENDSEC;\nDATA;\n#1=IFCPROJECT('0abcdefghijklmnopqrstu',$,'Res',$,$,$,$,$,$);\nENDSEC;\nEND-ISO-10303-21;\n"
DXF="999\nEXB-REF=STR-RES-PLAN;TITRE=Plan 2D\n0\nSECTION\n2\nENTITIES\n0\nENDSEC\n0\nEOF\n"
answers=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},150)")
    pg.on('dialog',lambda d:d.accept(answers.pop(0) if (d.type=='prompt' and answers) else (d.default_value if d.type=='prompt' else None)))
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function("window.EXBPLN&&window.EXBS&&window.EXB_ARCH",timeout=20000)
    answers.append('TestLocal#2026'); pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(2500)
    # 1. Plans : deux exports successifs du même ouvrage + une maquette IFC
    pg.evaluate("EXBPLN.open()"); pg.wait_for_selector('#plFile',timeout=5000)
    for i in (1,2):
        pg.set_input_files('#plFile',{'name':f'e{i}.dxf','mimeType':'application/dxf','buffer':DXF.encode()}); pg.wait_for_timeout(500)
        pg.evaluate("EXBPLN.add()"); pg.wait_for_timeout(900)
    pg.set_input_files('#plFile',{'name':'maquette.ifc','mimeType':'application/octet-stream','buffer':IFC.encode()}); pg.wait_for_timeout(500)
    pg.evaluate("EXBPLN.add()"); pg.wait_for_timeout(1200)
    F=pg.evaluate("EXBS.get('exb_plan_files')"); R=pg.evaluate("EXBS.get('exb_v94_revisions')"); D=pg.evaluate("EXBS.get('exb_v94_drawings')")
    chk('Plans -> V94 : 3 fichiers rattachés à 2 plans V94 (PLAN : A,B ; BIM : A)',len(F)==3 and all(f.get('revision_id') for f in F) and len(D)==2 and len(R)==3,(len(F),len(D),len(R)))
    rv={r['id']:r for r in R}
    chk('V94 : chaque révision porte l\'identifiant de son fichier',all(rv[f['revision_id']].get('file_id')==f['id'] for f in F))
    # 2. Bureau d'études : le plan issu d'un export est visible, avec ses indices
    N=pg.evaluate("EXB_ARCH.plansNested()"); pl=[x for x in N if x['no']=='STR-RES-PLAN']
    chk('V94 -> Bureau d\'études : le plan exporté apparaît avec ses indices A et B',len(pl)==1 and [v['ind'] for v in pl[0]['versions']]==['A','B'],N)
    # 3. diffusion + visa depuis le Bureau d'études, puis rechargement (persistance)
    pl=pl[0]; pl['versions'][1]['sent'].append({'to':'Client SA','role':'Client','date':'2026-04-01','visa':'Visé avec observations','vdate':'2026-04-03','obs':'RAS sauf P3'})
    pg.evaluate("p=>EXB_ARCH.savePlanNested(p)",pl)
    pg.reload(); pg.wait_for_function("window.EXB_ARCH&&window.EXBS",timeout=20000); pg.wait_for_timeout(800)
    N2=[x for x in pg.evaluate("EXB_ARCH.plansNested()") if x['no']=='STR-RES-PLAN']
    chk('visa BE conservé après rechargement, fichiers toujours liés',len(N2)==1 and N2[0]['versions'][1]['sent'][0]['visa']=='Visé avec observations' and len(pg.evaluate("EXBS.get('exb_v94_revisions').filter(r=>r.file_id)"))==3)
    # 4. CDE + BIM (écrans V68) alimentent V94
    pg.evaluate("exbV68Open()"); pg.wait_for_timeout(300)
    pg.evaluate("EXB_ARCH.addCde({project:'',title:'CCTP gros oeuvre',disc:'Structure',rev:'A',status:'Review'});EXB_ARCH.addBim({project:'',title:'Gaine dans poutre P3',priority:'Haute',status:'Ouvert',disc:'MEP',disc2:'Structure',loc:'R+1'})")
    pg.evaluate("document.querySelector('#exbV68Tabs button[data-t=cde]').click()"); pg.wait_for_timeout(300)
    chk('CDE : le document V94 s\'affiche dans l\'écran V68',('CCTP gros oeuvre' in pg.inner_text('#exbV68Body')))
    pg.evaluate("document.querySelector('#exbV68Tabs button[data-t=bim]').click()"); pg.wait_for_timeout(300)
    chk('BIM : l\'issue V94 s\'affiche dans l\'écran V68',('Gaine dans poutre P3' in pg.inner_text('#exbV68Body')))
    # 5. Modèles BIM : un fichier IFC ajouté dans Plans doit exister comme modèle BIM, et l'issue y être rattachable
    M=pg.evaluate("EXBS.get('exb_v94_bim_models')")
    chk('IFC ajouté dans Plans -> modèle BIM V94 enregistré',len(M)==1 and M[0].get('format')=='IFC',M)
    # 5b. Observation BIM saisie dans l'écran : rattachée au modèle IFC et au GlobalId stable de l'élément
    mid=M[0]['id'] if M else ''
    pg.evaluate("document.querySelector('#exbV68Tabs button[data-t=bim]').click()"); pg.wait_for_timeout(300)
    pg.fill('#v68_title','Poteau A1 mal positionné'); pg.select_option('#v68_model',mid); pg.fill('#v68_guid','0abcdefghijklmnopqrstu')
    pg.evaluate("document.getElementById('v68Save').onclick()"); pg.wait_for_timeout(600)  # (un vrai clic est bloqué par le verrou de licence du banc d'essai)
    iss=pg.evaluate("EXBS.get('exb_v94_bim_issues').find(x=>x.title==='Poteau A1 mal positionné')")
    chk('observation BIM : modèle IFC et GlobalId enregistrés dans V94',iss and iss.get('model_id')==mid and iss.get('element_guid')=='0abcdefghijklmnopqrstu',iss)
    pg.fill('#v68_title','Obs GlobalId faux'); pg.fill('#v68_guid','trop-court')
    pg.evaluate("document.getElementById('v68Save').onclick()"); pg.wait_for_timeout(500)
    chk('GlobalId invalide refusé',not pg.evaluate("EXBS.get('exb_v94_bim_issues').some(x=>x.title==='Obs GlobalId faux')"))
    # 6. Suppression d'un fichier : plus de lien orphelin
    fid=[f for f in F if f['name']=='e2.dxf'][0]['id']
    pg.evaluate("id=>{window.confirm=()=>true;EXBPLN.del(id)}",fid); pg.wait_for_timeout(800)
    orph=pg.evaluate("EXBS.get('exb_v94_revisions').filter(r=>r.file_id&&!EXBS.get('exb_plan_files').some(f=>f.id===r.file_id)).length")
    chk('suppression d\'un fichier : aucune révision ne pointe vers un fichier disparu',orph==0,orph)
    # 7. Suppression d'un plan BE : plus de fichier lié à un plan disparu
    pg.evaluate("EXB_ARCH.deletePlan(EXB_ARCH.plansNested().find(x=>x.no==='STR-RES-BIM').id)")
    orph2=pg.evaluate("EXBS.get('exb_plan_files').filter(f=>f.drawing_id&&!EXBS.get('exb_v94_drawings').some(d=>d.id===f.drawing_id)).length")
    chk('suppression d\'un plan : aucun fichier ne pointe vers un plan disparu',orph2==0,orph2)
    # 8. Synchronisation : toutes les clés concernées sont gérées par la base partagée et exclues de la copie par compte
    h=pg.evaluate("""()=>{const ks=['exb_plan_files','exb_plan_annots','exb_v94_drawings','exb_v94_revisions','exb_v94_visas','exb_v94_distributions','exb_v94_documents','exb_v94_bim_models','exb_v94_bim_issues','exb_cde','exb_bim_issues'];
      return ks.map(k=>[k,!!(window.EXBDB&&EXBDB.handles&&EXBDB.handles(k))])}""")
    chk('synchro : EXBDB déclare gérer les 11 clés plans/CDE/BIM',all(x[1] for x in h),[x[0] for x in h if not x[1]])
    d=pg.evaluate("""()=>{localStorage.setItem('exb_db_on','1');return window.exbSync&&exbSync.skips?['exb_v94_revisions','exb_plan_files','exb_cde'].map(k=>exbSync.skips(k)):null}""")
    chk('synchro : la copie par compte (exb-sync) ignore ces clés quand la base partagée est active',d and all(d),d)
    chk('aucune erreur JavaScript',not errs,errs[:3])
print(f'BILAN FLUX {ok}/{tot}'); srv.shutdown()
