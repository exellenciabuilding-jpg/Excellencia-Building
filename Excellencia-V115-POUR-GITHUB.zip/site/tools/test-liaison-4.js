#!/usr/bin/env node
/* Test de la tranche 4 : chantiers V93, bureau d'études / BIM, dossier chantier, clients en double (fusion).
 * Bac à sable Node, stockage simulé. Usage : node tools/test-liaison-4.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');let fails=0,passes=0;
const ok=(c,m,d)=>{if(c){passes++;console.log('  OK   '+m)}else{fails++;console.log('  FAIL '+m+(d?' — '+d:''))}};
const J=o=>JSON.stringify(o);
function boot(seed){const mem=Object.assign({},seed);const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
 const document={readyState:'complete',getElementById:()=>null,addEventListener(){}};
 const w={localStorage:ls,exbStorage:ls,document,save:(k,v)=>{ls.setItem(k,JSON.stringify(v))},dispatchEvent(){},confirm:()=>true,setInterval:()=>0,setTimeout:f=>{try{f()}catch(e){}return 0}};
 w.window=w;w.globalThis=w;const ctx=vm.createContext(w);vm.runInContext('Event=function(){}',ctx);
 const L=k=>{try{return JSON.parse(mem[k]||'[]')}catch(e){return[]}};
 w.__live={exbClients:L('exb_clients'),exbProjects:L('exb_projects'),exbQuotes:L('exb_quotes'),exbStudies:L('exb_studies'),exbCash:L('exb_cash'),exbHr:L('exb_hr'),participants:L('exb_participants'),formations:L('exb_formations'),trainers:L('exb_trainers'),payments:L('exb_payments'),receipts:L('exb_receipts'),certs:L('exb_certificates'),attendance:[],evaluations:[],cotations:[],schedules:[],tpRequests:[],exbStock:[],exbStockMoves:L('exb_stock_moves')};
 vm.runInContext('var '+Object.keys(w.__live).map(k=>k+'=globalThis.__live.'+k).join(',')+';',ctx);
 ['exb-liaison.js','exb-liaison-edu.js','exb-liaison-3.js','exb-liaison-4.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f}));
 return{w,mem,X:w.EXBLIEN,get:k=>JSON.parse(mem[k]||'[]')}}
const seed=()=>({
 exb_clients:J([{id:'CLI-1',full_name:'Marie Kabongo',phone:'0810000001'},{id:'CLI-2',full_name:'Marie K.',phone:'+243 81 000 0001',email:'m@x.cd'},{id:'CLI-3',full_name:'Paul',phone:'0820000002',email:'M@X.CD',address:'Gombe, Kinshasa'},{id:'CLI-4',full_name:'Jean Dupont'},{id:'CLI-5',full_name:'jean  dupont'},{id:'CLI-6',full_name:'Seul'}]),
 exb_projects:J([{id:'PRJ1',name:'Villa Gombe',client:'Marie K.',client_id:'CLI-2',budget:1000},{id:'PRJ2',name:'Tour Lemba',client:'Paul',client_id:'CLI-3'},{id:'PRJ3',name:'Sans client'}]),
 exb_quotes:J([{id:'Q1',client:'Paul',client_id:'CLI-3',project_id:'PRJ2',total:500,currency:'USD',status:'brouillon'},{id:'Q2',client:'Paul',client_id:'CLI-3',project_id:'PRJ2',total:300,currency:'USD',emis:true,client_snapshot:{name:'Paul'}}]),
 exb_invoices:J([{id:'FA1',no:'FA-1',client_id:'CLI-2',project_id:'PRJ1',lines:[{q:1,pu:2000}],tva:0,payments:[{id:'PAY1',date:'2026-10-10',amount:900}]},{id:'FA2',no:'FA-2',client_id:'CLI-3',project_id:'PRJ2',lines:[{q:1,pu:700}],tva:0,payments:[{id:'PAY2',date:'2026-10-11',amount:100}]}]),
 exb_cash:J([{id:'CA1',type:'in',label:'Acompte',amount:50,client_id:'CLI-3',project_id:'PRJ2'}]),
 exb_v93_projects:J([{id:'V1',name:'villa  gombe'},{id:'V2',name:'Projet inconnu'},{id:'PRJ2',name:'autre nom'}]),
 exb_v93_sites:J([{id:'SI1',project_id:'V1'},{id:'SI2',project_id:'PRJ2'},{id:'SI3',project_id:'ZZ'}]),
 exb_v93_tasks:J([{id:'T1',site_id:'SI1',progress:50},{id:'T2',project_id:'V1',progress:100}]),
 exb_v93_hse:J([{id:'H1',project_id:'V1',status:'open'},{id:'H2',project_id:'V1',status:'closed'}]),
 exb_calc_notes:J([{id:'N1',project_id:'PRJ1'},{id:'N2',project_id:'PRJX'},{id:'N3'}]),
 exb_be_missions:J([{id:'M1',project_id:'PRJ1'}]),
 exb_v94_drawings:J([{id:'D1',project_id:'PRJ1'},{id:'D2',project_id:'PRJX'}]),
 exb_v94_revisions:J([{id:'R1',drawing_id:'D1'},{id:'R2',drawing_id:'D1'},{id:'R3',drawing_id:'D2'}]),
 exb_v94_documents:J([{id:'DC1',project_id:'PRJ1'}]),
 exb_v94_bim_models:J([{id:'B1',project_id:'PRJ1'}]),
 exb_v94_bim_issues:J([{id:'I1',project_id:'PRJ1',status:'open'},{id:'I2',project_id:'PRJ1',status:'closed'}]),
 exb_site_journal:J([{id:'J1',project_id:'PRJ1'},{id:'J2',project_id:'PRJ1'},{id:'J3',project_id:'PRJY'}]),
 exb_timesheets:J([{id:'TS1',project_id:'PRJ1',days:2,cost:40,cash_id:''}]),
 exb_purchase_orders:J([{id:'PO1',no:'BC-1',project_id:'PRJ1'}])
});

console.log('# Chantiers V93 ↔ projets du logiciel');
let t=boot(seed());const V=t.X.v4;
const P93=t.get('exb_v93_projects');
ok(P93[0].core_project_id==='PRJ1'&&P93[0].client_id==='CLI-2','projet V93 relié au projet du logiciel par son nom (espaces et casse ignorés), client repris');
ok(!P93[1].core_project_id,'projet V93 sans équivalent : aucun lien deviné');
ok(P93[2].core_project_id==='PRJ2','projet V93 relié par identifiant identique');
const S93=t.get('exb_v93_sites'),T93=t.get('exb_v93_tasks');
ok(S93[0].core_project_id==='PRJ1'&&S93[1].core_project_id==='PRJ2'&&!S93[2].core_project_id,'chantiers V93 suivent leur projet (identifiant V93 ou projet du logiciel) ; référence inconnue non devinée');
ok(T93[0].core_project_id==='PRJ1'&&T93[1].core_project_id==='PRJ1','tâches V93 reliées via le chantier ou directement via le projet');
ok(t.get('exb_v93_hse')[0].core_project_id==='PRJ1','alertes QHSE V93 reliées');
console.log('\n# Bureau d’études : notes de calcul et missions');
ok(t.get('exb_calc_notes')[0].client_id==='CLI-2'&&!t.get('exb_calc_notes')[1].client_id&&!t.get('exb_calc_notes')[2].client_id,'note de calcul reliée au client du projet ; projet inconnu ou absent : intacte');
ok(t.get('exb_be_missions')[0].client_id==='CLI-2','mission reliée au client du projet');
ok(t.get('exb_v94_drawings')[0].project_id==='PRJ1'&&!('client_id' in t.get('exb_v94_drawings')[0]),'plans / BIM V94 : contrôlés en lecture seule, jamais modifiés');
const b=J([t.get('exb_v93_projects'),t.get('exb_v93_sites'),t.get('exb_calc_notes')]);V.linkAll();
ok(J([t.get('exb_v93_projects'),t.get('exb_v93_sites'),t.get('exb_calc_notes')])===b,'idempotent : un 2e passage ne change rien');

console.log('\n# Anomalies');
const A=V.anomalies().join('\n');
ok(/Projet V93 « Projet inconnu »/.test(A),'projet V93 non relié signalé');
ok(/1 note\(s\) de calcul.*chantier introuvable/.test(A),'note de calcul sur chantier introuvable signalée');
ok(/1 plan\(s\).*introuvable/.test(A),'plan sur chantier introuvable signalé');
ok(/1 entrée\(s\) du journal de chantier.*introuvable/.test(A),'journal de chantier sur chantier introuvable signalé');
ok(/1 tâche\(s\) \/ chantier\(s\) V93.*introuvable/.test(A),'chantier V93 sur projet introuvable signalé');
ok(/groupe\(s\) de clients en double/.test(A),'doublons de clients signalés');
ok(t.X.anomalies().some(x=>/Projet V93/.test(x)),'visible aussi dans la liste centrale « points à vérifier »');

console.log('\n# Dossier chantier');
const D=V.dossier('PRJ1'),tile=n=>(D.tiles.find(x=>x[0].indexOf(n)===0)||[])[1];
ok(D.client==='Marie K.'&&D.budget===1000,'client et budget du chantier');
ok(D.finances.USD&&D.finances.USD.facture===2000&&D.finances.USD.verse===900&&D.finances.USD.solde===1100,'finances : facturé 2000, versé 900, solde 1100',J(D.finances));
ok(tile('Factures')===1&&tile('Notes de calcul')===1&&tile('Plans')===1&&tile('Révisions')===2&&tile('Documents')===1&&tile('Maquettes')===1,'compteurs : factures, notes, plans, révisions (2 de D1 seulement), documents, maquettes');
ok(tile('Problèmes BIM')===1,'problèmes BIM : seul l’ouvert est compté');
ok(tile('Journal')===2&&tile('Commandes')===1&&tile('Missions')===1&&tile('Projet V93')===1,'journal, commandes, missions, projet V93');
ok(tile('Tâches V93')===2&&/avancement 75 %/.test(D.tiles.find(x=>/Tâches V93/.test(x[0]))[0]),'tâches V93 : 2, avancement moyen 75 %');
ok(tile('Alertes QHSE')===1&&tile('Jours pointés')===2,'alertes QHSE ouvertes et jours pointés');
ok(/Villa Gombe/.test(V.dossierHtml('PRJ1'))&&V.dossier('INCONNU')===null,'affichage HTML produit ; chantier inconnu : rien');

console.log('\n# Clients en double');
const G=t.X.dup.groups();
const names=G.map(g=>g.clients.map(c=>c.id).sort().join(',')).sort();
ok(J(names)===J(['CLI-1,CLI-2,CLI-3','CLI-4,CLI-5']),'deux groupes : téléphone + e-mail (écrits différemment) et nom identique',J(names));
ok(!G.some(g=>g.clients.some(c=>c.id==='CLI-6')),'client unique non signalé');
ok(G[0].raisons.length>=1,'raison du rapprochement indiquée',J(G.map(g=>g.raisons)));
const sit=id=>t.X.situation({clientId:id}).total.USD||{};
const before=[sit('CLI-2'),sit('CLI-3')];
const r=t.X.dup.merge('CLI-2',['CLI-1','CLI-3']);
const C=t.get('exb_clients');
ok(C.length===4&&!C.some(c=>c.id==='CLI-1'||c.id==='CLI-3'),'les deux fiches fusionnées sont retirées de la liste',J(C.map(c=>c.id)));
ok(t.get('exb_projects').find(p=>p.id==='PRJ2').client_id==='CLI-2','chantier du client supprimé rattaché au client conservé');
ok(t.get('exb_invoices')[1].client_id==='CLI-2'&&t.get('exb_cash')[0].client_id==='CLI-2'&&t.get('exb_quotes')[0].client_id==='CLI-2','factures, caisse et devis rattachés au client conservé');
ok(t.get('exb_calc_notes')[0].client_id==='CLI-2'&&t.get('exb_v93_projects')[0].client_id==='CLI-2','notes de calcul et projets V93 aussi');
const after=sit('CLI-2');
ok(after.facture===before[0].facture+before[1].facture&&after.verse===before[0].verse+before[1].verse&&after.devis===before[0].devis+before[1].devis,'registre financier : devis, facturé et versé du client conservé = somme des deux (acompte de caisse compris, sans doublon)',J([before,after]));
const keep=C.find(c=>c.id==='CLI-2');
ok(keep.address==='Gombe, Kinshasa'&&keep.email==='m@x.cd'&&keep.phone==='+243 81 000 0001','informations manquantes reprises de la fiche supprimée, existantes conservées',J(keep));
ok(t.get('exb_quotes')[0].client==='Marie K.','devis brouillon : nom mis à jour',t.get('exb_quotes')[0].client);
ok(t.get('exb_quotes')[1].client==='Paul'&&t.get('exb_quotes')[1].client_snapshot.name==='Paul','devis émis : nom d’origine conservé (client_snapshot)');
const jr=t.X.journal().filter(j=>j.op==='client_fusion')[0];
ok(jr&&jr.detail.supprimes.length===2&&jr.detail.supprimes.some(s=>s.id==='CLI-3'&&s.address==='Gombe, Kinshasa'),'journal : fiche complète des clients supprimés conservée');
ok(r.fiches_deplacees>=6,'nombre de fiches déplacées indiqué',String(r.fiches_deplacees));
let err='';try{t.X.dup.merge('CLI-2',['CLI-3'])}catch(e){err=e.message}
ok(/Aucun client à fusionner/.test(err),'fusion d’une fiche déjà supprimée refusée');
err='';try{t.X.dup.merge('CLI-9',['CLI-4'])}catch(e){err=e.message}
ok(/introuvable/.test(err),'client à conserver inconnu : refusé');
t.w.EXB_CORE={can:()=>false};err='';try{t.X.dup.merge('CLI-4',['CLI-5'])}catch(e){err=e.message}
ok(/Droits insuffisants/.test(err)&&t.get('exb_clients').length===4,'sans droit d’écriture sur les clients : fusion refusée, rien modifié');

console.log('\nRésultat liaison tranche 4 : '+passes+' contrôles réussis, '+fails+' échec(s).');process.exit(fails?1:0);
