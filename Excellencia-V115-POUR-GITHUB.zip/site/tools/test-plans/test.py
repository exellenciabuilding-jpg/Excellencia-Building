# Test navigateur : mesure sur plan avec échelle (DXF). Depuis la racine : python3 tools/test-plans/test.py
import threading, http.server, socketserver, functools, sys, math
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
def line(x1,y1,x2,y2): return f"0\nLINE\n8\n0\n10\n{x1}\n20\n{y1}\n11\n{x2}\n21\n{y2}\n"
# dalle de 10 m × 6 m dessinée en millimètres
dxf="0\nSECTION\n2\nENTITIES\n"+line(0,0,10000,0)+line(10000,0,10000,6000)+line(10000,6000,0,6000)+line(0,6000,0,0)+"0\nENDSEC\n0\nEOF\n"
answers=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},150)")  # écran de licence retiré UNIQUEMENT dans ce test
    pg.on('dialog',lambda d:d.accept(answers.pop(0) if (d.type=='prompt' and answers) else (d.default_value if d.type=='prompt' else None)))
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function("window.EXBPLN&&window.EXBS",timeout=20000)
    answers.append('TestLocal#2026'); pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(2500)  # connexion locale (mot de passe par défaut, changement imposé)
    pg.evaluate("EXBPLN.open()"); pg.wait_for_selector('#plFile',timeout=5000)
    pg.set_input_files('#plFile',{'name':'dalle.dxf','mimeType':'application/dxf','buffer':dxf.encode()}); pg.fill('#plRef','PL-TEST')
    pg.evaluate("EXBPLN.add()"); pg.wait_for_timeout(800)
    fid=pg.evaluate("EXBS.get('exb_plan_files').slice(-1)[0].id")
    pg.evaluate("id=>EXBPLN.view(id)",fid); pg.wait_for_selector('#plCv',timeout=8000); pg.wait_for_timeout(500)
    chk('barre d\'outils : échelle, distance, longueur, surface', all(pg.query_selector('#plT'+k) for k in ['scale','dist','poly','area']))
    chk('échelle non définie signalée', 'Échelle non définie' in pg.inner_text('#plMesBar'))
    def at(x,y):  # coordonnées dessin (mm) -> clic écran (mise en page identique à fit())
        r=pg.evaluate("""([x,y])=>{const c=document.getElementById('plCv'),R=c.getBoundingClientRect(),k=c.width/R.width,W=10000,H=6000,s=Math.min(c.width/W,c.height/H)*.92,ox=(c.width-W*s)/2,oy=(c.height+H*s)/2;return [R.left+(x*s+ox)/k,R.top+(-y*s+oy)/k]}""",[x,y])
        pg.evaluate("([x,y])=>{for(let i=0;i<6;i++){let e=document.elementFromPoint(x,y);if(!e||e.id==='plCv')break;(e.closest('[role=status],[class*=toast],[class*=notif]')||e).remove()}}",[r[0],r[1]])  # écarte une notification qui recouvrirait le plan
        pg.mouse.click(r[0],r[1]); pg.wait_for_timeout(120)
    n0=pg.evaluate("(EXBS.get('exb_plan_files').find(x=>x.id===%s).mesures||[]).length"%repr(fid))
    # mesure sans échelle : refusée
    pg.evaluate("EXBPLN.tool('dist')"); at(0,0); at(10000,0)
    chk('mesure sans échelle refusée', pg.evaluate("(EXBS.get('exb_plan_files').find(x=>x.id===%s).mesures||[]).length"%repr(fid))==n0)
    # étalonnage : 10 000 unités = 10 m
    answers.append('10'); pg.evaluate("EXBPLN.tool('scale')"); at(0,0); at(10000,0); pg.wait_for_timeout(300)
    k=pg.evaluate("EXBS.get('exb_plan_files').find(x=>x.id===%s).echelle.k"%repr(fid))
    chk('échelle calibrée : 1 unité = 0,001 m (%s)'%k, abs(k-0.001)<1e-9)
    # distance (diagonale)
    answers.append('Diagonale'); pg.evaluate("EXBPLN.tool('dist')"); at(0,0); at(10000,6000); pg.wait_for_timeout(200)
    # longueur cumulée (2 côtés = 16 m)
    answers.append('Deux côtés'); pg.evaluate("EXBPLN.tool('poly')"); at(0,0); at(10000,0); at(10000,6000); pg.evaluate("EXBPLN.mfin()"); pg.wait_for_timeout(200)
    # surface 60 m²
    answers.append('Dalle'); pg.evaluate("EXBPLN.tool('area')"); at(0,0); at(10000,0); at(10000,6000); at(0,6000); pg.evaluate("EXBPLN.mfin()"); pg.wait_for_timeout(300)
    m=pg.evaluate("EXBS.get('exb_plan_files').find(x=>x.id===%s).mesures"%repr(fid))
    by={x['label']:x for x in m}
    chk('distance diagonale = %.2f m (attendu 11,66)'%by.get('Diagonale',{}).get('val',0), abs(by.get('Diagonale',{}).get('val',0)-math.hypot(10,6))<0.01)
    chk('longueur cumulée = %.2f m (attendu 16,00)'%by.get('Deux côtés',{}).get('val',0), abs(by.get('Deux côtés',{}).get('val',0)-16)<0.01)
    chk('surface = %.2f m² (attendu 60,00)'%by.get('Dalle',{}).get('val',0), abs(by.get('Dalle',{}).get('val',0)-60)<0.01 and by['Dalle']['unit']=='m²')
    tx=pg.inner_text('#plMes'); chk('liste des mesures et total affichés', 'Dalle' in tx and '60,00 m²' in tx and 'Total' in tx)
    with pg.expect_download() as dl: pg.evaluate("EXBPLN.mcsv()")
    chk('export CSV', dl.value.suggested_filename.startswith('mesures-') and dl.value.suggested_filename.endswith('.csv'))
    pg.evaluate("EXBPLN.mmet()"); pg.wait_for_timeout(500)
    ex=pg.evaluate("EXBMetre.state().extra")
    chk('envoi au métré : surface en m² et longueurs en ml', any(e['d'].startswith('Dalle') and e['u']=='m²' and abs(e['q']-60)<0.01 for e in ex) and any(e['u']=='ml' for e in ex))
    pg.evaluate("EXBPLN.mmet()"); pg.wait_for_timeout(300)
    chk('renvoi : pas de doublon', len(pg.evaluate("EXBMetre.state().extra"))==len(ex))
    # persistance : on rouvre le plan
    pg.evaluate("id=>EXBPLN.view(id)",fid); pg.wait_for_selector('#plCv',timeout=8000); pg.wait_for_timeout(500)
    chk('mesures et échelle conservées à la réouverture', 'Dalle' in pg.inner_text('#plMes') and 'Échelle : 1 unité' in pg.inner_text('#plMesBar'))
    pg.evaluate("EXBPLN.mdel(%s)"%repr(by['Dalle']['id'])); chk('suppression d\'une mesure', 'Dalle' not in pg.inner_text('#plMes'))
    chk('aucune erreur JavaScript '+str(errs[:2]), not errs)
    b.close()
print('\n%d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
