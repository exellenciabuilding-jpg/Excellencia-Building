"""Test navigateur (Chromium, écran 390 px) du suivi TFL : python3 tools/test-tfl/e2e-suivi.py
Page minimale qui charge exb-tfl.js seul : chapitres/corrections, rendez-vous, défense, tableau de bord, rapport CSV."""
import asyncio, os, sys, tempfile, json
from playwright.async_api import async_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
fails = 0
def ok(c, m):
    global fails
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails += 1
FORM = {'form':'EXB_TFL','version':1,'submitted_at':'2026-10-17T10:00:00.000Z','ref':'R1','photo':'','d':{'nom':'Jean Kasongo','telephone':'0812345678','email':'j@mail.com','universite':'UNIKIN','domaine':'genie_civil','sujet_titre':'Étude des fondations','problematique':'P','objectifs':'O'}}
async def main():
    page_html = os.path.join(tempfile.mkdtemp(), 't.html')
    open(page_html, 'w').write('<!doctype html><html><head><meta charset="utf-8"></head><body><div class="wrap"><section id="projets"></section></div><script>window.show=function(){};</script><script src="file://%s/exb-tfl.js"></script></body></html>' % ROOT)
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={'width': 390, 'height': 900}, accept_downloads=True)
        pg = await ctx.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)[:200])); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto('file://' + page_html); await pg.wait_for_timeout(1800)
        await pg.evaluate("(f)=>{EXBTFL.importer(f);show('tflSec')}", FORM); await pg.wait_for_timeout(300)
        await pg.click('[data-tfl="ouvrir"]'); await pg.wait_for_selector('#tflSuivi')
        ok(await pg.locator('#tflSuivi h3:has-text("Suivi de la rédaction")').count() == 1, 'bloc « Suivi de la rédaction » dans la fiche du dossier')
        # 06
        await pg.click('[data-tfl="chPlan"]'); await pg.wait_for_selector('text=Introduction générale')
        ok(await pg.locator('[data-tfl="chDel"]').count() == 5, 'plan type : 5 chapitres')
        await pg.fill('#tflCo-' + (await pg.evaluate("EXBTFL.dossiers()[0].chapitres[0].id")), 'Revoir la problématique')
        await pg.click('[data-tfl="coAdd"] >> nth=0'); await pg.wait_for_selector('text=Revoir la problématique')
        ok(await pg.evaluate("EXBTFL.dossiers()[0].chapitres[0].statut") == 'a_corriger', 'correction ajoutée → chapitre « À corriger »')
        await pg.click('[data-tfl="coBasc"]'); await pg.wait_for_timeout(150)
        ok(await pg.evaluate("EXBTFL.dossiers()[0].chapitres[0].corrections[0].fait") is True, 'case de correction cochée')
        await pg.click('[data-tfl="chStatut"][data-v="valide"] >> nth=0'); await pg.wait_for_timeout(150)
        await pg.click('[data-tfl="progAuto"]'); await pg.wait_for_timeout(200)
        ok(await pg.evaluate("EXBTFL.dossiers()[0].progression") == 20, 'progression calculée (1 chapitre validé sur 5 = 20 %)')
        await pg.fill('#tflChT', 'Annexes'); await pg.fill('#tflChD', '2020-01-01'); await pg.click('[data-tfl="chAdd"]'); await pg.wait_for_selector('text=Annexes')
        ok(await pg.locator('text=en retard').count() >= 1, 'chapitre à l’échéance dépassée signalé « en retard »')
        # 07
        await pg.fill('#tflRvD', '2030-05-10'); await pg.fill('#tflRvH', '14:30'); await pg.fill('#tflRvO', 'Relecture chapitre 2'); await pg.click('[data-tfl="rdvAdd"]')
        await pg.wait_for_selector('text=Relecture chapitre 2')
        ok(await pg.locator('a:has-text("Rappel")').count() == 1, 'rendez-vous planifié + lien WhatsApp « Rappel »')
        async with pg.expect_download() as dl: await pg.click('[data-tfl="rdvIcs"]')
        d = await dl.value; txt = open(await d.path(), encoding='utf-8').read()
        ok(d.suggested_filename.endswith('.ics') and 'BEGIN:VEVENT' in txt and 'DTSTART:20300510T143000' in txt, 'agenda .ics téléchargé')
        # 08
        await pg.fill('#tflDfD', '2030-06-20'); await pg.fill('#tflDfL', 'Salle A'); await pg.check('.tflDefC[data-k="memoire"]'); await pg.check('.tflDefC[data-k="jury"]')
        await pg.click('[data-tfl="defSave"]'); await pg.wait_for_selector('text=2/7 points prêts')
        ok(await pg.locator('a:has-text("Convocation WhatsApp")').count() == 1, 'défense enregistrée (2/7) + convocation WhatsApp')
        ok(await pg.evaluate("EXBTFL.dossiers()[0].etape") == 8, 'étape du parcours passée à 8')
        # affichage mobile : rien ne déborde
        ow = await pg.evaluate("document.documentElement.scrollWidth"); ok(ow <= 392, 'pas de défilement horizontal sur 390 px (largeur %d)' % ow)
        # 09
        await pg.click('[data-tfl="fermer"]'); await pg.click('[data-tfl="vue"][data-v="tableau"]'); await pg.wait_for_selector('h3:has-text("Tableau de bord TFL")')
        t = await pg.inner_text('#tflBox')
        ok('dossiers actifs' in t and 'Répartition par étape' in t and 'Échéances' in t, 'tableau de bord affiché')
        ok('Annexes' in t, 'chapitre en retard listé dans les échéances')
        async with pg.expect_download() as dl: await pg.click('[data-tfl="csvRapport"]')
        d = await dl.value; csv = open(await d.path(), encoding='utf-8').read()
        ok(d.suggested_filename.startswith('rapport-TFL-') and 'Jean Kasongo' in csv and '1/6' in csv, 'rapport CSV téléchargé (chapitres validés 1/6)')
        await pg.click('[data-tfl="ouvrirDos"] >> nth=0'); await pg.wait_for_selector('#tflDetail')
        ok(True, 'clic sur une échéance : ouvre le dossier')
        ok(not errs, 'aucune erreur JavaScript ' + str(errs[:2]))
        await b.close()
    print('\n' + (str(fails) + ' ÉCHEC(S)' if fails else 'Tout est OK')); sys.exit(1 if fails else 0)
asyncio.run(main())
