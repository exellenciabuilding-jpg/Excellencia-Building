#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) de la page publique tfl-sujets.html : python3 tools/test-tfl/e2e-sujets.py (depuis le dossier du site).
Le serveur Supabase est SIMULÉ : on vérifie la liste, les filtres, « Choisir ce sujet » (en ligne, sujet déjà réservé, sans serveur)."""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
BASE=f'http://127.0.0.1:{PORT}'
def fiche(ref,titre,cat,fil,statut='disponible',excl=True):
    return {'ref':ref,'exclusif':excl,'statut':statut,'data':{'ref':ref,'titre':titre,'categorie':cat,'filiere':fil,'domaine':'genie_civil','problematique':'Problématique de '+titre,'objectifs':'Objectifs de '+titre,'methodologie':'Méthode','livrables':'Mémoire','competences':'BAEL','encadrement':'Pr X','mots_cles':'béton'}}
ROWS=[fiche('EXB-TFL-BTP-0001','Dimensionnement d’une dalle','structures','Génie civil'),fiche('EXB-TFL-BTP-0002','Étude de voirie urbaine','voirie','Génie civil'),fiche('EXB-TFL-BTP-0003','Habitat bioclimatique','architecture','Architecture','reserve')]
CFG="window.EXB_SUPABASE={url:'https://stub.supabase.co',key:'anon-key'};"
with sync_playwright() as p:
    b=p.chromium.launch()
    print('# Page publique — lecture et filtres (sans compte)')
    ctx=b.new_context(); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    ctx.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=CFG))
    ctx.route('**/rest/v1/rpc/tfl_sujets_publics',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps(ROWS)))
    sent=[]
    def choisir(route):
        d=json.loads(route.request.post_data); sent.append(d)
        route.fulfill(status=200,content_type='application/json',body='{"ok":true,"reserve":true}')
    ctx.route('**/rest/v1/rpc/tfl_sujet_choisir',choisir)
    pg.set_viewport_size({'width':390,'height':800})
    pg.goto(BASE+'/tfl-sujets.html'); pg.wait_for_selector('.card')
    ok(pg.locator('.card').count()==2,'2 sujets affichés sans compte : le sujet déjà choisi (réservé) n’est plus proposé')
    ok('2 sujets' in pg.inner_text('#etat'),'compteur de sujets')
    pg.fill('#q','voirie'); ok(pg.locator('.card').count()==1,'recherche « voirie » : 1 résultat')
    pg.fill('#q','VOIRIE urbaine'); ok(pg.locator('.card').count()==1,'recherche sans tenir compte de la casse')
    pg.fill('#q','béton'); ok(pg.locator('.card').count()==2,'recherche dans les mots-clés')
    pg.fill('#q',''); pg.select_option('#cat','structures'); ok(pg.locator('.card').count()==1,'filtre par catégorie')
    pg.select_option('#cat',''); pg.select_option('#dis','disponible'); ok(pg.locator('.card').count()==2,'filtre « Disponibles » : 2 sujets')
    pg.select_option('#dis',''); ok(pg.locator('#c-EXB-TFL-BTP-0003').count()==0 and pg.locator('#dis option[value="reserve"]').count()==0,'sujet déjà choisi : absent de la liste, plus de filtre « Réservés »')
    ok(pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'),'aucun défilement horizontal sur 390 px')
    print('# Choisir ce sujet — en ligne')
    pg.click('[data-r="EXB-TFL-BTP-0001"]'); ok('Problématique' in pg.inner_text('#c-EXB-TFL-BTP-0001') and pg.locator('#f-go').count()==1,'fiche complète + formulaire')
    pg.click('#f-go'); ok('nom' in pg.inner_text('#f-msg').lower() and not sent,'nom manquant : rien n’est envoyé')
    pg.fill('#f-nom','Aline Tshala'); pg.fill('#f-tel','12'); pg.click('#f-go'); ok('téléphone' in pg.inner_text('#f-msg') and not sent,'téléphone invalide refusé')
    pg.fill('#f-tel','0991112222'); pg.click('#f-go'); ok('université' in pg.inner_text('#f-msg').lower() and not sent,'université manquante refusée')
    pg.fill('#f-univ','ISTA'); pg.fill('#f-mot','Je fais un stage sur chantier'); pg.click('#f-go'); pg.wait_for_timeout(500)
    ok(len(sent)==1 and sent[0]['p_ref']=='EXB-TFL-BTP-0001' and sent[0]['p_data']['nom']=='Aline Tshala' and sent[0]['p_submitted'],'demande envoyée : référence du sujet, données, horodatage')
    ok('envoyée' in pg.inner_text('#c-EXB-TFL-BTP-0001') and 'réservé' in pg.inner_text('#c-EXB-TFL-BTP-0001'),'confirmation + mention de réservation')
    ok('sujet_titre' not in sent[0]['p_data'] and 'problematique' not in sent[0]['p_data'],'la fiche du sujet n’est pas renvoyée par l’étudiant (copiée côté serveur)')
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2])); ctx.close()
    print('# Choisir ce sujet — déjà réservé entre-temps')
    ctx=b.new_context(); pg=ctx.new_page()
    ctx.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=CFG))
    état={'n':0}
    def pubs(r):
        état['n']+=1; rows=json.loads(json.dumps(ROWS))
        if état['n']>1: rows[0]['statut']='reserve'
        r.fulfill(status=200,content_type='application/json',body=json.dumps(rows))
    ctx.route('**/rest/v1/rpc/tfl_sujets_publics',pubs)
    ctx.route('**/rest/v1/rpc/tfl_sujet_choisir',lambda r:r.fulfill(status=400,content_type='application/json',body='{"message":"sujet_deja_reserve"}'))
    pg.goto(BASE+'/tfl-sujets.html'); pg.wait_for_selector('.card'); pg.click('[data-r="EXB-TFL-BTP-0001"]')
    pg.fill('#f-nom','Bob K'); pg.fill('#f-tel','0822222222'); pg.fill('#f-univ','UNIKIN'); pg.click('#f-go'); pg.wait_for_timeout(700)
    ok('réservé par un autre étudiant' in pg.inner_text('#etat'),'sujet pris par un autre : message clair')
    ok(pg.locator('#c-EXB-TFL-BTP-0001').count()==0,'liste rechargée : le sujet pris par un autre a disparu')
    ctx.close()
    print('# Sans serveur — fichier tfl-sujets.json et demande par fichier')
    ctx=b.new_context(accept_downloads=True); pg=ctx.new_page()
    ctx.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body='window.EXB_SUPABASE=null;'))
    pub={'form':'EXB_TFL_SUJETS','sujets':[dict(ROWS[0]['data'],exclusif=True,statut='disponible')]}
    ctx.route('**/tfl-sujets.json',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps(pub)))
    pg.goto(BASE+'/tfl-sujets.html'); pg.wait_for_selector('.card'); ok(pg.locator('.card').count()==1,'liste lue dans tfl-sujets.json')
    pg.click('[data-r="EXB-TFL-BTP-0001"]'); ok('fichier' in pg.inner_text('#f-go'),'bouton adapté : « fichier à envoyer »')
    pg.fill('#f-nom','Carine M'); pg.fill('#f-tel','0833333333'); pg.fill('#f-univ','ISP')
    with pg.expect_download() as dl: pg.click('#f-go')
    path=dl.value.path(); o=json.load(open(path,encoding='utf8'))
    ok(o['form']=='EXB_TFL' and o['d']['sujet_ref']=='EXB-TFL-BTP-0001' and o['d']['sujet_titre'].startswith('Dimensionnement') and o['d']['nom']=='Carine M','fichier de candidature importable (EXB_TFL + sujet_ref + fiche copiée)')
    ctx.close()
    b.close()
print('\n'+(str(fails)+' ÉCHEC(S)' if fails else 'Tout est OK')); raise SystemExit(1 if fails else 0)
