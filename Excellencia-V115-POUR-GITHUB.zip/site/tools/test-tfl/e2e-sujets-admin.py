#!/usr/bin/env python3
"""Test navigateur (Chromium) de l'écran 📋 Sujets du module TFL + champ « consultation autorisée » : python3 tools/test-tfl/e2e-sujets-admin.py
Page minimale qui charge exb-tfl.js seul ; le serveur est SIMULÉ (window.exbSb)."""
import asyncio, os, tempfile, json
from playwright.async_api import async_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
fails = 0
def ok(c, m):
    global fails
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails += 1
STUB = """window.show=function(){};window.__calls=[];window.__etat=[];
window.exbSb={isIn:function(){return true},cfg:function(){return {url:'https://stub.supabase.co',key:'k'}},api:async function(path,o){var n=path.split('/').pop();var b=o&&o.body?JSON.parse(o.body):{};window.__calls.push([n,b]);
 if(n==='tfl_sujets_etat')return window.__etat;if(n==='tfl_candidatures_liste')return window.__cands||[];return {ok:true}}};"""
async def main():
    page_html = os.path.join(tempfile.mkdtemp(), 't.html')
    open(page_html, 'w').write('<!doctype html><html><head><meta charset="utf-8"></head><body><div class="wrap"><section id="projets"></section></div><script>%s</script><script src="file://%s/exb-tfl.js"></script></body></html>' % (STUB, ROOT))
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 390, 'height': 900})
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto('file://' + page_html); await pg.wait_for_timeout(1800); await pg.evaluate("show('tflSec')")
        await pg.click('[data-tfl="vue"][data-v="sujets"]')
        ok(await pg.locator('h3:has-text("Catalogue des sujets")').count() == 1, 'bouton 📋 Sujets ouvre le catalogue')
        await pg.click('[data-tfl="sjNouveau"]')
        await pg.click('[data-tfl="sjOk"]'); ok(await pg.locator('#tflBox').inner_text() != '' and await pg.locator('.tflS').count() > 0, 'fiche incomplète : le formulaire reste ouvert')
        await pg.fill('#tflSt', 'Dimensionnement d’une dalle'); await pg.fill('#tflSp', 'Quelle épaisseur ?'); await pg.fill('#tflSo', 'Comparer deux méthodes'); await pg.fill('#tflSf', 'Génie civil')
        await pg.select_option('#tflSc', 'structures'); await pg.click('[data-tfl="sjOk"]')
        ok('EXB-TFL-BTP-0001' in await pg.locator('#tflBox').inner_text() and 'Non publié' in await pg.locator('#tflBox').inner_text(), 'fiche ajoutée : EXB-TFL-BTP-0001, non publiée')
        await pg.click('[data-tfl="sjEdit"]'); ok(await pg.input_value('#tflSt') == 'Dimensionnement d’une dalle' and await pg.locator('#tflSref').is_disabled(), 'modification : champs préremplis, référence verrouillée')
        await pg.fill('#tflSl', 'Mémoire + notes de calcul'); await pg.click('[data-tfl="sjOk"]')
        ok(await pg.evaluate("EXBTFL.sujets.liste()[0].livrables") == 'Mémoire + notes de calcul', 'fiche modifiée (livrables)')
        await pg.click('[data-tfl="sjPublie"]'); ok('Publié' in await pg.locator('#tflBox').inner_text() and await pg.evaluate("EXBTFL.sujets.liste()[0].publie"), 'fiche publiée localement')
        # synchronisation : le serveur annonce une réservation faite par un étudiant
        await pg.evaluate("window.__etat=[{ref:'EXB-TFL-BTP-0001',statut:'reserve',publie:true,exclusif:true}]")
        await pg.click('[data-tfl="sjSync"]'); await pg.wait_for_timeout(500)
        calls = await pg.evaluate("window.__calls")
        pub = [c for c in calls if c[0] == 'tfl_sujets_publier']
        ok(len(pub) == 1 and pub[0][1]['p_sujets'][0]['ref'] == 'EXB-TFL-BTP-0001' and pub[0][1]['p_sujets'][0]['livrables'] == 'Mémoire + notes de calcul', 'synchronisation : fiche publiée envoyée au serveur')
        ok(await pg.evaluate("EXBTFL.sujets.liste()[0].statut") == 'reserve' and 'Réservé' in await pg.locator('#tflBox').inner_text(), 'réservation du serveur reprise : sujet « Réservé »')
        ok(not any('dossier_numero' in json.dumps(c[1]) for c in pub), 'aucune donnée de dossier envoyée au serveur')
        # candidature en ligne portant la référence : dossier créé, lié au sujet
        await pg.evaluate("window.__cands=[{id:'u1',imported:false,submitted_at:'2026-11-01T08:00:00Z',ref:'SUJET-EXB-TFL-BTP-0001',data:{nom:'Aline Tshala',telephone:'0991112222',universite:'ISTA',domaine:'genie_civil',sujet_ref:'EXB-TFL-BTP-0001',sujet_titre:'Dimensionnement d’une dalle',problematique:'Quelle épaisseur ?',objectifs:'Comparer'}}]")
        await pg.click('[data-tfl="vue"][data-v="dossiers"]')
        r = await pg.evaluate("(async()=>{var imp=EXBTFL.dossiers().length;var rows=await exbSb.api('/rest/v1/rpc/tfl_candidatures_liste',{method:'POST',body:'{}'});var o=EXBTFL.importer({form:'EXB_TFL',version:1,submitted_at:rows[0].submitted_at,ref:rows[0].ref,d:rows[0].data,photo:''});return [o.numero,o.sujet&&o.sujet.reserve,EXBTFL.sujets.liste()[0].dossier_numero]})()")
        ok(r[0].startswith('TFL-') and r[1] is True and r[2] == r[0], 'candidature « Choisir ce sujet » → dossier %s lié au sujet' % r[0])
        # décision : libérer après refus, puis re-synchroniser
        await pg.evaluate("EXBTFL.setStatut(EXBTFL.dossiers()[0].id,'refuse','Hors sujet')")
        await pg.click('[data-tfl="vue"][data-v="sujets"]')
        ok('Disponible' in await pg.locator('#tflBox').inner_text() and 'à synchroniser' in await pg.locator('#tflBox').inner_text(), 'dossier refusé : sujet de nouveau disponible, « à synchroniser »')
        await pg.evaluate("window.__calls=[]"); await pg.click('[data-tfl="sjSync"]'); await pg.wait_for_timeout(500)
        pub = [c for c in await pg.evaluate("window.__calls") if c[0] == 'tfl_sujets_publier']
        ok(len(pub) == 1 and pub[0][1]['p_sujets'][0]['statut'] == 'disponible' and pub[0][1]['p_sujets'][0]['push_statut'] is True, 'la libération est envoyée avec push_statut')
        ok(await pg.evaluate("EXBTFL.sujets.liste()[0].push") is False, 'après synchronisation : plus rien « à synchroniser »')
        await pg.click('[data-tfl="sjPublie"]'); await pg.evaluate("window.__calls=[]"); await pg.click('[data-tfl="sjSync"]'); await pg.wait_for_timeout(500)
        ok(any(c[0] == 'tfl_sujet_retirer' for c in await pg.evaluate("window.__calls")), 'sujet retiré du public : tfl_sujet_retirer appelé')
        ok(await pg.evaluate("document.documentElement.scrollWidth<=window.innerWidth+1"), 'aucun défilement horizontal sur 390 px')
        # --- Bibliothèque : consultation autorisée ---
        await pg.click('[data-tfl="vue"][data-v="dossiers"]'); await pg.click('[data-tfl="vue"][data-v="biblio"]')
        ok('pas un travail à recopier' in await pg.locator('#tflBox').inner_text(), 'mention « référence méthodologique, pas un travail à recopier »')
        await pg.fill('#tflBt', 'TFL Route'); await pg.select_option('#tflBc', 'oui'); await pg.click('[data-tfl="bAjouter"]'); await pg.wait_for_timeout(400)
        ok('Consultation autorisée' in await pg.locator('#tflBox').inner_text(), 'travail ajouté avec « Consultation autorisée »')
        await pg.click('[data-tfl="bConsult"]'); ok('Consultation non autorisée' in await pg.locator('#tflBox').inner_text(), 'bascule → « Consultation non autorisée »')
        ok(not errs, 'aucune erreur JavaScript ' + str(errs[:2]))
        await b.close()
    print('\n' + (str(fails) + ' ÉCHEC(S)' if fails else 'Tout est OK')); raise SystemExit(1 if fails else 0)
asyncio.run(main())
