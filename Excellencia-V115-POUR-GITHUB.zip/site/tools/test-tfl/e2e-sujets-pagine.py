#!/usr/bin/env python3
"""Test navigateur de tfl-sujets.html en lecture PAGINÉE (migration-v99zzw) : python3 tools/test-tfl/e2e-sujets-pagine.py
Le serveur Supabase est SIMULÉ : 120 fiches publiées, 30 par page, recherche et filtres côté « serveur »."""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
def fiche(i):
    cat='voirie' if i%2 else 'agriculture'; fil='Routes' if i%2 else 'Génie rural'
    return {'ref':'GR-TFL-%04d'%i,'exclusif':True,'statut':'disponible','data':{'ref':'GR-TFL-%04d'%i,'titre':('Drainage routier n°%d'%i) if i%2 else ('Piste agricole n°%d'%i),'categorie':cat,'filiere':fil,'domaine':'autre','problematique':'P','objectifs':'O'}}
ALL=[fiche(i) for i in range(1,121)]
CFG="window.EXB_SUPABASE={url:'https://stub.supabase.co',key:'anon-key'};"
calls=[]
def page_rpc(r):
    b=json.loads(r.request.post_data); calls.append(b)
    rows=[x for x in ALL if (not b['p_q'] or b['p_q'].lower() in x['data']['titre'].lower()) and (not b['p_cat'] or x['data']['categorie']==b['p_cat'])]
    out=[dict(x,total=len(rows)) for x in rows[b['p_offset']:b['p_offset']+b['p_limit']]]
    r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
def facettes(r):
    r.fulfill(status=200,content_type='application/json',body=json.dumps([{'categorie':'voirie','filiere':'Routes','n':60},{'categorie':'agriculture','filiere':'Génie rural','n':60}]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    ctx.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=CFG))
    ctx.route('**/rest/v1/rpc/tfl_sujets_publics_page',page_rpc); ctx.route('**/rest/v1/rpc/tfl_sujets_facettes',facettes)
    pg.goto(f'http://127.0.0.1:{PORT}/tfl-sujets.html'); pg.wait_for_selector('.card',timeout=8000)
    print('# Lecture paginée')
    ok(pg.evaluate('TFL_SUJETS_TEST.paged()') is True and pg.locator('.card[id^="c-"]').count()==30,'mode paginé : 30 fiches affichées sur 120')
    ok('120 sujets' in pg.locator('#etat').inner_text(),'compteur : 120 sujets (total donné par le serveur)')
    ok(pg.locator('#cat option').count()==3,'filtres construits à partir des facettes du serveur')
    pg.click('[data-a="plus"]'); pg.wait_for_function('document.querySelectorAll(\'.card[id^="c-"]\').length==60')
    ok(calls[-1]['p_offset']==30,'« Voir plus » demande la page suivante (offset 30)')
    pg.fill('#q','drainage'); pg.wait_for_function('document.querySelectorAll(\'.card[id^="c-"]\').length==30',timeout=5000)
    ok(calls[-1]['p_q']=='drainage' and calls[-1]['p_offset']==0,'recherche envoyée au serveur (depuis le début)')
    ok('60 sujets' in pg.locator('#etat').inner_text(),'compteur après recherche : 60 sujets')
    pg.fill('#q',''); pg.wait_for_timeout(700); pg.select_option('#cat','agriculture'); pg.wait_for_timeout(700)
    ok(calls[-1]['p_cat']=='agriculture' and pg.locator('#fil option').count()==2,'filtre catégorie envoyé ; filières limitées à la catégorie')
    pg.locator('[data-a="voir"]').first.click(); ok(pg.locator('.form').count()==1,'« Voir la fiche » ouvre la fiche et « Choisir ce sujet »')
    ok(errs==[],'aucune erreur JavaScript '+str(errs[:2]))
    print('# Repli sans la migration V99zzw (ancienne fonction, 500 lignes)')
    ctx2=b.new_context(); pg2=ctx2.new_page()
    ctx2.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=CFG))
    ctx2.route('**/rest/v1/rpc/tfl_sujets_publics_page',lambda r:r.fulfill(status=404,content_type='application/json',body='{"message":"function does not exist"}'))
    ctx2.route('**/rest/v1/rpc/tfl_sujets_publics',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps(ALL)))
    pg2.goto(f'http://127.0.0.1:{PORT}/tfl-sujets.html'); pg2.wait_for_selector('.card',timeout=8000)
    ok(pg2.evaluate('TFL_SUJETS_TEST.paged()') is False and pg2.locator('.card[id^="c-"]').count()==50,'ancienne fonction : 120 fiches, 50 affichées')
    pg2.click('[data-a="plus"]'); ok(pg2.locator('.card[id^="c-"]').count()==100,'« Voir plus » : 100 affichées')
    b.close()
srv.shutdown(); print('\nTout est OK' if not fails else f'\n{fails} échec(s)'); raise SystemExit(1 if fails else 0)
