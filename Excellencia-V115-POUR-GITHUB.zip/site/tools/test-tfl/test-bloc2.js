/* Test bloc 2 : proposition de sujet ou de plan par l'étudiant (administration + portail) : node tools/test-tfl/test-bloc2.js
 * Navigateur et serveur SIMULÉS (le faux serveur reproduit supabase/migration-tfl-bloc2-proposition-sujet-plan.sql). */
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
const throws=(f)=>{try{f();return false}catch(e){return true}};
const J=o=>JSON.parse(JSON.stringify(o));

/* ================= Administration (exb-tfl.js) ================= */
const src=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');
const ctx={EXBTFL_MEM:{},console,clearTimeout,setTimeout};ctx.window=undefined;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);
const T=ctx.EXBTFL,P=T.portail,MEM=()=>ctx.EXBTFL_MEM;
T.importer({form:'EXB_TFL',version:1,submitted_at:'2026-10-17T10:00:00.000Z',ref:'REF-B2',photo:'',d:{nom:'Jean Kasongo',telephone:'0812345678',email:'j@m.com',universite:'UNIKIN',promotion:'L3',domaine:'genie_civil',sujet_titre:'Dalle en béton armé',problematique:'p',objectifs:'o',methodologie:'m'}});
let d=T.dossiers()[0];T.setStatut(d.id,'accepte','');
T.ajouterEncadreur({nom:'Pr Mbuyi',telephone:'0811111111',max_etudiants:3,domaines:['genie_civil']});
const enc=J(MEM()['exb_tfl_encadreurs'])[0];
const mat=T.etudiants()[0].matricule;
const row=(id,type,texte,role)=>({id,role:role||'etudiant',identifiant:role==='encadreur'?'X':mat,nom:'Jean Kasongo',de:role||'etudiant',type,dossier:d.numero,texte:typeof texte==='string'?texte:JSON.stringify(texte),valeur:null,cree_le:'2026-10-29T10:00:00Z'});
console.log('# Snapshot avant toute proposition');
let s0=P.snapEtudiant(T.dossiers()[0]);
ok(Array.isArray(s0.mes_propositions)&&s0.mes_propositions.length===0&&s0.plan==='','aucune proposition, aucun plan');
console.log('# Réception');
let res=P.appliquerRetours([
  row('p1','proposition_sujet',{titre:'Dimensionnement d’une dalle précontrainte',problematique:'Comment limiter la flèche ?',objectifs:'Comparer deux méthodes de calcul',methodologie:'Calcul manuel',motif:'Sujet actuel refusé'}),
  row('p2','proposition_plan',{plan:'Introduction\nChapitre 1 : généralités\nChapitre 2 : calcul\nConclusion',motif:'Version 1'}),
  row('p3','proposition_sujet',{titre:'court',problematique:'x',objectifs:'y'}),
  row('p4','proposition_sujet',{titre:'Titre assez long pour passer',problematique:'problématique ok',objectifs:'objectifs ok'},'encadreur'),
  row('p5','proposition_plan','pas du json')]);
const M=()=>J(MEM()['exb_tfl_messages']||[]);
ok(res.recus===3&&res.refuses===2,'3 reçues (sujet, plan, sujet court) ; le texte non JSON et le dépôt par un encadreur sont refusés');
ok(M().find(m=>m.remote_id==='p1').type==='proposition_sujet'&&M().find(m=>m.remote_id==='p1').prop.titre.startsWith('Dimensionnement'),'proposition de sujet stockée avec ses champs');
ok(M().find(m=>m.remote_id==='p4')===undefined||M().find(m=>m.remote_id==='p4').type==='message','un encadreur ne peut pas déposer une proposition de l’étudiant');
const s1=P.snapEtudiant(T.dossiers()[0]);
ok(s1.mes_propositions.length===3&&s1.mes_propositions.every(x=>x.statut==='en_etude'&&x.rid),'état « en étude » publié avec l’identifiant du message');
ok(s1.plan===''&&T.dossiers()[0].sujet_titre==='Dalle en béton armé','rien ne change dans le dossier avant décision');
const id=r=>M().find(m=>m.remote_id===r).id;
console.log('# Décisions');
ok(throws(()=>P.propositionDecider(id('p1'),'refusee','')),'refus sans motif impossible');
ok(throws(()=>P.propositionDecider(id('p1'),'valide','motif ok')),'décision inconnue impossible');
ok(throws(()=>P.propositionRetenir(id('p3'))),'proposition incomplète impossible à retenir');
P.propositionDecider(id('p3'),'refusee','Titre trop court');
let sp=P.snapEtudiant(T.dossiers()[0]).mes_propositions.find(x=>x.rid==='p3');
ok(sp.statut==='refusee'&&sp.motif==='Titre trop court','refus publié avec son motif');
ok(throws(()=>P.propositionDecider(id('p3'),'refusee','Encore')),'une proposition déjà décidée ne se décide pas deux fois');
console.log('# Plan retenu');
P.propositionRetenir(id('p2'));
ok(T.dossiers()[0].plan.startsWith('Introduction')&&T.dossiers()[0].sujet_titre==='Dalle en béton armé','plan enregistré, sujet inchangé');
ok(P.snapEtudiant(T.dossiers()[0]).plan.startsWith('Introduction'),'le plan est visible dans le portail de l’étudiant');
console.log('# Sujet retenu');
P.affecter?0:0;T.affecter(T.dossiers()[0].id,enc.id);
T.patchDossier(T.dossiers()[0].id,{validation_encadreur:'valide',validation_univ:'accordee',sujet_statut:'accepte'});
const nd=P.propositionRetenir(id('p1'));
ok(nd.sujet_titre.startsWith('Dimensionnement')&&nd.problematique==='Comment limiter la flèche ?'&&nd.objectifs.startsWith('Comparer'),'sujet, problématique et objectifs remplacés');
ok(nd.sujet_statut==='a_etudier'&&nd.validation_univ==='non_demandee'&&!nd.validation_encadreur,'validations remises à zéro');
ok(T.dossiers()[0].statut==='accepte'&&T.dossiers()[0].encadreur_id===enc.id,'statut du dossier et encadreur inchangés');
const se=P.snapEncadreur(enc?J(MEM()['exb_tfl_encadreurs'])[0]:null).dossiers[0];
ok(se.avis===true&&se.sujet_modifie===true&&se.sujet_titre.startsWith('Dimensionnement')&&se.plan.startsWith('Introduction'),'l’encadreur est invité à donner son avis et voit le nouveau sujet et le plan');
const hist=J(MEM()['exb_tfl_historique']||[]);
ok(hist.some(h=>h.action==='changement_sujet')&&hist.some(h=>h.action==='changement_plan'),'historique du dossier tenu à jour');
const sf=P.snapEtudiant(T.dossiers()[0]).mes_propositions;
ok(sf.find(x=>x.rid==='p1').statut==='retenue'&&sf.find(x=>x.rid==='p2').statut==='retenue','décisions « retenue » publiées');
ok(throws(()=>P.propositionRetenir(id('p1'))),'impossible de retenir deux fois');
console.log('# Dossier clos');
P.appliquerRetours([row('p6','proposition_plan',{plan:'Un autre plan de travail complet'})]);
T.setStatut(T.dossiers()[0].id,'refuse','Hors délai');
ok(throws(()=>P.propositionRetenir(id('p6'))),'dossier refusé : plan non modifiable');

/* ================= Portail (tfl-portail.html) ================= */
const html=fs.readFileSync(path.join(__dirname,'../../tfl-portail.html'),'utf8');
const scripts=[...html.matchAll(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const norm=s=>String(s||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase();
const H=(m,r,i)=>crypto.createHash('sha256').update(m+':'+r+':'+norm(i)).digest('hex');
function serveur(contenu){
  const S={a:{id:'a0',role:'etudiant',identifiant:'123456789',nom:'Jean',mdp:H('Solide2026!','etudiant','123456789'),contenu},msgs:[],n:0,calls:[]};
  const fn={
    tfl_portail_connexion(b){if(b.p_mdp!=='Solide2026!')return{ok:false,code:'code',minutes:0};
      return{ok:true,changer:false,nom:S.a.nom,publie_le:'2026-10-29T08:00:00Z',contenu:S.a.contenu,messages:S.msgs.map(m=>({id:m.id,de:m.de,type:m.type,dossier:m.dossier,texte:m.texte,valeur:null,cree_le:m.cree_le,traite:m.traite}))}},
    tfl_portail_proposition(b){const c=S.a.contenu,g=b.p_genre,t='proposition_'+g,f=b.p_champs||{};
      if(!['sujet','plan'].includes(g))return{ok:false,code:'type'};
      if(!c.numero||!['accepte','en_verification'].includes(c.statut))return{ok:false,code:'dossier'};
      if(g==='sujet'){if(String(f.titre||'').trim().length<8||String(f.problematique||'').trim().length<10||String(f.objectifs||'').trim().length<10)return{ok:false,code:'vide'}}
      else if(String(f.plan||'').trim().length<20)return{ok:false,code:'vide'};
      const dec=m=>(c.mes_propositions||[]).some(x=>x.rid===m.id&&x.statut&&x.statut!=='en_etude');
      if(S.msgs.some(m=>m.type===t&&!dec(m)))return{ok:false,code:'deja_propose'};
      if(S.msgs.filter(m=>m.type===t).length>=10)return{ok:false,code:'limite'};
      S.msgs.push({id:'srv-'+(++S.n),de:'etudiant',type:t,dossier:c.numero,texte:JSON.stringify(f),cree_le:'2026-10-29T10:0'+S.n+':00Z',traite:false});return{ok:true}}};
  S.fetch=async(url,o)=>{const m=/\/rpc\/(\w+)$/.exec(url);S.calls.push(m&&m[1]);if(!m||!fn[m[1]])return{ok:false,status:404,json:async()=>({})};return{ok:true,status:200,json:async()=>fn[m[1]](JSON.parse(o.body))}};
  S.fn=fn;return S;
}
function navigateur(srv){
  const els={};const ids=new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m=>m[1]));
  const mk=id=>{const e={id,value:'',textContent:'',className:'',disabled:false,hidden:/\shidden[\s>]/.test((html.match(new RegExp('<[^>]*id="'+id+'"[^>]*>'))||[''])[0]),_h:'',_l:{},style:{},addEventListener(t,f){(e._l[t]=e._l[t]||[]).push(f)},focus(){},getAttribute(k){return null}};
    Object.defineProperty(e,'innerHTML',{get(){return e._h},set(v){e._h=v}});return e};
  const doc={title:'',body:{className:''},getElementById(id){if(els[id])return els[id];const dyn=Object.values(els).some(x=>x._h&&x._h.indexOf('id="'+id+'"')>=0);if(ids.has(id)||dyn)return els[id]=mk(id);return null},addEventListener(){},hidden:false};
  const cx={document:doc,location:{search:'?role=etudiant'},window:{EXB_SUPABASE:{url:'https://x.supabase.co',key:'sb_publishable_k'}},fetch:srv.fetch,setTimeout:()=>0,clearTimeout(){},console,Date,Math,isFinite,parseInt,String,JSON,Promise};
  cx.window.document=doc;vm.createContext(cx);vm.runInContext(scripts[scripts.length-1],cx);
  const $=id=>doc.getElementById(id),tick=()=>new Promise(r=>setImmediate(r));
  const fire=async id=>{for(const f of ($(id)._l.click||[]))await f({});await tick();await tick()};
  const clic=async(act,p)=>{const b={disabled:false,getAttribute:k=>({'data-act':act,'data-p':p||null,'data-i':null})[k]};const ev={target:{closest:()=>b}};for(const f of ($('vApp')._l.click||[]))await f(ev);await tick();await tick()};
  return{$,fire,clic};
}
const contenu={nom:'Jean Kasongo',matricule:'123-456-789',numero:'TFL-2026-0001',domaine:'Génie civil',statut:'accepte',statut_label:'Accepté',etape:6,progression:40,sujet_titre:'Dalle',encadreur:null,historique:[],messages_admin:[],mes_propositions:[],plan:''};
(async()=>{
console.log('# Portail étudiant');
let srv=serveur(JSON.parse(JSON.stringify(contenu)));let b=navigateur(srv);
b.$('idf').value='123-456-789';b.$('pw').value='Solide2026!';await b.fire('bLogin');
let h=b.$('vApp').innerHTML;
ok(!b.$('vApp').hidden&&/Proposer un nouveau sujet/.test(h)&&/Proposer un plan de travail/.test(h),'formulaires de proposition de sujet et de plan affichés');
ok(/Proposer un sujet ou un plan/.test(h),'raccourci sur le tableau de bord');
b.$('ps1').value='court';await b.clic('propsujet');
ok(/obligatoires/.test(b.$('m6').textContent)&&srv.msgs.length===0,'champs obligatoires contrôlés avant envoi');
b.$('pp1').value='trop court';await b.clic('propplan');
ok(/20 caractères/.test(b.$('m7').textContent)&&srv.msgs.length===0,'plan trop court refusé avant envoi');
b.$('ps1').value='Étude <script>alert(1)</script> des dalles';b.$('ps2').value='Comment limiter la flèche des dalles ?';b.$('ps3').value='Comparer deux méthodes de calcul';b.$('ps4').value='';b.$('ps5').value='Sujet refusé';
await b.clic('propsujet');
ok(srv.msgs.length===1&&srv.msgs[0].type==='proposition_sujet'&&JSON.parse(srv.msgs[0].texte).motif==='Sujet refusé','proposition de sujet envoyée au serveur');
h=b.$('vApp').innerHTML;
ok(!/<script>alert/.test(h)&&/&lt;script&gt;/.test(h),'le texte saisi est échappé à l’affichage');
ok(/Envoyée/.test(h)&&/en cours d’étude/.test(h)&&!/id="ps1"/.test(h)&&/id="pp1"/.test(h),'sujet en étude : formulaire de sujet masqué, formulaire de plan toujours disponible');
const r2=srv.fn.tfl_portail_proposition({p_genre:'sujet',p_champs:{titre:'Un autre titre long',problematique:'une autre problématique',objectifs:'d’autres objectifs ici'}});
ok(r2.ok===false&&r2.code==='deja_propose','le serveur refuse une 2e proposition de sujet en cours d’étude');
b.$('pp1').value='Introduction\nChapitre 1\nChapitre 2\nConclusion';b.$('pp2').value='';await b.clic('propplan');
ok(srv.msgs.length===2&&srv.msgs[1].type==='proposition_plan','plan envoyé');
srv.msgs[0].traite=true;await b.clic('maj');
ok(/En cours d’étude par l’administration/.test(b.$('vApp').innerHTML),'après réception par l’administration : « en cours d’étude »');
srv.a.contenu.mes_propositions=[{rid:'srv-1',genre:'sujet',titre:'x',statut:'refusee',motif:'Trop large'},{rid:'srv-2',genre:'plan',titre:'Plan de travail',statut:'retenue',motif:''}];
srv.a.contenu.plan='Introduction\nChapitre 1';await b.clic('maj');h=b.$('vApp').innerHTML;
ok(/Refusée<\/b> — Trop large/.test(h)&&/Retenue/.test(h),'décisions de l’administration visibles avec leur motif');
ok(/id="ps1"/.test(h)&&/id="pp1"/.test(h),'après décision, l’étudiant peut proposer de nouveau');
ok(/Mon plan de travail/.test(h)&&/Chapitre 1/.test(h),'le plan retenu s’affiche dans « Mon sujet »');
const r3=srv.fn.tfl_portail_proposition({p_genre:'sujet',p_champs:{titre:'Un autre titre long',problematique:'une autre problématique',objectifs:'d’autres objectifs ici'}});
ok(r3.ok===true,'le serveur accepte une nouvelle proposition une fois la précédente décidée');
srv.a.contenu.statut='refuse';await b.clic('maj');
ok(!/id="ps1"/.test(b.$('vApp').innerHTML)&&/accepté ou en vérification/.test(b.$('vApp').innerHTML),'dossier non actif : aucun formulaire');
console.log(fails?'\n'+fails+' ÉCHEC(S)':'\nTout est OK');process.exit(fails?1:0);
})();
