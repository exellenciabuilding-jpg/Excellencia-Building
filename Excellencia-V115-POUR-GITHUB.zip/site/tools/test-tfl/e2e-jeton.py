#!/usr/bin/env python3
"""V99zzy — parcours navigateur : « Choisir ce sujet » reçoit un jeton, la fiche étudiante l'envoie ; la page de vérification affiche « non confirmée ».
Serveur Supabase SIMULÉ. Usage (depuis le dossier du site) : python3 tools/test-tfl/e2e-jeton.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
BASE=f'http://127.0.0.1:{PORT}'
CFG="window.EXB_SUPABASE={url:'https://stub.supabase.co',key:'anon-key'};"
ROW={'ref':'EXB-TFL-BTP-0001','exclusif':True,'statut':'disponible','data':{'ref':'EXB-TFL-BTP-0001','titre':'Dimensionnement d’une dalle','categorie':'structures','filiere':'Génie civil','domaine':'genie_civil','problematique':'P','objectifs':'O','niveau':'L3'}}
TOKEN='a'*64
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(); errs=[]
    ctx.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=CFG))
    ctx.route('**/rest/v1/rpc/tfl_sujets_publics',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps([ROW])))
    ctx.route('**/rest/v1/rpc/tfl_sujets_publics_page',lambda r:r.fulfill(status=404,content_type='application/json',body='{"message":"function does not exist"}'))
    ctx.route('**/rest/v1/rpc/tfl_sujets_facettes',lambda r:r.fulfill(status=404,content_type='application/json',body='{"message":"function does not exist"}'))
    ctx.route('**/rest/v1/rpc/tfl_sujet_choisir',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':True,'reserve':True,'token':TOKEN})))
    sent=[]
    def fiche(route):
        sent.append(json.loads(route.request.post_data)); route.fulfill(status=200,content_type='application/json',body='{"ok":true}')
    ctx.route('**/rest/v1/rpc/tfl_fiche_etudiant_envoyer',fiche)
    ctx.route('**/rest/v1/rpc/exb_doc_declare',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ok":true}'))
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    pg.goto(BASE+'/tfl-sujets.html'); pg.wait_for_selector('[data-a=voir]',timeout=15000); pg.click('[data-a=voir]')
    pg.fill('#f-nom','Marie Kabila'); pg.fill('#f-tel','0812345678'); pg.fill('#f-univ','UNIKIN')
    with ctx.expect_page() as np_:
        pg.click('[data-a=choisir]')
    fp=np_.value; fp.on('pageerror',lambda e:errs.append(str(e)[:160]))
    fp.wait_for_load_state()
    ch=json.loads(pg.evaluate("localStorage.getItem('exb_tfl_choix_fiche')"))
    ok(ch.get('token')==TOKEN,'le jeton reçu au choix est gardé sur l’appareil')
    fp.fill('#annee_academique','2025-2026'); fp.fill('#promotion','L3'); fp.fill('#universite','UNIKIN'); fp.fill('#nom','Marie Kabila'); fp.fill('#telephone','0812345678')
    fp.click('#online'); fp.wait_for_timeout(2500)
    ok(len(sent)==1 and sent[0].get('p_token')==TOKEN and sent[0].get('p_ref')=='EXB-TFL-BTP-0001','la fiche envoyée en ligne contient le jeton')
    # renvoi du même choix : le serveur ne renvoie plus de jeton -> l'ancien est conservé
    ctx.unroute('**/rest/v1/rpc/tfl_sujet_choisir')
    ctx.route('**/rest/v1/rpc/tfl_sujet_choisir',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':True,'reserve':True,'token':None})))
    pg.reload(); pg.wait_for_selector('[data-a=voir]',timeout=15000); pg.click('[data-a=voir]')
    pg.fill('#f-nom','Marie Kabila'); pg.fill('#f-tel','0812345678'); pg.fill('#f-univ','UNIKIN')
    with ctx.expect_page():
        pg.click('[data-a=choisir]')
    ch=json.loads(pg.evaluate("localStorage.getItem('exb_tfl_choix_fiche')"))
    ok(ch.get('token')==TOKEN,'un renvoi du choix (sans nouveau jeton) ne perd pas le jeton')
    # fiche refusée sans jeton : message clair
    ctx.unroute('**/rest/v1/rpc/tfl_fiche_etudiant_envoyer')
    ctx.route('**/rest/v1/rpc/tfl_fiche_etudiant_envoyer',lambda r:r.fulfill(status=400,content_type='application/json',body='{"message":"jeton_requis"}'))
    fp2=ctx.new_page(); fp2.goto(BASE+'/tfl-fiche.html?r=EXB-TFL-BTP-0001'); fp2.wait_for_load_state()
    fp2.fill('#nom','Marie Kabila'); fp2.fill('#telephone','0812345678'); fp2.fill('#universite','UNIKIN'); fp2.fill('#annee_academique','2025-2026'); fp2.fill('#promotion','L3')
    fp2.click('#online'); fp2.wait_for_timeout(1500)
    ok('Enregistrer le fichier' in fp2.inner_text('#msg'),'jeton refusé : message qui renvoie vers le fichier')
    # page de vérification : dépôt non confirmé
    ctx.route('**/supabase-config.js',lambda r:r.fulfill(status=200,content_type='application/javascript',body=CFG)); ctx.route('**/rest/v1/rpc/exb_doc_verify2',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'found':True,'kind':'inscription','status':'reçue','nom':'Faux','libelle':'Fiche','detail':'x','latest':True,'confirmed':False,'date':'2026-10-17'})))
    vp=ctx.new_page(); vp.goto(BASE+'/verification.html?c=i~TFL-1~2026-10-17~0~~abcdef1234~Faux'); vp.wait_for_timeout(2500)
    t=vp.inner_text('body'); ok('non confirmée' in t and 'authentique' not in t.split('Informations')[0].lower(),'vérification : « Fiche déposée, non confirmée » (pas « authentique »)')
    ok(not errs,'aucune erreur JavaScript '+str(errs))
    b.close()
srv.shutdown(); print('Tout est OK' if not fails else f'{fails} échec(s)'); raise SystemExit(1 if fails else 0)
