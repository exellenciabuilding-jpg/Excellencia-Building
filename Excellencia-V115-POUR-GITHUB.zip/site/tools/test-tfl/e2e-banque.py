#!/usr/bin/env python3
"""Test navigateur (Chromium) de la banque de 4 300 sujets dans 📋 Sujets : python3 tools/test-tfl/e2e-banque.py
Page minimale qui charge exb-tfl.js + tfl-banque.json par HTTP local ; le serveur Supabase est SIMULÉ (window.exbSb)."""
import asyncio, os, tempfile, shutil, threading, socketserver, functools, http.server, json
from playwright.async_api import async_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
fails = 0
def ok(c, m):
    global fails
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails += 1
STUB = """window.show=function(){};window.__calls=[];
window.exbSb={isIn:function(){return true},cfg:function(){return {url:'https://stub.supabase.co',key:'k'}},api:async function(path,o){var n=path.split('/').pop();var b=o&&o.body?JSON.parse(o.body):{};window.__calls.push([n,b]);
 if(n==='tfl_sujets_etat')return [];if(n==='tfl_candidatures_liste')return [];return {ok:true}}};"""
async def main():
    d = tempfile.mkdtemp()
    for f in ('exb-tfl.js', 'tfl-banque.json'): shutil.copy(os.path.join(ROOT, f), d)
    open(os.path.join(d, 't.html'), 'w').write('<!doctype html><html><head><meta charset="utf-8"></head><body><div class="wrap"><section id="projets"></section></div><script>%s</script><script src="exb-tfl.js"></script></body></html>' % STUB)
    class Q(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a): pass
    srv = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=d)); port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 390, 'height': 900})
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda x: asyncio.ensure_future(x.accept()))
        await pg.goto(f'http://127.0.0.1:{port}/t.html'); await pg.wait_for_timeout(1800); await pg.evaluate("show('tflSec')")
        await pg.click('[data-tfl="vue"][data-v="sujets"]')
        box = lambda: pg.locator('#tflBox').inner_text()
        ok('Banque de 4 300 sujets' in await box(), 'la banque est proposée dans 📋 Sujets (fermée au départ)')
        await pg.click('[data-tfl="bqOuvrir"]'); await pg.wait_for_selector('#tflGq', timeout=8000)
        ok('4300 sujet' in await box() or '4 300 sujet' in await box() or '4300 sujets' in (await box()).replace('\u202f', '').replace(' ', ''), 'banque chargée : 4 300 sujets')
        ok(await pg.locator('#tflGd option').count() >= 31 and await pg.locator('#tflGd optgroup').count() == 2, 'liste des domaines : 30 domaines en 2 catalogues')
        await pg.focus('#tflGq'); await pg.keyboard.type('drainage', delay=40)
        ok(await pg.input_value('#tflGq') == 'drainage' and await pg.evaluate("document.activeElement.id") == 'tflGq', 'recherche : la saisie garde le focus')
        n_dr = await pg.evaluate("EXBTFL.banque_sujets.chercher({q:'drainage'}).length")
        ok(n_dr > 0 and f'{n_dr} sujet' in await box(), f'recherche « drainage » : {n_dr} résultats affichés')
        await pg.fill('#tflGq', ''); await pg.dispatch_event('#tflGq', 'input')
        await pg.select_option('#tflGd', 'GR')
        ok('200 sujets' in await box(), 'filtre domaine Génie rural : 200 sujets')
        ok(await pg.locator('[data-tfl="bqAdd"]').count() == 25, 'liste paginée : 25 sujets par page')
        await pg.click('[data-tfl="bqPage"][data-v="1"]'); ok('Page 2 / 8' in await box(), 'page suivante : Page 2 / 8')
        await pg.click('[data-tfl="bqPage"][data-v="-1"]')
        await pg.locator('[data-tfl="bqAdd"]').first.click()
        ok('Sujet ajouté à vos fiches' in await box() and await pg.locator('text=✓ Ajouté').count() >= 1, 'un sujet ajouté : message et marque « ✓ Ajouté »')
        await pg.click('[data-tfl="bqAddAll"]')
        ok(await pg.evaluate("EXBTFL.sujets.liste().length") == 200, 'tout le domaine adopté (200 fiches)')
        ok(await pg.evaluate("EXBTFL.sujets.liste().every(function(x){return !x.publie})"), 'aucune fiche publiée automatiquement')
        ok('Mes fiches (200)' in await box() and await pg.locator('[data-tfl="sjPlus"]').count() == 1, 'mes fiches : liste limitée à 40 avec « Afficher plus »')
        await pg.click('[data-tfl="sjPlus"]'); ok(await pg.locator('[data-tfl="sjPublie"]').count() == 100, '« Afficher plus » : 100 fiches visibles')
        # synchronisation par lots de 300
        await pg.evaluate("""(function(){var T=EXBTFL.banque_sujets;T.adopter(T.chercher({dom:'ELEC'}).map(function(x){return x.ref}));
          T.adopter(T.chercher({dom:'MEC'}).map(function(x){return x.ref}).slice(0,100));
          EXBTFL.sujets.liste().forEach(function(x){EXBTFL.sujets.publier(x.ref,true)})})()""")
        n = await pg.evaluate("EXBTFL.sujets.liste().length"); ok(n == 500, f'500 fiches publiables (adoption de 300 + 200)')
        await pg.evaluate("show('tflSec')"); await pg.click('[data-tfl="sjSync"]'); await pg.wait_for_timeout(1500)
        pub = await pg.evaluate("window.__calls.filter(function(c){return c[0]==='tfl_sujets_publier'}).map(function(c){return c[1].p_sujets.length})")
        ok(pub == [300, 200], f'synchronisation en lots de 300 : {pub}')
        ok(errs == [], f'aucune erreur JavaScript {errs[:2]}')
        await b.close()
    srv.shutdown(); shutil.rmtree(d, ignore_errors=True)
    print('\nTout est OK' if not fails else f'\n{fails} échec(s)'); raise SystemExit(1 if fails else 0)
asyncio.run(main())
