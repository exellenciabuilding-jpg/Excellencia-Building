#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) des contributions TFL : python3 tools/test-tfl/e2e-contributions.py (depuis le dossier du site).
Le serveur Supabase est SIMULÉ : page publique (envoi + refus des fichiers trop lourds), puis onglet Bibliothèque › Contributions."""
import http.server, threading, socketserver, os, functools, json, sys, base64
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
BASE=f'http://127.0.0.1:{PORT}'
PDF=b'%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n'
open('/tmp/tfl-test.pdf','wb').write(PDF); open('/tmp/gros.pdf','wb').write(b'0'*(3*1024*1024+10))
with sync_playwright() as p:
    b=p.chromium.launch()
    print('# Page publique')
    ctx=b.new_context(); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:160])); sent=[]
    ctx.route('**/rest/v1/rpc/tfl_contribution_envoyer',lambda r:(sent.append(json.loads(r.request.post_data)),r.fulfill(status=200,content_type='application/json',body='{"ok":true}')))
    pg.goto(BASE+'/tfl-contribution.html?n=Paul%20Kasa&t=0991234567'); pg.wait_for_timeout(400)
    ok(pg.input_value('#nom')=='Paul Kasa' and pg.input_value('#telephone')=='0991234567','lien personnalisé : nom et téléphone pré-remplis')
    pg.fill('#titre','Étude des fondations'); pg.set_input_files('#fichier','/tmp/gros.pdf'); pg.click('#go'); pg.wait_for_timeout(300)
    ok(not sent and 'trop lourd' in pg.inner_text('#msg'),'fichier > 3 Mo refusé avant envoi')
    pg.set_input_files('#fichier','/tmp/tfl-test.pdf'); pg.fill('#annee','2024'); pg.check('#consultation'); pg.click('#go'); pg.wait_for_timeout(700)
    ok(len(sent)==1 and sent[0]['p_data']['titre']=='Étude des fondations' and sent[0]['p_data']['consultation']=='oui','fiche envoyée avec le consentement de partage')
    ok(len(sent)==1 and base64.b64decode(sent[0]['p_fichier'])==PDF and sent[0]['p_fichier_nom']=='tfl-test.pdf','fichier envoyé intact (base64)')
    ok('Merci' in pg.inner_text('#msg') and not pg.is_visible('#f'),'confirmation affichée')
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2]))
    ctx.close()
    print('# Onglet Bibliothèque › Contributions')
    ctx=b.new_context(viewport={'width':1100,'height':900}); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    pg.on('dialog',lambda d:d.accept('TestLocal#2026') if d.type=='prompt' else d.accept())
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    pg.goto(BASE+'/index.html'); pg.wait_for_timeout(3000)
    pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(3000)
    b64=base64.b64encode(PDF).decode()
    pg.evaluate("""(b64)=>{window.__traites=[];window.__rows=[{id:'22222222-2222-2222-2222-222222222222',created_at:'2026-10-21T10:00:00+00:00',imported:false,fichier_nom:'tfl-test.pdf',fichier_taille:40,
      data:{nom:'Paul Kasa',telephone:'0991234567',universite:'ISTA',annee:'2024',domaine:'genie_civil',encadreur:'Prof. X',titre:'Étude des fondations',mots_cles:'fondations',resume:'Résumé',consultation:'oui'}}];
      window.exbSb={isIn:()=>true,cfg:()=>({url:'https://exemple.supabase.co',key:'sb_publishable_x'}),api:async(path,o)=>{
        if(/tfl_candidatures_liste/.test(path))return [];
        if(/tfl_contributions_liste/.test(path))return window.__rows.map(r=>Object.assign({},r,{imported:window.__traites.indexOf(r.id)>=0}));
        if(/tfl_contribution_fichier/.test(path))return b64;
        if(/tfl_contribution_traiter/.test(path)){window.__traites.push(JSON.parse(o.body).p_id);return null}
        throw new Error('inattendu '+path)}};show('tflSec')}""",b64)
    pg.wait_for_timeout(800)
    pg.click('[data-tfl=vue][data-v=biblio]'); pg.wait_for_timeout(300)
    ok('Contributions' in pg.inner_text('#tflBox'),'onglet « 🤝 Contributions » présent dans la bibliothèque')
    pg.click('[data-tfl=bOnglet][data-v=contrib]'); pg.wait_for_timeout(300)
    pg.fill('#tflCnom','Paul Kasa'); pg.fill('#tflCtel','0991234567'); pg.click('[data-tfl=cLien]'); pg.wait_for_timeout(400)
    t=pg.inner_text('#tflBox')
    ok(BASE+'/tfl-contribution.html?n=Paul%20Kasa&t=0991234567' in t,'lien de contribution généré avec nom et téléphone')
    ok(pg.input_value('#tflCnom')=='Paul Kasa','la saisie n’est pas perdue après génération du lien')
    pg.click('[data-tfl=cRecup]'); pg.wait_for_timeout(500)
    t=pg.inner_text('#tflBox'); ok('Étude des fondations' in t and 'autorise le partage' in t,'contribution reçue en ligne affichée')
    pg.click('[data-tfl=cGarder]'); pg.wait_for_timeout(1200)
    lst=pg.evaluate("EXBTFL.biblio.liste()")
    ok(len(lst)==1 and lst[0]['type']=='tfl' and lst[0]['titre']=='Étude des fondations' and lst[0]['consultation']=='oui' and lst[0]['fichier_nom']=='tfl-test.pdf','gardée dans la bibliothèque : TFL résolu, consultation autorisée, fichier joint')
    size=pg.evaluate("EXBTFL.biblio.fichier(%s).then(b=>b.size)"%json.dumps(lst[0]['id'] if lst else ''))
    ok(size==len(PDF),'le fichier est bien enregistré sur l’appareil (%s octets)'%size)
    ok(pg.evaluate("window.__traites.length")==1,'contribution marquée « traitée » sur le serveur')
    pg.click('[data-tfl=cRecup]'); pg.wait_for_timeout(500)
    ok('Étude des fondations' not in pg.inner_text('#tflBox').split('Contributions reçues')[-1],'2e récupération : plus de doublon')
    pg.evaluate("window.exbSb.isIn=()=>false"); pg.click('[data-tfl=cRecup]'); pg.wait_for_timeout(300)
    ok('connect' in pg.inner_text('#tflBox').lower(),'non connecté : message explicite')
    ok(not errs,'index.html : aucune erreur JavaScript '+str(errs[:2]))
    ctx.close(); b.close()
print('\n'+(str(fails)+' ÉCHEC(S)' if fails else 'Tout est OK')); sys.exit(1 if fails else 0)
