/* Test bloc 3 : documents (étudiant ↔ encadreur ↔ administration) : node tools/test-tfl/test-bloc3.js
 * Navigateur et serveur SIMULÉS : le faux serveur reproduit les règles de supabase/migration-tfl-bloc3-documents.sql. */
const fs=require('fs'),path=require('path'),vm=require('vm');
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
const html=fs.readFileSync(path.join(__dirname,'../../tfl-portail.html'),'utf8');
const scripts=[...html.matchAll(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const PDF=n=>{const b=Buffer.alloc(n,7);Buffer.from('%PDF-1.4\n').copy(b);return b};

/* ---------- faux serveur ---------- */
function serveur(){
  const S={acces:[],docs:[],parts:{},n:0,calls:[],off:false};
  const find=(role,ident,mdp)=>S.acces.find(a=>a.role===role&&a.ident===ident&&a.mdp===mdp);
  const vis=(a,d)=>d.acces===a.id||(d.statut!=='envoi'&&(a.role==='etudiant'?d.dossier===a.contenu.numero:(a.contenu.dossiers||[]).some(x=>x.numero===d.dossier)));
  const js=(d,a)=>({id:d.id,de:d.de,dossier:d.dossier,genre:d.genre,titre:d.titre,note:d.note,nom:d.nom,mime:d.mime,taille:d.taille,parties:d.parties,statut:d.statut,commentaire:d.commentaire,decide_par:d.decide_par,cree_le:d.cree_le,maj_le:d.cree_le,mien:d.acces===a.id});
  const bad=(code)=>({ok:false,code});
  const magic=(ext,b)=>({pdf:()=>b.subarray(0,4).toString('latin1')==='%PDF',docx:()=>b[0]===0x50&&b[1]===0x4b,png:()=>b[0]===0x89&&b.subarray(1,4).toString()==='PNG'}[ext]||(()=>false))();
  const fn={
    tfl_portail_connexion(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return{ok:false,code:'code',minutes:0};return{ok:true,changer:false,nom:a.nom,publie_le:'2026-10-29T08:00:00Z',contenu:a.contenu,messages:[]}},
    tfl_document_creer(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');
      let d=String(b.p_dossier||'');
      if(a.role==='etudiant'){d=d||a.contenu.numero;if(d!==a.contenu.numero||a.contenu.statut!=='accepte')return bad('dossier');if(!['plan','chapitre','version_finale','autre'].includes(b.p_genre))return bad('type')}
      else{if(!(a.contenu.dossiers||[]).some(x=>x.numero===d))return bad('dossier');if(!['correction','autre'].includes(b.p_genre))return bad('type')}
      if(String(b.p_titre||'').trim().length<3)return bad('vide');
      if(!/\.(pdf|docx?|odt|pptx?|xlsx?|jpe?g|png)$/i.test(b.p_nom||''))return bad('format');
      if(b.p_taille<1)return bad('fichier_vide');if(b.p_taille>15000000)return bad('trop_lourd');
      if(b.p_parties!==Math.ceil(b.p_taille/900000))return bad('invalide');
      if(S.docs.filter(x=>x.acces===a.id).length>=60)return bad('limite');
      const doc={id:'d'+(++S.n),acces:a.id,de:a.role,dossier:d,genre:b.p_genre,titre:b.p_titre.trim(),note:b.p_note||'',nom:b.p_nom,mime:'application/pdf',taille:b.p_taille,parties:b.p_parties,statut:'envoi',commentaire:'',decide_par:'',cree_le:'2026-10-29T10:0'+S.n+':00Z'};
      S.docs.push(doc);S.parts[doc.id]={};return{ok:true,id:doc.id}},
    tfl_document_partie(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');const d=S.docs.find(x=>x.id===b.p_id&&x.acces===a.id&&x.statut==='envoi');if(!d)return bad('introuvable');
      if(b.p_idx<0||b.p_idx>=d.parties||!/^[A-Za-z0-9+/]+={0,2}$/.test(b.p_b64)||b.p_b64.length%4||b.p_b64.length>1200000||(b.p_idx<d.parties-1&&b.p_b64.length!==1200000))return bad('invalide');
      if(b.p_idx===0){const ext=d.nom.split('.').pop().toLowerCase();if(!magic(ext,Buffer.from(b.p_b64.slice(0,16),'base64'))){S.docs.splice(S.docs.indexOf(d),1);return bad('contenu')}}
      S.parts[d.id][b.p_idx]=b.p_b64;return{ok:true}},
    tfl_document_terminer(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');const d=S.docs.find(x=>x.id===b.p_id&&x.acces===a.id&&x.statut==='envoi');if(!d)return bad('introuvable');
      const P=Object.values(S.parts[d.id]);const tot=P.reduce((t,x)=>t+Buffer.from(x,'base64').length,0);if(P.length!==d.parties||tot!==d.taille)return bad('incomplet');d.statut='depose';return{ok:true}},
    tfl_document_liste(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');return{ok:true,documents:S.docs.filter(d=>vis(a,d)).sort((x,y)=>y.cree_le.localeCompare(x.cree_le)).map(d=>js(d,a))}},
    tfl_document_telecharger(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');const d=S.docs.find(x=>x.id===b.p_id);if(!d||d.statut==='envoi'||!vis(a,d))return bad('introuvable');
      const v=S.parts[d.id][b.p_idx];if(!v)return bad('introuvable');return{ok:true,b64:v,parties:d.parties,nom:d.nom,mime:d.mime,taille:d.taille}},
    tfl_document_decider(b){const a=find('encadreur',b.p_ident,b.p_mdp);if(!a)return bad('code');const d=S.docs.find(x=>x.id===b.p_id);if(!d||d.de!=='etudiant'||d.statut==='envoi'||!vis(a,d))return bad('introuvable');
      if(!['depose','a_corriger','valide'].includes(b.p_statut))return bad('type');if(b.p_statut==='a_corriger'&&String(b.p_commentaire||'').trim().length<3)return bad('vide');
      d.statut=b.p_statut;d.commentaire=b.p_commentaire||'';d.decide_par='encadreur';return{ok:true}},
    tfl_document_supprimer(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');const i=S.docs.findIndex(x=>x.id===b.p_id&&x.acces===a.id&&x.statut!=='valide');if(i<0)return bad('introuvable');S.docs.splice(i,1);return{ok:true}}};
  S.fetch=async(url,o)=>{const m=/\/rpc\/(\w+)$/.exec(url);S.calls.push(m&&m[1]);if(!m||!fn[m[1]]||(S.off&&/document/.test(m[1])))return{ok:false,status:404,json:async()=>({})};return{ok:true,status:200,json:async()=>fn[m[1]](JSON.parse(o.body))}};
  S.fn=fn;return S;
}
function navigateur(srv,role){
  const els={},downloads=[];const ids=new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m=>m[1]));
  const mk=id=>{const e={id,value:'',textContent:'',className:'',disabled:false,files:null,hidden:/\shidden[\s>]/.test((html.match(new RegExp('<[^>]*id="'+id+'"[^>]*>'))||[''])[0]),_h:'',_l:{},style:{},addEventListener(t,f){(e._l[t]=e._l[t]||[]).push(f)},focus(){},getAttribute(){return null}};
    Object.defineProperty(e,'innerHTML',{get(){return e._h},set(v){e._h=v}});return e};
  const doc={title:'',body:{className:'',appendChild(){},removeChild(){}},getElementById(id){if(els[id])return els[id];const dyn=Object.values(els).some(x=>x._h&&x._h.indexOf('id="'+id+'"')>=0);if(ids.has(id)||dyn)return els[id]=mk(id);return null},addEventListener(){},hidden:false,
    createElement(){const a={click(){downloads.push({href:a.href,download:a.download})}};return a}};
  const lastBlob={};
  const cx={document:doc,location:{search:'?role='+role},window:{EXB_SUPABASE:{url:'https://x.supabase.co',key:'sb_publishable_k'}},fetch:srv.fetch,setTimeout:()=>0,clearTimeout(){},console,Date,Math,isFinite,parseInt,String,JSON,Promise,Uint8Array,
    atob:s=>Buffer.from(s,'base64').toString('binary'),confirm:()=>true,
    Blob:class{constructor(p,o){this.parts=p;this.type=o&&o.type}},URL:{createObjectURL(b){lastBlob.b=b;return 'blob:x'},revokeObjectURL(){}},
    FileReader:class{readAsDataURL(bl){setImmediate(()=>{this.result='data:application/octet-stream;base64,'+Buffer.from(bl.buf).toString('base64');this.onload()})}}};
  cx.window.document=doc;vm.createContext(cx);vm.runInContext(scripts[scripts.length-1],cx);
  const $=id=>doc.getElementById(id),tick=()=>new Promise(r=>setImmediate(r));
  const fire=async id=>{for(const f of ($(id)._l.click||[]))await f({});await tick();await tick()};
  const clic=async(act,at)=>{at=at||{};const b={disabled:false,getAttribute:k=>({'data-act':act,'data-i':at.i==null?null:String(at.i),'data-id':at.id||null,'data-z':at.z||null,'data-p':at.p||null})[k]};const ev={target:{closest:()=>b}};
    for(const f of ($('vApp')._l.click||[]))await f(ev);await tick();await tick()};
  const login=async(ident,mdp)=>{$('idf').value=ident;$('pw').value=mdp;await fire('bLogin')};
  const fichier=(name,buf)=>({name,size:buf.length,type:'',slice:(a,b)=>({buf:buf.subarray(a,b)})});
  return{$,fire,clic,login,fichier,downloads,lastBlob};
}
const etu=(over)=>Object.assign({nom:'Jean Kasongo',matricule:'123-456-789',numero:'TFL-2026-0001',domaine:'Génie civil',statut:'accepte',statut_label:'Accepté',etape:6,progression:40,sujet_titre:'Dalle',encadreur:{nom:'Pr Ilunga',telephone:'0991234567'},historique:[],messages_admin:[],mes_propositions:[],plan:''},over||{});
const enc=(nums)=>({nom:'Pr Ilunga',max_etudiants:3,dossiers:nums.map(n=>({numero:n,etudiant:'Jean Kasongo',matricule:'123-456-789',telephone:'0812345678',universite:'UNIKIN',domaine:'Génie civil',sujet_titre:'Dalle',problematique:'P?',objectifs:'O?',methodologie:'M?',etape:6,etape_label:'Recherche',progression:40})),messages_admin:[]});
const setup=()=>{const s=serveur();s.acces.push({id:'A1',role:'etudiant',ident:'123-456-789',mdp:'Solide2026!',nom:'Jean',contenu:etu()},
  {id:'A2',role:'etudiant',ident:'222-222-222',mdp:'Solide2026!',nom:'Marie',contenu:etu({nom:'Marie',numero:'TFL-2026-0002'})},
  {id:'E1',role:'encadreur',ident:'ENC-1',mdp:'Solide2026!',nom:'Pr Ilunga',contenu:enc(['TFL-2026-0001'])},
  {id:'E2',role:'encadreur',ident:'ENC-2',mdp:'Solide2026!',nom:'Dr Autre',contenu:enc(['TFL-2026-0002'])});return s};
const PW='Solide2026!';
(async()=>{
console.log('# Étudiant : envoi');
let srv=setup(),b=navigateur(srv,'etudiant');await b.login('123-456-789',PW);
let h=b.$('vApp').innerHTML;
ok(/Envoyer le document/.test(h)&&/id="df0"/.test(h)&&/Documents/.test(h),'page Documents avec formulaire d’envoi');
await b.clic('docsend',{i:0});ok(/Choisissez un fichier/.test(b.$('md0').textContent)&&!srv.calls.includes('tfl_document_creer'),'aucun fichier : refusé avant tout envoi');
b.$('df0').files=[b.fichier('x.pdf',PDF(100))];b.$('dt0').value='ab';await b.clic('docsend',{i:0});ok(/titre/i.test(b.$('md0').textContent)&&!srv.calls.includes('tfl_document_creer'),'titre trop court refusé');
b.$('dt0').value='Chapitre 1';b.$('df0').files=[b.fichier('virus.exe',Buffer.from('MZ'))];await b.clic('docsend',{i:0});ok(/Format refusé/.test(b.$('md0').textContent)&&!srv.calls.includes('tfl_document_creer'),'extension .exe refusée sans appel serveur');
b.$('df0').files=[{name:'gros.pdf',size:16000000,slice(){}}];await b.clic('docsend',{i:0});ok(/15 Mo/.test(b.$('md0').textContent)&&!srv.calls.includes('tfl_document_creer'),'plus de 15 Mo refusé sans appel serveur');
const buf=PDF(2000000);b.$('df0').files=[b.fichier('chapitre1.pdf',buf)];b.$('dg0').value='chapitre';b.$('dt0').value='Chapitre 1 — Généralités';b.$('dn0').value='Première version';
await b.clic('docsend',{i:0});
const d1=srv.docs[0];
ok(srv.docs.length===1&&d1.statut==='depose'&&d1.parties===3&&Object.keys(srv.parts[d1.id]).length===3,'2 Mo envoyés en 3 morceaux, document « déposé »');
ok(Object.values(srv.parts[d1.id]).reduce((t,x)=>t+Buffer.from(x,'base64').length,0)===2000000,'le serveur a reçu exactement les 2 000 000 octets');
h=b.$('vApp').innerHTML;ok(/Chapitre 1 — Généralités/.test(h)&&/chapitre1\.pdf/.test(h)&&/en attente de lecture/.test(h)&&/2,0 Mo/.test(h),'le document apparaît dans « Mes documents »');
console.log('# Contenu falsifié');
b.$('df0').files=[b.fichier('faux.pdf',Buffer.from('Ceci n’est pas un PDF, juste du texte.'))];b.$('dt0').value='Faux document';await b.clic('docsend',{i:0});
ok(/ne correspond pas/.test(b.$('md0').textContent)&&srv.docs.length===1,'un .pdf qui n’est pas un PDF est refusé et supprimé du serveur');
console.log('# Téléchargement');
await b.clic('docdl',{id:d1.id,z:'mdl'});
ok(b.downloads.length===1&&b.downloads[0].download==='chapitre1.pdf'&&Buffer.concat(b.lastBlob.b.parts.map(p=>Buffer.from(p))).equals(buf),'fichier téléchargé identique à l’original');
console.log('# Confidentialité');
ok(srv.fn.tfl_document_telecharger({p_role:'etudiant',p_ident:'222-222-222',p_mdp:PW,p_id:d1.id,p_idx:0}).code==='introuvable','un autre étudiant ne peut pas télécharger');
ok(srv.fn.tfl_document_liste({p_role:'etudiant',p_ident:'222-222-222',p_mdp:PW}).documents.length===0,'un autre étudiant ne voit pas la liste');
ok(srv.fn.tfl_document_telecharger({p_role:'encadreur',p_ident:'ENC-2',p_mdp:PW,p_id:d1.id,p_idx:0}).code==='introuvable'&&srv.fn.tfl_document_liste({p_role:'encadreur',p_ident:'ENC-2',p_mdp:PW}).documents.length===0,'un encadreur non affecté ne voit rien');
console.log('# Encadreur');
let be=navigateur(srv,'encadreur');await be.login('ENC-1',PW);h=be.$('vApp').innerHTML;
ok(/Chapitre 1 — Généralités/.test(h)&&/Envoyé par l’étudiant/.test(h)&&/docval/.test(h),'l’encadreur voit le document de son étudiant avec les boutons de décision');
await be.clic('doccor',{id:d1.id,z:'mdl0'});ok(/à corriger/i.test(be.$('mdl0').textContent)&&d1.statut==='depose','« À corriger » sans commentaire refusé');
be.$('dc_'+d1.id).value='Revoir les références';await be.clic('doccor',{id:d1.id,z:'mdl0'});
ok(d1.statut==='a_corriger'&&d1.commentaire==='Revoir les références'&&d1.decide_par==='encadreur','« À corriger » enregistré avec commentaire');
await be.clic('docdl',{id:d1.id,z:'mdl0'});ok(be.downloads.length===1&&Buffer.concat(be.lastBlob.b.parts.map(p=>Buffer.from(p))).equals(buf),'l’encadreur télécharge le fichier');
be.$('df0').files=[be.fichier('correction.docx',Buffer.concat([Buffer.from([0x50,0x4b,3,4]),Buffer.alloc(500)]))];be.$('dg0').value='correction';be.$('dt0').value='Chapitre 1 annoté';await be.clic('docsend',{i:0});
ok(srv.docs.length===2&&srv.docs[1].de==='encadreur'&&srv.docs[1].statut==='depose','l’encadreur renvoie un document de correction');
console.log('# Retour à l’étudiant');
await b.clic('maj');h=b.$('vApp').innerHTML;
ok(/À corriger/.test(h)&&/Revoir les références/.test(h)&&/Encadreur : Revoir/.test(h),'l’étudiant voit « À corriger » et le commentaire');
ok(/Chapitre 1 annoté/.test(h)&&/Envoyé par votre encadreur/.test(h),'l’étudiant reçoit le document de correction');
ok(/class="nb">2</.test(h),'pastille sur le menu Documents');
const corr=srv.docs[1];ok(srv.fn.tfl_document_supprimer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_id:corr.id}).code==='introuvable','l’étudiant ne peut pas supprimer le document de l’encadreur');
console.log('# Validation et suppression');
await be.clic('docval',{id:d1.id,z:'mdl0'});ok(d1.statut==='valide','document validé par l’encadreur');
ok(srv.fn.tfl_document_supprimer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_id:d1.id}).code==='introuvable','un document validé ne peut plus être supprimé');
b.$('df0').files=[b.fichier('plan.pdf',PDF(5000))];b.$('dg0').value='plan';b.$('dt0').value='Plan v1';await b.clic('docsend',{i:0});
const d3=srv.docs.find(x=>x.titre==='Plan v1');ok(!!d3,'plan envoyé (1 morceau)');
await b.clic('docdel',{id:d3.id,z:'mdl'});ok(!srv.docs.some(x=>x.titre==='Plan v1'),'l’étudiant supprime son propre document');
console.log('# Dossier non accepté / service absent');
srv.acces[0].contenu.statut='clos';await b.clic('maj');h=b.$('vApp').innerHTML;
ok(!/id="df0"/.test(h)&&/quand votre dossier est accepté/.test(h)&&/Chapitre 1 — Généralités/.test(h),'dossier clos : lecture seule, plus de formulaire');
ok(srv.fn.tfl_document_creer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'',p_genre:'plan',p_titre:'Plan',p_note:'',p_nom:'a.pdf',p_mime:'',p_taille:10,p_parties:1}).code==='dossier','le serveur refuse aussi l’envoi');
srv.off=true;await b.clic('maj');ok(/pas encore activé/.test(b.$('vApp').innerHTML),'service non activé : message clair, le portail reste utilisable');
console.log('# Administration : assemblage des morceaux');
const T=(()=>{const src=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');const ctx={EXBTFL_MEM:{},console,clearTimeout,setTimeout,atob:s=>Buffer.from(s,'base64').toString('binary')};ctx.window=undefined;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);return ctx.EXBTFL})();
srv.off=false;
const f=await T.portail.docAssembler(async i=>srv.fn.tfl_document_telecharger({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_id:d1.id,p_idx:i}));
ok(f.nom==='chapitre1.pdf'&&f.parts.length===3&&f.taille===2000000&&Buffer.concat(f.parts.map(p=>Buffer.from(p))).equals(buf),'3 morceaux décodés et réassemblés (2 000 000 octets identiques)');
let err=false;try{await T.portail.docAssembler(async()=>({ok:false}))}catch(e){err=true}ok(err,'morceau manquant : erreur claire, pas de fichier tronqué');
console.log(fails?'\n'+fails+' ÉCHEC(S)':'\nTout est OK');process.exit(fails?1:0);
})();
