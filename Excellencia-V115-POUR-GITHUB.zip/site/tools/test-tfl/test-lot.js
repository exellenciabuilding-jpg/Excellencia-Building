/* Test de la publication de sujets EN GROUPE : node tools/test-tfl/test-lot.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const src=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
const ctx={EXBTFL_MEM:{},console};ctx.window=undefined;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);
const T=ctx.EXBTFL,S=T.sujets;
const f=(n,cat)=>({titre:'Étude du sujet numéro '+n,categorie:cat||'structures',filiere:'Génie civil',problematique:'Problématique '+n,objectifs:'Objectifs '+n});
const refs=[];for(let i=1;i<=6;i++)refs.push(S.ajouter(f(i,i<=3?'structures':'voirie')).ref);
ok(S.liste().length===6&&S.liste().every(x=>!x.publie),'6 fiches créées, aucune publiée');
console.log('# Publication en lot');
let r=S.publierLot(refs.slice(0,4),true);
ok(r.ok===4&&r.deja===0&&r.incomplets.length===0,'4 fiches publiées d’un coup ('+JSON.stringify(r)+')');
ok(S.liste().filter(x=>x.publie).length===4,'état enregistré : 4 publiées');
r=S.publierLot(refs.slice(0,6),true);
ok(r.ok===2&&r.deja===4,'republier : 2 nouvelles, 4 déjà publiées (aucun doublon)');
r=S.publierLot(refs.slice(0,3),false);
ok(r.ok===3&&S.liste().filter(x=>x.publie).length===3,'retrait en groupe : 3 fiches retirées');
r=S.publierLot(['EXB-INCONNU-1'],true);
ok(r.ok===0&&r.inconnus===1,'référence inconnue signalée, rien d’écrit');
console.log('# Fiche incomplète jamais publiée');
const mem=ctx.EXBTFL_MEM,k=Object.keys(mem).filter(x=>/suj/i.test(x))[0];
if(k){const all=typeof mem[k]==='string'?JSON.parse(mem[k]):mem[k];all[0].objectifs='';if(typeof mem[k]==='string')mem[k]=JSON.stringify(all);
 const r2=S.publierLot([all[0].ref],true);ok(r2.ok===0&&r2.incomplets.length===1&&r2.incomplets[0]===all[0].ref,'fiche sans objectifs : ignorée et signalée')}
else ok(false,'clé de stockage des sujets introuvable');
console.log('# Filtre');
S.publierLot(refs,false);
let flt=S.filtrer();ok(flt.length===6&&flt[0].ref===refs[5],'liste filtrée : 6 fiches, la plus récente d’abord');
S.publierLot(refs.slice(0,2),true);
console.log(fails?'\nÉCHECS : '+fails:'\nTout est OK');process.exit(fails?1:0);
