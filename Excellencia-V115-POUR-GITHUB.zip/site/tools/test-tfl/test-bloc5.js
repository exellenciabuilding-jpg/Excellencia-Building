/* Test bloc 5 : frais TFL et bordereaux de paiement : node tools/test-tfl/test-bloc5.js
 * Navigateur et serveur SIMULÉS : le faux serveur reproduit les règles de supabase/migration-tfl-bloc5-frais-paiements.sql
 * (il ne remplace pas un essai sur un vrai Supabase). */
const fs=require('fs'),path=require('path'),vm=require('vm');
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
const html=fs.readFileSync(path.join(__dirname,'../../tfl-portail.html'),'utf8');
const scripts=[...html.matchAll(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const srcAdm=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');
const sql=fs.readFileSync(path.join(__dirname,'../../supabase/migration-tfl-bloc5-frais-paiements.sql'),'utf8');
const PDF=n=>{const b=Buffer.alloc(n,7);Buffer.from('%PDF-1.4\n').copy(b);return b};
const PNG=n=>{const b=Buffer.alloc(n,9);Buffer.from([0x89,0x50,0x4e,0x47]).copy(b);return b};
const EXE=n=>{const b=Buffer.alloc(n,1);Buffer.from('MZ').copy(b);return b};
const pad=n=>('0'+n).slice(-2);
const iso=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const TODAY=iso(new Date()),DEMAIN=iso(new Date(Date.now()+3*86400000)),ANCIEN=iso(new Date(Date.now()-500*86400000));

/* ---------- faux serveur (règles de migration-tfl-bloc5-frais-paiements.sql) ---------- */
function serveur(){
  const S={acces:[],pay:[],parts:{},n:0,recu:0,t:0,h:0,calls:[],off:false,admin:true,registre:[],registreOff:false,noVerif:false};
  const bad=code=>({ok:false,code});
  const find=(ident,mdp)=>S.acces.find(a=>a.role==='etudiant'&&a.ident===ident&&a.mdp===mdp);
  const stamp=()=>new Date(Date.UTC(2026,9,29,8,0,++S.t)).toISOString();
  const ext=nom=>{const m=/\.([A-Za-z0-9]+)$/.exec(nom);return m?m[1].toLowerCase():null};
  const js=p=>({id:p.id,source:p.source,dossier:p.dossier,montant:p.montant,devise:p.devise,mode:p.mode,reference:p.reference,date_paiement:p.date_paiement,note:p.note,nom:p.nom_fichier,mime:p.mime,taille:p.taille,parties:p.parties,statut:p.statut,montant_confirme:p.montant_confirme,motif:p.motif,recu_no:p.recu_no,verif:(p.statut==='confirme'&&!S.noVerif)?p.verif:undefined,decide_le:p.decide_le,cree_le:p.cree_le});
  const newHash=()=>('0000000000'+(++S.h*7919+1234567).toString(16)).slice(-10);
  const reg=p=>{if(S.registreOff)return false;const k=S.registre.find(r=>r.no===p.recu_no&&r.hash===p.verif);const row={no:p.recu_no,hash:p.verif,kind:'recu',status:'valide',nom:'Jean Kasongo',matricule:'MAT',total:p.montant_confirme,cur:p.devise};if(k)Object.assign(k,row);else S.registre.push(row);return true};
  const annul=no=>{S.registre.filter(r=>r.no===no).forEach(r=>r.status='annulé')};
  const numRecu=()=>'REC-TFL-2026-'+('0000'+(++S.recu)).slice(-5);
  const adm=()=>{if(!S.admin)throw new Error('non autorisé')};
  const fn={
    tfl_portail_connexion(b){const a=find(b.p_ident,b.p_mdp)||S.acces.find(x=>x.role===b.p_role&&x.ident===b.p_ident&&x.mdp===b.p_mdp);if(!a)return{ok:false,code:'code',minutes:0};return{ok:true,changer:false,nom:a.nom,publie_le:'2026-10-29T08:00:00Z',contenu:a.contenu,messages:[]}},
    tfl_paiement_creer(b){const a=find(b.p_ident,b.p_mdp);if(!a)return bad('code');const c=a.contenu,d=c.numero||'';
      if(!d||c.statut!=='accepte')return bad('dossier');
      if(!c.frais||((Number(c.frais.montant)||0)<=0&&c.frais.exonere!==true))return bad('sans_frais');if(c.frais.exonere===true)return bad('exonere');
      const dev=String(c.frais.devise||'USD').toUpperCase().slice(0,5);
      if(!['banque','mobile_money','caisse','autre'].includes(b.p_mode))return bad('type');
      if(!(b.p_montant>0)||b.p_montant>1000000)return bad('montant');const m=Math.round(b.p_montant*100)/100;
      const ref=String(b.p_reference||'').trim().slice(0,80);if(ref.length<3)return bad('vide');
      if(!b.p_date||b.p_date>DEMAIN||b.p_date<ANCIEN.slice(0,10)||b.p_date<iso(new Date(Date.now()-400*86400000)))return bad('date');
      const nom=String(b.p_nom||'').trim().slice(0,120),e=ext(nom);if(!['pdf','jpg','jpeg','png'].includes(e))return bad('format');
      if(!(b.p_taille>=1))return bad('fichier_vide');if(b.p_taille>5000000)return bad('trop_lourd');
      if(b.p_parties!==Math.ceil(b.p_taille/900000))return bad('invalide');
      S.pay=S.pay.filter(p=>!(p.acces===a.id&&p.statut==='envoi'&&p.t<S.t-7200));
      if(S.pay.filter(p=>p.acces===a.id&&p.t>S.t-3600).length>=10)return bad('trop');
      if(S.pay.filter(p=>p.dossier===d).length>=30)return bad('limite');
      if(S.pay.filter(p=>p.acces===a.id).reduce((t,p)=>t+p.taille,0)+b.p_taille>50000000)return bad('espace');
      if(S.pay.some(p=>p.dossier===d&&['en_attente','confirme'].includes(p.statut)&&p.reference.toLowerCase()===ref.toLowerCase()&&p.montant===m))return bad('doublon');
      const p={id:'P'+(++S.n),acces:a.id,dossier:d,source:'etudiant',montant:m,devise:dev,mode:b.p_mode,reference:ref,date_paiement:b.p_date,note:String(b.p_note||'').trim().slice(0,500),nom_fichier:nom,
        mime:e==='pdf'?'application/pdf':e==='png'?'image/png':'image/jpeg',taille:b.p_taille,parties:b.p_parties,statut:'envoi',montant_confirme:null,motif:'',recu_no:null,decide_le:null,cree_le:stamp(),t:S.t};
      S.pay.push(p);return{ok:true,id:p.id}},
    tfl_paiement_partie(b){const a=find(b.p_ident,b.p_mdp);if(!a)return bad('code');const p=S.pay.find(x=>x.id===b.p_id&&x.acces===a.id&&x.statut==='envoi');if(!p)return bad('introuvable');
      if(b.p_idx==null||b.p_idx<0||b.p_idx>=p.parties)return bad('invalide');
      if(!/^[A-Za-z0-9+/]+={0,2}$/.test(b.p_b64||'')||b.p_b64.length%4||b.p_b64.length>1200000||(b.p_idx<p.parties-1&&b.p_b64.length!==1200000))return bad('invalide');
      if(b.p_idx===0){const h=Buffer.from(b.p_b64.slice(0,16),'base64'),e=ext(p.nom_fichier);
        const okSig=e==='pdf'?h.slice(0,4).toString('latin1')==='%PDF':(e==='jpg'||e==='jpeg')?(h[0]===0xff&&h[1]===0xd8&&h[2]===0xff):e==='png'?(h[0]===0x89&&h[1]===0x50&&h[2]===0x4e&&h[3]===0x47):false;
        if(!okSig){S.pay=S.pay.filter(x=>x!==p);return bad('contenu')}}
      (S.parts[p.id]=S.parts[p.id]||{})[b.p_idx]=b.p_b64;return{ok:true}},
    tfl_paiement_terminer(b){const a=find(b.p_ident,b.p_mdp);if(!a)return bad('code');const p=S.pay.find(x=>x.id===b.p_id&&x.acces===a.id&&x.statut==='envoi');if(!p)return bad('introuvable');
      const L=S.parts[p.id]||{},n=Object.keys(L).length,oct=Object.values(L).reduce((t,v)=>t+Buffer.from(v,'base64').length,0);
      if(n!==p.parties||oct!==p.taille)return bad('incomplet');p.statut='en_attente';return{ok:true}},
    tfl_paiement_liste(b){const a=find(b.p_ident,b.p_mdp);if(!a)return bad('code');const d=a.contenu.numero||'';
      const L=S.pay.filter(p=>p.dossier===d&&p.statut!=='envoi').slice().reverse();
      return{ok:true,paiements:L.map(js),confirme:S.pay.filter(p=>p.dossier===d&&p.statut==='confirme').reduce((t,p)=>t+p.montant_confirme,0),en_attente:S.pay.filter(p=>p.dossier===d&&p.statut==='en_attente').reduce((t,p)=>t+p.montant,0)}},
    tfl_paiement_telecharger(b){const a=find(b.p_ident,b.p_mdp);if(!a)return bad('code');const p=S.pay.find(x=>x.id===b.p_id);
      if(!p||p.statut==='envoi'||p.parties<1||p.dossier!==(a.contenu.numero||''))return bad('introuvable');if(b.p_idx==null||b.p_idx<0||b.p_idx>=p.parties)return bad('invalide');
      return{ok:true,b64:S.parts[p.id][b.p_idx],parties:p.parties,nom:p.nom_fichier,mime:p.mime,taille:p.taille}},
    tfl_paiement_supprimer(b){const a=find(b.p_ident,b.p_mdp);if(!a)return bad('code');const p=S.pay.find(x=>x.id===b.p_id&&x.acces===a.id&&x.source==='etudiant'&&['en_attente','refuse'].includes(x.statut));
      if(!p)return bad('introuvable');S.pay=S.pay.filter(x=>x!==p);return{ok:true}},
    tfl_paiements_admin_liste(b){adm();return S.pay.filter(p=>p.statut!=='envoi'&&(!b.p_dossier||p.dossier===b.p_dossier)).slice().reverse().map(p=>Object.assign(js(p),{auteur:p.source==='etudiant'?'Jean Kasongo':''}))},
    tfl_paiements_admin_resume(){adm();const m={};S.pay.filter(p=>p.statut!=='envoi').forEach(p=>{const k=p.dossier+'|'+p.devise;const r=m[k]=m[k]||{dossier:p.dossier,devise:p.devise,confirme:0,en_attente_n:0,en_attente_montant:0,dernier:p.cree_le};
      if(p.statut==='confirme')r.confirme+=p.montant_confirme;if(p.statut==='en_attente'){r.en_attente_n++;r.en_attente_montant+=p.montant}});return Object.values(m)},
    tfl_paiement_admin_telecharger(b){adm();const p=S.pay.find(x=>x.id===b.p_id&&x.statut!=='envoi'&&x.parties>0);if(!p)return bad('introuvable');if(b.p_idx<0||b.p_idx>=p.parties)return bad('invalide');
      return{ok:true,b64:S.parts[p.id][b.p_idx],parties:p.parties,nom:p.nom_fichier,mime:p.mime,taille:p.taille}},
    tfl_paiement_admin_decider(b){adm();if(!['confirme','refuse','en_attente'].includes(b.p_statut))return bad('type');const p=S.pay.find(x=>x.id===b.p_id&&x.statut!=='envoi');if(!p)return bad('introuvable');
      const motif=String(b.p_motif||'').trim().slice(0,500);
      if(b.p_statut==='confirme'){const m=Math.round((b.p_montant==null?p.montant:b.p_montant)*100)/100;if(m<=0||m>1000000)return bad('montant');Object.assign(p,{statut:'confirme',montant_confirme:m,motif,recu_no:p.recu_no||numRecu(),verif:p.verif||newHash(),decide_le:stamp()});return{ok:true,verifiable:reg(p)}}
      if(b.p_statut==='refuse'&&motif.length<3)return bad('vide');annul(p.recu_no);
      if(b.p_statut==='refuse')Object.assign(p,{statut:'refuse',montant_confirme:null,motif,recu_no:null,verif:null,decide_le:stamp()});
      else Object.assign(p,{statut:'en_attente',montant_confirme:null,motif:'',recu_no:null,verif:null,decide_le:null});return{ok:true,verifiable:true}},
    tfl_paiement_admin_ajouter(b){adm();const d=String(b.p_dossier||'').trim();if(!d)return bad('dossier');if(!['banque','mobile_money','caisse','autre'].includes(b.p_mode))return bad('type');
      if(!(b.p_montant>0)||b.p_montant>1000000)return bad('montant');if(!b.p_date||b.p_date>DEMAIN)return bad('date');if(S.pay.filter(p=>p.dossier===d).length>=60)return bad('limite');
      const m=Math.round(b.p_montant*100)/100,recu=numRecu();const np={id:'P'+(++S.n),acces:null,dossier:d,source:'administration',montant:m,devise:String(b.p_devise||'USD').toUpperCase(),mode:b.p_mode,reference:String(b.p_reference||'').trim(),date_paiement:b.p_date,note:String(b.p_note||'').trim(),
        nom_fichier:'',mime:'',taille:0,parties:0,statut:'confirme',montant_confirme:m,motif:'',recu_no:recu,decide_le:stamp(),cree_le:stamp(),t:S.t,verif:newHash()};S.pay.push(np);return{ok:true,id:np.id,recu_no:recu,verifiable:reg(np)}},
    tfl_paiement_admin_supprimer(b){adm();const n=S.pay.length;const q=S.pay.find(p=>p.id===b.p_id);if(q)annul(q.recu_no);S.pay=S.pay.filter(p=>p.id!==b.p_id);return{ok:S.pay.length<n}}
  };
  fn.exb_doc_verify2=b=>{const r=S.registre.find(x=>x.no===b.p_no&&x.hash===b.p_hash);return r?{found:true,kind:r.kind,status:r.status,nom:r.nom,matricule:r.matricule,total:r.total,cur:r.cur}:{found:false}};
  S.fn=fn;
  S.fetch=async(url,o)=>{const m=/\/rpc\/(\w+)$/.exec(url);S.calls.push(m&&m[1]);
    if(!m||!fn[m[1]]||(S.off&&/paiement/.test(m[1])))return{ok:false,status:404,json:async()=>({message:'Could not find the function public.'+(m&&m[1])})};
    let r;try{r=fn[m[1]](JSON.parse(o.body))}catch(e){return{ok:false,status:400,json:async()=>({message:e.message})}}return{ok:true,status:200,json:async()=>r}};
  return S;
}

/* ---------- faux navigateur (portail) ---------- */
function navigateur(srv,role){
  const els={},downloads=[],opened={html:null,n:0};const ids=new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m=>m[1]));
  const mk=id=>{const e={id,value:'',textContent:'',className:'',disabled:false,files:null,hidden:/\shidden[\s>]/.test((html.match(new RegExp('<[^>]*id="'+id+'"[^>]*>'))||[''])[0]),_h:'',_l:{},style:{},addEventListener(t,f){(e._l[t]=e._l[t]||[]).push(f)},focus(){},getAttribute(){return null}};
    Object.defineProperty(e,'innerHTML',{get(){return e._h},set(v){e._h=v}});return e};
  const doc={title:'',body:{className:'',appendChild(){},removeChild(){}},getElementById(id){if(els[id])return els[id];const dyn=Object.values(els).some(x=>x._h&&x._h.indexOf('id="'+id+'"')>=0);if(ids.has(id)||dyn)return els[id]=mk(id);return null},addEventListener(){},hidden:false,
    createElement(){const a={click(){downloads.push({href:a.href,download:a.download})}};return a}};
  const lastBlob={};
  const cx={document:doc,location:{search:'?role='+role},window:{EXB_SUPABASE:{url:'https://x.supabase.co',key:'sb_publishable_k'},EXBQR:{svg:(t)=>'<svg data-url="'+t+'"></svg>'},open(){opened.n++;return{document:{open(){},write(h){opened.html=h},close(){}}}}},fetch:srv.fetch,setTimeout:()=>0,clearTimeout(){},console,Date,Math,isFinite,parseInt,parseFloat,String,JSON,Promise,Uint8Array,Object,
    atob:s=>Buffer.from(s,'base64').toString('binary'),confirm:()=>true,
    Blob:class{constructor(p,o){this.parts=p;this.type=o&&o.type}},URL:{createObjectURL(b){lastBlob.b=b;return 'blob:x'},revokeObjectURL(){}},
    FileReader:class{readAsDataURL(bl){setImmediate(()=>{this.result='data:application/octet-stream;base64,'+Buffer.from(bl.buf).toString('base64');this.onload()})}}};
  cx.window.document=doc;vm.createContext(cx);vm.runInContext(scripts[scripts.length-1],cx);
  const $=id=>doc.getElementById(id),tick=()=>new Promise(r=>setImmediate(r));
  const fire=async id=>{for(const f of ($(id)._l.click||[]))await f({});await tick();await tick()};
  const clic=async(act,at)=>{at=at||{};const b={disabled:false,getAttribute:k=>({'data-act':act,'data-i':at.i==null?null:String(at.i),'data-id':at.id||null,'data-z':at.z||null,'data-p':at.p||null})[k]};const ev={target:{closest:()=>b}};
    for(const f of ($('vApp')._l.click||[]))await f(ev);await tick();await tick()};
  const login=async(ident,mdp)=>{$('idf').value=ident;$('pw').value=mdp;await fire('bLogin')};
  const fichier=(name,buf)=>({name,size:buf.length,type:'',slice:(a,b)=>({buf:buf.subarray(a,b)})});
  const remplir=(o)=>{const m={pam:o.montant,pamo:o.mode||'banque',par:o.ref,pad:o.date||TODAY,pan:o.note||''};Object.keys(m).forEach(k=>{if(m[k]!==undefined)$(k).value=m[k]});$('paf').files=o.fichier?[o.fichier]:[]};
  return{$,fire,clic,login,fichier,downloads,lastBlob,opened,remplir};
}

/* ---------- administration (exb-tfl.js) branchée sur le même faux serveur ---------- */
function admin(srv){
  const MEM={};
  const exbSb={isIn:()=>true,api:async(p,o)=>{const r=await srv.fetch('https://x'+p,o);const j=await r.json();if(!r.ok)throw new Error(j.message||('HTTP '+r.status));return j}};
  const opened={html:null};
  const ctx={EXBTFL_MEM:MEM,console,exbSb,document:{readyState:'complete',body:{appendChild(){},removeChild(){}},getElementById:()=>null,querySelector:()=>null,addEventListener(){},createElement(){const a={click(){}};return a}},setTimeout:()=>0,clearTimeout(){},
    location:{protocol:'https:',origin:'https://logiciel.example',pathname:'/index.html'},confirm:()=>true,navigator:{},atob:s=>Buffer.from(s,'base64').toString('binary'),
    URL:{createObjectURL:()=>'blob:x',revokeObjectURL(){}},Blob:class{constructor(p){this.parts=p}}};
  ctx.EXBQR={svg:(t)=>'<svg data-url="'+t+'"></svg>'};ctx.EXBVerif={vbase:()=>'https://site.example/'};
  ctx.open=()=>({document:{open(){},write(h){opened.html=h},close(){}}});
  ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(srcAdm,ctx);
  return{T:ctx.EXBTFL,opened,ctx};
}

const PW='Solide2026!';
const form=(o)=>({form:'EXB_TFL',version:1,submitted_at:'2026-10-17T10:00:00.000Z',ref:'',photo:'',d:Object.assign({nom:'Jean Kasongo',telephone:'0812345678',email:'j@x.cd',universite:'UNIKIN',promotion:'L3',filiere:'GC',matricule_existant:'',domaine:'genie_civil',sujet_titre:'Béton HAP',problematique:'Comment ?',objectifs:'Étudier',methodologie:'',recherches_deja:''},o||{})});

(async()=>{
  /* --- administration : configuration des frais et instantané publié --- */
  console.log('# Administration : montant standard, exceptions, instantané');
  let srv=serveur();let A=admin(srv),T=A.T;
  T.importer(form());let dos=T.dossiers()[0];T.setStatut(dos.id,'accepte');
  ok(T.portail.snapEtudiant(T.dossiers()[0]).frais===null&&T.frais.publie(T.dossiers()[0])===null,'aucun montant défini : rien n’est publié (l’étudiant est invité à écrire à l’administration)');
  let thr=false;try{T.frais.enregistrer({montant:'abc'})}catch(e){thr=true}ok(thr,'montant non numérique refusé');
  thr=false;try{T.frais.enregistrer({montant:'-5'})}catch(e){thr=true}ok(thr,'montant négatif refusé');
  thr=false;try{T.frais.enregistrer({montant:'2000000'})}catch(e){thr=true}ok(thr,'montant démesuré refusé');
  const cfg=T.frais.enregistrer({montant:'150,50',devise:'usd',intitule:'Frais de TFL 2026',instructions:'Banque X — compte 123.\nIndiquez le dossier.'});
  ok(cfg.montant===150.5&&cfg.devise==='USD'&&/Banque X/.test(cfg.instructions),'montant standard enregistré (virgule acceptée, devise en majuscules)');
  let snap=T.portail.snapEtudiant(T.dossiers()[0]);
  ok(snap.frais&&snap.frais.montant===150.5&&snap.frais.devise==='USD'&&snap.frais.exonere===false&&/Banque X/.test(snap.frais.instructions),'les frais sont dans l’instantané publié pour l’étudiant');
  T.frais.dossierEnregistrer(dos.id,{montant:'100',note:'Bourse partielle'});
  ok(T.frais.dossier(T.dossiers()[0]).montant===100&&T.frais.dossier(T.dossiers()[0]).propre&&T.portail.snapEtudiant(T.dossiers()[0]).frais.note==='Bourse partielle','montant propre à un dossier : prioritaire sur le standard, note transmise');
  T.frais.dossierEnregistrer(dos.id,{montant:'',exonere:true,note:'Exonération accordée'});
  ok(T.portail.snapEtudiant(T.dossiers()[0]).frais.exonere===true&&T.portail.snapEtudiant(T.dossiers()[0]).frais.montant===0,'exonération : montant 0, marquée « exonéré »');
  T.frais.dossierEnregistrer(dos.id,{montant:'',exonere:false,note:''});
  ok(T.frais.dossier(T.dossiers()[0]).montant===150.5&&!T.frais.dossier(T.dossiers()[0]).propre,'retour au montant standard');
  ok(JSON.stringify(T.K).includes('exb_tfl_frais'),'la configuration des frais fait partie de la sauvegarde / restauration (clé K.frais)');

  /* instantané réaliste pour le portail */
  const mat=T.etudiants()[0].matricule,numero=dos.numero;
  T.frais.enregistrer({montant:'150',devise:'USD',intitule:'Frais de TFL 2026',instructions:'Banque X — compte 123.\nMobile money : 0812 000 000.'});
  const contenu=()=>Object.assign({},T.portail.snapEtudiant(T.dossiers()[0]));
  const setup=(mod)=>{const s=serveur();const c=contenu();if(mod)mod(c);s.acces.push({id:'A1',role:'etudiant',ident:mat,mdp:PW,nom:'Jean Kasongo',contenu:c});
    s.acces.push({id:'A2',role:'etudiant',ident:'222-222-222',mdp:PW,nom:'Marie',contenu:Object.assign({},c,{nom:'Marie',matricule:'222-222-222',numero:'TFL-2026-0002'})});
    s.acces.push({id:'E1',role:'encadreur',ident:'ENC-1',mdp:PW,nom:'Pr Ilunga',contenu:{nom:'Pr Ilunga',max_etudiants:3,dossiers:[{numero:c.numero,etudiant:'Jean Kasongo',matricule:mat,etape:6,progression:10}],messages_admin:[]}});return s};

  /* --- étudiant : page Frais TFL --- */
  console.log('# Étudiant : page Frais TFL');
  srv=setup();let b=navigateur(srv,'etudiant');await b.login(mat,PW);let h=b.$('vApp').innerHTML;
  ok(/Frais TFL<\/button>|<\/span>Frais TFL/.test(h)&&/Frais TFL et paiement/.test(h),'menu « Frais TFL » et accès rapide sur le tableau de bord');
  ok(/Frais TFL : reste à payer/.test(h)&&/150\s*USD/.test(h.replace(/\u00a0/g,' ')),'tableau de bord : reste à payer 150 USD');
  ok(srv.calls.includes('tfl_paiement_liste'),'les paiements sont lus à la connexion');
  await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;const hh=h.replace(/\u00a0/g,' ');
  ok(/Frais à payer/.test(h)&&/150 USD/.test(hh)&&/Reste à payer/.test(h),'page : frais à payer, payé, en attente, reste');
  ok(/Banque X/.test(h)&&/Mobile money : 0812/.test(h)&&new RegExp('<b>'+numero+'</b>').test(h),'consignes de paiement et numéro de dossier à indiquer en référence');
  ok(/id="pam"/.test(h)&&/id="paf"/.test(h)&&/value="150"/.test(h),'formulaire de déclaration, montant prérempli avec le reste à payer');
  ok(/Aucun paiement déclaré/.test(h),'liste vide au départ');

  /* --- validations côté navigateur --- */
  console.log('# Déclaration : contrôles avant envoi');
  const crees=()=>srv.calls.filter(c=>c==='tfl_paiement_creer').length;
  b.remplir({montant:'150',ref:'BR-1001',fichier:null});await b.clic('paisend');
  ok(/Joignez le bordereau/.test(b.$('mp0').textContent)&&crees()===0,'sans fichier : refusé, aucun appel serveur');
  b.remplir({montant:'0',ref:'BR-1001',fichier:b.fichier('b.pdf',PDF(1000))});await b.clic('paisend');ok(/Montant invalide/.test(b.$('mp0').textContent)&&crees()===0,'montant nul refusé');
  b.remplir({montant:'beaucoup',ref:'BR-1001',fichier:b.fichier('b.pdf',PDF(1000))});await b.clic('paisend');ok(/Montant invalide/.test(b.$('mp0').textContent)&&crees()===0,'montant non numérique refusé');
  b.remplir({montant:'150',ref:'ab',fichier:b.fichier('b.pdf',PDF(1000))});await b.clic('paisend');ok(/Indiquez la référence/.test(b.$('mp0').textContent)&&crees()===0,'référence trop courte refusée');
  b.remplir({montant:'150',ref:'BR-1001',date:DEMAIN,fichier:b.fichier('b.pdf',PDF(1000))});await b.clic('paisend');ok(/Date de paiement invalide/.test(b.$('mp0').textContent)&&crees()===0,'date dans le futur refusée');
  b.remplir({montant:'150',ref:'BR-1001',fichier:b.fichier('virus.exe',EXE(1000))});await b.clic('paisend');ok(/PDF, JPG ou PNG/.test(b.$('mp0').textContent)&&crees()===0,'format .exe refusé');
  b.remplir({montant:'150',ref:'BR-1001',fichier:b.fichier('gros.pdf',PDF(5000001))});await b.clic('paisend');ok(/5 Mo/.test(b.$('mp0').textContent)&&crees()===0,'fichier de plus de 5 Mo refusé');
  b.remplir({montant:'150',ref:'BR-1001',fichier:b.fichier('vide.pdf',Buffer.alloc(0))});await b.clic('paisend');ok(/vide/.test(b.$('mp0').textContent)&&crees()===0,'fichier vide refusé');

  /* --- envoi réel --- */
  console.log('# Déclaration : envoi du bordereau par morceaux');
  const gros=PDF(1000000);
  b.remplir({montant:'100',mode:'mobile_money',ref:'<img src=x onerror=alert(1)>',note:'Premier versement',fichier:b.fichier('bordereau.pdf',gros)});await b.clic('paisend');
  const p1=srv.pay[0];
  ok(srv.pay.length===1&&p1.statut==='en_attente'&&p1.montant===100&&p1.devise==='USD'&&p1.mode==='mobile_money'&&p1.dossier===numero,'paiement enregistré « en attente », rattaché au dossier, devise fixée par le serveur');
  ok(p1.parties===2&&Buffer.concat([0,1].map(i=>Buffer.from(srv.parts[p1.id][i],'base64'))).equals(gros),'bordereau de 1 Mo envoyé en 2 morceaux, contenu identique');
  h=b.$('vApp').innerHTML;ok(/En attente de vérification/.test(h)&&/Paiement déclaré/.test(b.$('mp0').textContent),'état « En attente de vérification » affiché, message de confirmation');
  ok(!/<img src=x/.test(h)&&/&lt;img src=x/.test(h),'le HTML saisi dans la référence est neutralisé à l’affichage');
  ok(/En attente de vérification/.test(h)&&/100 USD/.test(h.replace(/\u00a0/g,' ')),'la somme en attente apparaît dans le résumé');
  b.remplir({montant:'100',mode:'mobile_money',ref:'<IMG src=x onerror=alert(1)>',fichier:b.fichier('b2.pdf',PDF(2000))});await b.clic('paisend');
  ok(srv.pay.length===1&&/déjà déclaré/.test(b.$('mp0').textContent),'même référence et même montant : doublon refusé');
  b.remplir({montant:'20',ref:'BR-FAUX',fichier:b.fichier('faux.pdf',PNG(2000))});await b.clic('paisend');
  ok(/ne correspond pas à son format/.test(b.$('mp0').textContent),'un « .pdf » qui est en réalité une image est refusé par le serveur (message clair)');
  ok(srv.pay.length===1&&!srv.pay.some(x=>x.reference==='BR-FAUX'),'… et rien n’est conservé');
  await b.clic('paidl',{id:p1.id,z:'mpl'});
  ok(b.downloads.length===1&&b.downloads[0].download==='bordereau.pdf'&&Buffer.concat(b.lastBlob.b.parts.map(u=>Buffer.from(u))).equals(gros),'l’étudiant retélécharge son bordereau : fichier identique');

  /* --- administration : décisions --- */
  console.log('# Administration : vérification du bordereau');
  A=admin(srv);T=A.T;T.importer(form());T.setStatut(T.dossiers()[0].id,'accepte');T.frais.enregistrer({montant:'150',devise:'USD'});const U=T.ui;
  await U.paiAdminCharger(numero);let st=U.state.pa;
  ok(st.liste.length===1&&st.liste[0].auteur==='Jean Kasongo'&&!st.err,'administration : le paiement déclaré apparaît (auteur, statut)');
  const hb=U.blocPaiements(T.dossiers()[0]);
  ok(/Frais à payer : <b>150\s*USD<\/b>/.test(hb.replace(/\u00a0/g,' '))&&/data-tfl="paiOk"/.test(hb)&&/data-tfl="paiNon"/.test(hb)&&/data-tfl="paiDl"/.test(hb)&&/data-tfl="paiAjout"/.test(hb),'fiche dossier : bordereau, Confirmer, Refuser, saisie en caisse');
  ok(!/<img src=x/.test(hb)&&/&lt;img src=x/.test(hb),'référence non fiable neutralisée dans l’écran administrateur');
  await U.paiAdminTelecharger(p1.id);ok(!U.state.pa.err&&/Téléchargé : bordereau\.pdf/.test(U.state.pa.msg),'administration : téléchargement du bordereau (morceaux réassemblés)');
  await U.paiAdminDecider(p1.id,'refuse',null,'');ok(srv.pay[0].statut==='en_attente'&&/motif/i.test(U.state.pa.err),'refus sans motif impossible');
  await U.paiAdminDecider(p1.id,'refuse',null,'Bordereau illisible, renvoyez une photo nette.');
  ok(srv.pay[0].statut==='refuse'&&srv.pay[0].recu_no===null,'refus avec motif enregistré, aucun reçu');
  await b.clic('maj');await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;
  ok(/Refusé/.test(h)&&/Bordereau illisible/.test(h)&&/class="nb">1</.test(h.split('Frais TFL')[1].slice(0,80)),'l’étudiant voit « Refusé » et le motif ; pastille « 1 » sur le menu');
  await b.clic('paidel',{id:p1.id,z:'mpl'});ok(srv.pay.length===0,'l’étudiant peut supprimer une déclaration refusée');
  b.remplir({montant:'100',mode:'banque',ref:'BR-2002',date:TODAY,fichier:b.fichier('b3.png',PNG(3000))});await b.clic('paisend');
  const p2=srv.pay[0];ok(srv.pay.length===1&&p2.statut==='en_attente'&&p2.mime==='image/png','nouvelle déclaration (PNG) acceptée');
  await U.paiAdminCharger(numero);
  const idEl=p2.id;await U.paiAdminDecider(idEl,'confirme','98,50','');
  ok(srv.pay[0].statut==='confirme'&&srv.pay[0].montant_confirme===98.5&&/^REC-TFL-2026-\d{5}$/.test(srv.pay[0].recu_no),'confirmation : montant réellement reçu (98,50) et numéro de reçu donné par le serveur');
  await b.clic('maj');await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;let h2=h.replace(/\u00a0/g,' ');
  ok(/Confirmé/.test(h)&&/REC-TFL-2026-00001/.test(h)&&/98,50 USD/.test(h2),'l’étudiant voit « Confirmé », le montant retenu et le reçu');
  ok(/51,50 USD/.test(h2.split('Reste à payer')[0]+h2.split('Reste à payer')[1].slice(0,120)),'reste à payer recalculé : 150 − 98,50 = 51,50');
  ok(!/data-act="paidel"/.test(h),'un paiement confirmé ne peut plus être supprimé par l’étudiant');
  ok(srv.fn.tfl_paiement_supprimer({p_ident:mat,p_mdp:PW,p_id:idEl}).code==='introuvable','… et le serveur le refuse aussi');
  await b.clic('pairecu',{id:idEl,z:'mpl'});
  ok(b.opened.n===1&&/REC-TFL-2026-00001/.test(b.opened.html)&&/Jean Kasongo/.test(b.opened.html)&&new RegExp(mat).test(b.opened.html)&&/98,50/.test(b.opened.html.replace(/\u00a0/g,' ')),'reçu imprimable : numéro, étudiant, matricule, montant retenu');
  ok(/Banque \(dépôt ou virement\)/.test(b.opened.html)&&/BR-2002/.test(b.opened.html),'reçu : moyen de paiement et référence');
  U.paiRecuAdmin(idEl);ok(/REC-TFL-2026-00001/.test(A.opened.html||'')&&/Jean Kasongo/.test(A.opened.html||''),'l’administration peut aussi imprimer le reçu');

  console.log('# QR de vérification du reçu');
  const urlOf=x=>{const m=/data-url="([^"]+)"/.exec(x||'');return m?m[1]:''};
  const uS=urlOf(b.opened.html),qS=uS?decodeURIComponent(uS.split('?c=')[1]).split('~'):[];
  ok(/^https:\/\/excellenciabuildingsarlu01\.netlify\.app\/verification\.html\?c=r~REC-TFL-2026-00001~\d{4}-\d{2}-\d{2}~98\.50~USD~[0-9a-f]{10}~Jean_Kasongo$/.test(uS)&&uS.length<=150,'le reçu de l’étudiant porte un QR vers verification.html (même format que les autres documents, ≤ 150 caractères)');
  ok(/class="qr"/.test(b.opened.html)&&/Vérifier ce reçu/.test(b.opened.html),'le reçu explique comment vérifier');
  let vv=srv.fn.exb_doc_verify2({p_no:qS[1],p_hash:qS[5]});
  ok(vv.found&&vv.status==='valide'&&vv.nom==='Jean Kasongo'&&vv.total===98.5&&vv.cur==='USD'&&vv.kind==='recu','le registre reconnaît le QR : valide, nom, montant retenu');
  ok(!srv.fn.exb_doc_verify2({p_no:qS[1],p_hash:'deadbeef00'}).found&&!srv.fn.exb_doc_verify2({p_no:'REC-TFL-2026-00099',p_hash:qS[5]}).found,'un code ou un numéro falsifié n’est pas reconnu');
  const uA=urlOf(A.opened.html);ok(uA.startsWith('https://site.example/verification.html?c=r~REC-TFL-2026-00001~')&&uA.split('?c=')[1].split('~')[5]===qS[5],'le reçu imprimé par l’administration porte le même code de vérification');
  ok(srv.fn.tfl_paiement_liste({p_ident:mat,p_mdp:PW}).paiements.every(x=>x.statut==='confirme'||!x.verif),'le code de vérification n’est jamais donné pour un paiement non confirmé');
  console.log('# Administration : paiement reçu à la caisse');
  await U.paiAdminAjouter(numero,{montant:'51,50',mode:'caisse',reference:'Reçu papier 0042',date:TODAY,note:'Solde'});
  ok(srv.pay.length===2&&srv.pay[1].source==='administration'&&srv.pay[1].statut==='confirme'&&srv.pay[1].recu_no==='REC-TFL-2026-00002'&&/reçu n° REC-TFL-2026-00002/.test(U.state.pa.msg),'paiement en caisse : directement confirmé, avec son reçu');
  await U.paiAdminAjouter(numero,{montant:'0',mode:'caisse',reference:'x',date:TODAY});ok(/montant/i.test(U.state.pa.err)&&srv.pay.length===2,'montant nul refusé côté administration');
  await U.paiAdminAjouter(numero,{montant:'10',mode:'caisse',reference:'x',date:DEMAIN});ok(/date/i.test(U.state.pa.err)&&srv.pay.length===2,'date future refusée côté administration');
  await b.clic('maj');await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;
  ok(/entièrement payés/.test(h)&&!/id="paf"/.test(h)&&/enregistré par l’administration/.test(h),'frais soldés : plus de formulaire, paiement de caisse visible');
  h=b.$('vApp').innerHTML;ok(/Soldés/.test(h.split('<h3>Que souhaitez')[0]||h),'tableau de bord : « Soldés »');
  /* correction d'erreur : refus après confirmation */
  const noCaisse=srv.pay[1].recu_no,hCaisse=srv.pay[1].verif;ok(srv.fn.exb_doc_verify2({p_no:noCaisse,p_hash:hCaisse}).status==='valide','le paiement de caisse est aussi inscrit au registre');
  await U.paiAdminDecider(srv.pay[1].id,'refuse',null,'Erreur de saisie');ok(srv.pay[1].statut==='refuse'&&srv.pay[1].recu_no===null,'une confirmation peut être corrigée (refus : le reçu est annulé)');
  ok(srv.fn.exb_doc_verify2({p_no:noCaisse,p_hash:hCaisse}).status==='annulé','… et son QR affiche alors « annulé » à la vérification');
  await U.paiAdminSupprimer(srv.pay[1].id);ok(srv.pay.length===1&&/supprimé/.test(U.state.pa.msg),'suppression par l’administration');

  /* --- tableau des frais --- */
  console.log('# Administration : tableau des frais et export');
  await U.fraisResumeCharger();let S5=T.frais.soldes();
  ok(U.state.fr.charge&&S5.rows.length===1&&S5.rows[0].du===150&&S5.rows[0].confirme===98.5&&S5.rows[0].reste===51.5&&S5.total.reste===51.5,'soldes par dossier : dû 150, payé 98,50, reste 51,50');
  const vf=U.vueFrais();ok(/Frais TFL/.test(vf)&&/data-tfl="fraisSave"/.test(vf)&&/data-tfl="fraisCsv"/.test(vf)&&/Où et comment payer/.test(vf),'écran « Frais TFL » : montant, consignes, export');
  const csv=T.frais.csv();ok(/^\ufeff"N° dossier";"Étudiant"/.test(csv)&&new RegExp('"'+numero+'";"Jean Kasongo"').test(csv)&&/"TOTAL"/.test(csv)&&/;"51.5"$/.test(csv),'export CSV : une ligne par dossier + total');
  srv.fn.tfl_paiement_admin_decider({p_id:srv.pay[0].id,p_statut:'en_attente'});
  ok(srv.pay[0].statut==='en_attente'&&srv.pay[0].recu_no===null,'remise en attente : reçu annulé');
  srv.pay.push({id:'PX',acces:'A1',dossier:numero,source:'etudiant',montant:5,devise:'USD',mode:'autre',reference:'zz',date_paiement:TODAY,note:'',nom_fichier:'a.pdf',mime:'application/pdf',taille:1,parties:1,statut:'en_attente',montant_confirme:null,motif:'',recu_no:null,decide_le:null,cree_le:'2026-10-29T09:00:00Z',t:0});
  await U.fraisResumeCharger();ok(T.frais.soldes().total.attenteN===2&&/fraisAVerifier\(\) \+ ' à vérifier\)'/.test(srcAdm),'paiements à vérifier comptés (pastille de l’onglet « Frais TFL »)');
  srv.pay.pop();
  const noP0=srv.pay[0].recu_no;srv.fn.tfl_paiement_admin_decider({p_id:srv.pay[0].id,p_statut:'confirme',p_montant:100});const noC=srv.pay[0].recu_no,hC=srv.pay[0].verif;
  srv.fn.tfl_paiement_admin_decider({p_id:srv.pay[0].id,p_statut:'en_attente'});ok(srv.fn.exb_doc_verify2({p_no:noC,p_hash:hC}).status==='annulé','remise en attente : le reçu est annulé au registre');
  srv.registreOff=true;await U.paiAdminDecider(srv.pay[0].id,'confirme','100','');
  ok(srv.pay[0].statut==='confirme'&&/⚠/.test(U.state.pa.msg)&&/registre/.test(U.state.pa.msg),'registre indisponible : le paiement est confirmé mais l’administration est prévenue que le QR ne sera pas reconnu');
  srv.registreOff=false;srv.noVerif=true;await b.clic('maj');await b.clic('go',{p:'frais'});b.opened.html=null;await b.clic('pairecu',{id:srv.pay[0].id,z:'mpl'});
  ok(b.opened.html&&!/class="qr"/.test(b.opened.html)&&/REC-TFL-/.test(b.opened.html),'serveur sans la partie 4 (pas de code) : le reçu s’affiche sans QR, sans erreur');srv.noVerif=false;

  /* --- confidentialité et droits --- */
  console.log('# Confidentialité');
  srv=setup();b=navigateur(srv,'etudiant');await b.login(mat,PW);
  b.remplir({montant:'30',ref:'REF-A',fichier:b.fichier('a.pdf',PDF(1500))});await b.clic('go',{p:'frais'});b.remplir({montant:'30',ref:'REF-A',fichier:b.fichier('a.pdf',PDF(1500))});await b.clic('paisend');
  const pid=srv.pay[0]&&srv.pay[0].id;ok(!!pid,'(préparation) un paiement existe');
  ok(srv.fn.tfl_paiement_telecharger({p_ident:'222-222-222',p_mdp:PW,p_id:pid,p_idx:0}).code==='introuvable','un autre étudiant ne peut pas télécharger ce bordereau');
  ok(srv.fn.tfl_paiement_liste({p_ident:'222-222-222',p_mdp:PW}).paiements.length===0,'un autre étudiant ne voit pas ces paiements');
  ok(srv.fn.tfl_paiement_supprimer({p_ident:'222-222-222',p_mdp:PW,p_id:pid}).code==='introuvable','un autre étudiant ne peut pas supprimer cette déclaration');
  ok(srv.fn.tfl_paiement_liste({p_ident:mat,p_mdp:'faux'}).code==='code','mauvais mot de passe refusé');
  ok(srv.fn.tfl_paiement_liste({p_ident:'ENC-1',p_mdp:PW}).code==='code','un code encadreur n’ouvre pas les paiements');
  srv.admin=false;A=admin(srv);await A.T.ui.paiAdminCharger(numero);ok(/non autoris/i.test(A.T.ui.state.pa.err),'sans droit administrateur : liste refusée');
  const be=navigateur(srv,'encadreur');await be.login('ENC-1',PW);h=be.$('vApp').innerHTML;
  ok(!/Frais TFL/.test(h)&&!srv.calls.slice(srv.calls.lastIndexOf('tfl_portail_connexion')).includes('tfl_paiement_liste'),'l’encadreur n’a ni menu « Frais TFL » ni accès aux paiements');

  /* --- cas limites : dossier / frais --- */
  console.log('# Cas particuliers');
  srv=setup(c=>{c.statut='complement_demande'});b=navigateur(srv,'etudiant');await b.login(mat,PW);await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;
  ok(/quand votre dossier est accepté/.test(h)&&!/id="paf"/.test(h),'dossier non accepté : pas de formulaire');
  ok(srv.fn.tfl_paiement_creer({p_ident:mat,p_mdp:PW,p_montant:10,p_mode:'banque',p_reference:'ABC',p_date:TODAY,p_note:'',p_nom:'a.pdf',p_mime:'',p_taille:10,p_parties:1}).code==='dossier','le serveur refuse aussi');
  srv=setup(c=>{c.frais=null});b=navigateur(srv,'etudiant');await b.login(mat,PW);await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;
  ok(/pas encore communiqués/.test(h)&&!/id="paf"/.test(h),'frais non définis : message clair, pas de formulaire');
  ok(srv.fn.tfl_paiement_creer({p_ident:mat,p_mdp:PW,p_montant:10,p_mode:'banque',p_reference:'ABC',p_date:TODAY,p_note:'',p_nom:'a.pdf',p_mime:'',p_taille:10,p_parties:1}).code==='sans_frais','le serveur refuse sans frais définis');
  srv=setup(c=>{c.frais={montant:0,devise:'USD',intitule:'Frais de TFL',instructions:'',exonere:true,note:'Bourse du mérite'}});b=navigateur(srv,'etudiant');await b.login(mat,PW);await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;
  ok(/exonéré/.test(h)&&/Bourse du mérite/.test(h)&&!/id="paf"/.test(h),'étudiant exonéré : message, aucune demande de paiement');
  ok(srv.fn.tfl_paiement_creer({p_ident:mat,p_mdp:PW,p_montant:10,p_mode:'banque',p_reference:'ABC',p_date:TODAY,p_note:'',p_nom:'a.pdf',p_mime:'',p_taille:10,p_parties:1}).code==='exonere','le serveur refuse pour un étudiant exonéré');
  srv=setup();b=navigateur(srv,'etudiant');await b.login(mat,PW);
  let okN=0,dernier=null;for(let i=0;i<14;i++){const r=srv.fn.tfl_paiement_creer({p_ident:mat,p_mdp:PW,p_montant:1+i,p_mode:'banque',p_reference:'LIM-'+i,p_date:TODAY,p_note:'',p_nom:'a.pdf',p_mime:'',p_taille:10,p_parties:1});if(r.ok)okN++;else dernier=r.code}
  ok(okN===10&&dernier==='trop','10 déclarations par heure au plus, ensuite « trop »');
  srv=setup();srv.off=true;b=navigateur(srv,'etudiant');await b.login(mat,PW);await b.clic('go',{p:'frais'});h=b.$('vApp').innerHTML;
  ok(/pas encore activé/.test(h)&&/Mon encadreur/.test(h),'service non activé : message clair, le portail reste utilisable');
  ok(!/id="paf"/.test(h),'… sans formulaire');
  ok(/migration-tfl-bloc5-frais-paiements\.sql/.test(admin(srv).T.frais.erreurPaiements(new Error('Could not find the function public.tfl_paiements_admin_liste'))),'service absent : l’administration est renvoyée vers le bon script SQL');

  /* --- script SQL --- */
  console.log('# Script SQL');
  const fns=[...sql.matchAll(/create or replace function public\.(\w+)\(([^)]*)\)/g)].map(m=>m[1]);
  const attendues=['tfl_paiement_creer','tfl_paiement_partie','tfl_paiement_terminer','tfl_paiement_liste','tfl_paiement_telecharger','tfl_paiement_supprimer','tfl_paiement_json','tfl_paiements_admin_liste','tfl_paiements_admin_resume','tfl_paiement_admin_telecharger','tfl_paiement_admin_decider','tfl_paiement_admin_ajouter','tfl_paiement_admin_supprimer'];
  ok(attendues.every(f=>fns.includes(f)),'les 13 fonctions « tfl_paiement% » sont définies');
  const publiques=['tfl_paiement_creer','tfl_paiement_partie','tfl_paiement_terminer','tfl_paiement_liste','tfl_paiement_telecharger','tfl_paiement_supprimer'];
  ok(publiques.every(f=>new RegExp('grant execute on function public\\.'+f+'\\([^)]*\\) to anon, authenticated').test(sql)),'fonctions étudiant : exécutables par le portail (anon) avec mot de passe vérifié');
  const admins=attendues.filter(f=>/admin/.test(f));
  ok(admins.every(f=>new RegExp('revoke all on function public\\.'+f+'\\([^)]*\\) from public, anon').test(sql)&&new RegExp('grant execute on function public\\.'+f+'\\([^)]*\\) to authenticated').test(sql))&&(sql.match(/tfl_admin_ok\(\)/g)||[]).length>=admins.length,'fonctions administrateur : réservées au compte connecté et contrôlées par tfl_admin_ok()');
  ok(/alter table public\.tfl_paiements enable row level security/.test(sql)&&/alter table public\.tfl_paiements_parties enable row level security/.test(sql)&&/revoke all on public\.tfl_paiements from anon, authenticated/.test(sql),'tables : RLS activée, aucun accès direct');
  ok(/on delete set null/.test(sql)&&!/references public\.tfl_acces\(id\) on delete cascade/.test(sql.split('create table if not exists public.tfl_paiements_parties')[0]),'l’historique financier survit à la suppression d’un accès');
  ok(/security definer set search_path/.test(sql)&&(sql.match(/security definer/g)||[]).length>=12,'fonctions en security definer avec search_path fixé');
  ok(!/p_devise text, p_mode text, p_reference text, p_date date, p_note text,\s*p_nom/.test(sql),'la devise n’est pas fournie par l’étudiant');
  const sql4=fs.readFileSync(path.join(__dirname,'../../supabase/bloc5-partie4-qr-verification.sql'),'utf8');
  ok(/add column if not exists verif_hash/.test(sql4)&&/exb_doc_registry/.test(sql4)&&/'recu'/.test(sql4)&&/substr\(md5\(random\(\)/.test(sql4),'partie 4 : code de vérification aléatoire, inscription au registre (type « recu »)');
  ok(/exception when others then\s+return false/.test(sql4)&&/exception when others then\s+null/.test(sql4),'partie 4 : un registre absent ne bloque jamais la confirmation d’un paiement');
  ok(['tfl_recu_registre','tfl_recu_annuler','tfl_paiement_admin_decider','tfl_paiement_admin_ajouter','tfl_paiement_admin_supprimer','tfl_paiement_json'].every(f=>new RegExp('create or replace function public\\.'+f).test(sql4))&&sql4.split('$$').length%2===1,'partie 4 : fonctions complètes, $$ équilibrés');
  const dec=sql4.slice(sql4.indexOf('function public.tfl_paiement_admin_decider'));ok(dec.indexOf("length(v_motif) < 3")<dec.indexOf('tfl_recu_annuler(d.recu_no)'),'un refus sans motif n’annule pas le reçu (contrôle avant annulation)');
  ok(/PARTIE 4/.test(sql)&&/tfl_recu_registre/.test(sql),'le fichier complet contient la partie 4');

  /* --- intégration source --- */
  console.log('# Intégration');
  ok(/data-v="frais">💰 Frais TFL/.test(srcAdm)&&/ST\.vue === 'frais' \? vueFrais\(\)/.test(srcAdm)&&/\+ blocEchanges\(d\)\s*\n\s*\+ blocPaiements\(d\)/.test(srcAdm),'logiciel : onglet « 💰 Frais TFL » et bloc Paiements dans la fiche dossier');
  ok(['paiCharger','paiDl','paiRecu','paiOk','paiNon','paiSupp','paiAjout','fraisResume','fraisCsv','fraisSave','fraisDos'].every(a=>new RegExp("a === '"+a+"'").test(srcAdm)),'tous les boutons administrateur sont branchés');
  const sw=fs.readFileSync(path.join(__dirname,'../../sw.js'),'utf8');ok(/tfl-bloc5-frais-paiements/.test(sw),'service worker : nouvelle version de cache (le portail à jour est rechargé)');
  console.log(fails?'\n'+fails+' ÉCHEC(S)':'\nTout est OK');process.exit(fails?1:0);
})();
