"""Test navigateur (Chromium) de l'écran 📚 Bibliothèque TFL : python3 tools/test-tfl/e2e-biblio.py
Page minimale qui charge exb-tfl.js seul (sans serveur, sans Internet)."""
import asyncio, os, sys, tempfile
from playwright.async_api import async_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
fails = 0
def ok(c, m):
    global fails
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails += 1
async def main():
    page_html = os.path.join(tempfile.mkdtemp(), 't.html')
    open(page_html, 'w').write('<!doctype html><html><head><meta charset="utf-8"></head><body><div class="wrap"><section id="projets"></section></div><script>window.show=function(){};</script><script src="file://%s/exb-tfl.js"></script></body></html>' % ROOT)
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 390, 'height': 900})
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto('file://' + page_html)
        await pg.wait_for_timeout(1800)
        await pg.evaluate("show('tflSec')")
        await pg.click('[data-tfl="vue"][data-v="biblio"]')
        ok(await pg.locator('h3:has-text("Bibliothèque TFL")').count() == 1, 'bouton 📚 Bibliothèque ouvre l’écran')
        # --- TFL résolus : deux fichiers d'un coup ---
        d = tempfile.mkdtemp()
        f1 = os.path.join(d, 'TFL_Dalle_Pleine.pdf'); open(f1, 'wb').write(b'%PDF-1.4 test dalle')
        f2 = os.path.join(d, 'TFL_Route.docx'); open(f2, 'wb').write(b'PK docx')
        await pg.fill('#tflBu', 'UNIKIN'); await pg.fill('#tflBy', '2022')
        await pg.set_input_files('#tflBf', [f1, f2])
        await pg.click('[data-tfl="bAjouter"]')
        await pg.wait_for_selector('text=TFL Dalle Pleine')
        ok(await pg.locator('text=TFL Route').count() >= 1, '2 fichiers importés d’un coup (titres pris dans les noms)')
        ok(await pg.locator('text=UNIKIN').count() >= 2, 'université et année communes appliquées aux fiches')
        # --- recherche ---
        await pg.fill('#tflBq', 'route')
        await pg.wait_for_timeout(200)
        ok(await pg.locator('[data-tfl="bEdit"]').count() == 1, 'recherche filtre la liste (1 fiche sur 2)')
        ok(await pg.evaluate("document.activeElement.id") == 'tflBq', 'le curseur reste dans la zone de recherche')
        await pg.fill('#tflBq', '')
        await pg.wait_for_timeout(200)
        # --- téléchargement ---
        async with pg.expect_download() as dl:
            await pg.locator('[data-tfl="bTelecharger"]').first.click()
        dw = await dl.value
        ok(dw.suggested_filename in ('TFL_Dalle_Pleine.pdf', 'TFL_Route.docx'), 'téléchargement du fichier gardé : ' + dw.suggested_filename)
        # --- sujets reçus ---
        await pg.click('[data-tfl="bOnglet"][data-v="sujet"]')
        s1 = os.path.join(d, 'sujet-paul.pdf'); open(s1, 'wb').write(b'%PDF-1.4 sujet')
        await pg.click('[data-tfl="bAjouter"]')
        await pg.wait_for_selector('text=indiquez')
        ok(True, 'sujet sans titre ni fichier : message d’erreur')
        await pg.fill('#tflBa', 'Paul Ngoy'); await pg.fill('#tflBtel', '0970000001'); await pg.fill('#tflBt', 'Fondations sur argile')
        await pg.set_input_files('#tflBf', [s1])
        await pg.click('[data-tfl="bAjouter"]')
        await pg.wait_for_selector('b:has-text("Fondations sur argile")')
        ok(await pg.locator('text=À étudier').count() >= 1, 'sujet reçu enregistré, statut « À étudier »')
        ok('1 à étudier' in await pg.locator('[data-tfl="bOnglet"][data-v="sujet"]').inner_text(), 'compteur « à étudier » sur l’onglet')
        await pg.click('[data-tfl="bStatut"][data-v="accepte"]')
        ok(await pg.locator('span:has-text("Accepté")').count() >= 1, 'statut changé en « Accepté »')
        ok('wa.me/243970000001' in (await pg.locator('a:has-text("WhatsApp")').first.get_attribute('href')), 'bouton WhatsApp avec le numéro (+243) et message prêt')
        await pg.click('[data-tfl="bVersDossier"]')
        await pg.wait_for_selector('text=dossier TFL-')
        ok(await pg.locator('[data-tfl="bOuvrirDos"]').count() == 1, 'sujet → dossier de candidature créé et lié')
        await pg.screenshot(path='/home/claude/biblio-mobile.png', full_page=True)
        await pg.click('[data-tfl="bOuvrirDos"]')
        ok(await pg.locator('#tflDetail').count() == 1, 'le bouton « Dossier » ouvre la fiche du dossier')
        # persistance : recharger la page
        await pg.reload(); await pg.wait_for_timeout(1800)
        await pg.evaluate("show('tflSec')"); await pg.click('[data-tfl="vue"][data-v="biblio"]')
        ok(await pg.locator('text=TFL Dalle Pleine').count() >= 1, 'TFL résolus encore là après rechargement (fiche + fichier)')
        async with pg.expect_download() as dl2:
            await pg.locator('[data-tfl="bTelecharger"]').first.click()
        ok((await dl2.value) is not None, 'fichier toujours téléchargeable après rechargement (IndexedDB)')
        ok(not errs, 'aucune erreur JavaScript' + (' : ' + '; '.join(errs) if errs else ''))
        await b.close()
    print('\n%s' % ('%d ÉCHEC(S)' % fails if fails else 'Tout est OK'))
    sys.exit(1 if fails else 0)
asyncio.run(main())
