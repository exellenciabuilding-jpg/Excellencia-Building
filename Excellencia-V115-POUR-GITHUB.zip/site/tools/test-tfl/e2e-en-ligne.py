#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) du TFL en ligne + hors ligne : python3 tools/test-tfl/e2e-en-ligne.py (depuis le dossier du site).
Le serveur Supabase est SIMULÉ (aucune requête réelle) : on vérifie le formulaire, le lien Internet et l'import dans l'onglet TFL."""
import http.server, threading, socketserver, os, functools, json, sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
BASE=f'http://127.0.0.1:{PORT}'
def remplir(pg):
    pg.fill('#nom','Aline Tshala'); pg.fill('#telephone','0991112222'); pg.fill('#universite','ISTA')
    pg.select_option('#domaine','architecture'); pg.fill('#sujet_titre','Habitat bioclimatique')
    pg.fill('#problematique','Comment concevoir…'); pg.fill('#objectifs','Proposer…')
with sync_playwright() as p:
    b=p.chromium.launch()
    # ---------- 1. Formulaire : envoi en ligne ----------
    print('# Formulaire — en ligne')
    ctx=b.new_context(); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    sent=[]
    def rpc_ok(route):
        sent.append(json.loads(route.request.post_data)); route.fulfill(status=200,content_type='application/json',body='{"ok":true}')
    ctx.route('**/rest/v1/rpc/tfl_candidature_envoyer',rpc_ok)
    pg.goto(BASE+'/tfl-formulaire.html?n=Aline%20Tshala&t=0991112222&r=REF-XY12'); pg.wait_for_timeout(500)
    ok(pg.input_value('#nom')=='Aline Tshala' and pg.input_value('#telephone')=='0991112222','lien Internet personnalisé : nom et téléphone pré-remplis')
    ok(pg.is_visible('#online') and not pg.is_disabled('#online'),'bouton « Envoyer en ligne » visible quand le serveur est configuré')
    remplir(pg); pg.click('#online'); pg.wait_for_timeout(600)
    ok(len(sent)==1 and sent[0]['p_data']['sujet_titre']=='Habitat bioclimatique' and sent[0]['p_ref']=='REF-XY12' and sent[0]['p_submitted'],'candidature envoyée au serveur (données, référence, horodatage)')
    ok('envoyée' in pg.inner_text('#msg') and pg.is_disabled('#online'),'confirmation affichée, formulaire verrouillé')
    ok(pg.evaluate("localStorage.getItem('exb_tfl_brouillon')")is None,'brouillon effacé après envoi réussi')
    ok(not errs,'aucune erreur JavaScript '+str(errs[:2]))
    ctx.close()
    # ---------- 2. Service non activé / réseau coupé : le fichier reste possible ----------
    print('# Formulaire — repli')
    ctx=b.new_context(accept_downloads=True); pg=ctx.new_page()
    ctx.route('**/rest/v1/rpc/tfl_candidature_envoyer',lambda r:r.fulfill(status=404,content_type='application/json',body='{"message":"Could not find the function public.tfl_candidature_envoyer"}'))
    pg.goto(BASE+'/tfl-formulaire.html'); pg.wait_for_timeout(400); remplir(pg); pg.click('#online'); pg.wait_for_timeout(500)
    ok('pas encore activé' in pg.inner_text('#msg'),'service non activé : message clair + réponses conservées')
    ok(pg.input_value('#nom')=='Aline Tshala','réponses conservées après échec')
    pg.reload(); pg.wait_for_timeout(300)
    ok(pg.input_value('#sujet_titre')=='Habitat bioclimatique','brouillon rechargé après fermeture de la page')
    ctx.set_offline(True); pg.evaluate("window.dispatchEvent(new Event('offline'))"); pg.wait_for_timeout(200)
    ok(pg.is_disabled('#online'),'hors connexion : envoi en ligne désactivé')
    with pg.expect_download() as dl: pg.click('#send')
    d=dl.value; path=d.path(); o=json.load(open(path,encoding='utf-8'))
    ok(o['form']=='EXB_TFL' and o['d']['nom']=='Aline Tshala' and o['submitted_at'],'hors connexion : fichier .json créé ('+d.suggested_filename+')')
    ctx.close()
    # ---------- 3. Onglet TFL de l'application ----------
    print('# Onglet TFL')
    ctx=b.new_context(viewport={'width':1100,'height':900}); pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    pg.on('dialog',lambda d:d.accept('TestLocal#2026') if d.type=='prompt' else d.accept())
    pg.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")  # écran de licence retiré UNIQUEMENT dans ce test
    pg.goto(BASE+'/index.html'); pg.wait_for_timeout(3000)
    pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(3000)
    pg.evaluate("""()=>{window.__rows=[{id:'11111111-1111-1111-1111-111111111111',created_at:'2026-10-21T10:00:00+00:00',submitted_at:'2026-10-21T09:59:58+00:00',ref:'REF-XY12',imported:false,photo:null,
      data:{nom:'Aline Tshala',telephone:'0991112222',email:'',universite:'ISTA',promotion:'',filiere:'',matricule_existant:'',domaine:'architecture',sujet_titre:'Habitat bioclimatique',problematique:'P',objectifs:'O',methodologie:'',recherches_deja:''}}];
      window.__traites=[];
      window.exbSb={isIn:()=>true,cfg:()=>({url:'https://exemple.supabase.co',key:'sb_publishable_x'}),api:async(path,o)=>{
        if(/tfl_candidatures_liste/.test(path))return window.__rows.map(r=>Object.assign({},r,{imported:window.__traites.indexOf(r.id)>=0}));
        if(/tfl_candidature_traiter/.test(path)){window.__traites.push(JSON.parse(o.body).p_id);return null}
        throw new Error('inattendu '+path)}};
      show('tflSec')}""")
    pg.wait_for_timeout(800)
    txt=pg.inner_text('#tflBox')
    ok('Lien Internet' in txt and 'Fichier hors ligne' in txt,'onglet TFL : lien Internet ET fichier hors ligne proposés')
    ok('1 nouvelle' in txt,'compteur : 1 nouvelle candidature en ligne détectée à l’ouverture')
    pg.fill('#tflPnom','Marc Ilunga'); pg.fill('#tflPtel','0970001111')
    pg.evaluate("navigator.clipboard&&navigator.clipboard.writeText&&0"); pg.click('[data-tfl=lienCopier]'); pg.wait_for_timeout(400)
    lien=pg.input_value('#tflBox input[readonly]')
    ok(lien.startswith(BASE+'/tfl-formulaire.html?') and 'n=Marc%20Ilunga' in lien and 't=0970001111' in lien,'lien Internet généré avec les infos de l’étudiant : '+lien[:90])
    ok(pg.input_value('#tflPnom')=='Marc Ilunga','la saisie n’est pas perdue après génération du lien')
    pg.click('[data-tfl=enligne]'); pg.wait_for_timeout(800)
    n=pg.evaluate("EXBTFL.dossiers().length"); num=pg.evaluate("(EXBTFL.dossiers()[0]||{}).numero")
    ok(n==1 and str(num).startswith('TFL-'),'candidature reçue en ligne → dossier '+str(num)+' créé')
    ok(pg.evaluate("window.__traites.length")==1,'candidature marquée « traitée » sur le serveur')
    pg.click('[data-tfl=enligne]'); pg.wait_for_timeout(500)
    ok(pg.evaluate("EXBTFL.dossiers().length")==1,'2e récupération : aucun doublon')
    # non connecté
    pg.evaluate("window.exbSb.isIn=()=>false"); pg.click('[data-tfl=enligne]'); pg.wait_for_timeout(300)
    ok('connect' in pg.inner_text('#tflBox').lower(),'non connecté au serveur : message explicite')
    ok(not errs,'index.html : aucune erreur JavaScript '+str(errs[:2]))
    ctx.close(); b.close()
print('\n'+(str(fails)+' ÉCHEC(S)' if fails else 'Tout est OK')); sys.exit(1 if fails else 0)
