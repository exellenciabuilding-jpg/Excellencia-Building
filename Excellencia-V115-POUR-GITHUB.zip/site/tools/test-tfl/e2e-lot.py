"""Test navigateur (Chromium, écran 390 px) de la publication de sujets EN GROUPE : python3 tools/test-tfl/e2e-lot.py"""
import asyncio, os, sys, tempfile, shutil, http.server, socketserver, threading, functools
from playwright.async_api import async_playwright
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
fails = 0
def ok(c, m):
    global fails
    print(('  OK   ' if c else '  FAIL ') + m)
    if not c: fails += 1
STUB = """window.show=function(){};window.__calls=[];
window.exbSb={isIn:function(){return true},cfg:function(){return {url:'https://stub.supabase.co',key:'k'}},api:async function(path,o){var n=path.split('/').pop();var b=o&&o.body?JSON.parse(o.body):{};window.__calls.push([n,b]);
 if(n==='tfl_sujets_etat')return [];if(n==='tfl_candidatures_liste')return [];return {ok:true}}};"""
async def main():
    d = tempfile.mkdtemp()
    for f in ('exb-tfl.js', 'tfl-banque.json'): shutil.copy(os.path.join(ROOT, f), d)
    open(os.path.join(d, 't.html'), 'w').write('<!doctype html><html><head><meta charset="utf-8"></head><body><div class="wrap"><section id="projets"></section></div><script>%s</script><script src="exb-tfl.js"></script></body></html>' % STUB)
    class Q(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a): pass
    srv = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(Q, directory=d)); port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 390, 'height': 900})
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda x: asyncio.ensure_future(x.accept()))
        await pg.goto(f'http://127.0.0.1:{port}/t.html'); await pg.wait_for_timeout(1800); await pg.evaluate("show('tflSec')")
        await pg.evaluate("""(function(){for(var i=1;i<=8;i++)EXBTFL.sujets.ajouter({titre:'Étude du béton numéro '+i,categorie:i<=5?'structures':'voirie',problematique:'Problématique '+i,objectifs:'Objectifs '+i})})()""")
        await pg.click('[data-tfl="vue"][data-v="sujets"]')
        box = lambda: pg.locator('#tflBox').inner_text()
        ok('Publier en groupe' in await box(), 'barre « Publier en groupe » affichée')
        ok(await pg.locator('input[data-tfl="sjSel"]').count() == 8, 'une case à cocher par fiche (8)')
        ok(await pg.locator('[data-tfl="sjLotPub"]').is_disabled(), 'bouton Publier désactivé tant que rien n’est coché')
        # sélection individuelle puis en groupe
        await pg.locator('input[data-tfl="sjSel"]').nth(0).click(); await pg.locator('input[data-tfl="sjSel"]').nth(1).click()
        ok('2 sélectionnées' in await box(), 'cocher 2 fiches : « 2 sélectionnées »')
        await pg.click('[data-tfl="sjLotPub"]'); await pg.wait_for_timeout(500)
        n_pub = await pg.evaluate("EXBTFL.sujets.liste().filter(function(x){return x.publie}).length")
        ok(n_pub == 2, 'Publier la sélection : 2 fiches publiées d’un coup')
        calls = await pg.evaluate("window.__calls.map(function(c){return c[0]})")
        ok('tfl_sujets_publier' in calls, 'envoi automatique au serveur (synchronisation) après publication')
        # filtre + tout sélectionner
        await pg.select_option('#tflFp', 'non'); await pg.wait_for_timeout(200)
        ok(await pg.locator('input[data-tfl="sjSel"]').count() == 6, 'filtre « Non publiées » : 6 fiches')
        await pg.select_option('#tflFc', 'voirie'); await pg.wait_for_timeout(200)
        ok(await pg.locator('input[data-tfl="sjSel"]').count() == 1, 'filtre catégorie « Routes et voirie » (parmi les non publiées) : 1 fiche (les 2 autres fiches voirie sont déjà publiées)')
        await pg.click('[data-tfl="sjSelTous"]'); await pg.wait_for_timeout(200)
        ok('1 sélectionnée' in await box(), '« Sélectionner les résultats » : 1 sélectionnée')
        await pg.click('[data-tfl="sjLotPub"]'); await pg.wait_for_timeout(500)
        ok(await pg.evaluate("EXBTFL.sujets.liste().filter(function(x){return x.publie}).length") == 3, 'publier ce résultat : 3 publiées au total')
        # tout ce qui reste non publié
        await pg.select_option('#tflFc', 'tous'); await pg.select_option('#tflFp', 'non'); await pg.wait_for_timeout(200)
        await pg.click('[data-tfl="sjPubTout"]'); await pg.wait_for_timeout(500)
        ok(await pg.evaluate("EXBTFL.sujets.liste().filter(function(x){return x.publie}).length") == 8, '« Publier toutes les non publiées affichées » : 8 publiées')
        # retrait en groupe
        await pg.select_option('#tflFp', 'tous'); await pg.fill('#tflFq', 'numéro 7'); await pg.wait_for_timeout(250)
        ok(await pg.locator('input[data-tfl="sjSel"]').count() == 1, 'recherche « numéro 7 » : 1 fiche (focus conservé)')
        await pg.fill('#tflFq', ''); await pg.wait_for_timeout(250)
        await pg.click('[data-tfl="sjSelTous"]'); await pg.click('[data-tfl="sjLotRet"]'); await pg.wait_for_timeout(600)
        ok(await pg.evaluate("EXBTFL.sujets.liste().filter(function(x){return x.publie}).length") == 0, 'Retirer la sélection : plus aucune fiche publiée')
        ok(errs == [], 'aucune erreur JavaScript ' + str(errs))
        await b.close()
    srv.shutdown()
    print('\nÉCHECS : %d' % fails if fails else '\nTout est OK'); sys.exit(1 if fails else 0)
asyncio.run(main())
