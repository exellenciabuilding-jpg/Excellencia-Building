/* Test de la page tfl-portail.html (étudiant / encadreur) : node tools/test-tfl/test-portail.js
 * Navigateur et serveur SIMULÉS : le faux serveur reproduit les règles de supabase/migration-v99zzt-tfl-portails.sql
 * (blocage après 5 essais, changement de mot de passe obligatoire, droits par dossier). Il ne remplace pas un essai sur un vrai Supabase. */
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
const html=fs.readFileSync(path.join(__dirname,'../../tfl-portail.html'),'utf8');
const scripts=[...html.matchAll(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
const norm=s=>String(s||'').replace(/[^A-Za-z0-9]/g,'').toUpperCase();
const H=(m,r,i)=>crypto.createHash('sha256').update(m+':'+r+':'+norm(i)).digest('hex');

/* ---------- faux serveur ---------- */
function serveur(){
  const S={acces:[],msgs:[],now:Date.now(),calls:[]};
  const add=(role,ident,nom,code,contenu)=>S.acces.push({id:'a'+S.acces.length,role,identifiant:norm(ident),nom,mdp:H(code,role,ident),doit_changer:true,actif:true,essais:0,bloque:0,contenu});
  const check=(role,ident,mdp)=>{const a=S.acces.find(x=>x.role===role&&x.identifiant===norm(ident));if(!a)return{err:'code'};
    if(a.bloque>S.now)return{err:'bloque',min:Math.ceil((a.bloque-S.now)/60000)};
    if(a.mdp!==H(mdp||'',a.role,a.identifiant)){if(a.essais+1>=5){a.essais=0;a.bloque=S.now+15*60000;return{err:'bloque',min:15}}a.essais++;return{err:'code'}}
    if(!a.actif)return{err:'revoque'};a.essais=0;a.bloque=0;return{a}};
  const fn={
    tfl_portail_connexion(b){const c=check(b.p_role,b.p_ident,b.p_mdp);if(c.err)return{ok:false,code:c.err,minutes:c.min||0};
      if(c.a.doit_changer)return{ok:true,changer:true,nom:c.a.nom};
      return{ok:true,changer:false,nom:c.a.nom,publie_le:'2026-10-23T08:00:00Z',contenu:c.a.contenu,messages:S.msgs.filter(m=>m.acces===c.a.id).map(m=>({de:m.de,type:m.type,dossier:m.dossier,texte:m.texte,valeur:m.valeur,cree_le:m.cree_le}))}},
    tfl_portail_changer(b){const c=check(b.p_role,b.p_ident,b.p_mdp);if(c.err)return{ok:false,code:c.err,minutes:c.min||0};
      if(String(b.p_nouveau||'').length<8||b.p_nouveau===b.p_mdp)return{ok:false,code:'faible'};c.a.mdp=H(b.p_nouveau,c.a.role,c.a.identifiant);c.a.doit_changer=false;return{ok:true}},
    tfl_portail_envoyer(b){const c=check(b.p_role,b.p_ident,b.p_mdp);if(c.err)return{ok:false,code:c.err,minutes:c.min||0};if(c.a.doit_changer)return{ok:false,code:'changer'};
      const type=b.p_type||'message';if(c.a.role==='etudiant'&&type!=='message')return{ok:false,code:'type'};
      let d=String(b.p_dossier||'');const okd=c.a.role==='etudiant'?(d||c.a.contenu.numero)===c.a.contenu.numero:(c.a.contenu.dossiers||[]).some(x=>x.numero===d);if(!okd)return{ok:false,code:'dossier'};
      if(type==='progression'){if(b.p_valeur==null||b.p_valeur<0||b.p_valeur>100)return{ok:false,code:'valeur'}}else if(String(b.p_texte||'').trim().length<2)return{ok:false,code:'vide'};
      S.msgs.push({acces:c.a.id,de:c.a.role,type,dossier:d||c.a.contenu.numero,texte:String(b.p_texte||'').trim(),valeur:type==='progression'?b.p_valeur:null,cree_le:new Date(S.now+S.msgs.length*1000).toISOString()});return{ok:true}}};
  Object.assign(fn,{
    tfl_portail_publier(b){const ident=norm(b.p_ident);let a=S.acces.find(x=>x.role===b.p_role&&x.identifiant===ident);const code=b.p_code||'';
      if(!a){if(!code)throw new Error('code_requis');add(b.p_role,ident,b.p_nom,code,b.p_contenu);return{ok:true,nouveau:true}}
      a.nom=b.p_nom;a.contenu=b.p_contenu;a.actif=true;if(code){a.mdp=H(code,a.role,a.identifiant);a.doit_changer=true;a.essais=0;a.bloque=0}return{ok:true,nouveau:false}},
    tfl_portail_revoquer(b){const a=S.acces.find(x=>x.role===b.p_role&&x.identifiant===norm(b.p_ident));if(a)a.actif=false;return null},
    tfl_portail_liste(){return S.acces.map(a=>({role:a.role,identifiant:a.identifiant,nom:a.nom,actif:a.actif,doit_changer:a.doit_changer,connexions:0,derniere_connexion:null,publie_le:'2026-10-23T08:00:00Z'}))},
    tfl_portail_retours(){return S.msgs.filter(m=>!m.traite).map((m,i)=>{const a=S.acces.find(x=>x.id===m.acces);return{id:m.id||(m.id='m'+i+'-'+S.msgs.indexOf(m)),role:a.role,identifiant:a.identifiant,nom:a.nom,de:m.de,type:m.type,dossier:m.dossier,texte:m.texte,valeur:m.valeur,cree_le:m.cree_le}})},
    tfl_portail_retours_traiter(b){S.msgs.forEach(m=>{if((b.p_ids||[]).indexOf(m.id)>=0)m.traite=true});return null}});
  S.add=add;S.fetch=async(url,o)=>{const m=/\/rpc\/(\w+)$/.exec(url);S.calls.push(m&&m[1]);if(!m||!fn[m[1]])return{ok:false,status:404,json:async()=>({})};let r;try{r=fn[m[1]](JSON.parse(o.body))}catch(e){return{ok:false,status:400,json:async()=>({message:e.message})}}return{ok:true,status:200,json:async()=>r}};
  return S;
}

/* ---------- faux navigateur ---------- */
function navigateur(role,srv){
  const els={};const ids=new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m=>m[1]));
  const mk=id=>{const e={id,value:'',textContent:'',className:'',disabled:false,hidden:/\shidden[\s>]/.test((html.match(new RegExp('<[^>]*id="'+id+'"[^>]*>'))||[''])[0]),_h:'',_l:{},style:{},
    addEventListener(t,f){(e._l[t]=e._l[t]||[]).push(f)},focus(){},getAttribute(k){return e._a?e._a[k]:null}};
    Object.defineProperty(e,'innerHTML',{get(){return e._h},set(v){e._h=v}});return e};
  const doc={title:'',body:{className:''},getElementById(id){if(els[id])return els[id];const dyn=Object.values(els).some(x=>x._h&&x._h.indexOf('id="'+id+'"')>=0);if(ids.has(id)||dyn)return els[id]=mk(id);return null},addEventListener(){},hidden:false};
  const ctx={document:doc,location:{search:role==='encadreur'?'?role=encadreur':'?role=etudiant'},window:{EXB_SUPABASE:{url:'https://x.supabase.co',key:'sb_publishable_k'}},fetch:srv.fetch,setTimeout:()=>0,clearTimeout(){},console,Date,Math,isFinite,parseInt,String,JSON,Promise};
  ctx.window.document=doc;vm.createContext(ctx);vm.runInContext(scripts[scripts.length-1],ctx);
  const $=id=>doc.getElementById(id),tick=()=>new Promise(r=>setImmediate(r));
  const fire=async(id)=>{for(const f of ($(id)._l.click||[]))await f({});await tick();await tick()};
  const clic=async(act,i,zoneEvt)=>{const b={disabled:false,getAttribute:k=>({'data-act':act,'data-i':i==null?null:String(i)})[k]};const ev={target:{closest:()=>b}};
    for(const f of ($('vApp')._l.click||[]))await f(ev);await tick();await tick()};
  return{$,fire,clic,doc,tick};
}
const etuContenu={nom:'Jean Kasongo',matricule:'123-456-789',numero:'TFL-2026-0001',domaine:'Génie civil',statut:'accepte',statut_label:'Accepté',etape:6,etape_label:'Recherche et rédaction',progression:40,sujet_titre:'Béton <b>HAP</b> & dalles',motif_decision:'',sujet_label:'Accepté',univ_label:'En attente',encadreur:{nom:'Pr Ilunga',telephone:'0991234567'},historique:[{at:'2026-10-20T10:00:00Z',label:'Statut : Accepté'}],messages_admin:[{at:'2026-10-21T09:00:00Z',texte:'Bienvenue <script>x</script>',dossier:'TFL-2026-0001'}]};
const encContenu={nom:'Pr Ilunga',max_etudiants:3,dossiers:[{numero:'TFL-2026-0001',etudiant:'Jean Kasongo',matricule:'123-456-789',telephone:'0812345678',universite:'UNIKIN',domaine:'Génie civil',sujet_titre:'Béton HAP',problematique:'P?',objectifs:'O?',methodologie:'M?',etape:6,etape_label:'Recherche et rédaction',progression:40}],messages_admin:[]};

(async()=>{
console.log('# Portail étudiant');
let srv=serveur();srv.add('etudiant','123-456-789','Jean Kasongo','482913',etuContenu);srv.add('encadreur','ENC-1234','Pr Ilunga','777111',encContenu);
let b=navigateur('etudiant',srv);
ok(b.doc.title.includes('étudiant'),'titre « Espace étudiant »');
b.$('idf').value='';b.$('pw').value='';await b.fire('bLogin');ok(/Saisissez/.test(b.$('m1').textContent),'champs vides refusés');
b.$('idf').value='123-456-789';b.$('pw').value='faux';await b.fire('bLogin');ok(/incorrect/.test(b.$('m1').textContent),'mauvais mot de passe : message générique');
b.$('idf').value='000-000-000';b.$('pw').value='x';await b.fire('bLogin');ok(/incorrect/.test(b.$('m1').textContent),'identifiant inconnu : même message (pas de fuite)');
b.$('idf').value='123456789';b.$('pw').value='482913';await b.fire('bLogin');
ok(!b.$('vChg').hidden&&b.$('vLogin').hidden&&b.$('vApp').hidden,'1re connexion (matricule sans tirets accepté) → changement de mot de passe obligatoire');
b.$('np').value='court';b.$('np2').value='court';await b.fire('bChg');ok(/8 caractères/.test(b.$('m2').textContent),'nouveau mot de passe < 8 caractères refusé');
b.$('np').value='Solide2026!';b.$('np2').value='Autre2026!';await b.fire('bChg');ok(/différents/.test(b.$('m2').textContent),'confirmation différente refusée');
b.$('np').value='482913';b.$('np2').value='482913';await b.fire('bChg');ok(/8 caract|différent/.test(b.$('m2').textContent),'mot de passe de départ réutilisé refusé');
b.$('np').value='Solide2026!';b.$('np2').value='Solide2026!';await b.fire('bChg');
ok(!b.$('vApp').hidden&&b.$('vChg').hidden,'mot de passe changé → portail affiché');
let h=b.$('vApp').innerHTML;
ok(/Jean Kasongo/.test(h)&&/123-456-789/.test(h)&&/TFL-2026-0001/.test(h)&&/Accepté/.test(h),'nom, matricule, dossier, statut affichés');
ok(/40 %/.test(h)&&/étape 6 sur 9/.test(h)&&(h.match(/class="cour"/g)||[]).length===1&&(h.match(/class="fait"/g)||[]).length===5,'avancement : 40 %, étape 6, 5 étapes faites, 1 en cours');
ok(/Pr Ilunga/.test(h),'encadreur affiché');
ok(!/<script>x/.test(h)&&!/<b>HAP/.test(h)&&/&lt;script&gt;/.test(h)&&/&lt;b&gt;HAP/.test(h),'contenu du serveur échappé (aucun HTML injecté)');
ok(/Bienvenue/.test(h)&&/Administration/.test(h),'message de l’administration visible');
b.$('txt').value='Bonjour, puis-je déposer le chapitre 1 ?';await b.clic('msg');
ok(/Envoyé/.test(b.$('m3').textContent)&&/déposer le chapitre 1/.test(b.$('vApp').innerHTML)&&/Vous ·/.test(b.$('vApp').innerHTML),'message envoyé puis visible dans le fil après actualisation');
b.$('txt').value=' ';await b.clic('msg');ok(/Écrivez/.test(b.$('m3').textContent),'message vide refusé par le serveur, message clair');
await b.clic('quit');ok(!b.$('vLogin').hidden&&b.$('vApp').hidden&&b.$('pw').value==='','déconnexion : retour à la connexion, mot de passe effacé');
b.$('idf').value='123-456-789';b.$('pw').value='Solide2026!';await b.fire('bLogin');ok(!b.$('vApp').hidden,'reconnexion avec le nouveau mot de passe');
b.$('idf').value='123-456-789';await b.clic('quit');b.$('idf').value='123-456-789';b.$('pw').value='482913';await b.fire('bLogin');ok(/incorrect/.test(b.$('m1').textContent),'l’ancien mot de passe de départ ne fonctionne plus');
console.log('# Blocage après essais');
srv=serveur();srv.add('etudiant','111-111-111','Test','123456',etuContenu);b=navigateur('etudiant',srv);
for(let i=0;i<5;i++){b.$('idf').value='111-111-111';b.$('pw').value='mauvais'+i;await b.fire('bLogin')}
ok(/Trop d’essais.*15 minute/.test(b.$('m1').textContent),'5 mots de passe faux → blocage 15 minutes annoncé');
b.$('idf').value='111-111-111';b.$('pw').value='123456';await b.fire('bLogin');ok(/Trop d’essais/.test(b.$('m1').textContent),'même le bon mot de passe est refusé pendant le blocage');
srv.now+=16*60000;b.$('idf').value='111-111-111';b.$('pw').value='123456';await b.fire('bLogin');ok(!b.$('vChg').hidden,'après 16 minutes : connexion possible');
console.log('# Accès désactivé et service');
srv=serveur();srv.add('etudiant','222-222-222','Rév','123456',etuContenu);srv.acces[0].actif=false;b=navigateur('etudiant',srv);
b.$('idf').value='222-222-222';b.$('pw').value='123456';await b.fire('bLogin');ok(/désactivé/.test(b.$('m1').textContent),'accès révoqué : message clair');
b=navigateur('etudiant',{fetch:async()=>{throw new Error('offline')}});b.$('idf').value='a';b.$('pw').value='b';await b.fire('bLogin');ok(/Service indisponible/.test(b.$('m1').textContent)&&!b.$('bLogin').disabled,'hors connexion : message clair, bouton de nouveau actif');
b=navigateur('etudiant',{fetch:async()=>({ok:false,status:404,json:async()=>({})})});b.$('idf').value='a';b.$('pw').value='b';await b.fire('bLogin');ok(/Service indisponible/.test(b.$('m1').textContent),'SQL non exécuté (404) : message clair');
srv=serveur();srv.add('encadreur','ENC-1234','Pr','777111',encContenu);b=navigateur('etudiant',srv);b.$('idf').value='ENC-1234';b.$('pw').value='777111';await b.fire('bLogin');ok(/incorrect/.test(b.$('m1').textContent),'un code encadreur ne s’ouvre pas dans le portail étudiant');

console.log('# Portail encadreur');
srv=serveur();srv.add('encadreur','ENC-1234','Pr Ilunga','777111',encContenu);srv.add('etudiant','123-456-789','Jean','482913',etuContenu);b=navigateur('encadreur',srv);
ok(b.doc.title.includes('encadreur')&&/Matricule encadreur/.test(b.$('lId').textContent),'titre et champ « Matricule encadreur » (identifiant = matricule)');
b.$('idf').value='enc-1234';b.$('pw').value='777111';await b.fire('bLogin');ok(!b.$('vChg').hidden,'code saisi en minuscules accepté → changement de mot de passe');
b.$('np').value='Encadreur2026';b.$('np2').value='Encadreur2026';await b.fire('bChg');h=b.$('vApp').innerHTML;
ok(!b.$('vApp').hidden&&/1 dossier affecté/.test(h)&&/Jean Kasongo/.test(h)&&/Béton HAP/.test(h)&&/wa\.me\/243812345678/.test(h),'liste des étudiants affectés + lien WhatsApp (0 → +243)');
ok(/Problématique/.test(h)&&/id="t0"/.test(h)&&/id="p0"/.test(h),'détails du sujet, zone de commentaire et de progression');
b.$('t0').value='Reprenez la revue de littérature.';await b.clic('com',0);ok(/Envoyé/.test(b.$('m4_0').textContent)&&/Commentaire : Reprenez/.test(b.$('vApp').innerHTML),'commentaire envoyé et visible');
b.$('p0').value='55';b.$('t0').value='';await b.clic('prog',0);ok(/Progression proposée : 55 %/.test(b.$('vApp').innerHTML),'progression proposée (55 %) enregistrée comme proposition');
b.$('p0').value='140';await b.clic('prog',0);ok(/entre 0 et 100/.test(b.$('m4_0').textContent),'progression > 100 refusée');
b.$('t0').value='Question pour l’administration';await b.clic('adm',0);ok(srv.msgs.filter(m=>m.de==='encadreur').length===3,'message à l’administration enregistré (3 envois valides au total)');
ok(srv.msgs.every(m=>m.dossier==='TFL-2026-0001'),'tous les envois rattachés au dossier de l’encadreur');
console.log('# Droits : écriture hors périmètre');
const r1=await(await srv.fetch('https://x/rest/v1/rpc/tfl_portail_envoyer',{body:JSON.stringify({p_role:'encadreur',p_ident:'ENC-1234',p_mdp:'Encadreur2026',p_dossier:'TFL-2026-0099',p_type:'commentaire',p_texte:'intrus'})})).json();
ok(r1.ok===false&&r1.code==='dossier','l’encadreur ne peut pas écrire sur un dossier qui n’est pas le sien');
const r2=await(await srv.fetch('https://x/rest/v1/rpc/tfl_portail_envoyer',{body:JSON.stringify({p_role:'etudiant',p_ident:'123-456-789',p_mdp:'482913',p_dossier:'TFL-2026-0001',p_type:'message',p_texte:'avant changement'})})).json();
ok(r2.ok===false&&r2.code==='changer','pas d’envoi tant que le mot de passe de départ n’est pas changé');

console.log('# Circuit complet : administration ↔ serveur ↔ portails');
{
  const srv2=serveur();
  const MEM={};const exbSb={isIn:()=>true,api:async(p,o)=>{const r=await srv2.fetch('https://x'+p,o);const j=await r.json();if(!r.ok)throw new Error(j.message||('HTTP '+r.status));return j}};
  const ctx={EXBTFL_MEM:MEM,console,exbSb,document:{readyState:'complete',getElementById:()=>null,querySelector:()=>null,addEventListener(){}},setTimeout:()=>0,clearTimeout(){},location:{protocol:'https:',origin:'https://logiciel.example',pathname:'/index.html'},confirm:()=>true,open(){},navigator:{}};
  ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8'),ctx);
  const T=ctx.EXBTFL,U=T.ui,P=T.portail;
  const f=(o)=>({form:'EXB_TFL',version:1,submitted_at:'2026-10-17T10:00:00.000Z',ref:'',photo:'',d:Object.assign({nom:'Jean Kasongo',telephone:'0812345678',email:'j@x.cd',universite:'UNIKIN',promotion:'L3',filiere:'GC',matricule_existant:'',domaine:'genie_civil',sujet_titre:'Béton HAP',problematique:'Comment ?',objectifs:'Étudier',methodologie:'',recherches_deja:''},o||{})});
  T.importer(f());let dos=T.dossiers()[0];T.setStatut(dos.id,'accepte');
  const enc=T.ajouterEncadreur({nom:'Pr Ilunga',telephone:'0991234567',max_etudiants:3});T.affecter(dos.id,enc.id);T.patchDossier(dos.id,{progression:30,etape:6});
  const mat=T.etudiants()[0].matricule,numero=dos.numero;
  ok(U.lienPortail('etudiant')==='https://logiciel.example/tfl-portail.html?role=etudiant','lien étudiant construit depuis l’adresse du logiciel');
  await U.publierPortails();
  ok(srv2.acces.length===2&&/2 accès publié/.test(U.state.pt.msg)&&!U.state.pt.err,'publication : 2 accès créés sur le serveur (étudiant + encadreur)');
  let codes=MEM['exb_tfl_codes']||{};const cleE='etudiant:'+P.normId(mat),encId=T.encadreurs()[0].portail_id,cleC='encadreur:'+P.normId(encId);
  ok(/^\d{6}$/.test(codes[cleE])&&/^\d{6}$/.test(codes[cleC]),'mots de passe de départ générés et gardés sur l’appareil');
  ok(!JSON.stringify(srv2.acces).includes(codes[cleE])&&!JSON.stringify(srv2.acces).includes('"'+codes[cleE]+'"'),'le serveur ne reçoit que le code haché (aucun mot de passe en clair dans les données)');
  const codeE=codes[cleE],codeC=codes[cleC];
  /* étudiant */
  let be=navigateur('etudiant',srv2);be.$('idf').value=mat;be.$('pw').value=codeE;await be.fire('bLogin');
  ok(!be.$('vChg').hidden,'l’étudiant se connecte avec son matricule et le mot de passe de départ → doit le changer');
  be.$('np').value='MonMotDePasse1';be.$('np2').value='MonMotDePasse1';await be.fire('bChg');
  ok(/Jean Kasongo/.test(be.$('vApp').innerHTML)&&/30 %/.test(be.$('vApp').innerHTML)&&/Pr Ilunga/.test(be.$('vApp').innerHTML),'portail étudiant : son dossier, 30 %, son encadreur');
  be.$('txt').value='Bonjour, ma question sur le chapitre 2.';await be.clic('msg');
  /* encadreur */
  let bc=navigateur('encadreur',srv2);bc.$('idf').value=encId;bc.$('pw').value=codeC;await bc.fire('bLogin');bc.$('np').value='EncadreurSolide1';bc.$('np2').value='EncadreurSolide1';await bc.fire('bChg');
  ok(/Jean Kasongo/.test(bc.$('vApp').innerHTML)&&/1 dossier affecté/.test(bc.$('vApp').innerHTML),'portail encadreur : son étudiant affecté');
  bc.$('p0').value='60';bc.$('t0').value='Chapitre 2 rédigé';await bc.clic('prog',0);
  bc.$('t0').value='Ajoutez des références';await bc.clic('com',0);
  /* retours */
  await U.recupererRetours();
  let ml=P.messages().filter(m=>m.de!=='admin');
  ok(ml.length===3&&ml.some(m=>m.de==='etudiant'&&/chapitre 2/.test(m.texte))&&ml.some(m=>m.type==='progression'&&m.valeur===60)&&ml.some(m=>m.type==='commentaire'),'messages reçus : question de l’étudiant, progression et commentaire de l’encadreur');
  ok(P.nonLus()===3&&/3 message/.test(U.state.pt.msg),'3 non lus, compte rendu affiché');
  ok(srv2.msgs.every(m=>m.traite),'tous marqués « traités » sur le serveur');
  await U.recupererRetours();ok(/Aucun nouveau/.test(U.state.pt.msg)&&P.messages().filter(m=>m.de!=='admin').length===3,'2e récupération : rien de nouveau, aucun doublon');
  ok(T.dossiers()[0].progression===30,'progression inchangée tant que l’administration n’a pas décidé');
  P.appliquerProgression(ml.filter(m=>m.type==='progression')[0].id);P.messageAdmin(numero,'etudiant','Bien reçu, continuez.');
  await U.publierPortails();
  ok(/0 nouveau|accès publié/.test(U.state.pt.msg)&&Object.keys(MEM['exb_tfl_codes']).length===2&&MEM['exb_tfl_codes'][cleE]===codeE,'republication : aucun mot de passe de départ régénéré');
  await be.clic('maj');
  ok(/60 %/.test(be.$('vApp').innerHTML)&&/Bien reçu, continuez/.test(be.$('vApp').innerHTML),'après republication et « Actualiser » : 60 % et réponse de l’administration visibles — avec le mot de passe choisi par l’étudiant');
  be=navigateur('etudiant',srv2);be.$('idf').value=mat;be.$('pw').value='MonMotDePasse1';await be.fire('bLogin');ok(!be.$('vApp').hidden&&be.$('vChg').hidden,'le mot de passe choisi par l’étudiant survit à la republication');
  /* nouveau mot de passe de départ */
  await U.publierPortails({reset:cleE});const code2=MEM['exb_tfl_codes'][cleE];
  ok(code2!==codeE&&/^\d{6}$/.test(code2),'« Nouveau mot de passe » : nouveau code de départ');
  be=navigateur('etudiant',srv2);be.$('idf').value=mat;be.$('pw').value='MonMotDePasse1';await be.fire('bLogin');ok(/incorrect/.test(be.$('m1').textContent),'l’ancien mot de passe ne marche plus après réinitialisation');
  be.$('idf').value=mat;be.$('pw').value=code2;await be.fire('bLogin');ok(!be.$('vChg').hidden,'le nouveau code de départ ouvre, avec changement obligatoire');
  /* matricule modifié */
  T.fixerMatricule(T.etudiants()[0].id,'TFL-0042');await U.publierPortails();
  ok(srv2.acces.filter(a=>a.role==='etudiant'&&a.actif).length===1&&srv2.acces.some(a=>a.identifiant==='TFL0042'&&a.actif)&&srv2.acces.some(a=>a.identifiant===P.normId(mat)&&!a.actif),'matricule modifié : l’ancien accès est désactivé, le nouveau est créé');
  /* révocation */
  await U.recupererRetours();await U.revoquerAcces('encadreur:'+P.normId(encId));
  bc=navigateur('encadreur',srv2);bc.$('idf').value=encId;bc.$('pw').value='EncadreurSolide1';await bc.fire('bLogin');ok(/désactivé/.test(bc.$('m1').textContent),'accès révoqué par l’administration : connexion refusée, message clair');
  ok(!/Pr Ilunga.*<script/.test(U.vuePortails())&&/Accès ouverts/.test(U.vuePortails())&&/Nouveau mot de passe/.test(U.vuePortails()),'écran « Portails » : liste des accès et actions');
  ok(/Messages des portails/.test(U.blocMessages(T.dossiers()[0]))&&/Appliquer|appliquée/.test(U.blocMessages(T.dossiers()[0])),'fiche dossier : messages des portails et proposition de progression');
}
console.log(fails?'\n'+fails+' ÉCHEC(S)':'\nTout est OK');process.exit(fails?1:0);
})();
