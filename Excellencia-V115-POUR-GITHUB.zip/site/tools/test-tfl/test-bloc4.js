/* Test bloc 4 : messagerie directe étudiant ↔ encadreur : node tools/test-tfl/test-bloc4.js
 * Navigateur et serveur SIMULÉS : le faux serveur reproduit les règles de supabase/migration-tfl-bloc4-messagerie.sql. */
const fs=require('fs'),path=require('path'),vm=require('vm');
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
const html=fs.readFileSync(path.join(__dirname,'../../tfl-portail.html'),'utf8');
const scripts=[...html.matchAll(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const PDF=n=>{const b=Buffer.alloc(n,7);Buffer.from('%PDF-1.4\n').copy(b);return b};


/* ---------- faux serveur (règles de migration-tfl-bloc4-messagerie.sql) ---------- */
function serveur(){
  const S={acces:[],msgs:[],n:0,t:0,calls:[],off:false};
  const find=(role,ident,mdp)=>S.acces.find(a=>a.role===role&&a.ident===ident&&a.mdp===mdp);
  const bad=(code)=>({ok:false,code});
  const stamp=()=>new Date(Date.UTC(2026,9,29,8,0,++S.t)).toISOString();
  const encDe=(num)=>S.acces.find(e=>e.role==='encadreur'&&e.actif!==false&&(e.contenu.dossiers||[]).some(x=>x.numero===num));
  const fn={
    tfl_portail_connexion(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return{ok:false,code:'code',minutes:0};return{ok:true,changer:false,nom:a.nom,publie_le:'2026-10-29T08:00:00Z',contenu:a.contenu,messages:[]}},
    tfl_echange_envoyer(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');
      let d=String(b.p_dossier||'').trim().slice(0,40),t=String(b.p_texte||'').trim().slice(0,2000),enc;
      if(!t)return bad('vide');
      if(a.role==='etudiant'){d=d||a.contenu.numero;if(d!==a.contenu.numero||a.contenu.statut!=='accepte')return bad('dossier');
        if(!(a.contenu.encadreur&&a.contenu.encadreur.nom))return bad('sans_encadreur');enc=encDe(d);if(!enc)return bad('sans_encadreur')}
      else{if(!(a.contenu.dossiers||[]).some(x=>x.numero===d))return bad('dossier');enc=a}
      if(S.msgs.filter(m=>m.auteur===a.id&&m.t>S.t-60).length>=60)return bad('trop');
      if(S.msgs.filter(m=>m.dossier===d&&m.enc===enc.id).length>=1000)return bad('limite');
      const m={id:'m'+(++S.n),dossier:d,enc:enc.id,auteur:a.id,de:a.role,texte:t,cree_le:stamp(),lu_le:null,t:S.t};S.msgs.push(m);return{ok:true,id:m.id}},
    tfl_echange_liste(b){const a=find(b.p_role,b.p_ident,b.p_mdp);if(!a)return bad('code');
      const d=String(b.p_dossier||'').trim(),num=a.contenu.numero||'';let msgs=null,mine;
      const js=m=>({id:m.id,de:m.de,texte:m.texte,cree_le:m.cree_le,lu:m.lu_le!==null,mien:m.auteur===a.id});
      if(d){
        if(a.role==='etudiant'){if(d!==num)return bad('introuvable');mine=S.msgs.filter(m=>m.dossier===num);mine.filter(m=>m.de==='encadreur'&&!m.lu_le).forEach(m=>m.lu_le=stamp())}
        else{if(!(a.contenu.dossiers||[]).some(x=>x.numero===d))return bad('introuvable');mine=S.msgs.filter(m=>m.enc===a.id&&m.dossier===d);mine.filter(m=>m.de==='etudiant'&&!m.lu_le).forEach(m=>m.lu_le=stamp())}
        msgs=mine.slice(-300).map(js)}
      const nl={};S.msgs.filter(m=>!m.lu_le&&(a.role==='etudiant'?(m.dossier===num&&m.de==='encadreur'):(m.enc===a.id&&m.de==='etudiant'))).forEach(m=>{nl[m.dossier]=(nl[m.dossier]||0)+1});
      return{ok:true,non_lus:nl,messages:msgs}}
  };
  S.fetch=async(url,o)=>{const m=/\/rpc\/(\w+)$/.exec(url);S.calls.push(m&&m[1]);if(!m||!fn[m[1]]||(S.off&&/echange/.test(m[1])))return{ok:false,status:404,json:async()=>({})};return{ok:true,status:200,json:async()=>fn[m[1]](JSON.parse(o.body))}};
  S.fn=fn;return S;
}

function navigateur(srv,role){
  const els={},downloads=[];const ids=new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m=>m[1]));
  const mk=id=>{const e={id,value:'',textContent:'',className:'',disabled:false,files:null,hidden:/\shidden[\s>]/.test((html.match(new RegExp('<[^>]*id="'+id+'"[^>]*>'))||[''])[0]),_h:'',_l:{},style:{},addEventListener(t,f){(e._l[t]=e._l[t]||[]).push(f)},focus(){},getAttribute(){return null}};
    Object.defineProperty(e,'innerHTML',{get(){return e._h},set(v){e._h=v}});return e};
  const doc={title:'',body:{className:'',appendChild(){},removeChild(){}},getElementById(id){if(els[id])return els[id];const dyn=Object.values(els).some(x=>x._h&&x._h.indexOf('id="'+id+'"')>=0);if(ids.has(id)||dyn)return els[id]=mk(id);return null},addEventListener(){},hidden:false,
    createElement(){const a={click(){downloads.push({href:a.href,download:a.download})}};return a}};
  const lastBlob={};
  const cx={document:doc,location:{search:'?role='+role},window:{EXB_SUPABASE:{url:'https://x.supabase.co',key:'sb_publishable_k'}},fetch:srv.fetch,setTimeout:()=>0,clearTimeout(){},console,Date,Math,isFinite,parseInt,String,JSON,Promise,Uint8Array,
    atob:s=>Buffer.from(s,'base64').toString('binary'),confirm:()=>true,
    Blob:class{constructor(p,o){this.parts=p;this.type=o&&o.type}},URL:{createObjectURL(b){lastBlob.b=b;return 'blob:x'},revokeObjectURL(){}},
    FileReader:class{readAsDataURL(bl){setImmediate(()=>{this.result='data:application/octet-stream;base64,'+Buffer.from(bl.buf).toString('base64');this.onload()})}}};
  cx.window.document=doc;vm.createContext(cx);vm.runInContext(scripts[scripts.length-1],cx);
  const $=id=>doc.getElementById(id),tick=()=>new Promise(r=>setImmediate(r));
  const fire=async id=>{for(const f of ($(id)._l.click||[]))await f({});await tick();await tick()};
  const clic=async(act,at)=>{at=at||{};const b={disabled:false,getAttribute:k=>({'data-act':act,'data-i':at.i==null?null:String(at.i),'data-id':at.id||null,'data-z':at.z||null,'data-p':at.p||null})[k]};const ev={target:{closest:()=>b}};
    for(const f of ($('vApp')._l.click||[]))await f(ev);await tick();await tick()};
  const login=async(ident,mdp)=>{$('idf').value=ident;$('pw').value=mdp;await fire('bLogin')};
  const fichier=(name,buf)=>({name,size:buf.length,type:'',slice:(a,b)=>({buf:buf.subarray(a,b)})});
  return{$,fire,clic,login,fichier,downloads,lastBlob};
}
const etu=(over)=>Object.assign({nom:'Jean Kasongo',matricule:'123-456-789',numero:'TFL-2026-0001',domaine:'Génie civil',statut:'accepte',statut_label:'Accepté',etape:6,progression:40,sujet_titre:'Dalle',encadreur:{nom:'Pr Ilunga',telephone:'0991234567'},historique:[],messages_admin:[],mes_propositions:[],plan:''},over||{});
const enc=(nums)=>({nom:'Pr Ilunga',max_etudiants:3,dossiers:nums.map(n=>({numero:n,etudiant:'Jean Kasongo',matricule:'123-456-789',telephone:'0812345678',universite:'UNIKIN',domaine:'Génie civil',sujet_titre:'Dalle',problematique:'P?',objectifs:'O?',methodologie:'M?',etape:6,etape_label:'Recherche',progression:40})),messages_admin:[]});

const setup=()=>{const s=serveur();s.acces.push({id:'A1',role:'etudiant',ident:'123-456-789',mdp:'Solide2026!',nom:'Jean',contenu:etu()},
  {id:'A2',role:'etudiant',ident:'222-222-222',mdp:'Solide2026!',nom:'Marie',contenu:etu({nom:'Marie',numero:'TFL-2026-0002',encadreur:null})},
  {id:'E1',role:'encadreur',ident:'ENC-1',mdp:'Solide2026!',nom:'Pr Ilunga',contenu:enc(['TFL-2026-0001'])},
  {id:'E2',role:'encadreur',ident:'ENC-2',mdp:'Solide2026!',nom:'Dr Autre',contenu:enc(['TFL-2026-0002'])});return s};
const PW='Solide2026!';
(async()=>{
console.log('# Étudiant : ouverture de la messagerie');
let srv=setup(),b=navigateur(srv,'etudiant');await b.login('123-456-789',PW);
let h=b.$('vApp').innerHTML;
ok(/Échanges encadreur/.test(h)&&/Écrire à mon encadreur/.test(h),'menu « Échanges encadreur » et accès rapide sur le tableau de bord');
ok(!/class="nb">\d/.test(h.split('Échanges encadreur')[1].slice(0,60)),'aucune pastille tant qu’il n’y a rien à lire');
await b.clic('go',{p:'chat'});h=b.$('vApp').innerHTML;
ok(srv.calls.includes('tfl_echange_liste')&&/Conversation privée avec <b>Pr Ilunga/.test(h)&&/Aucun message pour le moment/.test(h)&&/id="chm0"/.test(h),'page de discussion : encadreur nommé, fil vide, zone de saisie');
ok(/consulter en cas de litige/.test(h),'l’étudiant est averti que l’administration peut consulter le fil');
console.log('# Étudiant : envoi');
await b.clic('chsend',{i:0});ok(/Écrivez votre message/.test(b.$('chz0').textContent)&&!srv.calls.includes('tfl_echange_envoyer'),'message vide refusé sans appel serveur');
b.$('chm0').value='Bonjour Professeur, puis-je vous montrer mon plan ?';await b.clic('chsend',{i:0});
ok(srv.msgs.length===1&&srv.msgs[0].de==='etudiant'&&srv.msgs[0].enc==='E1'&&srv.msgs[0].dossier==='TFL-2026-0001','message enregistré, rattaché à l’encadreur du dossier');
h=b.$('vApp').innerHTML;ok(/Bonjour Professeur/.test(h)&&/bulle moi/.test(h)&&/Message envoyé/.test(b.$('chz0').textContent),'le message apparaît dans le fil (bulle « Vous »)');
b.$('chm0').value='<img src=x onerror=alert(1)>';await b.clic('chsend',{i:0});h=b.$('vApp').innerHTML;
ok(!/<img src=x/.test(h)&&/&lt;img src=x/.test(h),'le HTML saisi est neutralisé à l’affichage');
console.log('# Encadreur : lecture et réponse');
let be=navigateur(srv,'encadreur');await be.login('ENC-1',PW);h=be.$('vApp').innerHTML;
ok(/Messages non lus/.test(h)&&/class="nb">2</.test(h),'pastille « 2 » sur le menu Messages, compteur sur le tableau de bord');
await be.clic('go',{p:'chat'});h=be.$('vApp').innerHTML;
ok(/Bonjour Professeur/.test(h)&&/id="chm0"/.test(h),'un seul étudiant : conversation ouverte directement');
ok(srv.msgs.every(m=>m.lu_le),'messages marqués lus à l’ouverture');
ok(!/class="nb">2</.test(h),'la pastille disparaît après lecture');
be.$('chm0').value='Bonsoir Jean, envoyez-le moi demain.';await be.clic('chsend',{i:0});
ok(srv.msgs.length===3&&srv.msgs[2].de==='encadreur'&&srv.msgs[2].enc==='E1','réponse de l’encadreur enregistrée');
console.log('# Retour à l’étudiant');
await b.clic('maj');h=b.$('vApp').innerHTML;
ok(/class="nb">1</.test(h.split('Échanges encadreur')[1].slice(0,60)),'pastille « 1 » sur le menu de l’étudiant');
await b.clic('go',{p:'chat'});h=b.$('vApp').innerHTML;
ok(/Bonsoir Jean/.test(h)&&/✓ lu/.test(h),'l’étudiant lit la réponse ; ses messages affichent « ✓ lu »');
console.log('# Actualisation sans perdre le brouillon');
b.$('chm0').value='brouillon en cours';
srv.fn.tfl_echange_envoyer({p_role:'encadreur',p_ident:'ENC-1',p_mdp:PW,p_dossier:'TFL-2026-0001',p_texte:'Autre point : pensez aux références.'});
await b.clic('chmaj',{i:0});
ok(/pensez aux références/.test(b.$('chfil')._h)&&b.$('chm0').value==='brouillon en cours','« Actualiser » ajoute le nouveau message sans effacer la saisie');
console.log('# Confidentialité');
ok(srv.fn.tfl_echange_liste({p_role:'encadreur',p_ident:'ENC-2',p_mdp:PW,p_dossier:'TFL-2026-0001'}).code==='introuvable','un autre encadreur ne peut pas ouvrir ce fil');
ok(srv.fn.tfl_echange_envoyer({p_role:'encadreur',p_ident:'ENC-2',p_mdp:PW,p_dossier:'TFL-2026-0001',p_texte:'intrus'}).code==='dossier','un autre encadreur ne peut pas y écrire');
ok(srv.fn.tfl_echange_liste({p_role:'etudiant',p_ident:'222-222-222',p_mdp:PW,p_dossier:'TFL-2026-0001'}).code==='introuvable','un autre étudiant ne peut pas ouvrir ce fil');
ok(srv.fn.tfl_echange_envoyer({p_role:'etudiant',p_ident:'222-222-222',p_mdp:PW,p_dossier:'',p_texte:'Bonjour'}).code==='sans_encadreur','étudiant sans encadreur : envoi refusé par le serveur');
ok(srv.fn.tfl_echange_liste({p_role:'encadreur',p_ident:'ENC-2',p_mdp:PW}).non_lus['TFL-2026-0001']===undefined,'les compteurs d’un autre encadreur ne mentionnent pas ce dossier');
ok(srv.fn.tfl_echange_liste({p_role:'etudiant',p_ident:'123-456-789',p_mdp:'faux'}).code==='code','mauvais mot de passe refusé');
let b2=navigateur(srv,'etudiant');await b2.login('222-222-222',PW);await b2.clic('go',{p:'chat'});h=b2.$('vApp').innerHTML;
ok(/Aucun encadreur ne vous est affecté/.test(h)&&!/id="chm0"/.test(h),'étudiant sans encadreur : message explicatif, pas de zone de saisie');
console.log('# Changement d’encadreur');
srv.acces[2].contenu.dossiers=[];srv.acces[3].contenu.dossiers=enc(['TFL-2026-0001','TFL-2026-0002']).dossiers;srv.acces[0].contenu.encadreur={nom:'Dr Autre',telephone:''};
ok(srv.fn.tfl_echange_liste({p_role:'encadreur',p_ident:'ENC-2',p_mdp:PW,p_dossier:'TFL-2026-0001'}).messages.length===0,'le nouvel encadreur ne voit pas l’historique de son prédécesseur');
ok(srv.fn.tfl_echange_liste({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'TFL-2026-0001'}).messages.length===4,'l’étudiant garde tout son fil');
ok(srv.fn.tfl_echange_envoyer({p_role:'encadreur',p_ident:'ENC-1',p_mdp:PW,p_dossier:'TFL-2026-0001',p_texte:'je ne suis plus l’encadreur'}).code==='dossier','l’ancien encadreur ne peut plus écrire');
srv.fn.tfl_echange_envoyer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'',p_texte:'Bonjour Docteur'});
ok(srv.msgs[srv.msgs.length-1].enc==='E2','le nouveau message de l’étudiant va au nouvel encadreur');
console.log('# Limite horaire');
const s3=setup();let okN=0;for(let i=0;i<70;i++){if(s3.fn.tfl_echange_envoyer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'',p_texte:'m'+i}).ok)okN++}
ok(okN===60&&s3.fn.tfl_echange_envoyer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'',p_texte:'x'}).code==='trop','60 messages par heure au plus, ensuite « trop »');
console.log('# Dossier clos / service absent');
srv.acces[0].contenu.statut='clos';await b.clic('maj');await b.clic('go',{p:'chat'});h=b.$('vApp').innerHTML;
ok(/en lecture seule/.test(h)&&!/id="chm0"/.test(h)&&/Bonsoir Jean/.test(h),'dossier clos : fil visible en lecture seule, plus de saisie');
ok(srv.fn.tfl_echange_envoyer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'',p_texte:'Bonjour'}).code==='dossier','le serveur refuse aussi l’envoi');
srv.off=true;await b.clic('maj');await b.clic('go',{p:'chat'});h=b.$('vApp').innerHTML;
ok(/pas encore activée/.test(h)&&/Mon encadreur/.test(h),'service non activé : message clair, le portail reste utilisable');
console.log('# Encadreur avec plusieurs étudiants');
const s4=setup();s4.acces[2].contenu=enc(['TFL-2026-0001','TFL-2026-0009']);s4.acces[2].contenu.dossiers[1].etudiant='Paul Mbuyi';
s4.fn.tfl_echange_envoyer({p_role:'etudiant',p_ident:'123-456-789',p_mdp:PW,p_dossier:'',p_texte:'Question de Jean'});
let be2=navigateur(s4,'encadreur');await be2.login('ENC-1',PW);await be2.clic('go',{p:'chat'});h=be2.$('vApp').innerHTML;
ok(/Touchez un étudiant pour ouvrir/.test(h)&&/data-act="chsel" data-i="0"/.test(h)&&/class="nb">1</.test(h),'plusieurs étudiants : liste avec compteurs, aucune conversation ouverte');
await be2.clic('chsel',{i:0});h=be2.$('vApp').innerHTML;ok(/Question de Jean/.test(h)&&/id="chm0"/.test(h),'choix d’un étudiant : son fil s’ouvre');
await be2.clic('chsel',{i:1});h=be2.$('vApp').innerHTML;ok(/Paul Mbuyi/.test(h)&&/Aucun message pour le moment/.test(h)&&!/Question de Jean/.test(h)&&/id="chm1"/.test(h),'autre étudiant : fil séparé');
be2.$('chm1').value='Bonjour Paul';await be2.clic('chsend',{i:1});ok(s4.msgs[s4.msgs.length-1].dossier==='TFL-2026-0009','le message part vers le bon dossier');
console.log('# Administration');
const T=(()=>{const src=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');const ctx={EXBTFL_MEM:{},console,clearTimeout,setTimeout,atob:s=>Buffer.from(s,'base64').toString('binary')};ctx.window=undefined;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);return ctx.EXBTFL})();
const srcAdm=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');
ok(/data-tfl="echCharger"/.test(srcAdm)&&/data-tfl="echSupp"/.test(srcAdm)&&/blocDocuments\(d\)\s*\n\s*\+ blocEchanges\(d\)/.test(srcAdm)&&/ec: \{ num: ''/.test(srcAdm),'fiche dossier : bouton « Charger les échanges du serveur » et suppression d’un message');
ok(/tfl_echanges_admin_liste/.test(srcAdm)&&/tfl_echange_admin_supprimer/.test(srcAdm)&&/a === 'echCharger'/.test(srcAdm)&&/a === 'echSupp'/.test(srcAdm),'boutons administrateur branchés sur les fonctions SQL');
ok(/migration-tfl-bloc4-messagerie\.sql/.test(T.portail.erreurEchanges(new Error('Could not find the function public.tfl_echanges_admin_liste'))),'service absent : l’administration est renvoyée vers le bon script SQL');
console.log(fails?'\n'+fails+' ÉCHEC(S)':'\nTout est OK');process.exit(fails?1:0);
})();
