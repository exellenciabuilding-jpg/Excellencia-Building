/* Test du module TFL local : node tools/test-tfl/test.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const src=fs.readFileSync(path.join(__dirname,'../../exb-tfl.js'),'utf8');
let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
function boot(extra){const ctx={EXBTFL_MEM:{},console};ctx.window=undefined;Object.assign(ctx,extra||{});ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);return ctx}
const form=(o)=>Object.assign({form:'EXB_TFL',version:1,submitted_at:'2026-10-17T10:00:00.000Z',ref:'REF-AB12',photo:'',d:{nom:'Jean Kasongo',telephone:'0812345678',email:'Jean@Mail.com',universite:'UNIKIN',promotion:'L3',filiere:'Génie civil',domaine:'genie_civil',sujet_titre:'Étude d’un R+3',problematique:'P',objectifs:'O',methodologie:'M',recherches_deja:'R',matricule_existant:'999-999-999'}},o||{});
let c=boot(),T=c.EXBTFL;
console.log('# Import');
let r=T.importer(form());
ok(!r.dup&&/^TFL-\d{4}-0001$/.test(r.numero),'numéro de dossier attribué : '+r.numero);
ok(T.etudiants().length===1&&T.dossiers()[0].statut==='recu','étudiant et dossier créés, statut Reçu');
ok(/^\d{3}-\d{3}-\d{3}$/.test(T.etudiants()[0].matricule),'matricule attribué automatiquement dès l’import');
ok(T.etudiants()[0].matricule_declare==='999-999-999','matricule déclaré par l’étudiant seulement affiché');
ok(T.importer(form()).dup===true,'même fichier importé 2 fois → doublon ignoré');
r=T.importer(form({submitted_at:'2026-10-18T10:00:00.000Z',d:Object.assign(form().d,{nom:'Marie Mbuyi',telephone:'0899999999',email:''})}));
ok(/-0002$/.test(r.numero),'2e dossier = 0002 : '+r.numero);
let bad=0;[{d:{}},{d:{nom:'X',telephone:'1'}},{form:'AUTRE',d:{}},null].forEach(o=>{try{T.importer(o)}catch(e){bad++}});
ok(bad===4,'fichiers invalides refusés (4/4)');
console.log('# Matricule');
const e1=T.etudiants()[0],e2=T.etudiants()[1];
let m1=T.attribuerMatricule(e1.id);ok(/^\d{3}-\d{3}-\d{3}$/.test(m1.matricule),'matricule attribué : '+m1.matricule);
ok(T.attribuerMatricule(e1.id).deja===true&&T.etudiants()[0].matricule===m1.matricule,'ré-attribution = même matricule (pas de second numéro)');
let m2=T.attribuerMatricule(e2.id);ok(m2.matricule!==m1.matricule,'deux étudiants → deux matricules distincts');
let thrown=false;try{T.fixerMatricule(e2.id,m1.matricule)}catch(e){thrown=true}ok(thrown,'matricule déjà pris refusé');
ok(T.fixerMatricule(e2.id,'TFL-0042')==='TFL-0042','matricule saisi à la main accepté');
console.log('# Apprenant déjà inscrit');
c=boot({participants:[{name:'Jean Kasongo',phone:'+243 81 234 5678',matricule:'111-222-333'}]});T=c.EXBTFL;
T.importer(form({d:Object.assign(form().d,{telephone:'081 234 5678'})}));
ok(T.attribuerMatricule(T.etudiants()[0].id).matricule==='111-222-333','même téléphone qu’un apprenant → son matricule est repris');
console.log('# Décision');
c=boot();T=c.EXBTFL;T.importer(form());const d=T.dossiers()[0];
let t=false;try{T.setStatut(d.id,'refuse','')}catch(e){t=true}ok(t,'refus sans motif impossible');
T.setStatut(d.id,'complement_demande','Précisez la problématique');ok(T.dossiers()[0].statut==='complement_demande','complément demandé');
r=T.importer(form({submitted_at:'2026-10-19T08:00:00.000Z',d:Object.assign(form().d,{problematique:'Nouvelle problématique'})}));
ok(r.maj===true&&T.dossiers().length===1&&T.dossiers()[0].statut==='recu'&&T.dossiers()[0].problematique==='Nouvelle problématique','complément renvoyé → même dossier mis à jour (pas de doublon)');
let s=T.setStatut(d.id,'accepte');ok(T.dossiers()[0].statut==='accepte'&&!!T.etudiants()[0].matricule,'acceptation → matricule déjà attribué, conservé');
console.log('# Encadreur');
const en=T.ajouterEncadreur({nom:'Pr Ilunga',max_etudiants:1});T.affecter(d.id,en.id);ok(T.dossiers()[0].encadreur_id===en.id,'affectation après acceptation');
T.importer(form({submitted_at:'x2',d:Object.assign(form().d,{nom:'Paul N',telephone:'0970000000',email:'p@x.cd'})}));
const d2=T.dossiers().filter(x=>x.id!==d.id)[0];t=false;try{T.affecter(d2.id,en.id)}catch(e){t=true}ok(t,'affectation refusée tant que le dossier n’est pas accepté');
T.setStatut(d2.id,'accepte');t=false;try{T.affecter(d2.id,en.id)}catch(e){t=true}ok(t,'charge maximale de l’encadreur respectée');
console.log('# Étapes, spécialités');
ok(T.dossiers().filter(x=>x.id===d.id)[0].etape===5,'étape = 5 après acceptation puis affectation');
const e2b=T.ajouterEncadreur({nom:'Dr Arch',domaines:['architecture','xx'],specialites:'plans'});ok(e2b.domaines.length===1&&e2b.domaines[0]==='architecture','spécialités filtrées sur les domaines connus');
T.basculerEncadreur(e2b.id);T.setStatut(d2.id,'accepte');t=false;try{T.affecter(d2.id,e2b.id)}catch(e){t=true}ok(t,'encadreur indisponible refusé');
console.log('# Envoi en ligne = même dossier que le fichier');
c=boot();T=c.EXBTFL;
T.importer(form({submitted_at:'2026-10-20T09:15:30.000Z'}));
r=T.importer(form({submitted_at:'2026-10-20T09:15:30+00:00'}));
ok(r.dup===true&&T.dossiers().length===1,'même envoi reçu par fichier puis en ligne (date écrite autrement) → un seul dossier');
r=T.importer({form:'EXB_TFL',version:1,submitted_at:'2026-10-21T10:00:00+00:00',ref:'',d:{nom:'Aline Tshala',telephone:'+243 99 111 2222',email:'',universite:'ISTA',promotion:'',filiere:'',matricule_existant:'',domaine:'architecture',sujet_titre:'Habitat bioclimatique',problematique:'P',objectifs:'O',methodologie:'',recherches_deja:''},photo:''});
ok(!r.dup&&/-0002$/.test(r.numero)&&T.dossiers().length===2,'candidature venue du serveur (forme RPC) importée dans le module local');
console.log('# Portails étudiant / encadreur (V99zzt)');
c=boot();T=c.EXBTFL;const P=T.portail;
T.importer(form());const dp=T.dossiers()[0];
ok(P.accesAPublier().acces.length===0,'dossier non accepté : aucun accès à publier');
T.setStatut(dp.id,'accepte');const matp=T.etudiants()[0].matricule;
let pub=P.accesAPublier();
ok(pub.acces.length===1&&pub.acces[0].role==='etudiant'&&pub.acces[0].ident===matp,'dossier accepté avec matricule : un accès étudiant, identifiant = matricule');
T.importer(form({submitted_at:'2026-10-22T10:00:00.000Z',d:Object.assign(form().d,{nom:'Sans Matricule',telephone:'0970001111',email:'sm@x.cd'})}));
const dsm=T.dossiers().filter(x=>x.id!==dp.id)[0];T.setStatut(dsm.id,'clos');
pub=P.accesAPublier();ok(pub.sans_matricule.length===0,'plus aucun étudiant sans matricule (attribué automatiquement)');
T.patchDossier(dp.id,{observation_encadreur:'SECRET-OBS',analyse:{notes:'NOTE-INTERNE'},progression:30,etape:6});
let se=P.snapEtudiant(T.dossiers().filter(x=>x.id===dp.id)[0]),js=JSON.stringify(se);
ok(!/SECRET-OBS|NOTE-INTERNE|Jean@|0812345678/.test(js),'instantané étudiant : ni notes internes, ni observation, ni e-mail/téléphone');
ok(se.numero===dp.numero&&se.matricule===matp&&se.progression===30&&se.etape===6&&se.statut==='accepte'&&se.statut_label==='Accepté','instantané étudiant : numéro, matricule, avancement, statut');
ok(se.encadreur===null,'pas d’encadreur affiché tant qu’aucun n’est affecté');
const enc=T.ajouterEncadreur({nom:'Pr Ilunga',telephone:'0991234567',max_etudiants:3,domaines:['genie_civil']});
T.affecter(dp.id,enc.id);
pub=P.accesAPublier();const ae=pub.acces.filter(a=>a.role==='encadreur')[0];
ok(!!ae&&/^\d{3}-\d{3}-\d{3}$/.test(ae.ident),'encadreur affecté : accès avec son matricule '+(ae&&ae.ident));
ok(P.accesAPublier().acces.filter(a=>a.role==='encadreur')[0].ident===ae.ident,'le code ENC reste le même à chaque publication');
ok(ae.contenu.dossiers.length===1&&ae.contenu.dossiers[0].numero===dp.numero&&ae.contenu.dossiers[0].telephone==='0812345678','instantané encadreur : son étudiant (avec contact)');
ok(ae.contenu.dossiers.every(d=>d.numero!==dsm.numero),'instantané encadreur : aucun dossier qui ne lui est pas affecté');
se=P.snapEtudiant(T.dossiers().filter(x=>x.id===dp.id)[0]);ok(se.encadreur&&se.encadreur.nom==='Pr Ilunga','instantané étudiant : encadreur affiché après affectation');
console.log('  — messages de l’administration');
P.messageAdmin(dp.numero,'etudiant','Pour l’étudiant');P.messageAdmin(dp.numero,'encadreur','Pour l’encadreur');P.messageAdmin(dp.numero,'tous','Pour tous');
let ms=P.snapEtudiant(T.dossiers().filter(x=>x.id===dp.id)[0]).messages_admin.map(m=>m.texte).sort();
ok(ms.length===2&&ms[0]==='Pour l’étudiant'&&ms[1]==='Pour tous','l’étudiant reçoit « étudiant » et « tous » seulement');
ms=P.snapEncadreur(T.encadreurs()[0]).messages_admin.map(m=>m.texte).sort();
ok(ms.length===2&&ms[0]==='Pour l’encadreur'&&ms[1]==='Pour tous','l’encadreur reçoit « encadreur » et « tous » seulement');
t=false;try{P.messageAdmin(dp.numero,'tous',' ')}catch(e){t=true}ok(t,'message vide refusé');
t=false;try{P.messageAdmin('TFL-0000-9999','tous','x y')}catch(e){t=true}ok(t,'message sur un dossier inconnu refusé');
console.log('  — messages reçus des portails');
const rid=n=>'00000000-0000-0000-0000-00000000000'+n;
let rows=[
 {id:rid(1),role:'etudiant',identifiant:matp.replace(/-/g,''),nom:'Jean Kasongo',dossier:dp.numero,type:'message',texte:'Bonjour, où en est mon dossier ?',valeur:null,cree_le:'2026-10-23T08:00:00Z'},
 {id:rid(2),role:'etudiant',identifiant:'999999999',nom:'Intrus',dossier:dp.numero,type:'message',texte:'message d’un autre',valeur:null,cree_le:'2026-10-23T08:01:00Z'},
 {id:rid(3),role:'encadreur',identifiant:ae.ident,nom:'Pr Ilunga',dossier:dp.numero,type:'progression',texte:'chapitre 1 terminé',valeur:250,cree_le:'2026-10-23T08:02:00Z'},
 {id:rid(4),role:'encadreur',identifiant:'ENC-0000',nom:'Autre',dossier:dp.numero,type:'commentaire',texte:'pas mon étudiant',valeur:null,cree_le:'2026-10-23T08:03:00Z'},
 {id:rid(5),role:'etudiant',identifiant:matp,nom:'Jean Kasongo',dossier:dp.numero,type:'progression',texte:'je triche',valeur:100,cree_le:'2026-10-23T08:04:00Z'},
 {id:rid(6),role:'encadreur',identifiant:ae.ident,nom:'Pr Ilunga',dossier:dsm.numero,type:'commentaire',texte:'dossier non affecté',valeur:null,cree_le:'2026-10-23T08:05:00Z'}];
let rr=P.appliquerRetours(rows);
ok(rr.recus===3&&rr.refuses===3&&rr.ids.length===6,'6 messages : 3 reçus, 3 refusés (identifiant ou dossier ne correspondant pas)');
ok(rr.ids.length===6,'tous les identifiants à marquer « traités » côté serveur (même les refusés)');
rr=P.appliquerRetours(rows);ok(rr.recus===0&&rr.dup===3&&P.messages().filter(m=>m.de!=='admin').length===3,'même lot reçu deux fois → les 3 messages déjà reçus ne sont pas recréés');
let loc=P.messages().filter(m=>m.de!=='admin');
ok(loc.length===3&&loc.every(m=>m.lu===false),'3 messages locaux non lus');
const prop=loc.filter(m=>m.type==='progression');
ok(prop.length===1&&prop[0].de==='encadreur'&&prop[0].valeur===100,'progression proposée par l’encadreur : valeur bornée à 100');
ok(loc.filter(m=>m.de==='etudiant'&&m.type==='message').length===2,'« progression » envoyée par un étudiant → simple message, jamais une proposition');
ok(T.dossiers().filter(x=>x.id===dp.id)[0].progression===30,'la progression n’a PAS changé avant la décision de l’administration');
ok(P.nonLus()===3,'3 non lus comptés');P.marquerLus(dp.numero);ok(P.nonLus()===0,'marquer lus à l’ouverture du dossier');
P.appliquerProgression(prop[0].id);
ok(T.dossiers().filter(x=>x.id===dp.id)[0].progression===100,'après « Appliquer » : progression mise à jour');
ok(P.messages().filter(m=>m.id===prop[0].id)[0].appliquee===true,'proposition marquée appliquée');
t=false;try{P.appliquerProgression('inconnu')}catch(e){t=true}ok(t,'proposition inconnue refusée');
console.log('  — identifiants');
ok(P.normId('123-456-789')==='123456789'&&P.normId(' enc-12 34 ')==='ENC1234','identifiant normalisé (tirets, espaces, casse)');
const cd=new Set();for(let i=0;i<200;i++)cd.add(P.genCode());ok([...cd].every(x=>/^\d{6}$/.test(x))&&cd.size>150,'mots de passe de départ : 6 chiffres, variés');
ok(Object.keys(T.K).indexOf('acc')>=0&&T.K.msg==='exb_tfl_messages'&&!/exb_tfl_codes/.test(JSON.stringify(T.K)),'messages et accès dans la sauvegarde ; mots de passe de départ HORS sauvegarde');
(async()=>{
console.log('# Bibliothèque (V99zzu)');
const c2=boot({EXBTFL_FILES:{}});const T2=c2.EXBTFL,B=T2.biblio,F=c2.EXBTFL_FILES;
const fich=(n,t)=>({name:n,size:t===undefined?2048:t,type:'application/octet-stream'});
let r1=await B.ajouter({type:'tfl',titre:'Étude de la dalle',auteur:'Marie Mbuyi',annee:'2023',domaine:'genie_civil',mots_cles:'dalle béton'},fich('tfl-dalle.pdf'));
ok(!r1.dup&&B.liste().length===1&&Object.keys(F).length===1,'TFL résolu importé : fiche + fichier gardé');
ok((await B.ajouter({type:'tfl',titre:'x'},fich('tfl-dalle.pdf'))).dup===true&&B.liste().length===1,'même fichier importé 2 fois → doublon ignoré');
let r2=await B.ajouter({type:'tfl'},fich('Route_Kinshasa_2021.docx'));
ok(r2.entree.titre==='Route Kinshasa 2021','titre repris du nom du fichier');
let bad=0;for(const [o,f] of [[{type:'tfl',titre:'ab'},null],[{type:'zzz',titre:'abc'},null],[{type:'tfl',titre:'Virus'},fich('x.exe')],[{type:'tfl'},fich('vide.pdf',0)],[{type:'tfl'},fich('gros.pdf',26*1024*1024)],[{type:'sujet',titre:'Sujet valide'},null]]){try{await B.ajouter(o,f)}catch(e){bad++}}
ok(bad===6,'refusés : titre trop court, type inconnu, format .exe, fichier vide, > 25 Mo, sujet sans nom (6/6)');
ok(B.liste().length===2,'aucune fiche créée par les refus');
let s1=await B.ajouter({type:'sujet',titre:'Fondations sur sol argileux',auteur:'Paul Ngoy',telephone:'0970000001',universite:'UNIKIN',domaine:'genie_civil'},fich('sujet-paul.pdf'));
ok(s1.entree.statut==='a_etudier'&&s1.entree.type==='sujet','sujet reçu en PDF : statut « à étudier »');
await B.ajouter({type:'sujet',titre:'Plan photo',auteur:'Anne K'},fich('photo-sujet.jpg'));
ok(B.liste().length===4,'sujets reçus en PDF et en photo (autre format)');
B.statut(s1.entree.id,'accepte');ok(B.liste().filter(x=>x.id===s1.entree.id)[0].statut==='accepte','statut du sujet : accepté');
let t=false;try{B.statut(r1.entree.id,'accepte')}catch(e){t=true}ok(t,'le statut ne concerne pas un TFL résolu');
t=false;try{B.statut(s1.entree.id,'nimporte')}catch(e){t=true}ok(t,'statut inconnu refusé');
ok(B.chercher('dalle').length===1&&B.chercher('béton').length===1&&B.chercher('FONDATIONS','sujet').length===1,'recherche : titre, mots-clés, sans accent ni casse');
ok(B.chercher('','tfl').length===2&&B.chercher('','sujet').length===2&&B.chercher('','','architecture').length===0,'filtres par onglet et par domaine');
ok((await B.fichier(r1.entree.id)).name==='tfl-dalle.pdf','fichier retrouvé pour l’ouverture / le téléchargement');
B.modifier(r1.entree.id,{annee:'1800',titre:'Dalle pleine',mots_cles:'dalle'});const m=B.liste().filter(x=>x.id===r1.entree.id)[0];
ok(m.titre==='Dalle pleine'&&m.annee==='',  'fiche modifiée ; année invraisemblable ignorée');
t=false;try{B.modifier(r1.entree.id,{titre:'a'})}catch(e){t=true}ok(t,'titre trop court refusé à la modification');
console.log('  — du sujet au dossier');
t=false;try{B.versDossier(B.liste().filter(x=>x.titre==='Plan photo')[0].id)}catch(e){t=true}ok(t,'sujet sans téléphone : dossier refusé');
const rd=B.versDossier(s1.entree.id);
ok(/^TFL-\d{4}-0001$/.test(rd.numero)&&T2.dossiers()[0].statut==='recu'&&T2.dossiers()[0].problematique.includes('sujet-paul.pdf'),'sujet reçu → dossier de candidature '+rd.numero+' (à compléter, fichier cité)');
ok(B.liste().filter(x=>x.id===s1.entree.id)[0].dossier_numero===rd.numero,'fiche liée au dossier');
t=false;try{B.versDossier(s1.entree.id)}catch(e){t=true}ok(t,'pas de second dossier pour le même sujet');
console.log('  — dossier terminé → bibliothèque');
const dos=T2.dossiers()[0];t=false;try{B.depuisDossier(dos.id)}catch(e){t=true}ok(t,'dossier non terminé refusé');
T2.setStatut(dos.id,'accepte');T2.patchDossier(dos.id,{etape:9});
const bd=B.depuisDossier(dos.id);ok(bd.type==='tfl'&&bd.titre==='Fondations sur sol argileux'&&bd.dossier_numero===dos.numero&&bd.auteur==='Paul Ngoy','dossier terminé gardé comme TFL résolu');
t=false;try{B.depuisDossier(dos.id)}catch(e){t=true}ok(t,'même dossier pas deux fois');
console.log('  — joindre, supprimer, catalogue');
const rj=await B.joindre(bd.id,fich('final.pdf'));ok(rj.fichier_nom==='final.pdf'&&!!F[bd.id],'document joint à une fiche sans fichier');
t=false;try{await B.joindre(bd.id,fich('autre.pdf'))}catch(e){t=true}ok(t,'fiche déjà pourvue d’un fichier : refus');
const avant=Object.keys(F).length;await B.supprimer(r2.entree.id);ok(Object.keys(F).length===avant-1&&!B.liste().some(x=>x.id===r2.entree.id),'suppression : fiche et fichier retirés');
t=false;
const pid=B.liste().filter(x=>x.titre==='Plan photo')[0].id;delete F[pid];try{await B.fichier(pid)}catch(e){t=/absent de cet appareil/.test(e.message)}ok(t,'fichier absent (sauvegarde restaurée ailleurs) : message clair');
const csv=B.csv();ok(csv.charCodeAt(0)===0xFEFF&&/"Titre";"Auteur"/.test(csv)&&/Sujet reçu/.test(csv)&&/TFL résolu/.test(csv)&&csv.split('\r\n').length===B.liste().length+1,'catalogue CSV (Excel, accents) : une ligne par fiche');
ok(Object.keys(T2.K).indexOf('bib')>=0&&T2.K.bib==='exb_tfl_biblio','fiches de la bibliothèque dans la sauvegarde TFL');
console.log('# Catalogue des sujets (V99zzv)');
{
const T3=boot({EXBTFL_MEM:{},EXBTFL_FILES:{}}).EXBTFL,S=T3.sujets;
const fiche=(o)=>Object.assign({titre:'Dimensionnement d’une dalle',categorie:'structures',domaine:'genie_civil',filiere:'Génie civil',problematique:'Quelle épaisseur ?',objectifs:'Comparer deux méthodes',methodologie:'Calcul + essais',livrables:'Mémoire, notes de calcul',competences:'BAEL, Eurocode 2',encadrement:'Pr Ilunga'},o||{});
let a=S.ajouter(fiche());
ok(a.ref==='EXB-TFL-BTP-0001'&&a.statut==='disponible'&&a.publie===false&&a.exclusif===true,'fiche créée : référence automatique, non publiée, exclusive');
ok(S.ajouter(fiche({titre:'Étude de voirie',categorie:'voirie'})).ref==='EXB-TFL-BTP-0002','référence suivante 0002');
let bad=0;[{titre:'ab'},{problematique:''},{objectifs:''}].forEach(o=>{try{S.ajouter(fiche(o))}catch(e){bad++}});
ok(bad===3,'fiche sans intitulé, problématique ou objectifs refusée');
let t=false;try{S.ajouter(fiche({ref:'EXB-TFL-BTP-0001'}))}catch(e){t=true}ok(t,'référence déjà utilisée refusée');
t=false;try{S.ajouter(fiche({ref:'a b'}))}catch(e){t=true}ok(t,'référence avec espace refusée');
ok(S.ajouter(fiche({categorie:'zzz',domaine:'zzz'})).categorie==='autre','catégorie inconnue → « autre »');
S.publier('EXB-TFL-BTP-0001',true);
ok(S.liste()[0].publie&&S.pourServeur().length===1&&S.pourServeur()[0].ref==='EXB-TFL-BTP-0001','seules les fiches publiées partent au serveur');
const pj=S.jsonPublic();ok(pj.sujets.length===1&&!('dossier_numero' in pj.sujets[0])&&!('push' in pj.sujets[0]),'fichier public : aucune donnée interne ni personnelle');
console.log('# Choisir ce sujet : exclusivité');
const choix=(nom,tel,sub,ref)=>form({submitted_at:sub,d:Object.assign(form().d,{nom:nom,telephone:tel,email:nom+'@x.cd',sujet_ref:ref||'EXB-TFL-BTP-0001',sujet_titre:'Dimensionnement d’une dalle'})});
let r1=T3.importer(choix('Alice','0811111111','2026-11-01T08:00:00.000Z'));
ok(r1.sujet&&r1.sujet.reserve===true&&S.liste()[0].statut==='reserve'&&S.liste()[0].dossier_numero===r1.numero,'sujet exclusif choisi → réservé pour ce dossier');
ok(T3.dossiers()[0].sujet_ref==='EXB-TFL-BTP-0001','le dossier garde la référence du sujet');
let r2=T3.importer(choix('Bob','0822222222','2026-11-01T09:00:00.000Z'));
ok(r2.sujet.conflit===true&&S.liste()[0].dossier_numero===r1.numero&&T3.dossiers()[1].sujet_conflit===true,'second étudiant sur un sujet réservé → conflit signalé, la réservation d’Alice reste');
T3.setStatut(T3.dossiers()[0].id,'accepte');
ok(S.liste()[0].statut==='attribue'&&S.liste()[0].push===true,'dossier accepté → sujet attribué (à synchroniser)');
const T4=boot({EXBTFL_MEM:{}}).EXBTFL;T4.sujets.ajouter(fiche());T4.sujets.publier('EXB-TFL-BTP-0001',true);
T4.importer(choix('Carine','0833333333','2026-11-02T08:00:00.000Z'));
T4.setStatut(T4.dossiers()[0].id,'refuse','Hors sujet');
ok(T4.sujets.liste()[0].statut==='disponible'&&T4.sujets.liste()[0].dossier_numero===''&&T4.sujets.liste()[0].push===true,'dossier refusé → sujet de nouveau disponible pour les autres');
const T5=boot({EXBTFL_MEM:{}}).EXBTFL;T5.sujets.ajouter(fiche({exclusif:false}));
T5.importer(choix('D1','0844444444','2026-11-03T08:00:00.000Z'));const rr=T5.importer(choix('D2','0855555555','2026-11-03T09:00:00.000Z'));
ok(T5.sujets.liste()[0].statut==='disponible'&&!rr.sujet.conflit&&T5.dossiers().length===2,'sujet non exclusif : plusieurs étudiants, jamais réservé');
const rI=T5.importer(choix('D3','0866666666','2026-11-03T10:00:00.000Z','EXB-TFL-BTP-9999'));
ok(rI.sujet.inconnu===true&&T5.dossiers().length===3,'référence inconnue : dossier créé quand même, signalé');
console.log('# Catalogue : décisions et serveur');
t=false;try{S.supprimer('EXB-TFL-BTP-0001')}catch(e){t=true}ok(t,'sujet lié à un dossier : suppression refusée');
S.statut('EXB-TFL-BTP-0001','disponible');ok(S.liste()[0].dossier_numero===''&&S.liste()[0].statut==='disponible','libérer → disponible, lien au dossier retiré');
t=false;try{S.statut('EXB-TFL-BTP-0001','zzz')}catch(e){t=true}ok(t,'disponibilité inconnue refusée');
const T6=boot({EXBTFL_MEM:{}}).EXBTFL;T6.sujets.ajouter(fiche());T6.sujets.publier('EXB-TFL-BTP-0001',true);
ok(T6.sujets.appliquerEtat([{ref:'EXB-TFL-BTP-0001',statut:'reserve'}])===1&&T6.sujets.liste()[0].statut==='reserve','réservation faite en ligne reprise dans le catalogue local');
T6.sujets.statut('EXB-TFL-BTP-0001','disponible');
ok(T6.sujets.appliquerEtat([{ref:'EXB-TFL-BTP-0001',statut:'reserve'}])===0,'décision locale non encore envoyée : jamais écrasée par le serveur');
ok(T6.sujets.pourServeur()[0].push_statut===true,'la décision locale part avec push_statut');
const csvS=S.csv();ok(csvS.charCodeAt(0)===0xFEFF&&csvS.split('\r\n').length===S.liste().length+1,'liste des sujets en CSV');
ok(T3.K.suj==='exb_tfl_sujets','catalogue dans la sauvegarde TFL');
console.log('# Bibliothèque : consultation autorisée');
const T7=boot({EXBTFL_MEM:{},EXBTFL_FILES:{}}).EXBTFL,B7=T7.biblio;
const x=(await B7.ajouter({type:'tfl',titre:'TFL de démonstration',auteur:'A. B.',annee:'2024'})).entree,y=(await B7.ajouter({type:'tfl',titre:'Autre TFL',consultation:'oui'})).entree,z=(await B7.ajouter({type:'sujet',titre:'Sujet reçu',auteur:'C. D.'})).entree;
ok(x.consultation==='non'&&y.consultation==='oui'&&z.consultation==='','consultation : « non » par défaut, « oui » si choisi, sans objet pour un sujet reçu');
B7.modifier(x.id,{consultation:'oui'});ok(B7.liste().filter(e=>e.id===x.id)[0].consultation==='oui','consultation modifiable');
B7.modifier(x.id,{consultation:'peut-être'});ok(B7.liste().filter(e=>e.id===x.id)[0].consultation==='non','valeur inconnue → « non » (prudence)');
ok(/Consultation autorisée/.test(B7.csv())&&/pas un travail à recopier/.test(T7.sujets.MENTION),'colonne CSV et mention « référence méthodologique, pas un travail à recopier »');
}
console.log(fails?'\n'+fails+' ÉCHEC(S)':'\nTout est OK');
console.log('# V99zzx fiche étudiante après le choix d’un sujet');
{ const PH='data:image/jpeg;base64,'+'A'.repeat(40);
  const c2=boot(),T2=c2.EXBTFL;
  const choix=form({submitted_at:'2026-10-20T09:00:00.000Z',ref:'SUJET-BTP-TFL-0001',d:Object.assign(form().d,{sujet_ref:'BTP-TFL-0001'})});
  const r1=T2.importer(choix);
  const fiche=form({submitted_at:'2026-10-20T09:05:00.000Z',ref:'SUJET-BTP-TFL-0001',photo:PH,d:Object.assign(form().d,{sujet_ref:'BTP-TFL-0001',annee_academique:'2025-2026',promotion:'L3 — 2026',filiere:'Génie civil',faculte:'Polytechnique',niveau:'L3',date_naissance:'2002-05-04',nationalite:'Congolaise',matricule_univ:'U-123'})});
  const r2=T2.importer(fiche);
  ok(T2.dossiers().length===1&&r2.maj===true&&r2.numero===r1.numero,'fiche complète après le choix → même dossier (pas de doublon)');
  const e=T2.etudiants()[0];
  ok(e.annee_academique==='2025-2026'&&e.promotion==='L3 — 2026'&&e.filiere==='Génie civil'&&e.faculte==='Polytechnique'&&e.niveau==='L3'&&e.nationalite==='Congolaise'&&e.matricule_univ==='U-123','année académique, promotion, spécialité, faculté, niveau enregistrés');
  ok(e.photo===PH,'photo enregistrée');
  const r3=T2.importer(form({submitted_at:'2026-10-21T09:00:00.000Z',d:Object.assign(form().d,{sujet_ref:'BTP-TFL-0001'})}));
  ok(T2.etudiants()[0].annee_academique==='2025-2026'&&T2.etudiants()[0].photo===PH,'un nouvel envoi sans ces champs ne les efface pas');
  ok(T2.dossiers().length===1,'toujours un seul dossier pour ce sujet et cet étudiant');
}
process.exit(fails?1:0);
})();


/* V99zzzzzzzzzzzzzz : formulaire encadreur, matricule automatique, décisions, validation, statuts */
{const E=T.encadreur;
const fe=(o)=>({form:'EXB_TFL_ENC',version:1,submitted_at:'2026-10-25T08:00:00.000Z',d:Object.assign({nom:'Dr Mbala',telephone:'0991112222',email:'mbala@x.cd',institution:'ISTA',domaines:['genie_civil'],sujets:[{titre:'Béton de sable local',problematique:'Quelle résistance ?',objectifs:'Mesurer',methodologie:'Essais'}]},o||{})});
let r=E.importer(fe());ok(!r.dup&&/^\d{3}-\d{3}-\d{3}$/.test(r.matricule)&&r.sujets===1,'encadreur : matricule automatique + 1 sujet reçu');
ok(E.importer(fe()).dup===true,'même formulaire encadreur importé 2 fois → ignoré');
const ref=T.sujets.liste().filter(s=>s.source==='encadreur')[0].ref;
ok(T.sujets.liste().filter(s=>s.ref===ref)[0].publie===false,'sujet proposé : non publié tant que non retenu');
let err='';try{E.decider(ref,'refuse','')}catch(e){err=e.message}ok(/motif/.test(err),'refus sans motif impossible');
E.decider(ref,'retenu','');const sj=T.sujets.liste().filter(s=>s.ref===ref)[0];ok(sj.publie===true&&sj.statut==='disponible','sujet retenu → publié et disponible');
err='';const enc=T.encadreurs().filter(x=>x.nom==='Dr Mbala')[0];const dd=T.dossiers()[0];try{T.affecter(dd.id,enc.id)}catch(e){err=e.message}ok(/validez/.test(err),'encadreur non validé : affectation refusée');
E.valider(enc.id,true);T.affecter(dd.id,enc.id);ok(T.dossiers()[0].encadreur_id===enc.id,'encadreur validé : affectation possible');
const st=E.statuts();ok(st.some(x=>x.role==='encadreur'&&x.items.length>0&&x.items[0].statut==='retenu')&&st.some(x=>x.role==='etudiant'&&x.items.length>0),'statuts à publier : encadreur (sujet retenu) et étudiants');
const P2=T.portail;P2.appliquerRetours([{id:'v1',role:'encadreur',identifiant:P2.accesAPublier().acces.filter(a=>a.role==='encadreur'&&a.nom==='Dr Mbala')[0].ident,dossier:dd.numero,type:'validation',valeur:1,texte:'Sujet pertinent',nom:'Dr Mbala',cree_le:'2026-10-26T08:00:00Z'}]);
const mv=P2.messages().filter(m=>m.type==='validation')[0];ok(!!mv&&mv.valeur===1,'validation reçue du portail encadreur');
E.appliquerValidation(mv.id);ok(T.dossiers()[0].validation_encadreur==='valide'&&T.dossiers()[0].sujet_statut==='accepte','validation appliquée au dossier');
}

/* identifiant du portail encadreur = matricule ; accès ouvert dès la validation */
{const E=T.encadreur,P=T.portail;
E.importer({form:'EXB_TFL_ENC',version:1,submitted_at:'2026-11-02T08:00:00.000Z',d:{nom:'Ir Kabeya',telephone:'0993334444',institution:'UNIKIN',sujets:[{titre:'Drainage urbain',problematique:'Inondations ?',objectifs:'Dimensionner'}]}});
const k=T.encadreurs().filter(x=>x.nom==='Ir Kabeya')[0];
ok(!P.accesAPublier().acces.some(a=>a.nom==='Ir Kabeya'),'encadreur non validé : aucun accès');
E.valider(k.id,true);
const a=P.accesAPublier().acces.filter(x=>x.nom==='Ir Kabeya')[0];
ok(!!a&&a.role==='encadreur'&&a.ident===T.encadreurs().filter(x=>x.nom==='Ir Kabeya')[0].matricule&&/^\d{3}-\d{3}-\d{3}$/.test(a.ident),'encadreur validé sans dossier : accès ouvert, identifiant = matricule');
ok(a.contenu.dossiers.length===0&&a.contenu.propositions.length===1,'portail encadreur : sujets proposés visibles, sans dossier');
}

/* V99… : avis de l'encadreur avant acceptation, demandes de retrait/modification, messages WhatsApp */
{const E=T.encadreur,P=T.portail;
T.importer({form:'EXB_TFL',version:1,submitted_at:'2026-11-05T09:00:00.000Z',d:{nom:'Avis Avant',telephone:'0975556666',email:'aa@x.cd',universite:'UNILU',domaine:'genie_civil',sujet_titre:'Pont mixte',problematique:'P',objectifs:'O',methodologie:'M'}});
const da=T.dossiers().filter(x=>x.sujet_titre==='Pont mixte')[0];
T.setStatut(da.id,'en_verification','vérif');
const k=T.encadreurs().filter(x=>x.nom==='Ir Kabeya')[0];
T.affecter(da.id,k.id);
ok(T.dossiers().filter(x=>x.id===da.id)[0].encadreur_id===k.id,'avis anticipé : encadreur affecté à un dossier « En vérification »');
const acc=P.accesAPublier().acces.filter(x=>x.nom==='Ir Kabeya')[0];
ok(acc.contenu.dossiers.some(d=>d.numero===da.numero&&d.avis===true),'portail encadreur : dossier en vérification marqué « avis demandé »');
let err='';T.setStatut(da.id,'recu','');try{T.affecter(da.id,k.id)}catch(e){err=e.message}ok(/Vérification|vérification/.test(err),'affectation refusée pour un dossier simplement « Reçu »');
T.setStatut(da.id,'en_verification','');
const r=E.demandeAppliquer({ref:da.numero,type:'modifier',texte:'Changer le titre'});
ok(T.dossiers().filter(x=>x.id===da.id)[0].statut==='complement_demande'&&/Changer le titre/.test(T.dossiers().filter(x=>x.id===da.id)[0].motif_decision),'demande de modification d’un dossier → complément demandé avec le texte');
E.demandeAppliquer({ref:da.numero,type:'retirer',texte:''});ok(T.dossiers().filter(x=>x.id===da.id)[0].statut==='clos','demande de retrait d’un dossier → clos');
const sj=T.sujets.liste().filter(s=>s.encadreur_id===k.id)[0];
E.demandeAppliquer({ref:sj.ref,type:'retirer',texte:''});const s2=T.sujets.liste().filter(s=>s.ref===sj.ref)[0];ok(s2.proposition==='retire'&&s2.publie===false,'demande de retrait d’un sujet d’encadreur → retiré, non publié');
err='';try{E.demandeAppliquer({ref:'INCONNU',type:'retirer'})}catch(e){err=e.message}ok(/introuvable/.test(err),'demande sur un élément inconnu → message clair');
ok(/MATRICULE : 12/.test(E.texteMatricule('A','12-3','etudiant'))&&/RETIRÉ/.test(E.texteDecisionProp(s2,k))&&/ACCEPTÉ/.test(E.texteDecisionDossier({statut:'accepte',sujet_titre:'X'},{nom:'N'})),'textes WhatsApp : matricule, décision sujet, décision dossier');
}

/* V99… : historique « par qui » et rappel de sauvegarde */
{const E=T.encadreur;
const b64=s=>Buffer.from(s).toString('base64').replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
const store={EXB_SB_TOKEN:JSON.stringify({access_token:'h.'+b64(JSON.stringify({email:'admin@excellencia.cd'}))+'.s'})};
c.atob=s=>Buffer.from(s,'base64').toString('binary');c.localStorage={getItem:k=>store[k]===undefined?null:store[k],setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}};
ok(E.operateur()==='admin@excellencia.cd','historique : l’adresse de l’administrateur connecté est lue dans sa session');
ok(E.joursDepuisSauvegarde()===null,'rappel : aucune sauvegarde enregistrée → null');
store.exb_tfl_last_backup=new Date(Date.now()-9*86400000).toISOString();ok(E.joursDepuisSauvegarde()===9,'rappel : 9 jours depuis la dernière sauvegarde');
const dd=T.dossiers()[0];T.setStatut(dd.id,'en_verification','');
const H=JSON.parse(JSON.stringify(c.EXBTFL_MEM['exb_tfl_historique']||[]));
ok(H.length&&H[0].par==='admin@excellencia.cd','historique : chaque décision enregistre qui l’a prise');
const sj=T.sujets.liste().filter(s=>s.source==='encadreur')[0];E.decider(sj.ref,'en_verification','');
ok(T.sujets.liste().filter(s=>s.ref===sj.ref)[0].decide_par==='admin@excellencia.cd','décision sur un sujet : auteur enregistré');
delete c.localStorage;
}

/* attestation d'encadrement : contenu transmis au moteur PDF */
{let cap=null;c.EXBForm={pdfBlobAsync:async o=>{cap=o;return {}},download(){}};
const k=T.encadreurs().filter(x=>x.nom==='Ir Kabeya')[0];T.encadreur.attestation(k.id);
ok(!!cap&&cap.titre.indexOf('ENCADREMENT')>=0&&cap.matricule===k.matricule&&/Pont mixte/.test(cap.sections[0][1]),'attestation d’encadrement : matricule et travaux encadrés transmis au PDF');
cap=null;const k2=T.encadreurs().filter(x=>x.nom==='Dr Mbala')[0];T.encadreur.attestation(k2.id);
ok(cap===null||cap.sections[0][1].length>0,'attestation d’encadrement : sans étudiant encadré → pas de PDF vide');}
