#!/usr/bin/env python3
"""Test navigateur formation + TFL : vraies fonctions saveFormation / saveParticipant / savePayment / saveCert, puis panneau direction.
Usage : python3 tools/e2e-liaison-edu.py"""
import http.server, threading, socketserver, os, functools, json
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m,d=''):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m+('' if c or not d else ' — '+str(d)))
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':420,'height':800}); errs=[]; dlg=[]
    answer={'v':True}
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    def on_dialog(d):
        dlg.append(d.message[:90]); (d.accept() if answer['v'] else d.dismiss())
    pg.on('dialog',on_dialog)
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(4500)
    ok(not errs,'chargement sans erreur JavaScript',errs[:2])
    ok(pg.evaluate("()=>!!(window.EXBLIEN&&EXBLIEN.edu)"),'extension formation/TFL chargée')
    r=pg.evaluate("""()=>{
      const set=(i,v)=>{const e=document.getElementById(i);if(e)e.value=v};
      // formation AutoCAD à 300
      fillFormationSelects();set('for_name','AutoCAD');set('for_price','300');saveFormation();
      // participant
      set('participant_id','');set('p_name','Jean Mbala');set('p_phone','+243811111111');set('p_email','jean@x.cd');
      const tr=document.getElementById('p_training');if(tr){tr.value='AutoCAD'}
      let e1='';try{saveParticipant()}catch(e){e1=String(e)}
      return {e1,f:formations.map(f=>({n:f.name,id:f.formation_id,p:f.price})),p:participants.map(p=>({id:p.participant_id,n:p.name,t:p.training,f:p.formation_id}))}}""")
    print('   ',json.dumps(r,ensure_ascii=False)[:300])
    ok(any(f['n']=='AutoCAD' and f['p']==300 for f in r['f']),'formation AutoCAD créée avec son prix')
    ok(len(r['p'])==1 and r['p'][0]['f'],'participant créé et rattaché à sa formation (formation_id)',r['p'])
    r=pg.evaluate("""()=>{
      const set=(i,v)=>{const e=document.getElementById(i);if(e)e.value=v};
      const pid=participants[0].participant_id;fillPaymentParticipants();set('pay_participant',pid);set('pay_amount','100');set('pay_method','cash');savePayment();
      set('pay_participant',pid);set('pay_amount','50');savePayment();
      return {pay:payments.map(y=>({a:y.amount,f:y.formation_id})),s:EXBLIEN.edu.situation(pid)}}""")
    ok(len(r['pay'])==2 and all(y['f'] for y in r['pay']),'2 paiements enregistrés, rattachés à la formation',r['pay'])
    ok(r['s']['verse']==150 and r['s']['solde']==150 and r['s']['statut']=='moitie','situation : versé 150 / solde 150 / moitié payée',r['s'])
    # certificat : solde impayé => confirmation demandée
    pg.evaluate("()=>{participants[0].approval_status='APPROUVE';participants[0].matricule='123-456-789';participants[0].status='ACTIF'}")
    ok(not any('prix non renseigné' in x for x in pg.evaluate("()=>EXBLIEN.anomalies()")),'les 34 formations du catalogue sans inscrit ne polluent pas les alertes')
    def cert(accept):
        answer['v']=accept; dlg.clear()
        return pg.evaluate("""()=>{const set=(i,v)=>{const e=document.getElementById(i);if(e)e.value=v};const n0=certs.length;
          set('holder','Jean Mbala');set('training','AutoCAD');set('cert_participant_id',participants[0].participant_id);set('duration','1 mois');set('place','Kinshasa');set('issued_date','2026-10-21');
          saveCert();return certs.length-n0}""")
    n=cert(False); ok(n==0 and any('à payer' in x for x in dlg),'certificat avec solde impayé : confirmation demandée, refus respecté (rien délivré)',dlg)
    n=cert(True); ok(n==1,'certificat délivré après confirmation explicite')
    pg.wait_for_timeout(300)
    an=pg.evaluate("()=>EXBLIEN.anomalies()")
    ok(any('alors qu’il reste' in x for x in an),'anomalie « certificat délivré avec solde impayé » remontée à la direction',an[:3])
    pg.evaluate("()=>{const set=(i,v)=>{const e=document.getElementById(i);if(e)e.value=v};set('pay_participant',participants[0].participant_id);set('pay_amount','150');savePayment()}")
    ok(pg.evaluate("()=>EXBLIEN.edu.situation(participants[0].participant_id).statut")=='total','après le solde : participant « Soldé »')
    ok(not any('alors qu’il reste' in x for x in pg.evaluate("()=>EXBLIEN.anomalies()")),'l’alerte disparaît une fois le solde payé')
    # TFL : étudiant = participant
    r=pg.evaluate("""()=>{const P=participants[0];
      const etu=[{id:'TFLE-T',nom:'Jean Mbala',telephone:'081 111 1111',email:'jean@x.cd',matricule:''}];
      exbStorage.setItem('exb_tfl_etudiants',JSON.stringify(etu));
      EXBLIEN.edu.linkTfl();return {e:JSON.parse(exbStorage.getItem('exb_tfl_etudiants'))[0],tfl:participants[0].tfl_etudiant_id}}""")
    ok(r['e'].get('participant_id') and r['tfl']=='TFLE-T','étudiant TFL relié au participant (même téléphone/e-mail, formats différents)',r)
    pg.evaluate("show('direction')") if pg.evaluate("()=>!!document.getElementById('direction')") else None
    pg.wait_for_timeout(400)
    ok(pg.evaluate("()=>/Formations : attendu/.test((document.getElementById('exbLienDir')||{}).innerText||'')||/Formations/.test((document.getElementById('exbLienDir')||{}).innerHTML||'')"),'panneau direction : bloc formations attendu/versé affiché')
    ok(not errs,'aucune erreur JavaScript en fin de parcours',errs[:2])
    b.close()
print('\nRésultat e2e formation/TFL :',('ÉCHEC' if fails else 'tout est OK')); raise SystemExit(1 if fails else 0)
