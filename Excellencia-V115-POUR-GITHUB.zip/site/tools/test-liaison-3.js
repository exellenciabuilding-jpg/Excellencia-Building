#!/usr/bin/env node
/* Test de la tranche 3 : pédagogie (planning, présences, notes, TP/TD) et opérations (stock, caisse, métrés, résultat par chantier).
 * Bac à sable Node, stockage simulé. Usage : node tools/test-liaison-3.js */
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');let fails=0,passes=0;
const ok=(c,m,d)=>{if(c){passes++;console.log('  OK   '+m)}else{fails++;console.log('  FAIL '+m+(d?' — '+d:''))}};
const J=o=>JSON.stringify(o);
function boot(seed,dom){const mem=Object.assign({},seed);const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
 const els=Object.assign({},dom||{});
 const document={readyState:'complete',getElementById:id=>els[id]||null,addEventListener(){},createElement:()=>({style:{},appendChild(){},setAttribute(){},getAttribute(){return null}})};
 const w={localStorage:ls,exbStorage:ls,document,save:(k,v)=>{ls.setItem(k,JSON.stringify(v))},dispatchEvent(){},confirm:()=>true,setInterval:()=>0,setTimeout:f=>{try{f()}catch(e){}return 0}};
 w.window=w;w.globalThis=w;const ctx=vm.createContext(w);vm.runInContext('Event=function(){}',ctx);
 /* listes en mémoire des écrans, comme dans index.html */
 const L=k=>{try{return JSON.parse(mem[k]||'[]')}catch(e){return[]}};
 w.__live={attendance:L('exb_attendance'),evaluations:L('exb_evaluations'),cotations:L('exb_cotations'),schedules:L('exb_schedules'),tpRequests:L('exb_tp_td_requests'),exbStock:L('exb_stock'),exbStockMoves:L('exb_stock_moves'),exbCash:L('exb_cash'),exbProjects:L('exb_projects'),exbClients:L('exb_clients'),exbHr:L('exb_hr'),participants:L('exb_participants'),formations:L('exb_formations'),trainers:L('exb_trainers'),exbQuotes:L('exb_quotes'),exbStudies:L('exb_studies'),payments:L('exb_payments'),receipts:L('exb_receipts'),certs:L('exb_certificates')};
 vm.runInContext('var '+Object.keys(w.__live).map(k=>k+'=globalThis.__live.'+k).join(',')+';',ctx);
 if(dom&&dom.__screens)dom.__screens(w,ctx);
 ['exb-liaison.js','exb-liaison-edu.js','exb-liaison-3.js'].forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f}));
 return{w,mem,ctx,X:w.EXBLIEN,get:k=>JSON.parse(mem[k]||'[]')}}
const seed=()=>({
 exb_formations:J([{formation_id:'F1',name:'AutoCAD',price:300,modules:['Bases','3D']},{formation_id:'F2',name:'Revit',price:200,modules:[{name:'BIM'}]},{formation_id:'F3',name:'Doublon'},{formation_id:'F4',name:'doublon'}]),
 exb_participants:J([{participant_id:'P1',name:'Jean Mbala',training:'AutoCAD',approval_status:'APPROUVE'},{participant_id:'P2',name:'Marie Lutu',training:'Revit',approval_status:'APPROUVE'},{participant_id:'P3',name:'Zoé',training:'Doublon',approval_status:'APPROUVE'},{participant_id:'P4',name:'Refusé',training:'AutoCAD',approval_status:'REJETE'}]),
 exb_trainers:J([{id:'TR-1',name:'Ir Kasa'},{trainer_id:'TR-2',name:'Dr Ilunga'}]),
 exb_schedules:J([
  {schedule_id:'S1',training:'AutoCAD',module:'Bases',trainer_id:'TR-1',date:'2026-10-20',start:'08:00',end:'10:00',room:'A1'},
  {schedule_id:'S2',training:'Revit',module:'BIM',trainer_id:'TR-1',date:'2026-10-20',start:'09:00',end:'11:00',room:'B2'},
  {schedule_id:'S3',training:'Revit',module:'BIM',trainer_id:'TR-2',date:'2026-10-21',start:'09:00',end:'11:00',room:'B2'},
  {schedule_id:'S4',training:'Revit',module:'Inconnu',trainer_id:'TR-9',date:'2026-10-21',start:'09:30',end:'10:30',room:'b2'},
  {schedule_id:'S5',training:'Doublon',module:'X',date:'2026-10-22',start:'08:00',end:'09:00'},
  {schedule_id:'S6',training:'AutoCAD',module:'3D',trainer_id:'TR-1',date:'2026-10-23',start:'08:00',end:'09:00'},
  {schedule_id:'S7',training:'AutoCAD',module:'3D',trainer_id:'TR-2',date:'2026-10-23',start:'13:00',end:'14:00'}]),
 exb_attendance:J([{date:'2026-10-20',participant_id:'P1',status:'PRESENT'},{date:'2026-10-20',participant_id:'P2',status:'ABSENT'},{date:'2026-10-23',participant_id:'P1',status:'PRESENT'},{date:'2026-10-20',participant_id:'PX',status:'PRESENT'},{date:'2026-10-20',participant_id:'P4',status:'PRESENT'}]),
 exb_cotations:J([{cotation_id:'C1',participant_id:'P1',module:'Bases',training:'AutoCAD'},{cotation_id:'C2',participant_id:'P1',module:'3D',training:'AutoCAD'},{cotation_id:'C3',participant_id:'P2',module:'BIM',training:'Revit'}]),
 exb_evaluations:J([{evaluation_id:'E1',participant_id:'P1',subject:'bases',training:'AutoCAD',score:15,max:20},{evaluation_id:'E2',participant_id:'P1',subject:'Autre',training:'AutoCAD',score:10,max:20},{evaluation_id:'E3',participant_id:'PZ',subject:'BIM',score:5,max:10}]),
 exb_tp_td_requests:J([{request_id:'R1',participant_id:'P1',training:'AutoCAD',work_type:'TP'},{request_id:'R2',participant_id:'PY',training:'AutoCAD',work_type:'TD'}]),
 exb_clients:J([{id:'CLI-1',full_name:'Marie Kabongo',phone:'0810000001'}]),
 exb_projects:J([{id:'PRJ1',name:'Villa Gombe',client:'Marie Kabongo',budget:1000},{id:'PRJ2',name:'Tour Lemba',client:'',budget:0},{id:'PRJ3',name:'Résidence',client:''},{id:'PRJ4',name:'résidence',client:''}]),
 exb_purchase_orders:J([{id:'PO1',no:'BC-2026-001',project_id:'PRJ1'},{id:'PO2',no:'BC-2026-002'}]),
 exb_stock:J([{id:'STK1',name:'Ciment',unit:'sac',qty:10,min:2},{id:'STK2',name:'Fer',unit:'kg',qty:-4,min:0}]),
 exb_stock_moves:J([{id:'MV1',item:'STK1',type:'in',qty:10,ref:'BC-2026-001',date:'2026-10-01'},{id:'MV2',item:'STK1',type:'out',qty:2,ref:'Tour Lemba',date:'2026-10-02'},{id:'MV3',item:'STK1',type:'out',qty:1,ref:'Résidence',date:'2026-10-03'},{id:'MV4',item:'STKX',type:'out',qty:1,ref:'',date:'2026-10-03'}]),
 exb_cash:J([{id:'CA1',type:'out',label:'Achat BC-2026-001',amount:300,ref:'BC-2026-001',category:'Matériaux'},{id:'CA2',type:'out',label:'Main-d’œuvre',amount:200,project_id:'PRJ1',category:'Main-d’œuvre'},{id:'CA3',type:'out',label:'Loyer bureau',amount:150},{id:'CA4',type:'in',label:'Encaissement',amount:999,ref:'Tour Lemba'}]),
 exb_hr:J([{id:'HR1',name:'Ouvrier A'}]),
 exb_timesheets:J([{id:'TS1',worker_id:'HR1',worker_name:'Ouvrier A',project_id:'PRJ1',date:'2026-10-05',cost:40,cash_id:''},{id:'TS2',worker_id:'HRX',worker_name:'Inconnu',project_id:'PRJ1',date:'2026-10-06',cost:30,cash_id:'CA2'},{id:'TS3',worker_id:'HR1',worker_name:'Ouvrier A',project_id:'PRJ1',date:'2026-10-07',cost:20,cash_id:'CAX'}]),
 exb_invoices:J([{id:'FA1',no:'FA-1',client:'Marie Kabongo',project_id:'PRJ1',lines:[{q:1,pu:2000}],tva:0,payments:[{id:'PAY1',date:'2026-10-10',amount:900}]}]),
 exb_metre:J([{id:'MET-1',name:'Villa',hdr:{no:'DEV-1',client:'marie kabongo',project:'Villa Gombe'}},{id:'MET-2',name:'X',hdr:{no:'DEV-2',client:'Inconnu',project:'Résidence'}},{id:'MET-3',name:'Y',hdr:{no:'DEV-3',client:'',project:''}}])
});

console.log('# Pédagogie — rattachement par identifiant');
let t=boot(seed());const O=t.X.ops;
const S=t.get('exb_schedules');
ok(S[0].formation_id==='F1'&&S[1].formation_id==='F2','séances rattachées à leur formation');
ok(!S[4].formation_id,'nom de formation porté par deux formations : aucun lien deviné');
const A=t.get('exb_attendance');
ok(A[0].formation_id==='F1'&&A[0].schedule_id==='S1','présence rattachée à la formation et à l’unique séance du jour');
ok(A[1].formation_id==='F2'&&A[1].schedule_id==='S2','présence P2 rattachée à la séance Revit du 20/10');
ok(A[2].formation_id==='F1'&&!A[2].schedule_id,'deux séances AutoCAD le même jour : séance non devinée');
ok(!A[3].formation_id,'présence d’un participant inconnu : non rattachée');
const C=t.get('exb_cotations');
ok(C[0].trainer_id==='TR-1','cotation : formateur déduit de l’unique séance du module');
ok(!C[1].trainer_id,'module donné par deux formateurs différents : pas de formateur deviné');
ok(C[2].formation_id==='F2'&&C[2].trainer_id==='TR-2'||C[2].trainer_id===undefined,'cotation Revit : formation reliée');
const E=t.get('exb_evaluations');
ok(E[0].formation_id==='F1'&&E[0].cotation_id==='C1','évaluation « bases » reliée à la cotation du module Bases (casse ignorée)');
ok(!E[1].cotation_id,'évaluation sans cotation correspondante : aucun lien');
ok(t.get('exb_tp_td_requests').every(r=>r.formation_id==='F1'),'demandes TP/TD reliées à leur formation (participant, sinon nom de formation unique)');
ok(S[0].module==='Bases'&&A[0].status==='PRESENT'&&E[0].score===15,'aucune donnée existante modifiée');
const before=J([t.get('exb_schedules'),t.get('exb_attendance'),t.get('exb_cotations'),t.get('exb_evaluations'),t.get('exb_tp_td_requests')]);O.linkPedagogie();
ok(J([t.get('exb_schedules'),t.get('exb_attendance'),t.get('exb_cotations'),t.get('exb_evaluations'),t.get('exb_tp_td_requests')])===before,'idempotent : un 2e passage ne change rien');

console.log('\n# Pédagogie — anomalies');
const AP=O.anomaliesPedagogie().join('\n');
ok(/1 participant\(s\) ont des présences.*n’existent plus/.test(AP),'présences de participants introuvables signalées');
ok(/1 présence\(s\).*participants refusés/.test(AP),'présence d’un participant refusé signalée');
ok(/notes.*n’existent plus/.test(AP),'notes de participants introuvables signalées');
ok(/Formateur Ir Kasa : deux séances se chevauchent le 2026-10-20/.test(AP),'formateur en double réservation signalé');
ok(/Salle « B2 » : deux séances se chevauchent le 2026-10-21/.test(AP),'salle en double réservation signalée (casse ignorée)');
ok(/Revit — Inconnu.*module absent du programme/.test(AP),'module absent du programme signalé');
ok(/Revit — Inconnu.*formateur introuvable/.test(AP),'formateur inconnu signalé');
ok(!/S3|BIM \(2026-10-21\).*formateur introuvable/.test(AP),'formateur déclaré par trainer_id accepté');
ok(/demande\(s\) TP\/TD d’un participant introuvable/.test(AP),'demande TP/TD d’un inconnu signalée');
ok(/Pédagogie par formation/.test(O.htmlPedagogie())&&/AutoCAD/.test(O.htmlPedagogie()),'tableau « Pédagogie par formation » produit');

console.log('\n# Opérations — stock, caisse, métrés');
const M=t.get('exb_stock_moves');
ok(M[0].po_id==='PO1'&&M[0].project_id==='PRJ1'&&M[0].client_id==='CLI-1','réception de commande : mouvement relié au bon de commande, au chantier et au client');
ok(M[1].project_id==='PRJ2','sortie dont la référence est le nom exact d’un chantier : reliée');
ok(!M[2].project_id,'nom de chantier porté par deux projets : aucun lien deviné');
const CA=t.get('exb_cash');
ok(CA[0].po_id==='PO1'&&CA[0].project_id==='PRJ1'&&CA[0].client_id==='CLI-1','dépense « Achat BC… » reliée à la commande, au chantier et au client');
ok(!CA[2].project_id,'frais généraux (sans référence) : laissés sans chantier');
ok(!CA[3].project_id,'une entrée de caisse n’est jamais touchée par cette tranche');
const MT=t.get('exb_metre');
ok(MT[0].client_id==='CLI-1'&&MT[0].project_id==='PRJ1','métré : client (casse ignorée) et chantier reliés');
ok(!MT[1].client_id&&!MT[1].project_id,'métré : client inconnu et chantier ambigu non devinés');
ok(!MT[2].client_id&&!MT[2].project_id,'métré sans client ni chantier : intact');
ok(MT[0].hdr.client==='marie kabongo','nom saisi dans le métré conservé tel quel');
const b2=J([t.get('exb_stock_moves'),t.get('exb_cash'),t.get('exb_metre')]);O.linkOperations();
ok(J([t.get('exb_stock_moves'),t.get('exb_cash'),t.get('exb_metre')])===b2,'idempotent : un 2e passage ne change rien');

console.log('\n# Opérations — résultat par chantier');
const R=O.resultat(),v=R.chantiers.find(x=>x.project_id==='PRJ1');
ok(v&&v.dep.USD===500&&v.cat['Matériaux']===300&&v.cat['Main-d’œuvre']===200,'chantier Villa Gombe : dépenses 500 (matériaux 300, main-d’œuvre 200)',J(v));
ok(v.verse.USD===900,'versé = paiements de facture (900) du registre',J(v.verse));
ok(v.mo===40,'main-d’œuvre pointée et non payée : 40 (les pointages déjà payés ne comptent pas)',String(v.mo));
ok(R.horsChantier.USD===150,'frais généraux hors chantier : 150',J(R.horsChantier));
ok(/Résultat par chantier/.test(O.htmlOperations())&&/Villa Gombe/.test(O.htmlOperations()),'tableau « Résultat par chantier » produit');

console.log('\n# Opérations — anomalies');
const AO=O.anomaliesOperations().join('\n');
ok(/Fer.*quantité négative/.test(AO),'stock négatif signalé');
ok(/STKX|MV4.*matériau introuvable/.test(AO),'mouvement sur un matériau inexistant signalé');
ok(/Inconnu.*personne introuvable/.test(AO),'pointage d’une personne absente du personnel signalé');
ok(/marqué payé mais l’écriture de caisse n’existe plus/.test(AO),'pointage payé sans écriture de caisse signalé');
ok(/Bon de commande BC-2026-002.*non renseigné/.test(AO),'bon de commande sans chantier signalé');
ok(!/supérieures au budget/.test(AO),'budget 1000 non dépassé (500) : pas d’alerte');
const cc=t.get('exb_cash');cc.push({id:'CA9',type:'out',label:'Gros achat',amount:700,project_id:'PRJ1'});t.mem.exb_cash=J(cc);t.w.__live.exbCash.push(cc[cc.length-1]);
ok(/Villa Gombe.*supérieures au budget/.test(O.anomaliesOperations().join('\n')),'dépenses > budget : alerte');
ok(t.X.anomalies().some(x=>/Formateur Ir Kasa/.test(x))&&t.X.anomalies().some(x=>/quantité négative/.test(x)),'les anomalies apparaissent dans la liste centrale « points à vérifier »');
ok(/Résultat par chantier/.test(t.w.EXBLIEN.ops.htmlOperations()),'extension branchée sur le panneau Direction');

console.log('\n# Intégrité — une modification d’écran ne fait plus perdre les liens');
function screens(w,ctx){
 vm.runInContext(`
 function saveExbCash(){const label=document.getElementById('exb_cash_label').value.trim(),amount=Number(document.getElementById('exb_cash_amount').value||0);if(!label||amount<=0)return;const id=document.getElementById('exb_cash_id').value||('CASH-'+(exbCash.length+1)),o={id,date:'2026-10-23',type:'out',label,amount,method:'',ref:''};const i=exbCash.findIndex(x=>x.id===id);if(i>=0)exbCash[i]=o;else exbCash.push(o);save('exb_cash',exbCash);}
 function saveExbStockItem(){const id=document.getElementById('exb_st_id').value;const i=exbStock.findIndex(x=>x.id===id);const o={id,name:document.getElementById('exb_st_name').value,unit:'sac',qty:5,min:1,supplier:''};if(i>=0)exbStock[i]=o;save('exb_stock',exbStock);}
 function saveExbProject(){const id=document.getElementById('exb_prj_id').value;const i=exbProjects.findIndex(x=>x.id===id);const o={id,name:document.getElementById('exb_prj_name').value,client:document.getElementById('exb_prj_client').value,budget:1000};if(i>=0)exbProjects[i]=o;save('exb_projects',exbProjects);}
 function saveExbStockMovement(){exbStockMoves.push({id:'MV'+(exbStockMoves.length+1),item:'STK1',type:'out',qty:1,ref:'',date:'2026-10-23'});save('exb_stock_moves',exbStockMoves);}
 `,ctx);
}
const el=v=>({value:v});
const dom={exb_cash_id:el('CA1'),exb_cash_label:el('Achat BC-2026-001 (corrigé)'),exb_cash_amount:el('310'),exbLienCashPrj:el(''),exb_st_id:el('STK1'),exb_st_name:el('Ciment CPA'),exb_prj_id:el('PRJ1'),exb_prj_name:el('Villa Gombe'),exb_prj_client:el('Marie Kabongo'),exbLienMvPrj:el('PRJ2'),__screens:screens};
let u=boot(seed(),dom);
u.w.saveExbCash();
let c1=u.get('exb_cash').find(x=>x.id==='CA1');
ok(c1.label==='Achat BC-2026-001 (corrigé)'&&c1.amount===310,'la modification demandée est bien appliquée');
ok(c1.project_id==='PRJ1'&&c1.po_id==='PO1'&&c1.category==='Matériaux','dépense modifiée : chantier, commande et catégorie conservés');
u.w.saveExbStockItem();
ok(u.get('exb_stock').find(x=>x.id==='STK1').name==='Ciment CPA','matériau modifié');
u.w.saveExbProject();
ok(u.get('exb_projects').find(x=>x.id==='PRJ1').client_id==='CLI-1','projet modifié : son client reste relié');
dom.exb_prj_client.value='';u.w.saveExbProject();
ok(!u.get('exb_projects').find(x=>x.id==='PRJ1').client_id,'projet dont on retire le client : l’ancien lien n’est pas conservé à tort');
dom.exb_cash_id.value='';dom.exb_cash_label.value='Transport';dom.exb_cash_amount.value='80';dom.exbLienCashPrj.value='PRJ2';u.w.saveExbCash();
const nc=u.get('exb_cash').find(x=>x.label==='Transport');
ok(nc&&nc.project_id==='PRJ2','nouvelle dépense : chantier choisi dans le formulaire enregistré');
ok(dom.exbLienCashPrj.value==='','sélecteur remis à zéro après enregistrement');
u.w.saveExbStockMovement();
const nm=u.get('exb_stock_moves').slice(-1)[0];
ok(nm.project_id==='PRJ2','nouveau mouvement de stock : chantier choisi enregistré');
dom.exb_cash_label.value='';dom.exb_cash_amount.value='0';dom.exbLienCashPrj.value='PRJ1';const n0=u.get('exb_cash').length;u.w.saveExbCash();
ok(u.get('exb_cash').length===n0&&!u.get('exb_cash').some(x=>x.project_id==='PRJ1'&&x.label==='Transport'&&x.amount!==80),'saisie invalide : rien n’est enregistré ni rattaché');

console.log('\nRésultat liaison tranche 3 : '+passes+' contrôles réussis, '+fails+' échec(s).');process.exit(fails?1:0);
