/* Tests du moteur de décomptes (node tools/test-decompte.js) — valeurs recalculées à la main. */
const E=require('../exb-decompte.js');let ko=0;
const eq=(a,b,m)=>{const ok=Math.abs(a-b)<0.005;console.log((ok?'  OK   ':'  FAIL ')+m+(ok?'':` (obtenu ${a}, attendu ${b})`));if(!ok)ko++};
const base=()=>({postes:[{id:'a',qte:100,pu:50},{id:'b',qte:20,pu:500}],decomptes:[{id:'d1',cumul:{a:40,b:4},retard_jours:0},{id:'d2',cumul:{a:100,b:10},retard_jours:12}],params:{}});
let c=E.calc(base()),l=c.lignes;
eq(c.montantMarche,15000,'montant du marché = 5 000 + 10 000');
eq(c.avanceMontant,2250,'avance 15 % = 2 250');
eq(l[0].travauxMois,4000,'décompte 1 : travaux du mois');eq(l[0].tva,640,'décompte 1 : TVA 16 %');
eq(l[0].retenueMois,200,'décompte 1 : retenue de garantie 5 %');eq(l[0].remboursementAvanceMois,600,'décompte 1 : avance remboursée au prorata (26,67 %)');
eq(l[0].netAPayer,3840,'décompte 1 : net à payer');
eq(l[1].travauxMois,6000,'décompte 2 : travaux du mois = cumul − précédent');eq(l[1].retenueCumul,500,'décompte 2 : retenue cumulée');
eq(l[1].remboursementAvanceMois,900,'décompte 2 : remboursement du mois (cumul 1 500)');eq(l[1].penalitesMois,180,'décompte 2 : pénalités 12 j × 0,1 % × 15 000');
eq(l[1].netAPayer,5580,'décompte 2 : net à payer');
// plafond des pénalités (10 % = 1 500) et avance jamais dépassée
let m=base();m.decomptes[1].retard_jours=500;eq(E.calc(m).lignes[1].penalitesCumul,1500,'pénalités plafonnées à 10 % du marché');
m=base();m.decomptes[1].cumul={a:100,b:20};eq(E.calc(m).lignes[1].remboursementAvanceCumul,2250,'avance remboursée en totalité à 100 %');
// paramètres modifiables + TVA 0
m=base();m.params={tva_pct:0,retenue_pct:10,avance_pct:0};l=E.calc(m).lignes;eq(l[0].tva,0,'TVA 0 %');eq(l[0].retenueMois,400,'retenue 10 %');eq(l[0].remboursementAvanceMois,0,'sans avance');
// révision : K = 0,15 + 0,5 × 110/100 + 0,35 × 120/100 = 1,12
m=base();m.params={rev_actif:true};m.idx={i1_0:100,i2_0:100};m.decomptes[0].i1=110;m.decomptes[0].i2=120;l=E.calc(m).lignes;
eq(l[0].coefRevision,1.12,'coefficient de révision K');eq(l[0].revisionMois,480,'révision = 4 000 × 0,12');eq(l[0].baseHT,4480,'base HT = travaux + révision');
// cautions
eq(E.etatCaution({expiration:'2026-10-01'},'2026-10-13')==='expiree'?1:0,1,'caution expirée');eq(E.etatCaution({expiration:'2026-11-01'},'2026-10-13')==='bientot'?1:0,1,'caution < 30 jours');
eq(E.etatCaution({expiration:'2027-06-01'},'2026-10-13')==='valide'?1:0,1,'caution valide');eq(E.etatCaution({expiration:'2026-10-01',levee:true},'2026-10-13')==='levee'?1:0,1,'caution levée');
// libération de la retenue de garantie : cumul 500 après 2 décomptes ; 250 libérés à la réception provisoire
m=base();m.liberations=[{montant:250,motif:'Réception provisoire'}];let rs=E.retenueSolde(m);eq(rs.cumul,500,'retenue cumulée = 500');eq(rs.libere,250,'retenue libérée = 250');eq(rs.solde,250,'solde encore retenu = 250');
m.liberations.push({montant:250});eq(E.retenueSolde(m).solde,0,'retenue entièrement libérée à la réception définitive');eq(E.retenueSolde({postes:[],decomptes:[]}).solde,0,'marché sans décompte : aucune retenue');
console.log('\nRésultat :',ko?ko+' échec(s)':'tout passe');process.exit(ko?1:0);
