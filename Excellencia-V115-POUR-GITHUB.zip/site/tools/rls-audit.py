#!/usr/bin/env python3
"""Audit statique (sans base de données) des politiques RLS des migrations Supabase.
Usage : python3 tools/rls-audit.py [--json]   (depuis le dossier du site)
Lit supabase/*.sql dans l'ordre d'exécution de tools/test-rls/run.sh, déplie les boucles « foreach t in array … create policy … format(…) »,
puis liste pour chaque table : RLS activée ?, politiques par commande, fonction de garde utilisée. Signale les anomalies. Ne remplace PAS l'exécution des tests sur PostgreSQL (tools/test-rls/run.sh)."""
import re, os, sys, json
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); D=os.path.join(ROOT,'supabase')
order=re.search(r'for f in (.*?); do',open(os.path.join(ROOT,'tools/test-rls/run.sh'),encoding='utf-8').read(),re.S).group(1).split()
def strip(s): return re.sub(r'--[^\n]*','',s)
tables={}; rls=set(); pols=[]; defs=[]; grants=[]
def add_stmt(st,f):
    m=re.match(r'\s*alter\s+table\s+(?:if\s+exists\s+)?(?:public\.)?"?(\w+)"?\s+enable\s+row\s+level\s+security',st,re.I)
    if m: rls.add(m.group(1)); return
    m=re.match(r'\s*create\s+policy\s+"?([\w%]+)"?\s+on\s+(?:public\.)?"?(\w+)"?\s*(.*)',st,re.I|re.S)
    if m:
        body=m.group(3); cmd=(re.search(r'\bfor\s+(select|insert|update|delete|all)\b',body,re.I) or [0,'all'])[1].lower()
        to=(re.search(r'\bto\s+([\w, ]+?)(?=\s+(?:using|with)\b|$)',body,re.I) or [0,''])[1].strip().lower()
        pols.append(dict(table=m.group(2),name=m.group(1),cmd=cmd,to=to,body=' '.join(body.split()),file=f)); return
    m=re.match(r'\s*drop\s+policy\s+(?:if\s+exists\s+)?"?([\w%]+)"?\s+on\s+(?:public\.)?"?(\w+)"?',st,re.I)
    if m: pols[:]=[p for p in pols if not(p['table']==m.group(2) and p['name']==m.group(1))]
for f in order:
    p=os.path.join(D,f+'.sql')
    if not os.path.exists(p): print('MANQUANT',f,file=sys.stderr); continue
    s=strip(open(p,encoding='utf-8').read())
    for m in re.finditer(r'create\s+table\s+(?:if\s+not\s+exists\s+)?(?:public\.)?"?(\w+)"?\s*\((.*?)\n\)\s*;',s,re.I|re.S): tables.setdefault(m.group(1),dict(file=f,cols=m.group(2)))
    for m in re.finditer(r'create\s+table\s+(?:if\s+not\s+exists\s+)?(?:public\.)?"?(\w+)"?',s,re.I): tables.setdefault(m.group(1),dict(file=f,cols=''))
    # boucles dynamiques
    for m in re.finditer(r'foreach\s+(\w+)\s+in\s+array\s+array\[(.*?)\]\s+loop(.*?)end\s+loop',s,re.I|re.S):
        var,lst,body=m.groups();names=re.findall(r"'([\w]+)'",lst)
        for ex in re.finditer(r"execute\s+format\(\s*'((?:[^']|'')*)'",body,re.I|re.S):
            tpl=ex.group(1).replace("''","'")
            for t in names: add_stmt(tpl.replace('%I',t),f)
    # boucles « for r in select * from (values (table, collection), …) as v(t,c) loop … » (V99zz)
    for m in re.finditer(r'values\s*(.*?)\)\s*as\s+v\(t,\s*c\)\s*loop(.*?)end\s+loop',s,re.I|re.S):
        pairs=re.findall(r"\('(\w+)'\s*,\s*'(\w+)'\)",m.group(1))
        for ex in re.finditer(r"execute\s+format\(\s*'((?:[^']|'')*)'\s*,([^;]*?)\)\s*;",m.group(2),re.I|re.S):
            tpl=ex.group(1).replace("''","'"); args=[a.strip() for a in ex.group(2).split(',')]
            for t,c in pairs:
                out_s=tpl; vals=iter(args)
                out_s=re.sub(r'%[IL]',lambda _:(lambda a:(t if a=='r.t' else c if a=='r.c' else a))(next(vals,'')),out_s)
                add_stmt(out_s.replace("'"+c+"'",'<collection>') if False else out_s,f)
    s_nolo=re.sub(r'foreach\s+\w+\s+in\s+array.*?end\s+loop','',s,flags=re.I|re.S)
    for st in s_nolo.split(';'): add_stmt(st,f)
    for m in re.finditer(r'create\s+(?:or\s+replace\s+)?function\s+(?:public\.)?(\w+)\s*\((.*?)\)(.*?)(?:\$\$|\$\w+\$)',s,re.I|re.S):
        hdr=m.group(3); defs.append(dict(name=m.group(1),file=f,definer=bool(re.search(r'security\s+definer',hdr,re.I)),searchpath=bool(re.search(r'search_path',hdr,re.I))))
    for m in re.finditer(r'grant\s+(.*?)\s+on\s+(.*?)\s+to\s+(\w+)',s,re.I): grants.append((m.group(1).lower(),m.group(2).lower(),m.group(3).lower(),f))
# anomalies
out=[];A=[]
sens={'erp_paies','erp_contrats_rh','erp_employes','erp_comptes_bancaires','erp_transactions_bancaires','paiements','operations_caisse','moyens_paiement'}
for t,info in sorted(tables.items()):
    ps=[p for p in pols if p['table']==t]; cmds=set(p['cmd'] for p in ps)
    has_org='org_id' in info['cols'] or not info['cols']
    row=dict(table=t,file=info['file'],rls=t in rls,policies=len(ps),cmds=sorted(cmds))
    guards=set()
    for p in ps:
        for g in re.findall(r'\b(est_membre|peut|exb_[a-z_]+|peut_[a-z_]+|droit_[a-z_]+|auth\.uid|auth\.role)\s*\(',p['body']): guards.add(g)
    row['guards']=sorted(guards); out.append(row)
    if t not in rls: A.append(('HAUTE',t,'RLS non activée (détection statique)'))
    elif not ps: A.append(('INFO',t,'RLS activée sans politique : table fermée (accès par fonctions seulement)'))
    for p in ps:
        if re.search(r'using\s*\(\s*true\s*\)|with\s+check\s*\(\s*true\s*\)',p['body'],re.I): A.append(('HAUTE' if p['cmd']!='select' else 'MOYENNE',t,'politique « %s » (%s) ouverte à tous (true)'%(p['name'],p['cmd'])))
        if p['to'] and ('anon' in p['to'] or 'public' in p['to']): A.append(('MOYENNE',t,'politique « %s » accordée à %s'%(p['name'],p['to'])))
    if ps and t in sens and 'peut' not in guards : A.append(('MOYENNE',t,'donnée sensible protégée par le seul rôle (admin/éditeur) et non par la fonction : %s'%', '.join(sorted(guards))))
    if ps and not (cmds & {'select','all'}): A.append(('INFO',t,'aucune politique de lecture'))
for d in defs:
    if d['definer'] and not d['searchpath']: A.append(('MOYENNE',d['name']+'()','SECURITY DEFINER sans search_path fixé (%s)'%d['file']))
for g in grants:
    if g[2] in('anon','public') and re.search(r'\b(all|insert|update|delete)\b',g[0]): A.append(('HAUTE',g[1],'GRANT %s à %s (%s)'%(g[0],g[2],g[3])))
if '--json' in sys.argv: print(json.dumps(dict(tables=out,anomalies=A),ensure_ascii=False,indent=1)); sys.exit(0)
print('Tables : %d | RLS activée : %d | politiques : %d | fonctions : %d'%(len(tables),sum(1 for r in out if r['rls']),len(pols),len(defs)))
for lvl in('HAUTE','MOYENNE','INFO'):
    L=[a for a in A if a[0]==lvl]
    print('\n== %s (%d)'%(lvl,len(L)))
    for a in L: print(' -',a[1],':',a[2])
sys.exit(1 if any(a[0]=='HAUTE' for a in A) else 0)
