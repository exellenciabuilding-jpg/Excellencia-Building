#!/usr/bin/env python3
"""Test navigateur (Playwright + Chromium) — complète tools/check.js (qui reste statique).
Usage, depuis le dossier du site :  pip install playwright && playwright install chromium && python3 tools/e2e-smoke.py
Vérifie : chargement sans erreur JS, protection de la clé privée de licence, parcours de menu Construction / Formation,
calculateur de structure (poteau, poutre, dalle, semelle, escalier : 3D + note + plan, modules simples)."""
import http.server, threading, socketserver, os, functools, sys
from playwright.sync_api import sync_playwright
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); os.chdir(ROOT)
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory=ROOT)); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
fails=0
def ok(c,m):
    global fails
    print(('  OK   ' if c else '  FAIL ')+m)
    if not c: fails+=1
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1000,'height':800}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(3000)
    ok(not errs,'index.html : aucune erreur JavaScript '+str(errs[:2]))
    r=pg.evaluate("()=>{localStorage.setItem('exb_lic_priv','{\"d\":\"X\"}');return [Object.keys(localStorage).includes('exb_lic_priv'),sessionStorage.getItem('exb_lic_priv')!=null]}")
    ok(r==[False,True],'clé privée : jamais écrite dans le stockage local durable'); pg.evaluate("localStorage.removeItem('exb_lic_priv')")
    ok(pg.evaluate("()=>{const x=esc('\"><img src=x onerror=alert(1)>');return x.indexOf('<')<0&&x.indexOf('\"')<0}"),'esc() : neutralise < > et les guillemets (injection dans attribut)')
    t=pg.evaluate("()=>{const o={};['btp','for','all'].forEach(m=>{EXB_SHELL.setParcours(m);o[m]=[...document.querySelectorAll('#exbSide .xs')].map(x=>x.textContent).join('|')});return o}")
    ok('Formation' not in t['btp'] and 'Architecture' in t['btp'],'parcours Construction : sans Formation')
    ok('Architecture' not in t['for'] and 'Formation' in t['for'],'parcours Formation : sans Architecture / Chantiers')
    ok('Formation' in t['all'] and 'Architecture' in t['all'],'parcours Tout : menu complet')

    # --- Parcours réel : connexion locale (écran de licence retiré UNIQUEMENT dans ce test) puis ouverture de chaque entrée du menu ---
    a=b.new_page(viewport={'width':1100,'height':800}); ae=[]
    a.on('pageerror',lambda e:ae.append(str(e)[:160]))
    a.on('dialog',lambda d:d.accept('TestLocal#2026') if d.type=='prompt' else d.accept())
    a.add_init_script("setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},200)")
    a.goto(f'http://127.0.0.1:{PORT}/index.html'); a.wait_for_timeout(3000)
    a.fill('#li_user','admin'); a.fill('#li_pass','admin'); a.click('text=Se connecter'); a.wait_for_timeout(3000)
    ok(a.evaluate("getComputedStyle(document.getElementById('app')).display")!='none','connexion locale (identifiant par défaut, changement de mot de passe imposé)')
    tot=0; bad=[]
    for k in ['ent','for','crm','arc','ing','prj','fin','ach','rap','set']:
        a.evaluate("(k)=>EXB_SHELL.openCat(k)",k); a.wait_for_timeout(150)
        n=a.evaluate("document.querySelectorAll('#exbHub .xg .c').length")
        for j in range(n):
            ae.clear(); a.evaluate("(k)=>EXB_SHELL.openCat(k)",k); a.wait_for_timeout(100)
            lab=a.evaluate("(j)=>document.querySelectorAll('#exbHub .xg .c b')[j].textContent",j)
            a.evaluate("([j,k])=>EXB_SHELL.go(j,k)",[j,k]); a.wait_for_timeout(400)
            shown=a.evaluate("""()=>[...document.querySelectorAll('body *')].some(e=>e.id!=='app'&&e.id!=='exbHub'&&e.offsetParent!==null&&e.innerText&&e.innerText.length>40&&e.getBoundingClientRect().height>120&&getComputedStyle(e).display!=='none')""")
            tot+=1
            if ae or not shown: bad.append((k,lab,ae[:1]))
    ok(not bad,f'menu : les {tot} entrées s\'ouvrent sans erreur JavaScript '+str(bad[:3]))


    # --- V99zt : focalisation produit (accueil, indicateurs, recherche selon le parcours) ---
    ae.clear()
    f=a.evaluate("""()=>{const o={};['btp','for','all'].forEach(m=>{EXB_SHELL.setParcours(m);o[m]={k:document.getElementById('xhK').innerText,s:document.getElementById('xhSub').innerText,ph:document.getElementById('exbGlobalSearch').placeholder}});return o}""")
    ok('Projets terminés' in f['btp']['k'] and 'Apprenants' not in f['btp']['k'] and 'certificat' not in f['btp']['ph'].lower(),'accueil Construction : indicateurs et recherche sans apprenants / certificats')
    ok('Certificats' in f['for']['k'] and 'Projets' not in f['for']['k'] and 'projet' not in f['for']['ph'].lower(),'accueil Formation : indicateurs et recherche sans projets')
    ok('Clients' in f['all']['k'] and 'Apprenants' in f['all']['k'],'accueil Tout : indicateurs d\'origine')
    a.evaluate("()=>{localStorage.removeItem('exb_parcours_ask');EXB_SHELL.setParcours('all')}")
    ok(a.evaluate("()=>document.getElementById('xhPick').innerText.includes('Que souhaitez-vous')"),'premier lancement : bandeau de choix du parcours affiché')
    a.evaluate("()=>EXB_SHELL.pickParcours('btp')")
    ok(a.evaluate("()=>document.getElementById('xhPick').innerText===''&&EXB_SHELL.parcours()==='btp'"),'choix du parcours : bandeau retiré, parcours enregistré')
    ok(not ae,'focalisation produit : aucune erreur JavaScript '+str(ae[:2]))
    # recherche filtrée par parcours + parcours par défaut selon la fonction
    r=a.evaluate("""()=>{const box=document.getElementById('exbGlobalResults');const out={};
      box.style.display='block';box.innerHTML='<div class="exb-search-item"><div class="exb-search-type">Projet</div>p</div><div class="exb-search-item"><div class="exb-search-type">Certificat</div>c</div>';
      ['btp','for','all'].forEach(m=>{EXB_SHELL.setParcours(m);EXB_SHELL.filterSearch();out[m]=[...box.querySelectorAll('.exb-search-item')].map(e=>e.style.display==='none'?'-':e.querySelector('.exb-search-type').textContent)});
      box.innerHTML='';return out}""")
    ok(r['btp']==['Projet','-'] and r['for']==['-','Certificat'] and r['all']==['Projet','Certificat'],'recherche : résultats filtrés selon le parcours '+str(r))
    ok(a.evaluate("()=>{localStorage.removeItem('exb_parcours');const o=EXB_SHELL.parcours();return o}")=='all','parcours sans choix ni fonction : Tout')
    a.evaluate("()=>{localStorage.setItem('exb_parcours','all')}")
    a.evaluate("()=>EXB_SHELL.setParcours('all')")

    # --- Planning : dépendances, marges, chemin critique ---
    ae.clear()
    a.evaluate("""()=>{if(!exbProjects.some(p=>p.id==='PRJ_PL')){exbProjects.push({id:'PRJ_PL',name:'Chantier Planning',currency:'USD'});save(EXB_ECO_KEYS.projects,exbProjects)}
      show('plangantt');EXBPL.tab('g');EXBPL.pid('PRJ_PL');EXBPL.newG(false)}""")
    a.evaluate("""()=>{const g=load('exb_gantt',[]).find(x=>x.project_id==='PRJ_PL');g.date='2026-10-05';
      g.tasks=[{id:'t1',name:'Fondations',start:1,dur:2,pct:100,pred:''},{id:'t2',name:'Élévation',start:1,dur:3,pct:0,pred:'1'},{id:'t3',name:'Plomberie',start:1,dur:1,pct:0,pred:'1'},{id:'t4',name:'Finitions',start:1,dur:1,pct:0,pred:'2, 3'}];
      const all=load('exb_gantt',[]).map(x=>x.id===g.id?g:x);save('exb_gantt',all);EXBPL.render()}""")
    a.wait_for_timeout(300)
    cp=a.evaluate("EXBPL._cpm()")
    ok(cp['fin']==6 and cp['critiques']==[1,2,4],'planning : durée 6 sem., chemin critique 1 → 2 → 4')
    txt=a.evaluate("document.getElementById('exbpl_box').textContent")
    ok('chemin critique' in txt and 'Retard prévisionnel' in txt and 'Préd.' in txt and 'Marge' in txt,'planning : colonnes Préd. / Marge et cartes affichées')
    a.evaluate("EXBPL.delT(1)")
    ok(a.evaluate("load('exb_gantt',[]).find(x=>x.project_id==='PRJ_PL').tasks.map(t=>t.pred).join('|')")=='|1|2','planning : suppression d\'une tâche → liens renumérotés')
    a.evaluate("EXBPL.tf(0,'pred','<img src=x>2')")
    ok('<' not in a.evaluate("load('exb_gantt',[]).find(x=>x.project_id==='PRJ_PL').tasks[0].pred"),'planning : champ Préd. assaini (aucun caractère HTML)')
    ok(not ae,'planning : aucune erreur JavaScript '+str(ae[:2]))

    # --- Contrôles & sécurité : checklist signée → non-conformité, causerie signée, photo, position ---
    ae.clear()
    a.evaluate("""()=>{navigator.geolocation.getCurrentPosition=cb=>cb({coords:{latitude:-4.3217,longitude:15.3125,accuracy:12}});
      if(!exbProjects.some(p=>p.id==='PRJ_CT')){exbProjects.push({id:'PRJ_CT',name:'Chantier Contrôles',currency:'USD'});save(EXB_ECO_KEYS.projects,exbProjects)}
      show('chantierctl');EXBCTL.pick('PRJ_CT');EXBCTL.newC()}""")
    def draw():
        box=a.locator('canvas[width="360"]').bounding_box(); a.mouse.move(box['x']+30,box['y']+40); a.mouse.down(); a.mouse.move(box['x']+120,box['y']+90,steps=6); a.mouse.move(box['x']+200,box['y']+50,steps=6); a.mouse.up()
    a.evaluate("()=>{const c=load('exb_ctl_chk',[])[0];c.items.forEach((x,i)=>{x.r=i===1?'nok':'ok'});c.items[1].rem='cales manquantes';save('exb_ctl_chk',[c]);EXBCTL.cset('signataire','Ing. Test');EXBCTL.cgeo()}")
    a.evaluate("EXBCTL.csign()"); a.wait_for_timeout(200); draw(); a.click('button[data-a="v"]'); a.wait_for_timeout(300)
    chk=a.evaluate("load('exb_ctl_chk',[])[0]"); ncs=a.evaluate("load('exb_ctl_nc',[])")
    ok(chk['signe'] and chk['signature'].startswith('data:image/png') and chk['geo'] and abs(chk['geo']['lat']+4.3217)<1e-6,'contrôles : checklist signée au doigt, position enregistrée')
    ok(len(ncs)==1 and 'cales manquantes' in ncs[0]['desc'] and ncs[0]['statut']=='ouverte','contrôles : le point NOK crée une non-conformité ouverte (remarque reprise)')
    a.evaluate("()=>{EXBCTL.tab('s');EXBCTL.newS();const c=load('exb_ctl_cau',[])[0];c.part=[{nom:'Ouvrier A',sig:''},{nom:'Ouvrier B',sig:''}];save('exb_ctl_cau',[c]);EXBCTL.sset('animateur','Chef de chantier');EXBCTL.render();EXBCTL.psign(0)}")
    a.wait_for_timeout(200); draw(); a.click('button[data-a="v"]'); a.wait_for_timeout(200)
    a.evaluate("EXBCTL.ssign()"); a.wait_for_timeout(200); draw(); a.click('button[data-a="v"]'); a.wait_for_timeout(300)
    cau=a.evaluate("load('exb_ctl_cau',[])[0]")
    ok(cau['signe'] and cau['part'][0]['sig'].startswith('data:image/png') and not cau['part'][1]['sig'],'contrôles : causerie clôturée, 1 participant sur 2 a signé')
    a.evaluate("EXBCTL.tab('n'),EXBCTL.nopen(load('exb_ctl_nc',[])[0].id)")
    PNG=__import__('base64').b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')
    a.set_input_files('input[type=file][capture]',{'name':'p.png','mimeType':'image/png','buffer':PNG}); a.wait_for_timeout(500)
    ok(a.evaluate("load('exb_ctl_nc',[])[0].photo").startswith('data:image/jpeg'),'contrôles : photo de la non-conformité réduite et enregistrée')
    a.evaluate("EXBCTL.nset('statut','levee')")
    ok(a.evaluate("load('exb_ctl_nc',[])[0].levee_le")!=None,'contrôles : non-conformité levée datée')
    a.evaluate("EXBCTL.nset('desc','<img src=x onerror=alert(1)>')"); a.wait_for_timeout(100)
    ok(a.evaluate("document.getElementById('exbctl_box').querySelectorAll('img[src=x]').length")==0,'contrôles : texte saisi échappé à l\'affichage')
    ok(not ae,'contrôles : aucune erreur JavaScript '+str(ae[:2]))

    # --- Rapport journalier enrichi + pointage géolocalisé ---
    ae.clear()
    a.evaluate("""()=>{show('terrain');EXBTR.pid('PRJ_CT');EXBTR.tab('j');EXBTR.newJr();EXBTR.fe(0,4);EXBTR.fe(5,10);EXBTR.ega();EXBTR.eg(0,'type','Pelleteuse');EXBTR.eg(0,'h','6');
      EXBTR.f('pluie_h','3',1);EXBTR.f('work','Coulage de la dalle');EXBTR.f('signataire','Ing. Test');EXBTR.jgeo()}""")
    a.evaluate("EXBTR.jsign()"); a.wait_for_timeout(200); draw(); a.click('button[data-a="v"]'); a.wait_for_timeout(300)
    a.evaluate("EXBTR.saveJr()"); a.wait_for_timeout(200)
    j=a.evaluate("load('exb_site_journal',[]).slice(-1)[0]")
    ok(j['crew']==14 and j['effectifs']['Maçons']==4 and j['effectifs']['Manœuvres']==10,'rapport journalier : effectifs par corps (4 maçons + 10 manœuvres = 14)')
    ok(j['engins'][0]['type']=='Pelleteuse' and j['engins'][0]['h']==6 and j['pluie_h']==3,'rapport journalier : engin, heures et heures perdues enregistrés')
    ok(j['signature'].startswith('data:image/png') and abs(j['geo']['lat']+4.3217)<1e-6,'rapport journalier : visa signé au doigt et position')
    a.evaluate("()=>{window.__pdf=null;EXBPdf.make=o=>{window.__pdf=o;return Promise.resolve(new Blob())};EXBPdf.save=()=>{};EXBTR.pdfJr(load('exb_site_journal',[]).slice(-1)[0].id)}"); a.wait_for_timeout(200)
    rows=a.evaluate("(window.__pdf&&window.__pdf.rows||[]).map(r=>r.join(' = ')).join(' | ')")
    ok('Maçons : 4' in rows and 'Pelleteuse 6 h' in rows and 'Heures perdues' in rows and 'Visa' in rows and 'Position' in rows,'rapport journalier : le PDF reprend effectifs, engins, visa et position')
    a.evaluate("""()=>{exbHr.push({id:'H_T',name:'Jean Maçon',role:'Maçon',salary:260});EXBTR.tab('p');EXBTR.pid('PRJ_CT');document.getElementById('exbtr_tw').value='H_T';EXBTR.rate();EXBTR.tgeo()}""")
    a.evaluate("EXBTR.addT()"); a.wait_for_timeout(200)
    ts=a.evaluate("load('exb_timesheets',[]).filter(t=>t.worker_id==='H_T').slice(-1)[0]")
    ok(ts and ts['geo'] and abs(ts['geo']['lng']-15.3125)<1e-6,'pointage : position jointe au pointage de l\'ouvrier')
    ok(not ae,'rapport / pointage : aucune erreur JavaScript '+str(ae[:2]))
    # --- Décomptes : parcours complet marché → DQE → décompte → net à payer ---
    a.evaluate("""()=>{exbProjects.push({id:'PRJ_T',name:'Immeuble Test',currency:'USD'});save(EXB_ECO_KEYS.projects,exbProjects);
      save('exb_dqe',[{id:'q1',ref:'1.1',project:'Immeuble Test',designation:'Béton',unit:'m3',qty:100,pu:50},{id:'q2',ref:'1.2',project:'Immeuble Test',designation:'Acier',unit:'kg',qty:20,pu:500},{id:'q3',ref:'9',project:'Autre',designation:'x',unit:'u',qty:1,pu:1}])}""")
    a.evaluate("EXB_SHELL.openCat('fin')"); a.wait_for_timeout(200)
    ok(a.evaluate("[...document.querySelectorAll('#exbHub .xg .c b')].some(b=>/Décomptes/.test(b.textContent))"),'menu Finance : entrée « Décomptes » présente')
    ae.clear()
    a.evaluate("show('decomptes')"); a.wait_for_timeout(400)
    a.evaluate("EXBDEC.pick('PRJ_T')"); a.evaluate("EXBDEC.impDqe()"); a.wait_for_timeout(200)
    ok(a.evaluate("EXBDEC_CALC.montant(JSON.parse(localStorage.getItem('exb_decomptes')||'[]')[0]||load('exb_decomptes',[])[0])")==15000,'décomptes : DQE du chantier importé (3e ligne d\'un autre chantier ignorée), marché = 15 000')
    a.evaluate("EXBDEC.tab('d')"); a.evaluate("EXBDEC.newD()")
    pid=a.evaluate("load('exb_decomptes',[])[0].postes.map(p=>p.id)")
    a.evaluate("([x,y])=>{EXBDEC.cum(x,40);EXBDEC.cum(y,4)}",pid); a.wait_for_timeout(200)
    txt=a.inner_text('#exbdec_box')
    ok('NET À PAYER' in txt and '3 840,00' in txt,'décomptes : net à payer affiché = 3 840,00 (4 000 HT + TVA − retenue − avance)')
    ok('à confirmer par contrat' in (a.evaluate("EXBDEC.tab('m'),document.getElementById('exbdec_box').innerText")),'décomptes : taux marqués « à confirmer par contrat »')
    a.evaluate("EXBDEC.tab('d')"); a.wait_for_timeout(150)
    ok('Retenue de garantie' in a.inner_text('#exbdec_box') or 'Retenue de garantie' in a.evaluate("document.getElementById('exbdec_box').innerText"),'décomptes : bloc « Retenue de garantie » affiché')
    a.evaluate("()=>{document.getElementById('exbdec_la').value='100';EXBDEC.lib()}"); a.wait_for_timeout(150)
    ok(a.evaluate("EXBDEC_CALC.retenueSolde(load('exb_decomptes',[]).find(m=>m.project_id==='PRJ_T')).libere")==100,'décomptes : libération de 100 enregistrée')
    a.evaluate("EXBDEC.tab('c'),EXBDEC.addC('Bonne exécution',500)"); a.wait_for_timeout(200)
    ok('Valide' in a.inner_text('#exbdec_box') or 'Valide' in a.evaluate("document.getElementById('exbdec_box').innerText"),'décomptes : caution ajoutée')
    a.screenshot(path='/tmp/decomptes.png')
    ok(not ae,'décomptes : aucune erreur JavaScript '+str(ae[:2]))
    # --- Import de sauvegarde : clés sensibles bloquées, identifiants nettoyés ---
    a.evaluate("exbStorage.setItem('exb_user','admin')")
    a.evaluate("""()=>{const d={storage_prefix:(typeof EXB_STORAGE_PREFIX!=='undefined'?EXB_STORAGE_PREFIX:undefined),data:{exb_lic_token:'FAUX',exb_user:'pirate',exb_test_liste:JSON.stringify([{id:"x');alert(1);//",nom:'<b>ok</b>',client_id:'a"b'},{__proto__:{p:1},constructor:'x'}])}};
      importCompleteBackup(new File([JSON.stringify(d)],'sauvegarde.json',{type:'application/json'}))}""")
    a.wait_for_timeout(500)
    r=a.evaluate("()=>({tok:exbStorage.getItem('exb_lic_token'),user:exbStorage.getItem('exb_user'),liste:exbStorage.getItem('exb_test_liste')})")
    ok(r['tok']!='FAUX' and r['user']!='pirate','import : clés de licence / identifiant refusées')
    ok(r['liste'] and 'alert(1)' not in r['liste'].replace('alert1','') and "');" not in r['liste'] and '"id":"xalert1//"' in r['liste'].replace('alert(1)','alert1').replace(';',''),'import : identifiants nettoyés (id, client_id)')
    ok('<b>ok</b>' in r['liste'],'import : les textes ordinaires ne sont pas modifiés (ils restent échappés à l\'affichage)')
    c=b.new_page(viewport={'width':390,'height':780}); ce=[]; c.on('pageerror',lambda e:ce.append(str(e)[:160]))
    c.goto(f'file://{ROOT}/calcul-structure/index.html'); c.wait_for_timeout(2000)
    for k in ['poteau','poutre','plancher','semelle','escalier']:
        c.evaluate(f"go('m:{k}')"); c.wait_for_timeout(900)
        h=c.evaluate("[...document.querySelectorAll('#inl h4')].length==3&&!!document.querySelector('#inl3d canvas')")
        ok(h,f'calcul {k} : vue 3D + note + plan affichés sur la page')
    for k in ['volume','coffrage','ferraillage','moment']:
        c.evaluate(f"go('m:{k}')"); c.wait_for_timeout(400)
        ok(c.evaluate("!!(document.querySelector('#res')||{}).innerText"),f'calcul {k} : résultat affiché')
    ok(not ce,'calculateur : aucune erreur JavaScript '+str(ce[:2]))
    b.close()
print('\nRésultat :','ÉCHEC' if fails else 'tout passe'); sys.exit(1 if fails else 0)
