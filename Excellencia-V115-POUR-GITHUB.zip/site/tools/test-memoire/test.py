# Test navigateur : mémoire du travail + alertes sonores. Depuis la racine : python3 tools/test-memoire/test.py
import threading, http.server, socketserver, functools, sys
from playwright.sync_api import sync_playwright
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',0),functools.partial(Q,directory='.')); PORT=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
ok=0; tot=0
def chk(n,c):
    global ok,tot; tot+=1; ok+=bool(c); print(('OK    ' if c else 'ECHEC ')+n)
INIT="""
window.__osc=0; window.__spoken=[];
const AC=window.AudioContext||window.webkitAudioContext;
if(AC){const co=AC.prototype.createOscillator;AC.prototype.createOscillator=function(){window.__osc++;return co.apply(this,arguments)}}
if(window.speechSynthesis){window.speechSynthesis.speak=function(u){window.__spoken.push(u.text)};window.speechSynthesis.cancel=function(){}}
setInterval(()=>{const d=document.getElementById('exbLicLock');if(d)d.remove()},150)
"""
answers=['TestLocal#2026']
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']); pg=b.new_page(viewport={'width':1300,'height':900}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    pg.add_init_script(INIT)
    pg.on('dialog',lambda d:d.accept(answers.pop(0) if (d.type=='prompt' and answers) else (d.default_value if d.type=='prompt' else None)))
    pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_function("window.EXBMEM&&window.EXBALERT&&window.EXBS",timeout=20000)
    pg.fill('#li_user','admin'); pg.fill('#li_pass','admin'); pg.click('text=Se connecter'); pg.wait_for_timeout(2500)
    pg.add_style_tag(content='#exbSplash,#toastBox{display:none!important}'); pg.wait_for_timeout(800)
    # ---- mémoire du travail ----
    pg.evaluate("show('bureauEtudes')"); pg.wait_for_timeout(500)
    pg.fill('#exb_be_project','Villa R+1 brouillon'); pg.fill('#exb_be_client','M. Mukendi'); pg.fill('#exb_be_note','note en cours')
    pg.evaluate("show('metreDevis')"); pg.wait_for_timeout(500); pg.evaluate("show('bureauEtudes')"); pg.wait_for_timeout(600)
    chk('retour sur l\'onglet : la saisie est là', pg.input_value('#exb_be_project')=='Villa R+1 brouillon')
    # simulation d'un onglet qui se redessine (champs remis à zéro) pendant l'absence
    pg.evaluate("show('metreDevis')"); pg.wait_for_timeout(300)
    pg.evaluate("['exb_be_project','exb_be_client','exb_be_note'].forEach(i=>{document.getElementById(i).value=''})")
    pg.evaluate("show('bureauEtudes')"); pg.wait_for_timeout(1700)
    chk('onglet redessiné : le travail est retrouvé (projet)', pg.input_value('#exb_be_project')=='Villa R+1 brouillon')
    chk('onglet redessiné : le travail est retrouvé (client + note)', pg.input_value('#exb_be_client')=='M. Mukendi' and pg.input_value('#exb_be_note')=='note en cours')
    # rechargement de la page
    pg.evaluate("EXBMEM.snapshot()"); pg.reload(); pg.wait_for_function("window.EXBMEM",timeout=20000); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbSplash,#toastBox{display:none!important}')
    chk('rechargement : la dernière page est rouverte', pg.evaluate("document.getElementById('bureauEtudes').style.display!=='none'"))
    pg.wait_for_timeout(1800)
    chk('rechargement : la saisie est retrouvée', pg.input_value('#exb_be_project')=='Villa R+1 brouillon')
    # enregistrement : plus de brouillon périmé
    pg.evaluate("saveExbStudy()"); pg.evaluate("clearExbStudyForm()"); pg.wait_for_timeout(1000)
    pg.evaluate("show('metreDevis')"); pg.wait_for_timeout(300); pg.evaluate("show('bureauEtudes')"); pg.wait_for_timeout(1700)
    chk('après enregistrement : pas de brouillon ressuscité', pg.input_value('#exb_be_project')=='')
    chk('mots de passe jamais mémorisés', 'li_pass' not in pg.evaluate("localStorage.getItem('exb_keep_v1')||''"))
    # désactivation
    pg.evaluate("localStorage.setItem('exb_mem_cfg',JSON.stringify({keep:false,reopen:false}))"); pg.fill('#exb_be_project','X'); pg.evaluate("EXBMEM.snapshot()")
    chk('option désactivée : rien n\'est mémorisé', 'exb_be_project' not in pg.evaluate("localStorage.getItem('exb_keep_v1')||''"))
    pg.evaluate("localStorage.removeItem('exb_mem_cfg')"); pg.evaluate("clearExbStudyForm()")
    # ---- alertes sonores ----
    pg.evaluate("show('settings')"); pg.wait_for_timeout(600)
    chk('panneau « Alertes sonores » dans Paramètres', pg.query_selector('#exbAlertPanel') is not None and pg.query_selector('#ea_on') is not None)
    chk('panneau « Mémoire du travail » dans Paramètres', pg.query_selector('#exbMemPanel') is not None)
    pg.evaluate("window.__osc=0;window.__spoken=[]")
    pg.evaluate("window.dispatchEvent(new CustomEvent('exb-inbox',{detail:{insc:1}}))"); pg.wait_for_timeout(2500)
    chk('alertes désactivées par défaut : silence', pg.evaluate("window.__osc")==0)
    pg.check('#ea_on'); pg.wait_for_timeout(2500)
    chk('activation : un son de contrôle est joué', pg.evaluate("window.__osc")>0)
    pg.evaluate("window.__osc=0;window.__spoken=[]")
    pg.evaluate("window.dispatchEvent(new CustomEvent('exb-inbox',{detail:{insc:2,tptd:0}}))"); pg.wait_for_timeout(3600)
    sp=pg.evaluate("window.__spoken.join(' | ')")
    chk('nouvelle demande : son joué', pg.evaluate("window.__osc")>0)
    chk('annonce vocale : « Vous avez reçu … importer … approuver » (%s)'%sp[:90], 'Vous avez reçu' in sp and 'approuver' in sp)
    chk('titre de l\'onglet : nombre de demandes en attente', pg.evaluate("document.title").startswith('(2)'))
    pg.evaluate("window.__osc=0;window.__spoken=[]")
    pg.evaluate("window.dispatchEvent(new CustomEvent('exb-inbox',{detail:{insc:2}}))"); pg.wait_for_timeout(2500)
    chk('même nombre de demandes : pas de nouvelle sonnerie', pg.evaluate("window.__osc")==0)
    pg.evaluate("window.dispatchEvent(new CustomEvent('exb-inbox',{detail:{insc:3,cli:1}}))"); pg.wait_for_timeout(3600)
    sp=pg.evaluate("window.__spoken.join(' | ')")
    chk('apprenant + client regroupés en une seule annonce (%s)'%sp[:110], 'inscription' in sp and 'client' in sp)
    pg.uncheck('[data-ea-kind=cli]'); pg.evaluate("window.__osc=0;window.__spoken=[]")
    pg.evaluate("window.dispatchEvent(new CustomEvent('exb-inbox',{detail:{insc:3,cli:2}}))"); pg.wait_for_timeout(2500)
    chk('type désactivé : pas d\'alerte', pg.evaluate("window.__osc")==0)
    pg.evaluate("window.dispatchEvent(new CustomEvent('exb-inbox',{detail:{insc:0,cli:0}}))"); pg.wait_for_timeout(300)
    chk('demandes traitées : compteur à zéro dans le titre', not pg.evaluate("/^\\(\\d+\\)/.test(document.title)"))
    chk('configuration enregistrée (son activé, type client coupé)', pg.evaluate("EXBALERT.cfg().on===true&&EXBALERT.cfg().kinds.cli===false"))
    pg.evaluate("EXBALERT.setCfg({on:false})")
    chk('aucune erreur JavaScript', not errs)
    if errs: print(errs[:3])
    b.close()
print('BILAN %d/%d'%(ok,tot)); sys.exit(0 if ok==tot else 1)
