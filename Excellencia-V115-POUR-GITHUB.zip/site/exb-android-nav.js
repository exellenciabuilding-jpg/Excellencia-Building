/* Excellencia Building — navigation Android : touche/geste « Retour », clavier, zones réservées du téléphone
 * Rôle : donner à la touche Retour (barre à 3 boutons OU geste Android) un comportement professionnel, dans cet ordre :
 *   1. écran de confirmation de sortie ouvert  → on reste dans l'application ;
 *   2. clavier affiché                          → on le masque ;
 *   3. menu des boutons flottants               → on le referme ;
 *   4. fenêtre / formulaire flottant ouvert     → on le ferme (la plus haute d'abord) ;
 *   5. menu latéral, menu profil, recherche     → on les replie ;
 *   6. sous-module / formulaire secondaire      → retour à l'écran ou au module précédent (historique du logiciel) ;
 *   7. écran principal                          → confirmation avant de quitter (jamais de fermeture brutale).
 * Actif dans l'application Android (plugin @capacitor/app) ; à défaut, dans une application web installée (PWA) ou un navigateur mobile,
 * le même comportement est obtenu avec l'historique du navigateur. Sur ordinateur, rien ne bloque le bouton Précédent du navigateur.
 * Ce fichier gère aussi : les zones réservées (barre d'état, barre de navigation, encoche) et les champs masqués par le clavier. */
(function (w, d) {
  'use strict';
  if (w.EXB_BACK) return;
  /* ce module remplace la navigation « historique » V98 (même rôle, mais sans fenêtres ni confirmation) */
  w.__exbNavV98 = true;

  var C = w.Capacitor, native = !!(C && C.isNativePlatform && C.isNativePlatform());
  var closers = [], leaving = false, exitDlg = null, baseH = 0, kbOpen = false;

  function $(id) { return d.getElementById(id); }
  function vis(el) { return !!el && el.isConnected && !el.hidden && el.style.display !== 'none' && w.getComputedStyle(el).display !== 'none'; }
  function isEditable(e) {
    if (!e || e === d.body) return false;
    var t = (e.tagName || '').toLowerCase();
    if (t === 'textarea' || t === 'select') return true;
    if (t === 'input') return !/^(button|submit|reset|checkbox|radio|range|color|file|image)$/i.test(e.type || 'text');
    return !!e.isContentEditable;
  }

  /* ---------- 1. zones réservées + clavier ---------- */
  function css() {
    if ($('exbAndroidNavCss')) return;
    var s = d.createElement('style'); s.id = 'exbAndroidNavCss';
    s.textContent =
      /* barre d'état (bas) et menu latéral : on ajoute les marges réservées du téléphone (valent 0 hors encoche / mode plein écran) */
      '@media screen{' +
      '#exbStatus{padding-bottom:calc(7px + env(safe-area-inset-bottom,0px))!important;padding-left:calc(16px + env(safe-area-inset-left,0px))!important;padding-right:calc(16px + env(safe-area-inset-right,0px))!important}' +
      '#exbSide{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}' +
      '#toastBox{bottom:calc(16px + env(safe-area-inset-bottom,0px))!important;right:calc(16px + env(safe-area-inset-right,0px))!important}' +
      'body{padding-left:env(safe-area-inset-left,0px);padding-right:env(safe-area-inset-right,0px)}' +
      '#app{padding-bottom:env(safe-area-inset-bottom,0px)}' +
      '}' +
      /* clavier ouvert : la barre d'état du bas ne mange plus la place et les fenêtres restent dans la zone visible */
      'html.exb-kb-open #exbStatus{display:none!important}' +
      'html.exb-kb-open #exbNudge,html.exb-kb-open #exbLicBar{display:none!important}' +
      '#exbExitDlg{position:fixed;inset:0;z-index:100050;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:18px;font:15px system-ui,Arial,sans-serif}' +
      '#exbExitDlg .bx{background:#fff;color:#172033;border-radius:16px;padding:20px;width:100%;max-width:340px;box-shadow:0 18px 50px #0007;text-align:center}' +
      '#exbExitDlg h3{margin:0 0 6px;color:#173565;font-size:18px}#exbExitDlg p{margin:0 0 16px;color:#52607a;line-height:1.45}' +
      '#exbExitDlg .r{display:flex;gap:10px}#exbExitDlg button{flex:1;min-height:46px;border:0;border-radius:12px;font:700 15px system-ui,Arial,sans-serif;cursor:pointer}' +
      '#exbExitDlg .stay{background:#173565;color:#fff}#exbExitDlg .quit{background:#e8edf5;color:#173565}' +
      '@media print{#exbExitDlg{display:none!important}}';
    d.head.appendChild(s);
  }
  function vvh() { return (w.visualViewport && w.visualViewport.height) || w.innerHeight; }
  function checkKeyboard() {
    var h = vvh();
    if (!baseH || h > baseH) baseH = h;
    var open = isEditable(d.activeElement) && (baseH - h) > 110;
    if (open !== kbOpen) { kbOpen = open; d.documentElement.classList.toggle('exb-kb-open', open); }
    return open;
  }
  /* un champ sélectionné ne doit jamais rester caché derrière le clavier ou une barre */
  function reveal() {
    var f = d.activeElement; if (!isEditable(f) || !f.getBoundingClientRect) return;
    var r = f.getBoundingClientRect(), H = vvh(), off = (w.visualViewport && w.visualViewport.offsetTop) || 0;
    if (r.bottom > off + H - 12 || r.top < off + 56) {
      try { f.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' }); } catch (e) { try { f.scrollIntoView(); } catch (e2) {} }
    }
  }
  function onKeyboardSignals() { checkKeyboard(); }
  function startKeyboard() {
    d.addEventListener('focusin', function (e) {
      if (!isEditable(e.target)) return;
      w.setTimeout(function () { checkKeyboard(); reveal(); }, 320);   /* l'animation du clavier dure ~250 ms */
      w.setTimeout(function () { checkKeyboard(); reveal(); }, 700);
    });
    d.addEventListener('focusout', function () { w.setTimeout(checkKeyboard, 150); });
    w.addEventListener('resize', onKeyboardSignals);
    w.addEventListener('orientationchange', function () { baseH = 0; w.setTimeout(checkKeyboard, 350); });
    if (w.visualViewport) { w.visualViewport.addEventListener('resize', function () { checkKeyboard(); if (kbOpen) reveal(); }); }
  }

  /* ---------- 2. fenêtres / formulaires flottants ---------- */
  var SKIP = /^(exbSplash|exbLicLock|exbLock|exbSide|exbStatus|exbWM|exbDim|toastBox|exbFabHub|exbFabMenu|exbFabTip|exbGuide|exbNudge|exbExitDlg|exbBurger|xbTop|exbCoreNotifications|exbLicBar|exbQuota|exbV97Badge|exbdb_chip|exbMfaBtn|exbHelpBtn|exbGenBtn|exbAIbtn|exbQuickActions)$/;
  var PANELS = /^(exbAI|exbV73Panel|exbCoreNotificationPanel|exbdb_panel|exbDiag|exbGenOv|exbBrandUI|exbViewer|exbSendBox|exbEqModal|exbOwnModal|exbV74Form|exbV74Panel|exbV76Lab|exbV76RecPanel|exbFin|exbFinF|exbArc|exbCart|exbPil|exbSec|xbModal|xbApPanel|exbMfaPanel)$/;
  function overlays() {
    var vw = w.innerWidth || 1, vh = w.innerHeight || 1, res = [], i = 0;
    Array.prototype.forEach.call(d.body.children, function (el) {
      i++;
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE' || el.tagName === 'LINK' || SKIP.test(el.id) || el.classList.contains('exb-fab')) return;
      var cs = w.getComputedStyle(el);
      if (cs.position !== 'fixed' || cs.display === 'none' || cs.visibility === 'hidden' || cs.pointerEvents === 'none' || +cs.opacity === 0) return;
      var r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return;
      var frac = (r.width * r.height) / (vw * vh), known = PANELS.test(el.id);
      if (frac < 0.3 && !known) return;
      res.push({ el: el, z: parseInt(cs.zIndex, 10) || 0, i: i });
    });
    res.sort(function (a, b) { return a.z - b.z || a.i - b.i; });
    return res;
  }
  var STRONG = /^(×|✕|✖|✗|x|❌|fermer|close|fermer la fenêtre)$/i, SOFT = /^(annuler|retour|terminé|termine|ok|non|plus tard|j[’']ai compris|compris)$/i;
  function labelOf(b) { return String(b.getAttribute('aria-label') || b.title || b.textContent || '').replace(/\s+/g, ' ').trim(); }
  function findCloser(el) {
    var btns = Array.prototype.slice.call(el.querySelectorAll('button,a[role=button],[role=button],[data-close],.close'));
    btns = btns.filter(function (b) { return b.offsetWidth > 0 && b.offsetHeight > 0 && !b.disabled; });
    var strong = btns.filter(function (b) { var t = labelOf(b); return STRONG.test(t) || /(^|\s)(fermer|close)(\s|$)/i.test(String(b.title || b.getAttribute('aria-label') || '')) || b.hasAttribute('data-close'); });
    if (strong.length) return strong[0];
    var soft = btns.filter(function (b) { return SOFT.test(labelOf(b)); });
    return soft.length ? soft[soft.length - 1] : null;
  }
  function interactive(el) { return !!el.querySelector('button,input,select,textarea,a[href],iframe,[role=button]'); }
  function closeOverlay(o) {
    var el = o.el, id = el.id;
    if (id === 'exbGenOv') { try { w.postMessage({ exbGen: 'close' }, location.origin); } catch (e) {} w.setTimeout(function () { if (el.isConnected && vis(el)) el.remove(); }, 120); return id; }
    if (id === 'xbModal' && w.EXB_SHELL && w.EXB_SHELL.closeModal) { w.EXB_SHELL.closeModal(); return id; }
    var b = findCloser(el);
    if (b) { b.click(); return id || 'overlay'; }
    if (!interactive(el)) return 'busy';       /* simple message d'attente : on n'y touche pas */
    /* sans bouton de fermeture : clic sur le fond (la plupart des fenêtres se ferment ainsi), puis retrait si rien ne s'est passé */
    try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); } catch (e) {}
    w.setTimeout(function () { if (el.isConnected && vis(el) && !el.id.match(/^(exbLicLock|exbLock)$/)) el.remove(); }, 160);
    return id || 'overlay';
  }

  /* ---------- 3. états de l'interface à replier ---------- */
  function collapseChrome() {
    var side = $('exbSide');
    if (side && side.classList.contains('on')) { side.classList.remove('on'); return 'menu'; }
    var pm = $('xbMenu');
    if (pm && pm.classList.contains('on')) { pm.classList.remove('on'); return 'profil'; }
    var sr = d.querySelector('#app>header .exb-pro-search.xopen');
    if (sr) { sr.classList.remove('xopen'); return 'recherche'; }
    return null;
  }
  function atHome() {
    var hm = $('exbHome');
    if (hm) return vis(hm);
    var dash = $('dashboard');
    return !dash || vis(dash);
  }
  var BACKLBL = /^(?:(?:←|⬅️?|◀|‹)\s*)?retour(?:\s+(?:à|au|aux)\s+.+)?$|^(?:←|⬅️?|◀|‹)\s*(?:liste|menu|accueil|tableau de bord|fiche|détails?|dossier|projets?|chantiers?|clients?|participants?)\b/i;
  function inlineBackButton() {
    var secs = Array.prototype.slice.call(d.querySelectorAll('#app section, #app .exb-sub, #app [data-exb-view]')).filter(function (s) { return vis(s) && s.offsetHeight > 0; });
    for (var i = secs.length - 1; i >= 0; i--) {
      var bs = secs[i].querySelectorAll('button,a[role=button]');
      for (var j = 0; j < bs.length; j++) {
        var b = bs[j];
        if (b.closest('#exbCrumb,#xbTop,#exbSide,#exbModBar,header,.tabs') || !b.offsetWidth || b.disabled) continue;
        var t = labelOf(b); if (t.length < 90 && BACKLBL.test(t)) return b;
      }
    }
    return null;
  }
  function navBack() {
    var xb = $('xbBack');
    if (w.EXB_SHELL && w.EXB_SHELL.back && xb && !xb.disabled) { w.EXB_SHELL.back(); return 'historique'; }
    if (typeof w.show === 'function') { w.show('dashboard'); return 'accueil'; }
    return null;
  }

  /* ---------- 4. confirmation de sortie ---------- */
  function closeExit() { if (exitDlg) { exitDlg.remove(); exitDlg = null; return true; } return false; }
  function quit() {
    leaving = true;
    var App = appPlugin();
    if (native && App && App.exitApp) { try { App.exitApp(); return; } catch (e) {} }
    try { w.history.go(-2); } catch (e) {}
    w.setTimeout(function () { try { w.close(); } catch (e) {} leaving = false; }, 400);
  }
  function askExit() {
    if (exitDlg) return;
    exitDlg = d.createElement('div'); exitDlg.id = 'exbExitDlg'; exitDlg.className = 'no-print'; exitDlg.setAttribute('role', 'alertdialog');
    exitDlg.innerHTML = '<div class="bx"><h3>Quitter l’application ?</h3><p>Vos données sont enregistrées. Appuyez sur Retour une nouvelle fois pour rester.</p>' +
      '<div class="r"><button type="button" class="stay">Rester</button><button type="button" class="quit">Quitter</button></div></div>';
    exitDlg.querySelector('.stay').onclick = closeExit;
    exitDlg.querySelector('.quit').onclick = function () { closeExit(); quit(); };
    exitDlg.addEventListener('click', function (e) { if (e.target === exitDlg) closeExit(); });
    d.body.appendChild(exitDlg);
    try { exitDlg.querySelector('.stay').focus({ preventScroll: true }); } catch (e) {}
  }

  /* ---------- 5. le cœur : une pression sur Retour ---------- */
  function handle() {
    var r, i;
    if (closeExit()) return 'reste';
    /* écrans qu'on ne ferme pas : connexion, licence, démarrage → on propose de quitter */
    var lock = $('exbLicLock'), lg = $('loginScreen'), sp = $('exbSplash');
    if ((sp && vis(sp)) || (lock && vis(lock)) || (lg && vis(lg) && lg.offsetParent !== null)) { askExit(); return 'quitter?'; }
    if (isEditable(d.activeElement)) {
      var wasOpen = checkKeyboard();
      try { d.activeElement.blur(); } catch (e) {}
      w.setTimeout(checkKeyboard, 120);
      if (wasOpen) return 'clavier';      /* clavier réellement affiché : cette pression sert uniquement à le masquer */
    }
    if (w.EXB_FAB && w.EXB_FAB.closeTop && w.EXB_FAB.closeTop()) return 'boutons';
    for (i = closers.length - 1; i >= 0; i--) { try { r = closers[i](); } catch (e) { r = false; } if (r) return typeof r === 'string' ? r : 'module'; }
    var ov = overlays();
    if (ov.length) return closeOverlay(ov[ov.length - 1]);
    r = collapseChrome(); if (r) return r;
    if (!atHome()) {
      var ib = inlineBackButton();
      if (ib) { ib.click(); return 'formulaire'; }
      r = navBack(); if (r) return r;
    }
    askExit(); return 'quitter?';
  }
  function press() {
    try { return handle(); } catch (e) { try { w.console.error('[exb-back]', e); } catch (e2) {} return 'erreur'; }
  }

  /* ---------- 6. branchement : application Android ou navigateur ---------- */
  var appObj = null;
  function appPlugin() {
    if (appObj !== null) return appObj || null;
    try { appObj = (C && C.Plugins && C.Plugins.App) || (C && C.registerPlugin && C.registerPlugin('App')) || false; } catch (e) { appObj = false; }
    return appObj || null;
  }
  var guardOn = false;
  function armGuard() {
    if (guardOn) return; guardOn = true;
    try { w.history.replaceState({ exbRoot: 1 }, ''); w.history.pushState({ exbGuard: 1 }, ''); } catch (e) { guardOn = false; return; }
    w.addEventListener('popstate', function (e) {
      if (leaving) return;
      var s = e.state;
      if (s && s.exbGuard) return;                          /* avance (clavier de PC) : rien à faire */
      press();
      try { w.history.pushState({ exbGuard: 1 }, ''); } catch (e2) {}
    });
  }
  function wantGuard() {
    try {
      var standalone = (w.matchMedia && (w.matchMedia('(display-mode: standalone)').matches || w.matchMedia('(display-mode: fullscreen)').matches)) || w.navigator.standalone;
      var coarse = w.matchMedia && w.matchMedia('(pointer: coarse)').matches;
      return !!(standalone || coarse || native);
    } catch (e) { return native; }
  }
  function attach() {
    var App = native ? appPlugin() : null;
    if (App && App.addListener) {
      try {
        var p = App.addListener('backButton', function () { press(); });
        if (p && p.catch) p.catch(function () { if (wantGuard()) armGuard(); });
        w.EXB_BACK.mode = 'android';
        return;
      } catch (e) {}
    }
    if (wantGuard()) { armGuard(); w.EXB_BACK.mode = 'historique'; } else { w.EXB_BACK.mode = 'aucun'; }
  }

  w.EXB_BACK = {
    press: press,
    /* un module peut déclarer sa propre fermeture : fn() renvoie true (ou un texte) s'il a fermé quelque chose */
    register: function (fn) { if (typeof fn === 'function' && closers.indexOf(fn) < 0) closers.push(fn); return function () { var k = closers.indexOf(fn); if (k >= 0) closers.splice(k, 1); }; },
    overlays: function () { return overlays().map(function (o) { return o.el.id || o.el.className || o.el.tagName; }); },
    mode: 'aucun'
  };

  function start() { css(); startKeyboard(); checkKeyboard(); attach(); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
