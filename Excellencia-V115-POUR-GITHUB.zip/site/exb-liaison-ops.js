/* Excellencia Building V99 — LIAISON, tranche 5 : complément des tranches 3 et 4 (uniquement ce qu'elles ne font pas).
 * - Affectations du personnel aux chantiers (chevauchement, statut, sessions de formation le même jour).
 * - Matériaux consommés par chantier (lit les mouvements de stock reliés par la tranche 3 : champ project_id).
 * - Même nom, clients différents : choisir le bon client PAR DOCUMENT, sans fusionner (la fusion reste celle de la tranche 4).
 * - Suivi par participant (présence, moyenne sur 20) et alerte « certificat délivré sans présence / sans note ».
 * - Suggestions de clients dans l'en-tête du Métré.
 * Principe inchangé : on ajoute, on ne supprime rien, on ne devine pas un lien ambigu. */
(function(w,d){'use strict';
function boot(){var X=w.EXBLIEN;if(!X||!X.extend){return setTimeout(boot,300)}
var norm=X.norm,esc=X.esc,num=X.num,r2=X.r2,fmt=X.fmt;
var K={hr:'exb_hr',moves:'exb_stock_moves',stock:'exb_stock',prj:'exb_projects',qt:'exb_quotes',st:'exb_studies',inv:'exb_invoices',cli:'exb_clients',par:'exb_participants',frm:'exb_formations',att:'exb_attendance',ev:'exb_evaluations',cot:'exb_cotations',sch:'exb_schedules',trn:'exb_trainers',cert:'exb_certificates'};

/* ---------- accès aux données : listes vivantes des écrans quand elles existent, sinon stockage ---------- */
function liveArr(k){try{switch(k){
 case 'exb_stock':return typeof exbStock!=='undefined'?exbStock:null;case 'exb_stock_moves':return typeof exbStockMoves!=='undefined'?exbStockMoves:null;
 case 'exb_attendance':return typeof attendance!=='undefined'?attendance:null;case 'exb_evaluations':return typeof evaluations!=='undefined'?evaluations:null;
 case 'exb_cotations':return typeof cotations!=='undefined'?cotations:null;case 'exb_schedules':return typeof schedules!=='undefined'?schedules:null}}catch(e){}return null}
function rd(k){var l=liveArr(k);if(Array.isArray(l))return l;return X.rd(k)}
function persist(k,list){var l=liveArr(k);try{if(typeof w.save==='function')w.save(k,Array.isArray(l)?l:list);else X.wr(k,list)}catch(e){}}
function byKey(list,k){var m={};list.forEach(function(x){if(x&&x[k]!=null)m[x[k]]=x});return m}
function byId(list){return byKey(list,'id')}
function today(){return new Date().toISOString().slice(0,10)}
function prjIndex(){var L=rd(K.prj);return{list:L,byId:byId(L)}}
function clientName(id){var c=byId(rd(K.cli))[id];return c?(c.full_name||c.company||c.id):''}

/* ---------- affectations du personnel (rangées dans la fiche : sauvegardées et synchronisées avec elle) ---------- */
function allAsg(){var out=[];rd(K.hr).forEach(function(h){(h.assignments||[]).forEach(function(a){out.push({a:a,h:h})})});return out}
function overlap(a,b){var a1=a.from||'0000',a2=a.to||'9999',b1=b.from||'0000',b2=b.to||'9999';return a1<=b2&&b1<=a2}
function asgConflicts(h,a){var msg=[],pi=prjIndex();(h.assignments||[]).forEach(function(o){if(o.id===a.id)return;if(overlap(o,a)){var p=pi.byId[o.project_id];msg.push(o.project_id===a.project_id?'déjà affecté à ce même chantier sur une période qui se recoupe':'déjà affecté à « '+(p?p.name:o.project_id)+' » sur une période qui se recoupe')}});
 if(/cong|suspen|sorti/i.test(String(h.status||'')))msg.push('statut actuel : '+h.status);
 var tid={};rd(K.trn).filter(function(t){return t.hr_id===h.id||norm(t.name)===norm(h.name)}).forEach(function(t){tid[t.trainer_id||t.id]=1;tid[t.id]=1});
 rd(K.sch).forEach(function(s){if(s.trainer_id&&tid[s.trainer_id]&&s.date&&s.date>=(a.from||'0000')&&s.date<=(a.to||'9999'))msg.push('session de formation « '+(s.training||'')+' » le '+s.date)});
 return msg}
function addAssignment(o){var hr=rd(K.hr),h=hr.filter(function(x){return x.id===o.hr_id})[0],p=prjIndex().byId[o.project_id];if(!h)throw Error('Personnel introuvable');if(!p)throw Error('Chantier introuvable');var from=o.from||today();if(o.to&&o.to<from)throw Error('La date de fin précède la date de début');
 var a={id:'ASG-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6),project_id:p.id,from:from,to:o.to||'',role:o.role||'',created_at:new Date().toISOString()};a.warn=asgConflicts(h,a);
 h.assignments=(h.assignments||[]).concat([a]);persist(K.hr,hr);X.log('affectation',{hr:h.id,project:p.id,from:from,to:a.to},(h.name||h.id)+' affecté(e) à « '+p.name+' »');return a}
function removeAssignment(hrId,aid){var hr=rd(K.hr),h=hr.filter(function(x){return x.id===hrId})[0];if(!h||!h.assignments)return false;var n=h.assignments.length;h.assignments=h.assignments.filter(function(a){return a.id!==aid});if(h.assignments.length!==n){persist(K.hr,hr);X.log('affectation_retiree',{hr:hrId,asg:aid},'Affectation retirée de '+(h.name||hrId));return true}return false}

/* ---------- matériaux consommés par chantier (lecture seule) + sorties restées sans chantier ---------- */
function stockByProject(){var items=byId(rd(K.stock)),pi=prjIndex(),m={},sans=[];rd(K.moves).forEach(function(v){if(!v.project_id){if(v.type==='out')sans.push(v);return}var p=m[v.project_id]=m[v.project_id]||{};var it=p[v.item]=p[v.item]||{out:0,back:0};if(v.type==='out')it.out+=num(v.qty);else it.back+=num(v.qty)});
 var rows=[];Object.keys(m).forEach(function(pid){Object.keys(m[pid]).forEach(function(iid){var it=items[iid]||{},x=m[pid][iid];rows.push({project:(pi.byId[pid]||{}).name||pid,item:it.name||iid,unit:it.unit||'',out:r2(x.out),back:r2(x.back),net:r2(x.out-x.back)})})});return{rows:rows,sans:sans}}

/* ---------- même nom, clients différents : choix par document (jamais de fusion ici) ---------- */
var REFS=[['projects',K.prj,'Projet',function(o){return o.name},function(o){return o.client}],['quotes',K.qt,'Devis',function(o){return o.no||o.id},function(o){return o.client}],['studies',K.st,'Étude',function(o){return o.title||o.name||o.id},function(o){return o.client}],['invoices',K.inv,'Facture',function(o){return o.no||o.id},function(o){return o.client}]];
function unresolvedRefs(){var out=[],act=rd(K.cli),cl=byId(act);REFS.forEach(function(r){rd(r[1]).forEach(function(o){if(o.client_id&&cl[o.client_id])return;var nm=r[4](o);if(!nm)return;var n=norm(nm),hit=act.filter(function(c){return [c.full_name,c.company,c.contact].map(norm).indexOf(n)>=0});if(hit.length>1)out.push({kind:r[0],label:r[2],rec:o,title:r[3](o),client:nm,cands:hit})})});return out}
function assignClient(kind,id,clientId){var r=REFS.filter(function(x){return x[0]===kind})[0];if(!r||!clientId||!byId(rd(K.cli))[clientId])return false;var L=rd(r[1]),o=L.filter(function(x){return x.id===id})[0];if(!o)return false;o.client_id=clientId;var nm=r[4](o);if(nm&&!o.client_snapshot)o.client_snapshot=nm;persist(r[1],L);X.log('client_choisi',{kind:kind,id:id,client:clientId},'Même nom, clients différents : '+r[2]+' rattaché à « '+clientName(clientId)+' »');return true}

/* ---------- suivi pédagogique par participant ---------- */
function pedago(){var par=rd(K.par),frm={},att=rd(K.att),ev=rd(K.ev),cot=rd(K.cot),P={},rows=[];rd(K.frm).forEach(function(f){frm[f.formation_id]=f});
 par.forEach(function(p){P[p.participant_id]={p:p,pres:0,tot:0,notes:[],cot:0}});
 att.forEach(function(a){var x=P[a.participant_id];if(!x)return;x.tot++;if(/pr[ée]sent|late|retard/i.test(String(a.status||'')))x.pres++});
 ev.forEach(function(e){var x=P[e.participant_id];if(!x)return;var pc=parseFloat(e.percent),sc=parseFloat(e.score),m=parseFloat(e.max);if(isFinite(pc))x.notes.push(pc/100*20);else if(isFinite(sc)&&m>0)x.notes.push(sc/m*20)});
 cot.forEach(function(c){var x=P[c.participant_id];if(x)x.cot++});
 Object.keys(P).forEach(function(id){var x=P[id],p=x.p,f=p.formation_id&&frm[p.formation_id];rows.push({id:id,name:p.name||id,formation:f?f.name:(p.training||''),presence:x.tot?Math.round(x.pres/x.tot*100):null,seances:x.tot,moyenne:x.notes.length?Math.round(x.notes.reduce(function(a,b){return a+b},0)/x.notes.length*10)/10:null,evals:x.notes.length,cotations:x.cot})});
 return rows}

/* ---------- points à vérifier (ajoutés à ceux des tranches précédentes) ---------- */
function anomalies(){var a=[],pi=prjIndex();
 var sb=stockByProject();if(sb.sans.length)a.push('Stock : '+sb.sans.length+' sortie(s) de matériaux sans chantier');
 allAsg().forEach(function(r){var p=pi.byId[r.a.project_id];if(!p)a.push('Affectation de '+(r.h.name||r.h.id)+' : chantier introuvable');else asgConflicts(r.h,r.a).filter(function(m){return /recoupe|session|statut/.test(m)}).forEach(function(m){a.push('Personnel « '+(r.h.name||r.h.id)+' » ('+p.name+') : '+m)})});
 var par=byKey(rd(K.par),'participant_id'),withNotes={},withPres={};rd(K.ev).forEach(function(e){withNotes[e.participant_id]=1});rd(K.att).forEach(function(e){withPres[e.participant_id]=1});
 rd(K.cert).forEach(function(c){if(c.participant_id&&par[c.participant_id]&&(!withNotes[c.participant_id]||!withPres[c.participant_id]))a.push('Certificat de « '+(c.participant_name||par[c.participant_id].name||c.participant_id)+' » délivré sans '+(!withPres[c.participant_id]?'présence enregistrée':'note d’examen'))});
 return a}

/* ---------- interface ---------- */
var CSS='.exbops select,.exbops input{max-width:100%}.exbops table{width:100%}.exbops .row{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:6px 0}.exbops .warn{color:#b45309}.exbops h3{margin:0 0 8px}.exbops small{opacity:.75}';
function mkCard(id,host){if(!host||d.getElementById(id))return d.getElementById(id);var c=d.createElement('div');c.className='card exbops';c.id=id;host.appendChild(c);return c}
function busy(el){var a=d.activeElement;return !!(el&&a&&el.contains(a)&&/^(SELECT|INPUT|TEXTAREA)$/.test(a.tagName))}
function projOpts(sel,blank){return '<option value="">'+esc(blank)+'</option>'+prjIndex().list.map(function(p){return '<option value="'+esc(p.id)+'"'+(p.id===sel?' selected':'')+'>'+esc(p.name||p.id)+'</option>'}).join('')}
function tbl(head,rows){return '<div style="overflow-x:auto"><table class="exb-table"><thead><tr>'+head.map(function(h){return '<th>'+h+'</th>'}).join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody></table></div>'}
function td(v,r){return '<td'+(r?' style="text-align:right"':'')+'>'+v+'</td>'}
function more(n,shown){return n>shown?'<p class="exb-muted"><small>+ '+(n-shown)+' autre(s) non affiché(s)</small></p>':''}

function renderStock(){var host=d.getElementById('exbOpsStock');if(!host||busy(host))return;var sb=stockByProject(),rows=sb.rows.slice(0,40).map(function(r){return '<tr>'+td(esc(r.project))+td(esc(r.item))+td(esc(r.unit))+td(fmt(r.out),1)+td(fmt(r.back),1)+td('<b>'+fmt(r.net)+'</b>',1)+'</tr>'});
 var sans=sb.sans.slice(0,12).map(function(v){var it=byId(rd(K.stock))[v.item]||{};return '<tr>'+td(esc(v.date||''))+td(esc(it.name||v.item_name||v.item))+td(fmt(num(v.qty)),1)+td(esc(v.ref||'—'))+td('<select data-mv="'+esc(v.id)+'">'+projOpts('','— Choisir —')+'</select> <button class="muted" data-ops="mv">Rattacher</button>')+'</tr>'});
 host.innerHTML='<h3>🔗 Matériaux consommés par chantier</h3>'+(rows.length?tbl(['Chantier','Matériau','Unité','Sorti','Retourné','Net consommé'],rows)+more(sb.rows.length,40):'<p class="exb-muted">Aucune sortie rattachée à un chantier pour le moment. Choisissez un chantier en enregistrant une sortie.</p>')+
 (sans.length?'<details style="margin-top:8px" open><summary class="warn">⚠ '+sb.sans.length+' sortie(s) sans chantier</summary>'+tbl(['Date','Matériau','Qté','Référence saisie','Chantier'],sans)+more(sb.sans.length,12)+'</details>':'')}
function renderHr(){var host=d.getElementById('exbOpsHr');if(!host||busy(host))return;var hr=rd(K.hr),pi=prjIndex(),A=allAsg().sort(function(x,y){return String(y.a.from).localeCompare(String(x.a.from))}).slice(0,40);
 var rows=A.map(function(r){var p=pi.byId[r.a.project_id],c=asgConflicts(r.h,r.a).filter(function(m){return /recoupe|session|statut/.test(m)});return '<tr>'+td(esc(r.h.name||r.h.id))+td(esc(p?p.name:'(chantier introuvable)'))+td(esc(r.a.from||'')+' → '+esc(r.a.to||'…'))+td(esc(r.a.role||''))+td(c.length?'<span class="warn" title="'+esc(c.join(' ; '))+'">⚠ '+c.length+'</span>':'✓')+td('<button class="muted" data-ops="unasg" data-hr="'+esc(r.h.id)+'" data-asg="'+esc(r.a.id)+'">Retirer</button>')+'</tr>'});
 host.innerHTML='<h3>🔗 Affectations aux chantiers</h3><div class="row"><select id="exbAsgHr"><option value="">— Personnel —</option>'+hr.map(function(h){return '<option value="'+esc(h.id)+'">'+esc(h.name||h.id)+(h.status&&h.status!=='Actif'?' ('+esc(h.status)+')':'')+'</option>'}).join('')+'</select><select id="exbAsgPrj">'+projOpts('','— Chantier —')+'</select></div><div class="row"><label>Du <input id="exbAsgFrom" type="date" value="'+today()+'"></label><label>Au <input id="exbAsgTo" type="date"></label><input id="exbAsgRole" placeholder="Rôle / tâche (facultatif)"><button class="primary" data-ops="asg">Affecter</button></div><div id="exbAsgMsg" class="exb-muted"></div>'+
 (rows.length?tbl(['Personnel','Chantier','Période','Rôle','Contrôle',''],rows)+more(allAsg().length,40):'<p class="exb-muted">Aucune affectation. Une affectation est signalée si la personne est déjà sur un autre chantier à la même période, en congé/suspendue/sortie, ou si elle donne une session de formation ces jours-là.</p>')}
function renderPedago(){var host=d.getElementById('exbOpsPedago');if(!host||busy(host))return;var all=pedago().sort(function(a,b){return String(a.formation).localeCompare(String(b.formation))||String(a.name).localeCompare(String(b.name))}),rows=all.slice(0,60).map(function(r){return '<tr>'+td(esc(r.name))+td(esc(r.formation))+td(r.presence==null?'—':r.presence+' % ('+r.seances+')',1)+td(r.moyenne==null?'—':r.moyenne+' / 20 ('+r.evals+')',1)+td(r.cotations,1)+'</tr>'});
 host.innerHTML='<h3>🔗 Suivi pédagogique par participant</h3>'+(rows.length?tbl(['Participant','Formation','Présence','Moyenne des évaluations','Cotations'],rows)+more(all.length,60):'<p class="exb-muted">Aucun participant.</p>')+'<p class="exb-muted"><small>Présence = séances marquées présent ou en retard / séances enregistrées. Moyenne ramenée sur 20.</small></p>'}
function renderResolver(){var host=d.getElementById('exbOpsClients');if(!host||busy(host))return;var U=unresolvedRefs();
 if(!U.length){host.style.display='none';host.innerHTML='';return}host.style.display='';
 var uh=U.slice(0,20).map(function(u){return '<tr>'+td(esc(u.label))+td(esc(u.title))+td(esc(u.client))+td('<select data-ref="'+esc(u.kind)+'" data-rid="'+esc(u.rec.id)+'"><option value="">— Quel client ? —</option>'+u.cands.map(function(c){return '<option value="'+esc(c.id)+'">'+esc(c.full_name||c.company||c.id)+' — '+esc([c.phone,c.email].filter(Boolean).join(' · ')||c.id)+'</option>'}).join('')+'</select> <button class="muted" data-ops="pick">Choisir</button>')+'</tr>'}).join('');
 host.innerHTML='<h3>🔗 Même nom, clients différents</h3><p class="exb-muted">Ces documents portent un nom partagé par plusieurs fiches clients. Aucun lien n’est deviné : indiquez le bon client pour chacun. (Si ce sont les mêmes personnes, utilisez plutôt « Garder celui-ci » dans les doublons ci-dessus.)</p>'+tbl(['Type','Document','Nom saisi','Client'],[uh])+more(U.length,20)}

function mountAll(){var st=d.getElementById('stock');if(st)mkCard('exbOpsStock',st);var hr=d.getElementById('rh');if(hr)mkCard('exbOpsHr',hr);var cl=d.getElementById('clients');if(cl)mkCard('exbOpsClients',cl);var pt=d.getElementById('participants');if(pt)mkCard('exbOpsPedago',pt);
 if(!d.getElementById('exbOpsCss')){var s=d.createElement('style');s.id='exbOpsCss';s.textContent=CSS;d.head.appendChild(s)}metreList()}
function metreList(){var inp=d.querySelector('#mb_panel input[data-h="client"]');if(!inp)return;var dl=d.getElementById('exbMetreClients');if(!dl){dl=d.createElement('datalist');dl.id='exbMetreClients';d.body.appendChild(dl)}
 var html=rd(K.cli).map(function(c){return '<option value="'+esc(c.full_name||c.company||'')+'"></option>'}).join('');if(dl.getAttribute('data-sig')!==html){dl.setAttribute('data-sig',html);dl.innerHTML=html}if(inp.getAttribute('list')!=='exbMetreClients')inp.setAttribute('list','exbMetreClients')}
function refreshOps(){try{mountAll();[renderStock,renderHr,renderPedago,renderResolver].forEach(function(f){try{f()}catch(e){}})}catch(e){}}

/* ---------- actions (délégation d'événements ; attribut data-ops pour ne pas entrer en collision avec data-act d'autres modules) ---------- */
function msg(el,t){if(el){el.textContent=t;el.style.color='#b91c1c'}}
function onClick(e){var b=e.target.closest&&e.target.closest('[data-ops]');if(!b)return;var act=b.getAttribute('data-ops'),row=b.closest('tr')||b.closest('.row')||b.parentNode;
 try{
  if(act==='mv'){var s=row.querySelector('select[data-mv]');if(!s||!s.value)return;var M=rd(K.moves),m=M.filter(function(x){return x.id===s.getAttribute('data-mv')})[0];if(m){m.project_id=s.value;persist(K.moves,M);X.log('stock_rattache',{move:m.id,project:s.value},'Sortie de stock rattachée à un chantier')}refreshOps()}
  else if(act==='asg'){var m2=d.getElementById('exbAsgMsg'),hid=(d.getElementById('exbAsgHr')||{}).value,pid=(d.getElementById('exbAsgPrj')||{}).value;if(!hid||!pid){msg(m2,'Choisissez une personne et un chantier.');return}
   var h=rd(K.hr).filter(function(z){return z.id===hid})[0],probe={id:'',project_id:pid,from:(d.getElementById('exbAsgFrom')||{}).value||today(),to:(d.getElementById('exbAsgTo')||{}).value||''},c=asgConflicts(h,probe);
   if(c.length&&typeof w.confirm==='function'&&!w.confirm('Attention pour '+(h.name||hid)+' :\n- '+c.join('\n- ')+'\n\nAffecter quand même ?'))return;
   addAssignment({hr_id:hid,project_id:pid,from:probe.from,to:probe.to,role:(d.getElementById('exbAsgRole')||{}).value||''});refreshOps()}
  else if(act==='unasg'){if(typeof w.confirm==='function'&&!w.confirm('Retirer cette affectation ?'))return;removeAssignment(b.getAttribute('data-hr'),b.getAttribute('data-asg'));refreshOps()}
  else if(act==='pick'){var s5=row.querySelector('select[data-ref]');if(!s5||!s5.value)return;assignClient(s5.getAttribute('data-ref'),s5.getAttribute('data-rid'),s5.value);refreshOps();try{X.refresh()}catch(er){}}
 }catch(err){try{if(typeof w.notify==='function')w.notify(String(err&&err.message||err),'warn');else alert(String(err&&err.message||err))}catch(e3){}}}

/* ---------- branchement ---------- */
X.extend({anomalies:function(){return anomalies()},html:function(){return''}});
d.addEventListener('click',onClick);
var tmr=0;try{new MutationObserver(function(){if(tmr)return;tmr=setTimeout(function(){tmr=0;try{metreList()}catch(e){}},400)}).observe(d.body,{childList:true,subtree:true})}catch(e){}
w.EXBOPS={version:'V99-LIAISON-5',stockByProject:stockByProject,addAssignment:addAssignment,removeAssignment:removeAssignment,assignmentConflicts:asgConflicts,pedago:pedago,anomalies:anomalies,unresolvedRefs:unresolvedRefs,assignClient:assignClient,refresh:refreshOps};
setTimeout(function(){refreshOps();setInterval(refreshOps,15000)},500)}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(boot,2000)});else setTimeout(boot,2000);
})(typeof window!=='undefined'?window:globalThis,typeof document!=='undefined'?document:{readyState:'complete',getElementById:function(){return null},addEventListener:function(){},querySelector:function(){return null}});
