EXCELLENCIA BUILDING V76 — COMPLÉMENTS (suite de l'audit V74)

INSTALLATION
1) Hébergez le dossier complet (le cache hors ligne passe à « exb-v76 »).
2) Supabase › SQL Editor : exécuter UNE fois supabase/migration-v76-droits-reception.sql
   (après migration-v75-droits-v69-v74.sql). Réexécutable sans danger.
3) Avant chaque livraison : ouvrir un terminal dans le dossier du site et lancer   node tools/check.js
   (72 contrôles : syntaxe, fichiers chargés, cache hors ligne, colonnes et collections SQL, comportement des modules).
   Un échec = ne pas livrer.

NOUVEAUTÉS
· 🏷 Étiquettes QR (Maintenance / Facility › « Étiquettes QR ») : une planche imprimable (ou PDF) avec un QR par équipement.
  Le QR contient un lien direct : en le scannant avec l'appareil photo du téléphone, l'application s'ouvre sur la fiche de l'équipement
  (interventions, garanties, inspections) avec le bouton « + Intervention sur cet équipement ».
  Générateur 100 % hors ligne (exb-qr.js). Si le lien dépasse 213 caractères, le QR contient seulement « EXB-ASSET:<code> ».
· 📅 Maintenance préventive récurrente : champ « Récurrence » sur les interventions (mensuelle, trimestrielle, semestrielle, annuelle).
  - Quand une intervention récurrente passe à « terminée », la suivante est créée automatiquement.
  - Bouton « Planifier 12 mois » : crée toutes les échéances à venir (sans doublon, relançable sans risque).
· 📷 Photos : jointes aux interventions (2 max) et, en saisie terrain hors ligne, au journal, HSE, RFI et réserves (3 max).
  Compression automatique (800 px, JPEG).
· 👷 Pointage hors ligne : la liste du personnel est mémorisée sur l'appareil (elle se met à jour à chaque ouverture en ligne).
· ⬇ Import du matériel de chantier : le bouton « Importer matériel (V68) » copie les fiches « Maintenance matériel » de Priorité 2 en interventions
  (une seule fois par fiche, sans doublon). Les deux modules restent distincts : V68 = engins de chantier, Facility = patrimoine livré.
· ✅ Réception de chantier (nouveau bouton) : réception provisoire/définitive, décision (sans réserve / avec réserves / refusée), délai de levée,
  personnes présentes, dossier des ouvrages exécutés (DOE : 6 pièces à cocher). Le tableau compte les réserves ouvertes du projet (module V67)
  et signale un délai dépassé. « 📄 PV » génère le procès-verbal PDF A4 : réserves ouvertes listées, photos des réserves, zones de signature.
  Droits par fonction (collection « receptions »), synchronisé par la base partagée.
· Contrôle automatique : tools/check.js.

LIMITES CONNUES
· Non testé dans un navigateur ni sur un Supabase réel. Seul le générateur QR a été vérifié par décodage (OpenCV, versions 1 à 10, 54 longueurs de texte).
  À contrôler sur le terrain : scan d'une étiquette imprimée, prise de photo mobile, impression de la planche et du PV.
· Le lien du QR contient l'adresse du site au moment de l'impression : si l'adresse change, réimprimer les étiquettes.
  Le lien ne s'ouvre que sur un appareil où l'utilisateur est connecté et dont les données sont synchronisées.
· Pas de scanner QR intégré à l'application : on utilise l'appareil photo du téléphone.
· Les photos sont stockées dans l'appareil (limite d'environ 5 Mo du navigateur) puis synchronisées : éviter de joindre beaucoup de photos hors ligne
  sans synchroniser régulièrement.
· La création automatique de l'échéance suivante se fait à la validation d'une intervention terminée (pas de tâche en arrière-plan) :
  utiliser « Planifier 12 mois » pour anticiper.
· Le PV reprend les réserves enregistrées dans « Projet 360° » (V67) : une réserve est considérée levée si son statut contient « Clôturée » ou « Levée ».
