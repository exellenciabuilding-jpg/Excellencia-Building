# V99zzzzzzzzzzzzzzzzzzzzzz — Éditeur de plan : interface « Excellencia Arch »

Fichiers modifiés : `plan-editeur/index.html` (balisage, styles, 1 script d'interface en fin de page, 1 ligne dans `draw()`), `sw.js` (version du cache). Le moteur (2D, 3D, coupes, charpente, métré, exports) n'est pas touché ; tous les boutons gardent leurs `id` et leurs gestionnaires.

- **Barre de titre** : EXCELLENCIA ARCH, badge « Projet BIM », nom du plan.
- **Menus** : Fichier (plans, import, export, métré) · Édition (sélection, historique, affichage) · Architecture (murs, ouvertures, pièces, mobilier, électricité, texte) · Structure (poteau, dalle de balcon, trémie, garde-corps, escaliers, toitures, axes) · Document (cotation, légende, cartouche, prix, quantités) · Vue 3D (3D, coupes / façades, visite).
- **Outils** (à gauche) : Sélection, Mur, Dalle, Porte, Fenêtre, Poteau, Poutre, Toiture, Escalier, Cotation + annuler / rétablir / supprimer.
- **Navigateur du projet** (bleu, bande dorée en bas) : Terrain · niveaux (RDC, ＋ Étage…) · Toiture · Coupes · Façades · 3D. Légende sous le plan : « Plan RDC », « Échelle ≈ 1:100 » (échelle d'écran indicative).
- Réglages détaillés (cartouche, cotation auto, prix, axes, fond de plan, quantités) : panneau de droite « Propriétés et réglages », ouvert par les menus.

Limites : **Poutre** grisée (absente du moteur). **Dalle** = dalle de balcon / terrasse (le plancher des étages se calcule seul). **Toiture** = tracer un toit (toit libre / auto : menu Structure). **Terrain** = vue 3D du dessus avec l'extérieur. Testé dans un navigateur (téléphone 390 px et ordinateur) ; non testé sur appareil réel.
