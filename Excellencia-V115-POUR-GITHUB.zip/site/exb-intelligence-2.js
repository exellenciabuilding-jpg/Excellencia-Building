/* EXCELLENCIA INTELLIGENCE — lot 2 : corrections guidées, annulation, documents automatiques.
 * Extension de exb-intelligence.js (à charger APRÈS lui). Rien n'est modifié sans confirmation ; chaque opération est inscrite au journal.
 *  • Doublons de stock : fusion (quantités additionnées, mouvements rattachés) — annulable depuis l'historique.
 *  • Factures de même numéro : renumérotation de la plus récente (prochain numéro libre) — annulable.
 *  • Clients en double : fusion via la fonction existante de la liaison (EXBLIEN.dup), après confirmation ; la fiche supprimée reste dans son journal.
 *  • Documents : relances prêtes à envoyer (toutes les factures en retard) et rapport de situation téléchargeable.
 * Pour retirer : supprimer la balise <script src="exb-intelligence-2.js"> de index.html. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot2) return; I.lot2 = true;
    var H = I.helpers, list = H.list, lab = H.lab, num = H.num, esc = H.esc, toast = H.toast, X = function () { return w.EXBLIEN; };
    function canW(c) { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can(c, 'ecrire'); } catch (e) { return true; } }
    function save(k, arr) { try { if (typeof exbSave === 'function') exbSave(k, arr); else if (typeof w.save === 'function') w.save(k, arr); else (w.exbStorage || w.localStorage).setItem(k, JSON.stringify(arr)); } catch (e) {} }
    function live(k) { try { if (k === 'exb_stock' && typeof exbStock !== 'undefined') return exbStock; if (k === 'exb_stock_moves' && typeof exbStockMoves !== 'undefined') return exbStockMoves; } catch (e) {} try { if (X() && X().rd) return X().rd(k); } catch (e) {} return list(k); }
    function refresh() { try { if (typeof renderExbStock === 'function') renderExbStock(); } catch (e) {} try { if (X() && X().refresh) X().refresh(); } catch (e) {} }

    /* ---- Stock : fusion de doublons ---- */
    function mergeStock(keepId, dupId) {
      if (!canW('stock')) { toast('Droits insuffisants pour modifier le stock.'); return Promise.resolve(); }
      var S = live('exb_stock'), M = live('exb_stock_moves'), keep = S.filter(function (s) { return s.id === keepId; })[0], dup = S.filter(function (s) { return s.id === dupId; })[0];
      if (!keep || !dup) { toast('Fiche introuvable : relancez le contrôle.'); return Promise.resolve(); }
      var moved = M.filter(function (m) { return m.item === dup.id; }).length, total = num(keep.qty) + num(dup.qty), unitNote = keep.unit && dup.unit && H.norm(keep.unit) !== H.norm(dup.unit) ? ' ATTENTION : unités différentes (' + keep.unit + ' / ' + dup.unit + ').' : '';
      return I.confirm('Fusionner ces deux fiches de stock ?', '« ' + lab(keep) + ' » (' + num(keep.qty) + ') + « ' + lab(dup) + ' » (' + num(dup.qty) + ') = ' + total + '. ' + moved + ' mouvement(s) seront rattachés à la fiche conservée.' + unitNote + ' Annulable depuis l’historique.', 'Fusionner').then(function (ok) {
        if (!ok) return;
        var before = JSON.stringify(keep), dupJson = JSON.stringify(dup), ids = [];
        keep.qty = total; keep.min = Math.max(num(keep.min), num(dup.min)); if (!keep.supplier && dup.supplier) keep.supplier = dup.supplier;
        M.forEach(function (m) { if (m.item === dup.id) { m.item = keep.id; ids.push(m.id); } });
        S.splice(S.indexOf(dup), 1); save('exb_stock', S); save('exb_stock_moves', M); refresh();
        I.log('fusion', 'Stock fusionné : « ' + lab(keep) + ' » (' + total + ')', { undo: { type: 'stock_merge', data: { keep: before, dup: dupJson, moved: ids } } });
        toast('Fiches de stock fusionnées.');
      });
    }
    I.registerUndo('stock_merge', function (data) {
      var S = live('exb_stock'), M = live('exb_stock_moves'), k = JSON.parse(data.keep), dp = JSON.parse(data.dup), i;
      for (i = 0; i < S.length; i++) if (S[i].id === k.id) { S[i] = k; break; }
      if (!S.some(function (s) { return s.id === dp.id; })) S.push(dp);
      M.forEach(function (m) { if (data.moved.indexOf(m.id) >= 0) m.item = dp.id; });
      save('exb_stock', S); save('exb_stock_moves', M); refresh();
    });
    I.addFixer('dup.stock', function (f) { return f.other ? { label: 'Fusionner…', run: function () { return mergeStock(f.other, f.ref.id); } } : null; });

    /* ---- Factures : numéro en double ---- */
    function invList() { return (X() && X().rd) ? X().rd('exb_invoices') : list('exb_invoices'); }
    function invSave(a) { try { if (X() && X().wr) X().wr('exb_invoices', a); else save('exb_invoices', a); } catch (e) {} try { if (w.EXBCH && w.EXBCH.render) w.EXBCH.render(); } catch (e) {} }
    function nextFree(no, all) {
      var m = /^(.*?)(\d+)$/.exec(String(no || '')); if (!m) return '';
      var max = 0; all.forEach(function (i) { var mm = /^(.*?)(\d+)$/.exec(String(i.no || '')); if (mm && mm[1] === m[1]) max = Math.max(max, parseInt(mm[2], 10)); });
      return m[1] + String(max + 1).padStart(m[2].length, '0');
    }
    function renumber(id) {
      if (!canW('budgets_chantier')) { toast('Droits insuffisants pour modifier une facture.'); return Promise.resolve(); }
      var A = invList(), inv = A.filter(function (i) { return i.id === id; })[0]; if (!inv) { toast('Facture introuvable : relancez le contrôle.'); return Promise.resolve(); }
      var nn = nextFree(inv.no, A); if (!nn) { toast('Numéro non standard : renumérotation impossible automatiquement.'); return Promise.resolve(); }
      var pay = (inv.payments || []).length;
      return I.confirm('Renuméroter cette facture ?', 'La facture du ' + (inv.date || '?') + (inv.client ? ' (' + inv.client + ')' : '') + ' passera de ' + inv.no + ' à ' + nn + '.' + (pay ? ' Elle a ' + pay + ' paiement(s) : ils restent rattachés.' : '') + ' Si elle a déjà été envoyée au client, prévenez-le. Annulable depuis l’historique.', 'Renuméroter').then(function (ok) {
        if (!ok) return; var old = inv.no; inv.no = nn; invSave(A);
        I.log('renumérotation', 'Facture ' + old + ' → ' + nn, { undo: { type: 'inv_renumber', data: { id: id, old: old } } }); toast('Facture renumérotée : ' + nn);
      });
    }
    I.registerUndo('inv_renumber', function (data) { var A = invList(); A.forEach(function (i) { if (i.id === data.id) i.no = data.old; }); invSave(A); });
    I.addFixer('dup.factures', function (f) { return { label: 'Renuméroter…', run: function () { return renumber(f.ref.id); } }; });

    /* ---- Clients : doublons (fusion existante de la liaison) ---- */
    I.addRule({ id: 'dup.clients', check: function () {
      var x = X(), out = []; if (!x || !x.dup || !x.dup.groups) return out;
      x.dup.groups().forEach(function (g) { out.push({ sev: 'alerte', mod: 'Clients', msg: 'Clients en double (' + g.raisons.join(', ') + ') : ' + g.clients.map(function (c) { return '« ' + lab(c) + ' »'; }).join(' · '), ref: { col: 'exb_clients', id: g.clients[0].id }, group: g.clients.map(function (c) { return c.id; }) }); });
      return out; } });
    I.addFilter(function (f) { return !(f.rule === 'liaison' && /^Clients en double possible/.test(f.msg) && X() && X().dup); });
    I.addFixer('dup.clients', function (f) {
      return { label: 'Fusionner…', run: function () {
        var x = X(), ids = f.group || [], use = ids.map(function (id) { return { id: id, n: x.dup.usage ? x.dup.usage(id) : 0 }; }), keep = use.slice().sort(function (a, b) { return b.n - a.n; })[0], names = {};
        list('exb_clients').forEach(function (c) { names[c.id] = lab(c); });
        return I.confirm('Fusionner ces fiches client ?', 'Conservée : « ' + names[keep.id] + ' » (' + keep.n + ' fiche(s) liée(s)). Fusionnées dedans : ' + use.filter(function (u) { return u.id !== keep.id; }).map(function (u) { return '« ' + names[u.id] + ' » (' + u.n + ')'; }).join(', ') + '. Devis, chantiers, factures et paiements sont déplacés ; la fiche supprimée est conservée dans le journal de la liaison.', 'Fusionner').then(function (ok) {
          if (!ok) return; try { var r = x.dup.merge(keep.id, ids.filter(function (i) { return i !== keep.id; })); I.log('fusion', 'Clients fusionnés dans « ' + names[keep.id] + ' » (' + (r && r.fiches_deplacees != null ? r.fiches_deplacees : '?') + ' fiche(s) déplacée(s))'); toast('Clients fusionnés.'); refresh(); } catch (e) { toast(e && e.message ? e.message : 'Fusion impossible.'); }
        });
      } };
    });

    /* ---- Documents automatiques ---- */
    function tot(i) { return I.calc.invoice(i); }
    function lateInvoices() { var t = H.today(); return list('exb_invoices').filter(function (i) { return i.due && i.due < t && tot(i).reste > 0.005 && !/annul/i.test(i.status || ''); }); }
    function relancesText() {
      var cl = list('exb_clients');
      return lateInvoices().map(function (i) {
        var c = cl.filter(function (x) { return H.norm(lab(x)) === H.norm(i.client); })[0], reste = tot(i).reste.toFixed(2) + ' ' + (i.currency || '');
        return 'Pour : ' + (i.client || 'Client') + (c && c.phone ? ' (' + c.phone + ')' : '') + '\nBonjour, sauf erreur de notre part, la facture ' + (i.no || '') + ' (reste à payer : ' + reste + ') était due le ' + i.due + '. Merci de nous indiquer la date de règlement. Cordialement, Excellencia Building.';
      }).join('\n\n— — —\n\n');
    }
    function situationHtml() {
      var cur = {}, inv = list('exb_invoices'), t = H.today();
      inv.forEach(function (i) { var c = i.currency || '—', x = tot(i); cur[c] = cur[c] || { f: 0, p: 0 }; cur[c].f += x.ttc; cur[c].p += x.paid; });
      var rows = Object.keys(cur).map(function (c) { return '<tr><td>' + esc(c) + '</td><td align="right">' + cur[c].f.toFixed(2) + '</td><td align="right">' + cur[c].p.toFixed(2) + '</td><td align="right"><b>' + (cur[c].f - cur[c].p).toFixed(2) + '</b></td></tr>'; }).join('');
      var late = lateInvoices().map(function (i) { return '<tr><td>' + esc(i.no) + '</td><td>' + esc(i.client || '') + '</td><td>' + esc(i.due) + '</td><td align="right">' + tot(i).reste.toFixed(2) + ' ' + esc(i.currency || '') + '</td></tr>'; }).join('');
      var low = list('exb_stock').filter(function (s) { return num(s.min) > 0 && num(s.qty) <= num(s.min); }).map(function (s) { return '<li>' + esc(lab(s)) + ' : ' + num(s.qty) + ' / ' + num(s.min) + '</li>'; }).join('');
      var s = I.summary();
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Situation</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Situation — Excellencia Building</h1><p>' + t + ' · ' + list('exb_clients').length + ' client(s) · ' + list('exb_projects').length + ' projet(s) · ' + inv.length + ' facture(s)</p>' +
        '<h2>Facturation (TTC)</h2><table border="1" cellpadding="6" style="border-collapse:collapse"><tr><th>Devise</th><th>Facturé</th><th>Encaissé</th><th>Reste</th></tr>' + (rows || '<tr><td colspan="4">Aucune facture</td></tr>') + '</table>' +
        '<h2>Factures en retard</h2><table border="1" cellpadding="6" style="border-collapse:collapse"><tr><th>N°</th><th>Client</th><th>Échéance</th><th>Reste</th></tr>' + (late || '<tr><td colspan="4">Aucune</td></tr>') + '</table>' +
        '<h2>Stock à réapprovisionner</h2><ul>' + (low || '<li>Rien à signaler</li>') + '</ul><h2>Contrôle des données</h2><p>' + s.erreur + ' erreur(s), ' + s.alerte + ' alerte(s), ' + s.info + ' information(s).</p></body></html>';
    }
    function download(name, html) { try { var b = new Blob([html], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); I.log('document', 'Document produit : ' + name); } catch (e) { toast('Export impossible.'); } }
    I.docs = { relances: relancesText, situation: situationHtml };
    I.addReco(function () {
      var r = [], n = lateInvoices().length;
      if (n) r.push({ ic: '✉️', t: 'Relances prêtes pour ' + n + ' facture(s)', x: 'Un message par client, avec numéro, reste à payer et échéance.', acts: [{ l: 'Copier toutes les relances', f: function () { if (H.copy(relancesText())) { I.log('document', 'Relances copiées (' + n + ')'); toast(n + ' relance(s) copiée(s).'); } else toast('Copie impossible.'); } }] });
      r.push({ ic: '📄', t: 'Rapport de situation', x: 'Facturation, retards, stock et contrôle des données dans un seul document.', acts: [{ l: 'Télécharger le rapport', f: function () { download('situation-' + H.today() + '.html', situationHtml()); } }] });
      return r;
    });
    I.run();
  }
  boot(0);
})(window, document);
