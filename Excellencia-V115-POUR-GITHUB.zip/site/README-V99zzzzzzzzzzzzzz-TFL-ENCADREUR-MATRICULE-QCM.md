# V99zzzzzzzzzzzzzz — Encadreur, matricule automatique, suivi, attestation complète, QCM TP/TD

## Ce qui change
1. **Formulaire encadreur** (`tfl-encadreur-formulaire.html`, lien court `/tfl-encadreur-formulaire`) : fiche + jusqu'à 3 sujets (titre, problématique, objectifs, méthodologie). En ligne ou fichier hors ligne. Admin : TFL › Encadreurs › « Formulaire encadreur, matricule et sujets proposés » (lien, WhatsApp, fichier, réception, décisions).
2. **Matricule automatique dès la soumission**
   - En ligne : le serveur donne le matricule immédiatement (étudiant qui propose son sujet, encadreur) et l'affiche à l'écran.
   - Hors ligne : le matricule est attribué automatiquement à l'**import** du fichier (plus aucun clic) ; il faut le communiquer à la personne.
   - Un matricule déjà donné par le serveur est conservé à l'import ; s'il est déjà pris localement, un nouveau est créé et signalé.
3. **Suivi par matricule** (`tfl-statut.html`, lien court `/tfl-statut`) : matricule + téléphone → statut de chaque sujet : Reçu, En vérification, Retenu/Accepté, Refusé (avec motif), Complément demandé. Les décisions sont publiées seules quand l'administrateur est connecté ; sinon bouton « Publier les statuts ».
4. **Sujets d'encadreurs** : proposés en « Reçu », non publiés ; « Retenir » les met au catalogue. Un encadreur venu par formulaire doit être **validé** avant affectation.
5. **Validation du sujet par l'encadreur** : champ « Encadreur pressenti » dans le formulaire étudiant ; dans le portail encadreur, boutons Valider / À corriger / Refuser (+ observations) ; l'administration clique « Appliquer » dans le dossier. L'étudiant voit le résultat.
6. **Attestation de dépôt PDF** : page d'annexe avec titre, problématique, objectifs, méthodologie et recherches déjà faites (autant de pages que nécessaire).
7. **QCM à côté de TP/TD** : bloc « 🧠 QCM » dans le générateur TP/TD (`exb-tp-qcm.js`). Questions tirées de la banque avec bonnes réponses ; épreuve **en ligne** corrigée automatiquement (10 questions tirées au hasard par apprenant) ; à domicile = fenêtre d'ouverture/clôture + durée. Les réponses sont retirées du fichier hors ligne et de la fiche papier ; le fichier hors ligne ne corrige pas les QCM.

## Déploiement
1. Déployer le ZIP. 2. Exécuter `supabase/migration-v99zzzzzzzzzzzzzz-tfl-matricule-suivi.sql` (n° 11 de `ORDRE-D-EXECUTION.md`, après le n° 10). 3. Ouvrir l'application une fois en ligne pour renouveler le cache.
Sans le SQL : tout fonctionne en mode fichier ; l'envoi en ligne des formulaires, le suivi par matricule et la validation côté portail affichent « service non activé ».

## Tests
`node tools/test-tfl/test.js` (encadreur, matricule, décisions, validation, statuts) et `node tools/check.js`.
