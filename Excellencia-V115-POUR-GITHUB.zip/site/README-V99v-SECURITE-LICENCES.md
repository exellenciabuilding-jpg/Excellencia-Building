## V99v (suite) — Sécurité des données sensibles et espace propriétaire
Fichiers : `supabase/migration-v99v-securite-licences.sql` (nouveau), `exb-proprietaire.js` (nouveau), `exb-license.js` (expose `make`), `exb-v99r-shell.js` (menu), `index.html`, `sw.js`.

### Ordre de mise en service
1. Supabase : faire une sauvegarde, puis exécuter `migration-v99v-securite-licences.sql` (SQL Editor › Run).
2. Vous déclarer propriétaire (remplacer l'e-mail) :
   `insert into plateforme_proprietaires(user_id) select id from auth.users where email='votre@email.com';`
3. Donner aux membres concernés leur fonction (rh, comptable, direction) : `update membres set fonction='comptable' where user_id='…' and org_id='…';`
   Les membres « polyvalent » n'ont plus accès aux employés, contrats, paies et comptes bancaires (l'administrateur garde tout).
4. Déployer les fichiers, ouvrir l'application sur l'appareil qui détient la clé de licence : Paramètres › « 👑 Espace propriétaire ».
5. Cliquer « Sauvegarder la clé (chiffrée) » et conserver le fichier en 2 endroits + le mot de passe à part.

### Limites connues
- Suspension : empêche de rejoindre l'entreprise ; les appareils déjà activés restent valables jusqu'à l'échéance de leur code (licence signée hors connexion).
- Le script SQL n'a pas été exécuté sur votre serveur par l'auteur : tester d'abord sur une copie.
