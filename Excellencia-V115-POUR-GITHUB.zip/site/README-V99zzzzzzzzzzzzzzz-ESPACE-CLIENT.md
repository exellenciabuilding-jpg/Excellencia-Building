# Espace client avec compte (matricule + mot de passe)

## Ce que voit le client
Page `/espace-client` (`espace-client.html`) : matricule + mot de passe. Puis son espace (`portail.html`, mode compte) :
projet et avancement, **calendrier** (début / fin prévue), **activité récente**, photos, journal, devis / factures / paiements avec reste à payer, **documents à valider (signature)**, messages avec l'entreprise, bouton « Se déconnecter ».
Le lien + code à 6 chiffres existant reste valable (clients occasionnels) : les deux accès coexistent.

## Comment l'entreprise crée le compte
Clients & CRM › 🔗 Portails & signatures › sur un portail client : **🔐 Compte client**. Saisir le matricule du client (pré-rempli avec le numéro de sa fiche) ; le message WhatsApp prêt à envoyer donne l'adresse, l'identifiant et le mot de passe provisoire. Refaire la même action **réinitialise** le compte (mot de passe remis au matricule, sessions coupées).

## Mot de passe par défaut = matricule
- Mot de passe provisoire = matricule, comme demandé. Un matricule se devine facilement : **le changement est donc obligatoire à la première connexion** (8 caractères minimum, différent du matricule). Tant qu'il n'est pas changé, aucun contenu n'est accessible.
- Mots de passe hachés (bcrypt) ; 5 essais ratés = blocage 15 minutes ; session aléatoire de 12 h stockée hachée ; message d'erreur identique si le matricule n'existe pas ; aucun accès direct aux tables.
- Le client voit **uniquement** le portail relié à son compte (pas d'autre dossier).

## Limite à connaître
L'espace montre le dernier **instantané publié** par l'entreprise (comme le portail actuel) : après un avancement, cliquer « ↻ Mettre à jour » sur le portail. Ce n'est pas encore une lecture en direct de toutes les données.

## Installation
1. Déployer le zip. 2. Supabase › SQL Editor : exécuter `supabase/migration-v99zzzzzzzzzzzzzzz-espace-client.sql` (après `migration-v99zy-portails.sql`). 3. Ouvrir l'application deux fois (cache).

## Tests
`tools/test-rls/run.sh` (27 contrôles « ESPACE CLIENT » : mot de passe par défaut, changement obligatoire, blocage, isolation entre organisations, révocation) ; `python3 tools/e2e-espace-client.py` (connexion, changement, espace, déconnexion, navigateur simulé) ; `node tools/check.js`.

## Plans envoyés au client (nouveau plan / plan modifié)
- Portail client › **📐 Envoyer un plan** : choisir un PDF ou une image (6 Mo maximum ; exporter un plan DXF / IFC / DWG en PDF), un titre et une note. **Même titre = nouvelle version**, signalée « Modifié » au client ; les anciennes versions restent visibles (« remplacée »).
- Le client est **informé** : message WhatsApp prêt à envoyer, message de l'entreprise dans sa messagerie, bandeau « 🔔 plan nouveau ou modifié » à l'ouverture de son espace, rubrique « 📐 Plans » avec bouton Ouvrir.
- **📋 Plans envoyés** : l'entreprise voit pour chaque plan « Vu le … » ou « Pas encore ouvert ».
- Installation : exécuter `supabase/migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql` (après la migration de l'espace client). Tests : `tools/test-rls/run.sh` (16 contrôles « PLANS CLIENT »).
- Limite : les fichiers sont stockés dans la base (pas dans le stockage de fichiers) pour que le client y accède sans service supplémentaire ; d'où la limite de 6 Mo.

## Accès à l'espace client (visible pour le client)
- **Après sa demande** (formulaires client et demande BTP) : l'écran de confirmation affiche « 🔐 Votre espace client » avec le bouton « Accéder à mon espace client », et rappelle que l'espace est activé par l'entreprise (identifiant = matricule, mot de passe provisoire = matricule, à changer à la première connexion).
- **Sur le site vitrine** : bouton « 🔐 Espace client » dans la barre du haut et près de « Déposer ma demande » (l'adresse suit automatiquement celle du logiciel configurée).
