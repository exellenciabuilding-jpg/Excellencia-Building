/* Excellencia Building V99x — CONNEXION PAR EMPREINTE DIGITALE / VISAGE (déverrouillage de l'appareil).
 * Fonctionnement : le téléphone ou l'ordinateur vérifie lui-même l'empreinte ou le visage (WebAuthn, authentificateur de la plateforme).
 * L'application ne voit, ne lit et ne stocke JAMAIS l'empreinte ni le visage : elle reçoit seulement « vérifié » ou « refusé ».
 * - Activation : menu du profil › « Connexion par empreinte / visage » (après une connexion normale).
 * - Écran de connexion : bouton « Se connecter avec l'empreinte / le visage » (affiché seulement si activé sur CET appareil).
 * - Le mot de passe reste toujours disponible comme secours. Désactivation possible à tout moment (même menu).
 * - Limites : fonctionne en HTTPS (ou localhost) et si une empreinte/un visage est déjà enregistré dans les réglages de l'appareil.
 *   Propre à chaque appareil ; vider les données du navigateur l'efface. Cela remplace la SAISIE du mot de passe local sur cet appareil ;
 *   cela ne remplace pas le compte en ligne ni ses droits côté serveur. */
(function(w,d){'use strict';
var KEY='exb_bio';
var $=function(i){return d.getElementById(i)};
function ls(k,v){try{if(v===undefined)return w.localStorage.getItem(k);if(v===null)w.localStorage.removeItem(k);else w.localStorage.setItem(k,v)}catch(e){return null}}
function b64(u){var s='';u=new Uint8Array(u);for(var i=0;i<u.length;i++)s+=String.fromCharCode(u[i]);return btoa(s)}
function unb64(s){var b=atob(s),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
function rnd(n){return w.crypto.getRandomValues(new Uint8Array(n))}
function cfg(){try{return JSON.parse(ls(KEY)||'null')}catch(e){return null}}

/* Application Android installée : le WebView ne gère pas WebAuthn, on utilise l'empreinte / le visage du système via le plugin natif BiometricAuth. */
var nat=undefined;
/* Windows (application Electron) : l'empreinte / le visage / le code PIN de Windows Hello sont demandés par le programme (preload) ; WebAuthn est refusé sur l'adresse interne app://. */
function deskBio(){var D=w.exbDesktop;if(!(D&&D.hello&&D.helloAvailable))return false;
 return{desktop:true,
  checkBiometry:async function(){return{isAvailable:!!(await D.helloAvailable())}},
  authenticate:async function(o){var r=await D.hello(o&&o.reason||'Excellencia Building');
   if(r&&r.ok)return;var e=new Error(r&&r.msg||'Vérification refusée');e.code=(r&&r.code)||'userCancel';throw e}}}
function nativeBio(){if(nat!==undefined)return nat;var C=w.Capacitor;nat=false;
 try{if(C&&C.isNativePlatform&&C.isNativePlatform())nat=(C.Plugins&&(C.Plugins.BiometricAuthNative||C.Plugins.BiometricAuth))||(C.registerPlugin&&C.registerPlugin('BiometricAuthNative'))||false}catch(e){nat=false}
 if(!nat)nat=deskBio();
 return nat}
async function nativeOk(){var N=nativeBio();if(!N)return false;try{var r=await N.checkBiometry();return !!(r&&r.isAvailable)}catch(e){return false}}
/* Le plugin Capacitor n'expose côté natif que « internalAuthenticate » : « authenticate » n'existe que dans l'enveloppe JavaScript du paquet (absente ici) → on appelle l'une ou l'autre. */
async function nativeAsk(why){var N=nativeBio(),o={reason:why,cancelTitle:'Annuler',allowDeviceCredential:false,androidTitle:'Excellencia Building',androidSubtitle:why,androidConfirmationRequired:false};
 if(typeof N.authenticate==='function')return N.authenticate(o);
 if(typeof N.internalAuthenticate==='function')return N.internalAuthenticate(o);
 throw new Error('module d’empreinte indisponible dans cette version de l’application')}
function nativeErr(e){var c=String(e&&(e.code||e.message)||'');
 if(/userCancel|systemCancel|appCancel|cancel/i.test(c))return 'Vérification annulée.';
 if(/biometryNotEnrolled|notEnrolled/i.test(c))return nat&&nat.desktop?'Windows Hello n’est pas configuré : Paramètres › Comptes › Options de connexion.':'Aucune empreinte / aucun visage enregistré : ajoutez-en un dans les réglages du téléphone (Sécurité).';
 if(/lockout/i.test(c))return 'Trop d’essais : patientez ou déverrouillez l’appareil avec son code.';
 return 'Échec de la vérification : '+(e&&e.message||c)}
var supported=null;
async function isSupported(){if(supported!==null)return supported;
 if(nativeBio()){supported=await nativeOk();return supported}
 try{supported=!!(w.isSecureContext&&w.PublicKeyCredential&&navigator.credentials&&await w.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())}catch(e){supported=false}return supported}

function errMsg(e){var n=e&&e.name||'';
 if(n==='NotAllowedError')return 'Vérification annulée ou refusée.';
 if(n==='InvalidStateError')return 'Cet appareil est déjà enregistré.';
 if(n==='SecurityError')return 'Non disponible sur cette adresse (HTTPS requis).';
 if(n==='NotSupportedError')return 'Cet appareil ne gère pas l’empreinte / le visage pour les sites web.';
 return 'Échec de la vérification : '+(e&&e.message||e)}

/* ---------- activer / désactiver ---------- */
async function enable(){
 if(!await isSupported())return alert('Empreinte / visage indisponible ici.\n'+(nativeBio()?(nativeBio().desktop?'Windows Hello n’est pas disponible ou pas configuré sur cet ordinateur.\\nConfigurez-le dans Paramètres › Comptes › Options de connexion (empreinte, visage ou code PIN), puis réessayez.':'Aucune empreinte ni aucun visage n’est enregistré sur ce téléphone, ou le capteur est indisponible.\\nAjoutez-en un dans Réglages › Sécurité, puis réessayez.'):'Il faut : une adresse sécurisée (HTTPS) et une empreinte ou un visage déjà enregistré dans les réglages de l’appareil.'));
 var user=''; try{user=(w.exbStorage&&JSON.parse(w.exbStorage.getItem('exb_user')))||'admin'}catch(e){user='admin'}
 if(!confirm('Activer la connexion par empreinte / visage sur cet appareil ?\n\nLe mot de passe restera disponible en secours. Votre empreinte ou votre visage ne quitte jamais l’appareil.'))return;
 if(nativeBio()){try{await nativeAsk('Activer la connexion par empreinte / visage');ls(KEY,JSON.stringify({native:1,user:String(user),at:new Date().toISOString()}));alert('✓ Connexion par empreinte / visage activée sur cet appareil.');refresh()}catch(e){alert(nativeErr(e))}return}
 try{
  var cred=await navigator.credentials.create({publicKey:{
   rp:{name:'Excellencia Building',id:location.hostname},
   user:{id:rnd(16),name:String(user)||'admin',displayName:'Excellencia Building — '+(String(user)||'admin')},
   challenge:rnd(32),pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],
   authenticatorSelection:{authenticatorAttachment:'platform',userVerification:'required',residentKey:'discouraged'},
   timeout:60000,attestation:'none'}});
  if(!cred)throw new Error('aucune réponse');
  ls(KEY,JSON.stringify({id:b64(cred.rawId),user:String(user),at:new Date().toISOString(),host:location.hostname}));
  alert('✓ Connexion par empreinte / visage activée sur cet appareil.');refresh()}
 catch(e){alert(errMsg(e))}}
function disable(){if(!confirm('Désactiver la connexion par empreinte / visage sur cet appareil ?\nLe mot de passe continue de fonctionner.'))return;ls(KEY,null);alert('Désactivé.');refresh()}

/* ---------- connexion ---------- */
async function unlock(){var c=cfg(),msg=$('li_msg');
 if(!c){return}
 if(c.native&&nativeBio()){try{await nativeAsk('Se connecter');if(typeof w.exbFinishLogin!=='function'){if(msg)msg.textContent='Connexion par empreinte indisponible dans cette version : utilisez le mot de passe.';return}if(msg)msg.textContent='';w.exbFinishLogin()}catch(e){if(msg)msg.textContent=nativeErr(e)+' Vous pouvez utiliser le mot de passe.'}return}
 if(c.native)return;
 if(c.host&&c.host!==location.hostname){if(msg)msg.textContent='Cette activation appartient à une autre adresse : utilisez le mot de passe.';return}
 try{
  var a=await navigator.credentials.get({publicKey:{challenge:rnd(32),rpId:location.hostname,
   allowCredentials:[{type:'public-key',id:unb64(c.id),transports:['internal']}],userVerification:'required',timeout:60000}});
  if(!a)throw new Error('aucune réponse');
  if(typeof w.exbFinishLogin!=='function'){if(msg)msg.textContent='Connexion par empreinte indisponible dans cette version : utilisez le mot de passe.';return}
  if(msg)msg.textContent='';w.exbFinishLogin()}
 catch(e){if(msg)msg.textContent=errMsg(e)+' Vous pouvez utiliser le mot de passe.'}}

/* ---------- interface ---------- */
async function loginButton(){var box=d.querySelector('#loginScreen .loginbox');if(!box)return;
 var ex=$('exbBioBtn'),on=!!cfg()&&await isSupported();
 if(!on){if(ex)ex.remove();return}
 if(ex)return;
 var anchor=box.querySelector('button.primary[onclick*="doLogin"]');if(!anchor)return;
 var b=d.createElement('button');b.id='exbBioBtn';b.type='button';b.className='muted';b.style.cssText='width:100%;margin-top:8px;padding:11px 12px;font-weight:700;border-radius:9px';
 b.textContent='🔐 Se connecter avec l’empreinte / le visage';b.onclick=unlock;anchor.insertAdjacentElement('afterend',b)}
function menuItem(){var m=$('xbMenu');if(!m)return;
 var b=$('xbBio');if(!b){b=d.createElement('button');b.id='xbBio';b.type='button';b.onclick=function(e){e.stopPropagation();if(cfg())disable();else enable()};m.insertBefore(b,m.lastElementChild)}
 b.textContent=cfg()?'🔐 Empreinte / visage : activé (désactiver)':'🔐 Activer l’empreinte / le visage'}
function refresh(){loginButton();menuItem()}
function start(){refresh();setInterval(refresh,1500)}
w.EXB_BIO={enable:enable,disable:disable,unlock:unlock,enabled:function(){return !!cfg()},supported:isSupported,version:'V99x'};
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',start);else start();
})(window,document);
