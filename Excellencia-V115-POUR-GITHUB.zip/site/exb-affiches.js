/* Excellencia Building — affiches : les textes modifiables s'adaptent à leur zone (la police se réduit si le texte est plus long que l'original). */
(function(){'use strict';
function fit(el){
 var keep=['justify-content','align-items'].map(function(k){return[k,el.style.getPropertyValue(k),el.style.getPropertyPriority(k)]});
 el.style.fontSize='';
 keep.forEach(function(k){el.style.setProperty(k[0],'flex-start','important')});
 var fs=parseFloat(getComputedStyle(el).fontSize)||16,min=fs*.45,n=0;
 while(fs>min&&n++<90&&(el.scrollWidth>el.clientWidth+1||el.scrollHeight>el.clientHeight+1)){fs-=Math.max(.5,fs*.03);el.style.fontSize=fs.toFixed(1)+'px'}
 keep.forEach(function(k){if(k[1])el.style.setProperty(k[0],k[1],k[2]);else el.style.removeProperty(k[0])})}
function all(){document.querySelectorAll('#posterPaper,.softwarePosterPaper').forEach(function(p){if(!p.offsetWidth)return;p.querySelectorAll('.pchip,.sp-overlay').forEach(fit)})}
var t=0;window.exbFitPosters=function(){clearTimeout(t);t=setTimeout(all,30)};
function watch(){if(!window.ResizeObserver)return;var ro=new ResizeObserver(function(){window.exbFitPosters()});document.querySelectorAll('#posterPaper,.softwarePosterPaper').forEach(function(p){ro.observe(p)})}
if(document.readyState!=='loading'){watch()}else document.addEventListener('DOMContentLoaded',watch);
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){window.exbFitPosters()});
window.addEventListener('load',function(){window.exbFitPosters()});
})();
