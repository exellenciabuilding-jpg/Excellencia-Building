# V99zq — Planning de chantier : dépendances, marges, chemin critique (audit interne P1)

Fichiers : `exb-cpm.js` (nouveau, moteur), `exb-planning.js`, `index.html` (1 balise), `sw.js` (cache `exb-v99zq-planning-1`), `exb-v99r-shell.js` (menu, version), `tools/test-cpm.js` et `tools/e2e-smoke.py`.

## Correctif important : le module « Planning & budget » n'était pas accessible
Sa section utilisait l'identifiant `planning`, déjà pris par le planning de **Formation** : le module ne se montait jamais et aucune entrée de menu n'y menait. Il utilise maintenant `plangantt` et apparaît dans **Projets & Chantiers › Planning & budget** (Gantt hebdomadaire + budget de construction en 26 postes).

## Nouveautés du Gantt
- **Préd.** : prédécesseurs de chaque tâche, ex. `1, 3+1, 5-1` = après la tâche 1 ; après la 3 avec 1 semaine de décalage ; après la 5 avec 1 semaine de chevauchement.
- **Marge (sem.)** et **chemin critique** (tâches 🔴, barres rouges) : toute marge nulle = un retard retarde la fin du chantier.
- **Retard prévisionnel du projet** : recalcule la fin à partir de l'avancement réel et de la semaine en cours (une tâche non terminée ne peut pas se terminer dans le passé ; ses successeurs sont décalés). Exige la date de la semaine 1.
- Contrôles : dépendances circulaires, prédécesseurs invalides, début saisi antérieur à la fin des prédécesseurs (⚠).
- Boutons : **Enchaîner** (chaque tâche sans lien suit la précédente), **Recaler selon les liens** (débuts au plus tôt). Le « Début » saisi reste une contrainte « pas avant ». La suppression d'une tâche renumérote les liens.
- Unité : la semaine ; liens fin → début uniquement.
## Tests
`node tools/test-cpm.js` (réseaux dessinés à la main : chemin critique, marges, décalages, cycle, retard) ; parcours navigateur dans `tools/e2e-smoke.py`. `node tools/check.js` : 274 contrôles.
## Non fait
Ressources et charge, planning en jours, import MS Project / Excel, lignes de base enregistrées, liens début → début / fin → fin.
