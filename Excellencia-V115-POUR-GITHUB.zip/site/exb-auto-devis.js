/* Excellencia Building — Devis automatique depuis un plan (V99 « axe 1 »).
 * Un seul geste pour passer d'un fichier de plan à un devis chiffré à vérifier :
 *   • maquette IFC / IFCZIP : lecture par le lecteur 3D (exb-ifc3d.js), quantités par niveau et catégorie, prix de départ, écran de contrôle ;
 *   • plan PDF / image : convertisseur existant (échelle + détection des murs), puis bouton « 💰 Devis direct » qui chiffre le plan converti
 *     avec le même calcul et les mêmes prix que l'éditeur de plan (EXBPLANEDIT.lines) ;
 *   • dans les deux cas : écran de contrôle (cases, quantités et prix modifiables, alertes) AVANT l'envoi dans « Matériaux ajoutés » du métré.
 * Rien n'est envoyé au client automatiquement : toutes les quantités sont indicatives et à contrôler avant chiffrage.
 * Pour retirer le module : supprimer la balise <script src="exb-auto-devis.js"> de index.html. */
(function (root) {
  'use strict';

  /* Prix de départ en dollars : mêmes valeurs que l'éditeur de plan (plan-editeur/index.html, tableau PRIX). Indicatifs, à ajuster. */
  var PRIX_DEFAUT = { maco: 14, enduit: 7, dalle: 38, porte: 75, fenetre: 95, toit_tuile: 32 };
  var PORTE_M2 = 0.9 * 2.1, FEN_M2 = 1.2 * 1.2; /* dimensions courantes supposées (IFC : seul le nombre est repris) */
  var LS_PU = 'exb_autodevis_pu';

  function r2(n) { return Math.round(n * 100) / 100; }
  function r3(n) { return Math.round(n * 1000) / 1000; }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
  function fmt(n, k) { return (Number(n) || 0).toLocaleString('fr-FR', { maximumFractionDigits: k == null ? 2 : k }); }
  function validStorey(s) { return !!s && s !== '—'; }

  /* ---------- prix mémorisés par l'utilisateur (dernier prix validé pour chaque poste) ---------- */
  function loadPu() { try { return JSON.parse(root.localStorage.getItem(LS_PU) || '{}') || {}; } catch (e) { return {}; } }
  function savePu(o) { try { root.localStorage.setItem(LS_PU, JSON.stringify(o)); } catch (e) { } }

  /* ---------- IFC : lignes de devis à partir des quantités (EXB_IFC3D.quantities) ----------
     rows : lignes de quantities(model) — { cat, storey, vol, aire, plan, lg, ouvertures, src }.
     Retourne { lines, warnings, skipped } ; chaque ligne : { k, d, u, q, pu ('' = à saisir), pk, src, hyp }. */
  function ifcLignes(rows, title, prix) {
    var P = Object.assign({}, PRIX_DEFAUT, prix || {}), warnings = [], skipped = Object.create(null), groups = Object.create(null), order = [];
    title = title || 'maquette';
    (rows || []).forEach(function (r) {
      var key = r.cat + '\u0001' + r.storey, g = groups[key];
      if (!g) { g = groups[key] = { cat: r.cat, storey: r.storey, n: 0, vol: 0, aire: 0, plan: 0, face: 0 }; order.push(key); }
      g.n++; g.vol += r.vol || 0; g.aire += r.aire || 0; g.plan += r.plan || 0;
      /* face d'un mur = (surface totale − dessus et dessous) / 2 : retire les chants du haut et du bas, garde l'estimation prudente */
      g.face += Math.max(0, ((r.aire || 0) - 2 * (r.plan || 0)) / 2);
    });
    var CATS = ['Fondations', 'Poteaux', 'Poutres', 'Dalles', 'Murs', 'Escaliers', 'Portes', 'Fenêtres', 'Toitures'], stOrder = [];
    order.forEach(function (key) { var s = groups[key].storey; if (stOrder.indexOf(s) < 0) stOrder.push(s); });
    order.sort(function (a, b) { var ga = groups[a], gb = groups[b], d1 = stOrder.indexOf(ga.storey) - stOrder.indexOf(gb.storey); if (d1) return d1; var ia = CATS.indexOf(ga.cat), ib = CATS.indexOf(gb.cat); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib); });
    var lines = [], nCorr = rows ? rows.filter(function (r) { return /corrigée/.test(r.src || ''); }).length : 0;
    function suffix(g) { return (validStorey(g.storey) ? ' — ' + g.storey : '') + ' (maquette IFC ' + title + ')'; }
    function add(g, k, d, u, q, pk, pu, hyp) {
      q = r3(q); if (!(q > 0)) return;
      lines.push({ k: k, d: d + suffix(g), u: u, q: q, pu: pu == null ? '' : pu, pk: pk || k, src: 'autoifc:' + title + ':' + g.cat + ':' + g.storey + ':' + k, hyp: hyp || '' });
    }
    order.forEach(function (key) {
      var g = groups[key];
      switch (g.cat) {
        case 'Murs':
          add(g, 'murs-m2', 'Maçonnerie — murs, surface nette 1 face', 'm²', g.face, 'maco', P.maco, 'surface estimée sur la géométrie, chants et retours d’ouverture inclus : peut dépasser le réel de quelques %');
          add(g, 'murs-enduit', 'Enduit / peinture murs (2 faces)', 'm²', 2 * g.face, 'enduit', P.enduit, 'surface estimée sur la géométrie, chants et retours d’ouverture inclus : peut dépasser le réel de quelques %');
          break;
        case 'Dalles': add(g, 'dalle', 'Dalle / plancher béton armé', 'm²', g.plan, 'dalle', P.dalle); break;
        case 'Poteaux': add(g, 'poteaux', 'Poteaux béton armé (volume)', 'm³', g.vol, 'ba_poteaux', ''); break;
        case 'Poutres': add(g, 'poutres', 'Poutres béton armé (volume)', 'm³', g.vol, 'ba_poutres', ''); break;
        case 'Fondations': add(g, 'fondations', 'Fondations béton armé (volume)', 'm³', g.vol, 'ba_fond', ''); break;
        case 'Escaliers': add(g, 'escaliers', 'Escaliers (volume)', 'm³', g.vol, 'escaliers', ''); break;
        case 'Portes': add(g, 'portes', 'Portes (' + g.n + ' u, standard 0,90 × 2,10 m supposé)', 'u', g.n, 'porte', r2(P.porte * PORTE_M2), 'dimensions supposées'); break;
        case 'Fenêtres': add(g, 'fenetres', 'Fenêtres (' + g.n + ' u, standard 1,20 × 1,20 m supposé)', 'u', g.n, 'fenetre', r2(P.fenetre * FEN_M2), 'dimensions supposées'); break;
        case 'Toitures': add(g, 'toiture', 'Toiture — surface en plan (hors pente et débord)', 'm²', g.plan, 'toit_tuile', P.toit_tuile, 'surface en plan'); break;
        default: skipped[g.cat] = (skipped[g.cat] || 0) + g.n;
      }
    });
    var sk = Object.keys(skipped).map(function (c) { return { cat: c, n: skipped[c] }; });
    if (!rows || !rows.length) warnings.push('Aucun élément quantifiable dans ce fichier : rien à chiffrer.');
    if (sk.length) warnings.push('Non chiffrés (aucune règle de prix) : ' + sk.map(function (s) { return s.cat + ' (' + s.n + ')'; }).join(', ') + '. Ajoutez-les à la main dans le métré si nécessaire.');
    if (nCorr) warnings.push(nCorr + ' élément(s) avec une unité corrigée automatiquement (mm → m) : vérifiez les quantités.');
    if (lines.some(function (l) { return l.pu === ''; })) warnings.push('Postes sans prix de départ (béton armé, escaliers…) : saisissez le prix unitaire avant d’envoyer le devis.');
    if (lines.some(function (l) { return l.hyp; })) warnings.push('Surfaces de murs, dimensions de portes / fenêtres et surface de toiture sont des estimations (voir « Hypothèse » sous chaque désignation).');
    return { lines: lines, warnings: warnings, skipped: sk };
  }

  /* ---------- plan converti (PDF / image) : lignes de l'éditeur de plan ---------- */
  function planLignes(L) {
    return (L || []).filter(function (l) { return l && !l.info && l.q > 0; }).map(function (l) {
      return { k: l.src, d: l.d, u: l.u, q: r3(l.q), pu: l.pu > 0 ? l.pu : '', pk: l.pk || '', src: l.src, hyp: '' };
    });
  }
  function planResult(L, ctx) {
    var lines = planLignes(L), w = [];
    if (!lines.length) w.push('Aucune quantité calculée : le plan ne contient pas de murs détectés. Ouvrez-le dans l’éditeur pour le compléter.');
    w.push('Plan issu d’une détection automatique sur un PDF : murs, ouvertures et échelle sont à vérifier dans l’éditeur de plan avant tout chiffrage. Les pièces, sols, toiture et équipements ne sont pas détectés.');
    if (lines.some(function (l) { return l.pu === ''; })) w.push('Certains postes n’ont pas de prix de départ : saisissez-les avant d’envoyer le devis.');
    return { lines: lines, warnings: w, skipped: [], ctx: ctx };
  }

  var api = { ifcLignes: ifcLignes, planLignes: planLignes, PRIX_DEFAUT: PRIX_DEFAUT, version: 'V99-axe1' };
  if (typeof document === 'undefined') { if (typeof module !== 'undefined') module.exports = api; return; }

  /* =================== interface =================== */
  var d = root.document, OV = null;
  function $(i) { return d.getElementById(i); }
  function close() { if (OV) { OV.remove(); OV = null; } }
  function css() {
    if ($('exbAdCss')) return; var s = d.createElement('style'); s.id = 'exbAdCss';
    s.textContent = '#exbAd{position:fixed;inset:0;z-index:2147482000;background:rgba(15,23,42,.72);display:flex;align-items:center;justify-content:center;padding:10px;font:14px system-ui,sans-serif}'
      + '#exbAd .box{background:#fff;color:#172033;border-radius:14px;max-width:1000px;width:100%;max-height:94vh;display:flex;flex-direction:column;box-shadow:0 20px 60px #0007}'
      + '#exbAd .hd{padding:12px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #e2e8f0}#exbAd .hd b{flex:1;font-size:16px}'
      + '#exbAd .bd{overflow:auto;padding:12px 16px}#exbAd .ft{padding:10px 16px;border-top:1px solid #e2e8f0;display:flex;gap:8px;align-items:center;flex-wrap:wrap}'
      + '#exbAd button{padding:8px 14px;border:0;border-radius:8px;font-weight:600;cursor:pointer;background:#eef2f7;color:#172033}#exbAd button.ok{background:#15803d;color:#fff}#exbAd button.pr{background:#0f4aa8;color:#fff}'
      + '#exbAd .ln{border-top:1px solid #e2e8f0;padding:8px 4px}#exbAd .ln.np{background:#fffbeb}#exbAd .ln.off{opacity:.45}#exbAd .l1{display:flex;gap:8px;align-items:center}#exbAd .l1 input[type=checkbox]{width:20px;height:20px;flex:none}'
      + '#exbAd .l2{display:flex;gap:6px 10px;align-items:center;flex-wrap:wrap;margin-top:6px;padding-left:28px;font-size:12.5px}#exbAd .l2 label{display:flex;gap:5px;align-items:center;white-space:nowrap;font-weight:400;margin:0}#exbAd .l2 .mm{margin-left:auto}#exbAd input.qq{width:90px}'
      + '#exbAd input.n{width:84px;padding:6px 4px;border:1px solid #cbd5e1;border-radius:6px;text-align:right}#exbAd input.t{flex:1;min-width:0;padding:7px;font-size:13px;border:1px solid #cbd5e1;border-radius:6px}#exbAd .ln .mu{padding-left:28px;margin-top:3px}'
      + '#exbAd .w{background:#fff7ed;border:1px solid #fdba74;color:#7c2d12;border-radius:8px;padding:8px 10px;margin:6px 0;font-size:12.5px}'
      + '#exbAd .dz{border:2px dashed #94a3b8;border-radius:12px;padding:26px 14px;text-align:center;color:#475569}#exbAd .mu{color:#64748b;font-size:12px}'
      + '#exbAd tr.np td{background:#fffbeb}#exbAd .tot{font-weight:700;font-size:15px;margin-left:auto}';
    d.head.appendChild(s);
  }
  function shell(title, body, foot) {
    css(); close(); OV = d.createElement('div'); OV.id = 'exbAd'; OV.setAttribute('role', 'dialog'); OV.setAttribute('aria-modal', 'true');
    OV.innerHTML = '<div class="box"><div class="hd"><b>' + esc(title) + '</b><button id="adX" type="button">Fermer</button></div><div class="bd">' + body + '</div>' + (foot ? '<div class="ft">' + foot + '</div>' : '') + '</div>';
    d.body.appendChild(OV); OV.querySelector('#adX').onclick = close; return OV;
  }
  function busy(msg) { shell('🤖 Devis automatique', '<p class="dz">' + esc(msg) + '</p>'); }
  function fail(msg) { shell('🤖 Devis automatique', '<div class="w">' + esc(msg) + '</div>'); }

  /* écran de départ : choix du fichier */
  function open() {
    var o = shell('🤖 Devis automatique',
      '<p>Choisissez un plan : le logiciel calcule les quantités, propose des prix de départ et prépare le devis. <b>Vous contrôlez tout avant l’envoi.</b></p>'
      + '<div class="dz"><b>Maquette IFC</b> (.ifc, .ifczip) → devis en un geste<br><input type="file" id="adIfc" accept=".ifc,.ifczip,.zip" style="margin-top:10px"></div>'
      + '<div class="dz" style="margin-top:10px"><b>Plan PDF ou image</b> → conversion guidée (échelle + détection des murs), puis « 💰 Devis direct »<br><button id="adPdf" class="pr" type="button" style="margin-top:10px">📄 Ouvrir le convertisseur de plan PDF</button></div>'
      + '<p class="mu">Les quantités sont indicatives. Un PDF n’a pas de géométrie fiable : l’échelle et les murs détectés doivent être vérifiés.</p>');
    o.querySelector('#adIfc').onchange = function () { if (this.files[0]) fromIfcFile(this.files[0]); };
    o.querySelector('#adPdf').onclick = function () { close(); var P = root.EXBIMPPDF; if (P && P.open) P.open(); else alert('Le convertisseur de plan PDF n’est pas disponible dans cette page.'); };
  }

  /* dernier prix validé pour chaque poste : IFC → par type de poste ; plan → seulement pour les postes sans prix de départ */
  function memKey(l, ctx) { return (ctx && ctx.source === 'plan' ? 'plan:' + (l.pk || l.k) : 'ifc:' + l.k); }
  function applyMem(res, onlyEmpty) {
    var mem = loadPu(); res.lines.forEach(function (l) { var m = mem[memKey(l, res.ctx)]; if (m > 0 && (!onlyEmpty || l.pu === '')) l.pu = m; });
  }

  /* IFC → quantités → écran de contrôle */
  function fromIfcFile(file) {
    var I = root.EXB_IFC3D;
    if (!I || !I.parse || !I.quantities) { fail('Le lecteur IFC n’est pas disponible dans cette page.'); return Promise.resolve(); }
    if (file.size > 120 * 1048576) { fail('Fichier trop volumineux (120 Mo maximum).'); return Promise.resolve(); }
    busy('Lecture de « ' + file.name + ' »…');
    return file.arrayBuffer().then(function (buf) { return I.ifcTextOf(buf, file.name); })
      .then(function (txt) { return I.parse(txt); })
      .then(function (model) {
        var title = file.name.replace(/\.[^.]+$/, ''), res = ifcLignes(I.quantities(model), title);
        res.ctx = { title: title, project: title, source: 'ifc' }; applyMem(res); review(res);
      })
      .catch(function (e) { fail('Lecture impossible : ' + (e && e.message ? e.message : e)); });
  }

  /* plan converti → éditeur masqué (même calcul et mêmes prix que le bouton « Envoyer au métré » de l'éditeur) → écran de contrôle */
  function fromPlan(plan) {
    busy('Calcul des quantités du plan…');
    return new Promise(function (ok, ko) {
      try { root.localStorage.setItem('exbPlanEd.handoff', JSON.stringify(plan)); } catch (e) { ko(new Error('Plan trop volumineux pour être transmis : ouvrez-le dans l’éditeur puis « ➕ Envoyer au métré ».')); return; }
      var f = d.createElement('iframe'), t0 = Date.now(), done = false;
      f.setAttribute('aria-hidden', 'true'); f.tabIndex = -1; f.style.cssText = 'position:fixed;left:-9999px;top:0;width:1100px;height:800px;border:0;visibility:hidden';
      function end(err, L) { if (done) return; done = true; try { f.remove(); } catch (e) { } if (err) ko(err); else ok(L); }
      f.onload = function () {
        (function wait() {
          if (done) return; var w = f.contentWindow, A = w && w.EXBPLANEDIT, pending = true;
          try { pending = w.localStorage.getItem('exbPlanEd.handoff') !== null; } catch (e) { pending = false; }
          if (A && A.lines && !pending) { try { end(null, A.lines()); } catch (e) { end(e); } }
          else if (Date.now() - t0 > 20000) end(new Error('L’éditeur de plan n’a pas répondu.'));
          else setTimeout(wait, 200);
        })();
      };
      f.src = 'plan-editeur/index.html?auto=' + Date.now(); d.body.appendChild(f);
    }).then(function (L) {
      var res = planResult(L, { title: (plan && plan.name) || 'Plan importé', project: (plan && plan.name) || '', source: 'plan' });
      applyMem(res, true); review(res);
    }).catch(function (e) { fail(e && e.message ? e.message : String(e)); });
  }

  /* écran de contrôle : cases, quantités, unités et prix modifiables */
  function review(res) {
    var L = res.lines.map(function (l) { return Object.assign({ on: true }, l); });
    var h = '';
    res.warnings.forEach(function (w) { h += '<div class="w">⚠ ' + esc(w) + '</div>'; });
    if (!L.length) { shell('🤖 Devis automatique — contrôle', h || '<p>Rien à chiffrer.</p>'); return; }
    h += '<p class="mu">Décochez ce que vous ne voulez pas chiffrer, corrigez quantités et prix. Fond jaune : prix à saisir.</p><div id="adL">';
    L.forEach(function (l, i) {
      h += '<div class="ln' + (l.pu === '' ? ' np' : '') + '" data-i="' + i + '"><div class="l1"><input type="checkbox" class="on" checked aria-label="Inclure cette ligne"><input class="t dd" aria-label="Désignation" value="' + esc(l.d) + '"></div>'
        + (l.hyp ? '<div class="mu">Hypothèse : ' + esc(l.hyp) + '</div>' : '')
        + '<div class="l2"><label>Qté <input class="n qq" type="number" step="any" inputmode="decimal" value="' + l.q + '"> ' + esc(l.u) + '</label><label>PU ($) <input class="n pp" type="number" step="any" inputmode="decimal" value="' + (l.pu === '' ? '' : l.pu) + '" placeholder="à saisir"></label><b class="mm"></b></div></div>';
    });
    h += '</div>';
    var o = shell('🤖 Devis automatique — contrôle (' + (res.ctx ? res.ctx.title : '') + ')', h,
      '<button id="adOk" class="ok" type="button">✅ Créer le devis dans le métré</button><span class="mu" id="adNote"></span><span class="tot" id="adTot"></span>');
    function recalc() {
      var tot = 0, np = 0;
      [].forEach.call(o.querySelectorAll('.ln'), function (tr) {
        var l = L[+tr.dataset.i]; l.on = tr.querySelector('.on').checked; l.d = tr.querySelector('.dd').value;
        l.q = parseFloat(tr.querySelector('.qq').value) || 0; var pv = tr.querySelector('.pp').value; l.pu = pv === '' ? '' : (parseFloat(pv) || 0);
        var m = l.on && l.pu !== '' ? l.q * l.pu : 0; tr.querySelector('.mm').textContent = l.pu === '' ? '—' : fmt(m, 2) + ' $'; tr.classList.toggle('np', l.pu === ''); tr.classList.toggle('off', !l.on);
        if (l.on) { tot += m; if (l.pu === '') np++; }
      });
      o.querySelector('#adTot').textContent = 'Total chiffré : ' + fmt(tot, 2) + ' $';
      o.querySelector('#adNote').textContent = np ? np + ' poste(s) sans prix (non comptés)' : '';
    }
    o.addEventListener('input', recalc); o.addEventListener('change', recalc); recalc();
    o.querySelector('#adOk').onclick = function () { recalc(); confirmSend(L, res.ctx || {}); };
  }

  /* envoi dans « Matériaux ajoutés » du métré, puis ouverture de l'onglet Devis */
  function confirmSend(L, ctx) {
    var M = root.EXBMetre;
    if (!M || !M.addLignes) { alert('Le module Métré n’est pas disponible dans cette page.'); return; }
    var pick = L.filter(function (l) { return l.on && l.q > 0; });
    if (!pick.length) { alert('Aucune ligne cochée.'); return; }
    var mem = loadPu(); pick.forEach(function (l) { if (l.pu !== '' && l.pu > 0) mem[memKey(l, ctx)] = l.pu; }); savePu(mem);
    try { var st = M.state && M.state(); if (st && st.hdr && !st.hdr.project && ctx.project) st.hdr.project = ctx.project; } catch (e) { }
    var n = M.addLignes(pick.map(function (l) { return { d: l.d, u: l.u, q: l.q, pu: l.pu, src: l.src, puSync: true }; }));
    close();
    setTimeout(function () { var b = d.querySelector('#mb_panel button[data-act="tab"][data-t="dev"]'); if (b) b.click(); }, 60);
    try { if (typeof root.notify === 'function') root.notify(n + ' ligne(s) envoyée(s) dans le devis. Vérifiez client, validité et prix avant tout envoi.', 'success', 8000); } catch (e) { }
  }

  /* bouton d'accès, à côté de « Plan PDF → éditeur » */
  function mount() {
    if ($('bautodevis')) return;
    var anchor = $('bplanpdf') || $('bplanedit') || $('bbet') || $('bdev'), par = anchor && anchor.parentNode;
    if (!par) return;
    var b = d.createElement('button'); b.id = 'bautodevis'; b.type = 'button'; b.textContent = '🤖 Devis automatique'; b.onclick = open;
    par.insertBefore(b, anchor.nextSibling);
  }
  api.open = open; api.fromIfcFile = fromIfcFile; api.fromPlan = fromPlan; api.review = review; api.close = close;
  root.EXBAutoDevis = api;
  function start() { setTimeout(mount, 1800); }
  if (d.readyState === 'complete') start(); else root.addEventListener('load', start);
})(typeof window !== 'undefined' ? window : globalThis);
