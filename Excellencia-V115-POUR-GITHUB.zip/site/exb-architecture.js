/* Excellencia Building — Architecture & diagnostics V51 */
(function(w,d){'use strict';
function esc(v){return String(v??'').replace(/[&<>"']/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));}
function section(){
 if(d.getElementById('architecture')) return d.getElementById('architecture');
 const s=d.createElement('section');s.id='architecture';s.style.display='none';s.innerHTML=`<div class="card">
 <div class="exb-module-head"><div><h2>🧩 Architecture & diagnostic système</h2><p class="exb-muted">Vue structurée des modules, dépendances, rôles et état technique de l'application.</p></div><button class="muted" onclick="exbRunArchitectureCheck()">🔎 Vérifier maintenant</button></div>
 <div id="exbArchHealth" class="exb-kpi-grid" style="margin:12px 0"></div>
 <div class="exb-grid"><div class="exb-card"><h3>🏗️ Architecture fonctionnelle</h3><div id="exbArchModules"></div></div>
 <div class="exb-card"><h3>🔐 Matrice des rôles</h3><div class="exb-scroll"><table class="exb-table"><thead><tr><th>Rôle</th><th>Accès</th></tr></thead><tbody id="exbArchRoles"></tbody></table></div></div></div>
 <div class="exb-card" style="margin-top:12px"><h3>🔗 Flux cible</h3><div class="localhint">Client → Projet → Études → Métré/Devis → Budget → Achats/Stock → Chantier → Dépenses → Avancement → Rapports → Client</div><div class="localhint" style="margin-top:8px">Formation → Apprenant → Présences → Évaluations → Paiements → Documents → Certificat</div></div>
 <div class="exb-card" style="margin-top:12px"><h3>🧪 Contrôles techniques</h3><div id="exbArchChecks"></div></div>
 </div>`;
 const adm=d.getElementById('administration'); if(adm&&adm.parentNode)adm.parentNode.insertBefore(s,adm); else (d.querySelector('main')||d.body).appendChild(s); return s;
}
function render(){
 const s=section(), ms=w.EXB_MODULES||[]; const by={};ms.forEach(m=>(by[m.area]??=[]).push(m));
 d.getElementById('exbArchModules').innerHTML=Object.entries(by).map(([area,list])=>`<div style="margin-bottom:12px"><b>${esc(area)}</b><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;margin-top:7px">${list.map(m=>`<div style="border:1px solid #e5eaf1;border-radius:10px;padding:10px;background:#fafbfd"><b>${m.icon} ${esc(m.name)}</b><div class="localhint">${esc(m.status)} · ${m.deps.length?`dépend de ${esc(m.deps.join(', '))}`:'socle'}</div></div>`).join('')}</div></div>`).join('');
 d.getElementById('exbArchRoles').innerHTML=Object.entries(w.EXB_ROLES||{}).map(([r,a])=>`<tr><td>${esc(r)}</td><td>${a.includes('*')?'Tous les modules':esc(a.join(', '))}</td></tr>`).join('');
 run(); return s;
}
function run(){
 const checks=[]; const push=(name,ok,detail)=>checks.push({name,ok,detail});
 push('Registre des modules',Array.isArray(w.EXB_MODULES)&&w.EXB_MODULES.length>0,`${(w.EXB_MODULES||[]).length} modules déclarés`);
 push('Stockage isolé',typeof w.exbStorage!=='undefined',w.EXB_STORAGE_PREFIX?`namespace ${w.EXB_STORAGE_PREFIX}`:'API de stockage détectée');
 push('Service Worker', 'serviceWorker' in navigator, 'serviceWorker' in navigator?'API disponible':'non disponible dans ce navigateur');
 push('Synchronisation',typeof w.exbSync!=='undefined'||typeof w.syncExb==='function'||typeof w.EXB_SYNC_VERSION!=='undefined', 'Interface de synchronisation détectée ou mode local actif');
 push('QR local',typeof w.QRCode!=='undefined','Générateur QR local');
 push('PDF local',!!(w.jspdf&&w.jspdf.jsPDF), 'Moteur PDF local');
 d.getElementById('exbArchHealth').innerHTML=`<div class="exb-big-kpi"><b>${checks.filter(x=>x.ok).length}/${checks.length}</b><span>Contrôles OK</span></div><div class="exb-big-kpi"><b>${(w.EXB_MODULES||[]).length}</b><span>Modules</span></div><div class="exb-big-kpi"><b>${Object.keys(w.EXB_ROLES||{}).length}</b><span>Rôles définis</span></div><div class="exb-big-kpi"><b>${esc(w.EXB_ARCHITECTURE_VERSION||'V51')}</b><span>Architecture</span></div>`;
 d.getElementById('exbArchChecks').innerHTML=checks.map(c=>`<div style="padding:8px 10px;border-bottom:1px solid #edf1f5"><b>${c.ok?'✅':'⚠️'} ${esc(c.name)}</b><div class="localhint">${esc(c.detail)}</div></div>`).join('');
}
w.exbRunArchitectureCheck=run;w.exbOpenArchitecture=function(){const s=section();if(typeof w.show==='function')w.show('architecture');['administration','exbEnterprise'].forEach(function(i){const e=d.getElementById(i);if(e)e.style.display='none'});s.style.display='block';render();try{s.scrollIntoView({block:'start'})}catch(e){}};
d.addEventListener('DOMContentLoaded',function(){
 section(); const adm=d.getElementById('badm'); if(adm&&!d.getElementById('barch'))adm.insertAdjacentHTML('afterend','<button id="barch" onclick="exbOpenArchitecture()">🧩 Architecture & diagnostic</button>');
});
})(window,document);
