# EXCELLENCIA INTELLIGENCE — lot 4 : formation, personnel (RH) et paie

Nouveau : `exb-intelligence-4.js` (après `exb-intelligence.js`). Modifiés : `index.html` (1 balise), `sw.js` (cache), `exb-intelligence.js` (libellés des reçus/certificats/employés dans les messages). **Lecture seule** : ce lot ne modifie aucune donnée.

Complète la liaison formation existante (EXBLIEN.edu : paiements ↔ participants ↔ reçus ↔ certificats, TFL, séances, formateurs) sans la dupliquer.

## Contrôles ajoutés
- **Formations** : fin avant début, effectif > capacité, terminée mais encore active, formateur absent (démarrage sous 30 jours) ou introuvable, doublon de nom.
- **Reçus / certificats** : numéro en double, reçu à montant nul ou daté dans le futur.
- **Personnel** : doublons (nom ou téléphone), salaire ou contact manquant.
- **Contrats** : expirés (personnel actif), fin sous 30 jours, fin avant début, personne absente du personnel.
- **Paie** : retenues > brut + primes, brut nul, même employé/même période en double, employé inconnu, paie du mois manquante, brut éloigné de plus de 10 % du salaire de la fiche.

## Documents (HTML, hors ligne)
Relances de solde des participants (un message par participant, via EXBLIEN.edu) ; rapport formation ; récapitulatif de paie du mois (net = brut + primes − retenues, confidentiel).

## Confidentialité
Les contrôles RH/paie et leurs documents ne s'affichent que si l'utilisateur a le droit de lecture « rh » (EXB_CORE.can). Les messages ne contiennent pas de montants de salaire.

## Réserves
Le nom du droit (`rh`), la formule du net et le format de période (AAAA-MM) sont déduits du code : à confirmer sur vos données réelles. Métré ↔ devis et plans : non traités.

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-4.js">` de index.html.
