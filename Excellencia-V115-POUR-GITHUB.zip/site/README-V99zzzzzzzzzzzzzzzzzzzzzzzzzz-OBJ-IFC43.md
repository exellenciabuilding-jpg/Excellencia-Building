# V99 — Import natif OBJ et prise en charge IFC 4.3

Fichiers modifiés : `exb-ifc3d.js` (moteur + visionneuse), `exb-v81-plans.js` (registre des plans), `sw.js` (version du cache). Aucun SQL.

## 1. Import natif des fichiers OBJ
- Ouverture dans la même visionneuse 3D que l'IFC : rotation, mesures 3D, coupe, isolation / masquage, filtres par catégorie, **Quantités** (surfaces, volumes, export Excel/CSV, envoi au métré).
- Formats acceptés : `.obj` seul, `.obj` + `.mtl` (sélection multiple), ou `.zip` contenant un `.obj` (export Excellencia, SketchUp, Blender, 3ds Max…). Un ZIP contenant un `.ifc` s'ouvre toujours comme avant.
- Un élément par objet (`o`) / groupe (`g`) / matériau (`usemtl`). Catégorie déduite du nom (mur, dalle, toit, porte, fenêtre, poteau, poutre, escalier, fondation, terrain…), sinon « Objets OBJ ». Couleurs : `Kd` du .mtl.
- Faces à 3, 4 ou n sommets (triangulation automatique), indices négatifs acceptés.
- À l'ouverture, une question : **unité** (m, cm, mm, ft, in) et **axe vertical** (Y ou Z), avec une valeur proposée (détectée dans l'en-tête des exports Excellencia, sinon d'après l'étendue). Y vertical est converti en Z vertical.
- Registre des plans (Projet › Plans) : le format **OBJ** peut être ajouté, versionné et ouvert en 3D.

## 2. IFC 4.3 (IFC4X3, IFC4X3_ADD2)
- Schéma reconnu et affiché dans la barre d'état ; la garde d'unités « mm » ne s'applique plus aux IFC 4.3 (un ouvrage de plus de 100 m est normal en infrastructure).
- Nouvelles catégories : routes, voies ferrées, ponts, ouvrages, chaussées, couches, bordures, rails, signalisation, terrassements, remblais, géotechnique, appareils d'appui, ouvrages maritimes… (noms et couleurs).
- Parties d'ouvrage (IfcRoadPart, IfcBridgePart, IfcRailwayPart, IfcFacilityPart…) utilisées comme « niveaux » ; `IfcRelReferencedInSpatialStructure` pris en compte.
- Géométrie : `IfcFixedReferenceSweptAreaSolid` et `IfcSurfaceCurveSweptAreaSolid` le long d'une polyligne / polycourbe / courbe composée (volumes vérifiés) ; `IfcLinearPlacement` (position `CartesianPosition` si fournie, sinon calcul le long d'une polyligne).
- Les alignements (`IfcAlignment`, référents) ne sont plus comptés comme « sans géométrie ».

## Limites (signalées dans le panneau « Limites de cette lecture »)
- IFC 4.3 : `IfcSectionedSolidHorizontal`, courbes de référence à profil en long (`IfcGradientCurve`, `IfcSegmentedReferenceCurve`, clothoïdes) et placements linéaires sans `CartesianPosition` sur ces courbes ne sont pas lus. BREP avancés (NURBS) : comme avant, non lus.
- OBJ : couleurs unies (pas de textures image) ; volumes fiables seulement pour des maillages fermés et orientés.

## Tests
Moteur testé sous Node et visionneuse dans Chromium sans écran : OBJ mm / axe Y (mur 4 × 3 × 0,2 → 2,400 m³, 26,8 m²), IFC 4.3 synthétique (chaussée 140,04 m³ pour 140,06 théorique, bordure 4,50 m³, panneau posé par placement linéaire), IFC4 de régression (2,400 m³). Fichiers d'exemple dans `tests-obj-ifc43/`. Non testé avec de gros fichiers IFC 4.3 réels (ponts, voies ferrées) ni sur téléphone.
