# V99 — Éditeur de plan : outil Poutre

Fichiers : `plan-editeur/catalogue.js`, `symboles.js`, `vue3d.js`, `coupes.js`, `index.html`, `sw.js`.
- **Poutre** (palette de gauche, menu Dessin › Structure, barre d'objets « Structure ») : se pose comme un poteau. Par défaut 4,00 m × 0,20 m × 0,40 m, dessous placé sous le plafond du niveau.
- Propriétés : longueur (largeur), section (profondeur × hauteur), **cote du dessous (m)**, rotation, dupliquer, coller au mur.
- Plan : rectangle en pointillés avec axe ; 3D : volume à la bonne hauteur ; coupes et façades : à la bonne cote. Visite virtuelle : la poutre n'est pas un obstacle au sol.
- Comptée dans le métré avec les « Équipements, escaliers, poteaux » (en unités ; pas encore de volume de béton).
- Toujours grisés « bientôt » : Maillage (terrain), Élévation, Détail. Garde-corps : outil basique inchangé.
- Testé dans un navigateur de test (pose, propriétés, 3D) ; non testé sur téléphone ni sur Windows réels.
