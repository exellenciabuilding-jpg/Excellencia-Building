# Excellencia Building V97 — Enterprise intégré

V97 consolide V95 Formation, V96 IA/Copilot et l’intégration transverse.

## Flux
CRM → Contrat → Projet → Étude → Plan/BIM/CDE → DQE/Devis → Achats → Réception → Stock → Chantier → RH/Matériel/Sous-traitance → Coûts réels → Facture → Paiement → Comptabilité → Reporting → Client → IA.

## PDF/A4
Les exports génériques sont maintenant normalisés en A4 avec découpage multipage automatique. Les certificats A4 paysage restent séparés, avec fond décoratif désactivé pendant la capture PDF afin de préserver la lisibilité de la photo et du contenu.

## IA
L’IA V96 produit des propositions et recommandations ; les écritures/actions sensibles restent soumises à validation humaine.
