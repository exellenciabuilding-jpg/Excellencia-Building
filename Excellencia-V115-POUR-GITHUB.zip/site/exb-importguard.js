/* Excellencia Building V99zi — garde-fou des sauvegardes et fichiers importés (audit interne : validation des imports).
 * - bloque l'écriture de clés sensibles (licence, session, identifiants, verrou de tentatives) par un fichier importé ;
 * - neutralise les prototypes dangereux (__proto__, constructor, prototype) ;
 * - nettoie les identifiants (champs id / *_id / *Id / key / ref) : retire les caractères qui permettraient de sortir d'un attribut HTML ou d'un onclick. */
(function(w){'use strict';
var BLOCK=/^(exb_pass|exb_pass_h|exb_session|exb_lock|exb_logged|exb_user|exb_lic|exb_lic_[a-z_]+)$/i;
var BADKEY={'__proto__':1,'constructor':1,'prototype':1};
var IDKEY=/^(id|key|ref|uid|matricule|[a-z0-9]+_id|[a-z0-9]+Id|[a-z0-9]+ID)$/;
var BADCH=/['"<>`\\${}();&\r\n]/g;
function walk(x,st){
  if(Array.isArray(x)){for(var i=0;i<x.length;i++)x[i]=walk(x[i],st);return x}
  if(x&&typeof x==='object'){
    Object.keys(x).forEach(function(k){
      if(BADKEY[k]){delete x[k];st.n++;return}
      var v=x[k];
      if(typeof v==='string'&&IDKEY.test(k)){var c=v.replace(BADCH,'');if(c!==v){x[k]=c;st.n++}}
      else x[k]=walk(v,st)});
  }
  return x}
function clean(k,v){
  var s=typeof v==='string'?v:JSON.stringify(v);
  var t=s.charAt(0);if(t!=='{'&&t!=='[')return {value:s,changed:0};
  var o;try{o=JSON.parse(s)}catch(e){return {value:s,changed:0}}
  var st={n:0};walk(o,st);
  return {value:st.n?JSON.stringify(o):s,changed:st.n}}
/* entries(obj) : [[clé, valeur texte nettoyée]…] sans les clés bloquées ; report = {blocked:[…], cleaned:n} */
function entries(obj){var out=[],rep={blocked:[],cleaned:0};
  Object.keys(obj||{}).forEach(function(k){
    if(BLOCK.test(k)||BADKEY[k]){rep.blocked.push(k);return}
    var r=clean(k,obj[k]);rep.cleaned+=r.changed;out.push([k,r.value])});
  return {list:out,report:rep}}
w.exbImportGuard={blocked:function(k){return BLOCK.test(k)},clean:clean,entries:entries};
})(window);
