/* Excellencia Building — Confort d'usage V100 (aucun SQL, aucune clé existante modifiée sauf le nettoyage des devis en double, sauvegardé avant).
 *  1. Devis déjà enregistrés en double : détection + nettoyage automatique (copie de sauvegarde, bouton « Annuler le nettoyage »).
 *  2. Menu de gauche aux mêmes couleurs que la barre des modules (bleu + doré).
 *  3. Après le choix d'un module : le menu de gauche se masque, il reste les onglets du module. Bouton ☰ pour le rouvrir.
 *  4. Accueil personnalisable : bouton « 🧩 Organiser » → déplacer (glisser ou ▲ ▼), masquer, réinitialiser. Mémorisé sur l'appareil.
 * Pour retirer : supprimer la balise <script src="exb-ux-v100.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_UX) return;
  var $ = function (i) { return d.getElementById(i); };
  function note(t, k, ms) { try { w.notify ? w.notify(t, k || 'info', ms || 7000) : alert(t); } catch (e) {} }
  function ls(k, def) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function lw(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }

  /* ================= CSS ================= */
  function css() {
    if ($('exbUxCss')) return;
    var s = d.createElement('style'); s.id = 'exbUxCss';
    s.textContent =
      /* 2. menu de gauche = même palette que la barre des modules */
      '#exbSide{background:var(--dk-bg,#12254a)!important;border-right:0!important;color:#fff}' +
      '#exbSide .xs{color:#fff!important}#exbSide .xs span.ch{color:var(--dk-acc2,#e3b85a)!important}' +
      '#exbSide .xs:hover{background:#ffffff22!important}' +
      '#exbSide .xs.on{background:#fff!important;color:var(--dk-bg,#12254a)!important;box-shadow:inset 5px 0 0 var(--dk-acc,#c8962e)}' +
      '#exbSide .xpar{background:#ffffff1c!important}#exbSide .xpar button{color:#fff!important}' +
      '#exbSide .xpar button.on{background:var(--dk-acc,#c8962e)!important;color:#12254a!important}' +
      '#exbSide .xsf{border-top:1px solid #ffffff33!important;color:#c9d6ee!important}#exbSide .xsf b{color:#fff!important}' +
      /* 3. menu masqué quand un module est ouvert (ordinateur) */
      '@media(min-width:901px){' +
      'html.exb-side-off #app{grid-template-columns:minmax(0,1fr)!important}html.exb-side-off #app>*{grid-column:1!important}' +
      'html.exb-side-off #exbSide{display:none!important}' +
      'html.exb-side-off #exbBurger{display:block!important}' +
      'html.exb-side-off.exb-side-peek #exbSide{display:flex!important;position:fixed!important;left:0;top:0;bottom:0;height:auto!important;width:280px;z-index:150;padding-top:64px!important;box-shadow:0 0 30px #0006}}' +
      /* 4. accueil personnalisable */
      '.exb-hb{display:none!important}' +
      'html.exb-home-edit #exbHome .exb-hb{display:block!important;opacity:.4}' +
      'html.exb-home-edit #exbHome .exb-hk{position:relative;outline:2px dashed #c8962e;outline-offset:3px;border-radius:12px;margin-bottom:12px}' +
      '.xhe-bar{display:none}html.exb-home-edit .xhe-bar{display:flex;gap:6px;position:absolute;right:8px;top:8px;z-index:30;background:#12254a;border-radius:10px;padding:4px;box-shadow:0 4px 14px #0005}' +
      '.xhe-bar button{width:38px;height:38px;border:0;border-radius:8px;background:#ffffff22;color:#fff;font:700 16px Arial;cursor:pointer;padding:0}' +
      '.xhe-bar .xhe-g{cursor:grab;touch-action:none;background:#c8962e;color:#12254a}' +
      '.xhe-drag{opacity:.55;outline-color:#1f6feb!important}' +
      '#xheTop{display:none}html.exb-home-edit #xheTop{display:flex;gap:8px;flex-wrap:wrap;align-items:center;padding:10px 12px;margin:0 0 12px;background:#fff8e6;border:1px solid #f2d28b;border-radius:12px;color:#12254a;font:600 13px Arial}' +
      '#xheTop button,#xheBtn{border:0;border-radius:9px;padding:10px 14px;background:#12254a;color:#fff;font:700 13px Arial;cursor:pointer;min-height:40px}' +
      '#xheTop button.s{background:#e3e9f4;color:#12254a}' +
      '#xheBtn{background:#c8962e;color:#12254a;margin-left:8px}' +
      /* devis en double */
      '#exbDupBar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0;padding:10px 12px;border-radius:10px;background:#fff8e6;border:1px solid #f2d28b;color:#5b4300;font:600 13px Arial}' +
      '#exbDupBar.ok{background:#effaf3;border-color:#b7e3c6;color:#14532d}' +
      '#exbDupBar button{border:0;border-radius:8px;padding:9px 12px;background:#12254a;color:#fff;font:700 13px Arial;cursor:pointer}' +
      '@media print{.xhe-bar,#xheTop,#xheBtn,#exbDupBar{display:none!important}}';
    d.head.appendChild(s);
  }

  /* ================= 1. DEVIS EN DOUBLE ================= */
  var BK = 'exb_quotes_doublons_sauvegarde';
  function Q() { try { if (typeof exbQuotes !== 'undefined' && Array.isArray(exbQuotes)) return exbQuotes; } catch (e) {} return null; }
  function persist(arr) {
    try { if (typeof exbSave === 'function' && typeof EXB_ECO_KEYS !== 'undefined') exbSave(EXB_ECO_KEYS.quotes, arr); else localStorage.setItem('exb_quotes', JSON.stringify(arr)); } catch (e) {}
    try { if (typeof renderExbQuotes === 'function') renderExbQuotes(); } catch (e) {}
  }
  function fp(q) { return [norm(q.client), norm(q.project), Number(q.total) || 0, q.currency || '', (q.lines || []).map(function (l) { return norm(l.designation) + ':' + (Number(l.qty) || 0) + ':' + (Number(l.pu) || 0); }).join('|')].join('#'); }
  function nextNo(arr) {
    try { if (w.EXB_UNIQUE && Q() === arr) return w.EXB_UNIQUE.nextNo('DEV'); } catch (e) {}
    var y = new Date().getFullYear(), pre = 'DEV-' + y + '-', max = 0, used = {};
    arr.forEach(function (q) { if (q.no) used[q.no] = 1; });
    try { if (w.EXB_UNIQUE) { var u = w.EXB_UNIQUE.used(); Object.keys(u).forEach(function (k) { used[k] = 1; }); } } catch (e) {}
    Object.keys(used).forEach(function (k) { if (k.indexOf(pre) === 0) { var n = parseInt(k.slice(pre.length), 10); if (n > max) max = n; } });
    var n2; do { max++; n2 = pre + String(max).padStart(3, '0'); } while (used[n2]);
    return n2;
  }
  /* calcule le plan de nettoyage sans rien modifier : {drop:[ids], renum:[{q, no}], same:n} */
  function plan(arr) {
    var drop = {}, renum = [], i, byNo = {}, byFp = {};
    arr.forEach(function (q, idx) { q.__i = idx; (byNo[q.no || ''] = byNo[q.no || ''] || []).push(q); });
    Object.keys(byNo).forEach(function (no) {
      var g = byNo[no]; if (g.length < 2 || !no) return;
      var sub = {}, order = [];
      g.forEach(function (q) { var k = norm(q.project) || ('c:' + norm(q.client)); if (!sub[k]) { sub[k] = []; order.push(k); } sub[k].push(q); });
      order.forEach(function (k, n) {
        var s = sub[k], keep = s[0];
        s.forEach(function (q) { if ((q.date || '') > (keep.date || '') || ((q.date || '') === (keep.date || '') && q.__i > keep.__i)) keep = q; });
        s.forEach(function (q) { if (q !== keep) drop[q.id] = 1; });
        if (n > 0) renum.push(keep);
      });
    });
    arr.forEach(function (q) { if (drop[q.id]) return; var f = fp(q); if (!norm(q.client)) return; if (byFp[f]) { drop[q.id] = 1; } else byFp[f] = q; });
    arr.forEach(function (q) { delete q.__i; });
    return { drop: drop, renum: renum, count: Object.keys(drop).length + renum.length };
  }
  function count() { var a = Q(); if (!a) return 0; try { return plan(a.slice()).count; } catch (e) { return 0; } }
  function clean(auto) {
    var a = Q(); if (!a) return 0; var p = plan(a); if (!p.count) return 0;
    var removed = a.filter(function (q) { return p.drop[q.id]; }), renumbered = [];
    var kept = a.filter(function (q) { return !p.drop[q.id]; });
    a.splice(0, a.length); kept.forEach(function (q) { a.push(q); });
    p.renum.forEach(function (q) { if (a.indexOf(q) < 0) return; var old = q.no; q.no = nextNo(a); renumbered.push({ id: q.id, old: old, no: q.no }); });
    var bk = ls(BK, []); bk.push({ at: new Date().toISOString(), removed: removed, renumbered: renumbered }); lw(BK, bk.slice(-5));
    persist(a);
    note((auto ? 'Nettoyage automatique : ' : '') + removed.length + ' devis en double supprimé(s)' + (renumbered.length ? ', ' + renumbered.length + ' renuméroté(s)' : '') + '. Une copie est gardée : bouton « Annuler le nettoyage » dans la liste des devis.', 'success', 9000);
    return removed.length + renumbered.length;
  }
  function undo() {
    var bk = ls(BK, []), last = bk.pop(); if (!last) return note('Rien à annuler.', 'info');
    var a = Q(); if (!a) return;
    last.renumbered.forEach(function (r) { var q = a.filter(function (x) { return x.id === r.id; })[0]; if (q) q.no = r.old; });
    last.removed.forEach(function (q) { if (!a.some(function (x) { return x.id === q.id; })) a.push(q); });
    lw(BK, bk); persist(a); note('Nettoyage annulé : devis restaurés.', 'success');
  }
  function dupBar() {
    var tb = $('exb_quote_rows'); if (!tb) return;
    var tbl = tb.closest ? tb.closest('table') : null; if (!tbl || !tbl.parentNode) return;
    var bar = $('exbDupBar');
    if (!bar) { bar = d.createElement('div'); bar.id = 'exbDupBar'; bar.className = 'no-print'; tbl.parentNode.insertBefore(bar, tbl.closest('.tablewrap') || tbl); }
    var n = count(), hasBk = ls(BK, []).length > 0;
    bar.className = 'no-print' + (n ? '' : ' ok');
    bar.innerHTML = (n ? '⚠️ <span>' + n + ' devis en double détecté(s) (même numéro ou même contenu).</span><button type="button" onclick="EXB_UX.clean()">🧹 Nettoyer les doublons</button>' : '✅ <span>Aucun devis en double.</span>') +
      (hasBk ? '<button type="button" style="background:#e3e9f4;color:#12254a" onclick="EXB_UX.undo()">↩ Annuler le nettoyage</button>' : '');
  }

  /* ================= 3. MENU MASQUÉ APRÈS CHOIX D'UN MODULE ================= */
  var wasHome = true;
  function homeVisible() { var h = $('exbHome'); return !!h && h.style.display !== 'none' && h.offsetParent !== null; }
  function sideSync() {
    var hv = homeVisible(), de = d.documentElement;
    if (hv) { de.classList.remove('exb-side-off', 'exb-side-peek'); }
    else if (wasHome) { de.classList.add('exb-side-off'); de.classList.remove('exb-side-peek'); }
    wasHome = hv;
  }
  d.addEventListener('click', function (e) {
    var de = d.documentElement;
    if (e.target.closest && e.target.closest('#exbBurger') && w.innerWidth > 900 && de.classList.contains('exb-side-off')) { de.classList.toggle('exb-side-peek'); return; }
    if (de.classList.contains('exb-side-peek') && !(e.target.closest && e.target.closest('#exbSide'))) de.classList.remove('exb-side-peek');
    else if (e.target.closest && e.target.closest('#exbSide .xs')) setTimeout(function () { de.classList.remove('exb-side-peek'); sideSync(); }, 60);
    setTimeout(sideSync, 120);
  }, true);

  /* ================= 4. ACCUEIL PERSONNALISABLE ================= */
  var HK = 'exb_home_layout_v1';
  function blocks() {
    var h = $('exbHome'); if (!h) return null;
    var card = function (id) { var e = $(id); return e && e.closest ? e.closest('.xh-card') : null; };
    return {
      top: [['head', h.querySelector('.xh-head')], ['pick', $('xhPick')], ['hero', h.querySelector('.xh-hero')], ['kpis', $('xhK')], ['cols', h.querySelector('.xh-cols')], ['qa', card('xhQA')]].filter(function (x) { return x[1]; }),
      cols: [['chart', card('xhChart')], ['act', card('xhAct')]].filter(function (x) { return x[1]; })
    };
  }
  var LBL = { head: 'Titre', pick: 'Sélecteur', hero: 'Bandeau de bienvenue', kpis: 'Chiffres clés', cols: 'Graphique + activité', qa: 'Accès rapide', chart: 'Graphique', act: 'Activité récente' };
  function saved() { return ls(HK, { top: [], cols: [], hid: [] }); }
  /* Le tableau de bord (titre, date, bandeau photo, chiffres…) reste en haut ; les blocs « Actions rapides / À faire / Reprendre » restent tout en bas. */
  function keepBottom() {
    var h = $('exbHome'); if (!h) return;
    var head = h.querySelector('.xh-head'), bar = $('xheTop');
    if (head && head.parentNode === h) { var f = (bar && bar.parentNode === h) ? bar.nextElementSibling : h.firstElementChild; if (f && f !== head) h.insertBefore(head, f); }
    var pro = $('exbHomePro'); if (pro && pro.parentNode === h && h.lastElementChild !== pro) h.appendChild(pro);
  }
  function applyLayout() {
    var B = blocks(); if (!B) return; var S = saved();
    [['top', B.top, $('exbHome')], ['cols', B.cols, B.top.filter(function (x) { return x[0] === 'cols'; })[0] && B.top.filter(function (x) { return x[0] === 'cols'; })[0][1]]].forEach(function (g) {
      var list = g[1], parent = g[2]; if (!parent) return;
      var order = (S[g[0]] || []).filter(function (k) { return list.some(function (x) { return x[0] === k; }); });
      list.forEach(function (x) { if (order.indexOf(x[0]) < 0) order.push(x[0]); });
      order.forEach(function (k) { var el = list.filter(function (x) { return x[0] === k; })[0][1]; if (el.parentNode === parent) parent.appendChild(el); });
    });
    keepBottom();
    B.top.concat(B.cols).forEach(function (x) { x[1].classList.toggle('exb-hb', (S.hid || []).indexOf(x[0]) >= 0); x[1].setAttribute('data-hk', x[0]); });
  }
  function saveLayout() {
    var B = blocks(); if (!B) return; var S = saved();
    S.top = Array.prototype.map.call($('exbHome').children, function (e) { return e.getAttribute('data-hk'); }).filter(Boolean);
    var c = B.top.filter(function (x) { return x[0] === 'cols'; })[0]; if (c) S.cols = Array.prototype.map.call(c[1].children, function (e) { return e.getAttribute('data-hk'); }).filter(Boolean);
    lw(HK, S);
  }
  function setHidden(k, v) { var S = saved(); S.hid = (S.hid || []).filter(function (x) { return x !== k; }); if (v) S.hid.push(k); lw(HK, S); applyLayout(); }
  function move(el, dir) {
    var sib = dir < 0 ? el.previousElementSibling : el.nextElementSibling;
    while (sib && !sib.getAttribute('data-hk')) sib = dir < 0 ? sib.previousElementSibling : sib.nextElementSibling;
    if (!sib) return;
    if (dir < 0) el.parentNode.insertBefore(el, sib); else el.parentNode.insertBefore(el, sib.nextSibling);
    saveLayout(); try { el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {}
  }
  var drag = null;
  function dragStart(e, el) {
    e.preventDefault(); drag = el; el.classList.add('xhe-drag');
    try { e.target.setPointerCapture(e.pointerId); } catch (x) {}
  }
  function dragMove(e) {
    if (!drag) return;
    var y = e.clientY, x = e.clientX, par = drag.parentNode, sibs = Array.prototype.filter.call(par.children, function (c) { return c !== drag && c.getAttribute('data-hk') && c.offsetParent !== null; }), t = null;
    sibs.forEach(function (c) { var r = c.getBoundingClientRect(); if (y >= r.top && y <= r.bottom && x >= r.left && x <= r.right) t = c; });
    if (t) { var r = t.getBoundingClientRect(), after = (par.classList.contains('xh-cols') && w.innerWidth > 900) ? x > r.left + r.width / 2 : y > r.top + r.height / 2; par.insertBefore(drag, after ? t.nextSibling : t); }
    if (y < 80) w.scrollBy(0, -14); else if (y > w.innerHeight - 80) w.scrollBy(0, 14);
  }
  function dragEnd() { if (!drag) return; drag.classList.remove('xhe-drag'); drag = null; saveLayout(); }
  d.addEventListener('pointermove', dragMove); d.addEventListener('pointerup', dragEnd); d.addEventListener('pointercancel', dragEnd);

  function toolbars() {
    d.querySelectorAll('.xhe-bar').forEach(function (b) { b.remove(); });
    var B = blocks(); if (!B) return;
    B.top.concat(B.cols).forEach(function (x) {
      var el = x[1], k = x[0]; el.classList.add('exb-hk');
      var bar = d.createElement('div'); bar.className = 'xhe-bar no-print'; bar.setAttribute('data-for', k);
      bar.innerHTML = '<button type="button" class="xhe-g" title="Glisser pour déplacer" aria-label="Déplacer ' + LBL[k] + '">⠿</button><button type="button" data-a="up" title="Monter" aria-label="Monter">▲</button><button type="button" data-a="dn" title="Descendre" aria-label="Descendre">▼</button><button type="button" data-a="hide" title="Masquer / afficher" aria-label="Masquer ou afficher">👁</button>';
      bar.querySelector('.xhe-g').addEventListener('pointerdown', function (e) { dragStart(e, el); });
      bar.addEventListener('click', function (e) {
        var a = e.target.getAttribute && e.target.getAttribute('data-a'); if (!a) return;
        if (a === 'up') move(el, -1); else if (a === 'dn') move(el, 1); else setHidden(k, !el.classList.contains('exb-hb'));
      });
      el.appendChild(bar);
    });
  }
  function editMode(on) {
    var de = d.documentElement, h = $('exbHome'); if (!h) return;
    de.classList.toggle('exb-home-edit', !!on);
    var top = $('xheTop');
    if (on) {
      applyLayout();
      if (!top) { top = d.createElement('div'); top.id = 'xheTop'; top.className = 'no-print'; top.innerHTML = '<span>🧩 Organisez votre accueil : glissez ⠿ (ou ▲ ▼) pour déplacer, 👁 pour masquer.</span><button type="button" data-a="done">✔ Terminer</button><button type="button" class="s" data-a="reset">↺ Réinitialiser</button>'; h.insertBefore(top, h.firstChild); top.addEventListener('click', function (e) { var a = e.target.getAttribute('data-a'); if (a === 'done') editMode(false); if (a === 'reset') { try { localStorage.removeItem(HK); } catch (x) {} location.reload(); } }); }
      toolbars();
    } else { d.querySelectorAll('.xhe-bar').forEach(function (b) { b.remove(); }); d.querySelectorAll('.exb-hk').forEach(function (e) { e.classList.remove('exb-hk'); }); saveLayout(); applyLayout(); }
  }
  function mountHomeBtn() {
    var h = $('exbHome'); if (!h || $('xheBtn')) return;
    var head = h.querySelector('.xh-head'); if (!head) return;
    var b = d.createElement('button'); b.id = 'xheBtn'; b.type = 'button'; b.className = 'no-print'; b.textContent = '🧩 Organiser'; b.title = 'Déplacer, masquer ou réorganiser les blocs de l’accueil';
    b.onclick = function () { editMode(!d.documentElement.classList.contains('exb-home-edit')); };
    var dt = head.querySelector('.xh-date'); if (dt) dt.appendChild(b); else head.appendChild(b);
    applyLayout();
  }

  w.EXB_UX = { clean: function () { clean(false); dupBar(); }, undo: function () { undo(); dupBar(); }, dupCount: count, editHome: editMode, version: 'V100' };

  var autoDone = false;
  function tick() {
    css(); mountHomeBtn(); sideSync(); dupBar();
    if (d.documentElement.classList.contains('exb-home-edit') && d.querySelectorAll('.xhe-bar').length < 5) toolbars();
    if (!autoDone && Q() && Q().length) { autoDone = true; setTimeout(function () { try { if (count()) { clean(true); dupBar(); } } catch (e) {} }, 1500); }
  }
  function start() { tick(); setInterval(tick, 1500); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(start, 400); }); else setTimeout(start, 400);
})(window, document);
