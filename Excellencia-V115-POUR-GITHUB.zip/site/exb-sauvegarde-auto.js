/* Excellencia Building — Sauvegarde automatique (aucun SQL).
 *  • Copie interne automatique : au plus toutes les 3 h (et au démarrage), 7 jours gardés dans IndexedDB, restauration en un clic (copie de sécurité avant).
 *  • Dossier de sauvegarde (Chrome / Edge / Electron) : choisi une fois, le logiciel y écrit un fichier par jour (14 jours gardés).
 *  • Sans dossier : bouton « Télécharger un fichier » (même format que 🛡 Sécurité & sauvegardes, compatible avec le test de restauration).
 *  • Code de l'appareil : sert dans les numéros de devis (DEV-2026-K7-001) pour éviter le même numéro sur deux appareils.
 * Réutilise EXBSEC (exb-v81-securite.js). Pour retirer : supprimer la balise <script src="exb-sauvegarde-auto.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_ABK) return;
  var $ = function (i) { return d.getElementById(i); };
  var DB = 'EXB_AUTOBK', KEEP = 7, FILES = 14, EVERY = 3 * 3600 * 1000, LAST = 'exb_autobk_last', LASTF = 'exb_autobk_file', LB = 'exb_last_backup';
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function note(t, k, ms) { try { w.notify ? w.notify(t, k || 'info', ms || 6000) : alert(t); } catch (e) {} }
  function lsg(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lss(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function today() { return new Date().toISOString().slice(0, 10); }
  function fmt(iso) { if (!iso) return 'jamais'; var t = new Date(iso); if (isNaN(t)) return '—'; return t.toLocaleDateString('fr-FR') + ' à ' + t.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }); }
  function mo(n) { return n < 1048576 ? Math.max(1, Math.round(n / 1024)) + ' Ko' : (n / 1048576).toFixed(1).replace('.', ',') + ' Mo'; }
  var SEC = function () { return w.EXBSEC && w.EXBSEC._makeBackup ? w.EXBSEC : null; };

  /* ---------- IndexedDB ---------- */
  var dbp = null;
  function idb() {
    if (dbp) return dbp;
    dbp = new Promise(function (ok, ko) {
      try {
        var r = indexedDB.open(DB, 1);
        r.onupgradeneeded = function () { var db = r.result; if (!db.objectStoreNames.contains('snaps')) db.createObjectStore('snaps', { keyPath: 'id' }); if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv'); };
        r.onsuccess = function () { ok(r.result); }; r.onerror = function () { ko(r.error); };
      } catch (e) { ko(e); }
    });
    return dbp;
  }
  function tx(store, mode, fn) { return idb().then(function (db) { return new Promise(function (ok, ko) { var t = db.transaction(store, mode), s = t.objectStore(store), r = fn(s); t.oncomplete = function () { ok(r && r.result); }; t.onerror = t.onabort = function () { ko(t.error); }; }); }); }
  function kvGet(k) { return tx('kv', 'readonly', function (s) { return s.get(k); }); }
  function kvSet(k, v) { return tx('kv', 'readwrite', function (s) { return s.put(v, k); }); }
  function snapAll() { return tx('snaps', 'readonly', function (s) { return s.getAll(); }).then(function (a) { return (a || []).sort(function (x, y) { return y.at < x.at ? -1 : 1; }); }); }
  function snapPut(o) { return tx('snaps', 'readwrite', function (s) { return s.put(o); }); }
  function snapDel(id) { return tx('snaps', 'readwrite', function (s) { return s.delete(id); }); }
  function snapGet(id) { return tx('snaps', 'readonly', function (s) { return s.get(id); }); }

  function hasData() {
    var S = SEC(); if (!S) return false;
    try { var c = S._collect(), ks = ['exb_projects', 'exb_clients', 'exb_quotes', 'exb_metre', 'exb_participants', 'exb_certificates', 'exb_receipts', 'exb_trainers', 'exb_formations'];
      return ks.some(function (k) { try { var v = JSON.parse(c[k] || 'null'); return Array.isArray(v) ? v.length > 0 : !!(v && Object.keys(v).length); } catch (e) { return false; } }); } catch (e) { return false; }
  }

  /* ---------- dossier choisi ---------- */
  var dirH = null, needPerm = false;
  async function loadDir() { try { if (!w.showDirectoryPicker) return null; dirH = (await kvGet('dir')) || null; } catch (e) { dirH = null; } return dirH; }
  async function permOf(h, ask) {
    try { var o = { mode: 'readwrite' }; var p = await h.queryPermission(o); if (p === 'granted') return true; if (ask) { p = await h.requestPermission(o); return p === 'granted'; } } catch (e) {}
    return false;
  }
  async function writeFolder(text) {
    if (!dirH) return { ok: false, why: 'aucun dossier' };
    if (!(await permOf(dirH, false))) { needPerm = true; return { ok: false, why: 'autorisation' }; }
    needPerm = false;
    try {
      var name = 'Excellencia-sauvegarde-' + today() + '.json', fh = await dirH.getFileHandle(name, { create: true }), wr = await fh.createWritable(); await wr.write(text); await wr.close();
      try { var names = []; for await (var e of dirH.values()) { if (e.kind === 'file' && /^Excellencia-sauvegarde-\d{4}-\d{2}-\d{2}\.json$/.test(e.name)) names.push(e.name); } names.sort().reverse().slice(FILES).forEach(function (n) { dirH.removeEntry(n).catch(function () {}); }); } catch (e) {}
      return { ok: true, name: name };
    } catch (e) { return { ok: false, why: String(e && e.message || e) }; }
  }

  /* ---------- sauvegarde ---------- */
  var busy = false;
  async function run(manual) {
    var S = SEC(); if (!S) { if (manual) note('Module de sécurité indisponible.', 'error'); return null; }
    if (busy) return null; busy = true;
    try {
      if (!manual && !hasData()) return null;
      var text = await S._makeBackup(null), at = new Date().toISOString(), res = { at: at, size: text.length, folder: null };
      try {
        await snapPut({ id: today(), at: at, size: text.length, text: text });
        var all = await snapAll(); for (var i = KEEP; i < all.length; i++) await snapDel(all[i].id);
        lss(LAST, at);
      } catch (e) { res.err = 'copie interne impossible (espace plein ?)'; }
      var f = await writeFolder(text); res.folder = f;
      if (f.ok) { lss(LASTF, at); lss(LB, at); }
      if (manual) note(f.ok ? 'Sauvegarde faite : copie interne + fichier ' + f.name + ' dans votre dossier.' : (res.err ? 'Sauvegarde interne échouée : ' + res.err : 'Copie interne faite. Choisissez un dossier ou téléchargez un fichier pour une vraie sauvegarde hors de l’appareil.'), res.err ? 'error' : 'success', 8000);
      return res;
    } catch (e) { if (manual) note('Sauvegarde échouée : ' + (e.message || e), 'error', 9000); return null; }
    finally { busy = false; render(); }
  }
  async function download() {
    var S = SEC(); if (!S) return; var t = await S._makeBackup(null), b = new Blob([t], { type: 'application/json' }), a = d.createElement('a');
    a.href = URL.createObjectURL(b); a.download = 'Excellencia-sauvegarde-' + today() + '.json'; d.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    lss(LB, new Date().toISOString()); note('Fichier de sauvegarde téléchargé. Gardez-le hors de l’appareil (clé USB, e-mail, cloud).', 'success', 7000); render();
  }
  async function pick() {
    try { var h = await w.showDirectoryPicker({ mode: 'readwrite' }); await kvSet('dir', h); dirH = h; needPerm = false; note('Dossier choisi : « ' + h.name + ' ». Une sauvegarde par jour y sera écrite automatiquement.', 'success', 7000); await run(true); }
    catch (e) { if (e && e.name !== 'AbortError') note('Dossier non accessible : ' + (e.message || e), 'warn', 7000); }
    render();
  }
  async function grant() { if (dirH && await permOf(dirH, true)) { needPerm = false; await run(true); } else note('Autorisation refusée.', 'warn'); bar(); render(); }
  async function forget() { try { await kvSet('dir', null); } catch (e) {} dirH = null; needPerm = false; render(); bar(); }
  async function restore(id) {
    var S = SEC(); if (!S) return;
    if (S._canRestore && !S._canRestore()) return note('Restauration réservée à l’administrateur.', 'warn');
    var s = await snapGet(id); if (!s) return note('Copie introuvable.', 'error');
    var v = await S._verify(s.text, null); if (!v.ok) return note('Copie illisible ou altérée : ' + v.errors.join(' '), 'error', 9000);
    if (!confirm('Restaurer les données du ' + fmt(s.at) + ' ?\n\nLes données actuelles seront remplacées. Une copie de sécurité des données actuelles est faite avant.')) return;
    try {
      var cur = await S._makeBackup(null); await snapPut({ id: 'avant-restauration', at: new Date().toISOString(), size: cur.length, text: cur });
      var n = S._restoreInto(v.payload); note(n + ' éléments restaurés. Rechargement…', 'success', 3000); setTimeout(function () { location.reload(); }, 1200);
    } catch (e) { note('Restauration échouée : ' + (e.message || e), 'error', 9000); }
  }
  async function delSnap(id) { if (!confirm('Supprimer cette copie interne ?')) return; await snapDel(id); render(); }

  /* ---------- écran ---------- */
  var MID = 'exbAbk';
  function css() {
    if ($('exbAbkCss')) return; var s = d.createElement('style'); s.id = 'exbAbkCss';
    s.textContent = '#exbAbk{position:fixed;inset:0;z-index:99996;background:#0008;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto}' +
      '#exbAbk .bx{background:#fff;color:#12254a;border-radius:14px;max-width:640px;width:100%;padding:16px 18px;font:14px/1.45 Arial,sans-serif;box-shadow:0 10px 40px #0006}' +
      '#exbAbk h2{margin:0 0 6px;font-size:19px}#exbAbk h3{margin:14px 0 6px;font-size:14px}#exbAbk small{color:#5b6b85}' +
      '#exbAbk .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}' +
      '#exbAbk button{border:0;border-radius:9px;padding:10px 13px;background:#12254a;color:#fff;font:700 13px Arial;cursor:pointer;min-height:40px}#exbAbk button.s{background:#e3e9f4;color:#12254a}#exbAbk button.g{background:#c8962e;color:#12254a}#exbAbk button.r{background:#fee2e2;color:#991b1b}' +
      '#exbAbk .ok{color:#166534;font-weight:700}#exbAbk .ko{color:#b45309;font-weight:700}' +
      '#exbAbk .sn{display:flex;gap:8px;align-items:center;justify-content:space-between;padding:8px 10px;border:1px solid #e3e9f4;border-radius:10px;margin:5px 0}' +
      '#exbAbk input{padding:9px 10px;border:1px solid #9aafc6;border-radius:8px;font:700 14px Arial;width:90px;text-transform:uppercase}' +
      '#exbAbkBar{position:fixed;left:8px;right:8px;bottom:46px;z-index:99995;max-width:560px;margin:auto;background:#fff8e6;border:1px solid #f2d28b;border-radius:12px;padding:10px 12px;font:13px Arial;color:#5b4300;box-shadow:0 6px 20px #0004;display:flex;gap:8px;align-items:center;flex-wrap:wrap}' +
      '#exbAbkBar button{border:0;border-radius:8px;padding:8px 12px;background:#12254a;color:#fff;font:700 12px Arial;cursor:pointer}' +
      '@media print{#exbAbk,#exbAbkBar{display:none!important}}';
    d.head.appendChild(s);
  }
  async function render() {
    var m = $(MID); if (!m) return; var b = m.querySelector('.bx'); if (!b) return;
    var all = []; try { all = await snapAll(); } catch (e) {}
    var api = !!w.showDirectoryPicker, code = (w.EXB_UNIQUE && w.EXB_UNIQUE.deviceCode()) || '';
    var okF = lsg(LASTF), okB = lsg(LB), age = okB ? Math.floor((Date.now() - Date.parse(okB)) / 864e5) : null;
    b.innerHTML = '<div class="row" style="justify-content:space-between"><h2>💾 Sauvegarde automatique</h2><button class="s" data-a="close" aria-label="Fermer">✕</button></div>' +
      '<p>' + (age != null && age < 2 ? '<span class="ok">✔ Sauvegarde hors de l’appareil récente.</span>' : '<span class="ko">⚠ Pas de sauvegarde hors de l’appareil ' + (age == null ? 'enregistrée' : 'depuis ' + age + ' jours') + '.</span>') + '</p>' +
      '<small>Copie interne : ' + esc(fmt(lsg(LAST))) + ' — Fichier / dossier : ' + esc(fmt(okB)) + '</small>' +
      '<h3>1. Copie interne (automatique)</h3><small>Toutes les 3 heures environ, 7 jours gardés, restauration en un clic. Elle protège contre une erreur ou une mauvaise modification, mais <b>pas</b> contre l’effacement des données du navigateur ou la perte de l’appareil.</small>' +
      '<div class="row"><button data-a="now">💾 Sauvegarder maintenant</button></div>' +
      (all.length ? all.map(function (s) { return '<div class="sn"><span><b>' + esc(s.id === 'avant-restauration' ? 'Avant la dernière restauration' : fmt(s.at)) + '</b> <small>' + mo(s.size || 0) + '</small></span><span><button data-a="rest" data-id="' + esc(s.id) + '">↩ Restaurer</button> <button class="r" data-a="del" data-id="' + esc(s.id) + '" aria-label="Supprimer">🗑</button></span></div>'; }).join('') : '<small>Aucune copie pour le moment.</small>') +
      '<h3>2. Dossier de sauvegarde (hors du logiciel)</h3>' +
      (api ? '<small>' + (dirH ? 'Dossier choisi : <b>' + esc(dirH.name) + '</b>' + (needPerm ? ' — <span class="ko">autorisation à renouveler</span>' : '') + '. Un fichier par jour, 14 jours gardés. Choisissez de préférence une clé USB ou un dossier synchronisé (Drive, OneDrive).' : 'Choisissez un dossier une seule fois : le logiciel y écrira un fichier par jour. Idéal : clé USB ou dossier synchronisé (Drive, OneDrive).') + '</small>' +
        '<div class="row"><button class="g" data-a="pick">📁 ' + (dirH ? 'Changer de dossier' : 'Choisir le dossier') + '</button>' + (needPerm ? '<button data-a="grant">✔ Autoriser</button>' : '') + (dirH ? '<button class="s" data-a="forget">Retirer le dossier</button>' : '') + '</div>'
        : '<small>Ce navigateur ne peut pas écrire dans un dossier choisi. Utilisez le téléchargement ci-dessous (ou ouvrez le logiciel dans Chrome / Edge sur ordinateur).</small>') +
      '<div class="row"><button class="s" data-a="dl">⬇ Télécharger un fichier de sauvegarde</button><button class="s" data-a="sec">🛡 Sécurité &amp; sauvegardes (chiffrement, test)</button></div>' +
      '<h3>3. Code de cet appareil</h3><small>Placé dans les numéros de devis (ex. DEV-' + new Date().getFullYear() + '-<b>' + esc(code || 'XX') + '</b>-001) : deux appareils ne peuvent plus donner le même numéro. Donnez un code différent à chaque appareil (ex. BU = bureau, T1 = téléphone 1). Vide = ancien format sans code.</small>' +
      '<div class="row"><input id="exbAbkCode" maxlength="4" value="' + esc(code) + '" aria-label="Code de l’appareil"><button data-a="code">Enregistrer le code</button></div>';
  }
  function open() {
    css(); var m = $(MID); if (!m) { m = d.createElement('div'); m.id = MID; m.className = 'no-print'; m.innerHTML = '<div class="bx"></div>'; m.addEventListener('click', onClick); d.body.appendChild(m); }
    render();
  }
  function onClick(e) {
    var m = $(MID); if (e.target === m) return m.remove();
    var t = e.target.closest && e.target.closest('[data-a]'); if (!t) return; var a = t.getAttribute('data-a'), id = t.getAttribute('data-id');
    if (a === 'close') m.remove(); else if (a === 'now') run(true); else if (a === 'pick') pick(); else if (a === 'grant') grant(); else if (a === 'forget') forget();
    else if (a === 'dl') download(); else if (a === 'sec') { m.remove(); try { w.EXBSEC.open(); } catch (x) {} }
    else if (a === 'rest') restore(id); else if (a === 'del') delSnap(id);
    else if (a === 'code') { var v = ($('exbAbkCode') || {}).value || ''; if (w.EXB_UNIQUE) { var r = w.EXB_UNIQUE.setDeviceCode(v); note(r ? 'Code de l’appareil : ' + r + '. Les prochains devis porteront ce code.' : 'Code retiré : ancien format de numéro (sans code).', 'success', 6000); } render(); }
  }
  function bar() {
    var b = $('exbAbkBar');
    if (!needPerm) { if (b) b.remove(); return; }
    if (b) return; css(); b = d.createElement('div'); b.id = 'exbAbkBar'; b.className = 'no-print';
    b.innerHTML = '💾 <span>Autorisez la sauvegarde automatique dans votre dossier (une fois par session).</span><button type="button" data-a="grant">Autoriser</button><button type="button" style="background:#e3e9f4;color:#12254a" data-a="x">Plus tard</button>';
    b.addEventListener('click', function (e) { var a = e.target.getAttribute && e.target.getAttribute('data-a'); if (a === 'grant') grant(); else if (a === 'x') b.remove(); });
    d.body.appendChild(b);
  }
  function mountBtn() {
    var st = $('exbStatus'); if (!st || $('exbAbkBtn')) return;
    var s = d.createElement('button'); s.id = 'exbAbkBtn'; s.type = 'button'; s.className = 'no-print'; s.textContent = '💾 Sauvegarde auto';
    s.style.cssText = 'border:0;background:transparent;color:inherit;font:inherit;font-weight:700;cursor:pointer;text-decoration:underline;padding:0 6px'; s.onclick = open; st.insertBefore(s, st.children[2] || null);
  }

  /* ---------- planification ---------- */
  async function tick() {
    mountBtn();
    try {
      if (!dirH && w.showDirectoryPicker && !tick.l) { tick.l = 1; await loadDir(); }
      var l = lsg(LAST), due = !l || Date.now() - Date.parse(l) > EVERY || String(l).slice(0, 10) !== today();
      if (due && d.visibilityState !== 'hidden') await run(false);
      if (dirH && !needPerm) { var p = await permOf(dirH, false); if (!p) needPerm = true; }
      bar();
    } catch (e) {}
  }
  w.EXB_ABK = { open: open, run: function () { return run(true); }, snapshots: snapAll, restore: restore, version: 'V100' };
  function start() { setTimeout(tick, 9000); setInterval(tick, 10 * 60 * 1000); setInterval(mountBtn, 2500); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
