# V99zzg — Assistant guidé avec voix (étapes dans le bon ordre)

**Aucun SQL.** Fichiers : `exb-guide.js` (nouveau), `index.html` (1 balise), `sw.js` (cache `exb-v99zzg-guide-vocal-1`), `exb-v99r-shell.js` (version), `tools/e2e-guide.py` (nouveau).
Le module **Budget & pilotage financier** (V99zzb) était déjà présent et identique dans la V99zzf : rien à reporter, il a été re-testé sur cette version.

## Ce que fait l'assistant
Avant d'enregistrer ou d'exporter, il vérifie que les étapes **précédentes** sont faites. S'il manque quelque chose :
1. l'action est suspendue (rien n'est enregistré ni exporté à moitié) ;
2. une voix française le dit : « Veuillez d'abord créer la fiche du client dans la section Clients avant d'enregistrer le devis » ; s'il manque plusieurs choses : « Avant d'enregistrer le devis, il reste 2 étapes. D'abord : … Ensuite : … » ;
3. une carte liste les étapes, avec un bouton **➡ Ouvrir « Clients »** (ou Participants, Paiements, Stock, Planning…) ; les champs concernés sont surlignés en rouge et le premier reçoit le curseur.
Après un enregistrement réussi, la voix annonce la **prochaine étape** (ex. « Devis enregistré. Vous pouvez maintenant l'exporter en PDF… »).
Tous les avertissements déjà présents dans le logiciel (messages et alertes) sont aussi **lus à voix haute**.

## Actions surveillées (et ce qui est exigé)
- **Client** : nom + téléphone. **Projet** : nom ; au moins un client existant ; client choisi.
- **Devis** (enregistrer, exporter PDF, imprimer) : au moins une fiche client existe ; nom du client renseigné ; *(mode strict)* ce client a une fiche ; au moins une ligne.
- **Participant** : nom, formation. **Formation** : nom. **Séance du planning** : formation existante, formation, module, date. **Export du planning** : séances créées.
- **Paiement** : participant existant et choisi, montant > 0.
- **Reçu** : participant existant, choisi dans la liste et **approuvé** ; formation ; un montant ; *(mode strict)* son paiement est enregistré. **Export PDF du reçu** : tout ce qui précède + reçu **enregistré** (numéro définitif).
- **Certificat** : participant existant, titulaire, formation, durée, lieu, date ; *(strict)* titulaire enregistré comme participant. **Export PDF** : certificat enregistré (numéro + QR). **Certificats en lot** : participants cochés, durée, lieu, date.
- **Présences** (enregistrer, PDF), **cotation**, **évaluation**, **liste des participants PDF**, **stock** (matériau, mouvement), **caisse**, **étude**, **formateur**, **facture de chantier** (projet + client existants).

## Réglages (Paramètres › « Assistant guidé & voix »)
Activer l'assistant · lecture vocale · annonce de la prochaine étape · **mode strict** (exige les fiches liées ; désactivez-le si vous établissez parfois un devis pour un client sans fiche) · volume · test de la voix.
Préférences gardées sur l'appareil seulement ; aucune donnée métier n'est créée.

## Limites
- La voix dépend du navigateur (synthèse vocale française du téléphone / PC) ; sans voix, la carte et le surlignage restent. Chrome exige un premier clic dans la page.
- Les règles couvrent les actions listées ci-dessus ; les autres modules gardent leurs messages d'origine (lus à voix haute). Pour en ajouter : une entrée dans `RULES` de `exb-guide.js`.
- Les contrôles tiennent compte de ce qui est enregistré dans l'application ; ils ne remplacent pas les droits par fonction.

## Tests
`python3 tools/e2e-guide.py` (navigateur, voix simulée : on vérifie ce qui est dit) · `node tools/check.js` (355 contrôles).
