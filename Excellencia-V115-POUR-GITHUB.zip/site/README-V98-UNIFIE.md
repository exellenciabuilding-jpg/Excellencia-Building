# Excellencia Building V98 — Version unifiée

Un seul logiciel qui réunit les trois versions auditées :

| Origine | Ce qui est repris |
|---|---|
| **V97 Enterprise** (base) | Core, ERP, BTP, Architecture/BIM/CDE, Formation, IA/Copilot, PDF A4 multipage |
| **V81-2 Pilotage & Sécurité** | Pilotage direction, sauvegardes chiffrées + test de restauration, quota IA serveur, **devis rapide avec main d'œuvre et imprévus**, devis CDF → facture FC |
| **V81 Gestion** | **Paie & RH** (INSS, IPR, bulletins, congés, avances), **permis & autorisations**, **pièces écrites** (CCTP, CCAP, lettres, OS), **plans CAO** (DXF, IFC) |

## Corrections apportées à la fusion
- Restauré dans V97 : le devis rapide (sections matériaux / main d'œuvre, imprévus, note) et la conversion devis en CDF → facture en FC. Ils avaient été perdus et les tests correspondants avaient été réduits : ils sont de nouveau complets.
- Nouvelle migration `migration-v98-unifie.sql` : les droits V90/V92 visaient « ressources humaines », « chef de projet », « conducteur travaux », des noms que le noyau n'utilise pas ; ils sont copiés vers rh, chef_projet, conducteur.
- Cache hors ligne : `exb-v98-unifie-1` (les appareils se mettent à jour à la prochaine ouverture en ligne).
- `tools/check.js` : 215 contrôles (fusion des tests V81, V81-2 et V97 + contrôles d'intégration).

## Installation
1. Hébergez le dossier complet.
2. Supabase › SQL Editor, dans cet ordre (toutes réexécutables) :
   `schema-entreprise` → `migration-v66` → `v67` → `v68` → `v75` → `v76` → `v77` → `v78` → `v79` → `v80` →
   `v81-securite` → `v81-gestion` → `v90` → `v91` → `v92` → `v93` → `v94` → `v97` → **`v98-unifie`**.
3. Si vous utilisez l'assistant IA en ligne : redéployer `supabase/functions/assistant/index.ts`.
4. Avant chaque livraison : `node tools/check.js`.

## Limites connues — à lire
- **Non testé dans un navigateur ni sur un Supabase réel** : seuls les scripts de contrôle ont été exécutés.
- **Deux modules de paie** coexistent : « Paie & RH » (V81, avec barèmes INSS/IPR, à confirmer avec l'INSS, la DGI et votre expert-comptable) et la table `paie` du bloc ERP V92, qui n'a pas de calcul. Utilisez celui de V81.
- **Données locales seulement** (non synchronisées avec Supabase) : modules ERP V92, BTP V93, paiements V93, workflow Formation V95, liens V97. Seul V94 (Architecture/BIM/CDE) est synchronisé. Les tables SQL V92/V93 existent mais ne sont pas encore alimentées par ces modules.
- **IA V96** : règles simples, niveaux de confiance écrits en dur, aucune action exécutée ; ce n'est pas un modèle d'IA.
- Les dossiers `erp/`, `btp/`, `architecture/`, `formation/`, `ai/` sont des espaces de noms (README) : le code actif reste dans les fichiers `exb-*.js`.
- `licence-config.js` : `requireToken:true` → sans code d'activation, le logiciel reste verrouillé. Vérifiez que c'est voulu avant livraison.
- `exb-btp.js` et `exb-form.js` ne sont chargés par aucun écran (déjà le cas dans les trois versions).

## Corrections après essais sur téléphone (cache `exb-v98-unifie-3`)
- **Navigation mobile** (`exb-v98-nav.js`) : sur écran ≤ 900 px, ouvrir une partie replie le menu ; seule la partie ouverte reste à l'écran, avec un bouton « ⬅ Menu » ; le bouton Retour du téléphone ramène au menu. Sur ordinateur, rien ne change.
- **Alerte « Intégration V97 incomplète »** : le contrôle cherchait un objet `EXBSYNC` qui n'existe pas (l'objet réel est `exbSync`). La synchronisation du noyau (`core/index.js`) avait le même défaut. Corrigé.
- **Diagnostic « Serveur Supabase joignable ❌ »** : faux négatif (le point de santé répond une erreur 4xx avec les nouvelles clés `sb_publishable_`). Une réponse HTTP < 500 est maintenant comptée comme « joignable ».
