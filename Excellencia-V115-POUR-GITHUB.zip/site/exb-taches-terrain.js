/* Excellencia Building — Tâches terrain : tâches par chantier, attribuées à l'équipe ou à un sous-traitant,
 * priorité, échéance, avancement, photos, commentaires, liste prête à envoyer (WhatsApp / impression).
 * Stockage : exb_taches_terrain (collection serveur « taches_terrain »), via EXBS : hors ligne + synchronisation comme les autres modules.
 * Droits : EXBDB.can('taches_terrain', 'lire' | 'ecrire'). Voir README-TACHES-TERRAIN.md. */
(function (w, d) {
'use strict';
var KEY = 'exb_taches_terrain', COL = 'taches_terrain';
var STATUTS = ['À faire', 'En cours', 'Bloquée', 'Terminée', 'Validée'];
var PRIOS = ['Basse', 'Normale', 'Haute', 'Urgente'];
var PCOL = { Basse: '#64748b', Normale: '#0369a1', Haute: '#b45309', Urgente: '#b00020' };
var ST = { pid: '', who: '', st: '' };

function load() { return w.EXBS ? w.EXBS.get(KEY) : []; }
function save(a) { return w.EXBS ? w.EXBS.set(KEY, a) : false; }
function uid() { return 'TT-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); } catch (e) {} }
function today() { return new Date().toISOString().slice(0, 10); }
function frDate(s) { var m = /^(\d{4})-(\d\d)-(\d\d)/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || '—'); }
function canW() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'ecrire'); } catch (e) { return true; } }
function canR() { try { return !w.EXBDB || !w.EXBDB.can || w.EXBDB.can(COL, 'lire'); } catch (e) { return true; } }
function projects() { try { return w.EXBS.projects(); } catch (e) { return []; } }
function pname(id) { var p = projects().find(function (x) { return String(x.id) === String(id); }); return p ? (p.nom || p.name || p.titre || p.title || p.id) : (id || '—'); }
function names() {
  var out = {};
  ['exb_hr', 'exb_suppliers', 'exb_subcontractors'].forEach(function (k) {
    try { w.EXBS.get(k).forEach(function (x) { var n = x.nom || x.name || x.raison || x.societe; if (n) out[n] = 1; }); } catch (e) {}
  });
  load().forEach(function (t) { if (t.assignee) out[t.assignee] = 1; });
  return Object.keys(out).sort();
}
function isOpen(t) { return t.status !== 'Terminée' && t.status !== 'Validée'; }
function isLate(t) { return isOpen(t) && t.due && t.due < today(); }

/* ---------- photos : réduites avant stockage ---------- */
function shrink(file, cb) {
  var r = new FileReader();
  r.onload = function () {
    var img = new Image();
    img.onload = function () {
      var max = 900, k = Math.min(1, max / Math.max(img.width, img.height)), c = d.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      cb(c.toDataURL('image/jpeg', 0.6));
    };
    img.onerror = function () { cb(null); };
    img.src = r.result;
  };
  r.onerror = function () { cb(null); };
  r.readAsDataURL(file);
}

/* ---------- liste ---------- */
function filtered() {
  return load().filter(function (t) {
    return (!ST.pid || String(t.project) === ST.pid) && (!ST.who || t.assignee === ST.who) && (!ST.st || t.status === ST.st);
  }).sort(function (a, b) {
    var la = isLate(a) ? 0 : 1, lb = isLate(b) ? 0 : 1; if (la !== lb) return la - lb;
    return String(a.due || '9999').localeCompare(String(b.due || '9999'));
  });
}
function opt(list, val, all) {
  return (all ? '<option value="">' + all + '</option>' : '') + list.map(function (o) {
    var v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o;
    return '<option value="' + esc(v) + '"' + (String(v) === String(val) ? ' selected' : '') + '>' + esc(l) + '</option>';
  }).join('');
}
function card(t) {
  var late = isLate(t), ro = !canW();
  return '<div style="border:1px solid ' + (late ? '#b00020' : '#d8dde6') + ';border-radius:12px;padding:10px;margin:8px 0;background:#fff">'
    + '<div style="display:flex;justify-content:space-between;gap:8px"><b>' + esc(t.title) + '</b>'
    + '<span style="color:#fff;background:' + PCOL[t.priority || 'Normale'] + ';border-radius:8px;padding:1px 8px;font-size:12px;height:18px">' + esc(t.priority || 'Normale') + '</span></div>'
    + '<div style="font-size:13px;color:#555;margin:3px 0">' + esc(pname(t.project)) + ' · 👷 ' + esc(t.assignee || 'Non attribuée') + (t.assignee_type === 'soustraitant' ? ' (sous-traitant)' : '')
    + ' · ⏰ <span style="color:' + (late ? '#b00020' : 'inherit') + '">' + esc(frDate(t.due)) + (late ? ' — en retard' : '') + '</span></div>'
    + (t.description ? '<div style="font-size:13px;margin:3px 0">' + esc(t.description) + '</div>' : '')
    + '<div style="background:#e8edf4;border-radius:6px;height:8px;margin:6px 0"><div style="width:' + (+t.progress || 0) + '%;height:8px;border-radius:6px;background:#0b7a5c"></div></div>'
    + (t.photos && t.photos.length ? '<div style="display:flex;gap:6px;flex-wrap:wrap">' + t.photos.map(function (p) { return '<img src="' + p + '" style="width:64px;height:64px;object-fit:cover;border-radius:8px" alt="">'; }).join('') + '</div>' : '')
    + (t.comments && t.comments.length ? '<div style="font-size:12px;color:#555;margin-top:4px">💬 ' + esc(t.comments[t.comments.length - 1].text) + ' <i>(' + frDate(t.comments[t.comments.length - 1].date) + ')</i></div>' : '')
    + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><select data-s="' + t.id + '" ' + (ro ? 'disabled' : '') + ' style="padding:6px;border-radius:8px;border:1px solid #ccc">' + opt(STATUTS, t.status) + '</select>'
    + '<button class="muted" data-a="e|' + t.id + '"' + (ro ? ' disabled' : '') + '>✏️ Modifier</button>'
    + '<button class="muted" data-a="x|' + t.id + '"' + (ro ? ' disabled' : '') + '>🗑</button></div></div>';
}
function render() {
  var el = d.getElementById('exbTTlist'); if (!el) return;
  var all = load(), a = filtered();
  var late = all.filter(isLate).length, open = all.filter(isOpen).length;
  d.getElementById('exbTTkpi').innerHTML = '<b>' + open + '</b> ouvertes · <b style="color:' + (late ? '#b00020' : 'inherit') + '">' + late + '</b> en retard · <b>' + all.filter(function (t) { return t.status === 'Bloquée'; }).length + '</b> bloquées';
  el.innerHTML = a.length ? a.map(card).join('') : '<p style="color:#666">Aucune tâche pour ce filtre.</p>';
}

/* ---------- panneau ---------- */
function panel() {
  var old = d.getElementById('exbTTpanel'); if (old) { old.remove(); return; }
  var p = d.createElement('div'); p.id = 'exbTTpanel';
  p.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0008;display:flex;align-items:center;justify-content:center;padding:10px';
  var ps = projects().map(function (x) { return [x.id, x.nom || x.name || x.titre || x.title || x.id]; });
  p.innerHTML = '<div style="background:#f6f8fb;color:#111;width:min(900px,100%);max-height:94vh;overflow:auto;border-radius:16px;padding:14px">'
    + '<div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">✅ Tâches terrain</h3><button class="muted" id="exbTTx">✕</button></div>'
    + '<div id="exbTTkpi" style="margin:6px 0;font-size:14px"></div>'
    + '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:6px 0"><select id="exbTTfp" style="padding:7px;border-radius:8px">' + opt(ps, ST.pid, 'Tous les chantiers') + '</select>'
    + '<select id="exbTTfw" style="padding:7px;border-radius:8px">' + opt(names(), ST.who, 'Toutes les personnes') + '</select>'
    + '<select id="exbTTfs" style="padding:7px;border-radius:8px">' + opt(STATUTS, ST.st, 'Tous les statuts') + '</select></div>'
    + '<div style="display:flex;gap:6px;flex-wrap:wrap"><button id="exbTTnew">➕ Nouvelle tâche</button><button class="muted" id="exbTTsend">📤 Liste à envoyer</button></div>'
    + '<div id="exbTTlist"></div></div>';
  d.body.appendChild(p);
  p.querySelector('#exbTTx').onclick = function () { p.remove(); };
  var nb = p.querySelector('#exbTTnew'); nb.disabled = !canW(); nb.onclick = function () { form(); };
  p.querySelector('#exbTTsend').onclick = sendList;
  ['p', 'w', 's'].forEach(function (k) { p.querySelector('#exbTTf' + k).onchange = function (e) { ST[{ p: 'pid', w: 'who', s: 'st' }[k]] = e.target.value; render(); }; });
  p.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-a]'); if (!b) return;
    var v = b.getAttribute('data-a').split('|'); if (v[0] === 'e') form(v[1]); else if (v[0] === 'x') del(v[1]);
  });
  p.addEventListener('change', function (e) {
    var id = e.target.getAttribute && e.target.getAttribute('data-s'); if (!id) return;
    if (!canW()) { say('Droits insuffisants.', 'warn'); return; }
    var a = load(), t = a.find(function (x) { return x.id === id; }); if (!t) return;
    t.status = e.target.value; if (t.status === 'Terminée' || t.status === 'Validée') t.progress = 100;
    t.updated = new Date().toISOString(); if (save(a)) render();
  });
  render();
}
function del(id) {
  if (!canW() || !w.confirm('Supprimer cette tâche ?')) return;
  if (save(load().filter(function (x) { return x.id !== id; }))) render();
}

/* ---------- formulaire ---------- */
function form(id) {
  if (!canW()) { say('Droits insuffisants.', 'warn'); return; }
  var cur = id ? load().find(function (x) { return x.id === id; }) : null;
  var c = cur || { status: 'À faire', priority: 'Normale', assignee_type: 'equipe', progress: 0, photos: [], comments: [], project: ST.pid };
  var photos = (c.photos || []).slice();
  var m = d.createElement('div');
  m.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0008;display:flex;align-items:center;justify-content:center;padding:10px';
  var L = 'display:block;margin:8px 0 2px;font-size:13px', I = 'width:100%;padding:8px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box';
  var ps = [['', '— choisir —']].concat(projects().map(function (x) { return [x.id, x.nom || x.name || x.titre || x.title || x.id]; }));
  m.innerHTML = '<div style="background:#fff;color:#111;width:min(520px,100%);max-height:92vh;overflow:auto;border-radius:14px;padding:14px"><h3 style="margin:0 0 6px">' + (cur ? 'Modifier' : 'Nouvelle') + ' tâche</h3>'
    + '<label style="' + L + '"><b>Titre *</b><input id="ttT" style="' + I + '" value="' + esc(c.title || '') + '"></label>'
    + '<label style="' + L + '"><b>Chantier *</b><select id="ttP" style="' + I + '">' + opt(ps, c.project) + '</select></label>'
    + '<label style="' + L + '"><b>Attribuée à</b><input id="ttA" list="ttNames" style="' + I + '" value="' + esc(c.assignee || '') + '"><datalist id="ttNames">' + names().map(function (n) { return '<option value="' + esc(n) + '">'; }).join('') + '</datalist></label>'
    + '<label style="' + L + '"><b>Type</b><select id="ttY" style="' + I + '">' + opt([['equipe', 'Équipe interne'], ['soustraitant', 'Sous-traitant']], c.assignee_type) + '</select></label>'
    + '<label style="' + L + '"><b>Priorité</b><select id="ttR" style="' + I + '">' + opt(PRIOS, c.priority) + '</select></label>'
    + '<label style="' + L + '"><b>Échéance</b><input id="ttD" type="date" style="' + I + '" value="' + esc(c.due || '') + '"></label>'
    + '<label style="' + L + '"><b>Statut</b><select id="ttS" style="' + I + '">' + opt(STATUTS, c.status) + '</select></label>'
    + '<label style="' + L + '"><b>Avancement : <span id="ttPv">' + (+c.progress || 0) + '</span> %</b><input id="ttG" type="range" min="0" max="100" step="5" style="width:100%" value="' + (+c.progress || 0) + '"></label>'
    + '<label style="' + L + '"><b>Description</b><textarea id="ttX" rows="3" style="' + I + '">' + esc(c.description || '') + '</textarea></label>'
    + '<label style="' + L + '"><b>Nouveau commentaire</b><input id="ttC" style="' + I + '" placeholder="ex. matériel livré, reste le coulage"></label>'
    + '<label style="' + L + '"><b>Photos (3 max)</b><input id="ttF" type="file" accept="image/*" multiple capture="environment"></label><div id="ttPh" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px"></div>'
    + '<div id="ttE" style="color:#b00020;font-size:13px;min-height:18px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button class="muted" id="ttN">Annuler</button><button id="ttOk">Enregistrer</button></div></div>';
  d.body.appendChild(m);
  function $(i) { return m.querySelector('#' + i); }
  function ph() { $('ttPh').innerHTML = photos.map(function (p, i) { return '<span style="position:relative"><img src="' + p + '" style="width:60px;height:60px;object-fit:cover;border-radius:8px" alt=""><b data-r="' + i + '" style="position:absolute;top:-4px;right:-4px;background:#b00020;color:#fff;border-radius:50%;width:18px;height:18px;text-align:center;font-size:12px;cursor:pointer">×</b></span>'; }).join(''); }
  ph();
  $('ttPh').onclick = function (e) { var r = e.target.getAttribute && e.target.getAttribute('data-r'); if (r != null) { photos.splice(+r, 1); ph(); } };
  $('ttG').oninput = function () { $('ttPv').textContent = this.value; };
  $('ttF').onchange = function () {
    Array.prototype.slice.call(this.files).forEach(function (f) {
      if (photos.length >= 3) return;
      shrink(f, function (u) { if (u && photos.length < 3) { photos.push(u); ph(); } });
    });
    this.value = '';
  };
  $('ttN').onclick = function () { m.remove(); };
  $('ttOk').onclick = function () {
    var title = $('ttT').value.trim(), pr = $('ttP').value;
    if (!title || !pr) { $('ttE').textContent = 'Le titre et le chantier sont obligatoires.'; return; }
    var a = load(), t = cur ? a.find(function (x) { return x.id === id; }) : { id: uid(), created: new Date().toISOString(), comments: [] };
    if (!t) { m.remove(); return; }
    t.title = title; t.project = pr; t.assignee = $('ttA').value.trim(); t.assignee_type = $('ttY').value; t.priority = $('ttR').value;
    t.due = $('ttD').value; t.status = $('ttS').value; t.progress = +$('ttG').value; t.description = $('ttX').value.trim(); t.photos = photos;
    if (t.status === 'Terminée' || t.status === 'Validée') t.progress = 100;
    var cm = $('ttC').value.trim(); if (cm) (t.comments = t.comments || []).push({ date: today(), text: cm });
    t.updated = new Date().toISOString();
    if (!cur) a.unshift(t);
    if (save(a)) { m.remove(); render(); say('Tâche enregistrée.'); } else { $('ttE').textContent = 'Stockage plein : retirez des photos.'; }
  };
}

/* ---------- liste à envoyer (sans photos, texte seul : pas de portail, aucun accès aux autres données) ---------- */
function sendList() {
  var who = ST.who;
  if (!who) { say('Choisissez d’abord une personne dans le filtre « Toutes les personnes ».', 'warn'); return; }
  var a = filtered().filter(isOpen);
  if (!a.length) { say('Aucune tâche ouverte pour ' + who + '.', 'warn'); return; }
  var txt = 'Bonjour ' + who + ',\nVoici vos tâches ouvertes (' + a.length + ') :\n\n' + a.map(function (t, i) {
    return (i + 1) + '. ' + t.title + ' — ' + pname(t.project) + ' — échéance ' + frDate(t.due) + ' — priorité ' + (t.priority || 'Normale') + (isLate(t) ? ' ⚠ EN RETARD' : '');
  }).join('\n') + '\n\nMerci de confirmer l’avancement.';
  var m = d.createElement('div');
  m.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0008;display:flex;align-items:center;justify-content:center;padding:10px';
  m.innerHTML = '<div style="background:#fff;color:#111;width:min(520px,100%);border-radius:14px;padding:14px"><h3 style="margin:0 0 6px">📤 Liste pour ' + esc(who) + '</h3><textarea id="ttMsg" rows="10" style="width:100%;box-sizing:border-box;padding:8px;border:1px solid #ccc;border-radius:8px">' + esc(txt) + '</textarea>'
    + '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px;flex-wrap:wrap"><button class="muted" id="ttK">Fermer</button><button class="muted" id="ttCp">Copier</button><button id="ttWa">WhatsApp</button></div></div>';
  d.body.appendChild(m);
  m.querySelector('#ttK').onclick = function () { m.remove(); };
  m.querySelector('#ttCp').onclick = function () { try { w.navigator.clipboard.writeText(m.querySelector('#ttMsg').value); say('Copié.'); } catch (e) { m.querySelector('#ttMsg').select(); } };
  m.querySelector('#ttWa').onclick = function () { w.open('https://wa.me/?text=' + encodeURIComponent(m.querySelector('#ttMsg').value), '_blank'); };
}

/* ---------- bouton dans le menu ---------- */
function ui() {
  var badm = d.getElementById('badm');
  if (!badm || d.getElementById('exbTTbtn')) return;
  var b = d.createElement('button'); b.id = 'exbTTbtn'; b.className = 'muted'; b.textContent = '✅ Tâches terrain'; b.onclick = panel;
  badm.parentNode.appendChild(b);
  if (!canR()) b.setAttribute('data-exbrole', 'hide');
}
var tries = 0, iv = setInterval(function () { ui(); if (d.getElementById('exbTTbtn') || ++tries > 120) clearInterval(iv); }, 500);
w.EXBTT = { open: panel, list: load, version: 'tt-1' };
})(window, document);
