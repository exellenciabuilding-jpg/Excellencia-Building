# V99w — Apparence (thèmes Doux/Auto, couleur, luminosité, filigrane) sur la base V99v

Fichier ajouté : `exb-v99w-appearance.js`. Modifiés : `index.html` (1 balise + pré-application dans le <head>), `sw.js` (cache `exb-v99w-appearance-1`), `exb-v99r-shell.js` (libellé de version seulement).
- Bouton 🎨 (barre du haut) : thème Clair / Doux / Sombre / Auto (clair 6 h–18 h, sombre ensuite), 5 couleurs, luminosité 60–100 %, filigrane Excellencia Building, Réinitialiser.
- Le bouton soleil/lune de `exb-theme.js` reste un raccourci Clair/Sombre : il met à jour le panneau (testé).
- Réglages sous la clé `exb_appearance` ; la clé `exb_theme` reste celle d'`exb-theme.js` (clair/sombre). Les couleurs d'entreprise du logiciel (clés préfixées EXB_V28__) ne sont pas touchées.
- Filigrane et luminosité : écran uniquement, jamais imprimés. Pastille 🔔 d'origine et puce « Base partagée » déplacées pour ne plus recouvrir le profil et la barre d'état. Téléphone : le raccourci soleil/lune est masqué sous 600 px (le panneau 🎨 le remplace) pour que l'en-tête tienne sur l'écran.
- Retrait : supprimer la balise `exb-v99w-appearance.js` d'index.html.
