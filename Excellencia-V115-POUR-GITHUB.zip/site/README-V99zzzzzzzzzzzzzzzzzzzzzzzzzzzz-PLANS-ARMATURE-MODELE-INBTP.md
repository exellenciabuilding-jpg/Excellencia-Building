# Plans d'armature détaillés (modèle bordereaux INBTP / TFL)

Fichier modifié : `calcul-structure/index.html` (+ cache `sw.js`). Aucun SQL.

## Ce qui change
- **Tableau d'armatures** (tous les plans) : N° | Description (HA..) | Forme (pictogramme : droit, coudé, crochets, cadre, épingle) | Repère | Espacement | Nombre | longueur (cm).
- **Cartouche** (tous les plans) : légende des armatures du plan + **caractéristiques des matériaux** (béton fc28, ft28, fbu ; acier fe, fsu), calculés selon la norme choisie.
- **Poteau** : élévation avec plancher bas hachuré, attentes coudées, cadres et épingles, règle des espacements (un trait par cadre), « hauteur du poteau », repères 1/2/3, coupes A-A (zone courante) et B-B (zone d'about) avec cadre à crochets 135° et épingles, formes CADRE (a-2c, b-2c, développé) et ÉPINGLE.
- **Poutre** : poteaux d'appui, crochets des barres, règle d'espacement des cadres, coupes A-A / B-B avec hauteur utile d, dalle (section en T, ou épaisseur de dalle transmise par le bâtiment), cadre à crochets.
- **Semelle** : vue en plan agrandie (nappes avec crochets, attentes, cotes), coupes A-A / B-B avec poteau, attentes coudées, cadres, béton de propreté.
- **Épingles** : le métré du poteau compte maintenant les épingles des barres intermédiaires (section rectangulaire, plus de 4 barres) ; poids et ratio d'acier en tiennent compte.

## Limites
- Poteaux d'appui de la poutre supposés de 30 cm ; plancher bas du poteau dessiné sans épaisseur cotée.
- fbu est la contrainte réelle du béton (0,85·fc28/γb), et non la valeur de ft28 recopiée sur les bordereaux de référence.
- Calculs indicatifs, à faire vérifier par un ingénieur.
