/* Excellencia Building V99zg — protection de la clé privée de licence (audit interne : risque « Haute »).
 * La clé privée d'administration (exb_lic_priv) n'est plus conservée durablement dans le stockage local de l'appareil :
 * elle est gardée en mémoire de session (sessionStorage) et disparaît à la fermeture de l'onglet / de l'application.
 * Pour la réutiliser : « Restaurer » depuis la sauvegarde chiffrée (Paramètres › Espace propriétaire) ou coller le fichier CLE-PRIVEE-ADMIN.txt.
 * Une clé déjà présente en stockage local n'est déplacée que si une sauvegarde chiffrée a été créée (exb_lic_backup_at),
 * pour ne jamais enfermer le propriétaire dehors. Doit être chargé AVANT exb-license.js, exb-proprietaire.js et exb-v81-securite.js. */
(function(w){'use strict';
var K='exb_lic_priv',B='exb_lic_backup_at',F='exb_lic_keep';
try{
  var SP=w.Storage&&w.Storage.prototype,L=w.localStorage,S=w.sessionStorage;
  if(!SP||!L||!S||SP.__exbKeyGuard)return;
  var gi=SP.getItem,si=SP.setItem,ri=SP.removeItem;
  SP.__exbKeyGuard=1;
  SP.getItem=function(k){if(this===L&&k===K){var v=gi.call(S,K);return v!=null?v:gi.call(L,K)}return gi.apply(this,arguments)};
  /* V99zu : option « garder la clé sur cet appareil » (F='1') → la clé reste en stockage local, comme avant l'audit */
  function keep(){return gi.call(L,F)==='1'}
  SP.setItem=function(k,v){if(this===L&&k===K){if(keep()){si.call(L,K,v);ri.call(S,K);return}si.call(S,K,v);ri.call(L,K);return}return si.apply(this,arguments)};
  SP.removeItem=function(k){if(this===L&&k===K){ri.call(S,K);ri.call(L,K);return}return ri.apply(this,arguments)};
  /* migration : seulement si une sauvegarde chiffrée existe */
  var cur=gi.call(L,K);
  if(cur&&!keep()&&gi.call(L,B)){si.call(S,K,cur);ri.call(L,K)}
  w.EXBKEY={keep:function(on){if(on===undefined)return keep();var v=gi.call(S,K);if(v==null)v=gi.call(L,K);
    if(on){si.call(L,F,'1');if(v!=null)si.call(L,K,v);ri.call(S,K)}else{ri.call(L,F);if(v!=null&&gi.call(L,B)){si.call(S,K,v);ri.call(L,K)}}return keep()},
  persistent:function(){return gi.call(L,K)!=null},session:function(){return gi.call(S,K)!=null},backedUp:function(){return gi.call(L,B)!=null}};
}catch(e){}
})(window);
