# V99zzh — L'assistant vocal guide partout (approbations, TP/TD, chantier, messages d'erreur)

**Aucun SQL.** Fichiers modifiés : `exb-guide.js`, `sw.js` (cache `exb-v99zzh-guide-partout-1`), `exb-v99r-shell.js` (version), `tools/e2e-guide.py` (+18 contrôles). Aucune donnée métier modifiée.

## Bilan de ce qui existait (V99zzg)
28 actions gardées : client, projet, devis (enregistrer / PDF / imprimer), caisse, stock, étude, participant, formation, formateur, planning, présences, paiement, reçu, certificat, cotation, évaluation, liste des participants, création de facture de chantier.
Les avertissements passant par `notify()` ou `alert()` étaient déjà lus (métré, chantiers, RH, communication…).

## Ce qui manquait (trouvé à l'audit) et ce qui est ajouté
1. **Approbations** (votre exemple « tu veux approuver mais tu as oublié quelque chose ») : `approveEntity` (participant, formateur, personnel RH) vérifie maintenant la **fiche** avant d'attribuer le matricule : nom, téléphone, formation (apprenant) ; nom, spécialité, téléphone (formateur) ; nom, fonction, téléphone (personnel). Il faut aussi qu'une formation existe pour approuver un apprenant. Sinon : voix + carte + bouton « ➡ Ouvrir Participants / Formateurs / Ressources humaines », et rien n'est approuvé. Les approbations automatiques (`silent`) ne sont jamais bloquées.
2. **Enregistrer + approuver** (voie directe du participant) : même contrôle, avec carte et surlignage des champs.
3. **TP / TD** : titre, matière, questions obligatoires, annoncés à voix haute (avant : message écrit seulement, sans voix).
4. **Chantier** : dépense (libellé, montant > 0) et enregistrement d'une facture (projet et client existants).
5. **Filet de sécurité partout** : tout message d'erreur écrit dans une zone de message de formulaire (classe `msg`, `*_msg`, `pm_local`) est lu à voix haute, même sans notification. Les messages de réussite (« ✓ ») ne sont pas lus.
6. **Calcul de structure** : l'écran est un iframe (même origine). Ses messages d'erreur (ex. « Indiquez le nom de l'ingénieur et son numéro d'inscription pour valider ») sont maintenant lus aussi.

## Limites (à lire)
- Les modules dont les fonctions sont privées (métré/devis rapide, calcul de structure, ERP V92, BTP V93, architecture V94, budget, planning CPM, finance V78) **ne reçoivent pas de carte d'étapes avec bouton** : leurs messages d'erreur existants sont lus, mais l'ordre des étapes n'y est pas contrôlé. Pour cela il faut déclarer chaque règle (champs et ordre) module par module : dites-moi les enchaînements voulus (ex. « pas d'approbation d'un décompte sans visa de l'ingénieur ») et je les ajoute.
- Pour le calcul de structure, le blocage d'export/impression d'une note non validée relève de ce module (il a déjà sa fiche « à remplir avant impression ») : la voix le lit, elle ne le remplace pas.
- Voix = synthèse vocale du navigateur (français). Sans voix, carte et surlignage restent.
- Le filet de lecture peut répéter un message déjà annoncé par une notification : un anti-doublon de 3,5 s limite cela.

## Tests
`python3 tools/e2e-guide.py` (navigateur, voix simulée) → tout passe (approbation bloquée/acceptée, formateur, TP/TD, messages de formulaire, iframe calcul de structure) · `node tools/check.js`.
Retour en arrière : restaurer `exb-guide.js`, `sw.js`, `exb-v99r-shell.js` de V99zzg.
