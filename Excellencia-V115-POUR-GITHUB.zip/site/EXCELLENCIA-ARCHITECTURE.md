# EXCELLENCIA BUILDING — Architecture Enterprise

## Architecture cible

- Core: Auth, Permissions, Organisation, Notifications, Audit, Sync
- ERP: CRM, Finance, Achats, Stocks, RH, Comptabilité
- BTP: Projets, Chantiers, Planning, QHSE, Matériel, Sous-traitance
- Architecture: Études, Plans, BIM, CDE
- Formation: Apprenants, Formations, Certifications
- AI: Copilot, Prévisions, Analyse, Reporting

## Principe de migration
La V90 reste rétrocompatible avec le noyau historique V81. Les anciens fichiers restent actifs; les dossiers ci-dessus constituent la couche Enterprise cible. Les nouveaux modules doivent exposer une interface stable et ne doivent pas modifier directement les données critiques sans passer par Core/Permissions/Audit.

## Flux métier cible
Prospect → CRM → Projet → Études → Plans/BIM/CDE → DQE/Devis → Contrat → Budget → Achats/Stocks/Sous-traitance → Chantier → QHSE/Planning → Situations/Factures → Finance/Comptabilité → Reporting/IA.

Formation → Apprenant → Formation → Présence/Évaluation → Paiement → Certification.

## V91 — Core runtime
Le dossier `core/` n'est plus uniquement documentaire. `core/index.js` expose le runtime `EXB_CORE` et les six adaptateurs spécialisés : auth, permissions, organisation, notifications, audit et sync. Les modules métiers peuvent désormais appeler ces services au lieu d'implémenter chacun leur propre logique transverse.
