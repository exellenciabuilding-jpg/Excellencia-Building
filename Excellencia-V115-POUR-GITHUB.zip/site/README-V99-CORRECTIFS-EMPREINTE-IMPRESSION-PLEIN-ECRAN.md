# Correctifs : empreinte, impression Windows, plein écran

1. **Empreinte / visage (Android)** : erreur « N.authenticate is not a function ». Le plugin n'expose que `internalAuthenticate` côté natif ; `exb-biometrie.js` appelle maintenant la bonne méthode.
2. **Empreinte / Windows Hello (Windows)** : « HTTPS requis ». WebAuthn est refusé sur `app://`. Electron demande désormais Windows Hello (empreinte, visage ou PIN) via `electron/preload.js` + `electron/main.js`. Windows Hello doit être configuré (Paramètres › Comptes › Options de connexion).
3. **Impression (Windows)** : boutons séparés « 📄 PDF » (crée le PDF, demande où l’enregistrer, l’ouvre) et « 🖨 Imprimer » (boîte Windows habituelle) dans les notes de calcul et l’éditeur de plans. Partout ailleurs, un clic sur Imprimer propose le choix PDF / Imprimer.
4. **Plein écran pour tous les modules** : nouveau bouton ⛶ dans la barre du haut (`site/exb-focus.js`). Bouton « ✕ Quitter le plein écran » en haut à droite, ou touche Échap / F.

Après dépôt : `cd electron && npm run prepare:www` puis reconstruire (`npm run dist`) ; Android : build habituel.
