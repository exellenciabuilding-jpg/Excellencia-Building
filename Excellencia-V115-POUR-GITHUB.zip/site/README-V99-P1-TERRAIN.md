# V99 — P1 Terrain : journal + QHSE + réserves

## Problèmes trouvés (audit du code)
1. Le journal de chantier stockait le projet dans `project_id`, QHSE/réserves/RFI dans `project`.
2. La saisie « Chantier hors ligne » écrivait `name` ; la liste Projet 360° affiche `title` → réserves et fiches HSE saisies sur le terrain apparaissaient **sans titre**.
3. Statuts différents selon l'écran (hors ligne : Levée / En cours ; Projet 360° : En correction / À vérifier / Action / Vérification). Le tableau de bord 360° comptait une réserve « Levée » comme ouverte.
4. Un incident noté dans le journal n'ouvrait aucune fiche QHSE.

## Correction
- `exb-terrain-unif.js` (nouveau) : migration automatique au démarrage, au retour du réseau et après chaque écriture. Idempotente, sans perte, sans doublon.
  - Ajoute `project`/`project_id` et `title`/`name` partout ; ancien statut gardé dans `status_orig` (Levée → Clôturée, En cours → En correction pour les réserves ou Action pour QHSE).
  - Chaque incident du journal crée une fiche QHSE liée (`from_journal`), une seule fois ; une fiche supprimée n'est pas recréée.
- `exb-v73-offline.js` : la saisie hors ligne utilise désormais les mêmes champs et les mêmes statuts que Projet 360°.
- `exb-v67.js` : écrit `project_id`, et le tableau de bord compte « ouvert » avec la même règle que le reste de l'application.

## Retour arrière
Console du navigateur : `EXBTerrain.undo()` restaure les anciennes valeurs (la migration reste alors désactivée) ; `EXBTerrain.enable()` la réactive.

## Tests
`node tools/test-terrain/test.js` : 15/15. `node tools/check.js` : 436 réussis, 0 échec. Chargement complet de index.html sans erreur.
Reste à tester : multi-appareils avec coupure puis retour du réseau (téléphone réel).
