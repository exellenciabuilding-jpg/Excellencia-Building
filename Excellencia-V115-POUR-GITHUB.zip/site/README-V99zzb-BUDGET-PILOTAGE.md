# V99zzb — Budget & pilotage financier (menu Finance › « 📊 Budget & pilotage »)

Aucun SQL à exécuter. Fichiers : `exb-budgetfin.js` (nouveau), `index.html` (1 balise), `sw.js` (cache `exb-v99zzb-budget-pilotage-1`), `exb-v99r-shell.js` (menu Finance, version), `exb-roles.js` (droits), `modules/exb-module-registry.js`, `tools/test-budgetfin.js`, `tools/e2e-budgetfin.py`.

## Les 4 outils (4 onglets)
1. **Budget mensuel** : revenus, dépenses fixes, prêts/dettes, dépenses variables, épargne/réserve. Chaque ligne a un **mot-clé** (ex. `loyer|bail`) : le « Réel » se calcule tout seul depuis la **caisse** (encaissements de factures inclus) et les paiements des apprenants. On peut remplacer le réel à la main (vide = automatique). Cartes, reste à vivre, répartition, copie du mois précédent, PDF. Les dépenses ajoutées ici sont enregistrées **dans la caisse** (une seule source de vérité, pas de double saisie).
2. **Comparatif** : deux périodes libres (+ raccourcis mois / trimestre / année), recettes, dépenses, résultat, marge, répartition par catégorie, écarts et %, graphiques, PDF.
3. **Annuel & TVA** : 12 mois, recettes, dépenses, résultat, TVA facturée (factures émises, hors annulées), TVA déductible (saisie), TVA à reverser, graphique, PDF.
4. **Fiche client** : coordonnées, projets liés, récapitulatif de période (factures, payées, à encaisser, facturé, encaissé, reste dû, annulées), factures filtrables par statut avec 💵 encaisser / 📄 PDF / 🚫 annuler, créances par client (top 10), PDF.

## Données
- Lit : `exb_cash`, `exb_payments`, `exb_invoices`, `exb_clients`, `exb_projects`, `exb_quotes`, `exb_finance` (taux FC pour 1 USD).
- Écrit : `exb_bf_budgets` (lignes de budget par mois), `exb_bf_tva` (TVA déductible), `exb_invoices` (seulement l'indicateur `annule`), `exb_cash` (dépenses ajoutées, marquées `bf:1`).
- Tout est converti en USD ; affichage USD ou FC (taux du jour de Finance). Une facture en FC sans taux enregistré est ignorée et signalée.
- Droits : section visible avec « lire » sur caisse ou factures ; lecture seule sans « écrire » sur la caisse.

## À savoir
- Un mouvement de caisse est rangé dans UNE seule ligne du budget (catégorie exacte d'abord, puis mot-clé) : pas de double comptage. Ce qui ne correspond à rien apparaît en « Non classé ».
- Une dépense modifiée ensuite avec l'ancien formulaire de la caisse perd sa catégorie « budget » (elle est alors classée par mots-clés).
- « Annuler » une facture l'exclut de ces tableaux uniquement ; le module Chantiers & finances la compte encore.
- La TVA déductible n'est pas calculée automatiquement (pas de TVA sur les factures d'achat dans les données).

## Tests
`node tools/test-budgetfin.js` (44 contrôles : classement, double comptage, devises, TVA, rapprochement client), `python3 tools/e2e-budgetfin.py` (navigateur, format téléphone), `node tools/check.js` (336 contrôles, 0 échec).
Non testé : la synchronisation Supabase des nouvelles clés `exb_bf_*`.
