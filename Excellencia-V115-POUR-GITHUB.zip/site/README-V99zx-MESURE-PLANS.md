# V99zx — Mesure sur plan avec échelle

Fichier modifié : `exb-v81-plans.js` (visionneuse de plans DXF et images), `sw.js` (cache `exb-v99zx-mesure-plans-1`), `exb-v99r-shell.js` (version), `tools/test-plans/test.py` (nouveau).
Pas de nouveau SQL : l'échelle et les mesures sont enregistrées dans la fiche du plan (`exb_plan_files`, champs `echelle` et `mesures`), donc partagées avec la fiche.

## Utilisation (Plans & fichiers CAO › ouvrir un plan DXF ou une image)
1. **📏 Échelle** : touchez deux points dont vous connaissez la distance réelle (ex. une cote de 10 m), saisissez cette distance en mètres. Pour un DXF dont l'unité est connue, **⚙ Unité** permet de saisir directement « 1 unité = 0,001 m » (dessin en millimètres), « 1 » (mètres)…
2. **↔ Distance** : 2 points. **〰 Longueur** : plusieurs points, puis « ✔ Terminer » (ou « ↩ Retirer le dernier »). **▱ Surface** : au moins 3 points, puis « ✔ Terminer ».
3. Chaque mesure reçoit un libellé et s'affiche sur le plan (valeur au centre, fond blanc) et dans la liste, avec le total en m et en m².
4. **⬇ CSV** (Excel, séparateur « ; ») ou **➕ Envoyer au métré** : les lignes arrivent dans *Métré béton armé › Matériaux ajoutés* (m² ou ml). Renvoyer met à jour les lignes (pas de doublon).
- Glisser = déplacer le plan ; toucher = placer un point. Sur un DXF, les points **s'accrochent aux extrémités** des lignes (à 14 px).
- L'échelle et les mesures sont conservées à la réouverture. Sans échelle, la mesure est refusée avec un message.

## Limites
- Précision = précision de l'échelle saisie et du pointage (zoomer pour viser) ; mesures **indicatives**, à contrôler avant chiffrage.
- PDF : lecture seule (pas de mesure) ; exporter en DXF ou image. Une image redimensionnée garde sa fiche mais l'échelle doit être refaite si le fichier est remplacé par un autre indice.
- Les mesures ne remplissent pas les cases du calcul béton armé (dimensions en cm) : elles s'ajoutent au devis, comme les quantités IFC.
- Pas encore de découpe visuelle des ouvertures dans les murs 3D (limite du lecteur IFC V99zw).

## Tests
`python3 tools/test-plans/test.py` : 14/14 (échelle, distance 11,66 m, longueur 16 m, surface 60 m², CSV, métré sans doublon, persistance, suppression). Connexion locale avec l'écran de licence retiré **dans le test seulement**.
