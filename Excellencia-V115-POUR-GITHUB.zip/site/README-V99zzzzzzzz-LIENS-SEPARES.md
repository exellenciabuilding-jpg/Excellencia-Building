# V99zzzzzzzz — Liens de formulaires : chaque profil copie SON lien

## Problème
Dans les boîtes « 📥 Demandes en ligne » (onglets Formateurs, Clients, Personnel, TP / TD…), les boutons **📋 Copier le lien**, **💬 WhatsApp** et **↗ Partager** donnaient toujours le lien **apprenant** (`inscription.html`), quel que soit l'onglet.
Cause : le bouton connaissait son onglet, mais la fonction qui fabrique le lien relisait une variable globale (`CUR`) que l'écran remet à « licences » ; le profil par défaut était alors « apprenant ».

## Correction (index.html)
- `link(t)`, `MSG(t)` et `copyLink(t)` reçoivent maintenant le type de l'onglet du bouton cliqué ; copier, WhatsApp et partager utilisent ce type.
- Le panneau « Demandes en ligne » (onglet Licences) propose le lien **Logiciel** ; il n'affiche plus de lien sur « Chantiers terrain » (pas de formulaire).
- Les boutons « 🔗 Copier le lien » des onglets Formateurs, Clients, Personnel, TP / TD et Apprenants indiquent maintenant explicitement leur profil (plus de déduction fragile via `window.event`) ; la détection de secours tient compte de la vraie visibilité de l'onglet.

## Liens (un par profil, rien d'autre n'est visible)
Apprenant `/inscription.html` · TP / TD `/demande-tp-td.html` · Formateur `/formateur.html` · Client `/client.html` · Personnel `/personnel.html` · Logiciel `/logiciel.html` · BTP `/btp.html`

## Après mise à jour
Déposer le ZIP sur Netlify (cache `exb-v99zzz-tfl-sans-limite-liens-separes-3`), pas de SQL, ouvrir le logiciel deux fois. Les liens déjà envoyés restent valables.

## Contrôle
Test navigateur (Chromium) : chaque bouton copie le bon fichier ; sur l'ancienne version, 4 boîtes sur 5 donnaient le lien apprenant.
