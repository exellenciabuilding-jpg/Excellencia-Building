/* EXBMAN — escalier manuel et dalle manuelle (façon ArchiCAD).
 * Géométrie pure, en mètres, sans dépendance : testable hors navigateur.
 *
 * ESCALIER MANUEL  st = { id, name, pts:[[x,y],…], w, h, n, rise, hole }
 *   pts  : ligne de foulée tracée à la main (départ en bas, arrivée en haut). Chaque segment est une volée ;
 *          chaque sommet intermédiaire devient un palier carré (largeur × largeur).
 *   w    : largeur d'emmarchement (m)            h : hauteur à franchir (m, 0/absent = niveau + dalle)
 *   n    : nombre de contremarches (0/absent = automatique)   rise : hauteur de marche visée (m)
 *   hole : false = pas de trémie automatique dans la dalle du dessus
 *
 * DALLE MANUELLE   sl = { id, name, pts:[[x,y],…], th, z, type, col }
 *   th : épaisseur (m)   z : décalage du dessus par rapport au sol fini du niveau (m)
 *   type : 'plancher' | 'balcon' | 'dallage' | 'terrasse'
 */
(function (root) {
  'use strict';
  var M = {};
  function r3(v) { return Math.round(v * 1000) / 1000; }
  function hyp(a, b) { return Math.hypot(b[0] - a[0], b[1] - a[1]); }

  /* ---------------------------------------------------------------- géométrie plane */
  M.polyArea = function (P) {
    var s = 0, i, a, b;
    for (i = 0; i < P.length; i++) { a = P[i]; b = P[(i + 1) % P.length]; s += a[0] * b[1] - b[0] * a[1]; }
    return Math.abs(s) / 2;
  };
  M.signedArea = function (P) {
    var s = 0, i, a, b;
    for (i = 0; i < P.length; i++) { a = P[i]; b = P[(i + 1) % P.length]; s += a[0] * b[1] - b[0] * a[1]; }
    return s / 2;
  };
  M.inPoly = function (p, P) {
    var c = false, i, j;
    for (i = 0, j = P.length - 1; i < P.length; j = i++) {
      if (((P[i][1] > p[1]) !== (P[j][1] > p[1])) &&
          (p[0] < (P[j][0] - P[i][0]) * (p[1] - P[i][1]) / (P[j][1] - P[i][1]) + P[i][0])) c = !c;
    }
    return c;
  };
  /* découpe d'un polygone par un demi-plan (Sutherland–Hodgman) : axis 0 = x, 1 = y ; keepLess = garder « ≤ val » */
  M.clipHP = function (P, axis, val, keepLess) {
    var out = [], n = P.length, i, a, b, da, db;
    if (!n) return out;
    for (i = 0; i < n; i++) {
      a = P[i]; b = P[(i + 1) % n];
      da = keepLess ? val - a[axis] : a[axis] - val;
      db = keepLess ? val - b[axis] : b[axis] - val;
      if (da >= 0) out.push(a);
      if ((da > 0 && db < 0) || (da < 0 && db > 0)) {
        var t = da / (da - db);
        out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
      }
    }
    return out;
  };
  /* polygone ∩ rectangle [x0,x1,y0,y1] */
  M.clipRect = function (P, h) {
    var q = M.clipHP(P, 0, h[0], false);
    q = M.clipHP(q, 0, h[1], true);
    q = M.clipHP(q, 1, h[2], false);
    q = M.clipHP(q, 1, h[3], true);
    return q;
  };
  /* aire du polygone (même concave) située dans le rectangle */
  M.polyRectArea = function (P, h) {
    var q = M.clipRect(P, h);
    return q.length >= 3 ? M.polyArea(q) : 0;
  };
  /* polygones CONVEXES moins un rectangle → liste de polygones convexes */
  M.subRect = function (polys, h) {
    var out = [];
    polys.forEach(function (P) {
      var A = M.clipHP(P, 0, h[0], true), B = M.clipHP(P, 0, h[1], false);
      var mid = M.clipHP(M.clipHP(P, 0, h[0], false), 0, h[1], true);
      var C = M.clipHP(mid, 1, h[2], true), D = M.clipHP(mid, 1, h[3], false);
      [A, B, C, D].forEach(function (Q) { if (Q.length >= 3 && M.polyArea(Q) > 1e-6) out.push(Q); });
    });
    return out;
  };
  /* découpage en triangles (oreilles) d'un polygone simple, même concave : renvoie des triplets de points */
  M.triangulate = function (P) {
    var n = P.length, idx = [], i, out = [], guard = 0;
    if (n < 3) return out;
    for (i = 0; i < n; i++) idx.push(i);
    if (M.signedArea(P) < 0) idx.reverse();
    function cross(a, b, c) { return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]); }
    function inTri(p, a, b, c) {
      var d1 = cross(a, b, p), d2 = cross(b, c, p), d3 = cross(c, a, p);
      return d1 >= -1e-12 && d2 >= -1e-12 && d3 >= -1e-12;
    }
    while (idx.length > 3 && guard++ < 5000) {
      var ear = false;
      for (i = 0; i < idx.length; i++) {
        var i0 = idx[(i + idx.length - 1) % idx.length], i1 = idx[i], i2 = idx[(i + 1) % idx.length];
        var a = P[i0], b = P[i1], c = P[i2];
        if (cross(a, b, c) <= 1e-12) continue;
        var ok = true, j;
        for (j = 0; j < idx.length; j++) {
          var k = idx[j];
          if (k === i0 || k === i1 || k === i2) continue;
          if (inTri(P[k], a, b, c)) { ok = false; break; }
        }
        if (!ok) continue;
        out.push([a, b, c]); idx.splice(i, 1); ear = true; break;
      }
      if (!ear) { /* contour dégénéré : on referme en éventail */
        for (i = 1; i < idx.length - 1; i++) out.push([P[idx[0]], P[idx[i]], P[idx[i + 1]]]);
        return out;
      }
    }
    if (idx.length === 3) out.push([P[idx[0]], P[idx[1]], P[idx[2]]]);
    return out;
  };
  /* morceaux convexes d'une dalle, trémies [x0,x1,y0,y1] retirées */
  M.slabPieces = function (poly, holes) {
    var pieces = [];
    M.triangulate(poly).forEach(function (t) {
      var ps = [t];
      (holes || []).forEach(function (h) { ps = M.subRect(ps, h); });
      ps.forEach(function (p) { pieces.push(p); });
    });
    return pieces;
  };
  M.bbox = function (P) {
    var x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
    P.forEach(function (p) { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); });
    return [x0, x1, y0, y1];
  };

  /* ---------------------------------------------------------------- dalle */
  M.slabDefaults = function (type) {
    return {
      plancher: { th: 0.2, z: 0 },
      balcon: { th: 0.15, z: 0 },
      terrasse: { th: 0.15, z: 0 },
      dallage: { th: 0.15, z: 0 }
    }[type] || { th: 0.2, z: 0 };
  };
  M.slabTypes = [['plancher', 'Plancher / dalle d’étage'], ['dallage', 'Dallage sur terre-plein'], ['balcon', 'Balcon / console'], ['terrasse', 'Terrasse']];
  M.slabArea = function (sl) { return M.polyArea(sl.pts || []); };
  /* aire nette (trémies déduites) */
  M.slabNetArea = function (sl, holes) {
    var a = M.slabArea(sl);
    (holes || []).forEach(function (h) { a -= M.polyRectArea(sl.pts, h); });
    return Math.max(0, a);
  };

  /* ---------------------------------------------------------------- escalier */
  M.stairDefaults = { w: 1.0, rise: 0.175 };

  /* Calcule la disposition : volées, paliers, marches. levelRise = hauteur par défaut à franchir. */
  M.stairLayout = function (st, levelRise) {
    var P = [], i;
    (st.pts || []).forEach(function (p) {
      if (!P.length || hyp(P[P.length - 1], p) >= 0.05) P.push([p[0], p[1]]);
    });
    if (P.length < 2) return null;
    var w = st.w > 0.3 ? st.w : M.stairDefaults.w;
    var h = st.h > 0.3 ? st.h : (levelRise > 0.3 ? levelRise : 3.0);
    var F = P.length - 1, hw = w / 2;
    var fl = [];
    for (i = 0; i < F; i++) {
      var a = P[i], b = P[i + 1], len = hyp(a, b), ux = (b[0] - a[0]) / len, uy = (b[1] - a[1]) / len;
      var s0 = i > 0 ? hw : 0, s1 = i < F - 1 ? hw : 0;
      var run = Math.max(0, len - s0 - s1);
      fl.push({ i: i, a: a, b: b, u: [ux, uy], len: len, run: run, s0: s0, s1: s1 });
    }
    var sumRun = 0; fl.forEach(function (f) { sumRun += f.run; });
    if (sumRun < 0.2) return null;
    var N = st.n > 0 ? Math.round(st.n) : Math.max(2, Math.round(h / (st.rise > 0.1 ? st.rise : M.stairDefaults.rise)));
    if (N < 2) N = 2;
    var r = h / N;
    /* répartition des contremarches au prorata des longueurs de volée (plus fort reste).
       Un tronçon intermédiaire très court (demi-tour en U) ne porte aucune marche : il prolonge le palier. */
    var flat = fl.map(function (f, k) { return k < F - 1 && f.run < 0.35; });
    var sumRun2 = 0; fl.forEach(function (f, k) { if (!flat[k]) sumRun2 += f.run; });
    if (sumRun2 < 0.2) { flat = flat.map(function () { return false; }); sumRun2 = sumRun; }
    var raw = fl.map(function (f, k) { return flat[k] ? 0 : N * f.run / sumRun2; });
    var nf = raw.map(function (v) { return Math.floor(v); });
    var left = N - nf.reduce(function (s, v) { return s + v; }, 0);
    var order = raw.map(function (v, k) { return [v - Math.floor(v), k]; }).sort(function (x, y) { return y[0] - x[0]; });
    for (i = 0; left > 0 && i < order.length; i++, left--) nf[order[i][1]]++;
    /* une volée qui porte des marches en reçoit au moins une */
    fl.forEach(function (f, k) {
      if (!flat[k] && f.run > 0.05 && nf[k] < 1) {
        var big = 0, q; for (q = 1; q < nf.length; q++) if (nf[q] > nf[big]) big = q;
        if (nf[big] > 1) { nf[big]--; nf[k]++; }
      }
    });
    var cum = 0, steps = [], landings = [], treadLines = [], quads = [];
    fl.forEach(function (f, k) {
      f.n = nf[k]; f.z0 = cum * r;
      var last = (k === F - 1);
      f.treads = last ? f.n : Math.max(0, f.n - 1);
      f.g = f.treads > 0 ? f.run / f.treads : 0;
      f.S = [f.a[0] + f.u[0] * f.s0, f.a[1] + f.u[1] * f.s0];
      f.E = [f.S[0] + f.u[0] * f.run, f.S[1] + f.u[1] * f.run];
      f.nx = -f.u[1]; f.ny = f.u[0];                    /* normale à gauche du sens de montée */
      var j;
      for (j = 1; j <= f.treads; j++) {
        var d0 = (j - 1) * f.g, d1 = j * f.g, zt = (cum + j) * r;
        var c0 = [f.S[0] + f.u[0] * d0, f.S[1] + f.u[1] * d0], c1 = [f.S[0] + f.u[0] * d1, f.S[1] + f.u[1] * d1];
        steps.push({ f: k, j: j, z: zt, q: [
          [c0[0] + f.nx * hw, c0[1] + f.ny * hw], [c1[0] + f.nx * hw, c1[1] + f.ny * hw],
          [c1[0] - f.nx * hw, c1[1] - f.ny * hw], [c0[0] - f.nx * hw, c0[1] - f.ny * hw]] });
        treadLines.push([[c1[0] + f.nx * hw, c1[1] + f.ny * hw], [c1[0] - f.nx * hw, c1[1] - f.ny * hw]]);
      }
      if (f.run > 0.02) quads.push([
        [f.S[0] + f.nx * hw, f.S[1] + f.ny * hw], [f.E[0] + f.nx * hw, f.E[1] + f.ny * hw],
        [f.E[0] - f.nx * hw, f.E[1] - f.ny * hw], [f.S[0] - f.nx * hw, f.S[1] - f.ny * hw]]);
      cum += f.n;
      f.z1 = cum * r;
      if (!last) {
        /* palier carré centré sur le sommet, aligné sur la volée qui arrive puis sur celle qui repart */
        var v = f.b, nx = fl[k + 1];
        var sq = function (u) {
          var n2 = [-u[1], u[0]];
          return [[v[0] + u[0] * hw + n2[0] * hw, v[1] + u[1] * hw + n2[1] * hw], [v[0] + u[0] * hw - n2[0] * hw, v[1] + u[1] * hw - n2[1] * hw],
                  [v[0] - u[0] * hw - n2[0] * hw, v[1] - u[1] * hw - n2[1] * hw], [v[0] - u[0] * hw + n2[0] * hw, v[1] - u[1] * hw + n2[1] * hw]];
        };
        var cr = f.u[0] * nx.u[1] - f.u[1] * nx.u[0];
        landings.push({ at: k, v: v, z: cum * r, u: f.u, rot: f.u, q: sq(f.u), twin: Math.abs(cr) > 0.02 && Math.abs(f.u[0] * nx.u[0] + f.u[1] * nx.u[1]) > 0.02 ? sq(nx.u) : null });
      }
    });
    var tot = 0; fl.forEach(function (f) { tot += f.treads; });
    var length = 0; fl.forEach(function (f) { length += f.len; });
    return { pts: P, w: w, h: h, N: N, r: r, flights: fl, steps: steps, landings: landings, quads: quads, treadLines: treadLines,
             treads: tot, length: length, giron: tot ? sumRun / tot : 0 };
  };

  /* angle (degrés) du champ « rot » d'un objet du plan pour que son axe local +y suive la direction u */
  M.rotOf = function (u) { return Math.atan2(-u[0], u[1]) * 180 / Math.PI; };

  /* Entrées « meuble » pour la scène 3D / coupes / visite : une par volée et par palier (boîtes pleines). */
  M.furnEntries = function (st, levelRise, idBase) {
    var L = M.stairLayout(st, levelRise);
    if (!L) return [];
    var out = [], hh = L.h, i;
    var C1 = '#e2e8f0', C2 = '#cbd5e1', CL = '#d6dce5';
    L.flights.forEach(function (f, k) {
      if (f.run < 0.02) return;
      if (f.treads < 1) {   /* tronçon plat entre deux paliers : plancher plein à la cote du palier */
        out.push({ id: st.id, tt: 'q', x: r3(f.S[0] + f.u[0] * f.run / 2), y: r3(f.S[1] + f.u[1] * f.run / 2),
          w: L.w, d: f.run, h: hh, rot: M.rotOf(f.u), k: 'escalier_man', z: 0, stair: true, solid: false,
          parts: [[0, 0, 0, 1, 1, f.z0 / hh, CL]] });
        return;
      }
      var parts = [], j;
      for (j = 1; j <= f.treads; j++) {
        var zt = (f.z0 + j * L.r) / hh;
        parts.push([0, (j - 1) / f.treads, 0, 1, j / f.treads, zt, j % 2 ? C1 : C2]);
      }
      out.push({ id: st.id, tt: 'q', x: r3(f.S[0] + f.u[0] * f.run / 2), y: r3(f.S[1] + f.u[1] * f.run / 2),
        w: L.w, d: f.run, h: hh, rot: M.rotOf(f.u), k: 'escalier_man', z: 0, stair: true, solid: false, parts: parts });
    });
    L.landings.forEach(function (lg) {
      [lg.q, lg.twin].forEach(function (q) {
        if (!q) return;
        var cx = (q[0][0] + q[2][0]) / 2, cy = (q[0][1] + q[2][1]) / 2;
        var u = [q[0][0] - q[3][0], q[0][1] - q[3][1]], ul = Math.hypot(u[0], u[1]) || 1; u = [u[0] / ul, u[1] / ul];
        out.push({ id: st.id, tt: 'q', x: r3(cx), y: r3(cy), w: L.w, d: L.w, h: hh, rot: M.rotOf(u), k: 'escalier_man', z: 0, stair: true, solid: false,
          parts: [[0, 0, 0, 1, 1, lg.z / hh, CL]] });
      });
    });
    return out;
  };

  /* Trémies [x0,x1,y0,y1] dans la dalle du niveau supérieur : parties de l'escalier qui passent
   * dans la hauteur de passage (2,10 m sous le plafond) : une trémie rectangulaire par volée / palier concerné. */
  M.holeRects = function (st, levelRise, headroom) {
    if (st.hole === false) return [];
    var L = M.stairLayout(st, levelRise);
    if (!L) return [];
    var hd = headroom > 0 ? headroom : 2.1, lim = L.h - hd, rects = [];
    function bb(q) { return M.bbox(q); }
    L.flights.forEach(function (f) {
      if (f.treads < 1) return;
      if (f.z1 < lim - 1e-6) return;
      /* tranche de la volée au-dessus de la cote limite */
      var t0 = Math.max(0, Math.min(f.treads, Math.floor((lim - f.z0) / L.r)));
      var d0 = t0 * f.g, S = [f.S[0] + f.u[0] * d0, f.S[1] + f.u[1] * d0], hw = L.w / 2;
      var E = f.E;
      rects.push(bb([[S[0] + f.nx * hw, S[1] + f.ny * hw], [E[0] + f.nx * hw, E[1] + f.ny * hw], [E[0] - f.nx * hw, E[1] - f.ny * hw], [S[0] - f.nx * hw, S[1] - f.ny * hw]]));
    });
    L.landings.forEach(function (lg) {
      if (lg.z < lim - 1e-6) return;
      rects.push(bb(lg.q)); if (lg.twin) rects.push(bb(lg.twin));
    });
    return rects.map(function (r) { return [r3(r[0] - 0.02), r3(r[1] + 0.02), r3(r[2] - 0.02), r3(r[3] + 0.02)]; });
  };

  /* le point p touche-t-il l'escalier ? */
  M.stairHit = function (st, p, levelRise, tol) {
    var L = M.stairLayout(st, levelRise), i;
    if (!L) return false;
    for (i = 0; i < L.quads.length; i++) if (M.inPoly(p, L.quads[i])) return true;
    for (i = 0; i < L.landings.length; i++) { if (M.inPoly(p, L.landings[i].q)) return true; if (L.landings[i].twin && M.inPoly(p, L.landings[i].twin)) return true; }
    return false;
  };
  M.stairBBox = function (st, levelRise) {
    var L = M.stairLayout(st, levelRise), pts = [];
    if (!L) return M.bbox(st.pts || [[0, 0]]);
    L.quads.forEach(function (q) { q.forEach(function (p) { pts.push(p); }); });
    L.landings.forEach(function (lg) { lg.q.forEach(function (p) { pts.push(p); }); });
    return pts.length ? M.bbox(pts) : M.bbox(st.pts);
  };

  /* synthèse pour la fiche et le métré */
  M.stairInfo = function (st, levelRise) {
    var L = M.stairLayout(st, levelRise);
    if (!L) return null;
    var vol = 0;
    L.flights.forEach(function (f) {
      var j; for (j = 1; j <= f.treads; j++) vol += L.w * f.g * (f.z0 + j * L.r);
    });
    L.landings.forEach(function (lg) { vol += L.w * L.w * lg.z; });
    return { N: L.N, treads: L.treads, r: L.r, giron: L.giron, w: L.w, h: L.h, flights: L.flights.length, landings: L.landings.length,
             length: L.length, vol: vol, blondel: 2 * L.r + L.giron };
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = M;
  root.EXBMAN = M;
})(typeof window !== 'undefined' ? window : globalThis);
