/* Maillage de terrain (V99) : triangulation de Delaunay de points cotés, courbes de niveau, volumes déblai / remblai.
 * Points : {x,y,z} en mètres (x,y = plan, z = altitude par rapport au niveau 0 du RDC). */
(function(w){
function circum(a,b,c){var d=2*(a[0]*(b[1]-c[1])+b[0]*(c[1]-a[1])+c[0]*(a[1]-b[1]));if(Math.abs(d)<1e-12)return null;
 var a2=a[0]*a[0]+a[1]*a[1],b2=b[0]*b[0]+b[1]*b[1],c2=c[0]*c[0]+c[1]*c[1],ux=(a2*(b[1]-c[1])+b2*(c[1]-a[1])+c2*(a[1]-b[1]))/d,uy=(a2*(c[0]-b[0])+b2*(a[0]-c[0])+c2*(b[0]-a[0]))/d;
 return{x:ux,y:uy,r2:(a[0]-ux)*(a[0]-ux)+(a[1]-uy)*(a[1]-uy)}}
function triangulate(P){var n=P.length;if(n<3)return[];var i,minx=1e9,miny=1e9,maxx=-1e9,maxy=-1e9;
 P.forEach(function(p){minx=Math.min(minx,p.x);maxx=Math.max(maxx,p.x);miny=Math.min(miny,p.y);maxy=Math.max(maxy,p.y)});
 var d=Math.max(maxx-minx,maxy-miny,1)*20,cx=(minx+maxx)/2,cy=(miny+maxy)/2,V=P.map(function(p){return[p.x,p.y]});
 V.push([cx-d,cy-d],[cx+d,cy-d],[cx,cy+d]);
 var T=[[n,n+1,n+2]];T[0].c=circum(V[n],V[n+1],V[n+2]);
 for(i=0;i<n;i++){var bad=[],keep=[];T.forEach(function(t){var c=t.c;if(c&&(V[i][0]-c.x)*(V[i][0]-c.x)+(V[i][1]-c.y)*(V[i][1]-c.y)<=c.r2*(1+1e-9))bad.push(t);else keep.push(t)});
  var E={};bad.forEach(function(t){[[t[0],t[1]],[t[1],t[2]],[t[2],t[0]]].forEach(function(e){var k=Math.min(e[0],e[1])+'_'+Math.max(e[0],e[1]);E[k]=E[k]?null:e})});
  T=keep;Object.keys(E).forEach(function(k){var e=E[k];if(!e)return;var nt=[e[0],e[1],i];nt.c=circum(V[e[0]],V[e[1]],V[i]);if(nt.c)T.push(nt)})}
 return T.filter(function(t){return t[0]<n&&t[1]<n&&t[2]<n}).map(function(t){return[t[0],t[1],t[2]]})}
function contours(P,T,step){var out=[];T.forEach(function(t){var a=P[t[0]],b=P[t[1]],c=P[t[2]],lo=Math.min(a.z,b.z,c.z),hi=Math.max(a.z,b.z,c.z),k;
 for(k=Math.ceil(lo/step-1e-9);k*step<=hi+1e-9;k++){var z=k*step,pts=[];
  [[a,b],[b,c],[c,a]].forEach(function(e){var p=e[0],q=e[1];if((p.z-z)*(q.z-z)<0||(p.z===z&&q.z!==z&&false)){var f=(z-p.z)/(q.z-p.z);pts.push([p.x+f*(q.x-p.x),p.y+f*(q.y-p.y)])}});
  if(pts.length===2)out.push({z:z,a:pts[0],b:pts[1],k:k})}});return out}
function stats(P,T,base){var area=0,cut=0,fill=0;base=base||0;
 T.forEach(function(t){var a=P[t[0]],b=P[t[1]],c=P[t[2]],N=4,i,j;function pt(u,v){return[a.x+u*(b.x-a.x)+v*(c.x-a.x),a.y+u*(b.y-a.y)+v*(c.y-a.y),a.z+u*(b.z-a.z)+v*(c.z-a.z)]}
  var A=Math.abs((b.x-a.x)*(c.y-a.y)-(c.x-a.x)*(b.y-a.y))/2;area+=A;var sa=A/(N*N);
  for(i=0;i<N;i++)for(j=0;j<N-i;j++){var q=pt((i+1/3)/N,(j+1/3)/N),h=q[2]-base;if(h>0)cut+=h*sa;else fill-=h*sa;
   if(j<N-i-1){var q2=pt((i+2/3)/N,(j+2/3)/N),h2=q2[2]-base;if(h2>0)cut+=h2*sa;else fill-=h2*sa}}});
 return{area:area,cut:cut,fill:fill}}
w.EXBTERR={triangulate:triangulate,contours:contours,stats:stats}})(window);
