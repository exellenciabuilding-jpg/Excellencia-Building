/* Catalogue de l'éditeur de plan : mobilier / équipements, points électriques, circuits.
 * Mobilier : dimensions par défaut (m) et « pièces » 3D construites en mètres avec b(x0,y0,z0,x1,y1,z1,couleur,forme,param,matériau) : boîtes, boîtes arrondies, cylindres, cônes, ellipsoïdes (V4.6).
 * Pour ajouter un meuble : une entrée dans FURN (cat « Cuisine » et « Sanitaire » = équipements, toujours comptés au métré). */
(function(w){'use strict';
/* Constructeur de pièces 3D en MÈTRES : b(x0,y0,z0, x1,y1,z1, couleur, forme, paramètre, matériau)
 * repère local : x = largeur (gauche→droite), y = profondeur (0 = dos du meuble), z = hauteur (0 = sol).
 * formes : 'b' boîte · 'r' arêtes arrondies (paramètre = rayon en m) · 'c' cylindre · 'k' cône tronqué (paramètre = rapport haut/bas) · 'e' ellipsoïde
 * matériau (facultatif) : 10 = métal brillant (poignées, robinets), 8 = bois, 11 = feuillage. Les pièces sont converties en fractions de (largeur, profondeur, hauteur). */
function mk(w,d,h){var a=[],o={a:a,b:function(x0,y0,z0,x1,y1,z1,c,sh,pa,mt){a.push([x0/w,y0/d,z0/h,x1/w,y1/d,z1/h,c,sh||'b',pa,mt]);return o}};return o}
var BOIS='#a98467',BOIS2='#b08968',BOISD='#7c5e46',METAL='#cbd5e1',NOIR='#111827',BLANC='#f8fafc';
function pieds4(o,w,d,z1,col,r,ins){ins=ins||.05;r=r||.025;[[ins,ins],[w-ins,ins],[ins,d-ins],[w-ins,d-ins]].forEach(function(p){o.b(p[0]-r,p[1]-r,0,p[0]+r,p[1]+r,z1,col,'k',.7)})}
function poignee(o,x,y,z,len,vert){if(vert)o.b(x-.008,y,z,x+.008,y+.035,z+len,METAL,'c',null,10);else o.b(x,y,z-.008,x+len,y+.035,z+.008,METAL,'c',null,10)}
function coussinsAssise(o,x0,x1,y0,y1,zb,n,col,colD){var cw=(x1-x0)/n,i;for(i=0;i<n;i++){o.b(x0+i*cw+.012,y0+.2,zb,x0+(i+1)*cw-.012,y1,zb+.14,col,'r',.055);o.b(x0+i*cw+.04,y0+.04,zb+.14,x0+(i+1)*cw-.04,y0+.26,zb+.46,colD,'r',.08)}}
var F={};
F.lit2=(function(){var o=mk(1.6,2.0,1.0);pieds4(o,1.6,2.0,.12,'#5b4330',.03,.06);
 o.b(0,0,.12,1.6,2.0,.3,'#8b6b4a','r',.025).b(0,0,.12,1.6,.08,1.0,'#7a5a3c','r',.035).b(.04,.08,.3,1.56,1.98,.5,'#f1f5f9','r',.07)
  .b(.03,.62,.42,1.57,1.99,.56,'#a9c1db','r',.06).b(.03,.55,.5,1.57,.74,.58,'#e8eef6','r',.04)
  .b(.12,.14,.5,.76,.54,.64,'#ffffff','r',.09).b(.84,.14,.5,1.48,.54,.64,'#ffffff','r',.09).b(0,1.92,.12,1.6,2.0,.42,'#7a5a3c','r',.02);return o.a})();
F.lit1=(function(){var o=mk(.9,2.0,.9);pieds4(o,.9,2.0,.12,'#5b4330',.03,.05);
 o.b(0,0,.12,.9,2.0,.3,'#8b6b4a','r',.025).b(0,0,.12,.9,.07,.9,'#7a5a3c','r',.03).b(.03,.07,.3,.87,1.98,.5,'#f1f5f9','r',.06)
  .b(.02,.6,.42,.88,1.99,.56,'#c4b5a0','r',.05).b(.02,.54,.5,.88,.72,.57,'#efe9df','r',.035).b(.1,.12,.5,.8,.52,.63,'#ffffff','r',.08);return o.a})();
F.armoire=(function(){var o=mk(1.2,.6,2.0);
 o.b(.02,.02,0,1.18,.56,.07,'#4a3a2c').b(0,0,.07,1.2,.6,1.96,BOIS,'r',.008).b(-0.0,-0.0,1.96,1.2,.62,2.0,'#8f7358','r',.01)
  .b(.02,.57,.1,.595,.6,1.92,'#b08968','r',.006).b(.605,.57,.1,1.18,.6,1.92,'#b08968','r',.006);
 poignee(o,.55,.6,.85,.28,true);poignee(o,.65,.6,.85,.28,true);return o.a})();
F.chevet=(function(){var o=mk(.45,.4,.5);pieds4(o,.45,.4,.1,'#6b4f35',.018,.04);
 o.b(0,0,.43,.45,.4,.5,BOIS2,'r',.01).b(.015,.015,.1,.435,.385,.43,BOIS,'r',.008).b(.03,.385,.27,.42,.4,.41,'#b9946f','r',.006).b(.03,.385,.13,.42,.4,.255,'#b9946f','r',.006);
 o.b(.19,.4,.33,.26,.425,.35,METAL,'c',null,10).b(.19,.4,.18,.26,.425,.2,METAL,'c',null,10);return o.a})();
F.canape=(function(){var o=mk(2.0,.9,.85);
 [[.1,.12],[1.9,.12],[.1,.78],[1.9,.78]].forEach(function(p){o.b(p[0]-.03,p[1]-.03,0,p[0]+.03,p[1]+.03,.1,'#2a2f3a','k',.8)});
 o.b(.02,.02,.1,1.98,.88,.36,'#4d5b70','r',.04).b(0,0,.1,.19,.9,.62,'#586882','r',.07).b(1.81,0,.1,2,.9,.62,'#586882','r',.07).b(.19,0,.1,1.81,.26,.85,'#64748b','r',.08);
 coussinsAssise(o,.19,1.81,.0,.9,.36,3,'#64748b','#718096');return o.a})();
F.fauteuil=(function(){var o=mk(.85,.85,.85);
 [[.1,.1],[.75,.1],[.1,.75],[.75,.75]].forEach(function(p){o.b(p[0]-.03,p[1]-.03,0,p[0]+.03,p[1]+.03,.1,'#2a2f3a','k',.8)});
 o.b(.02,.02,.1,.83,.83,.34,'#4d5b70','r',.04).b(0,0,.1,.16,.85,.6,'#586882','r',.07).b(.69,0,.1,.85,.85,.6,'#586882','r',.07).b(.16,0,.1,.69,.24,.85,'#64748b','r',.08);
 coussinsAssise(o,.16,.69,0,.85,.34,1,'#64748b','#718096');return o.a})();
F.tablebasse=(function(){var o=mk(1,.6,.4);pieds4(o,1,.6,.36,BOISD,.022,.07);
 o.b(0,0,.36,1,.6,.4,BOIS2,'r',.015).b(.07,.07,.12,.93,.53,.14,'#8d6e53','r',.005);o.b(.4,.2,.405,.6,.4,.42,'#f8fafc','r',.01);return o.a})();
F.tv=(function(){var o=mk(1.6,.4,1.0);pieds4(o,1.6,.4,.1,'#2a2f3a',.02,.06);
 o.b(0,0,.1,1.6,.4,.5,'#6b4f35','r',.012).b(.02,.385,.13,.52,.4,.47,'#7c5e46','r',.006).b(.54,.385,.13,1.06,.4,.47,'#7c5e46','r',.006).b(1.08,.385,.13,1.58,.4,.47,'#7c5e46','r',.006);
 o.b(.7,.14,.5,.9,.28,.55,'#1f2937','r',.01).b(.72,.19,.55,.88,.23,.6,'#1f2937').b(.2,.17,.6,1.4,.23,1.0,NOIR,'r',.012).b(.22,.168,.62,1.38,.172,.98,'#0b1220');return o.a})();
F.etagere=(function(){var o=mk(.9,.35,1.8),i,cols=['#c2410c','#1d4ed8','#15803d','#a16207','#7c3aed','#0e7490'];
 o.b(0,0,0,.025,.35,1.8,BOIS).b(.875,0,0,.9,.35,1.8,BOIS).b(.025,0,0,.875,.01,1.8,'#8f7358');
 for(i=0;i<6;i++)o.b(.025,.01,i*.34,.875,.35,i*.34+.025,BOIS2);
 for(i=0;i<5;i++){var x=.06+((i*37)%5)*.04,z=.025+i*.34,k;for(k=0;k<4;k++){o.b(x+k*.05,.06,z,x+k*.05+.04,.28,z+.2+(k%2)*.04,cols[(i+k)%6],'r',.004)}}return o.a})();
F.table=(function(){var o=mk(1.6,.9,.75);[[.1,.1],[1.5,.1],[.1,.8],[1.5,.8]].forEach(function(p){o.b(p[0]-.035,p[1]-.035,0,p[0]+.035,p[1]+.035,.71,BOISD,'k',.75)});
 o.b(0,0,.71,1.6,.9,.75,BOIS2,'r',.018).b(.06,.06,.66,1.54,.84,.71,'#8d6e53');return o.a})();
F.chaise=(function(){var o=mk(.45,.45,.9);
 [[.04,.04,.0],[.41,.04,0],[.04,.41,0],[.41,.41,0]].forEach(function(p){o.b(p[0]-.015,p[1]-.015,0,p[0]+.015,p[1]+.015,.43,BOISD,'c')});
 o.b(.025,.025,.43,.425,.425,.47,BOIS,'r',.012).b(.04,.07,.47,.41,.42,.51,'#d6dbe4','r',.02).b(.025,.025,.47,.065,.065,.9,BOISD,'c').b(.385,.025,.47,.425,.065,.9,BOISD,'c')
  .b(.04,.025,.62,.41,.06,.84,BOIS,'r',.012);return o.a})();
F.bureau=(function(){var o=mk(1.4,.7,.75),i;
 o.b(0,0,.72,1.4,.7,.75,BOIS2,'r',.012).b(.0,.02,0,.46,.68,.72,'#8d6e53','r',.008).b(1.34,.02,0,1.4,.68,.72,'#8d6e53').b(.46,.66,.25,1.34,.68,.7,'#7c5e46');
 for(i=0;i<3;i++){o.b(.02,.675,.04+i*.22,.44,.69,.24+i*.22,'#a98467','r',.005);o.b(.2,.69,.13+i*.22,.26,.715,.15+i*.22,METAL,'c',null,10)}
 o.b(.78,.12,.75,1.02,.34,.77,'#e5e7eb','r',.01).b(.8,.14,.77,1.0,.32,.78,'#1f2937');return o.a})();
F.comptoir=(function(){var o=mk(1.2,.6,.9);
 o.b(.02,.02,0,1.18,.5,.1,'#475569').b(0,0,.1,1.2,.6,.86,'#e2e8f0','r',.008).b(-0.0,-0.0,.86,1.2,.6,.9,'#475569','r',.006)
  .b(.015,.585,.12,.595,.6,.84,'#f1f5f9','r',.004).b(.605,.585,.12,1.185,.6,.84,'#f1f5f9','r',.004);poignee(o,.5,.6,.55,.12,true);poignee(o,.7,.6,.55,.12,true);return o.a})();
F.evier=(function(){var o=mk(.9,.6,.9);
 o.b(.02,.02,0,.88,.5,.1,'#475569').b(0,0,.1,.9,.6,.86,'#e2e8f0','r',.008).b(0,0,.86,.9,.6,.9,'#475569','r',.006)
  .b(.07,.1,.895,.43,.5,.905,'#cbd5e1').b(.1,.13,.9,.4,.47,.91,'#94a3b8').b(.47,.1,.895,.83,.5,.905,'#cbd5e1').b(.5,.13,.9,.8,.47,.91,'#94a3b8')
  .b(.06,.04,.9,.1,.08,1.05,METAL,'c',null,10).b(.06,.04,1.02,.1,.2,1.06,METAL,'c',null,10).b(.015,.585,.12,.445,.6,.84,'#f1f5f9','r',.004).b(.455,.585,.12,.885,.6,.84,'#f1f5f9','r',.004);
 poignee(o,.4,.6,.55,.12,true);poignee(o,.5,.6,.55,.12,true);return o.a})();
F.cuisiniere=(function(){var o=mk(.6,.6,.9);
 o.b(0,0,0,.6,.6,.88,'#cbd5e1','r',.012).b(0,0,.88,.6,.6,.9,NOIR,'r',.004);
 [[.15,.17],[.45,.17],[.15,.43],[.45,.43]].forEach(function(p,i){var r=i%3===0?.065:.05;o.b(p[0]-r,p[1]-r,.9,p[0]+r,p[1]+r,.915,'#1f2937','c');o.b(p[0]-r*.45,p[1]-r*.45,.915,p[0]+r*.45,p[1]+r*.45,.925,'#4b5563','c')});
 o.b(.04,.575,.1,.56,.6,.62,'#94a3b8','r',.008).b(.1,.585,.2,.5,.6,.5,'#0f172a','r',.004);o.b(.06,.6,.6,.54,.63,.625,METAL,'c',null,10);
 [.12,.24,.36,.48].forEach(function(x){o.b(x-.015,.6,.7,x+.015,.62,.8,'#374151','c')});return o.a})();
F.frigo=(function(){var o=mk(.65,.65,1.8);
 o.b(0,0,0,.65,.65,1.8,'#e5e7eb','r',.025).b(.005,.645,.6,.645,.66,.615,'#6b7280').b(.04,.65,.05,.61,.66,.58,'#eceff3','r',.01).b(.04,.65,.63,.61,.66,1.76,'#eceff3','r',.01);
 o.b(.07,.66,1.0,.09,.7,1.5,METAL,'c',null,10).b(.07,.66,.2,.09,.7,.5,METAL,'c',null,10);return o.a})();
F.wc=(function(){var o=mk(.4,.7,.8);
 o.b(.03,0,.38,.37,.17,.82,BLANC,'r',.03).b(.12,0,.82,.28,.05,.85,METAL,'c',null,10).b(.1,.2,.0,.3,.5,.3,'#eef2f7','k',.8).b(.1,.2,.0,.3,.5,.25,'#eef2f7','r',.03)
  .b(0,.17,.16,.4,.7,.45,BLANC,'e').b(.01,.2,.4,.39,.69,.45,'#ffffff','c').b(.07,.26,.405,.33,.63,.455,'#bae6fd','c');return o.a})();
F.lavabo=(function(){var o=mk(.6,.5,.85);
 o.b(.22,.1,0,.38,.26,.72,'#eef2f7','k',.9).b(0,0,.72,.6,.5,.85,BLANC,'r',.07).b(.07,.07,.835,.53,.43,.86,'#dbeafe','r',.05)
  .b(.27,.03,.85,.33,.09,.96,METAL,'c',null,10).b(.27,.03,.93,.33,.16,.97,METAL,'c',null,10).b(.46,.04,.85,.5,.08,.92,METAL,'c',null,10);return o.a})();
F.douche=(function(){var o=mk(.9,.9,.12);
 o.b(0,0,0,.9,.9,.1,'#f1f5f9','r',.015).b(.05,.05,.095,.85,.85,.108,'#dbeafe','r',.01).b(.41,.41,.1,.49,.49,.112,METAL,'c',null,10)
  .b(.03,.03,.1,.06,.06,2.1,METAL,'c',null,10).b(.03,.03,2.0,.3,.1,2.05,METAL,'c',null,10).b(.2,.06,1.98,.34,.2,2.0,'#e5e7eb','c');return o.a})();
F.baignoire=(function(){var o=mk(1.7,.75,.55);
 o.b(0,0,0,1.7,.75,.5,BLANC,'r',.12).b(.07,.07,.46,1.63,.68,.56,'#bae6fd','r',.1).b(0,0,.5,1.7,.75,.55,'#ffffff','r',.04)
  .b(.06,.34,.5,.1,.38,.66,METAL,'c',null,10).b(.06,.34,.62,.16,.4,.66,METAL,'c',null,10).b(.02,.2,.5,.05,.23,.57,METAL,'c',null,10).b(.02,.5,.5,.05,.53,.57,METAL,'c',null,10);return o.a})();
F.lavelinge=(function(){var o=mk(.6,.6,.85);
 o.b(0,0,0,.6,.6,.85,'#f1f5f9','r',.012).b(.07,.58,.1,.53,.62,.58,'#cbd5e1','e').b(.12,.59,.15,.48,.625,.53,'#334155','e').b(.04,.585,.7,.56,.6,.82,'#94a3b8','r',.006).b(.46,.595,.74,.52,.62,.78,'#475569','c');return o.a})();
F.poteau=(function(){var o=mk(.25,.25,2.8);o.b(0,0,0,.25,.25,2.8,'#6b7280','r',.008);return o.a})();
F.poutre=(function(){var o=mk(4,.2,.4);o.b(0,0,0,4,.2,.4,'#8d949e','b');return o.a})();

/* Garde-corps (V4.7) : les pièces sont recalculées selon la longueur réelle (poteaux tous les 90 cm au plus), donc F.garde n'est qu'un modèle de 3 m.
 * w = longueur, d = épaisseur (6 cm), h = hauteur (1 m, norme usuelle 1,00 à 1,10 m). */
function railParts(W,D,H,sty){var a=[],n=Math.max(1,Math.ceil(W/0.9)),i,t=Math.min(Math.max(D,0.04),0.08),G='#4b5563',y0=(D-t)/2,y1=y0+t,pw=0.045,py0=(D-pw)/2,py1=py0+pw;sty=sty||'b';
 function B(x0,z0,x1,z1,yy0,yy1,c){a.push([x0/W,yy0/D,z0/H,x1/W,yy1/D,z1/H,c||G,'b',null,10])}
 for(i=0;i<=n;i++){var cx=W*i/n,x0=Math.max(0,cx-pw/2),x1=Math.min(W,cx+pw/2);B(x0,0,x1,H,py0,py1)}
 B(0,H-0.05,W,H,y0,y1);
 if(sty==='v'){/* verre : panneau clair entre les poteaux, lisse basse */
  B(0,0.08,W,0.11,y0,y1);B(0.0,0.11,W,H-0.05,(D-0.012)/2,(D+0.012)/2,'#bcd8e8');return a}
 if(sty==='c'){/* câbles inox horizontaux (un tous les ~9 cm) */
  var nc=Math.max(3,Math.floor((H-0.2)/0.09)),j;for(j=0;j<=nc;j++){var zc=0.1+(H-0.2)*j/nc;B(0,zc-0.006,W,zc+0.006,(D-0.012)/2,(D+0.012)/2,'#c7ced6')}return a}
 B(0,H*0.52,W,H*0.52+0.03,y0+0.01,y1-0.01);B(0,0.1,W,0.13,y0+0.01,y1-0.01);
 /* barreaux verticaux fins (un tous les ~12 cm) */
 var nb=Math.min(120,Math.floor(W/0.12)),k;for(k=1;k<nb;k++){var bx=W*k/nb;B(bx-0.008,0.13,bx+0.008,H-0.05,(D-0.016)/2,(D+0.016)/2)}
 return a}
F.garde=railParts(3,.06,1);
/* Dalle de balcon / terrasse en console : 15 cm sous le niveau du plancher, avec rive plus claire */
F.balcon=[[0,0,-1,1,1,0,'#cfcfd2','b',null,7]];
/* voûte en berceau : demi-ellipse sur la largeur, extrudée sur la profondeur ; 'v' = forme voûte, paramètre = épaisseur de la coque (m) */
F.voute=[[0,0,0,1,1,1,'#d8d2c4','v',0.2,7]];
/* lucarne à deux versants : joues, façade vitrée, toit à faîtage perpendiculaire au versant ; 'g' = prisme à deux versants */
F.lucarne=(function(){var o=mk(1.4,1.6,1.7),E='#e9e4d8',BL='#f8fafc';
 o.b(0,0,0,.08,1.6,1.15,E).b(1.32,0,0,1.4,1.6,1.15,E).b(.08,1.5,0,1.32,1.6,.25,E).b(.08,1.5,1.0,1.32,1.6,1.15,E)
  .b(.08,1.5,.25,.2,1.6,1.0,E).b(1.2,1.5,.25,1.32,1.6,1.0,E)
  .b(.2,1.52,.25,1.2,1.58,1.0,'#9ccbea').b(.2,1.595,.25,1.2,1.61,.28,BL).b(.2,1.595,.97,1.2,1.61,1.0,BL).b(.2,1.595,.25,.23,1.61,1.0,BL).b(1.17,1.595,.25,1.2,1.61,1.0,BL).b(.69,1.595,.25,.71,1.61,1.0,BL)
  .b(-.1,0,1.15,1.5,1.7,1.7,'#b45f3c','g');return o.a})();
// --- nouveautés ---
F.tableronde=(function(){var o=mk(1.1,1.1,.75);
 o.b(0,0,.71,1.1,1.1,.75,BOIS2,'c').b(.2,.2,0,.9,.9,.035,BOISD,'c').b(.46,.46,.03,.64,.64,.71,BOISD,'k',.85);return o.a})();
F.tabouret=(function(){var o=mk(.35,.35,.65);
 [[.06,.06],[.29,.06],[.06,.29],[.29,.29]].forEach(function(p){o.b(p[0]-.015,p[1]-.015,0,p[0]+.015,p[1]+.015,.62,BOISD,'k',.8)});o.b(0,0,.6,.35,.35,.65,BOIS,'c');o.b(.04,.04,.3,.31,.31,.315,BOISD,'c');return o.a})();
F.commode=(function(){var o=mk(1.0,.5,.85),i;pieds4(o,1.0,.5,.1,'#5b4330',.025,.06);
 o.b(0,0,.1,1,.5,.85,BOIS,'r',.012).b(-0.0,-0.0,.82,1,.5,.85,BOIS2,'r',.01);
 for(i=0;i<3;i++){o.b(.025,.485,.13+i*.23,.975,.5,.34+i*.23,'#b9946f','r',.006);o.b(.45,.5,.225+i*.23,.55,.52,.245+i*.23,METAL,'c',null,10)}return o.a})();
F.buffet=(function(){var o=mk(1.6,.45,.9);pieds4(o,1.6,.45,.1,'#5b4330',.025,.07);
 o.b(0,0,.1,1.6,.45,.9,BOIS,'r',.012).b(0,0,.87,1.6,.45,.9,BOIS2,'r',.01).b(.025,.435,.13,.53,.45,.84,'#b9946f','r',.006).b(.545,.435,.13,1.055,.45,.84,'#b9946f','r',.006).b(1.07,.435,.13,1.575,.45,.84,'#b9946f','r',.006);
 poignee(o,.5,.45,.45,.14,true);poignee(o,.57,.45,.45,.14,true);poignee(o,1.03,.45,.45,.14,true);poignee(o,1.1,.45,.45,.14,true);return o.a})();
F.lampadaire=(function(){var o=mk(.35,.35,1.7);
 o.b(.04,.04,0,.31,.31,.03,'#1f2937','c').b(.16,.16,.03,.19,.19,1.35,'#374151','c',null,10).b(.03,.03,1.3,.32,.32,1.7,'#fde68a','k',.65);return o.a})();
F.plante=(function(){var o=mk(.5,.5,1.1);
 o.b(.08,.08,0,.42,.42,.3,'#b45f3c','k',.78).b(.1,.1,.29,.4,.4,.31,'#4b3621','c');
 o.b(.02,.02,.25,.48,.48,.75,'#3f7a35','e',null,11).b(.1,.06,.55,.5,.45,1.05,'#4f8a3c','e',null,11).b(0,.1,.6,.38,.46,1.1,'#2f6a2f','e',null,11);return o.a})();
F.tapis=(function(){var o=mk(2.0,1.4,.02);o.b(0,0,0,2.0,1.4,.014,'#b8a58c','r',.004).b(.1,.1,.01,1.9,1.3,.02,'#cdbfa9','r',.004);return o.a})();
F.ilot=(function(){var o=mk(1.8,.9,.9);
 o.b(.03,.03,0,1.77,.8,.1,'#475569').b(0,0,.1,1.8,.9,.86,'#e2e8f0','r',.01).b(-0.0,-0.0,.86,1.8,.9,.9,'#374151','r',.008)
  .b(.02,.885,.12,.88,.9,.84,'#f1f5f9','r',.005).b(.92,.885,.12,1.78,.9,.84,'#f1f5f9','r',.005);poignee(o,.8,.9,.55,.14,true);poignee(o,.98,.9,.55,.14,true);return o.a})();
function stairL(){var a=[],i,n1=7,col=function(i){return i%2?'#cbd5e1':'#e2e8f0'};
 for(i=0;i<n1;i++)a.push([0,1-(i+1)*0.6/n1,0,0.5,1-i*0.6/n1,(i+1)/15,col(i)]);
 a.push([0,0,0,0.5,0.4,8/15,'#d5dbe6']);
 for(i=0;i<n1;i++)a.push([0.5+i*0.5/n1,0,0,0.5+(i+1)*0.5/n1,0.4,(9+i)/15,col(i)]);return a}
function stairU(){var a=[],i,n1=7,col=function(i){return i%2?'#cbd5e1':'#e2e8f0'};
 for(i=0;i<n1;i++)a.push([0,1-(i+1)*0.75/n1,0,0.45,1-i*0.75/n1,(i+1)/15,col(i)]);
 a.push([0,0,0,1,0.25,8/15,'#d5dbe6']);
 for(i=0;i<n1;i++)a.push([0.55,0.25+i*0.75/n1,0,1,0.25+(i+1)*0.75/n1,(9+i)/15,col(i)]);return a}
var FURN=[
 {k:'lit2',n:'Lit double',e:'🛏',cat:'Chambre',w:1.6,d:2.0,h:1.0,p:F.lit2},
 {k:'lit1',n:'Lit simple',e:'🛏',cat:'Chambre',w:0.9,d:2.0,h:0.9,p:F.lit1},
 {k:'armoire',n:'Armoire',e:'🚪',cat:'Chambre',w:1.2,d:0.6,h:2.0,p:F.armoire},
 {k:'chevet',n:'Table de chevet',e:'▫',cat:'Chambre',w:0.45,d:0.4,h:0.5,p:F.chevet},
 {k:'commode',n:'Commode',e:'🗄',cat:'Chambre',w:1.0,d:0.5,h:0.85,p:F.commode},
 {k:'canape',n:'Canapé',e:'🛋',cat:'Salon',w:2.0,d:0.9,h:0.85,p:F.canape},
 {k:'fauteuil',n:'Fauteuil',e:'💺',cat:'Salon',w:0.85,d:0.85,h:0.85,p:F.fauteuil},
 {k:'tablebasse',n:'Table basse',e:'▭',cat:'Salon',w:1.0,d:0.6,h:0.4,p:F.tablebasse},
 {k:'tv',n:'Meuble TV',e:'📺',cat:'Salon',w:1.6,d:0.4,h:1.0,p:F.tv},
 {k:'etagere',n:'Étagère',e:'📚',cat:'Salon',w:0.9,d:0.35,h:1.8,p:F.etagere},
 {k:'buffet',n:'Buffet',e:'🗄',cat:'Salon',w:1.6,d:0.45,h:0.9,p:F.buffet},
 {k:'tapis',n:'Tapis',e:'▭',cat:'Salon',w:2.0,d:1.4,h:0.02,p:F.tapis},
 {k:'lampadaire',n:'Lampadaire',e:'💡',cat:'Salon',w:0.35,d:0.35,h:1.7,p:F.lampadaire},
 {k:'plante',n:'Plante verte',e:'🪴',cat:'Salon',w:0.5,d:0.5,h:1.1,p:F.plante},
 {k:'table',n:'Table à manger',e:'🍽',cat:'Salle à manger',w:1.6,d:0.9,h:0.75,p:F.table},
 {k:'tableronde',n:'Table ronde',e:'⚪',cat:'Salle à manger',w:1.1,d:1.1,h:0.75,p:F.tableronde},
 {k:'chaise',n:'Chaise',e:'🪑',cat:'Salle à manger',w:0.45,d:0.45,h:0.9,p:F.chaise},
 {k:'tabouret',n:'Tabouret',e:'🪑',cat:'Salle à manger',w:0.35,d:0.35,h:0.65,p:F.tabouret},
 {k:'bureau',n:'Bureau',e:'🖥',cat:'Bureau',w:1.4,d:0.7,h:0.75,p:F.bureau},
 {k:'comptoir',n:'Plan de travail',e:'▬',cat:'Cuisine',w:1.2,d:0.6,h:0.9,p:F.comptoir},
 {k:'evier',n:'Évier',e:'🚰',cat:'Cuisine',w:0.9,d:0.6,h:0.9,p:F.evier},
 {k:'cuisiniere',n:'Cuisinière',e:'🔥',cat:'Cuisine',w:0.6,d:0.6,h:0.9,p:F.cuisiniere},
 {k:'frigo',n:'Réfrigérateur',e:'🧊',cat:'Cuisine',w:0.65,d:0.65,h:1.8,p:F.frigo},
 {k:'ilot',n:'Îlot de cuisine',e:'▬',cat:'Cuisine',w:1.8,d:0.9,h:0.9,p:F.ilot},
 {k:'wc',n:'WC',e:'🚽',cat:'Sanitaire',w:0.4,d:0.7,h:0.8,p:F.wc},
 {k:'lavabo',n:'Lavabo',e:'🚿',cat:'Sanitaire',w:0.6,d:0.5,h:0.85,p:F.lavabo},
 {k:'douche',n:'Douche',e:'🚿',cat:'Sanitaire',w:0.9,d:0.9,h:0.12,p:F.douche},
 {k:'baignoire',n:'Baignoire',e:'🛁',cat:'Sanitaire',w:1.7,d:0.75,h:0.55,p:F.baignoire},
 {k:'lavelinge',n:'Lave-linge',e:'🧺',cat:'Sanitaire',w:0.6,d:0.6,h:0.85,p:F.lavelinge},
 {k:'poteau',n:'Poteau',e:'■',cat:'Structure',w:0.25,d:0.25,h:2.8,p:F.poteau},
 {k:'poutre',n:'Poutre',e:'═',cat:'Structure',w:4,d:0.2,h:0.4,beam:true,p:F.poutre},
 {k:'escalier_l',stair:true,n:'Escalier quart tournant',e:'🪜',cat:'Circulation',w:2.0,d:2.8,h:3.0,p:stairL()},
 {k:'escalier_u',stair:true,n:'Escalier en U (deux volées)',e:'🪜',cat:'Circulation',w:2.2,d:3.0,h:3.0,p:stairU()},
 {k:'balcon',n:'Dalle de balcon / terrasse',e:'▭',cat:'Structure',w:3.0,d:1.2,h:0.15,slab:true,p:F.balcon},
 {k:'garde',n:'Garde-corps (balcon, terrasse)',e:'┃',cat:'Structure',w:3.0,d:0.06,h:1.0,rail:true,p:F.garde},
 {k:'tremie',n:'Trémie (vide dans la dalle)',e:'⬚',cat:'Structure',w:1.0,d:2.0,h:0.01,void:true,p:[]},
 {k:'voute',n:'Voûte en berceau',e:'⌓',cat:'Structure',w:4.0,d:3.0,h:1.4,vault:true,p:F.voute},
 {k:'lucarne',n:'Lucarne à deux versants',e:'⌂',cat:'Structure',w:1.4,d:1.6,h:1.7,dormer:true,p:F.lucarne},
 {k:'escalier',stair:true,n:'Escalier droit',e:'🪜',cat:'Circulation',w:1.0,d:3.2,h:3.0,p:(function(){var a=[],n=14,i;for(i=0;i<n;i++)a.push([0,i/n,0,1,(i+1)/n,(i+1)/n,i%2?'#cbd5e1':'#e2e8f0']);return a})()}
];
var EQUIP={Cuisine:1,Sanitaire:1,Structure:1,Circulation:1};
FURN.forEach(function(f){f.equip=!!EQUIP[f.cat]});
var WALL={balcon:1,garde:1,commode:1,buffet:1,lit2:1,lit1:1,armoire:1,chevet:1,tv:1,etagere:1,comptoir:1,evier:1,cuisiniere:1,frigo:1,wc:1,lavabo:1,douche:1,baignoire:1,lavelinge:1,bureau:1};
FURN.forEach(function(f){f.wall=!!WALL[f.k]});

/* Points électriques : z = hauteur par défaut (m) ; null = au plafond */
var ELEC=[
 {k:'prise',n:'Prise 2P+T 16 A',s:'P',col:'#15803d',z:0.3,circ:'prises'},
 {k:'prise_pt',n:'Prise plan de travail',s:'PT',col:'#15803d',z:1.1,circ:'prises'},
 {k:'inter',n:'Interrupteur simple',s:'I',col:'#c2410c',z:1.1,circ:'eclairage'},
 {k:'va',n:'Va-et-vient',s:'V',col:'#c2410c',z:1.1,circ:'eclairage'},
 {k:'lum',n:'Point lumineux plafond',s:'☀',col:'#ca8a04',z:null,circ:'eclairage'},
 {k:'appl',n:'Applique murale',s:'A',col:'#ca8a04',z:2.0,circ:'eclairage'},
 {k:'tv',n:'Prise TV',s:'TV',col:'#0369a1',z:0.3,circ:'prises'},
 {k:'rj',n:'Prise RJ45',s:'RJ',col:'#0369a1',z:0.3,circ:'prises'},
 {k:'cuis',n:'Prise cuisinière 32 A',s:'C',col:'#b91c1c',z:0.3,circ:'cuisiniere'},
 {k:'clim',n:'Climatiseur',s:'❄',col:'#0e7490',z:2.2,circ:'clim'},
 {k:'chauffe',n:'Chauffe-eau',s:'CE',col:'#b91c1c',z:2.0,circ:'prises'},
 {k:'tab',n:'Tableau électrique',s:'TD',col:'#7f1d1d',z:1.5,circ:'tableau'}
];
var CIRC=[
 {k:'eclairage',n:'Éclairage (1,5 mm²)',col:'#ca8a04'},
 {k:'prises',n:'Prises (2,5 mm²)',col:'#15803d'},
 {k:'cuisiniere',n:'Cuisinière (6 mm²)',col:'#b91c1c'},
 {k:'clim',n:'Climatisation (4 mm²)',col:'#0e7490'},
 {k:'tableau',n:'Alimentation tableau (10 mm²)',col:'#7f1d1d'}
];
function by(a){var o={};a.forEach(function(x){o[x.k]=x});return o}
w.EXBCAT={railParts:railParts,furn:FURN,furnBy:by(FURN),elec:ELEC,elecBy:by(ELEC),circ:CIRC,circBy:by(CIRC)};
})(window);
