/* Plan de charpente et métré des tuiles — éditeur de plan, V4.7.
 *  EXBCHA.calc(R)               → { members[], qty{}, geo{} } pour un toit R de la scène (2 pans ou 4 pans, emprise rectangulaire)
 *  EXBCHA.render(g,S,view,T,o)  → dessine le plan de charpente (vue « cha ») ; même convention que coupes.js : écran = T.ox + X·T.s ; T.oy − Y·T.s, avec X = x du plan, Y = −y du plan (nord en haut)
 *  EXBCHA.extent(S)             → étendue du dessin en mètres (pour le cadrage)
 *  EXBCHA.cfg(R)                → réglages effectifs (valeurs par défaut + R.cha)
 *  EXBCHA.has(S)                → true s'il existe au moins un toit à pentes à dessiner
 * Géométrie : même emprise et même débord que la vue 3D (débord supplémentaire e = 0,35 m autour de l'emprise du toit, hanches à 45°).
 * Repère local d'un toit : u le long du faîtage (0 → La), v en travers (0 → Wd, faîtage en Wd/2). x = X0+u, z = Z0+v si le faîtage est sur X ; sinon x = X0+v, z = Z0+u.
 * Hypothèses (indicatives, à valider par un charpentier ou un ingénieur) : chevrons 63×75 mm à entraxe réglable (0,60 m), faîtière et pannes 75×225 mm,
 * sablières 75×100 mm, liteaux et contre-liteaux 38×38 mm, pannes intermédiaires au-delà de 3 m de rampant, tuiles courantes = 1 / (pas × largeur utile).
 * Aucune dépendance, aucun accès au DOM. */
(function(w){'use strict';
var E=0.35;
var DEF={ent:0.6,pas:0.3,larg:0.3,perte:8,fait:0.33};
var COL={noue:'#1d4ed8',chev:'#8b5a2b',fait:'#7c2d12',sab:'#2a2a2a',panne:'#4b5563',aret:'#b91c1c',lit:'#d4c9b5',mur:'#999'};
var SEC={chev:[0.063,0.075],fait:[0.075,0.225],sab:[0.075,0.1],panne:[0.075,0.225],aret:[0.075,0.225],lit:[0.038,0.038],clit:[0.038,0.038]};
function nf(x,d){d=d==null?2:d;var k=Math.pow(10,d);return (Math.round(x*k)/k).toFixed(d).replace('.',',')}
function cfg(R){var c=R&&R.cha||{},o={},k;for(k in DEF)o[k]=(c[k]>0)?+c[k]:DEF[k];o.ent=Math.max(0.3,Math.min(1.2,o.ent));o.pas=Math.max(0.15,Math.min(0.6,o.pas));o.larg=Math.max(0.15,Math.min(0.6,o.larg));o.perte=Math.max(0,Math.min(40,c.perte!=null&&isFinite(+c.perte)?+c.perte:DEF.perte));return o}
function has(S){return(S.roofs||[]).length>0}

function base(R){
 if(!R||R.poly||(R.type!=='2pans'&&R.type!=='4pans'))return null;
 var c=cfg(R),sl=Math.max(5,Math.min(60,R.slope||30))*Math.PI/180,cs=Math.cos(sl),tn=Math.tan(sl),
  ww=R.x1-R.x0,dd=R.y1-R.y0,alongX=R.axis==='x'?true:R.axis==='y'?false:ww>=dd,
  X0=R.x0-E,Z0=R.y0-E,so=E+(R.ov>0?R.ov:0),La=(alongX?ww:dd)+2*E,Wd=(alongX?dd:ww)+2*E,qc=Math.min(Wd/2,La/2),
  M=[],i,j;
 function W(u,v){return alongX?[X0+u,Z0+v]:[X0+v,Z0+u]}
 function add(k,u0,v0,u1,v1,L,tag){var a=W(u0,v0),b=W(u1,v1);M.push({k:k,a:a,b:b,L:L==null?Math.hypot(b[0]-a[0],b[1]-a[1]):L,tag:tag||''})}
 var four=R.type==='4pans',run=qc;
 /* chevrons */
 function stations(len,margin){var n=Math.max(2,Math.ceil((len-2*margin)/c.ent)+1),a=[];for(var q=0;q<n;q++)a.push(margin+q*(len-2*margin)/(n-1));return a}
 if(!four){var us=stations(La,0.05);us.forEach(function(u){add('chev',u,0,u,Wd/2,(Wd/2)/cs,'');add('chev',u,Wd,u,Wd/2,(Wd/2)/cs,'')})}
 else{
  var us2=stations(La,0.05);
  us2.forEach(function(u){var r=Math.min(u,La-u,qc);if(r<0.12)return;add('chev',u,0,u,r,r/cs,'');add('chev',u,Wd,u,Wd-r,r/cs,'')});
  var m=Math.max(1,Math.ceil(Wd/c.ent));for(j=0;j<m;j++){var v=(j+0.5)*Wd/m,r2=Math.min(v,Wd-v,qc);if(r2<0.12)continue;add('chev',0,v,r2,v,r2/cs,'');add('chev',La,v,La-r2,v,r2/cs,'')}
  var hl=qc*Math.sqrt(2+tn*tn);add('aret',0,0,qc,qc,hl);add('aret',0,Wd,qc,Wd-qc,hl);add('aret',La,0,La-qc,qc,hl);add('aret',La,Wd,La-qc,Wd-qc,hl)}
 /* faîtière */
 if(!four)add('fait',0,Wd/2,La,Wd/2);else if(La-2*qc>0.05)add('fait',qc,Wd/2,La-qc,Wd/2);
 /* sablières posées sur l'emprise du toit (au droit des murs) */
 if(!four){add('sab',so,so,La-so,so);add('sab',so,Wd-so,La-so,Wd-so)}
 else{add('sab',so,so,La-so,so);add('sab',La-so,so,La-so,Wd-so);add('sab',La-so,Wd-so,so,Wd-so);add('sab',so,Wd-so,so,so)}
 /* pannes intermédiaires : une par tranche de 3 m de rampant */
 var rampant=qc/cs,np=Math.max(0,Math.ceil(rampant/3.0)-1);
 for(j=1;j<=np;j++){var d=qc*j/(np+1);
  if(!four){add('panne',0,d,La,d);add('panne',0,Wd-d,La,Wd-d)}
  else if(La-2*d>0.2&&Wd-2*d>0.2){add('panne',d,d,La-d,d);add('panne',La-d,d,La-d,Wd-d);add('panne',La-d,Wd-d,d,Wd-d);add('panne',d,Wd-d,d,d)}}
 /* liteaux : rangs parallèles aux égouts, au pas du calepinage (dessinés et comptés) */
 var rows=[],ml=0,hmax=qc,step=c.pas*cs,hk;
 for(hk=0;hk<=hmax+1e-6;hk+=step)rows.push(hk);if(hmax-rows[rows.length-1]>0.05)rows.push(hmax);
 rows.forEach(function(h){
  if(!four){add('lit',0,h,La,h,La);add('lit',0,Wd-h,La,Wd-h,La);ml+=2*La}
  else{var a1=La-2*h,b1=Wd-2*h;if(a1>0.02){add('lit',h,h,La-h,h,a1);add('lit',h,Wd-h,La-h,Wd-h,a1);ml+=2*a1}if(b1>0.02){add('lit',h,h,h,Wd-h,b1);add('lit',La-h,h,La-h,Wd-h,b1);ml+=2*b1}}});
 return{R:R,members:M,cfg:c,geo:{X0:X0,Z0:Z0,La:La,Wd:Wd,alongX:alongX,qc:qc,sl:sl,tn:tn,cs:cs,four:four,perim:2*(La+Wd),x0:X0,x1:X0+(alongX?La:Wd),z0:Z0,z1:Z0+(alongX?Wd:La)},rows:rows.length,np:np,rampant:rampant}}

/* hauteur de la couverture en (x, z) : même formule que la vue 3D et les façades (coupes.js, roofFn) */
function hFn(C){var R=C.R,g=C.geo,tn=g.tn,ye=R.yE-E*tn,four=g.four,alongX=g.alongX,x0=g.x0,x1=g.x1,z0=g.z0,z1=g.z1,qc=E+(alongX?R.y1-R.y0:R.x1-R.x0)/2;
 return function(x,z){if(x<x0-1e-9||x>x1+1e-9||z<z0-1e-9||z>z1+1e-9)return null;var q;
  if(!four)q=alongX?Math.min(z-z0,z1-z):Math.min(x-x0,x1-x);else q=Math.min(x-x0,x1-x,z-z0,z1-z);
  return ye+tn*Math.min(q,qc)}}

/* parties visibles d'un élément : on masque ce qui est sous une autre couverture plus haute (toits en L, en T, annexes) */
function visible(m,i,H){var n=Math.max(8,Math.ceil(Math.hypot(m.b[0]-m.a[0],m.b[1]-m.a[1])/0.08)),ok=[],k,t;
 function at(t){return[m.a[0]+(m.b[0]-m.a[0])*t,m.a[1]+(m.b[1]-m.a[1])*t]}
 function vis(t){var p=at(t),hs=H[i](p[0],p[1]),j;if(hs==null){hs=-1e9}
  for(j=0;j<H.length;j++){if(j===i||!H[j])continue;var hj=H[j](p[0],p[1]);if(hj==null)continue;if(hj>hs+1e-4)return false;if(Math.abs(hj-hs)<=1e-4&&j<i)return false}return true}
 for(k=0;k<=n;k++)ok.push(vis(k/n));
 var out=[],st=null;
 function edge(a,b){var lo=a,hi=b,va=vis(a),q;for(q=0;q<10;q++){var mid=(lo+hi)/2;if(vis(mid)===va)lo=mid;else hi=mid}return(lo+hi)/2}
 for(k=0;k<=n;k++){
  if(ok[k]&&st==null)st=k===0?0:edge((k-1)/n,k/n);
  if(!ok[k]&&st!=null){out.push([st,edge((k-1)/n,k/n)]);st=null}}
 if(st!=null)out.push([st,1]);
 return out.filter(function(q){return q[1]-q[0]>1e-3})}

function polyArea(P){var a=0,i,j;for(i=0,j=P.length-1;i<P.length;j=i++)a+=(P[j][0]+P[i][0])*(P[j][1]-P[i][1]);return Math.abs(a/2)}
function polyPerim(P){var l=0,i;for(i=0;i<P.length;i++){var a=P[i],b=P[(i+1)%P.length];l+=Math.hypot(b[0]-a[0],b[1]-a[1])}return l}


/* Toit pentu à contour libre (V4.8) : un contour dont tous les côtés sont parallèles aux axes (L, T, croix, U, redans…)
 * est découpé en rectangles qui se recouvrent (rectangles maximaux, recouvrement minimal) ; chaque rectangle devient un toit
 * rectangulaire, et le calcul « plusieurs toits » (noues, parties cachées, union des surfaces) s'applique tel quel.
 * decompose(poly) → {ok:true, poly:contour recalé, rects:[[x0,x1,y0,y1],…], area} ou {ok:false, why:'oblique'|'trop'|'degenere'}.
 * Les coordonnées proches (moins de 6 cm) sont alignées avant l'analyse ; un côté oblique ou courbe n'est pas accepté. */
function decompose(poly){
 var TOL=0.06,P,i,j;
 if(!poly||poly.length<3)return{ok:false,why:'degenere'};
 if(poly.length>80)return{ok:false,why:'trop'};
 function snap(ix){var v=poly.map(function(p){return p[ix]}),o=v.map(function(_,k){return k}).sort(function(a,b){return v[a]-v[b]}),grp=[],cur=[o[0]];
  for(var q=1;q<o.length;q++){if(v[o[q]]-v[o[q-1]]<=TOL)cur.push(o[q]);else{grp.push(cur);cur=[o[q]]}}grp.push(cur);
  var out=v.slice();grp.forEach(function(g){var m=0;g.forEach(function(k){m+=v[k]});m/=g.length;g.forEach(function(k){out[k]=Math.round(m*1000)/1000})});return out}
 var sx=snap(0),sy=snap(1);P=poly.map(function(_,k){return[sx[k],sy[k]]});
 /* retire les doublons consécutifs et les points alignés */
 var Q=[];P.forEach(function(p){var l=Q[Q.length-1];if(!l||Math.abs(l[0]-p[0])>1e-9||Math.abs(l[1]-p[1])>1e-9)Q.push(p)});
 if(Q.length>1&&Math.abs(Q[0][0]-Q[Q.length-1][0])<1e-9&&Math.abs(Q[0][1]-Q[Q.length-1][1])<1e-9)Q.pop();
 for(i=0;i<Q.length;i++){var a=Q[i],b=Q[(i+1)%Q.length];if(Math.abs(a[0]-b[0])>1e-9&&Math.abs(a[1]-b[1])>1e-9)return{ok:false,why:'oblique'}}
 var R=[];for(i=0;i<Q.length;i++){var pa=Q[(i+Q.length-1)%Q.length],pb=Q[i],pc=Q[(i+1)%Q.length];
  var col=(Math.abs(pa[0]-pb[0])<1e-9&&Math.abs(pb[0]-pc[0])<1e-9)||(Math.abs(pa[1]-pb[1])<1e-9&&Math.abs(pb[1]-pc[1])<1e-9);if(!col)R.push(pb)}
 if(R.length<4)return{ok:false,why:'degenere'};
 var XS=[],YS=[];R.forEach(function(p){if(XS.indexOf(p[0])<0)XS.push(p[0]);if(YS.indexOf(p[1])<0)YS.push(p[1])});
 XS.sort(function(a,b){return a-b});YS.sort(function(a,b){return a-b});
 var nx=XS.length-1,ny=YS.length-1;if(nx<1||ny<1)return{ok:false,why:'degenere'};
 function inPoly(x,y){var c=false,n=R.length,k,l;for(k=0,l=n-1;k<n;l=k++){var A=R[k],B=R[l];if((A[1]>y)!==(B[1]>y)&&x<(B[0]-A[0])*(y-A[1])/(B[1]-A[1])+A[0])c=!c}return c}
 var cell=[];for(i=0;i<nx;i++){cell.push([]);for(j=0;j<ny;j++)cell[i].push(inPoly((XS[i]+XS[i+1])/2,(YS[j]+YS[j+1])/2)?1:0)}
 /* sommes cumulées pour tester « rectangle entièrement plein » en O(1) */
 var S=[];for(i=0;i<=nx;i++){S.push([]);for(j=0;j<=ny;j++)S[i].push(0)}
 for(i=0;i<nx;i++)for(j=0;j<ny;j++)S[i+1][j+1]=S[i][j+1]+S[i+1][j]-S[i][j]+cell[i][j];
 function full(i0,i1,j0,j1){return S[i1+1][j1+1]-S[i0][j1+1]-S[i1+1][j0]+S[i0][j0]===(i1-i0+1)*(j1-j0+1)}
 var mx=[],i0,i1,j0,j1;
 for(i0=0;i0<nx;i0++)for(i1=i0;i1<nx;i1++)for(j0=0;j0<ny;j0++)for(j1=j0;j1<ny;j1++){
  if(!full(i0,i1,j0,j1))continue;
  if(i0>0&&full(i0-1,i1,j0,j1))continue;if(i1<nx-1&&full(i0,i1+1,j0,j1))continue;
  if(j0>0&&full(i0,i1,j0-1,j1))continue;if(j1<ny-1&&full(i0,i1,j0,j1+1))continue;
  mx.push([i0,i1,j0,j1])}
 if(!mx.length)return{ok:false,why:'degenere'};
 var done=[];for(i=0;i<nx;i++){done.push([]);for(j=0;j<ny;j++)done[i].push(cell[i][j]?0:1)}
 var rects=[],guard=0;
 function gain(m){var g=0,a,b;for(a=m[0];a<=m[1];a++)for(b=m[2];b<=m[3];b++)if(!done[a][b])g+=(XS[a+1]-XS[a])*(YS[b+1]-YS[b]);return g}
 while(guard++<200){var best=null,bg=1e-9;mx.forEach(function(m){var g=gain(m);if(g>bg+1e-9){bg=g;best=m}});if(!best)break;
  for(var a2=best[0];a2<=best[1];a2++)for(var b2=best[2];b2<=best[3];b2++)done[a2][b2]=1;
  rects.push([XS[best[0]],XS[best[1]+1],YS[best[2]],YS[best[3]+1]])}
 if(!rects.length||rects.length>12)return{ok:false,why:'trop'};
 return{ok:true,poly:R,rects:rects,area:polyArea(R)}}

/* calcul pour tous les toits d'un projet : retourne un tableau parallèle à roofs (null = pas de calcul). */
function calcAll(roofs){
 roofs=roofs||[];var C=roofs.map(function(R){return base(R)}),H=C.map(function(c){return c?hFn(c):null}),out=[],i,j;
 /* masquage des éléments sous un autre toit plus haut */
 C.forEach(function(c,ix){if(!c)return;var res=[];
  c.members.forEach(function(m){
   if(C.length<2||C.filter(Boolean).length<2){res.push(m);return}
   var tl=m.L,pl=Math.hypot(m.b[0]-m.a[0],m.b[1]-m.a[1]),ratio=pl>1e-9?tl/pl:1;
   visible(m,ix,H).forEach(function(q){var a=[m.a[0]+(m.b[0]-m.a[0])*q[0],m.a[1]+(m.b[1]-m.a[1])*q[0]],b=[m.a[0]+(m.b[0]-m.a[0])*q[1],m.a[1]+(m.b[1]-m.a[1])*q[1]],l=Math.hypot(b[0]-a[0],b[1]-a[1]);
    res.push({k:m.k,a:a,b:b,L:l*ratio,tag:m.tag})})});
  c.members=res;c.noues=[]});
 /* noues : deux toits à faîtages perpendiculaires, même égout et même pente → arêtes à 45° partant des angles rentrants */
 for(i=0;i<C.length;i++)for(j=0;j<C.length;j++){var A=C[i],B=C[j];if(!A||!B||i===j||!A.geo.alongX||B.geo.alongX)continue;
  var ga=A.geo,gb=B.geo;if(Math.abs(A.R.yE-B.R.yE)>0.02||Math.abs(ga.sl-gb.sl)>0.01)continue;
  var xcB=(gb.x0+gb.x1)/2,zcA=(ga.z0+ga.z1)/2;
  [gb.x0,gb.x1].forEach(function(cx){[ga.z0,ga.z1].forEach(function(cz){
   if(!(cx>ga.x0+0.02&&cx<ga.x1-0.02&&cz>gb.z0+0.02&&cz<gb.z1-0.02))return;
   var sx=xcB>cx?1:-1,sz=cz===ga.z0?1:-1,l=Math.min(Math.abs(xcB-cx),Math.abs(zcA-cz));if(l<0.1)return;
   var a=[cx,cz],b=[cx+sx*l,cz+sz*l];
   /* le point de départ doit être sous le toit voisin : l'angle rentrant vu de l'extérieur n'est pas une noue */
   if(!(H[i]&&H[j]))return;
   A.noues.push({k:'noue',a:a,b:b,L:l*Math.sqrt(2+ga.tn*ga.tn),tag:''})})})}
 /* quantités par toit, couverture = surface visible (grille d'union des emprises) */
 var xs=[],zs=[];C.forEach(function(c){if(!c)return;xs.push(c.geo.x0,c.geo.x1);zs.push(c.geo.z0,c.geo.z1)});
 xs.sort(function(a,b){return a-b});zs.sort(function(a,b){return a-b});
 var couv=C.map(function(){return 0}),ix,iz;
 for(ix=0;ix<xs.length-1;ix++)for(iz=0;iz<zs.length-1;iz++){var dx=xs[ix+1]-xs[ix],dz=zs[iz+1]-zs[iz];if(dx<1e-6||dz<1e-6)continue;
  var cx2=(xs[ix]+xs[ix+1])/2,cz2=(zs[iz]+zs[iz+1])/2,best=-1,bh=-1e9;
  C.forEach(function(c,k){if(!c)return;var h=H[k](cx2,cz2);if(h!=null&&h>bh+1e-4){bh=h;best=k}});
  if(best>=0)couv[best]+=dx*dz/C[best].geo.cs}
 C.forEach(function(c,k){if(!c){out.push(null);return}
  var cf=c.cfg,Q={chev:{n:0,ml:0},aret:{n:0,ml:0},fait:{ml:0},sab:{ml:0},panne:{ml:0},lit:{ml:0},clit:{ml:0},noue:{n:c.noues.length,ml:0}};
  c.noues.forEach(function(q){Q.noue.ml+=q.L});
  c.members.forEach(function(q){if(q.k==='chev'){Q.chev.n++;Q.chev.ml+=q.L}else if(q.k==='aret'){Q.aret.n++;Q.aret.ml+=q.L}else if(q.k==='fait')Q.fait.ml+=q.L;else if(q.k==='sab')Q.sab.ml+=q.L;else if(q.k==='panne')Q.panne.ml+=q.L;else if(q.k==='lit')Q.lit.ml+=q.L});
  Q.clit.ml=Q.chev.ml;
  var cr=couv[k],crete=Q.fait.ml+Q.aret.ml,nCour=cr/(cf.pas*cf.larg),nFait=crete/cf.fait,bois=0,vol={};
  ['chev','aret','fait','sab','panne','lit','clit','noue'].forEach(function(q){var s=SEC[q]||SEC.aret,l=Q[q].ml;vol[q]=l*s[0]*s[1];bois+=vol[q]});
  Q.couv=cr;Q.tuilesCourantes=Math.ceil(nCour);Q.tuilesFaitieres=Math.ceil(nFait);Q.perte=cf.perte;Q.tuiles=Math.ceil((nCour+nFait)*(1+cf.perte/100));
  Q.parM2=1/(cf.pas*cf.larg);Q.vol=vol;Q.bois=bois;Q.rangs=c.rows;Q.rampant=c.rampant;Q.pannesParPan=c.np;
  out.push({members:c.members.concat(c.noues),qty:Q,cfg:cf,geo:c.geo,noues:c.noues})});
 return out}
function calc(R){return calcAll([R])[0]}

/* terrasse (toit plat, rectangulaire ou à contour libre) : pas de charpente bois, plan de la dalle et de l'acrotère */
function flatInfo(R){var P=R.poly&&R.poly.length>=3?R.poly:[[R.x0,R.y0],[R.x1,R.y0],[R.x1,R.y1],[R.x0,R.y1]];return{poly:P,area:polyArea(P),perim:polyPerim(P),libre:!!R.poly}}

/* ------------------------------------------------------------------ dessin */
function extent(S){var x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,any=false,rf=S.roofs||[];
 calcAll(rf).forEach(function(C,i){if(C){any=true;var g=C.geo;x0=Math.min(x0,g.x0);x1=Math.max(x1,g.x1);y0=Math.min(y0,-g.z1);y1=Math.max(y1,-g.z0)}
  else if(rf[i]){any=true;flatInfo(rf[i]).poly.forEach(function(p){x0=Math.min(x0,p[0]);x1=Math.max(x1,p[0]);y0=Math.min(y0,-p[1]);y1=Math.max(y1,-p[1])})}});
 if(!any){x0=0;x1=8;y0=-6;y1=0}var wd=x1-x0;
 return{x0:x0-1.6,x1:x1+Math.max(8.5,wd*0.45),y0:y0-1.8,y1:y1+1.9+Math.max(0,(rf.length-1))*0}}
function render(g,S,view,T,opt){opt=opt||{};var k=opt.k||1,s=T.s;
 function sx(X){return T.ox+X*s}function sy(Y){return T.oy-Y*s}
 function line(x0,z0,x1,z1,col,lw,dash){g.beginPath();g.moveTo(sx(x0),sy(-z0));g.lineTo(sx(x1),sy(-z1));g.strokeStyle=col;g.lineWidth=lw*k;if(dash)g.setLineDash(dash.map(function(v){return v*k}));g.stroke();if(dash)g.setLineDash([])}
 function txt(t,X,Y,px,al,col,bold){g.font=(bold?'700 ':'')+(px*k)+'px Arial';g.textAlign=al||'left';g.fillStyle=col||'#111';g.fillText(t,X,Y)}
 g.lineJoin='round';
 var rf=S.roofs||[],CA=calcAll(rf),roofs=rf.map(function(R,i){return{R:R,C:CA[i],F:CA[i]?null:flatInfo(R)}});
 if(!roofs.length){txt('Aucun toit : ajoutez-en un pour obtenir le plan de charpente.',sx(0)+10*k,sy(0)-10*k,13,'left','#64748b');return}
 var ex=extent(S),xr=sx(ex.x1-Math.max(8.5,(ex.x1-ex.x0)*0.0)),tb=0;
 roofs.forEach(function(o,idx){var R=o.R,C=o.C,i;
  if(o.F){var F=o.F,P=F.poly,X=xr+14*k,Y=sy(ex.y1)+(22+tb)*k,lh=14*k;
   for(i=0;i<P.length;i++){var pa=P[i],pb=P[(i+1)%P.length];line(pa[0],pa[1],pb[0],pb[1],'#1b1b1b',2.2);line(pa[0],pa[1],pb[0],pb[1],'#4b5563',1,[6,4])}
   var cx0=P.reduce(function(a,p){return a+p[0]},0)/P.length,cz0=P.reduce(function(a,p){return a+p[1]},0)/P.length;
   txt('Terrasse'+(F.libre?' libre':''),sx(cx0),sy(-cz0),10.5,'center','#4b5563',true);txt('dalle béton, sans charpente',sx(cx0),sy(-cz0)+14*k,9.5,'center','#64748b');
   txt((roofs.length>1?'Toit '+(idx+1)+' — ':'')+'TERRASSE',X,Y,11,'left','#12254a',true);Y+=lh;txt('Surface de dalle',X,Y,11,'left');txt(nf(F.area,1)+' m²',X+250*k,Y,11,'right');Y+=lh;txt('Rives / acrotère',X,Y,11,'left');txt(nf(F.perim,1)+' ml',X+250*k,Y,11,'right');Y+=lh+8*k;
   tb=(Y-sy(ex.y1))/k-22+8;return}
  var G=C.geo,c=C.cfg,Q=C.qty;
  /* murs du niveau d'appui, en fond */
  var L=(S.levels||[])[R.base!=null?R.base:(S.levels||[]).length-1];
  if(L)(L.walls||[]).forEach(function(wl){var P=wl.path;for(i=0;i<P.length-1;i++)line(P[i][0],P[i][1],P[i+1][0],P[i+1][1],COL.mur,Math.max(1,wl.t*s/k*0.9))});
  /* contour du débord */
  var xa=G.x0,xb=G.x1,za=G.z0,zb=G.z1;
  var ord={lit:0,chev:1,panne:2,sab:3,aret:4,noue:4,fait:5},W={lit:0.5,chev:1.2,panne:2.2,sab:3.2,aret:2.4,noue:2.4,fait:3.6},DS={panne:[8,4,2,4],sab:[10,4]};
  C.members.slice().sort(function(a,b){return ord[a.k]-ord[b.k]}).forEach(function(m){line(m.a[0],m.a[1],m.b[0],m.b[1],COL[m.k],W[m.k],DS[m.k])});
  line(xa,za,xb,za,'#1b1b1b',1.6);line(xb,za,xb,zb,'#1b1b1b',1.6);line(xb,zb,xa,zb,'#1b1b1b',1.6);line(xa,zb,xa,za,'#1b1b1b',1.6);
  /* cotes : largeur et profondeur hors tout du débord */
  var yd=sy(-za)+(-0)*k,cy=sy(-zb)-16*k,cx=sx(xa)-16*k;
  g.strokeStyle='#444';g.lineWidth=.8*k;g.beginPath();g.moveTo(sx(xa),cy);g.lineTo(sx(xb),cy);g.stroke();[sx(xa),sx(xb)].forEach(function(X){g.beginPath();g.moveTo(X,cy-5*k);g.lineTo(X,cy+5*k);g.stroke()});
  g.save();txt(nf(xb-xa)+' m',(sx(xa)+sx(xb))/2,cy-4*k,10.5,'center','#111',true);g.restore();
  g.beginPath();g.moveTo(cx,sy(-za));g.lineTo(cx,sy(-zb));g.stroke();[sy(-za),sy(-zb)].forEach(function(Y){g.beginPath();g.moveTo(cx-5*k,Y);g.lineTo(cx+5*k,Y);g.stroke()});
  g.save();g.translate(cx-4*k,(sy(-za)+sy(-zb))/2);g.rotate(-Math.PI/2);txt(nf(zb-za)+' m',0,0,10.5,'center','#111',true);g.restore();
  /* repères : faîtage et pente */
  var mx=(xa+xb)/2,mz=(za+zb)/2;
  txt('Faîtage '+(G.alongX?'sens X':'sens Y')+' · pente '+nf(G.sl*180/Math.PI,0)+'°',sx(mx),sy(-mz)-12*k,10.5,'center','#7c2d12',true);
  /* nomenclature à droite (la première en haut, les suivantes dessous) */
  var X=xr+14*k,Y=sy(ex.y1)+(22+tb)*k,lh=14*k,ln=function(a,b,bold,col){txt(a,X,Y,11,'left',col||'#111',bold);if(b!=null)txt(b,X+250*k,Y,11,'right',col||'#111',bold);Y+=lh};
  var nm=roofs.length>1?'Toit '+(idx+1)+' — ':'';
  ln(nm+'NOMENCLATURE ('+(G.four?'4 pans':'2 pans')+')',null,true,'#12254a');
  ln('Chevrons 63×75, entraxe '+nf(c.ent)+' m',Q.chev.n+' u · '+nf(Q.chev.ml,1)+' ml');
  if(Q.aret.n)ln('Arêtiers 75×225',Q.aret.n+' u · '+nf(Q.aret.ml,1)+' ml',false,COL.aret);
  if(Q.noue.n)ln('Noues (45°, zinc ou tuiles de noue)',Q.noue.n+' u · '+nf(Q.noue.ml,1)+' ml',false,COL.noue);
  ln('Faîtière 75×225',nf(Q.fait.ml,1)+' ml',false,COL.fait);
  ln('Sablières 75×100',nf(Q.sab.ml,1)+' ml');
  if(Q.panne.ml>0)ln('Pannes intermédiaires 75×225',nf(Q.panne.ml,1)+' ml',false,COL.panne);
  ln('Contre-liteaux 38×38',nf(Q.clit.ml,1)+' ml');
  ln('Liteaux 38×38, pas '+nf(c.pas)+' m ('+Q.rangs+' rangs/pan)',nf(Q.lit.ml,1)+' ml');
  ln('Bois de charpente (hors pertes)',nf(Q.bois,2)+' m³',true);
  Y+=4*k;ln('TUILES',null,true,'#12254a');
  ln('Couverture développée (avec débord)',nf(Q.couv,1)+' m²');
  ln('Tuiles courantes ('+nf(Q.parM2,1)+' / m²)',Q.tuilesCourantes+' u');
  ln('Faîtières et arêtières',Q.tuilesFaitieres+' u');
  ln('Total avec '+nf(Q.perte,0)+' % de pertes',Q.tuiles+' u',true);
  /* légende des traits */
  Y+=6*k;var leg=[['noue','Noue'],['chev','Chevron'],['fait','Faîtière'],['sab','Sablière'],['panne','Panne'],['aret','Arêtier'],['lit','Liteau']];
  leg.forEach(function(q){if(q[0]==='aret'&&!G.four)return;if(q[0]==='noue'&&!Q.noue.n)return;if(q[0]==='panne'&&!Q.panne.ml)return;line2(X,Y-3*k,X+26*k,Y-3*k,COL[q[0]],W[q[0]]);txt(q[1],X+32*k,Y,10,'left','#222');Y+=13*k});tb=(Y-sy(ex.y1))/k-22+14;
  function line2(x0,y0,x1,y1,col,lw){g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.strokeStyle=col;g.lineWidth=lw*k;g.stroke()}
 });
 /* nord */
 var nx=sx(ex.x0)+24*k,ny=sy(ex.y1)+38*k;g.strokeStyle='#111';g.lineWidth=1.4*k;g.beginPath();g.moveTo(nx,ny+22*k);g.lineTo(nx,ny-14*k);g.stroke();g.beginPath();g.moveTo(nx,ny-20*k);g.lineTo(nx-5*k,ny-10*k);g.lineTo(nx+5*k,ny-10*k);g.closePath();g.fillStyle='#111';g.fill();txt('N',nx,ny-26*k,12,'center','#111',true)}

w.EXBCHA={decompose:decompose,calc:calc,calcAll:calcAll,flatInfo:flatInfo,cfg:cfg,render:render,extent:extent,has:has,DEF:DEF,COL:COL};
})(typeof window!=='undefined'?window:globalThis);
