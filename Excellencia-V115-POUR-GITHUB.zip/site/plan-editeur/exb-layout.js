/* Excellencia Arch — disposition façon ArchiCAD : panneaux redimensionnables, flottants/déplaçables, espaces de travail enregistrés.
 * Ordinateur / tablette large (> 820 px). Sur téléphone la disposition en colonne d'origine est conservée.
 * Réglages enregistrés dans le navigateur (clé exbPlanEd.layout et exbPlanEd.ws). Double-clic sur une poignée = taille d'origine. */
(function(){'use strict';
var d=document,K='exbPlanEd.layout',KW='exbPlanEd.ws',main=d.getElementById('main'),tools=d.getElementById('tools'),rcol=d.getElementById('rcol'),work=d.getElementById('work'),top=d.getElementById('top');
if(!main||!tools||!rcol||!work)return;
function wide(){return window.innerWidth>820}
function rd(k,def){try{var v=JSON.parse(localStorage.getItem(k));return v==null?def:v}catch(e){return def}}
function wr(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
var L=rd(K,{});
var st=d.createElement('style');st.textContent=
'.lgrip{display:flex;align-items:center;gap:6px;height:24px;flex:none;margin:-10px -8px 6px;padding:0 6px;background:#0c1b3a;color:#cbd5e8;font:700 11px Arial;letter-spacing:.04em;text-transform:uppercase;cursor:grab;user-select:none;touch-action:none}'
+'#rcol>.lgrip{margin:0;background:#12254a}.lgrip span{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.lgrip button{all:unset;cursor:pointer;padding:0 5px;border-radius:4px;font-size:13px}.lgrip button:hover{background:#ffffff33}'
+'.lspl{flex:none;width:6px;margin:0 -3px;z-index:6;cursor:col-resize;background:transparent;position:relative}.lspl:hover,.lspl.on{background:#c49a3888}'
+'.lsplh{flex:none;height:6px;margin:-3px 0;z-index:6;cursor:row-resize;background:transparent}.lsplh:hover,.lsplh.on{background:#c49a3888}'
+'.lfloat{position:fixed!important;z-index:9000;box-shadow:0 10px 36px #0008;border:1px solid #c49a38;border-radius:8px;overflow:auto;resize:both;min-width:150px;min-height:120px;max-width:96vw;max-height:94vh}'
+'#rcol.lfloat{display:flex!important;flex-direction:column;background:#fff}#tools.lfloat{display:flex!important}'
+'#lmenu{position:fixed;z-index:9500;background:#fff;color:#12254a;border:1px solid #cfd8e8;border-radius:10px;box-shadow:0 10px 30px #0006;padding:6px;min-width:230px;font:600 13px Arial;display:none}#lmenu.on{display:block}'
+'#lmenu button{display:block;width:100%;text-align:left;background:none;border:0;padding:7px 10px;border-radius:6px;font:inherit;color:inherit;cursor:pointer}#lmenu button:hover{background:#e8f0fe}#lmenu hr{border:0;border-top:1px solid #e1e7f2;margin:5px 0}#lmenu small{display:block;padding:4px 10px;color:#64748b;font-weight:700;text-transform:uppercase;font-size:10px}'
+'@media(max-width:820px){.lgrip,.lspl,.lsplh{display:none!important}}';
d.head.appendChild(st);
function relayout(){try{window.dispatchEvent(new Event('resize'))}catch(e){}}
var raf=0;function later(){if(raf)return;raf=requestAnimationFrame(function(){raf=0;relayout()})}
function save(){wr(K,L)}
var DEF={tw:null,rw:null};
function apply(){
 if(!wide()){tools.style.width='';rcol.style.width='';tools.classList.remove('lfloat');rcol.classList.remove('lfloat');return}
 tools.style.width=(!L.tf&&L.tw)?L.tw+'px':'';rcol.style.width=(!L.rf&&L.rw)?L.rw+'px':'';
 [['tf',tools],['rf',rcol]].forEach(function(q){var g=L[q[0]],el=q[1];
  if(g){el.classList.add('lfloat');el.style.left=g.x+'px';el.style.top=g.y+'px';el.style.width=g.w+'px';el.style.height=g.h+'px'}
  else{el.classList.remove('lfloat');el.style.left=el.style.top=el.style.height='';}
  el.style.display=L[q[0]==='tf'?'th':'rh']?'none':''});
 sync();later()}
/* barres de titre */
function grip(el,label,key,hk){var g=d.createElement('div');g.className='lgrip';g.innerHTML='<span>⠿ '+label+'</span><button type="button" title="Flottant / ancré">⧉</button><button type="button" title="Masquer (rouvrir par ▦ Disposition)">–</button>';
 el.insertBefore(g,el.firstChild);var bs=g.querySelectorAll('button');
 bs[0].onclick=function(e){e.stopPropagation();toggleFloat(el,key)};bs[1].onclick=function(e){e.stopPropagation();L[hk]=true;save();apply()};
 var sx,sy,ox,oy,pid=null;
 g.addEventListener('pointerdown',function(e){if(e.target.tagName==='BUTTON'||!wide())return;var r=el.getBoundingClientRect();
  if(!L[key]){L[key]={x:Math.round(r.left),y:Math.round(r.top),w:Math.round(r.width),h:Math.round(Math.min(r.height,window.innerHeight*.8))};apply()}
  sx=e.clientX;sy=e.clientY;ox=L[key].x;oy=L[key].y;pid=e.pointerId;try{g.setPointerCapture(pid)}catch(_){}g.style.cursor='grabbing';e.preventDefault()});
 g.addEventListener('pointermove',function(e){if(e.pointerId!==pid)return;var gg=L[key];gg.x=Math.max(-gg.w+60,Math.min(window.innerWidth-60,ox+e.clientX-sx));gg.y=Math.max(0,Math.min(window.innerHeight-30,oy+e.clientY-sy));el.style.left=gg.x+'px';el.style.top=gg.y+'px'});
 function end(e){if(e.pointerId!==pid)return;pid=null;g.style.cursor='';save()}
 g.addEventListener('pointerup',end);g.addEventListener('pointercancel',end);
 g.addEventListener('dblclick',function(e){if(e.target.tagName!=='BUTTON')toggleFloat(el,key)});
 /* taille d'un panneau flottant (poignée de coin native) : mémorisée */
 if(window.ResizeObserver)new ResizeObserver(function(){if(L[key]&&el.classList.contains('lfloat')){var r=el.getBoundingClientRect();if(Math.abs(r.width-L[key].w)>2||Math.abs(r.height-L[key].h)>2){L[key].w=Math.round(r.width);L[key].h=Math.round(r.height);save()}}}).observe(el)}
function toggleFloat(el,key){if(L[key]){L[key]=null}else{var r=el.getBoundingClientRect();L[key]={x:Math.round(Math.min(r.left+30,window.innerWidth-300)),y:Math.round(r.top+30),w:Math.max(el===tools?190:330,Math.round(r.width)),h:Math.round(Math.min(r.height-40,window.innerHeight*.75))}}save();apply()}
grip(tools,'Outils','tf','th');grip(rcol,'Navigateur · Propriétés','rf','rh');
/* poignées de redimensionnement ancré */
function splitter(cls,after,get,set,dir){var s=d.createElement('div');s.className=cls;after.parentNode.insertBefore(s,after.nextSibling);return s}
function vspl(target,side,key,min,max,dflt){/* side 'r' : poignée à droite du panneau ; 'l' : à gauche */
 var s=d.createElement('div');s.className='lspl';s.title='Glisser pour redimensionner · double-clic = taille d’origine';
 if(side==='r')target.parentNode.insertBefore(s,target.nextSibling);else target.parentNode.insertBefore(s,target);
 var sx,w0,pid=null;
 s.addEventListener('pointerdown',function(e){if(!wide()||L[key==='tw'?'tf':'rf'])return;sx=e.clientX;w0=target.getBoundingClientRect().width;pid=e.pointerId;try{s.setPointerCapture(pid)}catch(_){}s.classList.add('on');e.preventDefault()});
 s.addEventListener('pointermove',function(e){if(e.pointerId!==pid)return;var dx=e.clientX-sx,w=Math.round(Math.max(min,Math.min(max,w0+(side==='r'?dx:-dx))));L[key]=w;target.style.width=w+'px';later()});
 function end(e){if(e.pointerId!==pid)return;pid=null;s.classList.remove('on');save();relayout()}
 s.addEventListener('pointerup',end);s.addEventListener('pointercancel',end);
 s.addEventListener('dblclick',function(){L[key]=null;target.style.width='';save();relayout()});return s}
var sTools=vspl(tools,'r','tw',88,360),sRcol=vspl(rcol,'l','rw',220,720);
/* poignée horizontale entre navigateur (#nav) et propriétés (#side) */
var nav=d.getElementById('nav'),side=d.getElementById('side');
if(nav&&side&&nav.parentNode===rcol){var h=d.createElement('div');h.className='lsplh';h.title='Glisser pour répartir la hauteur · double-clic = d’origine';rcol.insertBefore(h,side);
 var sy0,h0,p0=null;h.addEventListener('pointerdown',function(e){if(!wide())return;sy0=e.clientY;h0=nav.getBoundingClientRect().height;p0=e.pointerId;try{h.setPointerCapture(p0)}catch(_){}h.classList.add('on');e.preventDefault()});
 h.addEventListener('pointermove',function(e){if(e.pointerId!==p0)return;var v=Math.max(80,Math.min(rcol.getBoundingClientRect().height-120,h0+e.clientY-sy0));nav.style.flex='0 0 '+Math.round(v)+'px';L.nh=Math.round(v)});
 h.addEventListener('pointerup',function(e){if(e.pointerId!==p0)return;p0=null;h.classList.remove('on');save()});
 h.addEventListener('dblclick',function(){L.nh=null;nav.style.flex='';save()});
 if(L.nh&&wide())nav.style.flex='0 0 '+L.nh+'px'}
function sync(){sTools.style.display=(L.tf||L.th||!wide())?'none':'';sRcol.style.display=(L.rf||L.rh||!wide())?'none':''}
/* menu Disposition + espaces de travail */
var btn=d.createElement('button');btn.type='button';btn.id='blay';btn.textContent='▦ Disposition';btn.title='Panneaux : afficher, flotter, enregistrer un espace de travail';
var menu=d.createElement('div');menu.id='lmenu';d.body.appendChild(menu);
if(top){var anchor=d.getElementById('bpan');if(anchor)top.insertBefore(btn,anchor);else top.appendChild(btn)}else d.body.appendChild(btn);
function snapshot(){return JSON.parse(JSON.stringify({tw:L.tw||null,rw:L.rw||null,tf:L.tf||null,rf:L.rf||null,th:!!L.th,rh:!!L.rh,nh:L.nh||null}))}
function setLayout(o){L=Object.assign({},o);save();nav&&(nav.style.flex=L.nh?'0 0 '+L.nh+'px':'');apply()}
function build(){var ws=rd(KW,{}),h='<small>Panneaux</small><button data-a="tt">'+(L.th?'☐':'☑')+' Palette d’outils</button><button data-a="rr">'+(L.rh?'☐':'☑')+' Navigateur et propriétés</button><button data-a="ft">⧉ '+(L.tf?'Ancrer':'Détacher')+' la palette</button><button data-a="fr">⧉ '+(L.rf?'Ancrer':'Détacher')+' le navigateur</button><hr><small>Dispositions</small>'
 +'<button data-a="p1">✏️ Dessin (standard)</button><button data-a="p2">🖥 Zone de dessin maximale</button><button data-a="p3">📐 Panneau large (propriétés)</button><button data-a="p4">🪟 Panneaux flottants</button><hr><small>Mes espaces de travail</small>';
 Object.keys(ws).forEach(function(n){h+='<button data-w="'+n.replace(/"/g,'&quot;')+'">⭐ '+n.replace(/</g,'&lt;')+'</button>'});
 h+='<button data-a="sv">💾 Enregistrer la disposition actuelle…</button>'+(Object.keys(ws).length?'<button data-a="dw">🗑 Supprimer un espace de travail…</button>':'')+'<hr><button data-a="rs">↺ Réinitialiser la disposition</button>';menu.innerHTML=h}
function show(){build();var r=btn.getBoundingClientRect();menu.style.top=(r.bottom+4)+'px';menu.style.left=Math.max(6,Math.min(window.innerWidth-250,r.left))+'px';menu.classList.add('on')}
btn.onclick=function(e){e.stopPropagation();menu.classList.contains('on')?menu.classList.remove('on'):show()};
d.addEventListener('click',function(e){if(!menu.contains(e.target))menu.classList.remove('on')});
menu.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var a=b.getAttribute('data-a'),w=b.getAttribute('data-w'),ws=rd(KW,{});
 if(w){if(ws[w])setLayout(ws[w]);menu.classList.remove('on');return}
 if(a==='tt'){L.th=!L.th;save();apply();show();return}if(a==='rr'){L.rh=!L.rh;save();apply();show();return}
 if(a==='ft'){toggleFloat(tools,'tf');show();return}if(a==='fr'){toggleFloat(rcol,'rf');show();return}
 if(a==='p1'||a==='rs')setLayout({});else if(a==='p2')setLayout({th:false,rh:true,tw:null});else if(a==='p3')setLayout({rw:520});
 else if(a==='p4'){var W=window.innerWidth,H=window.innerHeight;setLayout({tf:{x:16,y:110,w:190,h:Math.round(H*.7)},rf:{x:W-360,y:110,w:340,h:Math.round(H*.7)}})}
 else if(a==='sv'){var n=prompt('Nom de cet espace de travail :','Mon espace');if(n&&n.trim()){ws[n.trim()]=snapshot();wr(KW,ws)}}
 else if(a==='dw'){var n2=prompt('Espace à supprimer ('+Object.keys(ws).join(', ')+') :');if(n2&&ws[n2]){delete ws[n2];wr(KW,ws)}}
 menu.classList.remove('on')});
window.addEventListener('resize',function(){sync()});
apply();
window.EXBLAYOUT={reset:function(){setLayout({})},get:snapshot,set:setLayout};
})();
