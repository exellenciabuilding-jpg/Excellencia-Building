/* Objets paramétriques de l'éditeur de plan (à la manière des objets GDL d'ArchiCAD).
 * Chaque objet = une définition { paramètres, fonction de génération } : la fiche de l'objet propose ses paramètres,
 * et la forme 3D est recalculée à chaque modification. Les valeurs sont enregistrées dans le plan (clé facultative `pp` sur l'objet).
 * Pour ajouter un objet : une entrée dans DEFS (k, n, e, w, d, h par défaut, params, gen). gen(pp,w,d,h,b) pose des boîtes en MÈTRES avec b(x0,y0,z0,x1,y1,z1,couleur,forme,param,matériau). */
(function(w){'use strict';
var BOIS='#a98467',BOIS2='#b08968',BOISD='#7c5e46',CAT='Objets paramétriques';
function num(v,p){v=parseFloat(v);if(!isFinite(v))v=p.def;v=Math.min(p.max,Math.max(p.min,v));return p.int?Math.round(v):v}
var DEFS=[
 {k:'p_table',n:'Table (paramétrique)',e:'▦',w:1.6,d:0.8,h:0.75,
  params:[{id:'ep',l:'Épaisseur du plateau (m)',def:0.04,min:0.01,max:0.15,step:0.01},{id:'pied',l:'Section des pieds (m)',def:0.06,min:0.02,max:0.2,step:0.01},{id:'ret',l:'Retrait des pieds (m)',def:0.05,min:0,max:0.5,step:0.01}],
  gen:function(p,W,D,H,b){var r=Math.min(p.ret,W/2-p.pied,D/2-p.pied);r=Math.max(0,r);
   b(0,0,H-p.ep,W,D,H,BOIS2,'r',Math.min(0.01,p.ep/2));
   [[r,r],[W-r-p.pied,r],[r,D-r-p.pied],[W-r-p.pied,D-r-p.pied]].forEach(function(q){b(q[0],q[1],0,q[0]+p.pied,q[1]+p.pied,H-p.ep,BOISD)})}},
 {k:'p_etagere',n:'Étagère (paramétrique)',e:'▤',w:1.0,d:0.35,h:2.0,wall:true,
  params:[{id:'n',l:'Nombre de tablettes',def:4,min:1,max:20,step:1,int:true},{id:'ep',l:'Épaisseur des planches (m)',def:0.025,min:0.01,max:0.08,step:0.005},{id:'fond',l:'Fond (1 = oui, 0 = non)',def:1,min:0,max:1,step:1,int:true}],
  gen:function(p,W,D,H,b){var e=p.ep,i;b(0,0,0,e,D,H,BOISD);b(W-e,0,0,W,D,H,BOISD);
   if(p.fond)b(e,0,0,W-e,0.01,H,'#8d6e53');
   for(i=0;i<=p.n;i++){var z=i===p.n?H-e:i*(H-e)/p.n;b(e,0,z,W-e,D,z+e,BOIS2)}}},
 {k:'p_pergola',n:'Pergola (paramétrique)',e:'⛩',w:4.0,d:3.0,h:2.6,
  params:[{id:'np',l:'Poteaux par grand côté',def:2,min:2,max:8,step:1,int:true},{id:'sect',l:'Section poteaux / poutres (m)',def:0.15,min:0.05,max:0.4,step:0.01},{id:'nl',l:'Nombre de lames de couverture',def:9,min:0,max:40,step:1,int:true}],
  gen:function(p,W,D,H,b){var s=p.sect,i,x,zt=H-s;
   for(i=0;i<p.np;i++){x=i*(W-s)/(p.np-1);b(x,0,0,x+s,s,zt,BOISD);b(x,D-s,0,x+s,D,zt,BOISD)}
   b(0,0,zt,W,s,H,BOIS);b(0,D-s,zt,W,D,H,BOIS);
   for(i=0;i<p.nl;i++){x=p.nl>1?i*(W-0.06)/(p.nl-1):(W-0.06)/2;b(x,-0.1,H,x+0.06,D+0.1,H+0.05,BOIS2)}}}
];
var by={};DEFS.forEach(function(d){by[d.k]=d});
function norm(f,d){var pp=f.pp||{},o={};d.params.forEach(function(p){o[p.id]=num(pp[p.id],p)});return o}
function parts(f,it){var d=by[f.k||it&&it.k];if(!d)return [[0,0,0,1,1,1,'#94a3b8']];var W=f.w,D=f.d,H=f.h,a=[];
 function b(x0,y0,z0,x1,y1,z1,c,sh,pa,mt){a.push([x0/W,y0/D,z0/H,x1/W,y1/D,z1/H,c,sh||'b',pa,mt])}
 d.gen(norm(f,d),W,D,H,b);return a}
function init(it){var d=by[it.k],o={};d.params.forEach(function(p){o[p.id]=p.def});return o}
function rows(f,row){var d=by[f.k];if(!d)return '';var o=norm(f,d);return '<h4 style="margin:6px 0 2px">Paramètres</h4>'+d.params.map(function(p){return row(p.l,'pp_'+p.id,o[p.id],p.step)}).join('')}
function bindAll(f,bind){var d=by[f.k];if(!d)return;d.params.forEach(function(p){bind('pp_'+p.id,function(v){f.pp=f.pp||{};f.pp[p.id]=num(v,p)})})}
w.EXBPARAM={defs:by,list:DEFS,parts:parts,init:init,rows:rows,bind:bindAll};
if(w.EXBCAT){DEFS.forEach(function(d){var it={k:d.k,n:d.n,e:d.e,cat:CAT,w:d.w,d:d.d,h:d.h,param:true,equip:false,wall:!!d.wall};
 it.p=parts({k:d.k,w:d.w,d:d.d,h:d.h,pp:init(it)},it);w.EXBCAT.furn.push(it);w.EXBCAT.furnBy[d.k]=it})}
})(window);
