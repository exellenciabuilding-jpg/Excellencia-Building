EXCELLENCIA BUILDING V75 — CORRECTIONS DE LA V74 (audit)

INSTALLATION
1) Hébergez les fichiers (dossier complet). Le cache du navigateur est renommé « exb-v75 » : les appareils se mettent à jour à la prochaine connexion.
2) Supabase › SQL Editor : exécuter UNE fois supabase/migration-v75-droits-v69-v74.sql
   (après migration-v66, v67 et v68). Elle REMPLACE les anciennes migrations v69 à v74, supprimées car leurs colonnes étaient fausses.
   Aucune table supplémentaire n'est nécessaire (la table exb_offline_operations de la V73 n'était pas utilisée : retirée).
3) Dans « 🗄 Base partagée », vérifier la fonction de chaque membre (inchangé).

CORRECTIONS
- Hors ligne : sw.js met maintenant en cache tous les modules V67 à V75 (nouveau nom de cache exb-v75).
- Droits SQL : colonnes correctes (fonction, collection, lire, ecrire) et vraies collections : price_library, estimates, benchmarks, ai_notes,
  plans_coupes_structure, drawing_sheets, drawing_sets, facility_assets/_workorders/_contracts/_warranties/_inspections.
- Synchronisation : exb-db.js synchronise désormais ces 9 collections supplémentaires (V69 et Maintenance).
- Stockage : nouveau fichier exb-storage-bridge.js (EXBS). V70, V71, V72 et Maintenance écrivaient dans le stockage brut du navigateur,
  que ni la synchronisation ni la sauvegarde ne lisaient. Ils passent par exbStorage. Les anciennes données sont migrées automatiquement à la 1re ouverture.
  Les listes de projets s'affichent aussi correctement (nom au lieu de l'identifiant) dans V71/V72.
- Maintenance / Facility : formulaires complets (listes, dates, champs obligatoires, contrôle des dates, code équipement unique), modification et suppression,
  alertes (interventions en retard, garanties < 30 j, contrats < 60 j, contrôles à planifier), filtre par projet actif, droits par fonction.
- Chantier hors ligne : les boutons Journal, HSE, RFI, Réserve et Pointage enregistrent maintenant dans les vrais modules (journal, QHSE, RFI, réserves, pointage),
  même sans réseau. Fusion par fiche (plus d'écrasement de liste), détection des doublons (pointage) et des droits insuffisants, panneau « à vérifier ».
- Rôles : menus et lecture seule appliqués aux modules V67 à V72 (exb-roles.js). Les boutons V73/V74 ne sont plus placés dans le bouton Administration.

LIMITES CONNUES
- Non testé dans un navigateur ni sur un serveur Supabase réel : à valider (voir ci-dessous).
- Le module « Maintenance » V68 (engins de chantier) et « Facility » (patrimoine) restent distincts ; un import est disponible depuis la V76.
- Le pointage hors ligne exige que le personnel soit déjà chargé sur l'appareil. Les photos hors ligne sont gérées depuis la V76.
- exb-enterprise-v51.js reste dans le paquet (sans effet), supprimable plus tard.

TESTS À FAIRE AVANT MISE EN PRODUCTION
1) Ouvrir le site en ligne, puis couper le réseau et recharger : les menus V67 à V75 doivent s'ouvrir.
2) Créer un équipement + une intervention (Maintenance), vérifier la synchro sur un 2e appareil.
3) Hors ligne : enregistrer une RFI et un pointage ; remettre le réseau ; contrôler l'autre appareil.
4) Avec un compte « magasinier » : Maintenance modifiable, Plans en lecture seule, Intelligence BTP masquée pour les estimations.
