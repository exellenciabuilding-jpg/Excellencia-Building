# V99j — PDF professionnels
- Certificats : filigrane (carte/drapeau RDC ou logo Excellencia) visible dans le PDF, QR code toujours présent.
- Reçus : logo Excellencia, export sur UNE seule page A4.
- Exports d'onglets et rapports : en-tête (logos Excellencia + RDC, coordonnées), titre, date, pied de page « Page n / N », coupures entre les lignes, contenu en haut de page.
- Correction du moteur PDF : taille de page (mm/pt) et position verticale des images.
Les PDF restent des images (texte non sélectionnable). Penser à vider le cache / recharger l'app après mise à jour.
- Fiche/reçu d'inscription téléchargé automatiquement (exb-form.js) : nouvelle mise en page pro (logo, carte matricule, tableau, À retenir, pied de page).
- Générateur commun EXBPdf (exb-pdf.js) refait : fiches BTP, clients, terrain, planning, études, réception, devis… même style pro, multi-pages avec en-tête et pagination.
- Signature manuscrite (doigt) sur le formulaire d'inscription; signature + cachet de l'administrateur (écran ou image importée) dans Logo Excellencia Building; ajout auto sur certificats, reçus, fiches/devis (exb-sign.js). Données gardées sur l'appareil.
