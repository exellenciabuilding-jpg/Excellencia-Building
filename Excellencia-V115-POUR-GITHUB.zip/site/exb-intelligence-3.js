/* EXCELLENCIA INTELLIGENCE — lot 3 : bureau d'études, calcul de structure, planning et pilotage.
 * Extension (à charger APRÈS exb-intelligence.js). LECTURE SEULE des données, sauf la synchronisation de la descente de charges (après confirmation, annulable).
 *  • Notes de calcul (BAEL) : contrôles de cohérence des saisies — ce n'est PAS un recalcul de dimensionnement, qui reste sous la responsabilité de l'ingénieur.
 *  • Planning (Gantt) : durées, avancements, dépassement de la fin du projet, écart avec l'avancement du projet, doublons de planning.
 *  • Honoraires (missions) : facturé supérieur à l'avancement acquis, heures dépassées, budget manquant.
 *  • Pilotage : les alertes du moteur EVM existant (coûts, délais) remontent dans le même panneau.
 *  • Rapport « Dossier d'études » téléchargeable. Pour retirer : supprimer la balise <script src="exb-intelligence-3.js">. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot3) return; I.lot3 = true;
    var H = I.helpers, list = H.list, lab = H.lab, num = H.num, esc = H.esc, toast = H.toast, X = function () { return w.EXBLIEN; };
    function f1(x) { return (Math.round(x * 10) / 10).toString(); }
    function proj(id) { return list('exb_projects').filter(function (p) { return String(p.id) === String(id); })[0]; }
    function pname(id) { var p = proj(id); return p ? lab(p) : 'Sans projet'; }
    function closed(p) { return /termin|cl[oô]tur|livr/i.test((p && p.status) || ''); }

    /* ---- moteurs spécialisés (réutilisables par les autres modules) ---- */
    var CALC = I.calc;
    CALC.descente = function (e) { var G = 0, Q = 0, pp = num(e.v && e.v.pp); (e.lv || []).forEach(function (l) { G += num(l.g) * num(l.s) + pp; Q += num(l.q) * num(l.s); }); return { ns: G + Q, nu: 1.35 * G + 1.5 * Q }; };
    CALC.elancement = function (v) { var circ = v.forme === 'circulaire', a = num(v.a), b = circ ? a : num(v.b), l0 = num(v.l0); if (l0 > 0 && l0 <= 15) l0 *= 100; var lf = num(v.k || 0.7) * l0, mn = Math.min(a, b); if (!(mn > 0) || !(lf > 0)) return 0; return circ ? 4 * lf / a : 3.46 * lf / mn; };
    I.registerEngine('calcul.structure', 'Contrôle des notes de calcul (descente de charges, poteau, semelle, poutre)', function () { return []; });
    I.registerEngine('calcul.planning', 'Contrôle du planning (Gantt) et des honoraires', function () { return []; });

    /* ---- notes de calcul ---- */
    function F(sev, mod, msg, col, id, extra) { var o = { sev: sev, mod: mod, msg: msg, ref: { col: col, id: id } }; if (extra) for (var k in extra) o[k] = extra[k]; return o; }
    function notes() { return list('exb_calc_notes'); }
    I.addRule({ id: 'be.notes', check: function () {
      var out = []; notes().forEach(function (nt) {
        var P = 'Note ' + (nt.no || nt.id) + ' : ', M = 'Bureau d’études', add = function (s, m) { out.push(F(s, M, P + m, 'exb_calc_notes', nt.id)); };
        if (!nt.project_id) add('info', 'aucun projet rattaché');
        if (!String(nt.author || '').trim()) add('info', 'établie sans auteur (à faire valider et signer par l’ingénieur responsable)');
        if (nt.enr != null && num(nt.enr) < 2) add('alerte', 'enrobage inférieur à 2 cm (' + num(nt.enr) + ' cm)');
        (nt.els || []).forEach(function (e) {
          var v = e.v || {}, nm = '« ' + (e.name || e.type) + ' » : ';
          if (e.type === 'dc') { (e.lv || []).forEach(function (l) { if (num(l.g) <= 0 || num(l.s) <= 0 || num(l.q) < 0) add('erreur', nm + 'niveau « ' + (l.n || '?') + ' » avec charge ou surface nulle/négative'); }); }
          else if (e.type === 'col') {
            if (!(num(v.nu) > 0)) add('alerte', nm + 'Nu non renseigné');
            var mn = Math.min(num(v.a), v.forme === 'circulaire' ? num(v.a) : num(v.b)); if (mn > 0 && mn < 20) add('alerte', nm + 'plus petite dimension ' + mn + ' cm (< 20 cm) : à justifier');
            var lam = CALC.elancement(v); if (lam > 70) add('erreur', nm + 'élancement λ = ' + f1(lam) + ' > 70 (hors du domaine de la méthode simplifiée)');
          } else if (e.type === 'foot') {
            if (num(v.sol) <= 0) add('erreur', nm + 'contrainte du sol nulle'); else if (num(v.sol) > 0.6) add('alerte', nm + 'contrainte du sol élevée (' + num(v.sol) + ' MPa) : à justifier par l’étude géotechnique');
            if (!(num(v.ns) > 0) || !(num(v.nu) > 0)) add('alerte', nm + 'Ns ou Nu non renseigné'); else if (num(v.nu) < num(v.ns)) add('alerte', nm + 'Nu ELU (' + num(v.nu) + ') inférieur à Ns ELS (' + num(v.ns) + ') : incohérent');
          } else if (e.type === 'beam') {
            if (num(v.L) <= 0 || num(v.h) <= 0 || num(v.b) <= 0) add('erreur', nm + 'portée ou section nulle');
            else if (num(v.h) < num(v.L) * 100 / 16) add('alerte', nm + 'h < L/16 : flèche à vérifier (non calculée par le module)');
            if (num(v.g) < 0 || num(v.q) < 0) add('erreur', nm + 'charge négative');
          }
        });
      }); return out; } });
    /* synchronisation descente de charges -> poteau / semelle (un seul DC et un seul poteau par note) */
    I.addRule({ id: 'be.dcsync', check: function () {
      var out = []; notes().forEach(function (nt) {
        var dcs = (nt.els || []).filter(function (e) { return e.type === 'dc'; }), cols = (nt.els || []).filter(function (e) { return e.type === 'col'; }), ft = (nt.els || []).filter(function (e) { return e.type === 'foot'; });
        if (dcs.length !== 1 || cols.length !== 1) return; var o = CALC.descente(dcs[0]); if (!(o.nu > 0)) return;
        var cu = num(cols[0].v.nu), bad = cu > 0 && Math.abs(cu - o.nu) / o.nu > 0.02;
        if (bad) out.push(F('alerte', 'Bureau d’études', 'Note ' + (nt.no || nt.id) + ' : Nu du poteau (' + f1(cu) + ' kN) ≠ descente de charges (' + f1(o.nu) + ' kN)', 'exb_calc_notes', nt.id, { note: nt.id, nu: o.nu, ns: o.ns, hasFoot: ft.length === 1 }));
      }); return out; } });
    function nList() { return (X() && X().rd) ? X().rd('exb_calc_notes') : notes(); }
    function nSave(a) { try { if (X() && X().wr) X().wr('exb_calc_notes', a); else if (typeof w.save === 'function') w.save('exb_calc_notes', a); } catch (e) {} }
    I.addFixer('be.dcsync', function (f) { return { label: 'Synchroniser Nu…', run: function () {
      var A = nList(), nt = A.filter(function (x) { return x.id === f.note; })[0]; if (!nt) { toast('Note introuvable : relancez le contrôle.'); return Promise.resolve(); }
      var col = nt.els.filter(function (e) { return e.type === 'col'; })[0], ft = nt.els.filter(function (e) { return e.type === 'foot'; }), ft0 = ft.length === 1 ? ft[0] : null;
      return I.confirm('Aligner le poteau sur la descente de charges ?', 'Poteau : Nu ' + f1(num(col.v.nu)) + ' → ' + f1(f.nu) + ' kN' + (ft0 ? ' ; semelle : Ns → ' + f1(f.ns) + ', Nu → ' + f1(f.nu) + ' kN' : '') + '. Fermez la note si elle est ouverte à l’écran. Les résultats seront recalculés à l’ouverture. Annulable depuis l’historique.', 'Aligner').then(function (ok) {
        if (!ok) return; var before = { col: JSON.stringify(col.v), foot: ft0 ? JSON.stringify(ft0.v) : null, colId: col.id, footId: ft0 ? ft0.id : null };
        col.v.nu = +f.nu.toFixed(1); if (ft0) { ft0.v.ns = +f.ns.toFixed(1); ft0.v.nu = +f.nu.toFixed(1); } nSave(A);
        I.log('synchronisation', 'Note ' + (nt.no || nt.id) + ' : Nu aligné sur la descente de charges', { undo: { type: 'dc_sync', data: { note: nt.id, b: before } } }); toast('Note mise à jour.');
      });
    } }; });
    I.registerUndo('dc_sync', function (data) { var A = nList(), nt = A.filter(function (x) { return x.id === data.note; })[0]; if (!nt) return; nt.els.forEach(function (e) { if (e.id === data.b.colId) e.v = JSON.parse(data.b.col); if (data.b.footId && e.id === data.b.footId) e.v = JSON.parse(data.b.foot); }); nSave(A); });

    /* ---- planning (Gantt) ---- */
    function addDays(iso, n) { var x = new Date(iso + 'T00:00:00Z'); if (isNaN(x)) return ''; x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); }
    I.addRule({ id: 'plan.gantt', check: function () {
      var out = [], G = list('exb_gantt'), seen = {};
      G.forEach(function (g) {
        var p = proj(g.project_id), pn = pname(g.project_id), M = 'Planning', T = g.tasks || [], add = function (s, m) { out.push(F(s, M, 'Planning « ' + pn + ' » : ' + m, 'exb_gantt', g.id)); };
        if (g.project_id) { if (seen[g.project_id]) add('alerte', 'deux plannings pour le même projet (doublon)'); seen[g.project_id] = 1; } else add('info', 'planning sans projet');
        var endW = 0, sw = 0, sp = 0;
        T.forEach(function (t) {
          if (num(t.dur) <= 0 || num(t.start) < 1) add('erreur', 'tâche « ' + (t.name || '?') + ' » : début ou durée invalide');
          if (num(t.pct) < 0 || num(t.pct) > 100) add('erreur', 'tâche « ' + (t.name || '?') + ' » : avancement hors de 0–100 %');
          if (!String(t.name || '').trim()) add('info', 'tâche sans nom');
          endW = Math.max(endW, num(t.start) + num(t.dur) - 1); sw += Math.max(0, num(t.dur)); sp += Math.max(0, num(t.dur)) * Math.min(100, Math.max(0, num(t.pct)));
        });
        if (p && g.date && p.end && endW > 0) { var pe = addDays(g.date, endW * 7 - 1); if (pe && pe > addDays(p.end, 6)) add('alerte', 'se termine vers le ' + pe + ', après la fin prévue du projet (' + p.end + ')'); }
        if (p && sw > 0 && p.progress != null && p.progress !== '') { var pg = sp / sw; if (Math.abs(pg - num(p.progress)) > 15) out.push(F('info', M, 'Projet « ' + pn + ' » : avancement saisi ' + f1(num(p.progress)) + ' % ≠ planning ' + f1(pg) + ' %', 'exb_projects', p.id)); }
        if (p && closed(p) && T.some(function (t) { return num(t.pct) < 100; })) add('alerte', 'projet terminé mais des tâches ne sont pas à 100 %');
      }); return out; } });

    /* ---- honoraires du bureau d'études ---- */
    I.addRule({ id: 'be.missions', check: function () {
      var out = [], Tm = list('exb_be_time'), Ms = list('exb_be_missions'), ids = {};
      Ms.forEach(function (mi) {
        ids[mi.id] = 1; var T = Tm.filter(function (x) { return x.mission_id === mi.id; }), h = T.reduce(function (a, x) { return a + num(x.h); }, 0), p = proj(mi.project_id),
          hon = mi.mode === 'forfait' ? num(mi.amount) : mi.mode === 'pct' ? num(p && p.budget) * num(mi.pct) / 100 : h * num(mi.taux), acq = mi.mode === 'horaire' ? hon : hon * num(mi.avance) / 100,
          add = function (s, m) { out.push(F(s, 'Honoraires', 'Mission « ' + (mi.title || mi.id) + ' » : ' + m, 'exb_be_missions', mi.id)); };
        if (num(mi.billed) > acq + 0.5) add('alerte', 'facturé (' + num(mi.billed).toFixed(2) + ') supérieur à l’avancement acquis (' + acq.toFixed(2) + ')');
        if (mi.mode === 'pct' && !(p && num(p.budget) > 0)) add('alerte', 'honoraires en % du budget mais le projet n’a pas de budget');
        if (num(mi.hbud) > 0 && h > num(mi.hbud)) add('alerte', 'heures dépassées (' + h.toFixed(1) + ' h sur ' + num(mi.hbud).toFixed(0) + ' prévues)');
      });
      Tm.forEach(function (t) { if (t.mission_id && !ids[t.mission_id]) out.push(F('info', 'Honoraires', 'Heures saisies sur une mission qui n’existe plus', 'exb_be_time', t.id)); });
      return out; } });

    /* ---- pilotage : alertes du moteur EVM existant ---- */
    I.registerEngine('pilotage', 'Pilotage projets (EVM : coûts, délais)', function () {
      var E = w.EXBEVM, out = []; if (!E || !E.analyseProject) return out;
      var G = list('exb_gantt'), B = list('exb_budgets'), C = list('exb_cash'), V = list('exb_invoices'), t = H.today();
      list('exb_projects').forEach(function (p) {
        if (closed(p)) return;
        var g = G.filter(function (x) { return String(x.project_id) === String(p.id); })[0], b = B.filter(function (x) { return String(x.project_id) === String(p.id); })[0],
          rc = C.filter(function (c) { return String(c.project_id) === String(p.id); }), cash = rc.reduce(function (a, c) { return c.type === 'out' ? a + num(c.amount) : a; }, 0),
          late = V.filter(function (i) { return String(i.project_id) === String(p.id) && i.due && i.due < t && I.calc.invoice(i).reste > 0.005; }).length;
        try { var a = E.analyseProject(p, g, b, cash, t, late, E.thFor([], p.id), rc); (a.alerts || []).forEach(function (al) { if (al.sev === 'low') return; out.push({ sev: al.sev === 'high' ? 'erreur' : 'alerte', mod: 'Pilotage', msg: 'Projet « ' + lab(p) + ' » : ' + al.msg, ref: { col: 'exb_projects', id: p.id } }); }); } catch (e) {}
      }); return out;
    });

    /* ---- recommandations et rapport ---- */
    function dossierHtml() {
      var P = list('exb_projects'), rows = P.map(function (p) {
        var N = notes().filter(function (x) { return x.project_id === p.id; }), g = list('exb_gantt').filter(function (x) { return x.project_id === p.id; })[0], M = list('exb_be_missions').filter(function (x) { return x.project_id === p.id; });
        var fs = I.findings().filter(function (f) { return f.ref && ((f.ref.col === 'exb_projects' && f.ref.id === p.id) || (/^exb_(calc_notes|gantt|be_missions)$/.test(f.ref.col) && ((f.ref.col === 'exb_calc_notes' && N.some(function (n) { return n.id === f.ref.id; })) || (f.ref.col === 'exb_gantt' && g && g.id === f.ref.id) || (f.ref.col === 'exb_be_missions' && M.some(function (m) { return m.id === f.ref.id; }))))); });
        return '<tr><td>' + esc(lab(p)) + '</td><td>' + N.length + '</td><td>' + (g ? (g.tasks || []).length : 0) + '</td><td>' + M.length + '</td><td>' + (fs.length ? '<ul>' + fs.map(function (f) { return '<li>' + esc(f.msg) + '</li>'; }).join('') + '</ul>' : 'RAS') + '</td></tr>';
      }).join('');
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Dossier d’études</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Dossier d’études par projet</h1><p>' + H.today() + ' — contrôle de cohérence des saisies ; ne remplace pas la vérification et la signature de l’ingénieur responsable.</p><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Projet</th><th>Notes</th><th>Tâches</th><th>Missions</th><th>Points à vérifier</th></tr>' + (rows || '<tr><td colspan="5">Aucun projet</td></tr>') + '</table></body></html>';
    }
    I.docs.dossierEtudes = dossierHtml;
    I.addReco(function () {
      var r = [], nS = notes().filter(function (n) { return !String(n.author || '').trim(); }).length;
      if (nS) r.push({ ic: '🧮', t: nS + ' note(s) de calcul sans auteur', x: 'À faire valider et signer par l’ingénieur responsable avant diffusion.', acts: [{ l: 'Ouvrir le bureau d’études', f: function () { H.go('bureauEtudes'); } }] });
      var lt = I.findings().filter(function (f) { return f.rule === 'plan.gantt' && /après la fin prévue/.test(f.msg); }).length;
      if (lt) r.push({ ic: '📅', t: lt + ' planning(s) dépassent la fin prévue du projet', x: 'Replanifier ou décaler la date de fin du projet.', acts: [{ l: 'Ouvrir le planning', f: function () { H.go('planning'); } }] });
      if (list('exb_projects').length) r.push({ ic: '🗂️', t: 'Dossier d’études par projet', x: 'Notes, planning, honoraires et points à vérifier par projet.', acts: [{ l: 'Télécharger le dossier', f: function () { try { var b = new Blob([dossierHtml()], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'dossier-etudes-' + H.today() + '.html'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); I.log('document', 'Dossier d’études exporté'); } catch (e) { toast('Export impossible.'); } } }] });
      return r;
    });
    I.run();
  }
  boot(0);
})(window, document);
