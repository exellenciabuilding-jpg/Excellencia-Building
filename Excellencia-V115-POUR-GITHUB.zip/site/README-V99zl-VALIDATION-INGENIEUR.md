# V99zl — Ingénierie P3 : validation par un ingénieur, cachet et journal des versions

Fichiers modifiés : `calcul-structure/exb-calcul-doc.js`, `calcul-structure/index.html`, `exb-calcul-structure.js`, `exb-v99r-shell.js`, `sw.js` (cache `exb-v99zl-validation-ingenieur-1`).

## Circuit de validation (notes de calcul et plans d'exécution)
Dans l'aperçu d'une note ou d'un plan, nouvelle fiche « ✅ Vérification et validation par un ingénieur » :
- **Statuts** : Émis (non validé) · Soumis à vérification · Validé · Validé avec réserves · Refusé.
- **Validé** exige : nom de l'ingénieur, n° d'inscription à l'ordre, déclaration de responsabilité cochée. « Avec réserves » et « Refusé » exigent un commentaire.
- **Cachet et signature** : image de l'ingénieur (réduite et gardée sur l'appareil), imprimée sur la page de garde, dans les visas de la dernière page et dans le cartouche des plans.
- **Lien avec la version** : la validation porte sur l'empreinte du contenu. Si les données changent, le statut redevient « Émis » et le journal avertit que la dernière validation portait sur une autre version.
- **Journal des versions** par projet et par type de calcul : indice, date, n°, statut, ingénieur, observations ; la version actuelle est repérée.
- **Impression** : filigrane « EN VÉRIFICATION » ou « REFUSÉ » selon le statut ; page de garde avec « Validé par », n° d'ordre, date, réserves ; mention légale (nouvelle validation à chaque modification) ; le QR de vérification porte le statut et le nom du validateur.

## Notes de calcul pour les modules simples
Vent, Séisme, Pieu foré et Maçonnerie ont maintenant un bouton « 📝 Note de calcul » (données, résultats, observations, formules, norme propre au module), donc la même habillage et la même validation que Poutre, Poteau, etc.

## Limites
- Journal, statuts et cachet sont gardés **sur l'appareil** (comme le reste du calculateur) : ils ne sont ni synchronisés ni protégés contre une modification par un utilisateur technique. Pour une valeur probante, il faudra les enregistrer côté serveur avec l'identité authentifiée de l'ingénieur (voir l'audit, priorité 1).
- Le cachet est une image : ce n'est pas une signature électronique qualifiée. Le QR du registre en ligne reste la preuve d'authenticité du document imprimé.
- Les mentions légales sont génériques : à faire relire selon l'ordre des ingénieurs et la réglementation du pays.

Reste dans « Ingénierie P3 » : structures acier et bois, éléments finis.
Retour en arrière : restaurer les 5 fichiers de V99zk.
