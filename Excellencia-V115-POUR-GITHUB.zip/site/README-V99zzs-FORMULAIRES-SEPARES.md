# V99zzs — Un formulaire = un lien = un seul profil

Avant : `inscription.html` affichait le menu de tous les profils (apprenant, TP/TD, formateur, client, personnel, logiciel, BTP, épreuves, résultats). Maintenant chaque personne ne voit QUE son formulaire.

| Profil | Lien (même dossier que le logiciel) |
|---|---|
| Apprenant | `/inscription.html?type=apprenant` (ou `/inscription`) |
| Demande TP / TD | `/inscription.html?type=tp_td` (ou `/demande-tp-td.html`) |
| Formateur | `/inscription.html?type=formateur` (ou `/formateur.html`) |
| Client | `/inscription.html?type=client` (ou `/client.html`) |
| Personnel | `/inscription.html?type=personnel` (ou `/personnel.html`) |
| Demande de logiciel | `/inscription.html?type=logiciel` (ou `/logiciel.html`) |
| BTP · Architecture · Divers | `/inscription.html?type=projet` (ou `/btp.html`) |
| TFL | `/tfl-formulaire.html` (ou `/tfl`) |
| Épreuves / Résultats | `/epreuve.html` · `/apprenant.html` (inchangés, pages déjà séparées) |

- Plus de menu ni de liens vers les autres profils. Un ancien lien sans `?type=` ouvre le formulaire **apprenant** seul. Le menu complet n'existe que pour le personnel : `?type=choix`.
- Dans le logiciel, chaque onglet (Participants, TP/TD, Formateurs, Clients, RH, Projets) et chaque onglet des demandes en ligne copie / envoie par WhatsApp le lien de SON formulaire.
- Hors connexion : « 📴 Formulaires hors connexion » propose un sélecteur de profil ; le fichier généré ne contient que ce formulaire (`Excellencia-Building-Formulaire-<profil>-Hors-Connexion.html`).
- Aucun changement serveur : pas de SQL à exécuter pour cette version. Les redirections courtes sont dans `_redirects` (Netlify) ; les liens `?type=` fonctionnent sur tout hébergement.
- Après mise à jour : recharger une fois (cache `exb-v99zzs-formulaires-separes`).

Contrôles : `python3 tools/test-formulaires-separes.py` · `node tools/check.js` (357).
