# V99zzu — TFL : bibliothèque (TFL résolus + sujets reçus en PDF ou autre format)

Nouveau module dans l'onglet **🎓 TFL › 📚 Bibliothèque**. Il fonctionne **sans serveur ni SQL** (aucune migration à exécuter), comme le mode local V99zzq.

## Deux onglets
| | 🎓 TFL résolus | 📥 Sujets reçus |
|---|---|---|
| Rôle | garder les TFL déjà résolus pour s'en servir de références | recevoir le sujet de ceux qui veulent être encadrés |
| Ajout | « ⬆ Importer » : un ou **plusieurs fichiers** à la fois (titre pris dans le nom du fichier) ou fiche seule | « 📥 Recevoir » : nom (obligatoire), téléphone, titre, domaine, université + le fichier reçu |
| Fiche | titre, auteur, année, université, domaine, encadreur, mots-clés, résumé | idem + téléphone et **statut** : À étudier · Accepté · À réviser · Refusé |
| Actions | 👁 Ouvrir (PDF, images, texte) · ⬇ Télécharger · 📎 Joindre un fichier · ✏ Modifier · 🗑 Supprimer | idem + 💬 WhatsApp (message prêt) · ➡ **Créer le dossier** |

## Formats et limites de fichier
PDF, Word (doc, docx, odt, rtf), texte, PowerPoint, Excel/CSV, zip, images (jpg, png). **25 Mo maximum** par fichier. Un même fichier n'est pas importé deux fois.

## Liens avec le reste du module TFL
- **Sujet reçu → dossier** : « ➡ Créer le dossier » ouvre un dossier de candidature (n° TFL-AAAA-0001, étape 1, statut Reçu). Il faut le nom et le téléphone. Problématique et objectifs sont marqués « À compléter » avec le nom du fichier : complétez-les dans le dossier, puis suivez le parcours habituel (matricule, décision, encadreur).
- **Dossier terminé → bibliothèque** : dans la fiche d'un dossier Clos (ou étape 9), « 📚 Garder dans la bibliothèque » crée la fiche du TFL résolu ; on y joint ensuite le document final avec « 📎 Joindre un fichier ».
- **Recherche** par titre, auteur, année, université, encadreur, mots-clés ou nom de fichier (sans tenir compte des accents), filtre par domaine, **catalogue CSV** (ouvre dans Excel).

## Où sont les données
- **Fiches** : clé locale `exb_tfl_biblio`, incluse dans « ⬇ Sauvegarde » / « ⬆ Restaurer » du module TFL.
- **Fichiers** : base IndexedDB `exb_tfl_biblio` de **cet appareil**. Ils ne sont **pas** dans la sauvegarde JSON (trop lourds) : conservez vos originaux. Après une restauration sur un autre appareil, les fiches reviennent mais pas les fichiers : « Ouvrir » l'indique, et on rejoint le fichier avec « 📎 Joindre » (après suppression de la fiche et réimportation, si elle avait déjà un fichier).
- Vider les données du navigateur efface aussi les fichiers.

## Limites
- Les portails étudiant / encadreur (V99zzt) **ne reçoivent pas encore de fichiers** : l'étudiant envoie son sujet par WhatsApp ou e-mail, et vous l'enregistrez ici. Un dépôt direct depuis le portail demanderait un stockage serveur (bucket Supabase) et une migration SQL à part.
- Pas de lecture du contenu des documents : la recherche porte sur la fiche, pas sur le texte du PDF.
- Pas d'envoi automatique : le bouton WhatsApp ouvre la conversation avec le message prêt.
- Testé dans **Chromium** (écran sur 390 px, import, recherche, téléchargement, rechargement) sur une page minimale ; non testé dans l'application complète ni sur un vrai téléphone : vérifiez l'ouverture des PDF sur mobile.

## Fichiers
Modifiés : `exb-tfl.js` (module + écran), `sw.js` (cache `exb-v99zzu-tfl-biblio`), `tools/check.js` (+3 contrôles), `tools/test-tfl/test.js` (+25). Nouveau : `tools/test-tfl/e2e-biblio.py`.

## Contrôles
`node tools/test-tfl/test.js` · `python3 tools/test-tfl/e2e-biblio.py` (Chromium) · `node tools/check.js`.
Retour en arrière : restaurer `exb-tfl.js`, `sw.js`, `tools/check.js`, `tools/test-tfl/test.js` de V99zzt. Les fiches déjà saisies restent dans `exb_tfl_biblio`.
