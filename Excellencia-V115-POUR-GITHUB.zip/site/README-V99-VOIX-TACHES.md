# V99 — Assistant IA : écoute de la voix + nouvelles tâches automatiques

Fichiers : `site/exb-voix.js` (nouveau), `site/index.html` (assistant), `site/sw.js` (cache hors connexion), `package.json` et `scripts/patch-android.js` (application Android). **Aucun SQL.**

## 1. La voix (dans la fenêtre 🤖)
- **🎤** : touchez, parlez, la phrase s'écrit en direct puis part à l'assistant. Touchez ⏹ pour arrêter.
- **🎧 Mains libres** : après chaque réponse l'assistant réécoute tout seul. Dites « stop » (ou « arrête », « silence ») pour arrêter. Active aussi la lecture des réponses.
- **🔊** : lit les réponses à voix haute (voix française de l'appareil).
- Les réglages 🎧 / 🔊 sont mémorisés sur l'appareil. Fermer la fenêtre coupe le micro.
- Une phrase dite passe par **les mêmes autorisations** que si elle était tapée (Paramètres › 🤖 Assistant IA : Interdit / Demander / Automatique). La voix ne donne aucun droit en plus.

## 2. Où la voix fonctionne
| Appareil | Moteur | Remarque |
|---|---|---|
| Chrome / Edge (PC), Chrome Android, PWA installée | reconnaissance du navigateur | https obligatoire (Netlify : oui) |
| Application Android (APK) | plugin `@capacitor-community/speech-recognition` | à installer : `npm install` puis `npm run android:sync` |
| Application Windows (Electron) | aucun | le micro est masqué ; utilisez Chrome/Edge |
- **Internet** : la reconnaissance vocale du navigateur et d'Android envoie le son au service vocal du système (Google en général). Sans internet, le micro peut échouer : le clavier marche toujours, et le reste du logiciel reste hors connexion.
- Si le navigateur ne gère pas la voix, le bouton 🎤 n'apparaît pas et rien d'autre ne change.

## 3. Nouvelles tâches (assistant local, sans clé ni internet)
Phrases d'exemple :
- « **cherche Jean Kasongo** » / « trouve la fiche de Marie » → cherche dans participants, formateurs, clients, personnel, projets de cet appareil et propose d'ouvrir l'onglet.
- « **combien d'apprenants ?** », « combien de formateurs et de clients », « combien de reçus » → chiffres de cet appareil (participants approuvés / en attente).
- « **mets le mode sombre** » / « mode clair » → change le thème (annulable).
- « **fais une sauvegarde** » → télécharge la sauvegarde complète.

Deux nouvelles lignes dans Paramètres › 🤖 Assistant IA : **Changer le thème** et **Lancer une sauvegarde**, chacune réglable (Interdit / Demander / Automatique, par défaut *Demander*). La recherche et les chiffres sont en lecture seule : ils n'ont pas besoin d'autorisation.

## 4. Mise en place
1. Netlify : déposer le ZIP comme d'habitude (le service worker prend la nouvelle version).
2. Android : `npm install`, `npm run android:sync` (ajoute la permission micro RECORD_AUDIO), puis refaire l'APK. Au premier appui sur 🎤, Android demande l'autorisation du micro.

## Limites
- Testé : syntaxe des 16 scripts de `index.html`, règles de l'assistant sur 16 phrases types, et le parcours voix (micro → texte → envoi → mot « stop ») avec un faux moteur de reconnaissance.
- **Non testé** : micro réel dans un navigateur ou sur un téléphone, plugin Android (non installé ici), lecture à voix haute réelle. À essayer d'abord sur Chrome (PC ou téléphone).
- Ce n'est **pas** une identification du locuteur : l'assistant comprend ce qui est dit, il ne reconnaît pas qui parle. Ne pas s'en servir comme mot de passe.
- La reconnaissance se trompe sur les noms propres ou les numéros : vérifiez le texte affiché avant d'« Appliquer » une action.

Retour en arrière : restaurer `index.html`, `sw.js`, `package.json`, `scripts/patch-android.js` et supprimer `exb-voix.js`.
