/* Excellencia Building V76 — Maintenance & Facility Management (refonte du module V74)
 * Stockage via EXBS (exbStorage) => synchronisé par la base partagée, sauvegardé, soumis aux droits par fonction.
 * Saisie par formulaire (plus de prompt()), alertes d'échéance, filtre par projet actif. */
(function(w,d){'use strict';
var K={assets:'exb_facility_assets',work:'exb_facility_workorders',contracts:'exb_facility_contracts',warranties:'exb_facility_warranties',inspections:'exb_facility_inspections'};
var COL={assets:'facility_assets',work:'facility_workorders',contracts:'facility_contracts',warranties:'facility_warranties',inspections:'facility_inspections'};
var LBL={assets:'Équipement',work:'Intervention',contracts:'Contrat',warranties:'Garantie',inspections:'Inspection'};
var CLOSED=['terminée','annulée'];
var FORMS={
 assets:[{k:'code',l:'Code équipement',r:1},{k:'name',l:'Désignation',r:1},{k:'category',l:'Catégorie',t:['Électricité','Plomberie','CVC / Climatisation','Ascenseur','Sécurité incendie','Groupe électrogène','Toiture / Étanchéité','Autre']},{k:'location',l:'Localisation'},{k:'status',l:'État',t:['actif','en panne','hors service'],def:'actif'}],
 work:[{k:'asset_code',l:'Code équipement',r:1},{k:'type',l:'Type',t:['préventive','corrective','urgence'],def:'préventive'},{k:'priority',l:'Priorité',t:['basse','normale','haute','critique'],def:'normale'},{k:'due_date',l:'Échéance',d:1,r:1},{k:'technician',l:'Technicien / prestataire'},{k:'status',l:'Statut',t:['à faire','en cours','terminée','annulée'],def:'à faire'},{k:'recurrence',l:'Récurrence (préventif)',t:['aucune','mensuelle','trimestrielle','semestrielle','annuelle'],def:'aucune'},{k:'note',l:'Description',ta:1},{k:'photos',l:'Photos (2 max)',ph:1}],
 contracts:[{k:'supplier',l:'Prestataire',r:1},{k:'reference',l:'Référence contrat'},{k:'start_date',l:'Début',d:1},{k:'end_date',l:'Fin',d:1,r:1},{k:'frequency',l:'Fréquence',t:['mensuelle','trimestrielle','semestrielle','annuelle'],def:'annuelle'},{k:'amount',l:'Montant'}],
 warranties:[{k:'asset_code',l:'Code équipement',r:1},{k:'provider',l:'Fournisseur / garant',r:1},{k:'start_date',l:'Début',d:1},{k:'end_date',l:'Fin',d:1,r:1},{k:'status',l:'Statut',t:['active','expirée'],def:'active'}],
 inspections:[{k:'asset_code',l:'Code équipement',r:1},{k:'type',l:'Type de contrôle',r:1},{k:'date',l:'Date',d:1,r:1},{k:'result',l:'Résultat',t:['conforme','non conforme','réserves'],def:'conforme'},{k:'next_date',l:'Prochain contrôle',d:1}]
};
var COLS_SHOW={assets:['code','name','category','location','status'],work:['asset_code','type','priority','due_date','status','recurrence','photos'],contracts:['supplier','reference','start_date','end_date','frequency'],warranties:['asset_code','provider','start_date','end_date','status'],inspections:['asset_code','type','date','result','next_date']};
var HEAD={code:'Code',name:'Désignation',category:'Catégorie',location:'Lieu',status:'Statut',asset_code:'Équipement',type:'Type',priority:'Priorité',due_date:'Échéance',technician:'Technicien',recurrence:'Récurrence',photos:'Photos',supplier:'Prestataire',reference:'Réf.',start_date:'Début',end_date:'Fin',frequency:'Fréquence',provider:'Garant',date:'Date',result:'Résultat',next_date:'Prochain'};
function load(t){return w.EXBS.get(K[t])}
function save(t,a){return w.EXBS.set(K[t],a)}
function uid(){return 'FM-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7)}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}}
function proj(){try{return localStorage.getItem('exb_active_project')||''}catch(e){return''}}
function canW(t){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL[t],'ecrire')}catch(e){return true}}
function canR(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can('facility_assets','lire')}catch(e){return true}}
function days(s){if(!s)return null;var t=new Date(s+'T00:00:00');return isNaN(t)?null:Math.round((t-new Date(new Date().toDateString()))/86400000)}
function mine(a){var p=proj();return p?a.filter(function(x){return !x.project||x.project===p}):a}
function ui(){var badm=d.getElementById('badm');if(!badm||d.getElementById('exbV74Btn'))return;var b=d.createElement('button');b.id='exbV74Btn';b.textContent='🏢 Maintenance / Facility';b.className='muted';b.onclick=panel;badm.parentNode.appendChild(b);rights()}
function rights(){var b=d.getElementById('exbV74Btn');if(!b)return;if(canR())b.removeAttribute('data-exbrole');else b.setAttribute('data-exbrole','hide')}
function shell(){return '<div style="background:#fff;color:#111;width:min(1100px,100%);max-height:92vh;overflow:auto;border-radius:16px;padding:18px"><div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><div><h2 style="margin:0">🏢 Maintenance & Facility</h2><small>Après-construction · patrimoine · équipements · interventions</small></div><button class="muted" id="v74x">✕</button></div><div id="v74kpi" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;margin:14px 0"></div><div id="v74bar" style="display:flex;gap:6px;flex-wrap:wrap"></div><div id="v74alerts"></div><div id="v74out" style="margin-top:14px"></div></div>'}
function panel(){var old=d.getElementById('exbV74Panel');if(old){old.remove();return}var p=d.createElement('div');p.id='exbV74Panel';p.style.cssText='position:fixed;inset:0;z-index:99998;background:#0006;display:flex;align-items:center;justify-content:center;padding:14px';p.onclick=function(e){if(e.target===p)p.remove()};p.innerHTML=shell();d.body.appendChild(p);d.getElementById('v74x').onclick=function(){p.remove()};
 var bar=d.getElementById('v74bar');Object.keys(LBL).forEach(function(t,i){var b=d.createElement('button');b.className=i?'muted smallbtn':'primary smallbtn';b.textContent='+ '+LBL[t];b.disabled=!canW(t);b.onclick=function(){form(t)};bar.appendChild(b)});
 var ex=[['🏷 Étiquettes QR',labels],['📅 Planifier 12 mois',planify],['⬇ Importer matériel (V68)',importV68]];ex.forEach(function(a){var b=d.createElement('button');b.className='muted smallbtn';b.textContent=a[0];b.onclick=a[1];bar.appendChild(b)});render()}
function card(t,v,warn){return '<div style="border:1px solid '+(warn?'#e0a0a0':'#ddd')+';border-radius:10px;padding:10px"><small>'+t+'</small><div style="font-size:22px;font-weight:700;color:'+(warn?'#b00020':'inherit')+'">'+v+'</div></div>'}
function render(){var out=d.getElementById('v74out');if(!out)return;var A=mine(load('assets')),W=mine(load('work')),C=mine(load('contracts')),G=mine(load('warranties')),I=mine(load('inspections'));
 var open=W.filter(function(x){return CLOSED.indexOf(x.status)<0}),late=open.filter(function(x){var n=days(x.due_date);return n!==null&&n<0});
 var gExp=G.filter(function(x){var n=days(x.end_date);return n!==null&&n>=0&&n<=30}),cExp=C.filter(function(x){var n=days(x.end_date);return n!==null&&n>=0&&n<=60}),iDue=I.filter(function(x){var n=days(x.next_date);return n!==null&&n<=30});
 d.getElementById('v74kpi').innerHTML=card('Équipements',A.length)+card('En panne',A.filter(function(x){return x.status==='en panne'}).length,1)+card('Interventions ouvertes',open.length)+card('En retard',late.length,late.length>0)+card('Garanties < 30 j',gExp.length,gExp.length>0)+card('Contrats < 60 j',cExp.length,cExp.length>0)+card('Contrôles à prévoir',iDue.length,iDue.length>0);
 var al=[];late.forEach(function(x){al.push('⏰ Intervention en retard : '+esc(x.asset_code)+' ('+esc(x.due_date)+')')});gExp.forEach(function(x){al.push('🛡 Garantie bientôt expirée : '+esc(x.asset_code)+' ('+esc(x.end_date)+')')});cExp.forEach(function(x){al.push('📄 Contrat à renouveler : '+esc(x.supplier)+' ('+esc(x.end_date)+')')});iDue.forEach(function(x){al.push('🔍 Contrôle à planifier : '+esc(x.asset_code)+' '+esc(x.type)+' ('+esc(x.next_date)+')')});
 d.getElementById('v74alerts').innerHTML=al.length?'<div style="margin-top:12px;background:#fff4d6;border:1px solid #e0b84c;border-radius:10px;padding:10px;font-size:13px">'+al.slice(0,12).join('<br>')+(al.length>12?'<br>… +'+(al.length-12):'')+'</div>':'';
 var sets={assets:A,work:W,contracts:C,warranties:G,inspections:I};out.innerHTML=Object.keys(LBL).map(function(t){return '<h3>'+LBL[t]+'s</h3>'+table(t,sets[t])}).join('')}
function table(t,a){if(!a.length)return '<p class="exb-muted">Aucun enregistrement.</p>';var cols=COLS_SHOW[t],w_=canW(t);return '<div style="overflow:auto"><table class="exb-table"><thead><tr>'+cols.map(function(c){return '<th>'+esc(HEAD[c]||c)+'</th>'}).join('')+'<th></th></tr></thead><tbody>'+a.map(function(x){return '<tr>'+cols.map(function(c){return '<td>'+(c==='photos'?((x.photos||[]).length?'📷 '+x.photos.length:''):esc(x[c]))+'</td>'}).join('')+'<td style="white-space:nowrap">'+(w_?'<button class="muted smallbtn" data-e="'+t+'|'+esc(x.id)+'">✎</button> <button class="danger smallbtn" data-x="'+t+'|'+esc(x.id)+'">×</button>':'🔒')+'</td></tr>'}).join('')+'</tbody></table></div>'}
d.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-e],[data-x]');if(!b||!d.getElementById('exbV74Panel')||!d.getElementById('exbV74Panel').contains(b))return;var v=(b.getAttribute('data-e')||b.getAttribute('data-x')).split('|');if(b.hasAttribute('data-e'))form(v[0],v[1]);else del(v[0],v[1])});
function field(f,val,cur){if(f.ph)return '<label style="display:block;margin:8px 0;font-size:13px"><b>'+esc(f.l)+'</b>'+(cur&&cur.photos&&cur.photos.length?' <small>('+cur.photos.length+' déjà jointe(s) ; en ajouter remplace)</small>':'')+'<input id="v74f_photos" type="file" accept="image/*" multiple style="width:100%;padding:6px"></label>';var id='v74f_'+f.k,v=val==null?(f.def||''):val,s='width:100%;padding:8px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box';var inp;
 if(f.t)inp='<select id="'+id+'" style="'+s+'">'+f.t.map(function(o){return '<option'+(o===v?' selected':'')+'>'+esc(o)+'</option>'}).join('')+'</select>';
 else if(f.ta)inp='<textarea id="'+id+'" rows="3" style="'+s+'">'+esc(v)+'</textarea>';
 else inp='<input id="'+id+'" type="'+(f.d?'date':'text')+'" value="'+esc(v)+'" style="'+s+'">';
 return '<label style="display:block;margin:8px 0;font-size:13px"><b>'+esc(f.l)+(f.r?' *':'')+'</b>'+inp+'</label>'}
function form(t,id,pre){if(!canW(t)){say('Droits insuffisants pour modifier cette section.','warn');return}var cur=id?load(t).find(function(x){return x.id===id}):null;pre=pre||{};var m=d.createElement('div');m.id='exbV74Form';m.style.cssText='position:fixed;inset:0;z-index:99999;background:#0008;display:flex;align-items:center;justify-content:center;padding:14px';
 m.innerHTML='<div style="background:#fff;color:#111;width:min(520px,100%);max-height:90vh;overflow:auto;border-radius:14px;padding:16px"><h3 style="margin:0 0 6px">'+(cur?'Modifier':'Nouveau')+' — '+LBL[t]+'</h3>'+FORMS[t].map(function(f){return field(f,cur?cur[f.k]:pre[f.k],cur)}).join('')+'<div id="v74err" style="color:#b00020;font-size:13px;min-height:18px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button class="muted" id="v74c">Annuler</button><button class="primary" id="v74s">Enregistrer</button></div></div>';d.body.appendChild(m);
 d.getElementById('v74c').onclick=function(){m.remove()};
 d.getElementById('v74s').onclick=function(){var o={},err='';FORMS[t].forEach(function(f){if(f.ph)return;var v=(d.getElementById('v74f_'+f.k).value||'').trim();if(f.r&&!v&&!err)err='Champ obligatoire : '+f.l;o[f.k]=v});
  if(!err&&o.start_date&&o.end_date&&o.end_date<o.start_date)err='La date de fin précède la date de début.';
  if(!err&&t==='assets'&&load('assets').some(function(x){return x.code===o.code&&x.id!==id}))err='Ce code équipement existe déjà.';
  if(err){d.getElementById('v74err').textContent=err;return}
  var pf=d.getElementById('v74f_photos'),files=pf&&pf.files?Array.prototype.slice.call(pf.files,0,2):[];
  var btn=d.getElementById('v74s');btn.disabled=true;
  Promise.all(files.map(function(f){return photo(f)})).then(function(ph){
   if(t==='work'){o.photos=ph.length?ph:(cur&&cur.photos)||[]}
   var a=load(t),rec;if(cur){var i=a.findIndex(function(x){return x.id===id});rec=a[i]=Object.assign({},cur,o,{updated_at:new Date().toISOString()})}else{rec=Object.assign({id:uid(),project:proj(),created_at:new Date().toISOString()},o);a.push(rec)}
   var extra=t==='work'?followUp(a,rec):0;
   if(save(t,a)){m.remove();render();say('Enregistré.'+(extra?' Prochaine échéance créée.':''))}else btn.disabled=false
  }).catch(function(){btn.disabled=false;d.getElementById('v74err').textContent='Photo illisible.'})}}
function photo(f){return (w.EXBPdf&&w.EXBPdf.fileJpg)?w.EXBPdf.fileJpg(f,800,.6):Promise.resolve('')}
/* ---- récurrence préventive ---- */
var MOIS={mensuelle:1,trimestrielle:3,semestrielle:6,annuelle:12};
function fmtD(x){return x.getFullYear()+'-'+('0'+(x.getMonth()+1)).slice(-2)+'-'+('0'+x.getDate()).slice(-2)}
function addPeriod(s,rec){var n=MOIS[rec];if(!n||!s)return '';var x=new Date(s+'T00:00:00');if(isNaN(x))return '';var day=x.getDate();x.setMonth(x.getMonth()+n);if(x.getDate()!==day)x.setDate(0);return fmtD(x)}
function exists(a,asset,type,due){return a.some(function(y){return y.asset_code===asset&&y.type===type&&y.due_date===due&&CLOSED.indexOf(y.status)<0})}
function nextOf(x){return Object.assign({},x,{id:uid(),status:'à faire',due_date:addPeriod(x.due_date,x.recurrence),photos:[],next_generated:false,generated_from:x.id,created_at:new Date().toISOString(),updated_at:undefined})}
function followUp(a,rec){if(rec.status!=='terminée'||!MOIS[rec.recurrence]||rec.next_generated||!rec.due_date)return 0;var nd=addPeriod(rec.due_date,rec.recurrence);rec.next_generated=true;if(!nd||exists(a,rec.asset_code,rec.type,nd))return 0;a.push(nextOf(rec));return 1}
w.EXBFM={catchUp:function(){var a=load('work'),n=0;a.slice().forEach(function(x){n+=followUp(a,x)});if(n)save('work',a);return n}};
function planify(){if(!canW('work')){say('Droits insuffisants.','warn');return}var a=load('work'),lim=new Date();lim.setFullYear(lim.getFullYear()+1);var limS=fmtD(lim),n=0;
 mine(a).slice().forEach(function(x){if(!MOIS[x.recurrence]||!x.due_date||CLOSED.indexOf(x.status)>=0)return;var cur=x;for(var g=0;g<60;g++){var nd=addPeriod(cur.due_date,cur.recurrence);if(!nd||nd>limS)break;if(!exists(a,x.asset_code,x.type,nd)){var o=nextOf(cur);o.due_date=nd;a.push(o);n++;cur=o}else cur=Object.assign({},cur,{due_date:nd})}});
 if(n&&save('work',a))say(n+' intervention(s) planifiée(s) sur 12 mois.');else say(n?'Enregistrement impossible.':'Rien à planifier : renseignez une récurrence et une échéance sur une intervention ouverte.','warn');render()}
/* ---- import du matériel de chantier (V68) ---- */
function importV68(){if(!canW('work')){say('Droits insuffisants.','warn');return}var src=w.EXBS.get('exb_maintenance'),a=load('work'),seen={};a.forEach(function(x){if(x.source)seen[x.source]=1});var n=0;
 src.forEach(function(s){var key='v68:'+s.id;if(seen[key])return;a.push({id:uid(),project:s.project||proj(),asset_code:s.title||'(sans nom)',type:/corr/i.test(s.type||'')?'corrective':'préventive',priority:'normale',due_date:s.due||'',technician:'',status:/cl[oô]tur/i.test(s.status||'')?'terminée':'à faire',recurrence:'aucune',note:'Importé du matériel de chantier (V68)',source:key,created_at:new Date().toISOString()});n++});
 if(n&&save('work',a))say(n+' fiche(s) importée(s).');else say(n?'Enregistrement impossible.':'Rien de nouveau à importer.','warn');render()}
/* ---- étiquettes QR + lien direct ---- */
function linkFor(code){var base=(w.EXB77&&w.EXB77.base())||location.href.split('#')[0],u=base+'#asset='+encodeURIComponent(code);try{if(unescape(encodeURIComponent(u)).length<=(w.EXBQR?w.EXBQR.maxBytes:0))return u}catch(e){}return 'EXB-ASSET:'+code}
function labels(){if(!w.EXBQR){say('Générateur QR indisponible.','warn');return}var A=mine(load('assets'));if(!A.length){say('Aucun équipement à étiqueter.','warn');return}
 var old=d.getElementById('exbV76Lab');if(old)old.remove();var o=d.createElement('div');o.id='exbV76Lab';o.style.cssText='position:fixed;inset:0;z-index:100000;background:#fff;color:#000;overflow:auto;padding:14px';
 var cells=A.map(function(x){var q='';try{q=w.EXBQR.svg(linkFor(x.code),{px:130,quiet:2})}catch(e){q='<small>QR impossible</small>'}return '<div style="border:1px dashed #888;padding:8px;text-align:center;width:170px;break-inside:avoid;box-sizing:border-box">'+q+'<div style="font:700 13px Arial">'+esc(x.code)+'</div><div style="font:11px Arial">'+esc(x.name||'')+'</div><div style="font:10px Arial;color:#555">'+esc(x.location||'')+'</div></div>'}).join('');
 o.innerHTML='<style>@media print{body>*:not(#exbV76Lab){display:none!important}#exbV76Lab .noprint{display:none!important}#exbV76Lab{position:static!important;padding:0!important}}</style><div class="noprint" style="margin-bottom:10px;display:flex;gap:8px"><button class="primary" id="v76pr">🖨 Imprimer / Enregistrer en PDF</button><button class="muted" id="v76cl">✕ Fermer</button></div><div style="display:flex;flex-wrap:wrap;gap:8px">'+cells+'</div>';
 d.body.appendChild(o);d.getElementById('v76cl').onclick=function(){o.remove()};d.getElementById('v76pr').onclick=function(){w.print()}}
function detail(code){var A=load('assets').find(function(x){return x.code===code}),out=d.getElementById('v74out');if(!out)return;
 if(!A){out.innerHTML='<p>Équipement « '+esc(code)+' » introuvable sur cet appareil (synchronisez puis réessayez).</p>';return}
 var W=load('work').filter(function(x){return x.asset_code===code}),G=load('warranties').filter(function(x){return x.asset_code===code}),I=load('inspections').filter(function(x){return x.asset_code===code});
 out.innerHTML='<div style="border:2px solid #173565;border-radius:12px;padding:12px;margin-bottom:12px"><h3 style="margin:0">'+esc(A.code)+' — '+esc(A.name)+'</h3><p>'+esc(A.category||'')+' · '+esc(A.location||'')+' · <b>'+esc(A.status||'')+'</b></p>'+(canW('work')?'<button class="primary smallbtn" id="v76nw">+ Intervention sur cet équipement</button> ':'')+'<button class="muted smallbtn" id="v76all">Voir tout</button></div><h3>Interventions</h3>'+table('work',W)+'<h3>Garanties</h3>'+table('warranties',G)+'<h3>Inspections</h3>'+table('inspections',I);
 var nb=d.getElementById('v76nw');if(nb)nb.onclick=function(){form('work',null,{asset_code:code})};d.getElementById('v76all').onclick=render}
function fromHash(){var m=/#asset=([^&]+)/.exec(location.hash||'');if(!m)return;var code;try{code=decodeURIComponent(m[1])}catch(e){return}if(!canR())return;if(!d.getElementById('exbV74Panel'))panel();detail(code)}
function del(t,id){if(!canW(t))return;if(!confirm('Supprimer cet enregistrement ?'))return;save(t,load(t).filter(function(x){return x.id!==id}));render()}
w.EXBV74={panel:panel,render:render,form:form,del:del,keys:K,collections:COL,addPeriod:addPeriod,followUp:followUp,planify:planify,importV68:importV68,labels:labels,detail:detail,linkFor:linkFor};w.addEventListener('hashchange',function(){setTimeout(fromHash,300)});
w.addEventListener('exb-rights',rights);
d.addEventListener('DOMContentLoaded',function(){setTimeout(function(){ui();fromHash()},1100)});
})(window,document);
