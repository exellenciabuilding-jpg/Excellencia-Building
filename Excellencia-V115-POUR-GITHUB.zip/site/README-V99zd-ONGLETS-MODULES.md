# V99zd — Calcul de structure : onglets de modules + tout affiché sur l'écran

Fichiers modifiés : `calcul-structure/index.html`, `sw.js` (cache `exb-v99zd-onglets-modules-1`). (V99zc : onglet « Tout afficher » du Bâtiment + largeur pleine.)

- **Barre d'onglets des modules**, toujours visible en haut de l'écran : Bâtiment, Prédimensionnement, Poutre, Poteau, Dalle, Semelle, Escalier, Dosage, Mortier, Volumes, Coffrage, Ferraillage, Moment, Coûts, Agglos, Devis. On passe d'un module à l'autre d'un seul toucher, sans repasser par Accueil > Calculs.
- **Poutre, Poteau, Dalle, Semelle, Escalier, Bâtiment** : le calcul se lance à l'ouverture et se met à jour après chaque changement de valeur. Sous les résultats, **Note de calcul** et **Plan d'exécution 2D** sont affichés directement (onglets), sans ouvrir de page supplémentaire. Le bouton « Imprimer / PDF » ouvre la version imprimable avec cartouche.
- La vue 3D et l'export DXF/IFC restent des boutons dans les résultats.
- Retour en arrière : restaurer l'ancien `calcul-structure/index.html`.
