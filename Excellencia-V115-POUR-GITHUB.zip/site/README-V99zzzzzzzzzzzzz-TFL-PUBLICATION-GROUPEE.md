# V99zzzzzzzzzzzzz — TFL : publier les sujets en groupe

Reprend la version « Carte de visite » (V99zzzzzzzzzzzz). Rien d'existant n'est retiré ; **aucun SQL**.

## TFL › 📋 Sujets › « 📦 Publier en groupe »
Au-dessus de **Mes fiches** :
- **Filtres** : recherche (référence, intitulé, filière), état (Toutes / Non publiées / Publiées), catégorie.
- **Cases à cocher** sur chaque fiche, ou **☑ Sélectionner les N résultats** (tous les résultats du filtre, pas seulement les 40 affichés) ; **☐ Tout désélectionner**.
- **🌐 Publier la sélection** / **🔒 Retirer la sélection**.
- **🌐 Publier toutes les non publiées affichées** : un seul bouton, sans rien cocher, après avoir filtré.
- **Envoyer aussitôt au serveur** (coché par défaut) : après la publication, le catalogue est synchronisé tout de suite si vous êtes connecté ; sinon le message vous invite à toucher « 🔄 Synchroniser ».
Le bouton individuel « 🌐 Publier » de chaque fiche reste disponible.

## Garde-fous
- Une **confirmation** est demandée avant d'agir ; si des fiches viennent de la **banque** (modèles génériques), elle rappelle de vérifier qu'elles ont été relues et validées par un encadreur.
- Une fiche **incomplète** (intitulé, problématique ou objectifs manquants) n'est **jamais publiée** : elle est ignorée et signalée dans le message.
- Les fiches déjà dans l'état demandé sont comptées, pas modifiées. Les retraits ne suppriment rien : ils se répercutent au prochain envoi au serveur.
- Écriture locale **unique** pour tout le lot (rapide, même pour des centaines de fiches).

## Contrôles
`node tools/check.js` (427) · `node tools/test-tfl/test-lot.js` (logique, 8) · `python3 tools/test-tfl/e2e-lot.py` (navigateur, 14).

## Limites
- La sélection est vidée après chaque action et n'est pas conservée si vous quittez l'écran.
- Les actions s'appliquent aux fiches **visibles dans le filtre en cours** (une fiche cochée puis masquée par un autre filtre n'est pas touchée).
- La synchronisation envoie les fiches par lots de 300, comme avant.
