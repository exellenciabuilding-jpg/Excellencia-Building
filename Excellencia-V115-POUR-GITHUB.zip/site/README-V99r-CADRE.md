# V99r — nouveau cadre (menu par catégories, barre du haut, accueil)

Ajouts : `exb-v99r-shell.js`, `assets/accueil/banniere-1..4.jpg` (photos du site vitrine). Modifiés : `index.html` (1 balise script), `sw.js` (cache `exb-v99r-shell-1`).
- Menu de gauche : 11 catégories ; un clic n'affiche que les éléments de la catégorie. Le menu d'origine reste dans la page (masqué) : chaque carte déclenche son bouton d'origine.
- Profil administrateur : clic sur le nom → changer/retirer la photo, modifier le nom, déconnexion (enregistré sur l'appareil).
- Accueil : bannière avec photo modifiable (bouton « Changer la photo »), cartes, graphique, activité récente, accès rapide, barre d'état.
- Aucun SQL à exécuter. Pour revenir en arrière : retirer la balise `exb-v99r-shell.js` de index.html.
- Limites : testé par `node tools/check.js` (241 contrôles) et par un test navigateur automatisé (ouverture d'une catégorie, d'un écran, retour accueil). Rendu visuel complet et version téléphone à confirmer sur vos appareils. `licence-config.js` reste en `requireToken:true`.
