/* Excellencia Building V99zr — Contrôles & sécurité sur chantier (audit interne : « Chantier terrain », P2).
 * Checklists qualité (avant coulage, maçonnerie, fondations, sécurité), causeries sécurité avec liste de présence signée au doigt,
 * non-conformités (gravité, responsable, échéance, action corrective, photo, position GPS), signature tactile, PDF.
 * Les modèles de checklist sont des bases de travail : à adapter aux plans, au CCTP et au plan d'assurance qualité du chantier. */
(function(root){'use strict';
var MODELES={
 coulage:{nom:'Avant coulage du béton',items:['Implantation et niveaux vérifiés','Coffrage propre, étanche, étayé et contreventé','Ferraillage conforme au plan (diamètres, espacements, nombre)','Enrobage assuré (cales en place)','Recouvrements et ancrages conformes','Réservations, gaines et attentes en place','Béton : classe / dosage conforme au bon de livraison','Affaissement (slump) mesuré et conforme','Matériel de vibration et de mise en œuvre disponible','Protection contre la pluie / le soleil prévue','Éprouvettes prévues et identifiées']},
 maconnerie:{nom:'Maçonnerie',items:['Aplomb et alignement des murs','Épaisseur et dimensions conformes au plan','Joints remplis, épaisseur régulière','Chaînages et raidisseurs en place','Linteaux et appuis conformes','Dosage du mortier respecté','Humidification / protection des ouvrages frais','Réservations et traversées prévues']},
 fondations:{nom:'Terrassement & fondations',items:['Implantation vérifiée (axes, cotes)','Profondeur de fouille conforme','Fond de fouille sain, nettoyé, hors d\'eau','Nature du sol conforme à l\'étude géotechnique','Béton de propreté réalisé','Ferraillage des semelles conforme','Talus / blindage de fouille sécurisé','Épuisement des eaux assuré']},
 securite:{nom:'Sécurité du chantier (quotidien)',items:['EPI portés par tout le personnel (casque, chaussures, gilet)','Échafaudages et garde-corps vérifiés','Zones dangereuses balisées / fouilles protégées','Installation électrique provisoire protégée','Extincteur et trousse de secours disponibles','Eau potable et sanitaires disponibles','Voies de circulation et stockages en ordre','Engins : conducteur habilité, signalisation en place']}};
var THEMES=['Port des EPI','Travail en hauteur','Fouilles et terrassement','Risque électrique','Manutention et gestes','Circulation des engins','Incendie et premiers secours','Hygiène et propreté','Autre'];
var GRAV={mineure:'Mineure',majeure:'Majeure',critique:'Critique'};
function resultat(items){var ok=0,nok=0,na=0,vide=0;(items||[]).forEach(function(x){if(x.r==='ok')ok++;else if(x.r==='nok')nok++;else if(x.r==='na')na++;else vide++});
  var den=ok+nok;return {ok:ok,nok:nok,na:na,vide:vide,pct:den?Math.round(ok/den*1000)/10:0,statut:nok?'Non conforme':(vide?'En cours':'Conforme')}}
function ncDepuis(chk){return (chk.items||[]).filter(function(x){return x.r==='nok'&&!x.nc}).map(function(x){return {desc:x.t+(x.rem?' — '+x.rem:''),item:x.t}})}
function enRetard(nc,today){return nc.statut!=='levee'&&!!nc.echeance&&nc.echeance<today}
var ENG={MODELES:MODELES,resultat:resultat,ncDepuis:ncDepuis,enRetard:enRetard};
root.EXBCTL_CALC=ENG;if(typeof module!=='undefined'&&module.exports)module.exports=ENG;
if(typeof document==='undefined')return;

/* ============================== INTERFACE ============================== */
var K={c:'exb_ctl_chk',s:'exb_ctl_cau',n:'exb_ctl_nc'},$=function(i){return document.getElementById(i)},ST={tab:'c',pid:'',open:'',nf:'t'};
var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var say=function(t,k){try{notify(t,k||'info',4500)}catch(e){alert(t)}};
var L=function(k){try{return load(K[k],[])}catch(e){return[]}},S=function(k,a){save(K[k],a)};
var projs=function(){return typeof exbProjects!=='undefined'?exbProjects:[]},proj=function(id){return projs().filter(function(p){return p.id===id})[0]};
var pname=function(id){var p=proj(id);return p?p.name:'—'};
var uid=function(p){return p+'_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)};
var today=function(){return new Date().toISOString().slice(0,10)};
var byId=function(k,id){return L(k).filter(function(x){return x.id===id})[0]};
var put=function(k,o){var a=L(k),i=a.findIndex(function(x){return x.id===o.id});if(i>=0)a[i]=o;else a.push(o);S(k,a)};
var mine=function(k){return L(k).filter(function(x){return x.project_id===ST.pid}).sort(function(a,b){return a.date<b.date?1:-1})};
function geoTxt(g){return g?g.lat.toFixed(5)+', '+g.lng.toFixed(5)+' (±'+Math.round(g.acc||0)+' m)':''}
function geoLink(g){return g?' <a href="https://www.openstreetmap.org/?mlat='+g.lat+'&mlon='+g.lng+'#map=17/'+g.lat+'/'+g.lng+'" target="_blank" rel="noopener">carte</a>':''}
function inp(v,fn,w,type){return '<input '+(type?'type="'+type+'" ':'')+'value="'+esc(v)+'" onchange="EXBCTL.'+fn+'" style="width:'+(w||'100%')+'">'}
function badge(t,c){return '<span style="background:'+c+';color:#fff;border-radius:8px;padding:2px 8px;font-size:12px;white-space:nowrap">'+esc(t)+'</span>'}
var CST={'Conforme':'#15803d','Non conforme':'#b91c1c','En cours':'#b45309'};

/* ---- signature tactile ---- */
function signPad(titre,cb){var ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;background:#000a;z-index:99999;display:flex;align-items:center;justify-content:center;padding:12px';
  ov.innerHTML='<div style="background:#fff;border-radius:14px;padding:14px;width:100%;max-width:420px"><b>✍️ '+esc(titre)+'</b><p style="font-size:12px;color:#666;margin:4px 0">Signez au doigt dans le cadre.</p><canvas width="360" height="150" style="width:100%;border:2px dashed #94a3b8;border-radius:10px;touch-action:none;background:#fff"></canvas><div style="display:flex;gap:8px;margin-top:10px"><button type="button" data-a="c" class="muted">Effacer</button><button type="button" data-a="x" class="muted">Annuler</button><button type="button" data-a="v" style="margin-left:auto">Valider</button></div></div>';
  document.body.appendChild(ov);var cv=ov.querySelector('canvas'),cx=cv.getContext('2d'),dr=false,has=false;cx.lineWidth=2.4;cx.lineCap='round';cx.strokeStyle='#0f172a';
  function pt(e){var r=cv.getBoundingClientRect();return [(e.clientX-r.left)*cv.width/r.width,(e.clientY-r.top)*cv.height/r.height]}
  cv.addEventListener('pointerdown',function(e){dr=true;has=true;var p=pt(e);cx.beginPath();cx.moveTo(p[0],p[1]);try{cv.setPointerCapture(e.pointerId)}catch(x){}e.preventDefault()});
  cv.addEventListener('pointermove',function(e){if(!dr)return;var p=pt(e);cx.lineTo(p[0],p[1]);cx.stroke();e.preventDefault()});
  ['pointerup','pointercancel'].forEach(function(n){cv.addEventListener(n,function(){dr=false})});
  ov.onclick=function(e){var a=e.target.getAttribute&&e.target.getAttribute('data-a');if(!a)return;
    if(a==='c'){cx.clearRect(0,0,cv.width,cv.height);has=false}
    else if(a==='x')ov.remove();
    else if(a==='v'){if(!has)return say('Signez d\'abord dans le cadre.','warn');var d=cv.toDataURL('image/png');ov.remove();cb(d)}}}
function locate(cb){if(!navigator.geolocation)return say('Position indisponible sur cet appareil.','warn');say('Recherche de la position…');
  navigator.geolocation.getCurrentPosition(function(p){cb({lat:p.coords.latitude,lng:p.coords.longitude,acc:p.coords.accuracy,at:new Date().toISOString()})},function(){say('Position refusée ou indisponible : autorisez la localisation.','warn')},{enableHighAccuracy:true,timeout:9000,maximumAge:30000})}
function photo(file,cb){var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var m=800,k=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);cb(c.toDataURL('image/jpeg',0.6))};im.onerror=function(){say('Image illisible.','warn')};im.src=r.result};r.readAsDataURL(file)}

/* ---- vues ---- */
function tabs(){return '<div class="tabs" style="margin:8px 0">'+[['c','✅ Checklists qualité'],['s','🦺 Causeries sécurité'],['n','⚠ Non-conformités']].map(function(t){return '<button class="'+(ST.tab===t[0]?'':'muted')+'" onclick="EXBCTL.tab(\''+t[0]+'\')">'+t[1]+'</button>'}).join('')+'</div>'}
function kpis(){var nc=mine('n'),ouv=nc.filter(function(x){return x.statut!=='levee'}),ret=nc.filter(function(x){return enRetard(x,today())}),cs=mine('c'),last=cs[0];
  return '<div class="exb-grid"><div class="exb-card"><b style="font-size:20px;color:'+(ouv.length?'#b91c1c':'#15803d')+'">'+ouv.length+'</b><br><small>Non-conformité(s) ouverte(s)'+(ret.length?' dont <b style="color:#b91c1c">'+ret.length+' en retard</b>':'')+'</small></div><div class="exb-card"><b style="font-size:20px">'+cs.length+'</b><br><small>Checklist(s)'+(last?' — dernière : '+resultat(last.items).pct+' % conforme':'')+'</small></div><div class="exb-card"><b style="font-size:20px">'+mine('s').length+'</b><br><small>Causerie(s) sécurité</small></div></div>'}
function vChk(){var h='<div class="exb-actions" style="align-items:end"><div><label>Nouvelle checklist</label><select id="exbctl_m">'+Object.keys(MODELES).map(function(k){return '<option value="'+k+'">'+esc(MODELES[k].nom)+'</option>'}).join('')+'</select></div><button onclick="EXBCTL.newC()">＋ Créer</button></div>';
  var c=ST.open&&byId('c',ST.open);
  if(c){var r=resultat(c.items),lock=c.signe;h+='<div class="exb-card" style="margin-top:10px"><b>'+esc(c.nom)+'</b> — '+esc(c.date)+' '+badge(r.statut,CST[r.statut])+' <small>'+r.pct+' % conforme ('+r.ok+' OK, '+r.nok+' NOK, '+r.na+' N/A, '+r.vide+' à contrôler)</small>'
    +'<div class="exb-actions" style="margin:6px 0"><div><label>Zone / ouvrage contrôlé</label>'+inp(c.zone||'',"cset('zone',this.value)",'220px')+'</div></div>';
    h+=c.items.map(function(x,i){var b=function(v,l,col){return '<button '+(lock?'disabled ':'')+'onclick="EXBCTL.cres('+i+',\''+v+'\')" style="padding:4px 9px;margin-right:3px;'+(x.r===v?'background:'+col+';color:#fff':'')+'" class="'+(x.r===v?'':'muted')+'">'+l+'</button>'};
      return '<div style="border-top:1px solid #e5e7eb;padding:6px 0"><div>'+(i+1)+'. '+esc(x.t)+(x.nc?' '+badge('NC créée','#b45309'):'')+'</div><div style="margin-top:3px">'+b('ok','✓ OK','#15803d')+b('nok','✗ NOK','#b91c1c')+b('na','N/A','#6b7280')+'</div>'+(x.r==='nok'||x.rem?'<input '+(lock?'disabled ':'')+'placeholder="Remarque" value="'+esc(x.rem||'')+'" onchange="EXBCTL.crem('+i+',this.value)" style="width:100%;margin-top:3px">':'')+'</div>'}).join('');
    h+='<div style="margin-top:8px">'+(c.geo?'📍 '+esc(geoTxt(c.geo))+geoLink(c.geo)+' ':'')+(lock?'':'<button class="muted" onclick="EXBCTL.cgeo()">📍 Position</button> ')+'</div>';
    if(lock)h+='<p>✅ Signé par <b>'+esc(c.signataire)+'</b> le '+esc((c.signe_le||'').slice(0,10))+'<br><img alt="Signature" src="'+esc(c.signature)+'" style="height:60px;border:1px solid #ddd;background:#fff"></p><button onclick="EXBCTL.cpdf()">📄 PDF</button> <button class="muted" onclick="EXBCTL.cclose()">Fermer</button>';
    else h+='<div class="exb-actions" style="align-items:end;margin-top:8px"><div><label>Contrôleur</label>'+inp(c.signataire||'',"cset('signataire',this.value)",'180px')+'</div><button onclick="EXBCTL.csign()">✍️ Signer et clôturer</button><button class="muted" onclick="EXBCTL.cclose()">Fermer</button><button class="muted" onclick="EXBCTL.cdel()">🗑</button></div><small class="exb-muted">À la signature, chaque point NOK crée une non-conformité à suivre.</small>';
    h+='</div>'}
  var all=mine('c');h+=all.length?'<div style="margin-top:10px">'+all.map(function(x){var r=resultat(x.items);return '<div class="exb-card" style="margin-top:6px;display:flex;gap:8px;align-items:center;justify-content:space-between"><span><b>'+esc(x.nom)+'</b><br><small>'+esc(x.date)+(x.zone?' — '+esc(x.zone):'')+' — '+r.pct+' %</small></span><span>'+badge(r.statut,CST[r.statut])+(x.signe?' ✍️':'')+' <button class="muted" onclick="EXBCTL.copen(\''+esc(x.id)+'\')">Ouvrir</button></span></div>'}).join('')+'</div>':'<p class="exb-muted">Aucune checklist pour ce chantier.</p>';
  return h}
function vCau(){var h='<button onclick="EXBCTL.newS()">＋ Nouvelle causerie sécurité</button>',c=ST.open&&byId('s',ST.open);
  if(c){var lock=c.signe;h+='<div class="exb-card" style="margin-top:10px"><div class="exb-actions" style="align-items:end"><div><label>Date</label>'+inp(c.date,"sset('date',this.value)",'',"date")+'</div><div><label>Thème</label><select onchange="EXBCTL.sset(\'theme\',this.value)"'+(lock?' disabled':'')+'>'+THEMES.map(function(t){return '<option'+(t===c.theme?' selected':'')+'>'+esc(t)+'</option>'}).join('')+'</select></div><div><label>Durée (min)</label>'+inp(c.duree,"sset('duree',this.value)",'70px','number')+'</div></div>'
    +'<label>Animateur</label>'+inp(c.animateur||'',"sset('animateur',this.value)")+'<label>Points abordés</label><textarea rows="3" style="width:100%"'+(lock?' disabled':'')+' onchange="EXBCTL.sset(\'points\',this.value)">'+esc(c.points||'')+'</textarea>'
    +'<h4 style="margin:10px 0 4px">Présence ('+c.part.length+')</h4>'+c.part.map(function(p,i){return '<div style="display:flex;gap:6px;align-items:center;margin:3px 0"><span style="flex:1">'+esc(p.nom)+'</span>'+(p.sig?'<img alt="" src="'+esc(p.sig)+'" style="height:34px;border:1px solid #ddd;background:#fff">':(lock?'':'<button class="muted" onclick="EXBCTL.psign('+i+')">✍️ Signer</button>'))+(lock?'':'<button class="muted" onclick="EXBCTL.pdel('+i+')">✕</button>')+'</div>'}).join('')
    +(lock?'':'<div class="exb-actions" style="margin-top:6px"><input id="exbctl_pn" placeholder="Nom du participant" style="flex:1"><button onclick="EXBCTL.padd()">＋ Ajouter</button></div>');
    h+='<div style="margin-top:8px">'+(c.geo?'📍 '+esc(geoTxt(c.geo))+geoLink(c.geo)+' ':'')+(lock?'':'<button class="muted" onclick="EXBCTL.sgeo()">📍 Position</button>')+'</div>';
    h+=lock?'<p>✅ Clôturée — animateur : <b>'+esc(c.animateur)+'</b> <img alt="Signature" src="'+esc(c.signature)+'" style="height:50px;border:1px solid #ddd;background:#fff"></p><button onclick="EXBCTL.spdf()">📄 PDF</button> <button class="muted" onclick="EXBCTL.sclose()">Fermer</button>':'<div class="exb-actions" style="margin-top:8px"><button onclick="EXBCTL.ssign()">✍️ Signature animateur et clôture</button><button class="muted" onclick="EXBCTL.sclose()">Fermer</button><button class="muted" onclick="EXBCTL.sdel()">🗑</button></div>';h+='</div>'}
  var all=mine('s');return h+(all.length?all.map(function(x){return '<div class="exb-card" style="margin-top:6px;display:flex;justify-content:space-between;gap:8px;align-items:center"><span><b>'+esc(x.theme)+'</b><br><small>'+esc(x.date)+' — '+x.part.length+' participant(s) '+(x.part.filter(function(p){return p.sig}).length)+' signature(s)</small></span><span>'+(x.signe?'✅ ':'')+'<button class="muted" onclick="EXBCTL.sopen(\''+esc(x.id)+'\')">Ouvrir</button></span></div>'}).join(''):'<p class="exb-muted">Aucune causerie pour ce chantier.</p>')}
function vNc(){var nc=mine('n'),f=ST.nf,h='<button onclick="EXBCTL.newN()">＋ Nouvelle non-conformité</button> <select onchange="EXBCTL.nf(this.value)"><option value="t"'+(f==='t'?' selected':'')+'>Toutes</option><option value="o"'+(f==='o'?' selected':'')+'>Ouvertes</option><option value="l"'+(f==='l'?' selected':'')+'>Levées</option></select>';
  nc=nc.filter(function(x){return f==='t'||(f==='o'?x.statut!=='levee':x.statut==='levee')});
  h+=nc.length?nc.map(function(x){var ret=enRetard(x,today()),sc=x.statut==='levee'?'#15803d':(ret?'#b91c1c':'#b45309'),op=ST.open===x.id;
    var g={mineure:'#6b7280',majeure:'#b45309',critique:'#b91c1c'}[x.grav];
    var s='<div class="exb-card" style="margin-top:6px"><div style="display:flex;justify-content:space-between;gap:8px"><span><b>'+esc(x.desc||'(sans description)')+'</b><br><small>'+esc(x.date)+(x.source?' — '+esc(x.source):'')+(x.resp?' — resp. '+esc(x.resp):'')+(x.echeance?' — échéance '+esc(x.echeance):'')+'</small></span><span style="text-align:right">'+badge(GRAV[x.grav]||'—',g||'#6b7280')+' '+badge(x.statut==='levee'?'Levée':(ret?'En retard':(x.statut==='cours'?'En cours':'Ouverte')),sc)+'</span></div>'+(x.photo?'<img alt="Photo" src="'+esc(x.photo)+'" style="max-width:100%;max-height:160px;margin-top:6px;border-radius:8px">':'')+(x.geo?'<div style="margin-top:4px">📍 '+esc(geoTxt(x.geo))+geoLink(x.geo)+'</div>':'');
    if(op)s+='<div style="margin-top:8px"><label>Description</label>'+inp(x.desc||'',"nset('desc',this.value)")+'<div class="exb-actions"><div><label>Gravité</label><select onchange="EXBCTL.nset(\'grav\',this.value)">'+Object.keys(GRAV).map(function(k){return '<option value="'+k+'"'+(x.grav===k?' selected':'')+'>'+GRAV[k]+'</option>'}).join('')+'</select></div><div><label>Statut</label><select onchange="EXBCTL.nset(\'statut\',this.value)"><option value="ouverte"'+(x.statut==='ouverte'?' selected':'')+'>Ouverte</option><option value="cours"'+(x.statut==='cours'?' selected':'')+'>En cours</option><option value="levee"'+(x.statut==='levee'?' selected':'')+'>Levée</option></select></div></div><div class="exb-actions"><div><label>Responsable</label>'+inp(x.resp||'',"nset('resp',this.value)",'170px')+'</div><div><label>Échéance</label>'+inp(x.echeance||'',"nset('echeance',this.value)",'',"date")+'</div></div><label>Action corrective</label><textarea rows="2" style="width:100%" onchange="EXBCTL.nset(\'action\',this.value)">'+esc(x.action||'')+'</textarea><div class="exb-actions" style="margin-top:6px"><label class="muted" style="padding:6px 10px;border-radius:8px;background:#eef2fa;cursor:pointer">📷 Photo<input type="file" accept="image/*" capture="environment" style="display:none" onchange="EXBCTL.nphoto(this)"></label><button class="muted" onclick="EXBCTL.ngeo()">📍 Position</button><button class="muted" onclick="EXBCTL.ndel()">🗑 Supprimer</button></div></div>';
    return s+'<div style="margin-top:6px"><button class="muted" onclick="EXBCTL.nopen(\''+esc(x.id)+'\')">'+(op?'Fermer':'Modifier')+'</button></div></div>'}).join(''):'<p class="exb-muted">Aucune non-conformité.</p>';return h}
function render(){var b=$('exbctl_box');if(!b)return;
  var h='<label>Chantier</label><select onchange="EXBCTL.pick(this.value)"><option value="">— Choisir un chantier —</option>'+projs().map(function(p){return '<option value="'+esc(p.id)+'"'+(p.id===ST.pid?' selected':'')+'>'+esc(p.name)+'</option>'}).join('')+'</select>';
  if(!ST.pid)h+='<p class="exb-muted">Choisissez un chantier pour contrôler la qualité et la sécurité.</p>';else h+=kpis()+tabs()+(ST.tab==='c'?vChk():ST.tab==='s'?vCau():vNc());
  b.innerHTML=h}
function cur(k){return byId(k,ST.open)}
function pdf(o,name){if(!window.EXBPdf)return say('Module PDF indisponible.','warn');EXBPdf.make(o).then(function(x){EXBPdf.save(x,name)})}
var A={
 pick:function(v){ST.pid=v;ST.open='';render()},tab:function(t){ST.tab=t;ST.open='';render()},
 /* checklists */
 newC:function(){var k=($('exbctl_m')||{}).value||'coulage',m=MODELES[k];var c={id:uid('CHK'),project_id:ST.pid,date:today(),modele:k,nom:m.nom,zone:'',items:m.items.map(function(t){return {t:t,r:'',rem:''}}),signataire:'',signe:false};put('c',c);ST.open=c.id;render()},
 copen:function(id){ST.open=id;render()},cclose:function(){ST.open='';render()},
 cset:function(k,v){var c=cur('c');if(!c||c.signe)return;c[k]=v;put('c',c)},
 cres:function(i,v){var c=cur('c');if(!c||c.signe)return;c.items[i].r=(c.items[i].r===v?'':v);put('c',c);render()},
 crem:function(i,v){var c=cur('c');if(!c||c.signe)return;c.items[i].rem=v;put('c',c)},
 cgeo:function(){locate(function(g){var c=cur('c');c.geo=g;put('c',c);render()})},
 csign:function(){var c=cur('c');if(!c)return;if(!String(c.signataire||'').trim())return say('Indiquez le nom du contrôleur.','warn');var r=resultat(c.items);if(r.vide&&!confirm(r.vide+' point(s) non contrôlé(s). Clôturer quand même ?'))return;
  signPad('Signature du contrôleur',function(sig){c=cur('c');var drafts=ncDepuis(c);drafts.forEach(function(d){put('n',{id:uid('NC'),project_id:c.project_id,date:today(),source:'Checklist « '+c.nom+' »',desc:d.desc,grav:'majeure',statut:'ouverte',resp:'',echeance:'',action:'',geo:c.geo||null,photo:'',chk:c.id});c.items.forEach(function(x){if(x.t===d.item)x.nc=true})});c.signature=sig;c.signe=true;c.signe_le=new Date().toISOString();put('c',c);say(drafts.length?drafts.length+' non-conformité(s) créée(s).':'Checklist clôturée.','success');render()})},
 cdel:function(){if(!confirm('Supprimer cette checklist ?'))return;S('c',L('c').filter(function(x){return x.id!==ST.open}));ST.open='';render()},
 cpdf:function(){var c=cur('c'),r=resultat(c.items),rows=[['Chantier',pname(c.project_id)],['Contrôle',c.nom],['Date',c.date],['Zone / ouvrage',c.zone||'—'],['Résultat',r.statut+' — '+r.pct+' % conforme ('+r.ok+' OK, '+r.nok+' NOK, '+r.na+' N/A)']];
  c.items.forEach(function(x,i){rows.push([(i+1)+'. '+x.t,({ok:'OK',nok:'NON CONFORME',na:'N/A','':'non contrôlé'})[x.r]+(x.rem?' — '+x.rem:'')])});rows.push(['Contrôleur',c.signataire+' — signé le '+(c.signe_le||'').slice(0,10)]);if(c.geo)rows.push(['Position',geoTxt(c.geo)]);
  pdf({titre:'CHECKLIST QUALITÉ — '+c.nom.toUpperCase(),sousTitre:pname(c.project_id)+' — '+c.date,rows:rows,notes:['Document de contrôle interne. Modèle à adapter au CCTP et au plan d\'assurance qualité du chantier.'],footer:'Contrôle — '+pname(c.project_id)+' — Excellencia Building'},'checklist-'+c.date+'.pdf')},
 /* causeries */
 newS:function(){var c={id:uid('CAU'),project_id:ST.pid,date:today(),theme:THEMES[0],duree:15,animateur:'',points:'',part:[],signe:false};put('s',c);ST.open=c.id;render()},
 sopen:function(id){ST.open=id;render()},sclose:function(){ST.open='';render()},
 sset:function(k,v){var c=cur('s');if(!c||c.signe)return;c[k]=v;put('s',c)},
 sgeo:function(){locate(function(g){var c=cur('s');c.geo=g;put('s',c);render()})},
 padd:function(){var c=cur('s'),n=(($('exbctl_pn')||{}).value||'').trim();if(!c||!n)return;c.part.push({nom:n,sig:''});put('s',c);render()},
 pdel:function(i){var c=cur('s');c.part.splice(i,1);put('s',c);render()},
 psign:function(i){var c=cur('s');signPad('Signature : '+c.part[i].nom,function(sig){c=cur('s');c.part[i].sig=sig;put('s',c);render()})},
 ssign:function(){var c=cur('s');if(!c)return;if(!String(c.animateur||'').trim())return say('Indiquez le nom de l\'animateur.','warn');if(!c.part.length)return say('Ajoutez au moins un participant.','warn');signPad('Signature de l\'animateur',function(sig){c=cur('s');c.signature=sig;c.signe=true;c.signe_le=new Date().toISOString();put('s',c);say('Causerie clôturée.','success');render()})},
 sdel:function(){if(!confirm('Supprimer cette causerie ?'))return;S('s',L('s').filter(function(x){return x.id!==ST.open}));ST.open='';render()},
 spdf:function(){var c=cur('s'),rows=[['Chantier',pname(c.project_id)],['Date',c.date],['Thème',c.theme],['Durée',c.duree+' min'],['Animateur',c.animateur],['Points abordés',c.points||'—']];
  c.part.forEach(function(p,i){rows.push(['Participant '+(i+1),p.nom+(p.sig?' — signé':' — non signé')])});if(c.geo)rows.push(['Position',geoTxt(c.geo)]);
  pdf({titre:'CAUSERIE SÉCURITÉ',sousTitre:pname(c.project_id)+' — '+c.date,rows:rows,notes:['Liste de présence : '+c.part.filter(function(p){return p.sig}).length+' signature(s) sur '+c.part.length+' participant(s).'],footer:'Causerie sécurité — '+pname(c.project_id)+' — Excellencia Building'},'causerie-'+c.date+'.pdf')},
 /* non-conformités */
 nf:function(v){ST.nf=v;render()},nopen:function(id){ST.open=(ST.open===id?'':id);render()},
 newN:function(){var n={id:uid('NC'),project_id:ST.pid,date:today(),source:'Saisie manuelle',desc:'',grav:'mineure',statut:'ouverte',resp:'',echeance:'',action:'',photo:'',geo:null};put('n',n);ST.open=n.id;render()},
 nset:function(k,v){var n=cur('n');if(!n)return;n[k]=v;if(k==='statut'&&v==='levee')n.levee_le=today();put('n',n);render()},
 nphoto:function(el){var f=el.files&&el.files[0];if(!f)return;photo(f,function(d){var n=cur('n');n.photo=d;put('n',n);render()})},
 ngeo:function(){locate(function(g){var n=cur('n');n.geo=g;put('n',n);render()})},
 ndel:function(){if(!confirm('Supprimer cette non-conformité ?'))return;S('n',L('n').filter(function(x){return x.id!==ST.open}));ST.open='';render()},
 render:render};
A.signPad=signPad;A.locate=locate;root.EXBCTL=A;
function mount(){if($('chantierctl'))return;var ref=$('plangantt')||$('terrain')||$('chantiers')||$('projets'),host=document.querySelector('.wrap')||document.querySelector('main')||document.body,s=document.createElement('section');s.id='chantierctl';s.style.display='none';
 s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>🦺 Contrôles &amp; sécurité</h2><p class="exb-muted">Checklists qualité, causeries sécurité signées au doigt, non-conformités avec photo et position — sur le téléphone, au chantier.</p></div></div><div id="exbctl_box"></div></div>';
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
 var b=$('bplan')||$('bprj');if(b&&!$('bctl')){var n=document.createElement('button');n.id='bctl';n.textContent='🦺 Contrôles & sécurité';n.setAttribute('onclick',"show('chantierctl')");b.parentNode.insertBefore(n,b.nextSibling)}
 var os=window.show;if(typeof os==='function'&&!window.__exbCtlShow){window.__exbCtlShow=1;window.show=function(x){var r=os.apply(this,arguments),e=$('chantierctl');if(e)e.style.display=(x==='chantierctl')?'':'none';if(x==='chantierctl')render();return r}}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(mount,1100)});else setTimeout(mount,1100);
})(typeof window!=='undefined'?window:globalThis);
