# V99 — Éditeur de plan, lot 2 : rotation rapide, ouvertures dans les vues, nomenclatures interactives

Fichiers modifiés : `plan-editeur/index.html`, `plan-editeur/coupes.js`, `sw.js` (version du cache). Aucun changement de format de plan.

## 1. Rotation rapide des éléments
- **Touche R** : pivote la sélection de 90° à droite ; **Maj+R** : 90° à gauche. **Alt+→ / Alt+←** : 15° ; avec **Maj** : 1°.
- **Poignée ↻** au-dessus de la sélection (plan 2D) : glisser pour pivoter à la main, par pas de 15° (**Maj** = au degré). L'angle s'affiche pendant le geste.
- **Boutons** ↺ 90° / ↻ 90° : menu Édition › Modifier, barre d'outils, fiche de sélection multiple, fiche d'un meuble (+ bouton ↻ 15°), menu clic droit / appui long (« Pivoter 90° »).
- Un meuble seul pivote sur lui-même ; un groupe pivote autour du centre de la sélection (murs, pièces, meubles, électricité…). Une **porte** seule : R fait tourner charnière et sens d'ouverture. Les toitures rectangulaires ne pivotent pas (comme avant).
- Fonctionne aussi depuis les façades et coupes (touche R).

## 2. Ouvertures posées directement dans les coupes et élévations
- Dans la vue Façades / Coupe A-A / Élévations int. : boutons **🚪 Poser une porte** et **🪟 Poser une fenêtre**. Champs L, H (et Allège pour une fenêtre) réglables ; ils mettent à jour les valeurs par défaut du plan.
- Un fantôme vert suit la souris sur le mur visé (rouge = chevauche une ouverture existante). Toucher / cliquer pose l'ouverture, **calée à 5 cm**. Pour une fenêtre, **la hauteur de l'allège suit le point touché** ; pour une porte, elle part du sol. **Échap** termine l'outil.
- Fonctionne sur tous les niveaux visibles (le niveau du mur touché devient le niveau courant), sur les murs vus de face et sur les murs traversés par la coupe (l'ouverture est alors centrée sur le plan de coupe).
- **Glisser une fenêtre sélectionnée** : horizontalement, elle se déplace sur son mur (comme avant) ; verticalement, elle change d'allège (pas de 5 cm).
- Les messages de la barre d'aide s'affichent maintenant aussi en vue façade/coupe (bandeau temporaire).
- `coupes.js` : les « hits » de murs fournissent désormais la correspondance abscisse de vue ↔ position sur le mur (`m`), et les hits d'ouvertures leur mur (`wid`).

## 3. Nomenclatures interactives
- Nouveau panneau **📑 Nomenclatures** (menu Documentation › Quantités et devis, groupe Ouvertures, barre des vues). Non modal : le plan reste actif. « Tableau des pièces » ouvre le même panneau, rubrique Pièces.
- Rubriques : **Menuiseries**, **Pièces**, **Murs**, **Mobilier**. Tri par clic sur l'en-tête, filtre par niveau et par texte, totaux en pied.
- **Sélection liée** : toucher une ligne sélectionne l'élément sur le plan (et change de niveau si besoin, recentre la vue) ; la sélection faite sur le plan ou en façade surligne la ligne.
- **Édition directe** : type / L / H / allège / position des ouvertures ; nom et sol des pièces ; épaisseur et hauteur des murs. Valeurs bornées (une ouverture reste dans son mur). Annuler / Rétablir fonctionnent.
- **Menuiseries « Par repère »** : une ligne par repère (P1, F1…) avec quantité, m² unitaire et total ; modifier L / H / allège change toutes les ouvertures du repère ; toucher la ligne les sélectionne toutes. Mode liste : liseré rouge si deux ouvertures se chevauchent, bouton 🗑 par ligne.
- Export **CSV** (Excel, BOM UTF-8, séparateur « ; ») et copie du tableau affiché.
- **Repères P / F globaux** : la numérotation est désormais calculée sur tous les niveaux (même repère = mêmes dimensions) ; la légende et les repères sur le plan l'utilisent. Un niveau peut donc commencer à P2 / F3 si P1 / F1 n'existent qu'ailleurs.

## Limites / tests
Testé dans Chromium sans écran : rotation (R, Maj+R, Alt+flèches, poignée), pose porte / fenêtre en façade Sud, en coupe (mur traversé) et au R+1, glisser vertical, éditions du tableau (liste, par repère, pièces, murs), suppression, changement de niveau, aucune erreur de console. Non testé sur appareil Android / Windows réel ni en 3D WebGL.
