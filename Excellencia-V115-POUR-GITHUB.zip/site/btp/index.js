(function(w){'use strict';w.EXB_BTP={version:'V90-Enterprise',modules:['projets','chantiers','planning','qhse','materiel','sous-traitance']};})(window);
