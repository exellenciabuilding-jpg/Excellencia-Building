/* QCM AutoCAD — lot 4. Format : [question, BONNE réponse, faux, faux, faux]. */
(function(){const B=EXBQCM_BANKS,N='AutoCAD';
B.add(N,'debutant',[
['Quelle commande donne du volume à un profil 2D fermé ?','EXTRUDE','OFFSET','TRIM','PURGE'],
['À quoi sert le ViewCube ?','Changer l’orientation de la vue 3D','Créer des calques','Mesurer des angles','Imprimer'],
['Que fait 3DORBIT ?','Fait pivoter la vue 3D autour du modèle','Supprime les solides','Crée des cotes','Exporte en PDF'],
['Quelle commande crée un solide parallélépipédique ?','BOX','XLINE','ARRAY','DIST'],
['Que crée la commande REVOLVE ?','Un solide ou une surface par révolution autour d’un axe','Une copie parallèle','Un nuage de révision','Un bloc'],
['Que fait SCALE avec un facteur de 0,5 ?','Réduit l’objet de moitié','Double l’objet','Le fait pivoter de 50°','Le déplace de 0,5 unité'],
['Si l’on dessine en mètres, que représente 1 unité de dessin ?','1 mètre','1 millimètre','1 pied','1 centimètre'],
['Quelle commande ouvre un nouveau dessin ?','NEW','OPEN','SAVE','CLOSE'],
['Quelle commande ouvre un dessin existant ?','OPEN','NEW','SAVEAS','PURGE'],
['Quelle commande ferme le dessin actif ?','CLOSE','QUIT','NEW','PLOT']]);
B.add(N,'intermediaire',[
['À quoi sert l’option Référence de SCALE ?','Mettre à l’échelle à partir d’une longueur connue vers une nouvelle longueur','Copier l’objet','Faire pivoter l’objet','Verrouiller l’objet'],
['Quel raccourci colle des objets copiés comme un bloc ?','Ctrl+Maj+V','Ctrl+Z','Ctrl+S','Ctrl+P'],
['À quoi sert COPYBASE ?','Copier des objets dans le presse-papiers avec un point de base choisi','Copier un calque','Copier une police','Copier l’imprimante'],
['À quoi sert BEDIT ?','Ouvrir l’éditeur de blocs','Éditer un calque','Éditer un tracé','Éditer une cote'],
['À quoi sert REFEDIT ?','Modifier un bloc ou une référence sur place','Supprimer une référence','Imprimer une référence','Exporter un bloc'],
['À quoi sert un champ (FIELD) ?','Insérer un texte mis à jour automatiquement','Créer un calque','Tracer une ligne','Verrouiller un objet'],
['À quoi sert SCALETEXT ?','Changer la taille de textes sans déplacer leur position','Supprimer des textes','Traduire des textes','Fusionner des textes'],
['À quoi sert DRAWORDER ?','Gérer l’ordre d’affichage des objets qui se superposent','Gérer l’ordre d’impression des fichiers','Trier les calques par nom','Numéroter les objets'],
['À quoi sert SELECTSIMILAR ?','Sélectionner les objets de même type et propriétés','Supprimer les objets similaires','Copier les objets','Colorer les objets'],
['À quoi sert EATTEDIT ?','Modifier les valeurs d’attributs d’un bloc','Éditer une hachure','Éditer une cote','Éditer un calque'],
['À quoi sert la commande ALIGN ?','Aligner des objets sur d’autres à l’aide de points sources et destinations','Aligner uniquement du texte','Créer une symétrie','Supprimer des doublons'],
['Comment modifier rapidement un texte existant ?','Double-cliquer dessus ou utiliser TEXTEDIT','Le supprimer et fermer le dessin','Utiliser PURGE','Utiliser PLOT']]);
B.add(N,'avance',[
['Pourquoi PURGE ne supprime-t-il pas un calque ?','Il contient encore des objets, est actif ou est référencé','Il est trop long à supprimer','Il est toujours protégé','Il est de couleur rouge'],
['Quelle variable règle l’échelle globale des types de ligne ?','LTSCALE','OSMODE','DIMSCALE','MIRRTEXT'],
['Pourquoi des tirets peuvent-ils sembler continus à l’écran ?','L’échelle des types de ligne est mal adaptée','Le fichier est un PDF','Le calque est supprimé','La molette est bloquée'],
['Que contrôle l’unité d’insertion (INSUNITS) ?','La mise à l’échelle des blocs insérés selon leur unité','La police','La couleur du fond','La résolution de l’écran'],
['À quoi sert PUBLISH ?','Publier plusieurs présentations en lot, par exemple en PDF','Publier un calque','Copier une police','Réparer un fichier'],
['Pourquoi éviter d’exploser des cotes ?','Elles perdent leur association avec la géométrie','Elles deviennent rouges','Elles changent de langue','Elles sont supprimées du fichier']]);
})();
