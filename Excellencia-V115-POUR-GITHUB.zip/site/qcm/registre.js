/* Registre des banques QCM : un fichier par formation (qcm/<formation>.js). */
(function(w){'use strict';
const TARGET=300;
const ALL=["AutoCAD","SketchUp","ArchiCAD","Robot Structural Analysis","Métré et Devis","Revit","Civil 3D","ETABS","SAP2000","Tekla Structures","3ds Max","Lumion","Twinmotion","MS Project","Primavera P6","Excel professionnel","DAO / CAO","Génie civil et bâtiment","Revit MEP","Navisworks","Advance Steel","STAAD.Pro","SAFE","Idea StatiCa","Rhino et Grasshopper","Blender","Enscape","D5 Render","V-Ray","Photoshop pour l’architecture","QGIS","DIALux","Power BI","BIM Management","Béton armé (Eurocode 2)"];
const data={};
w.EXBQCM_BANKS={target:TARGET,all:ALL,data,
 register(name,levels){const d=data[name]||(data[name]={debutant:[],intermediaire:[],avance:[]});['debutant','intermediaire','avance'].forEach(k=>{(levels[k]||[]).forEach(q=>d[k].push(q))})},
 add(name,level,rows){const seen=new Set();const d=data[name]||(data[name]={debutant:[],intermediaire:[],avance:[]});d[level].forEach(q=>seen.add(q[0]));rows.forEach(r=>{if(!seen.has(r[0])){seen.add(r[0]);d[level].push([r[0],r.slice(1),0])}})},
 importPack(pack,cfg){ // format « excellencia-building-qcm » v1 : questions à choix unique avec explication
  if(!pack||pack.format!=='excellencia-building-qcm'||!Array.isArray(pack.questions))return {added:0,replaced:0};
  cfg=cfg||{};const cat=cfg.categories||{},lv=cfg.levels||{},rep=cfg.replace||{};let added=0,replaced=0;
  pack.questions.forEach(q=>{
   const name=cat[q.category]||q.category;if(!name||!q.options||q.options.length<2)return;
   const good=q.options.find(o=>o.id===q.correct_option_id);if(!good)return;
   const texts=[good.text].concat(q.options.filter(o=>o!==good).map(o=>o.text));
   const row=[q.prompt,texts,0,q.explanation||''];
   const d=data[name]||(data[name]={debutant:[],intermediaire:[],avance:[]});
   const old=rep[q.id];let done=false;
   if(old){['debutant','intermediaire','avance'].forEach(k=>{if(done)return;const i=d[k].findIndex(e=>e[0]===old);if(i>=0){d[k][i]=row;done=true;replaced++}})}
   if(!done){const k=lv[q.id]||'debutant';if(!d[k].some(e=>e[0]===q.prompt)){d[k].push(row);added++}}
  });
  return {added,replaced};
 },
 count(name){const d=data[name];return d?d.debutant.length+d.intermediaire.length+d.avance.length:0}};
})(window);
