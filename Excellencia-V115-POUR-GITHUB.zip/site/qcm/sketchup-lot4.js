/* QCM SketchUp — lot 4. Format : [question, BONNE réponse, faux, faux, faux]. */
(function(){const B=EXBQCM_BANKS,N='SketchUp';
B.add(N,'debutant',[
['Quel raccourci rétablit une action annulée sous Windows ?','Ctrl+Y','Ctrl+X','Ctrl+W','Ctrl+B'],
['Quel outil trace des formes à main levée ?','Main levée (Freehand)','Mètre ruban','Pot de peinture','Gomme'],
['Quel outil permet de se déplacer à hauteur d’yeux dans le modèle ?','Marcher (Walk)','Rapporteur','Texte 3D','Échelle'],
['Quel outil place l’observateur à une position choisie, à hauteur d’yeux ?','Positionner la caméra','Rapporteur','Offset','Pot de peinture'],
['Quel outil permet de regarder autour depuis un point fixe ?','Regarder autour (Look Around)','Gomme','Orbite','Pivoter'],
['Quel est le raccourci par défaut de Zoom étendu ?','Maj+Z','Ctrl+Z','Alt+Z','Z seul'],
['À quoi sert l’outil Axes ?','Définir l’origine et l’orientation des axes','Mesurer des angles','Créer des textures','Supprimer les arêtes'],
['Comment supprimer tous les guides ?','Menu Édition > Supprimer les guides','Fermer le modèle','Utiliser Push/Pull','Changer de style'],
['À quoi sert l’outil Texte ?','Ajouter une annotation ou étiquette dans le modèle','Créer un volume en 3D','Modifier une matière','Changer une scène'],
['Que fait l’outil Vue précédente ?','Revenir à la vue de caméra précédente','Annuler une modélisation','Supprimer un composant','Changer de style']]);
B.add(N,'intermediaire',[
['Pourquoi une face peut-elle ne pas se former ?','Les arêtes ne sont pas toutes coplanaires ou ne forment pas un contour fermé','Le modèle est trop petit pour être affiché','Le style est en filaire','La molette est bloquée'],
['Que fait Maj avec la Gomme ?','Masque l’arête au lieu de la supprimer','Supprime tout le modèle','Colore l’arête','Crée une copie'],
['Que fait Ctrl avec la Gomme ?','Adoucit les arêtes','Supprime les faces','Masque les groupes','Change l’échelle'],
['Que fait Alt avec le Pot de peinture sous Windows ?','Échantillonne la matière d’un élément','Supprime la matière','Crée un composant','Verrouille la face'],
['Que fait Maj avec le Pot de peinture ?','Remplace une matière par une autre sur tout le modèle','Supprime la face','Change la vue','Crée une scène'],
['À quoi sert le verrouillage d’un groupe ou composant ?','Éviter de le modifier par erreur','L’exporter en PDF','Réduire sa taille','Supprimer ses matières'],
['Comment créer 5 copies espacées après un déplacement avec Ctrl ?','Saisir 5x dans la zone Mesures','Appuyer 5 fois sur Entrée sans saisie','Utiliser la Gomme 5 fois','Changer de scène'],
['Que fait la saisie /5 après une copie par déplacement ?','Répartit les copies en 5 intervalles égaux entre l’original et la copie','Crée 5 groupes','Divise la face en 5 matières','Supprime 5 arêtes'],
['Comment augmenter le nombre de segments d’un cercle ?','Saisir par exemple 48s dans la zone Mesures','Changer la couleur du ciel','Utiliser la Gomme','Exporter en PDF'],
['Que permet la fonction Envoyer à LayOut ?','Créer une mise en page à partir du modèle SketchUp','Créer une texture','Exporter une matière','Supprimer les scènes'],
['Comment importer une image comme référence ou texture ?','Fichier > Importer','Édition > Supprimer','Fenêtre > Gomme','Style > Arêtes']]);
B.add(N,'avance',[
['Qu’est-ce que le z-fighting ?','Un scintillement causé par des faces coplanaires superposées','Une erreur de licence','Un type de matière','Une fonction d’export'],
['Pourquoi des modèles de 3D Warehouse peuvent-ils alourdir un projet ?','Ils peuvent contenir beaucoup de géométrie et de textures','Ils sont toujours vides','Ils sont en 2D uniquement','Ils bloquent l’orbite'],
['Pourquoi vérifier l’échelle d’un modèle importé de 3D Warehouse ?','Les dimensions peuvent ne pas correspondre à celles du projet','Les couleurs sont toujours fausses','Les axes disparaissent','Les ombres sont impossibles'],
['Pourquoi utiliser des composants pour 100 arbres identiques ?','Alléger le modèle et modifier toutes les copies ensemble','Supprimer les faces','Éviter de les placer','Changer leur nature'],
['Pourquoi nommer clairement les scènes comme plans, façades et coupes ?','Faciliter leur gestion et leur utilisation dans LayOut','Réduire la résolution','Supprimer les balises','Désactiver les ombres'],
['Pourquoi mettre à jour une scène après un changement de style ?','Les scènes mémorisent des réglages qui doivent être actualisés','Pour supprimer les faces','Pour changer le nom du fichier','Pour verrouiller les axes']]);
})();
