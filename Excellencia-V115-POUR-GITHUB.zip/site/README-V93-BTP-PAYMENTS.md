# Excellencia Building V93 — BTP Enterprise + Moyens de paiement

## BTP
- Projets
- Chantiers
- Planning / activités
- QHSE
- Matériel
- Sous-traitance

## Paiements
- Espèces / caisse
- Virement bancaire
- Mobile Money
- Carte bancaire
- Chèque
- Prélèvement
- Encaissements et décaissements
- Statut pending/confirmed
- Référence et traçabilité
- Rapprochement bancaire prêt

## Intégration
Commande → réception → stock → coût projet → facture → paiement → comptabilité.
Sous-traitant → contrat → situation → paiement.
Client → facture → encaissement → banque/caisse.

Migration Supabase : `supabase/migration-v93-btp-payments.sql`, après V92.
