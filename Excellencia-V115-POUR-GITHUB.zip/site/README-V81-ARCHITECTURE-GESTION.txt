EXCELLENCIA BUILDING V81 — ARCHITECTURE & GESTION

INSTALLATION
1) Hébergez le dossier complet (le cache hors ligne passe à « exb-v81 »).
2) Supabase › SQL Editor : exécuter UNE fois supabase/migration-v81-gestion.sql (droits pièces, plans, permis, paie ; réexécutable). Facultatif : supabase/migration-v81-securite.sql (quota quotidien de l'assistant IA).
3) Nouveaux boutons dans « Administration » : ✍️ Pièces écrites · 🗂 Plans & fichiers CAO · 🏛 Permis & autorisations · 💰 Paie & RH.
   (Les phases de mission avec facturation par phase existent déjà depuis la V79 : 📐 Phases architecture.)
4) Contrôle : node tools/check.js (92 contrôles).

1. PIÈCES ÉCRITES — CCTP (11 lots à cocher), CCAP (12 articles), 5 modèles de lettres, compte rendu de réunion, 4 ordres de service
   (démarrage, arrêt, reprise, travaux supplémentaires). Pré-remplis avec projet, client, maître d'ouvrage, lieu, permis, phase.
   Numérotation automatique, statut (brouillon / émis / signé), duplication, PDF. Les clauses sont des bases à faire valider juridiquement.

2. PLANS CAO
   DXF  : visionneuse 2D (calques, blocs, zoom, déplacement), comparaison de versions (ajouté / supprimé / inchangé par calque), annotations.
   IFC  : niveaux, éléments par catégorie, comparaison par identifiant d'élément. PAS de vue 3D.
   Images : visionneuse, comparaison par différence de pixels, annotations.   PDF : lecture seule.
   DWG et Revit (RVT/RFA) : formats propriétaires illisibles dans un navigateur → archivés et versionnés (A, B, C…) ; exporter en DXF / IFC / PDF.
   Les FICHIERS restent sur l'appareil (IndexedDB) ; fiches de versions et annotations sont synchronisées. Un fichier ajouté sur un autre appareil n'est pas visible ici.

3. PERMIS & AUTORISATIONS — permis de bâtir, démolir, environnement, voirie, raccordements, sécurité incendie, ouverture de chantier.
   Pièces à fournir (cases), statuts, dates, alertes (expiration ≤ 60 j, instruction > 60 j, phase chantier sans permis valide).
   Un permis de bâtir « accordé » renseigne son numéro dans le cartouche des plans.

4. PAIE & RH — contrats (CDI/CDD/journalier) imprimables, bulletins mensuels, état des cotisations à reverser, congés avec soldes,
   avances sur salaire remboursées automatiquement, habilitations avec échéances, barèmes modifiables.
   Lien avec le pointage : les ouvriers pointés (Terrain & achats) sont payés d'après leurs pointages du mois ; ceux déjà payés en caisse sont exclus.
   Calcul en FC au taux Finance USD/FC, puis reconverti en $. Paramètres initiaux : INSS 5 % salarié / 13 % employeur (5 + 6,5 + 1,5),
   INPP 3,5 %, ONEM 0,2 %, IPR 3/15/30/40 % (tranches mensuelles 162 000 / 1 800 000 / 3 600 000 FC), plafond 30 %, -2 % par personne à charge.
   ⚠ À CONFIRMER avec l'INSS, la DGI et votre expert-comptable avant la première paie réelle (onglet Barèmes).

LIMITES : la paie ne crée pas d'écriture en caisse (à saisir dans Caisse) ; pas de télédéclaration ; pas de 13e mois ni heures supplémentaires automatiques
(saisir en « primes » sur le bulletin) ; droits : paie visible direction / RH / comptabilité, modifiable RH et comptabilité.
