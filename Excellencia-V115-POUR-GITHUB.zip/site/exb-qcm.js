/* Excellencia Building — QCM débutant, intégré au module Formation */
(function(w){
'use strict';
const KEY='exb_qcm_results_v1';
const REG=w.EXBQCM_BANKS||{data:{},all:[],target:300,count:()=>0};
const BANK={}, LEVEL_BANKS={};
Object.keys(REG.data).forEach(n=>{BANK[n]=REG.data[n].debutant;LEVEL_BANKS[n]={intermediaire:REG.data[n].intermediaire,avance:REG.data[n].avance};});
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function read(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}}
function write(a){try{localStorage.setItem(KEY,JSON.stringify(a));return true}catch(e){return false}}
let current=[], lastResult=null;
function listParticipants(){
 let arr=[];try{if(typeof participants!=='undefined'&&Array.isArray(participants))arr=participants}catch(e){}
 const sel=$('qcm_participant');if(!sel)return;const old=sel.value;
 sel.innerHTML='<option value="">— Test libre / aucun apprenant —</option>'+arr.map(p=>`<option value="${esc(p.participant_id||'')}">${esc(p.name||p.full_name||p.participant_id||'Apprenant')} — ${esc(p.training||'')}</option>`).join('');
 if(old)sel.value=old;
}
function init(){
 const sw=$('qcm_software');if(!sw)return;
 if(!sw.options.length){const names=(REG.all&&REG.all.length?REG.all:Object.keys(BANK));sw.innerHTML=names.map(n=>{const c=REG.count?REG.count(n):0;return c?`<option value="${esc(n)}">${esc(n)} (${c}/${REG.target||300})</option>`:`<option value="${esc(n)}" disabled>${esc(n)} — en préparation (0/${REG.target||300})</option>`}).join('');const first=[...sw.options].find(o=>!o.disabled);if(first)sw.value=first.value}
 listParticipants();
 const levelSel=$('qcm_level'); if(levelSel&&!levelSel.dataset.qcmBound){levelSel.addEventListener('change',()=>{start();});levelSel.dataset.qcmBound='1';}
 renderHistory();start();
}
function start(){
 const software=$('qcm_software')?.value||Object.keys(BANK)[0], count=Number($('qcm_count')?.value||5), level=$('qcm_level')?.value||'debutant';
 const pool=(level==='debutant'?(BANK[software]||[]):((LEVEL_BANKS[software]||{})[level]||[])).slice();
 // Tirage aléatoire sans répétition pour renouveler les QCM à chaque passation.
 for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}
 current=pool.slice(0,Math.min(count,pool.length)).map(q=>{const copy=[q[0],q[1].slice(),q[2],q[3]||''];for(let i=copy[1].length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[1][i],copy[1][j]]=[copy[1][j],copy[1][i]];if(copy[2]===i)copy[2]=j;else if(copy[2]===j)copy[2]=i;}return copy;});
 $('qcm_result').innerHTML='';
 $('qcm_questions').innerHTML=current.map((q,i)=>`<div class="exb-card" style="padding:14px;margin:10px 0;border:1px solid #dce3ed;border-radius:10px"><h3 style="margin:0 0 10px">${i+1}. ${esc(q[0])}</h3>${q[1].map((a,j)=>`<label style="display:flex;gap:8px;align-items:flex-start;padding:7px 0;font-weight:400"><input type="radio" name="qcm_answer_${i}" value="${j}" style="margin-top:4px"> <span>${String.fromCharCode(65+j)}. ${esc(a)}</span></label>`).join('')}</div>`).join('');
 lastResult=null;
}
function reset(){document.querySelectorAll('#qcm_questions input[type=radio]').forEach(x=>x.checked=false);$('qcm_result').innerHTML='';lastResult=null}
function correct(){
 if(!current.length){start();if(!current.length)return}
 const software=$('qcm_software').value, pid=$('qcm_participant').value;
 let score=0, unanswered=0;
 const detail=current.map((q,i)=>{const chosen=document.querySelector(`#qcm_questions input[name="qcm_answer_${i}"]:checked`);const ans=chosen?Number(chosen.value):-1;if(ans<0)unanswered++;if(ans===q[2])score++;return {question:q[0],chosen:ans,correct:q[2],isCorrect:ans===q[2],options:q[1],explanation:q[3]||''}});
 const percent=Math.round(score/current.length*100);
 let pname='Test libre';
 try{if(pid&&typeof participants!=='undefined'){const p=participants.find(x=>x.participant_id===pid);if(p)pname=p.name||p.full_name||'Apprenant'}}catch(e){}
 const level=$('qcm_level')?.value||'debutant';
 const levelLabel={debutant:'Débutant',intermediaire:'Intermédiaire',avance:'Avancé'}[level]||level;
 const result={id:'QCM-'+Date.now(),date:new Date().toISOString(),software,level,level_label:levelLabel,participant_id:pid||'',participant_name:pname,score,total:current.length,percent,details:detail};
 const all=read();all.unshift(result);write(all);lastResult=result;
 $('qcm_result').innerHTML=`<div class="exb-card" style="padding:16px;border:1px solid #cbd5e1;border-radius:12px"><h3>Résultat : ${score}/${current.length} — ${percent}%</h3><p><b>Apprenant :</b> ${esc(pname)} &nbsp; <b>Logiciel :</b> ${esc(software)} &nbsp; <b>Niveau :</b> ${esc(levelLabel)}</p><p>${percent>=80?'Très bien !':percent>=50?'Bon début, continue à pratiquer.':'Continue à t’exercer : tu vas progresser.'}${unanswered?` ${unanswered} question(s) sans réponse.`:''}</p><details><summary>Voir la correction</summary>${detail.map((d,i)=>`<p><b>${i+1}. ${esc(d.question)}</b><br>Ta réponse : ${d.chosen<0?'Aucune réponse':esc(d.options[d.chosen])}<br><span style="color:${d.isCorrect?'#16803c':'#b42318'}">Bonne réponse : ${esc(d.options[d.correct])}</span>${d.explanation?`<br><i>${esc(d.explanation)}</i>`:''}</p>`).join('')}</details></div>`;
 if(pid)saveAsEvaluation(result);
 renderHistory();
}
function saveAsEvaluation(r){
 try{
  if(typeof evaluations==='undefined'||typeof save!=='function')return;
  const exists=evaluations.some(x=>x.qcm_id===r.id);if(exists)return;
  evaluations.unshift({evaluation_id:'EXB-'+r.id, qcm_id:r.id, participant_id:r.participant_id, participant_name:r.participant_name, matricule:r.participant_id, training:r.software, type:'QCM', date:r.date.slice(0,10), subject:'QCM '+(r.level_label||r.level||'Débutant')+' — '+r.software, score:r.score, max:r.total, percent:r.percent, note:'Résultat du QCM logiciel. Réponses détaillées enregistrées dans le module QCM.', epreuve:'QCM', created_at:r.date});
  save('exb_evaluations',evaluations);
 }catch(e){console.warn('QCM: intégration évaluation non disponible',e)}
}
function renderHistory(){
 const all=read();if($('qcm_total'))$('qcm_total').textContent=all.length;
 if($('qcm_average'))$('qcm_average').textContent=(all.length?Math.round(all.reduce((a,x)=>a+(Number(x.percent)||0),0)/all.length):0)+'%';
 if($('qcm_history'))$('qcm_history').innerHTML=all.slice(0,100).map(r=>`<tr><td>${esc((r.date||'').slice(0,10))}</td><td>${esc(r.participant_name)}</td><td>${esc(r.software)}</td><td>${esc(r.level_label||'Débutant')}</td><td>${r.score}/${r.total}</td><td><b>${r.percent}%</b></td></tr>`).join('')||'<tr><td colspan="5">Aucun QCM enregistré.</td></tr>';
}
function exportCSV(){
 const all=read();if(!all.length){alert('Aucun résultat à exporter.');return}
 const rows=[['Date','Apprenant','Identifiant','Logiciel','Niveau','Score','Total','Pourcentage'],...all.map(r=>[r.date,r.participant_name,r.participant_id,r.software,r.level_label||'Débutant',r.score,r.total,r.percent+'%'])];
 const csv='\ufeff'+rows.map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='excellencia-resultats-qcm.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function printResult(){if(!lastResult){alert('Corrigez un QCM avant l’impression.');return}const r=lastResult,win=window.open('','_blank');if(!win){alert('Autorisez les fenêtres contextuelles pour imprimer.');return}win.document.write('<!doctype html><html lang="fr"><meta charset="utf-8"><title>Résultat QCM</title><style>body{font:14px Arial;margin:28px;color:#222}h1{color:#173565}table{border-collapse:collapse;width:100%}td,th{border:1px solid #bbb;padding:8px;text-align:left}</style><h1>Excellencia Building — Résultat QCM</h1><p>Apprenant : '+esc(r.participant_name)+'</p><p>Logiciel : '+esc(r.software)+'</p><p>Niveau : '+esc(r.level_label||'Débutant')+'</p><p>Date : '+esc(r.date.slice(0,10))+'</p><h2>Note : '+r.score+'/'+r.total+' ('+r.percent+'%)</h2><table><tr><th>Question</th><th>Réponse donnée</th><th>Bonne réponse</th><th>Résultat</th></tr>'+r.details.map((d,i)=>'<tr><td>'+(i+1)+'. '+esc(d.question)+'</td><td>'+esc(d.chosen<0?'Sans réponse':d.options[d.chosen])+'</td><td>'+esc(d.options[d.correct])+'</td><td>'+(d.isCorrect?'Correcte':'À revoir')+'</td></tr>').join('')+'</table><script>window.onload=()=>window.print()<\/script></html>');win.document.close()}
w.EXBQCM={init,start,reset,correct,exportCSV,printResult,bank:BANK,levelBank:LEVEL_BANKS};
})(window);
