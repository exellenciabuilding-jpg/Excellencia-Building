/* À renseigner avec VOTRE projet Supabase (clé PUBLIQUE uniquement) — ou via l'écran de configuration (❓ › Personnaliser). Laisser vide = mode local. */
window.EXB_SUPABASE = { url: "https://tqzqkejgkdvznivzsdnq.supabase.co", key: "sb_publishable_bV-ayp3yZZgD0sE1xWn4Zw_9d5BSCDx" };
