/* Excellencia Building — V50.2 module registry
 * Non-destructive registry: it documents and validates the existing modules without replacing them.
 */
(function(w){'use strict';
const modules=[
{id:'dashboard',name:'Tableau de bord',area:'Pilotage',icon:'📊',status:'actif',deps:[]},
{id:'formation',name:'Formation',area:'Formation',icon:'🎓',status:'actif',deps:['participants','formations','formateurs','planning','presence','evaluations']},
{id:'participants',name:'Participants',area:'Formation',icon:'👤',status:'actif',deps:['documents','finances']},
{id:'projets',name:'Projets & chantiers',area:'BTP',icon:'🏗️',status:'actif',deps:['clients','metreDevis','stock','rh','comptabilite','documents']},
{id:'clients',name:'Clients',area:'BTP',icon:'👥',status:'actif',deps:['projets','finances','documents']},
{id:'metreDevis',name:'Métré & devis',area:'BTP',icon:'📐',status:'actif',deps:['projets','clients','stock']},
{id:'stock',name:'Stock & matériaux',area:'BTP',icon:'🧱',status:'actif',deps:['projets','comptabilite']},
{id:'rh',name:'Personnel & RH',area:'Ressources',icon:'👷',status:'actif',deps:['projets','comptabilite','documents']},
{id:'comptabilite',name:'Comptabilité & trésorerie',area:'Finance',icon:'💳',status:'actif',deps:['projets','clients','rh']},
{id:'budgetfin',name:'Budget & pilotage financier',area:'Finance',icon:'📊',status:'nouveau',deps:['comptabilite','facturation','clients','finances']},
{id:'bureauEtudes',name:"Bureau d'études",area:'Technique',icon:'📐',status:'actif',deps:['projets','clients','documents']},
{id:'documents',name:'Gestion documentaire',area:'Transverse',icon:'📁',status:'actif',deps:[]},
{id:'communication',name:'Communication',area:'Commercial',icon:'📣',status:'actif',deps:['clients','projets']},
{id:'portailApprenant',name:'Portail apprenant',area:'Portails',icon:'🎓',status:'actif',deps:['participants','formation','finances','documents']},
{id:'administration',name:'Administration & sécurité',area:'Système',icon:'⚙️',status:'actif',deps:['documents']},
{id:'architecture',name:'Architecture système',area:'Système',icon:'🧩',status:'nouveau',deps:['administration']},
{id:'enterpriseV51',name:'Centre de gestion V51',area:'Pilotage',icon:'🏢',status:'nouveau',deps:['projets','clients','metreDevis','stock','comptabilite','bureauEtudes','documents']},
{id:'tachesChantier',name:'Tâches & planning chantier',area:'BTP',icon:'📋',status:'nouveau',deps:['projets','rh']},
{id:'achats',name:'Achats & bons de commande',area:'Achats',icon:'🛒',status:'nouveau',deps:['projets','stock','fournisseurs']},
{id:'fournisseurs',name:'Fournisseurs & sous-traitants',area:'Achats',icon:'🤝',status:'nouveau',deps:['projets','comptabilite']},
{id:'facturation',name:'Facturation & change orders',area:'Finance',icon:'🧾',status:'nouveau',deps:['projets','clients','comptabilite']},
{id:'journalChantier',name:'Journal, qualité & sécurité',area:'Terrain',icon:'📸',status:'nouveau',deps:['projets','documents']},
{id:'plansVersions',name:'Plans & contrôle des versions',area:'Technique',icon:'📐',status:'nouveau',deps:['projets','bureauEtudes','documents']},
{id:'portailClient',name:'Portail client',area:'Portails',icon:'👤',status:'nouveau',deps:['clients','projets','documents','facturation']},
{id:'etudesTechniques',name:'Études techniques (notes de calcul, plans & visas, honoraires)',area:'Technique',icon:'🧮',status:'nouveau',deps:['projets','bureauEtudes','facturation','rh']},
{id:'planningBudget',name:'Planning de Gantt & budget de construction',area:'BTP',icon:'📅',status:'nouveau',deps:['projets','comptabilite']},
{id:'mobileChantier',name:'Application Excellencia Chantier',area:'Terrain',icon:'📱',status:'separe',deps:['projets','documents','rh']},
{id:'projet360',name:'Projet 360°',area:'BTP',icon:'🏗️',status:'nouveau',deps:['projets','clients','documents','planningBudget','facturation']},
{id:'crmBtp',name:'CRM & opportunités BTP',area:'Commercial',icon:'👥',status:'nouveau',deps:['clients','projets']},
{id:'contrats',name:'Contrats & marchés',area:'Juridique',icon:'📜',status:'nouveau',deps:['projets','clients','fournisseurs']},
{id:'rfi',name:'RFI / demandes d’information',area:'Technique',icon:'❓',status:'nouveau',deps:['projets','plansVersions','documents']},
{id:'submittals',name:'Submittals / fiches techniques',area:'Technique',icon:'📤',status:'nouveau',deps:['projets','fournisseurs','documents']},
{id:'changeOrders',name:'Avenants / Change Orders',area:'Finance',icon:'🔄',status:'nouveau',deps:['projets','facturation','comptabilite']},
{id:'engagements',name:'Engagements & prévisions de coûts',area:'Finance',icon:'💰',status:'nouveau',deps:['projets','achats','comptabilite']},
{id:'qhse',name:'QHSE',area:'Terrain',icon:'🦺',status:'nouveau',deps:['projets','journalChantier','documents']},
{id:'risques',name:'Registre des risques',area:'Pilotage',icon:'⚠️',status:'nouveau',deps:['projets','planningBudget','comptabilite']},
{id:'reunions',name:'Réunions & décisions',area:'Pilotage',icon:'📝',status:'nouveau',deps:['projets','documents']},
{id:'reserves',name:'Réserves / réception / garantie',area:'BTP',icon:'🟠',status:'nouveau',deps:['projets','journalChantier','documents']},
{id:'parcMateriel',name:'Parc matériel & engins',area:'Ressources',icon:'🚜',status:'nouveau',deps:['projets','comptabilite']},
{id:'enterprise360',name:'Enterprise 360°',area:'Entreprise',icon:'🏢',status:'actif',deps:['projets','clients','comptabilite','documents']},
{id:'procurement',name:'Achats & approvisionnements',area:'Achats',icon:'🛒',status:'actif',deps:['projets','stock','fournisseurs']},
{id:'subcontracting',name:'Sous-traitance',area:'Achats',icon:'🤝',status:'actif',deps:['projets','contrats','comptabilite']},
{id:'dqe',name:'DQE / BPU / DPGF',area:'Technique',icon:'📋',status:'actif',deps:['projets','metreDevis','comptabilite']},
{id:'hrContracts',name:'Contrats RH',area:'Ressources',icon:'👥',status:'actif',deps:['rh','documents']},
{id:'approvals',name:'Workflows de validation',area:'Transverse',icon:'✅',status:'actif',deps:['documents','projets']},
{id:'cdeWorkflow',name:'CDE & révisions',area:'Technique',icon:'🗂️',status:'actif',deps:['documents','plansVersions']},
{id:'bankReconciliation',name:'Rapprochement bancaire',area:'Finance',icon:'🏦',status:'actif',deps:['comptabilite','facturation']},
{id:'payroll',name:'Paie & rémunération',area:'Ressources',icon:'💶',status:'actif',deps:['rh','comptabilite']},
{id:'compliance',name:'Conformité & documents expirants',area:'Gouvernance',icon:'🛡️',status:'actif',deps:['documents','rh','fournisseurs']},
{id:'actionPlans',name:'Plans d’actions',area:'Gouvernance',icon:'🎯',status:'actif',deps:['qhse','risques','reunions']},
{id:'architectureEnterprise',name:'Architecture & BIM Enterprise',area:'Architecture',icon:'🏛️',status:'actif',deps:['projets','bureauEtudes','documents']},{id:'cdeEnterprise',name:'CDE documentaire & visas',area:'Architecture',icon:'🗂️',status:'actif',deps:['documents','plansVersions','approvals']},{id:'bimEnterprise',name:'BIM / IFC / Issues',area:'Architecture',icon:'🏗️',status:'actif',deps:['projets','cdeEnterprise']}
];
const roles={
'super_admin':['*'],
'administrateur':['*'],
'direction':['dashboard','planningBudget','etudesTechniques','projets','clients','metreDevis','stock','rh','comptabilite','budgetfin','bureauEtudes','communication','documents','reports'],
'chef de projet':['dashboard','planningBudget','etudesTechniques','projets','clients','metreDevis','stock','documents','bureauEtudes'],
'conducteur travaux':['dashboard','planningBudget','projets','stock','documents'],
'bureau d’études':['dashboard','etudesTechniques','projets','metreDevis','bureauEtudes','documents'],
'comptable':['dashboard','clients','comptabilite','budgetfin','projets','documents'],
'rh':['dashboard','rh','documents'],
'formateur':['dashboard','formation','participants','evaluations','documents'],
'apprenant':['portailApprenant'],
'client':['portailClient']
};
w.EXB_MODULES=modules;
w.EXB_ROLES=roles;
w.EXB_ARCHITECTURE_VERSION='V94-Architecture-BIM-CDE';
w.EXB_MODULE_REGISTRY={get(id){return modules.find(m=>m.id===id)||null;},all(){return modules.slice();},byArea(a){return modules.filter(m=>m.area===a);}};
})(window);
