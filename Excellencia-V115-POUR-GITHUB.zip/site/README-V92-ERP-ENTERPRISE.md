# Excellencia Building — V92 ERP Enterprise

V92 transforme l'architecture Enterprise en flux ERP opérationnels et transversaux.

## Flux
- CRM → opportunité/projet
- Demande d'achat → validation → commande → réception → facture fournisseur → paiement
- Réception → mouvement de stock → consommation chantier → coût projet
- Employé → contrat → paie → comptabilité
- Banque → transaction → rapprochement

## Runtime
`exb-v92-erp.js` fournit un service ERP local/offline avec contrôle des permissions via `EXB_CORE` et journalisation via `EXB_CORE.audit`.

## Base Supabase
Migration : `supabase/migration-v92-erp.sql`

La migration doit être exécutée après `migration-v91-core.sql` et les migrations précédentes. Les nouvelles tables sont isolées par `org_id` et protégées par RLS.

## Important
Le mode local est conçu pour permettre la continuité de travail hors connexion. Le passage en production doit être validé sur un vrai projet Supabase, avec les rôles, RLS, données de l'organisation et workflows d'approbation réels.
