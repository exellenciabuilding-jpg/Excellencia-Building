/* Excellencia Building V99zt — Moteur de pilotage projet : EVM automatique, retard (chemin critique), alertes, consolidation.
 * Aucune saisie en plus : tout est calculé à partir des données existantes (projet, planning Gantt, budget de construction, caisse).
 *  · BAC (budget)       = total du budget de construction (26 postes) s'il existe, sinon budget du projet.
 *  · AC  (coût réel)    = le plus élevé de « coût réel » du budget et des dépenses de caisse du projet (jamais sous-estimé).
 *  · EV  (valeur acquise) = BAC × avancement physique (Gantt pondéré par les durées, sinon avancement du projet).
 *  · PV  (valeur planifiée) = BAC × avancement planifié à la date du jour (Gantt, sinon calendrier début → fin du projet).
 *  CPI = EV/AC · SPI = EV/PV · EAC = BAC/CPI · VAC = BAC − EAC · TCPI = (BAC − EV)/(BAC − AC).
 * Limite : les tâches du Gantt n'ont pas de coût propre ; l'avancement et le planifié sont pondérés par les durées. */
(function(root){'use strict';
var N=function(x){x=+x;return isFinite(x)?x:0};
var r2=function(n){return Math.round((n+Number.EPSILON)*100)/100};
var M=function(n){return Math.round(N(n)).toLocaleString('fr-FR').replace(/[\u202f\u00a0]/g,' ')};
var D2=function(n){return String(r2(n)).replace('.',',')};
var clamp=function(x,a,b){return Math.min(b,Math.max(a,x))};
function days(a,b){return Math.floor((Date.parse(a)-Date.parse(b))/864e5)}
function addDays(s,n){var d=new Date(s+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)}
var DEF={cpiRed:.85,cpiAmber:.95,spiRed:.85,spiAmber:.95,vacRed:.10,vacAmber:.03,delayRed:2,delayAmber:1,burn:.9};
function CPM(){return root.EXBCPM||(typeof require!=='undefined'?require('./exb-cpm.js'):null)}

/* semaine en cours du Gantt (même règle que le module Planning) */
function curWeek(week1,today){if(!week1||!today)return 0;return Math.floor(days(today,week1)/7)+1}
/* avancement planifié (%) après t semaines écoulées (t continu, 0 = début de la semaine 1) */
function plannedAt(tasks,es,t){var sd=0,sp=0;tasks.forEach(function(k,i){var d=Math.max(1,N(k.dur)||1),s=es?es[i]:Math.max(1,N(k.start)||1);sd+=d;sp+=d*clamp((t-(s-1))/d,0,1)});return sd>0?sp/sd*100:0}
function actual(tasks){var sd=0,sp=0;tasks.forEach(function(k){var d=Math.max(1,N(k.dur)||1);sd+=d;sp+=d*clamp(N(k.pct),0,100)});return sd>0?sp/sd:0}

/* inp : {bac,ac,acSource,bacSource,progress,tasks,week1,start,end,today,postes,cash,impayes,closed,bacProj} */
function analyse(inp,th){
  th=Object.assign({},DEF,sane(th));inp=inp||{};
  var tasks=Array.isArray(inp.tasks)?inp.tasks:[],hasG=tasks.length>0,today=inp.today,
      bac=Math.max(0,N(inp.bac)),ac=Math.max(0,N(inp.ac)),al=[],src={};
  function A(sev,code,msg,hint){al.push({sev:sev,code:code,msg:msg,hint:hint||''})}
  /* --- planning / chemin critique --- */
  var cw=hasG?curWeek(inp.week1,today):0,cp=null,cm=CPM();
  if(hasG&&cm)cp=cm.compute(tasks,cw>0?cw:0);
  var cpOk=!!(cp&&!cp.error);
  /* --- avancement réel et planifié --- */
  var prog,planned=null;
  if(hasG){prog=actual(tasks);src.progress='Gantt (pondéré par les durées)'}
  else{prog=clamp(N(inp.progress),0,100);src.progress='Avancement du projet (saisi)'}
  if(hasG&&inp.week1){var t=Math.max(0,days(today,inp.week1)/7);planned=plannedAt(tasks,cpOk?cp.tasks.map(function(o){return o.es}):null,t);src.planned='Gantt, à la date du jour'}
  else if(inp.start&&inp.end&&Date.parse(inp.end)>Date.parse(inp.start)){planned=clamp((Date.parse(today)-Date.parse(inp.start))/(Date.parse(inp.end)-Date.parse(inp.start))*100,0,100);src.planned='Calendrier du projet (début → fin, linéaire)'}
  else src.planned='Non disponible'
  /* --- EVM --- */
  var ev=bac*prog/100,pv=(planned==null)?null:bac*planned/100,cpi=null,spi=null,eac=null,etc=null,vac=null,tcpi=null,cv=null,sv=null;
  if(bac>0){
    if(ac>0){cpi=ev/ac;cv=ev-ac}
    if(pv!=null&&pv>0){spi=ev/pv;sv=ev-pv}
    if(cpi!=null&&cpi>0){eac=bac/cpi;etc=eac-ac;vac=bac-eac}else if(ac===0){eac=bac;etc=bac;vac=0}
    if(bac>ac&&bac-ev>0)tcpi=(bac-ev)/(bac-ac)}
  /* --- retard (chemin critique) --- */
  var fin=null,finP=null,retard=0,late=0,critLate=0,finPlan='',finPrev='';
  if(cpOk){fin=cp.fin;finP=cp.finPrevue;retard=cp.retardProjet||0;
    late=cp.tasks.filter(function(o){return o.retard>0}).length;critLate=cp.tasks.filter(function(o){return o.critique&&o.retard>0}).length;
    if(inp.week1){finPlan=addDays(inp.week1,fin*7-1);if(finP!=null)finPrev=addDays(inp.week1,finP*7-1)}}
  /* --- alertes (projet en cours seulement pour délai et consommation) --- */
  var open=!inp.closed;
  if(bac>0&&ac>0){
    if(cpi<th.cpiRed)A('high','CPI','Coût : chaque dollar dépensé n\'a produit que '+D2(cpi)+' $ d\'avancement (CPI '+D2(cpi)+').','Vérifier les postes en dépassement et renégocier ou arbitrer avant de poursuivre.');
    else if(cpi<th.cpiAmber)A('medium','CPI','Dérive de coût (CPI '+D2(cpi)+').','Surveiller les postes qui dépassent leur budget.')}
  if(open&&spi!=null){
    if(spi<th.spiRed)A('high','SPI','Délai : avancement à '+Math.round(spi*100)+' % du planifié (SPI '+D2(spi)+').','Renforcer les ressources sur le chemin critique ou replanifier.');
    else if(spi<th.spiAmber)A('medium','SPI','Léger retard sur le planifié (SPI '+D2(spi)+').','Contrôler les tâches de la semaine.')}
  if(open&&cpOk&&inp.week1){
    if(retard>=th.delayRed)A('high','RETARD','Retard prévisionnel de '+retard+' semaine(s) sur la fin du chantier'+(finPrev?' (fin prévue le '+finPrev.split('-').reverse().join('/')+')':'')+'.','Les tâches critiques en retard décalent la livraison : agir dessus en priorité.');
    else if(retard>=th.delayAmber)A('medium','RETARD','Retard prévisionnel de '+retard+' semaine.','Rattraper sur les tâches critiques.');
    if(critLate>0&&retard<th.delayAmber)A('medium','CRIT','Tâche(s) critique(s) en retard : '+critLate+'.','Elles n\'ont aucune marge.')}
  if(bac>0&&vac!=null&&eac!=null){
    var pct=-vac/bac;
    if(pct>th.vacRed)A('high','EAC','Coût final estimé '+M(eac)+' $ pour un budget de '+M(bac)+' $ (dépassement de '+Math.round(pct*100)+' %).','Décider d\'un avenant, d\'économies ou d\'un arbitrage de périmètre.');
    else if(pct>th.vacAmber)A('medium','EAC','Coût final estimé supérieur au budget de '+Math.round(pct*100)+' %.','')}
  if(open&&bac>0&&ac>bac)A('high','BUDGET','Dépenses ('+M(ac)+' $) supérieures au budget ('+M(bac)+' $).','Geler les engagements non essentiels.');
  else if(open&&bac>0&&ac>th.burn*bac&&prog<90)A('medium','BURN',Math.round(ac/bac*100)+' % du budget consommé pour '+Math.round(prog)+' % d\'avancement.','');
  var over=(inp.postes||[]).filter(function(x){return N(x.b)>0&&N(x.r)>N(x.b)}).sort(function(a,b){return(N(b.r)-N(b.b))-(N(a.r)-N(a.b))});
  if(over.length)A('medium','POSTES',over.length+' poste(s) de dépense au-dessus de leur budget : '+over.slice(0,3).map(function(x){return x.label+' (+'+M(N(x.r)-N(x.b))+' $)'}).join(' ; ')+(over.length>3?'…':'')+'.','');
  if(N(inp.impayes)>0.005)A('medium','IMPAYES','Impayés échus : '+M(inp.impayes)+' $ sur ce chantier.','Relancer le client (module Pilotage direction).');
  if(cp&&cp.error)A('medium','CYCLE','Planning : dépendances circulaires (tâches '+cp.cycle.join(', ')+') — retard et chemin critique non calculés.','Corriger les liens dans « Planning & budget ».');
  /* --- qualité des données --- */
  if(!(bac>0))A('low','DATA_BAC','Aucun budget : EVM impossible.','Saisir un budget dans « Planning & budget » (ou le budget du projet).');
  else if(!(ac>0)&&prog>0)A('low','DATA_AC','Aucun coût réel enregistré : le CPI ne peut pas être calculé.','Saisir les coûts réels ou les dépenses de caisse du projet.');
  if(!hasG&&planned==null)A('low','DATA_PLAN','Ni planning Gantt ni dates début/fin : SPI et retard indisponibles.','Créer le planning du chantier.');
  else if(hasG&&!inp.week1)A('low','DATA_S1','Planning sans date de la semaine 1 : SPI et retard prévisionnel indisponibles.','Renseigner la date de début dans le Gantt.');
  if(hasG&&inp.progress!=null&&inp.progress!==''&&Math.abs(actual(tasks)-N(inp.progress))>10)A('low','DATA_AV','Avancement du projet ('+Math.round(N(inp.progress))+' %) différent de celui du Gantt ('+Math.round(actual(tasks))+' %) : le Gantt est utilisé.','Utiliser « Avancement → projet » dans le planning.');
  if(inp.bacProj>0&&inp.bac>0&&inp.bacSource==='budget'&&Math.abs(inp.bacProj-inp.bac)/inp.bac>0.01)A('low','DATA_BUD','Budget du projet ('+M(inp.bacProj)+' $) différent du budget détaillé ('+M(inp.bac)+' $) : le budget détaillé est utilisé.','');
  if(inp.cash>0&&inp.acSource==='budget'&&inp.cash>ac*1.005)A('low','DATA_CASH','Dépenses de caisse supérieures au coût réel saisi.','');
  var rank={high:0,medium:1,low:2};al.sort(function(a,b){return rank[a.sev]-rank[b.sev]});
  var hasHigh=al.some(function(a){return a.sev==='high'}),hasMed=al.some(function(a){return a.sev==='medium'});
  var status=(cpi==null&&spi==null&&!hasHigh&&!hasMed)?'gris':hasHigh?'rouge':hasMed?'orange':'vert';
  var curve=null,nW=0;
  if(hasG&&inp.week1){nW=tasks.reduce(function(m,k){return Math.max(m,(cpOk?cp.tasks[tasks.indexOf(k)].ef:N(k.start)+N(k.dur)-1))},cw>0?cw:0);nW=Math.max(nW,finP||0,4);
    var es=cpOk?cp.tasks.map(function(o){return o.es}):null;curve=[];for(var w=0;w<=nW;w++)curve.push(r2(plannedAt(tasks,es,w)))}
  var anomalies=detect(inp,bac);
  return {thr:th,anomalies:anomalies,bac:r2(bac),ac:r2(ac),ev:r2(ev),pv:pv==null?null:r2(pv),progress:r2(prog),planned:planned==null?null:r2(planned),
    cpi:cpi==null?null:r2(cpi),spi:spi==null?null:r2(spi),cv:cv==null?null:r2(cv),sv:sv==null?null:r2(sv),eac:eac==null?null:r2(eac),etc:etc==null?null:r2(etc),vac:vac==null?null:r2(vac),tcpi:tcpi==null?null:r2(tcpi),
    cw:cw,weeks:nW,curve:curve,fin:fin,finPrevue:finP,retard:retard,tachesRetard:late,critRetard:critLate,critiques:cpOk?cp.critiques:[],finPlan:finPlan,finPrev:finPrev,
    closed:!open,alerts:al,status:status,sources:{progress:src.progress,planned:src.planned,bac:inp.bacSource||'',ac:inp.acSource||''}}}

/* assemble les entrées depuis les fiches de l'application */
function build(p,g,b,cashOut,today,impayes,cashRows){
  p=p||{};var tot=0,real=0,postes=[];
  if(b&&Array.isArray(b.postes)){postes=b.postes;b.postes.forEach(function(x){tot+=N(x.b);real+=N(x.r)})}
  var bac,bs;if(tot>0){bac=tot;bs='budget'}else{bac=N(p.budget);bs='projet'}
  var cash=N(cashOut),ac,as;if(real>=cash&&real>0){ac=real;as='budget'}else if(cash>0){ac=cash;as='caisse'}else{ac=0;as=''}
  var prog=p.progress,fin=/termin|cl[oô]tur|livr/i.test(p.status||'')||N(prog)>=100;
  return {bac:bac,bacSource:bs,bacProj:N(p.budget),ac:ac,acSource:as,cash:cash,progress:prog,tasks:(g&&g.tasks)||[],week1:g&&g.date||'',
    start:p.start||'',end:p.end||'',today:today,postes:postes,impayes:impayes,closed:fin,cashRows:cashRows||[]}}
function analyseProject(p,g,b,cashOut,today,impayes,th,cashRows){return analyse(build(p,g,b,cashOut,today,impayes,cashRows),th)}

/* consolidation multi-projets : l'indice du portefeuille = somme des EV / somme des AC (et des PV) */
function consolidate(rows){
  var T={n:0,actifs:0,rouge:0,orange:0,vert:0,gris:0,bac:0,ev:0,ac:0,pv:0,evPv:0,eac:0,eacN:0,retardMax:0,alertes:0};
  rows.forEach(function(a){T.n++;T[a.status]++;if(!a.closed)T.actifs++;T.alertes+=a.alerts.filter(function(x){return x.sev!=='low'}).length;
    if(!(a.bac>0))return;T.bac+=a.bac;T.ev+=a.ev;T.ac+=a.ac;if(a.pv!=null){T.pv+=a.pv;T.evPv+=a.ev}
    if(a.eac!=null){T.eac+=a.eac;T.eacN++}else T.eac+=a.bac;if(a.retard>T.retardMax)T.retardMax=a.retard});
  T.cpi=T.ac>0?r2(T.ev/T.ac):null;T.spi=T.pv>0?r2(T.evPv/T.pv):null;
  ['bac','ev','ac','pv','eac'].forEach(function(k){T[k]=r2(T[k])});T.vac=r2(T.bac-T.eac);return T}

/* ---------- IA locale (V99zz) : anomalies de coûts, synthèse, contexte pour l'assistant — règles déterministes, aucune donnée envoyée ---------- */
function median(a){var b=a.slice().sort(function(x,y){return x-y}),n=b.length;return n?(n%2?b[(n-1)/2]:(b[n/2-1]+b[n/2])/2):0}
function clean(t,n){return String(t==null?'':t).replace(/[\u0000-\u001f\u007f<>`]/g,' ').replace(/\s+/g,' ').trim().slice(0,n||60)}
function fr(s){return s?String(s).slice(0,10).split('-').reverse().join('/'):'—'}
/* inp.postes : [{label,b,r}] ; inp.cashRows : écritures de caisse du projet [{type,amount,date,label}] */
function detect(inp,bac){
  var out=[],postes=inp.postes||[],cash=(inp.cashRows||[]).filter(function(c){return c&&c.type==='out'&&N(c.amount)>0});
  postes.forEach(function(x){var b=N(x.b),r=N(x.r);
    if(b===0&&r>0)out.push({sev:'medium',code:'HORS_BUDGET',msg:'Dépense hors budget : « '+clean(x.label)+' » '+M(r)+' $ sans montant prévu.'});
    else if(b>0&&r>=1.5*b)out.push({sev:'high',code:'SURCONSO',msg:'Poste « '+clean(x.label)+' » à '+Math.round(r/b*100)+' % de son budget ('+M(r)+' $ pour '+M(b)+' $ prévus).'})});
  var seen={};cash.forEach(function(c){var k=[c.date,N(c.amount),clean(c.label,80).toLowerCase()].join('|');(seen[k]=seen[k]||[]).push(c)});
  Object.keys(seen).forEach(function(k){var l=seen[k];if(l.length>1)out.push({sev:'medium',code:'DOUBLON',msg:'Possible double saisie : '+l.length+' sorties de caisse de '+M(l[0].amount)+' $ le '+fr(l[0].date)+' (« '+clean(l[0].label)+' »).'})});
  if(cash.length>=5){var med=median(cash.map(function(c){return N(c.amount)})),lim=Math.max(5*med,bac>0?0.02*bac:0);
    cash.forEach(function(c){if(med>0&&N(c.amount)>=lim&&N(c.amount)>=5*med)out.push({sev:'low',code:'ATYPIQUE',msg:'Montant atypique : '+M(c.amount)+' $ le '+fr(c.date)+' (« '+clean(c.label)+' ») — '+Math.round(N(c.amount)/med)+' fois la dépense habituelle ('+M(med)+' $).'})})}
  return out}

function pctTxt(v){return v==null?'—':Number(v).toFixed(2).replace('.',',')}
/* synthèse hebdomadaire du portefeuille (texte prêt à lire ou à envoyer) ; rows = résultats d'analyse enrichis de .name */
function synthese(rows,today){
  var R=(rows||[]).filter(function(a){return !a.closed});if(!R.length)return '';
  var T=consolidate(R),L=[];
  L.push('Synthèse des chantiers au '+fr(today)+' — '+R.length+' projet(s) en cours : '+T.rouge+' à traiter, '+T.orange+' à surveiller, '+T.vert+' sous contrôle'+(T.gris?', '+T.gris+' sans données':'')+'.');
  if(T.bac>0)L.push('Portefeuille : CPI '+pctTxt(T.cpi)+', SPI '+pctTxt(T.spi)+', budget '+M(T.bac)+' $, coût réel '+M(T.ac)+' $, coût final estimé '+M(T.eac)+' $'+(T.vac<0?' (dépassement de '+M(-T.vac)+' $)':'')+'.');
  tri(R).filter(function(a){return a.status==='rouge'||a.status==='orange'}).slice(0,5).forEach(function(a){
    var top=a.alerts.filter(function(x){return x.sev!=='low'}).slice(0,2).map(function(x){return x.msg}).join(' ');
    L.push('• '+clean(a.name)+' ('+(a.status==='rouge'?'à traiter':'à surveiller')+') : '+top)});
  var an=[];R.forEach(function(a){(a.anomalies||[]).filter(function(x){return x.sev!=='low'}).forEach(function(x){an.push(clean(a.name)+' — '+x.msg)})});
  if(an.length)L.push('Anomalies de coûts à vérifier : '+an.slice(0,3).join(' | ')+(an.length>3?' (+'+(an.length-3)+')':'')+'.');
  var hints=[];R.forEach(function(a){a.alerts.forEach(function(x){if(x.sev==='high'&&x.hint&&hints.indexOf(x.hint)<0)hints.push(x.hint)})});
  if(hints.length)L.push('À faire en priorité : '+hints.slice(0,3).join(' ; ')+'');
  var low=R.filter(function(a){return a.status==='gris'}).length;if(low)L.push(low+' projet(s) sans budget ni planning exploitable : indicateurs indisponibles.');
  return L.join('\n')}
/* contexte compact transmis à l'assistant (jamais de nom de personne, uniquement chantiers et indicateurs) */
function ctx(rows,today){
  var R=tri((rows||[]).filter(function(a){return !a.closed}));if(!R.length)return '';
  var T=consolidate(R),L=['Pilotage projets (indicateurs calculés par le logiciel au '+fr(today)+', en USD ; CPI et SPI inférieurs à 1 = dérive de coût ou de délai) :'];
  L.push('Portefeuille : '+R.length+' projets ; à traiter '+T.rouge+', à surveiller '+T.orange+', sous contrôle '+T.vert+' ; CPI '+pctTxt(T.cpi)+' ; SPI '+pctTxt(T.spi)+' ; budget '+M(T.bac)+' ; coût réel '+M(T.ac)+' ; coût final estimé '+M(T.eac));
  var used=L.join('\n').length,shown=0;
  R.slice(0,10).forEach(function(a){
    var al=a.alerts.concat(a.anomalies||[]).filter(function(x){return x.sev!=='low'}).slice(0,2).map(function(x){return clean(x.msg,140)}).join(' / ');
    var line='- '+clean(a.name,40)+' ['+a.status+'] avancement '+Math.round(a.progress)+' % / planifié '+(a.planned==null?'?':Math.round(a.planned)+' %')+' ; CPI '+pctTxt(a.cpi)+' ; SPI '+pctTxt(a.spi)+' ; retard '+(a.finPrevue==null?'?':a.retard+' sem')+' ; budget '+M(a.bac)+' ; EAC '+(a.eac==null?'?':M(a.eac))+(al?' ; alertes : '+al:'');
    if(used+line.length+1>3000)return;L.push(line);used+=line.length+1;shown++});
  if(R.length>shown)L.push('(+'+(R.length-shown)+' autres projets)');
  return L.join('\n').slice(0,3200)}


/* ---------- seuils d'alerte réglables (V100) ---------- */
/* limites autorisées : [min,max] ; rouge/orange doivent rester cohérents (rouge plus sévère que orange) */
var LIM={cpiRed:[.3,1.5],cpiAmber:[.3,1.5],spiRed:[.3,1.5],spiAmber:[.3,1.5],vacRed:[0,1],vacAmber:[0,1],delayRed:[0,52],delayAmber:[0,52],burn:[.5,1]};
function sane(o){var r={};if(!o||typeof o!=='object')return r;Object.keys(LIM).forEach(function(k){if(o[k]===''||o[k]==null)return;var v=+o[k];if(isFinite(v)&&v>=LIM[k][0]&&v<=LIM[k][1])r[k]=v});return r}
function validateTh(o){var errs=[],th=Object.assign({},DEF);o=o||{};
  Object.keys(LIM).forEach(function(k){if(o[k]===''||o[k]==null)return;var v=+o[k];if(!isFinite(v)||v<LIM[k][0]||v>LIM[k][1])errs.push(k+' : valeur hors limites ('+LIM[k][0]+' à '+LIM[k][1]+')');else th[k]=v});
  if(th.cpiRed>th.cpiAmber)errs.push('CPI : le seuil rouge doit être inférieur ou égal au seuil orange');
  if(th.spiRed>th.spiAmber)errs.push('SPI : le seuil rouge doit être inférieur ou égal au seuil orange');
  if(th.vacRed<th.vacAmber)errs.push('Dépassement : le seuil rouge doit être supérieur ou égal au seuil orange');
  if(th.delayRed<th.delayAmber)errs.push('Retard : le seuil rouge doit être supérieur ou égal au seuil orange');
  return {ok:!errs.length,errors:errs,th:errs.length?null:th}}
/* cfg : [{id:'global',th:{}},{id:'<projet>',th:{}}] ; priorité : projet > global > défauts */
function thFor(cfg,pid){var g=null,p=null;(cfg||[]).forEach(function(c){if(!c)return;if(c.id==='global')g=c.th;else if(String(c.id)===String(pid))p=c.th});
  var okT=function(t){return t.cpiRed<=t.cpiAmber&&t.spiRed<=t.spiAmber&&t.vacRed>=t.vacAmber&&t.delayRed>=t.delayAmber},
      A=Object.assign({},DEF,sane(g),sane(p)),B=Object.assign({},DEF,sane(g));
  return okT(A)?A:okT(B)?B:Object.assign({},DEF)}


/* ---------- Historique hebdomadaire (V99zz+) : un point par projet et par semaine (lundi), le dernier relevé de la semaine l'emporte ---------- */
var r1=function(n){return Math.round((n+Number.EPSILON)*10)/10};
function monday(s){var d=new Date(String(s||'').slice(0,10)+'T00:00:00Z');if(isNaN(d.getTime()))return '';d.setUTCDate(d.getUTCDate()-((d.getUTCDay()+6)%7));return d.toISOString().slice(0,10)}
/* Un projet terminé, sans budget ou sans aucun indice calculable n'a pas de point : on ne fabrique jamais d'indice. */
function snap(a,today){if(!a||a.closed||!(a.bac>0)||(a.cpi==null&&a.spi==null))return null;var w=monday(today);if(!w)return null;
  return {pid:String(a.id),week:w,date:String(today).slice(0,10),progress:r1(N(a.progress)),planned:a.planned==null?null:r1(N(a.planned)),cpi:a.cpi==null?null:r2(a.cpi),spi:a.spi==null?null:r2(a.spi),ac:r2(N(a.ac)),bac:r2(N(a.bac)),eac:a.eac==null?null:r2(a.eac),retard:N(a.retard),status:a.status||''}}
/* Fusion : remplace le point de même projet et même semaine ; garde les 104 dernières semaines par projet (2 ans). */
function mergeHistory(hist,snaps,keep){keep=keep||104;var h=(Array.isArray(hist)?hist:[]).filter(function(x){return x&&x.pid&&x.week});
  (snaps||[]).forEach(function(s){if(!s)return;h=h.filter(function(x){return !(x.pid===s.pid&&x.week===s.week)});h.push(s)});
  h.sort(function(a,b){return a.pid<b.pid?-1:a.pid>b.pid?1:(a.week<b.week?-1:a.week>b.week?1:0)});
  var cnt={},out=[];for(var i=h.length-1;i>=0;i--){var k=h[i].pid;cnt[k]=(cnt[k]||0)+1;if(cnt[k]<=keep)out.push(h[i])}return out.reverse()}
function series(hist,pid){return (Array.isArray(hist)?hist:[]).filter(function(x){return x&&String(x.pid)===String(pid)}).sort(function(a,b){return a.week<b.week?-1:a.week>b.week?1:0})}
function dir(d,eps){return d==null?null:d>=eps?'up':d<=-eps?'down':'flat'}
/* Tendance = dernier point comparé au précédent. Écart de 0,02 ou plus : amélioration / dégradation ; en dessous : stable. */
function trend(hist,pid){var s=series(hist,pid),n=s.length;if(n<2)return {n:n,cpi:null,spi:null};var a=s[n-2],b=s[n-1];
  function one(k){if(a[k]==null||b[k]==null)return null;var d=r2(b[k]-a[k]);return {v:b[k],delta:d,dir:dir(d,.02)}}
  return {n:n,from:a.week,to:b.week,cpi:one('cpi'),spi:one('spi')}}

var ORDER={rouge:0,orange:1,gris:2,vert:3};
function tri(rows){return rows.slice().sort(function(a,b){return(a.closed-b.closed)||(ORDER[a.status]-ORDER[b.status])||String(a.name).localeCompare(String(b.name))})}

var API={sane:sane,validateTh:validateTh,thFor:thFor,LIM:LIM,detect:detect,synthese:synthese,ctx:ctx,analyse:analyse,build:build,analyseProject:analyseProject,consolidate:consolidate,tri:tri,monday:monday,snap:snap,mergeHistory:mergeHistory,series:series,trend:trend,curWeek:curWeek,plannedAt:plannedAt,DEF:DEF};
root.EXBEVM=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
