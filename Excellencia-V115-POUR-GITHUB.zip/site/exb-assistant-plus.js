/* Excellencia Building — V99 ASSISTANT : nouvelles tâches locales (sans clé ni internet, lecture seule).
 *   « y a-t-il des doublons ? »            → contrôle des doublons (personnes, formateurs, certificats, reçus, numéros)
 *   « vérifie l'orthographe de mes fiches » → fautes repérées dans les textes libres (notes, spécialités, adresses…)
 *   « liste les inscrits à AutoCAD »        → participants d'une formation ; « répartition par formation »
 *   « qui n'a pas payé ? »                  → reçus dont l'inscription ou la formation n'est pas payée
 *   « relance les impayés » / « relance Jean Kasongo » → messages de rappel prêts à copier (rien n'est envoyé)
 *   EXB_ASSIST_PLUS.fuzzy(nom) : recherche tolérante aux fautes de frappe et aux erreurs de reconnaissance vocale
 * Rien n'est modifié : ces tâches ne demandent donc aucune autorisation. Appelé depuis localAI() de index.html :
 *   var r = EXB_ASSIST_PLUS.run(texteBrut, texteNormalisé) → {answer, actions} ou null. */
(function (w) {
  'use strict';
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9+#.\- ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function jlist(key) { /* même lecture que le logiciel : pont EXBS, exbStorage (préfixé), localStorage brut */
    var a = null, v;
    try { if (w.EXBS && w.EXBS.get) a = w.EXBS.get(key); } catch (e) {}
    if (!a || !a.length) { try { var st = (typeof exbStorage !== 'undefined') ? exbStorage : null; if (st) { v = JSON.parse(st.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } } catch (e) {} }
    if (!a || !a.length) { try { v = JSON.parse(w.localStorage.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } catch (e) {} }
    return (a || []).filter(function (x) { return x && typeof x === 'object'; });
  }
  function pName(p) { return String(p.name || p.full_name || [p.first_name, p.last_name].filter(Boolean).join(' ') || '').trim(); }
  function osa(a, b, max) { /* distance d'édition avec transposition, arrêtée au-delà de max */
    var la = a.length, lb = b.length; if (Math.abs(la - lb) > max) return max + 1;
    var m = [], i, j; for (i = 0; i <= la; i++) m[i] = [i]; for (j = 1; j <= lb; j++) m[0][j] = j;
    for (i = 1; i <= la; i++) for (j = 1; j <= lb; j++) {
      m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      if (i > 1 && j > 1 && a.charAt(i - 1) === b.charAt(j - 2) && a.charAt(i - 2) === b.charAt(j - 1)) m[i][j] = Math.min(m[i][j], m[i - 2][j - 2] + 1);
    }
    return m[la][lb];
  }
  /* forme « sonore » d'un mot : rapproche Kasonga/Kasongo, Mukendi/Moukendi, Philippe/Filipe, Ilunga/IluNga… */
  function phon(t) {
    return String(t).replace(/ph/g, 'f').replace(/ou/g, 'u').replace(/[ckq]+/g, 'k').replace(/y/g, 'i').replace(/w/g, 'u').replace(/(.)\1+/g, '$1').replace(/[hsxtd]+$/, '');
  }
  function title(x) { return String(x).replace(/(^|[\s\-])([a-zà-ÿ])/g, function (m, a, b) { return a + b.toUpperCase(); }); }
  function tokDist(q, t, loose) { /* -1 = pas de rapprochement ; sinon 0 (exact / début de mot / même son), 1 ou 2 fautes */
    if (q === t) return 0; if (q.length >= 3 && t.indexOf(q) === 0) return 0;
    var qp = phon(q), tp = phon(t); if (qp === tp) return 0;
    var lim = qp.length >= 7 ? 2 : qp.length >= 4 ? 1 : (loose && qp.length === 3 ? 1 : 0); if (!lim) return -1;
    var d = osa(qp, tp, lim); return d <= lim ? d : -1;
  }
  var KINDS = [['exb_participants', 'Participant', 'participants'], ['exb_trainers', 'Formateur', 'formateurs'], ['exb_clients', 'Client', 'clients'], ['exb_hr', 'Personnel', 'rh'], ['exb_projects', 'Projet', 'projets']];
  function fuzzy(term) {
    var ws = norm(term).split(' ').filter(function (x) { return x.length >= 2 && !/^(le|la|les|de|du|des|d|l)$/.test(x); });
    if (!ws.length) return [];
    var out = [];
    KINDS.forEach(function (K) {
      jlist(K[0]).slice(0, 4000).forEach(function (r) {
        var label = pName(r) || String(r.title || r.nom || r.code || '').trim(); if (!label) return;
        var toks = norm(label).split(' ').filter(Boolean), score = 0, ok = true;
        ws.forEach(function (q) { if (!ok) return; var best = -1; toks.forEach(function (t) { var d = tokDist(q, t, ws.length >= 2); if (d >= 0 && (best < 0 || d < best)) best = d; }); if (best < 0) ok = false; else score += best; });
        if (ok) out.push({ kind: K[1], tab: K[2], label: label, phone: r.phone || r.telephone || '', score: score });
      });
    });
    out.sort(function (a, b) { return a.score - b.score || a.label.localeCompare(b.label); });
    return out;
  }
  function R(answer, actions) { return { answer: answer, actions: actions || [] }; }
  var NOHOW = /\b(comment|pourquoi|explique\w*|c.?est quoi|a quoi sert|mode d.?emploi)\b/;

  /* 1) doublons */
  function doublons() {
    var D = w.EXBDOUBLONS, L = D && D.scan ? D.scan() : null;
    if (L === null) return R('Le contrôle des doublons n’est pas encore prêt : ouvrez l’écran d’accueil quelques secondes puis redemandez-moi.', [{ type: 'goto', tab: 'dashboard' }]);
    if (!L.length) return R('✅ Aucun doublon repéré (participants, formateurs, certificats, reçus, numéros de documents). Je ne modifie jamais rien : je signale seulement.');
    var rank = { erreur: 0, alerte: 1, info: 2 };
    L.sort(function (a, b) { return (rank[a.sev] == null ? 3 : rank[a.sev]) - (rank[b.sev] == null ? 3 : rank[b.sev]); });
    var n = { erreur: 0, alerte: 0, info: 0 }; L.forEach(function (x) { if (n[x.sev] != null) n[x.sev]++; });
    var ic = { erreur: '⛔', alerte: '⚠️', info: 'ℹ️' };
    return R(L.length + ' point(s) à vérifier : ' + n.erreur + ' erreur(s), ' + n.alerte + ' alerte(s), ' + n.info + ' information(s).\n' +
      L.slice(0, 6).map(function (x) { return (ic[x.sev] || '•') + ' ' + x.msg; }).join('\n') + (L.length > 6 ? '\n… et ' + (L.length - 6) + ' autre(s) sur l’écran d’accueil.' : '') +
      '\nCe sont des avertissements : la décision reste à vous (rien n’est supprimé ni fusionné).', [{ type: 'goto', tab: 'dashboard' }]);
  }

  /* 2) orthographe des fiches */
  var FIELDS = [
    ['exb_participants', 'Participants', ['training', 'note', 'address', 'job', 'profession']],
    ['exb_trainers', 'Formateurs', ['specialty', 'note']],
    ['exb_clients', 'Clients', ['company', 'address', 'note']],
    ['exb_projects', 'Projets', ['name', 'location', 'note', 'description']],
    ['exb_hr', 'Personnel', ['role', 'note']],
    ['exb_quotes', 'Devis', ['project', 'object', 'note']]
  ];
  function ortho() {
    var S = w.EXB_SPELL; if (!S || !S.check) return R('Le correcteur n’est pas chargé sur cet écran.');
    var found = [], seen = {}, scanned = 0;
    FIELDS.forEach(function (F) {
      jlist(F[0]).slice(0, 3000).forEach(function (rec) {
        F[2].forEach(function (f) {
          var v = rec[f]; if (typeof v !== 'string' || v.length < 4) return;
          scanned++;
          S.check(v, { sureOnly: true }).forEach(function (x) {
            var k = F[1] + '|' + x.w.toLowerCase() + '|' + x.rep; if (seen[k]) return; seen[k] = 1;
            found.push(F[1] + ' › ' + (pName(rec) || rec.title || rec.id || '?') + ' : « ' + x.w + ' » → « ' + x.rep + ' »');
          });
        });
      });
    });
    if (!found.length) return R('✅ Aucune faute sûre repérée dans les textes libres de cet appareil (' + scanned + ' champs lus). Les noms propres ne sont pas vérifiés.');
    return R(found.length + ' faute(s) sûre(s) repérée(s) (' + scanned + ' champs lus) :\n' + found.slice(0, 10).map(function (x) { return '• ' + x; }).join('\n') + (found.length > 10 ? '\n… et ' + (found.length - 10) + ' autre(s).' : '') +
      '\nJe ne modifie rien : ouvrez la fiche, puis clic droit › « Corriger l’orthographe du champ ». Les noms propres ne sont pas vérifiés.');
  }

  /* 3) participants par formation */
  function parTraining(P) { var m = {}; P.forEach(function (p) { var t = String(p.training || '').trim() || '(sans formation)'; var k = norm(t); (m[k] = m[k] || { t: t, n: 0, names: [] }).n++; m[k].names.push(pName(p) || p.participant_id || '?'); }); return Object.keys(m).map(function (k) { return m[k]; }).sort(function (a, b) { return b.n - a.n; }); }
  function formations(q) {
    var P = jlist('exb_participants'); if (!P.length) return R('Aucun participant enregistré sur cet appareil.');
    var tm = q.match(/(?:inscrits?|participants?|apprenants?|eleves?|stagiaires?)\s+(?:a|au|aux|en|de|dans|pour|sur)\s+(?:la |le |l.|les )?(?:formation\s+)?(?:de |d.|en |du |des |sur )?([a-z0-9+#.\- ]{2,40})$/) ||
      q.match(/(?:formation|cours|session|filiere)\s+(?:de |d.|en |du |des |sur )?([a-z0-9+#.\- ]{2,40})$/);
    var term = tm ? tm[1].replace(/\b(svp|stp|merci|s il (?:te|vous) plait)\b/g, '').replace(/^(?:la |le |l.|les )/, '').trim() : '';
    if (term && !/^(chaque|toutes?|les|des)$/.test(term)) {
      var ws = term.split(' ').filter(function (x) { return x.length >= 2; });
      var hit = ws.length ? P.filter(function (p) { var t = norm(p.training); return ws.every(function (x) { return t.indexOf(x) >= 0; }); }) : [];
      if (!hit.length) return R('Je ne trouve aucun participant inscrit à « ' + term + ' ». Dites « répartition par formation » pour voir toutes les formations.');
      return R(hit.length + ' participant(s) pour « ' + term + ' » :\n' + hit.slice(0, 12).map(function (p) { return '• ' + (pName(p) || '?') + (p.matricule ? ' — ' + p.matricule : '') + (p.approval_status && p.approval_status !== 'APPROUVE' ? ' (en attente)' : ''); }).join('\n') + (hit.length > 12 ? '\n… et ' + (hit.length - 12) + ' autre(s).' : '') + '\n(chiffres de cet appareil)', [{ type: 'goto', tab: 'participants' }]);
    }
    var G = parTraining(P);
    return R('Participants par formation (' + P.length + ' au total) :\n' + G.slice(0, 10).map(function (g) { return '• ' + g.t + ' : ' + g.n; }).join('\n') + (G.length > 10 ? '\n… et ' + (G.length - 10) + ' autre(s) formation(s).' : '') + '\n(chiffres de cet appareil)', [{ type: 'goto', tab: 'participants' }]);
  }

  /* 4) impayés (d'après les reçus) */
  var PAID = /^pay[eé]/i, NOTP = /^non/i;
  function unpaidSt(st) { st = String(st == null ? '' : st).trim(); return !!st && (NOTP.test(st) || !PAID.test(st)); }
  function unpaidList() { /* [{name, training, receipt_no, parts:[{what, fee}]}] */
    var out = [];
    jlist('exb_receipts').forEach(function (r) {
      if (/^(ANNUL|SUPPR|INVALID)/i.test(String(r.status || ''))) return;
      var parts = [];
      if (unpaidSt(r.registration_status)) parts.push({ what: 'inscription', fee: r.registration_fee });
      if (unpaidSt(r.training_status)) parts.push({ what: 'formation', fee: r.training_fee });
      if (parts.length) out.push({ name: String(r.participant || '').trim(), training: String(r.training || '').trim(), receipt_no: r.receipt_no, parts: parts });
    });
    return out;
  }
  function impayes() {
    var Rr = jlist('exb_receipts'); if (!Rr.length) return R('Aucun reçu enregistré sur cet appareil : je ne peux pas dire qui n’a pas payé.');
    var U = unpaidList();
    if (!U.length) return R('✅ Tous les reçus enregistrés sur cet appareil sont marqués payés (' + Rr.length + ' reçu(s) vérifié(s)).');
    var bad = U.map(function (u) { return '• ' + (u.name || '?') + (u.training ? ' — ' + u.training : '') + ' : ' + u.parts.map(function (p) { return p.what + ' non payée' + (p.fee ? ' (' + p.fee + ')' : ''); }).join(', ') + (u.receipt_no ? ' [' + u.receipt_no + ']' : ''); });
    return R(U.length + ' reçu(s) avec un paiement en attente (sur ' + Rr.length + ') :\n' + bad.slice(0, 10).join('\n') + (bad.length > 10 ? '\n… et ' + (bad.length - 10) + ' autre(s).' : '') +
      '\nD’après l’état « payé / non payé » saisi sur les reçus ; un participant sans reçu n’apparaît pas ici. Dites « relance les impayés » pour des messages de rappel prêts à copier.');
  }
  function phoneOf(name) { /* téléphone de la fiche participant correspondante (même nom, quel que soit l'ordre) */
    var k = norm(name).split(' ').sort().join(' '), ph = '';
    jlist('exb_participants').forEach(function (p) { if (!ph && p.phone && norm(pName(p)).split(' ').sort().join(' ') === k) ph = p.phone; });
    return ph;
  }
  function msgFor(u) {
    var what = u.parts.map(function (p) { return (p.what === 'inscription' ? 'l’inscription' : 'la formation') + (p.fee ? ' (' + p.fee + ')' : ''); }).join(' et ');
    return 'Bonjour ' + (u.name || '') + ', nous vous rappelons gentiment que le paiement de ' + what + (u.training ? ' pour « ' + u.training + ' »' : '') + ' est en attente. Merci de régulariser dès que possible ou de nous contacter pour convenir d’un arrangement. Cordialement, Excellencia Building.';
  }
  function relance(q, raw) {
    var Rr = jlist('exb_receipts'); if (!Rr.length) return R('Aucun reçu enregistré sur cet appareil : je ne peux pas préparer de relance.');
    var U = unpaidList();
    if (!U.length) return R('✅ Aucun paiement en attente d’après les reçus : rien à relancer.');
    var tm = q.match(/\b(?:relance\w*|rappelle\w*|rappeler)\s+(?:a\s+|au\s+|le\s+|la\s+|l.\s*)?(?:participant\s+|apprenant\s+|client\s+)?([a-z][a-z .\-]{2,40})$/), term = tm ? tm[1].replace(/\b(svp|stp|merci)\b/g, '').trim() : '';
    var one = term && !/^(les|des|tous|toutes|tout le monde|ceux|celles|impaye|impayes|paiements?|paiement|les impayes)/.test(term) && !/\b(impaye\w*|paiements?|retards?)\b/.test(term);
    var list = U, head;
    if (one) {
      var ws = term.split(' ').filter(function (x) { return x.length >= 2; });
      list = U.filter(function (u) { var toks = norm(u.name).split(' '); return ws.every(function (q1) { return toks.some(function (t) { return tokDist(q1, t, ws.length >= 2) >= 0; }); }); });
      if (!list.length) return R('Je ne trouve aucun paiement en attente pour « ' + title(term) + ' » d’après les reçus. Dites « qui n’a pas payé ? » pour voir la liste.');
      head = 'Relance pour « ' + title(term) + ' » :';
    } else head = list.length + ' relance(s) à envoyer :';
    var shown = list.slice(0, 15).map(function (u) { var ph = phoneOf(u.name); return '👤 ' + (u.name || '?') + (ph ? ' — ' + ph : ' — (téléphone non trouvé)') + '\n' + msgFor(u); });
    return R(head + '\n\n' + shown.join('\n\n') + (list.length > 15 ? '\n\n… et ' + (list.length - 15) + ' autre(s) : dites « relance » suivi du nom pour un message précis.' : '') +
      '\n\nCopiez le message pour WhatsApp ou SMS : je n’envoie rien moi-même.');
  }

  function run(raw, q) {
    q = q || norm(raw);
    if (NOHOW.test(q)) return null;
    if (/\b(doublons?|en double|homonymes?|inscrit\w* (?:deux|2) fois)\b/.test(q)) return doublons();
    if (/\b(orthograph\w*|fautes?)\b/.test(q) && /\b(verifi\w*|controle\w*|cherche\w*|detecte\w*|relis\w*|repere\w*|corrige\w*|y a.?t.?il|analyse\w*)\b/.test(q)) return ortho();
    if (/\b(relance\w*|rappel\w*|rappelle\w*)\b/.test(q) && (/\b(impaye\w*|non paye\w*|pas (?:encore )?paye\w*|paiements?|dettes?|retards?)\b/.test(q) || /\b(?:relance\w*|rappelle\w*)\s+(?:a\s+|au\s+|le\s+|la\s+|l.\s*)?(?:participant\s+|apprenant\s+|client\s+)?[a-z]{3,}/.test(q)) && !(/\b(message|modele|texte|sms|mail|whatsapp)\b/.test(q) && !/\bimpaye\w*/.test(q)) && !/^(?:relance\w*|rappelle\w*)\s+(?:un|une|moi|nous|demain|plus tard|dans)\b/.test(q)) return relance(q, raw);
    if (/\b(impaye\w*|non paye\w*|pas (?:encore )?paye\w*|ont pas paye|nont pas paye|doivent (?:encore )?(?:payer|de l.?argent)|reste\w* a payer|dettes?)\b/.test(q)) return impayes();
    if (/\b(repartition|par formation)\b/.test(q) || (/\b(liste\w*|montre\w*|affiche\w*|donne\w*|qui (?:est|sont))\b/.test(q) && /\b(inscrits?|participants?|apprenants?|eleves?|stagiaires?)\b/.test(q) && /\b(formation|cours|session|inscrits? (?:a|au|aux|en)|participants? (?:a|au|aux|en)|apprenants? (?:a|au|aux|en))\b/.test(q))) return formations(q);
    return null;
  }
  w.EXB_ASSIST_PLUS = { run: run, fuzzy: fuzzy, version: 'V99-assistant-plus-3' };
})(window);
