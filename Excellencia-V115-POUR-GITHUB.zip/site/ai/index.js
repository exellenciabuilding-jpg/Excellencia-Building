(function(w){'use strict';w.EXB_AI={version:'V97-Enterprise',modules:['copilot','previsions','analyse','reporting']};})(window);
