EXCELLENCIA BUILDING V73 — CHANTIER OFFLINE AVANCÉ

Fonctions :
- travail terrain sans réseau ;
- file locale d'opérations ;
- états pending / synced / conflict ;
- synchronisation au retour du réseau ;
- journal de chantier ;
- HSE ;
- RFI ;
- réserves ;
- pointage ;
- panneau de suivi de synchronisation.

Migration Supabase : voir README-V75
