# V112 — Les mises à jour en arrière-plan ne ferment plus l'application

**Cause** : `exb-sync.js` rechargeait la page automatiquement 1,5 s après chaque réception de données du serveur
(synchro toutes les 60 s, au retour sur l'application, à la reconnexion). Sur un deuxième appareil, l'application
« se fermait » donc en plein travail.

**Correctif** : plus de rechargement forcé. Une bannière « Nouvelles données reçues — Actualiser / Plus tard » s'affiche.
Le rechargement automatique n'a lieu que si l'utilisateur est inactif depuis 3 minutes, sans champ actif ni fenêtre ouverte.
`sw.js` : nouvelle version de cache pour que le correctif soit pris en compte.

Non modifiés : verrouillage automatique après inactivité (sécurité), restaurations/imports (rechargement voulu).
Pas de nouveau SQL.
