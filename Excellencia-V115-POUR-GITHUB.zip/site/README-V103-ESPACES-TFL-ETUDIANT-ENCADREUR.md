# V103 — Espaces TFL étudiant et encadreur (nouvelle présentation)

`tfl-portail.html` reprend la présentation des maquettes `espace-etudiant-tfl.html` et `espace-encadreur.html` :
menu latéral (tiroir sur téléphone, fixe sur grand écran), tableau de bord avec cartes de synthèse,
thème clair/sombre automatique. Les liens courts ne changent pas : `/tfl-etudiant` et `/tfl-encadreur`.

## Branché sur les vraies données (aucun SQL à ajouter)
- Connexion, 1re connexion avec changement de mot de passe, blocage après 5 essais, fermeture après 20 min : inchangés.
- **Étudiant** : tableau de bord, mon sujet (statut, motif, validation université et encadreur), mon encadreur
  (WhatsApp / appel), avancement en 9 étapes + historique, messagerie avec l'administration, plans, profil.
- **Encadreur** : tableau de bord (étudiants, avis à donner, avancement moyen), liste des étudiants avec
  valider / à corriger / refuser, commentaires, progression proposée, message à l'administration, mes sujets, profil.

## Non repris des maquettes (le serveur n'a pas encore les tables)
Frais TFL et bordereaux de paiement, envoi de documents, demande d'encadreur par l'étudiant,
proposition de sujet ou de plan depuis le portail, messagerie directe étudiant ↔ encadreur.
Ils étaient simulés (données fictives) : les afficher aurait montré de fausses informations.
Chacun demande une migration SQL + son écran d'administration ; à faire un par un.

## Déploiement
Remplacer les fichiers `tfl-portail.html` et `sw.js` (cache renouvelé), redéployer sur Netlify, ouvrir une fois en ligne.
Retour en arrière : restaurer ces deux fichiers de V102.
