/* Envoi des formulaires publics vers Supabase. Aucune donnée secrète ici (clé publique + règles RLS). */
window.EXBForm=(function(){
  function cfg(){var c=window.EXB_SUPABASE||{};return c.url&&c.key?c:null}
  function shrink(file){
    return new Promise(function(ok,ko){
      var url=URL.createObjectURL(file),im=new Image();
      im.onload=function(){
        var r=Math.min(420/im.naturalWidth,560/im.naturalHeight,1),c=document.createElement('canvas');
        c.width=Math.max(1,Math.round(im.naturalWidth*r));c.height=Math.max(1,Math.round(im.naturalHeight*r));
        var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
        URL.revokeObjectURL(url);c.toBlob(function(b){b?ok(b):ko(new Error('conversion'))},'image/jpeg',0.8)
      };
      im.onerror=function(){URL.revokeObjectURL(url);ko(new Error('lecture'))};
      im.src=url
    })
  }
  function dataUrl(b){return new Promise(function(ok,ko){var r=new FileReader();r.onload=function(){ok(r.result)};r.onerror=function(){ko(new Error('Lecture de la photo impossible.'))};r.readAsDataURL(b)})}
  /* kind : 'logiciel' (table demandes_logiciel) | 'apprenant' (table inscriptions) | 'tp_td' | 'formateur' | 'client' | 'personnel' (table formulaires) */
  var ERR={trop_de_demandes:'Le service est momentanément saturé. Réessayez plus tard.',photo_trop_lourde:'Photo trop lourde. Choisissez une image plus petite.',nom_invalide:'Nom invalide.',telephone_invalide:'Numéro de téléphone invalide.',formation_invalide:'Choisissez une formation.',email_invalide:'E-mail invalide.',centre_invalide:'Nom du centre invalide.',donnees_trop_longues:'Texte trop long. Raccourcissez votre message.',lien_invalide:'Ce lien n’est plus valide. Demandez un nouveau lien au centre.'};
  async function send(kind,data,file){
    var c=cfg();if(!c)throw new Error('Le service d’envoi n’est pas encore configuré.');
    var photo=null;
    if(file){
      var blob;try{blob=await shrink(file)}catch(e){throw new Error('Photo illisible. Essayez une autre image ou envoyez sans photo.')}
      photo=await dataUrl(blob);
      if(photo.length>390000)throw new Error('Photo trop lourde. Choisissez une image plus petite.')
    }
    var h={apikey:c.key,'Content-Type':'application/json'};
    if(/^eyJ/.test(c.key))h.Authorization='Bearer '+c.key;
    var path,body;
    if(kind==='logiciel'){path='/rest/v1/rpc/demande_logiciel_envoyer';body={p_data:data}}
    else if(kind==='projet'){path='/rest/v1/rpc/demande_projet_envoyer';body={p_data:data}}
    else if(kind==='apprenant'){path='/rest/v1/rpc/inscription_envoyer';body={p_name:data.name,p_phone:data.phone,p_email:data.email||null,p_training:data.training,p_note:data.note||null,p_photo:photo}}
    else{path='/rest/v1/rpc/formulaire_envoyer';body={p_kind:kind,p_data:data,p_photo:photo}}
    var cen=(location.search.match(/[?&]c=([0-9a-fA-F-]{36})/)||[])[1];
    if(cen&&kind!=='logiciel'&&kind!=='projet'){path+='_centre';body.p_centre=cen}
    var r=await fetch(c.url.replace(/\/+$/,'')+path,{method:'POST',headers:h,body:JSON.stringify(body)});
    if(!r.ok){var m='';try{var j=await r.json();m=j&&j.message||''}catch(e){}
      throw new Error(ERR[m]||('Envoi impossible (code '+r.status+(m?' : '+m:'')+'). Réessayez.'))}
    try{return await r.json()}catch(e){return {ok:true}}
  }

  /* ---- Fiche PDF (sans bibliothèque) : A4, Helvetica, accents WinAnsi ---- */
  var WIN={8217:146,8216:145,8220:147,8221:148,8211:150,8212:151,8364:128,339:156,338:140,8230:133,8226:149,160:32};
  function pe(t){
    var o='';t=String(t==null?'':t);
    for(var i=0;i<t.length;i++){
      var c=t.charCodeAt(i);
      if(c===10||c===13){o+=' ';continue}
      if(WIN[c])c=WIN[c];else if(c>255)c=63;
      if(c===40||c===41||c===92)o+='\\'+String.fromCharCode(c);
      else if(c<32)o+=' ';
      else if(c>126)o+='\\'+('00'+c.toString(8)).slice(-3);
      else o+=String.fromCharCode(c)
    }
    return o
  }
  function wrap(t,max){
    var out=[];String(t==null?'':t).split(/\r?\n/).forEach(function(par){
      var w=par.split(/\s+/),l='';
      w.forEach(function(x){
        while(x.length>max){if(l){out.push(l);l=''}out.push(x.slice(0,max));x=x.slice(max)}
        if((l+' '+x).trim().length>max){out.push(l);l=x}else l=(l+' '+x).trim()
      });
      out.push(l)
    });
    return out
  }

  /* V99j — mise en page professionnelle de la fiche / du reçu d'inscription (partagée par pdfBuild et pdfBlobAsync) */
  function drawFiche(o,logo,photo,IM,sig,qr,vi){
    var W=595,H=842,M=40,ops=[],NAVY='0.09 0.21 0.40',GOLD='0.79 0.64 0.15',GREY='0.40 0.43 0.49',LINE='0.84 0.87 0.92',SOFT='0.95 0.97 0.99';
    function T(txt,x,yy,sz,bold,rgb){ops.push((rgb||'0.10 0.12 0.18')+' rg BT /'+(bold?'F2':'F1')+' '+sz+' Tf '+x+' '+yy+' Td ('+pe(txt)+') Tj ET')}
    function TR(txt,xr,yy,sz,bold,rgb){var w=String(txt).length*sz*(bold?.56:.5);T(txt,xr-w,yy,sz,bold,rgb)}
    function R(x,yy,w,h,rgb){ops.push(rgb+' rg '+x+' '+yy+' '+w+' '+h+' re f')}
    function RS(x,yy,w,h,rgb,lw){ops.push(rgb+' RG '+(lw||.8)+' w '+x+' '+yy+' '+w+' '+h+' re S')}
    function D(k,x,yy,w,h){ops.push('q '+w+' 0 0 '+h+' '+x+' '+yy+' cm /I'+k+' Do Q')}
    /* en-tête */
    R(0,H-110,W,110,NAVY);R(0,H-114,W,4,GOLD);
    var tx=M;
    if(logo>=0){R(M,H-98,84,84,'1 1 1');var lg=IM[logo],lw=76,lh=lw*lg.h/lg.w;if(lh>76){lh=76;lw=lh*lg.w/lg.h}D(logo,M+(84-lw)/2,H-98+(84-lh)/2,lw,lh);tx=M+102}
    T('EXCELLENCIA BUILDING',tx,H-50,25,true,'1 1 1');
    T(o.titre||'',tx,H-76,12.5,true,'0.95 0.82 0.40');
    if(o.sousTitre)T(o.sousTitre,tx,H-95,9.5,false,'0.80 0.86 0.95');
    var y=H-114-26;
    /* carte matricule (+ photo) */
    var PW=96,PH=124,QW=100,hasPh=photo>=0,hasQr=qr>=0,cardH=hasPh?PH:(hasQr?122:96),cardW=W-2*M-(hasPh?PW+18:0)-(hasQr?QW+14:0),narrow=hasPh&&hasQr;
    if(o.matricule){
      R(M,y-cardH,cardW,cardH,SOFT);R(M,y-cardH,6,cardH,NAVY);RS(M,y-cardH,cardW,cardH,LINE);
      T('NUMÉRO MATRICULE',M+22,y-26,9,true,GREY);
      var mf=hasPh?(narrow&&String(o.matricule).length>16?21:26):32;
      T(o.matricule,M+22,y-(hasPh||hasQr?cardH/2+8:60),mf,true,NAVY);
      T(narrow?'À conserver : paiement, épreuves, résultats.':'À conserver : il sert pour le paiement, les épreuves et les résultats.',M+22,y-cardH+16,8.5,false,GREY)
    }
    if(hasQr){
      var qx=M+cardW+14;
      R(qx,y-QW,QW,QW,'1 1 1');RS(qx,y-QW,QW,QW,LINE,1);D(qr,qx+5,y-QW+5,QW-10,QW-10);
      T('SCANNER POUR VÉRIFIER',qx+4,y-QW-12,6.8,true,NAVY)
    }
    if(hasPh){
      var px=W-M-PW,im=IM[photo],w=PW,h=PW*im.h/im.w;if(h>PH){h=PH;w=h*im.w/im.h}
      RS(px-3,y-PH-3,PW+6,PH+6,NAVY,1.6);D(photo,px+(PW-w)/2,y-PH+(PH-h)/2,w,h)
    }
    y-=cardH+26;
    /* tableau des informations */
    T('INFORMATIONS',M,y,10,true,NAVY);R(M+84,y+3,W-2*M-84,1.2,GOLD);y-=12;
    var LW=150,VX=M+LW+12,VW=W-M-VX-8,rows=o.lignes||[],ry=y,k=0;
    rows.forEach(function(r){
      var L=wrap(r[1]==null||r[1]===''?'—':String(r[1]),Math.floor(VW/5.6)).slice(0,6),rh=Math.max(30,L.length*15+14);
      if(ry-rh<150)return;
      R(M,ry-rh,W-2*M,rh,k%2?'0.985 0.99 1':'1 1 1');R(M,ry-rh,LW,rh,SOFT);
      RS(M,ry-rh,W-2*M,rh,LINE,.6);
      ops.push(LINE+' RG .6 w '+(M+LW)+' '+(ry-rh)+' m '+(M+LW)+' '+ry+' l S');
      var lab=wrap(String(r[0]).toUpperCase(),26);T(lab[0],M+10,ry-rh/2-3+(lab.length>1?5:0),8.5,true,NAVY);if(lab[1])T(lab[1],M+10,ry-rh/2-3-5,8.5,true,NAVY);
      L.forEach(function(l,i){T(l,VX,ry-19-i*15,11,false)});
      ry-=rh;k++
    });
    y=ry-22;
    /* à retenir */
    var nn=(o.notes||[]).map(function(n){return wrap(n,96)}),nh=nn.reduce(function(a,L){return a+L.length*12.5+5},0);
    if(nn.length&&y-nh-34>178){
      R(M,y-nh-30,W-2*M,nh+30,'0.995 0.975 0.90');R(M,y-nh-30,5,nh+30,GOLD);
      T('À RETENIR',M+18,y-18,9.5,true,'0.55 0.40 0.03');var ny=y-34;
      nn.forEach(function(L){L.forEach(function(l){T(l,M+18,ny,9.5,false,'0.25 0.25 0.25');ny-=12.5});ny-=5})
    }
    /* zone de signature */
    (function(){var cw=(W-2*M-30)/2,yb=150;
      T('SIGNATURE DE L’APPRENANT / DU DEMANDEUR',M,yb+6,8,true,NAVY);T('CACHET ET VISA EXCELLENCIA BUILDING',M+cw+30,yb+6,8,true,NAVY);
      RS(M,yb-84,cw,84,LINE);RS(M+cw+30,yb-84,cw,84,LINE);
      try{var dgn=window.EXBId&&EXBId.get().dg;if(dgn)T(String(dgn).slice(0,46),M+cw+30,yb-96,8,false,GREY)}catch(e){}
      if(sig>=0){var im=IM[sig],w=cw-24,h=w*im.h/im.w;if(h>70){h=70;w=h*im.w/im.h}D(sig,M+(cw-w)/2,yb-84+(84-h)/2,w,h)}
      if(vi>=0&&IM[vi]){var iv=IM[vi],w2=cw-20,h2=w2*iv.h/iv.w;if(h2>76){h2=76;w2=h2*iv.w/iv.h}D(vi,M+cw+30+(cw-w2)/2,yb-84+(84-h2)/2,w2,h2)}else T('À valider par l’administration',M+cw+30+cw/2-62,yb-46,8.5,false,GREY)})();
    /* pied de page */
    R(0,0,W,6,NAVY);R(M,52,W-2*M,.8,LINE);
    T(o.pied||'Excellencia Building',M,36,8.5,false,GREY);
    TR('Document généré automatiquement',W-M,36,8.5,false,GREY);
    return ops.join('\n')
  }
  /* o = {titre, sousTitre, matricule, lignes:[[libelle,valeur],...], notes:[texte,...], pied} -> chaîne PDF (ASCII) */
  function pdfBuild(o){
    var W=595,H=842,content0=drawFiche(o,-1,-1,[],-1);
    var content=content0,objs=[];
    objs[1]='<< /Type /Catalog /Pages 2 0 R >>';
    objs[2]='<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
    objs[3]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>';
    objs[4]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    objs[5]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    objs[6]='<< /Length '+content.length+' >>\nstream\n'+content+'\nendstream';
    var out='%PDF-1.4\n',off=[0];
    for(var i=1;i<=6;i++){off[i]=out.length;out+=i+' 0 obj\n'+objs[i]+'\nendobj\n'}
    var xr=out.length;out+='xref\n0 7\n0000000000 65535 f \n';
    for(i=1;i<=6;i++)out+=('0000000000'+off[i]).slice(-10)+' 00000 n \n';
    out+='trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF';
    return out
  }
  function pdfBlob(o){return new Blob([pdfBuild(o)],{type:'application/pdf'})}
  /* ---- Fiche avec LOGO + PHOTO de l'apprenant (images JPEG intégrées) ---- */
  function loadJpg(src,maxW,q){return new Promise(function(ok,ko){
    var im=new Image();im.onload=function(){
      var r=Math.min(maxW/im.naturalWidth,1),c=document.createElement('canvas');
      c.width=Math.max(1,Math.round(im.naturalWidth*r));c.height=Math.max(1,Math.round(im.naturalHeight*r));
      var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
      var d=c.toDataURL('image/jpeg',q||.85),b=atob(d.split(',')[1]),u=new Uint8Array(b.length);
      for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);ok({u:u,w:c.width,h:c.height})};
    im.onerror=function(){ko(new Error('image'))};im.src=src})}
  function fileToDataUrl(f){return new Promise(function(ok,ko){var r=new FileReader();r.onload=function(){ok(r.result)};r.onerror=function(){ko(new Error('lecture'))};r.readAsDataURL(f)})}
  function bytesOf(s){var u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i)&255;return u}
  /* V99zzzzzzzzzzzzzz — pages d'annexe : texte long (problématique, objectifs, méthodologie…) réparti sur autant de pages que nécessaire.
     o.sections = [[titre, texte], ...] ; o.titreAnnexe = intitulé de l'en-tête (défaut « ANNEXE — CONTENU DU SUJET »). Retourne un tableau de contenus de pages. */
  function annexePages(o,logo,IM){
    var W=595,H=842,M=44,NAVY='0.09 0.21 0.40',GOLD='0.79 0.64 0.15',GREY='0.40 0.43 0.49',LINE='0.84 0.87 0.92',LH=13.5,TOP=H-98,BOT=64;
    var items=[];
    (o.sections||[]).forEach(function(sec){
      var txt=String(sec[1]==null?'':sec[1]).trim();
      items.push({h:String(sec[0]||'')});
      wrap(txt||'—',92).forEach(function(l){items.push({p:l})});
      items.push({gap:1})
    });
    var pages=[],ops,y;
    function T(txt,x,yy,sz,bold,rgb){ops.push((rgb||'0.10 0.12 0.18')+' rg BT /'+(bold?'F2':'F1')+' '+sz+' Tf '+x+' '+yy+' Td ('+pe(txt)+') Tj ET')}
    function R(x,yy,w,h,rgb){ops.push(rgb+' rg '+x+' '+yy+' '+w+' '+h+' re f')}
    function nouvelle(){
      ops=[];pages.push(ops);
      R(0,H-70,W,70,NAVY);R(0,H-74,W,4,GOLD);
      var tx=M;
      if(logo>=0){var lg=IM[logo],lw=46,lh=lw*lg.h/lg.w;if(lh>46){lh=46;lw=lh*lg.w/lg.h}ops.push('q '+lw+' 0 0 '+lh+' '+M+' '+(H-58)+' cm /I'+logo+' Do Q');tx=M+60}
      T('EXCELLENCIA BUILDING',tx,H-34,15,true,'1 1 1');
      T(o.titreAnnexe||'ANNEXE — CONTENU DU SUJET',tx,H-52,9.5,true,'0.95 0.82 0.40');
      if(o.sousTitre)T(String(o.sousTitre).slice(0,60),W-M-String(o.sousTitre).slice(0,60).length*5,H-52,9,false,'0.80 0.86 0.95');
      y=TOP
    }
    nouvelle();
    items.forEach(function(it){
      if(it.h){
        if(y-LH*3<BOT)nouvelle();
        T(it.h.toUpperCase(),M,y,10.5,true,NAVY);R(M,y-5,W-2*M,1.1,GOLD);y-=LH+8
      }else if(it.p!==undefined){
        if(y<BOT)nouvelle();
        T(it.p,M+4,y,10,false);y-=LH
      }else y-=8
    });
    pages.forEach(function(pg,k){
      ops=pg;R(0,0,W,6,NAVY);ops.push(LINE+' rg '+M+' 52 '+(W-2*M)+' .8 re f');
      T(o.pied||'Excellencia Building',M,36,8.5,false,GREY);
      var tp='Page '+(k+2)+' / '+(pages.length+1);T(tp,W-M-tp.length*4.4,36,8.5,false,GREY)
    });
    return pages.map(function(pg){return pg.join('\n')})
  }
  /* o = {titre, sousTitre, matricule, lignes, notes, pied, photo:(File|dataURL|null), logo:'icon-192.png', sections:[[titre,texte],...]} -> Promise<Blob> */
  async function pdfBlobAsync(o){
    var W=595,H=842,M=44,ops=[],y,IM=[],logo=-1,photo=-1,sg=-1;
    try{IM.push(await loadJpg(o.logo||'icon-192.png',256,.9));logo=IM.length-1}catch(e){}
    if(o.photo){try{var src=typeof o.photo==='string'?o.photo:await fileToDataUrl(o.photo);IM.push(await loadJpg(src,600,.85));photo=IM.length-1}catch(e){}}
    if(o.signature){try{IM.push(await loadJpg(o.signature,500,.9));sg=IM.length-1}catch(e){}}
    var qrI=-1;if(o.qr){try{IM.push(await loadJpg(o.qr,300,.95));qrI=IM.length-1}catch(e){}}
    /* visa de l'administrateur (signature + cachet enregistrés sur cet appareil) : posé automatiquement, sauf si o.visa===false */
    var vi=-1;if(o.visa!==false&&window.EXBSign){try{var vu=await (EXBSign.anyVisa?EXBSign.anyVisa('jpg'):(EXBSign.active&&EXBSign.active()?EXBSign.visa('jpg'):''));if(vu){IM.push(await loadJpg(vu,520,.92));vi=IM.length-1}}catch(e){}}
    ops=[drawFiche(o,logo,photo,IM,sg,qrI,vi)];
    var ann=(o.sections&&o.sections.length)?annexePages(o,logo,IM):[];
    var content=bytesOf(ops.join('\n')),ch=[],pos=0,off=[];
    function P(x){var u=typeof x==='string'?bytesOf(x):x;ch.push(u);pos+=u.length}
    function O(n,head,stream){off[n]=pos;P(n+' 0 obj\n'+head);if(stream){P('\nstream\n');P(stream);P('\nendstream')}P('\nendobj\n')}
    var n=IM.length,N=6+n,NN=N+2*ann.length,xo=IM.map(function(m,k){return '/I'+k+' '+(6+k)+' 0 R'}).join(' ');
    P('%PDF-1.4\n');
    O(1,'<< /Type /Catalog /Pages 2 0 R >>');
    O(2,'<< /Type /Pages /Kids [3 0 R'+ann.map(function(a,k){return ' '+(N+1+2*k)+' 0 R'}).join('')+'] /Count '+(1+ann.length)+' >>');
    O(3,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> /XObject << '+xo+' >> >> /Contents '+N+' 0 R >>');
    O(4,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    O(5,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    IM.forEach(function(m,k){O(6+k,'<< /Type /XObject /Subtype /Image /Width '+m.w+' /Height '+m.h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+m.u.length+' >>',m.u)});
    O(N,'<< /Length '+content.length+' >>',content);
    ann.forEach(function(txt,k){
      var cb=bytesOf(txt);
      O(N+1+2*k,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> /XObject << '+xo+' >> >> /Contents '+(N+2+2*k)+' 0 R >>');
      O(N+2+2*k,'<< /Length '+cb.length+' >>',cb)
    });
    var xr=pos,x='xref\n0 '+(NN+1)+'\n0000000000 65535 f \n';
    for(var j=1;j<=NN;j++)x+=('0000000000'+off[j]).slice(-10)+' 00000 n \n';
    P(x+'trailer\n<< /Size '+(NN+1)+' /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF');
    return new Blob(ch,{type:'application/pdf'})
  }
  function download(blob,name){
    var u=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(u);a.remove()},4000)
  }
  return {send:send,shrink:shrink,pdfBuild:pdfBuild,pdfBlob:pdfBlob,pdfBlobAsync:pdfBlobAsync,download:download}
})();
