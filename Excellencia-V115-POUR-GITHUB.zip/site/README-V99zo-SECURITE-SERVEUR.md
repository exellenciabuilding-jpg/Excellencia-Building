# V99zo — Audit des politiques de sécurité (RLS) et corrections côté serveur

## Méthode
Les 28 migrations ont été chargées dans l'ordre sur un **vrai PostgreSQL 16** (avec une imitation de l'authentification Supabase), puis auditées : catalogue (RLS, politiques, droits des fonctions) et **20 tests d'attaque** (`tools/test-rls/run.sh`) avec 5 comptes : 2 entreprises, administrateur, éditeur polyvalent, lecteur, comptable, anonyme.

## Ce qui était bon
- Les 47 tables ont la RLS activée (99 politiques). Les 40 tables rattachées à une entreprise filtrent toutes par appartenance à l'entreprise : aucune lecture ni écriture entre entreprises, aucune montée de privilège (un éditeur ne peut pas se promouvoir administrateur, ni s'ajouter à une autre entreprise, ni déplacer une ligne vers une autre entreprise).
- Le stockage (documents, photos) est isolé par dossier d'entreprise.
- Les 4 tables sans politique (assistant_usage, exb_doc_registry, collections_sensibles, plateforme_proprietaires) sont volontairement fermées : seules des fonctions y accèdent.

## 3 failles trouvées et corrigées (`supabase/migration-v99zo-securite-serveur.sql`)
| Gravité | Faille | Correction |
|---|---|---|
| Haute | **Licence non appliquée à l'écriture** : une entreprise suspendue, résiliée ou échue depuis des mois continuait à écrire (seule l'adhésion de nouveaux membres était bloquée). | `enregistrer()` et toutes les tables dédiées refusent l'écriture si licence suspendue / résiliée / échue depuis plus de 7 jours (même tolérance que pour rejoindre). La **lecture reste possible** (export, sauvegarde). L'application affiche « Licence suspendue ou expirée… (lecture seule) ». Une entreprise sans ligne de licence n'est pas touchée. |
| Haute | **Appel anonyme de `exb_generer_recurrences`** : sans connexion (clé publique seule), on pouvait lancer la génération pour TOUTES les entreprises (le cas « auth.uid() nul = pg_cron » le permettait). | Fonction retirée au rôle anonyme + refus explicite des appels anonymes ; pg_cron et la clé de service continuent de fonctionner. |
| Moyenne | **Déclaration publique de paiement** limitée à 5 par numéro : contournable en changeant de numéro. | Plafond global de 300 déclarations par heure. |
Aussi : les fonctions d'API qui exigent une connexion (enregistrer, mon_organisation, créer / rejoindre / renouveler, notifications) ne sont plus exécutables par le rôle anonyme. Restent ouvertes volontairement : vérification de documents, dépôt d'inscription / copie / paiement, et les fonctions d'aide aux politiques.

## Mise en service
1. Sauvegarde Supabase, puis exécuter `supabase/migration-v99zo-securite-serveur.sql` **après** `migration-v99zn-synchro-modules.sql`. Réexécutable.
2. **Ordre des migrations** (constat de l'audit) : `migration-v99v-securite-licences.sql` doit passer **avant** `migration-v99w-equipe.sql` (celle-ci utilise la table des licences ; sinon erreur « type licences_clients does not exist »).
3. Déployer les fichiers (cache `exb-v99zo-securite-serveur-1`).
4. Essai : suspendre une licence d'essai (`select owner_maj_licence('<id>','suspendu')`), vérifier qu'un membre voit « lecture seule », puis la réactiver.

## Reste à faire / recommandations (non couvert)
- **Double authentification (2FA)** : toujours absente ; c'est un réglage Supabase (Authentication › MFA) + un écran d'activation dans le logiciel. Prochain chantier de sécurité.
- **Boutique vitrine** : l'écriture dans le stockage « vitrine » est réservée à une adresse e-mail codée en dur ; vérifier que la **confirmation d'e-mail est obligatoire** dans Supabase Auth, sinon quelqu'un pourrait s'inscrire avec cette adresse.
- **Code d'invitation** de 8 caractères hexadécimaux, sans limite d'essais côté base : s'appuyer sur la limitation de débit de Supabase Auth ; envisager un code plus long.
- `droits_fonction` (matrice des droits) est lisible par tout utilisateur connecté (nécessaire au fonctionnement ; pas de donnée d'entreprise).
- Les tests tournent sur PostgreSQL avec une **imitation** de l'authentification Supabase : à confirmer sur un projet Supabase de recette (en particulier `auth.role()` dans la protection des récurrences, et le message de licence dans l'application).
