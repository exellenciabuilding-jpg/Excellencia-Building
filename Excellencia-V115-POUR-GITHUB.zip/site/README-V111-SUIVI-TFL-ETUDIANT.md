# V111 — Espace étudiant TFL : suivi complet, dans la charte bleu #173565 + doré #d8a43c

Ajouté sur la base V110i (rien d'existant retiré : frais TFL, documents, échanges, propositions, demande d'encadreur).
- **Tableau de bord** : chapitres validés, prochain rendez-vous / défense, 2 dernières actualités, tuiles « Mon planning » et « Ma carte d'étudiant ».
- **Avancement** : liste des **chapitres** (statut, échéance, corrections à faire/faites) avant les 9 étapes.
- **Mon planning** : défense (date, lieu, jury), **rendez-vous**, échéances de chapitres (retards en rouge), « Ajouter à mon agenda » (.ics).
- **Actualités** : dossier, avis encadreur, validation université, corrections, retards, rendez-vous, documents, décisions, administration. Pastille = ce qui demande une action.
- **Ma carte d'étudiant** (PNG avec QR `verification.html?m=matricule`, charte bleu/doré) ; **Mon profil** : université, faculté, filière, promotion, niveau, année académique ; photo (reste dans la page jusqu'à la déconnexion, jamais enregistrée).
- Bouton ↻ en haut, actualisation auto après 5 min, bandeau « Hors connexion » (les données déjà chargées restent affichées), notifications discrètes.
- `exb-tfl.js` (snapEtudiant) publie en plus : université, faculté, filière, promotion, niveau, année académique, chapitres + corrections, rendez-vous, défense (jamais notes internes, téléphone, e-mail). **Aucun SQL.** **Republier les portails (📡)** pour que les étudiants voient ces pages.
- Sécurité inchangée : aucun stockage navigateur (contrôle V99zzt), mot de passe en mémoire, fermeture après 20 min. « Garder ma connexion » et mode hors ligne persistant non repris pour cette raison.
- Fichiers : `tfl-portail.html`, `exb-tfl.js`, `sw.js`. Contrôles : check.js 505/505 ; test-bloc1..5 et test-portail OK ; Chromium 390 px (serveur simulé).
