# TFL — bloc 2/5 : proposition de sujet ou de plan depuis le portail

**Étudiant** (Espace TFL › Mon sujet, dossier accepté ou en vérification) : deux formulaires repliables.
- *Proposer un nouveau sujet* : titre, problématique, objectifs (obligatoires), méthodologie et raison du changement (facultatives).
- *Proposer un plan de travail* : plan libre (introduction, chapitres, conclusion…) + note facultative.
Une seule proposition « en étude » par genre. L'état de chaque proposition est visible : Envoyée → En cours d'étude par l'administration → Retenue / Refusée / Complément demandé (avec le motif). Après une décision, il peut proposer de nouveau (10 propositions au plus par genre). Le plan retenu s'affiche dans « Mon sujet ». Raccourci aussi sur le tableau de bord.

**Administration** (logiciel › TFL) :
1. 📡 *Publier* les portails, puis 📥 *Récupérer les messages reçus* : la proposition apparaît dans le dossier (💬 Messages des portails) avec tous ses champs.
2. Trois boutons : **Retenir**, **Demander un complément**, **Refuser** (motif obligatoire pour les deux derniers, visible par l'étudiant).
   - *Retenir un sujet* : il REMPLACE le sujet du dossier (titre, problématique, objectifs, méthodologie) ; le sujet repasse « À étudier », la validation de l'université et celle de l'encadreur sont remises à zéro, un sujet exclusif du catalogue éventuellement réservé est libéré. Le statut du dossier et l'encadreur ne changent pas. L'encadreur voit « Le sujet a été remplacé à la demande de l'étudiant : votre avis est demandé ».
   - *Retenir un plan* : il est enregistré dans le dossier (champ « Plan de travail ») et visible par l'étudiant et son encadreur.
3. Puis 📡 *Publier* : l'étudiant voit la décision. Rien ne change dans le dossier tant que l'administration n'a pas cliqué.
L'historique du dossier garde la trace (« Sujet remplacé », « Plan de travail mis à jour »).

**À exécuter une fois :** `supabase/migration-tfl-bloc2-proposition-sujet-plan.sql` (après migration-v99zzt-tfl-portails.sql et migration-tfl-bloc1-demande-encadreur.sql). Réexécutable. Contrôle : `select proname from pg_proc where proname='tfl_portail_proposition';` → 1 ligne.

**Fichiers modifiés :** `tfl-portail.html`, `exb-tfl.js`, `sw.js`. Tests : `node tools/test-tfl/test-bloc2.js` (le faux navigateur de `test-portail.js` reçoit aussi `document.body`).
**Limites :** serveur simulé uniquement (SQL non exécuté sur un vrai Supabase) : faire un essai avec un dossier fictif accepté. Les anciens tests `test-portail.js` et `test-suivi.js` avaient déjà des échecs avant ce bloc (libellés de l'ancien « Code encadreur », tableau de suivi) : non liés.
