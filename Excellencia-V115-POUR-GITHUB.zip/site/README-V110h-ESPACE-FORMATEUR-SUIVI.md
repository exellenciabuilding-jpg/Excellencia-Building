# V110h — Espace formateur complet (présences, suivi, rapports, messagerie)

## Ce que le formateur fait dans son espace (`espace-formateur.html`, lien `/espace-formateur`)
Connexion par matricule + mot de passe (1234 à changer à la première connexion, comme avant). Menu :
- **Tableau de bord** : prochaine séance, nombre d'appels à faire, actions rapides.
- **Mes formations / Mon calendrier / Mes apprenants / Mes honoraires / Sujets** : inchangés.
- **📋 Présences** : liste des séances (à venir et passées) ; pour chaque séance, appel des apprenants de la formation (Présent / Absent / Retard / Excusé, « Tous présents »), enregistré aussitôt.
- **📈 Suivi des apprenants** : par apprenant, module, note /20, progression %, observation ; historique et total des présences.
- **📓 Rapports de séance** : séance tenue ou non, contenu dispensé, observations, durée réelle.
- **💬 Messages à l'administration** : messages enregistrés sur le serveur avec les réponses de l'administration (WhatsApp reste proposé en secours).

## Ce que l'administration fait (onglet Formateurs › « 📥 Retours des formateurs »)
- **Récupérer et lire les retours** : présences par séance (absents nommés), notes et progressions, rapports, messages ; bouton **↩ Répondre**.
- Les retours sont conservés sur l'appareil (clé `exb_formateur_retours`). Ils ne sont PAS (encore) injectés automatiquement dans les modules Présences / Évaluations du logiciel.
- Le planning et la liste d'apprenants du formateur viennent de **📢 Publier l'espace formateur** : republier après chaque changement d'horaire ou d'inscrit.

## À faire UNE fois
1. Supabase › SQL Editor : exécuter `supabase/migration-v110h-espace-formateur-suivi.sql` (après la v103).
2. Contrôle : `select proname from pg_proc where proname like 'formateur_retour%' or proname = 'formateur_repondre';` → 5 lignes.
3. Déployer le ZIP, ouvrir le logiciel deux fois, republier l'espace formateur, reconstruire l'APK.

## Limites (à lire)
- Le script SQL n'a PAS été exécuté sur un vrai Supabase. Il suppose que `resultats_publies` a les colonnes `matricule`, `session`, `donnees` et que `_exb_n` existe (comme dans la v103). Faire un essai avec un formateur fictif avant ouverture.
- Les présences et notes ne sont acceptées que pour les apprenants publiés pour CE formateur.
- Pas de notification automatique d'un changement d'horaire : le formateur voit le nouveau planning à la republication.
- Les séances sont identifiées par formation + date + heure + module : si l'administration modifie l'un de ces champs, une nouvelle ligne de présence/rapport est créée.
Retour en arrière : restaurer `espace-formateur.html`, `index.html`, `sw.js` ; côté serveur `drop table public.formateur_retours cascade;`.

## Interconnexion (V110i)
« Récupérer et lire les retours » (et « 🔁 Reprendre dans Présences / Évaluations ») verse automatiquement dans le logiciel :
- **Présences formateur → Présence** (`exb_attendance`) : PRESENT / ABSENT / RETARD (Excusé = ABSENT avec le champ `excuse`). Une ligne par date et participant ; la saisie du formateur remplace une saisie manuelle du même jour.
- **Notes → Évaluations** (`exb_evaluations`) : type « Évaluation », note sur 20, matière = module, commentaire = progression % + observation. Pas de note = pas d'évaluation.
- **Rapports → Planning** (`exb_schedules`) : séance marquée TENUE / NON_TENUE avec rapport, observations et durée réelle (mêmes date + formation + module).
- Reprise **sans doublon** (relancer ne duplique rien). Les apprenants dont le matricule ne correspond à aucun participant sont comptés et ignorés.
Limite : les champs ajoutés au planning (statut, rapport) ne sont pas encore affichés dans l'écran Planning ; ils servent aux rapports et sauvegardes.
