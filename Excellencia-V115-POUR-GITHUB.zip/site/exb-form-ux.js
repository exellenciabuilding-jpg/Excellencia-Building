/* exb-form-ux.js — Formulaires publics (inscription, demandes, TFL) :
 * 1) la photo et la signature sont affichées juste sous le nom (plus enfouies tout en bas du formulaire) ;
 * 2) le nom est validé tout de suite, pendant la saisie (✔ valide / message d'erreur), et bloque l'envoi s'il est invalide. */
(function () {
  'use strict';
  var d = document;
  var NAMES = [['a_name', 1], ['f_name', 1], ['p_name', 1], ['l_name', 1], ['b_name', 1], ['nom', 1], ['c_first', 0], ['c_last', 0]];
  var WORD = /^[\p{L}][\p{L}'’.\-]*$/u;
  function $(i) { return d.getElementById(i); }
  function visible(e) { return !!e && (e.offsetParent !== null || e.getClientRects().length > 0); }

  function judge(v, full) {
    v = String(v || '').trim().replace(/\s+/g, ' ');
    if (!v) return { ok: null, msg: '' };
    var w = v.split(' ');
    if (!w.every(function (x) { return WORD.test(x); })) return { ok: false, msg: 'Le nom ne doit contenir que des lettres (pas de chiffres ni de symboles).' };
    if (v.replace(/[^\p{L}]/gu, '').length < 2) return { ok: false, msg: 'Nom trop court.' };
    if (full && w.length < 2) return { ok: false, msg: 'Indiquez votre nom ET votre prénom.' };
    return { ok: true, msg: '✔ Nom valide' };
  }
  function wireName(id, full) {
    var inp = $(id); if (!inp || inp.dataset.nv) return;
    inp.dataset.nv = '1';
    var h = d.createElement('div'); h.className = 'exb-nv'; h.setAttribute('aria-live', 'polite'); h.style.cssText = 'font-size:12.5px;min-height:16px;margin-top:3px';
    inp.parentNode.insertBefore(h, inp.nextSibling);
    function upd(show) {
      var r = judge(inp.value, full);
      inp.setCustomValidity(r.ok === false ? r.msg : '');
      if (r.ok === null) { h.textContent = ''; return; }
      if (r.ok === false && !show) { h.textContent = ''; return; }
      h.textContent = r.msg; h.style.color = r.ok ? '#15803d' : '#b42318';
      inp.style.borderColor = r.ok ? '#15803d' : '#b42318';
    }
    inp.addEventListener('input', function () { upd(inp.value.trim().length > 2); });
    inp.addEventListener('blur', function () { upd(true); });
    inp._exbNv = function () { upd(true); return judge(inp.value, full).ok !== false; };
  }

  function topChild(el) { var a = el; while (a.parentElement && a.parentElement.tagName !== 'FIELDSET' && a.parentElement.tagName !== 'FORM') a = a.parentElement; return a; }
  function activeName() {
    var ids = ['a_name', 'f_name', 'p_name', 'l_name', 'b_name', 'c_last', 'nom'];
    for (var i = 0; i < ids.length; i++) { var e = $(ids[i]); if (visible(e)) return e; }
    return null;
  }
  /* pages TFL : regroupe le bloc « Photo » et le bloc « Signature » pour pouvoir les déplacer */
  function tflBlocks() {
    var f = $('f'); if (!f || $('photoBox') || $('sigBox')) return [];
    var out = [];
    if (!$('exbPhoto2')) {
      var lab = [].slice.call(f.querySelectorAll('label')).filter(function (l) { return /^Photo/i.test(l.textContent.trim()); })[0];
      if (lab && lab.nextElementSibling && lab.nextElementSibling.classList.contains('photo')) {
        var w = d.createElement('div'); w.id = 'exbPhoto2'; lab.parentNode.insertBefore(w, lab); w.appendChild(lab); w.appendChild(w.nextElementSibling); out.push(w);
      }
    } else out.push($('exbPhoto2'));
    if (!$('exbSig2')) {
      var h2 = [].slice.call(f.querySelectorAll('h2')).filter(function (h) { return /^Signature/i.test(h.textContent.trim()); })[0];
      if (h2) {
        var s = d.createElement('div'); s.id = 'exbSig2'; h2.parentNode.insertBefore(s, h2);
        var n = h2; while (n && n.id !== 'online' && n.id !== 'send') { var nx = n.nextElementSibling; s.appendChild(n); n = nx; }
        var t = s.querySelector('h2'); if (t) { t.style.marginTop = '10px'; t.textContent = '✍️ Signature'; }
        out.push(s);
      }
    } else out.push($('exbSig2'));
    return out;
  }
  function place() {
    var inp = activeName(); if (!inp) return;
    var blocks = [$('photoBox'), $('sigBox')].filter(Boolean);
    if (!blocks.length) blocks = tflBlocks();
    if (!blocks.length) return;
    var anchor = topChild(inp), ref = anchor;
    if (anchor === inp && inp.nextElementSibling && inp.nextElementSibling.classList.contains('exb-nv')) anchor = ref = inp.nextElementSibling;
    if (anchor.nextElementSibling === blocks[0] && (!blocks[1] || blocks[0].nextElementSibling === blocks[1])) return;
    blocks.forEach(function (b) { ref.parentNode.insertBefore(b, ref.nextSibling); ref = b; });
    /* le rang du champ suivant ne doit pas coller au bloc */
    blocks.forEach(function (b) { if (!b.dataset.exbSp) { b.dataset.exbSp = '1'; b.style.marginTop = '8px'; b.style.marginBottom = '4px'; } });
  }
  function init() {
    NAMES.forEach(function (n) { wireName(n[0], !!n[1]); });
    place();
    /* formulaires TFL : l'envoi se fait par boutons → on bloque aussi si le nom est invalide */
    ['online', 'send'].forEach(function (id) {
      var b = $(id); if (!b || b.dataset.nvb) return; b.dataset.nvb = '1';
      b.addEventListener('click', function (e) {
        var n = $('nom'); if (n && n._exbNv && !n._exbNv()) { e.preventDefault(); e.stopImmediatePropagation(); n.scrollIntoView({ behavior: 'smooth', block: 'center' }); try { n.focus(); } catch (x) {} }
      }, true);
    });
  }
  function boot() {
    init();
    var f = $('f'); if (!f) return;
    var t = null;
    new MutationObserver(function () { clearTimeout(t); t = setTimeout(init, 120); }).observe(f, { attributes: true, attributeFilter: ['hidden', 'style', 'class'], subtree: true, childList: true });
    setTimeout(init, 400); setTimeout(init, 1500);
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})();
