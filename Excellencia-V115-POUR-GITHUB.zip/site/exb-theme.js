/* Excellencia Building V99u — thème clair / sombre.
 * - Bouton soleil/lune dans la barre du haut (créé par exb-v99r-shell.js, id « xbTheme »).
 * - Le choix est mémorisé sur l'appareil (localStorage « exb_theme ») et appliqué avant l'affichage (voir <head> d'index.html).
 * - Le thème sombre ne s'applique qu'à l'écran : l'impression et les PDF restent toujours clairs
 *   (@media screen + passage temporaire en clair pendant la capture PDF). Les documents (.paper : certificats, reçus,
 *   affiches) gardent leurs couleurs d'origine.
 * AUCUNE donnée ni fonction existante n'est modifiée : le thème sombre est une simple feuille de style. */
(function(w,d){'use strict';
var KEY='exb_theme',root=d.documentElement;
var SUN='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.4M12 19.1v2.4M2.5 12h2.4M19.1 12h2.4M5.3 5.3l1.7 1.7M17 17l1.7 1.7M5.3 18.7L7 17M17 7l1.7-1.7"/></svg>';
var MOON='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.5 14.2A8.5 8.5 0 0 1 9.8 3.5a8.5 8.5 0 1 0 10.7 10.7z"/></svg>';

/* ---------- Palette ---------- */
var BG='#0d1424',S1='#151f33',S2='#1b2740',S3='#22314d',LN='#2a3a58',TX='#e4e9f3',TX2='#cdd8ef',MU='#9fb0cf',AC='#6ea8ff',ACB='#2f6fdb';
var H='html[data-exb-theme="dark"]';
/* éléments qui doivent rester tels quels (documents imprimables, logos, connexion) */
var X=':not(.paper *):not(.paperP *):not(.loginwrap *):not(#exbLicLock *):not(.logo-preview *):not(.softwarePosterPaper *):not(.tpPaper *)';

function R(sels,decl){return (Array.isArray(sels)?sels:[sels]).map(function(s){return H+' '+s}).join(',')+'{'+decl+'}'}
var SHORT={'#fff':1,'white':1,'#111':1,'#222':1,'#333':1,'#555':1,'#667':1,'#777':1,'#888':1};
function attr(prop,hexes,extra){var out=[],e=extra||'';
 hexes.forEach(function(h){var props=prop==='bg'?['background:','background-color:']:['color:'];
  props.forEach(function(p){var k='[style*="'+p+h;
   if(SHORT[h]){[';',' ','!'].forEach(function(t){out.push(k+t+'" i]'+e)});out.push('[style$="'+p+h+'" i]'+e)}
   else out.push(k+'" i]'+e)})});return out}
function RA(prop,hexes,decl,extra){return attr(prop,hexes,extra).map(function(s){return H+' '+s+X}).join(',')+'{'+decl+'}'}

function buildCss(){
var c=[];
c.push('@media screen{');
c.push(H+'{color-scheme:dark}');
c.push(R(['body','#app'],'background:'+BG+';color:'+TX));
c.push(R('#app>header','background:#0a1220;box-shadow:0 2px 14px #0009;border-bottom:1px solid #16233d'));
c.push(R('#app>header .exb-pro-search','background:transparent'));
c.push(R('#app>header .exb-pro-search input','background:#0f1829;color:'+TX+';border:1px solid '+LN));
c.push(R('#app>header .exb-pro-search input::placeholder','color:#7f90b3'));
c.push(R('.exb-search-results','background:'+S1+';color:'+TX+';border:1px solid '+LN));
c.push(R('.exb-search-item','border-color:'+LN));
c.push(R('.exb-search-item:hover','background:'+S2));
c.push(R('.exb-search-type','color:'+MU));
/* menu latéral */
c.push(R('#exbSide','background:#101a2e;border-right-color:'+LN));
c.push(R('#exbSide .xs','color:'+TX2));
c.push(R('#exbSide .xs:hover','background:'+S2));
c.push(R('#exbSide .xs.on','background:#1f3a6b;color:#a9caff'));
c.push(R('#exbSide .xs span.ch','color:#6f82a8'));
c.push(R('.xsf','border-color:'+LN+';color:'+MU));
c.push(R('.xsf b','color:'+TX));
c.push(R('#exbStatus','background:#101a2e;border-top-color:'+LN+';color:'+MU));
c.push(R('#exbStatus b','color:'+TX2));
/* fil d'Ariane, barre des modules, pages catégorie */
c.push(R('#exbCrumb','color:'+MU));
c.push(R('#exbCrumb button','background:#1f3a6b;color:#a9caff'));
c.push(R('#exbModBar .mb','background:'+S1+';border-color:'+LN+';color:'+TX2));
c.push(R('#exbModBar .mb:hover','border-color:'+AC+';color:'+AC));
c.push(R('#exbModBar .mb.on','background:'+ACB+';border-color:'+ACB+';color:#fff;box-shadow:0 4px 14px #2f6fdb55'));
c.push(R('#exbModBar .mb-ar','background:'+S1+';border-color:'+LN+';color:'+TX2+';box-shadow:0 2px 10px #0008'));
c.push(R(['.xh','#exbHub','.xh-head h1','#exbHub h1'],'color:'+TX));
c.push(R(['.xh-crumb','.xh-head p','#exbHub p','.xh-k small','.xh-k em','.xh-card small','.xh-empty','.xh-act small','.xh-act time','.xg .c small','.xh-qa .q small'],'color:'+MU));
c.push(R(['.xh-date','.xh-card','.xh-k','.xg .c','.xh-qa .q'],'background:'+S1+';border-color:'+LN+';color:'+TX+';box-shadow:0 4px 18px #0006'));
c.push(R(['.xg .c:hover','.xh-k:hover','.xh-qa .q:hover'],'border-color:'+AC+';box-shadow:0 8px 22px #0008'));
c.push(R(['.xh-card h3','.xh-k b','.xg .c b','.xh-qa .q b','.xh-act b'],'color:'+TX));
c.push(R(['.xh-card h3 a','.xh-k small a'],'color:'+AC));
c.push(R('.xh-lg','background:'+S2));
c.push(R('.xh-act','border-color:'+LN));
c.push(R('.xh-act .ci','background:#1f3a6b'));
c.push(R('.xh-chart svg text','fill:'+MU));
c.push(R('.xh-hero','background:#0a1630;box-shadow:0 10px 28px #0007'));
c.push(R('.xh-hl','background:linear-gradient(90deg,#0a1630e6 0%,#0a1630b3 38%,#0a163000 72%)'));
c.push(R('.xm-b','background:'+S1+';color:'+TX));
c.push(R('.xm-x','background:'+S3+';color:'+TX));
c.push(R('.xm-g button','background:'+S1+';border-color:'+LN));
c.push(R('.xm-r button','background:#1f3a6b;color:#a9caff'));
c.push(R('.xmenu','background:'+S1+';color:'+TX+';border:1px solid '+LN+';box-shadow:0 14px 36px #000a'));
c.push(R('.xmenu button','color:'+TX));
c.push(R('.xmenu button:hover','background:'+S2));
/* cartes, formulaires, tableaux */
c.push(R(['.card','.enterprise-card','.exb-doc-card','.exb-v51-kpi','.exb-big-kpi','.exb-v51-client','.exb92-kpi','.profile-panel','.stat','.exbHybrid .modeCard','.exb-enterprise-group','.exb-enterprise-item','.exb93-pay-grid div','.exb94-grid div','.exb92-flow div'],
  'background:'+S1+';border-color:'+LN+';color:'+TX+';box-shadow:0 4px 18px #0005'));
c.push(R(['.logo-box','.bulkbox','.filebox','.tpMeta','.exb-flow','.exb-enterprise-flow','.exb94-flow','.exb-v51-tabs','.exbHybrid','.exbHybrid .onlineState','.exb-progress','.preview'],'background:'+S2+';border-color:'+LN+';color:'+TX));
c.push(R(['.exb-enterprise-item:hover','.exb-doc-row:hover'],'background:'+S3));
c.push(R('.exb-v51-tabs button','background:'+S3+';color:'+TX2));
c.push(R('.exb-v51-tabs button.active,.exb-v51-tabs .active','background:'+ACB+';color:#fff'));
c.push(R(['h1'+X,'h2'+X,'h3'+X,'h4'+X,'.enterprise-card h3','.enterprise-kpi','.count','.exb-v51-kpi b','.exb-big-kpi b','.stat b','.exbHybrid h2','.exbHybrid h3','.exbHybrid .modeCard strong'],'color:#eef3ff'));
c.push(R(['label'+X,'.exbHybrid .badge'],'color:'+TX2));
c.push(R(['.hint','.enterprise-muted','.exb-v51-kpi span','.msg'],'color:'+MU));
c.push(R(['input'+X,'textarea'+X,'select'+X],'background:#0f1829;color:'+TX+';border-color:#33466a'));
c.push(R(['input'+X+'::placeholder','textarea'+X+'::placeholder'],'color:#7384a8'));
c.push(R(['input:focus'+X,'textarea:focus'+X,'select:focus'+X],'outline:2px solid '+AC+'55;border-color:'+AC));
c.push(R('select option','background:'+S1+';color:'+TX));
c.push(R('input[type=checkbox],input[type=radio]','accent-color:'+ACB));
c.push(R(['table'+X,'.tbl','.enterprise-table'],'color:'+TX));
c.push(R(['th'+X,'.tbl th','.enterprise-table th','.exbHybrid .responseTable th'],'background:'+S2+';color:#cfdaf2;border-color:'+LN));
c.push(R(['td'+X,'.tbl td','.enterprise-table td','.exbHybrid .responseTable td'],'border-color:'+LN));
c.push(R('.tbl tr:hover td','background:#1a2640'));
c.push(R('hr','border-color:'+LN));
/* boutons */
c.push(R('.muted','background:'+S3+';color:'+TX2));
c.push(R('.primary','background:'+ACB+';color:#fff'));
c.push(R('.primary:hover','background:#4382ee'));
c.push(R(['.pill','.tag'],'background:#1f3a6b;color:#cfe0ff'));
c.push(R(['.tag.ok','.badge-ok','.ok','.paid','.valid','.success-soft'],'background:#14301f;border-color:#235b38;color:#6ee7a0'));
c.push(R(['.tag.warn','.warn','.warnbox','.warning-soft'],'background:#3a3016;border-color:#6b5a1f;color:#fbd34d'));
c.push(R(['.tag.off','.badge-no','.unpaid','.danger-soft','.ann'],'background:#3a1d20;border-color:#6b2a2e;color:#ff9a9a'));
c.push(R('.tabs button','background:'+S3+';color:'+TX2));
c.push(R('.tabs .active','background:'+ACB+';color:#fff'));
var MODS=['#exbV67','#exbV68','#exbV69','#exbPlansV70','#exb_v71_plans','#exb_v72_print'];
c.push(R(MODS.map(function(i){return i+' button:not([class])'}),'background:'+S3+';color:'+TX2));
c.push(R(MODS.map(function(i){return i+' th,'+H+' '+i+' td'}),'border-color:'+LN+';color:'+TX));
/* styles en ligne : fonds clairs -> surfaces sombres */
var WHITE=['#fff','white','#ffffff'],
 SOFT=['#f8fafc','#f7f9fc','#f1f5fb','#f4f6f9','#f1f5f9','#f2f5fa','#eef2f7','#f5f7fa','#f4f4f4','#f3f6fc','#eef3fb','#eef1f6','#fafcff','#f5f9ff','#f3f6fa','#f9fafb','#f6f8fb','#fbfdff','#f0f4f9','#eff3f8'],
 BLUE=['#e8edf5','#e3edfd','#dce4f0','#e7edf6','#edf3fb','#eaf0fb','#dbeafe','#e0ecff','#e8f0fe','#dfe4ec','#eef2f6'],
 RED=['#fde8e8','#fee2e2','#fff1f0','#fef2f2','#fff1f2','#fff5f5'],
 YEL=['#fff7e6','#fff7e0','#fff4d6','#fef9c3','#fffbe6','#fffbeb','#fff8e1','#fef3c7','#fff7ed'],
 GRN=['#dcfce7','#ecfdf3','#effaf3','#f0fdf4','#e7f7ee'];
var MEDIA=':not(img):not(canvas):not(svg):not(:has(>img,>canvas,>svg))';
c.push(RA('bg',WHITE,'background:'+S1+'!important;color:'+TX+';border-color:'+LN,MEDIA));
c.push(RA('bg',SOFT,'background:'+S2+'!important;color:'+TX+';border-color:'+LN,':not(img):not(canvas):not(svg)'));
c.push(RA('bg',BLUE,'background:#1f3a6b!important;color:#cfe0ff',':not(img):not(canvas):not(svg)'));
c.push(RA('bg',RED,'background:#3a1d20!important;color:#ffb4b4;border-color:#6b2a2e',':not(img):not(canvas):not(svg)'));
c.push(RA('bg',YEL,'background:#3a3016!important;color:#fbd34d;border-color:#6b5a1f',':not(img):not(canvas):not(svg)'));
c.push(RA('bg',GRN,'background:#14301f!important;color:#8df0b4;border-color:#235b38',':not(img):not(canvas):not(svg)'));
c.push(RA('bg',['#173565','#0a3a86','#002451'],'background:#2a5db8!important',':not(img):not(canvas):not(svg)'));
/* conteneurs blancs qui portent une image / un QR : ils restent blancs, leur texte reste foncé */
c.push(['background:','background-color:'].map(function(p){return WHITE.map(function(h){return H+' [style*="'+p+h+'" i]:has(>img,>canvas,>svg), '+H+' [style*="'+p+h+'" i]:has(>img,>canvas,>svg) *'}).join(',')}).join(',')+'{color:#172033!important}');
/* styles en ligne : textes foncés -> textes clairs */
c.push(RA('tx',['#172033','#12254a','#173565','#111','#111827','#202633','#334155','#344054','#1e293b','#0f172a','#1f2937','#222','#333'],'color:'+TX+'!important'));
c.push(RA('tx',['#64748b','#667085','#6b7a99','#475569','#5e6877','#555','#7b8494','#98a2b3','#6b7280','#667','#777','#888'],'color:'+MU+'!important'));
c.push(RA('tx',['#b91c1c','#a52323','#b00020','#991b1b','#b42318','#c0392b','#a92323','#dc2626'],'color:#ff9a9a!important'));
c.push(RA('tx',['#b45309','#92400e','#a16207'],'color:#fbd34d!important'));
c.push(RA('tx',['#166534','#15803d','#18733b','#027a48','#17702d','#047857'],'color:#6ee7a0!important'));
c.push(RA('tx',['#1f6feb','#0a3a86','#1d4ed8'],'color:'+AC+'!important'));
c.push('}'); /* fin @media screen */
return c.join('\n')}

/* ---------- Logique ---------- */
function stored(){try{return w.localStorage.getItem(KEY)}catch(e){return null}}
function save(v){try{w.localStorage.setItem(KEY,v)}catch(e){}}
function current(){return root.getAttribute('data-exb-theme')==='dark'?'dark':'light'}
function refresh(){var b=d.getElementById('xbTheme');if(!b)return;var dk=current()==='dark';
 b.innerHTML=dk?SUN:MOON;b.title=dk?'Passer au thème clair':'Passer au thème sombre';b.setAttribute('aria-label',b.title);b.setAttribute('aria-pressed',dk?'true':'false')}
function meta(t){var m=d.querySelector('meta[name="theme-color"]');if(!m){m=d.createElement('meta');m.name='theme-color';d.head.appendChild(m)}m.content=t==='dark'?'#0a1220':'#0f2e66'}
function apply(t,animate){
 if(animate){root.classList.add('exb-theme-anim');clearTimeout(apply.t);apply.t=setTimeout(function(){root.classList.remove('exb-theme-anim')},400)}
 if(t==='dark')root.setAttribute('data-exb-theme','dark');else root.setAttribute('data-exb-theme','light');
 meta(t);refresh();
 try{w.dispatchEvent(new CustomEvent('exb-theme',{detail:{theme:t}}))}catch(e){}}
function set(t){if(t!=='dark')t='light';save(t);apply(t,true)}
function toggle(){set(current()==='dark'?'light':'dark')}

/* Les exports PDF (capture de l'écran) se font toujours en clair, puis le thème choisi est remis */
function wrapPdf(){var f=w.html2canvas;if(typeof f!=='function'||f.__exbLight)return;
 var n=function(){var self=this,args=arguments,dk=current()==='dark';
  if(!dk)return f.apply(self,args);
  root.setAttribute('data-exb-theme','light');
  var back=function(){root.setAttribute('data-exb-theme','dark')};
  try{var p=f.apply(self,args);return Promise.resolve(p).then(function(r){back();return r},function(e){back();throw e})}
  catch(e){back();throw e}};
 n.__exbLight=true;w.html2canvas=n}

function init(){
 var st=document.getElementById('exbThemeCss');if(!st){st=d.createElement('style');st.id='exbThemeCss';
  st.textContent=buildCss()+'\n@media screen{html.exb-theme-anim,html.exb-theme-anim *{transition:background-color .25s ease,color .25s ease,border-color .25s ease!important}}';d.head.appendChild(st)}
 apply(stored()==='dark'?'dark':'light',false);
 wrapPdf();setTimeout(wrapPdf,1500);setTimeout(wrapPdf,5000);
 setTimeout(refresh,400);setTimeout(refresh,1200)}

w.EXB_THEME={toggle:toggle,set:set,get:current,refresh:refresh,version:'V99u'};
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',init);else init();
})(window,document);
