# Excellencia Building — QCM logiciels (banque étendue)

## Banque incluse
- 16 logiciels/matières de construction, architecture, structure, rendu, planification et bureautique.
- 10 questions faciles par thème, soit 160 questions au total.
- Tirage aléatoire sans répétition au sein d’une passation ; l’ordre des propositions est également mélangé.
- Choix de 5 ou 10 questions par passation. Relancer le QCM permet d’obtenir un autre tirage.

## Fonctions
- Correction et note automatiques.
- Affichage de la correction après soumission.
- Historique local des résultats, export CSV et impression du résultat.
- Sélection facultative d’un apprenant et tentative d’ajout à la liste d’évaluations locale existante.

## Données et déploiement
Les résultats QCM sont enregistrés dans le stockage local du navigateur/appareil. Ils ne sont pas automatiquement partagés entre appareils et la synchronisation Supabase n’est pas garantie par ce module seul. Après remplacement des fichiers dans le déploiement, actualiser le site et, si nécessaire, fermer/réouvrir l’application pour charger le nouveau cache.

## Note pédagogique
Ces questions sont des questions d’initiation. Pour les calculs de structure, les résultats de logiciels spécialisés doivent toujours être contrôlés par un professionnel qualifié et selon les normes applicables.


## Évolution — banque QCM à trois niveaux
- Débutant : banque existante de 10 questions par thème.
- Intermédiaire : 5 questions supplémentaires par thème, axées sur la mise en pratique.
- Avancé : 5 questions supplémentaires par thème, axées sur les contrôles, hypothèses et limites.
- 16 thèmes, soit 320 questions au total (160 débutant + 80 intermédiaire + 80 avancé).
- Le niveau est conservé dans l’historique, l’export CSV, l’impression et le libellé de l’évaluation.
- Pour les niveaux intermédiaire et avancé, choisir 5 questions (la banque de ces niveaux contient actuellement 5 questions par thème).
