/* exb-metre.js — V57 : Métré béton armé (Paramètres, Quantité béton, Prix matériaux, Devis, Matériaux ajoutés).
   Méthode de calcul issue du fichier « Metrec 2026 » (© IBWAMPERE NGWALA LOUIS) : les formules du fichier Excel sont reprises telles quelles par un moteur de calcul intégré. */
(function(){
'use strict';
const MODEL={"P":{"E1":"Quantitatif béton armé","H1":"Horaire M.O. par tâche","L1":"Programme d'exécution","D2":"1/","E2":"INFRASTRUCTURE","G2":"بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ.","E3":"(Veuillez entrer les dimensions en cm)","E5":"Radier","E6":"Longueur","F6":12000,"G6":"Largeur :","H6":182,"I6":"Epaisseur :","J6":30,"E8":"Béton de propreté semelles filantes","E9":"Largeur :","F9":0,"G9":"Epaisseur :","H9":0,"I9":"Longueur :","J9":0,"E11":"Semelles filantes","E12":"Largeur :","F12":0,"G12":"Hauteur :","H12":0,"I12":"Longueur :","J12":0,"A14":"Mur de soubassement 15","B14":400,"E14":"Mur de soubassement 20","A15":"Mur de soubassement 20","B15":300,"E15":"Hauteur :","F15":60,"G15":"Longueur :","H15":960,"J15":" ","E17":"Chaînage bas","C18":"© Copyright IBWAMPERE NGWALA LOUIS","E18":"Largeur :","F18":20,"G18":"Hauteur :","H18":20,"I18":"Longueur :","J18":960,"J19":5.78,"E20":"Béton de propreté semelles isolées","E21":"Longueur :","F21":0,"G21":"Largeur :","H21":0,"I21":"Epaisseur :","J21":0,"K21":"Nbre :","L21":8,"E23":"Semelles isolées","E24":"Longueur :","F24":0,"G24":"Largeur :","H24":0,"I24":"Hauteur :","J24":0,"K24":"Nbre :","L24":0,"E26":"Amorces de poteaux","E27":"Longueur :","F27":20,"G27":"Largeur :","H27":20,"I27":"Hauteur :","J27":50,"K27":"Nbre :","L27":["f","L21"],"E29":"Longrines","E30":"Largeur :","F30":30,"G30":"Hauteur :","H30":30,"I30":"Longueur :","J30":30,"K30":"Nbre :","L30":5,"E32":"Amorces de raidisseurs verticaux","E33":"Longueur :","F33":0,"G33":"Largeur :","H33":0,"I33":"Hauteur :","J33":0,"K33":"Nbre :","L33":0,"E35":"Voiles en BA","E36":"Epaisseur :","F36":0,"G36":"Hauteur :","H36":0,"I36":"Longueur :","J36":0,"E38":"Dallage","E39":"Longueur :","F39":500,"G39":"Largeur :","H39":300,"I39":"Epaisseur :","J39":15,"K39":"Nbre :","L39":3,"D41":"2/","E41":"SUPERSTRUCTURE / RDC","E42":"(Veuillez entrer les dimensions en cm)","E44":"Mur en élévation 15","E45":"Hauteur :","F45":300,"G45":"Longueur :","H45":960,"E46":"A déduire :","E47":"(Veuillez entrer les dimensions en cm)","F48":"Long/larg","H48":"Hauteur","J48":"Nombre","E49":"n°1","F49":90,"G49":"X","H49":210,"I49":"X","J49":1,"K49":["f","+J49*H49*F49"],"E50":"n°2","F50":120,"G50":"X","H50":120,"I50":"X","J50":2,"K50":["f","+J50*H50*F50"],"E51":"n°3","F51":0,"G51":"X","H51":0,"I51":"X","J51":0,"K51":["f","+J51*H51*F51"],"C52":"© Copyright IBWAMPERE NGWALA LOUIS","E52":"n°4","F52":0,"G52":"X","H52":0,"I52":"X","J52":0,"K52":["f","+J52*H52*F52"],"E53":"n°5","F53":0,"G53":"X","H53":0,"I53":"X","J53":0,"K53":["f","+J53*H53*F53"],"K54":["f","SUM(K49:K53)*0.0001"],"E55":"Mur en élévation 10","E56":"Hauteur :","G56":"Longueur :","I56":"Nbre :","E57":"A déduire :","E58":"(Veuillez entrer les dimensions en cm)","F59":"Long/larg","H59":"Hauteur","J59":"Nombre","E60":"n°1","G60":"X","I60":"X","K60":["f","+J60*H60*F60"],"E61":"n°2","F61":0,"G61":"X","H61":0,"I61":"X","J61":0,"K61":["f","+J61*H61*F61"],"E62":"n°3","F62":0,"G62":"X","H62":0,"I62":"X","J62":0,"K62":["f","+J62*H62*F62"],"E63":"n°4","F63":0,"G63":"X","H63":0,"I63":"X","J63":0,"K63":["f","+J63*H63*F63"],"E64":"n°5","F64":0,"G64":"X","H64":0,"I64":"X","J64":0,"K64":["f","+J64*H64*F64"],"K65":["f","SUM(K60:K64)*0.0001"],"E66":"Linteaux","E67":"Largeur/ép :","F67":15,"G67":"Hauteur :","H67":20,"I67":"Longueur :","J67":300,"E69":"Claustras","E70":"Hauteur :","F70":0,"G70":"Longueur :","H70":0,"E72":"Chaînage haut","E73":"Largeur :","F73":20,"G73":"Hauteur :","H73":20,"I73":"Longueur :","J73":960,"E75":"Poteaux","E76":"Longueur :","F76":["f","+F27"],"G76":"Largeur :","H76":["f","+H27"],"I76":"Hauteur :","J76":300,"K76":"Nbre :","L76":["f","+L27"],"E78":"Voiles en BA","E79":"Epaisseur :","F79":0,"G79":"Hauteur :","H79":0,"I79":"Longueur :","J79":0,"E81":"Raidisseurs verticaux","E82":"Longueur :","F82":["f","+F33"],"G82":"Largeur :","H82":["f","+H33"],"I82":"Hauteur :","J82":0,"K82":"Nbre :","L82":0,"J83":" ","E84":"Poutres en BA","E85":"Largeur :","F85":20,"G85":"Hauteur :","H85":40,"I85":"Longueur :","J85":960,"K85":"Nbre :","L85":1,"E87":"Escaliers","B88":1,"E88":"Nbre de volée :","F88":2,"H88":"Nbre de marche / voléé :","I88":18,"K88":"Epaisseur de la paillasse :","L88":0,"B89":2,"E90":"Largeur marche :","F90":25,"G90":"Ht marche :","H90":17,"I90":"Giron :","J90":27,"K90":"Jour :","L90":0,"G92":"Epaisseur du palier de repos :","H92":12,"E94":"Hourdis","F94":"Dalle de compression / nervures","E95":"Longueur :","F95":300,"G95":"Largeur :","H95":182,"I95":"Epaisseur :","J95":15,"K95":"Nbre :","L95":1,"D97":"3/","E97":"ETAGE","G98":"PARAMETRE D'ETAGE","G99":"Nombre d'étage :","H99":9,"A101":"avec plancher","G101":"Choisir un type de toiture :","H101":"sans plancher","A102":"sans plancher","B102":2,"E102":"(Veuillez entrer les dimensions en cm)","B103":3,"B104":4,"E104":"Mur en élévation 15","B105":5,"E105":"Hauteur :","G105":"Longueur :","B106":6,"E106":"A déduire :","B107":7,"E107":"(Veuillez entrer les dimensions en cm)","B108":8,"F108":"Long/larg","H108":"Hauteur","J108":"Nombre","B109":9,"E109":"n°1","G109":"X","I109":"X","K109":["f","+J109*H109*F109"],"E110":"n°2","F110":0,"G110":"X","H110":0,"I110":"X","J110":0,"K110":["f","+J110*H110*F110"],"E111":"n°3","F111":0,"G111":"X","H111":0,"I111":"X","J111":0,"K111":["f","+J111*H111*F111"],"E112":"n°4","F112":0,"G112":"X","H112":0,"I112":"X","J112":0,"K112":["f","+J112*H112*F112"],"E113":"n°5","F113":0,"G113":"X","H113":0,"I113":"X","J113":0,"K113":["f","+J113*H113*F113"],"K114":["f","SUM(K109:K113)*0.0001"],"E115":"Mur en élévation 10","E116":"Hauteur :","F116":300,"G116":"Longueur :","H116":400,"J116":1,"C117":"© Copyright IBWAMPERE NGWALA LOUIS","E117":"A déduire :","E118":"(Veuillez entrer les dimensions en cm)","F119":"Long/larg","H119":"Hauteur","J119":"Nombre","E120":"n°1","F120":120,"G120":"X","H120":120,"I120":"X","J120":5,"K120":["f","+J120*H120*F120"],"E121":"n°2","F121":90,"G121":"X","H121":220,"I121":"X","J121":4,"K121":["f","+J121*H121*F121"],"E122":"n°3","F122":0,"G122":"X","H122":0,"I122":"X","J122":0,"K122":["f","+J122*H122*F122"],"E123":"n°4","F123":0,"G123":"X","H123":0,"I123":"X","J123":0,"K123":["f","+J123*H123*F123"],"E124":"n°5","F124":0,"G124":"X","H124":0,"I124":"X","J124":0,"K124":["f","+J124*H124*F124"],"K125":["f","SUM(K120:K124)*0.0001"],"E126":"Linteaux","E127":"Largeur/ép :","F127":15,"G127":"Hauteur :","H127":20,"I127":"Longueur :","J127":300,"E129":"Claustras","E130":"Hauteur :","F130":0,"G130":"Longueur :","H130":0,"E132":"Chaînage haut","E133":"Largeur :","F133":["f","+F73"],"G133":"Hauteur :","H133":20,"I133":"Longueur :","J133":960,"E135":"Poteaux","E136":"Longueur :","F136":["f","F76"],"G136":"Largeur :","H136":20,"I136":"Hauteur :","J136":300,"K136":"Nbre :","L136":8,"E138":"Voiles en BA","E139":"Epaisseur :","F139":0,"G139":"Hauteur :","H139":0,"I139":"Longueur :","J139":0,"E141":"Raidisseurs verticaux","E142":"Longueur :","F142":0,"G142":"Largeur :","H142":["f","H82"],"I142":"Hauteur :","J142":0,"K142":"Nbre :","L142":["f","L82"],"J143":" ","E144":"Poutres en BA","E145":"Largeur :","F145":20,"G145":"Hauteur :","H145":40,"I145":"Longueur :","J145":960,"K145":"Nbre :","L145":1,"E147":"Escaliers","B148":1,"E148":"Nbre de volée :","F148":2,"H148":"Nbre de marche / voléé :","I148":18,"K148":"Epaisseur de la paillasse :","L148":["f","L88"],"B149":2,"E150":"Largeur marche :","F150":25,"G150":"Ht marche :","H150":["f","H90"],"I150":"Giron :","J150":["f","J90"],"K150":"Jour : ","L150":["f","L90"],"G152":"Epaisseur du palier de repos :","H152":["f","H92"],"E154":"Hourdis","F154":"Dalle de compression / nervures","E155":"Longueur :","F155":300,"G155":"Largeur :","H155":182,"I155":"Epaisseur :","J155":15,"K155":"Nbre :","L155":1,"F159":"Auteur :","G159":"IBWAMPERE NGWALA LOUIS","F160":"E-mail :","G160":"louisonibwampere@gmail.com","G161":"République Démocratique du Congo"},"Q":{"B1":"Paramètres","E1":"Horaire M.O. par tâche","H1":"Programme d'exécution","B2":"STATISTIQUES","B3":"INFRASTRUCTURE","B4":"BETON POUR OSSATURE","E4":"AGGLOMERES","I4":"DALLAGE","B5":"Béton pour radier","C5":["f","IF(SUM(D50)>0,SUM(D50),\"\")"],"D5":"m3","F5":"Ciment pour confection","G5":["f","IF(SUM(H106)>0,SUM(H106),\"\")"],"H5":"tonne","J5":"Ciment pour radier","K5":["f","IF(SUM(F50)>0,SUM(F50),\"\")"],"L5":"tonne","B6":"Béton pour dallage","C6":["f","IF(SUM(D60)>0,SUM(D60),\"\")"],"D6":"m3","F6":"Sable pour confection","G6":["f","IF(SUM(J106)>0,SUM(J106),\"\")"],"H6":"m3","J6":"Sable pour radier","K6":["f","IF(SUM(H50)>0,SUM(H50),\"\")"],"L6":"m3","F7":"Ciment pour montage","G7":["f","IF(SUM(H107)>0,SUM(H107),\"\")"],"H7":"tonne","J7":"Gravier pour radier","K7":["f","IF(SUM(J50)>0,SUM(J50),\"\")"],"L7":"tonne","B8":"Mortier pour chape (400 kg/m3)","C8":["f","IF(SUM(D61)>0,SUM(D61),\"\")"],"D8":"m3","F8":"Sable pour montage","G8":["f","IF(SUM(J107)>0,SUM(J107),\"\")"],"H8":"m3","J8":"Fer pour radier","K8":["f","IF(SUM(L50)>0,SUM(L50),\"\")"],"L8":"tonne","F9":"Nombre d'agglos pleins","G9":["f","IF(SUM(F92)>0,SUM(F92),\"\")"],"H9":"unités","J9":"Ciment pour dallage","K9":["f","IF(SUM(F60)>0,SUM(F60),\"\")"],"L9":"tonne","A10":"© Copyright IBWAMPERE NGWALA LOUIS","B10":"Matériaux pour autres ouvrages en béton","J10":"Sable pour dallage","K10":["f","IF(SUM(H60)>0,SUM(H60),\"\")"],"L10":"m3","B11":"Ciment","C11":["f","IF(SUM(F50:F59)>0,SUM(F50:F59),\"\")"],"D11":"tonne","J11":"Gravier pour dallage","K11":["f","IF(SUM(J60)>0,SUM(J60),\"\")"],"L11":"tonne","B12":"Sable","C12":["f","IF(SUM(H50:H59)>0,SUM(H50:H59),\"\")"],"D12":"m3","J12":"Fer pour dallage","K12":["f","IF(SUM(L60)>0,SUM(L60),\"\")"],"L12":"tonne","B13":"Gravier","C13":["f","IF(SUM(J50:J59)>0,SUM(J50:J59),\"\")"],"D13":"tonne","J13":"Ciment pour chape","K13":["f","IF(SUM(F61)>0,SUM(F61),\"\")"],"L13":"tonne","B14":"Fer","C14":["f","IF(SUM(L52:L53,L55:L59)>0,SUM(L52:L53,L55:L59),\"\")"],"D14":"tonne","J14":"Sable pour chape","K14":["f","IF(SUM(H61)>0,SUM(H61),\"\")"],"L14":"m3","B16":"SUPERSTRUCTURE / RDC","B17":"BETON POUR OSSATURE","E17":"AGGLOMERES","I17":"PLANCHER HAUT RDC","B18":"Béton pour plancher","C18":["f","IF(SUM(D72)>0,SUM(D72),\"\")"],"D18":"m3","F18":"Ciment pour confection","G18":["f","IF(SUM(H95:H96,H98)>0,SUM(H95:H96,H98),\"\")"],"H18":"tonne","J18":"Ciment pour hourdis","K18":["f","IF(SUM(H97)>0,SUM(H97),\"\")"],"L18":"tonne","F19":"Sable pour confection","G19":["f","IF(SUM(I95:J96,I98)>0,SUM(I95:J96,I98),\"\")"],"H19":"m3","J19":"Sable pour hourdis","K19":["f","IF(SUM(I97)>0,SUM(I97),\"\")"],"L19":"m3","B20":"Mortier pour chape (400 kg/m3)","C20":["f","IF(SUM(D73)>0,SUM(D73),\"\")"],"D20":"m3","F20":"Ciment pour montage","G20":["f","IF(SUM(H110)>0,SUM(H110),\"\")"],"H20":"tonne","J20":"Ciment pour plancher","K20":["f","IF(SUM(F72)>0,SUM(F72),\"\")"],"L20":"tonne","F21":"Sable pour montage","G21":["f","IF(SUM(J110)>0,SUM(J110),\"\")"],"H21":"m3","J21":"Sable pour plancher","K21":["f","IF(SUM(H72)>0,SUM(H72),\"\")"],"L21":"m3","B22":"Matériaux pour autres ouvrages en béton","F22":"Ciment pour enduit","G22":["f","IF(SUM(H115)>0,SUM(H115),\"\")"],"H22":"tonne","J22":"Gravier pour plancher","K22":["f","IF(SUM(J72)>0,SUM(J72),\"\")"],"L22":"tonne","B23":"Ciment","C23":["f","IF(SUM(F65:F71)>0,SUM(F65:F71),\"\")"],"D23":"tonne","F23":"Sable pour enduit","G23":["f","IF(SUM(J115)>0,SUM(J115),\"\")"],"H23":"m3","J23":"Fer pour plancher","K23":["f","IF(SUM(L72)>0,SUM(L72),\"\")"],"L23":"tonne","B24":"Sable","C24":["f","IF(SUM(H65:H71)>0,SUM(H65:H71),\"\")"],"D24":"m3","F24":"Nombre d'agglos 15 creux ","G24":["f","IF(SUM(F95)>0,SUM(F95),\"\")"],"H24":"unités","J24":"Ciment pour chape","K24":["f","IF(SUM(F73)>0,SUM(F73),\"\")"],"L24":"tonne","B25":"Gravier","C25":["f","IF(SUM(J65:J71)>0,SUM(J65:J71),\"\")"],"D25":"tonne","F25":"Nombre d'agglos 10 creux ","G25":["f","IF(SUM(F96)>0,SUM(F96),\"\")"],"H25":"unités","J25":"Sable pour chape","K25":["f","IF(SUM(H73)>0,SUM(H73),\"\")"],"L25":"m3","B26":"Fer","C26":["f","IF(SUM(L65:L71)>0,SUM(L65:L71),\"\")"],"D26":"tonne","F26":"Nombre de claustras","G26":["f","IF(SUM(F98)>0,SUM(F98),\"\")"],"H26":"unités","J26":"Nombred'hourdis","K26":["f","IF(SUM(F97)>0,SUM(F97),\"\")"],"L26":"unités","B28":"ETAGE","G28":"(Ici, toutes les données sont pour le nombre total d'étage)","B29":"BETON POUR OSSATURE","E29":"AGGLOMERES","I29":"PLANCHER","B30":"Béton pour plancher","C30":["f","IF(AND(D84>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(D84>0,P!H101=\"avec plancher\",P!H99=1),D84,IF(AND(D84>0,P!H101=\"sans plancher\",P!H99>=2),D84*(P!H99-1),IF(AND(D84>0,P!H101=\"avec plancher\",P!H99>=2),D84*P!H99,\"\"))))"],"D30":"m3","F30":"Ciment pour confection","G30":["f","IF(SUM(H101:H102,H104)>0,SUM(H101:H102,H104),\"\")"],"H30":"tonne","J30":"Ciment pour hourdis","K30":["f","IF(SUM(H103)>0,SUM(H103),\"\")"],"L30":"tonne","F31":"Sable pour confection","G31":["f","IF(SUM(I101:J102,I104)>0,SUM(I101:J102,I104),\"\")"],"H31":"m3","J31":"Sable pour hourdis","K31":["f","IF(SUM(I103)>0,SUM(I103),\"\")"],"L31":"m3","B32":"Mortier pour chape (400 kg/m3)","C32":["f","IF(AND(D85>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(D85>0,P!H101=\"avec plancher\",P!H99=1),D85,IF(AND(D85>0,P!H101=\"sans plancher\",P!H99>=2),D85*(P!H99-1),IF(AND(D85>0,P!H101=\"avec plancher\",P!H99>=2),D85*P!H99,\"\"))))"],"D32":"m3","F32":"Ciment pour montage","G32":["f","IF(SUM(H113)>0,SUM(H113),\"\")"],"H32":"tonne","J32":"Ciment pour plancher","K32":["f","IF(AND(F84>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(F84>0,P!H101=\"avec plancher\",P!H99=1),F84,IF(AND(F84>0,P!H101=\"sans plancher\",P!H99>=2),F84*(P!H99-1),IF(AND(F84>0,P!H101=\"avec plancher\",P!H99>=2),F84*P!H99,\"\"))))"],"L32":"tonne","F33":"Sable pour montage","G33":["f","IF(SUM(J113)>0,SUM(J113),\"\")"],"H33":"m3","J33":"Sable pour plancher","K33":["f","IF(AND(H84>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(H84>0,P!H101=\"avec plancher\",P!H99=1),H84,IF(AND(H84>0,P!H101=\"sans plancher\",P!H99>=2),H84*(P!H99-1),IF(AND(H84>0,P!H101=\"avec plancher\",P!H99>=2),H84*P!H99,\"\"))))"],"L33":"m3","B34":"Matériaux pour autres ouvrages en béton","F34":"Ciment pour enduit","G34":["f","IF(SUM(H116)>0,SUM(H116),\"\")"],"H34":"tonne","J34":"Gravier pour plancher","K34":["f","IF(AND(J84>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(J84>0,P!H101=\"avec plancher\",P!H99=1),J84,IF(AND(J84>0,P!H101=\"sans plancher\",P!H99>=2),J84*(P!H99-1),IF(AND(J84>0,P!H101=\"avec plancher\",P!H99>=2),J84*P!H99,\"\"))))"],"L34":"tonne","B35":"Ciment","C35":["f","IF(SUM(F86)-SUM(F84:F85)>0,SUM(F86)-SUM(F84:F85),\"\")"],"D35":"tonne","F35":"Sable pour enduit","G35":["f","IF(SUM(J116)>0,SUM(J116),\"\")"],"H35":"m3","J35":"Fer pour plancher","K35":["f","IF(AND(L84>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(L84>0,P!H101=\"avec plancher\",P!H99=1),L84,IF(AND(L84>0,P!H101=\"sans plancher\",P!H99>=2),L84*(P!H99-1),IF(AND(L84>0,P!H101=\"avec plancher\",P!H99>=2),L84*P!H99,\"\"))))"],"L35":"tonne","B36":"Sable","C36":["f","IF(SUM(H86)-SUM(H84:H85)>0,SUM(H86)-SUM(H84:H85),\"\")"],"D36":"m3","F36":"Nombre d'agglos 15 creux ","G36":["f","IF(SUM(F101)>0,SUM(F101),\"\")"],"H36":"unités","J36":"Ciment pour chape","K36":["f","IF(AND(F85>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(F85>0,P!H101=\"avec plancher\",P!H99=1),\"\",IF(AND(F85>0,P!H101=\"sans plancher\",P!H99>=2),F85*(P!H99-1),IF(AND(F85>0,P!H101=\"avec plancher\",P!H99>=2),F85*(P!H99-1),\"\"))))"],"L36":"tonne","B37":"Gravier","C37":["f","IF(SUM(J86)-SUM(J84:J85)>0,SUM(J86)-SUM(J84:J85),\"\")"],"D37":"tonne","F37":"Nombre d'agglos 10 creux ","G37":["f","IF(SUM(F102)>0,SUM(F102),\"\")"],"H37":"unités","J37":"Sable pour chape","K37":["f","IF(AND(H85>0,P!H101=\"sans plancher\",P!H99=1),\"\",IF(AND(H85>0,P!H101=\"avec plancher\",P!H99=1),\"\",IF(AND(H85>0,P!H101=\"sans plancher\",P!H99>=2),H85*(P!H99-1),IF(AND(H85>0,P!H101=\"avec plancher\",P!H99>=2),H85*(P!H99-1),\"\"))))"],"L37":"m3","B38":"Fer","C38":["f","IF(SUM(L86)-SUM(L84:L85)>0,SUM(L86)-SUM(L84:L85),\"\")"],"D38":"tonne","F38":"Nombre de claustras","G38":["f","IF(SUM(F104)>0,SUM(F104),\"\")"],"H38":"unités","J38":"Nombred'hourdis","K38":["f","IF(SUM(F103)>0,SUM(F103),\"\")"],"L38":"unités","C40":"RECAPITULATIF GLOBAL DES MATERIAUX A COMMANDER","C41":"Ciment :","D41":["f","IF(AND(F62=\"\",F74=\"\",F86=\"\",H118=\"\"),\"\",SUM(F62,F74,F86,H118))"],"E41":"tonne","C42":"Sable :","D42":["f","IF(AND(H62=\"\",H74=\"\",H86=\"\",J118=\"\"),\"\",SUM(H62,H74,H86,J118))"],"E42":"m3","C43":"Gravier :","D43":["f","IF(AND(J62=\"\",J74=\"\",J86=\"\"),\"\",SUM(J62,J74,J86))"],"E43":"tonne","C44":"Fer :","D44":["f","IF(AND(L62=\"\",L74=\"\",L86=\"\"),\"\",SUM(L62,L74,L86))"],"E44":"tonne","B46":"1/ DETAIL POUR LE BETON ARME","B47":"DESIGNATION","C47":"UNITE","D47":"QUANTITE","E47":"CIMENT (tonne)","G47":"SABLE (m3)","I47":"GRAVIER (tonne)","K47":"FER (tonne)","E48":"DOSAGE","F48":"QUANTITE","G48":"DOSAGE","H48":"QUANTITE","I48":"DOSAGE","J48":"QUANTITE","K48":"RATIO","L48":"QUANTITE","B49":"INFRASTRUCTURE","B50":["f","P!E5"],"C50":"m3","D50":["f","IF(P!F6*P!H6*P!J6>0,P!F6*P!H6*P!J6*0.000001,\"\")"],"E50":350,"F50":["f","IF(D50=\"\",\"\",E50*D50*0.001*1.02)"],"G50":0.45,"H50":["f","IF(D50=\"\",\"\",+G50*D50*1.03)"],"I50":0.85,"J50":["f","IF(D50=\"\",\"\",I50*D50*1.44*1.03)"],"K50":90,"L50":["f","IF(D50=\"\",\"\",K50*D50*0.001*1.05)"],"B51":["f","P!E8"],"C51":"m3","D51":["f","IF((P!J9*P!H9*P!F9)>0,P!J9*P!H9*P!F9*0.000001,\"\")"],"E51":150,"F51":["f","IF(D51=\"\",\"\",E51*D51*0.001*1.02)"],"G51":0.4,"H51":["f","IF(D51=\"\",\"\",+G51*D51*1.03)"],"I51":0.8,"J51":["f","IF(D51=\"\",\"\",I51*D51*1.44*1.03)"],"B52":["f","P!E11"],"C52":"m3","D52":["f","IF((+P!F12*P!H12*P!J12)>0,+P!F12*P!H12*P!J12*0.000001,\"\")"],"E52":250,"F52":["f","IF(D52=\"\",\"\",E52*D52*0.001*1.02)"],"G52":0.45,"H52":["f","IF(D52=\"\",\"\",+G52*D52*1.03)"],"I52":0.85,"J52":["f","IF(D52=\"\",\"\",I52*D52*1.44*1.03)"],"K52":30,"L52":["f","IF(D52=\"\",\"\",K52*D52*0.001*1.05)"],"B53":["f","P!E17"],"C53":"m3","D53":["f","IF(AND(P!H18<>\"\",P!J18>0),+P!F18*P!H18*P!J18*0.000001,\"\")"],"E53":350,"F53":["f","IF(D53=\"\",\"\",E53*D53*0.001*1.02)"],"G53":0.45,"H53":["f","IF(D53=\"\",\"\",+G53*D53*1.03)"],"I53":0.85,"J53":["f","IF(D53=\"\",\"\",I53*D53*1.44*1.03)"],"K53":70,"L53":["f","IF(D53=\"\",\"\",K53*D53*0.001*1.05)"],"B54":["f","P!E20"],"C54":"m3","D54":["f","IF((+P!F21*P!H21*P!J21*P!L21)>0,+P!F21*P!H21*P!J21*P!L21*0.000001,\"\")"],"E54":["f","+E51"],"F54":["f","IF(D54=\"\",\"\",E54*D54*0.001*1.02)"],"G54":["f","G51"],"H54":["f","IF(D54=\"\",\"\",+G54*D54*1.03)"],"I54":["f","+I51"],"J54":["f","IF(D54=\"\",\"\",I54*D54*1.44*1.03)"],"B55":["f","P!E23"],"C55":"m3","D55":["f","IF((+P!F24*P!H24*P!J24*P!L24)>0,+P!F24*P!H24*P!J24*P!L24*0.000001,\"\")"],"E55":["f","E53"],"F55":["f","IF(D55=\"\",\"\",E55*D55*0.001*1.02)"],"G55":0.45,"H55":["f","IF(D55=\"\",\"\",+G55*D55*1.03)"],"I55":0.85,"J55":["f","IF(D55=\"\",\"\",I55*D55*1.44*1.03)"],"K55":50,"L55":["f","IF(D55=\"\",\"\",K55*D55*0.001*1.05)"],"B56":["f","P!E26"],"C56":"m3","D56":["f","IF((+P!F27*P!H27*P!J27*P!L27)>0,+P!F27*P!H27*P!J27*P!L27*0.000001,\"\")"],"E56":["f","E53"],"F56":["f","IF(D56=\"\",\"\",E56*D56*0.001*1.02)"],"G56":0.45,"H56":["f","IF(D56=\"\",\"\",+G56*D56*1.03)"],"I56":0.85,"J56":["f","IF(D56=\"\",\"\",I56*D56*1.44*1.03)"],"K56":90,"L56":["f","IF(D56=\"\",\"\",K56*D56*0.001*1.05)"],"B57":["f","P!E29"],"C57":"m3","D57":["f","IF((+P!F30*P!H30*P!J30*P!L30)>0,+P!F30*P!H30*P!J30*P!L30*0.000001,\"\")"],"E57":["f","E53"],"F57":["f","IF(D57=\"\",\"\",E57*D57*0.001*1.02)"],"G57":0.45,"H57":["f","IF(D57=\"\",\"\",+G57*D57*1.03)"],"I57":0.85,"J57":["f","IF(D57=\"\",\"\",I57*D57*1.44*1.03)"],"K57":110,"L57":["f","IF(D57=\"\",\"\",K57*D57*0.001*1.05)"],"B58":["f","P!E32"],"C58":"m3","D58":["f","IF((+P!F33*P!H33*P!J33*P!L33)>0,+P!F33*P!H33*P!J33*P!L33*0.000001,\"\")"],"E58":["f","E53"],"F58":["f","IF(D58=\"\",\"\",E58*D58*0.001*1.02)"],"G58":0.45,"H58":["f","IF(D58=\"\",\"\",+G58*D58*1.03)"],"I58":0.85,"J58":["f","IF(D58=\"\",\"\",I58*D58*1.44*1.03)"],"K58":["f","K53"],"L58":["f","IF(D58=\"\",\"\",K58*D58*0.001*1.05)"],"B59":["f","P!E35"],"C59":"m3","D59":["f","IF((P!F36*P!H36*P!J36)>0,P!F36*P!H36*P!J36*0.000001,\"\")"],"E59":["f","E53"],"F59":["f","IF(D59=\"\",\"\",E59*D59*0.001*1.02)"],"G59":0.45,"H59":["f","IF(D59=\"\",\"\",+G59*D59*1.03)"],"I59":0.85,"J59":["f","IF(D59=\"\",\"\",I59*D59*1.44*1.03)"],"K59":75,"L59":["f","IF(D59=\"\",\"\",K59*D59*0.001*1.05)"],"B60":["f","P!E38"],"C60":"m3","D60":["f","IF((+P!F39*P!H39*P!J39*P!L39)>0,+P!F39*P!H39*P!J39*P!L39*0.000001,\"\")"],"E60":["f","E53"],"F60":["f","IF(D60=\"\",\"\",E60*D60*0.001*1.02)"],"G60":0.45,"H60":["f","IF(D60=\"\",\"\",+G60*D60*1.03)"],"I60":0.85,"J60":["f","IF(D60=\"\",\"\",I60*D60*1.44*1.03)"],"K60":50,"L60":["f","IF(D60=\"\",\"\",K60*D60*0.001*1.05)"],"A61":"© Copyright IBWAMPERE NGWALA LOUIS","B61":"Chape sur dallage","C61":"m3","D61":["f","IF((+P!F39*P!H39*5*P!L39)>0,+P!F39*P!H39*5*P!L39*0.000001,\"\")"],"E61":400,"F61":["f","IF(D61=\"\",\"\",E61*D61*0.001*1.02)"],"G61":1,"H61":["f","IF(D61=\"\",\"\",G61*D61*1.03)"],"D62":"TOTAL","E62":"(tonne)","F62":["f","IF(SUM(F50:F61)>0,SUM(F50:F61),\"\")"],"G62":"(m3)","H62":["f","IF(SUM(H50:H61)>0,SUM(H50:H61),\"\")"],"I62":"(tonne)","J62":["f","IF(SUM(J50:J61)>0,SUM(J50:J61),\"\")"],"K62":"(tonne)","L62":["f","IF(SUM(L50:L61)>0,SUM(L50:L61),\"\")"],"B64":"SUPERSTRUCTURE / RDC","B65":["f","P!E72"],"C65":"m3","D65":["f","IF((+P!F73*P!H73*P!J73)>0,+P!F73*P!H73*P!J73*0.000001,\"\")"],"E65":["f","E53"],"F65":["f","IF(D65=\"\",\"\",E65*D65*0.001*1.02)"],"G65":0.45,"H65":["f","IF(D65=\"\",\"\",+G65*D65*1.03)"],"I65":0.85,"J65":["f","IF(D65=\"\",\"\",I65*D65*1.44*1.03)"],"K65":["f","K53"],"L65":["f","IF(D65=\"\",\"\",K65*D65*0.001*1.05)"],"B66":["f","P!E66"],"C66":"m3","D66":["f","IF(P!J67<>\"\",(P!F67*P!H67*P!J67)*0.000001,\"\")"],"E66":["f","E53"],"F66":["f","IF(D66=\"\",\"\",E66*D66*0.001*1.02)"],"G66":0.45,"H66":["f","IF(D66=\"\",\"\",+G66*D66*1.03)"],"I66":0.85,"J66":["f","IF(D66=\"\",\"\",I66*D66*1.44*1.03)"],"K66":70,"L66":["f","IF(D66=\"\",\"\",K66*D66*0.001*1.05)"],"B67":["f","P!E75"],"C67":"m3","D67":["f","IF((+P!F76*P!H76*P!J76*P!L76)>0,+P!F76*P!H76*P!J76*P!L76*0.000001,\"\")"],"E67":["f","E53"],"F67":["f","IF(D67=\"\",\"\",E67*D67*0.001*1.02)"],"G67":0.45,"H67":["f","IF(D67=\"\",\"\",+G67*D67*1.03)"],"I67":0.85,"J67":["f","IF(D67=\"\",\"\",I67*D67*1.44*1.03)"],"K67":["f","K56"],"L67":["f","IF(D67=\"\",\"\",K67*D67*0.001*1.05)"],"B68":["f","P!E78"],"C68":"m3","D68":["f","IF(P!F79*P!H79*P!J79>0,P!F79*P!H79*P!J79*0.000001,\"\")"],"E68":["f","E67"],"F68":["f","IF(D68=\"\",\"\",E68*D68*0.001*1.02)"],"G68":["f","G67"],"H68":["f","IF(D68=\"\",\"\",+G68*D68*1.03)"],"I68":["f","I67"],"J68":["f","IF(D68=\"\",\"\",I68*D68*1.44*1.03)"],"K68":["f","K59"],"L68":["f","IF(D68=\"\",\"\",K68*D68*0.001*1.05)"],"B69":["f","P!E81"],"C69":"m3","D69":["f","IF((+P!F82*P!H82*P!J82*P!L82)>0,+P!F82*P!H82*P!J82*P!L82*0.000001,\"\")"],"E69":["f","E53"],"F69":["f","IF(D69=\"\",\"\",E69*D69*0.001*1.02)"],"G69":0.45,"H69":["f","IF(D69=\"\",\"\",+G69*D69*1.03)"],"I69":0.85,"J69":["f","IF(D69=\"\",\"\",I69*D69*1.44*1.03)"],"K69":["f","K53"],"L69":["f","IF(D69=\"\",\"\",K69*D69*0.001*1.05)"],"B70":["f","P!E84"],"C70":"m3","D70":["f","IF((P!F85*P!H85*P!J85*P!L85)>0,P!F85*P!H85*P!J85*P!L85*0.000001,\"\")"],"E70":["f","E53"],"F70":["f","IF(D70=\"\",\"\",E70*D70*0.001*1.02)"],"G70":0.45,"H70":["f","IF(D70=\"\",\"\",+G70*D70*1.03)"],"I70":0.85,"J70":["f","IF(D70=\"\",\"\",I70*D70*1.44*1.03)"],"K70":["f","K57"],"L70":["f","IF(D70=\"\",\"\",K70*D70*0.001*1.05)"],"B71":["f","P!E87"],"C71":"m3","D71":["f","IF(AND(P!F88>=2,P!F90<>\"\",P!I88<>\"\"),((((SQRT(P!H90^2+P!J90^2)*P!L88)+((P!H90*P!J90)/2))*P!F90*P!I88*P!F88)+((P!F90*1.2)*(P!F90*2+P!L90)*P!H92*(P!F88-1)))*0.000001,IF(AND(P!F88=1,P!F90<>\"\",P!I88<>\"\"),((((SQRT(P!H90^2+P!J90^2)*P!L88)+((P!H90*P!J90)/2))*P!F90*P!I88*P!F88)+((P!F90*1.2)*(P!F90*2+P!L90)*P!H92*P!F88))*0.000001,\"\"))"],"E71":["f","E53"],"F71":["f","IF(D71=\"\",\"\",E71*D71*0.001*1.02)"],"G71":0.45,"H71":["f","IF(D71=\"\",\"\",+G71*D71*1.03)"],"I71":0.85,"J71":["f","IF(D71=\"\",\"\",I71*D71*1.44*1.03)"],"K71":100,"L71":["f","IF(D71=\"\",\"\",K71*D71*0.001*1.05)"],"B72":["f","P!F94"],"C72":"m3","D72":["f","IF((+P!F95*P!H95*P!J95*P!L95)>0,+P!F95*P!H95*P!J95*P!L95*0.000001,\"\")"],"E72":["f","E53"],"F72":["f","IF(D72=\"\",\"\",E72*D72*0.001*1.02)"],"G72":0.45,"H72":["f","IF(D72=\"\",\"\",+G72*D72*1.03)"],"I72":0.85,"J72":["f","IF(D72=\"\",\"\",I72*D72*1.44*1.03)"],"K72":["f","K60"],"L72":["f","IF(D72=\"\",\"\",K72*D72*0.001*1.05)"],"B73":"Chape sur plancher haut RDC","C73":"m3","D73":["f","IF((+P!F95*P!H95*5*P!L95)>0,+P!F95*P!H95*5*P!L95*0.000001,\"\")"],"E73":["f","E61"],"F73":["f","IF(D73=\"\",\"\",E73*D73*0.001*1.02)"],"G73":1,"H73":["f","IF(D73=\"\",\"\",G73*D73*1.03)"],"D74":"TOTAL","E74":"(tonne)","F74":["f","IF(SUM(F65:F73)>0,SUM(F65:F73),\"\")"],"G74":"(m3)","H74":["f","IF(SUM(H65:H73)>0,SUM(H65:H73),\"\")"],"I74":"(tonne)","J74":["f","IF(SUM(J65:J73)>0,SUM(J65:J73),\"\")"],"K74":"(tonne)","L74":["f","IF(SUM(L65:L73)>0,SUM(L65:L73),\"\")"],"B76":"ETAGE","B77":["f","P!E132"],"C77":"m3","D77":["f","IF((P!F133*P!H133*P!J133)>0,P!F133*P!H133*P!J133*0.000001,\"\")"],"E77":["f","E53"],"F77":["f","IF(D77=\"\",\"\",E77*D77*0.001*1.02)"],"G77":0.45,"H77":["f","IF(D77=\"\",\"\",+G77*D77*1.03)"],"I77":0.85,"J77":["f","IF(D77=\"\",\"\",I77*D77*1.44*1.03)"],"K77":["f","K53"],"L77":["f","IF(D77=\"\",\"\",K77*D77*0.001*1.05)"],"B78":["f","P!E126"],"C78":"m3","D78":["f","IF(P!J127<>\"\",(+P!F127*P!H127*P!J127)*0.000001,\"\")"],"E78":["f","E53"],"F78":["f","IF(D78=\"\",\"\",E78*D78*0.001*1.02)"],"G78":0.45,"H78":["f","IF(D78=\"\",\"\",+G78*D78*1.03)"],"I78":0.85,"J78":["f","IF(D78=\"\",\"\",I78*D78*1.44*1.03)"],"K78":["f","+K66"],"L78":["f","IF(D78=\"\",\"\",K78*D78*0.001*1.05)"],"B79":["f","P!E135"],"C79":"m3","D79":["f","IF((+P!F136*P!H136*P!J136*P!L136)>0,+(P!F136*P!H136*P!J136*P!L136)*0.000001,\"\")"],"E79":["f","E53"],"F79":["f","IF(D79=\"\",\"\",E79*D79*0.001*1.02)"],"G79":0.45,"H79":["f","IF(D79=\"\",\"\",+G79*D79*1.03)"],"I79":0.85,"J79":["f","IF(D79=\"\",\"\",I79*D79*1.44*1.03)"],"K79":["f","K56"],"L79":["f","IF(D79=\"\",\"\",K79*D79*0.001*1.05)"],"B80":["f","P!E138"],"C80":"m3","D80":["f","IF(P!F139*P!H139*P!J139>0,P!F139*P!H139*P!J139*0.000001,\"\")"],"E80":["f","E79"],"F80":["f","IF(D80=\"\",\"\",E80*D80*0.001*1.02)"],"G80":["f","G79"],"H80":["f","IF(D80=\"\",\"\",+G80*D80*1.03)"],"I80":["f","I79"],"J80":["f","IF(D80=\"\",\"\",I80*D80*1.44*1.03)"],"K80":["f","K68"],"L80":["f","IF(D80=\"\",\"\",K80*D80*0.001*1.05)"],"B81":["f","P!E141"],"C81":"m3","D81":["f","IF((+P!F142*P!H142*P!J142*P!L142)>0,+P!F142*P!H142*P!J142*P!L142*0.000001,\"\")"],"E81":["f","E53"],"F81":["f","IF(D81=\"\",\"\",E81*D81*0.001*1.02)"],"G81":0.45,"H81":["f","IF(D81=\"\",\"\",+G81*D81*1.03)"],"I81":0.85,"J81":["f","IF(D81=\"\",\"\",I81*D81*1.44*1.03)"],"K81":["f","K53"],"L81":["f","IF(D81=\"\",\"\",K81*D81*0.001*1.05)"],"B82":["f","P!E144"],"C82":"m3","D82":["f","IF((+P!F145*P!H145*P!J145*P!L145)>0,+P!F145*P!H145*P!J145*P!L145*0.000001,\"\")"],"E82":["f","E53"],"F82":["f","IF(D82=\"\",\"\",E82*D82*0.001*1.02)"],"G82":0.45,"H82":["f","IF(D82=\"\",\"\",+G82*D82*1.03)"],"I82":0.85,"J82":["f","IF(D82=\"\",\"\",I82*D82*1.44*1.03)"],"K82":["f","K57"],"L82":["f","IF(D82=\"\",\"\",K82*D82*0.001*1.05)"],"B83":["f","P!E147"],"C83":"m3","D83":["f","IF(AND(P!F148>=2,P!F150<>\"\",P!I148<>\"\"),((((SQRT(P!H150^2+P!J150^2)*P!L148)+((P!H150*P!J150)/2))*P!F150*P!I148*P!F148)+((P!F150*1.2)*(P!F150*2+P!L150)*P!H152*(P!F148-1)))*0.000001,IF(AND(P!F148=1,P!F150<>\"\",P!I148<>\"\"),((((SQRT(P!H150^2+P!J150^2)*P!L148)+((P!H150*P!J150)/2))*P!F150*P!I148*P!F148)+((P!F150*1.2)*(P!F150*2+P!L150)*P!H152*P!F148))*0.000001,\"\"))"],"E83":["f","E53"],"F83":["f","IF(D83=\"\",\"\",E83*D83*0.001*1.02)"],"G83":0.45,"H83":["f","IF(D83=\"\",\"\",+G83*D83*1.03)"],"I83":0.85,"J83":["f","IF(D83=\"\",\"\",I83*D83*1.44*1.03)"],"K83":["f","K71"],"L83":["f","IF(D83=\"\",\"\",K83*D83*0.001*1.05)"],"B84":["f","P!F154"],"C84":"m3","D84":["f","IF((+P!F155*P!H155*P!J155*P!L155)>0,+P!F155*P!H155*P!J155*P!L155*0.000001,\"\")"],"E84":["f","E53"],"F84":["f","IF(D84=\"\",\"\",E84*D84*0.001*1.02)"],"G84":0.45,"H84":["f","IF(D84=\"\",\"\",+G84*D84*1.03)"],"I84":0.85,"J84":["f","IF(D84=\"\",\"\",I84*D84*1.44*1.03)"],"K84":["f","K60"],"L84":["f","IF(D84=\"\",\"\",K84*D84*0.001*1.05)"],"B85":"Chape sur plancher haut étage","C85":"m3","D85":["f","IF((+P!F155*P!H155*5*P!L155)>0,+P!F155*P!H155*5*P!L155*0.000001,\"\")"],"E85":["f","E61"],"F85":["f","IF(D85=\"\",\"\",E85*D85*0.001*1.02)"],"G85":1,"H85":["f","IF(D85=\"\",\"\",G85*D85*1.03)"],"D86":"TOTAUX POUR TOUS LES ETAGES","E86":"(tonne)","F86":["f","IF(AND(SUM(F77:F85)>0,P!H99=1,P!H101=\"sans plancher\"),SUM(F77:F82),IF(AND(SUM(F77:F85)>0,P!H99=1,P!H101=\"avec plancher\"),SUM(F77:F84),IF(AND(SUM(F77:F85)>0,P!H99>=2,P!H101=\"sans plancher\"),SUM(F77:F82)+SUM(F83:F85)*(P!H99-1),IF(AND(SUM(F77:F85)>0,P!H99>=2,P!H101=\"avec plancher\"),SUM(F77:F82,85)+SUM(F85,F83)*(P!H99-1),\"\"))))"],"G86":"(m3)","H86":["f","IF(AND(SUM(H77:H85)>0,P!H99=1,P!H101=\"sans plancher\"),SUM(H77:H82),IF(AND(SUM(H77:H85)>0,P!H99=1,P!H101=\"avec plancher\"),SUM(H77:H84),IF(AND(SUM(H77:H85)>0,P!H99>=2,P!H101=\"sans plancher\"),SUM(H77:H82)+SUM(H83:H85)*(P!H99-1),IF(AND(SUM(H77:H85)>0,P!H99>=2,P!H101=\"avec plancher\"),SUM(H77:H82,85)+SUM(H85,H83)*(P!H99-1),\"\"))))"],"I86":"(tonne)","J86":["f","IF(AND(SUM(J77:J85)>0,P!H99=1,P!H101=\"sans plancher\"),SUM(J77:J82),IF(AND(SUM(J77:J85)>0,P!H99=1,P!H101=\"avec plancher\"),SUM(J77:J84),IF(AND(SUM(J77:J85)>0,P!H99>=2,P!H101=\"sans plancher\"),SUM(J77:J82)+SUM(J83:J85)*(P!H99-1),IF(AND(SUM(J77:J85)>0,P!H99>=2,P!H101=\"avec plancher\"),SUM(J77:J82,85)+SUM(J85,J83)*(P!H99-1),\"\"))))"],"K86":"(tonne)","L86":["f","IF(AND(SUM(L77:L85)>0,P!H99=1,P!H101=\"sans plancher\"),SUM(L77:L82),IF(AND(SUM(L77:L85)>0,P!H99=1,P!H101=\"avec plancher\"),SUM(L77:L84),IF(AND(SUM(L77:L85)>0,P!H99>=2,P!H101=\"sans plancher\"),SUM(L77:L82)+SUM(L83:L85)*(P!H99-1),IF(AND(SUM(L77:L85)>0,P!H99>=2,P!H101=\"avec plancher\"),SUM(L77:L82,85)+SUM(L85,L83)*(P!H99-1),\"\"))))"],"B88":"2/ CONFECTION ET MONTAGE D'AGGLOMERES","A89":"© Copyright IBWAMPERE NGWALA LOUIS","B89":"DESIGNATION","C89":"UNITE","D89":"QUANTITE","E89":"RATIO / m²","F89":"NBRE TOTAL","G89":"CIMENT (tonne)","I89":"SABLE (m3)","G90":"RATIO / Tonne","H90":"QUANTITE","B91":"INFRASTRUCTURE","B92":["f","P!E14"],"C92":"m²","D92":["f","IF((P!F15*P!H15)>0,P!F15*P!H15*0.0001,\"\")"],"E92":12,"F92":["f","IF(D92=\"\",\"\",E92*D92)"],"G92":["f","VLOOKUP(P!E14,P!A14:B15,2,0)"],"H92":["f","IF(F92=\"\",\"\",+F92*1.02/G92)"],"I92":["f","IF(H92=\"\",\"\",+H92*3*1.03)"],"B94":"SUPERSTRUCTURE / RDC","B95":["f","P!E44"],"C95":"m²","D95":["f","IF(((+P!F45*P!H45)-P!K54)>0,(+P!F45*P!H45*0.0001)-P!K54,\"\")"],"E95":["f","E92"],"F95":["f","IF(D95=\"\",\"\",E95*D95)"],"G95":500,"H95":["f","IF(F95=\"\",\"\",+F95*1.02/G95)"],"I95":["f","IF(H95=\"\",\"\",+H95*3*1.03)"],"B96":["f","P!E55"],"C96":"m²","D96":["f","IF(((+P!F56*P!H56)-P!K65)>0,(+P!F56*P!H56*0.0001)-P!K65,\"\")"],"E96":["f","E95"],"F96":["f","IF(D96=\"\",\"\",E96*D96)"],"G96":600,"H96":["f","IF(F96=\"\",\"\",+F96*1.02/G96)"],"I96":["f","IF(H96=\"\",\"\",+H96*3*1.03)"],"B97":["f","P!E94"],"C97":"m²","D97":["f","IF(AND(P!F95<>\"\",P!H95<>\"\"),+P!F95*P!H95*P!L95*0.0001,\"\")"],"E97":12,"F97":["f","IF(D97=\"\",\"\",E97*D97)"],"G97":300,"H97":["f","IF(F97=\"\",\"\",+F97*1.02/G97)"],"I97":["f","IF(H97=\"\",\"\",+H97*3*1.03)"],"B98":["f","P!E69"],"C98":"m²","D98":["f","IF((P!F70*P!H70)>0,P!F70*P!H70*0.0001,\"\")"],"E98":24,"F98":["f","IF(D98=\"\",\"\",E98*D98)"],"G98":650,"H98":["f","IF(F98=\"\",\"\",+F98*1.02/G98)"],"I98":["f","IF(H98=\"\",\"\",+H98*3*1.03)"],"B100":"ETAGE","F100":"(Ici, toutes les données sont pour le nombre total d'étage)","B101":["f","P!E104"],"C101":"m²","D101":["f","IF(((P!F105*P!H105)-(P!K114))>0,(P!F105*P!H105*0.0001*P!H99)-(P!K114*P!H99),\"\")"],"E101":["f","E95"],"F101":["f","IF(D101=\"\",\"\",E101*D101)"],"G101":["f","G95"],"H101":["f","IF(F101=\"\",\"\",+F101*1.02/G101)"],"I101":["f","IF(H101=\"\",\"\",+H101*3*1.03)"],"B102":["f","P!E115"],"C102":"m²","D102":["f","IF(((P!F116*P!H116)-(P!K125))>0,(P!F116*P!H116*0.0001*P!H99)-(P!K125*P!H99),\"\")"],"E102":["f","E96"],"F102":["f","IF(D102=\"\",\"\",E102*D102)"],"G102":["f","G96"],"H102":["f","IF(F102=\"\",\"\",+F102*1.02/G102)"],"I102":["f","IF(H102=\"\",\"\",+H102*3*1.03)"],"B103":["f","P!E154"],"C103":"m²","E103":["f","E97"],"F103":["f","IF(D103=\"\",\"\",E103*D103)"],"G103":["f","G97"],"H103":["f","IF(F103=\"\",\"\",+F103*1.02/G103)"],"I103":["f","IF(H103=\"\",\"\",+H103*3*1.03)"],"B104":["f","P!E129"],"C104":"m²","D104":["f","IF((P!F130*P!H130)>0,P!F130*P!H130*0.0001*P!H99,\"\")"],"E104":["f","E98"],"F104":["f","IF(D104=\"\",\"\",E104*D104)"],"G104":["f","G98"],"H104":["f","IF(F104=\"\",\"\",+F104*1.02/G104)"],"I104":["f","IF(H104=\"\",\"\",+H104*3*1.03)"],"F106":"QUANTITE POUR LA CONFECTION SOUBASSEMENT","G106":"(tonne)","H106":["f","IF(SUM(H92)>0,SUM(H92),\"\")"],"I106":"(m3)","J106":["f","IF(H106=\"\",\"\",+I92)"],"F107":"QUANTITE POUR LE MONTAGE SOUBASSEMENT","G107":"(tonne)","H107":["f","IF((SUM(F92)*1.02/1000)>0,SUM(F92)*1.02/1000,\"\")"],"I107":"(m3)","J107":["f","IF(H107=\"\",\"\",+H107*3*1.03)"],"F109":"QUANTITE POUR LA CONFECTION SUPERSTRUCTURE / RDC","G109":"(tonne)","H109":["f","IF(SUM(H95:H98)>0,SUM(H95:H98),\"\")"],"I109":"(m3)","J109":["f","IF(H109=\"\",\"\",SUM(I95:J98))"],"F110":"QUANTITE POUR LE MONTAGE SUPERSTRUCTURE / RDC","G110":"(tonne)","H110":["f","IF((SUM(F95:F96,F98)*1.02/1000)>0,SUM(F95:F96,F98)*1.02/1000,\"\")"],"I110":"(m3)","J110":["f","IF(H110=\"\",\"\",+H110*3*1.03)"],"F112":"QUANTITE POUR LA CONFECTION ETAGE","G112":"(tonne)","H112":["f","IF(SUM(H101:H104)>0,SUM(H101:H104),\"\")"],"I112":"(m3)","J112":["f","IF(H112=\"\",\"\",SUM(I101:J104))"],"F113":"QUANTITE POUR LE MONTAGE ETAGE","G113":"(tonne)","H113":["f","IF((SUM(F101:F102,F104)*1.02/1000)>0,SUM(F101:F102,F104)*1.02/1000,\"\")"],"I113":"(m3)","J113":["f","IF(H113=\"\",\"\",+H113*3*1.03)"],"F115":"ENDUIT RDC (300 kg/m3)","G115":"(tonne)","H115":["f","IF(AND(D97<>\"\",H110<>\"\"),(SUM(D95:D96)*2+SUM(H!C26:C27))*0.015*0.3*1.02,IF(AND(D97=\"\",H110<>\"\"),(SUM(D95:D96)*2+SUM(H!C26))*0.015*0.3*1.02,\"\"))"],"I115":"(m3)","J115":["f","IF(H115=\"\",\"\",+H115*1*1.03)"],"F116":"ENDUIT ETAGE (300 kg/m3)","G116":"(tonne)","H116":["f","IF(AND(D103<>\"\",H113<>\"\"),(SUM(D101:D102)*2+SUM(H!C37:C38))*0.015*0.3*1.02,IF(AND(D103=\"\",H113<>\"\"),(SUM(D101:D102)*2+SUM(H!C37))*0.015*0.3*1.02,\"\"))"],"I116":"(m3)","J116":["f","IF(H116=\"\",\"\",+H116*1*1.03)"],"F118":"TOTAL DEFINITIF POUR LA CONFECTION ET LE MONTAGE","G118":"(tonne)","H118":["f","IF(SUM(H106:H116)>0,SUM(H106:H116),\"\")"],"I118":"(m3)","J118":["f","IF(SUM(J106:J116)>0,SUM(J106:J116),\"\")"],"G120":"PARAMETRE D'ETAGE","H121":["f","P!G99"],"I121":["f","P!H99"],"H122":["f","P!G101"],"I122":["f","P!H101"]},"X":{"B2":"GRILLE DES PRIX DES MATÉRIAUX — RDC & ÉTAGE COURANT","B4":"Taux de change appliqué :","C4":2350,"D4":"(pour 1 USD)","E4":"(Cellule modifiable — mettez à jour selon le taux du jour de la BCC / marché parallèle)","B6":"1/ PRIX UNITAIRES DES MATÉRIAUX (exemple à ajuster selon votre marché)","B7":"Désignation","C7":"Unité","D7":"Prix RDC\n($)","E7":"Prix RDC\n(FC)","F7":"Prix Étage courant\n($)","G7":"Prix Étage courant\n(FC)","B8":"Ciment (sac 50kg = 0.05t)","C8":"tonne","D8":12,"E8":["f","D8*$C$4"],"F8":12,"G8":["f","F8*$C$4"],"B9":"Sable de rivière","C9":"m3","D9":22,"E9":["f","D9*$C$4"],"F9":22,"G9":["f","F9*$C$4"],"B10":"Gravier / moellons concassés","C10":"tonne","D10":30,"E10":["f","D10*$C$4"],"F10":30,"G10":["f","F10*$C$4"],"B11":"Fer à béton (rond lisse/HA)","C11":"tonne","D11":950,"E11":["f","D11*$C$4"],"F11":965,"G11":["f","F11*$C$4"],"B12":"Agglos pleins 15/20","C12":"unité","D12":0.6,"E12":["f","D12*$C$4"],"F12":0.65,"G12":["f","F12*$C$4"],"B13":"Agglos creux 15","C13":"unité","D13":0.55,"E13":["f","D13*$C$4"],"F13":0.6,"G13":["f","F13*$C$4"],"B14":"Agglos creux 10","C14":"unité","D14":0.45,"E14":["f","D14*$C$4"],"F14":0.5,"G14":["f","F14*$C$4"],"B15":"Claustras","C15":"unité","D15":1.2,"E15":["f","D15*$C$4"],"F15":1.3,"G15":["f","F15*$C$4"],"B16":"Hourdis","C16":"unité","D16":1.5,"E16":["f","D16*$C$4"],"F16":1.6,"G16":["f","F16*$C$4"],"B17":"Bois de coffrage","C17":"m²","D17":3,"E17":["f","D17*$C$4"],"F17":3.5,"G17":["f","F17*$C$4"],"B18":"Eau de gâchage","C18":"m3","D18":1,"E18":["f","D18*$C$4"],"F18":1,"G18":["f","F18*$C$4"],"B19":"Main d'œuvre (journée manœuvre)","C19":"forfait/j","D19":8,"E19":["f","D19*$C$4"],"F19":9,"G19":["f","F19*$C$4"],"B21":"Légende : chiffres en bleu = valeurs modifiables par vous.","B23":"2/ CALCUL AUTOMATIQUE DU COÛT DES MATÉRIAUX PRINCIPAUX","B24":"(quantités reprises automatiquement depuis la feuille « Quantitatif béton armé »)","B26":"Désignation","C26":"Unité","D26":"Qté Infra + RDC","E26":"Qté Étage courant","F26":"Prix RDC ($)","G26":"Prix Étage ($)","H26":"Coût Infra+RDC ($)","I26":"Coût Étage ($)","J26":"Coût Total ($)","K26":"Coût Total (FC)","B27":"Ciment","C27":"tonne","D27":["f","IF(SUM(Q!C11,Q!C23)=0,0,SUM(Q!C11,Q!C23))"],"E27":["f","IF(Q!C35=\"\",0,Q!C35)"],"F27":["f","D8"],"G27":["f","F8"],"H27":["f","D27*F27"],"I27":["f","E27*G27"],"J27":["f","H27+I27"],"K27":["f","J27*$C$4"],"B28":"Sable","C28":"m3","D28":["f","IF(SUM(Q!C12,Q!C24)=0,0,SUM(Q!C12,Q!C24))"],"E28":["f","IF(Q!C36=\"\",0,Q!C36)"],"F28":["f","D9"],"G28":["f","F9"],"H28":["f","D28*F28"],"I28":["f","E28*G28"],"J28":["f","H28+I28"],"K28":["f","J28*$C$4"],"B29":"Gravier","C29":"tonne","D29":["f","IF(SUM(Q!C13,Q!C25)=0,0,SUM(Q!C13,Q!C25))"],"E29":["f","IF(Q!C37=\"\",0,Q!C37)"],"F29":["f","D10"],"G29":["f","F10"],"H29":["f","D29*F29"],"I29":["f","E29*G29"],"J29":["f","H29+I29"],"K29":["f","J29*$C$4"],"B30":"Fer à béton","C30":"tonne","D30":["f","IF(SUM(Q!C14,Q!C26)=0,0,SUM(Q!C14,Q!C26))"],"E30":["f","IF(Q!C38=\"\",0,Q!C38)"],"F30":["f","D11"],"G30":["f","F11"],"H30":["f","D30*F30"],"I30":["f","E30*G30"],"J30":["f","H30+I30"],"K30":["f","J30*$C$4"],"B31":"TOTAL GÉNÉRAL","H31":["f","SUM(H27:H30)"],"I31":["f","SUM(I27:I30)"],"J31":["f","SUM(J27:J30)"],"K31":["f","SUM(K27:K30)"],"B33":"Note : les agglomérés, claustras, hourdis, bois de coffrage, eau et main d'œuvre se chiffrent en reprenant leurs quantités dans l'onglet « Quantitatif béton armé » (section 2/) et en les multipliant par les prix unitaires du tableau 1 ci-dessus."},"H":{"C26":["f","IF(AND(P!F88>=2,P!F90<>\"\",P!I88<>\"\"),(((SQRT(P!H90^2+P!J90^2)*P!F90*P!F88)+(P!F90*P!H90*P!I88*P!F88)+((SQRT(P!H90^2+P!J90^2)*P!I88)*(1+P!L88)*P!F88*2)+(P!F90*1.2)*(P!F90*2+P!L90)*(P!F88-1)+((P!F90*1.2)+(P!F90*2+P!L90))*2*(P!F88-1)))*0.0001,IF(AND(P!F88=1,P!F90<>\"\",P!I88<>\"\"),(((SQRT(P!H90^2+P!J90^2)*P!F90*P!F88)+(P!F90*P!H90*P!I88*P!F88)+((SQRT(P!H90^2+P!J90^2)*P!I88)*(1+P!L88)*P!F88*2)+(P!F90*1.2)*(P!F90*2+P!L90)*P!F88+((P!F90*1.2)+(P!F90*2+P!L90))*2*P!F88))*0.0001,\"\"))"],"C27":["f","IF(((P!F95*P!H95)+((P!F95+P!H95)*2*P!J95))>0,((P!F95*P!H95)+((P!F95+P!H95)*2*P!J95))*P!L95*0.0001,\"\")"],"C37":["f","IF(AND(P!H99>=2,P!F148>=2,P!F150<>\"\",P!I148<>\"\"),(((SQRT(P!H150^2+P!J150^2)*P!F150*P!F148)+(P!F150*P!H150*P!I148*P!F148)+((SQRT(P!H150^2+P!J150^2)*P!I148)*(1+P!L148)*P!F148*2)+(P!F150*1.2)*(P!F150*2+P!L150)*(P!F148-1)+((P!F150*1.2)+(P!F150*2+P!L150))*2*(P!F148-1)))*(P!H99-1)*0.0001,IF(AND(P!H99>=2,P!F148=1,P!F150<>\"\",P!I148<>\"\"),(((SQRT(P!H150^2+P!J150^2)*P!F150*P!F148)+(P!F150*P!H150*P!I148*P!F148)+((SQRT(P!H150^2+P!J150^2)*P!I148)*(1+P!L148)*P!F148*2)+(P!F150*1.2)*(P!F150*2+P!L150)*P!F148+((P!F150*1.2)+(P!F150*2+P!L150))*2*P!F148))*(P!H99-1)*0.0001,IF(AND(P!H99=1,P!F148>=2,P!F150<>\"\",P!I148<>\"\"),(((SQRT(P!H150^2+P!J150^2)*P!F150*P!F148)+(P!F150*P!H150*P!I148*P!F148)+((SQRT(P!H150^2+P!J150^2)*P!I148)*(1+P!L148)*P!F148*2)+(P!F150*1.2)*(P!F150*2+P!L150)*(P!F148-1)+((P!F150*1.2)+(P!F150*2+P!L150))*2*(P!F148-1)))*P!H99*0.0001,IF(AND(P!H99=1,P!F148=1,P!F150<>\"\",P!I148<>\"\"),(((SQRT(P!H150^2+P!J150^2)*P!F150*P!F148)+(P!F150*P!H150*P!I148*P!F148)+((SQRT(P!H150^2+P!J150^2)*P!I148)*(1+P!L148)*P!F148*2)+(P!F150*1.2)*(P!F150*2+P!L150)*P!F148+((P!F150*1.2)+(P!F150*2+P!L150))*2*P!F148))*P!H99*0.0001,\"\"))))"],"C38":["f","IF(AND(((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))>0,P!H99=1,P!H101=\"sans plancher\"),\"\",IF(AND(((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))>0,P!H99=1,P!H101=\"avec plancher\"),((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))*P!L155*0.0001,IF(AND(((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))>0,P!H99>=2,P!H101=\"avec plancher\"),((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))*P!L155*0.0001*P!H99,IF(AND(((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))>0,P!H99>=2,P!H101=\"sans plancher\"),((P!F155*P!H155)+((P!F155+P!H155)*2*P!J155))*P!L155*0.0001*(P!H99-1),\"\"))))"]},"D":{"B17":"Ciment","C17":"tonne","D17":["f","X!D27+X!E27"],"E17":["f","IF(D17=0,0,X!J27/D17)"],"F17":["f","X!J27"],"G17":["f","X!K27"],"B18":"Sable","C18":"m3","D18":["f","X!D28+X!E28"],"E18":["f","IF(D18=0,0,X!J28/D18)"],"F18":["f","X!J28"],"G18":["f","X!K28"],"B19":"Gravier","C19":"tonne","D19":["f","X!D29+X!E29"],"E19":["f","IF(D19=0,0,X!J29/D19)"],"F19":["f","X!J29"],"G19":["f","X!K29"],"B20":"Fer à béton","C20":"tonne","D20":["f","X!D30+X!E30"],"E20":["f","IF(D20=0,0,X!J30/D20)"],"F20":["f","X!J30"],"G20":["f","X!K30"],"B21":"Sous-total matériaux","F21":["f","SUM(F17:F20)"],"G21":["f","SUM(G17:G20)"],"B22":"Divers & imprévus (%)","D22":0.1,"F22":["f","F21*D22"],"G22":["f","G21*D22"],"B23":"TOTAL GÉNÉRAL","F23":["f","F21+F22"],"G23":["f","G21+G22"]}};
/* ---------- moteur de formules (sous-ensemble Excel : + - * / ^ & comparaisons, SUM IF AND SQRT VLOOKUP) ---------- */
function XlErr(c){this.code=c}
const XE=c=>{throw new XlErr(c)};
const colNum=s=>{let n=0;for(let i=0;i<s.length;i++)n=n*26+s.charCodeAt(i)-64;return n};
const numCol=n=>{let s='';while(n>0){const r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=(n-r-1)/26}return s};
function tokenize(s){
  const t=[];let i=0;
  while(i<s.length){
    const c=s[i];
    if(c===' '){i++;continue}
    if(c==='"'){let j=i+1,str='';while(j<s.length){if(s[j]==='"'){if(s[j+1]==='"'){str+='"';j+=2;continue}break}str+=s[j++]}t.push({t:'s',v:str});i=j+1;continue}
    const rest=s.slice(i);let m;
    if((m=/^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(rest))){t.push({t:'n',v:parseFloat(m[0])});i+=m[0].length;continue}
    if((m=/^(?:([A-Z])!)?\$?([A-Z]{1,2})\$?(\d+)(?::\$?([A-Z]{1,2})\$?(\d+))?(?![A-Za-z0-9(])/.exec(rest))){
      t.push(m[4]?{t:'r',sh:m[1]||null,c1:m[2],r1:+m[3],c2:m[4],r2:+m[5]}:{t:'c',sh:m[1]||null,c:m[2],r:+m[3]});i+=m[0].length;continue}
    if((m=/^([A-Z][A-Z0-9.]*)\(/.exec(rest))){t.push({t:'f',v:m[1]});i+=m[0].length;continue}
    if((m=/^(<>|<=|>=)/.exec(rest))){t.push({t:'o',v:m[1]});i+=2;continue}
    if('+-*/^=<>&(),'.indexOf(c)>=0){t.push({t:'o',v:c});i++;continue}
    throw new Error('Formule illisible : '+s);
  }
  return t;
}
function parse(src){
  const T=tokenize(src);let p=0;
  const peek=()=>T[p],isOp=v=>T[p]&&T[p].t==='o'&&T[p].v===v;
  function cmp(){let a=cat();while(T[p]&&T[p].t==='o'&&['=','<>','<','>','<=','>='].indexOf(T[p].v)>=0){const op=T[p++].v;a={k:'b',op,a,b:cat()}}return a}
  function cat(){let a=add();while(isOp('&')){p++;a={k:'b',op:'&',a,b:add()}}return a}
  function add(){let a=mul();while(isOp('+')||isOp('-')){const op=T[p++].v;a={k:'b',op,a,b:mul()}}return a}
  function mul(){let a=pow();while(isOp('*')||isOp('/')){const op=T[p++].v;a={k:'b',op,a,b:pow()}}return a}
  function pow(){let a=un();while(isOp('^')){p++;a={k:'b',op:'^',a,b:un()}}return a}
  function un(){if(isOp('-')||isOp('+')){const op=T[p++].v;return{k:'u',op,a:un()}}return prim()}
  function prim(){
    const t=T[p++];if(!t)throw new Error('Formule incomplète : '+src);
    if(t.t==='n')return{k:'n',v:t.v};
    if(t.t==='s')return{k:'s',v:t.v};
    if(t.t==='c')return{k:'c',sh:t.sh,c:t.c,r:t.r};
    if(t.t==='r')return{k:'r',sh:t.sh,c1:t.c1,r1:t.r1,c2:t.c2,r2:t.r2};
    if(t.t==='f'){const args=[];if(!isOp(')')){for(;;){args.push(cmp());if(isOp(',')){p++;continue}break}}if(!isOp(')'))throw new Error('Parenthèse manquante : '+src);p++;return{k:'f',name:t.v,args}}
    if(t.t==='o'&&t.v==='('){const e=cmp();if(!isOp(')'))throw new Error('Parenthèse manquante : '+src);p++;return e}
    throw new Error('Formule inattendue : '+src);
  }
  const e=cmp();if(p<T.length)throw new Error('Formule inattendue : '+src);return e;
}
const AST=new Map();const astOf=s=>{let a=AST.get(s);if(!a){a=parse(s);AST.set(s,a)}return a};
const toNum=v=>{if(v===null||v===undefined)return 0;if(typeof v==='number')return v;if(typeof v==='boolean')return v?1:0;const s=String(v).trim();if(s===''||isNaN(Number(s)))XE('#VALUE!');return Number(s)};
const rank=v=>typeof v==='number'?1:typeof v==='string'?2:3;
function cmpVals(a,b,op){
  if(a===null&&b===null){a=0;b=0}
  else if(a===null)a=typeof b==='string'?'':typeof b==='boolean'?false:0;
  else if(b===null)b=typeof a==='string'?'':typeof a==='boolean'?false:0;
  let r;
  if(rank(a)!==rank(b))r=rank(a)-rank(b);
  else if(typeof a==='string'){const x=a.toLowerCase(),y=b.toLowerCase();r=x<y?-1:x>y?1:0}
  else{a=+a;b=+b;r=a<b?-1:a>b?1:0}
  return op==='='?r===0:op==='<>'?r!==0:op==='<'?r<0:op==='>'?r>0:op==='<='?r<=0:r>=0;
}
function Engine(model){this.m=model}
Engine.prototype.run=function(ov){
  const m=this.m,memo=new Map(),busy=new Set();
  function raw(sh,a){const o=ov&&ov[sh];if(o&&Object.prototype.hasOwnProperty.call(o,a))return o[a];const c=m[sh]&&m[sh][a];return c===undefined?null:c}
  function cell(sh,a){
    const k=sh+'!'+a;if(memo.has(k))return memo.get(k);
    let v=raw(sh,a);
    if(Array.isArray(v)&&v[0]==='f'){
      if(busy.has(k))return{err:'#REF!'};
      busy.add(k);
      try{v=ev(astOf(v[1]),sh);if(v&&v.rng)v=v.vals.length?v.vals[0]:null;if(v===null)v=0}
      catch(e){if(e instanceof XlErr)v={err:e.code};else throw e}
      busy.delete(k);
    }
    memo.set(k,v);return v;
  }
  function refVal(sh,a){const v=cell(sh,a);if(v&&typeof v==='object'&&v.err)XE(v.err);return v}
  function ev(n,sh){
    switch(n.k){
      case'n':case's':return n.v;
      case'c':return refVal(n.sh||sh,n.c+n.r);
      case'r':{const s=n.sh||sh,vals=[],c1=colNum(n.c1),c2=colNum(n.c2);for(let r=Math.min(n.r1,n.r2);r<=Math.max(n.r1,n.r2);r++)for(let c=Math.min(c1,c2);c<=Math.max(c1,c2);c++)vals.push(refVal(s,numCol(c)+r));return{rng:true,vals,c1:Math.min(c1,c2),r1:Math.min(n.r1,n.r2),w:Math.abs(c2-c1)+1}}
      case'u':{const v=ev(n.a,sh);return n.op==='-'?-toNum(v):(v===null?0:v)}
      case'b':{
        if(n.op==='&'){const a=ev(n.a,sh),b=ev(n.b,sh);return (a===null?'':String(a))+(b===null?'':String(b))}
        const a=ev(n.a,sh),b=ev(n.b,sh);
        if(['=','<>','<','>','<=','>='].indexOf(n.op)>=0)return cmpVals(a,b,n.op);
        const x=toNum(a),y=toNum(b);
        if(n.op==='+')return x+y;if(n.op==='-')return x-y;if(n.op==='*')return x*y;
        if(n.op==='/'){if(y===0)XE('#DIV/0!');return x/y}
        const r=Math.pow(x,y);if(!isFinite(r))XE('#NUM!');return r;
      }
      case'f':return fn(n,sh);
    }
    throw new Error('Nœud inconnu');
  }
  const bool=v=>{if(v===null||v===undefined)return false;if(typeof v==='boolean')return v;if(typeof v==='number')return v!==0;XE('#VALUE!')};
  function fn(n,sh){
    const A=n.args,N=n.name;
    if(N==='IF'){const c=bool(ev(A[0],sh));const x=c?A[1]:A[2];if(!x)return c;const v=ev(x,sh);return v&&v.rng?v.vals[0]:v}
    if(N==='AND'){let r=true;A.forEach(a=>{const v=ev(a,sh);(v&&v.rng?v.vals:[v]).forEach(x=>{if(!bool(x))r=false})});return r}
    if(N==='SUM'){let s=0;A.forEach(a=>{const v=ev(a,sh);if(v&&v.rng)v.vals.forEach(x=>{if(typeof x==='number')s+=x});else if(a.k==='c'){if(typeof v==='number')s+=v}else s+=toNum(v)});return s}
    if(N==='SQRT'){const x=toNum(ev(A[0],sh));if(x<0)XE('#NUM!');return Math.sqrt(x)}
    if(N==='VLOOKUP'){
      const key=ev(A[0],sh),R=ev(A[1],sh),col=toNum(ev(A[2],sh));
      if(!R||!R.rng)XE('#VALUE!');const w=R.w,rows=R.vals.length/w;
      for(let i=0;i<rows;i++){const k=R.vals[i*w];if(k!==null&&key!==null&&cmpVals(k,key,'=')){if(col<1||col>w)XE('#REF!');const v=R.vals[i*w+col-1];return v===null?0:v}}
      XE('#N/A');
    }
    XE('#NAME?');
  }
  return{get:(sh,a)=>cell(sh,a)};
};

/* ===================== Interface « Métré béton armé » ===================== */
const KEY='exb_metre',DRAFT='exb_metre_draft';
const ENG=new Engine(MODEL);
const $=id=>document.getElementById(id);
const ESC=v=>String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const NOTE0='Ce devis porte uniquement sur la fourniture des matériaux principaux (ciment, sable, gravier, fer) calculés automatiquement selon les dimensions saisies, ainsi que sur les matériaux ajoutés ci-dessus. Main d’œuvre, transport et finitions à ajouter séparément si nécessaire.';
const COMP={name:'EXCELLENCIA BUILDING',tag:'Ingénierie & Construction — Métré et Calcul de Structures',email:'excelenciabuilding@gmail.com',country:'République Démocratique du Congo'};
/* V99k — identité unique (EXBId) : nom, slogan, téléphone, e-mail, adresse, mentions légales, signature + cachet. L'ancien e-mail codé en dur (« excelenciabuilding ») n'est plus utilisé. */
let VISA='';
const ID=()=>{try{if(window.EXBId){const I=EXBId.get();return Object.assign({},I,{tag:I.tagline||COMP.tag})}}catch(e){}return{name:COMP.name,tag:COMP.tag,phone:'',email:COMP.email,address:'',country:COMP.country,logo:'',legal:'',city:''}};
const coName=H=>(H&&H.company&&String(H.company).trim().toUpperCase()!==COMP.name)?H.company:ID().name;
const frDate=d=>{const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(String(d||''));return m?m[3]+'/'+m[2]+'/'+m[1]:String(d||'')};
async function refreshVisa(){try{VISA=(window.EXBSign&&EXBSign.active())?(await EXBSign.visa('png')||''):''}catch(e){VISA=''}return VISA}
const ld=(k,d)=>{try{return typeof load==='function'?load(k,d):(JSON.parse(localStorage.getItem(k))??d)}catch(e){return d}};
const sv=(k,v)=>{try{return typeof save==='function'?save(k,v):(localStorage.setItem(k,JSON.stringify(v)),true)}catch(e){return false}};
const say=(m,t,ms)=>{try{notify(m,t||'info',ms||4000)}catch(e){alert(m)}};
const today=()=>{try{return todayISO()}catch(e){return new Date().toISOString().slice(0,10)}};
function blank(){return{id:null,name:'',ov:{P:{},Q:{},X:{},D:{}},hdr:{no:'',date:today(),validity:'30 jours',client:'',address:'',phone:'',email:'',project:'',place:'',nature:'',ref:'Voir onglet « Paramètres »',city:'',company:COMP.name,tag:COMP.tag,cemail:COMP.email,country:COMP.country,note:NOTE0},extra:[],logo:'',showLogo:true}}
let CTX=null,ST=null,R=null,TAB='par',saved=[],dirty=false,tmr=null;
const num=(sh,a)=>{const v=R.get(sh,a);return typeof v==='number'?v:0};
const val=(sh,a)=>{const v=R.get(sh,a);return v&&typeof v==='object'&&v.err?'#ERR':v};
const fx=(v,d)=>{if(v===null||v===undefined||v==='')return '';if(typeof v==='number'){if(!isFinite(v))return '';return v.toLocaleString('fr-FR',{minimumFractionDigits:0,maximumFractionDigits:d==null?3:d})}return String(v)};
const usd=v=>(Math.round(v*100)/100).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2});
const fc=v=>Math.round(v).toLocaleString('fr-FR',{maximumFractionDigits:0});
const isF=(sh,a)=>{const c=MODEL[sh]&&MODEL[sh][a];return Array.isArray(c)&&c[0]==='f'};
const cur=(sh,a)=>{const o=ST.ov[sh];if(o&&Object.prototype.hasOwnProperty.call(o,a))return o[a];const c=MODEL[sh]&&MODEL[sh][a];return c===undefined||Array.isArray(c)?null:c};
function calc(){R=ENG.run(ST.ov)}
/* ---- totaux du devis (lignes principales Excel + matériaux ajoutés) ---- */
function totals(){
  const taux=num('X','C4'),sub1=num('D','F21'),sub1fc=num('D','G21');
  const xs=ST.extra.reduce((a,l)=>a+(Number(l.q)||0)*(Number(l.pu)||0),0),imp=num('D','D22');
  const sub=sub1+xs,impv=sub*imp,tot=sub+impv;
  return{taux,sub1,sub1fc,xs,xsfc:xs*taux,sub,subfc:sub*taux,imp,impv,impfc:impv*taux,tot,totfc:tot*taux};
}
/* ---- éléments saisissables / calculés ---- */
const inp=(sh,a,o)=>{o=o||{};const v=cur(sh,a);return '<input class="mbi" type="number" step="any" inputmode="decimal" data-sh="'+sh+'" data-a="'+a+'"'+(o.min!=null?' min="'+o.min+'"':'')+' value="'+(v===null||v===undefined?'':ESC(v))+'">'};
const ro=(sh,a,d)=>'<span class="mbro" data-sh="'+sh+'" data-a="'+a+'" data-d="'+(d==null?3:d)+'">'+ESC(fx(val(sh,a),d))+'</span>';
const field=(label,sh,a,o)=>{o=o||{};
  if(o.sel){const v=cur(sh,a);return '<label class="mbf"><span>'+ESC(label)+'</span><select class="mbi" data-sh="'+sh+'" data-a="'+a+'" data-s="1">'+o.sel.map(x=>'<option'+(String(x)===String(v)?' selected':'')+'>'+ESC(x)+'</option>').join('')+'</select></label>'}
  if(isF(sh,a))return '<label class="mbf"><span>'+ESC(label)+'</span><b class="mbro" data-sh="'+sh+'" data-a="'+a+'" data-d="3" title="Valeur reprise automatiquement">'+ESC(fx(val(sh,a),3))+'</b></label>';
  return '<label class="mbf"><span>'+ESC(label)+(o.u===false?'':' <small>(cm)</small>')+'</span>'+inp(sh,a,o)+'</label>'};
/* ---- groupes de paramètres (cellules de l'onglet « Paramètres » du fichier Excel) ---- */
const SELT=['avec plancher','sans plancher'];
const DED=(t,rows,tot)=>({ded:1,t,rows,tot});
const GRP=[
 ['1/ INFRASTRUCTURE (dimensions en cm)',[
  {t:'Radier',f:[['Longueur','F6'],['Largeur','H6'],['Épaisseur','J6']]},
  {t:'Béton de propreté — semelles filantes',f:[['Largeur','F9'],['Épaisseur','H9'],['Longueur','J9']]},
  {t:'Semelles filantes',f:[['Largeur','F12'],['Hauteur','H12'],['Longueur','J12']]},
  {t:'Mur de soubassement',f:[['Type de mur','E14',{sel:['Mur de soubassement 15','Mur de soubassement 20']}],['Hauteur','F15'],['Longueur','H15']]},
  {t:'Chaînage bas',f:[['Largeur','F18'],['Hauteur','H18'],['Longueur','J18']]},
  {t:'Béton de propreté — semelles isolées',f:[['Longueur','F21'],['Largeur','H21'],['Épaisseur','J21'],['Nombre','L21',{u:false}]]},
  {t:'Semelles isolées',f:[['Longueur','F24'],['Largeur','H24'],['Hauteur','J24'],['Nombre','L24',{u:false}]]},
  {t:'Amorces de poteaux',f:[['Longueur','F27'],['Largeur','H27'],['Hauteur','J27'],['Nombre','L27',{u:false}]]},
  {t:'Longrines',f:[['Largeur','F30'],['Hauteur','H30'],['Longueur','J30'],['Nombre','L30',{u:false}]]},
  {t:'Amorces de raidisseurs verticaux',f:[['Longueur','F33'],['Largeur','H33'],['Hauteur','J33'],['Nombre','L33',{u:false}]]},
  {t:'Voiles en BA',f:[['Épaisseur','F36'],['Hauteur','H36'],['Longueur','J36']]},
  {t:'Dallage',f:[['Longueur','F39'],['Largeur','H39'],['Épaisseur','J39'],['Nombre','L39',{u:false}]]}]],
 ['2/ SUPERSTRUCTURE / RDC (dimensions en cm)',[
  {t:'Mur en élévation 15',f:[['Hauteur','F45'],['Longueur','H45']]},
  DED('Mur 15 — à déduire (portes, fenêtres…)',[49,50,51,52,53],54),
  {t:'Mur en élévation 10',f:[['Hauteur','F56'],['Longueur','H56']]},
  DED('Mur 10 — à déduire',[60,61,62,63,64],65),
  {t:'Linteaux',f:[['Largeur / épaisseur','F67'],['Hauteur','H67'],['Longueur','J67']]},
  {t:'Claustras',f:[['Hauteur','F70'],['Longueur','H70']]},
  {t:'Chaînage haut',f:[['Largeur','F73'],['Hauteur','H73'],['Longueur','J73']]},
  {t:'Poteaux',f:[['Longueur','F76'],['Largeur','H76'],['Hauteur','J76'],['Nombre','L76',{u:false}]]},
  {t:'Voiles en BA',f:[['Épaisseur','F79'],['Hauteur','H79'],['Longueur','J79']]},
  {t:'Raidisseurs verticaux',f:[['Longueur','F82'],['Largeur','H82'],['Hauteur','J82'],['Nombre','L82',{u:false}]]},
  {t:'Poutres en BA',f:[['Largeur','F85'],['Hauteur','H85'],['Longueur','J85'],['Nombre','L85',{u:false}]]},
  {t:'Escaliers',f:[['Nombre de volées','F88',{sel:[1,2]}],['Marches par volée','I88',{u:false}],['Épaisseur de la paillasse','L88'],['Largeur de marche','F90'],['Hauteur de marche','H90'],['Giron','J90'],['Jour','L90'],['Épaisseur du palier de repos','H92']]},
  {t:'Hourdis (dalle de compression / nervures)',f:[['Longueur','F95'],['Largeur','H95'],['Épaisseur','J95'],['Nombre','L95',{u:false}]]}]],
 ['3/ ÉTAGE (dimensions en cm)',[
  {t:'Paramètres d’étage',f:[['Nombre d’étages','H99',{u:false,min:1}],['Type de toiture','H101',{sel:SELT}]]},
  {t:'Mur en élévation 15',f:[['Hauteur','F105'],['Longueur','H105']]},
  DED('Mur 15 — à déduire',[109,110,111,112,113],114),
  {t:'Mur en élévation 10',f:[['Hauteur','F116'],['Longueur','H116']]},
  DED('Mur 10 — à déduire',[120,121,122,123,124],125),
  {t:'Linteaux',f:[['Largeur / épaisseur','F127'],['Hauteur','H127'],['Longueur','J127']]},
  {t:'Claustras',f:[['Hauteur','F130'],['Longueur','H130']]},
  {t:'Chaînage haut',f:[['Largeur','F133'],['Hauteur','H133'],['Longueur','J133']]},
  {t:'Poteaux',f:[['Longueur','F136'],['Largeur','H136'],['Hauteur','J136'],['Nombre','L136',{u:false}]]},
  {t:'Voiles en BA',f:[['Épaisseur','F139'],['Hauteur','H139'],['Longueur','J139']]},
  {t:'Raidisseurs verticaux',f:[['Longueur','F142'],['Largeur','H142'],['Hauteur','J142'],['Nombre','L142',{u:false}]]},
  {t:'Poutres en BA',f:[['Largeur','F145'],['Hauteur','H145'],['Longueur','J145'],['Nombre','L145',{u:false}]]},
  {t:'Escaliers',f:[['Nombre de volées','F148',{sel:[1,2]}],['Marches par volée','I148',{u:false}],['Épaisseur de la paillasse','L148'],['Largeur de marche','F150'],['Hauteur de marche','H150'],['Giron','J150'],['Jour','L150'],['Épaisseur du palier de repos','H152']]},
  {t:'Hourdis (dalle de compression / nervures)',f:[['Longueur','F155'],['Largeur','H155'],['Épaisseur','J155'],['Nombre','L155',{u:false}]]}]]
];
function dedHTML(g){
  return '<div class="mbc mbwide"><h4>'+ESC(g.t)+'</h4><div class="mbscroll"><table class="mbt"><thead><tr><th></th><th>Long./larg. (cm)</th><th>Hauteur (cm)</th><th>Nombre</th><th>Surface (cm²)</th></tr></thead><tbody>'+
   g.rows.map((r,i)=>'<tr><td>n°'+(i+1)+'</td><td>'+inp('P','F'+r)+'</td><td>'+inp('P','H'+r)+'</td><td>'+inp('P','J'+r)+'</td><td>'+ro('P','K'+r,0)+'</td></tr>').join('')+
   '</tbody></table></div><div class="mbtot">Total à déduire : '+ro('P','K'+g.tot,3)+' m²</div></div>'}
function parHTML(){
  return '<p class="mbhint">Saisissez les dimensions en <b>cm</b>. Les quantités de ciment, sable, gravier et fer sont recalculées automatiquement. Les valeurs en gris sont reprises d’une autre rubrique.</p>'+
  GRP.map(sec=>'<h3 class="mbsec">'+ESC(sec[0])+'</h3><div class="mbgrid">'+sec[1].map(g=>g.ded?dedHTML(g):'<div class="mbc"><h4>'+ESC(g.t)+'</h4>'+g.f.map(f=>field(f[0],'P',f[1],f[2])).join('')+'</div>').join('')+'</div>').join('')}
/* ---- Quantité béton ---- */
const QSEC=[['INFRASTRUCTURE',[50,51,52,53,54,55,56,57,58,59,60,61],62],['SUPERSTRUCTURE / RDC',[65,66,67,68,69,70,71,72,73],74],['ÉTAGE',[77,78,79,80,81,82,83,84,85],86]];
const qin=(a,d)=>{const c=MODEL.Q[a];if(c===undefined)return '';return isF('Q',a)?ro('Q',a,d==null?3:d):inp('Q',a)};
function qtyHTML(){
  let h='<p class="mbhint">Détail par ouvrage (dosages modifiables : ciment en kg/m³, sable et gravier en m³ par m³ de béton, fer en kg/m³).</p><div class="mbscroll"><table class="mbt mbq"><thead><tr><th rowspan="2">Désignation</th><th rowspan="2">Unité</th><th rowspan="2">Quantité</th><th colspan="2">Ciment (t)</th><th colspan="2">Sable (m³)</th><th colspan="2">Gravier (t)</th><th colspan="2">Fer (t)</th></tr><tr><th>Dosage</th><th>Qté</th><th>Dosage</th><th>Qté</th><th>Dosage</th><th>Qté</th><th>Ratio</th><th>Qté</th></tr></thead><tbody>';
  QSEC.forEach(s=>{
    h+='<tr class="mbh"><td colspan="11">'+ESC(s[0])+'</td></tr>';
    s[1].forEach(r=>{h+='<tr><td>'+ro('Q','B'+r,3)+'</td><td>'+ESC(MODEL.Q['C'+r]||'')+'</td><td>'+ro('Q','D'+r,4)+'</td><td>'+qin('E'+r)+'</td><td>'+ro('Q','F'+r,3)+'</td><td>'+qin('G'+r)+'</td><td>'+ro('Q','H'+r,3)+'</td><td>'+qin('I'+r)+'</td><td>'+ro('Q','J'+r,3)+'</td><td>'+qin('K'+r)+'</td><td>'+ro('Q','L'+r,4)+'</td></tr>'});
    const t=s[2];h+='<tr class="mbs"><td colspan="3">'+(s[0]==='ÉTAGE'?'TOTAUX POUR TOUS LES ÉTAGES':'TOTAL')+'</td><td></td><td>'+ro('Q','F'+t,3)+'</td><td></td><td>'+ro('Q','H'+t,3)+'</td><td></td><td>'+ro('Q','J'+t,3)+'</td><td></td><td>'+ro('Q','L'+t,4)+'</td></tr>'});
  h+='</tbody></table></div>';
  h+='<h3 class="mbsec">Confection et montage d’agglomérés</h3><div class="mbscroll"><table class="mbt"><thead><tr><th>Désignation</th><th>Unité</th><th>Quantité</th><th>Ratio / m²</th><th>Nbre total</th><th>Ratio / tonne</th><th>Ciment (t)</th><th>Sable (m³)</th></tr></thead><tbody>';
  [['INFRASTRUCTURE',[92]],['SUPERSTRUCTURE / RDC',[95,96,97,98]],['ÉTAGE',[101,102,103,104]]].forEach(s=>{
    h+='<tr class="mbh"><td colspan="8">'+s[0]+'</td></tr>';
    s[1].forEach(r=>{h+='<tr><td>'+ro('Q','B'+r,3)+'</td><td>'+ESC(MODEL.Q['C'+r]||'')+'</td><td>'+ro('Q','D'+r,3)+'</td><td>'+qin('E'+r)+'</td><td>'+ro('Q','F'+r,2)+'</td><td>'+qin('G'+r)+'</td><td>'+ro('Q','H'+r,3)+'</td><td>'+ro('Q','I'+r,3)+'</td></tr>'})});
  h+='</tbody></table></div><div class="mbscroll"><table class="mbt"><thead><tr><th>Récapitulatif agglomérés</th><th>Ciment (t)</th><th>Sable (m³)</th></tr></thead><tbody>';
  [106,107,109,110,112,113,115,116,118].forEach(r=>{h+='<tr'+(r===118?' class="mbs"':'')+'><td>'+ESC(MODEL.Q['F'+r]||'')+'</td><td>'+ro('Q','H'+r,3)+'</td><td>'+ro('Q','J'+r,3)+'</td></tr>'});
  h+='</tbody></table></div>';
  h+='<h3 class="mbsec">Récapitulatif global des matériaux à commander</h3><div class="mbrecap">'+[41,42,43,44].map(r=>'<div><span>'+ESC(String(MODEL.Q['C'+r]||'').replace(/\s*:\s*$/,''))+'</span><b>'+ro('Q','D'+r,3)+'</b> <small>'+ESC(MODEL.Q['E'+r]||'')+'</small></div>').join('')+'</div>';
  h+='<details class="mbdet"><summary>Statistiques détaillées par ouvrage</summary>'+statsHTML()+'</details>';
  return h}
function statsHTML(){
  const blocks=[['Béton / ossature','B','C','D','B'],['Agglomérés','F','G','H','E'],['Dallage et planchers','J','K','L','I']];
  return blocks.map(b=>{
    let rows=[];
    for(let r=2;r<=38;r++){
      const head=MODEL.Q[b[4]+r],lab=MODEL.Q[b[1]+r],v=MODEL.Q[b[2]+r];
      if(b[4]!==b[1]&&typeof head==='string'&&!/^\(/.test(head))rows.push('<div class="mbsh">'+ESC(head)+'</div>');
      if(b[4]===b[1]&&typeof lab==='string'&&v===undefined&&!/^\(/.test(lab)&&lab.trim())rows.push('<div class="mbsh">'+ESC(lab)+'</div>');
      else if(lab!==undefined&&Array.isArray(v)){rows.push('<div class="mbsr"><span>'+ro('Q',b[1]+r,3)+'</span><b>'+ro('Q',b[2]+r,3)+'</b> <small>'+ESC(MODEL.Q[b[3]+r]||'')+'</small></div>')}}
    return '<h4>'+ESC(b[0])+'</h4>'+rows.join('')}).join('')}
/* ---- Prix des matériaux ---- */
function prixHTML(){
  let h='<div class="mbrate"><label class="mbf"><span>Taux de change appliqué <small>(FC pour 1 USD)</small></span>'+inp('X','C4')+'</label><p class="mbhint">Mettez à jour selon le taux du jour. Les chiffres modifiables sont les cases à saisir.</p></div>';
  h+='<h3 class="mbsec">1/ Prix unitaires des matériaux</h3><div class="mbscroll"><table class="mbt"><thead><tr><th>Désignation</th><th>Unité</th><th>Prix RDC ($)</th><th>Prix RDC (FC)</th><th>Prix étage ($)</th><th>Prix étage (FC)</th></tr></thead><tbody>';
  for(let r=8;r<=19;r++)h+='<tr><td>'+ESC(MODEL.X['B'+r])+'</td><td>'+ESC(MODEL.X['C'+r])+'</td><td>'+inp('X','D'+r)+'</td><td>'+ro('X','E'+r,0)+'</td><td>'+inp('X','F'+r)+'</td><td>'+ro('X','G'+r,0)+'</td></tr>';
  h+='</tbody></table></div><h3 class="mbsec">2/ Coût automatique des matériaux principaux</h3><p class="mbhint">Quantités reprises de l’onglet « Quantité béton ».</p><div class="mbscroll"><table class="mbt"><thead><tr><th>Désignation</th><th>Unité</th><th>Qté Infra + RDC</th><th>Qté étage</th><th>Prix RDC ($)</th><th>Prix étage ($)</th><th>Coût Infra+RDC ($)</th><th>Coût étage ($)</th><th>Total ($)</th><th>Total (FC)</th></tr></thead><tbody>';
  for(let r=27;r<=30;r++)h+='<tr><td>'+ESC(MODEL.X['B'+r])+'</td><td>'+ESC(MODEL.X['C'+r])+'</td><td>'+ro('X','D'+r,3)+'</td><td>'+ro('X','E'+r,3)+'</td><td>'+ro('X','F'+r,2)+'</td><td>'+ro('X','G'+r,2)+'</td><td>'+ro('X','H'+r,2)+'</td><td>'+ro('X','I'+r,2)+'</td><td>'+ro('X','J'+r,2)+'</td><td>'+ro('X','K'+r,0)+'</td></tr>';
  h+='<tr class="mbs"><td colspan="6">TOTAL GÉNÉRAL</td><td>'+ro('X','H31',2)+'</td><td>'+ro('X','I31',2)+'</td><td>'+ro('X','J31',2)+'</td><td>'+ro('X','K31',0)+'</td></tr></tbody></table></div>';
  h+='<p class="mbhint">Les agglomérés, claustras, hourdis, bois de coffrage, eau et main d’œuvre s’ajoutent dans l’onglet « Matériaux ajoutés » : ils sont alors repris dans le devis.</p>';return h}
/* ---- Matériaux ajoutés ---- */
const SUG={12:()=>num('Q','G9'),13:()=>num('Q','G24')+num('Q','G36'),14:()=>num('Q','G25')+num('Q','G37'),15:()=>num('Q','G26')+num('Q','G38'),16:()=>num('Q','K26')+num('Q','K38')};
function extraHTML(){
  let h='<p class="mbhint">Ajoutez ici tout matériau ou service qui doit figurer dans le devis (agglos, hourdis, bois de coffrage, main d’œuvre, transport…). Les lignes sont reprises dans l’onglet « Devis » et dans le PDF.</p>';
  h+='<div class="mbadd"><select id="mb_pick"><option value="">— Choisir dans la grille des prix —</option>'+[12,13,14,15,16,17,18,19].map(r=>'<option value="'+r+'">'+ESC(MODEL.X['B'+r])+' ('+ESC(MODEL.X['C'+r])+')</option>').join('')+'</select><button class="primary" data-act="addpick">➕ Ajouter</button><button class="muted" data-act="addfree">➕ Ligne libre</button></div>';
  h+='<div class="mbscroll"><table class="mbt"><thead><tr><th>Désignation</th><th>Unité</th><th>Quantité</th><th>PU ($)</th><th>Montant ($)</th><th>Montant (FC)</th><th></th></tr></thead><tbody>';
  if(!ST.extra.length)h+='<tr><td colspan="7" class="mbmuted">Aucun matériau ajouté.</td></tr>';
  ST.extra.forEach((l,i)=>{h+='<tr><td><input class="mbx" data-i="'+i+'" data-k="d" value="'+ESC(l.d)+'"></td><td><input class="mbx mbs6" data-i="'+i+'" data-k="u" value="'+ESC(l.u)+'"></td><td><input class="mbx" type="number" step="any" inputmode="decimal" data-i="'+i+'" data-k="q" value="'+ESC(l.q)+'"></td><td><input class="mbx" type="number" step="any" inputmode="decimal" data-i="'+i+'" data-k="pu" value="'+ESC(l.pu)+'"></td><td><span class="mbk" data-k="xa'+i+'"></span></td><td><span class="mbk" data-k="xf'+i+'"></span></td><td><button class="danger" data-act="delx" data-i="'+i+'">×</button></td></tr>'});
  h+='</tbody></table></div><div class="mbtot">Total des matériaux ajoutés : <span class="mbk" data-k="xs"></span> $</div>';return h}
/* ---- Devis ---- */
const hin=(k,l,t)=>'<label class="mbf"><span>'+l+'</span><input class="mbh2" data-h="'+k+'"'+(t?' type="'+t+'"':'')+' value="'+ESC(ST.hdr[k])+'"></label>';
function devisHTML(){
  let h='<div class="mbcard"><div class="mbcomp">'+(ST.showLogo?'<img class="mblogo" src="'+ESC(ST.logo||logoSrc())+'" alt="Logo">':'')+'<div><b>'+ESC(ST.hdr.company)+'</b><div class="mbmuted">'+ESC(ST.hdr.tag)+'</div></div></div>'+
   '<div class="mbrow"><label class="mbck"><input type="checkbox" data-act="logoon"'+(ST.showLogo?' checked':'')+'> Afficher le logo dans le devis</label><label class="mbbtn">🖼 Changer le logo<input type="file" accept="image/*" hidden data-act="logofile"></label>'+(ST.logo?'<button class="muted" data-act="logodef">↺ Logo d’origine</button>':'')+'</div></div>';
  h+='<div class="mbgrid"><div class="mbc"><h4>Devis</h4>'+hin('no','N° du devis')+hin('date','Date','date')+hin('validity','Validité de l’offre')+'</div><div class="mbc"><h4>Client</h4>'+hin('client','Nom / raison sociale')+hin('address','Adresse')+hin('phone','Téléphone')+hin('email','E-mail')+'</div><div class="mbc"><h4>Projet</h4>'+hin('project','Nom du projet')+hin('place','Lieu / commune')+hin('nature','Nature')+hin('ref','Référence paramètres')+'</div><div class="mbc"><h4>Société</h4>'+hin('company','Nom')+hin('tag','Activité')+hin('cemail','E-mail')+hin('country','Pays')+'</div></div>';
  h+='<h3 class="mbsec">Récapitulatif des matériaux</h3><div class="mbscroll"><table class="mbt"><thead><tr><th>Désignation</th><th>Unité</th><th>Quantité</th><th>PU ($)</th><th>Montant ($)</th><th>Montant (FC)</th><th></th></tr></thead><tbody>';
  for(let r=17;r<=20;r++)h+='<tr><td>'+ESC(MODEL.D['B'+r])+'</td><td>'+ESC(MODEL.D['C'+r])+'</td><td>'+ro('D','D'+r,3)+'</td><td>'+ro('D','E'+r,2)+'</td><td>'+ro('D','F'+r,2)+'</td><td>'+ro('D','G'+r,0)+'</td><td></td></tr>';
  ST.extra.forEach((l,i)=>{h+='<tr class="mbxr"><td><input class="mbx" data-i="'+i+'" data-k="d" placeholder="Désignation du matériau" value="'+ESC(l.d)+'"></td><td><input class="mbx mbs6" data-i="'+i+'" data-k="u" value="'+ESC(l.u)+'"></td><td><input class="mbx" type="number" step="any" inputmode="decimal" data-i="'+i+'" data-k="q" value="'+ESC(l.q)+'"></td><td><input class="mbx" type="number" step="any" inputmode="decimal" data-i="'+i+'" data-k="pu" value="'+ESC(l.pu)+'"></td><td><span class="mbk" data-k="xa'+i+'"></span></td><td><span class="mbk" data-k="xf'+i+'"></span></td><td><button class="danger" data-act="delx" data-i="'+i+'" title="Supprimer cette ligne">×</button></td></tr>'});
  h+='<tr class="mbs"><td colspan="4">Sous-total</td><td><span class="mbk" data-k="sub"></span></td><td><span class="mbk" data-k="subfc"></span></td><td></td></tr>';
  h+='<tr><td colspan="2">Divers &amp; imprévus (%)</td><td><input class="mbi" type="number" step="any" inputmode="decimal" data-pct="1" value="'+ESC(Math.round(num('D','D22')*10000)/100)+'"></td><td></td><td><span class="mbk" data-k="impv"></span></td><td><span class="mbk" data-k="impfc"></span></td><td></td></tr>';
  h+='<tr class="mbs mbg"><td colspan="4">TOTAL GÉNÉRAL</td><td><span class="mbk" data-k="tot"></span></td><td><span class="mbk" data-k="totfc"></span></td><td></td></tr></tbody></table></div>';
  h+='<div class="mbadd"><select id="mb_pick"><option value="">— Matériau de la grille des prix —</option>'+[12,13,14,15,16,17,18,19].map(r=>'<option value="'+r+'">'+ESC(MODEL.X['B'+r])+' ('+ESC(MODEL.X['C'+r])+')</option>').join('')+'</select><button class="primary" data-act="addpick">➕ Ajouter ce matériau</button><button class="primary" data-act="addfree">➕ Ajouter une ligne</button></div><p class="mbhint">Un matériau manque ? Ajoutez une ligne : désignation, unité, quantité et prix unitaire se saisissent directement dans le tableau.</p>';
  h+='<label class="mbf"><span>Note du devis</span><textarea class="mbh2" data-h="note" rows="3">'+ESC(ST.hdr.note)+'</textarea></label>';
  h+='<div class="mbrow"><button class="primary" data-act="pdf">📄 Exporter en PDF (A4)</button><button class="muted" data-act="print">🖨 Imprimer</button><button class="muted" data-act="suivi">📋 Suivi / envoi</button><button class="muted" data-act="toquote">📤 Ajouter aux devis enregistrés</button></div><p class="mbhint">Les matériaux ajoutés s’ajoutent au sous-total ; les « divers &amp; imprévus » s’appliquent sur l’ensemble.</p>';return h}
function logoSrc(){try{return typeof getLogo==='function'?getLogo('exb'):'icon-192.png'}catch(e){return 'icon-192.png'}}
/* ---- mise à jour des valeurs calculées sans reconstruire les champs ---- */
function refresh(){
  const P=$('mb_body');if(!P)return;
  P.querySelectorAll('.mbro').forEach(e=>{e.textContent=fx(val(e.dataset.sh,e.dataset.a),+e.dataset.d)});
  const T=totals(),K={sub:usd(T.sub),subfc:fc(T.subfc),impv:usd(T.impv),impfc:fc(T.impfc),tot:usd(T.tot),totfc:fc(T.totfc),xs:usd(T.xs)};
  ST.extra.forEach((l,i)=>{const a=(Number(l.q)||0)*(Number(l.pu)||0);K['xa'+i]=usd(a);K['xf'+i]=fc(a*T.taux)});
  P.querySelectorAll('.mbk').forEach(e=>{if(K[e.dataset.k]!==undefined)e.textContent=K[e.dataset.k]});
  const s=$('mb_sum');if(s)s.innerHTML='<span>Ciment <b>'+fx(num('Q','D41'),2)+' t</b></span><span>Sable <b>'+fx(num('Q','D42'),2)+' m³</b></span><span>Gravier <b>'+fx(num('Q','D43'),2)+' t</b></span><span>Fer <b>'+fx(num('Q','D44'),3)+' t</b></span><span class="mbtotal">Devis <b>'+usd(T.tot)+' $</b> · '+fc(T.totfc)+' FC</span>';
}
function body(){return TAB==='par'?parHTML():TAB==='qty'?qtyHTML():TAB==='prix'?prixHTML():TAB==='ext'?extraHTML():devisHTML()}
function render(){
  const P=$('mb_panel');if(!P)return;
  calc();
  const tabs=[['par','⚙️ Paramètres'],['qty','🧱 Quantité béton'],['prix','💲 Prix matériaux'],['ext','➕ Matériaux ajoutés'+(ST.extra.length?' ('+ST.extra.length+')':'')],['dev','🧾 Devis']];
  P.innerHTML='<div class="mbtop"><select id="mb_sel"><option value="">— Métrés enregistrés ('+saved.length+') —</option>'+saved.map(s=>'<option value="'+ESC(s.id)+'"'+(ST.id===s.id?' selected':'')+'>'+ESC(s.name||s.hdr.no||s.id)+'</option>').join('')+'</select><button class="muted" data-act="new">Nouveau</button><button class="primary" data-act="save">💾 Enregistrer</button>'+(ST.id?'<button class="danger" data-act="del">🗑</button>':'')+'</div><div id="mb_sum" class="mbsum"></div><div class="mbtabs">'+tabs.map(t=>'<button data-act="tab" data-t="'+t[0]+'" class="'+(t[0]===TAB?'on':'')+'">'+t[1]+'</button>').join('')+'</div><div id="mb_body">'+body()+'</div><p class="mbcredit">Méthode de calcul : fichier « Metrec 2026 » — © IBWAMPERE NGWALA LOUIS. Résultats identiques à ceux du fichier Excel.</p>';
  calc();refresh();
}
function touch(){dirty=true;clearTimeout(tmr);tmr=setTimeout(()=>{sv(DRAFT,ST)},700)}
/* ---- Mise en page A4 : PDF multi-pages et impression (lignes jamais coupées) ---- */
const PW=794,PH=1120,PADX=36,PADT=32,FOOT=54;               /* A4 à 96 dpi ; marges ≈ 9 mm */
const TDS='border:1px solid #cbd5e1;padding:6px 8px;line-height:1.3;word-break:break-word;',THS='background:#173565;color:#fff;border:1px solid #173565;padding:7px 6px;font-size:11.5px;';
const COLG='<colgroup><col style="width:34%"><col style="width:10%"><col style="width:14%"><col style="width:12%"><col style="width:15%"><col style="width:15%"></colgroup>';
const TBL='width:100%;border-collapse:collapse;table-layout:fixed;';
function docLines(){
  if(CTX)return CTX.lines;
  const T=totals(),L=[];
  for(let r=17;r<=20;r++)L.push([MODEL.D['B'+r],MODEL.D['C'+r],num('D','D'+r),num('D','E'+r),num('D','F'+r),num('D','G'+r)]);
  ST.extra.forEach(l=>{const a=(Number(l.q)||0)*(Number(l.pu)||0);L.push([l.d||'—',l.u||'',Number(l.q)||0,Number(l.pu)||0,a,a*T.taux])});
  return L}
const rowN=(r,i)=>'<tr style="background:'+(i%2?'#f8fafc':'#fff')+'"><td style="'+TDS+'">'+ESC(r[0])+'</td><td style="'+TDS+'text-align:center">'+ESC(r[1])+'</td><td style="'+TDS+'text-align:right">'+ESC(fx(r[2],3))+'</td><td style="'+TDS+'text-align:right">'+usd(r[3])+'</td><td style="'+TDS+'text-align:right">'+usd(r[4])+'</td><td style="'+TDS+'text-align:right">'+fc(r[5])+'</td></tr>';
const rowH=(r,i)=>r&&r.k==='sec'?'<tr><td colspan="6" style="'+TDS+'background:#eef2f7;color:#173565;font-weight:700">'+ESC(r[0])+'</td></tr>':r&&r.k==='sub'?'<tr><td colspan="4" style="'+TDS+'text-align:right;font-weight:700">'+ESC(r[0])+'</td><td style="'+TDS+'text-align:right;font-weight:700">'+usd(r[4])+'</td><td style="'+TDS+'text-align:right;font-weight:700">'+fc(r[5])+'</td></tr>':rowN(r,i);
const theadH='<thead><tr><th style="'+THS+'text-align:left">Désignation</th><th style="'+THS+'">Unité</th><th style="'+THS+'text-align:right">Quantité</th><th style="'+THS+'text-align:right">PU ($)</th><th style="'+THS+'text-align:right">Montant ($)</th><th style="'+THS+'text-align:right">Montant (FC)</th></tr></thead>';
function headH(){
  const H=CTX?CTX.hdr:ST.hdr,I=ID(),c='color:#475569;font-size:12px',lg=(CTX?CTX.logo:ST.logo)||I.logo||logoSrc();
  const contact=window.EXBId?EXBId.contactLine(I):('E-mail : '+I.email),place=window.EXBId?EXBId.placeLine(I):I.country,legal=window.EXBId?EXBId.legalLine(I):'';
  return '<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #c9a227;padding-bottom:12px"><div style="display:flex;gap:14px;align-items:center">'+((CTX?CTX.showLogo:ST.showLogo)?'<img src="'+ESC(lg)+'" style="width:78px;height:78px;object-fit:contain">':'')+'<div><div style="font-size:21px;font-weight:700;color:#173565">'+ESC(coName(H))+'</div>'+
   (I.tag?'<div style="'+c+'">'+ESC(I.tag)+'</div>':'')+(contact?'<div style="'+c+'">'+ESC(contact)+'</div>':'')+(place?'<div style="'+c+'">'+ESC(place)+'</div>':'')+(legal?'<div style="color:#64748b;font-size:10.5px;margin-top:2px">'+ESC(legal)+'</div>':'')+'</div></div>'+
   '<div style="text-align:right"><div style="font-size:26px;font-weight:700;color:#173565;letter-spacing:2px">DEVIS</div><div style="font-size:12px">N° : <b>'+ESC(H.no)+'</b></div><div style="font-size:12px">Date : <b>'+ESC(frDate(H.date))+'</b></div><div style="font-size:12px">Validité : <b>'+ESC(H.validity)+'</b></div></div></div>'}
function miniHeadH(){
  const H=CTX?CTX.hdr:ST.hdr;
  return '<div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #c9a227;padding-bottom:8px;margin-bottom:10px"><b style="color:#173565;font-size:14px">'+ESC(coName(H))+'</b><span style="font-size:12px;color:#475569">DEVIS N° <b>'+ESC(H.no)+'</b> — '+ESC(H.client)+'</span></div>'}
function infoH(){
  const H=CTX?CTX.hdr:ST.hdr,box=(t,rows)=>'<div style="flex:1;border:1px solid #cbd5e1;border-radius:6px;padding:9px 10px"><div style="font-weight:700;color:#173565;margin-bottom:4px">'+t+'</div>'+rows.filter(x=>!CTX||String(x[1]||'').trim()).map(x=>'<div style="font-size:12px"><span style="color:#64748b">'+x[0]+' :</span> '+ESC(x[1])+'</div>').join('')+'</div>';
  return '<div style="display:flex;gap:14px;margin:14px 0">'+box('CLIENT',[['Nom / raison sociale',H.client],['Adresse',H.address],['Téléphone',H.phone],['E-mail',H.email]])+box('PROJET',[['Nom du projet',H.project],['Lieu / commune',H.place],['Nature',H.nature],['Référence',/^Voir onglet/i.test(H.ref||'')?'':H.ref]])+'</div>'+
   '<div style="font-weight:700;color:#173565;margin-bottom:6px">'+(CTX&&CTX.title?CTX.title:'RÉCAPITULATIF DES MATÉRIAUX')+'</div>'}
function finalH(){
  const T=CTX?CTX.T:totals(),H=CTX?CTX.hdr:ST.hdr,td='style="'+TDS;
  return '<table style="'+TBL+'">'+COLG+'<tbody>'+
   '<tr><td '+td+'font-weight:700" colspan="4">Sous-total</td><td '+td+'text-align:right;font-weight:700">'+usd(T.sub)+'</td><td '+td+'text-align:right;font-weight:700">'+fc(T.subfc)+'</td></tr>'+
   (CTX&&CTX.noImp&&!(T.imp>0)?'':'<tr><td '+td+'" colspan="4">Divers &amp; imprévus ('+(Math.round(T.imp*10000)/100)+' %)</td><td '+td+'text-align:right">'+usd(T.impv)+'</td><td '+td+'text-align:right">'+fc(T.impfc)+'</td></tr>')+
   '<tr><td '+td+'background:#173565;color:#fff;font-weight:700" colspan="4">TOTAL GÉNÉRAL</td><td '+td+'background:#173565;color:#fff;text-align:right;font-weight:700">'+usd(T.tot)+' $</td><td '+td+'background:#173565;color:#fff;text-align:right;font-weight:700">'+fc(T.totfc)+' FC</td></tr></tbody></table>'+
   '<div style="font-size:11px;color:#64748b;margin-top:6px">Taux de change appliqué : 1 USD = '+fc(T.taux)+' FC</div>'+
   (H.note?'<div style="margin-top:12px;font-size:12px;color:#334155;line-height:1.5;white-space:pre-wrap">'+ESC(H.note)+'</div>':'')+
   '<div style="display:flex;justify-content:space-between;margin-top:20px;font-size:12px"><div>Fait à : '+(ID().city?'<b>'+ESC(ID().city)+'</b>':'____________________')+'</div><div>Le '+(H.date?'<b>'+ESC(frDate(H.date))+'</b>':'______ / ______ / __________')+'</div></div>'+
   '<div style="display:flex;justify-content:space-between;margin-top:14px;font-size:12px"><div style="width:44%;text-align:center"><div style="height:96px;display:flex;align-items:flex-end;justify-content:center">'+(VISA?'<img src="'+VISA+'" style="max-height:96px;max-width:100%;object-fit:contain">':'')+'</div><div style="border-top:1px solid #475569;padding-top:4px">Signature du prestataire'+(ID().dg?'<br><b>'+ESC(ID().dg)+'</b>'+(ID().dgRole?' · '+ESC(ID().dgRole):''):'')+'</div></div><div style="width:44%;text-align:center"><div style="height:96px"></div><div style="border-top:1px solid #475569;padding-top:4px">Signature du client (bon pour accord)</div></div></div>'}
/* découpe le devis en pages : mesure réelle de chaque bloc, lignes jamais coupées, en-tête du tableau répété, totaux + signatures groupés */
function buildPages(){
  const L=docLines(),H=CTX?CTX.hdr:ST.hdr,AV=PH-PADT-FOOT;
  const m=document.createElement('div');m.style.cssText='position:absolute;left:-100000px;top:0;width:'+(PW-2*PADX)+'px;font-family:Arial,sans-serif;font-size:13px;color:#172033;background:#fff';document.body.appendChild(m);
  const hh=h=>{m.innerHTML=h;return m.getBoundingClientRect().height};
  let pages=[];
  try{
    const hHead=hh(headH()+infoH()),hMini=hh(miniHeadH()),hThead=hh('<table style="'+TBL+'">'+COLG+theadH+'</table>'),hFin=hh(finalH());
    const rh=L.map((r,i)=>hh('<table style="'+TBL+'">'+COLG+'<tbody>'+rowH(r,i)+'</tbody></table>'));
    let cur=null;
    const open=()=>{const first=!pages.length;cur={rows:[],used:(first?hHead:hMini)+hThead,first};pages.push(cur)};
    open();
    L.forEach((r,i)=>{if(cur.used+rh[i]>AV&&cur.rows.length){open()}cur.rows.push(i);cur.used+=rh[i]});
    /* totaux + signatures : doivent tenir sur la même page que les dernières lignes */
    if(cur.used+hFin>AV){
      const back=[];while(cur.rows.length>2&&cur.used+hFin>AV&&back.length<2){const i=cur.rows.pop();cur.used-=rh[i];back.unshift(i)}
      if(cur.used+hFin>AV||!back.length){open();cur.rows=back;cur.used=hMini+hThead+back.reduce((a,i)=>a+rh[i],0);if(cur.used+hFin>AV){open();cur.used=hMini}}
      else{open();cur.rows=back;cur.used=hMini+hThead+back.reduce((a,i)=>a+rh[i],0)}
    }
    cur.final=true;
  }finally{m.remove()}
  const N=pages.length;
  return pages.map((p,k)=>{
    const body=(p.first?headH()+infoH():miniHeadH())+(p.rows.length?'<table style="'+TBL+'">'+COLG+theadH+'<tbody>'+p.rows.map(i=>rowH(L[i],i)).join('')+'</tbody></table>':'')+(p.final?(p.rows.length?'':'')+finalH():'');
    return '<div class="mbpg" style="position:relative;width:'+PW+'px;height:'+PH+'px;box-sizing:border-box;overflow:hidden;background:#fff;color:#172033;font-family:Arial,sans-serif;font-size:13px;padding:'+PADT+'px '+PADX+'px 0">'+body+
     '<div style="position:absolute;left:'+PADX+'px;right:'+PADX+'px;bottom:18px;border-top:1px solid #cbd5e1;padding-top:6px;display:flex;justify-content:space-between;font-size:10.5px;color:#64748b"><span>'+ESC([coName(H),ID().phone,ID().email].filter(Boolean).join(' — '))+'</span><span>Devis '+ESC(H.no)+' · Page '+(k+1)+' / '+N+'</span></div></div>'});
}
function pdfHTML(){return buildPages().join('')}

/* ---- V99l : PDF à texte sélectionnable (EXBDocs), suivi et envoi ---- */
async function vecDoc(q){
  await refreshVisa();
  let c=null;if(q){c=quoteDoc(q);if(c.error){say(c.error,'warn');return null}}
  const o=CTX;if(c)CTX=c;
  try{
    const Hh=c?c.hdr:ST.hdr,T=c?c.T:totals(),L=docLines(),I=ID(),cdf=!!(q&&/^(CDF|FC)$/i.test(q.currency||'')),show=c?c.showLogo:ST.showLogo;
    const dv=window.EXB_UNIQUE?window.EXB_UNIQUE.guardDoc({kind:'devis',no:Hh.no||'',client:{name:Hh.client}}):null;if(dv&&dv.no&&dv.no!==(Hh.no||'')){Hh.no=dv.no;if(!c){ST.hdr.no=dv.no;try{touch()}catch(e){}}else if(q){q.no=dv.no;try{exbSave(EXB_ECO_KEYS.quotes,exbQuotes)}catch(e){}}}
    return{no:Hh.no||'',date:Hh.date||new Date().toISOString().slice(0,10),validity:Hh.validity||'30 jours',client:{name:Hh.client,address:Hh.address,phone:Hh.phone,email:Hh.email},project:Hh.project,place:Hh.place,company:coName(Hh),
      cur:cdf?'CDF':'USD',lines:L,T:{taux:T.taux,sub:T.sub,subfc:T.subfc,imp:T.imp,impv:T.impv,impfc:T.impfc,tot:T.tot,totfc:T.totfc},total:cdf?T.totfc:T.tot,note:Hh.note||'',title:c&&c.title?c.title:'',
      noLogo:!show,logo:show?((c?c.logo:ST.logo)||I.logo||logoSrc()):'',visa:VISA}
  }finally{CTX=o}}
async function vecPdf(q){
  try{
    const d=await vecDoc(q);if(!d)return;
    const rec=window.EXBDocs.get(d.no);d.status=rec?rec.status:'';if(rec&&rec.sig)d.clientSig=rec.sig;const sg=window.EXBDocs.signer();d.signerName=sg.name;d.signerRole=sg.role;if(rec&&rec.clientSigner)d.clientSigner=rec.clientSigner;if(rec&&rec.due)d.validity=rec.due;
    say('Préparation du PDF…','info',2500);
    const r=await window.EXBDocs.build(d),name='devis-'+(d.no||'metre')+'.pdf';
    const ok=typeof saveFile==='function'?await saveFile(name,r.blob):(window.EXBDocs.save(r.blob,name),true);
    if(ok!==false)say('PDF généré : '+name+' ('+r.pages+' page'+(r.pages>1?'s':'')+', texte sélectionnable)','success',4500)
  }catch(e){say('Échec de la génération du PDF : '+(e&&e.message||e),'error',8000);console.error(e)}}
function openSuivi(q){
  if(!window.EXBDocs){say('Module « documents » indisponible.','warn');return}
  const no=q?q.no:ST.hdr.no,client=q?q.client:ST.hdr.client;
  if(!String(no||'').trim()){say('Renseignez d’abord le numéro du devis.','warn');return}
  if(!String(client||'').trim()){say('Renseignez d’abord le nom du client.','warn');return}
  let hd=q?{}:ST.hdr;if(q){try{const cd=quoteDoc(q);hd=cd.hdr||{}}catch(e){}}
  window.EXBDocs.open({no,client,phone:hd.phone,email:hd.email,getDoc:async()=>{const d=await vecDoc(q);if(!d)throw new Error('Devis incomplet');return d}})}
async function exportPdf(){
  if(!ST.hdr.client.trim()){say('Renseignez d’abord le nom du client (onglet Devis).','warn');return}
  if(window.EXBDocs)return vecPdf(null);
  if(typeof html2canvas==='undefined'||!window.jspdf||typeof prepareOfflinePdfClone!=='function'||typeof savePdf!=='function'){say('Export PDF indisponible : le moteur PDF local n’est pas chargé.','error');return}
  const wrap=document.createElement('div');wrap.style.cssText='position:absolute;left:-100000px;top:0;width:'+PW+'px;background:#fff';
  await refreshVisa();const pgs=buildPages();wrap.innerHTML=pgs.join('');document.body.appendChild(wrap);
  try{
    say('Préparation du PDF (A4, '+pgs.length+' page'+(pgs.length>1?'s':'')+')…','info',3000);
    const {jsPDF}=window.jspdf,pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4',compress:true});
    const els=[...wrap.querySelectorAll('.mbpg')];
    for(let i=0;i<els.length;i++){
      const pr=await prepareOfflinePdfClone(els[i]);
      try{
        if(typeof __waitImages==='function')await __waitImages(pr.clone,10000);
        const cv=await html2canvas(pr.clone,{scale:2,backgroundColor:'#ffffff',useCORS:false,allowTaint:false,imageTimeout:12000,logging:false,removeContainer:true});
        if(i>0)pdf.addPage('a4','portrait');
        pdf.addImage(cv.toDataURL('image/jpeg',0.94),'JPEG',0,0,210,297,undefined,'FAST')
      }finally{pr.clone.remove()}
    }
    const ok=await savePdf(pdf,'devis-'+(ST.hdr.no||'metre')+'.pdf');
    if(ok)say('PDF généré : devis-'+(ST.hdr.no||'metre')+'.pdf','success',4000)
  }catch(e){say('Échec de la génération du PDF : '+(e&&e.message||e),'error',8000);console.error(e)}
  finally{wrap.remove()}}
/* impression directe : seul le devis est imprimé (menus, boutons flottants et bandeaux masqués) */
function mountPrint(){
  unmountPrint();
  const d=document.createElement('div');d.id='mb_print';d.innerHTML=buildPages().join('');document.body.appendChild(d);document.body.classList.add('mb-printing');return d}
function unmountPrint(){const d=$('mb_print');if(d)d.remove();document.body.classList.remove('mb-printing')}
async function printDevis(){
  if(!ST.hdr.client.trim()){say('Renseignez d’abord le nom du client (onglet Devis).','warn');return}
  await refreshVisa();mountPrint();let done=false;const fin=()=>{if(done)return;done=true;window.removeEventListener('afterprint',fin);unmountPrint()};
  window.addEventListener('afterprint',fin);
  setTimeout(()=>{try{window.print()}catch(e){fin();say('Impression impossible : '+e.message,'error')}},150);
  setTimeout(fin,120000)}
/* ---- Devis rapide : MÊME gabarit A4 que le devis maître (logo, en-tête, tableau $ / FC, totaux, signatures, pages numérotées).
   Le devis maître et ses données ne sont pas modifiés : le gabarit lit simplement un contexte « devis rapide » le temps du rendu. ---- */
function quoteDoc(q){
  const H0=(ST&&ST.hdr)||{};let taux=0;try{taux=totals().taux}catch(e){}
  if(!(taux>0)){try{const F=(window.EXBS?window.EXBS.get('exb_finance'):[]).filter(x=>x.type==='taux'&&x.rate>0).sort((a,b)=>a.date<b.date?-1:1);if(F.length)taux=Number(F[F.length-1].rate)}catch(e){}}
  const cdf=/^(CDF|FC)$/i.test(q.currency||'');
  if(cdf&&!(taux>0))return{error:'Taux de change introuvable : renseignez-le (Métré › Paramètres, ou Finance USD / FC).'};
  taux=taux>0?taux:0;
  const items=(q.lines||[]).map(l=>{const qty=Number(l.qty)||0,pu=Number(l.pu)||0,a=qty*pu,c=l.cat==='mo'?'mo':l.cat==='aut'?'aut':'mat';
    return{c,lot:String(l.lot||'').trim(),r:cdf?[l.designation||'—',l.unit||'',qty,pu/taux,a/taux,a]:[l.designation||'—',l.unit||'',qty,pu,a,a*taux]}});
  const CATS=[['mat','MATÉRIAUX','Sous-total matériaux'],['mo','MAIN D’ŒUVRE','Sous-total main d’œuvre'],['aut','AUTRES','Sous-total autres']],groups=CATS.map(g=>({g,it:items.filter(x=>x.c===g[0])})).filter(g=>g.it.length),lines=[];
  if(items.some(x=>x.lot)){const order=[];items.forEach(x=>{const n=x.lot||'Divers';if(order.indexOf(n)<0)order.push(n)});
    order.forEach((n,i)=>{const it=items.filter(x=>(x.lot||'Divers')===n),sc=[(i+1)+'. '+n.toLocaleUpperCase('fr-FR')];sc.k='sec';lines.push(sc);it.forEach(x=>lines.push(x.r));
      const st=['Sous-total '+n.charAt(0).toLowerCase()+n.slice(1),'','','',it.reduce((t,x)=>t+x.r[4],0),it.reduce((t,x)=>t+x.r[5],0)];st.k='sub';lines.push(st)})}
  else
  groups.forEach(gr=>{if(groups.length>1){const sc=[gr.g[1]];sc.k='sec';lines.push(sc)}gr.it.forEach(x=>lines.push(x.r));if(groups.length>1){const st=[gr.g[2],'','','',gr.it.reduce((t,x)=>t+x.r[4],0),gr.it.reduce((t,x)=>t+x.r[5],0)];st.k='sub';lines.push(st)}});
  const sub=items.reduce((t,x)=>t+x.r[4],0),subfc=items.reduce((t,x)=>t+x.r[5],0),imp=Math.max(0,Number(q.imp)||0)/100;
  let cl={};try{if(typeof exbClients!=='undefined'){const n=String(q.client||'').trim().toLowerCase();cl=exbClients.find(c=>String(c.full_name||'').toLowerCase()===n||String(c.company||'').toLowerCase()===n||String(c.contact||'').toLowerCase()===n)||{}}}catch(e){cl={}}
  const hdr=Object.assign({},H0,{no:q.no||'',date:q.date||'',client:q.client||'',project:q.project||'',address:q.address||cl.address||'',phone:q.phone||cl.phone||'',email:q.email||cl.email||'',place:'',nature:'',ref:'',note:q.note||''});
  return{hdr,lines,T:{taux,sub,subfc,imp,impv:sub*imp,impfc:subfc*imp,tot:sub*(1+imp),totfc:subfc*(1+imp)},noImp:true,title:'DÉTAIL DU DEVIS',showLogo:ST?ST.showLogo:true,logo:ST?ST.logo:''}}
function quotePages(q){
  const c=quoteDoc(q);if(c.error)return c;
  const o=CTX;CTX=c;try{return{pages:buildPages(),ctx:c}}finally{CTX=o}}
function quoteCheck(q){
  if(!String(q.client||'').trim()){say('Renseignez d’abord le nom du client.','warn');return null}
  if(!(q.lines||[]).length){say('Aucune ligne dans ce devis.','warn');return null}
  const r=quotePages(q);if(r.error){say(r.error,'warn');return null}return r}
async function quotePdf(q){
  if(window.EXBDocs){if(!String(q.client||'').trim()){say('Renseignez d’abord le nom du client.','warn');return}if(!(q.lines||[]).length){say('Aucune ligne dans ce devis.','warn');return}return vecPdf(q)}
  if(typeof html2canvas==='undefined'||!window.jspdf||typeof prepareOfflinePdfClone!=='function'||typeof savePdf!=='function'){say('Export PDF indisponible : le moteur PDF local n’est pas chargé.','error');return}
  await refreshVisa();const r=quoteCheck(q);if(!r)return;const pgs=r.pages,name='devis-'+(q.no||'rapide')+'.pdf';
  const wrap=document.createElement('div');wrap.style.cssText='position:absolute;left:-100000px;top:0;width:'+PW+'px;background:#fff';
  wrap.innerHTML=pgs.join('');document.body.appendChild(wrap);
  try{
    say('Préparation du PDF (A4, '+pgs.length+' page'+(pgs.length>1?'s':'')+')…','info',3000);
    const {jsPDF}=window.jspdf,pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4',compress:true});
    const els=[...wrap.querySelectorAll('.mbpg')];
    for(let i=0;i<els.length;i++){
      const pr=await prepareOfflinePdfClone(els[i]);
      try{
        if(typeof __waitImages==='function')await __waitImages(pr.clone,10000);
        const cv=await html2canvas(pr.clone,{scale:2,backgroundColor:'#ffffff',useCORS:false,allowTaint:false,imageTimeout:12000,logging:false,removeContainer:true});
        if(i>0)pdf.addPage('a4','portrait');
        pdf.addImage(cv.toDataURL('image/jpeg',0.94),'JPEG',0,0,210,297,undefined,'FAST')
      }finally{pr.clone.remove()}
    }
    const ok=await savePdf(pdf,name);
    if(ok)say('PDF généré : '+name,'success',4000)
  }catch(e){say('Échec de la génération du PDF : '+(e&&e.message||e),'error',8000);console.error(e)}
  finally{wrap.remove()}}
async function quotePrint(q){
  if(window.EXBDocs&&String(q.client||'').trim()&&(q.lines||[]).length){try{const d=await vecDoc(q);if(d){const rec=window.EXBDocs.get(d.no);d.status=rec?rec.status:'';if(rec&&rec.sig)d.clientSig=rec.sig;const sg=window.EXBDocs.signer();d.signerName=sg.name;d.signerRole=sg.role;if(rec&&rec.due)d.validity=rec.due;
    const r=await window.EXBDocs.build(d),u=URL.createObjectURL(r.blob),w2=window.open(u,'_blank');if(!w2){window.EXBDocs.save(r.blob,'devis-'+(d.no||'rapide')+'.pdf');say('PDF téléchargé : ouvrez-le pour l’imprimer.','info',5000)}return}}catch(e){console.error(e)}}
  await refreshVisa();const r=quoteCheck(q);if(!r)return;
  unmountPrint();const d=document.createElement('div');d.id='mb_print';d.innerHTML=r.pages.join('');document.body.appendChild(d);document.body.classList.add('mb-printing');
  let done=false;const fin=()=>{if(done)return;done=true;window.removeEventListener('afterprint',fin);unmountPrint()};
  window.addEventListener('afterprint',fin);
  setTimeout(()=>{try{window.print()}catch(e){fin();say('Impression impossible : '+e.message,'error')}},150);
  setTimeout(fin,120000)}
function toQuote(){
  if(typeof exbQuotes==='undefined'||typeof exbSave!=='function'||typeof EXB_ECO_KEYS==='undefined'){say('Le module « Devis rapide » n’est pas disponible.','warn');return}
  const T=totals(),lines=[];
  for(let r=17;r<=20;r++){const q=num('D','D'+r);if(q>0)lines.push({designation:MODEL.D['B'+r],unit:MODEL.D['C'+r],qty:Math.round(q*1000)/1000,pu:Math.round(num('D','E'+r)*100)/100})}
  ST.extra.forEach(l=>{if((Number(l.q)||0)>0)lines.push({designation:l.d||'Matériau',unit:l.u||'u',qty:Number(l.q)||0,pu:Number(l.pu)||0})});
  if(T.impv>0)lines.push({designation:'Divers & imprévus ('+(Math.round(T.imp*10000)/100)+' %)',unit:'forfait',qty:1,pu:Math.round(T.impv*100)/100});
  if(!lines.length){say('Aucune quantité à transférer : renseignez d’abord les paramètres.','warn');return}
  const total=lines.reduce((a,l)=>a+l.qty*l.pu,0);
  const q={id:(typeof exbId==='function'?exbId('DEV'):'DEV-'+Date.now()),no:ST.hdr.no||('DEV-'+new Date().getFullYear()+'-'+String(exbQuotes.length+1).padStart(3,'0')),client:ST.hdr.client||'Client à renseigner',project:ST.hdr.project||'',date:ST.hdr.date,currency:'USD',lines,total};
  let up=null;try{if(window.EXB_UNIQUE)up=window.EXB_UNIQUE.upsertQuote(q)}catch(e){console.error(e)}
  if(!up||up.mode==='created'){if(!exbQuotes.includes(q))exbQuotes.push(q)}
  exbSave(EXB_ECO_KEYS.quotes,exbQuotes);try{renderExbQuotes()}catch(e){}
  if(up&&up.mode==='unchanged')say('Ce devis est déjà dans les devis enregistrés (N° '+up.q.no+') : rien n’a été ajouté en double.','info',6000);
  else if(up&&up.mode==='updated')say('Devis « '+up.q.no+' » mis à jour dans les devis enregistrés (pas de doublon).','success',5000);
  else say('Devis « '+q.no+' » ajouté aux devis enregistrés (mode Devis rapide).','success',5000)}
/* ---- enregistrement ---- */
function nextNo(){if(window.EXB_UNIQUE)return window.EXB_UNIQUE.nextNo('DEV');return 'DEV-'+new Date().getFullYear()+'-'+String(saved.length+1).padStart(3,'0')}
function saveCur(){
  if(!ST.hdr.no)ST.hdr.no=nextNo();
  try{if(window.EXB_UNIQUE)window.EXB_UNIQUE.beforeSaveMetre(ST)}catch(e){console.error(e)}
  ST.name=(ST.hdr.project||ST.hdr.client||ST.hdr.no).trim();ST.updated=new Date().toISOString();
  if(!ST.id)ST.id='MET-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
  const o=JSON.parse(JSON.stringify(ST)),i=saved.findIndex(x=>x.id===ST.id);if(i>=0)saved[i]=o;else saved.push(o);
  if(sv(KEY,saved)){dirty=false;sv(DRAFT,ST);say('Métré enregistré : '+ST.name,'success');try{audit('Métré béton enregistré',ST.name)}catch(e){}}
  render()}
function openId(id){const s=saved.find(x=>x.id===id);if(!s)return;ST=Object.assign(blank(),JSON.parse(JSON.stringify(s)));ST.hdr=Object.assign(blank().hdr,ST.hdr);ST.ov=Object.assign({P:{},Q:{},X:{},D:{}},ST.ov);dirty=false;render()}
function resizeLogo(file){return new Promise((ok,ko)=>{const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,320/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));c.getContext('2d').drawImage(im,0,0,c.width,c.height);ok(c.toDataURL('image/png'))};im.onerror=()=>ko(new Error('Image illisible'));im.src=fr.result};fr.onerror=()=>ko(new Error('Lecture impossible'));fr.readAsDataURL(file)})}
/* ---- événements ---- */
function onInput(e){
  const t=e.target;if(!t||!t.classList)return;
  if(t.dataset.sh&&t.classList.contains('mbi')){
    if(t.dataset.s){const v=t.value,n=Number(v);ST.ov[t.dataset.sh][t.dataset.a]=(v!==''&&!isNaN(n)&&/^\d+$/.test(v))?n:v;calc();refresh();touch();return}
    const v=t.value===''?null:Number(t.value);ST.ov[t.dataset.sh][t.dataset.a]=(v!==null&&isNaN(v))?null:v;calc();refresh();touch();return}
  if(t.dataset.pct){const v=t.value===''?0:Number(t.value)/100;ST.ov.D.D22=isNaN(v)?0:v;calc();refresh();touch();return}
  if(t.dataset.h){ST.hdr[t.dataset.h]=t.value;touch();return}
  if(t.classList.contains('mbx')){const l=ST.extra[+t.dataset.i];if(!l)return;const k=t.dataset.k;l[k]=(k==='q'||k==='pu')?(t.value===''?'':Number(t.value)):t.value;refresh();touch()}}
async function onClick(e){
  const b=e.target.closest&&e.target.closest('[data-act]');if(!b||!$('mb_panel').contains(b))return;
  const a=b.dataset.act;
  if(b.tagName==='INPUT')return;
  if(a==='tab'){TAB=b.dataset.t;render();window.scrollTo&&$('mb_panel').scrollIntoView({block:'start'})}
  else if(a==='new'){if(dirty&&!confirm('Les modifications non enregistrées seront perdues. Continuer ?'))return;ST=blank();ST.hdr.no=nextNo();dirty=false;sv(DRAFT,ST);render()}
  else if(a==='save')saveCur();
  else if(a==='del'){if(!ST.id||!confirm('Supprimer ce métré enregistré ?'))return;saved=saved.filter(x=>x.id!==ST.id);sv(KEY,saved);ST=blank();ST.hdr.no=nextNo();dirty=false;render();say('Métré supprimé.','info')}
  else if(a==='addpick'){const r=+($('mb_pick').value||0);if(!r){say('Choisissez un matériau dans la liste.','warn');return}const q=SUG[r]?SUG[r]():0;ST.extra.push({d:MODEL.X['B'+r].replace(/\s*\(.*\)$/,''),u:MODEL.X['C'+r],q:q?Math.round(q*1000)/1000:'',pu:num('X','D'+r)});touch();render()}
  else if(a==='addfree'){ST.extra.push({d:'',u:'u',q:'',pu:''});touch();render();setTimeout(()=>{const f=document.querySelectorAll('#mb_body input.mbx[data-k="d"]'),l=f[f.length-1];if(l){l.focus();l.scrollIntoView&&l.scrollIntoView({block:'center'})}},60)}
  else if(a==='delx'){ST.extra.splice(+b.dataset.i,1);touch();render()}
  else if(a==='logodef'){ST.logo='';touch();render()}
  else if(a==='pdf')exportPdf();
  else if(a==='print')printDevis();
  else if(a==='suivi')openSuivi(null);
  else if(a==='toquote')toQuote()}
function onChange(e){
  const t=e.target;if(!t)return;
  if(t.id==='mb_sel'){if(!t.value)return;if(dirty&&!confirm('Les modifications non enregistrées seront perdues. Ouvrir ce métré ?')){render();return}openId(t.value);return}
  if(t.dataset&&t.dataset.act==='logoon'){ST.showLogo=t.checked;touch();render();return}
  if(t.dataset&&t.dataset.act==='logofile'&&t.files&&t.files[0]){resizeLogo(t.files[0]).then(d=>{ST.logo=d;touch();render()}).catch(err=>say(err.message,'error'));return}
  if(t.classList&&t.classList.contains('mbx')){refresh();return}}
/* ---- installation dans la section « Métré & devis » ---- */
const PRINTCSS='#mb_print{display:none}@media print{@page{size:A4 portrait;margin:0}html,body{margin:0!important;padding:0!important;background:#fff!important}body.mb-printing>*:not(#mb_print){display:none!important}body.mb-printing #mb_print{display:block!important}body.mb-printing .mbpg{break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}body.mb-printing .mbpg:last-child{break-after:auto;page-break-after:auto}body.mb-printing tr{break-inside:avoid;page-break-inside:avoid}}';
const CSS='#mb_seg{display:flex;gap:8px;margin:10px 0;flex-wrap:wrap}#mb_seg button{padding:9px 14px;border-radius:20px;border:1px solid #cbd5e1;background:#fff;cursor:pointer}#mb_seg button.on{background:#173565;color:#fff;border-color:#173565}'+
'#mb_panel{font-size:14px}#mb_panel .mbtop{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px}#mb_panel .mbtop select{flex:1;min-width:150px;padding:9px;border:1px solid #cbd5e1;border-radius:8px}'+
'#mb_panel .mbsum{display:flex;flex-wrap:wrap;gap:6px 14px;background:#eef3fb;border:1px solid #d3deef;border-radius:10px;padding:9px 12px;margin-bottom:8px;position:sticky;top:0;z-index:5;font-size:13px}#mb_panel .mbsum b{color:#173565}#mb_panel .mbtotal{margin-left:auto}'+
'#mb_panel .mbtabs{display:flex;gap:6px;overflow-x:auto;padding-bottom:6px;margin-bottom:8px}#mb_panel .mbtabs button{white-space:nowrap;padding:9px 13px;border-radius:10px;border:1px solid #cbd5e1;background:#fff;cursor:pointer}#mb_panel .mbtabs button.on{background:#173565;color:#fff;border-color:#173565}'+
'#mb_panel .mbsec{margin:16px 0 8px;color:#173565;font-size:15px}#mb_panel .mbgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px}#mb_panel .mbc{border:1px solid #e2e8f0;border-radius:10px;padding:10px;background:#fff}#mb_panel .mbc.mbwide{grid-column:1/-1}#mb_panel .mbc h4{margin:0 0 6px;font-size:13px;color:#173565}'+
'#mb_panel .mbf{display:flex;flex-direction:column;gap:3px;margin:5px 0;font-size:12px;color:#475569}#mb_panel .mbf small{color:#94a3b8}#mb_panel .mbi,#mb_panel .mbh2,#mb_panel .mbx,#mb_panel select.mbi,#mb_panel textarea.mbh2{width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px;background:#fff;color:#0000cc}#mb_panel .mbh2{color:#172033}'+
'#mb_panel .mbro{color:#475569}#mb_panel b.mbro{background:#f1f5f9;border-radius:8px;padding:8px;display:block;font-weight:600}#mb_panel .mbscroll{overflow-x:auto;margin:6px 0}#mb_panel table.mbt{border-collapse:collapse;width:100%;font-size:13px}#mb_panel .mbt th{background:#173565;color:#fff;padding:7px 8px;font-weight:600;white-space:nowrap;text-align:center}#mb_panel .mbt td{border-bottom:1px solid #e2e8f0;padding:5px 7px;text-align:right}#mb_panel .mbt td:first-child{text-align:left}#mb_panel .mbt tr.mbh td{background:#e8eef8;color:#173565;font-weight:700;text-align:left}#mb_panel .mbt tr.mbs td{background:#f1f5f9;font-weight:700}#mb_panel .mbt tr.mbg td{background:#173565;color:#fff}#mb_panel .mbt td .mbi,#mb_panel .mbt td .mbx{min-width:70px;padding:6px}#mb_panel .mbs6{min-width:56px!important;max-width:80px}'+
'#mb_panel .mbhint{color:#64748b;font-size:12px;margin:6px 0}#mb_panel .mbtot{text-align:right;font-weight:700;margin:6px 0;color:#173565}#mb_panel .mbmuted{color:#64748b;font-size:12px}#mb_panel .mbcredit{margin-top:18px;font-size:11px;color:#94a3b8;text-align:center}'+
'#mb_panel .mbrecap{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}#mb_panel .mbrecap div{border:1px solid #d3deef;background:#eef3fb;border-radius:10px;padding:10px;display:flex;flex-direction:column}#mb_panel .mbrecap b{font-size:18px;color:#173565}'+
'#mb_panel .mbdet{margin-top:14px}#mb_panel .mbsh{font-weight:700;color:#173565;margin:8px 0 2px;font-size:12px}#mb_panel .mbsr{display:flex;gap:8px;font-size:13px;padding:2px 0;border-bottom:1px dotted #e2e8f0}#mb_panel .mbsr span{flex:1}'+
'#mb_panel .mbcomp{display:flex;gap:12px;align-items:center}#mb_panel .mblogo{width:64px;height:64px;object-fit:contain}#mb_panel .mbcard{border:1px solid #e2e8f0;border-radius:10px;padding:10px;margin-bottom:10px}#mb_panel .mbrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px}#mb_panel .mbbtn{padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;cursor:pointer;background:#fff}#mb_panel .mbadd{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}#mb_panel .mbadd select{flex:1;min-width:180px;padding:9px;border:1px solid #cbd5e1;border-radius:8px}';
function install(){
  const sec=$('metreDevis');if(!sec||$('mb_panel'))return;
  const card=sec.querySelector('.card'),head=sec.querySelector('.exb-module-head'),grid=sec.querySelector('.exb-grid');if(!card||!head||!grid)return;
  const st=document.createElement('style');st.textContent=CSS+PRINTCSS;document.head.appendChild(st);
  grid.id='mb_quick';grid.style.display='none';
  const seg=document.createElement('div');seg.id='mb_seg';seg.innerHTML='<button data-m="mb" class="on">🧱 Métré béton armé</button><button data-m="quick">Devis rapide</button>';
  head.insertAdjacentElement('afterend',seg);
  const pan=document.createElement('div');pan.id='mb_panel';card.appendChild(pan);
  seg.addEventListener('click',e=>{const b=e.target.closest('button[data-m]');if(!b)return;seg.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));const mb=b.dataset.m==='mb';pan.style.display=mb?'':'none';grid.style.display=mb?'none':''});
  saved=ld(KEY,[]);if(!Array.isArray(saved))saved=[];
  const d=ld(DRAFT,null);ST=blank();
  if(d&&d.ov){ST=Object.assign(blank(),d);ST.hdr=Object.assign(blank().hdr,d.hdr||{});ST.ov=Object.assign({P:{},Q:{},X:{},D:{}},d.ov);if(!Array.isArray(ST.extra))ST.extra=[];dirty=true}
  if(!ST.hdr.no)ST.hdr.no=nextNo();
  pan.addEventListener('input',onInput);pan.addEventListener('click',onClick);pan.addEventListener('change',onChange);
  render();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
setTimeout(refreshVisa,1200);
/* V99zw — reçoit des lignes de quantités d'un autre module (ex. maquette IFC) dans « Matériaux ajoutés ».
   Une ligne portant la même clé « src » est mise à jour au lieu d'être dupliquée ; le prix unitaire déjà saisi est conservé. */
function addLignes(lines){
  if(!ST||!Array.isArray(lines))return 0;let n=0;
  lines.forEach(l=>{const q=Math.round((Number(l&&l.q)||0)*1000)/1000;if(!l||!l.d||!(q>0))return;
    const ex=l.src?ST.extra.find(x=>x.src===l.src):null;
    if(ex){ex.d=l.d;ex.u=l.u||ex.u;ex.q=q;if(l.puSync&&l.pu!=null&&l.pu!=='')ex.pu=l.pu}else ST.extra.push({d:String(l.d),u:l.u||'u',q:q,pu:l.pu==null?'':l.pu,src:l.src||''});n++});
  if(n){TAB='ext';touch();try{if(typeof show==='function')show('metreDevis')}catch(e){}const b=document.querySelector('#mb_seg button[data-m="mb"]');if(b)b.click();render()}
  return n}
window.EXBMetre={refreshVisa,addLignes,engine:ENG,model:MODEL,state:()=>ST,render,calc:()=>{calc();return R},totals,buildPages,mountPrint,unmountPrint,quotePdf,quotePrint,openSuivi,vecDoc,_quoteDoc:quoteDoc,_quotePages:quotePages};

})();
