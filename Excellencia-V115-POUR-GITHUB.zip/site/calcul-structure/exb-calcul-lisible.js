/* Excellencia Building — écritures plus grandes et plus lisibles dans les notes de calcul et les plans d'exécution.
 * Avant : texte des notes 11,5 px et textes des plans de 1 à 2,4 unités (trop fins une fois imprimés).
 * Maintenant : trois tailles au choix dans la barre « Aperçu du document » — Normal / Grand (par défaut) / Très grand.
 *   - notes de calcul : corps, tableaux, titres, sommaire, page de garde agrandis, texte plus foncé ;
 *   - plans d'exécution : tous les textes du dessin (cotes, légendes, tableau des aciers, cartouche) agrandis et plus épais,
 *     traits un peu plus forts ; les coupes, cotes et légendes gardent leur position.
 * Le choix est mémorisé sur l'appareil (clé exb_doc_ecriture). Aucun calcul n'est modifié. */
(function (w, d) {
  'use strict';
  var KEY = 'exb_doc_ecriture';
  var LV = {
    n: { name: 'Normal', t: 1, floor: 0, small: 1, w: 0, sw: 1 },
    g: { name: 'Grand', t: 1.32, floor: 0.0095, small: 1.45, w: 600, sw: 1.3 },
    x: { name: 'Très grand', t: 1.65, floor: 0.0120, small: 1.85, w: 700, sw: 1.6 }
  };
  function level() { var v = 'g'; try { v = w.localStorage.getItem(KEY) || 'g'; } catch (e) {} return LV[v] ? v : 'g'; }
  function setLevel(v) { try { w.localStorage.setItem(KEY, v); } catch (e) {} }

  /* ---------- feuille de style des notes (aperçu, impression et PDF) ---------- */
  function rules(P, k) {
    var g = k === 'g', f = function (a, b) { return g ? a : b; };
    var A = P + '[data-ec="' + k + '"] ';
    return A + '.pg{font-size:' + f(14.5, 16.5) + 'px;line-height:1.52;color:#0b1220}' +
      A + '.pg th,' + A + '.pg td{font-size:' + f(13.5, 15.5) + 'px;padding:' + f(5, 6) + 'px 7px}' + A + '.pg td{color:#0b1220}' + A + '.pg th{color:#fff}' +
      A + '.pg th{font-weight:800}' +
      A + '.pg td{font-weight:500}' +
      A + '.pg h2{font-size:' + f(17.5, 20) + 'px;margin:18px 0 8px}' +
      A + '.pg h3{font-size:' + f(15.5, 17.5) + 'px}' +
      A + '.pg .nt,' + A + '.nt{font-size:' + f(13, 15) + 'px;color:#334155}' +
      A + '.pg .ct td,' + A + '.ct td{font-size:' + f(12.5, 14.5) + 'px}' +
      A + '.hd{font-size:' + f(12.5, 14) + 'px}' + A + '.hd b{font-size:' + f(14.5, 16.5) + 'px}' +
      A + '.ex-foot{font-size:' + f(11, 12.5) + 'px}' +
      A + '.ex-som{font-size:' + f(12.5, 14) + 'px}' +
      A + '.ex-box{font-size:' + f(13.5, 15) + 'px}' + A + '.ex-box>b{font-size:' + f(11.5, 13) + 'px}' +
      A + '.ex-cl{font-size:' + f(13, 14.5) + 'px}' + A + '.ex-cl b{font-size:' + f(15.5, 17) + 'px}' +
      A + '.ex-rf{font-size:' + f(11.5, 13) + 'px}' +
      A + '.ex-c .ex-som{font-size:' + f(11.5, 13) + 'px}' +
      A + '.ex-lb{font-size:' + f(10, 11.5) + 'px}' +
      A + '.ex-vg>div{font-size:' + f(12, 13.5) + 'px}' + A + '.ex-visas>b{font-size:' + f(12.5, 14) + 'px}' +
      A + '.ex-id span{font-size:' + f(11.5, 13) + 'px}' + A + '.ex-ttl span{font-size:' + f(11.5, 13) + 'px}';
  }
  function css() {
    if (d.getElementById('exbLisibleCss')) return;
    var s = d.createElement('style'); s.id = 'exbLisibleCss';
    s.textContent = rules('#doc', 'g') + rules('#inl', 'g') + rules('#doc', 'x') + rules('#inl', 'x') +
      '#exbEcr{display:inline-flex;align-items:center;gap:6px;margin-right:10px;font:700 12px Arial;color:#fff;white-space:nowrap}' +
      '#exbEcr select{width:auto;padding:5px 6px;border-radius:7px;border:0;font:700 12px Arial;color:#12254a;background:#fff}';
    d.head.appendChild(s);
  }

  /* ---------- plans : textes et traits (idempotent : la valeur d'origine est gardée dans data-fs0 / data-sw0) ---------- */
  function svgScale(root, k) {
    var L = LV[k];
    Array.prototype.forEach.call(root.querySelectorAll('svg'), function (svg) {
      var vb = (svg.getAttribute('viewBox') || '').split(/[\s,]+/).map(Number), W = vb.length === 4 ? vb[2] : 300;
      Array.prototype.forEach.call(svg.querySelectorAll('text'), function (t) {
        var f0 = t.getAttribute('data-fs0');
        if (f0 === null) { f0 = t.getAttribute('font-size'); if (f0 === null) f0 = String(parseFloat((t.style && t.style.fontSize) || '') || 0); t.setAttribute('data-fs0', f0); t.setAttribute('data-fw0', t.getAttribute('font-weight') || ''); }
        f0 = parseFloat(f0); if (!(f0 > 0)) return;
        var nf;
        if (k === 'n') nf = f0;
        else if (f0 < 1.9) nf = f0 * L.small;                              /* cartouche, notes : petits textes */
        else if (f0 >= 2.8) nf = f0 * (k === 'x' ? 1.18 : 1.08);       /* titres de vues : à peine plus grands (sinon ils se chevauchent) */
        else nf = Math.max(f0 * L.t, W * L.floor);
        t.setAttribute('font-size', nf.toFixed(3));
        if (t.style && t.style.fontSize) t.style.fontSize = nf.toFixed(3) + 'px';
        var fw0 = t.getAttribute('data-fw0');
        if (k === 'n') { if (fw0) t.setAttribute('font-weight', fw0); else t.removeAttribute('font-weight'); }
        else if (!fw0 || fw0 === 'normal' || (+fw0 && +fw0 < L.w)) t.setAttribute('font-weight', String(L.w));
      });
      Array.prototype.forEach.call(svg.querySelectorAll('line,path,polyline,polygon,rect,circle,ellipse'), function (e) {
        var s0 = e.getAttribute('data-sw0');
        if (s0 === null) { s0 = e.getAttribute('stroke-width'); if (s0 === null) return; e.setAttribute('data-sw0', s0); }
        var v = parseFloat(s0); if (!(v > 0)) return;
        e.setAttribute('stroke-width', (v * L.sw).toFixed(3));
      });
    });
  }

  function apply() {
    var k = level();
    ['doc', 'inl'].forEach(function (id) {
      var el = d.getElementById(id); if (!el) return;
      el.setAttribute('data-ec', k);
      svgScale(el, k);
    });
    var sel = d.getElementById('exbEcrSel'); if (sel && sel.value !== k) sel.value = k;
  }

  function toolbar() {
    var dt = d.querySelector('#doc .dt'); if (!dt || d.getElementById('exbEcr')) return;
    var box = d.createElement('span'); box.id = 'exbEcr';
    box.innerHTML = '<span>Écritures</span><select id="exbEcrSel" aria-label="Taille des écritures"><option value="n">Normal</option><option value="g">Grand</option><option value="x">Très grand</option></select>';
    var last = dt.lastElementChild; dt.insertBefore(box, last && last.tagName === 'SPAN' ? last : null);
    var sel = box.querySelector('select'); sel.value = level();
    sel.onchange = function () { setLevel(sel.value); apply(); };
  }

  var timer = 0;
  function later() { clearTimeout(timer); timer = setTimeout(function () { try { toolbar(); apply(); } catch (e) {} }, 120); }
  function boot() {
    css();
    var mo = new MutationObserver(later); mo.observe(d.body, { childList: true, subtree: true });
    later();
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();

  w.EXBLisible = { apply: apply, level: level, set: function (v) { if (LV[v]) { setLevel(v); apply(); } }, version: 'V99-correctifs-2' };
})(window, document);
