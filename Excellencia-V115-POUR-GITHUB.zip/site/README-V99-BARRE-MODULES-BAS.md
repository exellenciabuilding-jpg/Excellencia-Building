# V99 — Barre des modules en bas de l'écran (déplaçable)

Nouveau fichier : `exb-module-dock.js`. Modifiés : `index.html` (1 balise script), `sw.js` (cache). Aucune fonction existante modifiée.

- L'écran d'accueil et les pages de catégorie restent inchangés.
- Dès qu'on ouvre N'IMPORTE QUEL module (sans exception), la barre apparaît en bas : Accueil, la catégorie, puis les modules voisins (ou le module seul s'il n'a pas de voisins). Un appui change de module en gardant tout l'espace de travail.
- La barre du haut des modules est masquée tant que la barre du bas est active (un seul niveau).
- Déplaçable : glisser la poignée ⠿ (position mémorisée, comme les boutons flottants). Double appui sur la poignée : remise en bas.
- Bouton ▾ : réduit la barre en pastille ; un appui la rouvre.
- Elle se cache pendant la saisie au clavier.
- Retour en arrière : supprimer la balise `<script src="exb-module-dock.js">` de index.html.

À confirmer sur vos appareils (rendu mobile non testé ici).
- Détection par lecture de l'écran uniquement : aucune fonction du logiciel n'est enveloppée ni modifiée. Testé dans un navigateur sur Formation (TP / TD), Architecture, Ingénierie, Achats, Paramètres, Notifications : aucune erreur de script.
