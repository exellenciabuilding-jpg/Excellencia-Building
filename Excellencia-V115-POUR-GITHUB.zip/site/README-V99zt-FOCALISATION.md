# V99zt — Focalisation produit (audit interne : « Séparer Formation et Construction / Architecture »)

Fichiers modifiés : `exb-v99r-shell.js`, `sw.js` (cache `exb-v99zt-focalisation-1`). Aucun SQL, aucune donnée modifiée.

Le sélecteur « Tout / Construction / Formation » existait depuis V99zg (menu seulement). V99zt étend le parcours à tout l'écran d'accueil :
- **Choix au premier lancement** : bandeau non bloquant sur l'accueil (Construction / Architecture, Formation, Tout afficher). Affiché une seule fois ; le sélecteur en haut du menu reste disponible.
- **Indicateurs de l'accueil par parcours** : Construction = projets en cours, projets terminés, clients, paiements en attente. Formation = apprenants, formations, certificats, paiements en attente. Tout = indicateurs d'origine.
- **Graphique** : Construction = évolution des projets ; Formation = évolution des inscriptions.
- **Textes** : sous-titre, bannière, bouton principal, accroche, sous-titre de l'en-tête et zone de recherche adaptés au parcours.
- Un dirigeant BTP ne voit plus d'apprenants, de certificats ni de cotations ; un centre de formation ne voit plus de chantiers ni de plans.

Limites : la recherche globale cherche toujours dans toutes les données (seul son texte d'aide change) ; le parcours est mémorisé sur l'appareil (pas encore lié au rôle ni à la licence). Rendu à confirmer sur vos appareils.
Retour en arrière : restaurer `exb-v99r-shell.js` et `sw.js` de V99zs.

## Complément (fin de l'étape 1)
- **Recherche globale filtrée** : en Construction, plus de participants, certificats, reçus ni formations ; en Formation, plus de projets ni de devis. « Tout » : inchangé.
- **Parcours selon la fonction** : sans choix explicite, un formateur arrive en Formation ; un conducteur de travaux, chef de projet, bureau d'études ou ingénieur arrive en Construction (nécessite la base partagée, qui fournit la fonction). Le bandeau de choix n'apparaît alors pas. Un choix explicite l'emporte toujours.
- Reste hors de cette étape : lien avec la licence (un client sans module Formation ne verrait que Construction).
