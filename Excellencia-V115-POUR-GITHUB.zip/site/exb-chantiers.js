/* Excellencia Building V61 — Chantiers & finances : fiche chantier, facturation (TVA), dépenses et marge par projet.
 * Utilise les projets, devis et la caisse existants. Nouvelles données : exb_invoices (factures + encaissements). */
(function(){'use strict';
var KI='exb_invoices',TVA0=16,$=function(i){return document.getElementById(i)};
var CATS=['Matériaux','Main-d\'œuvre','Sous-traitance','Transport','Location engins','Divers'];
var ST={tab:'c',pid:'',draft:null};
function esc(v){return String(v==null?'':v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function m(n){return Number(n||0).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})}
function today(){return new Date().toISOString().slice(0,10)}
function plus(d,n){var x=new Date(d||today());x.setDate(x.getDate()+n);return x.toISOString().slice(0,10)}
function say(t,k){try{notify(t,k||'info',4500)}catch(e){alert(t)}}
function invs(){try{return load(KI,[])}catch(e){return[]}}
function saveInv(a){save(KI,a)}
function projs(){return typeof exbProjects!=='undefined'?exbProjects:[]}
function cash(){return typeof exbCash!=='undefined'?exbCash:[]}
function saveCash(){exbSave(EXB_ECO_KEYS.cash,exbCash);try{renderExbCash()}catch(e){}try{updateExbDirection()}catch(e){}}
/* ---------- calculs ---------- */
function tot(i){var ht=(i.lines||[]).reduce(function(a,l){return a+(+l.q||0)*(+l.pu||0)},0),tv=ht*(+i.tva||0)/100,ttc=ht+tv,paid=(i.payments||[]).reduce(function(a,p){return a+(+p.amount||0)},0);return {ht:ht,tva:tv,ttc:ttc,paid:paid,reste:Math.max(0,ttc-paid)}}
function statut(i){var t=tot(i);if(t.ttc>0&&t.paid>=t.ttc-0.005)return 'Payée';if(i.due&&i.due<today())return 'En retard';return t.paid>0?'Partielle':'Émise'}
function bilan(pid){var p=projs().find(function(x){return x.id===pid});if(!p)return null;var cur='USD',I=invs().filter(function(i){return i.project_id===pid}),autre=I.filter(function(i){return (i.currency||'USD')!==cur}).length;I=I.filter(function(i){return (i.currency||'USD')===cur});
 var T=I.reduce(function(a,i){var t=tot(i);a.ht+=t.ht;a.ttc+=t.ttc;a.paid+=t.paid;return a},{ht:0,ttc:0,paid:0});
 var dep=cash().filter(function(x){return x.type==='out'&&x.project_id===pid}),cat={},D=0;dep.forEach(function(x){var a=+x.amount||0;D+=a;var c=x.category||'Divers';cat[c]=(cat[c]||0)+a});
 var Q=(typeof exbQuotes!=='undefined'?exbQuotes:[]).filter(function(q){return q.project===p.name||q.project===p.id});
 var bud=+p.budget||0,al=[];if(bud&&D>bud)al.push('⛔ Les dépenses dépassent le budget.');else if(bud&&D>0.9*bud)al.push('⚠ Plus de 90 % du budget est consommé.');
 var late=I.filter(function(i){return statut(i)==='En retard'}).length;if(late)al.push('⚠ '+late+' facture(s) en retard de paiement.');
 if(bud&&p.progress!=null&&D/bud*100>(+p.progress||0)+15)al.push('⚠ Les dépenses ('+Math.round(D/bud*100)+' %) avancent plus vite que le chantier ('+(+p.progress||0)+' %).');
 if(autre)al.push('ℹ '+autre+' facture(s) en autre devise non comptée(s) dans ce bilan (USD).');
 return {p:p,bud:bud,devis:Q.reduce(function(a,q){return a+(+q.total||0)},0),nq:Q.length,quotes:Q,ht:T.ht,ttc:T.ttc,paid:T.paid,reste:T.ttc-T.paid,dep:D,cat:cat,dl:dep,pct:bud?D/bud*100:0,margeReelle:T.paid-D,margePrevue:T.ht-D,al:al,invs:I}}
function nextNo(){var y=new Date().getFullYear(),n=invs().filter(function(i){return String(i.no||'').indexOf('FAC-'+y)===0}).length+1;return 'FAC-'+y+'-'+String(n).padStart(3,'0')}
/* ---------- affichage ---------- */
function opts(sel){return '<option value="">— Choisir un chantier —</option>'+projs().map(function(p){return '<option value="'+esc(p.id)+'"'+(p.id===sel?' selected':'')+'>'+esc(p.name)+'</option>'}).join('')}
function head(){var T=[['c','📋 Chantier'],['f','🧾 Factures'],['d','💸 Dépenses']];return '<div class="exb-actions" style="flex-wrap:wrap">'+T.map(function(x){return '<button class="'+(x[0]===ST.tab?'primary':'muted')+'" onclick="EXBCH.tab(\''+x[0]+'\')">'+x[1]+'</button>'}).join('')+'</div><label>Chantier</label><select onchange="EXBCH.pid(this.value)">'+opts(ST.pid)+'</select>'}
function kpi(l,v,c){return '<div class="exb-card" style="padding:10px"><div class="exb-muted" style="font-size:12px">'+l+'</div><b style="font-size:17px;color:'+(c||'inherit')+'">'+v+'</b></div>'}
function vChantier(){var b=bilan(ST.pid);if(!b)return '<p class="exb-muted">Choisissez un chantier pour voir sa fiche financière. Les projets se créent dans « Projets &amp; chantiers ».</p>';
 var p=b.p,col=function(v){return v<0?'#b91c1c':'#15803d'};
 var h='<h3>'+esc(p.name)+'</h3><p class="exb-muted">'+esc(p.client||'—')+' · '+esc(p.location||'')+' · '+esc(p.status||'')+' · Avancement '+(+p.progress||0)+' %</p>'+(b.al.length?'<div class="exb-card" style="background:#fff7ed;border:1px solid #fdba74;padding:8px">'+b.al.map(function(a){return '<div>'+a+'</div>'}).join('')+'</div>':'')+
 '<div class="exb-grid" style="margin-top:8px">'+kpi('Budget',m(b.bud)+' $')+kpi('Devis ('+b.nq+')',m(b.devis)+' $')+kpi('Facturé TTC',m(b.ttc)+' $')+kpi('Encaissé',m(b.paid)+' $','#15803d')+kpi('Reste à encaisser',m(b.reste)+' $','#b45309')+kpi('Dépenses réelles',m(b.dep)+' $ ('+Math.round(b.pct)+' %)')+kpi('Marge réelle (encaissé − dépenses)',m(b.margeReelle)+' $',col(b.margeReelle))+kpi('Marge prévue (facturé HT − dépenses)',m(b.margePrevue)+' $',col(b.margePrevue))+'</div>';
 var cs=Object.keys(b.cat);h+='<h4>Dépenses par catégorie</h4>'+(cs.length?'<table class="exb-table"><tbody>'+cs.map(function(c){return '<tr><td>'+esc(c)+'</td><td style="text-align:right">'+m(b.cat[c])+' $</td></tr>'}).join('')+'</tbody></table>':'<p class="exb-muted">Aucune dépense enregistrée.</p>');
 h+='<h4>Devis de ce chantier</h4>'+(b.quotes.length?'<table class="exb-table"><tbody>'+b.quotes.map(function(q){return '<tr><td>'+esc(q.no)+'</td><td>'+m(q.total)+' '+esc(q.currency||'')+'</td><td><button class="muted smallbtn" onclick="EXBCH.fromQuote(\''+esc(q.id)+'\')">➡ Facturer</button></td></tr>'}).join('')+'</tbody></table>':'<p class="exb-muted">Aucun devis lié (le nom du projet doit être indiqué dans le devis).</p>');
 return h}
function vFactures(){var d=ST.draft,h='';
 if(d){var t=tot(d);h+='<div class="exb-card"><h3>'+(d._new?'Nouvelle facture':'Facture '+esc(d.no))+'</h3><div class="exb-grid"><div><label>N°</label><input value="'+esc(d.no)+'" oninput="EXBCH.d(\'no\',this.value)"></div><div><label>Client</label><input value="'+esc(d.client)+'" oninput="EXBCH.d(\'client\',this.value)"></div><div><label>Date</label><input type="date" value="'+esc(d.date)+'" oninput="EXBCH.d(\'date\',this.value)"></div><div><label>Échéance</label><input type="date" value="'+esc(d.due)+'" oninput="EXBCH.d(\'due\',this.value)"></div><div><label>TVA %</label><input type="number" step="any" value="'+d.tva+'" oninput="EXBCH.d(\'tva\',this.value,1)"></div><div><label>Devise</label><select onchange="EXBCH.d(\'currency\',this.value)"><option'+(d.currency==='USD'?' selected':'')+'>USD</option><option'+(d.currency==='FC'?' selected':'')+'>FC</option></select></div></div>'+
  '<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Désignation</th><th>Unité</th><th>Qté</th><th>PU</th><th></th></tr></thead><tbody>'+d.lines.map(function(l,i){return '<tr><td><input value="'+esc(l.d)+'" oninput="EXBCH.l('+i+',\'d\',this.value)" style="width:170px"></td><td><input value="'+esc(l.u)+'" oninput="EXBCH.l('+i+',\'u\',this.value)" style="width:55px"></td><td><input type="number" step="any" value="'+l.q+'" oninput="EXBCH.l('+i+',\'q\',this.value,1)" style="width:70px"></td><td><input type="number" step="any" value="'+l.pu+'" oninput="EXBCH.l('+i+',\'pu\',this.value,1)" style="width:80px"></td><td><button class="danger" onclick="EXBCH.delL('+i+')">×</button></td></tr>'}).join('')+'</tbody></table></div><div class="exb-actions"><button class="muted" onclick="EXBCH.addL()">➕ Ligne</button></div>'+
  '<div id="exbch_tot">'+totHtml(t)+'</div><div class="exb-actions"><button class="primary" onclick="EXBCH.saveD()">💾 Enregistrer la facture</button><button class="muted" onclick="EXBCH.cancel()">Annuler</button></div></div>'}
 else h+='<div class="exb-actions"><button class="primary" onclick="EXBCH.newInv()">➕ Nouvelle facture</button></div>';
 var L=invs().filter(function(i){return !ST.pid||i.project_id===ST.pid});
 h+=L.length?'<div class="exb-scroll"><table class="exb-table"><thead><tr><th>N°</th><th>Client</th><th>TTC</th><th>Payé</th><th>Statut</th><th></th></tr></thead><tbody>'+L.map(function(i){var t=tot(i),s=statut(i);return '<tr><td>'+esc(i.no)+'<br><small>'+esc(i.date)+'</small></td><td>'+esc(i.client)+'</td><td>'+m(t.ttc)+' '+esc(i.currency||'')+'</td><td>'+m(t.paid)+'</td><td><span class="exb-badge" style="'+(s==='En retard'?'background:#fee2e2;color:#b91c1c':s==='Payée'?'background:#dcfce7;color:#15803d':'')+'">'+s+'</span></td><td style="white-space:nowrap"><button class="muted smallbtn" onclick="EXBCH.open(\''+i.id+'\')">Ouvrir</button> <button class="muted smallbtn" onclick="EXBCH.pay(\''+i.id+'\')">💰</button> <button class="muted smallbtn" onclick="EXBCH.pdf(\''+i.id+'\')">📄</button> <button class="danger smallbtn" onclick="EXBCH.delI(\''+i.id+'\')">×</button></td></tr>'}).join('')+'</tbody></table></div><p class="exb-muted">💰 = enregistrer un paiement (il est ajouté automatiquement à la caisse) · 📄 = PDF.</p>':'<p class="exb-muted">Aucune facture'+(ST.pid?' pour ce chantier':'')+'.</p>';
 return h}
function totHtml(t){return '<table class="exb-table" style="margin-top:8px"><tbody><tr><td>Total HT</td><td style="text-align:right">'+m(t.ht)+'</td></tr><tr><td>TVA</td><td style="text-align:right">'+m(t.tva)+'</td></tr><tr><td><b>Total TTC</b></td><td style="text-align:right"><b>'+m(t.ttc)+'</b></td></tr></tbody></table>'}
function vDepenses(){var h='<div class="exb-card"><h3>Nouvelle dépense</h3><div class="exb-grid"><div><label>Date</label><input id="exbch_ed" type="date" value="'+today()+'"></div><div><label>Catégorie</label><select id="exbch_ec">'+CATS.map(function(c){return '<option>'+c+'</option>'}).join('')+'</select></div><div><label>Libellé</label><input id="exbch_el" placeholder="Ex. 20 sacs de ciment"></div><div><label>Montant ($)</label><input id="exbch_ea" type="number" step="any"></div></div><div class="exb-actions"><button class="primary" onclick="EXBCH.addE()">➕ Enregistrer la dépense</button></div><p class="exb-muted">Imputée au chantier choisi ci-dessus et ajoutée à la caisse (sortie).</p></div>';
 var D=cash().filter(function(x){return x.type==='out'&&x.project_id&&(!ST.pid||x.project_id===ST.pid)}).slice().reverse();
 return h+(D.length?'<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Date</th><th>Libellé</th><th>Catég.</th><th>Montant</th><th></th></tr></thead><tbody>'+D.map(function(x){return '<tr><td>'+esc(x.date)+'</td><td>'+esc(x.label)+'</td><td>'+esc(x.category||'')+'</td><td>'+m(x.amount)+'</td><td><button class="danger smallbtn" onclick="EXBCH.delE(\''+x.id+'\')">×</button></td></tr>'}).join('')+'</tbody></table></div>':'<p class="exb-muted">Aucune dépense imputée à un chantier.</p>')}
function render(){var b=$('exbch_box');if(!b)return;b.innerHTML=head()+(ST.tab==='c'?vChantier():ST.tab==='f'?vFactures():vDepenses())}
/* ---------- actions ---------- */
function blank(pid,client){return {_new:1,id:exbId('FAC'),no:nextNo(),project_id:pid||'',client:client||'',date:today(),due:plus(today(),30),tva:TVA0,currency:'USD',lines:[{d:'',u:'forfait',q:1,pu:0}],payments:[],note:''}}
function needP(){if(!ST.pid){say('Choisissez d\'abord un chantier.','warn');return false}return true}
function upd(){var e=$('exbch_tot');if(e&&ST.draft)e.innerHTML=totHtml(tot(ST.draft))}
var A={
 tab:function(t){ST.tab=t;render()},pid:function(v){ST.pid=v;if(ST.draft&&!ST.draft.project_id)ST.draft.project_id=v;render()},
 newInv:function(){if(!needP())return;var p=projs().find(function(x){return x.id===ST.pid});ST.draft=blank(ST.pid,p&&p.client);render()},
 d:function(k,v,n){ST.draft[k]=n?(+v||0):v;if(k==='tva')upd()},
 l:function(i,k,v,n){ST.draft.lines[i][k]=n?(+v||0):v;upd()},addL:function(){ST.draft.lines.push({d:'',u:'u',q:1,pu:0});render()},delL:function(i){ST.draft.lines.splice(i,1);if(!ST.draft.lines.length)ST.draft.lines.push({d:'',u:'u',q:1,pu:0});render()},
 cancel:function(){ST.draft=null;render()},
 saveD:function(){var d=ST.draft;if(!d.client)return say('Indiquez le client.','warn');if(!d.lines.some(function(l){return l.d&&l.q&&l.pu}))return say('Ajoutez au moins une ligne complète.','warn');
  var a=invs(),o=JSON.parse(JSON.stringify(d));delete o._new;o.lines=o.lines.filter(function(l){return l.d||l.pu});var i=a.findIndex(function(x){return x.id===o.id});if(i>=0)a[i]=o;else a.push(o);saveInv(a);ST.draft=null;try{audit('Facture enregistrée',o.no)}catch(e){}say('Facture '+o.no+' enregistrée.','success');render()},
 open:function(id){var i=invs().find(function(x){return x.id===id});if(!i)return;ST.draft=JSON.parse(JSON.stringify(i));ST.tab='f';render();window.scrollTo(0,0)},
 delI:function(id){if(!confirm('Supprimer cette facture et ses paiements enregistrés en caisse ?'))return;var a=invs().filter(function(x){return x.id!==id});saveInv(a);var c=cash().filter(function(x){return x.invoice_id!==id});if(c.length!==cash().length){exbCash.length=0;c.forEach(function(x){exbCash.push(x)});saveCash()}render()},
 pay:function(id){var a=invs(),i=a.find(function(x){return x.id===id});if(!i)return;var t=tot(i);var v=prompt('Montant encaissé pour '+i.no+' (reste à payer : '+m(t.reste)+') :',String(t.reste.toFixed(2)));if(v==null)return;var amt=+String(v).replace(',','.');if(!(amt>0))return say('Montant invalide.','warn');
  var mt=prompt('Mode de paiement (Espèces, Virement, Mobile money, Chèque) :','Espèces')||'',pid='PAY-'+Date.now().toString(36);
  i.payments=i.payments||[];i.payments.push({id:pid,date:today(),amount:amt,method:mt});saveInv(a);
  var p=projs().find(function(x){return x.id===i.project_id});exbCash.push({id:exbId('CASH'),date:today(),type:'in',label:'Encaissement facture '+i.no+(p?' — '+p.name:''),amount:amt,method:mt,ref:i.no,project_id:i.project_id,invoice_id:i.id,pay_id:pid});saveCash();say('Paiement enregistré et ajouté à la caisse.','success');render()},
 fromQuote:function(qid){var q=(typeof exbQuotes!=='undefined'?exbQuotes:[]).find(function(x){return x.id===qid});if(!q||!needP())return;var d=blank(ST.pid,q.client);d.currency=/^(FC|CDF)$/i.test(q.currency||'')?'FC':'USD';d.quote_id=q.id;
  d.lines=(q.lines||[]).map(function(l){return {d:l.designation||l.name||l.d||'',u:l.unit||l.u||'u',q:+(l.qty!=null?l.qty:l.q)||1,pu:+(l.pu!=null?l.pu:l.price)||0}});if(d.lines.length&&+q.imp>0){var sb=d.lines.reduce(function(a,l){return a+l.q*l.pu},0);d.lines.push({d:'Divers & imprévus ('+(+q.imp)+' %)',u:'forfait',q:1,pu:Math.round(sb*(+q.imp))/100})}if(!d.lines.length)d.lines=[{d:'Selon devis '+(q.no||''),u:'forfait',q:1,pu:+q.total||0}];ST.draft=d;ST.tab='f';render();say('Facture préparée depuis le devis '+(q.no||'')+' : vérifiez puis enregistrez.','info')},
 addE:function(){if(!needP())return;var l=$('exbch_el').value.trim(),a=+$('exbch_ea').value;if(!l||!(a>0))return say('Libellé et montant obligatoires.','warn');
  exbCash.push({id:exbId('CASH'),date:$('exbch_ed').value||today(),type:'out',label:l,amount:a,method:'',ref:'',project_id:ST.pid,category:$('exbch_ec').value});saveCash();say('Dépense enregistrée.','success');render()},
 delE:function(id){if(!confirm('Supprimer cette dépense ?'))return;var c=cash().filter(function(x){return x.id!==id});exbCash.length=0;c.forEach(function(x){exbCash.push(x)});saveCash();render()},
 pdf:function(id){var i=invs().find(function(x){return x.id===id});if(!i||!window.EXBPdf)return;var t=tot(i),cu=i.currency||'USD',p=projs().find(function(x){return x.id===i.project_id});
  var rows=[['Facture N°',i.no],['Client',i.client||'—'],['Chantier',p?p.name+(p.location?' — '+p.location:''):'—'],['Date / échéance',i.date+'  →  '+(i.due||'—')]];
  (i.lines||[]).forEach(function(l){rows.push([l.d,m(l.q)+' '+(l.u||'')+' × '+m(l.pu)+' = '+m(l.q*l.pu)+' '+cu])});
  rows.push(['Total HT',m(t.ht)+' '+cu],['TVA ('+i.tva+' %)',m(t.tva)+' '+cu],['TOTAL TTC',m(t.ttc)+' '+cu],['Déjà payé',m(t.paid)+' '+cu],['RESTE À PAYER',m(t.reste)+' '+cu]);
  EXBPdf.make({titre:'FACTURE '+i.no,sousTitre:'Statut : '+statut(i),rows:rows,notes:[i.note||'Merci de votre confiance.'],footer:'Facture '+i.no+' — Excellencia Building'}).then(function(b){EXBPdf.save(b,i.no+'.pdf')}).catch(function(e){say('PDF impossible : '+(e.message||e),'error')})}
};
window.EXBCH=Object.assign(A,{render:render,_tot:tot,_statut:statut,_bilan:bilan});
/* ---------- montage : section + bouton de menu ---------- */
function mount(){if($('chantiers'))return;var host=document.querySelector('.wrap')||document.querySelector('main')||document.body,ref=$('projets');
 var s=document.createElement('section');s.id='chantiers';s.style.display='none';s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>💼 Chantiers &amp; finances</h2><p class="exb-muted">Fiche financière par chantier, facturation avec TVA, dépenses et marge. TVA par défaut : '+TVA0+' % (modifiable sur chaque facture).</p></div></div><div id="exbch_box"></div></div>';
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
 var b=$('bprj');if(b&&!$('bchan')){var n=document.createElement('button');n.id='bchan';n.textContent='💼 Chantiers & finances';n.onclick=function(){show('chantiers')};b.parentNode.insertBefore(n,b.nextSibling)}
 var os=window.show;if(typeof os==='function'&&!window.__exbChShow){window.__exbChShow=1;window.show=function(x){var r=os.apply(this,arguments);var e=$('chantiers');if(e)e.style.display=(x==='chantiers')?'':'none';if(x==='chantiers')render();return r}}
 render()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(mount,300)});else setTimeout(mount,300);
})();
