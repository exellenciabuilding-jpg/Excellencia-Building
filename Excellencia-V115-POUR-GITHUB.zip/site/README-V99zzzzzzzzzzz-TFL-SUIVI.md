# V99zzzzzzzzzzz — TFL : suivi complet (étapes 06 à 09) sur la version « Signatures »

Reprend votre version V99zzzzzzzzzz (Signatures, habillage public, liens séparés) et y ajoute le suivi du TFL. Rien d'existant n'est retiré.

## Dans la fiche d'un dossier TFL : « 📌 Suivi de la rédaction »
- **06 · Chapitres et corrections** : plan type (5 chapitres) ou chapitres un par un avec échéance ; statut À faire / En cours / Remis / À corriger / Validé ; corrections par chapitre à cocher quand elles sont faites ; « 🧮 Calculer la progression » (validé 100, remis 70, à corriger 50, en cours 30, à faire 0 ; moyenne).
- **07 · Rendez-vous et échéances** : date, heure, objet, lieu ; case « fait » ; 💬 rappel WhatsApp ; 📆 fichier agenda (.ics) ; retards en rouge.
- **08 · Préparation de la défense** : date, heure, lieu, jury, 7 points à cocher, notes ; 💬 convocation WhatsApp ; une date fait passer le dossier à l'étape 8.
## « 📊 Tableau de bord » (en haut de la liste des dossiers)
Indicateurs (actifs, progression moyenne, sans encadreur, sans matricule, corrections à faire, défenses à venir, retards), répartition par étape, charge des encadreurs, échéances (retards + 14 jours, un clic ouvre le dossier), **rapport CSV** de tous les dossiers.
Tout est enregistré dans le dossier (sauvegarde JSON incluse), sans Internet.

## SQL
Aucun nouveau script pour cette version. Ordre complet des scripts : `supabase/ORDRE-D-EXECUTION.md` (10 scripts avec contrôles, dont `migration-v99zzzzzzzzzz-tfl-signature.sql`).

## Petite correction
`tfl-sujets.html` contenait de nouveau l'ancien message « trop de sujets réservés avec ce numéro » (limite supprimée en V99zzz) : retiré, ce qui fait repasser le contrôle automatique correspondant.

## Après mise à jour
Déposer le ZIP sur Netlify (cache `exb-v99zzz-tfl-sans-limite-signatures-suivi-8`), ouvrir le logiciel deux fois.

## Limites
Pas de dépôt de fichiers de chapitres par l'étudiant (stockage serveur nécessaire) ; corrections et rendez-vous visibles seulement dans votre logiciel (pas dans les portails) ; pas d'envoi automatique (boutons WhatsApp). Testé dans Chromium (390 px) sur une page minimale, pas sur un vrai téléphone.

## Contrôles
`node tools/test-tfl/test-suivi.js` · `python3 tools/test-tfl/e2e-suivi.py` · `node tools/test-tfl/test.js` · `node tools/check.js` · `python3 tools/e2e-liens.py`.
