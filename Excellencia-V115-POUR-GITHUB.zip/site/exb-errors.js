/* Excellencia Building V99zv — suivi d'erreurs et métriques d'usage (audit interne : « Suivi d'erreurs absent »).
 * Capte les erreurs JavaScript, les promesses rejetées, les scripts qui ne se chargent pas et les console.error ;
 * les garde sur l'appareil (journal local de 50 entrées max, hors synchronisation et hors sauvegarde) puis les envoie au serveur
 * quand l'appareil est en ligne ET connecté (rpc erreur_signaler). Aucun contenu saisi par l'utilisateur n'est lu :
 * messages nettoyés (e-mails, jetons, chiffres longs, paramètres d'adresse), pile tronquée.
 * Métriques : par jour et par appareil, nombre de sessions, écrans ouverts, erreurs. À charger EN PREMIER dans index.html. */
(function(w){'use strict';
if(w.EXBERR)return;
var VER='V99zv',LOG='exb_errlog',USE='exb_usagelog',MAXLOG=50,MAXSESSION=40,FLUSH_MS=30000;
var sent=0,timer=null,busy=false,lastFlush=0;
function ls(){try{return w.localStorage}catch(e){return null}}
function rd(k,d){try{var s=ls();var v=s&&s.getItem(k);return v?JSON.parse(v):d}catch(e){return d}}
function wr(k,v){try{var s=ls();if(s)s.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
function clean(s,n){s=String(s==null?'':s);
  s=s.replace(/eyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{5,}/g,'[jeton]')            /* JWT */
     .replace(/Bearer\s+[\w.~+\/-]+=*/gi,'Bearer [jeton]')
     .replace(/[\w.+-]+@[\w-]+(\.[\w-]+)+/g,'[e-mail]')
     .replace(/(\?|&|#)[^\s)'"]*/g,function(m){return m.charAt(0)==='#'?'#…':m.charAt(0)+'…'}) /* paramètres d'adresse */
     .replace(/\d{6,}/g,'[nombre]');
  return s.slice(0,n||300)}
function hash(s){var h=5381;for(var i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return (h>>>0).toString(36)}
function today(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function where(){try{var x=w.location;return clean(x.pathname.split('/').pop()||'index',60)+(x.hash?'#'+clean(x.hash.slice(1),40):'')}catch(e){return ''}}
function ignore(m){return /ResizeObserver loop|^Script error\.?$|Non-Error promise rejection captured|AbortError|The user aborted|Load failed$|NetworkError when attempting to fetch|Failed to fetch$/i.test(m)}
function firstFrame(st){var l=String(st||'').split('\n');for(var i=0;i<l.length;i++){if(/\.js|\.html/.test(l[i]))return clean(l[i].trim(),160)}return ''}

/* ---------- journal local ---------- */
function record(kind,message,stack,extra){
  try{
    message=clean(message,300);if(!message||ignore(message))return;
    var frame=firstFrame(stack),fp=hash(kind+'|'+message.replace(/\d+/g,'#')+'|'+frame.replace(/:\d+:\d+/,'')),
        log=rd(LOG,[]),now=new Date().toISOString(),e=null;
    for(var i=0;i<log.length;i++)if(log[i].f===fp){e=log[i];break}
    if(e){e.n=(e.n||1)+1;e.t=now;e.s=0}   /* s=0 : à renvoyer */
    else{log.push({f:fp,k:kind,m:message,p:clean(stack,900),g:where(),v:VER,n:1,t0:now,t:now,s:0,x:extra||''});if(log.length>MAXLOG)log=log.slice(-MAXLOG)}
    wr(LOG,log);bumpUse('erreurs');schedule();
  }catch(x){}
}
function schedule(){if(timer)return;timer=setTimeout(function(){timer=null;flush()},Math.max(2000,FLUSH_MS-(Date.now()-lastFlush)))}

/* ---------- métriques d'usage ---------- */
function bumpUse(what,key){try{
  var u=rd(USE,{}),d=today(),r=u[d]||(u[d]={sessions:0,erreurs:0,vues:{},s:0});
  if(what==='vue'){var k=clean(key,40);if(k&&(r.vues[k]||Object.keys(r.vues).length<40))r.vues[k]=(r.vues[k]||0)+1}else r[what]=(r[what]||0)+1;
  r.s=0;var ks=Object.keys(u).sort();while(ks.length>14)delete u[ks.shift()];wr(USE,u)}catch(e){}}

/* ---------- envoi ---------- */
function online(){return w.navigator?w.navigator.onLine!==false:true}
function loggedIn(){try{return !!(w.exbSb&&w.exbSb.isIn&&w.exbSb.isIn())}catch(e){return false}}
function flush(){
  if(busy||!online()||!loggedIn()||!w.exbSb.api)return Promise.resolve(false);
  var log=rd(LOG,[]),use=rd(USE,{}),items=log.filter(function(e){return !e.s}).slice(0,20),
      days=Object.keys(use).filter(function(d){return !use[d].s}).slice(-3);
  if(sent>=MAXSESSION&&items.length)items=[];
  if(!items.length&&!days.length)return Promise.resolve(true);
  busy=true;lastFlush=Date.now();
  var body={p_items:items.map(function(e){return{empreinte:e.f,source:e.k,message:e.m,pile:e.p,page:e.g,version:e.v,nb:e.n,premiere:e.t0,derniere:e.t,agent:agent(),extra:e.x}}),
            p_usage:days.map(function(d){return{jour:d,version:VER,sessions:use[d].sessions,erreurs:use[d].erreurs,vues:use[d].vues}})};
  return w.exbSb.api('/rest/v1/rpc/erreur_signaler',{method:'POST',body:JSON.stringify(body)}).then(function(){
    sent+=items.length;
    var l2=rd(LOG,[]);items.forEach(function(it){l2.forEach(function(e){if(e.f===it.f&&e.n===it.n)e.s=1})});wr(LOG,l2);
    var u2=rd(USE,{});days.forEach(function(d){if(u2[d]&&u2[d].sessions===use[d].sessions&&u2[d].erreurs===use[d].erreurs)u2[d].s=1});wr(USE,u2);
    busy=false;return true}).catch(function(){busy=false;return false})}
function agent(){try{var n=w.navigator,u=n.userAgent||'',b=(/(Edg|OPR|Chrome|Firefox|Version)\/(\d+)/.exec(u)||[])[0]||'',o=/Android/.test(u)?'Android':/iPhone|iPad/.test(u)?'iOS':/Windows/.test(u)?'Windows':/Mac/.test(u)?'macOS':/Linux/.test(u)?'Linux':'?';
  return clean(o+' · '+b+' · '+w.innerWidth+'x'+w.innerHeight+(n.onLine===false?' · hors ligne':''),120)}catch(e){return ''}}

/* ---------- capture ---------- */
w.addEventListener('error',function(ev){
  try{
    var t=ev.target;
    if(t&&t!==w&&t.tagName){ /* ressource qui ne se charge pas (script, feuille de style) */
      if(/^(SCRIPT|LINK)$/.test(t.tagName))record('ressource','Chargement impossible : '+clean(t.src||t.href||'',120),'');
      return}
    var er=ev.error;record('erreur',(er&&er.message)||ev.message,(er&&er.stack)||(ev.filename?'at '+ev.filename+':'+ev.lineno+':'+ev.colno:''));
  }catch(x){}},true);
w.addEventListener('unhandledrejection',function(ev){
  try{var r=ev.reason;record('promesse',(r&&r.message)||(typeof r==='string'?r:'Promesse rejetée'),(r&&r.stack)||'')}catch(x){}});
try{var ce=w.console&&w.console.error;if(ce&&!ce.__exb){var wrap=function(){try{var a=[].slice.call(arguments).map(function(x){return x&&x.message?x.message:(typeof x==='object'?'':String(x))}).join(' ').trim();if(a)record('console',a,'')}catch(x){}return ce.apply(this,arguments)};wrap.__exb=1;w.console.error=wrap}}catch(e){}
w.addEventListener('online',function(){schedule()});
w.addEventListener('visibilitychange',function(){if(w.document.visibilityState==='hidden')flush()});
/* la session compte une fois par ouverture ; les écrans ouverts sont comptés en enveloppant show() une fois la page chargée */
bumpUse('sessions');
w.addEventListener('load',function(){setTimeout(function(){
  try{if(typeof w.show==='function'&&!w.show.__exbUse){var os=w.show;w.show=function(x){try{if(typeof x==='string')bumpUse('vue',x)}catch(e){}return os.apply(this,arguments)};w.show.__exbUse=1}}catch(e){}
  schedule()},3000)});

/* ---------- API publique : journal local, copie, panneau propriétaire ---------- */
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function fr(d){try{return new Date(d).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'})}catch(e){return d||''}}
function srvErr(e){var m=String(e&&e.message||e);return /erreur_signaler|owner_erreurs|42883|404|function/i.test(m)?'Suivi non activé : exécutez supabase/migration-v99zv-suivi-erreurs.sql dans Supabase.':m}
function panel(el,isOwner){
  if(!el)return;
  var log=rd(LOG,[]).slice().reverse();
  el.innerHTML='<div class="card"><h2>🐞 Erreurs et usage</h2>'+
    '<p class="hint">Journal de cet appareil : '+log.length+' erreur(s) distincte(s). Envoi automatique au serveur quand l’appareil est connecté.</p>'+
    '<div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0"><button class="muted" id="exe_cp">📋 Copier le journal</button><button class="muted" id="exe_cl">🗑 Vider le journal local</button><button class="muted" id="exe_fl">⬆ Envoyer maintenant</button>'+(isOwner?'<button class="primary" id="exe_sv">↻ Voir les erreurs de tous les clients</button>':'')+'</div>'+
    '<div id="exe_loc">'+(log.length?'<div class="tablewrap"><table class="tbl"><thead><tr><th>Dernière fois</th><th>Type</th><th>Message</th><th>×</th></tr></thead><tbody>'+log.slice(0,15).map(function(e){return'<tr><td>'+esc(fr(e.t))+'</td><td>'+esc(e.k)+'</td><td>'+esc(e.m)+'<br><span class="hint">'+esc(e.g)+' · '+esc(e.v)+(e.s?' · envoyée':' · en attente')+'</span></td><td>'+(+e.n||1)+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="hint">Aucune erreur enregistrée sur cet appareil. ✓</p>')+'</div><div id="exe_srv"></div></div>';
  var $=function(i){return el.querySelector('#'+i)};
  $('exe_cp').onclick=function(){var t=JSON.stringify({version:VER,agent:agent(),erreurs:rd(LOG,[]),usage:rd(USE,{})},null,1);
    (w.navigator.clipboard?w.navigator.clipboard.writeText(t):Promise.reject()).then(function(){alert('Journal copié.')},function(){w.prompt('Copiez le journal :',t)})};
  $('exe_cl').onclick=function(){if(confirm('Vider le journal local des erreurs ?')){wr(LOG,[]);panel(el,isOwner)}};
  $('exe_fl').onclick=function(){flush().then(function(ok){alert(ok?'Envoi terminé.':'Envoi impossible (hors ligne ou non connecté).');panel(el,isOwner)})};
  if(isOwner&&$('exe_sv'))$('exe_sv').onclick=function(){loadServer($('exe_srv'))}}
function loadServer(box){
  if(!loggedIn()){box.innerHTML='<p class="ann">Connectez-vous à votre compte en ligne.</p>';return}
  box.innerHTML='<p class="hint">Chargement…</p>';
  w.exbSb.api('/rest/v1/rpc/owner_erreurs',{method:'POST',body:JSON.stringify({p_jours:14})}).then(function(r){
    var g=(r&&r.erreurs)||[],u=(r&&r.usage)||[];
    box.innerHTML='<h3 style="margin:14px 0 6px">Erreurs des 14 derniers jours</h3>'+(g.length?'<div class="tablewrap"><table class="tbl"><thead><tr><th>Dernière fois</th><th>Message</th><th>×</th><th>Appareils</th><th>Version</th><th></th></tr></thead><tbody>'+g.map(function(e,i){return'<tr><td>'+esc(fr(e.derniere))+'</td><td>'+esc(e.message)+'<br><span class="hint">'+esc(e.source)+' · '+esc(e.page||'')+'<br>'+esc(e.pile||'')+'</span></td><td>'+e.nb+'</td><td>'+e.appareils+'</td><td>'+esc(e.version)+'</td><td><button class="muted" data-r="'+i+'">'+(e.resolu?'Rouvrir':'✓ Résolue')+'</button></td></tr>'}).join('')+'</tbody></table></div>':'<p class="hint">Aucune erreur remontée. ✓</p>')+
    '<h3 style="margin:14px 0 6px">Usage (14 jours)</h3>'+(u.length?'<div class="tablewrap"><table class="tbl"><thead><tr><th>Jour</th><th>Appareils actifs</th><th>Sessions</th><th>Erreurs</th><th>Écrans les plus ouverts</th></tr></thead><tbody>'+u.map(function(x){return'<tr><td>'+esc(x.jour)+'</td><td>'+x.appareils+'</td><td>'+x.sessions+'</td><td>'+x.erreurs+'</td><td>'+esc(x.top||'')+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="hint">Pas encore de données.</p>');
    box.querySelectorAll('button[data-r]').forEach(function(b){b.onclick=function(){var e=g[+b.dataset.r];
      w.exbSb.api('/rest/v1/rpc/owner_erreur_resoudre',{method:'POST',body:JSON.stringify({p_empreinte:e.empreinte,p_resolu:!e.resolu})}).then(function(){loadServer(box)}).catch(function(x){alert(srvErr(x))})}})
  }).catch(function(e){box.innerHTML='<p class="ann">'+esc(srvErr(e))+'</p>'})}

w.EXBERR={version:VER,record:record,flush:flush,panel:panel,log:function(){return rd(LOG,[])},usage:function(){return rd(USE,{})},_clean:clean,_hash:hash};
})(window);
