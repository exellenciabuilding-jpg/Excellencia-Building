/* exb-bcf.js — V99 : BCF 2.1 (BIM Collaboration Format) — échange des observations BIM avec Revit, Solibri, BIMcollab, Navisworks…
 *   EXB_BCF.build(rows, ctx)  -> Uint8Array (fichier .bcfzip)   rows = lignes de EXB_ARCH.bimRows() ; ctx = { project, author, modelName(id) }
 *   EXB_BCF.parse(Uint8Array) -> Promise<{ version, project, topics:[…], skipped }>   topics prêts pour EXB_ARCH.importBcf
 * Contenu exporté par observation : sujet (titre, type Issue/Clash, statut, priorité, étiquettes = disciplines, responsable,
 * description avec localisation, date de création) + point de vue avec le GlobalId IFC de l'élément concerné (sélection).
 * Limites : pas de capture d'écran ni de caméra (le logiciel n'enregistre pas de point de vue 3D), pas de commentaires multiples,
 * pas de pièces jointes. À l'import, les points de vue ne servent qu'à retrouver le GlobalId du premier élément sélectionné. */
(function (root) {
  'use strict';
  var Z = function () { return root.EXB_ZIP || (typeof require !== 'undefined' ? require('./exb-zip.js') : null); };
  var esc = function (v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]; }); };
  /* nom de fichier « sûr » dans l'archive : pas de dossier parent, pas de caractère interdit */
  /* ---- identifiants : UUID stable calculé à partir de l'identifiant de l'observation ---- */
  function h128(s) {
    var h1 = 1779033703, h2 = 3144134277, h3 = 1013904242, h4 = 2773480762, i, k;
    for (i = 0; i < s.length; i++) { k = s.charCodeAt(i); h1 = h2 ^ Math.imul(h1 ^ k, 597399067); h2 = h3 ^ Math.imul(h2 ^ k, 2869860233); h3 = h4 ^ Math.imul(h3 ^ k, 951274213); h4 = h1 ^ Math.imul(h4 ^ k, 2716044179); }
    h1 = Math.imul(h3 ^ (h1 >>> 18), 597399067); h2 = Math.imul(h4 ^ (h2 >>> 22), 2869860233); h3 = Math.imul(h1 ^ (h3 >>> 17), 951274213); h4 = Math.imul(h2 ^ (h4 >>> 19), 2716044179);
    return [(h1 ^ h2 ^ h3 ^ h4) >>> 0, (h2 ^ h1) >>> 0, (h3 ^ h1) >>> 0, (h4 ^ h1) >>> 0];
  }
  var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function uuidOf(seed) {
    seed = String(seed == null ? '' : seed); if (UUID.test(seed)) return seed.toLowerCase();
    var w = h128(seed), hx = w.map(function (x) { return ('00000000' + x.toString(16)).slice(-8); }).join('');
    return hx.slice(0, 8) + '-' + hx.slice(8, 12) + '-4' + hx.slice(13, 16) + '-' + '89ab'[parseInt(hx[16], 16) & 3] + hx.slice(17, 20) + '-' + hx.slice(20, 32);
  }
  /* ---- correspondances libellés français du logiciel ⇄ BCF ---- */
  var ST_OUT = { 'Ouvert': 'Open', 'Assigné': 'Assigned', 'En correction': 'In Progress', 'À vérifier': 'Resolved', 'Clôturé': 'Closed' };
  var PR_OUT = { 'Normale': 'Normal', 'Haute': 'High', 'Critique': 'Critical' };
  function statusIn(s) {
    s = String(s || '').toLowerCase().replace(/[^a-zà-ÿ ]/g, '').trim();
    if (/clos|clôtur|closed|done|termin|fini|ferm/.test(s)) return 'Clôturé';
    if (/resolv|verif|vérif|to ?verify|review|contrôl/.test(s)) return 'À vérifier';
    if (/progress|en cours|correction|working|fixing|actif|active/.test(s)) return 'En correction';
    if (/assign/.test(s)) return 'Assigné';
    return 'Ouvert';
  }
  function priorityIn(s) {
    s = String(s || '').toLowerCase();
    if (/crit|urgent|blocker|blocking|bloquant/.test(s)) return 'Critique';
    if (/high|haut|major|majeur|élev|elev/.test(s)) return 'Haute';
    return 'Normale';
  }
  var iso = function (v) { var d = v ? new Date(v) : new Date(); return (isNaN(d) ? new Date() : d).toISOString(); };
  var safeName = function (s) { return String(s || 'modele').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').slice(0, 120); };

  /* ================= export ================= */
  function topicXml(r, ctx, guid, vpGuid) {
    var model = ctx.modelName ? ctx.modelName(r.model) : '', labels = [r.disc, r.disc2].filter(Boolean);
    var desc = [r.title, labels.length ? 'Disciplines : ' + labels.join(' / ') : '', r.loc ? 'Localisation : ' + r.loc : '', r.guid ? 'Élément IFC (GlobalId) : ' + r.guid : ''].filter(Boolean).join('\n');
    var x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Markup xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">\n';
    x += '  <Header>' + (model ? '<File IsExternal="true"><Filename>' + esc(model) + '</Filename></File>' : '') + '</Header>\n';
    x += '  <Topic Guid="' + guid + '" TopicType="' + (r.disc2 ? 'Clash' : 'Issue') + '" TopicStatus="' + esc(ST_OUT[r.status] || 'Open') + '">\n';
    x += '    <Title>' + esc(r.title || 'Observation') + '</Title>\n    <Priority>' + esc(PR_OUT[r.priority] || 'Normal') + '</Priority>\n';
    labels.forEach(function (l) { x += '    <Labels>' + esc(l) + '</Labels>\n'; });
    x += '    <CreationDate>' + iso(r.createdAt) + '</CreationDate>\n    <CreationAuthor>' + esc(ctx.author || 'Excellencia Building') + '</CreationAuthor>\n';
    x += '    <ModifiedDate>' + iso(r.modifiedAt || r.createdAt) + '</ModifiedDate>\n';
    if (r.owner) x += '    <AssignedTo>' + esc(r.owner) + '</AssignedTo>\n';
    x += '    <Description>' + esc(desc) + '</Description>\n  </Topic>\n';
    if (vpGuid) x += '  <Viewpoints Guid="' + vpGuid + '">\n    <Viewpoint>viewpoint.bcfv</Viewpoint>\n  </Viewpoints>\n';
    return x + '</Markup>\n';
  }
  function viewpointXml(vpGuid, ifcGuid) {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<VisualizationInfo Guid="' + vpGuid + '">\n  <Components>\n    <Selection>\n      <Component IfcGuid="' + esc(ifcGuid) + '"/>\n    </Selection>\n    <Visibility DefaultVisibility="true"/>\n  </Components>\n</VisualizationInfo>\n';
  }
  function build(rows, ctx) {
    ctx = ctx || {}; var zip = Z(); if (!zip) throw new Error('Module ZIP absent (exb-zip.js).');
    var files = [], seen = Object.create(null);
    files.push({ name: 'bcf.version', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Version VersionId="2.1" xsi:noNamespaceSchemaLocation="version.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">\n  <DetailedVersion>2.1</DetailedVersion>\n</Version>\n' });
    files.push({ name: 'project.bcfp', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<ProjectExtension xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">\n  <Project ProjectId="' + uuidOf('prj|' + (ctx.project || '')) + '">\n    <Name>' + esc(ctx.project || 'Excellencia Building') + '</Name>\n  </Project>\n  <ExtensionSchema></ExtensionSchema>\n</ProjectExtension>\n' });
    (rows || []).forEach(function (r) {
      var guid = uuidOf(r.bcf || r.id), n = 1; while (seen[guid]) guid = uuidOf((r.bcf || r.id) + '#' + (++n)); seen[guid] = 1;
      var vp = r.guid && /^[0-9A-Za-z_$]{22}$/.test(r.guid) ? uuidOf('vp|' + guid) : null;
      files.push({ name: guid + '/markup.bcf', data: topicXml(r, ctx, guid, vp) });
      if (vp) files.push({ name: guid + '/viewpoint.bcfv', data: viewpointXml(vp, r.guid) });
    });
    return zip.store(files);
  }

  /* ================= lecture XML minimale (sans DOMParser, donc testable hors navigateur) ================= */
  function decode(s) { return String(s).replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, function (m, e) { e = e.toLowerCase(); if (e === 'amp') return '&'; if (e === 'lt') return '<'; if (e === 'gt') return '>'; if (e === 'quot') return '"'; if (e === 'apos') return "'"; try { return String.fromCodePoint(e[1] === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (x) { return ''; } }); }
  function xml(src) {
    src = String(src).replace(/^﻿/, '').replace(/<\?[\s\S]*?\?>/g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/<!DOCTYPE[^>]*>/gi, '');
    var re = /<!\[CDATA\[([\s\S]*?)\]\]>|<(\/?)([A-Za-z_][\w:.-]*)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g, m, root = { n: '#root', a: {}, c: [], t: '' }, st = [root], cur = root;
    while ((m = re.exec(src))) {
      if (m[1] !== undefined) { cur.t += m[1]; continue; }
      if (m[6] !== undefined) { cur.t += decode(m[6]); continue; }
      var name = m[3].replace(/^.*:/, '');
      if (m[2]) { if (st.length > 1 && st[st.length - 1].n === name) st.pop(); cur = st[st.length - 1]; continue; }
      var at = {}, ar = /([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g, am; while ((am = ar.exec(m[4] || ''))) at[am[1].replace(/^.*:/, '')] = decode(am[2] !== undefined ? am[2] : am[3]);
      var node = { n: name, a: at, c: [], t: '' }; cur.c.push(node); if (!m[5]) { st.push(node); cur = node; }
    }
    return root;
  }
  var kids = function (n, name) { return n ? n.c.filter(function (x) { return x.n === name; }) : []; };
  var kid = function (n, name) { return kids(n, name)[0] || null; };
  var txt = function (n, name) { var k = kid(n, name); return k ? k.t.trim() : ''; };
  function find(n, name, out) { out = out || []; if (!n) return out; n.c.forEach(function (x) { if (x.n === name) out.push(x); find(x, name, out); }); return out; }

  function parse(u8) {
    var zip = Z(); if (!zip) return Promise.reject(new Error('Module ZIP absent (exb-zip.js).'));
    return zip.unzip(u8).then(function (files) {
      var byName = Object.create(null); files.forEach(function (f) { byName[f.name.replace(/\\/g, '/')] = f.data; });
      var T = function (nm) { return nm in byName ? zip.text(byName[nm]) : null; };
      var vsrc = T('bcf.version'), version = vsrc ? (txt(kid(xml(vsrc), 'Version'), 'DetailedVersion') || (kid(xml(vsrc), 'Version') || { a: {} }).a.VersionId || '') : '';
      if (!vsrc && !files.some(function (f) { return /(^|\/)markup\.bcf$/i.test(f.name); })) throw new Error('Ce fichier n’est pas un BCF (aucun bcf.version ni markup.bcf).');
      var proj = ''; var psrc = T('project.bcfp'); if (psrc) { var pn = find(xml(psrc), 'Name'); proj = pn[0] ? pn[0].t.trim() : ''; }
      var topics = [], skipped = 0;
      Object.keys(byName).filter(function (k) { return /(^|\/)markup\.bcf$/i.test(k); }).sort().forEach(function (k) {
        try {
          var folder = k.replace(/markup\.bcf$/i, ''), mk = xml(zip.text(byName[k])).c.filter(function (x) { return x.n === 'Markup'; })[0], tp = kid(mk, 'Topic');
          if (!tp) { skipped++; return; }
          var labels = kids(tp, 'Labels').map(function (l) { return l.t.trim(); }).filter(Boolean), desc = txt(tp, 'Description'), ifcGuid = '', model = '';
          var fl = find(kid(mk, 'Header'), 'Filename'); if (fl[0]) model = fl[0].t.trim();
          /* GlobalId : premier élément sélectionné d'un point de vue de ce sujet (BCF 2.x : fichiers .bcfv du dossier) */
          Object.keys(byName).filter(function (q) { return q.indexOf(folder) === 0 && /\.bcfv$/i.test(q); }).sort().some(function (q) {
            var comps = []; find(xml(zip.text(byName[q])), 'Selection').forEach(function (sl) { find(sl, 'Component', comps); }); comps = comps.filter(function (c) { return c.a.IfcGuid && /^[0-9A-Za-z_$]{22}$/.test(c.a.IfcGuid); });
            if (comps.length) { ifcGuid = comps[0].a.IfcGuid; return true; } return false;
          });
          var loc = (/(?:^|\n)\s*Localisation\s*:\s*(.+)/i.exec(desc) || [])[1] || '';
          topics.push({
            bcf: tp.a.Guid || uuidOf(k), title: txt(tp, 'Title') || 'Observation BCF', status: statusIn(tp.a.TopicStatus), priority: priorityIn(txt(tp, 'Priority')),
            owner: txt(tp, 'AssignedTo'), disc: labels[0] || '', disc2: labels[1] || '', loc: loc.trim(), guid: ifcGuid, model: model,
            description: desc, createdAt: txt(tp, 'CreationDate'), author: txt(tp, 'CreationAuthor'), type: tp.a.TopicType || ''
          });
        } catch (e) { skipped++; }
      });
      return { version: version, project: proj, topics: topics, skipped: skipped };
    });
  }

  var api = { build: build, parse: parse, uuidOf: uuidOf, xml: xml, version: 'V99' };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.EXB_BCF = api;
})(typeof window !== 'undefined' ? window : globalThis);
