# Plan éditeur — escalier manuel et dalle manuelle (façon ArchiCAD)

Fichiers : `plan-editeur/manuel.js` (nouveau), `index.html`, `vue3d.js`, `coupes.js`, `exports.js`, `sw.js`. Les plans existants s'ouvrent comme avant (nouvelles listes `slabs` et `stairs` par niveau, vides par défaut).

## Escalier manuel (bouton « Escalier manuel »)
- Touchez le départ (en bas), puis chaque changement de direction, puis l'arrivée ; Entrée ou double-toucher pour finir.
- Chaque segment est une volée ; chaque point intermédiaire devient un palier carré (largeur × largeur). Le tracé peut être quelconque, sans rapport avec un modèle du catalogue.
- Largeur dans la barre du haut. Fiche : hauteur à franchir (0 = niveau + dalle), nombre de contremarches (0 = auto), hauteur de marche visée, trémie automatique, confort 2H+G, volume béton, inversion du sens.
- Poignées : carrés = points du tracé, ronds « + » = nouveau virage, double-toucher un point = le retirer, glisser l'intérieur = déplacer.
- Trémie découpée seule dans les dalles « plancher » du niveau supérieur.

## Dalle manuelle (« Dalle manuelle » ou « Dalle rectangle »)
- Contour libre point par point. Types : plancher, dallage, balcon, terrasse ; épaisseur et cote du dessus réglables.
- Dès qu'un niveau porte une dalle tracée, son plancher automatique est remplacé.
- Fiche : copie sur le niveau du dessus, rectangle englobant, surface nette, volume béton.

## Partout ailleurs
Vue 3D (sélection au clic), coupes et façades, visite virtuelle, métré et devis (prix « escalier béton armé » à régler), export DXF (calques DALLES et ESCALIERS), copier-coller, symétrie, rotation.
