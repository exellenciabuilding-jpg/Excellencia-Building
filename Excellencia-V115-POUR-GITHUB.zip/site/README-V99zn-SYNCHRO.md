# V99zn — Synchronisation des modules ERP, BTP et paiements + protection des données sensibles

## Ce qui change
- **Synchronisés entre appareils** (comme les clients, devis, stock… déjà synchronisés) : ERP V92 (CRM, fournisseurs, demandes d'achat, commandes, réceptions, factures fournisseurs, stock, mouvements, banques, transactions, salariés, contrats, paies), BTP V93 (projets, chantiers, tâches, QHSE, matériel, sous-traitance), paiements V93 (moyens, paiements, opérations de caisse), workflow formation V95 et liens V97. Avant : ces données restaient sur l'appareil.
- **Même moteur que le reste du logiciel** : une fiche = un enregistrement versionné, détection de conflit (la version du collègue est gardée, la vôtre va dans « Conflits »), journal des opérations, droits par fonction appliqués par le serveur.
- **Données sensibles** (personnel, paie, contrats RH, rapprochement bancaire et leurs équivalents V92) : un membre « polyvalent » n'y a plus accès, ni en lecture ni en écriture, côté serveur comme dans le navigateur. Avant, « polyvalent » avait un accès complet à la paie via le stockage générique.
- **Moyens de paiement par défaut** : identifiants fixes (PM-cash, PM-bank_transfer…), pour que chaque appareil ne crée plus ses propres doublons ; les doublons déjà créés sont réduits à un seul.
- Un changement de droits n'efface plus les données locales jamais synchronisées.

## Mise en service
1. Faire une sauvegarde Supabase, puis exécuter `supabase/migration-v99zn-synchro-modules.sql` **en dernier** (après `migration-v98-unifie.sql`). Réexécutable.
2. Déployer les fichiers (cache hors ligne `exb-v99zn-synchro-modules-1` : les appareils se mettent à jour à la prochaine ouverture en ligne).
3. Donner la bonne fonction aux membres qui doivent voir la paie ou la banque :
   `update membres set fonction='comptable' where user_id='…' and org_id='…';` (fonctions : rh, comptable, direction).
4. Sur chaque appareil, ouvrir 🗄 Base partagée › Synchroniser maintenant : les données locales V92/V93 existantes sont envoyées au serveur.

## Vérifications faites
- `node tools/check.js` : voir le résultat de `node tools/check.js`.
- Simulation multi-appareils (`cd tools/test-synchro && python3 test.py <dossier du site>`, Chromium + faux serveur reproduisant les règles SQL) : 12/12 — commande créée sur A reçue sur B, conflit, 6 moyens de paiement sans doublon, paie invisible et non modifiable pour un membre polyvalent, lecture et écriture directes refusées.
- Migration exécutée sur un vrai PostgreSQL 16 (avec une imitation du schéma d'authentification Supabase) : polyvalent refusé sur la paie et la banque, comptable autorisé, administrateur autorisé, lecture filtrée par les politiques de sécurité.

## Limites
- **Non testé sur votre vrai Supabase ni dans l'application complète sur téléphone** : à essayer d'abord sur un projet de recette avec 3 comptes (administrateur, polyvalent, comptable).
- Les 12 tables `erp_*` de `migration-v92-erp.sql` restent inutilisées (les modules passent par `enregistrements`).
- Deux circuits de stock et deux de paie coexistent toujours (anciens modules et V92) ; la paie V92 n'a pas de calcul : utiliser « Paie & RH » (V81).
- Les données des modules Formation (participants, présence, évaluations) ne sont pas dans cette synchronisation.
- En cas de conflit, la version du collègue gagne et la vôtre est conservée dans « Conflits » (comportement existant).
- Les membres « polyvalent » existants perdent l'accès à la paie, au personnel et à la banque tant qu'ils n'ont pas de fonction adaptée.
