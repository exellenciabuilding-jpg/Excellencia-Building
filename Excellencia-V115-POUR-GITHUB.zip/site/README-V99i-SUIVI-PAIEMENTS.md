# V99i — Suivi des paiements des apprenants

**Où ?** 👤 Participants › bouton **💰 Paiements (qui a payé ?)**.

- Pour chaque apprenant approuvé : **Inscription** (payée / non payée) et **Frais de formation** (non payée / moitié / payée en totalité).
- Filtres : Tous · Formation payée · Moitié · Non payée · Inscription non payée ; recherche ; filtre par formation.
- Boutons : 🧾 Reçu (préremplit le reçu), 💰 Inscription payée, 🟡 Moitié, ✅ Payé en totalité, ↩ Non payé, 🕘 Historique.
- Quand l'apprenant paie plus tard : touchez simplement le nouveau statut (ou faites un reçu), l'historique garde la trace.
- Export **Excel (CSV)** et **Imprimer / PDF** (avec logo) de la liste filtrée.
- Dans la liste des participants, un badge 💰 sous la formation montre le statut.
- Le statut vient du **dernier reçu** enregistré, ou de votre saisie manuelle si elle est plus récente.
- Mobile Money : quand vous **Confirmez** un paiement d'apprenant dans 🌐 Site vitrine, une question demande s'il s'agit de l'inscription, de la moitié ou de la totalité, puis le statut se met à jour.

Limites : suivi local (comme les participants) ; pas de montants par versement (statuts seulement) ; sauvegardez via Registre & sauvegarde.
