/* EXCELLENCIA INTELLIGENCE — lot 5 : métrés, devis et plans.
 * Extension (à charger APRÈS exb-intelligence.js). Complète les liaisons existantes (EXBLIEN : métré ↔ client/chantier ; plans ↔ projet) sans les dupliquer.
 *  • Métrés : numéros en double, client/projet introuvables, valeurs négatives, matériaux sans prix ou sans quantité, désignations en double, métré vide.
 *  • Métré ↔ devis (même numéro) : client différent, matériau du métré absent du devis ou quantité différente.
 *  • Devis : lignes à quantité/prix invalides, désignations en double, total ≠ lignes × (1 + imprévus %), « Client à renseigner », client/projet introuvables.
 *  • Plans (fiches) : projet introuvable, même référence + indice en double, mesures sans échelle.
 *  • Correction guidée : recalcul du total d'un devis (confirmation + annulable). Documents : dossier métré-devis-plans par projet (HTML, hors ligne).
 * Tout le reste est en LECTURE SEULE. Pour retirer : supprimer la balise <script src="exb-intelligence-5.js">. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot5) return; I.lot5 = true;
    var H = I.helpers, list = H.list, lab = H.lab, num = H.num, norm = H.norm, esc = H.esc, toast = H.toast;
    function money(x) { return (Math.round(x * 100) / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
    function F(sev, mod, msg, col, id, extra) { var o = { sev: sev, mod: mod, msg: msg, ref: { col: col, id: id } }; if (extra) for (var k in extra) o[k] = extra[k]; return o; }
    function canW(c) { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can(c, 'ecrire'); } catch (e) { return true; } }
    function dupBy(arr, keyFn, col, mod, what, sev) {
      var seen = {}, out = []; arr.forEach(function (o) { var k = keyFn(o); if (!k) return; if (seen[k]) out.push(F(sev || 'alerte', mod, 'Doublon possible (' + what + ') : « ' + lab(seen[k]) + ' » et « ' + lab(o) + ' »', col, o.id)); else seen[k] = o; });
      return out;
    }
    function mets() { return list('exb_metre').filter(function (m) { return m && m.hdr; }); }
    function mlab(m) { return (m.hdr && (m.hdr.no || m.hdr.project || m.hdr.client)) || m.name || m.id || '?'; }
    function extras(m) { return Array.isArray(m.extra) ? m.extra : []; }
    function qlines(q) { return Array.isArray(q.lines) ? q.lines : []; }

    /* ---- moteurs spécialisés ---- */
    I.calc.devis = function (q) { var ht = qlines(q).reduce(function (a, l) { return a + num(l.qty) * num(l.pu); }, 0), imp = Math.max(0, num(q.imp)); return { ht: ht, imp: imp, total: ht * (1 + imp / 100) }; };
    I.calc.metreExtras = function (m) { return extras(m).reduce(function (a, l) { return a + num(l.q) * num(l.pu); }, 0); };
    I.registerEngine('calcul.devis', 'Contrôle des métrés, devis et plans (total devis = lignes × (1 + imprévus %))', function () { return []; });

    /* ---- métrés ---- */
    I.addRule({ id: 'met.doublon', check: function () {
      var seen = {}, out = []; mets().forEach(function (m) { var k = m.hdr.no ? norm(m.hdr.no) : ''; if (!k) return; if (seen[k]) out.push(F('erreur', 'Métré', 'Doublon possible (même numéro de métré « ' + m.hdr.no + ' ») : ' + (seen[k].hdr.client || seen[k].hdr.project || seen[k].id) + ' et ' + (m.hdr.client || m.hdr.project || m.id), 'exb_metre', m.id)); else seen[k] = m; });
      return out; } });
    I.addRule({ id: 'met.liens', check: function () {
      var out = [], C = list('exb_clients'), P = list('exb_projects');
      mets().forEach(function (m) {
        var nm = 'Métré ' + mlab(m) + ' : ', id = m.id;
        if (m.client_id && C.length && !C.some(function (c) { return c.id === m.client_id; })) out.push(F('erreur', 'Métré', nm + 'client rattaché introuvable', 'exb_metre', id));
        else if (!m.client_id && !m.hdr.client) out.push(F('info', 'Métré', nm + 'aucun client', 'exb_metre', id));
        if (m.project_id && P.length && !P.some(function (p) { return p.id === m.project_id; })) out.push(F('erreur', 'Métré', nm + 'projet rattaché introuvable', 'exb_metre', id));
        else if (!m.project_id && m.hdr.project && P.length && !P.some(function (p) { return norm(p.name) === norm(m.hdr.project); })) out.push(F('info', 'Métré', nm + 'le projet « ' + m.hdr.project + ' » n’existe pas dans les projets', 'exb_metre', id));
      }); return out; } });
    I.addRule({ id: 'met.valeurs', check: function () {
      var out = [];
      mets().forEach(function (m) {
        var nm = 'Métré ' + mlab(m) + ' : ', id = m.id, neg = 0, filled = 0, ov = m.ov || {};
        Object.keys(ov).forEach(function (sh) { var o = ov[sh] || {}; Object.keys(o).forEach(function (a) { var v = o[a]; if (typeof v === 'number') { if (v < 0) neg++; if (v !== 0) filled++; } else if (v !== '' && v != null) filled++; }); });
        if (neg) out.push(F('erreur', 'Métré', nm + neg + ' valeur(s) négative(s) dans les paramètres', 'exb_metre', id));
        var seen = {};
        extras(m).forEach(function (l, i) {
          var dn = String(l.d || '').trim(), q = num(l.q), pu = num(l.pu), tag = '« ' + (dn || 'ligne ' + (i + 1)) + ' » ';
          if (q > 0 || pu > 0) filled++;
          if (!dn && (q > 0 || pu > 0)) out.push(F('alerte', 'Métré', nm + 'matériau ajouté sans désignation (ligne ' + (i + 1) + ')', 'exb_metre', id));
          if (q < 0 || pu < 0) out.push(F('erreur', 'Métré', nm + tag + ': quantité ou prix négatif', 'exb_metre', id));
          else if (q > 0 && pu <= 0) out.push(F('alerte', 'Métré', nm + tag + ': quantité sans prix unitaire', 'exb_metre', id));
          else if (pu > 0 && q <= 0) out.push(F('info', 'Métré', nm + tag + ': prix sans quantité', 'exb_metre', id));
          if (dn) { var k = norm(dn); if (seen[k]) out.push(F('info', 'Métré', nm + tag + ': désignation en double', 'exb_metre', id)); seen[k] = 1; }
        });
        if (!filled) out.push(F('info', 'Métré', nm + 'métré vide (aucune quantité saisie)', 'exb_metre', id));
      }); return out; } });
    I.addRule({ id: 'met.devis', check: function () {
      var out = [], Q = list('exb_quotes');
      mets().forEach(function (m) {
        if (!m.hdr.no) return;
        var q = Q.filter(function (x) { return x.no && norm(x.no) === norm(m.hdr.no); })[0]; if (!q) return;
        var nm = 'Métré ' + mlab(m) + ' ↔ devis ' + q.no + ' : ';
        if (m.hdr.client && q.client && q.client !== 'Client à renseigner' && norm(m.hdr.client) !== norm(q.client)) out.push(F('alerte', 'Métré ↔ devis', nm + 'client différent (« ' + m.hdr.client + ' » / « ' + q.client + ' »)', 'exb_metre', m.id));
        var QL = qlines(q), miss = 0, diff = 0;
        extras(m).forEach(function (l) {
          if (num(l.q) <= 0 || !String(l.d || '').trim()) return;
          var ql = QL.filter(function (x) { return norm(x.designation) === norm(l.d); })[0];
          if (!ql) miss++; else if (Math.abs(num(ql.qty) - num(l.q)) > 0.0005) diff++;
        });
        if (miss) out.push(F('alerte', 'Métré ↔ devis', nm + miss + ' matériau(x) du métré absent(s) du devis (devis non mis à jour ?)', 'exb_metre', m.id));
        if (diff) out.push(F('alerte', 'Métré ↔ devis', nm + diff + ' quantité(s) différente(s) entre le métré et le devis', 'exb_metre', m.id));
      }); return out; } });

    /* ---- devis ---- */
    I.addRule({ id: 'dev.lignes', check: function () {
      var out = [];
      list('exb_quotes').forEach(function (q) {
        var nm = 'Devis ' + lab(q) + ' : ', id = q.id, seen = {};
        qlines(q).forEach(function (l, i) {
          var tag = '« ' + (String(l.designation || '').trim() || 'ligne ' + (i + 1)) + ' » ';
          if (!String(l.designation || '').trim()) out.push(F('alerte', 'Devis', nm + 'ligne ' + (i + 1) + ' sans désignation', 'exb_quotes', id));
          if (num(l.qty) < 0 || num(l.pu) < 0) out.push(F('erreur', 'Devis', nm + tag + ': quantité ou prix négatif', 'exb_quotes', id));
          else if (num(l.qty) === 0 && num(l.pu) > 0) out.push(F('alerte', 'Devis', nm + tag + ': quantité nulle', 'exb_quotes', id));
          else if (num(l.pu) === 0 && num(l.qty) > 0) out.push(F('alerte', 'Devis', nm + tag + ': prix unitaire nul', 'exb_quotes', id));
          var k = norm(l.designation) + '|' + norm(l.unit); if (norm(l.designation)) { if (seen[k]) out.push(F('info', 'Devis', nm + tag + ': ligne en double', 'exb_quotes', id)); seen[k] = 1; }
        });
        if (num(q.imp) < 0 || num(q.imp) > 100) out.push(F('alerte', 'Devis', nm + 'imprévus de ' + num(q.imp) + ' % inhabituel', 'exb_quotes', id));
        if (!q.currency && qlines(q).length) out.push(F('info', 'Devis', nm + 'devise non précisée', 'exb_quotes', id));
      }); return out; } });
    I.addRule({ id: 'dev.total', check: function () {
      var out = [];
      list('exb_quotes').forEach(function (q) {
        if (!qlines(q).length || !('total' in q)) return;
        var c = I.calc.devis(q); if (Math.abs(c.total - num(q.total)) > 0.01) out.push(F('erreur', 'Devis', 'Devis ' + lab(q) + ' : total enregistré ' + money(num(q.total)) + ' ≠ total recalculé ' + money(c.total) + ' ' + (q.currency || ''), 'exb_quotes', q.id, { calc: c.total }));
      }); return out; } });
    I.addRule({ id: 'dev.liens', check: function () {
      var out = [], C = list('exb_clients'), P = list('exb_projects');
      list('exb_quotes').forEach(function (q) {
        var nm = 'Devis ' + lab(q) + ' : ';
        if (q.client === 'Client à renseigner') out.push(F('alerte', 'Devis', nm + 'client à renseigner (devis issu du métré)', 'exb_quotes', q.id));
        else if (q.client && !q.client_id && C.length && !C.some(function (c) { return norm(c.name || c.full_name) === norm(q.client); })) out.push(F('info', 'Devis', nm + 'client « ' + q.client + ' » absent de la liste des clients', 'exb_quotes', q.id));
        if (q.project && P.length && !P.some(function (p) { return norm(p.name) === norm(q.project); })) out.push(F('info', 'Devis', nm + 'projet « ' + q.project + ' » absent de la liste des projets', 'exb_quotes', q.id));
      }); return out; } });

    /* ---- plans ---- */
    I.addRule({ id: 'plan.fiches', check: function () {
      var out = [], PF = list('exb_plan_files'), P = list('exb_projects');
      PF.forEach(function (f) {
        var nm = 'Plan « ' + (f.ref || f.name || f.id) + ' » : ';
        if (f.project && P.length && !P.some(function (p) { return p.id === f.project; })) out.push(F('erreur', 'Plans', nm + 'projet rattaché introuvable', 'exb_plan_files', f.id));
        if (!f.project && P.length) out.push(F('info', 'Plans', nm + 'aucun projet rattaché', 'exb_plan_files', f.id));
        if (Array.isArray(f.mesures) && f.mesures.length && !num(f.echelle)) out.push(F('alerte', 'Plans', nm + f.mesures.length + ' mesure(s) enregistrée(s) sans échelle', 'exb_plan_files', f.id));
      });
      return out.concat(dupBy(PF, function (f) { return f.ref && f.ver ? norm(f.project || '') + '|' + norm(f.ref) + '|' + norm(f.ver) : ''; }, 'exb_plan_files', 'Plans', 'même référence et même indice dans le projet', 'erreur')); } });

    /* ---- correction guidée : recalcul du total d'un devis (annulable) ---- */
    function live() { try { if (typeof exbQuotes !== 'undefined') return exbQuotes; } catch (e) {} return list('exb_quotes'); }
    function save(arr) { try { if (typeof exbSave === 'function' && typeof EXB_ECO_KEYS !== 'undefined') exbSave(EXB_ECO_KEYS.quotes, arr); else { var st = (typeof exbStorage !== 'undefined') ? exbStorage : w.localStorage; st.setItem('exb_quotes', JSON.stringify(arr)); } } catch (e) {} try { if (typeof renderExbQuotes === 'function') renderExbQuotes(); } catch (e) {} }
    function recalc(id) {
      if (!canW('metreDevis')) { toast('Droits insuffisants pour modifier les devis.'); return Promise.resolve(); }
      var A = live(), q = A.filter(function (x) { return x.id === id; })[0]; if (!q) { toast('Devis introuvable : relancez le contrôle.'); return Promise.resolve(); }
      var c = I.calc.devis(q).total, old = q.total;
      return I.confirm('Recalculer le total du devis ?', 'Devis ' + lab(q) + ' : ' + money(num(old)) + ' → ' + money(c) + ' ' + (q.currency || '') + ' (lignes × (1 + imprévus %)). Les lignes ne sont pas modifiées. Annulable depuis l’historique.', 'Recalculer').then(function (ok) {
        if (!ok) return; q.total = Math.round(c * 100) / 100; save(A);
        I.log('correction', 'Total du devis ' + lab(q) + ' recalculé (' + money(num(old)) + ' → ' + money(c) + ')', { undo: { type: 'devis_total', data: { id: id, old: old } } }); toast('Total recalculé.');
      });
    }
    I.registerUndo('devis_total', function (data) { var A = live(); A.forEach(function (q) { if (q.id === data.id) q.total = data.old; }); save(A); });
    I.addFixer('dev.total', function (f) { return { label: 'Recalculer…', run: function () { return recalc(f.ref.id); } }; });

    /* ---- documents ---- */
    function dossierHtml() {
      var P = list('exb_projects'), M = mets(), Q = list('exb_quotes'), PF = list('exb_plan_files'), t = H.today();
      function sec(title, mm, qq, pp) {
        var r = '<h2>' + esc(title) + '</h2>';
        r += '<h3>Métrés</h3>' + (mm.length ? '<ul>' + mm.map(function (m) { return '<li>' + esc(mlab(m)) + ' — client : ' + esc(m.hdr.client || '—') + ' — matériaux ajoutés : ' + money(I.calc.metreExtras(m)) + '</li>'; }).join('') + '</ul>' : '<p>Aucun.</p>');
        r += '<h3>Devis</h3>' + (qq.length ? '<table border="1" cellpadding="5" style="border-collapse:collapse"><tr><th>N°</th><th>Client</th><th>Date</th><th>Total</th></tr>' + qq.map(function (q) { return '<tr><td>' + esc(q.no || '') + '</td><td>' + esc(q.client || '') + '</td><td>' + esc(q.date || '') + '</td><td align="right">' + money(I.calc.devis(q).total) + ' ' + esc(q.currency || '') + '</td></tr>'; }).join('') + '</table>' : '<p>Aucun.</p>');
        r += '<h3>Plans</h3>' + (pp.length ? '<ul>' + pp.map(function (f) { return '<li>' + esc(f.ref || f.name || '') + ' — indice ' + esc(f.ver || '—') + ' — ' + esc(f.date || '') + '</li>'; }).join('') + '</ul>' : '<p>Aucun.</p>');
        return r;
      }
      var body = P.map(function (p) {
        return sec(lab(p), M.filter(function (m) { return m.project_id === p.id || (!m.project_id && m.hdr.project && norm(m.hdr.project) === norm(p.name)); }), Q.filter(function (q) { return q.project && norm(q.project) === norm(p.name); }), PF.filter(function (f) { return f.project === p.id; }));
      }).join('');
      var used = function (arr, fn) { return arr.filter(function (x) { return !P.some(function (p) { return fn(x, p); }); }); };
      var oM = used(M, function (m, p) { return m.project_id === p.id || (!m.project_id && m.hdr.project && norm(m.hdr.project) === norm(p.name)); }), oQ = used(Q, function (q, p) { return q.project && norm(q.project) === norm(p.name); }), oP = used(PF, function (f, p) { return f.project === p.id; });
      if (oM.length || oQ.length || oP.length) body += sec('Hors projet', oM, oQ, oP);
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Dossier métré-devis-plans</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Dossier métrés, devis et plans</h1><p>' + t + '</p>' + (body || '<p>Aucune donnée.</p>') + '</body></html>';
    }
    function dl(name, html, what) { try { var b = new Blob([html], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); I.log('document', what); } catch (e) { toast('Export impossible.'); } }
    I.docs.metreDevisPlans = dossierHtml;

    /* ---- recommandations ---- */
    I.addReco(function () {
      var r = [], M = mets(), Q = list('exb_quotes');
      var sans = M.filter(function (m) { return m.hdr.no && !Q.some(function (q) { return q.no && norm(q.no) === norm(m.hdr.no); }) && (extras(m).length || m.ov); });
      if (sans.length) r.push({ ic: '📐', t: sans.length + ' métré(s) sans devis correspondant', x: 'Aucun devis ne porte le même numéro. Ouvrez le métré et utilisez le transfert vers le devis.', acts: [{ l: 'Ouvrir Métré & devis', f: function () { H.go('metreDevis'); } }] });
      var ph = Q.filter(function (q) { return q.client === 'Client à renseigner'; }).length;
      if (ph) r.push({ ic: '🧾', t: ph + ' devis avec « Client à renseigner »', x: 'Renseignez le client avant l’envoi.', acts: [{ l: 'Ouvrir les devis', f: function () { H.go('metreDevis'); } }] });
      if (M.length || Q.length || list('exb_plan_files').length) r.push({ ic: '📁', t: 'Dossier métrés, devis et plans par projet', x: 'Un document réunissant, pour chaque projet, ses métrés, devis et plans.', acts: [{ l: 'Télécharger le dossier', f: function () { dl('dossier-metre-devis-plans-' + H.today() + '.html', dossierHtml(), 'Dossier métrés-devis-plans exporté'); } }] });
      return r;
    });
    I.run();
  }
  boot(0);
})(window, document);
