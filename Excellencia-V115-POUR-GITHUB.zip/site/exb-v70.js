/* EXCELLENCIA BUILDING V70 — PLANS, COUPES & STRUCTURE
 * Extension non destructive de V69. Registre les livrables graphiques d'etudes
 * et les plans structurels, avec revision, visa et liaison CDE.
 */
(function(w,d){'use strict';
var KEY='exb_drawings_v70', TAB='exbPlansV70';
var TYPES=['Plan architectural','Coupe architecturale','Façade','Plan de situation','Plan de masse','Plan de fondations','Plan de coffrage','Plan de ferraillage','Plan de charpente','Détail structurel','Plan de toiture','Plan VRD','Plan électrique','Plan plomberie','Détail architectural','Autre'];
var DISC=['Architecture','Structure','VRD','Électricité','Plomberie','CVC','Autre'];
var ST=['WIP','Shared','Review','Approved','Published','Superseded'];
function today(){return new Date().toISOString().slice(0,10)}
function esc(x){return String(x==null?'':x).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function load(){try{return w.EXBS.get(KEY)}catch(e){return[]}}
function save(a){w.EXBS.set(KEY,a)}
function projects(){try{return w.EXBS.projects()}catch(e){return[]}}
function pname(id){var p=projects().find(function(x){return String(x.id)===String(id)});return p?(p.nom||p.name||p.titre||p.title||p.id):'—'}
function opt(arr,val){return arr.map(function(x){return '<option '+(x===val?'selected':'')+'>'+esc(x)+'</option>'}).join('')}
function popt(val){return '<option value="">— Projet —</option>'+projects().map(function(p){var id=p.id||p.project_id,n=p.nom||p.name||p.titre||p.title||id;return '<option value="'+esc(id)+'" '+(String(id)===String(val)?'selected':'')+'>'+esc(n)+'</option>'}).join('')}
function input(label,key,val,extra){return '<label>'+label+'<input id="v70_'+key+'" value="'+esc(val||'')+'" '+(extra||'')+'></label>'}
function select(label,key,val,arr){return '<label>'+label+'<select id="v70_'+key+'">'+opt(arr,val)+'</select></label>'}
function button(t,fn,cl){return '<button class="'+(cl||'muted')+'" onclick="'+fn+'">'+t+'</button>'}
function data(){return load()}
function render(){var box=d.getElementById(TAB);if(!box)return;var a=data();
 var counts={};a.forEach(function(x){counts[x.type]=(counts[x.type]||0)+1});
 var h='<div class="card"><div class="exb-module-head"><div><h2>📐 Plans, coupes & structure</h2><p class="exb-muted">Registre central des livrables graphiques : architecture, coupes, façades et plans structurels.</p></div></div>';
 h+='<div class="exb-grid"><div><b>'+a.length+'</b><br><small>Livrables</small></div><div><b>'+a.filter(x=>x.discipline==='Structure').length+'</b><br><small>Structure</small></div><div><b>'+a.filter(x=>x.status==='Published').length+'</b><br><small>Publiés</small></div><div><b>'+a.filter(x=>x.status==='Review').length+'</b><br><small>En revue</small></div></div>';
 h+='<div class="exb-actions" style="margin-top:10px">'+button('➕ Nouveau plan / coupe','EXBV70.newDrawing()','primary')+button('📊 Vue structure','EXBV70.filterStructure()')+button('🧹 Réinitialiser','EXBV70.clearFilter()')+'</div>';
 h+='<div id="v70_form"></div><div class="exb-scroll"><table class="exb-table"><thead><tr><th>Référence</th><th>Type</th><th>Projet</th><th>Discipline</th><th>Indice</th><th>Échelle</th><th>Statut</th><th></th></tr></thead><tbody>';
 a.forEach(function(x){h+='<tr><td><b>'+esc(x.ref)+'</b><br><small>'+esc(x.title)+'</small></td><td>'+esc(x.type)+'</td><td>'+esc(pname(x.project_id))+'</td><td>'+esc(x.discipline)+'</td><td>'+esc(x.revision)+'</td><td>'+esc(x.scale)+'</td><td>'+esc(x.status)+'</td><td>'+button('Ouvrir','EXBV70.edit(\''+x.id+'\')')+'</td></tr>'});
 h+=a.length?'':'<tr><td colspan="8">Aucun livrable graphique enregistré.</td></tr>';h+='</tbody></table></div></div>';box.innerHTML=h}
function form(x){x=x||{id:'v70-'+Date.now(),revision:'A',status:'WIP',date:today()};var b=d.getElementById('v70_form');if(!b)return;
 b.innerHTML='<div class="card" style="margin-top:10px"><h3>📄 Livrable graphique</h3><div class="exb-grid">'+input('Référence *','ref',x.ref)+input('Titre *','title',x.title)+
 '<label>Projet *<select id="v70_project_id">'+popt(x.project_id)+'</select></label>'+select('Type','type',x.type||TYPES[0],TYPES)+select('Discipline','discipline',x.discipline||'Architecture',DISC)+
 input('Niveau / zone','level',x.level)+input('Échelle','scale',x.scale||'1/50')+input('Indice','revision',x.revision||'A')+select('Statut CDE','status',x.status||'WIP',ST)+
 input('Responsable','author',x.author)+input('Référence CDE','cde_ref',x.cde_ref)+input('Date','date',x.date||today())+input('Note / liaison calcul','calc_ref',x.calc_ref)+'</div><div class="exb-actions">'+button('💾 Enregistrer','EXBV70.save()','primary')+button('Annuler','EXBV70.cancel()')+'</div></div>'}
function newD(){form()}
function edit(id){var x=load().find(function(a){return a.id===id});form(x)}
function saveD(){var a=load(),id=d.getElementById('v70_id');var old=id? a.find(function(x){return x.id===id.value}):null;var x=old||{id:'v70-'+Date.now()};['ref','title','project_id','type','discipline','level','scale','revision','status','author','cde_ref','date','calc_ref'].forEach(function(k){var e=d.getElementById('v70_'+k);if(e)x[k]=e.value});if(!x.ref||!x.title||!x.project_id){alert('Référence, titre et projet sont obligatoires.');return}if(old)Object.assign(old,x);else a.unshift(x);save(a);render()}
function addHidden(){var b=d.getElementById('v70_form');if(b&&!d.getElementById('v70_id')){var i=d.createElement('input');i.type='hidden';i.id='v70_id';b.prepend(i)}}
function edit2(id){var x=load().find(function(a){return a.id===id});form(x);addHidden();d.getElementById('v70_id').value=x.id}
function new2(){form();addHidden();d.getElementById('v70_id').value=''}
function filterStructure(){var a=load().filter(x=>x.discipline==='Structure');var old=load;renderFiltered(a)}
function renderFiltered(a){var box=d.getElementById(TAB);if(!box)return;var all=load();render();var table=box.querySelector('tbody');if(table)table.innerHTML=a.length?a.map(function(x){return '<tr><td><b>'+esc(x.ref)+'</b><br><small>'+esc(x.title)+'</small></td><td>'+esc(x.type)+'</td><td>'+esc(pname(x.project_id))+'</td><td>'+esc(x.discipline)+'</td><td>'+esc(x.revision)+'</td><td>'+esc(x.scale)+'</td><td>'+esc(x.status)+'</td><td>'+button('Ouvrir','EXBV70.edit(\''+x.id+'\')')+'</td></tr>'}).join(''):'<tr><td colspan="8">Aucun plan de structure.</td></tr>'}
function mount(){if(d.getElementById(TAB))return;var host=d.querySelector('.wrap')||d.querySelector('main')||d.body,s=d.createElement('section');s.id=TAB;s.style.display='none';host.appendChild(s);var nav=d.getElementById('bbet');if(nav&&!d.getElementById('bv70plans')){var n=d.createElement('button');n.id='bv70plans';n.textContent='📐 Plans & Structure';n.onclick=function(){show(TAB)};nav.parentNode.insertBefore(n,nav.nextSibling)}var os=w.show;if(typeof os==='function'&&!w.__exbV70Show){w.__exbV70Show=1;w.show=function(x){var r=os.apply(this,arguments),e=d.getElementById(TAB);if(e)e.style.display=x===TAB?'':'none';if(x===TAB)render();return r}}}
w.EXBV70={newDrawing:new2,newD:new2,edit:edit2,save:saveD,cancel:function(){var b=d.getElementById('v70_form');if(b)b.innerHTML=''},filterStructure:filterStructure,clearFilter:render};
d.addEventListener('DOMContentLoaded',mount);setTimeout(mount,1500);
})(window,document);
