/* Excellencia Building V99 — LIAISON, tranche 4 (extension de exb-liaison*.js).
 * 1. Chantiers V93 (BTP Enterprise) ↔ projets du logiciel (`core_project_id`) ; tâches, chantiers, QHSE, matériel, sous-traitants suivent leur projet.
 * 2. Notes de calcul et missions du bureau d'études ↔ client du projet (`client_id`) ; BIM / plans / documents V94 contrôlés (lecture seule).
 * 3. « Dossier chantier » : tout ce qui touche un chantier sur un seul écran (finances, achats, études, plans, BIM, V93, terrain).
 * 4. « Clients en double » : détection (téléphone, e-mail, nom identique) et fusion sur confirmation, sans perte (journal complet de la fiche supprimée).
 * Même principe qu'avant : on AJOUTE des identifiants, aucun lien n'est deviné quand plusieurs candidats existent, rien n'est créé automatiquement. */
(function (w, d) {
  'use strict';
  function boot(tries) {
    var X = w.EXBLIEN;
    if (!X || !X.extend || !X.ops) { if ((tries || 0) > 90) return; return setTimeout(function () { boot((tries || 0) + 1); }, 400); }
    var wr = X.wr, norm = X.norm, digits = X.digits, esc = X.esc, num = X.num, r2 = X.r2, fmt = X.fmt;
    var K = { cli: 'exb_clients', prj: 'exb_projects', qt: 'exb_quotes', st: 'exb_studies', inv: 'exb_invoices', cash: 'exb_cash', v93pay: 'exb_v93_payments',
      mv: 'exb_stock_moves', met: 'exb_metre', cn: 'exb_calc_notes', mi: 'exb_be_missions',
      v93p: 'exb_v93_projects', v93s: 'exb_v93_sites', v93t: 'exb_v93_tasks', v93h: 'exb_v93_hse', v93e: 'exb_v93_equipment', v93c: 'exb_v93_subcontracts',
      v94dr: 'exb_v94_drawings', v94rv: 'exb_v94_revisions', v94dc: 'exb_v94_documents', v94bm: 'exb_v94_bim_models', v94bi: 'exb_v94_bim_issues', v94st: 'exb_v94_studies',
      jr: 'exb_site_journal', sit: 'exb_situations', ts: 'exb_timesheets', po: 'exb_purchase_orders', pf: 'exb_plan_files' };
    var CLIENT_KEYS = [K.prj, K.qt, K.st, K.inv, K.cash, K.v93pay, K.mv, K.met, K.cn, K.mi, K.v93p];

    /* lecture : les collections V94 passent par le pont commun EXBS quand il existe (même zone de stockage) */
    function rd(k) { try { if (w.EXBS && typeof w.EXBS.get === 'function' && /^exb_v94_/.test(k)) { var v = w.EXBS.get(k); if (Array.isArray(v)) return v; } } catch (e) {} return X.rd(k); }
    function uniq(a) { return a.length === 1 ? a[0] : null; }
    function setIf(o, k, v) { if (v && !o[k]) { o[k] = v; return true; } return false; }
    function can(c) { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can(c, 'ecrire'); } catch (e) { return true; } }
    function pIndex() { var P = X.rd(K.prj), byId = {}, byName = {}; P.forEach(function (p) { byId[p.id] = p; var k = norm(p.name); if (k) (byName[k] = byName[k] || []).push(p); }); return { P: P, byId: byId, byName: byName }; }
    function cIndex() { var C = X.rd(K.cli), byId = {}; C.forEach(function (c) { byId[c.id] = c; }); return { C: C, byId: byId }; }
    function cname(c) { return c ? (c.full_name || c.company || c.id) : ''; }

    /* ======================= 1. V93 + BE ======================= */
    function linkAll() {
      var pi = pIndex(), res = { v93: 0, enfants: 0, be: 0 };
      var P = X.rd(K.v93p), chP = false, coreOf = {};
      P.forEach(function (p) {
        var core = (p.core_project_id && pi.byId[p.core_project_id]) || pi.byId[p.id] || (p.project_id && pi.byId[p.project_id]) || null;
        if (!core) { var h = pi.byName[norm(p.name || p.title)]; core = h && h.length === 1 ? h[0] : null; }
        if (!core) return;
        coreOf[p.id] = core; var mod = false;
        if (setIf(p, 'core_project_id', core.id)) mod = true;
        if (core.client_id && setIf(p, 'client_id', core.client_id)) mod = true;
        if (mod) { res.v93++; chP = true; }
      });
      if (chP) wr(K.v93p, P);
      var siteCore = {};
      X.rd(K.v93s).forEach(function (s) { var c = (s.core_project_id && pi.byId[s.core_project_id]) || (s.project_id && (coreOf[s.project_id] || pi.byId[s.project_id])); if (c) siteCore[s.id] = c; });
      [K.v93s, K.v93t, K.v93h, K.v93e, K.v93c].forEach(function (key) {
        var L = X.rd(key), ch = false;
        L.forEach(function (o) {
          var c = (o.core_project_id && pi.byId[o.core_project_id]) || (o.project_id && (coreOf[o.project_id] || pi.byId[o.project_id])) || (o.site_id && siteCore[o.site_id]) || null;
          if (c && setIf(o, 'core_project_id', c.id)) { res.enfants++; ch = true; }
        });
        if (ch) wr(key, L);
      });
      [K.cn, K.mi].forEach(function (key) {
        var L = X.rd(key), ch = false;
        L.forEach(function (o) { var p = o.project_id && pi.byId[o.project_id]; if (p && p.client_id && setIf(o, 'client_id', p.client_id)) { res.be++; ch = true; } });
        if (ch) wr(key, L);
      });
      res.total = res.v93 + res.enfants + res.be;
      if (res.total) X.log('liaison_v93_be', res, res.total + ' fiche(s) V93 / bureau d’études rattachée(s)');
      return res;
    }

    function anomaliesProjets() {
      var pi = pIndex(), a = [], v93ids = {}, v93 = X.rd(K.v93p);
      v93.forEach(function (p) { v93ids[p.id] = 1; });
      function known(id) { return !!(id && (pi.byId[id] || v93ids[id])); }
      function bad(label, list, get) { var n = list.filter(function (o) { var p = get(o); return p && !known(p); }).length; if (n) a.push(n + ' ' + label + ' rattaché(e)(s) à un chantier introuvable'); }
      bad('note(s) de calcul', X.rd(K.cn), function (o) { return o.project_id; });
      bad('mission(s) du bureau d’études', X.rd(K.mi), function (o) { return o.project_id; });
      bad('plan(s) (registre)', rd(K.v94dr), function (o) { return o.project_id; });
      bad('document(s) du dossier numérique', rd(K.v94dc), function (o) { return o.project_id; });
      bad('maquette(s) BIM', rd(K.v94bm), function (o) { return o.project_id; });
      bad('problème(s) BIM', rd(K.v94bi), function (o) { return o.project_id; });
      bad('étude(s) technique(s) V94', rd(K.v94st), function (o) { return o.project_id; });
      bad('entrée(s) du journal de chantier', X.rd(K.jr), function (o) { return o.project_id; });
      bad('situation(s) de travaux', X.rd(K.sit), function (o) { return o.project_id; });
      bad('tâche(s) / chantier(s) V93', X.rd(K.v93t).concat(X.rd(K.v93s)), function (o) { return o.project_id; });
      v93.forEach(function (p) { if (!p.core_project_id) a.push('Projet V93 « ' + (p.name || p.title || p.id) + ' » : aucun projet correspondant dans le logiciel (relier par le même nom ou le même identifiant)'); });
      var g = dupGroups(); if (g.length) a.push(g.length + ' groupe(s) de clients en double possible : Clients › « Clients en double »');
      return a;
    }

    /* ======================= 2. Dossier chantier ======================= */
    function dossier(pid) {
      var pi = pIndex(), p = pi.byId[pid]; if (!p) return null;
      var ci = cIndex(), c = p.client_id ? ci.byId[p.client_id] : null, sit = X.situation({ projectId: pid }), R = X.ops.resultat().chantiers.filter(function (r) { return r.project_id === pid; })[0] || { dep: {}, mo: 0 };
      function mine(list, f) { return list.filter(function (o) { return (f ? f(o) : o.project_id) === pid; }); }
      var v93p = X.rd(K.v93p).filter(function (x) { return x.core_project_id === pid; }), tasks = mine(X.rd(K.v93t), function (o) { return o.core_project_id; });
      var avg = tasks.length ? Math.round(tasks.reduce(function (a, t) { return a + num(t.progress); }, 0) / tasks.length) : null;
      var hse = mine(X.rd(K.v93h), function (o) { return o.core_project_id; }).filter(function (x) { return x.status !== 'closed'; }).length;
      var dr = mine(rd(K.v94dr)), drIds = {}; dr.forEach(function (x) { drIds[x.id] = 1; });
      var bi = mine(rd(K.v94bi)).filter(function (x) { return !/^(closed|resolved|ferm|r[ée]solu|clos)/i.test(String(x.status || '')); }).length;
      var days = mine(X.rd(K.ts)).reduce(function (a, t) { return a + num(t.days); }, 0);
      return { id: pid, nom: p.name, client: cname(c), budget: num(p.budget), finances: sit.total, dep: R.dep, mo: R.mo,
        tiles: [
          ['Devis', mine(X.rd(K.qt)).length], ['Factures', mine(X.rd(K.inv)).length], ['Commandes d’achat', mine(X.rd(K.po)).length], ['Mouvements de stock', mine(X.rd(K.mv)).length],
          ['Études', mine(X.rd(K.st)).length + mine(rd(K.v94st)).length], ['Notes de calcul', mine(X.rd(K.cn)).length], ['Plans', dr.length], ['Révisions de plans', rd(K.v94rv).filter(function (r) { return drIds[r.drawing_id]; }).length],
          ['Documents', mine(rd(K.v94dc)).length], ['Maquettes BIM', mine(rd(K.v94bm)).length], ['Problèmes BIM ouverts', bi], ['Missions du bureau d’études', mine(X.rd(K.mi)).length],
          ['Journal de chantier', mine(X.rd(K.jr)).length], ['Jours pointés', Math.round(days * 10) / 10], ['Situations de travaux', mine(X.rd(K.sit)).length],
          ['Projet V93', v93p.length], ['Tâches V93' + (avg == null ? '' : ' (avancement ' + avg + ' %)'), tasks.length], ['Alertes QHSE ouvertes', hse]
        ] };
    }
    function money(o) { var ks = Object.keys(o || {}); return ks.length ? ks.map(function (c) { return fmt(o[c]) + ' ' + c; }).join(' · ') : '—'; }
    function dossierHtml(pid) {
      var D = dossier(pid); if (!D) return '';
      var f = Object.keys(D.finances).map(function (c) { var b = D.finances[c]; return '<tr><td>' + esc(c) + '</td><td style="text-align:right">' + fmt(b.devis) + '</td><td style="text-align:right">' + fmt(b.facture) + '</td><td style="text-align:right">' + fmt(b.verse) + '</td><td style="text-align:right">' + fmt(b.solde) + '</td></tr>'; }).join('');
      return '<p style="margin:4px 0"><b>' + esc(D.nom) + '</b>' + (D.client ? ' — client : ' + esc(D.client) : ' — <i>aucun client relié</i>') + (D.budget ? ' — budget ' + fmt(D.budget) : '') + '</p>' +
        '<div style="overflow-x:auto"><table class="exb-table"><thead><tr><th>Devise</th><th>Devis</th><th>Facturé</th><th>Versé</th><th>Solde</th></tr></thead><tbody>' + (f || '<tr><td colspan="5" class="exb-muted">Aucun devis, facture ni paiement.</td></tr>') + '</tbody></table></div>' +
        '<p class="exb-muted" style="font-size:12px;margin:6px 0">Dépenses : ' + money(D.dep) + (D.mo ? ' · main-d’œuvre pointée à payer : ' + fmt(D.mo) : '') + '</p>' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px">' + D.tiles.map(function (t) { return '<div style="padding:8px;border:1px solid #e2e8f0;border-radius:10px;background:#fff"><strong style="display:block;font-size:18px">' + esc(t[1]) + '</strong><span style="font-size:11px;color:#64748b">' + esc(t[0]) + '</span></div>'; }).join('') + '</div>';
    }
    function renderDossier() {
      var host = d.getElementById('exbLienPrj'); if (!host) return;
      var P = X.rd(K.prj), sel = d.getElementById('exbLienPrjSel'), cur = sel ? sel.value : '';
      var head = '<h3 style="margin:0 0 8px">🔗 Dossier chantier connecté</h3><select id="exbLienPrjSel" style="max-width:100%"><option value="">— Choisir un chantier —</option>' + P.map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === cur ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select><div id="exbLienPrjOut" style="margin-top:8px"></div>';
      if (host.getAttribute('data-sig') !== head) { host.innerHTML = head; host.setAttribute('data-sig', head); }
      var s = d.getElementById('exbLienPrjSel'), o = d.getElementById('exbLienPrjOut');
      function show() { if (o) o.innerHTML = s.value ? dossierHtml(s.value) : ''; }
      s.onchange = show; show();
    }

    /* ======================= 3. Clients en double ======================= */
    function usage(cid) { var n = 0; CLIENT_KEYS.forEach(function (k) { X.rd(k).forEach(function (o) { if (o && o.client_id === cid) n++; }); }); return n; }
    function dupGroups() {
      var C = X.rd(K.cli), par = C.map(function (_, i) { return i; }), why = {};
      function find(i) { while (par[i] !== i) { par[i] = par[par[i]]; i = par[i]; } return i; }
      function union(i, j, r) { var a = find(i), b = find(j); if (a !== b) par[b] = a; (why[find(i)] = why[find(i)] || {})[r] = 1; }
      var seen = {};
      C.forEach(function (c, i) {
        [['même téléphone', digits(c.phone).length >= 9 ? 'T' + digits(c.phone).slice(-9) : ''], ['même e-mail', String(c.email || '').trim() ? 'E' + String(c.email).trim().toLowerCase() : ''], ['même nom', norm(c.full_name || c.company) ? 'N' + norm(c.full_name || c.company) : '']].forEach(function (kv) {
          if (!kv[1]) return; if (seen[kv[1]] !== undefined) union(seen[kv[1]], i, kv[0]); else seen[kv[1]] = i;
        });
      });
      var groups = {}; C.forEach(function (c, i) { var r = find(i); (groups[r] = groups[r] || []).push(c); });
      var out = []; Object.keys(groups).forEach(function (r) { if (groups[r].length > 1) { var reasons = {}; groups[r].forEach(function (c, i) { var f = find(C.indexOf(c)); Object.keys(why[f] || {}).forEach(function (k) { reasons[k] = 1; }); }); out.push({ clients: groups[r], raisons: Object.keys(reasons) }); } });
      return out;
    }
    var SKIP = { id: 1, created_at: 1, updated_at: 1, client_snapshot: 1 };
    function mergeClients(keepId, dupIds) {
      if (!can('clients')) throw Error('Droits insuffisants pour fusionner des clients');
      var ci = cIndex(), keep = ci.byId[keepId], gone = {};
      if (!keep) throw Error('Client à conserver introuvable');
      var dups = (dupIds || []).filter(function (id) { return id !== keepId && ci.byId[id]; });
      if (!dups.length) throw Error('Aucun client à fusionner');
      dups.forEach(function (id) { gone[id] = 1; });
      var snaps = dups.map(function (id) { return JSON.parse(JSON.stringify(ci.byId[id])); }), filled = [];
      dups.forEach(function (id) { var dc = ci.byId[id]; Object.keys(dc).forEach(function (k) { if (SKIP[k]) return; var v = dc[k]; if (v === undefined || v === null || v === '') return; if (keep[k] === undefined || keep[k] === null || keep[k] === '') { keep[k] = v; filled.push(k); } }); });
      var moved = 0;
      CLIENT_KEYS.forEach(function (k) { var L = X.rd(k), ch = false; L.forEach(function (o) { if (o && o.client_id && gone[o.client_id]) { o.client_id = keepId; moved++; ch = true; } }); if (ch) wr(k, L); });
      var C = ci.C; for (var i = C.length - 1; i >= 0; i--) if (gone[C[i].id]) C.splice(i, 1);
      wr(K.cli, C);
      try { X.propagateClient(keepId); } catch (e) {}
      X.log('client_fusion', { conserve: keepId, supprimes: snaps, champs_completes: filled, fiches_deplacees: moved }, dups.length + ' client(s) fusionné(s) dans « ' + cname(keep) + ' » (' + moved + ' fiche(s) rattachée(s))');
      try { if (typeof w.renderExbClients === 'function') w.renderExbClients(); if (typeof w.renderExbProjects === 'function') w.renderExbProjects(); } catch (e) {}
      try { X.refresh(); } catch (e) {}
      return { conserve: keepId, supprimes: dups, fiches_deplacees: moved, champs_completes: filled };
    }
    function renderDup() {
      var host = d.getElementById('exbLienDup'); if (!host) return;
      var G = dupGroups();
      var html = '<h3 style="margin:0 0 8px">👥 Clients en double' + (G.length ? ' (' + G.length + ')' : '') + '</h3>';
      if (!G.length) html += '<p class="exb-muted">Aucun doublon détecté (téléphone, e-mail ou nom identique).</p>';
      else html += '<p class="exb-muted" style="font-size:12px">Choisissez la fiche à conserver : les autres sont fusionnées dedans (chantiers, devis, factures, paiements rattachés). Les informations manquantes sont reprises, et la fiche supprimée reste dans le journal de liaison.</p>' +
        G.map(function (g) {
          var ids = g.clients.map(function (c) { return c.id; }).join('|');
          return '<div style="border:1px solid #e2e8f0;border-radius:10px;padding:8px;margin:8px 0"><div class="exb-muted" style="font-size:12px">' + esc(g.raisons.join(', ')) + '</div>' + g.clients.map(function (c) {
            return '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;padding:6px 0;border-top:1px solid #f1f5f9"><div><b>' + esc(cname(c)) + '</b><br><small>' + esc(c.phone || '') + (c.email ? ' · ' + esc(c.email) : '') + ' · ' + usage(c.id) + ' fiche(s) liée(s)</small></div><button data-keep="' + esc(c.id) + '" data-grp="' + esc(ids) + '" class="smallbtn">✔ Garder celui-ci</button></div>';
          }).join('') + '</div>';
        }).join('');
      if (host.getAttribute('data-sig') !== html) { host.innerHTML = html; host.setAttribute('data-sig', html); }
      if (!host.__lien4) {
        host.__lien4 = 1;
        host.addEventListener('click', function (e) {
          var b = e.target && e.target.closest && e.target.closest('[data-keep]'); if (!b) return;
          var keepId = b.getAttribute('data-keep'), ids = (b.getAttribute('data-grp') || '').split('|').filter(function (x) { return x && x !== keepId; });
          var ci = cIndex(), nm = cname(ci.byId[keepId]);
          if (typeof w.confirm === 'function' && !w.confirm('Conserver « ' + nm + ' » et fusionner ' + ids.length + ' autre(s) fiche(s) dedans ? Cette action déplace tous les devis, chantiers et paiements rattachés.')) return;
          try { var r = mergeClients(keepId, ids); if (typeof w.notify === 'function') w.notify('Fusion terminée : ' + r.fiches_deplacees + ' fiche(s) rattachée(s) à « ' + nm + ' ».', 'success', 5000); } catch (err) { if (typeof w.notify === 'function') w.notify(String(err.message || err), 'warn', 6000); else if (typeof w.alert === 'function') w.alert(String(err.message || err)); }
          renderDup();
        });
      }
    }

    function mount() {
      try {
        var pr = d.getElementById('projets'); if (pr && !d.getElementById('exbLienPrj')) { var a = d.createElement('div'); a.className = 'card'; a.id = 'exbLienPrj'; pr.appendChild(a); }
        var cs = d.getElementById('clients'); if (cs && !d.getElementById('exbLienDup')) { var b = d.createElement('div'); b.className = 'card'; b.id = 'exbLienDup'; cs.appendChild(b); }
        renderDossier(); renderDup();
      } catch (e) {}
    }
    function link() { try { linkAll(); } catch (e) {} }
    X.extend({ link: link, anomalies: anomaliesProjets, html: function () { return ''; } });
    X.dup = { groups: dupGroups, merge: mergeClients, usage: usage };
    X.v4 = { linkAll: linkAll, anomalies: anomaliesProjets, dossier: dossier, dossierHtml: dossierHtml };
    try { w.addEventListener && w.addEventListener('exb-liaison-change', mount); } catch (e) {}
    link(); mount(); try { X.refresh(); } catch (e) {}
    setInterval(mount, 5000);
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 3000); }); else setTimeout(boot, 3000);
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : { readyState: 'complete', getElementById: function () { return null; }, addEventListener: function () {} });
