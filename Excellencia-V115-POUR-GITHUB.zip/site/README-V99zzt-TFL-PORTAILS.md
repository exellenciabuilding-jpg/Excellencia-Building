# V99zzt — TFL : portails étudiant et encadreur avec connexion

Suite de V99zzq (local) et V99zzr (en ligne). Chaque étudiant accepté et chaque encadreur affecté a maintenant **son espace en ligne protégé par identifiant + mot de passe**. Vos dossiers restent sur l'appareil de l'administration : le serveur ne garde qu'une copie de ce que la personne a le droit de voir, et la boîte de ses messages.

## Ce que voit et fait chacun
| | Étudiant | Encadreur |
|---|---|---|
| Lien | `/tfl-portail.html?role=etudiant` (court : `/tfl-etudiant`) | `/tfl-portail.html?role=encadreur` (court : `/tfl-encadreur`) |
| Identifiant | son **matricule** (000-000-000, avec ou sans tirets) | son code **ENC-1234** (attribué à la première publication) |
| Voit | statut, motif de décision, avancement (barre + 9 étapes), sujet, encadreur, historique, messages de l'administration | ses étudiants affectés et acceptés (contact, WhatsApp, sujet, problématique, objectifs, méthodologie, étape, progression) |
| Peut faire | écrire à l'administration | envoyer un commentaire / une correction, écrire à l'administration, **proposer** une progression (0-100 %) |
| Ne peut jamais | changer statut, étape, progression, affectation, décision, voir un autre dossier | idem ; écrire sur un dossier qui n'est pas dans son instantané |

## Parcours de l'administration (onglet 🎓 TFL › 🔐 Portails)
1. **📡 Publier / mettre à jour les portails** : crée l'accès de chaque étudiant accepté **avec matricule** et de chaque encadreur affecté. Un mot de passe de départ à 6 chiffres est généré pour chaque nouvel accès (gardé sur cet appareil, **hors sauvegarde**). Les dossiers sans matricule sont signalés.
2. Envoyez à chacun **deux messages séparés** : « 💬 Lien + identifiant » puis « 💬 Mot de passe de départ » (WhatsApp, numéro pré-rempli).
3. À sa première connexion la personne **doit choisir son mot de passe** (8 caractères minimum). Vous ne pouvez plus le lire ensuite : seulement « 🔑 Nouveau mot de passe » (génère un nouveau code de départ ; l'ancien mot de passe cesse de fonctionner).
4. **📥 Récupérer les messages reçus** : les messages arrivent dans la fiche du dossier (section « 💬 Messages des portails ») ; le compteur de non lus s'affiche sur l'onglet. Les messages dont l'identifiant ne correspond plus aux données de cet appareil sont ignorés.
5. Une **progression proposée** par l'encadreur n'est appliquée qu'avec le bouton **Appliquer** de l'administration (elle est alors écrite dans l'historique).
6. Répondre : dans la fiche, « Ajouter le message » (à l'étudiant, à l'encadreur ou aux deux) ; il apparaît dans le portail à la **prochaine publication**.
7. **Republier après chaque changement important** (décision, affectation, progression, étape, message) : le portail est un instantané. Republier ne change jamais les mots de passe choisis.
8. **⛔ Désactiver** coupe un accès ; **🔄 Vérifier l'état des accès** montre qui a changé son mot de passe et le nombre de connexions. Si vous modifiez le matricule d'un étudiant, l'ancien accès est désactivé et le nouveau créé à la publication suivante.

## À faire UNE FOIS
1. Supabase › SQL Editor : exécuter **`supabase/migration-v99zzt-tfl-portails.sql`** (livré aussi à part ; réexécutable ; indépendant de `migration-v99zzq-tfl.sql`, qui reste NON nécessaire). Utilise les mêmes e-mails administrateur que `migration-v99zzr-tfl-en-ligne.sql` : adaptez la liste dans la fonction `tfl_admin_ok()` si besoin.
2. Contrôle : `select proname from pg_proc where proname like 'tfl_portail_%';` → **8 lignes** ; `select tablename, rowsecurity from pg_tables where tablename in ('tfl_acces','tfl_messages');` → `true` pour les deux.
3. Déployer ce ZIP (Netlify), recharger une fois (cache `exb-v99zzt-tfl-portails`). Le lien n'apparaît dans l'application que si elle est ouverte depuis son adresse web (https://…).
4. Essai de recette recommandé : un dossier d'essai accepté → publier → connexion étudiant → message → récupérer.
Tant que le SQL n'est pas exécuté, l'application affiche « Les portails TFL ne sont pas encore activés » et les portails répondent « Service indisponible » ; rien n'est perdu.

## Sécurité
- Tables `tfl_acces` et `tfl_messages` : RLS **sans politique** et tous droits retirés ; tout passe par des fonctions `security definer` à `search_path` fixé.
- Mot de passe haché (SHA-256 salé par rôle + identifiant) ; identifiant inconnu et mot de passe faux donnent **le même message** ; **5 essais faux = blocage 15 minutes** (même avec le bon mot de passe pendant le blocage).
- Publication, révocation, liste, retours : réservés aux e-mails administrateur (fermés à l'anonyme).
- Écriture : étudiant → son dossier seulement ; encadreur → les dossiers de son instantané ; 30 envois par heure et par accès ; textes limités à 1 500 caractères.
- La page garde le mot de passe **en mémoire seulement** (jamais dans le navigateur), se ferme après 20 minutes d'inactivité, n'est pas indexée par les moteurs de recherche, et échappe tout contenu reçu du serveur.
- Instantané étudiant : sans notes internes, sans « observation de l'encadreur », sans analyse du sujet, sans e-mail ni téléphone.

## Limites
- **Le script SQL n'a PAS été exécuté sur un vrai PostgreSQL/Supabase** (indisponible ici). Les fonctions ont été relues et leurs règles reproduites dans un serveur simulé ; faites l'essai de recette ci-dessus avant d'ouvrir les accès aux étudiants.
- La page et l'écran d'administration ont été testés dans un navigateur **simulé** (pas Chromium) : vérifiez l'affichage sur téléphone.
- Portail = instantané : il n'est à jour qu'après « Publier ». Il faut une connexion Internet pour s'y connecter (pas de mode hors ligne).
- Pas encore de dépôt de fichiers (chapitres, plans), de corrections par chapitre, de rendez-vous ni de défense dans les portails : seuls messages, commentaires et progression proposée.
- Pas d'envoi automatique WhatsApp / SMS / e-mail : les boutons ouvrent WhatsApp avec le message prêt.
- « Mot de passe oublié » : l'administration génère un nouveau code de départ (🔑).
- Le mot de passe de départ est conservé sur l'appareil de l'administration jusqu'à sa réinitialisation : sur un autre appareil, utilisez « Nouveau mot de passe ».

## Fichiers
Nouveaux : `tfl-portail.html`, `supabase/migration-v99zzt-tfl-portails.sql`, `tools/test-tfl/test-portail.js`. Modifiés : `exb-tfl.js` (accès, messages, écran 🔐 Portails, messages dans la fiche), `sw.js` (cache `exb-v99zzt-tfl-portails`), `_redirects` (2 liens courts), `tools/check.js` (+12 contrôles), `tools/test-tfl/test.js` (+31).
Clés locales ajoutées : `exb_tfl_acces`, `exb_tfl_messages` (dans la sauvegarde TFL) ; `exb_tfl_codes` (mots de passe de départ, **hors** sauvegarde).

## Contrôles
`node tools/test-tfl/test.js` (logique, dont les portails) · `node tools/test-tfl/test-portail.js` (page de connexion + circuit complet administration ↔ serveur simulé ↔ portails) · `node tools/check.js` (369).

Retour en arrière : restaurer `exb-tfl.js`, `sw.js`, `_redirects`, `tools/check.js`, `tools/test-tfl/test.js` de V99zzs et retirer `tfl-portail.html` ; côté serveur `drop table public.tfl_messages, public.tfl_acces cascade;` supprime les accès (aucune autre donnée n'est concernée).
