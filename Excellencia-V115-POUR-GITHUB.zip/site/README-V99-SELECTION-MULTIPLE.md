# V99 — Éditeur de plan : sélection multiple, menu clic droit, sélection 3D / façades

Fichiers modifiés : `plan-editeur/index.html`, `vue3d.js`, `coupes.js`, `sw.js` (cache).

## 1. Sélection multiple façon ArchiCAD
- Maj ou Ctrl + clic : ajoute / retire un élément. Alt + clic : retire.
- Bouton « ▭ Cadre » (ou Ctrl/Maj + glisser) : fenêtre de sélection. Gauche→droite (trait plein bleu) = éléments entièrement dans le cadre ; droite→gauche (pointillé vert) = éléments touchés.
- Bouton « Remplacer / Ajouter-retirer / Retirer » : mode du simple toucher (tactile sans clavier). « ☑ Tout » ou Ctrl+A.
- Glisser un élément d'un groupe sélectionné déplace tout le groupe.

## 2. Menu clic droit façon AutoCAD (2D, 3D, façades/coupes ; appui long au tactile)
Copier, Couper, Coller, Coller ici (2D), Dupliquer, Déplacer… (ΔX, ΔY), Déplacer / Copier par deux points (2D), Copier avec translation… (réseau de n copies), Rotation…, Tout sélectionner, Inverser, Désélectionner, Supprimer. Raccourcis : Ctrl+C / X / V / D / A, Suppr.
Une porte ou fenêtre se copie avec son mur. Le collage va sur le niveau courant (copie possible d'un étage à l'autre).

## 3. Sélection en 3D, façades et coupes
- 3D : le vitrage (sélectionne la fenêtre) et les sols (pièces) se sélectionnent ; cadre Ctrl+glisser en 3D.
- Façades et coupes : murs, portes/fenêtres, meubles coupés, toitures ; clic, Maj+clic, cadre, clic droit.

## V4.8 — limites levées
- Cadre en 3D : ne retient que les éléments VISIBLES (tir de rayons) ; les sols sont pris dès qu'ils sont visibles dans le cadre (croisé) ou entièrement encadrés (fenêtre).
- Glisser direct en 3D : appuyer sur un élément DÉJÀ sélectionné et glisser le déplace sur le plan horizontal (pas de 5 cm). Sur un élément non sélectionné, le glisser tourne toujours la caméra.
- Glisser direct en façade / coupe : appuyer sur un élément sélectionné et glisser le déplace le long de la vue (une fenêtre ou une porte coulisse le long de son mur). Annulation : Ctrl+Z.

## Limites connues
- Translation en plan (X, Y) uniquement ; pas de Z. Rotation : toitures rectangulaires exclues. Pas de miroir.
- Testé dans Chromium (clic, cadre, 3D, façades, glisser, appui long simulé) ; à confirmer sur vos appareils.
