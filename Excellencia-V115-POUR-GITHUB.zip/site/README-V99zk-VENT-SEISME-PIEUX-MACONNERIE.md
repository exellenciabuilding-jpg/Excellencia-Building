# V99zk — Ingénierie P3 : vent, séisme, pieux, maçonnerie

Fichiers modifiés : `calcul-structure/index.html`, `exb-calcul-structure.js`, `exb-v99r-shell.js`, `sw.js` (cache `exb-v99zk-vent-seisme-pieux-1`).

Quatre nouveaux modules, en tuiles dans « Ingénierie & Structure » et dans la barre des modules :

- **Vent (EN 1991-1-4)** : pression de pointe qp(z), pressions face au vent / sous le vent, force par niveau, effort tranchant et moment de renversement (ELS et ELU). Murs verticaux, vent perpendiculaire à une face.
- **Séisme (EN 1998-1)** : spectre de calcul (types 1 et 2, sols A à E), période T1, effort tranchant à la base et forces par niveau (méthode des forces latérales), moment de renversement. Refuse la méthode si T1 > min(4·TC ; 2 s).
- **Pieu foré** : frottement latéral sur 2 couches, résistance de pointe, charge admissible (coefficient de sécurité global), contrainte du béton, armatures minimales (EN 1536) et choix d'armatures avec espacement ≥ 10 cm.
- **Maçonnerie porteuse (EN 1996-1-1)** : fk, fd, élancement, excentricités, coefficient Φ, résistance NRd d'un mur par mètre et taux de travail.

Limites (affichées aussi dans chaque module) :
- Aucun zonage sismique ni carte de vent n'est intégré : agR et vb,0 sont des données à saisir depuis les sources officielles.
- Vent : toiture, pressions locales, pression intérieure et effets dynamiques non traités.
- Séisme : bâtiments réguliers seulement ; déplacements, torsion et détails de ductilité non vérifiés.
- Pieux : tassement, frottement négatif, effort horizontal et effet de groupe non calculés ; capacité fondée sur les valeurs saisies (rapport géotechnique ou essai de charge).
- Maçonnerie : compression centrée sans ouverture ; charges concentrées, flexion hors plan et cisaillement non traités.
- Calculs vérifiés à la main sur les valeurs par défaut (qp, T1, Sd, Fb, fk, NRd) et testés dans Chromium ; non revus par un ingénieur.

Reste à faire dans « Ingénierie P3 » : structures acier et bois, validation par un ingénieur avec cachet, éléments finis.

Retour en arrière : restaurer les 4 fichiers de V99zj.
