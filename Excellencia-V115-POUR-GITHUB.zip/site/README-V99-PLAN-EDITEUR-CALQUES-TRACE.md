# V99 — Éditeur de plan : Calques et Trace (lot 2)

Fichiers modifiés : `plan-editeur/index.html`, `sw.js` (version du cache). Le moteur de métré, la 3D et les exports ne sont pas touchés.

- **Où** : menu Fenêtres → « Calques et Trace ».
- **Calques** (7 familles : Murs et ouvertures, Pièces, Mobilier et structure, Électricité, Cotations, Textes et hachures, Fond de plan) :
  - 👁 affiche / masque la famille dans le dessin 2D (aussi à l'impression) ;
  - 🔒 la rend non sélectionnable (elle reste visible et comptée dans le métré).
  Réglages enregistrés avec le plan, annulables (Ctrl+Z).
- **Trace** : niveau de référence affiché en filigrane (murs, pièces, mobilier). « Niveau du dessous » (comportement d'avant, par défaut), « Aucune », ou n'importe quel autre niveau (en bleu clair).
- Un calque masqué n'est masqué que dans la vue 2D : métré, 3D et exports gardent tout.

Testé dans Chromium sans écran : ouverture du menu, affichage / verrouillage, aucune erreur de console. Trace avec plusieurs niveaux non testée à l'écran ; non testé sur appareil réel.
