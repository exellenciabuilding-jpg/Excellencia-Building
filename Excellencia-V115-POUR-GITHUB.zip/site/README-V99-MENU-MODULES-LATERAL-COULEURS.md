# Menu des modules : côté gauche, « vous êtes ici », couleurs personnalisables

Fichiers modifiés : `exb-module-dock.js` (menu des modules), `sw.js` (version du cache), `plan-editeur/index.html` (Maj sur les murs).

## Menu des modules
- Sur grand écran (largeur ≥ 900 px) le menu s'affiche à gauche, sous l'en-tête fixe s'il y en a un. Sur téléphone il reste en bas, comme avant.
- Le module où l'on se trouve apparaît en onglet blanc arrondi avec une barre d'accent à gauche (« Vous êtes ici »).
- Bouton ⚙ du menu : disposition (Automatique / À gauche / En bas), 5 jeux de couleurs prêts (Bleu Excellencia = couleurs d'origine, Violet, Vert forêt, Anthracite, Brique), couleur du menu et couleur d'accent au choix, bouton Réinitialiser. Les choix sont mémorisés sur l'appareil.
- À gauche, le menu ne se cache pas pendant la saisie au clavier. Le bouton ▾ le réduit toujours en pastille.
- Retour en arrière : choisir « En bas » dans ⚙, ou remettre l'ancien `exb-module-dock.js`.

À vérifier sur vos appareils : testé sur une page qui reproduit la structure lue par le menu (le vrai logiciel demande une connexion). La mise en page à gauche (décalage du contenu, bandeau du haut) est à confirmer dans le logiciel connecté.

## Éditeur de plan : Maj sur les murs
En déplaçant l'extrémité d'un mur (outil Flèche), maintenir Maj : l'extrémité se cale sur l'intersection la plus proche avec un autre mur (elle recule si elle dépasse, ou se prolonge). Un cercle bleu montre le point de calage. L'outil « ✂ Ajuster » reste disponible.
