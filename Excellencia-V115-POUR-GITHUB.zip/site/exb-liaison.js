/* Excellencia Building V99 — LIAISON : interconnexion client ↔ projet/chantier ↔ devis ↔ études ↔ factures ↔ paiements.
 * Principe : on N'AJOUTE que des identifiants (client_id, project_id) aux fiches existantes ; on ne supprime ni ne renomme rien.
 * Le registre financier est une VUE calculée à partir des enregistrements réels (factures, caisse, paiements V93 confirmés) :
 * aucun versement n'est jamais créé à partir d'un devis, et un même paiement vu par deux modules n'est compté qu'une fois. */
(function(w,d){'use strict';
var VERSION='V99-LIAISON';
var K={clients:'exb_clients',projects:'exb_projects',quotes:'exb_quotes',studies:'exb_studies',invoices:'exb_invoices',cash:'exb_cash',v93:'exb_v93_payments',journal:'exb_liaison_journal'};
function store(){try{if(typeof exbStorage!=='undefined')return exbStorage}catch(e){}return w.exbStorage||w.localStorage}
/* Les écrans gardent leurs listes en mémoire (exbClients, exbProjects…) et les réécrivent telles quelles : on travaille donc sur ces listes vivantes, sinon le prochain enregistrement effacerait nos liens. */
function live(k){try{switch(k){case 'exb_clients':return typeof exbClients!=='undefined'?exbClients:null;case 'exb_projects':return typeof exbProjects!=='undefined'?exbProjects:null;case 'exb_quotes':return typeof exbQuotes!=='undefined'?exbQuotes:null;case 'exb_studies':return typeof exbStudies!=='undefined'?exbStudies:null;case 'exb_cash':return typeof exbCash!=='undefined'?exbCash:null;case 'exb_participants':return typeof participants!=='undefined'?participants:null;case 'exb_payments':return typeof payments!=='undefined'?payments:null;case 'exb_receipts':return typeof receipts!=='undefined'?receipts:null;case 'exb_certificates':return typeof certs!=='undefined'?certs:null;case 'exb_formations':return typeof formations!=='undefined'?formations:null;case 'exb_trainers':return typeof trainers!=='undefined'?trainers:null;case 'exb_hr':return typeof exbHr!=='undefined'?exbHr:null}}catch(e){}return null}
function rd(k){var l=live(k);if(Array.isArray(l))return l;try{var v=JSON.parse(store().getItem(k)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}}
function wr(k,v){try{if(typeof w.save==='function'&&k!==K.journal)w.save(k,v);else store().setItem(k,JSON.stringify(v));return true}catch(e){return false}}
function norm(s){s=String(s==null?'':s);try{s=s.normalize('NFD').replace(/[\u0300-\u036f]/g,'')}catch(e){}return s.toLowerCase().replace(/\s+/g,' ').trim()}
function digits(s){return String(s==null?'':s).replace(/\D/g,'')}
function num(x){x=+x;return isFinite(x)?x:0}
function r2(x){return Math.round(x*100)/100}
function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function audit(a,t){try{if(w.EXB_CORE&&w.EXB_CORE.audit)w.EXB_CORE.audit(a,t,'liaison')}catch(e){}try{if(typeof w.audit==='function')w.audit(a,t)}catch(e){}}
function journal(op,detail){var j=rd(K.journal);j.push({at:new Date().toISOString(),op:op,detail:detail});wr(K.journal,j.slice(-500))}
function canPay(){try{return !w.EXB_CORE||!w.EXB_CORE.can||w.EXB_CORE.can('paiements','ecrire')}catch(e){return true}}

/* ---------- clients ---------- */
function clientKeys(c){return [c.full_name,c.company,c.contact].map(norm).filter(Boolean)}
function clientIndex(){var cl=rd(K.clients),byName={},byId={};cl.forEach(function(c){byId[c.id]=c;clientKeys(c).forEach(function(k){(byName[k]=byName[k]||[]);if(byName[k].indexOf(c.id)<0)byName[k].push(c.id)})});return{list:cl,byName:byName,byId:byId}}
function resolveClient(ref,idx){idx=idx||clientIndex();if(ref&&typeof ref==='object')ref=ref.client_id||ref.client;if(!ref)return null;if(idx.byId[ref])return idx.byId[ref];var h=idx.byName[norm(ref)];return h&&h.length===1?idx.byId[h[0]]:null}
function ambiguousName(ref,idx){var h=idx.byName[norm(ref)];return !!(h&&h.length>1)}
function projectIndex(){var p=rd(K.projects),byName={},byId={};p.forEach(function(x){byId[x.id]=x;var k=norm(x.name);if(k){(byName[k]=byName[k]||[]).push(x.id)}});return{list:p,byName:byName,byId:byId}}
function resolveProject(name,clientId,pidx){if(!name)return null;if(pidx.byId[name])return pidx.byId[name];var h=(pidx.byName[norm(name)]||[]).map(function(i){return pidx.byId[i]});if(clientId){var m=h.filter(function(x){return x.client_id===clientId});if(m.length===1)return m[0]}return h.length===1?h[0]:null}
var ISSUED_ST=/(envoy|emis|émis|approuv|accept|sign|valid|factur)/i;
function isIssued(q){return !!(q&&(q.emis||q.issued_at||q.locked||q.approved||q.approved_at||ISSUED_ST.test(String(q.status||''))))}

/* ---------- rattachement (idempotent, additif) ---------- */
function linkAll(opts){opts=opts||{};var idx=clientIndex(),pidx=projectIndex(),res={projects:0,quotes:0,studies:0,invoices:0,cash:0,v93:0,ambigus:[],sansClient:[]};
 function setIf(o,k,v){if(v&&!o[k]){o[k]=v;return true}return false}
 var P=pidx.list,chP=false;P.forEach(function(p){var c=p.client_id?idx.byId[p.client_id]:resolveClient(p.client,idx);if(!c){if(p.client&&ambiguousName(p.client,idx))res.ambigus.push('Projet « '+p.name+' » : plusieurs clients portent le nom « '+p.client+' »');else if(p.client&&!p.client_id)res.sansClient.push('Projet « '+p.name+' » : client « '+p.client+' » introuvable');return}if(setIf(p,'client_id',c.id)){res.projects++;chP=true}});
 if(chP)wr(K.projects,P);pidx=projectIndex();
 var Q=rd(K.quotes),chQ=false;Q.forEach(function(q){var c=q.client_id?idx.byId[q.client_id]:resolveClient(q.client,idx),mod=false;if(c&&setIf(q,'client_id',c.id))mod=true;else if(!c&&q.client&&ambiguousName(q.client,idx))res.ambigus.push('Devis '+(q.no||q.id)+' : plusieurs clients portent le nom « '+q.client+' »');
  var p=resolveProject(q.project_id||q.project,q.client_id||(c&&c.id),pidx);if(p&&setIf(q,'project_id',p.id))mod=true;if(p&&!q.client_id&&p.client_id&&setIf(q,'client_id',p.client_id))mod=true;
  if(!q.client_snapshot&&q.client){q.client_snapshot=q.client;mod=true}if(mod){res.quotes++;chQ=true}});
 if(chQ)wr(K.quotes,Q);
 var S=rd(K.studies),chS=false;S.forEach(function(s){var c=s.client_id?idx.byId[s.client_id]:resolveClient(s.client,idx),mod=false;if(c&&setIf(s,'client_id',c.id))mod=true;var p=resolveProject(s.project_id||s.project,s.client_id||(c&&c.id),pidx);if(p&&setIf(s,'project_id',p.id))mod=true;if(p&&!s.client_id&&p.client_id&&setIf(s,'client_id',p.client_id))mod=true;if(mod){res.studies++;chS=true}});
 if(chS)wr(K.studies,S);
 var I=rd(K.invoices),chI=false;I.forEach(function(i){var p=i.project_id?pidx.byId[i.project_id]:null,c=i.client_id?idx.byId[i.client_id]:(resolveClient(i.client,idx)||(p&&p.client_id?idx.byId[p.client_id]:null)),mod=false;if(c&&setIf(i,'client_id',c.id))mod=true;if(!i.client_snapshot&&i.client){i.client_snapshot=i.client;mod=true}if(mod){res.invoices++;chI=true}});
 if(chI)wr(K.invoices,I);
 var invById={};I.forEach(function(i){invById[i.id]=i});
 function viaRef(o){var i=o.invoice_id?invById[o.invoice_id]:null,p=o.project_id?pidx.byId[o.project_id]:(i&&i.project_id?pidx.byId[i.project_id]:null),mod=false;if(i&&setIf(o,'project_id',i.project_id))mod=true;var cid=(i&&i.client_id)||(p&&p.client_id);if(cid&&setIf(o,'client_id',cid))mod=true;return mod}
 var C=rd(K.cash),chC=false;C.forEach(function(x){if(x.type==='in'&&viaRef(x)){res.cash++;chC=true}});if(chC)wr(K.cash,C);
 var V=rd(K.v93),chV=false;V.forEach(function(x){if(x.direction==='in'&&viaRef(x)){res.v93++;chV=true}});if(chV)wr(K.v93,V);
 var n=res.projects+res.quotes+res.studies+res.invoices+res.cash+res.v93;if(n&&!opts.silent){journal('liaison',{projects:res.projects,quotes:res.quotes,studies:res.studies,invoices:res.invoices,cash:res.cash,v93:res.v93});audit('LIAISON_AUTO',n+' fiche(s) rattachée(s) à leur client / chantier')}
 res.total=n;return res}

/* ---------- répercussion d'une modification autorisée de la fiche client ---------- */
function propagateClient(clientId){var c=clientIndex().byId[clientId];if(!c)return{n:0};var nm=c.full_name||c.company||'',n=0,out={projects:0,studies:0,quotes:0,gardes:0};if(!nm)return{n:0};
 [['projects',K.projects],['studies',K.studies],['quotes',K.quotes]].forEach(function(p){var a=rd(p[1]),ch=false;a.forEach(function(o){if(o.client_id!==clientId||o.client===nm)return;if(p[0]==='quotes'&&isIssued(o)){out.gardes++;return}o.client=nm;out[p[0]]++;ch=true;n++});if(ch)wr(p[1],a)});
 /* factures et documents émis : conservent le nom d'origine (client_snapshot) ; l'identifiant les relie à la fiche à jour */
 if(n){journal('client_modifie',{client:clientId,maj:out});audit('LIAISON_CLIENT','Fiche client mise à jour dans '+n+' enregistrement(s)')}
 out.n=n;return out}

/* ---------- registre financier central (vue calculée, sans doublon) ---------- */
function invTot(i){var ht=(i.lines||[]).reduce(function(a,l){return a+num(l.q)*num(l.pu)},0);return r2(ht*(1+num(i.tva)/100))}
function ledger(){var I=rd(K.invoices),C=rd(K.cash),V=rd(K.v93),seen={},rows=[],susp=[],orph=[];
 function push(r){if(seen[r.key])return;seen[r.key]=1;rows.push(r)}
 I.forEach(function(i){(i.payments||[]).forEach(function(p){push({key:'PAY:'+p.id,id:p.id,date:p.date||'',amount:num(p.amount),currency:i.currency||'USD',client_id:i.client_id||'',project_id:i.project_id||'',invoice_id:i.id,source:'facture',method:p.method||''})})});
 C.forEach(function(x){if(x.type!=='in')return;var key=x.pay_id?'PAY:'+x.pay_id:'CASH:'+x.id;if(seen[key])return;
  if(x.invoice_id&&!x.pay_id){var dup=rows.some(function(r){return r.invoice_id===x.invoice_id&&Math.abs(r.amount-num(x.amount))<0.005&&r.date===x.date});if(dup)susp.push('Caisse « '+(x.label||x.id)+' » ('+x.amount+') ressemble à un paiement déjà enregistré sur la facture')}
  push({key:key,id:x.id,date:x.date||'',amount:num(x.amount),currency:x.currency||'USD',client_id:x.client_id||'',project_id:x.project_id||'',invoice_id:x.invoice_id||'',source:'caisse',method:x.method||''})});
 V.forEach(function(x){if(x.direction!=='in')return;if(x.status!=='confirmed')return;var key=x.ledger_key||(x.pay_id?'PAY:'+x.pay_id:'V93:'+x.id);if(seen[key])return;
  push({key:key,id:x.id,date:(x.confirmed_at||x.created_at||'').slice(0,10),amount:num(x.amount),currency:x.currency||'USD',client_id:x.client_id||'',project_id:x.project_id||'',invoice_id:x.invoice_id||'',source:'paiements V93',method:x.method||''})});
 rows.forEach(function(r){if(!r.client_id&&!r.project_id)orph.push(r)});
 return{rows:rows,suspects:susp,nonRattaches:orph}}
function bucket(m,cur){return m[cur]||(m[cur]={devis:0,facture:0,verse:0,solde:0,aFacturer:0})}
function finish(m){Object.keys(m).forEach(function(c){var b=m[c];b.devis=r2(b.devis);b.facture=r2(b.facture);b.verse=r2(b.verse);b.solde=r2(b.facture-b.verse);b.aFacturer=r2(Math.max(0,b.devis-b.facture))});return m}
function situation(opt){opt=opt||{};var L=ledger(),P=rd(K.projects),Q=rd(K.quotes),I=rd(K.invoices),m={},byProj={};
 function inScope(o){if(opt.projectId)return o.project_id===opt.projectId;if(opt.clientId)return o.client_id===opt.clientId;return true}
 Q.filter(inScope).forEach(function(q){var b=bucket(m,q.currency||'USD');b.devis+=num(q.total);var pid=q.project_id||'—';var pb=byProj[pid]=byProj[pid]||{};bucket(pb,q.currency||'USD').devis+=num(q.total)});
 I.filter(inScope).forEach(function(i){var t=invTot(i),pid=i.project_id||'—';bucket(m,i.currency||'USD').facture+=t;bucket(byProj[pid]=byProj[pid]||{},i.currency||'USD').facture+=t});
 L.rows.filter(inScope).forEach(function(r){bucket(m,r.currency).verse+=r.amount;var pid=r.project_id||'—';bucket(byProj[pid]=byProj[pid]||{},r.currency).verse+=r.amount});
 var projets=Object.keys(byProj).map(function(pid){var p=P.filter(function(x){return x.id===pid})[0];return{project_id:pid==='—'?'':pid,nom:p?p.name:'(sans chantier)',montants:finish(byProj[pid])}});
 return{total:finish(m),projets:projets,nbPaiements:L.rows.filter(inScope).length}}

/* ---------- saisie unique d'un paiement : une seule porte d'entrée, sans doublon ---------- */
function recordPayment(o){o=o||{};if(!canPay())throw Error('Droits insuffisants pour enregistrer un paiement');var amt=num(o.amount);if(!(amt>0))throw Error('Montant de paiement invalide');
 var idx=clientIndex(),I=rd(K.invoices),inv=o.invoice_id?I.filter(function(i){return i.id===o.invoice_id})[0]:null;if(o.invoice_id&&!inv)throw Error('Facture introuvable');
 var pid=o.project_id||(inv&&inv.project_id)||'',cid=o.client_id||(inv&&inv.client_id)||'';if(!cid&&pid){var pr=projectIndex().byId[pid];cid=pr&&pr.client_id||''}
 if(!cid&&!pid)throw Error('Un paiement doit être rattaché à un client ou à un chantier');if(cid&&!idx.byId[cid])throw Error('Client introuvable');
 var C=rd(K.cash);if(o.idem){var ex=C.filter(function(x){return x.idem===o.idem})[0];if(ex)return{id:ex.pay_id||ex.id,duplicate:true}}
 var cur=o.currency||(inv&&inv.currency)||'USD',pay='PAY-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),date=o.date||new Date().toISOString().slice(0,10);
 if(inv){var tt=invTot(inv),dejà=(inv.payments||[]).reduce(function(a,p){return a+num(p.amount)},0);if(!o.allowOverpay&&dejà+amt>tt+0.005)throw Error('Ce versement dépasse le solde de la facture ('+r2(tt-dejà)+')');inv.payments=inv.payments||[];inv.payments.push({id:pay,date:date,amount:amt,method:o.method||''});wr(K.invoices,I)}
 C.push({id:'CASH-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7),date:date,type:'in',label:o.label||('Encaissement'+(inv?' facture '+(inv.no||inv.id):'')),amount:amt,currency:cur,method:o.method||'',ref:o.ref||(inv&&inv.no)||'',project_id:pid,client_id:cid,invoice_id:inv?inv.id:'',pay_id:pay,idem:o.idem||''});wr(K.cash,C);
 journal('paiement',{pay:pay,amount:amt,currency:cur,client:cid,project:pid,invoice:inv&&inv.id||''});audit('LIAISON_PAIEMENT','Paiement '+amt+' '+cur+' rattaché au client/chantier');refreshAll();return{id:pay,duplicate:false}}

/* ---------- contrôles de cohérence ---------- */
function anomalies(){var idx=clientIndex(),l=linkAll({silent:true,dry:1}),L=ledger(),a=[].concat(l.ambigus,l.sansClient,extCall('anomalies'));
 L.nonRattaches.forEach(function(r){a.push('Paiement non rattaché ('+r.amount+' '+r.currency+', '+r.source+(r.date?', '+r.date:'')+') : ni client ni chantier')});
 L.suspects.forEach(function(s){a.push(s)});
 rd(K.invoices).forEach(function(i){var t=invTot(i),p=(i.payments||[]).reduce(function(x,y){return x+num(y.amount)},0);if(p>t+0.005)a.push('Facture '+(i.no||i.id)+' : versé ('+p+') supérieur au montant facturé ('+t+')')});
 var seen={};idx.list.forEach(function(c){var k=digits(c.phone)||String(c.email||'').toLowerCase();if(!k)return;if(seen[k])a.push('Clients en double possible : « '+seen[k]+' » et « '+(c.full_name||c.id)+' » (même téléphone ou e-mail)');else seen[k]=c.full_name||c.id});
 return a}

/* ---------- extensions (formation, TFL…) ---------- */
var EXT=[];function extCall(f,a){var out=[];EXT.forEach(function(x){try{var v=x[f]&&x[f](a);if(v)out=out.concat(v)}catch(e){}});return out}

/* ---------- interface ---------- */
function fmt(n){return Number(n||0).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})}
function tableHtml(sit){var rows='';sit.projets.forEach(function(p){Object.keys(p.montants).forEach(function(c){var b=p.montants[c];rows+='<tr><td>'+esc(p.nom)+'</td><td>'+esc(c)+'</td><td style="text-align:right">'+fmt(b.devis)+'</td><td style="text-align:right">'+fmt(b.facture)+'</td><td style="text-align:right">'+fmt(b.verse)+'</td><td style="text-align:right"><b>'+fmt(b.solde)+'</b></td></tr>'})});
 if(!rows)return'<p class="exb-muted">Aucun devis, facture ni paiement rattaché pour le moment.</p>';return'<div style="overflow-x:auto"><table class="exb-table"><thead><tr><th>Chantier</th><th>Devise</th><th>Devis</th><th>Facturé</th><th>Versé</th><th>Solde à payer</th></tr></thead><tbody>'+rows+'</tbody></table></div><p class="exb-muted" style="font-size:12px">Un devis établi n’est pas un paiement : « Versé » ne compte que les encaissements réellement enregistrés.</p>'}
function renderClientPanel(){var host=d.getElementById('exbLienClient');if(!host)return;var cl=rd(K.clients),sel=d.getElementById('exbLienSel'),cur=sel?sel.value:'';
 host.innerHTML='<h3 style="margin:0 0 8px">🔗 Dossier client connecté</h3><select id="exbLienSel" style="max-width:100%"><option value="">— Choisir un client —</option>'+cl.map(function(c){return'<option value="'+esc(c.id)+'"'+(c.id===cur?' selected':'')+'>'+esc(c.full_name||c.company||c.id)+'</option>'}).join('')+'</select><div id="exbLienOut" style="margin-top:10px"></div>';
 var s=d.getElementById('exbLienSel');function show(){var o=d.getElementById('exbLienOut');if(!o)return;if(!s.value){o.innerHTML='';return}var sit=situation({clientId:s.value}),I=rd(K.invoices).filter(function(i){return i.client_id===s.value}).length,E=rd(K.studies).filter(function(x){return x.client_id===s.value}).length,Q=rd(K.quotes).filter(function(x){return x.client_id===s.value}).length;o.innerHTML='<p class="exb-muted">'+Q+' devis · '+I+' facture(s) · '+E+' étude(s) · '+sit.nbPaiements+' paiement(s)</p>'+tableHtml(sit)}
 s.onchange=show;show()}
function renderDirection(){var host=d.getElementById('exbLienDir');if(!host)return;var sit=situation({}),an=anomalies();host.innerHTML='<h3 style="margin:0 0 8px">🔗 Situation financière consolidée</h3>'+tableHtml(sit)+extCall('html').join('')+(an.length?'<details style="margin-top:8px"><summary>⚠ '+an.length+' point(s) à vérifier</summary><ul>'+an.slice(0,30).map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></details>':'<p class="exb-muted">✓ Aucune incohérence détectée.</p>')}
function mount(){var cs=d.getElementById('clients');if(cs&&!d.getElementById('exbLienClient')){var c=d.createElement('div');c.className='card';c.id='exbLienClient';cs.appendChild(c)}
 var dp=d.getElementById('exb_dir_projects');if(dp&&!d.getElementById('exbLienDir')){var card=dp.closest&&dp.closest('.card')||dp.parentNode,x=d.createElement('div');x.className='card';x.id='exbLienDir';card.parentNode.insertBefore(x,card.nextSibling)}}
function refreshAll(){try{linkAll()}catch(e){}extCall('link');try{mount();renderClientPanel();renderDirection()}catch(e){}try{if(typeof w.updateExbDirection==='function')w.updateExbDirection()}catch(e){}try{w.dispatchEvent(new Event('exb-liaison-change'))}catch(e){}}

/* ---------- branchements sur les écrans existants (sans les remplacer) ---------- */
function after(name,fn){var f=w[name];if(typeof f!=='function'||f.__lien)return;var g=function(){var r=f.apply(this,arguments);try{fn.apply(null,arguments)}catch(e){}return r};g.__lien=1;w[name]=g}
function hook(){
 after('saveExbProject',function(){refreshAll()});after('saveExbQuote',function(){refreshAll()});after('saveExbStudy',function(){refreshAll()});
 var f=w.saveExbClient;if(typeof f==='function'&&!f.__lien){var g=function(){var idEl=d.getElementById('exb_cli_id'),ph=d.getElementById('exb_cli_phone'),em=d.getElementById('exb_cli_email'),id=idEl&&idEl.value;
   if(!id){var p=digits(ph&&ph.value),e=String(em&&em.value||'').toLowerCase().trim(),dup=rd(K.clients).filter(function(c){return(p&&digits(c.phone)===p)||(e&&String(c.email||'').toLowerCase()===e)})[0];if(dup&&typeof w.confirm==='function'&&!w.confirm('Un client existe déjà avec ce téléphone ou cet e-mail : « '+(dup.full_name||dup.id)+' ». Créer quand même une deuxième fiche ?'))return}
   var r=f.apply(this,arguments);try{var cid=id||(rd(K.clients)[0]||{}).id;if(cid)propagateClient(cid);refreshAll()}catch(e){}return r};g.__lien=1;w.saveExbClient=g}
}
function start(){hook();refreshAll();setInterval(function(){try{var r=linkAll({silent:true});if(r.total)refreshAll()}catch(e){}},20000)}
w.EXBLIEN={version:VERSION,keys:K,norm:norm,resolveClient:function(ref){return resolveClient(ref)},linkAll:linkAll,propagateClient:propagateClient,ledger:ledger,situation:situation,recordPayment:recordPayment,anomalies:anomalies,refresh:refreshAll,extend:function(x){EXT.push(x)},log:function(op,detail,msg){journal(op,detail);if(msg)audit('LIAISON_'+op.toUpperCase(),msg)},rd:rd,wr:wr,norm:norm,digits:digits,esc:esc,num:num,r2:r2,fmt:fmt,journal:function(){return rd(K.journal)}};
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(start,1500)});else setTimeout(start,1500);
})(typeof window!=='undefined'?window:globalThis,typeof document!=='undefined'?document:{readyState:'complete',getElementById:function(){return null},addEventListener:function(){}});
