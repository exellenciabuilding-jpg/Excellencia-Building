# V99zz — Politiques RLS : droits par fonction sur les tables dédiées (audit interne : « Politiques RLS non éprouvées », gravité Haute)

Fichiers ajoutés : `supabase/migration-v99zz-droits-tables-dediees.sql`, `tools/rls-audit.py`.
Fichiers modifiés : `tools/test-rls/run.sh`, `tools/test-rls/test-rls.sql` (tests T34 à T40), `tools/check.js` (+12 contrôles).
Aucun changement dans l'application (JavaScript).

## Ce qui a été fait, et ce qui n'a PAS pu l'être
- **Aucun PostgreSQL ni Supabase n'était disponible** dans cet environnement : **la migration V99zz et les tests T34 à T40 n'ont pas été exécutés.** Ce qui a été vérifié ici : analyse statique des 32 fichiers SQL (`python3 tools/rls-audit.py`) et les contrôles `tools/check.js`.
- L'audit de V99zo (README-V99zo) a été fait sur un vrai PostgreSQL 16 ; je n'ai pas pu le refaire. Les migrations ajoutées depuis (V99zp, V99zv, V99zw, V99zy) sont chargées par le banc d'essai, mais je ne peux pas confirmer qu'elles passent sans erreur.

## Constat (analyse statique)
- Les 55 tables ont la RLS activée ; 117 politiques ; 8 tables fermées (accès par fonctions seulement, voulu).
- **Anomalie trouvée** : 8 tables dédiées (`erp_employes`, `erp_contrats_rh`, `erp_paies`, `erp_comptes_bancaires`, `erp_transactions_bancaires`, `moyens_paiement`, `paiements`, `operations_caisse`) n'étaient protégées que par le **rôle** du membre : tout membre de l'entreprise (magasinier, par exemple) pouvait les lire par l'API. Le stockage `enregistrements`, lui, applique les droits par **fonction** (`peut()`, V99zn). Les modules actuels n'écrivent pas dans ces tables (elles restent vides, d'après V99zn) : c'est donc une porte dérobée **latente**, pas une fuite de données constatée.
- `droits_fonction` reste lisible par tout utilisateur connecté : voulu (matrice des droits, aucune donnée d'entreprise).

## Correction proposée (à tester avant mise en service)
`migration-v99zz-droits-tables-dediees.sql` : lecture par `peut(org_id, collection, false)`, écriture par `peut(org_id, collection, true)` sur ces 8 tables, avec la correspondance v92_* / v93_* de V99zn. Les politiques restrictives de licence (V99zo) ne sont pas touchées. Réexécutable. Retour en arrière : ré-exécuter les boucles de V92 et V93.

## Mise en service
1. Sur un projet Supabase de **recette** : sauvegarde, puis migrations dans l'ordre de `tools/test-rls/run.sh`, V99zz en dernier.
2. Lancer `PGHOST=… tools/test-rls/run.sh` (PostgreSQL 14+) : tous les tests T1 à T40 doivent afficher OK. **Le banc d'essai affiche désormais les migrations qui échouent** (« ECHEC migration … ») au lieu de les ignorer : une ligne d'échec est à traiter avant de lire les résultats.
3. Essai à la main avec un compte magasinier puis comptable (requêtes de vérification en fin de migration).

## Reste à faire (non couvert)
- Exécuter tout cela sur le Supabase de recette avec de vrais comptes (l'imitation de l'authentification des tests n'est pas Supabase) — c'est l'action n° 1 de la feuille de route de l'audit.
- Points déjà signalés par V99zo : confirmation d'e-mail obligatoire (boutique vitrine), code d'invitation de 8 caractères sans limite d'essais côté base.
- Les autres tables dédiées (erp_contacts, btp_*, etc.) restent protégées par le rôle ; elles contiennent des données moins sensibles, à aligner plus tard si ces tables servent un jour.
