/* Excellencia Building V99zzzzzzzzzzzzzzzzzzzzz — Éditeur de plan de maison 2D (usage interne de l'équipe).
 * Dessin de murs, portes, fenêtres et pièces ; quantités (murs, maçonnerie, enduit/peinture, sols, plinthes, portes, fenêtres)
 * envoyées dans « Métré & devis › Matériaux ajoutés » par EXBMetre.addLignes (une même ligne est mise à jour, pas dupliquée).
 * Le dessin est un bloc indépendant (plan-editeur/index.html, affiché dans la page) : aucune fonction existante n'est modifiée.
 * Plans et fonds de plan enregistrés par exbStorage (une clé par plan : exbPlanEd.p.<id>, exbPlanEd.bg.<id>), donc synchronisés avec le compte par exb-sync.js ; Exporter / Importer (.json) pour les partager.
 * Pour retirer le module : supprimer la balise <script src="exb-plan-editeur.js"> de index.html. */
(function(w,d){'use strict';
var URL_ED='plan-editeur/index.html';
var $=function(i){return d.getElementById(i)};
function css(){if($('exbPlanEdCss'))return;var s=d.createElement('style');s.id='exbPlanEdCss';
 s.textContent='#planEditeur .pe-wrap{border:1px solid #d5dbe5;border-radius:14px;overflow:hidden;background:#f4f4f4;box-shadow:0 6px 24px #0f2e6618}'
 +'#planEditeur iframe{display:block;width:100%;height:calc(100vh - 150px);min-height:560px;border:0;background:#fff}'
 +'#planEditeur .pe-note{margin:10px auto 0;font-size:12px;color:#6b7a99;text-align:center}'
 +'@media(max-width:700px){#planEditeur iframe{height:calc(100vh - 130px);min-height:520px}#planEditeur .pe-wrap{border-radius:10px}}';
 d.head.appendChild(s)}
function build(){var sec=d.createElement('section');sec.id='planEditeur';sec.style.display='none';
 sec.innerHTML='<div class="card"><h2>✏️ Plan de maison</h2>'
 +'<div class="pe-wrap"><iframe id="exbPlanEdFrame" title="Éditeur de plan de maison" loading="lazy" allow="fullscreen"></iframe></div>'
 +'<p class="pe-note">Quantités indicatives d’après le dessin, à contrôler avant chiffrage. « Envoyer au métré » les ajoute dans Métré &amp; devis › Matériaux ajoutés.</p></div>';return sec}
function mount(){if($('planEditeur'))return;
 var ref=$('calcStructure')||$('metreDevis')||$('bureauEtudes')||$('projets'),host=d.querySelector('.wrap')||d.querySelector('main')||d.body,sec=build();css();
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(sec,ref.nextSibling);else host.appendChild(sec);
 var anchor=$('bbet')||$('bdev'),par=anchor&&anchor.parentNode;
 if(par&&!$('bplanedit')){var b=d.createElement('button');b.id='bplanedit';b.type='button';b.textContent='✏️ Plan de maison';b.setAttribute('onclick',"show('planEditeur')");par.insertBefore(b,anchor.nextSibling)}
 var os=w.show;
 if(typeof os==='function'&&!w.__exbPlanEdShow){w.__exbPlanEdShow=1;
  w.show=function(x){var r=os.apply(this,arguments),e=$('planEditeur');
   if(e){e.style.display=(x==='planEditeur')?'':'none';
    if(x==='planEditeur'){var f=$('exbPlanEdFrame');if(f&&!f.getAttribute('src'))f.setAttribute('src',URL_ED);else if(f){try{var E=f.contentWindow.EXBPLANEDIT;if(E&&E.refresh)E.refresh()}catch(e){}}}}
   var b2=$('bplanedit');if(b2)b2.classList.toggle('active',x==='planEditeur');return r}}}
/* agrandissement : si le plein écran du navigateur est refusé, l'éditeur occupe toute la fenêtre du logiciel */
w.addEventListener('message',function(e){var f=$('exbPlanEdFrame');if(!f||!e.data||typeof e.data.exbPlanBig==='undefined'||e.source!==f.contentWindow)return;
 var on=!!e.data.exbPlanBig;f.style.cssText=on?'position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:99999;min-height:0':'';});
var STORE_API={get:function(k){try{return exbStorage.getItem(k)}catch(e){return null}},set:function(k,v){exbStorage.setItem(k,v)},remove:function(k){try{exbStorage.removeItem(k)}catch(e){}},
 keys:function(p){var a=[];try{for(var i=0,n=exbStorage.length;i<n;i++){var k=exbStorage.key(i);if(k&&k.indexOf(p)===0)a.push(k)}}catch(e){}return a}};
w.EXBPLANED={store:STORE_API,open:function(){if(!$('planEditeur'))mount();if(typeof w.show==='function')w.show('planEditeur');try{w.scrollTo(0,0)}catch(e){}},version:'V99zzzzzzzzzzzzzzzzzzzzz'};
function start(){setTimeout(mount,800)}
if(d.readyState==='complete')start();else w.addEventListener('load',start);
})(window,document);
