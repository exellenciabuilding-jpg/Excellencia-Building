# V99zzzzzzzzzzzzzzz — Devis : cachet sur le nom, lots du devis rapide
Fichiers modifiés : `exb-docs.js`, `exb-metre.js`, `index.html`, `sw.js` (cache renouvelé). Recharger l'application après mise à jour.

- Page de garde alignée sur le modèle PDF : cadre doré fin, bleu exact du modèle.
- Cachet + signature du prestataire remontés : ils chevauchent le nom et la fonction du signataire (le texte reste lisible par-dessus).
- Devis rapide : nouvelle colonne « Lot » (Maçonnerie, Finitions, etc., liste de suggestions + saisie libre). Si au moins une ligne a un lot, le PDF affiche des sections numérotées avec sous-totaux par lot. Sans lot : classement Matériaux / Main d'œuvre / Autres comme avant.
- Devis rapide : le bouton Imprimer ouvre le même PDF que le devis principal (page de garde + QR sur chaque page).

## Complément : cachet + signature collés au nom du signataire sur TOUS les documents
- Factures, reçus et devis sans page de garde (`exb-docs.js`) : le cachet descend sur la ligne de signature et touche le nom/la fonction du signataire.
- PDF génériques (`exb-pdf.js`) : même réglage pour le bloc « Le Directeur Général ».
- Notes de calcul (`calcul-structure/exb-calcul-doc.js`) : signature et cachet chevauchent les noms « Établi par / Validé par / Vérifié par » (visas de conclusion et pied de page).
- Certificats et reçus à l'écran/impression (`index.html`) : le cachet chevauche le nom du directeur.
Le texte reste toujours lisible par-dessus l'image.
