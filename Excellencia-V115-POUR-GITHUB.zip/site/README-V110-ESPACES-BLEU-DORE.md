# V110 — Espaces apprenant et encadreur : charte bleu + doré

- **Espace apprenant** (`espace-apprenant.html`) : le noir (#101827) est remplacé par le bleu institutionnel #173565 (barre du haut, menu, onglets du bas, carte d'accueil, bandeaux, carte d'apprenant PNG). Doré #d8a43c pour les filets, le menu actif et les tuiles de services (alternance bleu / doré). Le mode sombre automatique du téléphone est désactivé : l'espace garde toujours sa charte.
- **Espace étudiant TFL** : tableau de bord en « Services disponibles » (tuiles bleu / doré) et bandeau « Votre réussite est notre priorité », comme l’espace apprenant.
- **Espace encadreur** (`tfl-portail.html?role=encadreur`, lien `/tfl-encadreur`) : même habillage (barre bleue avec logo et filet doré, carte d'accueil avec photo, onglets du bas sur téléphone, bandeau). Le tableau de bord ajoute « Services disponibles » propres à l'encadrement : Mes étudiants, Avis à donner, Messages, Documents, Mes sujets, Mon profil. L'espace étudiant TFL, qui partage la même page, prend la même charte.
- Fichiers modifiés : `espace-apprenant.html`, `tfl-portail.html`, `sw.js`. Aucune nouvelle fonction SQL.
- Retour en arrière : restaurer ces trois fichiers de V109.

## Images et icônes (espaces encadreur et étudiant TFL)
- Bandeau photo en tête de chaque page (étudiants, sujets, documents, échanges, frais, avancement, profil…), comme dans l'espace apprenant (photos `assets/accueil/banniere-1..4.jpg`, filet doré).
- Icônes dessinées en SVG (même rendu sur tous les téléphones) dans le menu, les onglets du bas et les tuiles de services, à la place des émojis.
- Fichier modifié : `tfl-portail.html`. Aucune nouvelle fonction SQL.

## Bordereau de paiement généré par l'étudiant (TFL › Frais TFL)
- Nouveau bouton **🧾 Générer mon bordereau** (étape 1) : page imprimable / PDF avec nom, matricule, dossier, frais total, déjà payé, reste, **montant à verser** (modifiable pour un paiement partiel), consignes de paiement de l'administration, référence `BP-TFL-<dossier>-AAAAMMJJ-HHMM`, cases cachet banque / signature.
- Étape 2 : l'étudiant paie, puis **déclare son paiement** (référence et montant déjà remplis) avec la preuve ; l'administration confirme et délivre le reçu (inchangé).
- Ce n'est pas un reçu. La référence n'est pas enregistrée sur le serveur (aucun SQL) : elle voyage avec la déclaration de paiement.
