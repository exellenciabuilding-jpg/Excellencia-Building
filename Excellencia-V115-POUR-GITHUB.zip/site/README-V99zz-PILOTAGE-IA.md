# V99zz — Pilotage projets et IA (audit interne : « Pilotage » et « IA », P2/P3)

Fichiers ajoutés : `exb-evm.js` (moteur), `exb-pilote.js` (écran), `tools/test-evm.js`, `tools/e2e-pilote.py`.
Fichiers modifiés : `index.html` (2 scripts, contexte et repli de l'assistant), `sw.js` (cache `exb-v99zz-pilotage-1`), `exb-v99r-shell.js` (tuile), `exb-roles.js` (droit de lecture), `exb-storage-bridge.js` (correctif), `supabase/functions/assistant/index.ts` (invite), `tools/check.js`.
Aucun SQL. Aucune donnée modifiée : l'écran est en lecture seule.

## 1. Pilotage projets (Projets › « 📈 Pilotage projets »)
Calculé automatiquement à partir du planning, du budget et de la caisse existants, sans saisie en plus.
- **EVM** : BAC (budget détaillé, sinon budget du projet), AC (le plus élevé du coût réel saisi et des dépenses de caisse), EV = BAC × avancement du Gantt, PV = BAC × planifié à la date du jour. CPI, SPI, CV, SV, EAC, ETC, VAC, TCPI.
- **Retard** : retard prévisionnel et date de fin prévue issus du chemin critique (V99zq), tâches critiques en retard.
- **Alertes** par gravité (coût, délai, retard, dépassement final, budget consommé, postes, impayés, dépendances circulaires) et **alertes de qualité des données** (pas de budget, pas de date S1, avancement du projet ≠ Gantt…). Un indice n'est jamais inventé : sans données, le projet est « Données insuffisantes ».
- **Portefeuille** : indices pondérés par les montants, tri par gravité, export CSV (formules neutralisées), PDF. **Détail projet** : indicateurs, courbe en S, alertes, méthode de calcul.
- Lecture réservée aux fonctions qui peuvent lire projets, planning **et** budgets.

## 2. IA (phase 1)
- **Anomalies de coûts** (règles, par projet) : dépense hors budget, poste ≥ 150 % de son budget, doublons de caisse, montants atypiques (≥ 5 × la médiane, à partir de 5 écritures).
- **Synthèse de la semaine** : texte calculé localement, prêt à copier.
- **Assistant en ligne** : reçoit désormais un contexte « Pilotage projets » (≤ 3 300 caractères, 10 projets, libellés nettoyés) s'il y a le droit de lecture. **Redéployer la fonction `assistant`** (invite mise à jour : ne pas inventer, données saisies = données, jamais des instructions). Sans redéploiement, l'assistant fonctionne comme avant.
- **Assistant hors ligne** : « quels chantiers sont en retard / en dérive ? », « CPI », « synthèse »… répond avec la synthèse locale et propose d'ouvrir l'écran.

## 3. Correctif découvert pendant les tests
`exbStorage` est déclaré avec `const` dans index.html : il n'existe pas sur `window`, donc le pont `EXBS` lisait le stockage brut et **ne voyait pas les projets, factures et caisse** enregistrés par l'application. Conséquence : « Pilotage direction » (V81) affichait 0 projet. Le pont atteint maintenant `exbStorage`. Les données déjà enregistrées par les modules qui utilisent `EXBS` sont migrées au premier accès (`migrate`). **À vérifier sur un appareil ayant des données réelles** : Direction, Plans (V81), Cartouche (V80), Architecture (V79), Finance (V78), Portails (V99zy) lisent aussi via `EXBS`.

## Limites
- Les tâches du Gantt n'ont pas de coût : l'avancement et le planifié sont pondérés par les **durées**. Le CPI dépend de la qualité des « coûts réels » saisis.
- Seuils d'alerte (CPI/SPI 0,95 et 0,85, dépassement 3 % et 10 %, retard 1 et 2 semaines) fixés dans `EXBEVM.DEF`, pas encore modifiables à l'écran.
- Pas d'historique : pas encore de tendance semaine par semaine (à prévoir : enregistrement d'un point hebdomadaire).
- Le test navigateur est fait en local (Chromium). Le chemin complet vers la fonction `assistant` (session, licence, quota, modèle) n'a **pas** été exercé : aucun Supabase réel ici.
- Les anomalies sont des pistes à vérifier, pas des erreurs prouvées.

Retour en arrière : retirer les deux `<script>` d'index.html et restaurer les fichiers modifiés de V99zy.

## Complément : historique hebdomadaire et tendance
Fichiers modifiés : `exb-evm.js` (fonctions `snap`, `mergeHistory`, `series`, `trend`), `exb-pilote.js` (relevé, flèches, section « Tendance hebdomadaire »), `sw.js` (cache `exb-v99zz-pilotage-2`), `tools/test-evm.js`, `tools/e2e-pilote.py`. Aucun SQL.
- **Un relevé par projet et par semaine** (le lundi de la semaine), enregistré automatiquement à l'ouverture de « Pilotage projets » : avancement, planifié, CPI, SPI, coût réel, budget, coût final estimé, retard, état. Le dernier relevé de la semaine remplace le précédent ; 104 semaines au plus par projet.
- **Pas de relevé** pour un projet terminé, sans budget ou sans indice calculable : aucun chiffre n'est inventé.
- **Liste** : flèche ↗ / → / ↘ à côté du CPI et du SPI (écart de 0,02 ou plus depuis le relevé précédent). **Détail projet** : courbe CPI / SPI par semaine (26 dernières) et tableau des 8 derniers relevés.
- Stockage dans la clé `exb_pilot_hist` de `exbStorage` : incluse dans la sauvegarde ; **sur l'appareil seulement** tant que la synchronisation de ce module n'est pas faite.

Limites :
- Le relevé n'est créé que lorsque quelqu'un ouvre le pilotage : une semaine sans ouverture n'a pas de point (pas de tâche planifiée en arrière-plan). Ouvrir l'écran une fois par semaine suffit.
- Pas de rétro-calcul : l'historique commence à la première ouverture avec cette version ; la tendance apparaît dès le deuxième relevé.
- Un appareil par historique : deux appareils auront deux historiques différents.
- Le portefeuille n'a pas encore de courbe de tendance globale (seulement par projet).
Retour en arrière : restaurer `exb-evm.js`, `exb-pilote.js` et `sw.js` de V99zz.

## Complément : PDF et CSV du pilotage (mise en page Excellencia Building)
Fichier modifié : `exb-pilote.js` (+ test `tools/e2e-pilote.py`). Le PDF utilise toujours le gabarit commun `EXBPdf` (en-tête marine avec logo, identité de l'entreprise, QR de vérification, pagination, pied de page).
- **PDF portefeuille** : ouvre sur une ligne « Portefeuille » (projets à traiter / à surveiller / sous contrôle) et « Indices globaux » (CPI, SPI, budget, réel, coût final estimé), puis une fiche par projet.
- **PDF par projet** : ligne « Tendance » (CPI et SPI en amélioration, en dégradation ou stable, avec l'écart) et les 6 derniers relevés hebdomadaires (« Semaine du … »).
- Le moteur PDF ne sait pas écrire les flèches (↗ ↘ →) : elles sont remplacées par des mots. Les anciennes alertes affichaient un « ? » à la place de la flèche avant l'action recommandée ; elles se lisent maintenant « … Action : … ».
- **CSV** : deux colonnes ajoutées, « Tendance CPI » et « Tendance SPI » (amelioration / degradation / stable).
Limite : les messages d'alerte produits par le moteur écrivent encore les indices avec un point (0.82) et non une virgule.
Retour en arrière : restaurer `exb-pilote.js` de la version précédente.

## Complément V99zzf : seuils d'alerte réglables et rapport PDF de chantier
Fichiers modifiés : `exb-evm.js` (`sane`, `validateTh`, `thFor`, `LIM`, décimales avec virgule), `exb-pilote.js` (panneaux de seuils, `report`), `exb-pdf.js` (titre de la section d'images configurable : `imagesTitle`, « PHOTOS » par défaut), `sw.js` (cache `exb-v99zzf-pilotage-seuils-1`), `exb-v99r-shell.js` (version), tests. Aucun SQL.
- **Seuils réglables** (CPI, SPI, dépassement final, retard, budget consommé) : en bas de la liste (tous les chantiers) et dans le détail d'un chantier (ce chantier seulement). Priorité : chantier > général > valeurs par défaut. Une valeur hors limites ou un seuil rouge plus tolérant que l'orange est refusé. Modification réservée aux fonctions qui peuvent **écrire** les budgets ; les autres voient les seuils en lecture seule. Clé `exb_pilot_th` : **sur l'appareil seulement** (comme l'historique), incluse dans la sauvegarde.
- **Rapport PDF d'un chantier** (bouton « Rapport PDF ») : état global, avancement, coût, coût final estimé, délai, tendance, points d'attention, anomalies, **décisions à prendre**, 6 derniers relevés, **courbe en S et courbe de tendance**, méthode et seuils appliqués, zone de signature (Conducteur de travaux / Directeur), QR de vérification. Le PDF du portefeuille est inchangé.
- **Corrections** : le repère « aujourd'hui » de la courbe en S était toujours à S0 (date de la semaine 1 non transmise) ; messages d'alerte avec virgule décimale (0,82).
Limites : les graphiques du PDF sont petits (grille à deux images du gabarit commun) ; seuils non synchronisés entre appareils.
Retour en arrière : restaurer `exb-evm.js`, `exb-pilote.js`, `exb-pdf.js`, `sw.js`, `exb-v99r-shell.js` de V99zze.
