/* Excellencia Building V110h — Administration : retours saisis par les formateurs dans leur espace
   (présences, suivi des apprenants, rapports de séance, messages) + réponses.
   Serveur : supabase/migration-v110h-espace-formateur-suivi.sql. Les retours sont conservés sur cet appareil (clé exb_formateur_retours). */
(function (w) {
  'use strict';
  var KEY = 'exb_formateur_retours';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lire() { try { return JSON.parse(w.localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } }
  function ecrire(a) { try { w.localStorage.setItem(KEY, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function dire(m, t) { try { if (typeof w.notify === 'function') w.notify(m, t || 'info', 6000); else w.alert(m); } catch (e) { /* silencieux */ } }
  function srv() {
    if (typeof api !== 'function' || typeof S === 'undefined' || !S) { dire('Connectez-vous d’abord au serveur : 📨 Inscriptions › Demandes reçues.', 'warn'); return false; }
    return true;
  }
  function erreur(e) {
    var m = String((e && e.message) || e || '');
    return 'Opération impossible : ' + m + (/rpc|function|404/i.test(m) ? '\nExécutez d’abord supabase/migration-v110h-espace-formateur-suivi.sql.' : '');
  }

  /* ---- Interconnexion : reprise dans Présences, Évaluations et Planning du logiciel (idempotent) ---- */
  function nd(m) { return String(m || '').replace(/\D/g, '') || String(m || '').trim(); }
  function nz(t) { return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function jourDe(x) { return String((x && x.maj_le) || '').slice(0, 10) || new Date().toISOString().slice(0, 10); }
  function appliquer(rows) {
    var R = { pres: 0, evals: 0, seances: 0, inconnus: 0 };
    if (typeof participants === 'undefined' || typeof attendance === 'undefined' || typeof evaluations === 'undefined') return R;
    var P = {}; participants.forEach(function (p) { if (p && p.matricule) P[nd(p.matricule)] = p; });
    var STAT = { P: 'PRESENT', A: 'ABSENT', R: 'RETARD', E: 'ABSENT' }, maintenant = new Date().toISOString(), inconnus = {};
    var chAtt = false, chEv = false, chSch = false;
    rows.forEach(function (x) {
      var d = x.data || {};
      if (x.type === 'presence') {
        var p = P[nd(x.apprenant)]; if (!p) { inconnus[nd(x.apprenant)] = 1; return; }
        for (var i = attendance.length - 1; i >= 0; i--) if (attendance[i].date === d.date && attendance[i].participant_id === p.participant_id) attendance.splice(i, 1);
        attendance.push({ date: d.date, participant_id: p.participant_id, status: STAT[d.statut] || 'PRESENT', updated_at: maintenant, source: 'formateur', formateur: x.nom || x.matricule, module: d.module || '', excuse: d.statut === 'E' });
        R.pres++; chAtt = true;
      } else if (x.type === 'note') {
        var q = P[nd(x.apprenant)]; if (!q) { inconnus[nd(x.apprenant)] = 1; return; }
        if (d.note == null) return;
        var cle = x.matricule + '|' + x.cle + '|' + nd(x.apprenant), max = 20, sc = Math.max(0, Math.min(Number(d.note), max));
        var ev = null; for (var j = 0; j < evaluations.length; j++) if (evaluations[j].source_formateur === cle) { ev = evaluations[j]; break; }
        if (!ev) { ev = { evaluation_id: nextNo(evaluations, 'evaluation_id', 'EXB-EVAL'), participant_id: q.participant_id, participant_name: q.name || '', matricule: q.matricule || q.participant_id, training: q.training || d.formation || '', source_formateur: cle, created_at: maintenant }; evaluations.unshift(ev); }
        Object.assign(ev, { type: 'Évaluation', date: jourDe(x), subject: (d.module && d.module !== 'Général') ? d.module : 'Suivi du formateur', score: sc, max: max, percent: Math.round(sc / max * 10000) / 100, epreuve: '',
          note: 'Suivi par ' + (x.nom || x.matricule) + (d.progression != null ? ' — progression ' + d.progression + ' %' : '') + (d.observation ? ' — ' + d.observation : '') });
        R.evals++; chEv = true;
      } else if (x.type === 'rapport' && typeof schedules !== 'undefined') {
        schedules.forEach(function (sc2) {
          if (sc2 && sc2.date === d.date && nz(sc2.training) === nz(d.formation) && (!d.module || !sc2.module || nz(sc2.module) === nz(d.module))) {
            sc2.statut_seance = d.realisee === false ? 'NON_TENUE' : 'TENUE'; sc2.rapport_formateur = d.contenu || ''; sc2.observations_formateur = d.observations || ''; sc2.duree_reelle = d.duree || ''; sc2.rapport_at = maintenant; R.seances++; chSch = true;
          }
        });
      }
    });
    R.inconnus = Object.keys(inconnus).length;
    try {
      if (chAtt) save('exb_attendance', attendance);
      if (chEv) save('exb_evaluations', evaluations);
      if (chSch) save('exb_schedules', schedules);
      if (chAtt || chEv || chSch) audit('INTERCONNEXION FORMATEURS', R.pres + ' présence(s), ' + R.evals + ' évaluation(s), ' + R.seances + ' séance(s)');
      ['renderAttendance', 'renderEvaluations', 'updateReports', 'renderSchedules', 'updateDashboard'].forEach(function (f) { try { if (typeof w[f] === 'function') w[f](); } catch (e) { /* écran absent */ } });
    } catch (e) { /* enregistrement local refusé : signalé par save() */ }
    return R;
  }
  function resume(R) { return R.pres + ' présence(s), ' + R.evals + ' évaluation(s), ' + R.seances + ' séance(s) de planning mises à jour' + (R.inconnus ? ' — ' + R.inconnus + ' apprenant(s) introuvable(s) dans Participants (matricule différent)' : '') + '.'; }
  w.EXBFormateurAppliquer = function () { var R = appliquer(lire()); dire('✓ Historique repris : ' + resume(R), R.inconnus ? 'warn' : 'success'); ecran(); return R; };

  async function recuperer(silencieux) {
    if (!srv()) return null;
    try {
      var L = await api('/rest/v1/rpc/formateur_retours_recus', { method: 'POST', body: '{}' });
      if (!L || !L.length) { if (!silencieux) dire('Aucun nouveau retour de formateur.', 'info'); return 0; }
      var cur = lire(), idx = {};
      cur.forEach(function (x, i) { idx[x.matricule + '|' + x.type + '|' + x.cle + '|' + x.apprenant] = i; });
      L.forEach(function (r) {
        var k = r.matricule + '|' + r.type + '|' + r.cle + '|' + r.apprenant, o = { id: r.id, matricule: r.matricule, nom: r.nom || '', type: r.type, cle: r.cle, apprenant: r.apprenant || '', data: r.data || {}, maj_le: r.maj_le };
        if (idx[k] != null) cur[idx[k]] = o; else { idx[k] = cur.length; cur.push(o); }
      });
      if (!ecrire(cur)) { w.alert('Enregistrement local refusé (espace plein ?). Rien n’a été marqué comme reçu.'); return null; }
      await api('/rest/v1/rpc/formateur_retours_marquer', { method: 'POST', body: JSON.stringify({ p_ids: L.map(function (r) { return r.id; }) }) });
      var R = appliquer(L.map(function (r) { return { matricule: r.matricule, nom: r.nom || '', type: r.type, cle: r.cle, apprenant: r.apprenant || '', data: r.data || {}, maj_le: r.maj_le }; }));
      if (!silencieux) dire('✓ ' + L.length + ' retour(s) repris. ' + resume(R), R.inconnus ? 'warn' : 'success');
      return L.length;
    } catch (e) { w.alert(erreur(e)); return null; }
  }
  function rapport() {
    var A = lire(), par = {};
    A.forEach(function (x) { (par[x.matricule] = par[x.matricule] || { nom: x.nom, L: [] }).L.push(x); });
    var cles = Object.keys(par);
    if (!cles.length) return '<p class="exb-muted">Aucun retour pour le moment. Touchez « 📥 Récupérer » après avoir publié l’espace formateur.</p>';
    return cles.map(function (m) {
      var g = par[m], L = g.L, h = '<div style="border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:10px 0"><b>👨‍🏫 ' + esc(g.nom || m) + '</b> <small>' + esc(m) + '</small>';
      var seances = {};
      L.filter(function (x) { return x.type === 'presence'; }).forEach(function (x) { var s = seances[x.cle] = seances[x.cle] || { d: x.data, P: 0, A: 0, R: 0, E: 0, abs: [] }; s[x.data.statut] = (s[x.data.statut] || 0) + 1; if (x.data.statut === 'A') s.abs.push(x.apprenant); });
      var ks = Object.keys(seances).sort();
      if (ks.length) h += '<h4 style="margin:10px 0 4px">📋 Présences</h4>' + ks.map(function (k) { var s = seances[k]; return '<div style="border-top:1px solid #eef2f7;padding:4px 0"><b>' + esc(s.d.date) + '</b> · ' + esc(s.d.formation) + ' · ' + esc(s.d.module) + '<br><small>Présents ' + s.P + ' · Absents ' + s.A + ' · Retards ' + s.R + ' · Excusés ' + s.E + (s.abs.length ? ' — absents : ' + esc(s.abs.join(', ')) : '') + '</small></div>'; }).join('');
      var notes = L.filter(function (x) { return x.type === 'note'; });
      if (notes.length) h += '<h4 style="margin:10px 0 4px">📈 Suivi des apprenants</h4>' + notes.map(function (x) { return '<div style="border-top:1px solid #eef2f7;padding:4px 0"><b>' + esc(x.apprenant) + '</b> · ' + esc(x.data.formation) + ' · ' + esc(x.data.module) + '<br><small>Note : ' + (x.data.note == null ? '–' : esc(x.data.note) + '/20') + ' · Progression : ' + (x.data.progression == null ? '–' : esc(x.data.progression) + ' %') + (x.data.observation ? ' · ' + esc(x.data.observation) : '') + '</small></div>'; }).join('');
      var rap = L.filter(function (x) { return x.type === 'rapport'; }).sort(function (a, b) { return String(a.data.date).localeCompare(String(b.data.date)); });
      if (rap.length) h += '<h4 style="margin:10px 0 4px">📓 Rapports de séance</h4>' + rap.map(function (x) { return '<div style="border-top:1px solid #eef2f7;padding:4px 0"><b>' + esc(x.data.date) + '</b> · ' + esc(x.data.formation) + ' · ' + esc(x.data.module) + (x.data.realisee === false ? ' <b style="color:#b45309">(séance non tenue)</b>' : '') + '<br><small>' + esc(x.data.contenu || '') + (x.data.observations ? ' — Observations : ' + esc(x.data.observations) : '') + (x.data.duree ? ' — Durée : ' + esc(x.data.duree) : '') + '</small></div>'; }).join('');
      var msg = L.filter(function (x) { return x.type === 'message'; });
      if (msg.length) h += '<h4 style="margin:10px 0 4px">💬 Messages</h4>' + msg.map(function (x) { return '<div style="border-top:1px solid #eef2f7;padding:4px 0"><span class="tag">' + esc(x.data.objet || '') + '</span> ' + esc(x.data.texte || '') + '</div>'; }).join('');
      return h + '<div style="margin-top:8px"><button type="button" class="primary" data-frep="' + esc(m) + '">↩ Répondre à ce formateur</button></div></div>';
    }).join('');
  }
  function ecran() {
    var o = document.getElementById('exbFormRetours');
    if (!o) { o = document.createElement('div'); o.id = 'exbFormRetours'; o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px'; document.body.appendChild(o); }
    o.innerHTML = '<div style="background:#fff;color:#0f172a;border-radius:14px;max-width:760px;width:100%;padding:14px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><h3 style="margin:0">📥 Retours des formateurs</h3><button type="button" class="muted" data-fclose="1">✕ Fermer</button></div>' + rapport() + '</div>';
    o.onclick = async function (e) {
      var b = e.target.closest ? e.target.closest('button') : null; if (e.target === o) { o.remove(); return; } if (!b) return;
      if (b.getAttribute('data-fclose')) { o.remove(); return; }
      var m = b.getAttribute('data-frep'); if (!m) return;
      var t = w.prompt('Réponse à ce formateur (visible dans son espace › Messages à l’administration) :', ''); if (!t || !t.trim()) return;
      if (!srv()) return;
      try { await api('/rest/v1/rpc/formateur_repondre', { method: 'POST', body: JSON.stringify({ p_matricule: m, p_texte: t.trim() }) }); dire('✓ Réponse envoyée.', 'success'); }
      catch (x) { w.alert(erreur(x)); }
    };
  }
  w.EXBFormateurRetours = async function () { await recuperer(false); ecran(); };
  function injecter() {
    var sec = document.getElementById('formateurs'); if (!sec || sec.querySelector('.exb-retours-formateurs')) return;
    var d = document.createElement('div'); d.className = 'card exb-retours-formateurs'; d.style.cssText = 'border:1px solid #dce3ed;border-radius:12px;padding:12px;margin:10px 0';
    d.innerHTML = '<h3 style="margin:0 0 4px">📥 Retours des formateurs</h3><p class="exb-muted" style="margin:0 0 8px">Présences, suivi des apprenants, rapports de séance et messages saisis par les formateurs dans leur espace. Les formateurs voient leur planning après « 📢 Publier l’espace formateur » (republiez après chaque changement de planning ou d’apprenants).</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="primary" id="exbFRBtn">📥 Récupérer et lire les retours</button><button type="button" class="muted" id="exbFRHist">🗂 Historique sur cet appareil</button><button type="button" class="muted" id="exbFRApp">🔁 Reprendre dans Présences / Évaluations</button></div><p class="exb-muted" style="margin:8px 0 0">Les présences vont dans Présences, les notes dans Évaluations (note sur 20), les rapports dans le Planning (séance tenue ou non). Reprise sans doublon.</p>';
    sec.insertBefore(d, sec.firstChild);
    d.querySelector('#exbFRBtn').onclick = function () { w.EXBFormateurRetours(); };
    d.querySelector('#exbFRHist').onclick = ecran;
    d.querySelector('#exbFRApp').onclick = function () { w.EXBFormateurAppliquer(); };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injecter); else injecter();
  setTimeout(injecter, 1500);
})(window);
