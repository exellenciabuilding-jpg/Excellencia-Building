# V99y — Calcul de structure : géométrie des éléments + note de calcul de bureau d'études

Fichiers modifiés : `calcul-structure/index.html` (module Bâtiment), `sw.js` (cache `exb-v99y-geometrie-note-1`), libellé de version du cadre.
Un bâtiment enregistré s'ouvre comme avant : sans réglage, toutes les valeurs restent celles du bâtiment (onglet Général).

## 1. Géométrie des éléments (onglet « Axes & modélisation »)
- **Géométrie du niveau** : section des poutres (b × h) et épaisseur des dalles **propres à chaque niveau** (champ vide = valeur commune). Boutons « Appliquer à tous les niveaux » et « Valeurs communes ».
- **Section imposée d'un poteau** : touchez un poteau puis saisissez sa section (carrée, de 20 à 100 cm, par pas de 5). Le calcul la retient si elle est suffisante, sinon l'augmente et le signale. « Même section à tous les niveaux » et « Section automatique ».
- Pris en compte partout : descente de charges (poids propre des poutres et des dalles par niveau), dimensionnement des poutres, vue 3D, plans, coffrage, élévation, quantités, tableaux et notes. Insérer ou supprimer un axe décale correctement les sections imposées.
- « Copier ce niveau vers tous » copie aussi les sections de poteaux imposées.

## 2. Note de calcul globale du bâtiment (7 pages)
1 Objet et description de l'ouvrage · règlements, matériaux, enrobages, exposition, sol — 2 Géométrie : tableau des axes (positions), niveaux (cotes, hauteurs, sections de poutres, épaisseur de dalle, nombre d'éléments), sections de poteaux imposées, **plans de trame par niveau** — 3 Charges et combinaisons (par niveau, charges aux fondations, méthode) — 4 Poteaux (matrice des sections par niveau, charges au pied, détail et ferraillage) — 5 Poutres (section de chaque file) — 6 Dalles (épaisseur de chaque panneau) — 7 Quantités de béton par niveau et ratio, synthèse des vérifications avec conclusion, observations, limites et références.
Tableaux numérotés ; cartouche, page de garde, QR et numéro de note (NCS-AAAA-NNN) inchangés.

## Limites
- Section de poutre commune à toutes les files d'un même niveau (pas encore par poutre individuelle) ; poteaux carrés ; dalles d'épaisseur commune par niveau.
- Références normatives de la note à adapter au pays du projet. Calculs indicatifs, à faire vérifier par un ingénieur.
- Retour en arrière : restaurer l'ancien `calcul-structure/index.html`.
