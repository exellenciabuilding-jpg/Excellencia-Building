/* Excellencia Building V99s — Calcul de structure (béton armé BAEL 91 / EC2)
 * Intègre le calculateur « calcul de structure » dans le logiciel central, catégorie « Ingénierie & Structure » :
 * bâtiment (descente de charges, 3D, plans), poutre continue, poteau, dalle/plancher, semelle isolée, escalier,
 * dosage béton, mortier, volumes, coffrage, ferraillage, moment max, coûts, agglos, devis DQE.
 * Le calculateur reste un bloc indépendant (calcul-structure/index.html, affiché dans la page) : aucun de ses calculs
 * ni aucune fonction existante du logiciel central n'est modifié, et aucun conflit de noms n'est possible.
 * Données du calculateur : clés xbp / xbh / xbd / xbb du stockage de l'appareil (aucun lien avec les clés exb_* du central).
 * Pour retirer le module : supprimer la balise <script src="exb-calcul-structure.js"> de index.html. */
(function(w,d){'use strict';
var URL_CALC='calcul-structure/index.html';
var $=function(i){return d.getElementById(i)};
var esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};

/* Modules proposés en raccourci (clé = clé interne du calculateur) */
var CHIPS=[
 ['predim','📏','Prédimensionnement'],['batiment','🏢','Bâtiment'],['poutre','📏','Poutre'],['poteau','🏛️','Poteau'],['plancher','🧱','Dalle / plancher'],
 ['semelle','🦶','Semelle'],['escalier','🪜','Escalier'],['dosage','🧪','Dosage béton'],['mortier','🧰','Mortier'],
 ['volume','📦','Volumes'],['vent','🌬️','Vent'],['seisme','🌋','Séisme'],['pieu','🕳️','Pieux'],['maconnerie','🧱','Maçonnerie'],['apoutre','🏗️','Poutre acier'],['apoteau','🏛️','Poteau acier'],['bpoutre','🪵','Poutre bois'],['bpoteau','🌲','Poteau bois'],['ferraillage','⛓️','Ferraillage'],['cout','💰','Coûts'],['devis','🧾','Devis DQE']];
/* Entrées ajoutées au menu « Ingénierie & Structure » (en plus de l'écran complet) */
var MENU=[
 ['bcs_pre','📏 Prédimensionnement','predim'],['bcs_bat','🏢 Bâtiment','batiment'],['bcs_pou','📏 Poutre continue','poutre'],['bcs_pot','🏛️ Poteau','poteau'],
 ['bcs_dal','🧱 Dalle / plancher','plancher'],['bcs_sem','🦶 Semelle isolée','semelle'],['bcs_esc','🪜 Escalier','escalier'],['bcs_dos','🧪 Dosage béton','dosage'],
 ['bcs_mor','🧰 Mortier','mortier'],['bcs_vol','📦 Volumes','volume'],['bcs_cof','🔲 Coffrage','coffrage'],['bcs_fer','⛓️ Ferraillage','ferraillage'],
 ['bcs_mom','📈 Moment maximal','moment'],['bcs_cou','💰 Coûts','cout'],['bcs_agg','🧱 Agglos','agglos'],['bcs_ven','🌬️ Vent','vent'],['bcs_sei','🌋 Séisme','seisme'],['bcs_pie','🕳️ Pieux','pieu'],['bcs_mac','🧱 Maçonnerie porteuse','maconnerie'],['bcs_apo','🏗️ Poutre acier','apoutre'],['bcs_apt','🏛️ Poteau acier','apoteau'],['bcs_bpo','🪵 Poutre bois','bpoutre'],['bcs_bpt','🌲 Poteau bois','bpoteau'],['bcs_dev','🧾 Devis DQE','devis']];

var NORMES=[['bael','BAEL 91 mod. 99'],['ec2fr','NF EN 1992-1-1 (Annexe nationale française)'],['ec2','EN 1992-1-1 — Eurocode 2 (base)'],['ec2uk','BS EN 1992-1-1 (Annexe nationale britannique)']];
var pending=null,ready=false;
function syncNorm(){try{var s=$('exbCalcNorm'),n=frame().contentWindow.nrm().id;if(s&&n)s.value=n}catch(e){}}
function setNorm(id){var f=frame();if(!f)return;try{f.contentWindow.postMessage({exbCalc:'norm',id:id},w.location.origin)}catch(e){}}

function frame(){return $('exbCalcFrame')}
function send(k){
  var f=frame();if(!f)return;
  if(!ready){pending=k;return}
  try{f.contentWindow.postMessage({exbCalc:'open',k:k||'home'},w.location.origin)}catch(e){}
}
function css(){
  if($('exbCalcCss'))return;
  var s=d.createElement('style');s.id='exbCalcCss';
  s.textContent='#calcStructure .cs-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:10px}'
  +'#calcStructure .cs-chips{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 12px}'
  +'#calcStructure .cs-chips button{border:1px solid #d5dbe5;background:#fff;color:#12254a;border-radius:999px;padding:8px 14px;font:700 13px Arial;cursor:pointer}'
  +'#calcStructure .cs-chips button:hover{background:#e8f0fe;border-color:#1f6feb}'
  +'#calcStructure .cs-chips button.on{background:#12254a;color:#fff;border-color:#12254a}'
  +'#calcStructure .cs-wrap{border:1px solid #d5dbe5;border-radius:14px;overflow:hidden;background:#f4f4f4;max-width:100%;margin:0 auto;box-shadow:0 6px 24px #0f2e6618}'
  +'#calcStructure iframe{display:block;width:100%;height:calc(100vh - 170px);min-height:560px;border:0;background:#f4f4f4}'
  +'#calcStructure .cs-note{margin:10px auto 0;max-width:100%;font-size:12px;color:#6b7a99;text-align:center}'
  +'@media(max-width:700px){#calcStructure iframe{height:calc(100vh - 150px);min-height:480px}#calcStructure .cs-wrap{border-radius:10px}}';
  d.head.appendChild(s);
}
function build(){
  var sec=d.createElement('section');sec.id='calcStructure';sec.style.display='none';
  sec.innerHTML='<div class="card"><div class="cs-head"><div><h2>🧮 Calcul de structure</h2></div></div>'
   +'<div class="cs-chips"><label style="font:700 13px Arial;color:#12254a">📘 Norme de calcul : <select id="exbCalcNorm" onchange="EXBCALC.norm(this.value)" style="padding:7px 10px;border-radius:8px;border:1px solid #d5dbe5;font:600 13px Arial;max-width:100%">'+NORMES.map(function(n){return '<option value="'+n[0]+'">'+esc(n[1])+'</option>'}).join('')+'</select></label></div>'
   +'<div class="cs-wrap"><iframe id="exbCalcFrame" title="Calcul de structure" src="'+URL_CALC+'" loading="lazy" allow="clipboard-write; fullscreen"></iframe></div>'
   +'<p class="cs-note">Les calculs sont indicatifs et doivent être vérifiés par un ingénieur structure avant exécution. Les notes de calcul et plans s’impriment depuis chaque module.</p></div>';
  return sec;
}
function mount(){
  if($('calcStructure'))return;
  var ref=$('metreDevis')||$('bureauEtudes')||$('projets'),host=d.querySelector('.wrap')||d.querySelector('main')||d.body,sec=build();
  css();
  if(ref&&ref.parentNode)ref.parentNode.insertBefore(sec,ref.nextSibling);else host.appendChild(sec);

  /* Boutons du menu d'origine (masqué) : repris par le nouveau menu « Ingénierie & Structure » */
  var anchor=$('bdev')||$('bbet'),par=anchor&&anchor.parentNode;
  if(par){
    var main=d.createElement('button');main.id='bcalcs';main.type='button';main.textContent='🧮 Calcul de structure';main.setAttribute('onclick',"show('calcStructure')");main.hidden=true;main.style.display='none';
    par.insertBefore(main,anchor.nextSibling);
    var prev=main;
    MENU.forEach(function(m){var b=d.createElement('button');b.id=m[0];b.type='button';b.textContent=m[1];b.setAttribute('onclick',"EXBCALC.open('"+m[2]+"')");par.insertBefore(b,prev.nextSibling);prev=b});
  }

  /* Écran géré par show() : affiché seulement pour 'calcStructure' */
  var os=w.show;
  if(typeof os==='function'&&!w.__exbCalcShow){
    w.__exbCalcShow=1;
    w.show=function(x){
      var r=os.apply(this,arguments),e=$('calcStructure');
      if(e)e.style.display=(x==='calcStructure')?'':'none';
      var b=$('bcalcs');if(b)b.classList.toggle('active',x==='calcStructure');
      return r};
  }
  var f=frame();
  if(f)f.addEventListener('load',function(){setTimeout(function(){syncNorm();ready=true;if(pending){var k=pending;pending=null;send(k)}},1500)});
  w.addEventListener('message',function(e){
    if(e.origin!==w.location.origin||!e.data||e.data.exbCalc!=='ready')return;
    ready=true;if(pending){var k=pending;pending=null;send(k)}
  });
}
function mark(k){
  Array.prototype.forEach.call(d.querySelectorAll('#exbCalcChips button'),function(b){b.classList.toggle('on',b.getAttribute('data-k')===k)})}

w.EXBCALC={
  /* EXBCALC.open('poutre') : ouvre l'écran et lance directement le module demandé */
  open:function(k){
    if(!$('calcStructure'))mount();
    if(typeof w.show==='function')w.show('calcStructure');
    mark(k);send(k||'home');setTimeout(syncNorm,900);
    try{w.scrollTo(0,0)}catch(e){}
  },
  norm:function(id){setNorm(id);setTimeout(syncNorm,500)},
  version:'V99zm'
};

function start(){setTimeout(mount,700)}
if(d.readyState==='complete')start();else w.addEventListener('load',start);
/* agrandissement : si le plein écran du navigateur est refusé, le calcul occupe toute la fenêtre du logiciel */
w.addEventListener('message',function(e){var f=$('exbCalcFrame');if(!f||!e.data||typeof e.data.exbCalcBig==='undefined'||e.source!==f.contentWindow)return;
 f.style.cssText=e.data.exbCalcBig?'position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:99999;min-height:0':'';});
})(window,document);
