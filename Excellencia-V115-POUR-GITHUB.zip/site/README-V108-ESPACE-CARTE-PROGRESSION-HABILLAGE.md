# V108 — Espace apprenant : carte d'apprenant, progression, paramètres, habillage

- **Ma carte d'apprenant** (Profil › Ma carte d'apprenant, ou menu) : même dessin que la carte matricule de `apprenant.html` (photo, nom, formation, matricule, année, QR de vérification). Téléchargement en PNG. La photo vient de « Mon profil › Changer la photo ».
- **Ma formation** : progression globale (séances effectuées / séances du planning, sinon avancement entre date de début et de fin) et barre par module (séances effectuées, note /20 si publiée). Les modules sont rapprochés des séances par leur nom.
- **Paramètres** : garder la connexion sur l'appareil, changer son mot de passe (même fonction serveur `apprenant_changer_mdp`).
- **Mon profil** : raccourcis carte et paramètres, bouton « Se déconnecter ».
- **Habillage** : couleurs de la charte (bleu nuit #101827, bleu institutionnel #1C3965, doré #D8A43C, vert validation #249566), en-tête sombre avec logo, « Services disponibles » en tuiles, bannière « Votre réussite est notre priorité ».

Fichiers modifiés : `espace-apprenant.html`, `sw.js`. Aucune nouvelle fonction SQL.
