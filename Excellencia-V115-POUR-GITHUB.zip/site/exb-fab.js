/* Excellencia Building — boutons flottants personnalisables (mobile et PC)
 * Rôle : rendre déplaçables les boutons flottants du logiciel (🤖 assistant, 🔑 licences, ❓ aide, 🗄 base partagée, 🔐 2FA, 🔔 notifications…)
 * SANS modifier les modules qui les créent : ce fichier les détecte, puis ajoute par-dessus :
 *   - déplacement au doigt (glisser, ou maintenir puis glisser) ; clic de la souris sur PC ;
 *   - position mémorisée (en proportion de l'écran : elle suit la rotation et le clavier) ;
 *   - boutons toujours gardés dans la zone visible (barres Android, clavier, encoche) ;
 *   - esquive automatique d'un champ de saisie sélectionné (le bouton ne le cache jamais) ;
 *   - menu d'options (maintien sans bouger, ou clic droit) : regrouper dans un menu flottant, réduire en petite icône, remettre en place ;
 *   - mode « regroupé » : une seule pastille ⊞ qui déplie les boutons (rétractable) ;
 *   - carte de réglages dans Paramètres.
 * Un autre module peut déclarer son propre bouton flottant avec l'attribut data-exb-fab="identifiant". */
(function (w, d) {
  'use strict';
  if (w.EXB_FAB) return;

  var KEY = 'exb_fab_v1', GAP = 8, HOLD = 450, SLOP_T = 9, SLOP_M = 4;
  var NAMES = {
    exbAIbtn: 'Assistant IA', exbGenBtn: 'Licences clients', exbHelpBtn: 'Aide et assistance',
    exbdb_chip: 'Base partagée', exbMfaBtn: 'Double authentification', exbCoreNotifications: 'Notifications'
  };
  var ORDER = ['exbAIbtn', 'exbHelpBtn', 'exbGenBtn', 'exbCoreNotifications', 'exbdb_chip', 'exbMfaBtn'];
  var IGNORE = { exbBurger: 1, exbSide: 1, exbStatus: 1, exbWM: 1, exbDim: 1, toastBox: 1, exbV97Badge: 1, exbLicLock: 1, exbSplash: 1,
    exbNudge: 1, exbGuide: 1, exbFabHub: 1, exbFabMenu: 1, exbFabTip: 1, exbQuickActions: 1, exbAI: 1, exbGenOv: 1, exbBrandUI: 1 };

  /* ---------- état mémorisé ---------- */
  function fresh() { return { mode: 'free', mini: false, pos: {}, tip: false }; }
  function load() {
    try {
      var o = JSON.parse(w.localStorage.getItem(KEY) || 'null');
      if (o && typeof o === 'object') { var s = fresh(); for (var k in s) if (o[k] != null) s[k] = o[k]; if (!s.pos || typeof s.pos !== 'object') s.pos = {}; return s; }
    } catch (e) {}
    return fresh();
  }
  var st = load(), items = {}, open = false, drag = null, typing = null, raf = 0, hub = null, menu = null, safeProbe = null;
  function save() { try { w.localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function vib(n) { try { if (w.navigator.vibrate) w.navigator.vibrate(n); } catch (e) {} }

  /* ---------- zone visible (clavier, barres système, encoche) ---------- */
  function safe() {
    if (!safeProbe) {
      safeProbe = d.createElement('div');
      safeProbe.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)';
      d.body.appendChild(safeProbe);
    }
    var c = w.getComputedStyle(safeProbe);
    return { t: parseFloat(c.paddingTop) || 0, r: parseFloat(c.paddingRight) || 0, b: parseFloat(c.paddingBottom) || 0, l: parseFloat(c.paddingLeft) || 0 };
  }
  function area() {
    var v = w.visualViewport, L = 0, T = 0, R = w.innerWidth, B = w.innerHeight;
    if (v) { L = v.offsetLeft; T = v.offsetTop; R = L + v.width; B = T + v.height; }
    var s = safe();
    return { l: L + s.l + GAP, t: T + s.t + GAP, r: R - s.r - GAP, b: B - s.b - GAP };
  }
  function isEditable(e) {
    if (!e || e === d.body) return false;
    var t = (e.tagName || '').toLowerCase();
    if (t === 'textarea' || t === 'select') return true;
    if (t === 'input') return !/^(button|submit|reset|checkbox|radio|range|color|file|image)$/i.test(e.type || 'text');
    return !!e.isContentEditable;
  }

  /* ---------- positionnement ---------- */
  function keyOf(el) { return el.id || el.getAttribute('data-exb-fab') || ''; }
  function rememberOrig(el) {
    if (el.__exbOrig) return;
    var o = {};['left', 'top', 'right', 'bottom'].forEach(function (p) { o[p] = [el.style.getPropertyValue(p), el.style.getPropertyPriority(p)]; });
    el.__exbOrig = o;
  }
  function place(el, x, y) {
    rememberOrig(el);
    var s = el.style;
    s.setProperty('left', Math.round(x) + 'px', 'important'); s.setProperty('top', Math.round(y) + 'px', 'important');
    s.setProperty('right', 'auto', 'important'); s.setProperty('bottom', 'auto', 'important');
    el.__exbPlaced = true;
  }
  function unplace(el) {
    if (!el.__exbPlaced) return;
    var o = el.__exbOrig || {};
    ['left', 'top', 'right', 'bottom'].forEach(function (p) {
      el.style.removeProperty(p);
      if (o[p] && o[p][0]) el.style.setProperty(p, o[p][0], o[p][1] || '');
    });
    el.__exbPlaced = false;
  }
  function shift(el, dx, dy) { el.style.setProperty('--exb-dx', Math.round(dx) + 'px'); el.style.setProperty('--exb-dy', Math.round(dy) + 'px'); }
  /* position « de mise en page » (sans animation ni décalage) : fiable même pendant une transition */
  function base(el) { return { l: el.offsetLeft, t: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight }; }
  function curShift(el) { return { dx: parseFloat(el.style.getPropertyValue('--exb-dx')) || 0, dy: parseFloat(el.style.getPropertyValue('--exb-dy')) || 0 }; }
  function fromFrac(el, f, a) {
    var w0 = el.offsetWidth, h0 = el.offsetHeight;
    return { x: a.l + clamp(f.fx, 0, 1) * Math.max(0, (a.r - a.l) - w0), y: a.t + clamp(f.fy, 0, 1) * Math.max(0, (a.b - a.t) - h0) };
  }
  function toFrac(el, x, y, a) {
    var rx = Math.max(1, (a.r - a.l) - el.offsetWidth), ry = Math.max(1, (a.b - a.t) - el.offsetHeight);
    return { fx: clamp((x - a.l) / rx, 0, 1), fy: clamp((y - a.t) / ry, 0, 1) };
  }
  function appHidden(el) { return !el.isConnected || el.hidden || el.style.display === 'none' || el.style.visibility === 'hidden'; }

  /* ---------- détection des boutons flottants ---------- */
  function adopt(el, id) {
    if (!el.__exbFab) {
      el.__exbFab = 1; el.classList.add('exb-fab'); rememberOrig(el);
      el.style.touchAction = 'none';
      el.addEventListener('pointerdown', onDown);
      el.addEventListener('click', clickGuard, true);
      el.addEventListener('click', function () { if (st.mode === 'group' && open && el !== hub) setTimeout(function () { setOpen(false); }, 80); });
      el.addEventListener('contextmenu', function (e) { e.preventDefault(); if (!(drag && drag.touch)) openMenu(el); });
    }
    el.setAttribute('data-exb-name', NAMES[id] || el.getAttribute('title') || el.getAttribute('aria-label') || id);
    el.classList.toggle('exb-nolbl', (el.textContent || '').trim().length > 5);   /* pastille déjà lisible (ex. « Base partagée ») : pas d'étiquette en double */
    items[id] = el;
  }
  function scan() {
    var seen = {}, k;
    for (k in NAMES) { var e = d.getElementById(k); if (e) { adopt(e, k); seen[k] = 1; } }
    Array.prototype.forEach.call(d.querySelectorAll('[data-exb-fab]'), function (e) { var id = e.getAttribute('data-exb-fab') || e.id; if (id && id !== 'hub') { adopt(e, id); seen[id] = 1; } });
    Array.prototype.forEach.call(d.body.children, function (e) {
      if (e.tagName !== 'BUTTON' || !e.id || IGNORE[e.id] || NAMES[e.id] || seen[e.id]) return;
      var c = w.getComputedStyle(e);
      if (c.position === 'fixed' && e.offsetWidth > 0 && e.offsetWidth <= 72 && e.offsetHeight <= 72) { adopt(e, e.id); seen[e.id] = 1; }
    });
    for (k in items) if (!seen[k] || !items[k].isConnected) delete items[k];
  }
  function list() {
    var ks = Object.keys(items).filter(function (k) { return !appHidden(items[k]); });
    ks.sort(function (a, b) { var i = ORDER.indexOf(a), j = ORDER.indexOf(b); return (i < 0 ? 99 : i) - (j < 0 ? 99 : j); });
    return ks;
  }

  /* ---------- pastille ⊞ (menu flottant rétractable) ---------- */
  function ensureHub() {
    if (hub && hub.isConnected) return hub;
    hub = d.createElement('button');
    hub.id = 'exbFabHub'; hub.type = 'button'; hub.className = 'exb-fab no-print'; hub.textContent = '⊞';
    hub.setAttribute('aria-label', 'Boutons rapides'); hub.title = 'Boutons rapides (maintenez pour déplacer)';
    hub.style.touchAction = 'none';
    hub.addEventListener('pointerdown', onDown);
    hub.addEventListener('click', clickGuard, true);
    hub.addEventListener('click', function () { setOpen(!open); });
    hub.addEventListener('contextmenu', function (e) { e.preventDefault(); if (!(drag && drag.touch)) openMenu(hub); });
    d.body.appendChild(hub);
    return hub;
  }
  function removeHub() { if (hub) { hub.remove(); hub = null; } }
  function setOpen(v) { open = !!v && st.mode === 'group'; render(); }

  function layoutStack(keys) {
    var a = area(), hb = base(hub), hs = curShift(hub), hr = { left: hb.l + hs.dx, top: hb.t + hs.dy, width: hb.w, height: hb.h, right: hb.l + hs.dx + hb.w, bottom: hb.t + hs.dy + hb.h }, up = (hr.top + hr.height / 2) > (a.t + a.b) / 2, right = (hr.left + hr.width / 2) > (a.l + a.r) / 2;
    var els = keys.map(function (k) { return items[k]; });
    els.forEach(function (e) { e.classList.remove('exb-fab-off'); e.classList.add('exb-fab-stack'); e.classList.toggle('exb-lbl-l', right); e.classList.toggle('exb-lbl-r', !right); shift(e, 0, 0); });
    var need = 0; els.forEach(function (e) { need += e.offsetHeight + GAP; });
    var room = up ? hr.top - a.t : a.b - hr.bottom, i, x, y, e2;
    if (need <= room) {
      y = up ? hr.top - GAP : hr.bottom + GAP;
      for (i = 0; i < els.length; i++) {
        e2 = els[i]; x = right ? hr.right - e2.offsetWidth : hr.left;
        if (up) y -= e2.offsetHeight;
        place(e2, clamp(x, a.l, Math.max(a.l, a.r - e2.offsetWidth)), clamp(y, a.t, Math.max(a.t, a.b - e2.offsetHeight)));
        y = up ? y - GAP : y + e2.offsetHeight + GAP;
      }
    } else { /* écran bas (paysage) : on déplie en rangée vers le côté le plus large */
      var toRight = (a.r - hr.right) >= (hr.left - a.l);
      x = toRight ? hr.right + GAP : hr.left - GAP;
      for (i = 0; i < els.length; i++) {
        e2 = els[i]; if (!toRight) x -= e2.offsetWidth;
        place(e2, clamp(x, a.l, Math.max(a.l, a.r - e2.offsetWidth)), clamp(hr.top, a.t, Math.max(a.t, a.b - e2.offsetHeight)));
        x = toRight ? x + e2.offsetWidth + GAP : x - GAP;
      }
    }
  }

  /* ---------- rendu principal ---------- */
  function render() {
    raf = 0;
    if (!d.body) return;
    scan();
    var keys = list(), a = area(), k, el;
    var onLogin = (function () { var l = d.getElementById('loginScreen'); return !!(l && l.offsetParent !== null); })();
    if (st.mode === 'group' && keys.length && !onLogin) {
      var h = ensureHub(); h.classList.toggle('exb-hub-mini', !!st.mini); h.classList.toggle('exb-hub-open', open);
      var hp = st.pos.hub; if (hp) { var q = fromFrac(h, hp, a); place(h, q.x, q.y); } else { unplace(h); }
      for (k in items) { el = items[k]; if (keys.indexOf(k) < 0 || !open) { el.classList.add('exb-fab-off'); el.classList.remove('exb-fab-stack'); } }
      if (open && keys.length) layoutStack(keys);
      fitInside(h, a);
    } else {
      open = false; removeHub();
      for (k in items) {
        el = items[k]; el.classList.remove('exb-fab-off', 'exb-fab-stack', 'exb-lbl-l', 'exb-lbl-r');
        var p = st.pos[k];
        if (p && !(drag && drag.el === el)) { var u = fromFrac(el, p, a); place(el, u.x, u.y); } else if (!p) unplace(el);
        if (!(drag && drag.el === el)) fitInside(el, a);
      }
      if (keys.length && !st.tip && !onLogin) { st.tip = true; save(); tip(); }
    }
    dodge();
  }
  function soon() { if (!raf) raf = w.requestAnimationFrame ? w.requestAnimationFrame(render) : w.setTimeout(render, 16); }

  /* garde chaque bouton dans la zone visible, sans toucher à la position mémorisée */
  function fitInside(el, a) {
    if (!el.isConnected || el.classList.contains('exb-fab-off')) return;
    var b = base(el), dx = 0, dy = 0;
    if (!b.w) { shift(el, 0, 0); return; }
    if (b.l < a.l) dx = a.l - b.l; else if (b.l + b.w > a.r) dx = a.r - (b.l + b.w);
    if (b.t < a.t) dy = a.t - b.t; else if (b.t + b.h > a.b) dy = a.b - (b.t + b.h);
    shift(el, dx, dy);
  }

  /* esquive d'un champ de saisie : le bouton ne le recouvre jamais */
  function dodge() {
    var f = d.activeElement, a = area(), k;
    for (k in items) { items[k].classList.remove('exb-fab-typing'); }
    if (hub) hub.classList.remove('exb-fab-typing');
    if (!isEditable(f)) return;
    var fr = f.getBoundingClientRect();
    if (!fr.width || !fr.height) return;
    var zone = { l: fr.left - 6, r: fr.right + 6, t: fr.top - 6, b: fr.bottom + 6 };
    var all = Object.keys(items).map(function (x) { return items[x]; }); if (hub) all.push(hub);
    all.forEach(function (e) {
      if (e.classList.contains('exb-fab-off') || !e.isConnected) return;
      var b = base(e), s0 = curShift(e), l = b.l + s0.dx, t = b.t + s0.dy;
      var hit = l + b.w > zone.l && l < zone.r && t + b.h > zone.t && t < zone.b;
      if (!hit) return;
      /* le bouton passe au-dessus du champ ; sinon en dessous ; sinon on l'estompe */
      if (zone.t - b.h >= a.t) shift(e, s0.dx, zone.t - b.h - b.t);
      else if (zone.b + b.h <= a.b) shift(e, s0.dx, zone.b - b.t);
      else e.classList.add('exb-fab-typing');
    });
  }

  /* ---------- glisser / maintenir ---------- */
  function clickGuard(e) {
    var el = e.currentTarget;
    if (el.__exbNoClick && Date.now() < el.__exbNoClick) { e.stopImmediatePropagation(); e.preventDefault(); }
  }
  function canDrag(el) { return el === hub || st.mode !== 'group'; }
  function onDown(e) {
    if (e.button > 0 || drag) return;
    var el = e.currentTarget;
    if (!canDrag(el)) return;
    closeMenu();
    var b0 = base(el), s0 = curShift(el);
    drag = { el: el, id: el === hub ? 'hub' : keyOf(el), sx: e.clientX, sy: e.clientY, ox: e.clientX - (b0.l + s0.dx),
      oy: e.clientY - (b0.t + s0.dy), moved: false, picked: false, touch: e.pointerType !== 'mouse', x: 0, y: 0, timer: 0 };
    drag.timer = w.setTimeout(pick, HOLD);
    d.addEventListener('pointermove', onMove, true);
    d.addEventListener('pointerup', onUp, true);
    d.addEventListener('pointercancel', onUp, true);
  }
  function pick() {
    if (!drag || drag.moved) return;
    drag.picked = true; drag.el.classList.add('exb-fab-pick'); vib(18);
  }
  function startDrag() {
    drag.moved = true; w.clearTimeout(drag.timer);
    drag.el.classList.add('exb-fab-drag'); d.documentElement.classList.add('exb-fab-dragging');
    drag.el.classList.remove('exb-fab-typing'); shift(drag.el, 0, 0);
    if (!drag.picked) vib(8);
  }
  function onMove(e) {
    if (!drag) return;
    var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.moved) {
      if (Math.sqrt(dx * dx + dy * dy) < (drag.touch ? SLOP_T : SLOP_M)) return;
      startDrag();
    }
    e.preventDefault();
    var a = area(), el = drag.el;
    drag.x = clamp(e.clientX - drag.ox, a.l, Math.max(a.l, a.r - el.offsetWidth));
    drag.y = clamp(e.clientY - drag.oy, a.t, Math.max(a.t, a.b - el.offsetHeight));
    place(el, drag.x, drag.y);
  }
  function onUp() {
    if (!drag) return;
    var g = drag; drag = null;
    w.clearTimeout(g.timer);
    d.removeEventListener('pointermove', onMove, true); d.removeEventListener('pointerup', onUp, true); d.removeEventListener('pointercancel', onUp, true);
    g.el.classList.remove('exb-fab-drag', 'exb-fab-pick'); d.documentElement.classList.remove('exb-fab-dragging');
    if (g.moved) {
      g.el.__exbNoClick = Date.now() + 450;
      var a = area(), x = g.x, y = g.y, wd = g.el.offsetWidth;
      if (x - a.l < 22) x = a.l; else if (a.r - (x + wd) < 22) x = a.r - wd;   /* aimantation douce sur les bords */
      place(g.el, x, y);
      st.pos[g.id] = toFrac(g.el, x, y, a); save();
      if (g.el === hub && open) layoutStack(list());
      soon();
    } else if (g.picked) {
      g.el.__exbNoClick = Date.now() + 450;
      openMenu(g.el);
    }
  }

  /* ---------- menu d'options ---------- */
  function closeMenu() { if (menu) { menu.remove(); menu = null; return true; } return false; }
  function openMenu(anchor) {
    closeMenu();
    menu = d.createElement('div'); menu.id = 'exbFabMenu'; menu.className = 'no-print'; menu.setAttribute('role', 'menu');
    var grouped = st.mode === 'group', id = anchor === hub ? 'hub' : keyOf(anchor), rows = [];
    rows.push(grouped ? ['free', '↗ Séparer les boutons'] : ['group', '🧲 Regrouper dans un menu flottant']);
    rows.push(st.mini && grouped ? ['maxi', '➕ Agrandir la pastille'] : ['mini', '➖ Réduire en petite icône']);
    if (st.pos[id]) rows.push(['one', '↩ Remettre ce bouton à sa place']);
    rows.push(['all', '↺ Tout remettre par défaut'], ['x', '✕ Fermer']);
    menu.innerHTML = '<div class="exb-fm-t">' + (anchor === hub ? 'Boutons rapides' : (anchor.getAttribute('data-exb-name') || 'Bouton')) + '</div>' +
      rows.map(function (r) { return '<button type="button" data-a="' + r[0] + '">' + r[1] + '</button>'; }).join('');
    d.body.appendChild(menu);
    var a = area(), r = anchor.getBoundingClientRect(), mw = menu.offsetWidth, mh = menu.offsetHeight;
    var x = clamp(r.left + r.width / 2 - mw / 2, a.l, Math.max(a.l, a.r - mw)), below = (r.top + r.height / 2) < (a.t + a.b) / 2;
    var y = below ? r.bottom + GAP : r.top - mh - GAP;
    menu.style.left = Math.round(x) + 'px'; menu.style.top = Math.round(clamp(y, a.t, Math.max(a.t, a.b - mh))) + 'px';
    menu.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('button[data-a]'); if (!b) return;
      var act = b.getAttribute('data-a'); closeMenu();
      if (act === 'group') { st.mode = 'group'; open = true; }
      else if (act === 'free') { st.mode = 'free'; st.mini = false; open = false; }
      else if (act === 'mini') { st.mode = 'group'; st.mini = true; open = false; }
      else if (act === 'maxi') { st.mini = false; }
      else if (act === 'one') { delete st.pos[id]; var t = id === 'hub' ? hub : items[id]; if (t) unplace(t); }
      else if (act === 'all') resetAll();
      save(); render();
    });
  }
  function resetAll() {
    st.mode = 'free'; st.mini = false; st.pos = {}; open = false;
    for (var k in items) { unplace(items[k]); shift(items[k], 0, 0); }
    removeHub(); save();
  }

  function tip() {
    try { if (typeof w.notify === 'function') w.notify('💡 Astuce : maintenez un bouton flottant pour le déplacer, le regrouper ou le réduire en petite icône.', 'ok', 7000); } catch (e) {}
  }

  /* ---------- carte de réglages (Paramètres) ---------- */
  function settingsCard() {
    var s = d.getElementById('settings'); if (!s) return;
    var box = d.getElementById('exbFabBox');
    if (!box) { box = d.createElement('div'); box.id = 'exbFabBox'; box.className = 'pgroup'; var m = d.getElementById('setmsg'); if (m && m.parentNode) m.parentNode.insertBefore(box, m); else s.appendChild(box); }
    box.innerHTML = '<b class="pgtitle">🧲 Boutons flottants</b>' +
      '<div class="hint">Maintenez un bouton flottant (🤖 🔑 ❓…) puis glissez-le où vous voulez. La position est mémorisée et les boutons s’écartent des champs de saisie.</div>' +
      '<label style="display:block;margin:8px 0"><input type="radio" name="exbFabMode" value="free"' + (st.mode === 'free' ? ' checked' : '') + '> Boutons séparés (déplaçables)</label>' +
      '<label style="display:block;margin:8px 0"><input type="radio" name="exbFabMode" value="group"' + (st.mode === 'group' ? ' checked' : '') + '> Regroupés dans un menu flottant ⊞ (rétractable)</label>' +
      '<label style="display:block;margin:8px 0"><input type="checkbox" id="exbFabMini"' + (st.mini ? ' checked' : '') + (st.mode === 'group' ? '' : ' disabled') + '> Réduire le menu en petite icône</label>' +
      '<div class="actions"><button type="button" class="muted" id="exbFabReset">↺ Remettre les boutons par défaut</button></div>';
    Array.prototype.forEach.call(box.querySelectorAll('input[name=exbFabMode]'), function (r) {
      r.onchange = function () { st.mode = r.value; if (st.mode === 'free') st.mini = false; open = false; save(); render(); settingsCard(); };
    });
    box.querySelector('#exbFabMini').onchange = function () { st.mini = this.checked; save(); render(); };
    box.querySelector('#exbFabReset').onclick = function () { resetAll(); render(); settingsCard(); };
  }

  /* ---------- styles ---------- */
  function css() {
    if (d.getElementById('exbFabCss')) return;
    var s = d.createElement('style'); s.id = 'exbFabCss';
    s.textContent =
      '.exb-fab{transform:translate(var(--exb-dx,0px),var(--exb-dy,0px)) scale(var(--exb-s,1));transition:transform .16s,opacity .16s;-webkit-tap-highlight-color:transparent;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}' +
      '.exb-fab-drag{--exb-s:1.14;transition:none!important;box-shadow:0 10px 28px #0007!important;opacity:.95;z-index:100030!important;cursor:grabbing}' +
      '.exb-fab-pick{--exb-s:1.1;box-shadow:0 0 0 4px #c49a3866,0 8px 22px #0006!important}' +
      '.exb-fab-off{display:none!important}' +
      '.exb-fab-typing{opacity:.12!important;pointer-events:none!important}' +
      '.exb-fab-dragging,.exb-fab-dragging *{user-select:none!important;-webkit-user-select:none!important;cursor:grabbing!important}' +
      '.exb-fab-stack{z-index:100021!important;animation:exbFabIn .16s ease-out}' +
      '@keyframes exbFabIn{from{opacity:0;--exb-s:.6}to{opacity:1}}' +
      '.exb-fab-stack::after{content:attr(data-exb-name);position:absolute;top:50%;transform:translateY(-50%);white-space:nowrap;background:#0f2e66;color:#fff;font:600 12px system-ui,Arial,sans-serif;padding:5px 9px;border-radius:8px;box-shadow:0 2px 8px #0004;pointer-events:none}' +
      '.exb-nolbl.exb-fab-stack::after{display:none}' +
      '.exb-lbl-r.exb-fab-stack::after{left:calc(100% + 8px)}.exb-lbl-l.exb-fab-stack::after{right:calc(100% + 8px)}' +
      '#exbFabHub{position:fixed;right:14px;bottom:150px;z-index:100022;width:48px;height:48px;border-radius:50%;border:0;background:#173565;color:#fff;font:700 24px/1 system-ui,Arial,sans-serif;padding:0;box-shadow:0 4px 14px #0005;cursor:pointer;display:flex;align-items:center;justify-content:center}' +
      '#exbFabHub.exb-hub-open{background:#c49a38}' +
      '#exbFabHub.exb-hub-mini{width:26px;height:26px;font-size:14px;opacity:.62}' +
      '#exbFabHub.exb-hub-mini.exb-hub-open{opacity:1}' +
      '#exbFabMenu{position:fixed;z-index:100040;background:#fff;color:#172033;border-radius:14px;box-shadow:0 12px 36px #0006;padding:6px;min-width:230px;max-width:calc(100vw - 16px);font:14px system-ui,Arial,sans-serif}' +
      '#exbFabMenu .exb-fm-t{font-weight:700;padding:8px 10px 6px;color:#173565}' +
      '#exbFabMenu button{display:block;width:100%;text-align:left;background:none;border:0;border-radius:9px;padding:11px 10px;font:inherit;color:inherit;cursor:pointer;min-height:44px}' +
      '#exbFabMenu button:active,#exbFabMenu button:hover{background:#eef2f9}' +
      '#exbV97Badge{pointer-events:none}' +
      '@media print{.exb-fab,#exbFabHub,#exbFabMenu{display:none!important}}';
    d.head.appendChild(s);
  }

  /* ---------- démarrage ---------- */
  function outsideClose(e) {
    var t = e.target;
    if (menu && !menu.contains(t)) closeMenu();
    if (open && hub && !hub.contains(t) && !(t.closest && t.closest('.exb-fab-stack'))) setOpen(false);
  }
  function start() {
    css();
    d.addEventListener('pointerdown', outsideClose, true);
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && (closeMenu() || (open && (setOpen(false) || true)))) e.stopPropagation(); }, true);
    d.addEventListener('focusin', function () { w.setTimeout(soon, 60); w.setTimeout(soon, 350); });
    d.addEventListener('focusout', function () { w.setTimeout(soon, 120); });
    w.addEventListener('resize', soon); w.addEventListener('orientationchange', function () { w.setTimeout(soon, 250); });
    if (w.visualViewport) { w.visualViewport.addEventListener('resize', soon); w.visualViewport.addEventListener('scroll', soon); }
    try { new MutationObserver(soon).observe(d.body, { childList: true }); } catch (e) {}
    try {
      var s = d.getElementById('settings');
      if (s) new MutationObserver(function () { if (s.style.display !== 'none') settingsCard(); }).observe(s, { attributes: true, attributeFilter: ['style'] });
    } catch (e) {}
    w.setInterval(soon, 2500);
    render();
  }

  w.EXB_FAB = {
    state: function () { return JSON.parse(JSON.stringify(st)); },
    setMode: function (m) { st.mode = m === 'group' ? 'group' : 'free'; if (st.mode === 'free') st.mini = false; open = false; save(); render(); },
    setMini: function (v) { st.mini = !!v; save(); render(); },
    reset: function () { resetAll(); render(); },
    render: render,
    isOpen: function () { return !!open; },
    /* fermeture de ce qui est ouvert, dans l'ordre : menu d'options, puis menu regroupé. Renvoie true si quelque chose a été fermé. */
    closeTop: function () { if (closeMenu()) return true; if (open) { setOpen(false); return true; } return false; }
  };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
