# V99 — LIAISON, tranche 2 : Formation + TFL

Fichiers ajoutés : `exb-liaison-edu.js` (+ `tools/test-liaison-edu.js`, `tools/e2e-liaison-edu.py`). Modifiés : `exb-liaison.js` (points d'extension, listes en mémoire des écrans formation), `index.html` (1 balise), `sw.js` (cache), `tools/check.js`. **Aucun SQL. Aucune donnée existante modifiée ou supprimée : seuls des identifiants sont ajoutés.**

## Formation
- Participants, paiements, reçus et certificats reçoivent leur `formation_id` / `participant_id` (nom + formation, matricule). Aucun lien n'est deviné si plusieurs candidats.
- **Rapprochement reçu ↔ paiement** : seulement s'il y a un seul paiement du même participant et du même montant (`payment_id` / `receipt_no`). Sinon rien n'est forcé.
- **Aucun versement fictif** : un reçu sans paiement enregistré n'ajoute rien au « versé » ; il est signalé (« enregistrez le paiement dans Finances »).
- Situation par participant : prix, versé, solde, statut calculé (soldé / moitié / partiel / non payé) ; totaux attendu/versé/solde par formation dans le panneau Direction.
- **Certificat** : si le participant a un solde impayé, une confirmation est demandée avant de le délivrer (refus respecté ; aucun blocage si vous confirmez). Les certificats déjà émis ne sont jamais modifiés.
- Alertes (panneau Direction) : paiement sans participant, reçu non rattaché ou sans paiement, certificat délivré avec solde, statut « payé » saisi à la main incohérent avec les montants, participant dont la formation n'est pas au catalogue, formation inscrite sans prix, participants en double (même téléphone/e-mail).

## TFL
- Étudiant TFL ↔ participant (même matricule, ou même téléphone/e-mail même écrit différemment) : `participant_id` / `tfl_etudiant_id`.
- Encadreur TFL ↔ formateur / personnel (même téléphone ou e-mail) : `trainer_id` / `hr_id`.
- Alertes : dossier sans étudiant ou avec encadreur introuvable, dossier refusé encore affecté, encadreur au-delà de sa charge maximale, matricule porté par deux étudiants ou par deux personnes différentes, dossier accepté dont l'étudiant doit encore de l'argent.
- Le TFL gérait déjà en interne l'affectation (statut, historique, charge de l'encadreur) : ces mécanismes ne sont pas touchés.

## Tests
- `node tools/check.js` : 463 contrôles réussis, 0 échec.
- `node tools/test-liaison-edu.js` : 31 contrôles. `python3 tools/e2e-liaison-edu.py` : parcours réel dans Chromium (formation, participant, 3 paiements, certificat refusé puis confirmé, lien TFL, panneau direction) : tout OK.
- `tools/test-tfl/test-portail.js` et `test-suivi.js` **échouaient déjà dans l'archive d'origine** (mêmes erreurs, avant ces modifications) : non corrigés ici.
- Le test navigateur a fait corriger deux défauts de ma version : 34 alertes parasites « prix non renseigné » (le catalogue contient 35 formations à prix 0) et un test mal posé (l'application bloque déjà les certificats de participants non approuvés).

## NON fait / limites
- Résultats, notes, cotations, TP/TD, examens, présences et planning de formation ne sont pas reliés dans cette tranche.
- Pas de devise dans les fiches de formation/paiements : montants affichés sans devise (à confirmer). Les paiements de formation ne sont pas mélangés aux encaissements de chantier.
- Les statuts « payé / moitié » saisis à la main (suivi des paiements des apprenants) ne sont pas écrasés : un écart est seulement signalé.
- Un reçu sans montant exploitable (champ texte libre) n'est pas rapproché.
- Non testé sur un vrai Supabase ni sur plusieurs vrais appareils.
