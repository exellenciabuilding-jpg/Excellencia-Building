/* Excellencia Building V99zj — Marchés & décomptes mensuels (audit interne : « Marchés et décomptes », priorité P1).
 * Marché lié au DQE → décompte mensuel par quantités cumulées → avance de démarrage, retenue de garantie, révision de prix,
 * pénalités de retard, TVA, net à payer ; cautions et garanties avec alertes d'expiration.
 * TOUS LES TAUX PAR DÉFAUT SONT À CONFIRMER PAR CONTRAT (marché, CCAP) ET PAR L'EXPERT-COMPTABLE : ils sont modifiables marché par marché. */
(function(root){'use strict';
var DEF={avance_pct:15,remb_debut_pct:0,retenue_pct:5,tva_pct:16,pen_taux_jour_pct:0.1,pen_plafond_pct:10,rev_actif:false,rev_a:0.15,rev_b:0.5,rev_c:0.35};
var r2=function(x){return Math.round((+x||0)*100+ (x<0?-1e-9:1e-9))/100};
var N=function(x){x=+x;return isFinite(x)?x:0};
function params(m){var p={};for(var k in DEF)p[k]=(m&&m.params&&m.params[k]!==undefined&&m.params[k]!=='')?(typeof DEF[k]==='boolean'?!!m.params[k]:N(m.params[k])):DEF[k];return p}
function montant(m){return r2((m.postes||[]).reduce(function(a,x){return a+N(x.qte)*N(x.pu)},0))}
function cumulTravaux(m,d){return r2((m.postes||[]).reduce(function(a,x){return a+N((d.cumul||{})[x.id])*N(x.pu)},0))}
/* calcule tous les décomptes du marché, dans l'ordre ; retourne [{…}] */
function calc(m){
  var P=params(m),M=montant(m),av=r2(M*P.avance_pct/100),out=[],prev={tr:0,rev:0,rg:0,remb:0,pen:0};
  var i1=N(m.idx&&m.idx.i1_0)||0,i2=N(m.idx&&m.idx.i2_0)||0;
  (m.decomptes||[]).forEach(function(d,k){
    var tr=cumulTravaux(m,d),trMois=r2(tr-prev.tr);
    var K=1;if(P.rev_actif&&i1>0&&i2>0&&N(d.i1)>0&&N(d.i2)>0)K=P.rev_a+P.rev_b*N(d.i1)/i1+P.rev_c*N(d.i2)/i2;
    var revMois=r2(trMois*(K-1)),revCum=r2(prev.rev+revMois);
    var base=r2(trMois+revMois),tva=r2(base*P.tva_pct/100),ttc=r2(base+tva);
    var avancement=M>0?tr/M:0;
    var rgCum=r2((tr+revCum)*P.retenue_pct/100),rgMois=r2(rgCum-prev.rg);
    var rembCum=avancement*100>=P.remb_debut_pct?r2(Math.min(av,av*avancement)):0,rembMois=r2(rembCum-prev.remb);
    var penCum=r2(Math.min(M*P.pen_plafond_pct/100,N(d.retard_jours)*P.pen_taux_jour_pct/100*M)),penMois=r2(penCum-prev.pen);
    var net=r2(ttc-rgMois-rembMois-penMois);
    var o={num:k+1,id:d.id,travauxCumul:tr,travauxMois:trMois,coefRevision:K,revisionMois:revMois,baseHT:base,tva:tva,ttc:ttc,
      avancementPct:r2(avancement*100),retenueMois:rgMois,retenueCumul:rgCum,remboursementAvanceMois:rembMois,remboursementAvanceCumul:rembCum,
      penalitesMois:penMois,penalitesCumul:penCum,netAPayer:net,depasse:(m.postes||[]).some(function(x){return N((d.cumul||{})[x.id])>N(x.qte)+1e-9})};
    out.push(o);prev={tr:tr,rev:revCum,rg:rgCum,remb:rembCum,pen:penCum}});
  return {montantMarche:M,avanceMontant:av,params:P,lignes:out}}
/* état d'une caution : 'expiree' | 'bientot' (≤ 30 j) | 'valide' | 'levee' */
function etatCaution(c,today){if(c.levee)return'levee';if(!c.expiration)return'valide';var t=new Date((today||new Date().toISOString().slice(0,10))+'T00:00:00'),e=new Date(c.expiration+'T00:00:00'),j=Math.round((e-t)/864e5);return j<0?'expiree':(j<=30?'bientot':'valide')}
/* retenue de garantie : cumul retenu sur les décomptes, libérations (réception provisoire / définitive / remplacement par caution), solde encore retenu */
function retenueSolde(m){var c=calc(m),last=c.lignes.length?c.lignes[c.lignes.length-1].retenueCumul:0,lib=r2((m.liberations||[]).reduce(function(a,x){return a+N(x.montant)},0));return {cumul:last,libere:lib,solde:r2(last-lib)}}
var ENG={retenueSolde:retenueSolde,DEF:DEF,params:params,montant:montant,calc:calc,etatCaution:etatCaution,r2:r2};
root.EXBDEC_CALC=ENG;if(typeof module!=='undefined'&&module.exports)module.exports=ENG;
if(typeof document==='undefined')return;

/* ============================== INTERFACE ============================== */
var K='exb_decomptes',$=function(i){return document.getElementById(i)},ST={tab:'m',pid:'',dec:''};
var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var fx=function(x){return N(x).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2}).replace(/[\u202f\u00a0]/g,' ')};
var say=function(t,k){try{notify(t,k||'info',4500)}catch(e){alert(t)}};
var L=function(){try{return load(K,[])}catch(e){return[]}},S=function(a){save(K,a)};
var projs=function(){return typeof exbProjects!=='undefined'?exbProjects:[]},proj=function(id){return projs().filter(function(p){return p.id===id})[0]};
var uid=function(p){return p+'_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)};
var today=function(){return new Date().toISOString().slice(0,10)};
function M(){var a=L(),m=a.filter(function(x){return x.project_id===ST.pid})[0];return m}
function put(m){var a=L(),i=a.findIndex(function(x){return x.id===m.id});if(i>=0)a[i]=m;else a.push(m);S(a)}
function ensure(){var m=M();if(!m&&ST.pid){m={id:uid('MAR'),project_id:ST.pid,intitule:'',params:{},postes:[],decomptes:[],cautions:[],idx:{}};put(m)}return m}
var DEVISE=function(){var p=proj(ST.pid);return(p&&p.currency)||'USD'};
function inp(v,fn,type,w){return '<input '+(type==='number'?'type="number" step="any" ':'')+'value="'+esc(v)+'" onchange="EXBDEC.'+fn+'" style="width:'+(w||'100%')+'">'}
function pct(k,label,help){var m=ensure(),P=params(m);return '<label style="display:block"><small>'+label+' <b style="color:#b45309">à confirmer par contrat</b></small>'+inp(P[k],"par('"+k+"',this.value)",'number')+(help?'<small class="exb-muted">'+help+'</small>':'')+'</label>'}

function tabs(){return '<div class="tabs" style="margin:8px 0">'+[['m','Marché & DQE'],['d','Décomptes'],['c','Cautions'],['x','Méthode']].map(function(t){return '<button class="'+(ST.tab===t[0]?'':'muted')+'" onclick="EXBDEC.tab(\''+t[0]+'\')">'+t[1]+'</button>'}).join('')+'</div>'}
function vMarche(){var m=ensure(),P=params(m),tot=montant(m);
  var h='<div class="card" style="background:#fff7ed;border:1px solid #fdba74;margin:8px 0"><b>⚠ Valeurs par défaut à confirmer par contrat.</b> Avance, retenue de garantie, TVA, pénalités et révision sont des valeurs de départ modifiables ci-dessous ; elles doivent correspondre au marché (CCAP) et être validées par l\'expert-comptable.</div>';
  h+='<label>Intitulé du marché</label>'+inp(m.intitule,"set('intitule',this.value)");
  h+='<h3>Conditions du marché</h3><div class="two" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">'
   +pct('avance_pct','Avance de démarrage (% du marché)')+pct('remb_debut_pct','Remboursement dès avancement (%)','0 = dès le 1er décompte, au prorata de l\'avancement')
   +pct('retenue_pct','Retenue de garantie (%)')+pct('tva_pct','TVA (%)','0 si exonéré')
   +pct('pen_taux_jour_pct','Pénalité par jour de retard (% du marché)')+pct('pen_plafond_pct','Plafond des pénalités (% du marché)')+'</div>';
  h+='<label style="display:block;margin-top:8px"><input type="checkbox" '+(P.rev_actif?'checked':'')+' onchange="EXBDEC.par(\'rev_actif\',this.checked)"> Révision de prix  <b style="color:#b45309;font-size:12px">à confirmer par contrat</b></label>';
  if(P.rev_actif)h+='<div class="two" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px"><label><small>Part fixe a</small>'+inp(P.rev_a,"par('rev_a',this.value)",'number')+'</label><label><small>Part main-d\'œuvre b</small>'+inp(P.rev_b,"par('rev_b',this.value)",'number')+'</label><label><small>Part matériaux c</small>'+inp(P.rev_c,"par('rev_c',this.value)",'number')+'</label><label><small>Indice MO de base I₁₀</small>'+inp((m.idx||{}).i1_0||'',"idx('i1_0',this.value)",'number')+'</label><label><small>Indice matériaux de base I₂₀</small>'+inp((m.idx||{}).i2_0||'',"idx('i2_0',this.value)",'number')+'</label></div><small class="exb-muted">K = a + b·I₁/I₁₀ + c·I₂/I₂₀ (a+b+c doit valoir 1)'+(Math.abs(P.rev_a+P.rev_b+P.rev_c-1)>0.001?' — <b style="color:#b91c1c">a+b+c = '+(P.rev_a+P.rev_b+P.rev_c).toFixed(3)+' ≠ 1</b>':'')+'</small>';
  h+='<h3>Postes du marché (DQE)</h3><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse"><tr><th>Code</th><th>Désignation</th><th>Unité</th><th>Quantité</th><th>P.U. HT</th><th>Montant HT</th><th></th></tr>'
   +m.postes.map(function(x,i){return '<tr><td>'+inp(x.code,"pst("+i+",'code',this.value)",'',"60px")+'</td><td>'+inp(x.des,"pst("+i+",'des',this.value)")+'</td><td>'+inp(x.unite,"pst("+i+",'unite',this.value)",'',"55px")+'</td><td>'+inp(x.qte,"pst("+i+",'qte',this.value)",'number',"85px")+'</td><td>'+inp(x.pu,"pst("+i+",'pu',this.value)",'number',"95px")+'</td><td style="text-align:right;white-space:nowrap">'+fx(N(x.qte)*N(x.pu))+'</td><td><button class="muted" onclick="EXBDEC.delP('+i+')">✕</button></td></tr>'}).join('')
   +'<tr><td colspan="5" style="text-align:right"><b>Montant du marché HT</b></td><td style="text-align:right;white-space:nowrap"><b>'+fx(tot)+'</b></td><td></td></tr></table></div>'
   +'<div style="margin-top:8px"><button onclick="EXBDEC.addP()">＋ Poste</button> <button class="muted" onclick="EXBDEC.impDqe()">📥 Importer le DQE du projet</button></div>';
  return h}
function dcur(m){return(m.decomptes||[]).filter(function(d){return d.id===ST.dec})[0]}
function vDecomptes(){var m=ensure(),c=calc(m),h='';
  if(!m.postes.length)return '<p class="exb-muted">Renseignez d\'abord les postes du marché (onglet « Marché & DQE »).</p>';
  h+='<button onclick="EXBDEC.newD()">＋ Nouveau décompte</button>';
  h+='<div style="overflow-x:auto;margin-top:8px"><table style="width:100%;border-collapse:collapse"><tr><th>N°</th><th>Date</th><th>Avancement</th><th>Travaux du mois</th><th>Net à payer</th><th>Statut</th><th></th></tr>'
   +c.lignes.map(function(l,i){var d=m.decomptes[i];return '<tr><td>'+l.num+'</td><td>'+esc(d.date||'')+'</td><td>'+l.avancementPct+' %'+(l.depasse?' ⚠':'')+'</td><td style="text-align:right;white-space:nowrap">'+fx(l.travauxMois)+'</td><td style="text-align:right;white-space:nowrap"><b>'+fx(l.netAPayer)+'</b></td><td>'+(d.valide?'✅ Validé':'📝 Brouillon')+'</td><td><button class="muted" onclick="EXBDEC.open(\''+esc(d.id)+'\')">Ouvrir</button></td></tr>'}).join('')+'</table></div>';
  var rs=retenueSolde(m),LIB=['Réception provisoire','Réception définitive','Remplacement par une caution'];
  h+='<h3>Retenue de garantie</h3><div class="exb-grid"><div class="exb-card"><b>'+fx(rs.cumul)+'</b><br><small>Retenue cumulée</small></div><div class="exb-card"><b>'+fx(rs.libere)+'</b><br><small>Déjà libérée</small></div><div class="exb-card"><b style="color:'+(rs.solde>0?'#b45309':'#15803d')+'">'+fx(rs.solde)+'</b><br><small>Encore retenue</small></div></div>';
  h+=(m.liberations||[]).map(function(x,i){return '<div style="border-top:1px solid #e5e7eb;padding:4px 0">'+esc(x.date||'')+' — '+esc(x.motif)+' : <b>'+fx(x.montant)+'</b> <button class="muted" onclick="EXBDEC.delLib('+i+')">✕</button></div>'}).join('');
  if(rs.solde>0.004)h+='<div class="exb-actions" style="align-items:end;margin-top:6px"><div><label>Motif</label><select id="exbdec_lm">'+LIB.map(function(x){return '<option>'+x+'</option>'}).join('')+'</select></div><div><label>Montant à libérer</label><input id="exbdec_la" type="number" step="any" value="'+rs.solde+'" style="width:130px"></div><button onclick="EXBDEC.lib()">Libérer</button></div><small class="exb-muted">La libération est à payer à l\'entreprise ; elle suppose en général la levée des réserves. À confirmer par contrat.</small>';
  var d=dcur(m);if(d){var i=m.decomptes.indexOf(d),l=c.lignes[i],P=c.params,dev=DEVISE(),lock=d.valide?' disabled':'';
   h+='<h3>Décompte n° '+l.num+(d.valide?' — validé (verrouillé)':'')+'</h3><div class="two" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px"><label><small>Date</small><input type="date" value="'+esc(d.date||'')+'"'+lock+' onchange="EXBDEC.dset(\'date\',this.value)"></label><label><small>Période</small><input value="'+esc(d.periode||'')+'"'+lock+' placeholder="ex. Octobre 2026" onchange="EXBDEC.dset(\'periode\',this.value)"></label><label><small>Jours de retard cumulés</small><input type="number" value="'+esc(d.retard_jours||0)+'"'+lock+' onchange="EXBDEC.dset(\'retard_jours\',this.value)"></label>'
    +(P.rev_actif?'<label><small>Indice MO du mois I₁</small><input type="number" step="any" value="'+esc(d.i1||'')+'"'+lock+' onchange="EXBDEC.dset(\'i1\',this.value)"></label><label><small>Indice matériaux du mois I₂</small><input type="number" step="any" value="'+esc(d.i2||'')+'"'+lock+' onchange="EXBDEC.dset(\'i2\',this.value)"></label>':'')+'</div>';
   var prevD=i>0?m.decomptes[i-1]:null;
   h+='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse"><tr><th>Poste</th><th>Qté marché</th><th>Cumul précédent</th><th>Cumul à ce jour</th><th>%</th><th>Montant cumulé</th></tr>'
    +m.postes.map(function(x){var cu=N((d.cumul||{})[x.id]),pv=prevD?N((prevD.cumul||{})[x.id]):0;return '<tr><td>'+esc(x.code||'')+' '+esc(x.des||'')+'</td><td style="text-align:right;white-space:nowrap">'+fx(x.qte)+' '+esc(x.unite||'')+'</td><td style="text-align:right;white-space:nowrap">'+fx(pv)+'</td><td><input type="number" step="any" value="'+esc(cu)+'"'+lock+' style="width:95px'+(cu>N(x.qte)+1e-9?';background:#fee2e2':'')+'" onchange="EXBDEC.cum(\''+esc(x.id)+'\',this.value)"></td><td style="text-align:right;white-space:nowrap">'+(N(x.qte)>0?fx(cu/N(x.qte)*100):'—')+'</td><td style="text-align:right;white-space:nowrap">'+fx(cu*N(x.pu))+'</td></tr>'}).join('')+'</table></div>';
   var row=function(a,b,s){return '<tr'+(s?' style="font-weight:700;background:#eef2fa"':'')+'><td>'+a+'</td><td style="text-align:right;white-space:nowrap">'+b+'</td></tr>'};
   h+='<h3>Calcul du décompte</h3><table style="width:100%;border-collapse:collapse;max-width:560px">'
    +row('Travaux cumulés HT',fx(l.travauxCumul))+row('Travaux du mois HT',fx(l.travauxMois))
    +(P.rev_actif?row('Révision de prix (K = '+l.coefRevision.toFixed(4)+')',fx(l.revisionMois)):'')
    +row('Montant HT du mois',fx(l.baseHT),1)+row('TVA '+P.tva_pct+' %',fx(l.tva))+row('Montant TTC',fx(l.ttc),1)
    +row('− Retenue de garantie '+P.retenue_pct+' % (cumul '+fx(l.retenueCumul)+')',fx(l.retenueMois))
    +row('− Remboursement de l\'avance (avance '+fx(c.avanceMontant)+', cumul '+fx(l.remboursementAvanceCumul)+')',fx(l.remboursementAvanceMois))
    +row('− Pénalités de retard (cumul '+fx(l.penalitesCumul)+')',fx(l.penalitesMois))
    +row('NET À PAYER ('+dev+')',fx(l.netAPayer),1)+'</table>';
   if(l.depasse)h+='<p style="color:#b91c1c">⚠ Une quantité cumulée dépasse la quantité du marché : vérifier (avenant ou erreur de saisie).</p>';
   h+='<div style="margin-top:8px"><button onclick="EXBDEC.pdf()">📄 PDF</button> '+(d.valide?'<button class="muted" onclick="EXBDEC.unval()">Rouvrir</button>':'<button onclick="EXBDEC.val()">✅ Valider (verrouiller)</button>')+' <button class="muted" onclick="EXBDEC.delD()">🗑 Supprimer</button></div>'}
  return h}
function vCautions(){var m=ensure(),c=calc(m),dev=DEVISE(),
  lbl={expiree:['⛔ Expirée','#b91c1c'],bientot:['⚠ Expire sous 30 j','#b45309'],valide:['✓ Valide','#15803d'],levee:['Levée','#6b7280']};
  var h='<p class="exb-muted">Caution d\'avance, de bonne exécution, de retenue de garantie… Les alertes se basent sur la date d\'expiration.</p>';
  h+='<button onclick="EXBDEC.addC(\'Avance de démarrage\','+c.avanceMontant+')">＋ Caution d\'avance ('+fx(c.avanceMontant)+')</button> <button class="muted" onclick="EXBDEC.addC(\'Bonne exécution\',0)">＋ Bonne exécution</button> <button class="muted" onclick="EXBDEC.addC(\'Retenue de garantie\',0)">＋ Autre</button>';
  h+='<div style="overflow-x:auto;margin-top:8px"><table style="width:100%;border-collapse:collapse"><tr><th>Type</th><th>Montant</th><th>Banque / assureur</th><th>Référence</th><th>Émission</th><th>Expiration</th><th>État</th><th></th></tr>'
   +(m.cautions||[]).map(function(x,i){var e=lbl[etatCaution(x)];return '<tr><td>'+inp(x.type,"cau("+i+",'type',this.value)",'',"130px")+'</td><td>'+inp(x.montant,"cau("+i+",'montant',this.value)",'number',"100px")+'</td><td>'+inp(x.banque,"cau("+i+",'banque',this.value)",'',"120px")+'</td><td>'+inp(x.ref,"cau("+i+",'ref',this.value)",'',"90px")+'</td><td><input type="date" value="'+esc(x.emission||'')+'" onchange="EXBDEC.cau('+i+',\'emission\',this.value)"></td><td><input type="date" value="'+esc(x.expiration||'')+'" onchange="EXBDEC.cau('+i+',\'expiration\',this.value)"></td><td style="color:'+e[1]+'"><b>'+e[0]+'</b><br><label style="font-size:12px"><input type="checkbox" '+(x.levee?'checked':'')+' onchange="EXBDEC.cau('+i+',\'levee\',this.checked)"> levée</label></td><td><button class="muted" onclick="EXBDEC.delC('+i+')">✕</button></td></tr>'}).join('')+'</table></div>';
  return h}
function vMethode(){return '<div style="line-height:1.5"><p><b>Méthode de calcul (modifiable marché par marché).</b></p><ul><li><b>Travaux cumulés</b> = Σ (quantité cumulée × prix unitaire). <b>Travaux du mois</b> = cumul − cumul du décompte précédent.</li><li><b>Révision</b> (optionnelle) : travaux du mois × (K − 1), K = a + b·I₁/I₁₀ + c·I₂/I₂₀.</li><li><b>Montant HT</b> = travaux du mois + révision ; <b>TVA</b> = taux × montant HT ; <b>TTC</b> = HT + TVA.</li><li><b>Retenue de garantie</b> = taux × (travaux cumulés + révision cumulée) − retenue déjà opérée.</li><li><b>Avance</b> = % du marché, versée au démarrage ; <b>remboursée au prorata de l\'avancement</b> (cumul = avance × avancement), sans dépasser l\'avance.</li><li><b>Pénalités</b> = jours de retard cumulés × taux par jour × montant du marché, plafonnées ; seule la différence avec le décompte précédent est retenue.</li><li><b>Net à payer</b> = TTC − retenue du mois − remboursement d\'avance du mois − pénalités du mois.</li></ul><p class="exb-muted">Les retenues sont déduites du TTC à leur montant HT calculé ci-dessus ; si votre marché prévoit une autre base (retenue sur TTC, TVA sur avance…), ajustez les taux ou faites valider la méthode par votre expert-comptable. Un décompte validé est verrouillé.</p></div>'}
function render(){var b=$('exbdec_box');if(!b)return;
  var h='<label>Chantier</label><select onchange="EXBDEC.pick(this.value)"><option value="">— Choisir un chantier —</option>'+projs().map(function(p){return '<option value="'+esc(p.id)+'"'+(p.id===ST.pid?' selected':'')+'>'+esc(p.name)+'</option>'}).join('')+'</select>';
  if(!ST.pid)h+='<p class="exb-muted">Choisissez un chantier pour gérer son marché, ses décomptes et ses cautions.</p>';
  else{var m=ensure(),al=(m.cautions||[]).filter(function(x){var e=etatCaution(x);return e==='expiree'||e==='bientot'}).length;
   if(al)h+='<p style="color:#b91c1c;margin:6px 0"><b>⚠ '+al+' caution(s) expirée(s) ou proche(s) de l\'expiration.</b></p>';
   h+=tabs()+(ST.tab==='m'?vMarche():ST.tab==='d'?vDecomptes():ST.tab==='c'?vCautions():vMethode())}
  b.innerHTML=h}
var A={
 pick:function(v){ST.pid=v;ST.dec='';render()},tab:function(t){ST.tab=t;render()},
 set:function(k,v){var m=M();m[k]=v;put(m)},
 par:function(k,v){var m=M();m.params=m.params||{};m.params[k]=(typeof v==='boolean')?v:v;put(m);render()},
 idx:function(k,v){var m=M();m.idx=m.idx||{};m.idx[k]=v;put(m)},
 pst:function(i,k,v){var m=M();m.postes[i][k]=(k==='qte'||k==='pu')?N(v):v;put(m);render()},
 addP:function(){var m=M();m.postes.push({id:uid('P'),code:String(m.postes.length+1),des:'',unite:'u',qte:0,pu:0});put(m);render()},
 delP:function(i){var m=M();if(!confirm('Supprimer ce poste ?'))return;m.postes.splice(i,1);put(m);render()},
 impDqe:function(){var m=M(),p=proj(ST.pid),all=[];try{all=load('exb_dqe',[])}catch(e){}
  var nm=(p&&p.name||'').trim().toLowerCase(),rows=all.filter(function(x){var q=String(x.project||'').trim().toLowerCase();return q&&(q===nm||q===String(ST.pid).toLowerCase())});
  if(!rows.length)return say('Aucune ligne de DQE trouvée pour ce chantier (le champ « Projet » du DQE doit porter le nom du chantier).','warn');
  if(m.postes.length&&!confirm('Ajouter '+rows.length+' ligne(s) du DQE aux postes existants ?'))return;
  rows.forEach(function(x,i){m.postes.push({id:uid('P'),code:x.ref||String(m.postes.length+1),des:x.designation||'',unite:x.unit||'u',qte:N(x.qty),pu:N(x.pu)})});put(m);render();say(rows.length+' ligne(s) importée(s).','success')},
 newD:function(){var m=M(),last=m.decomptes[m.decomptes.length-1];if(last&&!last.valide&&!confirm('Le dernier décompte n\'est pas validé. En créer un nouveau quand même ?'))return;
  var d={id:uid('DEC'),date:today(),periode:'',retard_jours:last?last.retard_jours:0,cumul:Object.assign({},last?last.cumul:{}),valide:false,i1:'',i2:''};m.decomptes.push(d);put(m);ST.dec=d.id;render()},
 open:function(id){ST.dec=(ST.dec===id?'':id);render()},
 dset:function(k,v){var m=M(),d=dcur(m);if(!d||d.valide)return;d[k]=(k==='retard_jours'||k==='i1'||k==='i2')?N(v):v;put(m);render()},
 cum:function(pid,v){var m=M(),d=dcur(m);if(!d||d.valide)return;d.cumul=d.cumul||{};d.cumul[pid]=N(v);put(m);render()},
 val:function(){var m=M(),d=dcur(m);if(!d||!confirm('Valider ce décompte ? Il sera verrouillé.'))return;d.valide=true;put(m);render()},
 unval:function(){var m=M(),d=dcur(m);if(!d)return;var i=m.decomptes.indexOf(d);if(m.decomptes[i+1]&&m.decomptes[i+1].valide)return say('Rouvrez d\'abord les décomptes suivants.','warn');d.valide=false;put(m);render()},
 delD:function(){var m=M(),d=dcur(m);if(!d||d.valide||!confirm('Supprimer ce décompte ?'))return d&&d.valide&&say('Rouvrez le décompte avant de le supprimer.','warn');m.decomptes=m.decomptes.filter(function(x){return x!==d});put(m);ST.dec='';render()},
 lib:function(){var m=M(),s=retenueSolde(m),mt=N((document.getElementById('exbdec_la')||{}).value),mo=(document.getElementById('exbdec_lm')||{}).value||'Réception provisoire';if(!(mt>0))return say('Indiquez un montant à libérer.','warn');if(mt>s.solde+0.005)return say('Le montant dépasse la retenue encore détenue ('+fx(s.solde)+').','warn');m.liberations=m.liberations||[];m.liberations.push({id:uid('LIB'),date:today(),motif:mo,montant:r2(mt)});put(m);say('Retenue libérée : '+fx(mt),'success');render()},
 delLib:function(i){var m=M();if(!confirm('Supprimer cette libération ?'))return;m.liberations.splice(i,1);put(m);render()},
 addC:function(t,mt){var m=M();m.cautions=m.cautions||[];m.cautions.push({id:uid('CAU'),type:t,montant:N(mt),banque:'',ref:'',emission:today(),expiration:'',levee:false});put(m);render()},
 cau:function(i,k,v){var m=M();m.cautions[i][k]=(k==='montant')?N(v):v;put(m);render()},
 delC:function(i){var m=M();if(!confirm('Supprimer cette caution ?'))return;m.cautions.splice(i,1);put(m);render()},
 pdf:function(){var m=M(),d=dcur(m);if(!d)return;var c=calc(m),i=m.decomptes.indexOf(d),l=c.lignes[i],P=c.params,p=proj(ST.pid),dev=DEVISE();
  var rows=[['Chantier',p?p.name:'—'],['Marché',m.intitule||'—'],['Décompte n°',l.num+' — '+(d.periode||d.date||'')],['Montant du marché HT',fx(c.montantMarche)+' '+dev],['Avancement cumulé',l.avancementPct+' %'],['Travaux cumulés HT',fx(l.travauxCumul)],['Travaux du mois HT',fx(l.travauxMois)]];
  if(P.rev_actif)rows.push(['Révision de prix (K = '+l.coefRevision.toFixed(4)+')',fx(l.revisionMois)]);
  rows.push(['Montant HT du mois',fx(l.baseHT)],['TVA '+P.tva_pct+' %',fx(l.tva)],['Montant TTC',fx(l.ttc)],['Retenue de garantie '+P.retenue_pct+' %',fx(l.retenueMois)],['Remboursement de l\'avance',fx(l.remboursementAvanceMois)],['Pénalités de retard',fx(l.penalitesMois)],['NET À PAYER ('+dev+')',fx(l.netAPayer)]);
  EXBPdf.make({titre:'DÉCOMPTE N° '+l.num,sousTitre:(p?p.name:'')+' — '+(d.date||''),rows:rows,notes:['Taux appliqués : voir conditions du marché. Document de travail à faire valider par le maître d\'ouvrage.'+(d.valide?'':' (brouillon)')],footer:'Décompte — '+(p?p.name:'')+' — Excellencia Building'}).then(function(x){EXBPdf.save(x,'decompte-'+l.num+'.pdf')})}
};
root.EXBDEC=A;
function mount(){if($('decomptes'))return;var ref=$('finances')||$('chantiers'),host=document.querySelector('.wrap')||document.querySelector('main')||document.body,s=document.createElement('section');s.id='decomptes';s.style.display='none';
 s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>🧾 Marchés &amp; décomptes</h2><p class="exb-muted">Décompte mensuel lié au DQE : avance, retenue de garantie, révision de prix, pénalités, TVA, net à payer — et cautions.</p></div></div><div id="exbdec_box"></div></div>';
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
 var b=$('bfin')||$('bplan');if(b&&!$('bdec')){var n=document.createElement('button');n.id='bdec';n.textContent='🧾 Décomptes';n.setAttribute('onclick',"show('decomptes')");b.parentNode.insertBefore(n,b.nextSibling)}
 var os=window.show;if(typeof os==='function'&&!window.__exbDecShow){window.__exbDecShow=1;window.show=function(x){var r=os.apply(this,arguments),e=$('decomptes');if(e)e.style.display=(x==='decomptes')?'':'none';if(x==='decomptes')render();return r}}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(mount,900)});else setTimeout(mount,900);
})(typeof window!=='undefined'?window:globalThis);
