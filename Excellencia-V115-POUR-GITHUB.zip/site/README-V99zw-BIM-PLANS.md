# V99zw — BIM et plans

## Lecteur IFC 3D (V99zw)
Ouvre un fichier IFC (IFC2X3 / IFC4) directement dans le logiciel, **sans bibliothèque externe et hors connexion** : rotation, zoom, déplacement, clic sur un élément pour voir ses propriétés, arborescence par niveau, filtres par catégorie, isoler / masquer, coupe horizontale, vues standard, capture d'image.
**Limites connues** : révolutions, balayages et surfaces NURBS non affichés (comptés et signalés) ; les ouvertures (portes, fenêtres) ne sont pas découpées dans les murs (le mur apparaît plein).

## Plans partagés (V99zw)
Les fichiers de plans (DXF, IFC, PDF, images, DWG, RVT) sont envoyés dans un espace privé Supabase « exb-plans » (un dossier par entreprise) : toute l'équipe autorisée voit les mêmes plans, sur tous les appareils. Avant, les fichiers restaient sur l'appareil qui les avait ajoutés.
DWG et RVT restent archivés avec leurs versions (non lisibles dans un navigateur : exporter en DXF / IFC / PDF).

## Installation
1. Déployer le zip.
2. Supabase › SQL Editor : exécuter `supabase/migration-v99zw-plans-partages.sql` (une partie, réexécutable). Prérequis : V99zn, V99zo et V99zp déjà exécutés.

## Tests
`tools/test-rls` (33/33, dont le stockage des plans), `tools/test-bim/test.py` (5/5), `tools/check.js`.

## Quantités IFC (nouveau)
Bouton « 📐 Quantités » dans le lecteur 3D : tableau par niveau et par catégorie (nombre, volume net, surface totale, surface en plan, longueur, ouvertures) et export CSV (s'ouvre dans Excel).
- Les quantités **déclarées dans l'IFC** (Qto_… / BaseQuantities) sont prioritaires ; sinon elles sont **calculées sur la géométrie**.
- Le volume net **déduit les ouvertures** reliées à l'élément (portes, fenêtres).
- Les unités de surface et de volume déclarées dans l'IFC sont respectées (correction d'un affichage faux sur les fichiers en mm avec quantités en m²/m³).
- À contrôler avant tout chiffrage : surface totale = toutes les faces ; longueur = plus grande dimension (murs, poutres) ou hauteur (poteaux).
Tests : `node tools/test-bim/test-quantites.js` (9/9), `tools/test-bim/test.py` (7/7).

## Envoi des quantités vers le métré (nouveau)
Dans « 📐 Quantités » : cochez les lignes, choisissez l'unité (m³ volume net, m² surface totale ou en plan, ml, u), puis « ➕ Envoyer au métré ».
Les lignes arrivent dans **Métré béton armé › ➕ Matériaux ajoutés** (donc dans l'onglet Devis et le PDF). Saisissez ensuite le prix unitaire.
- Renvoyer la même maquette **met à jour** les lignes existantes (pas de doublon) et **conserve le prix unitaire** déjà saisi.
- Les quantités IFC n'alimentent pas les cellules du calcul béton armé paramétré (dimensions en cm) : elles s'ajoutent au devis.
Test : `tools/test-bim/test.py` (13/13).
