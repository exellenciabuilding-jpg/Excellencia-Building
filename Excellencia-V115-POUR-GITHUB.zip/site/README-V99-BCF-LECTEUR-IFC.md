# V99 — BCF, lecteur IFC complété, dégression réglable

Fichiers nouveaux : `exb-zip.js` (lecture/écriture ZIP), `exb-bcf.js` (BCF 2.1).
Fichiers modifiés : `exb-ifc3d.js`, `exb-v68.js`, `exb-v94-architecture.js`, `calcul-structure/index.html`, `index.html` (2 balises script), `sw.js` (cache), `tools/check.js`. Aucun SQL.
Tests : `node tools/test-bim/test-lecteur-geometries.js` (22), `node tools/test-bim/test-bcf.js` (26), `python3 tools/test-bim/test-bcf-ui.py` (7), `python3 tools/test-bim/test-degression.py` (6), `node tools/check.js`.

## 1. Lecteur IFC (`exb-ifc3d.js`)
- **Fichiers `.ifczip` / `.zip`** : lus directement (bouton d'ouverture du lecteur 3D). Le premier `.ifc` de l'archive (le plus volumineux s'il y en a plusieurs) est ouvert. Messages clairs pour une archive sans `.ifc`, corrompue, chiffrée ou ZIP64. Limite inchangée : 120 Mo. Le module Plans (V81) accepte toujours `.ifc` uniquement.
- **Géométries ajoutées** : extrusion conique (`IfcExtrudedAreaSolidTapered`), révolution (`IfcRevolvedAreaSolid`, angle en radians ou en degrés selon l'unité déclarée), disque balayé (`IfcSweptDiskSolid` : armatures, directrice en polyligne, polycourbe indexée avec arcs, courbe composée de polylignes), découpe par plan (`IfcBooleanClippingResult` / `IfcBooleanResult` DIFFERENCE avec `IfcHalfSpaceSolid` ou `IfcPolygonalBoundedHalfSpace`, par exemple un mur coupé par une toiture inclinée). La coupe est refermée ; les volumes des quantités sont donc exacts (vérifiés : tronc 7 m³, anneau 28,27 m³, coupe oblique 6 m³).
- **Garde-fous** : si une découpe ne peut pas être refermée proprement (trou dans la coupe, contour de demi-espace plus petit que l'élément), elle n'est pas appliquée et l'élément est signalé « apparaît plein » comme avant. Rayon intérieur d'un disque balayé ignoré (signalé).
- Toujours non pris en charge (comptés et signalés dans « Limites de cette lecture ») : BREP avancés (NURBS), profils composites, balayages autres que le disque, soustractions booléennes par un solide (hors demi-espace).

## 2. BCF 2.1 (« Priorité 2 › BIM / Issues »)
- **⬇ Exporter en BCF** : fichier `observations-bim.bcfzip` (sujets, statut, priorité, disciplines en étiquettes, responsable, description avec localisation, modèle IFC cité, point de vue avec le **GlobalId** de l'élément). Identifiants stables d'un export à l'autre.
- **⬆ Importer un BCF** : lit le BCF 2.0/2.1 d'autres logiciels (Solibri, BIMcollab, Revit…), demande confirmation, puis crée les nouvelles observations dans le projet sélectionné. Une observation déjà connue (même identifiant BCF, ou export de ce logiciel) est **mise à jour, jamais dupliquée**. Le modèle est rattaché par nom de fichier s'il existe dans « Modèles BIM ».
- Correspondance des statuts : Open/Ouvert, Assigned/Assigné, In Progress/Active → En correction, Resolved → À vérifier, Closed → Clôturé ; priorités Normal/High/Critical.
- **Limites** : pas de capture d'écran ni de caméra, pas de commentaires multiples ni de pièces jointes (point de vue limité à la sélection d'un élément) ; le BCF 3.0 n'est lu qu'au mieux. Non testé avec des fichiers réels de Revit/Solibri (essais sur des fichiers fabriqués selon le format).

## 3. Dégression des charges d'exploitation (calcul du bâtiment)
Case « Dégression des charges d'exploitation » (onglet Général). Cochée par défaut : résultats **inchangés** pour tous les bâtiments déjà enregistrés. Décochée (stockage, commerce, salle de réunion) : les charges d'exploitation de tous les niveaux sont cumulées en totalité. La note de calcul et l'avertissement des limites indiquent le choix retenu. Calculs indicatifs, à faire vérifier par un ingénieur.
