# V115 — Pont Projets (central) ⇄ Chantiers (logiciel chantier)
Le projet du logiciel central et le chantier terrain se rejoignent par un lien enregistré sur le chantier (`exb_sites.central_project_id`).
1. Demandes reçues › 🏗️ Chantiers terrain : sur chaque chantier, **🔗 Lier à un projet** (choix du projet par numéro ; 0 pour délier).
2. **⬇ Mettre à jour le projet** reporte dans le projet lié : avancement (dernier rapport), budget (si le projet n'en a pas), dépenses → Caisse (catégorie, lot, projet), rapports journaliers → Journal de chantier du projet.
3. Sans doublon : chaque ligne importée garde son identifiant d'origine (champ `src`) ; relancer la mise à jour n'ajoute que le nouveau.
NON REPORTÉ (données disponibles dans la fonction `chantier_export_projet`) : pointage → feuilles de présence, mouvements de matériaux → stock, registres (RFI, réserves…). À brancher après essai de ce premier pont.
Limites : seul le compte administrateur peut lier/importer ; mise à jour à la demande (bouton), pas automatique. Non testé sur un vrai Supabase.
