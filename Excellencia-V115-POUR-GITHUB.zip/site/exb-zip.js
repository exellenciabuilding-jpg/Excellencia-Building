/* exb-zip.js — V99 : lecture et écriture de fichiers ZIP, sans bibliothèque externe, fonctionne hors connexion.
 * Sert au lecteur IFC (fichiers .ifczip) et au BCF (échange d'observations BIM, fichiers .bcfzip / .bcf).
 *   EXB_ZIP.store([{name, data: Uint8Array | string}]) -> Uint8Array   (ZIP non compressé, noms en UTF-8)
 *   EXB_ZIP.unzip(Uint8Array)  -> Promise<[{name, data: Uint8Array}]>  (méthodes « stocké » et « deflate »)
 * Limites : pas de ZIP64 (archives de plus de 4 Go), pas d'archive chiffrée ; refus clair dans ces cas. */
(function (root) {
  'use strict';
  var MAX_ENTRY = 600 * 1048576;               // 600 Mo par fichier décompressé : au-delà, refus (protection mémoire)
  var CRC = null;
  function crcTable() { CRC = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; CRC[n] = c >>> 0; } }
  function crc32(b) { if (!CRC) crcTable(); var c = 0xFFFFFFFF; for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function utf8(s) { return new TextEncoder().encode(String(s)); }
  function text(u8) { return new TextDecoder('utf-8').decode(u8); }
  function u16(v) { return [v & 255, (v >> 8) & 255]; }
  function u32(v) { return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]; }

  function store(files) {
    var parts = [], cen = [], off = 0, i, f, nm, d, crc, hdr, c;
    var now = new Date(), dt = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate(), tm = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    for (i = 0; i < files.length; i++) {
      f = files[i]; nm = utf8(f.name); d = typeof f.data === 'string' ? utf8(f.data) : f.data; crc = crc32(d);
      hdr = [].concat(u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(tm), u16(dt), u32(crc), u32(d.length), u32(d.length), u16(nm.length), u16(0));
      parts.push(new Uint8Array(hdr), nm, d);
      c = [].concat(u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(tm), u16(dt), u32(crc), u32(d.length), u32(d.length), u16(nm.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(off));
      cen.push(new Uint8Array(c), nm);
      off += hdr.length + nm.length + d.length;
    }
    var csz = 0; cen.forEach(function (p) { csz += p.length; });
    var end = new Uint8Array([].concat(u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(csz), u32(off), u16(0)));
    var all = parts.concat(cen, [end]), tot = 0; all.forEach(function (p) { tot += p.length; });
    var out = new Uint8Array(tot), o = 0; all.forEach(function (p) { out.set(p, o); o += p.length; });
    return out;
  }

  function inflateRaw(u8) {
    if (typeof DecompressionStream !== 'undefined') {
      var ds = new DecompressionStream('deflate-raw'), w = ds.writable.getWriter();
      w.write(u8).catch(function () {}); w.close().catch(function () {});
      return new Response(ds.readable).arrayBuffer().then(function (b) { return new Uint8Array(b); });
    }
    if (typeof require !== 'undefined') { try { return Promise.resolve(new Uint8Array(require('zlib').inflateRawSync(u8))); } catch (e) { return Promise.reject(e); } }
    return Promise.reject(new Error('Décompression non disponible sur ce navigateur : utilisez un navigateur récent ou un fichier .ifc non compressé.'));
  }

  function unzip(u8) {
    return new Promise(function (resolve, reject) {
      try {
        if (!(u8 instanceof Uint8Array)) u8 = new Uint8Array(u8);
        var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), n = u8.length, e = -1, i;
        for (i = n - 22; i >= Math.max(0, n - 22 - 65535); i--) { if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; } }
        if (e < 0) throw new Error('Archive ZIP invalide (fin de répertoire introuvable).');
        var cnt = dv.getUint16(e + 10, true), cdOff = dv.getUint32(e + 16, true);
        if (cnt === 0xFFFF || cdOff === 0xFFFFFFFF) throw new Error('Archive ZIP64 non prise en charge.');
        var list = [], p = cdOff;
        for (i = 0; i < cnt; i++) {
          if (p + 46 > n || dv.getUint32(p, true) !== 0x02014b50) throw new Error('Archive ZIP invalide (répertoire central).');
          var flag = dv.getUint16(p + 8, true), meth = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true), usz = dv.getUint32(p + 24, true),
            nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), lo = dv.getUint32(p + 42, true),
            name = text(u8.subarray(p + 46, p + 46 + nl));
          if (flag & 1) throw new Error('Archive ZIP chiffrée non prise en charge.');
          list.push({ name: name, meth: meth, csz: csz, usz: usz, lo: lo });
          p += 46 + nl + el + cl;
        }
        var out = [], idx = 0;
        (function next() {
          while (idx < list.length && /\/$/.test(list[idx].name)) idx++;          // dossiers ignorés
          if (idx >= list.length) return resolve(out);
          var it = list[idx++];
          if (it.usz > MAX_ENTRY) return reject(new Error('« ' + it.name + ' » est trop volumineux une fois décompressé.'));
          if (it.lo + 30 > n || dv.getUint32(it.lo, true) !== 0x04034b50) return reject(new Error('Archive ZIP invalide (en-tête local).'));
          var st = it.lo + 30 + dv.getUint16(it.lo + 26, true) + dv.getUint16(it.lo + 28, true), raw = u8.subarray(st, st + it.csz);
          if (it.meth === 0) { out.push({ name: it.name, data: raw.slice() }); return next(); }
          if (it.meth !== 8) return reject(new Error('Méthode de compression ZIP non prise en charge (' + it.meth + ').'));
          inflateRaw(raw).then(function (d) { out.push({ name: it.name, data: d }); next(); }, reject);
        })();
      } catch (err) { reject(err); }
    });
  }

  var api = { store: store, unzip: unzip, crc32: crc32, text: text, utf8: utf8, version: 'V99' };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.EXB_ZIP = api;
})(typeof window !== 'undefined' ? window : globalThis);
