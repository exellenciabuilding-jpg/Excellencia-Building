# V99zzzzz — Démarrage robuste (connexion lente)

- `index.html` : 2,35 Mo -> 0,83 Mo. Les 3 grosses images (affiche, fond d'affiche, filigrane certificat) sont dans `exb-images.js`, chargé après l'ouverture.
- Écran de chargement affiché dès les premiers octets.
- `sw.js` : plus de téléchargement massif à l'installation ; fichiers déjà enregistrés servis tout de suite ; préparation hors connexion en arrière-plan (2 fichiers à la fois, 15 s après l'ouverture, désactivée en mode économie de données / 2G).
- `_headers` : cache des images (Netlify).
- Après mise à jour : ouvrir le logiciel deux fois (cache `exb-v99zzz-tfl-sans-limite-demarrage-robuste`).
