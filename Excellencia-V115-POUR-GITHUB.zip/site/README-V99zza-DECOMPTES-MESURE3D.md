# V99zza — Décomptes mensuels & retenue de garantie, mesure de distances en 3D

Fichiers : `exb-decompte.js` (nouveau dans cette branche), `exb-ifc3d.js`, `index.html` (1 balise), `sw.js` (cache `exb-v99zza-decomptes-mesure3d-1`), `exb-v99r-shell.js` (menu, version), `tools/test-decompte.js`, `tools/test-bim/test-mesure.py`, `tools/e2e-smoke.py`. Aucun nouveau SQL.

## 1. Décomptes mensuels (Finance › Décomptes)
- **Marché** par chantier : postes saisis ou importés du DQE (le champ « Projet » du DQE doit porter le nom du chantier).
- **Décompte mensuel** par quantités cumulées : travaux du mois = cumul − cumul précédent ; avance de démarrage remboursée au prorata de l'avancement ; **retenue de garantie** ; pénalités de retard plafonnées ; révision de prix optionnelle ; TVA ; **net à payer**. Validation = verrouillage ; PDF ; alerte si une quantité dépasse le marché.
- **Retenue de garantie** : cumul retenu, **libérations** (réception provisoire, réception définitive, remplacement par une caution), solde encore retenu ; une libération ne peut pas dépasser le solde.
- **Cautions et garanties** (avance, bonne exécution, retenue de garantie) avec alertes « expirée » / « expire sous 30 jours ».
- **Valeurs par défaut à confirmer par contrat et par l'expert-comptable** (marquées ainsi à l'écran, modifiables marché par marché) : avance 15 %, retenue 5 %, TVA 16 %, pénalité 0,1 % du marché par jour plafonnée à 10 %, révision désactivée. Méthode détaillée dans l'onglet « Méthode ».
- Hypothèses à valider : retenues déduites du TTC à leur montant HT ; avance traitée hors TVA.
- Non fait : lien automatique avec les situations / factures existantes, avenants.

## 2. Mesure de distances en 3D (lecteur IFC)
- Bouton **📏 Mesurer** : touchez deux points du modèle ; **accrochage automatique aux sommets** (à 18 px) ; trait et étiquette dessinés sur le modèle.
- Le panneau « Mesures 3D » donne pour chaque mesure la **distance 3D**, la part **horizontale** et la part **verticale**, plus le total ; **↩ Retirer**, **🗑 Tout effacer**, **➕ Envoyer au métré** (lignes en ml dans « Matériaux ajoutés », sans doublon au renvoi).
- Pendant la mesure, le clic ne sélectionne plus d'élément ; glisser tourne la vue ; désactiver « Mesurer » rétablit la sélection.
- Limites : distance en ligne droite entre deux points visibles du modèle (pas de chemin le long d'un mur) ; les mesures ne sont pas conservées à la fermeture de la maquette ; l'image exportée (PNG) ne contient pas les traits de mesure ; mesures indicatives.

## Tests
`node tools/test-decompte.js` (22 contrôles, valeurs recalculées à la main dont la retenue), `python3 tools/test-bim/test-mesure.py` (19/19 : distance 10,198 m exacte, horizontal² + vertical² = 3D², métré, annulation), `python3 tools/test-bim/test.py` (14/14), `node tools/test-bim/test-quantites.js` (13/13), `python3 tools/e2e-smoke.py`, `node tools/check.js` (335 contrôles). Non testé sur un vrai téléphone.
