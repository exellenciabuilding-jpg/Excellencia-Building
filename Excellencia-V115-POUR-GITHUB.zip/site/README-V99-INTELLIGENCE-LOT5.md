# EXCELLENCIA INTELLIGENCE — lot 5 : métrés, devis et plans

Nouveau : `exb-intelligence-5.js` (après `exb-intelligence.js`). Modifiés : `index.html` (1 balise), `sw.js` (cache + version). Comble le point « Métré ↔ devis et plans : non traités » des lots 3 et 4.

## Contrôles ajoutés
- **Métrés** : numéros en double, client/projet rattaché introuvable, valeurs négatives, matériau sans prix / sans quantité / sans désignation / en double, métré vide.
- **Métré ↔ devis (même numéro)** : client différent, matériau du métré absent du devis, quantité différente.
- **Devis** : lignes sans désignation, quantité ou prix négatif/nul, lignes en double, imprévus hors 0–100 %, devise absente, **total enregistré ≠ lignes × (1 + imprévus %)**, « Client à renseigner », client/projet absents des listes.
- **Plans (fiches)** : projet introuvable, même référence + indice en double dans un projet, mesures sans échelle.

## Correction guidée
« Recalculer… » sur un total de devis incohérent : confirmation, lignes jamais modifiées, **annulable** depuis l'historique, inscrit au journal. Droit requis : écriture sur `metreDevis`.

## Moteurs et documents
`EXBI.calc.devis`, `EXBI.calc.metreExtras`. Document : « Dossier métrés, devis et plans par projet » (HTML, hors ligne). Recommandations : métrés sans devis, devis « Client à renseigner ».

## Tests réalisés (navigateur, vraies pages)
Données de test avec erreurs volontaires : les 18 constats attendus sont produits ; le recalcul 999 → 172,70 puis l'annulation (retour à 999) fonctionnent avec confirmation ; les constats des lots 1 à 4 sont identiques avec et sans ce lot ; aucune erreur JavaScript ; fonctionne hors connexion.

## Réserves
- Le contrôle métré ↔ devis ne compare que les **matériaux ajoutés** : les lignes issues du moteur Excel du métré (béton, fer…) ne sont pas recalculables hors du module métré.
- Le total d'un devis suit la formule de votre écran Devis (lignes × (1 + imprévus %)) : à confirmer sur vos devis réels.
- Les mesures des plans sont seulement comptées ; leur contenu n'est pas vérifié. Fichiers de plans (IndexedDB) non lus.
- Non testé sur téléphone ni avec la base partagée réelle.

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-5.js">` de index.html.
