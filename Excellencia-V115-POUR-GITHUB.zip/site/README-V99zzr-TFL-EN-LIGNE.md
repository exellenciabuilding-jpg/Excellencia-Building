# V99zzr — TFL : fonctionne EN LIGNE et HORS CONNEXION (comme les apprenants)

Le module TFL garde son mode local (V99zzq) et gagne un **mode Internet** : l'étudiant peut envoyer sa candidature directement par un lien, sans fichier à renvoyer.

## Deux façons d'envoyer le formulaire (onglet 🎓 TFL › ① Préparer)
| Mode | Ce que vous faites | Ce que fait l'étudiant |
|---|---|---|
| 🌐 **Lien Internet** | « 🔗 Copier le lien » ou « 💬 Envoyer par WhatsApp » (nom/téléphone/université pré-remplis si saisis) | ouvre le lien, remplit, touche « 📡 Envoyer en ligne » : la candidature arrive sur le serveur |
| 📴 **Fichier hors ligne** | « 📤 Envoyer le fichier » ou « ⬇ Télécharger » | remplit sans Internet, touche « 💾 Enregistrer le fichier », vous renvoie le `.json` |

- La même page `tfl-formulaire.html` sert aux deux : avec Internet le bouton « Envoyer en ligne » est actif ; sans Internet il se désactive et le fichier reste possible. Les réponses sont gardées sur l'appareil de l'étudiant tant que rien n'est envoyé.
- Le fichier hors ligne contient la clé **publique** du serveur : si l'étudiant a Internet au moment de l'ouvrir, il peut aussi l'envoyer en ligne.
- Le lien Internet n'apparaît que lorsque le logiciel est ouvert depuis son adresse web (https://…, ex. Netlify). Le même lien refonctionne hors connexion après une première ouverture (cache du service worker `exb-v99zzr-tfl-en-ligne`).

## Recevoir (onglet 🎓 TFL › ② Recevoir les candidatures)
- **En ligne** : « 📡 Récupérer les candidatures en ligne ». Il faut être connecté au serveur (Inscription › Demandes reçues, compte administrateur). À l'ouverture de l'onglet, le nombre de nouvelles candidatures s'affiche. Chaque candidature crée le dossier **TFL-AAAA-0001** (même traitement que le fichier), puis est marquée « traitée » sur le serveur.
- **Hors ligne** : importer les fichiers `.json`, comme avant.
- Une candidature reçue par les deux voies (fichier + en ligne) ne crée **qu'un seul dossier**.
- Le matricule, la décision, l'encadreur, l'attestation PDF : inchangés (voir README-V99zzq-TFL-LOCAL.md).

## À faire UNE FOIS pour le mode Internet
1. Supabase › SQL Editor : exécuter **`supabase/migration-v99zzr-tfl-en-ligne.sql`** (réexécutable ; indépendant du gros script `migration-v99zzq-tfl.sql`, qui reste NON nécessaire).
2. Déployer ce ZIP sur le site (Netlify) ; vider le cache / recharger une fois.
3. Vérifier : `select proname from pg_proc where proname in ('tfl_candidature_envoyer','tfl_candidatures_liste','tfl_candidature_traiter');` → 3 lignes.
Tant que le SQL n'est pas exécuté, le formulaire affiche « service pas encore activé » et propose le fichier ; rien n'est perdu.

## Sécurité (ce que fait le script)
- Table `tfl_candidatures` sans aucune politique : personne ne la lit directement.
- Envoi public limité (200 / heure au total, 5 / heure par numéro), champs filtrés et tronqués, photo ≤ 390 Ko.
- Lecture et « traitée » réservées aux e-mails administrateur (mêmes que `migration-v99m-verification.sql`).

## Limites
- **Le script SQL n'a pas été exécuté sur un vrai PostgreSQL/Supabase** (indisponible ici) : relisez-le et testez avec une candidature d'essai. Le formulaire et l'application, eux, ont été testés dans un navigateur avec un serveur simulé.
- Les candidatures reçues sont ensuite stockées **sur l'appareil administrateur** (comme les apprenants) : faites des sauvegardes (« ⬇ Sauvegarde »). Elles restent aussi sur le serveur (marquées traitées).
- Pas de pièces jointes (chapitres, plans) ni de comptes étudiant / encadreur en mode local.
- Pas encore faits : bibliothèque de documents (05), corrections par chapitre (06), rendez-vous et échéances (07), préparation de la défense (08), tableau de bord et rapports (09).
- Un numéro WhatsApp commençant par 0 est converti en +243.

## Contrôles
`node tools/test-tfl/test.js` (logique, dont le même envoi reçu par fichier puis en ligne) · `python3 tools/test-tfl/e2e-en-ligne.py` (navigateur : formulaire en ligne, repli sans service, hors connexion, lien Internet, récupération et absence de doublon) · `node tools/check.js` (357 contrôles).
