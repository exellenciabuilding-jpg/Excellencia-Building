# Clic droit, devis sans doublon, QR unique, orthographe

**Aucun SQL.** Nouveaux fichiers : `exb-menu-contextuel.js`, `exb-devis-unique.js` (balises dans `index.html`, cache dans `sw.js`). Modifiés : `exb-metre.js`, `exb-docs.js`.

## 1. Menu du clic droit (tous les modules)
Clic droit (ou appui long sur téléphone) dans un champ ou sur un texte sélectionné : menu à côté du curseur → **Couper, Copier, Coller, Tout sélectionner**, correction du mot ou du champ, interrupteur « Correction automatique ». Maj + clic droit = menu normal du navigateur. Si le navigateur bloque « Coller » par le menu, utiliser Ctrl+V.

## 2. Devis : pas de doublon, QR unique
- **Numérotation** : DEV-AAAA-NNN = plus grand numéro déjà utilisé + 1 (métrés, devis rapides et registre des PDF). Un numéro supprimé n'est plus réutilisé par erreur.
- **Enregistrer deux fois le même devis** (même client, même projet, mêmes lignes) : le logiciel le reconnaît et met à jour l'existant au lieu d'en créer un second. Même client + même projet mais contenu différent : il demande « mettre à jour » ou « nouveau devis ».
- **Transfert métré → devis rapide** : ajoute ou met à jour, jamais de doublon.
- **Numéro déjà pris par un autre client** : un nouveau numéro est attribué automatiquement (message à l'écran). Le QR de vérification dépend du numéro, du client et du montant : un QR n'appartient donc jamais à deux personnes. Même contrôle juste avant la création du PDF.

## 3. Orthographe
Soulignement du navigateur en français dans les zones de texte ; correction d'un mot (« Corriger "recu" → "reçu" ») ou de tout le champ depuis le menu ; correction automatique douce à la sortie des zones de texte libres (notes, désignations, projets, objets…) : accents oubliés (béton, matériaux, désignation…), mots doublés, espaces en trop, majuscule en début de phrase. Adresses web, e-mails, codes et noms ne sont pas touchés. Désactivable dans le menu clic droit.
