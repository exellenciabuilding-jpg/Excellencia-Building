# V99zzy — Corrections de l'audit : fiche étudiante, QR de vérification, réservations

Trois failles confirmées par test sur PostgreSQL 16 (anonyme) ont été fermées. **Rien n'est supprimé** : une seule nouvelle migration, de petites modifications de pages, tests ajoutés.

## Ce qui change
| Faille | Avant | Maintenant |
|---|---|---|
| 1. Écrasement de fiche | Téléphone + référence du sujet suffisaient pour remplacer nom, année et photo d'un autre étudiant. | « Choisir ce sujet » remet **un jeton secret (une seule fois)**. La fiche en ligne l'exige (le serveur ne garde que son empreinte). Le choix renvoyé ne redonne **jamais** de nouveau jeton. Les choix faits avant la migration (sans jeton) restent acceptés. |
| 2. QR falsifiable | N'importe qui pouvait déclarer un faux document « authentique », ou un 2e code sur le même numéro pour déclasser le vrai en « ancienne version ». | Un dépôt public est **« Fiche déposée, non confirmée »**. Il ne compte plus pour « dernière version ». L'importation d'une fiche TFL par l'administrateur (en ligne) la **confirme automatiquement**. |
| 3. Réservations / saturation | Un anonyme pouvait réserver tous les sujets exclusifs ; plafonds globaux seulement. | **2 sujets réservés au plus par numéro** ; une réservation dont la fiche n'est jamais complétée **expire après 14 jours** (jamais si la fiche est complétée ou le dossier importé) ; **limite par adresse IP** (40 choix / 40 fiches / 100 dépôts de QR par heure). |

## À faire
1. Supabase › SQL Editor : exécuter **`supabase/migration-v99zzy-securite-tfl-qr.sql`** (après `migration-v99zzx`, réexécutable).
2. Déployer le ZIP (cache `exb-v99zzy-securite-tfl-qr`), recharger une fois.
3. Vérifier : `select proname from pg_proc where proname in ('exb_ip_limite','exb_doc_confirmer');` → 2 lignes.
4. **Déployer les fichiers et exécuter le SQL dans la même journée** : les nouvelles pages envoient le jeton, l'ancienne fonction SQL l'ignore sans erreur ; les anciennes pages sans jeton sont refusées pour les nouveaux choix (message : utiliser le fichier).

## Tests (tous OK)
- `PGHOST=… tools/test-rls/run.sh` : 43/43 (RLS) + 28/28 (validation ingénieur) + **29/29 nouveaux** (`test-tfl-qr.sql` : jeton, réservations, expiration, limite IP, registre QR, droits). Le banc charge désormais aussi les migrations TFL.
- `node tools/check.js` : 405/405 · `node tools/test-tfl/test.js` · `python3 tools/test-tfl/e2e-jeton.py` (nouveau) · `e2e-sujets.py` · `python3 tools/e2e-smoke.py`.

## Limites (à connaître)
- **Testé sur PostgreSQL 16 avec imitation de Supabase, pas sur un vrai projet Supabase.** La limite par IP lit l'en-tête `request.headers` (cf-connecting-ip, x-real-ip ou dernière adresse x-forwarded-for) : à confirmer en recette ; sans en-tête, aucune limite par IP (les plafonds globaux restent).
- **Appareils partagés par un campus** : 40 choix par heure et par IP ; relevez la valeur dans le SQL si besoin.
- **Jeton perdu** (autre appareil, données effacées, réponse perdue au premier choix) : la fiche en ligne est refusée, l'étudiant utilise « Enregistrer le fichier » (message affiché). Pas de renvoi automatique du jeton : c'est voulu, sinon la faille revient.
- **Le numéro de téléphone reste non vérifié** : quelqu'un qui fait le premier choix avec le numéro d'un autre reçoit le jeton. Seule une vérification par SMS/WhatsApp (OTP) le règle.
- Les fiches déjà déposées ont été marquées « non confirmées » ; elles se confirment à l'importation suivante ou par `exb_doc_confirmer` (administrateur connecté).
- Non traité : le plafond global de 200 candidatures/heure existe toujours ; le nom affiché d'une copie d'épreuve est repris du registre (dépôts publics compris).

Fichiers : nouveaux `supabase/migration-v99zzy-securite-tfl-qr.sql`, `tools/test-rls/test-tfl-qr.sql`, `tools/test-tfl/e2e-jeton.py` ; modifiés `tfl-sujets.html`, `tfl-fiche.html`, `verification.html`, `exb-verif.js`, `exb-tfl.js`, `sw.js`, `tools/check.js`, `tools/test-rls/run.sh`, `tools/test-rls/stub-supabase.sql`.
Retour en arrière : restaurer ces fichiers de V99zzx ; la colonne ajoutée est inoffensive (ré-exécuter les fonctions V99zzv / V99zzx / V99m pour retrouver l'ancien comportement).
