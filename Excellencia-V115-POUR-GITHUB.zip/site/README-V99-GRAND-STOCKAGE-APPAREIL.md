# Grand stockage de l'appareil (fini le « espace du navigateur saturé »)

Fichiers : exb-bigstore.js (nouveau), index.html (exbStorage + carte), exb-sync.js (attend la fin du chargement), sw.js (cache + liste hors connexion). Aucun SQL.

1. Les images lourdes (photos, logos, signatures de plus de 40 Ko) sont rangées dans IndexedDB (centaines de Mo) ; localStorage ne garde qu'un petit jeton. L'application, les sauvegardes et la synchronisation voient les mêmes images qu'avant. Les données déjà existantes sont compactées automatiquement quelques secondes après l'ouverture, ou à la demande.
2. Menu « 💾 Données sur mon PC » → carte « 📱 Stockage de l'appareil » : usage, protection contre l'effacement, et trois boutons :
   - 📲 Enregistrer sur le téléphone : sauvegarde complète (même contenu que « Sauvegarde complète ») via Partager (Fichiers, Drive…) ou Téléchargements ;
   - 📐 Enregistrer mes plans : les fichiers de plans (PDF, DWG, DXF, IFC, images) stockés sur l'appareil ;
   - 🧹 Libérer l'espace / 🔒 Protéger mes données.
3. Si IndexedDB est indisponible, rien n'est déplacé (comportement d'avant).
Limite : le stockage n'est protégé contre l'effacement automatique du téléphone que si le navigateur accorde « stockage persistant » (souvent après installation sur l'écran d'accueil) ; gardez une copie avec le bouton 📲.
