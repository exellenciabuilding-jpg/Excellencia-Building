# V99ze — Calcul de structure : tout sur une seule page, plus d'entrées successives

Fichiers modifiés : `calcul-structure/index.html`, `exb-calcul-structure.js`, `exb-v99r-shell.js` (libellé de version), `sw.js` (cache `exb-v99ze-tout-sur-page-1`).

- **Poutre, Poteau, Dalle, Semelle, Escalier** : en descendant sur la page, on trouve dans l'ordre la géométrie, les résultats, la **Vue 3D (affichée directement)**, la **Note de calcul** et le **Plan d'exécution 2D**. Plus de bouton à ouvrir. Une barre collante (Vue 3D · Note · Plan · Imprimer) permet de sauter à chaque partie. La 3D garde le plein écran (⛶).
- **Bâtiment** : modèle 3D, note de calcul et plans déjà sur la même page (inchangé).
- **Un seul niveau de navigation** : la barre des modules (Bâtiment … Devis DQE) est la seule. Ajout des onglets **Rapports** et **Options**. La barre du bas (Accueil / Calculs / Rapports / Plus) est retirée, de même que la page de tuiles « Tous les calculs » : « Accueil » et « Calculs » ouvrent directement le dernier module utilisé.
- Les puces en double au-dessus du calculateur sont supprimées ; l'écran de calcul est plus haut.
- Le titre n'a plus de flèche retour ni de cloche, sauf à l'intérieur d'un bâtiment (flèche vers la liste des bâtiments).
- Limites : volumes, coffrage, ferraillage minimal, moment maximal, dosage, mortier, coûts et agglos sont des calculs simples : ils s'affichent d'un coup avec leurs résultats, sans 3D ni plan (ils n'en ont pas). Testé dans Chromium (écran téléphone) et `node tools/check.js` (248 contrôles) ; à confirmer sur votre téléphone.
- Retour en arrière : restaurer les 4 fichiers de V99zd.
