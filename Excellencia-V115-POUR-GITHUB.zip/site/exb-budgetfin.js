/* Excellencia Building V99zzb — Budget & pilotage financier.
 * 4 outils branchés sur les données EXISTANTES (aucune double saisie) :
 *   1. Budget mensuel de l'entreprise (revenus, charges fixes, prêts, variables, épargne) — réel calculé depuis la caisse
 *   2. Comparatif de deux périodes (recettes, dépenses, résultat, répartition)
 *   3. Tableau de bord annuel (12 mois) avec suivi de la TVA
 *   4. Fiche client tout-en-un (coordonnées, projets, devis, factures filtrées, récapitulatif de période, créances)
 * Sources lues : exb_cash (caisse, y compris les encaissements de factures), exb_payments (paiements des apprenants),
 * exb_invoices, exb_clients, exb_projects, exb_quotes, exb_finance (taux du jour FC/USD).
 * Nouvelles données : exb_bf_budgets (lignes de budget par mois), exb_bf_tva (TVA déductible saisie par mois).
 * Les dépenses saisies ici sont enregistrées DANS la caisse (une seule source de vérité). */
(function(w,d){'use strict';
var K={b:'exb_bf_budgets',t:'exb_bf_tva'},SK='exb_bf_set';
var $=function(i){return d&&d.getElementById?d.getElementById(i):null};
var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
var say=function(m,t){try{notify(m,t||'info',4500)}catch(e){try{alert(m)}catch(x){}}};
function LD(k,df){try{var v=load(k,df);return v==null?df:v}catch(e){return df}}
function SV(k,v){try{return save(k,v)}catch(e){return false}}
var norm=function(s){return String(s==null?'':s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim()};
var pn=function(v){var x=parseFloat(String(v==null?'':v).replace(/\s/g,'').replace(',','.'));return isNaN(x)?0:x};
var nf=function(n,dec){return Number(n||0).toLocaleString('fr-FR',{minimumFractionDigits:dec==null?2:dec,maximumFractionDigits:dec==null?2:dec}).replace(/[\u202f\u00a0]/g,' ')};
var today=function(){return new Date().toISOString().slice(0,10)};
var MOIS=['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];
var PAL=['#2f6fed','#16a34a','#f59e0b','#e5352f','#8b5cf6','#0ea5e9','#64748b','#ec4899'];
var uid=function(p){try{return exbId(p)}catch(e){return p+'-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}};

/* ---------- réglages d'affichage ---------- */
var SET={disp:'USD',apprenants:true};
try{Object.assign(SET,JSON.parse(w.localStorage.getItem(SK)||'{}'))}catch(e){}
function saveSet(){try{w.localStorage.setItem(SK,JSON.stringify(SET))}catch(e){}}

/* ---------- devises : tous les montants sont ramenés en USD, affichage USD ou FC au taux enregistré (Finance V78) ---------- */
function rate(){var t=LD('exb_finance',[]).filter(function(x){return x&&x.type==='taux'&&+x.rate>0}).sort(function(a,b){return a.date<b.date?-1:1});return t.length?+t[t.length-1].rate:0}
var isFC=function(c){return /^(FC|CDF)$/i.test(c||'')};
function toUSD(a,cur){a=+a||0;if(!isFC(cur))return a;var r=rate();return r>0?a/r:null}
function money(usd){if(SET.disp==='FC'&&rate()>0)return nf(usd*rate(),0)+' FC';return nf(usd,2)+' $'}

/* ---------- mouvements normalisés (caisse + paiements apprenants) ---------- */
var DEPK=[['Loyer & charges',/loyer|bail|location|electricite|snel|regideso|\beau\b/],['Salaires & main-d’œuvre',/salaire|paie|main.?d.?oeuvre|ouvrier|journalier|prime/],
 ['Matériaux',/ciment|\bfer\b|sable|gravier|brique|agglo|beton|materiau|peinture|bois/],['Transport & carburant',/transport|carburant|essence|gasoil|diesel|taxi|voyage/],
 ['Internet & communication',/internet|\bdata\b|credit|airtime|telephone/],['Marketing & publicité',/publicit|affiche|marketing|\bpub\b/],
 ['Fournitures & bureau',/fourniture|papier|imprim|encre|bureau|papeterie/],['Abonnements & logiciels',/abonnement|licence|logiciel|hebergement/],['Impôts & taxes',/impot|taxe|\btva\b|\bdgi\b|inss|onem/]];
var RECK=[['Formations (apprenants)',/inscription|formation|apprenant/],['Études & honoraires',/etude|honoraire|plan/]];
function guessCat(lab,list,dflt){var t=norm(lab);for(var i=0;i<list.length;i++)if(list[i][1].test(t))return list[i][0];return dflt}
function cashArr(){try{return exbCash||[]}catch(e){return LD('exb_cash',[])}}
function entries(){var out=[],r=rate();
 cashArr().forEach(function(x){var a=+x.amount||0;if(!a||!x.date)return;var u=toUSD(a,x.currency);if(u==null)return;var inn=x.type==='in',lab=String(x.label||'');
  var cat=x.cat||(inn?((x.invoice_id||/^encaissement facture/i.test(lab))?'Encaissements factures chantier':guessCat(lab,RECK,'Autres recettes')):guessCat(lab,DEPK,'Autres dépenses'));
  out.push({d:String(x.date).slice(0,10),t:inn?'in':'out',a:u,cat:cat,lab:lab})});
 if(SET.apprenants)LD('exb_payments',[]).forEach(function(p){var a=+p.amount||0;if(!a||!p.date)return;out.push({d:String(p.date).slice(0,10),t:'in',a:a,cat:'Formations (apprenants)',lab:'Paiement '+(p.participant_name||'')+' '+(p.training||'')})});
 return out}

/* ---------- 1. BUDGET MENSUEL ---------- */
var TPL=[['rev','Encaissements factures chantier','encaissement facture'],['rev','Formations (apprenants)','inscription|formation'],['rev','Études & honoraires','etude|honoraire'],['rev','Autres recettes',''],
 ['fix','Loyer & charges','loyer|bail|electricite|eau'],['fix','Salaires & main-d’œuvre','salaire|paie|ouvrier|journalier'],['fix','Internet & communication','internet|data|airtime|telephone'],['fix','Abonnements & logiciels','abonnement|licence|logiciel'],['fix','Impôts & taxes','impot|taxe|dgi|inss'],
 ['pret','Remboursement prêt / dette','pret|dette'],
 ['var','Matériaux','ciment|sable|gravier|brique|agglo|beton|fer'],['var','Transport & carburant','transport|carburant|essence|gasoil'],['var','Fournitures & bureau','fourniture|papier|imprim|encre'],['var','Marketing & publicité','publicit|affiche|marketing'],['var','Divers',''],
 ['epa','Réserve / épargne entreprise','epargne|reserve']];
var GN={rev:'REVENUS',fix:'DÉPENSES FIXES',pret:'PRÊTS / DETTES',var:'DÉPENSES VARIABLES',epa:'ÉPARGNE / RÉSERVE'},GORD={rev:0,fix:1,pret:2,epa:3,var:4};
function budgets(){return LD(K.b,[])}
function newLines(){return TPL.map(function(t){return{id:uid('BL'),g:t[0],label:t[1],kw:t[2],budget:0,manual:''}})}
function getB(ym){var b=budgets().find(function(x){return x.ym===ym});return b||{id:'BM-'+ym,ym:ym,lines:newLines(),_new:1}}
function putB(b){delete b._new;var a=budgets(),i=a.findIndex(function(x){return x.id===b.id});if(i>=0)a[i]=b;else a.push(b);SV(K.b,a)}
function kwHit(l,e){if(!l.kw)return false;var t=norm(e.lab+' '+e.cat);return String(l.kw).split('|').some(function(k){k=norm(k);return k&&t.indexOf(k)>-1})}
function calcMonth(ym,E){E=(E||entries()).filter(function(e){return e.d.slice(0,7)===ym});
 var b=getB(ym),lines=b.lines.map(function(l){return Object.assign({},l,{auto:0})}),unIn=0,unOut=0;
 E.forEach(function(e){var pool=lines.filter(function(l){return (e.t==='in')===(l.g==='rev')});
  var ln=pool.find(function(l){return norm(l.label)===norm(e.cat)});
  if(!ln)ln=pool.map(function(l,i){return[l,i]}).sort(function(a,c){return GORD[a[0].g]-GORD[c[0].g]||a[1]-c[1]}).map(function(x){return x[0]}).find(function(l){return kwHit(l,e)});
  if(ln)ln.auto+=e.a;else if(e.t==='in')unIn+=e.a;else unOut+=e.a});
 var G={};Object.keys(GORD).forEach(function(g){G[g]={budget:0,real:0}});
 lines.forEach(function(l){l.real=(l.manual===''||l.manual==null)?l.auto:pn(l.manual);G[l.g].budget+=pn(l.budget);G[l.g].real+=l.real});
 var depB=G.fix.budget+G.pret.budget+G.var.budget+G.epa.budget,depR=G.fix.real+G.pret.real+G.var.real+G.epa.real+unOut;
 return{ym:ym,b:b,lines:lines,G:G,unIn:unIn,unOut:unOut,revR:G.rev.real+unIn,revB:G.rev.budget,depB:depB,depR:depR,resteB:G.rev.budget-depB,resteR:G.rev.real+unIn-depR}}

/* ---------- agrégats (comparatif / annuel) ---------- */
function agg(from,to,E){E=E||entries();var r={in:0,out:0,ci:{},co:{}};
 E.forEach(function(e){if(e.d<from||e.d>to)return;if(e.t==='in'){r.in+=e.a;r.ci[e.cat]=(r.ci[e.cat]||0)+e.a}else{r.out+=e.a;r.co[e.cat]=(r.co[e.cat]||0)+e.a}});
 r.res=r.in-r.out;r.marge=r.in?r.res/r.in*100:0;return r}
function monthEnd(ym){return ym+'-31'}
function addM(ym,n){var y=+ym.slice(0,4),m=+ym.slice(5,7)-1+n;y+=Math.floor(m/12);m=((m%12)+12)%12;return y+'-'+String(m+1).padStart(2,'0')}

/* ---------- factures ---------- */
function invs(){return LD('exb_invoices',[])}
function iTot(i){var ht=(i.lines||[]).reduce(function(a,l){return a+(+l.q||0)*(+l.pu||0)},0),tv=ht*(+i.tva||0)/100,ttc=ht+tv,paid=(i.payments||[]).reduce(function(a,p){return a+(+p.amount||0)},0);return{ht:ht,tva:tv,ttc:ttc,paid:paid,reste:Math.max(0,ttc-paid)}}
function cancelled(i){return !!(i.annule||/annul/i.test(i.status||''))}
function iStat(i){if(cancelled(i))return'Annulée';var t=iTot(i);if(t.ttc>0&&t.paid>=t.ttc-0.005)return'Payée';if(i.due&&i.due<today())return'En retard';return t.paid>0?'Partielle':'Émise'}
function iUSD(i){var t=iTot(i),c=i.currency,o={ht:toUSD(t.ht,c),tva:toUSD(t.tva,c),ttc:toUSD(t.ttc,c),paid:toUSD(t.paid,c)};if(o.ttc==null)return null;o.reste=Math.max(0,o.ttc-o.paid);return o}
function vatByMonth(year){var r={};invs().forEach(function(i){if(cancelled(i)||!i.date||String(i.date).slice(0,4)!==String(year))return;var u=iUSD(i);if(!u)return;var m=String(i.date).slice(5,7);r[m]=(r[m]||0)+u.tva});return r}
function vatDed(ym){var x=LD(K.t,[]).find(function(t){return t.ym===ym});return x?+x.deductible||0:0}
function setVatDed(ym,v){var a=LD(K.t,[]),i=a.findIndex(function(t){return t.ym===ym});if(i>=0)a[i].deductible=pn(v);else a.push({id:'T-'+ym,ym:ym,deductible:pn(v)});SV(K.t,a)}

/* ---------- graphiques SVG ---------- */
function compact(n){var a=Math.abs(n);return a>=1e6?(n/1e6).toFixed(1)+'M':a>=1e3?(n/1e3).toFixed(a>=1e4?0:1)+'k':String(Math.round(n))}
function bars(labels,series,names){var W=640,H=230,pl=44,pb=30,pt=16,lo=0,hi=0;series.forEach(function(s){s.forEach(function(v){if(v>hi)hi=v;if(v<lo)lo=v})});if(hi===lo)hi=lo+1;
 var Y=function(v){return pt+(H-pt-pb)*(1-(v-lo)/(hi-lo))},n=labels.length,gw=(W-pl-6)/n,bw=Math.max(4,Math.min(24,gw/(series.length+1))),h='<svg viewBox="0 0 '+W+' '+H+'" class="bf-svg" role="img">';
 [0,.5,1].forEach(function(f){var v=lo+(hi-lo)*f,y=Y(v);h+='<line x1="'+pl+'" x2="'+W+'" y1="'+y+'" y2="'+y+'" stroke="#8884" stroke-width="1"/><text x="'+(pl-4)+'" y="'+(y+3)+'" font-size="10" text-anchor="end" fill="currentColor">'+compact(v)+'</text>'});
 series.forEach(function(s,k){s.forEach(function(v,i){var x=pl+gw*i+(gw-bw*series.length)/2+bw*k,y0=Y(0),y=Y(v);h+='<rect x="'+x.toFixed(1)+'" y="'+Math.min(y,y0).toFixed(1)+'" width="'+bw+'" height="'+Math.max(1,Math.abs(y0-y)).toFixed(1)+'" fill="'+PAL[k%PAL.length]+'" rx="2"><title>'+esc(labels[i])+' — '+esc(names[k])+' : '+esc(nf(v,0))+'</title></rect>'})});
 labels.forEach(function(l,i){h+='<text x="'+(pl+gw*i+gw/2).toFixed(1)+'" y="'+(H-12)+'" font-size="10" text-anchor="middle" fill="currentColor">'+esc(l)+'</text>'});
 h+='</svg><div class="bf-leg">'+names.map(function(nm,k){return'<span><i style="background:'+PAL[k%PAL.length]+'"></i>'+esc(nm)+'</span>'}).join('')+'</div>';return h}
function donut(parts,fmtv){var tot=parts.reduce(function(a,p){return a+Math.max(0,p.v)},0);if(tot<=0)return'<p class="exb-muted">Aucune donnée sur la période.</p>';
 var off=25,h='<div class="bf-don"><svg viewBox="0 0 42 42" class="bf-donut"><circle cx="21" cy="21" r="15.9155" fill="none" stroke="#8883" stroke-width="6"/>';
 parts.forEach(function(p,i){if(p.v<=0)return;var pc=p.v/tot*100;h+='<circle cx="21" cy="21" r="15.9155" fill="none" stroke="'+PAL[i%PAL.length]+'" stroke-width="6" stroke-dasharray="'+pc.toFixed(2)+' '+(100-pc).toFixed(2)+'" stroke-dashoffset="'+off.toFixed(2)+'"/>';off-=pc});
 h+='</svg><ul class="bf-dl">'+parts.filter(function(p){return p.v>0}).map(function(p,i){return'<li><i style="background:'+PAL[parts.indexOf(p)%PAL.length]+'"></i>'+esc(p.l)+' — <b>'+(fmtv?fmtv(p.v):nf(p.v))+'</b> ('+(p.v/tot*100).toFixed(0)+' %)</li>'}).join('')+'</ul></div>';return h}
function topParts(map,n){var a=Object.keys(map).map(function(k){return{l:k,v:map[k]}}).sort(function(x,y){return y.v-x.v});if(a.length>n){var o=a.slice(n-1).reduce(function(s,p){return s+p.v},0);a=a.slice(0,n-1).concat([{l:'Autres',v:o}])}return a}

/* ---------- état et rendu ---------- */
var ST={tab:'b',ym:today().slice(0,7),year:new Date().getFullYear(),cp:null,cid:'',cstat:'Toutes',cfrom:new Date().getFullYear()+'-01-01',cto:new Date().getFullYear()+'-12-31'};
ST.cp={a1:addM(ST.ym,-1)+'-01',a2:monthEnd(addM(ST.ym,-1)),b1:ST.ym+'-01',b2:monthEnd(ST.ym)};
function css(){return'<style>.bf-tabs{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}.bf-tabs button.on{background:#2f6fed;color:#fff}.bf-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:10px 0}.bf-card{background:#8881;border:1px solid #8883;border-radius:10px;padding:8px 10px}.bf-card small{display:block;opacity:.75}.bf-card b{font-size:16px}.bf-svg{width:100%;max-width:680px;height:auto;display:block}.bf-leg{display:flex;gap:12px;flex-wrap:wrap;font-size:12px;margin:4px 0}.bf-leg i,.bf-dl i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:5px}.bf-don{display:flex;gap:14px;align-items:center;flex-wrap:wrap}.bf-donut{width:130px;height:130px;transform:none}.bf-dl{list-style:none;margin:0;padding:0;font-size:13px}.bf-t input{width:100%;min-width:70px;box-sizing:border-box}.bf-t td.n{text-align:right;white-space:nowrap}.bf-pos{color:#15803d}.bf-neg{color:#b91c1c}.bf-row{display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin:8px 0}.bf-row label{font-size:12px;display:flex;flex-direction:column;gap:2px}.bf-h{margin:14px 0 4px}</style>'}
function tabs(){var T=[['b','📅 Budget mensuel'],['c','⚖️ Comparatif'],['a','📈 Annuel & TVA'],['k','🧑‍💼 Fiche client']];return'<div class="bf-tabs">'+T.map(function(t){return'<button class="muted'+(ST.tab===t[0]?' on':'')+'" onclick="EXBBF.tab(\''+t[0]+'\')">'+t[1]+'</button>'}).join('')+'</div>'}
function dispBtn(){return'<label style="font-size:12px">Affichage <select onchange="EXBBF.disp(this.value)"><option value="USD"'+(SET.disp==='USD'?' selected':'')+'>USD ($)</option><option value="FC"'+(SET.disp==='FC'?' selected':'')+'>FC (taux '+(rate()?nf(rate(),0):'non défini')+')</option></select></label>'}
function cls(v){return v>0?'bf-pos':v<0?'bf-neg':''}
function pdf(titre,sous,rows,notes,file){if(!w.EXBPdf)return say('Module PDF indisponible.','warn');EXBPdf.make({titre:titre,sousTitre:sous,rows:rows,notes:notes||[],footer:titre+' — Excellencia Building'}).then(function(x){EXBPdf.save(x,file)})}
function dt(s){return s?String(s).slice(8,10)+'/'+String(s).slice(5,7)+'/'+String(s).slice(0,4):''}

/* --- onglet 1 --- */
function drawB(){var c=calcMonth(ST.ym),G=c.G,ex=calcExpParts(c),h='';
 h+='<div class="bf-row"><label>Mois<input type="month" value="'+ST.ym+'" onchange="EXBBF.month(this.value)"></label><button class="muted" onclick="EXBBF.copyPrev()">📋 Copier le budget du mois précédent</button><button class="muted" onclick="EXBBF.pdfB()">📄 PDF</button></div>';
 h+='<p class="exb-muted">Montants en <b>$ (USD)</b>. Le « Réel » se calcule automatiquement depuis la caisse (et les paiements des apprenants) grâce au <b>mot-clé</b> de chaque ligne ; saisissez un chiffre dans « Réel » pour le remplacer (vide = automatique).</p>';
 h+='<div class="bf-grid"><div class="bf-card"><small>Revenus reçus</small><b>'+nf(c.revR)+' $</b><small>Budget '+nf(c.revB)+' $</small></div><div class="bf-card"><small>Dépenses totales</small><b>'+nf(c.depR)+' $</b><small>Budget '+nf(c.depB)+' $</small></div><div class="bf-card"><small>Épargne / réserve</small><b>'+nf(G.epa.real)+' $</b><small>Budget '+nf(G.epa.budget)+' $</small></div><div class="bf-card"><small>Reste à vivre</small><b class="'+cls(c.resteR)+'">'+nf(c.resteR)+' $</b><small>Prévu '+nf(c.resteB)+' $</small></div></div>';
 ['rev','fix','pret','var','epa'].forEach(function(g){
  h+='<h4 class="bf-h">'+GN[g]+'</h4><div class="exb-scroll"><table class="exb-table bf-t"><thead><tr><th>Libellé</th><th>Mot-clé caisse</th><th>Budget</th><th>Réel</th><th>Écart</th><th></th></tr></thead><tbody>';
  c.lines.forEach(function(l){if(l.g!==g)return;var ec=g==='rev'?l.real-pn(l.budget):pn(l.budget)-l.real;
   h+='<tr><td><input value="'+esc(l.label)+'" onchange="EXBBF.ln(\''+l.id+'\',\'label\',this.value)"></td><td><input value="'+esc(l.kw)+'" placeholder="mot1|mot2" onchange="EXBBF.ln(\''+l.id+'\',\'kw\',this.value)"></td><td><input type="text" inputmode="decimal" value="'+(pn(l.budget)||'')+'" onchange="EXBBF.ln(\''+l.id+'\',\'budget\',this.value)"></td><td><input type="text" inputmode="decimal" value="'+(l.manual===''||l.manual==null?'':esc(l.manual))+'" placeholder="'+nf(l.auto)+'" onchange="EXBBF.ln(\''+l.id+'\',\'manual\',this.value)"></td><td class="n '+(g==='rev'?cls(ec):cls(ec))+'">'+(ec>0?'+':'')+nf(ec)+'</td><td><button class="muted smallbtn" onclick="EXBBF.delLn(\''+l.id+'\')">✕</button></td></tr>'});
  h+='<tr><td colspan="2"><b>Total</b></td><td class="n"><b>'+nf(G[g].budget)+'</b></td><td class="n"><b>'+nf(G[g].real)+'</b></td><td></td><td><button class="muted smallbtn" onclick="EXBBF.addLn(\''+g+'\')">＋</button></td></tr></tbody></table></div>'});
 if(c.unIn||c.unOut)h+='<p class="exb-muted">⚠ Non classé dans ce budget : recettes '+nf(c.unIn)+' $ · dépenses '+nf(c.unOut)+' $ (caisse). Ajoutez un mot-clé à une ligne, ou une ligne, pour les classer.</p>';
 h+='<h4 class="bf-h">Répartition des dépenses (réel)</h4>'+donut(ex,function(v){return nf(v)+' $'});
 var cats=c.lines.filter(function(l){return l.g==='var'}).map(function(l){return l.label});
 h+='<h4 class="bf-h">Ajouter une dépense (enregistrée dans la caisse)</h4><div class="bf-row"><label>Date<input type="date" id="bf_xd" value="'+(ST.ym===today().slice(0,7)?today():ST.ym+'-01')+'"></label><label>Description<input id="bf_xl" placeholder="Ex. Carburant camion"></label><label>Catégorie<select id="bf_xc">'+cats.map(function(x){return'<option>'+esc(x)+'</option>'}).join('')+'</select></label><label>Montant ($)<input id="bf_xa" type="text" inputmode="decimal"></label><label>Mode<select id="bf_xm"><option>Espèces</option><option>Virement</option><option>Mobile money</option><option>Chèque</option></select></label><button class="primary" onclick="EXBBF.addExp()">Enregistrer</button></div>';
 var mine=cashArr().filter(function(x){return x.bf&&String(x.date).slice(0,7)===ST.ym}).sort(function(a,b){return a.date<b.date?1:-1});
 if(mine.length)h+='<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Date</th><th>Description</th><th>Catégorie</th><th>Montant</th><th></th></tr></thead><tbody>'+mine.map(function(x){return'<tr><td>'+dt(x.date)+'</td><td>'+esc(x.label)+'</td><td>'+esc(x.cat||'')+'</td><td class="n">'+nf(x.amount)+' $</td><td><button class="muted smallbtn" onclick="EXBBF.delExp(\''+esc(x.id)+'\')">✕</button></td></tr>'}).join('')+'</tbody></table></div>';
 return h}
function calcExpParts(c){var m={};c.lines.forEach(function(l){if(l.g!=='rev'&&l.real>0)m[l.label]=(m[l.label]||0)+l.real});if(c.unOut>0)m['Non classé']=c.unOut;return topParts(m,8)}

/* --- onglet 2 --- */
function drawC(){var p=ST.cp,E=entries(),A=agg(p.a1,p.a2,E),B=agg(p.b1,p.b2,E),h='';
 h+='<div class="bf-row"><button class="muted" onclick="EXBBF.preset(\'m\')">Mois vs mois précédent</button><button class="muted" onclick="EXBBF.preset(\'t\')">Trimestre vs précédent</button><button class="muted" onclick="EXBBF.preset(\'a\')">Année vs précédente</button>'+dispBtn()+'<button class="muted" onclick="EXBBF.pdfC()">📄 PDF</button></div>';
 h+='<div class="bf-row"><b>Période 1</b><label>Du<input type="date" value="'+p.a1+'" onchange="EXBBF.per(\'a1\',this.value)"></label><label>Au<input type="date" value="'+p.a2+'" onchange="EXBBF.per(\'a2\',this.value)"></label></div><div class="bf-row"><b>Période 2</b><label>Du<input type="date" value="'+p.b1+'" onchange="EXBBF.per(\'b1\',this.value)"></label><label>Au<input type="date" value="'+p.b2+'" onchange="EXBBF.per(\'b2\',this.value)"></label></div>';
 function vr(a,b){var df=b-a;return'<td class="n">'+(df>0?'+':'')+money(df)+'</td><td class="n">'+(a?((df/Math.abs(a))*100).toFixed(0)+' %':'—')+'</td>'}
 h+='<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Vision d\'ensemble</th><th>Période 1</th><th>Période 2</th><th>Écart</th><th>%</th></tr></thead><tbody>'+
  [['Recettes',A.in,B.in],['Dépenses',A.out,B.out],['Résultat',A.res,B.res]].map(function(r){return'<tr><td><b>'+r[0]+'</b></td><td class="n">'+money(r[1])+'</td><td class="n">'+money(r[2])+'</td>'+vr(r[1],r[2])+'</tr>'}).join('')+'<tr><td><b>Marge</b></td><td class="n">'+A.marge.toFixed(1)+' %</td><td class="n">'+B.marge.toFixed(1)+' %</td><td class="n">'+(B.marge-A.marge>0?'+':'')+(B.marge-A.marge).toFixed(1)+' pt</td><td></td></tr></tbody></table></div>';
 var k=SET.disp==='FC'&&rate()>0?rate():1;
 h+='<h4 class="bf-h">Comparaison des périodes</h4>'+bars(['Recettes','Dépenses','Résultat'],[[A.in*k,A.out*k,A.res*k],[B.in*k,B.out*k,B.res*k]],['Période 1','Période 2']);
 [['Répartition des recettes','ci'],['Répartition des dépenses','co']].forEach(function(s){var keys=Object.keys(Object.assign({},A[s[1]],B[s[1]])).sort(function(x,y){return((B[s[1]][y]||0)+(A[s[1]][y]||0))-((B[s[1]][x]||0)+(A[s[1]][x]||0))});
  h+='<h4 class="bf-h">'+s[0]+'</h4><div class="exb-scroll"><table class="exb-table"><thead><tr><th>Catégorie</th><th>Période 1</th><th>Période 2</th><th>Écart</th><th>%</th></tr></thead><tbody>'+(keys.length?keys.map(function(c){var a=A[s[1]][c]||0,b=B[s[1]][c]||0;return'<tr><td>'+esc(c)+'</td><td class="n">'+money(a)+'</td><td class="n">'+money(b)+'</td>'+vr(a,b)+'</tr>'}).join(''):'<tr><td colspan="5" class="exb-muted">Aucune donnée.</td></tr>')+'</tbody></table></div><div class="bf-row" style="align-items:flex-start"><div><b>Période 1</b>'+donut(topParts(A[s[1]],6),money)+'</div><div><b>Période 2</b>'+donut(topParts(B[s[1]],6),money)+'</div></div>'});
 return h+'<p class="exb-muted">Recettes et dépenses = encaissements et décaissements réels (caisse + paiements des apprenants).</p>'}

/* --- onglet 3 --- */
function annual(year){var E=entries(),vat=vatByMonth(year),rows=[];for(var m=1;m<=12;m++){var mm=String(m).padStart(2,'0'),ym=year+'-'+mm,a=agg(ym+'-01',monthEnd(ym),E),tc=vat[mm]||0,td=vatDed(ym);rows.push({m:m,ym:ym,in:a.in,out:a.out,res:a.res,tc:tc,td:td,tv:tc-td})}
 var T=rows.reduce(function(s,r){['in','out','res','tc','td','tv'].forEach(function(k){s[k]=(s[k]||0)+r[k]});return s},{});T.marge=T.in?T.res/T.in*100:0;return{rows:rows,T:T}}
function drawA(){var Y=annual(ST.year),T=Y.T,k=SET.disp==='FC'&&rate()>0?rate():1,h='';
 h+='<div class="bf-row"><label>Année<input type="number" value="'+ST.year+'" style="width:90px" onchange="EXBBF.year(this.value)"></label>'+dispBtn()+'<button class="muted" onclick="EXBBF.pdfA()">📄 PDF</button></div>';
 h+='<div class="bf-grid"><div class="bf-card"><small>Recettes</small><b>'+money(T.in)+'</b></div><div class="bf-card"><small>Dépenses</small><b>'+money(T.out)+'</b></div><div class="bf-card"><small>Résultat</small><b class="'+cls(T.res)+'">'+money(T.res)+'</b></div><div class="bf-card"><small>Marge</small><b>'+T.marge.toFixed(1)+' %</b></div><div class="bf-card"><small>TVA à reverser (année)</small><b>'+money(T.tv)+'</b></div></div>';
 h+=bars(MOIS.map(function(x){return x.slice(0,3)}),[Y.rows.map(function(r){return r.in*k}),Y.rows.map(function(r){return r.out*k})],['Recettes','Dépenses']);
 h+='<div class="exb-scroll"><table class="exb-table bf-t"><thead><tr><th>Mois</th><th>Recettes</th><th>Dépenses</th><th>Résultat</th><th>TVA facturée</th><th>TVA déductible (saisie, $)</th><th>TVA à reverser</th></tr></thead><tbody>'+
  Y.rows.map(function(r){return'<tr><td>'+MOIS[r.m-1]+'</td><td class="n">'+money(r.in)+'</td><td class="n">'+money(r.out)+'</td><td class="n '+cls(r.res)+'">'+money(r.res)+'</td><td class="n">'+money(r.tc)+'</td><td><input type="text" inputmode="decimal" value="'+(r.td||'')+'" onchange="EXBBF.vat(\''+r.ym+'\',this.value)"></td><td class="n">'+money(r.tv)+'</td></tr>'}).join('')+
  '<tr><td><b>TOTAL</b></td><td class="n"><b>'+money(T.in)+'</b></td><td class="n"><b>'+money(T.out)+'</b></td><td class="n"><b>'+money(T.res)+'</b></td><td class="n"><b>'+money(T.tc)+'</b></td><td class="n"><b>'+money(T.td)+'</b></td><td class="n"><b>'+money(T.tv)+'</b></td></tr></tbody></table></div>';
 return h+'<p class="exb-muted">TVA facturée = TVA des factures émises dans le mois (hors annulées). La TVA déductible n\'est pas déduite automatiquement : saisissez-la chaque mois d\'après vos factures d\'achat.</p>'}

/* --- onglet 4 --- */
function clients(){return LD('exb_clients',[])}
function cNames(c){return[c.full_name,c.company,((c.first_name||'')+' '+(c.last_name||'')).trim()].map(norm).filter(function(x){return x.length>2})}
function cMatch(c,s){var n=norm(s);if(!n)return false;return cNames(c).some(function(x){return x===n||n.indexOf(x)>-1||x.indexOf(n)>-1})}
function recap(list,from,to){var r={n:0,paid:0,unpaid:0,ht:0,ttc:0,pay:0,due:0,canc:0,skipped:0};list.forEach(function(i){if(!i.date||i.date<from||i.date>to)return;if(cancelled(i)){r.canc++;return}var u=iUSD(i);if(!u){r.skipped++;return}r.n++;r.ttc+=u.ttc;r.ht+=u.ht;r.pay+=u.paid;r.due+=u.reste;if(iStat(i)==='Payée')r.paid++;else r.unpaid++});return r}
function drawK(){var C=clients(),c=C.find(function(x){return x.id===ST.cid}),h='';
 h+='<div class="bf-row"><label>Client<select onchange="EXBBF.cli(this.value)"><option value="">— Choisir un client —</option>'+C.map(function(x){return'<option value="'+esc(x.id)+'"'+(x.id===ST.cid?' selected':'')+'>'+esc(x.full_name||x.company||x.id)+'</option>'}).join('')+'</select></label>'+dispBtn()+'</div>';
 if(c){var L=invs().filter(function(i){return cMatch(c,i.client)}),P=LD('exb_projects',[]).filter(function(p){return cMatch(c,p.client)}),Q=LD('exb_quotes',[]).filter(function(q){return cMatch(c,q.client)});
  h+='<div class="bf-card"><b>'+esc(c.full_name||c.company)+'</b>'+(c.company&&c.company!==c.full_name?' · '+esc(c.company):'')+'<br><small>📞 '+esc(c.phone||'—')+' · ✉️ '+esc(c.email||'—')+'</small><small>📍 '+esc(c.address||'—')+'</small>'+(c.type?'<small>Type : '+esc(c.type)+'</small>':'')+(c.note?'<small>📝 '+esc(c.note)+'</small>':'')+'</div>';
  h+='<h4 class="bf-h">Projets liés ('+P.length+') et devis ('+Q.length+')</h4>'+(P.length?'<p>'+P.map(function(p){return esc(p.name||p.id)}).join(' · ')+'</p>':'<p class="exb-muted">Aucun projet lié.</p>');
  var R=recap(L,ST.cfrom,ST.cto);
  h+='<h4 class="bf-h">Récapitulatif des factures de la période</h4><div class="bf-row"><label>Du<input type="date" value="'+ST.cfrom+'" onchange="EXBBF.cper(\'cfrom\',this.value)"></label><label>Au<input type="date" value="'+ST.cto+'" onchange="EXBBF.cper(\'cto\',this.value)"></label></div>';
  h+='<div class="bf-grid"><div class="bf-card"><small>Factures</small><b>'+R.n+'</b><small>'+R.paid+' payée(s) · '+R.unpaid+' à encaisser</small></div><div class="bf-card"><small>Facturé TTC</small><b>'+money(R.ttc)+'</b></div><div class="bf-card"><small>Encaissé</small><b class="bf-pos">'+money(R.pay)+'</b></div><div class="bf-card"><small>Reste dû</small><b class="'+(R.due>0?'bf-neg':'')+'">'+money(R.due)+'</b></div><div class="bf-card"><small>Annulées</small><b>'+R.canc+'</b></div></div>'+(R.skipped?'<p class="exb-muted">⚠ '+R.skipped+' facture(s) en FC ignorée(s) : aucun taux du jour enregistré (Finance).</p>':'');
  h+=donut([{l:'Encaissé',v:R.pay},{l:'Reste dû',v:R.due}],money);
  h+='<h4 class="bf-h">Factures du client</h4><div class="bf-row"><label>Statut<select onchange="EXBBF.cstat(this.value)">'+['Toutes','Payée','Partielle','Émise','En retard','Annulée'].map(function(s){return'<option'+(s===ST.cstat?' selected':'')+'>'+s+'</option>'}).join('')+'</select></label><button class="muted" onclick="EXBBF.pdfK()">📄 PDF fiche client</button></div>';
  var F=L.filter(function(i){return ST.cstat==='Toutes'||iStat(i)===ST.cstat}).sort(function(a,b){return a.date<b.date?1:-1});
  h+=F.length?'<div class="exb-scroll"><table class="exb-table"><thead><tr><th>N°</th><th>Date</th><th>TTC</th><th>Payé</th><th>Reste</th><th>Statut</th><th></th></tr></thead><tbody>'+F.map(function(i){var t=iTot(i),cu=esc(i.currency||'USD');return'<tr><td>'+esc(i.no)+'</td><td>'+dt(i.date)+'</td><td class="n">'+nf(t.ttc)+' '+cu+'</td><td class="n">'+nf(t.paid)+'</td><td class="n">'+nf(cancelled(i)?0:t.reste)+'</td><td>'+iStat(i)+'</td><td style="white-space:nowrap">'+(w.EXBCH&&!cancelled(i)&&t.reste>0?'<button class="muted smallbtn" onclick="EXBBF.pay(\''+esc(i.id)+'\')">💵</button> ':'')+(w.EXBCH?'<button class="muted smallbtn" onclick="EXBBF.invPdf(\''+esc(i.id)+'\')">📄</button> ':'')+'<button class="muted smallbtn" onclick="EXBBF.cancel(\''+esc(i.id)+'\')">'+(cancelled(i)?'↩':'🚫')+'</button></td></tr>'}).join('')+'</tbody></table></div>':'<p class="exb-muted">Aucune facture pour ce filtre.</p>'}
 /* créances par client */
 var map={};invs().forEach(function(i){if(cancelled(i))return;var u=iUSD(i);if(!u||u.reste<=0.005)return;var k=i.client||'—';map[k]=(map[k]||0)+u.reste});
 var rk=Object.keys(map).map(function(k){return[k,map[k]]}).sort(function(a,b){return b[1]-a[1]}).slice(0,10);
 h+='<h4 class="bf-h">Créances par client (top 10)</h4>'+(rk.length?'<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Client</th><th>Reste dû</th></tr></thead><tbody>'+rk.map(function(r){return'<tr><td>'+esc(r[0])+'</td><td class="n">'+money(r[1])+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="exb-muted">Aucune créance en cours.</p>');
 return h}

function render(){var b=$('bf_box');if(!b)return;var f={b:drawB,c:drawC,a:drawA,k:drawK}[ST.tab]||drawB,h;try{h=f()}catch(e){h='<p class="exb-muted">Erreur d\'affichage : '+esc(e&&e.message)+'</p>'}b.innerHTML=css()+tabs()+h}

/* ---------- actions ---------- */
var A={tab:function(t){ST.tab=t;render()},disp:function(v){SET.disp=v;saveSet();render()},
 month:function(v){if(/^\d{4}-\d{2}$/.test(v)){ST.ym=v;render()}},
 ln:function(id,f,v){var b=getB(ST.ym),l=b.lines.find(function(x){return x.id===id});if(!l)return;l[f]=(f==='budget')?pn(v):(f==='manual'?(String(v).trim()===''?'':pn(v)):v);putB(b);render()},
 addLn:function(g){var b=getB(ST.ym);b.lines.push({id:uid('BL'),g:g,label:'Nouvelle ligne',kw:'',budget:0,manual:''});putB(b);render()},
 delLn:function(id){if(!confirm('Supprimer cette ligne du budget de ce mois ?'))return;var b=getB(ST.ym);b.lines=b.lines.filter(function(x){return x.id!==id});putB(b);render()},
 copyPrev:function(){var p=budgets().find(function(x){return x.ym===addM(ST.ym,-1)});if(!p)return say('Aucun budget enregistré le mois précédent.','warn');if(budgets().some(function(x){return x.ym===ST.ym})&&!confirm('Remplacer le budget de ce mois par celui du mois précédent ?'))return;
  putB({id:'BM-'+ST.ym,ym:ST.ym,lines:p.lines.map(function(l){return Object.assign({},l,{id:uid('BL'),manual:''})})});say('Budget copié.','success');render()},
 addExp:function(){var dd=$('bf_xd').value,lab=$('bf_xl').value.trim(),cat=$('bf_xc').value,a=pn($('bf_xa').value),m=$('bf_xm').value;if(!lab||a<=0||!dd)return say('Date, description et montant sont obligatoires.','warn');
  var o={id:uid('CASH'),date:dd,type:'out',label:lab,amount:a,method:m,ref:'',cat:cat,bf:1};
  try{exbCash.push(o);exbSave('exb_cash',exbCash);try{renderExbCash()}catch(e){}}catch(e){var x=LD('exb_cash',[]);x.push(o);SV('exb_cash',x)}
  say('Dépense enregistrée dans la caisse.','success');render()},
 delExp:function(id){if(!confirm('Supprimer cette dépense de la caisse ?'))return;try{var i=exbCash.findIndex(function(x){return x.id===id&&x.bf});if(i>=0){exbCash.splice(i,1);exbSave('exb_cash',exbCash);try{renderExbCash()}catch(e){}}}catch(e){SV('exb_cash',LD('exb_cash',[]).filter(function(x){return !(x.id===id&&x.bf)}))}render()},
 preset:function(k){var y=+ST.ym.slice(0,4),m=+ST.ym.slice(5,7),p=ST.cp;
  if(k==='m'){p.a1=addM(ST.ym,-1)+'-01';p.a2=monthEnd(addM(ST.ym,-1));p.b1=ST.ym+'-01';p.b2=monthEnd(ST.ym)}
  else if(k==='t'){var q=Math.floor((m-1)/3)*3+1,s=y+'-'+String(q).padStart(2,'0'),e=addM(s,2),ps=addM(s,-3),pe=addM(s,-1);p.b1=s+'-01';p.b2=monthEnd(e);p.a1=ps+'-01';p.a2=monthEnd(pe)}
  else{p.b1=y+'-01-01';p.b2=y+'-12-31';p.a1=(y-1)+'-01-01';p.a2=(y-1)+'-12-31'}render()},
 per:function(k,v){if(v){ST.cp[k]=v;render()}},
 year:function(v){var y=parseInt(v,10);if(y>1990&&y<2100){ST.year=y;render()}},
 vat:function(ym,v){setVatDed(ym,v);render()},
 cli:function(id){ST.cid=id;render()},cstat:function(s){ST.cstat=s;render()},cper:function(k,v){if(v){ST[k]=v;render()}},
 pay:function(id){try{EXBCH.pay(id)}catch(e){say('Encaissement impossible ici : utilisez « Chantiers & finances ».','warn')}render()},
 invPdf:function(id){try{EXBCH.pdf(id)}catch(e){say('PDF de facture indisponible.','warn')}},
 cancel:function(id){var a=invs(),i=a.find(function(x){return x.id===id});if(!i)return;if(!cancelled(i)&&!confirm('Annuler la facture '+i.no+' ? Elle sera exclue des totaux de ce tableau de bord (les encaissements déjà en caisse restent).'))return;i.annule=!cancelled(i);SV('exb_invoices',a);render()},
 pdfB:function(){var c=calcMonth(ST.ym),rows=[['Mois',MOIS[+ST.ym.slice(5,7)-1]+' '+ST.ym.slice(0,4)],['Revenus (réel / budget)',nf(c.revR)+' $ / '+nf(c.revB)+' $'],['Dépenses (réel / budget)',nf(c.depR)+' $ / '+nf(c.depB)+' $'],['Reste à vivre (réel / prévu)',nf(c.resteR)+' $ / '+nf(c.resteB)+' $']];
  c.lines.forEach(function(l){rows.push([GN[l.g]+' — '+l.label,'Budget '+nf(pn(l.budget))+' $  |  Réel '+nf(l.real)+' $'])});if(c.unOut||c.unIn)rows.push(['Non classé','Recettes '+nf(c.unIn)+' $  |  Dépenses '+nf(c.unOut)+' $']);
  pdf('BUDGET MENSUEL',MOIS[+ST.ym.slice(5,7)-1]+' '+ST.ym.slice(0,4),rows,['Réel calculé depuis la caisse et les paiements des apprenants.'],'budget-mensuel-'+ST.ym+'.pdf')},
 pdfC:function(){var p=ST.cp,E=entries(),a=agg(p.a1,p.a2,E),b=agg(p.b1,p.b2,E),rows=[['Période 1',dt(p.a1)+' → '+dt(p.a2)],['Période 2',dt(p.b1)+' → '+dt(p.b2)],['Recettes',money(a.in)+'  →  '+money(b.in)],['Dépenses',money(a.out)+'  →  '+money(b.out)],['Résultat',money(a.res)+'  →  '+money(b.res)],['Marge',a.marge.toFixed(1)+' %  →  '+b.marge.toFixed(1)+' %']];
  ['ci','co'].forEach(function(s){Object.keys(Object.assign({},a[s],b[s])).forEach(function(c){rows.push([(s==='ci'?'Recette — ':'Dépense — ')+c,money(a[s][c]||0)+'  →  '+money(b[s][c]||0)])})});pdf('COMPARATIF DE PÉRIODES','Période 1 vs Période 2',rows,[],'comparatif-periodes.pdf')},
 pdfA:function(){var Y=annual(ST.year),rows=[];Y.rows.forEach(function(r){rows.push([MOIS[r.m-1],'Recettes '+money(r.in)+' | Dépenses '+money(r.out)+' | Résultat '+money(r.res)+' | TVA à reverser '+money(r.tv)])});rows.push(['TOTAL','Recettes '+money(Y.T.in)+' | Dépenses '+money(Y.T.out)+' | Résultat '+money(Y.T.res)+' | TVA '+money(Y.T.tv)]);
  pdf('TABLEAU DE BORD ANNUEL','Année '+ST.year,rows,['TVA facturée = factures émises ; TVA déductible saisie manuellement.'],'tableau-bord-'+ST.year+'.pdf')},
 pdfK:function(){var c=clients().find(function(x){return x.id===ST.cid});if(!c)return;var L=invs().filter(function(i){return cMatch(c,i.client)}),R=recap(L,ST.cfrom,ST.cto),rows=[['Client',c.full_name||c.company||''],['Téléphone / e-mail',(c.phone||'—')+' / '+(c.email||'—')],['Adresse',c.address||'—'],['Période',dt(ST.cfrom)+' → '+dt(ST.cto)],['Factures',R.n+' ('+R.paid+' payées, '+R.unpaid+' à encaisser, '+R.canc+' annulées)'],['Facturé / encaissé / reste dû',money(R.ttc)+' / '+money(R.pay)+' / '+money(R.due)]];
  L.forEach(function(i){var t=iTot(i);rows.push([i.no+' — '+dt(i.date),'TTC '+nf(t.ttc)+' '+(i.currency||'USD')+' | Payé '+nf(t.paid)+' | '+iStat(i)])});pdf('FICHE CLIENT',c.full_name||c.company||'',rows,[],'fiche-client.pdf')}};
w.EXBBF=A;A._t={entries:entries,calcMonth:calcMonth,agg:agg,annual:annual,recap:recap,iTot:iTot,iStat:iStat,cMatch:cMatch,render:render,ST:ST,SET:SET,toUSD:toUSD,drawB:drawB,drawC:drawC,drawA:drawA,drawK:drawK,getB:getB,addM:addM};

/* ---------- montage dans le menu ---------- */
function mount(){if(!d||!d.body||$('budgetfin'))return;var ref=$('comptabilite')||$('chantiers')||$('projets'),host=d.querySelector('.wrap')||d.querySelector('main')||d.body,s=d.createElement('section');s.id='budgetfin';s.style.display='none';
 s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>📊 Budget &amp; pilotage financier</h2><p class="exb-muted">Budget mensuel, comparatif de périodes, tableau de bord annuel avec TVA et fiche client — calculés depuis votre caisse et vos factures.</p></div></div><div id="bf_box"></div></div>';
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
 var b=$('bcompta')||$('bchan')||$('bprj');if(b&&!$('bbfin')){var n=d.createElement('button');n.id='bbfin';n.textContent='📊 Budget & pilotage';n.setAttribute('onclick',"show('budgetfin')");b.parentNode.insertBefore(n,b.nextSibling)}
 var os=w.show;if(typeof os==='function'&&!w.__exbBfShow){w.__exbBfShow=1;w.show=function(x){var r=os.apply(this,arguments),e=$('budgetfin');if(e)e.style.display=(x==='budgetfin')?'':'none';if(x==='budgetfin')render();return r}}
 render()}
if(d&&d.readyState==='loading')d.addEventListener('DOMContentLoaded',function(){setTimeout(mount,800)});else setTimeout(mount,800);
})(typeof window!=='undefined'?window:globalThis,typeof document!=='undefined'?document:null);
