EXCELLENCIA BUILDING V77 — LIMITES DE LA V76

INSTALLATION
1) Hébergez le dossier (cache hors ligne « exb-v77 »).
2) Supabase › SQL Editor : exécuter supabase/migration-v77-photos-recurrence.sql (une fois, réexécutable).
3) Facultatif : activer l'extension pg_cron puis décommenter la dernière ligne du SQL (récurrences calculées chaque jour à 5 h).
4) node tools/check.js avant livraison.

CE QUI CHANGE
· Étiquettes QR : bouton « Adresse permanente » (domaine https fixe). Avertissement si les étiquettes imprimées pointent vers une autre adresse.
· Lien scanné avant connexion/synchronisation : mémorisé et ouvert dès que l'équipement est disponible.
· 📷 Scanner un QR (fiche Maintenance) : caméra intégrée si le navigateur gère la détection de QR (Chrome Android). Sinon : appareil photo du téléphone ou saisie du code.
· Récurrence : rattrapage à l'ouverture et au retour en ligne (local + fonction SQL exb_generer_recurrences). Sans pg_cron, rien ne tourne appareil éteint.
· Photos : à la synchronisation, les photos passent dans le bucket privé « exb-photos » (enregistrées sous la forme sb:chemin). Affichage et PDF les relisent par lien signé.
  Si le bucket est absent ou si l'appareil est hors ligne, la photo reste dans l'appareil. Alerte à 4 Mo de stockage local.
· Réserves levées : mots-clés modifiables (⚙ dans le panneau Réception). Par défaut : clôtur, lev, solde, résolu, fermé.

LIMITES CONNUES
· Non testé dans un navigateur ni sur un Supabase réel : envoi/lecture des photos, scanner caméra et fonction SQL à valider sur le terrain.
· Le scanner dépend du navigateur (absent sur beaucoup d'iPhone).
· Un lien QR reste lié à l'adresse imprimée : seul un domaine fixe évite de réimprimer.
· Les photos déjà synchronisées avant la V77 restent en base64 (non converties) ; seules les modifications ultérieures sont envoyées au stockage.
· Si le client et le serveur créent la même échéance en même temps, un doublon est possible ; il est limité par le contrôle « generated_from ».
· Ancien navigateur sans photos résolues : un PDF omet la photo si elle est introuvable.

CORRECTIF (V77) : exb-v67.js et exb-v68.js étaient appelés sans « document » (erreur « reading 'addEventListener' » au chargement, boutons Projet 360° et CDE/BIM/EVM non initialisés). Corrigé ; la page se charge maintenant sans erreur JavaScript en navigateur de test.

ÉCRAN D'OUVERTURE : image de chargement (splash-fond.jpg) au démarrage et en fond de l'écran de connexion. Le fond blanc natif d'Android (icône sur fond blanc, avant l'ouverture de la page) devient bleu (manifest : background_color). Android le génère lui-même : il ne peut pas être supprimé ni remplacé par une image plein écran ; pour qu'il change, désinstaller puis réinstaller l'application sur l'écran d'accueil.

V78 : Finance projet USD/FC (bouton « 💱 Finance USD / FC » dans l administration) : taux du jour, devis -> situation -> facture -> paiement (Mobile Money en reference), totaux dans la monnaie choisie. Executer supabase/migration-v78-finance.sql. Ce registre est NOUVEAU : il ne reprend pas les devis/factures des anciens modules.

V79 : Architecture (bouton « 📐 Phases architecture ») : 7 phases de mission, honoraires par phase, heures, avancement valide, marge, facturation vers Finance USD/FC. Executer supabase/migration-v79-architecture.sql. Necessite un taux du jour defini dans Finance. Pas de cartouche automatique sur les plans.

V80 : Cartouche des plans (bouton « 📐 Cartouche des plans ») : logo, projet, client, maitre d ouvrage, lieu, permis, titre, reference, indice, phase de mission (auto depuis Architecture), echelle, format, date, dessine/verifie, visa/statut. Executer supabase/migration-v80-cartouche.sql. Le dessin joint (image) est ajuste a la zone : l echelle imprimee n est pas garantie. PDF non pris en charge comme dessin. Pas d historique des revisions dans le cartouche.
