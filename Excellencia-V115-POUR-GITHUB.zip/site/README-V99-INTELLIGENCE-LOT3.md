# EXCELLENCIA INTELLIGENCE — lot 3 : bureau d'études, calcul de structure, planning, pilotage

Nouveau : `exb-intelligence-3.js` (après `exb-intelligence.js`). Modifiés : `index.html` (1 balise), `sw.js` (cache). Lecture seule des données, sauf la synchronisation de la descente de charges (confirmation + annulable).

## Contrôles ajoutés (panneau 🧠)
**Notes de calcul (BAEL)** — contrôle de COHÉRENCE DES SAISIES, pas un recalcul de dimensionnement (qui reste à l'ingénieur) :
auteur manquant, enrobage < 2 cm, poteau < 20 cm, élancement λ > 70, sol > 0,6 MPa, Nu ELU < Ns ELS, poutre h < L/16, charges nulles ou négatives, portée/section nulle.
**Synchronisation** : si une note contient UNE descente de charges et UN poteau dont Nu diffère de plus de 2 %, bouton « Synchroniser Nu… » (poteau + semelle alignés, formule 1,35 G + 1,5 Q identique à votre module). Annulable.
**Planning (Gantt)** : durée/début invalides, avancement hors 0–100 %, planning dépassant la fin du projet (> 1 semaine), avancement du projet ≠ planning (> 15 points), projet terminé avec tâches < 100 %, deux plannings pour un même projet.
**Honoraires** : facturé > avancement acquis, heures dépassées, « % du budget » sans budget, heures sur mission supprimée.
**Pilotage** : alertes du moteur EVM existant (CPI/SPI, retard, dépassement) remontées dans le même panneau.
**Document** : « Dossier d'études par projet » (HTML, hors ligne).
**Moteurs réutilisables** : `EXBI.calc.descente`, `EXBI.calc.elancement`.

## Réserves
Les seuils (20 cm, λ 70, 0,6 MPa, 2 cm) sont des repères usuels à faire valider par votre ingénieur ; ajustables dans le code. Les alertes de pilotage utilisent les seuils par défaut de l'EVM (pas vos seuils personnalisés par projet). Métré ↔ devis et plans : non traités dans ce lot.

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-3.js">` de index.html.
