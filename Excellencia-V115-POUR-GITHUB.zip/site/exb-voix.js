/* Excellencia Building — Assistant : écoute de la voix (V99 VOIX).
 * Ajoute dans la fenêtre de l'assistant 🤖 :
 *   🎤 parler (la phrase dite est écrite puis envoyée à l'assistant),
 *   🎧 mains libres (réécoute automatiquement après chaque réponse ; dire « stop » pour arrêter),
 *   🔊 lecture des réponses à voix haute.
 * Moteurs : reconnaissance du navigateur (Chrome, Edge, Safari, PWA Android) ou, dans l'application Android,
 * le plugin Capacitor « SpeechRecognition » s'il est installé. Sinon le micro reste masqué et le clavier fonctionne comme avant.
 * Ce fichier ne modifie aucune donnée et n'agit sur l'assistant qu'en remplissant son champ de saisie et en touchant « Envoyer » :
 * les autorisations Interdit / Demander / Automatique de Paramètres › 🤖 Assistant IA s'appliquent donc exactement comme au clavier.
 * Attention : la reconnaissance vocale des navigateurs et d'Android envoie le son au service vocal du système (Google en général) :
 * elle demande généralement internet. Le reste du logiciel continue de fonctionner hors connexion. */
(function (w, d) {
  'use strict';
  var KEY = 'exb_voice_cfg';
  function load() { try { var c = JSON.parse(w.localStorage.getItem(KEY) || '{}') || {}; return { hands: !!c.hands, speak: !!c.speak, lang: c.lang || 'fr-FR' }; } catch (e) { return { hands: false, speak: false, lang: 'fr-FR' }; } }
  function save() { try { w.localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {} }
  var cfg = load();

  var SR = w.SpeechRecognition || w.webkitSpeechRecognition || null;
  if (/Electron/i.test(w.navigator.userAgent || '')) SR = null; /* version Windows (Electron) : pas de service vocal intégré, le micro reste masqué */
  function nat() { try { return (w.Capacitor && w.Capacitor.Plugins && w.Capacitor.Plugins.SpeechRecognition) || null; } catch (e) { return null; } }
  function engine() { return nat() ? 'native' : (SR ? 'web' : ''); }

  var rec = null, listening = false, wantListen = false, speaking = false, restartT = 0, lastSpoken = '', nativeLast = '', nativeSub = [];
  var els = {};

  function $(id) { return d.getElementById(id); }
  function toast(t, type) { try { if (w.notify) w.notify(t, type || 'info', 5000); } catch (e) {} }
  function norm(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim(); }

  function setUi() {
    if (els.mic) {
      els.mic.style.background = listening ? '#c0392b' : '#173565';
      els.mic.title = listening ? 'Arrêter l’écoute' : 'Parler à l’assistant';
      els.mic.textContent = listening ? '⏹' : '🎤';
    }
    if (els.hands) { els.hands.style.opacity = cfg.hands ? '1' : '.45'; els.hands.title = 'Mains libres : ' + (cfg.hands ? 'activé (dites « stop » pour arrêter)' : 'désactivé'); }
    if (els.speak) { els.speak.style.opacity = cfg.speak ? '1' : '.45'; els.speak.title = 'Lire les réponses à voix haute : ' + (cfg.speak ? 'activé' : 'désactivé'); }
    var q = $('exbAIq');
    if (q) q.placeholder = listening ? '🎙️ Je vous écoute…' : 'Posez n’importe quelle question…';
  }

  function submit(text) {
    var q = $('exbAIq'), go = $('exbAIgo');
    text = String(text || '').trim();
    if (!q || !go || !text) return;
    q.value = text;
    go.click();
  }

  function stopWord(t) { var n = norm(t); return /^(stop|arrete|arrete toi|termine|fin|silence|tais toi|ferme)$/.test(n); }

  function onFinal(text) {
    wantListen = cfg.hands; /* en mains libres on réécoute après la réponse */
    if (!text) return;
    if (stopWord(text)) { cfg.hands = false; save(); wantListen = false; stopListen(); setUi(); return; }
    submit(text);
  }

  /* ---------- moteur navigateur ---------- */
  function startWeb() {
    try {
      rec = new SR();
      rec.lang = cfg.lang; rec.interimResults = true; rec.continuous = false; rec.maxAlternatives = 1;
      var finalTxt = '';
      rec.onstart = function () { listening = true; setUi(); };
      rec.onresult = function (e) {
        var interim = '';
        for (var i = e.resultIndex; i < e.results.length; i++) {
          var r = e.results[i];
          if (r.isFinal) finalTxt += r[0].transcript; else interim += r[0].transcript;
        }
        var q = $('exbAIq'); if (q) q.value = (finalTxt + ' ' + interim).trim();
      };
      rec.onerror = function (e) {
        var c = e && e.error;
        if (c === 'not-allowed' || c === 'service-not-allowed') { wantListen = false; cfg.hands = false; save(); toast('Micro refusé : autorisez le micro pour ce site dans les réglages du navigateur.', 'warn'); }
        else if (c === 'network') { wantListen = false; toast('La reconnaissance vocale demande internet. Vérifiez votre connexion.', 'warn'); }
        else if (c === 'audio-capture') { wantListen = false; toast('Aucun micro détecté sur cet appareil.', 'warn'); }
      };
      rec.onend = function () {
        listening = false; setUi();
        var t = finalTxt.trim(); finalTxt = '';
        if (t) onFinal(t);
        else if (cfg.hands && wantListen && $('exbAI')) schedule(600);
      };
      rec.start();
    } catch (e) { listening = false; setUi(); toast('Impossible de démarrer le micro : ' + (e && e.message || e), 'warn'); }
  }

  /* ---------- moteur Android (Capacitor) ---------- */
  async function startNative() {
    var P = nat(); if (!P) return;
    try {
      try { var av = await P.available(); if (av && av.available === false) { toast('La reconnaissance vocale n’est pas disponible sur ce téléphone.', 'warn'); return; } } catch (e) {}
      var perm = await P.checkPermissions().catch(function () { return {}; });
      if (!perm || perm.speechRecognition !== 'granted') perm = await P.requestPermissions();
      if (!perm || perm.speechRecognition !== 'granted') { wantListen = false; cfg.hands = false; save(); toast('Micro refusé : autorisez-le dans les réglages Android de l’application.', 'warn'); return; }
      nativeLast = '';
      nativeSub.forEach(function (s) { try { s.remove(); } catch (e) {} }); nativeSub = [];
      nativeSub.push(await P.addListener('partialResults', function (ev) {
        var m = ev && ev.matches && ev.matches[0]; if (m) { nativeLast = m; var q = $('exbAIq'); if (q) q.value = m; }
      }));
      nativeSub.push(await P.addListener('listeningState', function (ev) {
        if (ev && ev.status === 'stopped') { listening = false; setUi(); var t = nativeLast; nativeLast = ''; if (t) onFinal(t); else if (cfg.hands && wantListen && $('exbAI')) schedule(600); }
      }));
      listening = true; setUi();
      await P.start({ language: cfg.lang, maxResults: 1, partialResults: true, popup: false, prompt: '' });
    } catch (e) { listening = false; setUi(); toast('Micro indisponible : ' + (e && e.message || e), 'warn'); }
  }

  function schedule(ms) { clearTimeout(restartT); restartT = setTimeout(function () { if (cfg.hands && wantListen && !listening && !speaking && $('exbAI')) startListen(); }, ms || 400); }

  function startListen() {
    if (listening) return;
    var e = engine();
    if (!e) { toast('Votre navigateur ne gère pas la reconnaissance vocale. Utilisez Chrome ou Edge, ou l’application Android.', 'warn'); return; }
    try { w.speechSynthesis && w.speechSynthesis.cancel(); } catch (x) {}
    wantListen = true;
    if (e === 'native') startNative(); else startWeb();
  }
  function stopListen() {
    wantListen = false; clearTimeout(restartT);
    try { if (rec) rec.stop(); } catch (e) {}
    try { var P = nat(); if (P) P.stop(); } catch (e) {}
    listening = false; setUi();
  }

  /* ---------- lecture à voix haute ---------- */
  function speakText(t) {
    try {
      var S = w.speechSynthesis; if (!S || !w.SpeechSynthesisUtterance) { if (cfg.hands && wantListen) schedule(300); return; }
      t = String(t || '').replace(/[•⚡⚙️✅✓🔒🔌⚠️]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 600);
      if (!t) return;
      S.cancel();
      var u = new w.SpeechSynthesisUtterance(t); u.lang = cfg.lang; u.rate = 1;
      speaking = true; if (listening) { try { rec && rec.stop(); } catch (e) {} }
      var done = function () { speaking = false; if (cfg.hands && wantListen && $('exbAI')) schedule(500); };
      u.onend = done; u.onerror = done;
      S.speak(u);
    } catch (e) { speaking = false; }
  }

  /* suit les réponses de l'assistant : lecture et reprise de l'écoute */
  var logObs = null, tmr = 0;
  function lastAnswer() {
    var log = $('exbAIlog'); if (!log) return null;
    for (var i = log.children.length - 1; i >= 0; i--) {
      var c = log.children[i], st = c.getAttribute('style') || '';
      if (/margin-left:30px/.test(st)) return null;                 /* dernier message = celui de l'utilisateur : réponse pas encore arrivée */
      if (/margin-right:30px/.test(st)) return c;
    }
    return null;
  }
  function onLogChange() {
    clearTimeout(tmr);
    tmr = setTimeout(function () {
      var c = lastAnswer(); if (!c) return;
      var t = (c.textContent || '').trim();
      if (!t || t === '…' || t === lastSpoken) return;
      lastSpoken = t;
      if (cfg.speak || cfg.hands) speakText(t); else if (cfg.hands && wantListen) schedule(500);
    }, 450);
  }

  /* ---------- construction de l'interface dans la fenêtre de l'assistant ---------- */
  function btn(txt, title, fn) {
    var b = d.createElement('button'); b.type = 'button'; b.textContent = txt; b.title = title; b.onclick = fn;
    b.style.cssText = 'border:0;border-radius:10px;padding:8px 11px;font-size:16px;cursor:pointer;background:#173565;color:#fff;flex:none';
    return b;
  }
  function build() {
    var panel = $('exbAI'); if (!panel || panel.getAttribute('data-voix') === '1') return;
    var q = $('exbAIq'), clr = $('exbAIclr'); if (!q || !clr) return;
    panel.setAttribute('data-voix', '1');
    lastSpoken = (function () { var c = lastAnswer(); return c ? (c.textContent || '').trim() : ''; })();
    if (engine()) {
      els.mic = btn('🎤', 'Parler à l’assistant', function () { if (listening) { cfg.hands = false; save(); stopListen(); } else startListen(); });
      q.parentNode.insertBefore(els.mic, q);
    }
    els.hands = btn('🎧', 'Mains libres', function () {
      if (!engine()) { toast('Reconnaissance vocale indisponible ici (Chrome, Edge ou application Android).', 'warn'); return; }
      cfg.hands = !cfg.hands; if (cfg.hands) cfg.speak = true; save(); setUi();
      if (cfg.hands) startListen(); else stopListen();
    });
    els.speak = btn('🔊', 'Lire les réponses', function () { cfg.speak = !cfg.speak; if (!cfg.speak) { try { w.speechSynthesis.cancel(); } catch (e) {} } save(); setUi(); });
    [els.hands, els.speak].forEach(function (b) { b.style.cssText += ';padding:4px 8px;font-size:15px;background:transparent;color:inherit;margin-right:2px'; clr.parentNode.insertBefore(b, clr); });
    var log = $('exbAIlog');
    if (log) { if (logObs) logObs.disconnect(); logObs = new MutationObserver(onLogChange); logObs.observe(log, { childList: true, subtree: true, characterData: true }); }
    setUi();
    if (cfg.hands && engine()) setTimeout(startListen, 500);
  }
  function teardown() {
    stopListen(); try { w.speechSynthesis && w.speechSynthesis.cancel(); } catch (e) {}
    if (logObs) { logObs.disconnect(); logObs = null; }
    nativeSub.forEach(function (s) { try { s.remove(); } catch (e) {} }); nativeSub = [];
    els = {};
  }

  var present = false;
  new MutationObserver(function () {
    var now = !!$('exbAI');
    if (now && !present) { present = true; build(); }
    else if (now && present) build();
    else if (!now && present) { present = false; teardown(); }
  }).observe(d.documentElement, { childList: true, subtree: true });

  w.EXBVOIX = { cfg: function () { return cfg; }, engine: engine, start: startListen, stop: stopListen, speak: speakText };
})(window, document);
