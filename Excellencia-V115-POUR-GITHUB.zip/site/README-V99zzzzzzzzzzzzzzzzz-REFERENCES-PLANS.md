# Références automatiques des plans (calcul → Plans → 3D BIM)

## Avant
Après l'export d'un plan depuis le calcul de structure (DXF ou IFC), il fallait, dans Architecture › Plans › « Ajouter un fichier », retaper la référence du plan et la note de version.

## Maintenant
- **À l'export** (menu « Format DXF / BIM » du calcul) : chaque fichier porte sa référence, **stable d'un export à l'autre** : `STR-<OUVRAGE>-<TYPE>` (ex. `STR-RESIDENCE-A-PLAN`, `-COFF` coffrage, `-DAL` dalles, `-3D`, `-BIM`). DXF : commentaire (code 999) en tête de fichier ; IFC : texte dans `FILE_DESCRIPTION`. Ils restent lisibles par AutoCAD, Revit, etc. Le nom de l'ouvrage est celui du bâtiment.
- **À l'ajout dans Plans** : on choisit le fichier, la référence et la note (titre · date) se remplissent seules, avec « Indice suivant : A / B… ». Un fichier sans référence (autre logiciel) reçoit une référence déduite de son nom ; elle reste modifiable.
- **Rechargement** : un nouvel export du même ouvrage reprend la même référence, donc l'indice passe tout seul de A à B, C… (comparaison de versions possible).
- **3D** : un fichier IFC ajouté s'ouvre aussitôt dans le lecteur 3D BIM (bouton « 3D » toujours disponible dans la liste).
Limite : renommer le bâtiment change la référence (nouvelle série d'indices) ; la référence de l'ouvrage sert d'identifiant de série.
Test : `python3 tools/test-refs/test.py` (12/12).
