/* Excellencia Building V99v — typographie, tailles de texte, boutons uniformes, bandeau et boutons flottants discrets,
 * recherche en icône sur téléphone.
 * - Police : Inter si installée, sinon Segoe UI / police système, Arial en dernier recours (fonctionne hors connexion).
 * - Échelle uniforme + réglage « Taille du texte » (Petit / Normal / Grand) dans le menu du profil, mémorisé sur l'appareil.
 * - Écran uniquement : les documents (.paper, certificats, reçus, affiches), l'impression et les PDF ne changent pas.
 * AUCUNE donnée ni fonction existante n'est modifiée. */
(function(w,d){'use strict';
var KEY='exb_fs',NUDGE='exb_nudge_off',SC={s:.92,n:1,l:1.14},LB={s:'Petit',n:'Normal',l:'Grand'};
var P='html:root',F='Inter,"Segoe UI",system-ui,-apple-system,Roboto,"Helvetica Neue",Arial,sans-serif';
function px(n){return 'calc('+n+'px*var(--fs,1))'}
var X=':not(.paper *):not(.paperP *):not(.softwarePosterPaper *):not(.tpPaper *):not(#exbSplash *)';
function css(){return '@media screen{'+[
 'html{--fs:1}',
 P+' body,'+P+' #app,'+P+' button,'+P+' input,'+P+' select,'+P+' textarea{font-family:'+F+'}',
 P+' body,'+P+' #app{font-size:'+px(15)+';line-height:1.45;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}',
 P+' input'+X+','+P+' select'+X+','+P+' textarea'+X+'{font-size:'+px(14)+';min-height:40px;padding:9px 12px;border-radius:9px;line-height:1.35}',
 P+' textarea{min-height:72px}',
 P+' label'+X+'{font-size:'+px(13)+';font-weight:700;margin:10px 0 5px}',
 P+' .hint,'+P+' .msg,'+P+' .enterprise-muted{font-size:'+px(12.5)+';line-height:1.45}',
 P+' h2'+X+'{font-size:'+px(18)+';line-height:1.3;margin:0 0 14px}',
 P+' h3'+X+'{font-size:'+px(16)+';line-height:1.3}',
 P+' .tbl,'+P+' .enterprise-table,'+P+' table.tbl th,'+P+' table.tbl td{font-size:'+px(14)+'}',
 P+' .tbl th,'+P+' .tbl td,'+P+' .enterprise-table th,'+P+' .enterprise-table td{padding:9px 8px}',
 P+' .grid{grid-template-columns:minmax(280px,390px) minmax(0,1fr)}',P+' .grid>*{min-width:0}',P+' .localgrid{grid-template-columns:minmax(260px,360px) minmax(0,1fr)}',P+' .localgrid>*,'+P+' .enterprise-grid>*,'+P+' .exb-v51-grid>*{min-width:0}',P+' .tablewrap{max-width:100%;overflow:auto}',
 /* boutons : même hauteur, mêmes coins */
 P+' .primary,'+P+' .gold,'+P+' .muted,'+P+' .danger{min-height:40px;padding:9px 16px;border-radius:9px;font-size:'+px(14)+';font-weight:700;font-family:inherit;line-height:1.2}',
 P+' td .primary,'+P+' td .gold,'+P+' td .muted,'+P+' td .danger,'+P+' th .muted{min-height:32px;padding:6px 11px;font-size:'+px(13)+'}',
 /* cadre */
 P+' #exbSide .xs{font-size:'+px(14)+'}',
 P+' .xsf{font-size:'+px(12.5)+'}',
 P+' .xh-head p,'+P+' #exbHub p{font-size:'+px(15)+'}',
 P+' .xg .c b{font-size:'+px(15.5)+'}',P+' .xg .c small,'+P+' .xh-qa .q small{font-size:'+px(12.5)+'}',
 P+' #exbModBar .mb{font-size:'+px(13.5)+'}',
 P+' #exbCrumb{font-size:'+px(13.5)+'}',
 P+' .xh-k small,'+P+' .xh-k em,'+P+' .xh-act small{font-size:'+px(13)+'}',
 P+' .xh-act b,'+P+' .xh-card h3{font-size:'+px(15)+'}',
 P+' #exbStatus{font-size:'+px(12.5)+'}',
 P+' .xmenu button{font-size:'+px(14)+'}',
 /* bandeau « Connectez votre compte » : discret, en bas à droite, au-dessus de la barre d'état */
 P+' #exbNudge{left:270px!important;right:auto!important;bottom:44px!important;max-width:380px;font:'+px(13)+' '+F+'!important;padding:9px 12px!important;border-radius:12px!important;box-shadow:0 8px 24px #0004;opacity:.96}',
 P+' #exbNudge button{min-height:30px;padding:5px 10px;border-radius:8px;border:0;font:700 '+px(12.5)+' '+F+';cursor:pointer;background:#ffffff26;color:#fff}',
 P+' #exbNudge #nd_go{background:#c49a38}',
 /* boutons flottants : plus de superposition avec le menu ni le contenu */
 P+' #exbHelpBtn{left:auto!important;right:14px!important;bottom:128px!important;width:40px!important;height:40px!important;font-size:18px!important;opacity:.92}',
 P+' button[style*="right:14px"][style*="bottom:62px"]{bottom:92px!important}',
 /* pages des modules V67–V72 (boutons sans style, tableaux) */
 ["#exbV67","#exbV68","#exbV69","#exbPlansV70","#exb_v71_plans","#exb_v72_print"].map(function(i){return P+' '+i+' button:not([class])'}).join(',')+'{background:#e8edf5;color:#12254a;border:0;border-radius:9px;padding:9px 14px;font:700 '+px(13.5)+' '+F+';cursor:pointer;min-height:36px;margin:2px}',
 ["#exbV67","#exbV68","#exbV69","#exbPlansV70","#exb_v71_plans","#exb_v72_print"].map(function(i){return P+' '+i+' table'}).join(',')+'{width:100%;border-collapse:collapse;font-size:'+px(14)+'}',
 ["#exbV67","#exbV68","#exbV69","#exbPlansV70","#exb_v71_plans","#exb_v72_print"].map(function(i){return P+' '+i+' th,'+P+' '+i+' td'}).join(',')+'{text-align:left;padding:8px 8px;border-bottom:1px solid #e3e9f4}',
 /* recherche en icône sur téléphone */
 '#xbSearchBtn{display:none}',
 '@media(max-width:600px){#xbSearchBtn{display:block}',
 P+' #app>header .exb-pro-search{flex:none;margin:0;padding:0;max-width:none}',
 P+' #app>header .exb-pro-search input{display:none}',
 P+' #app>header .exb-pro-search.xopen{position:fixed;left:8px;right:8px;top:58px;z-index:90;background:#0f2e66;padding:8px;border-radius:12px;display:flex;box-shadow:0 12px 30px #0006}',
 P+' #app>header .exb-pro-search.xopen input{display:block;flex:1;width:100%}',
 P+' #exbNudge{left:8px!important;right:8px!important;max-width:none}}',
 '@media(max-width:900px){'+P+' #exbNudge{left:8px!important;right:8px!important;max-width:none}}',
 '}'].join('\n');
}
function inject(){if(d.getElementById('exbTypoCss'))return;var s=d.createElement('style');s.id='exbTypoCss';s.textContent=css();d.head.appendChild(s)}
function get(){var v=null;try{v=w.localStorage.getItem(KEY)}catch(e){}return SC[v]?v:'n'}
function set(v){try{w.localStorage.setItem(KEY,v)}catch(e){}apply(v)}
function apply(v){d.documentElement.style.setProperty('--fs',String(SC[v]||1));var b=d.getElementById('xbSize');if(b)b.textContent='🔠 Taille du texte : '+LB[v||get()]}
function cycle(){var o=['s','n','l'],v=get();set(o[(o.indexOf(v)+1)%3])}
function mount(){
 var m=d.getElementById('xbMenu');
 if(m&&!d.getElementById('xbSize')){var b=d.createElement('button');b.id='xbSize';b.type='button';b.onclick=function(e){e.stopPropagation();cycle()};m.insertBefore(b,m.lastElementChild);apply(get())}
 var top=d.getElementById('xbTop');
 if(top&&!d.getElementById('xbSearchBtn')){var sb=d.createElement('button');sb.id='xbSearchBtn';sb.className='xb';sb.type='button';sb.setAttribute('aria-label','Rechercher');sb.textContent='🔎';
  sb.onclick=function(e){e.stopPropagation();var sr=d.querySelector('.exb-pro-search');if(!sr)return;var on=sr.classList.toggle('xopen');if(on){var i=sr.querySelector('input');if(i)setTimeout(function(){i.focus()},30)}};
  top.insertBefore(sb,top.firstChild)}
 /* bandeau : fermé = ne revient pas avant 24 h */
 var n=d.getElementById('exbNudge');
 if(n&&!n.__x){n.__x=1;var off=0;try{off=+w.localStorage.getItem(NUDGE)||0}catch(e){}
  if(Date.now()-off<864e5){n.remove();return}
  var x=d.getElementById('nd_x');if(x)x.addEventListener('click',function(){try{w.localStorage.setItem(NUDGE,String(Date.now()))}catch(e){}})}}
function start(){inject();apply(get());mount();setInterval(mount,1500);
 d.addEventListener('click',function(e){var sr=d.querySelector('.exb-pro-search.xopen');if(sr&&!e.target.closest('.exb-pro-search,#xbSearchBtn'))sr.classList.remove('xopen')});
 d.addEventListener('keydown',function(e){if(e.key==='Escape'){var sr=d.querySelector('.exb-pro-search.xopen');if(sr)sr.classList.remove('xopen')}})}
w.EXB_TYPO={set:set,get:get,cycle:cycle,version:'V99v'};
try{d.documentElement.style.setProperty('--fs',String(SC[get()]))}catch(e){}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',start);else start();
})(window,document);
