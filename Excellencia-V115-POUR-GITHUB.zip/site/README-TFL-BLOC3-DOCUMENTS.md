# TFL — bloc 3/5 : envoi de documents (plan, chapitres, version finale)

**Étudiant** (Espace TFL › Documents, dossier accepté) : choisit le type (plan de travail, chapitre, version finale, autre), un titre, une note facultative et le fichier (PDF, Word, OpenDocument, PowerPoint, Excel, JPG, PNG ; 15 Mo au plus). L'envoi se fait par morceaux de 900 Ko avec un pourcentage d'avancement (adapté à une connexion lente). Il voit ensuite l'état de chaque document : Déposé — en attente de lecture, À corriger (avec le commentaire), Validé. Il télécharge ses fichiers et ceux que son encadreur lui renvoie, et peut supprimer ses envois tant qu'ils ne sont pas validés. Dossier clos : lecture seule. Pastille sur le menu quand un document est à corriger ou qu'un document de l'encadreur est arrivé.

**Encadreur** (Espace TFL › Documents) : pour chacun de ses étudiants, la liste des documents, le téléchargement, un commentaire puis **Valider** ou **À corriger** (commentaire obligatoire), et « Envoyer un document à l'étudiant » (correction, chapitre annoté…). Pastille = documents déposés à lire. Il ne voit que les dossiers de son instantané publié (si vous le retirez d'un dossier, il n'y a plus accès).

**Administration** (logiciel › TFL › dossier › 📎 Documents) : « 📥 Charger les documents du serveur » liste les documents du dossier ; ⬇ Télécharger, Valider / À corriger (commentaire), Supprimer. Les décisions sont lues directement sur le serveur : pas besoin de republier.

**Sécurité :** les fichiers restent dans la base du serveur (jamais dans un dossier public du site) ; chaque appel vérifie l'identifiant et le mot de passe (blocage après 5 essais) ; un étudiant ne voit que son dossier, un encadreur que ses étudiants. Le serveur contrôle l'extension ET la signature du fichier (un « .pdf » qui n'est pas un PDF est refusé). Limites par accès : 20 envois par heure, 60 documents, 150 Mo.

**À exécuter une fois :** `supabase/migration-tfl-bloc3-documents.sql` (prérequis : migration-v99zzt-tfl-portails.sql ; indépendant des blocs 1 et 2). Réexécutable. Contrôle : `select proname from pg_proc where proname like 'tfl_document%';` → 11 lignes.

**Fichiers modifiés :** `tfl-portail.html`, `exb-tfl.js`, `sw.js`. Test : `node tools/test-tfl/test-bloc3.js`.
**Limites :** serveur simulé uniquement (SQL non exécuté sur un vrai Supabase) : essai à faire avec un vrai fichier de 2 à 3 Mo depuis un téléphone. Les fichiers occupent la base de données (plan gratuit Supabase : 500 Mo au total) : surveillez l'espace et supprimez les anciens documents. Pas de notification automatique à l'encadreur ou à l'administration : ils voient les nouveautés en ouvrant leur page Documents. Les fichiers .exe, .zip, vidéos… sont refusés.

**Noms des tables :** `tfl_envois` et `tfl_envois_parties` (et non `tfl_documents`, nom déjà pris par l'ancien script `migration-v99zzq-tfl.sql` : avec cette ancienne table présente, la création était sautée et l'index échouait avec « column dossier does not exist »). Contrôle des tables : `select tablename, rowsecurity from pg_tables where tablename like 'tfl_envois%';` → 2 lignes, rowsecurity = true.
