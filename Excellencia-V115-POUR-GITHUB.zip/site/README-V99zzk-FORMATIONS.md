# Excellencia Building — V99zzk : catalogue des formations élargi (18 → 35)

## Formations ajoutées (17)
Revit MEP · Navisworks · Advance Steel · STAAD.Pro · SAFE · Idea StatiCa · Rhino et Grasshopper · Blender · Enscape · D5 Render · V-Ray · Photoshop pour l’architecture · QGIS · DIALux · Power BI · BIM Management · Béton armé (Eurocode 2)

Chacune a son programme de 15 à 16 modules (se sélectionnent dans la fiche Formation), ses matières TP/TD et une cotation par défaut.

## Où elles apparaissent
- Liste des formations programmées et menu « Formation » de la fiche formation.
- Formulaires d’inscription (en ligne, hors connexion, fiche participant, spécialités du formateur).
- Matières TP/TD et cotation par module.

## Mise à jour d’une installation existante
Au premier chargement, les 17 nouvelles formations sont ajoutées une seule fois à la liste déjà enregistrée (statut ACTIVE, durée/prix/dates à renseigner). Une formation supprimée ensuite n’est pas recréée. Les formations existantes ne sont pas modifiées.

## Non inclus
Les QCM restent ceux des 16 thèmes existants ; les 17 nouvelles formations n’ont pas encore de banque QCM.

## V99zzl — banques QCM séparées par formation
- Un fichier par formation dans `qcm/` (ex. `qcm/autocad.js`) ; `qcm/registre.js` les rassemble et fixe la cible de 300 questions par formation.
- Chaque fichier contient les 3 niveaux (débutant, intermédiaire, avancé). Ajouter des questions = les ajouter dans le fichier de la formation, sans toucher au reste.
- La liste du QCM affiche toutes les formations avec leur compteur (ex. « AutoCAD (20/300) ») ; celles sans questions sont marquées « en préparation ».
- Tirages possibles : 5, 10, 20, 30, 50 ou 100 questions.
- État : 16 formations × 20 questions = 320 ; 19 formations à 0. Cible totale : 35 × 300 = 10 500.

## V99zzm — QCM AutoCAD et SketchUp (lot 2)
- Nouveaux fichiers `qcm/autocad-lot2.js` et `qcm/sketchup-lot2.js` (format compact : question, bonne réponse, 3 mauvaises ; l’ordre est mélangé à chaque tirage).
- AutoCAD : 88/300 (45 débutant, 27 intermédiaire, 16 avancé). SketchUp : 72/300 (40 / 19 / 13).
- Pour continuer : ajouter des lots `*-lot3.js` ; les doublons de questions sont ignorés automatiquement.

## V99zzn — QCM AutoCAD et SketchUp (lot 3)
- Nouveaux fichiers `qcm/autocad-lot3.js` et `qcm/sketchup-lot3.js`.
- AutoCAD : 136/300 (65 débutant, 45 intermédiaire, 26 avancé). SketchUp : 116/300 (60 / 35 / 21).

## V99zzo — Intégration du pack « excellencia_building_qcm_logiciels_btp.json »
- Le pack (20 questions avec explications) est intégré dans `qcm/import-btp-1.js` ; l’original est conservé dans `qcm/sources/`.
- 11 questions équivalentes à des questions déjà présentes (AutoCAD, SketchUp, Revit, Twinmotion, Robot, Excel) remplacent l’ancienne version : aucun doublon.
- 9 nouvelles questions ajoutées : Revit (2), Twinmotion (1), Robot Structural Analysis (2), Excel professionnel (1), BIM Management (1, IFC), Génie civil et bâtiment (2, méthodes BTP).
- Les explications s’affichent maintenant dans la correction du QCM pour toute question qui en possède une.
- `EXBQCM_BANKS.importPack(pack, config)` permet d’intégrer d’autres packs de même format.
- Total de la banque : 541 questions.

## V99zzp — Lots QCM : AutoCAD (lot 4), SketchUp (lot 4), Robot Structural Analysis (lot 2)
- AutoCAD : 164/300 (75 débutant, 57 intermédiaire, 32 avancé). SketchUp : 143/300 (70 / 46 / 27). Robot Structural Analysis : 72/300 (33 / 25 / 14).
- Total de la banque : 646 questions.
