EXCELLENCIA BUILDING V70 — PLANS, COUPES & STRUCTURE

Ajout : registre des plans et coupes intégré au parcours Études/BIM.

Types couverts :
- Plans architecturaux, coupes, façades, situation, masse
- Plans de fondations, coffrage, ferraillage, charpente
- Détails structurels, toiture, VRD, électricité, plomberie, CVC

Chaque livrable possède : projet, référence, titre, discipline, niveau/zone,
échelle, indice, statut CDE, responsable, référence CDE, date et liaison à une note de calcul.

Migration Supabase : voir README-V75
