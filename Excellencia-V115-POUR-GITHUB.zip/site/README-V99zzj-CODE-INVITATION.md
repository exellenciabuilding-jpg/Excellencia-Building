# V99zzj — Un invité n'a besoin que de son CODE D'INVITATION

## Pourquoi « Code invalide ou modifié » ?
Il existe deux codes différents :
- **Code d'activation** (long, signé, généré avec 🔑) : déverrouille le logiciel sur un appareil.
- **Code d'invitation** (8 caractères, ex. `eaaa5313`) : sert à rejoindre l'entreprise après création du compte.

L'écran 🔒 n'acceptait que le premier. L'ami collait le second → refus.

## Ce qui change
L'écran de verrouillage accepte maintenant le **code d'invitation**. Le serveur renvoie l'abonnement de l'entreprise, l'appareil se déverrouille, puis l'invité crée son compte et rejoint l'entreprise automatiquement (par son e-mail invité, sinon avec le code mémorisé).

## Mise en service (ordre)
1. Supabase › SQL Editor : exécuter `supabase/migration-v99zzj-activation-invitation.sql` (fichier fourni à part ; réexécutable).
2. Déployer le dossier (Netlify). Cache mis à jour : `exb-v99zzj-code-invitation-1`.
3. **Sur votre appareil administrateur** (clé privée 🔑 présente), ouvrir une fois Paramètres › 👥 Équipe : l'abonnement signé de l'entreprise (validité 400 jours, renouvelé tous les 30 jours) est enregistré sur le serveur. Sans cette étape, le code d'invitation répond « Aucun abonnement n'est encore enregistré ».
   - Entreprises clientes créées par l'espace propriétaire : leur dernier code d'abonnement est déjà utilisé automatiquement.

## Procédure pour inviter un ami
1. Équipe › ➕ Inviter : nom, e-mail, rôle, fonction › envoyer le message (WhatsApp).
2. L'ami ouvre le lien. Si l'écran 🔒 s'affiche : il saisit **uniquement** le code d'invitation › Activer.
3. Il crée son compte avec **l'adresse e-mail invitée** : il rejoint l'entreprise avec le rôle et la fonction prévus.

## Sécurité
- Le code débloque seulement l'interface ; les données restent protégées par les droits de l'entreprise (membres).
- Limite anti-devinette : 40 essais ratés / 10 min (global). Abonnement suspendu côté propriétaire = refus.
- Renouveler le code (Base partagée › Renouveler) invalide les anciens messages d'invitation.

## Fichiers touchés
`exb-license.js`, `exb-equipe.js`, `exb-db.js`, `sw.js`, `supabase/migration-v99zzj-activation-invitation.sql` (nouveau).
