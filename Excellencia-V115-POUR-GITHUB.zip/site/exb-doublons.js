/* Excellencia Building — V99 DOUBLONS : « un seul enregistrement, un seul numéro, un seul QR par document ».
 * 1) DÉTECTION (lecture seule) : ajoute des règles au moteur d'intelligence de l'accueil (EXBI) :
 *    - personnes enregistrées deux fois : même matricule, même e-mail, même nom dans la même formation ;
 *    - formateurs en double (téléphone, e-mail ou nom) ;
 *    - certificats et reçus : même numéro utilisé deux fois, même personne certifiée / payée deux fois pour la même chose ;
 *    - un même numéro (donc un même QR) porté par deux documents différents (devis, facture, certificat, reçu).
 * 2) PRÉVENTION : avant d'enregistrer une NOUVELLE fiche participant, un certificat ou un reçu qui ressemble à un document
 *    déjà enregistré, une fenêtre le signale et laisse choisir. Rien n'est supprimé ni fusionné automatiquement.
 * Pour retirer : supprimer la balise <script src="exb-doublons.js">. */
(function (w, d) {
  'use strict';

  /* ---------- outils communs ---------- */
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function digits(s) { var v = String(s == null ? '' : s).replace(/\D+/g, ''); return v.length > 9 ? v.slice(-9) : v; } /* 9 derniers chiffres : +243 81… et 081… sont le même numéro */
  function jlist(key) { /* lit comme le logiciel : pont EXBS, puis exbStorage (préfixé), puis localStorage brut */
    var a = null, v;
    try { if (w.EXBS && w.EXBS.get) a = w.EXBS.get(key); } catch (e) {}
    if (!a || !a.length) { try { var st = (typeof exbStorage !== 'undefined') ? exbStorage : null; if (st) { v = JSON.parse(st.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } } catch (e) {} }
    if (!a || !a.length) { try { v = JSON.parse(w.localStorage.getItem(key) || '[]'); if (Array.isArray(v)) a = v; } catch (e) {} }
    return (a || []).filter(function (x) { return x && typeof x === 'object'; });
  }
  function pName(p) { return p.name || p.full_name || [p.first_name, p.last_name].filter(Boolean).join(' ') || ''; }
  function live() { return function (x) { return !/^(ANNUL|SUPPR|INVALID)/i.test(String(x.status || '')); }; }
  function osa(a, b, max) { /* distance d'édition (avec transposition), arrêtée au-delà de max */
    var la = a.length, lb = b.length; if (Math.abs(la - lb) > max) return max + 1;
    var m = [], i, j; for (i = 0; i <= la; i++) m[i] = [i]; for (j = 1; j <= lb; j++) m[0][j] = j;
    for (i = 1; i <= la; i++) for (j = 1; j <= lb; j++) {
      m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      if (i > 1 && j > 1 && a.charAt(i - 1) === b.charAt(j - 2) && a.charAt(i - 2) === b.charAt(j - 1)) m[i][j] = Math.min(m[i][j], m[i - 2][j - 2] + 1);
    }
    return m[la][lb];
  }
  function sortedName(s) { return norm(s).split(' ').filter(Boolean).sort().join(' '); } /* « Kasongo Jean » = « Jean Kasongo » */
  function nearName(a, b) { /* même nom à une faute de frappe près (noms assez longs seulement : évite de confondre deux noms courts) */
    var x = sortedName(a), y = sortedName(b); if (!x || !y || x === y) return false;
    return x.length >= 8 && osa(x, y, 1) <= 1;
  }
  function bdate(p) { return String(p.birth_date || p.birthdate || p.dob || '').trim(); }
  function say(t) { try { if (w.notify) w.notify(t, 'warn', 7000); } catch (e) {} }

  /* ---------- recherche de ressemblances (utilisée aussi par la prévention) ---------- */
  function similarPerson(rec, all, selfId) {
    var nm = norm(pName(rec)), ph = digits(rec.phone), em = norm(rec.email), tr = norm(rec.training), mt = norm(rec.matricule);
    var out = [];
    all.forEach(function (p) {
      if (selfId && p.participant_id === selfId) return;
      var why = '';
      if (mt && norm(p.matricule) === mt) why = 'même matricule';
      else if (em && norm(p.email) === em) why = 'même e-mail';
      else if (ph.length >= 8 && digits(p.phone) === ph && nm && norm(pName(p)).split(' ')[0] === nm.split(' ')[0]) why = 'même téléphone et même prénom/nom';
      else if (nm && norm(pName(p)) === nm && tr && norm(p.training) === tr) why = 'même nom dans la même formation';
      else if (nm && sortedName(pName(p)) === sortedName(pName(rec)) && tr && norm(p.training) === tr) why = 'même nom (prénom et nom inversés) dans la même formation';
      else if (nm && bdate(rec) && bdate(p) === bdate(rec) && (norm(pName(p)) === nm || sortedName(pName(p)) === sortedName(pName(rec)))) why = 'même nom et même date de naissance';
      else if (nm && nearName(pName(p), pName(rec)) && tr && norm(p.training) === tr) why = 'nom presque identique (faute de frappe ?) dans la même formation';
      else if (nm && nearName(pName(p), pName(rec)) && ((ph.length >= 8 && digits(p.phone) === ph) || (em && norm(p.email) === em))) why = 'nom presque identique et même téléphone ou e-mail';
      if (why) out.push({ p: p, why: why });
    });
    return out;
  }
  function similarCert(c, all) {
    var h = norm(c.holder), t = norm(c.training), ok = live();
    if (!h || !t) return [];
    return all.filter(function (x) { return ok(x) && norm(x.holder) === h && norm(x.training) === t; });
  }
  function similarReceipt(r, all) {
    var p = norm(r.participant), t = norm(r.training);
    if (!p || !t) return [];
    return all.filter(function (x) {
      return norm(x.participant) === p && norm(x.training) === t && String(x.issued_date || '') === String(r.issued_date || '') &&
        String(x.registration_fee || '') === String(r.registration_fee || '') && String(x.training_fee || '') === String(r.training_fee || '') &&
        String(x.registration_status || '') === String(r.registration_status || '') && String(x.training_status || '') === String(r.training_status || '');
    });
  }

  var RULES = [];
  /* ---------- 1) règles de détection pour l'accueil intelligent ---------- */
  function boot(n) {
    var I = w.EXBI; if (!I || !I.addRule) { if ((n || 0) < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.doublons) return; I.doublons = true;
    function F(sev, mod, msg, col, id) { return { sev: sev, mod: mod, msg: msg, ref: { col: col, id: id } }; }
    var add0 = I.addRule; function reg(rule) { RULES.push(rule); return add0.call(I, rule); }

    reg({ id: 'dup.personnes', check: function () {
      var out = [], P = jlist('exb_participants'), seenM = {}, seenE = {}, seenN = {};
      P.forEach(function (p) {
        var lab = pName(p) || p.participant_id || '?', m = norm(p.matricule), e = norm(p.email), k = norm(pName(p)) + '|' + norm(p.training);
        if (m) { if (seenM[m]) out.push(F('erreur', 'Participants', 'Même matricule sur deux fiches : ' + pName(seenM[m]) + ' et ' + lab + ' (' + (p.matricule) + ')', 'exb_participants', p.participant_id)); else seenM[m] = p; }
        if (e) { if (seenE[e]) out.push(F('alerte', 'Participants', 'Même e-mail sur deux fiches : ' + pName(seenE[e]) + ' et ' + lab, 'exb_participants', p.participant_id)); else seenE[e] = p; }
        if (norm(pName(p)) && norm(p.training)) { if (seenN[k]) out.push(F('alerte', 'Participants', 'Déjà inscrit(e) deux fois à la même formation : ' + lab + ' (' + p.training + ')', 'exb_participants', p.participant_id)); else seenN[k] = p; }
      });
      return out;
    } });

    /* personnes proches : prénom/nom inversés, même nom + même date de naissance, nom presque identique dans la même formation */
    reg({ id: 'dup.personnes.proches', check: function () {
      var out = [], P = jlist('exb_participants'), byT = {}, seenS = {}, seenB = {}, n = 0;
      P.forEach(function (p) {
        var lab = pName(p) || p.participant_id || '?', ss = sortedName(pName(p)), tr = norm(p.training), bd = bdate(p);
        if (!ss) return;
        if (bd) { var kb = ss + '|' + bd; if (seenB[kb]) out.push(F('alerte', 'Participants', 'Même nom et même date de naissance : ' + pName(seenB[kb]) + ' et ' + lab, 'exb_participants', p.participant_id)); else seenB[kb] = p; }
        if (tr) { var ks = ss + '|' + tr; if (seenS[ks] && norm(pName(seenS[ks])) !== norm(pName(p))) out.push(F('alerte', 'Participants', 'Prénom et nom inversés dans la même formation : ' + pName(seenS[ks]) + ' / ' + lab + ' (' + p.training + ')', 'exb_participants', p.participant_id)); else if (!seenS[ks]) seenS[ks] = p; (byT[tr] = byT[tr] || []).push(p); }
      });
      Object.keys(byT).forEach(function (t) {
        var L = byT[t]; if (L.length > 400) return;                       /* garde-fou de performance */
        for (var i = 0; i < L.length && n < 40; i++) for (var j = i + 1; j < L.length && n < 40; j++) {
          if (nearName(pName(L[i]), pName(L[j]))) { n++; out.push(F('info', 'Participants', 'Noms presque identiques dans la même formation (faute de frappe ?) : ' + pName(L[i]) + ' / ' + pName(L[j]) + ' (' + (L[i].training || '') + ')', 'exb_participants', L[j].participant_id)); }
        }
      });
      return out;
    } });

    reg({ id: 'dup.formateurs', check: function () {
      var out = [], seen = {};
      jlist('exb_trainers').forEach(function (t) {
        var lab = t.name || t.full_name || t.id || '?', ph = digits(t.phone), keys = [];
        if (ph.length >= 8) keys.push('t' + ph); if (t.email) keys.push('e' + norm(t.email)); if (norm(lab)) { keys.push('n' + norm(lab)); keys.push('s' + sortedName(lab)); }
        var hit = null; keys.forEach(function (k) { if (!hit && seen[k]) hit = seen[k]; });
        if (hit) out.push(F('alerte', 'Formateurs', 'Formateur possiblement enregistré deux fois : ' + (hit.name || hit.full_name || '?') + ' et ' + lab, 'exb_trainers', t.id));
        else keys.forEach(function (k) { seen[k] = t; });
      });
      return out;
    } });

    reg({ id: 'dup.certificats', check: function () {
      var out = [], C = jlist('exb_certificates'), seenN = {}, seenH = {}, ok = live();
      C.forEach(function (c) {
        var no = norm(c.cert_no), h = norm(c.holder) + '|' + norm(c.training);
        if (no) { if (seenN[no]) out.push(F('erreur', 'Certificats', 'Le numéro ' + c.cert_no + ' est utilisé par deux certificats (un numéro = un QR)', 'exb_certificates', c.cert_no)); else seenN[no] = c; }
        if (ok(c) && norm(c.holder) && norm(c.training)) { if (seenH[h]) out.push(F('alerte', 'Certificats', 'Deux certificats valides pour ' + c.holder + ' (' + c.training + ') : ' + seenH[h].cert_no + ' et ' + c.cert_no, 'exb_certificates', c.cert_no)); else seenH[h] = c; }
      });
      return out;
    } });

    reg({ id: 'dup.recus', check: function () {
      var out = [], R = jlist('exb_receipts'), seenN = {}, seenC = {};
      R.forEach(function (r) {
        var no = norm(r.receipt_no), key = [r.participant, r.training, r.issued_date, r.registration_fee, r.training_fee, r.registration_status, r.training_status].map(norm).join('|');
        if (no) { if (seenN[no]) out.push(F('erreur', 'Reçus', 'Le numéro ' + r.receipt_no + ' est utilisé par deux reçus (un numéro = un QR)', 'exb_receipts', r.receipt_no)); else seenN[no] = r; }
        if (norm(r.participant) && norm(r.training)) { if (seenC[key]) out.push(F('alerte', 'Reçus', 'Reçu identique enregistré deux fois pour ' + r.participant + ' (' + seenC[key].receipt_no + ' et ' + r.receipt_no + ')', 'exb_receipts', r.receipt_no)); else seenC[key] = r; }
      });
      return out;
    } });

    /* un même numéro (= un même QR) ne doit pas se retrouver sur deux documents de natures différentes */
    reg({ id: 'doc.numeros', check: function () {
      var out = [], map = {};
      function add(kind, no, lab) { var k = norm(no); if (!k) return; (map[k] = map[k] || []).push({ kind: kind, no: no, lab: lab }); }
      jlist('exb_quotes').forEach(function (q) { add('Devis', q.no || q.number, 'devis ' + (q.no || q.number)); });
      jlist('exb_invoices').forEach(function (i) { add('Facture', i.no, 'facture ' + i.no); });
      jlist('exb_certificates').forEach(function (c) { add('Certificat', c.cert_no, 'certificat ' + c.cert_no); });
      jlist('exb_receipts').forEach(function (r) { add('Reçu', r.receipt_no, 'reçu ' + r.receipt_no); });
      Object.keys(map).forEach(function (k) {
        var L = map[k]; if (L.length < 2) return;
        var kinds = {}; L.forEach(function (x) { kinds[x.kind] = 1; });
        if (Object.keys(kinds).length < 2) return; /* même nature : déjà signalé par les règles ci-dessus ou par « mêmes numéros » des devis et factures */
        out.push(F('erreur', 'Documents', 'Le même numéro ' + L[0].no + ' est porté par ' + Object.keys(kinds).join(' et ') + ' : le QR ne serait plus unique', 'exb_documents', L[0].no));
      });
      return out;
    } });
    try { I.run && I.run(); } catch (e) {}
  }
  boot(0);

  /* ---------- 2) prévention : avertir avant d'enregistrer un doublon ---------- */
  function wrap(name, fn) {
    var o = w[name]; if (typeof o !== 'function') return false;
    if (o.__exbDup) return true;
    var n = fn(o); n.__exbDup = true; w[name] = n; return true;
  }
  function tryWrap(n) {
    var a = wrap('saveParticipant', function (o) { return function (opts) {
      try {
        opts = opts || {};
        var idEl = d.getElementById('participant_id'), isNew = idEl && !String(idEl.value || '').trim();
        if (isNew && !opts.quiet) {
          var rec = { name: (d.getElementById('p_name') || {}).value, phone: (d.getElementById('p_phone') || {}).value, email: (d.getElementById('p_email') || {}).value, training: (w.participantTrainingValue ? w.participantTrainingValue() : '') };
          var hits = similarPerson(rec, jlist('exb_participants'), '');
          if (hits.length) {
            var h = hits[0], p = h.p;
            var ok = w.confirm('⚠️ Cette personne semble déjà enregistrée (' + h.why + ') :\n\n' + pName(p) + (p.matricule ? ' — matricule ' + p.matricule : '') + (p.training ? ' — ' + p.training : '') + (p.participant_id ? ' — ' + p.participant_id : '') + '\n\nOK = enregistrer quand même (ce n’est pas la même personne)\nAnnuler = ne pas créer de doublon');
            if (!ok) { var m = d.getElementById('pm_local'); if (m) m.textContent = 'Enregistrement annulé : cette personne existe déjà (' + pName(p) + ').'; return null; }
          }
        }
      } catch (e) {}
      return o.apply(this, arguments);
    }; });
    var b = wrap('saveCert', function (o) { return function () {
      try {
        if (typeof w.certData === 'function') {
          var c = w.certData(), same = similarCert(c, jlist('exb_certificates'));
          if (same.length) {
            var x = same[same.length - 1];
            var keep = w.confirm('⚠️ Un certificat valide existe déjà pour ' + c.holder + ' (' + c.training + ') :\nN° ' + x.cert_no + '\n\nUn document = un numéro = un QR.\nOK = ne pas créer de second certificat (l’existant est affiché)\nAnnuler = créer quand même un nouveau certificat');
            if (keep) {
              var f = d.getElementById('cert_no'); if (f) f.value = x.cert_no;
              try { if (w.renderCert) w.renderCert(x); if (w.renderQR && w.exbVerifCertText) w.renderQR('cqr', w.exbVerifCertText(x)); } catch (e) {}
              var cm = d.getElementById('cm'); if (cm) cm.textContent = 'Certificat existant conservé : ' + x.cert_no + ' (aucun doublon créé).';
              return;
            }
          }
        }
      } catch (e) {}
      return o.apply(this, arguments);
    }; });
    var r = wrap('saveReceipt', function (o) { return function () {
      try {
        if (typeof w.receiptData === 'function') {
          var rc = w.receiptData(), same = similarReceipt(rc, jlist('exb_receipts'));
          if (same.length) {
            var x = same[same.length - 1];
            var keep = w.confirm('⚠️ Un reçu identique existe déjà pour ' + rc.participant + ' (' + rc.training + ') :\nN° ' + x.receipt_no + '\n\nUn document = un numéro = un QR.\nOK = ne pas créer de second reçu\nAnnuler = créer quand même un nouveau reçu');
            if (keep) {
              var f = d.getElementById('receipt_no'); if (f) f.value = x.receipt_no;
              try { if (w.renderReceipt) w.renderReceipt(x); } catch (e) {}
              var rm = d.getElementById('rm'); if (rm) rm.textContent = 'Reçu existant conservé : ' + x.receipt_no + ' (aucun doublon créé).';
              return;
            }
          }
        }
      } catch (e) {}
      return o.apply(this, arguments);
    }; });
    if (!(a && b && r) && (n || 0) < 40) setTimeout(function () { tryWrap((n || 0) + 1); }, 750);
  }
  /* après les autres extensions qui enveloppent déjà ces fonctions (garde-fous, reçus liés aux participants) */
  setTimeout(function () { tryWrap(0); }, 2500);

  /* ---------- 3) garde-fou à l'import des demandes en ligne (« Demandes reçues ») ---------- */
  function similarTrainer(rec, all, selfId) {
    var nm = norm(rec.name), sn = sortedName(rec.name), ph = digits(rec.phone), em = norm(rec.email), out = [];
    all.forEach(function (t) {
      if (selfId && t.trainer_id === selfId) return;
      var n2 = t.name || t.full_name || '', why = '';
      if (ph.length >= 8 && digits(t.phone) === ph) why = 'même téléphone';
      else if (em && norm(t.email) === em) why = 'même e-mail';
      else if (nm && norm(n2) === nm) why = 'même nom';
      else if (sn && sortedName(n2) === sn) why = 'même nom (prénom et nom inversés)';
      else if (nm && nearName(n2, rec.name)) why = 'nom presque identique (faute de frappe ?)';
      if (why) out.push({ p: t, why: why });
    });
    return out;
  }
  function similarClient(rec, all, selfId) {
    var nm = norm(rec.name), sn = sortedName(rec.name), ph = digits(rec.phone), em = norm(rec.email), out = [];
    all.forEach(function (c) {
      if (selfId && c.id === selfId) return;
      var n2 = c.full_name || c.name || '', why = '';
      if (ph.length >= 8 && digits(c.phone) === ph) why = 'même téléphone';
      else if (em && norm(c.email) === em) why = 'même e-mail';
      else if (nm && norm(n2) === nm) why = 'même nom';
      else if (sn && sortedName(n2) === sn) why = 'même nom (prénom et nom inversés)';
      if (why) out.push({ p: c, why: why });
    });
    return out;
  }
  /* list = demandes en ligne [{d:{name,phone,email,training,…}}] ; renvoie celles à importer.
     Les demandes qui ressemblent à une fiche existante (ou à une autre demande du même lot) sont montrées dans UNE fenêtre :
     OK = tout importer quand même ; Annuler = laisser ces demandes-là en attente (rien n'est supprimé). */
  function guardImport(t, list) {
    try {
      if (!list || !list.length || ['insc', 'form', 'cli'].indexOf(t) < 0) return list;
      var base = t === 'insc' ? jlist('exb_participants') : t === 'form' ? jlist('exb_trainers') : jlist('exb_clients');
      var flagged = [], pool = base.slice();
      list.forEach(function (r) {
        var dd = r.d || {}, rec = { name: dd.name || dd.full_name || '', phone: dd.phone, email: dd.email, training: dd.training, matricule: dd.matricule, birth_date: dd.birth_date };
        var hits = t === 'insc' ? similarPerson(rec, pool, '') : t === 'form' ? similarTrainer(rec, pool, '') : similarClient(rec, pool, '');
        if (hits.length) flagged.push({ r: r, rec: rec, h: hits[0] });
        if (t === 'insc') pool.push({ name: rec.name, phone: rec.phone, email: rec.email, training: rec.training, matricule: rec.matricule, birth_date: rec.birth_date, participant_id: '(demande)', _req: 1 });
        else if (t === 'form') pool.push({ name: rec.name, phone: rec.phone, email: rec.email, trainer_id: '(demande)', _req: 1 });
        else pool.push({ full_name: rec.name, phone: rec.phone, email: rec.email, id: '(demande)', _req: 1 });
      });
      if (!flagged.length) return list;
      var lines = flagged.slice(0, 5).map(function (f) { return '• ' + (f.rec.name || '?') + ' — ' + f.h.why + (f.h.p._req ? ' (autre demande du même lot)' : ' (fiche : ' + pName(f.h.p) + (f.h.p.training ? ', ' + f.h.p.training : '') + ')'); });
      var ok = w.confirm('⚠️ ' + flagged.length + ' demande(s) sur ' + list.length + ' ressemblent à une fiche déjà enregistrée :\n\n' + lines.join('\n') + (flagged.length > 5 ? '\n… et ' + (flagged.length - 5) + ' autre(s).' : '') +
        '\n\nOK = tout importer quand même\nAnnuler = importer seulement les autres (celles-ci restent en attente, rien n’est supprimé)');
      if (ok) return list;
      var skip = {}; flagged.forEach(function (f) { skip[list.indexOf(f.r)] = 1; });
      return list.filter(function (r, i) { return !skip[i]; });
    } catch (e) { return list; }
  }

  /* ---------- 4) formateur / client : avertissement avant d'enregistrer une NOUVELLE fiche ---------- */
  function tryWrap2(n) {
    var a = wrap('saveTrainer', function (o) { return function () {
      try {
        var nameEl = d.getElementById('frm_name');
        if (nameEl && !(nameEl.dataset && nameEl.dataset.editId) && String(nameEl.value || '').trim()) {
          var hits = similarTrainer({ name: nameEl.value, phone: (d.getElementById('frm_phone') || {}).value, email: (d.getElementById('frm_email') || {}).value }, jlist('exb_trainers'), '');
          if (hits.length && !w.confirm('⚠️ Ce formateur semble déjà enregistré (' + hits[0].why + ') :\n\n' + pName(hits[0].p) + (hits[0].p.phone ? ' — ' + hits[0].p.phone : '') + '\n\nOK = enregistrer quand même\nAnnuler = ne pas créer de doublon')) {
            var m = d.getElementById('frm_msg'); if (m) m.textContent = 'Enregistrement annulé : ce formateur existe déjà (' + pName(hits[0].p) + ').'; return;
          }
        }
      } catch (e) {}
      return o.apply(this, arguments);
    }; });
    var b = wrap('saveExbClient', function (o) { return function () {
      try {
        var idEl = d.getElementById('exb_cli_id'), full = (w.clientFullName ? w.clientFullName() : '');
        if (idEl && !String(idEl.value || '').trim() && full) {
          var hits = similarClient({ name: full, phone: (d.getElementById('exb_cli_phone') || {}).value, email: (d.getElementById('exb_cli_email') || {}).value }, jlist('exb_clients'), '');
          if (hits.length && !w.confirm('⚠️ Ce client semble déjà enregistré (' + hits[0].why + ') :\n\n' + pName(hits[0].p) + (hits[0].p.phone ? ' — ' + hits[0].p.phone : '') + '\n\nOK = enregistrer quand même\nAnnuler = ne pas créer de doublon')) return;
        }
      } catch (e) {}
      return o.apply(this, arguments);
    }; });
    if (!(a && b) && (n || 0) < 40) setTimeout(function () { tryWrap2((n || 0) + 1); }, 750);
  }
  setTimeout(function () { tryWrap2(0); }, 2600);

  /* ---------- 5) contrôle à la demande (utilisé par l'assistant) : rien n'est modifié ---------- */
  function scan() {
    if (!RULES.length) return null;
    var out = []; RULES.forEach(function (r) { try { (r.check() || []).forEach(function (x) { out.push(x); }); } catch (e) {} });
    return out;
  }

  w.EXBDOUBLONS = { personnes: similarPerson, certificat: similarCert, recu: similarReceipt, formateur: similarTrainer, client: similarClient, guardImport: guardImport, scan: scan, read: jlist, version: 'V99-doublons-2' };
})(window, document);
