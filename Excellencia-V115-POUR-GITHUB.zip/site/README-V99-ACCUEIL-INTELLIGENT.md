# V99 — Accueil intelligent (3 blocs sous la bannière)

Nouveau fichier : `exb-home-pro.js`. Modifiés : `index.html` (1 balise script), `sw.js` (cache). Aucune fonction ni donnée existante modifiée.

- **Où** : dans l'écran d'accueil, entre la bannière et les 4 cartes. Les blocs font partie de l'accueil : dès qu'on ouvre un autre module ou onglet ils disparaissent ; ils reviennent avec « Accueil », le menu ou la flèche retour. Menu latéral et barre des modules : inchangés.
- **⚡ Actions rapides** : 6 boutons de création, triés selon votre usage (les plus utilisés remontent). « Personnaliser » : choisir parmi 10 actions. Un bouton n'apparaît que si votre rôle a accès au module.
- **📋 Coller pour créer** : colle un nom, un numéro, un e-mail ou un montant → propose « Créer le client » (champs pré-remplis), « Ajouter une dépense » (montant copié) ou « Rechercher ».
- **📌 À faire aujourd'hui** : factures en retard, documents/conformité qui expirent (30 j), tâches terrain échues, licences à renouveler (appareil administrateur), paiements en attente. Les lignes à zéro sont masquées. Bouton « Copier » : résumé prêt pour WhatsApp / e-mail.
- **🕘 Reprendre où j'en étais** : les 4 derniers modules ouverts.
- Réglages mémorisés sur l'appareil : `exb_home_use`, `exb_home_qa`, `exb_home_recent`.
- À confirmer sur vos appareils : champs téléphone/e-mail du formulaire client (`exb_cli_phone`, `exb_cli_email`) pré-remplis s'ils existent ; rendu mobile non testé ici.
- Retour en arrière : supprimer la balise `<script src="exb-home-pro.js">` de index.html.
