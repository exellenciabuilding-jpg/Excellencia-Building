/* Excellencia Building — Accueil intelligent (V99-HOME)
 * Ajoute 3 blocs dans l'écran d'accueil, tout en bas (sous le tableau de bord) :
 *   ⚡ Actions rapides (création en un appui, triées selon votre usage, personnalisables, + « Coller pour créer »)
 *   📌 À faire aujourd'hui (factures en retard, documents qui expirent, tâches, licences, paiements) + copie du résumé
 *   🕘 Reprendre où j'en étais (derniers modules ouverts)
 * Les blocs vivent DANS #exbHome : dès qu'on ouvre un autre module ou onglet, ils disparaissent avec l'accueil ;
 * ils reviennent avec « Accueil », le menu, ou la flèche retour. La barre des modules et le menu latéral ne sont pas touchés.
 * Aucune fonction ni donnée existante n'est modifiée (lecture seule des données).
 * Pour retirer : supprimer la balise <script src="exb-home-pro.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_HOME_PRO) return;
  var K_USE = 'exb_home_use', K_SEL = 'exb_home_qa', K_REC = 'exb_home_recent';
  var ACTIONS = [
    { id: 'devis', ic: '📝', t: 'Nouveau devis', key: 'metreDevis' },
    { id: 'client', ic: '👤', t: 'Nouveau client', key: 'clients', focus: 'exb_cli_full' },
    { id: 'depense', ic: '💸', t: 'Ajouter une dépense', key: 'chantiers', alt: 'finances' },
    { id: 'facture', ic: '🧾', t: 'Nouvelle facture', key: 'chantiers', alt: 'finances' },
    { id: 'participant', ic: '🎓', t: 'Nouveau participant', key: 'participants' },
    { id: 'plan', ic: '📐', t: 'Ouvrir un plan', key: 'planEditeur', alt: 'bureauEtudes' },
    { id: 'tache', ic: '✅', t: 'Nouvelle tâche chantier', key: 'terrain', alt: 'projets' },
    { id: 'projet', ic: '🏗️', t: 'Nouveau projet', key: 'projets' },
    { id: 'stock', ic: '🧱', t: 'Mouvement de stock', key: 'stock' },
    { id: 'doc', ic: '📁', t: 'Ajouter un document', key: 'documents' }
  ];
  var DEFAULT_SEL = ['devis', 'client', 'depense', 'facture', 'participant', 'plan'];
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jget(k, df) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? df : v; } catch (e) { return df; } }
  function jset(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function stor(k) { try { return JSON.parse(((typeof exbStorage !== 'undefined' ? exbStorage : null) || w.exbStorage || w.localStorage).getItem(k) || '[]') || []; } catch (e) { return []; } }
  function today() { return new Date().toISOString().slice(0, 10); }
  function plus(n) { var x = new Date(); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); }
  var editing = false, pasteOpen = false;

  /* ---- Disponibilité d'un module : lit le menu d'origine (droits par fonction respectés) ---- */
  function btnFor(key) {
    var bs = d.querySelectorAll('#app .tabs button'), i, oc;
    for (i = 0; i < bs.length; i++) {
      oc = bs[i].getAttribute('onclick') || '';
      if (oc.indexOf("show('" + key + "')") >= 0) {
        var g = bs[i].closest('.exb-nav-group');
        if (bs[i].hidden || w.getComputedStyle(bs[i]).display === 'none' || (g && w.getComputedStyle(g).display === 'none')) return null;
        return bs[i];
      }
    }
    return null;
  }
  function pick(a) { return btnFor(a.key) ? a.key : (a.alt && btnFor(a.alt) ? a.alt : null); }
  function labelOf(key) {
    var b = btnFor(key); if (!b) return key;
    return (b.textContent || '').replace(/\s+/g, ' ').trim().replace(/^[^\sA-Za-z0-9À-ÿ]+\s*/u, '') || key;
  }
  function iconOf(key) {
    var b = btnFor(key), m = b && (b.textContent || '').trim().match(/^([^\sA-Za-z0-9À-ÿ]+)/u);
    return m ? m[1] : '▫️';
  }
  function go(key, focusId) {
    try { w.show(key); } catch (e) { return; }
    setTimeout(function () {
      try {
        var el = focusId && $(focusId);
        if (el) { el.focus(); if (el.scrollIntoView) el.scrollIntoView({ block: 'center' }); }
      } catch (e) {}
    }, 250);
  }

  /* ---- Usage : le module apprend vos habitudes ---- */
  function bump(id) { var u = jget(K_USE, {}); u[id] = (u[id] || 0) + 1; jset(K_USE, u); }
  function chosen() {
    var sel = jget(K_SEL, null); if (!sel || !sel.length) sel = DEFAULT_SEL;
    var u = jget(K_USE, {}), pos = {};
    sel.forEach(function (id, i) { pos[id] = i; });
    var list = ACTIONS.filter(function (a) { return pos[a.id] != null && pick(a); });
    list.sort(function (a, b) { return (u[b.id] || 0) - (u[a.id] || 0) || pos[a.id] - pos[b.id]; });
    return list;
  }

  /* ---- À faire aujourd'hui (lecture seule) ---- */
  function todo() {
    var out = [], t = today(), n, items;
    try {
      items = stor('exb_invoices');
      n = items.filter(function (i) {
        var ttc = (i.lines || []).reduce(function (a, l) { return a + (+l.q || 0) * (+l.pu || 0); }, 0) * (1 + (+i.tva || 0) / 100);
        var paid = (i.payments || []).reduce(function (a, p) { return a + (+p.amount || 0); }, 0);
        return i.due && i.due < t && !(ttc > 0 && paid >= ttc - 0.005);
      }).length;
      if (n) out.push({ c: '#e5352f', t: 'Factures en retard', s: 'À relancer', n: n, key: pick({ key: 'chantiers', alt: 'finances' }) });
    } catch (e) {}
    try {
      var lim = plus(30);
      n = stor('compliance').filter(function (c) { return c.expiry && c.expiry <= lim; }).length;
      if (n) out.push({ c: '#f59e0b', t: 'Documents qui expirent', s: 'Sous 30 jours ou dépassés', n: n, key: pick({ key: 'documents' }) });
    } catch (e) {}
    try {
      items = w.EXBTT && w.EXBTT.list ? w.EXBTT.list() : [];
      n = items.filter(function (x) { return x.status !== 'Terminée' && x.status !== 'Validée' && x.due && x.due <= t; }).length;
      if (n) out.push({ c: '#1f6feb', t: 'Tâches de chantier du jour', s: 'Échéance aujourd’hui ou dépassée', n: n, key: pick({ key: 'terrain', alt: 'projets' }) });
    } catch (e) {}
    try {
      var lim7 = plus(7);
      n = jget('exb_gen_hist2', []).filter(function (h) { return h.exp && String(h.exp).slice(0, 10) <= lim7; }).length;
      if (n) out.push({ c: '#16a34a', t: 'Licences à renouveler', s: '7 jours ou moins', n: n, key: pick({ key: 'proprietaire', alt: 'clients' }) });
    } catch (e) {}
    try {
      n = parseInt(($('dashUnpaid') || {}).textContent, 10) || 0;
      if (n) out.push({ c: '#7c3aed', t: 'Paiements en attente', s: 'À encaisser', n: n, key: pick({ key: 'receipts', alt: 'finances' }) });
    } catch (e) {}
    try {
      if (w.EXBI && w.EXBI.summary) { var sm = w.EXBI.summary(); n = (sm.erreur || 0) + (sm.alerte || 0);
        if (n) out.unshift({ c: '#b42318', t: 'Anomalies détectées', s: 'Erreurs, incohérences, doublons', n: n, fn: function () { w.EXBI.open('ctl'); } }); }
    } catch (e) {}
    return out.filter(function (r) { return r.key || r.fn; });
  }

  /* ---- Reprendre où j'en étais ---- */
  function recent() { return jget(K_REC, []).filter(function (r) { return btnFor(r.k); }).slice(0, 4); }
  function noteVisit(k) {
    if (!k || k === 'dashboard' || k === 'notifications') return;
    var r = jget(K_REC, []).filter(function (x) { return x.k !== k; });
    r.unshift({ k: k, t: Date.now() });
    jset(K_REC, r.slice(0, 12));
  }

  /* ---- Copier / coller intelligent ---- */
  function copyText(s) {
    function fb() { try { var ta = d.createElement('textarea'); ta.value = s; ta.style.cssText = 'position:fixed;opacity:0'; d.body.appendChild(ta); ta.select(); d.execCommand('copy'); d.body.removeChild(ta); return true; } catch (e) { return false; } }
    if (w.navigator.clipboard && w.navigator.clipboard.writeText) return w.navigator.clipboard.writeText(s).then(function () { return true; }, function () { return fb(); });
    return Promise.resolve(fb());
  }
  function summaryText() {
    var rows = todo(), t = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    return 'À faire — ' + t + '\n' + (rows.length ? rows.map(function (r) { return '• ' + r.t + ' : ' + r.n; }).join('\n') : '• Rien à signaler');
  }
  function analyse(txt) {
    txt = String(txt || '').trim();
    var email = (txt.match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/) || [])[0] || '';
    var phone = (txt.match(/\+?\d[\d\s().-]{7,}\d/) || [])[0] || '';
    var amount = (txt.match(/(\d[\d\s.,]*)\s*(?:\$|usd|fc|cdf|€|eur)/i) || [])[1] || '';
    var name = txt.replace(email, ' ').replace(phone, ' ').replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (name.length > 60 || /\d/.test(name)) name = '';
    return { txt: txt, email: email, phone: phone.trim(), amount: amount.trim(), name: name };
  }
  function fillClient(a) {
    go('clients', 'exb_cli_full');
    setTimeout(function () {
      function set(id, v) { var e = $(id); if (e && v) { e.value = v; try { e.dispatchEvent(new Event('input', { bubbles: true })); } catch (x) {} } }
      set('exb_cli_full', a.name); set('exb_cli_phone', a.phone); set('exb_cli_email', a.email);
    }, 500);
  }
  function pasteHtml() {
    return '<div class="hp-paste"><textarea id="hpPasteTx" placeholder="Collez ici un nom, un numéro, un e-mail ou un montant…" rows="2"></textarea><div id="hpPasteOut"></div></div>';
  }
  function pasteOut() {
    var tx = $('hpPasteTx'), out = $('hpPasteOut'); if (!tx || !out) return;
    var a = analyse(tx.value), h = '';
    if (!a.txt) { out.innerHTML = ''; return; }
    if (a.name || a.phone || a.email) h += '<button class="hp-opt" data-hp="client">👤 Créer le client' + (a.name ? ' « ' + esc(a.name) + ' »' : '') + (a.phone ? ' · ' + esc(a.phone) : '') + (a.email ? ' · ' + esc(a.email) : '') + '</button>';
    if (a.amount) h += '<button class="hp-opt" data-hp="depense">💸 Ajouter une dépense de ' + esc(a.amount) + '</button>';
    h += '<button class="hp-opt" data-hp="search">🔎 Rechercher « ' + esc(a.txt.slice(0, 30)) + ' »</button>';
    out.innerHTML = h;
    out.onclick = function (e) {
      var b = e.target.closest('[data-hp]'); if (!b) return; var k = b.getAttribute('data-hp');
      if (k === 'client') { bump('client'); fillClient(a); }
      else if (k === 'depense') { bump('depense'); copyText(a.amount); var act = ACTIONS.filter(function (x) { return x.id === 'depense'; })[0], key = pick(act); if (key) go(key); notice('Montant copié : collez-le dans le champ de la dépense.'); }
      else { var s = $('exbGlobalSearch'); if (s) { s.value = a.txt; try { w.runExbGlobalSearch(a.txt); } catch (x) {} s.focus(); } }
    };
  }
  function notice(m) { try { w.notify(m, 'info', 3500); } catch (e) {} }

  /* ---- Styles ---- */
  function css() {
    if ($('exbHomeProCss')) return;
    var s = d.createElement('style'); s.id = 'exbHomeProCss';
    s.textContent =
      '#exbHomePro{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;margin-bottom:14px;font-family:Arial,Helvetica,sans-serif}' +
      '#exbHomePro .hp{background:#fff;border:1px solid #e3e9f4;border-top:3px solid #c8962e;border-radius:14px;padding:14px;box-shadow:0 2px 10px #12254a0d;min-width:0}' +
      '#exbHomePro .hp.wide{grid-column:1/-1}' +
      '#exbHomePro h3{margin:0 0 10px;font-size:15px;color:#12254a;display:flex;justify-content:space-between;align-items:center;gap:8px}' +
      '#exbHomePro h3 a,#exbHomePro h3 button{font:600 12px Arial;color:#1f6feb;background:none;border:0;cursor:pointer;padding:6px}' +
      '#exbHomePro .hp-qa{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}' +
      '#exbHomePro .hp-b{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-height:78px;border:1px solid #e3e9f4;border-radius:12px;background:#fff;color:#12254a;font:700 12px Arial;text-align:center;cursor:pointer;padding:8px 4px}' +
      '#exbHomePro .hp-b:hover{border-color:#1f6feb;box-shadow:0 6px 16px #12254a1a}#exbHomePro .hp-b span{font-size:22px}' +
      '#exbHomePro .hp-b:focus-visible,#exbHomePro .hp-td:focus-visible,#exbHomePro .hp-opt:focus-visible{outline:2px solid #1f6feb;outline-offset:2px}' +
      '#exbHomePro .hp-td{display:flex;align-items:center;gap:12px;min-height:52px;padding:6px 4px;border:0;border-bottom:1px solid #eef1f6;background:transparent;width:100%;text-align:left;font:700 14px Arial;color:#12254a;cursor:pointer}' +
      '#exbHomePro .hp-td:last-of-type{border-bottom:0}#exbHomePro .hp-td small{display:block;font-weight:400;color:#6b7a99;font-size:12px}' +
      '#exbHomePro .hp-dt{flex:none;width:10px;height:10px;border-radius:50%}' +
      '#exbHomePro .hp-nb{margin-left:auto;min-width:28px;height:28px;padding:0 6px;box-sizing:border-box;border-radius:14px;background:#eaf1ff;color:#1f6feb;font-weight:700;display:flex;align-items:center;justify-content:center;font-size:13px}' +
      '#exbHomePro .hp-ok{color:#16a34a;font-size:14px;font-weight:700;padding:10px 0}' +
      '#exbHomePro .hp-rec{display:flex;gap:8px;overflow-x:auto;padding-bottom:4px}' +
      '#exbHomePro .hp-r{flex:none;min-width:130px;display:flex;flex-direction:column;gap:4px;align-items:flex-start;border:1px solid #e3e9f4;border-radius:12px;padding:10px;background:#fff;color:#12254a;font:700 13px Arial;cursor:pointer;text-align:left}' +
      '#exbHomePro .hp-r span{font-size:20px}' +
      '#exbHomePro .hp-sel label{display:flex;align-items:center;gap:8px;min-height:36px;font-size:13px;color:#12254a}' +
      '#exbHomePro .hp-paste textarea{width:100%;box-sizing:border-box;border:1px solid #c5cedd;border-radius:10px;padding:10px;font:14px Arial;margin-top:8px}' +
      '#exbHomePro .hp-opt{display:block;width:100%;text-align:left;margin-top:6px;min-height:44px;padding:8px 12px;border:1px solid #1f6feb;border-radius:10px;background:#eaf1ff;color:#0f2e66;font:700 13px Arial;cursor:pointer}' +
      '@media(max-width:600px){#exbHomePro{grid-template-columns:1fr}}';
    d.head.appendChild(s);
  }

  /* ---- Rendu ---- */
  function render() {
    var box = $('exbHomePro'); if (!box) return;
    var qa = '', i, list = chosen(), rows = todo(), rec = recent(), h = '';
    if (editing) {
      var sel = jget(K_SEL, null) || DEFAULT_SEL;
      qa = '<div class="hp-sel">' + ACTIONS.filter(function (a) { return pick(a); }).map(function (a) { return '<label><input type="checkbox" data-sel="' + a.id + '"' + (sel.indexOf(a.id) >= 0 ? ' checked' : '') + '> ' + a.ic + ' ' + esc(a.t) + '</label>'; }).join('') + '</div>';
    } else {
      qa = '<div class="hp-qa">' + list.map(function (a) { return '<button class="hp-b" type="button" data-a="' + a.id + '"><span>' + a.ic + '</span>' + esc(a.t) + '</button>'; }).join('') +
        '<button class="hp-b" type="button" data-a="__paste" style="border-style:dashed"><span>📋</span>Coller pour créer</button></div>' + (pasteOpen ? pasteHtml() : '');
    }
    h += '<div class="hp"><h3><span>⚡ Actions rapides</span><button type="button" data-a="__edit">' + (editing ? 'Terminer' : 'Personnaliser') + '</button></h3>' + qa + '</div>';
    h += '<div class="hp"><h3><span>📌 À faire aujourd’hui</span><button type="button" data-a="__copy" title="Copier le résumé (WhatsApp, e-mail)">📋 Copier</button></h3>' +
      (rows.length ? rows.map(function (r, n) { return '<button class="hp-td" type="button" data-r="' + n + '"><span class="hp-dt" style="background:' + r.c + '"></span><span>' + esc(r.t) + '<small>' + esc(r.s) + '</small></span><span class="hp-nb">' + r.n + '</span></button>'; }).join('') : '<div class="hp-ok">✓ Rien à signaler pour aujourd’hui</div>') + '</div>';
    if (rec.length) h += '<div class="hp wide"><h3><span>🕘 Reprendre où j’en étais</span></h3><div class="hp-rec">' + rec.map(function (r) { return '<button class="hp-r" type="button" data-k="' + esc(r.k) + '"><span>' + iconOf(r.k) + '</span>' + esc(labelOf(r.k)) + '</button>'; }).join('') + '</div></div>';
    box.innerHTML = h;
    box._rows = rows;
  }
  function onClick(e) {
    var box = $('exbHomePro'), b = e.target.closest('[data-a],[data-r],[data-k],[data-sel]'); if (!b || !box) return;
    var a = b.getAttribute('data-a');
    if (b.hasAttribute('data-sel')) {
      var sel = [], cs = box.querySelectorAll('[data-sel]'), i;
      for (i = 0; i < cs.length; i++) if (cs[i].checked) sel.push(cs[i].getAttribute('data-sel'));
      jset(K_SEL, sel.length ? sel : DEFAULT_SEL); return;
    }
    if (a === '__edit') { editing = !editing; render(); return; }
    if (a === '__paste') {
      pasteOpen = !pasteOpen; render();
      if (pasteOpen) { var tx = $('hpPasteTx'); if (tx) { tx.oninput = pasteOut; tx.focus(); }
        if (w.navigator.clipboard && w.navigator.clipboard.readText) w.navigator.clipboard.readText().then(function (v) { if (v && tx && !tx.value) { tx.value = v.slice(0, 500); pasteOut(); } }, function () {}); }
      return;
    }
    if (a === '__copy') { copyText(summaryText()).then(function (ok) { notice(ok ? 'Résumé copié.' : 'Copie impossible sur cet appareil.'); }); return; }
    if (a) { var act = ACTIONS.filter(function (x) { return x.id === a; })[0]; if (act) { var key = pick(act); if (key) { bump(act.id); go(key, act.focus); } } return; }
    if (b.hasAttribute('data-r')) { var r = box._rows && box._rows[+b.getAttribute('data-r')]; if (r && r.fn) r.fn(); else if (r && r.key) go(r.key); return; }
    if (b.hasAttribute('data-k')) go(b.getAttribute('data-k'));
  }

  /* ---- Installation (attend que l'accueil V99r existe) ---- */
  function install() {
    var home = $('exbHome'), kp = $('xhK');
    if (!home || !kp || $('exbHomePro')) return !!$('exbHomePro');
    css();
    var box = d.createElement('div'); box.id = 'exbHomePro'; box.className = 'no-print';
    home.appendChild(box); /* tout en bas de l'accueil : le tableau de bord reste en haut */
    box.addEventListener('click', onClick);
    box.addEventListener('change', function (e) { if (e.target && e.target.hasAttribute('data-sel')) onClick(e); });
    /* mémorise les modules ouverts (même principe que le shell : on prolonge show sans la modifier) */
    if (typeof w.show === 'function' && !w.__exbHomeProShow) {
      var o = w.show; w.__exbHomeProShow = 1;
      w.show = function (x) { var r = o.apply(this, arguments); try { noteVisit(String(x || '')); } catch (e) {} return r; };
    }
    /* rafraîchit à chaque retour sur l'accueil */
    try { new MutationObserver(function () { if (home.style.display !== 'none') { editing = false; render(); } if (home.lastElementChild !== box) home.appendChild(box); }).observe(home, { attributes: true, attributeFilter: ['style'] }); } catch (e) {}
    setInterval(function () { if (home.lastElementChild !== box) home.appendChild(box); if (home.style.display !== 'none' && !editing && !pasteOpen) render(); }, 60000);
    render();
    return true;
  }
  function boot() { var n = 0, t = setInterval(function () { if (install() || ++n > 120) clearInterval(t); }, 500); }
  w.EXB_HOME_PRO = { version: 'V99-HOME', refresh: render };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
