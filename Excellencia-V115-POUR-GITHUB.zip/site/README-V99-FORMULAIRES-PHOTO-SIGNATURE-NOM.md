# Formulaires publics : photo et signature visibles, nom validé en direct

## Avant
Dans les formulaires d'inscription et de demande, la photo et la signature étaient tout en bas, avant le bouton d'envoi : on les trouvait tard (ou jamais). Le nom n'était contrôlé qu'à l'envoi.

## Maintenant (tous les formulaires)
Inscription apprenant, TP/TD, formateur, client, personnel, demande de logiciel, demande BTP, **candidature TFL** et **formulaire encadreur TFL** :
- la **photo** (quand le formulaire en prévoit une) et la **signature** s'affichent **juste sous le nom**, sans défiler ;
- le **nom est validé pendant la saisie** : « ✔ Nom valide », ou message immédiat (« Indiquez votre nom ET votre prénom », « lettres seulement… ») ; un nom invalide bloque l'envoi avec le message affiché sur le champ ;
- rien d'autre ne change : mêmes données envoyées, signature facultative.
Fichiers : `exb-form-ux.js` (nouveau, ajouté aux 9 pages et au cache hors ligne). Pas de SQL.
Test : `python3 tools/test-formulaires-ux/test.py` (16/16).
