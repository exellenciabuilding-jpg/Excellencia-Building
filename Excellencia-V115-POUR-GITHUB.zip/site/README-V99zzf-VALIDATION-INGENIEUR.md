# V99zzf — Validation des calculs par un ingénieur : enregistrée côté serveur

Réponse au point d'audit « Calculs d'ingénierie engageant la responsabilité ». V99zl avait créé le circuit (statuts, cachet, journal) mais tout restait **sur l'appareil** : modifiable, sans identité vérifiée. Cette version déplace la preuve sur le serveur.

Fichiers : `supabase/migration-v99zzf-validation-ingenieur.sql` (nouveau), `calcul-structure/exb-calcul-doc.js`, `exb-db.js`, `sw.js` (cache `exb-v99zzf-validation-ingenieur-1`), `tools/test-rls/test-validation.sql` (nouveau), `tools/test-rls/run.sh`, `tools/check.js`.

## Ce qui change
- **Ingénieur habilité** : l'administrateur désigne, dans Équipe, les membres autorisés à valider (nom + n° d'ordre). Seuls eux peuvent émettre Validé / Validé avec réserves / Refusé.
- **Identité du serveur** : le nom et le n° d'ordre imprimés viennent de la fiche d'habilitation liée au compte connecté, plus d'un champ libre.
- **2FA obligatoire pour valider** : « Validé » et « Validé avec réserves » exigent une session `aal2` (mot de passe + code). Un mot de passe volé ne suffit pas à signer.
- **Journal en ajout seul** : aucune modification ni suppression (déclencheurs + droits retirés), date du serveur, tout membre de l'entreprise peut le lire, aucune autre entreprise.
- **Lié à l'empreinte** : une validation porte sur l'empreinte du contenu ; si le calcul change, il n'est plus validé (le serveur renvoie « version périmée »).
- **Serveur = référence** : à l'ouverture en ligne, le statut affiché vient du serveur ; un statut « validé » falsifié dans le stockage local disparaît.
- **Hors connexion / non connecté** : la validation reste possible en local mais est marquée « non probante » sur la page de garde, les visas, le QR et le journal. Connecté mais sans réseau : refus, rien n'est enregistré.
- **QR branché sur la validation serveur** : à l'impression, le logiciel lie le code du QR à l'empreinte validée (`calcul_lier_qr`) ; refusé si l'exemplaire se dit « validé » alors que le serveur ne connaît pas cette validation. `verification.html` interroge `calcul_verifier(n°, code)` (sans identifiant interne) et affiche : ✅ validé par X (ordre n°…) / ⚠️ ancienne version (indice en vigueur) / ⛔ exemplaire imprimé « validé » mais refusé ou non validé au registre / ℹ️ exemplaire imprimé avant la validation.

## Mise en service
1. Sauvegarde Supabase, puis exécuter `migration-v99zzf-validation-ingenieur.sql`. Elle est autonome (crée `mfa_ok()` et, si absente, une `licence_ecriture_ok()` neutre) ; exécuter v99zo et v99zp reste recommandé (licence et 2FA appliquées partout). Réexécutable.
2. Déployer les fichiers.
3. Équipe › colonne « Ingénieur habilité » : saisir nom + n° d'ordre, « Habiliter ». L'ingénieur doit avoir activé la 2FA.
4. Essai : valider une note avec un compte habilité en session 2FA ; vérifier le refus avec un compte simple, et sans 2FA.

## Tests
`tools/check.js` : 354 contrôles réussis (9 nouveaux, statiques) ; `node tools/test-verification/test-ing.js` : 6 cas d'affichage de la page de vérification, réussis. `tools/test-rls/run.sh` charge la migration puis lance `test-validation.sql` (28 scénarios : rôles, 2FA, journal non modifiable, isolation entre entreprises, vérification publique).
**Les 28 scénarios SQL n'ont pas encore été exécutés** (pas de PostgreSQL dans l'environnement de rédaction) ; le test utilise l'imitation d'authentification du dépôt, à confirmer sur un projet Supabase de recette.

## Reste à faire
- Un QR imprimé hors connexion ou avant cette version n'a pas de lien serveur : la page affiche seulement le registre de V99m (pas de bloc « validation »). Réimprimer en ligne.
- Le cachet reste une image locale, pas une signature électronique qualifiée.
- Mentions légales à faire relire selon l'ordre des ingénieurs du pays.
- Pas de test navigateur du nouvel écran (parcours habilitation → validation).
Retour en arrière : restaurer `exb-calcul-doc.js`, `exb-db.js`, `sw.js` de V99zzf ; la migration peut rester (tables non utilisées).
