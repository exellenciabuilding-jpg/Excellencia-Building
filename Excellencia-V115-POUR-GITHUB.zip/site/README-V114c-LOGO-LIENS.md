# V114c — Logo à part + adresse unique

- `formulaire-hors-connexion.html` : le logo n'est plus incrusté en base64 (≈ 4,7 Ko de texte dans la page) ; il utilise le fichier `icon-192.png`, comme les autres formulaires. Page : 17,5 Ko -> 12,8 Ko.
- Les formulaires TFL (`tfl-*`) affichent déjà le logo via `exb-public.css` (fichier `icon-192.png`) : rien à changer.
- Adresse du logiciel : `excellenciabuildingsarlu.netlify.app` (sans « 01 ») remplacée par `excellenciabuildingsarlu01.netlify.app` dans `exb-vitrine.js`, `site-vitrine/config.json`, `site-vitrine/index.html`, `carte-visite.html`.
- `sw.js` : version du cache changée pour que les appareils rechargent les pages.

## Non vérifié
Contrôle de syntaxe seulement (node --check, JSON). Pas de test dans un navigateur : ouvrir `formulaire-hors-connexion.html` après déploiement pour voir le logo.
