# V99x — Connexion par empreinte / visage (déverrouillage de l'appareil)
Fichiers : `exb-biometrie.js` (nouveau), `index.html` (point d'accroche `exbFinishLogin` + script), `sw.js` (cache `exb-v99z-poutres-4`).
- Activation : menu du profil (nom en haut à droite) › « 🔐 Activer l'empreinte / le visage » (après une connexion normale).
- Écran de connexion : bouton « Se connecter avec l'empreinte / le visage » (seulement sur les appareils où c'est activé).
- Le mot de passe reste toujours disponible. L'empreinte / le visage ne quitte jamais l'appareil (WebAuthn).
- Exige HTTPS (ou localhost) et une empreinte / un visage déjà enregistré dans les réglages de l'appareil. Propre à chaque appareil.
- Remplace la saisie du mot de passe LOCAL ; ne remplace pas le compte en ligne ni les droits serveur.

# Fusion des entreprises en double
Voir `nettoyage-doublons-entreprises.sql` (fourni à part) : sauvegarde, fusion sans perte vers l'entreprise la plus ancienne, suppression des entreprises vidées.
Après exécution : Paramètres › Base partagée › « Se délier » puis laisser l'application se rattacher à l'entreprise principale (les données de l'appareil sont conservées).
