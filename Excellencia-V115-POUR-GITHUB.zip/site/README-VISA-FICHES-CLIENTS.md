# Cachet + signature du Directeur Général sur les fiches des clients

Avant : sur la fiche de demande (btp.html), le cachet et la signature du DG ne sortaient jamais, car ils sont enregistrés
seulement sur l'appareil de l'administrateur (EXB_SIGN_V1), pas sur celui du client.

Maintenant :
1. Administrateur : Paramètres › Logo Excellencia Building (signature + cachet actifs), puis Site vitrine › « 🚀 Publier sur le site ».
   Le visa (signature + cachet) est envoyé dans le bucket public « vitrine » sous le nom `visa.png` (type image/png, déjà autorisé).
2. Client : la fiche PDF pose automatiquement ce visa sur la page de garde et sur le bloc « Le Directeur Général » (dernière page),
   à côté de la signature du client. Le QR de vérification reste en bas de la dernière page.
3. Hors ligne : la dernière copie du visa lue est gardée dans le navigateur du client (EXB_VISA_REMOTE).

Fichiers modifiés : exb-sign.js, exb-pdf.js, exb-form.js, exb-btp.js (sign:true), exb-vitrine.js, sw.js (nouvelle version de cache).
Aucun SQL à exécuter. Le bucket accepte déjà image/png.

À faire après déploiement : republier une fois depuis « Site vitrine », sinon `visa.png` n'existe pas encore.
Limites : testé en bac à sable Node (lecture du visa public, cache hors ligne), pas dans un navigateur ni sur votre Supabase.
Si vous retirez votre cachet, republier ne supprime pas l'ancien visa.png (à supprimer dans Supabase › Storage › vitrine).
