EXCELLENCIA BUILDING — V67 INTÉGRATION BTP / ARCHITECTURE

Cette version conserve V66 et ajoute un socle Projet 360° non destructif.

Nouveaux workflows intégrés :
- Projet 360°
- CRM / prospects / opportunités
- Contrats et marchés
- RFI / demandes d'information
- Submittals / fiches techniques
- Avenants / Change Orders
- Engagements financiers
- QHSE : qualité, non-conformités, sécurité, environnement
- Registre des risques
- Réunions et décisions
- Réserves / réception
- Parc matériel et engins

Synchronisation :
Les nouvelles collections sont ajoutées au moteur de synchronisation V66 :
crm, contrats, rfis, submittals, avenants, engagements, risques, reunions,
reserves, parc_materiel, qhse.

Supabase :
Après déploiement, exécuter une seule fois :
supabase/migration-v67-btp.sql

Important :
- V67 ne supprime pas les données V66.
- Les nouveaux workflows utilisent exbStorage dès qu'il est disponible.
- Les droits serveur doivent être activés avec la migration V67.
- Tester connexion, création, modification, synchronisation et droits avant mise en production.
