/* EXCELLENCIA BUILDING — V93 BTP Enterprise */
(function(w,d){'use strict';
const K={projects:'exb_v93_projects',sites:'exb_v93_sites',tasks:'exb_v93_tasks',hse:'exb_v93_hse',equipment:'exb_v93_equipment',subcontracts:'exb_v93_subcontracts'};
const uid=p=>(p||'BTP')+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),store=()=>w.exbStorage||localStorage;
function get(k){try{const v=JSON.parse(store().getItem(k)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}}
function put(k,v){try{store().setItem(k,JSON.stringify(v));return true}catch(e){return false}}
function add(k,row){const a=get(k),r=Object.assign({id:uid('BTP'),created_at:new Date().toISOString()},row);a.unshift(r);put(k,a);try{w.EXB_CORE&&w.EXB_CORE.audit&&w.EXB_CORE.audit('btp_record_created',r.id,'btp',r.id)}catch(e){}return r}
function can(c){try{return !w.EXB_CORE||!w.EXB_CORE.can||w.EXB_CORE.can(c,'ecrire')}catch(e){return true}}
function createProject(data){if(!can('projets'))throw Error('Droits insuffisants');return add(K.projects,Object.assign({status:'active',progress:0},data))}
function createSite(data){if(!can('chantiers'))throw Error('Droits insuffisants');return add(K.sites,Object.assign({status:'active'},data))}
function addTask(data){if(!can('planning'))throw Error('Droits insuffisants');return add(K.tasks,Object.assign({status:'planned',progress:0},data))}
function reportHSE(data){if(!can('qhse'))throw Error('Droits insuffisants');return add(K.hse,Object.assign({status:'open',severity:data.severity||'medium'},data))}
function registerEquipment(data){if(!can('materiel'))throw Error('Droits insuffisants');return add(K.equipment,Object.assign({status:'available'},data))}
function createSubcontract(data){if(!can('sous_traitance'))throw Error('Droits insuffisants');return add(K.subcontracts,Object.assign({status:'draft',retention_rate:Number(data.retention_rate||0)},data))}
function kpis(){return {projects:get(K.projects).length,sites:get(K.sites).length,tasks:get(K.tasks).length,openHSE:get(K.hse).filter(x=>x.status!=='closed').length,equipment:get(K.equipment).length,subcontracts:get(K.subcontracts).length}}
function render(){const h=d.getElementById('exb93_btp_root');if(!h)return;const p=kpis();h.innerHTML='<div class="exb93-btp-head"><div><h3>BTP Enterprise</h3><p>Projets, chantiers, planning, QHSE, matériel et sous-traitance.</p></div><b>V93</b></div><div class="exb93-btp-grid">'+[['Projets',p.projects],['Chantiers',p.sites],['Activités',p.tasks],['Alertes QHSE',p.openHSE],['Matériel',p.equipment],['Sous-traitants',p.subcontracts]].map(x=>'<div><strong>'+x[1]+'</strong><span>'+x[0]+'</span></div>').join('')+'</div>'}
function mount(){if(!d.getElementById('exb93BtpCSS')){const s=d.createElement('style');s.id='exb93BtpCSS';s.textContent='.exb93-btp-head{display:flex;justify-content:space-between;margin:12px 0}.exb93-btp-head h3{margin:0}.exb93-btp-head p{margin:4px 0;color:#64748b}.exb93-btp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}.exb93-btp-grid div{padding:14px;border:1px solid #e2e8f0;border-radius:12px;background:#fff}.exb93-btp-grid strong,.exb93-btp-grid span{display:block}.exb93-btp-grid strong{font-size:21px}.exb93-btp-grid span{font-size:12px;color:#64748b}';d.head.appendChild(s)}const host=d.getElementById('enterprise360')||d.getElementById('exb90_root');if(host&&!d.getElementById('exb93_btp_root')){const x=d.createElement('div');x.id='exb93_btp_root';host.appendChild(x)}render()}
w.EXB_BTP={version:'V93-BTP-Enterprise',keys:K,createProject,createSite,addTask,reportHSE,registerEquipment,createSubcontract,kpis,refresh:render};if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',()=>setTimeout(mount,0));else setTimeout(mount,0);
})(window,document);
