EXCELLENCIA BUILDING — V91 CORE ENTERPRISE

Cette version rend le Core Enterprise opérationnel sans supprimer les services V81/V90.

Services :
- Auth : adaptateur vers le compte V81
- Permissions : point d'entrée EXBDB/EXBROLES
- Organisation : récupération de l'organisation et paramètres
- Notifications : centre local + prêt pour notifications Supabase
- Audit : journal local + tentative de journal serveur
- Sync : point d'entrée central vers EXBDB / synchronisation existante

Migration Supabase : supabase/migration-v91-core.sql
À exécuter après schema-entreprise.sql et migration-v90-enterprise.sql.

Le service Core est chargé avant Enterprise Shell et est inclus dans le cache PWA.
