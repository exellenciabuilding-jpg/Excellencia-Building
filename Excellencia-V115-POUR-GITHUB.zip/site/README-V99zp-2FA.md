# V99zp — Double authentification (2FA)

**Ce que ça change** : un compte qui active la 2FA doit saisir, à chaque connexion, le code à 6 chiffres de son application (Google/Microsoft Authenticator, Authy). Le serveur l'impose : un mot de passe volé ne donne plus accès aux données. Les comptes sans 2FA ne changent pas.

**Installation**
1. Déployer les fichiers de cette version (nouveau fichier `exb-mfa.js`).
2. Supabase › SQL Editor : exécuter `supabase/migration-v99zp-double-authentification.sql` (une seule partie, réexécutable).
3. Supabase › Authentication › Sign In / Providers › vérifier que « Multi-Factor (TOTP) » est activé.

**Utilisation** : une fois connecté, bouton « 🔐 2FA » en bas à gauche → scanner le QR → saisir le code → activée. **Notez le secret** (saisie manuelle) en lieu sûr : sans l'appli ni le secret, le compte est bloqué et il faut retirer le facteur dans Supabase (Authentication › Users › compte › Remove MFA factor).

**À savoir** : réservez la 2FA aux comptes administrateur/direction. Les comptes à connexion automatique par lien (mot de passe intégré) ne peuvent pas répondre à un code : n'y activez pas la 2FA.

**Tests** : `tools/test-rls` (26/26), `tools/test-mfa/test.py` (7/7), `tools/check.js`.
