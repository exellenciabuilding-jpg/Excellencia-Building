-- ===== Excellencia Building V99zzq — Module TFL (encadrement des Travaux de Fin de Licence) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor), APRÈS migration-v99zo-securite-serveur.sql (utilise peut() et licence_ecriture_ok()).
-- Réexécutable sans danger. FAITES D'ABORD UNE SAUVEGARDE et essayez sur un projet de recette : ce script n'a PAS été exécuté
-- sur PostgreSQL au moment de sa rédaction ; lancez tools/test-rls (et les tests TFL du README) avant toute mise en service.
--
-- PRINCIPES
--  · Le personnel (administrateur, direction, bureau d'études…) passe par peut(org,'tfl',...) comme tout le reste du logiciel.
--  · L'ÉTUDIANT et l'ENCADREUR ne sont PAS membres de l'organisation : ils ont un compte Supabase relié à leur fiche (user_id).
--    Ils ne voient QUE leurs propres dossiers (étudiant) ou les dossiers qui leur sont affectés ET acceptés (encadreur).
--  · Un étudiant ne peut jamais modifier lui-même statut, numéro, affectation, décision ou progression (trigger tfl_garde).
--  · Chaque changement important est écrit dans tfl_historique par le serveur (impossible à falsifier par l'application).
--  · « Validé par Excellencia Building » (sujet_statut) est DISTINCT de « Validé par l'université » (validation_univ).

-- ---------- 0. Droits par fonction ----------
insert into collections_sensibles(collection) values ('tfl') on conflict do nothing;
insert into droits_fonction(fonction,collection,lire,ecrire) values
  ('direction','tfl',true,true),
  ('bureau_etudes','tfl',true,true),
  ('chef_projet','tfl',true,false)
on conflict (fonction,collection) do nothing;

-- ---------- 1. Tables ----------
create table if not exists public.tfl_parametres (
  org_id uuid primary key,
  payant boolean not null default false,          -- à confirmer : l'encadrement est-il payant ?
  devise text default 'USD',
  frais numeric(12,2) default 0,
  max_dossiers_encadreur int not null default 8,
  annee_academique text
);

create table if not exists public.tfl_compteurs (
  org_id uuid not null, annee int not null, dernier int not null default 0,
  primary key (org_id, annee)
);

create table if not exists public.tfl_encadreurs (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  user_id uuid references auth.users(id) on delete set null,
  nom text not null,
  email text, telephone text,
  domaines text[] not null default '{}',          -- génie civil, architecture, gestion des travaux, autres
  specialites text,
  max_etudiants int not null default 8,
  disponible boolean not null default true,
  actif boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists tfl_encadreurs_user_uq on public.tfl_encadreurs (org_id, user_id) where user_id is not null;

create table if not exists public.tfl_etudiants (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  user_id uuid references auth.users(id) on delete set null,
  nom text not null,
  email text, telephone text,
  universite text, promotion text, filiere text,
  created_at timestamptz not null default now()
);
create unique index if not exists tfl_etudiants_user_uq on public.tfl_etudiants (org_id, user_id) where user_id is not null;

create table if not exists public.tfl_dossiers (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  numero text,                                     -- TFL-2026-0001, attribué par le serveur
  etudiant_id uuid not null references public.tfl_etudiants(id) on delete restrict,
  encadreur_id uuid references public.tfl_encadreurs(id) on delete set null,
  domaine text not null default 'genie_civil'
    check (domaine in ('genie_civil','architecture','gestion_travaux','autre')),
  statut text not null default 'brouillon'
    check (statut in ('brouillon','recu','en_verification','complement_demande','accepte','refuse','clos')),
  etape smallint not null default 1 check (etape between 1 and 9),   -- parcours en 9 étapes
  progression smallint not null default 0 check (progression between 0 and 100),
  -- candidature
  sujet_titre text, problematique text, objectifs text, methodologie text, recherches_deja text,
  -- décision administrative
  motif_decision text,
  depose_le timestamptz, decide_le timestamptz, decide_par uuid,
  -- analyse du sujet
  sujet_statut text not null default 'a_etudier'
    check (sujet_statut in ('a_etudier','accepte','refuse','a_reviser')),
  validation_exb boolean not null default false,  -- « Validé par Excellencia Building »
  validation_univ text not null default 'non_demandee'
    check (validation_univ in ('non_demandee','en_attente','accordee','refusee')),  -- « Validé par l'université » : saisie manuelle, preuve jointe
  observation_encadreur text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists tfl_dossiers_numero_uq on public.tfl_dossiers (org_id, numero) where numero is not null;
create index if not exists tfl_dossiers_etu_idx on public.tfl_dossiers (etudiant_id);
create index if not exists tfl_dossiers_enc_idx on public.tfl_dossiers (encadreur_id);
create index if not exists tfl_dossiers_statut_idx on public.tfl_dossiers (org_id, statut);

create table if not exists public.tfl_documents (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  dossier_id uuid not null references public.tfl_dossiers(id) on delete cascade,
  type text not null default 'chapitre'
    check (type in ('proposition','plan','chapitre','pdf','tableau','plan_archi','note_calcul','metre','reference','autre')),
  chapitre text,
  version int not null default 1,                  -- calculée par le serveur
  nom_fichier text not null,
  storage_path text not null,                      -- org_id/dossier_id/fichier (bucket tfl-documents)
  taille bigint,
  auteur_id uuid not null default auth.uid(),
  etat text not null default 'depose' check (etat in ('depose','en_revue','a_corriger','valide')),
  created_at timestamptz not null default now()
);
create index if not exists tfl_documents_dossier_idx on public.tfl_documents (dossier_id, type, chapitre, version);

create table if not exists public.tfl_commentaires (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  dossier_id uuid not null references public.tfl_dossiers(id) on delete cascade,
  document_id uuid references public.tfl_documents(id) on delete set null,
  auteur_id uuid not null default auth.uid(),
  auteur_role text not null check (auteur_role in ('etudiant','encadreur','admin')),
  texte text not null check (length(texte) between 1 and 4000),
  reponse_a uuid references public.tfl_commentaires(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists tfl_commentaires_dossier_idx on public.tfl_commentaires (dossier_id, created_at);

create table if not exists public.tfl_etapes (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  dossier_id uuid not null references public.tfl_dossiers(id) on delete cascade,
  libelle text not null,
  echeance date,
  statut text not null default 'a_faire' check (statut in ('a_faire','en_cours','termine','en_retard')),
  responsable uuid,
  termine_le timestamptz
);
create index if not exists tfl_etapes_dossier_idx on public.tfl_etapes (dossier_id, echeance);

create table if not exists public.tfl_rendez_vous (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  dossier_id uuid not null references public.tfl_dossiers(id) on delete cascade,
  date_heure timestamptz not null,
  lieu text, participants text, compte_rendu text,
  created_by uuid default auth.uid()
);

create table if not exists public.tfl_soutenances (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  dossier_id uuid not null unique references public.tfl_dossiers(id) on delete cascade,
  date_prevue timestamptz, salle text,
  jury jsonb not null default '[]'::jsonb,         -- [{nom, role}]
  statut text not null default 'a_preparer' check (statut in ('a_preparer','planifiee','passee','reportee'))
);

-- Notes : visibles de l'étudiant seulement une fois publiées.
create table if not exists public.tfl_resultats (
  dossier_id uuid primary key references public.tfl_dossiers(id) on delete cascade,
  org_id uuid not null,
  grille jsonb not null default '{}'::jsonb,       -- critères et notes
  note numeric(5,2) check (note between 0 and 20),
  mention text,
  pv_path text,
  publie boolean not null default false,
  publie_le timestamptz
);

create table if not exists public.tfl_historique (
  id bigint generated always as identity primary key,
  org_id uuid not null,
  dossier_id uuid not null references public.tfl_dossiers(id) on delete cascade,
  action text not null,
  avant jsonb, apres jsonb,
  auteur uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists tfl_historique_dossier_idx on public.tfl_historique (dossier_id, created_at);

-- ---------- 2. Fonctions d'aide aux politiques ----------
create or replace function public.tfl_staff(p_org uuid, p_ecrire boolean default false)
returns boolean language sql stable security definer set search_path=public as $$
  select public.peut(p_org,'tfl',p_ecrire) $$;

create or replace function public.tfl_dossier_etudiant(p_dossier uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from tfl_dossiers d join tfl_etudiants e on e.id=d.etudiant_id
                where d.id=p_dossier and e.user_id=auth.uid()) $$;

-- L'encadreur n'accède au dossier qu'APRÈS acceptation (statut accepte ou clos).
create or replace function public.tfl_dossier_encadreur(p_dossier uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from tfl_dossiers d join tfl_encadreurs en on en.id=d.encadreur_id
                where d.id=p_dossier and en.user_id=auth.uid() and en.actif and d.statut in ('accepte','clos')) $$;

create or replace function public.tfl_acces_dossier(p_dossier uuid, p_org uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select public.tfl_staff(p_org,false) or public.tfl_dossier_etudiant(p_dossier) or public.tfl_dossier_encadreur(p_dossier) $$;

grant execute on function public.tfl_staff(uuid,boolean), public.tfl_dossier_etudiant(uuid),
  public.tfl_dossier_encadreur(uuid), public.tfl_acces_dossier(uuid,uuid) to authenticated;

-- ---------- 3. Triggers ----------
-- 3a. Numéro de dossier (atomique) et date de mise à jour
create or replace function public.tfl_avant_dossier() returns trigger
language plpgsql security definer set search_path=public as $$
declare a int := extract(year from now())::int; n int;
begin
  if tg_op='INSERT' and new.numero is null then
    insert into tfl_compteurs(org_id,annee,dernier) values (new.org_id,a,1)
      on conflict (org_id,annee) do update set dernier=tfl_compteurs.dernier+1
      returning dernier into n;
    new.numero := 'TFL-'||a||'-'||lpad(n::text,4,'0');
  end if;
  if tg_op='UPDATE' and new.statut<>old.statut and new.statut in ('accepte','refuse','complement_demande') then
    new.decide_le := coalesce(new.decide_le, now());
    new.decide_par := coalesce(new.decide_par, auth.uid());
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists tfl_avant_dossier_t on public.tfl_dossiers;
create trigger tfl_avant_dossier_t before insert or update on public.tfl_dossiers
  for each row execute function public.tfl_avant_dossier();

-- 3b. Garde : ce que l'étudiant et l'encadreur n'ont pas le droit de changer
create or replace function public.tfl_garde() returns trigger
language plpgsql security definer set search_path=public as $$
declare est_proprio boolean; est_enc boolean;
begin
  if auth.uid() is null or public.tfl_staff(old.org_id,true) then return new; end if;   -- service/cron ou personnel
  est_proprio := public.tfl_dossier_etudiant(old.id);
  est_enc := public.tfl_dossier_encadreur(old.id);
  if est_proprio then
    if new.numero is distinct from old.numero or new.org_id<>old.org_id or new.etudiant_id<>old.etudiant_id
       or new.encadreur_id is distinct from old.encadreur_id or new.motif_decision is distinct from old.motif_decision
       or new.sujet_statut<>old.sujet_statut or new.validation_exb<>old.validation_exb
       or new.validation_univ<>old.validation_univ or new.etape<>old.etape or new.progression<>old.progression
       or new.observation_encadreur is distinct from old.observation_encadreur
       or new.decide_le is distinct from old.decide_le or new.decide_par is distinct from old.decide_par
       or new.domaine<>old.domaine and old.statut not in ('brouillon','complement_demande') then
      raise exception 'TFL : modification non autorisée pour l''étudiant';
    end if;
    if new.statut<>old.statut then
      if not (old.statut in ('brouillon','complement_demande') and new.statut='recu') then
        raise exception 'TFL : changement de statut non autorisé';
      end if;
      new.depose_le := now();
    end if;
    return new;
  elsif est_enc then
    -- l'encadreur ne touche qu'à l'avancement et à son observation
    if (to_jsonb(new) - 'etape' - 'progression' - 'observation_encadreur' - 'updated_at')
       is distinct from (to_jsonb(old) - 'etape' - 'progression' - 'observation_encadreur' - 'updated_at') then
      raise exception 'TFL : l''encadreur ne peut modifier que l''étape, la progression et son observation';
    end if;
    return new;
  end if;
  raise exception 'TFL : accès refusé';
end $$;
drop trigger if exists tfl_garde_t on public.tfl_dossiers;
create trigger tfl_garde_t before update on public.tfl_dossiers
  for each row execute function public.tfl_garde();

-- 3c. Historique automatique
create or replace function public.tfl_histo() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  if tg_op='INSERT' then
    insert into tfl_historique(org_id,dossier_id,action,apres) values (new.org_id,new.id,'creation',jsonb_build_object('statut',new.statut));
  else
    if new.statut<>old.statut then
      insert into tfl_historique(org_id,dossier_id,action,avant,apres)
        values (new.org_id,new.id,'statut',jsonb_build_object('statut',old.statut),jsonb_build_object('statut',new.statut,'motif',new.motif_decision));
    end if;
    if new.encadreur_id is distinct from old.encadreur_id then
      insert into tfl_historique(org_id,dossier_id,action,avant,apres)
        values (new.org_id,new.id,'affectation',jsonb_build_object('encadreur',old.encadreur_id),jsonb_build_object('encadreur',new.encadreur_id));
    end if;
    if new.sujet_statut<>old.sujet_statut or new.validation_univ<>old.validation_univ or new.validation_exb<>old.validation_exb then
      insert into tfl_historique(org_id,dossier_id,action,avant,apres)
        values (new.org_id,new.id,'validation_sujet',
          jsonb_build_object('sujet',old.sujet_statut,'exb',old.validation_exb,'univ',old.validation_univ),
          jsonb_build_object('sujet',new.sujet_statut,'exb',new.validation_exb,'univ',new.validation_univ));
    end if;
    if new.etape<>old.etape then
      insert into tfl_historique(org_id,dossier_id,action,avant,apres)
        values (new.org_id,new.id,'etape',jsonb_build_object('etape',old.etape),jsonb_build_object('etape',new.etape));
    end if;
  end if;
  return null;
end $$;
drop trigger if exists tfl_histo_t on public.tfl_dossiers;
create trigger tfl_histo_t after insert or update on public.tfl_dossiers
  for each row execute function public.tfl_histo();

-- 3d. Affectation : respecte la charge maximale de l'encadreur
create or replace function public.tfl_controle_charge() returns trigger
language plpgsql security definer set search_path=public as $$
declare n int; m int;
begin
  if new.encadreur_id is not null and new.encadreur_id is distinct from old.encadreur_id then
    select max_etudiants into m from tfl_encadreurs where id=new.encadreur_id;
    select count(*) into n from tfl_dossiers where encadreur_id=new.encadreur_id and statut in ('accepte') and id<>new.id;
    if m is not null and n>=m then raise exception 'TFL : cet encadreur a atteint sa charge maximale (%)', m; end if;
  end if;
  return new;
end $$;
drop trigger if exists tfl_charge_t on public.tfl_dossiers;
create trigger tfl_charge_t before update on public.tfl_dossiers
  for each row execute function public.tfl_controle_charge();

-- 3e. Version de document (+1 par dossier / type / chapitre) et rôle d'auteur des commentaires
create or replace function public.tfl_avant_document() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  new.auteur_id := coalesce(auth.uid(), new.auteur_id);
  select coalesce(max(version),0)+1 into new.version from tfl_documents
    where dossier_id=new.dossier_id and type=new.type and coalesce(chapitre,'')=coalesce(new.chapitre,'');
  return new;
end $$;
drop trigger if exists tfl_avant_document_t on public.tfl_documents;
create trigger tfl_avant_document_t before insert on public.tfl_documents
  for each row execute function public.tfl_avant_document();

create or replace function public.tfl_avant_commentaire() returns trigger
language plpgsql security definer set search_path=public as $$
begin
  new.auteur_id := coalesce(auth.uid(), new.auteur_id);
  new.auteur_role := case when public.tfl_staff(new.org_id,true) then 'admin'
                          when public.tfl_dossier_encadreur(new.dossier_id) then 'encadreur'
                          else 'etudiant' end;
  return new;
end $$;
drop trigger if exists tfl_avant_commentaire_t on public.tfl_commentaires;
create trigger tfl_avant_commentaire_t before insert on public.tfl_commentaires
  for each row execute function public.tfl_avant_commentaire();

-- ---------- 4. Sécurité par ligne (RLS) ----------
do $$
declare t text;
begin
  foreach t in array array['tfl_parametres','tfl_compteurs','tfl_encadreurs','tfl_etudiants','tfl_dossiers','tfl_documents',
                           'tfl_commentaires','tfl_etapes','tfl_rendez_vous','tfl_soutenances','tfl_resultats','tfl_historique']
  loop execute format('alter table public.%I enable row level security', t); end loop;
end $$;
-- tfl_compteurs : aucune politique = inaccessible en direct (seul le trigger y écrit).

-- Paramètres : personnel seulement
drop policy if exists tfl_param_lire on public.tfl_parametres;
create policy tfl_param_lire on public.tfl_parametres for select to authenticated using (public.tfl_staff(org_id,false));
drop policy if exists tfl_param_ecrire on public.tfl_parametres;
create policy tfl_param_ecrire on public.tfl_parametres for all to authenticated using (public.tfl_staff(org_id,true)) with check (public.tfl_staff(org_id,true));

-- Encadreurs : personnel ; l'encadreur lui-même ; l'étudiant auquel il est affecté (nom et contact)
drop policy if exists tfl_enc_lire on public.tfl_encadreurs;
create policy tfl_enc_lire on public.tfl_encadreurs for select to authenticated using (
  public.tfl_staff(org_id,false) or user_id=auth.uid()
  or exists(select 1 from tfl_dossiers d where d.encadreur_id=tfl_encadreurs.id and d.statut in ('accepte','clos') and public.tfl_dossier_etudiant(d.id)));
drop policy if exists tfl_enc_ecrire on public.tfl_encadreurs;
create policy tfl_enc_ecrire on public.tfl_encadreurs for all to authenticated using (public.tfl_staff(org_id,true)) with check (public.tfl_staff(org_id,true));

-- Étudiants : personnel ; l'étudiant lui-même ; l'encadreur des dossiers acceptés qui lui sont affectés
drop policy if exists tfl_etu_lire on public.tfl_etudiants;
create policy tfl_etu_lire on public.tfl_etudiants for select to authenticated using (
  public.tfl_staff(org_id,false) or user_id=auth.uid()
  or exists(select 1 from tfl_dossiers d where d.etudiant_id=tfl_etudiants.id and public.tfl_dossier_encadreur(d.id)));
drop policy if exists tfl_etu_ins on public.tfl_etudiants;
create policy tfl_etu_ins on public.tfl_etudiants for insert to authenticated
  with check (public.tfl_staff(org_id,true) or user_id=auth.uid());
drop policy if exists tfl_etu_upd on public.tfl_etudiants;
create policy tfl_etu_upd on public.tfl_etudiants for update to authenticated
  using (public.tfl_staff(org_id,true) or user_id=auth.uid())
  with check (public.tfl_staff(org_id,true) or user_id=auth.uid());

-- Dossiers
drop policy if exists tfl_dos_lire on public.tfl_dossiers;
create policy tfl_dos_lire on public.tfl_dossiers for select to authenticated using (public.tfl_acces_dossier(id,org_id));
drop policy if exists tfl_dos_ins on public.tfl_dossiers;
create policy tfl_dos_ins on public.tfl_dossiers for insert to authenticated with check (
  public.tfl_staff(org_id,true)
  or (statut='brouillon' and encadreur_id is null and exists(select 1 from tfl_etudiants e where e.id=etudiant_id and e.user_id=auth.uid() and e.org_id=tfl_dossiers.org_id)));
drop policy if exists tfl_dos_upd on public.tfl_dossiers;
create policy tfl_dos_upd on public.tfl_dossiers for update to authenticated
  using (public.tfl_staff(org_id,true)
         or (statut in ('brouillon','complement_demande') and public.tfl_dossier_etudiant(id))
         or public.tfl_dossier_encadreur(id))
  with check (public.tfl_staff(org_id,true) or public.tfl_dossier_etudiant(id) or public.tfl_dossier_encadreur(id));
-- Pas de suppression en direct : un dossier se « clôture » ou se « refuse », il ne disparaît pas.

-- Tables enfants : lecture = accès au dossier
do $$
declare t text;
begin
  foreach t in array array['tfl_documents','tfl_commentaires','tfl_etapes','tfl_rendez_vous','tfl_soutenances']
  loop
    execute format('drop policy if exists %I_lire on public.%I', t, t);
    execute format('create policy %I_lire on public.%I for select to authenticated using (public.tfl_acces_dossier(dossier_id,org_id))', t, t);
  end loop;
end $$;

-- Documents et commentaires : étudiant et encadreur déposent, uniquement sur un dossier ACCEPTÉ ; le personnel partout
drop policy if exists tfl_doc_ins on public.tfl_documents;
create policy tfl_doc_ins on public.tfl_documents for insert to authenticated with check (
  auteur_id=auth.uid() and exists(select 1 from tfl_dossiers d where d.id=dossier_id and d.org_id=tfl_documents.org_id) and (
    public.tfl_staff(org_id,true)
    or ((public.tfl_dossier_etudiant(dossier_id) or public.tfl_dossier_encadreur(dossier_id))
        and exists(select 1 from tfl_dossiers d where d.id=dossier_id and d.statut='accepte'))));
drop policy if exists tfl_doc_upd on public.tfl_documents;   -- seul l'état (revue, correction, validation) change : par l'encadreur ou le personnel
create policy tfl_doc_upd on public.tfl_documents for update to authenticated
  using (public.tfl_staff(org_id,true) or public.tfl_dossier_encadreur(dossier_id))
  with check (public.tfl_staff(org_id,true) or public.tfl_dossier_encadreur(dossier_id));

drop policy if exists tfl_com_ins on public.tfl_commentaires;
create policy tfl_com_ins on public.tfl_commentaires for insert to authenticated with check (
  auteur_id=auth.uid() and exists(select 1 from tfl_dossiers d where d.id=dossier_id and d.org_id=tfl_commentaires.org_id) and (
    public.tfl_staff(org_id,true)
    or ((public.tfl_dossier_etudiant(dossier_id) or public.tfl_dossier_encadreur(dossier_id))
        and exists(select 1 from tfl_dossiers d where d.id=dossier_id and d.statut='accepte'))
    or (public.tfl_dossier_etudiant(dossier_id)   -- l'étudiant peut répondre à une demande de complément
        and exists(select 1 from tfl_dossiers d where d.id=dossier_id and d.statut='complement_demande'))));

-- Étapes et rendez-vous : personnel et encadreur du dossier
do $$
declare t text;
begin
  foreach t in array array['tfl_etapes','tfl_rendez_vous']
  loop
    execute format('drop policy if exists %I_ins on public.%I', t, t);
    execute format('create policy %I_ins on public.%I for insert to authenticated with check (public.tfl_staff(org_id,true) or public.tfl_dossier_encadreur(dossier_id))', t, t);
    execute format('drop policy if exists %I_upd on public.%I', t, t);
    execute format('create policy %I_upd on public.%I for update to authenticated using (public.tfl_staff(org_id,true) or public.tfl_dossier_encadreur(dossier_id)) with check (public.tfl_staff(org_id,true) or public.tfl_dossier_encadreur(dossier_id))', t, t);
  end loop;
end $$;

-- Soutenances : le personnel planifie et compose le jury ; l'étudiant et l'encadreur lisent
drop policy if exists tfl_sout_ecrire on public.tfl_soutenances;
create policy tfl_sout_ecrire on public.tfl_soutenances for all to authenticated using (public.tfl_staff(org_id,true)) with check (public.tfl_staff(org_id,true));

-- Résultats : personnel ; l'étudiant seulement quand ils sont publiés
drop policy if exists tfl_res_lire on public.tfl_resultats;
create policy tfl_res_lire on public.tfl_resultats for select to authenticated using (
  public.tfl_staff(org_id,false) or (publie and public.tfl_dossier_etudiant(dossier_id)));
drop policy if exists tfl_res_ecrire on public.tfl_resultats;
create policy tfl_res_ecrire on public.tfl_resultats for all to authenticated using (public.tfl_staff(org_id,true)) with check (public.tfl_staff(org_id,true));

-- Historique : lecture par le personnel ; aucune écriture directe (triggers uniquement)
drop policy if exists tfl_hist_lire on public.tfl_historique;
create policy tfl_hist_lire on public.tfl_historique for select to authenticated using (public.tfl_staff(org_id,false));

-- Licence : même règle restrictive que le reste du logiciel (écriture bloquée si licence suspendue ou expirée)
do $$
declare t text;
begin
  foreach t in array array['tfl_parametres','tfl_encadreurs','tfl_etudiants','tfl_dossiers','tfl_documents',
                           'tfl_commentaires','tfl_etapes','tfl_rendez_vous','tfl_soutenances','tfl_resultats']
  loop
    execute format('drop policy if exists licence_ins on public.%I', t);
    execute format('create policy licence_ins on public.%I as restrictive for insert with check (licence_ecriture_ok(org_id))', t);
    execute format('drop policy if exists licence_upd on public.%I', t);
    execute format('create policy licence_upd on public.%I as restrictive for update using (licence_ecriture_ok(org_id)) with check (licence_ecriture_ok(org_id))', t);
  end loop;
end $$;

-- ---------- 5. Stockage des fichiers (bucket privé « tfl-documents ») ----------
-- Chemin imposé : <org_id>/<dossier_id>/<nom du fichier>
insert into storage.buckets (id, name, public, file_size_limit)
values ('tfl-documents','tfl-documents',false, 20971520)      -- 20 Mo par fichier
on conflict (id) do update set public=false, file_size_limit=20971520;

create or replace function public.tfl_chemin_dossier(p_name text) returns uuid
language sql immutable as $$
  select case when (storage.foldername(p_name))[2] ~ '^[0-9a-f-]{36}$' then ((storage.foldername(p_name))[2])::uuid end $$;

drop policy if exists tfl_obj_lire on storage.objects;
create policy tfl_obj_lire on storage.objects for select to authenticated using (
  bucket_id='tfl-documents' and exists(select 1 from tfl_dossiers d
    where d.id=public.tfl_chemin_dossier(name) and public.tfl_acces_dossier(d.id,d.org_id)));
drop policy if exists tfl_obj_ajout on storage.objects;
create policy tfl_obj_ajout on storage.objects for insert to authenticated with check (
  bucket_id='tfl-documents' and exists(select 1 from tfl_dossiers d
    where d.id=public.tfl_chemin_dossier(name) and d.org_id::text=(storage.foldername(name))[1]
      and (public.tfl_staff(d.org_id,true)
           or ((public.tfl_dossier_etudiant(d.id) or public.tfl_dossier_encadreur(d.id)) and d.statut='accepte'))));
-- Pas de modification ni de suppression en direct : une nouvelle version = un nouveau fichier.

-- ---------- 6. Contrôles à lancer après installation ----------
--  select tablename, policyname, cmd from pg_policies where tablename like 'tfl\_%' order by 1,2;
--  select count(*) from pg_trigger where tgname like 'tfl\_%' and not tgisinternal;   -- attendu : 6

-- ---------- 7. Liaison d'un compte à sa fiche (étudiant ou encadreur créé par l'administration) ----------
-- L'administration crée la fiche avec l'e-mail ; au premier accès, la personne appelle cette fonction avec son compte.
create or replace function public.tfl_lier_mon_compte(p_org uuid)
returns json language plpgsql security definer set search_path=public as $$
declare em text := lower(coalesce(auth.jwt()->>'email','')); n_enc int; n_etu int;
begin
  if auth.uid() is null or em='' then raise exception 'Connexion requise'; end if;
  update tfl_encadreurs set user_id=auth.uid() where org_id=p_org and user_id is null and lower(email)=em;
  get diagnostics n_enc = row_count;
  update tfl_etudiants set user_id=auth.uid() where org_id=p_org and user_id is null and lower(email)=em;
  get diagnostics n_etu = row_count;
  return json_build_object('encadreur',n_enc,'etudiant',n_etu);
end $$;
revoke all on function public.tfl_lier_mon_compte(uuid) from public, anon;
grant execute on function public.tfl_lier_mon_compte(uuid) to authenticated;

-- ---------- 8. Matricule et photo de l'étudiant (voir aussi sql-parties/partie-09.sql) ----------
alter table public.tfl_etudiants add column if not exists matricule text;
alter table public.tfl_etudiants add column if not exists photo text;
create unique index if not exists tfl_etudiants_matricule_uq on public.tfl_etudiants (org_id, matricule) where matricule is not null;
