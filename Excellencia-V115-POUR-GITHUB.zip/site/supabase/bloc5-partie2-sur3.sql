-- TFL bloc 5 — PARTIE 2 sur 3 (envoi du bordereau, liste, téléchargement, suppression). À exécuter APRÈS la partie 1. Réexécutable.

-- 2) Envoi d'un morceau du bordereau (0, 1, 2…) : 1 200 000 caractères base64 (900 Ko) sauf le dernier.
create or replace function public.tfl_paiement_partie(p_ident text, p_mdp text, p_id uuid, p_idx int, p_b64 text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; d public.tfl_paiements; v_ext text; v_h bytea;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into d from public.tfl_paiements where id = p_id and acces_id = c.v_id and statut = 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  if coalesce(p_b64,'') !~ '^[A-Za-z0-9+/]+={0,2}$' or length(p_b64) % 4 <> 0 or length(p_b64) > 1200000 or (p_idx < d.parties - 1 and length(p_b64) <> 1200000) then
    return jsonb_build_object('ok', false, 'code', 'invalide');
  end if;
  if p_idx = 0 then   -- signature du fichier : l'extension annoncée doit correspondre au contenu
    v_ext := lower(substring(d.nom_fichier from '\.([A-Za-z0-9]+)$'));
    v_h := decode(left(p_b64, 16), 'base64');
    if not (case
        when v_ext = 'pdf' then substring(v_h from 1 for 4) = '\x25504446'
        when v_ext in ('jpg','jpeg') then substring(v_h from 1 for 3) = '\xffd8ff'
        when v_ext = 'png' then substring(v_h from 1 for 4) = '\x89504e47'
        else false end) then
      delete from public.tfl_paiements where id = d.id;
      return jsonb_build_object('ok', false, 'code', 'contenu');
    end if;
  end if;
  insert into public.tfl_paiements_parties(paiement_id, idx, b64) values (d.id, p_idx, p_b64)
  on conflict (paiement_id, idx) do update set b64 = excluded.b64;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_partie(text,text,uuid,int,text) from public;
grant execute on function public.tfl_paiement_partie(text,text,uuid,int,text) to anon, authenticated;

-- 3) Fin de l'envoi : tous les morceaux sont là et la taille correspond → le paiement passe « en attente de vérification ».
create or replace function public.tfl_paiement_terminer(p_ident text, p_mdp text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; d public.tfl_paiements; v_n int; v_oct bigint;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into d from public.tfl_paiements where id = p_id and acces_id = c.v_id and statut = 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  select count(*), coalesce(sum(length(decode(b64, 'base64'))), 0) into v_n, v_oct from public.tfl_paiements_parties where paiement_id = d.id;
  if v_n <> d.parties or v_oct <> d.taille then return jsonb_build_object('ok', false, 'code', 'incomplet'); end if;
  update public.tfl_paiements set statut = 'en_attente', maj_le = now() where id = d.id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_terminer(text,text,uuid) from public;
grant execute on function public.tfl_paiement_terminer(text,text,uuid) to anon, authenticated;

-- 4) Les paiements de SON dossier (sans le fichier) + les totaux. Les paiements en cours d'envoi ne sont pas listés.
create or replace function public.tfl_paiement_liste(p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  v_d := coalesce(a.contenu->>'numero','');
  return jsonb_build_object('ok', true,
    'paiements', coalesce((select jsonb_agg(public.tfl_paiement_json(x) order by x.cree_le desc)
      from (select * from public.tfl_paiements where dossier = v_d and statut <> 'envoi' order by cree_le desc limit 100) x), '[]'::jsonb),
    'confirme', coalesce((select sum(montant_confirme) from public.tfl_paiements where dossier = v_d and statut = 'confirme'), 0),
    'en_attente', coalesce((select sum(montant) from public.tfl_paiements where dossier = v_d and statut = 'en_attente'), 0));
end $$;
revoke all on function public.tfl_paiement_liste(text,text) from public;
grant execute on function public.tfl_paiement_liste(text,text) to anon, authenticated;

-- 5) Téléchargement d'un morceau de SON bordereau.
create or replace function public.tfl_paiement_telecharger(p_ident text, p_mdp text, p_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; d public.tfl_paiements; v text;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  select * into d from public.tfl_paiements where id = p_id;
  if not found or d.statut = 'envoi' or d.parties < 1 or d.dossier <> coalesce(a.contenu->>'numero','') then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  select b64 into v from public.tfl_paiements_parties where paiement_id = d.id and idx = p_idx;
  if v is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true, 'b64', v, 'parties', d.parties, 'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille);
end $$;
revoke all on function public.tfl_paiement_telecharger(text,text,uuid,int) from public;
grant execute on function public.tfl_paiement_telecharger(text,text,uuid,int) to anon, authenticated;

-- 6) Suppression par l'étudiant : seulement SES déclarations encore « en attente » ou « refusées » (jamais un paiement confirmé).
create or replace function public.tfl_paiement_supprimer(p_ident text, p_mdp text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; n int;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  delete from public.tfl_paiements where id = p_id and acces_id = c.v_id and source = 'etudiant' and statut in ('en_attente','refuse');
  get diagnostics n = row_count;
  if n = 0 then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_supprimer(text,text,uuid) from public;
grant execute on function public.tfl_paiement_supprimer(text,text,uuid) to anon, authenticated;
