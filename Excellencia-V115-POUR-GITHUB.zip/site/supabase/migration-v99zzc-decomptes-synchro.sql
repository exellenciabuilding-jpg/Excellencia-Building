-- ===== Excellencia Building — V99zzc : synchronisation sécurisée des marchés et décomptes (collection « decomptes ») =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS les migrations précédentes. Réexécutable sans danger.
-- Les marchés et décomptes (Finance › Décomptes) passent dans le stockage versionné « enregistrements » comme les autres modules :
-- partagés avec l'équipe selon les droits, détection de conflit, journal, licence et 2FA appliquées par peut()/enregistrer().
-- Droits : copiés de la collection « finance » (direction, comptable, chef de projet… selon droits_fonction). Rien n'est écrasé.

insert into droits_fonction(fonction, collection, lire, ecrire)
select d.fonction, 'decomptes', d.lire, d.ecrire
from droits_fonction d
where d.collection = 'finance'
on conflict (fonction, collection) do nothing;

-- Vérification (à la main) :
--   select fonction, lire, ecrire from droits_fonction where collection = 'decomptes' order by fonction;
