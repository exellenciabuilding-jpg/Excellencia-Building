-- ===== Excellencia Building V111 — Vérification publique de la carte d'étudiant TFL =====
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable. Ne supprime rien. Petit script : se colle d'un coup, même sur téléphone.
-- Le QR de la carte (verification.html?m=MATRICULE) affiche une fiche de vérification : nom, matricule, université,
-- faculté, filière, promotion, niveau, année académique, état du dossier TFL.
-- Jamais : notes, téléphone, e-mail, sujet, encadreur, messages, paiements.
-- Les données viennent de l'instantané publié par « 📡 Republier les portails ».

create or replace function public.tfl_carte_verifier(p_m text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v_m text := upper(regexp_replace(coalesce(p_m, ''), '[^A-Za-z0-9]', '', 'g'));
  a public.tfl_acces;
  c jsonb;
begin
  if length(v_m) < 3 then return jsonb_build_object('found', false); end if;
  -- limite par adresse IP (si la fonction du script V99zzy existe) : évite de deviner des matricules en série
  begin
    perform public.exb_ip_limite('tfl_carte', 60);
  exception when undefined_function then null;
  end;
  select * into a from public.tfl_acces
   where role = 'etudiant'
     and (identifiant = v_m or upper(regexp_replace(coalesce(contenu->>'matricule', ''), '[^A-Za-z0-9]', '', 'g')) = v_m)
   order by publie_le desc limit 1;
  if not found then return jsonb_build_object('found', false); end if;
  c := coalesce(a.contenu, '{}'::jsonb);
  return jsonb_build_object(
    'found', true,
    'actif', a.actif,
    'nom', a.nom,
    'matricule', coalesce(nullif(c->>'matricule', ''), a.identifiant),
    'universite', coalesce(c->>'universite', ''),
    'faculte', coalesce(c->>'faculte', ''),
    'filiere', coalesce(c->>'filiere', ''),
    'promotion', coalesce(c->>'promotion', ''),
    'niveau', coalesce(c->>'niveau', ''),
    'annee_academique', coalesce(c->>'annee_academique', ''),
    'statut', coalesce(c->>'statut_label', ''),
    'publie_le', a.publie_le
  );
end $$;
revoke all on function public.tfl_carte_verifier(text) from public;
grant execute on function public.tfl_carte_verifier(text) to anon, authenticated;

-- Contrôle : select public.tfl_carte_verifier('VOTRE-MATRICULE');  → {"found": true, ...}
