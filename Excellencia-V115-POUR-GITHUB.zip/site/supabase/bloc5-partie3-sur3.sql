-- TFL bloc 5 — PARTIE 3 sur 3 (administration). À exécuter APRÈS les parties 1 et 2. Réexécutable.

-- ---------- Administration (e-mail administrateur connecté) ----------
create or replace function public.tfl_paiements_admin_liste(p_dossier text default null)
returns jsonb language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(public.tfl_paiement_json(x) || jsonb_build_object('auteur', coalesce(a.nom, '')) order by x.cree_le desc)
    from (select * from public.tfl_paiements t where t.statut <> 'envoi' and (p_dossier is null or t.dossier = p_dossier) order by t.cree_le desc limit 500) x
    left join public.tfl_acces a on a.id = x.acces_id), '[]'::jsonb);
end $$;
revoke all on function public.tfl_paiements_admin_liste(text) from public, anon;
grant execute on function public.tfl_paiements_admin_liste(text) to authenticated;

-- Résumé par dossier et par devise (tableau « Frais TFL » de l'administration).
create or replace function public.tfl_paiements_admin_resume()
returns jsonb language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('dossier', t.dossier, 'devise', t.devise, 'confirme', t.confirme, 'en_attente_n', t.en_attente_n,
      'en_attente_montant', t.en_attente_montant, 'dernier', t.dernier) order by t.dossier)
    from (select dossier, devise,
            coalesce(sum(montant_confirme) filter (where statut = 'confirme'), 0) as confirme,
            count(*) filter (where statut = 'en_attente') as en_attente_n,
            coalesce(sum(montant) filter (where statut = 'en_attente'), 0) as en_attente_montant,
            max(cree_le) as dernier
          from public.tfl_paiements where statut <> 'envoi' group by dossier, devise) t), '[]'::jsonb);
end $$;
revoke all on function public.tfl_paiements_admin_resume() from public, anon;
grant execute on function public.tfl_paiements_admin_resume() to authenticated;

create or replace function public.tfl_paiement_admin_telecharger(p_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare d public.tfl_paiements; v text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi' and parties > 0;
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  select b64 into v from public.tfl_paiements_parties where paiement_id = d.id and idx = p_idx;
  if v is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true, 'b64', v, 'parties', d.parties, 'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille);
end $$;
revoke all on function public.tfl_paiement_admin_telecharger(uuid,int) from public, anon;
grant execute on function public.tfl_paiement_admin_telecharger(uuid,int) to authenticated;

-- Décision : confirme (montant réellement reçu, numéro de reçu), refuse (motif obligatoire) ou remet en attente.
create or replace function public.tfl_paiement_admin_decider(p_id uuid, p_statut text, p_montant numeric default null, p_motif text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare d public.tfl_paiements; v_motif text := left(btrim(coalesce(p_motif,'')), 500); v_m numeric(12,2);
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('confirme','refuse','en_attente') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_statut = 'confirme' then
    v_m := round(coalesce(p_montant, d.montant), 2);
    if v_m <= 0 or v_m > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
    update public.tfl_paiements set statut = 'confirme', montant_confirme = v_m, motif = v_motif, recu_no = coalesce(recu_no, public.tfl_recu_numero()), decide_le = now(), maj_le = now() where id = d.id;
  elsif p_statut = 'refuse' then
    if length(v_motif) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    update public.tfl_paiements set statut = 'refuse', montant_confirme = null, motif = v_motif, recu_no = null, decide_le = now(), maj_le = now() where id = d.id;
  else
    update public.tfl_paiements set statut = 'en_attente', montant_confirme = null, motif = '', recu_no = null, decide_le = null, maj_le = now() where id = d.id;
  end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) from public, anon;
grant execute on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) to authenticated;

-- Paiement reçu en caisse ou enregistré par l'administration : directement confirmé, avec son reçu.
create or replace function public.tfl_paiement_admin_ajouter(p_dossier text, p_montant numeric, p_devise text, p_mode text, p_reference text, p_date date, p_note text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_m numeric(12,2); v_id uuid; v_recu text; v_dev text := upper(left(coalesce(nullif(btrim(p_devise), ''), 'USD'), 5));
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if v_d = '' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 800 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 60 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  v_m := round(p_montant, 2); v_recu := public.tfl_recu_numero();
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, statut, montant_confirme, recu_no, decide_le)
  values (null, v_d, 'administration', v_m, v_dev, p_mode, left(btrim(coalesce(p_reference,'')), 80), p_date, left(btrim(coalesce(p_note,'')), 500), 'confirme', v_m, v_recu, now())
  returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id, 'recu_no', v_recu);
end $$;
revoke all on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) from public, anon;
grant execute on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) to authenticated;

create or replace function public.tfl_paiement_admin_supprimer(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  delete from public.tfl_paiements where id = p_id;
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_paiement_admin_supprimer(uuid) from public, anon;
grant execute on function public.tfl_paiement_admin_supprimer(uuid) to authenticated;

-- Contrôle : select proname from pg_proc where proname like 'tfl_paiement%';  → 13 lignes
--   (étudiant : tfl_paiement_creer, _partie, _terminer, _liste, _telecharger, _supprimer ; interne : tfl_paiement_json ;
--    administration : tfl_paiements_admin_liste, tfl_paiements_admin_resume, tfl_paiement_admin_telecharger, _admin_decider, _admin_ajouter, _admin_supprimer)
-- Et : select tablename, rowsecurity from pg_tables where tablename like 'tfl_paiements%';  → 2 lignes, rowsecurity = true
