-- ===== Excellencia Building — V99zo : sécurité côté serveur (licence appliquée à l'écriture, appels anonymes, anti-spam) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, APRÈS toutes les autres migrations (après migration-v99zn-synchro-modules.sql).
-- Réexécutable sans danger. FAITES D'ABORD UNE SAUVEGARDE et essayez sur un projet de recette.
--
-- CE QUE FAIT CE SCRIPT (constats de l'audit des politiques RLS, voir README-V99zo-SECURITE-SERVEUR.md)
--  1. LICENCE APPLIQUÉE CÔTÉ SERVEUR : une entreprise dont la licence est suspendue / résiliée, ou échue depuis plus de 7 jours
--     (même tolérance que pour rejoindre l'entreprise), ne peut plus ÉCRIRE. La lecture reste possible (export, sauvegarde).
--     Avant : seule l'adhésion de nouveaux membres était bloquée ; les membres existants écrivaient encore.
--  2. exb_generer_recurrences() : un appel ANONYME (sans connexion) pouvait lancer la génération pour TOUTES les entreprises
--     (le cas « auth.uid() nul = pg_cron » le permettait). Désormais réservée aux utilisateurs connectés, à pg_cron et à la clé de service.
--  3. Les fonctions d'API qui exigent une connexion ne sont plus exécutables par le rôle anonyme (surface réduite).
--     Restent ouvertes, volontairement : vérification de documents (exb_doc_verify, exb_doc_verify2, exb_doc_search),
--     dépôt d'inscription / copie / paiement (exb_doc_declare, exb_doc_declare_copie, paiement_declarer) et les fonctions d'aide aux politiques.
--  4. paiement_declarer() : plafond global de 300 déclarations par heure (avant : seulement 5 par numéro, donc contournable).

-- ---------- 1. Licence appliquée à l'écriture ----------
create or replace function licence_ecriture_ok(p_org uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select coalesce((
    select not (l.statut in ('suspendu','resilie') or (l.expire_le is not null and l.expire_le < now() - interval '7 days'))
    from licences_clients l where l.org_id=p_org order by l.cree_le desc limit 1), true) $$;
grant execute on function licence_ecriture_ok(uuid) to authenticated, service_role;

create or replace function enregistrer(p_org uuid, p_col text, p_id text, p_data jsonb, p_base int, p_supprime boolean default false)
returns json language plpgsql security definer set search_path=public as $$
declare cur enregistrements; nv int;
begin
  if not peut(p_org,p_col,true) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus',0);
    return json_build_object('ok',false,'refus',true);
  end if;
  if not licence_ecriture_ok(p_org) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus licence',0);
    return json_build_object('ok',false,'refus',true,'licence',true);
  end if;
  select * into cur from enregistrements where org_id=p_org and collection=p_col and id=p_id for update;
  if found then
    if cur.version<>p_base then
      return json_build_object('ok',false,'conflit',true,'version',cur.version,'data',cur.data,'supprime',cur.supprime);
    end if;
    nv:=cur.version+1;
    update enregistrements set data=p_data,version=nv,supprime=p_supprime,maj=now(),maj_par=auth.uid()
      where org_id=p_org and collection=p_col and id=p_id;
  else
    if p_base<>0 then
      return json_build_object('ok',false,'conflit',true,'version',0,'data',null,'supprime',true);
    end if;
    nv:=1;
    insert into enregistrements(org_id,collection,id,data,version,supprime,maj_par) values (p_org,p_col,p_id,p_data,1,p_supprime,auth.uid());
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org,auth.uid(),p_col,p_id,case when p_supprime then 'suppression' when nv=1 then 'création' else 'modification' end,nv);
  return json_build_object('ok',true,'version',nv);
end $$;

-- Même règle pour les tables dédiées (erp_*, btp_*, paiements, caisse, CDE, BIM…) : politique RESTRICTIVE sur l'écriture.
do $$ declare r record; begin
  for r in select distinct c.table_name from information_schema.columns c
           join information_schema.tables t on t.table_schema=c.table_schema and t.table_name=c.table_name and t.table_type='BASE TABLE'
           where c.table_schema='public' and c.column_name='org_id'
             and c.table_name not in ('membres','licences_clients','invitations_equipe','journal_entreprise','organisations','enregistrements')
  loop
    execute format('drop policy if exists licence_ins on %I', r.table_name);
    execute format('create policy licence_ins on %I as restrictive for insert with check (licence_ecriture_ok(org_id))', r.table_name);
    execute format('drop policy if exists licence_upd on %I', r.table_name);
    execute format('create policy licence_upd on %I as restrictive for update using (licence_ecriture_ok(org_id)) with check (licence_ecriture_ok(org_id))', r.table_name);
    execute format('drop policy if exists licence_del on %I', r.table_name);
    execute format('create policy licence_del on %I as restrictive for delete using (licence_ecriture_ok(org_id))', r.table_name);
  end loop;
end $$;

-- ---------- 2. Génération automatique des récurrences : plus d'appel anonyme ----------
do $$ declare src text; begin
  select pg_get_functiondef('exb_generer_recurrences(uuid)'::regprocedure) into src;
  if src not like '%V99zo%' then
    src := replace(src, 'declare r record; n int:=0; m int; nd date; nid text;
begin', 'declare r record; n int:=0; m int; nd date; nid text;
begin
 -- V99zo : jamais pour un appel anonyme (clé publique sans connexion)
 if auth.uid() is null and coalesce(auth.role(),'''') in (''anon'','''') and session_user in (''authenticator'',''anon'',''authenticated'',''supabase_auth_admin'') then raise exception ''accès refusé''; end if;');
    execute src;
  end if;
end $$;

-- ---------- 3. Fonctions d'API réservées aux utilisateurs connectés ----------
do $$ declare f text; begin
  foreach f in array array[
    'enregistrer(uuid,text,text,jsonb,integer,boolean)','mon_organisation()','creer_organisation(text,text)','rejoindre_organisation(text,text)',
    'renouveler_code(uuid)','exb_generer_recurrences(uuid)','core_creer_notification(uuid,uuid,text,text,jsonb)','core_marquer_notification_lue(uuid)']
  loop
    if to_regprocedure(f) is not null then
      execute format('revoke execute on function %s from public, anon', f);
      execute format('grant execute on function %s to authenticated, service_role', f);
    end if;
  end loop;
end $$;

-- ---------- 4. Déclaration de paiement : plafond global ----------
CREATE OR REPLACE FUNCTION public.paiement_declarer(p_data jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_type text := p_data->>'type';
  v_ref  text := left(btrim(coalesce(p_data->>'reference','')), 40);
  v_tel  text := left(regexp_replace(coalesce(p_data->>'numero',''), '[^0-9+]', '', 'g'), 20);
  v_mont numeric; v_dbl boolean; v_id bigint;
begin
  if v_type is null or v_type not in ('apprenant','logiciel','projet') then raise exception 'type_invalide'; end if;
  begin v_mont := (p_data->>'montant')::numeric; exception when others then raise exception 'montant_invalide'; end;
  if v_mont is null or v_mont <= 0 or v_mont > 100000 then raise exception 'montant_invalide'; end if;
  if length(v_ref) < 3 then raise exception 'reference_invalide'; end if;
  if length(regexp_replace(v_tel, '[^0-9]', '', 'g')) < 8 then raise exception 'telephone_invalide'; end if;
  if (select count(*) from public.paiements_declares where numero_payeur = v_tel and created_at > now() - interval '1 hour') >= 5
    then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.paiements_declares where created_at > now() - interval '1 hour') >= 300
    then raise exception 'trop_de_demandes'; end if;
  select exists(select 1 from public.paiements_declares where lower(reference) = lower(v_ref)) into v_dbl;
  insert into public.paiements_declares(type, nom, telephone, matricule, montant, devise, reseau, numero_payeur, reference, doublon)
  values (v_type, left(p_data->>'nom',120), left(p_data->>'telephone',30), left(p_data->>'matricule',40), v_mont,
          case when p_data->>'devise' in ('USD','CDF') then p_data->>'devise' else 'USD' end,
          left(p_data->>'reseau',30), v_tel, v_ref, v_dbl)
  returning id into v_id;
  return jsonb_build_object('id', v_id, 'doublon', v_dbl);
end $function$;

-- ---------- Vérifications (à lancer à la main) ----------
-- select licence_ecriture_ok('<id de l''entreprise>');                         -- false si licence suspendue ou échue depuis plus de 7 jours
-- select has_function_privilege('anon','exb_generer_recurrences(uuid)','execute');  -- doit être false
