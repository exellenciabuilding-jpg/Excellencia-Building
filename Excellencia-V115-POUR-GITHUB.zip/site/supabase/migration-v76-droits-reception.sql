-- Excellencia Building V76 — droits par fonction pour la réception de chantier (collection « receptions »).
-- À exécuter UNE fois après migration-v75-droits-v69-v74.sql. Réexécutable sans danger.
insert into droits_fonction(fonction,collection,lire,ecrire) values
 ('direction','receptions',true,true),
 ('chef_projet','receptions',true,true),
 ('conducteur','receptions',true,true),
 ('bureau_etudes','receptions',true,false),
 ('comptable','receptions',true,false),
 ('magasinier','receptions',false,false)
on conflict (fonction,collection) do nothing;   -- les droits déjà personnalisés sont conservés
