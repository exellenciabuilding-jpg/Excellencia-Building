-- V99 — Source de vérité unique pour plans / CDE / BIM : le modèle V94.
-- À exécuter après migration-v94-architecture-bim-cde.sql (réexécutable).
--
-- Constat : les données transitent toutes par la table générique « enregistrements » (une collection = un nom).
-- Les 8 tables dédiées V94 (plans_v94, revisions_plans_v94, bim_issues_v94…) n'ont jamais été alimentées par l'application.
-- Décision : la source de vérité = les COLLECTIONS V94 (plans_v94, revisions_plans_v94, visas_v94, diffusions_v94,
-- documents_cde_v94, bim_models_v94, bim_issues_v94). Les anciennes collections (plans, cde, bim_issues) sont figées (sauvegarde).

-- 1) Les droits des anciennes collections sont reportés sur les nouvelles (aucun utilisateur ne perd ni ne gagne d'accès par rapport à avant ;
--    si le droit V94 existait déjà et était plus large, on garde le plus large).
insert into droits_fonction(fonction,collection,lire,ecrire)
select d.fonction,m.nouvelle,d.lire,d.ecrire
from droits_fonction d
join (values
  ('plans','plans_v94'),('plans','revisions_plans_v94'),('plans','visas_v94'),('plans','diffusions_v94'),
  ('cde','documents_cde_v94'),
  ('bim_issues','bim_issues_v94'),('bim_issues','bim_models_v94')
) as m(ancienne,nouvelle) on m.ancienne=d.collection
on conflict (fonction,collection) do update
  set lire=droits_fonction.lire or excluded.lire,
      ecrire=droits_fonction.ecrire or excluded.ecrire;

-- 2) Les tables dédiées V94 ne sont pas la source de vérité : on le dit dans le schéma (pas de suppression de données).
do $$ declare t text; begin
  foreach t in array array['plans_v94','revisions_plans_v94','visas_v94','documents_cde_v94','bim_models_v94','bim_issues_v94','diffusions_v94','etudes_v94'] loop
    if to_regclass(t) is not null then execute format('comment on table %I is %L',t,'OBSOLÈTE (V99) : non alimentée par l''application. Source de vérité = collection du même nom dans la table enregistrements.'); end if;
  end loop;
end $$;
