-- Excellencia Building — TFL bloc 3/5 : ENVOI DE DOCUMENTS (plan, chapitres, version finale, corrections).
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzt-tfl-portails.sql (accès étudiants / encadreurs, tfl_acces_check, tfl_admin_ok).
-- Les blocs 1 et 2 ne sont pas nécessaires à celui-ci.
--
-- Principe (comme les plans et esquisses) : les fichiers restent sur le serveur, dans la base (base64), jamais dans un dossier public.
--   · Étudiant (dossier ACCEPTÉ) : envoie un plan, un chapitre, la version finale ou un autre document, puis suit son état.
--   · Encadreur : voit les documents de SES étudiants (selon l'instantané publié), les télécharge, les marque « À corriger » (commentaire
--     obligatoire) ou « Validé », et peut renvoyer à l'étudiant un document de correction.
--   · Administration (e-mail administrateur) : voit, télécharge, décide et supprime tous les documents.
-- Fichiers : PDF, Word, OpenDocument, PowerPoint, Excel, JPG, PNG ; 15 Mo au plus ; envoi par morceaux de 900 Ko (téléphone, connexion lente).
-- Le serveur vérifie l'extension ET la signature du fichier (un .pdf qui n'est pas un PDF est refusé).
-- Limites par accès : 20 envois par heure, 60 documents, 150 Mo au total. Mot de passe vérifié à chaque appel (5 essais ratés = blocage).

create table if not exists public.tfl_envois (
  id uuid primary key default gen_random_uuid(),
  acces_id uuid not null references public.tfl_acces(id) on delete cascade,
  de text not null check (de in ('etudiant','encadreur')),
  dossier text not null,
  genre text not null check (genre in ('plan','chapitre','version_finale','correction','autre')),
  titre text not null,
  note text not null default '',
  nom_fichier text not null,
  mime text not null default 'application/octet-stream',
  taille bigint not null default 0,
  parties int not null default 1,
  statut text not null default 'envoi' check (statut in ('envoi','depose','a_corriger','valide')),
  commentaire text not null default '',
  decide_par text not null default '',
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now()
);
create index if not exists tfl_envois_dossier_idx on public.tfl_envois (dossier, cree_le);
create index if not exists tfl_envois_acces_idx on public.tfl_envois (acces_id, cree_le);
alter table public.tfl_envois enable row level security;
revoke all on public.tfl_envois from anon, authenticated;

create table if not exists public.tfl_envois_parties (
  doc_id uuid not null references public.tfl_envois(id) on delete cascade,
  idx int not null,
  b64 text not null,
  primary key (doc_id, idx)
);
alter table public.tfl_envois_parties enable row level security;
revoke all on public.tfl_envois_parties from anon, authenticated;

-- Ce document est-il visible par cet accès ? (étudiant : son dossier ; encadreur : les dossiers de son instantané ; chacun voit ses envois)
create or replace function public.tfl_doc_visible(a public.tfl_acces, d public.tfl_envois) returns boolean
language sql stable set search_path = public as $$
  select d.acces_id = a.id or (d.statut <> 'envoi' and (
    case when a.role = 'etudiant' then d.dossier = coalesce(a.contenu->>'numero','')
         else exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = d.dossier) end))
$$;
revoke all on function public.tfl_doc_visible(public.tfl_acces, public.tfl_envois) from public, anon, authenticated;

create or replace function public.tfl_doc_json(d public.tfl_envois, a public.tfl_acces) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object('id', d.id, 'de', d.de, 'dossier', d.dossier, 'genre', d.genre, 'titre', d.titre, 'note', d.note, 'nom', d.nom_fichier,
    'mime', d.mime, 'taille', d.taille, 'parties', d.parties, 'statut', d.statut, 'commentaire', d.commentaire, 'decide_par', d.decide_par,
    'cree_le', d.cree_le, 'maj_le', d.maj_le, 'mien', d.acces_id = a.id)
$$;
revoke all on function public.tfl_doc_json(public.tfl_envois, public.tfl_acces) from public, anon, authenticated;

-- 1) Déclaration du document (renvoie son identifiant) ; p_dossier vide = le dossier de l'étudiant.
create or replace function public.tfl_document_creer(p_role text, p_ident text, p_mdp text, p_dossier text, p_genre text, p_titre text, p_note text,
  p_nom text, p_mime text, p_taille bigint, p_parties int)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_titre text := left(btrim(coalesce(p_titre,'')), 150);
        v_nom text; v_id uuid; v_ext text;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if a.role = 'etudiant' then
    if v_d = '' then v_d := coalesce(a.contenu->>'numero',''); end if;
    if v_d = '' or v_d <> coalesce(a.contenu->>'numero','') or coalesce(a.contenu->>'statut','') <> 'accepte' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
    if p_genre not in ('plan','chapitre','version_finale','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  else
    if v_d = '' or not exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = v_d) then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
    if p_genre not in ('correction','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  end if;
  if length(v_titre) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  v_nom := left(regexp_replace(btrim(coalesce(p_nom,'')), '[\\/:*?"<>|[:cntrl:]]', '_', 'g'), 120);
  v_ext := lower(substring(v_nom from '\.([A-Za-z0-9]+)$'));
  if v_ext is null or v_ext not in ('pdf','doc','docx','odt','ppt','pptx','xls','xlsx','jpg','jpeg','png') then return jsonb_build_object('ok', false, 'code', 'format'); end if;
  if coalesce(p_taille,0) < 1 then return jsonb_build_object('ok', false, 'code', 'fichier_vide'); end if;
  if p_taille > 15000000 then return jsonb_build_object('ok', false, 'code', 'trop_lourd'); end if;
  if p_parties is distinct from ceil(p_taille / 900000.0)::int then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  delete from public.tfl_envois where acces_id = a.id and statut = 'envoi' and cree_le < now() - interval '2 hours';   -- envois abandonnés
  if (select count(*) from public.tfl_envois where acces_id = a.id and cree_le > now() - interval '1 hour') >= 20 then return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  if (select count(*) from public.tfl_envois where acces_id = a.id) >= 60 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  if coalesce((select sum(taille) from public.tfl_envois where acces_id = a.id), 0) + p_taille > 150000000 then return jsonb_build_object('ok', false, 'code', 'espace'); end if;
  insert into public.tfl_envois(acces_id, de, dossier, genre, titre, note, nom_fichier, mime, taille, parties)
  values (a.id, a.role, v_d, p_genre, v_titre, left(btrim(coalesce(p_note,'')), 1000), v_nom,
          case v_ext when 'pdf' then 'application/pdf' when 'png' then 'image/png' when 'jpg' then 'image/jpeg' when 'jpeg' then 'image/jpeg' else 'application/octet-stream' end,
          p_taille, p_parties) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;
revoke all on function public.tfl_document_creer(text,text,text,text,text,text,text,text,text,bigint,int) from public;
grant execute on function public.tfl_document_creer(text,text,text,text,text,text,text,text,text,bigint,int) to anon, authenticated;

-- 2) Envoi d'un morceau (0, 1, 2…) : 1 200 000 caractères base64 (900 Ko) sauf le dernier.
create or replace function public.tfl_document_partie(p_role text, p_ident text, p_mdp text, p_id uuid, p_idx int, p_b64 text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; d public.tfl_envois; v_ext text; v_h bytea;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into d from public.tfl_envois where id = p_id and acces_id = c.v_id and statut = 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  if coalesce(p_b64,'') !~ '^[A-Za-z0-9+/]+={0,2}$' or length(p_b64) % 4 <> 0 or length(p_b64) > 1200000 or (p_idx < d.parties - 1 and length(p_b64) <> 1200000) then
    return jsonb_build_object('ok', false, 'code', 'invalide');
  end if;
  if p_idx = 0 then   -- signature du fichier : l'extension annoncée doit correspondre au contenu
    v_ext := lower(substring(d.nom_fichier from '\.([A-Za-z0-9]+)$'));
    v_h := decode(left(p_b64, 16), 'base64');
    if not (case
        when v_ext = 'pdf' then substring(v_h from 1 for 4) = '\x25504446'
        when v_ext in ('docx','xlsx','pptx','odt') then substring(v_h from 1 for 2) = '\x504b'
        when v_ext in ('doc','xls','ppt') then substring(v_h from 1 for 4) = '\xd0cf11e0'
        when v_ext in ('jpg','jpeg') then substring(v_h from 1 for 3) = '\xffd8ff'
        when v_ext = 'png' then substring(v_h from 1 for 4) = '\x89504e47'
        else false end) then
      delete from public.tfl_envois where id = d.id;
      return jsonb_build_object('ok', false, 'code', 'contenu');
    end if;
  end if;
  insert into public.tfl_envois_parties(doc_id, idx, b64) values (d.id, p_idx, p_b64)
  on conflict (doc_id, idx) do update set b64 = excluded.b64;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_document_partie(text,text,text,uuid,int,text) from public;
grant execute on function public.tfl_document_partie(text,text,text,uuid,int,text) to anon, authenticated;

-- 3) Fin de l'envoi : tous les morceaux sont là et la taille correspond.
create or replace function public.tfl_document_terminer(p_role text, p_ident text, p_mdp text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; d public.tfl_envois; v_n int; v_oct bigint;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into d from public.tfl_envois where id = p_id and acces_id = c.v_id and statut = 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  select count(*), coalesce(sum(length(decode(b64, 'base64'))), 0) into v_n, v_oct from public.tfl_envois_parties where doc_id = d.id;
  if v_n <> d.parties or v_oct <> d.taille then return jsonb_build_object('ok', false, 'code', 'incomplet'); end if;
  update public.tfl_envois set statut = 'depose', maj_le = now() where id = d.id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_document_terminer(text,text,text,uuid) from public;
grant execute on function public.tfl_document_terminer(text,text,text,uuid) to anon, authenticated;

-- 4) Liste des documents visibles par l'accès (sans le contenu).
create or replace function public.tfl_document_liste(p_role text, p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  return jsonb_build_object('ok', true, 'documents', coalesce((select jsonb_agg(t.j order by t.cr desc)
    from (select public.tfl_doc_json(x, a) as j, x.cree_le as cr from public.tfl_envois x where public.tfl_doc_visible(a, x) order by x.cree_le desc limit 200) t), '[]'::jsonb));
end $$;
revoke all on function public.tfl_document_liste(text,text,text) from public;
grant execute on function public.tfl_document_liste(text,text,text) to anon, authenticated;

-- 5) Téléchargement d'un morceau (idx 0…parties-1).
create or replace function public.tfl_document_telecharger(p_role text, p_ident text, p_mdp text, p_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; d public.tfl_envois; v text;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  select * into d from public.tfl_envois where id = p_id;
  if not found or d.statut = 'envoi' or not public.tfl_doc_visible(a, d) then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  select b64 into v from public.tfl_envois_parties where doc_id = d.id and idx = p_idx;
  if v is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true, 'b64', v, 'parties', d.parties, 'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille);
end $$;
revoke all on function public.tfl_document_telecharger(text,text,text,uuid,int) from public;
grant execute on function public.tfl_document_telecharger(text,text,text,uuid,int) to anon, authenticated;

-- 6) Décision de l'encadreur sur un document de SON étudiant (jamais sur ses propres envois).
create or replace function public.tfl_document_decider(p_ident text, p_mdp text, p_id uuid, p_statut text, p_commentaire text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; d public.tfl_envois; v_c text := left(btrim(coalesce(p_commentaire,'')), 2000);
begin
  select * into c from public.tfl_acces_check('encadreur', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  if p_statut not in ('depose','a_corriger','valide') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  select * into d from public.tfl_envois where id = p_id;
  if not found or d.de <> 'etudiant' or d.statut = 'envoi' or not public.tfl_doc_visible(a, d) then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_statut = 'a_corriger' and length(v_c) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  update public.tfl_envois set statut = p_statut, commentaire = v_c, decide_par = 'encadreur', maj_le = now() where id = d.id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_document_decider(text,text,uuid,text,text) from public;
grant execute on function public.tfl_document_decider(text,text,uuid,text,text) to anon, authenticated;

-- 7) Suppression par son auteur (impossible une fois le document validé).
create or replace function public.tfl_document_supprimer(p_role text, p_ident text, p_mdp text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; n int;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  delete from public.tfl_envois where id = p_id and acces_id = c.v_id and statut <> 'valide';
  get diagnostics n = row_count;
  if n = 0 then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_document_supprimer(text,text,text,uuid) from public;
grant execute on function public.tfl_document_supprimer(text,text,text,uuid) to anon, authenticated;

-- ---------- Administration (e-mail administrateur connecté) ----------
create or replace function public.tfl_documents_admin_liste(p_dossier text default null)
returns jsonb language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'de', d.de, 'auteur', a.nom, 'dossier', d.dossier, 'genre', d.genre, 'titre', d.titre, 'note', d.note,
      'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille, 'parties', d.parties, 'statut', d.statut, 'commentaire', d.commentaire, 'decide_par', d.decide_par,
      'cree_le', d.cree_le, 'maj_le', d.maj_le) order by d.cree_le desc)
    from (select * from public.tfl_envois x where x.statut <> 'envoi' and (p_dossier is null or x.dossier = p_dossier) order by x.cree_le desc limit 500) d
    join public.tfl_acces a on a.id = d.acces_id), '[]'::jsonb);
end $$;
revoke all on function public.tfl_documents_admin_liste(text) from public, anon;
grant execute on function public.tfl_documents_admin_liste(text) to authenticated;

create or replace function public.tfl_document_admin_telecharger(p_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare d public.tfl_envois; v text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  select * into d from public.tfl_envois where id = p_id and statut <> 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  select b64 into v from public.tfl_envois_parties where doc_id = d.id and idx = p_idx;
  if v is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true, 'b64', v, 'parties', d.parties, 'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille);
end $$;
revoke all on function public.tfl_document_admin_telecharger(uuid,int) from public, anon;
grant execute on function public.tfl_document_admin_telecharger(uuid,int) to authenticated;

create or replace function public.tfl_document_admin_decider(p_id uuid, p_statut text, p_commentaire text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_c text := left(btrim(coalesce(p_commentaire,'')), 2000);
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('depose','a_corriger','valide') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_statut = 'a_corriger' and length(v_c) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  update public.tfl_envois set statut = p_statut, commentaire = v_c, decide_par = 'administration', maj_le = now() where id = p_id and statut <> 'envoi';
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_document_admin_decider(uuid,text,text) from public, anon;
grant execute on function public.tfl_document_admin_decider(uuid,text,text) to authenticated;

create or replace function public.tfl_document_admin_supprimer(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  delete from public.tfl_envois where id = p_id;
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_document_admin_supprimer(uuid) from public, anon;
grant execute on function public.tfl_document_admin_supprimer(uuid) to authenticated;

-- Contrôle : select proname from pg_proc where proname like 'tfl_document%';  → 11 lignes
--   (tfl_document_creer, _partie, _terminer, _liste, _telecharger, _decider, _supprimer, _admin_telecharger, _admin_decider, _admin_supprimer, tfl_documents_admin_liste)
-- Et : select tablename, rowsecurity from pg_tables where tablename like 'tfl_envois%';  → rowsecurity = true pour les deux
