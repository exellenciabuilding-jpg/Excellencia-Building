-- ===== Excellencia Building — V99zp : double authentification (2FA / TOTP) imposée par le serveur =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v99zn et v99zo. Réexécutable sans danger.
-- Prérequis dans Supabase : Authentication › Sign In / Providers › « Multi-Factor » : TOTP activé (par défaut : oui).
--
-- RÈGLE : si un compte a activé la 2FA (facteur TOTP vérifié), toute lecture/écriture des données de l'entreprise exige
-- une session « aal2 » (mot de passe + code à 6 chiffres). Un mot de passe volé seul ne suffit plus.
-- Les comptes SANS 2FA fonctionnent exactement comme avant : rien ne casse tant qu'on ne l'active pas.

create or replace function mfa_ok()
returns boolean language sql stable security definer set search_path=public,auth as $$
  select case
    when exists(select 1 from auth.mfa_factors f where f.user_id=auth.uid() and f.status='verified')
      then coalesce(auth.jwt()->>'aal','aal1')='aal2'
    else true end $$;
revoke execute on function mfa_ok() from public, anon;
grant execute on function mfa_ok() to authenticated, service_role;

-- peut() : identique à V99zn, avec la condition 2FA en plus.
create or replace function peut(p_org uuid, p_col text, p_ecrire boolean default false)
returns boolean language sql stable security definer set search_path=public as $$
  select mfa_ok() and exists(
    select 1 from membres m
    where m.org_id=p_org and m.user_id=auth.uid() and (
      m.role='admin'
      or ((not p_ecrire or m.role='editeur') and (
            (m.fonction='polyvalent' and not exists(select 1 from collections_sensibles s where s.collection=p_col))
            or exists(select 1 from droits_fonction d
                      where d.fonction=m.fonction and d.collection=p_col
                        and (case when p_ecrire then d.ecrire else d.lire end))
      ))
    )) $$;
grant execute on function peut(uuid,text,boolean) to authenticated;

-- Vérification (à la main) : sans 2FA → true ; avec 2FA activée et session sans code → false.
--   select mfa_ok();
