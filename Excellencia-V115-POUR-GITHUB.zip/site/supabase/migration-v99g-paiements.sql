-- Excellencia Building V99g — Tableau des paiements Mobile Money déclarés par les visiteurs.
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger.
-- Remplacez les e-mails administrateur si besoin (3 endroits, en minuscules).

create table if not exists public.paiements_declares (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  type text not null check (type in ('apprenant','logiciel','projet')),
  nom text, telephone text, matricule text,
  montant numeric(12,2) not null check (montant > 0),
  devise text not null default 'USD',
  reseau text, numero_payeur text,
  reference text not null,
  statut text not null default 'a_verifier' check (statut in ('a_verifier','confirme','rejete')),
  doublon boolean not null default false,
  note_admin text, verifie_le timestamptz
);
create index if not exists paiements_declares_ref_idx on public.paiements_declares (lower(reference));
alter table public.paiements_declares enable row level security;

drop policy if exists paiements_lire on public.paiements_declares;
create policy paiements_lire on public.paiements_declares for select to authenticated
  using (lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']));

drop policy if exists paiements_modifier on public.paiements_declares;
create policy paiements_modifier on public.paiements_declares for update to authenticated
  using (lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']))
  with check (lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']));

-- Les visiteurs n'écrivent QUE par cette fonction (validée, limitée à 5 déclarations/heure par numéro).
create or replace function public.paiement_declarer(p_data jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_type text := p_data->>'type';
  v_ref  text := left(btrim(coalesce(p_data->>'reference','')), 40);
  v_tel  text := left(regexp_replace(coalesce(p_data->>'numero',''), '[^0-9+]', '', 'g'), 20);
  v_mont numeric; v_dbl boolean; v_id bigint;
begin
  if v_type is null or v_type not in ('apprenant','logiciel','projet') then raise exception 'type_invalide'; end if;
  begin v_mont := (p_data->>'montant')::numeric; exception when others then raise exception 'montant_invalide'; end;
  if v_mont is null or v_mont <= 0 or v_mont > 100000 then raise exception 'montant_invalide'; end if;
  if length(v_ref) < 3 then raise exception 'reference_invalide'; end if;
  if length(regexp_replace(v_tel, '[^0-9]', '', 'g')) < 8 then raise exception 'telephone_invalide'; end if;
  if (select count(*) from public.paiements_declares where numero_payeur = v_tel and created_at > now() - interval '1 hour') >= 5
    then raise exception 'trop_de_demandes'; end if;
  select exists(select 1 from public.paiements_declares where lower(reference) = lower(v_ref)) into v_dbl;
  insert into public.paiements_declares(type, nom, telephone, matricule, montant, devise, reseau, numero_payeur, reference, doublon)
  values (v_type, left(p_data->>'nom',120), left(p_data->>'telephone',30), left(p_data->>'matricule',40), v_mont,
          case when p_data->>'devise' in ('USD','CDF') then p_data->>'devise' else 'USD' end,
          left(p_data->>'reseau',30), v_tel, v_ref, v_dbl)
  returning id into v_id;
  return jsonb_build_object('id', v_id, 'doublon', v_dbl);
end $$;
revoke all on function public.paiement_declarer(jsonb) from public;
grant execute on function public.paiement_declarer(jsonb) to anon, authenticated;
