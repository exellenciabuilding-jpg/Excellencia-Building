-- ===== Excellencia Building V99zzzzzz — TFL : contributions d'anciens (sujet + travail déjà résolu) =====
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger. Court (< 8 Ko) : se colle d'un coup, même sur téléphone.
-- PRINCIPE : comme tfl_candidatures. L'ancien étudiant (sans compte) dépose son TFL résolu par la page tfl-contribution.html ;
--   personne ne lit la table directement ; seul l'administrateur connecté lit la liste, télécharge le fichier à la demande
--   (la LISTE ne contient jamais les fichiers : elle reste légère) et marque « traitée » après l'ajout à la bibliothèque.
-- Remplacez les e-mails administrateur si besoin (minuscules) : mêmes que migration-v99zzr-tfl-en-ligne.sql.

create table if not exists public.tfl_contributions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  submitted_at timestamptz,
  data jsonb not null,
  fichier_nom text,
  fichier_taille integer,
  fichier text,
  imported boolean not null default false,
  imported_at timestamptz
);
create index if not exists tfl_contributions_created_idx on public.tfl_contributions (created_at desc);
alter table public.tfl_contributions enable row level security;
revoke all on public.tfl_contributions from anon, authenticated;

create or replace function public.tfl_contribution_envoyer(p_data jsonb, p_fichier_nom text default null, p_fichier text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_titre text := left(btrim(coalesce(p_data->>'titre','')), 250);
  v_fn text := left(btrim(coalesce(p_fichier_nom,'')), 200);
  v_clean jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if length(v_titre) < 3 then raise exception 'titre_invalide'; end if;
  if p_fichier is not null and p_fichier <> '' then
    if length(p_fichier) > 4300000 then raise exception 'fichier_trop_lourd'; end if;
    if p_fichier !~ '^[A-Za-z0-9+/=]+$' then raise exception 'fichier_invalide'; end if;
    if v_fn !~* '\.(pdf|doc|docx|odt|rtf|txt|ppt|pptx|zip|jpg|jpeg|png)$' then raise exception 'format_refuse'; end if;
  end if;
  -- Renvoi d'une fiche déjà enregistrée (même instant d'envoi + même téléphone) : réponse OK sans doublon, avant les limites.
  if p_submitted is not null and exists (select 1 from public.tfl_contributions where submitted_at = p_submitted and data->>'telephone' = v_tel) then
    return jsonb_build_object('ok', true, 'dup', true);
  end if;
  if (select count(*) from public.tfl_contributions where created_at > now() - interval '1 hour') >= 100 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_contributions where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 3 then raise exception 'trop_de_demandes'; end if;
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'annee', left(coalesce(p_data->>'annee',''), 4),
    'domaine', case when p_data->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then p_data->>'domaine' else 'autre' end,
    'encadreur', left(coalesce(p_data->>'encadreur',''), 120),
    'titre', v_titre,
    'mots_cles', left(coalesce(p_data->>'mots_cles',''), 200),
    'resume', left(coalesce(p_data->>'resume',''), 2000),
    'consultation', case when p_data->>'consultation' = 'oui' then 'oui' else 'non' end);
  insert into public.tfl_contributions(submitted_at, data, fichier_nom, fichier_taille, fichier)
  values (p_submitted, v_clean, nullif(v_fn,''), case when p_fichier is null or p_fichier = '' then null else (length(p_fichier) * 3 / 4) end, nullif(p_fichier,''));
  return jsonb_build_object('ok', true);
end $$;
grant execute on function public.tfl_contribution_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;

create or replace function public.tfl_contributions_liste()
returns table(id uuid, created_at timestamptz, data jsonb, fichier_nom text, fichier_taille integer, imported boolean)
language plpgsql security definer set search_path = public stable as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then raise exception 'non autorisé'; end if;
  return query select c.id, c.created_at, c.data, c.fichier_nom, c.fichier_taille, c.imported
    from public.tfl_contributions c where not c.imported order by c.created_at desc limit 300;
end $$;
revoke all on function public.tfl_contributions_liste() from public, anon;
grant execute on function public.tfl_contributions_liste() to authenticated;

create or replace function public.tfl_contribution_fichier(p_id uuid)
returns text language plpgsql security definer set search_path = public stable as $$
declare v text;
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then raise exception 'non autorisé'; end if;
  select fichier into v from public.tfl_contributions where id = p_id;
  return v;
end $$;
revoke all on function public.tfl_contribution_fichier(uuid) from public, anon;
grant execute on function public.tfl_contribution_fichier(uuid) to authenticated;

create or replace function public.tfl_contribution_traiter(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then raise exception 'non autorisé'; end if;
  update public.tfl_contributions set imported = true, imported_at = now(), fichier = null where id = p_id;
end $$;
revoke all on function public.tfl_contribution_traiter(uuid) from public, anon;
grant execute on function public.tfl_contribution_traiter(uuid) to authenticated;

-- Contrôle (doit renvoyer 4 lignes) :
-- select proname from pg_proc where proname in ('tfl_contribution_envoyer','tfl_contributions_liste','tfl_contribution_fichier','tfl_contribution_traiter');
