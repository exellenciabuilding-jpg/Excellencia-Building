-- ===== Excellencia Building — V99v : données sensibles + espace propriétaire (clients et licences) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : schema-entreprise.sql, migration-v66-roles.sql et migration-v92-erp.sql déjà exécutés.
-- FAITES D'ABORD UNE SAUVEGARDE (Supabase › Database › Backups, ou export) avant d'exécuter ce script.
--
-- PARTIE A — Données sensibles (employés, contrats, paies, banque)
--   Avant : tout membre de l'entreprise (même « lecteur ») pouvait les lire.
--   Après : seuls l'administrateur et les FONCTIONS concernées y accèdent (colonne membres.fonction) :
--       employés et contrats : rh, direction (lecture aussi : comptable)  | écriture : rh, direction
--       paies                : rh, comptable, direction                   | écriture : rh, comptable
--       banque               : comptable, direction                       | écriture : comptable
--   Un membre « polyvalent » n'y a plus accès : donnez-lui la bonne fonction si nécessaire
--   (update membres set fonction='comptable' where user_id='…' and org_id='…';).
--
-- PARTIE B — Espace propriétaire : créer les entreprises clientes, suivre licences et essais.
--   Premier propriétaire (à faire une fois, avec VOTRE e-mail de compte en ligne) :
--     insert into plateforme_proprietaires(user_id) select id from auth.users where email='votre@email.com';

-- ---------- A. Droits par fonction ----------
create or replace function est_membre_fonction(o uuid, roles text[], fonctions text[])
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from membres where org_id=o and user_id=auth.uid()
    and (role='admin' or (role=any(roles) and fonction=any(fonctions)))) $$;

do $$ declare r record; begin
  for r in select * from (values
    ('erp_employes',              array['rh','direction','comptable'], array['rh','direction']),
    ('erp_contrats_rh',           array['rh','direction','comptable'], array['rh','direction']),
    ('erp_paies',                 array['rh','comptable','direction'], array['rh','comptable']),
    ('erp_comptes_bancaires',     array['comptable','direction'],      array['comptable']),
    ('erp_transactions_bancaires',array['comptable','direction'],      array['comptable'])
  ) as v(t,lire,ecrire) loop
    if to_regclass('public.'||r.t) is null then continue; end if;
    execute format('alter table %I enable row level security', r.t);
    execute format('drop policy if exists %I_lire on %I', r.t, r.t);
    execute format('create policy %I_lire on %I for select using (est_membre_fonction(org_id, array[''admin'',''editeur'',''lecteur''], %L::text[]))', r.t, r.t, r.lire);
    execute format('drop policy if exists %I_ecrire on %I', r.t, r.t);
    execute format('create policy %I_ecrire on %I for insert with check (est_membre_fonction(org_id, array[''editeur''], %L::text[]))', r.t, r.t, r.ecrire);
    execute format('drop policy if exists %I_modif on %I', r.t, r.t);
    execute format('create policy %I_modif on %I for update using (est_membre_fonction(org_id, array[''editeur''], %L::text[])) with check (est_membre_fonction(org_id, array[''editeur''], %L::text[]))', r.t, r.t, r.ecrire, r.ecrire);
  end loop;
end $$;

-- ---------- B. Espace propriétaire ----------
create table if not exists plateforme_proprietaires(
  user_id uuid primary key references auth.users(id) on delete cascade,
  cree_le timestamptz not null default now());
alter table plateforme_proprietaires enable row level security;
-- aucune politique : personne n'y accède directement (seulement via les fonctions ci-dessous / SQL Editor)

create or replace function est_proprietaire() returns boolean
language sql stable security definer set search_path=public as $$
  select exists(select 1 from plateforme_proprietaires where user_id=auth.uid()) $$;

create table if not exists licences_clients(
  id uuid primary key default gen_random_uuid(),
  org_id uuid references organisations(id) on delete set null,
  client_nom text not null,
  contact text,
  plan text not null default 'essai' check (plan in ('essai','standard','pro')),
  statut text not null default 'essai' check (statut in ('essai','actif','suspendu','resilie')),
  max_utilisateurs int not null default 5 check (max_utilisateurs between 1 and 1000),
  essai_fin timestamptz,
  expire_le timestamptz,
  notes text,
  dernier_jeton text,
  cree_le timestamptz not null default now(),
  maj timestamptz not null default now());
create index if not exists licences_clients_org_idx on licences_clients(org_id);
alter table licences_clients enable row level security;
drop policy if exists lic_proprietaire on licences_clients;
create policy lic_proprietaire on licences_clients for all using (est_proprietaire()) with check (est_proprietaire());

-- Créer une entreprise cliente (en essai). Le premier compte qui saisit le code d'invitation en devient l'administrateur.
create or replace function owner_creer_client(p_nom text, p_contact text default null, p_jours_essai int default 14, p_max int default 5)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations; l licences_clients; fin timestamptz;
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  if coalesce(trim(p_nom),'')='' then raise exception 'nom du client requis'; end if;
  fin := now() + make_interval(days => greatest(1, least(coalesce(p_jours_essai,14), 90)));
  insert into organisations(nom, cree_par) values (trim(p_nom), auth.uid()) returning * into o;
  insert into licences_clients(org_id, client_nom, contact, plan, statut, max_utilisateurs, essai_fin, expire_le)
    values (o.id, trim(p_nom), p_contact, 'essai', 'essai', greatest(1, least(coalesce(p_max,5),1000)), fin, fin) returning * into l;
  return json_build_object('licence_id', l.id, 'org_id', o.id, 'code', o.code_invitation, 'essai_fin', fin);
end $$;

-- Liste pour le tableau de suivi.
create or replace function owner_liste() returns table(
  id uuid, org_id uuid, client_nom text, contact text, plan text, statut text, max_utilisateurs int,
  essai_fin timestamptz, expire_le timestamptz, notes text, code_invitation text,
  nb_membres bigint, derniere_activite timestamptz, cree_le timestamptz)
language plpgsql stable security definer set search_path=public as $$
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  return query
    select l.id, l.org_id, l.client_nom, l.contact, l.plan, l.statut, l.max_utilisateurs, l.essai_fin, l.expire_le, l.notes,
           o.code_invitation,
           (select count(*) from membres m where m.org_id=l.org_id),
           (select max(e.maj) from enregistrements e where e.org_id=l.org_id),
           l.cree_le
    from licences_clients l left join organisations o on o.id=l.org_id
    order by l.cree_le desc;
end $$;

-- Mettre à jour une licence : statut, échéance, nombre d'utilisateurs, notes, dernier code émis.
create or replace function owner_maj_licence(p_id uuid, p_statut text default null, p_plan text default null,
  p_expire timestamptz default null, p_max int default null, p_notes text default null, p_jeton text default null)
returns json language plpgsql security definer set search_path=public as $$
declare l licences_clients;
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  update licences_clients set
    statut = coalesce(p_statut, statut), plan = coalesce(p_plan, plan), expire_le = coalesce(p_expire, expire_le),
    max_utilisateurs = coalesce(p_max, max_utilisateurs), notes = coalesce(p_notes, notes),
    dernier_jeton = coalesce(p_jeton, dernier_jeton), maj = now()
  where id = p_id returning * into l;
  if not found then raise exception 'licence introuvable'; end if;
  return row_to_json(l);
end $$;

-- Suspension et limite d'utilisateurs appliquées quand quelqu'un REJOINT l'entreprise.
-- Le premier membre d'une entreprise créée par le propriétaire devient administrateur.
create or replace function rejoindre_organisation(p_code text, p_nom_user text default null)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations; r text; f text; n int; l licences_clients; a_lic boolean;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  select * into o from organisations where code_invitation=lower(trim(p_code));
  if not found then raise exception 'code invalide'; end if;
  select * into l from licences_clients where org_id=o.id order by cree_le desc limit 1;
  a_lic := found;
  if a_lic then
    if l.statut in ('suspendu','resilie') then raise exception 'licence suspendue : contactez l''administrateur du logiciel'; end if;
    if l.expire_le is not null and l.expire_le < now() - interval '7 days' then raise exception 'licence expirée : contactez l''administrateur du logiciel'; end if;
  end if;
  select count(*) into n from membres where org_id=o.id;
  if a_lic and n >= l.max_utilisateurs and not exists(select 1 from membres where org_id=o.id and user_id=auth.uid()) then
    raise exception 'nombre maximal d''utilisateurs atteint (%)', l.max_utilisateurs; end if;
  insert into membres(org_id,user_id,nom,role) values (o.id,auth.uid(),p_nom_user, case when n=0 then 'admin' else 'editeur' end) on conflict do nothing;
  select role,fonction into r,f from membres where org_id=o.id and user_id=auth.uid();
  return json_build_object('id',o.id,'nom',o.nom,'role',r,'fonction',f);
end $$;

revoke execute on function est_proprietaire(), owner_creer_client(text,text,int,int), owner_liste(),
  owner_maj_licence(uuid,text,text,timestamptz,int,text,text) from public, anon;
grant execute on function est_proprietaire(), owner_creer_client(text,text,int,int), owner_liste(),
  owner_maj_licence(uuid,text,text,timestamptz,int,text,text) to authenticated;
