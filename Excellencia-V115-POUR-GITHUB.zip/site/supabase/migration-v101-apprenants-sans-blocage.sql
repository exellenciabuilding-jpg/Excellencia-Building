-- Excellencia Building V101 — Espace apprenant : SUPPRESSION du blocage après essais de mot de passe.
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Reprend à l'identique apprenant_connexion et apprenant_changer_mdp, SANS : comptage des essais, blocage de 15 minutes,
-- ni comptage des essais du code de vérification. Les codes de retour restent les mêmes (invalides, code, faible) ;
-- « bloque » n'est plus jamais renvoyé. FAITES D'ABORD UNE SAUVEGARDE.

create or replace function public.apprenant_connexion(p_matricule text, p_mdp text)
 returns jsonb
 language plpgsql
 security definer
 set search_path to 'public', 'extensions'
as $function$
declare a public.apprenants_acces; m text := public._exb_n(p_matricule); res jsonb;
begin
  select * into a from public.apprenants_acces where matricule = m;
  if not found then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  if a.mdp_hash <> crypt(coalesce(p_mdp,''), a.mdp_hash) then
    return jsonb_build_object('ok', false, 'code', 'invalides');
  end if;
  if a.doit_changer then
    return jsonb_build_object('ok', true, 'doit_changer', true, 'nom', a.nom);
  end if;
  select coalesce(jsonb_agg(jsonb_build_object('session', session, 'publie_le', publie_le, 'donnees', donnees)
                            order by publie_le desc), '[]'::jsonb)
    into res from public.resultats_publies where matricule = m;
  return jsonb_build_object('ok', true, 'doit_changer', false, 'nom', a.nom,
                            'formation', a.formation, 'resultats', res);
end $function$;

create or replace function public.apprenant_changer_mdp(p_matricule text, p_ancien text, p_nouveau text, p_code text default null::text)
 returns jsonb
 language plpgsql
 security definer
 set search_path to 'public', 'extensions'
as $function$
declare r jsonb; a public.apprenants_acces; m text := public._exb_n(p_matricule);
        c text := right(regexp_replace(coalesce(p_code,''), '\D', '', 'g'), 4);
begin
  r := public.apprenant_connexion(p_matricule, p_ancien);
  if not coalesce((r->>'ok')::boolean, false) then return r; end if;
  select * into a from public.apprenants_acces where matricule = m;
  if a.code_hash is not null and (length(c) < 4 or a.code_hash <> crypt(c, a.code_hash)) then
    return jsonb_build_object('ok', false, 'code', 'code');
  end if;
  if length(coalesce(p_nouveau,'')) < 6 or p_nouveau = '123456789' then
    return jsonb_build_object('ok', false, 'code', 'faible');
  end if;
  update public.apprenants_acces
     set mdp_hash = crypt(p_nouveau, gen_salt('bf')), doit_changer = false, essais_code = 0
   where matricule = m;
  return jsonb_build_object('ok', true);
end $function$;

-- Débloque tout de suite les apprenants actuellement bloqués.
update public.apprenants_acces set essais = 0, essais_code = 0, bloque_jusqua = null;

-- Contrôle (résultat attendu : 0 ligne = plus aucune trace de blocage dans les deux fonctions) :
-- select proname from pg_proc where proname in ('apprenant_connexion','apprenant_changer_mdp') and prosrc ilike '%bloque_jusqua%';
