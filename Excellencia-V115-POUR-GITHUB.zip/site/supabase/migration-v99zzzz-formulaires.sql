-- ===== Excellencia Building V99zzzz — Formulaires en ligne : TP/TD, formateur, client, personnel =====
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Corrige le message : « Les formulaires TP/TD, formateur, client et personnel ne sont pas encore activés sur le serveur ».
-- PRINCIPE (comme les inscriptions d'apprenants) :
--   · La personne (sans compte) remplit son formulaire -> fonction formulaire_envoyer (anonyme, limitée en volume).
--   · Personne ne lit la table sans être connecté. L'administrateur (e-mails ci-dessous) voit tout ce qui n'a pas de centre ;
--     un centre connecté ne voit que SES demandes (centre_id = son identifiant utilisateur).
--   · L'application importe ensuite chaque demande dans le bon module (Clients, RH, Formateurs, TP/TD) : la personne y apparaît
--     alors dans toutes les listes de choix (décomptes, paiements, reçus, certificats, dossiers).
-- Les e-mails administrateur sont les mêmes que dans migration-v99m-verification.sql (en minuscules).

create table if not exists public.formulaires (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  kind text not null check (kind in ('tp_td','formateur','client','personnel')),
  data jsonb not null default '{}'::jsonb,
  photo text,
  imported boolean not null default false,
  imported_at timestamptz,
  centre_id uuid
);
-- si la table existait déjà sans certaines colonnes
alter table public.formulaires add column if not exists photo text;
alter table public.formulaires add column if not exists imported boolean not null default false;
alter table public.formulaires add column if not exists imported_at timestamptz;
alter table public.formulaires add column if not exists centre_id uuid;
create index if not exists formulaires_created_idx on public.formulaires (created_at desc);
create index if not exists formulaires_kind_idx on public.formulaires (kind, created_at desc);
create index if not exists formulaires_centre_idx on public.formulaires (centre_id);

alter table public.formulaires enable row level security;
revoke all on public.formulaires from anon;
grant select, update, delete on public.formulaires to authenticated;

-- ---------- Droits de lecture / traitement (administrateur ou centre propriétaire) ----------
drop policy if exists formulaires_lecture on public.formulaires;
create policy formulaires_lecture on public.formulaires for select to authenticated using (
  (centre_id is null and lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']))
  or centre_id = auth.uid()
);
drop policy if exists formulaires_maj on public.formulaires;
create policy formulaires_maj on public.formulaires for update to authenticated using (
  (centre_id is null and lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']))
  or centre_id = auth.uid()
) with check (
  (centre_id is null and lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']))
  or centre_id = auth.uid()
);
drop policy if exists formulaires_suppr on public.formulaires;
create policy formulaires_suppr on public.formulaires for delete to authenticated using (
  (centre_id is null and lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']))
  or centre_id = auth.uid()
);

-- ---------- Envoi anonyme (fonction commune, centre facultatif) ----------
create or replace function public._formulaire_inserer(p_kind text, p_data jsonb, p_photo text, p_centre uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text; v_tel text; v_clean jsonb := '{}'::jsonb; v_k text; v_v jsonb; v_n int := 0; v_id uuid;
begin
  if p_kind is null or p_kind not in ('tp_td','formateur','client','personnel') then raise exception 'type_invalide'; end if;
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  -- nom selon le type (le client utilise full_name ; le TP/TD s'identifie par son matricule)
  v_nom := left(btrim(coalesce(case p_kind when 'client' then p_data->>'full_name' when 'tp_td' then coalesce(p_data->>'matricule', p_data->>'name') else p_data->>'name' end, '')), 160);
  v_tel := left(btrim(coalesce(p_data->>'phone','')), 40);
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if p_kind <> 'tp_td' and v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if p_centre is not null and not exists (select 1 from auth.users u where u.id = p_centre) then raise exception 'centre_invalide'; end if;
  -- anti-spam : 300 envois / heure au total, 8 par téléphone et par heure
  if (select count(*) from public.formulaires where created_at > now() - interval '1 hour') >= 300 then raise exception 'trop_de_demandes'; end if;
  if v_tel <> '' and (select count(*) from public.formulaires where data->>'phone' = v_tel and created_at > now() - interval '1 hour') >= 8 then raise exception 'trop_de_demandes'; end if;
  -- on garde au plus 40 champs, chacun tronqué à 3000 caractères (chaînes, nombres, booléens, listes de textes)
  for v_k, v_v in select key, value from jsonb_each(p_data) loop
    v_n := v_n + 1; exit when v_n > 40;
    if jsonb_typeof(v_v) = 'string' then v_clean := v_clean || jsonb_build_object(left(v_k, 60), left(v_v #>> '{}', 3000));
    elsif jsonb_typeof(v_v) in ('number','boolean') then v_clean := v_clean || jsonb_build_object(left(v_k, 60), v_v);
    elsif jsonb_typeof(v_v) = 'array' and length(v_v::text) <= 3000 then v_clean := v_clean || jsonb_build_object(left(v_k, 60), v_v);
    end if;
  end loop;
  if length(v_clean::text) > 20000 then raise exception 'donnees_trop_longues'; end if;
  insert into public.formulaires(kind, data, photo, centre_id)
  values (p_kind, v_clean, nullif(p_photo,''), p_centre) returning id into v_id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public._formulaire_inserer(text, jsonb, text, uuid) from public, anon, authenticated;

create or replace function public.formulaire_envoyer(p_kind text, p_data jsonb, p_photo text default null)
returns jsonb language sql security definer set search_path = public as $$
  select public._formulaire_inserer(p_kind, p_data, p_photo, null)
$$;
grant execute on function public.formulaire_envoyer(text, jsonb, text) to anon, authenticated;

create or replace function public.formulaire_envoyer_centre(p_kind text, p_data jsonb, p_photo text default null, p_centre uuid default null)
returns jsonb language sql security definer set search_path = public as $$
  select public._formulaire_inserer(p_kind, p_data, p_photo, p_centre)
$$;
grant execute on function public.formulaire_envoyer_centre(text, jsonb, text, uuid) to anon, authenticated;

-- recharge le cache de l'API pour que les nouvelles fonctions soient visibles tout de suite
notify pgrst, 'reload schema';
