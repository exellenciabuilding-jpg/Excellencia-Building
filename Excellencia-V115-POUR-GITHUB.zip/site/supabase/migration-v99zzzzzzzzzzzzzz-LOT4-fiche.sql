-- LOT 4/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
create or replace function public.tfl_fiche_etudiant_envoyer(p_ref text, p_data jsonb, p_photo text default null, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ref text := btrim(coalesce(p_ref,''));
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_old public.tfl_candidatures%rowtype;
  v_new jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 2000 then raise exception 'trop_de_demandes'; end if;
  select * into v_old from public.tfl_candidatures
   where data->>'sujet_ref' = v_ref and data->>'telephone' = v_tel
   order by created_at desc limit 1;
  if not found then raise exception 'choix_introuvable'; end if;
  -- jeton : exigé dès que le choix en a un (les choix antérieurs à cette migration n'en ont pas et restent acceptés)
  if v_old.fiche_token_hash is not null then
    if coalesce(p_token,'') = '' then raise exception 'jeton_requis'; end if;
    if encode(sha256(convert_to(left(p_token, 200), 'UTF8')), 'hex') is distinct from v_old.fiche_token_hash then raise exception 'jeton_invalide'; end if;
  end if;
  v_new := v_old.data || jsonb_build_object(
    'nom', v_nom,
    'email', left(coalesce(p_data->>'email', v_old.data->>'email',''), 120),
    'universite', left(coalesce(nullif(p_data->>'universite',''), v_old.data->>'universite',''), 150),
    'promotion', left(coalesce(nullif(p_data->>'promotion',''), v_old.data->>'promotion',''), 60),
    'filiere', left(coalesce(nullif(p_data->>'filiere',''), v_old.data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(nullif(p_data->>'matricule_existant',''), v_old.data->>'matricule_existant',''), 40),
    'annee_academique', left(coalesce(p_data->>'annee_academique',''), 20),
    'faculte', left(coalesce(p_data->>'faculte',''), 100),
    'niveau', left(coalesce(p_data->>'niveau',''), 20),
    'date_naissance', left(coalesce(p_data->>'date_naissance',''), 20),
    'lieu_naissance', left(coalesce(p_data->>'lieu_naissance',''), 100),
    'nationalite', left(coalesce(p_data->>'nationalite',''), 60),
    'adresse', left(coalesce(p_data->>'adresse',''), 150),
    'matricule_univ', left(coalesce(p_data->>'matricule_univ',''), 40),
    'remarques', left(coalesce(p_data->>'remarques',''), 1000),
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 then
      (case when p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else coalesce(v_old.data->>'signature','') end) else coalesce(v_old.data->>'signature','') end,
    'recherches_deja', left(coalesce(nullif(p_data->>'recherches_deja',''), v_old.data->>'recherches_deja',''), 3000));
  if not v_old.imported then
    update public.tfl_candidatures set data = v_new, photo = coalesce(nullif(p_photo,''), photo) where id = v_old.id;
  else
    insert into public.tfl_candidatures(submitted_at, ref, data, photo, fiche_token_hash)
    values (now(), v_old.ref, v_new, coalesce(nullif(p_photo,''), v_old.photo), v_old.fiche_token_hash);
  end if;
  return jsonb_build_object('ok', true, 'matricule', (select s.matricule from public.tfl_statuts s where s.role = 'etudiant' and right(s.tel_norm, 6) = right(regexp_replace(coalesce(v_new->>'telephone',''), '\D', '', 'g'), 6) limit 1));
end $$;
revoke all on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) from public;
grant execute on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) to anon, authenticated;
