-- ===== Excellencia Building V99zzy — Corrections de l'audit : fiche étudiante (jeton), registre QR (non confirmé), réservations =====
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zzx-tfl-fiche-etudiant.sql. Réexécutable. Rien n'est supprimé.
-- 1) Fiche étudiante : un jeton secret, remis seulement à l'étudiant qui choisit le sujet, est exigé pour envoyer sa fiche.
-- 2) Registre QR : les fiches déposées par le public sont « non confirmées » tant que l'administrateur ne les confirme pas ;
--    elles ne peuvent plus déclasser un document officiel en « ancienne version ».
-- 3) Réservations : 2 sujets réservés au plus par numéro, expiration après 14 jours si la fiche n'est pas complétée,
--    limite par adresse IP (au mieux : l'adresse vient de l'en-tête de la requête).

-- ---------- Limite par adresse IP (générique, réutilisable) ----------
create table if not exists public.exb_limites_ip (
  scope text not null,
  ip_hash text not null,
  at timestamptz not null default now()
);
create index if not exists exb_limites_ip_idx on public.exb_limites_ip (scope, ip_hash, at);
alter table public.exb_limites_ip enable row level security;
revoke all on public.exb_limites_ip from anon, authenticated;

create or replace function public.exb_ip_limite(p_scope text, p_max int)
returns void language plpgsql security definer set search_path = public as $$
declare v_h jsonb; v_ip text := ''; v_hash text;
begin
  begin v_h := nullif(current_setting('request.headers', true), '')::jsonb; exception when others then v_h := null; end;
  if v_h is null then return; end if;  -- pas d'en-têtes (appel interne, test) : pas de limite par IP
  v_ip := btrim(coalesce(nullif(v_h->>'cf-connecting-ip',''), nullif(v_h->>'x-real-ip',''),
                         nullif(btrim(regexp_replace(coalesce(v_h->>'x-forwarded-for',''), '^.*,', '')),''), ''));
  if v_ip = '' then return; end if;
  v_hash := encode(sha256(convert_to(v_ip, 'UTF8')), 'hex');
  delete from public.exb_limites_ip where at < now() - interval '3 hours';
  if (select count(*) from public.exb_limites_ip where scope = p_scope and ip_hash = v_hash and at > now() - interval '1 hour') >= p_max then
    raise exception 'trop_de_demandes';
  end if;
  insert into public.exb_limites_ip(scope, ip_hash) values (p_scope, v_hash);
end $$;
revoke all on function public.exb_ip_limite(text, int) from public, anon, authenticated;

-- ---------- 1 + 3 : choix d'un sujet (jeton, plafond, expiration) ----------
alter table public.tfl_candidatures add column if not exists fiche_token_hash text;

create or replace function public.tfl_sujet_choisir(p_ref text, p_data jsonb, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  s public.tfl_sujets%rowtype;
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_clean jsonb; v_id uuid; v_hash text; v_token text := null;
  v_jours constant int := 14;      -- une réservation sans fiche complétée expire après 14 jours
  v_max_res constant int := 2;     -- sujets exclusifs réservés en même temps par un même numéro
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  perform public.exb_ip_limite('tfl_choisir', 40);
  select * into s from public.tfl_sujets where ref = btrim(coalesce(p_ref,'')) for update;
  if not found or not s.publie then raise exception 'sujet_introuvable'; end if;
  if s.statut in ('ferme','attribue') then raise exception 'sujet_indisponible'; end if;
  -- expiration : réservation ancienne, fiche jamais complétée, dossier non importé → le sujet redevient disponible
  if s.exclusif and s.statut = 'reserve' and s.reserve_tel is distinct from v_tel
     and s.reserve_at < now() - make_interval(days => v_jours)
     and not exists (select 1 from public.tfl_candidatures c
                      where c.data->>'sujet_ref' = s.ref and c.data->>'telephone' = s.reserve_tel
                        and (c.imported or coalesce(c.data->>'annee_academique','') <> '')) then
    update public.tfl_sujets set statut = 'disponible', reserve_tel = null, reserve_at = null, updated_at = now() where ref = s.ref;
    s.statut := 'disponible'; s.reserve_tel := null;
  end if;
  if s.exclusif and s.statut = 'reserve' then
    if s.reserve_tel is distinct from v_tel then raise exception 'sujet_deja_reserve'; end if;
  end if;
  if s.exclusif and not (s.statut = 'reserve' and s.reserve_tel = v_tel)
     and (select count(*) from public.tfl_sujets where statut = 'reserve' and reserve_tel = v_tel) >= v_max_res then
    raise exception 'trop_de_reservations';
  end if;
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere', s.data->>'filiere', ''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', coalesce(s.data->>'domaine', 'autre'),
    'sujet_ref', s.ref,
    'sujet_titre', s.data->>'titre',
    'problematique', s.data->>'problematique',
    'objectifs', s.data->>'objectifs',
    'methodologie', s.data->>'methodologie',
    'recherches_deja', left(coalesce(p_data->>'motivation',''), 3000));
  select id, fiche_token_hash into v_id, v_hash from public.tfl_candidatures
   where data->>'sujet_ref' = s.ref and data->>'telephone' = v_tel and not imported limit 1;
  if v_id is null then
    -- premier choix : le jeton n'est remis qu'ici, une seule fois (le serveur ne garde que son empreinte)
    v_token := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');
    insert into public.tfl_candidatures(submitted_at, ref, data, fiche_token_hash)
    values (p_submitted, left('SUJET-' || s.ref, 40), v_clean, encode(sha256(convert_to(v_token, 'UTF8')), 'hex')) returning id into v_id;
  end if;
  -- renvoi de la même demande : aucun nouveau jeton (sinon quelqu'un connaissant le numéro en obtiendrait un)
  if s.exclusif then
    update public.tfl_sujets set statut = 'reserve', reserve_tel = v_tel, reserve_at = coalesce(case when s.reserve_tel = v_tel then s.reserve_at end, now()), updated_at = now() where ref = s.ref;
  end if;
  return jsonb_build_object('ok', true, 'reserve', s.exclusif, 'token', v_token);
end $$;
revoke all on function public.tfl_sujet_choisir(text, jsonb, timestamptz) from public;
grant execute on function public.tfl_sujet_choisir(text, jsonb, timestamptz) to anon, authenticated;

-- ---------- 1 : envoi de la fiche étudiante avec jeton ----------
drop function if exists public.tfl_fiche_etudiant_envoyer(text, jsonb, text);
create or replace function public.tfl_fiche_etudiant_envoyer(p_ref text, p_data jsonb, p_photo text default null, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ref text := btrim(coalesce(p_ref,''));
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_old public.tfl_candidatures%rowtype;
  v_new jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  perform public.exb_ip_limite('tfl_fiche', 40);
  select * into v_old from public.tfl_candidatures
   where data->>'sujet_ref' = v_ref and data->>'telephone' = v_tel
   order by created_at desc limit 1;
  if not found then raise exception 'choix_introuvable'; end if;
  -- jeton : exigé dès que le choix en a un (les choix antérieurs à cette migration n'en ont pas et restent acceptés)
  if v_old.fiche_token_hash is not null then
    if coalesce(p_token,'') = '' then raise exception 'jeton_requis'; end if;
    if encode(sha256(convert_to(left(p_token, 200), 'UTF8')), 'hex') is distinct from v_old.fiche_token_hash then raise exception 'jeton_invalide'; end if;
  end if;
  v_new := v_old.data || jsonb_build_object(
    'nom', v_nom,
    'email', left(coalesce(p_data->>'email', v_old.data->>'email',''), 120),
    'universite', left(coalesce(nullif(p_data->>'universite',''), v_old.data->>'universite',''), 150),
    'promotion', left(coalesce(nullif(p_data->>'promotion',''), v_old.data->>'promotion',''), 60),
    'filiere', left(coalesce(nullif(p_data->>'filiere',''), v_old.data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(nullif(p_data->>'matricule_existant',''), v_old.data->>'matricule_existant',''), 40),
    'annee_academique', left(coalesce(p_data->>'annee_academique',''), 20),
    'faculte', left(coalesce(p_data->>'faculte',''), 100),
    'niveau', left(coalesce(p_data->>'niveau',''), 20),
    'date_naissance', left(coalesce(p_data->>'date_naissance',''), 20),
    'lieu_naissance', left(coalesce(p_data->>'lieu_naissance',''), 100),
    'nationalite', left(coalesce(p_data->>'nationalite',''), 60),
    'adresse', left(coalesce(p_data->>'adresse',''), 150),
    'matricule_univ', left(coalesce(p_data->>'matricule_univ',''), 40),
    'remarques', left(coalesce(p_data->>'remarques',''), 1000),
    'recherches_deja', left(coalesce(nullif(p_data->>'recherches_deja',''), v_old.data->>'recherches_deja',''), 3000));
  if not v_old.imported then
    update public.tfl_candidatures set data = v_new, photo = coalesce(nullif(p_photo,''), photo) where id = v_old.id;
  else
    insert into public.tfl_candidatures(submitted_at, ref, data, photo, fiche_token_hash)
    values (now(), v_old.ref, v_new, coalesce(nullif(p_photo,''), v_old.photo), v_old.fiche_token_hash);
  end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) from public;
grant execute on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) to anon, authenticated;

-- ---------- 2 : registre QR — « non confirmé » pour les dépôts du public ----------
alter table public.exb_doc_registry add column if not exists anon boolean not null default false;
-- les fiches déjà déposées par le public (texte posé par exb_doc_declare) deviennent « non confirmées »
update public.exb_doc_registry set anon = true
 where kind = 'inscription' and anon = false and detail like 'Fiche reçue par Excellencia Building%';

-- Dépôt public : marqué « anon ».
create or replace function public.exb_doc_declare(p_data jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_no text := left(btrim(coalesce(p_data->>'no','')),60); v_hash text := left(btrim(coalesce(p_data->>'hash','')),20);
begin
  if length(v_no) < 3 or length(v_hash) < 6 then raise exception 'donnees_invalides'; end if;
  perform public.exb_ip_limite('doc_declare', 100);
  if (select count(*) from public.exb_doc_registry where kind = 'inscription' and created_at > now() - interval '1 hour') >= 300 then raise exception 'trop_de_demandes'; end if;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail, anon)
  values (v_no, v_hash, 'inscription', nullif(p_data->>'date','')::date, 0, '', 'reçue', left(p_data->>'nom',120), left(p_data->>'matricule',40), left(p_data->>'libelle',200), 'Fiche reçue par Excellencia Building (en cours de traitement)', true)
  on conflict (no, hash) do nothing;
  return jsonb_build_object('ok', true);
exception when invalid_text_representation or invalid_datetime_format then raise exception 'date_invalide';
end $$;
grant execute on function public.exb_doc_declare(jsonb) to anon, authenticated;

-- Publication par l'administrateur : le document devient « confirmé » (anon = false).
create or replace function public.exb_doc_publish2(p_no text, p_kind text, p_hash text, p_date date, p_total numeric, p_cur text,
  p_status text, p_nom text, p_matricule text, p_libelle text, p_detail text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail, updated_at, anon)
  values (left(p_no,60), left(p_hash,20), p_kind, p_date, p_total, left(coalesce(p_cur,''),8), left(coalesce(p_status,''),20),
          left(p_nom,120), left(p_matricule,40), left(p_libelle,200), left(p_detail,300), now(), false)
  on conflict (no, hash) do update set status = excluded.status, total = excluded.total, cur = excluded.cur, doc_date = excluded.doc_date,
    nom = excluded.nom, matricule = excluded.matricule, libelle = excluded.libelle, detail = excluded.detail, updated_at = now(), anon = false;
  if p_status in ('annulé') then
    update public.exb_doc_registry set status = 'annulé', updated_at = now() where no = left(p_no,60) and kind = p_kind;
  end if;
end $$;
revoke all on function public.exb_doc_publish2(text,text,text,date,numeric,text,text,text,text,text,text) from public, anon;
grant execute on function public.exb_doc_publish2(text,text,text,date,numeric,text,text,text,text,text,text) to authenticated;

-- Confirmation d'une fiche déposée par le public (administrateur) : confirme la PLUS ANCIENNE ligne correspondant au numéro
-- (et au nom / code si fournis), pour qu'un faux dépôt ultérieur sur le même numéro ne soit pas confirmé à sa place.
create or replace function public.exb_doc_confirmer(p_no text, p_hash text default null, p_nom text default null)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  update public.exb_doc_registry set anon = false, detail = 'Fiche confirmée par Excellencia Building', updated_at = now()
   where ctid = (select g.ctid from public.exb_doc_registry g
                  where g.no = left(p_no,60) and g.anon and g.kind = 'inscription'
                    and (p_hash is null or g.hash = left(p_hash,20))
                    and (p_nom is null or lower(btrim(g.nom)) = lower(btrim(p_nom)))
                  order by g.created_at asc limit 1);
  get diagnostics n = row_count;
  return n;
end $$;
drop function if exists public.exb_doc_confirmer(text, text);
revoke all on function public.exb_doc_confirmer(text, text, text) from public, anon;
grant execute on function public.exb_doc_confirmer(text, text, text) to authenticated;

-- Vérification : « latest » ne compte que les documents confirmés ; un dépôt public n'est jamais « authentique ».
create or replace function public.exb_doc_verify2(p_no text, p_hash text)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare r public.exb_doc_registry; c public.exb_doc_registry;
begin
  select * into r from public.exb_doc_registry where no = left(p_no,60) and hash = left(p_hash,20);
  if not found then return jsonb_build_object('found', false); end if;
  if r.anon then c := r;
  else select * into c from public.exb_doc_registry where no = r.no and kind = r.kind and not anon order by created_at desc, hash limit 1;
  end if;
  return jsonb_build_object('found', true, 'kind', r.kind, 'status', r.status, 'nom', r.nom, 'matricule', r.matricule, 'libelle', r.libelle,
    'detail', case when r.anon then 'Fiche déposée en ligne, en attente de confirmation par Excellencia Building' else r.detail end,
    'date', r.doc_date, 'total', r.total, 'cur', r.cur, 'latest', (c.hash = r.hash), 'confirmed', not r.anon,
    'current', case when c.hash = r.hash then null else jsonb_build_object('hash', c.hash, 'date', c.doc_date, 'total', c.total, 'cur', c.cur, 'status', c.status, 'libelle', c.libelle) end);
end $$;
grant execute on function public.exb_doc_verify2(text,text) to anon, authenticated;

-- Ancienne vérification (V99l, repli des vieux clients) : un dépôt public n'y apparaît plus comme confirmé.
create or replace function public.exb_doc_verify(p_no text, p_hash text)
returns jsonb language sql security definer set search_path = public stable as $$
  select coalesce((select jsonb_build_object('found', true, 'status', case when anon then 'non confirmé' else status end)
                     from public.exb_doc_registry where no = left(p_no,60) and hash = left(p_hash,20)), jsonb_build_object('found', false));
$$;
grant execute on function public.exb_doc_verify(text,text) to anon, authenticated;

-- Recherche par matricule / numéro : indique si la fiche est confirmée.
create or replace function public.exb_doc_search(p_q text)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare q text := btrim(coalesce(p_q,''));
begin
  if length(q) < 3 then return jsonb_build_object('items', '[]'::jsonb); end if;
  return jsonb_build_object('items', coalesce((select jsonb_agg(x) from (
    select kind, no, doc_date as date, status, nom, matricule, libelle, (not anon) as confirmed
    from public.exb_doc_registry where upper(matricule) = upper(q) or upper(no) = upper(q)
    order by created_at desc limit 20) x), '[]'::jsonb));
end $$;
grant execute on function public.exb_doc_search(text) to anon, authenticated;

-- Contrôles : select proname from pg_proc where proname in ('exb_ip_limite','exb_doc_confirmer'); -- 2 lignes
--             select column_name from information_schema.columns where table_name='tfl_candidatures' and column_name='fiche_token_hash'; -- 1 ligne
