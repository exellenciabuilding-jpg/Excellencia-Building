-- ===== Excellencia Building — V99zn : synchronisation des modules ERP V92, BTP V93, paiements V93, formation V95, liens V97 =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, APRÈS toutes les autres migrations (en dernier, après v98-unifie).
-- Réexécutable sans danger. FAITES D'ABORD UNE SAUVEGARDE, et essayez sur un projet de recette.
--
-- CE QUE FAIT CE SCRIPT
--  1. Déclare les collections SENSIBLES (paie, contrats RH, personnel, banque) : un membre « polyvalent » n'y a plus accès,
--     même en lecture. Seuls l'administrateur et les fonctions qui ont une ligne dans droits_fonction y accèdent.
--     (Avant : « polyvalent » avait un accès complet à la paie via le stockage générique « enregistrements ».)
--  2. Donne aux fonctions (direction, comptable, rh, conducteur…) sur les nouvelles collections les mêmes droits que sur la
--     collection équivalente existante (ex. v92_commandes = achats). Rien n'est écrasé.
--  3. Les modules V92 / V93 / V95 / V97 enregistrent désormais dans le même stockage versionné que les autres modules
--     (table « enregistrements » : un enregistrement = une fiche, détection de conflit, journal des opérations).
--     Les tables dédiées erp_* de migration-v92-erp.sql ne sont pas utilisées par ces modules (elles restent vides).
--
-- À SAVOIR APRÈS L'EXÉCUTION
--  - Un membre « polyvalent » ne voit plus personnel, paie, contrats RH, rapprochement bancaire ni les données ERP V92 correspondantes.
--    Donnez-lui la bonne fonction si nécessaire :  update membres set fonction='comptable' where user_id='…' and org_id='…';
--  - Le test de non-régression se fait avec un compte « polyvalent » et un compte « comptable » : voir les requêtes en fin de fichier.

-- ---------- 1. Collections sensibles ----------
create table if not exists collections_sensibles(collection text primary key);
alter table collections_sensibles enable row level security;
-- aucune politique : seule la fonction peut() (security definer) lit cette table.

insert into collections_sensibles(collection) values
  ('personnel'),('paie'),('contrats_rh'),('rapprochement_bancaire'),
  ('v92_employes'),('v92_contrats_rh'),('v92_paies'),('v92_banques'),('v92_transactions_bancaires')
on conflict do nothing;

-- Les anciennes lignes « polyvalent » donnaient un accès complet à ces collections (migration-v90-enterprise.sql) : retirées.
delete from droits_fonction
 where fonction='polyvalent' and collection in (select collection from collections_sensibles);

-- Droit de lecture / d'écriture d'un membre sur une collection.
--  admin ........... tout
--  polyvalent ...... tout SAUF les collections sensibles (sauf ligne explicite dans droits_fonction)
--  autre fonction .. uniquement ce que droits_fonction autorise
--  lecteur ......... jamais d'écriture
create or replace function peut(p_org uuid, p_col text, p_ecrire boolean default false)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from membres m
    where m.org_id=p_org and m.user_id=auth.uid() and (
      m.role='admin'
      or ((not p_ecrire or m.role='editeur') and (
            (m.fonction='polyvalent' and not exists(select 1 from collections_sensibles s where s.collection=p_col))
            or exists(select 1 from droits_fonction d
                      where d.fonction=m.fonction and d.collection=p_col
                        and (case when p_ecrire then d.ecrire else d.lire end))
      ))
    )) $$;
grant execute on function peut(uuid,text,boolean) to authenticated;

-- ---------- 2. Droits des nouvelles collections (copiés depuis la collection équivalente) ----------
insert into droits_fonction(fonction,collection,lire,ecrire)
select d.fonction, m.nouveau, d.lire, d.ecrire
from droits_fonction d
join (values
  ('v92_crm','crm'),
  ('v92_fournisseurs','fournisseurs'),
  ('v92_demandes_achat','achats'),
  ('v92_commandes','achats'),
  ('v92_receptions','achats'),
  ('v92_factures_fournisseurs','achats'),
  ('v92_stock','stock'),
  ('v92_mouvements_stock','mouvements'),
  ('v92_banques','rapprochement_bancaire'),
  ('v92_transactions_bancaires','rapprochement_bancaire'),
  ('v92_employes','personnel'),
  ('v92_contrats_rh','contrats_rh'),
  ('v92_paies','paie'),
  ('v93_projets','projets'),
  ('v93_chantiers','projets'),
  ('v93_taches','projets'),
  ('v93_qhse','qhse'),
  ('v93_materiel','parc_materiel'),
  ('v93_sous_traitance','sous_traitants'),
  ('v93_moyens_paiement','finance'),
  ('v93_paiements','finance'),
  ('v93_operations_caisse','caisse'),
  ('v95_formation_workflow','documents'),
  ('v97_liens_flux','projets')
) as m(nouveau,ancien) on d.collection=m.ancien
where d.fonction<>'polyvalent' or m.nouveau not in (select collection from collections_sensibles)
on conflict (fonction,collection) do nothing;

-- ---------- 3. Vérifications (à lancer à la main) ----------
-- a) Les collections sensibles n'ont plus de ligne « polyvalent » :
--    select * from droits_fonction where fonction='polyvalent' and collection in (select collection from collections_sensibles);   -- doit être vide
-- b) Droits de la fonction comptable sur la banque V92 :
--    select * from droits_fonction where fonction='comptable' and collection in ('v92_banques','v92_transactions_bancaires');
-- c) En vous connectant avec un compte « polyvalent », la fonction peut(<org>,'paie') doit répondre false ; avec « rh », true.
