-- ===== Excellencia Building V99zzr — TFL : candidatures reçues EN LIGNE (formulaire Internet) =====
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger. INDÉPENDANT de migration-v99zzq-tfl.sql
-- (pas besoin d'exécuter le gros script des portails : ici seulement une « boîte de réception » des candidatures).
-- PRINCIPE : comme les inscriptions d'apprenants.
--   · L'étudiant (sans compte) envoie sa candidature par la page tfl-formulaire.html -> fonction tfl_candidature_envoyer (anonyme, limitée en volume).
--   · Personne ne peut lire la table directement (RLS sans politique). Seul l'administrateur connecté lit / marque « traitée ».
--   · L'application importe ensuite chaque candidature dans le module TFL local (numéro TFL-AAAA-0001, matricule, décision).
-- Remplacez les e-mails administrateur si besoin (en minuscules) : ce sont les mêmes que ceux de migration-v99m-verification.sql.

create table if not exists public.tfl_candidatures (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  submitted_at timestamptz,
  ref text,
  data jsonb not null,
  photo text,
  imported boolean not null default false,
  imported_at timestamptz
);
create index if not exists tfl_candidatures_created_idx on public.tfl_candidatures (created_at desc);
alter table public.tfl_candidatures enable row level security;
-- aucune politique : accès uniquement par les fonctions ci-dessous
revoke all on public.tfl_candidatures from anon, authenticated;

-- ---------- Envoi par l'étudiant (anonyme) ----------
create or replace function public.tfl_candidature_envoyer(p_data jsonb, p_photo text default null, p_ref text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_titre text := left(btrim(coalesce(p_data->>'sujet_titre','')), 250);
  v_prob text := left(btrim(coalesce(p_data->>'problematique','')), 3000);
  v_obj text := left(btrim(coalesce(p_data->>'objectifs','')), 3000);
  v_clean jsonb; v_id uuid; v_k text;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if length(v_titre) < 3 or length(v_prob) < 3 or length(v_obj) < 3 then raise exception 'sujet_incomplet'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  -- limite anti-spam : 200 candidatures par heure au total, 5 par numéro de téléphone et par heure
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  -- on ne garde que les champs attendus, tronqués
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', case when p_data->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then p_data->>'domaine' else 'autre' end,
    'sujet_titre', v_titre, 'problematique', v_prob, 'objectifs', v_obj,
    'methodologie', left(coalesce(p_data->>'methodologie',''), 3000),
    'recherches_deja', left(coalesce(p_data->>'recherches_deja',''), 3000));
  -- renvoi du même envoi (réseau instable) : pas de doublon
  select id into v_id from public.tfl_candidatures
   where p_submitted is not null and submitted_at = p_submitted and data->>'telephone' = v_tel limit 1;
  if v_id is null then
    insert into public.tfl_candidatures(submitted_at, ref, data, photo)
    values (p_submitted, left(coalesce(p_ref,''), 40), v_clean, nullif(p_photo,'')) returning id into v_id;
  end if;
  return jsonb_build_object('ok', true);
end $$;
grant execute on function public.tfl_candidature_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;

-- ---------- Lecture / traitement par l'administrateur ----------
create or replace function public.tfl_candidatures_liste()
returns table(id uuid, created_at timestamptz, submitted_at timestamptz, ref text, data jsonb, photo text, imported boolean)
language plpgsql security definer set search_path = public stable as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  return query select c.id, c.created_at, c.submitted_at, c.ref, c.data, c.photo, c.imported
    from public.tfl_candidatures c order by c.created_at desc limit 500;
end $$;
revoke all on function public.tfl_candidatures_liste() from public, anon;
grant execute on function public.tfl_candidatures_liste() to authenticated;

create or replace function public.tfl_candidature_traiter(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  update public.tfl_candidatures set imported = true, imported_at = now() where id = p_id;
end $$;
revoke all on function public.tfl_candidature_traiter(uuid) from public, anon;
grant execute on function public.tfl_candidature_traiter(uuid) to authenticated;

-- Contrôle rapide après exécution (doit renvoyer 3 lignes) :
-- select proname from pg_proc where proname in ('tfl_candidature_envoyer','tfl_candidatures_liste','tfl_candidature_traiter');
