-- ===== Excellencia Building V99zzt — TFL : portails ÉTUDIANT et ENCADREUR avec connexion =====
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger.
-- INDÉPENDANT de migration-v99zzq-tfl.sql (le gros script « comptes Supabase + RLS » reste NON nécessaire) ;
-- il complète migration-v99zzr-tfl-en-ligne.sql (même liste d'e-mails administrateur).
--
-- PRINCIPE (comme le portail client V99zy et l'espace apprenant) :
--   · Les dossiers restent sur l'appareil de l'administration. Ici le serveur ne garde qu'un INSTANTANÉ publié par l'administrateur
--     (ce que l'étudiant ou l'encadreur a le droit de voir) et la boîte de réception de leurs messages.
--   · Connexion = identifiant + mot de passe. Étudiant : son matricule (000-000-000). Encadreur : son code ENC-xxxx.
--     Le mot de passe de départ (6 à 12 chiffres) est choisi par l'application ; il DOIT être changé à la première connexion (8 caractères minimum).
--   · Aucune table lisible en direct (RLS sans politique) : tout passe par les fonctions ci-dessous.
--   · 5 mots de passe faux de suite = blocage 15 minutes. Mot de passe stocké haché (SHA-256 salé par rôle + identifiant).
--   · L'étudiant ne peut écrire QUE sur son dossier ; l'encadreur QUE sur les dossiers présents dans son instantané (affectés et acceptés).
--     Ni l'un ni l'autre ne peut changer un statut, une affectation ou une décision : la progression proposée par l'encadreur
--     n'est appliquée que par l'application de l'administration, après vérification.
--   · Lecture, publication et révocation : réservées aux e-mails administrateur (mêmes que migration-v99zzr-tfl-en-ligne.sql).
-- Remplacez les e-mails administrateur si besoin (en minuscules) dans la fonction tfl_admin_ok() ci-dessous.

create extension if not exists pgcrypto with schema extensions;

-- ---------- Tables ----------
create table if not exists public.tfl_acces (
  id uuid primary key default gen_random_uuid(),
  role text not null check (role in ('etudiant','encadreur')),
  identifiant text not null,                       -- normalisé : majuscules, lettres et chiffres seulement
  nom text not null default '',
  mdp_hash text not null,
  doit_changer boolean not null default true,
  actif boolean not null default true,
  essais int not null default 0,
  bloque_jusqua timestamptz,
  contenu jsonb not null default '{}'::jsonb,      -- instantané publié par l'administrateur
  publie_le timestamptz not null default now(),
  derniere_connexion timestamptz,
  connexions int not null default 0,
  unique (role, identifiant)
);
alter table public.tfl_acces enable row level security;
revoke all on public.tfl_acces from anon, authenticated;   -- aucune politique : accès uniquement par les fonctions

create table if not exists public.tfl_messages (
  id uuid primary key default gen_random_uuid(),
  acces_id uuid not null references public.tfl_acces(id) on delete cascade,
  de text not null check (de in ('etudiant','encadreur')),
  type text not null default 'message' check (type in ('message','commentaire','progression')),
  dossier text not null default '',                -- numéro du dossier (TFL-AAAA-0001)
  texte text not null default '',
  valeur int,                                      -- progression proposée (0-100) pour type = progression
  cree_le timestamptz not null default now(),
  traite boolean not null default false,
  traite_le timestamptz
);
create index if not exists tfl_messages_acces_idx on public.tfl_messages (acces_id, cree_le);
create index if not exists tfl_messages_attente_idx on public.tfl_messages (traite, cree_le);
alter table public.tfl_messages enable row level security;
revoke all on public.tfl_messages from anon, authenticated;

-- ---------- Fonctions internes ----------
create or replace function public.tfl_admin_ok() returns boolean
language sql stable security definer set search_path = public as $$
  select lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com'])
$$;
revoke all on function public.tfl_admin_ok() from public, anon;
grant execute on function public.tfl_admin_ok() to authenticated;

create or replace function public.tfl_norm_id(p text) returns text
language sql immutable as $$ select upper(regexp_replace(coalesce(p,''), '[^A-Za-z0-9]', '', 'g')) $$;
revoke all on function public.tfl_norm_id(text) from public, anon, authenticated;

create or replace function public.tfl_h(p_mdp text, p_role text, p_ident text) returns text
language sql immutable set search_path = public, extensions as $$
  select encode(extensions.digest(convert_to(coalesce(p_mdp,'') || ':' || coalesce(p_role,'') || ':' || public.tfl_norm_id(p_ident), 'UTF8'), 'sha256'), 'hex')
$$;
revoke all on function public.tfl_h(text, text, text) from public, anon, authenticated;

-- Vérifie identifiant + mot de passe. Pas d'exception : elle annulerait le comptage des essais ratés.
create or replace function public.tfl_acces_check(p_role text, p_ident text, p_mdp text,
  out v_id uuid, out v_err text, out v_min int, out v_changer boolean)
language plpgsql security definer set search_path = public, extensions as $$
declare a public.tfl_acces; v_i text := public.tfl_norm_id(left(coalesce(p_ident,''), 60));
begin
  v_id := null; v_err := null; v_min := 0; v_changer := false;
  select * into a from public.tfl_acces where role = p_role and identifiant = v_i;
  if not found then v_err := 'code'; return; end if;   -- même message qu'un mauvais mot de passe : on ne révèle pas si l'identifiant existe
  if a.bloque_jusqua is not null and a.bloque_jusqua > now() then
    v_err := 'bloque'; v_min := greatest(1, ceil(extract(epoch from (a.bloque_jusqua - now())) / 60)::int); return;
  end if;
  if a.mdp_hash <> public.tfl_h(left(coalesce(p_mdp,''), 100), a.role, a.identifiant) then
    if a.essais + 1 >= 5 then
      update public.tfl_acces set essais = 0, bloque_jusqua = now() + interval '15 minutes' where id = a.id;
      v_err := 'bloque'; v_min := 15;
    else
      update public.tfl_acces set essais = essais + 1 where id = a.id;
      v_err := 'code';
    end if;
    return;
  end if;
  if not a.actif then v_err := 'revoque'; return; end if;
  if a.essais <> 0 or a.bloque_jusqua is not null then update public.tfl_acces set essais = 0, bloque_jusqua = null where id = a.id; end if;
  v_id := a.id; v_changer := a.doit_changer;
end $$;
revoke all on function public.tfl_acces_check(text, text, text) from public, anon, authenticated;

-- ---------- Côté administration (e-mail administrateur connecté) ----------
create or replace function public.tfl_portail_publier(p_role text, p_ident text, p_nom text, p_code text, p_contenu jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v_i text := public.tfl_norm_id(left(coalesce(p_ident,''), 60)); v_id uuid; v_new boolean := false;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_role not in ('etudiant','encadreur') then raise exception 'role_invalide'; end if;
  if length(v_i) < 3 then raise exception 'identifiant_invalide'; end if;
  if jsonb_typeof(p_contenu) is distinct from 'object' then raise exception 'contenu_invalide'; end if;
  if octet_length(p_contenu::text) > 600000 then raise exception 'contenu_trop_gros'; end if;
  if coalesce(p_code,'') <> '' and p_code !~ '^[0-9]{6,12}$' then raise exception 'code_invalide'; end if;
  select id into v_id from public.tfl_acces where role = p_role and identifiant = v_i;
  if v_id is null then
    if coalesce(p_code,'') = '' then raise exception 'code_requis'; end if;
    insert into public.tfl_acces(role, identifiant, nom, mdp_hash, contenu)
    values (p_role, v_i, left(coalesce(p_nom,''), 160), public.tfl_h(p_code, p_role, v_i), p_contenu) returning id into v_id;
    v_new := true;
  else
    update public.tfl_acces set nom = left(coalesce(p_nom,''), 160), contenu = p_contenu, publie_le = now(), actif = true,
      mdp_hash = case when coalesce(p_code,'') <> '' then public.tfl_h(p_code, p_role, v_i) else mdp_hash end,
      doit_changer = case when coalesce(p_code,'') <> '' then true else doit_changer end,
      essais = case when coalesce(p_code,'') <> '' then 0 else essais end,
      bloque_jusqua = case when coalesce(p_code,'') <> '' then null else bloque_jusqua end
    where id = v_id;
  end if;
  return jsonb_build_object('ok', true, 'nouveau', v_new);
end $$;
revoke all on function public.tfl_portail_publier(text,text,text,text,jsonb) from public, anon;
grant execute on function public.tfl_portail_publier(text,text,text,text,jsonb) to authenticated;

create or replace function public.tfl_portail_revoquer(p_role text, p_ident text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  update public.tfl_acces set actif = false where role = p_role and identifiant = public.tfl_norm_id(left(coalesce(p_ident,''), 60));
end $$;
revoke all on function public.tfl_portail_revoquer(text,text) from public, anon;
grant execute on function public.tfl_portail_revoquer(text,text) to authenticated;

create or replace function public.tfl_portail_liste()
returns table(role text, identifiant text, nom text, actif boolean, doit_changer boolean, publie_le timestamptz, derniere_connexion timestamptz, connexions int)
language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return query select a.role, a.identifiant, a.nom, a.actif, a.doit_changer, a.publie_le, a.derniere_connexion, a.connexions
    from public.tfl_acces a order by a.role, a.nom limit 1000;
end $$;
revoke all on function public.tfl_portail_liste() from public, anon;
grant execute on function public.tfl_portail_liste() to authenticated;

create or replace function public.tfl_portail_retours()
returns table(id uuid, role text, identifiant text, nom text, de text, type text, dossier text, texte text, valeur int, cree_le timestamptz)
language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return query select m.id, a.role, a.identifiant, a.nom, m.de, m.type, m.dossier, m.texte, m.valeur, m.cree_le
    from public.tfl_messages m join public.tfl_acces a on a.id = m.acces_id
    where not m.traite order by m.cree_le limit 500;
end $$;
revoke all on function public.tfl_portail_retours() from public, anon;
grant execute on function public.tfl_portail_retours() to authenticated;

create or replace function public.tfl_portail_retours_traiter(p_ids uuid[])
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  update public.tfl_messages set traite = true, traite_le = now() where id = any (p_ids);
end $$;
revoke all on function public.tfl_portail_retours_traiter(uuid[]) from public, anon;
grant execute on function public.tfl_portail_retours_traiter(uuid[]) to authenticated;

-- ---------- Côté visiteur (étudiant / encadreur : identifiant + mot de passe obligatoires) ----------
create or replace function public.tfl_portail_connexion(p_role text, p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then
    select * into a from public.tfl_acces where id = c.v_id;
    return jsonb_build_object('ok', true, 'changer', true, 'nom', a.nom);
  end if;
  update public.tfl_acces set connexions = connexions + 1, derniere_connexion = now() where id = c.v_id returning * into a;
  return jsonb_build_object('ok', true, 'changer', false, 'nom', a.nom, 'publie_le', a.publie_le, 'contenu', a.contenu,
    'messages', coalesce((select jsonb_agg(jsonb_build_object('de', m.de, 'type', m.type, 'dossier', m.dossier, 'texte', m.texte, 'valeur', m.valeur, 'cree_le', m.cree_le) order by m.cree_le)
                          from public.tfl_messages m where m.acces_id = a.id), '[]'::jsonb));
end $$;
revoke all on function public.tfl_portail_connexion(text,text,text) from public;
grant execute on function public.tfl_portail_connexion(text,text,text) to anon, authenticated;

create or replace function public.tfl_portail_changer(p_role text, p_ident text, p_mdp text, p_nouveau text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; v_n text := left(coalesce(p_nouveau,''), 100);
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if length(v_n) < 8 or v_n = coalesce(p_mdp,'') then
    return jsonb_build_object('ok', false, 'code', 'faible');
  end if;
  update public.tfl_acces set mdp_hash = public.tfl_h(v_n, role, identifiant), doit_changer = false where id = c.v_id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_portail_changer(text,text,text,text) from public;
grant execute on function public.tfl_portail_changer(text,text,text,text) to anon, authenticated;

create or replace function public.tfl_portail_envoyer(p_role text, p_ident text, p_mdp text, p_dossier text, p_type text, p_texte text, p_valeur int default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_t text := left(btrim(coalesce(p_texte,'')), 1500); v_d text := left(btrim(coalesce(p_dossier,'')), 40);
        v_type text := coalesce(nullif(p_type,''), 'message'); v_ok boolean;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if v_type not in ('message','commentaire','progression') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if a.role = 'etudiant' and v_type <> 'message' then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  -- dossier : celui de l'étudiant, ou l'un des dossiers affectés à l'encadreur (selon l'instantané publié)
  if a.role = 'etudiant' then
    if v_d = '' then v_d := coalesce(a.contenu->>'numero',''); end if;
    v_ok := v_d <> '' and v_d = coalesce(a.contenu->>'numero','');
  else
    v_ok := v_d <> '' and exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = v_d);
  end if;
  if not v_ok then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if v_type = 'progression' then
    if p_valeur is null or p_valeur < 0 or p_valeur > 100 then return jsonb_build_object('ok', false, 'code', 'valeur'); end if;
  else
    if length(v_t) < 2 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  end if;
  if (select count(*) from public.tfl_messages where acces_id = a.id and cree_le > now() - interval '1 hour') >= 30 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_messages(acces_id, de, type, dossier, texte, valeur)
  values (a.id, a.role, v_type, v_d, v_t, case when v_type = 'progression' then p_valeur else null end);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_portail_envoyer(text,text,text,text,text,text,int) from public;
grant execute on function public.tfl_portail_envoyer(text,text,text,text,text,text,int) to anon, authenticated;

-- Contrôle rapide après exécution (doit renvoyer 8 lignes) :
-- select proname from pg_proc where proname in ('tfl_portail_publier','tfl_portail_revoquer','tfl_portail_liste','tfl_portail_retours',
--   'tfl_portail_retours_traiter','tfl_portail_connexion','tfl_portail_changer','tfl_portail_envoyer');
-- Et : select tablename, rowsecurity from pg_tables where tablename in ('tfl_acces','tfl_messages');   -- rowsecurity = true pour les deux
