-- ===== Excellencia Building — V99zw : fichiers de plans partagés (DXF, IFC, PDF, images, DWG, RVT) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS v99zn, v99zo et v99zp. Réexécutable sans danger.
-- Crée l'espace privé « exb-plans » : un dossier par entreprise (<id entreprise>/plans/<fichier>).
-- Lecture / écriture réservées aux membres qui ont le droit sur « plans_fichiers » (même règle que la fiche du plan),
-- avec 2FA et licence appliquées comme pour les autres données.

insert into storage.buckets(id,name,public,file_size_limit)
values ('exb-plans','exb-plans',false,104857600)
on conflict (id) do update set public=false, file_size_limit=excluded.file_size_limit;

create or replace function org_du_chemin(p_name text) returns uuid language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

drop policy if exists plans_lire on storage.objects;
create policy plans_lire on storage.objects for select to authenticated
  using (bucket_id='exb-plans' and peut(org_du_chemin(name),'plans_fichiers',false));
drop policy if exists plans_ajout on storage.objects;
create policy plans_ajout on storage.objects for insert to authenticated
  with check (bucket_id='exb-plans' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists plans_modif on storage.objects;
create policy plans_modif on storage.objects for update to authenticated
  using (bucket_id='exb-plans' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists plans_suppr on storage.objects;
create policy plans_suppr on storage.objects for delete to authenticated
  using (bucket_id='exb-plans' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
