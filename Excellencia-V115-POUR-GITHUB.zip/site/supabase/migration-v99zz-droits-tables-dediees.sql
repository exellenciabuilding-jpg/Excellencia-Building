-- ===== Excellencia Building — V99zz : droits PAR FONCTION sur les tables dédiées sensibles =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor, APRÈS migration-v99zo-securite-serveur.sql (et donc v99zn, qui crée peut()).
-- Réexécutable sans danger. FAITES D'ABORD UNE SAUVEGARDE ET ESSAYEZ SUR UN PROJET DE RECETTE : ce script n'a PAS été exécuté sur PostgreSQL
-- au moment de sa rédaction ; lancer tools/test-rls/run.sh (tests T34 à T40) avant toute mise en service.
--
-- POURQUOI
--  Les huit tables dédiées ci-dessous (paie, contrats RH, employés, banque, moyens de paiement, paiements, caisse) étaient protégées
--  par le seul RÔLE du membre (admin / éditeur / lecteur) : n'importe quel membre de l'entreprise pouvait les LIRE par l'API, quelle que
--  soit sa fonction (magasinier, par exemple). Le stockage « enregistrements » (celui qu'utilise l'application) applique déjà les droits
--  par fonction via peut() (V99zn). Ce script aligne les tables dédiées sur la même règle, pour qu'il n'existe pas de porte dérobée.
--  Les modules actuels n'écrivent pas dans ces tables (elles restent vides) : aucun changement de comportement attendu dans l'application.
--
-- CE QUE FAIT LE SCRIPT
--  lecture  : peut(org_id, <collection>, false)  — administrateur, ou fonction qui a « lire » sur la collection dans droits_fonction
--  écriture : peut(org_id, <collection>, true)   — administrateur, ou éditeur dont la fonction a « écrire » ; jamais le lecteur
--  Les politiques RESTRICTIVES de licence (licence_ins / licence_upd / licence_del, V99zo) restent en place : elles se cumulent.
--  Aucune suppression n'est autorisée (comme avant : pas de politique delete).
do $$
declare r record;
begin
  for r in select * from (values
      ('erp_employes','v92_employes'),
      ('erp_contrats_rh','v92_contrats_rh'),
      ('erp_paies','v92_paies'),
      ('erp_comptes_bancaires','v92_banques'),
      ('erp_transactions_bancaires','v92_transactions_bancaires'),
      ('moyens_paiement','v93_moyens_paiement'),
      ('paiements','v93_paiements'),
      ('operations_caisse','v93_operations_caisse')
    ) as v(t,c)
  loop
    if to_regclass('public.'||r.t) is null then continue; end if;   -- table absente : rien à faire
    execute format('alter table %I enable row level security', r.t);
    execute format('drop policy if exists %I_lire on %I', r.t, r.t);
    execute format('create policy %I_lire on %I for select using (peut(org_id,%L,false))', r.t, r.t, r.c);
    execute format('drop policy if exists %I_ecrire on %I', r.t, r.t);
    execute format('create policy %I_ecrire on %I for insert with check (peut(org_id,%L,true))', r.t, r.t, r.c);
    execute format('drop policy if exists %I_modif on %I', r.t, r.t);
    execute format('create policy %I_modif on %I for update using (peut(org_id,%L,true)) with check (peut(org_id,%L,true))', r.t, r.t, r.c, r.c);
  end loop;
end $$;

-- Vérification à la main (doit renvoyer 8 lignes, aucune avec est_membre seul) :
--   select tablename, policyname, cmd, qual, with_check from pg_policies
--    where tablename in ('erp_employes','erp_contrats_rh','erp_paies','erp_comptes_bancaires','erp_transactions_bancaires','moyens_paiement','paiements','operations_caisse')
--      and policyname not like 'licence_%' order by 1,2;
-- Retour en arrière : ré-exécuter la boucle de migration-v92-erp.sql (erp_*) et de migration-v93-btp-payments.sql (moyens_paiement, paiements, operations_caisse).
