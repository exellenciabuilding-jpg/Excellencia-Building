-- Excellencia Building V99o — Page publique de vérification (verification.html) : types de documents supplémentaires.
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99m-verification.sql. Réexécutable sans danger.
-- Ajoute le type « document » (rapports d'activité, fiches du personnel, bons de commande, procès-verbaux, etc.).
-- Aucune donnée de contact n'est stockée ni renvoyée. La page publique n'a besoin d'aucune autre fonction.

alter table public.exb_doc_registry drop constraint if exists exb_doc_registry_kind_check;
alter table public.exb_doc_registry add constraint exb_doc_registry_kind_check
  check (kind in ('devis','facture','recu','certificat','recu_formation','inscription','document'));
