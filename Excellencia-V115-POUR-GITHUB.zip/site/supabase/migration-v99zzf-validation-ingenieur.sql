-- ===== Excellencia Building — V99zzf : validation des calculs par un ingénieur, enregistrée CÔTÉ SERVEUR =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run). Autonome (crée mfa_ok() si besoin) ; v99zo et v99zp restent recommandées. Réexécutable sans danger.
--
-- PROBLÈME RÉSOLU (audit : « calculs d'ingénierie engageant la responsabilité »)
--  V99zl gardait statuts, cachet et journal sur l'appareil : modifiables par un utilisateur technique, sans identité vérifiée.
--  Ici, l'identité de l'ingénieur vient du COMPTE CONNECTÉ (auth.uid()), jamais d'un champ saisi ; le journal est en
--  ajout seul (ni modification ni suppression, même par l'administrateur) ; la date est celle du serveur.
--
-- RÈGLES
--  1. Seuls les membres désignés « ingénieur habilité » par l'administrateur de l'entreprise peuvent émettre
--     Validé / Validé avec réserves / Refusé. N'importe quel membre éditeur peut déposer Émis / Soumis à vérification.
--  2. Valider ou valider avec réserves exige une session 2FA (aal2) : une vraie signature n'est pas un mot de passe seul.
--  3. Le nom et le n° d'ordre inscrits viennent de la fiche « ingénieur habilité », pas du navigateur.
--  4. La validation porte sur l'empreinte (digest) du contenu : si le calcul change, l'empreinte change et il n'y a plus de validation.
--  5. Licence appliquée comme pour les autres écritures (V99zo) ; lecture toujours possible.

-- ---------- 0. Prérequis (autonome : fonctionne même si v99zo / v99zp n'ont pas encore été exécutées) ----------
do $$ begin
  if to_regclass('public.organisations') is null or to_regclass('public.membres') is null or to_regclass('public.journal_entreprise') is null then
    raise exception 'Tables de base absentes (organisations / membres / journal_entreprise) : exécutez d''abord schema-entreprise.sql puis migration-v66-roles.sql.';
  end if;
end $$;

-- Même définition que migration-v99zp-double-authentification.sql (sans effet pour un compte qui n'a pas activé la 2FA).
create or replace function mfa_ok()
returns boolean language sql stable security definer set search_path=public,auth as $$
  select case
    when exists(select 1 from auth.mfa_factors f where f.user_id=auth.uid() and f.status='verified')
      then coalesce(auth.jwt()->>'aal','aal1')='aal2'
    else true end $$;
revoke execute on function mfa_ok() from public, anon;
grant execute on function mfa_ok() to authenticated, service_role;

-- Si migration-v99zo n'a pas été exécutée : licence non contrôlée (fonction neutre). Exécuter v99zo la remplace par le vrai contrôle.
do $$ begin
  if to_regprocedure('public.licence_ecriture_ok(uuid)') is null then
    execute 'create function licence_ecriture_ok(p_org uuid) returns boolean language sql stable security definer set search_path=public as $b$ select true $b$';
    execute 'grant execute on function licence_ecriture_ok(uuid) to authenticated, service_role';
    raise notice 'licence_ecriture_ok absente : fonction neutre créée. Exécutez migration-v99zo-securite-serveur.sql pour appliquer la licence côté serveur.';
  end if;
end $$;

-- ---------- 1. Ingénieurs habilités (désignés par l'administrateur) ----------
create table if not exists ingenieurs_habilites(
  org_id uuid not null references organisations(id) on delete cascade,
  user_id uuid not null,
  nom text not null check (length(btrim(nom)) between 3 and 120),
  ordre text not null check (length(btrim(ordre)) between 2 and 40),
  actif boolean not null default true,
  designe_par uuid,
  maj timestamptz not null default now(),
  primary key (org_id, user_id)
);
alter table ingenieurs_habilites enable row level security;
drop policy if exists ingh_lire on ingenieurs_habilites;
create policy ingh_lire on ingenieurs_habilites for select
  using (mfa_ok() and exists(select 1 from membres m where m.org_id = ingenieurs_habilites.org_id and m.user_id = auth.uid()));
-- aucune politique d'écriture : seule la fonction ci-dessous (administrateur) modifie la table

create or replace function ingenieur_designer(p_org uuid, p_user uuid, p_nom text, p_ordre text, p_actif boolean default true)
returns json language plpgsql security definer set search_path = public as $$
begin
  if not mfa_ok() then return json_build_object('ok', false, 'refus', 'mfa_requise'); end if;
  if not exists(select 1 from membres m where m.org_id = p_org and m.user_id = auth.uid() and m.role = 'admin') then
    return json_build_object('ok', false, 'refus', 'administrateur_requis');
  end if;
  if not exists(select 1 from membres m where m.org_id = p_org and m.user_id = p_user) then
    return json_build_object('ok', false, 'refus', 'membre_inconnu');
  end if;
  if length(btrim(coalesce(p_nom, ''))) < 3 or length(btrim(coalesce(p_ordre, ''))) < 2 then
    return json_build_object('ok', false, 'refus', 'nom_ou_ordre_manquant');
  end if;
  insert into ingenieurs_habilites(org_id, user_id, nom, ordre, actif, designe_par, maj)
  values (p_org, p_user, left(btrim(p_nom), 120), left(btrim(p_ordre), 40), coalesce(p_actif, true), auth.uid(), now())
  on conflict (org_id, user_id) do update
    set nom = excluded.nom, ordre = excluded.ordre, actif = excluded.actif, designe_par = auth.uid(), maj = now();
  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), 'ingenieurs_habilites', p_user::text, case when coalesce(p_actif, true) then 'habilitation' else 'retrait habilitation' end, 0);
  return json_build_object('ok', true);
end $$;
revoke all on function ingenieur_designer(uuid, uuid, text, text, boolean) from public, anon;
grant execute on function ingenieur_designer(uuid, uuid, text, text, boolean) to authenticated;

-- ---------- 2. Journal des validations (ajout seul) ----------
create table if not exists validations_calcul(
  id bigint generated always as identity primary key,
  org_id uuid not null, -- volontairement sans clé étrangère en cascade : le journal ne doit jamais disparaître avec une suppression en chaîne
  projet text not null default '',
  type_calcul text not null,
  no text not null,
  indice text not null default 'A',
  digest text not null check (length(digest) between 6 and 64),
  statut text not null check (statut in ('emis', 'verif', 'valide', 'reserves', 'refuse')),
  commentaire text not null default '',
  declaration boolean not null default false,
  user_id uuid not null,
  ing_nom text not null default '',
  ing_ordre text not null default '',
  aal text not null default 'aal1',
  cree_le timestamptz not null default now()
);
create index if not exists validations_calcul_cle on validations_calcul(org_id, no, digest, id desc);
create index if not exists validations_calcul_projet on validations_calcul(org_id, projet, type_calcul, id desc);
alter table validations_calcul enable row level security;
drop policy if exists valc_lire on validations_calcul;
create policy valc_lire on validations_calcul for select
  using (mfa_ok() and exists(select 1 from membres m where m.org_id = validations_calcul.org_id and m.user_id = auth.uid()));
-- aucune politique d'écriture : insertion uniquement par calcul_valider()

create or replace function validations_calcul_fige() returns trigger language plpgsql as $$
begin raise exception 'journal des validations en ajout seul'; end $$;
drop trigger if exists validations_calcul_no_upd on validations_calcul;
create trigger validations_calcul_no_upd before update or delete on validations_calcul
  for each row execute function validations_calcul_fige();
drop trigger if exists validations_calcul_no_trunc on validations_calcul;
create trigger validations_calcul_no_trunc before truncate on validations_calcul
  for each statement execute function validations_calcul_fige();

-- Supabase accorde par défaut tous les droits aux rôles API : on retire l'écriture directe (en plus de l'absence de politique RLS).
revoke insert, update, delete, truncate on validations_calcul from anon, authenticated;
revoke insert, update, delete, truncate on ingenieurs_habilites from anon, authenticated;
revoke all on validations_calcul from anon;
revoke all on ingenieurs_habilites from anon;

-- ---------- 3. Enregistrer une étape du circuit ----------
create or replace function calcul_valider(
  p_org uuid, p_projet text, p_type text, p_no text, p_indice text, p_digest text,
  p_statut text, p_commentaire text default '', p_declaration boolean default false)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_role text; v_ing ingenieurs_habilites; v_aal text := coalesce(auth.jwt()->>'aal', 'aal1');
  v_nom text := ''; v_ordre text := ''; v_id bigint; v_t timestamptz;
begin
  if auth.uid() is null then return json_build_object('ok', false, 'refus', 'connexion_requise'); end if;
  if not mfa_ok() then return json_build_object('ok', false, 'refus', 'mfa_requise'); end if;
  if p_statut not in ('emis', 'verif', 'valide', 'reserves', 'refuse') then
    return json_build_object('ok', false, 'refus', 'statut_invalide'); end if;
  if length(btrim(coalesce(p_no, ''))) < 3 or length(btrim(coalesce(p_digest, ''))) < 6 or length(btrim(coalesce(p_type, ''))) < 2 then
    return json_build_object('ok', false, 'refus', 'donnees_invalides'); end if;

  select m.role into v_role from membres m where m.org_id = p_org and m.user_id = auth.uid();
  if v_role is null then return json_build_object('ok', false, 'refus', 'non_membre'); end if;
  if v_role not in ('admin', 'editeur') then return json_build_object('ok', false, 'refus', 'ecriture_interdite'); end if;
  if not licence_ecriture_ok(p_org) then return json_build_object('ok', false, 'refus', 'licence'); end if;

  if p_statut in ('valide', 'reserves', 'refuse') then
    select * into v_ing from ingenieurs_habilites h where h.org_id = p_org and h.user_id = auth.uid() and h.actif;
    if not found then return json_build_object('ok', false, 'refus', 'ingenieur_habilite_requis'); end if;
    v_nom := v_ing.nom; v_ordre := v_ing.ordre;
    if p_statut in ('valide', 'reserves') then
      if v_aal <> 'aal2' then return json_build_object('ok', false, 'refus', 'session_2fa_requise'); end if;
      if not coalesce(p_declaration, false) then return json_build_object('ok', false, 'refus', 'declaration_requise'); end if;
    end if;
    if p_statut in ('reserves', 'refuse') and length(btrim(coalesce(p_commentaire, ''))) < 3 then
      return json_build_object('ok', false, 'refus', 'commentaire_requis'); end if;
  end if;

  insert into validations_calcul(org_id, projet, type_calcul, no, indice, digest, statut, commentaire, declaration, user_id, ing_nom, ing_ordre, aal)
  values (p_org, left(coalesce(p_projet, ''), 200), left(p_type, 80), left(btrim(p_no), 60), left(coalesce(nullif(btrim(p_indice), ''), 'A'), 10),
          left(btrim(p_digest), 64), p_statut, left(coalesce(p_commentaire, ''), 600), coalesce(p_declaration, false) and p_statut in ('valide', 'reserves'),
          auth.uid(), v_nom, v_ordre, v_aal)
  returning id, cree_le into v_id, v_t;

  insert into journal_entreprise(org_id, user_id, collection, rec_id, action, version)
  values (p_org, auth.uid(), 'validations_calcul', v_id::text, 'calcul ' || p_statut, 0);

  return json_build_object('ok', true, 'id', v_id, 'ing_nom', v_nom, 'ing_ordre', v_ordre, 'date', v_t, 'statut', p_statut);
end $$;
revoke all on function calcul_valider(uuid, text, text, text, text, text, text, text, boolean) from public, anon;
grant execute on function calcul_valider(uuid, text, text, text, text, text, text, text, boolean) to authenticated;

-- ---------- 4. Journal d'un calcul (membres de l'entreprise) ----------
create or replace function calcul_journal(p_org uuid, p_projet text, p_type text)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not mfa_ok() or not exists(select 1 from membres m where m.org_id = p_org and m.user_id = auth.uid()) then
    return json_build_object('ok', false, 'refus', 'non_autorise'); end if;
  return json_build_object('ok', true, 'items', coalesce((
    select json_agg(x order by x.id desc) from (
      select id, no, indice, digest, statut, commentaire, ing_nom, ing_ordre, aal, cree_le
      from validations_calcul where org_id = p_org and projet = left(coalesce(p_projet, ''), 200) and type_calcul = left(p_type, 80)
      order by id desc limit 60) x), '[]'::json));
end $$;
revoke all on function calcul_journal(uuid, text, text) from public, anon;
grant execute on function calcul_journal(uuid, text, text) to authenticated;

-- ---------- 5. Lien QR ↔ validation, puis vérification publique ----------
-- Le QR imprimé ne porte pas l'empreinte du calcul, seulement un code court (hash de l'exemplaire imprimé).
-- À l'impression, le logiciel enregistre ici « ce code correspond à cette empreinte, ce numéro, cet indice, ce statut imprimé ».
create table if not exists validations_qr(
  id bigint generated always as identity primary key,
  org_id uuid not null,
  no text not null,
  code text not null check (length(code) between 6 and 20),
  digest text not null check (length(digest) between 6 and 64),
  indice text not null default 'A',
  statut_imprime text not null check (statut_imprime in ('emis', 'verif', 'valide', 'reserves', 'refuse')),
  user_id uuid not null,
  cree_le timestamptz not null default now(),
  unique (org_id, no, code)
);
alter table validations_qr enable row level security;
drop policy if exists valq_lire on validations_qr;
create policy valq_lire on validations_qr for select
  using (mfa_ok() and exists(select 1 from membres m where m.org_id = validations_qr.org_id and m.user_id = auth.uid()));
revoke insert, update, delete, truncate on validations_qr from anon, authenticated;
revoke all on validations_qr from anon;
drop trigger if exists validations_qr_no_upd on validations_qr;
create trigger validations_qr_no_upd before update or delete on validations_qr for each row execute function validations_calcul_fige();

create or replace function calcul_lier_qr(p_org uuid, p_no text, p_code text, p_digest text, p_indice text, p_statut text)
returns json language plpgsql security definer set search_path = public as $$
declare v_role text;
begin
  if auth.uid() is null then return json_build_object('ok', false, 'refus', 'connexion_requise'); end if;
  if not mfa_ok() then return json_build_object('ok', false, 'refus', 'mfa_requise'); end if;
  select m.role into v_role from membres m where m.org_id = p_org and m.user_id = auth.uid();
  if v_role is null then return json_build_object('ok', false, 'refus', 'non_membre'); end if;
  if v_role not in ('admin', 'editeur') then return json_build_object('ok', false, 'refus', 'ecriture_interdite'); end if;
  if not licence_ecriture_ok(p_org) then return json_build_object('ok', false, 'refus', 'licence'); end if;
  if p_statut not in ('emis', 'verif', 'valide', 'reserves', 'refuse') or length(btrim(coalesce(p_no, ''))) < 3
     or length(btrim(coalesce(p_code, ''))) < 6 or length(btrim(coalesce(p_digest, ''))) < 6 then
    return json_build_object('ok', false, 'refus', 'donnees_invalides'); end if;
  -- l'exemplaire imprimé ne peut pas prétendre à une validation que le serveur ne connaît pas pour cette empreinte
  if p_statut in ('valide', 'reserves') and not exists(
       select 1 from validations_calcul c where c.org_id = p_org and c.no = left(btrim(p_no), 60) and c.digest = left(btrim(p_digest), 64)
         and c.statut in ('valide', 'reserves') and c.id = (select max(id) from validations_calcul c2 where c2.org_id = p_org and c2.no = c.no and c2.digest = c.digest)) then
    return json_build_object('ok', false, 'refus', 'validation_serveur_absente'); end if;
  insert into validations_qr(org_id, no, code, digest, indice, statut_imprime, user_id)
  values (p_org, left(btrim(p_no), 60), left(btrim(p_code), 20), left(btrim(p_digest), 64), left(coalesce(nullif(btrim(p_indice), ''), 'A'), 10), p_statut, auth.uid())
  on conflict (org_id, no, code) do nothing;
  return json_build_object('ok', true);
end $$;
revoke all on function calcul_lier_qr(uuid, text, text, text, text, text) from public, anon;
grant execute on function calcul_lier_qr(uuid, text, text, text, text, text) to authenticated;

-- Vérification publique par le QR (n° + code) : sans contact, sans identifiant interne.
drop function if exists calcul_verifier(text, text);
create or replace function calcul_verifier(p_no text, p_code text)
returns json language plpgsql stable security definer set search_path = public as $$
declare q validations_qr; r validations_calcul; v validations_calcul;
begin
  select * into q from validations_qr where no = left(btrim(p_no), 60) and code = left(btrim(p_code), 20) order by id desc limit 1;
  if not found then return json_build_object('found', false); end if;
  select * into r from validations_calcul where org_id = q.org_id and no = q.no and digest = q.digest order by id desc limit 1;
  select * into v from validations_calcul where org_id = q.org_id and no = q.no order by id desc limit 1;
  return json_build_object('found', true,
    'statut', coalesce(r.statut, 'emis'), 'statut_imprime', q.statut_imprime, 'indice', q.indice,
    'ing_nom', coalesce(r.ing_nom, ''), 'ing_ordre', coalesce(r.ing_ordre, ''), 'commentaire', coalesce(r.commentaire, ''), 'date', r.cree_le,
    'derniere_version', (v.id is null or v.digest = q.digest),
    'version_actuelle', case when v.id is null or v.digest = q.digest then null
                             else json_build_object('indice', v.indice, 'statut', v.statut, 'date', v.cree_le) end);
end $$;
grant execute on function calcul_verifier(text, text) to anon, authenticated;
