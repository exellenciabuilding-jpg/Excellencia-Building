-- ===== Excellencia Building V99zzzzzzzzzz — TFL : signature de l'étudiant (fiche et attestation de dépôt) =====
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zzz-tfl-sans-limite.sql. Aucune nouvelle table. Réexécutable.
-- Les deux fonctions d'envoi gardent désormais la signature manuscrite (image PNG/JPEG/WebP, 150 000 caractères au plus) dans les données
-- de la candidature ; l'import côté administrateur la place dans la fiche de l'étudiant puis sur l'attestation de dépôt.
-- Sans cette migration, l'envoi en ligne continue de fonctionner (la signature est simplement ignorée) ; l'envoi par fichier la transmet déjà.

-- ---------- 1. Fiche étudiante (après le choix d'un sujet) ----------
create or replace function public.tfl_fiche_etudiant_envoyer(p_ref text, p_data jsonb, p_photo text default null, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ref text := btrim(coalesce(p_ref,''));
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_old public.tfl_candidatures%rowtype;
  v_new jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 2000 then raise exception 'trop_de_demandes'; end if;
  select * into v_old from public.tfl_candidatures
   where data->>'sujet_ref' = v_ref and data->>'telephone' = v_tel
   order by created_at desc limit 1;
  if not found then raise exception 'choix_introuvable'; end if;
  -- jeton : exigé dès que le choix en a un (les choix antérieurs à cette migration n'en ont pas et restent acceptés)
  if v_old.fiche_token_hash is not null then
    if coalesce(p_token,'') = '' then raise exception 'jeton_requis'; end if;
    if encode(sha256(convert_to(left(p_token, 200), 'UTF8')), 'hex') is distinct from v_old.fiche_token_hash then raise exception 'jeton_invalide'; end if;
  end if;
  v_new := v_old.data || jsonb_build_object(
    'nom', v_nom,
    'email', left(coalesce(p_data->>'email', v_old.data->>'email',''), 120),
    'universite', left(coalesce(nullif(p_data->>'universite',''), v_old.data->>'universite',''), 150),
    'promotion', left(coalesce(nullif(p_data->>'promotion',''), v_old.data->>'promotion',''), 60),
    'filiere', left(coalesce(nullif(p_data->>'filiere',''), v_old.data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(nullif(p_data->>'matricule_existant',''), v_old.data->>'matricule_existant',''), 40),
    'annee_academique', left(coalesce(p_data->>'annee_academique',''), 20),
    'faculte', left(coalesce(p_data->>'faculte',''), 100),
    'niveau', left(coalesce(p_data->>'niveau',''), 20),
    'date_naissance', left(coalesce(p_data->>'date_naissance',''), 20),
    'lieu_naissance', left(coalesce(p_data->>'lieu_naissance',''), 100),
    'nationalite', left(coalesce(p_data->>'nationalite',''), 60),
    'adresse', left(coalesce(p_data->>'adresse',''), 150),
    'matricule_univ', left(coalesce(p_data->>'matricule_univ',''), 40),
    'remarques', left(coalesce(p_data->>'remarques',''), 1000),
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 then (case when p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else coalesce(v_old.data->>'signature','') end) else coalesce(v_old.data->>'signature','') end,
    'recherches_deja', left(coalesce(nullif(p_data->>'recherches_deja',''), v_old.data->>'recherches_deja',''), 3000));
  if not v_old.imported then
    update public.tfl_candidatures set data = v_new, photo = coalesce(nullif(p_photo,''), photo) where id = v_old.id;
  else
    insert into public.tfl_candidatures(submitted_at, ref, data, photo, fiche_token_hash)
    values (now(), v_old.ref, v_new, coalesce(nullif(p_photo,''), v_old.photo), v_old.fiche_token_hash);
  end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) from public;
grant execute on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) to anon, authenticated;
revoke all on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) from public;

-- ---------- 2. Candidature TFL (formulaire complet) ----------
create or replace function public.tfl_candidature_envoyer(p_data jsonb, p_photo text default null, p_ref text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_titre text := left(btrim(coalesce(p_data->>'sujet_titre','')), 250);
  v_prob text := left(btrim(coalesce(p_data->>'problematique','')), 3000);
  v_obj text := left(btrim(coalesce(p_data->>'objectifs','')), 3000);
  v_clean jsonb; v_id uuid; v_k text;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if length(v_titre) < 3 or length(v_prob) < 3 or length(v_obj) < 3 then raise exception 'sujet_incomplet'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  -- limite anti-spam : 200 candidatures par heure au total, 5 par numéro de téléphone et par heure
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  -- on ne garde que les champs attendus, tronqués
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', case when p_data->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then p_data->>'domaine' else 'autre' end,
    'sujet_titre', v_titre, 'problematique', v_prob, 'objectifs', v_obj,
    'methodologie', left(coalesce(p_data->>'methodologie',''), 3000),
    'recherches_deja', left(coalesce(p_data->>'recherches_deja',''), 3000),
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 then (case when p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else '' end) else '' end);
  -- renvoi du même envoi (réseau instable) : pas de doublon
  select id into v_id from public.tfl_candidatures
   where p_submitted is not null and submitted_at = p_submitted and data->>'telephone' = v_tel limit 1;
  if v_id is null then
    insert into public.tfl_candidatures(submitted_at, ref, data, photo)
    values (p_submitted, left(coalesce(p_ref,''), 40), v_clean, nullif(p_photo,'')) returning id into v_id;
  end if;
  return jsonb_build_object('ok', true);
end $$;
grant execute on function public.tfl_candidature_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;

-- Contrôle : select proname from pg_proc where proname in ('tfl_fiche_etudiant_envoyer','tfl_candidature_envoyer');  -- 2 lignes
