-- ===== Excellencia Building — V99w : ÉQUIPE (invitations par e-mail, rôles, fonctions) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : schema-entreprise.sql, migration-v66-roles.sql et migration-v99v-securite-licences.sql déjà exécutés.
--
-- Principe (option « pré-inscription ») :
--   1. L'administrateur remplit nom, e-mail, rôle et fonction dans le panneau « 👥 Équipe » de l'application.
--   2. Si la personne a déjà un compte en ligne avec cet e-mail : elle est ajoutée tout de suite.
--   3. Sinon l'invitation est enregistrée. Dès que la personne crée son compte avec CET e-mail et se connecte
--      (ou saisit le code d'invitation), elle rejoint l'entreprise avec le bon rôle et la bonne fonction.
--   Seul un administrateur de l'entreprise peut inviter, modifier ou retirer des membres ; le dernier administrateur ne peut pas être retiré.

create table if not exists invitations_equipe(
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organisations(id) on delete cascade,
  email text not null,
  nom text,
  role text not null default 'editeur' check (role in ('admin','editeur','lecteur')),
  fonction text not null default 'polyvalent' check (fonction in
    ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','comptable','rh','magasinier')),
  cree_par uuid,
  cree_le timestamptz not null default now(),
  utilise_le timestamptz,
  unique(org_id, email));
alter table invitations_equipe enable row level security;
drop policy if exists inv_admin on invitations_equipe;
create policy inv_admin on invitations_equipe for all
  using (est_membre(org_id, array['admin'])) with check (est_membre(org_id, array['admin']));

-- Liste des membres (avec e-mail) et des invitations en attente. Réservé à l'administrateur.
create or replace function equipe_liste(p_org uuid) returns json
language plpgsql stable security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  return json_build_object(
    'membres', (select coalesce(json_agg(json_build_object('user_id',m.user_id,'nom',m.nom,'email',u.email,
                  'role',m.role,'fonction',m.fonction,'depuis',m.depuis) order by m.depuis),'[]'::json)
                from membres m left join auth.users u on u.id=m.user_id where m.org_id=p_org),
    'invitations', (select coalesce(json_agg(json_build_object('id',i.id,'email',i.email,'nom',i.nom,'role',i.role,
                  'fonction',i.fonction,'cree_le',i.cree_le) order by i.cree_le),'[]'::json)
                from invitations_equipe i where i.org_id=p_org and i.utilise_le is null));
end $$;

-- Inviter (ou mettre à jour) une personne.
create or replace function equipe_inviter(p_org uuid, p_email text, p_nom text default null,
  p_role text default 'editeur', p_fonction text default 'polyvalent') returns json
language plpgsql security definer set search_path=public as $$
declare em text := lower(trim(coalesce(p_email,''))); uid uuid; mx int; n int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if em !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'adresse e-mail invalide'; end if;
  if p_role not in ('admin','editeur','lecteur') then raise exception 'rôle invalide'; end if;
  if p_fonction not in ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','comptable','rh','magasinier') then
    raise exception 'fonction invalide'; end if;
  select id into uid from auth.users where lower(email)=em limit 1;
  -- limite d'utilisateurs de la licence (si l'entreprise a une licence suivie par le propriétaire)
  if to_regclass('public.licences_clients') is not null then
    execute 'select max_utilisateurs from licences_clients where org_id=$1 order by cree_le desc limit 1' into mx using p_org;
    if mx is not null then
      select count(*) into n from membres where org_id=p_org;
      n := n + (select count(*) from invitations_equipe where org_id=p_org and utilise_le is null and email<>em);
      if n >= mx and not exists(select 1 from membres where org_id=p_org and user_id=uid) then
        raise exception 'nombre maximal d''utilisateurs atteint (%)', mx; end if;
    end if;
  end if;
  if uid is not null then
    insert into membres(org_id,user_id,nom,role,fonction) values (p_org,uid,nullif(trim(p_nom),''),p_role,p_fonction)
      on conflict (org_id,user_id) do update set role=excluded.role, fonction=excluded.fonction,
        nom=coalesce(excluded.nom, membres.nom);
    delete from invitations_equipe where org_id=p_org and email=em;
    return json_build_object('statut','ajoute','email',em);
  end if;
  insert into invitations_equipe(org_id,email,nom,role,fonction,cree_par) values (p_org,em,nullif(trim(p_nom),''),p_role,p_fonction,auth.uid())
    on conflict (org_id,email) do update set nom=excluded.nom, role=excluded.role, fonction=excluded.fonction, utilise_le=null;
  return json_build_object('statut','invite','email',em);
end $$;

-- Changer le rôle / la fonction d'un membre (le dernier administrateur ne peut pas être rétrogradé).
create or replace function equipe_modifier(p_org uuid, p_user uuid, p_role text, p_fonction text) returns json
language plpgsql security definer set search_path=public as $$
declare cur text; admins int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if p_role not in ('admin','editeur','lecteur') then raise exception 'rôle invalide'; end if;
  if p_fonction not in ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','comptable','rh','magasinier') then
    raise exception 'fonction invalide'; end if;
  select role into cur from membres where org_id=p_org and user_id=p_user;
  if cur is null then raise exception 'membre introuvable'; end if;
  select count(*) into admins from membres where org_id=p_org and role='admin';
  if cur='admin' and p_role<>'admin' and admins<=1 then raise exception 'impossible : c''est le dernier administrateur'; end if;
  update membres set role=p_role, fonction=p_fonction where org_id=p_org and user_id=p_user;
  return json_build_object('ok',true);
end $$;

-- Retirer un membre de l'entreprise (ses comptes et ses données restent ; il n'a simplement plus accès).
create or replace function equipe_retirer(p_org uuid, p_user uuid) returns json
language plpgsql security definer set search_path=public as $$
declare cur text; admins int;
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  select role into cur from membres where org_id=p_org and user_id=p_user;
  if cur is null then raise exception 'membre introuvable'; end if;
  select count(*) into admins from membres where org_id=p_org and role='admin';
  if cur='admin' and admins<=1 then raise exception 'impossible : c''est le dernier administrateur'; end if;
  delete from membres where org_id=p_org and user_id=p_user;
  return json_build_object('ok',true);
end $$;

create or replace function equipe_annuler(p_id uuid) returns json
language plpgsql security definer set search_path=public as $$
declare o uuid;
begin
  select org_id into o from invitations_equipe where id=p_id;
  if o is null then raise exception 'invitation introuvable'; end if;
  if not est_membre(o, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  delete from invitations_equipe where id=p_id;
  return json_build_object('ok',true);
end $$;

-- Appelée automatiquement par l'application après connexion : rejoint toute entreprise qui a invité mon e-mail.
create or replace function equipe_reclamer() returns json
language plpgsql security definer set search_path=public as $$
declare em text; i record; res json := '[]'::json; n int; mx int;
begin
  if auth.uid() is null then return res; end if;
  select lower(email) into em from auth.users where id=auth.uid();
  for i in select * from invitations_equipe where email=em and utilise_le is null loop
    if to_regclass('public.licences_clients') is not null then
      execute 'select max_utilisateurs from licences_clients where org_id=$1 order by cree_le desc limit 1' into mx using i.org_id;
      select count(*) into n from membres where org_id=i.org_id;
      if mx is not null and n>=mx then continue; end if;
    end if;
    insert into membres(org_id,user_id,nom,role,fonction) values (i.org_id,auth.uid(),i.nom,i.role,i.fonction)
      on conflict (org_id,user_id) do nothing;
    update invitations_equipe set utilise_le=now() where id=i.id;
  end loop;
  return (select coalesce(json_agg(json_build_object('id',o.id,'nom',o.nom)),'[]'::json)
          from membres m join organisations o on o.id=m.org_id where m.user_id=auth.uid());
end $$;

-- Rejoindre avec le code : applique l'invitation si elle existe (rôle + fonction), respecte la licence (v99v).
create or replace function rejoindre_organisation(p_code text, p_nom_user text default null)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations; r text; f text; n int; l licences_clients; a_lic boolean; em text; inv invitations_equipe; a_inv boolean;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  select * into o from organisations where code_invitation=lower(trim(p_code));
  if not found then raise exception 'code invalide'; end if;
  select * into l from licences_clients where org_id=o.id order by cree_le desc limit 1;
  a_lic := found;
  if a_lic then
    if l.statut in ('suspendu','resilie') then raise exception 'licence suspendue : contactez l''administrateur du logiciel'; end if;
    if l.expire_le is not null and l.expire_le < now() - interval '7 days' then raise exception 'licence expirée : contactez l''administrateur du logiciel'; end if;
  end if;
  select count(*) into n from membres where org_id=o.id;
  if a_lic and n >= l.max_utilisateurs and not exists(select 1 from membres where org_id=o.id and user_id=auth.uid()) then
    raise exception 'nombre maximal d''utilisateurs atteint (%)', l.max_utilisateurs; end if;
  select lower(email) into em from auth.users where id=auth.uid();
  select * into inv from invitations_equipe where org_id=o.id and email=em and utilise_le is null;
  a_inv := found;
  insert into membres(org_id,user_id,nom,role,fonction)
    values (o.id, auth.uid(), coalesce(p_nom_user, case when a_inv then inv.nom end),
            case when n=0 then 'admin' when a_inv then inv.role else 'editeur' end,
            case when a_inv then inv.fonction else 'polyvalent' end)
    on conflict do nothing;
  if a_inv then update invitations_equipe set utilise_le=now() where id=inv.id; end if;
  select role,fonction into r,f from membres where org_id=o.id and user_id=auth.uid();
  return json_build_object('id',o.id,'nom',o.nom,'role',r,'fonction',f);
end $$;

revoke execute on function equipe_liste(uuid), equipe_inviter(uuid,text,text,text,text), equipe_modifier(uuid,uuid,text,text),
  equipe_retirer(uuid,uuid), equipe_annuler(uuid), equipe_reclamer() from public, anon;
grant execute on function equipe_liste(uuid), equipe_inviter(uuid,text,text,text,text), equipe_modifier(uuid,uuid,text,text),
  equipe_retirer(uuid,uuid), equipe_annuler(uuid), equipe_reclamer() to authenticated;
