-- ===== Excellencia Building — V99zv : suivi d'erreurs et métriques d'usage =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, APRÈS migration-v99v-securite-licences.sql (est_proprietaire) et les autres migrations.
-- Réexécutable sans danger.
--
-- CE QUE FAIT CE SCRIPT
--  1. exb_erreurs  : une ligne par erreur distincte (empreinte) et par version, avec compteur, dates, nombre d'appareils.
--  2. exb_usage    : une ligne par utilisateur et par jour (sessions, erreurs, écrans ouverts). Aucun contenu métier.
--  3. erreur_signaler(items, usage) : appelée par l'application (utilisateurs CONNECTÉS seulement) ; tailles plafonnées,
--     200 signalements par utilisateur et par heure, purge automatique après 90 jours.
--  4. owner_erreurs(jours) / owner_erreur_resoudre(empreinte, resolu) : lecture et suivi, RÉSERVÉS au propriétaire de la plateforme.
--  Les tables ne sont ni lisibles ni écrivables directement : tout passe par ces fonctions.

create table if not exists exb_erreurs(
  id bigserial primary key,
  org_id uuid,
  empreinte text not null,
  version text not null default '',
  source text not null default '',
  message text not null default '',
  pile text not null default '',
  page text not null default '',
  agent text not null default '',
  nb integer not null default 1,
  premiere_le timestamptz not null default now(),
  derniere_le timestamptz not null default now(),
  resolu boolean not null default false,
  unique(empreinte, version)
);
create index if not exists exb_erreurs_derniere on exb_erreurs(derniere_le desc);

create table if not exists exb_erreurs_appareils(
  empreinte text not null, version text not null, user_id uuid not null,
  primary key(empreinte, version, user_id)
);

create table if not exists exb_usage(
  user_id uuid not null,
  org_id uuid,
  jour date not null,
  version text not null default '',
  sessions integer not null default 0,
  erreurs integer not null default 0,
  vues jsonb not null default '{}'::jsonb,
  primary key(user_id, jour)
);

create table if not exists exb_erreurs_quota(
  user_id uuid not null, heure timestamptz not null, n integer not null default 0,
  primary key(user_id, heure)
);

alter table exb_erreurs enable row level security;
alter table exb_erreurs_appareils enable row level security;
alter table exb_usage enable row level security;
alter table exb_erreurs_quota enable row level security;
-- aucune politique : accès direct refusé à tous les rôles API ; seules les fonctions ci-dessous (security definer) y touchent.
revoke all on exb_erreurs, exb_erreurs_appareils, exb_usage, exb_erreurs_quota from anon, authenticated;

create or replace function erreur_signaler(p_items jsonb default '[]'::jsonb, p_usage jsonb default '[]'::jsonb)
returns json language plpgsql security definer set search_path=public as $$
declare
  uid uuid := auth.uid(); org uuid; it jsonb; us jsonb; h timestamptz := date_trunc('hour', now());
  q integer; nit integer := 0; emp text; ver text;
begin
  if uid is null then raise exception 'non connecté'; end if;
  if jsonb_typeof(p_items) <> 'array' then p_items := '[]'::jsonb; end if;
  if jsonb_typeof(p_usage) <> 'array' then p_usage := '[]'::jsonb; end if;

  insert into exb_erreurs_quota(user_id, heure, n) values (uid, h, 0) on conflict do nothing;
  select n into q from exb_erreurs_quota where user_id=uid and heure=h;
  if q >= 200 then return json_build_object('ok', false, 'limite', true); end if;

  begin org := (mon_organisation()->>'id')::uuid; exception when others then org := null; end;

  for it in select * from jsonb_array_elements(p_items) limit 20 loop
    emp := left(coalesce(it->>'empreinte',''), 20); ver := left(coalesce(it->>'version',''), 20);
    continue when emp = '';
    insert into exb_erreurs(org_id, empreinte, version, source, message, pile, page, agent, nb, premiere_le, derniere_le)
    values (org, emp, ver, left(coalesce(it->>'source',''), 20), left(coalesce(it->>'message',''), 300),
            left(coalesce(it->>'pile',''), 900), left(coalesce(it->>'page',''), 100), left(coalesce(it->>'agent',''), 120),
            greatest(1, least(coalesce((it->>'nb')::int, 1), 100000)), now(), now())
    on conflict (empreinte, version) do update
      set nb = exb_erreurs.nb + greatest(1, least(coalesce((it->>'nb')::int, 1), 100000)),
          derniere_le = now(), agent = excluded.agent,
          resolu = false;   -- une erreur « résolue » qui revient est rouverte
    insert into exb_erreurs_appareils(empreinte, version, user_id) values (emp, ver, uid) on conflict do nothing;
    nit := nit + 1;
  end loop;

  for us in select * from jsonb_array_elements(p_usage) limit 3 loop
    begin
      insert into exb_usage(user_id, org_id, jour, version, sessions, erreurs, vues)
      values (uid, org, (us->>'jour')::date, left(coalesce(us->>'version',''), 20),
              greatest(0, least(coalesce((us->>'sessions')::int, 0), 10000)),
              greatest(0, least(coalesce((us->>'erreurs')::int, 0), 100000)),
              case when jsonb_typeof(us->'vues') = 'object' and length((us->'vues')::text) < 4000 then us->'vues' else '{}'::jsonb end)
      on conflict (user_id, jour) do update
        set sessions = greatest(exb_usage.sessions, excluded.sessions),
            erreurs = greatest(exb_usage.erreurs, excluded.erreurs),
            vues = excluded.vues, version = excluded.version;
    exception when others then null; end;
  end loop;

  update exb_erreurs_quota set n = n + nit where user_id=uid and heure=h;
  if random() < 0.02 then   -- purge opportuniste : 90 jours pour les erreurs, 180 pour l'usage
    delete from exb_erreurs where derniere_le < now() - interval '90 days';
    delete from exb_erreurs_appareils a where not exists(select 1 from exb_erreurs e where e.empreinte=a.empreinte and e.version=a.version);
    delete from exb_usage where jour < current_date - 180;
    delete from exb_erreurs_quota where heure < now() - interval '2 days';
  end if;
  return json_build_object('ok', true, 'recu', nit);
end $$;

create or replace function owner_erreurs(p_jours integer default 14)
returns json language plpgsql security definer set search_path=public as $$
declare j integer := greatest(1, least(coalesce(p_jours,14), 90)); er json; us json;
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  select coalesce(json_agg(x order by x.derniere desc), '[]'::json) into er from (
    select e.empreinte, e.version, e.source, e.message, e.pile, e.page, e.nb, e.derniere_le as derniere, e.resolu,
           (select count(*) from exb_erreurs_appareils a where a.empreinte=e.empreinte and a.version=e.version) as appareils
    from exb_erreurs e where e.derniere_le >= now() - make_interval(days => j) order by e.derniere_le desc limit 200) x;
  select coalesce(json_agg(y order by y.jour desc), '[]'::json) into us from (
    select u.jour, count(distinct u.user_id) as appareils, sum(u.sessions) as sessions, sum(u.erreurs) as erreurs,
      (select string_agg(k || ' (' || s || ')', ', ' order by s desc) from (
         select v.key as k, sum((v.value)::int) as s
         from exb_usage u2, jsonb_each_text(u2.vues) v(key, value)
         where u2.jour = u.jour and v.value ~ '^\d+$' group by v.key order by sum((v.value)::int) desc limit 5) t) as top
    from exb_usage u where u.jour >= current_date - j group by u.jour) y;
  return json_build_object('erreurs', er, 'usage', us);
end $$;

create or replace function owner_erreur_resoudre(p_empreinte text, p_resolu boolean default true)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not est_proprietaire() then raise exception 'accès réservé au propriétaire'; end if;
  update exb_erreurs set resolu = coalesce(p_resolu, true) where empreinte = p_empreinte;
end $$;

revoke execute on function erreur_signaler(jsonb, jsonb), owner_erreurs(integer), owner_erreur_resoudre(text, boolean) from public, anon;
grant execute on function erreur_signaler(jsonb, jsonb), owner_erreurs(integer), owner_erreur_resoudre(text, boolean) to authenticated, service_role;
