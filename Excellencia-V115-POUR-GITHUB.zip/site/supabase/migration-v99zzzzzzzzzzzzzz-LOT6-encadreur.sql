-- LOT 6/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
-- 4) Formulaire ENCADREUR (public, sans compte) ----------------------------------------------------------
create or replace function public.tfl_encadreur_envoyer(p_data jsonb, p_photo text default null, p_ref text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_su jsonb := '[]'::jsonb; v_x jsonb; v_clean jsonb; v_id uuid; v_m text; v_items jsonb := '[]'::jsonb; v_i int := 0; v_doms jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_encadreurs_envois where created_at > now() - interval '1 hour') >= 60 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_encadreurs_envois where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  for v_x in select * from jsonb_array_elements(case when jsonb_typeof(p_data->'sujets') = 'array' then p_data->'sujets' else '[]'::jsonb end) loop
    exit when v_i >= 5;
    if length(btrim(coalesce(v_x->>'titre',''))) >= 3 and length(btrim(coalesce(v_x->>'problematique',''))) >= 3 and length(btrim(coalesce(v_x->>'objectifs',''))) >= 3 then
      v_su := v_su || jsonb_build_array(jsonb_build_object(
        'titre', left(btrim(v_x->>'titre'), 250), 'problematique', left(btrim(v_x->>'problematique'), 3000), 'objectifs', left(btrim(v_x->>'objectifs'), 3000),
        'methodologie', left(coalesce(v_x->>'methodologie',''), 3000), 'livrables', left(coalesce(v_x->>'livrables',''), 500),
        'domaine', case when v_x->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then v_x->>'domaine' else 'autre' end,
        'categorie', left(coalesce(v_x->>'categorie',''), 40), 'filiere', left(coalesce(v_x->>'filiere',''), 100), 'niveau', left(coalesce(v_x->>'niveau',''), 20), 'mots_cles', left(coalesce(v_x->>'mots_cles',''), 200)));
      v_i := v_i + 1;
    end if;
  end loop;
  if v_i = 0 then raise exception 'sujet_incomplet'; end if;
  v_doms := case when jsonb_typeof(p_data->'domaines') = 'array' then (select coalesce(jsonb_agg(d), '[]'::jsonb) from jsonb_array_elements_text(p_data->'domaines') d where d in ('genie_civil','architecture','gestion_travaux','autre')) else '[]'::jsonb end;
  v_clean := jsonb_build_object('nom', v_nom, 'telephone', v_tel, 'email', left(coalesce(p_data->>'email',''), 120), 'grade', left(coalesce(p_data->>'grade',''), 60),
    'institution', left(coalesce(p_data->>'institution',''), 150), 'specialites', left(coalesce(p_data->>'specialites',''), 200), 'experience', left(coalesce(p_data->>'experience',''), 60),
    'max_etudiants', least(30, greatest(1, coalesce(nullif(regexp_replace(coalesce(p_data->>'max_etudiants',''), '\D', '', 'g'), '')::int, 8))), 'domaines', v_doms, 'sujets', v_su,
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 and p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else '' end);
  select id into v_id from public.tfl_encadreurs_envois where p_submitted is not null and submitted_at = p_submitted and data->>'telephone' = v_tel limit 1;
  if v_id is null then
    insert into public.tfl_encadreurs_envois(submitted_at, ref, data, photo) values (p_submitted, left(coalesce(p_ref,''), 40), v_clean, nullif(p_photo,'')) returning id into v_id;
    for v_i in 0 .. jsonb_array_length(v_su) - 1 loop
      v_items := v_items || jsonb_build_array(jsonb_build_object('ref', 'S-' || left(v_id::text, 8) || '-' || (v_i + 1), 'titre', v_su->v_i->>'titre', 'statut', 'recu', 'label', 'Reçu — en cours d’étude', 'motif', '', 'encadreur', '', 'validation', '', 'maj', to_char(now(), 'YYYY-MM-DD')));
    end loop;
    select matricule into v_m from public.tfl_statuts where role = 'encadreur' and right(tel_norm, 6) = right(regexp_replace(v_tel, '\D', '', 'g'), 6) limit 1;
    if v_m is null then
      v_m := public.tfl_matricule_nouveau();
      insert into public.tfl_statuts(matricule, role, nom, tel_norm, items) values (v_m, 'encadreur', v_nom, regexp_replace(v_tel, '\D', '', 'g'), v_items);
    else
      update public.tfl_statuts set items = items || v_items, updated_at = now() where matricule = v_m;
    end if;
    update public.tfl_encadreurs_envois set data = data || jsonb_build_object('matricule_en_ligne', v_m) where id = v_id;
  else
    select data->>'matricule_en_ligne' into v_m from public.tfl_encadreurs_envois where id = v_id;
  end if;
  return jsonb_build_object('ok', true, 'matricule', v_m);
end $$;
revoke all on function public.tfl_encadreur_envoyer(jsonb, text, text, timestamptz) from public;
grant execute on function public.tfl_encadreur_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;

create or replace function public.tfl_encadreurs_liste() returns setof public.tfl_encadreurs_envois language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return query select * from public.tfl_encadreurs_envois where not imported order by created_at limit 200;
end $$;
revoke all on function public.tfl_encadreurs_liste() from public, anon;
grant execute on function public.tfl_encadreurs_liste() to authenticated;

create or replace function public.tfl_encadreur_traiter(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  update public.tfl_encadreurs_envois set imported = true, imported_at = now() where id = p_id;
  update public.tfl_statuts s set updated_at = now(), items = coalesce((select jsonb_agg(x) from jsonb_array_elements(s.items) x where x->>'ref' not like 'S-' || left(p_id::text, 8) || '-%'), '[]'::jsonb)
   where s.matricule = (select data->>'matricule_en_ligne' from public.tfl_encadreurs_envois where id = p_id);
end $$;
revoke all on function public.tfl_encadreur_traiter(uuid) from public, anon;
grant execute on function public.tfl_encadreur_traiter(uuid) to authenticated;
