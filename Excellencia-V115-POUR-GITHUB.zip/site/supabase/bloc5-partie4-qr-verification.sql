-- TFL bloc 5 — PARTIE 4 (QR de vérification des reçus). À exécuter APRÈS les parties 1, 2 et 3. Réexécutable.
-- Prérequis : le registre de vérification des documents (migration-v99m-verification.sql et migration-v99zzy-securite-tfl-qr.sql), déjà utilisé
-- par vos devis, factures et attestations. Si ce registre est absent, les reçus restent délivrés mais leur QR n'est pas reconnu (l'écran le signale).
-- Principe : chaque reçu CONFIRMÉ reçoit un code de vérification aléatoire (impossible à deviner) et est inscrit au registre ;
-- le QR du reçu ouvre verification.html. Si le paiement est refusé, remis en attente ou supprimé, le reçu est marqué « annulé » au registre.

alter table public.tfl_paiements add column if not exists verif_hash text;

-- Description d'un paiement : le code de vérification n'est donné que pour un paiement confirmé.
create or replace function public.tfl_paiement_json(p public.tfl_paiements) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object('id', p.id, 'source', p.source, 'dossier', p.dossier, 'montant', p.montant, 'devise', p.devise, 'mode', p.mode,
    'reference', p.reference, 'date_paiement', p.date_paiement, 'note', p.note, 'nom', p.nom_fichier, 'mime', p.mime, 'taille', p.taille,
    'parties', p.parties, 'statut', p.statut, 'montant_confirme', p.montant_confirme, 'motif', p.motif, 'recu_no', p.recu_no,
    'verif', case when p.statut = 'confirme' then p.verif_hash end, 'decide_le', p.decide_le, 'cree_le', p.cree_le)
$$;
revoke all on function public.tfl_paiement_json(public.tfl_paiements) from public, anon, authenticated;

-- Inscrit (ou met à jour) le reçu au registre de vérification. Renvoie false si le registre est indisponible (sans jamais bloquer la confirmation).
create or replace function public.tfl_recu_registre(p public.tfl_paiements) returns boolean
language plpgsql security definer set search_path = public as $$
declare v_nom text; v_mat text; v_mode text;
begin
  if p.recu_no is null or p.verif_hash is null or p.montant_confirme is null then return false; end if;
  select a.contenu->>'nom', a.contenu->>'matricule' into v_nom, v_mat from public.tfl_acces a
    where a.role = 'etudiant' and a.contenu->>'numero' = p.dossier order by a.publie_le desc limit 1;
  v_mode := case p.mode when 'banque' then 'banque' when 'mobile_money' then 'mobile money' when 'caisse' then 'caisse' else 'autre moyen' end;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail, updated_at)
  values (left(p.recu_no, 60), left(p.verif_hash, 20), 'recu', coalesce(p.decide_le::date, current_date), p.montant_confirme, left(p.devise, 8), 'valide',
          left(coalesce(v_nom, ''), 120), left(coalesce(v_mat, ''), 40), 'Reçu de paiement — frais TFL', left('Dossier ' || p.dossier || ' · ' || v_mode, 300), now())
  on conflict (no, hash) do update set status = 'valide', total = excluded.total, cur = excluded.cur, doc_date = excluded.doc_date, nom = excluded.nom,
    matricule = excluded.matricule, libelle = excluded.libelle, detail = excluded.detail, updated_at = now();
  return true;
exception when others then
  return false;
end $$;
revoke all on function public.tfl_recu_registre(public.tfl_paiements) from public, anon, authenticated;

-- Marque un reçu « annulé » au registre (tous ses codes). Sans effet si le registre est indisponible.
create or replace function public.tfl_recu_annuler(p_no text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_no is null or p_no = '' then return; end if;
  update public.exb_doc_registry set status = 'annulé', updated_at = now() where no = left(p_no, 60);
exception when others then
  null;
end $$;
revoke all on function public.tfl_recu_annuler(text) from public, anon, authenticated;

-- Décision : confirme (reçu + code de vérification + registre), refuse (motif obligatoire) ou remet en attente (le reçu est annulé au registre).
create or replace function public.tfl_paiement_admin_decider(p_id uuid, p_statut text, p_montant numeric default null, p_motif text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare d public.tfl_paiements; v_motif text := left(btrim(coalesce(p_motif,'')), 500); v_m numeric(12,2); v_reg boolean := true;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('confirme','refuse','en_attente') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_statut = 'confirme' then
    v_m := round(coalesce(p_montant, d.montant), 2);
    if v_m <= 0 or v_m > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
    update public.tfl_paiements set statut = 'confirme', montant_confirme = v_m, motif = v_motif, recu_no = coalesce(recu_no, public.tfl_recu_numero()),
      verif_hash = coalesce(verif_hash, substr(md5(random()::text || clock_timestamp()::text || id::text), 1, 10)), decide_le = now(), maj_le = now()
      where id = d.id returning * into d;
    v_reg := public.tfl_recu_registre(d);
  else
    if p_statut = 'refuse' and length(v_motif) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    perform public.tfl_recu_annuler(d.recu_no);
    if p_statut = 'refuse' then
      update public.tfl_paiements set statut = 'refuse', montant_confirme = null, motif = v_motif, recu_no = null, verif_hash = null, decide_le = now(), maj_le = now() where id = d.id;
    else
      update public.tfl_paiements set statut = 'en_attente', montant_confirme = null, motif = '', recu_no = null, verif_hash = null, decide_le = null, maj_le = now() where id = d.id;
    end if;
  end if;
  return jsonb_build_object('ok', true, 'verifiable', v_reg);
end $$;
revoke all on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) from public, anon;
grant execute on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) to authenticated;

-- Paiement reçu en caisse ou enregistré par l'administration : directement confirmé, avec son reçu et son code de vérification.
create or replace function public.tfl_paiement_admin_ajouter(p_dossier text, p_montant numeric, p_devise text, p_mode text, p_reference text, p_date date, p_note text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_m numeric(12,2); v_recu text; v_dev text := upper(left(coalesce(nullif(btrim(p_devise), ''), 'USD'), 5)); p public.tfl_paiements; v_reg boolean;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if v_d = '' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 800 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 60 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  v_m := round(p_montant, 2); v_recu := public.tfl_recu_numero();
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, statut, montant_confirme, recu_no, verif_hash, decide_le)
  values (null, v_d, 'administration', v_m, v_dev, p_mode, left(btrim(coalesce(p_reference,'')), 80), p_date, left(btrim(coalesce(p_note,'')), 500), 'confirme', v_m, v_recu,
          substr(md5(random()::text || clock_timestamp()::text || v_recu), 1, 10), now())
  returning * into p;
  v_reg := public.tfl_recu_registre(p);
  return jsonb_build_object('ok', true, 'id', p.id, 'recu_no', v_recu, 'verifiable', v_reg);
end $$;
revoke all on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) from public, anon;
grant execute on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) to authenticated;

-- Suppression : le reçu éventuel est annulé au registre.
create or replace function public.tfl_paiement_admin_supprimer(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_no text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  select recu_no into v_no from public.tfl_paiements where id = p_id;
  perform public.tfl_recu_annuler(v_no);
  delete from public.tfl_paiements where id = p_id;
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_paiement_admin_supprimer(uuid) from public, anon;
grant execute on function public.tfl_paiement_admin_supprimer(uuid) to authenticated;

-- Contrôles :
--   select column_name from information_schema.columns where table_name = 'tfl_paiements' and column_name = 'verif_hash';  → 1 ligne
--   select proname from pg_proc where proname in ('tfl_recu_registre','tfl_recu_annuler');  → 2 lignes
--   select count(*) from information_schema.tables where table_name = 'exb_doc_registry';  → 1 (sinon exécuter d'abord migration-v99m-verification.sql)
