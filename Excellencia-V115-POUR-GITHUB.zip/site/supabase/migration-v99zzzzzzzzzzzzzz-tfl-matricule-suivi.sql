-- ============================================================================
-- V99zzzzzzzzzzzzzz — TFL : matricule AUTOMATIQUE à la soumission, suivi du statut par matricule,
-- formulaire ENCADREUR (sujets proposés), validation du sujet par l'encadreur.
-- À exécuter APRÈS migration-v99zzt-tfl-portails.sql et migration-v99zzzzzzzzzz-tfl-signature.sql (tfl_admin_ok, tfl_candidatures, tfl_messages).
-- ============================================================================

-- 1) Statuts consultables par matricule (une ligne par personne) ------------------------------------------
create table if not exists public.tfl_statuts (
  matricule text primary key,
  role text not null check (role in ('etudiant','encadreur')),
  nom text not null default '',
  tel_norm text not null default '',
  items jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists tfl_statuts_tel_idx on public.tfl_statuts (role, tel_norm);
alter table public.tfl_statuts enable row level security;
revoke all on public.tfl_statuts from public, anon, authenticated;

create table if not exists public.tfl_statut_essais (id bigserial primary key, cle text not null, created_at timestamptz not null default now());
create index if not exists tfl_statut_essais_idx on public.tfl_statut_essais (cle, created_at);
alter table public.tfl_statut_essais enable row level security;
revoke all on public.tfl_statut_essais from public, anon, authenticated;

-- Formulaires d'encadreurs (même principe que tfl_candidatures)
create table if not exists public.tfl_encadreurs_envois (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  submitted_at timestamptz,
  ref text not null default '',
  data jsonb not null,
  photo text,
  imported boolean not null default false,
  imported_at timestamptz
);
alter table public.tfl_encadreurs_envois enable row level security;
revoke all on public.tfl_encadreurs_envois from public, anon, authenticated;

-- le portail accepte le type « validation » (valeur 1 = validé, 2 = à corriger, 3 = refusé)
alter table public.tfl_messages drop constraint if exists tfl_messages_type_check;
alter table public.tfl_messages add constraint tfl_messages_type_check check (type in ('message','commentaire','progression','validation'));

-- 2) Génération du matricule + enregistrement du statut « reçu » -------------------------------------------
create or replace function public.tfl_matricule_nouveau() returns text language plpgsql security definer set search_path = public as $$
declare v_n text; v_m text; i int := 0;
begin
  loop
    v_n := lpad((floor(random() * 1000000000))::bigint::text, 9, '0');
    v_m := substr(v_n,1,3) || '-' || substr(v_n,4,3) || '-' || substr(v_n,7,3);
    exit when not exists (select 1 from public.tfl_statuts where matricule = v_m);
    i := i + 1; if i > 60 then raise exception 'matricule_indisponible'; end if;
  end loop;
  return v_m;
end $$;
revoke all on function public.tfl_matricule_nouveau() from public, anon, authenticated;

-- Même personne (même rôle, mêmes 6 derniers chiffres de téléphone) = même matricule ; on ajoute seulement l'item « reçu ».
create or replace function public.tfl_statut_creer(p_role text, p_nom text, p_tel text, p_item jsonb) returns text language plpgsql security definer set search_path = public as $$
declare v_tel text := regexp_replace(coalesce(p_tel,''), '\D', '', 'g'); v_m text;
begin
  if length(v_tel) >= 6 then select matricule into v_m from public.tfl_statuts where role = p_role and right(tel_norm, 6) = right(v_tel, 6) limit 1; end if;
  if v_m is null then
    v_m := public.tfl_matricule_nouveau();
    insert into public.tfl_statuts(matricule, role, nom, tel_norm, items) values (v_m, p_role, left(coalesce(p_nom,''),120), v_tel, jsonb_build_array(p_item));
  else
    update public.tfl_statuts set items = items || jsonb_build_array(p_item), updated_at = now() where matricule = v_m;
  end if;
  return v_m;
end $$;
revoke all on function public.tfl_statut_creer(text, text, text, jsonb) from public, anon, authenticated;

-- Tout dépôt de candidature (formulaire direct, choix d'un sujet, fiche) reçoit son matricule à l'insertion.
create or replace function public.tfl_cand_matricule_trg() returns trigger language plpgsql security definer set search_path = public as $$
declare v_m text;
begin
  v_m := public.tfl_statut_creer('etudiant', NEW.data->>'nom', NEW.data->>'telephone',
    jsonb_build_object('ref', 'C-' || left(NEW.id::text, 8), 'titre', left(coalesce(NEW.data->>'sujet_titre',''), 250), 'statut', 'recu', 'label', 'Reçu — en cours d’étude', 'motif', '', 'encadreur', '', 'validation', '', 'maj', to_char(now(), 'YYYY-MM-DD')));
  NEW.data := NEW.data || jsonb_build_object('matricule_en_ligne', v_m);
  return NEW;
end $$;
drop trigger if exists tfl_cand_matricule on public.tfl_candidatures;
create trigger tfl_cand_matricule before insert on public.tfl_candidatures for each row execute function public.tfl_cand_matricule_trg();

-- 3) Candidature, fiche, traitement et portail : versions mises à jour -------------------------------------
create or replace function public.tfl_candidature_envoyer(p_data jsonb, p_photo text default null, p_ref text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_titre text := left(btrim(coalesce(p_data->>'sujet_titre','')), 250);
  v_prob text := left(btrim(coalesce(p_data->>'problematique','')), 3000);
  v_obj text := left(btrim(coalesce(p_data->>'objectifs','')), 3000);
  v_clean jsonb; v_id uuid; v_k text;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if length(v_titre) < 3 or length(v_prob) < 3 or length(v_obj) < 3 then raise exception 'sujet_incomplet'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  -- limite anti-spam : 200 candidatures par heure au total, 5 par numéro de téléphone et par heure
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  -- on ne garde que les champs attendus, tronqués
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', case when p_data->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then p_data->>'domaine' else 'autre' end,
    'sujet_titre', v_titre, 'problematique', v_prob, 'objectifs', v_obj,
    'methodologie', left(coalesce(p_data->>'methodologie',''), 3000),
    'recherches_deja', left(coalesce(p_data->>'recherches_deja',''), 3000),
    'encadreur_pressenti', left(coalesce(p_data->>'encadreur_pressenti',''), 150),
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 then (case when p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else '' end) else '' end);
  -- renvoi du même envoi (réseau instable) : pas de doublon
  select id into v_id from public.tfl_candidatures
   where p_submitted is not null and submitted_at = p_submitted and data->>'telephone' = v_tel limit 1;
  if v_id is null then
    insert into public.tfl_candidatures(submitted_at, ref, data, photo)
    values (p_submitted, left(coalesce(p_ref,''), 40), v_clean, nullif(p_photo,'')) returning id into v_id;
  end if;
  return jsonb_build_object('ok', true, 'matricule', (select data->>'matricule_en_ligne' from public.tfl_candidatures where id = v_id));
end $$;
grant execute on function public.tfl_candidature_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;

create or replace function public.tfl_fiche_etudiant_envoyer(p_ref text, p_data jsonb, p_photo text default null, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ref text := btrim(coalesce(p_ref,''));
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_old public.tfl_candidatures%rowtype;
  v_new jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 2000 then raise exception 'trop_de_demandes'; end if;
  select * into v_old from public.tfl_candidatures
   where data->>'sujet_ref' = v_ref and data->>'telephone' = v_tel
   order by created_at desc limit 1;
  if not found then raise exception 'choix_introuvable'; end if;
  -- jeton : exigé dès que le choix en a un (les choix antérieurs à cette migration n'en ont pas et restent acceptés)
  if v_old.fiche_token_hash is not null then
    if coalesce(p_token,'') = '' then raise exception 'jeton_requis'; end if;
    if encode(sha256(convert_to(left(p_token, 200), 'UTF8')), 'hex') is distinct from v_old.fiche_token_hash then raise exception 'jeton_invalide'; end if;
  end if;
  v_new := v_old.data || jsonb_build_object(
    'nom', v_nom,
    'email', left(coalesce(p_data->>'email', v_old.data->>'email',''), 120),
    'universite', left(coalesce(nullif(p_data->>'universite',''), v_old.data->>'universite',''), 150),
    'promotion', left(coalesce(nullif(p_data->>'promotion',''), v_old.data->>'promotion',''), 60),
    'filiere', left(coalesce(nullif(p_data->>'filiere',''), v_old.data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(nullif(p_data->>'matricule_existant',''), v_old.data->>'matricule_existant',''), 40),
    'annee_academique', left(coalesce(p_data->>'annee_academique',''), 20),
    'faculte', left(coalesce(p_data->>'faculte',''), 100),
    'niveau', left(coalesce(p_data->>'niveau',''), 20),
    'date_naissance', left(coalesce(p_data->>'date_naissance',''), 20),
    'lieu_naissance', left(coalesce(p_data->>'lieu_naissance',''), 100),
    'nationalite', left(coalesce(p_data->>'nationalite',''), 60),
    'adresse', left(coalesce(p_data->>'adresse',''), 150),
    'matricule_univ', left(coalesce(p_data->>'matricule_univ',''), 40),
    'remarques', left(coalesce(p_data->>'remarques',''), 1000),
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 then (case when p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else coalesce(v_old.data->>'signature','') end) else coalesce(v_old.data->>'signature','') end,
    'recherches_deja', left(coalesce(nullif(p_data->>'recherches_deja',''), v_old.data->>'recherches_deja',''), 3000));
  if not v_old.imported then
    update public.tfl_candidatures set data = v_new, photo = coalesce(nullif(p_photo,''), photo) where id = v_old.id;
  else
    insert into public.tfl_candidatures(submitted_at, ref, data, photo, fiche_token_hash)
    values (now(), v_old.ref, v_new, coalesce(nullif(p_photo,''), v_old.photo), v_old.fiche_token_hash);
  end if;
  return jsonb_build_object('ok', true, 'matricule', (select s.matricule from public.tfl_statuts s where s.role = 'etudiant' and right(s.tel_norm, 6) = right(regexp_replace(coalesce(v_new->>'telephone',''), '\D', '', 'g'), 6) limit 1));
end $$;
revoke all on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) from public;
grant execute on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) to anon, authenticated;

create or replace function public.tfl_candidature_traiter(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  update public.tfl_candidatures set imported = true, imported_at = now() where id = p_id;
  -- l'item « reçu » de ce dépôt est remplacé par le dossier réel (publié ensuite par l'administrateur)
  update public.tfl_statuts s set updated_at = now(), items = coalesce((select jsonb_agg(x) from jsonb_array_elements(s.items) x where x->>'ref' <> 'C-' || left(p_id::text, 8)), '[]'::jsonb)
   where s.matricule = (select data->>'matricule_en_ligne' from public.tfl_candidatures where id = p_id);
end $$;
revoke all on function public.tfl_candidature_traiter(uuid) from public, anon;
grant execute on function public.tfl_candidature_traiter(uuid) to authenticated;

create or replace function public.tfl_portail_envoyer(p_role text, p_ident text, p_mdp text, p_dossier text, p_type text, p_texte text, p_valeur int default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_t text := left(btrim(coalesce(p_texte,'')), 1500); v_d text := left(btrim(coalesce(p_dossier,'')), 40);
        v_type text := coalesce(nullif(p_type,''), 'message'); v_ok boolean;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if v_type not in ('message','commentaire','progression','validation') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if a.role = 'etudiant' and v_type <> 'message' then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  -- dossier : celui de l'étudiant, ou l'un des dossiers affectés à l'encadreur (selon l'instantané publié)
  if a.role = 'etudiant' then
    if v_d = '' then v_d := coalesce(a.contenu->>'numero',''); end if;
    v_ok := v_d <> '' and v_d = coalesce(a.contenu->>'numero','');
  else
    v_ok := v_d <> '' and exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = v_d);
  end if;
  if not v_ok then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if v_type = 'validation' and a.role <> 'encadreur' then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if v_type = 'validation' then
    if p_valeur is null or p_valeur < 1 or p_valeur > 3 then return jsonb_build_object('ok', false, 'code', 'valeur'); end if;
  elsif v_type = 'progression' then
    if p_valeur is null or p_valeur < 0 or p_valeur > 100 then return jsonb_build_object('ok', false, 'code', 'valeur'); end if;
  else
    if length(v_t) < 2 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  end if;
  if (select count(*) from public.tfl_messages where acces_id = a.id and cree_le > now() - interval '1 hour') >= 30 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_messages(acces_id, de, type, dossier, texte, valeur)
  values (a.id, a.role, v_type, v_d, v_t, case when v_type in ('progression','validation') then p_valeur else null end);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_portail_envoyer(text,text,text,text,text,text,int) from public;
grant execute on function public.tfl_portail_envoyer(text,text,text,text,text,text,int) to anon, authenticated;


-- 4) Formulaire ENCADREUR (public, sans compte) ----------------------------------------------------------
create or replace function public.tfl_encadreur_envoyer(p_data jsonb, p_photo text default null, p_ref text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_su jsonb := '[]'::jsonb; v_x jsonb; v_clean jsonb; v_id uuid; v_m text; v_items jsonb := '[]'::jsonb; v_i int := 0; v_doms jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_encadreurs_envois where created_at > now() - interval '1 hour') >= 60 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_encadreurs_envois where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  for v_x in select * from jsonb_array_elements(case when jsonb_typeof(p_data->'sujets') = 'array' then p_data->'sujets' else '[]'::jsonb end) loop
    exit when v_i >= 5;
    if length(btrim(coalesce(v_x->>'titre',''))) >= 3 and length(btrim(coalesce(v_x->>'problematique',''))) >= 3 and length(btrim(coalesce(v_x->>'objectifs',''))) >= 3 then
      v_su := v_su || jsonb_build_array(jsonb_build_object(
        'titre', left(btrim(v_x->>'titre'), 250), 'problematique', left(btrim(v_x->>'problematique'), 3000), 'objectifs', left(btrim(v_x->>'objectifs'), 3000),
        'methodologie', left(coalesce(v_x->>'methodologie',''), 3000), 'livrables', left(coalesce(v_x->>'livrables',''), 500),
        'domaine', case when v_x->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then v_x->>'domaine' else 'autre' end,
        'categorie', left(coalesce(v_x->>'categorie',''), 40), 'filiere', left(coalesce(v_x->>'filiere',''), 100), 'niveau', left(coalesce(v_x->>'niveau',''), 20), 'mots_cles', left(coalesce(v_x->>'mots_cles',''), 200)));
      v_i := v_i + 1;
    end if;
  end loop;
  if v_i = 0 then raise exception 'sujet_incomplet'; end if;
  v_doms := case when jsonb_typeof(p_data->'domaines') = 'array' then (select coalesce(jsonb_agg(d), '[]'::jsonb) from jsonb_array_elements_text(p_data->'domaines') d where d in ('genie_civil','architecture','gestion_travaux','autre')) else '[]'::jsonb end;
  v_clean := jsonb_build_object('nom', v_nom, 'telephone', v_tel, 'email', left(coalesce(p_data->>'email',''), 120), 'grade', left(coalesce(p_data->>'grade',''), 60),
    'institution', left(coalesce(p_data->>'institution',''), 150), 'specialites', left(coalesce(p_data->>'specialites',''), 200), 'experience', left(coalesce(p_data->>'experience',''), 60),
    'max_etudiants', least(30, greatest(1, coalesce(nullif(regexp_replace(coalesce(p_data->>'max_etudiants',''), '\D', '', 'g'), '')::int, 8))), 'domaines', v_doms, 'sujets', v_su,
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 and p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' then p_data->>'signature' else '' end);
  select id into v_id from public.tfl_encadreurs_envois where p_submitted is not null and submitted_at = p_submitted and data->>'telephone' = v_tel limit 1;
  if v_id is null then
    insert into public.tfl_encadreurs_envois(submitted_at, ref, data, photo) values (p_submitted, left(coalesce(p_ref,''), 40), v_clean, nullif(p_photo,'')) returning id into v_id;
    for v_i in 0 .. jsonb_array_length(v_su) - 1 loop
      v_items := v_items || jsonb_build_array(jsonb_build_object('ref', 'S-' || left(v_id::text, 8) || '-' || (v_i + 1), 'titre', v_su->v_i->>'titre', 'statut', 'recu', 'label', 'Reçu — en cours d’étude', 'motif', '', 'encadreur', '', 'validation', '', 'maj', to_char(now(), 'YYYY-MM-DD')));
    end loop;
    select matricule into v_m from public.tfl_statuts where role = 'encadreur' and right(tel_norm, 6) = right(regexp_replace(v_tel, '\D', '', 'g'), 6) limit 1;
    if v_m is null then
      v_m := public.tfl_matricule_nouveau();
      insert into public.tfl_statuts(matricule, role, nom, tel_norm, items) values (v_m, 'encadreur', v_nom, regexp_replace(v_tel, '\D', '', 'g'), v_items);
    else
      update public.tfl_statuts set items = items || v_items, updated_at = now() where matricule = v_m;
    end if;
    update public.tfl_encadreurs_envois set data = data || jsonb_build_object('matricule_en_ligne', v_m) where id = v_id;
  else
    select data->>'matricule_en_ligne' into v_m from public.tfl_encadreurs_envois where id = v_id;
  end if;
  return jsonb_build_object('ok', true, 'matricule', v_m);
end $$;
revoke all on function public.tfl_encadreur_envoyer(jsonb, text, text, timestamptz) from public;
grant execute on function public.tfl_encadreur_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;

create or replace function public.tfl_encadreurs_liste() returns setof public.tfl_encadreurs_envois language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return query select * from public.tfl_encadreurs_envois where not imported order by created_at limit 200;
end $$;
revoke all on function public.tfl_encadreurs_liste() from public, anon;
grant execute on function public.tfl_encadreurs_liste() to authenticated;

create or replace function public.tfl_encadreur_traiter(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  update public.tfl_encadreurs_envois set imported = true, imported_at = now() where id = p_id;
  update public.tfl_statuts s set updated_at = now(), items = coalesce((select jsonb_agg(x) from jsonb_array_elements(s.items) x where x->>'ref' not like 'S-' || left(p_id::text, 8) || '-%'), '[]'::jsonb)
   where s.matricule = (select data->>'matricule_en_ligne' from public.tfl_encadreurs_envois where id = p_id);
end $$;
revoke all on function public.tfl_encadreur_traiter(uuid) from public, anon;
grant execute on function public.tfl_encadreur_traiter(uuid) to authenticated;

-- 5) Publication des statuts par l'administrateur, consultation publique par matricule + téléphone ----------
create or replace function public.tfl_statut_publier(p_lot jsonb) returns int language plpgsql security definer set search_path = public as $$
declare x jsonb; n int := 0; v_tel text; v_mat text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if jsonb_typeof(p_lot) is distinct from 'array' then raise exception 'donnees_invalides'; end if;
  for x in select * from jsonb_array_elements(p_lot) loop
    v_mat := left(btrim(coalesce(x->>'matricule','')), 40); v_tel := regexp_replace(coalesce(x->>'tel',''), '\D', '', 'g');
    continue when v_mat = '' or x->>'role' not in ('etudiant','encadreur');
    insert into public.tfl_statuts(matricule, role, nom, tel_norm, items)
    values (v_mat, x->>'role', left(coalesce(x->>'nom',''), 120), v_tel, coalesce(x->'items','[]'::jsonb))
    on conflict (matricule) do update set role = excluded.role, nom = excluded.nom, tel_norm = case when excluded.tel_norm <> '' then excluded.tel_norm else public.tfl_statuts.tel_norm end,
      -- on garde les dépôts « reçus » pas encore traités (refs C-… / S-…), le reste est remplacé par l'état publié
      items = coalesce(excluded.items, '[]'::jsonb) || coalesce((select jsonb_agg(o) from jsonb_array_elements(public.tfl_statuts.items) o where o->>'ref' like 'C-%' or o->>'ref' like 'S-%'), '[]'::jsonb),
      updated_at = now();
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.tfl_statut_publier(jsonb) from public, anon;
grant execute on function public.tfl_statut_publier(jsonb) to authenticated;

create or replace function public.tfl_statut_consulter(p_matricule text, p_tel text) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_m text := btrim(coalesce(p_matricule,'')); v_k text; v_t text := regexp_replace(coalesce(p_tel,''), '\D', '', 'g'); s public.tfl_statuts; v_nom text;
begin
  v_k := regexp_replace(v_m, '\D', '', 'g');
  delete from public.tfl_statut_essais where created_at < now() - interval '1 day';
  if length(v_k) < 6 or length(v_t) < 6 then return jsonb_build_object('ok', false, 'code', 'saisie'); end if;
  if (select count(*) from public.tfl_statut_essais where cle = v_k and created_at > now() - interval '15 minutes') >= 8
     or (select count(*) from public.tfl_statut_essais where created_at > now() - interval '15 minutes') >= 400 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  select * into s from public.tfl_statuts where regexp_replace(matricule, '\D', '', 'g') = v_k limit 1;
  if s.matricule is null or right(s.tel_norm, 6) <> right(v_t, 6) then
    insert into public.tfl_statut_essais(cle) values (v_k);
    return jsonb_build_object('ok', false, 'code', 'introuvable');
  end if;
  v_nom := split_part(s.nom, ' ', 1) || case when position(' ' in s.nom) > 0 then ' ' || left(split_part(s.nom, ' ', 2), 1) || '.' else '' end;
  return jsonb_build_object('ok', true, 'role', s.role, 'nom', v_nom, 'matricule', s.matricule, 'items', s.items, 'maj', s.updated_at);
end $$;
revoke all on function public.tfl_statut_consulter(text, text) from public;
grant execute on function public.tfl_statut_consulter(text, text) to anon, authenticated;

-- Contrôle : select proname from pg_proc where proname in ('tfl_statut_consulter','tfl_statut_publier','tfl_encadreur_envoyer','tfl_encadreurs_liste','tfl_encadreur_traiter','tfl_matricule_nouveau'); -- 6 lignes
-- Et : select tablename, rowsecurity from pg_tables where tablename in ('tfl_statuts','tfl_statut_essais','tfl_encadreurs_envois'); -- rowsecurity = true pour les trois
