-- LOT 8/8 — demandes de modification ou de retrait d'un sujet (depuis la page de suivi). À exécuter après les lots 1 à 7.
create table if not exists public.tfl_demandes (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  matricule text not null,
  role text not null,
  nom text not null default '',
  ref text not null,
  titre text not null default '',
  type text not null check (type in ('modifier','retirer')),
  texte text not null default '',
  traitee boolean not null default false,
  traitee_le timestamptz
);
alter table public.tfl_demandes enable row level security;
revoke all on public.tfl_demandes from public, anon, authenticated;

create or replace function public.tfl_statut_demande(p_matricule text, p_tel text, p_ref text, p_type text, p_texte text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_k text := regexp_replace(coalesce(p_matricule,''), '\D', '', 'g');
  v_t text := regexp_replace(coalesce(p_tel,''), '\D', '', 'g');
  s public.tfl_statuts; v_it jsonb;
begin
  if length(v_k) < 6 or length(v_t) < 6 or p_type not in ('modifier','retirer') then return jsonb_build_object('ok', false, 'code', 'saisie'); end if;
  if (select count(*) from public.tfl_statut_essais where cle = v_k and created_at > now() - interval '15 minutes') >= 8 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  select * into s from public.tfl_statuts where regexp_replace(matricule, '\D', '', 'g') = v_k limit 1;
  if s.matricule is null or right(s.tel_norm, 6) <> right(v_t, 6) then
    insert into public.tfl_statut_essais(cle) values (v_k);
    return jsonb_build_object('ok', false, 'code', 'introuvable');
  end if;
  select x into v_it from jsonb_array_elements(s.items) x where x->>'ref' = p_ref limit 1;
  if v_it is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if (select count(*) from public.tfl_demandes where matricule = s.matricule and created_at > now() - interval '1 hour') >= 5 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_demandes(matricule, role, nom, ref, titre, type, texte)
  values (s.matricule, s.role, left(s.nom, 120), left(p_ref, 60), left(coalesce(v_it->>'titre',''), 250), p_type, left(coalesce(p_texte,''), 600));
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_statut_demande(text, text, text, text, text) from public;
grant execute on function public.tfl_statut_demande(text, text, text, text, text) to anon, authenticated;

create or replace function public.tfl_demandes_liste() returns setof public.tfl_demandes language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return query select * from public.tfl_demandes where not traitee order by created_at limit 200;
end $$;
revoke all on function public.tfl_demandes_liste() from public, anon;
grant execute on function public.tfl_demandes_liste() to authenticated;

create or replace function public.tfl_demande_traiter(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  update public.tfl_demandes set traitee = true, traitee_le = now() where id = p_id;
end $$;
revoke all on function public.tfl_demande_traiter(uuid) from public, anon;
grant execute on function public.tfl_demande_traiter(uuid) to authenticated;

-- Contrôle : select proname from pg_proc where proname in ('tfl_statut_demande','tfl_demandes_liste','tfl_demande_traiter'); -- 3 lignes
