-- ===== Excellencia Building V99zzz — TFL : aucune limite par étudiant + un sujet déjà choisi disparaît de la liste =====
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zzy-securite-tfl-qr.sql. Réexécutable. Rien n'est supprimé.
-- 1) Plus de limite par étudiant : ni plafond de sujets réservés par numéro, ni expiration des réservations,
--    ni limite par numéro / par adresse IP sur « Choisir ce sujet » et sur l'envoi de la fiche.
--    Seul un très haut plafond global (2000 demandes par heure) reste, contre une inondation automatique.
-- 2) Un sujet EXCLUSIF réservé ou attribué n'apparaît plus dans la liste publique (liste, recherche, filtres).
--    Un sujet « plusieurs étudiants possibles » reste affiché. L'administrateur peut toujours « libérer » un sujet :
--    il réapparaît aussitôt. Le jeton de la fiche étudiante (V99zzy) est conservé tel quel.
-- Non touché : les limites du registre QR (exb_doc_declare) de V99zzy.

-- ---------- Choisir ce sujet : sans limite par étudiant ----------
create or replace function public.tfl_sujet_choisir(p_ref text, p_data jsonb, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  s public.tfl_sujets%rowtype;
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_clean jsonb; v_id uuid; v_hash text; v_token text := null;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  -- aucune limite par étudiant (ni par numéro, ni par adresse IP) ; seul un très haut plafond global protège contre une inondation automatique
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 2000 then raise exception 'trop_de_demandes'; end if;
  select * into s from public.tfl_sujets where ref = btrim(coalesce(p_ref,'')) for update;
  if not found or not s.publie then raise exception 'sujet_introuvable'; end if;
  if s.statut in ('ferme','attribue') then raise exception 'sujet_indisponible'; end if;
  if s.exclusif and s.statut = 'reserve' then
    if s.reserve_tel is distinct from v_tel then raise exception 'sujet_deja_reserve'; end if;
  end if;
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere', s.data->>'filiere', ''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', coalesce(s.data->>'domaine', 'autre'),
    'sujet_ref', s.ref,
    'sujet_titre', s.data->>'titre',
    'problematique', s.data->>'problematique',
    'objectifs', s.data->>'objectifs',
    'methodologie', s.data->>'methodologie',
    'recherches_deja', left(coalesce(p_data->>'motivation',''), 3000));
  select id, fiche_token_hash into v_id, v_hash from public.tfl_candidatures
   where data->>'sujet_ref' = s.ref and data->>'telephone' = v_tel and not imported limit 1;
  if v_id is null then
    -- premier choix : le jeton n'est remis qu'ici, une seule fois (le serveur ne garde que son empreinte)
    v_token := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');
    insert into public.tfl_candidatures(submitted_at, ref, data, fiche_token_hash)
    values (p_submitted, left('SUJET-' || s.ref, 40), v_clean, encode(sha256(convert_to(v_token, 'UTF8')), 'hex')) returning id into v_id;
  end if;
  -- renvoi de la même demande : aucun nouveau jeton (sinon quelqu'un connaissant le numéro en obtiendrait un)
  if s.exclusif then
    update public.tfl_sujets set statut = 'reserve', reserve_tel = v_tel, reserve_at = coalesce(case when s.reserve_tel = v_tel then s.reserve_at end, now()), updated_at = now() where ref = s.ref;
  end if;
  return jsonb_build_object('ok', true, 'reserve', s.exclusif, 'token', v_token);
end $$;
revoke all on function public.tfl_sujet_choisir(text, jsonb, timestamptz) from public;
grant execute on function public.tfl_sujet_choisir(text, jsonb, timestamptz) to anon, authenticated;

-- ---------- Envoi de la fiche étudiante : sans limite par étudiant (jeton conservé) ----------
create or replace function public.tfl_fiche_etudiant_envoyer(p_ref text, p_data jsonb, p_photo text default null, p_token text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ref text := btrim(coalesce(p_ref,''));
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_old public.tfl_candidatures%rowtype;
  v_new jsonb;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 2000 then raise exception 'trop_de_demandes'; end if;
  select * into v_old from public.tfl_candidatures
   where data->>'sujet_ref' = v_ref and data->>'telephone' = v_tel
   order by created_at desc limit 1;
  if not found then raise exception 'choix_introuvable'; end if;
  -- jeton : exigé dès que le choix en a un (les choix antérieurs à cette migration n'en ont pas et restent acceptés)
  if v_old.fiche_token_hash is not null then
    if coalesce(p_token,'') = '' then raise exception 'jeton_requis'; end if;
    if encode(sha256(convert_to(left(p_token, 200), 'UTF8')), 'hex') is distinct from v_old.fiche_token_hash then raise exception 'jeton_invalide'; end if;
  end if;
  v_new := v_old.data || jsonb_build_object(
    'nom', v_nom,
    'email', left(coalesce(p_data->>'email', v_old.data->>'email',''), 120),
    'universite', left(coalesce(nullif(p_data->>'universite',''), v_old.data->>'universite',''), 150),
    'promotion', left(coalesce(nullif(p_data->>'promotion',''), v_old.data->>'promotion',''), 60),
    'filiere', left(coalesce(nullif(p_data->>'filiere',''), v_old.data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(nullif(p_data->>'matricule_existant',''), v_old.data->>'matricule_existant',''), 40),
    'annee_academique', left(coalesce(p_data->>'annee_academique',''), 20),
    'faculte', left(coalesce(p_data->>'faculte',''), 100),
    'niveau', left(coalesce(p_data->>'niveau',''), 20),
    'date_naissance', left(coalesce(p_data->>'date_naissance',''), 20),
    'lieu_naissance', left(coalesce(p_data->>'lieu_naissance',''), 100),
    'nationalite', left(coalesce(p_data->>'nationalite',''), 60),
    'adresse', left(coalesce(p_data->>'adresse',''), 150),
    'matricule_univ', left(coalesce(p_data->>'matricule_univ',''), 40),
    'remarques', left(coalesce(p_data->>'remarques',''), 1000),
    'recherches_deja', left(coalesce(nullif(p_data->>'recherches_deja',''), v_old.data->>'recherches_deja',''), 3000));
  if not v_old.imported then
    update public.tfl_candidatures set data = v_new, photo = coalesce(nullif(p_photo,''), photo) where id = v_old.id;
  else
    insert into public.tfl_candidatures(submitted_at, ref, data, photo, fiche_token_hash)
    values (now(), v_old.ref, v_new, coalesce(nullif(p_photo,''), v_old.photo), v_old.fiche_token_hash);
  end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) from public;
grant execute on function public.tfl_fiche_etudiant_envoyer(text, jsonb, text, text) to anon, authenticated;

-- ---------- Listes publiques : un sujet exclusif déjà choisi disparaît ----------
create or replace function public.tfl_sujets_publics()
returns table(ref text, data jsonb, exclusif boolean, statut text)
language sql security definer set search_path = public stable as $$
  select s.ref, s.data, s.exclusif, s.statut
    from public.tfl_sujets s
   where s.publie and (s.statut = 'disponible' or (not s.exclusif and s.statut = 'reserve'))
   order by s.ref
   limit 500;
$$;
revoke all on function public.tfl_sujets_publics() from public;
grant execute on function public.tfl_sujets_publics() to anon, authenticated;

create or replace function public.tfl_sujets_publics_page(
  p_q text default '', p_cat text default '', p_fil text default '', p_dispo text default '',
  p_offset int default 0, p_limit int default 30)
returns table(ref text, data jsonb, exclusif boolean, statut text, total bigint)
language sql security definer set search_path = public stable as $$
  with mots as (
    select m from unnest(regexp_split_to_array(public.tfl_norm(btrim(coalesce(p_q,''))), '\s+')) as m where m <> ''
  ), f as (
    select s.ref, s.data, s.exclusif, s.statut
      from public.tfl_sujets s
     where s.publie and (s.statut = 'disponible' or (not s.exclusif and s.statut = 'reserve'))
       and (coalesce(p_cat,'') = '' or s.data->>'categorie' = p_cat)
       and (coalesce(p_fil,'') = '' or s.data->>'filiere' = p_fil)
       and (coalesce(p_dispo,'') = ''
            or (p_dispo = 'disponible' and s.statut = 'disponible')
            or (p_dispo = 'reserve' and s.statut <> 'disponible'))
       and not exists (
         select 1 from mots
          where position(mots.m in public.tfl_norm(s.ref || ' ' || coalesce(s.data->>'titre','') || ' ' || coalesce(s.data->>'problematique','') || ' ' || coalesce(s.data->>'filiere','') || ' ' || coalesce(s.data->>'mots_cles',''))) = 0)
  )
  select f.ref, f.data, f.exclusif, f.statut, count(*) over () as total
    from f
   order by f.ref
  offset greatest(coalesce(p_offset,0), 0)
   limit least(greatest(coalesce(p_limit,30), 1), 60);
$$;
revoke all on function public.tfl_sujets_publics_page(text,text,text,text,int,int) from public;
grant execute on function public.tfl_sujets_publics_page(text,text,text,text,int,int) to anon, authenticated;

create or replace function public.tfl_sujets_facettes()
returns table(categorie text, filiere text, n bigint)
language sql security definer set search_path = public stable as $$
  select s.data->>'categorie', s.data->>'filiere', count(*)
    from public.tfl_sujets s
   where s.publie and (s.statut = 'disponible' or (not s.exclusif and s.statut = 'reserve'))
   group by 1, 2
   order by 1, 2;
$$;
revoke all on function public.tfl_sujets_facettes() from public;
grant execute on function public.tfl_sujets_facettes() to anon, authenticated;

-- Contrôle : doit renvoyer 0 ligne :
--   select proname from pg_proc where proname = 'tfl_sujet_choisir' and prosrc ilike '%_reservations%';
