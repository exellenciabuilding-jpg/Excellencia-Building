-- ===== Excellencia Building — TFL : catalogue de PLANS + esquisses des étudiants =====
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable. NON testé sur un vrai Supabase : faire un essai (plan d'essai → choisir → publier).
-- PRÉREQUIS : migration-v99zzt-tfl-portails.sql (tables/fonctions des accès étudiants) déjà exécutée.
-- PRINCIPE (même modèle que les sujets) : un plan choisi passe « reserve » et DISPARAÎT de la liste publique ; les autres restent visibles.
-- Si vous libérez le plan (refus, abandon) il redevient « disponible » et réapparaît.

create table if not exists public.tfl_plans (
  ref text primary key check (ref ~ '^[A-Za-z0-9._-]{3,40}$'),
  data jsonb not null,
  publie boolean not null default false,
  statut text not null default 'disponible' check (statut in ('disponible','reserve','attribue','ferme')),
  reserve_nom text, reserve_tel text, reserve_sujet text, reserve_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.tfl_plans enable row level security;
revoke all on public.tfl_plans from anon, authenticated;

-- Les fichiers de plans sont gardés ICI (jamais dans un dossier public du site) et ne sont rendus qu'à l'étudiant qui a réservé le plan.
create table if not exists public.tfl_plans_fichiers (
  ref text primary key references public.tfl_plans(ref) on delete cascade,
  nom text not null, mime text not null, taille int not null, b64 text not null, updated_at timestamptz not null default now()
);
alter table public.tfl_plans_fichiers enable row level security;
revoke all on public.tfl_plans_fichiers from anon, authenticated;

create table if not exists public.tfl_esquisses (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  nom text not null, telephone text not null, sujet_ref text, titre text, note text,
  fichier text,                                   -- chemin dans le bucket tfl-esquisses
  statut text not null default 'recu' check (statut in ('recu','a_corriger','valide','refuse')),
  commentaire text, updated_at timestamptz not null default now()
);
alter table public.tfl_esquisses enable row level security;
revoke all on public.tfl_esquisses from anon, authenticated;

create or replace function public.tfl_plans_admin_ok() returns boolean language sql stable security definer set search_path = public as $$
  select lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']);
$$;
revoke all on function public.tfl_plans_admin_ok() from public, anon;
grant execute on function public.tfl_plans_admin_ok() to authenticated;

-- Publication par l'administrateur. Le statut serveur n'est écrasé que si push_statut = true (comme pour les sujets).
create or replace function public.tfl_plans_publier(p_plans jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v jsonb; v_ref text; v_n int := 0; v_push boolean; v_st text; v_data jsonb;
begin
  if not public.tfl_plans_admin_ok() then raise exception 'non autorisé'; end if;
  if jsonb_typeof(p_plans) is distinct from 'array' or jsonb_array_length(p_plans) > 200 then raise exception 'donnees_invalides'; end if;
  for v in select * from jsonb_array_elements(p_plans) loop
    v_ref := btrim(coalesce(v->>'ref',''));
    if v_ref !~ '^[A-Za-z0-9._-]{3,40}$' then raise exception 'reference_invalide'; end if;
    -- Un plan ne se publie qu'avec une licence/autorisation déclarée (voir README : droits d'auteur).
    if coalesce(v->>'licence','') not in ('propre','autorise','libre') and coalesce((v->>'publie')::boolean,false) then raise exception 'licence_manquante'; end if;
    v_data := jsonb_build_object('ref', v_ref, 'titre', left(coalesce(v->>'titre',''),200), 'type', left(coalesce(v->>'type',''),60),
      'chambres', left(coalesce(v->>'chambres',''),10), 'niveaux', left(coalesce(v->>'niveaux',''),20), 'surface', left(coalesce(v->>'surface',''),30),
      'description', left(coalesce(v->>'description',''),2000),
      'apercu', case when length(coalesce(v->>'apercu','')) < 90000 and coalesce(v->>'apercu','') like 'data:image/%' then v->>'apercu' else '' end,
      'source', left(coalesce(v->>'source',''),200), 'licence', v->>'licence');
    v_push := coalesce((v->>'push_statut')::boolean,false);
    v_st := case when v->>'statut' in ('disponible','reserve','attribue','ferme') then v->>'statut' else 'disponible' end;
    insert into public.tfl_plans(ref,data,publie,statut,updated_at) values (v_ref,v_data,coalesce((v->>'publie')::boolean,false),v_st,now())
    on conflict (ref) do update set data = excluded.data, publie = excluded.publie, updated_at = now(),
      statut = case when v_push then excluded.statut else public.tfl_plans.statut end,
      reserve_nom = case when v_push and excluded.statut='disponible' then null else public.tfl_plans.reserve_nom end,
      reserve_tel = case when v_push and excluded.statut='disponible' then null else public.tfl_plans.reserve_tel end,
      reserve_sujet = case when v_push and excluded.statut='disponible' then null else public.tfl_plans.reserve_sujet end,
      reserve_at = case when v_push and excluded.statut='disponible' then null else public.tfl_plans.reserve_at end;
    v_n := v_n + 1;
  end loop;
  return jsonb_build_object('ok', true, 'n', v_n);
end $$;
revoke all on function public.tfl_plans_publier(jsonb) from public, anon;
grant execute on function public.tfl_plans_publier(jsonb) to authenticated;

-- Vue administrateur : qui a choisi quoi (nom + téléphone : réservé à l'admin).
create or replace function public.tfl_plans_etat() returns table(ref text, statut text, publie boolean, reserve_nom text, reserve_tel text, reserve_sujet text, reserve_at timestamptz)
language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_plans_admin_ok() then raise exception 'non autorisé'; end if;
  return query select p.ref,p.statut,p.publie,p.reserve_nom,p.reserve_tel,p.reserve_sujet,p.reserve_at from public.tfl_plans p order by p.ref;
end $$;
revoke all on function public.tfl_plans_etat() from public, anon;
grant execute on function public.tfl_plans_etat() to authenticated;

-- ===== ACCÈS RÉSERVÉ : matricule + mot de passe du portail étudiant (migration-v99zzt-tfl-portails.sql, À EXÉCUTER AVANT) =====
-- Personne n'a de lecture directe : le catalogue, le choix et les esquisses passent par les fonctions ci-dessous, qui vérifient
-- le matricule et le mot de passe avec tfl_acces_check (mêmes règles que le portail : mot de passe haché, 5 essais faux = blocage 15 min).
-- Un étudiant sans accès publié (dossier non accepté / sans matricule) ne voit rien. Il doit avoir changé son mot de passe de départ.
-- NB : les colonnes reserve_tel et telephone contiennent ici le MATRICULE normalisé.
drop function if exists public.tfl_plans_publics();
drop function if exists public.tfl_plan_choisir(text,text,text,text);
drop function if exists public.tfl_esquisse_deposer(text,text,text,text,text);
drop function if exists public.tfl_esquisse_fichier(uuid,text,text);
drop function if exists public.tfl_esquisse_suivi(uuid,text);

-- Catalogue : seulement les plans disponibles + le plan déjà réservé par cet étudiant.
create or replace function public.tfl_plans_publics(p_ident text, p_mdp text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  return jsonb_build_object('ok', true, 'nom', a.nom,
    'plans', coalesce((select jsonb_agg(jsonb_build_object('ref', p.ref) || p.data order by p.ref) from public.tfl_plans p where p.publie and p.statut = 'disponible'), '[]'::jsonb),
    'mon_plan', (select jsonb_build_object('ref', p.ref, 'statut', p.statut, 'a_fichier', exists(select 1 from public.tfl_plans_fichiers f where f.ref = p.ref)) || p.data from public.tfl_plans p where p.reserve_tel = a.identifiant and p.statut in ('reserve','attribue') limit 1));
end $$;
revoke all on function public.tfl_plans_publics(text,text) from public;
grant execute on function public.tfl_plans_publics(text,text) to anon, authenticated;

-- Choisir un plan : un seul plan à la fois par étudiant ; ligne verrouillée contre les choix simultanés.
create or replace function public.tfl_plan_choisir(p_ident text, p_mdp text, p_ref text, p_sujet text default null) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; s public.tfl_plans%rowtype;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  select * into s from public.tfl_plans where ref = btrim(coalesce(p_ref,'')) for update;
  if not found or not s.publie then return jsonb_build_object('ok', false, 'code', 'plan_introuvable'); end if;
  if s.statut in ('reserve','attribue') and s.reserve_tel = a.identifiant then return jsonb_build_object('ok', true, 'deja', true); end if;
  if s.statut <> 'disponible' then return jsonb_build_object('ok', false, 'code', 'plan_indisponible'); end if;
  if exists (select 1 from public.tfl_plans where reserve_tel = a.identifiant and statut in ('reserve','attribue')) then return jsonb_build_object('ok', false, 'code', 'deja_un_plan'); end if;
  update public.tfl_plans set statut='reserve', reserve_nom=a.nom, reserve_tel=a.identifiant, reserve_sujet=left(coalesce(p_sujet,''),40), reserve_at=now(), updated_at=now() where ref = s.ref;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_plan_choisir(text,text,text,text) from public;
grant execute on function public.tfl_plan_choisir(text,text,text,text) to anon, authenticated;

-- Fichier du plan : rendu seulement à l'étudiant qui a réservé CE plan (contenu en base64).
create or replace function public.tfl_plan_fichier(p_ident text, p_mdp text, p_ref text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; f public.tfl_plans_fichiers%rowtype;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if not exists (select 1 from public.tfl_plans where ref = p_ref and reserve_tel = a.identifiant and statut in ('reserve','attribue')) then return jsonb_build_object('ok', false, 'code', 'non_autorise'); end if;
  select * into f from public.tfl_plans_fichiers where ref = p_ref;
  if not found then return jsonb_build_object('ok', false, 'code', 'pas_de_fichier'); end if;
  return jsonb_build_object('ok', true, 'nom', f.nom, 'mime', f.mime, 'b64', f.b64);
end $$;
revoke all on function public.tfl_plan_fichier(text,text,text) from public;
grant execute on function public.tfl_plan_fichier(text,text,text) to anon, authenticated;

-- Dépôt du fichier d'un plan par l'administrateur (le plan doit déjà exister : synchroniser d'abord). 4 Mo de fichier au plus.
create or replace function public.tfl_plan_fichier_poser(p_ref text, p_nom text, p_mime text, p_b64 text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_plans_admin_ok() then raise exception 'non autorisé'; end if;
  if length(coalesce(p_b64,'')) > 5600000 then raise exception 'fichier_trop_lourd'; end if;
  if not exists (select 1 from public.tfl_plans where ref = p_ref) then raise exception 'plan_inconnu'; end if;
  insert into public.tfl_plans_fichiers(ref,nom,mime,taille,b64) values (p_ref, left(p_nom,120), left(coalesce(p_mime,'application/pdf'),80), length(p_b64), p_b64)
  on conflict (ref) do update set nom = excluded.nom, mime = excluded.mime, taille = excluded.taille, b64 = excluded.b64, updated_at = now();
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_plan_fichier_poser(text,text,text,text) from public, anon;
grant execute on function public.tfl_plan_fichier_poser(text,text,text,text) to authenticated;
-- Esquisses : déclaration (reçoit un identifiant), puis dépôt du fichier dans le bucket, puis rattachement.
create or replace function public.tfl_esquisse_deposer(p_ident text, p_mdp text, p_sujet text, p_titre text, p_note text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_id uuid;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if (select count(*) from public.tfl_esquisses where telephone = a.identifiant and created_at > now() - interval '1 hour') >= 10 then return jsonb_build_object('ok', false, 'code', 'trop_de_demandes'); end if;
  insert into public.tfl_esquisses(nom,telephone,sujet_ref,titre,note) values (a.nom, a.identifiant, left(coalesce(p_sujet,''),40), left(coalesce(p_titre,''),200), left(coalesce(p_note,''),2000)) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;
revoke all on function public.tfl_esquisse_deposer(text,text,text,text,text) from public;
grant execute on function public.tfl_esquisse_deposer(text,text,text,text,text) to anon, authenticated;

create or replace function public.tfl_esquisse_fichier(p_ident text, p_mdp text, p_id uuid, p_fichier text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  update public.tfl_esquisses set fichier = left(p_fichier,300), updated_at = now() where id = p_id and telephone = a.identifiant and fichier is null;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_esquisse_fichier(text,text,uuid,text) from public;
grant execute on function public.tfl_esquisse_fichier(text,text,uuid,text) to anon, authenticated;

-- Suivi : toutes SES esquisses (statut + commentaire de correction), rien d'autre.
create or replace function public.tfl_esquisse_suivi(p_ident text, p_mdp text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  return jsonb_build_object('ok', true, 'esquisses', coalesce((select jsonb_agg(jsonb_build_object('id', e.id, 'titre', e.titre, 'statut', e.statut, 'commentaire', e.commentaire, 'le', e.created_at, 'maj', e.updated_at) order by e.created_at desc)
    from public.tfl_esquisses e where e.telephone = a.identifiant), '[]'::jsonb));
end $$;
revoke all on function public.tfl_esquisse_suivi(text,text) from public;
grant execute on function public.tfl_esquisse_suivi(text,text) to anon, authenticated;

create or replace function public.tfl_esquisses_liste() returns setof public.tfl_esquisses
language plpgsql security definer set search_path = public stable as $$
begin if not public.tfl_plans_admin_ok() then raise exception 'non autorisé'; end if;
  return query select * from public.tfl_esquisses order by created_at desc limit 500; end $$;
revoke all on function public.tfl_esquisses_liste() from public, anon;
grant execute on function public.tfl_esquisses_liste() to authenticated;

create or replace function public.tfl_esquisse_decider(p_id uuid, p_statut text, p_commentaire text) returns void
language plpgsql security definer set search_path = public as $$
begin if not public.tfl_plans_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('recu','a_corriger','valide','refuse') then raise exception 'statut_invalide'; end if;
  update public.tfl_esquisses set statut = p_statut, commentaire = left(coalesce(p_commentaire,''),3000), updated_at = now() where id = p_id; end $$;
revoke all on function public.tfl_esquisse_decider(uuid,text,text) from public, anon;
grant execute on function public.tfl_esquisse_decider(uuid,text,text) to authenticated;

-- ---------- Stockage des fichiers d'esquisse (bucket privé) ----------
insert into storage.buckets (id, name, public, file_size_limit) values ('tfl-esquisses','tfl-esquisses', false, 10485760) on conflict (id) do nothing;
create or replace function public.tfl_esquisse_existe(p_id text) returns boolean language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.tfl_esquisses where id::text = p_id and created_at > now() - interval '1 hour' and fichier is null);
$$;
revoke all on function public.tfl_esquisse_existe(text) from public;
grant execute on function public.tfl_esquisse_existe(text) to anon, authenticated;
drop policy if exists tfl_esq_depot on storage.objects;
create policy tfl_esq_depot on storage.objects for insert to anon, authenticated
  with check (bucket_id = 'tfl-esquisses' and public.tfl_esquisse_existe((storage.foldername(name))[1]));
drop policy if exists tfl_esq_lecture_admin on storage.objects;
create policy tfl_esq_lecture_admin on storage.objects for select to authenticated
  using (bucket_id = 'tfl-esquisses' and public.tfl_plans_admin_ok());

-- Contrôle : select proname from pg_proc where proname like 'tfl_plan%' or proname like 'tfl_esquisse%';  (≈ 13 lignes)
