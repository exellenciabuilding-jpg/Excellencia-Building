-- TFL bloc 5 — PARTIE 1 sur 3 (tables + déclaration d'un paiement). À exécuter EN PREMIER, puis les parties 2 et 3, dans l'ordre. Réexécutable.

-- Excellencia Building — TFL bloc 5/5 : FRAIS TFL et BORDEREAUX DE PAIEMENT.
-- À exécuter UNE fois (Supabase : SQL Editor : New query : coller : Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzt-tfl-portails.sql (accès étudiants / encadreurs, tfl_acces_check, tfl_admin_ok).
-- Les blocs 1 à 4 ne sont pas nécessaires à celui-ci.
--
-- Principe :
--   · Le MONTANT À PAYER et la devise viennent de l'administration : ils sont publiés dans le dossier de l'étudiant (contenu->'frais').
--     Le serveur ne fait jamais confiance à la devise envoyée par le navigateur.
--   · Étudiant (dossier ACCEPTÉ) : déclare un paiement (montant, mode, référence, date) et joint son bordereau ou la capture du paiement
--     (PDF, JPG ou PNG, 5 Mo au plus, envoi par morceaux de 900 Ko). Il suit l'état : En attente de vérification, Confirmé (reçu n°…), Refusé (motif).
--   · Administration (e-mail administrateur) : télécharge le bordereau, CONFIRME (montant réellement reçu) ou REFUSE (motif obligatoire),
--     enregistre un paiement reçu en caisse, supprime. Le numéro de reçu est donné par le serveur à la confirmation.
--   · L'encadreur n'a AUCUN accès aux paiements.
-- Limites : 10 déclarations par heure et par accès, 30 paiements par dossier, 50 Mo de bordereaux par accès.
-- Les paiements ne sont jamais supprimés avec l'accès de l'étudiant (historique financier conservé).
-- Mot de passe vérifié à chaque appel (5 essais ratés = blocage).

create sequence if not exists public.tfl_recu_seq;

create table if not exists public.tfl_paiements (
  id uuid primary key default gen_random_uuid(),
  acces_id uuid references public.tfl_acces(id) on delete set null,
  dossier text not null,
  source text not null default 'etudiant' check (source in ('etudiant','administration')),
  montant numeric(12,2) not null check (montant > 0 and montant <= 1000000),
  devise text not null default 'USD',
  mode text not null check (mode in ('banque','mobile_money','caisse','autre')),
  reference text not null default '',
  date_paiement date not null,
  note text not null default '',
  nom_fichier text not null default '',
  mime text not null default '',
  taille bigint not null default 0,
  parties int not null default 0,
  statut text not null default 'envoi' check (statut in ('envoi','en_attente','confirme','refuse')),
  montant_confirme numeric(12,2),
  motif text not null default '',
  recu_no text,
  decide_le timestamptz,
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now()
);
create index if not exists tfl_paiements_dossier_idx on public.tfl_paiements (dossier, cree_le);
create index if not exists tfl_paiements_acces_idx on public.tfl_paiements (acces_id, cree_le);
create unique index if not exists tfl_paiements_recu_idx on public.tfl_paiements (recu_no) where recu_no is not null;
alter table public.tfl_paiements enable row level security;
revoke all on public.tfl_paiements from anon, authenticated;

create table if not exists public.tfl_paiements_parties (
  paiement_id uuid not null references public.tfl_paiements(id) on delete cascade,
  idx int not null,
  b64 text not null,
  primary key (paiement_id, idx)
);
alter table public.tfl_paiements_parties enable row level security;
revoke all on public.tfl_paiements_parties from anon, authenticated;

-- Description d'un paiement (sans le fichier).
create or replace function public.tfl_paiement_json(p public.tfl_paiements) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object('id', p.id, 'source', p.source, 'dossier', p.dossier, 'montant', p.montant, 'devise', p.devise, 'mode', p.mode,
    'reference', p.reference, 'date_paiement', p.date_paiement, 'note', p.note, 'nom', p.nom_fichier, 'mime', p.mime, 'taille', p.taille,
    'parties', p.parties, 'statut', p.statut, 'montant_confirme', p.montant_confirme, 'motif', p.motif, 'recu_no', p.recu_no,
    'decide_le', p.decide_le, 'cree_le', p.cree_le)
$$;
revoke all on function public.tfl_paiement_json(public.tfl_paiements) from public, anon, authenticated;

-- Numéro de reçu unique : REC-TFL-AAAA-00001.
create or replace function public.tfl_recu_numero() returns text
language sql volatile set search_path = public as $$
  select 'REC-TFL-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.tfl_recu_seq')::text, 5, '0')
$$;
revoke all on function public.tfl_recu_numero() from public, anon, authenticated;

-- 1) Déclaration d'un paiement (renvoie son identifiant ; le bordereau suit par morceaux).
create or replace function public.tfl_paiement_creer(p_ident text, p_mdp text, p_montant numeric, p_mode text, p_reference text, p_date date, p_note text,
  p_nom text, p_mime text, p_taille bigint, p_parties int)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text; v_dev text; v_ref text := left(btrim(coalesce(p_reference,'')), 80); v_nom text; v_ext text; v_id uuid; v_m numeric(12,2);
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  v_d := coalesce(a.contenu->>'numero','');
  if v_d = '' or coalesce(a.contenu->>'statut','') <> 'accepte' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if a.contenu->'frais' is null or (coalesce((a.contenu->'frais'->>'montant')::numeric, 0) <= 0 and coalesce(a.contenu->'frais'->>'exonere','') <> 'true') then
    return jsonb_build_object('ok', false, 'code', 'sans_frais');
  end if;
  if coalesce(a.contenu->'frais'->>'exonere','') = 'true' then return jsonb_build_object('ok', false, 'code', 'exonere'); end if;
  v_dev := upper(left(coalesce(nullif(btrim(a.contenu->'frais'->>'devise'), ''), 'USD'), 5));
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  v_m := round(p_montant, 2);
  if length(v_ref) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 400 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  v_nom := left(regexp_replace(btrim(coalesce(p_nom,'')), '[\\/:*?"<>|[:cntrl:]]', '_', 'g'), 120);
  v_ext := lower(substring(v_nom from '\.([A-Za-z0-9]+)$'));
  if v_ext is null or v_ext not in ('pdf','jpg','jpeg','png') then return jsonb_build_object('ok', false, 'code', 'format'); end if;
  if coalesce(p_taille,0) < 1 then return jsonb_build_object('ok', false, 'code', 'fichier_vide'); end if;
  if p_taille > 5000000 then return jsonb_build_object('ok', false, 'code', 'trop_lourd'); end if;
  if p_parties is distinct from ceil(p_taille / 900000.0)::int then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  delete from public.tfl_paiements where acces_id = a.id and statut = 'envoi' and cree_le < now() - interval '2 hours';   -- envois abandonnés
  if (select count(*) from public.tfl_paiements where acces_id = a.id and cree_le > now() - interval '1 hour') >= 10 then return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 30 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  if coalesce((select sum(taille) from public.tfl_paiements where acces_id = a.id), 0) + p_taille > 50000000 then return jsonb_build_object('ok', false, 'code', 'espace'); end if;
  if exists (select 1 from public.tfl_paiements where dossier = v_d and statut in ('en_attente','confirme') and lower(reference) = lower(v_ref) and montant = v_m) then
    return jsonb_build_object('ok', false, 'code', 'doublon');
  end if;
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, nom_fichier, mime, taille, parties)
  values (a.id, v_d, 'etudiant', v_m, v_dev, p_mode, v_ref, p_date, left(btrim(coalesce(p_note,'')), 500), v_nom,
          case v_ext when 'pdf' then 'application/pdf' when 'png' then 'image/png' else 'image/jpeg' end, p_taille, p_parties) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;
revoke all on function public.tfl_paiement_creer(text,text,numeric,text,text,date,text,text,text,bigint,int) from public;
grant execute on function public.tfl_paiement_creer(text,text,numeric,text,text,date,text,text,text,bigint,int) to anon, authenticated;
