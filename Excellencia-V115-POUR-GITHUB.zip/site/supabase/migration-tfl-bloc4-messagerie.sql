-- Excellencia Building — TFL bloc 4/5 : MESSAGERIE DIRECTE étudiant ↔ encadreur.
-- À exécuter UNE fois (Supabase : SQL Editor : New query : coller : Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzt-tfl-portails.sql (accès étudiants / encadreurs, tfl_acces_check, tfl_admin_ok).
-- Les blocs 1, 2 et 3 ne sont pas nécessaires à celui-ci.
--
-- Principe : un fil de discussion par dossier entre l'étudiant et SON encadreur.
--   · Étudiant (dossier ACCEPTÉ, encadreur affecté) : écrit à son encadreur et lit ses réponses (dossier clos : lecture seule).
--   · Encadreur : écrit aux étudiants de son instantané publié et ne lit que SES échanges (si un autre encadreur reprend
--     le dossier, il ne voit pas l'historique de son prédécesseur ; l'étudiant, lui, garde tout son fil).
--   · Administration : peut consulter et supprimer un message (litige, abus) ; l'étudiant en est averti à l'écran.
-- Limites : 2 000 caractères par message, 60 messages par heure et par accès, 1 000 messages par fil.
-- Mot de passe vérifié à chaque appel (5 essais ratés = blocage).

create table if not exists public.tfl_echanges (
  id uuid primary key default gen_random_uuid(),
  dossier text not null,
  encadreur_id uuid not null references public.tfl_acces(id) on delete cascade,
  auteur_id uuid not null references public.tfl_acces(id) on delete cascade,
  de text not null check (de in ('etudiant','encadreur')),
  texte text not null check (length(texte) between 1 and 2000),
  cree_le timestamptz not null default now(),
  lu_le timestamptz
);
create index if not exists tfl_echanges_dossier_idx on public.tfl_echanges (dossier, cree_le);
create index if not exists tfl_echanges_enc_idx on public.tfl_echanges (encadreur_id, dossier, cree_le);
alter table public.tfl_echanges enable row level security;
revoke all on public.tfl_echanges from anon, authenticated;

-- 1) Envoi d'un message.
create or replace function public.tfl_echange_envoyer(p_role text, p_ident text, p_mdp text, p_dossier text, p_texte text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_t text := left(btrim(coalesce(p_texte,'')), 2000);
        v_enc uuid; v_id uuid;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if v_t = '' then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  if a.role = 'etudiant' then
    if v_d = '' then v_d := coalesce(a.contenu->>'numero',''); end if;
    if v_d = '' or v_d <> coalesce(a.contenu->>'numero','') or coalesce(a.contenu->>'statut','') <> 'accepte' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
    if coalesce(a.contenu->'encadreur'->>'nom','') = '' then return jsonb_build_object('ok', false, 'code', 'sans_encadreur'); end if;
    select e.id into v_enc from public.tfl_acces e
      where e.role = 'encadreur' and e.actif and e.contenu->'dossiers' @> jsonb_build_array(jsonb_build_object('numero', v_d))
      order by e.publie_le desc limit 1;
    if v_enc is null then return jsonb_build_object('ok', false, 'code', 'sans_encadreur'); end if;
  else
    if v_d = '' or not exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = v_d) then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
    v_enc := a.id;
  end if;
  if (select count(*) from public.tfl_echanges where auteur_id = a.id and cree_le > now() - interval '1 hour') >= 60 then return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  if (select count(*) from public.tfl_echanges where dossier = v_d and encadreur_id = v_enc) >= 1000 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  insert into public.tfl_echanges(dossier, encadreur_id, auteur_id, de, texte) values (v_d, v_enc, a.id, a.role, v_t) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;
revoke all on function public.tfl_echange_envoyer(text,text,text,text,text) from public;
grant execute on function public.tfl_echange_envoyer(text,text,text,text,text) to anon, authenticated;

-- 2) Liste : sans p_dossier = seulement les compteurs de messages non lus ; avec p_dossier = le fil (et il est marqué lu).
create or replace function public.tfl_echange_liste(p_role text, p_ident text, p_mdp text, p_dossier text default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_num text; v_m jsonb := null; v_nl jsonb;
begin
  if p_role not in ('etudiant','encadreur') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  v_num := coalesce(a.contenu->>'numero','');
  if v_d <> '' then
    if a.role = 'etudiant' then
      if v_d <> v_num then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
      update public.tfl_echanges set lu_le = now() where dossier = v_num and de = 'encadreur' and lu_le is null;
      select coalesce(jsonb_agg(jsonb_build_object('id', t.id, 'de', t.de, 'texte', t.texte, 'cree_le', t.cree_le, 'lu', t.lu_le is not null, 'mien', t.auteur_id = a.id) order by t.cree_le), '[]'::jsonb)
        into v_m from (select * from public.tfl_echanges where dossier = v_num order by cree_le desc limit 300) t;
    else
      if not exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = v_d) then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
      update public.tfl_echanges set lu_le = now() where encadreur_id = a.id and dossier = v_d and de = 'etudiant' and lu_le is null;
      select coalesce(jsonb_agg(jsonb_build_object('id', t.id, 'de', t.de, 'texte', t.texte, 'cree_le', t.cree_le, 'lu', t.lu_le is not null, 'mien', t.auteur_id = a.id) order by t.cree_le), '[]'::jsonb)
        into v_m from (select * from public.tfl_echanges where encadreur_id = a.id and dossier = v_d order by cree_le desc limit 300) t;
    end if;
  end if;
  if a.role = 'etudiant' then
    select coalesce(jsonb_object_agg(t.dossier, t.n), '{}'::jsonb) into v_nl
      from (select dossier, count(*) as n from public.tfl_echanges where dossier = v_num and de = 'encadreur' and lu_le is null group by dossier) t;
  else
    select coalesce(jsonb_object_agg(t.dossier, t.n), '{}'::jsonb) into v_nl
      from (select dossier, count(*) as n from public.tfl_echanges where encadreur_id = a.id and de = 'etudiant' and lu_le is null group by dossier) t;
  end if;
  return jsonb_build_object('ok', true, 'non_lus', v_nl, 'messages', v_m);
end $$;
revoke all on function public.tfl_echange_liste(text,text,text,text) from public;
grant execute on function public.tfl_echange_liste(text,text,text,text) to anon, authenticated;

-- ---------- Administration (e-mail administrateur connecté) ----------
create or replace function public.tfl_echanges_admin_liste(p_dossier text)
returns jsonb language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'de', m.de, 'auteur', a.nom, 'encadreur', e.nom, 'dossier', m.dossier, 'texte', m.texte, 'cree_le', m.cree_le, 'lu', m.lu_le is not null) order by m.cree_le)
    from (select * from public.tfl_echanges x where x.dossier = p_dossier order by x.cree_le desc limit 500) m
    join public.tfl_acces a on a.id = m.auteur_id
    join public.tfl_acces e on e.id = m.encadreur_id), '[]'::jsonb);
end $$;
revoke all on function public.tfl_echanges_admin_liste(text) from public, anon;
grant execute on function public.tfl_echanges_admin_liste(text) to authenticated;

create or replace function public.tfl_echange_admin_supprimer(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  delete from public.tfl_echanges where id = p_id;
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_echange_admin_supprimer(uuid) from public, anon;
grant execute on function public.tfl_echange_admin_supprimer(uuid) to authenticated;

-- Contrôle : select proname from pg_proc where proname like 'tfl_echange%';  → 4 lignes
--   (tfl_echange_envoyer, tfl_echange_liste, tfl_echanges_admin_liste, tfl_echange_admin_supprimer)
-- Et : select tablename, rowsecurity from pg_tables where tablename = 'tfl_echanges';  → rowsecurity = true
