-- Excellencia Building V99l — Registre des documents émis (vérification du QR code), FACULTATIF.
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger.
-- Remplacez les e-mails administrateur si besoin (en minuscules).
-- Principe : seul l'administrateur connecté publie ; n'importe qui peut seulement demander « ce numéro + ce code existent-ils ? »
-- (réponse oui/non + statut), sans jamais lire le contenu des documents.

create table if not exists public.exb_doc_registry (
  no text not null,
  hash text not null,
  kind text not null check (kind in ('devis','facture','recu')),
  doc_date date,
  total numeric(14,2),
  cur text,
  status text not null default '',
  updated_at timestamptz not null default now(),
  primary key (no, hash)
);
alter table public.exb_doc_registry enable row level security;
-- aucune politique : la table n'est accessible que par les deux fonctions ci-dessous.

create or replace function public.exb_doc_publish(p_no text, p_kind text, p_hash text, p_date date, p_total numeric, p_cur text, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, updated_at)
  values (left(p_no,60), left(p_hash,20), p_kind, p_date, p_total, left(coalesce(p_cur,''),8), left(coalesce(p_status,''),20), now())
  on conflict (no, hash) do update set status = excluded.status, total = excluded.total, cur = excluded.cur, doc_date = excluded.doc_date, updated_at = now();
  -- un changement de statut (ex. annulé) s'applique à toutes les versions du même numéro
  if p_status = 'annulé' then update public.exb_doc_registry set status = 'annulé', updated_at = now() where no = left(p_no,60); end if;
end $$;
revoke all on function public.exb_doc_publish(text,text,text,date,numeric,text,text) from public, anon;
grant execute on function public.exb_doc_publish(text,text,text,date,numeric,text,text) to authenticated;

create or replace function public.exb_doc_verify(p_no text, p_hash text)
returns jsonb language sql security definer set search_path = public stable as $$
  select coalesce((select jsonb_build_object('found', true, 'status', status) from public.exb_doc_registry where no = left(p_no,60) and hash = left(p_hash,20)), jsonb_build_object('found', false));
$$;
grant execute on function public.exb_doc_verify(text,text) to anon, authenticated;
