-- Excellencia Building — TFL bloc 5/5 : FRAIS TFL et BORDEREAUX DE PAIEMENT.
-- À exécuter UNE fois (Supabase : SQL Editor : New query : coller : Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzt-tfl-portails.sql (accès étudiants / encadreurs, tfl_acces_check, tfl_admin_ok).
-- Les blocs 1 à 4 ne sont pas nécessaires à celui-ci.
--
-- Principe :
--   · Le MONTANT À PAYER et la devise viennent de l'administration : ils sont publiés dans le dossier de l'étudiant (contenu->'frais').
--     Le serveur ne fait jamais confiance à la devise envoyée par le navigateur.
--   · Étudiant (dossier ACCEPTÉ) : déclare un paiement (montant, mode, référence, date) et joint son bordereau ou la capture du paiement
--     (PDF, JPG ou PNG, 5 Mo au plus, envoi par morceaux de 900 Ko). Il suit l'état : En attente de vérification, Confirmé (reçu n°…), Refusé (motif).
--   · Administration (e-mail administrateur) : télécharge le bordereau, CONFIRME (montant réellement reçu) ou REFUSE (motif obligatoire),
--     enregistre un paiement reçu en caisse, supprime. Le numéro de reçu est donné par le serveur à la confirmation.
--   · L'encadreur n'a AUCUN accès aux paiements.
-- Limites : 10 déclarations par heure et par accès, 30 paiements par dossier, 50 Mo de bordereaux par accès.
-- Les paiements ne sont jamais supprimés avec l'accès de l'étudiant (historique financier conservé).
-- Mot de passe vérifié à chaque appel (5 essais ratés = blocage).

create sequence if not exists public.tfl_recu_seq;

create table if not exists public.tfl_paiements (
  id uuid primary key default gen_random_uuid(),
  acces_id uuid references public.tfl_acces(id) on delete set null,
  dossier text not null,
  source text not null default 'etudiant' check (source in ('etudiant','administration')),
  montant numeric(12,2) not null check (montant > 0 and montant <= 1000000),
  devise text not null default 'USD',
  mode text not null check (mode in ('banque','mobile_money','caisse','autre')),
  reference text not null default '',
  date_paiement date not null,
  note text not null default '',
  nom_fichier text not null default '',
  mime text not null default '',
  taille bigint not null default 0,
  parties int not null default 0,
  statut text not null default 'envoi' check (statut in ('envoi','en_attente','confirme','refuse')),
  montant_confirme numeric(12,2),
  motif text not null default '',
  recu_no text,
  decide_le timestamptz,
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now()
);
create index if not exists tfl_paiements_dossier_idx on public.tfl_paiements (dossier, cree_le);
create index if not exists tfl_paiements_acces_idx on public.tfl_paiements (acces_id, cree_le);
create unique index if not exists tfl_paiements_recu_idx on public.tfl_paiements (recu_no) where recu_no is not null;
alter table public.tfl_paiements enable row level security;
revoke all on public.tfl_paiements from anon, authenticated;

create table if not exists public.tfl_paiements_parties (
  paiement_id uuid not null references public.tfl_paiements(id) on delete cascade,
  idx int not null,
  b64 text not null,
  primary key (paiement_id, idx)
);
alter table public.tfl_paiements_parties enable row level security;
revoke all on public.tfl_paiements_parties from anon, authenticated;

-- Description d'un paiement (sans le fichier).
create or replace function public.tfl_paiement_json(p public.tfl_paiements) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object('id', p.id, 'source', p.source, 'dossier', p.dossier, 'montant', p.montant, 'devise', p.devise, 'mode', p.mode,
    'reference', p.reference, 'date_paiement', p.date_paiement, 'note', p.note, 'nom', p.nom_fichier, 'mime', p.mime, 'taille', p.taille,
    'parties', p.parties, 'statut', p.statut, 'montant_confirme', p.montant_confirme, 'motif', p.motif, 'recu_no', p.recu_no,
    'decide_le', p.decide_le, 'cree_le', p.cree_le)
$$;
revoke all on function public.tfl_paiement_json(public.tfl_paiements) from public, anon, authenticated;

-- Numéro de reçu unique : REC-TFL-AAAA-00001.
create or replace function public.tfl_recu_numero() returns text
language sql volatile set search_path = public as $$
  select 'REC-TFL-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.tfl_recu_seq')::text, 5, '0')
$$;
revoke all on function public.tfl_recu_numero() from public, anon, authenticated;

-- 1) Déclaration d'un paiement (renvoie son identifiant ; le bordereau suit par morceaux).
create or replace function public.tfl_paiement_creer(p_ident text, p_mdp text, p_montant numeric, p_mode text, p_reference text, p_date date, p_note text,
  p_nom text, p_mime text, p_taille bigint, p_parties int)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text; v_dev text; v_ref text := left(btrim(coalesce(p_reference,'')), 80); v_nom text; v_ext text; v_id uuid; v_m numeric(12,2);
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  v_d := coalesce(a.contenu->>'numero','');
  if v_d = '' or coalesce(a.contenu->>'statut','') <> 'accepte' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if a.contenu->'frais' is null or (coalesce((a.contenu->'frais'->>'montant')::numeric, 0) <= 0 and coalesce(a.contenu->'frais'->>'exonere','') <> 'true') then
    return jsonb_build_object('ok', false, 'code', 'sans_frais');
  end if;
  if coalesce(a.contenu->'frais'->>'exonere','') = 'true' then return jsonb_build_object('ok', false, 'code', 'exonere'); end if;
  v_dev := upper(left(coalesce(nullif(btrim(a.contenu->'frais'->>'devise'), ''), 'USD'), 5));
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  v_m := round(p_montant, 2);
  if length(v_ref) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 400 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  v_nom := left(regexp_replace(btrim(coalesce(p_nom,'')), '[\\/:*?"<>|[:cntrl:]]', '_', 'g'), 120);
  v_ext := lower(substring(v_nom from '\.([A-Za-z0-9]+)$'));
  if v_ext is null or v_ext not in ('pdf','jpg','jpeg','png') then return jsonb_build_object('ok', false, 'code', 'format'); end if;
  if coalesce(p_taille,0) < 1 then return jsonb_build_object('ok', false, 'code', 'fichier_vide'); end if;
  if p_taille > 5000000 then return jsonb_build_object('ok', false, 'code', 'trop_lourd'); end if;
  if p_parties is distinct from ceil(p_taille / 900000.0)::int then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  delete from public.tfl_paiements where acces_id = a.id and statut = 'envoi' and cree_le < now() - interval '2 hours';   -- envois abandonnés
  if (select count(*) from public.tfl_paiements where acces_id = a.id and cree_le > now() - interval '1 hour') >= 10 then return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 30 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  if coalesce((select sum(taille) from public.tfl_paiements where acces_id = a.id), 0) + p_taille > 50000000 then return jsonb_build_object('ok', false, 'code', 'espace'); end if;
  if exists (select 1 from public.tfl_paiements where dossier = v_d and statut in ('en_attente','confirme') and lower(reference) = lower(v_ref) and montant = v_m) then
    return jsonb_build_object('ok', false, 'code', 'doublon');
  end if;
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, nom_fichier, mime, taille, parties)
  values (a.id, v_d, 'etudiant', v_m, v_dev, p_mode, v_ref, p_date, left(btrim(coalesce(p_note,'')), 500), v_nom,
          case v_ext when 'pdf' then 'application/pdf' when 'png' then 'image/png' else 'image/jpeg' end, p_taille, p_parties) returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;
revoke all on function public.tfl_paiement_creer(text,text,numeric,text,text,date,text,text,text,bigint,int) from public;
grant execute on function public.tfl_paiement_creer(text,text,numeric,text,text,date,text,text,text,bigint,int) to anon, authenticated;

-- 2) Envoi d'un morceau du bordereau (0, 1, 2…) : 1 200 000 caractères base64 (900 Ko) sauf le dernier.
create or replace function public.tfl_paiement_partie(p_ident text, p_mdp text, p_id uuid, p_idx int, p_b64 text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; d public.tfl_paiements; v_ext text; v_h bytea;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into d from public.tfl_paiements where id = p_id and acces_id = c.v_id and statut = 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  if coalesce(p_b64,'') !~ '^[A-Za-z0-9+/]+={0,2}$' or length(p_b64) % 4 <> 0 or length(p_b64) > 1200000 or (p_idx < d.parties - 1 and length(p_b64) <> 1200000) then
    return jsonb_build_object('ok', false, 'code', 'invalide');
  end if;
  if p_idx = 0 then   -- signature du fichier : l'extension annoncée doit correspondre au contenu
    v_ext := lower(substring(d.nom_fichier from '\.([A-Za-z0-9]+)$'));
    v_h := decode(left(p_b64, 16), 'base64');
    if not (case
        when v_ext = 'pdf' then substring(v_h from 1 for 4) = '\x25504446'
        when v_ext in ('jpg','jpeg') then substring(v_h from 1 for 3) = '\xffd8ff'
        when v_ext = 'png' then substring(v_h from 1 for 4) = '\x89504e47'
        else false end) then
      delete from public.tfl_paiements where id = d.id;
      return jsonb_build_object('ok', false, 'code', 'contenu');
    end if;
  end if;
  insert into public.tfl_paiements_parties(paiement_id, idx, b64) values (d.id, p_idx, p_b64)
  on conflict (paiement_id, idx) do update set b64 = excluded.b64;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_partie(text,text,uuid,int,text) from public;
grant execute on function public.tfl_paiement_partie(text,text,uuid,int,text) to anon, authenticated;

-- 3) Fin de l'envoi : tous les morceaux sont là et la taille correspond → le paiement passe « en attente de vérification ».
create or replace function public.tfl_paiement_terminer(p_ident text, p_mdp text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; d public.tfl_paiements; v_n int; v_oct bigint;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into d from public.tfl_paiements where id = p_id and acces_id = c.v_id and statut = 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  select count(*), coalesce(sum(length(decode(b64, 'base64'))), 0) into v_n, v_oct from public.tfl_paiements_parties where paiement_id = d.id;
  if v_n <> d.parties or v_oct <> d.taille then return jsonb_build_object('ok', false, 'code', 'incomplet'); end if;
  update public.tfl_paiements set statut = 'en_attente', maj_le = now() where id = d.id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_terminer(text,text,uuid) from public;
grant execute on function public.tfl_paiement_terminer(text,text,uuid) to anon, authenticated;

-- 4) Les paiements de SON dossier (sans le fichier) + les totaux. Les paiements en cours d'envoi ne sont pas listés.
create or replace function public.tfl_paiement_liste(p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_d text;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  v_d := coalesce(a.contenu->>'numero','');
  return jsonb_build_object('ok', true,
    'paiements', coalesce((select jsonb_agg(public.tfl_paiement_json(x) order by x.cree_le desc)
      from (select * from public.tfl_paiements where dossier = v_d and statut <> 'envoi' order by cree_le desc limit 100) x), '[]'::jsonb),
    'confirme', coalesce((select sum(montant_confirme) from public.tfl_paiements where dossier = v_d and statut = 'confirme'), 0),
    'en_attente', coalesce((select sum(montant) from public.tfl_paiements where dossier = v_d and statut = 'en_attente'), 0));
end $$;
revoke all on function public.tfl_paiement_liste(text,text) from public;
grant execute on function public.tfl_paiement_liste(text,text) to anon, authenticated;

-- 5) Téléchargement d'un morceau de SON bordereau.
create or replace function public.tfl_paiement_telecharger(p_ident text, p_mdp text, p_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; d public.tfl_paiements; v text;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  select * into d from public.tfl_paiements where id = p_id;
  if not found or d.statut = 'envoi' or d.parties < 1 or d.dossier <> coalesce(a.contenu->>'numero','') then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  select b64 into v from public.tfl_paiements_parties where paiement_id = d.id and idx = p_idx;
  if v is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true, 'b64', v, 'parties', d.parties, 'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille);
end $$;
revoke all on function public.tfl_paiement_telecharger(text,text,uuid,int) from public;
grant execute on function public.tfl_paiement_telecharger(text,text,uuid,int) to anon, authenticated;

-- 6) Suppression par l'étudiant : seulement SES déclarations encore « en attente » ou « refusées » (jamais un paiement confirmé).
create or replace function public.tfl_paiement_supprimer(p_ident text, p_mdp text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; n int;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  delete from public.tfl_paiements where id = p_id and acces_id = c.v_id and source = 'etudiant' and statut in ('en_attente','refuse');
  get diagnostics n = row_count;
  if n = 0 then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_supprimer(text,text,uuid) from public;
grant execute on function public.tfl_paiement_supprimer(text,text,uuid) to anon, authenticated;

-- ---------- Administration (e-mail administrateur connecté) ----------
create or replace function public.tfl_paiements_admin_liste(p_dossier text default null)
returns jsonb language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(public.tfl_paiement_json(x) || jsonb_build_object('auteur', coalesce(a.nom, '')) order by x.cree_le desc)
    from (select * from public.tfl_paiements t where t.statut <> 'envoi' and (p_dossier is null or t.dossier = p_dossier) order by t.cree_le desc limit 500) x
    left join public.tfl_acces a on a.id = x.acces_id), '[]'::jsonb);
end $$;
revoke all on function public.tfl_paiements_admin_liste(text) from public, anon;
grant execute on function public.tfl_paiements_admin_liste(text) to authenticated;

-- Résumé par dossier et par devise (tableau « Frais TFL » de l'administration).
create or replace function public.tfl_paiements_admin_resume()
returns jsonb language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('dossier', t.dossier, 'devise', t.devise, 'confirme', t.confirme, 'en_attente_n', t.en_attente_n,
      'en_attente_montant', t.en_attente_montant, 'dernier', t.dernier) order by t.dossier)
    from (select dossier, devise,
            coalesce(sum(montant_confirme) filter (where statut = 'confirme'), 0) as confirme,
            count(*) filter (where statut = 'en_attente') as en_attente_n,
            coalesce(sum(montant) filter (where statut = 'en_attente'), 0) as en_attente_montant,
            max(cree_le) as dernier
          from public.tfl_paiements where statut <> 'envoi' group by dossier, devise) t), '[]'::jsonb);
end $$;
revoke all on function public.tfl_paiements_admin_resume() from public, anon;
grant execute on function public.tfl_paiements_admin_resume() to authenticated;

create or replace function public.tfl_paiement_admin_telecharger(p_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare d public.tfl_paiements; v text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi' and parties > 0;
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= d.parties then return jsonb_build_object('ok', false, 'code', 'invalide'); end if;
  select b64 into v from public.tfl_paiements_parties where paiement_id = d.id and idx = p_idx;
  if v is null then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  return jsonb_build_object('ok', true, 'b64', v, 'parties', d.parties, 'nom', d.nom_fichier, 'mime', d.mime, 'taille', d.taille);
end $$;
revoke all on function public.tfl_paiement_admin_telecharger(uuid,int) from public, anon;
grant execute on function public.tfl_paiement_admin_telecharger(uuid,int) to authenticated;

-- Décision : confirme (montant réellement reçu, numéro de reçu), refuse (motif obligatoire) ou remet en attente.
create or replace function public.tfl_paiement_admin_decider(p_id uuid, p_statut text, p_montant numeric default null, p_motif text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare d public.tfl_paiements; v_motif text := left(btrim(coalesce(p_motif,'')), 500); v_m numeric(12,2);
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('confirme','refuse','en_attente') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_statut = 'confirme' then
    v_m := round(coalesce(p_montant, d.montant), 2);
    if v_m <= 0 or v_m > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
    update public.tfl_paiements set statut = 'confirme', montant_confirme = v_m, motif = v_motif, recu_no = coalesce(recu_no, public.tfl_recu_numero()), decide_le = now(), maj_le = now() where id = d.id;
  elsif p_statut = 'refuse' then
    if length(v_motif) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    update public.tfl_paiements set statut = 'refuse', montant_confirme = null, motif = v_motif, recu_no = null, decide_le = now(), maj_le = now() where id = d.id;
  else
    update public.tfl_paiements set statut = 'en_attente', montant_confirme = null, motif = '', recu_no = null, decide_le = null, maj_le = now() where id = d.id;
  end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) from public, anon;
grant execute on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) to authenticated;

-- Paiement reçu en caisse ou enregistré par l'administration : directement confirmé, avec son reçu.
create or replace function public.tfl_paiement_admin_ajouter(p_dossier text, p_montant numeric, p_devise text, p_mode text, p_reference text, p_date date, p_note text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_m numeric(12,2); v_id uuid; v_recu text; v_dev text := upper(left(coalesce(nullif(btrim(p_devise), ''), 'USD'), 5));
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if v_d = '' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 800 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 60 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  v_m := round(p_montant, 2); v_recu := public.tfl_recu_numero();
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, statut, montant_confirme, recu_no, decide_le)
  values (null, v_d, 'administration', v_m, v_dev, p_mode, left(btrim(coalesce(p_reference,'')), 80), p_date, left(btrim(coalesce(p_note,'')), 500), 'confirme', v_m, v_recu, now())
  returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id, 'recu_no', v_recu);
end $$;
revoke all on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) from public, anon;
grant execute on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) to authenticated;

create or replace function public.tfl_paiement_admin_supprimer(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  delete from public.tfl_paiements where id = p_id;
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_paiement_admin_supprimer(uuid) from public, anon;
grant execute on function public.tfl_paiement_admin_supprimer(uuid) to authenticated;

-- ============ PARTIE 4 : QR de vérification des reçus ============
-- TFL bloc 5 — PARTIE 4 (QR de vérification des reçus). À exécuter APRÈS les parties 1, 2 et 3. Réexécutable.
-- Prérequis : le registre de vérification des documents (migration-v99m-verification.sql et migration-v99zzy-securite-tfl-qr.sql), déjà utilisé
-- par vos devis, factures et attestations. Si ce registre est absent, les reçus restent délivrés mais leur QR n'est pas reconnu (l'écran le signale).
-- Principe : chaque reçu CONFIRMÉ reçoit un code de vérification aléatoire (impossible à deviner) et est inscrit au registre ;
-- le QR du reçu ouvre verification.html. Si le paiement est refusé, remis en attente ou supprimé, le reçu est marqué « annulé » au registre.

alter table public.tfl_paiements add column if not exists verif_hash text;

-- Description d'un paiement : le code de vérification n'est donné que pour un paiement confirmé.
create or replace function public.tfl_paiement_json(p public.tfl_paiements) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object('id', p.id, 'source', p.source, 'dossier', p.dossier, 'montant', p.montant, 'devise', p.devise, 'mode', p.mode,
    'reference', p.reference, 'date_paiement', p.date_paiement, 'note', p.note, 'nom', p.nom_fichier, 'mime', p.mime, 'taille', p.taille,
    'parties', p.parties, 'statut', p.statut, 'montant_confirme', p.montant_confirme, 'motif', p.motif, 'recu_no', p.recu_no,
    'verif', case when p.statut = 'confirme' then p.verif_hash end, 'decide_le', p.decide_le, 'cree_le', p.cree_le)
$$;
revoke all on function public.tfl_paiement_json(public.tfl_paiements) from public, anon, authenticated;

-- Inscrit (ou met à jour) le reçu au registre de vérification. Renvoie false si le registre est indisponible (sans jamais bloquer la confirmation).
create or replace function public.tfl_recu_registre(p public.tfl_paiements) returns boolean
language plpgsql security definer set search_path = public as $$
declare v_nom text; v_mat text; v_mode text;
begin
  if p.recu_no is null or p.verif_hash is null or p.montant_confirme is null then return false; end if;
  select a.contenu->>'nom', a.contenu->>'matricule' into v_nom, v_mat from public.tfl_acces a
    where a.role = 'etudiant' and a.contenu->>'numero' = p.dossier order by a.publie_le desc limit 1;
  v_mode := case p.mode when 'banque' then 'banque' when 'mobile_money' then 'mobile money' when 'caisse' then 'caisse' else 'autre moyen' end;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail, updated_at)
  values (left(p.recu_no, 60), left(p.verif_hash, 20), 'recu', coalesce(p.decide_le::date, current_date), p.montant_confirme, left(p.devise, 8), 'valide',
          left(coalesce(v_nom, ''), 120), left(coalesce(v_mat, ''), 40), 'Reçu de paiement — frais TFL', left('Dossier ' || p.dossier || ' · ' || v_mode, 300), now())
  on conflict (no, hash) do update set status = 'valide', total = excluded.total, cur = excluded.cur, doc_date = excluded.doc_date, nom = excluded.nom,
    matricule = excluded.matricule, libelle = excluded.libelle, detail = excluded.detail, updated_at = now();
  return true;
exception when others then
  return false;
end $$;
revoke all on function public.tfl_recu_registre(public.tfl_paiements) from public, anon, authenticated;

-- Marque un reçu « annulé » au registre (tous ses codes). Sans effet si le registre est indisponible.
create or replace function public.tfl_recu_annuler(p_no text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_no is null or p_no = '' then return; end if;
  update public.exb_doc_registry set status = 'annulé', updated_at = now() where no = left(p_no, 60);
exception when others then
  null;
end $$;
revoke all on function public.tfl_recu_annuler(text) from public, anon, authenticated;

-- Décision : confirme (reçu + code de vérification + registre), refuse (motif obligatoire) ou remet en attente (le reçu est annulé au registre).
create or replace function public.tfl_paiement_admin_decider(p_id uuid, p_statut text, p_montant numeric default null, p_motif text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare d public.tfl_paiements; v_motif text := left(btrim(coalesce(p_motif,'')), 500); v_m numeric(12,2); v_reg boolean := true;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if p_statut not in ('confirme','refuse','en_attente') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select * into d from public.tfl_paiements where id = p_id and statut <> 'envoi';
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  if p_statut = 'confirme' then
    v_m := round(coalesce(p_montant, d.montant), 2);
    if v_m <= 0 or v_m > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
    update public.tfl_paiements set statut = 'confirme', montant_confirme = v_m, motif = v_motif, recu_no = coalesce(recu_no, public.tfl_recu_numero()),
      verif_hash = coalesce(verif_hash, substr(md5(random()::text || clock_timestamp()::text || id::text), 1, 10)), decide_le = now(), maj_le = now()
      where id = d.id returning * into d;
    v_reg := public.tfl_recu_registre(d);
  else
    if p_statut = 'refuse' and length(v_motif) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    perform public.tfl_recu_annuler(d.recu_no);
    if p_statut = 'refuse' then
      update public.tfl_paiements set statut = 'refuse', montant_confirme = null, motif = v_motif, recu_no = null, verif_hash = null, decide_le = now(), maj_le = now() where id = d.id;
    else
      update public.tfl_paiements set statut = 'en_attente', montant_confirme = null, motif = '', recu_no = null, verif_hash = null, decide_le = null, maj_le = now() where id = d.id;
    end if;
  end if;
  return jsonb_build_object('ok', true, 'verifiable', v_reg);
end $$;
revoke all on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) from public, anon;
grant execute on function public.tfl_paiement_admin_decider(uuid,text,numeric,text) to authenticated;

-- Paiement reçu en caisse ou enregistré par l'administration : directement confirmé, avec son reçu et son code de vérification.
create or replace function public.tfl_paiement_admin_ajouter(p_dossier text, p_montant numeric, p_devise text, p_mode text, p_reference text, p_date date, p_note text default '')
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_d text := left(btrim(coalesce(p_dossier,'')), 40); v_m numeric(12,2); v_recu text; v_dev text := upper(left(coalesce(nullif(btrim(p_devise), ''), 'USD'), 5)); p public.tfl_paiements; v_reg boolean;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if v_d = '' then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if p_mode not in ('banque','mobile_money','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 800 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  if (select count(*) from public.tfl_paiements where dossier = v_d) >= 60 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  v_m := round(p_montant, 2); v_recu := public.tfl_recu_numero();
  insert into public.tfl_paiements(acces_id, dossier, source, montant, devise, mode, reference, date_paiement, note, statut, montant_confirme, recu_no, verif_hash, decide_le)
  values (null, v_d, 'administration', v_m, v_dev, p_mode, left(btrim(coalesce(p_reference,'')), 80), p_date, left(btrim(coalesce(p_note,'')), 500), 'confirme', v_m, v_recu,
          substr(md5(random()::text || clock_timestamp()::text || v_recu), 1, 10), now())
  returning * into p;
  v_reg := public.tfl_recu_registre(p);
  return jsonb_build_object('ok', true, 'id', p.id, 'recu_no', v_recu, 'verifiable', v_reg);
end $$;
revoke all on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) from public, anon;
grant execute on function public.tfl_paiement_admin_ajouter(text,numeric,text,text,text,date,text) to authenticated;

-- Suppression : le reçu éventuel est annulé au registre.
create or replace function public.tfl_paiement_admin_supprimer(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_no text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  select recu_no into v_no from public.tfl_paiements where id = p_id;
  perform public.tfl_recu_annuler(v_no);
  delete from public.tfl_paiements where id = p_id;
  return jsonb_build_object('ok', found);
end $$;
revoke all on function public.tfl_paiement_admin_supprimer(uuid) from public, anon;
grant execute on function public.tfl_paiement_admin_supprimer(uuid) to authenticated;

-- Contrôles :
--   select column_name from information_schema.columns where table_name = 'tfl_paiements' and column_name = 'verif_hash';  → 1 ligne
--   select proname from pg_proc where proname in ('tfl_recu_registre','tfl_recu_annuler');  → 2 lignes
--   select count(*) from information_schema.tables where table_name = 'exb_doc_registry';  → 1 (sinon exécuter d'abord migration-v99m-verification.sql)

-- Contrôle : select proname from pg_proc where proname like 'tfl_paiement%';  → 13 lignes
--   (étudiant : tfl_paiement_creer, _partie, _terminer, _liste, _telecharger, _supprimer ; interne : tfl_paiement_json ;
--    administration : tfl_paiements_admin_liste, tfl_paiements_admin_resume, tfl_paiement_admin_telecharger, _admin_decider, _admin_ajouter, _admin_supprimer)
-- Et : select tablename, rowsecurity from pg_tables where tablename like 'tfl_paiements%';  → 2 lignes, rowsecurity = true
