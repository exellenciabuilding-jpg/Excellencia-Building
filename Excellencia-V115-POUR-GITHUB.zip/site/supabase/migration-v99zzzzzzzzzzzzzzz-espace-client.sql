-- Excellencia Building — Espace client avec compte (matricule + mot de passe)
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zy-portails.sql. Réexécutable sans danger.
-- Principe : le client garde son matricule (donné automatiquement à sa demande). L'entreprise crée son compte :
--   · identifiant = matricule ; mot de passe par défaut = ce même matricule ;
--   · à la PREMIÈRE connexion le client DOIT choisir un nouveau mot de passe (8 caractères minimum, différent du matricule) ;
--     tant qu'il ne l'a pas fait, rien d'autre n'est accessible.
--   · le compte est relié à un portail déjà publié (portail_liens) : le client voit le même contenu que par lien + code
--     (projets, avancement, devis/factures/paiements, documents à valider/signer, messages).
-- Protections : mot de passe haché (bcrypt), 5 essais ratés = blocage 15 min, session aléatoire de 12 h (stockée hachée),
-- aucun accès direct aux tables (tout passe par les fonctions), même message d'erreur si le matricule n'existe pas.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.client_comptes (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  matricule text not null,
  nom text,
  lien_id uuid references public.portail_liens(id) on delete set null,
  pw_hash text not null,
  doit_changer boolean not null default true,
  actif boolean not null default true,
  essais int not null default 0,
  bloque_jusqua timestamptz,
  derniere_connexion timestamptz,
  created_at timestamptz not null default now()
);
create unique index if not exists client_comptes_mat_uq on public.client_comptes (upper(matricule));
create index if not exists client_comptes_org_idx on public.client_comptes (org_id);

create table if not exists public.client_sessions (
  token_hash text primary key,
  compte_id uuid not null references public.client_comptes(id) on delete cascade,
  restreint boolean not null default false,
  expire_le timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists client_sessions_compte_idx on public.client_sessions (compte_id);

alter table public.client_comptes enable row level security;
alter table public.client_sessions enable row level security;
revoke all on public.client_comptes, public.client_sessions from anon, authenticated;
-- Lecture par les membres autorisés de l'organisation (sans le mot de passe haché : colonnes limitées).
grant select (id, org_id, matricule, nom, lien_id, doit_changer, actif, derniere_connexion, created_at) on public.client_comptes to authenticated;
drop policy if exists client_comptes_org on public.client_comptes;
create policy client_comptes_org on public.client_comptes for select to authenticated using (public.peut(org_id, 'portails', false));

create or replace function public.client_sh(p_t text)
returns text language sql immutable set search_path = public, extensions as $$
  select encode(extensions.digest(convert_to('cs:' || coalesce(p_t,''), 'UTF8'), 'sha256'), 'hex')
$$;
revoke all on function public.client_sh(text) from public, anon, authenticated;

-- Le contrôle du portail accepte aussi une session de compte client (jeton « cs_… ») à la place de lien + code.
create or replace function public.portail_check(p_token text, p_code text, out v_id uuid, out v_err text, out v_min int)
language plpgsql security definer set search_path = public, extensions as $$
declare l public.portail_liens; s record;
begin
  v_id := null; v_err := null; v_min := 0;
  if left(coalesce(p_token,''), 3) = 'cs_' then
    select s2.restreint, c.lien_id, c.actif as c_actif into s
      from public.client_sessions s2 join public.client_comptes c on c.id = s2.compte_id
     where s2.token_hash = public.client_sh(left(p_token, 80)) and s2.expire_le > now();
    if not found or not s.c_actif then v_err := 'session'; return; end if;
    if s.restreint then v_err := 'changer'; return; end if;
    if s.lien_id is null then v_err := 'revoque'; return; end if;
    select * into l from public.portail_liens where id = s.lien_id;
    if not found or not l.actif then v_err := 'revoque'; return; end if;
    if l.expire_le is not null and l.expire_le < current_date then v_err := 'expire'; return; end if;
    v_id := l.id; return;
  end if;
  select * into l from public.portail_liens where token = left(coalesce(p_token,''), 64);
  if not found then v_err := 'code'; return; end if;
  if l.bloque_jusqua is not null and l.bloque_jusqua > now() then
    v_err := 'bloque'; v_min := greatest(1, ceil(extract(epoch from (l.bloque_jusqua - now())) / 60)::int); return;
  end if;
  if l.code_hash <> public.portail_h(left(coalesce(p_code,''), 20), l.token) then
    if l.essais + 1 >= 5 then
      update public.portail_liens set essais = 0, bloque_jusqua = now() + interval '15 minutes' where id = l.id;
      v_err := 'bloque'; v_min := 15;
    else
      update public.portail_liens set essais = essais + 1 where id = l.id;
      v_err := 'code';
    end if;
    return;
  end if;
  if not l.actif then v_err := 'revoque'; return; end if;
  if l.expire_le is not null and l.expire_le < current_date then v_err := 'expire'; return; end if;
  if l.essais <> 0 then update public.portail_liens set essais = 0 where id = l.id; end if;
  v_id := l.id;
end $$;
revoke all on function public.portail_check(text, text) from public, anon, authenticated;

-- ---------- Côté entreprise ----------
-- Crée le compte (ou le réinitialise : mot de passe remis au matricule, changement obligatoire). p_token = jeton du portail à relier.
create or replace function public.client_compte_creer(p_org uuid, p_matricule text, p_nom text, p_token text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v_mat text := upper(btrim(coalesce(p_matricule,''))); v_lien uuid; v_id uuid;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  if v_mat !~ '^[A-Z0-9][A-Z0-9._/-]{3,39}$' then raise exception 'matricule_invalide'; end if;
  if coalesce(p_token,'') <> '' then
    select id into v_lien from public.portail_liens where token = p_token and org_id = p_org and kind = 'client';
    if v_lien is null then raise exception 'portail_introuvable'; end if;
  end if;
  if exists (select 1 from public.client_comptes where upper(matricule) = v_mat and org_id <> p_org) then raise exception 'matricule_pris'; end if;
  insert into public.client_comptes(org_id, matricule, nom, lien_id, pw_hash)
  values (p_org, v_mat, left(btrim(coalesce(p_nom,'')),160), v_lien, extensions.crypt(v_mat, extensions.gen_salt('bf', 10)))
  on conflict (upper(matricule)) do update set
    nom = excluded.nom, lien_id = coalesce(excluded.lien_id, public.client_comptes.lien_id),
    pw_hash = excluded.pw_hash, doit_changer = true, actif = true, essais = 0, bloque_jusqua = null
  returning id into v_id;
  delete from public.client_sessions where compte_id = v_id;
  return jsonb_build_object('ok', true, 'matricule', v_mat);
end $$;
revoke all on function public.client_compte_creer(uuid,text,text,text) from public, anon;
grant execute on function public.client_compte_creer(uuid,text,text,text) to authenticated;

create or replace function public.client_compte_etat(p_org uuid, p_matricule text, p_actif boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  update public.client_comptes set actif = coalesce(p_actif, actif) where org_id = p_org and upper(matricule) = upper(btrim(p_matricule)) returning id into v_id;
  if v_id is null then raise exception 'introuvable'; end if;
  if p_actif is false then delete from public.client_sessions where compte_id = v_id; end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.client_compte_etat(uuid,text,boolean) from public, anon;
grant execute on function public.client_compte_etat(uuid,text,boolean) to authenticated;

-- ---------- Côté client (anonyme : matricule + mot de passe) ----------
create or replace function public.client_connexion(p_matricule text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c public.client_comptes; v_mat text := upper(btrim(left(coalesce(p_matricule,''), 60))); v_tok text;
begin
  select * into c from public.client_comptes where upper(matricule) = v_mat;
  if not found then
    perform extensions.crypt(coalesce(p_mdp,''), extensions.gen_salt('bf', 10)); -- même durée de traitement
    return jsonb_build_object('ok', false, 'code', 'identifiants');
  end if;
  if c.bloque_jusqua is not null and c.bloque_jusqua > now() then
    return jsonb_build_object('ok', false, 'code', 'bloque', 'minutes', greatest(1, ceil(extract(epoch from (c.bloque_jusqua - now())) / 60)::int));
  end if;
  if c.pw_hash <> extensions.crypt(left(coalesce(p_mdp,''), 200), c.pw_hash) then
    if c.essais + 1 >= 5 then
      update public.client_comptes set essais = 0, bloque_jusqua = now() + interval '15 minutes' where id = c.id;
      return jsonb_build_object('ok', false, 'code', 'bloque', 'minutes', 15);
    end if;
    update public.client_comptes set essais = essais + 1 where id = c.id;
    return jsonb_build_object('ok', false, 'code', 'identifiants');
  end if;
  if not c.actif then return jsonb_build_object('ok', false, 'code', 'desactive'); end if;
  delete from public.client_sessions where compte_id = c.id and expire_le < now();
  v_tok := 'cs_' || encode(extensions.gen_random_bytes(24), 'hex');
  insert into public.client_sessions(token_hash, compte_id, restreint, expire_le)
  values (public.client_sh(v_tok), c.id, c.doit_changer, now() + interval '12 hours');
  update public.client_comptes set essais = 0, bloque_jusqua = null, derniere_connexion = now() where id = c.id;
  return jsonb_build_object('ok', true, 'session', v_tok, 'doit_changer', c.doit_changer, 'nom', c.nom, 'matricule', c.matricule);
end $$;
revoke all on function public.client_connexion(text,text) from public;
grant execute on function public.client_connexion(text,text) to anon, authenticated;

create or replace function public.client_changer_mdp(p_session text, p_ancien text, p_nouveau text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare s record; c public.client_comptes; n text := left(coalesce(p_nouveau,''), 200);
begin
  select s2.token_hash, s2.compte_id into s from public.client_sessions s2
   where s2.token_hash = public.client_sh(left(coalesce(p_session,''), 80)) and s2.expire_le > now();
  if not found then return jsonb_build_object('ok', false, 'code', 'session'); end if;
  select * into c from public.client_comptes where id = s.compte_id and actif;
  if not found then return jsonb_build_object('ok', false, 'code', 'session'); end if;
  if c.bloque_jusqua is not null and c.bloque_jusqua > now() then return jsonb_build_object('ok', false, 'code', 'bloque'); end if;
  if c.pw_hash <> extensions.crypt(left(coalesce(p_ancien,''), 200), c.pw_hash) then
    update public.client_comptes set
      bloque_jusqua = case when essais + 1 >= 5 then now() + interval '15 minutes' else bloque_jusqua end,
      essais = case when essais + 1 >= 5 then 0 else essais + 1 end where id = c.id;
    return jsonb_build_object('ok', false, 'code', 'ancien');
  end if;
  if length(n) < 8 then return jsonb_build_object('ok', false, 'code', 'court'); end if;
  if upper(n) = upper(c.matricule) then return jsonb_build_object('ok', false, 'code', 'identique'); end if;
  update public.client_comptes set pw_hash = extensions.crypt(n, extensions.gen_salt('bf', 10)), doit_changer = false, essais = 0 where id = c.id;
  delete from public.client_sessions where compte_id = c.id and token_hash <> s.token_hash;
  update public.client_sessions set restreint = false where token_hash = s.token_hash;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.client_changer_mdp(text,text,text) from public;
grant execute on function public.client_changer_mdp(text,text,text) to anon, authenticated;

create or replace function public.client_deconnexion(p_session text)
returns jsonb language sql security definer set search_path = public as $$
  with d as (delete from public.client_sessions where token_hash = public.client_sh(left(coalesce(p_session,''), 80)) returning 1)
  select jsonb_build_object('ok', true)
$$;
revoke all on function public.client_deconnexion(text) from public;
grant execute on function public.client_deconnexion(text) to anon, authenticated;

notify pgrst, 'reload schema';
