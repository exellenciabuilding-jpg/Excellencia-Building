-- Excellencia Building V99zy — Portails client et sous-traitant, e-signature, messages, déclarations d'avancement.
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zp-double-authentification.sql (utilise peut() et licence_ecriture_ok()). Réexécutable sans danger.
-- FAITES D'ABORD UNE SAUVEGARDE et essayez sur un projet de recette (voir tools/test-rls).
-- Principe : l'entreprise PUBLIE un instantané (avancement, photos choisies, factures, documents à signer) sous un lien secret
-- + un code à 6 chiffres. Le visiteur (anonyme) n'accède à rien d'autre que par les fonctions ci-dessous : aucune table n'est lisible en direct.
-- Protections : jeton aléatoire de 96 bits, code haché (SHA-256 salé par le jeton), blocage 15 min après 5 codes faux,
-- limites de volume, lien révocable et à date d'expiration. Côté entreprise, les droits suivent le modèle du logiciel : organisation + fonction (peut()), 2FA et licence appliquées par le serveur.
-- Les fonctions portail_lire / signer / message / declarer restent ouvertes à l'anonyme VOLONTAIREMENT (visiteur sans compte) : elles exigent le jeton ET le code.

create extension if not exists pgcrypto with schema extensions;

-- Si une version antérieure (sans organisation) avait été installée : on retire ses anciennes signatures de fonctions.
drop function if exists public.portail_publier(text,text,text,text,text,jsonb,date);
drop function if exists public.portail_retours();

create table if not exists public.portail_liens (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null default auth.uid(),
  org_id uuid not null,
  token text not null unique,
  kind text not null check (kind in ('client','soustraitant')),
  titre text not null,
  destinataire text,
  code_hash text not null,
  contenu jsonb not null default '{}'::jsonb,
  actif boolean not null default true,
  expire_le date,
  publie_le timestamptz not null default now(),
  created_at timestamptz not null default now(),
  essais int not null default 0,
  bloque_jusqua timestamptz,
  visites int not null default 0,
  derniere_visite timestamptz
);
create index if not exists portail_liens_org_idx on public.portail_liens (org_id);

create table if not exists public.portail_signatures (
  id uuid primary key default gen_random_uuid(),
  lien_id uuid not null references public.portail_liens(id) on delete cascade,
  doc_id text not null,
  doc_titre text,
  doc_hash text not null,
  role text not null,
  nom text not null,
  image text,
  agent text,
  signe_le timestamptz not null default now(),
  unique (lien_id, doc_id, role)
);

create table if not exists public.portail_messages (
  id uuid primary key default gen_random_uuid(),
  lien_id uuid not null references public.portail_liens(id) on delete cascade,
  de text not null check (de in ('visiteur','entreprise')),
  texte text not null,
  cree_le timestamptz not null default now()
);
create index if not exists portail_messages_lien_idx on public.portail_messages (lien_id, cree_le);

create table if not exists public.portail_declarations (
  id uuid primary key default gen_random_uuid(),
  lien_id uuid not null references public.portail_liens(id) on delete cascade,
  lot text not null,
  pct numeric(5,2) not null check (pct >= 0 and pct <= 100),
  note text,
  statut text not null default 'a_verifier' check (statut in ('a_verifier','accepte','refuse')),
  reponse text,
  cree_le timestamptz not null default now()
);
create index if not exists portail_declarations_lien_idx on public.portail_declarations (lien_id, cree_le);

alter table public.portail_liens enable row level security;
alter table public.portail_signatures enable row level security;
alter table public.portail_messages enable row level security;
alter table public.portail_declarations enable row level security;

-- Lecture réservée aux membres de l'organisation autorisés (collection « portails »). Aucune écriture directe : tout passe par les fonctions.
drop policy if exists portail_liens_proprio on public.portail_liens;
drop policy if exists portail_liens_org on public.portail_liens;
create policy portail_liens_org on public.portail_liens for select to authenticated using (public.peut(org_id, 'portails', false));
drop policy if exists portail_sig_proprio on public.portail_signatures;
drop policy if exists portail_sig_org on public.portail_signatures;
create policy portail_sig_org on public.portail_signatures for select to authenticated
  using (exists (select 1 from public.portail_liens l where l.id = lien_id and public.peut(l.org_id, 'portails', false)));
drop policy if exists portail_msg_proprio on public.portail_messages;
drop policy if exists portail_msg_org on public.portail_messages;
create policy portail_msg_org on public.portail_messages for select to authenticated
  using (exists (select 1 from public.portail_liens l where l.id = lien_id and public.peut(l.org_id, 'portails', false)));
drop policy if exists portail_decl_proprio on public.portail_declarations;
drop policy if exists portail_decl_org on public.portail_declarations;
create policy portail_decl_org on public.portail_declarations for select to authenticated
  using (exists (select 1 from public.portail_liens l where l.id = lien_id and public.peut(l.org_id, 'portails', false)));

-- Droits par fonction sur les nouvelles collections synchronisées (copiés depuis la collection équivalente ; rien n'est écrasé).
insert into public.droits_fonction(fonction, collection, lire, ecrire)
select d.fonction, m.nouveau, d.lire, d.ecrire
from public.droits_fonction d
join (values ('portails','clients'), ('relances','clients'), ('esign','contrats')) as m(nouveau, ancien) on d.collection = m.ancien
on conflict (fonction, collection) do nothing;

-- ---------- Fonctions internes ----------
create or replace function public.portail_h(p_code text, p_token text)
returns text language sql immutable set search_path = public, extensions as $$
  select encode(extensions.digest(convert_to(coalesce(p_code,'') || ':' || coalesce(p_token,''), 'UTF8'), 'sha256'), 'hex')
$$;
revoke all on function public.portail_h(text, text) from public, anon, authenticated;

-- Vérifie jeton + code. Renvoie l'identifiant du lien ou un code d'erreur. Les essais ratés sont comptés (pas d'exception : elle annulerait le comptage).
create or replace function public.portail_check(p_token text, p_code text, out v_id uuid, out v_err text, out v_min int)
language plpgsql security definer set search_path = public, extensions as $$
declare l public.portail_liens;
begin
  v_id := null; v_err := null; v_min := 0;
  select * into l from public.portail_liens where token = left(coalesce(p_token,''), 64);
  if not found then v_err := 'code'; return; end if;
  if l.bloque_jusqua is not null and l.bloque_jusqua > now() then
    v_err := 'bloque'; v_min := greatest(1, ceil(extract(epoch from (l.bloque_jusqua - now())) / 60)::int); return;
  end if;
  if l.code_hash <> public.portail_h(left(coalesce(p_code,''), 20), l.token) then
    if l.essais + 1 >= 5 then
      update public.portail_liens set essais = 0, bloque_jusqua = now() + interval '15 minutes' where id = l.id;
      v_err := 'bloque'; v_min := 15;
    else
      update public.portail_liens set essais = essais + 1 where id = l.id;
      v_err := 'code';
    end if;
    return;
  end if;
  if not l.actif then v_err := 'revoque'; return; end if;
  if l.expire_le is not null and l.expire_le < current_date then v_err := 'expire'; return; end if;
  if l.essais <> 0 then update public.portail_liens set essais = 0 where id = l.id; end if;
  v_id := l.id;
end $$;
revoke all on function public.portail_check(text, text) from public, anon, authenticated;

-- ---------- Côté entreprise (membre connecté de l'organisation) ----------
create or replace function public.portail_publier(p_org uuid, p_token text, p_kind text, p_titre text, p_dest text, p_code text, p_contenu jsonb, p_expire date)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare v_tok text := nullif(btrim(coalesce(p_token,'')), ''); v_id uuid;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  if p_kind not in ('client','soustraitant') then raise exception 'type_invalide'; end if;
  if length(btrim(coalesce(p_titre,''))) < 2 then raise exception 'titre_invalide'; end if;
  if octet_length(p_contenu::text) > 6000000 then raise exception 'contenu_trop_gros'; end if;
  if v_tok is null then
    if p_code !~ '^[0-9]{6,12}$' then raise exception 'code_invalide'; end if;
    v_tok := encode(extensions.gen_random_bytes(12), 'hex');
    insert into public.portail_liens(org_id, token, kind, titre, destinataire, code_hash, contenu, expire_le)
    values (p_org, v_tok, p_kind, left(p_titre,160), left(p_dest,160), public.portail_h(p_code, v_tok), p_contenu, p_expire)
    returning id into v_id;
  else
    select id into v_id from public.portail_liens where token = v_tok and org_id = p_org;
    if v_id is null then raise exception 'non autorisé'; end if;
    if coalesce(p_code,'') <> '' and p_code !~ '^[0-9]{6,12}$' then raise exception 'code_invalide'; end if;
    update public.portail_liens set titre = left(p_titre,160), destinataire = left(p_dest,160), contenu = p_contenu, expire_le = p_expire,
      actif = true, publie_le = now(), essais = 0, bloque_jusqua = null,
      code_hash = case when coalesce(p_code,'') <> '' then public.portail_h(p_code, v_tok) else code_hash end
    where id = v_id;
  end if;
  return jsonb_build_object('token', v_tok);
end $$;
revoke all on function public.portail_publier(uuid,text,text,text,text,text,jsonb,date) from public, anon;
grant execute on function public.portail_publier(uuid,text,text,text,text,text,jsonb,date) to authenticated;

create or replace function public.portail_revoquer(p_token text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.portail_liens;
begin
  select * into l from public.portail_liens where token = p_token;
  if not found or auth.uid() is null or not public.peut(l.org_id, 'portails', true) then raise exception 'non autorisé'; end if;
  update public.portail_liens set actif = false where id = l.id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.portail_revoquer(text) from public, anon;
grant execute on function public.portail_revoquer(text) to authenticated;

-- Retours pour l'entreprise : signatures, messages des visiteurs, déclarations, statistiques de visite.
create or replace function public.portail_retours(p_org uuid)
returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', false) then raise exception 'non autorisé'; end if;
  return jsonb_build_object(
    'liens', coalesce((select jsonb_agg(jsonb_build_object('token', token, 'kind', kind, 'actif', actif, 'visites', visites, 'derniere_visite', derniere_visite, 'publie_le', publie_le)) from public.portail_liens where org_id = p_org), '[]'::jsonb),
    'signatures', coalesce((select jsonb_agg(jsonb_build_object('token', l.token, 'doc_id', s.doc_id, 'doc_titre', s.doc_titre, 'doc_hash', s.doc_hash, 'role', s.role, 'nom', s.nom, 'image', s.image, 'signe_le', s.signe_le, 'agent', s.agent) order by s.signe_le)
      from public.portail_signatures s join public.portail_liens l on l.id = s.lien_id where l.org_id = p_org), '[]'::jsonb),
    'messages', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'token', l.token, 'titre', l.titre, 'de', m.de, 'texte', m.texte, 'cree_le', m.cree_le) order by m.cree_le)
      from public.portail_messages m join public.portail_liens l on l.id = m.lien_id where l.org_id = p_org), '[]'::jsonb),
    'declarations', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'token', l.token, 'titre', l.titre, 'destinataire', l.destinataire, 'lot', d.lot, 'pct', d.pct, 'note', d.note, 'statut', d.statut, 'reponse', d.reponse, 'cree_le', d.cree_le) order by d.cree_le)
      from public.portail_declarations d join public.portail_liens l on l.id = d.lien_id where l.org_id = p_org), '[]'::jsonb));
end $$;
revoke all on function public.portail_retours(uuid) from public, anon;
grant execute on function public.portail_retours(uuid) to authenticated;

create or replace function public.portail_repondre(p_token text, p_texte text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.portail_liens;
begin
  select * into l from public.portail_liens where token = p_token;
  if not found or auth.uid() is null or not public.peut(l.org_id, 'portails', true) then raise exception 'non autorisé'; end if;
  if length(btrim(coalesce(p_texte,''))) < 1 then raise exception 'texte_vide'; end if;
  insert into public.portail_messages(lien_id, de, texte) values (l.id, 'entreprise', left(p_texte, 1500));
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.portail_repondre(text,text) from public, anon;
grant execute on function public.portail_repondre(text,text) to authenticated;

create or replace function public.portail_decider(p_id uuid, p_statut text, p_reponse text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_org uuid;
begin
  if auth.uid() is null then raise exception 'non autorisé'; end if;
  if p_statut not in ('accepte','refuse','a_verifier') then raise exception 'statut_invalide'; end if;
  select l.org_id into v_org from public.portail_declarations d join public.portail_liens l on l.id = d.lien_id where d.id = p_id;
  if v_org is null or not public.peut(v_org, 'portails', true) then raise exception 'non autorisé'; end if;
  update public.portail_declarations set statut = p_statut, reponse = left(p_reponse, 500) where id = p_id;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.portail_decider(uuid,text,text) from public, anon;
grant execute on function public.portail_decider(uuid,text,text) to authenticated;

-- ---------- Côté visiteur (anonyme, avec jeton + code) ----------
create or replace function public.portail_lire(p_token text, p_code text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; l public.portail_liens;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  update public.portail_liens set visites = visites + 1, derniere_visite = now() where id = c.v_id returning * into l;
  return jsonb_build_object('ok', true, 'kind', l.kind, 'titre', l.titre, 'destinataire', l.destinataire, 'publie_le', l.publie_le, 'contenu', l.contenu,
    'signatures', coalesce((select jsonb_agg(jsonb_build_object('doc_id', s.doc_id, 'role', s.role, 'nom', s.nom, 'signe_le', s.signe_le, 'doc_hash', s.doc_hash)) from public.portail_signatures s where s.lien_id = l.id), '[]'::jsonb),
    'messages', coalesce((select jsonb_agg(jsonb_build_object('de', m.de, 'texte', m.texte, 'cree_le', m.cree_le) order by m.cree_le) from public.portail_messages m where m.lien_id = l.id), '[]'::jsonb),
    'declarations', coalesce((select jsonb_agg(jsonb_build_object('lot', d.lot, 'pct', d.pct, 'note', d.note, 'statut', d.statut, 'reponse', d.reponse, 'cree_le', d.cree_le) order by d.cree_le) from public.portail_declarations d where d.lien_id = l.id), '[]'::jsonb));
end $$;
revoke all on function public.portail_lire(text,text) from public;
grant execute on function public.portail_lire(text,text) to anon, authenticated;

create or replace function public.portail_signer(p_token text, p_code text, p_doc_id text, p_role text, p_nom text, p_image text, p_agent text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; l public.portail_liens; doc jsonb; v_nom text := left(btrim(coalesce(p_nom,'')), 120); v_when timestamptz;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into l from public.portail_liens where id = c.v_id;
  select d into doc from jsonb_array_elements(coalesce(l.contenu->'documents','[]'::jsonb)) d where d->>'id' = p_doc_id limit 1;
  if doc is null then return jsonb_build_object('ok', false, 'code', 'document'); end if;
  if not (coalesce(doc->'roles','[]'::jsonb) ? p_role) or p_role = 'entreprise' then return jsonb_build_object('ok', false, 'code', 'role'); end if;
  if (l.kind = 'client' and p_role <> 'client') or (l.kind = 'soustraitant' and p_role <> 'soustraitant') then return jsonb_build_object('ok', false, 'code', 'role'); end if;
  if length(v_nom) < 3 then return jsonb_build_object('ok', false, 'code', 'nom'); end if;
  if p_image is null or p_image !~ '^data:image/png;base64,[A-Za-z0-9+/=]+$' or length(p_image) > 150000 then return jsonb_build_object('ok', false, 'code', 'image'); end if;
  insert into public.portail_signatures(lien_id, doc_id, doc_titre, doc_hash, role, nom, image, agent)
  values (l.id, p_doc_id, left(doc->>'titre',200), left(doc->>'hash',80), p_role, v_nom, p_image, left(p_agent,200))
  on conflict (lien_id, doc_id, role) do nothing
  returning signe_le into v_when;
  if v_when is null then return jsonb_build_object('ok', false, 'code', 'deja'); end if;
  return jsonb_build_object('ok', true, 'signe_le', v_when, 'doc_hash', doc->>'hash');
end $$;
revoke all on function public.portail_signer(text,text,text,text,text,text,text) from public;
grant execute on function public.portail_signer(text,text,text,text,text,text,text) to anon, authenticated;

create or replace function public.portail_message(p_token text, p_code text, p_texte text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; v_t text := left(btrim(coalesce(p_texte,'')), 1500);
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if length(v_t) < 2 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  if (select count(*) from public.portail_messages where lien_id = c.v_id and de = 'visiteur' and cree_le > now() - interval '1 hour') >= 20 then
    return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  insert into public.portail_messages(lien_id, de, texte) values (c.v_id, 'visiteur', v_t);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.portail_message(text,text,text) from public;
grant execute on function public.portail_message(text,text,text) to anon, authenticated;

create or replace function public.portail_declarer(p_token text, p_code text, p_lot text, p_pct numeric, p_note text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; l public.portail_liens;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into l from public.portail_liens where id = c.v_id;
  if l.kind <> 'soustraitant' then return jsonb_build_object('ok', false, 'code', 'role'); end if;
  if p_pct is null or p_pct < 0 or p_pct > 100 or length(btrim(coalesce(p_lot,''))) < 1 then return jsonb_build_object('ok', false, 'code', 'donnees'); end if;
  if (select count(*) from public.portail_declarations where lien_id = l.id and cree_le > now() - interval '1 hour') >= 20 then
    return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  insert into public.portail_declarations(lien_id, lot, pct, note) values (l.id, left(btrim(p_lot),80), p_pct, left(p_note,500));
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.portail_declarer(text,text,text,numeric,text) from public;
grant execute on function public.portail_declarer(text,text,text,numeric,text) to anon, authenticated;
