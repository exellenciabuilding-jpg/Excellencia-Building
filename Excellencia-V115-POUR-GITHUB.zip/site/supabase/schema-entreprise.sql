-- ===== Excellencia Building — BASE DE DONNÉES PARTAGÉE (V56) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run.
-- Principe : une ENTREPRISE (organisation) regroupe plusieurs comptes. Chaque fiche (client, projet, devis, stock,
-- personnel, caisse, étude, communication) est UNE ligne : deux personnes peuvent travailler en même temps sans
-- s'écraser. Chaque modification est versionnée et journalisée. Rôles : admin / editeur / lecteur.

create extension if not exists pgcrypto;

create table if not exists organisations(
  id uuid primary key default gen_random_uuid(),
  nom text not null,
  code_invitation text not null unique default substr(md5(random()::text||clock_timestamp()::text),1,8),
  cree_par uuid default auth.uid(),
  cree_le timestamptz not null default now());

create table if not exists membres(
  org_id uuid not null references organisations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  nom text,
  role text not null default 'editeur' check (role in ('admin','editeur','lecteur')),
  depuis timestamptz not null default now(),
  primary key(org_id,user_id));

create table if not exists enregistrements(
  org_id uuid not null references organisations(id) on delete cascade,
  collection text not null,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  version int not null default 1,
  supprime boolean not null default false,
  maj timestamptz not null default now(),
  maj_par uuid,
  primary key(org_id,collection,id));
create index if not exists enreg_maj_idx on enregistrements(org_id,maj);

create table if not exists journal_entreprise(
  n bigserial primary key,
  org_id uuid, user_id uuid, collection text, rec_id text, action text, version int,
  quand timestamptz not null default now());

-- ---------- droits ----------
create or replace function est_membre(o uuid, roles text[] default array['admin','editeur','lecteur'])
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from membres where org_id=o and user_id=auth.uid() and role=any(roles)) $$;

alter table organisations enable row level security;
alter table membres enable row level security;
alter table enregistrements enable row level security;
alter table journal_entreprise enable row level security;

drop policy if exists org_lire on organisations;      create policy org_lire on organisations for select using (est_membre(id));
drop policy if exists mem_lire on membres;            create policy mem_lire on membres for select using (est_membre(org_id));
drop policy if exists mem_modif on membres;           create policy mem_modif on membres for update using (est_membre(org_id,array['admin'])) with check (est_membre(org_id,array['admin']));
drop policy if exists mem_suppr on membres;           create policy mem_suppr on membres for delete using (est_membre(org_id,array['admin']) or user_id=auth.uid());
drop policy if exists enr_lire on enregistrements;    create policy enr_lire on enregistrements for select using (est_membre(org_id));
drop policy if exists jr_lire on journal_entreprise;  create policy jr_lire on journal_entreprise for select using (est_membre(org_id,array['admin']));
-- Aucune écriture directe sur « enregistrements » : tout passe par la fonction enregistrer() ci-dessous.

-- ---------- fonctions ----------
create or replace function creer_organisation(p_nom text, p_nom_user text default null)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  insert into organisations(nom) values (coalesce(nullif(trim(p_nom),''),'Mon entreprise')) returning * into o;
  insert into membres(org_id,user_id,nom,role) values (o.id,auth.uid(),p_nom_user,'admin');
  return json_build_object('id',o.id,'nom',o.nom,'code',o.code_invitation,'role','admin');
end $$;

create or replace function rejoindre_organisation(p_code text, p_nom_user text default null)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations; r text;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  select * into o from organisations where code_invitation=lower(trim(p_code));
  if not found then raise exception 'code invalide'; end if;
  insert into membres(org_id,user_id,nom,role) values (o.id,auth.uid(),p_nom_user,'editeur') on conflict do nothing;
  select role into r from membres where org_id=o.id and user_id=auth.uid();
  return json_build_object('id',o.id,'nom',o.nom,'role',r);
end $$;

create or replace function mon_organisation()
returns json language sql stable security definer set search_path=public as $$
  select json_build_object('id',o.id,'nom',o.nom,'role',m.role,'code',case when m.role='admin' then o.code_invitation end)
  from membres m join organisations o on o.id=m.org_id where m.user_id=auth.uid() order by m.depuis limit 1 $$;

create or replace function renouveler_code(p_org uuid)
returns text language plpgsql security definer set search_path=public as $$
declare c text;
begin
  if not est_membre(p_org,array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  c:=substr(md5(random()::text||clock_timestamp()::text),1,8);
  update organisations set code_invitation=c where id=p_org; return c;
end $$;

-- Écriture d'une fiche avec contrôle de version (verrou optimiste).
-- p_base = version que l'appareil a vue en dernier (0 = nouvelle fiche).
create or replace function enregistrer(p_org uuid, p_col text, p_id text, p_data jsonb, p_base int, p_supprime boolean default false)
returns json language plpgsql security definer set search_path=public as $$
declare cur enregistrements; nv int;
begin
  if not est_membre(p_org,array['admin','editeur']) then raise exception 'droits insuffisants'; end if;
  select * into cur from enregistrements where org_id=p_org and collection=p_col and id=p_id for update;
  if found then
    if cur.version<>p_base then
      return json_build_object('ok',false,'conflit',true,'version',cur.version,'data',cur.data,'supprime',cur.supprime);
    end if;
    nv:=cur.version+1;
    update enregistrements set data=p_data,version=nv,supprime=p_supprime,maj=now(),maj_par=auth.uid()
      where org_id=p_org and collection=p_col and id=p_id;
  else
    if p_base<>0 then
      return json_build_object('ok',false,'conflit',true,'version',0,'data',null,'supprime',true);
    end if;
    nv:=1;
    insert into enregistrements(org_id,collection,id,data,version,supprime,maj_par) values (p_org,p_col,p_id,p_data,1,p_supprime,auth.uid());
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org,auth.uid(),p_col,p_id,case when p_supprime then 'suppression' when nv=1 then 'création' else 'modification' end,nv);
  return json_build_object('ok',true,'version',nv);
end $$;

grant execute on function creer_organisation(text,text), rejoindre_organisation(text,text), mon_organisation(),
  renouveler_code(uuid), enregistrer(uuid,text,text,jsonb,int,boolean) to authenticated;
-- Facultatif (mise à jour instantanée au lieu de toutes les 20 s) :
-- alter publication supabase_realtime add table enregistrements;

-- ================= ESPACE DE STOCKAGE DE DOCUMENTS (V59) =================
-- Bucket privé « documents » : un dossier par entreprise (nom du dossier = id de l'organisation).
insert into storage.buckets(id,name,public,file_size_limit) values ('documents','documents',false,52428800) on conflict (id) do nothing;

create or replace function org_du_chemin(p_name text) returns uuid language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

drop policy if exists doc_lire on storage.objects;
create policy doc_lire on storage.objects for select to authenticated
  using (bucket_id='documents' and est_membre(org_du_chemin(name)));
drop policy if exists doc_ajout on storage.objects;
create policy doc_ajout on storage.objects for insert to authenticated
  with check (bucket_id='documents' and est_membre(org_du_chemin(name),array['admin','editeur']));
drop policy if exists doc_modif on storage.objects;
create policy doc_modif on storage.objects for update to authenticated
  using (bucket_id='documents' and est_membre(org_du_chemin(name),array['admin','editeur']));
drop policy if exists doc_suppr on storage.objects;
create policy doc_suppr on storage.objects for delete to authenticated
  using (bucket_id='documents' and est_membre(org_du_chemin(name),array['admin','editeur']));
