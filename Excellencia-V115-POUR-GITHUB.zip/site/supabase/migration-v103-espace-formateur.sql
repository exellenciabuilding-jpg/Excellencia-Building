-- Excellencia Building V103 — Espace formateur : modification des sujets par les formateurs.
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v101 et migration-v102 (connexion par matricule), migration-v99zzv-tfl-sujets.sql (table tfl_sujets).
--
-- Le formateur se connecte avec son matricule et son mot de passe (1234 par défaut, à changer dès la première connexion), comme un apprenant.
-- Tant qu'il n'a pas changé son mot de passe, il ne peut ni lister ni modifier les sujets.
-- Son espace est ouvert quand l'équipe fait « 📢 Publier l'espace formateur » (session technique « __formateur »).
-- Seul un matricule présent dans cette session peut lister / modifier les sujets.
-- Chaque modification est conservée dans formateur_modifs (ancienne valeur, nouvelle valeur) pour que l'administration puisse la relire.

create table if not exists public.formateur_modifs (
  id bigint generated always as identity primary key,
  matricule text not null,
  nom text,
  ref text not null,
  avant jsonb,
  apres jsonb not null,
  cree_le timestamptz not null default now(),
  recu boolean not null default false
);
alter table public.formateur_modifs enable row level security;
revoke all on public.formateur_modifs from anon, authenticated;

-- Contrôle interne : renvoie le matricule normalisé si (matricule, mot de passe) valides ET formateur publié, sinon null.
create or replace function public._formateur_ok(p_matricule text, p_mdp text)
 returns text language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare r jsonb; m text := public._exb_n(p_matricule);
begin
  r := public.apprenant_connexion(p_matricule, p_mdp);
  if not coalesce((r->>'ok')::boolean, false) or coalesce((r->>'doit_changer')::boolean, false) then return null; end if;
  if not exists (select 1 from public.resultats_publies where matricule = m and session = '__formateur') then return null; end if;
  return m;
end $$;
revoke all on function public._formateur_ok(text, text) from public, anon, authenticated;

create or replace function public.formateur_sujets_lister(p_matricule text, p_mdp text)
 returns jsonb language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare m text := public._formateur_ok(p_matricule, p_mdp);
begin
  if m is null then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  return coalesce((select jsonb_agg(s.data || jsonb_build_object('ref', s.ref, 'statut', s.statut) order by s.ref)
                     from public.tfl_sujets s), '[]'::jsonb);
end $$;
revoke all on function public.formateur_sujets_lister(text, text) from public;
grant execute on function public.formateur_sujets_lister(text, text) to anon, authenticated;

create or replace function public.formateur_sujet_modifier(p_matricule text, p_mdp text, p_ref text, p_champs jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare m text := public._formateur_ok(p_matricule, p_mdp); s public.tfl_sujets; nv jsonb; k text; lim int; nm text;
begin
  if m is null then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  if jsonb_typeof(p_champs) is distinct from 'object' then return jsonb_build_object('ok', false, 'code', 'donnees'); end if;
  select * into s from public.tfl_sujets where ref = p_ref;
  if not found then return jsonb_build_object('ok', false, 'code', 'introuvable'); end if;
  nv := '{}'::jsonb;
  foreach k in array array['titre','problematique','objectifs','methodologie','livrables','competences','mots_cles'] loop
    if p_champs ? k then
      lim := case k when 'titre' then 250 when 'mots_cles' then 200 when 'livrables' then 2000 when 'competences' then 1000 else 3000 end;
      nv := nv || jsonb_build_object(k, left(btrim(coalesce(p_champs->>k,'')), lim));
    end if;
  end loop;
  if length(coalesce(nv->>'titre', s.data->>'titre')) < 3 then return jsonb_build_object('ok', false, 'code', 'titre'); end if;
  update public.tfl_sujets set data = data || nv, updated_at = now() where ref = p_ref;
  select nom into nm from public.apprenants_acces where matricule = m;
  insert into public.formateur_modifs(matricule, nom, ref, avant, apres) values (m, nm, p_ref, s.data, nv);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.formateur_sujet_modifier(text, text, text, jsonb) from public;
grant execute on function public.formateur_sujet_modifier(text, text, text, jsonb) to anon, authenticated;

-- Administration : lire puis marquer comme reçues les modifications faites par les formateurs.
create or replace function public.formateur_modifs_recues()
 returns table(id bigint, matricule text, nom text, ref text, apres jsonb, cree_le timestamptz)
 language plpgsql security definer set search_path to 'public' as $$
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  return query select m.id, m.matricule, m.nom, m.ref, m.apres, m.cree_le from public.formateur_modifs m where not m.recu order by m.id;
end $$;
revoke all on function public.formateur_modifs_recues() from public, anon;
grant execute on function public.formateur_modifs_recues() to authenticated;

create or replace function public.formateur_modifs_marquer(p_ids bigint[])
 returns void language plpgsql security definer set search_path to 'public' as $$
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  update public.formateur_modifs set recu = true where id = any(p_ids);
end $$;
revoke all on function public.formateur_modifs_marquer(bigint[]) from public, anon;
grant execute on function public.formateur_modifs_marquer(bigint[]) to authenticated;

-- Contrôle : select proname from pg_proc where proname like 'formateur_%';  → 5 lignes (3 avec _sujet/_modifs + _ok interne)
