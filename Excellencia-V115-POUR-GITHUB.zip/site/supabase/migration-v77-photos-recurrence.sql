-- Excellencia Building V77 — (1) photos en Supabase Storage  (2) récurrence calculée côté serveur.
-- À exécuter UNE fois (SQL Editor), après migration-v76. Réexécutable sans danger.

-- 1) PHOTOS : bucket privé « exb-photos ». Chemin attendu : <org_id>/<collection>/<fichier>.jpg
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('exb-photos','exb-photos',false,2097152,array['image/jpeg','image/png'])
on conflict (id) do update set file_size_limit=excluded.file_size_limit, allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists exb_photos_lire on storage.objects;
create policy exb_photos_lire on storage.objects for select to authenticated
 using (bucket_id='exb-photos' and est_membre(((storage.foldername(name))[1])::uuid));
drop policy if exists exb_photos_ecrire on storage.objects;
create policy exb_photos_ecrire on storage.objects for insert to authenticated
 with check (bucket_id='exb-photos' and est_membre(((storage.foldername(name))[1])::uuid,array['admin','editeur']));
drop policy if exists exb_photos_suppr on storage.objects;
create policy exb_photos_suppr on storage.objects for delete to authenticated
 using (bucket_id='exb-photos' and est_membre(((storage.foldername(name))[1])::uuid,array['admin']));

-- 2) RÉCURRENCE : crée l'intervention suivante de toute intervention « terminée » récurrente, sans doublon.
create or replace function exb_generer_recurrences(p_org uuid default null) returns int
language plpgsql security definer set search_path=public as $$
declare r record; n int:=0; m int; nd date; nid text;
begin
 -- appelée par un utilisateur : limitée à son organisation ; appelée par pg_cron (auth.uid() nul) : toutes
 if auth.uid() is not null then
   if p_org is null or not est_membre(p_org,array['admin','editeur']) then raise exception 'accès refusé'; end if;
 end if;
 for r in select * from enregistrements
   where collection='facility_workorders' and not supprime
     and (p_org is null or org_id=p_org)
     and data->>'status'='terminée'
     and coalesce((data->>'next_generated')::boolean,false)=false
     and coalesce(data->>'due_date','')<>''
     and data->>'recurrence' in ('mensuelle','trimestrielle','semestrielle','annuelle')
 loop
   m:=case r.data->>'recurrence' when 'mensuelle' then 1 when 'trimestrielle' then 3 when 'semestrielle' then 6 else 12 end;
   begin nd:=((r.data->>'due_date')::date + make_interval(months=>m))::date; exception when others then continue; end;
   -- doublon : une intervention issue de celle-ci existe déjà
   if not exists(select 1 from enregistrements e where e.org_id=r.org_id and e.collection='facility_workorders'
        and not e.supprime and e.data->>'generated_from'=r.id) then
     nid:='FM-'||to_char(extract(epoch from clock_timestamp())::bigint,'FM999999999999')||'-'||substr(md5(random()::text),1,5);
     insert into enregistrements(org_id,collection,id,data)
     values(r.org_id,'facility_workorders',nid,
       (r.data - 'photos') || jsonb_build_object('id',nid,'status','à faire','due_date',to_char(nd,'YYYY-MM-DD'),
         'photos','[]'::jsonb,'next_generated',false,'generated_from',r.id));
     n:=n+1;
   end if;
   update enregistrements set data=data||'{"next_generated":true}'::jsonb, version=version+1, maj=now()
    where org_id=r.org_id and collection=r.collection and id=r.id;
 end loop;
 return n;
end $$;
grant execute on function exb_generer_recurrences(uuid) to authenticated;

-- Tâche de fond quotidienne (facultatif) : Database > Extensions > activer « pg_cron », puis décommenter :
-- select cron.schedule('exb-recurrences','0 5 * * *','select exb_generer_recurrences()');
