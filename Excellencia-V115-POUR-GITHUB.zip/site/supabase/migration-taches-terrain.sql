-- Excellencia Building — droits par fonction pour les tâches terrain (collection « taches_terrain »).
-- À exécuter UNE fois après migration-v75-droits-v69-v74.sql. Réexécutable sans danger.
-- NON exécuté sur un vrai Supabase : essayer d'abord sur un projet de recette.
insert into droits_fonction(fonction,collection,lire,ecrire) values
 ('direction','taches_terrain',true,true),
 ('chef_projet','taches_terrain',true,true),
 ('conducteur','taches_terrain',true,true),
 ('bureau_etudes','taches_terrain',true,false),
 ('comptable','taches_terrain',false,false),
 ('magasinier','taches_terrain',false,false)
on conflict (fonction,collection) do nothing;
