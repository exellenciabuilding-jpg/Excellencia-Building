-- Excellencia Building V110h — Espace formateur : présences, suivi des apprenants, rapports de séance, messagerie.
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v103-espace-formateur.sql (fonction _formateur_ok, session « __formateur » publiée par 📢 Publier l'espace formateur)
--             et migration-v99zzv-tfl-sujets.sql (fonction tfl_sujets_admin_ok, utilisée pour réserver la lecture à l'administration).
--
-- Une seule table « formateur_retours » reçoit ce que le formateur saisit dans son espace :
--   presence : une ligne par (séance, apprenant)        data = {statut: P|A|R|E, formation, date, module}
--   note     : une ligne par (formation/module, apprenant) data = {note 0-20, progression 0-100, observation, formation, module}
--   rapport  : une ligne par séance                      data = {realisee, contenu, observations, duree, formation, date, module}
--   message  : message du formateur à l'administration   data = {objet, texte}
--   reponse  : réponse de l'administration au formateur  data = {texte}
-- Sécurité : table fermée (RLS sans politique, droits retirés) ; tout passe par des fonctions security definer.
-- Le formateur doit avoir changé son mot de passe ET figurer dans la session « __formateur » ; pour les présences et notes,
-- l'apprenant doit figurer dans la liste publiée pour CE formateur.

create table if not exists public.formateur_retours (
  id bigint generated always as identity primary key,
  matricule text not null,
  nom text,
  type text not null check (type in ('presence','note','rapport','message','reponse')),
  cle text not null,
  apprenant text not null default '',
  data jsonb not null default '{}'::jsonb,
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now(),
  recu boolean not null default false
);
create unique index if not exists formateur_retours_uniq on public.formateur_retours (matricule, type, cle, apprenant);
create index if not exists formateur_retours_recu on public.formateur_retours (recu, id);
alter table public.formateur_retours enable row level security;
revoke all on public.formateur_retours from anon, authenticated;

-- Le formateur enregistre (ou met à jour) une ligne.
create or replace function public.formateur_retour_enregistrer(p_matricule text, p_mdp text, p_type text, p_cle text, p_apprenant text, p_data jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare m text := public._formateur_ok(p_matricule, p_mdp); nm text; app text := coalesce(btrim(p_apprenant), ''); st text; nb numeric; pr numeric; d jsonb;
begin
  if m is null then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  if p_type not in ('presence','note','rapport','message') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if p_cle is null or length(btrim(p_cle)) = 0 or length(p_cle) > 200 then return jsonb_build_object('ok', false, 'code', 'cle'); end if;
  if jsonb_typeof(p_data) is distinct from 'object' or length(p_data::text) > 6000 then return jsonb_build_object('ok', false, 'code', 'donnees'); end if;
  if length(app) > 30 then return jsonb_build_object('ok', false, 'code', 'apprenant'); end if;

  if p_type in ('presence','note') then
    if app = '' or not exists (
      select 1 from public.resultats_publies r, jsonb_array_elements(coalesce(r.donnees->'apprenants','[]'::jsonb)) a
       where r.matricule = m and r.session = '__formateur' and public._exb_n(a->>'matricule') = public._exb_n(app)) then
      return jsonb_build_object('ok', false, 'code', 'apprenant');
    end if;
    app := public._exb_n(app);
  else
    app := '';
  end if;

  if p_type = 'presence' then
    st := p_data->>'statut';
    if st is null or st not in ('P','A','R','E') then return jsonb_build_object('ok', false, 'code', 'donnees'); end if;
    d := jsonb_build_object('statut', st, 'formation', left(coalesce(p_data->>'formation',''),200), 'date', left(coalesce(p_data->>'date',''),10), 'module', left(coalesce(p_data->>'module',''),200));
  elsif p_type = 'note' then
    nb := case when coalesce(p_data->>'note','') ~ '^\d+(\.\d+)?$' then (p_data->>'note')::numeric else null end;
    pr := case when coalesce(p_data->>'progression','') ~ '^\d+(\.\d+)?$' then (p_data->>'progression')::numeric else null end;
    if (nb is not null and nb > 20) or (pr is not null and pr > 100) then return jsonb_build_object('ok', false, 'code', 'donnees'); end if;
    d := jsonb_build_object('note', nb, 'progression', pr, 'observation', left(btrim(coalesce(p_data->>'observation','')), 1500), 'formation', left(coalesce(p_data->>'formation',''),200), 'module', left(coalesce(p_data->>'module',''),200));
  elsif p_type = 'rapport' then
    d := jsonb_build_object('realisee', coalesce((p_data->>'realisee')::boolean, true), 'contenu', left(btrim(coalesce(p_data->>'contenu','')), 3000), 'observations', left(btrim(coalesce(p_data->>'observations','')), 2000), 'duree', left(coalesce(p_data->>'duree',''), 30), 'formation', left(coalesce(p_data->>'formation',''),200), 'date', left(coalesce(p_data->>'date',''),10), 'module', left(coalesce(p_data->>'module',''),200));
  else
    if length(btrim(coalesce(p_data->>'texte',''))) < 2 then return jsonb_build_object('ok', false, 'code', 'donnees'); end if;
    if (select count(*) from public.formateur_retours where matricule = m and type = 'message' and cree_le > now() - interval '1 hour') >= 20 then
      return jsonb_build_object('ok', false, 'code', 'limite');
    end if;
    d := jsonb_build_object('objet', left(coalesce(p_data->>'objet','Question générale'),80), 'texte', left(btrim(p_data->>'texte'), 1500));
  end if;

  select nom into nm from public.apprenants_acces where matricule = m;
  insert into public.formateur_retours(matricule, nom, type, cle, apprenant, data)
  values (m, nm, p_type, left(btrim(p_cle), 200), app, d)
  on conflict (matricule, type, cle, apprenant) do update set data = excluded.data, maj_le = now(), recu = false;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.formateur_retour_enregistrer(text, text, text, text, text, jsonb) from public;
grant execute on function public.formateur_retour_enregistrer(text, text, text, text, text, jsonb) to anon, authenticated;

-- Le formateur relit ce qu'il a saisi + les réponses de l'administration (jamais celles des autres).
create or replace function public.formateur_retours_lister(p_matricule text, p_mdp text)
 returns jsonb language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare m text := public._formateur_ok(p_matricule, p_mdp);
begin
  if m is null then return jsonb_build_object('ok', false, 'code', 'invalides'); end if;
  return jsonb_build_object('ok', true, 'lignes', coalesce((
    select jsonb_agg(jsonb_build_object('id', x.id, 'type', x.type, 'cle', x.cle, 'apprenant', x.apprenant, 'data', x.data, 'maj_le', x.maj_le) order by x.id)
      from (select * from public.formateur_retours where matricule = m order by id desc limit 1500) x), '[]'::jsonb));
end $$;
revoke all on function public.formateur_retours_lister(text, text) from public;
grant execute on function public.formateur_retours_lister(text, text) to anon, authenticated;

-- Administration : lire les retours non encore repris, les marquer reçus, répondre à un formateur.
create or replace function public.formateur_retours_recus()
 returns table(id bigint, matricule text, nom text, type text, cle text, apprenant text, data jsonb, maj_le timestamptz)
 language plpgsql security definer set search_path to 'public' as $$
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  return query select r.id, r.matricule, r.nom, r.type, r.cle, r.apprenant, r.data, r.maj_le
                 from public.formateur_retours r where not r.recu and r.type <> 'reponse' order by r.id;
end $$;
revoke all on function public.formateur_retours_recus() from public, anon;
grant execute on function public.formateur_retours_recus() to authenticated;

create or replace function public.formateur_retours_marquer(p_ids bigint[])
 returns void language plpgsql security definer set search_path to 'public' as $$
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  update public.formateur_retours set recu = true where id = any(p_ids);
end $$;
revoke all on function public.formateur_retours_marquer(bigint[]) from public, anon;
grant execute on function public.formateur_retours_marquer(bigint[]) to authenticated;

create or replace function public.formateur_repondre(p_matricule text, p_texte text)
 returns void language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare m text := public._exb_n(p_matricule); nm text;
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  if length(btrim(coalesce(p_texte,''))) < 1 then raise exception 'message vide'; end if;
  select nom into nm from public.apprenants_acces where matricule = m;
  insert into public.formateur_retours(matricule, nom, type, cle, apprenant, data, recu)
  values (m, nm, 'reponse', gen_random_uuid()::text, '', jsonb_build_object('texte', left(btrim(p_texte), 1500)), true);
end $$;
revoke all on function public.formateur_repondre(text, text) from public, anon;
grant execute on function public.formateur_repondre(text, text) to authenticated;

-- Contrôle : select proname from pg_proc where proname like 'formateur_retour%' or proname = 'formateur_repondre';  → 5 lignes
-- Contrôle : select tablename, rowsecurity from pg_tables where tablename = 'formateur_retours';  → true
