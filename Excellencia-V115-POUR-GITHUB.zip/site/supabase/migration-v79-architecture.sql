-- Excellencia Building V79 — droits pour la collection « phases » (phases de mission, honoraires, heures). À exécuter UNE fois après migration-v78. Réexécutable.
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','phases',true,true),('chef_projet','phases',true,true),('bureau_etudes','phases',true,true),('comptable','phases',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
