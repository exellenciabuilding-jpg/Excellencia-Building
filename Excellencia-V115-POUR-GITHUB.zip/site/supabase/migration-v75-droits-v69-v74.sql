-- Excellencia Building V75 — droits par fonction pour les modules V69 à V74 (remplace les migrations v69 à v74).
-- À exécuter UNE fois après migration-v66-roles.sql (et v67, v68). Réexécutable sans danger.
-- Colonnes réelles de droits_fonction : fonction, collection, lire, ecrire.
-- Collections (= noms utilisés par exb-db.js) :
--   V69 : price_library, estimates, benchmarks, ai_notes
--   V70 : plans_coupes_structure     V71/V72 : drawing_sheets, drawing_sets
--   V74 : facility_assets, facility_workorders, facility_contracts, facility_warranties, facility_inspections
-- Les rôles 'polyvalent', 'rh' ne sont pas listés pour les plans/maintenance : 'polyvalent' a déjà tous les accès, 'rh' n'a pas lieu d'y accéder.

with droits(fonction, collection, lire, ecrire) as (values
 -- Direction : lit et modifie tout
 ('direction','price_library',true,true),('direction','estimates',true,true),('direction','benchmarks',true,true),('direction','ai_notes',true,true),
 ('direction','plans_coupes_structure',true,true),('direction','drawing_sheets',true,true),('direction','drawing_sets',true,true),
 ('direction','facility_assets',true,true),('direction','facility_workorders',true,true),('direction','facility_contracts',true,true),('direction','facility_warranties',true,true),('direction','facility_inspections',true,true),
 -- Chef de projet
 ('chef_projet','price_library',true,true),('chef_projet','estimates',true,true),('chef_projet','benchmarks',true,true),('chef_projet','ai_notes',true,true),
 ('chef_projet','plans_coupes_structure',true,true),('chef_projet','drawing_sheets',true,true),('chef_projet','drawing_sets',true,true),
 ('chef_projet','facility_assets',true,true),('chef_projet','facility_workorders',true,true),('chef_projet','facility_contracts',true,true),('chef_projet','facility_warranties',true,true),('chef_projet','facility_inspections',true,true),
 -- Conducteur de travaux : estimations en lecture, plans et maintenance en écriture
 ('conducteur','price_library',true,false),('conducteur','estimates',true,false),('conducteur','benchmarks',true,false),('conducteur','ai_notes',true,true),
 ('conducteur','plans_coupes_structure',true,true),('conducteur','drawing_sheets',true,true),('conducteur','drawing_sets',true,true),
 ('conducteur','facility_assets',true,true),('conducteur','facility_workorders',true,true),('conducteur','facility_contracts',true,false),('conducteur','facility_warranties',true,false),('conducteur','facility_inspections',true,true),
 -- Bureau d'études : plans en écriture, prix en lecture
 ('bureau_etudes','price_library',true,true),('bureau_etudes','estimates',true,true),('bureau_etudes','benchmarks',true,false),('bureau_etudes','ai_notes',true,true),
 ('bureau_etudes','plans_coupes_structure',true,true),('bureau_etudes','drawing_sheets',true,true),('bureau_etudes','drawing_sets',true,true),
 ('bureau_etudes','facility_assets',true,false),('bureau_etudes','facility_workorders',true,false),('bureau_etudes','facility_contracts',false,false),('bureau_etudes','facility_warranties',true,false),('bureau_etudes','facility_inspections',true,false),
 -- Comptable : prix/estimations/contrats en écriture, plans en lecture
 ('comptable','price_library',true,true),('comptable','estimates',true,true),('comptable','benchmarks',true,true),('comptable','ai_notes',false,false),
 ('comptable','plans_coupes_structure',true,false),('comptable','drawing_sheets',true,false),('comptable','drawing_sets',true,false),
 ('comptable','facility_assets',true,false),('comptable','facility_workorders',true,false),('comptable','facility_contracts',true,true),('comptable','facility_warranties',true,true),('comptable','facility_inspections',true,false),
 -- Magasinier : lecture des plans, maintenance des équipements
 ('magasinier','price_library',true,false),('magasinier','estimates',false,false),('magasinier','benchmarks',false,false),('magasinier','ai_notes',false,false),
 ('magasinier','plans_coupes_structure',true,false),('magasinier','drawing_sheets',true,false),('magasinier','drawing_sets',true,false),
 ('magasinier','facility_assets',true,true),('magasinier','facility_workorders',true,true),('magasinier','facility_contracts',true,false),('magasinier','facility_warranties',true,false),('magasinier','facility_inspections',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;   -- vos droits déjà personnalisés sont conservés

-- Nettoyage des lignes erronées éventuellement créées par d'anciennes migrations V70-V72 (colonnes différentes => normalement jamais insérées)
delete from droits_fonction where collection in ('plans_pdf');
