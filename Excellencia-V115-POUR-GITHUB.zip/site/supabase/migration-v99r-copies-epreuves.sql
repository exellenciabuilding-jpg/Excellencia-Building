-- Excellencia Building V99r — QR de vérification des copies d'épreuves (TD / TP / examens).
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99o-qr-public.sql. Réexécutable sans danger.
-- Prérequis : les tables « epreuves » et « reponses » (script supabase-epreuves.sql déjà exécuté chez vous).
--
-- Sécurité : la déclaration est VÉRIFIÉE par le serveur. Elle n'est acceptée que si une copie a réellement été remise
-- (ligne dans « reponses » pour ce matricule et cette épreuve). Le numéro, le titre de l'épreuve, la date de remise et le nom
-- viennent du serveur, jamais du navigateur. La première déclaration fait foi (aucune seconde version possible).
-- Aucune donnée de contact n'est stockée. Le QR atteste la REMISE de la copie, pas la note.

alter table public.exb_doc_registry drop constraint if exists exb_doc_registry_kind_check;
alter table public.exb_doc_registry add constraint exb_doc_registry_kind_check
  check (kind in ('devis','facture','recu','certificat','recu_formation','inscription','document','copie'));

create or replace function public.exb_doc_declare_copie(p_data jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_ep   text := left(btrim(coalesce(p_data->>'epreuve_id','')),80);
  v_mat  text := regexp_replace(coalesce(p_data->>'matricule',''),'\s','','g');
  v_hash text := left(btrim(coalesce(p_data->>'hash','')),20);
  v_emp  text := lower(coalesce(p_data->>'emp',''));
  v_no   text; v_nom text := ''; v_lib text; v_det text;
  rp record; ep record; ex public.exb_doc_registry;
begin
  if length(v_ep) < 8 or length(v_mat) < 3 or length(v_hash) < 6 then raise exception 'donnees_invalides'; end if;

  -- 1) une copie a-t-elle réellement été remise ?
  select r.created_at into rp from public.reponses r
   where r.epreuve_id::text = v_ep and regexp_replace(coalesce(r.matricule,''),'\s','','g') = v_mat
   order by r.created_at desc limit 1;
  if not found then raise exception 'copie_introuvable'; end if;

  select e.title, e.type into ep from public.epreuves e where e.id::text = v_ep;
  v_no  := 'COP-' || v_mat || '-' || upper(left(regexp_replace(v_ep,'[^A-Za-z0-9]','','g'),6));
  v_lib := left(coalesce(nullif(ep.type,'') || ' — ', '') || coalesce(ep.title,''), 200);

  -- 2) nom de l'apprenant : repris du registre (fiche d'inscription, reçu ou certificat du même matricule)
  select g.nom into v_nom from public.exb_doc_registry g
   where upper(g.matricule) = upper(v_mat) and coalesce(g.nom,'') <> '' and g.kind in ('inscription','recu_formation','certificat')
   order by g.created_at desc limit 1;
  v_nom := coalesce(v_nom,'');

  -- 3) première déclaration = référence
  select * into ex from public.exb_doc_registry where no = v_no and kind = 'copie' order by created_at asc limit 1;
  if not found then
    if (select count(*) from public.exb_doc_registry where kind = 'copie' and created_at > now() - interval '1 hour') >= 600 then raise exception 'trop_de_demandes'; end if;
    v_det := 'Copie remise le ' || to_char(rp.created_at at time zone 'Africa/Kinshasa','DD/MM/YYYY HH24:MI')
          || case when v_emp ~ '^[0-9a-f]{10}$' then ' · Empreinte des réponses ' || upper(v_emp) else '' end;
    insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail)
    values (v_no, v_hash, 'copie', (rp.created_at at time zone 'Africa/Kinshasa')::date, 0, '', 'soumise', left(v_nom,120), v_mat, v_lib, v_det)
    on conflict (no, hash) do nothing;
    select * into ex from public.exb_doc_registry where no = v_no and kind = 'copie' order by created_at asc limit 1;
  elsif coalesce(ex.nom,'') = '' and v_nom <> '' then
    update public.exb_doc_registry set nom = left(v_nom,120) where no = ex.no and hash = ex.hash;
  end if;

  return jsonb_build_object('ok', true, 'no', ex.no, 'hash', ex.hash, 'nom', v_nom,
                            'emp', lower(substring(ex.detail from 'Empreinte des réponses ([0-9A-Fa-f]{10})')));
exception when invalid_text_representation or invalid_datetime_format then raise exception 'donnees_invalides';
end $$;
grant execute on function public.exb_doc_declare_copie(jsonb) to anon, authenticated;
