-- Excellencia Building V98 (version unifiée) — alignement des noms de fonctions dans droits_fonction.
-- Les migrations V90 et V92 ont déclaré des droits pour « ressources humaines », « chef de projet » et « conducteur travaux »,
-- alors que le noyau (V66) utilise rh, chef_projet et conducteur : ces droits n'étaient donc jamais appliqués.
-- Cette migration COPIE ces droits vers les noms réellement utilisés. Elle n'écrase jamais un droit déjà défini
-- (ex. la paie de migration-v81-gestion.sql). À exécuter UNE fois, après toutes les autres migrations. Réexécutable.
insert into droits_fonction(fonction,collection,lire,ecrire)
select m.nouveau, d.collection, d.lire, d.ecrire
from droits_fonction d
join (values ('ressources humaines','rh'),('chef de projet','chef_projet'),('conducteur travaux','conducteur')) as m(ancien,nouveau)
  on d.fonction = m.ancien
on conflict (fonction,collection) do nothing;
