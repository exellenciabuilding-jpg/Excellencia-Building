-- EXCELLENCIA BUILDING V91 CORE ENTERPRISE
-- À exécuter après schema-entreprise.sql et migration-v90-enterprise.sql.
-- Les événements Core restent compatibles avec le journal existant.

create table if not exists core_notifications(
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organisations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null default 'info',
  title text not null,
  payload jsonb not null default '{}'::jsonb,
  lu boolean not null default false,
  cree_le timestamptz not null default now()
);
create index if not exists core_notifications_user_idx on core_notifications(org_id,user_id,lu,cree_le desc);

create table if not exists core_organisation_settings(
  org_id uuid primary key references organisations(id) on delete cascade,
  devise_principale text not null default 'USD',
  fuseau text not null default 'Africa/Kinshasa',
  langue text not null default 'fr',
  format_date text not null default 'DD/MM/YYYY',
  parametres jsonb not null default '{}'::jsonb,
  maj timestamptz not null default now(),
  maj_par uuid
);

alter table core_notifications enable row level security;
alter table core_organisation_settings enable row level security;

drop policy if exists core_notif_lire on core_notifications;
create policy core_notif_lire on core_notifications for select using (est_membre(org_id) and user_id=auth.uid());
drop policy if exists core_notif_ecrire on core_notifications;
create policy core_notif_ecrire on core_notifications for insert with check (est_membre(org_id,array['admin','editeur']) and user_id=auth.uid());
drop policy if exists core_notif_modif on core_notifications;
create policy core_notif_modif on core_notifications for update using (est_membre(org_id) and user_id=auth.uid()) with check (est_membre(org_id) and user_id=auth.uid());

drop policy if exists core_org_settings_lire on core_organisation_settings;
create policy core_org_settings_lire on core_organisation_settings for select using (est_membre(org_id));
drop policy if exists core_org_settings_modif on core_organisation_settings;
create policy core_org_settings_modif on core_organisation_settings for all using (est_membre(org_id,array['admin'])) with check (est_membre(org_id,array['admin']));

create or replace function core_creer_notification(p_org uuid,p_user uuid,p_type text,p_title text,p_payload jsonb default '{}'::jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare n uuid;
begin
  if not est_membre(p_org,array['admin','editeur']) then raise exception 'droits insuffisants'; end if;
  insert into core_notifications(org_id,user_id,type,title,payload) values(p_org,p_user,coalesce(p_type,'info'),p_title,coalesce(p_payload,'{}'::jsonb)) returning id into n;
  return n;
end $$;

create or replace function core_marquer_notification_lue(p_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  update core_notifications set lu=true where id=p_id and user_id=auth.uid();
  return found;
end $$;

grant execute on function core_creer_notification(uuid,uuid,text,text,jsonb), core_marquer_notification_lue(uuid) to authenticated;
