-- Excellencia Building V78 — droits pour la collection « finance » (devis, situations, factures, paiements, taux en USD/FC).
-- À exécuter UNE fois après migration-v75. Réexécutable. Données financières : accès réservé à la direction et à la comptabilité en écriture.
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','finance',true,true),('comptable','finance',true,true),('chef_projet','finance',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
