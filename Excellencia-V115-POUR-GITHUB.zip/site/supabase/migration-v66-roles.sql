-- ===== Excellencia Building — V66 : DROITS PAR FONCTION (rôles métier) =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run, APRÈS schema-entreprise.sql.
-- Réexécutable sans danger : les droits déjà personnalisés dans « droits_fonction » sont conservés.
--
-- PRINCIPE
--  · Le rôle existant (admin / editeur / lecteur) reste le plafond : un lecteur ne modifie jamais rien.
--  · La FONCTION précise ce que chaque membre voit et modifie, fiche par fiche (collection par collection).
--  · Fonction « polyvalent » (valeur par défaut) = comportement d'avant la V66 : aucun membre existant n'est bloqué.
--  · L'administrateur voit et modifie tout, quelle que soit sa fonction.
--  · Les droits sont appliqués par le SERVEUR : masquer un menu dans le navigateur n'est pas la seule protection.

alter table membres add column if not exists fonction text not null default 'polyvalent';
alter table membres drop constraint if exists membres_fonction_chk;
alter table membres add constraint membres_fonction_chk check (fonction in
  ('polyvalent','direction','chef_projet','conducteur','bureau_etudes','comptable','rh','magasinier'));

create table if not exists droits_fonction(
  fonction text not null, collection text not null,
  lire boolean not null default false, ecrire boolean not null default false,
  primary key(fonction,collection));
alter table droits_fonction enable row level security;
drop policy if exists df_lire on droits_fonction;
create policy df_lire on droits_fonction for select to authenticated using (true);
-- Aucune écriture par les clients : seul le propriétaire de la base (SQL Editor) modifie cette matrice.

insert into droits_fonction(fonction,collection,lire,ecrire) values
('direction','clients',true,true),
('direction','projets',true,true),
('direction','devis',true,true),
('direction','stock',true,false),
('direction','mouvements',true,false),
('direction','personnel',true,false),
('direction','caisse',true,false),
('direction','etudes',true,false),
('direction','communication',true,true),
('direction','documents',true,true),
('direction','metres',true,false),
('direction','factures',true,false),
('direction','fournisseurs',true,false),
('direction','commandes',true,false),
('direction','journal',true,false),
('direction','pointages',true,false),
('direction','situations',true,false),
('direction','notes_calcul',true,false),
('direction','plans',true,false),
('direction','missions_be',true,false),
('direction','heures_be',true,false),
('direction','planning_chantier',true,true),
('direction','budgets_chantier',true,true),
('chef_projet','clients',true,true),
('chef_projet','projets',true,true),
('chef_projet','devis',true,true),
('chef_projet','stock',true,false),
('chef_projet','mouvements',true,false),
('chef_projet','etudes',true,false),
('chef_projet','communication',true,true),
('chef_projet','documents',true,true),
('chef_projet','metres',true,true),
('chef_projet','factures',true,false),
('chef_projet','fournisseurs',true,true),
('chef_projet','commandes',true,true),
('chef_projet','journal',true,true),
('chef_projet','pointages',true,true),
('chef_projet','situations',true,true),
('chef_projet','notes_calcul',true,false),
('chef_projet','plans',true,true),
('chef_projet','missions_be',true,false),
('chef_projet','heures_be',true,false),
('chef_projet','planning_chantier',true,true),
('chef_projet','budgets_chantier',true,true),
('conducteur','clients',true,false),
('conducteur','projets',true,false),
('conducteur','devis',true,false),
('conducteur','stock',true,true),
('conducteur','mouvements',true,true),
('conducteur','documents',true,true),
('conducteur','metres',true,false),
('conducteur','fournisseurs',true,false),
('conducteur','commandes',true,true),
('conducteur','journal',true,true),
('conducteur','pointages',true,true),
('conducteur','situations',true,true),
('conducteur','plans',true,false),
('conducteur','planning_chantier',true,true),
('conducteur','budgets_chantier',true,false),
('bureau_etudes','clients',true,false),
('bureau_etudes','projets',true,false),
('bureau_etudes','devis',true,false),
('bureau_etudes','etudes',true,true),
('bureau_etudes','documents',true,true),
('bureau_etudes','metres',true,true),
('bureau_etudes','notes_calcul',true,true),
('bureau_etudes','plans',true,true),
('bureau_etudes','missions_be',true,true),
('bureau_etudes','heures_be',true,true),
('bureau_etudes','planning_chantier',true,false),
('comptable','clients',true,false),
('comptable','projets',true,false),
('comptable','devis',true,false),
('comptable','personnel',true,false),
('comptable','caisse',true,true),
('comptable','documents',true,true),
('comptable','factures',true,true),
('comptable','fournisseurs',true,true),
('comptable','commandes',true,true),
('comptable','pointages',true,true),
('comptable','situations',true,true),
('comptable','missions_be',true,true),
('comptable','heures_be',true,false),
('comptable','budgets_chantier',true,false),
('rh','projets',true,false),
('rh','personnel',true,true),
('rh','documents',true,true),
('rh','pointages',true,true),
('magasinier','projets',true,false),
('magasinier','stock',true,true),
('magasinier','mouvements',true,true),
('magasinier','documents',true,false),
('magasinier','fournisseurs',true,false),
('magasinier','commandes',true,true)
on conflict (fonction,collection) do nothing;

-- Droit de lecture / d'écriture d'un membre sur une collection.
create or replace function peut(p_org uuid, p_col text, p_ecrire boolean default false)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from membres m
    where m.org_id=p_org and m.user_id=auth.uid() and (
      m.role='admin'
      or (m.fonction='polyvalent' and (not p_ecrire or m.role='editeur'))
      or (m.fonction<>'polyvalent' and (not p_ecrire or m.role='editeur') and exists(
            select 1 from droits_fonction d
            where d.fonction=m.fonction and d.collection=p_col
              and (case when p_ecrire then d.ecrire else d.lire end)))
    )) $$;
grant execute on function peut(uuid,text,boolean) to authenticated;

-- La lecture des fiches est désormais filtrée par fonction.
drop policy if exists enr_lire on enregistrements;
create policy enr_lire on enregistrements for select using (peut(org_id,collection,false));

-- Écriture d'une fiche : même verrou de version qu'avant, plus le contrôle de fonction.
-- Un refus est renvoyé proprement (ok=false, refus=true) et journalisé.
create or replace function enregistrer(p_org uuid, p_col text, p_id text, p_data jsonb, p_base int, p_supprime boolean default false)
returns json language plpgsql security definer set search_path=public as $$
declare cur enregistrements; nv int;
begin
  if not peut(p_org,p_col,true) then
    insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version) values (p_org,auth.uid(),p_col,p_id,'refus',0);
    return json_build_object('ok',false,'refus',true);
  end if;
  select * into cur from enregistrements where org_id=p_org and collection=p_col and id=p_id for update;
  if found then
    if cur.version<>p_base then
      return json_build_object('ok',false,'conflit',true,'version',cur.version,'data',cur.data,'supprime',cur.supprime);
    end if;
    nv:=cur.version+1;
    update enregistrements set data=p_data,version=nv,supprime=p_supprime,maj=now(),maj_par=auth.uid()
      where org_id=p_org and collection=p_col and id=p_id;
  else
    if p_base<>0 then
      return json_build_object('ok',false,'conflit',true,'version',0,'data',null,'supprime',true);
    end if;
    nv:=1;
    insert into enregistrements(org_id,collection,id,data,version,supprime,maj_par) values (p_org,p_col,p_id,p_data,1,p_supprime,auth.uid());
  end if;
  insert into journal_entreprise(org_id,user_id,collection,rec_id,action,version)
    values (p_org,auth.uid(),p_col,p_id,case when p_supprime then 'suppression' when nv=1 then 'création' else 'modification' end,nv);
  return json_build_object('ok',true,'version',nv);
end $$;

-- Renvoie aussi la fonction du membre.
create or replace function mon_organisation()
returns json language sql stable security definer set search_path=public as $$
  select json_build_object('id',o.id,'nom',o.nom,'role',m.role,'fonction',m.fonction,
         'code',case when m.role='admin' then o.code_invitation end)
  from membres m join organisations o on o.id=m.org_id where m.user_id=auth.uid() order by m.depuis limit 1 $$;

create or replace function rejoindre_organisation(p_code text, p_nom_user text default null)
returns json language plpgsql security definer set search_path=public as $$
declare o organisations; r text; f text;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  select * into o from organisations where code_invitation=lower(trim(p_code));
  if not found then raise exception 'code invalide'; end if;
  insert into membres(org_id,user_id,nom,role) values (o.id,auth.uid(),p_nom_user,'editeur') on conflict do nothing;
  select role,fonction into r,f from membres where org_id=o.id and user_id=auth.uid();
  return json_build_object('id',o.id,'nom',o.nom,'role',r,'fonction',f);
end $$;

-- Documents (espace de stockage) : mêmes droits que la collection « documents ».
drop policy if exists doc_lire on storage.objects;
create policy doc_lire on storage.objects for select to authenticated
  using (bucket_id='documents' and peut(org_du_chemin(name),'documents',false));
drop policy if exists doc_ajout on storage.objects;
create policy doc_ajout on storage.objects for insert to authenticated
  with check (bucket_id='documents' and peut(org_du_chemin(name),'documents',true));
drop policy if exists doc_modif on storage.objects;
create policy doc_modif on storage.objects for update to authenticated
  using (bucket_id='documents' and peut(org_du_chemin(name),'documents',true));
drop policy if exists doc_suppr on storage.objects;
create policy doc_suppr on storage.objects for delete to authenticated
  using (bucket_id='documents' and peut(org_du_chemin(name),'documents',true));

-- Exemple pour changer un droit : update droits_fonction set ecrire=true where fonction='conducteur' and collection='factures';
