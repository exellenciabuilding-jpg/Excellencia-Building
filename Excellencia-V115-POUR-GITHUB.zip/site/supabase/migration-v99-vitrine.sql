-- Excellencia Building V99 — Site vitrine : photos et adresses publiées depuis le logiciel.
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger.
-- 1) Remplacez l'e-mail ci-dessous par celui de VOTRE compte administrateur (celui de la connexion au serveur).
--    Plusieurs e-mails possibles : array['a@x.com','b@y.com'] (en minuscules).
-- 2) Le bucket « vitrine » est PUBLIC en lecture (les visiteurs du site voient les photos) ;
--    seuls les e-mails listés peuvent ajouter, remplacer ou supprimer.

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('vitrine','vitrine',true,3145728,array['image/jpeg','image/png','image/webp','application/json'])
on conflict (id) do update set public=true, file_size_limit=excluded.file_size_limit, allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists vitrine_ecrire on storage.objects;
create policy vitrine_ecrire on storage.objects for insert to authenticated
 with check (bucket_id='vitrine' and lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com']));

drop policy if exists vitrine_modifier on storage.objects;
create policy vitrine_modifier on storage.objects for update to authenticated
 using (bucket_id='vitrine' and lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com']))
 with check (bucket_id='vitrine' and lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com']));

drop policy if exists vitrine_supprimer on storage.objects;
create policy vitrine_supprimer on storage.objects for delete to authenticated
 using (bucket_id='vitrine' and lower(auth.jwt()->>'email') = any(array['excellenciabuilding@gmail.com']));
