-- V115 — Pont logiciel central ↔ logiciel chantier : lien Projet central ⇄ Chantier terrain.
-- PRÉREQUIS : migration-chantier-comptes-sync-v67.sql (fonction exb_is_admin) déjà exécutée. Réexécutable.
alter table public.exb_sites add column if not exists central_project_id text;
alter table public.exb_field_expenses add column if not exists lot text;
alter table public.exb_field_journals add column if not exists signed_by text;
create index if not exists exb_sites_central_project_idx on public.exb_sites(central_project_id);

-- Lier (ou délier avec p_project = null) un chantier terrain à un projet du logiciel central.
create or replace function public.chantier_lier_projet(p_site uuid,p_project text) returns void
language plpgsql security definer set search_path=public as $$
begin
  if not public.exb_is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  update exb_sites set central_project_id=nullif(trim(p_project),'') where id=p_site;
end $$;

-- Liste des liens existants.
create or replace function public.chantier_liens() returns table(site_id uuid,project_id text)
language plpgsql security definer set search_path=public as $$
begin
  if not public.exb_is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  return query select id,central_project_id from exb_sites where central_project_id is not null;
end $$;

-- Données du chantier à reporter dans le projet central (avancement, budget, dépenses, rapports, pointage, matériaux).
create or replace function public.chantier_export_projet(p_site uuid) returns jsonb
language plpgsql security definer set search_path=public as $$
declare r jsonb;
begin
  if not public.exb_is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  select jsonb_build_object(
    'project_id',(select central_project_id from exb_sites where id=p_site),
    'meta',(select to_jsonb(m) from exb_field_site_meta m where m.site_id=p_site),
    'journaux',coalesce((select jsonb_agg(jsonb_build_object('id',j.local_event_id,'work_date',j.work_date,'weather',j.weather,'work_done',j.work_done,'staff',j.staff,'incidents',j.incidents,'progress',j.progress,'signed_by',j.signed_by) order by j.work_date desc)
       from (select * from exb_field_journals where site_id=p_site order by work_date desc limit 500) j),'[]'::jsonb),
    'expenses',coalesce((select jsonb_agg(jsonb_build_object('id',e.local_event_id,'category',e.category,'lot',e.lot,'label',e.label,'amount',e.amount,'created_at',e.created_at))
       from (select * from exb_field_expenses where site_id=p_site order by created_at desc limit 2000) e),'[]'::jsonb),
    'attendance',coalesce((select jsonb_agg(jsonb_build_object('id',a.local_event_id,'name',a.worker_name,'status',a.status,'date',a.attendance_date))
       from (select * from exb_field_attendance where site_id=p_site order by attendance_date desc limit 2000) a),'[]'::jsonb),
    'materials',coalesce((select jsonb_agg(jsonb_build_object('id',x.local_event_id,'item',x.item,'type',x.movement_type,'qty',x.quantity,'unit',x.unit,'created_at',x.created_at))
       from (select * from exb_field_materials where site_id=p_site order by created_at desc limit 2000) x),'[]'::jsonb)
  ) into r;
  return r;
end $$;

revoke all on function public.chantier_lier_projet(uuid,text),public.chantier_liens(),public.chantier_export_projet(uuid) from public;
grant execute on function public.chantier_lier_projet(uuid,text),public.chantier_liens(),public.chantier_export_projet(uuid) to authenticated;
-- Contrôle : select proname from pg_proc where proname in ('chantier_lier_projet','chantier_liens','chantier_export_projet'); → 3 lignes
