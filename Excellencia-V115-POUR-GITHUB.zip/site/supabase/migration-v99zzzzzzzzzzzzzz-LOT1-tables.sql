-- LOT 1/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
-- ============================================================================
-- V99zzzzzzzzzzzzzz — TFL : matricule AUTOMATIQUE à la soumission, suivi du statut par matricule,
-- formulaire ENCADREUR (sujets proposés), validation du sujet par l'encadreur.
-- À exécuter APRÈS migration-v99zzt-tfl-portails.sql et migration-v99zzzzzzzzzz-tfl-signature.sql (tfl_admin_ok, tfl_candidatures, tfl_messages).
-- ============================================================================

-- 1) Statuts consultables par matricule (une ligne par personne) ------------------------------------------
create table if not exists public.tfl_statuts (
  matricule text primary key,
  role text not null check (role in ('etudiant','encadreur')),
  nom text not null default '',
  tel_norm text not null default '',
  items jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists tfl_statuts_tel_idx on public.tfl_statuts (role, tel_norm);
alter table public.tfl_statuts enable row level security;
revoke all on public.tfl_statuts from public, anon, authenticated;

create table if not exists public.tfl_statut_essais (id bigserial primary key, cle text not null, created_at timestamptz not null default now());
create index if not exists tfl_statut_essais_idx on public.tfl_statut_essais (cle, created_at);
alter table public.tfl_statut_essais enable row level security;
revoke all on public.tfl_statut_essais from public, anon, authenticated;

-- Formulaires d'encadreurs (même principe que tfl_candidatures)
create table if not exists public.tfl_encadreurs_envois (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  submitted_at timestamptz,
  ref text not null default '',
  data jsonb not null,
  photo text,
  imported boolean not null default false,
  imported_at timestamptz
);
alter table public.tfl_encadreurs_envois enable row level security;
revoke all on public.tfl_encadreurs_envois from public, anon, authenticated;

-- le portail accepte le type « validation » (valeur 1 = validé, 2 = à corriger, 3 = refusé)
alter table public.tfl_messages drop constraint if exists tfl_messages_type_check;
alter table public.tfl_messages add constraint tfl_messages_type_check check (type in ('message','commentaire','progression','validation'));
