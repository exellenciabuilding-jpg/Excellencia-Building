-- LOT 7/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
-- 5) Publication des statuts par l'administrateur, consultation publique par matricule + téléphone ----------
create or replace function public.tfl_statut_publier(p_lot jsonb) returns int language plpgsql security definer set search_path = public as $$
declare x jsonb; n int := 0; v_tel text; v_mat text;
begin
  if not public.tfl_admin_ok() then raise exception 'non autorisé'; end if;
  if jsonb_typeof(p_lot) is distinct from 'array' then raise exception 'donnees_invalides'; end if;
  for x in select * from jsonb_array_elements(p_lot) loop
    v_mat := left(btrim(coalesce(x->>'matricule','')), 40); v_tel := regexp_replace(coalesce(x->>'tel',''), '\D', '', 'g');
    continue when v_mat = '' or x->>'role' not in ('etudiant','encadreur');
    insert into public.tfl_statuts(matricule, role, nom, tel_norm, items)
    values (v_mat, x->>'role', left(coalesce(x->>'nom',''), 120), v_tel, coalesce(x->'items','[]'::jsonb))
    on conflict (matricule) do update set role = excluded.role, nom = excluded.nom, tel_norm = case when excluded.tel_norm <> '' then excluded.tel_norm else public.tfl_statuts.tel_norm end,
      -- on garde les dépôts « reçus » pas encore traités (refs C-… / S-…), le reste est remplacé par l'état publié
      items = coalesce(excluded.items, '[]'::jsonb) || coalesce((select jsonb_agg(o) from jsonb_array_elements(public.tfl_statuts.items) o where o->>'ref' like 'C-%' or o->>'ref' like 'S-%'), '[]'::jsonb),
      updated_at = now();
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.tfl_statut_publier(jsonb) from public, anon;
grant execute on function public.tfl_statut_publier(jsonb) to authenticated;

create or replace function public.tfl_statut_consulter(p_matricule text, p_tel text) returns jsonb language plpgsql security definer set search_path = public as $$
declare v_m text := btrim(coalesce(p_matricule,'')); v_k text; v_t text := regexp_replace(coalesce(p_tel,''), '\D', '', 'g'); s public.tfl_statuts; v_nom text;
begin
  v_k := regexp_replace(v_m, '\D', '', 'g');
  delete from public.tfl_statut_essais where created_at < now() - interval '1 day';
  if length(v_k) < 6 or length(v_t) < 6 then return jsonb_build_object('ok', false, 'code', 'saisie'); end if;
  if (select count(*) from public.tfl_statut_essais where cle = v_k and created_at > now() - interval '15 minutes') >= 8
     or (select count(*) from public.tfl_statut_essais where created_at > now() - interval '15 minutes') >= 400 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  select * into s from public.tfl_statuts where regexp_replace(matricule, '\D', '', 'g') = v_k limit 1;
  if s.matricule is null or right(s.tel_norm, 6) <> right(v_t, 6) then
    insert into public.tfl_statut_essais(cle) values (v_k);
    return jsonb_build_object('ok', false, 'code', 'introuvable');
  end if;
  v_nom := split_part(s.nom, ' ', 1) || case when position(' ' in s.nom) > 0 then ' ' || left(split_part(s.nom, ' ', 2), 1) || '.' else '' end;
  return jsonb_build_object('ok', true, 'role', s.role, 'nom', v_nom, 'matricule', s.matricule, 'items', s.items, 'maj', s.updated_at);
end $$;
revoke all on function public.tfl_statut_consulter(text, text) from public;
grant execute on function public.tfl_statut_consulter(text, text) to anon, authenticated;

-- Contrôle : select proname from pg_proc where proname in ('tfl_statut_consulter','tfl_statut_publier','tfl_encadreur_envoyer','tfl_encadreurs_liste','tfl_encadreur_traiter','tfl_matricule_nouveau'); -- 6 lignes
-- Et : select tablename, rowsecurity from pg_tables where tablename in ('tfl_statuts','tfl_statut_essais','tfl_encadreurs_envois'); -- rowsecurity = true pour les trois
