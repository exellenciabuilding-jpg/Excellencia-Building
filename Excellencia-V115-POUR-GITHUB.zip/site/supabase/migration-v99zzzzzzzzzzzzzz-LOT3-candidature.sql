-- LOT 3/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
-- 3) Candidature, fiche, traitement et portail : versions mises à jour -------------------------------------
create or replace function public.tfl_candidature_envoyer(p_data jsonb, p_photo text default null, p_ref text default null, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_titre text := left(btrim(coalesce(p_data->>'sujet_titre','')), 250);
  v_prob text := left(btrim(coalesce(p_data->>'problematique','')), 3000);
  v_obj text := left(btrim(coalesce(p_data->>'objectifs','')), 3000);
  v_clean jsonb; v_id uuid; v_k text;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  if length(v_titre) < 3 or length(v_prob) < 3 or length(v_obj) < 3 then raise exception 'sujet_incomplet'; end if;
  if p_photo is not null and p_photo <> '' and (length(p_photo) > 390000 or p_photo !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$') then raise exception 'photo_trop_lourde'; end if;
  -- limite anti-spam : 200 candidatures par heure au total, 5 par numéro de téléphone et par heure
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  -- on ne garde que les champs attendus, tronqués
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere',''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', case when p_data->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then p_data->>'domaine' else 'autre' end,
    'sujet_titre', v_titre, 'problematique', v_prob, 'objectifs', v_obj,
    'methodologie', left(coalesce(p_data->>'methodologie',''), 3000),
    'recherches_deja', left(coalesce(p_data->>'recherches_deja',''), 3000),
    'encadreur_pressenti', left(coalesce(p_data->>'encadreur_pressenti',''), 150),
    'signature', case when length(coalesce(p_data->>'signature','')) between 100 and 150000 then
      (case when p_data->>'signature' ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$'
      then p_data->>'signature' else '' end) else '' end);
  -- renvoi du même envoi (réseau instable) : pas de doublon
  select id into v_id from public.tfl_candidatures
   where p_submitted is not null and submitted_at = p_submitted and data->>'telephone' = v_tel limit 1;
  if v_id is null then
    insert into public.tfl_candidatures(submitted_at, ref, data, photo)
    values (p_submitted, left(coalesce(p_ref,''), 40), v_clean, nullif(p_photo,'')) returning id into v_id;
  end if;
  return jsonb_build_object('ok', true, 'matricule', (select data->>'matricule_en_ligne' from public.tfl_candidatures where id = v_id));
end $$;
grant execute on function public.tfl_candidature_envoyer(jsonb, text, text, timestamptz) to anon, authenticated;
