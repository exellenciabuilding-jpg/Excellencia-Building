-- Excellencia Building V80 — droits pour la collection « cartouches » (infos projet du cartouche des plans). À exécuter UNE fois après migration-v79. Réexécutable.
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','cartouches',true,true),('chef_projet','cartouches',true,true),('bureau_etudes','cartouches',true,true),('conducteur','cartouches',true,false)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
