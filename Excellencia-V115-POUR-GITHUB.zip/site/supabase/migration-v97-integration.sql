-- Excellencia Building V97 — intégration globale
-- À exécuter après les migrations V91 à V94.
create table if not exists core_workflow_links(
 id uuid primary key default gen_random_uuid(), org_id uuid not null references organisations(id) on delete cascade,
 type text not null, source_id text, target_id text, payload jsonb not null default '{}'::jsonb,
 cree_le timestamptz not null default now()
);
create table if not exists formation_workflows(
 id uuid primary key default gen_random_uuid(), org_id uuid not null references organisations(id) on delete cascade,
 participant_id uuid, inscription_id uuid, stage text not null default 'learner', status text not null default 'active',
 payload jsonb not null default '{}'::jsonb, cree_le timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists ai_insights(
 id uuid primary key default gen_random_uuid(), org_id uuid not null references organisations(id) on delete cascade,
 kind text not null, source_type text, source_id text, confidence numeric(6,4),
 requires_human_validation boolean not null default true, status text not null default 'proposed',
 payload jsonb not null default '{}'::jsonb, cree_le timestamptz not null default now()
);
create table if not exists core_approval_queue(
 id uuid primary key default gen_random_uuid(), org_id uuid not null references organisations(id) on delete cascade,
 action_type text not null, source_type text, source_id text, requested_by uuid, status text not null default 'pending',
 payload jsonb not null default '{}'::jsonb, cree_le timestamptz not null default now(), decided_le timestamptz
);
create index if not exists core_workflow_links_org_idx on core_workflow_links(org_id,cree_le desc);
create index if not exists formation_workflows_org_stage_idx on formation_workflows(org_id,stage,updated_at desc);
create index if not exists ai_insights_org_status_idx on ai_insights(org_id,status,cree_le desc);
create index if not exists core_approval_queue_org_status_idx on core_approval_queue(org_id,status,cree_le desc);
do $$ declare t text; begin
 foreach t in array array['core_workflow_links','formation_workflows','ai_insights','core_approval_queue'] loop
  execute format('alter table %I enable row level security',t);
  execute format('drop policy if exists %I_lire on %I',t,t);
  execute format('create policy %I_lire on %I for select using (est_membre(org_id))',t,t);
  execute format('drop policy if exists %I_ecrire on %I',t,t);
  execute format('create policy %I_ecrire on %I for insert with check (est_membre(org_id,array[''admin'',''editeur'']))',t,t);
  execute format('drop policy if exists %I_modif on %I',t,t);
  execute format('create policy %I_modif on %I for update using (est_membre(org_id,array[''admin'',''editeur''])) with check (est_membre(org_id,array[''admin'',''editeur'']))',t,t);
 end loop;
end $$;
