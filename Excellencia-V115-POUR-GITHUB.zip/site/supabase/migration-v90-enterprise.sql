-- EXCELLENCIA BUILDING V90 ENTERPRISE
-- Réexécutable. Les nouvelles collections utilisent le registre partagé existant.
-- Exécuter après schema-entreprise.sql et les migrations V66+.
insert into droits_fonction(fonction,collection,lire,ecrire) values
('direction','achats',true,true),('direction','sous_traitants',true,true),('direction','dqe',true,true),('direction','contrats_rh',true,true),('direction','validations',true,true),('direction','signatures',true,true),('direction','cde_workflows',true,true),('direction','rapprochement_bancaire',true,true),('direction','paie',true,true),('direction','conformite',true,true),('direction','actifs_entreprise',true,true),('direction','plans_actions',true,true),
('chef de projet','achats',true,true),('chef de projet','sous_traitants',true,true),('chef de projet','dqe',true,true),('chef de projet','validations',true,true),('chef de projet','cde_workflows',true,true),('chef de projet','conformite',true,false),('chef de projet','plans_actions',true,true),
('conducteur travaux','achats',true,true),('conducteur travaux','sous_traitants',true,false),('conducteur travaux','dqe',true,false),('conducteur travaux','validations',true,true),('conducteur travaux','cde_workflows',true,true),('conducteur travaux','conformite',true,true),('conducteur travaux','plans_actions',true,true),
('bureau d’études','dqe',true,true),('bureau d’études','validations',true,true),('bureau d’études','cde_workflows',true,true),('bureau d’études','plans_actions',true,true),
('comptable','achats',true,true),('comptable','sous_traitants',true,true),('comptable','dqe',true,false),('comptable','validations',true,true),('comptable','rapprochement_bancaire',true,true),('comptable','paie',true,true),('comptable','conformite',true,false),
('ressources humaines','contrats_rh',true,true),('ressources humaines','paie',true,true),('ressources humaines','conformite',true,true),('ressources humaines','validations',true,false),
('magasinier','achats',true,true),('magasinier','conformite',true,false),
('polyvalent','achats',true,true),('polyvalent','sous_traitants',true,true),('polyvalent','dqe',true,true),('polyvalent','contrats_rh',true,true),('polyvalent','validations',true,true),('polyvalent','signatures',true,true),('polyvalent','cde_workflows',true,true),('polyvalent','rapprochement_bancaire',true,true),('polyvalent','paie',true,true),('polyvalent','conformite',true,true),('polyvalent','actifs_entreprise',true,true),('polyvalent','plans_actions',true,true)
on conflict (fonction,collection) do update set lire=excluded.lire,ecrire=excluded.ecrire;
