-- ===== Excellencia Building  V99zzj : ACTIVATION PAR CODE D'INVITATION SEUL =====
-- À exécuter UNE FOIS dans Supabase › SQL Editor › New query › Run. Réexécutable sans danger.
-- Prérequis : schema-entreprise.sql, migration-v99v-securite-licences.sql et migration-v99w-equipe.sql déjà exécutés.
--
-- Problème corrigé : un ami invité ouvrait le logiciel, voyait l'écran « Ce logiciel nécessite un code d'activation »,
-- saisissait son code d'invitation (ex. eaaa5313) et obtenait « Code invalide ou modifié » (ce sont deux codes différents).
-- Désormais : l'écran de verrouillage accepte le CODE D'INVITATION. Le serveur renvoie alors l'abonnement signé de
-- l'entreprise, l'appareil se déverrouille, puis l'invité crée son compte et rejoint l'entreprise automatiquement.

-- 1) Abonnement signé de l'entreprise (déposé par l'appareil administrateur, qui détient la clé privée).
alter table organisations add column if not exists jeton_equipe text;

-- 2) Journal des essais ratés (limite anti-devinette du code). Aucune lecture/écriture directe : fonctions seulement.
create table if not exists activations_invitation_essais(
  id bigserial primary key,
  essai_le timestamptz not null default now());
alter table activations_invitation_essais enable row level security;

-- 3) Enregistrer l'abonnement signé de l'entreprise (administrateur de l'entreprise uniquement).
create or replace function equipe_definir_jeton(p_org uuid, p_jeton text) returns json
language plpgsql security definer set search_path=public as $$
begin
  if not est_membre(p_org, array['admin']) then raise exception 'réservé à l''administrateur'; end if;
  if p_jeton is null or length(p_jeton) < 50 or length(p_jeton) > 4000 or position('.' in p_jeton) = 0 then
    raise exception 'abonnement invalide'; end if;
  update organisations set jeton_equipe = p_jeton where id = p_org;
  return json_build_object('ok', true);
end $$;

-- 4) Activation par code d'invitation : appelable SANS compte (l'invité n'en a pas encore).
--    Renvoie {ok:true, nom, jeton} ou {ok:false, msg}. Les échecs sont comptés (on ne lève pas d'exception,
--    sinon l'enregistrement de l'échec serait annulé). Limite : 40 échecs par tranche de 10 minutes.
create or replace function activer_par_invitation(p_code text) returns json
language plpgsql security definer set search_path=public as $$
declare c text; o organisations; tok text; stat text; a_lic boolean := false; fails int;
begin
  c := lower(trim(coalesce(p_code, '')));
  delete from activations_invitation_essais where essai_le < now() - interval '1 day';
  select count(*) into fails from activations_invitation_essais where essai_le > now() - interval '10 minutes';
  if fails >= 40 then
    return json_build_object('ok', false, 'msg', 'Trop d’essais. Réessayez dans quelques minutes.'); end if;
  if c !~ '^[a-z0-9]{4,32}$' then
    insert into activations_invitation_essais default values;
    return json_build_object('ok', false, 'msg', 'Code d’invitation invalide : 8 caractères (lettres et chiffres).'); end if;
  select * into o from organisations where code_invitation = c;
  if not found then
    insert into activations_invitation_essais default values;
    return json_build_object('ok', false, 'msg', 'Code d’invitation inconnu. Vérifiez-le auprès de la personne qui vous a invité(e).'); end if;
  if to_regclass('public.licences_clients') is not null then
    execute 'select statut, dernier_jeton from licences_clients where org_id=$1 order by cree_le desc limit 1'
      into stat, tok using o.id;
    a_lic := stat is not null;
    if a_lic and stat in ('suspendu', 'resilie') then
      return json_build_object('ok', false, 'msg', 'Abonnement suspendu : contactez l’administrateur du logiciel.'); end if;
  end if;
  tok := coalesce(tok, o.jeton_equipe);
  if tok is null then
    return json_build_object('ok', false, 'msg', 'Aucun abonnement n’est encore enregistré pour cette entreprise. Demandez à l’administrateur d’ouvrir le panneau « Équipe » sur son appareil, ou de vous envoyer un lien d’activation.'); end if;
  return json_build_object('ok', true, 'nom', o.nom, 'jeton', tok);
end $$;

revoke execute on function equipe_definir_jeton(uuid, text) from public, anon;
grant  execute on function equipe_definir_jeton(uuid, text) to authenticated;
revoke execute on function activer_par_invitation(text) from public;
grant  execute on function activer_par_invitation(text) to anon, authenticated;
