-- Excellencia Building — Plans envoyés au client (nouveau plan / plan modifié), avec information du client
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zzzzzzzzzzzzzzz-espace-client.sql. Réexécutable sans danger.
-- Principe : l'entreprise envoie un plan (PDF ou image, 6 Mo maximum) à un portail client. Si un plan du même titre existe déjà,
-- le nouvel envoi devient la « version N+1 » (plan MODIFIÉ) ; les anciennes versions restent consultables.
-- Le client est informé : bandeau « nouveau plan / plan modifié » à l'ouverture de son espace, message de l'entreprise dans sa
-- messagerie, et l'entreprise voit « vu le … » dès qu'il a ouvert le plan. Accès : compte client (session) ou lien + code.
-- Aucune table n'est lisible en direct : tout passe par les fonctions.

create table if not exists public.client_plans (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  lien_id uuid not null references public.portail_liens(id) on delete cascade,
  plan_ref text not null,
  titre text not null,
  version int not null default 1,
  note text,
  mime text not null,
  taille int not null,
  data text not null,
  publie_le timestamptz not null default now(),
  vu_le timestamptz,
  unique (lien_id, plan_ref, version)
);
create index if not exists client_plans_lien_idx on public.client_plans (lien_id, publie_le desc);
alter table public.client_plans enable row level security;
revoke all on public.client_plans from anon, authenticated;
-- Les membres autorisés lisent la liste SANS le contenu des fichiers.
grant select (id, org_id, lien_id, plan_ref, titre, version, note, mime, taille, publie_le, vu_le) on public.client_plans to authenticated;
drop policy if exists client_plans_org on public.client_plans;
create policy client_plans_org on public.client_plans for select to authenticated using (public.peut(org_id, 'portails', false));

-- ---------- Côté entreprise ----------
create or replace function public.client_plan_publier(p_org uuid, p_token text, p_titre text, p_note text, p_data text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare l public.portail_liens; v_titre text := left(btrim(coalesce(p_titre,'')), 160); v_ref text; v_ver int; v_mime text; v_id uuid;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  select * into l from public.portail_liens where token = p_token and org_id = p_org and kind = 'client';
  if not found then raise exception 'portail_introuvable'; end if;
  if length(v_titre) < 2 then raise exception 'titre_invalide'; end if;
  if p_data is null or p_data !~ '^data:(application/pdf|image/png|image/jpeg|image/webp);base64,[A-Za-z0-9+/=]+$' then raise exception 'fichier_invalide'; end if;
  if length(p_data) > 8400000 then raise exception 'fichier_trop_lourd'; end if;
  v_mime := substring(p_data from '^data:([a-z/]+);base64,');
  v_ref := lower(regexp_replace(v_titre, '\s+', ' ', 'g'));
  select coalesce(max(version), 0) + 1 into v_ver from public.client_plans where lien_id = l.id and plan_ref = v_ref;
  insert into public.client_plans(org_id, lien_id, plan_ref, titre, version, note, mime, taille, data)
  values (p_org, l.id, v_ref, v_titre, v_ver, left(btrim(coalesce(p_note,'')), 400), v_mime, (length(p_data) * 3 / 4)::int, p_data)
  returning id into v_id;
  -- le client est prévenu dans sa messagerie
  insert into public.portail_messages(lien_id, de, texte)
  values (l.id, 'entreprise', case when v_ver > 1 then '📐 Plan modifié : ' || v_titre || ' (version ' || v_ver || ').' else '📐 Nouveau plan : ' || v_titre || '.' end
          || case when btrim(coalesce(p_note,'')) <> '' then ' ' || left(btrim(p_note), 300) else '' end);
  return jsonb_build_object('ok', true, 'id', v_id, 'version', v_ver);
end $$;
revoke all on function public.client_plan_publier(uuid,text,text,text,text) from public, anon;
grant execute on function public.client_plan_publier(uuid,text,text,text,text) to authenticated;

create or replace function public.client_plan_retirer(p_org uuid, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  delete from public.client_plans where id = p_id and org_id = p_org;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.client_plan_retirer(uuid,uuid) from public, anon;
grant execute on function public.client_plan_retirer(uuid,uuid) to authenticated;

-- Liste pour l'entreprise : qui a reçu quoi, et si le client l'a ouvert.
create or replace function public.client_plans_suivi(p_org uuid)
returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', false) then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'token', l.token, 'titre', c.titre, 'version', c.version, 'publie_le', c.publie_le, 'vu_le', c.vu_le, 'taille', c.taille) order by c.publie_le desc)
    from public.client_plans c join public.portail_liens l on l.id = c.lien_id where c.org_id = p_org), '[]'::jsonb);
end $$;
revoke all on function public.client_plans_suivi(uuid) from public, anon;
grant execute on function public.client_plans_suivi(uuid) to authenticated;

-- ---------- Côté client (session de compte ou lien + code) ----------
create or replace function public.client_plans_liste(p_token text, p_code text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  return jsonb_build_object('ok', true, 'plans', coalesce((
    select jsonb_agg(jsonb_build_object('id', p.id, 'titre', p.titre, 'version', p.version, 'note', p.note, 'mime', p.mime, 'taille', p.taille,
             'publie_le', p.publie_le, 'nouveau', p.vu_le is null,
             'courant', p.version = (select max(q.version) from public.client_plans q where q.lien_id = p.lien_id and q.plan_ref = p.plan_ref))
           order by p.publie_le desc)
    from public.client_plans p where p.lien_id = c.v_id), '[]'::jsonb));
end $$;
revoke all on function public.client_plans_liste(text,text) from public;
grant execute on function public.client_plans_liste(text,text) to anon, authenticated;

create or replace function public.client_plan_lire(p_token text, p_code text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; p public.client_plans;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into p from public.client_plans where id = p_id and lien_id = c.v_id;
  if not found then return jsonb_build_object('ok', false, 'code', 'document'); end if;
  if p.vu_le is null then update public.client_plans set vu_le = now() where id = p.id; end if;
  return jsonb_build_object('ok', true, 'titre', p.titre, 'version', p.version, 'mime', p.mime, 'data', p.data);
end $$;
revoke all on function public.client_plan_lire(text,text,uuid) from public;
grant execute on function public.client_plan_lire(text,text,uuid) to anon, authenticated;

notify pgrst, 'reload schema';
