-- ===== Excellencia Building V99zzv — TFL : catalogue des sujets + « Choisir ce sujet » =====
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger.
-- Suppose migration-v99zzr-tfl-en-ligne.sql déjà exécutée (table tfl_candidatures) ; la table est recréée ici si absente.
-- PRINCIPE
--   · L'administrateur publie ses fiches depuis le module TFL (fonction tfl_sujets_publier).
--   · Le public (sans compte) lit les fiches publiées (tfl_sujets_publics) : aucun numéro de téléphone n'y figure.
--   · « Choisir ce sujet » (tfl_sujet_choisir) dépose une candidature dans tfl_candidatures (même boîte de réception
--     que le formulaire en ligne) avec la référence du sujet. Un sujet EXCLUSIF passe à « reserve » dès le premier choix :
--     un second étudiant reçoit « sujet_deja_reserve » tant que l'administrateur n'a pas décidé (libérer / attribuer / fermer).
--   · Personne ne lit la table tfl_sujets directement (RLS sans politique) ; tout passe par les fonctions ci-dessous.

create table if not exists public.tfl_candidatures (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  submitted_at timestamptz,
  ref text,
  data jsonb not null,
  photo text,
  imported boolean not null default false,
  imported_at timestamptz
);
alter table public.tfl_candidatures enable row level security;
revoke all on public.tfl_candidatures from anon, authenticated;

create table if not exists public.tfl_sujets (
  ref text primary key check (ref ~ '^[A-Za-z0-9._-]{3,40}$'),
  data jsonb not null,
  publie boolean not null default false,
  exclusif boolean not null default true,
  statut text not null default 'disponible' check (statut in ('disponible','reserve','attribue','ferme')),
  reserve_tel text,
  reserve_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.tfl_sujets enable row level security;
-- aucune politique : accès uniquement par les fonctions ci-dessous
revoke all on public.tfl_sujets from anon, authenticated;

-- Contrôle d'administrateur (mêmes e-mails que migration-v99m-verification.sql et migration-v99zzr).
create or replace function public.tfl_sujets_admin_ok()
returns boolean language sql stable security definer set search_path = public as $$
  select lower(coalesce(auth.jwt()->>'email','')) = any (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']);
$$;
revoke all on function public.tfl_sujets_admin_ok() from public, anon;
grant execute on function public.tfl_sujets_admin_ok() to authenticated;

-- ---------- Publication par l'administrateur ----------
-- p_sujets : tableau d'objets { ref, publie, exclusif, statut?, push_statut?, + champs de la fiche }.
-- Le statut du serveur n'est écrasé que si push_statut = true (décision de l'administrateur : libérer, attribuer, fermer).
-- Une réservation faite par un étudiant entre deux publications n'est donc jamais effacée par erreur.
create or replace function public.tfl_sujets_publier(p_sujets jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v jsonb; v_ref text; v_data jsonb; v_n int := 0; v_st text; v_push boolean;
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  if jsonb_typeof(p_sujets) is distinct from 'array' then raise exception 'donnees_invalides'; end if;
  if jsonb_array_length(p_sujets) > 300 then raise exception 'trop_de_sujets'; end if;
  for v in select * from jsonb_array_elements(p_sujets) loop
    v_ref := btrim(coalesce(v->>'ref',''));
    if v_ref !~ '^[A-Za-z0-9._-]{3,40}$' then raise exception 'reference_invalide'; end if;
    v_data := jsonb_build_object(
      'ref', v_ref,
      'titre', left(btrim(coalesce(v->>'titre','')), 250),
      'categorie', left(coalesce(v->>'categorie',''), 80),
      'filiere', left(coalesce(v->>'filiere',''), 100),
      'domaine', case when v->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then v->>'domaine' else 'autre' end,
      'niveau', left(coalesce(v->>'niveau',''), 60),
      'problematique', left(coalesce(v->>'problematique',''), 3000),
      'objectifs', left(coalesce(v->>'objectifs',''), 3000),
      'methodologie', left(coalesce(v->>'methodologie',''), 3000),
      'livrables', left(coalesce(v->>'livrables',''), 2000),
      'competences', left(coalesce(v->>'competences',''), 1000),
      'encadrement', left(coalesce(v->>'encadrement',''), 1000),
      'mots_cles', left(coalesce(v->>'mots_cles',''), 200));
    if length(v_data->>'titre') < 3 then raise exception 'titre_invalide'; end if;
    v_st := case when v->>'statut' in ('disponible','reserve','attribue','ferme') then v->>'statut' else 'disponible' end;
    v_push := coalesce((v->>'push_statut')::boolean, false);
    insert into public.tfl_sujets(ref, data, publie, exclusif, statut, updated_at)
    values (v_ref, v_data, coalesce((v->>'publie')::boolean, false), coalesce((v->>'exclusif')::boolean, true), v_st, now())
    on conflict (ref) do update set
      data = excluded.data, publie = excluded.publie, exclusif = excluded.exclusif, updated_at = now(),
      statut = case when v_push then excluded.statut else public.tfl_sujets.statut end,
      reserve_tel = case when v_push and excluded.statut = 'disponible' then null else public.tfl_sujets.reserve_tel end,
      reserve_at = case when v_push and excluded.statut = 'disponible' then null else public.tfl_sujets.reserve_at end;
    v_n := v_n + 1;
  end loop;
  return jsonb_build_object('ok', true, 'n', v_n);
end $$;
revoke all on function public.tfl_sujets_publier(jsonb) from public, anon;
grant execute on function public.tfl_sujets_publier(jsonb) to authenticated;

-- Retire du public un sujet (il reste sur l'appareil de l'administrateur).
create or replace function public.tfl_sujet_retirer(p_ref text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  update public.tfl_sujets set publie = false, updated_at = now() where ref = p_ref;
end $$;
revoke all on function public.tfl_sujet_retirer(text) from public, anon;
grant execute on function public.tfl_sujet_retirer(text) to authenticated;

-- Réservations du serveur (pour mettre à jour l'état local de l'administrateur).
create or replace function public.tfl_sujets_etat()
returns table(ref text, statut text, publie boolean, exclusif boolean, reserve_at timestamptz)
language plpgsql security definer set search_path = public stable as $$
begin
  if not public.tfl_sujets_admin_ok() then raise exception 'non autorisé'; end if;
  return query select s.ref, s.statut, s.publie, s.exclusif, s.reserve_at from public.tfl_sujets s order by s.ref;
end $$;
revoke all on function public.tfl_sujets_etat() from public, anon;
grant execute on function public.tfl_sujets_etat() to authenticated;

-- ---------- Lecture publique (sans compte) ----------
-- Aucune donnée personnelle : ni téléphone, ni nom d'étudiant. Seulement la fiche et la disponibilité.
create or replace function public.tfl_sujets_publics()
returns table(ref text, data jsonb, exclusif boolean, statut text)
language sql security definer set search_path = public stable as $$
  select s.ref, s.data, s.exclusif, s.statut
    from public.tfl_sujets s
   where s.publie and s.statut <> 'ferme'
   order by s.ref
   limit 500;
$$;
revoke all on function public.tfl_sujets_publics() from public;
grant execute on function public.tfl_sujets_publics() to anon, authenticated;

-- ---------- « Choisir ce sujet » (étudiant sans compte) ----------
create or replace function public.tfl_sujet_choisir(p_ref text, p_data jsonb, p_submitted timestamptz default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  s public.tfl_sujets%rowtype;
  v_nom text := left(btrim(coalesce(p_data->>'nom','')), 120);
  v_tel text := left(btrim(coalesce(p_data->>'telephone','')), 40);
  v_clean jsonb; v_id uuid;
begin
  if jsonb_typeof(p_data) is distinct from 'object' then raise exception 'donnees_invalides'; end if;
  if length(v_nom) < 2 then raise exception 'nom_invalide'; end if;
  if v_tel !~ '[0-9]{6,}' then raise exception 'telephone_invalide'; end if;
  -- limite anti-spam : 200 demandes par heure au total, 5 par numéro et par heure
  if (select count(*) from public.tfl_candidatures where created_at > now() - interval '1 hour') >= 200 then raise exception 'trop_de_demandes'; end if;
  if (select count(*) from public.tfl_candidatures where data->>'telephone' = v_tel and created_at > now() - interval '1 hour') >= 5 then raise exception 'trop_de_demandes'; end if;
  -- verrou de ligne : deux étudiants qui choisissent en même temps ne peuvent pas réserver le même sujet exclusif
  select * into s from public.tfl_sujets where ref = btrim(coalesce(p_ref,'')) for update;
  if not found or not s.publie then raise exception 'sujet_introuvable'; end if;
  if s.statut in ('ferme','attribue') then raise exception 'sujet_indisponible'; end if;
  if s.exclusif and s.statut = 'reserve' then
    -- le même étudiant qui renvoie sa demande (réseau instable) n'est pas bloqué
    if s.reserve_tel is distinct from v_tel then raise exception 'sujet_deja_reserve'; end if;
  end if;
  -- la fiche du sujet est copiée côté serveur : l'étudiant ne peut pas la modifier
  v_clean := jsonb_build_object(
    'nom', v_nom, 'telephone', v_tel,
    'email', left(coalesce(p_data->>'email',''), 120),
    'universite', left(coalesce(p_data->>'universite',''), 150),
    'promotion', left(coalesce(p_data->>'promotion',''), 60),
    'filiere', left(coalesce(p_data->>'filiere', s.data->>'filiere', ''), 100),
    'matricule_existant', left(coalesce(p_data->>'matricule_existant',''), 40),
    'domaine', coalesce(s.data->>'domaine', 'autre'),
    'sujet_ref', s.ref,
    'sujet_titre', s.data->>'titre',
    'problematique', s.data->>'problematique',
    'objectifs', s.data->>'objectifs',
    'methodologie', s.data->>'methodologie',
    'recherches_deja', left(coalesce(p_data->>'motivation',''), 3000));
  select id into v_id from public.tfl_candidatures
   where data->>'sujet_ref' = s.ref and data->>'telephone' = v_tel and not imported limit 1;
  if v_id is null then
    insert into public.tfl_candidatures(submitted_at, ref, data) values (p_submitted, left('SUJET-' || s.ref, 40), v_clean) returning id into v_id;
  end if;
  if s.exclusif then
    update public.tfl_sujets set statut = 'reserve', reserve_tel = v_tel, reserve_at = now(), updated_at = now() where ref = s.ref;
  end if;
  return jsonb_build_object('ok', true, 'reserve', s.exclusif);
end $$;
revoke all on function public.tfl_sujet_choisir(text, jsonb, timestamptz) from public;
grant execute on function public.tfl_sujet_choisir(text, jsonb, timestamptz) to anon, authenticated;

-- Contrôle rapide après exécution (doit renvoyer 5 lignes) :
-- select proname from pg_proc where proname in ('tfl_sujets_publier','tfl_sujet_retirer','tfl_sujets_etat','tfl_sujets_publics','tfl_sujet_choisir');
