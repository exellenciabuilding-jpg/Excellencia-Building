-- Excellencia Building — TFL bloc 2/5 : PROPOSITION DE SUJET OU DE PLAN PAR L'ÉTUDIANT (depuis son portail).
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzt-tfl-portails.sql, puis migration-tfl-bloc1-demande-encadreur.sql (ce script remplace de nouveau la fonction de connexion).
--
-- Principe : l'étudiant dont le dossier est accepté (ou en vérification) peut proposer
--   · un NOUVEAU SUJET (titre, problématique, objectifs, méthodologie facultative, raison du changement), ou
--   · un PLAN de travail (plan détaillé : introduction, chapitres, conclusion…), avec une note facultative.
-- La proposition arrive comme un message de type « proposition_sujet » ou « proposition_plan » dans la boîte de l'administration
-- (récupération habituelle : TFL › Portails › Récupérer les messages reçus). Seule l'administration retient, refuse ou demande un complément ;
-- rien ne change dans le dossier tant qu'elle n'a pas cliqué. Une seule proposition « en étude » par genre ; 10 propositions au plus par genre
-- et par étudiant ; 30 envois par heure et par accès (comme les messages).

alter table public.tfl_messages drop constraint if exists tfl_messages_type_check;
alter table public.tfl_messages add constraint tfl_messages_type_check
  check (type in ('message','commentaire','progression','validation','demande_encadreur','proposition_sujet','proposition_plan'));

-- Connexion : identique à la version du bloc 1, avec en plus l'identifiant de chaque message (pour rattacher la décision de l'administration).
create or replace function public.tfl_portail_connexion(p_role text, p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then
    select * into a from public.tfl_acces where id = c.v_id;
    return jsonb_build_object('ok', true, 'changer', true, 'nom', a.nom);
  end if;
  update public.tfl_acces set connexions = connexions + 1, derniere_connexion = now() where id = c.v_id returning * into a;
  return jsonb_build_object('ok', true, 'changer', false, 'nom', a.nom, 'publie_le', a.publie_le, 'contenu', a.contenu,
    'messages', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'de', m.de, 'type', m.type, 'dossier', m.dossier, 'texte', m.texte, 'valeur', m.valeur, 'cree_le', m.cree_le, 'traite', m.traite) order by m.cree_le)
                          from public.tfl_messages m where m.acces_id = a.id), '[]'::jsonb));
end $$;
revoke all on function public.tfl_portail_connexion(text,text,text) from public;
grant execute on function public.tfl_portail_connexion(text,text,text) to anon, authenticated;

-- p_genre : 'sujet' ou 'plan'.  p_champs : objet JSON {titre, problematique, objectifs, methodologie, plan, motif} (les champs inutiles sont ignorés).
create or replace function public.tfl_portail_proposition(p_ident text, p_mdp text, p_genre text, p_champs jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_type text; v_f jsonb; v_titre text; v_prob text; v_obj text; v_meth text; v_plan text; v_motif text;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  if p_genre not in ('sujet','plan') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if jsonb_typeof(p_champs) is distinct from 'object' then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  v_type := 'proposition_' || p_genre;
  select * into a from public.tfl_acces where id = c.v_id;
  if coalesce(a.contenu->>'numero','') = '' or coalesce(a.contenu->>'statut','') not in ('accepte','en_verification') then
    return jsonb_build_object('ok', false, 'code', 'dossier');
  end if;
  v_motif := left(btrim(coalesce(p_champs->>'motif','')), 1000);
  if p_genre = 'sujet' then
    v_titre := left(btrim(coalesce(p_champs->>'titre','')), 250);
    v_prob  := left(btrim(coalesce(p_champs->>'problematique','')), 3000);
    v_obj   := left(btrim(coalesce(p_champs->>'objectifs','')), 3000);
    v_meth  := left(btrim(coalesce(p_champs->>'methodologie','')), 3000);
    if length(v_titre) < 8 or length(v_prob) < 10 or length(v_obj) < 10 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    v_f := jsonb_build_object('titre', v_titre, 'problematique', v_prob, 'objectifs', v_obj, 'methodologie', v_meth, 'motif', v_motif);
  else
    v_plan := left(btrim(coalesce(p_champs->>'plan','')), 6000);
    if length(v_plan) < 20 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
    v_f := jsonb_build_object('plan', v_plan, 'motif', v_motif);
  end if;
  -- une seule proposition en étude par genre : un message de ce genre reste « en étude » tant que l'instantané publié ne contient pas
  -- une décision (retenue, refusée, complément) portant son identifiant (rid)
  if exists (select 1 from public.tfl_messages m where m.acces_id = a.id and m.type = v_type
             and not exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'mes_propositions','[]'::jsonb)) x
                             where x->>'rid' = m.id::text and coalesce(x->>'statut','en_etude') <> 'en_etude')) then
    return jsonb_build_object('ok', false, 'code', 'deja_propose');
  end if;
  if (select count(*) from public.tfl_messages where acces_id = a.id and type = v_type) >= 10 then
    return jsonb_build_object('ok', false, 'code', 'limite');
  end if;
  if (select count(*) from public.tfl_messages where acces_id = a.id and cree_le > now() - interval '1 hour') >= 30 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_messages(acces_id, de, type, dossier, texte)
  values (a.id, 'etudiant', v_type, a.contenu->>'numero', v_f::text);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_portail_proposition(text,text,text,jsonb) from public;
grant execute on function public.tfl_portail_proposition(text,text,text,jsonb) to anon, authenticated;

-- Contrôle : select proname from pg_proc where proname = 'tfl_portail_proposition';  → 1 ligne
