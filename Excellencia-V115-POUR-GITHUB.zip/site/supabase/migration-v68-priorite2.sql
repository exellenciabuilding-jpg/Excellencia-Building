-- Excellencia Building V68 — Priorité 2
-- CDE / BIM Issues / EVM / Maintenance / Risk Register / Client Portal
-- À exécuter après migration-v67-btp.sql. Réexécutable.
insert into droits_fonction(fonction,collection,lire,ecrire) values
('direction','cde',true,true),('direction','bim_issues',true,true),('direction','evm',true,true),('direction','maintenance',true,true),('direction','risk_register',true,true),('direction','client_portal',true,true),
('chef_projet','cde',true,true),('chef_projet','bim_issues',true,true),('chef_projet','evm',true,true),('chef_projet','maintenance',true,true),('chef_projet','risk_register',true,true),('chef_projet','client_portal',true,true),
('conducteur','cde',true,true),('conducteur','bim_issues',true,true),('conducteur','evm',true,false),('conducteur','maintenance',true,true),('conducteur','risk_register',true,true),('conducteur','client_portal',true,true),
('bureau_etudes','cde',true,true),('bureau_etudes','bim_issues',true,true),('bureau_etudes','evm',true,false),('bureau_etudes','maintenance',true,false),('bureau_etudes','risk_register',true,true),('bureau_etudes','client_portal',true,true),
('comptable','cde',true,false),('comptable','bim_issues',true,false),('comptable','evm',true,true),('comptable','maintenance',true,false),('comptable','risk_register',true,false),('comptable','client_portal',true,true),
('magasinier','cde',true,true),('magasinier','bim_issues',true,false),('magasinier','evm',true,false),('magasinier','maintenance',true,true),('magasinier','risk_register',true,false),('magasinier','client_portal',true,false)
on conflict (fonction,collection) do nothing;
