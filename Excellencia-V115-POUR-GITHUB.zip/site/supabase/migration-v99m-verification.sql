-- Excellencia Building V99m — Vérification unifiée des documents (devis, factures, reçus, certificats, fiches d'inscription).
-- À exécuter UNE fois APRÈS migration-v99l-documents.sql (Supabase › SQL Editor). Réexécutable sans danger.
-- Remplacez les e-mails administrateur si besoin (en minuscules).
-- Aucune donnée de contact (téléphone, e-mail, adresse) n'est stockée ni renvoyée : seulement nom, matricule, libellé, date, montant, statut.

alter table public.exb_doc_registry
  add column if not exists nom text,
  add column if not exists matricule text,
  add column if not exists libelle text,
  add column if not exists detail text,
  add column if not exists created_at timestamptz not null default now();

alter table public.exb_doc_registry drop constraint if exists exb_doc_registry_kind_check;
alter table public.exb_doc_registry add constraint exb_doc_registry_kind_check
  check (kind in ('devis','facture','recu','certificat','recu_formation','inscription'));
create index if not exists exb_doc_registry_mat_idx on public.exb_doc_registry (upper(matricule));

-- Publication par l'administrateur connecté uniquement.
create or replace function public.exb_doc_publish2(p_no text, p_kind text, p_hash text, p_date date, p_total numeric, p_cur text,
  p_status text, p_nom text, p_matricule text, p_libelle text, p_detail text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail, updated_at)
  values (left(p_no,60), left(p_hash,20), p_kind, p_date, p_total, left(coalesce(p_cur,''),8), left(coalesce(p_status,''),20),
          left(p_nom,120), left(p_matricule,40), left(p_libelle,200), left(p_detail,300), now())
  on conflict (no, hash) do update set status = excluded.status, total = excluded.total, cur = excluded.cur, doc_date = excluded.doc_date,
    nom = excluded.nom, matricule = excluded.matricule, libelle = excluded.libelle, detail = excluded.detail, updated_at = now();
  -- un statut « annulé » vaut pour toutes les versions du même numéro
  if p_status in ('annulé') then
    update public.exb_doc_registry set status = 'annulé', updated_at = now() where no = left(p_no,60) and kind = p_kind;
  end if;
end $$;
revoke all on function public.exb_doc_publish2(text,text,text,date,numeric,text,text,text,text,text,text) from public, anon;
grant execute on function public.exb_doc_publish2(text,text,text,date,numeric,text,text,text,text,text,text) to authenticated;

-- Fiche d'inscription déclarée par le visiteur (public) : enregistre seulement « une fiche a été reçue ». Limitée en volume.
create or replace function public.exb_doc_declare(p_data jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_no text := left(btrim(coalesce(p_data->>'no','')),60); v_hash text := left(btrim(coalesce(p_data->>'hash','')),20);
begin
  if length(v_no) < 3 or length(v_hash) < 6 then raise exception 'donnees_invalides'; end if;
  if (select count(*) from public.exb_doc_registry where kind = 'inscription' and created_at > now() - interval '1 hour') >= 300 then raise exception 'trop_de_demandes'; end if;
  insert into public.exb_doc_registry(no, hash, kind, doc_date, total, cur, status, nom, matricule, libelle, detail)
  values (v_no, v_hash, 'inscription', nullif(p_data->>'date','')::date, 0, '', 'reçue', left(p_data->>'nom',120), left(p_data->>'matricule',40), left(p_data->>'libelle',200), 'Fiche reçue par Excellencia Building (en cours de traitement)')
  on conflict (no, hash) do nothing;
  return jsonb_build_object('ok', true);
exception when invalid_text_representation or invalid_datetime_format then raise exception 'date_invalide';
end $$;
grant execute on function public.exb_doc_declare(jsonb) to anon, authenticated;

-- Vérification d'un document par son QR (numéro + code) : renvoie les repères enregistrés, jamais de contact.
create or replace function public.exb_doc_verify2(p_no text, p_hash text)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare r public.exb_doc_registry; c public.exb_doc_registry;
begin
  select * into r from public.exb_doc_registry where no = left(p_no,60) and hash = left(p_hash,20);
  if not found then return jsonb_build_object('found', false); end if;
  select * into c from public.exb_doc_registry where no = r.no and kind = r.kind order by created_at desc, hash limit 1;
  return jsonb_build_object('found', true, 'kind', r.kind, 'status', r.status, 'nom', r.nom, 'matricule', r.matricule, 'libelle', r.libelle,
    'detail', r.detail, 'date', r.doc_date, 'total', r.total, 'cur', r.cur, 'latest', (c.hash = r.hash),
    'current', case when c.hash = r.hash then null else jsonb_build_object('hash', c.hash, 'date', c.doc_date, 'total', c.total, 'cur', c.cur, 'status', c.status, 'libelle', c.libelle) end);
end $$;
grant execute on function public.exb_doc_verify2(text,text) to anon, authenticated;

-- Recherche par matricule (exact) ou par numéro de document (exact) : 20 résultats maximum, sans contact.
create or replace function public.exb_doc_search(p_q text)
returns jsonb language plpgsql security definer set search_path = public stable as $$
declare q text := btrim(coalesce(p_q,''));
begin
  if length(q) < 3 then return jsonb_build_object('items', '[]'::jsonb); end if;
  return jsonb_build_object('items', coalesce((select jsonb_agg(x) from (
    select kind, no, doc_date as date, status, nom, matricule, libelle
    from public.exb_doc_registry where upper(matricule) = upper(q) or upper(no) = upper(q)
    order by created_at desc limit 20) x), '[]'::jsonb));
end $$;
grant execute on function public.exb_doc_search(text) to anon, authenticated;
