-- LOT 5/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
create or replace function public.tfl_candidature_traiter(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if lower(coalesce(auth.jwt()->>'email','')) <> all (array['excellenciabuilding@gmail.com','exellenciabuilding@gmail.com']) then
    raise exception 'non autorisé';
  end if;
  update public.tfl_candidatures set imported = true, imported_at = now() where id = p_id;
  -- l'item « reçu » de ce dépôt est remplacé par le dossier réel (publié ensuite par l'administrateur)
  update public.tfl_statuts s set updated_at = now(), items = coalesce((select jsonb_agg(x) from jsonb_array_elements(s.items) x where x->>'ref' <> 'C-' || left(p_id::text, 8)), '[]'::jsonb)
   where s.matricule = (select data->>'matricule_en_ligne' from public.tfl_candidatures where id = p_id);
end $$;
revoke all on function public.tfl_candidature_traiter(uuid) from public, anon;
grant execute on function public.tfl_candidature_traiter(uuid) to authenticated;

create or replace function public.tfl_portail_envoyer(p_role text, p_ident text, p_mdp text, p_dossier text, p_type text, p_texte text, p_valeur int default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_t text := left(btrim(coalesce(p_texte,'')), 1500); v_d text := left(btrim(coalesce(p_dossier,'')), 40);
        v_type text := coalesce(nullif(p_type,''), 'message'); v_ok boolean;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if v_type not in ('message','commentaire','progression','validation') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if a.role = 'etudiant' and v_type <> 'message' then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  -- dossier : celui de l'étudiant, ou l'un des dossiers affectés à l'encadreur (selon l'instantané publié)
  if a.role = 'etudiant' then
    if v_d = '' then v_d := coalesce(a.contenu->>'numero',''); end if;
    v_ok := v_d <> '' and v_d = coalesce(a.contenu->>'numero','');
  else
    v_ok := v_d <> '' and exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'dossiers','[]'::jsonb)) x where x->>'numero' = v_d);
  end if;
  if not v_ok then return jsonb_build_object('ok', false, 'code', 'dossier'); end if;
  if v_type = 'validation' and a.role <> 'encadreur' then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if v_type = 'validation' then
    if p_valeur is null or p_valeur < 1 or p_valeur > 3 then return jsonb_build_object('ok', false, 'code', 'valeur'); end if;
  elsif v_type = 'progression' then
    if p_valeur is null or p_valeur < 0 or p_valeur > 100 then return jsonb_build_object('ok', false, 'code', 'valeur'); end if;
  else
    if length(v_t) < 2 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  end if;
  if (select count(*) from public.tfl_messages where acces_id = a.id and cree_le > now() - interval '1 hour') >= 30 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_messages(acces_id, de, type, dossier, texte, valeur)
  values (a.id, a.role, v_type, v_d, v_t, case when v_type in ('progression','validation') then p_valeur else null end);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_portail_envoyer(text,text,text,text,text,text,int) from public;
grant execute on function public.tfl_portail_envoyer(text,text,text,text,text,text,int) to anon, authenticated;
