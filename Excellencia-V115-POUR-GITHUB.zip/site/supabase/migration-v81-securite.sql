-- Excellencia Building V81 — quota quotidien de l'assistant IA en ligne (limite appliquée par le serveur).
-- À exécuter UNE fois (Supabase › SQL Editor). Réexécutable sans danger.
create table if not exists assistant_usage(
  user_id uuid not null,
  jour date not null default current_date,
  n int not null default 0,
  primary key(user_id,jour));
alter table assistant_usage enable row level security;
-- Aucune policy : la table n'est accessible que par la fonction ci-dessous.

create or replace function exb_assistant_quota(p_max int default 40)
returns json language plpgsql security definer set search_path=public as $$
declare v int;
begin
  if auth.uid() is null then raise exception 'non connecté'; end if;
  delete from assistant_usage where jour < current_date - 30;
  insert into assistant_usage(user_id,jour,n) values (auth.uid(),current_date,1)
    on conflict (user_id,jour) do update set n=assistant_usage.n+1 where assistant_usage.n < greatest(p_max,1)
    returning n into v;
  if v is null then
    select n into v from assistant_usage where user_id=auth.uid() and jour=current_date;
    return json_build_object('ok',false,'n',v,'max',p_max);
  end if;
  return json_build_object('ok',true,'n',v,'max',p_max);
end $$;
revoke all on function exb_assistant_quota(int) from public;
grant execute on function exb_assistant_quota(int) to authenticated;
