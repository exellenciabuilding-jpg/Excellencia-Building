-- LOT 2/7 — migration V99zzzzzzzzzzzzzz (TFL matricule/suivi/encadreur). Exécuter les lots 1 à 7 dans l'ordre, un par un.
-- 2) Génération du matricule + enregistrement du statut « reçu » -------------------------------------------
create or replace function public.tfl_matricule_nouveau() returns text language plpgsql security definer set search_path = public as $$
declare v_n text; v_m text; i int := 0;
begin
  loop
    v_n := lpad((floor(random() * 1000000000))::bigint::text, 9, '0');
    v_m := substr(v_n,1,3) || '-' || substr(v_n,4,3) || '-' || substr(v_n,7,3);
    exit when not exists (select 1 from public.tfl_statuts where matricule = v_m);
    i := i + 1; if i > 60 then raise exception 'matricule_indisponible'; end if;
  end loop;
  return v_m;
end $$;
revoke all on function public.tfl_matricule_nouveau() from public, anon, authenticated;

-- Même personne (même rôle, mêmes 6 derniers chiffres de téléphone) = même matricule ; on ajoute seulement l'item « reçu ».
create or replace function public.tfl_statut_creer(p_role text, p_nom text, p_tel text, p_item jsonb) returns text language plpgsql security definer set search_path = public as $$
declare v_tel text := regexp_replace(coalesce(p_tel,''), '\D', '', 'g'); v_m text;
begin
  if length(v_tel) >= 6 then select matricule into v_m from public.tfl_statuts where role = p_role and right(tel_norm, 6) = right(v_tel, 6) limit 1; end if;
  if v_m is null then
    v_m := public.tfl_matricule_nouveau();
    insert into public.tfl_statuts(matricule, role, nom, tel_norm, items) values (v_m, p_role, left(coalesce(p_nom,''),120), v_tel, jsonb_build_array(p_item));
  else
    update public.tfl_statuts set items = items || jsonb_build_array(p_item), updated_at = now() where matricule = v_m;
  end if;
  return v_m;
end $$;
revoke all on function public.tfl_statut_creer(text, text, text, jsonb) from public, anon, authenticated;

-- Tout dépôt de candidature (formulaire direct, choix d'un sujet, fiche) reçoit son matricule à l'insertion.
create or replace function public.tfl_cand_matricule_trg() returns trigger language plpgsql security definer set search_path = public as $$
declare v_m text;
begin
  v_m := public.tfl_statut_creer('etudiant', NEW.data->>'nom', NEW.data->>'telephone',
    jsonb_build_object('ref', 'C-' || left(NEW.id::text, 8), 'titre', left(coalesce(NEW.data->>'sujet_titre',''), 250), 'statut', 'recu', 'label', 'Reçu — en cours d’étude', 'motif', '', 'encadreur', '', 'validation', '', 'maj', to_char(now(), 'YYYY-MM-DD')));
  NEW.data := NEW.data || jsonb_build_object('matricule_en_ligne', v_m);
  return NEW;
end $$;
drop trigger if exists tfl_cand_matricule on public.tfl_candidatures;
create trigger tfl_cand_matricule before insert on public.tfl_candidatures for each row execute function public.tfl_cand_matricule_trg();
