-- Excellencia Building V81 — droits pour les collections : pieces (CCTP/CCAP/lettres/CR/OS), plans_fichiers et plans_annotations (plans CAO),
-- autorisations (permis de bâtir), paie (contrats, bulletins, congés, avances, habilitations). À exécuter UNE fois après migration-v80. Réexécutable.
-- La paie est une donnée sensible : lecture direction/RH/comptabilité, écriture RH et comptabilité uniquement.
with droits(fonction, collection, lire, ecrire) as (values
 ('direction','pieces',true,true),('chef_projet','pieces',true,true),('bureau_etudes','pieces',true,true),('conducteur','pieces',true,true),
 ('direction','plans_fichiers',true,true),('chef_projet','plans_fichiers',true,true),('bureau_etudes','plans_fichiers',true,true),('conducteur','plans_fichiers',true,false),
 ('direction','plans_annotations',true,true),('chef_projet','plans_annotations',true,true),('bureau_etudes','plans_annotations',true,true),('conducteur','plans_annotations',true,true),
 ('direction','autorisations',true,true),('chef_projet','autorisations',true,true),('bureau_etudes','autorisations',true,true),('conducteur','autorisations',true,false),
 ('direction','paie',true,false),('rh','paie',true,true),('comptable','paie',true,true)
)
insert into droits_fonction(fonction,collection,lire,ecrire)
select fonction,collection,lire,ecrire from droits
on conflict (fonction,collection) do nothing;
