-- Excellencia Building — TFL bloc 1/5 : DEMANDE D'ENCADREUR PAR L'ÉTUDIANT.
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v99zzt-tfl-portails.sql et les lots V99zzzzzzzzzzzzzz (type « validation » déjà autorisé).
--
-- Principe : l'étudiant dont le dossier est accepté (ou en vérification) et qui n'a pas encore d'encadreur peut demander jusqu'à
-- 3 encadreurs parmi ceux que l'administration publie dans son portail (liste « encadreurs_dispo », sans coordonnées),
-- avec une note facultative. La demande arrive comme un message de type « demande_encadreur » dans la boîte de l'administration
-- (récupération habituelle : TFL › Portails › Récupérer les messages reçus). Seule l'administration affecte l'encadreur.
-- Une seule demande en attente à la fois ; 30 envois par heure et par accès (comme les messages).

alter table public.tfl_messages drop constraint if exists tfl_messages_type_check;
alter table public.tfl_messages add constraint tfl_messages_type_check
  check (type in ('message','commentaire','progression','validation','demande_encadreur'));

-- Connexion : identique à la version V99zzt, avec en plus l'identifiant de message et l'état « traité » (pour suivre la demande).
create or replace function public.tfl_portail_connexion(p_role text, p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then
    select * into a from public.tfl_acces where id = c.v_id;
    return jsonb_build_object('ok', true, 'changer', true, 'nom', a.nom);
  end if;
  update public.tfl_acces set connexions = connexions + 1, derniere_connexion = now() where id = c.v_id returning * into a;
  return jsonb_build_object('ok', true, 'changer', false, 'nom', a.nom, 'publie_le', a.publie_le, 'contenu', a.contenu,
    'messages', coalesce((select jsonb_agg(jsonb_build_object('de', m.de, 'type', m.type, 'dossier', m.dossier, 'texte', m.texte, 'valeur', m.valeur, 'cree_le', m.cree_le, 'traite', m.traite) order by m.cree_le)
                          from public.tfl_messages m where m.acces_id = a.id), '[]'::jsonb));
end $$;
revoke all on function public.tfl_portail_connexion(text,text,text) from public;
grant execute on function public.tfl_portail_connexion(text,text,text) to anon, authenticated;

create or replace function public.tfl_portail_demande_encadreur(p_ident text, p_mdp text, p_choix jsonb, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces; v_note text := left(btrim(coalesce(p_note,'')), 500); v_ok jsonb := '[]'::jsonb; x jsonb; v_id text; v_nom text; v_n int := 0; v_liste jsonb;
begin
  select * into c from public.tfl_acces_check('etudiant', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if coalesce(a.contenu->>'numero','') = '' or coalesce(a.contenu->>'statut','') not in ('accepte','en_verification') then
    return jsonb_build_object('ok', false, 'code', 'dossier');
  end if;
  if coalesce(a.contenu->'encadreur'->>'nom','') <> '' then return jsonb_build_object('ok', false, 'code', 'deja_affecte'); end if;
  if exists (select 1 from public.tfl_messages where acces_id = a.id and type = 'demande_encadreur' and not traite) then
    return jsonb_build_object('ok', false, 'code', 'deja_demande');
  end if;
  v_liste := coalesce(a.contenu->'encadreurs_dispo', '[]'::jsonb);
  if jsonb_typeof(p_choix) = 'array' then
    for x in select * from jsonb_array_elements(p_choix) loop
      exit when v_n >= 3;
      v_id := left(btrim(coalesce(x->>'id','')), 40);
      -- le choix doit figurer dans la liste publiée dans le portail de l'étudiant
      select e->>'nom' into v_nom from jsonb_array_elements(v_liste) e where e->>'id' = v_id limit 1;
      if v_nom is not null and not (v_ok @> jsonb_build_array(jsonb_build_object('id', v_id, 'nom', v_nom))) then
        v_ok := v_ok || jsonb_build_array(jsonb_build_object('id', v_id, 'nom', left(v_nom, 120)));
        v_n := v_n + 1;
      end if;
      v_nom := null;
    end loop;
  end if;
  if v_n = 0 and length(v_note) < 5 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  if (select count(*) from public.tfl_messages where acces_id = a.id and cree_le > now() - interval '1 hour') >= 30 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_messages(acces_id, de, type, dossier, texte)
  values (a.id, 'etudiant', 'demande_encadreur', a.contenu->>'numero', jsonb_build_object('choix', v_ok, 'note', v_note)::text);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_portail_demande_encadreur(text,text,jsonb,text) from public;
grant execute on function public.tfl_portail_demande_encadreur(text,text,jsonb,text) to anon, authenticated;

-- Contrôle : select proname from pg_proc where proname = 'tfl_portail_demande_encadreur';  → 1 ligne
