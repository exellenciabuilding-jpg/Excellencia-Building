# V99zs — Rapport journalier enrichi et pointage géolocalisé (suite de V99zr)

Fichiers : `exb-terrain.js`, `exb-controles.js` (expose `signPad` et `locate`), `sw.js` (cache `exb-v99zs-rapport-terrain-1`), `exb-v99r-shell.js` (version), `tools/e2e-smoke.py`.
Menu : **Projets & Chantiers › Terrain & achats › Journal** et **Pointage** (écrans existants, enrichis).

## Rapport journalier (journal de chantier)
- **Effectif par corps de métier** (maçons, ferrailleurs / coffreurs, électriciens, plombiers, peintres, manœuvres, conducteurs d'engins, autres) : l'effectif total se calcule tout seul.
- **Engins et matériel** avec heures d'utilisation (liste libre).
- **Heures perdues** (intempéries, pannes) : utile pour justifier un retard auprès du maître d'ouvrage.
- **Visa du conducteur de travaux** signé au doigt, **position GPS**, repris dans la liste (✍️ 📍) et dans le **PDF** (effectifs, engins, heures perdues, visa, position).
- Les anciens rapports restent lisibles (nouveaux champs facultatifs).

## Pointage des ouvriers
- Bouton **📍 Position** avant « Pointer » : la position est jointe au pointage et marquée 📍 dans la liste (la position exacte apparaît au survol).
- La position est facultative : elle n'est pas exigée et n'est pas comparée à l'emplacement du chantier.

## Limites
- Le formulaire rapide du mode « Chantier hors ligne » (V73) n'a pas ces nouveaux champs : il reste simple (journal, HSE, RFI, réserve, pointage).
- Pas de contrôle d'emplacement (le chantier n'a pas de coordonnées enregistrées) ni de photo de présence.
- Tests : parcours navigateur (effectifs 4 + 10 = 14, engin, heures perdues, signature, PDF, pointage avec position) ; `node tools/check.js` : 275 contrôles. Non testé sur un vrai téléphone.
