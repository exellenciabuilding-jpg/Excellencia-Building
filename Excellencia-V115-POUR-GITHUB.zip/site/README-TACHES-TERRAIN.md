# Tâches terrain (nouveau module)

Bouton « ✅ Tâches terrain » à côté de « ✅ Réception de chantier ».

- Tâche : titre, chantier, attribuée à (équipe interne ou sous-traitant, noms suggérés depuis Personnel / Fournisseurs), priorité, échéance, statut, avancement, description, commentaires, 3 photos réduites.
- Filtres chantier / personne / statut ; tâches en retard en tête ; compteurs ouvertes / en retard / bloquées.
- « 📤 Liste à envoyer » : choisir une personne dans le filtre, puis message texte (copier ou WhatsApp) avec ses seules tâches ouvertes.
- Hors ligne et synchronisation : comme les autres modules (EXBS + collection `taches_terrain`).

## Installation
1. Déployer le ZIP (fichiers modifiés : `exb-db.js`, `index.html`, `sw.js` ; nouveau : `exb-taches-terrain.js`).
2. Supabase › SQL Editor : `supabase/migration-taches-terrain.sql`.
3. Recharger la page (le cache hors ligne change de version).

## Limites
- Pas de portail sous-traitant limité à ses tâches (le portail existant publie un instantané de lots, pas ces tâches) : prochaine étape.
- Les photos (réduites à ~900 px) occupent le stockage local ; 3 par tâche.
- Testé : syntaxe et logique dans un bac à sable Node. Non testé dans un navigateur sur vos données ni sur un vrai Supabase.
