# Signature et cachet de l'administration sur tous les documents des formulaires

## Constat
La signature + le cachet (visa) se posaient déjà sur la fiche de demande BTP et sur les fiches produites par `exb-form.js` (inscription, formateur, client, personnel, logiciel, TP/TD). Deux pages publiques qui éditent aussi un PDF ne chargeaient pas le module de signature : elles sortaient **sans** signature ni cachet.

## Corrigé
- `apprenant.html` : « Récapitulatif d'inscription — apprenant » reçoit maintenant signature + cachet.
- `resultats.html` : « Résultats — demande BTP · Architecture » reçoit maintenant signature + cachet.
Contrôle en navigateur : sur toutes les pages (inscription, formateur, personnel, client, BTP, logiciel, TP/TD, apprenant, résultats) le PDF contient l'image du visa quand il est disponible.

## À savoir
- Sur l'appareil d'un client, le visa vient du **visa public** que l'administrateur publie (Site vitrine › Publier). **Tant qu'il n'est pas publié, aucune signature ni cachet ne peut apparaître** sur les PDF des clients : publiez-le une fois.
- Volontairement sans visa : la fiche étudiante TFL (reste « À valider par l'administration » jusqu'à l'attestation éditée par l'administration) et la copie d'épreuve de l'apprenant (le visa y signifierait une validation de la note).
