# Nom du Directeur Général : une seule saisie

Où le régler : **Paramètres › Logo Excellencia Building › « 🧾 Identité imprimée sur les devis, fiches et documents clients »** : champs **Nom du Directeur Général** et **Fonction**, puis « Enregistrer l'identité des documents ».
Il est repris automatiquement par **tous les modules qui impriment la signature de la direction** :
- **Reçus** (champ « Directeur général », prérempli ; modifiable pour un reçu précis) et **certificats / attestations** de formation.
- **Devis du métré**, **devis, factures, reçus et documents clients** (nom + fonction du prestataire sous la signature ; un nom saisi à la main dans « Suivi / envoi » reste prioritaire).
- **Tous les PDF** produits par le moteur commun : fiches (personnel, TP/TD, clients…), rapports, TFL (attestation de dépôt, annexe), rapport de pilotage de chantier (« Le Directeur »), fiches « La Direction » : le nom est imprimé sous le libellé « Directeur / Direction ».
- **Fiches de demande en ligne** (cadre « Cachet et visa Excellencia Building »).
- **Pièces de marché** (CCAP…) : « Maître d’œuvre : Société (représentée par Nom, Fonction) ».
- **Signature électronique du portail** : la fenêtre « Signature de l’entreprise » est préremplie.
Volontairement NON modifiés : notes de calcul et études (« Établi par », « Vérifié par » = ingénieurs, pas la direction), visa du conducteur de travaux et du contrôleur (journal, contrôles), signature de l’apprenant / du client. Un libellé qui n'est pas « Directeur / Direction » n'affiche jamais le nom du DG.
Par défaut (identité d'origine) : Ir Ibwampere Ngwala Louis. Le nom est enregistré sur l'appareil (comme le reste de l'identité).
