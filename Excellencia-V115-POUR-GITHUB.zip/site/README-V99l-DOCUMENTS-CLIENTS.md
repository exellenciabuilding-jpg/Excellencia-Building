# V99l — Documents clients : authenticité, cycle commercial, envoi, PDF texte
Nouveau module `exb-docs.js` (ajouté à index.html et au cache hors ligne ; vider le cache / recharger après mise à jour).

- **PDF à texte sélectionnable** : devis du métré et devis rapide sont maintenant de vrais PDF (texte copiable/recherchable, ~20× plus légers). L'ancien moteur image reste en secours si le module manque. L'impression directe n'a pas changé.
- **QR de vérification** sur devis, factures et reçus (vectoriel, hors ligne). Scan → page « Vérification de document » (n°, date, montant, code). Vérification en ligne facultative : exécuter `supabase/migration-v99l-documents.sql` ; l'administrateur connecté publie alors chaque document, et le scan affiche authentique / annulé / non reconnu.
- **Signature du client au doigt** (fiche « 📋 Suivi / envoi »), reprise automatiquement sur les PDF du devis.
- **Filigrane** BROUILLON ou ANNULÉ selon le statut choisi ; **conditions générales** insérées en bas des devis et factures (modifiables dans la fiche ; clauses types à faire valider par votre conseil).
- **Devis → facture → reçu** : même numéro de dossier (DEV-2026-007 → FAC-2026-007 → REC-2026-007-1, -2…). La facture gère l'acompte et le solde ; chaque reçu indique le cumul réglé et le reste à payer.
- **Suivi des devis** : statuts brouillon / envoyé / accepté / refusé / annulé, date de validité, alerte quotidienne à l'ouverture pour les devis qui arrivent à échéance, bouton « ⏰ Suivi des devis » avec relance WhatsApp pré-remplie.
- **Envoi direct** : « 📲 Envoyer le PDF » (feuille de partage du téléphone, avec le fichier), WhatsApp (numéro du client, 0… converti en 243…) et e-mail. Hors feuille de partage, le PDF est téléchargé puis à joindre (WhatsApp/e-mail ne permettent pas de pré-joindre un fichier depuis une page web).
- Les données de suivi restent sur l'appareil (clé EXB_DOCS_V1).
