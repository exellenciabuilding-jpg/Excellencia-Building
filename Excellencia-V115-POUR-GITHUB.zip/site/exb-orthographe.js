/* Excellencia Building — V99 ORTHOGRAPHE RENFORCÉE (s'ajoute à exb-menu-contextuel.js, à charger APRÈS lui).
 * 1) Dictionnaire étendu (vocabulaire BTP, formation, administration, finance) : accents oubliés + fautes courantes.
 *    Chaque mot de la liste ci-dessous est écrit correctement ; la forme sans accent en est déduite automatiquement.
 *    Les mots ambigus (a/à, ou/où, sur/sûr, marche/marché, tache/tâche, cote/côté, paye/payé…) n'y figurent PAS :
 *    on ne corrige jamais un mot qui existe aussi sans accent.
 * 2) Suggestions « faute de frappe probable » (1 lettre de différence avec un mot connu) : proposées dans le menu du clic droit
 *    et dans « Signaler les fautes possibles », JAMAIS appliquées automatiquement.
 * 3) EXB_SPELL.check(texte) : liste les fautes sûres (dictionnaire) et probables (suggestions) sans rien modifier.
 * Retrait : supprimer la balise <script src="exb-orthographe.js"> (le menu garde sa liste de base). */
(function (w) {
  'use strict';
  var S = w.EXB_SPELL; if (!S || !S.dict) { return; }

  function strip(s) { return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }

  /* mots écrits correctement ; la clé fautive = même mot sans accents/cédille/tréma (uniquement si elle diffère) */
  var OK = ('béton bétonnage bétonnière bâtiment bâtiments matériau matériaux matériel matériels quantité quantités désignation désignations qualité sécurité propriétaire propriétaires société sociétés réseau réseaux ' +
    'téléphone téléphones numéro numéros délai délais durée durées période périodes général générale généraux très prêt prêts vérifié vérifiée vérifiés vérifiées terminée terminées déjà être même mêmes problème problèmes système systèmes thème thèmes coût coûts ' +
    'réalisation réalisations réalisé réalisée réalisés aménagement aménagements rénovation électrique électriques électricité électricien ingénieur ingénieurs ingénierie préparation vérification modèle modèles catégorie catégories référence références règlement règlements ' +
    'épaisseur façade façades maçon maçons maçonnerie clôture réception événement événements étude études école écoles tôle tôles résistance définitivement complément supplément accès progrès ' +
    'déplacement déplacements équipement équipements équipe équipes échéance échéances métier métiers dégâts dépôt dépôts hôpital hôtel contrôle contrôles prévu prévus prévision prévisions évaluation élévation élévations géométrie géotechnique étage étages séjour ' +
    /* chantier & construction */
    'échafaudage échafaudages étanchéité plâtre plâtrier peintre fenêtre fenêtres véranda géomètre bureau-d’études béton-armé ' +
    'fondation-profonde terrassement excavation décennale décennales réserve réserves levée récolement récapitulatif ' +
    'résidence résidences propriété propriétés immeuble-à-étages hygiène environnement prévention conducteur-de-travaux ' +
    'câble câbles câblage éclairage évacuation écoulement égout égouts assainissement drainage ventilation climatisation ' +
    'détail détails dimension dimensions hauteur largeur épaisseur-minimale coupe élévation-latérale ' +
    'bénéficiaire bénéficiaires créance créances débit crédit trésorerie comptabilité comptable dépense dépenses recette recettes bénéfice bénéfices intérêt intérêts pénalité pénalités ' +
    'chèque chèques espèces règlement-intérieur acompte-versé échéancier priorité priorités urgence résultat résultats ' +
    /* formation & administration */
    'épreuve épreuves présence présences nationalité nationalités diplôme diplômes félicitations mathématiques physique-chimie ' +
    'université universités éducation élève élèves licence-professionnelle expérience expériences compétence compétences responsabilité responsabilités ' +
    'séance séances séminaire séminaires thèse mémoire-de-fin-d’études stagiaire-vérifié date-de-naissance lieu-de-naissance ' +
    'téléchargement téléchargé téléchargée données paramètres désactivé désactivée créé créée supprimée modifiée ' +
    'enregistrée validée approuvée refusée annulée terminée payée impayée envoyée reçue reçues livrée livrées ' +
    'inscription-annulée délivré délivrée délivrés délivrées décerné décernée ' +
    'été-déjà année années entrée entrées sortie sorties arrêt arrêts début débuts fréquence fréquences ' +
    'cérémonie cérémonies célébration réunion-prévue réalisée prévue prévues ' +
    'à-côté où-êtes déjà-fait ' +
    'créer éditer générer imprimer vérifier télécharger enregistrer-sous ' +
    'élaboré élaborée élaborés établi établie établis établissement établissements ' +
    'bibliothèque bibliothèques catégorie-professionnelle spécialité spécialités spécialiste spécialistes spécifique spécifiques ' +
    'géologie géotechnicien topographe topographie ' +
    'mètre-carré mètres-carrés hectare-aménagé périmètre périmètres ' +
    'sécurité-incendie extincteur extincteurs ' +
    'représentant représentante représentants gérant gérante gérants directrice-générale directeur-général ' +
    'téléphone-mobile courriel-professionnel adresse-électronique ' +
    'réponse réponses question-posée énoncé énoncés corrigé corrigés ' +
    'événementiel dépannage dépanneur réparation réparations ' +
    'régulier régulière réguliers régulièrement sérieux sérieuse précédent précédente précédents précédentes ' +
    'différent différente différents différentes éventuel éventuelle éventuellement ' +
    'nécessaire nécessaires nécessité nécessaires-requis obligatoire-requis ' +
    'développement développements développé développée ' +
    'intérieur intérieure intérieurs extérieur extérieure extérieurs supérieur supérieure supérieurs inférieur inférieure inférieurs ' +
    'première premières dernière dernières ' +
    'élément éléments élevé élevée ' +
    'référencé référencée règle-générale ' +
    'décision décisions déclaration déclarations décalage ' +
    'périodique périodiques mensuelle mensuelles hebdomadaire hebdomadaires ' +
    'bâtisse bâtisseur bâche bâches ' +
    'hébergement hébergé ' +
    'fiabilité sûreté ' +
    'cohérence cohérent cohérente ' +
    'opérationnel opérationnelle opérationnels ' +
    'modifié-le créé-le ' +
    'accès-réservé libéré libérée libérés ' +
    'prénom prénoms ' +
    'bénévole bénévoles ' +
    'déroulement déroulé ' +
    'détaillé détaillée détaillés ' +
    'désigné désignée désignés ' +
    'économie économique économiques économies ' +
    'écran écrans ' +
    'écriture écritures ' +
    'évolution évolutions ' +
    'exécution exécuté exécutée ' +
    'étape étapes ' +
    'étroit étroite ' +
    'étudiant étudiante étudiants étudiantes ' +
    'opération-réalisée').split(/\s+/);

  /* on retire les mots composés « a-b » servant uniquement de repères et les mots dont la forme sans accent existe en français */
  var AMBIG = /^(été|ou|où|à|a|sûr|sur|marché|marche|tâche|tache|côté|cote|payé|paye|payée|modifié|modifie|supprimé|supprime|enregistré|enregistre|validé|valide|créé|cree|élevé|eleve|décalage|décision|désigné|designe|résumé|resume|mémoire|mur|mûr|âge|age|près|pres|dû|du|là|la|ça|ca|jeûne|jeune|pêche|peche|côte|forêt|foret|fût|fut|boîte|boite|maïs|mais|nôtre|notre|vôtre|votre|cèdre|cedre|pâte|pate|mètre|metre|crédit|credit|débit|debit|élève|eleve|licence|règle|regle|générale|etat|état)$/i;
  var vocab = {};      /* forme sans accents -> forme correcte (pour les suggestions) */
  var added = 0;
  OK.forEach(function (wd) {
    if (!wd || /-/.test(wd)) return;
    var low = wd.toLowerCase(), key = strip(low);
    vocab[key] = low;
    if (key === low) return;                 /* aucun accent : rien à corriger */
    if (AMBIG.test(low)) return;
    if (!S.dict[key]) { S.dict[key] = low; added++; }
  });
  /* mots courants sans accent : ils servent seulement à ne pas signaler un mot correct comme « suspect » */
  ('chantier chantiers ouvrier ouvriers ouvrière béton-armé plan plans devis facture factures client clients projet projets formation formations formateur formateurs ' +
    'participant participants apprenant apprenants certificat certificats attestation attestations paiement paiements montant montants prix tarif tarifs ' +
    'mur murs dalle dalles poutre poutres poteau poteaux semelle semelles radier ciment mortier gravier sable fer fers acier bois toiture charpente ' +
    'carrelage peinture plomberie menuiserie ferraillage coffrage fondation fondations terrain parcelle architecte entreprise société travaux ' +
    'logiciel ordinateur fichier dossier document documents adresse matricule inscription réception livraison commande commandes fournisseur fournisseurs ' +
    'bureau étude études topographie structure structures calcul calculs métré métrés quantité quantités unité unités total totaux ' +
    'ingénieur ingénieurs technicien techniciens chef conducteur directeur directrice gérant responsable assurance garantie qualité sécurité').split(/\s+/).forEach(function (wd) {
    if (wd && !/-/.test(wd)) { var k = strip(wd.toLowerCase()); if (!vocab[k]) vocab[k] = wd.toLowerCase(); }
  });

  /* fautes de frappe / d'orthographe fréquentes (mot fautif -> mot correct) */
  var TYPOS = {
    'aujourdhui': 'aujourd’hui', 'appeller': 'appeler', 'apartient': 'appartient', 'apartenir': 'appartenir', 'dificile': 'difficile', 'dificulté': 'difficulté', 'difficultée': 'difficulté',
    'developement': 'développement', 'developpement': 'développement', 'devellopement': 'développement', 'develloppement': 'développement', 'developper': 'développer',
    'neccessaire': 'nécessaire', 'necessaire': 'nécessaire', 'necessité': 'nécessité', 'ocasion': 'occasion', 'ocupé': 'occupé', 'occuper': 'occuper', 'aprentissage': 'apprentissage', 'apprentisage': 'apprentissage',
    'terasement': 'terrassement', 'terassement': 'terrassement', 'terrasement': 'terrassement', 'echafodage': 'échafaudage', 'echafaudage': 'échafaudage', 'etancheite': 'étanchéité', 'etanchéité': 'étanchéité',
    'ferrailage': 'ferraillage', 'feraillage': 'ferraillage', 'carelage': 'carrelage', 'carlage': 'carrelage', 'platre': 'plâtre', 'plafon': 'plafond', 'plafont': 'plafond', 'cloizon': 'cloison', 'cloisson': 'cloison',
    'fondatation': 'fondation', 'fondatations': 'fondations', 'fondassion': 'fondation', 'chanter': 'chantier', 'chantié': 'chantier', 'charpentte': 'charpente', 'toiturre': 'toiture',
    'ingenieur': 'ingénieur', 'ingenieure': 'ingénieure', 'architechte': 'architecte', 'architecte': 'architecte', 'archtecte': 'architecte', 'electricte': 'électricité', 'electriciter': 'électricité',
    'maçonerie': 'maçonnerie', 'maconerie': 'maçonnerie', 'maçonnrie': 'maçonnerie', 'menusier': 'menuisier', 'menuiserrie': 'menuiserie', 'plombrie': 'plomberie', 'plomberi': 'plomberie',
    'formateure': 'formateur', 'formatrise': 'formatrice', 'aprenant': 'apprenant', 'aprenants': 'apprenants', 'apprenent': 'apprenant', 'particpant': 'participant', 'particpants': 'participants', 'participent': 'participant',
    'inscripton': 'inscription', 'inscription': 'inscription', 'certficat': 'certificat', 'certifcat': 'certificat', 'certificat': 'certificat', 'atestation': 'attestation', 'attestaion': 'attestation',
    'paiment': 'paiement', 'payement': 'paiement', 'payements': 'paiements', 'paiments': 'paiements', 'reglement': 'règlement', 'reglment': 'règlement', 'acompte': 'acompte', 'accompte': 'acompte',
    'quantitée': 'quantité', 'qantité': 'quantité', 'quantite': 'quantité', 'metrage': 'métrage', 'metré': 'métré', 'devi': 'devis', 'factur': 'facture', 'fature': 'facture', 'factues': 'factures',
    'bordeau': 'bordereau', 'bordereaux': 'bordereaux', 'avenent': 'avenant', 'avenents': 'avenants', 'reception': 'réception', 'receptioon': 'réception', 'liveraison': 'livraison', 'livrasion': 'livraison',
    'fournisseure': 'fournisseur', 'fournisseurs': 'fournisseurs', 'comande': 'commande', 'comandes': 'commandes', 'commende': 'commande', 'adresse': 'adresse', 'adrese': 'adresse', 'adrsse': 'adresse',
    'telephne': 'téléphone', 'telefone': 'téléphone', 'telephon': 'téléphone', 'telephoner': 'téléphoner', 'matricul': 'matricule', 'matriclue': 'matricule', 'matricule': 'matricule',
    'parmis': 'parmi', 'malgrès': 'malgré', 'malgres': 'malgré', 'quelquefoi': 'quelquefois', 'quelques-fois': 'quelquefois', 'toujour': 'toujours', 'tjrs': 'toujours', 'beaucoup': 'beaucoup', 'beacoup': 'beaucoup', 'beaucou': 'beaucoup',
    'cependent': 'cependant', 'pourtant': 'pourtant', 'egalement': 'également', 'egalment': 'également', 'evidement': 'évidemment', 'evidemment': 'évidemment', 'recemment': 'récemment', 'rapidment': 'rapidement',
    'immediatement': 'immédiatement', 'immediatment': 'immédiatement', 'immediat': 'immédiat', 'definitif': 'définitif', 'definitive': 'définitive', 'definitivment': 'définitivement',
    'proffesionnel': 'professionnel', 'profesionnel': 'professionnel', 'professionel': 'professionnel', 'professionelle': 'professionnelle', 'profesionnelle': 'professionnelle',
    'competance': 'compétence', 'competence': 'compétence', 'competances': 'compétences', 'compétance': 'compétence', 'compétances': 'compétences',
    'responsable': 'responsable', 'responsabilite': 'responsabilité', 'resposable': 'responsable', 'respnsable': 'responsable', 'enterprise': 'entreprise', 'entreprize': 'entreprise', 'entrprise': 'entreprise',
    'directeure': 'directeur', 'directrise': 'directrice', 'general': 'général', 'generale': 'générale', 'secretaire': 'secrétaire', 'secretariat': 'secrétariat', 'comptabilite': 'comptabilité',
    'sauvgarde': 'sauvegarde', 'sauvgarder': 'sauvegarder', 'sauvegarde': 'sauvegarde', 'imprimmer': 'imprimer', 'telecharger': 'télécharger', 'telechargement': 'téléchargement',
    'rendez vous': 'rendez-vous', 'rendezvous': 'rendez-vous', 'aprés': 'après', 'apres': 'après', 'pres': 'pres', 'a peu pres': 'à peu près', 'dèja': 'déjà', 'dèjà': 'déjà',
    'seperer': 'séparer', 'seperé': 'séparé', 'sepa': 'sepa', 'separer': 'séparer', 'separement': 'séparément', 'enregistrment': 'enregistrement', 'enregistrer': 'enregistrer', 'enregistremnt': 'enregistrement',
    'modification': 'modification', 'modifcation': 'modification', 'suppresion': 'suppression', 'supression': 'suppression', 'creation': 'création', 'creations': 'créations', 'crée': 'crée',
    'validatoin': 'validation', 'validaton': 'validation', 'verificaton': 'vérification', 'verifcation': 'vérification', 'estimmation': 'estimation', 'estimaton': 'estimation',
    'bétonier': 'bétonnier', 'betonier': 'bétonnier', 'betonniere': 'bétonnière', 'betoniere': 'bétonnière', 'betonage': 'bétonnage', 'betonnage': 'bétonnage',
    'ciement': 'ciment', 'cimment': 'ciment', 'mortié': 'mortier', 'mortié': 'mortier', 'gravié': 'gravier', 'sabble': 'sable', 'agrégat': 'agrégat', 'agregat': 'agrégat',
    'etage': 'étage', 'etages': 'étages', 'rez de chaussé': 'rez-de-chaussée', 'rez-de-chaussé': 'rez-de-chaussée', 'rez de chaussee': 'rez-de-chaussée', 'rez-de-chaussee': 'rez-de-chaussée'
  };
  Object.keys(TYPOS).forEach(function (k) {
    if (/\s|-/.test(k)) return;                                  /* les expressions sont traitées plus bas */
    var v = TYPOS[k]; if (k.toLowerCase() === v.toLowerCase()) return;
    if (!S.dict[k.toLowerCase()]) { S.dict[k.toLowerCase()] = v; added++; }
    vocab[strip(v.toLowerCase())] = vocab[strip(v.toLowerCase())] || v.toLowerCase();
  });
  /* on garantit que les mots ambigus ne sont jamais corrigés seuls */
  ['ete', 'regle', 'etat', 'fondation', 'dossier', 'entreprise', 'immeuble', 'structure', 'cuisine', 'salle', 'sous-sol', 'estimatif', 'mur', 'sur', 'marche', 'tache', 'cote', 'paye', 'resume', 'licence', 'enregistre', 'valide', 'modifie', 'supprime', 'cree', 'pres', 'eleve', 'general', 'generale'].forEach(function (k) {
    if (k === 'general' || k === 'generale') return;             /* « general » (sans accent) n'existe pas en français : on garde la correction */
    delete S.dict[k];
  });
  /* expressions */
  if (S.phrases && S.phrases.push) {
    [[/\brez[ -]de[ -]chauss[ée]e?\b/gi, 'rez-de-chaussée'], [/\bbureau d['’ ]etudes?\b/gi, 'bureau d’études'], [/\bmaitre d['’ ]ouvrage\b/gi, 'maître d’ouvrage'], [/\bmaitre d['’ ]oeuvre\b/gi, 'maître d’œuvre'],
      [/\bmaitre d['’ ]œuvre\b/gi, 'maître d’œuvre'], [/\bchef de chantié\b/gi, 'chef de chantier'], [/\bconducteur de travaux\b/gi, 'conducteur de travaux'], [/\bpermi de construire\b/gi, 'permis de construire'],
      [/\btitre foncié\b/gi, 'titre foncier'], [/\brendez ?vous\b/gi, 'rendez-vous'], [/\ba peu pres\b/gi, 'à peu près'], [/\bquelques fois\b(?=[,.]| que)/gi, 'quelquefois'], [/\bsous[ -]sol\b/gi, 'sous-sol'],
      [/\bcest a dire\b/gi, 'c’est-à-dire'], [/\bc['’]est a dire\b/gi, 'c’est-à-dire'], [/\bbeton arm[ée]\b/gi, 'béton armé'], [/\bcharge d['’ ]affaire\b/gi, 'chargé d’affaires'], [/\bdate de naissence\b/gi, 'date de naissance'],
      [/\blieu de naissence\b/gi, 'lieu de naissance'], [/\bnumero de telephone\b/gi, 'numéro de téléphone'], [/\bpiece d['’ ]identite\b/gi, 'pièce d’identité'], [/\bcarte d['’ ]identite\b/gi, 'carte d’identité']
    ].forEach(function (p) { S.phrases.push(p); });
  }

  /* ---------- suggestions « faute de frappe probable » ---------- */
  function osa(a, b, max) {            /* distance d'édition avec transposition ; s'arrête au-delà de max */
    var la = a.length, lb = b.length; if (Math.abs(la - lb) > max) return max + 1;
    var d = []; for (var i = 0; i <= la; i++) { d[i] = [i]; } for (var j = 1; j <= lb; j++) d[0][j] = j;
    for (i = 1; i <= la; i++) for (j = 1; j <= lb; j++) {
      var c = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c);
      if (i > 1 && j > 1 && a.charAt(i - 1) === b.charAt(j - 2) && a.charAt(i - 2) === b.charAt(j - 1)) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
    }
    return d[la][lb];
  }
  function stem(k) { return k.replace(/(s|x)$/, '').replace(/e$/, '').replace(/(s|x)$/, ''); }
  var byStem = {}, list = Object.keys(vocab);
  list.forEach(function (k) { byStem[stem(k)] = 1; });
  function known(k) { return !!(vocab[k] || byStem[stem(k)] || S.dict[k]); }
  function suggest(word) {
    if (!word || word.length < 6 || /[0-9@_\/\\]/.test(word)) return null;
    var k = strip(word.toLowerCase());
    if (known(k)) return null;
    var best = null, bd = 2, st = stem(k);
    for (var i = 0; i < list.length; i++) {
      var v = list[i]; if (v.charAt(0) !== k.charAt(0) || Math.abs(v.length - k.length) > 1 || v.length < 6) continue;
      var dd = osa(st, stem(v), 1); if (dd < bd) { bd = dd; best = v; if (dd === 0) break; }
    }
    if (!best || bd > 1) return null;
    return vocab[best];
  }
  function matchCase(src, rep) {
    if (src.length > 1 && src === src.toUpperCase()) return rep.toUpperCase();
    if (src.charAt(0) !== src.charAt(0).toLowerCase()) return rep.charAt(0).toUpperCase() + rep.slice(1);
    return rep;
  }
  /* analyse sans rien modifier : [{w, rep, sure}] ; les mots en majuscule au milieu d'une phrase (noms propres) sont ignorés */
  function check(text, opt) {
    opt = opt || {}; var out = [], src = String(text == null ? '' : text), seen = {};
    var re = /[A-Za-zÀ-ÿŒœ]+(?:[’'][A-Za-zÀ-ÿŒœ]+)?/g, m;
    while ((m = re.exec(src)) && out.length < 60) {
      var tok = m[0], wd = tok.replace(/^.*[’']/, ''), low = wd.toLowerCase();
      if (/@|:\/\/|www\./i.test(src.slice(Math.max(0, m.index - 1), m.index + tok.length + 4)) || /[0-9_\\\/#]/.test(src.charAt(m.index + tok.length) || '')) continue;
      var prev = src.slice(0, m.index).replace(/\s+$/, ''), startSent = !prev || /[.!?:\n]$/.test(prev);
      var isCap = wd.charAt(0) !== wd.charAt(0).toLowerCase() && wd !== wd.toUpperCase();
      if (isCap && !startSent) continue;
      if (seen[low]) continue;
      var rep = S.dict[low];
      if (rep && rep.toLowerCase() !== low) { seen[low] = 1; out.push({ w: wd, rep: matchCase(wd, rep), sure: true }); continue; }
      if (!opt.sureOnly && !isCap) { var sg = suggest(wd); if (sg && sg.toLowerCase() !== low) { seen[low] = 1; out.push({ w: wd, rep: matchCase(wd, sg), sure: false }); } }
    }
    var dbl = /\b(le|la|les|de|du|des|un|une|et|à|en|que|pour|dans|sur|au|aux)\s+\1\b/gi, dm;
    while ((dm = dbl.exec(src)) && out.length < 60) out.push({ w: dm[0], rep: dm[1], sure: true });
    return out;
  }

  S.suggest = suggest; S.check = check; S.vocabSize = list.length; S.dictSize = Object.keys(S.dict).length;
  S.version = 'V99-ortho-2';
})(window);
