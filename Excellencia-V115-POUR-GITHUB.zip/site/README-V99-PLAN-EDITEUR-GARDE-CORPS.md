# V99 — Éditeur de plan : garde-corps tracé et styles

Fichiers modifiés : `plan-editeur/index.html`, `plan-editeur/catalogue.js`, `sw.js` (version du cache).

- **Tracé** : outil Garde-corps → touchez chaque angle ; un garde-corps est créé à chaque segment (longueur et angle réels). Double-touche (ou Terminer) pour arrêter ; Maj = angle verrouillé comme pour les murs. Aperçu en pointillé.
- **Styles** (panneau Propriétés d'un garde-corps) : Barreaux (par défaut), Verre, Câbles inox. Appliqué en 3D et en visite ; le métré reste en ml.
- Hauteur, épaisseur, rotation et « garde-corps 3 côtés » d'une dalle de balcon : inchangés.

Non touchés : Maillage, Élévation, Détail (grisés « bientôt », sans fausse fonction) ; Calques et Trace (lot 2). Poutre existe déjà dans le moteur.
Testé : syntaxe des scripts uniquement ; à essayer dans le navigateur avant dépôt.
