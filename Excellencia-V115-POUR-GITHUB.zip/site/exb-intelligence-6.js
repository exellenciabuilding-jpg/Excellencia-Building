/* EXCELLENCIA INTELLIGENCE — lot 6 : plan-éditeur ↔ métré, calcul de structure ↔ métré, BIM/IFC, chantier (terrain).
 * Extension (à charger APRÈS exb-intelligence.js). LECTURE SEULE : aucune donnée n'est modifiée par ce fichier.
 *  • Plan-éditeur ↔ métré : lignes du métré venant d'un plan supprimé ou en double ; plan modifié depuis son envoi au métré ; plans vides, murs de longueur nulle, plans de même nom.
 *  • Calcul de structure ↔ métré : section des poteaux de la note de calcul comparée aux « Amorces de poteaux » du métré (même projet).
 *  • BIM : modèles en double / dessin ou projet introuvable ; points BIM sans modèle, doublons BCF, points urgents ouverts depuis plus de 30 jours.
 *  • Chantier : bons de commande (payé > total, réception > commandé), situations de travaux (% hors 0–100, cumul décroissant), pointages (doublons, coût ≠ taux × jours), rapports de chantier (doublon par jour), tâches terrain en retard.
 *  • Documents : rapport chantier par projet (HTML, hors ligne). Pour retirer : supprimer la balise <script src="exb-intelligence-6.js">. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot6) return; I.lot6 = true;
    var H = I.helpers, list = H.list, lab = H.lab, num = H.num, norm = H.norm, esc = H.esc, toast = H.toast;
    function money(x) { return (Math.round(x * 100) / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
    function F(sev, mod, msg, col, id, extra) { var o = { sev: sev, mod: mod, msg: msg, ref: { col: col, id: id } }; if (extra) for (var k in extra) o[k] = extra[k]; return o; }
    function t0() { return H.today(); }
    function ago(days) { return new Date(Date.now() - days * 864e5).toISOString().slice(0, 10); }
    function pname(id, P) { var p = (P || list('exb_projects')).filter(function (x) { return x.id === id; })[0]; return p ? lab(p) : (id || 'sans projet'); }
    function dupBy(arr, keyFn, col, mod, what, sev, show) {
      var seen = {}, out = []; arr.forEach(function (o) { var k = keyFn(o); if (!k) return; if (seen[k]) out.push(F(sev || 'alerte', mod, 'Doublon possible (' + what + ') : ' + (show ? show(seen[k]) + ' et ' + show(o) : '« ' + lab(seen[k]) + ' » et « ' + lab(o) + ' »'), col, o.id)); else seen[k] = o; });
      return out;
    }

    /* ================= PLAN-ÉDITEUR ================= */
    function plans() {
      var out = [], S; try { S = (typeof exbStorage !== 'undefined') ? exbStorage : w.localStorage; } catch (e) { return out; }
      try { for (var i = 0, n = S.length; i < n; i++) { var k = S.key(i); if (k && k.indexOf('exbPlanEd.p.') === 0) { var v = JSON.parse(S.getItem('exbPlanEd.p.' + k.slice(12)) || S.getItem(k) || 'null'); if (v && v.data) out.push({ id: k.slice(12), name: v.name || v.data.name || '?', date: +v.date || 0, D: v.data }); } } } catch (e) {}
      return out;
    }
    I.calc.planStats = function (p) {
      var walls = 0, zero = 0, len = 0, rooms = 0; (p.D.levels || []).forEach(function (l) { (l.walls || []).forEach(function (m) { walls++; if (m.a && m.b) { var L = Math.hypot(num(m.b[0]) - num(m.a[0]), num(m.b[1]) - num(m.a[1])); if (!(L > 0.001)) zero++; else len += L; } }); rooms += (l.rooms || []).length; });
      return { walls: walls, zero: zero, length: len, rooms: rooms, levels: (p.D.levels || []).length };
    };
    function mets() { return list('exb_metre').filter(function (m) { return m && m.hdr; }); }
    function mlab(m) { return (m.hdr && (m.hdr.no || m.hdr.project || m.hdr.client)) || m.id || '?'; }
    function planSrc(m) { return (Array.isArray(m.extra) ? m.extra : []).filter(function (l) { return l && typeof l.src === 'string' && l.src.indexOf('planedit:') === 0; }); }
    I.registerEngine('calcul.plan', 'Contrôle des plans de maison et de leur lien avec le métré', function () { return []; });
    I.addRule({ id: 'plan.editeur', check: function () {
      var out = [], PL = plans();
      PL.forEach(function (p) {
        var s = I.calc.planStats(p), nm = 'Plan « ' + p.name + ' » : ';
        if (s.zero) out.push(F('alerte', 'Plan', nm + s.zero + ' mur(s) de longueur nulle (comptés dans les quantités)', 'exbPlanEd', p.id));
        if (!s.walls && p.D.levels && p.D.levels.length && (p.D.levels[0].rooms || []).length === 0) out.push(F('info', 'Plan', nm + 'plan vide (aucun mur)', 'exbPlanEd', p.id));
      });
      return out.concat(dupBy(PL, function (p) { return p.name && !/sans titre/i.test(p.name) ? norm(p.name) : ''; }, 'exbPlanEd', 'Plan', 'même nom de plan', 'info', function (p) { return '« ' + p.name + ' »'; })); } });
    I.addRule({ id: 'plan.metre', check: function () {
      var out = [], PL = plans(), ids = {}; PL.forEach(function (p) { ids[p.id] = p; });
      mets().forEach(function (m) {
        var L = planSrc(m), nm = 'Métré ' + mlab(m) + ' : ', gone = {}, seen = {}, dup = 0, newer = {};
        L.forEach(function (l) {
          var pid = l.src.split(':')[1]; if (!ids[pid]) gone[pid] = 1;
          if (seen[l.src]) dup++; seen[l.src] = 1;
          var upd = Date.parse(m.updated || ''); if (ids[pid] && upd && ids[pid].date > upd + 60000) newer[pid] = ids[pid];
        });
        var g = Object.keys(gone).length; if (g) out.push(F('alerte', 'Plan ↔ métré', nm + 'lignes issues de ' + g + ' plan(s) qui n’existe(nt) plus (quantités à vérifier)', 'exb_metre', m.id));
        if (dup) out.push(F('erreur', 'Plan ↔ métré', nm + dup + ' ligne(s) de plan en double (même source)', 'exb_metre', m.id));
        Object.keys(newer).forEach(function (pid) { out.push(F('info', 'Plan ↔ métré', nm + 'le plan « ' + newer[pid].name + ' » a été modifié après l’enregistrement du métré : renvoyer les quantités au métré si nécessaire', 'exb_metre', m.id)); });
      }); return out; } });

    /* ================= CALCUL DE STRUCTURE ↔ MÉTRÉ ================= */
    function notes() { return list('exb_calc_notes'); }
    function cols(nt) { return (nt.els || []).filter(function (e) { return e.type === 'col' && e.v; }); }
    function dim(v) { var a = num(v.a), b = v.forme === 'circulaire' ? a : num(v.b); return a > 0 && b > 0 ? [Math.min(a, b), Math.max(a, b)] : null; }
    function close(x, y) { return Math.abs(x - y) <= 0.05 * Math.max(x, y); }
    function metrePoteau(m) { var P = m.ov && m.ov.P || {}, L = num(P.F27), l = num(P.H27); return L > 0 && l > 0 ? [Math.min(L, l), Math.max(L, l)] : null; }
    I.calc.sectionPoteau = function (v) { var s = dim(v || {}); return s ? s[0] * s[1] : 0; };
    I.registerEngine('calcul.structure-metre', 'Cohérence note de calcul ↔ métré (sections de poteaux)', function () { return []; });
    I.addRule({ id: 'be.metre', check: function () {
      var out = [], N = notes();
      mets().forEach(function (m) {
        var pid = m.project_id, md = metrePoteau(m); if (!pid || !md) return;
        var cs = []; N.filter(function (nt) { return nt.project_id === pid; }).forEach(function (nt) { cols(nt).forEach(function (e) { var s = dim(e.v); if (s) cs.push({ s: s, nt: nt, e: e }); }); });
        if (!cs.length) return;
        if (!cs.some(function (c) { return close(c.s[0], md[0]) && close(c.s[1], md[1]); })) out.push(F('alerte', 'Structure ↔ métré', 'Métré ' + mlab(m) + ' : amorces de poteaux ' + md[0] + '×' + md[1] + ' cm ; aucune section de poteau identique dans les notes de calcul du projet (' + cs.map(function (c) { return c.s[0] + '×' + c.s[1]; }).filter(function (x, i, a) { return a.indexOf(x) === i; }).join(', ') + ' cm) — à vérifier avec l’ingénieur', 'exb_metre', m.id));
      }); return out; } });

    /* ================= BIM ================= */
    var KM = 'exb_v94_bim_models', KI = 'exb_v94_bim_issues', KD = 'exb_v94_drawings';
    I.registerEngine('calcul.bim', 'Contrôle des modèles et des points BIM (BCF)', function () { return []; });
    I.addRule({ id: 'bim.modeles', check: function () {
      var out = [], M = list(KM), Dw = list(KD), P = list('exb_projects');
      M.forEach(function (m) {
        var nm = 'Modèle BIM « ' + (m.ref || m.name || m.id) + ' » : ', pid = m.project_id || m.project;
        if (m.drawing_id && Dw.length && !Dw.some(function (x) { return x.id === m.drawing_id; })) out.push(F('erreur', 'BIM', nm + 'dessin rattaché introuvable', KM, m.id));
        if (pid && P.length && !P.some(function (p) { return p.id === pid || norm(p.name) === norm(pid); })) out.push(F('info', 'BIM', nm + 'projet « ' + pid + ' » introuvable', KM, m.id));
      });
      return out.concat(dupBy(M, function (m) { return m.ref ? norm(m.project_id || m.project || '') + '|' + norm(m.ref) : ''; }, KM, 'BIM', 'même référence de modèle dans le projet', 'alerte', function (m) { return '« ' + (m.ref || m.id) + ' » (' + m.id + ')'; })); } });
    I.addRule({ id: 'bim.points', check: function () {
      var out = [], M = list(KM), Is = list(KI), P = list('exb_projects'), lim = ago(30);
      Is.forEach(function (x) {
        var nm = 'Point BIM « ' + (x.title || x.id) + ' » : ', open = x.status !== 'closed';
        if (x.model_id && M.length && !M.some(function (m) { return m.id === x.model_id; })) out.push(F('erreur', 'BIM', nm + 'modèle rattaché introuvable', KI, x.id));
        if (x.project_id && P.length && !P.some(function (p) { return p.id === x.project_id; })) out.push(F('info', 'BIM', nm + 'projet rattaché introuvable', KI, x.id));
        if (open && /high|haute|urgent|critique/i.test(String(x.priority || '')) && x.created_at && String(x.created_at).slice(0, 10) < lim) out.push(F('alerte', 'BIM', nm + 'urgent, ouvert depuis plus de 30 jours', KI, x.id));
        if (open && !x.owner) out.push(F('info', 'BIM', nm + 'aucun responsable', KI, x.id));
      });
      return out.concat(dupBy(Is, function (x) { return x.bcf_guid ? norm(x.bcf_guid) : ''; }, KI, 'BIM', 'même identifiant BCF', 'erreur', function (x) { return '« ' + (x.title || x.id) + ' » (' + x.id + ')'; })); } });

    /* ================= CHANTIER (TERRAIN) ================= */
    I.calc.bc = function (p) { var tot = (p.lines || []).reduce(function (a, l) { return a + num(l.q) * num(l.pu); }, 0), paid = (p.payments || []).reduce(function (a, x) { return a + num(x.amount); }, 0); return { total: tot, paid: paid, reste: tot - paid }; };
    I.calc.situation = function (s) { var av = (s.avenants || []).reduce(function (a, x) { return a + num(x.amount); }, 0), mk = num(s.market) + av; return { marche: mk, cumul: mk * num(s.pct) / 100 }; };
    I.registerEngine('calcul.chantier', 'Contrôle des bons de commande, situations, pointages, rapports et tâches de chantier', function () { return []; });
    I.addRule({ id: 'chantier.bc', check: function () {
      var out = [], PO = list('exb_purchase_orders'), S = list('exb_suppliers'), P = list('exb_projects');
      PO.forEach(function (p) {
        var nm = 'Bon de commande ' + (p.no || p.id) + ' : ', c = I.calc.bc(p);
        if (c.total > 0 && c.paid > c.total + 0.01) out.push(F('erreur', 'Chantier', nm + 'payé (' + money(c.paid) + ') supérieur au total (' + money(c.total) + ')', 'exb_purchase_orders', p.id));
        if ((p.lines || []).some(function (l) { return num(l.rec) > num(l.q) + 1e-9; })) out.push(F('alerte', 'Chantier', nm + 'quantité reçue supérieure à la quantité commandée', 'exb_purchase_orders', p.id));
        if ((p.lines || []).some(function (l) { return num(l.q) < 0 || num(l.pu) < 0; })) out.push(F('erreur', 'Chantier', nm + 'quantité ou prix négatif', 'exb_purchase_orders', p.id));
        if (p.date && p.expected && p.expected < p.date) out.push(F('alerte', 'Chantier', nm + 'livraison prévue avant la date de commande', 'exb_purchase_orders', p.id));
        if (p.supplier_id && S.length && !S.some(function (s) { return s.id === p.supplier_id; })) out.push(F('erreur', 'Chantier', nm + 'fournisseur introuvable', 'exb_purchase_orders', p.id));
        if (p.project_id && P.length && !P.some(function (x) { return x.id === p.project_id; })) out.push(F('erreur', 'Chantier', nm + 'projet introuvable', 'exb_purchase_orders', p.id));
      });
      return out.concat(dupBy(PO, function (p) { return p.no ? norm(p.no) : ''; }, 'exb_purchase_orders', 'Chantier', 'même numéro de bon de commande', 'erreur', function (p) { return '« ' + (p.no || p.id) + ' »'; })); } });
    I.addRule({ id: 'chantier.situations', check: function () {
      var out = [], SI = list('exb_situations'), P = list('exb_projects'), by = {};
      SI.forEach(function (s) {
        var nm = 'Situation ' + (s.no || s.id) + ' : ';
        if (num(s.pct) < 0 || num(s.pct) > 100) out.push(F('erreur', 'Chantier', nm + 'avancement de ' + num(s.pct) + ' % hors de 0–100', 'exb_situations', s.id));
        if ('market' in s && num(s.market) <= 0) out.push(F('alerte', 'Chantier', nm + 'montant du marché nul', 'exb_situations', s.id));
        if (num(s.ret) < 0 || num(s.ret) > 20) out.push(F('info', 'Chantier', nm + 'retenue de ' + num(s.ret) + ' % inhabituelle', 'exb_situations', s.id));
        if (s.project_id && P.length && !P.some(function (x) { return x.id === s.project_id; })) out.push(F('erreur', 'Chantier', nm + 'projet introuvable', 'exb_situations', s.id));
        (by[s.project_id] = by[s.project_id] || []).push(s);
      });
      Object.keys(by).forEach(function (pid) { var a = by[pid].slice().sort(function (x, y) { return x.no < y.no ? -1 : x.no > y.no ? 1 : 0; }); for (var i = 1; i < a.length; i++) if (num(a[i].pct) < num(a[i - 1].pct)) out.push(F('alerte', 'Chantier', 'Situation ' + a[i].no + ' (' + pname(pid, P) + ') : avancement ' + num(a[i].pct) + ' % inférieur à la situation précédente (' + num(a[i - 1].pct) + ' %)', 'exb_situations', a[i].id)); });
      return out.concat(dupBy(SI, function (s) { return s.no ? norm(s.project_id || '') + '|' + norm(s.no) : ''; }, 'exb_situations', 'Chantier', 'même numéro de situation dans le projet', 'erreur', function (s) { return '« ' + (s.no || s.id) + ' »'; })); } });
    I.addRule({ id: 'chantier.pointages', check: function () {
      var out = [], TS = list('exb_timesheets'), seen = {};
      TS.forEach(function (t) {
        var nm = 'Pointage de « ' + (t.worker_name || t.worker_id || '?') + ' » le ' + (t.date || '?') + ' : ';
        if (num(t.days) <= 0 || num(t.days) > 1) out.push(F('alerte', 'Chantier', nm + 'nombre de jours ' + num(t.days) + ' hors de ]0 ; 1]', 'exb_timesheets', t.id));
        if ('cost' in t && 'rate' in t && Math.abs(num(t.cost) - num(t.rate) * num(t.days)) > 0.02) out.push(F('erreur', 'Chantier', nm + 'coût différent de taux × jours', 'exb_timesheets', t.id));
        if (t.date && String(t.date).slice(0, 10) > t0()) out.push(F('alerte', 'Chantier', nm + 'date dans le futur', 'exb_timesheets', t.id));
        var k = t.worker_id && t.date ? t.worker_id + '|' + t.project_id + '|' + t.date : ''; if (k) { if (seen[k]) out.push(F('erreur', 'Chantier', nm + 'pointé deux fois sur le même chantier', 'exb_timesheets', t.id)); seen[k] = 1; }
      }); return out; } });
    I.addRule({ id: 'chantier.journal', check: function () {
      var out = [], J = list('exb_site_journal'), P = list('exb_projects');
      J.forEach(function (j) { if (j.date && String(j.date).slice(0, 10) > t0()) out.push(F('alerte', 'Chantier', 'Rapport de chantier du ' + j.date + ' (' + pname(j.project_id, P) + ') : date dans le futur', 'exb_site_journal', j.id)); });
      return out.concat(dupBy(J, function (j) { return j.date && j.project_id ? j.project_id + '|' + j.date : ''; }, 'exb_site_journal', 'Chantier', 'deux rapports le même jour pour le même chantier', 'info', function (j) { return 'rapport du ' + j.date; })); } });
    I.addRule({ id: 'chantier.taches', check: function () {
      var out = [], T = list('exb_taches_terrain'), P = list('exb_projects'), t = t0();
      T.forEach(function (x) {
        var nm = 'Tâche « ' + (x.title || x.id) + ' » : ', done = /termin|valid/i.test(String(x.status || ''));
        if (!done && x.due && String(x.due).slice(0, 10) < t) out.push(F('alerte', 'Chantier', nm + 'échéance dépassée (' + x.due + ')', 'exb_taches_terrain', x.id));
        if (!done && num(x.progress) >= 100) out.push(F('info', 'Chantier', nm + 'avancement 100 % mais statut « ' + (x.status || '?') + ' »', 'exb_taches_terrain', x.id));
        if (!done && !String(x.assignee || '').trim()) out.push(F('info', 'Chantier', nm + 'aucun responsable', 'exb_taches_terrain', x.id));
        if (x.project && P.length && !P.some(function (p) { return p.id === x.project; })) out.push(F('info', 'Chantier', nm + 'projet introuvable', 'exb_taches_terrain', x.id));
      }); return out; } });

    /* ================= DOCUMENT + RECOMMANDATIONS ================= */
    function chantierHtml() {
      var P = list('exb_projects'), PO = list('exb_purchase_orders'), SI = list('exb_situations'), T = list('exb_taches_terrain'), Is = list(KI), t = t0();
      var rows = P.map(function (p) {
        var po = PO.filter(function (x) { return x.project_id === p.id; }), tot = 0, paid = 0; po.forEach(function (x) { var c = I.calc.bc(x); tot += c.total; paid += c.paid; });
        var si = SI.filter(function (x) { return x.project_id === p.id; }).sort(function (a, b) { return a.no < b.no ? -1 : 1; }), last = si[si.length - 1];
        var late = T.filter(function (x) { return x.project === p.id && !/termin|valid/i.test(String(x.status || '')) && x.due && String(x.due).slice(0, 10) < t; }).length;
        var bi = Is.filter(function (x) { return (x.project_id === p.id) && x.status !== 'closed'; }).length;
        return '<tr><td>' + esc(lab(p)) + '</td><td align="right">' + po.length + '</td><td align="right">' + money(paid) + ' / ' + money(tot) + '</td><td align="right">' + (last ? num(last.pct) + ' % (n° ' + esc(last.no) + ')' : '—') + '</td><td align="right">' + late + '</td><td align="right">' + bi + '</td></tr>';
      }).join('');
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Rapport chantier</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Rapport chantier par projet</h1><p>' + t + '</p><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Projet</th><th>Bons de commande</th><th>Payé / total</th><th>Dernière situation</th><th>Tâches en retard</th><th>Points BIM ouverts</th></tr>' + (rows || '<tr><td colspan="6">Aucun projet</td></tr>') + '</table></body></html>';
    }
    function dl(name, html, what) { try { var b = new Blob([html], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); I.log('document', what); } catch (e) { toast('Export impossible.'); } }
    I.docs.chantier = chantierHtml;
    I.addReco(function () {
      var r = [], t = t0(), PL = plans(), M = mets(), N = notes();
      var late = list('exb_taches_terrain').filter(function (x) { return !/termin|valid/i.test(String(x.status || '')) && x.due && String(x.due).slice(0, 10) < t; }).length;
      if (late) r.push({ ic: '⏰', t: late + ' tâche(s) de chantier en retard', x: 'Échéance dépassée et tâche non terminée.', acts: [{ l: 'Ouvrir les tâches terrain', f: function () { var b = d.getElementById('exbTTbtn'); if (b) { try { H.go('chantiers'); } catch (e) {} b.click(); } else H.go('chantiers'); } }] });
      var unsent = PL.filter(function (p) { return I.calc.planStats(p).walls > 0 && !M.some(function (m) { return planSrc(m).some(function (l) { return l.src.split(':')[1] === p.id; }); }); }).length;
      if (unsent) r.push({ ic: '✏️', t: unsent + ' plan(s) de maison jamais envoyé(s) au métré', x: 'Ouvrez le plan puis « Envoyer au métré » pour obtenir les quantités sans ressaisie.', acts: [{ l: 'Ouvrir le plan', f: function () { try { if (w.EXBPLANED) w.EXBPLANED.open(); } catch (e) {} } }] });
      var nb = M.filter(function (m) { var P = m.ov && m.ov.P || {}; return Object.keys(P).some(function (k) { return num(P[k]) > 0; }); }).filter(function (m) { return !m.project_id || !N.some(function (nt) { return nt.project_id === m.project_id; }); }).length;
      if (nb) r.push({ ic: '🏗️', t: nb + ' métré(s) béton sans note de calcul rattachée au projet', x: 'Faites établir et valider la note de calcul correspondante par l’ingénieur.', acts: [{ l: 'Ouvrir le bureau d’études', f: function () { H.go('bureauEtudes'); } }] });
      if (list('exb_projects').length) r.push({ ic: '📋', t: 'Rapport chantier par projet', x: 'Bons de commande, dernière situation, tâches en retard et points BIM ouverts.', acts: [{ l: 'Télécharger le rapport', f: function () { dl('rapport-chantier-' + t + '.html', chantierHtml(), 'Rapport chantier exporté'); } }] });
      return r;
    });
    I.run();
  }
  boot(0);
})(window, document);
