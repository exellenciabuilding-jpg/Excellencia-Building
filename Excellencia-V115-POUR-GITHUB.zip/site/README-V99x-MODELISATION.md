# V99x — Calcul de structure : onglet « Axes & modélisation » (module Bâtiment)

Fichier modifié : `calcul-structure/index.html` (module Bâtiment) ; `sw.js` (cache `exb-v99x-modelisation-1`) ; libellé de version du cadre.
Aucune donnée existante n'est perdue : un bâtiment enregistré s'ouvre comme avant (toutes les poutres sont « présentes » par défaut).

## Ce qui change dans Bâtiment
- **Trois onglets** en haut de l'éditeur : Général (nom, matériaux, niveaux) · **Axes & modélisation** · Calcul (bouton de calcul et résultats, affichés automatiquement après le calcul).
- **Axes — trame** : positions cumulées des axes (A, B, C… / 1, 2, 3…) affichées ; bouton ⊕ pour **insérer un axe** au milieu d'une travée (les poteaux, dalles et poutres retirées sont dupliqués/décalés correctement à tous les niveaux) ; suppression d'une travée mise à jour aussi pour les poutres retirées.
- **Modélisation du niveau** (plan interactif inspiré d'Autodesk Robot) : axes avec bulles et cotes, poteaux, poutres, dalles. Outils : Sélection / Poteaux / Poutres / Dalles. Fiche de l'élément (position, section, portée, état, vérification de la poutre après calcul). Zoom, « Rétablir toutes les poutres », « Copier ce niveau vers tous ».
- **Poutres retirables une par une** (avant : poutres toujours automatiques entre deux poteaux). Une poutre retirée est prise en compte partout : descente de charges (poids propre), dimensionnement des poutres, vue 3D, plans, coffrage, élévation, compteurs.

## Limites (volontaires, à discuter)
- Axes toujours orthogonaux ; noms d'axes = lettres (X) et chiffres (Y) non modifiables.
- Section des poteaux = calculée (descente de charges) ; section des poutres et épaisseur de dalle = valeurs communes du bâtiment (pas encore par élément).
- Pas de porte-à-faux, de charges ponctuelles ni d'appuis spécifiques. Calculs indicatifs, à faire vérifier par un ingénieur.
- Retour en arrière : restaurer l'ancien `calcul-structure/index.html`.
