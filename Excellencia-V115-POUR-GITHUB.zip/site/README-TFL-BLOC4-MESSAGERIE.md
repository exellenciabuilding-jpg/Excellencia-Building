# TFL — bloc 4/5 : messagerie directe étudiant ↔ encadreur

**Étudiant** (Espace TFL › Échanges encadreur, ou bouton « Écrire à mon encadreur » sur le tableau de bord et sur la page Mon encadreur) : un fil de discussion privé avec son encadreur. Il écrit (2 000 caractères au plus), voit les réponses et, sur ses propres messages, la mention « ✓ lu ». Pastille sur le menu quand l'encadreur a répondu. Il faut un dossier **accepté** et un encadreur affecté ; dossier clos : le fil reste visible en lecture seule. Un message vide est refusé avant tout envoi.

**Encadreur** (Espace TFL › Messages) : la liste de ses étudiants avec le nombre de messages non lus ; un seul étudiant = conversation ouverte directement. Il ne voit que **ses** échanges : si un autre encadreur reprend le dossier, il ne lit pas l'historique de son prédécesseur (l'étudiant, lui, garde tout son fil). Un encadreur retiré d'un dossier ne peut plus y écrire.

**Actualisation :** le fil est lu à l'ouverture de la page et se met à jour tout seul toutes les 30 secondes tant que la page est ouverte (« 🔄 Actualiser » pour le faire à la main). L'actualisation ne touche pas au texte que vous êtes en train d'écrire. Il n'y a pas de notification hors du portail : les pastilles apparaissent à la connexion ou à l'actualisation du menu.

**Administration** (logiciel › TFL › dossier › 🗨️ Échanges étudiant ↔ encadreur) : « 📥 Charger les échanges du serveur » affiche le fil du dossier (auteur, date, lu / non lu) et permet de **supprimer** un message (litige, abus). Les étudiants et les encadreurs sont prévenus à l'écran que l'administration peut consulter le fil ; si vous ne voulez pas ce droit de regard, dites-le-moi et je retire la liste administrateur (la suppression resterait possible).

**Sécurité :** mot de passe vérifié à chaque appel (blocage après 5 essais) ; un étudiant ne voit que son dossier, un encadreur que ses échanges ; le texte est affiché sans interprétation HTML ; 60 messages par heure et par accès, 1 000 messages par fil. Aucune lecture directe de la table depuis le navigateur (RLS + droits retirés).

**À exécuter une fois :** `supabase/migration-tfl-bloc4-messagerie.sql` (prérequis : migration-v99zzt-tfl-portails.sql ; indépendant des blocs 1 à 3). Réexécutable. Contrôle : `select proname from pg_proc where proname like 'tfl_echange%';` → 4 lignes. Pour un téléphone, le script existe aussi en 2 morceaux (`bloc4-partie1-sur2.sql` puis `bloc4-partie2-sur2.sql`, dans cet ordre).

**Fichiers modifiés :** `tfl-portail.html`, `exb-tfl.js`, `sw.js`. Test : `node tools/test-tfl/test-bloc4.js` (38 contrôles, tous OK).
**Limites :** serveur simulé uniquement (SQL non exécuté sur un vrai Supabase) : essai à faire avec un étudiant et un encadreur fictifs, sur deux navigateurs. Pas de pièces jointes dans la messagerie (utiliser l'onglet Documents du bloc 3). Pas de suppression d'un message par son auteur (seule l'administration peut supprimer). Les anciens essais `test-portail.js` et `test-suivi.js` échouent déjà sur la version précédente (problème du banc de test, sans lien avec ce bloc).
