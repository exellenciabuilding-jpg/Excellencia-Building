# V99s — Calcul de structure intégré

Ajouts : `exb-calcul-structure.js`, `calcul-structure/index.html` (calculateur béton armé BAEL 91 / EC2 : bâtiment, poutre, poteau, dalle, semelle, escalier, dosage béton, mortier, volumes, coffrage, ferraillage, moment, coûts, agglos, devis DQE).
Modifiés : `index.html` (1 balise script), `exb-v99r-shell.js` (catégorie « Ingénierie & Structure » : 6 entrées), `sw.js` (cache `exb-v99s-calcul-structure-1`, 2 fichiers ajoutés).

- Menu : Ingénierie & Structure > Calcul de structure (tous les calculs), Bâtiment, Poutre continue, Semelle isolée, Escalier, Dosage béton.
- Le calculateur s'affiche dans un cadre ; ses calculs et ses données (clés xbp, xbh, xbd, xbb) sont indépendants du central (clés exb_*).
- Correction : le bouton « Effacer » du calculateur ne vide plus tout le stockage de l'appareil, seulement ses propres clés.
- Le nom de l'entreprise du central pré-remplit le cartouche des plans (sans écraser une saisie existante).
- Aucun SQL à exécuter. Retour en arrière : retirer la balise `exb-calcul-structure.js` de index.html.
- Limites : testé par `node tools/check.js` (242 contrôles) et un test navigateur du module ; rendu dans le menu complet et version téléphone à confirmer sur vos appareils. `calcul-structure/index.html` reste ouvrable directement, hors licence. Calculs indicatifs, à faire vérifier par un ingénieur.

- Prédimensionnement (nouveau module, menu Ingénierie & Structure) : à partir du panneau de dalle, des charges, du nombre de niveaux et du sol, propose l'épaisseur de dalle, la section de poutre et de poteau, et la semelle (règles de pouce, valeurs de départ à confirmer par les modules de calcul).
- Transferts : sous les résultats du prédimensionnement, boutons Dalle / Poutre / Poteau / Semelle / Tout envoyer (reprennent portées, sections, charges en pied, sol, fc, fe).
- Norme de calcul : sélecteur en haut de l'écran (BAEL 91 mod. 99, NF EN 1992-1-1 annexe française, EN 1992-1-1, BS EN 1992-1-1). Les autres normes restent « bientôt » (non calculées).
