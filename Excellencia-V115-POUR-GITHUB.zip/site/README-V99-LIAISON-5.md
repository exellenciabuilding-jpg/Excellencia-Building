# V99 — Liaison, tranche 5 (complément des tranches 3 et 4)

Fichier : `exb-liaison-ops.js` (chargé après `exb-liaison-4.js`, mis en cache hors ligne). Aucun SQL. On ajoute, on ne supprime rien, on ne devine pas un lien ambigu.

Les tranches 3 et 4 couvrent déjà : sélecteur de chantier dans Stock et Caisse, métrés ↔ client/chantier, présences/notes/TP-TD ↔ formation, V93 ↔ projets, dossier chantier (plans, BIM, notes de calcul), fusion des clients en double. Cette tranche ne les refait pas ; elle ajoute seulement ce qui manquait :

| Ajout | Où |
|---|---|
| Affectations du personnel aux chantiers (période, rôle ; alerte si chevauchement, congé/suspendu/sorti, ou session de formation le même jour). Rangées dans la fiche personnel (`assignments`), donc sauvegardées et synchronisées avec elle | RH |
| Matériaux consommés par chantier (lecture de `project_id` posé par la tranche 3) + rattachement des anciennes sorties sans chantier | Stock |
| Même nom, clients différents : choisir le bon client **par document** (projet, devis, étude, facture) sans fusionner | Clients |
| Suivi par participant : présence, moyenne sur 20, cotations ; alerte « certificat délivré sans présence / sans note » | Participants |
| Suggestions de clients dans l'en-tête du Métré | Métré |

Tests : 23 contrôles navigateur (`/tmp` de livraison) + `node tools/check.js` (477 contrôles, 0 échec).
Limites : non testé sur téléphone, avec Supabase réel, ni par un build GitHub.
