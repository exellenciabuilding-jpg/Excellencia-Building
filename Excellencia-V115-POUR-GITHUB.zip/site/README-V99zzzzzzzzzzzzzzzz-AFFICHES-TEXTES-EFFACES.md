# V99zzzzzzzzzzzzzzzz — Affiches : textes effacés de l'image, seuls vos textes s'affichent

Reprend la version « Devis cachet / lots / encadreur / matricule / QCM » (V99zzzzzzzzzzzzzzz). **Aucun SQL.**

## Ce qui change (Affiches › affiche générale et affiche « logiciels »)
- Dans les deux images de fond, **tous les textes ont été effacés** (retouche image). Il ne reste que le décor : photos, icônes, rubans, logo, filets.
- Les textes modifiables s'affichent **directement à l'emplacement exact des anciens**, **sans cadre de couleur** (avant, des cases de couleur masquaient le texte de l'image et laissaient parfois apparaître l'ancien texte en double).
- **Affiche logiciels** : 4 nouveaux champs pour les textes qui étaient figés dans l'image : bandeau « SESSION DE FORMATION », titre du bloc « FRAIS DE PARTICIPATION », adresse du pied de page et phrase du bas.
- Un texte plus long que l'original **réduit automatiquement sa taille** pour rester dans sa zone (fichier `exb-affiches.js`).
- Corrections au passage : le slogan de l'affiche générale n'ajoute plus de tirets (les filets sont dans l'image) ; sur l'affiche logiciels, les chiffres 1 à 4 de la structure ne sont plus doublés (ils sont dans l'image) ; « & » du titre en bleu clair ; « Excellencia Building » en gras dans la description ; « DURÉE » et « LIEU » en gras.

## Ce qui reste dans l'image (non modifiable)
Le logo avec sa phrase « L'excellence au cœur de vos constructions » et la ligne « CONSTRUCTION • ARCHITECTURE • ÉTUDES & CONCEPTION » **en haut de l'affiche logiciels** (c'est le bloc logo), les logos AutoCAD / SketchUp / ArchiCAD, les écrans des logiciels, les icônes et les photos. Dites-moi si vous voulez aussi rendre ce bloc modifiable.

## À savoir
- Si vous aviez **téléversé votre propre image de fond** pour l'affiche générale, elle est conservée : les textes s'affichent dessus **sans cache**. Utilisez une image sans texte, ou « Image de fond par défaut » pour revenir au nouveau fond.
- Les écritures manuscrites utilisent la police « Caveat » si l'appareil l'a, sinon une écriture cursive de l'appareil : la forme change légèrement d'un téléphone à l'autre (taille ajustée automatiquement). L'export PNG/PDF garde le rendu de l'appareil qui exporte.
- Le texte a été effacé par retouche : de très petits défauts de grain peuvent se voir en zoom fort sur le fond (ciel, ruban) ; invisibles à l'écran et à l'impression normale.
- Les traits bleus sous la citation et sous « Ensemble, construisons vos rêves ! » sont maintenant dessinés par le logiciel (ils faisaient partie de l'image).

## Contrôles
`node tools/check.js` (428 réussis ; 5 anciens contrôles de noms de cache échouaient déjà dans la version reçue et n'ont pas été touchés) · `python3 tools/e2e-affiches.py` (navigateur, 9).
