/* Excellencia Building — Enterprise Architecture Shell V90
 * Presents the target architecture while preserving V81/V90 runtime modules.
 */
(function(w,d){'use strict';
const groups=[
 {id:'core',icon:'⚙️',name:'Core',desc:'Socle transversal : identité, droits, organisation, notifications, audit et synchronisation.',items:[['auth','Authentification','administration'],['permissions','Permissions','administration'],['organisation','Organisation','enterprise360'],['notifications','Notifications','enterprise360'],['audit','Audit','administration'],['sync','Synchronisation','enterprise360']]},
 {id:'erp',icon:'🏢',name:'ERP',desc:'Gestion commerciale, financière, achats, stocks, RH et comptabilité.',items:[['crm','CRM','crmBtp'],['finance','Finance','comptabilite'],['achats','Achats','procurement'],['stocks','Stocks','stock'],['rh','RH','rh'],['comptabilite','Comptabilité','comptabilite']]},
 {id:'btp',icon:'🏗️',name:'BTP',desc:'Pilotage des projets et opérations de chantier.',items:[['projets','Projets','projets'],['chantiers','Chantiers','projet360'],['planning','Planning','planningBudget'],['qhse','QHSE','qhse'],['materiel','Matériel','parcMateriel'],['sous-traitance','Sous-traitance','subcontracting']]},
 {id:'architecture',icon:'📐',name:'ARCHITECTURE',desc:'Bureau d’études, plans, BIM et environnement documentaire commun.',items:[['etudes','Études','etudesTechniques'],['plans','Plans','plansVersions'],['bim','BIM','plansVersions'],['cde','CDE','cdeWorkflow']]},
 {id:'formation',icon:'🎓',name:'FORMATION',desc:'Parcours apprenant, formations et certifications.',items:[['apprenants','Apprenants','participants'],['formations','Formations','formation'],['certifications','Certifications','resultats']]},
 {id:'ai',icon:'🤖',name:'AI',desc:'Assistant, prévisions, analyse et reporting intelligent.',items:[['copilot','Copilot','enterprise360'],['previsions','Prévisions','direction'],['analyse','Analyse','direction'],['reporting','Reporting','direction']]}
];
function esc(v){return String(v??'').replace(/[&<>"]/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[s]));}
function openModule(id){
 const target=d.getElementById(id); if(target && typeof w.show==='function'){w.show(id);return true;}
 const by=(w.EXB_MODULES||[]).find(m=>m.id===id); if(by){const el=d.getElementById(id); if(el&&typeof w.show==='function'){w.show(id);return true;}}
 return false;
}
function render(){
 const root=d.getElementById('exbEnterpriseArchitecture'); if(!root)return;
 root.innerHTML=`<div class="exb-enterprise-banner"><div><strong>EXCELLENCIA BUILDING — ENTERPRISE</strong><span>Architecture V93 · socle unifié BTP / Architecture / Formation / ERP / IA</span></div><span class="exb-enterprise-badge">V93 Enterprise</span></div>`+
 '<div class="exb-enterprise-grid">'+groups.map(g=>`<article class="exb-enterprise-group"><div class="exb-enterprise-title"><span>${g.icon}</span><div><h3>${esc(g.name)}</h3><p>${esc(g.desc)}</p></div></div><div class="exb-enterprise-items">${g.items.map(it=>`<button class="exb-enterprise-item" data-target="${esc(it[2])}"><span>${esc(it[1])}</span><small>Ouvrir</small></button>`).join('')}</div></article>`).join('')+'</div>'+
 '<div class="exb-enterprise-flow"><strong>Flux intégré :</strong> CRM → Projet → Études → Plans/BIM/CDE → DQE/Devis → Contrat → Budget → Achats/Stocks/Sous-traitance → Chantier → QHSE/Planning → Situations/Factures → Finance/Comptabilité → IA/Reporting</div>';
 root.querySelectorAll('[data-target]').forEach(b=>b.addEventListener('click',()=>openModule(b.dataset.target)));
}
function inject(){
 const host=d.getElementById('enterprise360'); if(!host)return;
 if(!d.getElementById('exbEnterpriseArchitecture')){const h=d.createElement('div');h.id='exbEnterpriseArchitecture';host.querySelector('.card')?.insertBefore(h,host.querySelector('#exb90_root'));}
 render();
}
w.EXB_ENTERPRISE_SHELL={version:'V92-Enterprise',groups,refresh:render};
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',()=>setTimeout(inject,0));else setTimeout(inject,0);
})(window,document);
