/* Excellencia Building V95 — Formation Enterprise workflow */
(function(w){'use strict';
const KEY='exb_formation_workflow_v95';
function read(){try{return JSON.parse((w.exbStorage&&w.exbStorage.getItem(KEY))||localStorage.getItem(KEY)||'[]')}catch(e){return[]}}
function write(v){try{const x=JSON.stringify(v);if(w.exbStorage)w.exbStorage.setItem(KEY,x);else localStorage.setItem(KEY,x);return true}catch(e){return false}}
function uid(){return 'FW-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7).toUpperCase()}
const STAGES=['learner','enrolment','attendance','evaluation','certificate','payment','reporting'];
function upsert(data){const a=read(), id=data.id||uid(), old=a.find(x=>x.id===id)||{};const row=Object.assign({},old,data,{id,updated_at:new Date().toISOString()});if(!row.created_at)row.created_at=row.updated_at;const i=a.findIndex(x=>x.id===id);if(i<0)a.unshift(row);else a[i]=row;write(a);return row}
function get(id){return read().find(x=>x.id===id)||null}
function advance(id,stage,meta){if(STAGES.indexOf(stage)<0)throw new Error('Étape de formation inconnue');const row=get(id)||{id};row.stage=stage;row.meta=Object.assign({},row.meta||{},meta||{});row.timeline=Array.isArray(row.timeline)?row.timeline:[];row.timeline.push({stage,at:new Date().toISOString()});return upsert(row)}
function certify(id,cert){return advance(id,'certificate',{certificate:Object.assign({},cert||{}, {status:'VALIDATION_HUMAINE_REQUISE'})})}
function summary(){const a=read();return {total:a.length,byStage:STAGES.reduce((o,s)=>(o[s]=a.filter(x=>x.stage===s).length,o),{})}}
w.EXB_FORMATION_V95={version:'V95-Enterprise',stages:STAGES,read,upsert,get,advance,certify,summary};
})(window);
