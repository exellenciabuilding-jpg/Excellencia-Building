/* Excellencia Building — PDF professionnel de la copie d'un apprenant (feuille vierge ou copie rendue).
   Même charte que les autres documents du système : bandeau marine, filet doré, tableau d'informations, pied de page + pagination.
   Sans bibliothèque externe, multi-pages, fonctionne hors connexion.
   EXBCopie.build({mode:'blank'|'filled', titre, sousTitre, rows:[[libellé,valeur]], instructions, resultat:{got,tot,pc}|null,
                   items:[{n,pts,text,qcm,opts:[{l,t,good,pick}],answer,ok,ex}], note, pied}) -> Promise<Blob>
   EXBCopie.save(blob, nom) */
window.EXBCopie=(function(){
  'use strict';
  var W=595,H=842,M=44;
  var WIN={8217:146,8216:145,8220:147,8221:148,8211:150,8212:151,8364:128,339:156,338:140,8230:133,8226:149,160:32};
  /* largeurs Helvetica (1/1000 em) ASCII 32..126 */
  var HR=[278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
  var HB=[278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
  var FOLD={'à':'a','á':'a','â':'a','ä':'a','ã':'a','å':'a','ç':'c','è':'e','é':'e','ê':'e','ë':'e','ì':'i','í':'i','î':'i','ï':'i','ñ':'n','ò':'o','ó':'o','ô':'o','ö':'o','õ':'o','ù':'u','ú':'u','û':'u','ü':'u','ÿ':'y','À':'A','Á':'A','Â':'A','Ä':'A','Ç':'C','È':'E','É':'E','Ê':'E','Ë':'E','Î':'I','Ï':'I','Ô':'O','Ö':'O','Ù':'U','Û':'U','Ü':'U'};
  function cw(ch,b){var c=ch.charCodeAt(0);if(FOLD[ch])c=FOLD[ch].charCodeAt(0);if(c>=32&&c<=126)return (b?HB:HR)[c-32];if(c===8217||c===8216||c===8221||c===8220)return 278;if(c===8211)return 556;if(c===8212)return 1000;if(c===339)return 944;return 556}
  function tw(t,sz,b){var w=0;for(var i=0;i<t.length;i++)w+=cw(t[i],b);return w*sz/1000}
  function clean(t){t=String(t==null?'':t).replace(/\r/g,'').replace(/\t/g,'    ').replace(/[→➡]/g,'->').replace(/[✓✔]/g,'v').replace(/[✗✘]/g,'x').replace(/[‘’]/g,'’');var o='';for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);if(c===10){o+='\n';continue}if(c>255&&!WIN[c])continue;if(c<32)continue;o+=t[i]}return o}
  function pe(t){var o='';for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);if(WIN[c])c=WIN[c];else if(c>255)c=63;
    if(c===40||c===41||c===92)o+='\\'+String.fromCharCode(c);else if(c<32)o+=' ';else if(c>126)o+='\\'+('00'+c.toString(8)).slice(-3);else o+=String.fromCharCode(c)}return o}
  function wrap(text,maxW,sz,b){
    var out=[];clean(text).split('\n').forEach(function(par){
      if(!par.trim()){out.push('');return}
      var l='',words=par.split(/ +/);
      words.forEach(function(x){
        while(tw(x,sz,b)>maxW){ /* mot trop long : coupe */
          if(l){out.push(l);l=''}
          var k=x.length;while(k>1&&tw(x.slice(0,k),sz,b)>maxW)k--;out.push(x.slice(0,k));x=x.slice(k)}
        if(!x)return;var t=l?l+' '+x:x;if(tw(t,sz,b)<=maxW)l=t;else{out.push(l);l=x}});
      out.push(l)});
    while(out.length>1&&out[out.length-1]==='')out.pop();return out}
  function bytes(s){var u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i)&255;return u}
  function jpg(src,maxW,q){return new Promise(function(ok,ko){var im=new Image();if(/^https?:/i.test(src))im.crossOrigin='anonymous';im.onload=function(){try{
    var r=Math.min(maxW/im.naturalWidth,1),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.naturalWidth*r));c.height=Math.max(1,Math.round(im.naturalHeight*r));
    var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
    var d=c.toDataURL('image/jpeg',q||.9),b=atob(d.split(',')[1]),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);ok({u:u,w:c.width,h:c.height})}catch(e){ko(e)}};
    im.onerror=function(){ko(new Error('image'))};im.src=src})}
  function hex(h,def){var m=/^#?([0-9a-f]{6})$/i.exec(String(h||''));if(!m)return def;var n=parseInt(m[1],16);return ((n>>16)/255).toFixed(3)+' '+(((n>>8)&255)/255).toFixed(3)+' '+((n&255)/255).toFixed(3)}

  async function build(o){
    var B=window.EXB_BRAND||{},BR=String(B.name||'Excellencia Building');
    var NAVY=hex(B.primary,'0.09 0.21 0.40'),GOLD=hex(B.accent,'0.79 0.64 0.15'),GREY='0.40 0.43 0.49',LINE='0.84 0.87 0.92',SOFT='0.95 0.97 0.99',INK='0.10 0.12 0.18';
    var GOK='0.91 0.97 0.93',GOKB='0.01 0.48 0.28',GKO='0.996 0.90 0.89',GKOB='0.71 0.14 0.09',GKT='0.995 0.975 0.90';
    var IM=[],logo=-1;
    try{IM.push(await jpg(B.logo||'icon-192.png',192,.9));logo=0}catch(e){try{IM.push(await jpg('icon-192.png',192,.9));logo=0}catch(e2){}}
    var pages=[],ops,used,y,BOT=64;
    function T(t,x,yy,sz,b,rgb){ops.push((rgb||INK)+' rg BT /'+(b?'F2':'F1')+' '+sz+' Tf '+x.toFixed(1)+' '+yy.toFixed(1)+' Td ('+pe(clean(t))+') Tj ET')}
    function TR(t,xr,yy,sz,b,rgb){T(t,xr-tw(clean(t),sz,b),yy,sz,b,rgb)}
    function R(x,yy,w,h,rgb){ops.push(rgb+' rg '+x.toFixed(1)+' '+yy.toFixed(1)+' '+w.toFixed(1)+' '+h.toFixed(1)+' re f')}
    function RS(x,yy,w,h,rgb,lw){ops.push(rgb+' RG '+(lw||.6)+' w '+x.toFixed(1)+' '+yy.toFixed(1)+' '+w.toFixed(1)+' '+h.toFixed(1)+' re S')}
    function LN(x1,y1,x2,y2,rgb,lw){ops.push(rgb+' RG '+(lw||.6)+' w '+x1.toFixed(1)+' '+y1.toFixed(1)+' m '+x2.toFixed(1)+' '+y2.toFixed(1)+' l S')}
    function D(k,x,yy,w,h){used[k]=1;ops.push('q '+w.toFixed(1)+' 0 0 '+h.toFixed(1)+' '+x.toFixed(1)+' '+yy.toFixed(1)+' cm /I'+k+' Do Q')}
    function logoBox(x,yy,box){R(x,yy,box,box,'1 1 1');if(logo>=0){var m=IM[logo],w=box-8,h=w*m.h/m.w;if(h>box-8){h=box-8;w=h*m.w/m.h}D(logo,x+(box-w)/2,yy+(box-h)/2,w,h)}}
    function np(){
      ops=[];used={};pages.push({ops:ops,used:used});var first=pages.length===1;
      if(first){
        R(0,H-110,W,110,NAVY);R(0,H-114,W,4,GOLD);logoBox(M,H-98,84);var tx=M+102;
        var bs=Math.max(13,Math.min(25,Math.floor(400/(BR.length*0.66))));
        T(BR.toUpperCase(),tx,H-50,bs,true,'1 1 1');
        var tt=clean(o.titre||'');while(tt.length>3&&tw(tt,12.5,true)>W-tx-M)tt=tt.slice(0,-2);if(tt!==clean(o.titre||''))tt+='…';
        T(tt,tx,H-76,12.5,true,'0.95 0.82 0.40');
        if(o.sousTitre){var st=clean(o.sousTitre);while(st.length>3&&tw(st,9.5,false)>W-tx-M)st=st.slice(0,-2);T(st,tx,H-95,9.5,false,'0.80 0.86 0.95')}
        y=H-114-28}
      else{R(0,H-50,W,50,NAVY);R(0,H-53,W,3,GOLD);logoBox(M,H-44,38);T(BR.toUpperCase().slice(0,42),M+52,H-28,13,true,'1 1 1');
        var s2=clean(o.titre||'');while(s2.length>3&&tw(s2,8.5,false)>W-M-52-M)s2=s2.slice(0,-2);T(s2,M+52,H-42,8.5,false,'0.95 0.82 0.40');y=H-53-26}
    }
    function need(h){if(y-h<BOT)np()}
    function section(title){need(40);T(title.toUpperCase(),M,y,10,true,NAVY);var w=tw(title.toUpperCase(),10,true);R(M+w+8,y+3,W-2*M-w-8,1.2,GOLD);y-=18}
    np();

    /* ---- informations ---- */
    section('Informations');
    var LW=150,VX=M+LW+12,VW=W-M-VX-8,k=0;
    (o.rows||[]).forEach(function(r){
      var L=wrap(r[1]==null||r[1]===''?'':r[1],VW,11,false),empty=!String(r[1]==null?'':r[1]).trim(),rh=Math.max(empty?34:30,L.length*15+14);
      need(rh+2);
      R(M,y-rh,W-2*M,rh,k%2?'0.985 0.99 1':'1 1 1');R(M,y-rh,LW,rh,SOFT);RS(M,y-rh,W-2*M,rh,LINE);LN(M+LW,y-rh,M+LW,y,LINE);
      var lb=wrap(String(r[0]||'').toUpperCase(),LW-18,8.5,true);T(lb[0],M+10,y-rh/2-3+(lb.length>1?5:0),8.5,true,NAVY);if(lb[1])T(lb[1],M+10,y-rh/2-8,8.5,true,NAVY);
      if(empty)LN(VX,y-rh+9,W-M-10,y-rh+9,'0.55 0.60 0.68',.7);else L.forEach(function(line,j){T(line,VX,y-19-j*15,11,false)});
      y-=rh;k++});
    y-=16;

    /* ---- encadré avec barre dorée, découpé proprement entre les pages ---- */
    function callout(title,lines,fill,bar,tcolor,sz,leading,txtRgb){
      var x=M,w=W-2*M,pad=14,i=0,first=true;
      while(i<lines.length||first){
        var head=first?22:8;need(head+leading*2+pad);
        var avail=Math.floor((y-BOT-head-pad+6)/leading),take=Math.max(1,Math.min(lines.length-i,avail)),h=head+take*leading+pad-6;
        R(x,y-h,w,h,fill);R(x,y-h,4,h,bar);
        if(first&&title)T(title,x+16,y-17,9.5,true,tcolor);
        for(var j=0;j<take;j++)T(lines[i+j],x+16,y-head-12-j*leading+(first?0:4),sz,false,txtRgb||'0.22 0.22 0.22');
        i+=take;y-=h+6;first=false;if(i>=lines.length)break}
      y-=14}

    if(o.instructions){callout('CONSIGNES',wrap(o.instructions,W-2*M-32,10,false),GKT,GOLD,'0.55 0.40 0.03',10,13.5)}

    /* ---- résultat QCM ---- */
    if(o.resultat){
      need(78);var r=o.resultat,bw=W-2*M,h=62;
      R(M,y-h,bw,h,SOFT);RS(M,y-h,bw,h,LINE);R(M,y-h,4,h,NAVY);
      T('RÉSULTAT DU QCM',M+16,y-18,9.5,true,NAVY);T(r.got+' / '+r.tot+'  points',M+16,y-42,19,true,INK);
      TR(r.pc+' %',W-M-14,y-42,19,true,r.pc>=50?GOKB:GKOB);
      var px=M+210,pw=bw-210-84;R(px,y-40,pw,8,'0.88 0.91 0.95');R(px,y-40,Math.max(0,pw*Math.min(100,r.pc)/100),8,r.pc>=50?GOKB:GKOB);
      y-=h+18}

    /* ---- questions ---- */
    var items=o.items||[];
    if(items.length){section(o.mode==='filled'?'Copie de l’apprenant':'Questions')}
    items.forEach(function(it){
      var tx=M+30,tW=W-M-tx,lead=14.5,lines=wrap(it.text||'',tW,10.5,false);
      need(70);
      /* en-tête de la question */
      R(M,y-18,22,22,NAVY);var ns=String(it.n),nsz=ns.length>2?8.5:11;T(ns,M+11-tw(ns,nsz,true)/2,y-11.5,nsz,true,'1 1 1');
      T('QUESTION '+it.n,tx,y-8,10,true,NAVY);
      if(it.pts&&it.pts!==1)TR(it.pts+' pts',W-M,y-8,8.5,false,GREY);else if(it.qcm)TR('1 pt',W-M,y-8,8.5,false,GREY);
      if(o.mode==='filled'&&it.qcm&&it.ok!==undefined){var st=it.ok?'BONNE RÉPONSE':'MAUVAISE RÉPONSE';TR(st,W-M-((it.pts?String(it.pts+(it.pts>1?' pts':' pt')).length:4)*5+14),y-8,8,true,it.ok?GOKB:GKOB)}
      y-=30;
      /* énoncé */
      lines.forEach(function(l){need(lead+2);if(l)T(l,tx,y,10.5,false);y-=lead});
      y-=4;
      if(it.qcm){
        (it.opts||[]).forEach(function(op){
          var ow=tW-34-(o.mode==='filled'?96:0),ol=wrap(op.t||'',ow,10,false),rh=Math.max(24,ol.length*13+11);need(rh+4);
          var fill='1 1 1',bd=LINE;
          if(o.mode==='filled'){if(op.good){fill=GOK;bd=GOKB}else if(op.pick){fill=GKO;bd=GKOB}}
          R(tx,y-rh,tW,rh,fill);RS(tx,y-rh,tW,rh,bd,op.good||op.pick&&o.mode==='filled'?1:.6);
          var bx=tx+9,by=y-rh/2-5.5;RS(bx,by,11,11,o.mode==='filled'&&(op.pick||op.good)?(op.good?GOKB:GKOB):'0.45 0.50 0.58',1);
          if(o.mode==='filled'&&op.pick){R(bx+2.5,by+2.5,6,6,op.good?GOKB:GKOB)}
          T(op.l+'.',tx+27,y-rh/2-3.5,10,true,NAVY);
          ol.forEach(function(l,j){T(l,tx+43,y-rh/2-3.5+(ol.length-1)*6.5-j*13,10,false)});
          if(o.mode==='filled'){var tag=op.good?(op.pick?'Votre réponse · correcte':'Bonne réponse'):(op.pick?'Votre choix':'');if(tag)TR(tag,tx+tW-8,y-rh/2-3,7.5,true,op.good?GOKB:GKOB)}
          y-=rh+3});
        if(o.mode==='filled'&&it.ex){y-=12;wrap('Explication : '+it.ex,tW-14,9,false).forEach(function(l,j){need(13);R(tx,y-3,2.5,12,GOLD);T(l,tx+10,y,9,false,GREY);y-=12})}
      }else if(o.mode==='filled'){
        var al=wrap(it.answer||'',tW-24,10.5,false),empty=!String(it.answer||'').trim();if(empty)al=['— Aucune réponse —'];
        need(36);T('RÉPONSE DE L’APPRENANT',tx,y,7.5,true,GREY);y-=8;
        var i=0;while(i<al.length){var avail=Math.floor((y-BOT-10)/lead);if(avail<2){np();avail=Math.floor((y-BOT-10)/lead)}
          var take=Math.min(al.length-i,avail),h=take*lead+14;R(tx,y-h,tW,h,SOFT);R(tx,y-h,3,h,GOLD);
          for(var j=0;j<take;j++){if(al[i+j])T(al[i+j],tx+14,y-16-j*lead,10.5,false,empty?GREY:INK)}
          y-=h;i+=take}
      }else{
        var nl=Math.max(4,Math.min(10,it.lines||5));
        for(var q=0;q<nl;q++){need(26);LN(tx,y-18,W-M,y-18,'0.62 0.66 0.72',.6);y-=26}
      }
      y-=8;need(8);LN(M,y,W-M,y,LINE,.6);y-=18});

    /* ---- grille de cartes QR (une carte par apprenant) ---- */
    if(o.cards&&o.cards.length){
      section(o.cardsTitre||'Apprenants');
      var gw=(W-2*M-14)/2,gh=122,col=0;
      o.cards.forEach(function(cd){
        if(col===0)need(gh+10);
        var gx=M+col*(gw+14),gy=y-gh;
        R(gx,gy,gw,gh,'1 1 1');RS(gx,gy,gw,gh,LINE,.8);R(gx,gy,gw,3,GOLD);
        try{ops.push(window.EXBVerif.qrOps(cd.url,gx+8,gy+14,98))}catch(e){}
        var tx2=gx+114,tw2=gw-122,nl=wrap(cd.name||'Apprenant',tw2,10.5,true).slice(0,2),ty=gy+gh-22;
        nl.forEach(function(l){T(l,tx2,ty,10.5,true,NAVY);ty-=13});
        T('Matricule',tx2,ty-4,7.5,false,GREY);T(cd.mat||'',tx2,ty-15,10,true,INK);ty-=30;
        if(cd.sub){wrap(cd.sub,tw2,8.5,false).slice(0,2).forEach(function(l){T(l,tx2,ty,8.5,false,GREY);ty-=11})}
        T('Scannez pour ouvrir l’épreuve',tx2,gy+10,7.5,false,GREY);
        col++;if(col===2){col=0;y-=gh+10}});
      if(col===1)y-=gh+10}
    if(o.note){callout('REMARQUE',wrap(o.note,W-2*M-32,9.5,false),GKT,GOLD,'0.55 0.40 0.03',9.5,12.5)}
    if(o.mode!=='filled'&&items.length){need(120);y-=6;var cwd=(W-2*M-30)/2;
      T('SIGNATURE DE L’APPRENANT',M,y,8,true,NAVY);T('VISA DU FORMATEUR / NOTE',M+cwd+30,y,8,true,NAVY);RS(M,y-90,cwd,82,LINE);RS(M+cwd+30,y-90,cwd,82,LINE);y-=110}

    /* ---- QR de vérification (dernière page, en bas, comme les autres documents) ---- */
    var VQ=o.verify&&o.verify.url&&window.EXBVerif&&window.EXBQR?o.verify:null;
    if(VQ){if(y<150)np()}
    /* ---- pieds de page ---- */
    var N=pages.length,today=new Date().toLocaleDateString('fr-FR');
    pages.forEach(function(p,i){var save=ops;ops=p.ops;used=p.used;
      R(0,0,W,6,NAVY);LN(M,52,W-M,52,LINE,.8);
      var ct=[B.phone,B.email].filter(Boolean).join(' — ');
      if(VQ&&i===N-1){try{var qs=62,qx=W-M-qs,qy=60,bx=M,bw=W-2*M;
        R(bx,qy-4,bw,qs+8,SOFT);RS(bx,qy-4,bw,qs+8,LINE);R(bx,qy-4,4,qs+8,GOLD);
        ops.push(window.EXBVerif.qrOps(VQ.url,qx-4,qy,qs));
        T('VÉRIFICATION DE LA COPIE',bx+16,qy+qs-14,9.5,true,NAVY);
        T('Scannez le QR pour vérifier l’authenticité de cette copie.',bx+16,qy+qs-29,8.5,false,GREY);
        T('N° '+VQ.no+'   ·   Code '+String(VQ.hash).toUpperCase(),bx+16,qy+qs-43,8,true,NAVY);
        if(VQ.emp)T('Empreinte des réponses : '+String(VQ.emp).toUpperCase(),bx+16,qy+qs-55,8,false,GREY)}catch(e){}}
      T(clean((o.pied||BR)+(ct?' — '+ct:'')).slice(0,92),M,36,8.5,false,GREY);
      T('Document généré le '+today,M,24,7.5,false,GREY);
      var pt='Page '+(i+1)+' / '+N;TR(pt,W-M,36,8.5,true,NAVY);ops=save});

    /* ---- assemblage PDF ---- */
    var ch=[],pos=0,off=[],cnt=4+IM.length+2*N;
    function Pw(x){var u=typeof x==='string'?bytes(x):x;ch.push(u);pos+=u.length}
    function O(n,head,stream){off[n]=pos;Pw(n+' 0 obj\n'+head);if(stream){Pw('\nstream\n');Pw(stream);Pw('\nendstream')}Pw('\nendobj\n')}
    Pw('%PDF-1.4\n');
    O(1,'<< /Type /Catalog /Pages 2 0 R >>');
    var kids=[],pb=5+IM.length;pages.forEach(function(p,i){kids.push((pb+2*i)+' 0 R')});
    O(2,'<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+N+' >>');
    O(3,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    O(4,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    IM.forEach(function(m,i){O(5+i,'<< /Type /XObject /Subtype /Image /Width '+m.w+' /Height '+m.h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+m.u.length+' >>',m.u)});
    pages.forEach(function(p,i){var n=pb+2*i,xo=Object.keys(p.used).map(function(kk){return '/I'+kk+' '+(5+Number(kk))+' 0 R'}).join(' '),c=bytes(p.ops.join('\n'));
      O(n,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << '+xo+' >> >> /Contents '+(n+1)+' 0 R >>');
      O(n+1,'<< /Length '+c.length+' >>',c)});
    var xr=pos,x='xref\n0 '+(cnt+1)+'\n0000000000 65535 f \n';for(var j=1;j<=cnt;j++)x+=('0000000000'+off[j]).slice(-10)+' 00000 n \n';
    Pw(x+'trailer\n<< /Size '+(cnt+1)+' /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF');
    return new Blob(ch,{type:'application/pdf'})
  }
  function save(blob,name){var u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},4000)}
  return {build:build,save:save}
})();
