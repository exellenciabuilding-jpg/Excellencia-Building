# V99m — Vérification unifiée des documents (QR)

Devis, factures, reçus de devis, **certificats**, **reçus de paiement des apprenants** et **fiches d'inscription** portent maintenant le même type de QR : `#verify=type~numéro~date~montant~devise~code`.
Le scan ouvre « Vérification de document » (sans connexion) et affiche les repères enregistrés au registre : type, numéro, nom, matricule, formation/objet, date, montant, statut, code.

- Verdicts : ✅ authentique · ⚠️ ancienne version remplacée (affiche la version en vigueur) · ⚠️ ANNULÉ · ⚠️ non reconnu.
- Un devis regénéré sous le même numéro n'est plus « modifié ou erroné » : l'ancienne version est reconnue comme remplacée et la version en vigueur est montrée.
- Recherche par **matricule** ou par **numéro** (champ en bas de la page de vérification, ou 🌐 Site vitrine › 5).
- Aucun contact (téléphone, e-mail, adresse) n'est stocké ni affiché.

## Mise en place
1. Supabase › SQL Editor : exécuter `supabase/migration-v99m-verification.sql` (après `migration-v99l-documents.sql`).
2. Déployer ce logiciel.
3. 🌐 Site vitrine › 5 › **📤 Publier les documents existants** (administrateur connecté). Ensuite chaque nouveau devis/reçu/certificat est publié automatiquement.
4. Anciens certificats/reçus déjà imprimés : leur ancien QR (texte) ne se vérifie pas ; régénérez le PDF pour obtenir le nouveau QR.

## Limites
- La fiche BTP/Architecture (PDF client) n'a pas encore de QR ; sa demande est enregistrée au registre.
- Les fiches d'inscription sont déclarées par le visiteur (« fiche reçue ») : elles prouvent la réception, pas une validation.
- Vérification en ligne : sans connexion, la page compare avec le registre de l'appareil de l'émetteur seulement.
