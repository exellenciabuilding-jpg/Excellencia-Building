/* Excellencia Building — Netteté et lisibilité des plans flous ou scannés (V99zzzzzzzzzzzzzzzzzzzz)
   Travaille sur un <canvas>, sans bibliothèque ni Internet :
   1. fond de page aplani (ombres, éclairage inégal d'une photo ou d'un scan) ;
   2. niveaux étirés (papier jauni ou gris -> blanc, traits -> noirs) ;
   3. masque flou (« unsharp mask ») pour redonner du mordant aux traits et aux chiffres ;
   Les couleurs (pièces teintées) sont conservées. */
(function(root){
'use strict';
function percentile(hist,total,p){var a=0,t=total*p;for(var i=0;i<256;i++){a+=hist[i];if(a>=t)return i}return 255}
/* fond estimé bloc par bloc (85e centile), lissé puis interpolé */
function fond(L,W,H){var bs=Math.max(12,Math.round(Math.min(W,H)/48)),gw=Math.ceil(W/bs),gh=Math.ceil(H/bs),G=new Float32Array(gw*gh);
 for(var by=0;by<gh;by++)for(var bx=0;bx<gw;bx++){var h=new Uint32Array(64),n=0,x1=Math.min(W,(bx+1)*bs),y1=Math.min(H,(by+1)*bs);
  for(var y=by*bs;y<y1;y+=2){var o=y*W;for(var x=bx*bs;x<x1;x+=2){h[L[o+x]>>2]++;n++}}
  var a=0,t=n*0.85,v=63;for(var i=0;i<64;i++){a+=h[i];if(a>=t){v=i;break}}G[by*gw+bx]=v*4+2}
 for(var it=0;it<2;it++){var G2=new Float32Array(G.length);for(var y=0;y<gh;y++)for(var x=0;x<gw;x++){var s=0,c=0;for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var yy=y+dy,xx=x+dx;if(yy>=0&&yy<gh&&xx>=0&&xx<gw){s+=G[yy*gw+xx];c++}}G2[y*gw+x]=s/c}G=G2}
 return{G:G,gw:gw,gh:gh,bs:bs}}
function fondAt(F,x,y){var fx=Math.min(F.gw-1,Math.max(0,x/F.bs-0.5)),fy=Math.min(F.gh-1,Math.max(0,y/F.bs-0.5)),x0=Math.floor(fx),y0=Math.floor(fy),x1=Math.min(F.gw-1,x0+1),y1=Math.min(F.gh-1,y0+1),tx=fx-x0,ty=fy-y0,G=F.G;
 return(G[y0*F.gw+x0]*(1-tx)+G[y0*F.gw+x1]*tx)*(1-ty)+(G[y1*F.gw+x0]*(1-tx)+G[y1*F.gw+x1]*tx)*ty}
/* flou rapide séparable (moyenne glissante) */
function flou(src,W,H,r){var tmp=new Float32Array(W*H),out=new Float32Array(W*H),k=2*r+1;
 for(var y=0;y<H;y++){var o=y*W,s=0;for(var x=-r;x<=r;x++)s+=src[o+Math.min(W-1,Math.max(0,x))];for(x=0;x<W;x++){tmp[o+x]=s/k;s+=src[o+Math.min(W-1,x+r+1)]-src[o+Math.max(0,x-r)]}}
 for(var x2=0;x2<W;x2++){var s2=0;for(var y2=-r;y2<=r;y2++)s2+=tmp[Math.min(H-1,Math.max(0,y2))*W+x2];for(y2=0;y2<H;y2++){out[y2*W+x2]=s2/k;s2+=tmp[Math.min(H-1,y2+r+1)*W+x2]-tmp[Math.max(0,y2-r)*W+x2]}}
 return out}
/* force : 0 (léger) .. 2 (fort). Renvoie un petit rapport. */
function ameliorer(cv,opt){opt=opt||{};var force=opt.force==null?1:opt.force,W=cv.width,H=cv.height,N=W*H,ctx=cv.getContext('2d'),im=ctx.getImageData(0,0,W,H),d=im.data,i;
 var L=new Uint8Array(N);for(i=0;i<N;i++){var p=i*4;L[i]=(d[p]*77+d[p+1]*150+d[p+2]*29)>>8}
 /* 1. fond aplani */
 var F=fond(L,W,H),L1=new Float32Array(N);
 for(var y=0;y<H;y++){var o=y*W;for(var x=0;x<W;x++){var b=fondAt(F,x,y),g=255/Math.max(60,b);L1[o+x]=Math.min(255,L[o+x]*g)}}
 /* 2. niveaux : noir = 0,5 % des pixels les plus sombres, blanc = 255 */
 var hist=new Uint32Array(256);for(i=0;i<N;i++)hist[L1[i]|0]++;
 var lo=percentile(hist,N,0.004),hi=Math.max(lo+40,Math.round(percentile(hist,N,0.5)*0.9)),mix=Math.min(1,0.55+0.25*force);
 for(i=0;i<N;i++){var t=(L1[i]-lo)/(hi-lo);t=t<0?0:t>1?1:t;L1[i]=255*(t+mix*(t*t*(3-2*t)-t))}
 /* 3. léger lissage du grain, puis masque flou */
 var r=Math.max(1,Math.round(Math.min(W,H)/1400)),S=flou(L1,W,H,1),B=flou(S,W,H,r+1),am=1.6+0.8*force,L3=new Float32Array(N);
 for(i=0;i<N;i++){var v=S[i]+am*(S[i]-B[i]);L3[i]=v<0?0:v>255?255:v>238?255:v}
 /* 4. on remet la couleur d'origine (rapport de luminance) */
 for(i=0;i<N;i++){var p2=i*4,l0=L[i]<1?1:L[i],k2=L3[i]/l0;
  if(L[i]<8){d[p2]=d[p2+1]=d[p2+2]=L3[i]}else{var rr=d[p2]*k2,gg=d[p2+1]*k2,bb=d[p2+2]*k2;d[p2]=rr>255?255:rr;d[p2+1]=gg>255?255:gg;d[p2+2]=bb>255?255:bb}}
 ctx.putImageData(im,0,0);return{noir:lo,blanc:hi,rayon:r,gain:am}}
/* netteté mesurée (variance du Laplacien, sur une copie réduite) : aide à décider « flou ou net » */
function flouMesure(cv){var s=Math.min(1,900/Math.max(cv.width,cv.height)),w=Math.max(8,Math.round(cv.width*s)),h=Math.max(8,Math.round(cv.height*s)),c=document.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');x.drawImage(cv,0,0,w,h);
 var d=x.getImageData(0,0,w,h).data,g=new Float32Array(w*h);for(var i=0;i<w*h;i++)g[i]=0.3*d[i*4]+0.59*d[i*4+1]+0.11*d[i*4+2];
 var sum=0,sq=0,n=0;for(var y=1;y<h-1;y++)for(var xx=1;xx<w-1;xx++){var q=4*g[y*w+xx]-g[y*w+xx-1]-g[y*w+xx+1]-g[(y-1)*w+xx]-g[(y+1)*w+xx];sum+=q;sq+=q*q;n++}
 var m=sum/n;return sq/n-m*m}
root.EXBNET={ameliorer:ameliorer,flouMesure:flouMesure};
})(typeof window!=='undefined'?window:globalThis);
