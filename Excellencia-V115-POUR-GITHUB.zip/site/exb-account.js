/* exb-account.js — Compte imposé par l'administrateur (porté par le code de licence signé).
 * MODE AUTO  (identifiant + mot de passe dans le lien) : connecté en permanence, sans écran de connexion ni déconnexion.
 * MODE CODE  (chantier : identifiant + code provisoire donné à part) : le client se connecte avec ce code,
 *            puis DOIT créer son propre mot de passe. Il ne peut utiliser que le compte attribué.
 * Dans les deux cas, changer de compte = nouveau lien émis par l'administrateur. */
(function () {
  'use strict';
  var A = null; try { A = JSON.parse(localStorage.getItem('EXB_ACCT_LOCK') || 'null'); } catch (e) {}
  if (!A || !A.id) return;
  var FIELD = !!window.EXB_FIELD_CONFIG, FIRST = !!A.first && !A.pw, AUTO = !!A.pw && !A.first;
  if (FIRST && !FIELD) return;                       /* le mode « code provisoire » concerne le logiciel chantier */
  window.EXB_ACCT = A; window.EXB_ACCT_ON = AUTO; window.EXB_ACCT_FIRST = FIRST;
  var NOTE = 'Ce compte est géré par l’administrateur. Pour le changer, contactez-le.';
  var st = document.createElement('style');
  st.textContent = 'body.exb-acct .logout,body.exb-acct #ol_out,body.exb-acct #ol_login,body.exb-acct #lgNew,body.exb-acct #lgEye,body.exb-acct #login .fld,body.exb-acct #login .row,body.exb-acct #login p.mut,body.exb-acct button[onclick="exbLogout()"],body.exb-acct button[onclick="changeCreds()"],body.exb-acct #credmsg{display:none!important}' +
    'body.exb-first #lgNew,body.exb-first #login .row{display:none!important}#exbPwUI{position:fixed;inset:0;z-index:99995;background:rgba(15,23,42,.7);display:flex;align-items:center;justify-content:center;padding:14px;font:15px system-ui,sans-serif;color:#172033}#exbPwUI .bx{background:#fff;border-radius:16px;padding:20px;width:100%;max-width:420px}#exbPwUI input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #cbd5e1;border-radius:10px;margin:6px 0;font:inherit}#exbPwUI button{width:100%;padding:13px;border:0;border-radius:12px;font:inherit;font-weight:700;margin-top:8px}';
  (document.head || document.documentElement).appendChild(st);

  function hideCreds() { ['new_user', 'new_pass'].forEach(function (i) { var e = document.getElementById(i); if (e) { var b = e.closest('.two') || e.parentElement; if (b) b.style.display = 'none'; } }); }
  function cloudLogin() {
    var sb = window.exbSb, c = window.EXB_SUPABASE || {};
    if (!AUTO || !sb || !c.url || !c.key || !navigator.onLine) return;
    try { if (sb.isIn()) return; } catch (e) { return; }
    fetch(c.url + '/auth/v1/token?grant_type=password', { method: 'POST', headers: { apikey: c.key, 'Content-Type': 'application/json' }, body: JSON.stringify({ email: A.id, password: A.pw }) })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (x) { if (x.ok && x.d.access_token) sb.set({ access_token: x.d.access_token, refresh_token: x.d.refresh_token, exp: Date.now() + (x.d.expires_in || 3600) * 1000 }); })
      .catch(function () {});
  }
  function keepSession() { try { if (typeof exbSessionStorage !== 'undefined' && document.getElementById('loginScreen')) exbSessionStorage.setItem('exb_logged', '1'); } catch (e) {} }

  /* création obligatoire du mot de passe (chantier, mode code) */
  window.exbForcePw = function (sb, user, code) {
    if (!FIRST) return Promise.resolve();
    if (user && user.user_metadata && user.user_metadata.pw_set) return Promise.resolve();
    try { localStorage.setItem('EXB_PW_PENDING', '1'); } catch (e) {}
    return new Promise(function (res, rej) {
      var d = document.createElement('div'); d.id = 'exbPwUI';
      d.innerHTML = '<div class="bx"><h2 style="margin:0 0 4px;color:#173565">Créez votre mot de passe</h2><p style="margin:0 0 8px;color:#64748b;font-size:13px">Pour votre sécurité, remplacez le code provisoire par un mot de passe personnel (8 caractères minimum).</p>' +
        '<input id="npw1" type="password" autocomplete="new-password" placeholder="Nouveau mot de passe"><input id="npw2" type="password" autocomplete="new-password" placeholder="Confirmer le mot de passe">' +
        '<div id="npwm" style="color:#b91c1c;font-size:13px;min-height:18px"></div><button id="npwg" style="background:#0f4aa8;color:#fff">Enregistrer et continuer</button><button id="npwc" style="background:#eef2f7;color:#173565">Annuler</button></div>';
      document.body.appendChild(d);
      var $ = function (i) { return d.querySelector('#' + i); };
      $('npwc').onclick = function () { d.remove(); rej(new Error('Vous devez créer votre mot de passe pour continuer.')); try { sb.auth.signOut(); } catch (e) {} };
      $('npwg').onclick = async function () {
        var a = $('npw1').value, b = $('npw2').value, m = $('npwm');
        if (a.length < 8) { m.textContent = '8 caractères minimum.'; return; }
        if (a === code) { m.textContent = 'Choisissez un mot de passe différent du code provisoire.'; return; }
        if (a !== b) { m.textContent = 'Les deux mots de passe ne sont pas identiques.'; return; }
        m.style.color = '#64748b'; m.textContent = 'Enregistrement…';
        try {
          var r = await sb.auth.updateUser({ password: a, data: { pw_set: true } });
          if (r && r.error) throw r.error;
          try { localStorage.removeItem('EXB_PW_PENDING'); } catch (e) {}
          d.remove(); res();
        } catch (e) { m.style.color = '#b91c1c'; m.textContent = (e && e.message) || 'Enregistrement impossible.'; }
      };
    });
  };

  function start() {
    if (AUTO) {
      document.body.classList.add('exb-acct'); hideCreds();
      var lb = document.getElementById('lgBtn'); if (lb) lb.textContent = 'Réessayer la connexion';
      ['changeCreds', 'logout'].forEach(function (f) { if (typeof window[f] === 'function') window[f] = function () { alert(NOTE); }; });
      var lg = document.getElementById('loginScreen'); if (lg && lg.style.display === 'none') keepSession();
      setInterval(function () { hideCreds(); if (document.getElementById('app') && document.getElementById('app').style.display !== 'none') keepSession(); cloudLogin(); }, 30000);
      setTimeout(cloudLogin, 2500); window.addEventListener('online', cloudLogin);
    } else if (FIRST) {
      document.body.classList.add('exb-first');
      var i = document.getElementById('lgId'); if (i) { i.value = A.id; i.readOnly = true; i.style.opacity = '.75'; }
      var s = document.querySelector('#login .sub'); if (s) s.textContent = 'Connectez-vous avec le code provisoire reçu de l’administrateur.';
      var p = document.getElementById('lgPw'); if (p) p.placeholder = 'Code provisoire ou mot de passe';
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
