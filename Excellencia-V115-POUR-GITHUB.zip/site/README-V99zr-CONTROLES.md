# V99zr — Contrôles & sécurité sur chantier (audit interne « Chantier terrain », P2)

Fichiers : `exb-controles.js` (nouveau), `index.html` (1 balise), `sw.js` (cache `exb-v99zr-controles-1`), `exb-v99r-shell.js` (menu, version), `tools/test-controles.js`, `tools/e2e-smoke.py`.
Menu : **Projets & Chantiers › Contrôles & sécurité**. Données : `exb_ctl_chk`, `exb_ctl_cau`, `exb_ctl_nc` (incluses dans la sauvegarde chiffrée complète, qui reprend toutes les clés). Pas encore dans la synchronisation serveur.

## Ce que ça fait
- **Checklists qualité** : 4 modèles (avant coulage du béton, maçonnerie, terrassement & fondations, sécurité quotidienne) ; chaque point OK / NOK / N/A avec remarque ; résultat en % ; **signature du contrôleur au doigt** + **position GPS** ; PDF. À la clôture, **chaque point NOK crée une non-conformité**. Une checklist signée est verrouillée.
- **Causeries sécurité** : thème, animateur, durée, points abordés, **liste de présence avec signature de chaque participant**, signature de l'animateur, position, PDF.
- **Non-conformités** : gravité (mineure / majeure / critique), responsable, échéance (alerte « en retard »), action corrective, statut (ouverte / en cours / levée, datée), **photo** (réduite à 800 px) et **position**. Filtre ouvertes / levées.
- Tableau de bord du chantier : non-conformités ouvertes et en retard, nombre de checklists et de causeries.
- Les modèles de checklist sont des **bases de travail** à adapter au CCTP et au plan d'assurance qualité du chantier.

## Limites connues
- Photos : une par non-conformité (stockage du navigateur limité à ~5 Mo) ; annotation de la photo sur plan non faite.
- Position GPS : exige l'autorisation de localisation du téléphone ; précision affichée. Le pointage des ouvriers existant (Terrain hors ligne) n'est pas encore géolocalisé.
- Le rapport journalier existant (météo, effectif) n'est pas encore enrichi (effectifs par corps de métier, engins, matériaux reçus).
- Test : `node tools/test-controles.js` (7 contrôles) et parcours navigateur (signature au pointeur, position simulée, photo, échappement) ; `node tools/check.js` : 275 contrôles. Non testé sur un vrai téléphone.
