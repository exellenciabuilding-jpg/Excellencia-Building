/* Excellencia Building V79 — Architecture : phases de mission, honoraires par phase, heures, facturation vers « Finance » (V78).
 * Stockage : exb_phases (collection serveur « phases »). Les factures d'honoraires sont créées dans exb_finance. */
(function(w,d){'use strict';
var KEY='exb_phases',COL='phases',FK='exb_finance',ST=['à faire','en cours','livré','validé client'],
 STD=[['Esquisse',10],['Avant-projet sommaire (APS)',15],['Avant-projet détaillé (APD)',15],['Projet et permis de bâtir',15],['Dossier de consultation des entreprises (DCE)',15],['Suivi de chantier',25],['Réception',5]],st={pid:''};
function load(){return w.EXBS.get(KEY)}function save(a){return w.EXBS.set(KEY,a)}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}}
function canR(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL,'lire')}catch(e){return true}}
function canW(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL,'ecrire')}catch(e){return true}}
function today(){return new Date().toISOString().slice(0,10)}
function uid(p){return p+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6)}
function projs(){try{return w.EXBS.projects()}catch(e){return[]}}
function fmt(n,c){return new Intl.NumberFormat('fr-FR',{minimumFractionDigits:c==='USD'?2:0,maximumFractionDigits:c==='USD'?2:0}).format(n||0)+(c==='USD'?' $':' FC')}
function R(t){return load().filter(function(x){return x.type===t&&String(x.project)===String(st.pid)})}
function fx(){var t=(w.EXBS.get(FK)||[]).filter(function(x){return x.type==='taux'&&x.rate>0}).sort(function(a,b){return a.date<b.date?-1:1});return t.length?t[t.length-1].rate:0}
function cost(){try{return Number(localStorage.getItem('exb_arch_cost'))||0}catch(e){return 0}}
function open(){if(!canR())return say('Accès non autorisé.','error');if(!st.pid){var P=projs();st.pid=localStorage.getItem('exb_active_project')||(P[0]&&P[0].id)||''}draw()}
function draw(){var o=d.getElementById('exbArc');if(!o){o=d.createElement('div');o.id='exbArc';o.style.cssText='position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';o.onclick=function(e){if(e.target===o)o.remove()};d.body.appendChild(o)}
 var c=R('contrat')[0],h='<div style="background:#fff;border-radius:14px;padding:16px;max-width:760px;width:100%;font:14px Arial;color:#172033"><div style="display:flex;justify-content:space-between"><b style="font-size:17px">📐 Architecture — phases et honoraires</b><button onclick="document.getElementById(\'exbArc\').remove()">✕</button></div>'
 +'<p><select onchange="EXBARC.proj(this.value)" style="padding:8px;max-width:100%">'+projs().map(function(p){return '<option value="'+esc(p.id)+'"'+(String(p.id)===String(st.pid)?' selected':'')+'>'+esc(p.nom||p.name||p.titre||p.title||p.id)+'</option>'}).join('')+'</select></p>';
 if(!c){h+=(canW()?'<p>Honoraires totaux du projet (HT)<br><input id="arT" type="number" step="any" style="padding:8px;width:160px"> <select id="arC" style="padding:8px"><option>USD</option><option>FC</option></select></p><button onclick="EXBARC.start()" style="padding:9px 14px">Créer les 7 phases standard</button><p style="color:#64748b;font-size:12px">Esquisse, APS, APD, projet et permis, DCE, suivi de chantier, réception. Les pourcentages sont modifiables ensuite.</p>':'<p>Aucun contrat d’honoraires pour ce projet.</p>')+'</div>';o.innerHTML=h;return}
 var P=R('phase'),T=R('temps'),tp=P.reduce(function(a,p){return a+(Number(p.pct)||0)},0),bill=0,val=0,hrs=0,rate=fx();
 var rows=P.map(function(p){var amt=Math.round(c.total*p.pct)/100,hh=T.filter(function(t){return t.phase===p.id}).reduce(function(a,t){return a+t.hours},0);hrs+=hh;if(p.billed)bill+=amt;if(p.status==='validé client')val+=Number(p.pct)||0;
  return '<div style="border-bottom:1px solid #e2e8f0;padding:7px 0"><b>'+esc(p.name)+'</b> · '+p.pct+' % · '+fmt(amt,c.cur)+'<br><select '+(canW()?'':'disabled ')+'onchange="EXBARC.st(\''+p.id+'\',this.value)" style="padding:6px">'+ST.map(function(s){return '<option'+(s===p.status?' selected':'')+'>'+s+'</option>'}).join('')+'</select> ⏱ '+hh+' h '
  +(canW()?'<button onclick="EXBARC.hours(\''+p.id+'\')">+ heures</button> '+(p.billed?'<span style="color:#166534">✔ facturée</span>':'<button onclick="EXBARC.bill(\''+p.id+'\')">🧾 Facturer</button>')+' <button onclick="EXBARC.del(\''+p.id+'\')">🗑</button>':'')+'</div>'}).join('');
 var cc=cost()*(c.cur==='FC'?rate:1),cs=hrs*cc,costKnown=cost()>0&&(c.cur==='USD'||rate>0);
 h+='<div style="display:flex;flex-wrap:wrap;gap:6px;margin:8px 0">'+[['Honoraires totaux',fmt(c.total,c.cur)],['Facturé',fmt(bill,c.cur)],['Avancement validé',val+' %'],['Heures passées',hrs+' h'],['Coût du temps',costKnown?fmt(cs,c.cur):'à définir'],['Marge sur facturé',costKnown?fmt(bill-cs,c.cur):'—']].map(function(x){return '<div style="flex:1 1 30%;background:#f1f5fb;border-radius:10px;padding:8px"><div style="font-size:12px;color:#64748b">'+x[0]+'</div><b>'+x[1]+'</b></div>'}).join('')+'</div>'
 +(tp!==100?'<div style="background:#fde8e8;padding:8px;border-radius:10px;margin-bottom:8px">⚠ Les phases totalisent '+tp+' % (attendu : 100 %).</div>':'')+rows
 +(canW()?'<p><button onclick="EXBARC.add()">➕ Phase</button> <button onclick="EXBARC.cost()">Coût horaire interne ('+(cost()?cost()+' $/h':'à définir')+')</button></p>':'')
 +'<p style="font-size:12px;color:#64748b">« Facturer » crée la facture d’honoraires dans Finance USD / FC (taux du jour : '+(rate?fmt(rate,'FC'):'non défini')+'). Le coût du temps = heures × coût horaire interne.</p></div>';o.innerHTML=h}
function A(f){return function(){if(!canW())return say('Écriture non autorisée.','error');f.apply(null,arguments);draw()}}
w.EXBARC={open:open,proj:function(v){st.pid=v;draw()},
 start:A(function(){var t=Number(d.getElementById('arT').value);if(!(t>0))return say('Montant obligatoire.','error');var a=load();a.push({id:uid('CT'),type:'contrat',project:st.pid,total:t,cur:d.getElementById('arC').value});STD.forEach(function(s){a.push({id:uid('PH'),type:'phase',project:st.pid,name:s[0],pct:s[1],status:'à faire'})});save(a)}),
 st:A(function(id,v){var a=load();a.forEach(function(x){if(x.id===id)x.status=v});save(a)}),
 hours:A(function(id){var v=w.prompt('Heures passées (ex. 3.5)','');var n=Number((v||'').replace(',','.'));if(!(n>0))return;var a=load();a.push({id:uid('TP'),type:'temps',project:st.pid,phase:id,date:today(),hours:n});save(a)}),
 add:A(function(){var n=w.prompt('Nom de la phase');if(!n)return;var p=Number((w.prompt('Pourcentage des honoraires','5')||'').replace(',','.'));if(!(p>0))return;var a=load();a.push({id:uid('PH'),type:'phase',project:st.pid,name:n,pct:p,status:'à faire'});save(a)}),
 cost:A(function(){var v=Number((w.prompt('Coût horaire interne moyen, en $ par heure','')||'').replace(',','.'));if(v>0)try{localStorage.setItem('exb_arch_cost',String(v))}catch(e){}}),
 del:A(function(id){if(!w.confirm('Supprimer cette phase et ses heures ?'))return;save(load().filter(function(x){return x.id!==id&&x.phase!==id}))}),
 bill:A(function(id){var a=load(),p=a.find(function(x){return x.id===id}),c=R('contrat')[0],r=fx();if(!p||p.billed)return;if(!r)return say('Définissez d’abord le taux du jour dans Finance USD / FC.','error');
  var tva=Number((w.prompt('TVA (%)','16')||'').replace(',','.'));if(isNaN(tva))return;var ht=Math.round(c.total*p.pct)/100,F=w.EXBS.get(FK),y=new Date().getFullYear(),n=F.filter(function(x){return x.type==='facture'&&String(x.no||'').indexOf('F-'+y)===0}).length+1,fid=uid('FIN');
  F.push({id:fid,type:'facture',project:st.pid,no:'F-'+y+'-'+String(n).padStart(3,'0'),date:today(),cur:c.cur,ht:ht,tva:tva,ttc:Math.round(ht*(1+tva/100)*100)/100,rate:r,parent:'',note:'Honoraires — '+p.name});w.EXBS.set(FK,F);p.billed=fid;save(a);say('Facture créée dans Finance.')})};
function ui(){var b=d.getElementById('badm');if(!b||d.getElementById('exbArcBtn'))return;var k=d.createElement('button');k.id='exbArcBtn';k.className='muted';k.textContent='📐 Phases architecture';k.onclick=open;if(!canR())k.setAttribute('data-exbrole','hide');b.parentNode.appendChild(k)}
new MutationObserver(ui).observe(d.documentElement,{childList:true,subtree:true});d.addEventListener('DOMContentLoaded',ui);
})(window,document);
