# Affiches › Studio libre : 40 nouveaux modèles

**Aucun SQL.** Fichier modifié : `exb-affiches-studio.js` (+ nouvelle version de cache dans `sw.js`).

Dans *Affiches › Studio libre › Modèle de départ*, la liste est maintenant classée par catégories (46 modèles au total). Chaque modèle choisit tout seul le bon format (A4, carré, story, bannière…) ; tous les textes, couleurs, photos et formes restent modifiables.

- **Communiqués & avis** : communiqué officiel (presse/public), fermeture/horaires, appel d'offres, convocation, changement d'adresse, mise en garde fraude, note de service (+ Avis/Communiqué existant).
- **Livres** : couverture, lancement/dédicace, livre en vente, catalogue de livres, citation/extrait, ebook à télécharger.
- **Équipements & matériel** : location d'engins, liste de prix matériaux, fiche équipement, nouvel arrivage, consignes de sécurité EPI.
- **Logiciels & formations** : formation sur un logiciel, programme par modules, pack multi-logiciels, logiciels enseignés, test QCM, webinaire, inscriptions ouvertes (story), attestation de formation (+ Formation existant).
- **Textes professionnels** : lettre, offre de services, page de garde (devis/rapport), attestation, invitation officielle, procès-verbal, vœux/remerciements.
- **Chantiers & réalisations** : panneau de chantier, projet réalisé, avant/après, avis de travaux, nos services, témoignage client, devis gratuit.

Les structures suivent les usages : communiqué (en-tête, « pour publication immédiate », titre, ville/date, contact), dédicace (titre, couverture, auteur, date/lieu, contact), appel d'offres (objet, délais, dépôt, ouverture des plis).

Outils : le logo, le nom, le téléphone, l'e-mail et l'adresse viennent de l'identité de l'entreprise. Les textes s'ajustent automatiquement pour ne pas se chevaucher ni passer sous le bandeau du bas.
