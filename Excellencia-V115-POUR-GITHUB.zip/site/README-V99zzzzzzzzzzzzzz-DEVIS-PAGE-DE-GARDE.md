# V99zzzzzzzzzzzzzz — Devis : page de garde + QR sur chaque page
Fichier modifié : `exb-docs.js` (+ `sw.js` pour renouveler le cache). Vider le cache / recharger l'application après mise à jour.

- **Page 1 = page de garde** (modèle devis_page_de_garde_v3) : en-tête (logo, nom, slogan, coordonnées), bandeau DEVIS + n° + date + validité, titre du projet, dossier, blocs CLIENT / PRESTATAIRE, récapitulatif (taux de change, détail des postes « pages 2 à N », sous-total, imprévus éventuels, TOTAL GÉNÉRAL), conditions générales, « Fait à … le … », signatures (cachet + signature du prestataire, signature du client).
- **Textes personnalisés automatiquement** : nom/adresse/téléphone/e-mail du client, intitulé du projet (1 à 3 lignes, police ajustée), n° de dossier, dates, taux, montants, noms des signataires, identité de l'entreprise (menu Logo Excellencia Building > identité : slogan, téléphone, e-mail, adresse, mentions légales, ville de signature).
- **Pages suivantes** : en-tête compact, « DÉTAIL DES POSTES », tableau, totaux ; la suite des conditions générales qui ne tient pas sur la page de garde est imprimée en fin de document.
- **QR de vérification en pied de TOUTES les pages** du devis (avec « Page i / N » et le code de vérification), quel que soit le nombre de pages.
- Factures et reçus : mise en page inchangée. Retour à l'ancien devis possible avec `build(d, { cover: false })`.
