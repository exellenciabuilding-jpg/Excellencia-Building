# V99 — Éditeur de plan : contrôle de résolution des vues 3D sur les mises en page

Fichiers modifiés : `plan-editeur/index.html`, `sw.js` (version du cache). Aucun changement de format de plan (deux champs ajoutés aux métadonnées : `v3d`, `res3d`).

## Utilisation
Menu Mise en page › 📋 Cartouche (impression) :
- **Vue 3D sur les feuilles** : Non (défaut, comportement inchangé) / Oui → une feuille « Vue 3D » est ajoutée après les façades et coupes, avec cartouche et numérotation (x / n) mise à jour.
- **Résolution des vues 3D** : Brouillon 100 dpi · Standard 150 dpi (défaut) · Haute 200 dpi · Très haute 300 dpi.
- Une ligne indique la taille exacte de l'image pour le format choisi (ex. A3 à 300 dpi : 4755 × 2759 px ≈ 13,1 Mpx ; A4 à 300 dpi : 3302 × 1802 px).

## Comportement
- La vue imprimée est le **dernier cadrage** de la vue 3D (si la 3D n'a jamais été ouverte : perspective par défaut). Les niveaux affichés suivent le réglage de la vue 3D ; la sélection n'apparaît pas à l'impression.
- Si l'appareil ne supporte pas la taille demandée (mémoire / limite WebGL), la résolution est réduite automatiquement (100 %, 75 %, 50 %, 35 %) ; un message le signale et la feuille indique **la résolution réelle** (« Vue 3D — 4096 × 2377 px · 258 dpi (demandé : 300 dpi) »).
- Image encodée en JPEG (qualité 93 %, fond blanc) pour garder le PDF léger.

## Tests
Chromium sans écran (rendu logiciel) : 100/150/300 dpi, feuille ajoutée, légende exacte, numérotation 1/8…8/8, option « Non » = 7 feuilles comme avant, aucune erreur de console. Non testé sur téléphone Android / Windows réel : la limite de mémoire graphique y est plus basse (le repli automatique s'applique).
