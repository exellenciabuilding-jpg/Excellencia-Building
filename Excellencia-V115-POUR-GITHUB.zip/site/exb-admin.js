/* exb-admin.js — Générateur de licences intégré au site central (administrateur uniquement).
 * Il ne s'affiche et ne fonctionne QUE sur l'appareil qui contient la clé privée.
 * Un appareil client (qui a activé un lien) ne le voit jamais, même avec ?admin=1, et ne peut rien signer sans la clé. */
(function () {
  'use strict';
  function hasKey() { try { var k = JSON.parse(localStorage.getItem('exb_lic_priv') || 'null'); return !!(k && k.d); } catch (e) { return false; } }
  function clientDevice() { try { return !!localStorage.getItem('exb_lic_token') && !hasKey(); } catch (e) { return false; } }
  var wantAdmin = /[?&]admin=1/.test(location.search);
  function due() {
    var h = []; try { h = JSON.parse(localStorage.getItem('exb_gen_hist2') || '[]'); } catch (e) {}
    var best = {}; h.forEach(function (x) { var k = (x.name || '').toLowerCase(); if (!best[k] || new Date(x.exp) > new Date(best[k].exp)) best[k] = x; });
    return Object.keys(best).filter(function (k) { return Math.ceil((new Date(best[k].exp) - Date.now()) / 864e5) <= 7; }).length;
  }
  function close() { var d = document.getElementById('exbGenOv'); if (d) d.remove(); show(); try { if (window.EXBLIC) window.EXBLIC.check(); } catch (e) {} }
  function open() {
    if (clientDevice() || document.getElementById('exbGenOv')) return;
    var d = document.createElement('div'); d.id = 'exbGenOv';
    d.style.cssText = 'position:fixed;inset:0;z-index:100002;background:#f2f5fa';
    d.innerHTML = '<iframe src="exb-generator.html?self=c" style="border:0;width:100%;height:100%" title="Licences clients"></iframe>';
    document.body.appendChild(d);
    var b = document.getElementById('exbGenBtn'); if (b) b.style.display = 'none';
  }
  window.addEventListener('message', function (e) { if (e.origin === location.origin && e.data && e.data.exbGen === 'close') close(); });
  function show() {
    var b = document.getElementById('exbGenBtn');
    if (clientDevice() || !(hasKey() || wantAdmin)) { if (b) b.remove(); var o = document.getElementById('exbGenOv'); if (o && clientDevice()) o.remove(); return; }
    if (!b) {
      b = document.createElement('button'); b.id = 'exbGenBtn'; b.title = 'Licences clients';
      b.style.cssText = 'position:fixed;left:12px;bottom:142px;z-index:100001;width:46px;height:46px;border-radius:50%;border:0;background:#c49a38;color:#fff;font-size:21px;box-shadow:0 4px 14px #0004';
      b.onclick = open; document.body.appendChild(b);
    }
    var n = hasKey() ? due() : 0;
    b.innerHTML = '🔑' + (n ? '<span style="position:absolute;top:-4px;right:-4px;min-width:20px;height:20px;border-radius:10px;background:#dc2626;color:#fff;font:700 12px/20px system-ui;text-align:center">' + n + '</span>' : '');
    b.title = n ? n + ' licence(s) à renouveler' : 'Licences clients';
    b.style.display = '';
  }
  function start() {
    show(); setInterval(function () { if (!document.getElementById('exbGenOv')) show(); }, 4000);
    try { if (window.EXBLIC) window.EXBLIC.adminDialog = async function () { open(); }; } catch (e) {}
    window.EXB_GEN = { open: open };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
