# V99 — Éditeur de plan : objets paramétriques (type GDL)

Fichiers : `plan-editeur/parametrique.js` (nouveau), `plan-editeur/index.html`, `sw.js` (cache). Clé facultative `pp` sur un objet : un plan existant s'ouvre comme avant.

- Palette Objets › **Objets paramétriques** : Table, Étagère, Pergola.
- Fiche de l'objet : largeur, profondeur, hauteur + paramètres propres (épaisseur plateau, pieds, nombre de tablettes, poteaux, lames…). La forme 3D est recalculée à chaque changement.
- Ajouter un objet : une entrée dans `DEFS` de `parametrique.js` (paramètres + fonction `gen` en boîtes, en mètres).

Limites : trois objets de départ ; pas de scripts 2D propres (symbole rectangulaire) ; coupes, IFC et DXF non testés sur ces objets. Testé : syntaxe, génération des pièces et bornage des paramètres sous Node ; pas de test visuel WebGL.
Restent : outil Morph et opérations booléennes.
