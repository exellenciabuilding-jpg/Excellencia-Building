EXCELLENCIA BUILDING V69 — INTELLIGENCE BTP & ARCHITECTURE

Base : V68 Priorité 2. Extension non destructive.

Nouveautés :
- Copilot IA local basé sur les données enregistrées : coûts, EVM, risques, projets, estimations et benchmarks.
- Analyse prédictive initiale : détection de CPI < 1, SPI < 1 et criticité de risques élevée.
- Bibliothèque de prix : matériaux, main-d'œuvre, matériel, prestations.
- Estimation automatique : quantité × prix + réserve de risque.
- Benchmark projets : coût/m², écart de délai, productivité et marge.

IMPORTANT : le Copilot V69 est volontairement local/règle-métier dans cette version. Aucun secret de fournisseur IA n'est embarqué. Une future passerelle IA sécurisée pourra être branchée côté serveur.

SUPABASE : exécuter supabase/migration-v75-droits-v69-v74.sql (V75) après les migrations précédentes.

TESTS :
- ouvrir l'application ;
- ouvrir « Intelligence BTP » ;
- créer un prix ;
- créer une estimation ;
- ajouter un benchmark ;
- poser une question au Copilot ;
- vérifier les alertes prédictives avec les données EVM/risques de V68 ;
- vérifier la synchronisation Supabase et les droits selon le rôle.
