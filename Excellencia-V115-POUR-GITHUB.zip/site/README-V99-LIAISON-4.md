# V99 — Liaison, tranche 4 (V93, bureau d'études / BIM, dossier chantier, clients en double)

Fichier : `exb-liaison-4.js` (chargé après la tranche 3, mis en cache hors ligne). Aucun SQL à exécuter.

## Chantiers V93 ↔ projets du logiciel
Un projet V93 (`exb_v93_projects`) reçoit `core_project_id` (et `client_id`) quand il correspond à un projet du logiciel : même identifiant,
ou même nom (espaces et casse ignorés) à condition qu'il soit unique. Chantiers, tâches, alertes QHSE, matériel et sous-traitants V93 suivent leur
projet (directement, par le projet V93 ou par leur chantier). Sans correspondance sûre, aucun lien n'est deviné : le projet est signalé.

## Bureau d'études et BIM
- Notes de calcul et missions : reçoivent le `client_id` du projet.
- Plans, révisions, documents, maquettes et problèmes BIM (V94) : **lecture seule**. Ils portent déjà leur projet ; on contrôle seulement
  qu'il existe encore et on les compte dans le dossier chantier.

## Dossier chantier connecté (écran Projets)
Choisir un chantier affiche : client, budget, devis / facturé / versé / solde par devise, dépenses et main-d'œuvre à payer, puis les compteurs :
devis, factures, commandes, mouvements de stock, études, notes de calcul, plans, révisions, documents, maquettes BIM, problèmes BIM ouverts,
missions BE, journal de chantier, jours pointés, situations de travaux, projet V93, tâches V93 (avancement moyen), alertes QHSE ouvertes.

## Clients en double (écran Clients)
Détection par téléphone (9 derniers chiffres), e-mail ou nom identique. Pour chaque groupe : **✔ Garder celui-ci** fusionne les autres dedans, après confirmation.
- Tous les enregistrements rattachés (projets, devis, factures, caisse, paiements V93, métrés, notes de calcul, missions, projets V93) passent au client conservé.
- Les informations manquantes de la fiche conservée sont reprises ; celles qui existent déjà ne sont jamais écrasées.
- Le nom est mis à jour sur les documents non émis ; les documents émis gardent le nom d'origine (`client_snapshot`).
- La fiche complète de chaque client supprimé est conservée dans le journal de liaison (`exb_liaison_journal`).
- Réservé aux utilisateurs ayant le droit d'écrire sur les clients. Il n'y a pas d'annulation automatique : le journal permet de recréer une fiche.

## Contrôles ajoutés
Projet V93 sans projet correspondant ; notes de calcul, missions, plans, documents, maquettes, problèmes BIM, études V94, journal de chantier,
situations de travaux, tâches et chantiers V93 rattachés à un chantier introuvable ; groupes de clients en double.

## Tests
`node tools/test-liaison-4.js` (41 contrôles), `python3 tools/e2e-liaison-4.py` (navigateur réel), `node tools/check.js` (476 contrôles).
