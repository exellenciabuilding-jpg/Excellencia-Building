# V99zj — Ingénierie & Structure : chaque module a sa tuile, ouverture directe

Fichiers modifiés : `exb-calcul-structure.js`, `exb-v99r-shell.js`, `calcul-structure/index.html`, `sw.js` (cache `exb-v99zj-tuiles-modules-1`).

- La page **Ingénierie & Structure** affiche maintenant **tous les modules du calcul de structure** en tuiles : Prédimensionnement, Bâtiment, Poutre continue, Poteau, Dalle / plancher, Semelle isolée, Escalier, Dosage béton, Mortier, Volumes, Coffrage, Ferraillage, Moment maximal, Coûts, Agglos, Devis DQE (+ Métré & devis).
- Un appui sur une tuile ouvre **directement le module** (géométrie, résultats, 3D, note de calcul, plan). Plus d'étape intermédiaire « Calcul de structure ».
- La tuile générique « Calcul de structure » est retirée du menu (l'écran reste accessible par le code).
- La barre des modules du haut (celle du logiciel) liste les mêmes modules ; la seconde barre qui était dans le calculateur est masquée quand il est intégré, pour ne garder qu'un seul niveau.
- Retour en arrière : restaurer les 4 fichiers de V99zi.
