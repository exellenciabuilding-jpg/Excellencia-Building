# V99zzx — TFL : fiche étudiante complète après le choix d'un sujet

Quand un étudiant clique **« Choisir ce sujet »** (page `tfl-sujets.html`), sa demande est envoyée, puis **un nouvel onglet s'ouvre** sur `tfl-fiche.html` (lien court `/tfl-fiche`) : fiche étudiante complète.

## Ce que l'étudiant renseigne
Identité (nom, téléphone, e-mail, date et lieu de naissance, nationalité, adresse) · **photo** · université, faculté/département, **spécialité/filière**, **année académique**, **promotion**, niveau, matricule Excellencia et universitaire · ce qu'il a déjà fait, remarques. Les champs déjà saisis au choix du sujet sont pré-remplis. Année académique et promotion sont obligatoires.
Si le navigateur bloque le nouvel onglet, un bouton « Compléter ma fiche étudiante » apparaît à la place.

## Envoi
- **En ligne** : « 📡 Envoyer ma fiche en ligne » → fonction `tfl_fiche_etudiant_envoyer` (à créer : `supabase/migration-v99zzx-tfl-fiche-etudiant.sql`, courte, une seule fonction). Refuse toute fiche sans choix de sujet préalable (même sujet + même téléphone).
- **Sans Internet** : « 💾 Enregistrer le fichier » → même format `EXB_TFL` que les autres candidatures, importable tel quel.

## Côté administrateur (onglet 🎓 TFL)
- La fiche du dossier affiche la **photo** et toutes les informations (année académique, promotion, spécialité, faculté, niveau, etc.).
- Importer la fiche **met à jour le dossier existant** du même étudiant et du même sujet : pas de doublon, statut et décision inchangés. Un nouvel envoi sans certains champs ne les efface pas.

## À faire
1. Supabase : exécuter `migration-v99zzx-tfl-fiche-etudiant.sql` (après la V99zzv).
2. Déployer le ZIP, recharger une fois.

## Limites
- SQL non exécuté sur un vrai Supabase ici : tester avec un sujet d'essai (choisir → compléter la fiche → récupérer les candidatures).
- La photo est conservée avec la candidature ; elle n'apparaît dans le dossier qu'après import.
- Testé : contrôles `node tools/check.js` (395), `node tools/test-tfl/test.js`, page ouverte et fichier généré dans Chromium (390 px). Non testé sur un vrai téléphone.

Fichiers : nouveaux `tfl-fiche.html`, `supabase/migration-v99zzx-tfl-fiche-etudiant.sql` ; modifiés `tfl-sujets.html`, `exb-tfl.js`, `sw.js` (cache `exb-v99zzx-tfl-fiche-etudiant`), `_redirects`, `tools/check.js`, `tools/test-tfl/test.js`.

## Ajout : fiche PDF avec QR de vérification
Après l'envoi de la fiche (en ligne ou par fichier), un **PDF « FICHE ÉTUDIANT — TFL · CHOIX DE SUJET »** se télécharge tout seul : logo, **photo**, **QR de vérification**, nom, contact, naissance, université/faculté, spécialité, **année académique**, **promotion**, niveau, matricules, **sujet choisi**, n° de fiche et code de vérification. Le bouton « 📄 Télécharger ma fiche PDF » permet de le re-télécharger (même QR).
- Le QR ouvre la page publique `verification.html` (sans connexion) : « ✅ Document authentique · Fiche d'inscription », nom, libellé (sujet), date, statut « reçue ». Aucun téléphone ni e-mail n'y figure.
- Enregistrement au registre : fonction existante `exb_doc_declare` (V99m, déjà exécutée) : **aucun nouveau SQL**. Hors connexion, l'enregistrement est repris dès que l'appareil est en ligne (tant qu'il n'est pas repris, la page indique « non confirmé »).
- Côté administrateur, l'**attestation de dépôt** d'un dossier porte aussi un QR et un code (publiés au registre quand l'administrateur est connecté).
- Le PDF affiche 10 lignes au plus (le moteur PDF coupe ce qui ne tient pas au-dessus de la zone de signature) ; l'adresse et les matricules n'apparaissent que s'ils sont renseignés.
- Testé : génération dans Chromium (page servie en HTTP), QR relu par un décodeur, page de vérification ouverte avec ce QR (serveur simulé). Non testé avec le vrai Supabase ni sur téléphone.
