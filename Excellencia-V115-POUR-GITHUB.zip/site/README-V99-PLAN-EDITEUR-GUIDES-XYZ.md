# V99 — Éditeur de plan : guides de direction et coordonnées X, Y, Z

Fichiers modifiés : `plan-editeur/index.html` et `sw.js` (version du cache). Aucun changement du format de plan.

**Guides de direction** (bouton 🧭 Guide, touche **G** pour activer / désactiver ; réglage mémorisé) — outils Mur, Pièce, Câble, Hachure, Cotation :
- Une ligne guide en pointillé passe par le dernier point et suit le curseur.
- Elle devient pleine et colorée, avec un texte dans la bulle, quand la direction est :
  - vert : Horizontal / Vertical : droit, Angle droit (90°) avec le mur précédent, Prolongement du mur précédent ;
  - orange : Diagonale 45° ;
  - violet : Parallèle ou Perpendiculaire à un mur existant.
- Le curseur s'accroche à ces directions à moins de 3°.
- Alignement : des pointillés turquoise relient le curseur aux points existants quand ils ont le même X ou le même Y (accrochage à 8 px).

**Bulle Distance / Angle** : tapez la distance en cm, Tab pour passer à l'angle (degrés, 0° = droite, 90° = haut), puis Entrée pour poser le mur. Distance seule ou angle seul fonctionnent aussi.

**Coordonnées X, Y, Z** (en bas à droite du plan, en mètres) : X vers la droite, Y vers le haut (convention CAD), Z = altitude de l'étage actif. Le bouton ⌖ Saisir pose un point exact par X, Y avec l'outil actif.

Maj = 45° et Alt = tracé libre gardent leur rôle ; le mode d'accrochage « Libre » désactive les alignements.
