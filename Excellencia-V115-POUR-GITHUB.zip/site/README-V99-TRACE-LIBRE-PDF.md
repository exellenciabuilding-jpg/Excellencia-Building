# Éditeur de plan — tracé libre, axes, export PDF

- Bouton d'accroche à 3 états (barre du haut) : 🧲 Grille (5/10/25 cm) → 🎯 Points (angles existants, sinon précis au cm, défaut) → ✋ Libre (aucune accroche).
- Courbure des murs : en Points/Libre, la flèche se règle au centimètre (plus de pas de 5 cm).
- Longueur d'un mur : fiche de droite, champ « Longueur (m) » (ex. 1,32).
- Correctif : le bouton « 📄 PDF » ouvrait l'import de plan (deux boutons avaient le même identifiant). Il fabrique maintenant le PDF du plan en page ; l'import s'appelle « PDF → plan ».
- Axes : tracés sur l'axe (ligne médiane) des murs ; panneau de droite > « Murs et axes ».

## Outil mur façon Archicad
- Info-bulle « Distance / Angle » (cm, °) qui suit le curseur.
- Saisie directe : tracer le départ, orienter la souris, taper la longueur en cm (132 = 1,32 m) puis Entrée.
- Maj = angle verrouillé 0/45/90° (longueur libre au cm). Alt = aucune accroche.

## Ajuster, hachures, cotes manuelles
- ✂ Ajuster : toucher la partie d'un mur qui dépasse -> coupée à l'intersection (Maj+toucher aussi). Alt+toucher = prolonger jusqu'au mur suivant. Les portes/fenêtres suivent.
- ▨ Hachure : zone libre (angles puis Entrée). Motifs : plein, diagonale, lignes (angle libre), croisé, points ; couleur, espacement (cm), épaisseur, contour.
- 📏 Cote : point A, point B, position de la ligne de cote. Fiche : décalage, texte libre, taille.

## Cotation automatique (façon Archicad)
Panneau de droite > « 📏 Cotation automatique » : (1) générale, (2) géométrie externe, (3) structures, (4) ouvertures (extrémités ou centre), murs cotés sur faces extérieures ou axes, distance entre lignes (50 cm), quatre côtés. « ⚡ Appliquer » active la cotation complète.

## Ligne de référence des murs
Liste « Réf. » dans la barre : axe / face gauche / face droite (selon le sens du tracé). Les angles se raccordent automatiquement, fermeture comprise. Fiche d'un mur droit : boutons « ½ ép. gauche / droite » pour décaler un mur déjà tracé.

## Tableau des pièces
Bouton « 📋 Tableau des pièces » : toutes les pièces de tous les niveaux (n°, niveau, nom modifiable, surface, périmètre, total), export CSV Excel, copie, et option « numéro de la pièce sur le plan ».
