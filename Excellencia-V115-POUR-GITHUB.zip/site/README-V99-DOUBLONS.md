# V99 — Doublons : un seul enregistrement, un seul numéro, un seul QR

Fichiers : `site/exb-doublons.js` (nouveau), `site/index.html` (une balise ajoutée), `site/sw.js` (cache hors connexion). **Aucun SQL.**

## 1. Détection sur l'écran d'accueil (intelligence)
Les anomalies apparaissent dans la carte « Anomalies détectées » de l'accueil et dans le panneau d'intelligence. Lecture seule : rien n'est modifié.
- **Personnes** : même matricule (erreur) ; même e-mail ; même nom inscrit deux fois à la même formation. (La règle existante garde le téléphone et nom + date de naissance.)
- **Formateurs** : même téléphone (+243 81… et 081… comptent pour le même), e-mail ou nom.
- **Certificats** : même numéro sur deux certificats (erreur) ; deux certificats valides pour la même personne et la même formation.
- **Reçus** : même numéro sur deux reçus (erreur) ; reçu identique (même personne, formation, date, montants, statuts) enregistré deux fois.
- **Un numéro = un QR** : le même numéro porté par deux documents de natures différentes (devis, facture, certificat, reçu) est signalé en erreur.

## 2. Avertissement avant d'enregistrer
- **Nouvelle fiche participant** (bouton Enregistrer de Participants) : si la personne ressemble à une fiche existante (matricule, e-mail, téléphone + nom, ou même nom dans la même formation), une fenêtre montre la fiche trouvée. *OK* = enregistrer quand même ; *Annuler* = ne pas créer de doublon. Modifier une fiche existante ne déclenche rien.
- **Certificat** : s'il existe déjà un certificat valide pour la même personne et la même formation, *OK* = ne pas en créer un second (l'existant et son QR s'affichent) ; *Annuler* = en créer un nouveau.
- **Reçu** : même principe pour un reçu identique.
Rien n'est supprimé ni fusionné automatiquement.

## Limites
- Testé avec des données simulées : les 5 règles de détection, les 3 fenêtres d'avertissement, la syntaxe de `index.html`. **Non testé** dans le logiciel avec vos vraies données.
- Les inscriptions qui arrivent par **Demandes reçues** (en ligne) et l'import en lot ne passent pas par ce garde-fou : l'import en lot ignore déjà nom + téléphone identiques, et les autres cas sont signalés ensuite par la détection de l'accueil.
- Deux homonymes dans la même formation seront signalés : ce n'est qu'un avertissement, vous gardez la décision.
- Les « travaux » (TFL, TP/TD) ne sont pas encore contrôlés ici (le TFL a déjà son contrôle de sujet en double).
Retour en arrière : supprimer la balise `<script src="exb-doublons.js">` dans `index.html`.
