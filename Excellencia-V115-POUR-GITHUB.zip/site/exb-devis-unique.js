/* Excellencia Building — Devis intelligents : pas de doublon d'enregistrement, numéro (donc QR) unique par devis.
 * - Numérotation : DEV-AAAA-NNN = plus grand numéro déjà utilisé + 1 (métrés, devis rapides ET registre des PDF) — plus de numéro réutilisé après une suppression.
 * - Avant d'enregistrer : détecte un devis identique déjà enregistré (met à jour au lieu de créer un doublon) ou un devis du même client et du même projet (demande quoi faire).
 * - Un numéro déjà attribué à un AUTRE client est refusé : un nouveau numéro est donné automatiquement, donc un QR de vérification n'appartient jamais à deux personnes.
 * Données : aucune nouvelle clé (lit exb_metre, exb_quotes, EXB_DOCS_V1). Aucun SQL.
 * Pour retirer : supprimer la balise <script src="exb-devis-unique.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_UNIQUE) return;
  function S() { try { return typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) { return null; } }
  function rd(k, def) { try { var v = (S() && S().getItem(k)) || localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function note(t, k, ms) { try { w.notify ? w.notify(t, k || 'info', ms || 6000) : alert(t); } catch (e) {} }
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
  function quotes() { try { if (typeof exbQuotes !== 'undefined' && Array.isArray(exbQuotes)) return exbQuotes; } catch (e) {} return rd('exb_quotes', []) || []; }
  function metres() { var a = rd('exb_metre', []); return Array.isArray(a) ? a : []; }
  function registry() { var r = rd('EXB_DOCS_V1', {}) || {}; return r.docs || {}; }
  function num(v) { v = Number(v); return isFinite(v) ? v : 0; }

  /* empreinte du contenu : même client, même projet, mêmes lignes et mêmes quantités = même devis */
  function stable(o) { try { return JSON.stringify(o, function (k, v) { if (v && typeof v === 'object' && !Array.isArray(v)) { var s = {}; Object.keys(v).sort().forEach(function (x) { s[x] = v[x]; }); return s; } return v; }); } catch (e) { return ''; } }
  function fpQuote(q) { return [norm(q.client), norm(q.project), (q.lines || []).map(function (l) { return norm(l.designation) + ':' + num(l.qty) + ':' + num(l.pu); }).join('|')].join('#'); }
  function fpMetre(m) { var h = m.hdr || {}; return [norm(h.client), norm(h.project), stable(m.ov || {}), stable(m.extra || [])].join('#'); }
  function pair(c, p) { return norm(c) + '#' + norm(p); }

  /* tous les numéros déjà utilisés → {numéro: client} */
  function used() {
    var u = {};
    metres().forEach(function (m) { var h = m.hdr || {}; if (h.no) u[h.no] = u[h.no] === undefined ? norm(h.client) : u[h.no]; });
    quotes().forEach(function (q) { if (q.no && u[q.no] === undefined) u[q.no] = norm(q.client); });
    var R = registry(); Object.keys(R).forEach(function (n) { if (u[n] === undefined) u[n] = norm(R[n] && R[n].client); });
    return u;
  }
  /* code de l'appareil (2 à 4 caractères) : évite que deux appareils donnent le même numéro. Vide = ancien format DEV-AAAA-NNN. */
  var DK = 'exb_device_code', AL = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  function deviceCode() {
    try {
      var c = localStorage.getItem(DK);
      if (c === null) { c = AL[Math.floor(Math.random() * 24)] + AL[Math.floor(Math.random() * 32)]; localStorage.setItem(DK, c); }
      return String(c).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4);
    } catch (e) { return ''; }
  }
  function setDeviceCode(v) { try { localStorage.setItem(DK, String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4)); } catch (e) {} return deviceCode(); }
  function nextNo(prefix) {
    prefix = prefix || 'DEV'; var y = new Date().getFullYear(), code = deviceCode(), pre = prefix + '-' + y + '-' + (code ? code + '-' : ''), max = 0, u = used(), k, n;
    for (k in u) if (k.indexOf(pre) === 0 && /^\d+$/.test(k.slice(pre.length))) { n = parseInt(k.slice(pre.length), 10); if (n > max) max = n; }
    do { max++; n = pre + String(max).padStart(3, '0'); } while (u[n] !== undefined);
    return n;
  }
  /* le numéro est-il déjà donné à un autre client / un autre devis ? selfNo : numéro actuel du devis modifié, selfClient : son client */
  function conflict(no, client, selfIds) {
    if (!no) return false; var c = norm(client), sid = selfIds || [], bad = false;
    metres().forEach(function (m) { if (!bad && m.hdr && m.hdr.no === no && sid.indexOf(m.id) < 0) bad = true; });
    quotes().forEach(function (q) { if (!bad && q.no === no && sid.indexOf(q.id) < 0) bad = true; });
    if (!bad) { var r = registry()[no]; if (r && r.client && c && norm(r.client) !== c) bad = true; }
    return bad;
  }
  function look(kind, rec, selfId) {
    /* kind : 'quote' (devis rapide) ou 'metre' ; renvoie le meilleur doublon dans la MÊME liste */
    var list = kind === 'quote' ? quotes() : metres(), fp = kind === 'quote' ? fpQuote(rec) : fpMetre(rec), pr = kind === 'quote' ? pair(rec.client, rec.project) : pair((rec.hdr || {}).client, (rec.hdr || {}).project), same = null, sim = null;
    list.forEach(function (x) {
      if (x.id === selfId) return;
      var f = kind === 'quote' ? fpQuote(x) : fpMetre(x), p = kind === 'quote' ? pair(x.client, x.project) : pair((x.hdr || {}).client, (x.hdr || {}).project);
      if (!same && f === fp && norm(kind === 'quote' ? x.client : (x.hdr || {}).client)) same = x;
      else if (!sim && p === pr && p !== '#') sim = x;
    });
    return same ? { mode: 'same', rec: same } : sim ? { mode: 'similar', rec: sim } : null;
  }
  function noOf(kind, x) { return kind === 'quote' ? x.no : (x.hdr || {}).no; }

  /* ----- métré (exb-metre.js appelle ceci avant d'enregistrer) : renvoie false pour annuler ----- */
  function beforeSaveMetre(ST) {
    var h = ST.hdr || {};
    if (!ST.id) {
      var f = look('metre', ST, null);
      if (f && f.mode === 'same') { ST.id = f.rec.id; if (!h.no) h.no = noOf('metre', f.rec); note('Ce devis est déjà enregistré (N° ' + noOf('metre', f.rec) + ') : il a été mis à jour, pas de doublon.', 'info'); }
      else if (f && f.mode === 'similar') {
        if (confirm('Un devis existe déjà pour ce client et ce projet (N° ' + noOf('metre', f.rec) + ').\n\nOK = METTRE À JOUR ce devis existant (recommandé)\nAnnuler = enregistrer comme NOUVEAU devis (nouveau numéro)')) { ST.id = f.rec.id; h.no = noOf('metre', f.rec) || h.no; }
        else if (h.no === noOf('metre', f.rec)) h.no = nextNo();
      }
    }
    if (h.no && conflict(h.no, h.client, ST.id ? [ST.id] : [])) { var old = h.no; h.no = nextNo(); note('Le numéro ' + old + ' est déjà attribué à un autre devis : ce devis reçoit le numéro ' + h.no + ' (un QR ne peut pas appartenir à deux devis).', 'warn', 9000); }
    return true;
  }
  /* ----- transfert métré → devis rapide : ajoute ou met à jour (jamais de doublon) ----- */
  function upsertQuote(q) {
    var f = look('quote', q, q.id), arr = quotes();
    if (f && f.mode === 'same') { return { q: f.rec, mode: 'unchanged' }; }
    if (f && f.mode === 'similar') {
      var keep = f.rec.id, no = f.rec.no; Object.keys(q).forEach(function (k) { if (k !== 'id') f.rec[k] = q[k]; }); f.rec.no = no; return { q: f.rec, mode: 'updated' };
    }
    if (q.no && conflict(q.no, q.client, [q.id])) q.no = nextNo();
    arr.push(q); return { q: q, mode: 'created' };
  }
  /* ----- contrôle d'un devis rapide en cours de saisie (formulaire de index.html) ----- */
  function beforeSaveForm() {
    var g = function (i) { var e = d.getElementById(i); return e ? e.value : ''; }, id = g('exb_q_id'), q = { id: id, no: g('exb_q_no'), client: g('exb_q_client').trim(), project: g('exb_q_project'), lines: [] };
    try { if (typeof exbQuoteLines !== 'undefined') q.lines = exbQuoteLines; } catch (e) {}
    if (!q.client) return true;
    if (!id) {
      var f = look('quote', q, null);
      if (f && f.mode === 'same') { d.getElementById('exb_q_id').value = f.rec.id; d.getElementById('exb_q_no').value = f.rec.no; note('Ce devis est déjà enregistré (N° ' + f.rec.no + ') : il est mis à jour, pas de doublon.', 'info'); return true; }
      if (f && f.mode === 'similar') {
        if (confirm('Un devis existe déjà pour ce client et ce projet (N° ' + f.rec.no + ').\n\nOK = METTRE À JOUR ce devis existant (recommandé)\nAnnuler = enregistrer comme NOUVEAU devis (nouveau numéro)')) { d.getElementById('exb_q_id').value = f.rec.id; d.getElementById('exb_q_no').value = f.rec.no; return true; }
        if (q.no === f.rec.no) d.getElementById('exb_q_no').value = nextNo();
      }
    }
    var cur = g('exb_q_no'), selfIds = g('exb_q_id') ? [g('exb_q_id')] : [];
    if (cur && conflict(cur, q.client, selfIds)) { var nn = nextNo(); d.getElementById('exb_q_no').value = nn; note('Le numéro ' + cur + ' est déjà attribué à un autre devis : nouveau numéro ' + nn + ' (un QR ne peut pas appartenir à deux devis).', 'warn', 9000); }
    return true;
  }
  /* ----- avant génération du PDF : le numéro doit appartenir à CE client ----- */
  var ALIAS = 'EXB_NO_ALIAS';
  function guardDoc(doc) {
    try {
      if (!doc || (doc.kind && doc.kind !== 'devis')) return doc;
      var no = doc.no, cl = norm(doc.client && doc.client.name); if (!no || !cl) return doc;
      var r = registry()[no]; if (!r || !r.client || norm(r.client) === cl) return doc;
      var al = rd(ALIAS, {}) || {}, key = no + '|' + cl;
      if (!al[key] || (registry()[al[key]] && norm(registry()[al[key]].client) !== cl)) { al[key] = nextNo(); try { (S() || localStorage).setItem(ALIAS, JSON.stringify(al)); } catch (e) {} }
      note('Numéro ' + no + ' déjà utilisé par un autre client : ce devis porte le numéro ' + al[key] + '.', 'warn', 9000);
      doc.no = al[key]; doc.devisNo = doc.devisNo ? al[key] : doc.devisNo;
    } catch (e) {}
    return doc;
  }

  w.EXB_UNIQUE = { deviceCode: deviceCode, setDeviceCode: setDeviceCode, nextNo: nextNo, conflict: conflict, beforeSaveMetre: beforeSaveMetre, upsertQuote: upsertQuote, beforeSaveForm: beforeSaveForm, guardDoc: guardDoc, norm: norm, used: used };

  /* ----- formulaire « devis rapide » de index.html : on enveloppe les fonctions existantes ----- */
  function wrap() {
    if (typeof w.saveExbQuote === 'function' && !w.saveExbQuote.__u) {
      var f = w.saveExbQuote, g = function () { try { beforeSaveForm(); } catch (e) {} return f.apply(this, arguments); }; g.__u = 1; w.saveExbQuote = g;
    }
    if (typeof w.clearExbQuoteForm === 'function' && !w.clearExbQuoteForm.__u) {
      var f2 = w.clearExbQuoteForm, g2 = function () { var r = f2.apply(this, arguments); try { var e = d.getElementById('exb_q_no'); if (e) e.value = nextNo(); } catch (x) {} return r; }; g2.__u = 1; w.clearExbQuoteForm = g2;
    }
  }
  var n = 0, iv = setInterval(function () { wrap(); if (++n > 30 || (w.saveExbQuote && w.saveExbQuote.__u && w.clearExbQuoteForm && w.clearExbQuoteForm.__u)) clearInterval(iv); }, 800);
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(wrap, 300); }); else setTimeout(wrap, 300);
})(window, document);
