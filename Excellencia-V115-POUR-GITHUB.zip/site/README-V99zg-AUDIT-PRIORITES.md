# V99zg — Corrections prioritaires de l'audit interne (celles faisables dans le code)

Fichiers : `exb-keyguard.js` (nouveau), `index.html` (1 balise script), `exb-generator.html`, `exb-proprietaire.js`, `exb-v99r-shell.js`, `sw.js` (cache `exb-v99zg-securite-1`), `tools/e2e-smoke.py` (nouveau).

1. **Clé privée de licence** (risque Haute) : elle n'est plus écrite durablement dans le stockage de l'appareil, seulement en mémoire de session (effacée à la fermeture). Pour la réutiliser : « Restaurer » depuis la sauvegarde chiffrée (Espace propriétaire) ou coller `CLE-PRIVEE-ADMIN.txt`. Une clé déjà présente n'est déplacée que si une sauvegarde chiffrée existe (sinon l'Espace propriétaire affiche un avertissement) : jamais de blocage définitif.
2. **Deux parcours de menu** : sélecteur « Tout / Construction / Formation » en haut du menu latéral. Construction masque Formation ; Formation masque Architecture, Ingénierie, Projets et Achats. « Tout » = menu d'origine (par défaut). Choix mémorisé.
3. **Test dans un navigateur** : `python3 tools/e2e-smoke.py` (Chromium) charge l'application et vérifie ces points + le calculateur. `node tools/check.js` reste inchangé (248 contrôles).

## Non fait (nécessite un serveur ou un chantier plus long)
Exécuter les migrations / tester les politiques RLS sur Supabase, 2FA (réglage Supabase), synchronisation de tous les modules, droits et licence appliqués côté serveur, TVA / facture DGI, décomptes, Gantt, SYSCOHADA, barèmes INSS/IPR à confirmer par un expert-comptable. Audit XSS (innerHTML) : non fait, à traiter champ par champ.
Retour en arrière : retirer la balise `exb-keyguard.js` de index.html.

## V99zh — Audit des champs saisis (XSS)
Méthode : analyse automatique des 473 insertions HTML (index.html + 95 scripts) : champs sensibles (noms, notes, titres, clients, messages…) insérés sans fonction d'échappement. La grande majorité était déjà protégée (`esc`, `exbEsc`, `E`, notifications en `textContent`).
Corrigé : journal d'audit (action affichée brute), message de paiement renvoyé par le serveur, libellés des moyens de paiement (V93), et la fonction `esc` de l'index qui n'échappait pas les guillemets (injection possible dans un attribut) ni la valeur 0.
Reste, faible risque : identifiants (`x.id`) placés dans des `onclick` — générés par l'application, mais un fichier importé hostile pourrait en fournir ; à traiter avec la validation des imports. Libellés fixes dans le code (v67/v70/v81/v90) : pas de saisie utilisateur.

## Test de parcours réel (local)
`tools/e2e-smoke.py` se connecte à une copie locale (identifiant par défaut, changement de mot de passe imposé : le test le fait) avec l'écran de licence retiré uniquement dans le test, puis ouvre les 67 entrées du menu : aucune erreur JavaScript. Paie & RH, Finance, Enterprise 360° et d'autres s'ouvrent dans une fenêtre superposée (comportement normal).
Non couvert : saisie de bout en bout (devis → situation → facture → paiement → paie), serveur Supabase.

## V99zi — Validation des imports
Nouveau `exb-importguard.js` (chargé dès le début, dans le cache hors ligne), branché sur les trois restaurations (`importBackup`, `importCompleteBackup`, `exbRestoreFile`/`restore`) :
- un fichier importé ne peut plus écrire les clés de licence (`exb_lic*`), de session, de verrou, d'ouverture de session ni l'identifiant (les mots de passe étaient déjà protégés sur un seul des trois chemins) ; un message indique combien de clés ont été ignorées ;
- les clés `__proto__`, `constructor`, `prototype` sont supprimées ;
- les identifiants (`id`, `*_id`, `*Id`, `key`, `ref`, `matricule`) perdent les caractères `' " < > \` \\ $ { } ( ) ; &` et les retours à la ligne, ce qui ferme le risque restant d'injection via un `onclick`.
Les textes ordinaires ne sont pas modifiés (ils sont échappés à l'affichage). Tests : `tools/e2e-smoke.py` (clés refusées, identifiants nettoyés). Non couvert : import des fiches formateur / participant / client / RH (formulaires JSON) et synchronisation Supabase.
