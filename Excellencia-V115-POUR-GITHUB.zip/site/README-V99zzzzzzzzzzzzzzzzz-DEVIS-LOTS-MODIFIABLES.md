# V99zzzzzzzzzzzzzzzzz — Devis rapide : lot modifiable à tout moment, curseur stable
Fichiers modifiés : `index.html`, `sw.js` (cache renouvelé). `exb-docs.js` : page de garde d'origine conservée. Recharger l'application après mise à jour.

- **Lot** : la case est maintenant une liste déroulante toujours complète (Implantation, Travaux préparatoires, Terrassement, Fondation, Maçonnerie, Béton armé, Charpente et couverture, Menuiserie, Électricité, Plomberie, Carrelage, Peinture, Finitions). On peut passer d'Implantation à Fondation (ou autre) autant de fois que l'on veut. « Autre lot… » permet de saisir un nom libre ; « Aucun lot » retire le lot.
  Avant, la liste ne proposait que les lots qui ressemblaient au texte déjà choisi : une fois « Implantation » choisi, les autres lots n'apparaissaient plus.
- **Curseur** : dans Quantité et PU, le curseur reste dans la case pendant la saisie (le tableau n'est plus reconstruit à chaque chiffre).
