# Audit V99 — Résultats P0 (20 octobre 2026)

## Contrôles locaux
- `node tools/check.js` : 435 réussis, 0 échec (les 5 tests de cache PWA périmés ont été alignés).
- `python3 tools/rls-audit.py` : 64 tables, RLS activée partout, 0 anomalie haute. 1 point moyen à confirmer : `droits_fonction` lisible par tous (`df_lire`).
- `tools/test-rls/run.sh` (PostgreSQL 16 local) : toutes les migrations chargées sans échec ; isolation/droits 43/43 ; validation 28/28 ; TFL/QR 33/33.

## Restauration de la base (testée sur la base de test)
Sauvegarde : `pg_dump -Fc <base> -f sauvegarde.dump`
Restauration : `createdb <nouvelle_base> && pg_restore -d <nouvelle_base> --no-owner sauvegarde.dump`
Résultat du test : 65 tables, 211 politiques, 86 fonctions, 64 tables sous RLS et 5 356 lignes identiques ; empreinte des politiques identique.

## Non couvert (à faire sur l'environnement réel)
- Migrations et RLS sur votre projet Supabase de recette (2 entreprises, plusieurs rôles).
- Pièces jointes (buckets Storage) : à sauvegarder et restaurer séparément.
- Paiement Mobile Money réel, tests Android réel avec réseau faible.
