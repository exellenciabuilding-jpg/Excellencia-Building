# Fusion V101 (emballage) + V103 (site)
- Base : Excellencia-V101 (electron/, native/, scripts/, resources/, tests-obj-ifc43/, fichiers LISEZ-MOI, package.json, capacitor.config.json).
- `site/` : remplacé par le contenu de l'archive V103 (600 fichiers) = V101 + 2 nouveaux fichiers + 11 fichiers mis à jour
  (index, btp, client, personnel, formateur, inscription, demande-tp-td, espace-apprenant, tfl-portail, sw.js, README-V101).
- Aucun fichier de V101 supprimé. Total : 633 fichiers (+ ce fichier et .gitignore).
- Vérifié : `node scripts/build-www.js` produit www/ sans erreur ; tous les .js passent `node --check`.
