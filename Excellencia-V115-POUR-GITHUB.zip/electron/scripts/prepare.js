/* Prépare electron/www : copie du logiciel (../site) sans les documents inutiles + correctif affiches. */
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..', '..'), SRC = path.join(ROOT, 'site'), OUT = path.join(__dirname, '..', 'www');
const SKIP_DIR = new Set(['site-vitrine', 'tools', 'node_modules', '.git']);
const SKIP_FILE = /^(README.*|LISEZ-MOI.*|1-LISEZ-MOI.*|ETUDE-.*|EXCELLENCIA-ARCHITECTURE\.md|_headers|_redirects|sw\.js)$/i;
if (!fs.existsSync(SRC)) { console.error('ERREUR : dossier site/ introuvable (' + SRC + ')'); process.exit(1); }
fs.rmSync(OUT, { recursive: true, force: true });
(function copy(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const e of fs.readdirSync(a, { withFileTypes: true })) {
    if (e.isDirectory()) { if (!SKIP_DIR.has(e.name)) copy(path.join(a, e.name), path.join(b, e.name)); }
    else if (!SKIP_FILE.test(e.name)) fs.copyFileSync(path.join(a, e.name), path.join(b, e.name));
  }
})(SRC, OUT);
/* correctif affiches (même fichier que sur Android) */
fs.copyFileSync(path.join(ROOT, 'native', 'exb-poster-fix.js'), path.join(OUT, 'exb-poster-fix.js'));
const idx = path.join(OUT, 'index.html');
let h = fs.readFileSync(idx, 'utf8');
if (!h.includes('exb-poster-fix.js')) {
  const at = h.toLowerCase().lastIndexOf('</body>');
  if (at < 0) { console.error('ERREUR : </body> introuvable dans index.html'); process.exit(1); }
  h = h.slice(0, at) + '<script src="exb-poster-fix.js"></script>' + h.slice(at);
}
fs.writeFileSync(idx, h);
/* icône de l'installateur */
fs.mkdirSync(path.join(__dirname, '..', 'build'), { recursive: true });
const ic = path.join(SRC, 'icon-512.png');
if (fs.existsSync(ic)) fs.copyFileSync(ic, path.join(__dirname, '..', 'build', 'icon.png'));
console.log('electron/www prêt.');
