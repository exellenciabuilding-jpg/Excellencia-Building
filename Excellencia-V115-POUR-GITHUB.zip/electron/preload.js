/* Excellencia Building — pont sécurisé entre le logiciel (page web) et Windows.
 * Exposé à la page sous le nom « exbDesktop » :
 *  - hello(raison) / helloAvailable() : Windows Hello (empreinte, visage ou code PIN) pour la connexion rapide ;
 *  - print({html,title}) : impression en PDF avec aperçu (la boîte d'impression Windows n'a pas d'aperçu et affichait une page blanche).
 * Le script est chargé dans toutes les fenêtres ET tous les cadres (calcul de structure, éditeur de plans…). */
const { contextBridge, ipcRenderer, webFrame } = require('electron');
contextBridge.exposeInMainWorld('exbDesktop', {
  hello: (reason) => ipcRenderer.invoke('exb:hello', String(reason || 'Excellencia Building')),
  helloAvailable: () => ipcRenderer.invoke('exb:hello-available'),
  print: (o) => ipcRenderer.invoke('exb:print', o),
  isDesktop: true
});
/* window.print() : choix « PDF » ou « Imprimer ». Le PDF copie la page (sans scripts) puis l'imprime dans une fenêtre cachée.
 * Exposé aux pages : window.exbPrintPDF(doc?) et window.exbPrintNative(). Un module peut aussi fixer window.__exbPrintMode='pdf'|'native' pour éviter la question. */
const SHIM = `(function(){if(window.__exbPrintShim)return;window.__exbPrintShim=1;
var orig=window.print.bind(window);
function snap(doc){doc=doc||document;
 var cs=doc.querySelectorAll('canvas'),root=doc.documentElement.cloneNode(true),cc=root.querySelectorAll('canvas');
 for(var i=0;i<cc.length&&i<cs.length;i++){try{var im=document.createElement('img');im.src=cs[i].toDataURL('image/png');im.setAttribute('style',cs[i].getAttribute('style')||'');im.width=cs[i].width;im.height=cs[i].height;im.className=cs[i].className;cc[i].parentNode.replaceChild(im,cc[i])}catch(e){}}
 var src=doc.querySelectorAll('input,textarea,select'),dst=root.querySelectorAll('input,textarea,select');
 for(var j=0;j<dst.length&&j<src.length;j++){var a=src[j],b=dst[j];try{
  if(b.tagName==='TEXTAREA')b.textContent=a.value;
  else if(b.tagName==='SELECT'){for(var k=0;k<b.options.length;k++){if(a.options[k]&&a.options[k].selected)b.options[k].setAttribute('selected','');else b.options[k].removeAttribute('selected')}}
  else if(b.type==='checkbox'||b.type==='radio'){if(a.checked)b.setAttribute('checked','');else b.removeAttribute('checked')}
  else b.setAttribute('value',a.value)}catch(e){}}
 Array.prototype.forEach.call(root.querySelectorAll('script,iframe,base,noscript,#exbPrintChoice'),function(n){n.remove()});
 var head=root.querySelector('head');if(head){var bs=document.createElement('base');bs.href=doc.baseURI||document.baseURI;head.insertBefore(bs,head.firstChild)}
 return '<!DOCTYPE html>'+root.outerHTML}
window.exbPrintPDF=function(doc){doc=doc||document;var D=window.exbDesktop,html;
 if(window.EXBDocPDF&&window.EXBDocPDF.run&&(doc===document)&&(document.getElementById('doc')||document.querySelector('#inl .db')))return window.EXBDocPDF.run();
 var done=function(){try{window.dispatchEvent(new Event('afterprint'))}catch(e){}};
 if(!D||!D.print){orig();return Promise.resolve(false)}
 try{window.dispatchEvent(new Event('beforeprint'));html=snap(doc)}catch(e){orig();return Promise.resolve(false)}
 return D.print({html:html,title:doc.title||document.title||'Document'}).then(function(r){done();if(r&&r.fallback){orig();return false}if(r&&r.error){try{alert('Le PDF n’a pas pu être créé (étape : '+(r.step||'?')+').\\n'+r.error+'\\n\\nUtilisez le bouton « Imprimer » puis choisissez « Microsoft Print to PDF ». Détails : fichier exb-print.log dans le dossier de données de l’application.')}catch(e){}return false}return true},function(err){done();try{alert('Le PDF n’a pas pu être créé : '+(err&&err.message||err))}catch(e){}return false})};
window.exbPrintNative=function(){orig()};
function choose(){
 var old=document.getElementById('exbPrintChoice');if(old)old.remove();
 var o=document.createElement('div');o.id='exbPrintChoice';o.className='no-print';
 o.style.cssText='position:fixed;inset:0;z-index:2147483000;background:rgba(10,20,40,.55);display:grid;place-items:center;font-family:Arial,sans-serif';
 o.innerHTML='<div style="background:#fff;border-radius:14px;padding:20px;width:min(92vw,360px);box-shadow:0 10px 40px #0007"><div style="font:700 17px Arial;color:#12254a;margin-bottom:4px">Que souhaitez-vous faire ?</div><div style="font:13px Arial;color:#6b7a99;margin-bottom:14px">Le PDF est conseillé : vous le voyez, l’enregistrez et l’imprimez ensuite.</div>'
 +'<button data-m="pdf" style="display:block;width:100%;padding:13px;margin-bottom:8px;border:0;border-radius:10px;background:#e8590c;color:#fff;font:700 15px Arial;cursor:pointer">📄 Enregistrer en PDF</button>'
 +'<button data-m="print" style="display:block;width:100%;padding:13px;margin-bottom:8px;border:1px solid #c9d3df;border-radius:10px;background:#f4f7fb;color:#12254a;font:700 15px Arial;cursor:pointer">🖨 Imprimer (boîte Windows)</button>'
 +'<button data-m="x" style="display:block;width:100%;padding:10px;border:0;background:none;color:#6b7a99;font:600 14px Arial;cursor:pointer">Annuler</button></div>';
 function close(){document.removeEventListener('keydown',kd,true);o.remove()}
 function kd(e){if(e.key==='Escape'){e.preventDefault();close()}}
 o.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('button[data-m]');if(!b){if(e.target===o)close();return}var m=b.getAttribute('data-m');close();
  if(m==='pdf')setTimeout(function(){window.exbPrintPDF()},60);else if(m==='print')setTimeout(function(){orig()},60)});
 document.addEventListener('keydown',kd,true);(document.body||document.documentElement).appendChild(o)}
window.print=function(){var m=window.__exbPrintMode;
 if(m==='native')return orig();if(m==='pdf')return window.exbPrintPDF();
 if(window.innerWidth<300||window.innerHeight<200||!document.body)return window.exbPrintPDF();
 choose()};
})();`;
const install = () => { try { webFrame.executeJavaScript(SHIM); } catch (e) {} };
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install); else install();
