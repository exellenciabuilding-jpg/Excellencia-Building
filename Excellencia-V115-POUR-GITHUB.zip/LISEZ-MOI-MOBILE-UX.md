# Excellencia Building — Boutons flottants & touche Retour (V99 mobile-ux)

Nouveaux fichiers (dossier site/) : exb-fab.js, exb-android-nav.js (déjà ajoutés à index.html et sw.js).
Modifiés : index.html (2 balises script + viewport-fit=cover), sw.js, package.json (+ @capacitor/app),
scripts/patch-android.js (clavier adjustResize).

## Boutons flottants
- Glisser un bouton (🤖 🔑 ❓ 🔔 🗄) pour le déplacer ; position mémorisée.
- Maintenir sans bouger (ou clic droit sur PC) : regrouper, réduire en petite icône, remettre en place.
- Paramètres > « Boutons flottants » : mode séparé / regroupé ⊞, petite icône, réinitialiser.
- Ils s'écartent d'un champ de saisie actif et restent dans la zone visible (clavier, rotation).

## Touche / geste Retour (ordre)
clavier > menu boutons > fenêtre flottante > menu latéral > sous-module précédent > confirmation « Quitter ? ».

## À faire pour l'APK
Déposer ce contenu sur GitHub (garder votre clé de signature et votre workflow actuels), puis relancer le build.
`npm install` récupère @capacitor/app ; `cap sync` l'enregistre. Sans ce plugin, la touche Retour garde l'ancien comportement.
