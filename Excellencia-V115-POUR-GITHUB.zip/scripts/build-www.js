/* Copie le logiciel (site/) dans www/ pour Capacitor, sans les documents inutiles dans l'application,
 * et ajoute exb-native.js juste après exb-bigstore.js dans index.html. */
const fs = require('fs'), path = require('path');
const SRC = path.join(__dirname, '..', 'site'), OUT = path.join(__dirname, '..', 'www');
const SKIP_DIR = new Set(['site-vitrine', 'tools', 'node_modules', '.git']);
const SKIP_FILE = /^(README.*|LISEZ-MOI.*|1-LISEZ-MOI.*|ETUDE-.*|EXCELLENCIA-ARCHITECTURE\.md|_headers|_redirects)$/i;
fs.rmSync(OUT, { recursive: true, force: true });
(function copy(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const e of fs.readdirSync(a, { withFileTypes: true })) {
    if (e.isDirectory()) { if (!SKIP_DIR.has(e.name)) copy(path.join(a, e.name), path.join(b, e.name)); }
    else if (!SKIP_FILE.test(e.name)) fs.copyFileSync(path.join(a, e.name), path.join(b, e.name));
  }
})(SRC, OUT);
fs.copyFileSync(path.join(__dirname, '..', 'native', 'exb-native.js'), path.join(OUT, 'exb-native.js'));
const idx = path.join(OUT, 'index.html');
let h = fs.readFileSync(idx, 'utf8');
const tag = '<script src="exb-bigstore.js"></script>';
if (!h.includes(tag)) { console.error('ERREUR : balise exb-bigstore.js introuvable dans index.html'); process.exit(1); }
if (!h.includes('exb-native.js')) h = h.replace(tag, tag + '<script src="exb-native.js"></script>');
/* correctif affiches : chargé en DERNIER (après exb-affiches.js) pour remplacer l'ajustement des textes */
fs.copyFileSync(path.join(__dirname, '..', 'native', 'exb-poster-fix.js'), path.join(OUT, 'exb-poster-fix.js'));
if (!h.includes('exb-poster-fix.js')) {
  if (!h.includes('</body>')) { console.error('ERREUR : </body> introuvable dans index.html'); process.exit(1); }
  /* la DERNIÈRE balise </body> : les précédentes sont dans des chaînes JavaScript du logiciel */
  const at = h.toLowerCase().lastIndexOf('</body>');
  h = h.slice(0, at) + '<script src="exb-poster-fix.js"></script>' + h.slice(at);
}
fs.writeFileSync(idx, h);
console.log('www/ prêt.');
