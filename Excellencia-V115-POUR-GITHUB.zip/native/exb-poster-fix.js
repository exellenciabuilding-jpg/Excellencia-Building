/* Excellencia Building — correctif « affiches » (Android + Windows)
 * 1) Ajustement du texte des affiches : recherche dichotomique (≈ 8 mesures au lieu de 90 par zone) et par petits lots,
 *    pour ne jamais bloquer l'écran du téléphone.
 * 2) Capture des affiches : résolution plafonnée sur téléphone, pause avant le gros calcul (le message s'affiche),
 *    et délai maximum de 60 s : si le rendu ne revient pas, un message d'erreur apparaît au lieu d'un blocage éternel.
 * 3) Export PNG des affiches : écrit directement le fichier (toBlob) sans passer par un texte de plusieurs Mo.
 * Ce fichier est chargé en dernier dans index.html (voir scripts/build-www.js). */
(function (w) {
  'use strict';
  var NATIVE = !!(w.Capacitor && w.Capacitor.isNativePlatform && w.Capacitor.isNativePlatform());
  function tick(ms) { return new Promise(function (r) { setTimeout(r, ms || 0); }); }
  function note(t, k, d) { try { w.notify && w.notify(t, k || 'info', d || 4000); } catch (e) {} }

  /* ---------- 1. ajustement des textes ---------- */
  function over(el) { return el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1; }
  function fitOne(el) {
    var keep = ['justify-content', 'align-items'].map(function (k) { return [k, el.style.getPropertyValue(k), el.style.getPropertyPriority(k)]; });
    try {
      el.style.fontSize = '';
      keep.forEach(function (k) { el.style.setProperty(k[0], 'flex-start', 'important'); });
      var full = parseFloat(getComputedStyle(el).fontSize) || 16;
      if (!over(el)) return;
      var lo = full * 0.45, hi = full;
      el.style.fontSize = lo.toFixed(1) + 'px';
      if (over(el)) return;                       /* même au minimum ça déborde : on garde le minimum */
      for (var i = 0; i < 8; i++) {
        var mid = (lo + hi) / 2;
        el.style.fontSize = mid.toFixed(2) + 'px';
        if (over(el)) hi = mid; else lo = mid;
      }
      el.style.fontSize = lo.toFixed(2) + 'px';
    } finally {
      keep.forEach(function (k) { if (k[1]) el.style.setProperty(k[0], k[1], k[2]); else el.style.removeProperty(k[0]); });
    }
  }
  var timer = 0, gen = 0;
  function run() {
    var my = ++gen, list = [];
    document.querySelectorAll('#posterPaper,.softwarePosterPaper').forEach(function (p) {
      if (!p.offsetWidth) return;
      p.querySelectorAll('.pchip,.sp-overlay').forEach(function (e) { list.push(e); });
    });
    var i = 0;
    (function batch() {
      if (my !== gen) return;                      /* un nouvel appel a pris le relais */
      for (var n = 0; n < 6 && i < list.length; n++, i++) { try { fitOne(list[i]); } catch (e) {} }
      if (i < list.length) setTimeout(batch, 0);
    })();
  }
  w.exbFitPosters = function () { clearTimeout(timer); timer = setTimeout(run, 80); };

  /* ---------- 2. capture (html2canvas local) ---------- */
  var orig = w.html2canvas;
  if (typeof orig === 'function') {
    w.html2canvas = function (el, opts) {
      opts = Object.assign({}, opts || {});
      var W = (el && (el.scrollWidth || el.offsetWidth)) || 1024, H = (el && (el.scrollHeight || el.offsetHeight)) || 1536;
      var maxPx = NATIVE ? 4.5e6 : 1.4e7, s = Number(opts.scale) || 1, cap = Math.sqrt(maxPx / (W * H));
      if (s > cap) s = Math.max(1, cap);
      opts.scale = s;
      var to;
      var guard = new Promise(function (_, rej) { to = setTimeout(function () { rej(new Error('le rendu a dépassé 60 s (page trop lourde pour cet appareil)')); }, 60000); });
      return tick(120).then(function () { return Promise.race([orig.call(w, el, opts), guard]); })
        .then(function (c) { clearTimeout(to); return c; }, function (e) { clearTimeout(to); throw e; });
    };
  }

  /* ---------- 3. export PNG des affiches ---------- */
  function saveBlob(blob, name) {
    if (w.EXBNativeDownload) return w.EXBNativeDownload.save(blob, name);
    var u = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 30000);
    return Promise.resolve();
  }
  function exportImg(paper, name, msgId, okMsg) {
    if (!paper) return Promise.resolve();
    note('⏳ Génération de l’image…', 'info', 3000);
    return w.html2canvas(paper, { scale: 2, backgroundColor: '#ffffff', useCORS: true, logging: false }).then(function (canvas) {
      return new Promise(function (res, rej) {
        canvas.toBlob(function (b) { b ? res(b) : rej(new Error('encodage de l’image impossible')); }, 'image/png');
      }).then(function (blob) { canvas.width = canvas.height = 0; return saveBlob(blob, name); });
    }).then(function () {
      var m = msgId && document.getElementById(msgId); if (m && okMsg) m.innerHTML = '<span class="valid">' + okMsg + '</span>';
    }).catch(function (e) { note('Export de l’affiche impossible : ' + (e && e.message || e), 'error', 9000); });
  }
  w.exportPosterImage = function () { return exportImg(document.getElementById('posterPaper'), 'affiche-excellencia-building.png'); };
  w.exportSoftwarePosterImage = function () { return exportImg(document.getElementById('softwarePosterPaper'), 'affiche-excellencia-building-logiciels.png', 'softwarePosterMsg', '✓ Affiche logiciels exportée en image.'); };
})(window);
