/* Excellencia Building — Accueil : widgets Horloge + Météo (V119g, V121 : dans la bannière bleue)
 * V121 : l'horloge, l'heure, la date et la météo sont désormais dans le panneau bleu de la bannière « Bienvenue dans »,
 *        comme dans le logiciel chantier. (Avant : deux cartes sous la bannière.)
 * Contenu :
 *   🕘 Horloge analogique : les aiguilles tournent en temps réel (heure de l'appareil), date du jour, température actuelle.
 *   ⛅ Météo : ville, température, conditions, min / max du jour, selon la position de l'appareil.
 * Position : GPS de l'appareil (navigator.geolocation) → à défaut, position approximative par l'adresse IP → à défaut, Kinshasa.
 * Appui sur la météo : « Ma position (GPS) » ou choix manuel d'une ville (mémorisé). Le choix manuel peut être annulé à tout moment.
 * Données : Open-Meteo (sans clé), nom de lieu BigDataCloud, position par IP GeoJS. Dernière météo gardée en mémoire : affichée hors connexion.
 * Aucune donnée existante n'est modifiée. Pour retirer : supprimer la balise <script src="exb-home-widgets.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_HOME_WIDGETS) return;
  var K_CACHE = 'exb_wx_cache', K_PLACE = 'exb_wx_place';          /* place : {mode:'auto'} | {mode:'manual', name, lat, lon} */
  var DEFAULT = { name: 'Kinshasa', lat: -4.3276, lon: 15.3136 };
  var REFRESH_MS = 15 * 60 * 1000, STALE_MS = 3 * 60 * 60 * 1000;
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jget(k, df) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? df : v; } catch (e) { return df; } }
  function jset(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  /* ---------- codes météo WMO (Open-Meteo) → libellé + icône + ambiance ---------- */
  function wmo(code, day) {
    var c = Number(code), t;
    if (c === 0) t = [day ? 'Ensoleillé' : 'Ciel dégagé', day ? '☀️' : '🌙', day ? 'clear' : 'night'];
    else if (c === 1) t = [day ? 'Plutôt ensoleillé' : 'Plutôt dégagé', day ? '🌤️' : '🌙', day ? 'clear' : 'night'];
    else if (c === 2) t = ['Partiellement nuageux', day ? '⛅' : '☁️', 'cloud'];
    else if (c === 3) t = ['Couvert', '☁️', 'cloud'];
    else if (c === 45 || c === 48) t = ['Brouillard', '🌫️', 'cloud'];
    else if (c >= 51 && c <= 57) t = ['Bruine', '🌦️', 'rain'];
    else if (c === 61 || c === 80) t = ['Pluie légère', '🌦️', 'rain'];
    else if (c === 63 || c === 81 || c === 66) t = ['Pluie', '🌧️', 'rain'];
    else if (c === 65 || c === 82 || c === 67) t = ['Pluie forte', '🌧️', 'rain'];
    else if (c >= 71 && c <= 77 || c === 85 || c === 86) t = ['Neige', '🌨️', 'cloud'];
    else if (c >= 95 && c <= 99) t = ['Orage', '⛈️', 'storm'];
    else t = ['Variable', '🌥️', 'cloud'];
    return { label: t[0], icon: t[1], mood: t[2] };
  }
  function deg(v) { return v == null || !isFinite(v) ? '–' : Math.round(v) + '°'; }

  /* ---------- angles des aiguilles (pures, testables) ---------- */
  function angles(dt) {
    var s = dt.getSeconds() + dt.getMilliseconds() / 1000, m = dt.getMinutes() + s / 60, h = (dt.getHours() % 12) + m / 60;
    return { h: h * 30, m: m * 6, s: s * 6 };
  }

  /* ---------- état ---------- */
  var wx = jget(K_CACHE, null);   /* {name, lat, lon, temp, code, day, min, max, at} */
  var busy = false, panel = false, lastNote = '', timerWx = 0;
  function place() { var p = jget(K_PLACE, null); return p && p.mode === 'manual' && isFinite(p.lat) && isFinite(p.lon) ? p : { mode: 'auto' }; }

  /* ---------- réseau ---------- */
  function jfetch(url, ms) {
    return new Promise(function (ok, ko) {
      var done = false, ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      var to = setTimeout(function () { if (!done) { done = true; if (ctl) ctl.abort(); ko(new Error('délai dépassé')); } }, ms || 9000);
      w.fetch(url, ctl ? { signal: ctl.signal } : {}).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (j) { if (!done) { done = true; clearTimeout(to); ok(j); } }, function (e) { if (!done) { done = true; clearTimeout(to); ko(e); } });
    });
  }
  function gps() {
    return new Promise(function (ok, ko) {
      if (!w.navigator || !w.navigator.geolocation) return ko(new Error('GPS indisponible'));
      w.navigator.geolocation.getCurrentPosition(function (p) { ok({ lat: p.coords.latitude, lon: p.coords.longitude, src: 'gps' }); },
        function (e) { ko(new Error(e && e.code === 1 ? 'GPS refusé' : 'GPS indisponible')); }, { enableHighAccuracy: false, timeout: 9000, maximumAge: 10 * 60 * 1000 });
    });
  }
  function byIp() {
    return jfetch('https://get.geojs.io/v1/ip/geo.json', 7000).then(function (j) {
      var la = parseFloat(j.latitude), lo = parseFloat(j.longitude);
      if (!isFinite(la) || !isFinite(lo)) throw new Error('IP sans position');
      return { lat: la, lon: lo, src: 'ip', name: j.city || '' };
    });
  }
  function placeName(lat, lon) {
    return jfetch('https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=' + lat + '&longitude=' + lon + '&localityLanguage=fr', 7000).then(function (j) {
      return String(j.city || j.locality || j.principalSubdivision || '').trim();
    });
  }
  function forecast(lat, lon) {
    var u = 'https://api.open-meteo.com/v1/forecast?latitude=' + lat.toFixed(4) + '&longitude=' + lon.toFixed(4) +
      '&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1';
    return jfetch(u, 10000).then(function (j) {
      if (!j || !j.current) throw new Error('réponse météo vide');
      return { temp: j.current.temperature_2m, code: j.current.weather_code, day: j.current.is_day !== 0,
        min: j.daily && j.daily.temperature_2m_min ? j.daily.temperature_2m_min[0] : null, max: j.daily && j.daily.temperature_2m_max ? j.daily.temperature_2m_max[0] : null };
    });
  }
  function locate() {
    var p = place();
    if (p.mode === 'manual') return Promise.resolve({ lat: p.lat, lon: p.lon, name: p.name, src: 'manuel' });
    return gps().catch(function (e) { lastNote = e.message; return byIp(); }).catch(function () { lastNote = (lastNote ? lastNote + ' · ' : '') + 'position approximative indisponible'; return { lat: DEFAULT.lat, lon: DEFAULT.lon, name: DEFAULT.name, src: 'défaut' }; });
  }

  function refresh(force) {
    if (busy) return Promise.resolve();
    if (!force && wx && Date.now() - wx.at < REFRESH_MS && sameTarget()) { paint(); return Promise.resolve(); }
    busy = true; paint();
    return locate().then(function (loc) {
      var nm = loc.name ? Promise.resolve(loc.name) : placeName(loc.lat, loc.lon).catch(function () { return ''; });
      return Promise.all([forecast(loc.lat, loc.lon), nm]).then(function (r) {
        wx = { name: r[1] || (loc.src === 'gps' ? 'Ma position' : DEFAULT.name), lat: loc.lat, lon: loc.lon, src: loc.src, temp: r[0].temp, code: r[0].code, day: r[0].day, min: r[0].min, max: r[0].max, at: Date.now() };
        jset(K_CACHE, wx); if (loc.src === 'gps' || loc.src === 'manuel') lastNote = '';
      });
    }).catch(function (e) { lastNote = 'Hors connexion' + (wx ? ' · dernière mise à jour ' + hhmm(wx.at) : ''); }).then(function () { busy = false; paint(); });
  }
  function sameTarget() { var p = place(); return !(p.mode === 'manual') || (wx && Math.abs(wx.lat - p.lat) < 0.01 && Math.abs(wx.lon - p.lon) < 0.01); }
  function hhmm(t) { var x = new Date(t); return pad(x.getHours()) + ':' + pad(x.getMinutes()); }

  /* ---------- horloge ---------- */
  function ticks() {
    var s = '', i, a, big, x1, y1, x2, y2, r2;
    for (i = 0; i < 60; i++) {
      big = i % 5 === 0; a = i * 6 * Math.PI / 180; r2 = big ? 86 : 91;
      x1 = 100 + Math.sin(a) * 96; y1 = 100 - Math.cos(a) * 96; x2 = 100 + Math.sin(a) * r2; y2 = 100 - Math.cos(a) * r2;
      s += '<line x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '" stroke="' + (big ? '#1b2540' : '#9aa6bd') + '" stroke-width="' + (big ? 2.4 : 1) + '" stroke-linecap="round"/>';
    }
    for (i = 1; i <= 12; i++) { a = i * 30 * Math.PI / 180; s += '<text x="' + (100 + Math.sin(a) * 71).toFixed(1) + '" y="' + (100 - Math.cos(a) * 71 + 6).toFixed(1) + '" text-anchor="middle" font-size="17" font-weight="700" fill="#1b2540" font-family="Arial,Helvetica,sans-serif">' + i + '</text>'; }
    return s;
  }
  function clockHtml() {
    return '<div class="hw-clock" role="img" id="hwClockImg" aria-label="Horloge">' +
      '<svg viewBox="0 0 200 200" aria-hidden="true"><circle cx="100" cy="100" r="99" fill="#fbfaf6"/>' + ticks() +
      '<g id="hwDate"><rect x="38" y="91" width="50" height="18" rx="9" fill="#e4e1d6"/><text id="hwDateT" x="63" y="103.5" text-anchor="middle" font-size="10.5" font-weight="700" fill="#4a4f5e" font-family="Arial,Helvetica,sans-serif"></text></g>' +
      '<text id="hwClockWx" x="100" y="146" text-anchor="middle" font-size="13" font-weight="700" fill="#4a4f5e" font-family="Arial,Helvetica,sans-serif"></text>' +
      '<g id="hwH"><line x1="100" y1="106" x2="100" y2="56" stroke="#1b2540" stroke-width="6" stroke-linecap="round"/></g>' +
      '<g id="hwM"><line x1="100" y1="110" x2="100" y2="30" stroke="#1b2540" stroke-width="4.2" stroke-linecap="round"/></g>' +
      '<g id="hwS"><line x1="100" y1="118" x2="100" y2="22" stroke="#f26b1d" stroke-width="2" stroke-linecap="round"/></g>' +
      '<circle cx="100" cy="100" r="5" fill="#f26b1d"/><circle cx="100" cy="100" r="2" fill="#fbfaf6"/></svg></div>';
  }
  var lastMin = -1, lastDay = -1;
  function tick() {
    var dt = new Date(), a = angles(dt), h = $('hwH'), m = $('hwM'), s = $('hwS');
    if (!h || !m || !s) return;
    h.setAttribute('transform', 'rotate(' + a.h.toFixed(2) + ' 100 100)');
    m.setAttribute('transform', 'rotate(' + a.m.toFixed(2) + ' 100 100)');
    s.setAttribute('transform', 'rotate(' + a.s.toFixed(2) + ' 100 100)');
    if (dt.getMinutes() !== lastMin) {
      lastMin = dt.getMinutes();
      var tm = $('hwTime'); if (tm) tm.textContent = pad(dt.getHours()) + ':' + pad(lastMin);
      var im = $('hwClockImg'); if (im) im.setAttribute('aria-label', 'Il est ' + dt.getHours() + ' h ' + pad(lastMin));
    }
    if (dt.getDate() !== lastDay) {
      lastDay = dt.getDate(); var t = $('hwDateT');
      var dl = $('hwDateL'); if (dl) dl.textContent = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'][dt.getDay()] + ' ' + dt.getDate() + ' ' + ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'][dt.getMonth()];
      if (t) { var mo = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'][dt.getMonth()]; t.textContent = dt.getDate() + ' ' + mo; }
    }
  }

  /* ---------- météo : peinture ---------- */
  function paint() {
    var box = $('exbHomeWidgets'); if (!box) return;
    var cw = $('hwClockWx'); if (cw) cw.textContent = wx ? deg(wx.temp) : '';
    var card = $('hwWx'); if (!card) return;
    var info = wx ? wmo(wx.code, wx.day) : null, stale = wx && Date.now() - wx.at > STALE_MS;
    card.className = 'hw-wx hw-' + (info ? info.mood : 'cloud');
    var h;
    if (panel) h = panelHtml();
    else if (wx) {
      h = '<div class="hw-city">' + (wx.src === 'gps' ? '📍 ' : '') + esc(wx.name) + '</div>' +
        '<div class="hw-temp">' + deg(wx.temp) + '<span class="hw-ic">' + info.icon + '</span></div>' +
        '<div class="hw-cond">' + esc(info.label) + '</div>' +
        '<div class="hw-mm">' + deg(wx.min) + '/' + deg(wx.max) + '</div>' +
        (busy ? '<div class="hw-note">Actualisation…</div>' : (lastNote || stale) ? '<div class="hw-note">' + esc(lastNote || ('Données de ' + hhmm(wx.at))) + '</div>' : '');
    } else h = '<div class="hw-city">Météo</div><div class="hw-cond" style="margin-top:14px">' + (busy ? 'Recherche de votre position…' : esc(lastNote || 'Appuyez pour choisir une ville')) + '</div>';
    card.innerHTML = h;
  }
  function panelHtml() {
    var p = place();
    return '<div class="hw-city">Position de la météo</div>' +
      '<button class="hw-b' + (p.mode === 'auto' ? ' on' : '') + '" data-hw="gps">📍 Ma position (GPS)</button>' +
      '<div class="hw-search"><input id="hwQ" type="search" placeholder="Autre ville…" autocomplete="off" aria-label="Rechercher une ville"><button class="hw-b" data-hw="find">OK</button></div>' +
      '<div id="hwRes"></div>' + (p.mode === 'manual' ? '<div class="hw-note">Ville fixée : ' + esc(p.name) + '</div>' : '') +
      '<button class="hw-x" data-hw="close">Fermer</button>';
  }
  function search() {
    var q = ($('hwQ') || {}).value || '', res = $('hwRes'); q = q.trim(); if (!res || q.length < 2) return;
    res.innerHTML = '<div class="hw-note">Recherche…</div>';
    jfetch('https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(q) + '&count=5&language=fr&format=json', 8000).then(function (j) {
      var r = (j && j.results) || [];
      if (!r.length) { res.innerHTML = '<div class="hw-note">Aucune ville trouvée</div>'; return; }
      res.innerHTML = r.map(function (c, i) { return '<button class="hw-b" data-hw="pick" data-i="' + i + '">' + esc(c.name) + (c.admin1 ? ', ' + esc(c.admin1) : '') + ' <small>' + esc(c.country_code || '') + '</small></button>'; }).join('');
      res._r = r;
    }, function () { res.innerHTML = '<div class="hw-note">Recherche impossible (hors connexion ?)</div>'; });
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-hw]') : null, card = $('hwWx');
    if (!b) { if (card && card.contains(e.target) && !panel) { panel = true; paint(); } return; }
    var a = b.getAttribute('data-hw');
    if (a === 'close') { panel = false; paint(); }
    else if (a === 'gps') { jset(K_PLACE, { mode: 'auto' }); lastNote = ''; panel = false; wx = null; refresh(true); }
    else if (a === 'find') search();
    else if (a === 'pick') {
      var c = ($('hwRes') || {})._r; c = c && c[Number(b.getAttribute('data-i'))]; if (!c) return;
      jset(K_PLACE, { mode: 'manual', name: c.name, lat: c.latitude, lon: c.longitude }); lastNote = ''; panel = false; wx = null; refresh(true);
    }
  }

  /* ---------- installation ---------- */
  function css() {
    if ($('exbHomeWidgetsCss')) return;
    var s = d.createElement('style'); s.id = 'exbHomeWidgetsCss';
    s.textContent =
      '#exbHomeWidgets{position:relative;z-index:3;align-self:center;display:flex;align-items:center;gap:16px;margin:16px 270px 16px 0;padding:14px 16px;box-sizing:border-box;border-radius:16px;background:#0a1b45;border:1px solid #ffffff1f;box-shadow:0 10px 26px #0006;font-family:Arial,Helvetica,sans-serif;color:#fff}' +
      '.hw-cw{flex:none;width:136px}.hw-clock{width:136px;height:136px}.hw-clock svg{width:100%;height:100%;display:block;border-radius:50%;box-shadow:0 2px 10px #0008}' +
      '.hw-side{display:flex;flex-direction:column;gap:3px;min-width:200px;max-width:260px}' +
      '.hw-time{font-size:38px;font-weight:700;line-height:1.05;letter-spacing:1px;font-variant-numeric:tabular-nums}' +
      '.hw-date{font-size:14px;color:#dbe6ff;margin-bottom:6px}' +
      '.hw-wx{padding:9px 12px;border-radius:12px;color:#fff;cursor:pointer;display:flex;flex-direction:column;gap:1px;position:relative;text-align:left;border:1px solid #ffffff2e}' +
      '.hw-clear{background:linear-gradient(160deg,#2f8be0,#1a5bb0)}.hw-night{background:linear-gradient(160deg,#27386b,#101a3a)}' +
      '.hw-cloud{background:linear-gradient(160deg,#6d86a8,#475c7c)}.hw-rain{background:linear-gradient(160deg,#6f86a1,#4a6079)}.hw-storm{background:linear-gradient(160deg,#4a4f6b,#2a2d44)}' +
      '.hw-city{font-size:13px;font-weight:700;opacity:.95;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
      '.hw-temp{font-size:30px;font-weight:700;line-height:1.1;display:flex;align-items:center;gap:8px}.hw-ic{font-size:22px}' +
      '.hw-cond{font-size:13px;font-weight:600}.hw-mm{font-size:12px;opacity:.88}' +
      '.hw-note{font-size:11px;opacity:.85;margin-top:3px}' +
      '.hw-b{display:block;width:100%;min-height:34px;margin-top:6px;padding:6px 10px;border:1px solid #ffffff66;border-radius:10px;background:#ffffff26;color:#fff;font:700 13px Arial;text-align:left;cursor:pointer}' +
      '.hw-b.on{background:#ffffff59}.hw-b small{opacity:.8}.hw-b:focus-visible,.hw-x:focus-visible,#hwQ:focus-visible,.hw-wx:focus-visible{outline:2px solid #fff;outline-offset:2px}' +
      '.hw-search{display:flex;gap:6px;margin-top:6px}.hw-search .hw-b{width:auto;margin:0;text-align:center}' +
      '#hwQ{flex:1;min-width:0;min-height:34px;border:0;border-radius:10px;padding:0 10px;font:14px Arial;color:#12254a}' +
      '.hw-x{margin-top:8px;border:0;background:none;color:#fff;font:700 12px Arial;text-decoration:underline;cursor:pointer;align-self:flex-start;padding:6px 0}' +
      /* écrans moyens : le panneau passe sous le texte de bienvenue */
      '@media(max-width:1500px){.xh-hero:has(#exbHomeWidgets){flex-direction:column;min-height:0}.xh-hero:has(#exbHomeWidgets) .xh-hl{flex:none}.xh-hero:has(#exbHomeWidgets) .xh-tag{position:relative;right:auto;bottom:auto;margin:0 26px 18px;max-width:none;z-index:3}#exbHomeWidgets{align-self:flex-start;margin:0 26px 16px}}' +
      '@media(max-width:600px){#exbHomeWidgets{align-self:stretch;margin:0 14px 14px;flex-wrap:wrap;justify-content:center;gap:10px}.hw-cw,.hw-clock{width:112px;height:112px}.hw-side{min-width:0;flex:1 1 150px;max-width:none}.hw-time{font-size:32px}}' +
      '@media print{#exbHomeWidgets{display:none}}';
    d.head.appendChild(s);
  }
  var iv = 0;
  function install() {
    var home = $('exbHome'), hero = home && home.querySelector('.xh-hero'), hl = hero && hero.querySelector('.xh-hl');
    if (!home || !hero || !hl || $('exbHomeWidgets')) return !!$('exbHomeWidgets');
    css();
    var box = d.createElement('div'); box.id = 'exbHomeWidgets'; box.className = 'no-print';
    box.innerHTML = '<div class="hw-cw">' + clockHtml() + '</div><div class="hw-side"><div class="hw-time" id="hwTime"></div><div class="hw-date" id="hwDateL"></div>' +
      '<div class="hw-wx hw-cloud" id="hwWx" role="button" tabindex="0" aria-label="Météo — appuyer pour changer de position"></div></div>';
    hl.parentNode.insertBefore(box, hl.nextSibling);
    box.addEventListener('click', onClick);
    box.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target.id === 'hwWx' && !panel) { e.preventDefault(); panel = true; paint(); } if (e.key === 'Enter' && e.target.id === 'hwQ') search(); });
    lastMin = lastDay = -1; tick(); paint(); refresh(false);
    /* les aiguilles ne tournent que si l'accueil est visible et l'application au premier plan */
    iv = setInterval(function () { if (!d.hidden && home.style.display !== 'none') tick(); }, 250);
    clearInterval(timerWx); timerWx = setInterval(function () { if (!d.hidden) refresh(false); }, 60 * 1000);
    d.addEventListener('visibilitychange', function () { if (!d.hidden) { tick(); refresh(false); } });
    w.addEventListener('online', function () { lastNote = ''; refresh(true); });
    try { new MutationObserver(function () { if (home.style.display !== 'none') { tick(); refresh(false); } }).observe(home, { attributes: true, attributeFilter: ['style'] }); } catch (e) {}
    return true;
  }
  function boot() { var n = 0, t = setInterval(function () { if (install() || ++n > 120) clearInterval(t); }, 500); }
  w.EXB_HOME_WIDGETS = { version: 'V121', refresh: function () { return refresh(true); }, _wmo: wmo, _angles: angles };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
