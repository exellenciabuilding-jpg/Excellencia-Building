/* Excellencia Building — V121 : modules déplaçables directement (glisser-déposer, comme les applications d'un téléphone Android)
 * Sur l'accueil (bandeau, chiffres clés, graphique, activité, accès rapide, blocs « À faire / Reprendre ») et dans les pages de catégories (tuiles de modules) :
 *   - souris : cliquer, garder le clic et glisser ;   - doigt : maintenir ~0,4 s puis glisser ;   - Échap : annule.
 * L'ordre est mémorisé sur l'appareil. Compatible avec « 🧩 Organiser » (même mémoire pour les grands blocs : exb_home_layout_v1).
 * Autres mémoires : exb_home_dnd_v1 (cartes de chiffres, raccourcis, blocs du bas, tuiles de catégories).
 * Aucune donnée métier n'est modifiée. Pour retirer : supprimer la balise <script src="exb-home-dnd.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_HOME_DND) return;
  var HK = 'exb_home_layout_v1', DK = 'exb_home_dnd_v1';
  var $ = function (i) { return d.getElementById(i); };
  function jget(k, df) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? df : v; } catch (e) { return df; } }
  function jset(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function txt(el, sel) { var n = sel ? el.querySelector(sel) : el; return n ? String(n.textContent || '').replace(/\s+/g, ' ').trim() : ''; }
  function hubName() { var h = $('exbHub'); return h ? txt(h, 'h1') : ''; }

  /* Groupes, du plus petit (tuile) au plus grand (bloc) : le plus petit sous le pointeur est celui qui bouge. */
  var GR = [
    { id: 'xk', box: '#xhK', kid: '.xh-k', key: function (e) { return txt(e, 'small').replace(/Voir tout.*$/, '').trim(); } },
    { id: 'qa', box: '#xhQA', kid: '.q', key: function (e) { return txt(e, 'b'); } },
    { id: 'hp', box: '#exbHomePro', kid: '.hp', key: function (e) { return txt(e, 'h3 span'); } },
    { id: 'hub', box: '.xg', kid: '.c', key: function (e) { return txt(e, 'b'); }, scope: hubName },
    { id: 'cols', box: '.xh-cols', kid: '.xh-card', key: function (e) { return e.getAttribute('data-hk') || (e.querySelector('#xhChart') ? 'chart' : 'act'); }, hk: true },
    { id: 'top', box: '#exbHome', kid: '[data-hk]', key: function (e) { return e.getAttribute('data-hk'); }, hk: true, skip: { head: 1, pick: 1 } }
  ];
  function okKid(g, el) { return !(g.skip && g.skip[el.getAttribute('data-hk')]); }

  /* ---------- mémoire ---------- */
  function order(g, box) {
    if (g.hk) { var S = jget(HK, {}); return S[g.id] || []; }
    var D = jget(DK, {}); return g.scope ? ((D[g.id] || {})[g.scope()] || []) : (D[g.id] || []);
  }
  function remember(g, box) {
    if (g.hk) { var S = jget(HK, { top: [], cols: [], hid: [] }); S[g.id] = [].slice.call(box.children).map(function (c) { return c.getAttribute('data-hk'); }).filter(Boolean); jset(HK, S); return; }
    var keys = kids(g, box).map(g.key);
    var D = jget(DK, {});
    if (g.scope) { D[g.id] = D[g.id] || {}; D[g.id][g.scope()] = keys; } else D[g.id] = keys;
    jset(DK, D);
  }
  function kids(g, box) { return [].slice.call(box.children).filter(function (c) { return c.matches && c.matches(g.kid) && okKid(g, c); }); }

  /* ---------- remise en ordre après chaque rafraîchissement de l'accueil / du hub ---------- */
  var applying = false;
  function applyOne(g, box) {
    var ks = kids(g, box); if (ks.length < 2) return;
    var ord = order(g, box); if (!ord.length) return;
    var cur = ks.map(g.key), want = ord.filter(function (k) { return cur.indexOf(k) >= 0; }).concat(cur.filter(function (k) { return ord.indexOf(k) < 0; }));
    if (want.join('\u0001') === cur.join('\u0001')) return;
    var anchor = null, last = ks[ks.length - 1]; anchor = last.nextSibling;
    want.forEach(function (k) { var el = ks[cur.indexOf(k)]; box.insertBefore(el, anchor); });
  }
  function applyAll() {
    if (applying || drag) return; applying = true;
    try { GR.forEach(function (g) { if (g.hk) return; /* grands blocs : appliqués par exb-ux-v100 */ d.querySelectorAll(g.box).forEach(function (b) { applyOne(g, b); }); }); } catch (e) {}
    applying = false;
  }
  var tm0 = 0;
  function watch() {
    ['exbHome', 'exbHub'].forEach(function (id) {
      var n = $(id); if (!n || n.__dnd) return; n.__dnd = 1;
      try { new MutationObserver(function () { if (applying) return; clearTimeout(tm0); tm0 = setTimeout(applyAll, 60); }).observe(n, { childList: true, subtree: true }); } catch (e) {}
    });
    applyAll();
  }

  /* ---------- glisser-déposer ---------- */
  var S = null, P = null, tm = null, suppress = 0, drag = null;
  function bad(t) { return t.closest('input,select,textarea,[contenteditable="true"],.xhe-bar,#xheTop,.hw-search,#hwRes,.no-drag'); }
  function find(t) {
    if (!t || !t.closest || bad(t) || d.documentElement.classList.contains('exb-home-edit')) return null;
    for (var i = 0; i < GR.length; i++) {
      var g = GR[i], k = t.closest(g.kid);
      while (k) {
        var p = k.parentNode;
        if (p && p.matches && p.matches(g.box) && okKid(g, k) && kids(g, p).length > 1 && (g.id !== 'top' || $('exbHome').offsetParent)) return { el: k, box: p, g: g };
        k = k.parentNode && k.parentNode.closest ? k.parentNode.closest(g.kid) : null;
      }
    }
    return null;
  }
  function begin() {
    var r = P.el.getBoundingClientRect();
    S = { el: P.el, box: P.box, g: P.g, id: P.id, dx: P.x - r.left, dy: P.y - r.top, orig: [].slice.call(P.box.children) };
    var gh = P.el.cloneNode(true); gh.removeAttribute('id');
    [].forEach.call(gh.querySelectorAll('[id]'), function (n) { n.removeAttribute('id'); });
    gh.classList.add('dnd-ghost');
    gh.style.cssText = 'position:fixed;left:0;top:0;width:' + r.width + 'px;height:' + r.height + 'px;z-index:99999;pointer-events:none;margin:0;transform:translate(' + r.left + 'px,' + r.top + 'px) scale(1.02) rotate(.8deg)';
    d.body.appendChild(gh); S.gh = gh; drag = S;
    P.el.classList.add('dnd-src'); d.body.classList.add('dnd-on');
    try { w.navigator.vibrate && w.navigator.vibrate(12); } catch (e) {}
  }
  function move(x, y) {
    S.gh.style.transform = 'translate(' + (x - S.dx) + 'px,' + (y - S.dy) + 'px) scale(1.02) rotate(.8deg)';
    if (y < 90) w.scrollBy(0, -18); else if (y > w.innerHeight - 90) w.scrollBy(0, 18);
    var hit = null, ks = kids(S.g, S.box);
    for (var i = 0; i < ks.length; i++) {
      var c = ks[i]; if (c === S.el || c.offsetParent === null) continue;
      var r = c.getBoundingClientRect(); if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) { hit = c; break; }
    }
    if (!hit) return;
    var all = [].slice.call(S.box.children), a = all.indexOf(S.el), b = all.indexOf(hit);
    S.box.insertBefore(S.el, a < b ? hit.nextSibling : hit);
  }
  function end(ok) {
    clearTimeout(tm); tm = null; var was = S; S = null; P = null; drag = null;
    d.body.classList.remove('dnd-on'); if (!was) return;
    was.gh.remove(); was.el.classList.remove('dnd-src');
    if (!ok) { was.orig.forEach(function (c) { was.box.appendChild(c); }); return; }
    suppress = Date.now() + 400; remember(was.g, was.box);
    try { w.localStorage.setItem('exb_home_dnd_seen', '1'); } catch (e) {} hint();
  }
  d.addEventListener('pointerdown', function (e) {
    if (S || (e.pointerType === 'mouse' && e.button !== 0)) return;
    var f = find(e.target); if (!f) return;
    P = { el: f.el, box: f.box, g: f.g, id: e.pointerId, x: e.clientX, y: e.clientY, touch: e.pointerType !== 'mouse' };
    if (P.touch) tm = setTimeout(function () { if (P && !S) begin(); }, 400);
  });
  d.addEventListener('pointermove', function (e) {
    if (S) { if (e.pointerId !== S.id) return; e.preventDefault(); move(e.clientX, e.clientY); return; }
    if (!P || e.pointerId !== P.id) return;
    var dd = Math.hypot(e.clientX - P.x, e.clientY - P.y);
    if (P.touch) { if (dd > 9) { clearTimeout(tm); P = null; } } else if (dd > 6) { begin(); move(e.clientX, e.clientY); }
  }, { passive: false });
  function up(ok) { return function (e) { if ((S && e.pointerId === S.id) || (P && e.pointerId === P.id)) { if (S) end(ok); else { clearTimeout(tm); P = null; } } }; }
  d.addEventListener('pointerup', up(true)); d.addEventListener('pointercancel', up(false));
  d.addEventListener('touchmove', function (e) { if (S) e.preventDefault(); }, { passive: false });
  d.addEventListener('click', function (e) { if (Date.now() < suppress) { e.preventDefault(); e.stopPropagation(); } }, true);
  d.addEventListener('dragstart', function (e) { var t = e.target; if (t && t.closest && !d.documentElement.classList.contains('exb-home-edit') && t.closest('#exbHome,.xg')) e.preventDefault(); }, true);
  d.addEventListener('contextmenu', function (e) { if (S || (P && P.touch)) e.preventDefault(); });
  d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && S) end(false); });

  /* ---------- astuce + remise à zéro ---------- */
  function hint() {
    var h = $('exbHome'), head = h && h.querySelector('.xh-head'), n = $('xhDndHint');
    if (!h || !head) return;
    if (!n) {
      n = d.createElement('div'); n.id = 'xhDndHint'; n.className = 'no-print';
      n.innerHTML = '<span>↕ Astuce : maintenez et glissez n’importe quel module pour le déplacer (souris ou doigt).</span><button type="button" id="xhDndReset">↺ Disposition d’origine</button>';
      head.parentNode.insertBefore(n, head.nextSibling);
      n.querySelector('button').addEventListener('click', function () {
        if (!w.confirm('Remettre l’accueil dans sa disposition d’origine ?')) return;
        try { w.localStorage.removeItem(DK); var S0 = jget(HK, {}); delete S0.top; delete S0.cols; jset(HK, S0); } catch (e) {} w.location.reload();
      });
    }
    n.classList.toggle('seen', !!w.localStorage.getItem('exb_home_dnd_seen'));
  }

  function css() {
    if ($('exbHomeDndCss')) return;
    var s = d.createElement('style'); s.id = 'exbHomeDndCss';
    s.textContent =
      '#xhDndHint{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 10px;font:12px Arial;color:#6b7a99}#xhDndHint button{border:0;background:none;color:#1f6feb;font:600 12px Arial;cursor:pointer;padding:4px 6px;text-decoration:underline}#xhDndHint.seen span{opacity:.7}' +
      'html:not(.exb-home-edit) #exbHome .xh-hero,html:not(.exb-home-edit) #exbHome>.xh-card,html:not(.exb-home-edit) .xh-cols>.xh-card,html:not(.exb-home-edit) #exbHomePro .hp{cursor:grab;-webkit-touch-callout:none}' +
      '#exbHome .xh-btn,#exbHome .xh-k,#exbHome .q,.xg .c,#hwWx{cursor:pointer}' +
      '#exbHome *,.xg *{-webkit-user-drag:none}' +
      'body.dnd-on{user-select:none;-webkit-user-select:none}body.dnd-on,body.dnd-on *{cursor:grabbing!important}' +
      '.dnd-src{opacity:.35;outline:2px dashed #c8962e;outline-offset:3px;border-radius:14px}' +
      '.dnd-ghost{opacity:.93;box-shadow:0 16px 38px #0f2a5a66;border-radius:14px;overflow:hidden}' +
      '@media print{#xhDndHint{display:none}}';
    d.head.appendChild(s);
  }
  function start() { css(); hint(); watch(); }
  w.EXB_HOME_DND = { version: 'V121', apply: applyAll };
  function boot() { var n = 0, t = setInterval(function () { start(); if (($('exbHome') && $('exbHub') && $('xhDndHint')) || ++n > 60) clearInterval(t); }, 500); setInterval(function () { hint(); watch(); }, 3000); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
