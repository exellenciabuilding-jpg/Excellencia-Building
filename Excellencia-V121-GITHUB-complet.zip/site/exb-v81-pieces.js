/* Excellencia Building V119 — Pièces écrites : CCTP, CCAP, lettres, comptes rendus, ordres de service, procès-verbaux,
 * attestations, contrats, notes/rapports et TEXTES LIBRES.
 * - Bibliothèque de modèles (exb-v81-pieces-modeles.js) pré-remplis avec projet, client, maître d’ouvrage, lieu, phase, société, DG…
 * - Chaque texte reste entièrement modifiable ; « Texte libre » pour écrire autre chose ; « Mes modèles » pour réutiliser ses propres textes.
 * - PDF OFFICIEL Excellencia Building : en-tête (logo, nom, slogan, contacts) répété sur chaque page, pied de page (mentions légales, pagination),
 *   bloc de signature du Directeur Général avec signature + cachet lorsque la pièce est « émise » ou « signée ».
 * Stockage : exb_pieces (collection « pieces »). Les modèles personnels y sont rangés avec modele:true (sans projet). */
(function(w,d){'use strict';var C=w.EXB81,KEY='exb_pieces',COL='pieces',st={pid:'',type:'',id:'',cands:[],ct:''};
var D=w.EXBPIE_DATA||{types:{cctp:['CCTP','Cahier des clauses techniques particulières','📐'],ccap:['CCAP','CCAP','📑'],lettre:['LTR','Lettre','✉️'],cr:['CR','Compte rendu de réunion','🗒️'],os:['OS','Ordre de service','📣']},lots:{},ccap:{},models:{},sign:{}};
var TY=D.types,ST=['brouillon','émis','signé'];
var VARS=[['projet','Projet'],['client','Client'],['moa','Maître d’ouvrage'],['lieu','Lieu'],['permis','N° de permis'],['phase','Phase'],['entreprise','Entreprise'],['lot','Lot'],['objet','Objet'],['date','Date'],['date_effet','Date d’effet'],['no','N° de la pièce'],['societe','Notre société'],['dg','Nom du DG'],['dg_role','Fonction du DG'],['ville','Ville'],['tel','Téléphone'],['email','E-mail'],['adresse','Adresse']];
function L(){return w.EXBS.get(KEY)}function S(a){return w.EXBS.set(KEY,a)}
function canW(){return C.can(COL,'ecrire')}
function pieces(){return L().filter(function(x){return !x.modele})}
function mine(){return L().filter(function(x){return x.modele})}
function ty(t){return TY[t]||[String(t||'?').toUpperCase().slice(0,3),String(t||'Pièce'),'📄']}
function ID(){try{return (w.EXBId&&w.EXBId.get())||{}}catch(e){return {}}}
function vars(p,keep){var c=C.cart(p.project),I=ID(),B=keep?'':'____________';return{projet:C.pn(p.project),client:c.client||'',moa:c.moa||c.client||'',lieu:c.lieu||'',permis:c.permis||'',societe:I.name||C.brand(),
 societe_rep:(I.name||C.brand())+(I.dg?' (représentée par '+I.dg+', '+(I.dgRole||'Directeur Général')+')':''),phase:C.phase(p.project)||'—',date:C.frDate(p.date),date_effet:C.frDate(p.effet)||(keep?'':'___/___/____'),
 entreprise:p.entreprise||B,lot:p.lot||B,objet:p.objet||B,no:p.no||(keep?'':'___'),destinataire:p.dest||'',
 dg:I.dg||'',dg_role:I.dgRole||'Directeur Général',ville:I.city||B,tel:I.phone||'',email:I.email||'',adresse:I.address||'',tagline:I.tagline||'',pays:I.country||''}}
function fill(s,v){return String(s).replace(/\{\{(\w+)\}\}/g,function(m,k){return v[k]!=null&&v[k]!==''?v[k]:m})}
function nextNo(t){var y=new Date().getFullYear(),p=ty(t)[0]+'-'+y,n=pieces().filter(function(x){return x.type===t&&String(x.no||'').indexOf(p)===0}).length+1;return p+'-'+String(n).padStart(3,'0')}
function cctp(sel){return '# CAHIER DES CLAUSES TECHNIQUES PARTICULIÈRES (CCTP)\n{{projet}} — {{lieu}}\n'+sel.map(function(k,i){return '# LOT '+(i+1)+' — '+k.toUpperCase()+'\n'+D.lots[k]}).join('\n')}
function lib(t){return t==='ccap'?D.ccap:(D.models[t]||{})}
/* ---------- mise en forme (aperçu et PDF) ---------- */
function inl(s){return C.esc(s).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')}
function rd(txt){var out=[],tb=[],ul='',first=true;
 function cl(){if(ul){out.push('</'+ul+'>');ul=''}}
 function fl(){if(!tb.length)return;var sg=tb.some(function(r){return r.some(function(c){return /Lu et approuvé/.test(c)})});
  out.push('<table'+(sg?' class="sigt"':'')+'>'+tb.map(function(r,i){var g=i===0?'th':'td';return '<tr>'+r.map(function(c){return '<'+g+'>'+inl(c.trim())+'</'+g+'>'}).join('')+'</tr>'}).join('')+'</table>');tb=[]}
 String(txt||'').split(/\r?\n/).forEach(function(l){
  if(/^\s*\|/.test(l)){cl();tb.push(l.replace(/^\s*\||\|\s*$/g,'').split('|'));return}fl();
  var m;
  if(/^\[saut de page\]\s*$/i.test(l)){cl();out.push('<div class="pb"></div>')}
  else if(/^---+\s*$/.test(l)){cl();out.push('<hr>')}
  else if(/^###\s/.test(l)){cl();out.push('<h4>'+inl(l.slice(4))+'</h4>')}
  else if(/^##\s/.test(l)){cl();out.push('<h3>'+inl(l.slice(3))+'</h3>')}
  else if(/^#\s/.test(l)){cl();out.push(first?'<h2 class="doct">'+inl(l.slice(2))+'</h2>':'<h2>'+inl(l.slice(2))+'</h2>');first=false}
  else if(/^\s*-\s/.test(l)){if(ul!=='ul'){cl();out.push('<ul>');ul='ul'}out.push('<li>'+inl(l.replace(/^\s*-\s/,''))+'</li>')}
  else if((m=/^\s*(\d+)[.)]\s+(.*)$/.exec(l))){if(ul!=='ol'){cl();out.push('<ol>');ul='ol'}out.push('<li>'+inl(m[2])+'</li>')}
  else if(/^>>\s?/.test(l)){cl();out.push('<p class="c">'+inl(l.replace(/^>>\s?/,''))+'</p>')}
  else if(/^<<\s?/.test(l)){cl();out.push('<p class="r">'+inl(l.replace(/^<<\s?/,''))+'</p>')}
  else if((m=/^(Objet|Réf\.? projet|Référence)\s*:\s*(.*)$/.exec(l))){cl();out.push('<p class="obj"><b>'+C.esc(m[1])+' :</b> '+inl(m[2])+'</p>')}
  else if(l.trim()){cl();out.push('<p>'+inl(l)+'</p>')}});
 cl();fl();return out.join('')}
/* ---------- PDF officiel ---------- */
function logoUrl(I){var l=I.logo||'';if(/^(data:|https?:|blob:)/.test(l))return l;try{if(l)return new URL(l,location.href).href}catch(e){}return C.logo()}
function visa(){try{if(w.EXBSign&&EXBSign.anyVisa)return Promise.resolve(EXBSign.anyVisa('png')).then(function(u){return u||''},function(){return ''})}catch(e){}return Promise.resolve('')}
var CSS='@page{size:A4;margin:12mm 14mm 16mm;@bottom-center{content:"Page " counter(page) " / " counter(pages);font:8pt Arial,sans-serif;color:#666}}'
+'*{box-sizing:border-box}html,body{margin:0;font:11pt/1.5 Arial,Helvetica,sans-serif;color:#111;-webkit-print-color-adjust:exact;print-color-adjust:exact}'
+'.wrap{width:100%;height:258mm;border-collapse:collapse;border:0}.wrap>tbody>tr>td{height:100%}.wrap>thead>tr>td,.wrap>tbody>tr>td,.wrap>tfoot>tr>td{border:0;padding:0;vertical-align:top}'
+'.hd{display:flex;align-items:center;gap:12px;border-bottom:3px solid #c49a38;padding-bottom:7px;margin-bottom:12px}.hd img{height:50px;max-width:90px;object-fit:contain}'
+'.hd .nm{font-size:15pt;font-weight:bold;color:#173565;line-height:1.1}.hd .tg{font-size:9pt;color:#8a6a1c;font-style:italic}.hd .ct{margin-left:auto;text-align:right;font-size:8pt;color:#444;line-height:1.35}'
+'.ft{border-top:2px solid #173565;margin-top:10px;padding-top:5px;display:flex;align-items:center;gap:10px;font-size:7.5pt;color:#444;line-height:1.35}.ft .fm{flex:1 1 auto;min-width:0;text-align:center;overflow-wrap:anywhere}.ft .exqr{position:static;right:auto;bottom:auto;display:block;flex:0 0 19mm;width:19mm;height:19mm;image-rendering:pixelated}.ft .qt{flex:0 0 30mm;width:30mm;font-size:7pt;text-align:left;position:static}.ft b{color:#173565}'
+'.bd h2{font-size:13pt;color:#173565;border-bottom:1px solid #173565;margin:16px 0 6px;padding-bottom:2px;page-break-after:avoid}'
+'.bd h2.doct{font-size:16pt;text-align:center;text-transform:uppercase;border:0;border-top:1px solid #c49a38;border-bottom:1px solid #c49a38;padding:8px 0;margin:6px 0 12px}'
+'.bd h3{font-size:11.5pt;color:#173565;margin:12px 0 4px;page-break-after:avoid}.bd h4{font-size:11pt;margin:10px 0 3px;page-break-after:avoid}'
+'.bd p{margin:0 0 6px;text-align:justify}.bd p.c{text-align:center}.bd p.r{text-align:right}.bd p.obj{margin:3px 0}.bd ul,.bd ol{margin:3px 0 8px;padding-left:22px}.bd li{margin:1px 0}'
+'.bd table{border-collapse:collapse;width:100%;margin:6px 0;page-break-inside:auto}.bd tr{page-break-inside:avoid}.bd td,.bd th{border:1px solid #777;padding:4px 6px;font-size:10pt;vertical-align:top;text-align:left}.bd th{background:#e8edf5;color:#173565}'
+'.bd table.sigt td,.bd table.sigt th{text-align:center}.bd table.sigt tr+tr td{height:26mm;vertical-align:bottom}'
+'.bd hr{border:0;border-top:1px solid #999;margin:10px 0}.pb{page-break-after:always;height:0}'
+'.meta{display:flex;flex-wrap:wrap;gap:4px 16px;background:#f1f5fb;border-left:4px solid #173565;padding:7px 10px;margin:0 0 10px;font-size:9.5pt}.meta div{flex:1 1 40%}.meta span{color:#555}'
+'.rf{display:flex;justify-content:space-between;gap:10px;font-size:10pt;margin-bottom:10px}.dest{margin:0 0 12px auto;width:46%;font-size:11pt}'
+'.sg{display:flex;gap:18px;margin-top:20px;page-break-inside:avoid}.sg>div{flex:1;border-top:1px solid #111;padding-top:4px;font-size:10pt;min-height:30mm;text-align:center}.sg img{max-height:26mm;max-width:100%;display:block;margin:2px auto}'
+'.wrap>tbody>tr.sgrow>td{height:1px;vertical-align:bottom;padding:0}.sgrow .sgr,.sgrow .sg{margin-top:8px;margin-bottom:6px}.sgr{margin-top:20px;display:flex;justify-content:flex-end;page-break-inside:avoid}.sgr>div{width:56%;text-align:center;font-size:10.5pt}.sgr img{max-height:30mm;max-width:100%;display:block;margin:4px auto}.sgr .sp{height:22mm}'
+'.bar{position:fixed;top:8px;right:8px;background:#fff;padding:6px;box-shadow:0 2px 10px #777}@media print{.bar{display:none}}';
function vqr(x,body){try{if(!(w.EXBVerif&&EXBVerif.docUrl&&EXBVerif.qrPng))return null;var c=EXBVerif.docUrl({title:x.title||ty(x.type)[1],sub:ty(x.type)[1]+(x.project?' · '+C.pn(x.project):''),digest:body,nom:x.entreprise||'',no:x.no,date:x.date,prefix:ty(x.type)[0],detail:'État : '+(x.status||'')});var im=c&&c.url?EXBVerif.qrPng(c.url):'';return im?{img:im,hash:c.hash}:null}catch(e){return null}}
function build(x,vz){var I=ID(),t=x.type,v=vars(x),mode=(x.sign||D.sign[t]||'dg'),sgn=(t==='lettre'||t==='attest');
 var body=fill(x.body||'',v).replace(/\{\{\w+\}\}/g,'____________');
 var addTitle=!/^#\s/m.test(body);
 var name=I.name||C.brand(),contact=[I.phone?'Tél : '+I.phone:'',I.email?'E-mail : '+I.email:'',I.website||''].filter(Boolean).join(' · '),place=w.EXBId?EXBId.placeLine(I):(I.address||''),legal=w.EXBId?EXBId.legalLine(I):'';
 var head='<div class="hd"><img src="'+C.esc(logoUrl(I))+'" alt=""><div><div class="nm">'+C.esc(name)+'</div>'+(I.tagline?'<div class="tg">'+C.esc(I.tagline)+'</div>':'')+'</div><div class="ct">'+(place?C.esc(place)+'<br>':'')+C.esc(contact)+'</div></div>';
 var Q=vqr(x,body);
 var foot='<div class="ft">'+(Q?'<img class="exqr" src="'+C.esc(Q.img)+'" alt="QR"><div class="qt"><b>Vérifier ce document</b><br>Scannez le QR code<br>Code : '+C.esc(Q.hash.toUpperCase())+'</div>':'')+'<div class="fm"><b>'+C.esc(name)+'</b>'+(I.tagline?' — '+C.esc(I.tagline):'')+(place||contact?'<br>'+C.esc([place,contact].filter(Boolean).join(' · ')):'')+(legal?'<br>'+C.esc(legal):'')+'<br>'+C.esc(x.no||'')+' · '+C.esc(C.frDate(x.date))+'</div></div>';
 var top='';
 if(sgn){top='<div class="rf"><div><b>Réf. :</b> '+C.esc(x.no||'')+(x.project?'<br><b>Projet :</b> '+C.esc(v.projet):'')+'</div><div style="text-align:right">'+C.esc(v.ville==='____________'?'':v.ville+', ')+'le '+C.esc(C.frDate(x.date))+'</div></div>'+(x.dest?'<div class="dest"><b>'+C.esc(x.dest).replace(/\n/g,'<br>')+'</b></div>':'');if(addTitle&&t==='attest')top+='<h2 class="doct">'+C.esc(x.title)+'</h2>'}
 else{top=(addTitle?'<h2 class="doct">'+C.esc(x.title||ty(t)[1])+'</h2>':'')+'<div class="meta"><div><span>Référence : </span><b>'+C.esc(x.no||'')+'</b></div><div><span>Date : </span><b>'+C.esc(C.frDate(x.date))+'</b></div>'+(x.project?'<div><span>Projet : </span><b>'+C.esc(v.projet)+'</b></div>':'')+(v.lieu?'<div><span>Lieu : </span><b>'+C.esc(v.lieu)+'</b></div>':'')+(x.dest?'<div><span>Destinataire : </span><b>'+C.esc(x.dest)+'</b></div>':'')+(x.entreprise?'<div><span>Entreprise : </span><b>'+C.esc(x.entreprise)+'</b></div>':'')+'</div>'}
 var img=vz?'<img src="'+C.esc(vz)+'" alt="">':'<div class="sp"></div>';
 var sig='';
 if(mode==='dg'){sig='<div class="sgr"><div><b>'+C.esc(v.dg_role)+'</b>'+(t==='os'?'':'')+img+'</div></div>';
  if(t==='os')sig+='<div class="sg"><div>Reçu par l’entreprise ('+C.esc(x.entreprise||'nom, date et signature')+')</div></div>'}
 else if(mode==='two'){sig='<div class="sg"><div><b>Le maître d’ouvrage</b><br>'+C.esc(v.moa)+'</div><div><b>L’entreprise</b><br>'+C.esc(x.entreprise||'')+'</div><div><b>Le maître d’œuvre</b><br>'+C.esc(name)+img+(v.dg?C.esc(v.dg):'')+'</div></div>'}
 return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>'+C.esc((x.no||'')+' '+(x.title||''))+'</title><style>'+CSS+'</style></head><body><table class="wrap"><thead><tr><td>'+head+'</td></tr></thead><tbody><tr><td class="bd">'+top+rd(body)+'</td></tr>'+(sig?'<tr class="sgrow"><td>'+sig+'</td></tr>':'')+'</tbody><tfoot><tr><td>'+foot+'</td></tr></tfoot></table></body></html>'}
function ask(title,fields,cb){var o=d.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99999;background:#000a;display:flex;align-items:center;justify-content:center;padding:12px';
 o.innerHTML='<div style="background:#fff;border-radius:12px;padding:16px;max-width:420px;width:100%;font:14px Arial;color:#172033"><b>'+C.esc(title)+'</b>'+fields.map(function(f,i){return '<label style="display:block;margin-top:10px;font-size:12px">'+C.esc(f.label)+'<br><input data-i="'+i+'" type="'+(f.type||'text')+'" value="'+C.esc(f.val==null?'':f.val)+'" style="width:100%;padding:8px;box-sizing:border-box"></label>'}).join('')+'<p style="margin:14px 0 0;text-align:right"><button data-k="n" style="padding:8px 12px">Annuler</button> <button data-k="o" style="padding:8px 14px;background:#173565;color:#fff;border:0;border-radius:8px">OK</button></p></div>';
 d.body.appendChild(o);var ins=o.querySelectorAll('input');if(ins[0])ins[0].focus();
 function ok(){var v=[].map.call(ins,function(i){return i.value});o.remove();cb(v)}
 o.querySelector('[data-k=n]').onclick=function(){o.remove()};o.querySelector('[data-k=o]').onclick=ok;[].forEach.call(ins,function(i){i.onkeydown=function(e){if(e.key==='Enter')ok()}})}
/* ---------- liste ---------- */
function open(){if(!C.can(COL,'lire'))return C.say('Accès non autorisé.','error');if(!st.pid)st.pid=C.firstProject();st.id='';list()}
function list(){var A=pieces().filter(function(x){return String(x.project)===String(st.pid)&&(!st.type||x.type===st.type)}).sort(function(a,b){return a.date<b.date?1:-1});
 var h='<p>'+C.projSelect('EXBPIE.proj',st.pid)+' <select onchange="EXBPIE.flt(this.value)" style="padding:8px"><option value="">Tous les types</option>'+Object.keys(TY).map(function(k){return '<option value="'+k+'"'+(st.type===k?' selected':'')+'>'+TY[k][0]+' — '+TY[k][1]+'</option>'}).join('')+'</select></p>';
 if(canW())h+='<p><button onclick="EXBPIE.neu()" style="padding:10px 14px;background:#173565;color:#fff;border:0;border-radius:8px">➕ Nouvelle pièce</button> <button onclick="EXBPIE.mods()" style="padding:10px 14px">📚 Mes modèles ('+mine().length+')</button></p>';
 h+=A.length?'<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse"><tr style="text-align:left;background:#f1f5fb"><th style="padding:6px">N°</th><th>Titre</th><th>Date</th><th>État</th><th></th></tr>'+A.map(function(x){return '<tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px">'+ty(x.type)[2]+' '+C.esc(x.no)+'</td><td>'+C.esc(x.title)+(x.dest?'<br><small>→ '+C.esc(x.dest)+'</small>':'')+'</td><td>'+C.frDate(x.date)+'</td><td>'+C.esc(x.status)+'</td><td><button onclick="EXBPIE.edit(\''+x.id+'\')">✏️ Ouvrir</button></td></tr>'}).join('')+'</table></div>':'<p style="color:#64748b">Aucune pièce pour ce projet. Touchez « Nouvelle pièce » : choisissez un modèle (CCTP, lettre, procès-verbal, contrat…) ou un texte libre. Les modèles se pré-remplissent avec le projet, le client, le lieu et la phase en cours.</p>';
 C.overlay('exbPie','✍️ Pièces écrites',h+'<p style="font-size:12px;color:#64748b">Les modèles sont des bases courantes à adapter : faites valider les clauses contractuelles (pénalités, garanties, assurances) par votre conseil juridique.</p>')}
/* ---------- nouvelle pièce : type puis modèle ---------- */
function chooseType(){var h='<p style="color:#64748b;margin:6px 0">Quel type de pièce voulez-vous écrire ?</p><div style="display:flex;flex-wrap:wrap;gap:8px">'+Object.keys(TY).map(function(k){var n=k==='cctp'?Object.keys(D.lots).length+' lots':(Object.keys(lib(k)).length+' modèles');return '<button onclick="EXBPIE.ct(\''+k+'\')" style="flex:1 1 44%;text-align:left;padding:10px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc"><span style="font-size:20px">'+TY[k][2]+'</span> <b>'+C.esc(TY[k][1])+'</b><br><small style="color:#64748b">'+n+(k==='libre'?' · écrivez ce que vous voulez':'')+'</small></button>'}).join('')+'</div><p><button onclick="EXBPIE.back()">← Liste</button></p>';
 C.overlay('exbPie','➕ Nouvelle pièce',h)}
function snip(b){var l=String(b||'').split(/\n/).filter(function(s){return s.trim()&&!/^#|^\|/.test(s)&&!/^(Objet|Réf)/.test(s)})[0]||'';l=l.replace(/\*\*|\{\{\w+\}\}/g,'…');return l.length>110?l.slice(0,110)+'…':l}
function chooseModel(t){st.ct=t;st.cands=[];var h='<p style="color:#64748b;margin:6px 0">'+ty(t)[2]+' '+C.esc(ty(t)[1])+'</p>';
 if(t==='cctp'){h+='<p style="margin:6px 0"><b>Lots à inclure</b> <button onclick="EXBPIE.lots(1)">Tout cocher</button> <button onclick="EXBPIE.lots(0)">Tout décocher</button></p><div style="display:flex;flex-wrap:wrap;gap:4px">'+Object.keys(D.lots).map(function(k,i){return '<label style="flex:1 1 46%;font-size:13px;display:flex;gap:6px;align-items:flex-start"><input type="checkbox" class="pLot" value="'+i+'" checked> '+C.esc(k)+'</label>'}).join('')+'</div><p><button onclick="EXBPIE.mkCctp()" style="padding:10px 14px;background:#173565;color:#fff;border:0;border-radius:8px">Créer le CCTP</button></p>'}
 var L1=lib(t);Object.keys(L1).forEach(function(k){st.cands.push({n:k,b:L1[k]})});
 var own=mine().filter(function(m){return m.type===t||t==='libre'});own.forEach(function(m){st.cands.push({n:m.name,b:m.body,own:1,t:m.type})});
 if(st.cands.length)h+='<div style="margin-top:8px">'+st.cands.map(function(c,i){return '<button onclick="EXBPIE.use('+i+')" style="display:block;width:100%;text-align:left;margin:4px 0;padding:9px;border:1px solid '+(c.own?'#c49a38':'#cbd5e1')+';border-radius:10px;background:'+(c.own?'#fffbeb':'#f8fafc')+'"><b>'+(c.own?'⭐ ':'')+C.esc(c.n)+'</b>'+(c.own?' <small>(mon modèle)</small>':'')+'<br><small style="color:#64748b">'+C.esc(snip(c.b))+'</small></button>'}).join('')+'</div>';
 if(t!=='libre')h+='<p><button onclick="EXBPIE.blank()" style="padding:9px 12px">✍️ Texte vierge : je rédige moi-même</button></p>';
 h+='<p><button onclick="EXBPIE.neu()">← Types</button> <button onclick="EXBPIE.back()">Liste</button></p>';
 C.overlay('exbPie','➕ '+C.esc(ty(t)[1]),h)}
function create(t,body,title,model){var x={id:C.uid('PIE'),type:t,project:st.pid,no:nextNo(t),date:C.today(),status:'brouillon',title:'',dest:'',entreprise:'',lot:'',objet:'',effet:'',model:model||'',sign:''};
 x.title=title||(ty(t)[1]+' — '+C.pn(st.pid));x.body=fill(body,vars(x,true));var a=L();a.push(x);S(a);edit(x.id)}
/* ---------- éditeur ---------- */
function edit(id){var x=L().find(function(q){return q.id===id});if(!x)return;st.id=id;var ro=!canW(),t=x.type,sg=x.sign||D.sign[t]||'dg';
 var tb='<div style="display:flex;flex-wrap:wrap;gap:4px;margin:6px 0">'+[['# T','# ','Titre'],['## ST','## ','Sous-titre'],['• Puce','- ','Puce'],['1. Liste','1. ','Numéro'],['B','**','Gras']].map(function(b){return '<button '+(ro?'disabled ':'')+'onclick="EXBPIE.ins(\''+b[1]+'\')" title="'+b[2]+'" style="padding:6px 9px">'+b[0]+'</button>'}).join('')
 +'<button '+(ro?'disabled ':'')+'onclick="EXBPIE.tab()" style="padding:6px 9px">▦ Tableau</button><button '+(ro?'disabled ':'')+'onclick="EXBPIE.ins(\'[saut de page]\')" style="padding:6px 9px">⤓ Saut de page</button>'
 +'<select '+(ro?'disabled ':'')+'onchange="EXBPIE.ivar(this.value);this.selectedIndex=0" style="padding:6px"><option value="">{{ }} Insérer une donnée…</option>'+VARS.map(function(q){return '<option value="'+q[0]+'">'+q[1]+'</option>'}).join('')+'</select></div>';
 var h='<p style="color:#64748b;margin:4px 0">'+ty(t)[2]+' '+C.esc(ty(t)[1])+(x.model?' · '+C.esc(x.model):'')+'</p><div style="display:flex;flex-wrap:wrap;gap:6px">'+C.field('pTi','Titre',x.title,'',60)+C.field('pNo','N° / Référence',x.no,'',30)+C.field('pDa','Date',x.date,'date',30)+'<label style="flex:1 1 45%;font-size:12px">Destinataire (une ligne par information)<br><textarea id="pDe" rows="2" style="width:100%;padding:7px;box-sizing:border-box">'+C.esc(x.dest||'')+'</textarea></label>'+C.field('pEn','Entreprise',x.entreprise,'',45)+C.field('pLo','Lot',x.lot,'',30)+C.field('pOb','Objet / motif',x.objet,'',60)+C.field('pEf',t==='os'?'Date d’effet':'Date de réunion / effet',x.effet,'date',30)+'</div>'
 +'<p style="margin:8px 0"><label style="font-size:12px">État <select id="pSt" style="padding:7px"'+(ro?' disabled':'')+'>'+ST.map(function(s){return '<option'+(s===x.status?' selected':'')+'>'+s+'</option>'}).join('')+'</select></label> '
 +'<label style="font-size:12px">Signature du PDF <select id="pSg" style="padding:7px"'+(ro?' disabled':'')+'><option value="dg"'+(sg==='dg'?' selected':'')+'>Directeur Général</option><option value="two"'+(sg==='two'?' selected':'')+'>Les parties (3 cases)</option><option value="none"'+(sg==='none'?' selected':'')+'>Aucune</option></select></label></p>'
 +tb+'<textarea id="pBo" '+(ro?'readonly ':'')+'style="width:100%;box-sizing:border-box;min-height:44vh;padding:8px;font:13px/1.4 monospace">'+C.esc(x.body)+'</textarea>'
 +'<div id="pPrev" style="display:none;border:1px solid #cbd5e1;border-radius:8px;padding:10px;max-height:52vh;overflow:auto;font:13px/1.45 Arial"></div>'
 +'<p style="font-size:12px;color:#64748b">Écrivez librement. Mise en forme : « # Titre », « ## Sous-titre », « - puce », « 1. numéro », « | a | b | » (tableau), **gras**. Les {{données}} se remplissent à l’export ; les trous restent « ____ » à compléter. La signature et le cachet du DG sont apposés quand l’état est « émis » ou « signé ».</p>'
 +'<p><button onclick="EXBPIE.save()" '+(ro?'disabled ':'')+'style="padding:9px 14px">💾 Enregistrer</button> <button onclick="EXBPIE.prev()" style="padding:9px 14px">👁 Aperçu</button> <button onclick="EXBPIE.print()" style="padding:9px 14px;background:#173565;color:#fff;border:0;border-radius:8px">📄 PDF officiel</button></p>'
 +'<p>'+(ro?'':'<button onclick="EXBPIE.fillv()">↻ Remplir les {{données}}</button> <button onclick="EXBPIE.saveMod()">⭐ Enregistrer comme modèle</button> <button onclick="EXBPIE.dup()">⧉ Dupliquer</button> <button onclick="EXBPIE.del()">🗑</button> ')+'<button onclick="EXBPIE.back()">← Liste</button></p>';
 C.overlay('exbPie','✍️ '+C.esc(x.title||x.no),h)}
function A2(f){return function(){if(!canW())return C.say('Écriture non autorisée.','error');return f.apply(null,arguments)}}
function collect(x){x.title=C.val('pTi')||x.title;x.no=C.val('pNo')||x.no;x.date=C.val('pDa')||x.date;x.dest=C.val('pDe');x.entreprise=C.val('pEn');x.lot=C.val('pLo');x.objet=C.val('pOb');x.effet=C.val('pEf');x.status=C.val('pSt')||x.status;x.sign=C.val('pSg')||x.sign||'';var b=d.getElementById('pBo');if(b)x.body=b.value}
function cur(){var a=L(),x=a.find(function(q){return q.id===st.id});return{a:a,x:x}}
function insAt(txt,block){var b=d.getElementById('pBo');if(!b||b.readOnly)return;var s=b.selectionStart||0,e=b.selectionEnd||0,v=b.value;
 if(block){var ls=v.lastIndexOf('\n',s-1)+1;b.value=v.slice(0,ls)+txt+v.slice(ls);b.selectionStart=b.selectionEnd=s+txt.length}
 else{var sel=v.slice(s,e);b.value=v.slice(0,s)+txt+sel+txt+v.slice(e);b.selectionStart=s+txt.length;b.selectionEnd=s+txt.length+sel.length}b.focus()}
w.EXBPIE={open:open,proj:function(v){st.pid=v;list()},flt:function(v){st.type=v;list()},back:list,edit:edit,
 neu:A2(function(){chooseType()}),ct:A2(function(t){chooseModel(t)}),
 lots:function(on){[].forEach.call(d.querySelectorAll('.pLot'),function(c){c.checked=!!on})},
 mkCctp:A2(function(){var ks=Object.keys(D.lots),sel=[];[].forEach.call(d.querySelectorAll('.pLot'),function(c){if(c.checked)sel.push(ks[+c.value])});if(!sel.length)return C.say('Cochez au moins un lot.','error');create('cctp',cctp(sel),'CCTP — '+C.pn(st.pid))}),
 use:A2(function(i){var c=st.cands[i];if(!c)return;var t=c.own?(c.t||st.ct):st.ct;create(t,c.b,c.n+' — '+C.pn(st.pid),c.n)}),
 blank:A2(function(){var t=st.ct,b=t==='lettre'?'Objet : \nRéf. projet : {{projet}}\n\nMadame, Monsieur,\n\n\n\nVeuillez agréer, Madame, Monsieur, nos salutations distinguées.':'';create(t,b,ty(t)[1]+' — '+C.pn(st.pid))}),
 ins:function(t){if(t==='[saut de page]'){var b=d.getElementById('pBo');if(!b||b.readOnly)return;var s=b.selectionStart||0;b.value=b.value.slice(0,s)+'\n[saut de page]\n'+b.value.slice(s);b.selectionStart=b.selectionEnd=s+16;b.focus();return}insAt(t,t!=='**')},
 tab:function(){var b=d.getElementById('pBo');if(!b||b.readOnly)return;var s0=b.selectionStart||b.value.length;
  ask('Insérer un tableau',[{label:'Nombre de colonnes (1 à 8)',val:'3',type:'number'},{label:'Nombre de lignes sans l’en-tête (1 à 40)',val:'3',type:'number'}],function(v){var n=Math.max(1,Math.min(8,parseInt(v[0],10)||0)),r=Math.max(1,Math.min(40,parseInt(v[1],10)||0));
   var hd='|'+Array(n+1).join(' Colonne |'),ln='|'+Array(n+1).join(' ____________ |'),t='\n'+hd+'\n'+Array(r+1).join(ln+'\n');b.value=b.value.slice(0,s0)+t+b.value.slice(s0);b.focus()})},
 ivar:function(k){if(!k)return;var b=d.getElementById('pBo');if(!b||b.readOnly)return;var s=b.selectionStart||0,t='{{'+k+'}}';b.value=b.value.slice(0,s)+t+b.value.slice(b.selectionEnd||s);b.selectionStart=b.selectionEnd=s+t.length;b.focus()},
 prev:function(){var b=d.getElementById('pBo'),p=d.getElementById('pPrev');if(!b||!p)return;if(p.style.display==='none'){var o=cur().x;if(o){var tmp=JSON.parse(JSON.stringify(o));collect(tmp);p.innerHTML='<style>'+CSS.replace(/@page\{[^}]*\{[^}]*\}\}/,'').replace(/html,body\{[^}]*\}/,'')+'</style><div class="bd">'+rd(fill(b.value,vars(tmp)).replace(/\{\{\w+\}\}/g,'____________'))+'</div>'}p.style.display='block';b.style.display='none'}else{p.style.display='none';b.style.display='block'}},
 fillv:A2(function(){var o=cur(),x=o.x;if(!x)return;collect(x);x.body=fill(x.body,vars(x,true));S(o.a);edit(x.id)}),
 save:A2(function(){var o=cur(),x=o.x;if(!x)return;collect(x);S(o.a);C.say('Pièce enregistrée.')}),
 saveMod:A2(function(){var o=cur(),x=o.x;if(!x)return;collect(x);ask('Enregistrer comme modèle',[{label:'Nom du modèle (réutilisable pour d’autres projets)',val:x.title.replace(/\s—\s.*$/,'')}],function(v){var n=(v[0]||'').trim();if(!n)return;var a=L();a.push({id:C.uid('MOD'),modele:true,type:x.type,name:n,body:x.body,project:'',date:C.today()});S(a);C.say('Modèle « '+n+' » enregistré.')})}),
 mods:function(){var M=mine(),h=M.length?M.map(function(m,i){return '<div style="border:1px solid #c49a38;background:#fffbeb;border-radius:10px;padding:9px;margin:5px 0"><b>⭐ '+C.esc(m.name)+'</b> <small>('+C.esc(ty(m.type)[1])+')</small><br><small style="color:#64748b">'+C.esc(snip(m.body))+'</small><br>'+(canW()?'<button onclick="EXBPIE.modUse(\''+m.id+'\')">Utiliser</button> <button onclick="EXBPIE.modRen(\''+m.id+'\')">✏️ Renommer</button> <button onclick="EXBPIE.modDel(\''+m.id+'\')">🗑</button>':'')+'</div>'}).join(''):'<p style="color:#64748b">Aucun modèle personnel. Ouvrez une pièce puis touchez « ⭐ Enregistrer comme modèle ».</p>';
  C.overlay('exbPie','📚 Mes modèles',h+'<p><button onclick="EXBPIE.back()">← Liste</button></p>')},
 modUse:A2(function(id){var m=mine().find(function(q){return q.id===id});if(!m)return;create(m.type,m.body,m.name+' — '+C.pn(st.pid))}),
 modRen:A2(function(id){var m=mine().find(function(q){return q.id===id});if(!m)return;ask('Renommer le modèle',[{label:'Nouveau nom',val:m.name}],function(v){var n=(v[0]||'').trim();if(!n)return;var a=L(),q=a.find(function(z){return z.id===id});q.name=n;S(a);EXBPIE.mods()})}),
 modDel:A2(function(id){if(!w.confirm('Supprimer ce modèle ?'))return;S(L().filter(function(q){return q.id!==id}));EXBPIE.mods()}),
 dup:A2(function(){var o=cur(),x=o.x;if(!x)return;collect(x);var n=JSON.parse(JSON.stringify(x));n.id=C.uid('PIE');n.no=nextNo(x.type);n.status='brouillon';n.date=C.today();n.title=x.title+' (copie)';o.a.push(n);S(o.a);edit(n.id)}),
 del:A2(function(){if(!w.confirm('Supprimer cette pièce ?'))return;S(L().filter(function(q){return q.id!==st.id}));list()}),
 html:function(x,vz){return build(x,vz||'')},
 print:function(){var o=cur(),x=o.x;if(!x)return;if(canW()){collect(x);S(o.a)}
  var signed=x.status!=='brouillon';return (signed?visa():Promise.resolve('')).then(function(vz){
   var title=(x.no||'')+' '+(x.title||''),htm=build(x,vz);
   var P=w.EXBPrint,native=!!(w.exbDesktop&&w.exbDesktop.print)||!!w.ExbAndroidPrint;
   function old(){return P.html(title,htm,{landscape:false})}
   if(native)return old();
   return pdfBlob(htm).then(function(b){deliver(b,fname(x));return true},function(e){C.say('PDF direct impossible ('+(e&&e.message||e)+'), ouverture de l’aperçu.','warn');return old()})})}};
/* ---------- V120 : vrai PDF fabriqué dans l'appareil (Android / PWA / navigateur) : ne dépend d'aucun moteur d'impression ---------- */
function fname(x){return String((x.no||'piece')+'-'+(x.title||'')).replace(/[^\wÀ-ſ]+/g,'-').replace(/^-+|-+$/g,'').slice(0,80)+'.pdf'}
function toData(src){return fetch(src).then(function(r){return r.blob()}).then(function(b){return new Promise(function(ok,ko){var f=new FileReader();f.onload=function(){ok(f.result)};f.onerror=ko;f.readAsDataURL(b)})})}
function cssScoped(){return CSS.replace(/@page\{[^}]*\{[^}]*\}[^}]*\}/,'').replace('html,body{','#exbPieR{').replace('*{box-sizing:border-box}','#exbPieR *{box-sizing:border-box}')}
function pdfBlob(htm){
 if(!w.html2canvas||!w.jspdf)return Promise.reject(new Error('moteur PDF local absent'));
 var doc=new DOMParser().parseFromString(htm,'text/html'),parts={h:doc.querySelector('.wrap>thead td'),b:doc.querySelector('.wrap>tbody>tr:not(.sgrow)>td'),s:doc.querySelector('.wrap>tbody>tr.sgrow>td'),f:doc.querySelector('.wrap>tfoot td')};
 if(!parts.b)return Promise.reject(new Error('mise en page introuvable'));
 var W=688,PW=794,PH=1123,MX=53,MT=45,MB=60,K=2,host=d.createElement('div'),st=d.createElement('style');
 st.textContent=cssScoped();host.id='exbPieR';host.style.cssText='position:absolute;left:-20000px;top:0;width:'+W+'px;background:#fff';
 var els={};['h','b','s','f'].forEach(function(k){var e=d.createElement('div');e.style.cssText='width:'+W+'px;background:#fff';e.innerHTML=parts[k]?parts[k].innerHTML:'';if(k==='b')e.className='bd';if(k==='s')e.className='sgrow';els[k]=e;host.appendChild(e)});
 d.head.appendChild(st);d.body.appendChild(host);
 function clean(){try{host.remove();st.remove()}catch(e){}}
 var imgs=[].slice.call(host.querySelectorAll('img')).filter(function(i){return !/^(data:|blob:)/.test(i.getAttribute('src')||'')});
 return Promise.all(imgs.map(function(i){return toData(i.src).then(function(u){i.src=u},function(){i.remove()})})).then(function(){
  return Promise.all([].slice.call(host.querySelectorAll('img')).map(function(i){return i.complete?1:new Promise(function(ok){i.onload=i.onerror=ok;setTimeout(ok,4000)})}))
 }).then(function(){
  function cap(e){return e.offsetHeight?w.html2canvas(e,{scale:K,backgroundColor:'#ffffff',logging:false}):Promise.resolve(null)}
  var bh=els.b.offsetHeight,cuts=[];
  var bt=els.b.getBoundingClientRect().top,blocks=[].slice.call(els.b.querySelectorAll('p,li,tr,h2,h3,h4,.sg,.sgr,.meta,.rf')).map(function(e){var r=e.getBoundingClientRect();return {t:r.top-bt,b:r.bottom-bt}});
  return Promise.all([cap(els.h),cap(els.b),cap(els.f),cap(els.s)]).then(function(cv){
   var ch=cv[0],cb=cv[1],cf=cv[2],cs=cv[3];
   if(!cb||!cb.width)throw new Error('contenu vide');
   var hh=els.h.offsetHeight,fh=els.f.offsetHeight,avail=PH-MT-MB-hh-fh-16;
   if(avail<200)throw new Error('en-tête trop grand');
   var y=0;while(y<bh){var lim=y+avail;if(lim>=bh){cuts.push([y,bh]);break}var cut=lim;
    for(var i=0;i<blocks.length;i++){var b=blocks[i];if(b.t<lim&&b.b>lim&&b.t>y+40&&(b.b-b.t)<avail*.6){cut=Math.min(cut,b.t)}}
    cuts.push([y,cut]);y=cut}
   /* visa : toujours en bas de la dernière page, juste au-dessus du pied de page ; s'il n'y a plus de place, il passe sur une page à lui */
   var sgh=cs?els.s.offsetHeight:0;
   if(sgh&&cuts.length){var lc=cuts[cuts.length-1];if(lc[1]-lc[0]>avail-sgh-8)cuts.push([bh,bh])}
   var N=cuts.length,J=w.jspdf.jsPDF,pdf=new J({unit:'mm',format:'a4',compress:true});
   cuts.forEach(function(c,n){
    var cn=d.createElement('canvas');cn.width=PW*K;cn.height=PH*K;var g=cn.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,cn.width,cn.height);
    var yy=MT;if(ch){g.drawImage(ch,MX*K,yy*K,W*K,hh*K);}yy+=hh;
    var sh=c[1]-c[0];if(sh>0)g.drawImage(cb,0,Math.round(c[0]*K),cb.width,Math.round(sh*K),MX*K,yy*K,W*K,Math.round(sh*K));
    if(cs&&n===N-1)g.drawImage(cs,MX*K,(PH-MB-fh-sgh-6)*K,W*K,sgh*K);
    if(cf)g.drawImage(cf,MX*K,(PH-MB-fh)*K,W*K,fh*K);
    g.fillStyle='#666';g.font=(11*K)+'px Arial,sans-serif';g.textAlign='center';g.fillText('Page '+(n+1)+' / '+N,PW*K/2,(PH-22)*K);
    if(n>0)pdf.addPage('a4','portrait');
    pdf.addImage(cn.toDataURL('image/jpeg',.92),'JPEG',0,0,210,297,undefined,'FAST')});
   clean();return pdf.output();
  })}).then(function(b){return b},function(e){clean();throw e})}
function deliver(b,name){
 try{w.__exbLastPdf={blob:b,filename:name}}catch(e){}
 var url=URL.createObjectURL(b),o=d.getElementById('exbPieOut');if(o)o.remove();
 o=d.createElement('div');o.id='exbPieOut';o.style.cssText='position:fixed;inset:0;z-index:100000;background:#000b;display:flex;align-items:center;justify-content:center;padding:14px';
 o.innerHTML='<div style="background:#fff;border-radius:14px;padding:18px;max-width:380px;width:100%;font:15px Arial;color:#172033;text-align:center"><div style="font-size:34px">✅</div><b>PDF prêt</b><div style="font-size:12px;color:#64748b;margin:6px 0 12px;word-break:break-all">'+C.esc(name)+' · '+Math.max(1,Math.round(b.size/1024))+' Ko</div>'
 +'<button data-k="s" style="display:block;width:100%;padding:13px;margin:6px 0;border:0;border-radius:9px;background:#173565;color:#fff;font-size:15px">📤 Partager / Enregistrer</button>'
 +'<a data-k="d" href="'+url+'" download="'+C.esc(name)+'" style="display:block;padding:13px;margin:6px 0;border-radius:9px;background:#eef2f8;color:#173565;text-decoration:none">⬇️ Télécharger</a>'
 +'<a data-k="o" href="'+url+'" target="_blank" rel="noopener" style="display:block;padding:13px;margin:6px 0;border-radius:9px;background:#eef2f8;color:#173565;text-decoration:none">👁 Ouvrir</a>'
 +'<button data-k="c" style="display:block;width:100%;padding:11px;margin-top:6px;border:0;background:none;color:#64748b">Fermer</button></div>';
 d.body.appendChild(o);
 o.querySelector('[data-k=c]').onclick=function(){o.remove();setTimeout(function(){URL.revokeObjectURL(url)},60000)};
 o.querySelector('[data-k=s]').onclick=function(){try{var f=new File([b],name,{type:'application/pdf'});if(navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:name}).catch(function(){})}else{o.querySelector('[data-k=d]').click()}}catch(e){o.querySelector('[data-k=d]').click()}}}
C.addButton('exbPieBtn','✍️ Pièces écrites',open,COL);
})(window,document);
