# V120e — Correctifs : PDF du pilotage, attestation, Entreprise 360°

## 1. Entreprise 360° ne s'ouvrait pas
- `index.html` : la balise `<script src="exb-enterprise-shell.js">` n'était pas fermée ; elle « avalait » la ligne suivante et
  `exb-v90-enterprise.js` n'était jamais chargé (module vide, bouton « Actualiser » sans effet). Balise fermée.
- `show('enterprise360')` n'affichait pas la section (absente de la liste des pages) : ajoutée, avec bouton actif et rafraîchissement.
- Le message brut « Failed to fetch » (hors connexion) est remplacé par un message clair en français.

## 2. Attestation (et toutes les pièces écrites) — mise en page
- Le QR code était déplacé et coupé : le style global `.qr` des certificats (position absolue) s'appliquait au pied de page.
  Le QR a maintenant sa classe `exqr`, protégée, et le pied de page ne peut plus se chevaucher.
- Le visa (cachet + signature) est désormais **en bas de la dernière page**, juste au-dessus du pied de page
  (dans le PDF Windows comme dans le PDF local). S'il n'y a plus de place, il passe seul sur une page.
- Le nom du signataire et le nom de la société sous le visa sont masqués (la mention « Directeur Général » reste).

## 3. Rapport de pilotage : le PDF ne sortait pas
- Sans PDF Windows intégré (installateur plus ancien) le logiciel ouvrait la boîte d'impression Windows sans aperçu.
  `exb-print.js` fabrique maintenant **un vrai PDF dans le logiciel** (A4, plusieurs pages, lignes de tableau non coupées),
  utilisé automatiquement dans l'application Windows quand le PDF intégré est absent ou échoue.
- Bouton « 📄 Créer le PDF » ajouté à l'aperçu d'impression.
- Cache hors connexion renouvelé (`sw.js` v120e).

## Tests
Contrôles du projet : 518 réussis. PDF vérifiés dans un navigateur sans tête (attestation, rapport de pilotage, document de 4 pages).
Non testé ici : l'installateur Windows lui-même — refaire l'installateur pour profiter aussi du PDF intégré.

## 4. Menu « Ingénierie & Structure » : tuiles manquantes (V120f)
Semelle filante, Radier général et Mur de soutènement existaient dans le calculateur (V119j à V119l) mais n'avaient **aucune tuile** dans le menu
« Ingénierie & Structure ». Trois tuiles ajoutées (`exb-calcul-structure.js`, `exb-v99r-shell.js`), ainsi que les raccourcis dans l'écran
Calcul de structure. Chaque tuile ouvre directement son module.
