/* Excellencia Building V113 — Recherche globale sur TOUS les modules.
 * Remplace runExbGlobalSearch : sans accents ni majuscules, plusieurs mots (tous doivent correspondre),
 * recherche dans tous les champs texte de chaque fiche. Un clic ouvre le bon module (et le dossier TFL concerné). */
(function (w) {
  'use strict';
  var d = document;
  function norm(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function rd(k) {
    try { var s = (w.exbStorage && w.exbStorage.getItem) ? w.exbStorage.getItem(k) : w.localStorage.getItem(k); var v = s ? JSON.parse(s) : []; return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }
  var SKIP = /^(photo|signature|sign|logo|image|img|data|file|fichier_data|b64|base64|blob|cachet|password|pass|mdp|code_acces|token|key|cle)/i;
  function flat(o, depth, out) {
    if (o == null) return out;
    if (typeof o === 'string') { if (o.length <= 300 && !/^data:/.test(o)) out.push(o); return out; }
    if (typeof o === 'number') { out.push(String(o)); return out; }
    if (depth > 1) return out;
    if (Array.isArray(o)) { o.slice(0, 20).forEach(function (x) { flat(x, depth + 1, out); }); return out; }
    if (typeof o === 'object') Object.keys(o).forEach(function (k) { if (!SKIP.test(k)) flat(o[k], depth + 1, out); });
    return out;
  }
  function first(r, fields) { for (var i = 0; i < fields.length; i++) { var v = r[fields[i]]; if (v != null && String(v).trim() !== '') return String(v); } return ''; }
  function go(sec) { try { w.show(sec); } catch (e) { /* module absent */ } }

  /* Collections : clé de stockage, libellé du type, champs du titre, champs du détail, action */
  var COLS = [
    { k: 'exb_participants', t: 'Participant', l: ['name', 'nom'], s: ['participant_id', 'training', 'phone'], a: function (r) { try { w.openParticipantProfile(r.participant_id); } catch (e) { go('participants'); } } },
    { k: 'exb_certificates', t: 'Certificat', l: ['cert_no', 'holder'], s: ['holder', 'training'], sec: 'certs' },
    { k: 'exb_receipts', t: 'Reçu', l: ['receipt_no', 'participant'], s: ['participant', 'training'], sec: 'receipts' },
    { k: 'exb_payments', t: 'Paiement', l: ['reference', 'payment_id'], s: ['amount', 'method', 'participant_id'], sec: 'finances' },
    { k: 'exb_formations', t: 'Formation', l: ['name', 'code'], s: ['code', 'trainer', 'status'], sec: 'formations' },
    { k: 'exb_trainers', t: 'Formateur', l: ['name'], s: ['matricule', 'specialty', 'phone'], sec: 'formateurs' },
    { k: 'exb_hr', t: 'Personnel', l: ['name', 'nom'], s: ['matricule', 'role', 'poste', 'phone'], sec: 'rh' },
    { k: 'exb_clients', t: 'Client', l: ['full_name', 'company', 'name', 'id'], s: ['company', 'phone', 'email'], sec: 'clients' },
    { k: 'exb_projects', t: 'Projet', l: ['name', 'id'], s: ['client', 'location', 'status'], sec: 'projets' },
    { k: 'exb_quotes', t: 'Devis', l: ['no', 'id'], s: ['client', 'project', 'total'], sec: 'metreDevis' },
    { k: 'exb_metre', t: 'Métré', l: ['name', 'titre', 'id'], s: ['project', 'client'], sec: 'metreDevis' },
    { k: 'exb_invoices', t: 'Facture', l: ['no', 'number', 'id'], s: ['client', 'project', 'total'], sec: 'comptabilite' },
    { k: 'exb_suppliers', t: 'Fournisseur', l: ['name', 'nom', 'company'], s: ['phone', 'email', 'category'], sec: 'stock' },
    { k: 'exb_purchase_orders', t: 'Bon de commande', l: ['no', 'id'], s: ['supplier', 'project', 'total'], sec: 'stock' },
    { k: 'exb_stock', t: 'Stock', l: ['name', 'nom', 'article'], s: ['category', 'unit', 'qty'], sec: 'stock' },
    { k: 'exb_studies', t: 'Étude', l: ['name', 'titre', 'id'], s: ['client', 'status'], sec: 'bureauEtudes' },
    { k: 'exb_be_missions', t: 'Mission BET', l: ['name', 'titre', 'id'], s: ['client', 'status'], sec: 'bureauEtudes' },
    { k: 'exb_plans', t: 'Plan', l: ['name', 'titre', 'id'], s: ['project', 'client'], sec: 'bureauEtudes' },
    { k: 'exb_calc_notes', t: 'Note de calcul', l: ['name', 'titre', 'id'], s: ['project', 'client'], sec: 'bureauEtudes' },
    { k: 'exb_situations', t: 'Situation de travaux', l: ['no', 'id', 'name'], s: ['project', 'client'], sec: 'projets' },
    { k: 'exb_site_journal', t: 'Journal de chantier', l: ['title', 'titre', 'date', 'id'], s: ['project', 'text', 'note'], sec: 'projets' },
    { k: 'exb_communication', t: 'Communication', l: ['title', 'titre', 'name', 'id'], s: ['channel', 'status'], sec: 'communication' },
    { k: 'exb_documents', t: 'Document', l: ['title', 'id'], s: ['type', 'participant_name', 'project_name'], sec: 'documents' },
    { k: 'exb_tfl_dossiers', t: 'Dossier TFL', tfl: 'dossier', l: ['numero'], s: [] },
    { k: 'exb_tfl_etudiants', t: 'Étudiant TFL', tfl: 'etudiant', l: ['nom'], s: ['matricule', 'universite', 'telephone'] },
    { k: 'exb_tfl_encadreurs', t: 'Encadreur TFL', tfl: 'encadreur', l: ['nom'], s: ['specialites', 'telephone', 'email'] },
    { k: 'exb_tfl_sujets', t: 'Sujet TFL', tfl: 'sujet', l: ['titre', 'ref'], s: ['categorie', 'domaine'] },
    { k: 'exb_tfl_biblio', t: 'Bibliothèque TFL', tfl: 'biblio', l: ['titre'], s: ['auteur', 'annee', 'universite'] }
  ];

  function tflOpen(o) { try { if (typeof w.exbTflOpen === 'function') w.exbTflOpen(o); } catch (e) { /* ignoré */ } go('tflSec'); }

  function search(q) {
    var toks = norm(q).split(' ').filter(Boolean), out = [], nq = norm(q);
    if (!toks.length) return out;
    var etu = rd('exb_tfl_etudiants'), enc = rd('exb_tfl_encadreurs'), dos = rd('exb_tfl_dossiers');
    var nomEtu = {}, nomEnc = {}; etu.forEach(function (e) { nomEtu[e.id] = e.nom || ''; }); enc.forEach(function (e) { nomEnc[e.id] = e.nom || ''; });
    COLS.forEach(function (c) {
      var rows = rd(c.k);
      if (c.k === 'exb_documents' && !rows.length && Array.isArray(w.exbDocuments)) rows = w.exbDocuments;
      rows.forEach(function (r) {
        if (!r || typeof r !== 'object') return;
        var parts = flat(r, 0, []);
        if (c.tfl === 'dossier') { parts.push(nomEtu[r.etudiant_id] || '', nomEnc[r.encadreur_id] || ''); }
        var hay = norm(parts.join(' '));
        for (var i = 0; i < toks.length; i++) if (hay.indexOf(toks[i]) < 0) return;
        var label = first(r, c.l), det = c.s.map(function (f) { return r[f] == null ? '' : String(r[f]); }).filter(Boolean).join(' — ');
        if (c.tfl === 'dossier') { label = (r.numero || 'Dossier') + ' — ' + (nomEtu[r.etudiant_id] || ''); det = [r.sujet || r.titre || '', nomEnc[r.encadreur_id] ? 'Encadreur : ' + nomEnc[r.encadreur_id] : ''].filter(Boolean).join(' — '); }
        var nl = norm(label), score = nl === nq ? 0 : nl.indexOf(nq) === 0 ? 1 : nl.indexOf(nq) >= 0 ? 2 : 3;
        out.push({ t: c.t, label: label || '(sans titre)', det: det, score: score, c: c, r: r });
      });
    });
    out.sort(function (a, b) { return a.score - b.score; });
    return out;
  }

  function open(x) {
    var c = x.c, r = x.r;
    if (c.a) return c.a(r);
    if (c.tfl === 'dossier') return tflOpen({ vue: 'dossiers', sel: r.id });
    if (c.tfl === 'etudiant') { var ds = rd('exb_tfl_dossiers').filter(function (z) { return z.etudiant_id === r.id; })[0]; return tflOpen(ds ? { vue: 'dossiers', sel: ds.id } : { vue: 'dossiers', sel: '', q: r.nom || '' }); }
    if (c.tfl === 'encadreur') return tflOpen({ vue: 'encadreurs', sel: '' });
    if (c.tfl === 'sujet') return tflOpen({ vue: 'sujets', sel: '' });
    if (c.tfl === 'biblio') return tflOpen({ vue: 'biblio', sel: '', bq: r.titre || '' });
    go(c.sec);
  }

  w.runExbGlobalSearch = function (q) {
    var box = d.getElementById('exbGlobalResults'); if (!box) return;
    q = (q || '').trim();
    if (!q) { box.style.display = 'none'; box.innerHTML = ''; return; }
    var r = search(q), MAX = 60;
    if (!r.length) box.innerHTML = '<div class="exb-search-item">Aucun résultat pour <b>' + esc(q) + '</b> dans les modules.</div>';
    else box.innerHTML = '<div class="exb-search-item" style="cursor:default;background:#f6f8fb"><small>' + r.length + ' résultat' + (r.length > 1 ? 's' : '') + (r.length > MAX ? ' — les ' + MAX + ' premiers sont affichés, précisez votre recherche' : '') + '</small></div>'
      + r.slice(0, MAX).map(function (x, i) { return '<div class="exb-search-item" data-i="' + i + '"><div class="exb-search-type">' + esc(x.t) + '</div><b>' + esc(x.label) + '</b>' + (x.det ? '<br><small>' + esc(x.det) + '</small>' : '') + '</div>'; }).join('');
    box._res = r;
    [].forEach.call(box.querySelectorAll('.exb-search-item[data-i]'), function (el) { el.onclick = function () { box.style.display = 'none'; open(r[Number(el.getAttribute('data-i'))]); }; });
    box.style.display = 'block';
  };
  w.exbSearchAll = search;

  /* Entrée = ouvre le premier résultat ; Ctrl+K / « / » = place le curseur dans la recherche. */
  d.addEventListener('keydown', function (e) {
    var s = d.getElementById('exbGlobalSearch'), box = d.getElementById('exbGlobalResults');
    if (!s) return;
    if (e.target === s && e.key === 'Enter' && box && box._res && box._res.length) { e.preventDefault(); box.style.display = 'none'; open(box._res[0]); }
    else if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); s.focus(); s.select(); }
  });
  var s0 = d.getElementById('exbGlobalSearch');
  if (s0) s0.placeholder = 'Rechercher partout : devis, client, étudiant TFL, encadreur, facture, projet, matricule…';
})(window);
