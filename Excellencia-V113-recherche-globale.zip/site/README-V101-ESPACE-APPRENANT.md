# V101 — Espace apprenant (frais, cours, calendrier, résultats, profil, recours)

**Page :** `espace-apprenant.html` (nouvelle). L'ancienne `apprenant.html` reste en service pour les clients (résultats, devis, plans) ; elle ignore désormais la session technique `__espace`.

**Connexion :** année académique, matricule (9 chiffres mis au format 000-000-000), mot de passe. Mêmes fonctions serveur que l'ancienne page (`apprenant_connexion`, `apprenant_changer_mdp`) : premier mot de passe 123456789, changement obligatoire avec code = 4 derniers chiffres du téléphone. Aucune limite de durée de session : l'apprenant reste connecté tant que la page est ouverte, jusqu'à « Déconnexion ». (Fermer l'onglet demande de se reconnecter : le mot de passe n'est jamais mémorisé sur l'appareil.)

**Menu (vocabulaire formation) :** Tableau de bord · Mes frais de formation · Calendrier de formation · Ma formation · Mes résultats · Mon profil · Déconnexion. Le recours s'ouvre depuis le tableau de bord et depuis « Mes résultats ».

**Ouverture unique, puis mises à jour automatiques :** une seule fois, Formation › Évaluations › **📢 Publier l'espace apprenant** (saisie du WhatsApp et des numéros de paiement). Ensuite, tant que le logiciel est connecté au serveur, il envoie tout seul (vérification toutes les 30 s, envoi des seules fiches modifiées) : paiements et reçus approuvés, séances du planning, cours, nouveaux inscrits (matricule attribué), coordonnées. Il ne reste à publier à la main que les **résultats** (📢 Publier les résultats). Hors connexion, les changements partent à la reconnexion.

**Écran des paiements :** une carte par motif (inscription, formation) avec Num. Réf. (n° du reçu), « Paiement approuvé avec succès », date, badge PAYÉ / MOITIÉ PAYÉE, et un bouton **Preuve de paiement** (PDF, qui ne remplace pas le reçu officiel) ; puis les versements enregistrés.

**Publication par l'équipe (première fois) :** Formation › Évaluations › **📢 Publier l'espace apprenant**. Pour chaque participant ayant un matricule, publie dans la session technique `__espace` : frais (dernier reçu + paiements), cours (formation, modules, formateur), calendrier (séances du planning de sa formation), coordonnées et numéro WhatsApp de l'administration (demandé à la publication). **Republier** met à jour.

**Bordereau de paiement :** depuis « Mes frais de formation », l'apprenant coche ce qu'il paie (inscription, formation : reste à payer), voit les numéros de paiement ou de caisse, et télécharge un PDF (nom, matricule, formation, montants, total par devise, numéros, référence BP-xxxx-AAAAMMJJ-HHMM). Ce n'est pas un reçu. La référence n'est pas enregistrée sur le serveur : l'apprenant l'envoie avec sa preuve de paiement (bouton WhatsApp).
À la publication, l'équipe saisit les numéros : `Caisse Excellencia : N° 001 ; Airtel Money : 0828633708 (Excellencia Building)` (mémorisés pour la fois suivante). Le reste à payer vient du statut du dernier reçu : NON PAYÉ = montant entier, MOITIÉ PAYÉE = moitié, PAYÉ = 0.

**Recours :** le message (objet, module, texte) est préparé et envoyé par WhatsApp ou copié. Il n'est PAS enregistré sur le serveur (il faudrait une nouvelle fonction SQL).

**Limites connues :** pas de paiement en ligne (l'écran « frais » affiche l'état et l'historique) ; les paiements du logiciel n'ont pas de devise (montant seul) ; la photo reste sur l'appareil ; non testé sur un vrai Supabase.

**Avant ouverture au public :** essayer avec un apprenant fictif. Vérifier que publier_resultats conserve le mot de passe d'un apprenant déjà connecté lors d'une republication.

**Mots de passe :** plus de blocage après essais ratés (script `supabase/migration-v101-apprenants-sans-blocage.sql`, à exécuter une fois). Attention : le mot de passe par défaut est le même pour tous (123456789) et les matricules ont 9 chiffres ; tant qu'un apprenant n'a pas changé son mot de passe, son espace est ouvert à qui connaît son matricule.

**Où trouver / mettre en ligne le lien de l'espace apprenant :**
- Logiciel › Formation › Inscriptions : bloc « 🎓 Espace apprenant » (Copier, WhatsApp, Partager).
- Site vitrine : bouton « 🎓 Espace apprenant » dans la section Formations (il prend l'adresse du logiciel saisie dans l'administration du site, « Publier sur le site »).
- Site vitrine › administration › « Copier les liens » : la liste contient maintenant « Espace apprenant : … ».
- Lien court : `/espace` (redirection Netlify vers `espace-apprenant.html`).
- Mise en ligne : déposer le dossier complet sur Netlify (comme d'habitude), puis, pour le site vitrine, « ⬇ Site complet (ZIP) » à redéposer.
- Attention : deux adresses existent dans le projet : `excellenciabuildingsarlu01.netlify.app` (logiciel, brand-config.js) et `excellenciabuildingsarlu.netlify.app` (valeur par défaut du site vitrine). Vérifiez que l'« adresse du logiciel » du site vitrine est la bonne avant de publier.

## V102 — Style officiel, mot de passe 1234, connexion mémorisée
- `espace-apprenant.html` : écran de connexion habillé comme les autres pages publiques (image du chantier, logo Excellencia, « Bienvenue à Excellencia Building »).
- Mot de passe par défaut **1234** ; plus de changement obligatoire ni de code des 4 derniers chiffres du téléphone. **À exécuter une fois : `supabase/migration-v102-mdp-1234-sans-code.sql`** (après la v101).
- L'appareil mémorise matricule + mot de passe (case « Garder ma connexion », cochée par défaut) et reconnecte tout seul. « Déconnexion » efface le mot de passe mémorisé (le matricule reste prérempli).
- Fiches d'inscription (apprenant, client, etc.) : l'adresse `espace-apprenant.html` et le mot de passe 1234 figurent en bas de la fiche PDF.

## V103 (suite) — mot de passe 1234 à changer à la première connexion
- Mot de passe par défaut **1234** pour apprenants, clients et formateurs ; **changement obligatoire** à la première connexion (4 caractères minimum, différent de 1234), **sans code de vérification**.
- L'appareil mémorise ensuite le mot de passe choisi et reconnecte tout seul ; « Déconnexion » l'efface.
- Un formateur n'a accès aux sujets qu'après ce changement (sinon 1234 + un matricule suffirait à modifier le catalogue).
- Scripts SQL à (ré)exécuter : `migration-v102-mdp-1234-sans-code.sql` (mis à jour) puis `migration-v103-espace-formateur.sql`.
- Espace formateur : voir la section V103 ci-dessus (publier, honoraires, sujets modifiés).
