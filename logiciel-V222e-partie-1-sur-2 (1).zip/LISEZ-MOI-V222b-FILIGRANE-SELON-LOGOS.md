# V222b — Filigrane des certificats 1 à 5 personnalisé comme les logos (base V221l + V222)

## Livré
- **V222 (BCF à deux éléments, règles IDS)** appliqué sur V221l : `exb-bcf.js`, `exb-v209-ids.js`, `sw.js`, tests, `package.json` (voir `LISEZ-MOI-V222-BCF-IDS.md`).
- **Filigrane selon les logos enregistrés** : nouveau choix « Selon mes logos (RDC, sinon Excellencia) », **par défaut** dans le réglage « Filigrane du certificat ».
  - Source : logo RDC enregistré, sinon logo Excellencia Building enregistré, sinon logo de la marque. Aucun logo = filigrane d'origine du modèle conservé.
  - La grande carte RDC pâle dessinée dans le fond est effacée (pièces nettoyées, uniquement les zones pâles : texte, bandeaux, ornements, lauriers intacts) avant la pose du logo.
  - Les autres choix (Aucun, logo Excellencia, filigrane RDC, texte) effacent aussi le filigrane dessiné dans le fond, sauf « Aucun » qui garde le fond tel quel.
  - Un choix déjà enregistré par l'utilisateur est respecté. Intensité réglable (4 à 30 %, 12 % par défaut).
- Fichiers : `exb-certificat-logos.js` (pièces `W` + `wmPatch`), `exb-certificat-filigrane.js` (mode `auto`), `sw.js` (suffixe `-v222w-`, préfixe `v221l-` inchangé), `tools/check.js`, `tools/e2e-certificat-filigrane.py`.

## Vérifications
`check.js` 983/0 échec · `e2e-certificat-filigrane.py` 63/63 · `e2e-certificat-logos.py` 18/18 · test-regles-ids 33/33 · test-coordination 36/36 · test-bcf 30/30. Rendu vérifié en capture (modèles 1 et 5).
Après déploiement : fermer complètement l'application une fois (nouveau cache).

## V222c — Partie 2 (moteur OCR) et sw.js
- Les 7 fichiers de `site/vendor/tesseract/` (partie 2 sur 2 de V209e) sont identiques à ceux déjà présents : ils sont intégrés dans cette archive complète.
- `sw.js` : liste `OCR_FILES` et préchargement **à la demande** (message `exb-precache-ocr`) ; au quotidien ils sont mis en cache à la première utilisation de l'OCR. Pas de préchargement au démarrage (≈ 18 Mo). Cache renouvelé (`-v222c-`).
- `check.js` : +4 contrôles (fichiers présents et complets, langue française gzip, chemins de `exb-ocr.js`, `sw.js`) → 987/0 échec.
- `tools/e2e-ocr-vendor.py` : essai navigateur réel, l'OCR lit « Salle de séjour 24 m² » (OK).

## V222a — correctifs reçus (fusion sans doublon)
Le lot V222a vient d'une branche plus ancienne que V221l : ses points 1 à 6 sont déjà dans V221l, sous une forme plus récente (bandeau « Réseau coupé », écran administrateur, invités / SQL v221c-d, modules Architecture, PDF d'ingénierie avec en-tête et QR, fenêtres sans popup). Ces fichiers n'ont donc **pas** été recopiés (cela aurait supprimé des fonctions de V221l).
Reporté seulement : `exb-v221-entete-modules.js` — repli sur le logo officiel (icon-192.png) quand aucun logo n'est enregistré, et en-tête plus compact (logo 78 px, nom sur une ligne). Cache : suffixe `-v222a-`.

## V222e — Équipe : connexion directe au moteur de licences
Quand l'avertissement « Les personnes invitées risquent de voir « abonnement expiré » » s'affiche (moteur de licences non connecté sur l'appareil), un bouton « 🔑 Connecter le moteur de licences » demande la clé d'administration du serveur (ADMIN-KEY-LICENCES.txt), la garde en mémoire de l'onglet, renouvelle l'abonnement transmis aux invités et le confirme.
