/* PDF Excellencia Building : logo + texte + photos JPEG (sans bibliothèque externe) */
window.EXBPdf=(function(){
  var W=595,H=842,M=44,WIN={8217:146,8216:145,8220:147,8221:148,8211:150,8212:151,8364:128,339:156,338:140,8230:133,8226:149,160:32};
  function pe(t){var o='';t=String(t==null?'':t);for(var i=0;i<t.length;i++){var c=t.charCodeAt(i);if(c===10||c===13){o+=' ';continue}if(WIN[c])c=WIN[c];else if(c>255)c=63;
    if(c===40||c===41||c===92)o+='\\'+String.fromCharCode(c);else if(c<32)o+=' ';else if(c>126)o+='\\'+('00'+c.toString(8)).slice(-3);else o+=String.fromCharCode(c)}return o}
  function wrap(t,max){var out=[];String(t==null?'':t).split(/\r?\n/).forEach(function(par){var l='';par.split(/\s+/).filter(Boolean).forEach(function(x){while(x.length>max){if(l){out.push(l);l=''}out.push(x.slice(0,max));x=x.slice(max)}if(!x)return;if(!l)l=x;else if((l+' '+x).length<=max)l+=' '+x;else{out.push(l);l=x}});out.push(l)});return out}
  function bytes(s){var u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i)&255;return u}
  function jpg(src,maxW,q){return new Promise(function(ok,ko){var im=new Image();if(/^https?:/i.test(src))im.crossOrigin='anonymous';im.onload=function(){
    var r=Math.min(maxW/im.naturalWidth,1),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.naturalWidth*r));c.height=Math.max(1,Math.round(im.naturalHeight*r));
    var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
    var d=c.toDataURL('image/jpeg',q||.75),b=atob(d.split(',')[1]),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);ok({u:u,w:c.width,h:c.height,url:d})};
    im.onerror=function(){ko(new Error('image'))};im.src=src})}
  /* File -> dataURL JPEG réduit (photos des clients) */
  function fileJpg(f,maxW,q){return new Promise(function(ok,ko){var r=new FileReader();r.onload=function(){jpg(r.result,maxW||1000,q||.7).then(function(o){ok(o.url)},ko)};r.onerror=function(){ko(new Error('lecture'))};r.readAsDataURL(f)})}
  /* o = {titre, sousTitre, rows:[[label,valeur]], notes:[], images:[dataURL], footer} -> Promise<Blob> */
  async function makeLocal(o){
    var IM=[],pages=[],ops,used,y,logo=null;
    var ID=null;try{ID=window.EXBId?EXBId.get():null}catch(e){}
    var BR=(ID&&ID.name)||(window.EXB_BRAND&&window.EXB_BRAND.name)||'Excellencia Building',SL=o.sigLabels||['Le Client','Le Directeur Général'];
    try{var l=await jpg((ID&&ID.logo)||'icon-192.png',192,.9);IM.push(l);logo=0}catch(e){try{var l2=await jpg('icon-192.png',192,.9);IM.push(l2);logo=0}catch(e2){}}
    var visa=-1,csig=-1;
    var VQ=null;try{if(o.verify!==false&&window.EXBVerif&&EXBVerif.docUrl&&window.EXBQR){var dg=(o.rows||[]).map(function(r){return r[0]+':'+r[1]}).join('|');VQ=EXBVerif.docUrl({title:o.titre||'',sub:o.sousTitre||'',digest:dg,nom:o.clientName||'',no:o.verifyNo})}}catch(e){VQ=null}
    if(o.sign!==false&&window.EXBSign){try{var vu=await (EXBSign.anyVisa?EXBSign.anyVisa('jpg'):(EXBSign.active()?EXBSign.visa('jpg'):''));if(vu){IM.push(await jpg(vu,520,.92));visa=IM.length-1}}catch(e){}}
    if(o.clientSig){try{IM.push(await jpg(o.clientSig,500,.9));csig=IM.length-1}catch(e){}}
    var ph=[];for(var i=0;i<(o.images||[]).length;i++){try{var p=await jpg(o.images[i],900,.72);IM.push(p);ph.push(IM.length-1)}catch(e){}}
    var NAVY='0.090 0.208 0.396',GOLD='0.769 0.604 0.220',GREY='0.40 0.43 0.49',LINE='0.84 0.87 0.92',SOFT='0.95 0.97 0.99',BOT=78+(VQ?64:0),LW=150,VX=M+LW+12,VW=W-M-VX-8,MAXC=Math.floor(VW/5.6);
    function T(t,x,yy,sz,b,rgb){ops.push((rgb||'0.10 0.12 0.18')+' rg BT /'+(b?'F2':'F1')+' '+sz+' Tf '+x+' '+yy+' Td ('+pe(t)+') Tj ET')}
    function D(k,x,yy,w,h){used[k]=1;ops.push('q '+w+' 0 0 '+h+' '+x+' '+yy+' cm /I'+k+' Do Q')}
    function R(x,yy,w,h,rgb){ops.push(rgb+' rg '+x+' '+yy+' '+w+' '+h+' re f')}
    function RS(x,yy,w,h,rgb,lw){ops.push(rgb+' RG '+(lw||.6)+' w '+x+' '+yy+' '+w+' '+h+' re S')}
    function logoBox(x,yy,box){R(x,yy,box,box,'1 1 1');if(logo!==null){var m=IM[logo],w=box-8,h=w*m.h/m.w;if(h>box-8){h=box-8;w=h*m.w/m.h}D(logo,x+(box-w)/2,yy+(box-h)/2,w,h)}}
    var k=0;
    function np(){ops=[];used={};pages.push({ops:ops,used:used});var first=pages.length===1;k=0;
      if(first){R(0,H-110,W,110,NAVY);R(0,H-114,W,4,GOLD);logoBox(M,H-98,84);var tx=M+102;
        var bs=Math.max(13,Math.min(25,Math.floor(400/(BR.length*0.66))));T(BR.toUpperCase(),tx,H-50,bs,true,'1 1 1');T(o.titre||'',tx,H-76,12.5,true,'0.95 0.82 0.40');
        if(o.sousTitre)T(o.sousTitre,tx,H-95,9.5,false,'0.80 0.86 0.95');y=H-114-30}
      else{R(0,H-50,W,50,NAVY);R(0,H-53,W,3,GOLD);logoBox(M,H-44,38);T(BR.toUpperCase().slice(0,42),M+52,H-28,13,true,'1 1 1');T(o.titre||'',M+52,H-42,8.5,false,'0.95 0.82 0.40');y=H-53-28}}
    /* ===== Page de garde standard (même style que le certificat, contour agrandi) — désactivable avec o.cover===false ===== */
    var COVER=o.cover!==false;
    /* Visa unique : si la page de garde porte déjà cachet + signature (tous les documents), les pages suivantes ne les répètent pas : seul le QR de vérification suit. */
    var COVERVISA=COVER&&visa>=0;
    var _cx=null;function tw(t,sz,b){try{if(!_cx&&typeof document!=='undefined')_cx=document.createElement('canvas').getContext('2d');if(_cx){_cx.font=(b?'bold ':'')+sz+'px Helvetica, Arial, sans-serif';return _cx.measureText(String(t)).width}}catch(e){}return String(t).length*sz*(b?.56:.52)}
    function fitSz(t,maxW,b,maxSz){var u=tw(String(t),100,b)/100;return u>0?Math.min(maxSz,maxW/u):maxSz}
    function wrapW(t,maxW,sz,b){var out=[];String(t==null?'':t).split(/\r?\n/).forEach(function(par){var l='';par.split(/\s+/).filter(Boolean).forEach(function(x){if(!l)l=x;else if(tw(l+' '+x,sz,b)<=maxW)l+=' '+x;else{out.push(l);l=x}});out.push(l)});return out}
    function TXc(t,x,yy,sz,b,rgb,al,cs){t=String(t==null?'':t);cs=cs||0;var wd=tw(t,sz,b)+cs*Math.max(0,t.length-1);if(al==='r')x-=wd;else if(al==='c')x-=wd/2;ops.push((rgb||'0.10 0.12 0.18')+' rg BT /'+(b?'F2':'F1')+' '+sz+' Tf '+(cs?cs.toFixed(2)+' Tc ':'')+x.toFixed(2)+' '+yy.toFixed(2)+' Td ('+pe(t)+') Tj '+(cs?'0 Tc ':'')+'ET')}
    function drawCover(){
      ops=[];used={};pages.push({ops:ops,used:used,cover:true});
      var CX0=W/2,RX=W-66,dark='0.10 0.12 0.18',SG='0.93 0.88 0.72',yy;
      RS(14,14,W-28,H-28,NAVY,9);RS(24,24,W-48,H-48,GOLD,2.4);RS(33,33,W-66,H-66,SG,9);RS(46,46,W-92,H-92,GOLD,1);RS(49,49,W-98,H-98,'0.90 0.82 0.58',.4);
      var big=String(BR).toUpperCase();TXc(big,CX0,H-96,fitSz(big,400,true,25),true,NAVY,'c',1.5);
      if(ID&&ID.tagline){var tg=String(ID.tagline).slice(0,80);TXc(tg,CX0,H-112,fitSz(tg,380,false,10),false,GREY,'c')}
      R(CX0-70,H-124,140,1.2,GOLD);
      if(logo!==null){var m=IM[logo],lw=200,lh=lw*m.h/m.w;if(lh>160){lh=160;lw=lh*m.w/m.h}D(logo,CX0-lw/2,H-138-lh,lw,lh)}
      var tt=String(o.titre||'DOCUMENT').toLocaleUpperCase('fr-FR'),fs=26,L=wrapW(tt,410,fs,true);while(L.length>2&&fs>13){fs--;L=wrapW(tt,410,fs,true)}
      if(L.length>3)L=L.slice(0,3);
      var stp=fs*1.22;yy=H-332;L.forEach(function(l,i){TXc(l,CX0,yy-i*stp,fs,true,NAVY,'c',L.length>1?0:2)});yy-=(L.length-1)*stp;
      if(o.sousTitre){wrapW(o.sousTitre,410,10.5,false).slice(0,2).forEach(function(l,i){TXc(l,CX0,yy-20-i*13,10.5,false,GOLD,'c')});yy-=20+(Math.min(2,wrapW(o.sousTitre,410,10.5,false).length)-1)*13}
      yy-=16;R(CX0-110,yy,220,1,GOLD);
      var cr=[];if(o.clientName)cr.push([String(o.clientName).slice(0,60),true]);
      (o.rows||[]).forEach(function(r){if(/t[ée]l|mail|adresse|phone|contact/i.test(String(r[0]||''))&&String(r[1]||'').trim()&&cr.length<5)cr.push([String(r[0])+' : '+String(r[1]).slice(0,70),false])});
      if(cr.length){yy-=26;TXc('COORDONNÉES',CX0,yy,8.5,true,GOLD,'c',2.5);R(CX0-70,yy-6,140,.8,LINE);var lh2=Math.min(15,Math.max(11,(yy-6-276)/cr.length));cr.forEach(function(r,i){TXc(r[0],CX0,yy-22-i*lh2,r[1]?12:9.5,r[1],r[1]?NAVY:dark,'c')})}
      var dl='Fait à '+((ID&&ID.city)||'…………………')+' — Date de délivrance : '+(o.dateLivraison||new Date().toLocaleDateString('fr-FR'));
      var sw=217,sx=RX-sw,ly=160,vh=0;
      if(visa>=0){var mv=IM[visa],vw=sw-6;vh=vw*mv.h/mv.w;if(vh>84){vh=84;vw=vh*mv.w/mv.h}D(visa,sx+(sw-vw)/2,ly-20,vw,vh)}
      TXc(dl,RX,ly+(visa>=0?vh-20:50)+16,10,false,dark,'r');
      R(sx,ly,sw,.9,NAVY);TXc(SL[1],sx+sw/2,ly-12,8.5,true,NAVY,'c');
      var sr=(window.EXBDocs&&EXBDocs.signer)?EXBDocs.signer(!(!o.sigLabels||/direct/i.test(String(SL[1])))):null;
      var snm=o.signerName||(sr&&sr.name)||'';if(snm)TXc(String(snm).slice(0,40),sx+sw/2,ly-25,fitSz(snm,sw,true,9.5),true,dark,'c');
      if((o.signerRole||(sr&&sr.role)))TXc(String(o.signerRole||sr.role).slice(0,44),sx+sw/2,ly-37,8,false,GREY,'c');
    }
    if(COVER)drawCover();
    np();
    T('INFORMATIONS',M,y,10,true,NAVY);R(M+84,y+3,W-2*M-84,1.2,GOLD);y-=12;
    (o.rows||[]).forEach(function(r){
      var L=wrap(r[1]==null||r[1]===''?'—':r[1],MAXC),lab=String(r[0]||'').toUpperCase(),cont=false;
      while(L.length){
        var n=Math.floor((y-BOT-14)/15);if(n<1){np();T('INFORMATIONS (suite)',M,y,10,true,NAVY);R(M+130,y+3,W-2*M-130,1.2,GOLD);y-=12;n=Math.floor((y-BOT-14)/15)}
        var ch=L.splice(0,Math.min(n,L.length)),rh=Math.max(30,ch.length*15+14);
        R(M,y-rh,W-2*M,rh,k%2?'0.985 0.99 1':'1 1 1');R(M,y-rh,LW,rh,SOFT);RS(M,y-rh,W-2*M,rh,LINE);
        ops.push(LINE+' RG .6 w '+(M+LW)+' '+(y-rh)+' m '+(M+LW)+' '+y+' l S');
        var lb=wrap(lab+(cont?' (SUITE)':''),26);T(lb[0],M+10,y-rh/2-3+(lb.length>1?5:0),8.5,true,NAVY);if(lb[1])T(lb[1],M+10,y-rh/2-8,8.5,true,NAVY);
        ch.forEach(function(line,j){T(line,VX,y-19-j*15,11,false)});
        y-=rh;k++;cont=true}
    });
    y-=20;
    var nn=(o.notes||[]).map(function(t){return wrap(t,96)}),nh=nn.reduce(function(a,L){return a+L.length*12.5+5},0)+30;
    if(nn.length){if(y-nh<BOT)np();
      R(M,y-nh,W-2*M,nh,'0.995 0.975 0.90');R(M,y-nh,5,nh,GOLD);T('À RETENIR',M+18,y-18,9.5,true,'0.55 0.40 0.03');var ny=y-34;
      nn.forEach(function(L){L.forEach(function(l){T(l,M+18,ny,9.5,false,'0.25 0.25 0.25');ny-=12.5});ny-=5});y-=nh+20}
    if(ph.length){if(y<BOT+230)np();T(o.imagesTitle||'PHOTOS',M,y,10,true,NAVY);R(M+56,y+3,W-2*M-56,1.2,GOLD);y-=14;
      ph.forEach(function(q,i){var im=IM[q],w=240,h=w*im.h/im.w;if(h>180){h=180;w=h*im.w/im.h}
        if(i%2===0&&y-196<BOT)np();var col=i%2,x=M+col*258;RS(x-3,y-h-3,w+6,h+6,LINE,1);D(q,x,y-h,w,h);if(col===1||i===ph.length-1)y-=200})}
    if(COVERVISA?(csig>=0||o.signBlock||!!o.sigLabels):(visa>=0||csig>=0||o.signBlock)){if(y<BOT+182)np();y=Math.min(y-10,BOT+172);
      if(o.signBlock){T('Fait à '+((ID&&ID.city)||'…………………………')+', le '+new Date().toLocaleDateString('fr-FR'),M,y,10,false,GREY);y-=22}
      var cw=(W-2*M-30)/2,bx=[M,M+cw+30];
      (COVERVISA?[[SL[0],csig]]:[[SL[0],csig],[SL[1],visa]]).forEach(function(c,ci){var x0=bx[ci],ix=c[1];
        if(ix>=0){var im=IM[ix],w=Math.min(cw-20,ci?190:170),h=w*im.h/im.w;if(h>96){h=96;w=h*im.w/im.h}D(ix,x0+(cw-w)/2,ci?y-112:y-h-4,w,h)}
        R(x0,y-108,cw,.8,'0.50 0.55 0.62');var t=c[0];T(t,x0+cw/2-t.length*2.4,y-121,9.5,true,NAVY);
        if(ci===1&&ID&&ID.dg&&(!o.sigLabels||/direct/i.test(String(SL[1]))))T(String(ID.dg).slice(0,40),x0+cw/2-Math.min(40,String(ID.dg).length)*2.2,y-134,9,false,GREY);
        if(ci===0&&o.clientName)T(String(o.clientName).slice(0,40),x0+cw/2-Math.min(40,String(o.clientName).length)*2.2,y-134,9,false,GREY)});
      y-=150}
    var pg=pages.length;pages.forEach(function(p,i){var save=ops;ops=p.ops;used=p.used;
      if(p.cover){var c0=ID?[ID.phone,ID.email].filter(Boolean).join('   '):'',p0='',g0='';try{p0=window.EXBId?EXBId.placeLine(ID):''}catch(e){}try{g0=window.EXBId?EXBId.legalLine(ID):''}catch(e){}
        if(c0)TXc(c0,66,96,fitSz(c0,330,false,8),false,GREY);if(p0)TXc(p0,66,85,fitSz(p0,330,false,7.5),false,GREY);if(g0)TXc(g0,66,74,fitSz(g0,330,false,6.5),false,GREY);
        TXc('Page 1 / '+pg,W-66,96,8.5,true,NAVY,'r');
        /* QR de vérification aussi sur la page de garde (bas gauche, face au cachet et à la signature) */
        if(VQ){try{var cq=60,cx2=66,cy2=112,tx2=cx2+cq+9;ops.push(EXBVerif.qrOps(VQ.url,cx2,cy2,cq));TXc('Scannez ce QR pour vérifier',tx2,cy2+44,8.5,true,NAVY);TXc('l\u2019authenticité de ce document',tx2,cy2+32,8.5,true,NAVY);TXc('Code '+String(VQ.hash).toUpperCase(),tx2,cy2+19,7.5,false,GREY)}catch(e){}}
        ops=save;return}
      R(0,0,W,6,NAVY);R(M,52,W-2*M,.8,LINE);
      var ct=ID?[ID.phone,ID.email].filter(Boolean).join(' — '):'',f1=(o.footer||BR)+(ct?' — '+ct:''),f2=ID?[window.EXBId?EXBId.placeLine(ID):'',window.EXBId?EXBId.legalLine(ID):''].filter(Boolean).join('  |  '):'';
      if(VQ&&(i===pg-1||COVERVISA)){try{var qs=58,qx=W-M-qs,qy=58;ops.push(EXBVerif.qrOps(VQ.url,qx,qy,qs));T('Scannez ce QR pour vérifier',qx-8-'Scannez ce QR pour vérifier'.length*4.9,qy+36,8.5,true,NAVY);T('l\u2019authenticité de ce document',qx-8-'l\u2019authenticité de ce document'.length*4.9,qy+24,8.5,true,NAVY);T('Code '+String(VQ.hash).toUpperCase(),qx-8-('Code '+VQ.hash).length*4.2,qy+11,7.5,false,GREY)}catch(e){}}
      T(f1.slice(0,92),M,38,8.5,false,GREY);if(f2)T(f2.slice(0,125),M,26,7,false,GREY);
      var pt='Page '+(i+1)+' / '+pg;T(pt,W-M-pt.length*4.6,36,8.5,true,NAVY);ops=save});
    var ch=[],pos=0,off=[],N=4+IM.length+2*pages.length;
    function P(x){var u=typeof x==='string'?bytes(x):x;ch.push(u);pos+=u.length}
    function O(n,head,stream){off[n]=pos;P(n+' 0 obj\n'+head);if(stream){P('\nstream\n');P(stream);P('\nendstream')}P('\nendobj\n')}
    P('%PDF-1.4\n');
    O(1,'<< /Type /Catalog /Pages 2 0 R /ViewerPreferences << /PrintScaling /None >> >>');
    var kids=[],pb=5+IM.length;pages.forEach(function(p,i){kids.push((pb+2*i)+' 0 R')});
    O(2,'<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+pages.length+' >>');
    O(3,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    O(4,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    IM.forEach(function(m,i){O(5+i,'<< /Type /XObject /Subtype /Image /Width '+m.w+' /Height '+m.h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+m.u.length+' >>',m.u)});
    pages.forEach(function(p,i){var n=pb+2*i,xo=Object.keys(p.used).map(function(k){return '/I'+k+' '+(5+Number(k))+' 0 R'}).join(' '),c=bytes('q 0.94 0 0 0.94 17.85 25.26 cm\n'+p.ops.join('\n')+'\nQ');
      O(n,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+W+' '+H+'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << '+xo+' >> >> /Contents '+(n+1)+' 0 R >>');
      O(n+1,'<< /Length '+c.length+' >>',c)});
    var xr=pos,x='xref\n0 '+(N+1)+'\n0000000000 65535 f \n';for(var j=1;j<=N;j++)x+=('0000000000'+off[j]).slice(-10)+' 00000 n \n';
    P(x+'trailer\n<< /Size '+(N+1)+' /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF');
    return new Blob(ch,{type:'application/pdf'})}
  function save(blob,name){var u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},4000)}
  /* V118 : point d'entrée UNIQUE. Le Centre documentaire (profil, historique, rendu serveur) prend la main ; sans lui, l'écrivain local ci-dessus produit le PDF. */
  function make(o){try{if(window.exbRebrandDeep&&o&&!o.__rb){o=window.exbRebrandDeep(o);o.__rb=1}}catch(e){}var E=window.EXBDocEngine;if(E&&E.make&&!(o&&o.engine==='local'))return E.make(o||{},makeLocal);return makeLocal(o)}
  return {make:make,makeLocal:makeLocal,save:save,fileJpg:fileJpg}
})();
