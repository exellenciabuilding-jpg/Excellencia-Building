/* Fabrique les 4 livrables, chacun prêt à déposer (ZIP) :
 *   1-PROPRIETAIRE-GITHUB   → VOTRE dépôt GitHub privé (tout : application propriétaire, serveur de licences, génération de licences)
 *   2-PROPRIETAIRE-NETLIFY  → VOTRE site Netlify privé (logiciel verrouillé ; vous y entrez avec votre clé privée)
 *   3-CLIENT-GITHUB         → dépôt GitHub privé du client (construit l'APK ; AUCUN outil de licences, AUCUNE clé)
 *   4-CLIENT-NETLIFY        → site Netlify du client (verrouillé : code d'activation ; aucun espace de création de licences)
 * Usage : node scripts/make-livrables.js [nom-du-client] [chemin/entreprise.json]
 * À relancer après « node licence-server/setup.js init … » (l'adresse du serveur et la clé PUBLIQUE sont alors reprises dans les éditions). */
const fs = require('fs'), path = require('path'), cp = require('child_process');
const root = path.join(__dirname, '..'), out = path.join(root, 'livrables');
const client = (process.argv[2] || 'client').replace(/[^a-z0-9\-_]/gi, '-').toLowerCase();
const ent = process.argv[3] ? path.resolve(process.argv[3]) : (fs.existsSync(path.join(root, 'clients', client, 'entreprise.json')) ? path.join(root, 'clients', client, 'entreprise.json') : path.join(root, 'site', 'entreprise.json'));
const die = (m) => { console.error('\nERREUR : ' + m); process.exit(1); };
const SO = require('./strip-owner.js');
const rm = (p) => fs.rmSync(p, { recursive: true, force: true });
const SKIP = new Set(['node_modules', '.git', 'dist', 'www', 'android', 'livrables', 'dist-site']);
function copy(a, b, filt) { fs.mkdirSync(b, { recursive: true }); for (const e of fs.readdirSync(a, { withFileTypes: true })) { const s = path.join(a, e.name), d = path.join(b, e.name); if (SKIP.has(e.name) && a === root) continue; if (filt && !filt(s)) continue; e.isDirectory() ? copy(s, d, filt) : fs.copyFileSync(s, d); } }
function zip(dir, name) { const z = path.join(out, name + '.zip'); rm(z); cp.execFileSync('zip', ['-qr', z, '.'], { cwd: dir }); console.log('  ✔ ' + path.relative(root, z)); }

rm(out); fs.mkdirSync(out, { recursive: true });
const tmp = path.join(out, '.tmp'); fs.mkdirSync(tmp);

/* éditions du site (public + propriétaire), avec l'identité du client */
cp.execFileSync('node', [path.join(__dirname, 'build-editions.js'), ent], { cwd: root, stdio: 'inherit' });
const dist = path.join(root, 'dist');

/* 2 et 4 : Netlify */
const nOwn = path.join(tmp, 'n2'); copy(path.join(dist, 'proprietaire'), nOwn); zip(nOwn, '2-PROPRIETAIRE-NETLIFY-site-prive');
const nCli = path.join(tmp, 'n4'); copy(path.join(dist, 'public'), nCli); zip(nCli, '4-CLIENT-NETLIFY-site-client-' + client);

/* 1 : GitHub propriétaire = tout le projet, sans les secrets ni les dossiers générés */
const g1 = path.join(tmp, 'g1');
copy(root, g1, (s) => !/(ADMIN-KEY-LICENCES\.txt|CLE-PRIVEE-ADMIN\.txt|SAUVEGARDE-CLE-.*\.json|supabase-secrets\.env)$/i.test(s));
fs.writeFileSync(path.join(g1, 'LISEZ-MOI-DEPOT-PROPRIETAIRE.md'), '# Dépôt PROPRIÉTAIRE — privé, pour vous seul\nContient tout : site, application propriétaire (EXE), serveur de licences, génération de licences, workflows.\nNe jamais le donner à un client. Les clés (ADMIN-KEY-LICENCES.txt, CLE-PRIVEE-ADMIN.txt, SAUVEGARDE-CLE-*.json) ne vont JAMAIS sur GitHub (.gitignore).\nPour fabriquer les livrables : `node scripts/make-livrables.js nom-du-client`.\n');
zip(g1, '1-PROPRIETAIRE-GITHUB-depot-prive');

/* 3 : GitHub client = projet sans aucun outil propriétaire */
const g3 = path.join(tmp, 'g3'); fs.mkdirSync(g3);
for (const f of ['package.json', 'capacitor.config.json', 'licence-serveur.json']) fs.copyFileSync(path.join(root, f), path.join(g3, f));
for (const d of ['resources', 'native', 'electron']) copy(path.join(root, d), path.join(g3, d), (s) => !/node_modules|[\\/]dist$|[\\/]www$/.test(s));
fs.mkdirSync(path.join(g3, 'scripts'));
for (const f of ['apply-brand.js', 'apply-licence.js', 'build-www.js', 'patch-android.js', 'strip-owner.js']) fs.copyFileSync(path.join(__dirname, f), path.join(g3, 'scripts', f));
copy(path.join(root, 'site'), path.join(g3, 'site'), (s) => !/[\\/]site[\\/](site-vitrine|tools)([\\/]|$)/.test(s));
/* licence-config.js du dépôt client = celui de l'édition publique (serveur + clé publique) */
fs.copyFileSync(path.join(dist, 'public', 'licence-config.js'), path.join(g3, 'site', 'licence-config.js'));
SO.stripDir(path.join(g3, 'site'));
fs.mkdirSync(path.join(g3, 'clients', client), { recursive: true }); fs.copyFileSync(ent, path.join(g3, 'clients', client, 'entreprise.json'));
const pj = JSON.parse(fs.readFileSync(path.join(g3, 'package.json'), 'utf8')); delete pj.scripts['test:licences']; delete pj.scripts['build:editions']; fs.writeFileSync(path.join(g3, 'package.json'), JSON.stringify(pj, null, 2));
fs.mkdirSync(path.join(g3, '.github', 'workflows'), { recursive: true });
for (const w of ['apk-client.yml', 'windows-client.yml']) { let t = fs.readFileSync(path.join(root, '.github', 'workflows', w), 'utf8'); t = t.replace(/\n {6}- name: Test de la licence[^\n]*\n {8}run: node scripts\/test-licence\.js/, ''); fs.writeFileSync(path.join(g3, '.github', 'workflows', w), t); }
fs.writeFileSync(path.join(g3, '.gitignore'), 'node_modules/\nwww/\nandroid/\nelectron/www/\nelectron/dist/\ndist/\n*.apk\n*.aab\n.DS_Store\n');
fs.writeFileSync(path.join(g3, 'LISEZ-MOI-CLIENT.md'), '# Dépôt CLIENT (privé) — ' + client + '\nAucun outil de génération de licences, aucune clé privée.\n1. Déposez ce dossier sur GitHub (dépôt privé).\n2. GitHub › Actions › « Application Android (APK) » › Run workflow › client = `' + client + '`.\n3. Téléchargez l\'APK (artefact) et remettez-le au client.\n4. Au lancement, le client voit « Ce logiciel nécessite un code d\'activation » avec le **code de cet appareil** : il vous l\'envoie ; vous lui répondez avec son code EXC-XXXX-XXXX-XXXX.\n');
/* contrôle : rien de propriétaire dans le dépôt client */
const bad = []; (function w(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { if (/^(owner-app|licence-server|owner-licences|provisioning)$/.test(e.name)) bad.push(p); w(p); } else if (/\.(js|html?|json|ya?ml|md)$/i.test(e.name)) { const t = fs.readFileSync(p, 'utf8'); if (!/strip-owner\.js$/.test(p) && /x-admin-key|admin\.create|admin\.release_device|ADMIN-KEY|subtle\.sign/.test(t)) bad.push(p); } } })(g3);
if (bad.length) die('Dépôt client NON conforme :\n - ' + bad.join('\n - '));
zip(g3, '3-CLIENT-GITHUB-depot-prive-' + client);
rm(tmp);
console.log('\n✔ 4 livrables dans livrables/ (client : ' + client + ').');
