# Guide — livrer le logiciel à un nouveau client (V120e)

Tout se fait avec ce qui existe déjà dans le logiciel. Aucun compte ni serveur n'est obligatoire pour que les PDF fonctionnent.

## 1. Préparer l'identité du client (un seul endroit)
1. Ouvrez le logiciel (votre exemplaire), puis **⚙️ Paramètres › 🏢 Identité de l'entreprise**.
2. Remplissez : nom, logo, 3 couleurs, téléphone, e-mail, adresse, mentions légales, dirigeant.
3. **Enregistrer**, puis **⬇️ Télécharger entreprise.json**.
4. Le **Centre documentaire** reprend automatiquement ces informations : en-tête de tous les PDF, devis, factures, reçus. Aucune ressaisie.

## 2. Déployer pour lui (Netlify)
Utilisez le workflow **Site Netlify** (Actions › Run workflow › client = nom du dossier) : il fabrique automatiquement l'**édition client** (sans générateur de licences ni clé privée) et la publie.
À la main : `cp -r site dist-site && node scripts/strip-owner.js dist-site`, puis déposez **dist-site** (jamais `site/`) sur Netlify. Dans `dist-site/brand-config.js`, `setupRequired:false`.

## 3. L'application (Android / Windows)
Workflows **Application Android (APK)** et **Application Windows (EXE)** (Actions › Run workflow › client = nom du dossier). Ils appliquent l'identité du client, **retirent tout outil propriétaire** et testent la licence avant de compiler. En local : `npm run android:debug` ou `cd electron && npm run dist` (même résultat ; `EXB_OWNER=1` garde l'édition propriétaire pour VOTRE exemplaire, à ne jamais livrer).

## 4. Licence du client (V120o : serveur de licences)
1. Une fois : installez le serveur de licences (`licence-server/LISEZ-MOI.md`) et l'application propriétaire.
2. Par client : `node provisioning/nouveau-client.js --fiche provisioning/<client>.json --publier` → code `EXC-XXXX-XXXX-XXXX` (2 appareils par défaut, modifiable dans l'application propriétaire).
3. Le client installe, saisit son code : ses appareils s'enregistrent tout seuls. Plus de code appareil à demander.
4. Renouveler, suspendre, révoquer, libérer un appareil : application « Excellencia Licences » (le renouvellement arrive tout seul chez le client).
5. Ancien mode hors serveur (V120n) : voir `LISEZ-MOI-V120n-LICENCES.md` (option `--cle`).

## 5. Comptes en ligne (facultatif)
Pour des comptes et la gestion par organisation, créez un projet Supabase pour le client, exécutez `schema-entreprise.sql` puis `migration-v118-moteur-documentaire.sql`, et renseignez l'URL et la clé dans l'identité de l'entreprise. Vous créez les comptes et gardez la main sur l'administration.

## 6. Serveur PDF (facultatif)
Sans serveur, les PDF sont produits dans le navigateur avec le même moteur. Le serveur (dossier `docengine-server`) apporte un rendu Chromium plus fidèle et les PDF remplissables ; voir `DOCENGINE-LISEZ-MOI.md`.

## 7. Réglages par client
- En-tête du profil sur tous les PDF : **Centre documentaire › Paramètres** (activé par défaut, chaque client peut le désactiver).
- Numérotation, mise en page par défaut, modèles personnalisés : Centre documentaire.
