/* Test automatique de la licence (V120n) — node scripts/test-licence.js
 * Génère une paire de clés DE TEST, remplace la clé publique dans le code, puis vérifie :
 *   édition propriétaire : une fausse clé admin ne déverrouille plus
 *   édition client       : code valide / modifié / expiré / signé par un tiers / lié à un autre appareil / lié à CET appareil
 * La vraie clé privée n'est jamais utilisée ici. */
const fs = require('fs'), path = require('path'), vm = require('vm');
const { clientLicense } = require('./strip-owner.js');
const ROOT = path.join(__dirname, '..');
const subtle = globalThis.crypto.subtle;
const b64u = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
let fail = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) fail++; };

async function newKey() {
  const kp = await subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  return { pub: await subtle.exportKey('jwk', kp.publicKey), priv: await subtle.exportKey('jwk', kp.privateKey), kp };
}
async function sign(k, p) {
  const bytes = new TextEncoder().encode(JSON.stringify(p));
  const sg = await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, k.kp.privateKey, bytes);
  return b64u(bytes) + '.' + b64u(sg);
}
function load(src, pub, store) {
  src = src.replace(/var PUB=\{[^}]*\};/, 'var PUB=' + JSON.stringify({ kty: 'EC', crv: 'P-256', x: pub.x, y: pub.y }) + ';');
  const mem = Object.assign({}, store || {}), ses = {};
  const mk = o => ({ getItem: k => (k in o ? o[k] : null), setItem: (k, v) => { o[k] = String(v); }, removeItem: k => { delete o[k]; } });
  const el = () => ({ style: {}, setAttribute() {}, getAttribute() { return null; }, appendChild() {}, remove() {}, firstChild: null, innerHTML: '', onclick: null, addEventListener() {} });
  const w = { crypto: globalThis.crypto, localStorage: mk(mem), sessionStorage: mk(ses), EXB_LICENSE_CONFIG: { requireToken: true, warnDays: 7, defaultGrace: 0, contact: 'le propriétaire' },
    addEventListener() {}, setTimeout: () => 0, location: { hash: '', search: '', pathname: '/', reload() { w.__reloaded = true; } }, history: { replaceState() {} }, alert() {}, prompt() {} };
  w.window = w;
  const ctx = vm.createContext(Object.assign(w, { document: { getElementById: () => el(), createElement: el, body: { appendChild() {} }, addEventListener() {}, hidden: false, readyState: 'complete' },
    navigator: { onLine: false }, setInterval: () => 0, setTimeout: () => 0, TextEncoder, TextDecoder, atob, btoa, Uint8Array, Date, JSON, Math, console, fetch: async () => { throw 0; } }));
  vm.runInContext(src, ctx);
  return { w, mem };
}
const day = 864e5, iso = ms => new Date(Date.now() + ms).toISOString();

(async () => {
  const K = await newKey(), OTHER = await newKey();
  const ownerSrc = fs.readFileSync(path.join(ROOT, 'site', 'exb-license.js'), 'utf8');
  const clientSrc = clientLicense(ownerSrc);

  console.log('Édition propriétaire — fausses clés administrateur');
  let o = load(ownerSrc, K.pub, { exb_lic_priv: JSON.stringify({ d: 'x', x: K.pub.x }) });
  ok(o.w.EXBLIC.isAdmin() === false, 'clé forgée {"d":"x","x":…} (l\'ancien contournement) refusée');
  o = load(ownerSrc, K.pub, { exb_lic_priv: JSON.stringify({ kty: 'EC', crv: 'P-256', x: K.pub.x, y: K.pub.y, d: 'A'.repeat(43) }) });
  ok(o.w.EXBLIC.isAdmin() === true, 'clé de bonne forme acceptée un instant…');
  await new Promise(r => setTimeout(r, 300));
  ok(o.w.EXBLIC.isAdmin() === false && !o.mem.exb_lic_priv, '…puis révoquée et effacée dès que la signature de contrôle échoue');
  o = load(ownerSrc, K.pub, { exb_lic_priv: JSON.stringify(K.priv) });
  await new Promise(r => setTimeout(r, 300));
  ok(o.w.EXBLIC.isAdmin() === true, 'la vraie clé du propriétaire reste acceptée');

  console.log('Édition client');
  const c0 = load(clientSrc, K.pub);
  ok(c0.w.EXBLIC.isAdmin() === false, 'aucun rôle administrateur');
  ok(typeof c0.w.EXBLIC.make === 'function' && await c0.w.EXBLIC.make({}).then(() => false, () => true), 'impossible de générer un code');
  ok(!/exb_lic_priv|subtle\.sign/.test(clientSrc), 'aucun code de signature ni clé privée dans le fichier');
  const me = c0.w.EXBLIC.deviceId().replace(/-/g, '');
  ok(/^[A-Z2-9]{12}$/.test(me), 'code appareil généré : ' + c0.w.EXBLIC.deviceId());

  const base = { v: 1, name: 'Client A', exp: iso(30 * day), grace: 0, iat: iso(0), id: 'abc' };
  const run = async (p, key, tweak) => {
    let t = await sign(key || K, p); if (tweak) t = tweak(t);
    const c = load(clientSrc, K.pub, { exb_dev_id: me });
    const a = await c.w.EXBLIC.apply(t); c.w.EXBLIC; const st = await c.w.EXBLIC.state();
    return { a, st };
  };
  let r = await run(base);                                   ok(r.a.ok && r.st.mode === 'ok', 'code valide, sans appareil lié : accepté');
  r = await run(base, OTHER);                                ok(!r.a.ok, 'code signé par une autre clé : refusé');
  r = await run(base, K, t => { const [p, s] = t.split('.'); const j = JSON.parse(Buffer.from(p, 'base64')); j.exp = iso(999 * day); return b64u(Buffer.from(JSON.stringify(j))) + '.' + s; });
  ok(!r.a.ok, 'date d\'expiration modifiée par le client : refusé');
  r = await run(Object.assign({}, base, { exp: iso(-2 * day) })); ok(!r.a.ok, 'code déjà expiré : refusé');
  r = await run(Object.assign({}, base, { dev: ['ZZZZ-ZZZZ-ZZZZ'] })); ok(!r.a.ok && /autre appareil/.test(r.a.msg) && r.a.msg.includes(c0.w.EXBLIC.deviceId()), 'code lié à un AUTRE appareil : refusé, avec rappel du code appareil');
  r = await run(Object.assign({}, base, { dev: [me.slice(0, 4) + '-' + me.slice(4, 8) + '-' + me.slice(8)] })); ok(r.a.ok && r.st.mode === 'ok', 'code lié à CET appareil : accepté');
  r = await run(Object.assign({}, base, { dev: ['ZZZZ-ZZZZ-ZZZZ', me] }));    ok(r.a.ok, 'liste de plusieurs appareils contenant celui-ci : accepté');
  /* code accepté puis copié sur un autre appareil (stockage recopié sans le code appareil) */
  const t = await sign(K, Object.assign({}, base, { dev: [me] }));
  const clone = load(clientSrc, K.pub, { exb_lic_token: t, exb_dev_id: 'QQQQQQQQQQQQ' });
  ok((await clone.w.EXBLIC.state()).mode === 'locked' && (await clone.w.EXBLIC.state()).reason === 'device', 'jeton recopié sur un autre appareil : verrouillé');
  const none = load(clientSrc, K.pub);
  ok((await none.w.EXBLIC.state()).mode === 'locked', 'sans code : verrouillé');

  console.log(fail ? '\n' + fail + ' ÉCHEC(S)' : '\nTous les tests de licence passent.');
  process.exit(fail ? 1 : 0);
})();
