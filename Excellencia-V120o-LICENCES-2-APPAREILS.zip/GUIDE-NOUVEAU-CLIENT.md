# Guide — livrer le logiciel à un nouveau client (V120e)

Tout se fait avec ce qui existe déjà dans le logiciel. Aucun compte ni serveur n'est obligatoire pour que les PDF fonctionnent.

## 1. Préparer l'identité du client (un seul endroit)
1. Ouvrez le logiciel (votre exemplaire), puis **⚙️ Paramètres › 🏢 Identité de l'entreprise**.
2. Remplissez : nom, logo, 3 couleurs, téléphone, e-mail, adresse, mentions légales, dirigeant.
3. **Enregistrer**, puis **⬇️ Télécharger entreprise.json**.
4. Le **Centre documentaire** reprend automatiquement ces informations : en-tête de tous les PDF, devis, factures, reçus. Aucune ressaisie.

## 2. Déployer pour lui (Netlify)
Utilisez le workflow **Site Netlify** (Actions › Run workflow › client = nom du dossier) : il fabrique automatiquement l'**édition client** (sans générateur de licences ni clé privée) et la publie.
À la main : `cp -r site dist-site && node scripts/strip-owner.js dist-site`, puis déposez **dist-site** (jamais `site/`) sur Netlify. Dans `dist-site/brand-config.js`, `setupRequired:false`.

## 3. L'application (Android / Windows)
Workflows **Application Android (APK)** et **Application Windows (EXE)** (Actions › Run workflow › client = nom du dossier). Ils appliquent l'identité du client, **retirent tout outil propriétaire** et testent la licence avant de compiler. En local : `npm run android:debug` ou `cd electron && npm run dist` (même résultat ; `EXB_OWNER=1` garde l'édition propriétaire pour VOTRE exemplaire, à ne jamais livrer).

## 4. Licence du client (code signé, lié à son appareil)
1. Le client installe l'application. Sur l'écran **« Logiciel verrouillé »** s'affiche son **code appareil** (ex. 4Z7G-DXSE-K4CJ) : il vous l'envoie.
2. Sur **votre PC**, ouvrez `owner-licences/Excellencia-Licences.html` (application propriétaire séparée, jamais livrée). Chargez votre sauvegarde chiffrée de clé (`SAUVEGARDE-CLE-LICENCE-*.json` + mot de passe).
3. Nom du client, cochez « 📱 Livré en application », collez son code appareil, choisissez la durée, **Générer**. Envoyez-lui le **code seul** : il le saisit sur l'écran verrouillé.
4. Renouvellement : bouton 🔄 dans « Licences émises », nouveau code (même appareil).
5. Sans clé privée, personne ne peut émettre ni modifier un code. Conservez la sauvegarde de la clé (sans elle, plus d'émission).

## 5. Comptes en ligne (facultatif)
Pour des comptes et la gestion par organisation, créez un projet Supabase pour le client, exécutez `schema-entreprise.sql` puis `migration-v118-moteur-documentaire.sql`, et renseignez l'URL et la clé dans l'identité de l'entreprise. Vous créez les comptes et gardez la main sur l'administration.

## 6. Serveur PDF (facultatif)
Sans serveur, les PDF sont produits dans le navigateur avec le même moteur. Le serveur (dossier `docengine-server`) apporte un rendu Chromium plus fidèle et les PDF remplissables ; voir `DOCENGINE-LISEZ-MOI.md`.

## 7. Réglages par client
- En-tête du profil sur tous les PDF : **Centre documentaire › Paramètres** (activé par défaut, chaque client peut le désactiver).
- Numérotation, mise en page par défaut, modèles personnalisés : Centre documentaire.
