import http.server, threading, functools, sys
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=sys.argv[1]); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8932), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_context(viewport={'width':1366,'height':800}).new_page(); errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto('http://127.0.0.1:8932/index.html'); pg.wait_for_timeout(3500)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("EXB_SHELL.goKey('exbbi')"); pg.wait_for_timeout(2000)
    pg.screenshot(path='../bi1.png')
    pg.evaluate("window.scrollTo(0,document.body.scrollHeight*0.5)"); pg.wait_for_timeout(500)
    pg.screenshot(path='../bi2.png')
    print(errs, pg.evaluate("document.title"))
    print(pg.evaluate("[...document.querySelectorAll('#exbHub, #exbbi, section')].filter(e=>e.offsetParent).map(e=>e.id).join(',')"))
