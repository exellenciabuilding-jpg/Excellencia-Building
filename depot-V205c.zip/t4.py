import http.server, threading, functools, sys
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=sys.argv[1]); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8934), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
PNG="data:image/jpg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/wAALCAAKAAoBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACP/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q=="
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_context(viewport={'width':1366,'height':900}).new_page(); errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto('http://127.0.0.1:8934/index.html'); pg.wait_for_timeout(3000)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    r=pg.evaluate("""async(PNG)=>{participants.push({participant_id:'P1',name:'IBWAMPERE  NGWALA LOUIS',matricule:'011-580-937',photo:''},{participant_id:'P2',name:'Ibwampère Ngwala Louis',photo:PNG});
      const o=await recuModeleLogiciel({receipt_no:'REC-1',participant:'IBWAMPERE NGWALA LOUIS',matricule:'011-580-937',training:'ArchiCAD'});
      document.body.innerHTML='<div style="background:#fff">'+EXBRecuTFL.html(o).replace(/^[\\s\\S]*?<body>/,'').replace(/<\\/body>[\\s\\S]*$/,'')+'</div>';
      const st=document.createElement('style');st.textContent=EXBRecuTFL.html(o).match(/<style>([\\s\\S]*?)<\\/style>/)[1];document.head.appendChild(st);
      return {hasPhoto:!!o.photo, ph:!!document.querySelector('.ph'), pdf:(await EXBRecuTFL.pdfBlob(o)).size}}""",PNG)
    print(r, errs)
    pg.screenshot(path='/tmp/claude-0/-home-claude/65909438-f354-5020-a3da-caab4b12a5bc/scratchpad/rc.png')
