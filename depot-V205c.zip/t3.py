import http.server, threading, functools, sys, json
from playwright.sync_api import sync_playwright
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=sys.argv[1]); H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8933), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_context(viewport={'width':1366,'height':800}).new_page(); errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto('http://127.0.0.1:8933/index.html'); pg.wait_for_timeout(3000)
    pg.add_style_tag(content='#exbLicLock,#loginScreen{display:none!important}#app{display:block!important}')
    pg.evaluate("""()=>{const pr=[{id:'p1',name:'Architecture — Ngelesi héritier',budget:1500000,currency:'USD',status:'En cours',start:'2026-09-01',end:'2027-03-01'}];
      save('exb_projects',pr); }""")
    pg.evaluate("EXB_SHELL.goKey('exbbi')"); pg.wait_for_timeout(2500)
    print(pg.evaluate("JSON.stringify(load('exb_projects',[])).slice(0,120)"))
    pg.screenshot(path='/tmp/claude-0/-home-claude/65909438-f354-5020-a3da-caab4b12a5bc/scratchpad/bi3.png')
    print(errs)
    print(pg.evaluate("document.getElementById('bi_box').innerText.slice(0,500)"))
