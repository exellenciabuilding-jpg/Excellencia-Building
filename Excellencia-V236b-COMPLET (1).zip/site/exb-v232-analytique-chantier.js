/* Excellencia Building V232 — 🏗️ ANALYTIQUE CHANTIER & BUDGETS (Lot 4 du cahier « Portail Comptable V229+ »).
 * Budget initial / révisé par chantier et par catégorie (matériaux, main-d'œuvre, sous-traitance, engins, frais généraux),
 * engagements (commandes non encore facturées), réalisé (factures fournisseurs + dépenses de caisse), recettes, marge, écarts.
 * ADAPTATEUR EN LECTURE : lit exb_projects, exb_purchase_orders, exb_v92_purchase_orders, exb_v92_supplier_invoices, exb_cash, exb_invoices.
 * Aucune donnée existante n’est modifiée. Clés créées : exb_an_budgets, exb_an_audit.
 * Anti-doublon : une dépense de caisse dont la référence est celle d’une facture fournisseur n’est PAS recomptée.
 * Une dépense sans catégorie reste en « Non classé » (jamais devinée). USD et CDF restent séparés : aucune conversion.
 * Ne remplace ni exb-budgetfin.js ni exb-compta*.js. Retirer : supprimer la balise <script src="exb-v232-analytique-chantier.js">. */
(function (w, d) {
  'use strict';
  if (w.EXBAN) return;
  var KB = 'exb_an_budgets', KA = 'exb_an_audit';
  var CATS = ['Matériaux', 'Main-d’œuvre', 'Sous-traitance', 'Engins', 'Frais généraux'], NC = 'Non classé';
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nc(c) { c = String(c || 'USD').toUpperCase(); return /^(FC|CDF)$/.test(c) ? 'CDF' : c; }
  function nrm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
  function iso(x) { var s = String(x || '').slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ''; }
  function jour() { var n = new Date(); return n.getFullYear() + '-' + ('0' + (n.getMonth() + 1)).slice(-2) + '-' + ('0' + n.getDate()).slice(-2); }
  function nf(n, c) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: c === 'CDF' ? 0 : 2, maximumFractionDigits: c === 'CDF' ? 0 : 2 }).replace(/[\u202f\u00a0]/g, ' '); }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function raw(k) { var S = store(); try { return S ? S.getItem(k) : w.localStorage.getItem(k); } catch (e) { return null; } }
  function rdA(k) { try { var v = JSON.parse(raw(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, v) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(v)); else w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function qui() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.nom)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function peutEcrire() { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can('budget', 'ecrire') || w.EXB_CORE.can('comptabilite', 'ecrire'); } catch (e) { return true; } }
  function audit(action, o) { var a = rdA(KA); a.push(Object.assign({ le: new Date().toISOString(), par: qui(), action: action }, o || {})); wr(KA, a); }

  /* ---------- fonctions pures (testées) ---------- */
  function catDe(x) {
    var c = nrm(x && (x.cat || x.category || x.categorie || x.nature || '')); if (!c) return NC;
    if (/mat/.test(c)) return CATS[0]; if (/main|oeuvre|salaire|paie|personnel/.test(c)) return CATS[1]; if (/sous/.test(c)) return CATS[2]; if (/engin|materiel|location/.test(c)) return CATS[3]; if (/frais|general|admin|bureau/.test(c)) return CATS[4]; return NC;
  }
  function projDe(x) { return String((x && (x.project_id || x.projectId || x.projet || x.chantier_id)) || ''); }
  function montantDe(x) { return r2(+x.amount || +x.total || +x.ttc || 0); }
  function projets(list) { return (list || []).filter(function (p) { return p && p.id; }).map(function (p) { return { id: String(p.id), nom: p.name || p.nom || p.title || p.label || String(p.id) }; }); }
  /* budget courant = dernière version révisée, sinon l’initiale ; budgets = [{id,projet,version,devise,lignes:[{cat,montant}],date,motif,annule}] */
  function budgetCourant(budgets, projet, devise) {
    var l = (budgets || []).filter(function (b) { return !b.annule && b.projet === projet && b.devise === devise; }).sort(function (a, b) { return String(a.le || a.date).localeCompare(String(b.le || b.date)); });
    var rev = l.filter(function (b) { return b.version === 'revise'; }), ini = l.filter(function (b) { return b.version === 'initial'; })[0];
    return { courant: rev.length ? rev[rev.length - 1] : (ini || null), initial: ini || null, nbRevisions: rev.length };
  }
  function totalLignes(b) { var t = {}; ((b && b.lignes) || []).forEach(function (x) { t[x.cat] = r2((t[x.cat] || 0) + (+x.montant || 0)); }); return t; }
  function validerBudget(b, existants) {
    var e = [], lignes = (b.lignes || []).filter(function (x) { return +x.montant > 0; });
    if (!b.projet) e.push('Choisissez le chantier.'); if (['USD', 'CDF'].indexOf(nc(b.devise)) < 0) e.push('Devise : USD ou CDF.'); if (!lignes.length) e.push('Saisissez au moins une ligne de budget supérieure à zéro.');
    if (lignes.some(function (x) { return CATS.indexOf(x.cat) < 0; })) e.push('Catégorie invalide.');
    var ini = (existants || []).filter(function (x) { return !x.annule && x.projet === b.projet && x.devise === nc(b.devise) && x.version === 'initial'; })[0];
    if (b.version === 'initial' && ini) e.push('Un budget initial existe déjà pour ce chantier dans cette devise : créez une révision.');
    if (b.version === 'revise' && !ini) e.push('Créez d’abord le budget initial.');
    if (b.version === 'revise' && String(b.motif || '').trim().length < 3) e.push('Le motif de la révision est obligatoire.');
    if (['initial', 'revise'].indexOf(b.version) < 0) e.push('Version invalide.'); return e;
  }
  function construireBudget(b, qui_, now) {
    var agg = {}; (b.lignes || []).forEach(function (x) { if (+x.montant > 0) agg[x.cat] = r2((agg[x.cat] || 0) + +x.montant); });
    return { id: uid('BUD'), projet: String(b.projet), version: b.version, devise: nc(b.devise), lignes: Object.keys(agg).map(function (c) { return { cat: c, montant: agg[c] }; }), motif: String(b.motif || '').trim(), date: iso(b.date) || jour(), par: qui_ || '', le: now || new Date().toISOString() };
  }
  /* engagé = commande non encore facturée (commande − factures liées à la commande), jamais négatif */
  function engagements(commandes, factures) {
    var out = []; (commandes || []).forEach(function (p) {
      if (!p || /annul|cancel/i.test(p.status || '')) return; var pr = projDe(p); if (!pr) return; var id = String(p.id || ''), no = String(p.no || p.number || p.po || ''), cur = nc(p.currency || p.devise), tot = montantDe(p);
      var fac = (factures || []).filter(function (f) { var l = String(f.po || f.po_no || f.order || f.order_id || f.purchase_order || ''); return l && (l === id || l === no) && nc(f.currency) === cur; }).reduce(function (a, f) { return a + montantDe(f); }, 0);
      out.push({ projet: pr, cur: cur, cat: catDe(p), montant: r2(Math.max(0, tot - fac)), ref: no || id });
    }); return out;
  }
  /* réalisé = factures fournisseurs + sorties de caisse du chantier non liées à une facture (pas de double compte) */
  function realise(factures, cash) {
    var out = [], refs = {}; (factures || []).forEach(function (f) { if (!f || /annul|cancel/i.test(f.status || '')) return; if (f.id) refs[String(f.id)] = 1; if (f.no) refs[String(f.no)] = 1; var pr = projDe(f); if (pr) out.push({ projet: pr, cur: nc(f.currency || f.devise), cat: catDe(f), montant: montantDe(f), ref: f.no || f.id || '', src: 'facture' }); });
    (cash || []).forEach(function (c) { if (!c || c.type !== 'out' || !(+c.amount > 0)) return; var pr = projDe(c); if (!pr) return; if (c.ref && refs[String(c.ref)]) return; out.push({ projet: pr, cur: nc(c.currency || c.devise), cat: catDe(c), montant: r2(+c.amount), ref: c.ref || c.id || '', src: 'caisse' }); }); return out;
  }
  function ht(inv) { return r2((inv.lines || []).reduce(function (a, l) { return a + (+l.q || 0) * (+l.pu || 0); }, 0)); }
  function recettes(factures, cash) {
    var out = []; (factures || []).forEach(function (f) { if (!f || f.annule || /annul|cancel/i.test(f.status || '')) return; var pr = projDe(f); if (!pr) return; var h = ht(f); out.push({ projet: pr, cur: nc(f.currency), facture: r2(h * (1 + (+f.tva || 0) / 100)), encaisse: 0 }); });
    (cash || []).forEach(function (c) { if (!c || c.type !== 'in' || !(+c.amount > 0)) return; var pr = projDe(c); if (pr) out.push({ projet: pr, cur: nc(c.currency || c.devise), facture: 0, encaisse: r2(+c.amount) }); }); return out;
  }
  function analyse(projetId, devise, S) {
    var b = budgetCourant(S.budgets, projetId, devise), bt = totalLignes(b.courant), bi = totalLignes(b.initial);
    var eng = engagements(S.commandes, S.facturesF).filter(function (x) { return x.projet === projetId && x.cur === devise; }), rea = realise(S.facturesF, S.cash).filter(function (x) { return x.projet === projetId && x.cur === devise; }), rec = recettes(S.facturesC, S.cash).filter(function (x) { return x.projet === projetId && x.cur === devise; });
    var cats = CATS.concat([NC]), lignes = cats.map(function (c) {
      var bu = bt[c] || 0, e = r2(eng.filter(function (x) { return x.cat === c; }).reduce(function (a, x) { return a + x.montant; }, 0)), r = r2(rea.filter(function (x) { return x.cat === c; }).reduce(function (a, x) { return a + x.montant; }, 0));
      return { cat: c, initial: bi[c] || 0, budget: bu, engage: e, realise: r, disponible: r2(bu - e - r), ecart: r2(bu - r) };
    }).filter(function (l) { return l.budget || l.engage || l.realise || l.initial; });
    var tot = lignes.reduce(function (a, l) { ['initial', 'budget', 'engage', 'realise'].forEach(function (k) { a[k] = r2(a[k] + l[k]); }); return a; }, { initial: 0, budget: 0, engage: 0, realise: 0 });
    tot.disponible = r2(tot.budget - tot.engage - tot.realise); var fac = r2(rec.reduce(function (a, x) { return a + x.facture; }, 0)), enc = r2(rec.reduce(function (a, x) { return a + x.encaisse; }, 0));
    return { lignes: lignes, tot: tot, facture: fac, encaisse: enc, marge: r2(fac - tot.realise), margeCash: r2(enc - tot.realise), aBudget: !!b.courant, revisions: b.nbRevisions, depasse: tot.budget > 0 && (tot.engage + tot.realise) > tot.budget + 0.004, nonClasse: (lignes.filter(function (l) { return l.cat === NC; })[0] || { realise: 0 }).realise };
  }
  function synthese(devise, S) {
    var ids = {}; (S.projets || []).forEach(function (p) { ids[p.id] = p.nom; });
    [].concat(engagements(S.commandes, S.facturesF), realise(S.facturesF, S.cash), recettes(S.facturesC, S.cash)).forEach(function (x) { if (x.cur === devise && !(x.projet in ids)) ids[x.projet] = x.projet; });
    (S.budgets || []).forEach(function (b) { if (!b.annule && b.devise === devise && !(b.projet in ids)) ids[b.projet] = b.projet; });
    return Object.keys(ids).map(function (id) { var a = analyse(id, devise, S); return { id: id, nom: ids[id], a: a }; }).filter(function (x) { var a = x.a; return a.aBudget || a.tot.engage || a.tot.realise || a.facture || a.encaisse; });
  }

  /* ---------- lecture globale ---------- */
  function lire() {
    return { projets: projets(rdA('exb_projects')), commandes: rdA('exb_purchase_orders').concat(rdA('exb_v92_purchase_orders')), facturesF: rdA('exb_v92_supplier_invoices'), cash: rdA('exb_cash'), facturesC: rdA('exb_invoices'), budgets: rdA(KB) };
  }
  /* ---------- interface ---------- */
  var TAB = 'synthese', DEV = 'USD', SEL = '', ERR = '', MSG = '', FORM = null;
  function css() {
    if ($('an_css')) return; var s = d.createElement('style'); s.id = 'an_css';
    s.textContent = '#an_c{background:#f5f8fd;color:#1b2a41;border-radius:14px;max-width:1100px;width:100%;padding:14px;font-family:inherit;box-sizing:border-box}#an_c *{box-sizing:border-box}#an_c h3{margin:0;color:#0f2a5c}#an_c .hd{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px}#an_c .x{border:0;background:#0f2a5c;color:#fff;border-radius:8px;padding:7px 12px;cursor:pointer;font-weight:700}' +
      '#an_c .tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}#an_c .tabs button{border:1px solid #d5deee;background:#fff;border-radius:9px;padding:8px 12px;cursor:pointer;font-weight:600;color:#1b2a41}#an_c .tabs button.on{background:#0f2a5c;color:#fff;border-color:#0f2a5c}' +
      '#an_c .cd{background:#fff;border:1px solid #e3e9f3;border-radius:12px;padding:12px;margin-bottom:10px;overflow:hidden}#an_c .tw{overflow-x:auto}#an_c table{width:100%;border-collapse:collapse;font-size:13px}#an_c th{text-align:left;color:#5b6b82;padding:7px 6px;border-bottom:1px solid #e3e9f3;white-space:nowrap}#an_c td{padding:8px 6px;border-bottom:1px solid #eef2f9;vertical-align:top}#an_c tr.rw{cursor:pointer}#an_c .r{text-align:right;white-space:nowrap}' +
      '#an_c .pl{display:inline-block;border-radius:999px;padding:2px 9px;font-size:11.5px;font-weight:700;background:#fdecc8;color:#8a5200;margin:1px 2px 1px 0}#an_c .pl.v{background:#dcfce7;color:#166534}#an_c .pl.r{background:#fee4e2;color:#b42318}#an_c .er{background:#fee4e2;border:1px solid #f3b7b1;color:#8a1c14;border-radius:8px;padding:8px 10px;margin-bottom:8px}#an_c .ok{background:#dcfce7;border:1px solid #a7e3bb;color:#14532d;border-radius:8px;padding:8px 10px;margin-bottom:8px}#an_c .mu{color:#5b6b82;font-size:12.5px}' +
      '#an_c label{display:block;font-size:12.5px;color:#5b6b82;margin-top:6px}#an_c input,#an_c select{width:100%;padding:8px;border:1px solid #d5deee;border-radius:8px;font-size:14px;background:#fff;color:#1b2a41}#an_c .gr{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px}#an_c .bt{background:#0f2a5c;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}#an_c .bt.s{background:#e8edf6;color:#0f2a5c}' +
      '#an_c .kp{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-bottom:10px}#an_c .kp div{background:#fff;border:1px solid #e3e9f3;border-radius:12px;padding:10px}#an_c .kp b{display:block;font-size:18px;color:#0f2a5c}' +
      '@media print{body>*:not(#an_ov){display:none!important}#an_ov{position:static!important;background:#fff!important}#an_c .tabs,#an_c .x,#an_c .no-print{display:none!important}}';
    d.head.appendChild(s);
  }
  function badge(t, c) { return '<span class="pl ' + (c || '') + '">' + esc(t) + '</span>'; }
  function tbl(h, rows) { return '<div class="tw"><table><thead><tr>' + h.map(function (x) { return '<th>' + x + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'; }
  function opt(v, t, sel) { return '<option value="' + esc(v) + '"' + (sel ? ' selected' : '') + '>' + esc(t) + '</option>'; }
  function val(id) { var e = $(id); return e ? e.value : ''; }
  function N(x) { return nf(x, DEV); }
  function vSynthese(S) {
    var L = synthese(DEV, S); if (!L.length) return '<div class="cd mu">Aucune donnée analytique en ' + DEV + '. Rattachez les commandes, factures et dépenses à un chantier (champ chantier / projet) et saisissez un budget dans l’onglet Budgets.</div>';
    var dep = L.filter(function (x) { return x.a.depasse; }).length;
    return '<div class="kp"><div><span class="mu">Chantiers suivis</span><b>' + L.length + '</b></div><div><span class="mu">Budget dépassé (engagé + réalisé)</span><b style="color:' + (dep ? '#b42318' : '#166534') + '">' + dep + '</b></div></div><div class="cd"><div class="mu" style="margin-bottom:6px">Touchez un chantier pour le détail par catégorie. Devise : ' + DEV + ' (aucune conversion).</div>' +
      tbl(['Chantier', 'Budget', 'Engagé', 'Réalisé', 'Disponible', 'Facturé', 'Encaissé', 'Marge', ''], L.map(function (x) { var a = x.a; return '<tr class="rw" data-s="' + esc(x.id) + '"><td><b>' + esc(x.nom) + '</b></td><td class="r">' + (a.aBudget ? N(a.tot.budget) : '—') + '</td><td class="r">' + N(a.tot.engage) + '</td><td class="r">' + N(a.tot.realise) + '</td><td class="r"><b style="color:' + (a.tot.disponible < 0 ? '#b42318' : '#166534') + '">' + (a.aBudget ? N(a.tot.disponible) : '—') + '</b></td><td class="r">' + N(a.facture) + '</td><td class="r">' + N(a.encaisse) + '</td><td class="r"><b style="color:' + (a.marge < 0 ? '#b42318' : '#166534') + '">' + N(a.marge) + '</b></td><td>' + (!a.aBudget ? badge('Sans budget') : a.depasse ? badge('Dépassement', 'r') : '') + '</td></tr>'; })) + '</div>';
  }
  function vDetail(S) {
    var L = synthese(DEV, S), cur = L.filter(function (x) { return x.id === SEL; })[0] || L[0]; if (!cur) return '<div class="cd mu">Aucun chantier à analyser en ' + DEV + '.</div>'; SEL = cur.id; var a = cur.a;
    var h = '<div class="cd"><div class="gr"><div><label>Chantier</label><select id="an_sel">' + L.map(function (x) { return opt(x.id, x.nom, x.id === cur.id); }).join('') + '</select></div></div></div>';
    h += '<div class="kp"><div><span class="mu">Budget ' + (a.revisions ? '(révisé ×' + a.revisions + ')' : '') + '</span><b>' + (a.aBudget ? N(a.tot.budget) : '—') + '</b></div><div><span class="mu">Engagé</span><b>' + N(a.tot.engage) + '</b></div><div><span class="mu">Réalisé</span><b>' + N(a.tot.realise) + '</b></div><div><span class="mu">Disponible</span><b style="color:' + (a.tot.disponible < 0 ? '#b42318' : '#166534') + '">' + (a.aBudget ? N(a.tot.disponible) : '—') + '</b></div><div><span class="mu">Marge (facturé − réalisé)</span><b>' + N(a.marge) + '</b></div><div><span class="mu">Marge encaissée</span><b>' + N(a.margeCash) + '</b></div></div>';
    h += '<div class="cd"><b>Par catégorie</b>' + (a.lignes.length ? tbl(['Catégorie', 'Initial', 'Budget actuel', 'Engagé', 'Réalisé', 'Disponible', 'Écart'], a.lignes.map(function (l) { return '<tr><td>' + esc(l.cat) + (l.cat === NC ? ' ' + badge('à classer') : '') + '</td><td class="r">' + N(l.initial) + '</td><td class="r">' + N(l.budget) + '</td><td class="r">' + N(l.engage) + '</td><td class="r">' + N(l.realise) + '</td><td class="r"><b style="color:' + (l.disponible < 0 ? '#b42318' : '#166534') + '">' + N(l.disponible) + '</b></td><td class="r">' + N(l.ecart) + '</td></tr>'; })) : '<div class="mu">Aucune ligne.</div>') +
      '<div class="mu" style="margin-top:6px">Réalisé = factures fournisseurs + sorties de caisse du chantier (une sortie de caisse portant la référence d’une facture n’est pas recomptée). L’engagé est le reste non facturé des commandes.' + (a.nonClasse ? ' <b>' + N(a.nonClasse) + ' ' + DEV + ' sans catégorie.</b>' : '') + '</div></div>';
    return h;
  }
  function vBudgets(S) {
    var f = FORM || { projet: '', version: 'initial', devise: DEV, motif: '', date: jour(), v: {} }, ps = synthese(DEV, S).map(function (x) { return { id: x.id, nom: x.nom }; }); (S.projets || []).forEach(function (p) { if (!ps.some(function (x) { return x.id === p.id; })) ps.push(p); });
    var h = '<div class="cd"><h4 style="margin:0 0 6px">Nouveau budget</h4><div class="gr"><div><label>Chantier</label><select id="bu_p"><option value=""></option>' + ps.map(function (p) { return opt(p.id, p.nom, p.id === f.projet); }).join('') + '</select></div><div><label>Version</label><select id="bu_v">' + opt('initial', 'Initial', f.version === 'initial') + opt('revise', 'Révisé', f.version === 'revise') + '</select></div><div><label>Devise</label><select id="bu_d">' + opt('USD', 'USD', f.devise === 'USD') + opt('CDF', 'CDF', f.devise === 'CDF') + '</select></div><div><label>Date</label><input type="date" id="bu_dt" value="' + esc(f.date) + '"></div><div><label>Motif (obligatoire pour une révision)</label><input id="bu_m" value="' + esc(f.motif) + '"></div></div><div class="gr" style="margin-top:6px">' +
      CATS.map(function (c, i) { return '<div><label>' + esc(c) + '</label><input id="bu_c' + i + '" inputmode="decimal" value="' + esc((f.v || {})[c] || '') + '"></div>'; }).join('') + '</div><p><button class="bt" id="bu_ok">Enregistrer le budget</button></p><div class="mu">Une révision s’ajoute au budget initial : l’initial n’est jamais écrasé.</div></div>';
    var L = S.budgets.slice().sort(function (a, b) { return String(b.le).localeCompare(String(a.le)); });
    h += '<div class="cd"><b>Historique des budgets</b>' + (L.length ? tbl(['Date', 'Chantier', 'Version', 'Devise', 'Total', 'Motif', 'Par', ''], L.map(function (b) { var tot = b.lignes.reduce(function (a, x) { return a + x.montant; }, 0), p = (S.projets || []).filter(function (x) { return x.id === b.projet; })[0]; return '<tr' + (b.annule ? ' style="opacity:.5"' : '') + '><td>' + esc(b.date) + '</td><td>' + esc(p ? p.nom : b.projet) + '</td><td>' + (b.version === 'initial' ? 'Initial' : 'Révisé') + '</td><td>' + b.devise + '</td><td class="r">' + nf(tot, b.devise) + '</td><td>' + esc(b.motif) + '</td><td>' + esc(b.par) + '</td><td>' + (b.annule ? badge('Annulé', 'r') : '<button class="bt s" data-ba="' + esc(b.id) + '">Annuler</button>') + '</td></tr>'; })) : '<div class="mu">Aucun budget.</div>') + '</div>';
    return h;
  }
  function paint() {
    var c = $('an_c'); if (!c) return; var S = lire(), T = [['synthese', '📊 Synthèse'], ['detail', '🏗️ Détail chantier'], ['budgets', '💰 Budgets']];
    c.innerHTML = '<div class="hd"><h3>🏗️ Analytique chantier & budgets</h3><button class="x" id="an_x">Fermer ✕</button></div><div class="tabs">' + T.map(function (t) { return '<button data-t="' + t[0] + '" class="' + (TAB === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; }).join('') + '<button data-dv="USD" class="' + (DEV === 'USD' ? 'on' : '') + '">USD</button><button data-dv="CDF" class="' + (DEV === 'CDF' ? 'on' : '') + '">CDF</button></div>' +
      (ERR ? '<div class="er">' + ERR + '</div>' : '') + (MSG ? '<div class="ok">' + esc(MSG) + '</div>' : '') + ({ synthese: vSynthese, detail: vDetail, budgets: vBudgets })[TAB](S); ERR = ''; MSG = '';
    $('an_x').onclick = close; c.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { TAB = b.getAttribute('data-t'); FORM = null; paint(); }; }); c.querySelectorAll('[data-dv]').forEach(function (b) { b.onclick = function () { DEV = b.getAttribute('data-dv'); paint(); }; });
    c.querySelectorAll('tr[data-s]').forEach(function (r) { r.onclick = function () { SEL = r.getAttribute('data-s'); TAB = 'detail'; paint(); }; }); var s = $('an_sel'); if (s) s.onchange = function () { SEL = s.value; paint(); };
    var ok = $('bu_ok'); if (ok) ok.onclick = function () {
      if (!peutEcrire()) { ERR = 'Droits insuffisants.'; return paint(); } var v = {}, lignes = CATS.map(function (cat, i) { var n = parseFloat(String(val('bu_c' + i)).replace(/\s/g, '').replace(',', '.')) || 0; v[cat] = val('bu_c' + i); return { cat: cat, montant: n }; });
      FORM = { projet: val('bu_p'), version: val('bu_v'), devise: val('bu_d'), motif: val('bu_m'), date: val('bu_dt'), v: v, lignes: lignes }; var er = validerBudget(FORM, S.budgets); if (er.length) { ERR = esc(er.join(' ')); return paint(); }
      var b = construireBudget(FORM, qui()), all = rdA(KB); all.push(b); if (!wr(KB, all)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); } audit('budget_' + b.version, { projet: b.projet, devise: b.devise, lignes: b.lignes, motif: b.motif }); FORM = null; MSG = 'Budget enregistré.'; paint();
    };
    c.querySelectorAll('[data-ba]').forEach(function (b) { b.onclick = function () { if (!peutEcrire()) { ERR = 'Droits insuffisants.'; return paint(); } var mo = (w.prompt('Motif de l’annulation (obligatoire) :') || '').trim(); if (mo.length < 3) { ERR = 'Un motif est obligatoire.'; return paint(); } var all = rdA(KB), x = all.filter(function (y) { return y.id === b.getAttribute('data-ba'); })[0]; if (!x) return; x.annule = true; x.annule_motif = mo; x.annule_par = qui(); wr(KB, all); audit('budget_annule', { id: x.id, motif: mo }); MSG = 'Budget annulé.'; paint(); }; });
  }
  function close() { var o = $('an_ov'); if (o && o.parentNode) o.parentNode.removeChild(o); }
  function open(tab) {
    close(); css(); TAB = tab || 'synthese'; FORM = null; ERR = ''; MSG = '';
    var o = d.createElement('div'); o.id = 'an_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9990;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.onclick = function (e) { if (e.target === o) close(); }; o.innerHTML = '<div id="an_c"></div>'; d.body.appendChild(o); paint();
  }
  function mount() { if ($('ban')) return; var a = $('btr') || $('bfd') || $('bcr') || $('bcompta'); if (!a || !a.parentNode) return; var b = d.createElement('button'); b.id = 'ban'; b.textContent = '🏗️ Analytique chantier'; b.onclick = function () { open('synthese'); }; a.parentNode.insertBefore(b, a.nextSibling); }
  function enregistrerModule() {
    try { if (w.EXB_MODULES && !w.EXB_MODULES.some(function (m) { return m.id === 'analytiqueChantier'; })) w.EXB_MODULES.push({ id: 'analytiqueChantier', name: 'Analytique chantier & budgets', area: 'Finance', icon: '🏗️', status: 'nouveau', deps: ['comptabilite', 'projets'] }); } catch (e) {}
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'analytique-chantier', name: 'Analytique chantier & budgets', version: '232.0.0', area: 'Finance', provides: ['compta.analytique', 'compta.budget-chantier'] }); } catch (e) {}
  }
  function start() { mount(); enregistrerModule(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000); }
  w.EXBAN = { open: open, pure: { catDe: catDe, budgetCourant: budgetCourant, validerBudget: validerBudget, construireBudget: construireBudget, engagements: engagements, realise: realise, recettes: recettes, analyse: analyse, synthese: synthese } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
