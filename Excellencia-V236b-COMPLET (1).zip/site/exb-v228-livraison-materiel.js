/* Excellencia Building V228 — 📦 Bon de livraison + reçu de matériel (Espace Comptable › Reçus de paiement).
 * Quand du matériel est remis à une entreprise : un seul PDF A4 (même en-tête, même pied, même QR de vérification que le reçu client) qui prouve
 *   - ce qui a été livré (désignation, quantité, unité, prix, total), à quelle entreprise, sur quel chantier, à quelle date ;
 *   - ce qui a été payé à ce jour et ce qui reste à payer ;
 *   - qui a livré et qui a reçu (nom du réceptionnaire, zone de signature et de cachet).
 * Registre local « exb_livraisons » (pont de stockage commun : sauvegardé avec le reste). Aucune donnée n'est inventée : tout est saisi.
 * API : EXBLivraison.build(lib,d,env) -> Promise<Uint8Array> ; .make(d) -> Promise<Blob> ; .mount() ; .totaux(lignes,paye). */
(function (w, d) {
  'use strict';
  var KEY = 'exb_livraisons', MAXL = 12;
  var NAVY = [0.090, 0.208, 0.396], BLUE = [0.125, 0.286, 0.541], BAND = [0.918, 0.941, 0.984], GOLD = [0.769, 0.604, 0.220], GREY = [0.40, 0.43, 0.49], INK = [0.10, 0.12, 0.18], LINE = [0.78, 0.82, 0.88], SOFT = [0.95, 0.97, 0.99];
  var TEL = '+243 810 644 554', MAIL = 'excellenciabuilding@gmail.com';
  var $ = function (i) { return d && d.getElementById(i); };
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { var n = parseFloat(String(v == null ? '' : v).replace(/[\s ]/g, '').replace(',', '.')); return isFinite(n) ? n : 0; }
  function r2(n) { return Math.round(n * 100) / 100; }
  function dev(x) { return String(x || '').toUpperCase() === 'FC' ? 'FC' : 'USD'; }
  function today() { var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
  function fmt(n, dv) { return Number(n || 0).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' ' + (dev(dv) === 'FC' ? 'FC' : '$'); }
  function rd(k) { try { if (w.EXBS && w.EXBS.get) return w.EXBS.get(k); } catch (e) { } return []; }
  function wr(k, v) { try { if (w.EXBS && w.EXBS.set) return w.EXBS.set(k, v) !== false; } catch (e) { } return false; }
  function audit(a, t) { try { if (typeof w.audit === 'function') w.audit(a, t); } catch (e) { } }

  /* ---------- calculs (testés hors navigateur) ---------- */
  function totaux(lignes, paye) {
    var tot = 0; (lignes || []).forEach(function (l) { tot += r2(num(l.qte) * num(l.pu)); });
    tot = r2(tot); var p = r2(Math.max(0, num(paye))), reste = r2(Math.max(0, tot - p)), surplus = p > tot ? r2(p - tot) : 0;
    return { total: tot, paye: p, reste: reste, surplus: surplus, statut: tot <= 0 ? 'aucun' : reste <= 0.005 ? 'payé' : p > 0 ? 'partiel' : 'à payer' };
  }
  function nextNo(all, date, pre) {
    pre = pre || 'BL';
    var y = String(date || today()).slice(0, 4), mx = 0;
    (all || []).forEach(function (r) { var m = new RegExp('^' + pre + '-(\\d{4})-(\\d+)$').exec(r && r.no || ''); if (m && m[1] === y) mx = Math.max(mx, parseInt(m[2], 10)); });
    return pre + '-' + y + '-' + ('00' + (mx + 1)).slice(-3);
  }

  /* ---------- utilitaires PDF (mêmes que le reçu client) ---------- */
  var OK = { 8217: 1, 8216: 1, 8220: 1, 8221: 1, 8211: 1, 8212: 1, 8364: 1, 339: 1, 338: 1, 8230: 1, 8226: 1 };
  function san(t) { t = String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ').replace(/ | /g, ' '); var o = ''; for (var i = 0; i < t.length; i++) { var c = t.charCodeAt(i); o += (c < 256 || OK[c]) ? t.charAt(i) : '?'; } return o; }
  function nf(v) { v = Number(v) || 0; var s = Math.abs(v).toFixed(2).split('.'); s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (v < 0 ? '-' : '') + s.join(','); }
  function fd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function dataUrlBytes(u) { var b = atob(String(u).split(',')[1] || ''), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function loadLib() {
    if (w.PDFLib) return Promise.resolve(w.PDFLib);
    return new Promise(function (ok, ko) { var s = d.createElement('script'); s.src = 'pdflib/pdf-lib.min.js'; s.onload = function () { w.PDFLib ? ok(w.PDFLib) : ko(new Error('pdf-lib')); }; s.onerror = function () { ko(new Error('pdf-lib introuvable')); }; d.head.appendChild(s); });
  }
  async function imgBytes(src) {
    try {
      if (!src) return null;
      if (/^data:image\/(png|jpe?g)/i.test(src)) return { b: dataUrlBytes(src), png: /^data:image\/png/i.test(src) };
      var r = await fetch(src); if (!r.ok) return null; var ab = new Uint8Array(await r.arrayBuffer()); return { b: ab, png: ab[0] === 0x89 };
    } catch (e) { return null; }
  }

  /* ---------- construction du PDF ---------- */
  async function build(lib, dt, env) {
    env = env || {}; var CMD = dt.type === 'commande';
    var pdf = await lib.PDFDocument.create(), pg = pdf.addPage([595, 842]), W = 595, H = 842, M = 40;
    var F1 = await pdf.embedFont(lib.StandardFonts.Helvetica), F2 = await pdf.embedFont(lib.StandardFonts.HelveticaBold), F3 = await pdf.embedFont(lib.StandardFonts.HelveticaOblique), F4 = await pdf.embedFont(lib.StandardFonts.TimesRomanBoldItalic);
    var rgb = function (a) { return lib.rgb(a[0], a[1], a[2]); };
    function T(t, x, y, sz, o) { o = o || {}; var f = o.i ? F3 : (o.b ? F2 : F1); t = san(t); if (o.al) { var wd = f.widthOfTextAtSize(t, sz); x = o.al === 'r' ? x - wd : x - wd / 2; } pg.drawText(t, { x: x, y: y, size: sz, font: f, color: rgb(o.c || INK) }); }
    function TW(t, sz, b) { return (b ? F2 : F1).widthOfTextAtSize(san(t), sz); }
    function R(x, y, w2, h, c) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, color: rgb(c) }); }
    function RS(x, y, w2, h, c, lw) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, borderColor: rgb(c), borderWidth: lw || .8 }); }
    function L(x1, y1, x2, y2, c, lw) { pg.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: lw || .6, color: rgb(c || LINE) }); }
    function fit(t, maxW, sz, b) { t = san(t); while (sz > 6 && TW(t, sz, b) > maxW) sz -= .25; if (TW(t, sz, b) > maxW) { while (t.length > 3 && TW(t + '…', sz, b) > maxW) t = t.slice(0, -1); t += '…'; } return { t: t, sz: sz }; }
    function field(label, val, x, y, wTot, o) {
      o = o || {}; T(label, x, y, 8.4, { b: true, c: NAVY }); var lx = x + TW(label, 8.4, true) + 6;
      L(lx, y - 2.5, x + wTot, y - 2.5, LINE, .6);
      if (val !== '' && val != null) { var f = fit(val, x + wTot - lx - 4, o.sz || 9.6, true); T(f.t, lx + 2, y, f.sz, { b: true }); }
    }
    function section(n, title, y) { R(M, y - 3, W - 2 * M, 16, NAVY); R(M, y - 3, 4, 16, GOLD); T(n + '. ' + title, M + 12, y + 1.2, 9.4, { b: true, c: [1, 1, 1] }); }
    function wrap(txt, maxW, sz) { var out = [], ln = ''; String(txt).split(' ').forEach(function (x) { var t2 = ln ? ln + ' ' + x : x; if (TW(t2, sz) > maxW && ln) { out.push(ln); ln = x; } else ln = t2; }); if (ln) out.push(ln); return out; }

    /* en-tête identique au reçu client */
    var I = env.id || {}, nom = dt.entreprise || I.name || 'Excellencia Building', logo = null;
    try { if (env.logo) logo = env.logo.png ? await pdf.embedPng(env.logo.b) : await pdf.embedJpg(env.logo.b); } catch (e) { logo = null; }
    var tx = M;
    if (logo) { var lh = 62, lw2 = lh * logo.width / logo.height; if (lw2 > 80) { lw2 = 80; lh = lw2 * logo.height / logo.width; } pg.drawImage(logo, { x: M, y: H - 26 - lh, width: lw2, height: lh }); tx = M + lw2 + 14; }
    var place = [I.address || 'Kinshasa, RDC', I.country].filter(function (v, i, a) { return v && !(i === 1 && String(a[0]).toLowerCase().indexOf(String(v).toLowerCase()) >= 0); }).join(', ');
    var items = [place, 'Tél : ' + (I.phone || TEL), 'E-mail : ' + (I.email || MAIL), I.website || ''].filter(Boolean), CW = 215, clines = [], cc = '';
    items.forEach(function (it) { var t5 = cc ? cc + '  ·  ' + it : it; if (cc && TW(t5, 7.6) > CW) { clines.push(cc); cc = it; } else cc = t5; }); if (cc) clines.push(cc);
    clines.slice(0, 4).forEach(function (l6, i) { var f6 = fit(l6, CW, 7.6); T(f6.t, W - M, H - 34 - i * 10.5, f6.sz, { al: 'r', c: GREY }); });
    var nmax = W - M - CW - 14 - tx, nf1 = fit(nom, nmax, 20, true);
    T(nf1.t, tx, H - 46, nf1.sz, { b: true, c: NAVY });
    var sl = fit('L’excellence au cœur de vos constructions', nmax, 9.5); T(sl.t, tx, H - 62, sl.sz, { i: true, c: [0.62, 0.47, 0.13] });
    var ar = fit('ARCHITECTURE  •  INGÉNIERIE  •  RÉALISATION', nmax, 7.8, true); T(ar.t, tx, H - 76, ar.sz, { b: true, c: GREY });
    L(M, H - 98, W - M, H - 98, GOLD, 2.2);
    R(M, H - 142, W - 2 * M, 38, BAND); R(M, H - 142, 5, 38, BLUE);
    T(CMD ? 'BON DE COMMANDE' : 'BON DE LIVRAISON / REÇU DE MATÉRIEL', M + 18, H - 123, 15, { b: true, c: BLUE });
    var sub = fit(dt.projet || '', W - 2 * M - 200, 9.5); if (sub.t) T(sub.t, M + 18, H - 136, sub.sz, { c: INK });
    T(CMD ? 'Commande fournisseur  •  À conserver' : 'Preuve de livraison  •  À conserver', W - M - 8, H - 136, 8, { al: 'r', c: GREY });
    L(M, H - 147, W - M, H - 147, NAVY, 3);

    var cur = dev(dt.devise), lignes = (dt.lignes || []).slice(0, MAXL), tt = totaux(lignes, dt.paye);
    var y = H - 168;
    field('N° DU BON', dt.no, M, y, 300, { sz: 10.5 }); field('DATE', fd(dt.date), M + 318, y, W - 2 * M - 318); y -= 21;
    field(CMD ? 'Fournisseur' : 'Entreprise destinataire', dt.entreprise_dest || '', M, y, W - 2 * M); y -= 21;
    field('Chantier / lieu de livraison', dt.projet || '', M, y, 300); field('Contact / Tél', dt.contact || '', M + 318, y, W - 2 * M - 318);

    /* 1. matériel livré */
    y -= 26; section(1, CMD ? 'MATÉRIEL COMMANDÉ' : 'MATÉRIEL LIVRÉ', y); y -= 20;
    var cx = [M, M + 24, M + 262, M + 312, M + 352, M + 428], cw = W - M;
    R(M, y - 4, W - 2 * M, 15, BAND);
    ['N°', 'Désignation', 'Qté', 'Unité', 'Prix unit.', 'Montant'].forEach(function (h, i) { T(h, i >= 4 ? (i === 4 ? M + 420 : cw - 4) : cx[i] + 3, y, 8, { b: true, c: NAVY, al: i >= 4 ? 'r' : undefined }); });
    y -= 17;
    for (var i = 0; i < MAXL; i++) {
      var l = lignes[i]; L(M, y - 4, cw, y - 4, LINE, .5);
      if (l) {
        var fl = fit(l.des || '', 232, 8.8, true); T(String(i + 1), cx[0] + 3, y, 8.6); T(fl.t, cx[1] + 3, y, fl.sz, { b: true });
        T(nf(num(l.qte)).replace(/,00$/, ''), cx[2] + 3, y, 8.8); T(l.unite || '', cx[3] + 3, y, 8.6);
        T(nf(num(l.pu)), M + 420, y, 8.6, { al: 'r' }); T(nf(r2(num(l.qte) * num(l.pu))), cw - 4, y, 8.8, { b: true, al: 'r' });
      }
      y -= 16;
    }
    L(M, y + 12, cw, y + 12, NAVY, 1);
    /* 2. situation de paiement */
    y -= 6; section(2, CMD ? 'TOTAL ET CONDITIONS' : 'SITUATION DE PAIEMENT', y); y -= 22;
    field('Montant total du matériel', nf(tt.total) + ' ' + cur, M, y, 300, { sz: 10.5 });
    if (CMD) field('Livraison souhaitée', dt.delai || '', M + 318, y, W - 2 * M - 318);
    else if (dt.mode) { var ML = { caisse: 'Espèces', banque: 'Virement', mobile_money: 'Mobile Money', cheque: 'Chèque', autre: 'Autre' }; field('Mode', ML[dt.mode] || dt.mode, M + 318, y, W - 2 * M - 318); }
    y -= 19; field(CMD ? 'Acompte versé' : 'Payé à ce jour', nf(tt.paye) + ' ' + cur, M, y, 300, { sz: 10.5 });
    if (CMD) field('Conditions', dt.conditions || '', M + 318, y, W - 2 * M - 318);
    else if (dt.reference) field('Réf.', dt.reference, M + 318, y, W - 2 * M - 318);
    y -= 24; var bh = 28; R(M, y - bh + 8, W - 2 * M, bh, SOFT); RS(M, y - bh + 8, W - 2 * M, bh, GOLD, 1.2); R(M, y - bh + 8, 5, bh, GOLD);
    T(CMD ? 'SOLDE À PAYER' : 'RESTE À PAYER', M + 16, y - 6, 9, { b: true, c: NAVY });
    T(nf(tt.reste) + ' ' + cur, M + 150, y - 7, 15, { b: true, c: tt.reste > 0.005 ? [0.70, 0.12, 0.12] : [0.05, 0.45, 0.20] });
    var stl = { 'payé': 'SOLDÉ', 'partiel': 'PAIEMENT PARTIEL', 'à payer': 'NON PAYÉ', 'aucun': '' }[tt.statut] || ''; if (CMD) stl = '';
    if (stl) T(stl, W - M - 12, y - 6, 10, { b: true, c: NAVY, al: 'r' });
    y -= bh + 4;

    /* 3. réception */
    y -= 6; section(3, CMD ? 'ENGAGEMENT' : 'RÉCEPTION', y); y -= 18;
    var conf = CMD ? 'Nous commandons au fournisseur désigné ci-dessus le matériel listé, aux quantités et prix indiqués, à livrer au lieu et à la date précisés. Le fournisseur confirme pouvoir livrer dans ces conditions. Ce bon ne remplace pas une facture.' : 'Nous attestons avoir livré à l’entreprise désignée ci-dessus le matériel listé. Le réceptionnaire reconnaît l’avoir reçu en bon état et en quantité conforme, sous réserve des remarques ci-dessous. Ce document prouve la livraison ; il ne remplace pas une facture lorsque celle-ci est requise.';
    wrap(conf, W - 2 * M, 8.2).forEach(function (s) { T(s, M, y, 8.2); y -= 10.5; });
    y -= 4; field('Remarques', dt.remarques || '', M, y, W - 2 * M); y -= 22;
    var bw = (W - 2 * M - 16) / 2, by = y - 62;
    RS(M, by, bw, 66, LINE, .8); RS(M + bw + 16, by, bw, 66, LINE, .8);
    T(CMD ? 'COMMANDÉ PAR' : 'LIVRÉ PAR', M + 8, y - 8, 7.8, { b: true, c: NAVY }); T(CMD ? 'ACCEPTÉ PAR LE FOURNISSEUR (nom, signature, cachet)' : 'REÇU PAR (nom, signature et cachet)', M + bw + 24, y - 8, 7.8, { b: true, c: NAVY });
    var opS = null; try { if (w.EXBOperateur && w.EXBOperateur.signeSeul && w.EXBOperateur.signeSeul()) { var po = w.EXBOperateur.get(); if (po && po.nom) opS = { nom: po.nom, role: po.fonction || 'Opérateur' }; } } catch (e) { }
    var liv = san(dt.livreur || (opS && opS.nom) || dt.dg || (I.dg) || '');
    if (liv) { var dsz = 13; while (F4.widthOfTextAtSize(liv, dsz) > bw - 20 && dsz > 8) dsz -= .5; pg.drawText(liv, { x: M + 8, y: by + 30, size: dsz, font: F4, color: rgb(BLUE) }); }
    T(opS ? opS.role : (dt.livreur ? '' : (I.dgRole || 'Directeur Général')), M + 8, by + 18, 8.2, { b: true });
    try { if (env.visa) { var vi = env.visa.png ? await pdf.embedPng(env.visa.b) : await pdf.embedJpg(env.visa.b), vh = 34, vw = vh * vi.width / vi.height; if (vw > 110) { vw = 110; vh = vw * vi.height / vi.width; } pg.drawImage(vi, { x: M + bw - vw - 6, y: by + 6, width: vw, height: vh }); } } catch (e) { }
    if (dt.receveur) { var rf = fit(dt.receveur + (dt.receveur_fonction ? ' — ' + dt.receveur_fonction : ''), bw - 16, 9.2, true); T(rf.t, M + bw + 24, by + 40, rf.sz, { b: true }); }
    T('Date : ' + fd(dt.date), M + bw + 24, by + 6, 7.6, { c: GREY });

    /* QR */
    var qy = by - 76;
    if (env.qrMatrix) {
      var m = env.qrMatrix, n = m.length, q = 2, t = n + 2 * q, qs = 62, s = qs / t, qx = M;
      R(qx, qy, qs, qs, [1, 1, 1]); RS(qx, qy, qs, qs, LINE, .6);
      for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) pg.drawRectangle({ x: qx + (c + q) * s, y: qy + qs - (r + q + 1) * s, width: s + .15, height: s + .15, color: lib.rgb(0, 0, 0) });
      T('Scannez pour vérifier', qx + qs + 10, qy + 38, 8.4, { b: true, c: NAVY });
      T('l’authenticité du ' + (CMD ? 'bon de commande' : 'bon'), qx + qs + 10, qy + 27, 8.4, { b: true, c: NAVY });
      if (env.qrCode) T('Code ' + String(env.qrCode).toUpperCase(), qx + qs + 10, qy + 15, 7.6, { c: GREY });
    }
    T('Toute correction doit être validée et authentifiée par ' + nom + '.', M + 215, qy + 38, 7.6, { c: GREY });
    /* pied */
    R(0, 0, W, 42, NAVY); R(0, 42, W, 3, GOLD);
    T('EXCELLENCIA BUILDING  •  Architecture  •  Ingénierie  •  Réalisation', W / 2, 26, 8.6, { b: true, c: [1, 1, 1], al: 'c' });
    T('WhatsApp : ' + TEL + '  |  E-mail : ' + MAIL, W / 2, 12, 8.2, { c: [0.95, 0.82, 0.40], al: 'c' });
    pdf.setTitle((CMD ? 'Bon de commande ' : 'Bon de livraison ') + (dt.no || '')); pdf.setAuthor('Excellencia Building');
    return pdf.save();
  }

  async function make(dt) {
    var lib = await loadLib(), ID = null; try { ID = w.EXBId ? w.EXBId.get() : null; } catch (e) { }
    var env = { id: ID };
    env.logo = await imgBytes((ID && ID.logo) || 'icon-192.png') || await imgBytes('icon-192.png');
    try { if (w.EXBSign && w.EXBSign.anyVisa) { var vu = await w.EXBSign.anyVisa('png'); if (vu) env.visa = await imgBytes(vu); } } catch (e) { }
    try {
      if (w.EXBVerif && w.EXBVerif.code && w.EXBQR) {
        var tt = totaux(dt.lignes, dt.paye), key = [dt.entreprise_dest || '', dt.projet || '', (dt.lignes || []).length, tt.total, tt.paye].join('|');
        var c1 = w.EXBVerif.code('g', dt.no, dt.date, tt.total, dt.devise || '', key, dt.entreprise_dest || '');
        env.qrMatrix = w.EXBQR.matrix(c1.url); env.qrCode = c1.hash;
        w.EXBVerif.publish({ no: dt.no, kind: 'document', hash: c1.hash, date: dt.date, total: tt.total, cur: dt.devise || '', status: 'valide', nom: dt.entreprise_dest || '', matricule: '', libelle: (dt.type === 'commande' ? 'Bon de commande de matériel — ' : 'Bon de livraison de matériel — ') + (dt.projet || dt.entreprise_dest || ''), detail: 'Payé ' + nf(tt.paye) + ' / reste ' + nf(tt.reste) });
      }
    } catch (e) { env.qrMatrix = null; }
    dt.entreprise = (ID && ID.name) || ''; dt.dg = dt.dg || (ID && ID.dg) || '';
    return new Blob([await build(lib, dt, env)], { type: 'application/pdf' });
  }

  /* ---------- interface (Reçus de paiement, au-dessus du guichet) ---------- */
  var S = { lignes: [{ des: '', qte: '', unite: 'u', pu: '' }] };
  function ligneHtml(l, i) {
    return '<div class="lvl" data-i="' + i + '" data-bib="' + esc(l.bib || '') + '" data-ref="' + esc(l.ref || '') + '" style="display:grid;grid-template-columns:2fr .7fr .7fr .9fr auto;gap:4px;margin-bottom:4px">' +
      '<input class="lv-des" placeholder="Matériel (ex. Ciment CPA 42,5)" maxlength="80" value="' + esc(l.des) + '"/>' +
      '<input class="lv-qte" inputmode="decimal" placeholder="Qté" value="' + esc(l.qte) + '"/>' +
      '<input class="lv-unite" placeholder="Unité" maxlength="10" value="' + esc(l.unite) + '"/>' +
      '<input class="lv-pu" inputmode="decimal" placeholder="Prix unit." value="' + esc(l.pu) + '"/>' +
      '<button type="button" class="muted lv-del" title="Retirer">✕</button></div>';
  }
  function lire() {
    var a = []; d.querySelectorAll('#lvLignes .lvl').forEach(function (r) {
      a.push({ bib: r.getAttribute('data-bib') || '', ref: r.getAttribute('data-ref') || '', des: r.querySelector('.lv-des').value.trim(), qte: r.querySelector('.lv-qte').value.trim(), unite: r.querySelector('.lv-unite').value.trim(), pu: r.querySelector('.lv-pu').value.trim() });
    }); return a;
  }
  function majTotaux() {
    var t = totaux(lire(), $('lvPaye').value), dv = $('lvDev').value;
    $('lvTot').innerHTML = 'Total : <b>' + esc(fmt(t.total, dv)) + '</b> · Payé : <b>' + esc(fmt(t.paye, dv)) + '</b> · Reste : <b style="color:' + (t.reste > 0 ? '#b32020' : '#0d7a3a') + '">' + esc(fmt(t.reste, dv)) + '</b>' + (t.surplus ? ' <span class="hint">(paiement supérieur au total de ' + esc(fmt(t.surplus, dv)) + ')</span>' : '');
  }
  function dessiner() { $('lvLignes').innerHTML = S.lignes.map(ligneHtml).join(''); majTotaux(); }
  function say(m, ok) { var b = $('lvBanner'); if (b) { b.className = 'msg ' + (ok ? 'ok' : 'warn'); b.innerHTML = m; b.style.display = 'block'; } }
  function liste() {
    var all = rd(KEY).slice().reverse().slice(0, 8), el = $('lvListe'); if (!el) return;
    el.innerHTML = all.length ? all.map(function (r) {
      return '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;border-bottom:1px solid #e4e8ef;padding:5px 0"><span><b>' + esc(r.no) + '</b> · ' + esc(r.entreprise_dest) + ' · ' + esc(fmt(r.total, r.devise)) + ' · reste <b>' + esc(fmt(r.reste, r.devise)) + '</b></span><button type="button" class="muted" data-lvpdf="' + esc(r.no) + '">📄 PDF</button></div>';
    }).join('') : '<p class="hint">Aucun bon pour l’instant.</p>';
  }
  async function aller() {
    var ent = $('lvEnt').value.trim(), lg = lire().filter(function (l) { return l.des && num(l.qte) > 0; });
    if (!ent) return say(isCmd() ? 'Indiquez le fournisseur.' : 'Indiquez l’entreprise destinataire.');
    if (!lg.length) return say('Ajoutez au moins une ligne de matériel avec une quantité.');
    if (lg.length > MAXL) return say('Maximum ' + MAXL + ' lignes par bon : faites un second bon.');
    var date = $('lvDate').value || today(), all = rd(KEY), no = nextNo(all, date, isCmd() ? 'BC' : 'BL'), t = totaux(lg, $('lvPaye').value);
    var rec = { type: isCmd() ? 'commande' : 'livraison', delai: $('lvDelai').value.trim(), conditions: $('lvCond').value.trim(), no: no, date: date, entreprise_dest: ent, contact: $('lvContact').value.trim(), projet: $('lvProj').value.trim(), devise: $('lvDev').value, lignes: lg, total: t.total, paye: t.paye, reste: t.reste,
      mode: $('lvMode').value, reference: $('lvRef').value.trim(), receveur: $('lvRecv').value.trim(), receveur_fonction: $('lvRecvF').value.trim(), remarques: $('lvRem').value.trim(), at: new Date().toISOString() };
    try {
      var blob = await make(rec); all.push(rec); if (!wr(KEY, all)) return say('Enregistrement impossible (stockage plein ?). Le bon n’a pas été créé.');
      audit(isCmd() ? 'COMMANDE_MATERIEL' : 'LIVRAISON_MATERIEL', no + ' — ' + ent + ' — ' + fmt(t.total, rec.devise));
      var url = URL.createObjectURL(blob);
      say('✓ Bon n° <b>' + esc(no) + '</b> créé pour ' + esc(ent) + (isCmd() ? ' · solde à payer <b>' : ' · reste à payer <b>') + esc(fmt(t.reste, rec.devise)) + '</b>.', true);
      $('lvResult').innerHTML = '<div class="actions"><a class="gold" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + url + '" target="_blank" rel="noopener">📄 Ouvrir le bon</a> <a class="muted" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + url + '" download="' + esc(no) + '.pdf">⬇ Télécharger</a></div>';
      liste();
    } catch (e) { say('Impossible de faire le PDF : ' + esc(e && e.message || e)); }
  }
  function isCmd() { var t = $('lvType'); return !!t && t.value === 'commande'; }
  function typeUi() {
    var c = isCmd();
    $('lvEntL').textContent = c ? 'Fournisseur' : 'Entreprise destinataire'; $('lvEnt').placeholder = c ? 'Nom du fournisseur' : 'Nom de l’entreprise';
    $('lvPayeL').textContent = c ? 'Acompte versé (facultatif)' : 'Payé à ce jour'; $('lvRecvL').textContent = c ? 'Accepté par (nom, facultatif)' : 'Reçu par (nom)';
    $('lvCmdBox').style.display = c ? 'grid' : 'none'; $('lvGo').textContent = c ? '🛒 Faire le bon de commande' : '📦 Faire le bon de livraison'; majTotaux();
  }
  function mount() {
    var sec = $('receipts'); if (!sec || $('exbLivCard')) return;
    var c = d.createElement('div'); c.id = 'exbLivCard'; c.className = 'card no-print'; c.style.marginBottom = '14px';
    c.innerHTML = '<h2>📦 Bons de livraison et de commande</h2>' +
      '<label>Type de bon</label><select id="lvType"><option value="livraison">📦 Bon de livraison (matériel remis à une entreprise)</option><option value="commande">🛒 Bon de commande (matériel commandé à un fournisseur)</option></select>' +
      '<p class="hint" style="margin:0 0 8px">Quand du matériel est remis à une entreprise : le bon prouve ce qui a été livré, ce qui a été payé et ce qui reste à payer (PDF avec QR de vérification).</p>' +
      '<label id="lvEntL">Entreprise destinataire</label><input id="lvEnt" maxlength="80" list="lvEntList" autocomplete="off" placeholder="Nom de l’entreprise"/><datalist id="lvEntList"></datalist>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label>Chantier / lieu</label><input id="lvProj" maxlength="80"/></div><div><label>Contact / Tél</label><input id="lvContact" maxlength="40"/></div></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label>Date</label><input id="lvDate" type="date"/></div><div><label>Devise</label><select id="lvDev"><option value="USD">USD ($)</option><option value="FC">FC</option></select></div></div>' +
      '<label style="margin-top:6px">Matériel livré (' + MAXL + ' lignes max.)</label><div id="lvLignes"></div>' +
      '<div class="actions"><button type="button" class="primary" id="lvBib">📚 Ajouter depuis la bibliothèque</button><button type="button" class="muted" id="lvAdd">➕ Ligne libre</button></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label id="lvPayeL">Payé à ce jour</label><input id="lvPaye" inputmode="decimal" placeholder="0"/></div><div><label>Mode de paiement</label><select id="lvMode"><option value="">—</option><option value="caisse">Espèces</option><option value="banque">Virement</option><option value="mobile_money">Mobile Money</option><option value="cheque">Chèque</option><option value="autre">Autre</option></select></div></div>' +
      '<label>Référence du paiement (facultatif)</label><input id="lvRef" maxlength="60"/><div id="lvTot" style="margin:6px 0;font-size:14px"></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label id="lvRecvL">Reçu par (nom)</label><input id="lvRecv" maxlength="60"/></div><div><label>Fonction</label><input id="lvRecvF" maxlength="40"/></div></div>' +
      '<div id="lvCmdBox" style="display:none;grid-template-columns:1fr 1fr;gap:6px"><div><label>Livraison souhaitée (date ou délai)</label><input id="lvDelai" maxlength="40"/></div><div><label>Conditions de paiement</label><input id="lvCond" maxlength="50" placeholder="ex. 50 % à la commande"/></div></div>' +
      '<label>Remarques (facultatif)</label><input id="lvRem" maxlength="120"/>' +
      '<div class="actions" style="margin-top:8px"><button type="button" class="primary" id="lvGo">📦 Faire le bon</button></div>' +
      '<div id="lvBanner" class="msg" style="display:none"></div><div id="lvResult"></div>' +
      '<details style="margin-top:10px"><summary><b>📒 Derniers bons</b></summary><div id="lvListe" style="margin-top:6px"></div></details>';
    sec.insertBefore(c, sec.firstChild);
    $('lvDate').value = today(); dessiner(); liste();
    $('lvType').onchange = typeUi; typeUi();
    try { var cl = rd('exb_clients').map(function (x) { return String(x && (x.name || x.company || x.nom || x.client) || '').trim(); }).filter(Boolean); $('lvEntList').innerHTML = cl.filter(function (v, i) { return cl.indexOf(v) === i; }).slice(0, 200).map(function (v) { return '<option value="' + esc(v) + '">'; }).join(''); } catch (e) { }
    $('lvAdd').onclick = function () { if (lire().length >= MAXL) return say('Maximum ' + MAXL + ' lignes par bon.'); S.lignes = lire(); S.lignes.push({ des: '', qte: '', unite: 'u', pu: '' }); dessiner(); };
    $('lvLignes').addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('.lv-del'); if (!b) return; S.lignes = lire(); S.lignes.splice(+b.parentNode.getAttribute('data-i'), 1); if (!S.lignes.length) S.lignes = [{ des: '', qte: '', unite: 'u', pu: '' }]; dessiner(); });
    c.addEventListener('input', majTotaux); $('lvDev').onchange = majTotaux;
    $('lvBib').onclick = function () {
      if (!w.EXB_BIB || !w.EXB_BIB.pick) return say('La bibliothèque BTP n’est pas disponible dans cette copie : utilisez « Ligne libre ».');
      w.EXB_BIB.pick({ multi: true, title: 'Choisir le matériel (plusieurs possibles, puis « Envoyer au document »)', add: function (l, q) {
        var cur = $('lvDev').value === 'FC' ? 'CDF' : 'USD', pu = l.price == null ? null : w.EXB_BIB.conv(l.price, l.cur, cur);
        var pus = pu == null ? '' : String(Math.round(pu * 100) / 100);
        var L = lire().filter(function (x) { return x.des || x.qte || x.pu; }); q = num(q) > 0 ? num(q) : 1;
        var ex = null; L.forEach(function (x) { if (l.id && x.bib === l.id && String(x.pu) === pus) ex = x; });
        if (ex) ex.qte = String(r2(num(ex.qte) + q));
        else { if (L.length >= MAXL) { say('Maximum ' + MAXL + ' lignes par bon.'); return false; } L.push({ des: l.name, qte: String(q), unite: l.unit || '', pu: pus, bib: l.id || '', ref: l.ref || '' }); }
        S.lignes = L; dessiner();
        say('Ajouté : ' + esc(l.name) + (pu == null ? ' — prix à saisir (prix ou taux de change absent)' : ''), true); return true;
      } });
    };
    $('lvGo').onclick = aller;
    $('lvListe').addEventListener('click', async function (e) {
      var b = e.target.closest && e.target.closest('[data-lvpdf]'); if (!b) return;
      var r = rd(KEY).filter(function (x) { return x.no === b.getAttribute('data-lvpdf'); })[0]; if (!r) return;
      try { var u = URL.createObjectURL(await make(JSON.parse(JSON.stringify(r)))); w.open(u, '_blank'); } catch (er) { say('PDF impossible : ' + esc(er && er.message || er)); }
    });
  }
  if (w.document) {
    var _s = w.show;
    if (typeof _s === 'function') w.show = function (x) { var r = _s.apply(this, arguments); if (x === 'receipts') { try { mount(); } catch (e) { } } return r; };
  }
  w.EXBLivraison = { build: build, make: make, mount: mount, totaux: totaux, nextNo: nextNo };
  if (typeof module !== 'undefined' && module.exports) module.exports = { build: build, totaux: totaux, nextNo: nextNo };
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
