/* Excellencia Building V231 — 🏦 TRÉSORERIE & RAPPROCHEMENT (Lot 3 du cahier « Portail Comptable V229+ »).
 * Caisses, banques et Mobile Money PAR DEVISE ; transferts ; import de relevé (CSV) ; rapprochement anti-doublon ; clôture de caisse ;
 * raccord des paiements/encaissements confirmés du Centre de réception vers la caisse existante, sans doublon.
 * ADAPTATEUR : lit exb_cash (caisse existante, jamais réécrite hors raccord explicite), exb_cr_demandes (Centre de réception).
 * Clés créées : exb_tr_comptes, exb_tr_transferts, exb_tr_releve, exb_tr_rapprochements, exb_tr_clotures, exb_tr_audit.
 * Seule écriture dans exb_cash : le bouton « Écrire en caisse » (une ligne, marquée cr_ref, refusée si déjà écrite).
 * Un paiement DÉCLARÉ par un client n’entre jamais ici : seul un encaissement confirmé dans le Centre est proposé.
 * Ne remplace ni exb-compta*.js, ni exb-v78-finance.js, ni le rapprochement V92. Retirer : supprimer la balise <script src="exb-v231-tresorerie.js">. */
(function (w, d) {
  'use strict';
  if (w.EXBTR) return;
  var K = { C: 'exb_tr_comptes', T: 'exb_tr_transferts', R: 'exb_tr_releve', M: 'exb_tr_rapprochements', L: 'exb_tr_clotures', A: 'exb_tr_audit', D: 'exb_cr_demandes' };
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nc(c) { c = String(c || 'USD').toUpperCase(); return /^(FC|CDF)$/.test(c) ? 'CDF' : c; }
  function nrm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
  function iso(x) { var s = String(x || '').slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ''; }
  function jour() { var n = new Date(); return n.getFullYear() + '-' + ('0' + (n.getMonth() + 1)).slice(-2) + '-' + ('0' + n.getDate()).slice(-2); }
  function ecartJours(a, b) { return Math.abs(Math.round((new Date(a + 'T00:00:00') - new Date(b + 'T00:00:00')) / 864e5)); }
  function nf(n, c) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: c === 'CDF' ? 0 : 2, maximumFractionDigits: c === 'CDF' ? 0 : 2 }).replace(/\u202f/g, ' '); }
  function fm(o) { var k = Object.keys(o || {}).filter(function (c) { return Math.abs(o[c]) > 0.004; }); return k.length ? k.map(function (c) { return nf(o[c], c) + ' ' + c; }).join(' · ') : '—'; }
  function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7); }
  var TYPES = { caisse: 'Caisse', banque: 'Banque', mobile: 'Mobile Money' };

  /* ---------- stockage ---------- */
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function raw(k) { var S = store(); try { return S ? S.getItem(k) : w.localStorage.getItem(k); } catch (e) { return null; } }
  function rdA(k) { try { var v = JSON.parse(raw(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function wr(k, v) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(v)); else w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function cashLire() { try { if (typeof exbCash !== 'undefined' && exbCash && exbCash.length != null) return exbCash; } catch (e) {} return rdA('exb_cash'); }
  function cashEcrire(entry) {
    try { if (typeof exbCash !== 'undefined' && typeof exbSave === 'function') { exbCash.push(entry); exbSave('exb_cash', exbCash); try { if (typeof renderExbCash === 'function') renderExbCash(); if (typeof updateExbDirection === 'function') updateExbDirection(); } catch (e) {} return true; } } catch (e) {}
    var a = rdA('exb_cash'); a.push(entry); return wr('exb_cash', a);
  }
  function peutEcrire() { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can('rapprochement_bancaire', 'ecrire') || w.EXB_CORE.can('comptabilite', 'ecrire'); } catch (e) { return true; } }
  function qui() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.nom)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function audit(action, o) { var a = rdA(K.A); a.push(Object.assign({ le: new Date().toISOString(), par: qui(), action: action }, o || {})); wr(K.A, a); }

  /* ---------- fonctions pures (testées) ---------- */
  function typeDepuisMode(m) { m = nrm(m); return /esp|cash|caisse/.test(m) || !m ? 'caisse' : /mobile|mpesa|m pesa|airtel|orange|money/.test(m) ? 'mobile' : 'banque'; }
  /* compte d’une écriture de caisse : compte_id explicite, sinon premier compte actif de la même devise et du même type de moyen ; sinon « non affecté » */
  function compteDe(x, comptes) {
    if (x.compte_id && comptes.some(function (c) { return c.id === x.compte_id; })) return x.compte_id;
    var cu = nc(x.currency || x.devise), t = typeDepuisMode(x.method || x.mode), l = comptes.filter(function (c) { return c.actif !== false && c.devise === cu && c.type === t; })[0];
    return l ? l.id : '__none__' + cu;
  }
  function trouveCompteParNom(txt, mode, cur, comptes) {
    var k = nrm(txt), l = comptes.filter(function (c) { return c.actif !== false && c.devise === cur && nrm(c.nom) === k; })[0] || comptes.filter(function (c) { return c.actif !== false && c.devise === cur && k && (nrm(c.nom).indexOf(k) >= 0 || k.indexOf(nrm(c.nom)) >= 0); })[0] || comptes.filter(function (c) { return c.actif !== false && c.devise === cur && c.type === typeDepuisMode(mode); })[0];
    return l ? l.id : '';
  }
  function mvCash(cash, comptes) {
    return (cash || []).filter(function (x) { return x && +x.amount > 0 && (x.type === 'in' || x.type === 'out'); }).map(function (x) {
      var cu = nc(x.currency || x.devise); return { key: 'c:' + x.id, src: 'caisse', id: x.id, date: iso(x.date), compte: compteDe(x, comptes), cur: cu, signe: x.type === 'in' ? 1 : -1, montant: r2(+x.amount), label: x.label || (x.type === 'in' ? 'Recette' : 'Dépense'), ref: x.ref || '' };
    });
  }
  function mvTransferts(tr) {
    var o = []; (tr || []).forEach(function (t) {
      if (t.annule) return;
      o.push({ key: 't:' + t.id + ':de', src: 'transfert', id: t.id, date: iso(t.date), compte: t.de, cur: nc(t.devise_de), signe: -1, montant: r2(t.montant), label: 'Transfert vers ' + (t.vers_nom || ''), ref: t.ref || '' });
      if (+t.frais > 0) o.push({ key: 't:' + t.id + ':fr', src: 'transfert', id: t.id, date: iso(t.date), compte: t.de, cur: nc(t.devise_de), signe: -1, montant: r2(t.frais), label: 'Frais de transfert', ref: t.ref || '' });
      o.push({ key: 't:' + t.id + ':vers', src: 'transfert', id: t.id, date: iso(t.date), compte: t.vers, cur: nc(t.devise_vers), signe: 1, montant: r2(t.montant_vers), label: 'Transfert depuis ' + (t.de_nom || ''), ref: t.ref || '' });
    }); return o;
  }
  /* paiements/encaissements CONFIRMÉS dans le Centre, avec leur clé d’unicité (demande + rang) */
  function mvCentre(dem, comptes) {
    var o = []; (dem || []).forEach(function (x) {
      if (!x) return;
      if (x.type === 'Paiement déclaré par un client') { var e = x.encaissement; if (e && e.confirme) { var cu = nc(x.devise); o.push({ key: x.ref + '#enc', src: 'centre', ref: x.ref, date: iso(e.date), cur: cu, signe: 1, montant: r2(+x.montant), mode: '', compteTxt: e.compte, compte: trouveCompteParNom(e.compte, '', cu, comptes), reference: e.reference || '', label: 'Encaissement confirmé — ' + (x.tiers || x.objet || x.ref) }); } return; }
      (x.paiements || []).forEach(function (p, i) { var cu = nc(p.devise); o.push({ key: x.ref + '#' + i, src: 'centre', ref: x.ref, date: iso(p.date), cur: cu, signe: -1, montant: r2(+p.montant), mode: p.mode || '', compteTxt: p.compte, compte: trouveCompteParNom(p.compte, p.mode, cu, comptes), reference: p.reference || '', label: 'Paiement — ' + (x.tiers || x.objet || x.ref) }); });
    }); return o;
  }
  function centreAEcrire(mc, cash) { var deja = {}; (cash || []).forEach(function (c) { if (c && c.cr_ref) deja[c.cr_ref] = 1; }); return mc.filter(function (m) { return !deja[m.key]; }); }
  function ligneCaisseDepuisCentre(m, compteId, now) {
    return { id: uid('CASH'), date: m.date, type: m.signe > 0 ? 'in' : 'out', label: m.label, amount: m.montant, currency: m.cur, method: m.mode || (m.signe > 0 ? 'Virement bancaire' : 'Autre'), ref: m.reference, compte_id: compteId || '', cr_ref: m.key, source: 'centre-reception', cree_le: now || new Date().toISOString() };
  }
  function soldeCompte(c, mvs) {
    var s = +c.ouverture || 0, dt = iso(c.ouverture_date); mvs.forEach(function (m) { if (m.compte === c.id && (!dt || !m.date || m.date >= dt)) s += m.signe * m.montant; }); return r2(s);
  }
  function soldesParDevise(comptes, mvs) { var o = {}; comptes.forEach(function (c) { if (c.actif === false) return; o[c.devise] = r2((o[c.devise] || 0) + soldeCompte(c, mvs)); }); mvs.forEach(function (m) { if (/^__none__/.test(m.compte)) o[m.cur] = r2((o[m.cur] || 0) + m.signe * m.montant); }); return o; }
  function validerCompte(c, comptes) {
    var e = []; if (!String(c.nom || '').trim()) e.push('Le nom du compte est obligatoire.'); if (!TYPES[c.type]) e.push('Type de compte invalide.'); if (['USD', 'CDF'].indexOf(nc(c.devise)) < 0) e.push('Devise : USD ou CDF.');
    if (comptes.some(function (x) { return nrm(x.nom) === nrm(c.nom) && nc(x.devise) === nc(c.devise) && x.id !== c.id; })) e.push('Un compte du même nom existe déjà dans cette devise.'); if (c.ouverture_date && !iso(c.ouverture_date)) e.push('Date d’ouverture invalide.'); return e;
  }
  function validerTransfert(t, comptes, mvs) {
    var e = [], a = comptes.filter(function (c) { return c.id === t.de; })[0], b = comptes.filter(function (c) { return c.id === t.vers; })[0];
    if (!a || !b) return ['Choisissez les deux comptes.']; if (a.id === b.id) e.push('Le compte source et le compte de destination doivent différer.'); if (!(+t.montant > 0)) e.push('Le montant doit être supérieur à zéro.'); if (!iso(t.date)) e.push('Date obligatoire.');
    if (a.devise !== b.devise && !(+t.montant_vers > 0)) e.push('Devises différentes : saisissez le montant reçu (le taux réel est conservé).'); if (a.devise === b.devise && +t.montant_vers > 0 && r2(t.montant_vers) !== r2(t.montant)) e.push('Même devise : le montant reçu doit être égal au montant envoyé.');
    if (a.type === 'caisse' && r2(soldeCompte(a, mvs) - (+t.montant || 0) - (+t.frais || 0)) < -0.005) e.push('Solde insuffisant dans la caisse « ' + a.nom + ' ».'); return e;
  }
  function construireTransfert(t, comptes, qui_, now) {
    var a = comptes.filter(function (c) { return c.id === t.de; })[0], b = comptes.filter(function (c) { return c.id === t.vers; })[0], mv = a.devise === b.devise ? r2(t.montant) : r2(t.montant_vers);
    return { id: uid('TRF'), date: iso(t.date), de: a.id, de_nom: a.nom, vers: b.id, vers_nom: b.nom, devise_de: a.devise, devise_vers: b.devise, montant: r2(t.montant), montant_vers: mv, taux_reel: a.devise === b.devise ? 1 : r2(a.devise === 'USD' ? mv / t.montant : t.montant / mv), frais: r2(t.frais || 0), ref: String(t.ref || '').trim(), motif: String(t.motif || '').trim(), par: qui_ || '', le: now || new Date().toISOString() };
  }
  /* ---- import de relevé CSV ---- */
  function nombre(s) { s = String(s == null ? '' : s).trim(); if (!s) return NaN; var neg = /^\(.*\)$/.test(s) || /^-/.test(s) || /-$/.test(s); s = s.replace(/[()\s\u00a0\u202f-]/g, '').replace(/[A-Za-z$€]/g, ''); if (/,\d{1,2}$/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else s = s.replace(/,/g, ''); var v = parseFloat(s); return isNaN(v) ? NaN : (neg ? -Math.abs(v) : v); }
  function dateRel(s) { s = String(s || '').trim(); var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s); if (m) return m[1] + '-' + m[2] + '-' + m[3]; m = /^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})/.exec(s); if (m) { var y = m[3].length === 2 ? '20' + m[3] : m[3]; return y + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2); } return ''; }
  function decouper(ligne, sep) { var o = [], cur = '', q = false, i; for (i = 0; i < ligne.length; i++) { var ch = ligne[i]; if (ch === '"') { if (q && ligne[i + 1] === '"') { cur += '"'; i++; } else q = !q; } else if (ch === sep && !q) { o.push(cur); cur = ''; } else cur += ch; } o.push(cur); return o; }
  function parseReleve(txt) {
    var L = String(txt || '').replace(/^\ufeff/, '').split(/\r?\n/).filter(function (l) { return l.trim(); }); if (!L.length) return { lignes: [], erreurs: ['Fichier vide.'] };
    var sep = ['\t', ';', ','].filter(function (s) { return L[0].indexOf(s) >= 0; })[0] || ';', H = decouper(L[0], sep).map(nrm), idx = function (re) { for (var i = 0; i < H.length; i++) if (re.test(H[i])) return i; return -1; };
    var iD = idx(/^date/), iL = idx(/libelle|description|motif|operation|narrat/), iM = idx(/^montant|amount/), iDe = idx(/debit|sortie/), iCr = idx(/credit|entree/), iR = idx(/ref|numero|n transaction|id/);
    var entete = iD >= 0 && (iM >= 0 || (iDe >= 0 && iCr >= 0)); if (!entete) { iD = 0; iL = 1; iM = 2; iR = 3; iDe = -1; iCr = -1; } var out = [], err = [];
    L.slice(entete ? 1 : 0).forEach(function (l, n) {
      var c = decouper(l, sep), dt = dateRel(c[iD]), m = iM >= 0 ? nombre(c[iM]) : (function () { var cr = nombre(c[iCr]), de = nombre(c[iDe]); return (isNaN(cr) ? 0 : Math.abs(cr)) - (isNaN(de) ? 0 : Math.abs(de)); })();
      if (!dt || isNaN(m) || m === 0) { err.push('Ligne ' + (n + (entete ? 2 : 1)) + ' ignorée (date ou montant illisible).'); return; }
      out.push({ date: dt, libelle: String(c[iL] == null ? '' : c[iL]).trim(), montant: r2(m), ref: String(c[iR] == null ? '' : c[iR]).trim() });
    }); return { lignes: out, erreurs: err };
  }
  function empreinte(compteId, l) { return [compteId, l.date, r2(l.montant).toFixed(2), nrm(l.libelle), nrm(l.ref)].join('|'); }
  function importer(rows, compte, existantes, now) {
    var vus = {}, nv = [], dbl = 0; (existantes || []).forEach(function (x) { vus[x.empreinte] = 1; });
    rows.forEach(function (l) { var e = empreinte(compte.id, l); if (vus[e]) { dbl++; return; } vus[e] = 1; nv.push({ id: uid('REL'), compte: compte.id, date: l.date, libelle: l.libelle, montant: l.montant, devise: compte.devise, ref: l.ref, empreinte: e, importe_le: now || new Date().toISOString() }); });
    return { nouveaux: nv, doublons: dbl };
  }
  function actifs(matches) { return (matches || []).filter(function (m) { return !m.annule; }); }
  function suggerer(ligne, mvs, matches, jours) {
    var pris = {}; actifs(matches).forEach(function (m) { if (m.mv_key) pris[m.mv_key] = 1; }); var jmax = jours == null ? 7 : jours;
    return mvs.filter(function (m) { return m.compte === ligne.compte && m.cur === ligne.devise && !pris[m.key] && (m.signe * m.montant > 0) === (ligne.montant > 0) && Math.abs(m.montant - Math.abs(ligne.montant)) < 0.005 && (!m.date || ecartJours(m.date, ligne.date) <= jmax); })
      .sort(function (a, b) { return (nrm(b.ref) && nrm(b.ref) === nrm(ligne.ref) ? 1 : 0) - (nrm(a.ref) && nrm(a.ref) === nrm(ligne.ref) ? 1 : 0) || ecartJours(a.date || ligne.date, ligne.date) - ecartJours(b.date || ligne.date, ligne.date); });
  }
  function creerRapprochement(ligne, mv, matches, ctx) {
    ctx = ctx || {}; var act = actifs(matches);
    if (act.some(function (m) { return m.ligne_id === ligne.id; })) return { ok: false, err: 'Cette ligne du relevé est déjà rapprochée : elle ne peut pas l’être deux fois.' };
    if (mv && act.some(function (m) { return m.mv_key === mv.key; })) return { ok: false, err: 'Cette écriture est déjà rapprochée avec une autre ligne du relevé.' };
    if (mv) { if (mv.compte !== ligne.compte) return { ok: false, err: 'Les deux lignes appartiennent à des comptes différents.' }; if (mv.cur !== ligne.devise) return { ok: false, err: 'Devises différentes : rapprochement refusé.' }; if ((mv.signe * mv.montant > 0) !== (ligne.montant > 0)) return { ok: false, err: 'Sens opposé (entrée / sortie) : rapprochement refusé.' }; }
    var ecart = mv ? r2(Math.abs(ligne.montant) - mv.montant) : r2(Math.abs(ligne.montant)); if (Math.abs(ecart) > 0.005 && String(ctx.motif || '').trim().length < 3) return { ok: false, err: mv ? 'Montants différents (écart ' + ecart + ') : un motif est obligatoire.' : 'Un motif est obligatoire pour justifier une ligne sans écriture.' };
    return { ok: true, match: { id: uid('RAP'), ligne_id: ligne.id, mv_key: mv ? mv.key : '', type: mv ? 'rapproche' : 'justifie', ecart: ecart, motif: String(ctx.motif || '').trim(), par: ctx.qui || '', le: ctx.now || new Date().toISOString() } };
  }
  function bilanRapprochement(compte, mvs, lignes, matches) {
    var act = actifs(matches), l = lignes.filter(function (x) { return x.compte === compte.id; }), kM = {}, kL = {}; act.forEach(function (m) { if (m.mv_key) kM[m.mv_key] = 1; kL[m.ligne_id] = m; });
    var rNon = l.filter(function (x) { return !kL[x.id]; }), mNon = mvs.filter(function (m) { return m.compte === compte.id && !kM[m.key] && (!compte.ouverture_date || !m.date || m.date >= compte.ouverture_date); });
    var uR = r2(rNon.reduce(function (a, x) { return a + x.montant; }, 0)), uL = r2(mNon.reduce(function (a, m) { return a + m.signe * m.montant; }, 0)), livre = soldeCompte(compte, mvs), res = null;
    if (compte.solde_releve != null && compte.solde_releve !== '') res = r2((+compte.solde_releve - uR) - (livre - uL));
    var justifies = l.filter(function (x) { return kL[x.id] && kL[x.id].type === 'justifie'; });
    return { releveNon: rNon, livreNon: mNon, uR: uR, uL: uL, livre: livre, residuel: res, nbRapproches: l.length - rNon.length, ecartsJustifies: justifies.length };
  }
  function theoriqueCaisse(c, mvs, date) { var s = +c.ouverture || 0, dt = iso(c.ouverture_date); mvs.forEach(function (m) { if (m.compte === c.id && (!dt || !m.date || m.date >= dt) && (!date || !m.date || m.date <= date)) s += m.signe * m.montant; }); return r2(s); }
  function cloture(c, mvs, date, compte_, motif, qui_, existantes, now) {
    if (!iso(date)) return { ok: false, err: 'Date obligatoire.' };
    if (!c || c.type !== 'caisse') return { ok: false, err: 'La clôture ne concerne que les caisses.' };
    var n = nombre(compte_); if (isNaN(n) || n < 0) return { ok: false, err: 'Montant compté invalide.' };
    if ((existantes || []).some(function (x) { return x.compte === c.id && x.date === iso(date) && !x.annule; })) return { ok: false, err: 'Cette caisse est déjà clôturée à cette date.' };
    var th = theoriqueCaisse(c, mvs, iso(date)), ec = r2(n - th);
    if (Math.abs(ec) > 0.005 && String(motif || '').trim().length < 3) return { ok: false, err: 'Écart de ' + nf(ec, c.devise) + ' ' + c.devise + ' : un motif est obligatoire.' };
    return { ok: true, cloture: { id: uid('CLO'), compte: c.id, compte_nom: c.nom, devise: c.devise, date: iso(date), theorique: th, compte_physique: r2(n), ecart: ec, motif: String(motif || '').trim(), par: qui_ || '', le: now || new Date().toISOString() } };
  }

  /* ---------- lecture globale ---------- */
  function lire() {
    var comptes = rdA(K.C), cash = cashLire(), tr = rdA(K.T), dem = rdA(K.D), mvs = mvCash(cash, comptes).concat(mvTransferts(tr)), centre = mvCentre(dem, comptes);
    return { comptes: comptes, cash: cash, tr: tr, mvs: mvs, centre: centre, aEcrire: centreAEcrire(centre, cash), lignes: rdA(K.R), matches: rdA(K.M), clotures: rdA(K.L) };
  }
  function soldesGlobaux() { try { var D = lire(); return D.comptes.length ? soldesParDevise(D.comptes, D.mvs) : null; } catch (e) { return null; } }
  function nbARapprocher() { try { var D = lire(), n = 0; D.comptes.forEach(function (c) { if (c.type !== 'caisse' && c.actif !== false) n += bilanRapprochement(c, D.mvs, D.lignes, D.matches).releveNon.length; }); return n; } catch (e) { return 0; } }

  /* ---------- interface ---------- */
  var TAB = 'comptes', ERR = '', MSG = '', FORM = null, SELC = '', SELM = '', CLC = '';
  function css() {
    if ($('tr_css')) return; var s = d.createElement('style'); s.id = 'tr_css';
    s.textContent = '#tr_c{background:#f5f8fd;color:#1b2a41;border-radius:14px;max-width:1100px;width:100%;padding:14px;font-family:inherit;box-sizing:border-box}#tr_c *{box-sizing:border-box}' +
      '#tr_c h3{margin:0;color:#0f2a5c}#tr_c .hd{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px}#tr_c .x{border:0;background:#0f2a5c;color:#fff;border-radius:8px;padding:7px 12px;cursor:pointer;font-weight:700}' +
      '#tr_c .tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}#tr_c .tabs button{border:1px solid #d5deee;background:#fff;border-radius:9px;padding:8px 12px;cursor:pointer;font-weight:600;color:#1b2a41}#tr_c .tabs button.on{background:#0f2a5c;color:#fff;border-color:#0f2a5c}' +
      '#tr_c .cd{background:#fff;border:1px solid #e3e9f3;border-radius:12px;padding:12px;margin-bottom:10px;overflow:hidden}#tr_c .tw{overflow-x:auto}#tr_c table{width:100%;border-collapse:collapse;font-size:13px}#tr_c th{text-align:left;color:#5b6b82;padding:7px 6px;border-bottom:1px solid #e3e9f3;white-space:nowrap}#tr_c td{padding:8px 6px;border-bottom:1px solid #eef2f9;vertical-align:top}' +
      '#tr_c .r{text-align:right;white-space:nowrap}#tr_c .pl{display:inline-block;border-radius:999px;padding:2px 9px;font-size:11.5px;font-weight:700;background:#fdecc8;color:#8a5200;margin:1px 2px 1px 0}#tr_c .pl.v{background:#dcfce7;color:#166534}#tr_c .pl.r{background:#fee4e2;color:#b42318}' +
      '#tr_c .er{background:#fee4e2;border:1px solid #f3b7b1;color:#8a1c14;border-radius:8px;padding:8px 10px;margin-bottom:8px}#tr_c .ok{background:#dcfce7;border:1px solid #a7e3bb;color:#14532d;border-radius:8px;padding:8px 10px;margin-bottom:8px}#tr_c .mu{color:#5b6b82;font-size:12.5px}#tr_c label{display:block;font-size:12.5px;color:#5b6b82;margin-top:6px}#tr_c input,#tr_c select,#tr_c textarea{width:100%;padding:8px;border:1px solid #d5deee;border-radius:8px;font-size:14px;background:#fff;color:#1b2a41}' +
      '#tr_c .gr{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px}#tr_c .bt{background:#0f2a5c;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}#tr_c .bt.s{background:#e8edf6;color:#0f2a5c}#tr_c .bt.g{background:#b8860b}' +
      '#tr_c .kp{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;margin-bottom:10px}#tr_c .kp div{background:#fff;border:1px solid #e3e9f3;border-radius:12px;padding:10px}#tr_c .kp b{display:block;font-size:19px;color:#0f2a5c}' +
      '#tr_c .lg{border:1px solid #e3e9f3;border-radius:10px;padding:9px;margin-bottom:8px;background:#fbfcff}' +
      '@media print{body>*:not(#tr_ov){display:none!important}#tr_ov{position:static!important;background:#fff!important}#tr_c .tabs,#tr_c .x,#tr_c .no-print{display:none!important}}';
    d.head.appendChild(s);
  }
  function badge(t, c) { return '<span class="pl ' + (c || '') + '">' + esc(t) + '</span>'; }
  function tbl(h, rows) { return '<div class="tw"><table><thead><tr>' + h.map(function (x) { return '<th>' + x + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'; }
  function opt(v, t, sel) { return '<option value="' + esc(v) + '"' + (sel ? ' selected' : '') + '>' + esc(t) + '</option>'; }
  function nomCompte(D, id) { var c = D.comptes.filter(function (x) { return x.id === id; })[0]; return c ? c.nom + ' (' + c.devise + ')' : (/^__none__/.test(id) ? 'Non affecté (' + id.slice(8) + ')' : '—'); }
  function val(id) { var e = $(id); return e ? e.value : ''; }
  function dec(id) { return val(id).replace(',', '.'); }

  function vComptes(D) {
    var h = '', nonAff = D.mvs.filter(function (m) { return /^__none__/.test(m.compte); }).length, S = soldesParDevise(D.comptes, D.mvs), devs = Object.keys(S);
    h += '<div class="kp">' + (devs.length ? devs.map(function (c) { return '<div><span class="mu">Disponible ' + c + '</span><b>' + esc(nf(S[c], c)) + ' ' + c + '</b></div>'; }).join('') : '<div><span class="mu">Disponible</span><b>—</b></div>') + '<div><span class="mu">À écrire en caisse (Centre)</span><b>' + D.aEcrire.length + '</b></div><div><span class="mu">Lignes de relevé à rapprocher</span><b>' + nbARapprocher() + '</b></div></div>';
    h += '<div class="mu" style="margin-bottom:8px">Les devises restent séparées : aucun montant n’est converti ni additionné à une autre devise.</div>';
    if (nonAff) h += '<div class="cd"><span class="pl">' + nonAff + ' écriture(s) de caisse non affectée(s)</span> <span class="mu">Créez un compte de la même devise et du même type pour les rattacher automatiquement.</span></div>';
    if (FORM && FORM.kind === 'compte') {
      var f = FORM;
      h += '<div class="cd"><h4 style="margin:0 0 6px">' + (f.id ? 'Modifier le compte' : 'Nouveau compte') + '</h4><div class="gr"><div><label>Nom</label><input id="tc_nom" value="' + esc(f.nom) + '"></div><div><label>Type</label><select id="tc_type">' + Object.keys(TYPES).map(function (k) { return opt(k, TYPES[k], f.type === k); }).join('') + '</select></div><div><label>Devise</label><select id="tc_dev">' + opt('USD', 'USD', f.devise === 'USD') + opt('CDF', 'CDF', f.devise === 'CDF') + '</select></div>' +
        '<div><label>Solde d’ouverture</label><input id="tc_ouv" inputmode="decimal" value="' + esc(f.ouverture) + '"></div><div><label>Date d’ouverture</label><input id="tc_od" type="date" value="' + esc(f.ouverture_date) + '"></div><div><label>État</label><select id="tc_act">' + opt('1', 'Actif', f.actif !== false) + opt('0', 'Désactivé', f.actif === false) + '</select></div></div>' +
        '<p><button class="bt" id="tc_ok">Enregistrer</button> <button class="bt s" id="tc_no">Annuler</button></p><div class="mu">Les écritures antérieures à la date d’ouverture ne comptent pas dans le solde.</div></div>';
    } else h += '<p><button class="bt" id="tc_new">+ Nouveau compte</button></p>';
    h += '<div class="cd"><b>Comptes, caisses et Mobile Money</b>' + (D.comptes.length ? tbl(['Compte', 'Type', 'Devise', 'Solde', 'Ouverture', '', ''], D.comptes.map(function (c) { return '<tr><td><b>' + esc(c.nom) + '</b></td><td>' + esc(TYPES[c.type] || c.type) + '</td><td>' + c.devise + '</td><td class="r"><b>' + esc(nf(soldeCompte(c, D.mvs), c.devise)) + '</b></td><td class="r">' + esc(nf(c.ouverture || 0, c.devise)) + (c.ouverture_date ? '<br><span class="mu">' + esc(c.ouverture_date) + '</span>' : '') + '</td><td>' + (c.actif === false ? badge('Désactivé', 'r') : '') + '</td><td><button class="bt s" data-ce="' + esc(c.id) + '">Modifier</button></td></tr>'; })) : '<div class="mu">Aucun compte. Créez au moins une caisse par devise (ex. « Caisse principale » USD).</div>') + '</div>';
    return h;
  }
  function vMouvements(D) {
    var h = '<div class="cd"><b>Paiements et encaissements confirmés dans le Centre de réception</b><div class="mu" style="margin:4px 0 8px">Un paiement déclaré par un client n’apparaît jamais ici tant qu’il n’est pas confirmé. Chaque opération ne peut être écrite en caisse qu’une seule fois.</div>';
    h += D.aEcrire.length ? tbl(['Réf.', 'Date', 'Libellé', 'Montant', 'Compte', ''], D.aEcrire.map(function (m, i) {
      var cand = D.comptes.filter(function (c) { return c.actif !== false && c.devise === m.cur; });
      return '<tr><td>' + esc(m.ref) + '</td><td>' + esc(m.date || '—') + '</td><td>' + esc(m.label) + '<br><span class="mu">' + esc(m.reference) + '</span></td><td class="r"><b>' + (m.signe > 0 ? '+' : '−') + esc(nf(m.montant, m.cur)) + ' ' + m.cur + '</b></td><td><select id="tw_c' + i + '"><option value="">— non affecté —</option>' + cand.map(function (c) { return opt(c.id, c.nom, c.id === m.compte); }).join('') + '</select></td><td><button class="bt g" data-w="' + i + '">Écrire en caisse</button></td></tr>';
    })) : '<div class="mu">Rien à écrire : tout est déjà en caisse.</div>';
    h += '</div>';
    var sel = SELM, L = D.mvs.filter(function (m) { return !sel || m.compte === sel; }).sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); }).slice(0, 150);
    h += '<div class="cd"><div class="gr"><div><label>Journal des mouvements — compte</label><select id="tm_sel"><option value="">Tous</option>' + D.comptes.map(function (c) { return opt(c.id, c.nom + ' (' + c.devise + ')', sel === c.id); }).join('') + '</select></div></div>' +
      (L.length ? tbl(['Date', 'Compte', 'Libellé', 'Réf.', 'Montant'], L.map(function (m) { return '<tr><td>' + esc(m.date || '—') + '</td><td>' + esc(nomCompte(D, m.compte)) + '</td><td>' + esc(m.label) + '</td><td>' + esc(m.ref || '') + '</td><td class="r"><b style="color:' + (m.signe > 0 ? '#166534' : '#b42318') + '">' + (m.signe > 0 ? '+' : '−') + esc(nf(m.montant, m.cur)) + ' ' + m.cur + '</b></td></tr>'; })) : '<div class="mu" style="margin-top:6px">Aucun mouvement.</div>') + '</div>';
    return h;
  }
  function vTransferts(D) {
    var f = FORM && FORM.kind === 'trf' ? FORM : { de: '', vers: '', montant: '', montant_vers: '', frais: '', date: jour(), ref: '', motif: '' }, act = D.comptes.filter(function (c) { return c.actif !== false; });
    var h = '<div class="cd"><h4 style="margin:0 0 6px">Nouveau transfert</h4>' + (act.length < 2 ? '<div class="mu">Créez au moins deux comptes pour faire un transfert.</div>' :
      '<div class="gr"><div><label>De</label><select id="tt_de"><option value=""></option>' + act.map(function (c) { return opt(c.id, c.nom + ' (' + c.devise + ') — ' + nf(soldeCompte(c, D.mvs), c.devise), f.de === c.id); }).join('') + '</select></div><div><label>Vers</label><select id="tt_vers"><option value=""></option>' + act.map(function (c) { return opt(c.id, c.nom + ' (' + c.devise + ')', f.vers === c.id); }).join('') + '</select></div>' +
      '<div><label>Montant envoyé</label><input id="tt_m" inputmode="decimal" value="' + esc(f.montant) + '"></div><div><label>Montant reçu (si devises différentes)</label><input id="tt_mv" inputmode="decimal" value="' + esc(f.montant_vers) + '"></div><div><label>Frais (compte source)</label><input id="tt_f" inputmode="decimal" value="' + esc(f.frais) + '"></div><div><label>Date</label><input id="tt_d" type="date" value="' + esc(f.date) + '"></div><div><label>Référence</label><input id="tt_r" value="' + esc(f.ref) + '"></div><div><label>Motif</label><input id="tt_mo" value="' + esc(f.motif) + '"></div></div><p><button class="bt" id="tt_ok">Enregistrer le transfert</button></p><div class="mu">Entre deux devises, le montant reçu réel est saisi : le taux réellement obtenu est conservé et ne change plus.</div>') + '</div>';
    h += '<div class="cd"><b>Transferts</b>' + (D.tr.length ? tbl(['Date', 'De → Vers', 'Envoyé', 'Reçu', 'Taux réel', 'Frais', 'Réf.', ''], D.tr.slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }).map(function (t) { return '<tr' + (t.annule ? ' style="opacity:.5"' : '') + '><td>' + esc(t.date) + '</td><td>' + esc(t.de_nom) + ' → ' + esc(t.vers_nom) + '</td><td class="r">' + esc(nf(t.montant, t.devise_de)) + ' ' + t.devise_de + '</td><td class="r">' + esc(nf(t.montant_vers, t.devise_vers)) + ' ' + t.devise_vers + '</td><td class="r">' + (t.devise_de === t.devise_vers ? '—' : esc(String(t.taux_reel))) + '</td><td class="r">' + (+t.frais ? esc(nf(t.frais, t.devise_de)) : '—') + '</td><td>' + esc(t.ref || '') + '</td><td>' + (t.annule ? badge('Annulé', 'r') : '<button class="bt s" data-ta="' + esc(t.id) + '">Annuler</button>') + '</td></tr>'; })) : '<div class="mu">Aucun transfert.</div>') + '</div>';
    return h;
  }
  function vRapp(D) {
    var cs = D.comptes.filter(function (c) { return c.actif !== false; });
    if (!cs.length) return '<div class="cd mu">Créez d’abord un compte bancaire ou Mobile Money (onglet Comptes).</div>';
    var c = cs.filter(function (x) { return x.id === SELC; })[0] || cs.filter(function (x) { return x.type !== 'caisse'; })[0] || cs[0]; SELC = c.id;
    var B = bilanRapprochement(c, D.mvs, D.lignes, D.matches), act = actifs(D.matches);
    var h = '<div class="cd"><div class="gr"><div><label>Compte</label><select id="tr_sel">' + cs.map(function (x) { return opt(x.id, x.nom + ' (' + x.devise + ')', x.id === c.id); }).join('') + '</select></div><div><label>Solde indiqué par le relevé</label><input id="tr_sr" inputmode="decimal" value="' + esc(c.solde_releve == null ? '' : c.solde_releve) + '"></div><div style="align-self:end"><button class="bt s" id="tr_srok">Enregistrer le solde</button></div></div></div>';
    h += '<div class="kp"><div><span class="mu">Solde du livre</span><b>' + esc(nf(B.livre, c.devise)) + '</b></div><div><span class="mu">Lignes du relevé non rapprochées</span><b>' + B.releveNon.length + '</b></div><div><span class="mu">Écritures non rapprochées</span><b>' + B.livreNon.length + '</b></div><div><span class="mu">Écart résiduel</span><b style="color:' + (B.residuel == null ? '#5b6b82' : Math.abs(B.residuel) < 0.005 ? '#166534' : '#b42318') + '">' + (B.residuel == null ? 'solde du relevé requis' : esc(nf(B.residuel, c.devise))) + '</b></div></div>';
    h += '<div class="cd"><b>Importer un relevé (CSV)</b><div class="mu" style="margin:4px 0">Colonnes reconnues : Date, Libellé, Montant (ou Débit / Crédit), Référence. Séparateur ; , ou tabulation. Une ligne déjà importée est ignorée.</div><input type="file" id="tr_file" accept=".csv,.txt,text/csv,text/plain"><label>… ou collez le contenu</label><textarea id="tr_txt" rows="4"></textarea><p><button class="bt" id="tr_imp">Importer</button></p></div>';
    h += '<div class="cd"><b>Lignes du relevé à rapprocher</b>';
    if (!B.releveNon.length) h += '<div class="mu" style="margin-top:6px">Aucune ligne en attente.</div>';
    B.releveNon.slice().sort(function (a, b) { return a.date.localeCompare(b.date); }).forEach(function (l) {
      var sug = suggerer(l, D.mvs, D.matches), pris = {}; act.forEach(function (m) { if (m.mv_key) pris[m.mv_key] = 1; });
      var cand = D.mvs.filter(function (m) { return m.compte === l.compte && m.cur === l.devise && !pris[m.key] && (m.signe * m.montant > 0) === (l.montant > 0); });
      h += '<div class="lg"><div><b>' + esc(l.date) + '</b> · ' + esc(l.libelle || '—') + ' · <b style="color:' + (l.montant > 0 ? '#166534' : '#b42318') + '">' + (l.montant > 0 ? '+' : '−') + esc(nf(Math.abs(l.montant), l.devise)) + ' ' + l.devise + '</b>' + (l.ref ? ' <span class="mu">réf. ' + esc(l.ref) + '</span>' : '') + (sug.length ? ' ' + badge('Suggestion trouvée', 'v') : '') + '</div>' +
        '<div class="gr"><div><label>Écriture correspondante</label><select id="rs_' + esc(l.id) + '"><option value="">— aucune (justifier) —</option>' + cand.map(function (m, i) { return opt(m.key, (m.date || '—') + ' · ' + m.label + ' · ' + nf(m.montant, m.cur), sug[0] && sug[0].key === m.key); }).join('') + '</select></div><div><label>Motif (si écart ou sans écriture)</label><input id="rm_' + esc(l.id) + '"></div><div style="align-self:end"><button class="bt" data-rp="' + esc(l.id) + '">Valider</button></div></div></div>';
    });
    h += '</div>';
    h += '<div class="cd"><b>Écritures du livre non présentes au relevé</b>' + (B.livreNon.length ? tbl(['Date', 'Libellé', 'Montant'], B.livreNon.map(function (m) { return '<tr><td>' + esc(m.date || '—') + '</td><td>' + esc(m.label) + '</td><td class="r">' + (m.signe > 0 ? '+' : '−') + esc(nf(m.montant, m.cur)) + '</td></tr>'; })) : '<div class="mu">Aucune.</div>') + '</div>';
    var faits = act.filter(function (m) { return D.lignes.some(function (l) { return l.id === m.ligne_id && l.compte === c.id; }); });
    h += '<div class="cd"><b>Rapprochements faits</b>' + (faits.length ? tbl(['Date', 'Type', 'Écart', 'Motif', 'Par', ''], faits.map(function (m) { return '<tr><td>' + esc(String(m.le).slice(0, 10)) + '</td><td>' + (m.type === 'justifie' ? badge('Justifié sans écriture') : badge('Rapproché', 'v')) + '</td><td class="r">' + (Math.abs(m.ecart) > 0.004 ? esc(nf(m.ecart, c.devise)) : '—') + '</td><td>' + esc(m.motif || '') + '</td><td>' + esc(m.par) + '</td><td><button class="bt s" data-ru="' + esc(m.id) + '">Défaire</button></td></tr>'; })) : '<div class="mu">Aucun.</div>') + '</div>';
    return h;
  }
  function vCloture(D) {
    var cs = D.comptes.filter(function (c) { return c.type === 'caisse' && c.actif !== false; });
    if (!cs.length) return '<div class="cd mu">Aucune caisse. Créez une caisse dans l’onglet Comptes.</div>';
    var c = cs.filter(function (x) { return x.id === CLC; })[0] || cs[0]; CLC = c.id; var dt = val('tc_cd') || jour(), th = theoriqueCaisse(c, D.mvs, iso(dt));
    var h = '<div class="cd"><b>Clôture de caisse</b><div class="gr"><div><label>Caisse</label><select id="tc_cs">' + cs.map(function (x) { return opt(x.id, x.nom + ' (' + x.devise + ')', x.id === c.id); }).join('') + '</select></div><div><label>Date</label><input type="date" id="tc_cd" value="' + esc(dt) + '"></div><div><label>Solde théorique</label><input id="tc_th" value="' + esc(nf(th, c.devise)) + '" readonly></div><div><label>Montant réellement compté</label><input id="tc_cp" inputmode="decimal"></div><div><label>Motif de l’écart (si écart)</label><input id="tc_mo"></div></div><p><button class="bt" id="tc_cl">Clôturer la caisse</button></p></div>';
    h += '<div class="cd"><b>Clôtures</b>' + (D.clotures.length ? tbl(['Date', 'Caisse', 'Théorique', 'Compté', 'Écart', 'Motif', 'Par'], D.clotures.slice().sort(function (a, b) { return b.date.localeCompare(a.date); }).map(function (x) { return '<tr><td>' + esc(x.date) + '</td><td>' + esc(x.compte_nom) + '</td><td class="r">' + esc(nf(x.theorique, x.devise)) + '</td><td class="r">' + esc(nf(x.compte_physique, x.devise)) + '</td><td class="r">' + (Math.abs(x.ecart) < 0.005 ? badge('Aucun', 'v') : badge(nf(x.ecart, x.devise) + ' ' + x.devise, 'r')) + '</td><td>' + esc(x.motif || '') + '</td><td>' + esc(x.par) + '</td></tr>'; })) : '<div class="mu">Aucune clôture.</div>') + '</div>';
    return h;
  }
  function paint() {
    var c = $('tr_c'); if (!c) return; var D = lire(), T = [['comptes', '🏦 Comptes'], ['mouvements', '📒 Mouvements'], ['transferts', '🔁 Transferts'], ['rapp', '✔ Rapprochement'], ['cloture', '🔒 Clôture caisse']];
    c.innerHTML = '<div class="hd"><h3>🏦 Trésorerie & rapprochement</h3><button class="x" id="tr_x">Fermer ✕</button></div><div class="tabs">' + T.map(function (t) { return '<button data-t="' + t[0] + '" class="' + (TAB === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      (ERR ? '<div class="er">' + ERR + '</div>' : '') + (MSG ? '<div class="ok">' + esc(MSG) + '</div>' : '') + ({ comptes: vComptes, mouvements: vMouvements, transferts: vTransferts, rapp: vRapp, cloture: vCloture })[TAB](D);
    ERR = ''; MSG = ''; brancher(D);
  }
  function on(id, fn) { var e = $(id); if (e) e.onclick = fn; }
  function each(sel, attr, fn) { var c = $('tr_c'); c.querySelectorAll(sel).forEach(function (b) { b.onclick = function () { fn(b.getAttribute(attr), b); }; }); }
  function interdit() { if (peutEcrire()) return false; ERR = 'Droits insuffisants pour cette action.'; paint(); return true; }
  function brancher(D) {
    on('tr_x', close); each('[data-t]', 'data-t', function (t) { TAB = t; FORM = null; paint(); });
    on('tc_new', function () { FORM = { kind: 'compte', nom: '', type: 'caisse', devise: 'USD', ouverture: '', ouverture_date: '' }; paint(); });
    each('[data-ce]', 'data-ce', function (id) { var c = D.comptes.filter(function (x) { return x.id === id; })[0]; FORM = Object.assign({ kind: 'compte' }, c); paint(); });
    on('tc_no', function () { FORM = null; paint(); });
    on('tc_ok', function () {
      if (interdit()) return; var all = rdA(K.C), c = { id: FORM.id || uid('CPT'), nom: val('tc_nom').trim(), type: val('tc_type'), devise: nc(val('tc_dev')), ouverture: r2(nombre(dec('tc_ouv')) || 0), ouverture_date: val('tc_od'), actif: val('tc_act') !== '0' };
      var er = validerCompte(c, all); if (er.length) { ERR = esc(er.join(' ')); return paint(); }
      var i = all.map(function (x) { return x.id; }).indexOf(c.id);
      if (i >= 0) { c.solde_releve = all[i].solde_releve; c.cree_le = all[i].cree_le; all[i] = c; } else { c.cree_le = new Date().toISOString(); all.push(c); }
      if (!wr(K.C, all)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); } audit(i >= 0 ? 'compte_modifie' : 'compte_cree', { compte: c.nom, devise: c.devise, type: c.type, ouverture: c.ouverture }); FORM = null; MSG = 'Compte enregistré.'; paint();
    });
    /* mouvements */
    var s = $('tm_sel'); if (s) s.onchange = function () { SELM = s.value; paint(); };
    each('[data-w]', 'data-w', function (i) {
      if (interdit()) return; var m = D.aEcrire[+i]; if (!m) return; if (cashLire().some(function (x) { return x && x.cr_ref === m.key; })) { ERR = 'Cette opération est déjà écrite en caisse.'; return paint(); }
      if (!m.date) { ERR = 'Date manquante sur l’opération du Centre.'; return paint(); }
      var cid = val('tw_c' + i), ligne = ligneCaisseDepuisCentre(m, cid); if (!cashEcrire(ligne)) { ERR = 'Écriture en caisse impossible (stockage).'; return paint(); }
      audit('ecrire_en_caisse', { cr_ref: m.key, montant: m.montant, devise: m.cur, sens: m.signe > 0 ? 'in' : 'out', compte_id: cid }); MSG = 'Écrit en caisse : ' + m.label + '.'; paint();
    });
    /* transferts */
    on('tt_ok', function () {
      if (interdit()) return; var t = { kind: 'trf', de: val('tt_de'), vers: val('tt_vers'), montant: dec('tt_m'), montant_vers: dec('tt_mv'), frais: dec('tt_f'), date: val('tt_d'), ref: val('tt_r'), motif: val('tt_mo') }; FORM = t;
      var er = validerTransfert({ de: t.de, vers: t.vers, montant: +t.montant, montant_vers: +t.montant_vers, frais: +t.frais || 0, date: t.date }, D.comptes, D.mvs); if (er.length) { ERR = esc(er.join(' ')); return paint(); }
      var n = construireTransfert({ de: t.de, vers: t.vers, montant: +t.montant, montant_vers: +t.montant_vers, frais: +t.frais || 0, date: t.date, ref: t.ref, motif: t.motif }, D.comptes, qui());
      var all = rdA(K.T); all.push(n); if (!wr(K.T, all)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); } audit('transfert', { id: n.id, de: n.de_nom, vers: n.vers_nom, montant: n.montant, devise: n.devise_de, recu: n.montant_vers, devise_vers: n.devise_vers, frais: n.frais }); FORM = null; MSG = 'Transfert enregistré.'; paint();
    });
    each('[data-ta]', 'data-ta', function (id) {
      if (interdit()) return; var mo = (w.prompt('Motif de l’annulation (obligatoire) :') || '').trim(); if (mo.length < 3) { ERR = 'Un motif est obligatoire pour annuler un transfert.'; return paint(); }
      var all = rdA(K.T), t = all.filter(function (x) { return x.id === id; })[0]; if (!t || t.annule) return; t.annule = true; t.annule_motif = mo; t.annule_par = qui(); t.annule_le = new Date().toISOString(); wr(K.T, all); audit('transfert_annule', { id: id, motif: mo }); MSG = 'Transfert annulé.'; paint();
    });
    /* rapprochement */
    var sc = $('tr_sel'); if (sc) sc.onchange = function () { SELC = sc.value; paint(); };
    on('tr_srok', function () { if (interdit()) return; var all = rdA(K.C), c = all.filter(function (x) { return x.id === SELC; })[0]; if (!c) return; var v = dec('tr_sr'); c.solde_releve = v === '' ? null : r2(nombre(v)); if (c.solde_releve !== null && isNaN(c.solde_releve)) { ERR = 'Solde du relevé illisible.'; return paint(); } wr(K.C, all); audit('solde_releve', { compte: c.nom, solde: c.solde_releve }); MSG = 'Solde du relevé enregistré.'; paint(); });
    on('tr_imp', function () {
      if (interdit()) return; var c = D.comptes.filter(function (x) { return x.id === SELC; })[0]; if (!c) return; var f = $('tr_file') && $('tr_file').files && $('tr_file').files[0];
      function go(txt) { var p = parseReleve(txt); if (!p.lignes.length) { ERR = esc((p.erreurs[0] || 'Aucune ligne lisible.')); return paint(); } var r = importer(p.lignes, c, rdA(K.R)); var all = rdA(K.R).concat(r.nouveaux); if (!wr(K.R, all)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); } audit('import_releve', { compte: c.nom, nouvelles: r.nouveaux.length, doublons: r.doublons, ignorees: p.erreurs.length }); MSG = r.nouveaux.length + ' ligne(s) importée(s), ' + r.doublons + ' doublon(s) ignoré(s)' + (p.erreurs.length ? ', ' + p.erreurs.length + ' illisible(s)' : '') + '.'; paint(); }
      if (f) { var fr = new FileReader(); fr.onload = function () { go(String(fr.result || '')); }; fr.onerror = function () { ERR = 'Lecture du fichier impossible.'; paint(); }; fr.readAsText(f); } else go(val('tr_txt'));
    });
    each('[data-rp]', 'data-rp', function (id) {
      if (interdit()) return; var l = D.lignes.filter(function (x) { return x.id === id; })[0], key = val('rs_' + id), mv = key ? D.mvs.filter(function (m) { return m.key === key; })[0] : null;
      var r = creerRapprochement(l, mv || null, D.matches, { motif: val('rm_' + id), qui: qui() }); if (!r.ok) { ERR = esc(r.err); return paint(); }
      var all = rdA(K.M); all.push(r.match); wr(K.M, all); audit('rapprochement', { ligne: id, ecriture: r.match.mv_key, type: r.match.type, ecart: r.match.ecart, motif: r.match.motif }); MSG = r.match.type === 'justifie' ? 'Ligne justifiée sans écriture (écart conservé).' : 'Rapprochement enregistré.'; paint();
    });
    each('[data-ru]', 'data-ru', function (id) {
      if (interdit()) return; var mo = (w.prompt('Motif pour défaire ce rapprochement (obligatoire) :') || '').trim(); if (mo.length < 3) { ERR = 'Un motif est obligatoire.'; return paint(); }
      var all = rdA(K.M), m = all.filter(function (x) { return x.id === id; })[0]; if (!m) return; m.annule = true; m.annule_motif = mo; m.annule_par = qui(); m.annule_le = new Date().toISOString(); wr(K.M, all); audit('rapprochement_defait', { id: id, motif: mo }); MSG = 'Rapprochement défait.'; paint();
    });
    /* clôture */
    var cs = $('tc_cs'); if (cs) cs.onchange = function () { CLC = cs.value; paint(); }; var cd = $('tc_cd'); if (cd) cd.onchange = function () { paint(); };
    on('tc_cl', function () {
      if (interdit()) return; var c = D.comptes.filter(function (x) { return x.id === CLC; })[0]; var r = cloture(c, D.mvs, val('tc_cd'), dec('tc_cp'), val('tc_mo'), qui(), D.clotures); if (!r.ok) { ERR = esc(r.err); return paint(); }
      var all = rdA(K.L); all.push(r.cloture); wr(K.L, all); audit('cloture_caisse', { caisse: c.nom, date: r.cloture.date, theorique: r.cloture.theorique, compte: r.cloture.compte_physique, ecart: r.cloture.ecart, motif: r.cloture.motif }); MSG = 'Caisse clôturée' + (Math.abs(r.cloture.ecart) > 0.004 ? ' avec écart justifié.' : ' sans écart.'); paint();
    });
  }
  function close() { var o = $('tr_ov'); if (o && o.parentNode) o.parentNode.removeChild(o); }
  function open(tab) {
    close(); css(); TAB = tab || 'comptes'; FORM = null; ERR = ''; MSG = '';
    var o = d.createElement('div'); o.id = 'tr_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9990;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.onclick = function (e) { if (e.target === o) close(); }; o.innerHTML = '<div id="tr_c"></div>'; d.body.appendChild(o); paint();
  }
  function mount() {
    if ($('btr')) return; var a = $('bfd') || $('bcr') || $('bcompta'); if (!a || !a.parentNode) return;
    var b = d.createElement('button'); b.id = 'btr'; b.textContent = '🏦 Trésorerie'; b.onclick = function () { open('comptes'); }; a.parentNode.insertBefore(b, a.nextSibling);
  }
  function enregistrerModule() {
    try { if (w.EXB_MODULES && !w.EXB_MODULES.some(function (m) { return m.id === 'tresorerieRapprochement'; })) w.EXB_MODULES.push({ id: 'tresorerieRapprochement', name: 'Trésorerie & rapprochement', area: 'Finance', icon: '🏦', status: 'nouveau', deps: ['comptabilite', 'rapprochement_bancaire'] }); } catch (e) {}
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'tresorerie', name: 'Trésorerie & rapprochement', version: '231.0.0', area: 'Finance', provides: ['compta.tresorerie', 'compta.rapprochement'] }); } catch (e) {}
  }
  function start() { mount(); enregistrerModule(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000); }
  w.EXBTR = { open: open, soldes: soldesGlobaux, aRapprocher: nbARapprocher, pure: { typeDepuisMode: typeDepuisMode, compteDe: compteDe, mvCash: mvCash, mvTransferts: mvTransferts, mvCentre: mvCentre, centreAEcrire: centreAEcrire, ligneCaisseDepuisCentre: ligneCaisseDepuisCentre, soldeCompte: soldeCompte, soldesParDevise: soldesParDevise, validerCompte: validerCompte, validerTransfert: validerTransfert, construireTransfert: construireTransfert, parseReleve: parseReleve, importer: importer, suggerer: suggerer, creerRapprochement: creerRapprochement, bilanRapprochement: bilanRapprochement, theoriqueCaisse: theoriqueCaisse, cloture: cloture } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
