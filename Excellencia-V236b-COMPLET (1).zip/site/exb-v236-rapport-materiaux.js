/* Excellencia Building V236 — 📦 RAPPORT DE MATÉRIAUX (Espace Magasin · aussi visible dans l'Espace Chantier).
 * Le magasinier fait lui-même le rapport, le synchronise avec les autres espaces et l'exporte en PDF :
 *   • Réception de matériaux  : commandé / reçu par ligne, écart, bon de livraison, fournisseur ;
 *   • Consommation de matériaux : prévu / consommé par ligne, chantier, période ;
 *   • État du stock (inventaire) : stock théorique / compté, écart.
 * « Reprendre le stock » remplit les lignes depuis les articles (exb_stock) et les mouvements (exb_stock_moves) : rien n'est inventé.
 * PDF A4 multi-pages : même en-tête, mêmes couleurs, même pied et même QR de vérification que le bon de paiement V235 / le bon de commande V228.
 * Registre « exb_rapports_materiaux » (collection synchronisée « rapports_materiaux », pont de stockage commun : sauvegardé avec le reste).
 * Serveur : exécuter supabase/migration-v236-rapports-materiaux.sql (droits par fonction), sinon les rapports restent sur l'appareil.
 * API : EXBRapportMateriaux.build(lib,r,env) -> Promise<Uint8Array> ; .make(r) -> Promise<Blob> ; .mount(sec) ; .nextNo(all,date,type) ;
 *       .calc(r) ; .fromStock(type,stock,moves,du,au). */
(function (w, d) {
  'use strict';
  var KEY = 'exb_rapports_materiaux';
  var NAVY = [0.090, 0.208, 0.396], BLUE = [0.125, 0.286, 0.541], BAND = [0.918, 0.941, 0.984], GOLD = [0.769, 0.604, 0.220], GREY = [0.40, 0.43, 0.49], INK = [0.10, 0.12, 0.18], LINE = [0.78, 0.82, 0.88], SOFT = [0.95, 0.97, 0.99], RED = [0.70, 0.12, 0.12], GREEN = [0.05, 0.45, 0.20];
  var TEL = '+243 810 644 554', MAIL = 'excellenciabuilding@gmail.com';
  var TYPES = {
    reception: { lib: 'Réception de matériaux', titre: 'RAPPORT DE RÉCEPTION DE MATÉRIAUX', pre: 'RM', ico: '🚚', c1: 'Commandée', c2: 'Reçue', ecart: 'Écart (reçue - commandée)', bad: -1 },
    consommation: { lib: 'Consommation de matériaux', titre: 'RAPPORT DE CONSOMMATION DE MATÉRIAUX', pre: 'RC', ico: '🧱', c1: 'Prévue', c2: 'Consommée', ecart: 'Écart (consommée - prévue)', bad: 1 },
    stock: { lib: 'État du stock', titre: 'RAPPORT D’ÉTAT DU STOCK', pre: 'RS', ico: '📦', c1: 'Théorique', c2: 'Comptée', ecart: 'Écart (comptée - théorique)', bad: -1 }
  };
  var $ = function (i) { return d && d.getElementById(i); };
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { var n = parseFloat(String(v == null ? '' : v).replace(/[\s\u00a0\u202f]/g, '').replace(',', '.')); return isFinite(n) ? n : 0; }
  function has(v) { return v !== '' && v != null && isFinite(parseFloat(String(v).replace(',', '.'))); }
  function r3(n) { return Math.round(n * 1000) / 1000; }
  function today() { var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
  function nfp(v) { v = Number(v) || 0; var s = Math.abs(v).toFixed(3).replace(/\.?0+$/, '').split('.'); s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (v < 0 ? '-' : '') + s.join(','); }
  function rd(k) { try { if (w.EXBS && w.EXBS.get) return w.EXBS.get(k) || []; } catch (e) { } return []; }
  function wr(k, v) { try { if (w.EXBS && w.EXBS.set) return w.EXBS.set(k, v) !== false; } catch (e) { } return false; }
  function audit(a, t) { try { if (typeof w.audit === 'function') w.audit(a, t); } catch (e) { } }
  function typ(t) { return TYPES[t] || TYPES.reception; }

  /* ---------- calculs (testés hors navigateur) ---------- */
  function calc(r) {
    var T = typ(r && r.type), n = 0, ecarts = 0, ok = 0, vides = 0, lignes = [];
    ((r && r.lignes) || []).forEach(function (l) {
      if (!l || !String(l.des || '').trim()) return; n++;
      var a = has(l.q1), b = has(l.q2), e = (a && b) ? r3(num(l.q2) - num(l.q1)) : null;
      if (e === null) vides++; else if (Math.abs(e) < 0.0005) ok++; else ecarts++;
      lignes.push({ des: l.des, unite: l.unite || '', q1: a ? num(l.q1) : null, q2: b ? num(l.q2) : null, ecart: e, obs: l.obs || '', mauvais: e !== null && ((T.bad < 0 && e < -0.0005) || (T.bad > 0 && e > 0.0005)) });
    });
    return { n: n, ok: ok, ecarts: ecarts, incomplets: vides, lignes: lignes, mauvais: lignes.filter(function (x) { return x.mauvais; }).length };
  }
  function nextNo(all, date, type) {
    var T = typ(type), y = String(date || today()).slice(0, 4), mx = 0, re = new RegExp('^EXB-' + T.pre + '-(\\d{4})-(\\d+)$');
    (all || []).forEach(function (r) { var m = re.exec(r && r.no || ''); if (m && m[1] === y) mx = Math.max(mx, parseInt(m[2], 10)); });
    return 'EXB-' + T.pre + '-' + y + '-' + ('000' + (mx + 1)).slice(-4);
  }
  /* lignes proposées depuis le stock et les mouvements (période du/au facultative, au format AAAA-MM-JJ) */
  function fromStock(type, stock, moves, du, au) {
    var inP = function (m) { var dt = String(m && m.date || '').slice(0, 10); return (!du || dt >= du) && (!au || dt <= au); };
    var by = {}; (moves || []).forEach(function (m) { if (!m || !inP(m)) return; var k = m.item, kind = m.type === 'in' ? 'in' : 'out'; by[k] = by[k] || { in: 0, out: 0 }; by[k][kind] += num(m.qty); });
    var out = [];
    (stock || []).forEach(function (s) {
      if (!s || !s.name) return; var mv = by[s.id] || { in: 0, out: 0 };
      if (type === 'stock') out.push({ des: s.name, unite: s.unit || '', q1: String(r3(num(s.qty))), q2: '', obs: '' });
      else if (type === 'consommation') { if (mv.out > 0) out.push({ des: s.name, unite: s.unit || '', q1: '', q2: String(r3(mv.out)), obs: '' }); }
      else { if (mv.in > 0) out.push({ des: s.name, unite: s.unit || '', q1: '', q2: String(r3(mv.in)), obs: s.supplier ? 'Fournisseur : ' + s.supplier : '' }); }
    });
    return out;
  }

  /* ---------- utilitaires PDF (mêmes que V235) ---------- */
  var OK = { 8217: 1, 8216: 1, 8220: 1, 8221: 1, 8211: 1, 8212: 1, 8364: 1, 339: 1, 338: 1, 8230: 1, 8226: 1 };
  function san(t) { t = String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ').replace(/\u202f|\u00a0/g, ' '); var o = ''; for (var i = 0; i < t.length; i++) { var c = t.charCodeAt(i); o += (c < 256 || OK[c]) ? t.charAt(i) : '?'; } return o; }
  function fd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function dataUrlBytes(u) { var b = atob(String(u).split(',')[1] || ''), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function loadLib() {
    if (w.PDFLib) return Promise.resolve(w.PDFLib);
    return new Promise(function (ok, ko) { var s = d.createElement('script'); s.src = 'pdflib/pdf-lib.min.js'; s.onload = function () { w.PDFLib ? ok(w.PDFLib) : ko(new Error('pdf-lib')); }; s.onerror = function () { ko(new Error('pdf-lib introuvable')); }; d.head.appendChild(s); });
  }
  async function imgBytes(src) {
    try {
      if (!src) return null;
      if (/^data:image\/(png|jpe?g)/i.test(src)) return { b: dataUrlBytes(src), png: /^data:image\/png/i.test(src) };
      var r = await fetch(src); if (!r.ok) return null; var ab = new Uint8Array(await r.arrayBuffer()); return { b: ab, png: ab[0] === 0x89 };
    } catch (e) { return null; }
  }

  /* ---------- construction du PDF (A4, plusieurs pages si besoin) ---------- */
  async function build(lib, r, env) {
    env = env || {};
    var T = typ(r.type), C = calc(r), pdf = await lib.PDFDocument.create(), W = 595, H = 842, M = 40, pages = [], pg = null;
    var F1 = await pdf.embedFont(lib.StandardFonts.Helvetica), F2 = await pdf.embedFont(lib.StandardFonts.HelveticaBold), F3 = await pdf.embedFont(lib.StandardFonts.HelveticaOblique);
    var rgb = function (a) { return lib.rgb(a[0], a[1], a[2]); };
    function Tx(t, x, y, sz, o) { o = o || {}; var f = o.i ? F3 : (o.b ? F2 : F1); t = san(t); if (o.al) { var wd = f.widthOfTextAtSize(t, sz); x = o.al === 'r' ? x - wd : x - wd / 2; } pg.drawText(t, { x: x, y: y, size: sz, font: f, color: rgb(o.c || INK) }); }
    function TW(t, sz, bd) { return (bd ? F2 : F1).widthOfTextAtSize(san(t), sz); }
    function R(x, y, w2, h, c) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, color: rgb(c) }); }
    function RS(x, y, w2, h, c, lw) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, borderColor: rgb(c), borderWidth: lw || .8 }); }
    function Ln(x1, y1, x2, y2, c, lw) { pg.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: lw || .6, color: rgb(c || LINE) }); }
    function fit(t, maxW, sz, bd) { t = san(t); while (sz > 6 && TW(t, sz, bd) > maxW) sz -= .25; if (TW(t, sz, bd) > maxW) { while (t.length > 3 && TW(t + '…', sz, bd) > maxW) t = t.slice(0, -1); t += '…'; } return { t: t, sz: sz }; }
    function wrap(txt, maxW, sz, bd) { var out = [], ln = ''; String(txt == null ? '' : txt).replace(/\r/g, '').split('\n').forEach(function (par) { ln = ''; par.split(' ').forEach(function (x) { var t2 = ln ? ln + ' ' + x : x; if (TW(t2, sz, bd) > maxW && ln) { out.push(ln); ln = x; } else ln = t2; }); out.push(ln); }); return out; }
    function field(label, val, x, y, wTot, o) {
      o = o || {}; Tx(label, x, y, 8.4, { b: true, c: NAVY }); var lx = x + TW(label, 8.4, true) + 6;
      Ln(lx, y - 2.5, x + wTot, y - 2.5, LINE, .6);
      if (val !== '' && val != null) { var f = fit(val, x + wTot - lx - 4, o.sz || 9.6, true); Tx(f.t, lx + 2, y, f.sz, { b: true }); }
    }
    function section(n, title, y) { R(M, y - 3, W - 2 * M, 16, NAVY); R(M, y - 3, 4, 16, GOLD); Tx(n + '. ' + title, M + 12, y + 1.2, 9.4, { b: true, c: [1, 1, 1] }); }
    function footer() {
      R(0, 0, W, 42, NAVY); R(0, 42, W, 3, GOLD);
      Tx('EXCELLENCIA BUILDING  –  From Vision to Reality', W / 2, 26, 8.6, { b: true, c: [1, 1, 1], al: 'c' });
      Tx('WhatsApp : ' + TEL + '  |  E-mail : ' + MAIL, W / 2, 12, 8.2, { c: [0.95, 0.82, 0.40], al: 'c' });
    }

    /* page 1 : en-tête complet (identique au bon de paiement) */
    pg = pdf.addPage([W, H]); pages.push(pg);
    var I = env.id || {}, nom = r.entreprise || I.name || 'Excellencia Building', logo = null;
    try { if (env.logo) logo = env.logo.png ? await pdf.embedPng(env.logo.b) : await pdf.embedJpg(env.logo.b); } catch (e) { logo = null; }
    var tx = M;
    if (logo) { var lh = 62, lw2 = lh * logo.width / logo.height; if (lw2 > 80) { lw2 = 80; lh = lw2 * logo.height / logo.width; } pg.drawImage(logo, { x: M, y: H - 26 - lh, width: lw2, height: lh }); tx = M + lw2 + 14; }
    var place = [I.address || 'Kinshasa, RDC', I.country].filter(function (v, i, a) { return v && !(i === 1 && String(a[0]).toLowerCase().indexOf(String(v).toLowerCase()) >= 0); }).join(', ');
    var items = [place, 'Tél : ' + (I.phone || TEL), 'E-mail : ' + (I.email || MAIL), I.website || ''].filter(Boolean), CW = 215, clines = [], cc = '';
    items.forEach(function (it) { var t5 = cc ? cc + '  ·  ' + it : it; if (cc && TW(t5, 7.6) > CW) { clines.push(cc); cc = it; } else cc = t5; }); if (cc) clines.push(cc);
    clines.slice(0, 4).forEach(function (l6, i) { var f6 = fit(l6, CW, 7.6); Tx(f6.t, W - M, H - 34 - i * 10.5, f6.sz, { al: 'r', c: GREY }); });
    var nmax = W - M - CW - 14 - tx, nf1 = fit(nom, nmax, 20, true);
    Tx(nf1.t, tx, H - 46, nf1.sz, { b: true, c: NAVY });
    var sl = fit('L’excellence au cœur de vos constructions', nmax, 9.5); Tx(sl.t, tx, H - 62, sl.sz, { i: true, c: [0.62, 0.47, 0.13] });
    var ar = fit('ARCHITECTURE  •  INGÉNIERIE  •  RÉALISATION', nmax, 7.8, true); Tx(ar.t, tx, H - 76, ar.sz, { b: true, c: GREY });
    Ln(M, H - 98, W - M, H - 98, GOLD, 2.2);
    R(M, H - 142, W - 2 * M, 38, BAND); R(M, H - 142, 5, 38, BLUE);
    var tf = fit(T.titre, W - 2 * M - 190, 14.5, true); Tx(tf.t, M + 18, H - 123, tf.sz, { b: true, c: BLUE });
    Tx('Espace Magasin — stock et approvisionnement', M + 18, H - 136, 9.2, { c: INK });
    Tx(r.statut === 'validé' ? 'RAPPORT VALIDÉ' : 'BROUILLON', W - M - 8, H - 123, 9.4, { b: true, al: 'r', c: r.statut === 'validé' ? GREEN : GREY });
    Tx('À conserver', W - M - 8, H - 136, 8, { al: 'r', c: GREY });
    Ln(M, H - 147, W - M, H - 147, NAVY, 3);

    var y = H - 168;
    field('N° du rapport : ', r.no, M, y, 300, { sz: 10.5 }); field('Date :', fd(r.date), M + 318, y, W - 2 * M - 318); y -= 28;
    section(1, 'INFORMATIONS GÉNÉRALES', y); y -= 22;
    field('Projet / chantier :', r.projet || '', M, y, 300); field('Dépôt / magasin :', r.depot || '', M + 318, y, W - 2 * M - 318); y -= 21;
    if (r.type === 'reception') { field('Fournisseur :', r.fournisseur || '', M, y, 300); field('BL / commande n° :', r.bl || '', M + 318, y, W - 2 * M - 318); y -= 21; }
    else { field('Période du :', fd(r.du), M, y, 150); field('au :', fd(r.au), M + 170, y, 130); if (r.type === 'consommation') field('Fournisseur / source :', r.fournisseur || '', M + 318, y, W - 2 * M - 318); y -= 21; }
    field('Établi par :', r.redacteur || '', M, y, 300); field(r.type === 'reception' ? 'Réceptionné par :' : 'Vérifié par :', r.verifie || '', M + 318, y, W - 2 * M - 318); y -= 26;

    /* tableau multi-pages */
    section(2, 'DÉTAIL DES MATÉRIAUX', y); y -= 22;
    var CX = [M, M + 22, M + 212, M + 252, M + 310, M + 368, M + 420], CWD = [22, 190, 40, 58, 58, 52, W - M - (M + 420)];
    function head() {
      R(M, y - 5, W - 2 * M, 17, BAND); Ln(M, y - 5, W - M, y - 5, NAVY, 1);
      Tx('N°', CX[0] + 5, y, 7.8, { b: true, c: NAVY }); Tx('Désignation', CX[1] + 4, y, 7.8, { b: true, c: NAVY }); Tx('Unité', CX[2] + 4, y, 7.8, { b: true, c: NAVY });
      Tx(T.c1, CX[3] + CWD[3] - 4, y, 7.8, { b: true, c: NAVY, al: 'r' }); Tx(T.c2, CX[4] + CWD[4] - 4, y, 7.8, { b: true, c: NAVY, al: 'r' }); Tx('Écart', CX[5] + CWD[5] - 4, y, 7.8, { b: true, c: NAVY, al: 'r' }); Tx('Observation', CX[6] + 4, y, 7.8, { b: true, c: NAVY });
      y -= 20;
    }
    function nouvellePage() {
      pg = pdf.addPage([W, H]); pages.push(pg);
      R(0, H - 46, W, 46, NAVY); R(0, H - 49, W, 3, GOLD);
      Tx(nom, M, H - 30, 12, { b: true, c: [1, 1, 1] }); Tx(T.titre + '  —  ' + r.no, W - M, H - 30, 8.6, { b: true, c: [0.95, 0.82, 0.40], al: 'r' });
      y = H - 78; head();
    }
    head();
    if (!C.lignes.length) { Tx('Aucune ligne saisie.', M + 6, y, 9, { i: true, c: GREY }); y -= 18; }
    C.lignes.forEach(function (l, i) {
      var dl = wrap(l.des, CWD[1] - 8, 8.4, false), ol = wrap(l.obs, CWD[6] - 8, 7.4, false), nl = Math.max(1, Math.min(4, Math.max(dl.length, ol.length))), rh = nl * 9.6 + 7;
      if (y - rh < 70) { footer(); nouvellePage(); }
      if (i % 2 === 1) R(M, y - rh + 9, W - 2 * M, rh, SOFT);
      Tx(String(i + 1), CX[0] + 5, y, 8, { c: GREY });
      dl.slice(0, 4).forEach(function (s, k) { Tx(s, CX[1] + 4, y - k * 9.6, 8.4, { b: k === 0 }); });
      var uf = fit(l.unite, CWD[2] - 6, 8); Tx(uf.t, CX[2] + 4, y, uf.sz);
      if (l.q1 !== null) Tx(nfp(l.q1), CX[3] + CWD[3] - 4, y, 8.4, { al: 'r' });
      if (l.q2 !== null) Tx(nfp(l.q2), CX[4] + CWD[4] - 4, y, 8.4, { al: 'r' });
      if (l.ecart !== null) Tx((l.ecart > 0 ? '+' : '') + nfp(l.ecart), CX[5] + CWD[5] - 4, y, 8.4, { b: true, al: 'r', c: l.mauvais ? RED : (Math.abs(l.ecart) < 0.0005 ? GREEN : NAVY) });
      ol.slice(0, 4).forEach(function (s, k) { Tx(s, CX[6] + 4, y - k * 9.6, 7.4, { c: INK }); });
      Ln(M, y - rh + 9, W - M, y - rh + 9, LINE, .4);
      y -= rh;
    });

    /* synthèse + observations + signatures + QR : sur une page avec assez de place */
    var obsL = r.observations ? wrap(r.observations, W - 2 * M - 12, 8.6, false) : [], need = 40 + (obsL.length ? 26 + obsL.length * 11 : 0) + 96 + 86;
    if (y - need < 50) { footer(); nouvellePage(); }
    y -= 10; section(3, 'SYNTHÈSE', y); y -= 20;
    Tx('Lignes : ' + C.n + '   •   Sans écart : ' + C.ok + '   •   Avec écart : ' + C.ecarts + (C.incomplets ? '   •   Incomplètes : ' + C.incomplets : ''), M, y, 9, { b: true });
    if (C.mauvais) Tx(C.mauvais + ' ligne(s) à traiter (' + T.ecart.toLowerCase() + ' défavorable)', W - M, y, 8.6, { b: true, c: RED, al: 'r' });
    else if (C.n && !C.incomplets) Tx('Aucun écart défavorable', W - M, y, 8.6, { b: true, c: GREEN, al: 'r' });
    y -= 12; Tx(T.ecart + '.', M, y, 7.6, { i: true, c: GREY }); y -= 14;
    if (obsL.length) { section(4, 'OBSERVATIONS', y); y -= 18; obsL.forEach(function (s) { Tx(s, M + 6, y, 8.6); y -= 11; }); y -= 6; }
    var sx = y - 8, sw = (W - 2 * M - 20) / 3, labs = ['Le magasinier', r.type === 'reception' ? 'Le réceptionnaire / livreur' : 'Le chef de chantier', 'La direction / le comptable'], who = [r.redacteur, r.verifie, ''];
    labs.forEach(function (lb, k) { var bx = M + k * (sw + 10); Tx(lb, bx, sx, 8.4, { b: true, c: NAVY }); RS(bx, sx - 70, sw, 62, LINE, .8); if (who[k]) Tx(who[k], bx + 6, sx - 66 + 0, 7.8, { c: GREY }); });
    var qy = Math.max(60, sx - 160), q = 2;
    if (env.qrMatrix) {
      var m = env.qrMatrix, n = m.length, t = n + 2 * q, qs = 62, s = qs / t, qx = M;
      R(qx, qy + 6, qs, qs, [1, 1, 1]); RS(qx, qy + 6, qs, qs, LINE, .6);
      for (var rr = 0; rr < n; rr++) for (var cc2 = 0; cc2 < n; cc2++) if (m[rr][cc2]) pg.drawRectangle({ x: qx + (cc2 + q) * s, y: qy + 6 + qs - (rr + q + 1) * s, width: s + .15, height: s + .15, color: lib.rgb(0, 0, 0) });
      Tx('Scannez pour vérifier', qx + qs + 10, qy + 44, 8.4, { b: true, c: NAVY }); Tx('l’authenticité du rapport', qx + qs + 10, qy + 33, 8.4, { b: true, c: NAVY });
      if (env.qrCode) Tx('Code ' + String(env.qrCode).toUpperCase(), qx + qs + 10, qy + 21, 7.6, { c: GREY });
    }
    Tx('Toute correction doit être validée et authentifiée par ' + nom + '.', W - M, qy + 24, 7.6, { c: GREY, al: 'r' });
    footer();
    pages.forEach(function (p, i) { pg = p; Tx('Page ' + (i + 1) + ' / ' + pages.length, W - M, 50, 7.6, { al: 'r', c: GREY }); });
    pdf.setTitle(T.lib + ' ' + (r.no || '')); pdf.setAuthor('Excellencia Building');
    return pdf.save();
  }

  async function make(r) {
    var lib = await loadLib(), ID = null; try { ID = w.EXBId ? w.EXBId.get() : null; } catch (e) { }
    var env = { id: ID };
    env.logo = await imgBytes((ID && ID.logo) || 'icon-192.png') || await imgBytes('icon-192.png');
    try {
      if (w.EXBVerif && w.EXBVerif.code && w.EXBQR) {
        var C = calc(r), key = [r.type, r.projet || '', r.fournisseur || '', r.bl || '', C.n, C.ecarts].join('|');
        var c1 = w.EXBVerif.code('g', r.no, r.date, '', '', key, r.projet || r.fournisseur || '');
        env.qrMatrix = w.EXBQR.matrix(c1.url); env.qrCode = c1.hash;
        w.EXBVerif.publish({ no: r.no, kind: 'document', hash: c1.hash, date: r.date, total: 0, cur: '', status: r.statut === 'validé' ? 'valide' : 'brouillon', nom: r.projet || r.fournisseur || '', matricule: '', libelle: typ(r.type).lib + ' — ' + (r.projet || r.fournisseur || ''), detail: C.n + ' ligne(s), ' + C.ecarts + ' écart(s)' });
      }
    } catch (e) { env.qrMatrix = null; }
    r.entreprise = (ID && ID.name) || r.entreprise || '';
    return new Blob([await build(lib, r, env)], { type: 'application/pdf' });
  }

  /* ---------- interface : carte « Rapport de matériaux » ---------- */
  function listes() {
    var pr = rd('exb_projects').map(function (x) { return String(x && (x.name || x.nom) || '').trim(); }).filter(Boolean);
    var fo = rd('exb_stock').map(function (x) { return String(x && x.supplier || '').trim(); }).filter(Boolean);
    var u = function (a) { return a.filter(function (v, i) { return a.indexOf(v) === i; }).slice(0, 200); };
    return { projets: u(pr), fournisseurs: u(fo) };
  }
  function lineRow(l, i, T) {
    l = l || {};
    return '<div data-rmline="' + i + '" style="display:grid;grid-template-columns:2.4fr .8fr .9fr .9fr 1.6fr auto;gap:4px;margin-bottom:4px;align-items:center">' +
      '<input data-f="des" maxlength="120" placeholder="Désignation (ex. Ciment CPA 42,5)" value="' + esc(l.des || '') + '"/>' +
      '<input data-f="unite" maxlength="14" placeholder="Unité" value="' + esc(l.unite || '') + '"/>' +
      '<input data-f="q1" inputmode="decimal" placeholder="' + esc(T.c1) + '" value="' + esc(l.q1 == null ? '' : l.q1) + '"/>' +
      '<input data-f="q2" inputmode="decimal" placeholder="' + esc(T.c2) + '" value="' + esc(l.q2 == null ? '' : l.q2) + '"/>' +
      '<input data-f="obs" maxlength="140" placeholder="Observation" value="' + esc(l.obs || '') + '"/>' +
      '<button type="button" class="muted" data-rmdel="' + i + '" title="Retirer la ligne">✕</button></div>';
  }
  function statLib(r) { return r.statut === 'validé' ? '✅ validé' : '📝 brouillon'; }
  function liRow(r) {
    var C = calc(r), T = typ(r.type);
    return '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;border-bottom:1px solid #e4e8ef;padding:5px 0"><span><b>' + esc(r.no) + '</b> · ' + T.ico + ' ' + esc(T.lib) + ' · ' + esc(r.projet || r.fournisseur || '—') + ' · ' + C.n + ' ligne(s)' + (C.ecarts ? ' · ' + C.ecarts + ' écart(s)' : '') + ' · ' + statLib(r) + '</span><span style="white-space:nowrap"><button type="button" class="muted" data-rmedit="' + esc(r.no) + '">✏️</button> <button type="button" class="muted" data-rmpdf="' + esc(r.no) + '">📄 PDF</button></span></div>';
  }

  function mountCard(sec) {
    if (!sec) return; var cid = 'exbRmCard_' + sec.id; if ($(cid)) return;
    var L = listes(), st = { type: 'reception', lignes: [{}, {}, {}], no: '' };
    var c = d.createElement('div'); c.id = cid; c.className = 'card no-print'; c.style.marginBottom = '14px';
    c.innerHTML = '<h2>📦 Rapport de matériaux</h2>' +
      '<p class="hint" style="margin:0 0 8px">Réception, consommation ou état du stock : saisissez ou reprenez les lignes depuis le stock, enregistrez (synchronisé avec les autres espaces) puis exportez en PDF avec QR de vérification.</p>' +
      '<label>Type de rapport</label><select data-rm="type">' + Object.keys(TYPES).map(function (k) { return '<option value="' + k + '">' + TYPES[k].ico + ' ' + TYPES[k].lib + '</option>'; }).join('') + '</select>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label>Projet / chantier</label><input data-rm="projet" maxlength="80" list="rmPr_' + sec.id + '" autocomplete="off"/><datalist id="rmPr_' + sec.id + '">' + L.projets.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist></div><div><label>Dépôt / magasin</label><input data-rm="depot" maxlength="60"/></div></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label data-rm="lblFour">Fournisseur</label><input data-rm="fournisseur" maxlength="80" list="rmFo_' + sec.id + '" autocomplete="off"/><datalist id="rmFo_' + sec.id + '">' + L.fournisseurs.map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist></div><div data-rm="boxBl"><label>BL / commande n°</label><input data-rm="bl" maxlength="40"/></div></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px"><div><label>Date</label><input data-rm="date" type="date"/></div><div><label>Période du</label><input data-rm="du" type="date"/></div><div><label>au</label><input data-rm="au" type="date"/></div></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label>Établi par (magasinier)</label><input data-rm="redacteur" maxlength="60"/></div><div><label data-rm="lblVer">Réceptionné par</label><input data-rm="verifie" maxlength="60"/></div></div>' +
      '<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:10px 0 4px"><b>Matériaux</b><button type="button" class="muted" data-rm="reprendre">📥 Reprendre depuis le stock</button><button type="button" class="muted" data-rm="addl">➕ Ligne</button></div>' +
      '<div data-rm="lignes"></div>' +
      '<label>Observations générales</label><textarea data-rm="observations" rows="2" maxlength="600" placeholder="Anomalies, matériaux endommagés, manquants, réserves…"></textarea>' +
      '<label>Statut</label><select data-rm="statut"><option value="brouillon">📝 Brouillon</option><option value="validé">✅ Validé</option></select>' +
      '<div class="actions" style="margin-top:8px"><button type="button" class="primary" data-rm="go">💾 Enregistrer et faire le PDF</button> <button type="button" class="muted" data-rm="save">💾 Enregistrer seulement</button> <button type="button" class="muted" data-rm="new">🆕 Nouveau</button></div>' +
      '<div data-rm="banner" class="msg" style="display:none"></div><div data-rm="result"></div>' +
      '<details style="margin-top:10px"><summary><b>📒 Derniers rapports de matériaux</b></summary><div data-rm="liste" style="margin-top:6px"></div></details>';
    sec.insertBefore(c, sec.firstChild);
    var q = function (k) { return c.querySelector('[data-rm="' + k + '"]'); };
    function say2(m, ok) { var e = q('banner'); e.className = 'msg ' + (ok ? 'ok' : 'warn'); e.innerHTML = m; e.style.display = 'block'; }
    function lirel() { var out = []; q('lignes').querySelectorAll('[data-rmline]').forEach(function (row) { var g = function (f) { return row.querySelector('[data-f="' + f + '"]').value; }; out.push({ des: g('des').trim(), unite: g('unite').trim(), q1: g('q1').trim(), q2: g('q2').trim(), obs: g('obs').trim() }); }); return out; }
    function dessinel() { var T = typ(st.type); q('lignes').innerHTML = st.lignes.map(function (l, i) { return lineRow(l, i, T); }).join(''); }
    function types() {
      st.type = q('type').value; var T = typ(st.type), rec = st.type === 'reception';
      q('boxBl').style.display = rec ? '' : 'none'; q('lblFour').textContent = rec ? 'Fournisseur' : 'Fournisseur / source (facultatif)'; q('lblVer').textContent = rec ? 'Réceptionné par' : 'Vérifié par (chef de chantier)';
      st.lignes = lirel(); dessinel();
    }
    function liste() { var all = rd(KEY).slice().reverse().slice(0, 10), el = q('liste'); el.innerHTML = all.length ? all.map(liRow).join('') : '<p class="hint">Aucun rapport pour l’instant.</p>'; }
    function remplir(r) {
      q('type').value = r.type || 'reception'; ['projet', 'depot', 'fournisseur', 'bl', 'date', 'du', 'au', 'redacteur', 'verifie', 'observations', 'statut'].forEach(function (k) { q(k).value = r[k] || (k === 'statut' ? 'brouillon' : ''); });
      st.no = r.no || ''; st.lignes = (r.lignes && r.lignes.length ? r.lignes : [{}, {}, {}]).map(function (l) { return { des: l.des || '', unite: l.unite || '', q1: l.q1 == null ? '' : l.q1, q2: l.q2 == null ? '' : l.q2, obs: l.obs || '' }; });
      var rec = (r.type || 'reception') === 'reception'; st.type = r.type || 'reception'; q('boxBl').style.display = rec ? '' : 'none'; dessinel();
    }
    function nouveau() { remplir({ type: q('type').value, date: today(), statut: 'brouillon' }); st.no = ''; q('banner').style.display = 'none'; q('result').innerHTML = ''; types(); }
    function collecte() {
      var date = q('date').value || today(), r = { type: q('type').value, date: date, projet: q('projet').value.trim(), depot: q('depot').value.trim(), fournisseur: q('fournisseur').value.trim(), bl: q('bl').value.trim(), du: q('du').value, au: q('au').value, redacteur: q('redacteur').value.trim(), verifie: q('verifie').value.trim(), observations: q('observations').value.trim(), statut: q('statut').value, lignes: lirel().filter(function (l) { return l.des; }) };
      return r;
    }
    function sauver(pdf) {
      var r = collecte(); if (!r.lignes.length) return say2('Ajoutez au moins un matériau (désignation).');
      if (!r.projet && !r.fournisseur) return say2('Indiquez le projet / chantier ou le fournisseur.');
      var all = rd(KEY), old = st.no ? all.filter(function (x) { return x.no === st.no; })[0] : null;
      if (old && old.type !== r.type) old = null;
      r.no = old ? old.no : nextNo(all, r.date, r.type); r.id = r.no; r.at = old ? old.at : new Date().toISOString(); r.maj = new Date().toISOString();
      var fin = function (blob) {
        var k = -1; all.forEach(function (x, i) { if (x.no === r.no) k = i; }); if (k >= 0) all[k] = r; else all.push(r);
        if (!wr(KEY, all)) return say2('Enregistrement impossible (stockage plein ?). Le rapport n’a pas été enregistré.');
        st.no = r.no; audit(old ? 'RAPPORT_MATERIAUX_MODIFIÉ' : 'RAPPORT_MATERIAUX_CRÉÉ', r.no + ' — ' + typ(r.type).lib + ' — ' + (r.projet || r.fournisseur));
        say2('✓ Rapport n° <b>' + esc(r.no) + '</b> enregistré (' + r.lignes.length + ' ligne(s)) et synchronisé avec les autres espaces.', true);
        q('result').innerHTML = blob ? '<div class="actions"><a class="primary" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + URL.createObjectURL(blob) + '" target="_blank" rel="noopener" download="' + esc(r.no) + '.pdf">📄 Ouvrir le PDF ' + esc(r.no) + '</a></div>' : '';
        liste();
      };
      if (!pdf) return fin(null);
      make(JSON.parse(JSON.stringify(r))).then(fin, function (e) { say2('Impossible de faire le PDF : ' + esc(e && e.message || e)); });
    }
    q('date').value = today(); types();
    c.addEventListener('change', function (e) { var k = e.target.getAttribute && e.target.getAttribute('data-rm'); if (k === 'type') types(); });
    c.addEventListener('click', function (e) {
      var bt = e.target.closest && e.target.closest('button'); if (!bt) return;
      var dl = bt.getAttribute('data-rmdel'); if (dl != null) { st.lignes = lirel(); st.lignes.splice(+dl, 1); if (!st.lignes.length) st.lignes = [{}]; dessinel(); return; }
      var k = bt.getAttribute('data-rm');
      if (k === 'addl') { st.lignes = lirel(); st.lignes.push({}); dessinel(); }
      else if (k === 'reprendre') {
        var t = q('type').value, add = fromStock(t, rd('exb_stock'), rd('exb_stock_moves'), q('du').value, q('au').value);
        if (!add.length) return say2(t === 'stock' ? 'Aucun article en stock à reprendre.' : 'Aucun mouvement de stock ' + (t === 'reception' ? 'd’entrée' : 'de sortie') + ' sur cette période. Saisissez les lignes à la main ou élargissez la période.');
        var cur = lirel().filter(function (l) { return l.des; }); st.lignes = cur.concat(add); dessinel(); say2('✓ ' + add.length + ' ligne(s) reprise(s) depuis le stock. Complétez les quantités manquantes puis enregistrez.', true);
      }
      else if (k === 'go') sauver(true); else if (k === 'save') sauver(false); else if (k === 'new') nouveau();
    });
    c.querySelector('[data-rm="liste"]').addEventListener('click', function (e) {
      var b1 = e.target.closest && e.target.closest('[data-rmpdf]'), b2 = e.target.closest && e.target.closest('[data-rmedit]');
      if (b1) { var r = rd(KEY).filter(function (x) { return x.no === b1.getAttribute('data-rmpdf'); })[0]; if (!r) return; make(JSON.parse(JSON.stringify(r))).then(function (bl) { w.open(URL.createObjectURL(bl), '_blank'); }, function (er) { say2('PDF impossible : ' + esc(er && er.message || er)); }); }
      else if (b2) { var r2 = rd(KEY).filter(function (x) { return x.no === b2.getAttribute('data-rmedit'); })[0]; if (r2) { remplir(JSON.parse(JSON.stringify(r2))); say2('Rapport ' + esc(r2.no) + ' chargé : modifiez puis enregistrez.', true); c.scrollIntoView && c.scrollIntoView(); } }
    });
    liste();
  }

  function mountAll(x) { try { if (x === 'stock') mountCard($('stock')); } catch (e) { } }
  if (w.document) {
    var _s = w.show;
    if (typeof _s === 'function' && !w.__exbRmShow) { w.__exbRmShow = 1; w.show = function (x) { var r = _s.apply(this, arguments); mountAll(x); return r; }; }
  }
  /* un collègue (autre appareil, autre espace) a créé ou modifié un rapport : la liste se réaffiche */
  w.exbReRenderRm = function () {
    try { d.querySelectorAll('[id^="exbRmCard_"]').forEach(function (c) { var l = c.querySelector('[data-rm="liste"]'); if (!l) return; var all = rd(KEY).slice().reverse().slice(0, 10); l.innerHTML = all.length ? all.map(liRow).join('') : '<p class="hint">Aucun rapport pour l’instant.</p>'; }); } catch (e) { }
  };
  w.EXBRapportMateriaux = { build: build, make: make, mount: mountCard, nextNo: nextNo, calc: calc, fromStock: fromStock, types: TYPES };
  if (typeof module !== 'undefined' && module.exports) module.exports = { build: build, calc: calc, nextNo: nextNo, fromStock: fromStock };
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
