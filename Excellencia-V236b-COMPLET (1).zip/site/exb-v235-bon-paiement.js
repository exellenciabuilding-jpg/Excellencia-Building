/* Excellencia Building V235 — 🧾 BON DE PAIEMENT (Ingénierie · Architecture · Chantiers → guichet du comptable).
 * Le bureau d'études / l'architecte / le chantier fait le devis ou la prestation, puis remet au client un BON DE PAIEMENT (PDF A4,
 * même en-tête, mêmes couleurs, même pied et même QR de vérification que le bon de commande V228). Le client se présente au guichet
 * du comptable avec le bon : le guichetier le retrouve (Espace Comptable › Reçus de paiement › « Bons de paiement à encaisser »),
 * encaisse, et le logiciel fait le reçu, marque le bon « PAYÉ » et reporte l'encaissement dans la caisse du guichet (exb_guichet).
 * Registre « exb_bons_paiement » (pont de stockage commun : sauvegardé avec le reste). Rien n'est inventé : tout est saisi ou repris d'un devis.
 * API : EXBBonPaiement.build(lib,bon,env) -> Promise<Uint8Array> ; .make(bon) -> Promise<Blob> ; .encaisser(no,{montant,mode,...}) ; .mount(sec,pole) ;
 *       .nextNo(all,date) ; .totaux(bon) ; .lettres(m,dev). */
(function (w, d) {
  'use strict';
  var KEY = 'exb_bons_paiement', KG = 'exb_guichet';
  var NAVY = [0.090, 0.208, 0.396], BLUE = [0.125, 0.286, 0.541], BAND = [0.918, 0.941, 0.984], GOLD = [0.769, 0.604, 0.220], GREY = [0.40, 0.43, 0.49], INK = [0.10, 0.12, 0.18], LINE = [0.78, 0.82, 0.88], SOFT = [0.95, 0.97, 0.99];
  var TEL = '+243 810 644 554', MAIL = 'excellenciabuilding@gmail.com';
  var POLES = {
    ingenierie: { lib: 'Ingénierie', ico: '⚙️', objet: 'Étude, note de calcul, plan de structure…', sub: 'Pôle Ingénierie' },
    architecture: { lib: 'Architecture', ico: '📐', objet: 'Plans architecturaux, permis, suivi…', sub: 'Pôle Architecture' },
    chantier: { lib: 'Chantier / Réalisation', ico: '🏗️', objet: 'Travaux, situation, avance…', sub: 'Pôle Réalisation — Chantier' }
  };
  var MODES = [['caisse', 'Espèces'], ['banque', 'Virement'], ['mobile_money', 'Mobile Money'], ['cheque', 'Chèque'], ['autre', 'Autre']];
  var $ = function (i) { return d && d.getElementById(i); };
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(v) { var n = parseFloat(String(v == null ? '' : v).replace(/[\s\u00a0\u202f]/g, '').replace(',', '.')); return isFinite(n) ? n : 0; }
  function r2(n) { return Math.round(n * 100) / 100; }
  function dev(x) { return String(x || '').toUpperCase() === 'FC' ? 'FC' : 'USD'; }
  function today() { var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
  function fmt(n, dv) { return Number(n || 0).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' ' + (dev(dv) === 'FC' ? 'FC' : '$'); }
  function rd(k) { try { if (w.EXBS && w.EXBS.get) return w.EXBS.get(k); } catch (e) { } return []; }
  function wr(k, v) { try { if (w.EXBS && w.EXBS.set) return w.EXBS.set(k, v) !== false; } catch (e) { } return false; }
  function audit(a, t) { try { if (typeof w.audit === 'function') w.audit(a, t); } catch (e) { } }

  /* ---------- calculs (testés hors navigateur) ---------- */
  function totaux(b) {
    var tot = r2(Math.max(0, num(b && b.montant))), p = 0;
    ((b && b.paiements) || []).forEach(function (x) { p += num(x.montant); });
    p = r2(p); var reste = r2(Math.max(0, tot - p));
    return { total: tot, paye: p, reste: reste, statut: tot <= 0 ? 'aucun' : reste <= 0.005 ? 'payé' : p > 0 ? 'partiel' : 'à payer' };
  }
  function nextNo(all, date) {
    var y = String(date || today()).slice(0, 4), mx = 0;
    (all || []).forEach(function (r) { var m = /^EXB-BP-(\d{4})-(\d+)$/.exec(r && r.no || ''); if (m && m[1] === y) mx = Math.max(mx, parseInt(m[2], 10)); });
    return 'EXB-BP-' + y + '-' + ('000' + (mx + 1)).slice(-4);
  }
  function lettres(m, dv) {
    try { if (w.EXBRecuClient && w.EXBRecuClient.words) return w.EXBRecuClient.words(m, dev(dv)); } catch (e) { }
    return nfp(m) + ' ' + dev(dv);
  }
  function nfp(v) { v = Number(v) || 0; var s = Math.abs(v).toFixed(2).split('.'); s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (v < 0 ? '-' : '') + s.join(','); }

  /* ---------- utilitaires PDF (mêmes que V228) ---------- */
  var OK = { 8217: 1, 8216: 1, 8220: 1, 8221: 1, 8211: 1, 8212: 1, 8364: 1, 339: 1, 338: 1, 8230: 1, 8226: 1 };
  function san(t) { t = String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ').replace(/\u202f|\u00a0/g, ' '); var o = ''; for (var i = 0; i < t.length; i++) { var c = t.charCodeAt(i); o += (c < 256 || OK[c]) ? t.charAt(i) : '?'; } return o; }
  function fd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function dataUrlBytes(u) { var b = atob(String(u).split(',')[1] || ''), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function loadLib() {
    if (w.PDFLib) return Promise.resolve(w.PDFLib);
    return new Promise(function (ok, ko) { var s = d.createElement('script'); s.src = 'pdflib/pdf-lib.min.js'; s.onload = function () { w.PDFLib ? ok(w.PDFLib) : ko(new Error('pdf-lib')); }; s.onerror = function () { ko(new Error('pdf-lib introuvable')); }; d.head.appendChild(s); });
  }
  async function imgBytes(src) {
    try {
      if (!src) return null;
      if (/^data:image\/(png|jpe?g)/i.test(src)) return { b: dataUrlBytes(src), png: /^data:image\/png/i.test(src) };
      var r = await fetch(src); if (!r.ok) return null; var ab = new Uint8Array(await r.arrayBuffer()); return { b: ab, png: ab[0] === 0x89 };
    } catch (e) { return null; }
  }

  /* ---------- construction du PDF ---------- */
  async function build(lib, b, env) {
    env = env || {};
    var pdf = await lib.PDFDocument.create(), pg = pdf.addPage([595, 842]), W = 595, H = 842, M = 40;
    var F1 = await pdf.embedFont(lib.StandardFonts.Helvetica), F2 = await pdf.embedFont(lib.StandardFonts.HelveticaBold), F3 = await pdf.embedFont(lib.StandardFonts.HelveticaOblique);
    var rgb = function (a) { return lib.rgb(a[0], a[1], a[2]); };
    function T(t, x, y, sz, o) { o = o || {}; var f = o.i ? F3 : (o.b ? F2 : F1); t = san(t); if (o.al) { var wd = f.widthOfTextAtSize(t, sz); x = o.al === 'r' ? x - wd : x - wd / 2; } pg.drawText(t, { x: x, y: y, size: sz, font: f, color: rgb(o.c || INK) }); }
    function TW(t, sz, bd) { return (bd ? F2 : F1).widthOfTextAtSize(san(t), sz); }
    function R(x, y, w2, h, c) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, color: rgb(c) }); }
    function RS(x, y, w2, h, c, lw) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, borderColor: rgb(c), borderWidth: lw || .8 }); }
    function L(x1, y1, x2, y2, c, lw) { pg.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: lw || .6, color: rgb(c || LINE) }); }
    function fit(t, maxW, sz, bd) { t = san(t); while (sz > 6 && TW(t, sz, bd) > maxW) sz -= .25; if (TW(t, sz, bd) > maxW) { while (t.length > 3 && TW(t + '…', sz, bd) > maxW) t = t.slice(0, -1); t += '…'; } return { t: t, sz: sz }; }
    function field(label, val, x, y, wTot, o) {
      o = o || {}; T(label, x, y, 8.4, { b: true, c: NAVY }); var lx = x + TW(label, 8.4, true) + 6;
      L(lx, y - 2.5, x + wTot, y - 2.5, LINE, .6);
      if (val !== '' && val != null) { var f = fit(val, x + wTot - lx - 4, o.sz || 9.6, true); T(f.t, lx + 2, y, f.sz, { b: true }); }
    }
    function section(n, title, y) { R(M, y - 3, W - 2 * M, 16, NAVY); R(M, y - 3, 4, 16, GOLD); T(n + '. ' + title, M + 12, y + 1.2, 9.4, { b: true, c: [1, 1, 1] }); }
    function wrap(txt, maxW, sz, bd) { var out = [], ln = ''; String(txt).split(' ').forEach(function (x) { var t2 = ln ? ln + ' ' + x : x; if (TW(t2, sz, bd) > maxW && ln) { out.push(ln); ln = x; } else ln = t2; }); if (ln) out.push(ln); return out; }

    /* en-tête : identique au bon de commande */
    var I = env.id || {}, nom = b.entreprise || I.name || 'Excellencia Building', logo = null;
    try { if (env.logo) logo = env.logo.png ? await pdf.embedPng(env.logo.b) : await pdf.embedJpg(env.logo.b); } catch (e) { logo = null; }
    var tx = M;
    if (logo) { var lh = 62, lw2 = lh * logo.width / logo.height; if (lw2 > 80) { lw2 = 80; lh = lw2 * logo.height / logo.width; } pg.drawImage(logo, { x: M, y: H - 26 - lh, width: lw2, height: lh }); tx = M + lw2 + 14; }
    var place = [I.address || 'Kinshasa, RDC', I.country].filter(function (v, i, a) { return v && !(i === 1 && String(a[0]).toLowerCase().indexOf(String(v).toLowerCase()) >= 0); }).join(', ');
    var items = [place, 'Tél : ' + (I.phone || TEL), 'E-mail : ' + (I.email || MAIL), I.website || ''].filter(Boolean), CW = 215, clines = [], cc = '';
    items.forEach(function (it) { var t5 = cc ? cc + '  ·  ' + it : it; if (cc && TW(t5, 7.6) > CW) { clines.push(cc); cc = it; } else cc = t5; }); if (cc) clines.push(cc);
    clines.slice(0, 4).forEach(function (l6, i) { var f6 = fit(l6, CW, 7.6); T(f6.t, W - M, H - 34 - i * 10.5, f6.sz, { al: 'r', c: GREY }); });
    var nmax = W - M - CW - 14 - tx, nf1 = fit(nom, nmax, 20, true);
    T(nf1.t, tx, H - 46, nf1.sz, { b: true, c: NAVY });
    var sl = fit('L’excellence au cœur de vos constructions', nmax, 9.5); T(sl.t, tx, H - 62, sl.sz, { i: true, c: [0.62, 0.47, 0.13] });
    var ar = fit('ARCHITECTURE  •  INGÉNIERIE  •  RÉALISATION', nmax, 7.8, true); T(ar.t, tx, H - 76, ar.sz, { b: true, c: GREY });
    L(M, H - 98, W - M, H - 98, GOLD, 2.2);
    var P = POLES[b.pole] || POLES.ingenierie, tt = totaux(b), cur = dev(b.devise);
    R(M, H - 142, W - 2 * M, 38, BAND); R(M, H - 142, 5, 38, BLUE);
    T('BON DE PAIEMENT', M + 18, H - 123, 15, { b: true, c: BLUE });
    T(P.sub, M + 18, H - 136, 9.5, { c: INK });
    T('À présenter au guichet  •  À conserver', W - M - 8, H - 136, 8, { al: 'r', c: GREY });
    L(M, H - 147, W - M, H - 147, NAVY, 3);

    var y = H - 168;
    field('Référence du bon : ', b.no, M, y, 300, { sz: 10.5 }); field('Date :', fd(b.date), M + 318, y, W - 2 * M - 318); y -= 21;
    field('Référence du devis :', b.devis || '', M, y, W - 2 * M);

    /* 1. client */
    y -= 28; section(1, 'INFORMATIONS DU CLIENT', y); y -= 22;
    field('Nom du client :', b.client || '', M, y, W - 2 * M, { sz: 10.2 }); y -= 22;
    field('Objet de la prestation :', b.objet || '', M, y, W - 2 * M); y -= 22;
    field('Projet / chantier :', b.projet || '', M, y, 300); field('Contact / Tél :', b.contact || '', M + 318, y, W - 2 * M - 318);

    /* 2. montant */
    y -= 28; section(2, 'MONTANT À PAYER', y); y -= 12;
    var bx = y - 78; R(M, bx, W - 2 * M, 80, SOFT); RS(M, bx, W - 2 * M, 80, GOLD, 1.2); R(M, bx, 5, 80, GOLD);
    T('Montant total', M + 16, y - 20, 9.2, { b: true, c: NAVY });
    T(nfp(tt.total) + ' ' + cur, W - M - 14, y - 22, 17, { b: true, c: BLUE, al: 'r' });
    L(M + 12, y - 32, W - M - 12, y - 32, LINE, .6);
    T('Montant en lettres', M + 16, y - 48, 9.2, { b: true, c: NAVY });
    var wl = wrap(lettres(tt.total, cur), W - 2 * M - 150, 9.2, true).slice(0, 2);
    wl.forEach(function (s, i) { T(s, M + 130, y - 48 - i * 12, 9.2, { b: true }); });
    if (tt.paye > 0.005) T('Déjà payé : ' + nfp(tt.paye) + ' ' + cur + '   •   Reste à payer : ' + nfp(tt.reste) + ' ' + cur, M + 16, y - 72, 8.6, { b: true, c: tt.reste > 0.005 ? [0.70, 0.12, 0.12] : [0.05, 0.45, 0.20] });
    y = bx - 14;

    /* 3. instructions */
    section(3, 'INSTRUCTIONS DE PAIEMENT', y); y -= 18;
    wrap('Veuillez vous présenter au guichet de paiement muni du présent bon afin de procéder au règlement du montant indiqué ci-dessus. Après paiement, veuillez conserver votre reçu comme preuve de règlement.', W - 2 * M, 8.6).forEach(function (s) { T(s, M, y, 8.6); y -= 11; });
    T('Ce bon est valable uniquement pour la prestation et le montant indiqués. Il ne remplace ni le devis ni la facture.', M, y - 2, 7.8, { i: true, c: GREY }); y -= 12;

    /* 4. caisse */
    y -= 14; section(4, 'RÉSERVÉ À LA CAISSE', y); y -= 14;
    var last = (b.paiements || []).slice(-1)[0] || {}, bh = 64, by = y - bh;
    RS(M, by, W - 2 * M, bh, LINE, .9); L(M + (W - 2 * M) / 2, by, M + (W - 2 * M) / 2, by + bh, LINE, .6); L(M, by + bh / 2, W - M, by + bh / 2, LINE, .6);
    var cx2 = M + (W - 2 * M) / 2 + 10, MODL = {}; MODES.forEach(function (m) { MODL[m[0]] = m[1]; });
    T('Montant reçu :', M + 10, by + bh - 20, 8.6, { b: true, c: NAVY }); if (last.montant != null) T(nfp(last.montant) + ' ' + cur, M + 90, by + bh - 20, 10, { b: true });
    T('Mode :', cx2, by + bh - 20, 8.6, { b: true, c: NAVY }); if (last.mode) T(MODL[last.mode] || last.mode, cx2 + 36, by + bh - 20, 9.4, { b: true });
    T('Date :', M + 10, by + 12, 8.6, { b: true, c: NAVY }); if (last.date) T(fd(last.date), M + 48, by + 12, 9.4, { b: true });
    T('N° de reçu :', cx2, by + 12, 8.6, { b: true, c: NAVY }); if (last.recu_no) T(last.recu_no, cx2 + 56, by + 12, 9.4, { b: true });
    y = by - 16; T('Signature et cachet de la caisse :', M, y, 8.6, { b: true, c: NAVY }); RS(M, y - 86, 250, 76, LINE, .8);
    if (tt.statut === 'payé') T('PAYÉ', W - M - 10, y - 2, 16, { b: true, c: [0.05, 0.45, 0.20], al: 'r' });
    else if (tt.statut === 'partiel') T('PAIEMENT PARTIEL', W - M - 10, y - 2, 11, { b: true, c: NAVY, al: 'r' });
    if (last.guichetier) T('Encaissé par ' + last.guichetier, M + 8, y - 22, 8.2, { c: GREY });

    /* QR */
    var qy = 62, q = 2;
    if (env.qrMatrix) {
      var m = env.qrMatrix, n = m.length, t = n + 2 * q, qs = 62, s = qs / t, qx = M;
      R(qx, qy + 6, qs, qs, [1, 1, 1]); RS(qx, qy + 6, qs, qs, LINE, .6);
      for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) pg.drawRectangle({ x: qx + (c + q) * s, y: qy + 6 + qs - (r + q + 1) * s, width: s + .15, height: s + .15, color: lib.rgb(0, 0, 0) });
      T('Scannez pour vérifier', qx + qs + 10, qy + 44, 8.4, { b: true, c: NAVY });
      T('l’authenticité du bon de paiement', qx + qs + 10, qy + 33, 8.4, { b: true, c: NAVY });
      if (env.qrCode) T('Code ' + String(env.qrCode).toUpperCase(), qx + qs + 10, qy + 21, 7.6, { c: GREY });
    }
    T('Toute correction doit être validée et authentifiée par ' + nom + '.', W - M, qy + 24, 7.6, { c: GREY, al: 'r' });
    /* pied */
    R(0, 0, W, 42, NAVY); R(0, 42, W, 3, GOLD);
    T('EXCELLENCIA BUILDING  –  From Vision to Reality', W / 2, 26, 8.6, { b: true, c: [1, 1, 1], al: 'c' });
    T('WhatsApp : ' + TEL + '  |  E-mail : ' + MAIL, W / 2, 12, 8.2, { c: [0.95, 0.82, 0.40], al: 'c' });
    pdf.setTitle('Bon de paiement ' + (b.no || '')); pdf.setAuthor('Excellencia Building');
    return pdf.save();
  }

  async function make(b) {
    var lib = await loadLib(), ID = null; try { ID = w.EXBId ? w.EXBId.get() : null; } catch (e) { }
    var env = { id: ID };
    env.logo = await imgBytes((ID && ID.logo) || 'icon-192.png') || await imgBytes('icon-192.png');
    try {
      if (w.EXBVerif && w.EXBVerif.code && w.EXBQR) {
        var tt = totaux(b), key = [b.client || '', b.objet || '', b.devis || '', tt.total].join('|');
        var c1 = w.EXBVerif.code('g', b.no, b.date, tt.total, b.devise || '', key, b.client || '');
        env.qrMatrix = w.EXBQR.matrix(c1.url); env.qrCode = c1.hash;
        w.EXBVerif.publish({ no: b.no, kind: 'document', hash: c1.hash, date: b.date, total: tt.total, cur: b.devise || '', status: 'valide', nom: b.client || '', matricule: '', libelle: 'Bon de paiement — ' + (b.objet || b.client || ''), detail: 'Payé ' + nfp(tt.paye) + ' / reste ' + nfp(tt.reste) });
      }
    } catch (e) { env.qrMatrix = null; }
    b.entreprise = (ID && ID.name) || b.entreprise || '';
    return new Blob([await build(lib, b, env)], { type: 'application/pdf' });
  }

  /* écriture en caisse de la comptabilité (exb_cash) : une ligne par encaissement, marquée bp_ref, jamais deux fois */
  function cashEcrire(entry) {
    try {
      var cur = null; try { if (typeof exbCash !== 'undefined' && exbCash && exbCash.length != null) cur = exbCash; } catch (e) { }
      var all = cur || rd('exb_cash');
      if (all.some(function (c) { return c && c.bp_ref === entry.bp_ref; })) return 'deja';
      if (cur && typeof exbSave === 'function') { cur.push(entry); exbSave('exb_cash', cur); try { if (typeof renderExbCash === 'function') renderExbCash(); if (typeof updateExbDirection === 'function') updateExbDirection(); } catch (e) { } return 'ok'; }
      all.push(entry); return wr('exb_cash', all) ? 'ok' : 'echec';
    } catch (e) { return 'echec'; }
  }

  /* ---------- encaissement (guichet du comptable) ---------- */
  async function encaisser(no, o) {
    o = o || {}; var all = rd(KEY), b = all.filter(function (x) { return x.no === no; })[0];
    if (!b) throw new Error('Bon introuvable : ' + no);
    var tt = totaux(b), m = r2(num(o.montant)); if (!(m > 0)) throw new Error('Indiquez le montant encaissé.');
    if (m > tt.reste + 0.005) throw new Error('Montant supérieur au reste à payer (' + fmt(tt.reste, b.devise) + ').');
    var g = rd(KG), y = new Date().getFullYear(), pre = 'REC-GUI-' + y + '-', mx = 0;
    g.forEach(function (x) { if (x.recu_no && x.recu_no.indexOf(pre) === 0) mx = Math.max(mx, parseInt(x.recu_no.slice(pre.length), 10) || 0); });
    var rno = pre + ('0000' + (mx + 1)).slice(-4), solde = r2(tt.reste - m), motif = solde <= 0.005 ? 'solde' : (tt.paye > 0 ? 'avancement' : 'acompte'), mode = o.mode || 'caisse';
    var data = { recu_no: rno, date: today(), devise: dev(b.devise), client: b.client, matricule: '', tel: b.contact || '', adresse: '', projet: b.projet || b.objet || '', contrat: 'Bon ' + b.no, motif: motif, motifAutre: '', montant: m,
      mode: mode === 'cheque' ? 'autre' : mode, reference: (mode === 'cheque' ? 'Chèque ' : '') + (o.reference || ''), trans_no: o.reference || '', total: tt.total, dejaPaye: tt.paye, solde: solde, caisse: o.guichetier || '', agence: 'Guichet' };
    var recu = null; if (w.EXBRecuClient && w.EXBRecuClient.make) recu = await w.EXBRecuClient.make(data);
    b.paiements = (b.paiements || []).concat([{ date: today(), montant: m, mode: mode, reference: o.reference || '', recu_no: rno, guichetier: o.guichetier || '' }]);
    var t2 = totaux(b); b.statut = t2.statut; b.paye = t2.paye; b.reste = t2.reste;
    g.push({ id: rno, type: 'client', date: today(), at: new Date().toISOString(), nom: b.client, matricule: '', tel: b.contact || '', ref: 'Bon ' + b.no, projet: b.projet || '', projetId: b.projetId || '', motif: motif, montant: m, devise: dev(b.devise), total: tt.total, solde: solde, mode: mode, reference: o.reference || '', guichetier: o.guichetier || '', recu_no: rno, statut: 'ok', bon_no: b.no });
    if (!wr(KG, g) || !wr(KEY, all)) throw new Error('Enregistrement impossible (stockage plein ?). Rien n’a été encaissé.');
    var caisse = cashEcrire({ id: 'CASH-BP-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), date: today(), type: 'in', label: 'Bon de paiement ' + b.no + ' — ' + b.client + (b.objet ? ' (' + b.objet + ')' : ''), amount: m, currency: dev(b.devise), method: { caisse: 'Caisse', banque: 'Banque', cheque: 'Banque', mobile_money: 'Mobile Money' }[mode] || 'Autre', ref: rno, bp_ref: rno, source: 'bon-paiement', projet: b.projet || '', cree_le: new Date().toISOString() });
    audit('BON_PAIEMENT_ENCAISSÉ', b.no + ' — ' + b.client + ' — ' + fmt(m, b.devise) + ' — reçu ' + rno);
    return { bon: b, recu: recu, recu_no: rno, solde: solde, caisse: caisse };
  }

  /* ---------- interface ---------- */
  function say(id, m, ok) { var e = $(id); if (e) { e.className = 'msg ' + (ok ? 'ok' : 'warn'); e.innerHTML = m; e.style.display = 'block'; } }
  function lien(url, nom, ico) { return '<a class="gold" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none;margin-right:6px" href="' + url + '" target="_blank" rel="noopener">' + ico + ' Ouvrir</a><a class="muted" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + url + '" download="' + esc(nom) + '.pdf">⬇ Télécharger</a>'; }
  function statLib(s) { return { 'payé': '✅ Payé', 'partiel': '🟠 Partiel', 'à payer': '🔴 À payer' }[s] || s; }
  function clientsList() { try { var cl = rd('exb_clients').map(function (x) { return String(x && (x.name || x.company || x.nom || x.client) || '').trim(); }).filter(Boolean); return cl.filter(function (v, i) { return cl.indexOf(v) === i; }).slice(0, 200); } catch (e) { return []; } }

  /* Carte « Bon de paiement » dans un module (ingénierie, architecture, chantier) */
  function mountCard(sec, pole) {
    if (!sec) return; var cid = 'exbBpCard_' + sec.id; if ($(cid)) return;
    var c = d.createElement('div'); c.id = cid; c.className = 'card no-print'; c.style.marginBottom = '14px';
    var devis = rd('exb_finance').filter(function (x) { return x && x.type === 'devis'; });
    c.innerHTML = '<h2>🧾 Bon de paiement client</h2>' +
      '<p class="hint" style="margin:0 0 8px">Après un devis ou une prestation, remettez ce bon au client : il le présente au guichet du comptable pour payer (PDF avec QR de vérification).</p>' +
      '<label>Pôle</label><select data-bp="pole">' + Object.keys(POLES).map(function (k) { return '<option value="' + k + '"' + (k === pole ? ' selected' : '') + '>' + POLES[k].ico + ' ' + POLES[k].lib + '</option>'; }).join('') + '</select>' +
      (devis.length ? '<label>Reprendre un devis existant (facultatif)</label><select data-bp="devisPick"><option value="">— saisie libre —</option>' + devis.map(function (x, i) { return '<option value="' + i + '">' + esc((x.no || '—') + ' · ' + (x.client || '—') + (Number(x.ttc) > 0 ? ' · ' + fmt(x.ttc, x.cur) : '')) + '</option>'; }).join('') + '</select>' : '') +
      '<label>Nom du client</label><input data-bp="client" maxlength="100" list="bpCl_' + sec.id + '" autocomplete="off"/><datalist id="bpCl_' + sec.id + '">' + clientsList().map(function (v) { return '<option value="' + esc(v) + '">'; }).join('') + '</datalist>' +
      '<label>Référence du devis</label><input data-bp="devis" maxlength="60"/>' +
      '<label>Objet de la prestation</label><input data-bp="objet" maxlength="140" placeholder="' + esc(POLES[pole].objet) + '"/>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px"><div><label>Projet / chantier</label><input data-bp="projet" maxlength="80"/></div><div><label>Contact / Tél</label><input data-bp="contact" maxlength="40"/></div></div>' +
      '<div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:6px"><div><label>Montant à payer</label><input data-bp="montant" inputmode="decimal"/></div><div><label>Devise</label><select data-bp="devise"><option value="USD">USD ($)</option><option value="FC">FC</option></select></div><div><label>Date</label><input data-bp="date" type="date"/></div></div>' +
      '<div data-bp="lettres" class="hint" style="margin:4px 0"></div>' +
      '<div class="actions" style="margin-top:8px"><button type="button" class="primary" data-bp="go">🧾 Faire le bon de paiement</button></div>' +
      '<div data-bp="banner" class="msg" style="display:none"></div><div data-bp="result"></div>' +
      '<details style="margin-top:10px"><summary><b>📒 Derniers bons de paiement</b></summary><div data-bp="liste" style="margin-top:6px"></div></details>';
    sec.insertBefore(c, sec.firstChild);
    var q = function (k) { return c.querySelector('[data-bp="' + k + '"]'); };
    q('date').value = today();
    function majL() { var m = num(q('montant').value); q('lettres').textContent = m > 0 ? 'En lettres : ' + lettres(m, q('devise').value) : ''; }
    function liste() {
      var all = rd(KEY).slice().reverse().slice(0, 8), el = q('liste');
      el.innerHTML = all.length ? all.map(function (r) { return '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;border-bottom:1px solid #e4e8ef;padding:5px 0"><span><b>' + esc(r.no) + '</b> · ' + esc(r.client) + ' · ' + esc(fmt(r.montant, r.devise)) + ' · ' + statLib(totaux(r).statut) + '</span><button type="button" class="muted" data-bppdf="' + esc(r.no) + '">📄 PDF</button></div>'; }).join('') : '<p class="hint">Aucun bon pour l’instant.</p>';
    }
    liste();
    c.addEventListener('input', function (e) { if (e.target.getAttribute && /montant|devise/.test(e.target.getAttribute('data-bp') || '')) majL(); });
    c.addEventListener('change', function (e) {
      var k = e.target.getAttribute && e.target.getAttribute('data-bp'); if (k === 'devise') majL();
      if (k === 'devisPick') {
        var f = devis[+e.target.value]; if (!f) return;
        var pr = rd('exb_projects').filter(function (x) { return f.project && x.id === f.project; })[0] || {};
        q('client').value = f.client || ''; q('devis').value = f.no || ''; q('objet').value = f.title || f.label || ''; q('projet').value = pr.name || '';
        if (Number(f.ttc) > 0) q('montant').value = String(f.ttc); q('devise').value = dev(f.cur); majL();
      }
    });
    q('go').onclick = async function () {
      var cl = q('client').value.trim(), m = r2(num(q('montant').value));
      if (!cl) return say2('Indiquez le nom du client.'); if (!(m > 0)) return say2('Indiquez le montant à payer.');
      var all = rd(KEY), date = q('date').value || today(), no = nextNo(all, date);
      var b = { id: no, no: no, date: date, pole: q('pole').value, client: cl, devis: q('devis').value.trim(), objet: q('objet').value.trim(), projet: q('projet').value.trim(), contact: q('contact').value.trim(), montant: m, devise: q('devise').value, paiements: [], statut: 'à payer', paye: 0, reste: m, at: new Date().toISOString() };
      try {
        var blob = await make(b); all.push(b); if (!wr(KEY, all)) return say2('Enregistrement impossible (stockage plein ?). Le bon n’a pas été créé.');
        audit('BON_PAIEMENT_CRÉÉ', no + ' — ' + cl + ' — ' + fmt(m, b.devise));
        say2('✓ Bon n° <b>' + esc(no) + '</b> créé pour ' + esc(cl) + ' · à payer <b>' + esc(fmt(m, b.devise)) + '</b> au guichet.', true);
        q('result').innerHTML = '<div class="actions">' + lien(URL.createObjectURL(blob), no, '📄') + '</div>'; liste();
      } catch (e) { say2('Impossible de faire le PDF : ' + esc(e && e.message || e)); }
    };
    function say2(m, ok) { var e = q('banner'); e.className = 'msg ' + (ok ? 'ok' : 'warn'); e.innerHTML = m; e.style.display = 'block'; }
    q('liste').addEventListener('click', async function (e) {
      var bt = e.target.closest && e.target.closest('[data-bppdf]'); if (!bt) return;
      var r = rd(KEY).filter(function (x) { return x.no === bt.getAttribute('data-bppdf'); })[0]; if (!r) return;
      try { w.open(URL.createObjectURL(await make(JSON.parse(JSON.stringify(r)))), '_blank'); } catch (er) { say2('PDF impossible : ' + esc(er && er.message || er)); }
    });
  }

  /* Carte « Bons de paiement à encaisser » dans le guichet du comptable (Reçus de paiement) */
  function mountGuichet() {
    var sec = $('receipts'); if (!sec || $('exbBpGuichet')) return;
    var c = d.createElement('div'); c.id = 'exbBpGuichet'; c.className = 'card no-print'; c.style.marginBottom = '14px';
    c.innerHTML = '<h2>🧾 Bons de paiement à encaisser</h2>' +
      '<p class="hint" style="margin:0 0 8px">Le client présente son bon (ingénierie, architecture, chantier) : cherchez-le par n° de bon, nom ou projet, puis encaissez. Le reçu est fait, le bon passe à « Payé » et la caisse du guichet est mise à jour.</p>' +
      '<input id="bpgQ" maxlength="60" placeholder="🔎 N° du bon (EXB-BP-…), nom du client, projet…" autocomplete="off"/><label style="display:flex;gap:6px;align-items:center;margin:6px 0"><input type="checkbox" id="bpgAll" style="width:auto"/> Afficher aussi les bons déjà payés</label>' +
      '<div id="bpgList"></div><div id="bpgForm"></div><div id="bpgBanner" class="msg" style="display:none"></div><div id="bpgResult"></div>';
    sec.insertBefore(c, sec.firstChild);
    function norm(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
    function draw() {
      var words = norm($('bpgQ').value).split(/\s+/).filter(Boolean), all = $('bpgAll').checked;
      var L = rd(KEY).slice().reverse().filter(function (b) { var st = totaux(b).statut; if (!all && st === 'payé') return false; var hay = norm([b.no, b.client, b.projet, b.objet, b.devis].join(' ')); return words.every(function (x) { return hay.indexOf(x) >= 0; }); }).slice(0, 15);
      $('bpgList').innerHTML = L.length ? L.map(function (b) { var t = totaux(b); return '<div style="border-bottom:1px solid #e4e8ef;padding:7px 0;display:flex;justify-content:space-between;gap:8px;align-items:center"><span><b>' + esc(b.no) + '</b> · ' + esc(b.client) + '<div class="hint">' + esc((POLES[b.pole] || {}).lib || '') + (b.objet ? ' · ' + esc(b.objet) : '') + ' · ' + esc(fmt(t.total, b.devise)) + (t.paye > 0 ? ' · reste ' + esc(fmt(t.reste, b.devise)) : '') + ' · ' + statLib(t.statut) + '</div></span>' + (t.statut === 'payé' ? '<button type="button" class="muted" data-bpg="pdf" data-no="' + esc(b.no) + '">📄 Bon</button>' : '<button type="button" class="primary" data-bpg="sel" data-no="' + esc(b.no) + '">💵 Encaisser</button>') + '</div>'; }).join('') : '<p class="hint">Aucun bon à encaisser' + (words.length ? ' avec cette recherche' : '') + '.</p>';
    }
    function form(no) {
      var b = rd(KEY).filter(function (x) { return x.no === no; })[0]; if (!b) return; var t = totaux(b), g = ''; try { g = w.localStorage.getItem('EXB_GUICHETIER') || ''; } catch (e) { }
      $('bpgForm').innerHTML = '<div style="border:2px solid #c49a38;border-radius:12px;padding:10px;margin-top:8px"><b>' + esc(b.no) + '</b> — ' + esc(b.client) + '<div class="hint">' + esc(b.objet || '') + ' · Total ' + esc(fmt(t.total, b.devise)) + ' · Reste à payer <b>' + esc(fmt(t.reste, b.devise)) + '</b></div>' +
        '<div class="two"><div><label>Montant encaissé</label><input id="bpgM" inputmode="decimal" value="' + t.reste + '"/></div><div><label>Mode de paiement</label><select id="bpgMode">' + MODES.map(function (m) { return '<option value="' + m[0] + '">' + m[1] + '</option>'; }).join('') + '</select></div></div>' +
        '<label>Référence / n° de transaction (si Mobile Money, banque, chèque)</label><input id="bpgRef" maxlength="80"/><label>Guichetier (personne qui encaisse)</label><input id="bpgG" maxlength="80" value="' + esc(g) + '"/>' +
        '<div class="actions" style="margin-top:8px"><button type="button" class="primary" data-bpg="go" data-no="' + esc(b.no) + '">💵 Encaisser et faire le reçu</button><button type="button" class="muted" data-bpg="cancel">Annuler</button></div></div>';
    }
    $('bpgQ').addEventListener('input', draw); $('bpgAll').addEventListener('change', draw);
    c.addEventListener('click', async function (e) {
      var bt = e.target.closest && e.target.closest('[data-bpg]'); if (!bt) return; var a = bt.getAttribute('data-bpg'), no = bt.getAttribute('data-no');
      if (a === 'sel') { form(no); $('bpgResult').innerHTML = ''; $('bpgBanner').style.display = 'none'; }
      else if (a === 'cancel') $('bpgForm').innerHTML = '';
      else if (a === 'pdf') { var r = rd(KEY).filter(function (x) { return x.no === no; })[0]; if (r) try { w.open(URL.createObjectURL(await make(JSON.parse(JSON.stringify(r)))), '_blank'); } catch (er) { say('bpgBanner', 'PDF impossible : ' + esc(er && er.message || er)); } }
      else if (a === 'go') {
        bt.disabled = true; var gu = $('bpgG').value.trim(); try { if (gu) w.localStorage.setItem('EXB_GUICHETIER', gu); } catch (e2) { }
        try {
          var res = await encaisser(no, { montant: $('bpgM').value, mode: $('bpgMode').value, reference: $('bpgRef').value.trim(), guichetier: gu }), b2 = res.bon, bonBlob = await make(JSON.parse(JSON.stringify(b2)));
          say('bpgBanner', '✓ Encaissé : <b>' + esc(fmt(num($('bpgM').value), b2.devise)) + '</b> de ' + esc(b2.client) + '. Reçu n° <b>' + esc(res.recu_no) + '</b> · bon ' + esc(b2.no) + ' : ' + statLib(totaux(b2).statut) + (res.solde > 0.005 ? ' · reste ' + esc(fmt(res.solde, b2.devise)) : '') + '. ' + (res.caisse === 'ok' ? 'Inscrit en caisse (Comptabilité).' : res.caisse === 'deja' ? 'Déjà inscrit en caisse.' : '⚠ Non inscrit en caisse : à saisir dans Comptabilité.'), true);
          $('bpgResult').innerHTML = '<div class="actions">' + (res.recu ? lien(URL.createObjectURL(res.recu), res.recu_no, '🧾') + ' ' : '') + '<a class="muted" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none" href="' + URL.createObjectURL(bonBlob) + '" target="_blank" rel="noopener">📄 Bon mis à jour</a></div>';
          $('bpgForm').innerHTML = ''; draw(); try { if (w.EXBGuichetCaisse) w.EXBGuichetCaisse(); } catch (e3) { }
        } catch (err) { say('bpgBanner', 'Échec : ' + esc(err && err.message || err)); bt.disabled = false; }
      }
    });
    draw();
  }

  function mountAll(x) {
    try {
      if (x === 'bureauEtudes') { mountCard($('bureauEtudes'), 'ingenierie'); }
      else if (x === 'projets') { mountCard($('projets'), 'chantier'); }
      else if (x === 'metreDevis') { mountCard($('metreDevis'), 'ingenierie'); }
      else if (x === 'etudes3') { mountCard($('etudes3'), 'ingenierie'); }
      else if (x === 'receipts') { mountGuichet(); }
      else if (x === 'architecture' || x === 'architectureEnterprise') { mountCard($(x), 'architecture'); }
    } catch (e) { }
  }
  if (w.document) {
    var _s = w.show;
    if (typeof _s === 'function' && !w.__exbBpShow) { w.__exbBpShow = 1; w.show = function (x) { var r = _s.apply(this, arguments); mountAll(x); return r; }; }
  }
  /* un collègue (autre appareil, autre espace) a créé ou modifié un bon : les listes se réaffichent */
  w.exbReRenderBp = function () {
    try {
      var g = $('exbBpGuichet'); if (g) { var q = $('bpgQ'); if (q) q.dispatchEvent(new Event('input')); }
      d.querySelectorAll('[id^="exbBpCard_"]').forEach(function (c) { var l = c.querySelector('[data-bp="liste"]'); if (!l) return; var all = rd(KEY).slice().reverse().slice(0, 8); l.innerHTML = all.length ? all.map(function (r) { return '<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;border-bottom:1px solid #e4e8ef;padding:5px 0"><span><b>' + esc(r.no) + '</b> · ' + esc(r.client) + ' · ' + esc(fmt(r.montant, r.devise)) + ' · ' + statLib(totaux(r).statut) + '</span><button type="button" class="muted" data-bppdf="' + esc(r.no) + '">📄 PDF</button></div>'; }).join('') : '<p class="hint">Aucun bon pour l’instant.</p>'; });
    } catch (e) { }
  };
  w.EXBBonPaiement = { build: build, make: make, encaisser: encaisser, mount: mountCard, mountGuichet: mountGuichet, nextNo: nextNo, totaux: totaux, lettres: lettres };
  if (typeof module !== 'undefined' && module.exports) module.exports = { build: build, totaux: totaux, nextNo: nextNo };
})(typeof window !== 'undefined' ? window : globalThis, typeof document !== 'undefined' ? document : null);
