# Vérification de la version V167 par rapport au Cahier des charges général unifié V1.0

Version vérifiée : V166e + liens Workflow (V167). Date : 15 novembre 2026.
Légende : ✅ vérifié · 🟡 partiel ou non démontré · ❌ non constaté.
« Vérifié » précise comment : **[exécuté]** test lancé ou écran ouvert dans Chromium · **[code]** lu dans le code · **[mots-clés]** simple recherche, indicative (« non constaté » ≠ « absent à coup sûr »).

## Réponse courte
Le cahier n'est **pas entièrement respecté** : c'est une cible en 9 phases, et la V167 couvre bien le socle, la BI, le Workflow, la comptabilité et la sécurité de base, mais pas encore l'organisation en 5 divisions, le CRM complet, l'isolation serveur des données, ni la validation sur appareils. Aucune fonction n'a été supprimée : la V167 n'ajoute que le module de liens Workflow, son test et sa documentation.

## Ce qui a été exécuté
| Contrôle | Résultat |
|---|---|
| Suites node (`tools/check.js` + 20 `test-*.js`) | 21 / 21 réussies [exécuté] |
| Tests navigateur (`tools/e2e-*.py`, 30) | 18 réussis, **12 en échec — à l'identique sur la V166e d'origine**, donc non causés par la V167 [exécuté] |
| Démarrage de l'application dans Chromium | aucune erreur JavaScript ; 69 écrans, 63 boutons de menu, noyau CORE chargé [exécuté] |
| Liens Workflow dans la V166e | panneau affiché, devis (132 $ = 120 × 1,10) et bon de commande (1 200 $) créent un dossier [exécuté] |

Les 12 échecs préexistants : assistant-approbation, budgetfin, calcul-publier, devis-publier (24/26), guide, liens, marque (nom d'origine dans le PDF de devis), parcours (export DXF du calcul), pilote, plans-publier (13/15), public-sans-config, smoke. Trois échouent dès l'étape « connexion locale » ; cause non diagnostiquée (tests périmés ou régression, à trancher).

## Non exécuté (donc non vérifié)
Données réelles · téléphone / tablette · tests de charge · restauration d'une vraie sauvegarde · isolation serveur (RLS) · résolution de conflits hors ligne · relecture visuelle des PDF · plusieurs utilisateurs simultanés.

## §3 — Les 15 modules
| # | Module | Écran présent | État / ce qui manque |
|---|---|---|---|
| 01 | BI | 📈 BI Direction [exécuté] | 🟡 dictionnaire des indicateurs présent (nom + définition) mais sans source / fréquence / responsable / règle de validation par KPI ; pas de statut de fiabilité par KPI ; tableau non configurable par l'utilisateur |
| 02 | Project Manager | Projets & chantiers, Planning & budget, Pilotage, Contrôles [exécuté] | ✅ présent ; blocage budgétaire via Workflow : règle à décider |
| 03 | Plan Editor | Plan de maison, Plan PDF, Mise en page [exécuté] | ✅ ; DWG = rangement seulement ; e2e « export DXF du calcul » en échec |
| 04 | CRM | Clients, Portails [exécuté] | ❌ pipeline d'opportunités (3 occurrences), versions de devis (0) ; 🟡 relances, réclamations, satisfaction |
| 05 | HR | Personnel & RH [exécuté] | 🟡 compétences liées au dossier, export vers paie validée |
| 06 | Stock & Procurement | Stock, Terrain & achats [exécuté] | 🟡 transferts, inventaires justifiés, demandes d'achat, comparatifs, rapprochement commande/réception/facture : traces partielles |
| 07 | Workflow | ✅ Workflow [exécuté] | ✅ + **liens V167** avec Devis, Achats (BC chantier et commandes ERP), Congés, Certificats ; délégations et rappels présents dans le code |
| 08 | Archives | 🗄 Archives [exécuté] | ✅ ; droits « partager / archiver » non appliqués |
| 09 | TFL & Académie | TFL, Formations, Portail apprenant [exécuté] | ✅ ; deux espaces (formations classiques / TFL) non séparés |
| 10 | Certificats | 📜 Certificats [exécuté] | ✅ ; statut « suspendu », traitement par lot : à confirmer |
| 11 | Server | Données, Synchronisation, Registre [exécuté] | 🟡 pas d'écran de supervision / alertes de disponibilité (état de santé dans CORE seulement) |
| 12 | Licences | pas de section de menu ; écran verrouillé [code] | ✅ (activation 2 appareils, clé privée) |
| 13 | Scanner | 📷 Scanner [exécuté] | 🟡 OCR : fichier présent, moteur non livré selon l'écart existant ; correction de perspective |
| 14 | Administration | ⚙️ Administration [exécuté] | 🟡 sessions / appareils distants, revue périodique des accès (0 occurrence) |
| 15 | Finances & Compta | Finances, Comptabilité, Budget [exécuté] | ✅ avoirs, échéanciers, clôture, verrou ; ❌ écritures de paie ; règles fiscales RDC à valider |

## §1-2 — Divisions et architecture
- 5 divisions dans la navigation : ❌ [exécuté] aucune ne figure dans l'interface.
- EXCELLENCIA CORE : ✅ [exécuté] `EXBCore` expose id, droits, santé, bus d'événements, journal d'audit, modules.
- Identifiant stable pour tout objet : 🟡 [code] existe, non appliqué partout.
- « Aucun module n'écrit dans la base d'un autre » : ❌ [code] accès direct au stockage commun (mon module de liens enveloppe des fonctions publiques mais lit aussi le stockage).
- Environnements séparés, démo séparée de la production : ❌ hors code.

## §4 — Règles métier impératives
| Règle | État |
|---|---|
| Réutilisation des données client / chantier | ✅ [exécuté] tests de liaison tranches 1 à 4 et e2e liaison réussis |
| Devis ≠ paiement | 🟡 [code] le paiement est un objet séparé (`exb_v93_payments`) ; aucun chemin « devis accepté → paiement » constaté, non testé bout en bout |
| Montant devis / facturé / encaissé / reste / dépenses / solde | ✅ [exécuté] BI : facturé, encaissé, dépenses, créances, dettes, résultat, par devise, sans conversion implicite (test-bi 35 contrôles) |
| Pas de double comptabilisation | ✅ pour l'encaissement (registre unique, test-bi) ; 🟡 idempotence ailleurs (6 occurrences) |
| Validation : auteur, date, statut, approbateur, historique | ✅ [exécuté] Workflow (69 contrôles) + journal d'audit chaîné |

## §5-7 — Droits, sécurité, transversal
| Exigence | État |
|---|---|
| Matrice de droits (10 actions) | ✅ [code] `exb-droits-actions.js` ; « partager » et « archiver » non appliqués ; limitation par département / projet / propriété partielle |
| MFA comptes privilégiés | ✅ [code] `exb-mfa.js` |
| Journal d'actions sensibles | ✅ [code] chaîné ; local à l'appareil (500 lignes) |
| Sauvegarde chiffrée, test de restauration, RPO / RTO, intégrité de migration | ✅ [code + tests node] V166c ; copies automatiques internes en clair ; valeurs RPO/RTO à valider |
| Cloisonnement réel des données (RLS) | ❌ côté écran seulement |
| Exports soumis aux droits et journalisés | ✅ [code] point d'entrée unique |
| Responsive ordinateur / tablette / téléphone | 🟡 non testé sur appareils |
| Hors ligne : indicateur de synchro | ✅ [code] `exb-v73-offline.js` ; 🟡 résolution de conflits à confirmer |
| PDF A4 complets et paginés | 🟡 plusieurs e2e PDF réussis (plans, reçus, envoi client), deux en échec (devis) |
| Pagination / filtres côté serveur | 🟡 150 lignes + « Afficher plus » |

## §8-12 — BI/IA, phases, priorités, tests
- BI : règle « pas de chiffre non validé » ❌ (aucun statut de fiabilité affiché). Copilot IA : 🟡 assistants existants, validation humaine à encadrer. KPIGO : ❌ (facultatif selon le cahier).
- Priorités : **P0** ✅ (sauvegarde, sécurité de base, PDF/exports, intégrité) sous réserve des 12 échecs e2e ; **P1** 🟡 (CORE, Workflow, finances faits ; CRM, achats/stocks incomplets) ; **P2** 🟡 ; **P3** ❌/🟡.
- Tests §11 : unitaires ✅ · intégration/e2e 🟡 (12 / 30 en échec) · permissions 🟡 · charge, appareils, hors ligne, PV de recette ❌.
- Décisions du §12 (hébergement, base, utilisateurs, règles fiscales RDC, RPO/RTO, périmètre BI, formats DWG/IFC, hors ligne) : toujours à prendre.

## Liens Workflow ajoutés (V167)
Voir `site/README-V148-WORKFLOW-LIENS.md` (87 contrôles dédiés). Limite connue : la réception en stock d'un BC de chantier n'est pas bloquée, seul son paiement l'est.

## Ordre proposé
1. Comprendre et corriger les 12 échecs e2e (P0) — surtout la connexion locale et le PDF de devis.
2. Organiser le menu en 5 divisions (simple, visible, sans toucher aux modules).
3. CRM : pipeline, versions de devis, relances (P1).
4. BI : statut de fiabilité par KPI et dictionnaire complet (source, fréquence, responsable, règle).
5. Stock / achats : transferts, inventaires, demandes d'achat, rapprochement.
6. RLS serveur et conflits hors ligne (nécessite la décision d'hébergement du §12).
