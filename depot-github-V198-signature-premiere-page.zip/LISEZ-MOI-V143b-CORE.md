# Excellencia Building V143b — Noyau CORE v1

Cette version = V142g + un noyau commun (`exb-core.js`) ajouté sans modifier les modules existants.

## Ce qui change
- **Version unique** : le pied de page et le diagnostic lisent `EXB_BUILD` (V143b) au lieu de « V120 » écrit en dur.
- **`EXBCore`** (console du navigateur) : identifiants stables `EXBCore.id('facture')`, bus d'événements `EXBCore.bus`, journal d'audit chaîné `EXBCore.audit`, contrat de module `EXBCore.modules.register(...)`, droits `EXBCore.can(...)`, santé `EXBCore.health()`.
- Chaque enregistrement du logiciel publie l'événement `data.changed` (lecture seule, la donnée n'est pas modifiée).
- `entreprise.json` : identité **Excellencia Building** (la V142g contenait « Excellencia Démo »). Vérifiez le téléphone, l'adresse et `publicUrl` (vide = adresse du site ouvert).

## Adaptateurs métier (`exb-core-adapters.js`)
Le noyau journalise, pour chaque fiche créée / modifiée / changée de statut / supprimée : devis-factures-reçus (`exb_quotes`), finance projet (`exb_finance`), caisse (`exb_cash`), paiements (`exb_v93_payments`), factures fournisseurs, projets (`exb_projects`, `exb_v93_projects`) et documents de chantier (`exb_pieces`).
Chaque ligne d'audit garde : action, identifiant, type, montant, devise, statut (et ancien → nouveau statut). **Aucun texte libre** (libellés, noms, notes) n'est copié.
Au-delà de 20 changements dans une même écriture (synchronisation, import) : une seule ligne « .lot ».
Limite connue : les fiches reçues d'un collègue par synchronisation sont journalisées comme locales (le noyau ne sait pas encore les distinguer).
Consulter : console du navigateur → `EXBCore.audit.list()` et `EXBCore.audit.verify()`. Il n'y a pas encore d'écran de consultation.
Retirer : supprimer la balise `exb-core-adapters.js` de `index.html`.

## Aucun SQL à exécuter.

## Déployer
1. Exportez une sauvegarde du logiciel actuel.
2. Glissez ce dossier sur Netlify (Deploys).
3. Rouvrez le logiciel (fermez-le complètement si l'ancienne version s'affiche).

## Retirer le noyau
Supprimez la balise `<script src="exb-core.js"></script>` dans `index.html`.

## Vérifié (Chromium, données d'exemple)
10 contrôles du noyau + 12 contrôles des adaptateurs, tous OK : identifiants, bus, journal chaîné (une falsification est détectée), registre de 67 modules, projet créé/modifié, caisse, facture À payer → Payée, document de chantier créé/émis/supprimé, lot de 30 fiches, aucun texte libre copié. Aucune erreur JavaScript de plus que V142g.
Non vérifié : le formulaire Projet lui-même (il exige d'abord un client ; j'ai testé son chemin d'enregistrement exbSave), les écrans réels de factures et reçus, affichage de V143b dans le pied de page après connexion, synchronisation avec votre Supabase réel.
