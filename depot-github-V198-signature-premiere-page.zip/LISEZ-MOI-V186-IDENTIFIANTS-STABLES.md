# V186 — Identifiant stable unique pour tout objet

Base : V185. Point du cahier unifié V1.0 : « Identifiant stable unique pour tout objet » — 🟡 en V185 (EXBCore.id existait, rien ne l'imposait) → ✅ pour les fiches de premier niveau.

## Règle
Toute fiche d'une collection `exb_*` porte un identifiant stable : son champ `id` s'il existe (jamais modifié), sinon un champ `uid` ajouté une fois pour toutes. Aucune donnée n'est supprimée ni renommée.

## Ce qui change
- **exb-core-ids.js** (nouveau), branché sur le point d'écriture commun (`exbStorage.setItem`) :
  1. à chaque écriture, les fiches sans identifiant en reçoivent un ;
  2. un module qui reconstruit une fiche en perdant son `uid` le retrouve par sa référence (no, ref, code, matricule…) ;
  3. une fiche recopiée (`{...x}`) ne garde pas le même `uid` ;
  4. au démarrage (4 s après), balayage unique des fiches existantes, identifiants **déterministes** (même donnée synchronisée → même identifiant sur deux appareils).
- Un `id` en double fourni par un module est **signalé**, jamais corrigé (les liens en dépendent).
- exb-db.js : la synchro réutilise le `uid` comme `id` (une seule identité par fiche).
- exb-core-adapters.js : `uid` passé en dernier dans l'identité suivie (pas de faux « supprimé + créé »).
- sw.js : cache v186 + nouveau fichier.

## Consulter (console du navigateur)
`EXBCore.ids.audit()` (bilan par collection) · `EXBCore.ids.sweep()` (forcer) · `EXBCore.health()` (contient `ids`).

## Limites connues
- Lignes imbriquées dans une fiche (lignes de devis…), tables clé→valeur : hors périmètre.
- Journaux, files, caches, préférences, licence : volontairement exclus (liste SKIP dans le fichier).
- Collections > 1 Mo : traitées par le balayage, pas à chaque écriture.
- Pas d'écran d'audit (console seulement). Pas de contrainte d'unicité côté serveur (Supabase) : à ajouter avec les tests RLS.
- Non testé : données réelles, plusieurs appareils réels.

## Vérifié
tools/test-ids.js (23 contrôles Node), tools/e2e-ids.py (13 contrôles Chromium), check.js (586), e2e-smoke, e2e-parcours, e2e-workflow-v13, e2e-liaison, e2e-cloture, test-workflow, test-liaison, test-compta-etats : 0 échec.

## Complément V186b — l'identité des Paramètres couvre-t-elle tout le logiciel ?
Constat : Paramètres › Identité de l'entreprise alimente écrans, PDF, impressions, noms de fichiers, liens (remplacement automatique dans exb-brand.js). Le test e2e-marque.py (fausse entreprise, 38 pages + toutes les sections + 2 PDF) était déjà à 0 résidu.
**Défaut trouvé** : le remplacement ne s'activait que si le NOM changeait. Si on ne changeait que téléphone / e-mail / direction, les valeurs d'Excellencia réapparaissaient (champs préremplis des Paramètres et de l'affiche, carte de visite, site vitrine, liens WhatsApp : 15 résidus).
Corrigé dans exb-brand.js (`contactChanged`) : 15 → 0 résidu.
Aussi corrigé (textes hors écran qui échappaient au remplacement) : calendrier ICS TFL (PRODID) et titre de partage, invite biométrique Android/WebAuthn, en-tête + titre + nom de fichier des planches de plans (exb-v72.js).
Nouveau test : tools/e2e-marque-contacts.py. Non-régression : e2e-marque, check.js (586), e2e-ids, e2e-tfl (7 suites), plans.
V186c — traité ensuite : « Fait à / Kinshasa, le … » des 8 modèles d'affiches et courriers (ville de l'identité, « … » si vide), cachet de signature « KINSHASA · RDC » (ville + pays de l'identité), valeurs de repli téléphone/e-mail/adresse des affiches et cartes de travail (plus d'Excellencia quand l'entreprise est personnalisée), noms des fichiers de sauvegarde (nom court / nom de l'entreprise ; l'ancien préfixe « Excellencia-sauvegarde- » reste reconnu pour la rotation). Le site vitrine n'avait pas de défaut : ses adresses d'origine ne s'appliquent déjà qu'à l'exemplaire d'origine.
Reste : un téléphone / e-mail volontairement laissé VIDE dans Paramètres n'est pas remplacé (la valeur d'origine pourrait réapparaître dans les textes fixes) ; noms techniques des serveurs (docengine, licences) ; exemples de placeholders. Non testé : impression réelle du cachet et des affiches avec une autre ville (vérifié par les tests e2e d'affiches et d'identité, pas à l'œil).
