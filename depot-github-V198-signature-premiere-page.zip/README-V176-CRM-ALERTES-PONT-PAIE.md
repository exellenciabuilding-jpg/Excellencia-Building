# V176 — CRM : alertes/import/export · Paie : pont « bulletins V81 → écritures » (un salaire, une seule source)

Appliqué sur la V175. **Aucun doublon de module** : le CRM reste celui de la V172 (`exb-crm-plus.js`), la paie comptable reste celle de la V173 (`exb-compta-paie.js`).

## 1. CRM (`exb-crm-plus.js`, additif) — onglet « 🔔 Alertes & export »
- **Alertes** : réclamations sans clôture au-delà du délai (urgente 3 j, normale 7 j — seuils fixes), relances / rendez-vous en retard, clôture prévue dépassée, opportunités ouvertes sans relance planifiée, opportunités inactives depuis plus de 14 jours (un échange terminé compte comme activité).
- **Import** des prospects de l'ancien CRM (`exb_crm`, `exb_v92_crm`) comme opportunités, une seule fois par prospect, sans montant (étapes converties : Visite/Étude → Qualifié, Devis → Devis envoyé…).
- **Export CSV** (opportunités, relances, réclamations, versions de devis ; formules neutralisées).
- Aucune nouvelle clé de stockage ; les données V172 ne sont pas modifiées (hors opportunités ajoutées par l'import). Retrait : retirer l'onglet n'est pas nécessaire, il suffit de ne pas l'ouvrir.

## 2. Paie : pont V81 → comptabilité (`exb-compta-paie-v81.js`, onglet « 💰 Paie V81 »)
Pourquoi : la paie V173 calcule ses bulletins depuis le Personnel avec un impôt à taux unique ; le module Paie V81 (déjà utilisé) calcule le barème IPR progressif, l'INSS, l'INPP et l'ONEM mais n'écrivait rien en comptabilité. Ce pont comptabilise les bulletins **V81 validés ou payés**, sans rien recalculer.
**Règle unique appliquée à chaque écriture, quel que soit l'ordre de saisie** : un bulletin V81 n'est comptabilisé que si la paie V173 n'a pas déjà validé ou payé **ce même employé pour ce même mois**.
Parcours couverts (tous testés) : A) V81 seul ; B) la V173 valide ensuite le même employé → le bulletin V81 et ses règlements sortent du journal ; C) mois mixte (employés différents) → chacun compté une fois ; D) brouillon V173 → rien de bloqué ; run V173 sans détail → mois entier considéré couvert (prudence) ; E) activation alors que la V173 existe déjà ; F) sorties de caisse déjà portées par la V173 (`paie_run`) → jamais proposées ni rapprochables ; G) avances (écran « ＋ Avance versée », direct ou rapprochée d'une sortie de caisse : débit 425).
Écriture d'un bulletin (journal OD, fin du mois) : D 661 brut + D 664 charges patronales (INSS patronal + INPP + ONEM) / C 421 net, C 431 organismes sociaux, C 447 IPR, C 425 avances, C 428 retenues. Règlements : direct (D 421 / C 571 ou 521) ou rapprochement d'une sortie de caisse (reclassement D 421 / C sa charge : pas de double charge).
**Désactivé par défaut** ; tant qu'il l'est, le journal est identique à la V175 (testé). Activation refusée si le mois choisi (ou un suivant) est déjà clôturé.
Modification de `exb-compta.js` : une seule ligne (export de `depAcc` dans `_x`).

## À valider avec votre comptable
Comptes (indicatifs), regroupement INSS/INPP/ONEM dans 431, pas de provision de congés, salaires en USD. Un bulletin V81 retiré du journal parce que la V173 le couvre dans un mois déjà clôturé ferait apparaître ce mois « modifié » à la vérification de clôture.

## Vérifié
`tools/test-crm-plus-v176.js` : 18 contrôles. `tools/test-compta-paie-v81.js` : 59 contrôles (la paie V173 chargée en même temps). `tools/check.js` : 581/581. Chromium sur la V175 : 0 erreur JS, onglets V173 intacts, import avec nom piégé échappé.
## Non vérifié
Données réelles, téléphone, impression.
