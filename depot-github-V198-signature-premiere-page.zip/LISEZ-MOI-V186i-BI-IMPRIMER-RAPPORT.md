# V186i — « Imprimer » imprime le document (pas l'écran), directement à l'imprimante Windows, dans tout le logiciel

Base : V186h. **Aucun SQL.** Fichiers modifiés : `site/exb-bi.js`, `site/exb-print.js`, `site/exb-rapport-marque.js`, `site/exb-metre.js`, `site/sw.js`, `site/exb-core.js` (« V186i-CORE »), `site/tools/check.js`. Nouveaux tests : `site/tools/e2e-bi-imprimer.py`, `site/tools/e2e-imprimer-partout.py`.

## Le problème (constaté sur vos photos)
Dans Excellencia BI — Direction, « 🖨 Imprimer » copiait l'écran du logiciel (boutons Personnaliser / Export Excel, menus, onglets), alors que « 📄 Rapport de direction (PDF) » produisait le vrai document.

## Ce qui change
- **« 🖨 Imprimer »** construit le même document que le Rapport de direction (en-tête société, alertes, indicateurs, projets, activité des modules, historique, QR de vérification) et l'envoie **directement à l'impression Windows** (choix de l'imprimante : réelle ou Microsoft Print to PDF). Si l'impression directe est impossible, il enregistre le PDF à la place.
- **« 📄 Rapport de direction (PDF) »** : inchangé (PDF enregistré puis ouvert).
- Hors Windows (navigateur, Android) : « Imprimer » ouvre le même document avec l'impression du système.
- Nouvelle option réutilisable : `EXBPrint.html(titre, doc, {print:true})` / `EXBRapport.print(titre, {imprimer:true})` = envoi direct à l'imprimante.

## Limites
- Seul le bouton Imprimer de la BI est converti. Les autres écrans qui impriment « l'écran courant » (ex. Ctrl+P sur un écran du logiciel) gardent le comportement actuel ; à convertir module par module, sur indication.
- La boîte Windows reste sans aperçu (limite de Windows) ; le PDF permet de voir avant d'imprimer.
- Non vérifié sous Windows réel avec une vraie imprimante. Vérifié dans Chromium avec une simulation de l'application Windows.
- Refaire l'installateur Windows (rien de nouveau côté `electron/` par rapport à V186h, mais il faut V186h + V186i ensemble).

## Contrôles
`node site/tools/check.js` : 615 réussis, 0 échec · `e2e-bi-imprimer.py` (6/6), `e2e-bi-modules.py`, `e2e-pieces-sans-chantier.py` : OK.

## Extension à tout le logiciel (Windows)
- **Règle générale** (exb-print.js, valable pour tous les modules qui impriment via le moteur commun : paiements, cartes de travail, plans, QR, QCM, rapports, étiquettes, etc.) :
  - un bouton dont le nom dit **« Imprimer »** (ou la seule icône 🖨), sans « PDF » ni « Enregistrer » → envoi **direct à l'imprimante Windows** ;
  - un bouton **« PDF »**, **« Imprimer / PDF »**, « Rapport PDF »… → **PDF enregistré** puis ouvert (comme avant) ;
  - un appel du logiciel sans clic sur un bouton « Imprimer » → PDF (comportement habituel).
- **Métré / Devis rapide** (impression depuis l'écran) : « Imprimer » part directement à l'imprimante, sans la question « PDF ou imprimer ? ».
- Si l'impression directe échoue, le logiciel enregistre le PDF à la place.

## Limites supplémentaires
- Les modules qui fabriquent eux-mêmes un PDF (ex. le moteur documentaire du serveur) ou qui tournent dans un cadre à part (éditeur de plans, calcul de structure) gardent leur propre chemin ; à convertir au besoin, un par un.
- Ctrl+P sur un écran du logiciel garde le choix « PDF ou imprimer ? » (il imprime ce qui est à l'écran).
- Non vérifié sous Windows réel avec une vraie imprimante.

## Contrôles (mise à jour)
`node site/tools/check.js` : 618 réussis, 0 échec · `e2e-imprimer-partout.py` (8/8), `e2e-bi-imprimer.py`, `e2e-bi-modules.py`, `e2e-pieces-sans-chantier.py`, `e2e-devis-paiement.py`, `e2e-paiements-listes.py` : OK.
