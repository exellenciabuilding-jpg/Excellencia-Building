# V184 — Menu en 5 divisions + correctifs, appliqués sur le dépôt V182

Base : depot-github-V182-workflow-v1_3. Résultat : tests navigateur 33 / 33, suites node 26 / 26.

## Ajouté
- **Menu en 5 divisions** (cahier unifié V1.0, §1), regroupement d'affichage : Direction & pilotage · Ingénierie et construction · Gestion & finances · Formation & académie · Infrastructure numérique. Aucun module modifié ; les 10 catégories d'origine restent dans le menu. Chaque écran appartient à une seule division (`DIV_ITEM` dans `site/exb-v99r-shell.js`). Parcours Construction / Formation, Retour / Avant : conservés.
- Nouveau test `site/tools/e2e-divisions.py`. Captures : dossier `captures/`.
- `site/sw.js` : version de cache « v184-divisions-… » (fermer complètement l'application une fois après déploiement).

## Reporté depuis la V168 (déjà présent dans la V182, fusionné sans conflit)
- Utilitaire `site/tools/_exbui.py` et adaptation des tests aux boîtes intégrées EXBUI (V144e) ; tests marque / public-sans-config / plans-publier / guide mis à jour.
- Correctifs de l'application : `plan.html` et `plan-cartouche/index.html` chargent `exb-brand.js` ; `calcul-structure/exb-calcul-doc.js` reconnaît le cartouche sous le nom de marque de l'entreprise (`isBrandMark`).

## Ajusté sur cette base
- `site/tools/e2e-marque.py` : simule aussi `site-vitrine/config.json` (réglage propre à chaque entreprise, dont `logiciel_url`). Sans cela, les liens de la vitrine gardent l'adresse d'Excellencia : pour une autre entreprise, éditer ce fichier.

- `site/tools/e2e-parcours.py` : attend la création du bandeau « Envoyer vers Plans » avant de lire son style (échec intermittent). `site/tools/e2e-devis-publier.py` : attente du QR portée de 20 à 45 s (échec intermittent sous charge). Aucun changement de l'application.

## Non vérifié
Téléphone / tablette, données réelles, plusieurs utilisateurs, restauration d'une vraie sauvegarde. L'étiquette de pied de page « V166c-CORE » (`site/exb-core.js`) n'a pas été modifiée.
