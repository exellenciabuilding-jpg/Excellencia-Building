# V193 — Reçu de paiement des frais (étudiants TFL) au format du modèle fourni

Base : V192. **Aucun SQL.** Nouveau fichier : `site/exb-recu-tfl.js` (gabarit commun). Fichiers modifiés : `site/tfl-portail.html` (espace étudiant), `site/exb-tfl.js` (écran administrateur), `site/index.html`, `site/sw.js` (V193, mise en cache hors connexion), `site/exb-core.js` (« V193-CORE »), `site/tools/check.js`, `site/tools/test-tfl/test-bloc5.js`. Nouveau test : `site/tools/e2e-recu-tfl-modele.py`.

## Ce qui change
Le bouton **🧾 Reçu** de l'espace étudiant TFL (téléchargement PDF, comme d'habitude) produit maintenant le reçu au format « carte paysage » du modèle : double cadre, filigrane EXCELLENCIA en diagonale, logo, photo de l'étudiant, titre « REÇU DE PAIEMENT DES FRAIS », champs à gauche, **Reçu N° + date + QR de vérification + code en cases** à droite, **Année académique / Motif / Montant en rouge**, Opérateur, cases de signature « Etudiant » / « Guichetier » (cachet + signature du Directeur posés si publiés). Une seule page A4 paysage. L'administration imprime le **même** reçu depuis son écran.

## Correspondance avec le modèle
| Modèle | Reçu Excellencia |
|---|---|
| Étudiant, Matricule | nom, matricule du dossier |
| Faculté / Département / Promotion | faculté, filière, promotion de la fiche étudiante |
| Sexe | affiché seulement s'il est renseigné (le dossier TFL ne le contient pas) |
| Payé le / Banque / No. Transaction | date de paiement / moyen de paiement / référence déclarée |
| Reçu N°, Date, QR, code | n° et date de délivrance, QR de vérification (même format que les autres documents), 10 premiers caractères du code |
| Année académique, Motif, Montant | année de la fiche, intitulé des frais, **montant réellement confirmé** |
| Opérateur | « Administration Excellencia Building » |

## À savoir
- **Opérateur** : le serveur n'enregistre pas le nom de la personne qui confirme le paiement ; le reçu porte donc le nom de l'administration. Pour afficher le nom du guichetier, il faudrait une colonne en base (SQL) : à décider.
- **Banque** : seul le moyen de paiement est enregistré (banque, mobile money, caisse), pas le nom de la banque.
- **Photo** : celle que l'étudiant ajoute dans son espace (« Ajouter ma photo ») ; elle est conservée jusqu'à sa déconnexion. Sans photo : cadre vide. L'écran administrateur n'a pas la photo.
- **Cachet + signature** : lus depuis le visa publié (Site vitrine › Publier). Rien de publié : case vide, jamais de faux cachet.
- Si le gabarit ne se charge pas, l'ancienne page simple du reçu reste le repli.
- Le reçu d'inscription / formation de l'espace apprenant (hors TFL) n'est pas modifié.

## Vérification des modifications précédentes dans la V192
V186h (pièces sans chantier, impression par copie propre) et V186i (« Imprimer » = document, direct à l'imprimante Windows, dans tout le logiciel) **sont bien intégrées** dans la V192 : marqueurs présents dans `exb-v81-pieces.js`, `exb-print.js`, `exb-bi.js`, `exb-metre.js`, `exb-rapport-marque.js`, `electron/main.js`, `electron/preload.js` ; leurs tests passent sur la V192.

## Contrôles
`node site/tools/check.js` : 625 réussis, 0 échec · `e2e-recu-tfl-modele.py` (14/14), `e2e-imprimer-partout.py`, `e2e-bi-imprimer.py`, `e2e-pieces-sans-chantier.py`, `e2e-affiches-excellencia.py` : OK · `node site/tools/test-tfl/test-bloc5.js` : tout OK (ce test échouait déjà sur la V192 d'origine : il attendait l'ancienne ouverture de fenêtre ; il est remis à jour et passe maintenant par le nouveau reçu).

## Limites
Rendu vérifié dans Chromium (PDF 1 page A4 paysage). Non vérifié avec une vraie imprimante ni sous Windows réel / Android. Refaire l'installateur Windows pour embarquer la V193.
