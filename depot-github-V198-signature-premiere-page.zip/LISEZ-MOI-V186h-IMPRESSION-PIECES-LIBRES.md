# V186h — Impression Windows (page blanche) et pièces écrites sans chantier

Base : V186g. **Aucun SQL.** Fichiers modifiés : `site/exb-v81-pieces.js`, `electron/main.js`, `electron/preload.js`, `site/sw.js`, `site/exb-core.js` (« V186h-CORE »), `site/tools/check.js`. Nouveau test : `site/tools/e2e-pieces-sans-chantier.py`.

## 1. Pièces écrites : un courrier n'est plus obligatoirement lié à un chantier
- Le sélecteur de la liste propose **« ✉️ Sans chantier (courriers libres) »** en premier choix.
- Dans chaque pièce, nouveau champ **« Chantier / projet (facultatif) »** : on peut rattacher une pièce à un chantier, ou la détacher.
- Sans chantier : le titre n'a plus de nom de chantier, la lettre vierge n'a plus la ligne « Réf. projet », et le document imprimé ne porte aucune mention « Projet : ».
- Les modèles contiennent des champs {{projet}}, {{lieu}}, {{client}}… : sans chantier, ces champs restent à compléter à la main (« ____ ») ; ils ne sont plus remplis par un chantier.
- Les pièces déjà créées ne changent pas.

## 2. Impression sous Windows : fin de la page blanche (bouton « Imprimer (boîte Windows) », Ctrl+P)
- Cause : ce choix imprimait l'écran de l'application elle-même, dont les feuilles « impression » masquent l'interface → page blanche.
- Maintenant : le logiciel imprime la **copie propre du document** (même méthode que le PDF) dans une fenêtre cachée, puis ouvre la boîte d'impression Windows. Si cela échoue, il bascule tout seul sur « Enregistrer en PDF ». Une copie vide est détectée et journalisée dans `exb-print.log`.
- Le chemin « Enregistrer en PDF » n'est pas modifié.

## À faire de votre côté
Refaire l'installateur Windows (les fichiers `electron/main.js` et `preload.js` changent).

## Limites
- Non vérifié sous Windows réel ni avec une vraie imprimante (pas de Windows ici). Si la page reste blanche : ouvrir `exb-print.log` (dossier de données de l'application) et indiquer sur quel bouton/écran cela arrive.
- Vérifié dans Chromium : pièce sans chantier (création, titre, aperçu, enregistrement). Le rattachement/détachement à un chantier n'a pas pu être exercé faute de projet dans le jeu d'essai.

## Contrôles
`node site/tools/check.js` : 612 réussis, 0 échec · `e2e-pieces-sans-chantier.py`, `e2e-affiches-excellencia.py`, `e2e-affiches-word.py` : OK.
