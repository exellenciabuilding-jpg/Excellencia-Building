# V173 — Paie, bilan complet (Finances) et tableau de bord adaptatif (BI)

## Finances & comptabilité — `exb-compta-paie.js` (3 nouveaux onglets dans 📒 Compta)
- **👥 Paie** : paramètres (CNSS salarié %, CNSS patronale %, impôt sur salaire %, devise) — **0 par défaut, aucun taux légal imposé** : à valider avec la législation locale et votre comptable. L'impôt est un taux unique sur (brut − CNSS salarié), **pas le barème progressif de l'IPR**.
  Préparer la paie du mois depuis le Personnel (fiche approuvée, statut ≠ sorti/suspendu, salaire > 0) → primes et retenues/avances modifiables en brouillon → **Valider** (écritures : D 661 brut + D 664 CNSS patronale / C 421 net, C 431 cotisations, C 447 impôt, C 425 avances) → **Payer** (sortie de caisse liée, portée au compte 421 : jamais comptée deux fois en charge). Une paie payée ne s'annule pas ; mois clôturé = refus ; export CSV.
- **🏛 Bilan complet** : actif (immobilisations nettes d'amortissements, stocks, créances, trésorerie), passif (capitaux propres + résultat, dettes financières, dettes, trésorerie négative), contrôle actif = passif, cumul à une date, par devise, export CSV.
- **🧱 Ouverture & immos** : écritures d'ouverture / opérations diverses équilibrées (capital, emprunts, soldes antérieurs…), immobilisations (amortissement linéaire mensuel calculé ; acquisition : déjà en ouverture / espèces / banque / reclassement d'une charge), valorisation de stock (valeur déclarée → variation de stock).
- Modification d'`exb-compta.js` : une sortie de caisse portant `paie_run` est portée au compte 421 (au lieu d'une charge).
- **Limites** : non certifié, ni déclaration fiscale/sociale ; pas de bulletin imprimable ; pas de cession d'immobilisation ; cumul depuis le début (pas de clôture d'exercice avec report à nouveau automatique : à faire par écriture diverse).
- Avertissement : ne ressaisissez pas dans « Ouverture » des factures/paiements déjà dans l'application.

## BI — `exb-bi.js` (V7 → adaptatif)
Mode **« Adapter automatiquement aux données »** (activé par défaut, case dans ⚙ Personnaliser) : indicateurs à zéro masqués (Facturé et Encaissé restent), graphique mensuel masqué s'il est vide, section Projets masquée s'il n'y en a pas, et si la période choisie ne contient aucun flux (facturé/encaissé/dépensé) alors que des données existent, affichage **depuis le début** avec un bandeau d'information (préférence de période inchangée). Les alertes ne sont jamais masquées.

Clés ajoutées : exb_paie_cfg, exb_paie_runs, exb_od, exb_immo, exb_stock_val. Tests Chromium : paie (calculs, refus, double paiement, verrou de mois clos), journal équilibré, bilan actif = passif, BI adaptatif ; 0 erreur JS.
