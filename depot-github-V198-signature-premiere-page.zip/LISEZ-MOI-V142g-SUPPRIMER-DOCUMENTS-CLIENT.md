# V142g (V142f corrigée) — Supprimer les documents envoyés à l'espace client (libérer de l'espace Supabase)

## Ce qui change
Portails & signatures › portail client › **📋 Documents envoyés** :
- chaque ligne affiche sa taille et un bouton **🗑** : supprime le document de l'espace du client (confirmation demandée, irréversible) ;
- en haut : nombre de documents et espace utilisé sur Supabase ;
- **🧹 Supprimer les anciennes versions** : garde la dernière version de chaque document (même type + même titre), supprime les autres.
La liste se rafraîchit après chaque suppression.

La confirmation de suppression utilise maintenant la boîte intégrée au logiciel (plus de message d'erreur parasite « Cette action n'a pas pu aboutir »).

## Conditions
Aucun nouveau SQL : la fonction `client_plan_retirer` existe déjà (migration `migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql`). Droit « portails » en écriture, connexion au compte en ligne.

## Fichiers
`site/exb-v99zy-portails.js`, `site/sw.js` (cache v160).

## Déploiement
Redéployer `site` sur Netlify, rouvrir le logiciel.

## Vérifié / limites
- `node tools/check.js` : 557 contrôles réussis, 0 échec ; logique de tri des anciennes versions testée sous Node.
- Non testé avec votre vrai Supabase ni sur téléphone.
- Les documents sont stockés dans la table `client_plans` : l'espace affiché dans Supabase peut mettre un moment à baisser après suppression.
- Le message « document disponible » déjà envoyé au client reste dans sa messagerie.
