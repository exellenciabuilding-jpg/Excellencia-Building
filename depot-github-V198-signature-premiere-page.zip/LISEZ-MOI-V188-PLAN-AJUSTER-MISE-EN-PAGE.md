# V188 — Éditeur de plan : ajuster le plan importé + mise en page de la feuille

## 1. Ajuster le plan importé (panneau de droite › Fond de plan › « 🧭 Ajuster le plan importé »)
Accès rapide : ruban **Importer › 🧭 Ajuster le plan…**
- **Position X / Y** et **largeur × hauteur** (en mètres, saisie exacte). Le redimensionnement garde le centre du fond.
- **🔍 Cadrer la vue** (zoom sur le fond, ne modifie rien) · **◎ Centrer sur le dessin** · **⌖ Origine (0 ; 0)**.
- **↺ / ↻ 90°**, **Redresser** (angle libre ±45°, ex. 0,5° pour une photo ou un scan penché), **⇋ / ⇅ Miroir**.
- **✂ Rogner** (% gauche / haut / droite / bas) pour retirer marges et cartouche d’origine.
- **Verrouiller le fond** : empêche tout déplacement ou recalage accidentel.
- Rotation, miroir et rognage sont appliqués à l’image du fond, l’échelle calée est conservée, et tout s’annule / se rétablit avec **Ctrl+Z / Ctrl+Y** (image comprise).

## 2. Mise en page de la feuille (panneau de droite › « 📐 Mise en page de la feuille »)
Accès rapide : ruban **Mise en page › 📐 Feuille / cadrage…**
- Format (A3 / A4) et échelle d’impression (mêmes réglages que le cartouche).
- **Remplissage de la zone de dessin** (100 % à 60 %) : laisse plus ou moins de marge autour du plan.
- **Décaler le plan** vers la droite / le bas (en mm) — s’applique aux plans, façades et coupes.
- **Imprimer le fond importé** (non par défaut) : le fond est imprimé sur le niveau affiché, avec l’opacité réglée ; l’échelle automatique en tient compte.
- **Aperçu schématique** de la feuille (zone de dessin, cartouche, légende, plan) ; le plan passe en rouge s’il dépasse.
- Boutons **Recentrer**, **PDF**, **Imprimer**. Réglages enregistrés avec le plan.

## Fichiers modifiés
`plan-editeur/index.html`, `sw.js` (version du cache). Recharger l’application après mise à jour.

## Vérifié / non vérifié
Testé dans Chromium (sans affichage) : chargement d’un fond, largeur, rotation 90°, miroir, rognage, redressage, 4 annulations successives, verrouillage, recentrage, réglages de feuille et contrôle de l’image imprimée (décalage de 40 mm = 302 px, remplissage réduit, fond imprimé seulement sur demande). Aucune erreur JavaScript de la page.
Non testé : appareil Android / Windows réel, PDF direct de l’application Windows, impression papier.
