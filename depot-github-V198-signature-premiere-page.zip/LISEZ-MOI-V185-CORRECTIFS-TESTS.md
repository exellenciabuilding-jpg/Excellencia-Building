# V185 — Correctifs issus de la passe complète de tests Chromium

Base : V184 (divisions). Passe complète : 94 suites (33 e2e navigateur + sous-dossiers BIM/flux/mémoire/plans/synchro/TFL + Node + licences + check.js 585 contrôles) → 0 échec.

## Défaut corrigé dans le logiciel
- exb-memoire.js (mémoire du travail) :
  - un nouveau wrapper de show() était ré-empilé toutes les 3 s (coût croissant à chaque changement d'écran : 6 → 22 balayages en 30 s) → un seul wrapper désormais (4 → 4) ;
  - après rechargement, le brouillon de la page rouverte n'était pas restauré → restauration lancée explicitement à la réouverture.
- sw.js : nom de cache v185 pour que les clients reçoivent le correctif.

## Tests corrigés (le logiciel était correct)
- e2e-parcours, tests/test-onglets-v180 et v181 : l'application était affichée sans session ouverte, le verrouillage automatique rechargeait la page (instabilité). Session simulée.
- test-auto-devis : ancien libellé « murs détectés » (le message est « N murs (≈ … m) »).
- BIM, flux, mémoire, plans, TFL (contributions, en-ligne, banque, biblio) : adaptation aux boîtes EXBUI, aux liens vers l'adresse publique (exbBase), à la majuscule automatique, au dernier onglet mémorisé, aux confirmations asynchrones. _exbui.py : exbui_script() (API asynchrone) et file window.__exbuiNext.

## Non exécutés ici
- docengine-server/tests (engine, supabase-mock) : nécessitent « npm install » (pdfjs-dist), réseau coupé dans cet environnement.
- tests/run1.js, run2.js : scripts manuels (fichier plan_a1.pdf / serveur :8099 externes), pas des tests.
- tools/controle-client.js : contrôle de livraison pour un autre client, non applicable à votre version.
- Toujours pas testé : téléphone/tablette réels, données réelles, plusieurs utilisateurs.
