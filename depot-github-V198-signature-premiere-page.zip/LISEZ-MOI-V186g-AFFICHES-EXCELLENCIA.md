# V186g — Éditeur Word et raccourcis aussi sur les Affiches Excellencia

Base : V186f. **Aucun SQL.** Nouveau fichier : `site/exb-v186g-affiches-excellencia.js`. Fichiers modifiés : `site/exb-v186d-affiches-word.js` (accepte une passerelle personnalisée), `site/index.html` (balise script), `site/sw.js` (cache), `site/exb-core.js` (« V186g-CORE »), `site/tools/check.js`. Nouveau test : `site/tools/e2e-affiches-excellencia.py`.

## Ce que vous pouvez faire (Affiches › Affiches Excellencia : affiche générale et affiche « logiciels »)
- **✍️ Word** à côté de chaque champ de texte : ouvre le vrai éditeur Word (polices, tailles, couleurs, gras/italique, alignements, listes…). Le texte mis en forme s'affiche dans l'aperçu et dans les exports **PNG / PDF**, et il est **enregistré** (il revient à la réouverture).
- **Double-clic sur un texte de l'aperçu** : ouvre le même éditeur sur ce texte.
- **Ctrl+S** enregistre les deux affiches (et, dans l'éditeur Word, applique le texte). **Ctrl+Z / Ctrl+Y** annulent / rétablissent les modifications faites avec Word ; dans un champ de saisie, Ctrl+Z annule la frappe comme d'habitude.
- « Texte simple » (à côté du champ) retire la mise en forme. Quand un texte est mis en forme, son champ est en lecture seule (la version simple y reste).

## Comment ça marche
- Le texte mis en forme est stocké à part (clé `exb_poster_rt`) ; le champ garde la version simple, donc les affiches enregistrées avant cette version fonctionnent comme avant. Si on retire le nouveau fichier, tout s'affiche en texte simple.
- Les tailles sont proportionnelles à la taille du texte de l'affiche (taille « 11 » = taille actuelle ; 22 = deux fois plus grand).

## Limites connues
- Les zones composées restent en texte simple : le nom « Excellencia Building » (deux couleurs) et les trois cartes de programme de l'affiche logiciels (listes de points), ainsi que les lignes « Durée » et « Lieu ».
- Les zones de l'affiche ont une taille fixe : un texte beaucoup plus grand ou plus long peut déborder de sa zone.
- Non vérifié : clavier tactile Android, Windows (Electron) réel, impression papier.

## Contrôles
`node site/tools/check.js` : 607 réussis, 0 échec · `e2e-affiches-excellencia.py` : 16/16 · `e2e-affiches-multi.py`, `e2e-affiches-clavier.py`, `e2e-affiches-word.py`, `e2e-affiches.py` : OK.
