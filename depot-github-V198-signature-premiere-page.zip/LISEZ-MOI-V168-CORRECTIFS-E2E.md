# V168 — Résolution des 12 échecs des tests navigateur (base V167)

Résultat : tests navigateur 30 / 30 réussis, suites node 21 / 21 réussies.

## Défauts réels de l'application corrigés
- `site/plan.html`, `site/plan-cartouche/index.html` : ne chargeaient pas `brand-config.js` / `exb-brand.js` -> le nom d'origine restait affiché en marque blanche. Les deux scripts sont ajoutés.
- `site/calcul-structure/exb-calcul-doc.js` : le plan d'exécution n'était plus reconnu (donc pas de bouton « Publier — QR / lien client ») dès que le cartouche affichait le nom court de l'entreprise au lieu de « EXCELLENCIA ». Nouveau détecteur `isBrandMark()`.
- `site/sw.js` : nouvelle version de cache (fermer complètement l'application une fois après déploiement).

## Tests périmés mis à jour (l'application était correcte)
- Depuis la V144e, confirm()/prompt() sont des boîtes intégrées (EXBUI) : `page.on('dialog')` ne les voyait plus et la boîte « changer le mot de passe » bloquait la connexion locale (smoke, guide, liens, pilote, budgetfin, assistant-approbation, parcours, devis-publier, plans-publier). Nouvel utilitaire `tools/_exbui.py`.
- e2e-marque : la fausse entreprise est servie via `entreprise.json` (qui prime sur localStorage).
- e2e-public-sans-config : l'écran de configuration n'existe que sans `entreprise.json`.
- e2e-plans-publier : deux boutons `.exbPubBtn` (🌐 et 🏗️ depuis V141r).
- e2e-guide : section « générateur de licences » ignorée (exb-generator.html retiré du site client, V120n/V120q).

## Non vérifié
Téléphone / tablette, données réelles, plusieurs utilisateurs, restauration d'une vraie sauvegarde. Les e2e parallèles peuvent échouer par délai : les lancer 1 ou 2 à la fois.
