# V192 — Signature + cachet du Directeur sur les documents à signer

Cause : les pièces écrites ne posaient la signature et le cachet que si l'état était « émis » ou « signé » (nouvelle pièce = « brouillon » → espace vide). Le reçu d'inscription de l'apprenant n'avait qu'un texte « Signature / Sceau autorisé », et le contrat de travail aucun visa.

## Corrigé
- **Pièces écrites** (lettres, CCTP, PV, attestations, contrats, notices, visas, dossier de chantier, éditeur Word…) : case « Apposer signature et cachet » (cochée par défaut) à côté du choix « Signature du PDF ». La signature + le cachet sont posés dans le PDF, quel que soit l'état ; décochez pour une version à signer à la main. L'aperçu 👁 montre aussi le bloc de signature.
- **Reçu d'inscription / formation** (espace apprenant, PDF identique au logiciel) : signature + cachet réels à la place du texte.
- **Contrat de travail** (Paie) : cachet + signature de l'employeur au-dessus de « L'employeur ».

## À savoir
La signature et le cachet viennent de « Logo Excellencia Building » (réglages de signature de l'administrateur, enregistrés sur CET appareil) ou, sinon, du visa publié (Site vitrine › Publier). Si rien n'est configuré/publié, aucun visa ne peut s'afficher.

Fichiers : exb-v81-pieces.js, exb-recu-inscription.js, exb-v81-paie.js, sw.js.
