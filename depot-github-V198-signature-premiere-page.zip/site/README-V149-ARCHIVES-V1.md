# Excellencia Archives (v2 — module complet)

> **v2 (V150)** : modification des métadonnées, dépôt par lot, archivage automatique des PDF générés, suppression anticipée soumise au Workflow, API `EXBAR.edit` / `EXBAR.remove`. Le texte ci-dessous décrit la v1, toujours valable ; les ajouts sont dans la section « Ajouts v2 ».

Module 08 du cahier des charges ERP. Menu : **🗄 Archives** (à côté de « ✅ Workflow »). Aucun SQL. Aucun autre module n'est modifié.
Fichiers : `exb-archives.js` (nouveau), balise ajoutée dans `index.html` après `exb-workflow-liens.js`, précache `sw.js` (version `v149-archives-v1`), `tools/test-archives.js`.
Retrait : supprimer `<script src="exb-archives.js">` dans `index.html` (les données restent dans `exb_ar_*`).

## Ce que fait le module (exigences de la fiche 08)
| Exigence du cahier | Dans la v1 |
|---|---|
| Classement par projet, client, service, type et période | Onglet **Classement** (regroupement par l'un des cinq critères) + filtres de la Bibliothèque. Projet et client : saisie libre avec suggestions tirées des modules Projets / Clients. |
| Métadonnées, mots-clés, recherche et filtres | Titre, type (11), projet, client, service, description, mots-clés. Recherche : tous les mots doivent correspondre (accents et casse ignorés) sur n°, titre, projet, client, type, service, description, mots-clés, nom de fichier. Filtres : type, service, projet, client, statut, période de dépôt. |
| Versionnement | Nouvelle version (note facultative), **empreinte SHA-256** par version, restauration = nouvelle version (l'historique n'est jamais réécrit). |
| Aperçu | PDF, images, texte ; sinon message (téléchargement si autorisé). |
| Droits de téléchargement, partage limité | Par document : accès « tous (lecture) » ou « restreint » ; téléchargement autorisé ou restreint ; partages par **nom** ou **fonction** (« fonction: Directeur général »), avec ou sans téléchargement, avec date de fin facultative. Propriétaire et administrateur : tous les droits. |
| Archivage, conservation, historique | Archiver / désarchiver (motif obligatoire au désarchivage) ; un document archivé n'accepte ni nouvelle version ni restauration. Durée de conservation en années → échéance (en cours / proche < 90 j / échue). Historique horodaté en ajout seul dans chaque fiche + une ligne dans le **journal d'audit chaîné du noyau CORE** à chaque action (dépôt, version, consultation, téléchargement, droits, partage, archivage, suppression). |
| Suppression autorisée | Motif obligatoire. Conservation non échue : **administrateur seul** (confirmation, marquée « forcée » dans la trace). Conservation échue ou non définie : propriétaire ou administrateur. Trace des suppressions conservée (`exb_ar_supprimes`, 500 dernières). Aucune suppression automatique. |
| Interconnexions | API pour Scanner, Plan Editor, Project Manager… : `EXBAR.add({fichier, nom, titre, type, projet, client, service, motsCles, conservationAns, source:{module,id}})`, `EXBAR.newVersion(id, fichier, note)`, `EXBAR.list()`, `EXBAR.find(id)`, `EXBAR.stats()`, `EXBAR.fetch(id, version, 'voir'|'telecharger')`. Événements du bus CORE : `archives.depose / .version / .archive / .desarchive / .restaure / .droits / .partage / .supprime`. **Pas encore branché** dans Scanner, Plan Editor, Project Manager (voir « Suite »). |

## Ajouts v2
- **✏ Modifier** (fiche d'un document actif) : titre, type, projet, client, service, mots-clés, description, conservation. Le fichier et les versions ne changent pas ; les champs modifiés sont inscrits dans l'historique et le journal CORE. **Réduire ou retirer la conservation : administrateur seul** ; l'allonger ou la définir : propriétaire.
- **📦 Déposer plusieurs** : sélection de plusieurs fichiers ; titre = nom du fichier ; type et service déduits du nom (facture, devis, certificat, plan, note, contrat, reçu, rapport, PV…) si non choisis ; compte rendu fichier par fichier.
- **🔗 Liens (onglet Conservation, désactivés par défaut, réglages propres à l'appareil)** :
  - *Archiver automatiquement les PDF générés* : intercepte `EXBPdf.save` (devis, certificats, plans, notes, reçus… tout PDF produit par le moteur PDF commun). Même empreinte déjà archivée : ignoré ; même nom : nouvelle version ; sinon nouvelle fiche classée par service probable (source « auto »). À reclasser ensuite avec « Modifier » (projet, client).
  - *Suppression pendant la conservation : exiger un dossier Workflow « Validé »* : la suppression anticipée ouvre un dossier de type « Document » (circuit actif requis) et ne devient possible qu'une fois validé ; pas de dossier en double.
- Correctif : une seule fenêtre ouverte à la fois (les fenêtres s'empilaient).

## Vérifié (v2)
- `node tools/test-archives.js` : **71 contrôles** (dont modification, droits sur la conservation, déduction du type).
- Chromium : dépôt par lot (2 fichiers → facture et plan reconnus), modification par l'écran (historique « modif »), archivage automatique (1ʳᵉ génération → fiche, doublon ignoré, contenu différent → version 2, réglage désactivé → rien), suppression anticipée avec Workflow (refus + dossier ouvert, pas de doublon, validation par la fonction attendue → suppression), **0 erreur JavaScript**.

## Données
`exb_ar_docs` (fiches, sans contenu) · `exb_ar_f_<id>_<n>` (contenu d'une version ; les « data: » sont rangés en IndexedDB par `exb-bigstore.js`) · `exb_ar_supprimes`. Synchronisées comme les autres clés `exb_*`.
Fichier limité à **15 Mo** (message clair au-delà). La sauvegarde complète de l'application contient les archives.

## Vérifié
- `node tools/test-archives.js` : **59 contrôles** (métadonnées, fichier, numérotation, droits propriétaire / admin / partage nom et fonction / expiration, versions, restauration, archivage, conservation, suppression, recherche et filtres, regroupements, statistiques).
- Chromium (banc d'essai, écran d'activation masqué) : le menu et l'écran apparaissent, dépôt d'un fichier, refus d'un titre vide, recherche (1 résultat puis 0), fiche, aperçu texte, 2ᵉ version avec empreinte SHA-256 de 64 caractères, contenu de la v1 et de la v2 relus correctement, historique à 2 lignes, **0 erreur JavaScript**.

## Non vérifié / à savoir
- **Les droits sont appliqués par l'écran et l'API, pas par un serveur** : quelqu'un de technique peut lire le stockage local de son appareil. Pour un cloisonnement réel (documents confidentiels, plusieurs sites), il faut des tables et un stockage serveur avec droits (RLS).
- **Identité** : connecté à une organisation, l'acteur est le compte ; en **mode local**, c'est « Utilisateur local » et l'historique marque « identité non vérifiée ». Les partages par nom ou fonction supposent que les libellés correspondent à vos comptes réels : à vérifier.
- Synchronisation entre deux appareils : une clé est écrasée en entier (dernière écriture gagne) ; le contenu d'un fichier déposé sur un appareil n'est disponible sur un autre qu'après synchronisation (message explicite sinon).
- Boîtes « Motif » : utilisent `exbPrompt` / `exbConfirm` du reste de la V144e. Archivage, suppression et partage par l'interface : logique testée (moteur), clics non rejoués un par un en navigateur.
- Téléphone, gros volumes (> 500 documents), impression de l'historique : non testés. La liste affiche 150 résultats au plus (affiner la recherche).
- L'application reconstruit son interface après la connexion : le module remonte son menu s'il manque (vérification toutes les 3 s, page visible). Vérifié en banc d'essai avec l'écran d'activation masqué, pas avec un vrai compte.

## Reste hors de ce lot (décisions à prendre)
1. **Serveur** : stockage et droits côté serveur (Supabase + RLS) pour la confidentialité réelle, les gros volumes et plusieurs sites.
2. **Branchements dédiés** (au-delà de l'archivage automatique des PDF) : dépôt direct d'une révision de plan depuis Plan Editor, de la numérisation depuis Scanner, du dossier final depuis Project Manager, avec projet et client renseignés d'office. Il faut pour cela me dire sur quel écran se trouvent ces actions.
3. Archivage automatique : non testé avec de vrais PDF volumineux (limite 15 Mo, au-delà ignoré sans message) ni sur téléphone.
