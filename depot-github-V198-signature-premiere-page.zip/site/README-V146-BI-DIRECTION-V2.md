# Excellencia BI — Direction (v2)

Suite de la v1 (module 01 du cahier des charges, priorité de développement). Menu : **📈 BI Direction**.
Toujours **lecture seule** : aucune donnée modifiée, aucun SQL, aucune nouvelle clé de stockage.
Retrait : supprimer `<script src="exb-bi.js">` dans `index.html` (retour à rien) ou remettre `exb-bi.js` de la V145 (retour à la v1).

## Ce qui est ajouté
1. **Alertes de direction** (en haut de l'écran), triées « à traiter » puis « à surveiller » :
   - Finance : résultat de trésorerie négatif (par devise) ; créances échues (grave si ≥ 50 % des créances dues) ; incohérence factures/paiements ; encaissements possiblement en double.
   - Projets : chaque projet en cours « à traiter » ou « à surveiller » remonte avec son premier motif et le nombre d'autres alertes ; lien « détail ».
2. **Projets : budget, avancement et écarts** (en USD, à ce jour) : budget, coût réel, coût final estimé, écart final, avancement réel / planifié, CPI, SPI, retard prévisionnel, statut. Ligne de consolidation du portefeuille. Cliquer un projet ouvre son détail (indicateurs, sources de calcul, alertes et conseils).
3. **Export Excel (CSV)** : ajoute les sections « Projets » et « Alertes de direction ».
4. **Dictionnaire** : 6 définitions de plus (budget, coût réel, valeur acquise, CPI, SPI, coût final estimé / écart final).
5. Export CSV : les textes commençant par `=`, `+`, `-` ou `@` sont préfixés d'une apostrophe (évite l'exécution d'une formule à l'ouverture dans Excel).

## D'où viennent les chiffres
Le calcul des projets **réutilise le moteur existant `exb-evm.js`** (le même que « Pilotage projets », mêmes seuils réglables `exb_pilot_th`) : pas de seconde règle de calcul, donc pas d'écart entre les deux écrans.
Différence volontaire : les sorties de caisse d'un projet **en FC ne sont pas converties** ; elles sont exclues du coût réel et comptées à part (message sous le tableau). Les impayés échus d'un projet ne comptent que les factures en USD.

## À savoir
- Les indicateurs de projet sont **à la date du jour** : le filtre de période (mois, année…) ne s'y applique pas. Le filtre « Projet » s'applique.
- Un projet sans budget affiche « données insuffisantes » : aucun indice n'est inventé.
- Sans avancement saisi (ni planning Gantt), la valeur acquise est nulle et le CPI vaut 0 : saisir l'avancement du projet ou créer le planning.

## Vérifié
- `node tools/test-bi.js` : 35 contrôles (indicateurs financiers de la v1 recalculés à la main, 3 projets de test, statuts, dépense en FC exclue, alertes et leur ordre, filtre projet, rendu, échappement HTML d'un nom de projet piégé).
- Chromium : l'application démarre, le module passe en version 2, l'écran s'affiche avec alertes et tableau, le détail d'un projet s'ouvre ; 0 erreur JavaScript (identique à la V145).
- `node tools/check.js` : 561 contrôles, 0 échec (voir « Correctifs » ci-dessous).
- Cache hors-ligne (`sw.js`) : nom de version changé pour que les appareils récupèrent le nouveau fichier.

## Correctifs (deux échecs qui existaient déjà dans la V144e)
1. **Fusion de clients en double — versements perdus du total** (`exb-liaison.js`). Le registre financier est gardé en mémoire un court instant (optimisation V144e) ; une écriture qui ne change que le rattachement d'un client (fusion) ne l'invalidait pas toujours, d'où un « versé » faux juste après la fusion. Le module invalide désormais ce cache à chacune de ses écritures. Test `tools/test-liaison-4.js` : 41/41.
2. **Test Budget & pilotage** (`tools/test-budgetfin.js`) : la suppression d'une dépense est devenue asynchrone en V144e (boîte de dialogue `exbConfirm`) ; le test n'attendait pas la fin. Test corrigé (le code du logiciel était correct) : 44/44.

## Non vérifié
Affichage sur téléphone, impression PDF réelle de l'écran, export CSV ouvert dans Excel, données réelles synchronisées.

## Pas encore couvert (à décider avec vous)
- **Indicateurs par département** : les projets n'ont pas de champ « département » dans les données actuelles ; il faut d'abord décider d'où il vient (champ du projet ? du collaborateur ?).
- Conversion de devises au taux du jour (aujourd'hui : jamais de conversion).
- Rapports périodiques planifiés (PDF/Excel envoyés automatiquement) : demande un serveur ou une tâche planifiée.
- Alertes poussées (notification) : aujourd'hui les alertes s'affichent à l'ouverture de l'écran.
- Autres modules du cahier des charges : Workflow, Archives, Scanner, Administration (rôles et revue des accès), CRM/HR/Stock en tant que modules complets.

## v5 (fusion sur V166c, sans doublon)
Ajouts uniquement : case « Tout en dollars » (conversion optionnelle au dernier taux Finances, désactivée sans taux, données jamais modifiées), « Rapport de direction (PDF) » avec alertes, indicateurs et tableau des projets, rappel périodique hebdomadaire/mensuel (📄), badge 🔴 d'alertes critiques sur le bouton et un rappel par jour.
Non repris car déjà couverts par la v4 de cette version : projets/écarts/avancement, alertes de direction, filtre par département, dettes fournisseurs et engagements, export CSV.
Non repris volontairement : paiements des apprenants dans « Encaissé » (pour ne pas changer vos chiffres).
