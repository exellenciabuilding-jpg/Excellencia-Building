# V169 — Scanner : cadre automatique à 4 coins et redressement

Fichier modifié : `site/exb-scanner.js` (fusionné avec V152 « rattachement projet/client » et V153 « OCR » : conservés). Aucun autre module touché. `tools/test-scanner.js` étendu (34 contrôles) et rendu autonome (n'exige plus `/home/claude/p.jpg`). `sw.js` : nouvelle version du cache.

## Changements
- **Détection par différence avec le fond** (au lieu de clair/foncé) : un bandeau foncé n'est plus coupé.
- **4 coins** (enveloppe convexe + rectangle d'aire minimale) ; « ✔ Appliquer et redresser » corrige inclinaison et perspective (homographie, interpolation bilinéaire).
- **Coins déplaçables** au doigt avant application ; le recadrage libre (glisser un rectangle) reste possible.
- Si la détection échoue : repli sur l'ancien cadre rectangulaire, puis message « Cadre non détecté ».
- Le moteur exporte `detectQuad`, `quadSize`, `warp`, `hull`.

## Vérifié
- `node tools/test-scanner.js` : 34 (page inclinée, bandeau foncé, trapèze, page foncée sur fond clair, fond uniforme, page minuscule ou pleine, couleurs des coins après redressement).
- `test-archives` 71, `test-bi-dettes` 41, `test-cloture` 52, `test-jalons` 18, `test-report-ops` 55, `site/tools/check.js` 574/574.
- Chromium (banc minimal avec les vrais `exb-core`, `exb-archives`, `exb-scanner`, `exb-ocr`) : photo penchée → 4 coins → page redressée (1600×1200 → 760×973) → dépôt Archives avec `projetId`/`clientId` (V152) ; bouton OCR présent ; 0 erreur JS.

## Limites
- Fond chargé, ombres fortes : déplacer les coins à la main. Page tournée de plus de 45° : bouton Rotation.
- L'OCR lit les pages avant « Appliquer et redresser » ; appliquez le cadre d'abord pour un meilleur résultat.
- Non testé : vrai téléphone, vraie photo, application complète derrière la connexion, Tesseract réel (toujours à fournir, voir V153).
- L'APK Android garde le cadre rectangulaire.
