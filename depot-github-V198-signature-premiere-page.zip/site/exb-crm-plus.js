/* Excellencia Building V172 — CRM : compléments (module 04 du cahier des charges).
 * Principe : clients (exb_clients) et devis (exb_quotes) existants ne sont JAMAIS modifiés. Tout est stocké dans des clés nouvelles.
 *  - Pipeline d'opportunités : exb_crm_opps (étapes Prospect → Qualifié → Devis envoyé → Négociation → Gagné / Perdu). Historique des changements d'étape ;
 *    « Perdu » exige un motif ; « Gagné » force 100 %. Valeur pondérée = montant × probabilité.
 *  - Relances & rendez-vous : exb_crm_followups (à faire / fait / en retard, résultat obligatoire à la clôture).
 *  - Versions de devis : exb_quote_versions (instantané figé d'un devis à une date + motif) ; comparaison entre versions ; devis → contrat : exb_crm_contracts.
 *  - Réclamations : exb_crm_claims (ouverte → en cours → résolue → clôturée ; actions datées ; résolution obligatoire).
 *  - Satisfaction : exb_crm_satisf (note 1–5 + commentaire) ; moyenne calculée.
 * V176 (additif) : onglet « Alertes & export » — alertes (réclamations hors délai, relances en retard, clôture dépassée, opportunités sans relance ou inactives), import des prospects de l'ancien CRM, export CSV.
 * Les montants sont par devise (aucune conversion). Retrait : supprimer la balise <script src="exb-crm-plus.js"> (les données restent dans leurs clés). */
(function (w) {
  'use strict';
  var d = w.document, $ = function (i) { return d && d.getElementById ? d.getElementById(i) : null; };
  var K = { op: 'exb_crm_opps', fu: 'exb_crm_followups', qv: 'exb_quote_versions', ct: 'exb_crm_contracts', cl: 'exb_crm_claims', sa: 'exb_crm_satisf' };
  var STAGES = [['prospect', 'Prospect', 10], ['qualifie', 'Qualifié', 30], ['devis', 'Devis envoyé', 50], ['negociation', 'Négociation', 70], ['gagne', 'Gagné', 100], ['perdu', 'Perdu', 0]];
  function stg(k) { return STAGES.find(function (s) { return s[0] === k; }) || STAGES[0]; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function pn(v) { var x = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isNaN(x) ? 0 : x; }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nf(n) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/[  ]/g, ' '); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function LD(k, df) { try { var v = w.load ? w.load(k, df) : JSON.parse(w.localStorage.getItem(k)); return v == null ? df : v; } catch (e) { return df; } }
  function SV(k, v) { try { return w.save ? w.save(k, v) : (w.localStorage.setItem(k, JSON.stringify(v)), true); } catch (e) { return false; } }
  function uid(p) { try { return w.exbId(p); } catch (e) { return p + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); } }
  function audit(a, o, x) { try { w.EXBCore && w.EXBCore.audit.log(a, o, x); } catch (e) {} }
  function say(m, t) { try { w.notify(m, t || 'info', 4500); } catch (e) { try { w.exbAlert(m); } catch (x) {} } }
  function who() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.fonction || i.role)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function can(c, m) { try { return w.EXBDB && w.EXBDB.can ? !!w.EXBDB.can(c, m) : true; } catch (e) { return true; } }
  function cur(x) { var c = String((x && x.currency) || 'USD').toUpperCase(); return c === 'CDF' ? 'FC' : c; }
  function clients() { return LD('exb_clients', []).map(function (c) { return c.full_name || c.company || c.name || c.id; }).filter(Boolean); }
  function quotes() { return LD('exb_quotes', []); }
  function qTot(q) { if (q.total != null && !isNaN(+q.total)) return r2(+q.total); return r2((q.lines || []).reduce(function (a, l) { return a + (+l.q || +l.qty || 0) * (+l.pu || +l.price || 0); }, 0)); }

  /* ---------- opportunités ---------- */
  function saveOpp(o) {
    if (!String(o.title || '').trim()) return { error: 'Le titre de l’opportunité est obligatoire.' };
    if (!String(o.client || '').trim()) return { error: 'Le client / prospect est obligatoire.' };
    var a = LD(K.op, []), i = a.findIndex(function (x) { return x.id === o.id; }), n = Object.assign({}, o);
    n.amount = r2(pn(n.amount)); if (n.amount < 0) return { error: 'Le montant ne peut pas être négatif.' };
    n.currency = cur(n); n.stage = n.stage || 'prospect'; n.prob = n.stage === 'gagne' ? 100 : n.stage === 'perdu' ? 0 : Math.max(0, Math.min(100, n.prob === '' || n.prob == null ? stg(n.stage)[2] : pn(n.prob)));
    if (i < 0) { n.id = n.id || uid('OPP'); n.created = today(); n.history = [{ date: today(), from: '', to: n.stage, by: who() }]; a.push(n); }
    else { n.history = a[i].history || []; n.created = a[i].created; if (a[i].stage !== n.stage) return { error: 'Utilisez « Changer d’étape » pour déplacer l’opportunité.' }; a[i] = n; }
    SV(K.op, a); audit('crm.opportunite', n.id, { titre: n.title, etape: n.stage }); return { ok: true, opp: n };
  }
  function moveOpp(id, to, reason) {
    var a = LD(K.op, []), o = a.find(function (x) { return x.id === id; }); if (!o) return { error: 'Opportunité introuvable.' };
    if (!STAGES.some(function (s) { return s[0] === to; })) return { error: 'Étape inconnue.' };
    if (o.stage === to) return { error: 'L’opportunité est déjà à cette étape.' };
    if ((o.stage === 'gagne' || o.stage === 'perdu') && !String(reason || '').trim()) return { error: 'Rouvrir une opportunité clôturée exige un motif.' };
    if (to === 'perdu' && !String(reason || '').trim()) return { error: 'Le motif de perte est obligatoire.' };
    o.history = o.history || []; o.history.push({ date: today(), from: o.stage, to: to, by: who(), note: String(reason || '').trim() });
    o.stage = to; o.prob = stg(to)[2]; if (to === 'perdu') o.lost_reason = String(reason).trim(); if (to === 'gagne') o.won_date = today();
    SV(K.op, a); audit('crm.etape', id, { vers: to }); return { ok: true, opp: o };
  }
  function pipeline() {
    var out = {}, open = LD(K.op, []);
    STAGES.forEach(function (s) { out[s[0]] = { count: 0, amount: {}, weighted: {} }; });
    open.forEach(function (o) { var b = out[o.stage]; if (!b) return; var c = cur(o); b.count++; b.amount[c] = r2((b.amount[c] || 0) + (+o.amount || 0)); b.weighted[c] = r2((b.weighted[c] || 0) + (+o.amount || 0) * (+o.prob || 0) / 100); });
    var won = out.gagne.count, lost = out.perdu.count; out.conversion = won + lost ? Math.round(100 * won / (won + lost)) : null; return out;
  }

  /* ---------- relances & rendez-vous ---------- */
  function addFollow(f) {
    var t = String(f.type || 'relance'); if (t !== 'relance' && t !== 'rdv') return { error: 'Type inconnu.' };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(f.date || ''))) return { error: 'La date est obligatoire (AAAA-MM-JJ).' };
    if (!String(f.client || '').trim()) return { error: 'Le client est obligatoire.' };
    var n = { id: uid('FU'), type: t, client: String(f.client).trim(), opp_id: f.opp_id || '', date: f.date, time: f.time || '', note: f.note || '', done: false, created: today(), by: who() };
    var a = LD(K.fu, []); a.push(n); SV(K.fu, a); audit('crm.' + t, n.id, { client: n.client, date: n.date }); return { ok: true, followup: n };
  }
  function doneFollow(id, result) {
    var a = LD(K.fu, []), f = a.find(function (x) { return x.id === id; }); if (!f) return { error: 'Introuvable.' };
    if (!String(result || '').trim()) return { error: 'Le résultat de l’échange est obligatoire.' };
    f.done = true; f.result = String(result).trim(); f.done_at = today(); SV(K.fu, a); audit('crm.fait', id, {}); return { ok: true };
  }
  function followStatus(f, t) { t = t || today(); return f.done ? 'fait' : (f.date < t ? 'en retard' : (f.date === t ? 'aujourd’hui' : 'à venir')); }

  /* ---------- versions de devis + contrat ---------- */
  function versionsOf(qid) { return LD(K.qv, []).filter(function (v) { return v.quote_id === qid; }).sort(function (a, b) { return a.v - b.v; }); }
  function snapshot(qid, motif) {
    var q = quotes().find(function (x) { return x.id === qid; }); if (!q) return { error: 'Devis introuvable.' };
    var vs = versionsOf(qid); if (vs.length && !String(motif || '').trim()) return { error: 'Le motif de la nouvelle version est obligatoire.' };
    var total = qTot(q), last = vs[vs.length - 1];
    if (last && JSON.stringify(last.snap) === JSON.stringify(q)) return { error: 'Aucun changement depuis la version ' + last.v + '.' };
    var n = { id: uid('QV'), quote_id: qid, quote_no: q.no || q.id, v: vs.length + 1, date: today(), total: total, currency: cur(q), client: q.client || '', motif: String(motif || '').trim() || 'Version initiale', by: who(), snap: JSON.parse(JSON.stringify(q)) };
    var a = LD(K.qv, []); a.push(n); SV(K.qv, a); audit('crm.version', n.id, { devis: n.quote_no, v: n.v }); return { ok: true, version: n };
  }
  function compare(a, b) {
    var ka = {}, kb = {}; (a.snap.lines || []).forEach(function (l) { ka[l.d || l.desc || l.label || l.name || JSON.stringify(l)] = l; }); (b.snap.lines || []).forEach(function (l) { kb[l.d || l.desc || l.label || l.name || JSON.stringify(l)] = l; });
    var diff = []; Object.keys(kb).forEach(function (k) { if (!ka[k]) diff.push('+ ' + k); else if (JSON.stringify(ka[k]) !== JSON.stringify(kb[k])) diff.push('~ ' + k); }); Object.keys(ka).forEach(function (k) { if (!kb[k]) diff.push('− ' + k); });
    return { delta: r2(b.total - a.total), lines: diff };
  }
  function toContract(qid, o) {
    var q = quotes().find(function (x) { return x.id === qid; }); if (!q) return { error: 'Devis introuvable.' };
    var a = LD(K.ct, []); if (a.some(function (c) { return c.quote_id === qid && !c.annule; })) return { error: 'Ce devis est déjà converti en contrat.' };
    if (!versionsOf(qid).length) { var s = snapshot(qid, ''); if (s.error) return s; }
    var vs = versionsOf(qid), v = vs[vs.length - 1], n = { id: uid('CTR'), no: 'CTR-' + new Date().getFullYear() + '-' + String(a.length + 1).padStart(3, '0'), quote_id: qid, quote_no: q.no || q.id, version: v.v, client: q.client || '', project: q.project || '', amount: v.total, currency: v.currency, date: (o && o.date) || today(), start: (o && o.start) || '', status: 'à signer', by: who() };
    a.push(n); SV(K.ct, a); audit('crm.contrat', n.id, { devis: n.quote_no, v: n.version }); return { ok: true, contract: n };
  }
  function setContractStatus(id, st) {
    var a = LD(K.ct, []), c = a.find(function (x) { return x.id === id; }); if (!c) return { error: 'Introuvable.' };
    if (['à signer', 'signé', 'résilié'].indexOf(st) < 0) return { error: 'Statut inconnu.' }; c.status = st; if (st === 'signé') c.signed_at = today(); SV(K.ct, a); audit('crm.contrat.statut', id, { statut: st }); return { ok: true };
  }

  /* ---------- réclamations ---------- */
  var CL_ST = ['ouverte', 'en cours', 'résolue', 'clôturée'];
  function addClaim(c) {
    if (!String(c.client || '').trim()) return { error: 'Le client est obligatoire.' };
    if (!String(c.subject || '').trim()) return { error: 'L’objet de la réclamation est obligatoire.' };
    var a = LD(K.cl, []), n = { id: uid('REC'), no: 'REC-' + new Date().getFullYear() + '-' + String(a.length + 1).padStart(3, '0'), client: String(c.client).trim(), project: c.project || '', date: today(), subject: String(c.subject).trim(), severity: c.severity || 'normale', status: 'ouverte', actions: [], by: who() };
    a.push(n); SV(K.cl, a); audit('crm.reclamation', n.id, { client: n.client }); return { ok: true, claim: n };
  }
  function advanceClaim(id, to, text) {
    var a = LD(K.cl, []), c = a.find(function (x) { return x.id === id; }); if (!c) return { error: 'Introuvable.' };
    var i = CL_ST.indexOf(c.status), j = CL_ST.indexOf(to); if (j < 0) return { error: 'Statut inconnu.' }; if (j !== i + 1) return { error: 'Étape suivante attendue : « ' + (CL_ST[i + 1] || '—') + ' ».' };
    if ((to === 'résolue' || to === 'clôturée') && !String(text || '').trim()) return { error: to === 'résolue' ? 'Décrivez la résolution apportée.' : 'Décrivez la confirmation du client.' };
    c.actions.push({ date: today(), text: String(text || '').trim() || 'Prise en charge', status: to, by: who() }); c.status = to; if (to === 'résolue') c.resolution = String(text).trim(); if (to === 'clôturée') c.closed_at = today();
    SV(K.cl, a); audit('crm.reclamation.statut', id, { statut: to }); return { ok: true };
  }

  /* ---------- satisfaction ---------- */
  function addSatisf(s) {
    var n = Math.round(pn(s.score)); if (n < 1 || n > 5) return { error: 'La note doit être comprise entre 1 et 5.' };
    if (!String(s.client || '').trim()) return { error: 'Le client est obligatoire.' };
    var a = LD(K.sa, []); a.push({ id: uid('SAT'), date: today(), client: String(s.client).trim(), project: s.project || '', score: n, comment: s.comment || '', by: who() }); SV(K.sa, a); audit('crm.satisfaction', s.client, { note: n }); return { ok: true };
  }
  function satisfStats() { var a = LD(K.sa, []); return { n: a.length, avg: a.length ? Math.round(10 * a.reduce(function (x, y) { return x + y.score; }, 0) / a.length) / 10 : null }; }

  /* ---------- interface ---------- */
  var S = { tab: 'pipe', sel: null };
  function inp(id, v, ph, ex, t) { return '<input id="' + id + '" ' + (t ? 'type="' + t + '" ' : '') + 'value="' + esc(v == null ? '' : v) + '" placeholder="' + esc(ph || '') + '" style="padding:6px;max-width:100%;box-sizing:border-box;' + (ex || '') + '">'; }
  function btn(id, l) { return '<button id="' + id + '" type="button" style="padding:6px 10px;margin:2px">' + l + '</button>'; }
  function tbl(h, rows) { return '<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12.5px"><thead><tr style="text-align:left;background:#f1f5fb">' + h.map(function (x) { return '<th style="padding:5px">' + x + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'; }
  function td(v, a) { return '<td style="padding:5px;border-top:1px solid #e2e8f0;' + (a ? 'text-align:' + a : '') + '">' + v + '</td>'; }
  function opts(arr, sel) { return arr.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === sel ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }
  function dl(id) { return '<datalist id="' + id + '">' + clients().map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist>'; }
  function money(m) { var k = Object.keys(m || {}); return k.length ? k.map(function (c) { return nf(m[c]) + ' ' + c; }).join(' + ') : '—'; }
  function body() { var o = $('crp_ov'); return o && o.querySelector('.crp_body'); }
  function render() {
    var o = $('crp_ov'); if (!o) return; var T = [['pipe', '🎯 Pipeline'], ['fu', '📞 Relances & RDV'], ['ver', '🧾 Devis & contrats'], ['rec', '📣 Réclamations'], ['sat', '⭐ Satisfaction'], ['syn', '🔔 Alertes & export']];
    o.querySelector('.crp_tabs').innerHTML = T.map(function (t) { return '<button type="button" data-t="' + t[0] + '" style="padding:6px 10px;margin:2px;' + (S.tab === t[0] ? 'font-weight:700;border:2px solid #1d4ed8' : '') + '">' + t[1] + '</button>'; }).join('');
    Array.prototype.forEach.call(o.querySelectorAll('.crp_tabs button'), function (b) { b.onclick = function () { S.tab = b.getAttribute('data-t'); S.sel = null; render(); }; });
    ({ pipe: vPipe, fu: vFu, ver: vVer, rec: vRec, sat: vSat, syn: vSyn })[S.tab](body());
  }
  function vPipe(b) {
    var p = pipeline(), ops = LD(K.op, []), canW = can('crm', 'ecrire') || can('exb_clients', 'ecrire');
    var h = '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">' + STAGES.map(function (s) { var x = p[s[0]]; return '<div style="flex:1;min-width:120px;border:1px solid #cbd5e1;border-radius:8px;padding:6px"><b>' + s[1] + '</b><br>' + x.count + ' opp.<br><small>' + money(x.amount) + '</small>' + (s[0] !== 'gagne' && s[0] !== 'perdu' ? '<br><small>pondéré : ' + money(x.weighted) + '</small>' : '') + '</div>'; }).join('') + '</div>';
    h += '<p>Taux de conversion (gagné / clôturé) : <b>' + (p.conversion == null ? '—' : p.conversion + ' %') + '</b></p>' + dl('crp_dl');
    if (canW) h += '<p>' + inp('po_t', '', 'Titre (ex. Villa Gombe)', 'width:170px') + ' ' + inp('po_c', '', 'Client / prospect', 'width:150px') + ' ' + inp('po_a', '', 'Montant', 'width:90px') + ' <select id="po_cu"><option>USD</option><option>FC</option></select> ' + inp('po_e', '', 'Clôture prévue AAAA-MM-JJ', 'width:150px') + btn('po_add', '➕ Ajouter') + '</p>';
    h += ops.length ? tbl(['Opportunité', 'Client', 'Montant', 'Étape', '%', 'Clôture prévue', 'Action'], ops.slice().reverse().map(function (o) { return '<tr>' + td(esc(o.title)) + td(esc(o.client)) + td(nf(o.amount) + ' ' + cur(o), 'right') + td(esc(stg(o.stage)[1]) + (o.lost_reason ? '<br><small>' + esc(o.lost_reason) + '</small>' : '')) + td(o.prob + ' %', 'right') + td(esc(o.expected || '')) + td(canW ? '<select class="po_mv" data-id="' + esc(o.id) + '"><option value="">Changer d’étape…</option>' + STAGES.filter(function (s) { return s[0] !== o.stage; }).map(function (s) { return '<option value="' + s[0] + '">' + s[1] + '</option>'; }).join('') + '</select>' : '') + '</tr>'; })) : '<p>Aucune opportunité.</p>';
    b.innerHTML = h;
    if ($('po_add')) { $('po_c').setAttribute('list', 'crp_dl'); $('po_add').onclick = function () { var r = saveOpp({ title: $('po_t').value, client: $('po_c').value, amount: $('po_a').value, currency: $('po_cu').value, expected: $('po_e').value, stage: 'prospect' }); if (r.error) return say(r.error, 'warn'); say('Opportunité ajoutée.', 'success'); render(); }; }
    Array.prototype.forEach.call(b.querySelectorAll('.po_mv'), function (s) { s.onchange = async function () { if (!s.value) return; var rs = ''; var o = ops.find(function (x) { return x.id === s.getAttribute('data-id'); }); if (s.value === 'perdu' || (o && (o.stage === 'gagne' || o.stage === 'perdu'))) { rs = await w.exbPrompt(s.value === 'perdu' ? 'Motif de la perte (prix, concurrent, report…) :' : 'Motif de la réouverture :', ''); if (rs == null) { render(); return; } } var r = moveOpp(s.getAttribute('data-id'), s.value, rs); if (r.error) say(r.error, 'warn'); else say('Étape mise à jour.', 'success'); render(); }; });
  }
  function vFu(b) {
    var a = LD(K.fu, []).slice().sort(function (x, y) { return (x.done - y.done) || (x.date + x.time < y.date + y.time ? -1 : 1); }), late = a.filter(function (f) { return followStatus(f) === 'en retard'; }).length;
    var h = '<p>' + (late ? '<b style="color:#b91c1c">' + late + ' en retard</b>' : 'Aucun retard') + '</p>' + dl('crp_dl2') + '<p><select id="pf_t"><option value="relance">Relance</option><option value="rdv">Rendez-vous</option></select> ' + inp('pf_c', '', 'Client', 'width:150px') + ' ' + inp('pf_d', today(), 'AAAA-MM-JJ', 'width:110px') + ' ' + inp('pf_h', '', 'Heure', 'width:70px') + ' ' + inp('pf_n', '', 'Objet', 'width:170px') + btn('pf_add', '➕ Planifier') + '</p>';
    h += a.length ? tbl(['Date', 'Type', 'Client', 'Objet', 'Statut', ''], a.map(function (f) { var st = followStatus(f); return '<tr>' + td(esc(f.date) + ' ' + esc(f.time)) + td(f.type === 'rdv' ? 'RDV' : 'Relance') + td(esc(f.client)) + td(esc(f.note) + (f.result ? '<br><small>→ ' + esc(f.result) + '</small>' : '')) + td('<span style="color:' + (st === 'en retard' ? '#b91c1c' : st === 'fait' ? '#15803d' : '#0f172a') + '">' + st + '</span>') + td(f.done ? '' : '<button type="button" class="pf_ok" data-id="' + esc(f.id) + '">Fait</button>') + '</tr>'; })) : '<p>Rien de planifié.</p>';
    b.innerHTML = h; $('pf_c').setAttribute('list', 'crp_dl2');
    $('pf_add').onclick = function () { var r = addFollow({ type: $('pf_t').value, client: $('pf_c').value, date: $('pf_d').value, time: $('pf_h').value, note: $('pf_n').value }); if (r.error) return say(r.error, 'warn'); say('Planifié.', 'success'); render(); };
    Array.prototype.forEach.call(b.querySelectorAll('.pf_ok'), function (x) { x.onclick = async function () { var r0 = await w.exbPrompt('Résultat de l’échange :', ''); if (r0 == null) return; var r = doneFollow(x.getAttribute('data-id'), r0); if (r.error) return say(r.error, 'warn'); render(); }; });
  }
  function vVer(b) {
    var qs = quotes(), cts = LD(K.ct, []);
    var h = qs.length ? tbl(['Devis', 'Client', 'Total', 'Versions', 'Contrat', 'Actions'], qs.map(function (q) { var vs = versionsOf(q.id), c = cts.find(function (x) { return x.quote_id === q.id && !x.annule; }); return '<tr>' + td(esc(q.no || q.id)) + td(esc(q.client)) + td(nf(qTot(q)) + ' ' + cur(q), 'right') + td(vs.length ? vs.map(function (v) { return 'v' + v.v + ' (' + nf(v.total) + ')'; }).join(' → ') : '—') + td(c ? esc(c.no) + ' · ' + esc(c.status) + (c.status !== 'signé' ? ' <button type="button" class="pv_sg" data-id="' + esc(c.id) + '">Marquer signé</button>' : '') : '—') + td('<button type="button" class="pv_snap" data-id="' + esc(q.id) + '">📸 Figer une version</button>' + (vs.length > 1 ? ' <button type="button" class="pv_cmp" data-id="' + esc(q.id) + '">Comparer</button>' : '') + (c ? '' : ' <button type="button" class="pv_ctr" data-id="' + esc(q.id) + '">📑 Convertir en contrat</button>')) + '</tr>'; })) : '<p>Aucun devis. Créez-en dans le module Devis.</p>';
    h += '<div id="pv_out" style="margin-top:8px"></div>'; b.innerHTML = h;
    Array.prototype.forEach.call(b.querySelectorAll('.pv_snap'), function (x) { x.onclick = async function () { var id = x.getAttribute('data-id'), m = ''; if (versionsOf(id).length) { m = await w.exbPrompt('Motif de la nouvelle version (ex. remise accordée) :', ''); if (m == null) return; } var r = snapshot(id, m); if (r.error) return say(r.error, 'warn'); say('Version ' + r.version.v + ' figée.', 'success'); render(); }; });
    Array.prototype.forEach.call(b.querySelectorAll('.pv_cmp'), function (x) { x.onclick = function () { var vs = versionsOf(x.getAttribute('data-id')), a = vs[vs.length - 2], z = vs[vs.length - 1], c = compare(a, z); $('pv_out').innerHTML = '<b>v' + a.v + ' → v' + z.v + '</b> : écart de total ' + nf(c.delta) + '<br>' + (c.lines.length ? c.lines.map(esc).join('<br>') : 'Mêmes lignes.') + '<br><small>Motif : ' + esc(z.motif) + '</small>'; }; });
    Array.prototype.forEach.call(b.querySelectorAll('.pv_ctr'), function (x) { x.onclick = async function () { if (!(await w.exbConfirm('Convertir ce devis (dernière version figée) en contrat ?'))) return; var r = toContract(x.getAttribute('data-id'), {}); if (r.error) return say(r.error, 'warn'); say('Contrat ' + r.contract.no + ' créé.', 'success'); render(); }; });
    Array.prototype.forEach.call(b.querySelectorAll('.pv_sg'), function (x) { x.onclick = function () { setContractStatus(x.getAttribute('data-id'), 'signé'); render(); }; });
  }
  function vRec(b) {
    var a = LD(K.cl, []).slice().reverse(), h = dl('crp_dl3') + '<p>' + inp('pr_c', '', 'Client', 'width:150px') + ' ' + inp('pr_s', '', 'Objet de la réclamation', 'width:230px') + ' <select id="pr_g"><option>normale</option><option>urgente</option></select> ' + btn('pr_add', '➕ Enregistrer') + '</p>';
    h += a.length ? tbl(['N°', 'Client', 'Objet', 'Gravité', 'Statut', 'Suivi', ''], a.map(function (c) { var nx = CL_ST[CL_ST.indexOf(c.status) + 1]; return '<tr>' + td(esc(c.no)) + td(esc(c.client)) + td(esc(c.subject)) + td(esc(c.severity)) + td(esc(c.status)) + td(c.actions.map(function (x) { return esc(x.date) + ' : ' + esc(x.text); }).join('<br>')) + td(nx ? '<button type="button" class="pr_nx" data-id="' + esc(c.id) + '" data-to="' + nx + '">→ ' + nx + '</button>' : '') + '</tr>'; })) : '<p>Aucune réclamation.</p>';
    b.innerHTML = h; $('pr_c').setAttribute('list', 'crp_dl3');
    $('pr_add').onclick = function () { var r = addClaim({ client: $('pr_c').value, subject: $('pr_s').value, severity: $('pr_g').value }); if (r.error) return say(r.error, 'warn'); say('Réclamation ' + r.claim.no + ' enregistrée.', 'success'); render(); };
    Array.prototype.forEach.call(b.querySelectorAll('.pr_nx'), function (x) { x.onclick = async function () { var to = x.getAttribute('data-to'), t = await w.exbPrompt(to === 'en cours' ? 'Action engagée :' : to === 'résolue' ? 'Résolution apportée :' : 'Confirmation du client :', ''); if (t == null) return; var r = advanceClaim(x.getAttribute('data-id'), to, t); if (r.error) return say(r.error, 'warn'); render(); }; });
  }
  function vSat(b) {
    var a = LD(K.sa, []).slice().reverse(), st = satisfStats();
    b.innerHTML = '<p>Note moyenne : <b>' + (st.avg == null ? '—' : st.avg + ' / 5') + '</b> sur ' + st.n + ' retour(s)</p>' + dl('crp_dl4') + '<p>' + inp('ps_c', '', 'Client', 'width:150px') + ' ' + inp('ps_p', '', 'Projet', 'width:130px') + ' <select id="ps_s"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select> ' + inp('ps_m', '', 'Commentaire', 'width:220px') + btn('ps_add', '➕ Enregistrer') + '</p>' + (a.length ? tbl(['Date', 'Client', 'Projet', 'Note', 'Commentaire'], a.map(function (s) { return '<tr>' + td(esc(s.date)) + td(esc(s.client)) + td(esc(s.project)) + td(s.score + ' / 5') + td(esc(s.comment)) + '</tr>'; })) : '<p>Aucun retour client.</p>');
    $('ps_c').setAttribute('list', 'crp_dl4'); $('ps_add').onclick = function () { var r = addSatisf({ client: $('ps_c').value, project: $('ps_p').value, score: $('ps_s').value, comment: $('ps_m').value }); if (r.error) return say(r.error, 'warn'); say('Merci, retour enregistré.', 'success'); render(); };
  }
  function open() {
    var o = $('crp_ov'); if (o) o.remove(); o = d.createElement('div'); o.id = 'crp_ov';
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.innerHTML = '<div style="background:var(--card,#fff);color:var(--fg,#0f172a);width:100%;max-width:980px;border-radius:12px;padding:14px;box-sizing:border-box"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">🤝 CRM — pipeline, relances, devis, réclamations</h3><button id="crp_x" type="button" aria-label="Fermer">✕</button></div><div class="crp_tabs" style="margin:8px 0"></div><div class="crp_body"></div></div>';
    d.body.appendChild(o); $('crp_x').onclick = function () { o.remove(); }; S.tab = 'pipe'; audit('crm.plus.ouvert', 'crm', who()); render();
  }
  function mount() { var ref = $('bclients'); if (ref && !$('bcrmp')) { var b = d.createElement('button'); b.id = 'bcrmp'; b.type = 'button'; b.textContent = '🤝 CRM : pipeline, relances, réclamations'; b.onclick = open; ref.parentNode.insertBefore(b, ref.nextSibling); } }
  function start() { mount(); var n = 0, t = setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} if ($('bcrmp') || ++n > 40) clearInterval(t); }, 1500); try { w.EXBCore && w.EXBCore.modules.register({ id: 'crm-plus', name: 'CRM : pipeline, relances, réclamations', version: '176.0.0', area: 'Gestion & finances' }); } catch (e) {} }

  /* ---------- V176 : alertes de direction, import des prospects historiques, export CSV (additif : aucune nouvelle clé, aucune donnée modifiée hors import) ---------- */
  var STALE_DAYS = 14, CLAIM_DAYS = { urgente: 3, normale: 7 };
  function dd(a, b) { return Math.round((Date.parse(String(a).slice(0, 10) + 'T00:00:00Z') - Date.parse(String(b).slice(0, 10) + 'T00:00:00Z')) / 864e5); }
  function isOpenOpp(o) { return o.stage !== 'gagne' && o.stage !== 'perdu'; }
  /* niveaux : critique > haute > moyenne ; les réclamations sont jugées sur leur ancienneté (3 j urgentes, 7 j normales : seuils fixes, non stockés) */
  function alertes(t) {
    t = t || today(); var ops = LD(K.op, []), fu = LD(K.fu, []), cl = LD(K.cl, []), out = [], open = ops.filter(isOpenOpp);
    var lateCl = cl.filter(function (c) { return c.status !== 'clôturée' && c.date && dd(t, c.date) > (CLAIM_DAYS[c.severity] != null ? CLAIM_DAYS[c.severity] : 7); });
    if (lateCl.length) out.push({ niveau: 'critique', code: 'reclamations', n: lateCl.length, texte: lateCl.length + ' réclamation(s) sans clôture au-delà du délai (' + CLAIM_DAYS.urgente + ' j urgentes, ' + CLAIM_DAYS.normale + ' j normales).' });
    var lateFu = fu.filter(function (f) { return !f.done && f.date && f.date < t; });
    if (lateFu.length) out.push({ niveau: 'haute', code: 'relances', n: lateFu.length, texte: lateFu.length + ' relance(s) / rendez-vous en retard.' });
    var lateOpp = open.filter(function (o) { return /^\d{4}-\d{2}-\d{2}$/.test(o.expected || '') && o.expected < t; });
    if (lateOpp.length) out.push({ niveau: 'haute', code: 'cloture', n: lateOpp.length, texte: lateOpp.length + ' opportunité(s) dont la clôture prévue est dépassée.' });
    var noFu = open.filter(function (o) { return !fu.some(function (f) { return !f.done && f.opp_id === o.id; }); });
    if (noFu.length) out.push({ niveau: 'moyenne', code: 'sans_relance', n: noFu.length, texte: noFu.length + ' opportunité(s) ouverte(s) sans relance planifiée.' });
    var stale = open.filter(function (o) {
      var h = o.history || [], last = h.length ? h[h.length - 1].date : o.created;
      fu.forEach(function (f) { if (f.opp_id === o.id && f.done_at && (!last || f.done_at > last)) last = f.done_at; });
      return last && dd(t, last) > STALE_DAYS;
    });
    if (stale.length) out.push({ niveau: 'moyenne', code: 'inactives', n: stale.length, texte: stale.length + ' opportunité(s) sans activité depuis plus de ' + STALE_DAYS + ' jours.' });
    return out;
  }
  /* Importe les prospects de l'ancien CRM (exb_crm, exb_v92_crm) comme opportunités, une seule fois chacun (clé src_id). */
  function importProspects() {
    var a = LD(K.op, []), have = {}, n = 0, MAP = { 'Prospect': 'prospect', 'Qualification': 'qualifie', 'Visite': 'qualifie', 'Étude': 'qualifie', 'Devis': 'devis', 'Négociation': 'negociation', 'Gagné': 'gagne', 'Perdu': 'perdu' };
    a.forEach(function (o) { if (o.src_id) have[o.src_id] = 1; });
    [['exb_crm', 'crm'], ['exb_v92_crm', 'v92']].forEach(function (p) {
      (LD(p[0], []) || []).forEach(function (x, i) {
        var nm = String(x && (x.name || x.nom || x.company) || '').trim(); if (!nm) return;
        var sid = p[1] + ':' + (x.id || (i + ':' + nm.toLowerCase())); if (have[sid]) return;
        var st = MAP[x.status] || 'prospect', o = { id: uid('OPP'), title: 'Prospect — ' + nm, client: nm, amount: 0, currency: 'USD', stage: st, prob: stg(st)[2], created: today(), history: [{ date: today(), from: '', to: st, by: who(), note: 'Import du CRM historique' }], src_id: sid, contact: x.contact || '', phone: x.phone || x.tel || '' };
        if (st === 'perdu') o.lost_reason = 'Repris du CRM historique'; if (st === 'gagne') o.won_date = today();
        a.push(o); have[sid] = 1; n++;
      });
    });
    if (n) { SV(K.op, a); audit('crm.import_prospects', 'exb_crm', { importes: n }); }
    return n;
  }
  function csvCell(v) { v = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return /[";\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  function toCsv() {
    var R = [['Section', 'N°', 'Titre / objet', 'Client', 'Statut / étape', 'Montant', 'Devise', 'Date', 'Détail']];
    LD(K.op, []).forEach(function (o) { R.push(['Opportunité', o.id, o.title, o.client, stg(o.stage)[1], o.amount, cur(o), o.expected || o.created || '', o.lost_reason || '']); });
    LD(K.fu, []).forEach(function (f) { R.push(['Relance / RDV', f.id, f.type, f.client, followStatus(f), '', '', f.date, f.result || f.note || '']); });
    LD(K.cl, []).forEach(function (c) { R.push(['Réclamation', c.no, c.subject, c.client, c.status, '', '', c.date, c.resolution || '']); });
    LD(K.qv, []).forEach(function (v) { R.push(['Version de devis', (v.quote_no || v.quote_id) + ' v' + v.v, v.motif || v.reason || '', v.client || '', '', v.total != null ? v.total : '', v.currency || '', v.date || '', '']); });
    return '﻿' + R.map(function (r) { return r.map(csvCell).join(';'); }).join('\r\n');
  }
  /* V177 : rapport PDF de marque (alertes, pipeline ouvert, relances en retard, réclamations ouvertes) */
  function rapportHtml() {
    var t = today(), A = alertes(t), ops = LD(K.op, []).filter(isOpenOpp), fu = LD(K.fu, []).filter(function (f) { return !f.done && f.date && f.date < t; }), cl = LD(K.cl, []).filter(function (c) { return c.status !== 'clôturée'; });
    var tot = {}; ops.forEach(function (o) { var c = cur(o); tot[c] = r2((tot[c] || 0) + (+o.amount || 0)); });
    var h = '<h2>Alertes de direction</h2>' + (A.length ? '<table><tr><th>Niveau</th><th>Alerte</th></tr>' + A.map(function (a) { return '<tr><td>' + esc(a.niveau) + '</td><td>' + esc(a.texte) + '</td></tr>'; }).join('') + '</table>' : '<p>Aucune alerte.</p>');
    h += '<h2>Opportunités ouvertes (' + ops.length + ')</h2>' + (ops.length ? '<table><tr><th>Titre</th><th>Client</th><th>Étape</th><th class="r">Montant</th><th>Clôture prévue</th></tr>' + ops.map(function (o) { return '<tr><td>' + esc(o.title) + '</td><td>' + esc(o.client) + '</td><td>' + esc(stg(o.stage)[1]) + '</td><td class="r">' + nf(o.amount) + ' ' + esc(cur(o)) + '</td><td>' + esc(o.expected || '') + '</td></tr>'; }).join('') + '</table>' + '<p><b>Total ouvert : ' + esc(Object.keys(tot).map(function (c) { return nf(tot[c]) + ' ' + c; }).join(' · ') || '0') + '</b></p>' : '<p>Aucune.</p>');
    h += '<h2>Relances / rendez-vous en retard (' + fu.length + ')</h2>' + (fu.length ? '<table><tr><th>Date</th><th>Type</th><th>Client</th><th>Note</th></tr>' + fu.map(function (f) { return '<tr><td>' + esc(f.date) + '</td><td>' + esc(f.type) + '</td><td>' + esc(f.client) + '</td><td>' + esc(f.note || '') + '</td></tr>'; }).join('') + '</table>' : '<p>Aucune.</p>');
    h += '<h2>Réclamations non clôturées (' + cl.length + ')</h2>' + (cl.length ? '<table><tr><th>N°</th><th>Objet</th><th>Client</th><th>Gravité</th><th>Statut</th><th>Date</th></tr>' + cl.map(function (c) { return '<tr><td>' + esc(c.no) + '</td><td>' + esc(c.subject) + '</td><td>' + esc(c.client) + '</td><td>' + esc(c.severity || '') + '</td><td>' + esc(c.status) + '</td><td>' + esc(c.date || '') + '</td></tr>'; }).join('') + '</table>' : '<p>Aucune.</p>');
    return { html: h, meta: [['Opportunités ouvertes', ops.length], ['Alertes', A.length]] };
  }
  function pdfRapport() {
    if (!w.EXBRapport) { say('Module d’export PDF indisponible.', 'error'); return null; }
    var R = rapportHtml(); audit('crm.export', 'pdf', {});
    return w.EXBRapport.print('Rapport CRM — alertes et pipeline', { sousTitre: 'Situation au ' + today(), meta: R.meta, html: R.html, note: 'Lecture seule : calculé à partir des opportunités, relances et réclamations enregistrées.', paysage: true });
  }
  function vSyn(b) {
    var A = alertes(), canW = can('crm', 'ecrire') || can('exb_clients', 'ecrire'), col = { critique: '#fde8e8', haute: '#fff0cc', moyenne: '#eef2f8' };
    b.innerHTML = '<h4>Alertes de direction</h4>' + (A.length ? A.map(function (a) { return '<div style="padding:4px 0"><span style="background:' + (col[a.niveau] || '#eef2f8') + ';border-radius:6px;padding:1px 6px;font-size:12px">' + esc(a.niveau) + '</span> ' + esc(a.texte) + '</div>'; }).join('') : '<p style="color:#64748b">Aucune alerte.</p>') +
      '<p>' + (canW ? btn('sy_imp', '⬇ Importer les prospects de l’ancien CRM') : '') + btn('sy_csv', '⬇ Export Excel (CSV)') + btn('sy_pdf', '🖨 Rapport PDF') + '</p><p style="font-size:12px;color:#64748b">Les retards s’affichent à l’ouverture de l’écran (aucune notification poussée). L’import ne crée qu’une opportunité par prospect, sans montant ; relancer l’import n’ajoute pas de doublon.</p>';
    if ($('sy_imp')) $('sy_imp').onclick = function () { var n = importProspects(); say(n ? n + ' prospect(s) importé(s).' : 'Aucun nouveau prospect à importer.', 'info'); render(); };
    $('sy_pdf').onclick = function () { try { pdfRapport(); } catch (e) { say('Export PDF impossible.', 'error'); } };
    $('sy_csv').onclick = function () { try { var bl = new Blob([toCsv()], { type: 'text/csv;charset=utf-8' }), a = d.createElement('a'); a.href = URL.createObjectURL(bl); a.download = 'crm-' + today() + '.csv'; d.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(a.href); }, 500); audit('crm.export', 'csv', {}); } catch (e) { say('Export impossible.', 'error'); } };
  }

  w.EXBCRMPLUS = { open: open, _t: { rapportHtml: rapportHtml, pdfRapport: pdfRapport, alertes: alertes, importProspects: importProspects, toCsv: toCsv, saveOpp: saveOpp, moveOpp: moveOpp, pipeline: pipeline, addFollow: addFollow, doneFollow: doneFollow, followStatus: followStatus, snapshot: snapshot, compare: compare, toContract: toContract, setContractStatus: setContractStatus, addClaim: addClaim, advanceClaim: advanceClaim, addSatisf: addSatisf, satisfStats: satisfStats, versionsOf: versionsOf } };
  if (d) { if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else setTimeout(start, 0); }
})(typeof window !== 'undefined' ? window : globalThis);
