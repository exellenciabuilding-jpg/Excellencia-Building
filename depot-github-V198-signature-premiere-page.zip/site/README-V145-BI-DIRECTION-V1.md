# Excellencia BI — Direction (v1)

Module 01 du cahier des charges ERP (priorité de développement). Menu : **📈 BI Direction** (à côté de « Budget & pilotage »).
Lecture seule : aucune donnée modifiée, aucun SQL. Retrait : supprimer `<script src="exb-bi.js">` dans `index.html`.

## Dictionnaire des indicateurs (à valider)
| Indicateur | Règle | Source |
| --- | --- | --- |
| Facturé | Total TTC des factures non annulées dont la date est dans la période | exb_invoices |
| Encaissé | Encaissements de la période, registre unique sans doublon (facture, caisse, paiements V93) | EXBLIEN.ledger |
| Dépenses | Sorties de caisse de la période | exb_cash (type out) |
| Résultat de trésorerie | Encaissé − Dépenses | calculé |
| Créances clients | Soldes restant dus de toutes les factures non annulées, à ce jour | exb_invoices |
| Dont échues | Part des créances dont l'échéance est dépassée | exb_invoices |

Règles communes : montants séparés par devise (USD / FC), jamais convertis ; factures annulées exclues ; filtres période (mois, trimestre, année, 12 mois, tout) et projet.

## Fonctions
- Chaque indicateur est cliquable : liste des opérations sources et total.
- Graphique encaissé / dépenses sur 12 mois, par devise.
- Export Excel (CSV) et impression PDF ; l'export et l'impression sont inscrits au journal d'audit du noyau CORE.
- Contrôle de rapprochement factures / paiements affiché en haut ; alerte si des encaissements ressemblent à des doublons.

## Vérifié
Jeu d'essai (2 factures USD dont 1 payée en partie, 1 facture FC annulée, 1 dépense, 1 acompte) : facturé 1 460 $, encaissé 450 $, dépenses 150 $, résultat 300 $, créances 1 060 $, échues 760 $ — conforme au calcul à la main. Aucune erreur JS.

## Pas encore couvert (à décider avec vous)
Indicateurs par département, budgets et écarts par projet, avancement physique, alertes automatiques, rapports périodiques planifiés, conversion de devises au taux du jour.
