# V152 — Administration avancée (14) + rattachement Scanner (13)

## Ajouté
- `exb-admin.js` (nouveau, balise après `exb-scanner.js`, précache `sw.js`) : bouton « 🛡 Administration avancée » sous le menu Administration, réservé aux administrateurs (ou mode local).
  - Audit : liste (100 dernières), filtre, vérification de la chaîne SHA-256, export CSV (cellules protégées contre l'injection de formules). Ouverture, vérification et export sont eux-mêmes journalisés.
  - Droits : lecture / écriture effectives de la session, par collection.
  - Accès & santé : version, utilisateur, appareil, connexion, dernière sauvegarde, intégrité du journal.
- `exb-scanner.js` : `source` du document déposé dans Archives contient désormais `projetId` / `clientId` quand le nom saisi correspond à exactement une fiche (sans accents ni casse). Aucun rattachement en cas d'ambiguïté.
- Retrait : supprimer la balise `exb-admin.js`. Aucun SQL.

## Vérifié (Chromium, banc minimal avec le vrai `exb-core.js`)
Bouton monté, liste, vérification de chaîne OK, filtre, CSV (`=cmd` neutralisé), matrice, onglet santé, 0 erreur JS. Rattachement : 3 cas testés (correspondance, doublon ambigu, inconnu).

## Non fait
- OCR (Tesseract.js ou ML Kit à fournir avec l'application : pas de réseau ici), correction de perspective, import de PDF existants.
- Gestion des comptes d'autres utilisateurs, sessions/appareils distants, délégations, revue périodique, suspension : dépendent du serveur Supabase.
- Journal d'audit limité à 500 entrées locales (limite du noyau CORE).
- Non testé : application complète derrière la connexion, vrai téléphone. `tools/test-scanner.js` exige `/home/claude/p.jpg` (absent de l'archive).
