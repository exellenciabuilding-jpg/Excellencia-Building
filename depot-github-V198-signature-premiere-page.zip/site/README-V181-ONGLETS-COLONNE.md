# V181 — Onglets en colonne latérale ou barre du bas (comme la barre des modules)

Fichier modifié : `exb-onglets.js` (+ V180 : modules raccordés), `sw.js` (cache `v181-…`).

Dans tous les modules, les onglets ne s'affichent plus en rangée en haut :
- **À gauche** (par défaut sur grand écran) : colonne bleu nuit, onglet actif en blanc avec trait doré, titre et contenu à droite.
- **En bas** (par défaut sur téléphone) : barre qui reste accrochée au bas de la fenêtre pendant le défilement.
- **En haut** : l'ancienne rangée, sur une seule ligne défilante.
- **« / »** : réduit la colonne en icônes seules (172 → 52 px) et la rouvre.
- **Bouton de position** (⇄ ◧ ⬓ ⬒) : Auto → Gauche → Bas → Haut. « Auto » suit le réglage ⚙ de la barre des modules (À gauche / En bas), sinon la largeur de l'écran. Couleurs reprises de cette barre.
- Choix mémorisé sur l'appareil (`exb_onglets_v1`). Flèches du clavier pour passer d'un onglet à l'autre.
- Aucune logique de module modifiée : un clic dans la colonne déclenche le même onglet qu'avant.

Tests : `node tests/test-onglets-v181.js` (gauche, bas, réduit, position, mémorisation, clic réel, Finances à 10 onglets) ; V179 et V180 passent aussi (ils forcent la position « haut »).

## V182 — toutes les barres passent ainsi
- Barres de 2 onglets (Métré, Studio d'affiches) : aussi en colonne / en bas.
- Suivi des paiements des participants (`#exbPayBar`) et Workflow (le bouton « Nouveau dossier » sort de la ligne d'onglets) : raccordés.
- Demandes en ligne : les raccourcis vers les autres modules restent en boutons ; les onglets du panneau (Licences, Chantiers…) passent en colonne.
- Messagerie (panneau plein écran en colonne) : onglets en barre du bas, le fil garde sa hauteur et défile.
- Un clic n'importe où range de nouveau les barres du module qui vient de s'afficher (en plus d'un contrôle toutes les 1,5 s).
- Non concernés : le menu principal / barre des modules (déjà à gauche ou en bas), les filtres en pastilles du portail public, et la navigation propre aux pages séparées (espace apprenant, TFL portail).
