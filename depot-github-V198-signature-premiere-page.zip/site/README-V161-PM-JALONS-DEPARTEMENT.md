# V161 — Jalons du planning (module 02) et département (BI, module 01)

## Département (BI)
- Fiche projet : nouveau champ **Département** (suggestions : Direction, Ingénierie, Construction, Gestion & finances, Formation, Infrastructure ; saisie libre).
- BI Direction : filtre **Département** (affiché dès qu'un projet en a un). Un filtre actif ne retient que les opérations rattachées à un projet de ce département (factures, encaissements, dépenses, bons de commande, tableau des projets). Casse et espaces ignorés.
- Correctif : l'enregistrement d'une fiche projet **reconstruisait** l'objet et effaçait tout champ non présent dans le formulaire. Il fusionne désormais avec l'existant (aucun champ perdu).

## Jalons (Project Manager)
- Planning & budget › Gantt › bloc **🚩 Jalons du projet** : nom, tâche liée (n°) ou semaine fixe (n° 0), case « atteint ».
- Jalon lié à une tâche = fin de cette tâche : suit le planning et le retard prévisionnel (moteur `exb-cpm.js`, `EXBCPM.jalons`).
- Statuts : atteint (coché ou tâche à 100 %) · en retard (semaine prévue passée) · menacé (prévision après la semaine prévue) · à venir. Sans date de début de planning, jamais « en retard ».
- Suppression d'une tâche : les jalons liés sont renumérotés ; celui de la tâche supprimée passe en semaine fixe.
- BI : alertes « Jalon » (en retard = à traiter, menacé = à surveiller), détail par projet, section « Jalons » dans l'export CSV.

## Vérifié
- `node tools/test-jalons.js` : 18 contrôles. `node tools/test-bi-dettes.js` : 24 contrôles (dettes, engagements, département, jalons dans la BI).
- Chromium (session de test, client de test) : enregistrement projet avec département, rechargement du formulaire, champ supplémentaire conservé après modification, création de jalons, statuts affichés, renumérotation après suppression de tâche, filtre Département visible dans la BI, 0 erreur JavaScript.

## Non vérifié / limites
- Alerte de jalon vue dans l'écran BI complet (testée par calcul seulement) ; impression PDF ; synchronisation Supabase ; téléphone réel.
- Les jalons ne sont pas encore dans le PDF du planning ni dans le portail client.
- `tools/check.js` et `tools/test-bi.js` sont absents de l'archive : leurs contrôles n'ont pas pu être relancés.
- Reste (module 02) : engagements budgétaires par projet, report automatique pointage → RH et matériaux → Stock, dossier de clôture. Reste (module 01) : tableau configurable, lecture RH/Stock/CRM/Workflow.
