# V163 — Dossier de clôture du projet (module 02, suite)

## Ce qui est ajouté
- **Planning & budget › onglet 🏁 Clôture** : contrôles de clôture, bilan chiffré, clôture, réouverture, PDF.
- **Points bloquants** (⛔) : tâches du planning non terminées · bons de commande non reçus ou non payés · factures du projet non soldées.
- **Alertes** (⚠️, ne bloquent pas) : jalons non atteints · dépassement de budget ou de poste · pas de planning ni de budget · caisse imputée supérieure au coût réel · bons de commande ou factures en FC (non convertis).
- **Clôturer** : sans point bloquant, une confirmation suffit. Avec des points bloquants, un **motif est obligatoire** (clôture « forcée », marquée comme telle). Une photo du bilan est conservée dans `exb_clotures`. La fiche projet reçoit `cloture_le`.
- **Rouvrir** : motif obligatoire ; la fiche de clôture est conservée (historique), un projet peut être reclôturé.
- **PDF « Dossier de clôture »** : bilan, tous les contrôles, motif forcé et leçons retenues.
- Lecture seule des autres modules : planning, budget, RH et Stock ne sont pas modifiés.

## Règles à valider
- Un projet sans planning, sans budget ou sans bon de commande n'est pas bloqué (alerte seulement).
- Les montants en FC ne sont pas convertis : signalés, jamais comptés.
- Pas de rôle « réservé au directeur » pour clôturer : tout utilisateur ayant accès à l'écran peut le faire.

## Vérifié
- `node tools/test-cloture.js` : 52 contrôles. `test-jalons.js` (18) et `test-bi-dettes.js` (41) toujours OK.
- Chromium (`python3 tools/e2e-cloture.py`) : onglet visible, tâche à 50 % bloquante, clôture refusée sans motif, clôture forcée enregistrée, réouverture, 0 erreur JavaScript.

## Non vérifié / limites
- PDF généré (non ouvert) ; synchronisation Supabase ; téléphone réel ; archivage automatique du PDF dans Archives (actif seulement si le réglage Archives est activé).
- La clôture ne bloque pas les nouvelles saisies sur un projet clôturé (affichage seulement).
- Reste (module 02) : report automatique pointage → RH et matériaux → Stock ; éventuel blocage Workflow d'un achat au-delà du budget.
