/* V193/V194 — Reçu de paiement des frais (étudiants TFL, apprenants inscription/formation) au format « carte paysage » : double cadre, filigrane, photo,
 * champs à gauche, N° de reçu + date + QR de vérification + code à droite, motif / montant en rouge, cases de signature.
 * Un seul gabarit pour l'espace étudiant (tfl-portail.html) et l'écran administrateur (exb-tfl.js).
 * API : EXBRecuTFL.html(o) → page HTML complète (A4 paysage) · EXBRecuTFL.visaPublic() → Promise<dataURL cachet+signature publiés> ·
 *       EXBRecuTFL.dataUrl(src) → Promise<dataURL> (logo). Tout le texte est échappé. */
(function (w) {
  'use strict';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function img(u) { return /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(String(u || '')) ? String(u) : ''; }
  function row(k, v) { return '<tr><th>' + esc(k) + '</th><td>: ' + esc(v || '—') + '</td></tr>'; }
  /* filigrane répété (texte en diagonale) — image SVG intégrée, aucun fichier externe */
  var WM = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="230" height="150"><text x="115" y="80" text-anchor="middle" font-family="Arial,sans-serif" font-weight="700" font-size="24" fill="#c9ced6" fill-opacity=".55" transform="rotate(-38 115 75)">EXCELLENCIA</text></svg>');
  var CSS = '@page{size:A4 landscape;margin:8mm}*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}html,body{margin:0;background:#fff}body{font-family:Arial,Helvetica,sans-serif;color:#111}'
    + '.rc{position:relative;width:281mm;height:194mm;border:1.1mm double #111;padding:5mm 8mm 5mm;background:#fff url("' + WM + '") repeat;overflow:hidden;page-break-inside:avoid;margin:0 auto}'
    + '.top{display:flex;justify-content:space-between;align-items:flex-start;height:43mm}.top .tl,.top .tr{flex:0 0 62mm}.top .tr{display:flex;justify-content:flex-end}.org{flex:1 1 auto;text-align:center;font-weight:700;font-size:22pt;letter-spacing:.3mm;margin-top:7mm}'
    + '.lg{display:block;height:39mm;max-width:60mm;object-fit:contain;margin:0 0 0 4mm}.ph{width:28mm;height:31mm;object-fit:cover;border:.3mm solid #999;background:#eef1f5;display:block}.ph0{width:28mm;height:31mm;border:.3mm dashed #aab;display:block}'
    + '.gc{font-size:13pt;text-align:center;margin:0}.ti{text-align:center;font-weight:700;font-size:24pt;margin:5mm 0 3mm;letter-spacing:.2mm}'
    + '.bx{display:flex;border:.35mm dashed #333;margin:0 6mm;padding:3mm 4mm;min-height:60mm;background:rgba(255,255,255,.55)}.bx .l{flex:1 1 0;min-width:0}.bx table{border-collapse:collapse}.bx th{text-align:left;font-size:13.5pt;padding:.7mm 5mm .7mm 0;white-space:nowrap;width:42mm}.bx td{font-size:14.5pt;padding:.7mm 0;overflow-wrap:anywhere}'
    + '.bx .r{flex:0 0 78mm;border-left:.35mm dashed #e0c400;padding-left:4mm;text-align:center}.no{color:#d00000;font-weight:700;font-size:13.5pt;text-align:left;white-space:nowrap}.dt{font-weight:700;font-size:13pt;text-align:left;margin-bottom:1.5mm}.qr svg,.qr img{width:36mm;height:36mm;display:block;margin:0 auto}'
    + '.cd{display:inline-flex;border:.3mm solid #333;margin-top:1.5mm}.cd span{width:5.6mm;height:6.4mm;line-height:6.4mm;border-right:.3mm solid #333;font-size:11.5pt;text-align:center}.cd span:last-child{border-right:0}'
    + '.bt{display:flex;margin:2.5mm 6mm 0;gap:6mm}.bt .a{flex:1 1 0}.bt .b{flex:0 0 118mm}.bt .ln{font-size:13.5pt;margin:.8mm 0;white-space:nowrap}.bt b.k{display:inline-block;min-width:42mm}.red{color:#d00000;font-weight:700}'
    + '.op{font-size:13.5pt;font-weight:700;margin-top:3mm}.op .red{display:block;margin:2mm 0 0 10mm}'
    + '.sg{display:flex;border:.4mm solid #111;height:30mm;margin-top:3mm;background:rgba(255,255,255,.7)}.sg div{flex:1 1 0;padding:2.5mm 4mm;font-size:12pt;position:relative}.sg div+div{border-left:.4mm solid #111}.sg img{position:absolute;right:4mm;bottom:1.5mm;max-height:23mm;max-width:46mm}'
    + '.sg .gn{display:block;font-weight:700;font-size:11.5pt;margin-top:2mm}.ft{position:absolute;left:8mm;bottom:3mm;font-size:8pt;color:#555}';
  function html(o) {
    o = o || {};
    var code = String(o.code || '').slice(0, 10), cells = code.split('').map(function (c) { return '<span>' + esc(c) + '</span>'; }).join('');
    var logo = img(o.logo), photo = img(o.photo), visa = img(o.visa), qr = String(o.qr || '');
    if (/^data:image\/(png|jpe?g|gif|webp);base64,/i.test(qr)) qr = '<img src="' + qr + '" alt="">'; else if (!/^\s*<svg[\s>]/i.test(qr)) qr = '';
    var org = esc(o.org || 'Excellencia Building');
    var left = (o.lignes && o.lignes.length) ? o.lignes.map(function (l) { return row(l[0], l[1]); }).join('') : (row('Étudiant', o.nom) + row('Matricule', o.matricule) + row('Faculté', o.faculte) + row('Département', o.filiere) + row('Promotion', o.promotion)
      + (o.sexe ? row('Sexe', o.sexe) : '') + row('Payé le', o.datePaiement) + row('Banque', o.mode) + row('No. Transaction', o.reference));
    return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Reçu ' + esc(o.no) + '</title><style>' + CSS + '</style></head><body><div class="rc">'
      + '<div class="top"><div class="tl">' + (logo ? '<img class="lg" src="' + logo + '" alt="">' : '') + '</div><div class="org">' + org + '</div><div class="tr">' + (photo ? '<img class="ph" src="' + photo + '" alt="">' : '<span class="ph0"></span>') + '</div></div>'
      + '<div class="gc">' + esc(o.guichet || 'GUICHET D’APUREMENT DES FRAIS') + '</div><div class="ti">' + esc(o.titre || 'REÇU DE PAIEMENT DES FRAIS') + '</div>'
      + '<div class="bx"><div class="l"><table>' + left + '</table></div><div class="r"><div class="no">Reçu N° ' + esc(o.no) + '</div><div class="dt">Date : ' + esc(o.dateEmission) + '</div>'
      + (qr ? '<div class="qr">' + qr + '</div>' : '') + (cells ? '<div class="cd">' + cells + '</div>' : '') + '</div></div>'
      + '<div class="bt"><div class="a">' + (o.libAnnee === '' ? '' : '<div class="ln"><b class="k">' + esc(o.libAnnee || 'Année Académique') + '</b> <span class="red">: ' + esc(o.annee || '—') + '</span></div>') + '<div class="op">Opérateur<span class="red">' + esc(o.operateur || '') + '</span></div></div>'
      + '<div class="b">' + ((o.bas && o.bas.length) ? o.bas.map(function (l) { return '<div class="ln"><b>' + esc(l[0]) + '</b> <span class="red">: ' + esc(l[1]) + '</span></div>'; }).join('') : '<div class="ln"><b>Motif</b> <span class="red">&nbsp;&nbsp;: ' + esc(o.motif || '—') + '</span></div><div class="ln"><b>Montant</b> <span class="red">: ' + esc(o.montant) + '</span></div>') + ''
      + '<div class="sg"><div>' + esc(o.libEtudiant || 'Etudiant') + '</div><div>Guichetier' + (o.guichetier ? '<span class="gn">' + esc(o.guichetier) + '</span>' : '') + (visa ? '<img src="' + visa + '" alt="">' : '') + '</div></div></div></div>'
      + '</div></body></html>';
  }
  function dataUrl(src) {
    return new Promise(function (ok) {
      try { var im = new Image(); im.onload = function () { try { var c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); ok(c.toDataURL('image/png')); } catch (e) { ok(''); } }; im.onerror = function () { ok(''); }; im.src = src; } catch (e) { ok(''); }
    });
  }
  /* cachet + signature du Directeur publiés (Site vitrine › Publier) : lus tels quels, jamais inventés ; vide si rien n'est publié */
  function visaPublic() {
    var RK = 'EXB_VISA_REMOTE', cached = ''; try { cached = w.localStorage.getItem(RK) || ''; } catch (e) {}
    var c = w.EXB_SUPABASE || {};
    if (!c.url || typeof w.fetch !== 'function') return Promise.resolve(img(cached));
    return w.fetch(String(c.url).replace(/\/+$/, '') + '/storage/v1/object/public/vitrine/visa.png?t=' + Date.now()).then(function (r) { if (!r.ok) throw 0; return r.blob(); })
      .then(function (b) { return new Promise(function (ok, ko) { var fr = new FileReader(); fr.onload = function () { ok(String(fr.result)); }; fr.onerror = ko; fr.readAsDataURL(b); }); })
      .then(function (u) { if (!img(u)) throw 0; try { w.localStorage.setItem(RK, u); } catch (e) {} return u; }).catch(function () { return img(cached); });
  }
  /* V194 — reçu d'inscription / de formation (espace apprenant et logiciel) au même modèle.
   * r = { no, date, formation, participant, matricule, debut, lieu, distinction, inscription:{montant,statut}, formation_frais:{montant,statut}, guichetier, code, qr, logo, visa, photo }
   * Les lignes s'adaptent aux informations de la formation : une ligne n'apparaît que si elle est renseignée. */
  function jour(d) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(d || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] : String(d || ''); }
  function codeUrl(u) { try { var raw = decodeURIComponent((String(u || '').split('c=')[1] || '').split('&')[0]); return (raw.split('~')[5] || '').toUpperCase(); } catch (e) { return ''; } }
  function depuisApprenant(r) {
    r = r || {}; var fi = r.inscription || {}, ff = r.formation_frais || {}, L = [], B = [];
    function add(a, k, v) { if (v != null && String(v).trim() !== '') a.push([k, String(v)]); }
    add(L, 'Participant', r.participant); add(L, 'Matricule', r.matricule); add(L, 'Formation', r.formation); add(L, 'Début', jour(r.debut)); add(L, 'Lieu', r.lieu); add(L, 'Distinction', r.distinction); add(L, 'Payé le', jour(r.date));
    if (fi.montant) B.push(['Frais d’inscription', String(fi.montant) + (fi.statut ? ' · ' + fi.statut : '')]);
    if (ff.montant) B.push(['Frais de formation', String(ff.montant) + (ff.statut ? ' · ' + ff.statut : '')]);
    return { no: r.no, dateEmission: jour(r.date), lignes: L, bas: B, libAnnee: '', libEtudiant: 'Participant', operateur: r.guichetier || 'Administration Excellencia Building', guichetier: r.guichetier || '',
      code: r.code || codeUrl(r.url), qr: r.qr, logo: r.logo, visa: r.visa, photo: r.photo };
  }
  /* V197 — vrai PDF (A4 paysage, 1 page) généré dans le navigateur, sans fenêtre ni .html : le reçu est dessiné (HTML → image) puis posé dans un PDF.
   * Hors connexion, aucune ressource externe. Promise<Blob>. */
  function bytes(s) { var u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255; return u; }
  function pdfDe(jpg, pw, ph) {
    var PW = 841.89, PH = 595.28, mm = 72 / 25.4, W = 281 * mm, H = 194 * mm, X = (PW - W) / 2, Y = (PH - H) / 2, ch = [], pos = 0, off = [];
    function P(x) { var u = typeof x === 'string' ? bytes(x) : x; ch.push(u); pos += u.length; }
    function O(n, head, stream) { off[n] = pos; P(n + ' 0 obj\n' + head); if (stream) { P('\nstream\n'); P(stream); P('\nendstream'); } P('\nendobj\n'); }
    var cs = 'q ' + W.toFixed(2) + ' 0 0 ' + H.toFixed(2) + ' ' + X.toFixed(2) + ' ' + Y.toFixed(2) + ' cm /I0 Do Q';
    P('%PDF-1.4\n'); O(1, '<< /Type /Catalog /Pages 2 0 R >>'); O(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
    O(3, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW + ' ' + PH + '] /Resources << /XObject << /I0 4 0 R >> >> /Contents 5 0 R >>');
    O(4, '<< /Type /XObject /Subtype /Image /Width ' + pw + ' /Height ' + ph + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + jpg.length + ' >>', jpg);
    O(5, '<< /Length ' + cs.length + ' >>', bytes(cs));
    var xr = pos, x = 'xref\n0 6\n0000000000 65535 f \n'; for (var j = 1; j <= 5; j++) x += ('0000000000' + off[j]).slice(-10) + ' 00000 n \n';
    P(x + 'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n' + xr + '\n%%EOF'); return new Blob(ch, { type: 'application/pdf' });
  }
  function pdfBlob(o) {
    return new Promise(function (ok, ko) {
      try {
        var d = new w.DOMParser().parseFromString(html(o), 'text/html'), root = d.createElement('div'), stl = d.querySelector('style');
        if (!d.body || !d.body.firstChild) throw new Error('reçu vide');
        var CW = 1062, CH = 734, K = 3;
        root.setAttribute('style', 'width:' + CW + 'px;height:' + CH + 'px;background:#fff;font-family:Arial,Helvetica,sans-serif;color:#111');
        if (stl) { stl.textContent = stl.textContent.replace(/@page\{[^}]*\}/g, ''); root.appendChild(stl); }
        while (d.body.firstChild) root.appendChild(d.body.firstChild);
        /* XHTML bien formé (le QR est un <svg> en ligne) : sérialisation XML obligatoire dans un <foreignObject> */
        var xml = new w.XMLSerializer().serializeToString(root);
        var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + CW * K + '" height="' + CH * K + '" viewBox="0 0 ' + CW + ' ' + CH + '"><foreignObject x="0" y="0" width="' + CW + '" height="' + CH + '">' + xml + '</foreignObject></svg>';
        var im = new Image();
        im.onload = function () {
          try {
            var c = w.document.createElement('canvas'); c.width = CW * K; c.height = CH * K; var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
            var u = c.toDataURL('image/jpeg', 0.93), b = w.atob(u.split(',')[1]); ok(pdfDe(bytes(b), c.width, c.height));
          } catch (e) { ko(e); }
        };
        im.onerror = function () { ko(new Error('rendu du reçu')); };
        im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
      } catch (e) { ko(e); }
    });
  }
  w.EXBRecuTFL = { html: html, visaPublic: visaPublic, dataUrl: dataUrl, depuisApprenant: depuisApprenant, pdfBlob: pdfBlob };
})(window);
