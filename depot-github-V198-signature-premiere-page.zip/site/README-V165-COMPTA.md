# V165 — Finances & comptabilité (module 15) : avoirs, échéanciers, journal, clôture

Nouveau fichier : `exb-compta.js` (balise après `exb-ocr.js`, précache `sw.js`). Bouton « 📒 Compta : avoirs, échéances, journal » sous « Budget & pilotage » (ou « Comptabilité »). Aucune facture, caisse ni paiement existant n'est modifié.

## Ce que ça fait
- **Avoirs** : émis depuis une facture (total ou partiel), numérotés `AV-AAAA-NNNN`, motif obligatoire, plafond = TTC de la facture − avoirs déjà émis. Annulation (jamais suppression) avec motif. Si le client a déjà trop payé, un message signale le remboursement à prévoir. Net à payer = TTC − avoirs − paiements.
- **Échéanciers** : N échéances égales (mois ou jours) ou lignes saisies ; le total doit égaler le TTC net d'avoirs. Statut calculé (payée / à venir / bientôt ≤ 7 j / en retard + jours de retard) en affectant paiements et avoirs aux échéances par date. Bandeau d'alerte des retards.
- **Journal, balance, grand livre** : écritures **calculées** à la demande (jamais stockées) depuis factures, paiements, avoirs, factures fournisseurs (`exb_v92_supplier_invoices`) et caisse (`exb_cash`). Journaux VT / AC / CA. Contrôle débit = crédit, filtre devise / période / journal, export CSV (anti-injection de formules).
- **Clôture mensuelle** : empreinte SHA-256 des écritures du mois ; « Vérifier » signale toute modification postérieure ; réouverture avec motif. Ne bloque pas les saisies des autres modules.
- Actions journalisées dans l'audit CORE (`compta.*`).

## Données (nouvelles clés, synchronisées comme les autres clés `exb_*`)
`exb_credit_notes`, `exb_pay_schedules`, `exb_compta_close`.

## Hypothèses à valider avec votre comptable
- Plan comptable indicatif de type SYSCOHADA (411, 401, 701, 709, 4431, 571, 521, 601, 604, 613, 616, 618, 623, 626, 641, 661, 658, 758). Le paramétrage comptable et fiscal RDC reste à valider localement.
- Règlement par « Espèces » → 571 ; tout autre mode → 521. Dépense de caisse classée par mots du libellé (loyer, salaire, ciment…), sinon 658.
- Facture fournisseur : charge 601 / dette 401, sans TVA (le champ n'existe pas dans le module Achats). Un décaissement de caisse dont la référence (`ref`) = n° ou id de la facture fournisseur solde le 401 au lieu de créer une charge.
- Encaissements de factures : pris dans la facture ; les lignes de caisse liées (`invoice_id` / `pay_id`) sont ignorées pour éviter les doublons.
- Chaque devise est séparée, sans conversion (USD, FC…).

## Vérifié (Chromium, banc avec données fictives)
Avoir (plafond, motif, facture annulée, numérotation), échéancier (somme, statuts, retards), journal équilibré, pas de doublon caisse/facture, règlement fournisseur, clôture → vérification OK puis « modifié » après ajout d'un paiement, réouverture, interface (4 onglets, formulaire d'avoir, grand livre), 0 erreur JS.

## Non fait / non vérifié
- Application complète derrière la connexion, données réelles, téléphone, impression PDF du journal.
- Pas encore : TVA récupérable sur achats, rapprochement bancaire dans le journal, écritures de paie, amortissements, états financiers (bilan / compte de résultat), blocage des saisies sur une période clôturée.
- Droits : contrôle `factures/ecrire` côté écran uniquement (comme le reste de l'application).
