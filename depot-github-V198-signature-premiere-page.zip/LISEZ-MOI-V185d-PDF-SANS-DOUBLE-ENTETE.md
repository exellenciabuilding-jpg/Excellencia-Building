# V185d — PDF : plus de double en-tête (logo + coordonnées)

Constat (Rapport de direction, mais pas seulement) : le PDF portait deux fois l'identité : le bandeau bleu « logo + EXCELLENCIA BUILDING + coordonnées » ET le bloc blanc « logo + nom + slogan + coordonnées + QR ».

Cause : `site/docengine/bridge.js` ajoute un bandeau d'en-tête à toute impression qui passe par `EXBPrint.html`, sauf pour les reçus, bordereaux, suivis de paiements et attestations. Les pièces qui construisent déjà leur propre en-tête (module commun `exb-rapport-marque.js`, en-tête V81 de la paie…) recevaient donc un second en-tête.

Correctifs :
1. `bridge.js` : nouvelle détection `hasOwnHeader` — si le nom de l'entreprise figure déjà en tête de la pièce (début du contenu visible), aucun bandeau n'est ajouté. Valable pour TOUS les titres.
2. `exb-rapport-marque.js` (`build`) et `exb-bi.js` (repli) : l'en-tête de marque porte maintenant le marqueur `data-exb-habillage`.
3. `exb-plans-publics.js` : l'affiche QR (qui a son propre bandeau) est imprimée avec `nativeLayout`.
4. Tests : 4 cas ajoutés à `docengine-server/tests/bridge-habillage.test.js` (14/14 OK).

PDF concernés (corrigés) : Rapport de direction, Journal d'audit, États financiers, Bilan, Journal et balance, État de paie (V81 et standard), Rapport CRM, État du stock, Bulletins / Cotisations / Contrats (en-tête V81), Rapport d'avancement (pilotage), Affiche QR des plans publics, Suivi des paiements des apprenants.
Inchangés (un seul en-tête déjà) : reçus, bordereaux, cartes, plans/cartouches, Gantt, résultats QCM, documents du moteur commun (EXBDoc).

## Étiquette de version
`site/exb-core.js` : l'étiquette affichée en bas du logiciel passe de « V166c-CORE » à « V185d-CORE » (elle n'avait pas été mise à jour depuis la V166c). Après installation, le pied de page doit afficher **Version : V185d-CORE** ; sinon les anciens fichiers sont encore utilisés (vider le cache / réinstaller).
