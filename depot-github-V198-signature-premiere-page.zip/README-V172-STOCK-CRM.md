# V172 — Stock (dépôts, inventaires, comparatifs) et CRM (pipeline, relances, réclamations)

Deux modules **additifs** (nouvelles clés de stockage, aucune donnée existante modifiée sauf l'ajustement d'inventaire, tracé). Boutons ajoutés sous « Stock » (📦) et « Clients » (🤝).

## Stock — `exb-stock-plus.js`
- **Dépôts & transferts** : « Principal » + dépôts créés. Le total par article reste celui du Stock ; le solde par dépôt est calculé. Transfert refusé si solde insuffisant ; annulation avec motif, refusée si des transferts ultérieurs utilisent la quantité.
- **Inventaires** : comptage par dépôt, brouillon enregistrable ; validation = chaque écart exige un motif, puis mouvement in/out (réf. INV-…) dans le stock existant. Inventaire validé non modifiable.
- **Comparatifs** : ≥ 2 offres, moins-disant signalé ⭐ ; retenir un autre fournisseur exige un motif.
- **Rapprochement** (lecture seule) : commandé → reçu → facturé (factures fournisseurs rattachées par n° de BC) → payé, avec alertes (reçu partiel, reçu non facturé, facturé > reçu, payé > reçu).

## CRM — `exb-crm-plus.js`
- **Pipeline** : Prospect → Qualifié → Devis envoyé → Négociation → Gagné / Perdu ; historique ; motif obligatoire pour « Perdu » et pour rouvrir ; montants par devise ; valeur pondérée ; taux de conversion.
- **Relances & RDV** : statut à venir / aujourd'hui / en retard / fait ; résultat obligatoire à la clôture.
- **Devis** : versions figées (motif obligatoire dès la v2, refus si aucun changement), comparaison, conversion en contrat (un seul par devis), marquage « signé ». Les devis eux-mêmes ne sont jamais modifiés.
- **Réclamations** : ouverte → en cours → résolue → clôturée (pas de saut d'étape ; résolution et confirmation client obligatoires).
- **Satisfaction** : note 1–5, moyenne.

Clés ajoutées : exb_stock_depots, exb_stock_transfers, exb_stock_counts, exb_stock_consults, exb_crm_opps, exb_crm_followups, exb_quote_versions, exb_crm_contracts, exb_crm_claims, exb_crm_satisf.
Tests : logique (≈45 vérifications) + interface sous Chromium, 0 erreur JS. Non testé : données réelles, téléphone, session connectée (droits `EXBDB.can`).
Retrait : supprimer les 2 balises `<script>` (index.html) — les données restent.
