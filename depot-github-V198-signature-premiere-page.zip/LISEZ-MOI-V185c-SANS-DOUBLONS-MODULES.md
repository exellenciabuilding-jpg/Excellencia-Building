# V185c — plus de modules en double (Entreprise / Infrastructure numérique)

Constat : Documents, Archives, Scanner, Données & installation, Continuité et Journal d'audit s'affichaient à la fois dans la page « Entreprise » et dans la page « Infrastructure numérique ».

Cause : `openCat()` (page d'une catégorie) listait tous les écrans de la catégorie, sans tenir compte du reclassement `DIV_ITEM` vers l'Infrastructure numérique, alors que `openDiv()` le respectait.

Correctif (`site/exb-v99r-shell.js`, seul fichier modifié) :
- nouvelle fonction `catList(k)` : les écrans classés `dv_inf` n'apparaissent plus dans les pages de catégorie ;
- `openCat()` et `go()` utilisent `catList` (mêmes index, pas de décalage au clic) ;
- fil d'Ariane : depuis ces écrans, « ← Infrastructure numérique » ramène à la bonne page.

Aucun module, aucune donnée ni fonction n'est modifié : seul l'affichage du menu change.

## Complément — division « Ingénierie et construction » (et autres divisions)
- La règle est générale : tout écran reclassé par `DIV_ITEM` vers une division (Intelligence BTP, Maintenance / Facility, Permis & autorisations, Pièces écrites → Ingénierie et construction ; RH, Portails → Gestion ; QCM, Import inscriptions → Formation) ne s'affiche plus dans la page de sa catégorie d'origine (Entreprise).
- La barre horizontale des modules (`renderModBar`) utilise la même liste que `go()` : plus de décalage au clic.
- Le fil d'Ariane renvoie à la division de l'écran.
- Dans les catégories Architecture / Ingénierie / Projets, aucun doublon : le bouton « Plan de maison » et « Éditeur de plans » ouvrent le même écran (`planEditeur`), compté une seule fois.
