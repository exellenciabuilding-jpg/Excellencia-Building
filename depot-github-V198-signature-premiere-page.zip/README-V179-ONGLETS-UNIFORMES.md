# V179 — onglets identiques et adaptables dans tous les modules

**Problème** (capture « Finances & comptabilité ») : les 10 onglets passaient sur deux lignes, et chaque module dessinait ses onglets à sa façon.

**Correction** : nouveau fichier `site/exb-onglets.js` (chargé en dernier). Il reconnaît toutes les barres d'onglets et leur donne le même comportement :
- une seule ligne, qui défile au doigt / à la molette s'il y a trop d'onglets (on peut en ajouter sans casser la page) ;
- l'onglet actif est recentré automatiquement et repéré partout pareil (gras + trait doré) ;
- dégradé sur le bord quand des onglets sont cachés ; flèches ← → au clavier ; rôles d'accessibilité.

| Module | Barre traitée |
|---|---|
| Finances & comptabilité (10 onglets, + futurs onglets ajoutés par d'autres fichiers) | `.cpt_tabs` |
| Administration avancée | `.adm_tabs` |
| CRM | `.crp_tabs` |
| Stock & approvisionnement | `.stp_tabs` |
| Budget & pilotage | `.bf-tabs` |
| Contrôles qualité/sécurité, Décomptes | `.exb-tabs` (classe ajoutée) |
| Métrés | `.mbtabs` |
| Centre de gestion V51 | `.exb-v51-tabs` |
| Portails & signatures | `.pt-tabs` |
| Messagerie | `#exbMsgr .tabs` |
| Paiements des apprenants | `#exbPayBar` |
| Archives, Workflow | `.exb-tabs` (classe ajoutée ; « Nouveau dossier » reste fixe à droite) |

Non modifiés volontairement : le menu principal (`#app .tabs`), le ruban de l'éditeur type Word (`#exbEdTabs`), la barre du bas du portail TFL.
Pour un futur module : lui donner la classe `exb-tabs`.

Fichiers modifiés : `site/exb-onglets.js` (nouveau), `index.html`, `sw.js` (cache + version v179), `exb-controles.js`, `exb-decompte.js`, `exb-archives.js`, `exb-workflow.js`.
Tests : `node site/tools/check.js` : 583/583 · `node tests/test-onglets-v179.js` (téléphone, tablette, bureau + 8 types de modules).
