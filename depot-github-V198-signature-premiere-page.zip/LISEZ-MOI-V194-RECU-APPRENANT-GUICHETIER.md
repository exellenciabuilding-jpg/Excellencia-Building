# V194 — Reçu d'inscription / de formation au modèle + nom du guichetier

Base : V193. **Un SQL à exécuter** : `site/supabase/migration-v194-guichetier.sql` (Supabase › SQL Editor, une seule fois, après le bloc 5 partie 4). Il ne concerne que le TFL. **Refaire l'installateur Windows** pour embarquer la V194.

## Ce qui change
1. **Espace apprenant › Mes reçus › Télécharger PDF** et **logiciel › Reçus de paiement › Exporter PDF** produisent le reçu au format « REÇU DE PAIEMENT DES FRAIS » (carte paysage, double cadre, filigrane, QR + code en cases, cachet et signature publiés, photo de l'apprenant dans son espace). Le gabarit est le même que celui du TFL (`site/exb-recu-tfl.js`).
2. **Adapté aux formations** : à gauche, Participant, Matricule, Formation, Début, Lieu, Distinction, Payé le (une ligne n'apparaît que si elle est renseignée) ; en bas à droite, « Frais d'inscription » et « Frais de formation » avec leur état (PAYÉ / MOITIÉ PAYÉE / NON PAYÉ), seulement s'ils existent sur le reçu. Pas d'« Année académique » (elle n'existe pas pour une formation).
3. **Nom du guichetier** : imprimé dans « Opérateur » et dans la case de signature « Guichetier ». Sans nom (anciens reçus, anciens paiements TFL) : « Administration Excellencia Building ».
   - **Logiciel** : nouveau champ « Guichetier (personne qui encaisse) » dans la fiche du reçu ; mémorisé sur l'appareil ; synchronisé vers l'espace apprenant avec le reçu (pas de SQL pour cette partie).
   - **TFL** : champ « Guichetier » au-dessus des paiements de la fiche dossier ; **obligatoire pour confirmer** un paiement ou enregistrer un paiement de caisse ; enregistré par le serveur (colonne `guichetier`) avec, en plus, le compte connecté (`guichetier_email`, relevé par le serveur, non modifiable, non affiché). Effacé si le paiement est refusé ou remis en attente.

## À savoir
- Le bouton ⬇ « Télécharger PDF » ouvre maintenant l'aperçu du reçu avec « Imprimer / PDF » (comme le reçu TFL ; Windows : PDF créé directement). L'ancien PDF reste en secours si le gabarit ne charge pas.
- L'aperçu à l'écran du reçu dans le logiciel (zone de prévisualisation) garde son ancienne apparence ; seul l'export PDF change.
- Le nom du guichetier est celui saisi : il n'est pas lié à un compte du logiciel (aucun nom d'utilisateur n'existe dans le logiciel).
- Pour le cachet et la signature : publier le visa (Site vitrine › Publier), comme avant.
- Le SQL retire les anciennes versions de `tfl_paiement_admin_decider` / `tfl_paiement_admin_ajouter` (nouvelle signature avec `p_guichetier`). Exécuter le SQL **avant** de déployer cette version (sinon la confirmation d'un paiement TFL échoue).

## Contrôles
`node site/tools/check.js` ; `node site/tools/test-tfl/test-bloc5.js` (mis à jour : guichetier) ; `python3 site/tools/e2e-recu-apprenant-modele.py` ; `python3 site/tools/e2e-recu-tfl-modele.py`.

## Limites
Rendu vérifié dans Chromium (PDF 1 page A4 paysage, gabarit seul). Non testé : vrai Supabase (le SQL n'a pas été exécuté sur une base réelle), Windows, Android, parcours complet derrière la connexion. L'installateur Windows n'a pas été reconstruit ici.

## Fusion avec la V192b (rattachement des pièces)
Cette version contient aussi la V192b (`exb-v81-pieces.js` : « Rattachée à » dès la création, choix « Sans chantier » mémorisé). Cache : `v194-…-v192b-…`. Contrôles : `check.js` 635 réussis, 0 échec ; `test-bloc5.js` OK ; `e2e-pieces-rattachement.py` OK.

## Retouche d'en-tête (tous les reçus du gabarit, TFL compris)
Logo agrandi (27 mm → 39 mm de haut), nom « Excellencia Building » centré en gras dans l'en-tête, ligne « GUICHET D'APUREMENT DES FRAIS » centrée. Photo inchangée, à droite.
