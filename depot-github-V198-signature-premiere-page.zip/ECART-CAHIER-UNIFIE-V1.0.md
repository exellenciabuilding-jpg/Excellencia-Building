# Écart entre le Cahier des charges général unifié V1.0 (nov. 2026) et la version V166b

Méthode : lecture des 13 pages, puis recherche dans `site/*.js`, les écarts déjà documentés (`ECART-CAHIER-DES-CHARGES-ERP-v1.1.md`) et les README. **Rien n'a été exécuté sur vos données réelles** ; « présent » = du code correspondant existe, pas qu'il est validé en production. Les recherches de mots-clés sont indicatives : « non constaté » ≠ « absent à coup sûr ».
Légende : ✅ présent · 🟡 partiel / à confirmer · ❌ non constaté

## Ce que le document unifié change par rapport aux deux sources
- EXCELLENCIA CORE devient le **nom officiel du noyau** : fait (exb-core.js, journal d'audit, écran d'audit V166b).
- Règle « devis ≠ paiement » (§4) : le paiement est un objet distinct (`exb_v93_payments`) ✅ ; à tester de bout en bout.
- Règle « pas de double comptabilisation / reprises idempotentes » : 🟡 idempotence présente sur certains transferts (liaisons, terrain), pas démontrée partout.
- Les 5 divisions (§1) sont un regroupement d'affichage : ✅ fait en V168 : menu organisé en 5 divisions (voir LISEZ-MOI-V168-CORRECTIFS-E2E.md).

## Modules (15)
| # | Module | État | Ce qui manque (priorité cahier) |
|---|---|---|---|
| 01 | BI | 🟡 | Tableau configurable par l'utilisateur ; lecture RH/Stock/CRM/Workflow ; alertes à seuils. Dictionnaire KPI ✅ (exb-bi.js). Règle « pas de chiffre non validé » : à afficher (statut de fiabilité par KPI) |
| 02 | Project Manager | ✅/🟡 | Blocage/validation Workflow au-delà du budget (règle à décider) |
| 03 | Plan Editor | ✅/🟡 | DWG : rangement seulement |
| 04 | CRM | 🟡 | Pipeline d'opportunités, relances/rendez-vous, versions de devis, réclamations, satisfaction |
| 05 | HR | 🟡 | Compétences liées au dossier ; export éléments variables vers paie validée |
| 06 | Stock & Procurement | 🟡 | Transferts entre dépôts, inventaires/ajustements justifiés, demandes d'achat, comparatifs fournisseurs, rapprochement commande/réception/facture |
| 07 | Workflow | ✅ | Délégations et rappels automatiques à confirmer |
| 08 | Archives | ✅/🟡 | Droits côté écran seulement ; dépôt direct depuis Plan Editor / Project Manager |
| 09 | TFL & Académie | ✅/🟡 | Préparation de soutenance (statut seulement) ; deux espaces « formations classiques » / « parcours TFL » à séparer |
| 10 | Certificats | ✅ | Statut « suspendu » vs « annulé » ; traitement par lot |
| 11 | Server | 🟡 | Supervision, reprise des traitements, alertes de disponibilité |
| 12 | Licences | ✅ | — |
| 13 | Scanner | 🟡 | Moteur OCR non livré ; correction de perspective ; import PDF |
| 14 | Administration | 🟡 | Sessions/appareils distants, revue périodique des accès, suspension d'autres comptes (serveur) |
| 15 | Finances & Compta | ✅/🟡 | V165–V166 : avoirs, échéanciers, journaux, clôture, TVA, résultat, bilan simplifié, verrou. Manque : **écritures de paie**, TVA sur factures fournisseurs saisies dans Achats, règles fiscales RDC à valider |

## Architecture et sécurité (§2, 6, 7)
| Exigence | État |
|---|---|
| Identifiant stable unique par objet | 🟡 `EXBCore.id/ensureId` existe ; non appliqué à tous les modules |
| Échanges par API/événements versionnés, journalisés | 🟡 bus d'événements local v1 + audit chaîné ; pas d'API serveur entre modules |
| Aucun module n'écrit dans la base d'un autre | ❌ non contrôlé (accès direct au stockage commun) |
| Environnements dev / préprod / prod séparés ; démo séparée de la production | ❌ organisation hors code ; démo à confirmer |
| Permissions : consulter, créer, modifier, soumettre, approuver, rejeter, exporter, partager, archiver, administrer | ✅/🟡 V166c : matrice par profil, appliquée au Workflow (approuver/rejeter/soumettre) et à tous les exports ; partager/archiver (Archives) pas encore appliqués |
| Limitation par module, action, département, projet, propriété | 🟡 module et action ; département/projet/propriété partiels |
| MFA comptes privilégiés | ✅ exb-mfa.js |
| Journalisation des actions sensibles | ✅ journal chaîné (collections sensibles) ; reste local à l'appareil, 500 lignes |
| Sauvegardes automatiques chiffrées + test de restauration | ✅ **corrigé V166c** : sauvegarde téléchargée chiffrée (AES-GCM) et test de restauration existaient (V81) ; 🟡 les copies automatiques internes restent en clair sur l'appareil |
| RPO / RTO | ✅ V166c : écran « 🛟 Continuité », objectifs par criticité comparés aux sauvegardes réelles (valeurs par défaut à valider) |
| Contrôle d'intégrité avant/après migration | ✅ V166c : contrôle + état de référence + comparaison |
| Pagination / filtres côté serveur | 🟡 150 lignes + « Afficher plus », pas de filtre serveur |
| Exports PDF/Excel soumis aux permissions et journalisés | ✅ V166c : point d'entrée unique, droit « exporter », journalisé |
| Formats dates/nombres/devises/unités configurables | 🟡 partiel |
| Mode hors ligne : indicateur de synchro, résolution de conflits, reprise | 🟡 stockage local ✅ ; résolution de conflits non constatée |
| Cloisonnement réel des données (RLS) | ❌ côté écran seulement |
| Copilot IA (recherche documents, résumés, alertes) | 🟡 assistants existants ; validation humaine à encadrer |
| Benchmark KPIGO | ❌ (le cahier dit : facultatif, à tester par démonstration) |
| Géolocalisation (P2) | 🟡 widgets seulement |

## Décisions du §12 encore à prendre (bloquantes pour certains lots)
Hébergement (central / cloud / hybride) · base et stockage documentaire · nombre d'utilisateurs, sites, volumes · **règles comptables et fiscales RDC** · RPO/RTO et conservation · périmètre du premier lot BI · formats PDF/DXF/DWG/IFC réellement garantis · fonctions hors ligne et règles de synchro.

## Ordre proposé (aligné sur P0–P3 du cahier)
1. ~~P0 : RPO/RTO, intégrité, test de restauration~~ → fait V166c.
2. **P1** : droits d'action sur Archives (partager/archiver) ; CRM (pipeline, relances, versions de devis) ; Stock (transferts, inventaires, demandes d'achat) ; écritures de paie (après décision comptable).
3. **P1/P2** : synchronisation du journal d'audit vers Supabase ; RLS ; conflits hors ligne.
4. **P3** : BI configurable + statut de fiabilité des KPI ; Copilot encadré ; KPIGO.
