# V185b — correctifs des 3 erreurs « Cette action n'a pas pu aboutir »

## 1. « Cannot read properties of undefined (reading 'slice') » et « (reading 'forEach') »
**Cause** : deux modules écrivaient dans la même clé `exb_core_audit` avec deux formats différents
(`core/index.js` V91 : tableau de lignes ; `exb-core.js` V166c : objet `{ base, list }`).
Dès qu'un tableau V91 était présent, `auditStore.list` devenait `undefined` → plantage au
« Lancer le contrôle », au rapport PDF de Continuité, au journal d'audit, etc.

**Correctif** (`site/exb-core.js`) :
- le journal chaîné a sa propre clé `exb_core_chain` (le tableau V91 n'est plus touché) ;
- le contenu stocké est validé au chargement (sinon repart d'un journal vide) ;
- un ancien journal chaîné valide trouvé sous `exb_core_audit` est repris.
Aucune donnée métier n'est modifiée.

## 2. « Failed to execute 'importScripts' on 'WorkerGlobalScope': The URL 'vendor/tesseract/worker.min.js' is invalid »
**Cause** : Tesseract lance son worker depuis un blob ; un chemin RELATIF y est invalide.
**Correctif** (`site/exb-ocr.js`) : URL absolues (`workerPath`, `corePath`, `langPath`, `tesseract.min.js`)
et `workerBlobURL:false`.

## Divers
- `site/sw.js` : version du cache augmentée (les postes reçoivent les fichiers corrigés).
- Test de non-régression : `node tests/test-core-journal-ocr.js` ; `node site/tools/check.js` → 585 contrôles, 0 échec.
- Aucun nouveau SQL dans cette livraison.
