/* Test du report contrôlé pointage → RH / matériel → Stock (exb-report-ops.js). node tools/test-report-ops.js */
const R = require('../site/exb-report-ops.js'); global.EXBRO = R; global.EXBCPM = require('../site/exb-cpm.js'); const CL = require('../site/exb-cloture.js'); let ok = 0, ko = 0;
function eq(a, b, m) { if (JSON.stringify(a) === JSON.stringify(b)) ok++; else { ko++; console.log('KO', m, JSON.stringify(a), '≠', JSON.stringify(b)); } }
const hr = [{ id: 'H1', name: 'Paul' }, { id: 'H2', name: 'Jean' }];
const ts = [{ id: 'T1', worker_id: 'H1', worker_name: 'Paul', project_id: 'P1', date: '2026-11-02', days: 1 }, { id: 'T2', worker_id: 'H2', worker_name: 'Jean', project_id: 'P1', date: '2026-11-02', days: 0.5 },
  { id: 'T3', worker_id: 'H9', worker_name: 'Inconnu', project_id: 'P1', date: '2026-11-03', days: 1 }, { id: 'T4', worker_id: 'H1', worker_name: 'Paul', project_id: 'P2', date: '2026-11-02', days: 1 },
  { id: 'T5', worker_id: 'H1', worker_name: 'Paul', project_id: 'P1', date: '', days: 1 }, { id: 'T6', worker_id: 'H1', worker_name: 'Paul', project_id: 'P1', date: '2026-11-04', days: 3 }];
let ap = R.apercuPointages(ts, hr, [], 'P1');
eq(ap.compte, { a_reporter: 2, deja: 0, sans_fiche: 1, doublon: 0, invalide: 2 }, 'aperçu : 2 à reporter, 1 sans fiche, 2 invalides'); eq(ap.lignes.length, 5, 'autre projet exclu');
eq(ap.lignes.find(l => l.ts === 'T3').statut, 'sans_fiche', 'ouvrier inconnu : rien deviné');
// report
let r = R.reporterPointages([], ap, ['T1', 'T2', 'T3'], { pid: 'P1', par: 'Ana', now: '2026-11-15T10:00:00Z' });
eq(r.crees.length, 2, 'T3 (sans fiche) non reporté même sélectionné'); eq(r.presences[0].cle, 'TS:T1', 'clé de rapprochement'); eq(r.presences[0].source, 'pointage', 'source'); eq(r.presences[0].par, 'Ana', 'auteur');
// idempotence
ap = R.apercuPointages(ts, hr, r.presences, 'P1'); eq(ap.compte.deja, 2, 'déjà reportés'); eq(ap.compte.a_reporter, 0, 'plus rien à reporter');
eq(R.reporterPointages(r.presences, ap, ['T1', 'T2'], { pid: 'P1' }).crees.length, 0, 'second report : aucun doublon');
const ap2 = R.apercuPointages(ts, hr, [], 'P1'); eq(R.reporterPointages(r.presences, ap2, ['T1'], { pid: 'P1' }).presences.length, 2, 'garde-fou sur la clé même avec un aperçu périmé');
// doublon ouvrier/jour
const ts2 = ts.concat([{ id: 'T7', worker_id: 'H1', worker_name: 'Paul', project_id: 'P1', date: '2026-11-02', days: 1 }]);
ap = R.apercuPointages(ts2, hr, [], 'P1'); eq(ap.lignes.find(l => l.ts === 'T7').statut, 'doublon', 'même jour, même ouvrier : doublon'); eq(ap.lignes.find(l => l.ts === 'T1').statut, 'a_reporter', 'le premier reste reportable');
eq(r.presences.length, 2, 'entrée non modifiée'); eq(JSON.stringify(R.reporterPointages(r.presences, ap, [], {}).presences), JSON.stringify(r.presences), 'rien choisi : rien écrit');
// annulation
eq(R.annulerPresence(r.presences, r.presences[0].id, '', {}).ok, false, 'motif obligatoire'); let an = R.annulerPresence(r.presences, r.presences[0].id, 'Erreur de saisie', { par: 'Ana', now: '2026-11-16T00:00:00Z' });
eq(an.ok, true, 'annulation'); eq(an.presences[0].annule.motif, 'Erreur de saisie', 'motif conservé'); eq(R.annulerPresence(an.presences, r.presences[0].id, 'x', {}).ok, false, 'double annulation refusée');
eq(R.apercuPointages(ts, hr, an.presences, 'P1').compte.a_reporter, 1, 'après annulation : de nouveau reportable'); eq(R.annulerPresence(r.presences, 'nul', 'x', {}).ok, false, 'report introuvable');
// stock
const stk = [{ id: 'S1', name: 'Ciment', unit: 'sac', qty: 100 }], mv = [];
let s = R.sortieMateriel(stk, mv, { item: 'S1', qty: 30, pid: 'P1', id: 'MV1', date: '2026-11-15', par: 'Ana' });
eq(s.ok, true, 'sortie'); eq(s.stock[0].qty, 70, 'quantité diminuée'); eq(s.moves[0].project_id, 'P1', 'lié au projet'); eq(stk[0].qty, 100, 'entrée non modifiée');
eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: 5, pid: 'P1', id: 'MV1' }).ok, false, 'même identifiant refusé (double traitement)');
eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: 71, pid: 'P1', id: 'MV2' }).ok, false, 'stock insuffisant refusé'); eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: 70, pid: 'P1', id: 'MV3' }).stock[0].qty, 0, 'sortie du stock entier autorisée');
eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: 0, pid: 'P1', id: 'MV4' }).ok, false, 'quantité nulle'); eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: -3, pid: 'P1', id: 'MV4' }).ok, false, 'quantité négative');
eq(R.sortieMateriel(s.stock, s.moves, { item: 'S9', qty: 1, pid: 'P1', id: 'MV4' }).ok, false, 'article inconnu'); eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: 1, id: 'MV4' }).ok, false, 'sans projet'); eq(R.sortieMateriel(s.stock, s.moves, { item: 'S1', qty: 1, pid: 'P1' }).ok, false, 'sans identifiant');
eq(R.consommation(s.moves, s.stock, 'P1'), [{ item: 'S1', nom: 'Ciment', unite: 'sac', qty: 30 }], 'consommation du projet'); eq(R.consommation(s.moves, s.stock, 'P2'), [], 'autre projet : rien');
let a2 = R.annulerSortie(s.stock, s.moves, 'MV1', '', {}); eq(a2.ok, false, 'motif obligatoire'); a2 = R.annulerSortie(s.stock, s.moves, 'MV1', 'Retour au dépôt', { par: 'Ana', now: '2026-11-16T00:00:00Z' });
eq(a2.ok, true, 'annulation sortie'); eq(a2.stock[0].qty, 100, 'stock rétabli'); eq(a2.moves.length, 2, 'contre-mouvement ajouté'); eq(a2.moves[1].type, 'in', 'contre-mouvement = entrée');
eq(R.consommation(a2.moves, a2.stock, 'P1'), [], 'consommation nette après annulation'); eq(R.annulerSortie(a2.stock, a2.moves, 'MV1', 'x', {}).ok, false, 'double annulation refusée'); eq(R.annulerSortie(a2.stock, a2.moves, 'MV-ANN-MV1', 'x', {}).ok, false, 'on n\'annule pas un contre-mouvement');
// clôture : alerte pointages
const base = { project: { id: 'P1', name: 'V', progress: 100 }, today: '2026-11-15', timesheets: ts, hr, presences: [] };
let c = CL.analyse(base); eq(c.controles.find(x => x.id === 'pointages').etat, 'alerte', 'clôture : alerte pointages non reportés'); eq(c.pret, true, 'ne bloque pas'); eq(c.bilan.pointages.a_reporter, 2, 'bilan pointages');
base.presences = r.presences; c = CL.analyse(base); eq(c.controles.find(x => x.id === 'pointages').detail.includes('1 sans fiche'), true, 'après report : reste le pointage sans fiche, signalé');
// report automatique
const tA = [{ id: 'A0', worker_id: 'H1', worker_name: 'Paul', project_id: 'P1', date: '2026-10-01', days: 1 }]; // ancien : dans la base
const tB = tA.concat([{ id: 'A1', worker_id: 'H2', worker_name: 'Jean', project_id: 'P1', date: '2026-11-10', days: 1 }, { id: 'A2', worker_id: 'H9', worker_name: 'X', project_id: 'P1', date: '2026-11-10', days: 1 }, { id: 'A3', worker_id: 'H1', worker_name: 'Paul', project_id: 'P2', date: '2026-11-10', days: 0.5 }, { id: 'A4', worker_id: 'H1', worker_name: 'Paul', project_id: 'P1', date: '2026-10-01', days: 1 }]);
let au = R.reporterAuto(tB, hr, [], ['A0'], { now: '2026-11-15T10:00:00Z' });
eq(au.crees.map(p => p.cle).sort(), ['TS:A1', 'TS:A3'], 'auto : nouveaux valides de tous les projets ; ancien (base), sans fiche et doublon exclus'); eq(au.crees[0].par, 'automatique', 'auteur = automatique');
eq(new Set(au.crees.map(p => p.id)).size, au.crees.length, 'identifiants uniques entre projets');
eq(R.reporterAuto(tB, hr, au.presences, ['A0'], {}).crees.length, 0, 'auto : idempotent');
const an2 = R.annulerPresence(au.presences, au.crees[0].id, 'Erreur', {}); eq(R.reporterAuto(tB, hr, an2.presences, ['A0'], {}).crees.length, 0, 'auto : un report annulé à la main n\'est pas refait');
eq(R.apercuPointages(tB, hr, an2.presences, 'P1').compte.a_reporter >= 1, true, 'annulé : reste reportable à la main');
eq(R.reporterAuto(tB, hr, [], tB.map(t => t.id), {}).crees.length, 0, 'tout dans la base : rien'); eq(R.reporterAuto([], hr, [], [], {}).crees.length, 0, 'aucun pointage');
console.log(ko ? ko + ' échec(s)' : 'OK : ' + ok + ' contrôles'); process.exit(ko ? 1 : 0);
