/* Reçu de paiement identique logiciel / espace apprenant : node tools/test-recu-papier.js */
const fs = require('fs'), path = require('path');
require('../site/exb-recu-papier.js');
const R = globalThis.EXBRecuPapier, site = f => fs.readFileSync(path.join(__dirname, '../site', f), 'utf8');
let ok = 0, ko = 0; const t = (n, c) => { if (c) ok++; else { ko++; console.log('ÉCHEC :', n); } };
const adm = { receipt_no: 'REC-0001', training: 'Génie civil', participant: 'Jean K.', program: 'A\nB', registration_fee: '10 USD', registration_status: 'PAYÉ', training_fee: '150 USD', training_status: 'MOITIÉ PAYÉE', start_date: '10/08/2026', location_room: 'Salle A', distinction: 'Certificat', reservation_phone: '+243', director: 'Dir' };
// enregistrement synchronisé : mêmes champs que la ligne `d.recus` d'index.html
const syn = { no: 'REC-0001', participant: 'Jean K.', programme: 'A\nB', lieu: 'Salle A', distinction: 'Certificat', reservation: '+243', directeur: 'Dir', formation: 'Génie civil', debut: '10/08/2026', inscription: { montant: '10 USD', statut: 'PAYÉ' }, formation_frais: { montant: '150 USD', statut: 'MOITIÉ PAYÉE' }, url: 'https://x/v?c=1' };
t('le module sait poser cachet + signature (visa)', /visa/.test(fs.readFileSync(path.join(__dirname, '../site/exb-recu-papier.js'), 'utf8')) && R.normalize({ visa: 'data:image/png;base64,AA' }).visa === 'data:image/png;base64,AA');
const a = R.fromAdmin(adm, 'https://x/v?c=1'), b = R.fromSynced(syn, 'Autre nom');
t('mêmes données logiciel / apprenant', JSON.stringify(a) === JSON.stringify(b));
t('nom de l’apprenant par défaut', R.fromSynced(Object.assign({}, syn, { participant: '' }), 'Nom Espace').participant === 'Nom Espace');
const idx = site('index.html'), esp = site('espace-apprenant.html'), sw = site('sw.js');
t('index.html charge exb-recu-papier.js', /<script src="exb-recu-papier\.js"><\/script>/.test(idx));
t('espace-apprenant.html charge exb-recu-papier.js', /<script src="exb-recu-papier\.js"><\/script>/.test(esp));
t('sw.js met le module en cache', sw.indexOf("'./exb-recu-papier.js'") > -1);
['programme:x.program', 'lieu:x.location_room', 'distinction:x.distinction', 'reservation:x.reservation_phone', 'directeur:x.director', 'participant:x.participant'].forEach(k => t('synchronisation : ' + k, idx.indexOf(k) > -1));
t('export logiciel utilise le gabarit partagé', /EXBRecuPapier\.blob\(data\)/.test(idx));
t('export logiciel pose le visa (EXBSign.visa)', /EXBSign\.visa\("png"\)/.test(idx));
t('téléchargement apprenant pose le visa (EXBSign.anyVisa)', /EXBSign\.anyVisa\("png"\)/.test(esp));
t('téléchargement apprenant utilise le gabarit partagé', /EXBRecuPapier\.fromSynced/.test(esp) && /EXBRecuPapier\.blob/.test(esp));
t('même nom de fichier (N°.pdf)', /receipt_no\.value\+"\.pdf"/.test(idx) && /String\(r\.no\)\.replace\([^)]*\)\+"\.pdf"/.test(esp));
console.log(ok + ' contrôles OK, ' + ko + ' échec(s)'); process.exit(ko ? 1 : 0);
