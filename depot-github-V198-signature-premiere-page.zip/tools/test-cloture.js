/* Test du dossier de clôture (exb-cloture.js). node tools/test-cloture.js */
const C = require('../site/exb-cloture.js'); const CPM = require('../site/exb-cpm.js'); global.EXBCPM = CPM; let ok = 0, ko = 0;
function eq(a, b, m) { if (JSON.stringify(a) === JSON.stringify(b)) ok++; else { ko++; console.log('KO', m, JSON.stringify(a), '≠', JSON.stringify(b)); } }
const P = { id: 'P1', name: 'Villa', progress: 100, budget: 1000 };
const base = () => ({ project: P, today: '2026-11-15',
  gantt: { date: '2026-09-01', tasks: [{ start: 1, dur: 2, pct: 100 }, { start: 3, dur: 2, pct: 100, pred: '1' }], jalons: [{ name: 'Réception', task: 2 }] },
  budget: { postes: [{ b: 600, r: 550 }, { b: 400, r: 400 }] },
  po: [{ project_id: 'P1', lines: [{ q: 10, pu: 20, rec: 10 }], payments: [{ amount: 200 }] }],
  invoices: [{ project_id: 'P1', lines: [{ q: 1, pu: 1000 }], tva: 0, payments: [{ amount: 1000 }] }],
  cash: [{ type: 'out', project_id: 'P1', amount: 900 }] });
let a = C.analyse(base());
eq(a.pret, true, 'projet complet = prêt'); eq(a.bloquants, 0, 'aucun bloquant'); eq(a.alertes, 0, 'aucune alerte');
eq(a.bilan.budget.ecart, -50, 'écart négatif = économie'); eq(a.bilan.taches, { total: 2, finies: 2 }, 'tâches'); eq(a.bilan.jalons.atteints, 1, 'jalon atteint');
// tâche non terminée
let s = base(); s.gantt.tasks[1].pct = 50; a = C.analyse(s); eq(a.pret, false, 'tâche à 50 % bloque'); eq(a.controles.find(x => x.id === 'taches').etat, 'bloquant', 'contrôle tâches');
// bon de commande non reçu / non payé
s = base(); s.po[0].lines[0].rec = 4; a = C.analyse(s); eq(a.bilan.bc.reste, 120, 'reste à recevoir'); eq(a.controles.find(x => x.id === 'bc').etat, 'bloquant', 'BC non reçu');
s = base(); s.po[0].payments = [{ amount: 100 }]; a = C.analyse(s); eq(a.bilan.bc.aPayer, 100, 'reste à payer'); eq(a.pret, false, 'BC non payé bloque');
s = base(); s.po[0].cancel = true; a = C.analyse(s); eq(a.bilan.bc.nb, 0, 'BC annulé ignoré'); eq(a.pret, true, 'sans BC actif : prêt');
s = base(); s.po[0].project_id = 'P2'; a = C.analyse(s); eq(a.bilan.bc.nb, 0, 'BC d\'un autre projet ignoré');
s = base(); s.po[0].currency = 'FC'; a = C.analyse(s); eq(a.bilan.bc.horsUsd, 1, 'BC en FC signalé'); eq(a.bilan.bc.commande, 0, 'FC non compté'); eq(a.controles.find(x => x.id === 'bc_fc').etat, 'alerte', 'alerte FC');
s = base(); s.po[0].lines[0].rec = 99; a = C.analyse(s); eq(a.bilan.bc.recu, 200, 'reçu plafonné à la commande');
// factures
s = base(); s.invoices[0].payments = [{ amount: 400 }]; a = C.analyse(s); eq(a.bilan.factures.solde, 600, 'à encaisser'); eq(a.controles.find(x => x.id === 'factures').etat, 'bloquant', 'facture impayée');
s = base(); s.invoices[0].tva = 16; s.invoices[0].payments = [{ amount: 1000 }]; a = C.analyse(s); eq(a.bilan.factures.solde, 160, 'TVA comptée dans le solde');
s = base(); s.invoices[0].annule = true; a = C.analyse(s); eq(a.bilan.factures.nb, 0, 'facture annulée ignorée');
// budget
s = base(); s.budget.postes[0].r = 700; a = C.analyse(s); eq(a.controles.find(x => x.id === 'budget').etat, 'alerte', 'dépassement = alerte'); eq(a.pret, true, 'dépassement seul ne bloque pas');
s = base(); delete s.budget; a = C.analyse(s); eq(a.bilan.budget, null, 'sans budget : rien inventé'); eq(a.controles.find(x => x.id === 'budget').etat, 'alerte', 'alerte sans budget');
s = base(); s.cash[0].amount = 2000; a = C.analyse(s); eq(!!a.controles.find(x => x.id === 'caisse'), true, 'caisse > réel signalée');
s = base(); delete s.gantt; a = C.analyse(s); eq(a.bilan.taches, null, 'sans planning'); eq(a.pret, true, 'sans planning : alerte seulement');
s = base(); s.gantt.jalons = [{ name: 'X', task: 0, week: 3 }]; a = C.analyse(s); eq(a.controles.find(x => x.id === 'jalons').etat, 'alerte', 'jalon non atteint = alerte');
// clôture
a = C.analyse(base()); let r = C.cloturer([], 'P1', a, { par: 'Ana', now: '2026-11-15T10:00:00Z', notes: 'RAS' });
eq(r.ok, true, 'clôture ok'); eq(r.rec.date, '2026-11-15', 'date'); eq(r.rec.forcee, false, 'non forcée'); eq(C.etat(r.list, 'P1').par, 'Ana', 'état clôturé');
eq(C.cloturer(r.list, 'P1', a, {}).ok, false, 'double clôture refusée');
s = base(); s.gantt.tasks[1].pct = 0; let b = C.analyse(s);
eq(C.cloturer([], 'P1', b, {}).ok, false, 'bloquants sans motif : refusé'); eq(C.cloturer([], 'P1', b, { motif: '   ' }).ok, false, 'motif blanc refusé');
r = C.cloturer([], 'P1', b, { motif: 'Accord direction', now: '2026-11-15T10:00:00Z' }); eq(r.ok, true, 'forcée avec motif'); eq(r.rec.forcee, true, 'marquée forcée'); eq(r.rec.bloquants.length, 1, 'bloquants conservés');
eq(C.cloturer([], '', a, {}).ok, false, 'sans projet');
// réouverture
eq(C.rouvrir(r.list, 'P1', '', {}).ok, false, 'motif obligatoire'); eq(C.rouvrir([], 'P1', 'x', {}).ok, false, 'non clôturé');
let ro = C.rouvrir(r.list, 'P1', 'Réserves à lever', { par: 'Ana', now: '2026-11-20T08:00:00Z' }); eq(ro.ok, true, 'réouverture'); eq(C.etat(ro.list, 'P1'), null, 'plus clôturé'); eq(ro.list.length, 1, 'fiche conservée'); eq(ro.list[0].rouvert.motif, 'Réserves à lever', 'motif conservé');
eq(r.list[0].rouvert, undefined, 'liste d\'origine non modifiée');
eq(C.cloturer(ro.list, 'P1', a, { now: '2026-12-01T00:00:00Z', id: 'CL2' }).ok, true, 'reclôture possible'); eq(C.cloturer(ro.list, 'P1', a, { now: '2026-12-01T00:00:00Z', id: 'CL2' }).list.length, 2, 'historique : 2 fiches');
eq(C.etat(r.list, 'P2'), null, 'autre projet non clôturé');
console.log(ko ? ko + ' échec(s)' : 'OK : ' + ok + ' contrôles'); process.exit(ko ? 1 : 0);
