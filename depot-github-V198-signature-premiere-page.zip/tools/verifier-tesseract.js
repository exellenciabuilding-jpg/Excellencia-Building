#!/usr/bin/env node
/* V175 — Vérifie que les fichiers du moteur OCR (Tesseract.js) sont bien présents dans site/vendor/tesseract/.
 * Usage : node tools/verifier-tesseract.js   (depuis la racine du dépôt)
 * Ne télécharge rien. Affiche ce qui manque, avec le paquet npm d'où copier chaque fichier. */
const fs = require('fs'), path = require('path');
const dir = path.resolve(__dirname, '..', 'site', 'vendor', 'tesseract');
const NEED = [
  ['tesseract.min.js', 'tesseract.js', 'dist/tesseract.min.js'],
  ['worker.min.js', 'tesseract.js', 'dist/worker.min.js'],
  ['tesseract-core.wasm.js', 'tesseract.js-core', 'tesseract-core.wasm.js'],
  ['tesseract-core-simd.wasm.js', 'tesseract.js-core', 'tesseract-core-simd.wasm.js'],
  ['fra.traineddata.gz', '@tesseract.js-data/fra', '4.0.0_best_int/fra.traineddata.gz'],
  /* V175 : le moteur LSTM (réglage par défaut du logiciel) charge CES variantes — constaté en test réel : sans elles, la lecture échoue */
  ['tesseract-core-simd-lstm.wasm.js', 'tesseract.js-core', 'tesseract-core-simd-lstm.wasm.js'],
  ['tesseract-core-lstm.wasm.js', 'tesseract.js-core', 'tesseract-core-lstm.wasm.js'],
];
const OPT = [];
let miss = 0;
console.log('Dossier : ' + dir + (fs.existsSync(dir) ? '' : '  (ABSENT — à créer)'));
for (const [f, pkg, src] of NEED) {
  const p = path.join(dir, f), ok = fs.existsSync(p) && fs.statSync(p).size > 1000;
  if (!ok) miss++;
  console.log((ok ? '  ✓ ' : '  ✗ ') + f.padEnd(34) + (ok ? Math.round(fs.statSync(p).size / 1024) + ' Ko' : 'MANQUANT → ' + pkg + '/' + src));
}
for (const [f, pkg, why] of OPT) console.log((fs.existsSync(path.join(dir, f)) ? '  ✓ ' : '  · ') + f.padEnd(34) + '(facultatif : ' + why + ')');
console.log(miss ? '\n' + miss + ' fichier(s) manquant(s) : l’OCR affichera « à installer ». Voir README-V153-OCR.md et README-V175-DWG-OCR.md.' : '\nFichiers présents. Testez ensuite le bouton « 🔤 Lire le texte (OCR) » du Scanner avec un vrai document (non vérifié ici : moteur absent).');
process.exit(miss ? 1 : 0);
