/* Tests du moteur Scanner (module 13) : node tools/test-scanner.js */
const E = require('../site/exb-scanner.js').engine;
const fs = require('fs');
let ok = 0, ko = 0; function t(n, c) { if (c) ok++; else { ko++; console.log('ÉCHEC :', n); } }
// types
t('facture', E.guessType('Facture Villa') === 'facture'); t('plan R+1', E.guessType('plan R+1') === 'plan'); t('accents', E.guessType('Réception chantier') === 'pv');
t('note de calcul', E.guessType('Note de calcul dalle') === 'note'); t('inconnu', E.guessType('xyz') === 'autre'); t('service facture', E.guessService('facture') === 'finance'); t('service autre', E.guessService('autre') === '');
// cadre
function img(w, h, bg, fg, r) { const D = new Uint8ClampedArray(w * h * 4); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = (y * w + x) * 4, inside = x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1, v = inside ? fg : bg; D[i] = D[i + 1] = D[i + 2] = v; D[i + 3] = 255; } return D; }
let r = { x0: 60, y0: 40, x1: 240, y1: 260 }, b = E.autoCropBox(img(320, 300, 40, 240, r), 320, 300);
t('papier clair/fond sombre', b && Math.abs(b.x0 - 60) <= 5 && Math.abs(b.x1 - 240) <= 5 && Math.abs(b.y0 - 40) <= 5 && Math.abs(b.y1 - 260) <= 5);
b = E.autoCropBox(img(320, 300, 235, 30, r), 320, 300); t('texte sombre sur fond clair (objet foncé)', b === null || b.x1 - b.x0 > 0);
t('image uniforme : rien', E.autoCropBox(img(320, 300, 128, 128, r), 320, 300) === null);
t('cadre trop petit : rien', E.autoCropBox(img(320, 300, 40, 240, { x0: 100, y0: 100, x1: 120, y1: 120 }), 320, 300) === null);
t('cadre plein : rien', E.autoCropBox(img(320, 300, 40, 240, { x0: 0, y0: 0, x1: 319, y1: 299 }), 320, 300) === null);
// PDF
const jpg = (process.argv[2] && fs.existsSync(process.argv[2])) ? fs.readFileSync(process.argv[2]) : Buffer.from('/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAwAEADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD0GiiiuoxCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//2Q==', 'base64');
const pdf = E.buildPdf([{ jpeg: jpg, w: 400, h: 300 }, { jpeg: jpg, w: 400, h: 300 }], { title: 'Facture é', subject: 'Facture — Villa', keywords: 'a, b', author: 'EB' });
fs.writeFileSync(require('os').tmpdir() + '/exb-test-scanner.pdf', pdf); t('PDF commence par %PDF', Buffer.from(pdf.slice(0, 5)).toString() === '%PDF-'); t('PDF finit par %%EOF', Buffer.from(pdf.slice(-5)).toString() === '%%EOF');
// archive meta
const m = E.archiveMeta({ titre: ' Plan ', type: 'plan', projet: 'P', motsCles: 'x' }, 3, 'sc_1');
t('meta source', m.source.module === 'scanner' && m.source.id === 'sc_1'); t('meta description pages', /3 pages/.test(m.description)); t('meta titre nettoyé', m.titre === 'Plan');
// compat Archives
const AR = require('../site/exb-archives.js').engine;
t('meta acceptée par Archives', AR.validateMeta(Object.assign({}, m, { projet: 'P' })).ok);
t('type facture reconnu par Archives', !!AR.TYPES[E.guessType('facture')] && !!AR.SERVICES[E.guessService('facture')]);
t('nom sûr', E.safeName('Plan R+1 / é') === 'Plan_R_1_é');
// ---- V2 : quadrilatère, redressement ----
function poly(w, h, bg, quad, colorAt) {
  const D = new Uint8ClampedArray(w * h * 4);
  function inside(x, y) { let c = false; for (let i = 0, j = 3; i < 4; j = i++) { const a = quad[i], b = quad[j]; if ((a.y > y) !== (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) c = !c; } return c; }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = (y * w + x) * 4; let c = inside(x, y) ? colorAt(x, y) : bg; D[i] = c[0]; D[i + 1] = c[1]; D[i + 2] = c[2]; D[i + 3] = 255; }
  return D;
}
function rotQuad(cx, cy, hw, hh, deg) { const a = deg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a); return [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]].map(([x, y]) => ({ x: cx + x * c - y * s, y: cy + x * s + y * c })); }
function near(q, t, tol) { return q && q.every((p, i) => Math.hypot(p.x - t[i].x, p.y - t[i].y) <= tol); }
const brown = [58, 44, 34], paper = [245, 245, 240], navy = [23, 53, 101];
// page inclinée de -5°, bandeau bleu foncé en haut (presque aussi sombre que le fond)
let tq = rotQuad(160, 150, 90, 120, -5);
const D1 = poly(320, 300, brown, tq, (x, y) => (y < 150 - 100 + 0 && false) ? navy : paper);
let q1 = E.detectQuad(D1, 320, 300); t('page inclinée : 4 coins à ±5 px', near(q1, tq, 5));
// avec bandeau foncé : le test porte sur le quadrilatère complet, bandeau inclus
const hdr = (x, y) => { const a = -5 * Math.PI / 180, c = Math.cos(a), s = Math.sin(a), dx = x - 160, dy = y - 150, v = -dx * s + dy * c; return v < -120 + 30 ? navy : paper; };
const D2 = poly(320, 300, brown, tq, hdr); let q2 = E.detectQuad(D2, 320, 300); t('bandeau foncé inclus dans le cadre', near(q2, tq, 6));
// perspective : trapèze
const trap = [{ x: 90, y: 40 }, { x: 240, y: 55 }, { x: 270, y: 260 }, { x: 60, y: 245 }];
const D3 = poly(320, 300, brown, trap, () => paper); let q3 = E.detectQuad(D3, 320, 300); t('trapèze (perspective) : 4 coins à ±6 px', near(q3, trap, 6));
// fond clair, page foncée
const D4 = poly(320, 300, [235, 235, 230], rotQuad(160, 150, 100, 110, 3), () => [40, 60, 90]); t('page foncée sur fond clair', near(E.detectQuad(D4, 320, 300), rotQuad(160, 150, 100, 110, 3), 6));
// rien à détecter
t('fond uniforme : rien', E.detectQuad(poly(320, 300, [128, 128, 128], tq, () => [128, 128, 128]), 320, 300) === null);
t('page minuscule : rien', E.detectQuad(poly(320, 300, brown, rotQuad(160, 150, 15, 15, 0), () => paper), 320, 300) === null);
t('page = image entière : rien', E.detectQuad(poly(320, 300, paper, [{ x: -5, y: -5 }, { x: 330, y: -5 }, { x: 330, y: 310 }, { x: -5, y: 310 }], () => paper), 320, 300) === null);
// redressement : coins colorés repérables après warp
const tq2 = rotQuad(160, 150, 90, 120, -5), cols = (x, y) => { const a = -5 * Math.PI / 180, c = Math.cos(a), s = Math.sin(a), dx = x - 160, dy = y - 150, u = dx * c + dy * s, v = -dx * s + dy * c; if (u < -60 && v < -90) return [255, 0, 0]; if (u > 60 && v < -90) return [0, 255, 0]; if (u > 60 && v > 90) return [0, 0, 255]; return paper; };
const D5 = poly(320, 300, brown, tq2, cols), q5 = E.detectQuad(D5, 320, 300), sz = E.quadSize(q5, 1800), W = E.warp(D5, 320, 300, q5, sz.w, sz.h);
t('taille redressée ≈ 180×240', Math.abs(sz.w - 180) <= 6 && Math.abs(sz.h - 240) <= 6);
const px = (x, y) => { const i = (y * sz.w + x) * 4; return [W[i], W[i + 1], W[i + 2]]; };
t('coin haut-gauche rouge', px(10, 10)[0] > 200 && px(10, 10)[1] < 60);
t('coin haut-droit vert', px(sz.w - 11, 10)[1] > 200 && px(sz.w - 11, 10)[0] < 60);
t('coin bas-droit bleu', px(sz.w - 11, sz.h - 11)[2] > 200 && px(sz.w - 11, sz.h - 11)[0] < 60);
t('centre papier', px(sz.w >> 1, sz.h >> 1)[0] > 230);
// warp affine identité
const Dq = poly(100, 80, brown, [{ x: 0, y: 0 }, { x: 99, y: 0 }, { x: 99, y: 79 }, { x: 0, y: 79 }], () => [10, 200, 30]), Wi = E.warp(Dq, 100, 80, [{ x: 0, y: 0 }, { x: 99, y: 0 }, { x: 99, y: 79 }, { x: 0, y: 79 }], 50, 40);
t('warp affine : couleur conservée', Wi[(20 * 50 + 25) * 4 + 1] > 190);
const hl = E.hull([[0, 0], [10, 0], [10, 10], [0, 10], [5, 5], [3, 4]]); t('enveloppe convexe', hl.length === 4);


console.log(ok + ' contrôles OK, ' + ko + ' échec(s)'); process.exit(ko ? 1 : 0);
