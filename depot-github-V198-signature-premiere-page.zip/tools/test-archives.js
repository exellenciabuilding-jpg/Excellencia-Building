/* Tests du moteur Archives (module 08) : node tools/test-archives.js */
const E = require('../site/exb-archives.js').engine;
let ok = 0, ko = 0;
function t(n, c) { if (c) ok++; else { ko++; console.log('ÉCHEC :', n); } }
const A = { name: 'Marie', role: 'Ingénieur', verified: true }, B = { name: 'Paul', role: 'Comptable', verified: true }, C = { name: 'Zoé', role: 'Directeur général', verified: true };
const T0 = '2026-11-15T10:00:00.000Z', file = { nom: 'plan-R+1.pdf', mime: 'application/pdf', taille: 2048, sha: 'abc' };
const meta = { titre: ' Plan R+1 villa ', type: 'plan', projet: 'Villa Kalala', motsCles: 'Plan, béton, plan,  RDC', conservationAns: 10 };
// métadonnées
t('titre requis', !E.validateMeta({ type: 'plan', projet: 'x' }).ok);
t('type inconnu', !E.validateMeta({ titre: 'a', type: 'zzz', projet: 'x' }).ok);
t('classement requis', !E.validateMeta({ titre: 'a', type: 'plan' }).ok);
t('service seul suffit', E.validateMeta({ titre: 'a', type: 'plan', service: 'rh' }).ok);
t('conservation 100 refusée', !E.validateMeta({ titre: 'a', type: 'plan', projet: 'x', conservationAns: 100 }).ok);
t('fichier vide', !E.validateFile({ nom: 'a', taille: 0 }).ok);
t('fichier trop gros', !E.validateFile({ nom: 'a', taille: 16 * 1048576 }).ok);
t('numéro', E.nextNo([], '2026') === 'ARC-2026-0001' && E.nextNo([{ no: 'ARC-2026-0007' }, { no: 'ARC-2025-0099' }], '2026') === 'ARC-2026-0008');
// création
const r = E.create(meta, file, A, T0, 'ARC-2026-0001', 'id1'); t('création ok', r.ok);
let d = r.doc;
t('titre nettoyé', d.titre === 'Plan R+1 villa');
t('mots-clés normalisés sans doublon', JSON.stringify(d.motsCles) === JSON.stringify(['plan', 'beton', 'rdc']));
t('v1 + historique', d.versions.length === 1 && d.historique.length === 1 && d.historique[0].a === 'depot');
t('création refusée si fichier invalide', !E.create(meta, { nom: '', taille: 1 }, A, T0, 'n', 'i').ok);
// droits
const now = '2026-11-20';
let rt = E.rights(d, B, false, now); t('accès tous : lecture + téléchargement', rt.voir && rt.telecharger && !rt.modifier);
t('propriétaire : tout', E.rights(d, A, false, now).gerer);
t('admin : tout', E.rights(d, B, true, now).gerer);
d = E.setAccess(d, 'restreint', 'oui', A, T0).doc;
t('restreint : invisible', !E.rights(d, B, false, now).voir);
let s = E.share(d, E.parseTarget('Paul'), false, '2026-12-01', A, T0); t('partage ok', s.ok); d = s.doc;
rt = E.rights(d, B, false, now); t('partagé : voir sans télécharger', rt.voir && !rt.telecharger && !rt.modifier);
t('partage expiré', !E.rights(d, B, false, '2026-12-02').voir);
t('partage passé refusé', !E.share(d, E.parseTarget('Paul'), false, '2026-01-01', A, T0).ok);
s = E.share(d, E.parseTarget('fonction: Directeur général'), true, '', A, T0); d = s.doc;
t('partage par fonction', E.rights(d, C, false, '2030-01-01').telecharger);
t('re-partage remplace', E.share(d, E.parseTarget('Paul'), true, '', A, T0).doc.partages.filter(p => E.tlabel(p.cible) === 'Paul').length === 1);
t('retrait partage', E.unshare(d, 'Paul', A, T0).ok && !E.unshare(d, 'Inconnu', A, T0).ok);
d = E.setAccess(d, 'tous', 'non', A, T0).doc;
t('téléchargement restreint', !E.rights(d, { name: 'Autre' }, false, now).telecharger && E.rights(d, A, false, now).telecharger);
// versions
let v = E.addVersion(d, { nom: 'plan-R+1-v2.pdf', mime: 'application/pdf', taille: 3000, sha: 'def' }, A, '2026-11-21T09:00:00Z', 'Retrait garde-corps'); t('version 2', v.ok && v.version === 2);
d = v.doc; t('courante = v2', E.current(d).n === 2 && d.versions.length === 2);
t('restaurer courante refusé', !E.restore(d, 2, A, T0).ok);
let rs = E.restore(d, 1, A, '2026-11-22T09:00:00Z'); t('restauration = v3 sans réécrire', rs.ok && rs.version === 3 && rs.doc.versions[2].depuis === 1 && rs.doc.versions[0].nom === 'plan-R+1.pdf');
t('v3 reprend l\'empreinte de v1', rs.doc.versions[2].sha === 'abc');
t('version inconnue', !E.restore(d, 9, A, T0).ok);
// archivage
let ar = E.archive(d, A, '2026-11-23T00:00:00Z', 'Fin de chantier'); t('archivage', ar.ok && ar.doc.statut === 'archive');
t('double archivage refusé', !E.archive(ar.doc, A, T0, '').ok);
t('version refusée si archivé', !E.addVersion(ar.doc, file, A, T0, '').ok);
t('restauration refusée si archivé', !E.restore(ar.doc, 1, A, T0).ok);
t('désarchivage : motif obligatoire', !E.unarchive(ar.doc, A, T0, ' ').ok && E.unarchive(ar.doc, A, T0, 'Erreur').ok);
t('historique en ajout seul', ar.doc.historique.length === d.historique.length + 1 && d.historique.length < ar.doc.historique.length);
// conservation
const dd = E.create({ titre: 'x', type: 'contrat', client: 'K', conservationAns: 1 }, file, A, '2026-01-10T00:00:00Z', 'n', 'i2').doc;
t('fin conservation', E.retentionEnd(dd) === '2027-01-10');
t('état en cours', E.retentionState(dd, '2026-06-01').etat === 'en_cours');
t('état proche (<90 j)', E.retentionState(dd, '2026-12-01').etat === 'proche');
t('état échue', E.retentionState(dd, '2027-01-11').etat === 'echue');
t('non définie', E.retentionState(E.create({ titre: 'x', type: 'autre', client: 'K' }, file, A, T0, 'n', 'i3').doc, now).etat === 'non_definie');
// suppression
t('motif obligatoire', !E.canDelete(dd, A, false, '2027-02-01', '').ok);
t('conservation en cours : propriétaire refusé', !E.canDelete(dd, A, false, '2026-06-01', 'x').ok);
t('conservation en cours : admin forcée', (() => { const c = E.canDelete(dd, A, true, '2026-06-01', 'x'); return c.ok && c.forcee; })());
t('échue : propriétaire autorisé', E.canDelete(dd, A, false, '2027-02-01', 'x').ok);
t('échue : tiers refusé', !E.canDelete(dd, B, false, '2027-02-01', 'x').ok);
// recherche
const d2 = E.create({ titre: 'Facture ciment', type: 'facture', projet: 'Immeuble Gombe', client: 'Société Étoile', service: 'finance', motsCles: 'ciment' }, { nom: 'F-001.pdf', taille: 10 }, B, '2026-03-05T00:00:00Z', 'ARC-2026-0002', 'id2').doc;
const L = [d, d2]; const S = (q, f, a, adm) => E.search(L, q, f || {}, a || A, !!adm, now).map(x => x.id).join();
t('recherche sans accent', S('etoile') === 'id2' && S('BETON', {}, A) === 'id1');
t('recherche ET', S('ciment gombe') === 'id2' && S('ciment kalala') === '');
t('recherche nom de fichier', S('F-001') === 'id2');
t('filtre type', S('', { type: 'plan' }) === 'id1');
t('filtre période', S('', { du: '2026-03-01', au: '2026-03-31' }) === 'id2');
t('filtre statut', S('', { statut: 'archive' }) === '');
t('ordre : plus récent d\'abord', S('') === 'id1,id2');
const dR = E.setAccess(d, 'restreint', 'non', A, T0).doc;
t('recherche respecte les droits', E.search([dR], '', {}, { name: 'Autre' }, false, now).length === 0 && E.search([dR], '', {}, { name: 'Autre' }, true, now).length === 1);
// regroupement et stats
const g = E.groupBy(L, 'periode'); t('groupBy période', Object.keys(g).sort().join() === '2026-03,2026-11');
t('groupBy non classé', Object.keys(E.groupBy([{ id: 1, cree: T0, versions: [] }], 'projet'))[0] === '(non classé)');
const st = E.stats(L, now); t('stats', st.total === 2 && st.actifs === 2 && st.taille === 2048 + 3000 + 10);
// modification des métadonnées
let e1 = E.editMeta(d2, { titre: 'Facture ciment CIMAF', motsCles: 'ciment, cimaf', projet: 'Immeuble Limete' }, B, '2026-04-01T00:00:00Z', false);
t('modif ok', e1.ok && e1.doc.titre === 'Facture ciment CIMAF' && e1.doc.projet === 'Immeuble Limete' && e1.champs.join() === 'titre,projet,mots-clés');
t('modif tracée', e1.doc.historique[e1.doc.historique.length - 1].a === 'modif' && e1.doc.versions.length === d2.versions.length);
t('modif sans changement refusée', !E.editMeta(d2, { titre: d2.titre }, B, T0, false).ok);
t('modif invalide refusée', !E.editMeta(d2, { titre: '' }, B, T0, false).ok && !E.editMeta(d2, { type: 'zzz' }, B, T0, false).ok);
t('modif ne change pas l\'original', d2.titre === 'Facture ciment');
t('modif archivé refusée', !E.editMeta(E.archive(d2, B, T0, '').doc, { titre: 'x' }, B, T0, true).ok);
t('retrait conservation : admin seul', !E.editMeta(dd, { conservationAns: '' }, A, T0, false).ok && E.editMeta(dd, { conservationAns: '' }, A, T0, true).ok);
t('réduction conservation : admin seul', !E.editMeta(dd, { conservationAns: 0 }, A, T0, false).ok);
t('allongement conservation : permis', E.editMeta(dd, { conservationAns: 5 }, A, T0, false).ok);
t('définir une conservation absente : permis', E.editMeta(E.create({ titre: 'x', type: 'autre', client: 'K' }, file, A, T0, 'n', 'i4').doc, { conservationAns: 3 }, A, T0, false).ok);
t('devine facture', E.guess('Facture-2026-001.pdf').type === 'facture' && E.guess('Facture-2026-001.pdf').service === 'finance');
t('devine certificat / plan / défaut', E.guess('Attestation.pdf').type === 'certificat' && E.guess('Plan_R+1.pdf').type === 'plan' && E.guess('zzz.pdf').type === 'autre');
// échappement / immutabilité
t('create ne modifie pas meta', meta.titre === ' Plan R+1 villa ');
console.log(ko ? ko + ' ÉCHEC(S) sur ' + (ok + ko) : 'OK : ' + ok + ' contrôles');
process.exit(ko ? 1 : 0);
