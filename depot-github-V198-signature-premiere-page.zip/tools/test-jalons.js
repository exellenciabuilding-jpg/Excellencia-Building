/* Test jalons du planning (moteur exb-cpm.js). node tools/test-jalons.js */
const C = require('../site/exb-cpm.js'); let ok = 0, ko = 0;
function eq(a, b, m) { if (a === b) ok++; else { ko++; console.log('KO', m, JSON.stringify(a), '≠', JSON.stringify(b)); } }
const T = [{ start: 1, dur: 2, pct: 100 }, { start: 3, dur: 3, pct: 0, pred: '1' }, { start: 6, dur: 2, pct: 0, pred: '2' }]; // fins prévues : S2, S5, S7
let J = C.jalons(T, [{ name: 'Fondations', task: 1 }, { name: 'Gros œuvre', task: 2 }, { name: 'Réception', task: 3 }, { name: 'Visite', task: 0, week: 4 }, { name: 'Faux', task: 9, week: 3 }], 4);
eq(J[0].statut, 'atteint', 'tâche à 100 % = atteint'); eq(J[0].semaine_prevue, 2, 'fin tâche 1');
eq(J[1].semaine_prevue, 5, 'fin tâche 2'); eq(J[1].statut, 'menace', 'S4 : tâche 2 à 0 % qui doit finir S5, la prévision glisse après S5');
eq(J[2].semaine_prevue, 7, 'fin tâche 3'); eq(J[3].statut, 'a_venir', 'semaine fixe 4 = semaine courante : pas encore en retard');
eq(J[4].lien_invalide, true, 'tâche inexistante signalée'); eq(J[4].tache, 0, 'retombe sur la semaine fixe'); eq(J[4].semaine_prevue, 3, 'semaine fixe de repli');
J = C.jalons(T, [{ name: 'Visite', task: 0, week: 4 }], 6); eq(J[0].statut, 'en_retard', 'semaine passée, non atteint');
J = C.jalons(T, [{ name: 'Visite', task: 0, week: 4, done: true }], 6); eq(J[0].statut, 'atteint', 'coché à la main');
J = C.jalons(T, [{ name: 'Visite', task: 0, week: 4 }], 0); eq(J[0].statut, 'a_venir', 'semaine courante inconnue : jamais « en retard »');
const T2 = [{ start: 1, dur: 2, pct: 100 }, { start: 3, dur: 3, pct: 50, pred: '1' }]; // tâche 2 à 50 % en S5 : reste 2 sem -> fin S6 au lieu de S5
J = C.jalons(T2, [{ name: 'X', task: 2 }], 5); eq(J[0].ecart, 1, 'retard prévisionnel d’1 semaine'); eq(J[0].statut, 'menace', 'menacé');
const cyc = [{ start: 1, dur: 1, pred: '2' }, { start: 1, dur: 2, pred: '1' }];
J = C.jalons(cyc, [{ name: 'C', task: 2 }], 1); eq(J[0].semaine_prevue, 2, 'cycle : repli sur début + durée'); 
eq(C.jalons([], null, 1).length, 0, 'aucun jalon');
eq(C.semaine('2026-11-02', '2026-11-15'), 2, 'semaine courante'); eq(C.semaine('', '2026-11-15'), 0, 'sans date : 0');
console.log(ko ? ko + ' échec(s)' : 'OK : ' + ok + ' contrôles'); process.exit(ko ? 1 : 0);
