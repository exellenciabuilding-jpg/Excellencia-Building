# V186f — Sélection multiple dans le Studio libre

Base : V186e. **Aucun SQL.** Fichiers modifiés : `site/exb-affiches-studio.js`, `site/sw.js` (cache), `site/exb-core.js` (« V186f-CORE »), `site/tools/check.js`. Nouveau test : `site/tools/e2e-affiches-multi.py`.

## Ce que vous pouvez faire (Affiches › Studio libre)
- **Sélectionner plusieurs éléments** : Maj + clic (ou Ctrl + clic) pour ajouter / retirer un élément ; **tracer un cadre** sur le fond de l'affiche ; **Ctrl+A** pour tout sélectionner.
- **Déplacer le groupe** : glisser l'un des éléments, ou les flèches (Maj = 20 px).
- **Panneau « plusieurs éléments »** : aligner (gauche, centre, droite, haut, milieu, bas), répartir horizontalement / verticalement (3 éléments ou plus, évite les chevauchements), centrer le groupe sur l'affiche, devant / derrière, dupliquer, supprimer, désélectionner.
- **Clavier sur le groupe** : Ctrl+C / X / V, Ctrl+D, Ctrl+] / [, Ctrl+B / I (textes simples), Suppr, Échap, Ctrl+Z / Ctrl+Y — chaque action s'annule en un seul pas.

## Limites connues
- Taille, couleur et police se règlent toujours un élément à la fois (le panneau de groupe ne les change pas).
- Les éléments pivotés sont pris dans le cadre selon leur zone non pivotée.
- Affiches Excellencia (onglet 1) non concernées. Non vérifié : clavier tactile Android, Windows (Electron) réel.

## Contrôles
`node site/tools/check.js` : 601 réussis, 0 échec · `e2e-affiches-multi.py` : 15/15 · `e2e-affiches-clavier.py`, `e2e-affiches-word.py` (19/19), `e2e-affiches.py` : OK.
