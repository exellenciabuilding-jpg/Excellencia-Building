# Vérification (mise à jour V186) de la V185 par rapport au Cahier des charges général unifié V1.0 (nov. 2026)

Légende : ✅ conforme · 🟡 partiel / non démontré · ❌ non constaté.
Méthode : lecture des 13 pages ; vérification dans le code V185 (lecture + recherches ciblées) ; passe de 94 suites de tests (33 e2e Chromium + sous-dossiers + Node + licences) : 0 échec. Les points « notes » s'appuient sur les LISEZ-MOI V167–V184, non relus ligne à ligne. Rien n'a été testé sur données réelles, téléphone/tablette, ni plusieurs utilisateurs ; les tests RLS PostgreSQL n'ont pas été exécutés (audit statique seulement).

## Réponse courte
Le socle est largement couvert, mais le cahier n'est pas entièrement respecté : il fixe une cible en 9 phases dont plusieurs (IA, mobilité complète, validation sur appareils, décisions §12) ne sont pas terminées.

## 15 modules
| # | Module | État | Reste à faire |
|---|---|---|---|
| 01 | BI | ✅ | V186 : dictionnaire complet (formule, source, fréquence, responsable modifiable, règle de validation) et pastille de fiabilité par indicateur (vérifié / à vérifier / non fiable / aucune donnée), export CSV inclus |
| 02 | Project Manager | ✅ | blocage budgétaire via Workflow : règle à décider |
| 03 | Plan Editor | ✅/🟡 | DWG : pont partiel ; formats réels à valider (§12) |
| 04 | CRM | ✅/🟡 | V172/V176 : pipeline, relances/RDV, versions de devis, conversion en contrat, réclamations, alertes. Satisfaction client à confirmer |
| 05 | HR | 🟡 | compétences liées au dossier ; paie V173 + pont V81 faits ; barèmes à valider avec votre comptable |
| 06 | Stock & Procurement | ✅/🟡 | V172 : dépôts, transferts, inventaires justifiés, comparatifs, rapprochement commande/réception/facture. Demande d'achat formelle à confirmer |
| 07 | Workflow | ✅ | liens avec devis, achats, congés, certificats (V167) |
| 08 | Archives | ✅ | partage avec droits présent ; dépôt direct depuis Plan Editor/Project Manager à confirmer |
| 09 | TFL & Académie | ✅ | V186 : division en trois espaces (formations classiques / parcours TFL / certificats) ; préparation de soutenance déjà présente (liste de contrôle, jury, rendez-vous, défense) |
| 10 | Certificats | ✅ | V186 : statuts valide / suspendu / révoqué, motif obligatoire, journal, traitement par lot, pages de vérification et espace apprenant à jour |
| 11 | Server | 🟡 | espace serveur, synchro ; pas d'écran de supervision / alertes de disponibilité constaté |
| 12 | Licences | ✅ | + sessions/appareils (V175) |
| 13 | Scanner | ✅/🟡 | V169 : cadre 4 coins + redressement ; OCR : moteur à fournir (V175) |
| 14 | Administration | 🟡 | sessions/appareils (V175) ; revue périodique des accès non constatée |
| 15 | Finances & Compta | ✅/🟡 | factures, avoirs, échéanciers, clôture, bilan, paie ; règles comptables/fiscales RDC à valider (§12) |

## Architecture, sécurité, transversal
| Exigence | État |
|---|---|
| 5 divisions (§1) | ✅ menu en 5 divisions (exb-v99r-shell.js, V184) |
| EXCELLENCIA CORE, journal d'audit, bus d'événements | ✅ |
| Identifiant stable unique pour tout objet | 🟡 existe, pas appliqué partout |
| Aucun module n'écrit dans la base d'un autre | ❌ non contrôlé (stockage commun) |
| Environnements dev/préprod/prod, démo séparée | ❌ hors code |
| Droits par action (10 actions) | ✅ exb-droits-actions.js ; limitation département/projet/propriété partielle |
| MFA comptes privilégiés | ✅ |
| Sauvegardes chiffrées, test de restauration, RPO/RTO, intégrité de migration | ✅ (V166c, V175) ; copies internes automatiques en clair sur certains chemins : à confirmer |
| Cloisonnement serveur (RLS) | ✅/🟡 78 tables avec RLS, 122 politiques (audit statique) ; tests PostgreSQL non exécutés ici |
| Exports soumis aux droits et journalisés | ✅ |
| Hors ligne : indicateur, reprise, conflits | ✅/🟡 exb-v73-offline.js + exb-db.js (conflits conservés) ; à tester sur appareils |
| Responsive ordinateur/tablette/téléphone | 🟡 onglets uniformes (V179-V181) ; non testé sur appareils |
| PDF A4 professionnels + QR | ✅ (V177-V178), tests e2e verts |
| Pagination / filtres côté serveur | 🟡 « Afficher plus » local |
| Copilot IA encadré | 🟡 assistants existants ; validation humaine à formaliser |
| KPIGO (facultatif), géolocalisation (P2) | ❌ / 🟡 |

## Règles métier §4
| Règle | État |
|---|---|
| Réutilisation des données client/chantier | ✅ tests de liaison |
| Devis ≠ paiement | 🟡 paiement = objet distinct ; parcours bout en bout non testé |
| Devis / facturé / encaissé / reste / dépenses / solde | ✅ BI |
| Pas de double comptabilisation (idempotence) | ✅ encaissement et paie V81/V173 ; 🟡 ailleurs |
| Validation : auteur, date, statut, approbateur, historique | ✅ Workflow + audit chaîné |

## Décisions §12 encore à prendre
Hébergement, base/stockage/sauvegarde, volumes et utilisateurs, règles comptables et fiscales RDC, RPO/RTO et conservation, périmètre BI, formats PDF/DXF/DWG/IFC, fonctions hors ligne.

## Ordre proposé
1. Fait en V186 : fiabilité des KPI (BI), deux espaces formation/TFL, statuts et lot de certificats. Reste : supervision Server ; revue périodique des accès.
2. Tests sur téléphone/tablette, RLS PostgreSQL (tools/test-rls/run.sh), parcours devis → paiement.
3. Décisions §12 avant IA/Copilot.
