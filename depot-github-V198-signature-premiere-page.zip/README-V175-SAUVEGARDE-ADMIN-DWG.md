# V175 — Sauvegardes chiffrées + test de restauration, sessions & appareils (Admin), pont DWG, OCR (fichiers à fournir)

## 1. Sauvegardes chiffrées et test de restauration — `exb-sauvegarde-chiffree.js` (nouveau)
- Bouton **🔐 Test restauration** dans la barre d'état. **Mot de passe de sauvegarde** (10 car. minimum) → clé AES-256-GCM dérivée (PBKDF2-SHA256, 250 000 itérations), gardée **non extractible** dans IndexedDB de l'appareil. Une fois activé, la copie interne automatique, les fichiers du dossier choisi et le fichier téléchargé de « 💾 Sauvegarde auto » sont **chiffrés**. Format identique à « 🛡 Sécurité & sauvegardes » : un fichier se déchiffre avec le mot de passe, sur n'importe quel appareil.
- **Clé absente (autre navigateur, données effacées) : la sauvegarde est refusée** au lieu d'être écrite en clair, avec un message.
- **Test de restauration** : déchiffre, contrôle l'empreinte SHA-256, **rejoue la restauration dans une mémoire temporaire** (jamais dans vos données), recontrôle l'empreinte, relit chaque collection, compare avec les données actuelles. Résultat : étapes ✔/✖, durée mesurée, journalisé (`sauvegarde.test_restauration`, sans contenu).
- **Test automatique** de la dernière copie interne chaque semaine (hors saisie) ; alerte si échec ; rappel si aucun test réussi depuis 30 jours.
- **RPO / RTO** : objectifs modifiables (24 h / 60 min par défaut — valeurs de départ, à fixer avec votre direction). Le test compare l'âge de la sauvegarde au RPO et la durée mesurée au RTO.
- ⚠ **Le mot de passe n'est jamais conservé et ne se retrouve pas.** Sans lui, une copie chiffrée est définitivement illisible. Changer de mot de passe ne re-chiffre pas les anciennes copies.
- Limite : la clé conservée protège les fichiers sortis de l'appareil ; quelqu'un qui contrôle votre session de navigateur peut l'utiliser (sans pouvoir l'exporter).
- Mécanisme : enveloppe `EXBSEC._makeBackup` / `_verify` (aucune modification d'`exb-v81-securite.js` ni d'`exb-sauvegarde-auto.js`).

## 2. Sessions & appareils — `exb-admin.js` (onglet « 📱 Sessions & appareils ») + serveur de licences
- Serveur (`licence-server/…/core.mjs`) : deux actions publiques **authentifiées par le code d'activation** : `devices` (liste : appareil, type, version, dernière activité) et `release_own` (libère un appareil). Même frein anti-essais (10 codes faux / 15 min / adresse). Un code ne voit et ne libère que **ses** appareils. Journal serveur `appareil_libere_par_client`.
- Admin : session en cours, saisie du code (jamais conservé ni journalisé), tableau avec statut **actif (< 24 h) / récent (< 7 j) / inactif**, bouton **Libérer** (confirmation, avertissement si c'est l'appareil courant). Action journalisée localement (`admin.appareil.libere`).
- **À déployer** : redéployer la fonction `licence` (`supabase functions deploy licence --no-verify-jwt`). Sans ce redéploiement, l'onglet affichera « action inconnue ».
- Libérer = déconnecter à la **prochaine vérification** de licence de l'appareil (au plus tard après la durée hors-ligne autorisée) ; ce n'est pas une coupure instantanée.
- **Non couvert** : sessions et comptes des autres utilisateurs, suspension de comptes, délégations, revue périodique des accès (dépendent de Supabase Auth / RLS, à concevoir).
- Ce module est retiré des éditions client par `scripts/strip-owner.js` (comme avant pour `exb-admin.js`) : l'onglet est donc côté propriétaire / Admin de l'édition qui garde ce fichier.

## 3. DWG — `exb-dwg.js` (nouveau) + 3 lignes dans `exb-v81-plans.js`
- **Aucun décodeur DWG n'est livré** : le navigateur ne lit pas le DWG. Le module reconnaît la version (AC1009 … AC1032), refuse un fichier vide / tronqué / renommé, puis charge **votre** convertisseur `site/vendor/dwg/exb-dwg-converter.js` qui doit définir :
  `window.EXB_DWG_CONVERTER = { name:'…', convert:function(arrayBuffer){ /* retourne une Promise du texte DXF */ } }`
  (adaptateur mince autour d'une bibliothèque DWG→DXF, par ex. LibreDWG compilé en WebAssembly — licence GPL : à valider avant diffusion commerciale). Le DXF produit est contrôlé (sections, entités) puis lu par le lecteur DXF des Plans (calques, mesures, annotations).
- Sans convertisseur ou en cas d'échec : comportement d'avant (archivage + versionnage) avec message précis. Délai maximal 90 s, fichier 80 Mo max.
- Journal : `plans.dwg.converti` / `plans.dwg.echec` (sans contenu).
- **Écriture DWG : non faite.** Export recommandé : DXF ou IFC.

## 4. OCR — fichiers Tesseract fournis par vous, vérifiés (7 fichiers dans `site/vendor/tesseract/`)
Test réel (`node tests/test-ocr-reel.js`, Chromium, vrai Tesseract.js 5 + `fra`) : facture d'essai en français lue correctement (accents, « N° », montant, date), confiance 94 %, < 1 s sur ordinateur. Le même appel `createWorker` que `exb-ocr.js` est utilisé. Non testé : téléphone Android, documents réels (tampons, plans, scans de travers).
Dans `site/vendor/tesseract/` : `tesseract.min.js`, `worker.min.js`, `tesseract-core.wasm.js`, `tesseract-core-simd.wasm.js`, **`tesseract-core-lstm.wasm.js`, `tesseract-core-simd-lstm.wasm.js`** (requis : le moteur LSTM par défaut charge ces deux-là — constaté en test réel), `fra.traineddata.gz` (voir README-V153-OCR.md pour les paquets npm). Vérifiez avec **`node tools/verifier-tesseract.js`** (liste ce qui manque, ne télécharge rien).

## Vérifié (Chromium + Node)
- Serveur de licences : 59 contrôles dont 9 nouveaux (liste, isolation entre clients, frein 429, libération, journal, déconnexion à la vérification suivante).
- Sauvegardes : 17 contrôles (chiffré = aucune donnée lisible, mauvais mot de passe, fichier modifié, contenu falsifié, clé absente → refus, test sans écriture dans les données réelles, copie interne chiffrée).
- Admin : 9 contrôles avec serveur simulé. DWG : 11 contrôles avec un **faux** convertisseur (le vrai n'existe pas ici). Application complète : chargée, 0 erreur JS.

## Non vérifié
- Un **vrai** convertisseur DWG et un vrai DWG ; le bouton OCR du Scanner dans l'application complète (le moteur, lui, est testé).
- L'onglet Sessions face au **vrai** serveur Supabase redéployé ; la restauration réelle (bouton « Restaurer ») d'une copie chiffrée dans l'application complète ; Android / Electron.
- Tests : `node tests/test-bkc.js`, `node tests/test-admin.js`, `node tests/test-dwg.js`, `node licence-server/tests/core.test.mjs`.
