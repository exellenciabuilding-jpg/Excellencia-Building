const {chromium}=require('/opt/npm-tools/node_modules/playwright');const http=require('http'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..','site');
const mime={'.js':'text/javascript','.gz':'application/gzip','.html':'text/html','.png':'image/png'};
const srv=http.createServer((q,r)=>{let f=path.join(root,decodeURIComponent(q.url.split('?')[0]));if(q.url.startsWith('/__t/'))f=path.join(__dirname,q.url.slice(5));if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.writeHead(404);return r.end()}r.writeHead(200,{'content-type':mime[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(r)}).listen(0,async()=>{
 const port=srv.address().port;const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto(`http://localhost:${port}/__t/blank.html`).catch(()=>{});
 await p.setContent('<html><body></body></html>');
 const out=await p.evaluate(async(port)=>{
  const B=`http://localhost:${port}/vendor/tesseract/`;
  await new Promise((ok,ko)=>{const s=document.createElement('script');s.src=B+'tesseract.min.js';s.onload=ok;s.onerror=()=>ko(new Error('script'));document.head.appendChild(s)});
  const t0=performance.now();
  const w=await Tesseract.createWorker('fra',1,{workerPath:B+'worker.min.js',corePath:B,langPath:B,gzip:true});
  const r=await w.recognize(`http://localhost:${port}/__t/ocr-facture.png`);await w.terminate();
  return{text:r.data.text,conf:r.data.confidence,ms:Math.round(performance.now()-t0)}},port);
 console.log(out.text);console.log('confiance',out.conf,'durée ms',out.ms,'erreurs JS',errs.length,errs.slice(0,2));await b.close();srv.close();});
