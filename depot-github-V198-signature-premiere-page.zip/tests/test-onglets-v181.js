/* V181 — onglets en colonne latérale (gauche) ou barre du bas, réductibles, mémorisés. Usage : node tests/test-onglets-v181.js */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
(async()=>{
 const b=await chromium.launch();let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
 const url='file://'+path.resolve(__dirname,'../site/index.html');
 async function page(w,h,pref){const p=await b.newPage({viewport:{width:w,height:h}});p.errs=[];p.on('pageerror',e=>p.errs.push(e.message));
  if(pref)await p.addInitScript(v=>{try{localStorage.setItem('exb_onglets_v1',v)}catch(e){}},pref);
  await p.goto(url);await p.waitForTimeout(3500);
  await p.evaluate(()=>{(window.exbSessionStorage||sessionStorage).setItem('exb_logged','1');document.getElementById('app').style.display='block';const l=document.getElementById('login');if(l)l.style.display='none'});return p}
 /* mesure d'un module réel, tout dans le même instant (l'appli retire les sections non autorisées hors connexion) */
 const mesure=(p,id,M)=>p.evaluate(([id,M])=>{try{show(id)}catch(e){}try{window[M].render()}catch(e){}window.EXBOnglets.scan();
   const sec=document.getElementById(id),c=sec&&sec.querySelector('.exb-onglets');if(!c)return{absent:true};sec.scrollIntoView();
   const R=e=>e.getBoundingClientRect(),bs=[...c.children].filter(x=>x.tagName==='BUTTON'),cr=R(c),host=c.parentElement;
   const autres=[...host.children].filter(x=>x!==c&&R(x).width>0&&getComputedStyle(x).position!=='fixed');
   return{n:bs.length,gauche:c.classList.contains('exb-rl'),bas:c.classList.contains('exb-rb'),compact:c.classList.contains('exb-rc'),
    memeX:new Set(bs.map(x=>Math.round(R(x).left))).size===1,lignes:new Set(bs.map(x=>Math.round(R(x).top))).size,largeur:Math.round(cr.width),
    chevauche:autres.some(x=>{const r=R(x);return r.width>0&&r.height>0&&!(r.left>=cr.right-1||r.right<=cr.left+1||r.top>=cr.bottom-1||r.bottom<=cr.top+1)}),
    sousContenu:autres.every(x=>R(x).bottom<=cr.top+2||R(x).top<cr.top+2),
    barreVisible:cr.bottom<=innerHeight+1&&cr.top>=0,debordePage:document.documentElement.scrollWidth>innerWidth+1,ctl:!!c.querySelector('.exb-ctl [data-a=min]')&&!!c.querySelector('.exb-ctl [data-a=pos]'),
    actifs:bs.filter(x=>x.classList.contains('exb-on')).length}},[id,M]);
 const MODS=[['Chantiers','chantiers','EXBCH'],['Études (Architecture)','etudes3','EXBET'],['Planning','plangantt','EXBPL'],['Terrain','terrain','EXBTR']];

 /* 1) bureau : colonne à gauche, sans chevauchement */
 {const p=await page(1280,800,null);
  for(const [l,id,M] of MODS){const r=await mesure(p,id,M);
   if(r.absent){ok(false,l+' : barre absente');continue}
   ok(r.gauche&&r.memeX&&r.lignes===r.n,l+' (bureau) : '+r.n+' onglets en colonne à gauche');
   ok(!r.chevauche&&!r.debordePage,l+' (bureau) : le contenu est à côté, rien ne se chevauche, pas de débordement');
   ok(r.ctl&&r.actifs===1,l+' (bureau) : boutons réduire/position présents, onglet actif repéré');}
  /* clic, réduction et changement de position : tout dans le même instant (l'appli retire les modules non autorisés hors connexion) */
  await p.close();const q=await page(1280,800,null);
  const T=await q.evaluate(()=>{const g=()=>document.getElementById('etudes3').querySelector('.exb-onglets'),sc=()=>window.EXBOnglets.scan(),out={};
   try{show('etudes3')}catch(e){}window.EXBET.render();sc();
   const bs=[...g().children].filter(x=>x.tagName==='BUTTON');bs[1].click();sc();
   out.clic=[...g().children].filter(x=>x.tagName==='BUTTON').map(x=>x.classList.contains('exb-on'));
   const w0=g().getBoundingClientRect().width;g().querySelector('[data-a=min]').click();
   out.w0=Math.round(w0);out.w1=Math.round(g().getBoundingClientRect().width);out.compact=g().classList.contains('exb-rc');out.ic=g().querySelector('button').getAttribute('data-ic');out.pref=localStorage.getItem('exb_onglets_v1');
   out.seq=[];for(let i=0;i<3;i++){g().querySelector('[data-a=pos]').click();const k=g();out.seq.push((k.classList.contains('exb-rl')?'gauche':k.classList.contains('exb-rb')?'bas':'haut')+'|'+JSON.parse(localStorage.getItem('exb_onglets_v1')).pos)}
   const k=g(),bb=[...k.children].filter(x=>x.tagName==='BUTTON');out.hautLignes=new Set(bb.map(x=>Math.round(x.getBoundingClientRect().top))).size;out.hautRail=k.classList.contains('exb-rl')||k.classList.contains('exb-rb');
   return out});
  ok(T.clic[1]===true&&T.clic.filter(Boolean).length===1,'Études : un clic dans la colonne ouvre bien l\u2019onglet (le module répond)');
  ok(T.compact&&T.w1<T.w0&&T.w1<=60,'Réduire : la colonne passe de '+T.w0+' px à '+T.w1+' px (icônes seules, icône « '+T.ic+' »)');
  ok(/compact":true/.test(T.pref||''),'Le choix « réduit » est mémorisé sur l\u2019appareil');
  ok(T.seq.join(' ')==='gauche|left bas|bottom haut|top','Bouton position : '+T.seq.join(' → '));
  ok(T.hautLignes===1&&!T.hautRail,'Position « haut » : retour à la rangée d\u2019origine, sur une ligne');
  const p2=q;p.errs=q.errs;
  ok(p.errs.length===0,'bureau : aucune erreur JavaScript'+(p.errs[0]||''));await q.close();}

 /* 2) téléphone : barre du bas (auto) ; le contenu reste au-dessus */
 {const p=await page(390,800,null);
  for(const [l,id,M] of MODS){const r=await mesure(p,id,M);
   if(r.absent){ok(false,l+' : barre absente');continue}
   ok(r.bas&&r.lignes===1,l+' (téléphone) : barre en bas, une seule ligne');
   ok(r.barreVisible&&!r.debordePage,l+' (téléphone) : la barre est visible au bas de l\u2019écran, pas de débordement');}
  const p3=await page(390,800,null);
  const st=await p3.evaluate(()=>{try{show('etudes3')}catch(e){}window.EXBET.render();window.EXBOnglets.scan();const c=document.getElementById('etudes3').querySelector('.exb-onglets');return getComputedStyle(c).position});
  await p3.close();
  ok(st==='sticky','Barre du bas : reste accrochée au bas de l’écran pendant le défilement');
  ok(p.errs.length===0,'téléphone : aucune erreur JavaScript'+(p.errs[0]||''));await p.close();}

 /* 3) suit la barre des modules : réglage « En bas » sur grand écran, « À gauche » sur téléphone */
 {const p=await page(1280,800,null);await p.evaluate(()=>localStorage.setItem('exb_dock_v1',JSON.stringify({layout:'bottom'})));
  const r=await mesure(p,'etudes3','EXBET');ok(r.bas,'Réglage de la barre des modules « En bas » → onglets en bas, même sur grand écran');await p.close();
  const q=await page(390,800,null);await q.evaluate(()=>localStorage.setItem('exb_dock_v1',JSON.stringify({layout:'left'})));
  const r2=await mesure(q,'etudes3','EXBET');ok(r2.gauche,'Réglage « À gauche » → onglets à gauche, même sur téléphone');await q.close();}

 /* 4) barres des autres modules (Paie V81, TFL, reçus, Finances) : même comportement, y compris dans un cadre fenêtre */
 {const p=await page(1280,800,null);
  const r=await p.evaluate(()=>{const out={};
   const mk=(host,tabs,act,bar)=>{const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:2147483647;background:#0004;display:flex;justify-content:center;padding:10px;overflow:auto';
     o.innerHTML='<div style="background:#fff;width:100%;max-width:940px;border-radius:12px;padding:14px;box-sizing:border-box;height:fit-content"><h3>Titre</h3><div class="'+bar+'">'+tabs.map((t,i)=>'<button type="button" class="'+(i===act?'on':'')+'">'+t+'</button>').join('')+'</div><div style="height:900px">contenu</div></div>';document.body.appendChild(o);return o};
   const fin=mk('',['🧾 Avoirs','📅 Échéanciers','📒 Journal','🧮 TVA','📊 États','👥 Paie','🏛 Bilan complet','🧱 Ouverture & immos','💰 Paie V81','🔒 Clôture'],8,'cpt_tabs');
   window.EXBOnglets.scan();
   const c=fin.querySelector('.exb-onglets'),R=e=>e.getBoundingClientRect(),bs=[...c.children].filter(x=>x.tagName==='BUTTON'),cr=R(c),ct=[...c.parentElement.children].find(x=>x.textContent==='contenu');
   return{gauche:c.classList.contains('exb-rl'),colonne:new Set(bs.map(x=>Math.round(R(x).left))).size===1,n:bs.length,contenuADroite:R(ct).left>=cr.right-1,titreADroite:R([...c.parentElement.children].find(x=>x.tagName==='H3')).left>=cr.right-1,actif:bs.filter(x=>x.classList.contains('exb-on'))[0].textContent}});
  ok(r.gauche&&r.colonne,'Finances & comptabilité : les '+r.n+' onglets sont en colonne à gauche (plus de retour à la ligne)');
  ok(r.contenuADroite&&r.titreADroite,'Finances & comptabilité : titre et contenu sont à droite de la colonne');
  ok(/Paie V81/.test(r.actif),'Finances & comptabilité : l’onglet actif reste « Paie V81 »');
  ok(p.errs.length===0,'aucune erreur JavaScript'+(p.errs[0]||''));await p.close();}

 /* 5) « tout passe ainsi » : barres de 2 onglets, panneau plein écran en colonne (messagerie), suivi des paiements, workflow */
 {const p=await page(1280,800,null);
  const r=await p.evaluate(()=>{const out={};const R=e=>e.getBoundingClientRect();
   const mk=(html)=>{const o=document.createElement('div');o.innerHTML=html;document.body.appendChild(o);return o};
   /* 2 onglets (Métré / Studio d'affiches) */
   const a=mk('<div id="t2"><h3>Titre</h3><div id="mb_seg"><button class="on" data-m="mb">🧱 Métré béton armé</button><button data-m="quick">Devis rapide</button></div><div id="pan" style="height:300px">panneau</div></div>');
   /* suivi des paiements des participants */
   const b=mk('<div id="t3"><div id="payBarTest" class="exb-tabs"><button type="button" data-tab="list" style="outline:3px solid #c9a227">👤 Liste</button><button type="button" data-tab="pay">💰 Paiements</button></div><div style="height:200px">liste</div></div>');
   /* messagerie : panneau plein écran en colonne, corps défilant */
   const c=mk('<div id="exbMsgr" class="on" style="position:fixed;inset:0;z-index:2147483646;background:#f4f6fb;display:flex;flex-direction:column"><div class="mh" style="background:#12254a;color:#fff;padding:12px">✉️ Messagerie</div><div class="tabs"><button class="tab on">Tous</button><button class="tab">Clients</button><button class="tab">Équipe</button></div><div class="bdy" style="flex:1;overflow-y:auto"><div style="height:2000px">fil</div></div></div>');
   window.EXBOnglets.scan();
   const t2=document.getElementById('mb_seg'),t3=document.getElementById('payBarTest'),ms=document.querySelector('#exbMsgr .tabs'),bdy=document.querySelector('#exbMsgr .bdy'),box=document.getElementById('exbMsgr');
   out.t2=t2.classList.contains('exb-rl');out.t2cont=R(document.getElementById('pan')).left>=R(t2).right-1;
   out.t3=t3.classList.contains('exb-rl');out.t3act=[...t3.children].filter(x=>x.tagName==='BUTTON'&&x.classList.contains('exb-on')).length;
   out.ms=ms.classList.contains('exb-rb');out.msBas=R(ms).bottom<=innerHeight+1&&R(ms).top>R(bdy).top;out.bdyBorne=R(bdy).height<innerHeight&&bdy.scrollHeight>bdy.clientHeight;out.msFond=getComputedStyle(ms).backgroundColor;
   return out});
  ok(r.t2&&r.t2cont,'Barre de 2 onglets (Métré, Studio d\u2019affiches) : aussi en colonne à gauche, contenu à droite');
  ok(r.t3&&r.t3act===1,'Suivi des paiements des participants : en colonne, onglet actif repéré');
  ok(r.ms&&r.msBas,'Messagerie (panneau plein écran en colonne) : onglets en barre du bas');
  ok(r.bdyBorne,'Messagerie : le fil garde sa hauteur et défile toujours (rien ne se bloque)');
  ok(/rgb\(18, 37, 74\)/.test(r.msFond),'Messagerie : la barre prend les couleurs de la colonne (fond imposé par le module écarté)');
  ok(p.errs.length===0,'aucune erreur JavaScript'+(p.errs[0]||''));await p.close();}
 await b.close();console.log(fails?('\n'+fails+' échec(s)'):'\nTous les contrôles passent');process.exit(fails?1:0);
})();
