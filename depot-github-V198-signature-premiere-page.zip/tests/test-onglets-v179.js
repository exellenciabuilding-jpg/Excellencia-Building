/* V179 — onglets uniformes : chaque barre reste sur UNE ligne, l'onglet actif est repéré, rien ne déborde de la page.
 * Usage : node tests/test-onglets-v179.js   (nécessite Playwright + Chromium) */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
(async()=>{
 const b=await chromium.launch();let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
 for(const [nom,w,h] of [['téléphone',390,800],['tablette',768,900],['bureau',1280,800]]){
  const p=await b.newPage({viewport:{width:w,height:h}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.addInitScript(()=>{try{localStorage.setItem('exb_onglets_v1','{"pos":"top"}')}catch(e){}});await p.goto('file://'+path.resolve(__dirname,'../site/index.html'));await p.waitForTimeout(3500);
  /* barre de démonstration avec les 10 onglets de la capture, sur le même modèle que le module Finances & comptabilité */
  await p.evaluate(()=>{
   const o=document.createElement('div');o.id='demoOv';o.style.cssText='position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.3);display:flex;justify-content:center;padding:10px';
   const T=['🧾 Avoirs','📅 Échéanciers','📒 Journal','🧮 TVA','📊 États','👥 Paie','🏛 Bilan complet','🧱 Ouverture & immos','💰 Paie V81','🔒 Clôture'];
   o.innerHTML='<div style="background:#fff;width:100%;max-width:940px;border-radius:12px;padding:14px;box-sizing:border-box;height:fit-content"><div class="cpt_tabs" style="margin:8px 0"></div></div>';
   document.body.appendChild(o);
   o.querySelector('.cpt_tabs').innerHTML=T.map((t,i)=>'<button type="button" data-t="'+i+'" style="padding:8px 10px;margin-right:4px;'+(i===8?'font-weight:700;border-bottom:3px solid #1d4ed8':'')+'">'+t+'</button>').join('');
  });
  await p.waitForTimeout(400);
  const r=await p.evaluate(()=>{const c=document.querySelector('.cpt_tabs'),bs=[...c.children],tops=new Set(bs.map(x=>Math.round(x.getBoundingClientRect().top)));
   const act=bs.filter(x=>x.classList.contains('exb-on'));
   return {lignes:tops.size,actifs:act.length,actif:act[0]&&act[0].textContent,aria:act[0]&&act[0].getAttribute('aria-selected'),visible:act[0]&&(()=>{const a=act[0].getBoundingClientRect(),k=c.getBoundingClientRect();return a.left>=k.left-1&&a.right<=k.right+1})(),
    debordePage:document.documentElement.scrollWidth>window.innerWidth+1,defile:c.scrollWidth>c.clientWidth+2,role:c.getAttribute('role')}});
  ok(r.lignes===1,nom+' ('+w+'px) : tous les onglets sur une seule ligne');
  ok(r.actifs===1&&/Paie V81/.test(r.actif)&&r.aria==='true',nom+' : un seul onglet actif repéré (Paie V81)');
  ok(r.visible,nom+' : l\u2019onglet actif est visible dans la barre'+(r.defile?' (barre défilante)':' (tout tient)'));
  ok(!r.debordePage,nom+' : la page ne déborde pas à l\u2019horizontale');
  ok(r.role==='tablist',nom+' : rôle d\u2019accessibilité tablist');
  if(w===390)await p.screenshot({path:path.resolve(__dirname,'../onglets-v179-telephone.png')});
  ok(errs.length===0,nom+' : aucune erreur JavaScript'+(errs.length?' '+errs[0]:''));
  await p.close();
 }

 /* les autres modules : chaque façon de signaler l'onglet actif doit être reconnue */
 {const p=await b.newPage({viewport:{width:390,height:800}});await p.addInitScript(()=>{try{localStorage.setItem('exb_onglets_v1','{"pos":"top"}')}catch(e){}});await p.goto('file://'+path.resolve(__dirname,'../site/index.html'));await p.waitForTimeout(3000);
  const cas=await p.evaluate(()=>{
   const mk=(cls,html)=>{const c=document.createElement('div');c.className=cls;c.innerHTML=html;document.body.appendChild(c);return c};
   const B=(a,l)=>'<button'+(a?' '+a:'')+'>'+l+'</button>';
   const cases={
    budget:mk('bf-tabs',B('class="muted"','a')+B('class="muted on"','b')+B('class="muted"','c')),
    controles:mk('tabs exb-tabs',B('class="muted"','a')+B('class=""','b')+B('class="muted"','c')),
    portails:mk('pt-tabs',B('class="pt-s"','a')+B('class="pt-s"','b')+B('','c')),
    crm:mk('crp_tabs',B('style="padding:6px 10px"','a')+B('style="padding:6px 10px;font-weight:700;border:2px solid #1d4ed8"','b')+B('style="padding:6px 10px"','c')),
    metres:mk('mbtabs',B('class=""','a')+B('class=""','b')+B('class="on"','c')),
    v51:mk('exb-v51-tabs',B('class="active"','a')+B('','b')+B('','c')),
    archives:mk('exb-tabs',B('class="ar-tab" style=""','a')+B('class="ar-tab" style="font-weight:700;border-bottom:3px solid #c9a24b"','b')+B('class="ar-tab" style=""','c')),
    paiements:mk('','')};
   const pb=document.createElement('div');pb.id='exbPayBar';pb.innerHTML=B('style="outline:3px solid #c9a227"','a')+B('','b');document.body.appendChild(pb);cases.paiements=pb;
   window.EXBOnglets.scan();
   const out={};for(const k in cases){const c=cases[k];out[k]={actifs:[...c.children].map((x,i)=>x.classList.contains('exb-on')?i:-1).filter(i=>i>=0),n:c.children.length,flex:getComputedStyle(c).flexWrap}}return out});
  const attendu={budget:[1],controles:[1],portails:[2],crm:[1],metres:[2],v51:[0],archives:[1],paiements:[0]};
  for(const k in attendu)ok(JSON.stringify(cas[k].actifs)===JSON.stringify(attendu[k])&&cas[k].flex==='nowrap',k+' : onglet actif reconnu et barre sur une seule ligne');
  await p.close();}
 await b.close();console.log(fails?'\n'+fails+' échec(s)':'\nTous les contrôles réussis');process.exit(fails?1:0)})();
