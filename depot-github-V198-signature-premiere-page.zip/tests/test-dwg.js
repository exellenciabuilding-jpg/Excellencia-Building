const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path'),fs=require('fs');
let fail=0;const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ ')+m);if(!c)fail++};
const dxf=fs.readFileSync(path.resolve(__dirname,'../site/tools/test-bim/villa-RDC.dxf'),'utf8');
(async()=>{
 const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file://'+path.resolve(__dirname,'harness-dwg.html'));
 const mk=(hdr)=>`(()=>{const u=new Uint8Array(200);const s='${hdr}';for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u.buffer})()`;
 let r;
 r=await p.evaluate(async(a)=>{try{await EXB_DWG.toDxf(new Blob([new Uint8Array(0)]));return 'ok'}catch(e){return e.message}});ok(/vide/.test(r),'fichier vide refusé');
 r=await p.evaluate(async()=>{try{await EXB_DWG.toDxf(new Blob(['0\nSECTION\n2\nHEADER\n']));return 'ok'}catch(e){return e.message}});ok(/pas un DWG valide/.test(r),'DXF renommé en .dwg refusé : '+r.slice(0,50));
 r=await p.evaluate(async()=>{const u=new Uint8Array(300);'AC1032'.split('').forEach((c,i)=>u[i]=c.charCodeAt(0));return EXB_DWG.head(u.buffer)});ok(r&&r.label==='AutoCAD 2018 et +','version reconnue : '+(r&&r.label));
 console.log('Sans convertisseur');
 r=await p.evaluate(async()=>{const u=new Uint8Array(300);'AC1027'.split('').forEach((c,i)=>u[i]=c.charCodeAt(0));return EXB_DWG.toDxf(new Blob([u]))});ok(r===null,'aucun convertisseur : null (le lecteur retombe sur l’aide)');
 console.log('Avec convertisseur (faux, renvoie un vrai DXF de test)');
 await p.evaluate((t)=>{window.EXB_DWG_CONVERTER={name:'faux',convert:async(buf)=>t}},dxf);
 r=await p.evaluate(async()=>{const u=new Uint8Array(300);'AC1027'.split('').forEach((c,i)=>u[i]=c.charCodeAt(0));const t=await EXB_DWG.toDxf(new Blob([u]));return{len:t.length,aud:window.__audit.slice()}});ok(r.len>200,'DXF accepté ('+r.len+' car.)');ok(r.aud.includes('plans.dwg.converti'),'journalisé sans contenu');
 console.log('Convertisseur défaillant');
 for(const [name,fn,re] of [['vide','async()=>""',/aucun DXF/],['sans entités','async()=>"0\\nSECTION\\n2\\nHEADER\\n0\\nENDSEC\\n0\\nSECTION\\n2\\nTABLES\\n0\\nENDSEC\\n"+" ".repeat(200)+"\\n0\\nEOF\\n"',/ENTITIES|entité/],['exception','async()=>{throw new Error("wasm: out of memory")}',/out of memory/]]){
  r=await p.evaluate(async(f)=>{window.EXB_DWG_CONVERTER={name:'x',convert:eval(f)};const u=new Uint8Array(300);'AC1018'.split('').forEach((c,i)=>u[i]=c.charCodeAt(0));try{await EXB_DWG.toDxf(new Blob([u]));return 'ok'}catch(e){return e.message}},fn);ok(re.test(r),name+' : '+r.slice(0,60));}
 r=await p.evaluate(()=>window.__audit.includes('plans.dwg.echec'));ok(r,'échec journalisé');
 ok(errs.length===0,'0 erreur JS');
 await b.close();console.log(fail?'\n'+fail+' ÉCHEC(S)':'\nTous les tests passent.');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1)});
