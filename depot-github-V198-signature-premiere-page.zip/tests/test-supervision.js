const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
let fail=0;const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ ')+m);if(!c)fail++};
(async()=>{
 const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 let sbUp=true;
 await p.route('https://sb.test/**',r=>sbUp?r.fulfill({status:200,headers:{'access-control-allow-origin':'*'},body:'{}'}):r.abort('failed'));
 await p.route('https://lic.test/**',r=>r.fulfill({status:200,headers:{'access-control-allow-origin':'*'},body:'{}'}));
 await p.route('https://moteur.test/**',r=>r.fulfill({status:200,body:'ok'}));
 await p.goto('file://'+path.resolve(__dirname,'harness-sup.html'));await p.waitForSelector('#bsup',{timeout:6000});
 /* fonctions pures */
 const pu=await p.evaluate(()=>{const P=EXBSUP.pure,h=(a)=>a.map((ok,i)=>({t:'2026-11-17T0'+i+':00:00Z',ok:ok,ms:ok?100:null}));
  return{vide:P.etat([]).code,ok:P.etat(h([1,1])).code,deg:P.etat(h([1,0])).code,panne:P.etat(h([1,0,0])).code,lent:P.etat([{t:'x',ok:true,ms:4000}]).code,dispo:P.etat(h([1,1,0,1])).dispo,
   t1:P.transition('ok','panne'),t2:P.transition('panne','ok'),t3:P.transition('ok','ok'),t4:P.transition('inconnu','panne'),t5:P.transition('ok','degrade'),
   cap:P.pushResult({a:Array(288).fill({ok:true})},'a',{t:'z',ok:true,ms:1},288).a.length,url1:P.sanitizeUrl('http://x'),url2:P.sanitizeUrl('https://x.cd/h')}});
 ok(pu.vide==='inconnu'&&pu.ok==='ok'&&pu.deg==='degrade'&&pu.panne==='panne'&&pu.lent==='degrade','états : inconnu / ok / dégradé / panne / lent');
 ok(pu.dispo===75,'disponibilité 75 %');
 ok(pu.t1==='panne'&&pu.t2==='retour'&&pu.t3===''&&pu.t4===''&&pu.t5==='','alertes seulement sur changement d’état');
 ok(pu.cap===288,'historique plafonné à 288 relevés'); ok(pu.url1===''&&pu.url2==='https://x.cd/h','seules les adresses https acceptées');
 /* écran */
 await p.click('#bsup');await p.waitForSelector('#sup_c table');await p.waitForSelector('[data-etat="ok"]');
 let t=await p.innerText('#sup_c');ok(/Connexion internet/.test(t)&&/Supabase/.test(t)&&/Serveur de licences/.test(t),'3 sondes affichées');
 ok(await p.locator('[data-etat="ok"]').count()===3,'3 services en service');
 /* panne Supabase : 2 mesures => en panne + alerte journalisée une seule fois */
 sbUp=false;await p.click('#sup_go');await p.waitForTimeout(500);await p.click('#sup_go');await p.waitForTimeout(500);
 ok(await p.locator('[data-etat="panne"]').count()===1,'Supabase en panne après 2 échecs');
 t=await p.innerText('#sup_c');ok(/Supabase/.test(t)&&/injoignable/.test(t),'motif affiché');
 await p.click('#sup_go');await p.waitForTimeout(500);
 let aud=await p.evaluate(()=>EXBCore.audit.list().filter(e=>e.action==='supervision.panne').length);ok(aud===1,'alerte de panne journalisée une seule fois');
 ok(/🔴1/.test(await p.innerText('#bsup')),'badge rouge sur le bouton');
 sbUp=true;await p.click('#sup_go');await p.waitForTimeout(500);
 aud=await p.evaluate(()=>EXBCore.audit.list().filter(e=>e.action==='supervision.retour').length);ok(aud===1,'retour en service journalisé');
 ok(await p.locator('[data-etat="ok"]').count()>=3,'services de nouveau en service');
 /* point de contrôle ajouté + refus http */
 await p.fill('#sup_n','Moteur docs');await p.fill('#sup_u','http://moteur.test');await p.click('#sup_add');
 ok(/https valide requise/.test(await p.innerText('#sup_m')),'adresse http refusée');
 await p.fill('#sup_u','https://moteur.test/health');await p.click('#sup_add');await p.waitForSelector('text=Moteur docs');await p.waitForTimeout(500);
 ok(await p.locator('[data-etat="ok"]').count()===4,'point de contrôle surveillé');
 /* reprise */
 await p.evaluate(()=>localStorage.setItem('exb_espace_todo',JSON.stringify([{x:1}])));await p.click('#sup_x');await p.click('#bsup');await p.waitForSelector('#sup_rep');
 ok(/\(1\)/.test(await p.innerText('#sup_rep')),'file d’attente affichée');
 ok(errs.length===0,'0 erreur JS'+(errs.length?' '+errs.join('|'):''));
 await b.close();console.log(fail?'\n'+fail+' ÉCHEC(S)':'\nTous les tests passent.');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1)});
