/* V185b — non-régression : (1) le journal chaîné d'exb-core.js ne doit plus planter quand l'ancien format V91 (tableau) est présent ;
 *         (2) l'OCR doit passer des URL ABSOLUES à Tesseract (chemin relatif invalide dans le worker). Usage : node tests/test-core-journal-ocr.js */
const fs = require('fs'), path = require('path'), assert = require('assert');
const site = path.resolve(__dirname, '..', 'site');
(async () => {
  const store = { exb_core_audit: JSON.stringify([{ id: 'AUD-1', action: 'x' }]), exb_core_events: JSON.stringify({ x: 1 }) };
  global.window = global;
  global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
  global.crypto = require('crypto').webcrypto;
  require(path.join(site, 'exb-core.js'));
  assert.ok(Array.isArray(EXBCore.audit.list()), 'audit.list() doit renvoyer un tableau');
  await EXBCore.audit.log('test', 'obj', { a: 1 });
  const v = await EXBCore.audit.verify();
  assert.ok(v.ok && v.entries >= 1, 'la chaîne doit être intacte');
  assert.ok(Array.isArray(JSON.parse(store.exb_core_audit)), 'le tableau V91 ne doit pas être écrasé');
  const ocr = fs.readFileSync(path.join(site, 'exb-ocr.js'), 'utf8');
  assert.ok(/absBase\(\)/.test(ocr) && /workerPath:\s*ABS/.test(ocr) && !/workerPath:\s*BASE/.test(ocr), 'workerPath doit être absolu');
  console.log('OK : journal chaîné compatible avec le format V91 ; OCR en URL absolues');
})().catch(e => { console.error('ÉCHEC :', e.message); process.exit(1); });
