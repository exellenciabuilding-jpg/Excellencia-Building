const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
let fail=0;const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ ')+m);if(!c)fail++};
(async()=>{
 const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file://'+path.resolve(__dirname,'harness-admin.html'));await p.waitForSelector('#badm2',{timeout:6000});
 /* faux serveur d'équipe */
 await p.evaluate(()=>{window.__M=[{user_id:'u1',nom:'Alice',email:'a@x.cd',role:'admin',fonction:'direction'},{user_id:'u2',nom:'Bob',email:'b@x.cd',role:'membre',fonction:'comptable'}];
  window.exbSb={isIn:()=>true,api:(u)=>Promise.resolve(/mon_organisation/.test(u)?{id:'o1',role:'admin'}:{membres:window.__M})}});
 await p.click('#badm2');await p.click('.adm_tabs button[data-t="revue"]');
 let t=await p.innerText('.adm_body');ok(/Aucune revue des accès enregistrée/.test(t),'jamais de revue : alerte affichée');
 await p.click('#rv_go');await p.waitForSelector('[data-rv="u1"]');
 await p.fill('#rv_par','Direction');await p.click('#rv_fin');
 t=await p.innerText('#rv_msg');ok(/sans décision/.test(t),'clôture refusée sans décision pour chaque compte');
 await p.selectOption('[data-rv="u1"]','maintenir');await p.selectOption('[data-rv="u2"]','retirer');
 await p.fill('#rv_par','');await p.click('#rv_fin');t=await p.innerText('#rv_msg');ok(/relecteur requis/.test(t),'relecteur obligatoire');
 await p.fill('#rv_par','Direction');await p.click('#rv_fin');
 t=await p.innerText('.adm_body');ok(/Revue enregistrée \(2 comptes, 1 à retirer\)/.test(t)&&/Dernière revue/.test(t),'revue enregistrée, échéance affichée');
 const aud=await p.evaluate(()=>JSON.stringify(EXBCore.audit.list()));ok(/admin\.revue\.terminee/.test(aud),'revue journalisée');
 /* écarts : Bob retiré, Carl nouveau */
 await p.evaluate(()=>{window.__M=[window.__M[0],{user_id:'u3',nom:'Carl',email:'c@x.cd',role:'membre',fonction:'rh'}]});
 await p.click('#rv_go');await p.waitForSelector('[data-rv="u3"]');
 t=await p.innerText('.adm_body');ok(/1 nouveau\(x\) compte\(s\), 1 retiré\(s\)/.test(t),'écarts depuis la dernière revue');
 /* fonctions pures : échéance */
 const e=await p.evaluate(()=>({a:EXBADM._rvEtat({periode:90,hist:[{le:'2026-01-01',par:'x'}]},'2026-04-02'),b:EXBADM._rvEtat({periode:90,hist:[{le:'2026-01-01',par:'x'}]},'2026-03-31')}));
 ok(e.a.due===true&&e.b.due===false,'échéance à 90 jours');
 const csv=await p.evaluate(()=>EXBADM._rvCsv({le:'2026-11-17',par:'=cmd',maintenus:1,aRetirer:[{nom:'=HYPERLINK("x")',email:'',role:'',fonction:''}]}));ok(!/;"?=HYP|"=HYP/.test(csv)||/'=HYP/.test(csv),'CSV neutralise les formules');
 ok(errs.length===0,'0 erreur JS'+(errs.length?' '+errs.join('|'):''));
 await b.close();console.log(fail?'\n'+fail+' ÉCHEC(S)':'\nTous les tests passent.');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1)});
