/* V180 — onglets uniformes dans TOUS les modules (Chantiers, Études, Planning, Terrain, Paie V81, TFL/bibliothèque,
 * Reçus-paiements, Métré, Studio d'affiches) : une seule ligne, onglet actif repéré, aucun débordement de page.
 * Usage : node tests/test-onglets-v180.js   (nécessite Playwright + Chromium) */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
(async()=>{
 const b=await chromium.launch();let fails=0;const ok=(c,m)=>{console.log((c?'  OK   ':'  FAIL ')+m);if(!c)fails++};
 for(const [nom,w,h] of [['téléphone',390,800],['bureau',1280,800]]){
  const p=await b.newPage({viewport:{width:w,height:h}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
  await p.addInitScript(()=>{try{localStorage.setItem('exb_onglets_v1','{"pos":"top"}')}catch(e){}});await p.goto('file://'+path.resolve(__dirname,'../site/index.html'));await p.waitForTimeout(3500);
  await p.evaluate(()=>{(window.exbSessionStorage||sessionStorage).setItem('exb_logged','1');document.getElementById('app').style.display='block';const lg=document.getElementById('login');if(lg)lg.style.display='none'});
  const mods=[['Chantiers','chantiers','EXBCH'],['Études (Architecture)','etudes3','EXBET'],['Planning','plangantt','EXBPL'],['Terrain','terrain','EXBTR']];
  for(const [lib,id,M] of mods){
   /* tout dans le même instant : l'application retire d'elle-même les sections non autorisées quand personne n'est connecté */
   const m=await p.evaluate(([id,M])=>{try{show(id)}catch(e){}try{window[M].render()}catch(e){}
     window.EXBOnglets.scan();
     const sec=document.getElementById(id),c=sec&&sec.querySelector('.exb-onglets');
     if(!c) return {pasdebarre:true,sec:!!sec};
     const bs=[...c.children].filter(x=>x.tagName==='BUTTON'),tops=new Set(bs.map(x=>Math.round(x.getBoundingClientRect().top)));
     return {n:bs.length,lignes:tops.size,actifs:bs.filter(x=>x.classList.contains('exb-on')).length,role:c.getAttribute('role'),debordePage:document.documentElement.scrollWidth>window.innerWidth+1}},[id,M]);
   if(m.pasdebarre){ok(false,lib+' ('+nom+') : barre non raccordée à l\u2019adaptateur (section '+(m.sec?'présente':'absente')+')');continue}
   ok(m.lignes===1&&m.role==='tablist',lib+' ('+nom+') : '+m.n+' onglets sur une seule ligne, rôle tablist');
   ok(m.actifs===1,lib+' ('+nom+') : onglet actif repéré');
   ok(!m.debordePage,lib+' ('+nom+') : la page ne déborde pas');
  }
  /* barres créées par du code partagé : on contrôle les balises produites (même structure que dans les modules) */
  const g2=await p.evaluate(()=>{
    const mk=(html,id)=>{const c=document.createElement('div');if(id)c.id=id;c.innerHTML=html;document.body.appendChild(c);return c};
    const out={};
    const bar=(c)=>{const e=c.querySelector('.exb-onglets,.exb-tabs');return e};
    /* Paie V81 : structure produite par tabs() */
    const T=['🧾 Bulletins','📄 Contrats','🌴 Congés','💵 Avances','🦺 Habilitations','⚙ Barèmes'];
    out.paie=mk('<div class="exb-tabs">'+T.map((t,i)=>'<button type="button" class="'+(i===2?'on':'')+'">'+t+'</button>').join('')+'</div>');
    out.tfl=mk('<div class="exb-tabs"><button type="button" class="">🎓 TFL résolus (12)</button><button type="button" class="on">📥 Sujets reçus (4, 2 à étudier)</button><button type="button" class="">🤝 Contributions (3 nouvelles)</button></div>');
    const pt=document.getElementById('payTabs');
    pt.innerHTML=['À encaisser','Payés','Tous','Refusés','Archivés'].map((t,i)=>'<button type="button" data-tab="'+i+'" class="'+(i===1?'on':'')+'">'+t+' ('+i+')</button>').join('')+'<button type="button" data-tab="__r">↻</button>';
    document.getElementById('payTabs').closest('section').style.display='block';
    out.pay=pt.parentElement;
    window.EXBOnglets.scan();
    const r={};
    const test=(k,c)=>{if(!c)return r[k]={absent:true};const bs=[...c.children].filter(x=>x.tagName==='BUTTON');r[k]={lignes:new Set(bs.map(x=>Math.round(x.getBoundingClientRect().top))).size,actifs:bs.filter(x=>x.classList.contains('exb-on')).length,role:c.getAttribute('role')}};
    const all=[...document.querySelectorAll('.exb-onglets')];
    test('paie',all.find(c=>/Bulletins/.test(c.textContent)));test('tfl',all.find(c=>/TFL résolus/.test(c.textContent)));test('pay',document.getElementById('payTabs'));
    return r});
  for(const k of Object.keys(g2)){const m=g2[k];ok(!m.absent&&m.lignes===1&&m.actifs===1&&m.role==='tablist',({paie:'Paie V81',tfl:'TFL / bibliothèque (Formation)',pay:'Reçus — paiements'})[k]+' ('+nom+') : une ligne, onglet actif repéré');}
  ok(errs.length===0,nom+' : aucune erreur JavaScript'+(errs.length?' '+errs[0]:''));
  await p.close();
 }
 await b.close();console.log(fails?('\n'+fails+' échec(s)'):'\nTous les contrôles passent');process.exit(fails?1:0);
})();
