const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
(async()=>{const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 p.on('requestfailed',r=>{if(/exb-(dwg|sauvegarde-chiffree)/.test(r.url()))errs.push('404 '+r.url())});
 await p.goto('file://'+path.resolve(__dirname,'../site/index.html'));await p.waitForTimeout(6000);
 const r=await p.evaluate(()=>({bkc:typeof window.EXB_BKC,dwg:typeof window.EXB_DWG,abk:typeof window.EXB_ABK,adm:typeof window.EXBADM,sec:typeof window.EXBSEC}));
 console.log(JSON.stringify(r),'erreurs JS:',errs.length,errs.slice(0,4));await b.close();})();
