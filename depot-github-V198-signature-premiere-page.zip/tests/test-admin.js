const {chromium}=require('/opt/npm-tools/node_modules/playwright');const path=require('path');
let fail=0;const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ ')+m);if(!c)fail++};
(async()=>{
 const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 const now=Date.now(),calls=[];let devs=[{device:'AAAA-BBBB-CCCC',libelle:'Win32',plateforme:'web',version:'V175',premier_vu:new Date(now-9e8).toISOString(),dernier_vu:new Date(now-6e5).toISOString()},{device:'DDDD-EEEE-FFFF',libelle:'Android',plateforme:'android',version:'V170',premier_vu:new Date(now-9e8).toISOString(),dernier_vu:new Date(now-86400e3*12).toISOString()}];
 await p.route('https://lic.test/**',async r=>{const j=JSON.parse(r.request().postData());calls.push(j);let out;
  if(j.code!=='EXC-AAAA-BBBB-CCCC')out={ok:false,raison:'code_invalide',msg:'Code d’activation inconnu. Vérifiez votre saisie.'};
  else if(j.action==='devices')out={ok:true,nom:'Client test',statut:'actif',max:2,exp:new Date(now+9e9).toISOString(),appareils:devs};
  else if(j.action==='release_own'){devs=devs.filter(x=>x.device!==j.device);out={ok:true,libere:j.device}}
  await r.fulfill({status:200,contentType:'application/json',headers:{'access-control-allow-origin':'*'},body:JSON.stringify(out)})});
 await p.goto('file://'+path.resolve(__dirname,'harness-admin.html'));await p.waitForSelector('#badm2',{timeout:6000});
 await p.click('#badm2');await p.click('.adm_tabs button[data-t="appareils"]');
 let t=await p.innerText('.adm_body');ok(/Cette session/.test(t)&&/AAAA-BBBB-CCCC/.test(t),'session : appareil affiché');
 await p.fill('#adm_code','EXC-ZZZZ-ZZZZ-ZZZZ');await p.click('#adm_dev_go');await p.waitForTimeout(300);
 t=await p.innerText('#adm_dev_out');ok(/inconnu/.test(t),'mauvais code : message du serveur');
 await p.fill('#adm_code','EXC-AAAA-BBBB-CCCC');await p.click('#adm_dev_go');await p.waitForTimeout(300);
 t=await p.innerText('#adm_dev_out');ok(/2 \/ 2/.test(t)&&/Android/.test(t),'liste des 2 appareils (2 / 2)');
 ok(/actif/.test(t)&&/inactif/.test(t)&&/cet appareil/.test(t),'session active / inactive / cet appareil');
 await p.click('[data-rel="DDDD-EEEE-FFFF"]');await p.waitForTimeout(500);
 t=await p.innerText('#adm_dev_out');ok(/1 \/ 2/.test(t)&&!/Android/.test(t),'appareil libéré, liste rafraîchie');
 ok(calls.some(c=>c.action==='release_own'&&c.device==='DDDD-EEEE-FFFF'),'appel release_own envoyé');
 const aud=await p.evaluate(()=>JSON.stringify(EXBCore.audit.list()));ok(/admin\.appareil\.libere/.test(aud)&&!/EXC-AAAA/.test(aud),'action journalisée, code d’activation absent du journal');
 const st=await p.evaluate(()=>Object.keys(localStorage).some(k=>/EXC-AAAA/.test(localStorage.getItem(k)||'')));ok(!st,'code d’activation non conservé');
 ok(errs.length===0,'0 erreur JS'+(errs.length?' '+errs.join('|'):''));
 await b.close();console.log(fail?'\n'+fail+' ÉCHEC(S)':'\nTous les tests passent.');process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(1)});
