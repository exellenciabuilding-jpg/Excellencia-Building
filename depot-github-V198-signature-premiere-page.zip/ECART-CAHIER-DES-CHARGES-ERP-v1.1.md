# Écart entre le cahier des charges ERP (v1.1, nov. 2026) et le code livré (v32 + V152/V153)

Méthode : lecture des 19 pages du cahier, puis recherche dans le code (`site/*.js`, `index.html`), les tables du catalogue `exb-db.js` et les « Non fait / Non vérifié » des README. **Aucune fonction n'a été exécutée** : « Présent » signifie qu'un code correspondant existe, pas qu'il a été testé sur vos données. Les modèles de documents (affiches, pièces) ne comptent pas comme preuve d'un module.

Légende : ✅ présent · 🟡 partiel / à confirmer · ❌ non constaté

## Modules
| # | Module | État | Constat |
|---|---|---|---|
| 01 | Business Intelligence | 🟡 | ✅ tableau de bord direction (`exb-bi.js`), créances/dettes, trésorerie, rapports PDF/CSV. 🟡 filtre département (V161 partiel). ❌ tableau **configurable** par l'utilisateur ; lecture RH / Stock / CRM / Workflow ; alertes à seuils paramétrables (peu de preuves). | **V173** : le tableau de bord s'adapte aux données (indicateurs à zéro et sections vides masqués, période élargie automatiquement si elle est vide, désactivable dans ⚙ Personnaliser).
| 02 | Project Manager | ✅/🟡 | ✅ planning, jalons, engagements, clôture/dossier final, report pointage→RH et matériaux→Stock (V161–V164). ❌ blocage/validation Workflow d'un achat au-delà du budget (règle à décider) ; la clôture ne bloque pas les nouvelles saisies. |
| 03 | Plan Editor | ✅/🟡 | ✅ calques, cotations, cartouches/feuilles, versions, import PDF, DXF, IFC. 🟡 **DWG** : **V175** pont `exb-dwg.js` (version, contrôles, lecture via un convertisseur DWG→DXF **à fournir**, non livré) ; sans convertisseur : rangement seul ; écriture DWG non faite (le cahier dit « formats retenus après validation technique »). |
| 04 | CRM | ✅/🟡 | ✅ clients, devis, parcours, portail client. ✅ **V172** (`exb-crm-plus.js`) : pipeline d'opportunités (6 étapes, motif de perte, valeur pondérée, conversion), relances & rendez-vous, versions de devis figées + comparaison + conversion en contrat, réclamations (4 statuts), satisfaction (note 1–5). 🟡 à valider sur données réelles ; pas de rappel automatique (notification) des relances en retard. |
| 05 | HR | 🟡 | ✅ présences, congés, paie (`v81-paie`), contrats (`exb_hr_contracts`), évaluations. 🟡 compétences/formations liées au dossier, export vers un processus de paie validé à confirmer. |
| 06 | Stock & Procurement | ✅/🟡 | ✅ stock, mouvements, commandes, réceptions, fournisseurs. ✅ **V172** (`exb-stock-plus.js`) : dépôts + transferts (soldes calculés), inventaires physiques avec motif d'écart obligatoire et ajustement tracé, comparatifs fournisseurs (motif si non moins-disant), rapprochement commande/réception/facture/paiement. 🟡 le stock ne porte pas de prix (pas de valorisation) ; rapprochement des factures fournisseurs par n° de BC seulement. |
| 07 | Workflow | ✅ | circuits configurables, étapes séquentielles et **parallèles** (tous / un seul), rejet motivé, historique (`exb-workflow.js`, liens V148). 🟡 délégations et rappels automatiques à confirmer. |
| 08 | Archives | ✅/🟡 | ✅ classement, métadonnées, versions (« nouvelle version »), partage, historique (V149). 🟡 **droits appliqués côté écran seulement** (pas de serveur/RLS) ; dépôt direct depuis Plan Editor / Project Manager non fait. |
| 09 | Portail TFL | ✅/🟡 | ✅ candidature, sujets, chapitres/versions/corrections, messagerie, paiements. 🟡 **préparation de soutenance** : seulement un statut. |
| 10 | Certificats | ✅ | numérotation unique, registre, QR + vérification, statuts (annulé/réactivé). 🟡 statut « **suspendu** » vs « annulé » à aligner ; **traitement par lot** peu visible (« imprimer tous » seulement). |
| 11 | Server | 🟡 | espace serveur, sauvegarde/synchronisation, santé. Dépend de Supabase : supervision et reprise des traitements limitées côté client. |
| 12 | Licences | ✅ | activation, 2 appareils, suspension/révocation, expiration (`exb-license.js`, `exb-proprietaire.js`). |
| 13 | Scanner | 🟡 | ✅ capture, recadrage, rotation, filtres, PDF, dépôt Archives, rattachement projet/client (V151–V152). **OCR : moteur Tesseract.js installé en V175 (7 fichiers, lecture testée sur une facture en français)** ; bouton à valider sur vos vrais documents. ❌ correction de perspective, import de PDF existants. |
| 14 | Administration | 🟡 | ✅ rôles/permissions, audit chaîné SHA-256 + export CSV, droits effectifs (V152). ✅ **V175** : sessions & appareils de la licence (liste, activité, libération à distance par code d'activation ; fonction `licence` à redéployer). ❌ délégations, revue périodique des accès, comptes/sessions des autres utilisateurs (dépendent de Supabase Auth/RLS). Journal limité à 500 entrées locales. |
| 15 | Finances & Comptabilité | ✅/🟡 | ✅ factures, paiements, caisse, budgets, rapprochement bancaire, créances/dettes ; **V165 : avoirs, échéanciers avec alertes de retard, journal / balance / grand livre, clôture mensuelle avec empreinte** (`exb-compta.js`). 🟡 plan comptable indicatif à valider (fiscalité RDC). **V166 : TVA récupérable (registre de justificatifs + état de TVA), compte de résultat, bilan simplifié, verrou optionnel des périodes clôturées** (`exb-compta-etats.js`). 🟡 bilan SIMPLIFIÉ (ni capital, immobilisations, à-nouveaux ni amortissements) ; TVA à valider avec le comptable ; verrou désactivé par défaut. ❌ écritures de paie. | **V173** (`exb-compta-paie.js`) : paie (brut → net, CNSS/impôt à taux saisis, validation = écritures, paiement lié à la caisse), bilan complet (immobilisations nettes, stocks, créances, trésorerie, capitaux propres, dettes), opérations diverses / ouverture, immobilisations + amortissement linéaire, valorisation de stock.

## Exigences transversales (sections 6 à 10)
| Exigence | État |
|---|---|
| MFA pour comptes privilégiés | ✅ `exb-mfa.js` |
| Sauvegardes automatiques | ✅ `exb-sauvegarde-auto.js` ; ✅ **V175** `exb-sauvegarde-chiffree.js` : chiffrement AES-256-GCM + test de restauration rejoué en mémoire (auto hebdomadaire) |
| RPO / RTO définis | 🟡 **V175** : objectifs saisissables (24 h / 60 min par défaut, à valider) et comparés au test |
| Exports PDF/Excel contrôlés par permissions | 🟡 seulement dans `exb-v81-pilotage.js` (`exportCsv`) |
| Pagination / filtres serveur / chargement progressif | 🟡 listes limitées à 150 lignes + « Afficher plus » ; pas de filtre serveur |
| Données de démonstration séparées de la production | 🟡 à confirmer |
| Identifiant, auteur, date, statut, lien projet sur chaque opération | 🟡 vrai pour les modules récents ; à vérifier sur les anciens |
| Environnements séparés (dev / pré-prod / prod) | ❌ hors code (organisation) |
| Cloisonnement réel des données | ❌ droits côté écran ; RLS Supabase à concevoir |

## Ordre de priorité proposé
1. **Moteur OCR** (fichiers Tesseract à fournir, voir README-V153).
2. ~~Finances : avoirs, échéanciers, écritures/journaux~~ → fait en V165 ; ~~TVA récupérable, bilan / résultat, blocage après clôture~~ → fait en V166 ; reste **écritures de paie**.
~~3. **CRM** : pipeline d'opportunités, relances/rendez-vous, versions de devis, réclamations.~~ — fait en V172
~~4. **Stock** : transferts entre dépôts, inventaires et ajustements, comparatif fournisseurs.~~ — fait en V172
5. **BI** : filtre département complet, tableau configurable, lecture RH/Stock/CRM/Workflow.
6. **Admin/Server** : sessions/appareils, revue des accès, RLS (nécessite Supabase).
7. **Sécurité** : sauvegardes chiffrées + test de restauration, RPO/RTO, droits sur les exports.
