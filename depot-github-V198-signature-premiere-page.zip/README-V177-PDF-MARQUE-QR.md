# V177 — Export PDF de marque (CRM et paie V81) avec QR code

Appliqué sur la V176. Nouveau fichier `site/exb-rapport-marque.js` (module commun, aucune donnée stockée, aucune clé nouvelle).

## Ce qui est ajouté
- **CRM → onglet « 🔔 Alertes & export » → « 🖨 Rapport PDF »** : alertes, opportunités ouvertes (total par devise), relances en retard, réclamations non clôturées. Format A4 paysage.
- **Compta → « 💰 Paie V81 » → « 🖨 État de paie PDF »** : bulletins comptabilisés (brut, net dû, réglé, reste, totaux) et règlements enregistrés (USD).
- **Contenu commun** : logo, nom, slogan, adresse, téléphone, e-mail, site (identité unique `EXBId`), **QR de vérification public**, référence `RAP-AAAAMMJJ-xxxxx` (numéro du registre), date et auteur, mentions légales et pied de page de l'entreprise.
- **Sortie** : impression universelle `EXBPrint` (PDF direct sous Windows, « Enregistrer au format PDF » sous Android, aperçu plein écran dans le navigateur).
- **BI Direction** : le bouton « 📄 Rapport de direction (PDF) » existant prend maintenant le même en-tête de marque et le QR de vérification publique (préfixe `BI-`). Contenu inchangé (alertes, indicateurs, projets, activité des modules, historique). L'ancienne mise en page reste le repli si le module commun manque.
- **Stock** (compléments) : onglet « Rapport » → « 🖨 État du stock PDF » : soldes par dépôt et chaîne commandé → reçu → facturé → payé (préfixe `STK-`), A4 paysage.
- Le CSV de la V176 reste disponible.

## Vérification du QR (comme les autres documents)
Le QR ouvre `verification.html?c=g~RAP-…` (même page publique que devis, reçus, certificats et PDF du moteur commun, via `EXBVerif.docRec/publish`). À l'impression, chaque rapport est inscrit au registre (type « Document », code = empreinte du contenu) ; hors connexion il entre dans la file d'attente `exb_verif_pending` et part tout seul dès que possible. Le numéro imprimé est celui du registre. Sans `EXBVerif` (page isolée), repli sur un QR texte hors ligne.
Mise en place : identique aux autres documents (migration `v99m`/`v99o` déjà exécutée, connecté en administrateur au moins une fois pour publier). Un même contenu redonne le même numéro ; un contenu différent donne un nouveau numéro.

## Vérifié
`tools/test-rapport-marque-v177.js` (15 contrôles : en-tête, slogan, contact, échappement d'un nom piégé, empreinte, lien `verification.html?c=g~RAP-…`, inscription au registre, numéro imprimé = numéro du registre), `tools/check.js` 582/582, tests V176 inchangés (18 et 59), Chromium : 0 erreur JS, QR image généré, `verification.html` ouvre bien le lien (type Document, numéro, nom, date, code).
## Non vérifié
Lecture du QR avec un téléphone, confirmation « authentique » en ligne (nécessite le registre Supabase connecté), impression sur Android/Windows (EXE), données réelles.
