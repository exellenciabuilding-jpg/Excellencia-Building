# V186d — L'éditeur Word est branché sur les affiches (Studio libre)

Base : V186c. **Aucun SQL.** Nouveau fichier : `site/exb-v186d-affiches-word.js`. Fichiers modifiés : `site/exb-v123-editeur.js`, `site/exb-affiches-studio.js`, `site/index.html`, `site/sw.js` (cache), `site/exb-core.js` (étiquette « V186d-CORE »), `site/tools/check.js`. Nouveau test : `site/tools/e2e-affiches-word.py`.

## Ce que vous pouvez faire maintenant (Affiches › Studio libre)
- **✍️ Éditer avec Word** (panneau « Modifier », sur un texte sélectionné) : ouvre le vrai éditeur Word du logiciel — ruban complet (polices, tailles, couleurs, gras/italique/souligné, listes, tableaux, images, bandeaux colorés, alignements, interligne, rechercher/remplacer…). « ✓ Appliquer à l'affiche » (ou Ctrl+S) renvoie le texte mis en forme sur l'affiche ; « Annuler » (ou Échap) ferme sans rien changer.
- **✍️ Texte Word** (barre d'outils) : crée un nouveau texte et l'ouvre directement dans l'éditeur Word.
- **📝 Word (.docx)** (à côté de PNG et PDF) : tous les textes et toutes les images de l'affiche, dans l'ordre de lecture (de haut en bas), dans un document Word. Les textes clairs sur fond sombre gardent leur bandeau de couleur pour rester lisibles.
- Le texte mis en forme s'affiche sur l'affiche et dans les exports **PNG / PDF**, et il est conservé quand on **enregistre** l'affiche.
- « Texte simple » (panneau « Modifier ») retire la mise en forme Word d'un texte.

## Comment ça marche
- Le texte mis en forme est stocké dans l'élément (champ `rt`, même balisage que les pièces écrites). Le champ `tx` garde la version texte simple : l'affiche, les modèles et les anciennes affiches enregistrées continuent de fonctionner. Si on retire le nouveau fichier, le texte s'affiche en texte simple.
- Taille « 11 » dans l'éditeur = la taille actuelle du texte sur l'affiche ; les autres tailles sont proportionnelles (22 = deux fois plus grand). Sans couleur choisie, le texte garde la couleur de l'élément.
- `exb-v123-editeur.js` : `attach(x, ro, opts)` accepte maintenant des options (zone de texte, sans en-tête société, boutons masqués, actions personnalisées) et `EXBPIE_ED.detach()`. Les pièces écrites se comportent comme avant (vérifié).

## Limites connues
- Les **affiches Excellencia** (onglet 1 : affiche générale et affiche « logiciels », avec leurs zones de texte fixes) ne sont pas concernées : le branchement porte sur le Studio libre (352 modèles).
- Export Word : l'image de fond de l'affiche, les rectangles, cercles et traits ne sont pas repris (seuls textes et images le sont) ; les tailles sont proportionnelles à l'affiche, donc un grand titre reste grand. Texte autour des images : image placée en ligne (limite de l'export Word existant).
- Un seul éditeur Word peut être ouvert à la fois : si une pièce écrite est ouverte en édition, la fenêtre de l'affiche demande de la fermer d'abord.
- Non vérifié : téléphone Android (clavier tactile), Windows (Electron) réel, impression papier. Vérifié dans Chromium : édition, rendu, enregistrement, export PNG, export .docx (valide, ouvert avec LibreOffice et python-docx).

## Contrôles
`node site/tools/check.js` : 592 réussis, 0 échec · `python3 site/tools/e2e-affiches-word.py` : 19/19 · `python3 site/tools/e2e-affiches.py` : OK.
