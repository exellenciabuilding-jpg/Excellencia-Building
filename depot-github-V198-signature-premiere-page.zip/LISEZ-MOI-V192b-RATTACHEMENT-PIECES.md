# V192b — Pièces écrites : « Rattachée à » dès la création, choix mémorisé

Base : V192. **Aucun SQL.** Fichiers modifiés : `site/exb-v81-pieces.js`, `site/sw.js` (cache), `site/tools/check.js`. Nouveau test : `site/tools/e2e-pieces-rattachement.py`.

## Ce qui est ajouté (le choix « Sans chantier » de la V186h/V192 est conservé)
- **Menu « Rattachée à »** sur l'écran « type de pièce » et sur l'écran « modèle » : on choisit un chantier ou « Sans chantier » avant de créer, sans repasser par la liste.
- **Choix mémorisé** : le dernier choix « Sans chantier » est retenu à la réouverture ; choisir un chantier le remplace. Premier lancement : chantier actif, comme avant.
- **Pièce sans chantier** : les données de chantier des modèles ({{projet}}, {{client}}, {{moa}}, {{lieu}}, {{permis}}, {{phase}}) restent en blanc « ____ » à compléter, au lieu de jetons {{…}} bruts. Le PDF n'ajoute ni « Projet » ni « Lieu ».
- La liste « Sans chantier » inclut aussi les anciennes pièces sans champ « chantier ».

## Limites connues
- Le titre d'une pièce déjà créée ne change pas quand on modifie son rattachement.
- Les jetons non liés au chantier (ex. {{date_effet}}) restent à remplir avec « ↻ Remplir les données », comme avant.

## Contrôles
`node site/tools/check.js` : 623 réussis, 0 échec · `e2e-pieces-rattachement.py` : 13/13 · `e2e-pieces-sans-chantier.py`, `e2e-affiches-word.py`, `e2e-affiches-clavier.py` : OK.
