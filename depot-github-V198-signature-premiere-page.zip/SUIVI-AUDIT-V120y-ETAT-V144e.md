# Suivi de l'audit V120y — état dans la V144e

Légende : ✅ fait et vérifié en banc d'essai Chromium · 🟡 fait, à confirmer sur votre poste · ⏳ dépend d'une mesure chez vous

| Point de l'audit | État | Détail / preuve |
|---|---|---|
| 4.1 / P0 Dialogues natifs, rejeu de clic | ✅ | ≈ 55 appels migrés vers `await exbConfirm/exbPrompt`, rejeu supprimé. 2 `alert()` natifs volontaires (session expirée). Devis en double : « demande → réponse → enregistrement » sans exécution double (testé). |
| 4.2 Bouton `v77lift` (prompt 5,6 s) | ✅ | Plus de `prompt` dans `exb-v77.js` (formulaire intégré). |
| 4.3 / P2 Observateurs DOM | ✅ | v77 : ne traite que les nœuds ajoutés ; bigstore : idem, **et** ne se déconnecte plus (correction d'un défaut : photos affichées après le chargement gardaient un jeton `exbidb:`). Aucun balayage global. |
| 4.4 / P3 Démarrage | 🟡 | Mesuré : 16 tâches longues (max 289 ms, 3,5 s) → 8 (max 130 ms, 1,8 s) sur 800 clients / 400 chantiers / 1 500 écritures. `defer` en masse **non** appliqué (l'audit le déconseille : ordre des scripts). Chargement à la demande des modules secondaires : non fait, risque d'ordre ; à décider après vos mesures. |
| 4.5 / P4 IndexedDB | 🟡 | Lecture par curseur ; compaction seulement après 5 s sans saisie et au repos ; `EXBBIG.perf()` journalise lecture/écriture/compactage (≥ 300 ms → rapport de lenteur). Test stockage : photo 430 Ko compactée, plus de `data:` dans localStorage, restituée à l'écran après rechargement. |
| 4.6 / P5 Métré, FAB, listes | ✅ / 🟡 | Formateurs de nombres réutilisés ; listes limitées à 150 lignes + « Afficher plus » ; recherche client retardée. Métré : 10 lignes saisies → enregistrées → rechargement = valeurs identiques (testé). 100 lignes : ≈ 100 à 150 ms par modification (seuil audit 200 ms). |
| P1 Blocage « source inconnue » 4,8 s | ⏳ | Non reproduit ici. Diagnostic prêt (Ctrl + Alt + T puis Ctrl + Alt + L). |
| Seuil recherche < 300 ms | ✅ | 20 recherches successives : 280–292 ms anti-rebond compris. |
| Seuil tâche > 1 000 ms | ✅ | Aucune pendant le parcours testé. |
| Tests de réception Windows / Android, endurance 60 min, PDF avec photos | ⏳ | À faire chez vous (voir ci-dessous). |

## Après installation — ce qu'il faut m'envoyer
1. **Essai de 10 minutes** : Ctrl + Alt + T, travailler normalement (recherche, fiche client, devis, Métré), puis Ctrl + Alt + L → capture(s) du rapport.
2. **IndexedDB** : F12 → Console → `EXBBIG.perf()` → copier le résultat ; ajouter `EXBBIG.usage()`.
3. **Si un blocage persiste** : onglet Performance (F12), enregistrer pendant le blocage, exporter le profil (.json) ou capture.
4. **Matrice de réception** (cocher OK / KO + remarque) :
   - Recherche : client, projet, devis, apprenant, 20 fois de suite.
   - Fiche client : créer / modifier / annuler / enregistrer, saisie rapide puis lente, changement d'onglet.
   - Chantier : création (une seule), membres, étapes, notifications non bloquantes.
   - Équipement : QR, code manuel, annulation puis validation (caméra libérée).
   - Suppression : annuler (aucun effet), puis confirmer sur une copie.
   - Devis déjà existant (même client + projet) : « Mettre à jour » puis « Nouveau devis ».
   - Réception d'un bon de commande : saisie des quantités par ligne.
   - Métré : 100 lignes, modifier quantités/prix, enregistrer, fermer, rouvrir.
   - Images / plans : importer, attendre la compaction, fermer/rouvrir, **générer un PDF avec photo (fiche client, reçu)**, exporter et restaurer sur une copie.
   - Endurance 60 min, réseau coupé puis rétabli.
5. **Avant déploiement** : sauvegarde complète exportée, version précédente conservée (retour arrière).

## Point d'attention connu (non bloquant)
Les listes en mémoire (`exbClients`, etc.) peuvent contenir un jeton `exbidb:` tant qu'elles n'ont pas été relues ; l'affichage à l'écran est maintenant résolu automatiquement, mais **la génération de PDF/export directement depuis ces listes n'a pas pu être testée ici** : c'est le premier point à vérifier (photo sur fiche/reçu PDF).

## Consommation du forfait internet (signalée après l'audit)
Causes identifiées dans le code :
1. **Synchronisation en ligne (`exb-sync.js`)** : toutes les 60 s, 2 requêtes (licence + liste des clés du compte), en permanence, y compris application en arrière-plan ou rien de modifié. → V144e : aucune requête en arrière-plan ; vérification du serveur au plus toutes les 5 min quand rien n'a changé localement ; envoi dans la minute quand une donnée locale change ; reprise immédiate au retour au premier plan, au retour du réseau et via « Synchroniser ».
2. **Mises à jour de l'application** : chaque nouvelle version change le cache hors-ligne (`sw.js`, 282 fichiers, 13,6 Mo au total) ; le téléchargement dépend des fichiers modifiés (jusqu'à plusieurs Mo par appareil et par version). → Éviter d'installer chaque petite version sur les téléphones sur forfait ; regrouper les mises à jour.
3. **Envoi de données volumineuses** : toute clé modifiée est renvoyée en entier (ex. liste clients avec photos). Les photos lourdes augmentent le volume à chaque modification.
4. Météo de l'accueil : mise en cache, au plus 1 appel par période de rafraîchissement ; faible volume.
À vérifier chez vous : Paramètres Android / Windows → consommation de données par application, avant et après installation, pour confirmer le gain.

## Notification « Hors connexion — le renouvellement de session sera réessayé automatiquement » qui revient chaque minute
Cause : `exb-memoire.js` (alertes sonores des demandes en ligne) interroge la boîte de réception toutes les 60 s ; sans réseau, chaque échec de renouvellement de session créait une nouvelle notification identique (et la cloche se remplissait). Les requêtes de la boîte (4 listes + licence) partaient aussi chaque minute.
Correction V144e :
- aucune interrogation de la boîte de réception quand l'appareil est hors connexion (`exb-memoire.js`) ;
- erreur « hors connexion » de la boîte de réception : affichée dans le panneau seulement, sans notification flottante ;
- tout avertissement identique n'est notifié qu'une fois par 10 min (`say` dans index.html).
La pastille « Hors connexion · Dernière synchronisation » et l'unique notification de changement de réseau restent affichées normalement.
À vérifier chez vous : couper le Wi-Fi 3 minutes puis le rétablir → une seule notification « Hors connexion », puis « Connexion rétablie », sans répétition.
(Remarque : la capture indique « Version : V120 » en bas à gauche — vérifier que la V144e est bien celle qui s'exécute, après rechargement complet Ctrl + Maj + R.)

## Forfait internet — vérification approfondie (V144e v13)
Essai de blocages reçu (10 min) : 0 blocage ≥ 200 ms hors boîtes de dialogue.

Banc d'essai : session connectée simulée (serveur factice), horloge accélérée, requêtes comptées par type.
| | Origine (V120y/v6) | V144e v13 |
|---|---|---|
| Écran visible, 6 min | 146 requêtes (≈ 1 460 / h) | 14 requêtes (≈ 140 / h) |
| Arrière-plan, 6 min | — | 8 requêtes (≈ 80 / h) |

Causes trouvées et corrigées :
1. **`exb-equipe.js`** : « mon_organisation » demandé au serveur **toutes les 4 s, sans fin**, tant que le compte n'est pas administrateur d'entreprise (≈ 900 requêtes / h = la plus grosse consommation). → une vérification, puis 30 min (non-admin) ou 2 min (erreur) ; rien en arrière-plan ni hors connexion.
2. **`exb-sync.js`** : 2 requêtes / min en permanence → 5 min quand rien n'a changé, rien en arrière-plan.
3. **`exb-license.js`** : demande de l'heure du serveur (`auth/v1/health`) chaque minute → au plus toutes les 15 min.
4. **`exb-memoire.js`** : boîte de réception (licence + 4 listes) chaque minute, même hors connexion → rien hors connexion, 3 min en arrière-plan.
5. **Météo d'accueil** : après un échec, nouvel essai chaque minute → 10 min ; rien hors connexion.
6. Rechargements de boîte (écran Inscriptions…, surveillance IA) : plus de requête hors connexion ni en arrière-plan.
Limites : mesure avec serveur factice (taille des réponses estimée) ; la consommation réelle dépend de vos données. Comparer dans Windows : Paramètres › Réseau et Internet › Utilisation des données, par application, avant / après.

## Lot « affiches / modèles de documents » (V156 + V157, archive V120-v17) appliqué sur la V144e
- Seul fichier concerné : `exb-affiches-studio.js` (Studio libre : **235 modèles**, dont 189 nouveaux — 76 en V156 + 113 en V157 : lettres, attestations, documents commerciaux, chantier/technique, RH, fêtes, avis, marketing, 4 nouveaux formats).
- Fusion : fichier v17 repris en entier ; les 3 boîtes de dialogue natives (supprimer une affiche, remplacer par un modèle, nouvelle affiche) y ont été remplacées par `await exbConfirm` comme dans le reste de la V144e. Aucune ligne de la version précédente n'a été retirée.
- Cache hors-ligne (`sw.js`) : nom de version changé pour que les appareils récupèrent le nouveau fichier.
- Ajoutés : `README-V156-…`, `README-V157-…`, `tools/e2e-affiches-modeles.py`.
- Vérifié (Chromium) : les 235 modèles s'appliquent sans erreur JavaScript, aucun élément hors cadre ; démarrage et tests de la V144e inchangés.
- Non repris volontairement : `exb-recu-client.js` (reçu client V142c de l'archive v17) — la V144e contient déjà la suite V142c-V142e (`exb-v142c-recu-client.js`). Les autres fichiers de l'archive v17 sont des versions antérieures aux corrections d'audit et n'ont pas été importés.
- Non testé : impression réelle, téléphone ; contrats / mises en demeure = trames générales à faire valider par un juriste.

## Affiches : QR code vers le site vitrine
- Bouton « ＋ QR site » (Studio libre) : ajoute en bas de l'affiche, au-dessus du bandeau de contact, un vrai QR code qui ouvre le site vitrine (adresse réglée dans 🌐 Site vitrine › Adresses ; à défaut l'adresse par défaut du site).
- Le modèle « Scannez le QR code (A4) » reçoit automatiquement ce QR (plus de cadre vide).
- Ce QR n'a aucun lien avec la vérification des documents (reçus, certificats, devis) : celle-ci est inchangée.
- Studio : 16 nouveaux formats (A6, DL, A3 paysage, A2, A1, A0, Instagram 4:5, Pinterest 2:3, couvertures X/Facebook, statut WhatsApp, carré 20 cm, badge, bâches 3×1 m et 2×1 m, kakemono 100×200) + bouton « 📐 Format libre » (largeur × hauteur en cm).
- Studio : « 🔳 Affiche QR seul » (QR géant + SCANNEZ-MOI, adresse modifiable), « ⬇ QR seul (PNG) », et 14 modèles « QR seul » (7 formats × fond bleu/blanc).
- Filigrane : (1) Studio › Fond : case « Filigrane : mon logo en transparence derrière l'affiche » (visibilité et taille réglables), incluse dans les exports PNG/PDF ; (2) le filigrane d'écran de l'application utilise maintenant le logo de l'entreprise (identité) au lieu de celui d'Excellencia Building.
- Lot affiches v18 (338 modèles, README-V158) importé ; mes ajouts (QR site, formats, QR seul, filigrane) conservés : 352 modèles au total, aucun débordement ni erreur JS.

## Noyau CORE (V143b) branché
- Ajouts : exb-core.js, exb-core-adapters.js (balises dans index.html avant exb-keyguard.js, fichiers au précache du service worker), version unique EXB_BUILD = « V144e-CORE » (pied de page, diagnostic), identité entreprise.json « Excellencia Building ».
- Ajout V142g (présent dans l'archive CORE seulement) : suppression des documents envoyés à l'espace client + nettoyage des anciennes versions (exb-v99zy-portails.js).
- Les corrections de l'audit (dialogues, performances, consommation de données) n'ont PAS été remplacées par les fichiers plus anciens de l'archive CORE.
- Vérifié : EXBCore chargé, registre de 67 modules, journal d'audit chaîné valide (4 entrées de test), 352 modèles d'affiches OK, aucune erreur JS.
- Non vérifié : écran de suppression des documents client (nécessite Supabase), synchronisation réelle.

## BI Direction v1 (cahier des charges ERP, module 01)
Voir src/site/README-V145-BI-DIRECTION-V1.md. Menu « 📈 BI Direction » ; lecture seule ; 6 indicateurs par devise, détail des opérations sources, export CSV, journal d'audit.

## BI Direction v2 (cahier des charges ERP, module 01 — suite)
Voir site/README-V146-BI-DIRECTION-V2.md. Ajouts : alertes de direction (finance + projets), tableau « Projets : budget, avancement et écarts » (moteur exb-evm.js réutilisé, USD, à ce jour), détail par projet, export CSV étendu, dictionnaire étendu. 35 contrôles (tools/test-bi.js), 0 erreur JS en Chromium. Restent ouverts : indicateurs par département (champ inexistant), rapports planifiés, alertes poussées. Deux échecs préexistants corrigés : cache du registre financier non invalidé à la fusion de clients (exb-liaison.js) et test budgetfin non asynchrone. tools/check.js : 561/561.

## Workflow v1 (cahier des charges ERP, module 07)
Voir site/README-V147-WORKFLOW-V1.md. Nouveau fichier exb-workflow.js (balise dans index.html, précache sw.js). Circuits par type, étapes séquentielles/parallèles, seuils, refus/correction motivés, délégations, échéances, historique + journal CORE. 69 contrôles (tools/test-workflow.js), parcours Chromium complet, check.js 562/562. Non branché aux autres modules ; synchronisation « dernière écriture gagne » (limite documentée).

## Workflow — liens avec les modules (V148)
Voir site/README-V148-WORKFLOW-LIENS.md. Nouveau fichier exb-workflow-liens.js (balise index.html, précache sw.js). Devis (export/impression PDF), Certificats (export PDF), Congés (demande → circuit → décision appliquée), Achats (commande → dossier → approved/rejected, réception bloquée si non validé). Désactivé par défaut ; réglages dans Workflow › Liens avec les modules ; empreinte du document (modification après validation → nouvelle validation). 74 contrôles (tools/test-workflow-liens.js), Chromium sans erreur JS, check.js 563/563. À confirmer : statuts de commande approved/rejected, essai sur téléphone et comptes réels.

## Scanner intégré à l'ERP (cahier des charges ERP, module 13) — V151
Voir site/README-V151-SCANNER-ERP.md. Nouveau fichier exb-scanner.js (balise index.html après exb-archives.js, précache sw.js). Photo/import, cadre automatique, rotation, filtres, PDF multipages avec métadonnées, fiche de vérification, dépôt direct dans Archives (EXBAR.add), recherche par numéro/QR selon les droits. 20 contrôles (tools/test-scanner.js), Archives 71, check.js 565/565, Chromium sans erreur JS. Application Android « Scanner » mise à jour en V2 (scanner-apk/LISEZ-MOI-SCANNER-V2.md). Reste : OCR, rattachement Project Manager / CRM / TFL, essai sur téléphone et dans l'application complète (écran de connexion).

## BI Direction v3 (renforcement module 01) — V160
Voir site/README-V160-BI-V3-DETTES.md. Dettes fournisseurs + engagements (bons de commande), alerte, export, dictionnaire. tools/test-bi-dettes.js : 10 contrôles. Reste : département, tableau configurable, lecture RH/Stock/CRM/Workflow ; Project Manager (jalons, engagements, clôture) à traiter ensuite.

## V161 — Département (BI) + Jalons (Project Manager)
Voir site/README-V161-PM-JALONS-DEPARTEMENT.md. Champ département sur les projets et filtre BI ; jalons dans le planning (moteur CPM, écran, alertes BI, CSV) ; correctif : la fiche projet ne perd plus les champs absents du formulaire. tools/test-jalons.js (18) et tools/test-bi-dettes.js (24) ; essai Chromium sans erreur JS. Reste : engagements par projet, report pointage/matériel, dossier de clôture.

## V162 — Engagements budgétaires par projet
Voir site/README-V162-PM-ENGAGEMENTS.md. Engagé / taux / disponible par projet (BI : colonne, détail, CSV, alertes ; planning : onglet Budget). Non ajouté au coût réel. tools/test-bi-dettes.js : 41 contrôles ; essai Chromium sans erreur JS. Reste : report pointage/matériel, dossier de clôture.

Voir site/README-V163-PM-CLOTURE.md. Onglet « 🏁 Clôture » (Planning & budget) : contrôles bloquants/alertes, bilan, clôture (motif si forcée), réouverture, PDF. tools/test-cloture.js : 52 contrôles ; essai Chromium sans erreur JS. Reste : report pointage/matériel (RH, Stock), blocage Workflow d'un achat hors budget.

Voir site/README-V164-PM-REPORT-RH-STOCK.md. Onglet « 🔁 Report RH / Stock » : pointages → présences RH (aperçu, clé unique, annulation), sorties de matériel → Stock (contrôle de quantité, contre-mouvement), alerte de clôture. tools/test-report-ops.js : 55 contrôles (dont report automatique des nouveaux pointages) ; essai Chromium sans erreur JS. Reste : blocage/validation Workflow d'un achat hors budget.


## V152 + V153 appliqués sur la v32 (administration avancée, rattachement Scanner, OCR)
- Ajoutés : `exb-admin.js`, `exb-ocr.js` ; modifiés : `exb-scanner.js`, `index.html` (2 balises), `sw.js` (version + précache). Ces fichiers ne différaient de la v32 que par ces lignes : aucune correction d'audit n'a été touchée.
- Moteur Tesseract.js non fourni : voir `README-V153-OCR.md`. `exb-admin.js` et `exb-ocr.js` posent chacun un `setInterval` léger (3 s / 1,5 s, page visible seulement).
- Écart avec le cahier des charges : `ECART-CAHIER-DES-CHARGES-ERP-v1.1.md`.

## V165 — Finances & comptabilité (module 15)
`exb-compta.js` : avoirs, échéanciers, journal/balance/grand livre calculés, clôture mensuelle. Détail et limites : `README-V165-COMPTA.md`. `exb-admin.js` : 2 `alert()` natifs remplacés par `exbAlert`.

## V166 — Comptabilité : TVA récupérable, états, verrou (module 15)
`exb-compta-etats.js` (+ points d'extension dans `exb-compta.js`). Détail et limites : `README-V166-COMPTA-ETATS.md`. 57 contrôles (`tools/test-compta-etats.js`), Chromium 0 erreur, `check.js` 571/571. Reste : écritures de paie ; verrou à essayer sur les écrans réels de saisie. Écart mis à jour : `ECART-CAHIER-DES-CHARGES-ERP-v1.1.md`.

## Fusion sur V166c (v36 FINANCES)
Vérification fichier par fichier : tout le travail précédent (dialogues, performances, consommation internet, affiches/QR/formats/filigrane, noyau CORE) était déjà présent et identique. Seule la BI v5 a été ajoutée (voir README-V146).

## V166e — Interconnexion des modules (audit)
- Recherche globale : +17 collections (avoirs, factures fournisseurs, échéanciers, caisse, clôtures, workflow, pointages, paie, sous-traitants, projets/tâches/sous-traitance/HSE/matériel BTP, RFI, risques, QHSE).
- Journal CORE : +7 domaines (factures, bons de commande, avoirs, clôtures, workflow, paie, paiements apprenants).
- Impression HTML (EXBPrint.build) : nom/contacts configurés appliqués à tous les documents (exbRebrand) ; rapport BI avec en-tête (logo, adresse, tél., e-mail) et pied (mentions légales) tirés d'Identité.
- BI « Encaissé » : inclut les paiements des apprenants (sans doublon).
- Test : tools/ictest.py (identité personnalisée → recherche, CORE, rapport, encaissé = 300).

## V167 — liens Workflow appliqués sur V166e + vérification du cahier unifié
Voir VERIFICATION-CAHIER-UNIFIE-V1.0-V167.md. 21 suites node réussies ; e2e : 18/30 réussis, 12 en échec identiques sur la V166e d'origine (non causés par V167).

## V170 — BI Direction v6 (module 01)
Voir site/README-V170-BI-V6-MODULES-CONFIG.md. Vérification V169 : dettes, engagements, département, jalons, clôture, report RH/Stock déjà présents. Ajout : activité des modules (RH, Stock, CRM, Workflow), alertes associées, tableau de bord personnalisable. tools/test-bi-dettes.js 64 ; site/tools/e2e-bi-modules.py 16 ; check.js 574. Reste : section dans le PDF de direction, historique des soldes, taux de conversion devis.

## V171 — BI Direction v7 (module 01)
Voir site/README-V171-BI-V7-HISTORIQUE-PDF.md. Historique mensuel des soldes (commence à la première ouverture, rien de reconstitué) + activité des modules et historique dans le PDF de direction. tools/test-bi-dettes.js 80 ; site/tools/e2e-bi-modules.py 29 ; check.js 574. Reste : taux de conversion devis ; règle Workflow achat > budget projet.


## V172 — Stock + CRM (cahier des charges, modules 06 et 04)
Ajout de `exb-stock-plus.js` et `exb-crm-plus.js` (voir README-V172-STOCK-CRM.md). Vérification de la v43/V171 : correctifs d'audit (dialogues, observateurs, refresh_token, brouillon Métré, compactage) tous présents.


## V173 — Paie, bilan complet, BI adaptatif
Voir README-V173-PAIE-BILAN-BI.md.

## V176 — CRM : alertes/import/export ; paie : pont V81 → compta (un salaire, une source)
Voir README-V176-CRM-ALERTES-PONT-PAIE.md. check.js 581/581.

## V177 — export PDF de marque + QR (CRM alertes, état de paie V81)
Voir README-V177-PDF-MARQUE-QR.md. check.js 582/582.
