# V178 — en-tête société + QR de vérification sur tous les documents imprimés

Nouveau dans `site/exb-rapport-marque.js` : `EXBRapport.stamp / printDoc / screen / qr / qrData`.
Chaque QR est inscrit au registre public (même page `verification.html` que les autres documents). Sans doublon (`data-exb-qr`).

| # | Écran | Correction |
|---|-------|-----------|
| 1 | Paie V81 (bulletin, cotisations, contrat) | QR en pied, via `C.printDoc` (exb-v81-core.js) |
| 2 | Rapport de pilotage V81 | QR en pied |
| 3 | Suivi des paiements des apprenants | QR en pied |
| 4 | Plans à cartouche (V80) | case QR dans le cartouche de chaque feuille |
| 5 | Éditeur type Word | PDF officiel : le QR sort toujours ; si le vérificateur ou le canvas échoue, repli sur le QR du module commun (exb-v81-pieces.js) |
| 6 | 18 modèles du centre documentaire | QR via `core.js` (options `qr_img`/`qr_ref`, filtrées aussi côté serveur) ; scripts ajoutés à `centre-documentaire.html` |
| 7 | Gantt | en-tête + QR |
| 8 | Résultat QCM | en-tête + QR |
| 9 | Feuilles de plans en lot (V72) | case QR dans le cartouche |
| 10 | Export PNG d'un plan V81 | en-tête + QR sous le plan |
| 11 | Impression d'écran (BI) | `EXBRapport.screen` : en-tête + QR ajoutés pendant l'impression |
| 12 | Compta : journal+balance, états, bilan | boutons « 🖨 PDF » |
| 13 | Paie V173 : état de paie, bilan | boutons « 🖨 PDF » |
| 14 | Journal d'audit, métrés IFC | boutons « 🖨 PDF » |

Test : `node site/tools/test-qr-partout-v178.js` (23 contrôles). `node site/tools/check.js` : 582/582.
