/* V123 — « Station d'analyse » du module Bâtiment : espace de travail en panneaux inspiré de Robot Structural Analysis.
   Arbre d'objets (gauche) · vue plan / portique (centre) · propriétés (droite) · tableaux de résultats (bas) · barre d'état ;
   disposition par métier : Géométrie · Charges · Analyse · Résultats · Dimensionnement.
   S'appuie sur le modèle du bâtiment de index.html (b.xs, b.ys, b.niv, b.res) et sur le moteur EXBR (exb-robot-analyse.js).
   Ouverture : EXBS.open(b). */
(function (root) {
  "use strict";
  const hist = { u: [], r: [] };
  const st = { cam: { yaw: -.6, pit: .55, zoom: 1, px: 0, py: 0 }, iso: false, tool: "sel", psel: null, ms: [], multi: false, zoom: 1, msg: "", dlg: false, pg: null, b: null, dir: "X", line: 0, layout: "geo", view: "plan", tab: "eff", diag: "M", sel: null, lv: 0, a: null, err: null, all: null, pane: "view", dsg: null };
  const f2 = (x, d = 2) => (Number.isFinite(x) ? x.toFixed(d) : "—"), esc = t => String(t == null ? "" : t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const q = (s, r) => (r || document).querySelector(s), qa = (s, r) => [...(r || document).querySelectorAll(s)];
  const LAYOUTS = [["geo", "Géométrie"], ["chg", "Charges"], ["ana", "Analyse"], ["res", "Résultats"], ["dim", "Dimensionnement"]];
  const G = n => root[n] !== undefined ? root[n] : (0, eval)(n);   /* accès aux liaisons globales de la page principale */

  /* ------------------------------------------------------------------ modèle : bâtiment → portique d'un axe */
  function lines(b) {
    const nx = b.xs.length, ny = b.ys.length, L = [];
    for (let j = 0; j <= ny; j++) L.push({ dir: "X", line: j, nom: "Axe " + (j + 1) + " (sens X)" });
    for (let i = 0; i <= nx; i++) L.push({ dir: "Y", line: i, nom: "Axe " + String.fromCharCode(65 + i % 26) + " (sens Y)" });
    return L;
  }
  function modele(b, dir, line) {
    const r = b.res, ax = dir === "X" ? b.xs : b.ys, xs = [0]; ax.forEach(l => xs.push(xs[xs.length - 1] + l));
    const z = [0]; b.niv.forEach(v => z.push(z[z.length - 1] + v.h));
    const col = b.niv.map((v, k) => xs.map((_, t) => { const i = dir === "X" ? t : line, j = dir === "X" ? line : t; if (!(v.cols[i] && v.cols[i][j])) return null;
      const a = G("batColA")(r, k, i, j); return a ? { b: a / 100, h: a / 100, nom: G("nname")(i, j) } : null; }));
    const beams = (r.beams || []).filter(x => x.dir === dir && x.line === line).map(x => ({ k: x.k, t0: x.t0, t1: x.t1, b: x.bs ? x.bs[0] : b.bm, h: x.bs ? x.bs[1] : b.bh, Gs: x.Gs.map((g, n) => g + ((((b.rb || {}).cl || {})[`${x.k}:${dir}:${line}:${x.t0 + n}`] || {}).G || 0)), Qs: x.Qs.map((g, n) => g + ((((b.rb || {}).cl || {})[`${x.k}:${dir}:${line}:${x.t0 + n}`] || {}).Q || 0)), nom: x.name }));
    const rb = b.rb;
    return { xs, z, col, beams, fc: b.fc, base: "enc", pp: 1, cat: rb.cat, Wx: rb.Wx, seis: rb.seis, norme: G("nrm")().ec ? "EC" : "BAEL" };
  }
  function analyser(dir, line) {
    const b = st.b; try { const a = root.EXBR.analyseModele(modele(b, dir, line)); a.dir = dir; a.line = line; return { a }; } catch (e) { return { err: e.message || "Analyse impossible" }; }
  }
  function run() { const r = analyser(st.dir, st.line); st.a = r.a || null; st.err = r.err || null; st.dsg = null; st.sel = null; }

  /* ------------------------------------------------------------------ dimensionnement des armatures d'un résultat */
  function dimensionner(a, b) {
    const calc = G("calcul"), pcalc = G("poteauCalc"), bars = G("poteauBars"), ac = G("AC"), N0 = G("nrm")(), enr = 4, out = [];
    a.elements.forEach(e => {
      if (e.type === "p") {
        const base = { b: e.b * 100, h: e.h * 100, enr, enrobageComprime: enr, fc: b.fc, fe: b.fe, fis: 0, G: 0, Q: 0, tee: null };
        let bt, ba; try { bt = calc({ ...base, Mu: e.Mt, Mser: e.MsT, Vu: e.V, L: e.len, rm: 1 }); ba = calc({ ...base, Mu: e.Ma, Mser: e.MsA, Vu: e.V, L: 0 }); } catch (x) { return; }
        const lit = c => (c && c.asRet ? `${f2(c.asRet)} cm² → ${c.T ? c.T.n + " HA" + c.T.phi : "2 lits"}` : "insuffisant");
        const ko = [bt, ba].some(c => !c || !c.asRet || (c.D && c.D.some(d => d.g === "erreur")));
        out.push({ id: e.id, nom: e.nom, typ: "Poutre", sec: `${f2(e.b * 100, 0)}×${f2(e.h * 100, 0)}`, sol: `Mu ${f2(e.Mt, 1)} / ${f2(e.Ma, 1)} kN.m · Vu ${f2(e.V, 0)} kN`, arm: `Travée ${lit(bt)} · appui ${lit(ba)}${bt && bt.phiT ? " · cadres φ" + bt.phiT + "/" + bt.st : ""}`, ok: !ko, msgs: [bt, ba].flatMap(c => (c && c.D ? c.D.filter(d => d.g === "erreur" || d.g === "alerte").map(d => d.m) : [])) });
      } else {
        let pc; try { pc = pcalc({ sec: "r", b: e.b, h: e.h, H: 3, k: .7, pp: 0, enr, fc: b.fc, fe: b.fe, L: [{ t: "G", N: e.N / N0.gG, Mx: e.M / N0.gG, My: 0 }] }); } catch (x) { return; }
        let txt, ok = true; const msgs = [];
        if (pc.as) { txt = `${f2(pc.as)} cm² → ${pc.T ? pc.T.n + " HA" + (pc.T.p || pc.T.phi) : "à revoir"}${pc.pt ? " · cadres φ" + pc.pt + "/" + pc.st : ""}`; ok = !pc.D.some(d => d.g === "erreur"); pc.D.filter(d => d.g === "erreur" || d.g === "alerte").forEach(d => msgs.push(d.m)); }
        else { const nm = root.EXBR.colonneNM({ b: e.b, h: e.h, enr: enr / 100, fc: b.fc, fe: b.fe, acc: N0.acc, gb: N0.gb, gs: N0.gs, N: e.N, M: e.M, l0: 3 });
          if (nm.ok) { let T = null; try { T = bars(nm.As, false, ac().pp || 0); } catch (x) { } txt = `${f2(nm.As)} cm² → ${T ? T.n + " HA" + T.p : "à revoir"} (N–M)`; if (nm.lam > 25) msgs.push("λ > 25 : second ordre à vérifier."); } else { txt = "section insuffisante"; ok = false; msgs.push(nm.err); } }
        out.push({ id: e.id, nom: e.nom, typ: "Poteau", sec: `${f2(e.b * 100, 0)}×${f2(e.h * 100, 0)}`, sol: `Nu ${f2(e.N, 0)} kN · M ${f2(e.M, 1)} kN.m`, arm: txt, ok, msgs });
      }
    });
    return out;
  }

  /* ------------------------------------------------------------------ rendu */
  const CSS = `#exbs{position:fixed;inset:0;z-index:2147483000;background:#e9edf3;display:flex;flex-direction:column;font-size:13px;color:#14284b}
#exbs *{box-sizing:border-box}#exbs button{font:inherit;cursor:pointer}
#exbs .tt{display:flex;align-items:center;gap:10px;background:#14284b;color:#fff;padding:6px 10px}#exbs .tt b{flex:1;font-size:.95rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#exbs .tt button{background:#e8590c;border:0;color:#fff;border-radius:6px;padding:5px 12px}
#exbs .rb{display:flex;background:#fff;border-bottom:1px solid #d5dae1;overflow-x:auto}#exbs .rb button{border:0;border-bottom:3px solid transparent;background:none;padding:9px 14px;white-space:nowrap;color:#5b6779}#exbs .rb button.on{color:#14284b;font-weight:700;border-bottom-color:#e8590c}
#exbs .tb{display:flex;gap:6px;flex-wrap:wrap;align-items:center;background:#f6f8fb;border-bottom:1px solid #d5dae1;padding:5px 8px}#exbs .tb button{border:1px solid #b8c2d3;background:#fff;border-radius:6px;padding:4px 10px}#exbs .tb button.on{background:#14284b;color:#fff;border-color:#14284b}#exbs .tb .sp{flex:1}
#exbs .ws{flex:1;min-height:0;display:grid;grid-template-columns:230px 1fr 290px;grid-template-rows:1fr 200px;grid-template-areas:"tree view prop" "tree tab prop"}
#exbs .pn{background:#fff;border:1px solid #d5dae1;overflow:auto;min-width:0;min-height:0}#exbs .pn>h3{margin:0;position:sticky;top:0;background:#eef2f8;font-size:.78rem;text-transform:uppercase;letter-spacing:.04em;padding:6px 10px;border-bottom:1px solid #d5dae1;z-index:1}
#exbs .tree{grid-area:tree}#exbs .vw{grid-area:view}#exbs .pr{grid-area:prop}#exbs .tab{grid-area:tab}
#exbs .tr div{padding:4px 10px;cursor:pointer;border-bottom:1px solid #f0f2f6}#exbs .tr div:hover{background:#eef4ff}#exbs .tr div.on{background:#dbe8ff;font-weight:600}#exbs .tr .g{background:#f6f8fb;font-weight:700;cursor:default;color:#5b6779;font-size:.74rem;text-transform:uppercase}#exbs .tr .i2{padding-left:22px}
#exbs table{border-collapse:collapse;width:100%}#exbs th,#exbs td{border-bottom:1px solid #e5e9f0;padding:4px 8px;text-align:left;white-space:nowrap}#exbs th{background:#f6f8fb;position:sticky;top:0}#exbs tr.on td{background:#fff3dc}#exbs tr[data-r]{cursor:pointer}#exbs .ok{color:#1b7a43;font-weight:700}#exbs .ko{color:#b3261e;font-weight:700}
#exbs .vb{padding:6px}#exbs .vb svg{max-height:46vh}#exbs .pb{padding:8px 10px}#exbs .pb label{display:block;margin:6px 0 2px;color:#5b6779;font-size:.78rem}#exbs .pb input,#exbs .pb select{width:100%;padding:5px;border:1px solid #b8c2d3;border-radius:5px;font:inherit}
#exbs .row2{display:flex;justify-content:space-between;gap:8px;border-bottom:1px dotted #d5dae1;padding:3px 0}#exbs .msg{margin:6px 0;padding:6px 8px;border-radius:6px;background:#fff3dc;color:#7a4b00}#exbs .msg.e{background:#fbe9e7;color:#b3261e}#exbs .msg.o{background:#e5f4ea;color:#1b7a43}
#exbs .sb{background:#14284b;color:#cfd8e6;padding:3px 10px;font-size:.74rem;display:flex;gap:14px;flex-wrap:wrap}
#exbs .mnav{display:none}
@media(max-width:900px){#exbs .ws{grid-template-columns:1fr;grid-template-rows:1fr;grid-template-areas:"x"}#exbs .pn{grid-area:x;display:none}#exbs[data-pane=tree] .tree,#exbs[data-pane=view] .vw,#exbs[data-pane=prop] .pr,#exbs[data-pane=tab] .tab{display:block}#exbs .mnav{display:flex;background:#fff;border-top:1px solid #d5dae1}#exbs .mnav button{flex:1;border:0;background:none;padding:9px 2px;color:#5b6779}#exbs .mnav button.on{color:#e8590c;font-weight:700}}
#exbs .vwr{display:flex;gap:6px;align-items:flex-start}#exbs .vwr .vb{flex:1;min-width:0;overflow:auto}
#exbs .pal{max-height:calc(100vh - 380px);min-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:3px;width:62px;flex:none;background:#f6f8fb;border:1px solid #d5dae1;border-radius:6px;padding:4px;position:sticky;top:0}
#exbs .pal button{display:flex;flex-direction:column;align-items:center;gap:0;border:1px solid transparent;background:#fff;border-radius:5px;padding:3px 1px;color:#14284b;line-height:1.1}#exbs .pal button i{font-style:normal;font-size:1.05rem;font-weight:700}#exbs .pal button span{font-size:.58rem;color:#5b6779;text-align:center}
#exbs .pal button:hover{border-color:#8fa6cf}#exbs .pal button.on{background:#14284b;color:#fff}#exbs .pal button.on span{color:#cfd8e6}#exbs .pal hr{width:100%;margin:2px 0;border:0;border-top:1px solid #d5dae1}
#exbs .cmdl{padding:5px 10px;background:#fffbea;border-bottom:1px solid #ecdca0;color:#6b5600;font-size:.8rem}
#exbs .btnx{margin-top:10px;width:100%;border:1px solid #b8c2d3;background:#fff;border-radius:6px;padding:6px}
#exbs-cm{position:fixed;z-index:9;background:#fff;border:1px solid #9aa6bb;border-radius:6px;box-shadow:0 6px 20px rgba(0,0,0,.25);min-width:230px;padding:4px 0;font-size:13px;color:#14284b}#exbs-cm div{padding:5px 14px;display:flex;gap:18px;cursor:pointer;justify-content:space-between}#exbs-cm div:hover{background:#dbe8ff}#exbs-cm div.off{color:#9aa6bb;pointer-events:none}#exbs-cm hr{margin:3px 0;border:0;border-top:1px solid #e1e6ee}#exbs-cm small{color:#6b778c}#exbs .dlg button.cap{background:#fff3cf;border-color:#e8590c}#exbs .dlg td button[data-kb]{min-width:130px}#exbs .dlg{position:absolute;inset:0;background:rgba(20,40,75,.45);display:flex;align-items:center;justify-content:center;z-index:5;padding:10px}#exbs .dlg>div{background:#fff;border-radius:8px;max-width:760px;width:100%;max-height:92%;overflow:auto;padding:12px 14px}
#exbs .dlg h4{margin:10px 0 4px}#exbs .dlg input{width:84px;padding:3px 5px;border:1px solid #b8c2d3;border-radius:4px;font:inherit}#exbs .dlg td button{border:1px solid #b8c2d3;background:#fff;border-radius:4px;padding:2px 7px;margin-right:3px}
#exbs .dlg .hd{display:flex;align-items:center;gap:8px}#exbs .dlg .hd b{flex:1;font-size:1rem}
@media(max-width:900px){#exbs .pal{width:48px}#exbs .pal button span{display:none}}`;

  function tree() {
    const b = st.b, nx = b.xs.length, ny = b.ys.length, r = b.res, L = lines(b), o = [];
    o.push(`<div class="g">Bâtiment</div><div class="i2">${esc(b.nom)}</div><div class="g">Niveaux (${b.niv.length})</div>`);
    for (let k = b.niv.length - 1; k >= 0; k--) { const v = b.niv[k]; o.push(`<div class="i2${st.lv === k ? " on" : ""}" data-lv="${k}">${esc(v.nom)} · h ${f2(v.h)} m</div>`); }
    o.push(`<div class="g">Portiques (${L.length})</div>`);
    L.forEach(l => o.push(`<div class="i2${st.dir === l.dir && st.line === l.line ? " on" : ""}" data-ln="${l.dir}:${l.line}">${esc(l.nom)}</div>`));
    o.push(`<div class="g">Cas de charges</div><div class="i2">G — permanentes</div><div class="i2">Q — exploitation</div>${b.rb.Wx > 0 ? '<div class="i2">W — vent (±X)</div>' : ""}${b.rb.seis.on ? '<div class="i2">E — séisme (spectre)</div>' : ""}`);
    o.push(`<div class="g">Combinaisons</div><div class="i2">${st.a ? st.a.elu.length + " ELU · " + st.a.els.length + " ELS" : "lancer l'analyse"}</div>`);
    return o.join("");
  }

  const DIAGS = [["M", "Σ", "Moments"], ["V", "↕", "Tranchants"], ["N", "↔", "Normaux"], ["def", "∿", "Flèches"]];
  const PAL = {
    geo: [["sel", "⬉", "Sélection"], ["!multi", "⬚", "Multi"], ["!selall", "▣", "Tout sél."], ["!copy", "⎘", "Copier"], ["!paste", "📋", "Coller"], ["!keys", "⌨", "Raccourcis"], ["col", "▮", "Poteau"], ["beam", "━", "Poutre"], ["slab", "▦", "Dalle"], "-", ["axX+", "⊕X", "Axe X"], ["axY+", "⊕Y", "Axe Y"], ["axX-", "⊖X", "Suppr. X"], ["axY-", "⊖Y", "Suppr. Y"], ["!axes", "⊞", "Axes…"], "-", ["!dup", "⎘", "Copier niv."], ["!lv+", "＋N", "Niveau"], ["!lv-", "－N", "Niveau"]],
    chg: [["sel", "⬉", "Sélection"], ["!multi", "⬚", "Multi"], ["cl", "⇩", "Charge lin."], ["clx", "⌫", "Effacer"]],
    ana: [["sel", "⬉", "Sélection"], "-", ["!run", "▶", "Analyser"], ["!all", "▶▶", "Tous"]],
    res: [["sel", "⬉", "Sélection"], "-", ...DIAGS.map(d => ["~" + d[0], d[1], d[2]])],
    dim: [["sel", "⬉", "Sélection"], "-", ...DIAGS.map(d => ["~" + d[0], d[1], d[2]]), "-", ["!run", "↻", "Recalculer"]]
  };
  const HINT = {
    sel: "Sélection : cliquez un poteau, une poutre, une dalle, une cote ou un axe. Clic droit : menu (copier, coller, supprimer, propriétés…). Maj+clic ou bouton Multi : sélection multiple. Raccourcis configurables (menu clic droit → Raccourcis clavier).", col: "Poteau : cliquez un nœud de la trame pour créer ou supprimer un poteau (cocher « tous niveaux » pour tout l'immeuble).",
    beam: "Poutre : cliquez un tronçon entre deux poteaux pour le retirer ou le rétablir.", slab: "Dalle : cliquez une case de la trame pour créer ou retirer la dalle.",
    "axX+": "Axe X : cliquez dans une travée pour y insérer un axe à l'endroit cliqué.", "axY+": "Axe Y : cliquez dans une travée pour y insérer un axe à l'endroit cliqué.",
    "axX-": "Suppression d'axe X : cliquez près de l'axe à supprimer (les deux travées fusionnent).", "axY-": "Suppression d'axe Y : cliquez près de l'axe à supprimer (les deux travées fusionnent).",
    cl: "Charge linéaire : cliquez une poutre pour lui ajouter une charge G / Q (propriétés à droite).", clx: "Effacer : cliquez une poutre pour supprimer sa charge ajoutée."
  };
  function planSvg() {
    const b = st.b, r = b.res, nx = b.xs.length, ny = b.ys.length, px = [0], py = [0]; b.xs.forEach(l => px.push(px[px.length - 1] + l)); b.ys.forEach(l => py.push(py[py.length - 1] + l));
    const W = px[nx], H = py[ny], s = Math.min(640 / W, 400 / H), x0 = 58, y0 = 54, VW = x0 + W * s + 30, VH = y0 + H * s + 34, X = i => x0 + px[i] * s, Y = j => y0 + py[j] * s, v = b.niv[st.lv], o = [], ps = st.psel, bOn = G("bOn");
    st.pg = { x0, y0, s, px, py };
    const isS = (t, a, c) => (ps && ps.t === t && ps.a === a && ps.c === c) || (st.ms.length > 0 && st.ms.includes(t + ":" + a + ":" + c));
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) o.push(`<rect data-sp="${i}:${j}" x="${X(i)}" y="${Y(j)}" width="${b.xs[i] * s}" height="${b.ys[j] * s}" fill="${v.sl[i][j] ? "#dbe8ff" : "#fff"}" stroke="${isS("slab", i, j) ? "#ff9800" : "#e1e6ee"}" stroke-width="${isS("slab", i, j) ? 3 : 1}" ${v.sl[i][j] ? "" : 'stroke-dasharray="3 3"'}/>`);
    /* V139 : charges de chaque dalle (disposition Charges : toutes ; sinon : seulement celles qui diffèrent du niveau) */
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { if (!v.sl[i][j]) continue; const ov = G("slOv")(v, i, j); if (!ov && st.layout !== "chg") continue;
      o.push(`<text x="${X(i) + b.xs[i] * s / 2}" y="${Y(j) + b.ys[j] * s / 2 + 4}" text-anchor="middle" font-size="10" fill="${ov ? "#b3261e" : "#5b6779"}" font-weight="${ov ? 700 : 400}" pointer-events="none">G ${f2(G("slG")(v, i, j), 1)} · Q ${f2(G("slQ")(v, i, j), 1)}${ov ? " *" : ""}</text>`); }
    const cl = (b.rb.cl || {}), hl = (d, ln) => st.dir === d && st.line === ln;
    const seg = (d, i, j) => { const i2 = d === "X" ? i + 1 : i, j2 = d === "Y" ? j + 1 : j; if (!(v.cols[i][j] && v.cols[i2][j2])) return; const on = bOn(v, d, i, j), sel = isS("beam", d + i, j), line = d === "X" ? j : i, k = `${st.lv}:${d}:${line}:${d === "X" ? i : j}`, x1 = X(i), y1 = Y(j), x2 = X(i2), y2 = Y(j2);
      o.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${sel ? "#ff9800" : hl(d, line) && on ? "#e8590c" : on ? "#5b8bd0" : "#b8c2d3"}" stroke-width="${sel ? 7 : hl(d, line) && on ? 6 : 4}" ${on ? "" : 'stroke-dasharray="6 5"'}/><line data-bs="${d}:${i}:${j}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="transparent" stroke-width="18" style="cursor:pointer"/>`);
      if (cl[k] && on) o.push(`<text x="${(x1 + x2) / 2}" y="${(y1 + y2) / 2 - 7}" text-anchor="middle" font-size="10" fill="#b3261e" font-weight="700">+${f2(cl[k].G || 0, 1)}G +${f2(cl[k].Q || 0, 1)}Q</text>`); };
    for (let j = 0; j <= ny; j++) for (let i = 0; i < nx; i++) seg("X", i, j);
    for (let i = 0; i <= nx; i++) for (let j = 0; j < ny; j++) seg("Y", i, j);
    for (let i = 0; i <= nx; i++) for (let j = 0; j <= ny; j++) { const on = v.cols[i][j], sel = isS("col", i, j);
      if (on) { const a = (G("batColA")(r, st.lv, i, j) || 30) / 100 * s * 1.4 + 8; o.push(`<rect data-nd="${i}:${j}" x="${X(i) - a / 2}" y="${Y(j) - a / 2}" width="${a}" height="${a}" fill="#7d8597" stroke="${sel ? "#ff9800" : "#14284b"}" stroke-width="${sel ? 4 : 1.5}" style="cursor:pointer"/>`); }
      else o.push(`<circle data-nd="${i}:${j}" cx="${X(i)}" cy="${Y(j)}" r="7" fill="#fff" stroke="#9aa6bb" stroke-dasharray="2 2" style="cursor:pointer"/>`); }
    let cx = 0; for (let i = 0; i <= nx; i++) { o.push(`<line x1="${X(i)}" y1="${y0 - 26}" x2="${X(i)}" y2="${y0 - 8}" stroke="#7a86a0"/><circle data-axl="x:${i}" cx="${X(i)}" cy="${y0 - 36}" r="11" fill="#fff" stroke="${isS("axe", "x", i) ? "#ff9800" : "#14284b"}" stroke-width="2" style="cursor:pointer"/><text x="${X(i)}" y="${y0 - 32}" text-anchor="middle" font-size="12" font-weight="700" fill="#14284b" pointer-events="none">${String.fromCharCode(65 + i % 26)}</text>`); if (i < nx) o.push(`<text data-dim="x:${i}" x="${(X(i) + X(i + 1)) / 2}" y="${y0 - 14}" text-anchor="middle" font-size="11" fill="${isS("span", "x", i) ? "#e8590c" : "#5b6779"}" style="cursor:pointer">${f2(b.xs[i])}</text>`); }
    for (let j = 0; j <= ny; j++) { o.push(`<line x1="${x0 - 30}" y1="${Y(j)}" x2="${x0 - 12}" y2="${Y(j)}" stroke="#7a86a0"/><circle data-axl="y:${j}" cx="${x0 - 42}" cy="${Y(j)}" r="11" fill="#fff" stroke="${isS("axe", "y", j) ? "#ff9800" : "#14284b"}" stroke-width="2" style="cursor:pointer"/><text x="${x0 - 42}" y="${Y(j) + 4}" text-anchor="middle" font-size="12" font-weight="700" fill="#14284b" pointer-events="none">${j + 1}</text>`); if (j < ny) o.push(`<text data-dim="y:${j}" x="${x0 - 18}" y="${(Y(j) + Y(j + 1)) / 2 + 4}" text-anchor="end" font-size="11" fill="${isS("span", "y", j) ? "#e8590c" : "#5b6779"}" style="cursor:pointer">${f2(b.ys[j])}</text>`); }
    o.push(`<text x="${x0}" y="${VH - 8}" font-size="11" fill="#5b6779">${esc(v.nom)} · ${f2(W)} × ${f2(H)} m</text>`);
    return `<svg id="exbs-plan" viewBox="0 0 ${VW} ${VH}" style="width:${st.zoom * 100}%;height:auto;background:#fff;border:1px solid #d5dae1;cursor:${st.tool === "sel" ? "default" : "crosshair"}">${o.join("")}</svg>`;
  }

  function paletteHtml() {
    const items = PAL[st.layout] || PAL.geo;
    const b = (id, ic, lb) => { const on = id[0] === "~" ? st.diag === id.slice(1) : id[0] === "!" ? (id === "!multi" && st.multi) : st.tool === id; return `<button data-pt="${id}" class="${on ? "on" : ""}" title="${lb}"><i>${ic}</i><span>${lb}</span></button>`; };
    return `<div class="pal">${items.map(it => it === "-" ? "<hr>" : b(...it)).join("")}<hr>${st.view === "3d" ? `<hr>${b("!v:iso", "◇", "Iso")}${b("!v:top", "▢", "Dessus")}${b("!v:front", "▭", "Face")}${b("!v:side", "▯", "Côté")}${b("!isol", "◧", st.iso ? "Tous niv." : "Isoler niv.")}<hr>` : ""}${b("!undo", "↶", "Annuler")}${b("!redo", "↷", "Rétablir")}${b("!z+", "＋", "Zoom +")}${b("!z-", "－", "Zoom −")}${b("!zf", "⛶", "Ajuster")}</div>`;
  }

  function viewHtml() {
    const tabs = `<div class="tb"><button data-vw="plan" class="${st.view === "plan" ? "on" : ""}">Plan du niveau</button><button data-vw="frame" class="${st.view === "frame" ? "on" : ""}">Portique ${esc(st.dir === "X" ? "X-" + (st.line + 1) : "Y-" + String.fromCharCode(65 + st.line % 26))}</button><button data-vw="3d" class="${st.view === "3d" ? "on" : ""}">Vue 3D</button><span class="sp"></span><button data-act="3d" title="Ouvre la visionneuse 3D plein écran">3D plein écran</button></div>`;
    let body;
    if (st.view === "plan") body = planSvg();
    else if (st.view === "3d") body = root.EXB3 ? root.EXB3.svg(st.b, st.cam, { sel: sel3(), iso: st.iso, lv: st.lv }) : `<div class="msg e">Module 3D non chargé.</div>`;
    else if (st.err) body = `<div class="msg e">${esc(st.err)}</div>`;
    else if (!st.a) body = `<div class="msg">Aucune analyse : cliquez sur « ▶ Analyser » dans la palette (disposition Analyse).</div>`;
    else body = root.EXBR.svgPortique(st.a, st.layout === "chg" || st.layout === "geo" ? "M" : st.diag, st.sel).replace('style="width:100%;height:auto;', `style="width:${st.zoom * 100}%;height:auto;`);
    const errs = st.b.res && st.b.res.D ? st.b.res.D.filter(d => d.g === "erreur").slice(0, 2) : [];
    const hint = st.view === "3d" ? "Vue 3D : glissez pour tourner, Maj+glisser ou deux doigts pour déplacer, molette ou pincement pour zoomer. " + (HINT[st.tool] || "") + " Les outils agissent sur le niveau de l'élément cliqué." + (st.tool === "col" ? ` <label style="margin-left:8px"><input type="checkbox" data-opt="allLv" ${st.allLv ? "checked" : ""}> tous niveaux</label>` : "") : st.view === "plan" ? (HINT[st.tool] || "") + (st.tool === "col" ? ` <label style="margin-left:8px"><input type="checkbox" data-opt="allLv" ${st.allLv ? "checked" : ""}> tous niveaux</label>` : "") : "Cliquez une barre pour afficher ses efforts et ses armatures.";
    return `<h3>Vue</h3>${tabs}<div class="cmdl">${hint}</div>${errs.map(d => `<div class="msg e">${esc(d.m)}</div>`).join("")}<div class="vwr">${paletteHtml()}<div class="vb">${body}</div></div>`;
  }

  function propsHtml() {
    const b = st.b, rb = b.rb, a = st.a;
    const inp = (id, l, v, t) => `<label>${l}<input data-p="${id}" type="${t || "number"}" step="any" value="${esc(v)}"></label>`;
    let h = "<h3>Propriétés</h3><div class=\"pb\">";
    const ps = st.psel, v0 = b.niv[st.lv];
    if (st.ms.length && st.view === "plan" && (st.layout === "geo" || st.layout === "chg")) { h += msHtml(); }
    else if (ps && (st.view === "plan" || st.view === "3d") && (st.layout === "geo" || st.layout === "chg")) {
      const rowi = (k, l, val) => inp(k, l, val);
      if (ps.t === "col") { const cs = (v0.cs && v0.cs[ps.a + ":" + ps.c]) || 0, calc = G("batColA")(b.res, st.lv, ps.a, ps.c); h += `<b>Poteau ${G("nname")(ps.a, ps.c)} · ${esc(v0.nom)}</b><div class="row2"><span>Section calculée</span><b>${calc ? calc + " × " + calc + " cm" : "—"}</b></div>` + inp("p_cs", "Section imposée (cm, 0 = automatique)", cs) + `<button class="btnx" data-act="delcol">Supprimer ce poteau</button>`; }
      else if (ps.t === "beam") { const d = ps.a[0], i = +ps.a.slice(1), line = d === "X" ? ps.c : i, sec = G("bsec")(b, v0, d, line), k = `${st.lv}:${d}:${line}:${d === "X" ? i : ps.c}`, c = (b.rb.cl || {})[k] || {}; h += `<b>Poutre axe ${d === "X" ? ps.c + 1 : String.fromCharCode(65 + i % 26)} · ${esc(v0.nom)}</b>` + inp("p_bb", "Largeur de la ligne d'axe (m)", sec[0]) + inp("p_bh", "Hauteur de la ligne d'axe (m)", sec[1]) + `<h4 style="margin:10px 0 2px">Charge linéaire ajoutée (kN/m)</h4>` + inp("p_clG", "Permanente G supplémentaire", c.G || 0) + inp("p_clQ", "Exploitation Q supplémentaire", c.Q || 0) + `<p style="color:#5b6779">Chargée dans la station d'analyse (effets visibles dans les portiques).</p>`; }
      else if (ps.t === "slab") h += `<b>Dalle ${G("nname")(ps.a, ps.c)} · ${esc(v0.nom)}</b>` + inp("p_hs", "Épaisseur du niveau (m)", G("lvHs")(b, v0)) + `<div class="row2"><span>État</span><b>${v0.sl[ps.a][ps.c] ? "présente" : "retirée"}</b></div>`
        + `<h4 style="margin:10px 0 2px">Charges de cette dalle (kN/m²)</h4>` + inp("p_sG", "Permanente G (revêtement, cloisons)", G("slG")(v0, ps.a, ps.c)) + inp("p_sQ", "Exploitation Q", G("slQ")(v0, ps.a, ps.c))
        + `<div class="row2"><span>Origine</span><b>${G("slOv")(v0, ps.a, ps.c) ? "propre à cette dalle" : "valeur du niveau (" + f2(v0.G) + " / " + f2(v0.Q) + ")"}</b></div>`
        + (G("slOv")(v0, ps.a, ps.c) ? `<button class="btnx" data-act="slreset">Reprendre les valeurs du niveau</button>` : "") + `<p style="color:#5b6779">Remplacent G et Q du niveau pour cette dalle : poutres voisines, poteaux, calcul de la dalle et note.</p>`;
      else if (ps.t === "span") { const arr = ps.a === "x" ? b.xs : b.ys; h += `<b>Travée ${ps.a === "x" ? String.fromCharCode(65 + ps.c) + "–" + String.fromCharCode(66 + ps.c) : ps.c + 1 + "–" + (ps.c + 2)}</b>` + inp("p_span", "Longueur (m)", arr[ps.c]); }
      else if (ps.t === "axe") { const arr = ps.a === "x" ? b.xs : b.ys, pos = arr.slice(0, ps.c).reduce((t, x) => t + x, 0); h += `<b>Axe ${ps.a === "x" ? String.fromCharCode(65 + ps.c % 26) : ps.c + 1}</b>` + inp("p_axp", "Position (m)", +pos.toFixed(3)) + `<button class="btnx" data-act="axes">Ouvrir la table des axes</button>`; }
    } else if (st.sel != null && a && a.elements[st.sel]) {
      const e = a.elements[st.sel], d = (st.dsg || []).find(x => x.id === e.id), bar = a.env.barres[e.id];
      h += `<b>${esc(e.nom)}</b>`;
      const row = (k, v) => `<div class="row2"><span>${k}</span><b>${v}</b></div>`;
      h += row("Section", `${f2(e.b * 100, 0)} × ${f2(e.h * 100, 0)} cm`) + row("Longueur", f2(a.members[e.id] && a.fr.geo[e.id].L, 2) + " m");
      if (e.type === "p") h += row("Mu travée", f2(e.Mt, 1) + " kN.m") + row("Mu appui gauche / droit", f2(e.Ma0, 1) + " / " + f2(e.Ma1, 1)) + row("Vu", f2(e.V, 1) + " kN") + row("Flèche ELS", f2(Math.abs(e.fl) * 1000, 1) + " mm");
      else h += row("Nu (compression)", f2(e.N, 0) + " kN") + row("Nu traction max", f2(e.Nt, 0) + " kN") + row("|M| max", f2(e.M, 1) + " kN.m") + row("Vu", f2(e.V, 1) + " kN");
      if (d) h += `<div class="msg ${d.ok ? "o" : "e"}">${esc(d.arm)}</div>${d.msgs.map(m => `<div class="msg">${esc(m)}</div>`).join("")}`;
      const n = bar.x.length, L = bar.L, mx = Math.max(1e-9, ...bar.Mmax.map(Math.abs), ...bar.Mmin.map(Math.abs)), P = (arr, c) => `<polyline fill="none" stroke="${c}" stroke-width="1.6" points="${bar.x.map((x, i) => `${(10 + x / L * 240).toFixed(1)},${(50 - arr[i] / mx * 40).toFixed(1)}`).join(" ")}"/>`;
      h += `<h4 style="margin:10px 0 2px">Enveloppe de moment ELU</h4><svg viewBox="0 0 260 100" style="width:100%;background:#fff;border:1px solid #d5dae1"><line x1="10" y1="50" x2="250" y2="50" stroke="#999"/>${P(bar.Mmax, "#e8590c")}${P(bar.Mmin, "#1b6fb3")}</svg><div class="row2"><span>orange : max · bleu : min</span><b>±${f2(mx, 1)} kN.m</b></div>`;
    } else if (st.layout === "geo") {
      h += "<b>Géométrie</b>" + b.niv.map((v, k) => inp("h" + k, `${esc(v.nom)} : hauteur (m)`, v.h)).join("") + b.xs.map((l, i) => inp("x" + i, `Travée X ${String.fromCharCode(65 + i)}–${String.fromCharCode(66 + i)} (m)`, l)).join("") + b.ys.map((l, j) => inp("y" + j, `Travée Y ${j + 1}–${j + 2} (m)`, l)).join("") + inp("bm", "Poutres : largeur (m)", b.bm) + inp("bh", "Poutres : hauteur (m)", b.bh) + inp("hs", "Dalle : épaisseur (m)", b.hs);
    } else if (st.layout === "chg") {
      h += "<b>Charges</b>" + b.niv.map((v, k) => inp("G" + k, `${esc(v.nom)} : G (kN/m²)`, v.G) + inp("Q" + k, `${esc(v.nom)} : Q (kN/m²)`, v.Q)).join("") + `<label>Catégorie de Q<select data-p="cat">${[[1, "A habitation"], [2, "B bureaux"], [3, "C réunion"], [4, "D commerces"], [5, "E stockage"]].map(([v, l]) => `<option value="${v}"${v == rb.cat ? " selected" : ""}>${l}</option>`).join("")}</select></label>` + inp("Wx", "Vent : force par niveau (kN, 0 = sans)", rb.Wx) +
        `<label>Séisme (analyse modale)<select data-p="seis_on"><option value="0"${!rb.seis.on ? " selected" : ""}>Non</option><option value="1"${rb.seis.on ? " selected" : ""}>Oui</option></select></label>` + (rb.seis.on ? inp("ag", "agR (m/s²)", rb.seis.ag) + `<label>Sol<select data-p="sol">${[1, 2, 3, 4, 5].map(v => `<option value="${v}"${v == rb.seis.sol ? " selected" : ""}>${"ABCDE"[v - 1]}</option>`).join("")}</select></label>` + inp("q", "Coefficient q", rb.seis.q) : "");
    } else {
      h += `<b>Portique ${esc(st.dir === "X" ? "X-" + (st.line + 1) : "Y-" + String.fromCharCode(65 + st.line % 26))}</b>`;
      if (a) { const row = (k, v) => `<div class="row2"><span>${k}</span><b>${v}</b></div>`; h += row("Nœuds / barres / ddl", `${a.nodes.length} / ${a.members.length} / ${a.fr.freeD.length}`) + row("Poids sismique", f2(a.Wtot, 0) + " kN") + row("Période T1", a.T1 ? f2(a.T1, 3) + " s" : "—") + row("Combinaisons", a.elu.length + " ELU / " + a.els.length + " ELS"); if (a.seis) h += row("Vb (modal)", f2(a.seis.Vb, 0) + " kN") + row("θ max", f2(Math.max(...a.seis.theta), 3)); }
      else h += "<p>Lancez l'analyse pour voir les résultats de cet axe.</p>";
      h += "<p style=\"color:#5b6779\">Cliquez une barre du portique pour afficher ses efforts et ses armatures.</p>";
    }
    return h + "</div>";
  }

  function tableHtml() {
    const a = st.a, tabs = (st.layout === "dim" ? [["arm", "Armatures"], ["fond", "Fondations"]] : [["eff", "Efforts"], ["rea", "Réactions"], ["cmb", "Combinaisons"], ["dyn", "Dynamique"], ["tous", "Tous les portiques"]]);
    if (!tabs.some(t => t[0] === st.tab)) st.tab = tabs[0][0];
    const bar = `<div class="tb">${tabs.map(([k, l]) => `<button data-tb="${k}" class="${st.tab === k ? "on" : ""}">${l}</button>`).join("")}<span class="sp"></span><button data-act="csv">Exporter CSV</button></div>`;
    const T = (h, rows, rid) => `<table><tr>${h.map(x => `<th>${x}</th>`).join("")}</tr>${rows.map((r, i) => `<tr${rid ? ` data-r="${rid[i]}"` : ""} class="${rid && rid[i] === st.sel ? "on" : ""}">${r.map(x => `<td>${x}</td>`).join("")}</tr>`).join("")}</table>`;
    let body = "";
    if (st.tab === "fond") {
      const F = st.b.res && st.b.res.fond;
      if (!F) body = `<div class="msg">Fondations non calculées : corrigez les anomalies de la descente de charges.</div>`;
      else body = T(["Semelle", "Poteau (cm)", "Nser (kN)", "A×B×H (m)", "σ sol max (MPa)", "Taux sol", "Armatures A / B", "Poinçonnement", "État"], F.list.map(f => [f.name, f.a + "×" + f.a, f2(f.Ns, 0), `${f2(f.A)}×${f2(f.B)}×${f2(f.H)}`, f2(f.smax, 3), f2(f.tsol * 100, 0) + " %", `${f.barA} / ${f.barB}`, f2(f.pun * 100, 0) + " %", f.ok ? '<span class="ok">✔</span>' : '<span class="ko">✖</span>'])) + `<div class="pb"><div class="row2"><span>Béton des semelles</span><b>${f2(F.vol)} m³</b></div>${F.ov.map(o => `<div class="msg">Semelles ${o.a} et ${o.b} en contact (écart ${f2(o.gap * 100, 0)} cm) : prévoir semelle filante ou radier.</div>`).join("")}</div>`;
    } else if (st.tab === "tous") {
      if (!st.all) body = `<div class="msg">Cliquez « Tous les portiques » dans la disposition Analyse.</div>`;
      else body = T(["Portique", "Mu poutre max", "Vu max", "Nu poteau max", "T1 (s)", "État"], st.all.map(r => [r.nom, r.M, r.V, r.N, r.T, r.err ? `<span class="ko">${esc(r.err)}</span>` : '<span class="ok">✔</span>']));
    } else if (st.err) body = `<div class="msg e">${esc(st.err)}</div>`;
    else if (!a) body = `<div class="msg">Aucun résultat : lancez l'analyse.</div>`;
    else if (st.tab === "eff") body = T(["Élément", "Type", "Section (cm)", "M travée / M max", "M appui", "V", "N", "Flèche ELS (mm)"], a.elements.map(e => [esc(e.nom), e.type === "p" ? "Poutre" : "Poteau", `${f2(e.b * 100, 0)}×${f2(e.h * 100, 0)}`, e.type === "p" ? f2(e.Mt, 1) : f2(e.M, 1), e.type === "p" ? f2(e.Ma, 1) : "—", f2(e.V, 1), e.type === "c" ? f2(e.N, 0) : "—", e.type === "p" ? f2(Math.abs(e.fl) * 1000, 1) : "—"]), a.elements.map(e => e.id));
    else if (st.tab === "rea") body = T(["Appui", "x (m)", "Rx min", "Rx max", "Ry min", "Ry max", "M min", "M max"], a.reac.map(r => [String.fromCharCode(65 + r.i % 26) + (r.i + 1), f2(r.x), f2(r.Rxmin, 1), f2(r.Rx, 1), f2(r.Rymin, 0), f2(r.Ry, 0), f2(r.Mmin, 1), f2(r.M, 1)]));
    else if (st.tab === "cmb") body = T(["N°", "Famille", "Expression"], a.combos.map(c => [c.id, c.famille, esc(c.expr)]));
    else if (st.tab === "dyn") {
      if (!a.md) body = `<div class="msg">Pas de masse ou d'analyse modale impossible.</div>`;
      else body = T(["Mode", "T (s)", "f (Hz)", "Masse eff. X (%)", "Cumul (%)"], a.md.modes.map(m => [m.k, f2(m.T, 3), f2(m.f, 2), f2(m.mex / a.md.Mx * 100, 1), f2(m.rx * 100, 1)])) + (a.seis ? `<div class="pb"><div class="row2"><span>Vb (CQC) / Fb forces latérales</span><b>${f2(a.seis.Vb, 0)} / ${f2(a.seis.Fb, 0)} kN</b></div>${T(["Niveau", "V étage", "dr·q (mm)", "limite (mm)", "θ"], a.seis.floors.map((L, i) => [L, f2(a.seis.Vst[i], 0), f2(a.seis.dr[i] * 1000, 1), f2(a.seis.lim[i] * 1000, 1), f2(a.seis.theta[i], 3)]))}</div>` : "");
    } else if (st.tab === "arm") {
      if (!st.dsg) st.dsg = dimensionner(a, st.b);
      body = T(["Élément", "Type", "Section", "Sollicitations ELU", "Armatures", "État"], st.dsg.map(d => [esc(d.nom), d.typ, d.sec, esc(d.sol), esc(d.arm), d.ok ? '<span class="ok">✔</span>' : '<span class="ko">✖</span>']), st.dsg.map(d => d.id));
    }
    return `<h3>Tableaux</h3>${bar}<div id="exbs-tb">${body}</div>`;
  }

  function toolbarHtml() {
    const l = st.layout; let h = "";
    if (l === "ana") h = `<button data-act="run">▶ Analyser ce portique</button><button data-act="all">▶▶ Tous les portiques</button>`;
    if (l === "dim") h = `<button data-act="run">↻ Recalculer</button>`;
    return h ? `<div class="tb">${h}</div>` : "";
  }

  function render() {
    const R = q("#exbs"); if (!R) return; const b = st.b;
    const ae = document.activeElement; if (ae && ae !== document.body && R.contains(ae) && /INPUT|SELECT/.test(ae.tagName) && !render.busy) { render.busy = 1; try { ae.blur(); } finally { render.busy = 0; } }
    q(".tt b", R).textContent = `Station d'analyse — ${b.nom}`;
    q(".rb", R).innerHTML = LAYOUTS.map(([k, l]) => `<button data-ly="${k}" class="${st.layout === k ? "on" : ""}">${l}</button>`).join("");
    q(".tree", R).innerHTML = `<h3>Objets</h3><div class="tr">${tree()}</div>`;
    q(".vw", R).innerHTML = viewHtml(); q(".pr", R).innerHTML = propsHtml(); q(".tab", R).innerHTML = toolbarHtml() + tableHtml();
    const nb = st.a ? st.a.members.length : 0, nm = G("nrm")();
    q(".sb", R).innerHTML = `<span>${esc(nm.nom)}</span><span>Unités : kN · m · MPa</span><span>${st.a ? `${st.a.nodes.length} nœuds · ${nb} barres · ${st.a.combos.length} combinaisons` : "modèle non analysé"}</span><span>${esc(st.msg || "")}</span><span>${b.res && b.res.ok ? "descente de charges ✔" : "descente de charges à corriger"}</span>`;
    let D = q('.dlg', R); if (D && D.parentNode) D.parentNode.removeChild(D); if (st.dlg) R.insertAdjacentHTML('beforeend', dlgHtml()); else if (st.kdlg) { if (!KEYS) loadKeys(); R.insertAdjacentHTML('beforeend', kdlgHtml()); }
    R.dataset.pane = st.pane; qa(".mnav button", R).forEach(x => x.classList.toggle("on", x.dataset.pn === st.pane));
  }


  /* ------------------------------------------------------------------ édition (palettes) */
  const snapStr = () => JSON.stringify(st.b, (k, v) => (k === "res" || k === "__b" ? undefined : v));
  function snap() { hist.u.push(snapStr()); if (hist.u.length > 60) hist.u.shift(); hist.r.length = 0; }
  function restore(js) { const b = st.b, res = b.res, o = JSON.parse(js); Object.keys(b).forEach(k => { if (k !== "res") delete b[k]; }); Object.assign(b, o); b.res = res; st.psel = null; st.ms = []; if (st.lv >= b.niv.length) st.lv = b.niv.length - 1; reDesc(); }
  function undo(redo) { const A = redo ? hist.r : hist.u, B = redo ? hist.u : hist.r; if (!A.length) { st.msg = redo ? "Rien à rétablir" : "Rien à annuler"; return; } B.push(snapStr()); restore(A.pop()); st.msg = redo ? "Rétabli" : "Annulé"; }
  const pos = (arr, c) => arr.slice(0, c).reduce((t, x) => t + x, 0);
  const r3 = x => +x.toFixed(3);
  function afterGeo(msg) { const b = st.b; b.rb.cl = b.rb.cl || {}; reDesc(); if (msg) st.msg = msg; }
  function clearCl() { st.b.rb.cl = {}; }
  function axIns(k, i, at) { const b = st.b, a = k === "x" ? b.xs : b.ys, l = a[i]; if (!(l >= 0.4)) { st.msg = "Travée trop courte (< 0,40 m)"; return false; } snap(); G("batAxIns")(b, k, i); const p = at != null ? Math.min(Math.max(at, 0.2), l - 0.2) : l / 2; a[i] = r3(p); a[i + 1] = r3(l - p); clearCl(); afterGeo("Axe inséré"); return true; }
  function axDel(k, c) { const b = st.b, a = k === "x" ? b.xs : b.ys; if (a.length < 2) { st.msg = "Il faut au moins une travée"; return false; } snap();
    if (c > 0 && c < a.length) { a[c] = r3(a[c - 1] + a[c]); G("batAxDel")(b, k, c - 1); } else if (c === 0) G("batAxDel")(b, k, 0); else G("batAxDel")(b, k, a.length - 1);
    clearCl(); st.psel = null; afterGeo("Axe supprimé"); return true; }
  function axAdd(k) { const b = st.b, a = k === "x" ? b.xs : b.ys; snap(); a.push(a[a.length - 1]); G("batFit")(b); clearCl(); afterGeo("Travée ajoutée"); }
  function axPos(k, c, p) { const b = st.b, a = k === "x" ? b.xs : b.ys, n = a.length; if (c < 1 || !(p > 0)) return; const prev = pos(a, c - 1), nxt = c < n ? pos(a, c + 1) : null; if (p < prev + 0.2 || (nxt != null && p > nxt - 0.2)) { st.msg = "Position incompatible avec les axes voisins"; return; } snap(); a[c - 1] = r3(p - prev); if (c < n) a[c] = r3(nxt - p); afterGeo(); }
  function axSpan(k, i, l) { const b = st.b, a = k === "x" ? b.xs : b.ys; if (!(l >= 0.2)) { st.msg = "Travée minimale 0,20 m"; return; } snap(); a[i] = r3(l); afterGeo(); }
  function planPt(e) { const sv = q("#exbs-plan"); if (!sv) return null; const m = sv.getScreenCTM(); if (!m) return null; const p = sv.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; const u = p.matrixTransform(m.inverse()), g = st.pg; return { x: (u.x - g.x0) / g.s, y: (u.y - g.y0) / g.s }; }
  const snap05 = v => Math.round(v * 20) / 20;
  function axisTool(e) {
    const t = st.tool, k = t[2] === "X" ? "x" : "y", add = t[3] === "+", P = planPt(e), b = st.b, g = st.pg; if (!P) return;
    const arr = k === "x" ? b.xs : b.ys, px = k === "x" ? g.px : g.py, v = k === "x" ? P.x : P.y;
    if (add) { for (let i = 0; i < arr.length; i++) if (v > px[i] && v < px[i + 1]) return axIns(k, i, snap05(v - px[i])); return; }
    let best = 0, d = 1e9; px.forEach((x, i) => { if (Math.abs(x - v) < d) { d = Math.abs(x - v); best = i; } }); axDel(k, best);
  }
  function setCol(i, j, on, all) { const b = st.b; (all ? b.niv.map((_, k) => k) : [st.lv]).forEach(k => { const c = b.niv[k].cols; if (c[i] && c[i][j] !== undefined) c[i][j] = on ? 1 : 0; }); }
  function planClick(e, t) {
    const b = st.b, v = b.niv[st.lv]; let x;
    if (/^ax[XY][+-]$/.test(st.tool)) return axisTool(e);
    const multi = st.tool === "sel" && (st.view === "plan" || st.view === "3d") && e && (e.shiftKey || e.ctrlKey || e.metaKey || st.multi);
    if (st.tool === "sel" && !multi) st.ms = [];
    if (multi) { let kk = null; if ((x = t.closest("[data-bs]"))) { const [d, i, j] = x.dataset.bs.split(":"); kk = "beam:" + d + i + ":" + j; } else if ((x = t.closest("[data-nd]"))) { kk = "col:" + x.dataset.nd; } else if ((x = t.closest("[data-sp]"))) { kk = "slab:" + x.dataset.sp; }
      if (kk) { const at = st.ms.indexOf(kk); if (at >= 0) st.ms.splice(at, 1); else st.ms.push(kk); st.psel = null; st.msg = st.ms.length + " élément(s) sélectionné(s)"; return; } }
    if ((x = t.closest("[data-axl]"))) { const [k, c] = x.dataset.axl.split(":"); st.psel = { t: "axe", a: k, c: +c }; return; }
    if ((x = t.closest("[data-dim]"))) { const [k, c] = x.dataset.dim.split(":"); st.psel = { t: "span", a: k, c: +c }; return; }
    if ((x = t.closest("[data-bs]"))) { const [d, i, j] = x.dataset.bs.split(":"), key = d + i + ":" + j;
      if (st.tool === "beam") { snap(); v.bo = v.bo || {}; if (G("bOn")(v, d, +i, +j)) v.bo[key] = 0; else delete v.bo[key]; afterGeo(); return; }
      if (st.tool === "clx") { const line = d === "X" ? +j : +i, k = `${st.lv}:${d}:${line}:${d === "X" ? i : j}`; if ((b.rb.cl || {})[k]) { snap(); delete b.rb.cl[k]; afterGeo("Charge supprimée"); } return; }
      st.psel = { t: "beam", a: d + i, c: +j }; if (d === "Y") st.psel.a = "Y" + i; return; }
    if ((x = t.closest("[data-nd]"))) { const [i, j] = x.dataset.nd.split(":").map(Number);
      if (st.tool === "col") { snap(); setCol(i, j, !v.cols[i][j], st.allLv); afterGeo(); return; }
      st.psel = { t: "col", a: i, c: j }; return; }
    if ((x = t.closest("[data-sp]"))) { const [i, j] = x.dataset.sp.split(":").map(Number);
      if (st.tool === "slab") { snap(); v.sl[i][j] = v.sl[i][j] ? 0 : 1; afterGeo(); return; }
      st.psel = { t: "slab", a: i, c: j }; return; }
    st.psel = null;
  }
  function palAct(id) {
    const b = st.b;
    if (id[0] === "~") { st.diag = id.slice(1); return; }
    if (id[0] !== "!") { st.tool = id; st.msg = ""; return; }
    const a = id.slice(1);
    if (a === "undo") return undo(false); if (a === "redo") return undo(true);
    if (a.startsWith("v:")) { Object.assign(st.cam, root.EXB3.PRE[a.slice(2)], { zoom: 1, px: 0, py: 0 }); return; }
    if (a === "isol") { st.iso = !st.iso; return; }
    if (a === "z+" && st.view === "3d") { st.cam.zoom = Math.min(6, st.cam.zoom * 1.25); return; } if (a === "z-" && st.view === "3d") { st.cam.zoom = Math.max(.3, st.cam.zoom / 1.25); return; } if (a === "zf" && st.view === "3d") { st.cam.zoom = 1; st.cam.px = st.cam.py = 0; return; }
    if (a === "z+") { st.zoom = Math.min(4, st.zoom * 1.25); return; } if (a === "z-") { st.zoom = Math.max(.4, st.zoom / 1.25); return; } if (a === "zf") { st.zoom = 1; return; }
    if (a === "multi") { st.multi = !st.multi; st.tool = "sel"; if (!st.multi) st.ms = []; st.msg = st.multi ? "Mode sélection multiple : cliquez plusieurs éléments" : ""; return; }
    if (a === "selall") { selAll(); return; }
    if (a === "copy") { clipCopy(false); return; } if (a === "paste") { st.cmTg = null; clipPaste(null); return; } if (a === "keys") { st.kdlg = true; st.kcap = null; st.msg = ""; return; }
    if (a === "axes") { st.dlg = true; return; }
    if (a === "run") { run(); st.view = "frame"; return; } if (a === "all") { runAll(); return; }
    if (a === "dup") { snap(); const c = JSON.parse(JSON.stringify(b.niv[st.lv])); c.nom = "Niveau " + (b.niv.length); b.niv.splice(st.lv + 1, 0, c); st.lv++; clearCl(); afterGeo("Niveau copié"); return; }
    if (a === "lv+") { snap(); const c = JSON.parse(JSON.stringify(b.niv[b.niv.length - 1])); c.nom = "Niveau " + b.niv.length; b.niv.push(c); st.lv = b.niv.length - 1; afterGeo("Niveau ajouté"); return; }
    if (a === "lv-") { if (b.niv.length < 2) { st.msg = "Il faut au moins un niveau"; return; } snap(); b.niv.splice(st.lv, 1); st.lv = Math.min(st.lv, b.niv.length - 1); clearCl(); st.psel = null; afterGeo("Niveau supprimé"); return; }
  }
  /* ---- sélection multiple et actions groupées (plan du niveau) ---- */
  const msItems = () => st.ms.map(k => { const p = k.split(":"); return { t: p[0], a: p[1], c: p[2], i: p[0] === "beam" ? +p[1].slice(1) : +p[1], j: p[0] === "beam" ? +p[2] : +p[2], d: p[1][0] }; });
  const bKey = o => o.d + o.i + ":" + o.j;
  function allKeys() {
    const b = st.b, v = b.niv[st.lv], nx = b.xs.length, ny = b.ys.length, G_ = G("bOn"), o = [];
    for (let i = 0; i <= nx; i++) for (let j = 0; j <= ny; j++) if (v.cols[i][j]) o.push("col:" + i + ":" + j);
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) if (v.sl[i][j]) o.push("slab:" + i + ":" + j);
    for (let j = 0; j <= ny; j++) for (let i = 0; i < nx; i++) if (v.cols[i][j] && v.cols[i + 1][j] && G_(v, "X", i, j)) o.push("beam:X" + i + ":" + j);
    for (let i = 0; i <= nx; i++) for (let j = 0; j < ny; j++) if (v.cols[i][j] && v.cols[i][j + 1] && G_(v, "Y", i, j)) o.push("beam:Y" + i + ":" + j);
    return o;
  }
  function selAll() { st.ms = allKeys(); st.psel = null; st.msg = st.ms.length + " élément(s) sélectionné(s)"; }
  function selInvert() { const cur = new Set(curKeys()); st.ms = allKeys().filter(k => !cur.has(k)); st.psel = null; st.msg = st.ms.length + " élément(s) sélectionné(s)"; }
  const curKeys = () => st.ms.length ? st.ms.slice() : singleAsMulti();
  /* ---- presse-papiers : copier / couper / coller (au nœud visé) ---- */
  function clipCopy(cut) {
    const keys = curKeys(); if (!keys.length) { st.msg = "Sélectionnez d'abord des éléments"; return true; }
    const b = st.b, v = b.niv[st.lv], keep = st.ms; st.ms = keys; const L = msItems(); st.ms = keep;
    const items = L.map(o => o.t === "col" ? { t: "col", i: o.i, j: o.j, on: v.cols[o.i][o.j] ? 1 : 0, cs: (v.cs && v.cs[o.i + ":" + o.j]) || 0 } : o.t === "slab" ? { t: "slab", i: o.i, j: o.j, on: v.sl[o.i][o.j] ? 1 : 0, sc: v.sc && v.sc[o.i + ":" + o.j] ? { ...v.sc[o.i + ":" + o.j] } : null } : { t: "beam", d: o.d, i: o.i, j: o.j, off: v.bo && v.bo[bKey(o)] === 0 ? 1 : 0 });
    st.clip = { items, i0: Math.min(...items.map(x => x.i)), j0: Math.min(...items.map(x => x.j)), from: v.nom };
    st.msg = items.length + " élément(s) " + (cut ? "coupé(s)" : "copié(s)") + " dans le presse-papiers"; if (cut) msDelete(false); return true;
  }
  function clipPaste(tg) {
    const c = st.clip; if (!c || !c.items.length) { st.msg = "Presse-papiers vide : copiez d'abord des éléments"; return true; }
    const b = st.b, v = b.niv[st.lv], nx = b.xs.length, ny = b.ys.length, di = tg ? tg.i - c.i0 : 0, dj = tg ? tg.j - c.j0 : 0;
    snap(); v.bo = v.bo || {}; v.cs = v.cs || {}; const out = []; let skip = 0;
    c.items.forEach(x => { const i = x.i + di, j = x.j + dj;
      if (x.t === "col") { if (i < 0 || j < 0 || i > nx || j > ny) { skip++; return; } v.cols[i][j] = x.on; if (x.cs) v.cs[i + ":" + j] = x.cs; else delete v.cs[i + ":" + j]; out.push("col:" + i + ":" + j); }
      else if (x.t === "slab") { if (i < 0 || j < 0 || i >= nx || j >= ny) { skip++; return; } v.sl[i][j] = x.on; v.sc = v.sc || {}; if (x.sc) v.sc[i + ":" + j] = { ...x.sc }; else delete v.sc[i + ":" + j]; out.push("slab:" + i + ":" + j); }
      else { const X = x.d === "X"; if (i < 0 || j < 0 || (X ? i >= nx || j > ny : i > nx || j >= ny)) { skip++; return; } if (x.off) v.bo[x.d + i + ":" + j] = 0; else delete v.bo[x.d + i + ":" + j]; out.push("beam:" + x.d + i + ":" + j); } });
    st.ms = out; st.psel = null; afterGeo(out.length + " élément(s) collé(s) · " + b.niv[st.lv].nom + (skip ? " · " + skip + " hors de la trame ignoré(s)" : ""));
    return true;
  }
  function nearNode(e) { const P = planPt(e), g = st.pg; if (!P || !g) return null; const near = (arr, v) => { let k = 0, d = 1e9; arr.forEach((x, i) => { if (Math.abs(x - v) < d) { d = Math.abs(x - v); k = i; } }); return k; }; return { i: near(g.px, P.x), j: near(g.py, P.y) }; }
  function singleAsMulti() { const p = st.psel; return p && (p.t === "col" || p.t === "slab" || p.t === "beam") ? [p.t + ":" + p.a + ":" + p.c] : []; }
  function msDelete(on) {
    const b = st.b, v = b.niv[st.lv], keys = st.ms.length ? st.ms : singleAsMulti(); if (!keys.length) { st.msg = "Rien à supprimer : sélectionnez des éléments"; return; }
    const keep = st.ms; st.ms = keys; const L = msItems(); st.ms = keep; snap(); let n = 0;
    L.forEach(o => { if (o.t === "col") { setCol(o.i, o.j, on, false); n++; } else if (o.t === "slab") { v.sl[o.i][o.j] = on ? 1 : 0; n++; } else if (o.t === "beam") { v.bo = v.bo || {}; if (on) delete v.bo[bKey(o)]; else v.bo[bKey(o)] = 0; n++; } });
    if (!on) { st.ms = []; st.psel = null; } afterGeo(n + (on ? " élément(s) rétabli(s)" : " élément(s) supprimé(s)"));
  }
  /* V139 — charges surfaciques propres à une dalle : v.sc["i:j"] = { G, Q } ; une valeur égale à celle du niveau n'est pas mémorisée */
  function setSlabLoad(lv, i, j, c, val) {
    const key = i + ":" + j; lv.sc = lv.sc || {}; const o = lv.sc[key] = lv.sc[key] || {};
    if (Math.abs(val - lv[c]) < 1e-9) delete o[c]; else o[c] = val;
    if (!Number.isFinite(o.G) && !Number.isFinite(o.Q)) delete lv.sc[key];
    if (!Object.keys(lv.sc).length) delete lv.sc;
  }
  function msLoads(c, val) { const v = st.b.niv[st.lv]; snap(); let n = 0; msItems().forEach(o => { if (o.t !== "slab") return; setSlabLoad(v, o.i, o.j, c, val); n++; }); afterGeo(n + " dalle(s) : " + c + " = " + f2(val) + " kN/m²"); }
  function msLoadsReset() { const v = st.b.niv[st.lv]; snap(); let n = 0; msItems().forEach(o => { if (o.t !== "slab" || !(v.sc && v.sc[o.i + ":" + o.j])) return; delete v.sc[o.i + ":" + o.j]; n++; }); if (v.sc && !Object.keys(v.sc).length) delete v.sc; afterGeo(n + " dalle(s) : valeurs du niveau rétablies"); }
  function msSection(val) { const v = st.b.niv[st.lv]; snap(); v.cs = v.cs || {}; let n = 0; msItems().forEach(o => { if (o.t !== "col") return; if (val > 0) v.cs[o.i + ":" + o.j] = val; else delete v.cs[o.i + ":" + o.j]; n++; }); afterGeo(n + " poteau(x) : section " + (val > 0 ? val + " cm imposée" : "automatique")); }
  function msCopy(k) {
    const b = st.b, v = b.niv[st.lv], T = b.niv[k]; if (!T || k === st.lv) { st.msg = "Choisissez un autre niveau"; return; } snap(); let n = 0; T.cs = T.cs || {}; T.bo = T.bo || {};
    msItems().forEach(o => { if (o.t === "col") { T.cols[o.i][o.j] = v.cols[o.i][o.j]; const key = o.i + ":" + o.j; if (v.cs && v.cs[key]) T.cs[key] = v.cs[key]; else delete T.cs[key]; n++; } else if (o.t === "slab") { T.sl[o.i][o.j] = v.sl[o.i][o.j]; T.sc = T.sc || {}; const kk = o.i + ":" + o.j; if (v.sc && v.sc[kk]) T.sc[kk] = { ...v.sc[kk] }; else delete T.sc[kk]; n++; } else if (o.t === "beam") { const key = bKey(o); if (v.bo && v.bo[key] === 0) T.bo[key] = 0; else delete T.bo[key]; n++; } });
    afterGeo(n + " élément(s) copié(s) vers " + T.nom);
  }
  function msHtml() {
    const b = st.b, L = msItems(), nc = L.filter(o => o.t === "col").length, ns = L.filter(o => o.t === "slab").length, nb = L.filter(o => o.t === "beam").length;
    const opts = b.niv.map((v, k) => k === st.lv ? "" : `<option value="${k}">${esc(v.nom)}</option>`).join("");
    return `<b>Sélection multiple · ${esc(b.niv[st.lv].nom)}</b><div class="row2"><span>Poteaux</span><b>${nc}</b></div><div class="row2"><span>Poutres</span><b>${nb}</b></div><div class="row2"><span>Dalles</span><b>${ns}</b></div>`
      + (nc ? `<label>Section imposée aux poteaux (cm, 0 = automatique)<input data-p="p_mcs" type="number" step="any" value=""></label>` : "")
      + (ns ? `<h4 style="margin:10px 0 2px">Charges des ${ns} dalle(s) (kN/m²)</h4><label>Permanente G<input data-p="p_msG" type="number" step="any" value=""></label><label>Exploitation Q<input data-p="p_msQ" type="number" step="any" value=""></label><button class="btnx" data-act="ms:sreset">Reprendre les valeurs du niveau</button>` : "")
      + `<button class="btnx" data-act="ms:del">Supprimer la sélection (Suppr)</button><button class="btnx" data-act="ms:rest">Rétablir la sélection</button>`
      + (b.niv.length > 1 ? `<label>Copier la sélection vers<select data-ml>${opts}</select></label><button class="btnx" data-act="ms:copy">Copier vers ce niveau</button>` : "")
      + `<button class="btnx" data-act="ms:clear">Désélectionner (Échap)</button>`;
  }
  /* ---- raccourcis clavier configurables ---- */
  const ACTS = [["undo", "Annuler", "Ctrl+Z"], ["redo", "Rétablir", "Ctrl+Y"], ["copy", "Copier la sélection", "Ctrl+C"], ["cut", "Couper la sélection", "Ctrl+X"], ["paste", "Coller (même position)", "Ctrl+V"], ["selall", "Tout sélectionner", "Ctrl+A"], ["invert", "Inverser la sélection", "Ctrl+I"], ["esc", "Annuler la commande / désélectionner", "Escape"], ["del", "Supprimer la sélection", "Delete"], ["lvup", "Niveau supérieur", "PageUp"], ["lvdn", "Niveau inférieur", "PageDown"], ["tsel", "Outil Sélection", "S"], ["tcol", "Outil Poteau", "C"], ["tbeam", "Outil Poutre", "P"], ["tslab", "Outil Dalle", "D"], ["multi", "Sélection multiple (bascule)", "M"], ["zin", "Zoom +", "+"], ["zout", "Zoom −", "-"], ["zfit", "Ajuster la vue", "0"], ["iso", "Isoler le niveau (3D)", "I"], ["v3", "Basculer plan ↔ 3D", "Tab"], ["menu", "Ouvrir le menu contextuel", "Shift+F10"]];
  let KEYS = null;
  function loadKeys() { KEYS = {}; ACTS.forEach(a => KEYS[a[0]] = a[2]); try { const o = JSON.parse(localStorage.getItem("exbs-keys") || "{}"); Object.keys(o).forEach(k => { if (KEYS[k] !== undefined && typeof o[k] === "string") KEYS[k] = o[k]; }); } catch (er) { } }
  function saveKeys() { try { localStorage.setItem("exbs-keys", JSON.stringify(KEYS)); } catch (er) { } }
  function combo(e) { let k = e.key; if (/^(Control|Shift|Alt|Meta)$/.test(k)) return ""; if (k === " ") k = "Space"; if (k === "=") k = "+"; if (k === "_") k = "-"; const named = k.length > 1; if (!named) k = k.toUpperCase(); const m = e.ctrlKey || e.metaKey; return (m ? "Ctrl+" : "") + (e.altKey ? "Alt+" : "") + (e.shiftKey && (named || m || e.altKey) ? "Shift+" : "") + k; }
  function kdlgHtml() {
    const rows = ACTS.map(([id, l]) => `<tr><td>${esc(l)}</td><td><button data-kb="${id}" class="${st.kcap === id ? "cap" : ""}">${st.kcap === id ? "Appuyez sur une touche…" : esc(KEYS[id] || "—")}</button></td></tr>`).join("");
    return `<div class="dlg"><div><div class="hd"><b>Raccourcis clavier</b><button class="btnx" data-kact="reset" style="width:auto;margin:0 4px 0 0;padding:4px 12px">Réinitialiser</button><button class="btnx" data-kact="close" style="width:auto;margin:0;padding:4px 12px">Fermer</button></div><p style="color:#5b6779;margin:4px 0">Cliquez une touche puis appuyez sur la nouvelle combinaison (Ctrl, Alt, Maj acceptés). Échap annule. Enregistré sur cet appareil. Clic droit dans le plan ou la 3D : menu contextuel.</p><table><tr><th>Commande</th><th>Raccourci</th></tr>${rows}</table><div class="msg">${esc(st.msg || "")}</div></div></div>`;
  }
  function doAct(id) {
    const geo = st.layout === "geo" || st.layout === "chg", vv = st.view === "plan" || st.view === "3d", edit = st.layout === "geo" && vv;
    switch (id) {
      case "undo": undo(false); return true; case "redo": undo(true); return true;
      case "copy": return geo && vv ? clipCopy(false) : false; case "cut": return edit ? clipCopy(true) : false; case "paste": return edit ? clipPaste(st.cmTg || null) : false;
      case "selall": if (geo && vv) { selAll(); return true; } return false; case "invert": if (geo && vv) { selInvert(); return true; } return false;
      case "esc": st.ms = []; st.psel = null; st.multi = false; st.tool = "sel"; st.msg = ""; return true;
      case "del": if (edit) { msDelete(false); return true; } return false;
      case "lvup": case "lvdn": { const n = st.b.niv.length, nl = Math.min(n - 1, Math.max(0, st.lv + (id === "lvup" ? 1 : -1))); if (nl !== st.lv) { st.lv = nl; st.ms = []; st.psel = null; st.msg = st.b.niv[nl].nom; } return true; }
      case "tsel": case "tcol": case "tbeam": case "tslab": if (!edit) return false; st.tool = { tsel: "sel", tcol: "col", tbeam: "beam", tslab: "slab" }[id]; st.msg = ""; return true;
      case "multi": if (geo && vv) { palAct("!multi"); return true; } return false;
      case "zin": palAct("!z+"); return true; case "zout": palAct("!z-"); return true; case "zfit": palAct("!zf"); return true;
      case "iso": if (st.view === "3d") { st.iso = !st.iso; return true; } return false;
      case "v3": if (geo) { st.view = st.view === "3d" ? "plan" : "3d"; return true; } return false;
      case "menu": { const w = q(st.view === "3d" ? "#exbs-3d" : "#exbs-plan"); if (!w) return false; const r = w.getBoundingClientRect(); cmOpen({ clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, target: w, kb: true }); return true; }
    }
    return false;
  }
  function onKey(e) {
    const R = q("#exbs"); if (!R) return; const tg = e.target, tn = tg && tg.tagName; if (!KEYS) loadKeys();
    if (st.kdlg) { if (st.kcap) { e.preventDefault(); if (e.key === "Escape") { st.kcap = null; return render(); } const c = combo(e); if (!c) return; const used = ACTS.find(a => a[0] !== st.kcap && KEYS[a[0]] === c); if (used) { st.msg = c + " est déjà utilisé par « " + used[1] + " »"; return render(); } KEYS[st.kcap] = c; saveKeys(); st.msg = "Raccourci enregistré : " + c; st.kcap = null; return render(); } if (e.key === "Escape") { st.kdlg = false; render(); } return; }
    if (st.dlg) { if (e.key === "Escape") { st.dlg = false; render(); } return; }
    const cm = q("#exbs-cm"); if (cm && e.key === "Escape") { cmClose(); e.preventDefault(); return; }
    if (tn === "INPUT" || tn === "SELECT" || tn === "TEXTAREA") { if (e.key === "Escape") tg.blur(); return; }
    let c = combo(e); if (c === "Backspace") c = "Delete"; if (c === "Ctrl+Shift+Z") c = KEYS.redo;
    const a = ACTS.find(x => KEYS[x[0]] === c); if (!a) return;
    cmClose(); st.cmTg = null; if (doAct(a[0])) { e.preventDefault(); render(); }
  }
  /* ---- menu contextuel (clic droit) : plan et 3D ---- */
  function cmClose() { const m = q("#exbs-cm"); if (m && m.parentNode) m.parentNode.removeChild(m); }
  function cmOpen(e) {
    const R = q("#exbs"); if (!R) return; if (!KEYS) loadKeys(); const t = e.target, b = st.b; let hit = null, tg = null;
    if (st.view === "3d") { const x = t.closest && t.closest("[data-e3]"); if (x) { const [kd, k, a, b2, c2] = x.dataset.e3.split(":"); if (kd !== "f") { if (st.lv !== +k) { st.ms = []; st.psel = null; } st.lv = +k; if (kd === "g" || kd === "c") { hit = { t: "col", a: +a, c: +b2 }; tg = { i: +a, j: +b2 }; } else if (kd === "s") { hit = { t: "slab", a: +a, c: +b2 }; tg = { i: +a, j: +b2 }; } else if (kd === "b") { hit = { t: "beam", a: a + b2, c: +c2 }; tg = { i: +b2, j: +c2 }; } } } }
    else { let x; if ((x = t.closest("[data-nd]"))) { const [i, j] = x.dataset.nd.split(":").map(Number); hit = { t: "col", a: i, c: j }; tg = { i, j }; } else if ((x = t.closest("[data-bs]"))) { const [d, i, j] = x.dataset.bs.split(":"); hit = { t: "beam", a: d + i, c: +j }; tg = { i: +i, j: +j }; } else if ((x = t.closest("[data-sp]"))) { const [i, j] = x.dataset.sp.split(":").map(Number); hit = { t: "slab", a: i, c: j }; tg = { i, j }; } if (!e.kb) { const nn = nearNode(e); if (nn) tg = nn; } }
    if (hit) { const key = hit.t + ":" + hit.a + ":" + hit.c; if (!curKeys().includes(key)) { st.ms = []; st.psel = hit; } }
    st.cmTg = tg; const n = curKeys().length, edit = st.layout === "geo", geo = st.layout === "geo" || st.layout === "chg", K = id => KEYS[id] || "";
    const it = (l, a, kid, off) => ({ l, a, k: kid ? K(kid) : "", off: !!off }), sep = { sep: 1 }, m = [];
    if (geo) {
      if (n) { m.push(it("Propriétés", "prop")); m.push(it("Copier", "act:copy", "copy")); m.push(it("Couper", "act:cut", "cut", !edit)); }
      m.push(it(tg ? "Coller ici" : "Coller", "act:paste", "paste", !edit || !st.clip)); m.push(sep);
      if (n) { m.push(it("Supprimer", "act:del", "del", !edit)); m.push(it("Rétablir (annule la suppression)", "rest", null, !edit)); b.niv.forEach((v, k) => { if (k !== st.lv) m.push(it("Copier vers « " + v.nom + " »", "tolv:" + k, null, !edit)); }); m.push(sep); }
      m.push(it("Tout sélectionner", "act:selall", "selall")); m.push(it("Inverser la sélection", "act:invert", "invert")); if (n) m.push(it("Désélectionner", "act:esc", "esc")); m.push(sep);
      if (edit) { m.push(it("Outil Poteau", "act:tcol", "tcol")); m.push(it("Outil Poutre", "act:tbeam", "tbeam")); m.push(it("Outil Dalle", "act:tslab", "tslab")); m.push(it("Outil Sélection", "act:tsel", "tsel")); m.push(sep); }
    }
    m.push(it("Annuler", "act:undo", "undo")); m.push(it("Rétablir", "act:redo", "redo")); m.push(sep);
    if (st.view === "3d") m.push(it(st.iso ? "Afficher tous les niveaux" : "Isoler le niveau", "act:iso", "iso")); if (geo) m.push(it(st.view === "3d" ? "Passer au plan" : "Passer en 3D", "act:v3", "v3"));
    m.push(it("Ajuster la vue", "act:zfit", "zfit")); m.push(it("Niveau supérieur", "act:lvup", "lvup")); m.push(it("Niveau inférieur", "act:lvdn", "lvdn")); m.push(sep); m.push(it("Raccourcis clavier…", "keys"));
    const el = document.createElement("div"); el.id = "exbs-cm"; el.innerHTML = m.map(x => x.sep ? "<hr>" : `<div data-cm="${x.a}" class="${x.off ? "off" : ""}"><span>${esc(x.l)}</span><small>${esc(x.k)}</small></div>`).join("");
    cmClose(); R.appendChild(el); const w = el.offsetWidth, h = el.offsetHeight; el.style.left = Math.max(4, Math.min(e.clientX, window.innerWidth - w - 6)) + "px"; el.style.top = Math.max(4, Math.min(e.clientY, window.innerHeight - h - 6)) + "px";
    render(); const el2 = q("#exbs-cm"); if (!el2) R.appendChild(el);
  }
  function cmRun(a) {
    if (a.startsWith("act:")) doAct(a.slice(4)); else if (a === "keys") { st.kdlg = true; st.kcap = null; st.msg = ""; } else if (a === "prop") { st.pane = "prop"; } else if (a === "rest") msDelete(true); else if (a.startsWith("tolv:")) { const keep = st.ms; if (!keep.length) st.ms = singleAsMulti(); msCopy(+a.slice(5)); }
  }
  function dlgHtml() {
    const b = st.b, blk = (k, T) => { const a = k === "x" ? b.xs : b.ys, rows = [];
      for (let c = 0; c <= a.length; c++) { const nm = k === "x" ? String.fromCharCode(65 + c % 26) : c + 1;
        rows.push(`<tr><td><b>${nm}</b></td><td>${c === 0 ? "0,000" : `<input type="number" step="0.05" data-ax="${k}:${c}:p" value="${r3(pos(a, c))}">`}</td><td>${c < a.length ? `<input type="number" step="0.05" data-ax="${k}:${c}:s" value="${a[c]}">` : "—"}</td><td>${c < a.length ? `<button data-axa="ins:${k}:${c}" title="Insérer un axe au milieu de la travée">＋ axe</button>` : ""}<button data-axa="del:${k}:${c}" title="Supprimer cet axe">✕</button></td></tr>`); }
      return `<h4>${T}</h4><table><tr><th>Axe</th><th>Position (m)</th><th>Travée suivante (m)</th><th>Actions</th></tr>${rows.join("")}</table><button class="btnx" data-axa="add:${k}:0" style="width:auto;padding:4px 10px">＋ Ajouter une travée</button>`; };
    return `<div class="dlg"><div><div class="hd"><b>Configuration des axes (grille)</b><button class="btnx" data-axa="close" style="width:auto;margin:0;padding:4px 12px">Fermer</button></div><p style="color:#5b6779;margin:4px 0">Modifier la position d'un axe déplace uniquement cet axe ; les travées voisines s'ajustent. La modification est immédiate sur tous les niveaux (poteaux, poutres, dalles suivent).</p>${blk("x", "Axes en X (lettres)")}${blk("y", "Axes en Y (numéros)")}<div class="msg">${esc(st.msg || "")}</div></div></div>`;
  }

  function save() { const b = st.b; b.mod = Date.now(); G("sv")("xbb", G("B")); }
  function reDesc() { const b = st.b; b.res = G("batCalc")(b); save(); st.a = null; st.dsg = null; st.all = null; }

  function propEdit(k, v) {
    const b = st.b, ps = st.psel, lv = b.niv[st.lv]; if (!ps) return false; snap();
    if (k === "p_cs") { lv.cs = lv.cs || {}; const key = ps.a + ":" + ps.c; if (v > 0) lv.cs[key] = v; else delete lv.cs[key]; }
    else if (k === "p_hs") { if (!(v > 0)) return false; lv.hs = v; }
    else if (k === "p_sG" || k === "p_sQ") { if (ps.t !== "slab" || !(v >= 0)) return false; setSlabLoad(lv, ps.a, ps.c, k === "p_sG" ? "G" : "Q", v); }
    else if (k === "p_bb" || k === "p_bh") { if (!(v > 0)) return false; const d = ps.a[0], i = +ps.a.slice(1), line = d === "X" ? ps.c : i, key = d + line; lv.bl = lv.bl || {}; const cur = G("bsec")(b, lv, d, line); lv.bl[key] = { b: k === "p_bb" ? v : cur[0], h: k === "p_bh" ? v : cur[1] }; }
    else if (k === "p_clG" || k === "p_clQ") { const d = ps.a[0], i = +ps.a.slice(1), line = d === "X" ? ps.c : i, key = `${st.lv}:${d}:${line}:${d === "X" ? i : ps.c}`; b.rb.cl = b.rb.cl || {}; const c = b.rb.cl[key] = b.rb.cl[key] || {}; c[k === "p_clG" ? "G" : "Q"] = v; }
    else if (k === "p_span") { if (!(v >= 0.2)) return false; (ps.a === "x" ? b.xs : b.ys)[ps.c] = v; }
    else if (k === "p_axp") { hist.u.pop(); axPos(ps.a, ps.c, v); return true; }
    reDesc(); return true;
  }

  function onProp(el) {
    const b = st.b, k = el.dataset.p, v = el.type === "number" ? +el.value : el.value, rb = b.rb; if (el.type === "number" && !(v >= 0)) return;
    let m;
    if ((m = /^h(\d+)$/.exec(k)) && v > 0) b.niv[+m[1]].h = v; else if ((m = /^x(\d+)$/.exec(k)) && v > 0) b.xs[+m[1]] = v; else if ((m = /^y(\d+)$/.exec(k)) && v > 0) b.ys[+m[1]] = v;
    else if (k === "bm" || k === "bh" || k === "hs") { if (!(v > 0)) return; b[k] = v; }
    else if ((m = /^([GQ])(\d+)$/.exec(k))) b.niv[+m[2]][m[1]] = v;
    else if (k === "p_mcs") { msSection(v); render(); return; }
    else if (k === "p_msG" || k === "p_msQ") { if (el.value === "") return; msLoads(k === "p_msG" ? "G" : "Q", v); render(); return; }
    else if (k === "p_cs" || k === "p_bb" || k === "p_bh" || k === "p_clG" || k === "p_clQ" || k === "p_hs" || k === "p_sG" || k === "p_sQ" || k === "p_span" || k === "p_axp") { if (!propEdit(k, v)) return; render(); return; }
    else if (k === "cat") rb.cat = +v; else if (k === "Wx") rb.Wx = v; else if (k === "seis_on") rb.seis.on = +v; else if (k === "ag") rb.seis.ag = v; else if (k === "sol") rb.seis.sol = +v; else if (k === "q") rb.seis.q = v;
    else return;
    if (!/^(cat|Wx|seis_on|ag|sol|q)$/.test(k)) reDesc(); else { st.a = null; st.dsg = null; save(); }
    if (/^(seis_on)$/.test(k)) render();
  }

  function csv() {
    const t = q("#exbs-tb table"); if (!t) return; const rows = qa("tr", t).map(r => qa("th,td", r).map(c => '"' + c.textContent.replace(/"/g, '""') + '"').join(";")).join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿" + rows], { type: "text/csv" })); a.download = "station-" + st.tab + ".csv"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function runAll() {
    const b = st.b; st.all = lines(b).map(l => { const r = analyser(l.dir, l.line); if (r.err) return { nom: l.nom, M: "—", V: "—", N: "—", T: "—", err: r.err }; const a = r.a, P = a.elements.filter(e => e.type === "p"), C = a.elements.filter(e => e.type === "c");
      return { nom: l.nom, M: P.length ? f2(Math.max(...P.map(e => Math.max(e.Mt, e.Ma))), 1) : "—", V: f2(Math.max(...a.elements.map(e => e.V)), 1), N: C.length ? f2(Math.max(...C.map(e => e.N)), 0) : "—", T: a.T1 ? f2(a.T1, 3) : "—" }; });
    st.tab = "tous";
  }


  function sel3() { const k = st.lv, o = []; const add = (t, a, c) => { if (t === "col") o.push(`c:${k}:${a}:${c}`); else if (t === "slab") o.push(`s:${k}:${a}:${c}`); else if (t === "beam") o.push(`b:${k}:${a[0]}:${a.slice(1)}:${c}`); };
    if (st.psel) add(st.psel.t, st.psel.a, st.psel.c); st.ms.forEach(m => { const p = m.split(":"); add(p[0], p[0] === "col" || p[0] === "slab" ? +p[1] : p[1], +p[2]); }); return o.length ? o : null; }
  function click3(e, el) {
    const id = el.dataset.e3, [kd, k, a, b2, c2] = id.split(":");
    if (kd === "f") { st.msg = `Semelle ${G("nname")(+k, +a)} (dimensionnée automatiquement : onglet Fondations).`; return; }
    if (st.lv !== +k) { st.ms = []; st.psel = null; } st.lv = +k;
    if (/^ax[XY][+-]$/.test(st.tool)) { st.msg = "Les axes se modifient en vue plan ou dans la table « Axes… »."; return; }
    const fake = { closest: q => { if (kd === "g" || kd === "c") return q === "[data-nd]" ? { dataset: { nd: `${a}:${b2}` } } : null; if (kd === "s") return q === "[data-sp]" ? { dataset: { sp: `${a}:${b2}` } } : null; if (kd === "b") return q === "[data-bs]" ? { dataset: { bs: `${a}:${b2}:${c2}` } } : null; return null; } };
    planClick(e, fake);
  }
  let ptr = new Map(), dragInfo = null;
  function redraw3() { const el = q("#exbs-3d"); if (!el || !root.EXB3) return; el.outerHTML = root.EXB3.svg(st.b, st.cam, { sel: sel3(), iso: st.iso, lv: st.lv }); }
  function p3down(e) { const el = e.target.closest("#exbs-3d"); if (!el || e.button === 2) return; ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); dragInfo = { x: e.clientX, y: e.clientY, moved: false, yaw: st.cam.yaw, pit: st.cam.pit, px: st.cam.px, py: st.cam.py, zoom: st.cam.zoom, shift: e.shiftKey || e.button === 2 || e.button === 1, d0: null }; }
  function p3move(e) {
    if (!dragInfo || !ptr.has(e.pointerId)) return; ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const el = q("#exbs-3d"); if (!el) return; const r = el.getBoundingClientRect(), k = 760 / r.width;
    if (ptr.size >= 2) { const [a, b] = [...ptr.values()], d = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2; if (dragInfo.d0 == null) { dragInfo.d0 = d; dragInfo.mx = mx; dragInfo.my = my; dragInfo.zoom = st.cam.zoom; dragInfo.px = st.cam.px; dragInfo.py = st.cam.py; }
      st.cam.zoom = Math.max(.3, Math.min(6, dragInfo.zoom * d / dragInfo.d0)); st.cam.px = dragInfo.px + (mx - dragInfo.mx) * k; st.cam.py = dragInfo.py + (my - dragInfo.my) * k; dragInfo.moved = true; st._moved = true; return redraw3(); }
    const dx = e.clientX - dragInfo.x, dy = e.clientY - dragInfo.y; if (!dragInfo.moved && Math.hypot(dx, dy) < 5) return; dragInfo.moved = true; st._moved = true;
    if (dragInfo.shift) { st.cam.px = dragInfo.px + dx * k; st.cam.py = dragInfo.py + dy * k; } else { st.cam.yaw = dragInfo.yaw + dx * .008; st.cam.pit = Math.max(.02, Math.min(Math.PI / 2 - .001, dragInfo.pit + dy * .008)); }
    redraw3();
  }
  function p3up(e) { ptr.delete(e.pointerId); if (!ptr.size) dragInfo = null; }
  function p3wheel(e) { if (!e.target.closest("#exbs-3d")) return; e.preventDefault(); st.cam.zoom = Math.max(.3, Math.min(6, st.cam.zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12))); redraw3(); }

  function click(e) {
    const t = e.target, g = s => t.closest(s), R = q("#exbs"); let x;
    const cmE = q("#exbs-cm"); if (cmE) { const it = g("[data-cm]"); const a = it && !it.classList.contains("off") ? it.dataset.cm : null; cmClose(); if (it) { if (a) cmRun(a); return render(); } return; }
    if (g(".tt button")) return close();
    if ((x = g("[data-kb]"))) { st.kcap = x.dataset.kb; st.msg = ""; return render(); }
    if ((x = g("[data-kact]"))) { if (x.dataset.kact === "close") { st.kdlg = false; st.kcap = null; } else { KEYS = {}; ACTS.forEach(a => KEYS[a[0]] = a[2]); saveKeys(); st.msg = "Raccourcis par défaut rétablis"; } return render(); }
    if (st._moved) { st._moved = false; if (g("#exbs-3d")) return; }
    if ((x = g("[data-e3]")) && st.view === "3d") { click3(e, x); return render(); }
    if ((x = g("[data-axa]"))) { const [a, k, c] = x.dataset.axa.split(":"); if (a === "close") st.dlg = false; else if (a === "ins") axIns(k, +c); else if (a === "del") axDel(k, +c); else if (a === "add") axAdd(k); return render(); }
    if ((x = g("[data-pt]"))) { palAct(x.dataset.pt); return render(); }
    if (g("#exbs-plan") && st.view === "plan") { planClick(e, t); return render(); }
    if (g("[data-opt]")) { st.allLv = g("[data-opt]").checked; return render(); }
    if ((x = g("[data-ly]"))) { st.layout = x.dataset.ly; st.tool = "sel"; st.psel = null; if (st.layout === "ana" || st.layout === "res" || st.layout === "dim") { st.view = "frame"; if (!st.a && !st.err) run(); } else st.view = st.layout === "geo" ? "plan" : st.view; if (st.layout === "dim") st.tab = st.tab === "fond" ? "fond" : "arm"; else if (st.tab === "arm" || st.tab === "fond") st.tab = "eff"; st.sel = null; return render(); }
    if ((x = g("[data-lv]"))) { st.lv = +x.dataset.lv; st.view = "plan"; return render(); }
    if ((x = g("[data-ln]"))) { const [d, l] = x.dataset.ln.split(":"); st.dir = d; st.line = +l; st.sel = null; st.a = null; st.dsg = null; if (st.layout !== "geo" && st.layout !== "chg") { st.view = "frame"; run(); } else st.view = "plan"; return render(); }
    if ((x = g("[data-vw]"))) { st.view = x.dataset.vw; if (st.view === "frame" && !st.a && !st.err) run(); return render(); }
    if ((x = g("[data-dg]"))) { st.diag = x.dataset.dg; return render(); }
    if ((x = g("[data-tb]"))) { st.tab = x.dataset.tb; return render(); }
    if ((x = g("[data-pn]"))) { st.pane = x.dataset.pn; return render(); }
    if ((x = g("[data-m]")) && st.a) { st.sel = +x.dataset.m; if (st.layout === "geo" || st.layout === "chg") st.layout = "res"; return render(); }
    if ((x = g("tr[data-r]"))) { st.sel = +x.dataset.r; st.pane = window.innerWidth < 900 ? "prop" : st.pane; return render(); }
    if ((x = g("[data-act]"))) { const a = x.dataset.act;
      if (a === "ms:del") { msDelete(false); return render(); } if (a === "ms:rest") { msDelete(true); return render(); } if (a === "ms:clear") { st.ms = []; st.multi = false; return render(); }
      if (a === "ms:sreset") { msLoadsReset(); return render(); }
      if (a === "slreset") { const ps = st.psel; if (ps && ps.t === "slab") { snap(); const lv = st.b.niv[st.lv]; if (lv.sc) { delete lv.sc[ps.a + ":" + ps.c]; if (!Object.keys(lv.sc).length) delete lv.sc; } afterGeo("Dalle : valeurs du niveau rétablies"); } return render(); }
      if (a === "ms:copy") { const se = q("[data-ml]"); if (se) msCopy(+se.value); return render(); }
      if (a === "delcol") { const ps = st.psel; if (ps) { snap(); setCol(ps.a, ps.c, false, false); st.psel = null; afterGeo(); } return render(); }
      if (a === "axes") { st.dlg = true; return render(); }
      if (a === "run") { run(); st.view = "frame"; return render(); } if (a === "all") { runAll(); return render(); } if (a === "csv") return csv();
      if (a === "3d") { try { G("open3D")("Vue 3D — " + st.b.nom, G("batScene3")(st.b, { sel: st.lv, hi: true })); } catch (er) { G("toast")("Vue 3D indisponible"); } return; } }
  }

  function close() { cmClose(); document.removeEventListener("keydown", onKey); const R = q("#exbs"); if (R) R.remove(); document.body.style.overflow = ""; try { const f = root.__exbsBack; if (f) f(); } catch (e) { } }

  function open(b, back) {
    close(); root.__exbsBack = back || null; st.b = b; hist.u.length = 0; hist.r.length = 0; st.tool = "sel"; st.psel = null; st.ms = []; st.dlg = false; st.msg = ""; st.zoom = 1;
    if (!b.rb) b.rb = { Wx: 0, cat: 2, seis: { on: 0, ag: 1.5, gI: 1, tsp: 1, sol: 2, q: 3, dlim: .005, nu: .5 } };
    if (!(b.res && b.res.ok)) { try { b.res = G("batCalc")(b); } catch (e) { } }
    st.layout = "geo"; st.view = "plan"; st.a = null; st.err = null; st.sel = null; st.all = null; st.dsg = null; st.lv = b.niv.length - 1; st.pane = "view"; st.dir = "X"; st.line = 0;
    if (!q("#exbs-css")) { const s = document.createElement("style"); s.id = "exbs-css"; s.textContent = CSS; document.head.appendChild(s); }
    const R = document.createElement("div"); R.id = "exbs";
    R.innerHTML = `<div class="tt"><b></b><button>✕ Fermer</button></div><div class="rb"></div><div class="ws"><div class="pn tree"></div><div class="pn vw"></div><div class="pn pr"></div><div class="pn tab"></div></div><div class="mnav"><button data-pn="tree">Objets</button><button data-pn="view">Vue</button><button data-pn="prop">Propriétés</button><button data-pn="tab">Tableaux</button></div><div class="sb"></div>`;
    R.addEventListener("click", click); R.addEventListener("pointerdown", p3down); R.addEventListener("pointermove", p3move); R.addEventListener("pointerup", p3up); R.addEventListener("pointercancel", p3up); R.addEventListener("wheel", p3wheel, { passive: false }); R.addEventListener("contextmenu", e => { if (e.target.closest("#exbs-3d,#exbs-plan")) { e.preventDefault(); if (!st.dlg && !st.kdlg) cmOpen(e); } });
    R.addEventListener("change", e => { const ax = e.target.closest("[data-ax]"); if (ax) { const [k, c, w] = ax.dataset.ax.split(":"); if (w === "p") axPos(k, +c, +ax.value); else axSpan(k, +c, +ax.value); return render(); } const el = e.target.closest("[data-p]"); if (el) { onProp(el); render(); } });
    document.addEventListener("keydown", onKey); st.ms = []; st.multi = false;
    document.body.appendChild(R); document.body.style.overflow = "hidden"; render();
  }
  root.EXBS = { open, close, modele, lines, dimensionner, state: st };
})(typeof window !== "undefined" ? window : globalThis);
