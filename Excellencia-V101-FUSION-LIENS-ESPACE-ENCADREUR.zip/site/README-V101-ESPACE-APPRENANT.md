# V101 — Espace apprenant (frais, cours, calendrier, résultats, profil, recours)

**Page :** `espace-apprenant.html` (nouvelle). L'ancienne `apprenant.html` reste en service pour les clients (résultats, devis, plans) ; elle ignore désormais la session technique `__espace`.

**Connexion :** année académique, matricule (9 chiffres mis au format 000-000-000), mot de passe. Mêmes fonctions serveur que l'ancienne page (`apprenant_connexion`, `apprenant_changer_mdp`) : premier mot de passe 123456789, changement obligatoire avec code = 4 derniers chiffres du téléphone. Aucune limite de durée de session : l'apprenant reste connecté tant que la page est ouverte, jusqu'à « Déconnexion ». (Fermer l'onglet demande de se reconnecter : le mot de passe n'est jamais mémorisé sur l'appareil.)

**Menu (vocabulaire formation) :** Tableau de bord · Mes frais de formation · Calendrier de formation · Ma formation · Mes résultats · Mon profil · Déconnexion. Le recours s'ouvre depuis le tableau de bord et depuis « Mes résultats ».

**Ouverture unique, puis mises à jour automatiques :** une seule fois, Formation › Évaluations › **📢 Publier l'espace apprenant** (saisie du WhatsApp et des numéros de paiement). Ensuite, tant que le logiciel est connecté au serveur, il envoie tout seul (vérification toutes les 30 s, envoi des seules fiches modifiées) : paiements et reçus approuvés, séances du planning, cours, nouveaux inscrits (matricule attribué), coordonnées. Il ne reste à publier à la main que les **résultats** (📢 Publier les résultats). Hors connexion, les changements partent à la reconnexion.

**Écran des paiements :** une carte par motif (inscription, formation) avec Num. Réf. (n° du reçu), « Paiement approuvé avec succès », date, badge PAYÉ / MOITIÉ PAYÉE, et un bouton **Preuve de paiement** (PDF, qui ne remplace pas le reçu officiel) ; puis les versements enregistrés.

**Publication par l'équipe (première fois) :** Formation › Évaluations › **📢 Publier l'espace apprenant**. Pour chaque participant ayant un matricule, publie dans la session technique `__espace` : frais (dernier reçu + paiements), cours (formation, modules, formateur), calendrier (séances du planning de sa formation), coordonnées et numéro WhatsApp de l'administration (demandé à la publication). **Republier** met à jour.

**Bordereau de paiement :** depuis « Mes frais de formation », l'apprenant coche ce qu'il paie (inscription, formation : reste à payer), voit les numéros de paiement ou de caisse, et télécharge un PDF (nom, matricule, formation, montants, total par devise, numéros, référence BP-xxxx-AAAAMMJJ-HHMM). Ce n'est pas un reçu. La référence n'est pas enregistrée sur le serveur : l'apprenant l'envoie avec sa preuve de paiement (bouton WhatsApp).
À la publication, l'équipe saisit les numéros : `Caisse Excellencia : N° 001 ; Airtel Money : 0828633708 (Excellencia Building)` (mémorisés pour la fois suivante). Le reste à payer vient du statut du dernier reçu : NON PAYÉ = montant entier, MOITIÉ PAYÉE = moitié, PAYÉ = 0.

**Recours :** le message (objet, module, texte) est préparé et envoyé par WhatsApp ou copié. Il n'est PAS enregistré sur le serveur (il faudrait une nouvelle fonction SQL).

**Limites connues :** pas de paiement en ligne (l'écran « frais » affiche l'état et l'historique) ; les paiements du logiciel n'ont pas de devise (montant seul) ; la photo reste sur l'appareil ; non testé sur un vrai Supabase.

**Avant ouverture au public :** essayer avec un apprenant fictif. Vérifier que publier_resultats conserve le mot de passe d'un apprenant déjà connecté lors d'une republication.

**Mots de passe :** plus de blocage après essais ratés (script `supabase/migration-v101-apprenants-sans-blocage.sql`, à exécuter une fois). Attention : le mot de passe par défaut est le même pour tous (123456789) et les matricules ont 9 chiffres ; tant qu'un apprenant n'a pas changé son mot de passe, son espace est ouvert à qui connaît son matricule.
