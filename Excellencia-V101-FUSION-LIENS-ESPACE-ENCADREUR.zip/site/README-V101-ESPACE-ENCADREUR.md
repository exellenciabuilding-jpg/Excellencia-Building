# V101 — Espace encadreur (lot 1) : tableau de bord, sujets émis, apprenants confiés

Page : `tfl-portail.html?role=encadreur` (connexion par matricule, comme avant). Rien n'est retiré : validation du sujet, commentaires, messages, progression proposée restent identiques.

## Ce qui est nouveau
- **Tableau de bord** : apprenants confiés (sur le maximum), avis demandés, sujets émis (dont retenus), progression moyenne ; alertes « avis demandé » et « charge maximale atteinte ».
- **Mes sujets émis** : état de chaque sujet (reçu, retenu, refusé, motif) ; **demander la modification ou le retrait** ; **proposer un nouveau sujet** (titre, domaine, problématique, objectifs, méthodologie) ; liste « en attente de traitement ».
- **Mes apprenants confiés** : recherche (nom, matricule, sujet, dossier) et filtres (avis demandé, en cours, terminés).

## Côté administration (aucun nouvel écran)
- Nouveau sujet proposé → TFL › Encadreurs › **② Récupérer les formulaires en ligne** (même circuit que le formulaire encadreur ; le sujet arrive « Reçu », non publié).
- Demande de modification ou de retrait → **④ Récupérer les demandes** → Appliquer / Ignorer.
- Republier ensuite les portails : l'encadreur voit le nouvel état.

## À faire UNE FOIS
1. Supabase › SQL Editor : `supabase/migration-v101-espace-encadreur.sql` (livré aussi à part ; réexécutable ; aucune table modifiée). Contrôle : `select proname from pg_proc where proname in ('tfl_espace_sujet_proposer','tfl_espace_sujet_demande','tfl_portail_connexion');` → 3 lignes.
2. Déployer le ZIP, puis TFL › Portails › **Publier / mettre à jour** une fois : le téléphone et l'e-mail de chaque encadreur sont ajoutés à son accès (nécessaire pour « Proposer un sujet »).
Sans le SQL : le portail fonctionne comme avant ; les nouveaux boutons répondent « Service indisponible ».

## Tests
`node tools/test-tfl/test-espace-encadreur.js` (vue, échappement HTML, actions conservées). Les autres tests TFL donnent les mêmes résultats qu'avant (le seul échec de `test-portail.js` sur le libellé « Code encadreur » existait déjà).
