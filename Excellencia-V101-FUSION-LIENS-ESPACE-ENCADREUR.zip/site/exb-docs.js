/* exb-docs.js (V99l + page de garde du devis) — documents clients : PDF à texte sélectionnable (devis / facture / reçu), QR de vérification,
 * filigrane BROUILLON / ANNULÉ, conditions générales, signature du client au doigt, suivi des devis,
 * devis → facture → reçu (même numéro de dossier), envoi du PDF (partage, WhatsApp, e-mail).
 * Les données de suivi restent sur l'appareil (clé EXB_DOCS_V1). Vérification en ligne : voir supabase/migration-v99l-documents.sql (facultatif). */
(function (w) {
  'use strict';
  var KEY = 'EXB_DOCS_V1', W = 595, H = 842, M = 40;
  var NAVY = '0.090 0.208 0.396', GOLD = '0.769 0.604 0.220', GREY = '0.40 0.43 0.49', LINE = '0.80 0.84 0.90', SOFT = '0.94 0.96 0.98';
  var WIN = { 8217: 146, 8216: 145, 8220: 147, 8221: 148, 8211: 150, 8212: 151, 8364: 128, 339: 156, 338: 140, 8230: 133, 8226: 149, 160: 32, 8239: 32 };
  var STATUTS = [['brouillon', 'Brouillon'], ['envoyé', 'Envoyé'], ['accepté', 'Accepté'], ['refusé', 'Refusé'], ['annulé', 'Annulé']];
  var CGV = [
    '1. Validité : la présente offre est valable pendant la durée indiquée, à compter de sa date d’émission.',
    '2. Acceptation : le devis signé, précédé de la mention « bon pour accord », vaut commande.',
    '3. Paiement : un acompte est exigible à la commande ; le solde est payable selon l’avancement convenu et au plus tard à la réception des travaux.',
    '4. Délais : ils courent à compter de la réception de l’acompte et de la mise à disposition du site ; ils sont prolongés en cas d’intempéries ou de force majeure.',
    '5. Prix : les prix sont fermes pendant la durée de validité ; toute modification du programme fait l’objet d’un avenant.',
    '6. Réception : elle est constatée contradictoirement ; les réserves éventuelles sont levées dans un délai convenu entre les parties.',
    '7. Litiges : les parties recherchent d’abord une solution amiable avant tout recours aux juridictions compétentes.'
  ].join('\n');

  /* ---------- outils ---------- */
  function pe(t) { var o = ''; t = String(t == null ? '' : t); for (var i = 0; i < t.length; i++) { var c = t.charCodeAt(i); if (c === 10 || c === 13) { o += ' '; continue; } if (WIN[c]) c = WIN[c]; else if (c > 255) c = 63; if (c === 40 || c === 41 || c === 92) o += '\\' + String.fromCharCode(c); else if (c < 32) o += ' '; else if (c > 126) o += '\\' + ('00' + c.toString(8)).slice(-3); else o += String.fromCharCode(c); } return o; }
  function bytes(s) { var u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i) & 255; return u; }
  var _cx = null;
  function tw(t, sz, b) { try { if (!_cx && typeof document !== 'undefined') _cx = document.createElement('canvas').getContext('2d'); if (_cx) { _cx.font = (b === 'i' ? 'italic ' : b === 'bi' ? 'italic bold ' : b ? 'bold ' : '') + sz + 'px Helvetica, Arial, sans-serif'; return _cx.measureText(String(t)).width; } } catch (e) {} return String(t).length * sz * (b ? 0.56 : 0.52); }
  function wrap(t, max, sz, b) {
    var out = []; String(t == null ? '' : t).split(/\r?\n/).forEach(function (par) {
      var l = ''; par.split(/\s+/).filter(Boolean).forEach(function (x) {
        while (tw(x, sz, b) > max && x.length > 1) { var n = x.length; while (n > 1 && tw(x.slice(0, n), sz, b) > max) n--; if (l) { out.push(l); l = ''; } out.push(x.slice(0, n)); x = x.slice(n); }
        if (!l) l = x; else if (tw(l + ' ' + x, sz, b) <= max) l += ' ' + x; else { out.push(l); l = x; }
      }); out.push(l);
    }); return out;
  }
  function nf(v, d) { v = Number(v) || 0; var s = Math.abs(v).toFixed(d == null ? 2 : d), p = s.split('.'); p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (v < 0 ? '-' : '') + p.join(','); }
  function frDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function dueISO(date, validity) {
    var s = String(validity || ''); if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    var b = /^\d{4}-\d{2}-\d{2}$/.test(date || '') ? new Date(date + 'T12:00:00') : new Date(), m = /(\d+)\s*(jours?|j|semaines?|mois)/i.exec(s), n = 30;
    if (m) { n = +m[1]; var u = m[2].toLowerCase(); if (u.indexOf('sem') === 0) n *= 7; else if (u === 'mois') n *= 30; }
    b.setDate(b.getDate() + n); return b.toISOString().slice(0, 10);
  }
  function dossierOf(no) { var m = /(\d{4}[-_]\d+)/.exec(no || ''); return m ? m[1] : (String(no || '').replace(/^[A-Za-z]+[-_ ]*/, '') || String(no || '')); }
  function digits(p) { p = String(p || '').replace(/[^\d+]/g, ''); if (/^0\d{9}$/.test(p)) return '243' + p.slice(1); return p.replace(/\D/g, ''); }
  async function sha(s) {
    try { var b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.from(new Uint8Array(b)).map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
    catch (e) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } var o = ''; for (var j = 0; j < 8; j++) { h = Math.imul(h ^ j, 16777619); o += ('00000000' + (h >>> 0).toString(16)).slice(-8); } return o; }
  }
  function jpg(src, maxW, q) {
    return new Promise(function (ok, ko) {
      if (typeof Image === 'undefined') return ko(new Error('no-dom'));
      var im = new Image(); if (/^https?:/i.test(src)) im.crossOrigin = 'anonymous';
      im.onload = function () { var r = Math.min(maxW / im.naturalWidth, 1), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * r)); c.height = Math.max(1, Math.round(im.naturalHeight * r)); var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height); var d = c.toDataURL('image/jpeg', q || 0.8), b = atob(d.split(',')[1]), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); ok({ u: u, w: c.width, h: c.height }); };
      im.onerror = function () { ko(new Error('image')); }; im.src = src;
    });
  }

  /* ---------- registre local (suivi) ---------- */
  function db() { try { var d = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; d.docs = d.docs || {}; return d; } catch (e) { return { docs: {} }; } }
  function put(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); return true; } catch (e) { return false; } }
  function track(no, f) { if (!no) return null; var d = db(), r = d.docs[no] || { no: no, created: today(), status: '', history: [] }; Object.keys(f || {}).forEach(function (k) { if (f[k] !== undefined) r[k] = f[k]; }); d.docs[no] = r; put(d); return r; }
  function getRec(no) { return db().docs[no] || null; }
  function setStatus(no, s) { var r = getRec(no); if (!r) return null; r.history = r.history || []; r.history.push({ s: s, d: today() }); var u = track(no, { status: s, history: r.history }); if (u && u.hash) publish({ no: no, kind: u.kind, hash: u.hash, date: u.date, total: u.total, cur: u.cur, status: s }); return u; }
  function effStatus(r) { if (r.status === 'envoyé' && r.due && r.due < today()) return 'expiré'; return r.status; }
  function signer(explicitOnly) { var d = db(), g = {}; try { g = (!explicitOnly && window.EXBId) ? EXBId.get() : {}; } catch (e) {} var x = d.signer || {}; return { name: x.name || g.dg || '', role: x.role || (g.dg ? g.dgRole : '') || '' }; }
  function setSigner(n, r) { var d = db(); d.signer = { name: String(n || '').trim(), role: String(r || '').trim() }; put(d); }
  function cgvText() { var d = db(); return d.cgv || CGV; }
  function setCgv(t) { var d = db(); d.cgv = String(t || '').trim() || CGV; put(d); }

  /* ---------- vérification (QR) ---------- */
  function baseUrl() { try { var fx = (w.EXB77 && w.EXB77.base && w.EXB77.base()) || ''; if (fx) return fx; if (w.exbOrigin && w.exbBase && w.exbOrigin() !== location.origin) return w.exbBase(); return location.href.split('#')[0]; } catch (e) { return ''; } }
  async function verifCode(d, kind, total, cur) {
    var dig = (d.lines || []).filter(function (r) { return !r.k; }).map(function (r) { return [r[0], r[2], r[3]].join(':'); }).join('|');
    var h = (await sha([kind, d.no, d.date, Number(total).toFixed(2), cur, (d.client && d.client.name) || '', dig].join('|'))).slice(0, 10);
    var raw = [kind.charAt(0), d.no, d.date, Number(total).toFixed(2), cur, h].join('~'), url = (w.EXBVerif && w.EXBVerif.vurl) ? w.EXBVerif.vurl(raw, d.client && d.client.name) : baseUrl() + '#verify=' + encodeURIComponent(raw);
    try { if (unescape(encodeURIComponent(url)).length > 213) url = 'EXB-DOC:' + raw; } catch (e) { url = 'EXB-DOC:' + raw; }
    if (unescape(encodeURIComponent(url)).length > 213) url = ''; return { hash: h, url: url, raw: raw };
  }

  /* ---------- moteur PDF : texte vectoriel, QR vectoriel, filigrane ---------- */
  /* d = {kind,no,dossier,date,validity,client:{name,address,phone,email},project,place,cur,total,lines:[[des,unit,qty,pu,usd,fc]+.k],
          T:{taux,sub,subfc,imp,impv,impfc,tot,totfc},title,note,status,clientSig,visa,logo,acompte:{pct,usd,fc},paid:{usd,fc,mode,date,cumulUsd,cumulFc,resteUsd,resteFc}} */
  async function build(d, o) {
    o = o || {}; var kind = d.kind || 'devis', TT = { devis: 'DEVIS', facture: 'FACTURE', recu: 'REÇU' }[kind] || 'DEVIS', TL = { devis: 'Devis', facture: 'Facture', recu: 'Reçu' }[kind] || 'Devis';
    try { if (w.EXB_UNIQUE && kind === 'devis') w.EXB_UNIQUE.guardDoc(d); } catch (e) {}
    var cover = o.cover !== false && d.noCover !== true;
    var ID = null; try { ID = w.EXBId ? w.EXBId.get() : null; } catch (e) {}
    var BR = d.company || (ID && ID.name) || 'Excellencia Building', IM = [], pages = [], ops, used, y, k = 0, T = d.T || { sub: 0, subfc: 0, imp: 0, impv: 0, impfc: 0, tot: 0, totfc: 0, taux: 0 }, cl = d.client || {};
    async function img(src, mw, q) { if (!src) return -1; try { IM.push(await jpg(src, mw, q)); return IM.length - 1; } catch (e) { return -1; } }
    var logo = d.noLogo ? -1 : await img(d.logo || (ID && ID.logo) || 'icon-192.png', 192, 0.9); if (logo < 0 && !d.noLogo) logo = await img('icon-192.png', 192, 0.9);
    var visa = await img(d.visa, 520, 0.92), csig = await img(d.clientSig, 500, 0.9);
    var wm = o.watermark !== undefined ? o.watermark : (d.status === 'annulé' ? 'ANNULÉ' : d.status === 'brouillon' ? 'BROUILLON' : '');
    var total = d.total != null ? d.total : T.tot, cur = d.cur || 'USD', V = await verifCode(d, kind, kind === 'recu' && d.paid ? (/^(CDF|FC)$/i.test(cur) ? d.paid.fc : d.paid.usd) : total, cur);
    var BOT = cover ? 90 : 70, CW = [200, 42, 52, 58, 80, 83], CX = [M]; for (var i = 0; i < CW.length; i++) CX.push(CX[i] + CW[i]);
    function Tx(t, x, yy, sz, b, rgb, al, cs) { t = String(t == null ? '' : t); cs = cs || 0; var wd = tw(t, sz, b) + cs * Math.max(0, t.length - 1); if (al === 'r') x -= wd; else if (al === 'c') x -= wd / 2; ops.push((rgb || '0.10 0.12 0.18') + ' rg BT /' + (b === 'bi' ? 'F4' : b === 'i' ? 'F3' : b ? 'F2' : 'F1') + ' ' + sz + ' Tf ' + (cs ? cs.toFixed(2) + ' Tc ' : '') + x.toFixed(2) + ' ' + yy.toFixed(2) + ' Td (' + pe(t) + ') Tj ' + (cs ? '0 Tc ' : '') + 'ET'); }
    function Dm(n, x, yy, ww, hh) { used[n] = 1; ops.push('q ' + ww.toFixed(2) + ' 0 0 ' + hh.toFixed(2) + ' ' + x.toFixed(2) + ' ' + yy.toFixed(2) + ' cm /I' + n + ' Do Q'); }
    function R(x, yy, ww, hh, rgb) { ops.push(rgb + ' rg ' + x.toFixed(2) + ' ' + yy.toFixed(2) + ' ' + ww.toFixed(2) + ' ' + hh.toFixed(2) + ' re f'); }
    function RS(x, yy, ww, hh, rgb, lw) { ops.push(rgb + ' RG ' + (lw || 0.6) + ' w ' + x.toFixed(2) + ' ' + yy.toFixed(2) + ' ' + ww.toFixed(2) + ' ' + hh.toFixed(2) + ' re S'); }
    function fitImg(n, bw, bh) { var m = IM[n], ww = bw, hh = ww * m.h / m.w; if (hh > bh) { hh = bh; ww = hh * m.w / m.h; } return [ww, hh]; }

    /* ===== V99zzzzzzzzzzzzzz : page de garde du devis, en-tête des pages de détail, pied de page avec QR ===== */
    function PL(pts, rgb) { var q = rgb + ' rg ' + pts[0][0].toFixed(2) + ' ' + pts[0][1].toFixed(2) + ' m '; for (var j = 1; j < pts.length; j++) q += pts[j][0].toFixed(2) + ' ' + pts[j][1].toFixed(2) + ' l '; ops.push(q + 'h f'); }
    function rrPath(x, yy, ww, hh, r) {
      r = Math.min(r, ww / 2, hh / 2); var c = 0.5523 * r, x2 = x + ww, y2 = yy + hh, f = function (n) { return n.toFixed(2); };
      return f(x + r) + ' ' + f(yy) + ' m ' + f(x2 - r) + ' ' + f(yy) + ' l ' + f(x2 - r + c) + ' ' + f(yy) + ' ' + f(x2) + ' ' + f(yy + r - c) + ' ' + f(x2) + ' ' + f(yy + r) + ' c ' +
        f(x2) + ' ' + f(y2 - r) + ' l ' + f(x2) + ' ' + f(y2 - r + c) + ' ' + f(x2 - r + c) + ' ' + f(y2) + ' ' + f(x2 - r) + ' ' + f(y2) + ' c ' +
        f(x + r) + ' ' + f(y2) + ' l ' + f(x + r - c) + ' ' + f(y2) + ' ' + f(x) + ' ' + f(y2 - r + c) + ' ' + f(x) + ' ' + f(y2 - r) + ' c ' +
        f(x) + ' ' + f(yy + r) + ' l ' + f(x) + ' ' + f(yy + r - c) + ' ' + f(x + r - c) + ' ' + f(yy) + ' ' + f(x + r) + ' ' + f(yy) + ' c h ';
    }
    function RR(x, yy, ww, hh, r, fill, stroke, lw) { ops.push((fill ? fill + ' rg ' : '') + (stroke ? stroke + ' RG ' + (lw || 0.8) + ' w ' : '') + rrPath(x, yy, ww, hh, r) + (fill && stroke ? 'B' : fill ? 'f' : 'S')); }
    function CLIP(x, yy, ww, hh, r) { ops.push('q ' + rrPath(x, yy, ww, hh, r) + 'W n'); }
    function UNCLIP() { ops.push('Q'); }
    function CI(cx, cy, r, rgb) { var c = 0.5523 * r, f = function (n) { return n.toFixed(2); }; ops.push(rgb + ' rg ' + f(cx + r) + ' ' + f(cy) + ' m ' + f(cx + r) + ' ' + f(cy + c) + ' ' + f(cx + c) + ' ' + f(cy + r) + ' ' + f(cx) + ' ' + f(cy + r) + ' c ' + f(cx - c) + ' ' + f(cy + r) + ' ' + f(cx - r) + ' ' + f(cy + c) + ' ' + f(cx - r) + ' ' + f(cy) + ' c ' + f(cx - r) + ' ' + f(cy - c) + ' ' + f(cx - c) + ' ' + f(cy - r) + ' ' + f(cx) + ' ' + f(cy - r) + ' c ' + f(cx + c) + ' ' + f(cy - r) + ' ' + f(cx + r) + ' ' + f(cy - c) + ' ' + f(cx + r) + ' ' + f(cy) + ' c h f'); }
    function LN(x1, y1, x2, y2, rgb, lw) { ops.push(rgb + ' RG ' + (lw || 0.8) + ' w ' + x1.toFixed(2) + ' ' + y1.toFixed(2) + ' m ' + x2.toFixed(2) + ' ' + y2.toFixed(2) + ' l S'); }
    function IC(t, x, yy, s, fg, bg) {
      if (t === 'tel') { RR(x + s * 0.22, yy, s * 0.56, s, s * 0.14, fg); R(x + s * 0.32, yy + s * 0.24, s * 0.36, s * 0.56, bg); CI(x + s * 0.5, yy + s * 0.11, s * 0.05, bg); }
      else if (t === 'mail') { R(x, yy + s * 0.16, s, s * 0.68, fg); LN(x + s * 0.04, yy + s * 0.8, x + s * 0.5, yy + s * 0.44, bg, 0.9); LN(x + s * 0.96, yy + s * 0.8, x + s * 0.5, yy + s * 0.44, bg, 0.9); }
      else if (t === 'pin') { PL([[x + s * 0.2, yy + s * 0.5], [x + s * 0.8, yy + s * 0.5], [x + s * 0.5, yy]], fg); CI(x + s * 0.5, yy + s * 0.64, s * 0.34, fg); CI(x + s * 0.5, yy + s * 0.64, s * 0.13, bg); }
      else if (t === 'cal') { RR(x, yy, s, s * 0.92, s * 0.12, fg); R(x + s * 0.12, yy + s * 0.12, s * 0.76, s * 0.5, bg); R(x + s * 0.24, yy + s * 0.84, s * 0.12, s * 0.16, fg); R(x + s * 0.64, yy + s * 0.84, s * 0.12, s * 0.16, fg); }
      else if (t === 'clock') { CI(x + s / 2, yy + s / 2, s / 2, fg); LN(x + s / 2, yy + s / 2, x + s / 2, yy + s * 0.8, bg, 0.9); LN(x + s / 2, yy + s / 2, x + s * 0.74, yy + s * 0.5, bg, 0.9); }
      else if (t === 'user') { CI(x + s / 2, yy + s * 0.72, s * 0.24, fg); RR(x + s * 0.12, yy, s * 0.76, s * 0.4, s * 0.2, fg); }
      else if (t === 'build') { R(x + s * 0.14, yy, s * 0.72, s, fg); [0.2, 0.5, 0.8].forEach(function (u) { [0.3, 0.6].forEach(function (v) { R(x + s * v, yy + s * u - s * 0.06, s * 0.12, s * 0.12, bg); }); }); }
      else if (t === 'doc') { RR(x + s * 0.16, yy, s * 0.68, s, s * 0.08, fg); [0.3, 0.52, 0.74].forEach(function (u) { LN(x + s * 0.3, yy + s * u, x + s * 0.7, yy + s * u, bg, 0.8); }); }
    }
    function fitSz(t, maxW, b, maxSz) { var u = tw(String(t), 100, b) / 100; return u > 0 ? Math.min(maxSz, maxW / u) : maxSz; }
    function qrDraw(qx, qy, sz) {
      if (!(V.url && w.EXBQR)) return false;
      try { var m = w.EXBQR.matrix(V.url), n = m.length, q = 2, t = n + 2 * q, s2 = sz / t, pth = ''; R(qx, qy, sz, sz, '1 1 1'); for (var r = 0; r < n; r++) for (var c2 = 0; c2 < n; c2++) if (m[r][c2]) pth += (qx + (c2 + q) * s2).toFixed(2) + ' ' + (qy + sz - (r + q + 1) * s2).toFixed(2) + ' ' + s2.toFixed(2) + ' ' + s2.toFixed(2) + ' re '; ops.push('0 0 0 rg ' + pth + 'f'); return true; } catch (e) { return false; }
    }
    function placeOf() { var p = ''; try { p = w.EXBId && ID ? w.EXBId.placeLine(ID) : ''; } catch (e) {} return p || (ID && ID.address) || ''; }
    /* en-tête compact des pages de détail (2, 3, …) */
    function headPage() {
      R(0, H - 44, W, 44, NAVY); R(0, H - 47, W, 3, GOLD);
      Tx(String(BR).toUpperCase().slice(0, 40), M, H - 26, 12, true, '1 1 1'); Tx(TT + ' N° ' + d.no + (cl.name ? ' — ' + cl.name : ''), M, H - 38, 8, false, '0.95 0.82 0.40');
    }
    function detailBand(txt) {
      Tx(txt, M, y, 10, true, NAVY, null, 1); R(M + tw(txt, 10, true) + 14, y + 3, W - 2 * M - tw(txt, 10, true) - 14, 1, GOLD); y -= 16;
    }
    /* mise en page de la page de garde (calculée avant les pages de détail, pour connaître les conditions restantes) */
    var CP = null;
    function planCover() {
      var Z = {}, tt = (String(d.project || '').trim() || (kind === 'recu' ? 'REÇU DE PAIEMENT' : kind === 'facture' ? 'FACTURE DE TRAVAUX' : 'DEVIS DE TRAVAUX')).toLocaleUpperCase('fr-FR');
      var fs = 17, L = wrap(tt, 400, fs, true); while (L.length > 2 && fs > 11) { fs--; L = wrap(tt, 400, fs, true); }
      if (L.length > 3) { L = L.slice(0, 3); L[2] = L[2].slice(0, Math.max(1, L[2].length - 2)).replace(/\s+$/, '') + '…'; }
      Z.tt = L; Z.tfs = fs;
      var cr = []; wrap(cl.name || '—', 400, 12, true).forEach(function (l) { cr.push([l, true]); });
      [cl.address, cl.phone, cl.email].forEach(function (r) { if (String(r || '').trim()) wrap(r, 400, 9.5, false).forEach(function (l) { cr.push([l, false]); }); });
      Z.cr = cr.slice(0, 6); Z.rest = (o.cgv === false || kind === 'recu') ? '' : cgvText();
      return Z;
    }
    /* contour de la page de garde : même style que le certificat (filet bleu épais, filet or, bande or pâle, filet fin), agrandi */
    function coverFrame() {
      var SG = '0.93 0.88 0.72';
      RS(14, 14, W - 28, H - 28, NAVY, 9); RS(24, 24, W - 48, H - 48, GOLD, 2.4); RS(33, 33, W - 66, H - 66, SG, 9); RS(46, 46, W - 92, H - 92, GOLD, 1); RS(49, 49, W - 98, H - 98, '0.90 0.82 0.58', 0.4);
    }
    function drawCover(N) {
      ops = pages[0].ops; used = pages[0].used;
      var Z = CP, dark = '0.10 0.12 0.18', CX0 = W / 2, RX = W - 66, yy;
      coverFrame();
      /* 1. nom de l'entreprise en haut */
      var big = String(BR).toUpperCase(); Tx(big, CX0, H - 96, fitSz(big, 400, true, 25), true, NAVY, 'c', 1.5);
      if (ID && ID.tagline) { var tg = String(ID.tagline).slice(0, 80); Tx(tg, CX0, H - 112, fitSz(tg, 380, 'i', 10), 'i', GREY, 'c'); }
      R(CX0 - 70, H - 124, 140, 1.2, GOLD);
      /* 2. logo, grand, descendu */
      if (logo >= 0) { var f = fitImg(logo, 200, 160); Dm(logo, CX0 - f[0] / 2, H - 138 - f[1], f[0], f[1]); }
      /* 3. titre en grand */
      Tx(TT, CX0, H - 330, 38, true, NAVY, 'c', 8);
      var nn = 'N° ' + d.no; Tx(nn, CX0, H - 350, fitSz(nn, 360, true, 12.5), true, GOLD, 'c', 1);
      if (kind === 'devis' && d.validity) Tx('Validité : ' + (/^\d{4}-/.test(d.validity) ? frDate(d.validity) : d.validity), CX0, H - 365, 9.5, false, GREY, 'c');
      R(CX0 - 110, H - 376, 220, 1, GOLD);
      yy = H - 400; Tx(kind === 'recu' ? 'OBJET' : 'TITRE DU PROJET', CX0, yy, 8.5, true, GOLD, 'c', 2.5);
      yy -= 6; var step = Z.tfs * 1.28; yy -= Z.tfs; Z.tt.forEach(function (l, i) { Tx(l, CX0, yy - i * step, Z.tfs, true, NAVY, 'c'); }); yy -= (Z.tt.length - 1) * step;
      if (d.dossier) { yy -= 16; Tx('Dossier : ' + d.dossier, CX0, yy, 9, false, GREY, 'c'); }
      /* 4. coordonnées du client */
      yy -= 30; Tx('CLIENT', CX0, yy, 8.5, true, GOLD, 'c', 2.5); R(CX0 - 70, yy - 6, 140, 0.8, LINE);
      var lh = Math.min(15, Math.max(11, (yy - 6 - 276) / Math.max(1, Z.cr.length)));
      Z.cr.forEach(function (r, i) { Tx(r[0], CX0, yy - 22 - i * lh, r[1] ? 12 : 9.5, r[1], r[1] ? NAVY : dark, 'c'); });
      /* 5. date de délivrance + signature de l'entreprise (cachet et signature posés sur le nom) */
      var dl = 'Fait à ' + ((ID && ID.city) || '…………………') + ' — Date de délivrance : ' + frDate(d.date || today());
      var sw = 217, sx1 = RX - sw, ly = 160, vh = 0, sl = kind === 'recu' ? 'Pour ' + BR : 'Le prestataire';
      if (visa >= 0) { var fv = fitImg(visa, sw - 6, 84); vh = fv[1]; Dm(visa, sx1 + (sw - fv[0]) / 2, ly - 20, fv[0], fv[1]); }
      Tx(dl, RX, ly + (visa >= 0 ? vh - 20 : 50) + 16, 10, 'i', dark, 'r');
      R(sx1, ly, sw, 0.9, NAVY); Tx(sl, sx1 + sw / 2, ly - 12, 8.5, true, NAVY, 'c');
      var sn = String(d.signerName || '').slice(0, 40), sr = String(d.signerRole || '').slice(0, 44);
      if (sn) Tx(sn, sx1 + sw / 2, ly - 25, fitSz(sn, sw, true, 9.5), true, dark, 'c'); if (sr) Tx(sr, sx1 + sw / 2, ly - 37, 8, 'i', GREY, 'c');
    }
    /* pied de page de TOUTES les pages : filet, coordonnées, pagination et QR de vérification (sobre) */
    function footerCover(i, N) {
      if (i === 0) {
        var hq = !!(V.url && w.EXBQR), lg0 = ''; try { lg0 = ID && w.EXBId ? w.EXBId.legalLine(ID) : ''; } catch (e) {}
        var c0 = ID ? [ID.phone, ID.email].filter(Boolean).join('   ') : '', p0 = placeOf(), lx = 66;
        if (c0) Tx(c0, lx, 96, fitSz(c0, 300, false, 8), false, GREY); if (p0) Tx(p0, lx, 85, fitSz(p0, 300, false, 7.5), false, GREY); if (lg0) Tx(lg0, lx, 74, fitSz(lg0, 300, false, 6.5), false, GREY);
        var rr = hq ? W - 66 - 58 : W - 66;
        Tx(TL + ' ' + d.no + ' · Page 1 / ' + N, rr, 96, 8.5, true, NAVY, 'r'); Tx((hq ? 'Scannez pour vérifier · ' : '') + 'Code ' + V.hash.toUpperCase(), rr, 85, 7.5, false, GREY, 'r');
        if (hq) { RS(W - 66 - 50, 62, 50, 50, LINE, 0.6); qrDraw(W - 66 - 50, 62, 50); }
        return;
      }
      var FH = 74, ct = ID ? [ID.phone, ID.email].filter(Boolean).join('   ') : '', pl = placeOf(), lg = ''; try { lg = ID && w.EXBId ? w.EXBId.legalLine(ID) : ''; } catch (e) {}
      R(M, FH, W - 2 * M, 0.8, GOLD); R(0, 0, W, 5, NAVY);
      var tx = M, mx = 330;
      Tx(String(BR).slice(0, 40), tx, FH - 16, fitSz(String(BR), mx, true, 9), true, NAVY);
      if (ct) Tx(ct, tx, FH - 28, fitSz(ct, mx, false, 8), false, GREY);
      if (pl) Tx(pl, tx, FH - 38, fitSz(pl, mx, false, 7), false, GREY);
      if (lg) Tx(lg, tx, FH - 48, fitSz(lg, mx, false, 6.5), false, GREY);
      var hasQ = !!(V.url && w.EXBQR), rxp = hasQ ? W - M - 60 : W - M;
      Tx(TL + ' ' + d.no + ' · Page ' + (i + 1) + ' / ' + N, rxp, FH - 22, 8.5, true, NAVY, 'r');
      Tx((hasQ ? 'Scannez pour vérifier · ' : '') + 'Code ' + V.hash.toUpperCase(), rxp, FH - 34, 7.5, false, GREY, 'r');
      if (hasQ) { RS(W - M - 54, 10, 54, 54, LINE, 0.6); qrDraw(W - M - 54, 10, 54); }
    }
    function np() {
      ops = []; used = {}; pages.push({ ops: ops, used: used }); k = 0;
      if (cover) { headPage(); y = H - 47 - 22; } else if (pages.length === 1) {
        R(0, H - 104, W, 104, NAVY); R(0, H - 108, W, 4, GOLD); R(M, H - 92, 76, 76, '1 1 1');
        if (logo >= 0) { var f = fitImg(logo, 68, 68); Dm(logo, M + (76 - f[0]) / 2, H - 92 + (76 - f[1]) / 2, f[0], f[1]); }
        var tx = M + 90, bs = Math.max(12, Math.min(20, 330 / Math.max(1, tw(BR.toUpperCase(), 1, true))));
        Tx(BR.toUpperCase(), tx, H - 38, bs, true, '1 1 1');
        if (ID && ID.tagline) Tx(String(ID.tagline).slice(0, 60), tx, H - 54, 9, false, '0.80 0.86 0.95');
        var c2 = [ID && ID.phone, ID && ID.email].filter(Boolean).join('  |  '); if (c2) Tx(c2.slice(0, 80), tx, H - 67, 8.5, false, '0.80 0.86 0.95');
        var pl = ''; try { pl = w.EXBId ? w.EXBId.placeLine(ID) : ''; } catch (e) {} if (pl) Tx(pl.slice(0, 80), tx, H - 79, 8.5, false, '0.80 0.86 0.95');
        var lg = ''; try { lg = w.EXBId ? w.EXBId.legalLine(ID) : ''; } catch (e) {} if (lg) Tx(lg.slice(0, 95), tx, H - 91, 7, false, '0.70 0.77 0.88');
        Tx(TT, W - M, H - 36, 24, true, '1 1 1', 'r');
        Tx('N° ' + d.no, W - M, H - 54, 10.5, true, '0.95 0.82 0.40', 'r'); Tx('Date : ' + frDate(d.date), W - M, H - 68, 9, false, '0.90 0.93 0.98', 'r');
        if (kind === 'devis' && d.validity) Tx('Validité : ' + (/^\d{4}-/.test(d.validity) ? frDate(d.validity) : d.validity), W - M, H - 80, 9, false, '0.90 0.93 0.98', 'r');
        else if (d.dossier) Tx('Dossier : ' + d.dossier, W - M, H - 80, 9, false, '0.90 0.93 0.98', 'r');
        y = H - 108 - 18;
      } else {
        R(0, H - 44, W, 44, NAVY); R(0, H - 47, W, 3, GOLD); Tx(BR.toUpperCase().slice(0, 40), M, H - 26, 12, true, '1 1 1'); Tx(TL.toUpperCase() + ' N° ' + d.no + (cl.name ? ' — ' + cl.name : ''), M, H - 38, 8, false, '0.95 0.82 0.40'); y = H - 47 - 20;
      }
    }
    function ensure(h, head) { if (y - h < BOT) { np(); if (head) thead(); } }
    function box(x, ww, title, rows) {
      var lines = []; rows.forEach(function (r) { if (String(r[1] || '').trim()) wrap(r[0] + ' : ' + r[1], ww - 16, 9, false).forEach(function (l) { lines.push(l); }); });
      var hh = 26 + Math.max(1, lines.length) * 12; R(x, y - hh, ww, hh, '1 1 1'); RS(x, y - hh, ww, hh, LINE, 0.8); R(x, y - 18, ww, 18, SOFT); Tx(title, x + 8, y - 13, 9, true, NAVY);
      lines.forEach(function (l, i) { Tx(l, x + 8, y - 32 - i * 12, 9, false); }); return hh;
    }
    function thead() {
      R(M, y - 20, W - 2 * M, 20, NAVY); var lab = ['Désignation', 'Unité', 'Qté', 'PU ($)', 'Montant ($)', 'Montant (FC)'];
      lab.forEach(function (t, i) { if (i < 2) Tx(t, CX[i] + (i ? 4 : 8), y - 14, 8.5, true, '1 1 1'); else Tx(t, CX[i + 1] - 6, y - 14, 8.5, true, '1 1 1', 'r'); }); y -= 20;
    }
    if (cover) { CP = planCover(); pages.push({ ops: [], used: {} }); }
    np();
    /* client + projet */
    if (cover) detailBand(kind === 'recu' ? 'DÉTAIL DU PAIEMENT' : kind === 'facture' ? 'DÉTAIL DE LA FACTURE' : 'DÉTAIL DES POSTES'); else {
    var bw = (W - 2 * M - 14) / 2, h1, h2; var y0 = y;
    h1 = box(M, bw, 'CLIENT', [['Nom', cl.name], ['Adresse', cl.address], ['Téléphone', cl.phone], ['E-mail', cl.email]]);
    y = y0; h2 = box(M + bw + 14, bw, kind === 'devis' ? 'PROJET' : 'RÉFÉRENCES', [['Projet', d.project], ['Lieu', d.place], ['Dossier', d.dossier], ['Devis', d.devisNo && kind !== 'devis' ? d.devisNo : '']]);
    y = y0 - Math.max(h1, h2) - 18;
    Tx(d.title || (kind === 'recu' ? 'REÇU DE PAIEMENT' : kind === 'facture' ? 'DÉTAIL DE LA FACTURE' : 'RÉCAPITULATIF'), M, y, 10, true, NAVY); R(M + tw(d.title || 'RÉCAPITULATIF', 10, true) + 8, y + 3, W - 2 * M - tw(d.title || 'RÉCAPITULATIF', 10, true) - 8, 1.2, GOLD); y -= 12;
    }
    /* tableau */
    if (kind !== 'recu') {
      thead();
      (d.lines || []).forEach(function (r) {
        if (r.k === 'sec') { ensure(22, true); R(M, y - 22, W - 2 * M, 22, SOFT); RS(M, y - 22, W - 2 * M, 22, LINE); Tx(r[0], M + 8, y - 15, 9.5, true, NAVY); y -= 22; return; }
        if (r.k === 'sub') { ensure(20, true); R(M, y - 20, W - 2 * M, 20, '0.97 0.98 1'); RS(M, y - 20, W - 2 * M, 20, LINE); Tx(r[0], CX[4] - 8, y - 14, 9, true, NAVY, 'r'); Tx(nf(r[4], 2), CX[5] - 6, y - 14, 9, true, '0.1 0.12 0.18', 'r'); Tx(nf(r[5], 0), CX[6] - 6, y - 14, 9, true, '0.1 0.12 0.18', 'r'); y -= 20; return; }
        var L = wrap(r[0] || '—', CW[0] - 14, 9.5, false), hh = Math.max(22, L.length * 12 + 10); ensure(hh, true);
        R(M, y - hh, W - 2 * M, hh, k % 2 ? '0.985 0.99 1' : '1 1 1'); RS(M, y - hh, W - 2 * M, hh, LINE);
        L.forEach(function (l, j) { Tx(l, M + 8, y - 15 - j * 12, 9.5, false); }); var my = y - 15;
        Tx(r[1] || '', CX[1] + 4, my, 9, false); Tx(nf(r[2], 3).replace(/,?0+$/, ''), CX[3] - 6, my, 9.5, false, null, 'r'); Tx(nf(r[3], 2), CX[4] - 6, my, 9.5, false, null, 'r'); Tx(nf(r[4], 2), CX[5] - 6, my, 9.5, false, null, 'r'); Tx(nf(r[5], 0), CX[6] - 6, my, 9.5, false, null, 'r'); y -= hh; k++;
      });
    }
    /* totaux */
    var rows = [];
    if (kind === 'recu') {
      var p = d.paid || {}; rows.push(['MONTANT REÇU', p.usd, p.fc, 'tot']); rows.push(['Total du dossier', T.tot, T.totfc, 'n']); rows.push(['Total déjà réglé (reçus cumulés)', p.cumulUsd, p.cumulFc, 'n']); rows.push(['Reste à payer', p.resteUsd, p.resteFc, 'b']);
    } else {
      rows.push(['Sous-total', T.sub, T.subfc, 'b']); if (T.imp > 0) rows.push(['Divers & imprévus (' + (Math.round(T.imp * 10000) / 100) + ' %)', T.impv, T.impfc, 'n']);
      rows.push(['TOTAL GÉNÉRAL', T.tot, T.totfc, 'tot']);
      if (kind === 'facture' && d.acompte) { rows.push(['Acompte (' + d.acompte.pct + ' %)', d.acompte.usd, d.acompte.fc, 'n']); rows.push(['SOLDE À PAYER', T.tot - d.acompte.usd, T.totfc - d.acompte.fc, 'b']); }
    }
    ensure(rows.length * 20 + 40); y -= 6;
    rows.forEach(function (r) { var tot = r[3] === 'tot'; R(M + 200, y - 20, W - 2 * M - 200, 20, tot ? NAVY : '1 1 1'); RS(M + 200, y - 20, W - 2 * M - 200, 20, tot ? NAVY : LINE); var c = tot ? '1 1 1' : '0.1 0.12 0.18'; Tx(r[0], M + 208, y - 14, 9, r[3] !== 'n', c); Tx(nf(r[1], 2) + ' $', CX[5] - 6, y - 14, 9, r[3] !== 'n', c, 'r'); Tx(nf(r[2], 0) + ' FC', CX[6] - 6, y - 14, 9, r[3] !== 'n', c, 'r'); y -= 20; });
    if (T.taux > 0) { y -= 12; Tx('Taux de change appliqué : 1 USD = ' + nf(T.taux, 0) + ' FC', M, y, 8.5, false, GREY); }
    if (kind === 'recu' && d.paid) { y -= 14; Tx('Mode de paiement : ' + (d.paid.mode || '—') + ' — Date : ' + frDate(d.paid.date), M, y, 9, false); }
    /* note + conditions générales */
    y -= 14;
    var nl = d.note ? wrap(d.note, W - 2 * M, 9.5, false) : [], cg = (kind === 'devis' || kind === 'facture') && o.cgv !== false ? (cover && !CP.rest ? [] : wrap(cover ? CP.rest : cgvText(), W - 2 * M, 7.5, false)) : [];
    if (nl.length) { ensure(nl.length * 12 + 10); nl.forEach(function (l) { Tx(l, M, y, 9.5, false, '0.2 0.25 0.33'); y -= 12; }); y -= 8; }
    if (cg.length) { ensure(Math.min(cg.length, 6) * 9.5 + 26); Tx('CONDITIONS GÉNÉRALES', M, y, 8.5, true, NAVY); R(M + 110, y + 3, W - 2 * M - 110, 1, GOLD); y -= 12; cg.forEach(function (l) { ensure(10); Tx(l, M, y, 7.5, false, GREY); y -= 9.5; }); y -= 8; }
    /* signatures + QR */
    if (!cover) {
    ensure(165); y -= 6;
    Tx('Fait à ' + ((ID && ID.city) || '…………………………') + ', le ' + frDate(d.date || today()), M, y, 9.5, false, GREY); y -= 8;
    var sl = kind === 'devis' ? ['Le prestataire', 'Le client — « Bon pour accord »'] : kind === 'facture' ? ['Le prestataire', 'Le client'] : ['Pour ' + BR, 'Le client'], sw = 160;
    var sn = [[d.signerName, d.signerRole], [d.clientSigner || cl.name, '']];
    [[sl[0], visa, M, 0], [sl[1], csig, M + sw + 18, 1]].forEach(function (c) { if (c[1] >= 0) { var f = fitImg(c[1], sw - 16, 74); Dm(c[1], c[2] + (sw - f[0]) / 2, y - (c[3] === 0 ? 108 : 88), f[0], f[1]); } R(c[2], y - 92, sw, 0.8, '0.5 0.55 0.62'); Tx(c[0], c[2] + sw / 2, y - 104, 8.5, true, NAVY, 'c'); var nm = sn[c[3]]; if (nm[0]) Tx(String(nm[0]).slice(0, 38), c[2] + sw / 2, y - 117, 9.5, true, '0.10 0.12 0.18', 'c'); if (nm[1]) Tx(String(nm[1]).slice(0, 44), c[2] + sw / 2, y - 129, 8, false, GREY, 'c'); });
    if (V.url && w.EXBQR) { try { var m = w.EXBQR.matrix(V.url), n = m.length, q = 2, t = n + 2 * q, sz = 96, s = sz / t, qx = W - M - sz, qy = y - 98, pth = ''; R(qx, qy, sz, sz, '1 1 1'); for (var r = 0; r < n; r++) for (var c2 = 0; c2 < n; c2++) if (m[r][c2]) pth += (qx + (c2 + q) * s).toFixed(2) + ' ' + (qy + sz - (r + q + 1) * s).toFixed(2) + ' ' + s.toFixed(2) + ' ' + s.toFixed(2) + ' re '; ops.push('0 0 0 rg ' + pth + 'f'); RS(qx, qy, sz, sz, LINE, 0.6); Tx('Scannez pour vérifier', qx + sz / 2, qy - 10, 7.5, true, NAVY, 'c'); Tx('Code ' + V.hash.toUpperCase(), qx + sz / 2, qy - 20, 7, false, GREY, 'c'); } catch (e) {} }
    y -= 138;
    }
    if (cover) drawCover(pages.length);
    /* pieds de page + filigrane */
    var N = pages.length; pages.forEach(function (p, i) {
      ops = p.ops; used = p.used; if (cover) footerCover(i, N); else { R(0, 0, W, 6, NAVY); R(M, 52, W - 2 * M, 0.8, LINE);
      var ct = ID ? [ID.phone, ID.email].filter(Boolean).join(' — ') : '', f2 = ''; try { f2 = ID && w.EXBId ? [w.EXBId.placeLine(ID), w.EXBId.legalLine(ID)].filter(Boolean).join('  |  ') : ''; } catch (e) {}
      Tx((BR + (ct ? ' — ' + ct : '')).slice(0, 92), M, 38, 8.5, false, GREY); if (f2) Tx(f2.slice(0, 125), M, 26, 7, false, GREY); Tx(TL + ' ' + d.no + ' · Page ' + (i + 1) + ' / ' + N, W - M, 36, 8.5, true, NAVY, 'r'); }
      if (wm) { var sz2 = wm.length > 7 ? 84 : 100, ww = tw(wm, sz2, true), cs = 0.7071; ops.push('q /GS1 gs 0.80 0.10 0.10 rg BT /F2 ' + sz2 + ' Tf ' + cs + ' ' + cs + ' ' + (-cs) + ' ' + cs + ' ' + (W / 2 - ww / 2 * cs - sz2 * 0.15).toFixed(1) + ' ' + (H / 2 - ww / 2 * cs - sz2 * 0.15).toFixed(1) + ' Tm (' + pe(wm) + ') Tj ET Q'); }
    });
    /* assemblage PDF */
    var ch = [], pos = 0, off = [], NO = 7 + IM.length + 2 * pages.length;
    function P(x) { var u = typeof x === 'string' ? bytes(x) : x; ch.push(u); pos += u.length; }
    function O(n, head, stream) { off[n] = pos; P(n + ' 0 obj\n' + head); if (stream) { P('\nstream\n'); P(stream); P('\nendstream'); } P('\nendobj\n'); }
    P('%PDF-1.4\n'); O(1, '<< /Type /Catalog /Pages 2 0 R /ViewerPreferences << /PrintScaling /None >> >>');
    var pb = 8 + IM.length, kids = pages.map(function (p, i) { return (pb + 2 * i) + ' 0 R'; }); O(2, '<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + pages.length + ' >>');
    O(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'); O(4, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    O(5, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>'); O(6, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique /Encoding /WinAnsiEncoding >>'); O(7, '<< /Type /ExtGState /ca 0.14 /CA 0.14 >>');
    IM.forEach(function (m, i) { O(8 + i, '<< /Type /XObject /Subtype /Image /Width ' + m.w + ' /Height ' + m.h + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + m.u.length + ' >>', m.u); });
    pages.forEach(function (p, i) { var n = pb + 2 * i, xo = Object.keys(p.used).map(function (q) { return '/I' + q + ' ' + (8 + Number(q)) + ' 0 R'; }).join(' '), c = bytes('q 0.94 0 0 0.94 17.85 25.26 cm\n' + p.ops.join('\n') + '\nQ');
      O(n, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + W + ' ' + H + '] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R >> /ExtGState << /GS1 7 0 R >> /XObject << ' + xo + ' >> >> /Contents ' + (n + 1) + ' 0 R >>'); O(n + 1, '<< /Length ' + c.length + ' >>', c); });
    var xr = pos, x = 'xref\n0 ' + (NO + 1) + '\n0000000000 65535 f \n'; for (var j = 1; j <= NO; j++) x += ('0000000000' + off[j]).slice(-10) + ' 00000 n \n';
    P(x + 'trailer\n<< /Size ' + (NO + 1) + ' /Root 1 0 R >>\nstartxref\n' + xr + '\n%%EOF');
    if (o.record !== false && kind === 'devis') track(d.no, { kind: 'devis', dossier: d.dossier || dossierOf(d.no), date: d.date, total: kind === 'devis' ? total : undefined, cur: cur, hash: V.hash, client: cl.name, phone: cl.phone, email: cl.email, due: dueISO(d.date, d.validity) });
    if (o.record !== false) publish({ no: d.no, kind: kind, hash: V.hash, date: d.date, total: kind === 'recu' && d.paid ? (/^(CDF|FC)$/i.test(cur) ? d.paid.fc : d.paid.usd) : total, cur: cur, status: d.status || '', nom: (cl && cl.name) || '', libelle: d.project || '' });
    return { blob: new Blob(ch, { type: 'application/pdf' }), hash: V.hash, url: V.url, pages: N };
  }

  /* ---------- envoi ---------- */
  function save(blob, name) { if (w.EXBPdf && w.EXBPdf.save) return w.EXBPdf.save(blob, name); var u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = name; a.style.display = 'none'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(u); a.remove(); }, 4000); }
  function say(m, t, ms) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', ms || 4000); } catch (e) {} try { alert(m); } catch (e) {} }
  async function send(blob, name, mode, c) {
    var BR = 'Excellencia Building'; try { BR = w.EXBId.get().name || BR; } catch (e) {}
    var msg = 'Bonjour' + (c.client ? ' ' + c.client : '') + ', veuillez trouver ci-joint ' + (c.label || 'votre document') + ' N° ' + c.no + (c.total ? ' (' + c.total + ')' : '') + '. — ' + BR;
    var file = null; try { file = new File([blob], name, { type: 'application/pdf' }); } catch (e) {}
    if (mode === 'share' && file && navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], title: name, text: msg }); return 'shared'; } catch (e) { if (e && e.name === 'AbortError') return 'cancel'; } }
    save(blob, name);
    if (mode === 'mail') { w.open('mailto:' + encodeURIComponent(c.email || '') + '?subject=' + encodeURIComponent((c.label || 'Document') + ' N° ' + c.no) + '&body=' + encodeURIComponent(msg + '\n\n(Le PDF vient d’être téléchargé : joignez-le à ce message.)'), '_blank'); return 'mail'; }
    w.open('https://wa.me/' + digits(c.phone) + '?text=' + encodeURIComponent(msg + '\n(Le PDF vient d’être téléchargé : joignez-le dans la conversation.)'), '_blank'); return 'wa';
  }

  /* ---------- interface : fiche d'actions d'un devis ---------- */
  function el(tag, css, html) { var e = document.createElement(tag); if (css) e.style.cssText = css; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function overlay() { var o = el('div', 'position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:99999;display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px'); o.id = 'exbdocs_ov'; var old = document.getElementById('exbdocs_ov'); if (old) old.remove(); document.body.appendChild(o); return o; }
  var BT = 'border:0;border-radius:10px;padding:11px 12px;font-size:14px;font-weight:600;cursor:pointer;', B1 = BT + 'background:#173565;color:#fff;', B2 = BT + 'background:#e8edf5;color:#173565;', B3 = BT + 'background:#c9a227;color:#fff;';
  function pad(cv, init) {
    var cx = cv.getContext('2d'), dr = false, has = !!init; cx.lineWidth = 2.4; cx.lineCap = 'round'; cx.strokeStyle = '#0b1b3a';
    if (init) { var im = new Image(); im.onload = function () { cx.drawImage(im, 0, 0, cv.width, cv.height); }; im.src = init; }
    function pt(e) { var r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; }
    cv.style.touchAction = 'none';
    cv.addEventListener('pointerdown', function (e) { dr = true; has = true; var p = pt(e); cx.beginPath(); cx.moveTo(p[0], p[1]); cv.setPointerCapture(e.pointerId); e.preventDefault(); });
    cv.addEventListener('pointermove', function (e) { if (!dr) return; var p = pt(e); cx.lineTo(p[0], p[1]); cx.stroke(); e.preventDefault(); });
    ['pointerup', 'pointercancel'].forEach(function (n) { cv.addEventListener(n, function () { dr = false; }); });
    return { clear: function () { cx.clearRect(0, 0, cv.width, cv.height); has = false; }, data: function () { return has ? cv.toDataURL('image/png') : ''; } };
  }
  /* c = {no, getDoc: async()=>doc, client, phone, email, label} */
  function open(c) {
    var rec = track(c.no, {}) || {}, o = overlay(), card = el('div', 'background:#fff;border-radius:14px;max-width:520px;width:100%;padding:14px;font-family:Arial,sans-serif;color:#172033'); o.appendChild(card);
    function paint() {
      rec = getRec(c.no) || rec; var tot = rec.total ? nf(rec.total, 2) + ' ' + (rec.cur || '') : '', st = effStatus(rec), pay = rec.payments || [], paid = pay.reduce(function (a, p) { return a + (p.usd || 0); }, 0);
      card.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px;color:#173565">Suivi et envoi — ' + esc(c.no) + '</b><button id="dx" style="' + B2 + '">✕</button></div>' +
        '<div style="color:#64748b;font-size:13px;margin:4px 0 10px">' + esc(c.client || '') + (tot ? ' · ' + esc(tot) : '') + (rec.due ? ' · valable jusqu’au ' + frDate(rec.due) : '') + '</div>' +
        '<div style="font-weight:700;margin:6px 0">Statut' + (st === 'expiré' ? ' <span style="color:#b91c1c">— expiré</span>' : '') + '</div><div id="stt" style="display:flex;flex-wrap:wrap;gap:6px"></div>' +
        '<div style="display:flex;gap:8px;margin:10px 0;align-items:center"><label style="font-size:13px;flex:1">Valable jusqu’au<br><input id="dd" type="date" value="' + esc(rec.due || '') + '" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></label><label style="font-size:13px;flex:1">Acompte (%)<br><input id="ac" type="number" min="0" max="100" value="' + esc(rec.acPct == null ? 50 : rec.acPct) + '" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></label></div>' +
        '<div style="font-weight:700;margin:10px 0 4px">Noms affichés sous les signatures</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><label style="font-size:13px">Prestataire (nom)<br><input id="pn" value="' + esc(signer().name) + '" placeholder="Nom du signataire" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></label><label style="font-size:13px">Fonction<br><input id="pf" value="' + esc(signer().role) + '" placeholder="ex. Directeur Général" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></label></div><label style="font-size:13px;display:block;margin-top:6px">Client (nom du signataire)<br><input id="cn" value="' + esc(rec.clientSigner || c.client || '') + '" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></label>' +
        '<div style="font-weight:700;margin:10px 0 6px">Signature du client (au doigt)</div><canvas id="sg" width="600" height="220" style="width:100%;height:110px;border:1px dashed #94a3b8;border-radius:8px;background:#fff"></canvas><div style="display:flex;gap:6px;margin:6px 0"><button id="sgc" style="' + B2 + 'flex:1">Effacer</button><button id="sgs" style="' + B2 + 'flex:1">Enregistrer la signature</button></div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><button id="bpdf" style="' + B1 + '">📄 PDF du devis</button><button id="bsh" style="' + B1 + '">📲 Envoyer le PDF</button><button id="bwa" style="' + B2 + '">WhatsApp</button><button id="bml" style="' + B2 + '">✉️ E-mail</button><button id="bfa" style="' + B3 + '">🧾 Facture</button><button id="bre" style="' + B3 + '">💰 Reçu</button></div>' +
        '<div style="display:flex;gap:8px;margin-top:10px;align-items:center"><label style="font-size:13px;flex:1">Montant reçu ($)<br><input id="rm" type="number" step="any" placeholder="ex. ' + (rec.total ? nf(rec.total * 0.5, 2).replace(',', '.').replace(/\s/g, '') : '0') + '" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"></label><label style="font-size:13px;flex:1">Mode<br><select id="rmd" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px"><option>Espèces</option><option>Mobile money</option><option>Virement</option><option>Chèque</option></select></label></div>' +
        (pay.length ? '<div style="font-size:12px;color:#475569;margin-top:6px">Reçus émis : ' + pay.map(function (p) { return esc(p.no) + ' (' + nf(p.usd, 2) + ' $)'; }).join(', ') + ' — total réglé ' + nf(paid, 2) + ' $</div>' : '') +
        '<div style="margin-top:10px"><button id="bcg" style="' + B2 + 'width:100%">📝 Conditions générales (clauses types)</button><div id="cgw"></div></div>' +
        (rec.history && rec.history.length ? '<div style="font-size:11px;color:#64748b;margin-top:8px">Historique : ' + rec.history.map(function (h) { return esc(h.s) + ' ' + frDate(h.d); }).join(' → ') + '</div>' : '');
      var stt = card.querySelector('#stt'); STATUTS.forEach(function (s) { var on = (rec.status || '') === s[0], b = el('button', BT + (on ? 'background:#173565;color:#fff;' : 'background:#e8edf5;color:#173565;') + 'padding:8px 10px;font-size:13px', s[1]); b.onclick = function () { setStatus(c.no, s[0]); paint(); }; stt.appendChild(b); });
      var sp = pad(card.querySelector('#sg'), rec.sig || ''), $ = function (i) { return card.querySelector('#' + i); };
      $('dx').onclick = function () { o.remove(); }; $('sgc').onclick = function () { sp.clear(); track(c.no, { sig: '' }); };
      $('sgs').onclick = function () { var d = sp.data(); track(c.no, { sig: d }); say(d ? 'Signature du client enregistrée.' : 'Aucune signature à enregistrer.', d ? 'success' : 'warn'); };
      $('pn').onchange = $('pf').onchange = function () { setSigner($('pn').value, $('pf').value); }; $('cn').onchange = function () { track(c.no, { clientSigner: this.value.trim() }); };
      $('dd').onchange = function () { track(c.no, { due: this.value }); }; $('ac').onchange = function () { track(c.no, { acPct: Math.max(0, Math.min(100, Number(this.value) || 0)) }); };
      async function mk(kind, extra) { var d = await c.getDoc(); var r = getRec(c.no) || {}; d.kind = kind; d.dossier = dossierOf(c.no); d.devisNo = c.no; d.clientSig = sp.data() || r.sig || ''; d.signerName = $('pn').value.trim(); d.signerRole = $('pf').value.trim(); d.clientSigner = $('cn').value.trim(); setSigner(d.signerName, d.signerRole); track(c.no, { clientSigner: d.clientSigner }); if (r.due && kind === 'devis') d.validity = r.due; if (kind === 'devis') d.status = r.status; else d.status = ''; Object.keys(extra || {}).forEach(function (k) { d[k] = extra[k]; }); return d; }
      async function doPdf(kind, extra, no, status) { try { var d = await mk(kind, extra); if (no) d.no = no; if (status !== undefined) d.status = status; var r = await build(d, { record: kind === 'devis' }); return { blob: r.blob, name: { devis: 'devis-', facture: 'facture-', recu: 'recu-' }[kind] + d.no + '.pdf', d: d }; } catch (e) { say('Échec : ' + (e && e.message || e), 'error', 7000); console.error(e); return null; } }
      function ready() { var r = getRec(c.no) || {}; if (!r.status || r.status === 'brouillon') { setStatus(c.no, 'envoyé'); } }
      var lab = { label: c.label || 'votre devis', no: c.no, client: c.client, phone: c.phone || rec.phone, email: c.email || rec.email, total: tot };
      $('bpdf').onclick = async function () { var r = await doPdf('devis'); if (r) { save(r.blob, r.name); say('PDF généré : ' + r.name, 'success'); } };
      [['bsh', 'share'], ['bwa', 'wa'], ['bml', 'mail']].forEach(function (b) { $(b[0]).onclick = async function () { ready(); var r = await doPdf('devis', {}, null, ''); if (!r) return; var s = await send(r.blob, r.name, b[1], lab); if (s !== 'cancel') { paint(); } }; });
      $('bfa').onclick = async function () { var pct = Math.max(0, Math.min(100, Number($('ac').value) || 0)); track(c.no, { acPct: pct }); var d0 = await c.getDoc(), T = d0.T || {}; var r = await doPdf('facture', { acompte: { pct: pct, usd: (T.tot || 0) * pct / 100, fc: (T.totfc || 0) * pct / 100 }, title: 'DÉTAIL DE LA FACTURE' }, 'FAC-' + dossierOf(c.no), ''); if (!r) return; track('FAC-' + dossierOf(c.no), { kind: 'facture', dossier: dossierOf(c.no), date: r.d.date, total: (T.tot || 0), cur: 'USD', client: c.client, status: 'envoyé' }); setStatus(c.no, 'accepté'); await send(r.blob, r.name, 'share', Object.assign({}, lab, { label: 'votre facture', no: 'FAC-' + dossierOf(c.no) })); paint(); };
      $('bre').onclick = async function () { var amt = Number($('rm').value); if (!(amt > 0)) { say('Saisissez le montant reçu.', 'warn'); return; } var d0 = await c.getDoc(), T = d0.T || {}, taux = T.taux || 0, r0 = getRec(c.no) || {}, pays = (r0.payments || []).slice(), no = 'REC-' + dossierOf(c.no) + '-' + (pays.length + 1), cum = pays.reduce(function (a, p) { return a + p.usd; }, 0) + amt, mode = $('rmd').value;
        var paidObj = { usd: amt, fc: taux ? amt * taux : 0, mode: mode, date: today(), cumulUsd: cum, cumulFc: taux ? cum * taux : 0, resteUsd: Math.max(0, (T.tot || 0) - cum), resteFc: taux ? Math.max(0, (T.tot || 0) - cum) * taux : 0 };
        var r = await doPdf('recu', { paid: paidObj, title: 'REÇU DE PAIEMENT', date: today() }, no, ''); if (!r) return; pays.push({ no: no, usd: amt, mode: mode, date: today() }); track(c.no, { payments: pays }); await send(r.blob, r.name, 'share', Object.assign({}, lab, { label: 'votre reçu', no: no, total: nf(amt, 2) + ' $' })); paint(); };
      $('bcg').onclick = function () { var w2 = $('cgw'); if (w2.firstChild) { w2.innerHTML = ''; return; } var ta = el('textarea', 'width:100%;height:180px;margin-top:6px;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font-size:12px'); ta.value = cgvText(); var sv = el('button', B1 + 'width:100%;margin-top:6px', 'Enregistrer ces clauses'); sv.onclick = function () { setCgv(ta.value); say('Clauses enregistrées.', 'success'); w2.innerHTML = ''; }; w2.appendChild(ta); w2.appendChild(sv); };
    }
    paint();
  }

  /* ---------- suivi global + rappels ---------- */
  function reminderMsg(r) { var BR = 'Excellencia Building'; try { BR = w.EXBId.get().name || BR; } catch (e) {} return 'Bonjour' + (r.client ? ' ' + r.client : '') + ', votre devis N° ' + r.no + (r.total ? ' de ' + nf(r.total, 2) + ' ' + (r.cur || '') : '') + ' reste valable jusqu’au ' + frDate(r.due) + '. Souhaitez-vous le valider ? — ' + BR; }
  function dueList(days) { var lim = new Date(); lim.setDate(lim.getDate() + (days == null ? 3 : days)); var l = lim.toISOString().slice(0, 10), d = db(); return Object.keys(d.docs).map(function (k) { return d.docs[k]; }).filter(function (r) { return r.kind === 'devis' && r.status === 'envoyé' && r.due && r.due <= l; }); }
  function checkDue() { try { var l = dueList(3), d = db(); if (!l.length || d.lastAlert === today()) return l.length; d.lastAlert = today(); put(d); say('⏰ ' + l.length + ' devis envoyé' + (l.length > 1 ? 's arrivent' : ' arrive') + ' à échéance ou ' + (l.length > 1 ? 'sont expirés' : 'est expiré') + ' — ouvrez « Suivi des devis ».', 'warn', 9000); return l.length; } catch (e) { return 0; } }
  function suivi() {
    var o = overlay(), card = el('div', 'background:#fff;border-radius:14px;max-width:560px;width:100%;padding:14px;font-family:Arial,sans-serif;color:#172033'); o.appendChild(card);
    var L = Object.keys(db().docs).map(function (k) { return db().docs[k]; }).filter(function (r) { return r.kind === 'devis'; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    card.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px;color:#173565">Suivi des devis</b><button id="sx" style="' + B2 + '">✕</button></div>' + (L.length ? '' : '<p style="color:#64748b">Aucun devis suivi pour l’instant. Ouvrez « Suivi / envoi » sur un devis, ou exportez-le en PDF.</p>');
    L.forEach(function (r) {
      var st = effStatus(r), col = { 'brouillon': '#64748b', 'envoyé': '#1d4ed8', 'accepté': '#15803d', 'refusé': '#b91c1c', 'annulé': '#b91c1c', 'expiré': '#b45309' }[st] || '#64748b', row = el('div', 'border:1px solid #e2e8f0;border-radius:10px;padding:9px;margin-top:8px');
      row.innerHTML = '<div style="display:flex;justify-content:space-between"><b>' + esc(r.no) + '</b><span style="color:' + col + ';font-weight:700">' + esc(st || 'non défini') + '</span></div><div style="font-size:12px;color:#64748b">' + esc(r.client || '') + ' · ' + nf(r.total, 2) + ' ' + esc(r.cur || '') + (r.due ? ' · échéance ' + frDate(r.due) : '') + '</div>';
      if (r.status === 'envoyé' && r.phone) { var b = el('button', B2 + 'margin-top:6px;padding:7px 10px;font-size:13px', '⏰ Relancer sur WhatsApp'); b.onclick = function () { w.open('https://wa.me/' + digits(r.phone) + '?text=' + encodeURIComponent(reminderMsg(r)), '_blank'); }; row.appendChild(b); }
      card.appendChild(row);
    });
    card.querySelector('#sx').onclick = function () { o.remove(); };
  }

  /* ---------- page de vérification (scan du QR) ---------- */
  function showVerify(code) {
    if (w.EXBVerif && w.EXBVerif.show) return w.EXBVerif.show(code, getRec);
    var p = String(code || '').split('~'); if (p.length < 6) return; var K = { d: 'Devis', f: 'Facture', r: 'Reçu' }[p[0]] || 'Document', rec = getRec(p[1]), o = overlay(), card = el('div', 'background:#fff;border-radius:14px;max-width:460px;width:100%;padding:18px;font-family:Arial,sans-serif;color:#172033;margin-top:30px'); o.appendChild(card);
    var verdict = rec && rec.hash ? (rec.hash === p[5] ? '<div style="background:#dcfce7;color:#166534;padding:10px;border-radius:10px;font-weight:700">✅ Document authentique — enregistré dans le registre de l’émetteur.</div>' : '<div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:10px;font-weight:700">⚠️ Les données ne correspondent pas au registre : document modifié ou erroné.</div>') : '<div id="vr" style="background:#fef9c3;color:#854d0e;padding:10px;border-radius:10px">Vérification en ligne en cours…</div>';
    card.innerHTML = '<b style="font-size:17px;color:#173565">Vérification de document</b><div style="margin:12px 0">' + verdict + '</div><table style="width:100%;font-size:14px;border-collapse:collapse">' + [[K, p[1]], ['Date', frDate(p[2])], ['Montant', nf(p[3], 2) + ' ' + p[4]], ['Code', p[5].toUpperCase()]].map(function (r) { return '<tr><td style="padding:5px;color:#64748b">' + r[0] + '</td><td style="padding:5px;font-weight:700">' + esc(r[1]) + '</td></tr>'; }).join('') + '</table><button id="vx" style="' + B1 + 'width:100%;margin-top:14px">Fermer</button>';
    card.querySelector('#vx').onclick = function () { o.remove(); try { history.replaceState(null, '', location.href.split('#')[0]); } catch (e) {} };
    if (!(rec && rec.hash)) lookup(p[1], p[5]).then(function (r) { var v = card.querySelector('#vr'); if (!v) return; var G = 'background:#dcfce7;color:#166534;padding:10px;border-radius:10px;font-weight:700', Rd = 'background:#fee2e2;color:#991b1b;padding:10px;border-radius:10px;font-weight:700';
      if (r && r.found && r.status === 'annulé') { v.style.cssText = Rd; v.textContent = '⚠️ Document enregistré mais ANNULÉ par l’émetteur.'; } else if (r && r.found) { v.style.cssText = G; v.textContent = '✅ Document authentique — enregistré par l’émetteur.'; } else if (r) { v.style.cssText = Rd; v.textContent = '⚠️ Aucun enregistrement correspondant : document non reconnu ou modifié.'; } else { v.textContent = 'Vérification en ligne indisponible. Comparez les informations ci-dessous avec votre document papier.'; } });
  }
  function sb() { var c = w.EXB_SUPABASE; return c && c.url && c.key ? c : null; }
  /* Publication du registre en ligne (facultatif) : uniquement si l'administrateur est connecté (exbSb) — voir supabase/migration-v99l-documents.sql */
  async function publish(r) { try { if (!w.exbSb || !w.exbSb.isIn || !w.exbSb.isIn() || !navigator.onLine || !r || !r.hash) return false; await w.exbSb.api('/rest/v1/rpc/exb_doc_publish', { method: 'POST', body: JSON.stringify({ p_no: r.no, p_kind: r.kind, p_hash: r.hash, p_date: r.date || null, p_total: Number(r.total) || 0, p_cur: r.cur || '', p_status: r.status || '' }) }); return true; } catch (e) { return false; } }
  async function lookup(no, hash) { var c = sb(); if (!c || !navigator.onLine) return null; try { var r = await fetch(c.url + '/rest/v1/rpc/exb_doc_verify', { method: 'POST', headers: { apikey: c.key, Authorization: 'Bearer ' + c.key, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_no: no, p_hash: hash }) }); if (!r.ok) return null; var j = await r.json(); return j && typeof j === 'object' ? j : null; } catch (e) { return null; } }
  function route() { var m = /^#verify=(.+)$/.exec(location.hash || ''); if (m) { try { showVerify(decodeURIComponent(m[1])); } catch (e) {} } }
  if (typeof window !== 'undefined' && typeof document !== 'undefined') { window.addEventListener('hashchange', route); window.addEventListener('load', function () { setTimeout(route, 400); setTimeout(checkDue, 2500); }); setInterval(checkDue, 6 * 3600 * 1000); }

  var _op = publish; publish = async function (r) { var ok = await _op(r); try { if (w.EXBVerif && r) { var g = getRec(r.no) || {}; await w.EXBVerif.publish({ no: r.no, kind: r.kind, hash: r.hash, date: r.date, total: r.total, cur: r.cur, status: r.status, nom: r.nom || g.client || '', libelle: r.libelle || '' }); } } catch (e) {} return ok; };
  w.EXBDocs = { build: build, open: open, suivi: suivi, checkDue: checkDue, track: track, get: getRec, setStatus: setStatus, dossierOf: dossierOf, dueISO: dueISO, nf: nf, cgv: cgvText, setCgv: setCgv, signer: signer, setSigner: setSigner, send: send, save: save, showVerify: showVerify };
})(typeof window !== 'undefined' ? window : globalThis);
