# Éditeur de plan — « Mes plans », titre du projet, saisie immédiate (reporté sur V101)

La V101 contient déjà le PDF direct (exbMakePdf) et le bouton « 💾 Enregistrer » : ils sont conservés, sans doublon.

## Ajouts
- **📂 Mes plans** (en-tête et menu Fichier) : liste des plans enregistrés sur l'appareil (nom, date, niveaux, murs) avec Ouvrir / Supprimer / Nouveau plan. Avant : liste cachée dans un menu, tous les plans nommés « Plan sans titre », et l'éditeur rouvrait toujours le dernier plan modifié sans moyen évident d'en choisir un autre.
- **💾 Enregistrer** : demande un nom au premier enregistrement (si le plan s'appelle « Plan sans titre »), reprend ce nom comme titre du projet s'il est vide, puis garde le comportement V101 (enregistrement + copie .json).
- **Titre du projet** : fenêtre proposée avant l'export PDF/impression si le projet n'a pas de titre (bouton « Passer ») ; entrée « 📋 Titre du projet… » dans Fichier ; les champs du cartouche s'enregistrent à chaque frappe (et plus seulement à la sortie du champ).
- Les exports de l'éditeur (JSON, PNG, CSV…) utilisent le téléchargement natif de l'application quand il existe (Android / Windows).
