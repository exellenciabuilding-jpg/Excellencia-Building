# Liens publics dans l'APK et Windows (reporté sur la fusion V101)

Adresse publique unique : `window.EXB_PUBLIC_URL` dans `brand-config.js` (fonctions `exbOrigin()` / `exbBase()`).
Dans l'APK (`https://localhost`) et sous Windows (`app://excellencia`), elle remplace l'adresse interne. Sur le site en ligne, rien ne change.

## Corrigé dans cette livraison
- `exb-tfl.js` (`baseSite`) : liens candidature, portails étudiant/encadreur, statut, contribution, sujets, formulaire encadreur. APK : donnait `https://localhost/…` ; Windows : aucun lien.
- `exb-docs.js` (`baseUrl`) et `exb-v74-facility.js` (`linkFor`) : liens des QR sans adresse fixe.
- `exb-generator.html` (`here`) : adresse pré-remplie du logiciel.
- `sw.js` : nouvelle version de cache.

## Déjà corrects (inchangés)
inscription, apprenant, formateur, client, personnel, btp, demande-tp-td, logiciel, exb-btp, exb-equipe, exb-license, exb-proprietaire, exb-v99zy-portails, exb-epreuve-qr, exb-verif (`base()`).
