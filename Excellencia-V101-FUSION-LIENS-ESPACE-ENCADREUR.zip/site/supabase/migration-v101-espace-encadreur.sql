-- V101 — Espace encadreur : proposer un sujet, demander la modification ou le retrait d'un sujet, depuis le portail.
-- À exécuter UNE FOIS dans Supabase › SQL Editor (réexécutable). Après : migration-v99zzt-tfl-portails.sql, migration-v99zzzzzzzzzzzzzz-tfl-matricule-suivi.sql, migration-v99zzzzzzzzzzzzzz-LOT8-demandes.sql.
-- Ne modifie aucune table existante : les propositions arrivent dans « Récupérer les formulaires en ligne » et les demandes dans « Récupérer les demandes » (écrans TFL › Encadreurs déjà en service).

-- 1) Proposer un nouveau sujet (identifiant + mot de passe de l'encadreur obligatoires)
create or replace function public.tfl_espace_sujet_proposer(p_ident text, p_mdp text, p_sujet jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  c record; a public.tfl_acces; v_titre text; v_pb text; v_ob text; v_tel text; v_clean jsonb; v_data jsonb; v_id uuid; v_max int;
begin
  select * into c from public.tfl_acces_check('encadreur', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if jsonb_typeof(p_sujet) is distinct from 'object' then return jsonb_build_object('ok', false, 'code', 'saisie'); end if;
  v_titre := left(btrim(coalesce(p_sujet->>'titre','')), 250);
  v_pb := left(btrim(coalesce(p_sujet->>'problematique','')), 3000);
  v_ob := left(btrim(coalesce(p_sujet->>'objectifs','')), 3000);
  if length(v_titre) < 3 or length(v_pb) < 3 or length(v_ob) < 3 then return jsonb_build_object('ok', false, 'code', 'saisie'); end if;
  v_tel := left(btrim(coalesce(a.contenu->>'telephone','')), 40);
  if v_tel !~ '[0-9]{6,}' then return jsonb_build_object('ok', false, 'code', 'telephone'); end if;
  if exists (select 1 from jsonb_array_elements(coalesce(a.contenu->'propositions','[]'::jsonb)) x where lower(btrim(x->>'titre')) = lower(v_titre))
     or exists (select 1 from public.tfl_encadreurs_envois e where e.data->>'portail_ident' = a.identifiant and not e.imported and lower(btrim(e.data->'sujets'->0->>'titre')) = lower(v_titre))
  then return jsonb_build_object('ok', false, 'code', 'doublon'); end if;
  if (select count(*) from public.tfl_encadreurs_envois where data->>'portail_ident' = a.identifiant and created_at > now() - interval '1 hour') >= 10 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  v_max := least(30, greatest(1, coalesce(nullif(regexp_replace(coalesce(a.contenu->>'max_etudiants',''), '\D', '', 'g'), '')::int, 8)));
  v_clean := jsonb_build_object('titre', v_titre, 'problematique', v_pb, 'objectifs', v_ob,
    'methodologie', left(coalesce(p_sujet->>'methodologie',''), 3000), 'livrables', left(coalesce(p_sujet->>'livrables',''), 500),
    'domaine', case when p_sujet->>'domaine' in ('genie_civil','architecture','gestion_travaux','autre') then p_sujet->>'domaine' else 'autre' end,
    'categorie', '', 'filiere', '', 'niveau', '', 'mots_cles', left(coalesce(p_sujet->>'mots_cles',''), 200));
  v_data := jsonb_build_object('nom', left(a.nom, 120), 'telephone', v_tel, 'email', left(coalesce(a.contenu->>'email',''), 120),
    'max_etudiants', v_max, 'domaines', '[]'::jsonb, 'sujets', jsonb_build_array(v_clean), 'portail_ident', a.identifiant);
  insert into public.tfl_encadreurs_envois(submitted_at, ref, data) values (now(), 'PORTAIL', v_data) returning id into v_id;
  update public.tfl_statuts set updated_at = now(), items = items || jsonb_build_array(jsonb_build_object(
      'ref', 'S-' || left(v_id::text, 8) || '-1', 'titre', v_titre, 'statut', 'recu', 'label', 'Reçu — en cours d’étude', 'motif', '', 'encadreur', '', 'validation', '', 'maj', to_char(now(), 'YYYY-MM-DD')))
   where role = 'encadreur' and right(tel_norm, 6) = right(regexp_replace(v_tel, '\D', '', 'g'), 6);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_espace_sujet_proposer(text, text, jsonb) from public;
grant execute on function public.tfl_espace_sujet_proposer(text, text, jsonb) to anon, authenticated;

-- 2) Demander la modification ou le retrait d'un de SES sujets
create or replace function public.tfl_espace_sujet_demande(p_ident text, p_mdp text, p_ref text, p_type text, p_texte text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  c record; a public.tfl_acces; v_ref text := left(btrim(coalesce(p_ref,'')), 60); v_titre text; v_txt text := left(btrim(coalesce(p_texte,'')), 600);
begin
  select * into c from public.tfl_acces_check('encadreur', p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then return jsonb_build_object('ok', false, 'code', 'changer'); end if;
  select * into a from public.tfl_acces where id = c.v_id;
  if p_type not in ('modifier','retirer') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  select x->>'titre' into v_titre from jsonb_array_elements(coalesce(a.contenu->'propositions','[]'::jsonb)) x where x->>'ref' = v_ref limit 1;
  if v_titre is null then return jsonb_build_object('ok', false, 'code', 'ref'); end if;
  if p_type = 'modifier' and length(v_txt) < 3 then return jsonb_build_object('ok', false, 'code', 'vide'); end if;
  if exists (select 1 from public.tfl_demandes where not traitee and ref = v_ref and type = p_type and regexp_replace(upper(matricule), '[^A-Z0-9]', '', 'g') = a.identifiant) then
    return jsonb_build_object('ok', true);
  end if;
  if (select count(*) from public.tfl_demandes where regexp_replace(upper(matricule), '[^A-Z0-9]', '', 'g') = a.identifiant and created_at > now() - interval '1 hour') >= 5 then
    return jsonb_build_object('ok', false, 'code', 'trop');
  end if;
  insert into public.tfl_demandes(matricule, role, nom, ref, titre, type, texte) values (a.identifiant, 'encadreur', left(a.nom, 120), v_ref, left(v_titre, 250), p_type, v_txt);
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.tfl_espace_sujet_demande(text, text, text, text, text) from public;
grant execute on function public.tfl_espace_sujet_demande(text, text, text, text, text) to anon, authenticated;

-- 3) Connexion : même réponse qu'avant + « envois » (sujets proposés) et « demandes » de l'encadreur
create or replace function public.tfl_portail_connexion(p_role text, p_ident text, p_mdp text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; a public.tfl_acces;
begin
  select * into c from public.tfl_acces_check(p_role, p_ident, p_mdp);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  if c.v_changer then
    select * into a from public.tfl_acces where id = c.v_id;
    return jsonb_build_object('ok', true, 'changer', true, 'nom', a.nom);
  end if;
  update public.tfl_acces set connexions = connexions + 1, derniere_connexion = now() where id = c.v_id returning * into a;
  return jsonb_build_object('ok', true, 'changer', false, 'nom', a.nom, 'publie_le', a.publie_le, 'contenu', a.contenu,
    'messages', coalesce((select jsonb_agg(jsonb_build_object('de', m.de, 'type', m.type, 'dossier', m.dossier, 'texte', m.texte, 'valeur', m.valeur, 'cree_le', m.cree_le) order by m.cree_le)
                          from public.tfl_messages m where m.acces_id = a.id), '[]'::jsonb),
    'envois', case when a.role = 'encadreur' then coalesce((select jsonb_agg(jsonb_build_object('titre', e.titre, 'cree_le', e.cree_le, 'importe', e.importe) order by e.cree_le desc)
                          from (select data->'sujets'->0->>'titre' as titre, created_at as cree_le, imported as importe from public.tfl_encadreurs_envois
                                 where data->>'portail_ident' = a.identifiant order by created_at desc limit 20) e), '[]'::jsonb) else '[]'::jsonb end,
    'demandes', case when a.role = 'encadreur' then coalesce((select jsonb_agg(jsonb_build_object('ref', d.ref, 'titre', d.titre, 'type', d.type, 'texte', d.texte, 'cree_le', d.cree_le, 'traitee', d.traitee) order by d.cree_le desc)
                          from (select ref, titre, type, texte, created_at as cree_le, traitee from public.tfl_demandes
                                 where regexp_replace(upper(matricule), '[^A-Z0-9]', '', 'g') = a.identifiant order by created_at desc limit 20) d), '[]'::jsonb) else '[]'::jsonb end);
end $$;
revoke all on function public.tfl_portail_connexion(text,text,text) from public;
grant execute on function public.tfl_portail_connexion(text,text,text) to anon, authenticated;

-- Contrôle : select proname from pg_proc where proname in ('tfl_espace_sujet_proposer','tfl_espace_sujet_demande','tfl_portail_connexion'); -- 3 lignes
-- Après exécution : TFL › Portails › « Publier / mettre à jour » UNE fois (le téléphone et l'e-mail de chaque encadreur sont ajoutés à son accès).
