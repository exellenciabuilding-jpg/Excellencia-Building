const fs=require('fs');
const h=fs.readFileSync(require('path').join(__dirname,'../../tfl-portail.html'),'utf8');
const sc=h.match(/<script>\n\(function\(\)\{[\s\S]*?<\/script>/)[0].replace(/^<script>\n/,'').replace(/<\/script>$/,'');
// extraire les fonctions utiles
const grab=(n)=>{const i=sc.indexOf('function '+n+'(');let d=0,j=sc.indexOf('{',i);for(let k=j;k<sc.length;k++){if(sc[k]=='{')d++;if(sc[k]=='}'){d--;if(!d)return sc.slice(i,k+1)}}};
const names=['esc','dt','wa','pct','fil','barre','pied','val','badgeS','vueEncadreur','erreur'];
let code="var $=function(){return {}};var FLASH='';"+names.map(grab).join('\n');
const vm=require('vm');const ctx={};vm.createContext(ctx);vm.runInContext(code,ctx);
const data={nom:'Dr Test',publie_le:'2026-10-29T08:00:00Z',contenu:{nom:'Dr Test',matricule:'123-456-789',max_etudiants:2,
 propositions:[{ref:'S1',titre:'Sujet A',label:'Retenu',statut:'retenu',motif:''},{ref:'S2',titre:'Sujet B',label:'Refusé',statut:'refuse',motif:'Hors périmètre'},{ref:'S3',titre:'Sujet C',label:'Retiré à la demande',statut:'retire',motif:''}],
 dossiers:[{numero:'TFL-1',etudiant:'Alice <b>',matricule:'111-111-111',telephone:'0810000000',sujet_titre:'Béton',etape:5,etape_label:'x',progression:40,avis:true,validation_label:'en attente'},
           {numero:'TFL-2',etudiant:'Bob',matricule:'222-222-222',sujet_titre:'Acier',etape:6,etape_label:'y',progression:100,avis:false}]},
 messages:[],envois:[{titre:'Nouveau',cree_le:'2026-10-28T10:00:00Z',importe:false}],demandes:[{ref:'S1',titre:'Sujet A',type:'modifier',cree_le:'2026-10-28T11:00:00Z',traitee:true}]};
const out=ctx.vueEncadreur(data);
const chk=(l,c)=>console.log((c?'OK  ':'FAIL')+' '+l);
chk('KPI dossiers 2 / 2',out.includes('<b>2 / 2</b>'));
chk('alerte avis',out.includes('attend votre avis'));
chk('alerte charge max',out.includes('Charge maximale atteinte'));
chk('3 sujets émis (1 retenu)',out.includes('<b>3</b>sujets émis (1 retenu)'));
chk('sujet retiré sans bouton demande',(out.match(/data-act="sdem"/g)||[]).length===4);
chk('formulaire nouveau sujet',out.includes('data-act="snew"'));
chk('en attente: envoi + demande',out.includes('Sujet « Nouveau »')&&out.includes('traité(e)'));
chk('2 cartes apprenants filtrables',(out.match(/data-ap="1"/g)||[]).length===2);
chk('échappement HTML',!out.includes('Alice <b>')&&out.includes('Alice &lt;b&gt;'));
chk('actions existantes conservées',['data-act="com"','data-act="adm"','data-act="v1"','data-act="v2"','data-act="v3"','data-act="prog"'].every(x=>out.includes(x)));
chk('erreur telephone',ctx.erreur({code:'telephone'}).includes('republier'));
const vide=ctx.vueEncadreur({nom:'Z',contenu:{}});chk('vue vide sans exception',vide.includes('Aucun étudiant')&&vide.includes('Aucun sujet émis'));
