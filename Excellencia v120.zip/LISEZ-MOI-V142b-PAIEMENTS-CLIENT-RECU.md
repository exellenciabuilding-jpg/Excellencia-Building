# V142b — Espace client : corrections de la maquette + paiement par déclaration et reçu

## Corrigé dans `site/portail.html` (espace client)
- Menu : « Documents à signer » et « Factures & Paiements » tiennent sur une ligne.
- Activités récentes : icône enveloppe pour les messages, miniature « Nouveau » pour un nouveau document, plus de doublon entre une facture envoyée et la même facture publiée.
- Mes documents : titres complets (retour à la ligne si besoin), détail masqué sur l'accueil (visible dans Plans & Documents).
- Indicateurs : « Villa R+1 / M. Jean Kabongo » sur une ligne, icône sac pour le montant facturé, fond « grue » du bloc d'aide.
- Mobile : indicateurs en 2 colonnes.

## Paiement des clients (même principe que les apprenants — aucun paiement en ligne)
1. Le client paie hors du logiciel (Mobile Money, banque, caisse).
2. Dans son espace › Factures & Paiements › **Régler** (ou « Déclarer un paiement ») : facture, montant, devise, mode, **référence**, **numéro de transaction**, date.
   Un même numéro de transaction ne peut pas être déclaré deux fois. Il suit l'état : En attente de vérification, Confirmé (reçu n°…), Refusé (motif).
3. Côté administrateur : **🔗 Portails & signatures › 💳 Paiements** : vérifier sur le relevé, **Confirmer** (montant réellement reçu ; le numéro REC-CLI-AAAA-00001 est donné par le serveur) ou **Refuser** (motif obligatoire).
4. **🧾 Générer et envoyer le reçu** : le PDF (une page, sans page de garde) est créé par le logiciel et envoyé dans l'espace du client (Plans & Documents › Reçus). Le client est prévenu dans ses messages ; un message WhatsApp/e-mail prêt à envoyer s'ouvre.
5. Le montant « payé » du tableau de bord se met à jour à la prochaine publication du portail.

## À faire (dans l'ordre)
1. Supabase › SQL Editor : exécuter `site/supabase/migration-v142b-paiements-client.sql` (une fois, réexécutable ; après v142a).
2. Redéployer `site` sur Netlify ; rouvrir le logiciel (cache v155).

## Vérifié
- SQL : v99zzzz…plans, v142a et v142b exécutées sur un vrai PostgreSQL 16 (avec des fonctions d'authentification simulées) : déclaration, doublon, références/devise/date invalides, confirmation, nouvelle confirmation sans message en double, refus sans motif refusé, refus après envoi du reçu refusé, envoi du reçu, accès direct à la table fermé, réexécution sans erreur.
- Portail : formulaire, validations, envoi, liste « Mes paiements », bouton « Reçu » (navigateur, serveur simulé).
- Reçu PDF : généré par le moteur du logiciel, 1 page.

## Non testé / limites
- Pas testé avec ton vrai Supabase, ni la partie administrateur complète dans index.html (onglet Paiements, confirmation, envoi), ni sur téléphone.
- Le reçu n'a pas de QR de vérification (il n'est pas inscrit au registre de vérification des reçus apprenants).
- Le logo complet, les images haute définition et la photo du client restent à fournir.
