# Excellencia Building — V120y PERFORMANCE & STABILITÉ

## Trois chantiers livrés

### 1. Recherche globale
- Le cache d’indexation utilise maintenant un compteur de révision alimenté par `exbStorage.setItem/removeItem/clear`.
- Une recherche ne relit donc plus systématiquement les grandes chaînes JSON de `localStorage` pour vérifier si chaque collection a changé.
- Les index périmés ne sont pas publiés si une collection est modifiée pendant sa construction.
- Le texte normalisé conservé par fiche est plafonné à 1 800 caractères pour limiter l’empreinte mémoire.
- Le préchargement au démarrage est limité aux collections courantes ; les autres sont indexées à la demande.
- Le délai supplémentaire de la barre de recherche est ramené à 90 ms afin d’éviter le cumul excessif des temporisations.
- Un événement `storage` invalide aussi le cache lorsqu’une autre fenêtre du même site modifie les données.

### 2. Consommation mémoire et sauvegarde automatique
- La sauvegarde complète automatique n’est plus lancée au milieu d’une saisie ou juste après une interaction.
- Elle attend une période d’inactivité et une fenêtre de repos du navigateur (`requestIdleCallback` si disponible).
- Elle reste reportée si l’application est masquée ou si l’utilisateur est encore actif.
- Une sauvegarde manuelle reste disponible depuis le panneau habituel.

### 3. Formulaires volumineux
- Dans le module Métré, les recalculs visuels déclenchés par la saisie sont regroupés à une seule mise à jour par image (`requestAnimationFrame`).
- Les valeurs du formulaire sont toujours mises à jour immédiatement dans l’état mémoire.
- La sauvegarde différée du brouillon et le bouton d’enregistrement manuel sont conservés.
- Aucun champ, module métier ou format de données n’a été supprimé.

## Vérifications effectuées
- 276 fichiers JavaScript du dossier `site` contrôlés avec `node --check` : aucune erreur de syntaxe.
- Tests de calcul : 30 vérifications de cohérence, 111 contrôles de calcul et 78 contrôles Robot/structures réussis, sans écart hors tolérance.
- Arborescence et fichiers de la version précédente conservés ; seuls les fichiers ciblés et cette note de version ont été modifiés/ajoutés.

## Essais indispensables avant déploiement
1. Rechercher un client, un projet, un devis et un participant ; modifier une fiche puis relancer la recherche pour vérifier l’actualisation du cache.
2. Saisir plusieurs lignes dans le module Métré, changer les quantités et prix, vérifier les totaux, quitter puis rouvrir le brouillon.
3. Laisser l’application ouverte et vérifier que la sauvegarde automatique attend une période d’inactivité.
4. Lancer une sauvegarde manuelle, vérifier le fichier, puis tester la restauration sur une copie de données.
5. Répéter sur Android et ordinateur, avec les données réelles et une connexion lente.

**Statut : version de test.** Les tests statiques et les tests numériques ne remplacent pas les essais interactifs sur navigateur/appareil et sur une copie de la base réelle. Faire une sauvegarde externe avant tout essai de restauration.
