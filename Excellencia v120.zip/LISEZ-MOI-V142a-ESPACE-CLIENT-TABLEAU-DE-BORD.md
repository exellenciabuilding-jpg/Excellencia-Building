# V142a — Espace client en tableau de bord + documents de tous types

## Nouveau
- `site/portail.html` : espace client refait d'après la maquette (menu latéral, accueil, avancement, actions rapides, photos, activités, documents, indicateurs, aide) + pages Mon Projet, Plans & Documents (onglets par type), Documents à signer, Factures & Paiements, Suivi de chantier, Messages, Mon Profil (changement de mot de passe), Aide. Le portail sous-traitant garde son affichage d'origine.
- `site/exb-v99zy-portails.js` : « 📎 Envoyer un document » (plan, devis, note de calcul, plan d'exécution, facture, contrat, rapport, autre), numéro et note, versions « modifié », suivi « Documents envoyés ».
- `site/espace-client.html` : mémorise le matricule pour l'en-tête.
- `site/assets/accueil/client-hero.jpg`, `client-side.jpg` : images de la maquette.
- `site/tools/e2e-espace-client.py` : test adapté.

## À faire (dans l'ordre)
1. Supabase › SQL Editor : exécuter `site/supabase/migration-v142a-documents-client.sql` (une fois, réexécutable ; après la migration « espace-client-plans »).
2. Redéployer `site` sur Netlify.

## Non fait / limites
- Paiement en ligne (Mobile Money…) : prochaine partie. Le bouton « Régler » écrit un message à l'entreprise.
- Envoi automatique depuis les modules devis / notes / plans : à venir ; pour l'instant on choisit le PDF à la main (6 Mo max).
- SQL non testé sur un vrai Postgres.
