/* Excellencia Building V66 — Droits par fonction (côté écran).
 * Le SERVEUR applique les droits (supabase/migration-v66-roles.sql). Ici : menus masqués, sections en lecture seule,
 * et blocage des actions qui touchent plusieurs fiches (paiements → caisse, facturation…) pour éviter les enregistrements à moitié faits.
 * Sans base partagée (mode local) ou sans migration SQL : aucun changement de comportement. */
(function(){'use strict';
var $=function(i){return document.getElementById(i)};
function D(){return window.EXBDB}
function info(){var d=D();return d&&d.info?d.info():{on:false}}
function active(){return !!info().on}
function can(c,m){var d=D();return d&&d.can?d.can(c,m):true}
function label(){return info().label||''}
function any(l,m){return l.some(function(c){return can(c,m)})}
function every(l,m){return l.every(function(c){return can(c,m)})}
function toast(m,t){try{if(typeof notify==='function')return notify(m,t||'warn',6000)}catch(e){}exbAlert(m)}

/* section -> bouton de menu, collections lues (l), collections modifiées (e). all:1 = il faut pouvoir tout lire. */
var SEC={
 projets:{b:'bprj',l:['projets'],e:['projets']},
 clients:{b:'bclients',l:['clients'],e:['clients']},
 metreDevis:{b:'bdev',l:['devis','metres'],e:['devis','metres']},
 stock:{b:'bstk',l:['stock','mouvements'],e:['stock','mouvements']},
 rh:{b:'brh',l:['personnel'],e:['personnel']},
 comptabilite:{b:'bcompta',l:['caisse'],e:['caisse']},
 budgetfin:{b:'bbfin',l:['caisse','factures'],e:['caisse']},
 direction:{b:'bdir',l:['caisse','projets'],all:1,e:[],quiet:1},
 bureauEtudes:{b:'bbet',l:['etudes'],e:['etudes']},
 communication:{b:'bcom',l:['communication'],e:['communication']},
 documents:{b:'bdocs',l:['documents'],e:['documents']},
 chantiers:{b:'bchan',l:['factures','caisse'],all:1,e:['factures','caisse']},
 terrain:{b:'bterr',l:['commandes','journal','pointages','situations','fournisseurs'],e:['commandes','journal','pointages','situations','fournisseurs']},
 etudes3:{b:'bete3',l:['notes_calcul','plans','missions_be','heures_be'],e:['notes_calcul','plans','missions_be','heures_be']},
 pilotprojet:{b:'bpilot',l:['projets','planning_chantier','budgets_chantier'],all:1,e:[],quiet:1},
 planning:{b:'bplan',l:['planning_chantier','budgets_chantier'],e:['planning_chantier','budgets_chantier']},
 exbV67:{b:'bv67',l:['crm','contrats','rfis','submittals','avenants','engagements','risques','reunions','reserves','parc_materiel','qhse'],e:['crm','contrats','rfis','submittals','avenants','engagements','risques','reunions','reserves','parc_materiel','qhse']},
 exbV68:{b:'bv68',l:['cde','bim_issues','evm','maintenance','risk_register','client_portal'],e:['cde','bim_issues','evm','maintenance','risk_register','client_portal']},
 exbV69:{b:'exbV69Btn',l:['price_library','estimates','benchmarks','ai_notes'],e:['price_library','estimates','benchmarks','ai_notes']},
 portails:{b:'bportails',l:['portails','clients'],e:['portails']},
 exbPlansV70:{b:'bv70plans',l:['plans_coupes_structure'],e:['plans_coupes_structure']},
 exb_v71_plans:{b:'bv71plans',l:['drawing_sheets','drawing_sets'],e:['drawing_sheets','drawing_sets']},
 exb_v72_print:{b:'bv72print',l:['drawing_sheets','drawing_sets'],e:[],quiet:1},
 administration:{b:'badm',admin:1,quiet:1}
};
function visible(id){var s=SEC[id];if(!s||!active())return true;
 if(s.admin){var i=info();return i.role==='admin'||i.fonction==='polyvalent'}
 return s.all?every(s.l,'lire'):any(s.l,'lire')}
function readOnly(id){var s=SEC[id];if(!s||!active()||s.admin)return false;return !(s.e&&s.e.length&&any(s.e,'ecrire'))}

/* ---------- styles ---------- */
var st=document.createElement('style');
st.textContent='[data-exbrole="hide"]{display:none!important}.exb-roban{background:#fff4d6;border:1px solid #e0b84c;color:#6a4b00;padding:8px 12px;border-radius:8px;margin:0 0 10px;font-size:13px}[data-exbro]{opacity:.5;cursor:not-allowed}';
document.head.appendChild(st);

/* ---------- lecture seule ---------- */
var obs=null,obsEl=null,tmr=null;
var SKIP=/search|recherche|filtre|filter/i;
function lockCtl(el){var n=el.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=search]),textarea,button.primary,button.danger');
 for(var i=0;i<n.length;i++){var c=n[i];if(c.disabled||SKIP.test((c.id||'')+' '+(c.placeholder||'')))continue;c.disabled=true;c.setAttribute('data-exbro','1')}}
function unlock(el){var n=el.querySelectorAll('[data-exbro]');for(var i=0;i<n.length;i++){n[i].disabled=false;n[i].removeAttribute('data-exbro')}var b=el.querySelector('.exb-roban');if(b)b.remove()}
function stopObs(){if(obs){obs.disconnect();obs=null;obsEl=null}}
function decorate(id){stopObs();var s=id&&SEC[id],el=id&&$(id);if(!s||!el)return;
 if(!readOnly(id)||s.quiet){unlock(el);return}
 if(!el.querySelector('.exb-roban')){var d=document.createElement('div');d.className='exb-roban';d.textContent='🔒 Lecture seule — votre fonction ('+label()+') ne permet pas de modifier cette section.';el.insertBefore(d,el.firstChild)}
 lockCtl(el);
 if(window.MutationObserver){obsEl=el;obs=new MutationObserver(function(){clearTimeout(tmr);tmr=setTimeout(function(){if(obsEl){if(!obsEl.querySelector('.exb-roban')){decorate(id)}else lockCtl(obsEl)}},60)});obs.observe(el,{childList:true,subtree:true})}}
function current(){var ids=Object.keys(SEC);for(var i=0;i<ids.length;i++){var e=$(ids[i]);if(e&&e.style.display!=='none'&&e.offsetParent!==null)return ids[i]}return null}

/* ---------- menus ---------- */
function apply(){Object.keys(SEC).forEach(function(id){var b=SEC[id].b&&$(SEC[id].b);if(!b)return;if(visible(id))b.removeAttribute('data-exbrole');else b.setAttribute('data-exbrole','hide')});
 var cur=current();if(cur&&!visible(cur)&&typeof window.show==='function'){window.show('dashboard');return}
 decorate(cur)}

/* show() : refus + décoration. Reposé après le montage des modules pour rester la couche la plus externe. */
function wrapShow(){var os=window.show;if(typeof os!=='function'||os.__roles)return;
 var f=function(x){if(SEC[x]&&!visible(x)){toast('Accès refusé : votre fonction ('+label()+') n\'a pas accès à cette section.');return os.call(this,'dashboard')}
  var r=os.apply(this,arguments);setTimeout(function(){decorate(x)},0);return r};
 f.__roles=1;window.show=f}

/* ---------- actions à plusieurs fiches : tout ou rien ---------- */
var LAB={caisse:'caisse',factures:'factures',commandes:'bons de commande',pointages:'pointages',situations:'situations',stock:'stock',mouvements:'mouvements de stock',fournisseurs:'fournisseurs',journal:'journal de chantier',notes_calcul:'notes de calcul',plans:'plans',missions_be:'missions & honoraires',heures_be:'heures',planning_chantier:'planning',budgets_chantier:'budget',projets:'projets'};
function guard(obj,map){if(!obj)return;Object.keys(map).forEach(function(n){var f=obj[n];if(typeof f!=='function'||f.__g)return;
 var g=function(){if(active()){var need=map[n];for(var i=0;i<need.length;i++)if(!can(need[i],'ecrire')){toast('Droits insuffisants : votre fonction ('+label()+') ne permet pas cette action (« '+(LAB[need[i]]||need[i])+' »).');return}}return f.apply(this,arguments)};
 g.__g=1;obj[n]=g})}
function guards(){
 guard(window.EXBCH,{newInv:['factures'],saveD:['factures'],delI:['factures'],fromQuote:['factures'],pay:['factures','caisse'],addE:['caisse'],delE:['caisse']});
 guard(window.EXBTR,{newSup:['fournisseurs'],saveSup:['fournisseurs'],newPo:['commandes'],savePo:['commandes'],rec:['commandes','stock','mouvements'],payPo:['commandes','caisse'],
  newJr:['journal'],editJr:['journal'],saveJr:['journal'],addT:['pointages'],payT:['pointages','caisse'],newSit:['situations'],editSit:['situations'],addAv:['situations'],saveSit:['situations'],sitInv:['situations','factures']});
 guard(window.EXBET,{newNote:['notes_calcul'],editNote:['notes_calcul'],dupNote:['notes_calcul'],delNote:['notes_calcul'],addEl:['notes_calcul'],saveNote:['notes_calcul'],
  newPlan:['plans'],editPlan:['plans'],savePlan:['plans'],delPlan:['plans'],newVer:['plans'],saveVer:['plans'],send:['plans'],visa:['plans'],obs:['plans'],delSent:['plans'],
  newMi:['missions_be'],editMi:['missions_be'],saveMi:['missions_be'],delMi:['missions_be','heures_be'],addT:['heures_be'],delT:['heures_be'],inv:['missions_be','factures']});
 guard(window.EXBPL,{newG:['planning_chantier'],addT:['planning_chantier'],delT:['planning_chantier'],delG:['planning_chantier'],toProj:['planning_chantier','projets'],
  newB:['budgets_chantier'],bAlea:['budgets_chantier'],calcAlea:['budgets_chantier'],addP:['budgets_chantier'],delP:['budgets_chantier'],delB:['budgets_chantier'],toBud:['budgets_chantier','projets']})}

window.EXBROLES={apply:apply,visible:visible,readOnly:readOnly};
window.addEventListener('exb-rights',apply);
guards();wrapShow();
var n=0,iv=setInterval(function(){n++;guards();apply();
 if((window.__exbChShow&&window.__exbTrShow&&window.__exbEtShow&&window.__exbPlShow&&$('bplan'))||n>40){clearInterval(iv);wrapShow();apply()}},250);
})();
