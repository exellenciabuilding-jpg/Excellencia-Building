# V157 — Studio libre : +113 modèles (textes/documents et affiches)

**Aucun SQL.** Fichier modifié : `exb-affiches-studio.js`. Total du Studio libre : **235 modèles** (46 d'origine + 76 en V156 + 113 ici).

## Textes et documents (A4, 55 modèles) — tout est modifiable
- **Lettres & courriers (14)** : demande de rendez-vous, relance de paiement, mise en demeure, remerciements, candidature, recommandation, démission, demande de congé, offre d'engagement, avertissement, félicitations, réponse à une réclamation, partenariat, convocation.
- **Attestations & certificats (6)** : attestation de travail, certificat de travail, fin de stage, attestation de paiement, bonne exécution, procuration.
- **Documents commerciaux (12)** : devis détaillé, facture proforma, bon de commande, bon de livraison, facture simple, note d'honoraires, bordereau de prix, décharge, contrat de prestation, avenant, conditions générales, reçu simple.
- **Chantier & technique (14)** : PV de réception, ordre de service, rapport journalier, rapport hebdomadaire, fiche de pointage, demande de matériaux, check-list de visite, liste des réserves, planning, fiche de métré, déclaration d'incident, registre des visiteurs, compte rendu de réunion, suivi des matériaux.
- **RH & administration (9)** : fiche de poste, évaluation, liste de présence, note interne, règlement intérieur, fiche employé, ordre de mission, demande d'avance, remise de matériel.

## Affiches (58 modèles)
- **Fêtes & occasions (14)** : Noël, Pâques, Aïd, Ramadan, 30 juin, 8 mars, fête des mères, des pères, Saint-Valentin, rentrée, Black Friday, anniversaire d'un collaborateur, félicitations, condoléances.
- **Avis & annonces (9)** : attribution de marché, enquête de satisfaction, interruption de service, déménagement, réouverture, travaux, rappel d'échéance, certification, poste interne.
- **Marketing & fidélisation (15)** : nouveau service, chantier démarré / livré, étude de cas, jeu-concours, planning de la semaine, tutoriel, bon cadeau, fidélité, newsletter, clé en main, paiement échelonné, garanties, plan 3D offert, témoignage (story).
- **Compléments** : réseaux sociaux (+6), immobilier (+4), sécurité (+5), formations (+5).

Les tableaux (devis, pointage, métré…) s'agrandissent pour remplir la page ; les textes se réduisent automatiquement s'ils sont trop longs. Test : `python3 tools/e2e-affiches-modeles.py`.
Non testé à l'impression réelle ni sur téléphone. Les modèles de contrats / mises en demeure sont des trames générales : à faire valider par un juriste avant usage.
