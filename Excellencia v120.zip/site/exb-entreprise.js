/* exb-entreprise.js — IDENTITÉ DE L'ENTREPRISE : un seul endroit à remplir.
 * Le propriétaire du logiciel saisit ici nom, logo, couleurs, contacts, direction, mentions légales,
 * adresse publique et (facultatif) serveur. Ces données alimentent partout :
 *   écrans et en-têtes (EXB_BRAND_V1 → exb-brand.js), documents/PDF/devis/certificats (EXB_IDENTITE_V1 → EXBId),
 *   en-tête de l'application (exb_brand), logo des certificats (exb_logo), manifeste de l'appli installée,
 *   adresse des liens envoyés (EXB_PUBLIC_URL_V1 → brand-config.js).
 * L'écran se trouve dans ⚙️ Paramètres › 🏢 Identité de l'entreprise (et s'affiche seul au tout premier lancement d'un exemplaire non préconfiguré).
 * Le bouton « Télécharger entreprise.json » produit le fichier à déposer dans le dossier du site (Netlify) AVANT de compiler l'APK / Windows.
 * Charge APRÈS exb-brand.js et exb-identite.js. API : EXBEntreprise.get() / .save(o) / .open() / .exporter() / .importer(file). */
window.EXBEntreprise = (function (w, d) {
  'use strict';
  var KB = 'EXB_BRAND_V1', KI = 'EXB_IDENTITE_V1', KU = 'EXB_PUBLIC_URL_V1';
  var ORIGIN = { name: 'Excellencia Building', short: 'Excellencia', chantier: 'Excellencia Chantier', primary: '#173565', secondary: '#0f4aa8', accent: '#c49a38' };

  function s(v) { return String(v == null ? '' : v).trim(); }
  function esc(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function ls(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function slug(v) { return s(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, ''); }

  /* ---------- lecture : fusionne les trois anciennes sources ---------- */
  function get() {
    var B = w.EXB_BRAND || {}, I = {}, own = ls(KI) || {};
    try { I = (w.EXBId && EXBId.get()) || {}; } catch (e) {}
    var pub = s(localStorage.getItem(KU)) || s(w.EXB_PUBLIC_URL);
    return {
      name: s(B.name) || ORIGIN.name, short: s(B.short) || ORIGIN.short, chantier: s(B.chantier) || ORIGIN.chantier,
      tagline: s(I.tagline) || s(B.tagline),
      logo: s(I.logo) || s(B.logo),
      primary: s(B.primary) || ORIGIN.primary, secondary: s(B.secondary) || ORIGIN.secondary, accent: s(B.accent) || ORIGIN.accent,
      phone: s(I.phone), email: s(I.email), address: s(I.address), city: s(I.city), country: s(I.country || B.country),
      website: s(own.website),
      dg: s(I.dg), dgRole: s(I.dgRole) || 'Directeur Général',
      legal: s(own.legal), footer: s(own.footer),
      publicUrl: pub, supabaseUrl: s(B.supabaseUrl), supabaseKey: s(B.supabaseKey)
    };
  }
  function nameUpper() { return get().name.toUpperCase(); }
  function isOrigin() { return get().name.toLowerCase() === ORIGIN.name.toLowerCase(); }

  /* ---------- écriture : une saisie → toutes les destinations ---------- */
  function save(o) {
    var cur = get(), n = {}; Object.keys(cur).forEach(function (k) { n[k] = (o && o[k] !== undefined) ? s(o[k]) : cur[k]; });
    if (o && o.logo !== undefined) n.logo = String(o.logo || '');
    if (!n.name) return { ok: false, err: 'Le nom de l’entreprise est obligatoire.' };
    if (!n.short) n.short = n.name.split(/\s+/)[0];
    if (!n.chantier) n.chantier = n.name + ' Chantier';
    if ((n.supabaseUrl || n.supabaseKey) && !(/^https:\/\/[^\s]+$/.test(n.supabaseUrl) && n.supabaseKey)) return { ok: false, err: 'Serveur : renseignez l’URL (https://…) ET la clé, ou videz les deux champs.' };
    if (n.publicUrl && !/^https?:\/\/[^\s]+$/.test(n.publicUrl)) return { ok: false, err: 'Adresse publique : commencez par https://' };

    /* 1. écrans (exb-brand.js) */
    var prev = ls(KB) || {}, pb = prev.brand || {};
    var brand = Object.assign({}, pb, { name: n.name, short: n.short, chantier: n.chantier, tagline: n.tagline, logo: n.logo, primary: n.primary, secondary: n.secondary, accent: n.accent,
      phone: n.phone, email: n.email, address: n.address, country: n.country, supabaseUrl: n.supabaseUrl.replace(/\/+$/, ''), supabaseKey: n.supabaseKey });
    if (!lsSet(KB, { done: true, brand: brand })) return { ok: false, err: 'Enregistrement impossible (mémoire pleine ou navigation privée).' };
    /* 2. documents (EXBId) */
    var ident = Object.assign({}, ls(KI) || {}, { phone: n.phone, email: n.email, address: n.address, city: n.city, legal: n.legal, footer: n.footer, website: n.website, dg: n.dg, dgRole: n.dgRole });
    lsSet(KI, ident);
    /* 3. en-tête et écran de connexion de l'application */
    try { if (typeof w.save === 'function' && typeof w.getBrand === 'function') { var gb = w.getBrand() || {}; w.save('exb_brand', { name: n.name, sub: gb.sub, loginsub: gb.loginsub }); } } catch (e) {}
    /* 4. logo des certificats / reçus / PDF */
    try { if (typeof exbStorage !== 'undefined') { if (n.logo) exbStorage.setItem('exb_logo', n.logo); else exbStorage.removeItem('exb_logo'); } } catch (e) {}
    /* 5. adresse publique des liens */
    try { if (n.publicUrl) localStorage.setItem(KU, n.publicUrl.replace(/\/+$/, '')); else localStorage.removeItem(KU); } catch (e) {}
    return { ok: true, data: n };
  }

  /* ---------- export / import de l'identité (autre appareil, exemplaire client) ---------- */
  /* entreprise.json : à déposer à la racine du site (à côté de index.html) puis à compiler. Clés vides omises. */
  function fileObject() {
    var o = get(), out = {
      _aide: 'Fichier d’identité. Déposez-le à la racine du site (à côté de index.html), sur Netlify ET dans le dossier site/ avant de compiler l’APK et Windows.',
      version: 1,
      name: o.name, short: o.short, chantier: o.chantier, tagline: o.tagline, logo: o.logo,
      primary: o.primary, secondary: o.secondary, accent: o.accent,
      phone: o.phone, email: o.email, address: o.address, city: o.city, country: o.country, website: o.website,
      dg: o.dg, dgRole: o.dgRole, legal: o.legal, footer: o.footer, publicUrl: o.publicUrl,
      supabaseUrl: o.supabaseUrl, supabaseKey: o.supabaseKey,
      appId: 'com.' + (slug(o.short || o.name).toLowerCase().replace(/-/g, '') || 'entreprise') + '.app'
    };
    Object.keys(out).forEach(function (k) { if (out[k] === '' || out[k] == null) delete out[k]; });
    return out;
  }
  function exporter() {
    var o = fileObject();
    var a = d.createElement('a'), u = URL.createObjectURL(new Blob([JSON.stringify(o, null, 2)], { type: 'application/json' }));
    a.href = u; a.download = 'entreprise.json'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(u); a.remove(); }, 1500);
  }
  function importer(file, cb) {
    var r = new FileReader();
    r.onload = function () { try { var j = JSON.parse(r.result); var x = j && (j.data || j); if (!x || !x.name) throw 0; cb(null, x); } catch (e) { cb('Fichier d’identité non reconnu.'); } };
    r.onerror = function () { cb('Lecture impossible.'); }; r.readAsText(file);
  }
  function resizeLogo(file, cb) {
    var r = new FileReader();
    r.onload = function () {
      if (/svg/.test(file.type)) { cb(r.result); return; }
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, 512 / Math.max(im.width, im.height)), c = d.createElement('canvas');
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); cb(c.toDataURL('image/png'));
      };
      im.onerror = function () { cb(null); }; im.src = r.result;
    };
    r.readAsDataURL(file);
  }

  /* ---------- interface ---------- */
  var CSS = '#exbEnt{position:fixed;inset:0;z-index:99995;background:rgba(15,23,42,.6);display:flex;align-items:center;justify-content:center;font:15px system-ui,sans-serif;color:#172033}' +
    '#exbEnt .bx{background:#fff;width:100%;max-width:640px;max-height:96vh;overflow:auto;border-radius:16px;padding:18px;box-sizing:border-box}' +
    '#exbEnt h2{margin:0 0 2px;color:var(--ent-p,#173565)}#exbEnt p.s{margin:0 0 10px;color:#64748b;font-size:13px}' +
    '#exbEnt fieldset{border:1px solid #e2e8f0;border-radius:12px;margin:12px 0;padding:6px 12px 12px}#exbEnt legend{font-weight:800;padding:0 6px;color:var(--ent-p,#173565)}' +
    '#exbEnt label{display:block;font-weight:700;font-size:13px;margin:10px 0 4px}#exbEnt .h{font-weight:400;color:#64748b;font-size:12px}' +
    '#exbEnt input,#exbEnt textarea{width:100%;box-sizing:border-box;padding:10px;border:1px solid #cbd5e1;border-radius:10px;font:inherit;background:#fff;color:#172033}' +
    '#exbEnt input[type=color]{padding:2px;height:42px}#exbEnt .r{display:flex;gap:10px;flex-wrap:wrap}#exbEnt .r>div{flex:1 1 140px}' +
    '#exbEnt button{font:inherit;cursor:pointer}#exbEnt .p{width:100%;margin-top:10px;padding:13px;border:0;border-radius:12px;background:var(--ent-p,#173565);color:#fff;font-weight:700}' +
    '#exbEnt .g{padding:10px 12px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;color:#172033}' +
    '#exbEnt .lg{display:flex;align-items:center;gap:12px;flex-wrap:wrap}#exbEnt .lg img{width:72px;height:72px;object-fit:contain;border:1px solid #e2e8f0;border-radius:10px;background:#fff}' +
    '#exbEnt .pv{border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;margin:8px 0}#exbEnt .pv .t{display:flex;align-items:center;gap:12px;padding:12px;color:#fff}' +
    '#exbEnt .pv .t img{width:46px;height:46px;object-fit:contain;background:#fff;border-radius:8px;padding:3px}#exbEnt .pv .t b{font-size:17px}#exbEnt .pv .t small{display:block;opacity:.85}' +
    '#exbEnt .pv .b{height:4px}#exbEnt .pv .f{padding:8px 12px;font-size:12px;color:#475569;background:#f8fafc}' +
    '#exbEnt .err{color:#b91c1c;font-size:13px;margin-top:8px;min-height:1em}#exbEnt .ok{color:#15803d}' +
    '#exbEnt.inl{position:static;inset:auto;z-index:auto;background:none;display:block;margin:0 0 18px}#exbEnt.inl .bx{max-width:none;max-height:none;overflow:visible;padding:14px;border:2px solid #c49a38;border-radius:14px;background:#fff}' +
    '';
  function injectCss() { if (d.getElementById('exbEntCss')) return; var st = d.createElement('style'); st.id = 'exbEntCss'; st.textContent = CSS; d.head.appendChild(st); }
  function close() { var u = d.getElementById('exbEnt'); if (u) u.remove(); }

  function build(first, inline) {
    injectCss(); close();
    var c = get(), logo = c.logo, nameTouched = !!(w.EXB_BRAND && (w.EXB_BRAND.name !== ORIGIN.name));
    /* 1er lancement d'un exemplaire neuf : aucune coordonnée, slogan ni logo de l'éditeur d'origine n'est proposé à l'entreprise cliente */
    if (first && !nameTouched) { c.name = ''; c.short = ''; c.chantier = ''; c.tagline = ''; c.phone = ''; c.email = ''; c.address = ''; c.city = ''; c.country = ''; c.dg = ''; c.logo = ''; logo = ''; }
    function fld(id, lab, val, ph, hint) { return '<label>' + lab + (hint ? ' <span class="h">' + hint + '</span>' : '') + '</label><input id="en_' + id + '" value="' + esc(val) + '" placeholder="' + esc(ph || '') + '">'; }
    var ui = d.createElement('div'); ui.id = 'exbEnt'; if (inline) ui.className = 'inl';
    ui.innerHTML = '<div class="bx"><h2>🏢 ' + (first ? 'Bienvenue — votre entreprise' : 'Identité de l’entreprise') + '</h2>' +
      '<p class="s">Un seul endroit : ce que vous saisissez ici apparaît partout — écrans, en-têtes, écran d’accueil, devis, certificats, reçus, cartes, PDF, liens envoyés.</p>' +
      '<div class="pv" id="en_pv"><div class="t" id="en_pvt"><img id="en_pvl" alt=""><div><b id="en_pvn"></b><small id="en_pvs"></small></div></div><div class="b" id="en_pvb"></div><div class="f" id="en_pvf"></div></div>' +
      '<fieldset><legend>Identité</legend>' + fld('name', 'Nom de l’entreprise *', c.name, 'Ex. Bâtiment Plus SARL') +
      '<div class="r"><div>' + fld('short', 'Nom court', c.short, 'Ex. Bâtiment Plus') + '</div><div>' + fld('chantier', 'Nom de l’appli chantier', c.chantier, 'Ex. Bâtiment Plus Chantier') + '</div></div>' +
      fld('tagline', 'Slogan', c.tagline, 'Ex. Ingénierie & Construction', '(facultatif)') +
      '<label>Logo <span class="h">(PNG, JPG, WebP ou SVG — carré de préférence)</span></label><div class="lg"><img id="en_logo" alt="" src="' + esc(logo) + '" style="' + (logo ? '' : 'visibility:hidden') + '"><input id="en_file" type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" style="flex:1 1 200px"><button type="button" class="g" id="en_nologo">Retirer</button></div></fieldset>' +
      '<fieldset><legend>Couleurs</legend><div class="r"><div><label>Principale</label><input id="en_primary" type="color" value="' + esc(c.primary) + '"></div><div><label>Boutons</label><input id="en_secondary" type="color" value="' + esc(c.secondary) + '"></div><div><label>Accent</label><input id="en_accent" type="color" value="' + esc(c.accent) + '"></div></div></fieldset>' +
      '<fieldset><legend>Contact (imprimé sur les documents)</legend><div class="r"><div>' + fld('phone', 'Téléphone', c.phone, '+243…') + '</div><div>' + fld('email', 'E-mail', c.email, 'contact@…') + '</div></div>' +
      fld('address', 'Adresse', c.address, 'Rue, quartier, ville') + '<div class="r"><div>' + fld('city', 'Ville de signature', c.city, '« Fait à … »') + '</div><div>' + fld('country', 'Pays', c.country, '') + '</div></div>' + fld('website', 'Site web', c.website, 'www.…', '(facultatif)') + '</fieldset>' +
      '<fieldset><legend>Direction et mentions</legend><div class="r"><div>' + fld('dg', 'Nom du dirigeant (signature)', c.dg, 'Prénom Nom') + '</div><div>' + fld('dgRole', 'Fonction', c.dgRole, 'Directeur Général') + '</div></div>' +
      '<label>Mentions légales <span class="h">(RCCM, Id. Nat., N° impôt, banque… une ligne par information)</span></label><textarea id="en_legal" rows="3">' + esc(c.legal) + '</textarea>' +
      fld('footer', 'Pied de page des documents', c.footer, 'Par défaut : le nom de l’entreprise', '(facultatif)') + '</fieldset>' +
      '<fieldset><legend>Publication</legend>' + fld('publicUrl', 'Adresse en ligne du logiciel', c.publicUrl, 'https://mon-entreprise.netlify.app', 'Les liens envoyés (apprenants, clients…) pointent vers cette adresse.') + '</fieldset>' +
      '<details><summary style="font-weight:700;cursor:pointer">☁️ Serveur en ligne <span class="h">(facultatif — synchronisation entre appareils)</span></summary>' + fld('supabaseUrl', 'URL Supabase', c.supabaseUrl, 'https://xxxx.supabase.co') + fld('supabaseKey', 'Clé publique (anon / publishable)', c.supabaseKey, '') + '</details>' +
      '<div class="s" style="margin-top:10px;padding:8px 10px;background:#f1f5f9;border-radius:10px;font-size:12px;color:#475569"><b>Avant de compiler l’APK / Windows :</b> enregistrez, cliquez « Télécharger entreprise.json », placez ce fichier dans le dossier <code>site/</code> (à côté de <code>index.html</code>), déposez le site sur Netlify, puis lancez <code>npm run brand</code>.</div><div class="err" id="en_err"></div><button class="p" id="en_ok">' + (first ? 'Enregistrer et démarrer' : 'Enregistrer partout') + '</button>' +
      '<div class="r" style="margin-top:8px"><div><button class="g" style="width:100%" id="en_exp">⬇️ Télécharger entreprise.json</button></div><div><button class="g" style="width:100%" id="en_imp">⬆️ Charger un entreprise.json</button><input id="en_impf" type="file" accept="application/json,.json" style="display:none"></div></div>' +
      (first ? '' : '<div class="r" style="margin-top:8px"><div><button class="g" style="width:100%" id="en_rs">Revenir à l’origine</button></div></div>') + '</div>';
    if (inline) { var hostSec = d.getElementById('settings'), h2 = hostSec && hostSec.querySelector('h2'); if (!hostSec) return null; hostSec.insertBefore(ui, h2 ? h2.nextSibling : hostSec.firstChild); } else d.body.appendChild(ui);
    var $ = function (i) { return ui.querySelector('#en_' + i); };
    var touched = {};
    function val(k) { return $(k) ? $(k).value : ''; }
    function preview() {
      var p = val('primary'), a = val('accent'), n = val('name') || 'Votre entreprise';
      ui.querySelector('.bx').style.setProperty('--ent-p', p);
      $('pvt').style.background = p; $('pvb').style.background = a; $('pvn').textContent = n; $('pvs').textContent = val('tagline');
      $('pvl').src = logo || ''; $('pvl').style.display = logo ? '' : 'none';
      $('pvf').textContent = [val('phone'), val('email'), val('address')].filter(Boolean).join('  ·  ') || 'Téléphone · e-mail · adresse';
    }
    ui.addEventListener('input', function (e) {
      var id = (e.target.id || '').replace('en_', '');
      if (id === 'name') { if (!touched.short) $('short').value = this.querySelector('#en_name').value.split(/\s+/)[0] || ''; if (!touched.chantier) $('chantier').value = val('name') ? val('name') + ' Chantier' : ''; }
      if (id === 'short' || id === 'chantier') touched[id] = 1;
      preview();
    });
    $('file').onchange = function () { var f = this.files[0]; if (!f) return; resizeLogo(f, function (u) { if (!u) { $('err').textContent = 'Image illisible.'; return; } logo = u; $('logo').src = u; $('logo').style.visibility = 'visible'; preview(); }); };
    $('nologo').onclick = function () { logo = ''; $('logo').style.visibility = 'hidden'; preview(); };
    $('ok').onclick = function () {
      var o = { logo: logo }; ['name', 'short', 'chantier', 'tagline', 'primary', 'secondary', 'accent', 'phone', 'email', 'address', 'city', 'country', 'website', 'dg', 'dgRole', 'legal', 'footer', 'publicUrl', 'supabaseUrl', 'supabaseKey'].forEach(function (k) { o[k] = val(k); });
      var r = save(o); if (!r.ok) { $('err').textContent = r.err; return; }
      $('err').className = 'err ok'; $('err').textContent = '✓ Enregistré — redémarrage de l’application…'; setTimeout(function () { location.reload(); }, 400);
    };
    $('exp').onclick = exporter;
    $('imp').onclick = function () { $('impf').click(); };
    $('impf').onchange = function () {
      var f = this.files[0]; if (!f) return;
      importer(f, function (err, data) { if (err) { $('err').textContent = err; return; } Object.keys(data).forEach(function (k) { if ($(k) && k !== 'supabaseKey') $(k).value = data[k] || ''; }); logo = data.logo || ''; $('logo').src = logo; $('logo').style.visibility = logo ? 'visible' : 'hidden'; $('err').className = 'err ok'; $('err').textContent = 'Identité chargée : vérifiez puis enregistrez.'; preview(); });
    };
    if (!first) {
      $('rs').onclick = async function () { if (!(await exbConfirm('Revenir au nom, au logo et aux couleurs d’origine ?'))) return; ['EXB_BRAND_V1', KI, KU].forEach(function (k) { try { localStorage.removeItem(k); } catch (e) {} }); try { if (typeof exbStorage !== 'undefined') exbStorage.removeItem('exb_logo'); } catch (e) {} location.reload(); };
    }
    preview();
    return ui;
  }
  /* open(true) : 1er lancement (fenêtre). open(false) : va dans Paramètres, section Identité. */
  function open(first) {
    if (first) return build(true, false);
    if (!d.getElementById('exbEnt')) build(false, true);
    try { if (typeof w.show === 'function') w.show('settings'); } catch (e) {}
    var e = d.getElementById('exbEnt'); if (e && e.scrollIntoView) e.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- points d'entrée : bouton dans l'Administration + synchronisation du logo historique ---------- */
  /* monte l'écran dans Paramètres et masque les anciens blocs en double (nom/logo/identité imprimée) */
  function mount() {
    if (d.getElementById('exbEnt')) return true;
    var sec = d.getElementById('settings'); if (!sec) return false;
    if (!build(false, true)) return false;
    var hide = function (el) { if (el) el.style.display = 'none'; };
    var nm = d.getElementById('set_brandname'); if (nm) hide(nm.closest('.pgroup'));
    ['exbLogoFile', 'exbLogoPreview2'].forEach(function (id) { var e = d.getElementById(id); if (e) hide(e.closest('.logo-box')); });
    return true;
  }
  function onFileReset() {
    /* un nouvel entreprise.json a été déposé avec le site : son logo et son nom remplacent ceux enregistrés sur l'appareil */
    if (!w.EXB_FILE_RESET) return;
    try { if (typeof exbStorage !== 'undefined') exbStorage.removeItem('exb_logo'); } catch (e) {}
    try { if (typeof w.save === 'function' && typeof w.getBrand === 'function' && w.EXB_BRAND) { var gb = w.getBrand() || {}; w.save('exb_brand', { name: w.EXB_BRAND.name, sub: gb.sub, loginsub: gb.loginsub }); } } catch (e) {}
    w.EXB_FILE_RESET = false;
  }
  function hookLogoButtons() {
    /* le bouton historique « Enregistrer le logo » met aussi à jour la marque centrale */
    ['saveLogo', 'resetLogo'].forEach(function (fn) {
      var o = w[fn]; if (typeof o !== 'function' || o.__ent) return;
      var n = function (kind) {
        var r = o.apply(this, arguments);
        var sync = function () { try { if (kind !== 'exb') return; var p = ls(KB) || { done: true, brand: {} }; p.brand = p.brand || {}; p.brand.logo = fn === 'resetLogo' ? '' : (typeof getLogo === 'function' ? getLogo('exb') : ''); lsSet(KB, p); } catch (e) {} };
        if (r && typeof r.then === 'function') r.then(sync); else sync();
        return r;
      };
      n.__ent = true; w[fn] = n;
    });
  }
  (function () { var n = 0, t = setInterval(function () { n++; try { hookLogoButtons(); onFileReset(); if (mount() || n > 400) clearInterval(t); } catch (e) { if (n > 400) clearInterval(t); } }, 900); })();

  return { get: get, save: save, open: open, close: close, exporter: exporter, importer: importer, nameUpper: nameUpper, isOrigin: isOrigin, slug: slug, ORIGIN: ORIGIN };
})(window, document);
