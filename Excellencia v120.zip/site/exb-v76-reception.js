/* Excellencia Building V76 — Réception de chantier : procès-verbal (PDF), réserves, dossier des ouvrages exécutés (DOE).
 * Stockage : exb_receptions (collection serveur « receptions »). Réserves lues dans exb_reserves (module V67). */
(function(w,d){'use strict';
var KEY='exb_receptions',COL='receptions',RES='exb_reserves';
var DOE=[['plans','Plans de récolement'],['notices','Notices d\u2019utilisation et d\u2019entretien'],['garanties','Garanties et certificats des équipements'],['essais','PV d\u2019essais et de contrôles'],['assurances','Attestations d\u2019assurance (décennale)'],['conformite','Attestations de conformité (électricité, sécurité incendie)']];
function load(){return w.EXBS.get(KEY)}
function save(a){return w.EXBS.set(KEY,a)}
function uid(){return 'REC-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6)}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}}
function canW(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL,'ecrire')}catch(e){return true}}
function canR(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL,'lire')}catch(e){return true}}
function pname(id){var p=w.EXBS.projects().find(function(x){return String(x.id)===String(id)});return p?(p.nom||p.name||p.titre||p.title||p.id):(id||'—')}
function lifted(r){return w.EXB77?w.EXB77.isLifted(r.status):/cl[oô]tur|lev/i.test(r.status||'')}
function reserves(pid){return w.EXBS.get(RES).filter(function(r){return String(r.project)===String(pid)})}
function frDate(s){if(!s)return '—';var m=/^(\d{4})-(\d\d)-(\d\d)/.exec(s);return m?m[3]+'/'+m[2]+'/'+m[1]:s}
function ui(){var badm=d.getElementById('badm');if(!badm||d.getElementById('exbV76RecBtn'))return;var b=d.createElement('button');b.id='exbV76RecBtn';b.className='muted';b.textContent='✅ Réception de chantier';b.onclick=panel;badm.parentNode.appendChild(b);rights()}
function rights(){var b=d.getElementById('exbV76RecBtn');if(!b)return;if(canR())b.removeAttribute('data-exbrole');else b.setAttribute('data-exbrole','hide')}
function panel(){var old=d.getElementById('exbV76RecPanel');if(old){old.remove();return}var p=d.createElement('div');p.id='exbV76RecPanel';p.style.cssText='position:fixed;inset:0;z-index:99998;background:#0006;display:flex;align-items:center;justify-content:center;padding:14px';p.onclick=function(e){if(e.target===p)p.remove()};
 p.innerHTML='<div style="background:#fff;color:#111;width:min(1000px,100%);max-height:92vh;overflow:auto;border-radius:16px;padding:18px"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><div><h2 style="margin:0">✅ Réception de chantier</h2><small>Procès-verbal · réserves · dossier des ouvrages exécutés (DOE)</small></div><button class="muted" id="v76x">✕</button></div><div style="margin:12px 0"><button class="primary smallbtn" id="v76new">+ Nouvelle réception</button></div><div id="v76list"></div></div>';d.body.appendChild(p);
 d.getElementById('v76x').onclick=function(){p.remove()};var nb=d.getElementById('v76new');nb.disabled=!canW();nb.onclick=function(){form()};
 p.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-a]');if(!b)return;var v=b.getAttribute('data-a').split('|');if(v[0]==='e')form(v[1]);else if(v[0]==='x')del(v[1]);else if(v[0]==='p')pdf(v[1])});render()}
function render(){var el=d.getElementById('v76list');if(!el)return;var a=load().slice().sort(function(x,y){return String(y.date).localeCompare(String(x.date))});
 if(!a.length){el.innerHTML='<p class="exb-muted">Aucune réception enregistrée.</p>';return}
 var w_=canW();el.innerHTML='<div style="overflow:auto"><table class="exb-table"><thead><tr><th>Projet</th><th>Type</th><th>Date</th><th>Décision</th><th>Réserves ouvertes</th><th>DOE</th><th></th></tr></thead><tbody>'+a.map(function(x){var rs=reserves(x.project),open=rs.filter(function(r){return !lifted(r)}).length,doeN=DOE.filter(function(k){return x.doe&&x.doe[k[0]]}).length;
  var late=x.lift_deadline&&open>0&&x.lift_deadline<new Date().toISOString().slice(0,10);
  return '<tr><td>'+esc(pname(x.project))+'</td><td>'+esc(x.kind)+'</td><td>'+esc(frDate(x.date))+'</td><td>'+esc(x.decision)+'</td><td style="color:'+(late?'#b00020':'inherit')+'">'+open+' / '+rs.length+(late?' ⏰ délai dépassé':'')+'</td><td>'+doeN+' / '+DOE.length+'</td><td style="white-space:nowrap"><button class="primary smallbtn" data-a="p|'+esc(x.id)+'">📄 PV</button> '+(w_?'<button class="muted smallbtn" data-a="e|'+esc(x.id)+'">✎</button> <button class="danger smallbtn" data-a="x|'+esc(x.id)+'">×</button>':'🔒')+'</td></tr>'}).join('')+'</tbody></table></div>'}
function sel(id,opts,val){return '<select id="'+id+'" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box">'+opts.map(function(o){var v=Array.isArray(o)?o[0]:o,l=Array.isArray(o)?o[1]:o;return '<option value="'+esc(v)+'"'+(String(v)===String(val)?' selected':'')+'>'+esc(l)+'</option>'}).join('')+'</select>'}
function form(id){if(!canW()){say('Droits insuffisants.','warn');return}var cur=id?load().find(function(x){return x.id===id}):null,c=cur||{kind:'provisoire',decision:'avec réserves',date:new Date().toISOString().slice(0,10),doe:{}},ps=w.EXBS.projects();
 var m=d.createElement('div');m.style.cssText='position:fixed;inset:0;z-index:99999;background:#0008;display:flex;align-items:center;justify-content:center;padding:14px';var L='display:block;margin:8px 0;font-size:13px',I='width:100%;padding:8px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box';
 m.innerHTML='<div style="background:#fff;color:#111;width:min(560px,100%);max-height:90vh;overflow:auto;border-radius:14px;padding:16px"><h3 style="margin:0 0 6px">'+(cur?'Modifier':'Nouvelle')+' réception</h3>'
 +'<label style="'+L+'"><b>Projet *</b>'+sel('v76p',[['','— choisir —']].concat(ps.map(function(p){return [p.id,p.nom||p.name||p.titre||p.title||p.id]})),c.project)+'</label>'
 +'<label style="'+L+'"><b>Type</b>'+sel('v76k',['provisoire','définitive'],c.kind)+'</label>'
 +'<label style="'+L+'"><b>Date de la réception *</b><input id="v76d" type="date" value="'+esc(c.date)+'" style="'+I+'"></label>'
 +'<label style="'+L+'"><b>Décision</b>'+sel('v76dec',['sans réserve','avec réserves','refusée'],c.decision)+'</label>'
 +'<label style="'+L+'"><b>Délai de levée des réserves</b><input id="v76dl" type="date" value="'+esc(c.lift_deadline||'')+'" style="'+I+'"></label>'
 +'<label style="'+L+'"><b>Personnes présentes (nom, fonction)</b><textarea id="v76pr" rows="3" style="'+I+'">'+esc(c.present||'')+'</textarea></label>'
 +'<label style="'+L+'"><b>Observations</b><textarea id="v76ob" rows="3" style="'+I+'">'+esc(c.observations||'')+'</textarea></label>'
 +'<div style="font-size:13px"><b>Dossier des ouvrages exécutés (DOE) remis</b>'+DOE.map(function(k){return '<label style="display:block;margin:4px 0"><input type="checkbox" id="v76doe_'+k[0]+'"'+(c.doe&&c.doe[k[0]]?' checked':'')+'> '+esc(k[1])+'</label>'}).join('')+'</div>'
 +'<div id="v76err" style="color:#b00020;font-size:13px;min-height:18px"></div><div style="display:flex;gap:8px;justify-content:flex-end"><button class="muted" id="v76c">Annuler</button><button class="primary" id="v76s">Enregistrer</button></div></div>';d.body.appendChild(m);
 d.getElementById('v76c').onclick=function(){m.remove()};
 d.getElementById('v76s').onclick=function(){var o={project:d.getElementById('v76p').value,kind:d.getElementById('v76k').value,date:d.getElementById('v76d').value,decision:d.getElementById('v76dec').value,lift_deadline:d.getElementById('v76dl').value,present:d.getElementById('v76pr').value.trim(),observations:d.getElementById('v76ob').value.trim(),doe:{}};
  DOE.forEach(function(k){o.doe[k[0]]=d.getElementById('v76doe_'+k[0]).checked});var err=!o.project?'Choisissez un projet.':!o.date?'Indiquez la date.':(o.lift_deadline&&o.lift_deadline<o.date?'Le délai de levée précède la date de réception.':'');
  if(err){d.getElementById('v76err').textContent=err;return}
  var a=load();if(cur){var i=a.findIndex(function(x){return x.id===id});a[i]=Object.assign({},cur,o,{updated_at:new Date().toISOString()})}else a.push(Object.assign({id:uid(),created_at:new Date().toISOString()},o));
  if(save(a)){m.remove();render();say('Réception enregistrée.')}}}
async function del(id){if(!canW())return;if(!(await exbConfirm('Supprimer cette réception ?')))return;save(load().filter(function(x){return x.id!==id}));render()}
function pdf(id){var x=load().find(function(r){return r.id===id});if(!x)return;if(!w.EXBPdf){say('Module PDF indisponible.','warn');return}
 var rs=reserves(x.project),open=rs.filter(function(r){return !lifted(r)}),notes=[];
 notes.push(x.decision==='sans réserve'?'Le maître d\u2019ouvrage prononce la réception des travaux SANS réserve.':x.decision==='refusée'?'Le maître d\u2019ouvrage REFUSE la réception des travaux en l\u2019état.':'Le maître d\u2019ouvrage prononce la réception des travaux AVEC les réserves listées ci-dessous'+(x.lift_deadline?', à lever avant le '+frDate(x.lift_deadline)+'.':'.'));
 if(open.length){notes.push('RÉSERVES À LEVER ('+open.length+') :');open.forEach(function(r,i){notes.push((i+1)+'. '+(r.name||r.title||'(sans libellé)')+' — '+(r.status||'Ouverte'))})}else notes.push('Aucune réserve ouverte enregistrée pour ce projet.');
 notes.push('');notes.push('Le maître d\u2019ouvrage : ______________________          L\u2019entreprise : ______________________          Le maître d\u2019œuvre : ______________________');
 var imgs=[];open.forEach(function(r){(r.photos||[]).forEach(function(p){if(imgs.length<6&&p)imgs.push(p)})});
 var rows=[['Projet',pname(x.project)],['Type de réception',x.kind],['Date',frDate(x.date)],['Décision',x.decision],['Personnes présentes',x.present||'—'],['Observations',x.observations||'—'],['Réserves',open.length+' ouverte(s) sur '+rs.length],['Dossier des ouvrages exécutés (DOE)',DOE.map(function(k){return (x.doe&&x.doe[k[0]]?'[x] ':'[ ] ')+k[1]}).join('\n')]];
 w.EXBPdf.make({titre:'PROCÈS-VERBAL DE RÉCEPTION',sousTitre:pname(x.project)+' · '+frDate(x.date),rows:rows,notes:notes,images:imgs,footer:'PV de réception · '+pname(x.project)}).then(function(b){w.EXBPdf.save(b,'PV-reception-'+String(pname(x.project)).replace(/[^\w-]+/g,'_')+'-'+(x.date||'')+'.pdf')}).catch(function(){say('Création du PDF impossible.','warn')})}
w.EXBREC={panel:panel,pdf:pdf,load:load,key:KEY,collection:COL,doe:DOE};
w.addEventListener('exb-rights',rights);
d.addEventListener('DOMContentLoaded',function(){setTimeout(ui,1200)});
})(window,document);
