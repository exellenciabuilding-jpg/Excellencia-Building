/* Excellencia Building V78 — Finance projet en USD et FC : taux du jour, devis → situation → facture → paiement.
 * Stockage : exb_finance (collection serveur « finance »). Chaque montant garde sa devise ; le taux (FC pour 1 USD) est enregistré avec lui. */
(function(w,d){'use strict';
var KEY='exb_finance',COL='finance',L={devis:'Devis',situation:'Situation',facture:'Facture',paiement:'Paiement'},PX={devis:'D',situation:'S',facture:'F',paiement:'P'},
 MODES=['Espèces','Virement','M-Pesa','Airtel Money','Orange Money','Chèque'],st={pid:'',disp:'USD'};
try{st.disp=localStorage.getItem('exb_fin_disp')||'USD'}catch(e){}
function load(){return w.EXBS.get(KEY)}function save(a){return w.EXBS.set(KEY,a)}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}}
function canR(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL,'lire')}catch(e){return true}}
function canW(){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(COL,'ecrire')}catch(e){return true}}
function today(){return new Date().toISOString().slice(0,10)}
function projs(){try{return w.EXBS.projects()}catch(e){return[]}}
function pn(p){return p.nom||p.name||p.titre||p.title||p.id}
function fmt(n,c){if(n==null||isNaN(n))return '—';return new Intl.NumberFormat('fr-FR',{minimumFractionDigits:c==='USD'?2:0,maximumFractionDigits:c==='USD'?2:0}).format(n)+(c==='USD'?' $':' FC')}
function rateAt(date){var r=0,t=load().filter(function(x){return x.type==='taux'&&x.rate>0}).sort(function(a,b){return a.date<b.date?-1:1});t.forEach(function(x){if(x.date<=date)r=x.rate});return r||(t.length?t[t.length-1].rate:0)}
function conv(x,disp){var a=Number(x.ttc)||0;if(x.cur===disp)return a;var r=Number(x.rate)||0;if(!r)return null;return disp==='FC'?a*r:a/r}
function sum(L2,disp){var v=0,m=0;L2.forEach(function(x){var c=conv(x,disp);if(c==null)m++;else v+=c});return{v:v,m:m}}
function docs(t){return load().filter(function(x){return x.type===t&&String(x.project)===String(st.pid)})}
function nextNo(t){var y=new Date().getFullYear(),n=load().filter(function(x){return x.type===t&&String(x.no||'').indexOf(PX[t]+'-'+y)===0}).length+1;return PX[t]+'-'+y+'-'+String(n).padStart(3,'0')}
function paid(f){return load().filter(function(x){return x.type==='paiement'&&x.parent===f.id})}
function open(){if(!canR())return say('Accès non autorisé.','error');var P=projs();if(!st.pid)st.pid=localStorage.getItem('exb_active_project')||(P[0]&&P[0].id)||'';draw()}
function draw(){var o=d.getElementById('exbFin');if(!o){o=d.createElement('div');o.id='exbFin';o.style.cssText='position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';o.onclick=function(e){if(e.target===o)o.remove()};d.body.appendChild(o)}
 var disp=st.disp,r0=rateAt(today()),dv=docs('devis'),acc=dv.filter(function(x){return x.status==='accepté'}),fa=docs('facture'),pa=[];fa.forEach(function(f){pa=pa.concat(paid(f))});
 var B=sum(acc,disp),S=sum(docs('situation'),disp),F=sum(fa,disp),E=sum(pa,disp),miss=B.m+S.m+F.m+E.m,card=function(t,v){return '<div style="flex:1 1 45%;background:#f1f5fb;border-radius:10px;padding:8px"><div style="font-size:12px;color:#64748b">'+t+'</div><b>'+fmt(v,disp)+'</b></div>'};
 var h='<div style="background:#fff;border-radius:14px;padding:16px;max-width:760px;width:100%;font:14px Arial;color:#172033"><div style="display:flex;justify-content:space-between"><b style="font-size:17px">💱 Finance projet (USD / FC)</b><button onclick="document.getElementById(\'exbFin\').remove()">✕</button></div>'
 +'<div style="margin:8px 0"><select onchange="EXBFIN.proj(this.value)" style="padding:8px;max-width:100%">'+projs().map(function(p){return '<option value="'+esc(p.id)+'"'+(String(p.id)===String(st.pid)?' selected':'')+'>'+esc(pn(p))+'</option>'}).join('')+'</select> '
 +'<button onclick="EXBFIN.cur(\'USD\')" style="padding:8px;font-weight:'+(disp==='USD'?'700':'400')+'">$ USD</button><button onclick="EXBFIN.cur(\'FC\')" style="padding:8px;font-weight:'+(disp==='FC'?'700':'400')+'">FC</button></div>'
 +'<div style="background:#fff7e6;border-radius:10px;padding:8px;margin-bottom:8px">Taux du jour : <b>1 $ = '+(r0?fmt(r0,'FC'):'non défini')+'</b>'+(canW()?' · <input id="finRate" type="number" step="any" placeholder="FC pour 1 $" style="width:110px;padding:6px"> <button onclick="EXBFIN.taux()">Enregistrer</button>':'')+'</div>'
 +(miss?'<div style="background:#fde8e8;padding:8px;border-radius:10px;margin-bottom:8px">⚠ '+miss+' document(s) sans taux : montant non converti, non compté.</div>':'')
 +'<div style="display:flex;flex-wrap:wrap;gap:6px">'+card('Budget (devis acceptés)',B.v)+card('Situations',S.v)+card('Facturé',F.v)+card('Encaissé',E.v)+card('Reste à encaisser',F.v-E.v)+card('Reste à facturer',B.v-F.v)+'</div>'
 +(canW()?'<p><button onclick="EXBFIN.form(\'devis\')" style="padding:9px">➕ Nouveau devis</button></p>':'');
 ['devis','situation','facture'].forEach(function(t){var A=docs(t);h+='<h3 style="margin:14px 0 4px">'+({devis:'Devis',situation:'Situations',facture:'Factures'})[t]+'</h3>'+(A.length?A.map(function(x){var cv=x.cur===disp?'':' ≈ '+fmt(conv(x,disp),disp),act='';
  if(canW()){if(t==='devis'){act=(x.status!=='accepté'?'<button onclick="EXBFIN.accept(\''+x.id+'\')">✔ Accepter</button> ':'<button onclick="EXBFIN.form(\'situation\',\''+x.id+'\')">→ Situation</button> ')}
   if(t==='situation')act='<button onclick="EXBFIN.form(\'facture\',\''+x.id+'\')">→ Facture</button> ';
   if(t==='facture'){var rest=(Number(x.ttc)||0)-paid(x).reduce(function(a,p){var c=conv(p,x.cur);return a+(c||0)},0);act='<button onclick="EXBFIN.form(\'paiement\',\''+x.id+'\')">→ Paiement</button> <span style="color:#64748b">reste '+fmt(Math.max(0,rest),x.cur)+'</span> '}
   act+='<button onclick="EXBFIN.del(\''+x.id+'\')">🗑</button>'}
  var pays=t==='facture'?paid(x).map(function(p){return '<div style="margin-left:14px;color:#475569">↳ '+esc(p.no)+' · '+esc(p.date)+' · '+fmt(p.ttc,p.cur)+' ('+esc(p.mode||'')+(p.ref?' '+esc(p.ref):'')+')</div>'}).join(''):'';
  return '<div style="border-bottom:1px solid #e2e8f0;padding:6px 0"><b>'+esc(x.no)+'</b> · '+esc(x.date)+(x.status?' · '+esc(x.status):'')+'<br>'+fmt(x.ttc,x.cur)+' <small>(HT '+fmt(x.ht,x.cur)+', TVA '+(x.tva||0)+' %)</small>'+cv+'<br>'+act+pays+'</div>'}).join(''):'<div style="color:#64748b">Aucun.</div>')});
 h+='<p style="font-size:12px;color:#64748b">Le taux est figé sur chaque document à sa date : un montant ne change pas quand le taux bouge.</p></div>';o.innerHTML=h}
function form(t,pid){var par=pid?load().find(function(x){return x.id===pid}):null,r=rateAt(today()),v=par?(t==='facture'?par.ht:(t==='situation'?'':'')):'',o=d.createElement('div');o.id='exbFinF';o.style.cssText='position:fixed;inset:0;z-index:99999;background:#0008;display:flex;align-items:center;justify-content:center;padding:12px';
 var pay=t==='paiement',rest=0;if(pay&&par){rest=(Number(par.ttc)||0)-paid(par).reduce(function(a,p){return a+(conv(p,par.cur)||0)},0);v=Math.max(0,Math.round(rest*100)/100)}
 o.innerHTML='<div style="background:#fff;border-radius:14px;padding:16px;width:100%;max-width:420px;font:14px Arial;color:#172033"><b>'+L[t]+(par?' — depuis '+esc(par.no):'')+'</b>'
 +'<p>N°<br><input id="ffNo" value="'+nextNo(t)+'" style="width:100%;padding:8px"></p><p>Date<br><input id="ffD" type="date" value="'+today()+'" style="width:100%;padding:8px"></p>'
 +'<p>Devise<br><select id="ffC" style="width:100%;padding:8px"><option'+(par&&par.cur==='FC'?'':' selected')+'>USD</option><option'+(par&&par.cur==='FC'?' selected':'')+'>FC</option></select></p>'
 +'<p>'+(pay?'Montant payé':'Montant HT')+'<br><input id="ffH" type="number" step="any" value="'+v+'" style="width:100%;padding:8px"></p>'
 +(pay?'<p>Mode<br><select id="ffM" style="width:100%;padding:8px">'+MODES.map(function(m){return '<option>'+m+'</option>'}).join('')+'</select></p><p>Référence de transaction<br><input id="ffR" style="width:100%;padding:8px"></p>':'<p>TVA (%)<br><input id="ffT" type="number" step="any" value="'+(par?par.tva:16)+'" style="width:100%;padding:8px"></p>')
 +'<p>Taux (FC pour 1 $)<br><input id="ffX" type="number" step="any" value="'+(r||'')+'" style="width:100%;padding:8px"></p>'
 +'<button onclick="EXBFIN.save(\''+t+'\',\''+(pid||'')+'\')" style="padding:10px 16px">Enregistrer</button> <button onclick="document.getElementById(\'exbFinF\').remove()" style="padding:10px 16px">Annuler</button></div>';d.body.appendChild(o)}
function saveDoc(t,pid){var g=function(i){return d.getElementById(i)},ht=Number(g('ffH').value),rate=Number(g('ffX').value)||0,tva=t==='paiement'?0:Number(g('ffT').value)||0;
 if(!(ht>0))return say('Montant obligatoire.','error');if(!rate)return say('Indiquez le taux du jour (FC pour 1 $).','error');
 var x={id:'FIN-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6),type:t,project:st.pid,no:g('ffNo').value.trim(),date:g('ffD').value||today(),cur:g('ffC').value,ht:ht,tva:tva,ttc:Math.round(ht*(1+tva/100)*100)/100,rate:rate,parent:pid||''};
 if(t==='devis')x.status='brouillon';if(t==='paiement'){x.mode=g('ffM').value;x.ref=g('ffR').value.trim()}
 var a=load();a.push(x);save(a);g('exbFinF').remove();draw()}
function taux(){var v=Number(d.getElementById('finRate').value);if(!(v>0))return say('Taux invalide.','error');var a=load();a.push({id:'FIN-'+Date.now().toString(36),type:'taux',date:today(),rate:v});save(a);draw()}
w.EXBFIN={open:open,proj:function(v){st.pid=v;draw()},cur:function(c){st.disp=c;try{localStorage.setItem('exb_fin_disp',c)}catch(e){}draw()},taux:taux,form:form,save:saveDoc,
 accept:function(id){var a=load();a.forEach(function(x){if(x.id===id)x.status='accepté'});save(a);draw()},
 del:async function(id){if(!(await exbConfirm('Supprimer ce document ?')))return;save(load().filter(function(x){return x.id!==id&&x.parent!==id}));draw()}};
function ui(){var b=d.getElementById('badm');if(!b||d.getElementById('exbFinBtn'))return;var k=d.createElement('button');k.id='exbFinBtn';k.className='muted';k.textContent='💱 Finance USD / FC';k.onclick=open;if(!canR())k.setAttribute('data-exbrole','hide');b.parentNode.appendChild(k)}
new MutationObserver(ui).observe(d.documentElement,{childList:true,subtree:true});d.addEventListener('DOMContentLoaded',ui);
})(window,document);
