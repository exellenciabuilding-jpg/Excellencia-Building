/* exb-brand.js — Personnalisation (marque blanche) + aide intégrée.
 * Charge APRÈS brand-config.js, supabase-config.js / config.js, et AVANT le code de l'application.
 * 1) Au premier lancement : écran de configuration (nom, logo, couleurs, contact, serveur).
 * 2) Remplace partout le nom d'origine par celui de l'entreprise (écran, PDF, noms de fichiers).
 * 3) Bouton ❓ : guide pas à pas (inscrire une personne, etc.), fonctionne hors ligne. */
(function () {
  'use strict';
  var KEY = 'EXB_BRAND_V1';
  var ORIGIN = { name: 'Excellencia Building', chantier: 'Excellencia Chantier', short: 'Excellencia', primary: '#173565', accent: '#c49a38' };
  /* ── Fichier d'identité déposé avec le site (entreprise.json, produit par Paramètres › Identité de l'entreprise).
   *    Il s'applique aussi dans l'APK et l'application Windows (le fichier est embarqué à la compilation).
   *    Priorité : réglages saisis sur l'appareil > entreprise.json > valeurs d'origine. */
  var SCRIPT_BASE = ''; try { SCRIPT_BASE = (document.currentScript && document.currentScript.src || '').replace(/[^\/]*$/, ''); } catch (e) {}
  var FILE = null, FILE_TXT = '', FILE_OFFLINE = false;
  try {
    var xf = new XMLHttpRequest(); xf.open('GET', (SCRIPT_BASE || '') + 'entreprise.json?t=' + Math.floor(Date.now() / 60000), false); xf.send();
    if (xf.status === 200 || (xf.status === 0 && xf.responseText)) { FILE_TXT = xf.responseText; var fj = JSON.parse(FILE_TXT); fj = fj && (fj.data || fj); if (fj && fj.name) FILE = fj; }
    if (xf.status === 0 && !xf.responseText) FILE_OFFLINE = true;
  } catch (e) { FILE_OFFLINE = true; }
  if (!FILE && FILE_OFFLINE) { try { var cj = localStorage.getItem('EXB_ENTREPRISE_FILE'); if (cj) { var cf = JSON.parse(cj); if (cf && cf.name) FILE = cf; } } catch (e) {} }
  if (FILE) {
    if (!FILE.short) FILE.short = String(FILE.name).split(/\s+/)[0]; if (!FILE.chantier) FILE.chantier = FILE.name + ' Chantier';
    if (FILE.logo && !/^(data:|https?:|\/)/.test(FILE.logo)) FILE.logo = SCRIPT_BASE + FILE.logo;
    try {
      localStorage.setItem('EXB_ENTREPRISE_FILE', JSON.stringify(FILE));
      var sig = String(FILE_TXT.length) + ':' + FILE_TXT.split('').reduce(function (h, ch) { return (h * 31 + ch.charCodeAt(0)) | 0; }, 7);
      if (FILE_TXT && localStorage.getItem('EXB_ENTREPRISE_SIG') !== sig) {
        /* nouvelle version du fichier déposé : elle remplace les anciens réglages de l'appareil */
        localStorage.removeItem('EXB_BRAND_V1'); localStorage.removeItem('EXB_IDENTITE_V1'); localStorage.removeItem('EXB_PUBLIC_URL_V1');
        window.EXB_FILE_RESET = true;
        var idn = {}; ['city', 'legal', 'footer', 'website', 'dg', 'dgRole', 'phone', 'email', 'address'].forEach(function (k) { if (FILE[k]) idn[k] = FILE[k]; });
        localStorage.setItem('EXB_IDENTITE_V1', JSON.stringify(idn));
        if (FILE.publicUrl) localStorage.setItem('EXB_PUBLIC_URL_V1', String(FILE.publicUrl).replace(/\/+$/, ''));
        localStorage.setItem('EXB_ENTREPRISE_SIG', sig);
      }
    } catch (e) {}
    window.EXB_BRAND_DEFAULT = Object.assign({}, window.EXB_BRAND_DEFAULT || {}, FILE, { setupRequired: false });
    if (FILE.publicUrl) window.EXB_PUBLIC_URL = String(FILE.publicUrl).replace(/\/+$/, '');
  }
  var D = Object.assign({
    name: ORIGIN.name, short: ORIGIN.short, chantier: ORIGIN.chantier, tagline: '',
    primary: ORIGIN.primary, secondary: '#0f4aa8', accent: ORIGIN.accent, logo: '',
    phone: '', email: '', address: '', supabaseUrl: '', supabaseKey: '', setupRequired: true
  }, window.EXB_BRAND_DEFAULT || {});
  var saved = {}, done = false, fixed = false;
  try { var raw = JSON.parse(localStorage.getItem(KEY) || 'null'); if (raw) { saved = raw.brand || {}; done = !!raw.done; fixed = !!raw.fixed; } } catch (e) {}
  /* V99c — pages publiques (inscription, apprenant, épreuve, résultats, demande TP/TD, formateur, client, personnel) : jamais d'écran de configuration pour le visiteur.
   * L'écran « Configurez le logiciel à votre entreprise » est réservé à l'administrateur de l'application et à la page des demandeurs du logiciel (logiciel.html).
   * L'identité (nom, logo, couleurs, contacts) enregistrée par l'administrateur est publiée via l'onglet « Site vitrine » (brand.json). */
  var PORTAL = /\/(inscription|apprenant|epreuve|resultats|demande-tp-td|formateur|client|personnel)(\.html)?\/?$/.test(location.pathname);
  /* pages annexes (TFL, espaces, vérification, outils…) : identité appliquée, jamais d'écran de configuration ni de bouton d'aide */
  var LIGHT = /\/(tfl-[a-z-]+|espace-[a-z]+|verification|suivi-chantier|portail|formulaire-hors-connexion|formulaires-publics|centre-documentaire|carte-visite|plan-editeur\/[a-z-]+|calcul-structure\/[a-z-]+|site-vitrine\/[a-z-]+)(\.html)?\/?$/.test(location.pathname);
  if (LIGHT) PORTAL = true;
  if (PORTAL && !done) {
    try {
      var S0 = window.EXB_SUPABASE || {}, RK = 'EXB_BRAND_REMOTE', rb = null;
      if (S0.url) { try { var x0 = new XMLHttpRequest(); x0.open('GET', String(S0.url).replace(/\/+$/, '') + '/storage/v1/object/public/vitrine/brand.json?t=' + Date.now(), false); x0.send(); if (x0.status === 200) { rb = JSON.parse(x0.responseText); localStorage.setItem(RK, x0.responseText); } } catch (e) {} }
      if (!rb) { try { rb = JSON.parse(localStorage.getItem(RK) || 'null'); } catch (e) {} }
      if (rb && rb.name) saved = rb;
    } catch (e) {}
    done = true; fixed = true;
  }
  var B = Object.assign({}, D, saved);
  window.EXB_BRAND = B;
  /* logo de l'entreprise, utilisable partout (PDF, impressions, reçus) */
  window.exbLogoSrc = function () {
    try { var b = window.EXB_BRAND || {}; if (b.logo) return b.logo; var l = localStorage.getItem('exb_logo'); if (l && /^data:image/.test(l)) return l; } catch (e) {}
    return 'icon-192.png';
  };
  /* valeurs d'origine à remplacer dans les textes fixes, quand l'entreprise n'est plus l'originale */
  var OX = { phone: '+243 810 644 554', email: 'Excellenciabuilding@gmail.com', dg: 'Ir Ibwampere Ngwala Louis', tag: 'Ingénierie & Construction', host: 'excellenciabuildingsarlu001.netlify.app' };
  var XI = {}; try { XI = JSON.parse(localStorage.getItem('EXB_IDENTITE_V1') || '{}') || {}; } catch (e) {}
  var changed = B.name !== ORIGIN.name || B.chantier !== ORIGIN.chantier || B.short !== ORIGIN.short;
  /* V120j : un autre client ne doit JAMAIS envoyer de liens vers le site d'origine. Sans adresse publique saisie, on n'en garde aucune (le site hébergé utilise sa propre adresse). */
  try { if (changed && String(window.EXB_PUBLIC_URL || '').indexOf(OX.host) >= 0 && !localStorage.getItem('EXB_PUBLIC_URL_V1')) window.EXB_PUBLIC_URL = ''; } catch (e) {}

  /* ---------- serveur propre à l'entreprise ---------- */
  if (B.supabaseUrl && B.supabaseKey) {
    window.EXB_SUPABASE = window.EXB_SUPABASE || {};
    window.EXB_SUPABASE.url = B.supabaseUrl; window.EXB_SUPABASE.key = B.supabaseKey;
    if (window.EXB_FIELD_CONFIG) { window.EXB_FIELD_CONFIG.supabaseUrl = B.supabaseUrl; window.EXB_FIELD_CONFIG.supabaseKey = B.supabaseKey; window.EXB_FIELD_CONFIG.syncEnabled = true; }
  }

  /* ---------- remplacement des textes / couleurs ---------- */
  function slug(s) { return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, ''); }
  /* REP-BEGIN (V120j) — remplacement du nom d'origine par celui de l'entreprise, partout où du texte est affiché.
   * Corrige : e-mail d'origine mélangé au nom court (l'ordre comptait), MAJUSCULES / tirets / « SARLU » collé, « & » écrit « &amp; » dans le HTML,
   * téléphone écrit autrement. Les identifiants tout en minuscules (classes CSS, clés, noms de fichier) ne sont JAMAIS touchés ici. */
  function rxq(t) { return String(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function rxSep(t) { return rxq(t).replace(/ /g, '[ \\u00a0_-]+'); }
  function caseLike(m, v) {
    if (m === m.toLowerCase()) return m;                                  /* identifiant minuscule : intact */
    return (m === m.toUpperCase() && /[A-Z]/.test(m)) ? String(v).toUpperCase() : v;
  }
  var RXS = null;
  function rxset() {
    if (RXS) return RXS;
    RXS = {
      chantier: new RegExp(rxSep(ORIGIN.chantier), 'gi'),
      name: new RegExp(rxSep(ORIGIN.name) + '(?:[ \\u00a0]+SARLU?)?', 'gi'),
      short: new RegExp('\\b' + rxq(ORIGIN.short) + '\\b', 'gi'),
      phone: /\+?\s?243[\s.-]*810[\s.-]*644[\s.-]*554|\b0810[\s.-]*644[\s.-]*554\b|\b810[\s.-]*644[\s.-]*554\b|\b0?82[\s.-]*863[\s.-]*3708\b/g,
      email: new RegExp(rxq(OX.email), 'gi'),
      host: new RegExp(rxq(OX.host) + '|\\bexcellenciabuilding\\.com\\b', 'gi'),
      dg: new RegExp(rxq(OX.dg), 'g'),
      tag: new RegExp(rxq(OX.tag).replace('&', '(?:&|&amp;)'), 'g')
    };
    return RXS;
  }
  function rep(s) {
    if (typeof s !== 'string' || !s) return s;
    if (changed) {
      var R = rxset();
      try { var pu = String((window.exbOrigin ? window.exbOrigin() : window.EXB_PUBLIC_URL) || '').replace(/^https?:\/\//, '').replace(/\/+$/, ''); if (pu !== OX.host) s = s.replace(R.host, function () { return pu || 'adresse-de-votre-site'; }); } catch (e) {}
      s = s.replace(R.email, function () { return B.email || ''; }).replace(R.phone, function () { return B.phone || ''; })
           .replace(R.dg, function () { return XI.dg || ''; }).replace(R.tag, function () { return B.tagline || ''; });
      /* V120t : le nom du client peut contenir le nom d'origine (« Excellencia Démo ») : on masque les noms déjà remplacés pour que le remplacement soit idempotent (sinon boucle infinie de l'observateur) */
      var KEEP = [B.chantier, B.name, B.short].filter(function (x) { return x && String(x).length > 2; }).sort(function (a, b) { return b.length - a.length; });
      var SAVED = [];
      KEEP.forEach(function (k) { s = s.replace(new RegExp(rxq(k), 'gi'), function (m) { SAVED.push(m); return '\u0001' + (SAVED.length - 1) + '\u0001'; }); });
      var ph = function (v) { SAVED.push(v); return '\u0001' + (SAVED.length - 1) + '\u0001'; };   /* la valeur insérée n'est plus re-remplacée par l'étape suivante */
      s = s.replace(R.chantier, function (m) { return ph(caseLike(m, B.chantier)); }).replace(R.name, function (m) { return ph(caseLike(m, B.name)); })
           .replace(R.short, function (m) { return ph(caseLike(m, B.short)); });
      s = s.replace(/\u0001(\d+)\u0001/g, function (m, i) { return SAVED[+i]; });
    }
    if (B.primary !== ORIGIN.primary) s = s.split(ORIGIN.primary).join(B.primary).split('#12305e').join(B.primary);
    if (B.accent !== ORIGIN.accent) s = s.split(ORIGIN.accent).join(B.accent);
    return s;
  }
  /* REP-END */
  /* V120g : remplacement exposé aux moteurs d'impression (iframe srcdoc / blob : hors de portée du remplacement innerHTML) */
  window.exbRebrand = function (v) { return typeof v === 'string' ? rep(v) : v; };
  /* V120j : même remplacement sur une structure entière (charge utile d'un PDF : titres, tableaux, pieds de page…). Les images (data:) et objets non simples sont laissés intacts. */
  /* DEEP-BEGIN */
  window.exbRebrandDeep = function deep(v, n) {
    n = n || 0; if (n > 12) return v;
    if (typeof v === 'string') return /^data:/i.test(v) ? v : rep(v);
    if (Array.isArray(v)) { var r = v.map(function (x) { return deep(x, n + 1); }); Object.keys(v).forEach(function (k) { if (isNaN(k)) r[k] = v[k]; }); return r; }
    if (v && typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype) { var o = {}; Object.keys(v).forEach(function (k) { o[k] = deep(v[k], n + 1); }); return o; }
    return v;
  };
  /* DEEP-END */
  var active = changed || B.primary !== ORIGIN.primary || B.accent !== ORIGIN.accent;
  var ATTRS = ['alt', 'title', 'placeholder', 'content', 'style', 'aria-label', 'data-title'];
  function fixNode(n) {
    if (!active || !n) return;
    if (n.nodeType === 3) { var p = n.parentNode && n.parentNode.nodeName; if (p === 'SCRIPT') return; var v = rep(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; return; }
    if (n.nodeType !== 1 || n.nodeName === 'SCRIPT') return;
    /* champs de saisie préremplis dans le HTML (nom, téléphone, e-mail d'origine) : remplacés tant que l'utilisateur ne les a pas modifiés */
    if (n.nodeName === 'INPUT' && n.hasAttribute('value') && /^(text|search|tel|email|url)?$/i.test(n.getAttribute('type') || '')) {
      var ov = n.getAttribute('value'), nv = rep(ov);
      if (nv !== ov) { var untouched = n.value === ov; n.setAttribute('value', nv); if (untouched) n.value = nv; }
    }
    ATTRS.forEach(function (a) { if (n.hasAttribute && n.hasAttribute(a)) { var o = n.getAttribute(a), v = rep(o); if (v !== o) n.setAttribute(a, v); } });
    /* liens : jamais vers le site ni le WhatsApp d'origine chez un autre client */
    if (changed && n.nodeName === 'A' && n.hasAttribute('href')) {
      var oh = n.getAttribute('href'), nh = oh;
      try {
        var hostNow = String((window.exbOrigin ? window.exbOrigin() : '') || '').replace(/^https?:\/\//, '').replace(/\/+$/, '') || location.host;
        nh = nh.replace(/excellenciabuildingsarlu0{1,2}1\.netlify\.app|excellenciabuilding\.com/gi, hostNow);
        nh = nh.replace(/(wa\.me\/|tel:\+?)243810644554/i, function (m, pre) { return pre + String(B.phone || '').replace(/\D/g, ''); });
        nh = nh.replace(/Excellenciabuilding@gmail\.com/gi, B.email || '');
      } catch (e) {}
      if (nh !== oh) n.setAttribute('href', nh);
    }
    for (var c = n.firstChild; c; c = c.nextSibling) fixNode(c);
  }
  /* documents générés par l'appli (PDF, certificats, formulaires) : on corrige le HTML à l'écriture */
  if (active) {
    try {
      var d = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
      if (d && d.set) Object.defineProperty(Element.prototype, 'innerHTML', { configurable: true, enumerable: d.enumerable, get: d.get, set: function (v) { d.set.call(this, typeof v === 'string' ? rep(v) : v); } });
      var dl = Object.getOwnPropertyDescriptor(HTMLAnchorElement.prototype, 'download');
      if (dl && dl.set) Object.defineProperty(HTMLAnchorElement.prototype, 'download', { configurable: true, enumerable: dl.enumerable, get: dl.get, set: function (v) {
        v = String(v).replace(/Excellencia[- ]Building/gi, slug(B.name)).replace(/Excellencia[- ]Chantier/gi, slug(B.chantier)).replace(/excellencia/gi, slug(B.short)); dl.set.call(this, v); } });
    } catch (e) {}
  }

  if (active) ['alert', 'confirm', 'prompt'].forEach(function (f) { var o = window[f]; if (typeof o === 'function') window[f] = function (m, d) { return o.call(window, rep(String(m == null ? '' : m)), d); }; });

  function applyLogoTo(img) { if (B.logo && img && img.src !== B.logo) img.src = B.logo; }
  var LOGO_IDS = ['brandLogoHeader', 'loginLogo', 'certLogoExb', 'bulkLogoExb', 'receiptLogoExb', 'exbLogoPreview', 'exbLogoPreview2'];
  function isLogo(img) { return img && img.tagName === 'IMG' && (LOGO_IDS.indexOf(img.id) >= 0 || /(^|\/)icon-(192|512)\.png$/.test(img.getAttribute('src') || '')); }

  function applyDom() {
    document.title = rep(document.title);
    var tc = document.querySelector('meta[name=theme-color]'); if (tc) tc.setAttribute('content', B.primary);
    if (B.logo) document.querySelectorAll('link[rel~=icon],link[rel=apple-touch-icon]').forEach(function (l) { l.setAttribute('href', B.logo); });
    var at = document.querySelector('meta[name=apple-mobile-web-app-title]'); if (at) at.setAttribute('content', B.short);
    /* V120j : balises de partage / description (aperçu WhatsApp, moteurs de recherche) */
    document.querySelectorAll('meta[name=description],meta[property^="og:"],meta[name^="twitter:"]').forEach(function (m) { var o = m.getAttribute('content'), v = rep(o || ''); if (o && v !== o) m.setAttribute('content', v); });
    var root = document.documentElement.style;
    root.setProperty('--blue', B.primary); root.setProperty('--blue2', B.secondary); root.setProperty('--n', B.primary); root.setProperty('--g', B.accent);
    document.querySelectorAll('style').forEach(function (s) { var o = s.textContent, v = rep(o); if (v !== o) s.textContent = v; });
    fixNode(document.body);
    document.querySelectorAll('img').forEach(function (i) { if (isLogo(i)) applyLogoTo(i); });
    // champs d'affiche : nom en deux parties
    var parts = B.name.split(/\s+/), dark = document.getElementById('p_company_dark'), light = document.getElementById('p_company_light');
    if (dark && dark.value === ORIGIN.short) dark.value = parts[0];
    if (light && light.value === 'Building') light.value = parts.slice(1).join(' ');
    [['p_contact_phone', B.phone], ['p_contact_email', B.email], ['p_contact_address', B.address]].forEach(function (x) { var e = document.getElementById(x[0]); if (e && x[1] && !e.dataset.exbSet) { e.value = x[1]; e.dataset.exbSet = 1; } });
  }
  /* V121e : seul le logiciel de l'équipe (index.html / racine) est installable ; toutes les autres pages (apprenants, clients, formateurs, TFL, formulaires, portails, vérification…) n'ont pas de manifeste : ni « Installer » ni appli autonome dans Chrome */
  var NOINST = !/^(index(\.html)?)?$/i.test((location.pathname.split('/').filter(Boolean).pop() || ''));
  function manifest() {
    try {
      if (NOINST) { var o = document.querySelector('link[rel=manifest]'); if (o) o.remove(); return; }
      var icons = B.logo ? [{ src: B.logo, sizes: '512x512', type: B.logo.slice(5, B.logo.indexOf(';')) }] : [];
      var base = location.href.replace(/[^\/]*$/, '');
      if (!icons.length) icons = [{ src: base + 'icon-192.png', sizes: '192x192', type: 'image/png' }, { src: base + 'icon-512.png', sizes: '512x512', type: 'image/png' }];
      var m = { name: document.title || B.name, short_name: B.short, start_url: base, scope: base, display: 'standalone', background_color: '#ffffff', theme_color: B.primary, icons: icons };
      var l = document.querySelector('link[rel=manifest]'); if (!l) { l = document.createElement('link'); l.rel = 'manifest'; document.head.appendChild(l); }
      l.href = URL.createObjectURL(new Blob([JSON.stringify(m)], { type: 'application/manifest+json' }));
    } catch (e) {}
  }
  function observe() {
    if (!window.MutationObserver) return;
    var busy = false;
    new MutationObserver(function (list) {
      if (busy) return; busy = true;
      list.forEach(function (m) {
        if (m.type === 'childList') m.addedNodes.forEach(function (n) { if (n.id === 'exbBrandUI') return; fixNode(n); if (n.querySelectorAll) n.querySelectorAll('img').forEach(function (i) { if (isLogo(i)) applyLogoTo(i); }); if (isLogo(n)) applyLogoTo(n); });
        else if (m.type === 'attributes' && isLogo(m.target)) applyLogoTo(m.target);
        else if (m.type === 'characterData') fixNode(m.target);
        else if (m.type === 'attributes' && m.attributeName === 'href') { if (m.target.nodeName === 'A') fixNode(m.target); }
      });
      busy = false;
    }).observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['src', 'href'] });
  }

  /* ---------- interface ---------- */
  function el(h) { var d = document.createElement('div'); d.innerHTML = h; return d.firstElementChild; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var CSS = '#exbBrandUI{position:fixed;inset:0;z-index:99990;background:rgba(15,23,42,.6);display:flex;align-items:center;justify-content:center;font:15px system-ui,sans-serif;color:#172033}' +
    '#exbBrandUI .bx{background:#fff;width:100%;max-width:520px;max-height:94vh;overflow:auto;border-radius:16px;padding:20px;box-sizing:border-box}' +
    '#exbBrandUI h2{margin:0 0 4px;color:' + B.primary + '}#exbBrandUI p.s{margin:0 0 12px;color:#64748b;font-size:13px}' +
    '#exbBrandUI label{display:block;font-weight:700;font-size:13px;margin:12px 0 4px}' +
    '#exbBrandUI input,#exbBrandUI textarea{width:100%;box-sizing:border-box;padding:11px;border:1px solid #cbd5e1;border-radius:10px;font:inherit}' +
    '#exbBrandUI input[type=color]{padding:2px;height:44px}#exbBrandUI .r{display:flex;gap:10px}#exbBrandUI .r>div{flex:1}' +
    '#exbBrandUI button.p{width:100%;margin-top:16px;padding:13px;border:0;border-radius:12px;background:' + B.primary + ';color:#fff;font-weight:700;font-size:15px}' +
    '#exbBrandUI button.g{width:100%;margin-top:8px;padding:11px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;font:inherit}' +
    '#exbBrandUI details{margin-top:14px;border:1px solid #e2e8f0;border-radius:10px;padding:8px 12px}#exbBrandUI summary{font-weight:700;cursor:pointer}' +
    '#exbBrandUI .lg{display:flex;align-items:center;gap:12px}#exbBrandUI .lg img{width:64px;height:64px;object-fit:contain;border:1px solid #e2e8f0;border-radius:10px}' +
    '#exbBrandUI .err{color:#b91c1c;font-size:13px;margin-top:8px}' +
    '#exbHelpBtn{position:fixed;left:12px;bottom:88px;z-index:99989;width:46px;height:46px;border-radius:50%;border:0;background:' + B.primary + ';color:#fff;font-size:22px;box-shadow:0 4px 14px #0004}' +
    '#exbBrandUI .tp{border:1px solid #e2e8f0;border-radius:12px;margin:8px 0;overflow:hidden}#exbBrandUI .tp>b{display:block;padding:11px 12px;cursor:pointer;background:#f8fafc}' +
    '#exbBrandUI .tp div{padding:4px 14px 12px;display:none;line-height:1.5}#exbBrandUI .tp.o div{display:block}#exbBrandUI .tp ol{padding-left:18px;margin:6px 0}';
  function injectCss() { var s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s); }
  function close() { var u = document.getElementById('exbBrandUI'); if (u) u.remove(); }

  function resizeLogo(file, cb) {
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, 512 / Math.max(im.width, im.height)), c = document.createElement('canvas');
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); cb(c.toDataURL('image/png'));
      };
      im.onerror = function () { cb(null); }; im.src = r.result;
    };
    r.readAsDataURL(file);
  }

  function setup(first) {
    if (window.EXBEntreprise && EXBEntreprise.open) { close(); EXBEntreprise.open(first); return; }  /* écran unique d'identité */
    close();
    var logo = B.logo || '';
    var ui = el('<div id="exbBrandUI"><div class="bx">' +
      '<h2>' + (first ? 'Bienvenue 👋' : 'Personnaliser') + '</h2><p class="s">' + (first ? 'Configurez le logiciel à votre entreprise en 1 minute. Vous pourrez tout modifier plus tard (Paramètres › Identité de l’entreprise).' : 'Modifiez l’identité de votre entreprise.') + '</p>' +
      '<label>Nom de l’entreprise *</label><input id="bn" value="' + esc(B.name === ORIGIN.name && first ? '' : B.name) + '" placeholder="Ex. Bâtiment Plus SARL">' +
      '<div class="r"><div><label>Nom court</label><input id="bs" value="' + esc(B.short === ORIGIN.short && first ? '' : B.short) + '" placeholder="Ex. Bâtiment Plus"></div>' +
      '<div><label>Nom de l’appli chantier</label><input id="bc" value="' + esc(B.chantier === ORIGIN.chantier && first ? '' : B.chantier) + '" placeholder="Ex. Bâtiment Plus Chantier"></div></div>' +
      '<label>Slogan (facultatif)</label><input id="bt" value="' + esc(B.tagline) + '">' +
      '<label>Logo</label><div class="lg"><img id="bl" src="' + esc(logo) + '" alt="" style="' + (logo ? '' : 'display:none') + '"><input id="bf" type="file" accept="image/png,image/jpeg,image/webp"></div>' +
      '<div class="r"><div><label>Couleur principale</label><input id="c1" type="color" value="' + B.primary + '"></div><div><label>Couleur boutons</label><input id="c2" type="color" value="' + B.secondary + '"></div><div><label>Couleur d’accent</label><input id="c3" type="color" value="' + B.accent + '"></div></div>' +
      '<div class="r"><div><label>Téléphone</label><input id="bp" value="' + esc(B.phone) + '"></div><div><label>E-mail</label><input id="be" value="' + esc(B.email) + '"></div></div>' +
      '<label>Adresse</label><input id="ba" value="' + esc(B.address) + '">' +
      '<details><summary>☁️ Serveur en ligne (facultatif)</summary><p class="s">Pour synchroniser plusieurs appareils. Laissez vide pour travailler uniquement sur cet appareil. Collez l’URL et la clé <b>publique</b> de VOTRE projet Supabase.</p>' +
      '<label>URL Supabase</label><input id="su" value="' + esc(B.supabaseUrl) + '" placeholder="https://xxxx.supabase.co"><label>Clé publique (anon / publishable)</label><input id="sk" value="' + esc(B.supabaseKey) + '"></details>' +
      '<div class="err" id="be2"></div><button class="p" id="bok">' + (first ? 'Enregistrer et démarrer' : 'Enregistrer') + '</button>' +
      (first ? '' : '<button class="g" id="bx">Annuler</button><button class="g" id="brs">Revenir aux réglages d’origine</button>') + '</div></div>');
    document.body.appendChild(ui);
    var $ = function (i) { return ui.querySelector('#' + i); };
    $('bf').onchange = function () { var f = this.files[0]; if (!f) return; resizeLogo(f, function (u) { if (!u) { $('be2').textContent = 'Image illisible.'; return; } logo = u; $('bl').src = u; $('bl').style.display = ''; }); };
    $('bn').oninput = function () { if (!$('bs').dataset.t) $('bs').value = this.value.split(/\s+/)[0] || ''; if (!$('bc').dataset.t) $('bc').value = this.value ? this.value + ' Chantier' : ''; };
    $('bs').oninput = function () { this.dataset.t = 1; }; $('bc').oninput = function () { this.dataset.t = 1; };
    $('bok').onclick = function () {
      var n = $('bn').value.trim(); if (!n) { $('be2').textContent = 'Le nom de l’entreprise est obligatoire.'; return; }
      var u = $('su').value.trim().replace(/\/+$/, ''), k = $('sk').value.trim();
      if ((u || k) && !(/^https:\/\/[^\s]+$/.test(u) && k)) { $('be2').textContent = 'Serveur : renseignez l’URL (https://…) ET la clé, ou videz les deux champs.'; return; }
      var nb = { name: n, short: $('bs').value.trim() || n.split(/\s+/)[0], chantier: $('bc').value.trim() || n + ' Chantier', tagline: $('bt').value.trim(), logo: logo,
        primary: $('c1').value, secondary: $('c2').value, accent: $('c3').value, phone: $('bp').value.trim(), email: $('be').value.trim(), address: $('ba').value.trim(), supabaseUrl: u, supabaseKey: k };
      try { localStorage.setItem(KEY, JSON.stringify({ done: true, brand: nb })); } catch (e) { $('be2').textContent = 'Enregistrement impossible (mémoire pleine ou navigation privée).'; return; }
      location.reload();
    };
    if (!first) { $('bx').onclick = close; $('brs').onclick = async function () { if (await (window.exbConfirm ? window.exbConfirm('Revenir au nom et au logo d’origine ?') : Promise.resolve(confirm('Revenir au nom et au logo d’origine ?')))) { try { localStorage.removeItem(KEY); } catch (e) {} location.reload(); } }; }
  }

  /* ---------- guide d'aide ---------- */
  var T_COMMUN = [
    ['Par où commencer ?', '<ol><li>Ouvrez <b>⚙️ Paramètres › 🏢 Identité de l’entreprise</b> : nom, logo, couleurs, contacts.</li><li>Connectez-vous (ou créez votre compte si l’écran le propose).</li><li>Créez votre premier élément (un participant, ou un projet) en suivant le guide correspondant ci-dessous.</li><li>Faites une <b>sauvegarde</b> régulière (Administration › Sauvegarde).</li></ol>'],
    ['Changer le nom, le logo ou les couleurs', '<ol><li>Ouvrez <b>⚙️ Paramètres</b>, section <b>🏢 Identité de l’entreprise</b>.</li><li>Modifiez, puis <b>Enregistrer</b> : l’appli redémarre avec la nouvelle identité (écrans, PDF, certificats).</li></ol>'],
    ['Installer sur le téléphone', '<ol><li>Ouvrez le lien dans Chrome (Android) ou Safari (iPhone).</li><li>Menu du navigateur › <b>Ajouter à l’écran d’accueil</b> / <b>Installer l’application</b>.</li></ol>'],
    ['Ça ne se synchronise pas / pas de connexion', '<ol><li>Vérifiez Wi‑Fi ou données mobiles.</li><li>Lancez le <b>🩺 Diagnostic</b> (menu Plus ou Administration) : il indique ce qui manque.</li><li>Si le serveur est en pause, ouvrez votre tableau de bord Supabase et cliquez sur « Restore ».</li></ol>']
  ];
  var T_CENTRAL = [
    ['Inscrire une personne (participant)', '<ol><li>Ouvrez l’onglet <b>👤 Participant</b>.</li><li>Remplissez nom, formation, contact, puis <b>Enregistrer</b>.</li><li>Un matricule est attribué : il sert pour les épreuves, les présences et la carte.</li></ol><b>Plusieurs d’un coup :</b> onglet <b>⚡ Ajouter plusieurs participants</b>, collez une ligne par personne.'],
    ['Laisser les gens s’inscrire eux‑mêmes', '<ol><li>Onglet <b>📨 Inscription des participants</b>.</li><li>Copiez ou partagez le <b>lien</b> (WhatsApp, SMS) ou téléchargez le formulaire.</li><li>La personne remplit ; la demande arrive dans votre liste pour validation.</li></ol>'],
    ['Faire un certificat', '<ol><li>Vérifiez que le participant a ses résultats (<b>📝 Évaluations</b>).</li><li>Onglet <b>Certificat</b> › remplissez ou choisissez dans la liste.</li><li>Prévisualisez puis exportez en PDF.</li></ol>'],
    ['Enregistrer un paiement / faire un reçu', '<ol><li>Onglet <b>💰 Finances &amp; paiements</b>.</li><li>Choisissez la personne, saisissez le montant.</li><li><b>Générer un reçu de paiement</b> › PDF.</li></ol>'],
    ['Présences et feuille de présence', '<ol><li>Onglet <b>✅ Gestion des présences</b>, choisissez la date et la formation.</li><li>Cochez les présents.</li><li>Exportez la <b>Feuille de présence</b> en PDF.</li></ol>'],
    ['Sauvegarder mes données', '<ol><li>Onglet <b>⚙️ Administration &amp; sauvegarde</b>.</li><li><b>Sauvegarde complète</b> : un fichier est téléchargé.</li><li>Pour restaurer : <b>Importer</b> ce fichier sur le nouvel appareil.</li></ol>']
  ];
  var T_CHANTIER = [
    ['Créer un projet / chantier', '<ol><li>Onglet <b>📁 Projets</b>.</li><li>Touchez <b>＋</b> et renseignez nom, code, lieu.</li><li>Rattachez les personnes concernées (équipe).</li></ol>'],
    ['Ajouter une photo', '<ol><li>Ouvrez le chantier.</li><li>Touchez le bouton <b>📷</b> puis prenez ou choisissez la photo.</li><li>Elle se synchronise dès qu’il y a du réseau.</li></ol>'],
    ['Pointer la présence des ouvriers', '<ol><li>Chantier › <b>👷 Présence</b>.</li><li>Cochez les présents du jour.</li></ol>'],
    ['Suivre le budget et les dépenses', '<ol><li>Chantier › <b>💰 Budget &amp; dépenses</b>.</li><li>Ajoutez chaque dépense avec montant et catégorie.</li></ol>'],
    ['Rapport de chantier en PDF', '<ol><li>Chantier › <b>📄 Rapport de chantier</b>.</li><li>Choisissez la période (du… au…).</li><li>Générez : le PDF reprend le nom et le logo de votre entreprise.</li></ol>'],
    ['Créer un compte pour un employé', '<ol><li>La création se fait par l’administrateur du logiciel (l’écran de connexion l’indique).</li><li>Demandez‑lui de créer le compte et de le rattacher au chantier.</li></ol>']
  ];
  function help() {
    close();
    var isField = !!window.EXB_FIELD_CONFIG;
    var topics = (isField ? T_CHANTIER : T_CENTRAL).concat(T_COMMUN);
    var ui = el('<div id="exbBrandUI"><div class="bx"><div style="display:flex;justify-content:space-between;align-items:center"><h2>❓ Aide pas à pas</h2><button id="hx" style="border:0;background:none;font-size:22px">✕</button></div>' +
      '<input id="hq" placeholder="Chercher : inscrire, certificat, photo…" style="margin:8px 0">' +
      '<div id="hl">' + topics.map(function (t) { return '<div class="tp"><b>' + esc(t[0]) + '</b><div>' + t[1] + '</div></div>'; }).join('') + '</div>' +
      '</div></div>');
    document.body.appendChild(ui);
    ui.querySelector('#hx').onclick = close;
    ui.querySelectorAll('.tp>b').forEach(function (b) { b.onclick = function () { b.parentNode.classList.toggle('o'); }; });
    ui.querySelector('#hq').oninput = function () {
      var q = this.value.toLowerCase(); ui.querySelectorAll('.tp').forEach(function (t) { var m = !q || t.textContent.toLowerCase().indexOf(q) >= 0; t.style.display = m ? '' : 'none'; if (q && m) t.classList.add('o'); });
    };
  }

  function start() {
    injectCss(); applyDom(); manifest(); observe();
    /* autre entreprise : l'image de fond d'origine porte le nom « Excellencia Building » dans la photo → version neutre (chantier sans logo) sur la couleur principale */
    if (changed) { try {
      var bg = B.primary + ' url(' + SCRIPT_BASE + 'splash-fond-neutre.webp) center/cover no-repeat', ns = document.createElement('style');
      ns.id = 'exbNeutralBg'; ns.textContent = '#exbSplash,.loginwrap{background:' + bg + ' !important}body.pub::before' + (document.querySelector('link[href*="exb-public.css"]') ? ',body::before' : '') + '{background:' + bg + ' !important}';
      document.head.appendChild(ns);
    } catch (e) {} }
    window.EXB_BRAND.openSetup = function () { if (fixed) { alert('Ces informations sont fixées par l’administrateur.'); return; } setup(false); }; window.EXB_BRAND.openHelp = help;
    if (LIGHT) return;
    var b = document.createElement('button'); b.id = 'exbHelpBtn'; b.title = 'Aide'; b.textContent = '❓'; b.onclick = help; document.body.appendChild(b);
    var needLic = window.EXB_LICENSE_CONFIG && window.EXB_LICENSE_CONFIG.requireToken && !localStorage.getItem('exb_lic_token');
    if (/[#&]lic=/.test(location.hash) || needLic) { /* l'écran de licence passe d'abord */ }
    else if (D.setupRequired && !done) setup(true);
    else if (/[?&]setup=1/.test(location.search)) setup(false);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
