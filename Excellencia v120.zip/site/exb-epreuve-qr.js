/* Excellencia Building V99n — QR individuel par apprenant pour les épreuves en ligne (TD, TP, examens).
 * Le QR ouvre epreuve.html?m=MATRICULE&e=ID : l'apprenant arrive directement sur son épreuve, peut travailler en ligne,
 * imprimer / enregistrer sa copie en PDF puis la joindre et l'envoyer plus tard (fonctions déjà présentes dans epreuve.html).
 * Ajout autonome : il ne modifie ni la publication des épreuves, ni les copies TP/TD existantes. */
(function (w, d) {
  'use strict';
  function $(i) { return d.getElementById(i); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function rm(v) { return String(v || '').replace(/\s+/g, '').trim(); }
  function origin() { return (window.exbOrigin?window.exbOrigin():location.origin); }
  function link(mat, id) { return origin() + '/epreuve.html?' + (mat ? 'm=' + encodeURIComponent(mat) + '&' : '') + 'e=' + encodeURIComponent(id); }
  function digits(p) { p = String(p || '').replace(/[^\d+]/g, ''); if (/^0\d{9}$/.test(p)) return '243' + p.slice(1); return p.replace(/\D/g, ''); }
  function say(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', 4000); } catch (e) {} try { exbAlert(m); } catch (e) {} }
  function people() { try { return (typeof participants !== 'undefined' ? participants : []).filter(function (p) { return p && p.matricule; }); } catch (e) { return []; } }
  function who(mat) { var k = rm(mat), p = people().filter(function (x) { return rm(x.matricule) === k; })[0]; return p || { name: '', phone: '', training: '' }; }
  function qr(text, px) { try { if (w.EXBQR && w.EXBQR.svg) return w.EXBQR.svg(text, { px: px || 150, quiet: 2 }); } catch (e) {} return '<div style="font-size:11px;color:#a52323;padding:20px 6px">QR indisponible</div>'; }

  var CSS = '@media print{body.exbqr-print>*:not(#exbQrOv){display:none!important}#exbQrOv{position:static!important;background:#fff!important;padding:0!important;overflow:visible!important}#exbQrOv .no-print{display:none!important}#exbQrOv .qbox{box-shadow:none!important;max-width:none!important;margin:0!important;padding:0!important}.qgrid{display:grid!important;grid-template-columns:1fr 1fr!important}.qc{break-inside:avoid;page-break-inside:avoid}}';
  var BTN = 'border:0;border-radius:10px;padding:9px 12px;font-weight:700;cursor:pointer;background:#173565;color:#fff;font-size:13px;';
  var B2 = 'border:0;border-radius:10px;padding:9px 12px;font-weight:700;cursor:pointer;background:#e8edf5;color:#173565;font-size:13px;';

  var EPS = [], CUR = null, FILTER = '';

  async function fetchEps() {
    if (!w.exbSb || !w.exbSb.isIn || !w.exbSb.isIn()) throw new Error('NOCONN');
    var r = await w.exbSb.api('/rest/v1/epreuves?select=id,title,type,matricules,opens_at,closes_at,active&order=created_at.desc&limit=100');
    return Array.isArray(r) ? r : [];
  }
  function cards(ep) {
    var q = FILTER.toLowerCase(), list = (ep.matricules || []).map(rm).filter(Boolean);
    var html = list.map(function (m) { var p = who(m); return { m: m, p: p }; }).filter(function (x) { return !q || (x.m + ' ' + (x.p.name || '')).toLowerCase().indexOf(q) >= 0; }).map(function (x) {
      var u = link(x.m, ep.id), ph = digits(x.p.phone);
      return '<div class="qc" style="border:1px solid #cbd5e1;border-radius:12px;padding:10px;display:flex;gap:10px;align-items:center;background:#fff"><div style="flex:none;width:150px;height:150px">' + qr(u, 150) + '</div><div style="min-width:0;flex:1"><b style="font-size:15px">' + esc(x.p.name || 'Apprenant') + '</b><div style="font-size:13px;color:#475569">Matricule : <b>' + esc(x.m) + '</b></div>' + (x.p.training ? '<div style="font-size:12px;color:#64748b">' + esc(x.p.training) + '</div>' : '') + '<div style="font-size:13px;margin-top:4px;color:#173565"><b>' + esc(ep.type || '') + ' — ' + esc(ep.title || '') + '</b></div><div style="font-size:11px;color:#64748b;margin-top:2px">Scannez pour ouvrir votre épreuve</div>'
        + '<div class="no-print" style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap"><button type="button" data-cp="' + esc(u) + '" style="' + B2 + '">Copier</button>' + (ph ? '<button type="button" data-wa="' + esc(ph) + '" data-u="' + esc(u) + '" data-n="' + esc(x.p.name || '') + '" style="' + B2 + '">WhatsApp</button>' : '') + '</div></div></div>';
    }).join('');
    return html || '<p style="color:#64748b">Aucun apprenant pour ce filtre.</p>';
  }
  function render(c) {
    var ep = CUR; if (!ep) return;
    c.querySelector('#qgrid').innerHTML = cards(ep);
    c.querySelector('#qcount').textContent = (ep.matricules || []).length + ' apprenant(s)';
  }
  async function open() {
    var O = d.createElement('div'); O.id = 'exbQrOv'; O.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:99999;overflow:auto;padding:12px';
    O.innerHTML = '<style>' + CSS + '</style><div class="qbox" style="background:#fff;border-radius:14px;max-width:760px;margin:16px auto;padding:16px;font-family:Arial,sans-serif;color:#172033"><div class="no-print" style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px;color:#173565">🔳 QR par apprenant</b><button type="button" id="qx" style="' + B2 + '">✕</button></div><p class="no-print" style="font-size:13px;color:#475569;margin:8px 0">Chaque QR ouvre directement l’épreuve de l’apprenant : il travaille en ligne, ou enregistre sa copie en PDF puis la joint et l’envoie plus tard. Le QR contient son matricule : transmettez-le à lui seul.</p><div id="qbody"><p>Chargement des épreuves…</p></div></div>';
    d.body.appendChild(O); d.body.classList.add('exbqr-print');
    O.querySelector('#qx').onclick = function () { O.remove(); d.body.classList.remove('exbqr-print'); };
    var box = O.querySelector('#qbody');
    try { EPS = await fetchEps(); } catch (e) { box.innerHTML = '<p style="color:#b45309">' + (e.message === 'NOCONN' ? 'Connectez-vous d’abord au serveur (Inscriptions › Demandes reçues), puis rouvrez cette fenêtre.' : 'Impossible de lire les épreuves : ' + esc(e.message)) + '</p>'; return; }
    if (!EPS.length) { box.innerHTML = '<p>Aucune épreuve publiée pour l’instant. Publiez d’abord une épreuve en ligne (TD, TP ou examen).</p>'; return; }
    CUR = EPS[0]; FILTER = '';
    box.innerHTML = '<div class="no-print"><label style="font-size:13px;font-weight:700">Épreuve</label><select id="qsel" style="width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:10px;margin:4px 0 8px">' + EPS.map(function (e, i) { return '<option value="' + i + '">' + esc((e.type || '') + ' — ' + (e.title || '') + (e.active ? '' : ' (fermée)')) + '</option>'; }).join('') + '</select><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><input id="qf" placeholder="Filtrer par nom ou matricule" style="flex:1;min-width:160px;padding:9px;border:1px solid #cbd5e1;border-radius:10px"><span id="qcount" style="font-size:12px;color:#64748b"></span></div><div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><button type="button" id="qpr" style="' + BTN + '">📄 Télécharger en PDF</button><button type="button" id="qall" style="' + B2 + '">📋 Copier tous les liens</button><button type="button" id="qgen" style="' + B2 + '">🔳 QR général (sans matricule)</button></div></div><div id="qgen-box"></div><div id="qgrid" class="qgrid" style="display:grid;gap:10px;grid-template-columns:1fr"></div>';
    var g = box.querySelector('#qgrid'); render(box);
    box.querySelector('#qsel').onchange = function () { CUR = EPS[+this.value]; render(box); box.querySelector('#qgen-box').innerHTML = ''; };
    box.querySelector('#qf').oninput = function () { FILTER = this.value; render(box); };
    box.querySelector('#qpr').onclick = async function () {
      var btn = this, old = btn.textContent, q = FILTER.toLowerCase();
      var list = (CUR.matricules || []).map(rm).filter(Boolean).map(function (m) { return { m: m, p: who(m) }; }).filter(function (x) { return !q || (x.m + ' ' + (x.p.name || '')).toLowerCase().indexOf(q) >= 0; });
      if (!w.EXBCopie || !w.EXBVerif || !w.EXBQR) { w.print(); return; }
      if (!list.length) { say('Aucun apprenant pour ce filtre.', 'warn'); return; }
      btn.disabled = true; btn.textContent = 'Création du PDF…';
      try {
        var blob = await w.EXBCopie.build({
          mode: 'sheet', titre: 'QR des apprenants — ' + ((CUR.type ? CUR.type + ' — ' : '') + (CUR.title || '')),
          sousTitre: list.length + ' apprenant(s) · édité le ' + new Date().toLocaleDateString('fr-FR'),
          rows: [['Épreuve', (CUR.type ? CUR.type + ' — ' : '') + (CUR.title || '')], ['Apprenants', String(list.length)]],
          instructions: 'Remettez à chaque apprenant SON QR uniquement : il contient le matricule et ouvre directement son épreuve. Découpez ou envoyez chaque carte séparément.',
          cardsTitre: 'Cartes individuelles',
          cards: list.map(function (x) { return { name: x.p.name || 'Apprenant', mat: x.m, sub: x.p.training || '', url: link(x.m, CUR.id) }; }),
          pied: 'Feuille de QR — ' + (CUR.title || 'épreuve')
        });
        w.EXBCopie.save(blob, 'QR-Apprenants-' + String(CUR.title || 'epreuve').replace(/[^A-Za-z0-9]+/g, '-').slice(0, 40) + '.pdf');
      } catch (e) { say('Impossible de créer le PDF. Réessayez.', 'warn'); }
      btn.disabled = false; btn.textContent = old;
    };
    box.querySelector('#qall').onclick = async function () { var t = (CUR.matricules || []).map(rm).filter(Boolean).map(function (m) { var p = who(m); return (p.name || m) + ' : ' + link(m, CUR.id); }).join('\n'); try { navigator.clipboard.writeText(t); say('Liens copiés (' + (CUR.matricules || []).length + ').', 'success'); } catch (e) { (await exbPrompt('Copiez :', t)); } };
    box.querySelector('#qgen').onclick = function () { var u = link('', CUR.id); box.querySelector('#qgen-box').innerHTML = '<div class="qc" style="border:2px solid #173565;border-radius:12px;padding:10px;display:flex;gap:10px;align-items:center;margin:8px 0"><div style="width:150px;height:150px;flex:none">' + qr(u, 150) + '</div><div><b>' + esc((CUR.type || '') + ' — ' + (CUR.title || '')) + '</b><div style="font-size:13px;color:#475569">QR général à projeter ou afficher : l’apprenant saisit son matricule et arrive sur cette épreuve.</div></div></div>'; };
    g.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.getAttribute('data-cp')) { var u = b.getAttribute('data-cp'); try { navigator.clipboard.writeText(u); b.textContent = '✓ Copié'; } catch (x) { exbPrompt('Copiez :', u); } }
      else if (b.getAttribute('data-wa')) { var n = b.getAttribute('data-n'); w.open('https://wa.me/' + b.getAttribute('data-wa') + '?text=' + encodeURIComponent('Bonjour' + (n ? ' ' + n : '') + ', voici votre épreuve Excellencia Building (' + (CUR.type || '') + ' — ' + (CUR.title || '') + ') : ' + b.getAttribute('data-u')), '_blank'); }
    });
  }
  function inject() {
    if ($('exbQrBtn')) return true; var rows = $('ep_rows'); if (!rows || !rows.parentNode) return false;
    var div = d.createElement('div'); div.style.cssText = 'margin:8px 0'; div.innerHTML = '<button type="button" id="exbQrBtn" class="primary smallbtn">🔳 QR par apprenant (ouvre directement l’épreuve)</button>';
    rows.parentNode.insertBefore(div, rows); $('exbQrBtn').onclick = open; return true;
  }
  var tries = 0; (function loop() { if (inject() || ++tries > 40) return; setTimeout(loop, 500); })();
  w.EXBEpQr = { open: open, link: link };
})(window, document);
