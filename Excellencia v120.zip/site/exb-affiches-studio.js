/* Excellencia Building — Affiches : (1) logo modifiable sur les deux affiches ; (2) « Studio libre » pour créer des affiches sur n'importe quel contenu.
 * Aucune donnée existante n'est modifiée. Données : clés exb_poster_logo, exb_poster_logo_cfg, exb_studio_posters (stockage de l'appareil).
 * Pour retirer : supprimer la balise <script src="exb-affiches-studio.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_STUDIO) return;
  var $ = function (i) { return d.getElementById(i); };
  var K_LOGO = 'exb_poster_logo', K_CFG = 'exb_poster_logo_cfg', K_LIST = 'exb_studio_posters';
  function S() { try { return typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) { return null; } }
  function rd(k, def) { try { var v = S().getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function wr(k, v) { try { S().setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function note(t, k, ms) { try { w.notify && w.notify(t, k || 'ok', ms || 4000); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function uid() { return 'e' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function brand() {
    var I = null; try { I = w.EXBId && w.EXBId.get ? w.EXBId.get() : null; } catch (e) {}
    I = I || {};
    var has = !!I.name; return { name: I.name || (window.EXB_BRAND && EXB_BRAND.name) || 'Excellencia Building', tagline: has ? (I.tagline || '') : "L'excellence au cœur de vos constructions", phone: has ? (I.phone || '') : '+243 810 644 554', email: has ? (I.email || '') : 'Excellenciabuilding@gmail.com', address: has ? (I.address || '') : 'Kinshasa, RDC', logo: I.logo || (window.exbLogoSrc ? exbLogoSrc() : 'icon-192.png') };
  }
  /* image choisie → réduite (taille maximale) → data URL ; PNG conservé (transparence) pour les logos */
  function readImg(file, maxPx, keepPng, cb) {
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, maxPx / Math.max(im.naturalWidth, im.naturalHeight)), c = d.createElement('canvas');
        c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
        var x = c.getContext('2d');
        var png = keepPng || /png|webp|svg/i.test(file.type || '');
        if (!png) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
        x.drawImage(im, 0, 0, c.width, c.height);
        cb(c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.88));
      };
      im.onerror = function () { note('Image illisible.', 'error'); };
      im.src = r.result;
    };
    r.onerror = function () { note('Lecture du fichier impossible.', 'error'); };
    r.readAsDataURL(file);
  }
  function download(blob, name) {
    var u = URL.createObjectURL(blob), a = d.createElement('a');
    a.href = u; a.download = name; d.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 5000);
  }
  function css(id, txt) { if ($(id)) return; var s = d.createElement('style'); s.id = id; s.textContent = txt; d.head.appendChild(s); }

  /* =====================================================================
   *  1) LOGO DES DEUX AFFICHES EXCELLENCIA
   *  Le logo d'origine fait partie de l'image de fond : on « efface » sa zone en reconstituant le ciel
   *  (dégradé calculé depuis les bords de la zone), puis on pose le logo choisi par-dessus.
   * ===================================================================== */
  var ZONES = {
    poster: { rect: [146, 20, 424, 200], box: [150, 24, 266, 152] },
    software: { rect: [16, 6, 496, 282], box: [22, 10, 466, 262] }
  };
  var cache = {};
  function cfg() { var c = rd(K_CFG, null) || {}; return { z: c.z || 1, dx: c.dx || 0, dy: c.dy || 0 }; }
  function logoSrc() { try { return S().getItem(K_LOGO) || ''; } catch (e) { return ''; } }

  function coons(im, rect, wref) {
    var sc = im.naturalWidth / wref, c = d.createElement('canvas');
    c.width = im.naturalWidth; c.height = im.naturalHeight;
    var x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0);
    var x0 = Math.max(3, Math.round(rect[0] * sc)), y0 = Math.max(3, Math.round(rect[1] * sc)), x1 = Math.min(c.width - 3, Math.round(rect[2] * sc)), y1 = Math.min(c.height - 3, Math.round(rect[3] * sc));
    var W = x1 - x0, H = y1 - y0; if (W < 4 || H < 4) return c.toDataURL('image/jpeg', 0.92);
    var g = x.getImageData(x0 - 3, y0 - 3, W + 6, H + 6), D = g.data, GW = W + 6;
    function P(px, py) { var o = ((py + 3) * GW + (px + 3)) * 4; return [D[o], D[o + 1], D[o + 2]]; } /* px,py relatifs au coin de la zone */
    function avg(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]; }
    var T = [], B = [], L = [], R = [], i, j;
    for (i = 0; i < W; i++) { T[i] = avg(P(i, -1), P(i, -2)); B[i] = avg(P(i, H), P(i, H + 1)); }
    for (j = 0; j < H; j++) { L[j] = avg(P(-1, j), P(-2, j)); R[j] = avg(P(W, j), P(W + 1, j)); }
    var c00 = avg(T[0], L[0]), c10 = avg(T[W - 1], R[0]), c01 = avg(B[0], L[H - 1]), c11 = avg(B[W - 1], R[H - 1]);
    for (j = 0; j < H; j++) {
      var v = (j + 0.5) / H;
      for (i = 0; i < W; i++) {
        var u = (i + 0.5) / W, o = ((j + 3) * GW + (i + 3)) * 4;
        for (var k = 0; k < 3; k++) {
          var val = (1 - v) * T[i][k] + v * B[i][k] + (1 - u) * L[j][k] + u * R[j][k] -
            ((1 - u) * (1 - v) * c00[k] + u * (1 - v) * c10[k] + (1 - u) * v * c01[k] + u * v * c11[k]);
          D[o + k] = Math.max(0, Math.min(255, val + (Math.random() - 0.5) * 2.2));
        }
        D[o + 3] = 255;
      }
    }
    x.putImageData(g, x0 - 3, y0 - 3);
    return c.toDataURL('image/jpeg', 0.93);
  }
  function patched(kind, src, cb) {
    var key = kind + '|' + src.length + '|' + src.slice(-48);
    if (cache[kind] && cache[kind].key === key) return cb(cache[kind].out);
    var im = new Image();
    im.onload = function () { try { var out = coons(im, ZONES[kind].rect, 1024); cache[kind] = { key: key, out: out }; cb(out); } catch (e) { cb(null); } };
    im.onerror = function () { cb(null); };
    im.src = src;
  }
  function overlay(kind, paper) {
    var id = 'exbLogoOv_' + kind, el = $(id);
    if (!el) {
      el = d.createElement('img'); el.id = id; el.alt = 'Logo';
      el.style.cssText = 'position:absolute;object-fit:contain;pointer-events:none;z-index:6;display:none';
      paper.appendChild(el);
    }
    return el;
  }
  function place(kind, el) {
    var b = ZONES[kind].box, c = cfg(), cx = b[0] + b[2] / 2 + c.dx, cy = b[1] + b[3] / 2 + c.dy, W = b[2] * c.z, H = b[3] * c.z;
    el.style.left = (cx - W / 2) + 'px'; el.style.top = (cy - H / 2) + 'px'; el.style.width = W + 'px'; el.style.height = H + 'px';
  }
  var tries = { poster: 0, software: 0 };
  function applyOne(kind) {
    var paper = $(kind === 'poster' ? 'posterPaper' : 'softwarePosterPaper'); if (!paper) return;
    var logo = logoSrc(), ov = overlay(kind, paper);
    if (!logo) { ov.style.display = 'none'; restore(kind, paper); return; }
    var src = '';
    if (kind === 'poster') { try { src = typeof getPosterBg === 'function' ? getPosterBg() : ''; } catch (e) {} }
    else { var im = $('softwarePosterImage'); src = (im && (im.getAttribute('data-orig') || im.src)) || ''; }
    if (!src || src === location.href) { if (tries[kind]++ < 25) setTimeout(function () { applyOne(kind); }, 400); return; }
    tries[kind] = 0;
    ov.src = logo; place(kind, ov); ov.style.display = 'block';
    patched(kind, src, function (out) {
      if (!out) return;
      if (kind === 'poster') paper.style.backgroundImage = 'url(' + out + ')';
      else { var im2 = $('softwarePosterImage'); if (im2) { if (!im2.getAttribute('data-orig')) im2.setAttribute('data-orig', im2.src); im2.src = out; } }
    });
  }
  function restore(kind, paper) {
    if (kind === 'poster') { try { paper.style.backgroundImage = 'url(' + getPosterBg() + ')'; } catch (e) {} }
    else { var im = $('softwarePosterImage'); if (im && im.getAttribute('data-orig')) { im.src = im.getAttribute('data-orig'); im.removeAttribute('data-orig'); } }
  }
  function applyAll() { applyOne('poster'); applyOne('software'); }
  function wrapRender() {
    ['renderPoster', 'renderSoftwarePoster'].forEach(function (n) {
      var f = w[n]; if (typeof f !== 'function' || f.__exbLogo) return;
      var g = function () { var r = f.apply(this, arguments); try { applyOne(n === 'renderPoster' ? 'poster' : 'software'); } catch (e) {} return r; };
      g.__exbLogo = 1; w[n] = g;
    });
  }

  function logoCard() {
    var sec = $('affiches'); if (!sec || $('exbLogoCard')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    var card = d.createElement('div'); card.className = 'card no-print'; card.id = 'exbLogoCard'; card.style.gridColumn = '1/-1';
    card.innerHTML =
      '<h2>🔷 Logo des affiches</h2>' +
      '<p style="font-size:12.5px;color:#5e6877;margin:-4px 0 10px">Changez le logo des deux affiches (générale et logiciels). Le fond, les photos et les textes ne changent pas : seule la zone du logo est remplacée.</p>' +
      '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">' +
      '<div id="exbLogoPrev" style="width:130px;height:84px;border:1px dashed #9aa6b8;border-radius:10px;background:#fff center/contain no-repeat;display:grid;place-items:center;font-size:11px;color:#6b7a99;text-align:center">Logo d’origine</div>' +
      '<div style="flex:1;min-width:240px"><input type="file" id="exbLogoFile" accept="image/png,image/jpeg,image/webp,image/svg+xml">' +
      '<div class="actions" style="margin-top:8px"><button class="muted" id="exbLogoCo">🏢 Logo de l’entreprise</button><button class="muted" id="exbLogoRs">↩ Logo d’origine</button></div></div></div>' +
      '<div id="exbLogoSl" style="display:none;margin-top:10px">' +
      '<label>Taille <b id="exbLz_v"></b></label><input type="range" id="exbLz" min="40" max="160" step="2" style="width:100%">' +
      '<label>Position horizontale</label><input type="range" id="exbLx" min="-160" max="160" step="2" style="width:100%">' +
      '<label>Position verticale</label><input type="range" id="exbLy" min="-120" max="120" step="2" style="width:100%"></div>' +
      '<div class="msg" id="exbLogoMsg"></div>';
    grid.insertBefore(card, grid.firstChild);
    function sync() {
      var l = logoSrc(), c = cfg(), pv = $('exbLogoPrev');
      pv.style.backgroundImage = l ? 'url(' + l + ')' : 'none'; pv.textContent = l ? '' : 'Logo d’origine';
      $('exbLogoSl').style.display = l ? 'block' : 'none';
      $('exbLz').value = Math.round(c.z * 100); $('exbLx').value = c.dx; $('exbLy').value = c.dy; $('exbLz_v').textContent = Math.round(c.z * 100) + ' %';
    }
    function setLogo(u) { try { S().setItem(K_LOGO, u); } catch (e) { note('Stockage plein : logo non enregistré.', 'error'); } cache = {}; sync(); applyAll(); }
    $('exbLogoFile').onchange = function (e) { var f = e.target.files && e.target.files[0]; if (!f) return; readImg(f, 900, true, function (u) { setLogo(u); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo appliqué aux deux affiches.</span>'; }); e.target.value = ''; };
    $('exbLogoCo').onclick = function () {
      var u = brand().logo; if (!u) return;
      var im = new Image(); im.onload = function () { var c = d.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); try { setLogo(c.toDataURL('image/png')); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo de l’entreprise appliqué.</span>'; } catch (e) { note('Logo de l’entreprise illisible.', 'error'); } };
      im.onerror = function () { note('Logo de l’entreprise introuvable.', 'error'); }; im.src = u;
    };
    $('exbLogoRs').onclick = function () { try { S().removeItem(K_LOGO); S().removeItem(K_CFG); } catch (e) {} cache = {}; sync(); applyAll(); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo d’origine rétabli.</span>'; };
    function sl() { wr(K_CFG, { z: $('exbLz').value / 100, dx: +$('exbLx').value, dy: +$('exbLy').value }); $('exbLz_v').textContent = $('exbLz').value + ' %'; ['poster', 'software'].forEach(function (k) { var p = $(k === 'poster' ? 'posterPaper' : 'softwarePosterPaper'), o = p && $('exbLogoOv_' + k); if (o) place(k, o); }); }
    ['exbLz', 'exbLx', 'exbLy'].forEach(function (i) { $(i).oninput = sl; });
    sync();
  }

  /* =====================================================================
   *  2) STUDIO LIBRE
   * ===================================================================== */
  var FMT = {
    a4p: { l: 'A4 portrait', w: 794, h: 1123, mm: [210, 297], sc: 3 },
    a4l: { l: 'A4 paysage', w: 1123, h: 794, mm: [297, 210], sc: 3 },
    a3p: { l: 'A3 portrait', w: 1123, h: 1587, mm: [297, 420], sc: 2.2 },
    sq: { l: 'Carré (réseaux sociaux)', w: 1080, h: 1080, mm: null, sc: 2 },
    story: { l: 'Story / Statut (9:16)', w: 1080, h: 1920, mm: null, sc: 1.6 },
    ban: { l: 'Bannière (Facebook / LinkedIn)', w: 1200, h: 628, mm: null, sc: 2 }
  };
  var FONTS = [['Arial', 'Arial, Helvetica, sans-serif'], ['Arial Black', '"Arial Black", Arial, sans-serif'], ['Impact', 'Impact, Haettenschweiler, sans-serif'], ['Georgia', 'Georgia, serif'], ['Times', '"Times New Roman", Times, serif'], ['Trebuchet', '"Trebuchet MS", sans-serif'], ['Verdana', 'Verdana, sans-serif'], ['Manuscrit', 'Caveat, "Segoe Script", "Brush Script MT", cursive']];
  var PALETTES = {
    marine: ['#0f2a56', '#1e5fb4', 160, '#f2c94c'], ciel: ['#e8f3ff', '#7ab8f5', 170, '#12305e'], blanc: ['#ffffff', '#eef2f8', 180, '#12305e'],
    noir: ['#0b0f17', '#1d2635', 160, '#e0b54a'], vert: ['#0e3b2e', '#2e8b57', 160, '#ffd54a'], orange: ['#e8590c', '#f59f00', 150, '#ffffff'], rouge: ['#7a0c1c', '#c2283d', 160, '#ffffff']
  };
  var ST = { id: null, name: 'Mon affiche', fmt: 'a4p', bg: { c1: '#0f2a56', c2: '#1e5fb4', ang: 160, img: '', ovl: 0 }, els: [], frame: { on: false } };
  var sel = null, scale = 1, root = null, hist = [];

  function stageCss(el, e) {
    el.style.cssText = 'position:absolute;left:' + e.x + 'px;top:' + e.y + 'px;width:' + e.w + 'px;' + (e.t === 'text' ? '' : 'height:' + e.h + 'px;') +
      'opacity:' + (e.op == null ? 1 : e.op) + ';transform:rotate(' + (e.rot || 0) + 'deg);transform-origin:center;box-sizing:border-box;';
    if (e.t === 'text') {
      el.style.cssText += 'font-family:' + (FONTS[e.ff] ? FONTS[e.ff][1] : FONTS[0][1]) + ';font-size:' + e.fs + 'px;color:' + e.col + ';font-weight:' + (e.b ? 800 : 400) + ';font-style:' + (e.i ? 'italic' : 'normal') +
        ';text-align:' + (e.al || 'left') + ';line-height:' + (e.lh || 1.2) + ';white-space:pre-wrap;word-break:break-word;letter-spacing:' + (e.ls || 0) + 'px;' +
        (e.bg ? 'background:' + e.bg + ';padding:' + (e.pad || 10) + 'px;border-radius:' + (e.rad || 0) + 'px;' : '') + (e.up ? 'text-transform:uppercase;' : '') +
        (e.sh ? 'text-shadow:0 2px 8px rgba(0,0,0,.45);' : '');
    } else if (e.t === 'rect' || e.t === 'ellipse') {
      el.style.cssText += 'background:' + (e.fill || 'transparent') + ';border:' + (e.sw || 0) + 'px solid ' + (e.stroke || 'transparent') + ';border-radius:' + (e.t === 'ellipse' ? '50%' : (e.rad || 0) + 'px') + ';';
    } else if (e.t === 'line') {
      el.style.cssText += 'height:' + Math.max(1, e.h) + 'px;background:' + (e.fill || '#fff') + ';border-radius:' + (e.h / 2) + 'px;';
    }
  }
  function bgVal(b) {
    var s = 'linear-gradient(' + b.ang + 'deg,' + b.c1 + ',' + b.c2 + ')';
    if (b.img) return (b.ovl ? 'linear-gradient(rgba(0,0,0,' + b.ovl / 100 + '),rgba(0,0,0,' + b.ovl / 100 + ')),' : '') + 'url(' + b.img + ') center/cover no-repeat,' + s;
    return s;
  }
  /* construit la feuille ; interactive = vrai pour l'écran (sélection, poignées), faux pour l'export */
  function build(host, interactive) {
    var F = FMT[ST.fmt]; host.innerHTML = '';
    host.style.position = 'relative'; host.style.overflow = 'hidden'; host.style.width = F.w + 'px'; host.style.height = F.h + 'px'; host.style.background = bgVal(ST.bg);
    if (ST.wm && ST.wm.on) {
      var ws = logoSrcForStudio(), wz = Math.round(Math.min(F.w, F.h) * (ST.wm.z || 70) / 100);
      if (ws) { var wd = d.createElement('div'); wd.className = 'exbs-wm'; wd.style.cssText = 'position:absolute;left:' + Math.round((F.w - wz) / 2) + 'px;top:' + Math.round((F.h - wz) / 2) + 'px;width:' + wz + 'px;height:' + wz + 'px;opacity:' + ((ST.wm.op == null ? 12 : ST.wm.op) / 100) + ';pointer-events:none;transform:rotate(' + (ST.wm.rot || 0) + 'deg)';
        var wi = d.createElement('img'); wi.src = ws; wi.alt = ''; wi.draggable = false; wi.style.cssText = 'width:100%;height:100%;object-fit:contain;display:block'; wd.appendChild(wi); host.appendChild(wd); }
    }
    ST.els.forEach(function (e) {
      var el = d.createElement('div'); el.setAttribute('data-id', e.id); stageCss(el, e);
      if (e.t === 'text') el.textContent = e.tx;
      else if (e.t === 'img') {
        var im = d.createElement('img'); im.src = e.src; im.alt = ''; im.draggable = false;
        im.style.cssText = 'width:100%;height:100%;display:block;object-fit:' + (e.fit || 'contain') + ';border-radius:' + (e.rad || 0) + 'px;pointer-events:none';
        el.appendChild(im);
      }
      if (interactive) {
        el.style.cursor = 'move'; el.style.touchAction = 'none';
        if (e.id === sel) {
          el.style.outline = '2px dashed #1e88e5'; el.style.outlineOffset = '2px';
          var h = d.createElement('div'); h.setAttribute('data-h', '1');
          h.style.cssText = 'position:absolute;right:-12px;bottom:-12px;width:' + (26 / scale) + 'px;height:' + (26 / scale) + 'px;background:#1e88e5;border:2px solid #fff;border-radius:50%;cursor:nwse-resize;touch-action:none;transform:rotate(' + (-(e.rot || 0)) + 'deg)';
          el.appendChild(h);
        }
      }
      host.appendChild(el);
    });
    try { if (w.EXB_FRAME && ST.frame && ST.frame.on) w.EXB_FRAME.draw(host, F.w, F.h, Math.min(F.w, F.h) / 595, ST.frame); } catch (e) {}
  }
  function find(id) { for (var i = 0; i < ST.els.length; i++) if (ST.els[i].id === id) return ST.els[i]; return null; }
  function push() { hist.push(JSON.stringify(ST)); if (hist.length > 40) hist.shift(); }
  function undo() { if (!hist.length) return; var s = JSON.parse(hist.pop()); ST = s; if (!find(sel)) sel = null; refresh(); }

  function fit() {
    var wrap = $('exbsWrap'), F = FMT[ST.fmt]; if (!wrap) return;
    var avail = Math.max(240, ($('exbsBox').clientWidth || 700) - 4);
    scale = Math.min(1, avail / F.w);
    var maxH = Math.max(380, (w.innerHeight || 800) * 0.78);
    if (F.h * scale > maxH) scale = maxH / F.h;
    wrap.style.width = (F.w * scale) + 'px'; wrap.style.height = (F.h * scale) + 'px';
    $('exbsStage').style.transform = 'scale(' + scale + ')';
  }
  function refresh(keepProps) { if (ST.fdef && !FMT[ST.fmt]) FMT[ST.fmt] = ST.fdef; fit(); build($('exbsStage'), true); if (!keepProps) props(); $('exbsFmtLbl').textContent = FMT[ST.fmt].l + ' — ' + FMT[ST.fmt].w + '×' + FMT[ST.fmt].h + ' px'; }

  /* ---------- glisser / redimensionner ---------- */
  function bindDrag() {
    var stage = $('exbsStage'), cur = null;
    stage.addEventListener('pointerdown', function (ev) {
      var h = ev.target.closest && ev.target.closest('[data-h]'), t = ev.target.closest && ev.target.closest('[data-id]');
      if (!t) { sel = null; refresh(); return; }
      var e = find(t.getAttribute('data-id')); if (!e) return;
      if (sel !== e.id) { sel = e.id; refresh(); }
      push();
      cur = { e: e, mode: h ? 'size' : 'move', x: ev.clientX, y: ev.clientY, ex: e.x, ey: e.y, ew: e.w, eh: e.h, moved: false };
      try { stage.setPointerCapture(ev.pointerId); } catch (x) {}
      ev.preventDefault();
    });
    stage.addEventListener('pointermove', function (ev) {
      if (!cur) return;
      var dx = (ev.clientX - cur.x) / scale, dy = (ev.clientY - cur.y) / scale; cur.moved = true;
      if (cur.mode === 'move') { cur.e.x = Math.round(cur.ex + dx); cur.e.y = Math.round(cur.ey + dy); }
      else { cur.e.w = Math.max(20, Math.round(cur.ew + dx)); if (cur.e.t !== 'text') cur.e.h = Math.max(cur.e.t === 'line' ? 2 : 20, Math.round(cur.eh + dy)); }
      var el = stage.querySelector('[data-id="' + cur.e.id + '"]');
      if (el) { el.style.left = cur.e.x + 'px'; el.style.top = cur.e.y + 'px'; el.style.width = cur.e.w + 'px'; if (cur.e.t !== 'text') el.style.height = cur.e.h + 'px'; }
    });
    function up() { if (!cur) return; var m = cur.moved; cur = null; if (!m) hist.pop(); refresh(); }
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
  }

  /* ---------- panneau de propriétés ---------- */
  function row(lbl, inner) { return '<label class="exbs-l">' + lbl + '</label>' + inner; }
  function props() {
    var P = $('exbsProps'); if (!P) return; var e = find(sel);
    if (!e) { P.innerHTML = '<p class="exbs-hint">Touchez un élément de l’affiche pour le modifier, ou ajoutez-en un avec les boutons ci-dessus.</p>'; return; }
    var h = '<b class="exbs-t">' + ({ text: 'Texte', img: 'Image', rect: 'Rectangle', ellipse: 'Cercle', line: 'Trait' }[e.t]) + ' sélectionné</b>';
    if (e.t === 'text') {
      h += '<textarea id="pp_tx" rows="3" class="exbs-in">' + esc(e.tx) + '</textarea>' +
        '<div class="exbs-2">' + row('Taille', '<input type="number" id="pp_fs" min="8" max="400" value="' + e.fs + '" class="exbs-in">') + row('Couleur', '<input type="color" id="pp_col" value="' + e.col + '" class="exbs-in">') + '</div>' +
        row('Police', '<select id="pp_ff" class="exbs-in">' + FONTS.map(function (f, i) { return '<option value="' + i + '"' + (i === (e.ff || 0) ? ' selected' : '') + '>' + f[0] + '</option>'; }).join('') + '</select>') +
        '<div class="exbs-btns"><button id="pp_b" class="' + (e.b ? 'on' : '') + '"><b>G</b></button><button id="pp_i" class="' + (e.i ? 'on' : '') + '"><i>I</i></button><button id="pp_up" class="' + (e.up ? 'on' : '') + '">AA</button><button id="pp_sh" class="' + (e.sh ? 'on' : '') + '">Ombre</button>' +
        '<button data-al="left" class="' + (e.al === 'left' || !e.al ? 'on' : '') + '">⬅</button><button data-al="center" class="' + (e.al === 'center' ? 'on' : '') + '">↔</button><button data-al="right" class="' + (e.al === 'right' ? 'on' : '') + '">➡</button></div>' +
        row('Interligne', '<input type="range" id="pp_lh" min="0.9" max="2" step="0.05" value="' + (e.lh || 1.2) + '" style="width:100%">') +
        '<div class="exbs-2">' + row('Fond du texte', '<input type="color" id="pp_bg" value="' + (e.bg || '#ffffff') + '" class="exbs-in">') + row('', '<button id="pp_nobg" class="exbs-mini">' + (e.bg ? 'Retirer le fond' : 'Aucun fond') + '</button>') + '</div>';
    } else if (e.t === 'rect' || e.t === 'ellipse' || e.t === 'line') {
      h += '<div class="exbs-2">' + row('Couleur', '<input type="color" id="pp_fill" value="' + (/^#/.test(e.fill) ? e.fill : '#1e5fb4') + '" class="exbs-in">') + (e.t === 'line' ? '' : row('Contour', '<input type="color" id="pp_stroke" value="' + (/^#/.test(e.stroke) ? e.stroke : '#ffffff') + '" class="exbs-in">')) + '</div>' +
        (e.t === 'rect' ? row('Coins arrondis', '<input type="range" id="pp_rad" min="0" max="200" value="' + (e.rad || 0) + '" style="width:100%">') : '') +
        (e.t === 'line' ? '' : row('Épaisseur du contour', '<input type="range" id="pp_sw" min="0" max="30" value="' + (e.sw || 0) + '" style="width:100%">'));
    } else if (e.t === 'img') {
      h += '<div class="exbs-btns"><button id="pp_swap">🖼 Changer l’image</button><button id="pp_fit">' + (e.fit === 'cover' ? 'Remplir (recadrer)' : 'Entière') + '</button></div>' +
        row('Coins arrondis (200 = rond)', '<input type="range" id="pp_rad" min="0" max="400" value="' + (e.rad || 0) + '" style="width:100%">');
    }
    h += row('Transparence', '<input type="range" id="pp_op" min="0.1" max="1" step="0.05" value="' + (e.op == null ? 1 : e.op) + '" style="width:100%">') +
      row('Rotation', '<input type="range" id="pp_rot" min="-180" max="180" value="' + (e.rot || 0) + '" style="width:100%">') +
      '<div class="exbs-btns"><button id="pp_front">⬆ Devant</button><button id="pp_back">⬇ Derrière</button><button id="pp_dup">⧉ Dupliquer</button><button id="pp_cx">⇔ Centrer</button><button id="pp_del" class="del">🗑 Supprimer</button></div>';
    P.innerHTML = h;
    var q = function (i) { return $(i); }, armed = false;
    function arm() { if (!armed) { push(); armed = true; } }
    function upd() {
      var el = $('exbsStage').querySelector('[data-id="' + e.id + '"]'); if (!el) return;
      stageCss(el, e); el.style.cursor = 'move'; el.style.touchAction = 'none'; el.style.outline = '2px dashed #1e88e5'; el.style.outlineOffset = '2px';
    }
    function on(id, ev, fn) { var x = q(id); if (x) x[ev] = fn; }
    function live(id, key, num) { on(id, 'onpointerdown', arm); on(id, 'onfocus', arm); on(id, 'oninput', function (ev) { arm(); e[key] = num ? +ev.target.value : ev.target.value; upd(); }); on(id, 'onchange', function () { refresh(true); }); }
    if (e.t === 'text') {
      on('pp_tx', 'onfocus', arm); on('pp_tx', 'oninput', function (ev) { arm(); e.tx = ev.target.value; refresh(true); });
      live('pp_fs', 'fs', 1); live('pp_col', 'col'); live('pp_lh', 'lh', 1);
      on('pp_ff', 'onchange', function (ev) { push(); e.ff = +ev.target.value; refresh(); });
      [['pp_b', 'b'], ['pp_i', 'i'], ['pp_up', 'up'], ['pp_sh', 'sh']].forEach(function (a) { on(a[0], 'onclick', function () { push(); e[a[1]] = !e[a[1]]; refresh(); }); });
      Array.prototype.forEach.call(P.querySelectorAll('[data-al]'), function (b) { b.onclick = function () { push(); e.al = b.getAttribute('data-al'); refresh(); }; });
      on('pp_bg', 'onpointerdown', arm); on('pp_bg', 'oninput', function (ev) { arm(); e.bg = ev.target.value; upd(); }); on('pp_bg', 'onchange', function () { refresh(true); });
      on('pp_nobg', 'onclick', function () { push(); e.bg = ''; refresh(); });
    } else if (e.t === 'img') {
      on('pp_swap', 'onclick', function () { pickImage(function (u) { push(); e.src = u; refresh(); }); });
      on('pp_fit', 'onclick', function () { push(); e.fit = e.fit === 'cover' ? 'contain' : 'cover'; refresh(); });
      on('pp_rad', 'onpointerdown', arm); on('pp_rad', 'oninput', function (ev) { arm(); e.rad = +ev.target.value; var im = $('exbsStage').querySelector('[data-id="' + e.id + '"] img'); if (im) im.style.borderRadius = e.rad + 'px'; });
    } else {
      live('pp_fill', 'fill'); live('pp_stroke', 'stroke'); live('pp_rad', 'rad', 1); live('pp_sw', 'sw', 1);
    }
    live('pp_op', 'op', 1); live('pp_rot', 'rot', 1);
    on('pp_front', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); ST.els.push(e); refresh(); });
    on('pp_back', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); ST.els.unshift(e); refresh(); });
    on('pp_dup', 'onclick', function () { push(); var c = JSON.parse(JSON.stringify(e)); c.id = uid(); c.x += 24; c.y += 24; ST.els.push(c); sel = c.id; refresh(); });
    on('pp_cx', 'onclick', function () { push(); e.x = Math.round((FMT[ST.fmt].w - e.w) / 2); refresh(); });
    on('pp_del', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); sel = null; refresh(); });
  }

  function pickImage(cb, keepPng) {
    var i = d.createElement('input'); i.type = 'file'; i.accept = 'image/png,image/jpeg,image/webp,image/svg+xml';
    i.onchange = function () { var f = i.files && i.files[0]; if (f) readImg(f, 1800, keepPng !== false, cb); };
    i.click();
  }
  function add(e) { push(); e.id = uid(); ST.els.push(e); sel = e.id; refresh(); }
  function addText(tx, o) { var F = FMT[ST.fmt]; add(Object.assign({ t: 'text', tx: tx, x: Math.round(F.w * 0.08), y: Math.round(F.h * 0.12), w: Math.round(F.w * 0.84), h: 60, fs: Math.round(F.w / 16), col: bgIsDark() ? '#ffffff' : '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 }, o || {})); }
  function bgIsDark() { var c = ST.bg.c1.replace('#', ''); if (c.length === 3) c = c.replace(/./g, '$&$&'); var r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16); return (r * 299 + g * 587 + b * 114) / 1000 < 150 || !!ST.bg.img; }

  function framePn() {
    var box = $('exbsFr'); if (!box || !w.EXB_FRAME) { if (box) box.innerHTML = '<p class="exbs-hint">Module contour non chargé.</p>'; return; }
    w.EXB_FRAME.panel(box, function () { return ST.frame; }, function (v) { push(); ST.frame = v; }, function (live) { build($('exbsStage'), true); }, 'exbsF');
  }
  /* ---------- fond ---------- */
  function bgPanel() {
    var P = $('exbsBg'); var b = ST.bg, wmv = ST.wm || {};
    P.innerHTML = '<div class="exbs-pal">' + Object.keys(PALETTES).map(function (k) { var p = PALETTES[k]; return '<button data-pal="' + k + '" title="' + k + '" style="background:linear-gradient(' + p[2] + 'deg,' + p[0] + ',' + p[1] + ')"></button>'; }).join('') + '</div>' +
      '<div class="exbs-2">' + row('Couleur 1', '<input type="color" id="bg_c1" value="' + b.c1 + '" class="exbs-in">') + row('Couleur 2', '<input type="color" id="bg_c2" value="' + b.c2 + '" class="exbs-in">') + '</div>' +
      row('Angle du dégradé', '<input type="range" id="bg_ang" min="0" max="360" value="' + b.ang + '" style="width:100%">') +
      '<div class="exbs-btns"><button id="bg_img">🖼 Photo de fond</button><button id="bg_noimg">Retirer la photo</button></div>' +
      row('Assombrir la photo', '<input type="range" id="bg_ovl" min="0" max="85" value="' + b.ovl + '" style="width:100%">') +
      '<div style="border-top:1px solid #e3e9f2;margin-top:8px;padding-top:6px"><label class="exbs-l"><input type="checkbox" id="wm_on"' + (wmv.on ? ' checked' : '') + '> Filigrane : mon logo en transparence derrière l’affiche</label>' + row('Visibilité', '<input type="range" id="wm_op" min="3" max="40" value="' + (wmv.op == null ? 12 : wmv.op) + '" style="width:100%">') + row('Taille', '<input type="range" id="wm_z" min="20" max="120" value="' + (wmv.z || 70) + '" style="width:100%">') + '</div>';
    Array.prototype.forEach.call(P.querySelectorAll('[data-pal]'), function (x) { x.onclick = function () { var p = PALETTES[x.getAttribute('data-pal')]; push(); b.c1 = p[0]; b.c2 = p[1]; b.ang = p[2]; ST.els.forEach(function (e) { if (e.t === 'text' && (e.col === '#ffffff' || e.col === '#12305e')) e.col = bgIsDark() ? '#ffffff' : '#12305e'; }); bgPanel(); refresh(); }; });
    var lv = function (id, k, n) { $(id).oninput = function (ev) { b[k] = n ? +ev.target.value : ev.target.value; $('exbsStage').style.background = bgVal(b); }; $(id).onchange = function () { push(); refresh(true); }; };
    lv('bg_c1', 'c1'); lv('bg_c2', 'c2'); lv('bg_ang', 'ang', 1); lv('bg_ovl', 'ovl', 1);
    var wmSet = function (k, v) { push(); ST.wm = ST.wm || { on: false, op: 12, z: 70 }; ST.wm[k] = v; refresh(true); };
    $('wm_on').onchange = function () { wmSet('on', this.checked); }; $('wm_op').onchange = function () { wmSet('op', +this.value); }; $('wm_z').onchange = function () { wmSet('z', +this.value); };
    $('bg_img').onclick = function () { pickImage(function (u) { push(); b.img = u; refresh(); }, false); };
    $('bg_noimg').onclick = function () { push(); b.img = ''; refresh(); };
  }

  /* ---------- modèles ---------- */
  function logoSrcForStudio() { return logoSrc() || brand().logo; }
  function head(F, dark) {
    var B = brand(), W = F.w, m = Math.round(W * 0.06);
    return [
      { t: 'img', src: logoSrcForStudio(), x: m, y: Math.round(W * 0.05), w: Math.round(W * 0.16), h: Math.round(W * 0.16), fit: 'contain', op: 1, rad: 0 },
      { t: 'text', tx: B.name.toUpperCase(), x: m + Math.round(W * 0.18), y: Math.round(W * 0.075), w: Math.round(W * 0.6), h: 40, fs: Math.round(W / 26), col: dark ? '#ffffff' : '#12305e', b: true, al: 'left', ff: 0, lh: 1.1, ls: 1 },
      { t: 'text', tx: B.tagline, x: m + Math.round(W * 0.18), y: Math.round(W * 0.075) + Math.round(W / 20), w: Math.round(W * 0.6), h: 30, fs: Math.round(W / 46), col: dark ? '#cfe3ff' : '#42526e', b: false, i: true, al: 'left', ff: 3, lh: 1.2 }
    ];
  }
  function foot(F, dark, gold) {
    var B = brand(), W = F.w, H = F.h, m = Math.round(W * 0.06);
    return [
      { t: 'rect', x: 0, y: H - Math.round(W * 0.16), w: W, h: Math.round(W * 0.16), fill: dark ? 'rgba(0,0,0,.35)' : '#12305e', sw: 0, rad: 0, fx: 1 },
      { t: 'text', tx: '📞 ' + B.phone + '    ✉ ' + B.email, x: m, y: H - Math.round(W * 0.135), w: W - 2 * m, h: 30, fs: Math.round(W / 36), col: '#ffffff', b: true, al: 'center', ff: 0, lh: 1.2, fx: 1 },
      { t: 'text', tx: '📍 ' + B.address, x: m, y: H - Math.round(W * 0.075), w: W - 2 * m, h: 30, fs: Math.round(W / 40), col: gold || '#f2c94c', b: false, al: 'center', ff: 0, lh: 1.2, fx: 1 }
    ];
  }
  var TPL = {
    vide: { l: 'Page vide', pal: 'marine', f: function () { return []; } },
    annonce: {
      l: 'Annonce / Événement', pal: 'marine', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06), G = PALETTES.marine[3];
        return head(F, true).concat([
          { t: 'rect', x: m, y: Math.round(H * 0.24), w: Math.round(W * 0.2), h: 8, fill: G, rad: 4, sw: 0 },
          { t: 'text', tx: "TITRE DE L'ANNONCE", x: m, y: Math.round(H * 0.27), w: W - 2 * m, h: 200, fs: Math.round(W / 10), col: '#ffffff', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: 'Sous-titre ou message d’accroche', x: m, y: Math.round(H * 0.5), w: W - 2 * m, h: 80, fs: Math.round(W / 22), col: '#cfe3ff', b: false, al: 'left', ff: 3, lh: 1.25 },
          { t: 'text', tx: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', x: m, y: Math.round(H * 0.6), w: W - 2 * m, h: 160, fs: Math.round(W / 24), col: '#ffffff', b: true, al: 'left', ff: 0, lh: 1.55 }
        ], foot(F, true));
      }
    },
    emploi: {
      l: 'Offre d’emploi / Recrutement', pal: 'blanc', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06);
        return [{ t: 'rect', x: 0, y: 0, w: W, h: Math.round(H * 0.3), fill: '#12305e', sw: 0, rad: 0 }].concat(head(F, true), [
          { t: 'text', tx: 'NOUS RECRUTONS', x: m, y: Math.round(H * 0.17), w: W - 2 * m, h: 100, fs: Math.round(W / 11), col: '#f2c94c', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: 'Poste : Ingénieur / Technicien…', x: m, y: Math.round(H * 0.35), w: W - 2 * m, h: 70, fs: Math.round(W / 17), col: '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'Profil recherché\n• Diplôme : …\n• Expérience : … ans\n• Compétences : …\n\nNous offrons\n• Contrat : …\n• Rémunération attractive', x: m, y: Math.round(H * 0.44), w: W - 2 * m, h: 360, fs: Math.round(W / 26), col: '#1c2b45', b: false, al: 'left', ff: 0, lh: 1.5 },
          { t: 'text', tx: 'Envoyez votre CV avant le … à ' + brand().email, x: m, y: Math.round(H * 0.77), w: W - 2 * m, h: 70, fs: Math.round(W / 24), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.25, bg: '#f2c94c', pad: 16, rad: 14 }
        ], foot(F, false));
      }
    },
    promo: {
      l: 'Promotion / Offre spéciale', pal: 'orange', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06);
        return head(F, true).concat([
          { t: 'text', tx: 'OFFRE SPÉCIALE', x: m, y: Math.round(H * 0.24), w: W - 2 * m, h: 90, fs: Math.round(W / 12), col: '#ffffff', b: true, al: 'center', ff: 1, lh: 1.05, sh: true },
          { t: 'ellipse', x: Math.round(W * 0.2), y: Math.round(H * 0.36), w: Math.round(W * 0.6), h: Math.round(W * 0.6), fill: '#ffffff', stroke: '#12305e', sw: 10 },
          { t: 'text', tx: '-20 %', x: Math.round(W * 0.2), y: Math.round(H * 0.36) + Math.round(W * 0.18), w: Math.round(W * 0.6), h: 200, fs: Math.round(W / 4.2), col: '#e8590c', b: true, al: 'center', ff: 1, lh: 1 },
          { t: 'text', tx: 'sur …  jusqu’au …', x: Math.round(W * 0.2), y: Math.round(H * 0.36) + Math.round(W * 0.44), w: Math.round(W * 0.6), h: 60, fs: Math.round(W / 24), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'Contactez-nous dès maintenant !', x: m, y: Math.round(H * 0.8), w: W - 2 * m, h: 60, fs: Math.round(W / 20), col: '#ffffff', b: true, al: 'center', ff: 0, lh: 1.2 }
        ], foot(F, true, '#ffffff'));
      }
    },
    avis: {
      l: 'Avis / Communiqué', pal: 'blanc', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.08);
        return head(F, false).concat([
          { t: 'rect', x: m, y: Math.round(H * 0.2), w: W - 2 * m, h: 6, fill: '#c9a227', rad: 3, sw: 0 },
          { t: 'text', tx: 'COMMUNIQUÉ', x: m, y: Math.round(H * 0.23), w: W - 2 * m, h: 100, fs: Math.round(W / 10), col: '#12305e', b: true, al: 'center', ff: 4, lh: 1.1, ls: 4 },
          { t: 'text', tx: 'Objet : …', x: m, y: Math.round(H * 0.34), w: W - 2 * m, h: 60, fs: Math.round(W / 20), col: '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'La direction de ' + brand().name + ' porte à la connaissance de sa clientèle et du public que …\n\nPour toute information complémentaire, veuillez nous contacter.', x: m, y: Math.round(H * 0.42), w: W - 2 * m, h: 380, fs: Math.round(W / 26), col: '#1c2b45', b: false, al: 'left', ff: 3, lh: 1.6 },
          { t: 'text', tx: 'Fait à Kinshasa, le …\nLa Direction', x: m, y: Math.round(H * 0.72), w: W - 2 * m, h: 90, fs: Math.round(W / 26), col: '#12305e', b: true, al: 'right', ff: 3, lh: 1.4 }
        ], foot(F, false));
      }
    },
    formation: {
      l: 'Formation / Séminaire', pal: 'noir', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06), G = PALETTES.noir[3];
        return head(F, true).concat([
          { t: 'text', tx: 'SESSION DE FORMATION', x: m, y: Math.round(H * 0.23), w: W - 2 * m, h: 50, fs: Math.round(W / 26), col: G, b: true, al: 'left', ff: 0, lh: 1.2, ls: 3 },
          { t: 'text', tx: 'Thème de la formation', x: m, y: Math.round(H * 0.27), w: W - 2 * m, h: 180, fs: Math.round(W / 11), col: '#ffffff', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: '• Objectif 1\n• Objectif 2\n• Objectif 3\n• Attestation de participation', x: m, y: Math.round(H * 0.47), w: W - 2 * m, h: 240, fs: Math.round(W / 22), col: '#e8edf5', b: false, al: 'left', ff: 0, lh: 1.6 },
          { t: 'text', tx: 'Frais : … $   |   Durée : …   |   Début : …', x: m, y: Math.round(H * 0.72), w: W - 2 * m, h: 60, fs: Math.round(W / 24), col: '#0b0f17', b: true, al: 'center', ff: 0, lh: 1.25, bg: G, pad: 16, rad: 14 }
        ], foot(F, true, G));
      }
    }
  };
  /* ---------- bibliothèque de modèles supplémentaires (V99 modèles-2) ---------- */
  PALETTES.jaune = ['#ffd54a', '#f5b800', 160, '#12305e'];
  PALETTES.gris = ['#f1f3f6', '#d9dee7', 180, '#12305e'];
  function flat(a) { return [].concat.apply([], a); }
  function K(F) {
    var W = F.w, H = F.h, m = Math.round(W * 0.07), iw = W - 2 * m, B = brand();
    return {
      W: W, H: H, m: m, iw: iw, B: B,
      T: function (s, yp, dv, col, o) { return Object.assign({ t: 'text', tx: s, x: m, y: Math.round(H * yp), w: iw, h: 60, fs: Math.round(W / dv), col: col, b: false, al: 'left', ff: 0, lh: 1.25 }, o || {}); },
      X: function (s, xp, yp, wp, dv, col, o) { return Object.assign({ t: 'text', tx: s, x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: 60, fs: Math.round(W / dv), col: col, b: false, al: 'left', ff: 0, lh: 1.25 }, o || {}); },
      R: function (xp, yp, wp, hp, fill, o) { return Object.assign({ t: 'rect', x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: Math.round(H * hp), fill: fill, sw: 0, rad: 0 }, o || {}); },
      E: function (xp, yp, wp, fill, o) { return Object.assign({ t: 'ellipse', x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: Math.round(W * wp), fill: fill, sw: 0 }, o || {}); },
      L: function (yp, col, o) { return Object.assign({ t: 'rect', x: m, y: Math.round(H * yp), w: iw, h: 5, fill: col, rad: 3, sw: 0 }, o || {}); },
      P: function (xp, yp, wp, hp, lb) {
        var fs = Math.round(W / 34);
        return [{ t: 'rect', x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: Math.round(H * hp), fill: '#e3eaf4', stroke: '#9fb0c8', sw: 3, rad: 14 },
          { t: 'text', tx: '📷 ' + (lb || 'Photo ici (bouton « ＋ Photo »)'), x: Math.round(W * xp), y: Math.round(H * (yp + hp / 2)) - fs, w: Math.round(W * wp), h: 40, fs: fs, col: '#5e6f8c', b: true, al: 'center', ff: 0, lh: 1.2 }];
      },
      rows: function (arr, yp, dv, col, pcol) {
        var fs = Math.round(W / dv), rh = Math.round(fs * 2.15), y0 = Math.round(H * yp), out = [];
        arr.forEach(function (r, i) {
          var y = y0 + i * rh;
          out.push({ t: 'text', tx: r[0], x: m, y: y, w: Math.round(iw * 0.62), h: fs, fs: fs, col: col, b: false, al: 'left', ff: 0, lh: 1.2 });
          out.push({ t: 'text', tx: r[1], x: m + Math.round(iw * 0.62), y: y, w: Math.round(iw * 0.38), h: fs, fs: fs, col: pcol || col, b: true, al: 'right', ff: 0, lh: 1.2 });
          out.push({ t: 'rect', x: m, y: y + Math.round(fs * 1.5), w: iw, h: 2, fill: '#d5dce8', sw: 0, rad: 0 });
        });
        return out;
      }
    };
  }
  var TPL2 = {
    /* ===== Communiqués & avis ===== */
    comm_officiel: {
      g: 'Communiqués & avis', l: 'Communiqué officiel (presse / public)', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.T('COMMUNIQUÉ', 0.2, 22, '#c9a227', { b: true, al: 'right', ls: 4 }),
          k.T('POUR PUBLICATION IMMÉDIATE', 0.232, 42, '#5e6877', { al: 'right', i: true }),
          k.L(0.262, '#12305e'),
          k.T('TITRE DU COMMUNIQUÉ : L’ESSENTIEL EN UNE PHRASE', 0.29, 21, '#12305e', { b: true, al: 'center', ff: 3, lh: 1.15 }),
          k.T('Kinshasa, le … —', 0.42, 28, '#1c2b45', { b: true }),
          k.T('Dès la première phrase : qui, quoi, quand, où. ' + B.name + ' annonce que …\n\nDeuxième paragraphe : les détails, les chiffres, la citation d’un responsable.\n\nTroisième paragraphe : la suite et les prochaines étapes.', 0.455, 27, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('— 30 —', 0.69, 26, '#12305e', { al: 'center', b: true }),
          k.T('Contact presse\nNom Prénom, fonction\n📞 ' + B.phone + '    ✉ ' + B.email, 0.73, 31, '#12305e', { lh: 1.45 }),
          foot(F, false)]);
      }
    },
    avis_fermeture: {
      g: 'Communiqués & avis', l: 'Avis de fermeture / changement d’horaires', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.R(0, 0.2, 1, 0.075, '#c0392b'),
          k.T('AVIS IMPORTANT', 0.2235, 20, '#ffffff', { b: true, al: 'center', ls: 5, ff: 1 }),
          k.T('FERMETURE EXCEPTIONNELLE', 0.32, 17, '#c0392b', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('Nous informons notre aimable clientèle et nos partenaires que nos bureaux seront fermés du … au … inclus.\nReprise normale des activités le … à … h.\nPour toute urgence, contactez-nous au numéro ci-dessous.', 0.4, 29, '#1c2b45', { lh: 1.5 }),
          k.T('Horaires habituels\nLundi – vendredi : 8 h – 17 h\nSamedi : 8 h – 13 h', 0.6, 30, '#12305e', { b: true, lh: 1.5, bg: '#eef2f8', pad: 22, rad: 14 }),
          k.T('Merci de votre compréhension.', 0.8, 24, '#12305e', { b: true, al: 'center', i: true }),
          foot(F, false)]);
      }
    },
    avis_ao: {
      g: 'Communiqués & avis', l: 'Avis d’appel d’offres', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.L(0.2, '#12305e'),
          k.T('AVIS D’APPEL D’OFFRES', 0.225, 18, '#12305e', { b: true, al: 'center', ff: 3, lh: 1.1 }),
          k.T('N° …… / ' + B.name.toUpperCase() + ' / 20…', 0.285, 30, '#5e6877', { al: 'center', b: true }),
          k.T('Objet : …', 0.33, 24, '#12305e', { b: true, lh: 1.3 }),
          k.rows([['Maître d’ouvrage', '…'], ['Nature des travaux / fournitures', '…'], ['Lieu d’exécution', '…'], ['Délai d’exécution', '… mois'], ['Retrait du dossier', '… (adresse)'], ['Date limite de dépôt', '… à … h'], ['Ouverture des plis', '… à … h']], 0.395, 29, '#1c2b45', '#12305e'),
          k.T('Les soumissionnaires fourniront les pièces administratives et techniques exigées par le dossier d’appel d’offres. La Direction se réserve le droit de ne donner suite à tout ou partie du présent avis.', 0.72, 33, '#42526e', { i: true, lh: 1.4, ff: 3 }),
          k.T('Fait à Kinshasa, le …\nLa Direction', 0.795, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    avis_reunion: {
      g: 'Communiqués & avis', l: 'Convocation / avis de réunion', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.L(0.2, '#c9a227'),
          k.T('CONVOCATION', 0.225, 11, '#12305e', { b: true, al: 'center', ls: 4, ff: 4 }),
          k.T('Réunion : …', 0.31, 22, '#12305e', { b: true }),
          k.T('📅 Date : …\n🕘 Heure : … h\n📍 Lieu : …', 0.37, 24, '#1c2b45', { lh: 1.55, b: true }),
          k.T('Ordre du jour', 0.53, 24, '#c9a227', { b: true, ls: 2 }),
          k.T('1. Ouverture et adoption de l’ordre du jour\n2. Point sur l’avancement des chantiers\n3. Situation financière\n4. Divers', 0.575, 26, '#1c2b45', { lh: 1.6 }),
          k.T('Votre présence est vivement souhaitée. En cas d’empêchement, prière d’en informer le secrétariat.', 0.745, 29, '#42526e', { i: true, ff: 3, lh: 1.4 }),
          k.T('Fait à Kinshasa, le …\nLa Direction', 0.8, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    avis_adresse: {
      g: 'Communiqués & avis', l: 'Changement d’adresse / de contacts', pal: 'ciel', fmt: 'sq', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.T('NOUVELLE ADRESSE', 0.26, 14, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.R(0.08, 0.36, 0.84, 0.28, '#ffffff', { rad: 28, stroke: '#12305e', sw: 4 }),
          k.T('📍 Nouvelle adresse :\n…………………………', 0.385, 22, '#12305e', { b: true, al: 'center', lh: 1.5, x: Math.round(F.w * 0.1), w: Math.round(F.w * 0.8) }),
          k.T('Nous avons déménagé ! Retrouvez-nous dès le … à notre nouvelle adresse. Nos numéros et e-mails restent inchangés.', 0.69, 27, '#1c2b45', { al: 'center', lh: 1.4 }),
          k.T('📞 ' + B.phone + '    ✉ ' + B.email, 0.82, 33, '#12305e', { b: true, al: 'center' })]);
      }
    },
    avis_fraude: {
      g: 'Communiqués & avis', l: 'Mise en garde — fraude / faux agents', pal: 'rouge', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, true),
          k.T('⚠ ATTENTION', 0.21, 9, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('MISE EN GARDE', 0.31, 20, '#f2c94c', { b: true, al: 'center', ls: 6 }),
          k.T('Nous constatons que des personnes malveillantes utilisent frauduleusement le nom de ' + B.name + ' pour demander de l’argent.', 0.38, 26, '#ffffff', { al: 'center', lh: 1.45, b: true }),
          k.T('✔ Aucun paiement ne se fait en espèces à un agent non identifié.\n✔ Seuls nos comptes officiels sont valables.\n✔ Vérifiez toujours l’identité de l’agent avant tout versement.\n✔ En cas de doute, appelez-nous.', 0.55, 27, '#ffffff', { lh: 1.55 }),
          k.T('Signalez toute tentative de fraude : ' + B.phone, 0.78, 26, '#7a0c1c', { b: true, al: 'center', bg: '#ffffff', pad: 18, rad: 14 }),
          foot(F, true, '#ffffff')]);
      }
    },
    note_service: {
      g: 'Communiqués & avis', l: 'Note de service', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('NOTE DE SERVICE', 0.2, 14, '#12305e', { b: true, al: 'center', ff: 4, ls: 3 }),
          k.T('N° …… /…… /20…', 0.25, 32, '#5e6877', { al: 'center' }),
          k.R(0.07, 0.29, 0.86, 0.12, '#eef2f8', { rad: 12 }),
          k.X('De : …\nÀ : Tout le personnel\nDate : …', 0.09, 0.3, 0.8, 28, '#12305e', { b: true, lh: 1.5 }),
          k.T('Objet : …', 0.44, 24, '#12305e', { b: true }),
          k.T('Le Directeur informe l’ensemble du personnel que, à compter du …, …\n\nEn conséquence, il est demandé à chacun de :\n• …\n• …\n\nLa présente note est d’application immédiate.', 0.49, 27, '#1c2b45', { lh: 1.55 }),
          k.T('Fait à Kinshasa, le …\nLe Directeur', 0.76, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    /* ===== Livres ===== */
    livre_couv: {
      g: 'Livres', l: 'Couverture de livre', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3], W = F.w, H = F.h;
        return flat([
          k.R(0.07, 0.06, 0.86, 0.004, G, { rad: 2 }),
          k.T('COLLECTION · …', 0.08, 36, G, { b: true, al: 'center', ls: 4 }),
          k.T('TITRE DU LIVRE', 0.2, 8.5, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.05, sh: true }),
          k.R(0.38, 0.5, 0.24, 0.004, G, { rad: 2 }),
          k.T('Sous-titre : la promesse du livre en une phrase', 0.53, 24, '#cfe3ff', { al: 'center', ff: 3, i: true, lh: 1.3 }),
          k.E(0.32, 0.6, 0.36, '#1d2635', { stroke: G, sw: 4 }),
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.375), y: Math.round(H * 0.6) + Math.round(W * 0.055), w: Math.round(W * 0.25), h: Math.round(W * 0.25), fit: 'contain', op: 1, rad: 0 },
          k.T('PRÉNOM NOM', 0.88, 15, '#ffffff', { b: true, al: 'center', ls: 5 }),
          k.T('Éditions ' + k.B.name, 0.94, 40, G, { al: 'center', i: true })]);
      }
    },
    livre_dedic: {
      g: 'Livres', l: 'Lancement / séance de dédicace', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('LANCEMENT OFFICIEL', 0.205, 22, G, { b: true, al: 'center', ls: 4 }),
          k.T('TITRE DU LIVRE', 0.245, 12, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.05, sh: true }),
          k.T('de Prénom NOM', 0.305, 24, '#cfe3ff', { al: 'center', i: true, ff: 3 }),
          k.P(0.3, 0.355, 0.4, 0.29, 'Couverture du livre (＋ Photo)'),
          k.T('Séance de dédicace et rencontre avec l’auteur', 0.665, 27, '#ffffff', { b: true, al: 'center' }),
          k.T('📅 Date : …     🕘 Heure : …\n📍 Lieu : …', 0.715, 26, '#ffffff', { b: true, al: 'center', lh: 1.5 }),
          k.T('ENTRÉE LIBRE', 0.81, 24, '#12305e', { b: true, al: 'center', bg: G, pad: 14, rad: 12, ls: 3 }),
          foot(F, true, G)]);
      }
    },
    livre_vente: {
      g: 'Livres', l: 'Livre en vente (réseaux sociaux)', pal: 'noir', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.noir[3];
        return flat([
          k.T('NOUVEAUTÉ', 0.06, 16, G, { b: true, ls: 6, x: Math.round(F.w * 0.07), w: Math.round(F.w * 0.5) }),
          k.P(0.07, 0.13, 0.4, 0.62, 'Couverture'),
          k.X('TITRE DU LIVRE', 0.52, 0.14, 0.42, 14, '#ffffff', { b: true, ff: 3, lh: 1.1 }),
          k.X('Une phrase d’accroche qui donne envie de lire.', 0.52, 0.34, 0.42, 30, '#cfe3ff', { i: true, ff: 3, lh: 1.4 }),
          k.X('Prénom NOM', 0.52, 0.5, 0.42, 26, G, { b: true }),
          k.X('… $', 0.52, 0.58, 0.42, 9, '#ffffff', { b: true, ff: 1 }),
          k.R(0, 0.82, 1, 0.18, G),
          k.T('📍 Disponible : …\n📞 ' + k.B.phone, 0.845, 27, '#0b0f17', { b: true, lh: 1.5, al: 'center' })]);
      }
    },
    livre_cata: {
      g: 'Livres', l: 'Catalogue de livres / manuels', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), out = [head(F, false), k.T('NOS PUBLICATIONS', 0.2, 16, '#12305e', { b: true, al: 'center', ff: 1 }), k.L(0.25, '#c9a227')], i, y;
        for (i = 0; i < 3; i++) {
          y = 0.285 + i * 0.205;
          out.push(k.R(0.07, y, 0.18, 0.17, '#12305e', { rad: 8 }));
          out.push(k.X('📘', 0.115, y + 0.045, 0.1, 14, '#ffffff', { al: 'center' }));
          out.push(k.X('Titre du livre ' + (i + 1), 0.28, y + 0.005, 0.65, 24, '#12305e', { b: true }));
          out.push(k.X('Auteur · Format · … pages\nUne ligne de présentation du contenu.', 0.28, y + 0.05, 0.65, 33, '#42526e', { lh: 1.45 }));
          out.push(k.X('… $', 0.28, y + 0.115, 0.4, 24, '#c9a227', { b: true }));
        }
        out.push(foot(F, false));
        return flat(out);
      }
    },
    livre_extrait: {
      g: 'Livres', l: 'Citation / extrait de livre', pal: 'marine', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([
          k.X('“', 0.08, 0.04, 0.2, 5, G, { b: true, ff: 3, lh: 0.8 }),
          k.T('Une phrase forte du livre, celle qui reste en tête, s’affiche ici en grand.', 0.25, 16, '#ffffff', { ff: 3, i: true, al: 'center', lh: 1.3 }),
          k.R(0.4, 0.62, 0.2, 0.005, G, { rad: 2 }),
          k.T('Prénom NOM', 0.66, 22, G, { b: true, al: 'center' }),
          k.T('Titre du livre · Éditions ' + k.B.name, 0.72, 32, '#cfe3ff', { al: 'center', i: true }),
          k.T('📚 Disponible dès maintenant', 0.88, 30, '#ffffff', { al: 'center', b: true })]);
      }
    },
    livre_ebook: {
      g: 'Livres', l: 'Ebook / guide à télécharger', pal: 'ciel', fmt: 'story', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('GUIDE GRATUIT', 0.18, 14, '#c9a227', { b: true, al: 'center', ls: 5 }),
          k.T('TITRE DU GUIDE', 0.215, 9, '#12305e', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('Ce que vous allez apprendre en … pages', 0.33, 26, '#42526e', { al: 'center', i: true, ff: 3 }),
          k.P(0.2, 0.39, 0.6, 0.27, 'Couverture'),
          k.T('✔ Point clé n° 1\n✔ Point clé n° 2\n✔ Point clé n° 3', 0.69, 19, '#12305e', { b: true, lh: 1.6, x: Math.round(F.w * 0.14), w: Math.round(F.w * 0.74) }),
          k.T('TÉLÉCHARGER', 0.83, 16, '#ffffff', { b: true, al: 'center', bg: '#12305e', pad: 24, rad: 40, ls: 4 }),
          k.T('✉ ' + k.B.email, 0.92, 27, '#12305e', { al: 'center' })]);
      }
    },
    /* ===== Équipements & matériel ===== */
    eq_location: {
      g: 'Équipements & matériel', l: 'Location d’engins et d’équipements', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3], out = [head(F, true), k.T('LOCATION D’ENGINS', 0.205, 12, G, { b: true, ff: 1, lh: 1.05 }), k.T('et d’équipements de chantier', 0.27, 24, '#ffffff', { i: true, ff: 3 })], items = [['🚜', 'Excavatrice'], ['🏗', 'Grue / Levage'], ['🚛', 'Camion benne'], ['🧱', 'Bétonnière']], i, x, y;
        for (i = 0; i < 4; i++) {
          x = 0.07 + (i % 2) * 0.445; y = 0.34 + Math.floor(i / 2) * 0.25;
          out.push(k.R(x, y, 0.42, 0.22, '#1d2635', { rad: 16, stroke: G, sw: 3 }));
          out.push(k.X(items[i][0], x, y + 0.01, 0.42, 11, '#ffffff', { al: 'center' }));
          out.push(k.X(items[i][1], x, y + 0.095, 0.42, 26, '#ffffff', { al: 'center', b: true }));
          out.push(k.X('… $ / jour', x, y + 0.14, 0.42, 28, G, { al: 'center', b: true }));
        }
        out.push(k.T('Avec ou sans opérateur · Livraison sur chantier · Contrats flexibles', 0.855, 36, '#e8edf5', { al: 'center' }));
        out.push(foot(F, true, G));
        return flat(out);
      }
    },
    eq_vente: {
      g: 'Équipements & matériel', l: 'Vente de matériaux / liste de prix', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('MATÉRIAUX & ÉQUIPEMENTS', 0.2, 17, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.T('Liste de prix · valable jusqu’au …', 0.25, 32, '#5e6877', { al: 'center', i: true }),
          k.L(0.285, '#c9a227'),
          k.rows([['Ciment (sac de 50 kg)', '… $'], ['Fer à béton Ø 8 / Ø 10 / Ø 12', '… $'], ['Tôle bac alu-zinc', '… $ / m²'], ['Briques / parpaings', '… $ / pièce'], ['Sable / gravier', '… $ / m³'], ['Peinture (seau 20 L)', '… $'], ['Carrelage', '… $ / m²']], 0.31, 27, '#1c2b45', '#12305e'),
          k.T('Prix hors transport · Livraison possible sur chantier', 0.8, 32, '#42526e', { al: 'center', i: true }),
          foot(F, false)]);
      }
    },
    eq_fiche: {
      g: 'Équipements & matériel', l: 'Fiche d’un équipement', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('NOM DE L’ÉQUIPEMENT', 0.2, 15, '#12305e', { b: true, ff: 1, lh: 1.05 }),
          k.T('Marque · Modèle · Année', 0.255, 30, '#5e6877', { i: true }),
          k.P(0.07, 0.3, 0.86, 0.26),
          k.T('Caractéristiques', 0.575, 26, '#c9a227', { b: true, ls: 2 }),
          k.rows([['Puissance', '…'], ['Capacité', '…'], ['Poids', '…'], ['État', 'Neuf / Occasion']], 0.615, 28, '#1c2b45', '#12305e'),
          k.T('PRIX : … $', 0.8, 18, '#12305e', { b: true, al: 'center', bg: '#f2c94c', pad: 16, rad: 14 }),
          foot(F, false)]);
      }
    },
    eq_arrivage: {
      g: 'Équipements & matériel', l: 'Nouvel arrivage / stock disponible', pal: 'orange', fmt: 'sq', f: function (F) {
        var k = K(F);
        return flat([head(F, true),
          k.T('NOUVEL ARRIVAGE', 0.24, 13, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('Stock disponible dès maintenant', 0.33, 26, '#ffffff', { al: 'center', i: true, ff: 3 }),
          k.R(0.08, 0.42, 0.84, 0.28, '#ffffff', { rad: 26 }),
          k.T('• Équipement / produit 1 — … $\n• Équipement / produit 2 — … $\n• Équipement / produit 3 — … $', 0.45, 29, '#12305e', { b: true, lh: 1.7, x: Math.round(F.w * 0.12), w: Math.round(F.w * 0.78) }),
          k.T('Quantités limitées · Réservez dès aujourd’hui', 0.74, 30, '#ffffff', { al: 'center', b: true }),
          k.T('📞 ' + k.B.phone, 0.81, 28, '#12305e', { al: 'center', b: true, bg: '#ffffff', pad: 12, rad: 30, x: Math.round(F.w * 0.25), w: Math.round(F.w * 0.5) })]);
      }
    },
    eq_epi: {
      g: 'Équipements & matériel', l: 'Consignes de sécurité — port des EPI', pal: 'jaune', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([
          k.R(0, 0, 1, 0.14, '#12305e'),
          k.T('⚠ SÉCURITÉ SUR CHANTIER', 0.045, 21, '#ffd54a', { b: true, al: 'center', ff: 1 }),
          k.T('PORT DES EPI OBLIGATOIRE', 0.18, 11, '#12305e', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('⛑ Casque de protection\n🦺 Gilet haute visibilité\n🥾 Chaussures de sécurité\n🧤 Gants de travail\n🥽 Lunettes de protection', 0.31, 17, '#12305e', { b: true, lh: 1.55, x: Math.round(F.w * 0.14), w: Math.round(F.w * 0.76) }),
          k.T('ACCÈS INTERDIT AUX PERSONNES NON AUTORISÉES', 0.74, 24, '#ffffff', { b: true, al: 'center', bg: '#c0392b', pad: 18, rad: 12, lh: 1.25 }),
          k.T('La sécurité est l’affaire de tous.', 0.86, 24, '#12305e', { al: 'center', i: true, ff: 3 }),
          k.T(k.B.name + ' · ' + k.B.phone, 0.93, 34, '#12305e', { al: 'center', b: true })]);
      }
    },
    /* ===== Logiciels & formations ===== */
    lf_logiciel: {
      g: 'Logiciels & formations', l: 'Formation sur un logiciel (AutoCAD, Revit…)', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('FORMATION PROFESSIONNELLE', 0.205, 30, G, { b: true, ls: 4 }),
          k.T('AUTOCAD', 0.24, 7.5, '#ffffff', { b: true, ff: 1, lh: 1, sh: true }),
          k.T('Nom du logiciel — niveau : débutant à avancé', 0.35, 26, '#cfe3ff', { i: true, ff: 3 }),
          k.T('Au programme', 0.42, 24, G, { b: true, ls: 2 }),
          k.T('✔ Interface et commandes essentielles\n✔ Dessin et modification de plans 2D\n✔ Cotation, calques et mise en page\n✔ Projet pratique encadré\n✔ Attestation de formation', 0.465, 26, '#ffffff', { lh: 1.55 }),
          k.T('Durée : … sem.  |  Frais : … $  |  Début : …', 0.735, 32, '#0b1f44', { b: true, al: 'center', bg: G, pad: 18, rad: 14 }),
          k.T('Places limitées · Inscrivez-vous maintenant', 0.82, 28, '#ffffff', { b: true, al: 'center' }),
          foot(F, true, G)]);
      }
    },
    lf_programme: {
      g: 'Logiciels & formations', l: 'Programme de formation (modules)', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), out = [head(F, false), k.T('PROGRAMME DE LA FORMATION', 0.2, 23, '#12305e', { b: true, al: 'center', ff: 1 }), k.T('Nom de la formation · … semaines', 0.248, 30, '#5e6877', { al: 'center', i: true }), k.L(0.28, '#c9a227')], mods = ['Prise en main et bases', 'Dessin / modélisation', 'Détails, annotations et rendu', 'Projet final et évaluation'], i, y;
        for (i = 0; i < 4; i++) {
          y = 0.3 + i * 0.12;
          out.push(k.R(0.07, y, 0.14, 0.1, '#12305e', { rad: 14 }));
          out.push(k.X('S' + (i + 1), 0.07, y + 0.026, 0.14, 15, '#f2c94c', { b: true, al: 'center', ff: 1 }));
          out.push(k.X(mods[i], 0.24, y + 0.003, 0.69, 26, '#12305e', { b: true }));
          out.push(k.X('Contenu du module : …', 0.24, y + 0.05, 0.69, 33, '#42526e'));
        }
        out.push(k.T('📅 Début : …  ·  🕘 Horaires : …  ·  📍 Lieu : …', 0.79, 38, '#12305e', { b: true, al: 'center' }));
        out.push(foot(F, false));
        return flat(out);
      }
    },
    lf_pack: {
      g: 'Logiciels & formations', l: 'Pack de formation multi-logiciels', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3], out = [head(F, true), k.T('PACK BTP COMPLET', 0.2, 15, G, { b: true, ff: 1 }), k.T('3 logiciels · 1 seule formation', 0.26, 26, '#ffffff', { i: true, ff: 3 })], nm = ['AutoCAD', 'SketchUp', 'ArchiCAD'], de = ['Plans 2D', 'Modélisation 3D', 'BIM'], i, x;
        for (i = 0; i < 3; i++) {
          x = 0.07 + i * 0.295;
          out.push(k.R(x, 0.34, 0.27, 0.22, '#1d2635', { rad: 16, stroke: G, sw: 3 }));
          out.push(k.X(nm[i], x, 0.375, 0.27, 33, '#ffffff', { b: true, al: 'center' }));
          out.push(k.X(de[i], x, 0.43, 0.27, 38, G, { al: 'center', i: true }));
          out.push(k.X('… sem.', x, 0.485, 0.27, 38, '#ffffff', { al: 'center' }));
        }
        out.push(k.T('PRIX DU PACK : … $', 0.6, 19, '#0b0f17', { b: true, al: 'center', bg: G, pad: 18, rad: 14 }));
        out.push(k.T('au lieu de … $', 0.67, 32, '#e8edf5', { al: 'center', i: true }));
        out.push(k.T('✔ Support de cours  ✔ Projet pratique  ✔ Attestation', 0.72, 36, '#ffffff', { al: 'center', b: true }));
        out.push(foot(F, true, G));
        return flat(out);
      }
    },
    lf_liste: {
      g: 'Logiciels & formations', l: 'Logiciels enseignés', pal: 'ciel', fmt: 'a4p', f: function (F) {
        var k = K(F), L = ['AutoCAD', 'SketchUp', 'ArchiCAD', 'Revit', 'Lumion', 'Twinmotion', 'Civil 3D', 'ETABS', 'SAP2000', 'MS Project', 'Primavera P6', 'Excel pro'], out = [head(F, false), k.T('LOGICIELS ENSEIGNÉS', 0.2, 15, '#12305e', { b: true, al: 'center', ff: 1 }), k.T('Du dessin au calcul de structure, de la 3D à la planification', 0.25, 34, '#42526e', { al: 'center', i: true, ff: 3 })], i, x, y;
        for (i = 0; i < 12; i++) {
          x = 0.07 + (i % 3) * 0.295; y = 0.31 + Math.floor(i / 3) * 0.12;
          out.push(k.R(x, y, 0.27, 0.095, '#ffffff', { rad: 14, stroke: '#12305e', sw: 3 }));
          out.push(k.X(L[i], x, y + 0.032, 0.27, 34, '#12305e', { b: true, al: 'center' }));
        }
        out.push(k.T('+ 3ds Max · Robot · Tekla · Métré & devis', 0.8, 30, '#12305e', { al: 'center', b: true }));
        out.push(foot(F, false));
        return flat(out);
      }
    },
    lf_certif: {
      g: 'Logiciels & formations', l: 'Certification / test QCM', pal: 'vert', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.vert[3];
        return flat([head(F, true),
          k.T('TESTEZ VOS COMPÉTENCES', 0.25, 14, '#ffffff', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('QCM · Logiciel : …', 0.4, 21, G, { b: true, al: 'center' }),
          k.T('✔ … questions corrigées\n✔ Résultat immédiat\n✔ Attestation de réussite', 0.5, 25, '#ffffff', { b: true, lh: 1.6, x: Math.round(F.w * 0.2), w: Math.round(F.w * 0.7) }),
          k.T('PASSER LE TEST', 0.76, 17, '#0e3b2e', { b: true, al: 'center', bg: G, pad: 18, rad: 40, ls: 3, x: Math.round(F.w * 0.18), w: Math.round(F.w * 0.64) }),
          k.T('📞 ' + k.B.phone, 0.9, 26, '#ffffff', { al: 'center' })]);
      }
    },
    lf_webinaire: {
      g: 'Logiciels & formations', l: 'Webinaire / atelier en ligne', pal: 'marine', fmt: 'ban', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([
          { t: 'img', src: logoSrcForStudio(), x: Math.round(F.w * 0.04), y: Math.round(F.h * 0.07), w: Math.round(F.h * 0.2), h: Math.round(F.h * 0.2), fit: 'contain', op: 1, rad: 0 },
          k.X('WEBINAIRE GRATUIT', 0.04, 0.33, 0.6, 28, G, { b: true, ls: 4 }),
          k.X('Titre de l’atelier en ligne', 0.04, 0.42, 0.62, 17, '#ffffff', { b: true, ff: 1, lh: 1.05 }),
          k.X('📅 … à … h   ·   💻 En ligne (lien envoyé à l’inscription)', 0.04, 0.72, 0.62, 44, '#cfe3ff', { b: true }),
          k.R(0.72, 0.18, 0.25, 0.64, '#ffffff', { rad: 24 }),
          k.X('S’INSCRIRE', 0.72, 0.32, 0.25, 30, '#12305e', { b: true, al: 'center', ls: 2 }),
          k.X('✉ ' + k.B.email, 0.72, 0.5, 0.25, 62, '#42526e', { al: 'center' }),
          k.X('📞 ' + k.B.phone, 0.72, 0.62, 0.25, 62, '#42526e', { al: 'center', b: true })]);
      }
    },
    lf_inscr: {
      g: 'Logiciels & formations', l: 'Inscriptions ouvertes (story / statut)', pal: 'orange', fmt: 'story', f: function (F) {
        var k = K(F);
        return flat([head(F, true),
          k.T('INSCRIPTIONS', 0.2, 11, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('OUVERTES', 0.25, 11, '#12305e', { b: true, al: 'center', ff: 1, sh: true }),
          k.R(0.08, 0.34, 0.84, 0.3, '#ffffff', { rad: 28 }),
          k.T('Formation : …\n📅 Début : …\n⏱ Durée : …\n💵 Frais : … $', 0.355, 20, '#12305e', { b: true, lh: 1.6, x: Math.round(F.w * 0.13), w: Math.round(F.w * 0.74) }),
          k.T('Places limitées !', 0.7, 14, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('📞 ' + k.B.phone + '\n✉ ' + k.B.email, 0.78, 26, '#12305e', { b: true, al: 'center', lh: 1.5 }),
          k.T('📍 ' + k.B.address, 0.88, 28, '#ffffff', { al: 'center', b: true })]);
      }
    },
    lf_attest: {
      g: 'Logiciels & formations', l: 'Attestation de formation (paysage)', pal: 'blanc', fmt: 'a4l', f: function (F) {
        var k = K(F), W = F.w, H = F.h;
        return flat([
          k.R(0.02, 0.03, 0.96, 0.94, 'rgba(0,0,0,0)', { rad: 10, stroke: '#c9a227', sw: 6 }),
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.07), y: Math.round(H * 0.07), w: Math.round(H * 0.17), h: Math.round(H * 0.17), fit: 'contain', op: 1, rad: 0 },
          k.T(k.B.name.toUpperCase(), 0.1, 40, '#12305e', { b: true, al: 'right', ls: 2 }),
          k.T('ATTESTATION DE FORMATION', 0.27, 20, '#12305e', { b: true, al: 'center', ff: 4, ls: 3 }),
          k.T('Il est certifié que', 0.4, 36, '#5e6877', { al: 'center', i: true, ff: 3 }),
          k.T('PRÉNOM NOM', 0.46, 14, '#c9a227', { b: true, al: 'center', ff: 3 }),
          k.T('a suivi avec assiduité la formation « … » du … au …, d’une durée totale de … heures, et a satisfait aux évaluations.', 0.58, 38, '#1c2b45', { al: 'center', ff: 3, lh: 1.5 }),
          k.T('Fait à Kinshasa, le …', 0.76, 40, '#12305e', { b: true, al: 'left', ff: 3, w: Math.round(W * 0.4) }),
          k.T('La Direction', 0.76, 40, '#12305e', { b: true, al: 'right', ff: 3, x: Math.round(W * 0.53), w: Math.round(W * 0.4) })]);
      }
    },
    /* ===== Textes professionnels ===== */
    tp_lettre: {
      g: 'Textes professionnels', l: 'Lettre professionnelle', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.L(0.19, '#12305e'),
          k.T('Kinshasa, le …', 0.21, 30, '#1c2b45', { al: 'right' }),
          k.T('À l’attention de : Nom Prénom\nFonction — Société\nAdresse', 0.26, 29, '#1c2b45', { b: true, lh: 1.45 }),
          k.T('Objet : …', 0.35, 26, '#12305e', { b: true }),
          k.T('Madame, Monsieur,\n\nNous avons l’honneur de … Suite à …, nous vous proposons de …\n\nNous restons à votre disposition pour tout complément d’information et vous prions d’agréer, Madame, Monsieur, l’expression de nos salutations distinguées.', 0.4, 28, '#1c2b45', { ff: 3, lh: 1.55 }),
          k.T('Le Directeur\n\nNom Prénom', 0.72, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    tp_offre: {
      g: 'Textes professionnels', l: 'Offre de services / présentation de l’entreprise', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.L(0.19, '#c9a227'),
          k.T('OFFRE DE SERVICES', 0.21, 15, '#12305e', { b: true, ff: 1 }),
          k.T('À propos', 0.285, 25, '#c9a227', { b: true, ls: 2 }),
          k.T(B.name + ' est une entreprise spécialisée en construction, architecture, études et conception. Depuis …, nous accompagnons nos clients de l’idée à la livraison.', 0.32, 29, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('Nos services', 0.445, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('✔ Construction et gros œuvre\n✔ Plans d’architecture et BIM\n✔ Études techniques et calcul de structure\n✔ Suivi de chantier, métrés et devis', 0.48, 28, '#1c2b45', { lh: 1.55 }),
          k.T('Pourquoi nous choisir ?', 0.67, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('Équipe qualifiée · Délais respectés · Devis clair et détaillé · Suivi régulier.', 0.705, 29, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('Demandez votre devis gratuit : ' + B.phone, 0.77, 31, '#ffffff', { b: true, al: 'center', bg: '#12305e', pad: 16, rad: 14 }),
          foot(F, false)]);
      }
    },
    tp_garde: {
      g: 'Textes professionnels', l: 'Page de garde (devis, rapport, dossier)', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3], W = F.w, H = F.h;
        return flat([
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.34), y: Math.round(H * 0.07), w: Math.round(W * 0.32), h: Math.round(W * 0.32), fit: 'contain', op: 1, rad: 0 },
          k.T(k.B.name.toUpperCase(), 0.33, 22, '#ffffff', { b: true, al: 'center', ls: 3 }),
          k.R(0.35, 0.39, 0.3, 0.005, G, { rad: 2 }),
          k.T('RAPPORT TECHNIQUE', 0.43, 11, '#ffffff', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('Projet : …\nClient : …', 0.53, 24, '#cfe3ff', { al: 'center', i: true, ff: 3, lh: 1.5 }),
          k.T('Référence : … · Version : 1 · Date : …', 0.7, 32, G, { al: 'center', b: true }),
          k.T('Établi par : …\nVérifié par : …', 0.77, 30, '#ffffff', { al: 'center', lh: 1.5 }),
          k.T('📞 ' + k.B.phone + '   ✉ ' + k.B.email + '\n📍 ' + k.B.address, 0.89, 36, '#cfe3ff', { al: 'center', lh: 1.5 })]);
      }
    },
    tp_attest: {
      g: 'Textes professionnels', l: 'Attestation de service / de stage', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.L(0.19, '#c9a227'),
          k.T('ATTESTATION', 0.22, 12, '#12305e', { b: true, al: 'center', ff: 4, ls: 4 }),
          k.T('Je soussigné, Nom Prénom, Directeur de ' + k.B.name + ', atteste que :', 0.33, 27, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('Madame / Monsieur NOM Prénom', 0.4, 19, '#12305e', { b: true, al: 'center', ff: 3 }),
          k.T('né(e) le … à …, a effectué au sein de notre entreprise un stage / a occupé le poste de … du … au …, pendant lequel il/elle a fait preuve de sérieux et de compétence.\n\nCette attestation est délivrée pour servir et valoir ce que de droit.', 0.47, 27, '#1c2b45', { ff: 3, lh: 1.55 }),
          k.T('Fait à Kinshasa, le …\nLe Directeur', 0.74, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    tp_invit: {
      g: 'Textes professionnels', l: 'Invitation officielle (inauguration, cérémonie)', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3];
        return flat([head(F, true),
          k.R(0.07, 0.205, 0.86, 0.004, G, { rad: 2 }),
          k.T('VOUS ÊTES INVITÉ(E)', 0.23, 24, G, { b: true, al: 'center', ls: 5 }),
          k.T('Inauguration / Cérémonie de …', 0.29, 13, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.1 }),
          k.T('La Direction de ' + k.B.name + ' a l’honneur de vous convier à la cérémonie de …, en présence de …', 0.43, 27, '#e8edf5', { al: 'center', ff: 3, lh: 1.5, i: true }),
          k.T('📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', 0.58, 22, '#ffffff', { b: true, al: 'center', lh: 1.6 }),
          k.T('Tenue de ville exigée · Merci de confirmer votre présence', 0.78, 31, G, { al: 'center', i: true }),
          foot(F, true, G)]);
      }
    },
    tp_pv: {
      g: 'Textes professionnels', l: 'Procès-verbal / compte rendu de réunion', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('PROCÈS-VERBAL DE RÉUNION', 0.2, 16, '#12305e', { b: true, al: 'center', ff: 4 }),
          k.L(0.245, '#c9a227'),
          k.T('Date : …    Lieu : …\nPrésents : …\nAbsents excusés : …', 0.27, 29, '#1c2b45', { b: true, lh: 1.5 }),
          k.T('Points discutés', 0.395, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('1. …\n2. …\n3. …', 0.435, 27, '#1c2b45', { lh: 1.6 }),
          k.T('Décisions et actions', 0.58, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('• Action 1 — responsable : … — échéance : …\n• Action 2 — responsable : … — échéance : …', 0.62, 29, '#1c2b45', { lh: 1.6 }),
          k.T('Prochaine réunion : …', 0.76, 28, '#12305e', { b: true }),
          k.T('Le Secrétaire de séance          Le Président', 0.82, 30, '#12305e', { b: true, al: 'center' }),
          foot(F, false)]);
      }
    },
    tp_voeux: {
      g: 'Textes professionnels', l: 'Vœux / remerciements', pal: 'marine', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('BONNE ET HEUREUSE', 0.25, 16, '#ffffff', { b: true, al: 'center', ff: 1 }),
          k.T('ANNÉE 20…', 0.33, 8, G, { b: true, al: 'center', ff: 1, sh: true }),
          k.T('Merci pour votre confiance. Toute l’équipe de ' + k.B.name + ' vous souhaite santé, réussite et beaux projets.', 0.52, 27, '#e8edf5', { al: 'center', ff: 3, i: true, lh: 1.4 }),
          k.R(0.4, 0.72, 0.2, 0.005, G, { rad: 2 }),
          k.T('La Direction et l’équipe', 0.76, 26, '#ffffff', { b: true, al: 'center' })]);
      }
    },
    /* ===== Chantiers & réalisations ===== */
    ch_panneau: {
      g: 'Chantiers & réalisations', l: 'Panneau de chantier', pal: 'blanc', fmt: 'a4l', f: function (F) {
        var k = K(F), W = F.w, H = F.h;
        return flat([
          k.R(0, 0, 1, 0.2, '#12305e'),
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.03), y: Math.round(H * 0.025), w: Math.round(H * 0.15), h: Math.round(H * 0.15), fit: 'contain', op: 1, rad: 0 },
          k.X('PANNEAU DE CHANTIER', 0.15, 0.04, 0.8, 22, '#ffffff', { b: true, ff: 1 }),
          k.X('Projet : …………………………', 0.15, 0.13, 0.8, 42, '#f2c94c', { b: true }),
          k.rows([['Maître d’ouvrage', '…'], ['Maître d’œuvre', '…'], ['Entreprise : ' + k.B.name, 'Tél. ' + k.B.phone], ['Permis de construire n°', '…'], ['Durée des travaux', 'Du … au …'], ['Coût des travaux', '… $']], 0.24, 44, '#1c2b45', '#12305e'),
          k.R(0, 0.93, 1, 0.07, '#f2c94c'),
          k.T('⚠ DANGER · CHANTIER INTERDIT AU PUBLIC', 0.945, 52, '#12305e', { b: true, al: 'center' })]);
      }
    },
    ch_realis: {
      g: 'Chantiers & réalisations', l: 'Projet réalisé (fiche réalisation)', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('PROJET RÉALISÉ', 0.2, 28, '#c9a227', { b: true, ls: 4 }),
          k.T('Nom du projet', 0.23, 17, '#12305e', { b: true, ff: 1, lh: 1.05 }),
          k.P(0.07, 0.3, 0.86, 0.3),
          k.rows([['Client', '…'], ['Lieu', '…'], ['Surface', '… m²'], ['Durée', '… mois']], 0.625, 28, '#1c2b45', '#12305e'),
          k.T('Livré dans les délais · Qualité garantie', 0.84, 28, '#12305e', { b: true, al: 'center', i: true }),
          foot(F, false)]);
      }
    },
    ch_avap: {
      g: 'Chantiers & réalisations', l: 'Avant / Après', pal: 'noir', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.noir[3];
        return flat([
          k.T('AVANT  /  APRÈS', 0.04, 11, '#ffffff', { b: true, al: 'center', ff: 1 }),
          k.P(0.05, 0.16, 0.435, 0.5, 'Avant'),
          k.P(0.515, 0.16, 0.435, 0.5, 'Après'),
          k.X('AVANT', 0.05, 0.69, 0.435, 24, '#ffffff', { b: true, al: 'center', ls: 4 }),
          k.X('APRÈS', 0.515, 0.69, 0.435, 24, G, { b: true, al: 'center', ls: 4 }),
          k.T('Rénovation / construction : … · Lieu : …', 0.77, 30, '#e8edf5', { al: 'center', i: true }),
          k.T(k.B.name + ' · ' + k.B.phone, 0.9, 30, G, { b: true, al: 'center' })]);
      }
    },
    ch_travaux: {
      g: 'Chantiers & réalisations', l: 'Avis de travaux (perturbation)', pal: 'jaune', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([
          k.R(0, 0, 1, 0.14, '#12305e'),
          k.T('⚠ ATTENTION · TRAVAUX', 0.045, 20, '#ffd54a', { b: true, al: 'center', ff: 1 }),
          k.T('AVIS DE TRAVAUX', 0.2, 12, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.T('Des travaux de … auront lieu à … du … au …, de … h à … h.', 0.31, 24, '#12305e', { b: true, al: 'center', lh: 1.4 }),
          k.T('Conséquences :\n• Circulation / accès perturbé\n• Bruit ponctuel\n• Stationnement restreint', 0.46, 25, '#12305e', { lh: 1.6, bg: 'rgba(255,255,255,.65)', pad: 24, rad: 14 }),
          k.T('Nous vous prions de nous excuser pour la gêne occasionnée.', 0.7, 27, '#12305e', { al: 'center', i: true, ff: 3 }),
          k.T('Renseignements : ' + k.B.phone, 0.8, 26, '#ffffff', { b: true, al: 'center', bg: '#12305e', pad: 16, rad: 14 }),
          k.T(k.B.name, 0.91, 28, '#12305e', { b: true, al: 'center' })]);
      }
    },
    ch_services: {
      g: 'Chantiers & réalisations', l: 'Nos services', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3], S = [['🏗', 'Construction'], ['📐', 'Architecture'], ['🧮', 'Études & conception'], ['🗺', 'Plans & BIM'], ['👷', 'Suivi de chantier'], ['🧾', 'Devis & métrés']], out = [head(F, true), k.T('NOS SERVICES', 0.2, 13, '#ffffff', { b: true, al: 'center', ff: 1 })], i, x, y;
        for (i = 0; i < 6; i++) {
          x = 0.07 + (i % 2) * 0.445; y = 0.29 + Math.floor(i / 2) * 0.185;
          out.push(k.R(x, y, 0.42, 0.16, 'rgba(255,255,255,.12)', { rad: 18, stroke: G, sw: 3 }));
          out.push(k.X(S[i][0], x, y + 0.012, 0.42, 14, '#ffffff', { al: 'center' }));
          out.push(k.X(S[i][1], x, y + 0.095, 0.42, 30, '#ffffff', { al: 'center', b: true }));
        }
        out.push(foot(F, true, G));
        return flat(out);
      }
    },
    ch_temoin: {
      g: 'Chantiers & réalisations', l: 'Témoignage client', pal: 'ciel', fmt: 'sq', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.X('“', 0.07, 0.22, 0.2, 6, '#c9a227', { b: true, ff: 3, lh: 0.8 }),
          k.T('Un travail soigné, des délais respectés et une équipe à l’écoute. Je recommande vivement.', 0.3, 25, '#12305e', { ff: 3, i: true, al: 'center', lh: 1.35 }),
          k.T('★ ★ ★ ★ ★', 0.58, 14, '#c9a227', { al: 'center' }),
          k.T('Prénom NOM', 0.67, 26, '#12305e', { b: true, al: 'center' }),
          k.T('Client · Projet : …', 0.73, 34, '#42526e', { al: 'center', i: true }),
          k.T('📞 ' + k.B.phone, 0.83, 30, '#12305e', { b: true, al: 'center' })]);
      }
    },
    ch_devis: {
      g: 'Chantiers & réalisations', l: 'Devis gratuit (appel à l’action)', pal: 'marine', fmt: 'story', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('VOTRE PROJET', 0.2, 11, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('COMMENCE ICI', 0.25, 11, G, { b: true, al: 'center', ff: 1, sh: true }),
          k.T('Construction · Rénovation · Plans · Études', 0.34, 24, '#cfe3ff', { al: 'center', i: true, ff: 3 }),
          k.R(0.08, 0.42, 0.84, 0.26, '#ffffff', { rad: 28 }),
          k.T('DEVIS GRATUIT', 0.45, 11, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.T('Réponse sous 48 h\nsans engagement', 0.55, 20, '#42526e', { al: 'center', lh: 1.4 }),
          k.T('📞 ' + k.B.phone, 0.74, 17, '#12305e', { b: true, al: 'center', bg: G, pad: 18, rad: 40 }),
          k.T('✉ ' + k.B.email + '\n📍 ' + k.B.address, 0.84, 28, '#ffffff', { al: 'center', lh: 1.6 })]);
      }
    }
  };
  Object.keys(TPL2).forEach(function (k) { TPL2[k].relax = true; TPL[k] = TPL2[k]; });
  /* ===== V156 : 76 modèles supplémentaires de communication d'entreprise (10 catégories) + 4 formats ===== */
  FMT.a5p = { l: 'A5 portrait (flyer)', w: 559, h: 794, mm: [148, 210], sc: 3 };
  FMT.card = { l: 'Carte de visite (90 × 50 mm)', w: 1063, h: 591, mm: [90, 50], sc: 3 };
  FMT.roll = { l: 'Kakemono / roll-up (85 × 200 cm)', w: 850, h: 2000, mm: null, sc: 1.2 };
  FMT.ytb = { l: 'Écran TV / vidéo (16:9)', w: 1280, h: 720, mm: null, sc: 1.5 };
  FMT.a6p = { l: 'A6 portrait (petit flyer)', w: 397, h: 559, mm: [105, 148], sc: 4 };
  FMT.dl = { l: 'Flyer DL (99 × 210 mm)', w: 374, h: 794, mm: [99, 210], sc: 4 };
  FMT.a3l = { l: 'A3 paysage', w: 1587, h: 1123, mm: [420, 297], sc: 2.2 };
  FMT.a2p = { l: 'A2 portrait (affiche 42 × 59,4 cm)', w: 1587, h: 2245, mm: [420, 594], sc: 1.5 };
  FMT.a1p = { l: 'A1 portrait (affiche 59,4 × 84,1 cm)', w: 2245, h: 3179, mm: [594, 841], sc: 1 };
  FMT.a0p = { l: 'A0 portrait (84,1 × 118,9 cm)', w: 3179, h: 4494, mm: [841, 1189], sc: 0.8 };
  FMT.ig45 = { l: 'Instagram / Facebook portrait (4:5)', w: 1080, h: 1350, mm: null, sc: 2 };
  FMT.pin = { l: 'Pinterest / TikTok photo (2:3)', w: 1000, h: 1500, mm: null, sc: 2 };
  FMT.xhd = { l: 'En-tête X / Twitter (3:1)', w: 1500, h: 500, mm: null, sc: 2 };
  FMT.fbc = { l: 'Couverture Facebook (820 × 312)', w: 1640, h: 624, mm: null, sc: 1.5 };
  FMT.wa = { l: 'Statut WhatsApp (9:16)', w: 1080, h: 1920, mm: null, sc: 1.6 };
  FMT.sq20 = { l: 'Carré imprimé 20 × 20 cm', w: 756, h: 756, mm: [200, 200], sc: 3 };
  FMT.bad = { l: 'Badge / étiquette (10 × 15 cm)', w: 567, h: 850, mm: [100, 150], sc: 3 };
  FMT.b0 = { l: 'Bâche / panneau 3 × 1 m', w: 3000, h: 1000, mm: null, sc: 0.7 };
  FMT.b4 = { l: 'Bâche / panneau 2 × 1 m', w: 2000, h: 1000, mm: null, sc: 0.8 };
  FMT.roll2 = { l: 'Kakemono 100 × 200 cm', w: 1000, h: 2000, mm: null, sc: 1.1 };
  var TPL3 = {}, SC3 = 1, LAST3 = { ok: true };
  var DARK3 = { marine: 1, noir: 1, vert: 1, rouge: 1, orange: 1 }, ACC3 = { marine: '#f2c94c', noir: '#e0b54a', vert: '#ffd54a', rouge: '#f2c94c', orange: '#12305e', ciel: '#c9a227', blanc: '#c9a227' };
  function sty3(p) { var dk = !!DARK3[p]; return { dk: dk, ink: dk ? '#ffffff' : '#12305e', mut: dk ? '#dbe8ff' : '#42526e', acc: ACC3[p] || '#c9a227', tile: dk ? 'rgba(255,255,255,.14)' : '#ffffff', edge: dk ? 'rgba(255,255,255,.35)' : '#cfd9e8' }; }
  /* constructeur de mise en page : empile les éléments de haut en bas, estime la hauteur des textes (le studio ajuste ensuite les chevauchements) */
  function B3(F, pal, short) {
    var W = F.w, H = F.h, m = Math.round(W * (short ? 0.05 : 0.07)), iw = W - 2 * m, s = sty3(pal), out = [], hs3 = Math.round(Math.min(W * 0.06, H * 0.16)), y = short ? Math.round(H * 0.05 + hs3 + H * 0.045) : Math.round(W * 0.27), B = brand();
    var api = {
      W: W, H: H, m: m, iw: iw, s: s, out: out, y: function () { return y; },
      gap: function (g) { y += Math.round(W * g * SC3); return api; },
      adv: function (px) { y += Math.round(px); return api; },
      t: function (tx, dv, col, o) {
        o = Object.assign({}, o || {}); var fs = Math.round(W / dv * SC3), lh = o.lh || 1.25, cw = o.w || iw, cpl = Math.max(4, Math.floor(cw / (fs * (o.ff === 1 ? 0.72 : o.b ? 0.6 : 0.53)))), n = 0, gp = o.gap == null ? 0.02 : o.gap, keep = o.keep; delete o.gap; delete o.keep;
        String(tx).split('\n').forEach(function (l) { n += Math.max(1, Math.ceil(l.length / cpl)); });
        var h = Math.round(n * fs * lh); out.push(Object.assign({ t: 'text', tx: tx, x: m, y: y, w: cw, h: h, fs: fs, col: col || s.ink, b: false, al: 'left', ff: 0, lh: lh }, o));
        if (!keep) y += h + Math.round(W * gp * SC3); return api;
      },
      r: function (x, yy, w, h, fill, o) { out.push(Object.assign({ t: 'rect', x: x, y: yy, w: w, h: h, fill: fill, sw: 0, rad: 0 }, o || {})); return api; },
      bar: function (al) { var w = Math.round(W * 0.2); return api.r(al === 'center' ? Math.round((W - w) / 2) : m, y, w, 8, s.acc, { rad: 4 }).gap(0.035); },
      cta: function (tx) { api.gap(0.015); return api.t(tx, 26, s.dk && s.acc !== '#12305e' ? '#12305e' : '#ffffff', { b: true, al: 'center', bg: s.dk && s.acc !== '#12305e' ? s.acc : '#12305e', pad: 16, rad: 40, gap: 0.02 }); },
      photo: function (h, lb, x, w) { h = Math.round(h * SC3); var fs = Math.round(W / 34 * SC3), px = x == null ? m : x, pw = w || iw; out.push({ t: 'rect', x: px, y: y, w: pw, h: h, fill: '#e3eaf4', stroke: '#9fb0c8', sw: 3, rad: 14 }); out.push({ t: 'text', tx: '📷 ' + (lb || 'Photo ici (bouton « ＋ Photo »)'), x: px, y: y + Math.round(h / 2) - fs, w: pw, h: 40, fs: fs, col: '#5e6f8c', b: true, al: 'center', ff: 0, lh: 1.2 }); y += h + Math.round(W * 0.025 * SC3); return api; },
      step: function (n, ti, de, num) {
        var d = Math.round(W * 0.085 * SC3), x2 = m + d + Math.round(W * 0.03), cw = iw - d - Math.round(W * 0.03), y0 = y;
        out.push({ t: 'ellipse', x: m, y: y0, w: d, h: d, fill: s.acc, sw: 0 });
        out.push({ t: 'text', tx: num === false ? '?' : String(n), x: m, y: y0 + Math.round(d * 0.2), w: d, h: d, fs: Math.round(d * 0.5), col: s.acc === '#12305e' ? '#ffffff' : '#12305e', b: true, al: 'center', ff: 0, lh: 1.1 });
        api.t(ti, 24, s.ink, { x: x2, w: cw, b: true, gap: 0.004 }); if (de) api.t(de, 30, s.mut, { x: x2, w: cw, gap: 0.0 });
        y = Math.max(y, y0 + d) + Math.round(W * 0.03 * SC3); return api;
      },
      tiles: function (items, cols, th, bigdv) {
        th = Math.round(th * SC3); var g = Math.round(W * 0.03), tw = Math.round((iw - g * (cols - 1)) / cols), y0 = y, rows = Math.ceil(items.length / cols), fs = Math.round(W / (bigdv || (cols > 2 ? 11 : 9)) * SC3);
        items.forEach(function (it, i) { var cx = m + (i % cols) * (tw + g), cy = y0 + Math.floor(i / cols) * (th + g);
          out.push({ t: 'rect', x: cx, y: cy, w: tw, h: th, fill: s.tile, stroke: s.edge, sw: 2, rad: 18 });
          out.push({ t: 'text', tx: it[0], x: cx, y: cy + Math.round(th * 0.16), w: tw, h: fs * 1.2, fs: fs, col: s.acc, b: true, al: 'center', ff: 1, lh: 1.1 });
          out.push({ t: 'text', tx: it[1], x: cx + 10, y: cy + Math.round(th * 0.16 + fs * 1.35), w: tw - 20, h: 40, fs: Math.round(W / (cols > 2 ? 34 : 28) * SC3), col: s.ink, b: true, al: 'center', ff: 0, lh: 1.2 }); });
        y = y0 + rows * (th + g) + Math.round(W * 0.01); return api;
      },
      cards: function (items, th) {
        var n = items.length, land = W > H, g = Math.round(W * 0.025), y0 = y, tw = land ? Math.round((iw - g * (n - 1)) / n) : iw, hh = Math.round((th || (land ? H * 0.5 : H * 0.17)) * SC3), f1 = W / (land ? 36 : 24) * SC3, f2 = W / (land ? 24 : 18) * SC3, f3 = W / (land ? 38 : 30) * SC3;
        items.forEach(function (it, i) { var cx = land ? m + i * (tw + g) : m, cy = land ? y0 : y0 + i * (hh + g), px = cx + 18, pw = tw - 36;
          out.push({ t: 'rect', x: cx, y: cy, w: tw, h: hh, fill: s.tile, stroke: s.edge, sw: 2, rad: 18 });
          out.push({ t: 'text', tx: it[0], x: px, y: cy + 16, w: pw, h: 40, fs: Math.round(f1), col: s.ink, b: true, al: 'left', ff: 0, lh: 1.2 });
          if (it[1]) out.push({ t: 'text', tx: it[1], x: px, y: cy + 16 + Math.round(f1 * 1.5), w: pw, h: 40, fs: Math.round(f2), col: s.acc, b: true, al: 'left', ff: 1, lh: 1.15 });
          if (it[2]) out.push({ t: 'text', tx: it[2], x: px, y: cy + 16 + Math.round(f1 * 1.5) + Math.round(f2 * 1.5), w: pw, h: 40, fs: Math.round(f3), col: s.mut, b: false, al: 'left', ff: 0, lh: 1.4 }); });
        y = land ? y0 + hh + Math.round(W * 0.03) : y0 + n * (hh + g); return api;
      },
      list: function (items, dv, mk) { items.forEach(function (it) { api.t((mk == null ? '✔ ' : mk) + it, dv || 24, s.ink, { gap: 0.014 }); }); return api; },
      table: function (items, dv) { var k = K(F), fs = Math.round(W / (dv || 28)); k.rows(items, y / H, dv || 28, s.ink, s.acc).forEach(function (e) { e.col = e.col; out.push(e); }); y += items.length * Math.round(fs * 2.15) + Math.round(W * 0.02); return api; },
      grid: function (cols, widths, n, rh) {
        rh = Math.round(rh * SC3); if (SC3 === 1 && H > W) { var avail = H - Math.round(W * 0.16) - Math.round(W * 0.015) - y - Math.round(W * 0.15); rh = Math.max(rh, Math.min(Math.round(avail / (n + 0.95)), Math.round(rh * 1.9))); } var tot = widths.reduce(function (p, c) { return p + c; }, 0), y0 = y, fs = Math.round(W / 40 * SC3), hh = Math.round(rh * 0.95), xs = [m];
        widths.forEach(function (wd) { xs.push(xs[xs.length - 1] + Math.round(iw * wd / tot)); });
        out.push({ t: 'rect', x: m, y: y0, w: iw, h: hh, fill: '#12305e', sw: 0, rad: 8 });
        cols.forEach(function (c, i) { out.push({ t: 'text', tx: c, x: xs[i] + 8, y: y0 + Math.round((hh - fs * 1.2) / 2), w: xs[i + 1] - xs[i] - 12, h: fs * 1.3, fs: fs, col: '#ffffff', b: true, al: 'left', ff: 0, lh: 1.1 }); });
        for (var r = 0; r < n; r++) { var ry = y0 + hh + r * rh; if (r % 2 === 0) out.push({ t: 'rect', x: m, y: ry, w: iw, h: rh, fill: 'rgba(18,48,94,.05)', sw: 0, rad: 0 }); out.push({ t: 'rect', x: m, y: ry + rh - 2, w: iw, h: 2, fill: '#cfd9e8', sw: 0, rad: 0 }); }
        for (var c2 = 1; c2 < cols.length; c2++) out.push({ t: 'rect', x: xs[c2] - 1, y: y0 + hh, w: 2, h: n * rh, fill: '#cfd9e8', sw: 0, rad: 0 });
        y = y0 + hh + n * rh + Math.round(W * 0.02 * SC3); return api;
      },
      done: function (noFoot) { var sh = short, cf = short || W > H * 1.3; LAST3.ok = y <= (cf ? H * 0.9 : H - Math.round(W * 0.16) - Math.round(W * 0.015));
        if (LAST3.ok && !sh && H > W * 1.6) { var dy = Math.round((H - Math.round(W * 0.16) - y) * 0.4); if (dy > 0) out.forEach(function (e) { e.y += dy; }); } var hd = sh ? [{ t: 'img', src: logoSrcForStudio(), x: m, y: Math.round(H * 0.05), w: hs3, h: hs3, fit: 'contain', op: 1, rad: 0 }, { t: 'text', tx: B.name.toUpperCase(), x: m + Math.round(hs3 * 1.25), y: Math.round(H * 0.05 + hs3 * 0.3), w: Math.round(W * 0.6), h: 30, fs: Math.round(hs3 * 0.34), col: s.ink, b: true, al: 'left', ff: 0, lh: 1.1, ls: 1 }] : head(F, s.dk);
        var ft = noFoot ? [] : cf ? [{ t: 'text', tx: '📞 ' + B.phone + '   ✉ ' + B.email + '   📍 ' + B.address, x: m, y: H - Math.round(H * 0.09), w: iw, h: 26, fs: Math.round(W / 56), col: s.mut, b: true, al: 'left', ff: 0, lh: 1.2, fx: 1 }] : foot(F, s.dk); return hd.concat(out, ft); }
    };
    return api;
  }
  /* mises en page types */
  var L3 = {
    hero: function (F, pal, o) { var a = B3(F, pal, o.short), al = o.al || 'left';
      if (o.kicker) a.t(o.kicker, 30, a.s.acc, { b: true, ls: 4, al: al, gap: 0.015 });
      a.t(o.title, o.td || 9, a.s.ink, { b: true, ff: 1, lh: 1.05, al: al, sh: a.s.dk, gap: 0.02 }); a.bar(al);
      if (o.sub) a.t(o.sub, o.sd || 22, a.s.mut, { ff: 3, i: true, al: al, gap: 0.03 });
      (o.lines || []).forEach(function (l) { a.t(l, o.ld || 24, a.s.ink, { al: al, gap: 0.014 }); });
      if (o.cta) a.cta(o.cta); return a.done(o.noFoot); },
    ann: function (F, pal, o) { var a = B3(F, pal, o.short), al = o.al || 'left';
      a.t(o.kicker || 'INVITATION', 28, a.s.acc, { b: true, ls: 5, al: al, gap: 0.015 }); a.t(o.title, o.td || 10, a.s.ink, { b: true, ff: 1, lh: 1.05, al: al, sh: a.s.dk, gap: 0.02 }); a.bar(al);
      if (o.sub) a.t(o.sub, 24, a.s.mut, { ff: 3, i: true, al: al, gap: 0.03 });
      a.t(o.info || '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', o.id || 22, a.s.ink, { b: true, lh: 1.6, al: al, gap: 0.025 }); if (o.cta) a.cta(o.cta); return a.done(o.noFoot); },
    quote: function (F, pal, o) { var a = B3(F, pal, false), al = o.al || 'center';
      a.t(o.kicker || '', 30, a.s.acc, { b: true, ls: 4, al: al, gap: 0.02 }); a.t('“', 5, a.s.acc, { b: true, ff: 3, lh: 0.7, al: al, gap: 0.0 });
      a.t(o.quote, o.qd || 16, a.s.ink, { ff: 3, i: true, lh: 1.3, al: al, gap: 0.04 }); a.bar(al); a.t(o.author || '— Auteur', 26, a.s.acc, { b: true, al: al }); return a.done(); },
    stats: function (F, pal, o) { var a = B3(F, pal, false), al = o.al || 'left';
      if (o.kicker) a.t(o.kicker, 30, a.s.acc, { b: true, ls: 4, al: al, gap: 0.01 }); a.t(o.title, o.td || 12, a.s.ink, { b: true, ff: 1, lh: 1.1, al: al, gap: 0.015 }); a.bar(al);
      a.tiles(o.items, o.cols || 2, o.th || Math.round(F.h * (o.cols > 2 ? 0.17 : 0.2)), o.bd); if (o.cta) a.cta(o.cta); return a.done(); },
    steps: function (F, pal, o) { var a = B3(F, pal, false);
      a.t(o.title, o.td || 12, a.s.ink, { b: true, ff: 1, lh: 1.1, gap: 0.015 }); a.bar(); if (o.sub) a.t(o.sub, 26, a.s.mut, { ff: 3, i: true, gap: 0.03 });
      o.items.forEach(function (it, i) { a.step(i + 1, it[0], it[1], o.num); }); if (o.cta) a.cta(o.cta); return a.done(); },
    check: function (F, pal, o) { var a = B3(F, pal, false);
      a.t(o.title, o.td || 12, a.s.ink, { b: true, ff: 1, lh: 1.1, gap: 0.015 }); a.bar(); if (o.sub) a.t(o.sub, 26, a.s.mut, { ff: 3, i: true, gap: 0.03 });
      if (o.sections) o.sections.forEach(function (sc) { a.t(sc[0], 26, a.s.acc, { b: true, ls: 2, gap: 0.01 }); a.list(sc[1], o.ld || 28); a.gap(0.01); }); else a.list(o.items, o.ld || 22, o.mk);
      if (o.cta) a.cta(o.cta); return a.done(); },
    table: function (F, pal, o) { var a = B3(F, pal, false);
      a.t(o.title, o.td || 12, a.s.ink, { b: true, ff: 1, lh: 1.1, gap: 0.015 }); a.bar(); if (o.sub) a.t(o.sub, 26, a.s.mut, { ff: 3, i: true, gap: 0.03 });
      a.table(o.items, o.dv); if (o.note) a.t(o.note, 34, a.s.mut, { i: true }); if (o.cta) a.cta(o.cta); return a.done(); },
    cards: function (F, pal, o) { var a = B3(F, pal, false);
      a.t(o.title, o.td || 16, a.s.ink, { b: true, ff: 1, lh: 1.1, gap: 0.012 }); a.bar(); if (o.sub) a.t(o.sub, 34, a.s.mut, { ff: 3, i: true, gap: 0.025 });
      a.cards(o.items, o.th); if (o.cta) a.cta(o.cta); return a.done(); },
    promo: function (F, pal, o) { var a = B3(F, pal, o.short), W = F.w, d = Math.round(W * (o.short ? 0.3 : 0.42) * (o.short ? 1 : SC3)), s = a.s;
      if (o.short) { a.out.push({ t: 'ellipse', x: a.m, y: a.y(), w: d, h: d, fill: s.acc, sw: 0 }); a.out.push({ t: 'text', tx: o.big || '-30%', x: a.m, y: a.y() + Math.round(d * 0.3), w: d, h: d, fs: Math.round(d * 0.36), col: s.acc === '#12305e' ? '#ffffff' : '#12305e', b: true, al: 'center', ff: 1, lh: 1 });
        var x2 = a.m + d + Math.round(W * 0.04), cw = a.iw - d - Math.round(W * 0.04), y0 = a.y(); a.out.push({ t: 'text', tx: o.title, x: x2, y: y0, w: cw, h: 120, fs: Math.round(W / 16), col: s.ink, b: true, al: 'left', ff: 1, lh: 1.05, sh: s.dk }); a.out.push({ t: 'text', tx: o.sub || '', x: x2, y: y0 + Math.round(W / 16 * 2.3), w: cw, h: 60, fs: Math.round(W / 34), col: s.mut, b: false, al: 'left', ff: 0, lh: 1.3 }); return a.done(); }
      a.t(o.kicker || 'OFFRE SPÉCIALE', 28, s.acc, { b: true, ls: 5, al: 'center', gap: 0.015 });
      a.out.push({ t: 'ellipse', x: Math.round((W - d) / 2), y: a.y(), w: d, h: d, fill: s.acc, sw: 0 }); a.out.push({ t: 'text', tx: o.big || '-30%', x: Math.round((W - d) / 2), y: a.y() + Math.round(d * 0.3), w: d, h: d, fs: Math.round(d * 0.34), col: s.acc === '#12305e' ? '#ffffff' : '#12305e', b: true, al: 'center', ff: 1, lh: 1 }); a.adv(d + Math.round(W * 0.03 * SC3));
      a.t(o.title, 12, s.ink, { b: true, ff: 1, al: 'center', lh: 1.1, sh: s.dk, gap: 0.015 }); a.t(o.sub || 'Conditions : …', 26, s.mut, { al: 'center', gap: 0.015 }); a.t(o.valid || '📅 Valable jusqu’au … · Offre limitée', 28, s.ink, { b: true, al: 'center' }); if (o.cta) a.cta(o.cta); return a.done(); },
    profile: function (F, pal, o) { var a = B3(F, pal, false), W = F.w, s = a.s, ph = Math.round(F.h * 0.34), pw = Math.round(W * 0.5);
      a.t(o.kicker, 28, s.acc, { b: true, ls: 5, al: 'center', gap: 0.015 }); a.photo(ph, 'Photo du collaborateur', Math.round((W - pw) / 2), pw);
      a.t(o.name || 'Prénom NOM', 12, s.ink, { b: true, ff: 1, al: 'center', gap: 0.005 }); a.t(o.role || 'Fonction dans l’entreprise', 26, s.acc, { b: true, al: 'center', gap: 0.02 }); a.t(o.msg || 'Un message de bienvenue ou de félicitations…', 28, s.mut, { ff: 3, i: true, al: 'center' }); return a.done(); },
    property: function (F, pal, o) { var a = B3(F, pal, false), s = a.s, W = F.w;
      a.t(o.kicker || 'À VENDRE', 28, s.acc, { b: true, ls: 5, gap: 0.01 }); a.t(o.title, o.td || 13, s.ink, { b: true, ff: 1, lh: 1.1, gap: 0.015 });
      a.photo(Math.round(F.h * (o.ph || 0.3)), 'Photo du bien'); a.t(o.price || 'Prix : … USD', 14, s.acc === '#12305e' ? '#ffffff' : '#12305e', { b: true, al: 'center', bg: s.acc, pad: 14, rad: 40, gap: 0.02 });
      a.list(o.items, o.ld || 26, ''); if (o.cta) a.cta(o.cta); return a.done(); },
    card: function (F, pal, o) { var B = brand(), W = F.w, H = F.h, s = sty3(pal), m = Math.round(W * 0.07);
      if (o.verso) return [{ t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.37), y: Math.round(H * 0.1), w: Math.round(W * 0.26), h: Math.round(W * 0.26), fit: 'contain', op: 1, rad: 0 }, { t: 'text', tx: B.name.toUpperCase(), x: m, y: Math.round(H * 0.58), w: W - 2 * m, h: 60, fs: Math.round(W / 18), col: s.ink, b: true, al: 'center', ff: 0, lh: 1.1, ls: 2 }, { t: 'text', tx: B.tagline || 'L’excellence au cœur de vos projets', x: m, y: Math.round(H * 0.74), w: W - 2 * m, h: 40, fs: Math.round(W / 36), col: s.acc, b: false, i: true, al: 'center', ff: 3, lh: 1.2 }];
      return [{ t: 'rect', x: 0, y: 0, w: Math.round(W * 0.025), h: H, fill: '#c9a227', sw: 0, rad: 0 }, { t: 'img', src: logoSrcForStudio(), x: W - m - Math.round(W * 0.14), y: Math.round(H * 0.1), w: Math.round(W * 0.14), h: Math.round(W * 0.14), fit: 'contain', op: 1, rad: 0 },
        { t: 'text', tx: 'Prénom NOM', x: m, y: Math.round(H * 0.12), w: Math.round(W * 0.6), h: 60, fs: Math.round(W / 15), col: s.ink, b: true, al: 'left', ff: 0, lh: 1.1 }, { t: 'text', tx: 'Fonction / Titre', x: m, y: Math.round(H * 0.31), w: Math.round(W * 0.6), h: 40, fs: Math.round(W / 30), col: '#c9a227', b: true, al: 'left', ff: 0, lh: 1.2 },
        { t: 'rect', x: m, y: Math.round(H * 0.45), w: Math.round(W * 0.16), h: 5, fill: '#c9a227', sw: 0, rad: 3 },
        { t: 'text', tx: '📞 ' + B.phone + '\n✉ ' + B.email + '\n📍 ' + B.address, x: m, y: Math.round(H * 0.52), w: W - 2 * m, h: 150, fs: Math.round(W / 34), col: s.ink, b: false, al: 'left', ff: 0, lh: 1.6 }]; }
  };
  function fit3(f) { return function (F) { var out; for (SC3 = 1; SC3 > 0.49; SC3 -= 0.05) { LAST3.ok = true; out = f(F); if (LAST3.ok) break; } SC3 = 1; return out; }; }
  function M3(k, g, l, pal, fmt, f) { TPL3[k] = { g: g, l: l, pal: pal, fmt: fmt, f: fit3(f) }; }
  function H3(g, l, k, pal, fmt, kind, o) { M3(k, g, l, pal, fmt, function (F) { var oo = typeof o === 'function' ? o(brand()) : o; return L3[kind](F, pal, oo); }); }
  var RH = 'Recrutement & RH', RS = 'Réseaux sociaux', PR = 'Promotions & ventes', IM = 'Immobilier & terrains', EV = 'Événements & célébrations', SQ = 'Sécurité & qualité', SV = 'Services & vitrine', IN = 'Informations clients', ID = 'Supports & identité', FO = 'Formations & écoles';

  /* Recrutement & RH */
  H3(RH, 'Nous recrutons (carré)', 'rh_recrute', 'marine', 'sq', 'hero', function (B) { return { kicker: 'REJOIGNEZ NOTRE ÉQUIPE', title: 'NOUS\nRECRUTONS', sub: 'Poste : Ingénieur / Chef de chantier / …', lines: ['✔ Expérience : … ans minimum', '✔ Lieu : …', '✔ Date limite : …'], cta: 'CV à : ' + B.email, td: 8 }; });
  H3(RH, 'Offre d’emploi détaillée (A4)', 'rh_offre', 'blanc', 'a4p', 'check', { title: 'OFFRE D’EMPLOI', sub: 'Intitulé du poste : …', td: 11, sections: [['MISSIONS', ['Mission principale …', 'Suivi et coordination …', 'Reporting …']], ['PROFIL RECHERCHÉ', ['Diplôme : …', 'Expérience : … ans', 'Compétences : …']], ['COMMENT POSTULER', ['Envoyez CV + lettre de motivation', 'Avant le : …']]] });
  H3(RH, 'Stages & emplois (story)', 'rh_stage', 'vert', 'story', 'hero', { kicker: 'STAGES & EMPLOIS', title: 'STAGIAIRES\nRECHERCHÉS', sub: 'Étudiants et jeunes diplômés', lines: ['🎓 Génie civil · Architecture', '🎓 Topographie · Électricité', '🎓 Gestion · Comptabilité'], cta: 'Postulez dès maintenant', td: 9, ld: 20 });
  H3(RH, 'Bienvenue au nouveau collaborateur', 'rh_bienvenue', 'ciel', 'sq', 'profile', { kicker: 'BIENVENUE À BORD', name: 'Prénom NOM', role: 'Poste dans l’entreprise', msg: 'Toute l’équipe est heureuse de t’accueillir.' });
  H3(RH, 'Employé du mois', 'rh_mois', 'noir', 'sq', 'profile', { kicker: '★ EMPLOYÉ DU MOIS ★', name: 'Prénom NOM', role: 'Service / Chantier', msg: 'Bravo pour votre engagement et votre excellent travail !' });
  H3(RH, 'Bannière recrutement (LinkedIn)', 'rh_linkedin', 'marine', 'ban', 'hero', function (B) { return { short: true, title: 'ON RECRUTE !', td: 11, sub: 'Rejoignez une équipe passionnée · ' + B.email, sd: 28, noFoot: false }; });
  H3(RH, 'Forum emploi / journée recrutement', 'rh_forum', 'orange', 'a4p', 'ann', { kicker: 'RECRUTEMENT', title: 'JOURNÉE\nRECRUTEMENT', sub: 'Venez rencontrer notre équipe', info: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …\n📄 Apportez votre CV', cta: 'Entrée libre', td: 9 });
  H3(RH, 'Nos valeurs (4 piliers)', 'rh_valeurs', 'blanc', 'sq', 'stats', { kicker: 'CE QUI NOUS GUIDE', title: 'NOS VALEURS', items: [['01', 'Qualité'], ['02', 'Intégrité'], ['03', 'Innovation'], ['04', 'Sécurité']], td: 11 });

  /* Réseaux sociaux */
  H3(RS, 'Citation motivante', 'rs_citation', 'noir', 'sq', 'quote', { kicker: 'CITATION DU JOUR', quote: 'Bâtir, c’est donner forme à l’avenir.', author: '— Auteur' });
  H3(RS, 'Lundi motivation (story)', 'rs_lundi', 'orange', 'story', 'quote', { kicker: 'LUNDI MOTIVATION', quote: 'Une grande semaine commence par un premier pas.', author: '#LundiMotivation', qd: 12 });
  H3(RS, 'Astuce / conseil du jour', 'rs_astuce', 'ciel', 'sq', 'hero', { kicker: '💡 ASTUCE DU JOUR', title: 'Titre de\nl’astuce', td: 10, sub: 'Expliquez le conseil en une ou deux phrases claires.', lines: ['👉 Étape 1 : …', '👉 Étape 2 : …'] });
  H3(RS, 'Le saviez-vous ?', 'rs_saviez', 'marine', 'sq', 'hero', { kicker: '🤔 LE SAVIEZ-VOUS ?', title: 'Un fait\nsurprenant…', td: 10, sub: 'Développez l’information intéressante pour vos abonnés.' });
  H3(RS, 'Chiffres clés (4 indicateurs)', 'rs_chiffres', 'marine', 'sq', 'stats', { kicker: 'EN CHIFFRES', title: 'NOTRE ENTREPRISE', items: [['+50', 'Projets réalisés'], ['10 ans', 'd’expérience'], ['+30', 'Collaborateurs'], ['100 %', 'Clients satisfaits']], td: 11 });
  H3(RS, 'Sondage / question (story)', 'rs_sondage', 'vert', 'story', 'hero', { kicker: '📊 SONDAGE', title: 'Votre avis\ncompte !', td: 9, sub: 'Quelle est votre préférence ?', lines: ['A.  …', 'B.  …'], cta: 'Répondez en commentaire', ld: 14 });
  H3(RS, '5 conseils / erreurs à éviter', 'rs_checklist', 'blanc', 'sq', 'check', { title: '5 ERREURS\nÀ ÉVITER', items: ['Erreur n° 1 : …', 'Erreur n° 2 : …', 'Erreur n° 3 : …', 'Erreur n° 4 : …', 'Erreur n° 5 : …'], mk: '✖ ', ld: 24, td: 11 });
  M3('rs_mythe', RS, 'Mythe ou réalité', 'ciel', 'sq', function (F) { return L3.cards(F, 'ciel', { title: 'MYTHE OU RÉALITÉ ?', td: 12, items: [['✖ MYTHE', '« … »', 'Ce que l’on entend souvent.'], ['✔ RÉALITÉ', '… ', 'Ce qu’il faut savoir vraiment.']], th: Math.round(F.h * 0.26) }); });
  H3(RS, 'Teaser « Bientôt » (story)', 'rs_bientot', 'noir', 'story', 'hero', { kicker: 'BIENTÔT', title: 'ÇA ARRIVE…', td: 8, al: 'center', sub: 'Restez connectés, une grande annonce arrive !', cta: 'Date : …' });
  H3(RS, 'Merci (abonnés / clients)', 'rs_merci', 'marine', 'sq', 'hero', { kicker: 'MERCI', title: 'MERCI\nPOUR VOTRE\nCONFIANCE', td: 9, al: 'center', sub: 'Grâce à vous, nous grandissons chaque jour.' });
  H3(RS, 'Bon week-end', 'rs_weekend', 'ciel', 'sq', 'hero', { kicker: 'À TOUTE L’ÉQUIPE ET À NOS CLIENTS', title: 'BON\nWEEK-END !', td: 8, al: 'center', sub: 'Rendez-vous lundi pour de nouveaux projets.' });
  H3(RS, 'Couverture de carrousel', 'rs_carrousel', 'blanc', 'sq', 'hero', { kicker: 'GUIDE EN IMAGES', title: 'TITRE DU\nCARROUSEL', td: 9, sub: 'Faites glisser pour découvrir →', lines: ['👉 Slide 1 : …', '👉 Slide 2 : …'] });
  H3(RS, 'Couverture Facebook / LinkedIn', 'rs_cover', 'marine', 'ban', 'hero', function (B) { return { short: true, title: B.tagline || 'Votre partenaire de confiance', td: 15, sub: 'Architecture · Ingénierie · Construction', sd: 28 }; });

  /* Promotions & ventes */
  H3(PR, 'Promotion en % (carré)', 'pr_pct', 'rouge', 'sq', 'promo', { kicker: 'OFFRE SPÉCIALE', big: '-30%', title: 'SUR NOS SERVICES', sub: 'Conditions : …', cta: 'Appelez-nous' });
  H3(PR, 'Promotion éclair (story)', 'pr_story', 'orange', 'story', 'promo', { kicker: 'VENTE FLASH', big: '-20%', title: 'AUJOURD’HUI\nSEULEMENT', sub: 'Profitez-en vite !', cta: 'Contactez-nous maintenant' });
  H3(PR, 'Offre de lancement', 'pr_lancement', 'vert', 'sq', 'hero', { kicker: '🚀 NOUVEAU', title: 'OFFRE DE\nLANCEMENT', td: 9, sub: 'Découvrez notre nouveau service à prix réduit.', lines: ['✔ Avantage 1', '✔ Avantage 2'], cta: 'Valable jusqu’au …' });
  H3(PR, 'Promotion de fin d’année', 'pr_finannee', 'noir', 'sq', 'promo', { kicker: 'FIN D’ANNÉE', big: '-25%', title: 'FÊTES DE FIN\nD’ANNÉE', sub: 'Sur tous nos packs', cta: 'Offre jusqu’au 31 décembre' });
  H3(PR, 'Trois formules / forfaits (A4 paysage)', 'pr_pack', 'blanc', 'a4l', 'cards', { title: 'NOS FORMULES', td: 18, sub: 'Choisissez l’offre adaptée à votre projet', items: [['BASIQUE', '… USD', '✔ Prestation 1\n✔ Prestation 2'], ['STANDARD', '… USD', '✔ Tout le Basique\n✔ Prestation 3\n✔ Prestation 4'], ['PREMIUM', '… USD', '✔ Tout le Standard\n✔ Prestation 5\n✔ Suivi dédié']] });
  H3(PR, 'Grille tarifaire (A4)', 'pr_tarifs', 'blanc', 'a4p', 'table', { title: 'NOS TARIFS', sub: 'Prix indicatifs · hors taxes', items: [['Étude de plans', '… USD'], ['Permis de construire', '… USD'], ['Suivi de chantier', '… USD / mois'], ['Devis détaillé', 'Gratuit'], ['Visite sur site', '… USD']], note: 'Tarifs valables jusqu’au … · Devis gratuit sur demande.' });
  H3(PR, 'Bon de réduction (bannière)', 'pr_coupon', 'orange', 'ban', 'promo', { short: true, big: '-15%', title: 'BON DE RÉDUCTION', sub: 'Présentez ce bon avant le … · Code : …' });
  H3(PR, 'Parrainage : recommandez-nous', 'pr_parrain', 'ciel', 'sq', 'hero', { kicker: '🤝 PARRAINAGE', title: 'RECOMMANDEZ-\nNOUS', td: 10, sub: 'Parrainez un ami et gagnez une remise sur votre prochain projet.', cta: 'Demandez les détails' });
  H3(PR, 'Vente flash 48 h (story)', 'pr_flash', 'rouge', 'story', 'promo', { kicker: '⚡ 48 H SEULEMENT', big: '-40%', title: 'VENTE FLASH', sub: 'Du … au …', cta: 'Réservez maintenant' });

  /* Immobilier & terrains */
  H3(IM, 'Villa / maison à vendre (A4)', 'im_vente', 'blanc', 'a4p', 'property', { title: 'VILLA R+1\nÀ VENDRE', items: ['🛏 … chambres   🛁 … douches', '📐 Superficie : … m²', '📍 Quartier : …', '✔ Titre de propriété · Eau · Électricité'], cta: 'Visite sur rendez-vous' });
  H3(IM, 'Terrain à vendre', 'im_terrain', 'vert', 'sq', 'property', { title: 'TERRAIN À VENDRE', td: 14, ph: 0.28, items: ['📐 Superficie : … m²', '📍 Localisation : …', '📄 Documents : …'], cta: 'Contactez-nous' });
  H3(IM, 'Appartement à louer', 'im_location', 'ciel', 'sq', 'property', { kicker: 'À LOUER', title: 'APPARTEMENT\nMEUBLÉ', td: 14, ph: 0.27, price: 'Loyer : … USD / mois', items: ['🛏 … chambres · 🚿 … douches', '📍 Quartier : …'], cta: 'Réservez une visite' });
  H3(IM, 'Nouveau programme immobilier (A4)', 'im_programme', 'marine', 'a4p', 'hero', { kicker: 'NOUVEAU PROGRAMME', title: 'RÉSIDENCE\n« NOM »', td: 8, sub: 'Appartements et villas clés en main', lines: ['✔ Plusieurs types de logements', '✔ Paiement échelonné', '✔ Livraison prévue : …', '✔ Sécurité 24 h/24'], cta: 'Réservez dès aujourd’hui' });
  H3(IM, 'Portes ouvertes / visite', 'im_portes', 'orange', 'sq', 'ann', { kicker: 'PORTES OUVERTES', title: 'VENEZ\nVISITER !', td: 9, sub: 'Découvrez nos réalisations', cta: 'Entrée libre' });
  H3(IM, 'VENDU / Livré', 'im_vendu', 'noir', 'sq', 'hero', { kicker: '🎉 FÉLICITATIONS', title: 'VENDU !', td: 6, al: 'center', sub: 'Un nouveau propriétaire heureux.', lines: ['Projet : …', 'Livré le : …'] });
  H3(IM, 'Visite du chantier (story)', 'im_visite', 'marine', 'story', 'ann', { kicker: 'VISITE DE CHANTIER', title: 'VENEZ\nVOIR AVANT\nLES AUTRES', td: 10, sub: 'Constatez l’avancement des travaux.', cta: 'Sur rendez-vous' });

  /* Événements & célébrations */
  H3(EV, 'Invitation — inauguration', 'ev_inaug', 'blanc', 'a4p', 'ann', { kicker: 'INVITATION', title: 'INAUGURATION', td: 9, sub: 'Nous avons le plaisir de vous inviter', info: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …\n👔 Tenue : …', cta: 'Confirmez votre présence', al: 'center' });
  H3(EV, 'Anniversaire de l’entreprise', 'ev_anniv', 'noir', 'sq', 'hero', { kicker: '🎂 JOYEUX ANNIVERSAIRE', title: '10 ANS\nD’EXCELLENCE', td: 9, al: 'center', sub: 'Merci à nos clients, partenaires et collaborateurs.' });
  H3(EV, 'Vœux de nouvelle année (carré)', 'ev_voeux', 'marine', 'sq', 'hero', { kicker: 'MEILLEURS VŒUX', title: 'BONNE\nANNÉE 2027', td: 8, al: 'center', sub: 'Santé, prospérité et beaux projets pour tous.' });
  H3(EV, 'Pose de la première pierre', 'ev_pierre', 'ciel', 'sq', 'ann', { kicker: 'CÉRÉMONIE', title: 'POSE DE LA\nPREMIÈRE PIERRE', td: 11, sub: 'Projet : …', cta: 'Soyez des nôtres' });
  H3(EV, 'Remise des clés', 'ev_cles', 'vert', 'sq', 'hero', { kicker: '🔑 FÉLICITATIONS', title: 'REMISE\nDES CLÉS', td: 9, al: 'center', sub: 'Projet livré dans les délais.', lines: ['Client : …', 'Date : …'] });
  H3(EV, 'Séminaire / conférence (bannière)', 'ev_semin', 'marine', 'ban', 'ann', { short: true, kicker: 'CONFÉRENCE', title: 'TITRE DE L’ÉVÉNEMENT', td: 15, sub: 'Intervenants : …', info: '📅 …   🕘 …   📍 …', id: 36 });
  H3(EV, 'Soirée de gala / cocktail', 'ev_gala', 'noir', 'a4p', 'ann', { kicker: 'SOIRÉE DE GALA', title: 'COCKTAIL\nDE FIN D’ANNÉE', td: 9, al: 'center', sub: 'En présence de nos clients et partenaires', info: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', cta: 'Sur invitation' });
  H3(EV, 'Prix / distinction reçue', 'ev_prix', 'noir', 'sq', 'hero', { kicker: '🏆 DISTINCTION', title: 'NOUS AVONS\nREÇU LE PRIX', td: 11, al: 'center', sub: 'Nom du prix · Année · Organisateur', lines: ['Merci à toute l’équipe !'] });
  H3(EV, 'Journée internationale / fête', 'ev_travail', 'rouge', 'sq', 'hero', { kicker: 'AUJOURD’HUI', title: 'BONNE FÊTE\nDU TRAVAIL', td: 9, al: 'center', sub: 'Hommage à tous les travailleurs.' });

  /* Sécurité & qualité */
  H3(SQ, 'Sécurité d’abord (A4)', 'sq_secu', 'orange', 'a4p', 'hero', { kicker: '⚠ CHANTIER', title: 'LA SÉCURITÉ\nD’ABORD', td: 8, sub: 'Chacun est responsable de sa sécurité et de celle des autres.', lines: ['⛑ Casque obligatoire', '🦺 Gilet obligatoire', '🥾 Chaussures de sécurité', '🧤 Gants et lunettes si besoin'], ld: 20 });
  H3(SQ, 'Jours sans accident', 'sq_zero', 'vert', 'sq', 'hero', { kicker: 'NOTRE OBJECTIF : ZÉRO ACCIDENT', title: '125', td: 4, al: 'center', sub: 'jours sans accident', lines: ['Merci pour votre vigilance !'] });
  H3(SQ, 'Règles du chantier (A4)', 'sq_regles', 'blanc', 'a4p', 'check', { title: 'RÈGLES DU CHANTIER', td: 11, sub: 'À respecter par toute personne présente', items: ['Port des EPI obligatoire', 'Accès réservé au personnel autorisé', 'Interdiction de fumer sur site', 'Signaler tout danger au responsable', 'Garder le chantier propre et rangé', 'Respecter les consignes du chef de chantier'], ld: 22 });
  H3(SQ, 'Numéros d’urgence', 'sq_urgence', 'rouge', 'a4p', 'table', { title: 'NUMÉROS D’URGENCE', sub: 'À afficher sur le chantier', items: [['Responsable sécurité', '+243 …'], ['Chef de chantier', '+243 …'], ['Police', '…'], ['Pompiers', '…'], ['Hôpital le plus proche', '…'], ['Ambulance', '…']] });
  H3(SQ, 'Gestes de premiers secours', 'sq_secours', 'blanc', 'a4p', 'steps', { title: 'PREMIERS SECOURS', td: 11, sub: 'En cas d’accident', items: [['Protéger', 'Sécurisez la zone et la victime.'], ['Alerter', 'Appelez les secours et le responsable.'], ['Secourir', 'Appliquez les gestes adaptés.'], ['Attendre', 'Restez avec la victime jusqu’aux secours.']] });
  H3(SQ, 'Politique qualité / HSE (A4 paysage)', 'sq_qualite', 'ciel', 'a4l', 'cards', { title: 'NOS ENGAGEMENTS', td: 16, sub: 'Qualité · Hygiène · Sécurité · Environnement', items: [['QUALITÉ', 'Travail soigné', 'Matériaux conformes aux normes et contrôle à chaque étape.'], ['SÉCURITÉ', 'Zéro accident', 'Formation, équipements de protection et suivi permanent.'], ['ENVIRONNEMENT', 'Chantier propre', 'Gestion des déchets et respect du voisinage.']] });

  /* Services & vitrine */
  H3(SV, 'Notre équipe (3 membres)', 'sv_equipe', 'blanc', 'a4l', 'cards', { title: 'NOTRE ÉQUIPE', td: 16, sub: 'Des experts à votre service', items: [['Prénom NOM', 'Directeur général', 'Présentation en une phrase.'], ['Prénom NOM', 'Ingénieur', 'Présentation en une phrase.'], ['Prénom NOM', 'Architecte', 'Présentation en une phrase.']] });
  H3(SV, 'Notre méthode en 4 étapes', 'sv_process', 'marine', 'sq', 'steps', { title: 'NOTRE MÉTHODE', td: 12, items: [['Écoute', 'Nous comprenons votre besoin.'], ['Conception', 'Plans, devis et planning.'], ['Réalisation', 'Chantier suivi de près.'], ['Livraison', 'Remise du projet et garantie.']] });
  H3(SV, 'Pourquoi nous choisir', 'sv_pourquoi', 'blanc', 'sq', 'check', { title: 'POURQUOI\nNOUS CHOISIR ?', td: 11, items: ['Expérience prouvée', 'Équipe qualifiée', 'Respect des délais', 'Devis clair et gratuit', 'Suivi transparent'], ld: 22 });
  H3(SV, 'Questions fréquentes (FAQ)', 'sv_faq', 'ciel', 'a4p', 'steps', { title: 'QUESTIONS\nFRÉQUENTES', td: 11, num: false, items: [['Question 1 ?', 'Réponse courte et claire.'], ['Question 2 ?', 'Réponse courte et claire.'], ['Question 3 ?', 'Réponse courte et claire.'], ['Question 4 ?', 'Réponse courte et claire.']] });
  M3('sv_portfolio', SV, 'Portfolio — 4 réalisations', 'blanc', 'sq', function (F) { var a = B3(F, 'blanc', false), g = Math.round(F.w * 0.025), pw = Math.round((a.iw - g) / 2), ph = Math.round(F.h * 0.27);
    a.t('NOS RÉALISATIONS', 12, a.s.ink, { b: true, ff: 1, gap: 0.01 }); a.bar(); a.photo(ph, 'Projet 1', a.m, pw); a.gap(-(ph / F.w + 0.025)); a.photo(ph, 'Projet 2', a.m + pw + g, pw); a.photo(ph, 'Projet 3', a.m, pw); a.gap(-(ph / F.w + 0.025)); a.photo(ph, 'Projet 4', a.m + pw + g, pw); return a.done(); });
  M3('sv_partenaires', SV, 'Nos partenaires / références', 'ciel', 'a4l', function (F) { var a = B3(F, 'ciel', false), g = Math.round(F.w * 0.025), pw = Math.round((a.iw - 2 * g) / 3), ph = Math.round(F.h * 0.22);
    a.t('ILS NOUS FONT CONFIANCE', 18, a.s.ink, { b: true, ff: 1, gap: 0.01 }); a.bar(); [0, 1].forEach(function (r) { [0, 1, 2].forEach(function (c) { a.photo(ph, 'Logo ' + (r * 3 + c + 1), a.m + c * (pw + g), pw); if (c < 2) a.gap(-(ph / F.w + 0.025)); }); }); return a.done(); });
  H3(SV, 'Zones d’intervention', 'sv_zones', 'marine', 'a4p', 'table', { title: 'OÙ INTERVENONS-NOUS ?', td: 12, sub: 'Zones couvertes par nos équipes', items: [['Ville 1', 'Tous services'], ['Ville 2', 'Construction'], ['Ville 3', 'Études & plans'], ['Autres', 'Sur demande']] });
  H3(SV, 'Nos services en 6 icônes', 'sv_catalogue', 'blanc', 'sq', 'stats', { title: 'NOS SERVICES', td: 12, cols: 3, items: [['🏗️', 'Construction'], ['📐', 'Plans & études'], ['🏠', 'Rénovation'], ['🧱', 'Gros œuvre'], ['🧮', 'Devis & métrés'], ['🔧', 'Maintenance']], th: 220, bd: 9 });

  /* Informations clients */
  H3(IN, 'Horaires d’ouverture (A4)', 'in_horaires', 'blanc', 'a4p', 'table', { title: 'HORAIRES D’OUVERTURE', sub: 'Nous vous accueillons', items: [['Lundi – Vendredi', '08 h – 17 h'], ['Samedi', '08 h – 13 h'], ['Dimanche', 'Fermé'], ['Jours fériés', 'Fermé']] });
  H3(IN, 'Moyens de paiement acceptés', 'in_paiement', 'marine', 'sq', 'check', { title: 'MOYENS DE\nPAIEMENT', td: 11, items: ['Mobile Money', 'Virement bancaire', 'Espèces à la caisse', 'Chèque certifié'], ld: 20 });
  H3(IN, 'Comment passer commande', 'in_commande', 'ciel', 'sq', 'steps', { title: 'COMMENT\nCOMMANDER ?', td: 11, items: [['Contactez-nous', 'Par téléphone ou WhatsApp.'], ['Recevez votre devis', 'Gratuit et sans engagement.'], ['Validez et payez', 'Acompte pour démarrer.']] });
  H3(IN, 'Suivez-nous sur les réseaux', 'in_suivez', 'noir', 'sq', 'hero', function (B) { return { kicker: 'RESTONS CONNECTÉS', title: 'SUIVEZ-NOUS', td: 9, al: 'center', lines: ['Facebook : …', 'LinkedIn : …', 'Instagram : …', 'WhatsApp : ' + B.phone], ld: 22 }; });
  M3('in_qr', IN, 'Scannez le QR code (A4)', 'blanc', 'a4p', function (F) { var a = B3(F, 'blanc', false), q = Math.round(F.w * 0.5);
    a.t('SCANNEZ-MOI', 9, a.s.ink, { b: true, ff: 1, al: 'center', gap: 0.015 }); a.bar('center'); a.t('Accédez à notre site, notre catalogue ou votre espace client.', 24, a.s.mut, { al: 'center', ff: 3, i: true, gap: 0.03 }); a.photo(q, 'QR code ici', Math.round((F.w - q) / 2), q); a.t('Ouvrez l’appareil photo de votre téléphone et visez le code.', 28, a.s.ink, { al: 'center', b: true }); return a.done(); });
  [['qr_a4', 'QR seul — A4 portrait', 'a4p'], ['qr_a3', 'QR seul — A3 portrait', 'a3p'], ['qr_a5', 'QR seul — A5 (flyer)', 'a5p'], ['qr_sq', 'QR seul — Carré réseaux', 'sq'], ['qr_story', 'QR seul — Story / Statut', 'story'], ['qr_roll', 'QR seul — Kakemono', 'roll'], ['qr_a4l', 'QR seul — A4 paysage', 'a4l']].forEach(function (q) {
    [['marine', 'Fond bleu'], ['blanc', 'Fond blanc']].forEach(function (pl) {
      M3(q[0] + '_' + pl[0], IN, q[1] + ' (' + pl[1].toLowerCase() + ')', pl[0], q[2], function (F) { var a = B3(F, pl[0], false), qs = Math.round(Math.min(F.w * 0.62, F.h * 0.46));
        a.t('SCANNEZ-MOI', 9, a.s.ink, { b: true, ff: 1, al: 'center', gap: 0.015 }); a.bar('center'); a.t('Découvrez notre site : réalisations, services et contacts.', 26, a.s.mut, { al: 'center', ff: 3, i: true, gap: 0.03 });
        a.photo(qs, 'QR code ici', Math.round((F.w - qs) / 2), qs); a.t('Ouvrez l’appareil photo de votre téléphone et visez le code.', 30, a.s.ink, { al: 'center', b: true }); return a.done(); });
    });
  });
  H3(IN, 'Documents à fournir', 'in_docs', 'ciel', 'a4p', 'check', { title: 'DOCUMENTS\nÀ FOURNIR', td: 11, sub: 'Pour démarrer votre dossier', items: ['Pièce d’identité', 'Titre de propriété / attestation', 'Plan de situation du terrain', 'Cahier des charges ou croquis', 'Budget estimatif'], ld: 22 });

  /* Supports & identité */
  M3('id_carte', ID, 'Carte de visite — recto', 'blanc', 'card', function (F) { return L3.card(F, 'blanc', {}); });
  M3('id_carte_v', ID, 'Carte de visite — verso', 'marine', 'card', function (F) { return L3.card(F, 'marine', { verso: true }); });
  H3(ID, 'Kakemono / roll-up', 'id_roll', 'marine', 'roll', 'hero', function (B) { return { kicker: B.name.toUpperCase(), title: 'NOS SERVICES', td: 7, sub: B.tagline || '', lines: ['🏗️ Construction', '📐 Plans & études', '🏠 Rénovation', '🧮 Devis & métrés', '🔧 Maintenance'], ld: 16, cta: B.phone }; });
  H3(ID, 'Flyer A5 (services)', 'id_a5', 'blanc', 'a5p', 'hero', { kicker: 'NOS SERVICES', title: 'VOTRE PROJET,\nNOTRE MÉTIER', td: 10, sub: 'Du plan à la clé en main.', lines: ['✔ Construction', '✔ Plans & permis', '✔ Rénovation'], ld: 22, cta: 'Devis gratuit' });
  H3(ID, 'Écran d’accueil / TV (16:9)', 'id_tv', 'noir', 'ytb', 'hero', function (B) { return { short: true, title: 'BIENVENUE', td: 10, sub: B.tagline || 'Votre partenaire de confiance', sd: 26 }; });

  /* Formations & écoles */
  H3(FO, 'Rentrée / ouverture des inscriptions', 'fo_rentree', 'marine', 'a4p', 'ann', { kicker: 'INSCRIPTIONS OUVERTES', title: 'RENTRÉE\n2026-2027', td: 8, sub: 'Rejoignez nos formations professionnelles', info: '📅 Début des cours : …\n💰 Frais : …\n📍 Lieu : …', cta: 'Inscrivez-vous maintenant' });
  H3(FO, 'Journée portes ouvertes (formation)', 'fo_portes', 'vert', 'sq', 'ann', { kicker: 'PORTES OUVERTES', title: 'DÉCOUVREZ\nNOS FORMATIONS', td: 11, sub: 'Rencontrez formateurs et anciens étudiants.', cta: 'Entrée libre' });
  H3(FO, 'Félicitations aux lauréats', 'fo_laureats', 'noir', 'sq', 'hero', { kicker: '🎓 PROMOTION', title: 'FÉLICITATIONS\nAUX LAURÉATS', td: 11, al: 'center', sub: 'Promotion … · Session …', lines: ['Nom 1 · Nom 2 · Nom 3'] });
  H3(FO, 'Cours du soir / week-end', 'fo_soir', 'ciel', 'sq', 'hero', { kicker: 'FORMATION', title: 'COURS DU SOIR\nET WEEK-END', td: 11, sub: 'Apprenez à votre rythme.', lines: ['🕕 Horaires : …', '📚 Matières : …', '💰 Frais : …'], cta: 'Inscription ouverte' });
  H3(FO, 'Remise de certificats (invitation)', 'fo_cert', 'blanc', 'a4l', 'ann', { kicker: 'CÉRÉMONIE', title: 'REMISE DES\nCERTIFICATS', td: 14, sub: 'Promotion … · Formation …', info: '📅 Date : …   🕘 Heure : …   📍 Lieu : …', id: 30, cta: 'Venez nombreux' });

  /* ===== V157 : documents (lettres, attestations, commerce, chantier, RH) + affiches supplémentaires ===== */
  L3.doc = function (F, pal, o) { var a = B3(F, 'blanc', false), s = a.s, dv = o.dv || 41;
    a.adv(-Math.round(F.w * 0.02));
    a.t(o.place || 'Ville, le … / … / ……', dv, s.mut, { al: 'right', gap: 0.012 });
    if (o.ref !== false) a.t('N/Réf : ………        V/Réf : ………', dv, s.mut, { gap: 0.012 });
    if (o.dest) a.t(o.dest, dv, s.ink, { b: true, gap: 0.02, lh: 1.4 });
    if (o.title) { a.t(o.title, o.td || 20, s.ink, { b: true, ff: 1, al: 'center', gap: 0.008 }); a.bar('center'); }
    if (o.obj) a.t('Objet : ' + o.obj, dv, s.ink, { b: true, gap: 0.02 });
    (o.paras || []).forEach(function (p) { a.t(p, dv, s.ink, { lh: 1.45, gap: 0.017 }); });
    if (o.items) a.list(o.items, dv, o.mk == null ? '• ' : o.mk);
    a.t(o.close || 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.', dv, s.ink, { lh: 1.45, gap: 0.03 });
    a.t(o.sign || 'Le Directeur Général', dv, s.ink, { b: true, al: 'right', gap: 0.004 }); a.t('(Nom, signature et cachet)', dv * 1.1, s.mut, { i: true, al: 'right' }); return a.done(); };
  L3.form = function (F, pal, o) { var a = B3(F, 'blanc', false), s = a.s, W = F.w, half = Math.round(a.iw / 2) - 10;
    a.adv(-Math.round(W * 0.02)); a.t(o.title, o.td || 16, s.ink, { b: true, ff: 1, al: 'center', gap: 0.006 }); a.bar('center'); if (o.sub) a.t(o.sub, 34, s.mut, { al: 'center', ff: 3, i: true, gap: 0.015 });
    (o.sections || [['', o.fields || []]]).forEach(function (sc) { if (sc[0]) a.t(sc[0], 34, s.acc, { b: true, ls: 2, gap: 0.006 }); a.table(sc[1].map(function (f) { return Array.isArray(f) ? f : [f, '……………………']; }), o.dv || 34); });
    if (o.lines) o.lines.forEach(function (l) { a.t(l, 34, s.ink, { gap: 0.012 }); });
    if (o.sign) { a.gap(0.01); var yy = a.y(); a.t(o.sign[0], 34, s.ink, { b: true, w: half, keep: true }); a.t(o.sign[1], 34, s.ink, { b: true, x: a.m + half + 20, w: half, al: 'right' }); a.t('Signature : …………………', 36, s.mut, { w: half, keep: true }); a.t('Signature : …………………', 36, s.mut, { x: a.m + half + 20, w: half, al: 'right' }); }
    return a.done(); };
  L3.grid = function (F, pal, o) { var a = B3(F, 'blanc', false), s = a.s, W = F.w;
    a.adv(-Math.round(W * 0.02)); a.t(o.title, o.td || 16, s.ink, { b: true, ff: 1, al: o.al || 'center', gap: 0.006 }); a.bar(o.al || 'center');
    if (o.info) a.t(o.info, 36, s.ink, { lh: 1.5, gap: 0.012 });
    a.grid(o.cols, o.w, o.rows || 8, o.rh || 40);
    if (o.total) a.t(o.total, 34, s.ink, { b: true, al: 'right', gap: 0.012 }); if (o.note) a.t(o.note, 38, s.mut, { i: true, gap: 0.01 });
    if (o.sign) { a.gap(0.01); a.t(o.sign[0], 34, s.ink, { b: true, w: Math.round(a.iw / 2) - 10, keep: true }); a.t(o.sign[1], 34, s.ink, { b: true, x: a.m + Math.round(a.iw / 2) + 10, w: Math.round(a.iw / 2) - 10, al: 'right' }); }
    return a.done(); };
  var DOCS = {}, CL = 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.', LC = 'Lettres & courriers', AT = 'Attestations & certificats', DC = 'Documents commerciaux', CT = 'Chantier & technique', AD = 'RH & administration', FE = 'Fêtes & occasions', AV = 'Avis & annonces', MK = 'Marketing & fidélisation';
  function DOC(g, l, k, o) { H3(g, l, k, 'blanc', 'a4p', 'doc', o); }
  function FRM(g, l, k, o) { H3(g, l, k, 'blanc', 'a4p', 'form', o); }
  function GRD(g, l, k, o, fmt) { H3(g, l, k, 'blanc', fmt || 'a4p', 'grid', o); }

  /* Lettres & courriers */
  DOC(LC, 'Demande de rendez-vous', 'lc_rdv', { dest: 'À l’attention de M./Mme …\nSociété / Organisation …', obj: 'Demande de rendez-vous', paras: ['Madame, Monsieur,', 'Nous avons l’honneur de solliciter un entretien afin de vous présenter notre société et d’échanger sur votre projet de … .', 'Nous restons disponibles aux dates et heures qui vous conviendront et vous remercions de l’attention portée à notre demande.'] });
  DOC(LC, 'Relance de paiement (courtoise)', 'lc_relance', { dest: 'À l’attention de M./Mme …', obj: 'Rappel de paiement — facture n° …', paras: ['Madame, Monsieur,', 'Sauf erreur de notre part, la facture n° … d’un montant de … , échue le … , reste impayée à ce jour.', 'Nous vous prions de bien vouloir procéder au règlement dans les meilleurs délais. Si votre paiement est déjà parti, nous vous prions de ne pas tenir compte de ce rappel.'] });
  DOC(LC, 'Mise en demeure de payer', 'lc_demeure', { dest: 'À M./Mme …\nAdresse : …', obj: 'MISE EN DEMEURE — facture n° …', paras: ['Madame, Monsieur,', 'Malgré nos précédentes relances, la somme de … demeure impayée au titre de la facture n° … du … .', 'Nous vous mettons en demeure de régler cette somme dans un délai de … jours à compter de la réception de la présente.', 'À défaut, nous nous réserverons le droit d’engager toute procédure utile pour obtenir le recouvrement de notre créance.'], close: 'Dans l’attente de votre règlement, nous vous prions d’agréer nos salutations.' });
  DOC(LC, 'Remerciements à un client', 'lc_merci', { dest: 'À M./Mme …', obj: 'Remerciements', paras: ['Madame, Monsieur,', 'Toute l’équipe vous remercie sincèrement pour la confiance que vous nous avez accordée pour la réalisation de votre projet de … .', 'Votre satisfaction est notre priorité ; n’hésitez pas à nous contacter pour tout besoin futur.'] });
  DOC(LC, 'Lettre de motivation / candidature', 'lc_candidature', { ref: false, dest: 'À l’attention du Responsable des ressources humaines\nSociété …', obj: 'Candidature au poste de …', paras: ['Madame, Monsieur,', 'Titulaire d’un diplôme de … et fort(e) de … années d’expérience en … , je vous adresse ma candidature au poste de … .', 'Rigoureux(se), motivé(e) et rapide à m’adapter, je souhaite mettre mes compétences au service de votre entreprise.', 'Je me tiens à votre disposition pour un entretien.'], sign: 'Prénom NOM' });
  DOC(LC, 'Lettre de recommandation', 'lc_recommande', { dest: 'À qui de droit', obj: 'Lettre de recommandation', paras: ['Madame, Monsieur,', 'Je soussigné(e) … , … de la société … , recommande vivement M./Mme … , que j’ai eu sous ma responsabilité du … au … en qualité de … .', 'Il/Elle s’est distingué(e) par son sérieux, son esprit d’équipe et la qualité de son travail.'] });
  DOC(LC, 'Lettre de démission', 'lc_demission', { ref: false, dest: 'À l’attention de la Direction', obj: 'Démission', paras: ['Madame, Monsieur,', 'Par la présente, je vous informe de ma décision de démissionner du poste de … que j’occupe depuis le … .', 'Conformément à mon contrat, je respecterai un préavis de … , soit jusqu’au … .', 'Je vous remercie pour la confiance accordée durant ces années.'], sign: 'Prénom NOM' });
  DOC(LC, 'Demande de congé', 'lc_conge', { ref: false, dest: 'À l’attention de la Direction', obj: 'Demande de congé', paras: ['Madame, Monsieur,', 'J’ai l’honneur de solliciter un congé de … jours, du … au … , pour le motif suivant : … .', 'Je reprendrai mon service le … . Dans l’attente d’une suite favorable, je vous prie d’agréer mes salutations respectueuses.'], close: 'Avec mes remerciements anticipés.', sign: 'Prénom NOM' });
  DOC(LC, 'Offre d’engagement (embauche)', 'lc_embauche', { dest: 'À M./Mme …', obj: 'Offre d’engagement — poste de …', paras: ['Madame, Monsieur,', 'Nous avons le plaisir de vous confirmer notre proposition d’engagement en qualité de … , à compter du … , sous la responsabilité de … .', 'Rémunération : … par mois · Lieu de travail : … · Période d’essai : … .', 'Merci de nous retourner un exemplaire signé avec la mention « Lu et approuvé ».'] });
  DOC(LC, 'Avertissement / mise en garde', 'lc_avertissement', { dest: 'À M./Mme …\nFonction : …', obj: 'Avertissement', paras: ['Madame, Monsieur,', 'Nous avons constaté, le … , les faits suivants : … , contraires au règlement intérieur de l’entreprise.', 'Nous vous demandons de veiller à ne plus renouveler ce comportement. Une récidive pourrait entraîner des sanctions plus sévères.'], close: 'Nous comptons sur votre sens des responsabilités.' });
  DOC(LC, 'Lettre de félicitations', 'lc_felicite', { dest: 'À M./Mme …', obj: 'Félicitations', paras: ['Chère / Cher …,', 'C’est avec grand plaisir que la Direction vous adresse ses plus sincères félicitations pour … .', 'Votre engagement est un exemple pour toute l’équipe. Nous vous souhaitons beaucoup de succès pour la suite.'], close: 'Avec nos meilleures salutations.' });
  DOC(LC, 'Réponse à une réclamation client', 'lc_reclamation', { dest: 'À M./Mme …', obj: 'Suite à votre réclamation du …', paras: ['Madame, Monsieur,', 'Nous avons bien reçu votre réclamation concernant … et nous vous prions de nous excuser pour la gêne occasionnée.', 'Après vérification, nous avons décidé de … dans un délai de … . Un responsable vous contactera pour confirmer la résolution.'] });
  DOC(LC, 'Proposition de partenariat', 'lc_partenariat', { dest: 'À l’attention de la Direction\nSociété …', obj: 'Proposition de partenariat', paras: ['Madame, Monsieur,', 'Forts de notre expérience en … , nous souhaitons vous proposer un partenariat dans le domaine de … .', 'Cette collaboration permettrait de … au bénéfice des deux parties. Nous serions heureux de vous rencontrer pour en discuter.'] });
  DOC(LC, 'Convocation à une réunion', 'lc_convocation', { dest: 'À : …', obj: 'Convocation à la réunion du …', paras: ['Madame, Monsieur,', 'Vous êtes prié(e) de bien vouloir assister à la réunion qui se tiendra le … à … heures, à … .', 'Ordre du jour : 1) … 2) … 3) … 4) Divers.', 'Votre présence est indispensable.'], close: 'Cordialement.' });

  /* Attestations & certificats */
  DOC(AT, 'Attestation de travail', 'at_travail', { ref: true, title: 'ATTESTATION DE TRAVAIL', paras: ['Je soussigné(e) … , Directeur Général de … , atteste par la présente que M./Mme … , né(e) le … à … , occupe le poste de … au sein de notre entreprise depuis le … .', 'La présente attestation est délivrée à l’intéressé(e) pour servir et valoir ce que de droit.'], close: 'Fait à … , le … ' });
  DOC(AT, 'Certificat de travail', 'at_certificat', { title: 'CERTIFICAT DE TRAVAIL', paras: ['Nous soussignés, certifions que M./Mme … a travaillé au sein de notre entreprise du … au … en qualité de … .', 'Il/Elle nous quitte libre de tout engagement.'], close: 'Fait à … , le … pour servir et valoir ce que de droit.' });
  DOC(AT, 'Attestation de fin de stage', 'at_stage', { title: 'ATTESTATION DE STAGE', paras: ['Nous attestons que M./Mme … , étudiant(e) en … à … , a effectué un stage au sein de notre entreprise du … au … .', 'Au cours de ce stage, il/elle a participé à … et a fait preuve de sérieux et d’assiduité.'], close: 'Délivrée à l’intéressé(e) pour servir et valoir ce que de droit.' });
  DOC(AT, 'Attestation de paiement', 'at_paiement', { title: 'ATTESTATION DE PAIEMENT', paras: ['Nous soussignés, attestons avoir reçu de M./Mme … la somme de … ( … en toutes lettres) au titre de … , selon facture n° … .', 'Cette attestation confirme uniquement l’encaissement du montant mentionné.'], close: 'Fait à … , le … ' });
  DOC(AT, 'Attestation de bonne exécution', 'at_bonne_exec', { title: 'ATTESTATION DE BONNE EXÉCUTION', paras: ['Nous attestons que la société … a réalisé pour notre compte les travaux de … sur le site de … , du … au … , pour un montant de … .', 'Les travaux ont été exécutés conformément aux règles de l’art et dans les délais convenus.'], close: 'Pour servir et valoir ce que de droit.' });
  DOC(AT, 'Procuration / mandat', 'at_mandat', { title: 'PROCURATION', paras: ['Je soussigné(e) … , demeurant à … , titulaire de la pièce d’identité n° … , donne pouvoir à M./Mme … , demeurant à … , à l’effet de me représenter pour … .', 'Cette procuration est valable du … au … .'], close: 'Fait à … , le … ', sign: 'Le mandant' });

  /* Documents commerciaux */
  GRD(DC, 'Devis (modèle détaillé)', 'dc_devis', { title: 'DEVIS N° …', info: 'Client : …………………        Date : …………\nProjet : …………………      Validité : 30 jours', cols: ['Désignation', 'Qté', 'P.U.', 'Total'], w: [5, 1.2, 1.6, 1.8], rows: 9, total: 'TOTAL HT : ………      TVA : ………      TOTAL TTC : ………', note: 'Bon pour accord : date, signature précédée de « Lu et approuvé ».' });
  GRD(DC, 'Facture proforma', 'dc_proforma', { title: 'FACTURE PROFORMA N° …', info: 'Client : …………………        Date : …………\nObjet : …………………', cols: ['Désignation', 'Qté', 'P.U.', 'Total'], w: [5, 1.2, 1.6, 1.8], rows: 8, total: 'TOTAL À PAYER : ………', note: 'Document non valable comme facture définitive.' });
  GRD(DC, 'Bon de commande', 'dc_commande', { title: 'BON DE COMMANDE N° …', info: 'Fournisseur : …………………      Date : …………\nLivraison à : …………………', cols: ['Article', 'Qté', 'P.U.', 'Total'], w: [5, 1.2, 1.6, 1.8], rows: 8, total: 'TOTAL : ………', sign: ['Le demandeur', 'Le fournisseur'] });
  GRD(DC, 'Bon de livraison', 'dc_livraison', { title: 'BON DE LIVRAISON N° …', info: 'Client : …………………        Date : …………\nChantier : …………………', cols: ['Désignation', 'Commandé', 'Livré', 'Observation'], w: [4.5, 1.6, 1.4, 2.6], rows: 8, sign: ['Livreur', 'Réceptionnaire'] });
  GRD(DC, 'Facture simple', 'dc_facture', { title: 'FACTURE N° …', info: 'Client : …………………        Date : …………\nÉchéance : …………', cols: ['Désignation', 'Qté', 'P.U.', 'Total'], w: [5, 1.2, 1.6, 1.8], rows: 8, total: 'TOTAL HT : ………   TVA : ………   TOTAL TTC : ………', note: 'Règlement par virement, Mobile Money ou espèces à la caisse.' });
  GRD(DC, 'Note d’honoraires par phase', 'dc_honoraires', { title: 'NOTE D’HONORAIRES', info: 'Projet : …………………      Client : …………………', cols: ['Phase', 'Taux', 'Montant'], w: [5.5, 1.5, 2.6], rows: 7, total: 'TOTAL : ………', note: 'Esquisse · APS · APD · Permis · DCE · Suivi · Réception' });
  GRD(DC, 'Bordereau de prix unitaires', 'dc_bpu', { title: 'BORDEREAU DES PRIX UNITAIRES', info: 'Projet : …………………', cols: ['N°', 'Désignation', 'U', 'P.U.'], w: [0.9, 5.4, 1, 1.8], rows: 10 });
  DOC(DC, 'Décharge', 'dc_decharge', { title: 'DÉCHARGE', paras: ['Je soussigné(e) … , reconnais avoir reçu de la société … : … ( … ) le … , en bon état de fonctionnement.', 'Je m’engage à en prendre soin et à le restituer au plus tard le … .'], close: 'Fait à … , le … ', sign: 'Le bénéficiaire' });
  DOC(DC, 'Contrat de prestation (simplifié)', 'dc_contrat', { title: 'CONTRAT DE PRESTATION', dv: 44, paras: ['Entre : … (le Prestataire) et … (le Client).', 'Article 1 — Objet : réalisation de … à … .', 'Article 2 — Durée : du … au … .', 'Article 3 — Prix : … payables ainsi : … % à la signature, … % à l’avancement, le solde à la livraison.', 'Article 4 — Obligations : le prestataire s’engage à exécuter les travaux dans les règles de l’art ; le client à régler aux échéances prévues.', 'Article 5 — Litiges : à défaut d’accord amiable, les tribunaux compétents seront saisis.'], close: 'Fait en deux exemplaires, à … , le … ', sign: 'Le Prestataire        Le Client' });
  DOC(DC, 'Avenant au contrat', 'dc_avenant', { title: 'AVENANT N° …', paras: ['Entre les soussignés … et … , il a été convenu ce qui suit, en complément du contrat du … :', 'Article 1 — Objet de l’avenant : … .', 'Article 2 — Incidence financière : … ; nouveau montant du contrat : … .', 'Article 3 — Délai : prolongé de … jours, soit jusqu’au … .', 'Les autres clauses du contrat demeurent inchangées.'], close: 'Fait à … , le … ', sign: 'Les parties' });
  H3(DC, 'Conditions générales de vente', 'dc_cgv', 'blanc', 'a4p', 'check', { title: 'CONDITIONS GÉNÉRALES', td: 13, sub: 'Extrait à adapter', items: ['Devis valable 30 jours à compter de sa date', 'Acompte de … % à la commande', 'Paiement par étapes selon l’avancement', 'Délais indicatifs, hors cas de force majeure', 'Travaux supplémentaires facturés après accord', 'Garantie : … mois après réception'], ld: 24 });
  FRM(DC, 'Reçu simple (espèces)', 'dc_recu', { title: 'REÇU', sub: 'À conserver', fields: ['N° du reçu', 'Date', 'Reçu de', 'La somme de', 'En toutes lettres', 'Motif', 'Mode de paiement'], sign: ['Le client', 'La caisse'] });

  /* Chantier & technique */
  FRM(CT, 'Procès-verbal de réception de travaux', 'ct_pv_reception', { title: 'PV DE RÉCEPTION DES TRAVAUX', sub: 'Réception provisoire / définitive', fields: ['Projet', 'Maître d’ouvrage', 'Entreprise', 'Lot / travaux', 'Date de réception', 'Réserves éventuelles', 'Délai de levée des réserves'], sign: ['Le Maître d’ouvrage', 'L’Entreprise'] });
  DOC(CT, 'Ordre de service', 'ct_ordre_service', { title: 'ORDRE DE SERVICE N° …', paras: ['Projet : … · Marché : … · Lot : …', 'L’entreprise … est invitée à : démarrer / suspendre / reprendre les travaux à compter du … .', 'Motif : … ', 'Le délai contractuel est / n’est pas modifié par le présent ordre de service.'], close: 'Fait à … , le … ', sign: 'Le Maître d’œuvre' });
  FRM(CT, 'Rapport journalier de chantier', 'ct_rapport_jour', { title: 'RAPPORT JOURNALIER', sections: [['GÉNÉRALITÉS', ['Chantier', 'Date', 'Météo', 'Effectif présent']], ['TRAVAUX', ['Travaux réalisés', 'Matériaux reçus', 'Matériel utilisé']], ['OBSERVATIONS', ['Incidents', 'Visites', 'Travaux du lendemain']]], sign: ['Chef de chantier', 'Visa conducteur'], dv: 36 });
  FRM(CT, 'Rapport hebdomadaire d’avancement', 'ct_rapport_hebdo', { title: 'RAPPORT HEBDOMADAIRE', fields: ['Semaine du … au …', 'Avancement physique (%)', 'Avancement financier (%)', 'Travaux terminés', 'Travaux en cours', 'Difficultés rencontrées', 'Actions correctives', 'Prévisions semaine suivante'], dv: 34 });
  GRD(CT, 'Fiche de pointage hebdomadaire', 'ct_pointage', { title: 'FICHE DE POINTAGE', info: 'Chantier : …………………       Semaine du … au …', cols: ['Nom', 'Poste', 'L', 'M', 'M', 'J', 'V', 'S', 'Total'], w: [3, 2.3, .8, .8, .8, .8, .8, .8, 1.3], rows: 12, rh: 36 });
  GRD(CT, 'Demande de matériaux', 'ct_demande_mat', { title: 'DEMANDE DE MATÉRIAUX', info: 'Chantier : …………………      Date : …………', cols: ['Matériau', 'Qté', 'Unité', 'Urgence'], w: [5, 1.3, 1.3, 1.8], rows: 9, sign: ['Demandeur', 'Approbation'] });
  H3(CT, 'Check-list de visite de chantier', 'ct_visite', 'blanc', 'a4p', 'check', { title: 'VISITE DE CHANTIER', td: 14, sub: 'Points à contrôler', items: ['Panneau de chantier en place', 'Clôture et accès sécurisés', 'EPI portés par tous', 'Qualité du béton / coffrages', 'Stockage des matériaux', 'Propreté et évacuation des déchets', 'Registre à jour'], mk: '☐ ', ld: 24 });
  GRD(CT, 'Liste des réserves', 'ct_reserves', { title: 'LISTE DES RÉSERVES', info: 'Projet : …………………      Date : …………', cols: ['N°', 'Réserve', 'Lot', 'Délai', 'Levée'], w: [.8, 5, 1.5, 1.4, 1.2], rows: 10 });
  GRD(CT, 'Planning des travaux', 'ct_planning', { title: 'PLANNING DES TRAVAUX', info: 'Projet : …………………', cols: ['Tâche', 'Début', 'Fin', 'Resp.', '%'], w: [4.2, 1.5, 1.5, 1.5, .9], rows: 10 }, 'a4p');
  GRD(CT, 'Fiche de métré', 'ct_metre', { title: 'FICHE DE MÉTRÉ', info: 'Projet : …………………      Lot : …………', cols: ['Poste', 'Désignation', 'Long.', 'Larg.', 'Haut.', 'Qté'], w: [.9, 3.6, 1.1, 1.1, 1.1, 1.2], rows: 10 });
  FRM(CT, 'Déclaration d’incident / accident', 'ct_incident', { title: 'DÉCLARATION D’INCIDENT', fields: ['Date et heure', 'Lieu précis', 'Personne(s) concernée(s)', 'Description des faits', 'Blessures / dégâts', 'Premiers secours donnés', 'Témoins', 'Mesures prises'], sign: ['Déclarant', 'Responsable sécurité'], dv: 36 });
  GRD(CT, 'Registre des visiteurs', 'ct_visiteurs', { title: 'REGISTRE DES VISITEURS', info: 'Chantier : …………………', cols: ['Date', 'Nom', 'Société', 'Motif', 'Entrée', 'Sortie'], w: [1.3, 2.5, 2.2, 2.4, 1.1, 1.1], rows: 11, rh: 38 });
  FRM(CT, 'Compte rendu de réunion de chantier', 'ct_pv_reunion', { title: 'COMPTE RENDU DE RÉUNION', fields: ['Projet', 'Date / lieu', 'Présents', 'Points abordés', 'Décisions prises', 'Actions / responsables', 'Prochaine réunion'], dv: 34 });
  GRD(CT, 'Suivi des entrées de matériaux', 'ct_stock', { title: 'SUIVI DES MATÉRIAUX', info: 'Chantier : …………………', cols: ['Date', 'Matériau', 'Entrée', 'Sortie', 'Stock'], w: [1.4, 3.6, 1.3, 1.3, 1.3], rows: 11 });

  /* RH & administration */
  FRM(AD, 'Fiche de poste', 'ad_fiche_poste', { title: 'FICHE DE POSTE', fields: ['Intitulé du poste', 'Service', 'Rattachement hiérarchique', 'Missions principales', 'Compétences requises', 'Formation / expérience', 'Conditions de travail'] });
  GRD(AD, 'Évaluation de performance', 'ad_evaluation', { title: 'ÉVALUATION DU PERSONNEL', info: 'Nom : …………………      Poste : …………      Période : …………', cols: ['Critère', '1', '2', '3', '4', '5'], w: [5, .8, .8, .8, .8, .8], rows: 9, note: 'Échelle : 1 insuffisant · 3 satisfaisant · 5 excellent.' });
  GRD(AD, 'Liste de présence', 'ad_presence', { title: 'LISTE DE PRÉSENCE', info: 'Réunion / formation : …………………      Date : …………', cols: ['N°', 'Nom et prénom', 'Fonction', 'Signature'], w: [.8, 3.6, 2.4, 2.4], rows: 13, rh: 38 });
  DOC(AD, 'Note de service interne', 'ad_note', { title: 'NOTE INTERNE', ref: true, dest: 'À : l’ensemble du personnel', obj: '…', paras: ['Il est porté à la connaissance de tout le personnel que … à compter du … .', 'Chacun est invité à s’y conformer strictement. Pour toute question, rapprochez-vous de … .'], close: 'Merci de votre compréhension.' });
  H3(AD, 'Règlement intérieur (extrait)', 'ad_reglement', 'blanc', 'a4p', 'check', { title: 'RÈGLEMENT INTÉRIEUR', td: 13, sub: 'Principales règles', items: ['Respect des horaires de travail', 'Port des EPI sur les chantiers', 'Utilisation responsable du matériel', 'Confidentialité des informations clients', 'Respect mutuel entre collègues', 'Toute absence doit être justifiée'], ld: 24, mk: '§ ' });
  FRM(AD, 'Fiche d’identification employé', 'ad_fiche_employe', { title: 'FICHE EMPLOYÉ', fields: ['Matricule', 'Nom et prénom', 'Date et lieu de naissance', 'Adresse', 'Téléphone', 'Poste', 'Date d’embauche', 'Personne à contacter en urgence'] });
  FRM(AD, 'Ordre de mission', 'ad_mission', { title: 'ORDRE DE MISSION', fields: ['Nom et fonction', 'Destination', 'Objet de la mission', 'Date de départ', 'Date de retour', 'Moyen de transport', 'Frais de mission prévus'], sign: ['Le Directeur', 'Le missionnaire'] });
  DOC(AD, 'Demande d’avance sur salaire', 'ad_avance', { ref: false, dest: 'À l’attention de la Direction', obj: 'Demande d’avance sur salaire', paras: ['Madame, Monsieur,', 'Je sollicite une avance de … sur mon salaire du mois de … , pour faire face à … .', 'Je m’engage à la rembourser en … mensualités à compter du … .'], close: 'Avec mes remerciements.', sign: 'Prénom NOM' });
  FRM(AD, 'Décharge de matériel / équipements', 'ad_decharge_mat', { title: 'FICHE DE REMISE DE MATÉRIEL', fields: ['Bénéficiaire', 'Matériel remis', 'N° de série', 'État à la remise', 'Date de remise', 'Date de retour prévue'], sign: ['Le responsable', 'Le bénéficiaire'] });

  /* Fêtes & occasions */
  H3(FE, 'Joyeux Noël', 'fe_noel', 'rouge', 'sq', 'hero', { kicker: '🎄 FÊTES DE FIN D’ANNÉE', title: 'JOYEUX\nNOËL', td: 7, al: 'center', sub: 'Que la joie et la paix remplissent vos foyers.' });
  H3(FE, 'Joyeuses Pâques', 'fe_paques', 'ciel', 'sq', 'hero', { kicker: '🐣 PÂQUES', title: 'JOYEUSES\nPÂQUES', td: 8, al: 'center', sub: 'Une très belle fête à vous et à vos proches.' });
  H3(FE, 'Aïd Moubarak', 'fe_aid', 'vert', 'sq', 'hero', { kicker: '🌙 AÏD MOUBARAK', title: 'BONNE FÊTE\nDE L’AÏD', td: 8, al: 'center', sub: 'Paix, santé et bénédictions à tous.' });
  H3(FE, 'Ramadan Karim', 'fe_ramadan', 'noir', 'sq', 'hero', { kicker: '☪ RAMADAN', title: 'RAMADAN\nKARIM', td: 8, al: 'center', sub: 'Excellent mois de partage et de spiritualité.' });
  H3(FE, 'Fête de l’indépendance (30 juin)', 'fe_independance', 'marine', 'sq', 'hero', { kicker: '🇨🇩 30 JUIN', title: 'VIVE\nL’INDÉPENDANCE', td: 9, al: 'center', sub: 'Bonne fête nationale à toute la nation.' });
  H3(FE, 'Journée de la femme (8 mars)', 'fe_femme', 'rouge', 'sq', 'hero', { kicker: '8 MARS', title: 'JOURNÉE DE\nLA FEMME', td: 9, al: 'center', sub: 'Hommage aux femmes qui bâtissent demain.' });
  H3(FE, 'Fête des mères', 'fe_meres', 'ciel', 'sq', 'hero', { kicker: '💐 FÊTE DES MÈRES', title: 'BONNE FÊTE\nMAMAN', td: 8, al: 'center', sub: 'Merci pour votre amour et votre force.' });
  H3(FE, 'Fête des pères', 'fe_peres', 'marine', 'sq', 'hero', { kicker: '👔 FÊTE DES PÈRES', title: 'BONNE FÊTE\nPAPA', td: 8, al: 'center', sub: 'Merci pour votre soutien et vos conseils.' });
  H3(FE, 'Saint-Valentin', 'fe_valentin', 'rouge', 'sq', 'hero', { kicker: '❤ 14 FÉVRIER', title: 'JOYEUSE\nSAINT-VALENTIN', td: 10, al: 'center', sub: 'Construisez ensemble la maison de vos rêves.' });
  H3(FE, 'Rentrée scolaire', 'fe_rentree', 'orange', 'sq', 'hero', { kicker: '🎒 RENTRÉE DES CLASSES', title: 'BONNE\nRENTRÉE !', td: 8, al: 'center', sub: 'Succès et réussite à tous les élèves et étudiants.' });
  H3(FE, 'Black Friday', 'fe_blackfriday', 'noir', 'sq', 'promo', { kicker: 'BLACK FRIDAY', big: '-50%', title: 'LES PLUS\nGRANDES PROMOS', sub: 'Un seul jour, des prix exceptionnels.', cta: 'Profitez-en maintenant' });
  H3(FE, 'Joyeux anniversaire (collaborateur)', 'fe_anniv', 'marine', 'sq', 'profile', { kicker: '🎂 JOYEUX ANNIVERSAIRE', name: 'Prénom NOM', role: 'Fonction', msg: 'Toute l’équipe vous souhaite une merveilleuse journée.' });
  H3(FE, 'Félicitations (mariage / naissance)', 'fe_felicite', 'ciel', 'sq', 'hero', { kicker: '💍 FÉLICITATIONS', title: 'TOUS NOS\nVŒUX DE\nBONHEUR', td: 9, al: 'center', sub: 'De la part de toute l’équipe.' });
  H3(FE, 'Message de condoléances', 'fe_condoleances', 'noir', 'sq', 'hero', { kicker: 'EN SIGNE DE COMPASSION', title: 'NOS SINCÈRES\nCONDOLÉANCES', td: 11, al: 'center', sub: 'La direction et le personnel s’associent à la douleur de la famille de … .' });

  /* Avis & annonces */
  H3(AV, 'Avis d’attribution de marché', 'av_attribution', 'blanc', 'a4p', 'ann', { kicker: 'AVIS', title: 'ATTRIBUTION\nDE MARCHÉ', td: 10, sub: 'Projet : …', info: 'Attributaire : …\nMontant : …\nDélai : …\nDate : …', al: 'center' });
  H3(AV, 'Enquête de satisfaction', 'av_satisfaction', 'ciel', 'sq', 'hero', { kicker: '⭐ VOTRE AVIS', title: 'AIDEZ-NOUS À\nMIEUX VOUS\nSERVIR', td: 11, sub: 'Répondez à notre enquête de satisfaction (2 minutes).', cta: 'Lien / QR code : …' });
  H3(AV, 'Avis de maintenance / interruption', 'av_maintenance', 'orange', 'sq', 'ann', { kicker: 'AVIS', title: 'INTERRUPTION\nDE SERVICE', td: 10, sub: 'Nous vous prions de nous excuser pour la gêne occasionnée.', info: '📅 Du … au …\n🕘 De … h à … h\n📍 Zone : …' });
  H3(AV, 'Avis de déménagement', 'av_demenagement', 'marine', 'sq', 'ann', { kicker: 'NOUVELLE ADRESSE', title: 'NOUS\nDÉMÉNAGEONS', td: 9, sub: 'À compter du … nous vous accueillons :', info: '📍 Nouvelle adresse : …\n📞 Téléphone : …' });
  H3(AV, 'Réouverture / reprise des activités', 'av_reouverture', 'vert', 'sq', 'hero', { kicker: 'BONNE NOUVELLE', title: 'NOUS\nROUVRONS !', td: 8, al: 'center', sub: 'Reprise des activités le … à … h.' });
  H3(AV, 'Avis de travaux / nuisances', 'av_travaux', 'orange', 'a4p', 'ann', { kicker: '⚠ ATTENTION', title: 'TRAVAUX\nEN COURS', td: 8, sub: 'Soyez prudents · Passage réservé aux personnes autorisées.', info: '📅 Durée : du … au …\n🕘 Horaires : …\n📍 Lieu : …' });
  H3(AV, 'Rappel d’échéance de paiement', 'av_rappel', 'blanc', 'sq', 'ann', { kicker: 'RAPPEL', title: 'ÉCHÉANCE\nDE PAIEMENT', td: 10, sub: 'Chers clients, pensez à régulariser vos versements.', info: '📅 Date limite : …\n💳 Mobile Money · Banque · Caisse\n📞 Info : …' });
  H3(AV, 'Certification / label obtenu', 'av_certification', 'noir', 'sq', 'hero', { kicker: '🏅 BONNE NOUVELLE', title: 'NOUS SOMMES\nCERTIFIÉS', td: 10, al: 'center', sub: 'Certification / label : … · Année : …' });
  H3(AV, 'Avis de recrutement interne', 'av_interne', 'ciel', 'a4p', 'ann', { kicker: 'AVIS INTERNE', title: 'POSTE À\nPOURVOIR', td: 9, sub: 'Candidatures ouvertes au personnel de l’entreprise.', info: 'Poste : …\nDate limite : …\nContact : …' });

  /* Marketing & fidélisation */
  H3(MK, 'Nouveau service (annonce)', 'mk_service', 'marine', 'sq', 'hero', { kicker: '🆕 NOUVEAUTÉ', title: 'NOUVEAU\nSERVICE', td: 9, sub: 'Nom du service : …', lines: ['✔ Pour qui ?', '✔ Ce que vous gagnez', '✔ Tarif / contact'], cta: 'En savoir plus' });
  H3(MK, 'Nouveau chantier démarré', 'mk_demarre', 'orange', 'sq', 'hero', { kicker: '🚧 C’EST PARTI', title: 'NOUVEAU\nCHANTIER', td: 9, al: 'center', sub: 'Projet : … · Lieu : …' });
  H3(MK, 'Chantier terminé / livré', 'mk_termine', 'vert', 'sq', 'hero', { kicker: '✅ LIVRÉ', title: 'PROJET\nTERMINÉ', td: 9, al: 'center', sub: 'Merci à notre client et à toutes les équipes.' });
  H3(MK, 'Étude de cas (avant / résultat)', 'mk_cas', 'blanc', 'sq', 'cards', { title: 'ÉTUDE DE CAS', td: 12, sub: 'Un projet, une solution', items: [['LE DÉFI', '', 'Le besoin du client en une phrase.'], ['NOTRE SOLUTION', '', 'Ce que nous avons mis en œuvre.'], ['LE RÉSULTAT', '', 'Délai, budget, satisfaction.']] });
  H3(MK, 'Jeu-concours', 'mk_concours', 'rouge', 'sq', 'hero', { kicker: '🎁 JEU-CONCOURS', title: 'À GAGNER :\n…', td: 9, al: 'center', sub: 'Comment participer ?', lines: ['1. Aimez notre page', '2. Partagez ce post', '3. Commentez'], cta: 'Tirage le …' });
  H3(MK, 'Planning de la semaine (story)', 'mk_planning', 'ciel', 'story', 'check', { title: 'CETTE SEMAINE', td: 10, items: ['Lundi : …', 'Mardi : …', 'Mercredi : …', 'Jeudi : …', 'Vendredi : …'], mk: '📌 ', ld: 16 });
  H3(MK, 'Tutoriel en 3 étapes', 'mk_tuto', 'blanc', 'sq', 'steps', { title: 'COMMENT FAIRE ?', td: 12, items: [['Étape 1', 'Décrivez la première action.'], ['Étape 2', 'Décrivez la deuxième action.'], ['Étape 3', 'Terminez par le résultat attendu.']] });
  H3(MK, 'Bon cadeau', 'mk_cadeau', 'noir', 'a4l', 'hero', { kicker: '🎁 BON CADEAU', title: 'OFFERT À : …', td: 12, sub: 'Valeur : … · Valable jusqu’au …', lines: ['De la part de : …'], cta: 'Code : …', noFoot: false });
  H3(MK, 'Programme de fidélité', 'mk_fidelite', 'marine', 'sq', 'hero', { kicker: '⭐ CLIENTS FIDÈLES', title: 'PROGRAMME\nDE FIDÉLITÉ', td: 10, sub: 'Cumulez des avantages à chaque projet.', lines: ['✔ -5 % dès le 2e projet', '✔ Suivi prioritaire', '✔ Cadeau de bienvenue'] });
  H3(MK, 'Newsletter — couverture', 'mk_newsletter', 'ciel', 'a4p', 'hero', { kicker: 'N° … · MOIS ANNÉE', title: 'LA LETTRE\nD’INFORMATION', td: 9, sub: 'Au sommaire :', lines: ['• Actualités de l’entreprise', '• Projets en cours', '• Conseils pratiques', '• Agenda'] });
  H3(MK, 'Construction clé en main', 'mk_cle_en_main', 'noir', 'sq', 'hero', { kicker: 'CLÉ EN MAIN', title: 'DE LA\nPARCELLE À\nLA CLÉ', td: 9, sub: 'Plans · permis · construction · finitions', lines: ['✔ Prix ferme', '✔ Délai garanti'], cta: 'Devis gratuit' });
  H3(MK, 'Paiement échelonné', 'mk_echelonne', 'vert', 'sq', 'hero', { kicker: '💳 FACILITÉS', title: 'PAYEZ EN\nPLUSIEURS FOIS', td: 10, sub: 'Un acompte, puis des paiements à chaque étape.', cta: 'Demandez votre échéancier' });
  H3(MK, 'Garantie sur nos travaux', 'mk_garantie', 'marine', 'sq', 'stats', { kicker: 'VOTRE TRANQUILLITÉ', title: 'NOS GARANTIES', items: [['… ans', 'Garantie structure'], ['… mois', 'Garantie finitions'], ['24 h', 'Réponse SAV'], ['100 %', 'Suivi après livraison']], td: 11 });
  H3(MK, 'Plan 3D / visite virtuelle offerts', 'mk_3d', 'ciel', 'sq', 'hero', { kicker: '🏠 OFFERT', title: 'VOTRE PLAN 3D\nGRATUIT', td: 11, sub: 'Pour tout projet de construction signé ce mois.', cta: 'Contactez-nous' });
  H3(MK, 'Témoignage client (story)', 'mk_temoin_story', 'orange', 'story', 'quote', { kicker: 'ILS NOUS FONT CONFIANCE', quote: 'Un travail soigné, des délais respectés. Merci à toute l’équipe !', author: '— Prénom NOM, client', qd: 14 });

  /* Réseaux sociaux (suite) */
  H3('Réseaux sociaux', 'Devinette / jeu', 'rs_jeu', 'vert', 'sq', 'hero', { kicker: '🕵 DEVINEZ', title: 'QU’EST-CE\nQUE C’EST ?', td: 9, al: 'center', sub: 'Répondez en commentaire !' });
  H3('Réseaux sociaux', 'À faire / à éviter', 'rs_faireviter', 'blanc', 'sq', 'cards', { title: 'À FAIRE / À ÉVITER', td: 13, items: [['✔ À FAIRE', '', '• …\n• …\n• …'], ['✖ À ÉVITER', '', '• …\n• …\n• …']], th: 320 });
  H3('Réseaux sociaux', 'Dans les coulisses', 'rs_coulisses', 'noir', 'sq', 'hero', { kicker: '🎬 COULISSES', title: 'DANS LES\nCOULISSES', td: 9, sub: 'Découvrez comment nous travaillons au quotidien.' });
  H3('Réseaux sociaux', 'Présentation d’un membre (story)', 'rs_equipe', 'marine', 'story', 'profile', { kicker: 'RENCONTRE DE L’ÉQUIPE', name: 'Prénom NOM', role: 'Fonction', msg: 'Sa passion : … · Son rôle : …' });
  H3('Réseaux sociaux', 'Un grand chiffre', 'rs_grand', 'rouge', 'sq', 'hero', { kicker: 'SAVIEZ-VOUS QUE ?', title: '+100', td: 4, al: 'center', sub: 'projets livrés depuis notre création', lines: ['Merci pour votre confiance.'] });
  H3('Réseaux sociaux', 'Vrai ou faux', 'rs_vraifaux', 'ciel', 'sq', 'hero', { kicker: '❓ QUIZ', title: 'VRAI\nOU FAUX ?', td: 8, al: 'center', sub: '« Affirmation à tester … »', cta: 'Réponse demain' });

  /* Immobilier (suite) */
  H3('Immobilier & terrains', 'Bien loué / vendu — merci', 'im_loue', 'vert', 'sq', 'hero', { kicker: '🎉 DÉJÀ LOUÉ', title: 'LOUÉ !', td: 6, al: 'center', sub: 'Merci pour votre confiance.' });
  H3('Immobilier & terrains', 'Estimation gratuite', 'im_estimation', 'marine', 'sq', 'hero', { kicker: 'ESTIMATION', title: 'COMBIEN VAUT\nVOTRE BIEN ?', td: 10, sub: 'Obtenez une estimation gratuite et sans engagement.', cta: 'Appelez-nous' });
  H3('Immobilier & terrains', 'Conseils avant d’acheter un terrain', 'im_conseils', 'blanc', 'sq', 'check', { title: 'AVANT D’ACHETER\nUN TERRAIN', td: 11, items: ['Vérifier le titre de propriété', 'Confirmer les limites (bornage)', 'S’informer sur la zone et l’accès', 'Vérifier eau et électricité', 'Se faire accompagner'], ld: 22 });
  H3('Immobilier & terrains', 'Construire ou acheter ?', 'im_vs', 'ciel', 'sq', 'cards', { title: 'CONSTRUIRE OU ACHETER ?', td: 14, items: [['🏗 CONSTRUIRE', '', 'Sur mesure · budget étalé · qualité maîtrisée.'], ['🏠 ACHETER', '', 'Immédiat · prix connu · moins de choix.']], th: 300 });

  /* Sécurité (suite) */
  H3('Sécurité & qualité', 'Travail en hauteur', 'sq_hauteur', 'orange', 'a4p', 'check', { title: 'TRAVAIL EN HAUTEUR', td: 11, items: ['Harnais obligatoire', 'Garde-corps en place', 'Échafaudage vérifié', 'Ne jamais travailler seul', 'Interdit par vent fort'], mk: '⚠ ', ld: 22 });
  H3('Sécurité & qualité', 'Risque électrique', 'sq_electricite', 'rouge', 'a4p', 'hero', { kicker: '⚡ DANGER', title: 'RISQUE\nÉLECTRIQUE', td: 8, sub: 'Seul le personnel habilité peut intervenir.', lines: ['✖ Ne jamais toucher un câble dénudé', '✔ Couper le courant avant toute intervention'], ld: 22 });
  H3('Sécurité & qualité', 'Prévention incendie', 'sq_incendie', 'rouge', 'a4p', 'steps', { title: 'EN CAS D’INCENDIE', td: 11, items: [['Alerter', 'Donnez l’alarme.'], ['Évacuer', 'Rejoignez le point de rassemblement.'], ['Appeler', 'Contactez les pompiers.']] });
  H3('Sécurité & qualité', 'Échafaudage : règles', 'sq_echaf', 'blanc', 'a4p', 'check', { title: 'ÉCHAFAUDAGE', td: 12, sub: 'Avant utilisation', items: ['Vérification de la stabilité', 'Plateaux complets', 'Garde-corps et plinthes', 'Accès sécurisé', 'Charge maximale respectée'], mk: '☐ ', ld: 22 });
  H3('Sécurité & qualité', 'Interdictions sur chantier', 'sq_interdit', 'rouge', 'a4p', 'check', { title: 'INTERDIT SUR\nLE CHANTIER', td: 10, items: ['Fumer', 'Courir', 'Consommer de l’alcool', 'Utiliser le téléphone en manœuvre', 'Entrer sans autorisation'], mk: '⛔ ', ld: 22 });

  /* Formations (suite) */
  H3('Formations & écoles', 'Calendrier des cours', 'fo_calendrier', 'blanc', 'a4p', 'table', { title: 'CALENDRIER', td: 12, sub: 'Session … · Salle …', items: [['Lundi', 'Cours …'], ['Mardi', 'Cours …'], ['Mercredi', 'Cours …'], ['Jeudi', 'Cours …'], ['Vendredi', 'Cours …'], ['Samedi', 'Atelier …']] });
  H3('Formations & écoles', 'Résultats / admis', 'fo_resultats', 'marine', 'sq', 'hero', { kicker: '🎓 RÉSULTATS', title: 'LES RÉSULTATS\nSONT TOMBÉS', td: 11, al: 'center', sub: 'Consultez la liste des admis auprès du secrétariat.' });
  H3('Formations & écoles', 'Inscription en ligne', 'fo_ligne', 'ciel', 'sq', 'steps', { title: 'S’INSCRIRE EN 3 ÉTAPES', td: 12, items: [['Remplir le formulaire', 'Sur notre site ou en agence.'], ['Payer les frais', 'Mobile Money, banque ou caisse.'], ['Recevoir la confirmation', 'Par message ou e-mail.']] });
  H3('Formations & écoles', 'Bourse d’excellence', 'fo_bourse', 'noir', 'sq', 'hero', { kicker: '🏆 BOURSE', title: 'BOURSE\nD’EXCELLENCE', td: 10, al: 'center', sub: 'Pour les meilleurs candidats · Dépôt avant le …', cta: 'Postulez' });
  H3('Formations & écoles', 'Règlement de l’établissement', 'fo_reglement', 'blanc', 'a4p', 'check', { title: 'RÈGLEMENT\nDES COURS', td: 11, items: ['Ponctualité obligatoire', 'Téléphones en mode silencieux', 'Respect des formateurs et des camarades', 'Matériel à prendre en soin', 'Frais payés avant chaque module'], mk: '§ ', ld: 22 });

  /* ===== V158 : communication interne, Instagram portrait, métiers, offres, salons, badges, certificats, autres secteurs ===== */
  FMT.ig = { l: 'Instagram portrait (4:5)', w: 1080, h: 1350, mm: null, sc: 1.8 };
  FMT.badge = { l: 'Badge (54 × 86 mm)', w: 638, h: 1013, mm: [54, 86], sc: 3 };
  FMT.tw = { l: 'Bannière X / YouTube (3:1)', w: 1500, h: 500, mm: null, sc: 1.5 };
  FMT.pin = { l: 'Pinterest (2:3)', w: 1000, h: 1500, mm: null, sc: 1.6 };
  var CI = 'Communication interne', IG = 'Instagram (portrait)', ME = 'Métiers & services du bâtiment', OF = 'Offres & ventes', SE = 'Salons & événements pro', BD = 'Badges, cartes & petits formats', CD = 'Certificats & diplômes', AS = 'Autres secteurs d’activité';
  function CERT(k, l, title, txt) { M3(k, CD, l, 'blanc', 'a4l', function (F) { var W = F.w, H = F.h, m = Math.round(W * 0.045), B = brand(), out = [];
    out.push({ t: 'rect', x: m, y: m, w: W - 2 * m, h: H - 2 * m, fill: 'rgba(0,0,0,0)', stroke: '#c9a227', sw: 10, rad: 0 }); out.push({ t: 'rect', x: m * 2, y: m * 2, w: W - 4 * m, h: H - 4 * m, fill: 'rgba(0,0,0,0)', stroke: '#12305e', sw: 2, rad: 0 });
    out.push({ t: 'img', src: logoSrcForStudio(), x: Math.round(W / 2 - W * 0.04), y: Math.round(H * 0.1), w: Math.round(W * 0.08), h: Math.round(W * 0.08), fit: 'contain', op: 1, rad: 0 });
    var T = function (tx, yp, dv, col, o) { out.push(Object.assign({ t: 'text', tx: tx, x: m * 3, y: Math.round(H * yp), w: W - 6 * m, h: 60, fs: Math.round(W / dv), col: col, b: false, al: 'center', ff: 0, lh: 1.25 }, o || {})); };
    T(B.name.toUpperCase(), 0.245, 46, '#12305e', { b: true, ls: 3 }); T(title, 0.3, W / Math.min(W / 17, (W - 6 * m) / (title.length * 0.74)), '#12305e', { b: true, ff: 1, ls: 2 }); T('est décerné à', 0.425, 36, '#42526e', { i: true, ff: 3 });
    T('Prénom NOM', 0.465, 14, '#c9a227', { b: true, i: true, ff: 3 }); out.push({ t: 'rect', x: Math.round(W * 0.3), y: Math.round(H * 0.585), w: Math.round(W * 0.4), h: 3, fill: '#12305e', sw: 0, rad: 0 });
    T(txt, 0.61, 36, '#12305e', { lh: 1.35 }); T('Fait à … , le … ', 0.735, 40, '#42526e', { i: true });
    out.push({ t: 'text', tx: 'Le Directeur\n(signature et cachet)', x: m * 3, y: Math.round(H * 0.795), w: Math.round(W * 0.3), h: 60, fs: Math.round(W / 46), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.3 });
    out.push({ t: 'text', tx: 'Le Responsable\n(signature)', x: W - m * 3 - Math.round(W * 0.3), y: Math.round(H * 0.795), w: Math.round(W * 0.3), h: 60, fs: Math.round(W / 46), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.3 });
    return out; }); }
  function BADGE(k, l, band, pal, role) { M3(k, BD, l, pal, 'badge', function (F) { var W = F.w, H = F.h, B = brand(), s = sty3(pal), out = [], m = Math.round(W * 0.08);
    out.push({ t: 'rect', x: 0, y: 0, w: W, h: Math.round(H * 0.2), fill: '#12305e', sw: 0, rad: 0 }); out.push({ t: 'img', src: logoSrcForStudio(), x: m, y: Math.round(H * 0.03), w: Math.round(W * 0.2), h: Math.round(W * 0.2), fit: 'contain', op: 1, rad: 0 });
    out.push({ t: 'text', tx: B.name.toUpperCase(), x: m + Math.round(W * 0.23), y: Math.round(H * 0.055), w: Math.round(W * 0.6), h: 50, fs: Math.round(W / 20), col: '#ffffff', b: true, al: 'left', ff: 0, lh: 1.15 });
    out.push({ t: 'rect', x: Math.round(W * 0.2), y: Math.round(H * 0.25), w: Math.round(W * 0.6), h: Math.round(H * 0.3), fill: '#e3eaf4', stroke: '#9fb0c8', sw: 3, rad: 14 }); out.push({ t: 'text', tx: '📷 Photo', x: Math.round(W * 0.2), y: Math.round(H * 0.385), w: Math.round(W * 0.6), h: 40, fs: Math.round(W / 22), col: '#5e6f8c', b: true, al: 'center', ff: 0, lh: 1.2 });
    out.push({ t: 'text', tx: 'Prénom NOM', x: m, y: Math.round(H * 0.585), w: W - 2 * m, h: 60, fs: Math.round(W / 13), col: s.ink, b: true, al: 'center', ff: 0, lh: 1.15 });
    out.push({ t: 'text', tx: role, x: m, y: Math.round(H * 0.67), w: W - 2 * m, h: 40, fs: Math.round(W / 22), col: '#c9a227', b: true, al: 'center', ff: 0, lh: 1.2 });
    out.push({ t: 'text', tx: 'Matricule : …\nValable jusqu’au : …', x: m, y: Math.round(H * 0.75), w: W - 2 * m, h: 80, fs: Math.round(W / 26), col: s.mut, b: false, al: 'center', ff: 0, lh: 1.5 });
    out.push({ t: 'rect', x: 0, y: Math.round(H * 0.9), w: W, h: Math.round(H * 0.1), fill: '#c9a227', sw: 0, rad: 0 }); out.push({ t: 'text', tx: band, x: 0, y: Math.round(H * 0.925), w: W, h: 40, fs: Math.round(W / 14), col: '#12305e', b: true, al: 'center', ff: 1, lh: 1.1, ls: 3 });
    return out; }); }

  /* Communication interne */
  H3(CI, 'Réunion générale du personnel', 'ci_reunion', 'marine', 'sq', 'ann', { kicker: 'COMMUNICATION INTERNE', title: 'RÉUNION\nGÉNÉRALE', td: 9, sub: 'Présence de tout le personnel requise.', info: '📅 Date : …\n🕘 Heure : …\n📍 Salle : …\n📋 Ordre du jour : …' });
  H3(CI, 'Résultats du mois (tableau de bord)', 'ci_resultats', 'blanc', 'sq', 'stats', { kicker: 'NOS RÉSULTATS', title: 'BILAN DU MOIS', items: [['… %', 'Objectif atteint'], ['…', 'Projets livrés'], ['…', 'Nouveaux clients'], ['0', 'Accident']], td: 11 });
  H3(CI, 'Objectifs du trimestre', 'ci_objectifs', 'ciel', 'sq', 'check', { title: 'OBJECTIFS DU\nTRIMESTRE', td: 11, items: ['Objectif 1 : …', 'Objectif 2 : …', 'Objectif 3 : …', 'Objectif 4 : …'], mk: '🎯 ', ld: 22 });
  H3(CI, 'Merci à toute l’équipe', 'ci_merci', 'vert', 'sq', 'hero', { kicker: 'BRAVO', title: 'MERCI À\nTOUTE L’ÉQUIPE', td: 10, al: 'center', sub: 'Grâce à vous, nous avons atteint nos objectifs.' });
  H3(CI, 'Règle d’or du jour', 'ci_regle', 'noir', 'sq', 'quote', { kicker: 'RÈGLE D’OR', quote: 'La qualité ne se négocie jamais.', author: '— Notre engagement', qd: 12 });
  H3(CI, 'Boîte à idées', 'ci_idees', 'orange', 'sq', 'hero', { kicker: '💡 PARTICIPEZ', title: 'BOÎTE\nÀ IDÉES', td: 8, al: 'center', sub: 'Une suggestion pour améliorer notre travail ? Partagez-la !' });
  H3(CI, 'Anniversaires du mois', 'ci_anniv', 'ciel', 'sq', 'check', { title: 'ANNIVERSAIRES\nDU MOIS', td: 12, items: ['Prénom NOM — le …', 'Prénom NOM — le …', 'Prénom NOM — le …'], mk: '🎂 ', ld: 20 });
  H3(CI, 'Planning des congés', 'ci_conges', 'blanc', 'a4p', 'table', { title: 'PLANNING DES CONGÉS', sub: 'À afficher au tableau', items: [['Prénom NOM', 'Du … au …'], ['Prénom NOM', 'Du … au …'], ['Prénom NOM', 'Du … au …'], ['Prénom NOM', 'Du … au …']] });
  H3(CI, 'Mot du directeur', 'ci_directeur', 'marine', 'a4p', 'quote', { kicker: 'LE MOT DU DIRECTEUR', quote: 'Ensemble, nous construisons plus que des bâtiments : nous construisons la confiance.', author: '— Le Directeur Général', qd: 17 });
  H3(CI, 'Consigne importante (affichage)', 'ci_consigne', 'rouge', 'a4p', 'hero', { kicker: '⚠ IMPORTANT', title: 'CONSIGNE\nÀ RESPECTER', td: 8, sub: 'Rédigez ici la consigne en une ou deux phrases claires.', lines: ['✔ Point 1', '✔ Point 2'], cta: 'Merci de votre collaboration' });

  /* Instagram portrait (carrousel / posts) */
  H3(IG, 'Carrousel — couverture', 'ig_cover', 'marine', 'ig', 'hero', { kicker: 'GUIDE · ASTUCES', title: 'TITRE DU\nCARROUSEL', td: 9, sub: 'Faites glisser →', lines: ['5 conseils pratiques'] });
  H3(IG, 'Carrousel — slide texte', 'ig_texte', 'blanc', 'ig', 'hero', { kicker: 'ASTUCE N° 1', title: 'Titre de\nl’astuce', td: 10, sub: 'Expliquez le conseil en deux ou trois phrases simples pour vos abonnés.' });
  H3(IG, 'Carrousel — slide liste', 'ig_liste', 'ciel', 'ig', 'check', { title: 'À RETENIR', td: 11, items: ['Point clé 1', 'Point clé 2', 'Point clé 3', 'Point clé 4'], ld: 20 });
  H3(IG, 'Carrousel — appel à l’action final', 'ig_cta', 'noir', 'ig', 'hero', { kicker: 'MERCI D’AVOIR LU', title: 'ON SE SUIT ?', td: 9, al: 'center', sub: 'Aimez · Commentez · Partagez · Enregistrez', cta: 'Contactez-nous' });
  H3(IG, 'Citation portrait', 'ig_citation', 'marine', 'ig', 'quote', { kicker: 'CITATION', quote: 'Chaque grand projet commence par une idée et un premier trait.', author: '— …' });
  H3(IG, 'Avant / Après portrait', 'ig_avant', 'blanc', 'ig', 'cards', { title: 'AVANT / APRÈS', td: 12, items: [['AVANT', '', 'Décrivez l’état initial.'], ['APRÈS', '', 'Décrivez le résultat obtenu.']], th: 360 });
  H3(IG, 'Chiffres clés portrait', 'ig_chiffres', 'vert', 'ig', 'stats', { kicker: 'EN BREF', title: 'NOS CHIFFRES', items: [['+…', 'Projets'], ['…', 'Années'], ['…', 'Clients'], ['…', 'Équipe']], td: 11 });
  H3(IG, 'Annonce portrait', 'ig_annonce', 'orange', 'ig', 'ann', { kicker: 'ANNONCE', title: 'TITRE DE\nL’ANNONCE', td: 9, sub: 'Un message court et clair.', info: '📅 …\n📍 …', cta: 'Plus d’infos : …' });
  H3(IG, 'Promotion portrait', 'ig_promo', 'rouge', 'ig', 'promo', { kicker: 'OFFRE SPÉCIALE', big: '-20%', title: 'SUR TOUS NOS\nSERVICES', sub: 'Jusqu’au …', cta: 'Réservez maintenant' });
  H3(IG, 'Témoignage portrait', 'ig_temoin', 'ciel', 'ig', 'quote', { kicker: '★★★★★', quote: 'Équipe sérieuse, travail impeccable. Je recommande !', author: '— Prénom NOM, client' });
  H3(IG, 'Quiz portrait', 'ig_quiz', 'vert', 'ig', 'hero', { kicker: '🧠 QUIZ', title: 'TESTEZ VOS\nCONNAISSANCES', td: 10, sub: 'Question : … ?', lines: ['A. …', 'B. …', 'C. …'], cta: 'Réponse en commentaire' });
  H3(IG, 'Présentation d’un projet', 'ig_projet', 'marine', 'ig', 'property', { kicker: 'PROJET', title: 'NOM DU PROJET', td: 13, ph: 0.34, price: 'Livré en … · Lieu : …', items: ['📐 Surface : …', '🏗 Type : …', '⏱ Durée : …'], cta: 'Voir tout le projet' });

  /* Métiers & services du bâtiment */
  [['me_maconnerie', 'Maçonnerie', '🧱', 'MAÇONNERIE', ['Fondations et élévations', 'Dalles, poteaux, poutres', 'Murs et enduits']], ['me_plomberie', 'Plomberie', '🚰', 'PLOMBERIE', ['Installation sanitaire', 'Réparation de fuites', 'Chauffe-eau et citernes']], ['me_electricite', 'Électricité', '💡', 'ÉLECTRICITÉ', ['Installation neuve', 'Dépannage', 'Mise aux normes']], ['me_peinture', 'Peinture', '🎨', 'PEINTURE', ['Intérieur et extérieur', 'Enduits décoratifs', 'Ravalement de façade']], ['me_carrelage', 'Carrelage', '🔲', 'CARRELAGE', ['Sols et murs', 'Salles de bains', 'Pose soignée']], ['me_toiture', 'Toiture', '🏠', 'TOITURE', ['Charpente et tôles', 'Étanchéité', 'Réparation de fuites']], ['me_menuiserie', 'Menuiserie', '🪚', 'MENUISERIE', ['Portes et fenêtres', 'Placards sur mesure', 'Charpente bois']], ['me_climatisation', 'Climatisation', '❄', 'CLIMATISATION', ['Installation', 'Entretien', 'Dépannage']], ['me_topographie', 'Topographie', '📍', 'TOPOGRAPHIE', ['Levés de terrain', 'Bornage', 'Implantation']], ['me_geotech', 'Études de sol', '🔬', 'ÉTUDES DE SOL', ['Sondages', 'Essais géotechniques', 'Rapport de fondation']], ['me_plans', 'Plans architecturaux', '📐', 'PLANS & ARCHITECTURE', ['Plans de villas et immeubles', 'Plans 3D', 'Dossier de permis']], ['me_permis', 'Permis de construire', '📄', 'PERMIS DE CONSTRUIRE', ['Montage du dossier', 'Suivi administratif', 'Obtention rapide']], ['me_suivi', 'Suivi de chantier', '📋', 'SUIVI DE CHANTIER', ['Contrôle qualité', 'Respect des délais', 'Rapports réguliers']], ['me_deco', 'Décoration intérieure', '🛋', 'DÉCORATION', ['Conseil et design', 'Mobilier sur mesure', 'Aménagement']], ['me_paysage', 'Aménagement paysager', '🌿', 'PAYSAGISME', ['Jardins et pelouses', 'Clôtures et allées', 'Arrosage']], ['me_renovation', 'Rénovation (cuisine / salle de bains)', '🔧', 'RÉNOVATION', ['Cuisine', 'Salle de bains', 'Remise à neuf']], ['me_forage', 'Forage et adduction d’eau', '💧', 'FORAGE & EAU', ['Forage de puits', 'Pompes et citernes', 'Réseau d’eau']], ['me_solaire', 'Énergie solaire', '☀', 'ÉNERGIE SOLAIRE', ['Panneaux solaires', 'Onduleurs et batteries', 'Étude gratuite']]].forEach(function (a, i) {
    var pal = ['marine', 'orange', 'noir', 'vert', 'ciel', 'rouge'][i % 6];
    H3(ME, a[1] + ' (carré)', a[0], pal, 'sq', 'hero', { kicker: a[2] + ' NOS SERVICES', title: a[3], td: a[3].length > 14 ? 12 : 9, sub: 'Un travail soigné, des délais respectés.', lines: a[4].map(function (x) { return '✔ ' + x; }), cta: 'Devis gratuit' }); });

  /* Offres & ventes */
  H3(OF, 'Soldes', 'of_soldes', 'rouge', 'sq', 'promo', { kicker: 'SOLDES', big: '-50%', title: 'GRANDS\nSOLDES', sub: 'Jusqu’à épuisement du stock', cta: 'Vite, profitez-en' });
  H3(OF, 'Offre étudiants', 'of_etudiant', 'ciel', 'sq', 'hero', { kicker: '🎓 ÉTUDIANTS', title: 'TARIF\nÉTUDIANT', td: 9, sub: 'Présentez votre carte et bénéficiez d’une réduction.', cta: '-… %' });
  H3(OF, 'Code promo', 'of_code', 'noir', 'sq', 'hero', { kicker: 'CODE PROMO', title: 'EXB2027', td: 7, al: 'center', sub: 'Utilisez ce code pour bénéficier de … % de réduction.', cta: 'Valable jusqu’au …' });
  H3(OF, 'Livraison gratuite (matériaux)', 'of_livraison', 'vert', 'sq', 'hero', { kicker: '🚚 LIVRAISON', title: 'LIVRAISON\nGRATUITE', td: 9, al: 'center', sub: 'Pour toute commande de matériaux supérieure à … USD.' });
  H3(OF, 'Prix cassés matériaux', 'of_prix', 'orange', 'a4p', 'table', { title: 'PRIX CASSÉS', sub: 'Matériaux de construction', items: [['Ciment 42,5 (sac)', '… USD'], ['Fer à béton 12 mm', '… USD'], ['Tôle bac alu', '… USD'], ['Carreaux (m²)', '… USD'], ['Peinture (seau)', '… USD']], note: 'Dans la limite des stocks disponibles.' });
  H3(OF, 'Déstockage', 'of_destockage', 'rouge', 'story', 'promo', { kicker: 'DÉSTOCKAGE TOTAL', big: '-60%', title: 'TOUT DOIT\nPARTIR', sub: 'Avant le …', cta: 'Passez en magasin' });
  H3(OF, 'Offre du week-end', 'of_weekend', 'orange', 'sq', 'promo', { kicker: 'CE WEEK-END', big: '-15%', title: 'OFFRE\nWEEK-END', sub: 'Samedi et dimanche seulement', cta: 'Réservez' });
  H3(OF, 'Pack famille / pack complet', 'of_pack', 'marine', 'sq', 'hero', { kicker: '📦 PACK', title: 'LE PACK\nCOMPLET', td: 9, sub: 'Tout ce qu’il faut pour votre projet, à prix réduit.', lines: ['✔ Plans', '✔ Permis', '✔ Construction'], cta: 'Prix : … USD' });
  H3(OF, 'Paiement à la livraison', 'of_cod', 'ciel', 'sq', 'hero', { kicker: '✔ SIMPLE ET SÛR', title: 'PAYEZ À\nLA LIVRAISON', td: 10, sub: 'Commandez, recevez, puis réglez.' });
  H3(OF, 'Pré-commande', 'of_precommande', 'noir', 'sq', 'hero', { kicker: 'PRÉ-COMMANDE OUVERTE', title: 'RÉSERVEZ\nDÈS MAINTENANT', td: 10, sub: 'Livraison prévue : … · Acompte : …' });
  H3(OF, 'Nouveauté du catalogue', 'of_nouveau', 'blanc', 'sq', 'property', { kicker: 'NOUVEAUTÉ', title: 'NOM DU PRODUIT', td: 13, price: 'Prix : … USD', items: ['✔ Caractéristique 1', '✔ Caractéristique 2', '✔ Caractéristique 3'], cta: 'Commandez' });
  H3(OF, 'Comparatif de formules', 'of_compare', 'blanc', 'a4l', 'cards', { title: 'COMPARONS', td: 18, items: [['Option A', '… USD', 'Avantage 1\nAvantage 2'], ['Option B', '… USD', 'Avantage 1\nAvantage 2'], ['Option C', '… USD', 'Avantage 1\nAvantage 2']] });

  /* Salons & événements professionnels */
  H3(SE, 'Salon / foire — nous y serons', 'se_salon', 'marine', 'sq', 'ann', { kicker: 'RENDEZ-VOUS', title: 'NOUS SERONS\nAU SALON', td: 10, sub: 'Venez nous rencontrer sur notre stand.', info: '📅 Du … au …\n📍 Lieu : …\n🏷 Stand n° : …' });
  H3(SE, 'Kakemono de stand', 'se_stand', 'noir', 'roll', 'hero', function (B) { return { kicker: B.name.toUpperCase(), title: 'CONSTRUIRE\nL’AVENIR', td: 7, sub: B.tagline || '', lines: ['🏗 Construction', '📐 Études & plans', '🏠 Immobilier'], ld: 15, cta: B.phone }; });
  H3(SE, 'Conférence de presse', 'se_presse', 'blanc', 'a4p', 'ann', { kicker: 'INVITATION PRESSE', title: 'CONFÉRENCE\nDE PRESSE', td: 9, sub: 'Présentation du projet : …', info: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', cta: 'Confirmez votre présence' });
  H3(SE, 'Atelier / workshop', 'se_atelier', 'ciel', 'sq', 'ann', { kicker: 'ATELIER', title: 'ATELIER\nPRATIQUE', td: 10, sub: 'Thème : …', info: '📅 …\n🕘 …\n📍 …\n👥 Places limitées', cta: 'Inscrivez-vous' });
  H3(SE, 'Journée sécurité', 'se_securite', 'orange', 'sq', 'ann', { kicker: 'SENSIBILISATION', title: 'JOURNÉE\nSÉCURITÉ', td: 9, sub: 'Formation aux gestes qui sauvent.', info: '📅 …\n📍 …' });
  H3(SE, 'Team building', 'se_team', 'vert', 'sq', 'ann', { kicker: 'COHÉSION', title: 'TEAM\nBUILDING', td: 9, sub: 'Une journée pour renforcer l’esprit d’équipe.', info: '📅 …\n📍 …' });
  H3(SE, 'Assemblée générale', 'se_ag', 'blanc', 'a4p', 'ann', { kicker: 'CONVOCATION', title: 'ASSEMBLÉE\nGÉNÉRALE', td: 9, sub: 'Tous les associés sont conviés.', info: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …\n📋 Ordre du jour : …' });
  H3(SE, 'Lancement de produit / projet', 'se_lancement', 'noir', 'sq', 'ann', { kicker: 'LANCEMENT OFFICIEL', title: 'NOUVEAU\nPROJET', td: 9, sub: 'Découvrez-le en avant-première.', info: '📅 …\n📍 …' });
  H3(SE, 'Visite officielle / délégation', 'se_visite', 'marine', 'sq', 'hero', { kicker: 'HONNEUR', title: 'VISITE\nOFFICIELLE', td: 10, al: 'center', sub: 'Accueil de … sur notre site.' });
  H3(SE, 'Programme de la journée', 'se_programme', 'blanc', 'a4p', 'table', { title: 'PROGRAMME', sub: 'Journée du …', items: [['08 h 30', 'Accueil'], ['09 h 00', 'Ouverture'], ['10 h 00', 'Présentation'], ['12 h 00', 'Pause déjeuner'], ['14 h 00', 'Ateliers'], ['16 h 30', 'Clôture']] });
  H3(SE, 'Invitation VIP', 'se_vip', 'noir', 'sq', 'ann', { kicker: 'INVITATION PERSONNELLE', title: 'SOIRÉE\nVIP', td: 9, al: 'center', sub: 'Vous êtes cordialement invité(e).', info: '📅 …\n🕘 …\n📍 …' });
  H3(SE, 'Remerciements après événement', 'se_merci', 'ciel', 'sq', 'hero', { kicker: 'MERCI', title: 'MERCI À TOUS\nLES PARTICIPANTS', td: 11, al: 'center', sub: 'Rendez-vous à la prochaine édition !' });

  /* Badges, cartes & petits formats */
  BADGE('bd_employe', 'Badge employé', 'PERSONNEL', 'blanc', 'Fonction / Service');
  BADGE('bd_visiteur', 'Badge visiteur', 'VISITEUR', 'blanc', 'Société / Motif de la visite');
  BADGE('bd_vip', 'Badge invité / VIP', 'INVITÉ', 'blanc', 'Invité d’honneur');
  BADGE('bd_chantier', 'Badge de chantier', 'CHANTIER', 'blanc', 'Poste / Entreprise');
  H3(BD, 'Carte de fidélité', 'bd_fidelite', 'marine', 'card', 'hero', { short: true, title: 'CARTE DE FIDÉLITÉ', td: 14, sub: 'N° : …        Titulaire : …' });
  H3(BD, 'Carte de vœux', 'bd_voeux', 'rouge', 'card', 'hero', { short: true, title: 'MEILLEURS VŒUX', td: 12, sub: 'Toute l’équipe vous souhaite une excellente année.' });
  H3(BD, 'Ticket d’entrée / invitation', 'bd_ticket', 'noir', 'card', 'hero', { short: true, title: 'INVITATION · 1 PERSONNE', td: 16, sub: 'Date : …   Lieu : …   N° : …' });
  H3(BD, 'Carte de remerciement', 'bd_merci', 'ciel', 'card', 'hero', { short: true, title: 'MERCI !', td: 8, sub: 'Pour votre confiance et votre fidélité.' });
  H3(BD, 'Carte rendez-vous', 'bd_rdv', 'blanc', 'card', 'hero', { short: true, title: 'VOTRE RENDEZ-VOUS', td: 14, sub: 'Date : …   Heure : …   Avec : …' });
  H3(BD, 'Étiquette de colis / dossier', 'bd_etiquette', 'blanc', 'card', 'hero', { short: true, title: 'DOSSIER N° …', td: 12, sub: 'Client : …     Projet : …     Date : …' });
  H3(BD, 'Panneau de porte / bureau', 'bd_porte', 'marine', 'ban', 'hero', { short: true, title: 'BUREAU DE …', td: 9, sub: 'Nom · Fonction · Horaires de réception', noFoot: false });
  H3(BD, 'Bannière X / YouTube', 'bd_tw', 'marine', 'tw', 'hero', function (B) { return { short: true, title: 'VOTRE PARTENAIRE\nDE CONFIANCE', td: 17, sub: B.name + ' · ' + (B.tagline || ''), sd: 36 }; });
  H3(BD, 'Épingle Pinterest', 'bd_pin', 'blanc', 'pin', 'hero', { kicker: 'IDÉE DÉCO', title: 'TITRE DE\nL’ÉPINGLE', td: 9, sub: 'Un visuel vertical à partager.', cta: 'Voir plus' });
  H3(BD, 'Signet / marque-page', 'bd_signet', 'ciel', 'story', 'quote', { kicker: '', quote: 'Lire, c’est bâtir son esprit.', author: '— …', qd: 12 });

  /* Certificats & diplômes */
  CERT('cd_reussite', 'Certificat de réussite', 'CERTIFICAT DE RÉUSSITE', 'pour avoir suivi avec succès la formation « … » du … au … , avec la mention « … ».');
  CERT('cd_participation', 'Certificat de participation', 'CERTIFICAT DE PARTICIPATION', 'pour sa participation active à « … » organisé(e) le … à … .');
  CERT('cd_honneur', 'Diplôme d’honneur', 'DIPLÔME D’HONNEUR', 'en reconnaissance de son dévouement, de son professionnalisme et de ses services rendus.');
  CERT('cd_reconnaissance', 'Certificat de reconnaissance', 'CERTIFICAT DE RECONNAISSANCE', 'en témoignage de gratitude pour sa précieuse contribution à … .');
  CERT('cd_mois', 'Certificat employé du mois', 'EMPLOYÉ DU MOIS', 'pour son excellent travail, son engagement et son esprit d’équipe durant le mois de … .');
  CERT('cd_anciennete', 'Certificat d’ancienneté', 'MÉDAILLE D’ANCIENNETÉ', 'pour … années de services loyaux au sein de notre entreprise.');
  CERT('cd_partenaire', 'Certificat de partenariat', 'CERTIFICAT DE PARTENAIRE', 'en qualité de partenaire officiel de notre entreprise pour la période … .');
  CERT('cd_meilleur', 'Prix du meilleur / trophée', 'PRIX D’EXCELLENCE', 'pour avoir obtenu le premier prix de la catégorie « … » lors de … .');

  /* Autres secteurs d’activité */
  H3(AS, 'Menu du jour (restaurant)', 'as_menu', 'blanc', 'a4p', 'table', { title: 'MENU DU JOUR', sub: 'Du … au …', items: [['Entrée', '… FC'], ['Plat principal', '… FC'], ['Dessert', '… FC'], ['Boisson', '… FC'], ['Menu complet', '… FC']] });
  H3(AS, 'Livraison à domicile', 'as_livraison', 'orange', 'sq', 'hero', { kicker: '🛵 COMMANDEZ', title: 'LIVRAISON\nÀ DOMICILE', td: 9, sub: 'Rapide, chaud et sans frais cachés.', cta: 'Appelez : …' });
  H3(AS, 'Ouverture de boutique', 'as_ouverture', 'marine', 'sq', 'ann', { kicker: 'GRANDE OUVERTURE', title: 'NOUVELLE\nBOUTIQUE', td: 9, sub: 'Venez découvrir nos produits.', info: '📅 Le … à … h\n📍 Adresse : …', cta: 'Offres d’ouverture' });
  H3(AS, 'Programme de la semaine (association)', 'as_programme', 'blanc', 'a4p', 'table', { title: 'PROGRAMME DE LA SEMAINE', sub: 'Activités ouvertes à tous', items: [['Lundi', '… h · …'], ['Mercredi', '… h · …'], ['Vendredi', '… h · …'], ['Dimanche', '… h · …']] });
  H3(AS, 'Appel aux dons / collecte', 'as_dons', 'vert', 'sq', 'hero', { kicker: '🤝 SOLIDARITÉ', title: 'APPEL\nAUX DONS', td: 9, sub: 'Soutenez notre action : …', lines: ['Mobile Money : …', 'Banque : …'], cta: 'Chaque geste compte' });
  H3(AS, 'Campagne de sensibilisation santé', 'as_sante', 'ciel', 'sq', 'hero', { kicker: '🩺 SANTÉ', title: 'PRENEZ SOIN\nDE VOUS', td: 10, sub: 'Dépistage et conseils gratuits.', lines: ['📅 Date : …', '📍 Lieu : …'] });
  H3(AS, 'Journée de salubrité / action citoyenne', 'as_salubrite', 'vert', 'sq', 'ann', { kicker: 'ACTION CITOYENNE', title: 'JOURNÉE DE\nSALUBRITÉ', td: 10, sub: 'Ensemble pour un quartier propre.', info: '📅 …\n🕘 …\n📍 Rendez-vous : …' });
  H3(AS, 'Tournoi sportif', 'as_tournoi', 'rouge', 'sq', 'ann', { kicker: '⚽ TOURNOI', title: 'GRAND\nTOURNOI', td: 9, sub: 'Inscrivez votre équipe !', info: '📅 …\n📍 …\n💰 Frais : …', cta: 'Inscriptions ouvertes' });
  H3(AS, 'Concert / spectacle', 'as_concert', 'noir', 'sq', 'ann', { kicker: '🎤 EN CONCERT', title: 'GRANDE\nSOIRÉE', td: 9, sub: 'Avec : …', info: '📅 …\n🕘 …\n📍 …\n🎟 Entrée : …' });
  H3(AS, 'Salon de coiffure / beauté', 'as_beaute', 'rouge', 'sq', 'promo', { kicker: '💇 BEAUTÉ', big: '-25%', title: 'SOINS &\nCOIFFURE', sub: 'Sur rendez-vous', cta: 'Réservez' });
  H3(AS, 'Garage / entretien auto', 'as_garage', 'noir', 'sq', 'hero', { kicker: '🚗 GARAGE', title: 'ENTRETIEN\nAUTO', td: 9, sub: 'Vidange, freins, diagnostic.', lines: ['✔ Devis gratuit', '✔ Pièces garanties'], cta: 'Prenez rendez-vous' });
  H3(AS, 'Traiteur / événements', 'as_traiteur', 'orange', 'sq', 'hero', { kicker: '🍽 TRAITEUR', title: 'POUR TOUS\nVOS ÉVÉNEMENTS', td: 11, sub: 'Mariages, anniversaires, séminaires.', cta: 'Devis gratuit' });
  H3(AS, 'Location de salle / matériel', 'as_salle', 'marine', 'sq', 'hero', { kicker: '🏛 LOCATION', title: 'SALLE &\nMATÉRIEL', td: 10, sub: 'Chaises, bâches, sonorisation, salle climatisée.', cta: 'Réservez' });
  H3(AS, 'Cours de soutien / alphabétisation', 'as_cours', 'ciel', 'sq', 'hero', { kicker: '📚 ÉDUCATION', title: 'COURS DE\nSOUTIEN', td: 9, sub: 'Primaire · Secondaire · Langues', lines: ['🕕 Horaires : …', '📍 Lieu : …'], cta: 'Inscriptions ouvertes' });
  H3(AS, 'Pharmacie / garde', 'as_garde', 'vert', 'sq', 'hero', { kicker: '⚕ DE GARDE', title: 'PERMANENCE\nDE GARDE', td: 10, al: 'center', sub: 'Du … au … · Ouvert 24 h/24', lines: ['📞 …'] });
  H3(AS, 'Voyage / transport', 'as_transport', 'marine', 'sq', 'hero', { kicker: '🚌 TRANSPORT', title: 'VOYAGEZ\nEN CONFIANCE', td: 10, sub: 'Départs : … · Destinations : …', cta: 'Réservez votre place' });
  H3(AS, 'Agriculture / produits locaux', 'as_agri', 'vert', 'sq', 'hero', { kicker: '🌾 PRODUITS LOCAUX', title: 'FRAIS DU\nCHAMP', td: 10, sub: 'Vente directe du producteur au consommateur.', cta: 'Commandez' });

  Object.keys(TPL3).forEach(function (k) { TPL3[k].relax = !/^(cd_|bd_(employe|visiteur|vip|chantier))/.test(k); TPL[k] = TPL3[k]; });
  ['vide', 'annonce', 'emploi', 'promo'].forEach(function (k) { TPL[k].g = 'Général'; });
  TPL.avis.g = 'Communiqués & avis'; TPL.formation.g = 'Logiciels & formations';
  function tplOptions() {
    var G = [], by = {};
    Object.keys(TPL).forEach(function (k) { var g = TPL[k].g || 'Général'; if (!by[g]) { by[g] = []; G.push(g); } by[g].push(k); });
    return G.map(function (g) { return '<optgroup label="' + g + '">' + by[g].map(function (k) { return '<option value="' + k + '">' + TPL[k].l + '</option>'; }).join('') + '</optgroup>'; }).join('');
  }
  /* évite les chevauchements : mesure la hauteur réelle de chaque texte puis décale vers le bas ce qui le recouvre */
  function relax() {
    var st = $('exbsStage'); if (!st) return;
    function hOf(e) { var n = st.querySelector('[data-id="' + e.id + '"]'); return n ? n.offsetHeight : 0; }
    var texts = ST.els.filter(function (e) { return e.t === 'text' && !e.fx; }).sort(function (a, b) { return a.y - b.y; });
    for (var i = 1; i < texts.length; i++) {
      var b = texts[i];
      for (var j = 0; j < i; j++) {
        var a = texts[j], ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x); if (ox <= 8) continue;
        var ah = hOf(a), need = a.y + ah + 8;
        if (b.y < need - 3 && b.y >= a.y) {
          var dl = need - b.y, y0 = b.y;
          ST.els.forEach(function (e) { if (!e.fx && e.y >= y0 - 1) e.y += dl; });
        }
      }
    }
  }
  /* QR du site vitrine (affiches) : adresse lue dans Site vitrine › Adresses ; aucun lien de vérification. */
  function vitrineUrl() {
    var u = '';
    try { var c = JSON.parse((w.exbStorage && w.exbStorage.getItem('exb_vitrine_cfg')) || w.localStorage.getItem('exb_vitrine_cfg') || '{}') || {}; u = String(c.site_url || '').trim(); } catch (e) {}
    return u || 'https://excellenciacenter01.netlify.app/';
  }
  function qrSrc(url) {
    try {
      if (!w.EXBQR) return '';
      var m = w.EXBQR.matrix(url), n = m.length, q = 2, t = n + 2 * q, px = Math.max(8, Math.ceil(600 / t)), cv = d.createElement('canvas'), x = cv.getContext('2d');
      cv.width = cv.height = t * px; x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.fillStyle = '#000';
      for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) x.fillRect((c + q) * px, (r + q) * px, px, px);
      return cv.toDataURL('image/png');
    } catch (e) { return ''; }
  }
  function qrEl(F, size, y, url) { var s = qrSrc(url || vitrineUrl()); if (!s) return null; size = size || Math.round(F.w * 0.22); return { t: 'img', src: s, x: Math.round((F.w - size) / 2), y: y == null ? F.h - size - Math.round(F.w * 0.04) : y, w: size, h: size, fit: 'contain', op: 1, rot: 0, rad: 0, qr: 1 }; }
  function qrReplace() {
    for (var i = ST.els.length - 1; i >= 0; i--) {
      var e = ST.els[i]; if (e.t !== 'text' || String(e.tx).indexOf('QR code ici') < 0) continue;
      var r = null, j; for (j = i - 1; j >= 0; j--) if (ST.els[j].t === 'rect' && ST.els[j].x === ST.els[i].x && ST.els[j].y < e.y + 1) { r = j; break; }
      if (r == null) continue; var R = ST.els[r], im = qrEl(FMT[ST.fmt], Math.min(R.w, R.h), R.y); if (!im) continue;
      im.x = R.x + Math.round((R.w - im.w) / 2); im.y = R.y + Math.round((R.h - im.h) / 2); im.id = uid();
      ST.els.splice(i, 1); ST.els.splice(r, 1, im);
    }
  }
  function applyTpl(k) {
    var T = TPL[k]; push();
    if (T.fmt && FMT[T.fmt] && T.fmt !== ST.fmt) { ST.fmt = T.fmt; var fs_ = $('exbsFmt'); if (fs_) fs_.value = T.fmt; }
    ST.els = []; sel = null; var p = PALETTES[T.pal]; ST.bg = { c1: p[0], c2: p[1], ang: p[2], img: '', ovl: 0 };
    T.f(FMT[ST.fmt]).forEach(function (e) { e.id = uid(); e.op = e.op == null ? 1 : e.op; e.rot = e.rot || 0; ST.els.push(e); });
    qrReplace(); bgPanel(); refresh();
    if (T.relax) {
      var base = JSON.parse(JSON.stringify(ST.els)), Hh = FMT[ST.fmt].h, lim = Hh - 8, sc, i2;
      ST.els.forEach(function (e) { if (e.fx && e.t === 'rect' && e.y < lim) lim = e.y; });
      for (sc = 1; sc >= 0.65; sc -= 0.05) {
        ST.els = JSON.parse(JSON.stringify(base));
        ST.els.forEach(function (e) { if (e.t === 'text' && !e.fx && sc < 1) e.fs = Math.max(9, Math.round(e.fs * sc)); });
        refresh(); relax(); refresh();
        var bot = 0, st2 = $('exbsStage');
        ST.els.forEach(function (e) { if (e.t === 'text' && !e.fx) { var n = st2.querySelector('[data-id="' + e.id + '"]'); bot = Math.max(bot, e.y + (n ? n.offsetHeight : 0)); } });
        if (bot <= lim - 6) break;
      }
    }
  }

  /* ---------- changement de format : tout est remis à l'échelle ---------- */
  function setFmt(k) {
    if (k === ST.fmt) return; push();
    var A = FMT[ST.fmt], B = FMT[k], sx = B.w / A.w, sy = B.h / A.h, sf = Math.min(sx, sy);
    ST.els.forEach(function (e) { e.x = Math.round(e.x * sx); e.y = Math.round(e.y * sy); e.w = Math.round(e.w * sx); e.h = Math.round(e.h * (e.t === 'img' || e.t === 'ellipse' ? sf : sy)); if (e.t === 'text') e.fs = Math.max(8, Math.round(e.fs * sf)); });
    ST.fmt = k; refresh();
  }

  /* ---------- enregistrement ---------- */
  function listAll() { return rd(K_LIST, []) || []; }
  function saveCur() {
    var nm = ($('exbsName').value || '').trim() || 'Mon affiche'; ST.name = nm;
    var L = listAll(); if (!ST.id) ST.id = uid();
    var o = JSON.parse(JSON.stringify(ST)); o.saved = new Date().toISOString();
    var i = L.map(function (x) { return x.id; }).indexOf(ST.id); if (i >= 0) L[i] = o; else L.unshift(o);
    if (!wr(K_LIST, L)) { note('Enregistrement impossible : espace de stockage plein. Supprimez d’anciennes affiches.', 'error', 7000); return; }
    note('✓ Affiche « ' + nm + ' » enregistrée.', 'ok'); mine();
  }
  function mine() {
    var L = listAll(), el = $('exbsMine'); if (!el) return;
    el.innerHTML = L.length ? L.map(function (x) {
      return '<div class="exbs-it"><div><b>' + esc(x.name) + '</b><span>' + (FMT[x.fmt] ? FMT[x.fmt].l : '') + ' · ' + (x.saved || '').slice(0, 10) + '</span></div><button data-o="' + x.id + '">Ouvrir</button><button data-x="' + x.id + '" class="del">🗑</button></div>';
    }).join('') : '<p class="exbs-hint">Aucune affiche enregistrée pour l’instant.</p>';
    Array.prototype.forEach.call(el.querySelectorAll('[data-o]'), function (b) { b.onclick = function () { var x = listAll().filter(function (y) { return y.id === b.getAttribute('data-o'); })[0]; if (x) { push(); ST = JSON.parse(JSON.stringify(x)); sel = null; $('exbsName').value = ST.name; $('exbsFmt').value = ST.fmt; if (!ST.frame) ST.frame = { on: false }; bgPanel(); framePn(); refresh(); note('Affiche ouverte.', 'ok'); } }; });
    Array.prototype.forEach.call(el.querySelectorAll('[data-x]'), function (b) { b.onclick = async function () { if (!(await exbConfirm('Supprimer cette affiche enregistrée ?'))) return; wr(K_LIST, listAll().filter(function (y) { return y.id !== b.getAttribute('data-x'); })); mine(); }; });
  }

  /* ---------- export ---------- */
  function render(cb) {
    if (typeof w.html2canvas !== 'function') { note('Export impossible : le moteur d’image n’est pas chargé.', 'error', 7000); return; }
    var F = FMT[ST.fmt], host = d.createElement('div');
    host.style.cssText = 'position:fixed;left:-100000px;top:0;';
    var st = d.createElement('div'); host.appendChild(st); d.body.appendChild(host); build(st, false);
    note('Création de l’affiche…', 'info', 2500);
    var imgs = Array.prototype.slice.call(st.querySelectorAll('img')), n = imgs.length, go = function () {
      setTimeout(function () {
        w.html2canvas(st, { scale: F.sc, backgroundColor: '#ffffff', useCORS: false, logging: false, width: F.w, height: F.h }).then(function (c) { host.remove(); cb(c); }, function (e) { host.remove(); note('Export impossible : ' + (e && e.message || e), 'error', 8000); });
      }, 120);
    };
    if (!n) return go();
    imgs.forEach(function (im) { var f = function () { if (--n === 0) go(); }; if (im.complete) f(); else { im.onload = f; im.onerror = f; } });
  }
  function fname() { return (ST.name || 'affiche').replace(/[\\/:*?"<>|]+/g, '-').trim() || 'affiche'; }
  function exportPng() { render(function (c) { c.toBlob(function (b) { if (b) { download(b, fname() + '.png'); note('✓ Image enregistrée.', 'ok'); } }, 'image/png'); }); }
  function exportPdf() {
    var J = w.jspdf && w.jspdf.jsPDF; if (!J) { note('Export PDF impossible : le moteur PDF n’est pas chargé.', 'error', 7000); return; }
    render(function (c) {
      var F = FMT[ST.fmt], mm = F.mm || [Math.round(F.w * 0.2646), Math.round(F.h * 0.2646)];
      var pdf = new J({ orientation: mm[0] > mm[1] ? 'l' : 'p', unit: 'mm', format: mm, compress: true });
      pdf.addImage(c.toDataURL('image/jpeg', 0.93), 'JPEG', 0, 0, mm[0], mm[1]);
      download(pdf.output('blob'), fname() + '.pdf'); note('✓ PDF enregistré.', 'ok');
    });
  }

  /* ---------- interface ---------- */
  function ui() {
    css('exbsCss',
      '.exbs-tabs{display:flex;gap:8px;margin:0 0 12px;flex-wrap:wrap}.exbs-tabs button{padding:11px 16px;border-radius:999px;border:1px solid #c9d3df;background:#fff;color:#12305e;font:700 14px Arial,sans-serif;cursor:pointer}.exbs-tabs button.on{background:#12305e;color:#fff;border-color:#12305e}' +
      '#exbsRoot{display:none}#exbsRoot.on{display:block}.exbs-grid{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:14px;align-items:start}@media(max-width:980px){.exbs-grid{grid-template-columns:1fr}}' +
      '.exbs-card{background:#fff;border:1px solid #dbe3ee;border-radius:14px;padding:12px;color:#172033}.exbs-card h3{margin:0 0 8px;font-size:15px;color:#12305e}' +
      '.exbs-bar{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}.exbs-bar button,.exbs-btns button,.exbs-mini,.exbs-it button{padding:9px 12px;border-radius:9px;border:1px solid #c9d3df;background:#f4f7fb;color:#12305e;font:700 13px Arial,sans-serif;cursor:pointer}' +
      '.exbs-bar button.p{background:#12305e;color:#fff;border-color:#12305e}.exbs-bar button.g{background:#c9a227;color:#12254a;border-color:#c9a227}.exbs-btns{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.exbs-btns button.on{background:#12305e;color:#fff}.exbs-btns button.del,.exbs-it button.del{color:#b91c1c}' +
      '.exbs-in{width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial,sans-serif;background:#fff;color:#172033}input[type=color].exbs-in{padding:2px;height:38px}.exbs-2{display:grid;grid-template-columns:1fr 1fr;gap:8px}' +
      '.exbs-l{display:block;font:700 12px Arial,sans-serif;color:#12305e;margin:8px 0 3px}.exbs-t{display:block;color:#12305e;margin-bottom:6px}.exbs-hint{font-size:12.5px;color:#5e6877;margin:6px 0}' +
      '#exbsBox{background:#dfe4ec;border-radius:12px;padding:10px;overflow:auto;display:flex;justify-content:center}#exbsWrap{position:relative;box-shadow:0 4px 18px #0004;background:#fff;flex:none}#exbsStage{transform-origin:top left;user-select:none;-webkit-user-select:none}' +
      '.exbs-pal{display:flex;gap:8px;flex-wrap:wrap}.exbs-pal button{width:40px;height:40px;border-radius:10px;border:2px solid #fff;box-shadow:0 0 0 1px #c9d3df;cursor:pointer}' +
      '.exbs-it{display:flex;gap:6px;align-items:center;border-top:1px solid #e3e9f2;padding:7px 0}.exbs-it div{flex:1;min-width:0}.exbs-it b{display:block;font-size:13px;color:#12305e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.exbs-it span{font-size:11px;color:#6b7a99}' +
      '@media print{#exbsRoot,.exbs-tabs{display:none!important}}');
    var sec = $('affiches'); if (!sec || $('exbsRoot')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    var tabs = d.createElement('div'); tabs.className = 'exbs-tabs no-print';
    tabs.innerHTML = '<button id="exbsT1" class="on">🖼️ Affiches Excellencia</button><button id="exbsT2">🎨 Studio libre (autres contenus)</button>';
    sec.insertBefore(tabs, grid);
    root = d.createElement('div'); root.id = 'exbsRoot'; root.className = 'no-print';
    root.innerHTML =
      '<div class="exbs-card" style="margin-bottom:12px"><h3>🎨 Studio libre — créez une affiche sur n’importe quel sujet</h3>' +
      '<p class="exbs-hint" style="margin-top:0">Choisissez un modèle ou partez d’une page vide, ajoutez vos textes, photos et formes, déplacez-les du doigt ou à la souris, puis exportez en image ou en PDF.</p>' +
      '<div class="exbs-2"><div><label class="exbs-l">Nom de l’affiche</label><input id="exbsName" class="exbs-in" value="Mon affiche"></div><div><label class="exbs-l">Format</label><select id="exbsFmt" class="exbs-in">' + Object.keys(FMT).map(function (k) { return '<option value="' + k + '">' + FMT[k].l + '</option>'; }).join('') + '</select></div></div>' +
      '<label class="exbs-l">Modèle de départ (' + Object.keys(TPL).length + ' modèles)</label><select id="exbsTpl" class="exbs-in"><option value="">— Choisir un modèle —</option>' + tplOptions() + '</select></div>' +
      '<div class="exbs-grid"><div class="exbs-card"><div class="exbs-bar"><button id="ad_t">＋ Texte</button><button id="ad_i">＋ Photo</button><button id="ad_l">＋ Logo</button><button id="ad_q" title="QR code qui ouvre notre site vitrine">＋ QR site</button><button id="ad_qo" title="Affiche contenant seulement un QR code">🔳 Affiche QR seul</button><button id="ad_qd" title="Télécharger le QR code seul">⬇ QR seul (PNG)</button><button id="ad_fm" title="Choisir vos dimensions">📐 Format libre</button><button id="ad_r">▭ Rectangle</button><button id="ad_e">◯ Cercle</button><button id="ad_ln">▬ Trait</button><button id="ad_u">↶ Annuler</button></div>' +
      '<div id="exbsBox"><div id="exbsWrap"><div id="exbsStage"></div></div></div><div class="exbs-hint" id="exbsFmtLbl" style="text-align:center"></div>' +
      '<div class="exbs-bar" style="margin-top:8px"><button class="p" id="ex_save">💾 Enregistrer</button><button class="g" id="ex_png">⬇ Image (PNG)</button><button class="g" id="ex_pdf">📄 PDF</button><button id="ex_new">🆕 Nouvelle</button></div></div>' +
      '<div><div class="exbs-card" id="exbsPropsCard"><h3>Modifier</h3><div id="exbsProps"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Fond</h3><div id="exbsBg"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Contour</h3><p class="exbs-hint" style="margin-top:0">Cadre comme sur la page de garde des devis : à mettre ou à retirer.</p><div id="exbsFr"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Mes affiches</h3><div id="exbsMine"></div></div></div></div>';
    sec.appendChild(root);
    $('exbsT1').onclick = function () { grid.style.display = ''; root.classList.remove('on'); $('exbsT1').classList.add('on'); $('exbsT2').classList.remove('on'); setTimeout(function () { w.exbFitPosters && w.exbFitPosters(); }, 50); };
    $('exbsT2').onclick = function () { grid.style.display = 'none'; root.classList.add('on'); $('exbsT2').classList.add('on'); $('exbsT1').classList.remove('on'); setTimeout(function () { fit(); refresh(true); }, 30); };
    $('exbsFmt').onchange = function () { setFmt(this.value); };
    $('exbsName').oninput = function () { ST.name = this.value; };
    $('exbsTpl').onchange = async function () { if (this.value) { if (ST.els.length && !(await exbConfirm('Remplacer le contenu actuel par ce modèle ?'))) { this.value = ''; return; } applyTpl(this.value); this.value = ''; } };
    $('ad_t').onclick = function () { addText('Votre texte ici', {}); };
    $('ad_i').onclick = function () { pickImage(function (u) { var F = FMT[ST.fmt]; add({ t: 'img', src: u, x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.3), w: Math.round(F.w * 0.8), h: Math.round(F.w * 0.5), fit: 'cover', op: 1, rot: 0, rad: 0 }); }); };
    $('ad_q').onclick = function () { var F0 = FMT[ST.fmt], e = qrEl(F0, Math.round(F0.w * 0.17)), top = F0.h; ST.els.forEach(function (r) { if (r.t === 'rect' && r.w >= F0.w * 0.8 && r.y > F0.h * 0.6 && r.y < top) top = r.y; }); if (e) { e.y = top - e.h - Math.round(F0.w * 0.02); e.x = F0.w - e.w - Math.round(F0.w * 0.05); } if (!e) { note('QR indisponible : générateur non chargé.', 'error', 5000); return; } add(e); note('✓ QR du site vitrine ajouté en bas : ' + vitrineUrl(), 'ok', 5000); };
    $('ad_qo').onclick = async function () { var u = String(await exbPrompt('Adresse que le QR doit ouvrir (par défaut : votre site vitrine) :', vitrineUrl()) || '').trim(); if (!u) return; if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
      var F = FMT[ST.fmt], qs = Math.round(Math.min(F.w * 0.7, F.h * 0.55)), e = qrEl(F, qs, Math.round((F.h - qs) / 2), u); if (!e) { note('QR indisponible.', 'error', 5000); return; }
      push(); ST.bg = { c1: '#ffffff', c2: '#ffffff', ang: 180, img: '', ovl: 0 }; e.id = uid(); e.fx = 0;
      ST.els = [{ t: 'text', tx: 'SCANNEZ-MOI', x: Math.round(F.w * 0.05), y: Math.round((F.h - qs) / 2 - F.h * 0.12), w: Math.round(F.w * 0.9), h: Math.round(F.h * 0.08), fs: Math.round(Math.min(F.w, F.h) * 0.08), col: '#12305e', b: true, al: 'center', ff: 1, lh: 1.1, id: uid(), op: 1, rot: 0 }, e,
        { t: 'text', tx: u.replace(/^https?:\/\//i, '').replace(/\/$/, ''), x: Math.round(F.w * 0.05), y: Math.round((F.h + qs) / 2 + F.h * 0.02), w: Math.round(F.w * 0.9), h: Math.round(F.h * 0.06), fs: Math.round(Math.min(F.w, F.h) * 0.035), col: '#5e6877', b: true, al: 'center', ff: 0, lh: 1.2, id: uid(), op: 1, rot: 0 }];
      sel = null; refresh(); note('✓ Affiche QR créée. Vous pouvez encore ajouter un logo ou un texte.', 'ok', 4500); };
    $('ad_qd').onclick = async function () { var u = String(await exbPrompt('Adresse que le QR doit ouvrir (par défaut : votre site vitrine) :', vitrineUrl()) || '').trim(); if (!u) return; if (!/^https?:\/\//i.test(u)) u = 'https://' + u; var s = qrSrc(u); if (!s) { note('QR indisponible.', 'error', 5000); return; }
      fetch(s).then(function (r) { return r.blob(); }).then(function (b) { download(b, 'QR-site-vitrine.png'); note('✓ QR enregistré (PNG).', 'ok'); }); };
    $('ad_fm').onclick = async function () { var v = String(await exbPrompt('Dimensions en cm : largeur x hauteur (ex. 60x90) :', '60x90') || '').toLowerCase().replace(/,/g, '.').match(/([\d.]+)\s*[x×*]\s*([\d.]+)/); if (!v) return; var cw = parseFloat(v[1]), ch = parseFloat(v[2]); if (!(cw >= 3 && ch >= 3 && cw <= 600 && ch <= 600)) { note('Dimensions invalides (3 à 600 cm).', 'error', 5000); return; }
      var f = Math.min(1, 3000 / Math.max(cw * 37.8, ch * 37.8)), pw = Math.round(cw * 37.8 * f), ph = Math.round(ch * 37.8 * f), key = 'p' + Date.now().toString(36);
      FMT[key] = { l: 'Format libre ' + cw + ' × ' + ch + ' cm', w: pw, h: ph, mm: [Math.round(cw * 10), Math.round(ch * 10)], sc: Math.max(0.5, Math.min(3, 3000 / Math.max(pw, ph))), custom: 1 };
      var sl = $('exbsFmt'); if (sl) { var o = d.createElement('option'); o.value = key; o.textContent = FMT[key].l; sl.appendChild(o); sl.value = key; }
      setFmt(key); ST.fdef = FMT[key]; };
    $('ad_l').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'img', src: logoSrcForStudio(), x: Math.round(F.w * 0.06), y: Math.round(F.h * 0.04), w: Math.round(F.w * 0.2), h: Math.round(F.w * 0.2), fit: 'contain', op: 1, rot: 0, rad: 0 }); };
    $('ad_r').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'rect', x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.4), w: Math.round(F.w * 0.8), h: Math.round(F.h * 0.12), fill: '#c9a227', stroke: '#ffffff', sw: 0, rad: 16, op: 1, rot: 0 }); };
    $('ad_e').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'ellipse', x: Math.round(F.w * 0.3), y: Math.round(F.h * 0.4), w: Math.round(F.w * 0.4), h: Math.round(F.w * 0.4), fill: '#ffffff', stroke: '#12305e', sw: 0, op: 1, rot: 0 }); };
    $('ad_ln').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'line', x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.5), w: Math.round(F.w * 0.8), h: 8, fill: '#f2c94c', op: 1, rot: 0 }); };
    $('ad_u').onclick = undo;
    $('ex_save').onclick = saveCur; $('ex_png').onclick = exportPng; $('ex_pdf').onclick = exportPdf;
    $('ex_new').onclick = async function () { if (ST.els.length && !(await exbConfirm('Commencer une nouvelle affiche ? (pensez à enregistrer l’actuelle)'))) return; ST = { id: null, name: 'Mon affiche', fmt: ST.fmt, bg: { c1: '#0f2a56', c2: '#1e5fb4', ang: 160, img: '', ovl: 0 }, els: [], frame: ST.frame || { on: false } }; sel = null; hist = []; $('exbsName').value = ST.name; bgPanel(); refresh(); };
    d.addEventListener('keydown', function (ev) {
      if (!root.classList.contains('on')) return; var t = ev.target && ev.target.tagName; if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return;
      var e = find(sel); if (!e) return;
      if (ev.key === 'Delete' || ev.key === 'Backspace') { push(); ST.els.splice(ST.els.indexOf(e), 1); sel = null; refresh(); ev.preventDefault(); }
      var st = ev.shiftKey ? 20 : 4, mv = { ArrowLeft: [-st, 0], ArrowRight: [st, 0], ArrowUp: [0, -st], ArrowDown: [0, st] }[ev.key];
      if (mv) { e.x += mv[0]; e.y += mv[1]; refresh(true); ev.preventDefault(); }
    });
    w.addEventListener('resize', function () { if (root.classList.contains('on')) { fit(); build($('exbsStage'), true); } });
    bindDrag(); bgPanel(); framePn(); mine(); props();
  }

  function start() {
    try { logoCard(); } catch (e) { try { console.error('logo affiches', e); } catch (x) {} }
    try { ui(); } catch (e) { try { console.error('studio affiches', e); } catch (x) {} }
    wrapRender(); applyAll();
  }
  d.addEventListener('exb-images-ready', function () { cache = {}; tries = { poster: 0, software: 0 }; setTimeout(applyAll, 60); });
  w.EXB_STUDIO = { version: 'V99-studio-2', applyLogo: applyAll, state: function () { return ST; }, templates: function () { return Object.keys(TPL); }, applyTemplate: function (k) { applyTpl(k); } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(start, 0); }); else setTimeout(start, 0);
  /* la section peut être construite plus tard : nouvel essai discret */
  var n = 0, iv = setInterval(function () { if ($('exbsRoot') && $('exbLogoCard')) { clearInterval(iv); return; } if (++n > 40) { clearInterval(iv); return; } try { logoCard(); ui(); wrapRender(); } catch (e) {} }, 1500);
})(window, document);
