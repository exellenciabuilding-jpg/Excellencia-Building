/* Excellencia Building — Accueil : widgets Horloge + Météo (V119g)
 * Deux cartes en haut du tableau de bord, sous le bandeau de bienvenue :
 *   🕘 Horloge analogique : les aiguilles tournent en temps réel (heure de l'appareil), date du jour, température actuelle.
 *   ⛅ Météo : ville, température, conditions, min / max du jour, selon la position de l'appareil.
 * Position : GPS de l'appareil (navigator.geolocation) → à défaut, position approximative par l'adresse IP → à défaut, Kinshasa.
 * Appui sur la météo : « Ma position (GPS) » ou choix manuel d'une ville (mémorisé). Le choix manuel peut être annulé à tout moment.
 * Données : Open-Meteo (sans clé), nom de lieu BigDataCloud, position par IP GeoJS. Dernière météo gardée en mémoire : affichée hors connexion.
 * Aucune donnée existante n'est modifiée. Pour retirer : supprimer la balise <script src="exb-home-widgets.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_HOME_WIDGETS) return;
  var K_CACHE = 'exb_wx_cache', K_PLACE = 'exb_wx_place';          /* place : {mode:'auto'} | {mode:'manual', name, lat, lon} */
  var DEFAULT = { name: 'Kinshasa', lat: -4.3276, lon: 15.3136 };
  var REFRESH_MS = 15 * 60 * 1000, STALE_MS = 3 * 60 * 60 * 1000;
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jget(k, df) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? df : v; } catch (e) { return df; } }
  function jset(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  /* ---------- codes météo WMO (Open-Meteo) → libellé + icône + ambiance ---------- */
  function wmo(code, day) {
    var c = Number(code), t;
    if (c === 0) t = [day ? 'Ensoleillé' : 'Ciel dégagé', day ? '☀️' : '🌙', day ? 'clear' : 'night'];
    else if (c === 1) t = [day ? 'Plutôt ensoleillé' : 'Plutôt dégagé', day ? '🌤️' : '🌙', day ? 'clear' : 'night'];
    else if (c === 2) t = ['Partiellement nuageux', day ? '⛅' : '☁️', 'cloud'];
    else if (c === 3) t = ['Couvert', '☁️', 'cloud'];
    else if (c === 45 || c === 48) t = ['Brouillard', '🌫️', 'cloud'];
    else if (c >= 51 && c <= 57) t = ['Bruine', '🌦️', 'rain'];
    else if (c === 61 || c === 80) t = ['Pluie légère', '🌦️', 'rain'];
    else if (c === 63 || c === 81 || c === 66) t = ['Pluie', '🌧️', 'rain'];
    else if (c === 65 || c === 82 || c === 67) t = ['Pluie forte', '🌧️', 'rain'];
    else if (c >= 71 && c <= 77 || c === 85 || c === 86) t = ['Neige', '🌨️', 'cloud'];
    else if (c >= 95 && c <= 99) t = ['Orage', '⛈️', 'storm'];
    else t = ['Variable', '🌥️', 'cloud'];
    return { label: t[0], icon: t[1], mood: t[2] };
  }
  function deg(v) { return v == null || !isFinite(v) ? '–' : Math.round(v) + '°'; }

  /* ---------- angles des aiguilles (pures, testables) ---------- */
  function angles(dt) {
    var s = dt.getSeconds() + dt.getMilliseconds() / 1000, m = dt.getMinutes() + s / 60, h = (dt.getHours() % 12) + m / 60;
    return { h: h * 30, m: m * 6, s: s * 6 };
  }

  /* ---------- état ---------- */
  var wx = jget(K_CACHE, null);   /* {name, lat, lon, temp, code, day, min, max, at} */
  var busy = false, panel = false, lastNote = '', timerWx = 0;
  function place() { var p = jget(K_PLACE, null); return p && p.mode === 'manual' && isFinite(p.lat) && isFinite(p.lon) ? p : { mode: 'auto' }; }

  /* ---------- réseau ---------- */
  function jfetch(url, ms) {
    return new Promise(function (ok, ko) {
      var done = false, ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      var to = setTimeout(function () { if (!done) { done = true; if (ctl) ctl.abort(); ko(new Error('délai dépassé')); } }, ms || 9000);
      w.fetch(url, ctl ? { signal: ctl.signal } : {}).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (j) { if (!done) { done = true; clearTimeout(to); ok(j); } }, function (e) { if (!done) { done = true; clearTimeout(to); ko(e); } });
    });
  }
  function gps() {
    return new Promise(function (ok, ko) {
      if (!w.navigator || !w.navigator.geolocation) return ko(new Error('GPS indisponible'));
      w.navigator.geolocation.getCurrentPosition(function (p) { ok({ lat: p.coords.latitude, lon: p.coords.longitude, src: 'gps' }); },
        function (e) { ko(new Error(e && e.code === 1 ? 'GPS refusé' : 'GPS indisponible')); }, { enableHighAccuracy: false, timeout: 9000, maximumAge: 10 * 60 * 1000 });
    });
  }
  function byIp() {
    return jfetch('https://get.geojs.io/v1/ip/geo.json', 7000).then(function (j) {
      var la = parseFloat(j.latitude), lo = parseFloat(j.longitude);
      if (!isFinite(la) || !isFinite(lo)) throw new Error('IP sans position');
      return { lat: la, lon: lo, src: 'ip', name: j.city || '' };
    });
  }
  function placeName(lat, lon) {
    return jfetch('https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=' + lat + '&longitude=' + lon + '&localityLanguage=fr', 7000).then(function (j) {
      return String(j.city || j.locality || j.principalSubdivision || '').trim();
    });
  }
  function forecast(lat, lon) {
    var u = 'https://api.open-meteo.com/v1/forecast?latitude=' + lat.toFixed(4) + '&longitude=' + lon.toFixed(4) +
      '&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1';
    return jfetch(u, 10000).then(function (j) {
      if (!j || !j.current) throw new Error('réponse météo vide');
      return { temp: j.current.temperature_2m, code: j.current.weather_code, day: j.current.is_day !== 0,
        min: j.daily && j.daily.temperature_2m_min ? j.daily.temperature_2m_min[0] : null, max: j.daily && j.daily.temperature_2m_max ? j.daily.temperature_2m_max[0] : null };
    });
  }
  function locate() {
    var p = place();
    if (p.mode === 'manual') return Promise.resolve({ lat: p.lat, lon: p.lon, name: p.name, src: 'manuel' });
    return gps().catch(function (e) { lastNote = e.message; return byIp(); }).catch(function () { lastNote = (lastNote ? lastNote + ' · ' : '') + 'position approximative indisponible'; return { lat: DEFAULT.lat, lon: DEFAULT.lon, name: DEFAULT.name, src: 'défaut' }; });
  }

  var failAt = 0;
  function refresh(force) {
    if (busy) return Promise.resolve();
    if (!force && wx && Date.now() - wx.at < REFRESH_MS && sameTarget()) { paint(); return Promise.resolve(); }
    if (!force && failAt && Date.now() - failAt < 10 * 60 * 1000) { paint(); return Promise.resolve(); } /* V144e : après un échec réseau, pas de nouvel essai avant 10 min */
    if (w.navigator && w.navigator.onLine === false) { paint(); return Promise.resolve(); }
    busy = true; paint();
    return locate().then(function (loc) {
      var nm = loc.name ? Promise.resolve(loc.name) : placeName(loc.lat, loc.lon).catch(function () { return ''; });
      return Promise.all([forecast(loc.lat, loc.lon), nm]).then(function (r) {
        wx = { name: r[1] || (loc.src === 'gps' ? 'Ma position' : DEFAULT.name), lat: loc.lat, lon: loc.lon, src: loc.src, temp: r[0].temp, code: r[0].code, day: r[0].day, min: r[0].min, max: r[0].max, at: Date.now() };
        failAt = 0; jset(K_CACHE, wx); if (loc.src === 'gps' || loc.src === 'manuel') lastNote = '';
      });
    }).catch(function (e) { failAt = Date.now(); lastNote = 'Hors connexion' + (wx ? ' · dernière mise à jour ' + hhmm(wx.at) : ''); }).then(function () { busy = false; paint(); });
  }
  function sameTarget() { var p = place(); return !(p.mode === 'manual') || (wx && Math.abs(wx.lat - p.lat) < 0.01 && Math.abs(wx.lon - p.lon) < 0.01); }
  function hhmm(t) { var x = new Date(t); return pad(x.getHours()) + ':' + pad(x.getMinutes()); }

  /* ---------- horloge ---------- */
  function ticks() {
    var s = '', i, a, big, x1, y1, x2, y2, r2;
    for (i = 0; i < 60; i++) {
      big = i % 5 === 0; a = i * 6 * Math.PI / 180; r2 = big ? 86 : 91;
      x1 = 100 + Math.sin(a) * 96; y1 = 100 - Math.cos(a) * 96; x2 = 100 + Math.sin(a) * r2; y2 = 100 - Math.cos(a) * r2;
      s += '<line x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '" stroke="' + (big ? '#1b2540' : '#9aa6bd') + '" stroke-width="' + (big ? 2.4 : 1) + '" stroke-linecap="round"/>';
    }
    for (i = 1; i <= 12; i++) { a = i * 30 * Math.PI / 180; s += '<text x="' + (100 + Math.sin(a) * 71).toFixed(1) + '" y="' + (100 - Math.cos(a) * 71 + 6).toFixed(1) + '" text-anchor="middle" font-size="17" font-weight="700" fill="#1b2540" font-family="Arial,Helvetica,sans-serif">' + i + '</text>'; }
    return s;
  }
  function clockHtml() {
    return '<div class="hw-clock" role="img" id="hwClockImg" aria-label="Horloge">' +
      '<svg viewBox="0 0 200 200" aria-hidden="true"><circle cx="100" cy="100" r="99" fill="#fbfaf6"/>' + ticks() +
      '<g id="hwDate"><rect x="38" y="91" width="50" height="18" rx="9" fill="#e4e1d6"/><text id="hwDateT" x="63" y="103.5" text-anchor="middle" font-size="10.5" font-weight="700" fill="#4a4f5e" font-family="Arial,Helvetica,sans-serif"></text></g>' +
      '<text id="hwClockWx" x="100" y="146" text-anchor="middle" font-size="13" font-weight="700" fill="#4a4f5e" font-family="Arial,Helvetica,sans-serif"></text>' +
      '<g id="hwH"><line x1="100" y1="106" x2="100" y2="56" stroke="#1b2540" stroke-width="6" stroke-linecap="round"/></g>' +
      '<g id="hwM"><line x1="100" y1="110" x2="100" y2="30" stroke="#1b2540" stroke-width="4.2" stroke-linecap="round"/></g>' +
      '<g id="hwS"><line x1="100" y1="118" x2="100" y2="22" stroke="#f26b1d" stroke-width="2" stroke-linecap="round"/></g>' +
      '<circle cx="100" cy="100" r="5" fill="#f26b1d"/><circle cx="100" cy="100" r="2" fill="#fbfaf6"/></svg></div>';
  }
  var lastMin = -1, lastDay = -1;
  var JOURS = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  var MOIS_L = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  function greet(dt) { var h = dt.getHours(); return h >= 18 || h < 4 ? 'Bonsoir' : 'Bonjour'; }
  function userName() { var n = $('xbName'); var t = n ? String(n.textContent || '').trim() : ''; return t; }
  function tick() {
    var dt = new Date(), a = angles(dt), h = $('hwH'), m = $('hwM'), s = $('hwS');
    if (!h || !m || !s) return;
    h.setAttribute('transform', 'rotate(' + a.h.toFixed(2) + ' 100 100)');
    m.setAttribute('transform', 'rotate(' + a.m.toFixed(2) + ' 100 100)');
    s.setAttribute('transform', 'rotate(' + a.s.toFixed(2) + ' 100 100)');
    if (dt.getMinutes() !== lastMin) {
      lastMin = dt.getMinutes();
      var im = $('hwClockImg'); if (im) im.setAttribute('aria-label', 'Il est ' + dt.getHours() + ' h ' + pad(lastMin));
      var tm = $('hwTime'); if (tm) tm.textContent = pad(dt.getHours()) + ':' + pad(lastMin);
      var hi = $('hwHello'), nm = userName(); if (hi) hi.textContent = greet(dt) + (nm ? ', ' + nm : '');
    }
    if (dt.getDate() !== lastDay) {
      lastDay = dt.getDate(); var t = $('hwDateT');
      if (t) { var mo = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'][dt.getMonth()]; t.textContent = dt.getDate() + ' ' + mo; }
      var dd = $('hwDay'); if (dd) dd.textContent = JOURS[dt.getDay()] + ' ' + dt.getDate() + ' ' + MOIS_L[dt.getMonth()];
    }
  }

  /* ---------- météo : peinture ---------- */
  function paint() {
    var box = $('exbHomeWidgets'); if (!box) return;
    var cw = $('hwClockWx'); if (cw) cw.textContent = wx ? deg(wx.temp) : '';
    var card = $('hwWx'); if (!card) return;
    if (panel && d.activeElement && d.activeElement.id === 'hwQ') return;   /* ne reconstruit pas pendant la saisie */
    var info = wx ? wmo(wx.code, wx.day) : null, stale = wx && Date.now() - wx.at > STALE_MS;
    card.className = 'hw-wx hw-' + (info ? info.mood : 'cloud');
    var h;
    card.classList.toggle('hw-pop', !!panel);
    if (panel) h = panelHtml();
    else if (wx) {
      h = '<div class="hw-r1"><span class="hw-city">' + (wx.src === 'gps' ? '📍 ' : '') + esc(wx.name) + '</span><span class="hw-mm">' + deg(wx.min) + ' / ' + deg(wx.max) + '</span></div>' +
        '<div class="hw-r2"><span class="hw-temp">' + deg(wx.temp) + '</span><span class="hw-ic">' + info.icon + '</span><span class="hw-cond">' + esc(info.label) + '</span></div>' +
        (busy ? '<div class="hw-note">Actualisation…</div>' : (lastNote || stale) ? '<div class="hw-note">' + esc(lastNote || ('Données de ' + hhmm(wx.at))) + '</div>' : '');
    } else h = '<div class="hw-city">Météo</div><div class="hw-cond" style="margin-top:6px">' + (busy ? 'Recherche de votre position…' : esc(lastNote || 'Appuyez pour choisir une ville')) + '</div>';
    card.innerHTML = h;
  }
  function panelHtml() {
    var p = place();
    return '<div class="hw-city">Position de la météo</div>' +
      '<button class="hw-b' + (p.mode === 'auto' ? ' on' : '') + '" data-hw="gps">📍 Ma position (GPS)</button>' +
      '<div class="hw-search"><input id="hwQ" type="search" placeholder="Autre ville…" autocomplete="off" aria-label="Rechercher une ville"><button class="hw-b" data-hw="find">OK</button></div>' +
      '<div id="hwRes"></div>' + (p.mode === 'manual' ? '<div class="hw-note">Ville fixée : ' + esc(p.name) + '</div>' : '') +
      '<button class="hw-x" data-hw="close">Fermer</button>';
  }
  function search() {
    var q = ($('hwQ') || {}).value || '', res = $('hwRes'); q = q.trim(); if (!res || q.length < 2) return;
    res.innerHTML = '<div class="hw-note">Recherche…</div>';
    jfetch('https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(q) + '&count=5&language=fr&format=json', 8000).then(function (j) {
      var r = (j && j.results) || [];
      if (!r.length) { res.innerHTML = '<div class="hw-note">Aucune ville trouvée</div>'; return; }
      res.innerHTML = r.map(function (c, i) { return '<button class="hw-b" data-hw="pick" data-i="' + i + '">' + esc(c.name) + (c.admin1 ? ', ' + esc(c.admin1) : '') + ' <small>' + esc(c.country_code || '') + '</small></button>'; }).join('');
      res._r = r;
    }, function () { res.innerHTML = '<div class="hw-note">Recherche impossible (hors connexion ?)</div>'; });
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-hw]') : null, card = $('hwWx');
    if (!b) { if (card && card.contains(e.target) && !panel) { panel = true; paint(); } return; }
    var a = b.getAttribute('data-hw');
    if (a === 'close') { panel = false; paint(); }
    else if (a === 'gps') { jset(K_PLACE, { mode: 'auto' }); lastNote = ''; panel = false; wx = null; refresh(true); }
    else if (a === 'find') search();
    else if (a === 'pick') {
      var c = ($('hwRes') || {})._r; c = c && c[Number(b.getAttribute('data-i'))]; if (!c) return;
      jset(K_PLACE, { mode: 'manual', name: c.name, lat: c.latitude, lon: c.longitude }); lastNote = ''; panel = false; wx = null; refresh(true);
    }
  }

  /* ---------- installation ---------- */
  function css() {
    if ($('exbHomeWidgetsCss')) return;
    var s = d.createElement('style'); s.id = 'exbHomeWidgetsCss';
    s.textContent =
      /* panneau horloge + date + météo, intégré au bandeau de bienvenue (même principe que le bandeau « Excellencia Chantier ») */
      '#exbHomeWidgets{position:relative;display:flex;align-items:center;gap:16px;box-sizing:border-box;margin:16px 0;padding:14px 18px;border-radius:16px;background:#071634b8;border:1px solid #ffffff22;box-shadow:0 6px 18px #0004;color:#fff;font-family:Arial,Helvetica,sans-serif;z-index:2;min-width:0;align-self:center}' +
      '#exbHomeWidgets .hw-cw{flex:none;display:flex;align-items:center;justify-content:center;background:none;padding:0}' +
      '.hw-clock{width:108px;height:108px;flex:none}.hw-clock svg{width:100%;height:100%;display:block;border-radius:50%;box-shadow:0 2px 8px #0007}' +
      '.hw-info{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}' +
      '.hw-hello{font-size:12px;font-weight:600;opacity:.8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
      '.hw-time{font-size:36px;font-weight:800;line-height:1.05;letter-spacing:.5px;font-variant-numeric:tabular-nums}' +
      '.hw-day{font-size:13px;font-weight:600;opacity:.92;margin-bottom:6px;white-space:nowrap}' +
      '.hw-wx{border-radius:12px;padding:7px 10px;color:#fff;cursor:pointer;display:flex;flex-direction:column;gap:1px;text-align:left;border:1px solid #ffffff2e}' +
      '.hw-wx:hover{filter:brightness(1.1)}' +
      '.hw-clear{background:linear-gradient(160deg,#2f8be0,#1a5bb0)}.hw-night{background:linear-gradient(160deg,#1c2a4d,#0d1630)}' +
      '.hw-cloud{background:linear-gradient(160deg,#6d86a8,#475c7c)}.hw-rain{background:linear-gradient(160deg,#6f86a1,#4a6079)}.hw-storm{background:linear-gradient(160deg,#4a4f6b,#2a2d44)}' +
      '.hw-r1{display:flex;justify-content:space-between;gap:8px;align-items:baseline}' +
      '.hw-r2{display:flex;align-items:center;gap:6px}' +
      '.hw-city{font-size:12px;font-weight:700;opacity:.92;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
      '.hw-temp{font-size:22px;font-weight:700;line-height:1.1}.hw-ic{font-size:17px}' +
      '.hw-cond{font-size:12.5px;font-weight:600}.hw-mm{font-size:11.5px;opacity:.85;white-space:nowrap}' +
      '.hw-note{font-size:10.5px;opacity:.85;margin-top:2px}' +
      '.hw-pop{position:absolute;inset:6px;z-index:6;background:#12254a;border:1px solid #ffffff44;box-shadow:0 10px 28px #000a;overflow:auto;cursor:default;padding:10px 12px}' +
      '.hw-b{display:block;width:100%;min-height:32px;margin-top:5px;padding:5px 10px;border:1px solid #ffffff66;border-radius:10px;background:#ffffff26;color:#fff;font:700 13px Arial;text-align:left;cursor:pointer}' +
      '.hw-b.on{background:#ffffff59}.hw-b small{opacity:.8}.hw-b:focus-visible,.hw-x:focus-visible,#hwQ:focus-visible{outline:2px solid #fff;outline-offset:2px}' +
      '.hw-search{display:flex;gap:6px;margin-top:5px}.hw-search .hw-b{width:auto;margin:0;text-align:center}' +
      '#hwQ{flex:1;min-width:0;min-height:32px;border:0;border-radius:10px;padding:0 10px;font:14px Arial;color:#12254a}' +
      '.hw-x{margin-top:6px;border:0;background:none;color:#fff;font:700 12px Arial;text-decoration:underline;cursor:pointer;align-self:flex-start;padding:4px 0}' +
      /* bandeau compact : texte | horloge-météo | photo (au lieu d’une photo plein écran) */
      '.xh-hero.xh-compact{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(310px,.95fr) minmax(0,.8fr);column-gap:8px;min-height:0;height:auto;align-items:stretch;margin-bottom:14px}' +
      '.xh-hero.xh-compact .xh-hl{background:none!important;padding:22px 8px 22px 26px;display:flex;flex-direction:column;justify-content:center}' +
      '.xh-hero.xh-compact .xh-hl small{font-size:14px;opacity:.9}' +
      '.xh-hero.xh-compact .xh-hl h2{font-size:26px;margin:2px 0 6px}' +
      '.xh-hero.xh-compact .xh-hl p{font-size:13.5px;margin:0 0 12px;max-width:380px;line-height:1.4}' +
      '.xh-hero.xh-compact .xh-btn{align-self:flex-start;padding:9px 16px}' +
      '.xh-hero.xh-compact .xh-img{inset:0 0 0 auto;width:31%;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 34%);mask-image:linear-gradient(90deg,transparent 0,#000 34%)}' +
      '.xh-hero.xh-compact .xh-tag{right:18px;bottom:12px;max-width:34%;font-size:13px;line-height:1.3}' +
      '.xh-hero.xh-compact .xh-cam{top:10px;bottom:auto;right:10px;padding:6px 10px;font-size:11.5px}' +
      '@media(max-width:1180px){.xh-hero.xh-compact .xh-cam{top:auto;bottom:10px}.xh-hero.xh-compact{grid-template-columns:minmax(0,1fr) minmax(300px,auto)}.xh-hero.xh-compact .xh-img{width:100%;-webkit-mask-image:linear-gradient(90deg,transparent 0,#000 0);mask-image:none;opacity:.28}.xh-hero.xh-compact .xh-tag{display:none}}' +
      '@media(max-width:900px){.xh-hero.xh-compact{display:flex;flex-direction:column}#exbHomeWidgets{margin:0 16px 16px;align-self:stretch}.xh-hero.xh-compact .xh-cam{top:auto;bottom:10px}.xh-hero.xh-compact .xh-hl{padding:20px 20px 12px}.xh-hero.xh-compact .xh-img{opacity:.22}}' +
      '@media(max-width:420px){.hw-clock{width:88px;height:88px}.hw-time{font-size:30px}#exbHomeWidgets{padding:12px;gap:12px}}' +
      '@media print{#exbHomeWidgets{display:none}}';
    d.head.appendChild(s);
  }
  var iv = 0;
  function install() {
    var home = $('exbHome'), hero = home && home.querySelector('.xh-hero');
    if (!home || !hero || $('exbHomeWidgets')) return !!$('exbHomeWidgets');
    css();
    hero.classList.add('xh-compact');
    var box = d.createElement('div'); box.id = 'exbHomeWidgets'; box.className = 'no-print';
    box.innerHTML = '<div class="hw-cw">' + clockHtml() + '</div><div class="hw-info"><div class="hw-hello" id="hwHello"></div><div class="hw-time" id="hwTime"></div><div class="hw-day" id="hwDay"></div>' +
      '<div class="hw-wx hw-cloud" id="hwWx" role="button" tabindex="0" aria-label="Météo — appuyer pour changer de position"></div></div>';
    var hl = hero.querySelector('.xh-hl');
    if (hl && hl.nextSibling) hero.insertBefore(box, hl.nextSibling); else hero.appendChild(box);
    box.addEventListener('click', onClick);
    box.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && e.target.id === 'hwWx' && !panel) { e.preventDefault(); panel = true; paint(); } if (e.key === 'Enter' && e.target.id === 'hwQ') search(); });
    lastMin = lastDay = -1; tick(); paint(); refresh(false);
    /* les aiguilles ne tournent que si l'accueil est visible et l'application au premier plan */
    iv = setInterval(function () { if (!d.hidden && home.style.display !== 'none') tick(); }, 250);
    clearInterval(timerWx); timerWx = setInterval(function () { if (!d.hidden) refresh(false); }, 60 * 1000);
    d.addEventListener('visibilitychange', function () { if (!d.hidden) { tick(); refresh(false); } });
    w.addEventListener('online', function () { lastNote = ''; refresh(true); });
    try { new MutationObserver(function () { if (home.style.display !== 'none') { tick(); refresh(false); } }).observe(home, { attributes: true, attributeFilter: ['style'] }); } catch (e) {}
    return true;
  }
  function boot() { var n = 0, t = setInterval(function () { if (install() || ++n > 120) clearInterval(t); }, 500); }
  w.EXB_HOME_WIDGETS = { version: 'V120l', refresh: function () { return refresh(true); }, _wmo: wmo, _angles: angles };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
