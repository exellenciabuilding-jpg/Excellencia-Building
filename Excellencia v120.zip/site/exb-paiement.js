/* Excellencia Building V99g — Paiement Mobile Money déclaratif sur les formulaires publics (apprenant, logiciel, BTP/projet).
 * Les numéros et montants viennent de paiement.json (bucket « vitrine »), publié depuis l'onglet Site vitrine.
 * Le visiteur envoie l'argent lui-même puis déclare son numéro et la référence : l'administrateur vérifie dans son relevé Mobile Money. */
(function(w,d){'use strict';
var P=null,kind=null,CK='EXB_PAY_CFG',TYPES=['apprenant','logiciel','projet'];
function $(i){return d.getElementById(i)}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function load(cb){var u=(w.EXB_SUPABASE&&w.EXB_SUPABASE.url)||'';
  function fb(){try{P=JSON.parse(localStorage.getItem(CK)||'null')}catch(e){P=null}cb()}
  if(!u)return fb();
  fetch(String(u).replace(/\/+$/,'')+'/storage/v1/object/public/vitrine/paiement.json?t='+Date.now(),{cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(j){if(j){P=j;try{localStorage.setItem(CK,JSON.stringify(j))}catch(e){}cb()}else fb()}).catch(fb)}
function conf(){return P&&P.actif&&kind&&P.types&&P.types[kind]&&+P.types[kind].montant>0?P.types[kind]:null}
function sync(){var b=$('exbpay'),t=conf();if(!b)return;if(!t){b.style.display='none';[].forEach.call(b.querySelectorAll('input,select'),function(i){i.required=false});return}
  b.style.display='';var later=$('pay_later')&&$('pay_later').checked;
  $('pay_amt').textContent=t.montant+' '+(P.devise||'USD');
  var rl=$('pay_laterbox');rl.style.display=t.obligatoire?'none':'';if(t.obligatoire&&$('pay_later'))$('pay_later').checked=false;
  var need=!(later&&!t.obligatoire);$('pay_fields').style.display=need?'':'none';
  ['pay_op','pay_num','pay_ref'].forEach(function(i){$(i).required=need})}
function build(){if($('exbpay')||!$('send')||!P||!P.actif)return;
  var cs=(P.comptes||[]).map(function(c){return'<div style="display:flex;gap:8px;align-items:center;margin:6px 0;flex-wrap:wrap"><b>'+esc(c.op)+'</b><span style="font-size:1.1em;letter-spacing:.5px">'+esc(c.num)+'</span><small>'+esc(c.nom||'')+'</small><button type="button" data-copy="'+esc(c.num)+'" style="padding:4px 10px">Copier</button></div>'}).join('');
  var ops=(P.comptes||[]).map(function(c){return c.op}).filter(function(v,i,a){return a.indexOf(v)===i}).concat(['Autre']);
  var h=d.createElement('div');h.id='exbpay';h.style.cssText='display:none;margin:16px 0;padding:14px;border:2px solid #173565;border-radius:12px;background:#f4f7fc';
  h.innerHTML='<h3 style="margin:0 0 6px">💳 Paiement Mobile Money</h3><p style="margin:4px 0">Montant à payer : <b id="pay_amt"></b></p><p style="margin:4px 0">Envoyez l’argent à l’un de ces numéros :</p>'+cs
   +'<div id="pay_laterbox"><label style="display:flex;gap:8px;align-items:center;margin:8px 0"><input type="checkbox" id="pay_later"> Je paierai plus tard</label></div>'
   +'<div id="pay_fields"><p style="margin:8px 0 4px">Après l’envoi, indiquez :</p>'
   +'<label for="pay_op">Réseau utilisé *</label><select id="pay_op">'+ops.map(function(o){return'<option>'+esc(o)+'</option>'}).join('')+'</select>'
   +'<label for="pay_num">Votre numéro qui a envoyé l’argent *</label><input id="pay_num" type="tel" inputmode="tel" placeholder="Ex. 0812345678" maxlength="20">'
   +'<label for="pay_ref">Référence / ID de la transaction *</label><input id="pay_ref" type="text" placeholder="Reçu dans le SMS de confirmation" maxlength="40">'
   +'<p style="font-size:.85em;margin:6px 0 0;opacity:.8">Votre paiement sera vérifié par notre équipe avant validation.</p></div>';
  var s=$('send');s.parentNode.insertBefore(h,s);
  h.addEventListener('click',function(e){var b=e.target.closest('button[data-copy]');if(!b)return;var v=b.getAttribute('data-copy');try{navigator.clipboard.writeText(v);b.textContent='✓ Copié'}catch(x){(window.exbPrompt||window.prompt)('Copiez :',v)}});
  $('pay_later').addEventListener('change',sync);sync()}
/* Type de formulaire actif : lu dans le DOM (le formulaire est choisi par le lien, sans clic) — fieldset actif, sinon bouton .on, sinon ?type= / EXB_FORM_TYPE */
function curKind(){var f=d.querySelector('fieldset[data-k]:not([disabled]):not([hidden])');if(f)return f.getAttribute('data-k');
  var o=d.querySelector('.kind.on[data-k]');if(o)return o.getAttribute('data-k');return null}
function refresh(){var k=curKind();if(!k)return;kind=k;build();sync()}
d.addEventListener('click',function(e){var k=e.target.closest&&e.target.closest('.kind[data-k]');if(!k)return;setTimeout(refresh,0)},true);
function watch(){refresh();try{new MutationObserver(function(){var k=curKind();if(k&&k!==kind)refresh()}).observe(d.body,{subtree:true,attributes:true,attributeFilter:['disabled','hidden','class']})}catch(e){}}
function wrap(){if(!w.EXBForm||w.EXBForm.__pay)return;var os=w.EXBForm.send;w.EXBForm.__pay=true;
  w.EXBForm.send=function(k,data,file){var t=conf(),b=$('exbpay');
    if(t&&b&&b.style.display!=='none'){var note=String(data.note||'').slice(0,760),dev=P.devise||'USD';
      if($('pay_later').checked&&!t.obligatoire){data.note=note+(note?'\n':'')+'💳 Paiement : à régler plus tard ('+t.montant+' '+dev+')'}
      else{var op=$('pay_op').value,num=$('pay_num').value.trim(),ref=$('pay_ref').value.trim();
        data.note=note+(note?'\n':'')+'💳 PAIEMENT DÉCLARÉ (à vérifier) : '+t.montant+' '+dev+' via '+op+' — n° payeur '+num+' — réf. '+ref;
        data.paiement_decl=op+' '+t.montant+' '+dev+' · réf. '+ref;data.paiement={montant:t.montant,devise:dev,reseau:op,numero:num,reference:ref,statut:'a_verifier'}}}
    var pr=os.call(this,k,data,file),dc=data.paiement;
    return dc?pr.then(function(res){report(k,data,dc,res);return res}):pr}}
function report(k,data,dc,res){try{var c=w.EXB_SUPABASE||{};if(!c.url||!c.key)return;var h={apikey:c.key,'Content-Type':'application/json'};if(/^eyJ/.test(c.key))h.Authorization='Bearer '+c.key;
  fetch(String(c.url).replace(/\/+$/,'')+'/rest/v1/rpc/paiement_declarer',{method:'POST',headers:h,body:JSON.stringify({p_data:{type:k,nom:data.name||data.full_name||'',telephone:data.phone||'',matricule:(res&&res.matricule)||'',montant:dc.montant,devise:dc.devise,reseau:dc.reseau,numero:dc.numero,reference:dc.reference}})}).catch(function(){})}catch(e){}}
load(function(){wrap();if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',watch);else watch()});
})(window,document);
