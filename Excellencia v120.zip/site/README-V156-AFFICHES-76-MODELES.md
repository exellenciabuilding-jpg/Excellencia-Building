# V156 — Studio libre : 76 nouveaux modèles de communication

**Aucun SQL.** Fichier modifié : `exb-affiches-studio.js` (+ cache `sw.js`). Test : `tools/e2e-affiches-modeles.py`.

Total : **122 modèles** (46 existants + 76). Chaque modèle choisit son format ; tout reste libre : textes, couleurs, photos, formes, logo. Les tailles de texte s'ajustent automatiquement pour rester au-dessus du bandeau de contact.

- **Recrutement & RH (8)** : nous recrutons, offre d'emploi détaillée, stages (story), bienvenue au nouveau collaborateur, employé du mois, bannière LinkedIn, journée recrutement, nos valeurs.
- **Réseaux sociaux (13)** : citation, lundi motivation, astuce du jour, le saviez-vous, chiffres clés, sondage, liste 5 erreurs, mythe/réalité, teaser « bientôt », merci, bon week-end, couverture de carrousel, couverture Facebook/LinkedIn.
- **Promotions & ventes (9)** : promo en %, promo éclair, offre de lancement, fin d'année, 3 formules, grille tarifaire, bon de réduction, parrainage, vente flash.
- **Immobilier & terrains (7)** : villa à vendre, terrain, appartement à louer, nouveau programme, portes ouvertes, vendu/livré, visite de chantier.
- **Événements & célébrations (9)** : inauguration, anniversaire, vœux, première pierre, remise des clés, séminaire, gala, distinction, fête du travail.
- **Sécurité & qualité (6)** : sécurité d'abord, jours sans accident, règles du chantier, numéros d'urgence, premiers secours, engagements qualité/HSE.
- **Services & vitrine (8)** : équipe, méthode en 4 étapes, pourquoi nous choisir, FAQ, portfolio, partenaires, zones d'intervention, 6 services en icônes.
- **Informations clients (6)** : horaires, moyens de paiement, comment commander, réseaux sociaux, QR code à scanner, documents à fournir.
- **Supports & identité (5)** : carte de visite recto/verso, kakemono, flyer A5, écran TV.
- **Formations & écoles (5)** : rentrée, portes ouvertes, lauréats, cours du soir, remise de certificats.

**4 nouveaux formats** : A5 portrait, carte de visite 90×50 mm, kakemono 85×200 cm, écran 16:9.

Non testé sur téléphone ni à l'impression réelle.
