/* V144c — boîtes de confirmation / saisie intégrées à la page (non bloquantes) : remplacent confirm()/prompt() natifs,
 * qui figent tout l'écran tant qu'on n'a pas répondu (et peuvent se perdre derrière la fenêtre).
 * EXBUI.confirm(msg,{ok,non,danger}) -> Promise<boolean> ; EXBUI.prompt(msg,defaut) -> Promise<string|null>. Échap = annuler, Entrée = valider. */
(function(w){'use strict';
if(w.EXBUI)return;
var d=w.document;
function el(t,c,x){var e=d.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
if(!d.getElementById('exbUiCss')){var st=d.createElement('style');st.id='exbUiCss';st.textContent='.exbui-bg{position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px}.exbui-box{background:#fff;color:#111;border-radius:12px;max-width:440px;width:100%;padding:18px 18px 14px;box-shadow:0 12px 40px rgba(0,0,0,.4);font:15px/1.45 system-ui,Arial,sans-serif}.exbui-msg{white-space:pre-line;margin:0 0 12px}.exbui-in{width:100%;box-sizing:border-box;padding:9px;font:inherit;border:1px solid #94a3b8;border-radius:8px;margin:0 0 12px}.exbui-btns{display:flex;gap:8px;justify-content:flex-end}.exbui-btns button{padding:9px 16px;border-radius:8px;border:1px solid #94a3b8;background:#f1f5f9;font:inherit;cursor:pointer}.exbui-btns .exbui-ok{background:#173565;color:#fff;border-color:#173565}.exbui-btns .exbui-dg{background:#b42318;border-color:#b42318}';(d.head||d.documentElement).appendChild(st)}
function boite(msg,champ,def,o){return new Promise(function(res){
  o=o||{};var prev=d.activeElement,bg=el('div','exbui-bg'),bx=el('div','exbui-box'),inp=null;
  bx.setAttribute('role','dialog');bx.setAttribute('aria-modal','true');bx.appendChild(el('p','exbui-msg',String(msg==null?'':msg)));
  if(champ){inp=el('input','exbui-in');inp.type='text';inp.value=def==null?'':def;bx.appendChild(inp)}
  var bt=el('div','exbui-btns'),non=el('button','',o.non||'Annuler'),ok=el('button','exbui-ok'+(o.danger?' exbui-dg':''),o.ok||'OK');non.type=ok.type='button';
  bt.appendChild(non);bt.appendChild(ok);bx.appendChild(bt);bg.appendChild(bx);
  function fin(v){d.removeEventListener('keydown',kd,true);bg.remove();try{prev&&prev.focus&&prev.focus()}catch(e){}res(v)}
  function kd(e){if(e.key==='Escape'){e.preventDefault();e.stopPropagation();fin(champ?null:false)}else if(e.key==='Enter'&&(champ||d.activeElement===ok)){e.preventDefault();e.stopPropagation();fin(champ?inp.value:true)}}
  ok.onclick=function(){fin(champ?inp.value:true)};non.onclick=function(){fin(champ?null:false)};
  bg.addEventListener('mousedown',function(e){if(e.target===bg)fin(champ?null:false)});
  d.addEventListener('keydown',kd,true);(d.body||d.documentElement).appendChild(bg);
  try{(inp||ok).focus();if(inp)inp.select()}catch(e){}})}
var fileAl=Promise.resolve();
/* V144d : alert intégré. File d'attente (un message à la fois), ne bloque pas le fil principal, aucun rejeu de clic. */
function alerte(m,o){o=Object.assign({ok:'OK'},o||{});
  fileAl=fileAl.then(function(){return new Promise(function(res){
    var prev=d.activeElement,bg=el('div','exbui-bg'),bx=el('div','exbui-box'),ok=el('button','exbui-ok',o.ok),bt=el('div','exbui-btns');
    bx.setAttribute('role','alertdialog');bx.setAttribute('aria-modal','true');bx.appendChild(el('p','exbui-msg',String(m==null?'':m)));
    ok.type='button';bt.appendChild(ok);bx.appendChild(bt);bg.appendChild(bx);
    function fin(){d.removeEventListener('keydown',kd,true);bg.remove();try{prev&&prev.focus&&prev.focus()}catch(e){}res()}
    function kd(e){if(e.key==='Escape'||e.key==='Enter'){e.preventDefault();e.stopPropagation();fin()}}
    ok.onclick=fin;d.addEventListener('keydown',kd,true);(d.body||d.documentElement).appendChild(bg);try{ok.focus()}catch(e){}})}).catch(function(){});
  return fileAl}
w.EXBUI={confirm:function(m,o){return boite(m,false,null,o)},prompt:function(m,def,o){return boite(m,true,def,o)},alert:alerte};
/* Aides explicites : repli sur la boîte native seulement si EXBUI est absent. */
w.exbAlert=function(m){try{if(w.__exbAlertHook)w.__exbAlertHook(m)}catch(e){}try{w.EXBUI.alert(m)}catch(e){w.alert(m)}};
w.exbPrompt=function(m,def){return w.EXBUI?w.EXBUI.prompt(m,def):Promise.resolve(w.prompt(m,def))};
w.exbConfirm=function(m,o){if(!w.EXBUI)return Promise.resolve(w.confirm(m));
  if(!o){var dg=/supprim|effac|retir|vider|r[ée]initialis|annul|perdu|irr[ée]versible/i.test(String(m||''));o={danger:dg,ok:dg?'Confirmer':'OK'}}
  return w.EXBUI.confirm(m,o)};

/* V144e : l'ancien mécanisme qui interceptait confirm()/prompt() natifs puis REJOUAIT le clic a été supprimé (risque d'exécuter deux fois
   les opérations placées avant la boîte). Tous les appels métier utilisent désormais await exbConfirm()/exbPrompt()/exbAlert() ;
   confirm()/prompt() natifs ne subsistent que dans des pages autonomes et comme repli si EXBUI est absent. */
})(window);
