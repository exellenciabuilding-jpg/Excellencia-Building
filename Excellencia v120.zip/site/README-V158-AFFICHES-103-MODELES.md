# V158 — Studio libre : +103 modèles (communication, marketing, métiers, badges, certificats, autres secteurs)

**Aucun SQL.** Fichier modifié : `exb-affiches-studio.js`. Total du Studio libre : **338 modèles** (46 d'origine + 76 V156 + 113 V157 + 103 ici). Test : `python3 tools/e2e-affiches-modeles.py`.

## Nouveaux formats
Instagram portrait 4:5 · Badge 54×86 mm · Bannière X/YouTube 3:1 · Pinterest 2:3 (plus A5, carte de visite, kakemono, écran 16:9 ajoutés en V156).

## Contenu
- **Communication interne (10)** : réunion générale, bilan du mois, objectifs, merci à l'équipe, règle d'or, boîte à idées, anniversaires, planning des congés, mot du directeur, consigne importante.
- **Instagram portrait (12)** : carrousel (couverture, texte, liste, appel à l'action), citation, avant/après, chiffres, annonce, promo, témoignage, quiz, présentation de projet.
- **Métiers & services du bâtiment (18)** : maçonnerie, plomberie, électricité, peinture, carrelage, toiture, menuiserie, climatisation, topographie, études de sol, plans, permis de construire, suivi de chantier, décoration, paysagisme, rénovation, forage & eau, énergie solaire.
- **Offres & ventes (12)** : soldes, offre étudiants, code promo, livraison gratuite, prix cassés, déstockage, week-end, pack complet, paiement à la livraison, pré-commande, nouveauté, comparatif.
- **Salons & événements pro (12)** : salon, kakemono de stand, conférence de presse, atelier, journée sécurité, team building, assemblée générale, lancement, visite officielle, programme, invitation VIP, remerciements.
- **Badges, cartes & petits formats (12)** : badges employé / visiteur / invité / chantier, carte de fidélité, vœux, ticket, remerciement, rendez-vous, étiquette de dossier, panneau de bureau, bannière X/YouTube, Pinterest, signet.
- **Certificats & diplômes (8, A4 paysage)** : réussite, participation, honneur, reconnaissance, employé du mois, ancienneté, partenaire, prix d'excellence.
- **Autres secteurs (17)** : menu du jour, livraison, ouverture de boutique, programme associatif, appel aux dons, santé, salubrité, tournoi, concert, beauté, garage, traiteur, location de salle, cours de soutien, garde, transport, produits locaux.

Tout reste modifiable (textes, couleurs, photos, formes, logo). Non testé à l'impression réelle ni sur téléphone.
