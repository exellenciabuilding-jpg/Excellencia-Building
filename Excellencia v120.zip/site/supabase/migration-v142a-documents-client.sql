-- Excellencia Building V142a — Tous les documents du client dans son espace (plan, devis, note de calcul, plan d'exécution, facture, contrat, rapport, autre)
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql. Réexécutable sans danger.
-- Principe : on réutilise la table client_plans (déjà en place, sans accès direct) en lui ajoutant un GENRE et un NUMÉRO de document.
-- Les plans déjà envoyés deviennent automatiquement du genre « plan ». Même genre + même titre = nouvelle version (« modifié »).
-- Les anciennes fonctions (client_plan_publier, client_plan_lire, client_plan_retirer) continuent de fonctionner.

alter table public.client_plans add column if not exists genre text not null default 'plan';
alter table public.client_plans add column if not exists numero text;
alter table public.client_plans drop constraint if exists client_plans_genre_chk;
alter table public.client_plans add constraint client_plans_genre_chk
  check (genre in ('plan','devis','note_calcul','plan_execution','facture','contrat','rapport','autre'));
grant select (genre, numero) on public.client_plans to authenticated;

-- ---------- Côté entreprise : envoyer un document d'un genre donné ----------
create or replace function public.client_doc_publier(p_org uuid, p_token text, p_genre text, p_titre text, p_numero text, p_note text, p_data text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare l public.portail_liens; v_titre text := left(btrim(coalesce(p_titre,'')), 160); v_ref text; v_ver int; v_mime text; v_id uuid;
        v_genre text := lower(btrim(coalesce(p_genre,'')));
        v_lib text; v_num text := left(btrim(coalesce(p_numero,'')), 60);
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  if v_genre not in ('plan','devis','note_calcul','plan_execution','facture','contrat','rapport','autre') then raise exception 'genre_invalide'; end if;
  select * into l from public.portail_liens where token = p_token and org_id = p_org and kind = 'client';
  if not found then raise exception 'portail_introuvable'; end if;
  if length(v_titre) < 2 then raise exception 'titre_invalide'; end if;
  if p_data is null or p_data !~ '^data:(application/pdf|image/png|image/jpeg|image/webp);base64,[A-Za-z0-9+/=]+$' then raise exception 'fichier_invalide'; end if;
  if length(p_data) > 8400000 then raise exception 'fichier_trop_lourd'; end if;
  v_mime := substring(p_data from '^data:([a-z/]+);base64,');
  -- les plans gardent l'ancienne référence (compatibilité) ; les autres genres ont leur propre espace de versions
  v_ref := case when v_genre = 'plan' then '' else v_genre || ':' end || lower(regexp_replace(v_titre, '\s+', ' ', 'g'));
  select coalesce(max(version), 0) + 1 into v_ver from public.client_plans where lien_id = l.id and plan_ref = v_ref;
  insert into public.client_plans(org_id, lien_id, plan_ref, titre, version, note, mime, taille, data, genre, numero)
  values (p_org, l.id, v_ref, v_titre, v_ver, left(btrim(coalesce(p_note,'')), 400), v_mime, (length(p_data) * 3 / 4)::int, p_data, v_genre, nullif(v_num, ''))
  returning id into v_id;
  v_lib := case v_genre when 'plan' then '📐 Plan' when 'devis' then '💶 Devis' when 'note_calcul' then '🧮 Note de calcul' when 'plan_execution' then '📐 Plan d’exécution'
                        when 'facture' then '🧾 Facture' when 'contrat' then '📑 Contrat' when 'rapport' then '📋 Rapport' else '📎 Document' end;
  insert into public.portail_messages(lien_id, de, texte)
  values (l.id, 'entreprise', case when v_ver > 1 then v_lib || ' modifié : ' || v_titre || ' (version ' || v_ver || ').' else v_lib || ' disponible : ' || v_titre || '.' end
          || case when btrim(coalesce(p_note,'')) <> '' then ' ' || left(btrim(p_note), 300) else '' end);
  return jsonb_build_object('ok', true, 'id', v_id, 'version', v_ver);
end $$;
revoke all on function public.client_doc_publier(uuid,text,text,text,text,text,text) from public, anon;
grant execute on function public.client_doc_publier(uuid,text,text,text,text,text,text) to authenticated;

-- ---------- Suivi côté entreprise : ajoute le genre ----------
create or replace function public.client_plans_suivi(p_org uuid)
returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', false) then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'token', l.token, 'titre', c.titre, 'version', c.version, 'publie_le', c.publie_le, 'vu_le', c.vu_le, 'taille', c.taille, 'genre', c.genre, 'numero', c.numero) order by c.publie_le desc)
    from public.client_plans c join public.portail_liens l on l.id = c.lien_id where c.org_id = p_org), '[]'::jsonb);
end $$;
revoke all on function public.client_plans_suivi(uuid) from public, anon;
grant execute on function public.client_plans_suivi(uuid) to authenticated;

-- ---------- Côté client : la liste indique le genre et le numéro ----------
create or replace function public.client_plans_liste(p_token text, p_code text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  return jsonb_build_object('ok', true, 'plans', coalesce((
    select jsonb_agg(jsonb_build_object('id', p.id, 'titre', p.titre, 'version', p.version, 'note', p.note, 'mime', p.mime, 'taille', p.taille,
             'publie_le', p.publie_le, 'nouveau', p.vu_le is null, 'genre', p.genre, 'numero', p.numero,
             'courant', p.version = (select max(q.version) from public.client_plans q where q.lien_id = p.lien_id and q.plan_ref = p.plan_ref))
           order by p.publie_le desc)
    from public.client_plans p where p.lien_id = c.v_id), '[]'::jsonb));
end $$;
revoke all on function public.client_plans_liste(text,text) from public;
grant execute on function public.client_plans_liste(text,text) to anon, authenticated;

notify pgrst, 'reload schema';
-- Contrôle : select column_name from information_schema.columns where table_name='client_plans' and column_name in ('genre','numero'); -> 2 lignes
