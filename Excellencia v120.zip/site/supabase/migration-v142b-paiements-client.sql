-- Excellencia Building V142b — Paiements des clients : déclaration (référence + n° de transaction), confirmation par l'administrateur, reçu renvoyé dans l'espace client
-- À exécuter UNE fois (Supabase › SQL Editor), APRÈS migration-v142a-documents-client.sql. Réexécutable sans danger.
-- Principe (même modèle que les frais des apprenants) :
--   · Le client paie HORS du logiciel (Mobile Money, banque, caisse…), puis déclare dans son espace : montant, mode, référence, numéro de transaction, date.
--   · L'administrateur vérifie : il CONFIRME (montant réellement reçu → numéro de reçu donné par le serveur) ou REFUSE (motif obligatoire).
--   · Il génère le reçu (PDF) depuis le logiciel : il est envoyé dans l'espace du client (genre « recu » dans client_plans).
--   · Aucun paiement en ligne : l'argent ne transite jamais par le logiciel. Les paiements ne sont jamais supprimés par le client.
-- Limites : 10 déclarations par heure et par espace client, 200 par espace. Un même numéro de transaction ne peut pas être déclaré deux fois.

-- 1) Le genre « recu » rejoint les genres de documents de l'espace client
alter table public.client_plans drop constraint if exists client_plans_genre_chk;
alter table public.client_plans add constraint client_plans_genre_chk
  check (genre in ('plan','devis','note_calcul','plan_execution','facture','contrat','rapport','autre','recu'));

-- 2) Paiements déclarés
create sequence if not exists public.client_recu_seq;

create table if not exists public.client_paiements (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null,
  lien_id uuid not null references public.portail_liens(id) on delete cascade,
  facture text not null default '',
  montant numeric(14,2) not null check (montant > 0 and montant <= 1000000000),
  devise text not null default 'USD' check (devise in ('USD','FC')),
  mode text not null check (mode in ('mobile_money','banque','caisse','autre')),
  reference text not null,
  trans_no text not null,
  date_paiement date not null,
  note text not null default '',
  statut text not null default 'en_attente' check (statut in ('en_attente','confirme','refuse')),
  montant_confirme numeric(14,2),
  motif text not null default '',
  recu_no text,
  recu_plan uuid,
  decide_le timestamptz,
  cree_le timestamptz not null default now()
);
create index if not exists client_paiements_lien_idx on public.client_paiements (lien_id, cree_le);
create index if not exists client_paiements_org_idx on public.client_paiements (org_id, cree_le);
create unique index if not exists client_paiements_recu_idx on public.client_paiements (recu_no) where recu_no is not null;
alter table public.client_paiements enable row level security;
revoke all on public.client_paiements from anon, authenticated;

-- Numéro de reçu unique : REC-CLI-AAAA-00001
create or replace function public.client_recu_numero() returns text
language sql volatile set search_path = public as $$
  select 'REC-CLI-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.client_recu_seq')::text, 5, '0')
$$;
revoke all on function public.client_recu_numero() from public, anon, authenticated;

-- ---------- Côté client : déclarer un paiement ----------
create or replace function public.client_paiement_declarer(p_token text, p_code text, p_facture text, p_montant numeric, p_devise text, p_mode text,
  p_reference text, p_trans text, p_date date, p_note text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record; l public.portail_liens; v_ref text := left(btrim(coalesce(p_reference,'')), 80); v_tr text := left(btrim(coalesce(p_trans,'')), 80);
        v_fac text := left(btrim(coalesce(p_facture,'')), 60); v_dev text := upper(btrim(coalesce(p_devise,''))); v_m numeric(14,2); v_id uuid; v_lib text;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  select * into l from public.portail_liens where id = c.v_id and kind = 'client';
  if not found then return jsonb_build_object('ok', false, 'code', 'revoque'); end if;
  if p_mode not in ('mobile_money','banque','caisse','autre') then return jsonb_build_object('ok', false, 'code', 'type'); end if;
  if v_dev not in ('USD','FC') then return jsonb_build_object('ok', false, 'code', 'devise'); end if;
  if p_montant is null or p_montant <= 0 or p_montant > 1000000000 then return jsonb_build_object('ok', false, 'code', 'montant'); end if;
  v_m := round(p_montant, 2);
  if length(v_ref) < 3 then return jsonb_build_object('ok', false, 'code', 'reference'); end if;
  if length(v_tr) < 4 then return jsonb_build_object('ok', false, 'code', 'transaction'); end if;
  if p_date is null or p_date > current_date + 1 or p_date < current_date - 400 then return jsonb_build_object('ok', false, 'code', 'date'); end if;
  if (select count(*) from public.client_paiements where lien_id = l.id and cree_le > now() - interval '1 hour') >= 10 then return jsonb_build_object('ok', false, 'code', 'trop'); end if;
  if (select count(*) from public.client_paiements where lien_id = l.id) >= 200 then return jsonb_build_object('ok', false, 'code', 'limite'); end if;
  if exists (select 1 from public.client_paiements where org_id = l.org_id and statut in ('en_attente','confirme') and lower(trans_no) = lower(v_tr)) then
    return jsonb_build_object('ok', false, 'code', 'doublon');
  end if;
  insert into public.client_paiements(org_id, lien_id, facture, montant, devise, mode, reference, trans_no, date_paiement, note)
  values (l.org_id, l.id, v_fac, v_m, v_dev, p_mode, v_ref, v_tr, p_date, left(btrim(coalesce(p_note,'')), 400)) returning id into v_id;
  v_lib := case p_mode when 'mobile_money' then 'Mobile Money' when 'banque' then 'banque' when 'caisse' then 'caisse' else 'autre mode' end;
  insert into public.portail_messages(lien_id, de, texte)
  values (l.id, 'visiteur', 'Paiement déclaré : ' || to_char(v_m, 'FM999G999G999G990D00') || ' ' || v_dev || ' (' || v_lib || ')'
          || case when v_fac <> '' then ' pour la facture ' || v_fac else '' end || ' — référence ' || v_ref || ', transaction ' || v_tr
          || ', le ' || to_char(p_date, 'DD/MM/YYYY') || '. En attente de vérification.');
  return jsonb_build_object('ok', true, 'id', v_id);
end $$;
revoke all on function public.client_paiement_declarer(text,text,text,numeric,text,text,text,text,date,text) from public;
grant execute on function public.client_paiement_declarer(text,text,text,numeric,text,text,text,text,date,text) to anon, authenticated;

-- ---------- Côté client : mes paiements ----------
create or replace function public.client_paiements_liste(p_token text, p_code text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare c record;
begin
  select * into c from public.portail_check(p_token, p_code);
  if c.v_err is not null then return jsonb_build_object('ok', false, 'code', c.v_err, 'minutes', c.v_min); end if;
  return jsonb_build_object('ok', true, 'paiements', coalesce((
    select jsonb_agg(jsonb_build_object('id', x.id, 'facture', x.facture, 'montant', x.montant, 'devise', x.devise, 'mode', x.mode, 'reference', x.reference,
             'trans_no', x.trans_no, 'date_paiement', x.date_paiement, 'statut', x.statut, 'montant_confirme', x.montant_confirme, 'motif', x.motif,
             'recu_no', x.recu_no, 'recu', x.recu_plan is not null, 'cree_le', x.cree_le) order by x.cree_le desc)
    from (select * from public.client_paiements where lien_id = c.v_id order by cree_le desc limit 100) x), '[]'::jsonb));
end $$;
revoke all on function public.client_paiements_liste(text,text) from public;
grant execute on function public.client_paiements_liste(text,text) to anon, authenticated;

-- ---------- Côté entreprise : suivi des paiements déclarés ----------
create or replace function public.client_paiements_suivi(p_org uuid)
returns jsonb language plpgsql security definer stable set search_path = public as $$
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', false) then raise exception 'non autorisé'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'token', l.token, 'portail', l.titre, 'client', l.destinataire, 'facture', x.facture,
      'montant', x.montant, 'devise', x.devise, 'mode', x.mode, 'reference', x.reference, 'trans_no', x.trans_no, 'date_paiement', x.date_paiement,
      'note', x.note, 'statut', x.statut, 'montant_confirme', x.montant_confirme, 'motif', x.motif, 'recu_no', x.recu_no, 'recu', x.recu_plan is not null,
      'cree_le', x.cree_le, 'decide_le', x.decide_le) order by x.cree_le desc)
    from public.client_paiements x join public.portail_liens l on l.id = x.lien_id where x.org_id = p_org), '[]'::jsonb);
end $$;
revoke all on function public.client_paiements_suivi(uuid) from public, anon;
grant execute on function public.client_paiements_suivi(uuid) to authenticated;

-- ---------- Côté entreprise : confirmer / refuser ----------
create or replace function public.client_paiement_decider(p_org uuid, p_id uuid, p_statut text, p_montant numeric default null, p_motif text default '')
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare d public.client_paiements; v_m numeric(14,2); v_motif text := left(btrim(coalesce(p_motif,'')), 300); v_recu text;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  select * into d from public.client_paiements where id = p_id and org_id = p_org;
  if not found then raise exception 'introuvable'; end if;
  if p_statut = 'confirme' then
    v_m := round(coalesce(p_montant, d.montant), 2);
    if v_m <= 0 or v_m > 1000000000 then raise exception 'montant_invalide'; end if;
    v_recu := coalesce(d.recu_no, public.client_recu_numero());
    update public.client_paiements set statut = 'confirme', montant_confirme = v_m, motif = '', recu_no = v_recu, decide_le = now() where id = d.id;
    if d.statut <> 'confirme' or d.montant_confirme is distinct from v_m then   -- pas de message en double si on reconfirme la même chose
      insert into public.portail_messages(lien_id, de, texte)
      values (d.lien_id, 'entreprise', 'Paiement confirmé : ' || to_char(v_m, 'FM999G999G999G990D00') || ' ' || d.devise || ' (transaction ' || d.trans_no || '). Reçu n° ' || v_recu || '.');
    end if;
    return jsonb_build_object('ok', true, 'recu_no', v_recu);
  elsif p_statut = 'refuse' then
    if length(v_motif) < 3 then raise exception 'motif_obligatoire'; end if;
    if d.recu_plan is not null then raise exception 'recu_deja_envoye'; end if;
    update public.client_paiements set statut = 'refuse', montant_confirme = null, motif = v_motif, recu_no = null, decide_le = now() where id = d.id;
    insert into public.portail_messages(lien_id, de, texte)
    values (d.lien_id, 'entreprise', 'Paiement non confirmé (transaction ' || d.trans_no || ') : ' || v_motif);
    return jsonb_build_object('ok', true);
  end if;
  raise exception 'statut_invalide';
end $$;
revoke all on function public.client_paiement_decider(uuid,uuid,text,numeric,text) from public, anon;
grant execute on function public.client_paiement_decider(uuid,uuid,text,numeric,text) to authenticated;

-- ---------- Côté entreprise : envoyer le reçu (PDF) dans l'espace du client ----------
create or replace function public.client_recu_publier(p_org uuid, p_id uuid, p_data text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare d public.client_paiements; v_ref text; v_ver int; v_mime text; v_pid uuid;
begin
  if auth.uid() is null or not public.peut(p_org, 'portails', true) then raise exception 'non autorisé'; end if;
  if not public.licence_ecriture_ok(p_org) then raise exception 'licence'; end if;
  select * into d from public.client_paiements where id = p_id and org_id = p_org;
  if not found then raise exception 'introuvable'; end if;
  if d.statut <> 'confirme' or d.recu_no is null then raise exception 'non_confirme'; end if;
  if p_data is null or p_data !~ '^data:(application/pdf|image/png|image/jpeg);base64,[A-Za-z0-9+/=]+$' then raise exception 'fichier_invalide'; end if;
  if length(p_data) > 8400000 then raise exception 'fichier_trop_lourd'; end if;
  v_mime := substring(p_data from '^data:([a-z/]+);base64,');
  v_ref := 'recu:' || lower(d.recu_no);
  select coalesce(max(version), 0) + 1 into v_ver from public.client_plans where lien_id = d.lien_id and plan_ref = v_ref;
  insert into public.client_plans(org_id, lien_id, plan_ref, titre, version, note, mime, taille, data, genre, numero)
  values (p_org, d.lien_id, v_ref, 'Reçu ' || d.recu_no, v_ver,
          left('Paiement du ' || to_char(d.date_paiement, 'DD/MM/YYYY') || ' — transaction ' || d.trans_no, 400), v_mime, (length(p_data) * 3 / 4)::int, p_data, 'recu', d.recu_no)
  returning id into v_pid;
  update public.client_paiements set recu_plan = v_pid where id = d.id;
  insert into public.portail_messages(lien_id, de, texte)
  values (d.lien_id, 'entreprise', '🧾 Reçu disponible : ' || d.recu_no || case when v_ver > 1 then ' (version ' || v_ver || ')' else '' end || '. Retrouvez-le dans « Plans & Documents ».');
  return jsonb_build_object('ok', true, 'id', v_pid, 'version', v_ver, 'recu_no', d.recu_no);
end $$;
revoke all on function public.client_recu_publier(uuid,uuid,text) from public, anon;
grant execute on function public.client_recu_publier(uuid,uuid,text) to authenticated;

notify pgrst, 'reload schema';
-- Contrôle : select count(*) from information_schema.tables where table_name='client_paiements'; -> 1
