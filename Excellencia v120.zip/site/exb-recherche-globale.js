/* Excellencia Building V113 / V120y — Recherche globale sur TOUS les modules (V120m : index en mémoire, calcul par tranches, anti-rebond).
 * Remplace runExbGlobalSearch : sans accents ni majuscules, plusieurs mots (tous doivent correspondre),
 * recherche dans tous les champs texte de chaque fiche. Un clic ouvre le bon module (et le dossier TFL concerné). */
(function (w) {
  'use strict';
  var d = document;
  function normRaw(v) { return String(v == null ? '' : v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }
  /* V144e : mêmes libellés normalisés des milliers de fois par passage (normalize('NFD') coûteux) → petit cache */
  var NC = new Map();
  function norm(s) { if (typeof s !== 'string' || s.length > 200) return normRaw(s); var c = NC.get(s); if (c !== undefined) return c; c = normRaw(s); if (NC.size > 20000) NC.clear(); NC.set(s, c); return c; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  /* exbStorage est déclaré avec « const » dans index.html : il n'existe PAS sur window.
   * Il faut l'atteindre par son nom global (comme exb-storage-bridge.js), sinon on lit le localStorage brut,
   * dont les clés n'ont pas le préfixe du logiciel → aucune donnée trouvée (bug V113). */
  function st() {
    try { if (typeof exbStorage !== 'undefined' && exbStorage && exbStorage.getItem) return exbStorage; } catch (e) { /* repli */ }
    return (w.exbStorage && w.exbStorage.getItem) ? w.exbStorage : null;
  }
  function arr(s) { try { var v = s ? JSON.parse(s) : []; return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function rd(k) {
    var v = [];
    try { var s = st(); if (s) v = arr(s.getItem(k)); } catch (e) { v = []; }
    if (!v.length) { try { if (w.EXBS && w.EXBS.get) v = w.EXBS.get(k) || []; } catch (e) { /* ignoré */ } }
    if (!v.length) { try { v = arr(w.localStorage.getItem(k)); } catch (e) { /* ignoré */ } }
    return Array.isArray(v) ? v : [];
  }
  var SKIP = /^(photo|signature|sign|logo|image|img|data|file|fichier_data|b64|base64|blob|cachet|password|pass|mdp|code_acces|token|key|cle)/i;
  function flat(o, depth, out) {
    if (o == null) return out;
    if (typeof o === 'string') { if (o.length <= 300 && !/^data:/.test(o)) out.push(o); return out; }
    if (typeof o === 'number') { out.push(String(o)); return out; }
    if (depth > 1) return out;
    if (Array.isArray(o)) { o.slice(0, 20).forEach(function (x) { flat(x, depth + 1, out); }); return out; }
    if (typeof o === 'object') Object.keys(o).forEach(function (k) { if (!SKIP.test(k)) flat(o[k], depth + 1, out); });
    return out;
  }
  function first(r, fields) { for (var i = 0; i < fields.length; i++) { var v = r[fields[i]]; if (v != null && String(v).trim() !== '') return String(v); } return ''; }
  function go(sec) { try { w.show(sec); } catch (e) { /* module absent */ } }

  /* Collections : clé de stockage, libellé du type, champs du titre, champs du détail, action */
  var COLS = [
    { k: 'exb_participants', t: 'Participant', l: ['name', 'nom'], s: ['participant_id', 'training', 'phone'], a: function (r) { try { w.openParticipantProfile(r.participant_id); } catch (e) { go('participants'); } } },
    { k: 'exb_certificates', t: 'Certificat', l: ['cert_no', 'holder'], s: ['holder', 'training'], sec: 'certs' },
    { k: 'exb_receipts', t: 'Reçu', l: ['receipt_no', 'participant'], s: ['participant', 'training'], sec: 'receipts' },
    { k: 'exb_payments', t: 'Paiement', l: ['reference', 'payment_id'], s: ['amount', 'method', 'participant_id'], sec: 'finances' },
    { k: 'exb_formations', t: 'Formation', l: ['name', 'code'], s: ['code', 'trainer', 'status'], sec: 'formations' },
    { k: 'exb_trainers', t: 'Formateur', l: ['name'], s: ['matricule', 'specialty', 'phone'], sec: 'formateurs' },
    { k: 'exb_hr', t: 'Personnel', l: ['name', 'nom'], s: ['matricule', 'role', 'poste', 'phone'], sec: 'rh' },
    { k: 'exb_clients', t: 'Client', l: ['full_name', 'company', 'name', 'id'], s: ['company', 'phone', 'email'], sec: 'clients' },
    { k: 'exb_projects', t: 'Projet', l: ['name', 'id'], s: ['client', 'location', 'status'], sec: 'projets' },
    { k: 'exb_quotes', t: 'Devis', l: ['no', 'id'], s: ['client', 'project', 'total'], sec: 'metreDevis' },
    { k: 'exb_metre', t: 'Métré', l: ['name', 'titre', 'id'], s: ['project', 'client'], sec: 'metreDevis' },
    { k: 'exb_invoices', t: 'Facture', l: ['no', 'number', 'id'], s: ['client', 'project', 'total'], sec: 'comptabilite' },
    { k: 'exb_suppliers', t: 'Fournisseur', l: ['name', 'nom', 'company'], s: ['phone', 'email', 'category'], sec: 'stock' },
    { k: 'exb_purchase_orders', t: 'Bon de commande', l: ['no', 'id'], s: ['supplier', 'project', 'total'], sec: 'stock' },
    { k: 'exb_stock', t: 'Stock', l: ['name', 'nom', 'article'], s: ['category', 'unit', 'qty'], sec: 'stock' },
    { k: 'exb_studies', t: 'Étude', l: ['name', 'titre', 'id'], s: ['client', 'status'], sec: 'bureauEtudes' },
    { k: 'exb_be_missions', t: 'Mission BET', l: ['name', 'titre', 'id'], s: ['client', 'status'], sec: 'bureauEtudes' },
    { k: 'exb_plans', t: 'Plan', l: ['name', 'titre', 'id'], s: ['project', 'client'], sec: 'bureauEtudes' },
    { k: 'exb_calc_notes', t: 'Note de calcul', l: ['name', 'titre', 'id'], s: ['project', 'client'], sec: 'bureauEtudes' },
    { k: 'exb_situations', t: 'Situation de travaux', l: ['no', 'id', 'name'], s: ['project', 'client'], sec: 'projets' },
    { k: 'exb_site_journal', t: 'Journal de chantier', l: ['title', 'titre', 'date', 'id'], s: ['project', 'text', 'note'], sec: 'projets' },
    { k: 'exb_communication', t: 'Communication', l: ['title', 'titre', 'name', 'id'], s: ['channel', 'status'], sec: 'communication' },
    { k: 'exb_documents', t: 'Document', l: ['title', 'id'], s: ['type', 'participant_name', 'project_name'], sec: 'documents' },
    { k: 'exb_tfl_dossiers', t: 'Dossier TFL', tfl: 'dossier', l: ['numero'], s: [] },
    { k: 'exb_tfl_etudiants', t: 'Étudiant TFL', tfl: 'etudiant', l: ['nom'], s: ['matricule', 'universite', 'telephone'] },
    { k: 'exb_tfl_encadreurs', t: 'Encadreur TFL', tfl: 'encadreur', l: ['nom'], s: ['specialites', 'telephone', 'email'] },
    { k: 'exb_tfl_sujets', t: 'Sujet TFL', tfl: 'sujet', l: ['titre', 'ref'], s: ['categorie', 'domaine'] },
    { k: 'exb_tfl_biblio', t: 'Bibliothèque TFL', tfl: 'biblio', l: ['titre'], s: ['auteur', 'annee', 'universite'] }
  ];

  function tflOpen(o) { try { if (typeof w.exbTflOpen === 'function') w.exbTflOpen(o); } catch (e) { /* ignoré */ } go('tflSec'); }

  /* ---------- V120y : recherche robuste, cache invalidé par révision de stockage ----------
   * Avant : chaque touche relisait et analysait les ~28 collections d'un seul bloc → l'écran se figeait par moments.
   * Maintenant : (1) index en mémoire, reconstruit seulement si les données ont changé ;
   *              (2) calcul découpé en tranches de ~10 ms (l'écran reste fluide) ;
   *              (3) anti-rebond : on ne cherche qu'une fois la frappe terminée ; une nouvelle frappe annule la recherche en cours ;
   *              (4) au plus 500 résultats collectés (les 60 premiers sont affichés) ;
   *              (5) toute erreur est contenue : la barre ne reste jamais bloquée. */
  var IDX = {}, BUILD = {}, T0 = 0, MAXC = 500, REV = w.__EXB_SEARCH_REV || (w.__EXB_SEARCH_REV = Object.create(null));
  /* Les écritures passent par exbStorage : un compteur évite de relire une grosse chaîne localStorage à chaque frappe. */
  function revision(k) { return Number(REV[k] || 0); }
  try { w.addEventListener('storage', function (e) { var pfx = 'EXB_V28__'; if (e && e.key && e.key.indexOf(pfx) === 0) { var k = e.key.slice(pfx.length); REV[k] = revision(k) + 1; } }); } catch (e) {}
  function now() { return (w.performance && performance.now) ? performance.now() : Date.now(); }
  function over() { return now() - T0 > 10; }
  function pause() { return new Promise(function (r) { setTimeout(r, 0); }); }
  function rawOf(k) {
    try { var sx = st(); if (sx) { var v = sx.getItem(k); if (typeof v === 'string' && v) return v; } } catch (e) { /* repli */ }
    try { var v2 = w.localStorage.getItem(k); if (typeof v2 === 'string' && v2) return v2; } catch (e) { /* repli */ }
    return null;
  }
  function hayOf(r) { var h = norm(flat(r, 0, []).join(' ')); return h.length > 1800 ? h.slice(0, 1800) : h; }
  function getRows(c) {
    var rev = revision(c.k), ix = IDX[c.k];
    if (ix && ix.rev === rev) return Promise.resolve(ix.rows);
    if (BUILD[c.k] && BUILD[c.k].rev === rev) return BUILD[c.k].p;
    var raw = rawOf(c.k);
    if (raw === null) {
      /* Sources EXBS/legacy : lecture directe, cache court et invalidé par les écritures exbStorage. */
      var rows0 = rd(c.k).map(function (r) { return { r: r, hay: hayOf(r) }; });
      IDX[c.k] = { rev: rev, rows: rows0 };
      return Promise.resolve(rows0);
    }
    var list = arr(raw), out = [], i = 0;
    var p = (async function () {
      T0 = now();
      for (; i < list.length; i++) {
        var r = list[i];
        if (r && typeof r === 'object') out.push({ r: r, hay: hayOf(r) });
        if (over()) { await pause(); T0 = now(); }
      }
      /* Si les données ont changé pendant l'indexation, ne pas publier un index périmé. */
      if (revision(c.k) === rev) IDX[c.k] = { rev: rev, rows: out };
      if (BUILD[c.k] && BUILD[c.k].rev === rev) delete BUILD[c.k];
      return revision(c.k) === rev ? out : getRows(c);
    })();
    BUILD[c.k] = { rev: rev, p: p };
    return p;
  }

  var COLBY = {}; COLS.forEach(function (c) { COLBY[c.k] = c; });
  function names(rows) { var m = {}; rows.forEach(function (e) { m[e.r.id] = e.r.nom || ''; }); return m; }
  async function searchAsync(q, id, alive) {
    var toks = norm(q).split(' ').filter(Boolean), out = [], nq = norm(q);
    if (!toks.length) return out;
    T0 = now();
    var nomEtu = names(await getRows(COLBY['exb_tfl_etudiants'])), nomEnc = names(await getRows(COLBY['exb_tfl_encadreurs']));
    out.truncated = false;
    for (var ci = 0; ci < COLS.length; ci++) {
      var c = COLS[ci], rows = await getRows(c);
      if (!alive(id)) return null;
      if (c.k === 'exb_documents' && !rows.length && Array.isArray(w.exbDocuments)) rows = w.exbDocuments.map(function (r) { return { r: r, hay: null }; });
      for (var i = 0; i < rows.length; i++) {
        var e = rows[i], r = e.r; if (!r || typeof r !== 'object') continue;
        var hay = e.hay == null ? hayOf(r) : e.hay;
        if (c.tfl === 'dossier') hay += ' ' + norm((nomEtu[r.etudiant_id] || '') + ' ' + (nomEnc[r.encadreur_id] || ''));
        var ok = true; for (var t = 0; t < toks.length; t++) if (hay.indexOf(toks[t]) < 0) { ok = false; break; }
        if (ok) {
          var label = first(r, c.l), det = c.s.map(function (f) { return r[f] == null ? '' : String(r[f]); }).filter(Boolean).join(' — ');
          if (c.tfl === 'dossier') { label = (r.numero || 'Dossier') + ' — ' + (nomEtu[r.etudiant_id] || ''); det = [r.sujet || r.titre || '', nomEnc[r.encadreur_id] ? 'Encadreur : ' + nomEnc[r.encadreur_id] : ''].filter(Boolean).join(' — '); }
          var nl = norm(label), score = nl === nq ? 0 : nl.indexOf(nq) === 0 ? 1 : nl.indexOf(nq) >= 0 ? 2 : 3;
          out.push({ t: c.t, label: label || '(sans titre)', det: det, score: score, c: c, r: r });
          if (out.length >= MAXC) { out.truncated = true; break; }
        }
        if (over()) { await pause(); if (!alive(id)) return null; T0 = now(); }
      }
      if (out.truncated) break;
    }
    out.sort(function (a, b) { return a.score - b.score; });
    return out;
  }
  /* version synchrone conservée pour les autres modules (utilise le même index quand il est prêt) */
  function search(q) {
    var toks = norm(q).split(' ').filter(Boolean), out = [];
    if (!toks.length) return out;
    COLS.forEach(function (c) {
      var ix = IDX[c.k]; if (!ix) return;
      ix.rows.forEach(function (e) {
        var ok = true; for (var t = 0; t < toks.length; t++) if (e.hay.indexOf(toks[t]) < 0) { ok = false; break; }
        if (ok && out.length < MAXC) out.push({ t: c.t, label: first(e.r, c.l) || '(sans titre)', det: '', score: 3, c: c, r: e.r });
      });
    });
    return out;
  }

  function open(x) {
    var c = x.c, r = x.r;
    if (c.a) return c.a(r);
    if (c.tfl === 'dossier') return tflOpen({ vue: 'dossiers', sel: r.id });
    if (c.tfl === 'etudiant') { var ds = rd('exb_tfl_dossiers').filter(function (z) { return z.etudiant_id === r.id; })[0]; return tflOpen(ds ? { vue: 'dossiers', sel: ds.id } : { vue: 'dossiers', sel: '', q: r.nom || '' }); }
    if (c.tfl === 'encadreur') return tflOpen({ vue: 'encadreurs', sel: '' });
    if (c.tfl === 'sujet') return tflOpen({ vue: 'sujets', sel: '' });
    if (c.tfl === 'biblio') return tflOpen({ vue: 'biblio', sel: '', bq: r.titre || '' });
    go(c.sec);
  }

  function render(box, q, r) {
    var MAX = 60;
    if (!r.length) box.innerHTML = '<div class="exb-search-item">Aucun résultat pour <b>' + esc(q) + '</b> dans les modules.</div>';
    else box.innerHTML = '<div class="exb-search-item" style="cursor:default;background:#f6f8fb"><small>' + (r.truncated ? 'Plus de ' + r.length : r.length) + ' résultat' + (r.length > 1 ? 's' : '') + (r.length > MAX ? ' — les ' + MAX + ' premiers sont affichés, précisez votre recherche' : '') + '</small></div>'
      + r.slice(0, MAX).map(function (x, i) { return '<div class="exb-search-item" data-i="' + i + '"><div class="exb-search-type">' + esc(x.t) + '</div><b>' + esc(x.label) + '</b>' + (x.det ? '<br><small>' + esc(x.det) + '</small>' : '') + '</div>'; }).join('');
    box._res = r;
    [].forEach.call(box.querySelectorAll('.exb-search-item[data-i]'), function (el) { el.onclick = function () { box.style.display = 'none'; try { open(r[Number(el.getAttribute('data-i'))]); } catch (e) { /* module absent */ } }; });
    box.style.display = 'block';
  }
  var cur = 0, timer = 0;
  function alive(id) { return id === cur; }
  w.runExbGlobalSearch = function (q) {
    var box = d.getElementById('exbGlobalResults'); if (!box) return;
    q = (q || '').trim(); clearTimeout(timer); var id = ++cur;   /* une nouvelle frappe annule la recherche en cours */
    if (!q) { box.style.display = 'none'; box.innerHTML = ''; box._res = null; return; }
    if (box.style.display === 'none' || !box.innerHTML) { box.innerHTML = '<div class="exb-search-item" style="cursor:default"><small>Recherche en cours…</small></div>'; box.style.display = 'block'; box._res = null; }
    timer = setTimeout(function () {
      searchAsync(q, id, alive).then(function (r) { if (r === null || id !== cur) return; render(box, q, r); }, function (e) {
        if (id !== cur) return;
        try { if (w.EXBERR && w.EXBERR.record) w.EXBERR.record('recherche', e && e.message || String(e)); } catch (x) { /* ignoré */ }
        box.innerHTML = '<div class="exb-search-item" style="cursor:default">La recherche a rencontré un problème. Modifiez votre saisie pour réessayer.</div>'; box.style.display = 'block';
      });
    }, q.length < 2 ? 280 : 170);
  };
  /* préparation de l'index en arrière-plan (au repos) : la première recherche est immédiate */
  function warm() {
    /* Précharge uniquement les collections les plus consultées : évite de remplir la mémoire au démarrage. */
    var hot = ['exb_clients', 'exb_projects', 'exb_quotes', 'exb_participants', 'exb_formations'], i = 0;
    (function next() { if (i >= hot.length) return; var c = COLBY[hot[i++]]; if (!c) return next(); getRows(c).then(function () { setTimeout(next, 120); }, function () { setTimeout(next, 250); }); })();
  }
  setTimeout(function () { try { (w.requestIdleCallback || setTimeout)(warm, 4000); } catch (e) { /* ignoré */ } }, 6000);
  w.exbSearchAll = search;

  /* Entrée = ouvre le premier résultat ; Ctrl+K / « / » = place le curseur dans la recherche. */
  d.addEventListener('keydown', function (e) {
    var s = d.getElementById('exbGlobalSearch'), box = d.getElementById('exbGlobalResults');
    if (!s) return;
    if (e.target === s && e.key === 'Enter' && box && box._res && box._res.length) { e.preventDefault(); box.style.display = 'none'; open(box._res[0]); }
    else if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); s.focus(); s.select(); }
  });
  var s0 = d.getElementById('exbGlobalSearch');
  if (s0) s0.placeholder = 'Rechercher partout : devis, client, étudiant TFL, encadreur, facture, projet, matricule…';
})(window);
