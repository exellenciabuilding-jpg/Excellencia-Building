/* Excellencia Building V64 (formules alignées sur Metrec 2026) — V63 — PHASE 3 : Bureau d'études
 * 🧮 Notes de calcul (descente de charges, poteaux, semelles isolées, poutres — BAEL 91 mod. 99, méthode simplifiée, ELU) + PDF
 * 📐 Plans : indices de version, diffusion, visas, bordereau d'envoi PDF
 * ⏱ Heures & honoraires par mission (forfait / % du budget / horaire) + facture */
(function(){'use strict';
var K={cn:'exb_calc_notes',pl:'exb_plans',mi:'exb_be_missions',tm:'exb_be_time'};
var $=i=>document.getElementById(i),ST={tab:'c',pid:'',kind:'',d:null,sel:'',vi:-1};
var esc=v=>String(v==null?'':v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
var fx=(x,d)=>Number(x||0).toLocaleString('fr-FR',{minimumFractionDigits:d==null?2:d,maximumFractionDigits:d==null?2:d}).replace(/[\u202f\u00a0]/g,' ');
var today=()=>new Date().toISOString().slice(0,10);
var say=(t,k)=>{try{notify(t,k||'info',4500)}catch(e){exbAlert(t)}};
var AR=()=>window.EXB_ARCH;/* V99 : les plans vivent dans le modèle V94 (plans, révisions, visas, diffusions) ; la vue imbriquée ci-dessous est reconstruite à la lecture */
var L=k=>{try{if(k==='pl'&&AR())return AR().plansNested();return load(K[k],[])}catch(e){return[]}},S=(k,a)=>save(K[k],a);
var upsert=(k,o)=>{if(k==='pl'&&AR()){AR().savePlanNested(o);return}var a=L(k),i=a.findIndex(x=>x.id===o.id);if(i>=0)a[i]=o;else a.push(o);S(k,a)};
var clone=o=>JSON.parse(JSON.stringify(o));
var projs=()=>typeof exbProjects!=='undefined'?exbProjects:[];
var proj=id=>projs().find(p=>p.id===id);
var pname=id=>{var p=proj(id);return p?p.name:'—'};
var num=(pre,list)=>{var y=new Date().getFullYear();return pre+'-'+y+'-'+String(list.filter(i=>String(i.no||'').indexOf(pre+'-'+y)===0).length+1).padStart(3,'0')};
var inp=(v,ex,t,w)=>`<input ${t?'type="number" step="any" ':''}value="${esc(v)}" oninput="EXBET.${ex.replace('§','this.value')}"${w?` style="width:${w}"`:''}>`;
var sel=(v,o,ex)=>`<select onchange="EXBET.${ex.replace('§','this.value')}">${o.map(x=>{var a=Array.isArray(x)?x:[x,x];return `<option value="${esc(a[0])}"${String(a[0])===String(v)?' selected':''}>${esc(a[1])}</option>`}).join('')}</select>`;
var popt=s=>'<option value="">—</option>'+projs().map(p=>`<option value="${esc(p.id)}"${p.id===s?' selected':''}>${esc(p.name)}</option>`).join('');
var btn=(t,c,cl)=>`<button class="${cl||'muted'}" onclick="EXBET.${c}">${t}</button>`;

/* =================== MOTEUR DE CALCUL — formules reprises du classeur « Metrec 2026 » (© IBWAMPERE NGWALA LOUIS) =================== */
var FISS=['peu préjudiciable','préjudiciable','très préjudiciable'],DUR=['t > 24 h','1 h ≤ t ≤ 24 h','t < 1 h'];
var theta=n=>n.t==='t < 1 h'?0.85:n.t==='1 h ≤ t ≤ 24 h'?0.9:1,fissOf=n=>n.fiss||FISS[0];
function bars(As,min,d0){var D=[10,12,14,16,20,25,32].filter(x=>x>=(d0||12));for(var i=0;i<D.length;i++){var a=Math.PI*D[i]*D[i]/400,k=Math.max(min||2,Math.ceil(As/a-1e-9));if(k<=8||i===D.length-1)return{n:k,d:D[i],as:k*a}}}
var QP=[['','Q : préréglage…'],[1.5,'Logement 1,5'],[3.5,'Balcons 3,5'],[2.5,'Bureaux, escaliers, classes 2,5'],[4,'Circulation scolaire, bibliothèque 4,0'],[1,'Terrasse non accessible 1,0'],[1.5,'Terrasse accessible privée 1,5'],[5,'Terrasse publique, cuisine collective 5,0']],
 GP=[['','G : préréglage plancher…'],[3.75,'Dalle pleine 15 cm : 3,75'],[5,'Dalle pleine 20 cm : 5,00'],[2.5,'Plancher 12+4 : 2,50'],[2.85,'Plancher 16+4 : 2,85']];
var SPEC={
 col:{lab:'🏛 Poteau',f:[['nu','Nu ELU (kN)',0],['forme','Forme','rect',['rect','circulaire']],['a','a (petit côté) ou diamètre D (cm)',25],['b','b (grand côté, cm)',25],['l0','Hauteur libre l0 (cm)',300],['k','Longueur de flambement lf = … × l0',0.7,[0.7,1]],['j','Délai d\'application des charges (jours)',60]]},
 foot:{lab:'🟫 Semelle isolée',f:[['ns','Ns ELS = G + Q (kN)',0],['nu','Nu ELU (kN, poids propre exclu)',0],['b','b poteau (grand côté, cm)',25],['a','a poteau (petit côté, cm)',25],['sol','Contrainte du sol (MPa)',0.15],['prof','Profondeur du bon sol (cm)',60]]},
 beam:{lab:'➖ Poutre',f:[['type','Section','rect',['rect','té']],['b','b (rect.) ou table (té) (cm)',20],['b0','b0 nervure (cm)',20],['h','h (cm)',40],['h0','h0 table (cm)',12],['L','Portée L (m)',4],['g','G charges permanentes (kN/m)',10],['q','Q exploitation (kN/m)',5],['km','Coefficient de moment (qu·L² ×)',0.125],['Mu','Mu imposé (kN.m, 0 = calculé)',0],['Ms','Mser imposé (kN.m, 0 = calculé)',0],['Vu','Vu imposé (kN, 0 = calculé)',0],['reprise','Reprise de bétonnage','oui',['oui','non']]]},
 dc:{lab:'⬇ Descente de charges'}};
function cDC(e){var G=0,Q=0,R=[],pp=+e.v.pp||0;(e.lv||[]).forEach(l=>{G+=(+l.g||0)*(+l.s||0)+pp;Q+=(+l.q||0)*(+l.s||0);R.push([l.n||'Niveau','G cumulé '+fx(G,1)+' kN ; Q cumulé '+fx(Q,1)+' kN ; Nu = '+fx(1.35*G+1.5*Q,1)+' kN'])});
 var ns=G+Q,nu=1.35*G+1.5*Q;R.push(['RÉSULTAT','Ns = G + Q = '+fx(ns,1)+' kN ; Nu = 1,35 G + 1,5 Q = '+fx(nu,1)+' kN']);return{rows:R,warn:[],out:{ns:ns,nu:nu}}}
/* ----- poteau (feuille « Poteau_compression simple ») ----- */
function cCol(v,n){var nu=+v.nu,circ=v.forme==='circulaire',a=+v.a,b=circ?a:+v.b,l0=+v.l0;if(l0>0&&l0<=15)l0*=100;if(!(nu>0&&a>0&&b>0&&l0>0))return{rows:[],warn:['Renseignez Nu, les dimensions et l0.']};
 var B=circ?Math.PI*a*a/4:a*b,Br=circ?Math.PI*Math.pow(a-2,2)/4:(a-2)*(b-2),imin=circ?a/4:Math.min(a,b)/Math.sqrt(12),u=circ?Math.PI*a/100:2*(a+b)/100,lf=(+v.k||0.7)*l0,lam=lf/imin,W=[],fe=n.fe,fc=n.fc,j=+v.j||90;
 if(lam>70)return{rows:[['Élancement',fx(lam,1)]],warn:['Élancement > 70 : méthode forfaitaire non applicable.']};
 var al=lam<=50?0.85/(1+0.2*Math.pow(lam/35,2)):0.6*Math.pow(50/lam,2),al2=j>90?al:j>=28?al/1.1:al/1.2,fce=fc;
 if(j<28)fce=fc<=40?j*fc/(4.76+0.83*j):j*fc/(1.4+0.95*j);
 var Ath=(nu/1000/al2-Br*1e-4*fce/(0.9*1.5))*(1.15e4/fe),Amin=Math.max(4*u,0.2*B/100),As=Math.max(Ath,Amin),Amax=5*B/100,Bb=bars(As,circ?6:4),ph=[6,8,10,12].find(x=>x>=Bb.d/3)||12,st=Math.floor(Math.min(15*Bb.d/10,40,Math.min(a,b)+10)/5)*5;
 if(lam>35)W.push('Élancement > 35 : disposer les aciers de façon à augmenter l\'inertie au flambement.');if(Ath<0)W.push('Le béton seul suffit : armatures minimales.');if(As>Amax)W.push('As > 5 % de B : augmenter la section ou réaliser un frettage.');
 if(j<28)W.push('Charges appliquées avant 28 jours : fc28 remplacé par fcj = '+fx(fce,1)+' MPa.');
 return{rows:[['Section B / réduite Br',fx(B,0)+' cm² / '+fx(Br,0)+' cm²'],['Élancement','lf = '+fx(lf,0)+' cm ; i = '+fx(imin,2)+' cm ; lambda = '+fx(lam,1)],['Coefficients','alpha1 = '+fx(al,3)+' ; alpha2 = '+fx(al2,3)+(j>90?'':j>=28?' (alpha1 / 1,10)':' (alpha1 / 1,20)')],
  ['Aciers','As,th = '+fx(Math.max(Ath,0),2)+' cm² ; A(4u) = '+fx(4*u,2)+' ; A(0,2 %) = '+fx(0.2*B/100,2)+' ; As,max = '+fx(Amax,1)+' cm²'],
  ['RÉSULTAT','Armatures longitudinales : '+Bb.n+' HA'+Bb.d+' ('+fx(Bb.as,2)+' cm²) ; cadres HA'+ph+' espacés de '+st+' cm']],warn:W,out:{}}}
/* ----- semelle isolée (feuilles « Semelle isolée_section béton / acier ») ----- */
function cFoot(v,n){var ns=(+v.ns)*1000,nu=(+v.nu)*1000,a0=+v.a,b0=+v.b,sol=+v.sol,pf=+v.prof;if(sol>=1)sol/=10;if(!(ns>0&&nu>0&&a0>0&&b0>0&&sol>0))return{rows:[],warn:['Renseignez Ns, Nu, le poteau et le sol.']};
 var gr=Math.max(a0,b0),pe=Math.min(a0,b0),den=sol*1e6-22000*(pf||0)/100,Sapp=1e4*ns/(den>0?den:sol*1e6),B=ceil5(Math.sqrt(Sapp*gr/pe)),A=ceil5(Math.sqrt(Sapp*pe/gr)),d1=(B-gr)/4,h=ceil5(d1)+5,pp=B/100*A/100*h/100*25000,sig=(pp+ns)/(B*10*A*10),W=[];
 var fsu=n.fe/1.15,d=h-5,dmin=(B-gr)/4,mj=fissOf(n)==='très préjudiciable'?1.5:fissOf(n)==='préjudiciable'?1.1:1,Ax=(nu/8)*(0.01/fsu)*(B-gr)/d*mj,Ay=(nu/8)*(0.01/fsu)*(A-pe)/d*mj,X=bars(Ax,3,10),Y=bars(Ay,3,10);
 if(sig>=sol)W.push('Contrainte sous semelle ≥ contrainte admise : augmenter A et B (par pas de 5 cm).');if(d<dmin)W.push('Condition de rigidité non satisfaite : augmenter h.');
 return{rows:[['Aire approchée','Sapp = Ns / (sigma sol − 22 kN/m³ × profondeur) = '+fx(Sapp,0)+' cm²'],['Dimensions','B × A × h = '+B+' × '+A+' × '+h+' cm ; d = '+d+' cm (dmin = '+fx(dmin,1)+' cm)'],['Contrainte sur le sol','Poids propre '+fx(pp/1000,1)+' kN ; sigma = '+fx(sig,3)+' MPa (admis '+fx(sol,3)+' MPa)'],
  ['Aciers (méthode des bielles)','Ax // B = '+fx(Ax,2)+' cm² ; Ay // A = '+fx(Ay,2)+' cm²'+(mj>1?' (majorées ×'+mj+')':'')],
  ['RÉSULTAT','Semelle '+B+' × '+A+' × '+h+' cm — nappe inférieure // B : '+X.n+' HA'+X.d+' ; nappe supérieure // A : '+Y.n+' HA'+Y.d]],warn:W,out:{}}}
/* ----- poutre (feuilles Flexion ELUR rect./TE, ELS, Vérification ELS, Effort tranchant) ----- */
function muCrit(gam,n,th){var fc=n.fc;if(fc>30||(n.fe!==500&&n.fe!==400))return null;var k=n.fe===500?[0.322,0.0051,0.31]:[0.344,0.0049,0.305];return (k[0]*gam+k[1]*fc-k[2])*(1-(1-th)/8.5)*th}
function flex(Mu,bw,d,n,gam){var th=theta(n),fbu=0.85*n.fc/(1.5*th),fsu=n.fe/1.15,mu=Mu*1e-3/((bw/100)*Math.pow(d/100,2)*fbu),mc=muCrit(gam,n,th),gen=false;
 if(mc==null){var al=3.5/(3.5+1000*fsu/200000);mc=0.8*al*(1-0.4*al);gen=true}
 var r={mu:mu,mc:mc,gen:gen,piv:mu<=0.186?'A':'B',ok:mu<=0.186||mu<=mc};if(r.ok){r.al=1.25*(1-Math.sqrt(1-2*mu));r.z=d*(1-0.4*r.al);r.As=Mu*1e-3/(fsu*r.z/100)*1e4}return r}
function ceil5(x){return Math.ceil(x/5-1e-9)*5}
function cBeam(v,n){var T=v.type==='té',b=+v.b,b0=T?+v.b0:b,h=+v.h,h0=+v.h0,L=+v.L,c=+n.enr||3,fe=n.fe,fc=n.fc,th=theta(n),fs=fissOf(n),W=[],R=[];
 if(!(b>0&&h>0&&L>0&&(!T||(b0>0&&h0>0&&b>=b0))))return{rows:[],warn:['Renseignez la section et la portée.'],out:{}};
 var pp=(T?b0*h+(b-b0)*h0:b*h)/1e4*25,gt=(+v.g||0)+pp,qu=1.35*gt+1.5*(+v.q||0),qs=gt+(+v.q||0),km=+v.km||0.125,
 Mu=+v.Mu>0?+v.Mu:qu*L*L*km,Ms=+v.Ms>0?+v.Ms:qs*L*L*km,Vu=+v.Vu>0?+v.Vu:qu*L/2,gam=Mu/Ms,d=T?h-c-5:Math.min(0.9*h,h-c-3),fbu=0.85*fc/(1.5*th),fsu=fe/1.15,ftj=0.6+0.06*fc;
 R.push(['Charges','Poids propre '+fx(pp,2)+' kN/m ; qu = '+fx(qu,2)+' kN/m ; qser = '+fx(qs,2)+' kN/m']);R.push(['Sollicitations','Mu = '+fx(Mu,2)+' kN.m ; Mser = '+fx(Ms,2)+' kN.m ; Vu = '+fx(Vu,2)+' kN ; d = '+d+' cm ; fbu = '+fx(fbu,2)+' MPa']);
 var Au=0,Amin=ftj/fe*0.23*d*b,sect='rect',f;
 if(T){var Bt=b0*h+(b-b0)*h0,vg=(b0*h*h+(b-b0)*h0*h0)/(2*Bt),Ig=b0*h*h*h/3+(b-b0)*h0*h0*h0/3-Bt*vg*vg,Mtu=(b/100)*(h0/100)*fbu*((d-h0/2)/100)*1e3;
  if(Mu<=Mtu)R.push(['Section en té','Mtu = '+fx(Mtu,1)+' kN.m ≥ Mu : table seule comprimée, calcul comme section rectangulaire b × h']);
  else{sect='te';Amin=Ig/(0.81*h*(d-vg))*ftj/fe;var Mu1=((b-b0)/100)*(h0/100)*fbu*((d-h0/2)/100)*1e3,Mu2=Mu-Mu1;f=flex(Mu2,b0,d,n,gam);
   R.push(['Section en té','Mtu = '+fx(Mtu,1)+' kN.m < Mu : table et nervure comprimées ; Mu1 = '+fx(Mu1,1)+' ; Mu2 = '+fx(Mu2,1)+' kN.m']);
   if(!f.ok)W.push('Nervure : mu2 = '+fx(f.mu,3)+' > mu critique '+fx(f.mc,3)+' : section de béton mal dimensionnée, augmenter b0 ou h.');
   else{var N1=(b-b0)*h0*fbu*100,N2=0.8*d*b0*fbu*100*f.al;Au=(N1+N2)/fsu*0.01;R.push(['Flexion (té)','mu2 = '+fx(f.mu,3)+' (pivot '+f.piv+') ; alpha2 = '+fx(f.al,3)+' ; Au = '+fx(Au,2)+' cm² ; As,min = '+fx(Amin,2)+' cm²'])}}}
 if(sect==='rect'){f=flex(Mu,b,d,n,gam);
  if(!f.ok)W.push('mu = '+fx(f.mu,3)+' > mu critique '+fx(f.mc,3)+' : section de béton mal dimensionnée, augmenter b ou h.');
  else{Au=f.As;R.push(['Flexion ELUR','mu = '+fx(f.mu,3)+' (pivot '+f.piv+') ; mu critique = '+fx(f.mc,3)+' ; alpha = '+fx(f.al,3)+' ; z = '+fx(f.z,1)+' cm ; Au = '+fx(Au,2)+' cm² ; As,min = '+fx(Amin,2)+' cm²'])}}
 if(f&&f.gen)W.push('fc28 > 30 MPa : mu critique calculé par la formule générale (hors tableau du classeur), à vérifier.');
 if(!(f&&f.ok))return{rows:R,warn:W.concat(['Armatures non calculées.']),out:{}};
 var Ase=0;if(fs!=='peu préjudiciable'&&sect==='rect'){var sst=fs==='très préjudiciable'?Math.min(0.5*fe,90*Math.sqrt(1.6*ftj)):Math.min(2*fe/3,110*Math.sqrt(1.6*ftj)),sbc=0.6*fc,al=15*sbc/(15*sbc+sst),K=sbc*al/2*(1-al/3),Ml=K*1e3*(b/100)*Math.pow(d/100,2),A0=Ms*1e-3/(sst*(d-al*d/3)/100)*1e4,y=(-15*A0+Math.sqrt(225*A0*A0+30*A0*b*d))/b;Ase=Ms*1e-3/(sst*(d-y/3)/100)*1e4;
  R.push(['Flexion ELS ('+fs+')','sigma-st = '+fx(sst,1)+' MPa ; Mlim = '+fx(Ml,1)+' kN.m ; Aser = '+fx(Ase,2)+' cm²']);if(Ml<=Ms)W.push('ELS : moment résistant du béton insuffisant, augmenter b ou h.')}
 var As=Math.max(Au,Ase,Amin),Bb=bars(As,2);if(As===Amin)W.push('Condition de non-fragilité : As,min imposée.');
 /* vérification ELS de la section choisie */
 var Ac=Bb.as,y1,I1,rect=!T||(b*h0*h0/2-15*Ac*(d-h0)>0);
 if(rect){y1=(-15*Ac+Math.sqrt(225*Ac*Ac+30*Ac*b*d))/b;I1=b*y1*y1*y1/3+15*Ac*Math.pow(d-y1,2)}
 else{var Aa=b0/2,Ab=(b-b0)*h0+15*Ac,Ac2=-(15*Ac*d+h0*h0*(b-b0)/2);y1=(-Ab+Math.sqrt(Ab*Ab-4*Aa*Ac2))/(2*Aa);I1=b*y1*y1*y1/3-(b-b0)*Math.pow(y1-h0,3)/3+15*Ac*Math.pow(d-y1,2)}
 var sb=Ms*1000*y1/I1,ss=15*Ms*1000*(d-y1)/I1,sbl=0.6*fc,ssl=fs==='peu préjudiciable'?fe:fs==='très préjudiciable'?Math.min(0.5*fe,90*Math.sqrt(1.6*ftj)):Math.min(2*fe/3,110*Math.sqrt(1.6*ftj));
 R.push(['Vérification ELS (section choisie)','y1 = '+fx(y1,2)+' cm ; sigma-bc = '+fx(sb,2)+' MPa (limite '+fx(sbl,1)+') ; sigma-st = '+fx(ss,1)+' MPa (limite '+fx(ssl,1)+')']);
 if(sb>sbl)W.push('ELS : contrainte du béton dépassée, redimensionner.');if(ss>ssl)W.push('ELS : contrainte de l\'acier dépassée, redimensionner.');
 /* effort tranchant */
 var tau=Vu*1e-3/((b0/100)*(d/100)),tl=fs==='peu préjudiciable'?Math.min(0.2*fc/1.5,5):Math.min(0.15*fc/1.5,4),tli=Math.min(0.27*fc/1.5,7),ft3=Math.min(ftj,3.3),
 dt=[6,8,10,12].filter(x=>x>=0.3*Bb.d&&x<=Math.min(b0,h*10/35,Bb.d)).shift()||6,At=Math.PI*dt*dt/400,Kb=(v.reprise==='oui'||fs==='très préjudiciable')?0:1,den=b0*(tau-0.3*Kb*ft3),
 St0=den>0?Math.floor(0.9*At*2*(fe/1.15)/den):999,Snf=At*2*fe/(0.4*b0),Smax=Math.min(40,0.9*d),st=Math.floor(Math.min(St0,Snf,Smax));
 R.push(['Effort tranchant','tau = '+fx(tau,2)+' MPa ; limite cadres droits '+fx(tl,2)+' MPa ; limite cadres inclinés '+fx(tli,2)+' MPa']);
 R.push(['Appuis d\'about','As ≥ Vu / fsu = '+fx(Vu*10/fsu,2)+' cm² ; profondeur d\'appui ≥ '+fx(3.75*Vu*10/(b0*fc),1)+' cm']);
 if(tau>tli)W.push('Cisaillement tau > '+fx(tli,2)+' MPa : redimensionner b0 et h.');else if(tau>tl)W.push('tau > '+fx(tl,2)+' MPa : armatures transversales inclinées à 45° nécessaires.');
 if(st<7)W.push('Espacement des cadres < 7 cm : redimensionner b0 et h.');if(h<L*100/16)W.push('h < L/16 : vérifier la flèche (non calculée).');
 W.push('Moments sur appuis, flèche et arrêts de barres non calculés : à compléter par l\'ingénieur.');
 R.push(['RÉSULTAT','Aciers tendus : '+Bb.n+' HA'+Bb.d+' ('+fx(Bb.as,2)+' cm²) ; cadres HA'+dt+' (2 brins), premier espacement '+st+' cm']);
 return{rows:R,warn:W,out:{}}}
function calc(e,n){return e.type==='dc'?cDC(e):e.type==='col'?cCol(e.v,n):e.type==='foot'?cFoot(e.v,n):cBeam(e.v,n)}
var resHtml=r=>(r.rows.length?`<table class="exb-table"><tbody>${r.rows.map(x=>`<tr><td><b>${esc(x[0])}</b></td><td>${esc(x[1])}</td></tr>`).join('')}</tbody></table>`:'')+r.warn.map(w=>`<p style="color:#b45309;margin:4px 0">⚠ ${esc(w)}</p>`).join('');
function newEl(t){var e={id:exbId('EL'),type:t,name:SPEC[t].lab.replace(/^\S+\s/,'')+' '+(ST.d.els.length+1),v:{}};if(t==='dc'){e.v={pp:0};e.lv=[{n:'Toiture',g:6,q:1,s:20},{n:'Étage 1',g:6,q:2.5,s:20},{n:'RDC',g:6,q:2.5,s:20}]}else SPEC[t].f.forEach(f=>e.v[f[0]]=f[2]);return e}

/* =================== NOTES DE CALCUL =================== */
function vNotes(){var d=ST.kind==='cn'?ST.d:null,h='';
 if(d){h+=`<div class="exb-card"><h3>Note de calcul ${esc(d.no)}</h3><div class="exb-grid"><div><label>Projet</label><select onchange="EXBET.f('project_id',this.value)">${popt(d.project_id)}</select></div><div><label>Titre *</label>${inp(d.title,"f('title',§)")}</div><div><label>Date</label><input type="date" value="${esc(d.date)}" oninput="EXBET.f('date',this.value)"></div><div><label>Établi par</label>${inp(d.author,"f('author',§)")}</div>
 <div><label>Béton fc28 (MPa)</label>${sel(d.fc,[20,25,30,35],"f('fc',+§)")}</div><div><label>Acier fe (MPa)</label>${sel(d.fe,[400,500],"f('fe',+§)")}</div><div><label>Enrobage (cm)</label>${inp(d.enr,"f('enr',+§)",1)}</div><div><label>Fissuration</label>${sel(d.fiss||FISS[0],FISS,"f('fiss',§)")}</div><div><label>Durée d'application des charges</label>${sel(d.t||DUR[0],DUR,"f('t',§)")}</div></div>`;
  d.els.forEach((e,i)=>{h+=`<div class="exb-card" style="border-left:4px solid #1a3a6b"><h3>${SPEC[e.type].lab} ${inp(e.name,"en("+i+",§)",0,'60%')} ${btn('×','delEl('+i+')','danger')}</h3>`;
   if(e.type==='dc'){h+=`<label>Poids propre poteau par niveau (kN)</label>${inp(e.v.pp,"ef("+i+",'pp',§)",1,'90px')}<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Niveau</th><th>G (kN/m²)</th><th>Q (kN/m²)</th><th>Surface (m²)</th><th>Préréglages</th><th></th></tr></thead><tbody>${e.lv.map((l,j)=>`<tr><td>${inp(l.n,"lv("+i+","+j+",'n',§)",0,'100px')}</td><td>${inp(l.g,"lv("+i+","+j+",'g',§,1)",1,'65px')}</td><td>${inp(l.q,"lv("+i+","+j+",'q',§,1)",1,'65px')}</td><td>${inp(l.s,"lv("+i+","+j+",'s',§,1)",1,'70px')}</td><td>${sel('',GP,"preset("+i+","+j+",'g',§)")}${sel('',QP,"preset("+i+","+j+",'q',§)")}</td><td>${btn('×','delLv('+i+','+j+')','danger')}</td></tr>`).join('')}</tbody></table></div><div class="exb-actions">${btn('➕ Niveau','addLv('+i+')')}${btn('➡ Créer poteau + semelle avec ce résultat','fromDc('+i+')')}</div>`}
   else h+=`<div class="exb-grid">${SPEC[e.type].f.filter(f=>!((e.type==='beam'&&e.v.type!=='té'&&(f[0]==='b0'||f[0]==='h0'))||(e.type==='col'&&e.v.forme==='circulaire'&&f[0]==='b'))).map(f=>`<div><label>${f[1]}</label>${f[3]?sel(e.v[f[0]],f[3],"ef("+i+",'"+f[0]+"',§,"+(typeof f[2]==='number'?1:0)+")"):inp(e.v[f[0]],"ef("+i+",'"+f[0]+"',§,1)",1)}</div>`).join('')}</div>`;
   h+=`<div id="exbe_r${i}">${resHtml(calc(e,d))}</div></div>`});
  h+=`<div class="exb-actions">${Object.keys(SPEC).map(t=>btn('➕ '+SPEC[t].lab,"addEl('"+t+"')")).join('')}</div><div class="exb-actions">${btn('💾 Enregistrer','saveNote()','primary')}${btn('📄 PDF','pdfNote()')}${btn('Fermer','cancel()')}</div></div>`}
 else h+=`<div class="exb-actions">${btn('➕ Nouvelle note de calcul',"newNote()",'primary')}</div><p class="exb-muted">Formules du classeur Metrec 2026 (BAEL 91 mod. 99). Les résultats sont une aide au dimensionnement : à vérifier et signer par l'ingénieur responsable.</p>`;
 var A=L('cn').filter(x=>!ST.pid||x.project_id===ST.pid).slice().reverse();
 return h+(A.length?`<div class="exb-scroll"><table class="exb-table"><thead><tr><th>N°</th><th>Titre</th><th>Projet</th><th>Éléments</th><th></th></tr></thead><tbody>${A.map(x=>`<tr><td>${esc(x.no)}<br><small>${esc(x.date)}</small></td><td>${esc(x.title)}</td><td>${esc(pname(x.project_id))}</td><td>${x.els.length}</td><td>${btn('Ouvrir',"editNote('"+x.id+"')")}${btn('📄',"pdfNote('"+x.id+"')")}${btn('⧉',"dupNote('"+x.id+"')")}${btn('×',"delNote('"+x.id+"')",'danger')}</td></tr>`).join('')}</tbody></table></div>`:'<p class="exb-muted">Aucune note de calcul.</p>')}
function upd(i){var e=$('exbe_r'+i);if(e)e.innerHTML=resHtml(calc(ST.d.els[i],ST.d))}
function updAll(){ST.d.els.forEach((e,i)=>upd(i))}
function notePdf(x){var r=[['Projet',pname(x.project_id)],['Note de calcul',x.no+' — '+x.title],['Date / établi par',x.date+' — '+(x.author||'—')],['Matériaux','Béton fc28 = '+x.fc+' MPa ; acier fe = '+x.fe+' MPa ; enrobage poutres '+x.enr+' cm'],['Règlement','BAEL 91 modifié 99 — formules du classeur Metrec 2026 (© Ibwampere Ngwala Louis) ; fissuration : '+(x.fiss||FISS[0])+' ; charges : '+(x.t||DUR[0])]];
 x.els.forEach(e=>{var c=calc(e,x);r.push([SPEC[e.type].lab.replace(/^\S+\s/,'')+' — '+e.name,c.rows.map(z=>z[0]+' : '+z[1]).join('\n')||'Données incomplètes']);
  if(e.type!=='dc')r.push(['Données',Object.keys(e.v).map(k=>k+' = '+e.v[k]).join(' ; ')])});
 var w=[];x.els.forEach(e=>calc(e,x).warn.forEach(t=>w.push('Attention ('+e.name+') : '+t)));
 var san=t=>String(t).replace(/≥/g,'>=').replace(/≤/g,'<=').replace(/−/g,'-');r=r.map(z=>[san(z[0]),san(z[1])]);
 return EXBPdf.make({titre:'NOTE DE CALCUL '+x.no,sousTitre:x.title+' — '+pname(x.project_id),rows:r,notes:w.map(san).concat(['Résultats à vérifier par l\'ingénieur responsable avant exécution.','Établi par : '+(x.author||'________')+'      Vérifié par : ________      Visa : ________']),footer:'Note '+x.no+' — Excellencia Building'})}

/* =================== PLANS & VISAS =================== */
var VISA=['En attente','Pour information','Visé sans observation','Visé avec observations','Refusé'],DISC=['Architecture','Structure','Électricité','Plomberie','Voirie / VRD','Autre'],ROLE=['Client','Maître d\'œuvre','Entreprise','Bureau de contrôle','Autre'];
function planSt(p,i){var v=p.versions[i];if(i<p.versions.length-1)return'Périmée';var s=(v.sent||[]).filter(x=>x.visa!=='Pour information');if(!(v.sent||[]).length)return'Non diffusé';if(s.some(x=>x.visa==='Refusé'))return'À reprendre';if(s.some(x=>x.visa==='En attente'))return'En circulation';return s.some(x=>x.visa==='Visé avec observations')?'Validé avec observations':'Validé'}
var BC={'Validé':'#15803d','Validé avec observations':'#a16207','En circulation':'#1d4ed8','À reprendre':'#b91c1c','Périmée':'#6b7280','Non diffusé':'#6b7280'};
var badge=t=>`<span class="exb-badge" style="background:${BC[t]||'#6b7280'};color:#fff">${esc(t)}</span>`;
var nextInd=p=>{var n=p.versions.length;return n<26?String.fromCharCode(65+n):'Z'+n};
function vPlans(){var P=L('pl'),h='',d=ST.kind==='pl'?ST.d:null,sp=ST.sel?P.find(x=>x.id===ST.sel):null;
 if(d)h+=`<div class="exb-card"><h3>Plan</h3><div class="exb-grid"><div><label>Projet *</label><select onchange="EXBET.f('project_id',this.value)">${popt(d.project_id)}</select></div><div><label>N° du plan *</label>${inp(d.no,"f('no',§)")}</div><div><label>Titre *</label>${inp(d.title,"f('title',§)")}</div><div><label>Discipline</label>${sel(d.disc,DISC,"f('disc',§)")}</div><div><label>Échelle / format</label>${inp(d.scale,"f('scale',§)")}</div></div><div class="exb-actions">${btn('💾 Enregistrer','savePlan()','primary')}${btn('Annuler','cancel()')}</div></div>`;
 else h+=`<div class="exb-actions">${btn('➕ Nouveau plan','newPlan()','primary')}</div>`;
 var A=P.filter(x=>!ST.pid||x.project_id===ST.pid);
 h+=A.length?`<div class="exb-scroll"><table class="exb-table"><thead><tr><th>N°</th><th>Titre</th><th>Projet</th><th>Indice</th><th>Statut</th><th></th></tr></thead><tbody>${A.map(x=>{var i=x.versions.length-1;return `<tr><td>${esc(x.no)}</td><td>${esc(x.title)}<br><small>${esc(x.disc)}</small></td><td>${esc(pname(x.project_id))}</td><td>${i>=0?esc(x.versions[i].ind):'—'}</td><td>${i>=0?badge(planSt(x,i)):'—'}</td><td>${btn('Ouvrir',"open('"+x.id+"')")}${btn('×',"delPlan('"+x.id+"')",'danger')}</td></tr>`}).join('')}</tbody></table></div>`:'<p class="exb-muted">Aucun plan.</p>';
 if(sp){h+=`<div class="exb-card"><h3>${esc(sp.no)} — ${esc(sp.title)}</h3><div class="exb-actions">${btn('✏️ Modifier',"editPlan('"+sp.id+"')")}${btn('➕ Nouvelle version',"newVer()",'primary')}</div>`;
  if(ST.vi===-2)h+=`<div class="exb-grid"><div><label>Indice</label><input value="${esc(ST.d.ind)}" disabled></div><div><label>Date</label><input type="date" value="${esc(ST.d.date)}" oninput="EXBET.vf('date',this.value)"></div><div><label>Modifications</label>${inp(ST.d.desc,"vf('desc',§)")}</div><div><label>Établi par</label>${inp(ST.d.by,"vf('by',§)")}</div></div><div class="exb-actions">${btn('💾 Créer la version','saveVer()','primary')}${btn('Annuler','cancel()')}</div>`;
  sp.versions.slice().reverse().forEach((v,r)=>{var i=sp.versions.length-1-r;h+=`<div class="exb-card"><h4>Indice ${esc(v.ind)} ${badge(planSt(sp,i))} <small>${esc(v.date)} — ${esc(v.desc||'')} ${v.by?'('+esc(v.by)+')':''}</small></h4>`;
   if((v.sent||[]).length)h+=`<div class="exb-scroll"><table class="exb-table"><thead><tr><th>Destinataire</th><th>Envoi</th><th>Visa</th><th>Date visa</th><th>Observations</th><th></th></tr></thead><tbody>${v.sent.map((s,j)=>`<tr><td>${esc(s.to)}<br><small>${esc(s.role)}</small></td><td>${esc(s.date)}</td><td>${sel(s.visa,VISA,"visa("+i+","+j+",§)")}</td><td>${esc(s.vdate||'')}</td><td>${inp(s.obs,"obs("+i+","+j+",§)",0,'130px')}</td><td>${btn('×',"delSent("+i+","+j+")",'danger')}</td></tr>`).join('')}</tbody></table></div>`;
   h+=`<div class="exb-actions"><input id="exbe_to${i}" list="exbe_cl" placeholder="Destinataire" style="width:150px">${sel('Client',ROLE,"role(§)")}<button class="muted" onclick="EXBET.send(${i})">📤 Diffuser</button>${btn('📄 Bordereau',"bord("+i+")")}</div></div>`});
  h+=`<datalist id="exbe_cl">${(typeof exbClients!=='undefined'?exbClients:[]).map(c=>`<option value="${esc(c.name)}">`).join('')}</datalist></div>`}
 return h}

/* =================== HEURES & HONORAIRES =================== */
function mCalc(mi){var T=L('tm').filter(x=>x.mission_id===mi.id),p=proj(mi.project_id),h=T.reduce((a,x)=>a+(+x.h||0),0),cost=T.reduce((a,x)=>a+(+x.h||0)*(+x.rate||0),0),
 hon=mi.mode==='forfait'?+mi.amount||0:mi.mode==='pct'?((p&&+p.budget)||0)*(+mi.pct||0)/100:h*(+mi.taux||0),acq=mi.mode==='horaire'?hon:hon*(+mi.avance||0)/100;
 return{h:h,cost:cost,hon:hon,acq:acq,du:acq-(+mi.billed||0),marge:acq-cost,T:T}}
var MODE=[['forfait','Forfait ($)'],['pct','% du budget du projet'],['horaire','Au temps passé ($/h)']];
function vHeures(){var M=L('mi').filter(x=>!ST.pid||x.project_id===ST.pid),h='',d=ST.kind==='mi'?ST.d:null,tot={h:0,acq:0,cost:0,marge:0};
 M.forEach(x=>{var c=mCalc(x);tot.h+=c.h;tot.acq+=c.acq;tot.cost+=c.cost;tot.marge+=c.marge});
 h+=`<div class="exb-grid"><div class="exb-card"><b>${fx(tot.h,1)} h</b><br><small>Heures</small></div><div class="exb-card"><b>${fx(tot.acq)} $</b><br><small>Honoraires acquis</small></div><div class="exb-card"><b>${fx(tot.cost)} $</b><br><small>Coût du temps</small></div><div class="exb-card"><b style="color:${tot.marge<0?'#b91c1c':'#15803d'}">${fx(tot.marge)} $</b><br><small>Marge</small></div></div>`;
 if(d)h+=`<div class="exb-card"><h3>Mission</h3><div class="exb-grid"><div><label>Projet *</label><select onchange="EXBET.f('project_id',this.value)">${popt(d.project_id)}</select></div><div><label>Intitulé *</label>${inp(d.title,"f('title',§)")}</div><div><label>Mode d'honoraires</label>${sel(d.mode,MODE,"f('mode',§,0,1)")}</div>
 <div><label>${d.mode==='forfait'?'Montant forfaitaire ($)':d.mode==='pct'?'Pourcentage (%)':'Taux horaire facturé ($/h)'}</label>${inp(d.mode==='forfait'?d.amount:d.mode==='pct'?d.pct:d.taux,"f('"+(d.mode==='forfait'?'amount':d.mode==='pct'?'pct':'taux')+"',+§)",1)}</div>${d.mode!=='horaire'?`<div><label>Avancement (%)</label>${inp(d.avance,"f('avance',+§)",1)}</div>`:''}<div><label>Budget d'heures</label>${inp(d.hbud,"f('hbud',+§)",1)}</div></div><div class="exb-actions">${btn('💾 Enregistrer','saveMi()','primary')}${btn('Annuler','cancel()')}</div></div>`;
 else h+=`<div class="exb-actions">${btn('➕ Nouvelle mission','newMi()','primary')}</div>`;
 M.forEach(x=>{var c=mCalc(x),over=+x.hbud>0&&c.h>+x.hbud;h+=`<div class="exb-card"><h3>${esc(x.title)} <small>— ${esc(pname(x.project_id))}</small></h3><p>Honoraires : <b>${fx(c.hon)} $</b> · acquis <b>${fx(c.acq)} $</b> · facturé ${fx(x.billed)} $ · <b>à facturer ${fx(c.du)} $</b><br>Heures : <b style="color:${over?'#b91c1c':'inherit'}">${fx(c.h,1)}${+x.hbud>0?' / '+fx(x.hbud,0):''} h</b>${over?' ⚠ budget d\'heures dépassé':''} · coût ${fx(c.cost)} $ · marge ${fx(c.marge)} $</p>
  <div class="exb-actions">${btn('➕ Heures',"addT('"+x.id+"')",'primary')}${btn('🧾 Facturer',"inv('"+x.id+"')")}${btn('📄 Relevé',"pdfMi('"+x.id+"')")}${btn('✏️',"editMi('"+x.id+"')")}${btn('×',"delMi('"+x.id+"')",'danger')}</div>
  ${c.T.length?`<div class="exb-scroll"><table class="exb-table"><tbody>${c.T.slice().sort((a,b)=>a.date<b.date?1:-1).slice(0,8).map(t=>`<tr><td>${esc(t.date)}</td><td>${esc(t.who)}</td><td>${fx(t.h,1)} h</td><td>${esc(t.note)}</td><td>${btn('×',"delT('"+t.id+"')",'danger')}</td></tr>`).join('')}</tbody></table></div>`:''}</div>`});
 return h+`<datalist id="exbe_hr">${(typeof exbHr!=='undefined'?exbHr:[]).map(w=>`<option value="${esc(w.name)}">`).join('')}</datalist>`}

/* =================== ACTIONS =================== */
function head(){var T=[['c','🧮 Notes de calcul'],['p','📐 Plans & visas'],['h','⏱ Heures & honoraires']];return `<div class="exb-actions" style="flex-wrap:wrap">${T.map(x=>`<button class="${x[0]===ST.tab?'primary':'muted'}" onclick="EXBET.tab('${x[0]}')">${x[1]}</button>`).join('')}</div><label>Projet</label><select onchange="EXBET.pid(this.value)">${popt(ST.pid)}</select>`}
function render(){var b=$('exbe_box');if(!b)return;b.innerHTML=head()+(ST.tab==='c'?vNotes():ST.tab==='p'?vPlans():vHeures())}
var role='Client';
var A={render:render,_calc:calc,
 tab:t=>{ST.tab=t;ST.d=null;ST.kind='';ST.sel='';render()},pid:v=>{ST.pid=v;render()},cancel:()=>{ST.d=null;ST.kind='';ST.vi=-1;render()},
 f:(k,v,n,rr)=>{ST.d[k]=n?(+v||0):v;if(ST.kind==='cn')updAll();if(rr)render()},
 /* notes */
 newNote:()=>{ST.kind='cn';ST.d={id:exbId('NC'),no:num('NC',L('cn')),project_id:ST.pid,title:'',date:today(),author:'',fc:25,fe:500,enr:3,fiss:FISS[0],t:DUR[0],els:[]};render()},
 editNote:id=>{var x=L('cn').find(a=>a.id===id);if(x){ST.kind='cn';ST.d=clone(x);render()}},
 dupNote:id=>{var x=L('cn').find(a=>a.id===id);if(!x)return;var c=clone(x);c.id=exbId('NC');c.no=num('NC',L('cn'));c.date=today();c.title+=' (copie)';upsert('cn',c);say('Note dupliquée : '+c.no,'success');render()},
 delNote:async id=>{if((await exbConfirm('Supprimer cette note de calcul ?'))){S('cn',L('cn').filter(x=>x.id!==id));render()}},
 addEl:t=>{ST.d.els.push(newEl(t));render()},delEl:i=>{ST.d.els.splice(i,1);render()},en:(i,v)=>{ST.d.els[i].name=v},
 ef:(i,k,v,n)=>{ST.d.els[i].v[k]=n?(+v||0):v;if(k==='type'||k==='forme')render();else upd(i)},lv:(i,j,k,v,n)=>{ST.d.els[i].lv[j][k]=n?(+v||0):v;upd(i)},
 preset:(i,j,k,v)=>{if(v!=='')ST.d.els[i].lv[j][k]=+v;render()},
 addLv:i=>{ST.d.els[i].lv.push({n:'Niveau',g:6,q:2.5,s:20});render()},delLv:(i,j)=>{ST.d.els[i].lv.splice(j,1);render()},
 fromDc:i=>{var o=cDC(ST.d.els[i]).out;if(!(o.nu>0))return say('Descente de charges vide.','warn');var c=newEl('col'),s=newEl('foot');c.v.nu=+o.nu.toFixed(1);s.v.ns=+o.ns.toFixed(1);s.v.nu=+o.nu.toFixed(1);ST.d.els.push(c,s);say('Poteau et semelle créés.','success');render()},
 saveNote:()=>{var d=ST.d;if(!d.title.trim())return say('Le titre est obligatoire.','warn');upsert('cn',d);say('Note enregistrée.','success');ST.kind='';ST.d=null;render()},
 pdfNote:id=>{var x=id?L('cn').find(a=>a.id===id):ST.d;if(!x)return;notePdf(x).then(b=>EXBPdf.save(b,x.no+'.pdf'))},
 /* plans */
 newPlan:()=>{ST.kind='pl';ST.sel='';ST.d={id:exbId('PL'),project_id:ST.pid,no:'',title:'',disc:'Architecture',scale:'1/100 — A1',versions:[]};render()},
 editPlan:id=>{var x=L('pl').find(a=>a.id===id);if(x){ST.kind='pl';ST.d=clone(x);render()}},
 savePlan:()=>{var d=ST.d;if(!d.project_id||!d.no.trim()||!d.title.trim())return say('Projet, N° et titre sont obligatoires.','warn');upsert('pl',d);ST.sel=d.id;ST.kind='';ST.d=null;say('Plan enregistré.','success');render()},
 delPlan:async id=>{if((await exbConfirm('Supprimer ce plan et tout son historique ?'))){if(AR())AR().deletePlan(id);else S('pl',L('pl').filter(x=>x.id!==id));ST.sel='';render()}},
 open:id=>{ST.sel=id;ST.d=null;ST.kind='';ST.vi=-1;render()},
 newVer:()=>{var p=L('pl').find(x=>x.id===ST.sel);ST.vi=-2;ST.d={ind:nextInd(p),date:today(),desc:'',by:''};render()},
 vf:(k,v)=>{ST.d[k]=v},
 saveVer:()=>{var p=L('pl').find(x=>x.id===ST.sel);p.versions.push(Object.assign({sent:[]},ST.d));upsert('pl',p);ST.vi=-1;ST.d=null;say('Indice '+p.versions[p.versions.length-1].ind+' créé : les précédents sont périmés.','success');render()},
 role:v=>{role=v},
 send:i=>{var to=$('exbe_to'+i).value.trim();if(!to)return say('Indiquez le destinataire.','warn');var p=L('pl').find(x=>x.id===ST.sel);p.versions[i].sent.push({to:to,role:role,date:today(),visa:'En attente',vdate:'',obs:''});upsert('pl',p);render()},
 visa:(i,j,v)=>{var p=L('pl').find(x=>x.id===ST.sel),s=p.versions[i].sent[j];s.visa=v;s.vdate=v==='En attente'?'':today();upsert('pl',p);render()},
 obs:(i,j,v)=>{var p=L('pl').find(x=>x.id===ST.sel);p.versions[i].sent[j].obs=v;upsert('pl',p)},
 delSent:(i,j)=>{var p=L('pl').find(x=>x.id===ST.sel);p.versions[i].sent.splice(j,1);upsert('pl',p);render()},
 bord:i=>{var p=L('pl').find(x=>x.id===ST.sel),v=p.versions[i];EXBPdf.make({titre:'BORDEREAU D\'ENVOI',sousTitre:pname(p.project_id)+' — '+p.no,rows:[['Plan',p.no+' — '+p.title],['Discipline / échelle',p.disc+' — '+p.scale],['Indice / date',v.ind+' — '+v.date],['Modifications',v.desc||'Première émission'],['Établi par',v.by||'—'],['Destinataires',(v.sent||[]).map(s=>s.to+' ('+s.role+') — '+s.visa+(s.obs?' : '+s.obs:'')).join('\n')||'—']],notes:['Merci de retourner le plan visé sous 7 jours. Les indices précédents sont périmés.'],footer:'Plan '+p.no+' ind. '+v.ind+' — Excellencia Building'}).then(b=>EXBPdf.save(b,'bordereau-'+p.no+'-'+v.ind+'.pdf'))},
 /* heures & honoraires */
 newMi:()=>{ST.kind='mi';ST.d={id:exbId('MI'),project_id:ST.pid,title:'',mode:'forfait',amount:0,pct:5,taux:50,avance:0,hbud:0,billed:0};render()},
 editMi:id=>{var x=L('mi').find(a=>a.id===id);if(x){ST.kind='mi';ST.d=clone(x);render()}},
 saveMi:()=>{var d=ST.d;if(!d.project_id||!d.title.trim())return say('Projet et intitulé obligatoires.','warn');upsert('mi',d);ST.kind='';ST.d=null;say('Mission enregistrée.','success');render()},
 delMi:async id=>{if((await exbConfirm('Supprimer la mission et ses heures ?'))){S('mi',L('mi').filter(x=>x.id!==id));S('tm',L('tm').filter(x=>x.mission_id!==id));render()}},
 addT:async id=>{var who=(await exbPrompt('Collaborateur :')),hrs=who&&+String((await exbPrompt('Nombre d\'heures :','1'))).replace(',','.');if(!who||!(hrs>0))return;var w=(typeof exbHr!=='undefined'?exbHr:[]).find(x=>x.name===who),rate=w&&w.salary?+(w.salary/26/8).toFixed(2):+((await exbPrompt('Coût horaire ($/h) :','5'))||0),note=(await exbPrompt('Tâche (facultatif) :',''))||'';
  upsert('tm',{id:exbId('TM'),mission_id:id,date:today(),who:who,h:hrs,rate:rate,note:note});say('Heures enregistrées.','success');render()},
 delT:id=>{S('tm',L('tm').filter(x=>x.id!==id));render()},
 inv:async id=>{var mi=L('mi').find(x=>x.id===id),c=mCalc(mi);if(!(c.du>0.005))return say('Rien à facturer pour l\'instant (avancement ou heures à mettre à jour).','info');if(!(await exbConfirm('Créer une facture d\'honoraires de '+fx(c.du)+' $ ?')))return;
  var inv;try{inv=load('exb_invoices',[])}catch(e){inv=[]}var p=proj(mi.project_id),y=new Date().getFullYear(),no='FAC-'+y+'-'+String(inv.filter(i=>String(i.no||'').indexOf('FAC-'+y)===0).length+1).padStart(3,'0'),dd=new Date();dd.setDate(dd.getDate()+30);
  inv.push({id:exbId('FAC'),no:no,project_id:mi.project_id,client:p&&p.client||'',date:today(),due:dd.toISOString().slice(0,10),tva:16,currency:'USD',lines:[{d:'Honoraires — '+mi.title+(mi.mode==='horaire'?' ('+fx(c.h,1)+' h)':' (avancement '+mi.avance+' %)'),u:'forfait',q:1,pu:+c.du.toFixed(2)}],payments:[],note:'Mission '+mi.title,mission_id:mi.id});save('exb_invoices',inv);
  mi.billed=+((+mi.billed||0)+c.du).toFixed(2);upsert('mi',mi);say('Facture '+no+' créée (Chantiers & finances › Factures).','success');render()},
 pdfMi:id=>{var mi=L('mi').find(x=>x.id===id),c=mCalc(mi);EXBPdf.make({titre:'RELEVÉ D\'HEURES ET HONORAIRES',sousTitre:mi.title+' — '+pname(mi.project_id),rows:[['Honoraires',fx(c.hon)+' $ ('+(MODE.find(m=>m[0]===mi.mode)||[])[1]+')'],['Acquis / facturé / à facturer',fx(c.acq)+' / '+fx(mi.billed)+' / '+fx(c.du)+' $'],['Heures',fx(c.h,1)+' h'+(+mi.hbud>0?' sur '+fx(mi.hbud,0)+' prévues':'')],['Détail',c.T.slice().sort((a,b)=>a.date<b.date?-1:1).map(t=>t.date+' — '+t.who+' — '+fx(t.h,1)+' h'+(t.note?' — '+t.note:'')).join('\n')||'—']],footer:'Mission '+mi.title+' — Excellencia Building'}).then(b=>EXBPdf.save(b,'releve-heures.pdf'))}
};
window.EXBET=A;
function mount(){if($('etudes3'))return;var ref=$('bureauEtudes')||$('projets'),host=document.querySelector('.wrap')||document.querySelector('main')||document.body,s=document.createElement('section');s.id='etudes3';s.style.display='none';
 s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>🧮 Études techniques</h2><p class="exb-muted">Notes de calcul imprimables, gestion des plans (versions, diffusion, visas) et suivi des heures et honoraires.</p></div></div><div id="exbe_box"></div></div>';
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
 var b=$('bbet');if(b&&!$('bete3')){var n=document.createElement('button');n.id='bete3';n.textContent='🧮 Études techniques';n.onclick=function(){show('etudes3')};b.parentNode.insertBefore(n,b.nextSibling)}
 var os=window.show;if(typeof os==='function'&&!window.__exbEtShow){window.__exbEtShow=1;window.show=function(x){var r=os.apply(this,arguments),e=$('etudes3');if(e)e.style.display=(x==='etudes3')?'':'none';if(x==='etudes3')render();return r}}
 render()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(mount,600)});else setTimeout(mount,600);
})();
