/* Excellencia Building V99w — Apparence : thème Doux et Auto (jour/nuit), couleur d'accent, luminosité de l'écran,
 * filigrane Excellencia Building derrière tous les écrans. S'appuie sur exb-theme.js (clair/sombre) sans le remplacer :
 * le bouton soleil/lune garde son rôle, le bouton 🎨 ouvre le panneau complet.
 * Réglages enregistrés sur l'appareil sous « exb_appearance » (la clé « exb_theme » reste réservée à exb-theme.js).
 * Écran uniquement : filigrane et luminosité ne sont jamais imprimés ni exportés en PDF. Aucune donnée n'est modifiée.
 * Pour retirer : supprimer la balise <script src="exb-v99w-appearance.js"> d'index.html. */
(function(w,d){'use strict';
var KEY='exb_appearance',DEF={mode:'light',accent:'blue',dim:0,wm:true};
var ACC={blue:['#1f6feb','#0f2e66','Bleu'],green:['#16a34a','#0b3d2e','Vert'],gold:['#b8860b','#4a3510','Or'],violet:['#7c3aed','#2e1a5c','Violet'],red:['#d92d27','#5c1414','Rouge']};
var MODES=[['light','☀️','Clair'],['soft','🌤️','Doux'],['dark','🌙','Sombre'],['auto','🕒','Auto']];
var $=function(i){return d.getElementById(i)},root=d.documentElement,busy=false,S=load();
function rawTheme(){try{return w.localStorage.getItem('exb_theme')}catch(e){return null}}
function load(){var s=null;try{s=JSON.parse(w.localStorage.getItem(KEY)||'null')}catch(e){}
 if(!s)return {mode:rawTheme()==='dark'?'dark':DEF.mode,accent:DEF.accent,dim:0,wm:true};
 return {mode:MODES.some(function(m){return m[0]===s.mode})?s.mode:DEF.mode,accent:ACC[s.accent]?s.accent:DEF.accent,dim:Math.max(0,Math.min(40,+s.dim||0)),wm:s.wm!==false}}
function save(){try{w.localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
function base(){if(S.mode==='auto'){var h=new Date().getHours();return h>=6&&h<18?'light':'dark'}return S.mode==='dark'?'dark':'light'}
var CSS='\
html{--xacc:#1f6feb;--xnav:#0f2e66}\
@media screen{\
html[data-exb-accent]:not([data-exb-theme=dark]) #app>header{background:var(--xnav)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) .xh-hero{background:var(--xnav)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) .xh-hl{background:linear-gradient(90deg,color-mix(in srgb,var(--xnav) 85%,transparent) 0%,color-mix(in srgb,var(--xnav) 65%,transparent) 38%,transparent 72%)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) .xh-btn{background:var(--xacc)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) #exbSide .xs.on{color:var(--xacc)!important;background:color-mix(in srgb,var(--xacc) 14%,#fff)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) :is(.xh-k small a,.xh-card h3 a){color:var(--xacc)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) :is(.xh-k:hover,.xg .c:hover,.xh-qa .q:hover){border-color:var(--xacc)!important}\
html[data-exb-accent]:not([data-exb-theme=dark]) #exbCrumb button{color:var(--xacc)!important;background:color-mix(in srgb,var(--xacc) 14%,#fff)!important}\
html[data-exb-soft=on]:not([data-exb-theme=dark]){--sbg:#ebe5d6;--scard:#f8f4ea;--stx:#2e2b26;--smut:#7a7264;--sbd:#d9cfba;--sinp:#fffdf7;--shead:#efe6d2}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) :is(body,#app){background:var(--sbg)!important;color:var(--stx)}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) :is(#app .card,#app .stat,.xh-card,.xh-k,.xg .c,.xh-qa .q,.xh-date,#exbSide,#exbStatus,.xmenu,.xm-b,#xbApPanel){background:var(--scard)!important;color:var(--stx);border-color:var(--sbd)!important}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) :is(.xh-head h1,.xh-card h3,.xh-k b,.xg .c b,.xh-qa .q b,#exbHub,#exbHub h1,#app .card h2,#app .card h3,#exbSide .xs){color:var(--stx)}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) :is(.xh-head p,.xh-crumb,.xh-k small,.xh-k em,.xh-act small,.xh-act time,.xg .c small,.xh-qa .q small,#exbCrumb,#exbStatus,.xsf,.hint){color:var(--smut)}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) #exbSide .xs:hover{background:var(--shead)!important}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) #app :is(input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=color]):not([type=file]),select,textarea){background:var(--sinp);border-color:var(--sbd);color:var(--stx)}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) #app :is(.tbl th,.tablewrap th,section .card table th){background:var(--shead)!important;color:var(--stx)}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) #app :is(.tbl td,.tablewrap td,section .card table td){border-color:var(--sbd)}\
html[data-exb-soft=on]:not([data-exb-theme=dark]) .xh-lg{background:var(--shead)!important}\
.xbAp{position:relative;display:inline-block}#xbAppear{display:grid;place-items:center;width:38px;height:38px;padding:0;font-size:19px}\
#xbApPanel{display:none;position:absolute;right:0;top:50px;width:290px;max-width:calc(100vw - 20px);background:#fff;color:#12254a;border:1px solid #e3e9f4;border-radius:14px;box-shadow:0 14px 36px #0004;padding:14px;z-index:90;text-align:left}#xbApPanel.on{display:block}\
html[data-exb-theme=dark] #xbApPanel{background:#17223c;color:#e4e9f3;border-color:#2a3a58}\
#xbApPanel h4{margin:0 0 8px;font-size:15px}#xbApPanel .lb{font-size:12px;opacity:.7;margin:12px 0 6px;font-weight:700}\
.xa-m{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.xa-m button{display:flex;flex-direction:column;align-items:center;gap:3px;border:2px solid #e3e9f4;background:#f3f6fc;color:inherit;border-radius:10px;padding:8px 2px;font:600 11px Arial;cursor:pointer;min-height:0}.xa-m button span{font-size:20px}.xa-m button.on{border-color:var(--xacc);background:color-mix(in srgb,var(--xacc) 14%,transparent)}\
html[data-exb-theme=dark] .xa-m button{border-color:#2a3a58;background:#1b2740}\
.xa-a{display:flex;gap:10px}.xa-a button{width:30px;height:30px;min-height:0;padding:0;border-radius:50%;border:3px solid transparent;cursor:pointer;box-shadow:0 0 0 1px #0003}.xa-a button.on{border-color:#fff;box-shadow:0 0 0 2px var(--xacc)}\
#xbApPanel input[type=range]{width:100%;min-height:0;padding:0;border:0;background:none;accent-color:var(--xacc)}#xbApPanel input[type=checkbox]{width:auto;min-height:0;flex:none}\
.xa-r{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:12px;font-size:13px}.xa-r button{border:0;background:color-mix(in srgb,var(--xacc) 14%,transparent);color:var(--xacc);border-radius:8px;padding:7px 10px;min-height:0;font-weight:700;cursor:pointer}\
}\
@media screen{\
#exbCoreNotifications{top:auto!important;bottom:196px!important;right:14px!important;z-index:70!important}\
#exbdb_chip{bottom:46px!important;left:256px!important;z-index:45!important}\
}\
@media screen and (max-width:900px){#exbdb_chip{left:12px!important}}\
@media screen and (max-width:600px){#xbTheme{display:none!important}#app>header{gap:6px!important}#xbTop{gap:2px!important}}\
#exbWM{position:fixed;inset:0;z-index:5;pointer-events:none;display:none;background-repeat:no-repeat;background-position:center;background-size:min(64vmin,560px);opacity:.08;mix-blend-mode:multiply}\
html[data-exb-wm=on] #exbWM{display:block}\
html[data-exb-theme=dark] #exbWM{opacity:.14;filter:grayscale(1) invert(1);mix-blend-mode:screen}\
@media(min-width:901px){#exbWM{background-position:calc(50% + 124px) 52%}}\
#exbDim{position:fixed;inset:0;background:#000;opacity:0;pointer-events:none;z-index:9990}\
@media print{#exbWM,#exbDim,#xbApPanel,.xbAp{display:none!important}}';
function css(){if($('exbAppearCss'))return;var s=d.createElement('style');s.id='exbAppearCss';s.textContent=CSS;d.head.appendChild(s)}
function logo(){var l='';try{var I=w.EXBId&&w.EXBId.get?w.EXBId.get():null;if(I&&/^(data:image|https?:|\/)/.test(I.logo||''))l=I.logo}catch(e){}if(!l)try{if(w.exbLogoSrc){var x=w.exbLogoSrc();if(x&&!/^icon-192/.test(x))l=x}}catch(e){}if(l)return l;var i=$('brandLogoHeader');return (i&&i.getAttribute('src'))||'icon-512.png'}
function applyAttrs(){root.setAttribute('data-exb-soft',S.mode==='soft'?'on':'off');root.setAttribute('data-exb-wm',S.wm?'on':'off');
 if(S.accent==='blue')root.removeAttribute('data-exb-accent');else root.setAttribute('data-exb-accent',S.accent);
 var a=ACC[S.accent];root.style.setProperty('--xacc',a[0]);root.style.setProperty('--xnav',a[1]);
 var wm=$('exbWM');if(wm)wm.style.backgroundImage='url("'+logo().replace(/"/g,'%22')+'")';
 var dm=$('exbDim');if(dm)dm.style.opacity=String(S.dim/100)}
function applyBase(){var b=base();if(w.EXB_THEME&&w.EXB_THEME.get&&w.EXB_THEME.get()!==b){busy=true;try{w.EXB_THEME.set(b)}finally{busy=false}}}
function apply(){applyBase();applyAttrs()}
function set(k,v){S[k]=v;save();apply();render()}
function dim(v){S.dim=Math.max(0,Math.min(40,+v||0));save();applyAttrs();var l=d.querySelector('#xbApPanel .lbd');if(l)l.textContent='Luminosité de l’écran : '+(100-S.dim)+' %'}
function reset(){S={mode:DEF.mode,accent:DEF.accent,dim:0,wm:true};save();apply();render()}
function toggle(){var p=$('xbApPanel');if(p){render();p.classList.toggle('on')}}
function render(){var p=$('xbApPanel');if(!p)return;
 p.innerHTML='<h4>🎨 Apparence</h4><div class="lb">Thème</div><div class="xa-m">'+MODES.map(function(m){return '<button type="button" class="'+(S.mode===m[0]?'on':'')+'" onclick="EXB_APPEAR.set(\'mode\',\''+m[0]+'\')"><span>'+m[1]+'</span>'+m[2]+'</button>'}).join('')+'</div>'+
 '<div class="lb">Couleur</div><div class="xa-a">'+Object.keys(ACC).map(function(k){return '<button type="button" title="'+ACC[k][2]+'" aria-label="'+ACC[k][2]+'" class="'+(S.accent===k?'on':'')+'" style="background:'+ACC[k][0]+'" onclick="EXB_APPEAR.set(\'accent\',\''+k+'\')"></button>'}).join('')+'</div>'+
 '<div class="lb lbd">Luminosité de l’écran : '+(100-S.dim)+' %</div><input type="range" min="60" max="100" step="2" value="'+(100-S.dim)+'" oninput="EXB_APPEAR.dim(100-this.value)" aria-label="Luminosité">'+
 '<div class="xa-r"><label style="display:flex;gap:8px;align-items:center;margin:0"><input type="checkbox" '+(S.wm?'checked':'')+' onchange="EXB_APPEAR.set(\'wm\',this.checked)">Filigrane (logo de l’entreprise)</label></div>'+
 '<div class="xa-r"><span style="opacity:.7;font-size:11px">Auto : clair de 6 h à 18 h, sombre ensuite.</span><button type="button" onclick="EXB_APPEAR.reset()">Réinitialiser</button></div>'}
function mount(){if($('xbAppear'))return true;var top=$('xbTop');if(!top)return false;var ref=$('xbTheme')||$('xbBell');if(!ref)return false;
 var wrap=d.createElement('div');wrap.className='xbAp';wrap.innerHTML='<button class="xb" id="xbAppear" type="button" title="Apparence" aria-label="Apparence" onclick="EXB_APPEAR.toggle()">🎨</button><div id="xbApPanel"></div>';
 top.insertBefore(wrap,ref);
 d.addEventListener('click',function(e){var p=$('xbApPanel');if(p&&p.classList.contains('on')&&!e.target.closest('.xbAp'))p.classList.remove('on')});
 d.addEventListener('keydown',function(e){if(e.key==='Escape'){var p=$('xbApPanel');if(p)p.classList.remove('on')}});return true}
function boot(){css();
 if(!$('exbWM')){var a=d.createElement('div');a.id='exbWM';a.className='no-print';a.setAttribute('aria-hidden','true');d.body.appendChild(a)}
 if(!$('exbDim')){var b=d.createElement('div');b.id='exbDim';b.className='no-print';b.setAttribute('aria-hidden','true');d.body.appendChild(b)}
 apply();setTimeout(applyAttrs,2500);var n=0,t=setInterval(function(){n++;if(mount()||n>100)clearInterval(t)},400);
 setInterval(function(){if(S.mode==='auto')apply()},300000);
 var li=$('brandLogoHeader');if(li&&w.MutationObserver)new MutationObserver(applyAttrs).observe(li,{attributes:true,attributeFilter:['src']});
 /* le bouton soleil/lune d'exb-theme.js reste un raccourci : il fixe alors le thème sur Clair ou Sombre */
 w.addEventListener('exb-theme',function(e){if(busy)return;var t=e&&e.detail&&e.detail.theme;if(t==='dark'||t==='light'){S.mode=t;save();applyAttrs();render()}})}
w.EXB_APPEAR={set:set,dim:dim,reset:reset,toggle:toggle,state:function(){return S}};
root.setAttribute('data-exb-soft',S.mode==='soft'?'on':'off');if(S.accent!=='blue')root.setAttribute('data-exb-accent',S.accent);
function start(){setTimeout(boot,0)}
if(d.readyState==='complete')start();else w.addEventListener('load',start)
})(window,document);
