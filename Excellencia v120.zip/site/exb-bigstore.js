/* Excellencia Building — grand stockage (V99 « stockage appareil »)
 * Problème : le navigateur limite localStorage à ~5 Mo ; photos, logos et signatures (images « data: ») le remplissent
 * et le message « espace du navigateur saturé » apparaît (ex. export d'un plan).
 * Solution : à l'écriture (exbStorage.setItem), chaque grosse image « data: » est rangée dans IndexedDB (centaines de Mo)
 * et remplacée dans localStorage par un petit jeton « exbidb:… » ; à la lecture (exbStorage.getItem) le jeton est remplacé
 * par l'image d'origine. Les données restent donc identiques pour l'application, sauvegardes et synchronisation comprises.
 * Sécurité : si IndexedDB est indisponible, rien n'est déplacé (comportement d'avant). Retrait : supprimer la balise
 * <script src="exb-bigstore.js"> et les 2 appels EXBBIG dans exbStorage (index.html) — les jetons existants ne seraient plus résolus,
 * il faut donc d'abord faire une sauvegarde complète depuis l'application (elle contient les images d'origine). */
(function (w) {
  'use strict';
  var DB = 'exb_big', ST = 'kv', THRESH = 40000, TOK = /exbidb:[0-9a-z]+/g, DURL = /data:[a-z0-9.+\-]+\/[a-z0-9.+\-]+;base64,[A-Za-z0-9+\/=]+/g;
  var M = new Map(), pend = new Map(), db = null, ok = true, ready = false, waiters = [], ft = 0, flushing = null, compacting = false, shown = 0;
  var PFX = 'EXB_V28__';
  /* V144e (audit P4) : mesures du grand stockage. EXBBIG.perf() liste les 60 dernières opérations (durée, nombre, taille) ;
     toute opération ≥ 300 ms est aussi notée dans le rapport de lenteur (Ctrl + Alt + L). Aucune donnée de contenu n'est lue. */
  var PERF = [];
  function now() { try { return performance.now(); } catch (e) { return Date.now(); } }
  function perf(kind, t0, n, chars) {
    var ms = Math.round(now() - t0); PERF.push({ t: new Date().toISOString(), op: kind, ms: ms, n: n || 0, mo: chars ? +(chars / 1048576).toFixed(2) : 0 }); if (PERF.length > 60) PERF.shift();
    if (ms >= 300) { try { w.EXBDiag && w.EXBDiag.note && w.EXBDiag.note('(IndexedDB) ' + kind + ' · ' + (n || 0) + ' élément(s) · ' + (chars ? (chars / 1048576).toFixed(1) + ' Mo' : ''), ms); } catch (e) {} }
  }

  function h53(s) { var a = 0xdeadbeef ^ s.length, b = 0x41c6ce57 ^ s.length; for (var i = 0, c; i < s.length; i++) { c = s.charCodeAt(i); a = Math.imul(a ^ c, 2654435761); b = Math.imul(b ^ c, 1597334677); } a = Math.imul(a ^ (a >>> 16), 2246822507) ^ Math.imul(b ^ (b >>> 13), 3266489909); b = Math.imul(b ^ (b >>> 16), 2246822507) ^ Math.imul(a ^ (a >>> 13), 3266489909); return (4294967296 * (2097151 & b) + (a >>> 0)); }
  function tokenOf(u) { return 'exbidb:' + h53(u).toString(36) + 'x' + u.length.toString(36); }
  function real() { try { var s = w.localStorage; s.getItem('__exb_probe__'); return s; } catch (e) { return null; } }

  function pack(v) {
    if (!ok || typeof v !== 'string' || v.length < THRESH || v.indexOf('data:') < 0) return v;
    return v.replace(DURL, function (u) {
      if (u.length < THRESH) return u;
      var t = tokenOf(u);
      if (!M.has(t)) { M.set(t, u); pend.set(t, u); schedule(); }
      return t;
    });
  }
  function unpack(v) {
    if (typeof v !== 'string' || v.indexOf('exbidb:') < 0) return v;
    return v.replace(TOK, function (t) { var u = M.get(t); return u !== undefined ? u : t; });
  }

  function open() {
    return new Promise(function (res, rej) {
      if (!w.indexedDB) return rej(new Error('IndexedDB absent'));
      var r = w.indexedDB.open(DB, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore(ST); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
      r.onblocked = function () { rej(new Error('blocked')); };
    });
  }
  function schedule() { if (ft) return; ft = setTimeout(function () { ft = 0; flush(); }, 60); }
  function flush() {
    if (flushing) return flushing.then(function () { return pend.size ? flush() : true; });
    if (!pend.size) return Promise.resolve(true);
    if (!db) { return Promise.resolve(false); }
    var batch = Array.from(pend.entries()), tF = now(), cF = 0;
    batch.forEach(function (e) { cF += e[1].length; });
    flushing = new Promise(function (res) {
      try {
        var tx = db.transaction(ST, 'readwrite'), os = tx.objectStore(ST);
        batch.forEach(function (e) { os.put(e[1], e[0]); });
        tx.oncomplete = function () { perf('écriture', tF, batch.length, cF); batch.forEach(function (e) { if (pend.get(e[0]) === e[1]) pend.delete(e[0]); }); res(true); };
        tx.onerror = tx.onabort = function () { res(false); };
      } catch (e) { res(false); }
    }).then(function (good) {
      flushing = null;
      if (!good) fail(batch.map(function (e) { return e[0]; }));
      return good;
    });
    return flushing;
  }
  /* échec d'écriture IndexedDB : on arrête de déplacer et on remet les images d'origine là où c'est possible */
  function fail(tokens) {
    ok = false;
    var s = real(); if (!s) return;
    try {
      for (var i = 0; i < s.length; i++) {
        var k = s.key(i); if (!k || k.indexOf(PFX) !== 0) continue;
        var v = s.getItem(k); if (v && v.indexOf('exbidb:') >= 0) { var n = unpack(v); if (n !== v) { try { s.setItem(k, n); } catch (e) {} } }
      }
    } catch (e) {}
    try { w.notify && w.notify('Le grand stockage de l’appareil n’a pas pu écrire : exportez une sauvegarde (Données sur mon PC).', 'warn', 8000); } catch (e) {}
  }

  function hydrate() {
    return open().then(function (d) {
      db = d;
      return new Promise(function (res) {
        try {
          /* V144e : lecture par curseur (un enregistrement par tâche) : getAll() livrait toutes les images d'un seul bloc,
             ce qui bloquait l'écran à la fin de la transaction (≈ 1 s dans le rapport de lenteur). */
          var tH = now(), nH = 0, cH = 0, tx = db.transaction(ST, 'readonly'), os = tx.objectStore(ST), cur = os.openCursor();
          cur.onsuccess = function () { var c = cur.result; if (!c) return; if (!M.has(c.key)) M.set(c.key, c.value); nH++; cH += (typeof c.value === 'string' ? c.value.length : 0); c.continue(); };
          tx.oncomplete = function () { perf('lecture au démarrage', tH, nH, cH); res(); };
          tx.onerror = tx.onabort = function () { ok = false; res(); };
        } catch (e) { ok = false; res(); }
      });
    }).catch(function () { ok = false; }).then(function () {
      if (!db) { if (pend.size) fail([]); } else if (pend.size) flush();
      ready = true; waiters.splice(0).forEach(function (f) { try { f(); } catch (e) {} });
      patchDom(); try { w.dispatchEvent(new Event('exb:bigready')); } catch (e) {}
      /* V144d : compactage automatique seulement quand l'utilisateur n'écrit plus depuis 5 s et que le navigateur est au repos ;
         sinon on réessaie plus tard (max 20 essais). Le compactage forcé (quota plein, bouton) reste immédiat. */
      (function () {
        var lastIn = 0, tries = 0;
        ['keydown', 'input', 'pointerdown'].forEach(function (ev) { try { document.addEventListener(ev, function () { lastIn = Date.now(); }, true); } catch (e) {} });
        function tryCompact() {
          if (!ok) return;
          if (Date.now() - lastIn < 5000 && ++tries < 20) { setTimeout(tryCompact, 4000); return; }
          var run = function () { if (Date.now() - lastIn < 2000 && ++tries < 20) { setTimeout(tryCompact, 4000); return; } try { var a = audit(); if (a.missing.length) console.warn('EXBBIG : ' + a.missing.length + ' image(s) référencée(s) mais absente(s) d’IndexedDB sur ' + a.tokens + ' :', a.missing.slice(0, 20)); } catch (e) {} compact(false); };
          if (window.requestIdleCallback) window.requestIdleCallback(run, { timeout: 8000 }); else setTimeout(run, 0);
        }
        setTimeout(tryCompact, 4000);
      })();
    });
  }

  /* images déjà affichées avec un jeton avant la fin du chargement */
  function patchDom() {
    try { Array.prototype.forEach.call(document.querySelectorAll('img[src^="exbidb:"]'), function (im) { var u = M.get(im.getAttribute('src')); if (u) im.src = u; }); } catch (e) {}
  }
  /* V144e (audit §4.3 / test « Stockage ») : l'observateur ne se déconnecte plus à la fin du chargement.
     Avant, une photo affichée par un rendu POSTÉRIEUR (liste clients, fiche, plan…) gardait son jeton exbidb: et ne s'affichait pas.
     Il reste léger : seuls les nœuds AJOUTÉS (ou un attribut src modifié) sont examinés, regroupés par requestAnimationFrame ; aucun balayage du document. */
  function fixImg(im) { try { var s = im.getAttribute('src'); if (s && s.indexOf('exbidb:') === 0) { var u = M.get(s); if (u) im.src = u; } } catch (e) {} }
  function fixNode(n) {
    if (!n || n.nodeType !== 1) return;
    if (n.tagName === 'IMG') { fixImg(n); return; }
    if (n.querySelectorAll) Array.prototype.forEach.call(n.querySelectorAll('img[src^="exbidb:"]'), fixImg);
  }
  try {
    var moQ = [], moP = 0;
    var mo = new MutationObserver(function (ms) {
      for (var i = 0; i < ms.length; i++) {
        var m = ms[i];
        if (m.type === 'attributes') { if (m.target.tagName === 'IMG') moQ.push(m.target); continue; }
        for (var j = 0; j < m.addedNodes.length; j++) if (m.addedNodes[j].nodeType === 1) moQ.push(m.addedNodes[j]);
      }
      if (moP || !moQ.length) return;
      moP = (window.requestAnimationFrame || setTimeout)(function () {
        moP = 0; var q = moQ; moQ = [];
        if (!ready) return; /* avant la fin de la lecture, patchDom() s'en charge une fois prêt */
        for (var k = 0; k < q.length; k++) if (q[k].isConnected) fixNode(q[k]);
      });
    });
    mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
  } catch (e) {}

  /* libère la place déjà occupée : range les images des données existantes (après écriture confirmée dans IndexedDB) */
  function compact(force) {
    if (compacting || !ok || !db) return Promise.resolve(0);
    var s = real(); if (!s) return Promise.resolve(0);
    compacting = true;
    var work = [], before = 0, tC = now();
    try {
      for (var i = 0; i < s.length; i++) {
        var k = s.key(i); if (!k || k.indexOf(PFX) !== 0) continue;
        var v = s.getItem(k); if (!v || v.length < THRESH || v.indexOf('data:') < 0) continue;
        var n = pack(v); if (n !== v) work.push([k, v, n]);
      }
    } catch (e) {}
    if (!work.length) { compacting = false; perf('compactage (analyse)', tC, 0, 0); return Promise.resolve(0); }
    before = usage().chars; /* mesure de l'espace libéré : seulement s'il y a du travail */
    return flush().then(function (good) {
      if (!good) return 0;
      work.forEach(function (x) { try { if (s.getItem(x[0]) === x[1]) s.setItem(x[0], x[2]); } catch (e) {} });
      perf('compactage', tC, work.length, before);
      return Math.max(0, before - usage().chars);
    }).catch(function () { return 0; }).then(function (r) { compacting = false; return r; });
  }
  /* V144d : diagnostic — jetons « exbidb: » présents dans localStorage dont l'image n'existe pas dans IndexedDB
     (ils s'affichent alors en erreur ERR_UNKNOWN_URL_SCHEME). Lecture seule, rien n'est modifié. */
  function audit() {
    var s = real(), tokens = new Set(), missing = new Set(); if (!s) return { tokens: 0, missing: [] };
    try {
      for (var i = 0; i < s.length; i++) {
        var k = s.key(i); if (!k || k.indexOf(PFX) !== 0) continue;
        var v = s.getItem(k); if (!v || v.indexOf('exbidb:') < 0) continue;
        var m = v.match(TOK); if (!m) continue;
        m.forEach(function (t) { tokens.add(t); if (!M.has(t)) missing.add(t + '  (clé ' + k.slice(PFX.length) + ')'); });
      }
    } catch (e) {}
    return { tokens: tokens.size, missing: Array.from(missing) };
  }
  function usage() {
    var s = real(), n = 0; if (!s) return { chars: 0 };
    try { for (var i = 0; i < s.length; i++) { var k = s.key(i) || ''; n += k.length + (s.getItem(k) || '').length; } } catch (e) {}
    return { chars: n };
  }
  function onQuota() { try { compact(true); } catch (e) {} }

  function mb(n) { return (n / 1048576).toFixed(n < 10485760 ? 1 : 0).replace('.', ',') + ' Mo'; }
  function persist() {
    try { if (navigator.storage && navigator.storage.persist) return navigator.storage.persist(); } catch (e) {}
    return Promise.resolve(false);
  }
  /* demande, une seule fois par session, de protéger les données contre l'effacement automatique du téléphone */
  function askPersist() { try { if (navigator.storage && navigator.storage.persisted) navigator.storage.persisted().then(function (p) { if (!p) persist(); }); } catch (e) {} }

  /* enregistrement sur le téléphone : fichier de sauvegarde complète via « Partager » (Fichiers, Drive, WhatsApp…) ou téléchargement */
  function backupFile() {
    var S = null, K = []; try { S = typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) {}
    if (!S) return null;
    try { K = (typeof EXB_ENTERPRISE_KEYS !== 'undefined' ? EXB_ENTERPRISE_KEYS.slice() : []); } catch (e) {}
    if (K.indexOf('exb_approvals') < 0) K.push('exb_approvals');
    if (K.indexOf('exb_plan_files') < 0) K.push('exb_plan_files');
    var data = {}; K.forEach(function (k) { var v = S.getItem(k); if (v === null) return; try { data[k] = JSON.parse(v); } catch (e) { data[k] = v; } });
    var obj = { version: 6, app: 'Excellencia Building', exported_at: new Date().toISOString(), data: data };
    return new File([JSON.stringify(obj, null, 2)], 'excellencia-building-sauvegarde-complete-' + isoDay() + '.json', { type: 'application/json' });
  }
  function isoDay() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function deliver(files, title) {
    var go = function () { files.forEach(function (f, i) { setTimeout(function () { var a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000); }, i * 700); }); return { ok: true, msg: files.length + ' fichier(s) enregistré(s) dans les Téléchargements du téléphone.' }; };
    try {
      if (navigator.canShare && navigator.canShare({ files: files })) return navigator.share({ files: files, title: title }).then(function () { return { ok: true, msg: 'Choisissez « Fichiers » ou « Drive » pour les enregistrer sur le téléphone.' }; }, function (e) { return e && e.name === 'AbortError' ? { ok: false, msg: 'Enregistrement annulé.' } : go(); });
    } catch (e) {}
    return Promise.resolve(go());
  }
  /* fichiers de plans (PDF, DWG, DXF, IFC, images) rangés dans l'appareil */
  function savePlansToPhone() {
    var S = null; try { S = typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) {}
    var L = []; try { L = JSON.parse((S && S.getItem('exb_plan_files')) || '[]') || []; } catch (e) {}
    if (!L.length) return Promise.resolve({ ok: false, msg: 'Aucun fichier de plan sur cet appareil.' });
    return new Promise(function (res) {
      var r = w.indexedDB.open('exb81', 1); r.onerror = function () { res({ ok: false, msg: 'Fichiers de plans illisibles.' }); };
      r.onupgradeneeded = function () { try { r.result.createObjectStore('blobs'); } catch (e) {} };
      r.onsuccess = function () {
        var d = r.result, out = [], n = 0;
        if (!d.objectStoreNames.contains('blobs')) return res({ ok: false, msg: 'Aucun fichier de plan sur cet appareil.' });
        L.forEach(function (m) {
          var q = d.transaction('blobs').objectStore('blobs').get(m.id);
          q.onsuccess = function () { if (q.result) { var nm = (m.ref ? m.ref + ' ind' + (m.ver || '') + ' — ' : '') + (m.name || m.id); out.push(new File([q.result], nm.replace(/[\\\/:*?"<>|]+/g, '-'), { type: q.result.type || 'application/octet-stream' })); } if (++n === L.length) fin(); };
          q.onerror = function () { if (++n === L.length) fin(); };
        });
        function fin() { if (!out.length) return res({ ok: false, msg: 'Aucun fichier de plan sur cet appareil.' }); deliver(out, 'Plans Excellencia Building').then(res); }
      };
    });
  }
  function saveToPhone() { var f = backupFile(); if (!f) return Promise.resolve({ ok: false, msg: 'Stockage introuvable.' }); return deliver([f], 'Sauvegarde Excellencia Building'); }

  function card() {
    var el = document.getElementById('exb_big_card'); if (!el || el.getAttribute('data-r')) return; el.setAttribute('data-r', '1');
    el.innerHTML = '<h2>📱 Stockage de l’appareil</h2><p class="localhint">Les photos et images lourdes sont rangées dans un grand espace de l’appareil (plus de message « espace du navigateur saturé »). Enregistrez aussi une copie sur le téléphone pour garder vos travaux terminés.</p><div class="onlineState" id="exb_big_st">…</div><div class="actions"><button class="primary" id="exb_big_save">📲 Enregistrer sur le téléphone</button><button class="primary" id="exb_big_plans">📐 Enregistrer mes plans</button><button class="gold" id="exb_big_cmp">🧹 Libérer l’espace</button><button class="muted" id="exb_big_per">🔒 Protéger mes données</button></div><div class="msg" id="exb_big_msg"></div>';
    var msg = function (t) { var m = document.getElementById('exb_big_msg'); if (m) m.textContent = t; };
    function stat() {
      var u = usage(), box = document.getElementById('exb_big_st'); if (!box) return;
      var p = navigator.storage && navigator.storage.estimate ? navigator.storage.estimate() : Promise.resolve({});
      var q = navigator.storage && navigator.storage.persisted ? navigator.storage.persisted() : Promise.resolve(false);
      Promise.all([p, q]).then(function (r) {
        var e = r[0] || {}; box.textContent = 'Réserve rapide du navigateur : ' + mb(u.chars) + ' sur ~5 Mo · Grand stockage : ' + (e.usage != null ? mb(e.usage) : '—') + (e.quota ? ' sur ' + mb(e.quota) : '') + ' · Protection contre l’effacement : ' + (r[1] ? 'activée' : 'non activée') + (ok ? '' : ' · grand stockage indisponible');
      });
    }
    document.getElementById('exb_big_save').onclick = function () { msg('Préparation…'); saveToPhone().then(function (r) { msg((r.ok ? '✓ ' : '') + r.msg); }); };
    document.getElementById('exb_big_plans').onclick = function () { msg('Préparation des plans…'); savePlansToPhone().then(function (r) { msg((r.ok ? '✓ ' : '') + r.msg); }); };
    document.getElementById('exb_big_cmp').onclick = function () { msg('Optimisation…'); compact(true).then(function (n) { msg('✓ Espace libéré : ' + mb(n || 0) + '.'); stat(); }); };
    document.getElementById('exb_big_per').onclick = function () { persist().then(function (g) { msg(g ? '✓ Données protégées contre l’effacement automatique.' : 'Le navigateur n’a pas accordé la protection (installez l’application sur l’écran d’accueil puis réessayez).'); stat(); }); };
    stat();
  }
  try { var mo2P = 0, mo2 = new MutationObserver(function () { if (mo2P) return; mo2P = (window.requestAnimationFrame || setTimeout)(function () { mo2P = 0; card(); }); }); document.addEventListener('DOMContentLoaded', function () { card(); mo2.observe(document.body, { childList: true, subtree: true }); }); } catch (e) {}

  w.EXBBIG = { pack: pack, unpack: unpack, onQuota: onQuota, isReady: function () { return ready; }, whenReady: function (f) { ready ? f() : waiters.push(f); }, compact: compact, audit: audit, persist: persist, saveToPhone: saveToPhone, savePlansToPhone: savePlansToPhone, usage: usage, enabled: function () { return ok; }, perf: function () { return PERF.slice(); } };
  window.addEventListener('pagehide', function () { if (pend.size) flush(); });
  hydrate().then(askPersist);
})(window);
