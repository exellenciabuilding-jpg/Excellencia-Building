/* exb-ifc3d.js — V99zq : lecteur IFC 3D autonome (aucune bibliothèque externe, fonctionne hors connexion).
 * 1) Moteur : lit le texte IFC (STEP, IFC2X3 / IFC4 / IFC4.3), reconstruit la géométrie et les propriétés.
 *    Géométrie prise en charge : extrusions (profils rectangle, cercle, ellipse, I, L, polygone, polyligne/courbe composite),
 *    BREP à facettes, maillages triangulés / polygonaux, blocs, cylindres, objets répétés (MappedItem), couleurs IfcStyledItem.
 *    V99 : + extrusions coniques, révolutions, disques balayés (armatures), découpe par plan (IfcBooleanClippingResult avec demi-espace),
 *    fichiers compressés .ifczip.
 *    Non prise en charge (comptée et signalée) : BREP avancés (NURBS), profils composites, balayages autres que le disque.
 *    Les ouvertures (portes/fenêtres découpées dans les murs) ne sont pas soustraites : le mur apparaît plein.
 * 2) Visionneuse WebGL : rotation, zoom, déplacement, sélection d'un élément avec ses propriétés, arborescence par niveau,
 *    filtres par catégorie, isoler / masquer, coupe horizontale, vues standard, capture d'image. */
(function (root) {
  'use strict';

  /* ================= STEP / IFC : lecture ================= */
  function decodeStr(s) {
    return s.replace(/\\X2\\([0-9A-Fa-f]+)\\X0\\/g, function (_, h) { var o = ''; for (var i = 0; i + 3 < h.length + 0; i += 4) o += String.fromCharCode(parseInt(h.substr(i, 4), 16)); return o; })
      .replace(/\\X\\([0-9A-Fa-f]{2})/g, function (_, h) { return String.fromCharCode(parseInt(h, 16)); })
      .replace(/\\S\\(.)/g, function (_, c) { return String.fromCharCode(c.charCodeAt(0) + 128); });
  }
  /* arguments STEP → tableau JS : #12 → {r:12}, 'txt' → "txt", 1.5 → 1.5, .T. → ".T.", $ → null, * → null, TYPE(x) → {t:'TYPE',v:[…]} */
  function parseArgs(s) {
    var i = 0, n = s.length;
    function ws() { while (i < n && s.charCodeAt(i) <= 32) i++; }
    function val() {
      ws(); var c = s[i];
      if (c === '(') { i++; var a = []; ws(); if (s[i] === ')') { i++; return a; } for (;;) { a.push(val()); ws(); if (s[i] === ',') { i++; continue; } if (s[i] === ')') { i++; break; } if (i >= n) break; i++; } return a; }
      if (c === "'") { var j = i + 1, o = ''; for (;;) { var q = s.indexOf("'", j); if (q < 0) { o += s.slice(j); i = n; break; } if (s[q + 1] === "'") { o += s.slice(j, q + 1); j = q + 2; continue; } o += s.slice(j, q); i = q + 1; break; } return decodeStr(o); }
      if (c === '#') { var m = /^#(\d+)/.exec(s.slice(i, i + 14)); i += m[0].length; return { r: +m[1] }; }
      if (c === '$' || c === '*') { i++; return null; }
      if (c === '.') { var e = s.indexOf('.', i + 1); var w = s.slice(i, e + 1); i = e + 1; return w; }
      var m2 = /^[-+0-9.eE]+/.exec(s.slice(i, i + 40));
      if (m2) { i += m2[0].length; return parseFloat(m2[0]); }
      var m3 = /^([A-Z0-9_]+)\s*\(/.exec(s.slice(i, i + 80));
      if (m3) { i += m3[0].length; var a2 = []; ws(); if (s[i] === ')') { i++; return { t: m3[1], v: a2 }; } for (;;) { a2.push(val()); ws(); if (s[i] === ',') { i++; continue; } if (s[i] === ')') { i++; break; } if (i >= n) break; i++; } return { t: m3[1], v: a2 }; }
      i++; return null;
    }
    var out = [];
    for (;;) { ws(); if (i >= n) break; out.push(val()); ws(); if (s[i] === ',') i++; else break; }
    return out;
  }

  /* ================= algèbre 4×4 (ligne par ligne : p' = M·p) ================= */
  function I4() { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
  function mul(A, B) { var R = new Array(16); for (var r = 0; r < 4; r++) for (var c = 0; c < 4; c++) { var s = 0; for (var k = 0; k < 4; k++) s += A[r * 4 + k] * B[k * 4 + c]; R[r * 4 + c] = s; } return R; }
  function tp(M, x, y, z) { return [M[0] * x + M[1] * y + M[2] * z + M[3], M[4] * x + M[5] * y + M[6] * z + M[7], M[8] * x + M[9] * y + M[10] * z + M[11]]; }
  function norm3(v) { var l = Math.hypot(v[0], v[1], v[2]); return l > 1e-12 ? [v[0] / l, v[1] / l, v[2] / l] : null; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function fromAxes(X, Y, Z, O) { return [X[0], Y[0], Z[0], O[0], X[1], Y[1], Z[1], O[1], X[2], Y[2], Z[2], O[2], 0, 0, 0, 1]; }
  function rigidInv(M) { /* inverse d'une matrice rotation + translation (échelle 1) */
    var R = [M[0], M[4], M[8], M[1], M[5], M[9], M[2], M[6], M[10]], t = [M[3], M[7], M[11]];
    var it = [-(R[0] * t[0] + R[1] * t[1] + R[2] * t[2]), -(R[3] * t[0] + R[4] * t[1] + R[5] * t[2]), -(R[6] * t[0] + R[7] * t[1] + R[8] * t[2])];
    return [R[0], R[1], R[2], it[0], R[3], R[4], R[5], it[1], R[6], R[7], R[8], it[2], 0, 0, 0, 1];
  }

  /* ================= triangulation ================= */
  function area2(p) { var a = 0; for (var i = 0, n = p.length; i < n; i++) { var q = p[(i + 1) % n]; a += p[i][0] * q[1] - q[0] * p[i][1]; } return a / 2; }
  function earClip(p) { /* p : [[x,y],…] → liste d'indices (triangles) */
    var n = p.length, idx = [], out = [], i;
    if (n < 3) return out;
    for (i = 0; i < n; i++) idx.push(i);
    if (area2(p) < 0) idx.reverse();
    function inTri(a, b, c, q) { var d1 = (q[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (q[1] - b[1]), d2 = (q[0] - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (q[1] - c[1]), d3 = (q[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (q[1] - a[1]); var neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0; return !(neg && pos); }
    var guard = 0;
    while (idx.length > 3 && guard++ < 20000) {
      var cut = false, m = idx.length;
      for (i = 0; i < m; i++) {
        var a = idx[(i + m - 1) % m], b = idx[i], c = idx[(i + 1) % m], A = p[a], B = p[b], C = p[c];
        if ((B[0] - A[0]) * (C[1] - A[1]) - (B[1] - A[1]) * (C[0] - A[0]) <= 1e-12) continue;
        var ok = true;
        for (var j = 0; j < m; j++) { var k = idx[j]; if (k === a || k === b || k === c) continue; if (inTri(A, B, C, p[k])) { ok = false; break; } }
        if (!ok) continue;
        out.push(a, b, c); idx.splice(i, 1); cut = true; break;
      }
      if (!cut) { out.push(idx[0], idx[1], idx[2]); idx.splice(1, 1); }
    }
    if (idx.length === 3) out.push(idx[0], idx[1], idx[2]);
    return out;
  }
  function polyArea(pts, N) { var a = 0; for (var i = 0, n = pts.length; i < n; i++) { var p = pts[i], q = pts[(i + 1) % n]; var c = cross(p, q); a += dot(c, N); } return a / 2; }
  function triPoly3D(pts) { /* polygone 3D → triangles [[a,b,c],…] indices */
    var n = pts.length; if (n < 3) return [];
    if (n === 3) return [[0, 1, 2]];
    var N = [0, 0, 0]; for (var i = 0; i < n; i++) { var p = pts[i], q = pts[(i + 1) % n]; N[0] += (p[1] - q[1]) * (p[2] + q[2]); N[1] += (p[2] - q[2]) * (p[0] + q[0]); N[2] += (p[0] - q[0]) * (p[1] + q[1]); }
    var nn = norm3(N); if (!nn) return [];
    var ax = Math.abs(nn[0]) > Math.abs(nn[1]) && Math.abs(nn[0]) > Math.abs(nn[2]) ? 0 : (Math.abs(nn[1]) > Math.abs(nn[2]) ? 1 : 2), u = (ax + 1) % 3, v = (ax + 2) % 3;
    var flip = nn[ax] < 0; var p2 = pts.map(function (p) { return flip ? [p[v], p[u]] : [p[u], p[v]]; });
    var t = earClip(p2), r = [];
    for (var k = 0; k < t.length; k += 3) r.push([t[k], t[k + 1], t[k + 2]]);
    return r;
  }


  /* ================= import natif OBJ (Wavefront) =================
   * Lit .obj (+ .mtl pour les couleurs), construit le même modèle que l'IFC : un « élément » par objet (o) / groupe (g),
   * catégorie déduite du nom ou du matériau, quantités (surfaces, volumes) et mesures 3D identiques à l'IFC.
   * Unité : m, cm, mm, ft, in (détectée ou imposée) ; axe vertical Y (convention OBJ) ou Z (converti en Z vertical). */
  var OBJ_UNITS = { m: 1, cm: 0.01, mm: 0.001, ft: 0.3048, in: 0.0254, pied: 0.3048, pouce: 0.0254 };
  var OBJ_CATS = [[/mur|wall|cloison/i, 'Murs'], [/dalle|slab|floor|plancher|sol\b/i, 'Dalles'], [/toit|roof|couverture/i, 'Toitures'], [/porte|door/i, 'Portes'], [/fen[eê]tre|window|vitr|glass/i, 'Fenêtres'], [/poteau|column|colonne/i, 'Poteaux'], [/poutre|beam/i, 'Poutres'], [/escalier|stair/i, 'Escaliers'], [/fondation|footing|semelle/i, 'Fondations'], [/garde|rail|balustr/i, 'Garde-corps'], [/terrain|ground|site|terre/i, 'Terrain'], [/meuble|furniture|chair|table|lit\b|bed/i, 'Mobilier']];
  function parseMtl(text) {
    var out = {}, cur = null; String(text || '').split(/\r?\n/).forEach(function (l) {
      var m = /^\s*newmtl\s+(.+?)\s*$/.exec(l); if (m) { cur = m[1]; out[cur] = out[cur] || {}; return; }
      m = /^\s*Kd\s+([-\d.eE+]+)\s+([-\d.eE+]+)\s+([-\d.eE+]+)/.exec(l); if (m && cur) out[cur].c = [Math.round(Math.min(1, +m[1]) * 255), Math.round(Math.min(1, +m[2]) * 255), Math.round(Math.min(1, +m[3]) * 255)];
    }); return out;
  }
  function objGuess(text) { /* → { unit, up, span } depuis les commentaires de l'export Excellencia ou l'étendue des coordonnées */
    var head = text.slice(0, 600), unit = null, up = null;
    if (/Unit[ée]\s*:\s*m[eè]tre/i.test(head)) unit = 'm'; else if (/Unit[ée]\s*:\s*(millim|mm)/i.test(head)) unit = 'mm'; else if (/Unit[ée]\s*:\s*(centim|cm)/i.test(head)) unit = 'cm';
    var mu = /axe vertical\s*:\s*([YZ])/i.exec(head); if (mu) up = mu[1].toUpperCase();
    var mn = [1e30, 1e30, 1e30], mx = [-1e30, -1e30, -1e30], re = /^v\s+([-\d.eE+]+)\s+([-\d.eE+]+)\s+([-\d.eE+]+)/gm, m, n = 0;
    while ((m = re.exec(text)) && n++ < 200000) { var c = [+m[1], +m[2], +m[3]]; for (var k = 0; k < 3; k++) { if (c[k] < mn[k]) mn[k] = c[k]; if (c[k] > mx[k]) mx[k] = c[k]; } }
    var span = n ? Math.max(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) : 0;
    if (!unit) unit = span > 3000 ? 'mm' : span > 300 ? 'cm' : 'm';
    return { unit: unit, up: up || 'Y', span: span, vertices: n };
  }
  async function parseObj(text, opts, onProgress) {
    var t0 = Date.now(); opts = opts || {}; var g = objGuess(text), unit = String(opts.unit || g.unit).toLowerCase(), up = String(opts.up || g.up).toUpperCase() === 'Z' ? 'Z' : 'Y';
    var k = OBJ_UNITS[unit]; if (!k) k = 1; var mtl = opts.mtl || {};
    var V = [], objs = Object.create(null), order = [], curName = 'Objet', curMat = '', lines = text.split(/\r?\n/), warnN = 0, faces = 0;
    function conv(x, y, z) { x *= k; y *= k; z *= k; return up === 'Y' ? [x, -z, y] : [x, y, z]; } /* Y vertical → Z vertical : (x, y, z) → (x, −z, y) */
    function grp(name, mat) { var key = name + '\u0001' + mat, o = objs[key]; if (!o) { o = objs[key] = { name: name, mat: mat, v: [], faces: 0 }; order.push(o); } return o; }
    var cg = grp(curName, curMat);
    for (var li = 0; li < lines.length; li++) {
      var l = lines[li]; if (!l || l.charCodeAt(0) === 35) continue; var c0 = l.charCodeAt(0), c1 = l.charCodeAt(1);
      if (c0 === 118 && c1 === 32) { var p = l.trim().split(/\s+/); V.push(conv(+p[1] || 0, +p[2] || 0, +p[3] || 0)); }
      else if (c0 === 102 && (c1 === 32 || c1 === 9)) {
        var tk = l.trim().split(/\s+/).slice(1), idx = [];
        for (var q = 0; q < tk.length; q++) { var vi = parseInt(tk[q], 10); if (!vi) continue; vi = vi < 0 ? V.length + vi : vi - 1; if (vi >= 0 && vi < V.length) idx.push(vi); }
        if (idx.length < 3) { warnN++; continue; }
        var pts = idx.map(function (i) { return V[i]; });
        if (pts.length === 3) cg.v.push(pts[0][0], pts[0][1], pts[0][2], pts[1][0], pts[1][1], pts[1][2], pts[2][0], pts[2][1], pts[2][2]);
        else { var tr = pts.length === 4 ? [[0, 1, 2], [0, 2, 3]] : triPoly3D(pts); for (var ti = 0; ti < tr.length; ti++) { var A0 = pts[tr[ti][0]], B0 = pts[tr[ti][1]], C0 = pts[tr[ti][2]]; cg.v.push(A0[0], A0[1], A0[2], B0[0], B0[1], B0[2], C0[0], C0[1], C0[2]); } }
        cg.faces++; faces++;
      }
      else if ((c0 === 111 || c0 === 103) && c1 === 32) { curName = l.slice(2).trim() || curName; cg = grp(curName, curMat); }
      else if (l.slice(0, 7) === 'usemtl ') { curMat = l.slice(7).trim(); cg = grp(curName, curMat); }
      if (li % 80000 === 79999) { if (onProgress) onProgress('Lecture OBJ… ' + Math.round(li / lines.length * 100) + ' %'); await tick(); }
    }
    var els = [], positions = [], total = 0, gmin = [1e30, 1e30, 1e30], gmax = [-1e30, -1e30, -1e30], id = 0, info = Object.create(null), seen = Object.create(null);
    order.forEach(function (o) {
      if (!o.v.length) return; id++;
      var cat = null; for (var ci = 0; ci < OBJ_CATS.length; ci++) { if (OBJ_CATS[ci][0].test(o.name) || OBJ_CATS[ci][0].test(o.mat)) { cat = OBJ_CATS[ci][1]; break; } }
      cat = cat || 'Objets OBJ';
      var col = mtl[o.mat] && mtl[o.mat].c || COLORS[cat] || DEF_COLOR, n = o.v.length, mn = [1e30, 1e30, 1e30], mx = [-1e30, -1e30, -1e30];
      for (var z = 0; z < n; z += 3) for (var kk = 0; kk < 3; kk++) { var x = o.v[z + kk]; if (x < mn[kk]) mn[kk] = x; if (x > mx[kk]) mx[kk] = x; }
      var nm = o.name; if (seen[nm]) nm += ' (' + (o.mat || seen[nm] + 1) + ')'; seen[o.name] = (seen[o.name] || 0) + 1;
      var el = { id: id, gid: '', type: 'OBJ', cat: cat, name: nm, desc: o.mat ? 'Matériau : ' + o.mat : '', storey: '—', start: total, count: n / 3, color: col, hidden0: false, min: mn, max: mx };
      info[id] = [['Objet / groupe', o.name], ['Matériau', o.mat || '—'], ['Faces', String(o.faces)]];
      els.push(el); total += n / 3; for (var zz = 0; zz < n; zz++) positions.push(o.v[zz]);
      for (var k3 = 0; k3 < 3; k3++) { if (mn[k3] < gmin[k3]) gmin[k3] = mn[k3]; if (mx[k3] > gmax[k3]) gmax[k3] = mx[k3]; }
    });
    var pos32 = new Float32Array(positions.length); for (var pi = 0; pi < positions.length; pi++) pos32[pi] = positions[pi];
    return { schema: 'OBJ (' + unit + ', axe vertical ' + up + ')', is43: false, isObj: true, noUnitGuard: true, scale: 1, positions: pos32, vertexCount: total, els: els, storeys: [], min: gmin, max: gmax,
      props: function (eid) { return info[eid] ? [{ name: 'Source OBJ', rows: info[eid] }] : []; }, voids: {}, warn: { unsupported: {}, bool: 0, clip: 0, cut: 0, objSkipped: warnN }, skipped: 0, entities: V.length, ms: Date.now() - t0 };
  }
  /* ================= modèle ================= */
  var TYPE_FR = { IFCWALL: 'Murs', IFCWALLSTANDARDCASE: 'Murs', IFCSLAB: 'Dalles', IFCCOLUMN: 'Poteaux', IFCBEAM: 'Poutres', IFCDOOR: 'Portes', IFCWINDOW: 'Fenêtres', IFCROOF: 'Toitures', IFCSTAIR: 'Escaliers', IFCSTAIRFLIGHT: 'Escaliers', IFCRAMP: 'Rampes', IFCRAMPFLIGHT: 'Rampes', IFCFOOTING: 'Fondations', IFCPILE: 'Pieux', IFCCOVERING: 'Revêtements', IFCRAILING: 'Garde-corps', IFCCURTAINWALL: 'Murs-rideaux', IFCPLATE: 'Plaques', IFCMEMBER: 'Éléments structurels', IFCFURNISHINGELEMENT: 'Mobilier', IFCFLOWSEGMENT: 'Réseaux', IFCFLOWTERMINAL: 'Appareils', IFCBUILDINGELEMENTPROXY: 'Éléments divers', IFCSPACE: 'Espaces', IFCOPENINGELEMENT: 'Ouvertures', IFCTRANSPORTELEMENT: 'Transport', IFCGEOGRAPHICELEMENT: 'Terrain', IFCSITE: 'Site' };
  var COLORS = { Murs: [226, 222, 210], Dalles: [168, 172, 178], Poteaux: [196, 168, 140], Poutres: [180, 150, 120], Portes: [150, 98, 60], 'Fenêtres': [140, 200, 235], Toitures: [190, 90, 80], Escaliers: [200, 190, 160], Rampes: [190, 190, 170], Fondations: [120, 120, 125], Pieux: [110, 110, 115], 'Revêtements': [214, 206, 190], 'Garde-corps': [90, 110, 130], 'Murs-rideaux': [150, 205, 230], Plaques: [190, 195, 200], 'Éléments structurels': [175, 160, 140], Mobilier: [160, 130, 100], 'Réseaux': [80, 150, 200], Appareils: [100, 170, 130], Espaces: [120, 190, 240], Terrain: [140, 170, 110] };
  /* IFC 4.3 : infrastructures (routes, voies ferrées, ponts, terrassements, géotechnique…) */
  var TYPE43 = { IFCROAD: 'Routes', IFCROADPART: 'Routes', IFCRAILWAY: 'Voies ferrées', IFCRAILWAYPART: 'Voies ferrées', IFCBRIDGE: 'Ponts', IFCBRIDGEPART: 'Ponts', IFCFACILITY: 'Ouvrages', IFCFACILITYPART: 'Ouvrages', IFCFACILITYPARTCOMMON: 'Ouvrages', IFCMARINEFACILITY: 'Ouvrages maritimes', IFCMARINEPART: 'Ouvrages maritimes',
    IFCPAVEMENT: 'Chaussées', IFCCOURSE: 'Couches de chaussée', IFCKERB: 'Bordures', IFCRAIL: 'Rails', IFCTRACKELEMENT: 'Voie ferrée', IFCSIGN: 'Signalisation', IFCSIGNAL: 'Signalisation', IFCEARTHWORKSELEMENT: 'Terrassements', IFCEARTHWORKSCUT: 'Terrassements', IFCEARTHWORKSFILL: 'Terrassements', IFCEMBANKMENT: 'Remblais', IFCREINFORCEDSOIL: 'Sols renforcés',
    IFCGEOTECHNICALSTRATUM: 'Géotechnique', IFCGEOMODEL: 'Géotechnique', IFCGEOSLICE: 'Géotechnique', IFCBOREHOLE: 'Géotechnique', IFCDEEPFOUNDATION: 'Fondations', IFCBEARING: 'Appareils d’appui', IFCSURFACEFEATURE: 'Marquages', IFCVEHICLE: 'Véhicules', IFCNAVIGATIONELEMENT: 'Signalisation', IFCMOORINGDEVICE: 'Équipements maritimes', IFCLINEARELEMENT: 'Éléments linéaires', IFCCOMMUNICATIONSAPPLIANCE: 'Appareils', IFCELECTRICAPPLIANCE: 'Appareils' };
  Object.keys(TYPE43).forEach(function (k) { if (!TYPE_FR[k]) TYPE_FR[k] = TYPE43[k]; });
  [['Routes', [96, 100, 108]], ['Voies ferrées', [120, 110, 100]], ['Ponts', [170, 170, 175]], ['Ouvrages', [170, 170, 175]], ['Ouvrages maritimes', [90, 140, 180]], ['Chaussées', [88, 92, 100]], ['Couches de chaussée', [110, 112, 118]], ['Bordures', [190, 190, 185]], ['Rails', [130, 130, 135]], ['Voie ferrée', [120, 110, 100]], ['Signalisation', [230, 190, 60]], ['Terrassements', [160, 130, 90]], ['Remblais', [170, 145, 100]], ['Sols renforcés', [150, 130, 100]], ['Géotechnique', [150, 120, 80]], ['Appareils d’appui', [140, 150, 160]], ['Marquages', [240, 240, 240]], ['Véhicules', [180, 80, 80]], ['Équipements maritimes', [110, 150, 170]], ['Éléments linéaires', [160, 160, 170]], ['Fondations', [120, 120, 125]]].forEach(function (c) { COLORS[c[0]] = c[1]; });
  var DEF_COLOR = [200, 200, 205];
  var BODY_TYPES = { SECTIONEDSOLID: 1, SWEPTSOLID: 1, BREP: 1, TESSELLATION: 1, MAPPEDREPRESENTATION: 1, CLIPPING: 1, CSG: 1, SURFACEMODEL: 1, ADVANCEDBREP: 1, SOLIDMODEL: 1, BRIDGEBODY: 1, ADVANCEDSWEPTSOLID: 1 };

  function tick() { return new Promise(function (r) { setTimeout(r, 0); }); }

  async function parse(text, onProgress) {
    var t0 = Date.now(), ent = Object.create(null), byType = Object.create(null), cache = Object.create(null);
    var i0 = text.indexOf('DATA;'); if (text.indexOf('ISO-10303-21') < 0 || i0 < 0) throw new Error('Fichier IFC non reconnu (IFC texte STEP attendu).');
    var schema = (/FILE_SCHEMA\s*\(\s*\(\s*'([^']+)'/.exec(text) || [])[1] || '', is43 = /^IFC4X3/i.test(schema);
    var i1 = text.indexOf('ENDSEC;', i0), body = text.slice(i0 + 5, i1 < 0 ? undefined : i1);
    body = body.replace(/\/\*[\s\S]*?\*\//g, '');
    /* découpe des instructions (« ; » hors chaînes) */
    var pos = 0, N = body.length, count = 0, inStr = false, st = 0, c;
    for (pos = 0; pos < N; pos++) {
      c = body.charCodeAt(pos);
      if (c === 39) inStr = !inStr;
      else if (c === 59 && !inStr) {
        var s = body.slice(st, pos); st = pos + 1;
        var m = /^\s*#(\d+)\s*=\s*([A-Za-z0-9_]+)\s*\(([\s\S]*)\)\s*$/.exec(s);
        if (m) { var id = +m[1], ty = m[2].toUpperCase(); ent[id] = { t: ty, raw: m[3] }; (byType[ty] || (byType[ty] = [])).push(id); }
        if (++count % 60000 === 0) { if (onProgress) onProgress('Lecture… ' + Math.round(pos / N * 100) + ' %'); await tick(); }
      }
    }
    function A(id) { var e = ent[id]; if (!e) return null; if (!e.a) e.a = parseArgs(e.raw); return e.a; }
    function E(ref) { return ref && ref.r !== undefined ? ent[ref.r] : null; }
    function EA(ref) { return ref && ref.r !== undefined ? A(ref.r) : null; }
    var warn = { unsupported: {}, bool: 0, clip: 0 };
    /* unités : longueur → mètres */
    var scale = 1;
    (function () {
      var ids = byType.IFCSIUNIT || [];
      for (var k = 0; k < ids.length; k++) { var a = A(ids[k]); if (a && a[1] === '.LENGTHUNIT.') { var p = a[2]; scale = p === '.MILLI.' ? 0.001 : p === '.CENTI.' ? 0.01 : p === '.DECI.' ? 0.1 : p === '.KILO.' ? 1000 : 1; } }
      var cu = byType.IFCCONVERSIONBASEDUNIT || [];
      for (k = 0; k < cu.length; k++) { var b = A(cu[k]); if (b && b[1] === '.LENGTHUNIT.') { var nm = String(b[2] || '').toUpperCase(); scale = /INCH|POUCE/.test(nm) ? 0.0254 : /FOOT|FEET|PIED/.test(nm) ? 0.3048 : scale; } }
    })();
    /* unités déclarées pour les surfaces et volumes des quantités (sinon : unité de longueur au carré / au cube) */
    var areaScale = scale * scale, volScale = scale * scale * scale;
    (function () {
      var PF = { '.MILLI.': 1e-3, '.CENTI.': 1e-2, '.DECI.': 0.1, '.KILO.': 1e3 }, ids = byType.IFCSIUNIT || [];
      for (var k = 0; k < ids.length; k++) { var a = A(ids[k]); if (!a) continue; var f = a[2] && PF[a[2]] ? PF[a[2]] : 1; if (a[1] === '.AREAUNIT.') areaScale = f * f; else if (a[1] === '.VOLUMEUNIT.') volScale = f * f * f; }
    })();

    /* unité d'angle (radian par défaut ; degré si déclaré « DEGREE ») */
    var angScale = 1;
    (function () {
      var cu = byType.IFCCONVERSIONBASEDUNIT || [];
      for (var k = 0; k < cu.length; k++) { var b = A(cu[k]); if (b && b[1] === '.PLANEANGLEUNIT.' && /DEG/.test(String(b[2] || '').toUpperCase())) angScale = Math.PI / 180; }
    })();

    /* ----- primitives ----- */
    function pt(ref) { var a = EA(ref); return a && Array.isArray(a[0]) ? [a[0][0] || 0, a[0][1] || 0, a[0][2] || 0] : [0, 0, 0]; }
    function dir(ref) { var a = EA(ref); return a && Array.isArray(a[0]) ? [a[0][0] || 0, a[0][1] || 0, a[0][2] || 0] : null; }
    function axis3(ref) {
      var a = EA(ref); if (!a) return I4(); var e = E(ref);
      if (e.t === 'IFCAXIS2PLACEMENT2D') { var O2 = pt(a[0]), rd = dir(a[1]) || [1, 0, 0], X2 = norm3([rd[0], rd[1], 0]) || [1, 0, 0]; return fromAxes(X2, [-X2[1], X2[0], 0], [0, 0, 1], O2); }
      var O = pt(a[0]), Z = norm3(dir(a[1]) || [0, 0, 1]) || [0, 0, 1], X = dir(a[2]) || [1, 0, 0];
      var d = dot(X, Z); X = norm3([X[0] - d * Z[0], X[1] - d * Z[1], X[2] - d * Z[2]]) || (Math.abs(Z[0]) < 0.9 ? norm3(cross([0, 1, 0], Z)) : norm3(cross([0, 0, 1], Z)));
      return fromAxes(X, cross(Z, X), Z, O);
    }
    function place(ref) {
      if (!ref || ref.r === undefined) return I4(); var key = 'P' + ref.r; if (cache[key]) return cache[key];
      var e = ent[ref.r], a = A(ref.r), M = I4();
      if (e && e.t === 'IFCLOCALPLACEMENT') { var par = a[0] ? place(a[0]) : I4(); M = mul(par, axis3(a[1])); }
      else if (e && e.t === 'IFCLINEARPLACEMENT') { /* IFC 4.3 : position le long d'une courbe (CartesianPosition si fournie, sinon calcul sur une courbe polygonale) */
        var par2 = a[0] ? place(a[0]) : I4();
        if (a[2] && E(a[2])) M = mul(par2, axis3(a[2])); else M = mul(par2, linearPlace(a[1]));
      }
      cache[key] = M; return M;
    }
    function num(v) { return typeof v === 'number' ? v : (v && v.v && typeof v.v[0] === 'number' ? v.v[0] : 0); }
    function linearPlace(ref) { /* IfcAxis2PlacementLinear(Location = IfcPointByDistanceExpression, Axis, RefDirection) */
      var a = EA(ref), le = a && E(a[0]); if (!le || le.t !== 'IFCPOINTBYDISTANCEEXPRESSION') { unsup('IFCLINEARPLACEMENT (position)'); return I4(); }
      var la = EA(a[0]), path = la[4] && curve3D(la[4]); if (!path || path.length < 2) { unsup('IFCLINEARPLACEMENT (courbe de base non lue — alignement)'); return I4(); }
      var dAlong = num(la[0]), oL = num(la[1]), oV = num(la[2]), oLg = num(la[3]), cum = 0, P0 = path[0], T = [1, 0, 0], i;
      for (i = 1; i < path.length; i++) { var sl = Math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1], path[i][2] - path[i - 1][2]); T = norm3([path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1], path[i][2] - path[i - 1][2]]) || T; if (cum + sl >= dAlong || i === path.length - 1) { var u = sl > 0 ? Math.max(0, Math.min(1, (dAlong - cum) / sl)) : 0; if (i === path.length - 1 && dAlong > cum + sl) u = 1 + (dAlong - cum - sl) / (sl || 1); P0 = [path[i - 1][0] + (path[i][0] - path[i - 1][0]) * u, path[i - 1][1] + (path[i][1] - path[i - 1][1]) * u, path[i - 1][2] + (path[i][2] - path[i - 1][2]) * u]; break; } cum += sl; }
      var Z = [0, 0, 1], X = norm3([T[0], T[1], 0]) || [1, 0, 0], Y = cross(Z, X);
      var O = [P0[0] + Y[0] * oL + Z[0] * oV + X[0] * oLg, P0[1] + Y[1] * oL + Z[1] * oV + X[1] * oLg, P0[2] + Y[2] * oL + Z[2] * oV + X[2] * oLg];
      return fromAxes(X, Y, Z, O);
    }
    function transformOp(ref) { /* IfcCartesianTransformationOperator3D(Axis1,Axis2,LocalOrigin,Scale,Axis3) */
      var a = EA(ref); if (!a) return I4(); var O = pt(a[2]), s = typeof a[3] === 'number' ? a[3] : 1;
      var X = norm3(dir(a[0]) || [1, 0, 0]) || [1, 0, 0], Y0 = dir(a[1]) || [0, 1, 0], Z = a[4] ? norm3(dir(a[4])) : norm3(cross(X, Y0)) || [0, 0, 1];
      var Y = cross(Z, X); return fromAxes([X[0] * s, X[1] * s, X[2] * s], [Y[0] * s, Y[1] * s, Y[2] * s], [Z[0] * s, Z[1] * s, Z[2] * s], O);
    }
    function ptsOf(list) { return (list || []).map(function (r) { return pt(r); }); }

    /* ----- courbes / profils 2D ----- */
    function arcPts(p1, p2, p3) { /* arc passant par 3 points (2D) → échantillons */
      var ax = p1[0], ay = p1[1], bx = p2[0], by = p2[1], cx = p3[0], cy = p3[1], d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
      if (Math.abs(d) < 1e-12) return [p1, p2, p3];
      var ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d, uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d, r = Math.hypot(ax - ux, ay - uy);
      var a1 = Math.atan2(ay - uy, ax - ux), a2 = Math.atan2(by - uy, bx - ux), a3 = Math.atan2(cy - uy, cx - ux);
      var TW = Math.PI * 2, d12 = ((a2 - a1) % TW + TW) % TW, d13 = ((a3 - a1) % TW + TW) % TW, ccw = d12 < d13, sw = ccw ? d13 : d13 - TW, out = [];
      for (var i = 0; i <= 8; i++) { var an = a1 + sw * i / 8; out.push([ux + r * Math.cos(an), uy + r * Math.sin(an)]); }
      return out;
    }
    function curve2D(ref) {
      var e = E(ref), a = EA(ref); if (!e) return null;
      if (e.t === 'IFCPOLYLINE') return ptsOf(a[0]).map(function (p) { return [p[0], p[1]]; });
      if (e.t === 'IFCINDEXEDPOLYCURVE') {
        var pl = EA(a[0]), L = pl && pl[0] || [], P = L.map(function (c) { return [c[0] || 0, c[1] || 0]; });
        if (!a[1] || !a[1].length) return P;
        var out = [];
        a[1].forEach(function (sg) { if (!sg || !sg.v) return; var ix = (sg.v[0] || []).map(function (n) { return P[n - 1]; }).filter(Boolean); if (sg.t === 'IFCARCINDEX' && ix.length === 3) arcPts(ix[0], ix[1], ix[2]).forEach(function (q) { out.push(q); }); else ix.forEach(function (q) { out.push(q); }); });
        return out;
      }
      if (e.t === 'IFCCOMPOSITECURVE') { var o = []; (a[0] || []).forEach(function (s) { var sa = EA(s), c = sa && curve2D(sa[2]); if (c) c.forEach(function (q) { o.push(q); }); }); return o; }
      return null;
    }
    function profile(ref) { /* → polygone 2D [[x,y],…] ou null */
      var e = E(ref), a = EA(ref); if (!e) return null; var t = e.t, P = null, i;
      if (t === 'IFCRECTANGLEPROFILEDEF' || t === 'IFCROUNDEDRECTANGLEPROFILEDEF' || t === 'IFCRECTANGLEHOLLOWPROFILEDEF') { var x = (a[3] || 0) / 2, y = (a[4] || 0) / 2; P = [[-x, -y], [x, -y], [x, y], [-x, y]]; }
      else if (t === 'IFCCIRCLEPROFILEDEF' || t === 'IFCCIRCLEHOLLOWPROFILEDEF') { var r = a[3] || 0; P = []; for (i = 0; i < 24; i++) P.push([r * Math.cos(i * Math.PI / 12), r * Math.sin(i * Math.PI / 12)]); }
      else if (t === 'IFCELLIPSEPROFILEDEF') { var r1 = a[3] || 0, r2 = a[4] || 0; P = []; for (i = 0; i < 24; i++) P.push([r1 * Math.cos(i * Math.PI / 12), r2 * Math.sin(i * Math.PI / 12)]); }
      else if (t === 'IFCISHAPEPROFILEDEF') { var w = (a[3] || 0) / 2, h = (a[4] || 0) / 2, tw = (a[5] || 0) / 2, tf = a[6] || 0; P = [[-w, -h], [w, -h], [w, -h + tf], [tw, -h + tf], [tw, h - tf], [w, h - tf], [w, h], [-w, h], [-w, h - tf], [-tw, h - tf], [-tw, -h + tf], [-w, -h + tf]]; }
      else if (t === 'IFCLSHAPEPROFILEDEF') { var d = a[3] || 0, wd = a[4] == null ? d : a[4], th = a[5] || 0; P = [[0, 0], [wd, 0], [wd, th], [th, th], [th, d], [0, d]]; }
      else if (t === 'IFCARBITRARYCLOSEDPROFILEDEF' || t === 'IFCARBITRARYPROFILEDEFWITHVOIDS') { P = curve2D(a[2]); }
      else if (t === 'IFCTSHAPEPROFILEDEF') { var bw = (a[3] || 0) / 2, dp = a[4] || 0, wt = (a[5] || 0) / 2, ft = a[6] || 0; P = [[-bw, dp / 2], [bw, dp / 2], [bw, dp / 2 - ft], [wt, dp / 2 - ft], [wt, -dp / 2], [-wt, -dp / 2], [-wt, dp / 2 - ft], [-bw, dp / 2 - ft]]; }
      else if (t === 'IFCUSHAPEPROFILEDEF' || t === 'IFCCSHAPEPROFILEDEF') { var D = a[3] || 0, Wd = a[4] || 0, Tw = a[5] || 0, Tf = a[6] || 0; P = [[-Wd / 2, -D / 2], [Wd / 2, -D / 2], [Wd / 2, -D / 2 + Tf], [-Wd / 2 + Tw, -D / 2 + Tf], [-Wd / 2 + Tw, D / 2 - Tf], [Wd / 2, D / 2 - Tf], [Wd / 2, D / 2], [-Wd / 2, D / 2]]; }
      if (!P || P.length < 3) return null;
      var f = P[0], l = P[P.length - 1]; if (P.length > 3 && Math.abs(f[0] - l[0]) < 1e-9 && Math.abs(f[1] - l[1]) < 1e-9) P = P.slice(0, -1);
      if (e.t !== 'IFCARBITRARYCLOSEDPROFILEDEF' && e.t !== 'IFCARBITRARYPROFILEDEFWITHVOIDS' && a[2] && a[2].r !== undefined) { var M = axis3(a[2]); P = P.map(function (p) { var q = tp(M, p[0], p[1], 0); return [q[0], q[1]]; }); }
      return P;
    }

    /* ----- constructeur de maillage (sommets en mètres, triangles indépendants) ----- */
    function Mesh() { this.v = []; }
    Mesh.prototype.tri = function (a, b, c, M) { var A = tp(M, a[0], a[1], a[2]), B = tp(M, b[0], b[1], b[2]), C = tp(M, c[0], c[1], c[2]); this.v.push(A[0], A[1], A[2], B[0], B[1], B[2], C[0], C[1], C[2]); };
    Mesh.prototype.poly = function (pts, M) { var t = triPoly3D(pts); for (var i = 0; i < t.length; i++) this.tri(pts[t[i][0]], pts[t[i][1]], pts[t[i][2]], M); };

    /* ----- V99 : géométries ajoutées (révolution, disque balayé, extrusion conique, découpe par demi-espace) ----- */
    function sVol(v) { var V = 0; for (var o = 0; o + 8 < v.length; o += 9) V += (v[o] * (v[o + 4] * v[o + 8] - v[o + 5] * v[o + 7]) - v[o + 1] * (v[o + 3] * v[o + 8] - v[o + 5] * v[o + 6]) + v[o + 2] * (v[o + 3] * v[o + 7] - v[o + 4] * v[o + 6])) / 6; return V; }
    function flipTris(v) { for (var o = 0; o + 8 < v.length; o += 9) { for (var k = 0; k < 3; k++) { var t = v[o + 3 + k]; v[o + 3 + k] = v[o + 6 + k]; v[o + 6 + k] = t; } } return v; }
    function pushOriented(mesh, tmp) { var v = tmp.v; if (sVol(v) < 0) flipTris(v); for (var i = 0; i < v.length; i++) mesh.v.push(v[i]); }
    function unsup(k) { warn.unsupported[k] = (warn.unsupported[k] || 0) + 1; }
    function arcPts3(p1, p2, p3) { /* arc de cercle passant par 3 points 3D → échantillons (p1 inclus, p3 inclus) */
      var u = [p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]], w = [p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]], n = cross(u, w), nn = dot(n, n);
      if (nn < 1e-18) return [p1, p3];
      var c1 = cross(n, u), c2 = cross(w, n), a = dot(u, u), b = dot(w, w), cen = [p1[0] + (b * c1[0] + a * c2[0]) / (2 * nn), p1[1] + (b * c1[1] + a * c2[1]) / (2 * nn), p1[2] + (b * c1[2] + a * c2[2]) / (2 * nn)];
      var e1 = norm3([p1[0] - cen[0], p1[1] - cen[1], p1[2] - cen[2]]), nz = norm3(n), e2 = cross(nz, e1), r = Math.hypot(p1[0] - cen[0], p1[1] - cen[1], p1[2] - cen[2]);
      var ang = function (p) { var d = [p[0] - cen[0], p[1] - cen[1], p[2] - cen[2]]; return Math.atan2(dot(d, e2), dot(d, e1)); };
      var a2 = ang(p2), a3 = ang(p3); if (a2 < 0) a2 += 2 * Math.PI; if (a3 < 0) a3 += 2 * Math.PI;
      var tot = a3; /* p1 → p2 → p3 est parcouru dans le sens trigonométrique autour de n = (p2−p1)×(p3−p1) */
      var ns = Math.max(4, Math.ceil(tot / (Math.PI / 12))), out = [];
      for (var i = 0; i <= ns; i++) { var t = tot * i / ns; out.push([cen[0] + r * (Math.cos(t) * e1[0] + Math.sin(t) * e2[0]), cen[1] + r * (Math.cos(t) * e1[1] + Math.sin(t) * e2[1]), cen[2] + r * (Math.cos(t) * e1[2] + Math.sin(t) * e2[2])]); }
      return out;
    }
    function curve3D(ref) { /* directrice 3D : polyligne, polycourbe indexée (segments et arcs), courbe composée de polylignes → [[x,y,z],…] ou null */
      var e = E(ref), a = EA(ref); if (!e) return null;
      if (e.t === 'IFCPOLYLINE') return ptsOf(a[0]);
      if (e.t === 'IFCINDEXEDPOLYCURVE') {
        var pl = EA(a[0]), L = pl && pl[0] || [], P = L.map(function (c) { return [c[0] || 0, c[1] || 0, c[2] || 0]; });
        if (!a[1] || !a[1].length) return P;
        var out = [];
        a[1].forEach(function (sg) {
          if (!sg || !sg.v) return; var ix = (sg.v[0] || []).map(function (n) { return P[n - 1]; }).filter(Boolean), q = [];
          if (sg.t === 'IFCARCINDEX' && ix.length === 3) q = arcPts3(ix[0], ix[1], ix[2]); else q = ix;
          q.forEach(function (p, j) { if (out.length && j === 0) { var l = out[out.length - 1]; if (Math.hypot(l[0] - p[0], l[1] - p[1], l[2] - p[2]) < 1e-9) return; } out.push(p); });
        });
        return out;
      }
      if (e.t === 'IFCCOMPOSITECURVE') {
        var o = []; (a[0] || []).forEach(function (s) { var sa = EA(s), c = sa && curve3D(sa[2]); if (!c) return; if (sa[1] === '.F.') c = c.slice().reverse(); c.forEach(function (p, j) { if (o.length && j === 0) { var l = o[o.length - 1]; if (Math.hypot(l[0] - p[0], l[1] - p[1], l[2] - p[2]) < 1e-9) return; } o.push(p); }); });
        return o.length > 1 ? o : null;
      }
      return null;
    }
    function sweptDisk(a, M, mesh) { /* IfcSweptDiskSolid(Directrix, Radius, InnerRadius, StartParam, EndParam) : tube plein autour de la directrice */
      var path = curve3D(a[0]), r = a[1] || 0; if (!path || path.length < 2 || !(r > 0)) { unsup('IFCSWEPTDISKSOLID (directrice)'); return; }
      var q = [path[0]]; for (var i = 1; i < path.length; i++) { var l = q[q.length - 1]; if (Math.hypot(path[i][0] - l[0], path[i][1] - l[1], path[i][2] - l[2]) > 1e-9) q.push(path[i]); }
      if (q.length < 2) { unsup('IFCSWEPTDISKSOLID (directrice)'); return; }
      if (a[2] > 0) unsup('IFCSWEPTDISKSOLID (rayon intérieur ignoré)');
      var T = [], m = q.length, NS = 16;
      for (i = 0; i < m; i++) { var d1 = i > 0 ? norm3([q[i][0] - q[i - 1][0], q[i][1] - q[i - 1][1], q[i][2] - q[i - 1][2]]) : null, d2 = i < m - 1 ? norm3([q[i + 1][0] - q[i][0], q[i + 1][1] - q[i][1], q[i + 1][2] - q[i][2]]) : null; var t = d1 && d2 ? norm3([d1[0] + d2[0], d1[1] + d2[1], d1[2] + d2[2]]) || d2 : (d1 || d2); T.push(t); }
      var n0 = Math.abs(T[0][2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], nn = norm3(cross(T[0], n0)), rings = [];
      for (i = 0; i < m; i++) {
        var tt = T[i], dn = dot(nn, tt), nv = norm3([nn[0] - dn * tt[0], nn[1] - dn * tt[1], nn[2] - dn * tt[2]]) || nn; nn = nv; var bv = cross(tt, nv), ring = [];
        for (var k = 0; k < NS; k++) { var an = 2 * Math.PI * k / NS, c = Math.cos(an) * r, s = Math.sin(an) * r; ring.push([q[i][0] + c * nv[0] + s * bv[0], q[i][1] + c * nv[1] + s * bv[1], q[i][2] + c * nv[2] + s * bv[2]]); }
        rings.push(ring);
      }
      var tmp = new Mesh();
      for (i = 0; i + 1 < m; i++) for (k = 0; k < NS; k++) { var k2 = (k + 1) % NS; tmp.tri(rings[i][k], rings[i][k2], rings[i + 1][k2], M); tmp.tri(rings[i][k], rings[i + 1][k2], rings[i + 1][k], M); }
      tmp.poly(rings[0], M); tmp.poly(rings[m - 1], M);
      pushOriented(mesh, tmp);
    }
    function sweptArea(a, M, mesh, kind) { /* IfcFixedReferenceSweptAreaSolid / IfcSurfaceCurveSweptAreaSolid(SweptArea, Position, Directrix, StartParam, EndParam, FixedReference | ReferenceSurface) */
      var lab = kind === 'fixed' ? 'IFCFIXEDREFERENCESWEPTAREASOLID' : 'IFCSURFACECURVESWEPTAREASOLID';
      var P = profile(a[0]); if (!P) { unsup(lab + ' (profil)'); return; }
      var path0 = curve3D(a[2]); if (!path0 || path0.length < 2) { unsup(lab + ' (directrice non lue : alignement / courbe de référence)'); return; }
      var q = [path0[0]]; for (var i = 1; i < path0.length; i++) { var l = q[q.length - 1]; if (Math.hypot(path0[i][0] - l[0], path0[i][1] - l[1], path0[i][2] - l[2]) > 1e-9) q.push(path0[i]); }
      if (q.length < 2) { unsup(lab + ' (directrice)'); return; }
      var Pos = axis3(a[1]); P = P.map(function (p) { var w = tp(Pos, p[0], p[1], 0); return [w[0], w[1]]; });
      var ref = [0, 0, 1];
      if (kind === 'fixed') { ref = norm3(dir(a[5]) || [0, 0, 1]) || [0, 0, 1]; }
      else { var se = E(a[5]); if (se && se.t === 'IFCPLANE') { var Mp = axis3(EA(a[5])[0]); ref = [Mp[2], Mp[6], Mp[10]]; } }
      var m = q.length, rings = [], tg = [];
      for (i = 0; i < m; i++) { var d1 = i > 0 ? norm3([q[i][0] - q[i - 1][0], q[i][1] - q[i - 1][1], q[i][2] - q[i - 1][2]]) : null, d2 = i < m - 1 ? norm3([q[i + 1][0] - q[i][0], q[i + 1][1] - q[i][1], q[i + 1][2] - q[i][2]]) : null; tg.push(d1 && d2 ? (norm3([d1[0] + d2[0], d1[1] + d2[1], d1[2] + d2[2]]) || d2) : (d2 || d1)); }
      for (i = 0; i < m; i++) {
        var T = tg[i], dr = dot(ref, T), rp = norm3([ref[0] - dr * T[0], ref[1] - dr * T[1], ref[2] - dr * T[2]]) || (Math.abs(T[2]) < 0.9 ? norm3(cross(T, [0, 0, 1])) : [1, 0, 0]), X, Y;
        Y = rp; X = cross(Y, T); /* axe Y du profil = direction de référence projetée (verticale pour une route), axe X = latéral */
        var ring = P.map(function (p) { return [q[i][0] + p[0] * X[0] + p[1] * Y[0], q[i][1] + p[0] * X[1] + p[1] * Y[1], q[i][2] + p[0] * X[2] + p[1] * Y[2]]; });
        rings.push(ring);
      }
      var n = P.length, tmp = new Mesh();
      for (i = 0; i + 1 < m; i++) for (var k = 0; k < n; k++) { var k2 = (k + 1) % n; tmp.tri(rings[i][k], rings[i][k2], rings[i + 1][k2], M); tmp.tri(rings[i][k], rings[i + 1][k2], rings[i + 1][k], M); }
      tmp.poly(rings[0], M); tmp.poly(rings[m - 1], M);
      pushOriented(mesh, tmp);
    }
    function revolved(a, M, mesh) { /* IfcRevolvedAreaSolid(SweptArea, Position, Axis, Angle) */
      var P = profile(a[0]); if (!P) { unsup('IFCREVOLVEDAREASOLID (profil)'); return; }
      var S = mul(M, axis3(a[1])), ax = EA(a[2]), loc = ax ? pt(ax[0]) : [0, 0, 0], ad = ax && dir(ax[1]) ? norm3(dir(ax[1])) : [0, 0, 1];
      if (!ad) { unsup('IFCREVOLVEDAREASOLID (axe)'); return; }
      var ang = (a[3] || 0) * angScale; if (!ang) { unsup('IFCREVOLVEDAREASOLID (angle nul)'); return; }
      var full = Math.abs(ang) >= 2 * Math.PI - 1e-6; if (full) ang = ang > 0 ? 2 * Math.PI : -2 * Math.PI;
      var ns = Math.max(8, Math.ceil(Math.abs(ang) / (2 * Math.PI) * 48)), n = P.length, rot = function (p, th) { /* Rodrigues autour de (loc, ad) */
        var v = [p[0] - loc[0], p[1] - loc[1], 0 - loc[2]], c = Math.cos(th), s = Math.sin(th), kv = cross(ad, v), kd = dot(ad, v);
        return [loc[0] + v[0] * c + kv[0] * s + ad[0] * kd * (1 - c), loc[1] + v[1] * c + kv[1] * s + ad[1] * kd * (1 - c), loc[2] + v[2] * c + kv[2] * s + ad[2] * kd * (1 - c)];
      }, rings = [];
      for (var s2 = 0; s2 <= ns; s2++) { var th = ang * s2 / ns, rg = []; for (var i = 0; i < n; i++) rg.push(rot(P[i], th)); rings.push(rg); }
      var tmp = new Mesh(), last = ns;
      for (s2 = 0; s2 < ns; s2++) for (i = 0; i < n; i++) { var i2 = (i + 1) % n; tmp.tri(rings[s2][i], rings[s2][i2], rings[s2 + 1][i2], S); tmp.tri(rings[s2][i], rings[s2 + 1][i2], rings[s2 + 1][i], S); }
      if (!full) { tmp.poly(rings[0], S); tmp.poly(rings[last], S); }
      pushOriented(mesh, tmp);
    }
    function tapered(a, M, mesh) { /* IfcExtrudedAreaSolidTapered(SweptArea, Position, ExtrudedDirection, Depth, EndSweptArea) */
      var P = profile(a[0]), P2 = profile(a[4]); if (!P || !P2 || P.length !== P2.length) { unsup('IFCEXTRUDEDAREASOLIDTAPERED (profils)'); return; }
      var S = mul(M, axis3(a[1])), D = norm3(dir(a[2]) || [0, 0, 1]) || [0, 0, 1], dep = a[3] || 0, off = [D[0] * dep, D[1] * dep, D[2] * dep], n = P.length;
      var ar = function (Q) { var s = 0; for (var i = 0; i < Q.length; i++) { var p = Q[i], q = Q[(i + 1) % Q.length]; s += p[0] * q[1] - q[0] * p[1]; } return s; };
      if ((ar(P) < 0) !== (ar(P2) < 0)) P2 = P2.slice().reverse();
      var tmp = new Mesh(), B = P.map(function (p) { return [p[0], p[1], 0]; }), T = P2.map(function (p) { return [p[0] + off[0], p[1] + off[1], off[2]]; });
      for (var i = 0; i < n; i++) { var i2 = (i + 1) % n; tmp.tri(B[i], B[i2], T[i2], S); tmp.tri(B[i], T[i2], T[i], S); }
      tmp.poly(B, S); tmp.poly(T, S); pushOriented(mesh, tmp);
    }
    function clipKey(p, q) { return Math.round(p[0] / q) + '|' + Math.round(p[1] / q) + '|' + Math.round(p[2] / q); }
    function clipHalf(v, O, nrm, sg) { /* garde la partie de v (maillage fermé) où sg·(n·(p−O)) ≥ 0 ; referme la coupe ; null si impossible */
      var mn = [1e30, 1e30, 1e30], mx = [-1e30, -1e30, -1e30], i, k; for (i = 0; i < v.length; i += 3) for (k = 0; k < 3; k++) { if (v[i + k] < mn[k]) mn[k] = v[i + k]; if (v[i + k] > mx[k]) mx[k] = v[i + k]; }
      var diag = Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) || 1, eps = diag * 1e-9, qn = diag * 1e-7;
      var val = function (p) { return sg * (nrm[0] * (p[0] - O[0]) + nrm[1] * (p[1] - O[1]) + nrm[2] * (p[2] - O[2])); };
      var out = [], segs = [], any = false;
      for (var o = 0; o + 8 < v.length; o += 9) {
        var tri = [[v[o], v[o + 1], v[o + 2]], [v[o + 3], v[o + 4], v[o + 5]], [v[o + 6], v[o + 7], v[o + 8]]], vs = tri.map(val);
        if (vs[0] >= -eps && vs[1] >= -eps && vs[2] >= -eps) { out.push.apply(out, v.slice(o, o + 9)); continue; }
        any = true; if (vs[0] < -eps && vs[1] < -eps && vs[2] < -eps) continue;
        var poly = [], ex = null, en = null;
        for (i = 0; i < 3; i++) {
          var a = tri[i], b = tri[(i + 1) % 3], va = vs[i], vb = vs[(i + 1) % 3], ia = va >= -eps, ib = vb >= -eps;
          if (ia) poly.push(a);
          if (ia !== ib) { var t = va / (va - vb), I = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; poly.push(I); if (ia) ex = I; else en = I; }
        }
        if (poly.length >= 3) { for (i = 1; i + 1 < poly.length; i++) { var q3 = [poly[0], poly[i], poly[i + 1]]; if (polyAreaOk(q3)) for (k = 0; k < 3; k++) out.push(q3[k][0], q3[k][1], q3[k][2]); } }
        if (ex && en && Math.hypot(ex[0] - en[0], ex[1] - en[1], ex[2] - en[2]) > qn) segs.push({ a: ex, b: en });
      }
      if (!any) return v.slice();                                  /* rien à couper */
      if (!out.length) return [];                                  /* tout est coupé */
      /* chaînage des segments de coupe en boucles */
      var map = Object.create(null); segs.forEach(function (s, ix) { s.k0 = clipKey(s.a, qn); s.k1 = clipKey(s.b, qn); (map[s.k0] || (map[s.k0] = [])).push(ix); });
      var used = new Array(segs.length), loops = [];
      for (var si = 0; si < segs.length; si++) {
        if (used[si]) continue; var first = segs[si], cur = first, loop = [first.a], guard = 0; used[si] = true;
        while (cur.k1 !== first.k0) {
          if (++guard > segs.length + 2) return null;
          var nxt = (map[cur.k1] || []).filter(function (ix) { return !used[ix]; })[0];
          if (nxt === undefined) return null;
          cur = segs[nxt]; used[nxt] = true; loop.push(cur.a);
        }
        if (loop.length >= 3) loops.push(loop);
      }
      if (!loops.length) return null;
      var w = [-sg * nrm[0], -sg * nrm[1], -sg * nrm[2]], ref = Math.abs(w[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], u = norm3(cross(w, ref)), vv = cross(w, u), L2 = [];
      loops.forEach(function (lp) { var nw = [0, 0, 0]; for (var j = 0; j < lp.length; j++) { var p = lp[j], q = lp[(j + 1) % lp.length]; nw[0] += (p[1] - q[1]) * (p[2] + q[2]); nw[1] += (p[2] - q[2]) * (p[0] + q[0]); nw[2] += (p[0] - q[0]) * (p[1] + q[1]); } if (dot(nw, w) < 0) lp = lp.slice().reverse(); L2.push({ p3: lp, p2: lp.map(function (p) { return [dot(p, u), dot(p, vv)]; }) }); });
      function inside2(pt2, poly) { var c = false; for (var j = 0, l = poly.length - 1; j < poly.length; l = j++) { if ((poly[j][1] > pt2[1]) !== (poly[l][1] > pt2[1]) && pt2[0] < (poly[l][0] - poly[j][0]) * (pt2[1] - poly[j][1]) / (poly[l][1] - poly[j][1]) + poly[j][0]) c = !c; } return c; }
      for (i = 0; i < L2.length; i++) for (k = 0; k < L2.length; k++) if (i !== k && inside2(L2[i].p2[0], L2[k].p2)) return null;   /* coupe avec trou : non géré */
      L2.forEach(function (lp) {
        var tr = earClip(lp.p2); for (var j = 0; j + 2 < tr.length; j += 3) { var A0 = lp.p2[tr[j]], B0 = lp.p2[tr[j + 1]], C0 = lp.p2[tr[j + 2]], P3 = [lp.p3[tr[j]], lp.p3[tr[j + 1]], lp.p3[tr[j + 2]]]; if ((B0[0] - A0[0]) * (C0[1] - A0[1]) - (B0[1] - A0[1]) * (C0[0] - A0[0]) < 0) P3 = [P3[0], P3[2], P3[1]]; for (var z = 0; z < 3; z++) out.push(P3[z][0], P3[z][1], P3[z][2]); }
      });
      /* contrôle : maillage fermé (chaque arête est parcourue une fois dans chaque sens) */
      var dc = Object.create(null);
      for (o = 0; o + 8 < out.length; o += 9) for (i = 0; i < 3; i++) { var ka = clipKey([out[o + i * 3], out[o + i * 3 + 1], out[o + i * 3 + 2]], qn), kb = clipKey([out[o + ((i + 1) % 3) * 3], out[o + ((i + 1) % 3) * 3 + 1], out[o + ((i + 1) % 3) * 3 + 2]], qn); if (ka !== kb) dc[ka + '>' + kb] = (dc[ka + '>' + kb] || 0) + 1; }
      for (var dk in dc) { var pr = dk.split('>'); if ((dc[pr[1] + '>' + pr[0]] || 0) !== dc[dk]) return null; }
      return out;
    }
    function safeClip(f, r, M, mesh, c) { try { return halfSpaceClip(f, r, M, mesh, c); } catch (e) { return false; } }
    function halfSpaceClip(first, secRef, M, mesh, colorRef) { /* A − demi-espace : renvoie true si la découpe a été réalisée */
      var sec = E(secRef), h = EA(secRef), hs = E(h[0]) && E(h[0]).t === 'IFCPLANE' ? EA(h[0]) : null; if (!hs) return false;
      var S = mul(M, axis3(hs[0])), O = [S[3], S[7], S[11]], nrm = norm3([S[2], S[6], S[10]]); if (!nrm) return false;
      var tmp = new Mesh(); solid(first, M, tmp, colorRef); if (!tmp.v.length) return true;
      if (sec.t === 'IFCPOLYGONALBOUNDEDHALFSPACE') { /* contour : on exige qu'il englobe tout l'élément (sinon la découpe n'est pas appliquée) */
        var B = curve2D(h[3]), Sb = mul(M, axis3(h[2])); if (!B || B.length < 3) return false; var bx = [1e30, 1e30, -1e30, -1e30]; B.forEach(function (p) { if (p[0] < bx[0]) bx[0] = p[0]; if (p[1] < bx[1]) bx[1] = p[1]; if (p[0] > bx[2]) bx[2] = p[0]; if (p[1] > bx[3]) bx[3] = p[1]; });
        var Ri = rigidInv(Sb); for (var z = 0; z < tmp.v.length; z += 3) { var lp = tp(Ri, tmp.v[z], tmp.v[z + 1], tmp.v[z + 2]), tol = 1e-6 * (Math.abs(bx[2] - bx[0]) + 1); if (lp[0] < bx[0] - tol || lp[0] > bx[2] + tol || lp[1] < bx[1] - tol || lp[1] > bx[3] + tol) return false; }
      }
      var sg = String(h[1]).toUpperCase() === '.T.' ? 1 : -1;    /* AgreementFlag vrai : la matière du demi-espace est du côté opposé à la normale → on garde le côté de la normale */
      var res = clipHalf(tmp.v, O, nrm, sg); if (!res) return false;
      for (var i = 0; i < res.length; i++) mesh.v.push(res[i]); return true;
    }

    function solid(ref, M, mesh, colorRef) {
      var e = E(ref), a = EA(ref); if (!e) return;
      var t = e.t;
      if (t === 'IFCEXTRUDEDAREASOLID') {
        var P = profile(a[0]); if (!P) { warn.unsupported[t + ' (profil)'] = (warn.unsupported[t + ' (profil)'] || 0) + 1; return; }
        var S = mul(M, axis3(a[1])), D = norm3(dir(a[2]) || [0, 0, 1]) || [0, 0, 1], dep = a[3] || 0, n = P.length;
        var off = [D[0] * dep, D[1] * dep, D[2] * dep];
        /* faces à sens cohérent (sortant) : profil anti-horaire, fond retourné, côtés du bas vers le haut — indispensable au calcul exact des volumes */
        var ar = 0; for (var ia = 0; ia < n; ia++) { var pa = P[ia], pb = P[(ia + 1) % n]; ar += pa[0] * pb[1] - pb[0] * pa[1]; }
        if (ar < 0) { P = P.slice().reverse(); }
        var up = off[2] >= 0, tr = earClip(P);
        for (var k = 0; k < tr.length; k += 3) {
          var p0 = P[tr[k]], p1 = P[tr[k + 1]], p2 = P[tr[k + 2]];
          if ((p1[0] - p0[0]) * (p2[1] - p0[1]) - (p1[1] - p0[1]) * (p2[0] - p0[0]) < 0) { var tmp = p1; p1 = p2; p2 = tmp; }
          var A0 = [[p0[0], p0[1], 0], [p1[0], p1[1], 0], [p2[0], p2[1], 0]], A1 = [[p0[0] + off[0], p0[1] + off[1], off[2]], [p1[0] + off[0], p1[1] + off[1], off[2]], [p2[0] + off[0], p2[1] + off[1], off[2]]];
          if (up) { mesh.tri(A0[0], A0[2], A0[1], S); mesh.tri(A1[0], A1[1], A1[2], S); } else { mesh.tri(A0[0], A0[1], A0[2], S); mesh.tri(A1[0], A1[2], A1[1], S); }
        }
        for (var i = 0; i < n; i++) { var q = P[i], r = P[(i + 1) % n]; var q0 = [q[0], q[1], 0], r0 = [r[0], r[1], 0], q1 = [q[0] + off[0], q[1] + off[1], off[2]], r1 = [r[0] + off[0], r[1] + off[1], off[2]]; if (up) { mesh.tri(q0, r0, r1, S); mesh.tri(q0, r1, q1, S); } else { mesh.tri(q0, r1, r0, S); mesh.tri(q0, q1, r1, S); } }
      } else if (t === 'IFCFACETEDBREP' || t === 'IFCFACETEDBREPWITHVOIDS') { shell(E(a[0]) ? EA(a[0]) : null, M, mesh, 'IFCCLOSEDSHELL'); }
      else if (t === 'IFCFACEBASEDSURFACEMODEL') { (a[0] || []).forEach(function (s) { shell(EA(s), M, mesh); }); }
      else if (t === 'IFCSHELLBASEDSURFACEMODEL') { (a[0] || []).forEach(function (s) { shell(EA(s), M, mesh); }); }
      else if (t === 'IFCTRIANGULATEDFACESET' || t === 'IFCPOLYGONALFACESET') {
        var cl = EA(a[0]), L = cl && cl[0] || [], pts = L.map(function (c) { return [c[0] || 0, c[1] || 0, c[2] || 0]; });
        if (t === 'IFCTRIANGULATEDFACESET') (a[3] || []).forEach(function (f) { if (f.length >= 3) mesh.tri(pts[f[0] - 1], pts[f[1] - 1], pts[f[2] - 1], M); });
        else (a[2] || []).forEach(function (fr) { var fa = EA(fr); var ix = fa && fa[0] || (fr && fr.v && fr.v[0]) || []; var pl = ix.map(function (n) { return pts[n - 1]; }).filter(Boolean); mesh.poly(pl, M); });
      } else if (t === 'IFCBLOCK') { var S2 = mul(M, axis3(a[0])), X = a[1] || 0, Y = a[2] || 0, Z = a[3] || 0, V = [[0, 0, 0], [X, 0, 0], [X, Y, 0], [0, Y, 0], [0, 0, Z], [X, 0, Z], [X, Y, Z], [0, Y, Z]]; [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]].forEach(function (f) { mesh.poly(f.map(function (j) { return V[j]; }), S2); }); }
      else if (t === 'IFCRIGHTCIRCULARCYLINDER') { var S3 = mul(M, axis3(a[0])), H = a[1] || 0, R = a[2] || 0, c0 = [], c1 = []; for (var j = 0; j < 24; j++) { var an = j * Math.PI / 12; c0.push([R * Math.cos(an), R * Math.sin(an), 0]); c1.push([R * Math.cos(an), R * Math.sin(an), H]); } mesh.poly(c0, S3); mesh.poly(c1, S3); for (j = 0; j < 24; j++) { var j2 = (j + 1) % 24; mesh.tri(c0[j], c0[j2], c1[j2], S3); mesh.tri(c0[j], c1[j2], c1[j], S3); } }
      else if (t === 'IFCMAPPEDITEM') {
        var src = EA(a[0]); if (!src) return; var rep = EA(src[1]); var Mt = mul(M, mul(transformOp(a[1]), rigidInv(axis3(src[0]))));
        if (rep) (rep[3] || []).forEach(function (it) { solid(it, Mt, mesh, colorRef); });
      } else if (t === 'IFCREVOLVEDAREASOLID') { revolved(a, M, mesh); }
      else if (t === 'IFCSWEPTDISKSOLID') { sweptDisk(a, M, mesh); }
      else if (t === 'IFCEXTRUDEDAREASOLIDTAPERED') { tapered(a, M, mesh); }
      else if (t === 'IFCBOOLEANRESULT' || t === 'IFCBOOLEANCLIPPINGRESULT') {
        var sec = E(a[2]);
        if (String(a[0]) === '.DIFFERENCE.' && sec && (sec.t === 'IFCHALFSPACESOLID' || sec.t === 'IFCPOLYGONALBOUNDEDHALFSPACE') && safeClip(a[1], a[2], M, mesh, colorRef)) { warn.clip++; return; }
        warn.bool++; solid(a[1], M, mesh, colorRef);
      }
      else if (t === 'IFCFIXEDREFERENCESWEPTAREASOLID') { sweptArea(a, M, mesh, 'fixed'); }
      else if (t === 'IFCSURFACECURVESWEPTAREASOLID') { sweptArea(a, M, mesh, 'surface'); }
      else if (t === 'IFCSECTIONEDSOLIDHORIZONTAL' || t === 'IFCSECTIONEDSOLID' || t === 'IFCSECTIONEDSURFACE') { unsup(t + ' (sections le long d’un alignement — IFC 4.3, non lu)'); }
      else if (t === 'IFCSHAPEREPRESENTATION') { (a[3] || []).forEach(function (it) { solid(it, M, mesh, colorRef); }); }
      else { warn.unsupported[t] = (warn.unsupported[t] || 0) + 1; }
    }
    function shell(a, M, mesh) { /* a = arguments d'un IfcClosedShell / OpenShell / ConnectedFaceSet : [[faces]] */
      if (!a) return; (a[0] || []).forEach(function (fr) {
        var fa = EA(fr); if (!fa) return; var bounds = fa[0] || [], best = null;
        for (var i = 0; i < bounds.length; i++) { var be = E(bounds[i]); if (be && be.t === 'IFCFACEOUTERBOUND') { best = bounds[i]; break; } } if (!best) best = bounds[0]; if (!best) return;
        var ba = EA(best), loop = ba && E(ba[0]) && EA(ba[0]); if (!loop) return;
        var pts = ptsOf(loop[0]); if (pts.length > 2 && ba[1] === '.F.') pts.reverse(); mesh.poly(pts, M);
      });
    }

    /* ----- couleurs (IfcStyledItem) ----- */
    var colorOf = Object.create(null);
    (byType.IFCSTYLEDITEM || []).forEach(function (id) {
      try {
        var a = A(id); if (!a || !a[0]) return; var col = null;
        (function walk(v, depth) { if (col || depth > 6 || !v) return; if (Array.isArray(v)) { v.forEach(function (x) { walk(x, depth + 1); }); return; } if (v.r === undefined) return; var e = ent[v.r]; if (!e) return; var ea = A(v.r);
          if (e.t === 'IFCCOLOURRGB') { col = [Math.round((ea[1] || 0) * 255), Math.round((ea[2] || 0) * 255), Math.round((ea[3] || 0) * 255)]; return; }
          if (/^IFC(PRESENTATIONSTYLEASSIGNMENT|SURFACESTYLE|SURFACESTYLERENDERING|SURFACESTYLESHADING)$/.test(e.t)) ea.forEach(function (x) { walk(x, depth + 1); }); })(a[1], 0);
        if (col) colorOf[a[0].r] = col;
      } catch (e) { /* style ignoré */ }
    });
    function itemColor(rep) { var c = null; (EA(rep) && EA(rep)[3] || []).forEach(function (it) { if (!c && it && colorOf[it.r]) c = colorOf[it.r]; }); return c; }

    /* ----- relations : niveaux et propriétés ----- */
    var storeyOf = Object.create(null), storeys = [], relProps = Object.create(null);
    (byType.IFCBUILDINGSTOREY || []).forEach(function (id) { var a = A(id); storeys.push({ id: id, name: a[2] || ('Niveau ' + id), elev: (typeof a[9] === 'number' ? a[9] : 0) * scale }); });
    /* IFC 4.3 : parties d'ouvrage (route, pont, voie ferrée…) utilisées comme « niveaux » de regroupement */
    ['IFCFACILITYPART', 'IFCBRIDGEPART', 'IFCROADPART', 'IFCRAILWAYPART', 'IFCMARINEPART', 'IFCFACILITY', 'IFCBRIDGE', 'IFCROAD', 'IFCRAILWAY', 'IFCMARINEFACILITY'].forEach(function (tn) { (byType[tn] || []).forEach(function (id) { var a = A(id); if (a) storeys.push({ id: id, name: a[2] || (tn.replace(/^IFC/, '') + ' ' + id), elev: -1e9 }); }); });
    storeys.sort(function (a, b) { return a.elev - b.elev; });
    var stName = Object.create(null); storeys.forEach(function (s) { stName[s.id] = s.name; });
    (byType.IFCRELCONTAINEDINSPATIALSTRUCTURE || []).forEach(function (id) { var a = A(id), s = a[5] && stName[a[5].r]; if (s) (a[4] || []).forEach(function (r) { storeyOf[r.r] = s; }); });
    (byType.IFCRELREFERENCEDINSPATIALSTRUCTURE || []).forEach(function (id) { var a = A(id), s = a[5] && stName[a[5].r]; if (s) (a[4] || []).forEach(function (r) { if (r && r.r !== undefined && !storeyOf[r.r]) storeyOf[r.r] = s; }); });
    (byType.IFCRELAGGREGATES || []).forEach(function (id) { var a = A(id), pn = a[4] && stName[a[4].r]; if (pn) (a[5] || []).forEach(function (r) { if (!storeyOf[r.r]) storeyOf[r.r] = pn; }); });
    var voidsOf = Object.create(null);
    (byType.IFCRELVOIDSELEMENT || []).forEach(function (id) { var a = A(id); if (a && a[4] && a[5] && a[4].r !== undefined && a[5].r !== undefined) (voidsOf[a[4].r] || (voidsOf[a[4].r] = [])).push(a[5].r); });
    (byType.IFCRELDEFINESBYPROPERTIES || []).forEach(function (id) { var a = A(id); if (!a[5] || a[5].r === undefined) return; (a[4] || []).forEach(function (r) { (relProps[r.r] || (relProps[r.r] = [])).push(a[5].r); }); });
    function props(elId) {
      var out = [];
      (relProps[elId] || []).forEach(function (pid) {
        var pe = ent[pid]; if (!pe) return; var a = A(pid), grp = { name: a[2] || pe.t, rows: [] };
        if (pe.t === 'IFCPROPERTYSET') (a[4] || []).forEach(function (r) { var ra = EA(r), re = E(r); if (!ra || !re) return; if (re.t === 'IFCPROPERTYSINGLEVALUE') { var v = ra[2]; if (v && v.v) v = v.v[0]; grp.rows.push([ra[0], v == null ? '' : String(v).replace(/^\.(.*)\.$/, '$1')]); } });
        else if (pe.t === 'IFCELEMENTQUANTITY') (a[5] || []).forEach(function (r) { var ra = EA(r), re = E(r); if (!ra || !re) return; var v = ra[3]; var u = /LENGTH/.test(re.t) ? ' m' : /AREA/.test(re.t) ? ' m²' : /VOLUME/.test(re.t) ? ' m³' : /WEIGHT/.test(re.t) ? ' kg' : ''; var nv = typeof v === 'number' ? (/LENGTH/.test(re.t) ? v * scale : /AREA/.test(re.t) ? v * areaScale : /VOLUME/.test(re.t) ? v * volScale : v) : v; grp.rows.push([ra[0], (typeof nv === 'number' ? Math.round(nv * 1000) / 1000 : nv) + u]); });
        if (grp.rows.length) out.push(grp);
      });
      return out;
    }

    /* ----- éléments ----- */
    var els = [], positions = [], total = 0, skipped = 0, done = 0, ids = Object.keys(ent);
    for (var q = 0; q < ids.length; q++) {
      var id = +ids[q], e = ent[id];
      if (e.t === 'IFCOPENINGELEMENT' || e.t === 'IFCSITE' || e.t === 'IFCBUILDING' || e.t === 'IFCBUILDINGSTOREY' || /^IFCREL|^IFCPROPERTY|^IFCELEMENTQUANTITY/.test(e.t)) { if (e.t !== 'IFCOPENINGELEMENT') continue; }
      if (!/^IFC/.test(e.t) || e.t.length < 7 || /^(IFCSHAPE|IFCPRODUCTDEF|IFCLOCALPL|IFCLINEARPL|IFCAXIS|IFCCARTESIAN|IFCDIRECTION|IFCPOLY|IFCSTYLED|IFCSURFACE|IFCALIGNMENT|IFCREFERENT|IFCLINEARPOSITIONING|IFCGRID|IFCANNOTATION)/.test(e.t)) continue;
      var a = A(id); if (!a || a.length < 7 || !a[6] || a[6].r === undefined || !ent[a[6].r] || ent[a[6].r].t !== 'IFCPRODUCTDEFINITIONSHAPE') continue;
      var M = place(a[5]), reps = A(a[6].r)[2] || [], mesh = new Mesh(), colr = null, usedRep = false;
      for (var ri = 0; ri < reps.length; ri++) {
        var rr = EA(reps[ri]); if (!rr) continue; var rid = String(rr[1] || '').toUpperCase(), rtp = String(rr[2] || '').toUpperCase();
        if (rid === 'BODY' || BODY_TYPES[rtp]) { usedRep = true; solid(reps[ri], M, mesh); colr = colr || itemColor(reps[ri]); }
      }
      if (!usedRep || !mesh.v.length) { skipped++; continue; }
      var v = mesh.v, n = v.length;
      for (var z = 0; z < n; z += 3) { v[z] *= scale; v[z + 1] *= scale; v[z + 2] *= scale; }
      var fr = TYPE_FR[e.t] || e.t.replace(/^IFC/, '').toLowerCase().replace(/^./, function (c) { return c.toUpperCase(); });
      var el = { id: id, gid: a[0] || '', type: e.t, cat: fr, name: a[2] || fr + ' #' + id, desc: a[3] || '', storey: storeyOf[id] || '—', start: total, count: n / 3, color: colr || COLORS[fr] || DEF_COLOR, hidden0: e.t === 'IFCOPENINGELEMENT' || e.t === 'IFCSPACE' };
      var mn = [1e30, 1e30, 1e30], mx = [-1e30, -1e30, -1e30];
      for (z = 0; z < n; z += 3) { for (var k = 0; k < 3; k++) { var x = v[z + k]; if (x < mn[k]) mn[k] = x; if (x > mx[k]) mx[k] = x; } }
      el.min = mn; el.max = mx; el._v = v; els.push(el);
      if (++done % 400 === 0) { if (onProgress) onProgress('Géométrie… ' + done + ' éléments'); await tick(); }
    }
    /* découpe réelle des ouvertures (portes, fenêtres) dans les murs et dalles convexes */
    var cutN = 0; (function () {
      var byId = Object.create(null); els.forEach(function (x) { byId[x.id] = x; });
      Object.keys(voidsOf).forEach(function (hid) {
        var host = byId[hid]; if (!host || host.type === 'IFCOPENINGELEMENT') return;
        var ops = voidsOf[hid].map(function (i) { return byId[i]; }).filter(Boolean); if (!ops.length) return;
        var r = carve(host._v, ops.map(function (o) { return o._v; }));
        if (r) { host.volBrut = r.volBrut; host._v = r.v; host.carved = true; host.count = r.v.length / 3; host.nOpen = r.n; cutN++; }
      });
    })();
    warn.cut = cutN;
    els.forEach(function (el) { el.start = total; total += el._v.length / 3; for (var z = 0; z < el._v.length; z++) positions.push(el._v[z]); el._v = null; });
    var pos32 = new Float32Array(positions.length); for (var pi = 0; pi < positions.length; pi++) pos32[pi] = positions[pi];
    var gmin = [1e30, 1e30, 1e30], gmax = [-1e30, -1e30, -1e30];
    els.forEach(function (el) { if (el.hidden0) return; for (var k = 0; k < 3; k++) { if (el.min[k] < gmin[k]) gmin[k] = el.min[k]; if (el.max[k] > gmax[k]) gmax[k] = el.max[k]; } });
    if (gmin[0] > gmax[0]) { els.forEach(function (el) { for (var k = 0; k < 3; k++) { if (el.min[k] < gmin[k]) gmin[k] = el.min[k]; if (el.max[k] > gmax[k]) gmax[k] = el.max[k]; } }); }
    return { schema: schema, is43: is43, scale: scale, positions: pos32, vertexCount: total, els: els, storeys: storeys, min: gmin, max: gmax, props: props, voids: voidsOf, warn: warn, skipped: skipped, entities: ids.length, ms: Date.now() - t0 };
  }



  /* ================= découpe des ouvertures (booléen maillage − solide convexe) ================= */
  var EPS = 1e-4;
  function planesOf(v) { /* plans d'un solide convexe (normale sortante), ou null si non convexe */
    var n = v.length / 9, cx = 0, cy = 0, cz = 0, c = v.length / 3; for (var i = 0; i < v.length; i += 3) { cx += v[i]; cy += v[i + 1]; cz += v[i + 2]; } cx /= c; cy /= c; cz /= c;
    var P = [];
    for (var t = 0; t < n; t++) {
      var o = t * 9, ux = v[o + 3] - v[o], uy = v[o + 4] - v[o + 1], uz = v[o + 5] - v[o + 2], wx = v[o + 6] - v[o], wy = v[o + 7] - v[o + 1], wz = v[o + 8] - v[o + 2];
      var nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx, l = Math.hypot(nx, ny, nz); if (l < 1e-12) continue; nx /= l; ny /= l; nz /= l;
      var d = nx * v[o] + ny * v[o + 1] + nz * v[o + 2]; if (nx * cx + ny * cy + nz * cz - d > 0) { nx = -nx; ny = -ny; nz = -nz; d = -d; }
      var dup = false; for (var k = 0; k < P.length; k++) if (Math.abs(P[k].n[0] - nx) + Math.abs(P[k].n[1] - ny) + Math.abs(P[k].n[2] - nz) < 1e-6 && Math.abs(P[k].c - d) < 1e-5) { dup = true; break; } if (!dup) P.push({ n: [nx, ny, nz], c: d });
    }
    for (var q = 0; q < v.length; q += 3) for (var k2 = 0; k2 < P.length; k2++) if (P[k2].n[0] * v[q] + P[k2].n[1] * v[q + 1] + P[k2].n[2] * v[q + 2] - P[k2].c > 1e-4) return null;
    return P.length >= 4 && P.length <= 32 ? P : null;
  }
  function clipPoly(poly, pl, sign, shift) { /* garde les points où sign·(n·p − c) + shift ≥ 0 */
    var out = [], m = poly.length; if (!m) return out;
    var val = function (p) { return sign * (pl.n[0] * p[0] + pl.n[1] * p[1] + pl.n[2] * p[2] - pl.c) + shift; };
    for (var i = 0; i < m; i++) {
      var a = poly[i], b = poly[(i + 1) % m], va = val(a), vb = val(b);
      if (va >= 0) out.push(a);
      if ((va >= 0) !== (vb >= 0)) { var t = va / (va - vb); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]); }
    }
    return out;
  }
  function centroid(v) { var x = 0, y = 0, z = 0, c = v.length / 3; for (var i = 0; i < v.length; i += 3) { x += v[i]; y += v[i + 1]; z += v[i + 2]; } return [x / c, y / c, z / c]; }
  /* oriente un triangle : sg = +1 → normale vers ref ; sg = −1 → normale à l'opposé de ref (vers l'extérieur) */
  function orientTri(q, ref, sg) {
    var ux = q[1][0] - q[0][0], uy = q[1][1] - q[0][1], uz = q[1][2] - q[0][2], wx = q[2][0] - q[0][0], wy = q[2][1] - q[0][1], wz = q[2][2] - q[0][2];
    var nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx, mx = (q[0][0] + q[1][0] + q[2][0]) / 3 - ref[0], my = (q[0][1] + q[1][1] + q[2][1]) / 3 - ref[1], mz = (q[0][2] + q[1][2] + q[2][2]) / 3 - ref[2];
    var dd = nx * mx + ny * my + nz * mz; /* >0 : la normale s'éloigne de ref */
    return (sg > 0 ? dd > 0 : dd < 0) ? [q[0], q[2], q[1]] : q;
  }
  function orientAll(v, ref, sg) { var out = v.slice(); for (var o = 0; o + 8 < v.length; o += 9) { var q = orientTri([[v[o], v[o + 1], v[o + 2]], [v[o + 3], v[o + 4], v[o + 5]], [v[o + 6], v[o + 7], v[o + 8]]], ref, sg); for (var k = 0; k < 3; k++) { out[o + k * 3] = q[k][0]; out[o + k * 3 + 1] = q[k][1]; out[o + k * 3 + 2] = q[k][2]; } } return out; }
  function polyAreaOk(p) { var a = 0; for (var i = 1; i + 1 < p.length; i++) { var ux = p[i][0] - p[0][0], uy = p[i][1] - p[0][1], uz = p[i][2] - p[0][2], wx = p[i + 1][0] - p[0][0], wy = p[i + 1][1] - p[0][1], wz = p[i + 1][2] - p[0][2]; a += Math.hypot(uy * wz - uz * wy, uz * wx - ux * wz, ux * wy - uy * wx) / 2; } return a > 1e-8; }
  function meshVolume(v) { var V = 0; for (var o = 0; o + 8 < v.length; o += 9) V += (v[o] * (v[o + 4] * v[o + 8] - v[o + 5] * v[o + 7]) - v[o + 1] * (v[o + 3] * v[o + 8] - v[o + 5] * v[o + 6]) + v[o + 2] * (v[o + 3] * v[o + 7] - v[o + 4] * v[o + 6])) / 6; return Math.abs(V); }
  /* hôte : maillage triangulé d'un solide CONVEXE (mur droit, dalle…) ; ouvertures : solides convexes (boîtes).
     Renvoie null (hôte inchangé) si l'un d'eux n'est pas convexe. */
  function carve(hv, opens) {
    var HP = planesOf(hv); if (!HP) return null; var hc = centroid(hv), cur = orientAll(hv, hc, -1), volB = meshVolume(hv), nOk = 0;
    for (var oi = 0; oi < opens.length; oi++) {
      var ov = opens[oi], OP = planesOf(ov); if (!OP) continue; var oc = centroid(ov);
      var out = [];
      function emit(poly, ref, sg) { if (poly.length < 3 || !polyAreaOk(poly)) return; for (var i = 1; i + 1 < poly.length; i++) { var q = [poly[0], poly[i], poly[i + 1]]; if (ref) q = orientTri(q, ref, sg); for (var k = 0; k < 3; k++) out.push(q[k][0], q[k][1], q[k][2]); } }
      for (var t = 0; t + 8 < cur.length; t += 9) {
        var tri = [[cur[t], cur[t + 1], cur[t + 2]], [cur[t + 3], cur[t + 4], cur[t + 5]], [cur[t + 6], cur[t + 7], cur[t + 8]]];
        for (var i = 0; i < OP.length; i++) {
          var piece = clipPoly(tri, OP[i], 1, -EPS);                                   /* dehors du plan i … */
          for (var j = 0; j < i && piece.length; j++) piece = clipPoly(piece, OP[j], -1, EPS); /* … et dans les plans précédents */
          emit(piece);
        }
      }
      var hole = 0;
      for (var u = 0; u + 8 < ov.length; u += 9) { /* parois du trou : faces de l'ouvertures strictement dans l'hôte, retournées */
        var poly = [[ov[u], ov[u + 1], ov[u + 2]], [ov[u + 3], ov[u + 4], ov[u + 5]], [ov[u + 6], ov[u + 7], ov[u + 8]]];
        for (var h = 0; h < HP.length && poly.length; h++) poly = clipPoly(poly, HP[h], -1, -EPS);
        if (poly.length >= 3) { emit(poly, oc, 1); hole++; }
      }
      if (hole) { cur = out; nOk++; }
    }
    return nOk ? { v: cur, volBrut: volB, n: nOk } : null;
  }

  /* ================= quantités ================= */
  var QNAME = { vol: /^(net ?volume|volume)$/i, volB: /^gross ?volume$/i, aire: /^(net ?side ?area|net ?area|net ?surface ?area|area)$/i, aireB: /^gross ?(side ?|surface )?area$/i, plan: /^(net ?floor ?area|gross ?floor ?area|net ?footprint ?area|gross ?footprint ?area)$/i, lg: /^length$/i };
  var LINEAR = { Murs: 1, Poutres: 1, Poteaux: 1 };
  function num(v) { var n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : null; }
  /* Quantités par élément : valeurs déclarées dans l'IFC (Qto) en priorité, sinon calculées sur la géométrie.
     Le volume net déduit les ouvertures reliées à l'élément (IfcRelVoidsElement). */
  function quantities(model) {
    var P = model.positions, byId = Object.create(null); model.els.forEach(function (x) { byId[x.id] = x; });
    function geo(x) {
      var V = 0, A = 0, up = 0;
      for (var t = 0; t + 2 < x.count; t += 3) {
        var o = (x.start + t) * 3, ax = P[o], ay = P[o + 1], az = P[o + 2], bx = P[o + 3], by = P[o + 4], bz = P[o + 5], cx = P[o + 6], cy = P[o + 7], cz = P[o + 8];
        V += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6;
        var ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az, nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        A += Math.hypot(nx, ny, nz) / 2; up += Math.abs(nz) / 4;
      }
      return { vol: Math.abs(V), aire: A, plan: up };
    }
    var rows = [];
    /* Garde-fou d'unités n°1 : fichier IFC dont l'unité de longueur est déclarée « mètre » alors que les coordonnées sont en millimètres
       (l'élément médian ferait plus de 100 m). Les volumes sortiraient en mm³ : on convertit en m et on le signale dans « Source ». */
    var dims = []; model.els.forEach(function (x) { if (x.type !== 'IFCOPENINGELEMENT') dims.push(Math.max(x.max[0] - x.min[0], x.max[1] - x.min[1], x.max[2] - x.min[2])); });
    dims.sort(function (p, q) { return p - q; });
    var mmFix = model.scale === 1 && !model.noUnitGuard && !model.is43 && dims.length > 0 && dims[dims.length >> 1] > 100, kl = mmFix ? 1e-3 : 1, ka = kl * kl, kv = ka * kl;
    /* Garde-fou d'unités n°2 : une quantité déclarée (Qto) qui diffère de la géométrie d'un facteur 10^2, 10^3, 10^4, 10^6 ou 10^9 est dans une autre unité (mm, cm…) : on la ramène en m. */
    function fixU(dv, gv, pows) {
      if (dv == null || !(dv > 0) || !(gv > 0)) return { v: dv, fixed: false };
      var e = Math.log10(dv / gv);
      for (var i = 0; i < pows.length; i++) { var pw = pows[i]; if (Math.abs(e - pw) < 0.2) return { v: dv / Math.pow(10, pw), fixed: true }; if (Math.abs(e + pw) < 0.2) return { v: dv * Math.pow(10, pw), fixed: true }; }
      return { v: dv, fixed: false };
    }
    model.els.forEach(function (x) {
      if (x.type === 'IFCOPENINGELEMENT') return;
      var g0 = geo(x), g = { vol: g0.vol * kv, aire: g0.aire * ka, plan: g0.plan * ka }, D = [(x.max[0] - x.min[0]) * kl, (x.max[1] - x.min[1]) * kl, (x.max[2] - x.min[2]) * kl], decl = {}, src = 'géométrie', corr = mmFix;
      model.props(x.id).forEach(function (grp) { if (!/^(Qto_|BaseQuantities)/i.test(grp.name) && !/quantit/i.test(grp.name)) return; grp.rows.forEach(function (r) { for (var k in QNAME) if (QNAME[k].test(r[0])) { var n = num(r[1]); if (n != null && decl[k] == null) decl[k] = n; } }); });
      var ops = (model.voids[x.id] || []).map(function (i) { return byId[i]; }).filter(Boolean), ov = 0, oa = 0;
      ops.forEach(function (o) { var go = geo(o); ov += go.vol * kv; });
      var fv = fixU(decl.vol, g.vol, [3, 6, 9]), fa = fixU(decl.aire, g.aire, [4, 6]), fp = fixU(decl.plan, g.plan, [4, 6]), fl = fixU(decl.lg, Math.max(D[0], D[1]), [2, 3]);
      if (fv.fixed || fa.fixed || fp.fixed || fl.fixed) { corr = true; decl.vol = fv.v; decl.aire = fa.v; decl.plan = fp.v; decl.lg = fl.v; }
      var vol = g.vol, brut = x.carved ? x.volBrut * kv : g.vol;
      if (decl.vol != null) { vol = decl.vol; src = 'déclaré dans l\'IFC'; } else if (ov > 0 && !x.carved) vol = Math.max(0, g.vol - Math.min(ov, g.vol));
      var aire = decl.aire != null ? decl.aire : g.aire, plan = decl.plan != null ? decl.plan : g.plan;
      var lg = decl.lg != null ? decl.lg : (x.cat === 'Poteaux' ? D[2] : Math.max(D[0], D[1]));
      rows.push({ id: x.id, gid: x.gid, name: x.name, cat: x.cat, storey: x.storey, vol: vol, volBrut: brut, ouvertures: ops.length, volOuvert: ov, aire: aire, plan: plan, lg: LINEAR[x.cat] ? lg : null, src: src + (corr ? ' — unité corrigée (mm → m)' : '') });
    });
    return rows;
  }
  function synthese(rows) {
    var by = Object.create(null);
    rows.forEach(function (r) { var k = r.cat + '\u0001' + r.storey, o = by[k] || (by[k] = { cat: r.cat, storey: r.storey, n: 0, vol: 0, aire: 0, plan: 0, lg: 0, ouv: 0 }); o.n++; o.vol += r.vol; o.aire += r.aire; o.plan += r.plan; o.lg += r.lg || 0; o.ouv += r.ouvertures; });
    return Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) { return a.storey < b.storey ? -1 : a.storey > b.storey ? 1 : a.cat < b.cat ? -1 : 1; });
  }
  function csv(rows, sep) {
    sep = sep || ';'; var f = function (n) { return n == null ? '' : String(Math.round(n * 1000) / 1000).replace('.', ','); }, q = function (t) { return '"' + String(t == null ? '' : t).replace(/"/g, '""') + '"'; };
    return '\ufeff' + ['Niveau', 'Catégorie', 'Élément', 'Identifiant', 'Volume net (m³)', 'Volume brut (m³)', 'Ouvertures', 'Surface totale (m²)', 'Surface en plan (m²)', 'Longueur (m)', 'Source'].join(sep) + '\r\n' +
      sortRows(rows).map(function (r) { return [q(r.storey), q(r.cat), q(r.name), q(r.gid), f(r.vol), f(r.volBrut), r.ouvertures, f(r.aire), f(r.plan), f(r.lg), q(r.src)].join(sep); }).join('\r\n');
  }

  /* ---- export Excel (.xlsx) : vrai classeur, sans bibliothèque (zip « stocké » + XML) ----
     Colonnes dimensionnées, nombres réels formatés (3 décimales pour les volumes), en-tête figé + filtres, ligne de totaux (SOUS.TOTAL : suit les filtres), feuille « Synthèse ». */
  var CRC = (function () { var t = [], c, n, k; for (n = 0; n < 256; n++) { c = n; for (k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { var c = 0xFFFFFFFF; for (var i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zipStore(files) {
    var enc = new TextEncoder(), parts = [], cen = [], off = 0;
    function u16(v) { return [v & 255, (v >> 8) & 255]; } function u32(v) { return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]; }
    files.forEach(function (f) {
      var nm = enc.encode(f[0]), data = typeof f[1] === 'string' ? enc.encode(f[1]) : f[1], crc = crc32(data);
      var lh = [].concat(u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(0), u16(0x21), u32(crc), u32(data.length), u32(data.length), u16(nm.length), u16(0));
      parts.push(new Uint8Array(lh), nm, data);
      cen.push([].concat(u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0x21), u32(crc), u32(data.length), u32(data.length), u16(nm.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(off)), Array.prototype.slice.call(nm));
      off += lh.length + nm.length + data.length;
    });
    var cd = [].concat.apply([], cen);
    parts.push(new Uint8Array(cd), new Uint8Array([].concat(u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(cd.length), u32(off), u16(0))));
    var len = 0; parts.forEach(function (p) { len += p.length; }); var out = new Uint8Array(len), o = 0; parts.forEach(function (p) { out.set(p, o); o += p.length; }); return out;
  }
  function sortRows(rows) { return rows.slice().sort(function (a, b) { return String(a.storey).localeCompare(String(b.storey), 'fr', { numeric: true }) || String(a.cat).localeCompare(String(b.cat), 'fr') || String(a.name).localeCompare(String(b.name), 'fr', { numeric: true }); }); }
  function xlsx(rows) {
    var X = function (t) { return String(t == null ? '' : t).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/[&<>"]/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); };
    var L = function (i) { return String.fromCharCode(65 + i); }, r3 = function (n) { return Math.round(n * 1000) / 1000; };
    function sheet(head, widths, body, tot, fmts, nData) {
      var n = nData + 1, h = '<row r="1" ht="32" customHeight="1">' + head.map(function (t, i) { return '<c r="' + L(i) + '1" s="1" t="inlineStr"><is><t>' + X(t) + '</t></is></c>'; }).join('') + '</row>';
      var rowsX = body.map(function (r, ri) { return '<row r="' + (ri + 2) + '">' + r.map(function (v, ci) { if (v == null || v === '') return ''; var ref = L(ci) + (ri + 2); return typeof v === 'number' ? '<c r="' + ref + '" s="' + fmts[ci] + '"><v>' + v + '</v></c>' : '<c r="' + ref + '" t="inlineStr"><is><t>' + X(v) + '</t></is></c>'; }).join('') + '</row>'; }).join('');
      var t = '<row r="' + (n + 1) + '">' + tot.map(function (c, ci) { var ref = L(ci) + (n + 1); if (c == null) return ''; if (c.t != null) return '<c r="' + ref + '" s="5" t="inlineStr"><is><t>' + X(c.t) + '</t></is></c>'; return '<c r="' + ref + '" s="' + (c.s || 6) + '"><f>' + c.f + '</f><v>' + c.v + '</v></c>'; }).join('') + '</row>';
      return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:' + L(head.length - 1) + (n + 1) + '"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>' + widths.map(function (w, i) { return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>'; }).join('') + '</cols><sheetData>' + h + rowsX + t + '</sheetData><autoFilter ref="A1:' + L(head.length - 1) + n + '"/><pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/><pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>';
    }
    rows = sortRows(rows); var N = rows.length, sum = function (k) { return r3(rows.reduce(function (a, r) { return a + (r[k] || 0); }, 0)); };
    /* styles : 1 en-tête · 2 volume 0,000 · 3 surface/longueur 0,00 · 4 entier · 5 total (libellé) · 6 total (nombre) */
    var s1 = sheet(['Niveau', 'Catégorie', 'Élément', 'Identifiant', 'Volume net (m³)', 'Volume brut (m³)', 'Ouvertures', 'Surface totale (m²)', 'Surface en plan (m²)', 'Longueur (m)', 'Source'],
      [20, 22, 30, 26, 16, 16, 12, 18, 18, 14, 34],
      rows.map(function (r) { return [r.storey, r.cat, r.name, r.gid, r3(r.vol), r3(r.volBrut), r.ouvertures, r3(r.aire), r3(r.plan), r.lg == null ? null : r3(r.lg), r.src]; }),
      [{ t: 'TOTAL (lignes filtrées)' }, null, null, null, { f: 'SUBTOTAL(109,E2:E' + (N + 1) + ')', v: sum('vol') }, { f: 'SUBTOTAL(109,F2:F' + (N + 1) + ')', v: sum('volBrut') }, { s: 7, f: 'SUBTOTAL(109,G2:G' + (N + 1) + ')', v: sum('ouvertures') }, { s: 8, f: 'SUBTOTAL(109,H2:H' + (N + 1) + ')', v: sum('aire') }, { s: 8, f: 'SUBTOTAL(109,I2:I' + (N + 1) + ')', v: sum('plan') }, null, null],
      [0, 0, 0, 0, 2, 2, 4, 3, 3, 3, 0], N);
    var S = synthese(rows), M = S.length, tt = function (k) { return r3(S.reduce(function (a, r) { return a + (r[k] || 0); }, 0)); };
    var s2 = sheet(['Niveau', 'Catégorie', 'Nombre', 'Volume net (m³)', 'Surface totale (m²)', 'Surface en plan (m²)', 'Longueur (m)', 'Ouvertures'], [22, 24, 10, 16, 18, 18, 14, 12],
      S.map(function (r) { return [r.storey, r.cat, r.n, r3(r.vol), r3(r.aire), r3(r.plan), r3(r.lg), r.ouv]; }),
      [{ t: 'TOTAL' }, null, { s: 7, f: 'SUBTOTAL(109,C2:C' + (M + 1) + ')', v: tt('n') }, { f: 'SUBTOTAL(109,D2:D' + (M + 1) + ')', v: tt('vol') }, { s: 8, f: 'SUBTOTAL(109,E2:E' + (M + 1) + ')', v: tt('aire') }, { s: 8, f: 'SUBTOTAL(109,F2:F' + (M + 1) + ')', v: tt('plan') }, null, { s: 7, f: 'SUBTOTAL(109,H2:H' + (M + 1) + ')', v: tt('ouv') }],
      [0, 0, 4, 2, 3, 3, 3, 4], M);
    var styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.000"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF173565"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEAF0FA"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top style="thin"><color rgb="FF173565"/></top><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="9"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="164" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="3" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/><xf numFmtId="4" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    var W = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    return zipStore([
      ['[Content_Types].xml', W + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'],
      ['_rels/.rels', W + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
      ['xl/workbook.xml', W + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Quantités" sheetId="1" r:id="rId1"/><sheet name="Synthèse" sheetId="2" r:id="rId2"/></sheets><calcPr fullCalcOnLoad="1"/></workbook>'],
      ['xl/_rels/workbook.xml.rels', W + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
      ['xl/styles.xml', styles], ['xl/worksheets/sheet1.xml', s1], ['xl/worksheets/sheet2.xml', s2]
    ]);
  }

  /* ================= visionneuse WebGL ================= */
  var api = { parseObj: parseObj, parseMtl: parseMtl, objGuess: objGuess, ifcTextOf: ifcTextOf, parse: parse, parseArgs: parseArgs, earClip: earClip, quantities: quantities, synthese: synthese, csv: csv, xlsx: xlsx, sortRows: sortRows, version: 'V99' };
  if (typeof document === 'undefined') { if (typeof module !== 'undefined') module.exports = api; root.EXB_IFC3D = api; return; }

  var d = document, $ = function (id) { return d.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); };
  var VS = 'attribute vec3 p;attribute vec4 c;uniform mat4 vp;varying vec3 w;varying vec4 col;void main(){w=p;col=c;gl_Position=vp*vec4(p,1.0);}';
  var FS = 'precision mediump float;varying vec3 w;varying vec4 col;uniform vec4 ov;uniform float clipZ;uniform float useOv;void main(){if(w.z>clipZ)discard;vec3 n=normalize(cross(dFdx(w),dFdy(w)));float l=0.38+0.62*abs(dot(n,normalize(vec3(0.45,0.3,0.84))));vec3 b=useOv>0.5?ov.rgb:col.rgb;gl_FragColor=vec4(b*l,1.0);}';
  function m4persp(fov, asp, n, f) { var t = 1 / Math.tan(fov / 2); return [t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, 2 * f * n / (n - f), 0]; }
  function m4look(e, c, u) { var z = norm3([e[0] - c[0], e[1] - c[1], e[2] - c[2]]), x = norm3(cross(u, z)), y = cross(z, x); return [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, e), -dot(y, e), -dot(z, e), 1]; }
  function m4mul(a, b) { var r = new Array(16); for (var i = 0; i < 4; i++) for (var j = 0; j < 4; j++) { var s = 0; for (var k = 0; k < 4; k++) s += a[k * 4 + j] * b[i * 4 + k]; r[i * 4 + j] = s; } return r; }

  function Viewer(canvas, model) {
    var self = this, gl = canvas.getContext('webgl', { antialias: true, preserveDrawingBuffer: true });
    if (!gl) throw new Error('WebGL indisponible sur cet appareil.');
    gl.getExtension('OES_standard_derivatives');
    var src = FS.replace('precision mediump float;', '#extension GL_OES_standard_derivatives : enable\nprecision mediump float;');
    function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, src)); gl.linkProgram(pr); gl.useProgram(pr);
    var aP = gl.getAttribLocation(pr, 'p'), aC = gl.getAttribLocation(pr, 'c'), uVP = gl.getUniformLocation(pr, 'vp'), uOv = gl.getUniformLocation(pr, 'ov'), uUse = gl.getUniformLocation(pr, 'useOv'), uClip = gl.getUniformLocation(pr, 'clipZ');
    var nv = model.vertexCount, col = new Uint8Array(nv * 4);
    model.els.forEach(function (el) { for (var i = 0; i < el.count; i++) { var o = (el.start + i) * 4; col[o] = el.color[0]; col[o + 1] = el.color[1]; col[o + 2] = el.color[2]; col[o + 3] = 255; } });
    var bp = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, bp); gl.bufferData(gl.ARRAY_BUFFER, model.positions, gl.STATIC_DRAW);
    var bc = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, bc); gl.bufferData(gl.ARRAY_BUFFER, col, gl.STATIC_DRAW);
    gl.enable(gl.DEPTH_TEST); gl.enableVertexAttribArray(aP); gl.enableVertexAttribArray(aC);
    var cen = [(model.min[0] + model.max[0]) / 2, (model.min[1] + model.max[1]) / 2, (model.min[2] + model.max[2]) / 2], rad = Math.max(0.5, Math.hypot(model.max[0] - model.min[0], model.max[1] - model.min[1], model.max[2] - model.min[2]) / 2);
    var cam = { az: -0.8, el: 0.55, dist: rad * 2.6, t: cen.slice() };
    var vis = {}, sel = -1, clip = 1e9, dirty = true, VP = I4();
    model.els.forEach(function (el, i) { vis[i] = !el.hidden0; });
    this.vis = vis; this.cam = cam; this.model = model; this.onPick = null;
    function eye() { var ce = Math.cos(cam.el); return [cam.t[0] + cam.dist * ce * Math.cos(cam.az), cam.t[1] + cam.dist * ce * Math.sin(cam.az), cam.t[2] + cam.dist * Math.sin(cam.el)]; }
    this.matrices = function () { var w = canvas.clientWidth || 1, h = canvas.clientHeight || 1; var P = m4persp(0.8, w / h, Math.max(0.01, cam.dist / 500), cam.dist * 8 + rad * 6), V = m4look(eye(), cam.t, [0, 0, 1]); VP = m4mul(P, V); return VP; };
    this.draw = function () {
      var dpr = Math.min(2, root.devicePixelRatio || 1), w = Math.round(canvas.clientWidth * dpr), h = Math.round(canvas.clientHeight * dpr);
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      gl.viewport(0, 0, w, h); gl.clearColor(0.93, 0.95, 0.98, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.uniformMatrix4fv(uVP, false, new Float32Array(this.matrices())); gl.uniform1f(uClip, clip); gl.uniform1f(uUse, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, bp); gl.vertexAttribPointer(aP, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, bc); gl.vertexAttribPointer(aC, 4, gl.UNSIGNED_BYTE, true, 0, 0);
      var a = -1, n = 0; /* regroupe les éléments visibles contigus */
      for (var i = 0; i <= model.els.length; i++) { var ok = i < model.els.length && vis[i]; if (ok) { if (a < 0) { a = model.els[i].start; n = 0; } n += model.els[i].count; } else if (a >= 0) { gl.drawArrays(gl.TRIANGLES, a, n); a = -1; } }
      if (sel >= 0 && vis[sel]) { var el = model.els[sel]; gl.uniform1f(uUse, 1); gl.uniform4f(uOv, 1, 0.55, 0.05, 1); gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(-1, -1); gl.drawArrays(gl.TRIANGLES, el.start, el.count); gl.disable(gl.POLYGON_OFFSET_FILL); }
      dirty = false;
    };
    this.invalidate = function () { dirty = true; };
    var raf = function () { if (self.dead) return; if (dirty) self.draw(); root.requestAnimationFrame(raf); }; raf();
    this.destroy = function () { self.dead = true; try { gl.getExtension('WEBGL_lose_context') && gl.getExtension('WEBGL_lose_context').loseContext(); } catch (e) { } };
    this.fit = function (els) { var mn = [1e30, 1e30, 1e30], mx = [-1e30, -1e30, -1e30]; (els || model.els).forEach(function (el) { for (var k = 0; k < 3; k++) { if (el.min[k] < mn[k]) mn[k] = el.min[k]; if (el.max[k] > mx[k]) mx[k] = el.max[k]; } }); if (mn[0] > mx[0]) return; cam.t = [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2]; cam.dist = Math.max(0.6, Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) * 1.25); dirty = true; };
    this.view = function (n) { var V = { top: [-Math.PI / 2, 1.5], front: [-Math.PI / 2, 0.02], right: [0, 0.02], back: [Math.PI / 2, 0.02], left: [Math.PI, 0.02], iso: [-0.8, 0.55] }[n]; if (V) { cam.az = V[0]; cam.el = V[1]; dirty = true; } };
    this.setClip = function (z) { clip = z; dirty = true; };
    this.select = function (i) { sel = i; dirty = true; if (this.onPick) this.onPick(i); };
    this.selected = function () { return sel; };
    this.vp = function () { return this.matrices(); };
    /* sélection par lancer de rayon (triangles des éléments visibles) */
    /* ----- V99zza : mesure de distances en 3D (2 points sur le modèle, accrochage aux sommets) ----- */
    this.meas = []; this.mp = null; this.mode = null; this.onMeasure = null;
    function proj(p) { var M = self.matrices(), c = mulv(M, [p[0], p[1], p[2], 1]); if (c[3] <= 0) return null; return [(c[0] / c[3] * 0.5 + 0.5) * canvas.clientWidth, (0.5 - c[1] / c[3] * 0.5) * canvas.clientHeight]; }
    this.pickPoint = function (px, py) {
      var w = canvas.clientWidth, h = canvas.clientHeight, nx = px / w * 2 - 1, ny = 1 - py / h * 2, M = this.matrices();
      var inv = inv4(M); if (!inv) return null;
      var p0 = mulv(inv, [nx, ny, -1, 1]), p1 = mulv(inv, [nx, ny, 1, 1]); p0 = [p0[0] / p0[3], p0[1] / p0[3], p0[2] / p0[3]]; p1 = [p1[0] / p1[3], p1[1] / p1[3], p1[2] / p1[3]];
      var D = norm3([p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]]), best = -1, bt = 1e30, bo = -1, pos = model.positions;
      for (var i = 0; i < model.els.length; i++) {
        if (!vis[i]) continue; var el = model.els[i]; if (!hitBox(p0, D, el.min, el.max, bt)) continue;
        for (var t = 0; t < el.count / 3; t++) { var o = el.start * 3 + t * 9, d0 = tri(p0, D, pos, o); if (d0 > 0 && d0 < bt) { var hz = p0[2] + D[2] * d0; if (hz <= clip) { bt = d0; best = i; bo = o; } } }
      }
      if (best < 0) return null;
      var P = [p0[0] + D[0] * bt, p0[1] + D[1] * bt, p0[2] + D[2] * bt], snap = false, bd = 18;
      for (var k = 0; k < 3; k++) { var V = [pos[bo + k * 3], pos[bo + k * 3 + 1], pos[bo + k * 3 + 2]], s = proj(V); if (!s) continue; var dd = Math.hypot(s[0] - px, s[1] - py); if (dd < bd) { bd = dd; P = V; snap = true; } }
      return { i: best, p: P, snap: snap };
    };
    this.setMeasure = function (on) { this.mode = on ? 'm' : null; this.mp = null; canvas.style.cursor = on ? 'crosshair' : ''; dirty = true; };
    this.addMeasPoint = function (p) { if (!this.mp) this.mp = p; else { this.meas.push({ a: this.mp, b: p }); this.mp = null; } dirty = true; if (this.onMeasure) this.onMeasure(); };
    this.undoMeas = function () { if (this.mp) this.mp = null; else this.meas.pop(); dirty = true; if (this.onMeasure) this.onMeasure(); };
    this.clearMeas = function () { this.meas = []; this.mp = null; dirty = true; if (this.onMeasure) this.onMeasure(); };
    var ov = d.createElement('canvas'); ov.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:2'; canvas.parentNode.appendChild(ov);
    function paintMeas() {
      var dp = root.devicePixelRatio || 1, w = canvas.clientWidth, h = canvas.clientHeight; if (ov.width !== Math.round(w * dp) || ov.height !== Math.round(h * dp)) { ov.width = Math.round(w * dp); ov.height = Math.round(h * dp); }
      var g = ov.getContext('2d'); g.setTransform(dp, 0, 0, dp, 0, 0); g.clearRect(0, 0, w, h); g.font = 'bold 13px Arial'; g.lineJoin = 'round';
      function dot(s, c) { g.beginPath(); g.arc(s[0], s[1], 5, 0, 6.2832); g.fillStyle = '#fff'; g.fill(); g.beginPath(); g.arc(s[0], s[1], 3.5, 0, 6.2832); g.fillStyle = c; g.fill(); }
      self.meas.forEach(function (m, n) {
        var a = proj(m.a), b = proj(m.b); if (!a || !b) return;
        g.strokeStyle = '#fff'; g.lineWidth = 5; g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); g.strokeStyle = '#f97316'; g.lineWidth = 2.4; g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); dot(a, '#f97316'); dot(b, '#f97316');
        var t = (n + 1) + ' : ' + self.measInfo(m).d3.toFixed(2).replace('.', ',') + ' m', x = (a[0] + b[0]) / 2 - g.measureText(t).width / 2, y = (a[1] + b[1]) / 2 - 8; g.lineWidth = 4; g.strokeStyle = '#fff'; g.strokeText(t, x, y); g.fillStyle = '#c2410c'; g.fillText(t, x, y);
      });
      if (self.mp) { var q = proj(self.mp); if (q) dot(q, '#16a34a'); }
    }
    this.measInfo = function (m) { var dx = m.b[0] - m.a[0], dy = m.b[1] - m.a[1], dz = m.b[2] - m.a[2]; return { d3: Math.hypot(dx, dy, dz), dh: Math.hypot(dx, dy), dv: Math.abs(dz) }; };
    this.pick = function (px, py) {
      var w = canvas.clientWidth, h = canvas.clientHeight, nx = px / w * 2 - 1, ny = 1 - py / h * 2, M = this.matrices();
      var inv = inv4(M); if (!inv) return -1;
      var p0 = mulv(inv, [nx, ny, -1, 1]), p1 = mulv(inv, [nx, ny, 1, 1]); p0 = [p0[0] / p0[3], p0[1] / p0[3], p0[2] / p0[3]]; p1 = [p1[0] / p1[3], p1[1] / p1[3], p1[2] / p1[3]];
      var D = norm3([p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]]), best = -1, bt = 1e30, pos = model.positions;
      for (var i = 0; i < model.els.length; i++) {
        if (!vis[i]) continue; var el = model.els[i]; if (!hitBox(p0, D, el.min, el.max, bt)) continue;
        for (var t = 0; t < el.count / 3; t++) { var o = el.start * 3 + t * 9; var d0 = tri(p0, D, pos, o); if (d0 > 0 && d0 < bt) { var hz = p0[2] + D[2] * d0; if (hz <= clip) { bt = d0; best = i; } } }
      }
      return best;
    };
    function hitBox(o, D, mn, mx, lim) { var t0 = 0, t1 = lim; for (var k = 0; k < 3; k++) { if (Math.abs(D[k]) < 1e-12) { if (o[k] < mn[k] || o[k] > mx[k]) return false; } else { var a = (mn[k] - o[k]) / D[k], b = (mx[k] - o[k]) / D[k]; if (a > b) { var s = a; a = b; b = s; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return false; } } return true; }
    function tri(o, D, P, i) { var e1x = P[i + 3] - P[i], e1y = P[i + 4] - P[i + 1], e1z = P[i + 5] - P[i + 2], e2x = P[i + 6] - P[i], e2y = P[i + 7] - P[i + 1], e2z = P[i + 8] - P[i + 2], px = D[1] * e2z - D[2] * e2y, py = D[2] * e2x - D[0] * e2z, pz = D[0] * e2y - D[1] * e2x, det = e1x * px + e1y * py + e1z * pz; if (Math.abs(det) < 1e-12) return -1; var f = 1 / det, sx = o[0] - P[i], sy = o[1] - P[i + 1], sz = o[2] - P[i + 2], u = f * (sx * px + sy * py + sz * pz); if (u < 0 || u > 1) return -1; var qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x, v = f * (D[0] * qx + D[1] * qy + D[2] * qz); if (v < 0 || u + v > 1) return -1; return f * (e2x * qx + e2y * qy + e2z * qz); }
    function mulv(m, v) { return [m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3], m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3], m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3], m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3]]; }
    function inv4(m) { var inv = new Array(16), det; inv[0] = m[5] * m[10] * m[15] - m[5] * m[11] * m[14] - m[9] * m[6] * m[15] + m[9] * m[7] * m[14] + m[13] * m[6] * m[11] - m[13] * m[7] * m[10]; inv[4] = -m[4] * m[10] * m[15] + m[4] * m[11] * m[14] + m[8] * m[6] * m[15] - m[8] * m[7] * m[14] - m[12] * m[6] * m[11] + m[12] * m[7] * m[10]; inv[8] = m[4] * m[9] * m[15] - m[4] * m[11] * m[13] - m[8] * m[5] * m[15] + m[8] * m[7] * m[13] + m[12] * m[5] * m[11] - m[12] * m[7] * m[9]; inv[12] = -m[4] * m[9] * m[14] + m[4] * m[10] * m[13] + m[8] * m[5] * m[14] - m[8] * m[6] * m[13] - m[12] * m[5] * m[10] + m[12] * m[6] * m[9]; inv[1] = -m[1] * m[10] * m[15] + m[1] * m[11] * m[14] + m[9] * m[2] * m[15] - m[9] * m[3] * m[14] - m[13] * m[2] * m[11] + m[13] * m[3] * m[10]; inv[5] = m[0] * m[10] * m[15] - m[0] * m[11] * m[14] - m[8] * m[2] * m[15] + m[8] * m[3] * m[14] + m[12] * m[2] * m[11] - m[12] * m[3] * m[10]; inv[9] = -m[0] * m[9] * m[15] + m[0] * m[11] * m[13] + m[8] * m[1] * m[15] - m[8] * m[3] * m[13] - m[12] * m[1] * m[11] + m[12] * m[3] * m[9]; inv[13] = m[0] * m[9] * m[14] - m[0] * m[10] * m[13] - m[8] * m[1] * m[14] + m[8] * m[2] * m[13] + m[12] * m[1] * m[10] - m[12] * m[2] * m[9]; inv[2] = m[1] * m[6] * m[15] - m[1] * m[7] * m[14] - m[5] * m[2] * m[15] + m[5] * m[3] * m[14] + m[13] * m[2] * m[7] - m[13] * m[3] * m[6]; inv[6] = -m[0] * m[6] * m[15] + m[0] * m[7] * m[14] + m[4] * m[2] * m[15] - m[4] * m[3] * m[14] - m[12] * m[2] * m[7] + m[12] * m[3] * m[6]; inv[10] = m[0] * m[5] * m[15] - m[0] * m[7] * m[13] - m[4] * m[1] * m[15] + m[4] * m[3] * m[13] + m[12] * m[1] * m[7] - m[12] * m[3] * m[5]; inv[14] = -m[0] * m[5] * m[14] + m[0] * m[6] * m[13] + m[4] * m[1] * m[14] - m[4] * m[2] * m[13] - m[12] * m[1] * m[6] + m[12] * m[2] * m[5]; inv[3] = -m[1] * m[6] * m[11] + m[1] * m[7] * m[10] + m[5] * m[2] * m[11] - m[5] * m[3] * m[10] - m[9] * m[2] * m[7] + m[9] * m[3] * m[6]; inv[7] = m[0] * m[6] * m[11] - m[0] * m[7] * m[10] - m[4] * m[2] * m[11] + m[4] * m[3] * m[10] + m[8] * m[2] * m[7] - m[8] * m[3] * m[6]; inv[11] = -m[0] * m[5] * m[11] + m[0] * m[7] * m[9] + m[4] * m[1] * m[11] - m[4] * m[3] * m[9] - m[8] * m[1] * m[7] + m[8] * m[3] * m[5]; inv[15] = m[0] * m[5] * m[10] - m[0] * m[6] * m[9] - m[4] * m[1] * m[10] + m[4] * m[2] * m[9] + m[8] * m[1] * m[6] - m[8] * m[2] * m[5]; det = m[0] * inv[0] + m[1] * inv[4] + m[2] * inv[8] + m[3] * inv[12]; if (!det) return null; det = 1 / det; for (var i = 0; i < 16; i++) inv[i] *= det; return inv; }

    /* souris / tactile */
    var drag = null, moved = 0, pts = {};
    canvas.style.touchAction = 'none';
    canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    canvas.addEventListener('pointerdown', function (e) { canvas.setPointerCapture(e.pointerId); pts[e.pointerId] = [e.clientX, e.clientY]; drag = { x: e.clientX, y: e.clientY, pan: e.button === 2 || e.shiftKey }; moved = 0; });
    canvas.addEventListener('pointermove', function (e) {
      if (!pts[e.pointerId]) return; var ids = Object.keys(pts);
      if (ids.length === 2) { var o = ids.filter(function (k) { return +k !== e.pointerId; })[0], p = pts[o], a = pts[e.pointerId]; var d0 = Math.hypot(a[0] - p[0], a[1] - p[1]); pts[e.pointerId] = [e.clientX, e.clientY]; var d1 = Math.hypot(e.clientX - p[0], e.clientY - p[1]); if (d0 > 0) { cam.dist = Math.max(0.3, Math.min(rad * 30, cam.dist * d0 / Math.max(1, d1))); dirty = true; } moved = 99; return; }
      pts[e.pointerId] = [e.clientX, e.clientY]; if (!drag) return;
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY; moved += Math.abs(dx) + Math.abs(dy);
      if (drag.pan) { var k = cam.dist * 0.0016, ca = Math.cos(cam.az), sa = Math.sin(cam.az); cam.t[0] += (sa * dx - ca * Math.sin(cam.el) * -dy * -1) * k * 0 + (sa * dx + ca * Math.sin(cam.el) * dy) * k; cam.t[1] += (-ca * dx + sa * Math.sin(cam.el) * dy) * k; cam.t[2] += Math.cos(cam.el) * dy * k; }
      else { cam.az -= dx * 0.008; cam.el = Math.max(-1.55, Math.min(1.55, cam.el + dy * 0.008)); }
      dirty = true;
    });
    function up(e) { var was = pts[e.pointerId]; delete pts[e.pointerId]; if (Object.keys(pts).length === 0 && drag) { if (moved < 5 && e.type === 'pointerup') { var r = canvas.getBoundingClientRect(); if (self.mode === 'm') { var q = self.pickPoint(e.clientX - r.left, e.clientY - r.top); if (q) self.addMeasPoint(q.p); } else self.select(self.pick(e.clientX - r.left, e.clientY - r.top)); } drag = null; } }
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('wheel', function (e) { e.preventDefault(); cam.dist = Math.max(0.3, Math.min(rad * 30, cam.dist * (e.deltaY > 0 ? 1.12 : 0.89))); dirty = true; }, { passive: false });
    var _draw = this.draw; this.draw = function () { _draw.apply(this, arguments); paintMeas(); };
    this.toPNG = function () { this.draw(); return canvas.toDataURL('image/png'); };
  }

  /* ----- interface ----- */
  var CSS = '#exbIfcUI{position:fixed;inset:0;z-index:99997;background:#0f172a;display:flex;flex-direction:column;font:14px system-ui,sans-serif;color:#172033}#exbIfcUI .tb{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:8px;background:#173565;color:#fff}#exbIfcUI .tb b{margin-right:auto;font-size:15px}#exbIfcUI button{border:0;border-radius:8px;padding:7px 10px;background:#eaf1fb;color:#173565;font-weight:600;cursor:pointer;font-size:13px}#exbIfcUI button.x{background:#fde8e8;color:#b91c1c}#exbIfcUI .mn{flex:1;display:flex;min-height:0}#exbIfcUI .cv{flex:1;position:relative;min-width:0}#exbIfcUI canvas{width:100%;height:100%;display:block}#exbIfcUI .sd{width:330px;background:#fff;overflow:auto;padding:10px;border-left:1px solid #dbe3ee}#exbIfcUI .sd h4{margin:10px 0 4px;color:#173565}#exbIfcUI .sd table{width:100%;border-collapse:collapse;font-size:13px}#exbIfcUI .sd td{padding:3px 4px;border-bottom:1px solid #eef2f7;vertical-align:top;word-break:break-word}#exbIfcUI .it{padding:3px 6px;cursor:pointer;border-radius:6px;font-size:13px}#exbIfcUI .it:hover,#exbIfcUI .it.on{background:#fff1dc}#exbIfcUI .ms{position:absolute;left:10px;bottom:10px;background:#fffc;border-radius:8px;padding:6px 10px;font-size:12px;max-width:70%}#exbIfcUI input[type=text]{width:100%;box-sizing:border-box;padding:7px;border:1px solid #cbd5e1;border-radius:8px}@media(max-width:760px){#exbIfcUI .mn{flex-direction:column}#exbIfcUI .sd{width:auto;height:42%;border-left:0;border-top:1px solid #dbe3ee}}';
  var UI = null;
  function close() { if (UI) { UI.v && UI.v.destroy(); UI.el.remove(); UI = null; } }
  async function openText(text, title, pre) {
    close();
    if (!$('exbIfcCSS')) { var s = d.createElement('style'); s.id = 'exbIfcCSS'; s.textContent = CSS; d.head.appendChild(s); }
    var el = d.createElement('div'); el.id = 'exbIfcUI';
    el.innerHTML = '<div class="tb"><b>🧊 ' + esc(title || 'Maquette IFC') + '</b><button id="ifFit">Ajuster</button><button id="ifIso">3D</button><button id="ifTop">Dessus</button><button id="ifFr">Face</button><button id="ifRi">Côté</button><button id="ifIs">Isoler</button><button id="ifHi">Masquer</button><button id="ifAll">Tout afficher</button><button id="ifMes">📏 Mesurer</button><button id="ifQty">📐 Quantités</button><button id="ifPng">📷 Image</button><button class="x" id="ifX">✕ Fermer</button></div><div class="mn"><div class="cv"><canvas id="ifCv"></canvas><div class="ms" id="ifMs">Chargement…</div></div><div class="sd" id="ifSd"></div></div>';
    d.body.appendChild(el); UI = { el: el, v: null }; $('ifX').onclick = close;
    var ms = $('ifMs'), sd = $('ifSd');
    var model; try { model = pre || await parse(text, function (m) { ms.textContent = m; }); } catch (e) { ms.textContent = '⚠ ' + e.message; return; }
    if (!model.els.length) { ms.innerHTML = '⚠ Aucune géométrie lisible dans ce fichier (' + model.entities + ' entités).'; sd.innerHTML = warnHtml(model); return; }
    var v; try { v = new Viewer($('ifCv'), model); } catch (e) { ms.textContent = '⚠ ' + e.message; return; }
    UI.v = v; v.fit(model.els.filter(function (x) { return !x.hidden0; })); v.view('iso');
    ms.innerHTML = model.els.length + ' éléments · ' + Math.round(model.vertexCount / 3).toLocaleString('fr-FR') + ' triangles · ' + (model.ms / 1000).toFixed(1) + ' s' + (model.schema ? ' · ' + model.schema : '') + (model.skipped ? ' · ' + model.skipped + ' sans géométrie lisible' : '');
    var cats = {}; model.els.forEach(function (x, i) { (cats[x.cat] || (cats[x.cat] = [])).push(i); });
    /* mesures 3D : panneau latéral, envoi au métré */
    function fm(n) { return n.toFixed(2).replace('.', ','); }
    function measHtml() {
      var m = v.meas, h = '<h4>📏 Mesures 3D</h4>';
      if (v.mode === 'm') h += '<p style="color:#b45309;font-size:13px">Touchez le point de départ, puis le point d’arrivée (accrochage aux sommets). Glisser = tourner.</p>'; else if (!m.length) h += '<p style="color:#64748b;font-size:13px">Activez « Mesurer » puis touchez deux points du modèle.</p>';
      if (m.length) { var T = 0; h += '<table>' + m.map(function (x, n) { var k = v.measInfo(x); T += k.d3; return '<tr><td>' + (n + 1) + '</td><td><b>' + fm(k.d3) + ' m</b><br><small>horiz. ' + fm(k.dh) + ' · vert. ' + fm(k.dv) + '</small></td></tr>'; }).join('') + '<tr><td></td><td><b>Total ' + fm(T) + ' m</b></td></tr></table>'; }
      if (m.length || v.mp) h += '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px"><button id="ifMU">\u21A9 Retirer</button><button id="ifMC">🗑 Tout effacer</button>' + (m.length && root.EXBMetre && root.EXBMetre.addLignes ? '<button id="ifMM" style="background:#15803d;color:#fff">\u2795 Envoyer au métré</button>' : '') + '</div><small style="color:#64748b">Mesures indicatives (distance en ligne droite entre deux points du modèle).</small>';
      return h;
    }
    function updMeas() {
      var e = $('ifMeas'); if (!e) return; e.innerHTML = measHtml();
      var u = $('ifMU'), c = $('ifMC'), mm = $('ifMM'); if (u) u.onclick = function () { v.undoMeas(); }; if (c) c.onclick = function () { v.clearMeas(); };
      if (mm) mm.onclick = function () { var L = v.meas.map(function (x, n) { return { d: 'Mesure 3D ' + (n + 1) + ' (' + (title || 'maquette') + ')', u: 'ml', q: Math.round(v.measInfo(x).d3 * 100) / 100, src: 'ifcmes:' + (title || 'maquette') + ':' + n + ':' + x.a.map(function (t) { return Math.round(t * 100); }).join(',') }; }); var k = root.EXBMetre.addLignes(L); exbAlert(k ? k + ' ligne(s) envoyée(s) dans le métré (Matériaux ajoutés). Saisissez les prix unitaires.' : 'Aucune ligne envoyée.'); };
    }
    $('ifMes').onclick = function () { v.setMeasure(v.mode !== 'm'); this.style.background = v.mode === 'm' ? '#f97316' : ''; updMeas(); };
    v.onMeasure = updMeas;
    var cut = '';
    function render() {
      var i = v.selected(), h = '<input type="text" id="ifQ" placeholder="Rechercher (nom, type, identifiant)…">';
      h += '<div id="ifSel">' + selHtml(i) + '</div><div id="ifMeas"></div>';
      if (model.storeys.length) { var mx = model.max[2], mn = model.min[2]; h += '<h4>Coupe horizontale</h4><input type="range" id="ifCut" min="' + mn.toFixed(2) + '" max="' + (mx + 0.1).toFixed(2) + '" step="0.05" value="' + (mx + 0.1).toFixed(2) + '" style="width:100%"><div style="font-size:12px;color:#64748b" id="ifCutV">Aucune coupe</div>'; }
      h += '<h4>Catégories</h4>' + Object.keys(cats).sort().map(function (c) { var on = cats[c].some(function (k) { return v.vis[k]; }); return '<label style="display:flex;align-items:center;gap:6px;padding:2px 0"><input type="checkbox" class="ifCat" style="width:auto;height:auto;margin:0" data-c="' + esc(c) + '"' + (on ? ' checked' : '') + '> ' + esc(c) + ' <span style="color:#64748b;margin-left:auto">' + cats[c].length + '</span></label>'; }).join('');
      h += '<h4>Niveaux</h4><div id="ifTree"></div>' + warnHtml(model);
      sd.innerHTML = h;
      $('ifQ').oninput = tree; tree(); updMeas();
      var c = $('ifCut'); if (c) c.oninput = function () { var z = +c.value; if (z >= model.max[2] + 0.05) { v.setClip(1e9); $('ifCutV').textContent = 'Aucune coupe'; } else { v.setClip(z); $('ifCutV').textContent = 'Coupe à ' + z.toFixed(2) + ' m'; } };
      [].forEach.call(sd.querySelectorAll('.ifCat'), function (b) { b.onchange = function () { cats[b.dataset.c].forEach(function (k) { v.vis[k] = b.checked; }); v.invalidate(); }; });
    }
    function selHtml(i) {
      if (i < 0) return '<p style="color:#64748b">Cliquez sur un élément pour voir ses propriétés.</p>';
      var x = model.els[i], D = [x.max[0] - x.min[0], x.max[1] - x.min[1], x.max[2] - x.min[2]];
      var h = '<h4>' + esc(x.name) + '</h4><table><tr><td>Catégorie</td><td>' + esc(x.cat) + ' <small>(' + esc(x.type) + ')</small></td></tr><tr><td>Niveau</td><td>' + esc(x.storey) + '</td></tr><tr><td>Identifiant</td><td>' + esc(x.gid) + '</td></tr><tr><td>Encombrement</td><td>' + D.map(function (n) { return n.toFixed(2); }).join(' × ') + ' m</td></tr><tr><td>Altitude</td><td>' + x.min[2].toFixed(2) + ' → ' + x.max[2].toFixed(2) + ' m</td></tr></table>';
      model.props(x.id).forEach(function (g) { h += '<h4>' + esc(g.name) + '</h4><table>' + g.rows.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td></tr>'; }).join('') + '</table>'; });
      return h;
    }
    function tree() {
      var q = (($('ifQ') || {}).value || '').toLowerCase(), by = {}, shown = 0;
      model.els.forEach(function (x, i) { if (q && (x.name + ' ' + x.cat + ' ' + x.type + ' ' + x.gid).toLowerCase().indexOf(q) < 0) return; (by[x.storey] || (by[x.storey] = [])).push(i); shown++; });
      var order = model.storeys.map(function (s) { return s.name; }).concat(['—']), h = '';
      order.forEach(function (n) { var L = by[n]; if (!L) return; h += '<details' + (q || order.length < 4 ? ' open' : '') + '><summary><b>' + esc(n === '—' ? 'Sans niveau' : n) + '</b> <small>(' + L.length + ')</small></summary>' + L.slice(0, 400).map(function (i) { return '<div class="it' + (i === v.selected() ? ' on' : '') + '" data-i="' + i + '">' + esc(model.els[i].name) + ' <small style="color:#64748b">' + esc(model.els[i].cat) + '</small></div>'; }).join('') + (L.length > 400 ? '<small>… ' + (L.length - 400) + ' autres (affinez la recherche)</small>' : '') + '</details>'; });
      $('ifTree').innerHTML = h || '<small>Aucun résultat.</small>';
      [].forEach.call($('ifTree').querySelectorAll('.it'), function (n) { n.onclick = function () { v.select(+n.dataset.i); v.fit([model.els[+n.dataset.i]]); v.cam.dist *= 2.2; }; });
    }
    v.onPick = function (i) { $('ifSel').innerHTML = selHtml(i); [].forEach.call(sd.querySelectorAll('.it'), function (n) { n.classList.toggle('on', +n.dataset.i === i); }); };
    $('ifFit').onclick = function () { v.fit(model.els.filter(function (x, k) { return v.vis[k]; })); };
    $('ifIso').onclick = function () { v.view('iso'); }; $('ifTop').onclick = function () { v.view('top'); }; $('ifFr').onclick = function () { v.view('front'); }; $('ifRi').onclick = function () { v.view('right'); };
    $('ifIs').onclick = function () { var i = v.selected(); if (i < 0) return; model.els.forEach(function (x, k) { v.vis[k] = k === i; }); v.invalidate(); syncCats(); };
    $('ifHi').onclick = function () { var i = v.selected(); if (i < 0) return; v.vis[i] = false; v.select(-1); syncCats(); };
    $('ifAll').onclick = function () { model.els.forEach(function (x, k) { v.vis[k] = !x.hidden0; }); v.invalidate(); syncCats(); };
    function syncCats() { [].forEach.call(sd.querySelectorAll('.ifCat'), function (b) { b.checked = cats[b.dataset.c].some(function (k) { return v.vis[k]; }); }); }
    $('ifPng').onclick = function () { var a = d.createElement('a'); a.href = v.toPNG(); a.download = (title || 'maquette').replace(/[^\w.-]+/g, '_') + '.png'; a.click(); };
    $('ifQty').onclick = function () {
      var rows = quantities(model), S = synthese(rows), f = function (n, k) { return n ? n.toLocaleString('fr-FR', { maximumFractionDigits: k == null ? 2 : k }) : '—'; };
      var o = d.createElement('div'); o.id = 'exbIfcQ'; o.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.72);display:flex;align-items:center;justify-content:center;padding:12px;font:14px system-ui,sans-serif';
      var UN = { 'm³': ['vol', 'Volume net'], 'm² (totale)': ['aire', 'Surface totale'], 'm² (en plan)': ['plan', 'Surface en plan'], 'ml': ['lg', 'Longueur'], 'u': ['n', 'Nombre'] };
      var DEF = { Murs: 'm³', Dalles: 'm³', Poteaux: 'm³', Poutres: 'm³', Portes: 'u', 'Fenêtres': 'u', Toitures: 'm² (en plan)', Escaliers: 'm³' };
      var h = '<div style="background:#fff;color:#172033;border-radius:12px;max-width:980px;width:100%;max-height:92vh;display:flex;flex-direction:column"><div style="padding:12px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #e2e8f0"><b style="flex:1">📐 Quantités — ' + esc(title || 'maquette') + '</b><button id="qMet" style="padding:7px 12px;border:0;border-radius:8px;background:#15803d;color:#fff;font-weight:600;cursor:pointer">➕ Envoyer au métré</button><button id="qXlsx" style="padding:7px 12px;border:0;border-radius:8px;background:#0f4aa8;color:#fff;font-weight:600;cursor:pointer">Exporter Excel (.xlsx)</button><button id="qCsv" style="padding:7px 12px;border:1px solid #0f4aa8;border-radius:8px;background:#fff;color:#0f4aa8;font-weight:600;cursor:pointer">CSV</button><button id="qX" style="padding:7px 12px;border:0;border-radius:8px;background:#eef2f7;cursor:pointer">Fermer</button></div><div style="overflow:auto;padding:0 16px 12px">';
      h += '<p style="font-size:12px;color:#64748b">Valeurs déclarées dans l’IFC si elles existent, sinon calculées sur la géométrie (volume net : ouvertures reliées déduites). À contrôler avant tout chiffrage. Cochez les lignes à envoyer dans « Matériaux ajoutés » du métré et choisissez l’unité ; le prix unitaire se saisit ensuite dans le métré. Renvoyer les mêmes lignes les met à jour sans doublon.</p>';
      h += '<table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr style="text-align:left;background:#f1f5fb"><th style="padding:6px"></th><th>Niveau</th><th>Catégorie</th><th style="text-align:right">Nb</th><th style="text-align:right">Volume net m³</th><th style="text-align:right">Surf. totale m²</th><th style="text-align:right">Surf. en plan m²</th><th style="text-align:right">Long. m</th><th>Envoyer en</th></tr></thead><tbody>';
      S.forEach(function (r, i) { h += '<tr style="border-top:1px solid #e2e8f0"><td style="padding:5px 6px"><input type="checkbox" class="qk" data-i="' + i + '" checked></td><td>' + esc(r.storey === '—' ? 'Sans niveau' : r.storey) + '</td><td>' + esc(r.cat) + '</td><td style="text-align:right">' + r.n + '</td><td style="text-align:right">' + f(r.vol) + '</td><td style="text-align:right">' + f(r.aire, 1) + '</td><td style="text-align:right">' + f(r.plan, 1) + '</td><td style="text-align:right">' + f(r.lg, 1) + '</td><td><select class="qu" data-i="' + i + '">' + Object.keys(UN).map(function (u) { return '<option' + (u === (DEF[r.cat] || 'm³') ? ' selected' : '') + '>' + u + '</option>'; }).join('') + '</select></td></tr>'; });
      h += '</tbody></table></div></div>'; o.innerHTML = h; d.body.appendChild(o);
      o.querySelector('#qMet').onclick = function () {
        var M = root.EXBMetre; if (!M || !M.addLignes) { exbAlert('Le module Métré n’est pas disponible dans cette page.'); return; }
        var lines = []; [].forEach.call(o.querySelectorAll('.qk'), function (k) {
          if (!k.checked) return; var i = +k.dataset.i, r = S[i], u = o.querySelector('.qu[data-i="' + i + '"]').value, key = UN[u][0], q = key === 'n' ? r.n : r[key];
          var unit = u.replace(/ \(.*\)/, ''); lines.push({ d: r.cat + (r.storey && r.storey !== '—' ? ' — ' + r.storey : '') + ' (' + UN[u][1].toLowerCase() + ', maquette IFC)', u: unit, q: q, src: 'ifc:' + (title || '') + ':' + r.cat + ':' + r.storey + ':' + key });
        });
        var n = M.addLignes(lines); if (!n) { exbAlert('Aucune ligne envoyée (quantités nulles ou aucune case cochée).'); return; }
        o.remove(); close(); try { notify(n + ' ligne(s) envoyée(s) dans le métré (Matériaux ajoutés). Saisissez les prix unitaires.', 'success', 7000); } catch (e) { }
      };
      o.querySelector('#qX').onclick = function () { o.remove(); };
      o.querySelector('#qXlsx').onclick = function () { var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([xlsx(rows)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })); a.download = 'quantites-' + (title || 'maquette').replace(/[^\w.-]+/g, '_') + '.xlsx'; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000); };
      o.querySelector('#qCsv').onclick = function () { var a = d.createElement('a'); a.href = URL.createObjectURL(new Blob([csv(rows)], { type: 'text/csv;charset=utf-8' })); a.download = 'quantites-' + (title || 'maquette').replace(/[^\w.-]+/g, '_') + '.csv'; a.click(); };
    };
    render(); root.EXB_IFC3D_VIEWER = v;
  }
  function warnHtml(model) {
    var k = Object.keys(model.warn.unsupported); var h = '';
    if (k.length || model.warn.bool > (model.warn.cut || 0)) h = '<h4>Limites de cette lecture</h4><p style="font-size:12px;color:#64748b;margin:0">' + (model.warn.bool > (model.warn.cut || 0) ? 'Découpes complexes non réalisées (éléments courbes ou non convexes) : ' + (model.warn.bool - (model.warn.cut || 0)) + ' élément(s) apparaissent pleins.<br>' : '') + (k.length ? 'Géométries non prises en charge : ' + k.map(function (t) { return esc(t.replace(/^IFC/, '')) + ' ×' + model.warn.unsupported[t]; }).join(', ') + '.' : '') + '</p>';
    return h;
  }
  /* texte IFC d'un fichier : .ifc tel quel, ou .ifczip / .zip (le premier .ifc de l'archive, le plus volumineux s'il y en a plusieurs) */
  function ifcTextOf(buf, name) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (!/\.(ifczip|zip)$/i.test(name || '') && !(u8[0] === 0x50 && u8[1] === 0x4b)) return Promise.resolve(new TextDecoder('utf-8').decode(u8));
    if (!root.EXB_ZIP) return Promise.reject(new Error('Module de décompression absent (exb-zip.js).'));
    return root.EXB_ZIP.unzip(u8).then(function (files) {
      var c = files.filter(function (f) { return /\.ifc$/i.test(f.name); }).sort(function (a, b) { return b.data.length - a.data.length; })[0];
      if (!c) throw new Error('Aucun fichier .ifc dans cette archive.');
      return new TextDecoder('utf-8').decode(c.data);
    });
  }
  /* ouverture d'un ou plusieurs fichiers : .ifc / .ifczip, ou .obj (+ .mtl), ou .zip contenant un .obj (export Excellencia, SketchUp, Blender…) */
  async function openFiles(files) {
    files = Array.prototype.slice.call(files || []); if (!files.length) return;
    var big = files.some(function (f) { return f.size > 120 * 1048576; }); if (big) { exbAlert('Fichier trop volumineux (120 Mo maximum).'); return; }
    var objF = files.filter(function (f) { return /\.obj$/i.test(f.name); })[0], mtlFs = files.filter(function (f) { return /\.mtl$/i.test(f.name); }), zipF = files.filter(function (f) { return /\.(zip)$/i.test(f.name); })[0], objText = null, mtlText = '', title = '';
    try {
      if (!objF && zipF) { /* le .zip contient-il un .obj ? */
        var u8 = new Uint8Array(await zipF.arrayBuffer()); if (!root.EXB_ZIP) throw new Error('Module de décompression absent (exb-zip.js).');
        var fl = await root.EXB_ZIP.unzip(u8), o = fl.filter(function (f) { return /\.obj$/i.test(f.name); }).sort(function (a, b) { return b.data.length - a.data.length; })[0];
        if (o) { objText = new TextDecoder('utf-8').decode(o.data); title = o.name.replace(/^.*\//, ''); mtlText = fl.filter(function (f) { return /\.mtl$/i.test(f.name); }).map(function (f) { return new TextDecoder('utf-8').decode(f.data); }).join('\n'); }
        else { var ifc = fl.filter(function (f) { return /\.ifc$/i.test(f.name); }).sort(function (a, b) { return b.data.length - a.data.length; })[0]; if (!ifc) throw new Error('Aucun fichier .ifc ou .obj dans cette archive.'); return openText(new TextDecoder('utf-8').decode(ifc.data), ifc.name.replace(/^.*\//, '')); }
      }
      if (objF) { objText = await objF.text(); title = objF.name; for (var i = 0; i < mtlFs.length; i++) mtlText += '\n' + await mtlFs[i].text(); }
      if (objText != null) {
        var g = objGuess(objText), ans = root.prompt('Fichier OBJ : ' + g.vertices.toLocaleString('fr-FR') + ' sommets, étendue ' + g.span.toFixed(1) + '.\nIndiquez l’unité des coordonnées (m, cm, mm, ft, in) et l’axe vertical (Y ou Z).\nExemple : « mm Z ». Valeur proposée :', g.unit + ' ' + g.up);
        if (ans === null) return; var w = String(ans).trim().split(/\s+/), un = (w[0] || g.unit).toLowerCase(), upx = (w[1] || g.up).toUpperCase();
        if (!OBJ_UNITS[un]) { exbAlert('Unité non reconnue : « ' + w[0] + ' ». Utilisez m, cm, mm, ft ou in.'); return; }
        var model = await parseObj(objText, { unit: un, up: upx, mtl: parseMtl(mtlText) });
        return openText('', title, model);
      }
      var f0 = files[0]; var t = await ifcTextOf(await f0.arrayBuffer(), f0.name); return openText(t, f0.name.replace(/\.(ifczip|zip)$/i, '.ifc'));
    } catch (e) { exbAlert('Lecture impossible : ' + (e && e.message || e)); }
  }
  function pick() {
    var i = d.createElement('input'); i.type = 'file'; i.multiple = true; i.accept = '.ifc,.ifczip,.zip,.obj,.mtl,text/plain';
    i.onchange = function () { openFiles(i.files); };
    i.click();
  }
  api.openFiles = openFiles; api.openText = openText; api.ifcTextOf = ifcTextOf; api.pick = pick; api.close = close; api.Viewer = Viewer;
  root.EXB_IFC3D = api;
})(typeof window !== 'undefined' ? window : globalThis);
