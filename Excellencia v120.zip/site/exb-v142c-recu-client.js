/* Excellencia Building V142c — Reçu de paiement client (disposition du modèle « Reçu de paiement Excellencia Building » + QR de vérification).
 * EXBRecuClient.make(data) -> Promise<Blob PDF> ; une seule page A4, sans page de garde.
 * data = { recu_no, date (AAAA-MM-JJ), agence, devise ('USD'|'FC'), client, matricule, tel, adresse,
 *          projet, contrat, motif ('acompte'|'avancement'|'solde'|'autre'), motifAutre, montant,
 *          mode ('mobile_money'|'banque'|'caisse'|'autre'), reference, total, dejaPaye, solde, caisse }
 * total / dejaPaye / solde : nombres ou null (champ laissé vide à remplir à la main).
 * Le QR ouvre verification.html (même registre que les autres documents) ; le reçu y est publié avec le type « Reçu ». */
(function (w) {
  'use strict';
  var NAVY = [0.090, 0.208, 0.396], BLUE = [0.125, 0.286, 0.541], BAND = [0.918, 0.941, 0.984], GOLD = [0.769, 0.604, 0.220], GREY = [0.40, 0.43, 0.49], INK = [0.10, 0.12, 0.18], LINE = [0.78, 0.82, 0.88], SOFT = [0.95, 0.97, 0.99];
  var TEL = '+243 810 644 554', MAIL = 'excellenciabuilding@gmail.com';

  /* ---------- montant en toutes lettres (français) ---------- */
  var U = ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
  var TENS = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante'];
  function below100(n, final) {
    if (n < 20) return U[n];
    var d = Math.floor(n / 10), u = n % 10;
    if (d <= 6) return TENS[d] + (u === 0 ? '' : (u === 1 ? ' et un' : '-' + U[u]));
    if (d === 7) return 'soixante' + (u === 1 ? ' et onze' : '-' + U[10 + u]);
    if (d === 8) return 'quatre-vingt' + (u === 0 ? (final ? 's' : '') : '-' + U[u]);
    return 'quatre-vingt-' + U[10 + u];
  }
  function below1000(n, final) {
    var c = Math.floor(n / 100), r = n % 100, s = '';
    if (c > 0) { s = (c === 1 ? 'cent' : U[c] + ' cent') + (r === 0 && c > 1 && final ? 's' : ''); }
    if (r > 0) s += (s ? ' ' : '') + below100(r, final);
    return s;
  }
  function intWords(n) {
    if (n === 0) return 'zéro';
    var parts = [], b = Math.floor(n / 1e9), m = Math.floor((n % 1e9) / 1e6), k = Math.floor((n % 1e6) / 1e3), r = n % 1000;
    if (b) parts.push((b === 1 ? 'un' : below1000(b)) + (b > 1 ? ' milliards' : ' milliard'));
    if (m) parts.push((m === 1 ? 'un' : below1000(m)) + (m > 1 ? ' millions' : ' million'));
    if (k) parts.push(k === 1 ? 'mille' : below1000(k, false) + ' mille');
    if (r) parts.push(below1000(r, true));
    return parts.join(' ');
  }
  function words(amount, devise) {
    var v = Math.round((Number(amount) || 0) * 100), ent = Math.floor(v / 100), cts = v % 100;
    var de = (ent > 0 && ent % 1000000 === 0) ? 'de ' : '';
    var unit = devise === 'FC' ? (ent > 1 ? 'francs congolais' : 'franc congolais') : (ent > 1 ? 'dollars américains' : 'dollar américain');
    var s = intWords(ent) + ' ' + de + unit;
    if (cts) s += ' et ' + intWords(cts) + (devise === 'FC' ? (cts > 1 ? ' centimes' : ' centime') : (cts > 1 ? ' cents' : ' cent'));
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  /* ---------- utilitaires ---------- */
  var OK = { 8217: 1, 8216: 1, 8220: 1, 8221: 1, 8211: 1, 8212: 1, 8364: 1, 339: 1, 338: 1, 8230: 1, 8226: 1 };
  function san(t) { t = String(t == null ? '' : t).replace(/[\r\n\t]+/g, ' ').replace(/\u202f|\u00a0/g, ' '); var o = ''; for (var i = 0; i < t.length; i++) { var c = t.charCodeAt(i); o += (c < 256 || OK[c]) ? t.charAt(i) : '?'; } return o; }
  function nf(v) { v = Number(v) || 0; var s = Math.abs(v).toFixed(2).split('.'); s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (v < 0 ? '-' : '') + s.join(','); }
  function fd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function dataUrlBytes(u) { var b = atob(String(u).split(',')[1] || ''), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function loadLib() {
    if (w.PDFLib) return Promise.resolve(w.PDFLib);
    return new Promise(function (ok, ko) { var s = document.createElement('script'); s.src = 'pdflib/pdf-lib.min.js'; s.onload = function () { w.PDFLib ? ok(w.PDFLib) : ko(new Error('pdf-lib')); }; s.onerror = function () { ko(new Error('pdf-lib introuvable')); }; document.head.appendChild(s); });
  }
  async function imgBytes(src) {
    try {
      if (!src) return null;
      if (/^data:image\/(png|jpe?g)/i.test(src)) return { b: dataUrlBytes(src), png: /^data:image\/png/i.test(src) };
      var r = await fetch(src); if (!r.ok) return null; var ab = new Uint8Array(await r.arrayBuffer()); return { b: ab, png: ab[0] === 0x89 };
    } catch (e) { return null; }
  }

  /* ---------- construction du PDF (testable hors navigateur : lib, QR et images fournis) ---------- */
  async function build(lib, d, env) {
    env = env || {};
    var pdf = await lib.PDFDocument.create(), pg = pdf.addPage([595, 842]), W = 595, H = 842, M = 40;
    var F1 = await pdf.embedFont(lib.StandardFonts.Helvetica), F2 = await pdf.embedFont(lib.StandardFonts.HelveticaBold), F3 = await pdf.embedFont(lib.StandardFonts.HelveticaOblique); var F4 = await pdf.embedFont(lib.StandardFonts.TimesRomanBoldItalic);
    var rgb = function (a) { return lib.rgb(a[0], a[1], a[2]); };
    function T(t, x, y, sz, o) { o = o || {}; var f = o.i ? F3 : (o.b ? F2 : F1); t = san(t); if (o.al) { var wd = f.widthOfTextAtSize(t, sz); x = o.al === 'r' ? x - wd : x - wd / 2; } pg.drawText(t, { x: x, y: y, size: sz, font: f, color: rgb(o.c || INK) }); }
    function TW(t, sz, b) { return (b ? F2 : F1).widthOfTextAtSize(san(t), sz); }
    function R(x, y, w2, h, c) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, color: rgb(c) }); }
    function RS(x, y, w2, h, c, lw) { pg.drawRectangle({ x: x, y: y, width: w2, height: h, borderColor: rgb(c), borderWidth: lw || .8 }); }
    function L(x1, y1, x2, y2, c, lw) { pg.drawLine({ start: { x: x1, y: y1 }, end: { x: x2, y: y2 }, thickness: lw || .6, color: rgb(c || LINE) }); }
    function fit(t, maxW, sz, b) { t = san(t); while (sz > 6 && TW(t, sz, b) > maxW) sz -= .25; if (TW(t, sz, b) > maxW) { while (t.length > 3 && TW(t + '…', sz, b) > maxW) t = t.slice(0, -1); t += '…'; } return { t: t, sz: sz }; }
    /* champ : étiquette + valeur sur une ligne de pointillé/trait ; retourne la fin de l'étiquette */
    function field(label, val, x, y, wTot, o) {
      o = o || {}; T(label, x, y, 8.4, { b: true, c: NAVY }); var lx = x + TW(label, 8.4, true) + 6;
      L(lx, y - 2.5, x + wTot, y - 2.5, LINE, .6);
      if (val !== '' && val != null) { var f = fit(val, x + wTot - lx - 4, o.sz || 9.6, true); T(f.t, lx + 2, y, f.sz, { b: true }); }
    }
    function box(x, y, on, label) { RS(x, y - 1, 8.5, 8.5, NAVY, .9); if (on) { R(x + 1.8, y + .8, 4.9, 4.9, NAVY); } T(label, x + 12.5, y, 8.6, { b: on }); return x + 12.5 + TW(label, 8.6, on) + 14; }
    function section(n, title, y) { R(M, y - 3, W - 2 * M, 16, NAVY); R(M, y - 3, 4, 16, GOLD); T(n + '. ' + title, M + 12, y + 1.2, 9.4, { b: true, c: [1, 1, 1] }); }

    /* ----- en-tête : même entête que le modèle « Dossier de chantier » (fond blanc, logo, nom, devise dorée, coordonnées à droite, filet doré) ----- */
    var I = env.id || {}, nom = d.entreprise || I.name || 'Excellencia Building';
    var logo = null; try { if (env.logo) logo = env.logo.png ? await pdf.embedPng(env.logo.b) : await pdf.embedJpg(env.logo.b); } catch (e) { logo = null; }
    var tx = M;
    if (logo) { var lh = 62, lw2 = lh * logo.width / logo.height; if (lw2 > 80) { lw2 = 80; lh = lw2 * logo.height / logo.width; } pg.drawImage(logo, { x: M, y: H - 26 - lh, width: lw2, height: lh }); tx = M + lw2 + 14; }
    /* coordonnées (colonne de droite, alignées à droite, grises) */
    var place = [I.address || 'Kinshasa, RDC', I.country].filter(function (v, i, a) { return v && !(i === 1 && String(a[0]).toLowerCase().indexOf(String(v).toLowerCase()) >= 0); }).join(', ');
    var items = [place, 'Tél : ' + (I.phone || TEL), 'E-mail : ' + (I.email || MAIL), I.website || ''].filter(Boolean), CW = 215, clines = [], cc = '';
    items.forEach(function (it) { var t5 = cc ? cc + '  ·  ' + it : it; if (cc && TW(t5, 7.6) > CW) { clines.push(cc); cc = it; } else cc = t5; }); if (cc) clines.push(cc);
    clines.slice(0, 4).forEach(function (l6, i) { var f6 = fit(l6, CW, 7.6); T(f6.t, W - M, H - 34 - i * 10.5, f6.sz, { al: 'r', c: GREY }); });
    var nmax = W - M - CW - 14 - tx, nf1 = fit(nom, nmax, 20, true);
    T(nf1.t, tx, H - 46, nf1.sz, { b: true, c: NAVY });
    var sl = fit('L’excellence au cœur de vos constructions', nmax, 9.5); T(sl.t, tx, H - 62, sl.sz, { i: true, c: [0.62, 0.47, 0.13] });
    var ar = fit('ARCHITECTURE  •  INGÉNIERIE  •  RÉALISATION', nmax, 7.8, true); T(ar.t, tx, H - 76, ar.sz, { b: true, c: GREY });
    L(M, H - 98, W - M, H - 98, GOLD, 2.2);
    /* bandeau du titre : fond clair + barre bleue (comme le reçu d'inscription), entre le filet doré de l'en-tête et un filet bleu */
    R(M, H - 142, W - 2 * M, 38, BAND); R(M, H - 142, 5, 38, BLUE);
    T('REÇU DE PAIEMENT', M + 18, H - 123, 17, { b: true, c: BLUE });
    var sub = fit(d.projet || '', W - 2 * M - 200, 9.5); if (sub.t) T(sub.t, M + 18, H - 136, sub.sz, { c: INK });
    T('Document client  •  À conserver', W - M - 8, H - 136, 8, { al: 'r', c: GREY });
    L(M, H - 147, W - M, H - 147, NAVY, 3);

    var y = H - 168;
    field('N° DU REÇU', d.recu_no, M, y, 300, { sz: 10.5 }); field('DATE', fd(d.date), M + 318, y, W - 2 * M - 318);
    y -= 22;
    field('AGENCE / SITE', d.agence || '', M, y, 300);
    var xd = M + 318; T('DEVISE', xd, y, 8.4, { b: true, c: NAVY }); xd += TW('DEVISE', 8.4, true) + 8;
    var dv = d.devise === 'FC' ? 'FC' : (d.devise === 'USD' ? 'USD' : 'autre');
    xd = box(xd, y, dv === 'FC', 'FC'); xd = box(xd, y, dv === 'USD', 'USD'); box(xd, y, dv === 'autre', 'Autre');

    /* ----- 1. client ----- */
    y -= 28; section(1, 'INFORMATIONS DU CLIENT', y); y -= 24;
    field('Nom et prénom / Raison sociale', d.client || '', M, y, W - 2 * M); y -= 20;
    field('Matricule client', d.matricule || '', M, y, 250); field('Téléphone', d.tel || '', M + 268, y, W - 2 * M - 268); y -= 20;
    field('Adresse / E-mail', d.adresse || '', M, y, W - 2 * M);

    /* ----- 2. objet ----- */
    y -= 28; section(2, 'OBJET DU PAIEMENT', y); y -= 24;
    field('Projet / Chantier', d.projet || '', M, y, W - 2 * M); y -= 20;
    field('Référence contrat / facture', d.contrat || '', M, y, W - 2 * M); y -= 22;
    T('Motif du paiement', M, y, 8.4, { b: true, c: NAVY }); var mx = M + TW('Motif du paiement', 8.4, true) + 12, mt = d.motif || '';
    mx = box(mx, y, mt === 'acompte', 'Acompte'); mx = box(mx, y, mt === 'avancement', 'Avancement'); mx = box(mx, y, mt === 'solde', 'Solde'); mx = box(mx, y, mt === 'autre', 'Autre :');
    if (mt === 'autre' && d.motifAutre) { var fo = fit(d.motifAutre, W - M - mx - 4, 9, true); T(fo.t, mx, y, fo.sz, { b: true }); L(mx - 2, y - 2.5, W - M, y - 2.5, LINE); } else L(mx - 2, y - 2.5, W - M, y - 2.5, LINE);
    /* montant reçu (cadre) */
    y -= 16; var bh = 40; R(M, y - bh, W - 2 * M, bh, SOFT); RS(M, y - bh, W - 2 * M, bh, GOLD, 1.2); R(M, y - bh, 5, bh, GOLD);
    T('MONTANT REÇU', M + 16, y - 15, 8.6, { b: true, c: NAVY });
    var ms = nf(d.montant) + '  ' + (dv === 'autre' ? '' : dv), mf = fit(ms, 250, 20, true); T(mf.t, M + 16, y - 34, mf.sz, { b: true, c: NAVY });
    var wd = words(d.montant, d.devise), wl = [], wc = '';
    wd.split(' ').forEach(function (x) { var t4 = wc ? wc + ' ' + x : x; if (TW(t4, 9, true) > 240 && wc) { wl.push(wc); wc = x; } else wc = t4; }); if (wc) wl.push(wc);
    T('Montant en toutes lettres :', M + 290, y - 12, 7.8, { c: GREY });
    wl.slice(0, 3).forEach(function (l5, i) { var f5 = fit(l5, 240, 9, true); T(f5.t, M + 290, y - 24 - i * 10.5, f5.sz, { b: true }); });
    y -= bh;

    /* ----- 3. mode et situation ----- */
    y -= 26; section(3, 'MODE DE PAIEMENT ET SITUATION', y); y -= 24;
    T('Mode de paiement', M, y, 8.4, { b: true, c: NAVY }); var px = M + TW('Mode de paiement', 8.4, true) + 12, md = d.mode || '';
    px = box(px, y, md === 'caisse', 'Espèces'); px = box(px, y, md === 'banque', 'Virement'); px = box(px, y, md === 'mobile_money', 'Mobile Money'); px = box(px, y, md === 'cheque', 'Chèque'); box(px, y, md === 'autre', 'Autre');
    y -= 20; field('Référence de transaction', [d.reference, d.trans_no].filter(Boolean).join('  /  '), M, y, W - 2 * M);
    var cur = dv === 'autre' ? '' : dv;
    function amt(v) { return (v == null || v === '') ? '' : nf(v) + ' ' + cur; }
    y -= 20; field('Montant total convenu', amt(d.total), M, y, 300); y -= 20; field('Total payé avant ce reçu', amt(d.dejaPaye), M, y, 300); y -= 20; field('Solde après paiement', amt(d.solde), M, y, 300);

    /* ----- 4. confirmation ----- */
    y -= 28; section(4, 'CONFIRMATION', y); y -= 22;
    var conf = 'Nous reconnaissons avoir reçu du client désigné ci-dessus le montant indiqué sur le présent reçu, au titre du paiement précisé. Ce reçu confirme uniquement l’encaissement du montant mentionné.';
    var words2 = conf.split(' '), ln = '', wmax = W - 2 * M;
    words2.forEach(function (x) { var t2 = ln ? ln + ' ' + x : x; if (TW(t2, 8.8) > wmax) { T(ln, M, y, 8.8); y -= 12; ln = x; } else ln = t2; }); if (ln) { T(ln, M, y, 8.8); y -= 12; }

    /* ----- signature du Directeur Général + sceau, en bas à gauche (comme le reçu d'inscription) ----- */
    y -= 6; var cx = M + 285;
    var dg = san(d.dg || d.caisse || (env.id && env.id.dg) || '');
    if (dg) { var dsz = 15; while (F4.widthOfTextAtSize(dg, dsz) > 215 && dsz > 9) dsz -= .5; pg.drawText(dg, { x: M, y: y - 8, size: dsz, font: F4, color: rgb(BLUE) }); }
    T((env.id && env.id.dgRole) || 'Directeur Général', M, y - 22, 9, { b: true });
    try { if (env.visa) { var vi = env.visa.png ? await pdf.embedPng(env.visa.b) : await pdf.embedJpg(env.visa.b), vh = 52, vw = vh * vi.width / vi.height; if (vw > 150) { vw = 150; vh = vw * vi.height / vi.width; } pg.drawImage(vi, { x: cx - vw / 2, y: y - 62, width: vw, height: vh }); } } catch (e) { }
    T('Signature / Sceau autorisé', cx, y - 72, 8.4, { al: 'c', c: GREY });

    /* ----- QR de vérification (à gauche, texte à sa droite) + mention « Important » ----- */
    var qy = y - 76 - 70;
    if (env.qrMatrix) {
      var m = env.qrMatrix, n = m.length, q = 2, t = n + 2 * q, qs = 66, s = qs / t, qx = M;
      R(qx, qy, qs, qs, [1, 1, 1]); RS(qx, qy, qs, qs, LINE, .6);
      for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (m[r][c]) pg.drawRectangle({ x: qx + (c + q) * s, y: qy + qs - (r + q + 1) * s, width: s + .15, height: s + .15, color: lib.rgb(0, 0, 0) });
      T('Scannez pour vérifier', qx + qs + 10, qy + 40, 8.4, { b: true, c: NAVY });
      T('l’authenticité du reçu', qx + qs + 10, qy + 29, 8.4, { b: true, c: NAVY });
      if (env.qrCode) T('Code ' + String(env.qrCode).toUpperCase(), qx + qs + 10, qy + 17, 7.6, { c: GREY });
    }
    var imp = 'Important : ce reçu doit être conservé par le client. Il ne remplace pas une facture lorsque celle-ci est requise. Toute correction doit être validée et authentifiée par Excellencia Building.';
    var ix = M + 215, il = [], l2 = ''; imp.split(' ').forEach(function (x) { var t3 = l2 ? l2 + ' ' + x : x; if (TW(t3, 7.8) > W - M - ix) { il.push(l2); l2 = x; } else l2 = t3; }); if (l2) il.push(l2);
    var iy = qy + 54; il.forEach(function (s2, i) { T(s2, ix, iy - i * 10.5, 7.8, { c: GREY }); });

    /* ----- pied de page ----- */
    R(0, 0, W, 42, NAVY); R(0, 42, W, 3, GOLD);
    T('EXCELLENCIA BUILDING  •  Architecture  •  Ingénierie  •  Réalisation', W / 2, 26, 8.6, { b: true, c: [1, 1, 1], al: 'c' });
    T('WhatsApp : ' + TEL + '  |  E-mail : ' + MAIL, W / 2, 12, 8.2, { c: [0.95, 0.82, 0.40], al: 'c' });
    pdf.setTitle('Reçu de paiement ' + (d.recu_no || '')); pdf.setAuthor('Excellencia Building');
    return pdf.save();
  }

  /* ---------- point d'entrée navigateur ---------- */
  async function make(d) {
    var lib = await loadLib(), ID = null; try { ID = w.EXBId ? w.EXBId.get() : null; } catch (e) { }
    var env = {}; env.id = ID;
    env.logo = await imgBytes((ID && ID.logo) || 'icon-192.png') || await imgBytes('icon-192.png');
    try { if (w.EXBSign && w.EXBSign.anyVisa) { var vu = await w.EXBSign.anyVisa('png'); if (vu) env.visa = await imgBytes(vu); } } catch (e) { }
    try {
      if (w.EXBVerif && w.EXBVerif.code && w.EXBQR) {
        var date = d.date || new Date().toISOString().slice(0, 10), key = [d.client || '', d.projet || '', d.reference || '', d.trans_no || ''].join('|');
        var c1 = w.EXBVerif.code('r', d.recu_no, date, Number(d.montant) || 0, d.devise || '', key, d.client || '');
        env.qrMatrix = w.EXBQR.matrix(c1.url); env.qrCode = c1.hash;
        w.EXBVerif.publish({ no: d.recu_no, kind: 'recu', hash: c1.hash, date: date, total: Number(d.montant) || 0, cur: d.devise || '', status: 'valide', nom: d.client || '', matricule: d.matricule || '', libelle: 'Reçu de paiement — ' + (d.projet || d.contrat || ''), detail: '' });
      }
    } catch (e) { env.qrMatrix = null; }
    d.entreprise = d.entreprise || (ID && ID.name) || ''; d.dg = d.dg || (ID && ID.dg) || '';
    var bytes = await build(lib, d, env);
    return new Blob([bytes], { type: 'application/pdf' });
  }
  w.EXBRecuClient = { make: make, words: words, build: build };
  if (typeof module !== 'undefined' && module.exports) module.exports = { words: words, build: build };
})(typeof window !== 'undefined' ? window : globalThis);
