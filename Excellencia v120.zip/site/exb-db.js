/* Excellencia Building V56 — Base de données partagée (fiche par fiche, multi-utilisateurs).
 * Nécessite : connexion au compte en ligne (exbSb) + supabase/schema-entreprise.sql exécuté une fois. */
(function(){'use strict';
var MK='EXB_DB_META',COLS={exb_decomptes:'decomptes',exb_clients:'clients',exb_projects:'projets',exb_quotes:'devis',exb_stock:'stock',exb_stock_moves:'mouvements',exb_hr:'personnel',exb_cash:'caisse',exb_studies:'etudes',exb_communication:'communication',exb_documents:'documents',exb_metre:'metres',exb_invoices:'factures',exb_finance:'finance',exb_phases:'phases',exb_cartouches:'cartouches',exb_suppliers:'fournisseurs',exb_purchase_orders:'commandes',exb_site_journal:'journal',exb_timesheets:'pointages',exb_situations:'situations',exb_calc_notes:'notes_calcul',exb_plans:'plans',exb_be_missions:'missions_be',exb_be_time:'heures_be',exb_gantt:'planning_chantier',exb_budgets:'budgets_chantier',exb_crm:'crm',exb_contracts:'contrats',exb_rfis:'rfis',exb_submittals:'submittals',exb_change_orders:'avenants',exb_commitments:'engagements',exb_risks:'risques',exb_meetings:'reunions',exb_reserves:'reserves',exb_equipment:'parc_materiel',exb_qhse:'qhse',exb_cde:'cde',exb_bim_issues:'bim_issues',exb_evm:'evm',exb_maintenance:'maintenance',exb_risk_register:'risk_register',exb_client_portal:'client_portal',exb_portails:'portails',exb_esign:'esign',exb_msg_queue:'relances',exb_drawings_v70:'plans_coupes_structure',exb_drawing_sheets_v71:'drawing_sheets',exb_drawing_sets_v71:'drawing_sets',exb_price_library:'price_library',exb_estimates:'estimates',exb_benchmarks:'benchmarks',exb_ai_notes:'ai_notes',exb_facility_assets:'facility_assets',exb_facility_workorders:'facility_workorders',exb_facility_contracts:'facility_contracts',exb_facility_warranties:'facility_warranties',exb_facility_inspections:'facility_inspections',exb_receptions:'receptions',exb_taches_terrain:'taches_terrain',exb_procurement:'achats',exb_subcontractors:'sous_traitants',exb_dqe:'dqe',exb_hr_contracts:'contrats_rh',exb_approvals:'validations',exb_signatures:'signatures',exb_cde_workflows:'cde_workflows',exb_bank_reconciliation:'rapprochement_bancaire',exb_payroll:'paie',exb_compliance:'conformite',exb_company_assets:'actifs_entreprise',exb_action_plans:'plans_actions',exb_v94_studies:'etudes_v94',exb_v94_drawings:'plans_v94',exb_v94_revisions:'revisions_plans_v94',exb_v94_visas:'visas_v94',exb_v94_documents:'documents_cde_v94',exb_v94_bim_models:'bim_models_v94',exb_v94_bim_issues:'bim_issues_v94',exb_v94_distributions:'diffusions_v94',exb_pieces:'pieces',exb_plan_files:'plans_fichiers',exb_plan_annots:'plans_annotations',exb_permits:'autorisations',exb_v92_crm:'v92_crm',exb_v92_suppliers:'v92_fournisseurs',exb_v92_purchase_requests:'v92_demandes_achat',exb_v92_purchase_orders:'v92_commandes',exb_v92_receipts:'v92_receptions',exb_v92_supplier_invoices:'v92_factures_fournisseurs',exb_v92_stock:'v92_stock',exb_v92_stock_moves:'v92_mouvements_stock',exb_v92_bank:'v92_banques',exb_v92_bank_tx:'v92_transactions_bancaires',exb_v92_employees:'v92_employes',exb_v92_contracts:'v92_contrats_rh',exb_v92_payroll:'v92_paies',exb_v93_projects:'v93_projets',exb_v93_sites:'v93_chantiers',exb_v93_tasks:'v93_taches',exb_v93_hse:'v93_qhse',exb_v93_equipment:'v93_materiel',exb_v93_subcontracts:'v93_sous_traitance',exb_v93_payment_methods:'v93_moyens_paiement',exb_v93_payments:'v93_paiements',exb_v93_cash_operations:'v93_operations_caisse',exb_formation_workflow_v95:'v95_formation_workflow',exb_workflow_links_v97:'v97_liens_flux'};
var REND={exb_clients:'renderExbClients',exb_projects:'renderExbProjects',exb_quotes:'renderExbQuotes',exb_stock:'renderExbStock',exb_hr:'renderExbHr',exb_cash:'renderExbCash',exb_studies:'renderExbStudies',exb_communication:'renderExbCom',exb_documents:'renderExbDocuments'};
REND.exb_invoices=null;
/* V99zn : les modules ERP V92, BTP V93 et paiements V93 se réaffichent quand une fiche arrive d'un collègue. */
function reMod(n){return function(){try{var m=window[n];if(m&&typeof m.refresh==='function')m.refresh()}catch(e){}}}
window.exbReRender92=reMod('EXB_ERP');window.exbReRender93b=reMod('EXB_BTP');window.exbReRender93p=reMod('EXB_PAYMENTS');
Object.keys({exb_v92_crm:1,exb_v92_suppliers:1,exb_v92_purchase_requests:1,exb_v92_purchase_orders:1,exb_v92_receipts:1,exb_v92_supplier_invoices:1,exb_v92_stock:1,exb_v92_stock_moves:1,exb_v92_bank:1,exb_v92_bank_tx:1,exb_v92_employees:1,exb_v92_contracts:1,exb_v92_payroll:1}).forEach(function(k){REND[k]='exbReRender92'});
Object.keys({exb_v93_projects:1,exb_v93_sites:1,exb_v93_tasks:1,exb_v93_hse:1,exb_v93_equipment:1,exb_v93_subcontracts:1}).forEach(function(k){REND[k]='exbReRender93b'});
Object.keys({exb_v93_payment_methods:1,exb_v93_payments:1,exb_v93_cash_operations:1}).forEach(function(k){REND[k]='exbReRender93p'});
/* V99zn : collections sensibles. Un membre « polyvalent » n'y a plus accès (le serveur applique la même règle : migration-v99zn-synchro-modules.sql). */
var SENS={personnel:1,paie:1,contrats_rh:1,rapprochement_bancaire:1,v92_employes:1,v92_contrats_rh:1,v92_paies:1,v92_banques:1,v92_transactions_bancaires:1};
var SET={exb_clients:function(v){exbClients=v},exb_projects:function(v){exbProjects=v},exb_quotes:function(v){exbQuotes=v},exb_stock:function(v){exbStock=v},exb_stock_moves:function(v){exbStockMoves=v},exb_hr:function(v){exbHr=v},exb_cash:function(v){exbCash=v},exb_studies:function(v){exbStudies=v},exb_communication:function(v){exbCommunication=v},exb_documents:function(v){window.exbDocuments=v}};
var FILT={exb_documents:function(o){return !!o.cloud}};
var KEYS=Object.keys(COLS),$=function(i){return document.getElementById(i)};
var meta={org:null,role:null,fonction:'polyvalent',droits:null,dAt:0,sig:'',nom:null,code:null,since:'',rec:{},conf:[]};try{meta=Object.assign(meta,JSON.parse(localStorage.getItem(MK)||'{}'))}catch(e){}
var applying=false,busy=false,tm=null,last=null,msg='',_set=null;
function sm(){try{localStorage.setItem(MK,JSON.stringify(meta))}catch(e){}}
function api(p,o){return window.exbSb.api(p,o)}function rpc(n,b){return api('/rest/v1/rpc/'+n,{method:'POST',body:JSON.stringify(b||{})})}
function locked(){try{var l=window.EXBLIC&&window.EXBLIC.last;return !!(l&&l.mode==='locked')}catch(e){return false}}
function canLeave(){try{return !window.EXBLIC||window.EXBLIC.isAdmin()}catch(e){return false}}
function on(){return !!(window.exbSb&&window.exbSb.isIn&&window.exbSb.isIn())}
function hs(o){var s=JSON.stringify(o),h=5381;for(var i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return s.length+':'+h}
function rd(k){try{var v=JSON.parse(exbStorage.getItem(k));return Array.isArray(v)?v:[]}catch(e){return []}}
function wr(k,v){applying=true;try{exbStorage.setItem(k,JSON.stringify(v));if(SET[k])try{SET[k](v)}catch(e){}}finally{applying=false}}
function ensureIds(k,a){var ch=false;a.forEach(function(o){if(o&&typeof o==='object'&&!o.id){o.id='R-'+Date.now().toString(36)+Math.random().toString(36).slice(2,7);ch=true}});if(ch)wr(k,a);return a}
function R(c){if(!meta.rec[c])meta.rec[c]={};return meta.rec[c]}
/* --- V66 : droits par fonction (le serveur les applique aussi ; ici : menus, lecture seule, messages) --- */
var FLAB={polyvalent:'Polyvalent',direction:'Direction',chef_projet:'Chef de projet',conducteur:'Conducteur de travaux',bureau_etudes:'Bureau d\'études',comptable:'Comptable',rh:'Ressources humaines',magasinier:'Magasinier'};
function can(c,m){if(!meta.org)return true;if(meta.role==='admin')return true;var w=(m==='ecrire');if(w&&meta.role==='lecteur')return false;var f=meta.fonction||'polyvalent';if(f==='polyvalent'&&!SENS[c])return true;var d=meta.droits&&meta.droits[c];return !!(d&&(w?d[1]:d[0]))}
function flab(){return meta.role==='admin'?'Administrateur':(FLAB[meta.fonction||'polyvalent']||meta.fonction)}
var lastDeny={};
function deny(k){applying=true;try{if(SET[k])SET[k](rd(k))}catch(e){}finally{applying=false}
 var t=Date.now();if(t-(lastDeny[k]||0)>4000){lastDeny[k]=t;say('Droits insuffisants : votre fonction ('+flab()+') ne permet pas de modifier « '+COLS[k]+' ». La modification n\'a pas été enregistrée.','warn',7000)}
 try{refresh([k])}catch(e){}}
/* Après un changement de fonction : les copies locales des données non modifiables sont rechargées depuis le serveur (aucun conflit). */
function applyRights(){var sig=meta.role+'|'+(meta.fonction||'polyvalent')+'|'+JSON.stringify(meta.droits||0);if(meta.sig===sig)return;
 KEYS.forEach(function(k){var c=COLS[k];if(can(c,'ecrire'))return;if(!meta.rec[c]||!Object.keys(meta.rec[c]).length)return;var keep=FILT[k]?rd(k).filter(function(o){return !FILT[k](o)}):[];wr(k,keep);meta.rec[c]={}});
 meta.since='';meta.sig=sig}
async function loadRights(force){if(!meta.org||!on())return;if(!force&&Date.now()-(meta.dAt||0)<300000)return;
 try{var o=await rpc('mon_organisation');if(o&&o.id===meta.org){meta.role=o.role;meta.fonction=o.fonction||'polyvalent'}
  if(meta.role!=='admin'){var rows=await api('/rest/v1/droits_fonction?fonction=eq.'+encodeURIComponent(meta.fonction)+'&select=collection,lire,ecrire')||[],d={};rows.forEach(function(r){d[r.collection]=[!!r.lire,!!r.ecrire]});meta.droits=d}else meta.droits=null;
  meta.dAt=Date.now();applyRights();sm();try{window.dispatchEvent(new Event('exb-rights'))}catch(e){}paint()}catch(e){}}
/* --- fusion d'une ligne distante dans la copie locale (la version distante gagne ; ma version non envoyée est gardée dans « Conflits ») --- */
function applyRemote(k,list,id,r){var b=R(COLS[k])[id],i=list.findIndex(function(x){return x.id===id}),loc=i>=0?list[i]:null;
 if(loc&&b&&hs(loc)!==b.h||(loc&&!b)){meta.conf.push({k:k,id:id,loc:loc,at:new Date().toISOString()});meta.conf=meta.conf.slice(-50)}
 if(r.supprime){if(i>=0)list.splice(i,1);delete R(COLS[k])[id]}else{if(i>=0)list[i]=r.data;else list.push(r.data);R(COLS[k])[id]={v:r.version,h:hs(r.data)}}
 if(r.supprime)R(COLS[k])[id]={v:r.version,h:'del',d:1}}
async function cycle(){if(busy||!meta.org||!on()||locked())return;busy=true;var n=0,sent=0,stale=false,licDeny=false;
 try{
  await loadRights();if(!meta.org){busy=false;return}
  var ch={},since=meta.since,more=true,maxM=meta.since;
  while(more){var q='/rest/v1/enregistrements?org_id=eq.'+meta.org+(since?'&maj=gt.'+encodeURIComponent(since):'')+'&select=collection,id,data,version,supprime,maj&order=maj.asc&limit=1000';
   var rows=await api(q)||[];rows.forEach(function(r){var k=KEYS.find(function(x){return COLS[x]===r.collection});if(!k)return;var b=R(r.collection)[r.id];if(b&&r.version<=b.v)return;
     if(!ch[k])ch[k]=ensureIds(k,rd(k));applyRemote(k,ch[k],r.id,r);n++;if(r.maj>maxM)maxM=r.maj});
   more=rows.length===1000;if(more)since=rows[rows.length-1].maj}
  Object.keys(ch).forEach(function(k){wr(k,ch[k])});
  meta.since=maxM?new Date(new Date(maxM).getTime()-5000).toISOString():meta.since;
  /* envoi des modifications locales */
  var conflicts=0;
  for(var ki=0;ki<KEYS.length;ki++){if(!can(COLS[KEYS[ki]],'ecrire'))continue;var k=KEYS[ki],c=COLS[k],list=ensureIds(k,rd(k)),rec=R(c),seen={};
   for(var j=0;j<list.length;j++){var o=list[j],h=hs(o),b=rec[o.id];seen[o.id]=1;if(FILT[k]&&!FILT[k](o))continue;if(b&&b.h===h)continue;
    try{if(window.EXB77&&await window.EXB77.pushPhotos(meta.org,c,o)){h=hs(o);list.__ph=1}}catch(e){}
    var res=await rpc('enregistrer',{p_org:meta.org,p_col:c,p_id:o.id,p_data:o,p_base:b?b.v:0,p_supprime:false});
    if(res&&res.ok){rec[o.id]={v:res.version,h:h};sent++}else if(res&&res.conflit){conflicts++;if(!ch[k])ch[k]=list;applyRemote(k,list,o.id,{data:res.data,version:res.version,supprime:res.supprime});if(!res.supprime)rec[o.id]={v:res.version,h:hs(res.data)};meta.since=''}else if(res&&res.refus){stale=true;if(res.licence)licDeny=true}}
   if(list.__ph){delete list.__ph;wr(k,list)}
   for(var id in rec){if(!seen[id]&&!rec[id].d){var b2=rec[id],rs=await rpc('enregistrer',{p_org:meta.org,p_col:c,p_id:id,p_data:{},p_base:b2.v,p_supprime:true});
    if(rs&&rs.ok){rec[id]={v:rs.version,h:'del',d:1};sent++}else if(rs&&rs.conflit){conflicts++;rec[id]={v:rs.version,h:'x'};meta.since=''}else if(rs&&rs.refus){stale=true;if(rs.licence)licDeny=true}}}
   if(conflicts&&ch[k])wr(k,list)}
  if(stale)meta.dAt=0;last=new Date();msg='✓ Synchronisé '+last.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})+' — reçu : '+n+', envoyé : '+sent+(conflicts?' — '+conflicts+' conflit(s)':'');if(licDeny)msg='⚠ Licence suspendue ou expirée : le serveur refuse les modifications (lecture seule). Contactez l\'administrateur du logiciel.';
  sm();if(n||conflicts)refresh(Object.keys(ch));if(ch.exb_metre)banner()
 }catch(e){msg='⚠ '+(e&&e.message||e)}finally{busy=false;paint()}}
function refresh(ks){try{if(window.EXBCH)window.EXBCH.render()}catch(e){}try{if(window.EXBTR)window.EXBTR.render()}catch(e){}try{if(window.EXBET)window.EXBET.render()}catch(e){}try{if(window.EXBPL)window.EXBPL.render()}catch(e){}ks.forEach(function(k){var f=REND[k]&&window[REND[k]];if(typeof f==='function')try{f()}catch(e){}});try{if(window.updateExbDirection)updateExbDirection()}catch(e){}}
function mark(k){if(applying||!meta.org||KEYS.indexOf(k)<0)return;clearTimeout(tm);tm=setTimeout(cycle,2500)}

/* --- Espace de stockage de documents (Supabase Storage, bucket privé « documents », un dossier par entreprise) --- */
var BUCKET='documents';
function cloud(){return !!(meta.org&&on())}
function safe(n){return String(n||'fichier').replace(/[^A-Za-z0-9._-]+/g,'_').slice(-80)}
function upload(path,file){return api('/storage/v1/object/'+BUCKET+'/'+path,{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream','x-upsert':'true'},body:file})}
async function signed(path){var r=await api('/storage/v1/object/sign/'+BUCKET+'/'+path,{method:'POST',body:JSON.stringify({expiresIn:600})});return window.exbSb.cfg().url+'/storage/v1'+r.signedURL}
function thumb(file){return new Promise(function(res){if(!/^image\//.test(file.type))return res('');var u=URL.createObjectURL(file),im=new Image();im.onload=function(){var k=Math.min(1,160/Math.max(im.width,im.height,1)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);res(c.toDataURL('image/jpeg',.6))};im.onerror=function(){URL.revokeObjectURL(u);res('')};im.src=u})}
function say(m,t,ms){try{notify(m,t||'info',ms||4000)}catch(e){exbAlert(m)}}
function banner(){if($('exbdb_ban'))return;var b=document.createElement('div');b.id='exbdb_ban';b.style.cssText='position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:9600;background:#173565;color:#fff;padding:10px 14px;border-radius:10px;font-size:13px;box-shadow:0 2px 10px rgba(0,0,0,.4)';b.innerHTML='Des métrés ont été mis à jour par un collègue. <button class="primary" style="margin-left:8px" onclick="location.reload()">Recharger</button> <button class="muted" onclick="this.parentNode.remove()">Plus tard</button>';document.body.appendChild(b)}
function wrapDocs(){if(typeof window.saveExbDocument!=='function')return setTimeout(wrapDocs,600);if(window.__exbDocsWrapped)return;window.__exbDocsWrapped=1;
 var oS=window.saveExbDocument,oD=window.downloadExbDocument,oP=window.printExbDocument,oX=window.deleteExbDocument;
 window.saveExbDocument=async function(){if(!cloud())return oS.apply(this,arguments);
  var f=$('exbDocFile')&&$('exbDocFile').files[0],title=$('exbDocTitle')&&$('exbDocTitle').value.trim();
  if(!f||!title)return say('Titre et fichier sont obligatoires pour enregistrer le document.','warn');
  if(f.size>50*1024*1024)return say('Fichier refusé : 50 Mo maximum.','error');
  if(meta.role==='lecteur')return say('Votre rôle (lecteur) ne permet pas d\'ajouter des documents.','warn');
  try{say('Envoi vers l\'espace de stockage…','info',3000);
   var id='DOC-'+Date.now().toString(36),path=meta.org+'/'+id+'-'+safe(f.name),pid=$('exbDocParticipant').value,prid=$('exbDocProject').value,p,pr;
   try{p=exbData('exb_participants').find(function(x){return x.participant_id===pid});pr=exbData('exb_projects').find(function(x){return x.id===prid})}catch(e){}
   await upload(path,f);
   var d={id:id,title:title,type:$('exbDocType').value,participant_id:pid,participant_name:p&&p.name||'',project_id:prid,project_name:pr&&pr.name||'',name:f.name,mime:f.type||'application/octet-stream',size:f.size,data:await thumb(f),path:path,cloud:true,created_at:new Date().toISOString()};
   window.exbDocuments.unshift(d);save('exb_documents',window.exbDocuments);try{audit('DOCUMENT_AJOUTÉ (cloud)',d.title+' — '+d.name)}catch(e){}
   clearExbDocumentForm();renderExbDocuments();say('Document enregistré dans l\'espace partagé.','success')
  }catch(e){say('Envoi impossible : '+(e.message||e),'error',9000)}};
 function find(id){return (window.exbDocuments||[]).find(function(x){return x.id===id})}
 window.downloadExbDocument=async function(id){var d=find(id);if(!d||!d.cloud)return oD.apply(this,arguments);try{var u=await signed(d.path),a=document.createElement('a');a.href=u;a.download=d.name||'document';a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove()}catch(e){say('Téléchargement impossible : '+(e.message||e),'error',8000)}};
 window.printExbDocument=async function(id){var d=find(id);if(!d||!d.cloud)return oP.apply(this,arguments);try{window.open(await signed(d.path),'_blank')}catch(e){say('Ouverture impossible : '+(e.message||e),'error',8000)}};
 window.deleteExbDocument=async function(id){var d=find(id);if(!d||!d.cloud)return oX.apply(this,arguments);if(!(await exbConfirm('Supprimer ce document de l\'espace partagé ?')))return;
  try{await api('/storage/v1/object/'+BUCKET+'/'+d.path,{method:'DELETE'})}catch(e){if(e&&e.code!==404){return say('Suppression refusée : '+(e.message||e),'error',8000)}}
  window.exbDocuments=window.exbDocuments.filter(function(x){return x.id!==id});save('exb_documents',window.exbDocuments);try{audit('DOCUMENT_SUPPRIMÉ (cloud)',d.title)}catch(e){}renderExbDocuments()}}
async function migrate(){if(!cloud())return;var l=window.exbDocuments||[],n=0,ko=0;
 for(var i=0;i<l.length;i++){var d=l[i];if(d.cloud||!d.data||String(d.data).indexOf('data:')!==0)continue;
  try{var b=await (await fetch(d.data)).blob(),f=new File([b],d.name||'fichier',{type:d.mime||b.type}),path=meta.org+'/'+d.id+'-'+safe(d.name);await upload(path,f);d.path=path;d.cloud=true;d.data=await thumb(f);n++;save('exb_documents',l)}catch(e){ko++}}
 try{renderExbDocuments()}catch(e){}say(n+' document(s) envoyé(s) vers l\'espace de stockage'+(ko?' — '+ko+' échec(s)':'')+'.',ko?'warn':'success',6000);cycle()}
/* --- interface --- */
function chip(){var c=$('exbdb_chip');if(c)return c;c=document.createElement('button');c.id='exbdb_chip';c.className='muted';c.style.cssText='position:fixed;left:10px;bottom:10px;z-index:9000;border-radius:20px;padding:8px 12px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,.25)';c.onclick=panel;document.body.appendChild(c);return c}
function paint(){var c=chip();c.textContent=meta.org?('🗄 '+(meta.nom||'Base partagée')+(busy?' ⏳':(msg.indexOf('⚠')===0?' ⚠':' ✓'))):'🗄 Base partagée';var p=$('exbdb_panel');if(p)panel(true)}
function esc(v){return String(v==null?'':v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
async function panel(keep){var p=$('exbdb_panel');if(!p){p=document.createElement('div');p.id='exbdb_panel';p.style.cssText='position:fixed;inset:0;z-index:9500;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:12px';p.onclick=function(e){if(e.target===p)p.remove()};document.body.appendChild(p)}
 var h='<div class="card" style="max-width:560px;width:100%;max-height:90vh;overflow:auto;background:#fff;color:#111;padding:16px;border-radius:12px"><div style="display:flex;justify-content:space-between"><h3 style="margin:0">🗄 Base de données partagée</h3><button class="muted" onclick="document.getElementById(\'exbdb_panel\').remove()">✕</button></div>';
 if(!on())h+='<p>Connectez-vous d\'abord au <b>compte en ligne</b> (serveur Supabase configuré), puis rouvrez ce panneau.</p>';
 else if(!meta.org)h+='<p>Votre entreprise n\'est pas encore reliée. Exécutez d\'abord <code>supabase/schema-entreprise.sql</code> dans Supabase, puis :</p><label>Nom de l\'entreprise (création)</label><input id="exbdb_nom" placeholder="Excellencia Building"/><button class="primary" onclick="EXBDB.create()">Créer la base de mon entreprise</button><hr><label>Ou rejoindre avec un code d\'invitation</label><input id="exbdb_code" placeholder="a1b2c3d4"/><button class="muted" onclick="EXBDB.join()">Rejoindre</button>';
 else{h+='<p><b>'+esc(meta.nom)+'</b> · votre rôle : <b>'+esc(meta.role)+'</b> · fonction : <b>'+esc(flab())+'</b></p><p class="exb-muted">'+esc(msg||'—')+'</p><div class="exb-actions"><button class="primary" onclick="EXBDB.now()">🔄 Synchroniser maintenant</button> <button class="muted" onclick="EXBDB.migrate()">☁️ Envoyer mes anciens documents vers l\'espace de stockage</button></div>';
  if(meta.role==='admin'&&meta.code)h+='<p>Code d\'invitation à donner à vos collaborateurs (ils doivent avoir un compte) : <b style="font-size:18px">'+esc(meta.code)+'</b> <button class="muted" onclick="EXBDB.renew()">Renouveler</button></p><div id="exbdb_mem">Chargement des membres…</div>';
  if(meta.conf.length)h+='<h4>⚠ Conflits ('+meta.conf.length+')</h4><p class="exb-muted">Quelqu\'un a modifié la même fiche en même temps : sa version a été gardée. Voici la vôtre :</p>'+meta.conf.map(function(c,i){return '<div style="border:1px solid #ddd;padding:6px;margin:4px 0;border-radius:6px"><small>'+esc(COLS[c.k])+' · '+esc(c.loc&&(c.loc.name||c.loc.client||c.loc.no||c.loc.label||c.loc.title||c.loc.project||c.id))+'</small> <button class="muted" onclick="EXBDB.restore('+i+')">Restaurer ma version</button> <button class="muted" onclick="EXBDB.drop('+i+')">Ignorer</button></div>'}).join('');
  if(canLeave())h+='<p><button class="muted" onclick="EXBDB.leave()">Se délier de cette base</button></p>';else h+='<p class="exb-muted">Cette base est liée à votre abonnement : seul l\'administrateur du logiciel peut la délier.</p>'}
 p.innerHTML=h+'</div>';
 if(on()&&meta.org&&meta.role==='admin'){var ms,hasF=true;try{ms=await api('/rest/v1/membres?org_id=eq.'+meta.org+'&select=user_id,nom,role,fonction')}catch(x){hasF=false;try{ms=await api('/rest/v1/membres?org_id=eq.'+meta.org+'&select=user_id,nom,role')}catch(y){ms=null}}
  var ih={};try{(await api('/rest/v1/ingenieurs_habilites?org_id=eq.'+meta.org+'&select=user_id,nom,ordre,actif')||[]).forEach(function(x){ih[x.user_id]=x})}catch(x){ih=null}
  var e=$('exbdb_mem');if(e&&ms){var fs=Object.keys(FLAB);e.innerHTML='<table class="exb-table"><thead><tr><th>Membre</th><th>Rôle</th>'+(hasF?'<th>Fonction</th>':'')+(ih?'<th>Ingénieur habilité</th>':'')+'</tr></thead><tbody>'+ms.map(function(m){return '<tr><td>'+esc(m.nom||m.user_id.slice(0,8))+'</td><td><select onchange="EXBDB.role(\''+m.user_id+'\',this.value)">'+['admin','editeur','lecteur'].map(function(r){return '<option'+(r===m.role?' selected':'')+'>'+r+'</option>'}).join('')+'</select></td>'+(hasF?'<td><select onchange="EXBDB.fonction(\''+m.user_id+'\',this.value)">'+fs.map(function(f){return '<option value="'+f+'"'+(f===(m.fonction||'polyvalent')?' selected':'')+'>'+esc(FLAB[f])+'</option>'}).join('')+'</select></td>':'')+(ih?(function(){var h=ih[m.user_id]||{},id=m.user_id;return '<td><input id="exbi_n_'+id+'" placeholder="Nom complet" value="'+esc(h.nom||'')+'" style="width:130px"> <input id="exbi_o_'+id+'" placeholder="N° ordre" value="'+esc(h.ordre||'')+'" style="width:80px"> <button class="muted" onclick="EXBDB.habiliter(\''+id+'\',true)">'+(h.actif?'Mettre à jour':'Habiliter')+'</button>'+(h.actif?' <button class="muted" onclick="EXBDB.habiliter(\''+id+'\',false)">Retirer</button> <small>✓ actif</small>':'')+'</td>'})():'')+'</tr>'}).join('')+'</tbody></table>'+(hasF?'<p class="exb-muted">Fonction « Polyvalent » = accès complet (comportement d\'avant). Choisissez une fonction pour limiter ce que le membre voit et modifie. Le rôle « admin » garde tous les droits.</p>':'<p class="exb-muted">Les fonctions ne sont pas encore activées : exécutez supabase/migration-v66-roles.sql dans Supabase.</p>')+'<p><button class="muted" onclick="EXBDB.journal()">📜 Journal des opérations</button></p><div id="exbdb_log"></div>'}}}
async function userNom(){try{var u=await api('/auth/v1/user');return u&&u.email||null}catch(e){return null}}
function setOrg(o){meta.org=o.id;meta.nom=o.nom;meta.role=o.role;meta.fonction=o.fonction||'polyvalent';meta.droits=null;meta.dAt=0;meta.sig='';meta.code=o.code||null;meta.since='';meta.rec={};sm();try{localStorage.setItem('exb_db_on','1')}catch(e){}}
window.EXBDB={
 handles:function(k){return !!COLS[k]},/* V99 : clés gérées fiche par fiche ici (exb-sync les ignore alors) */
 org:function(){return meta.org},
 habiliter:async function(u,actif){try{var n=($('exbi_n_'+u)||{}).value||'',o=($('exbi_o_'+u)||{}).value||'';var r=await rpc('ingenieur_designer',{p_org:meta.org,p_user:u,p_nom:n,p_ordre:o,p_actif:!!actif});if(r&&r.ok){say(actif?'Ingénieur habilité enregistré.':'Habilitation retirée.','success',5000);panel(true)}else exbAlert('Refusé : '+((r&&r.refus)||'erreur')+(r&&r.refus==='mfa_requise'?' — connectez-vous avec la double authentification.':''))}catch(e){exbAlert(e.message||e)}},
 create:async function(){try{setOrg(await rpc('creer_organisation',{p_nom:$('exbdb_nom').value,p_nom_user:await userNom()}));await cycle();panel(true)}catch(e){exbAlert('Erreur : '+(e.message||e))}},
 join:async function(){try{var o=await rpc('rejoindre_organisation',{p_code:$('exbdb_code').value,p_nom_user:await userNom()});setOrg(o);await cycle();panel(true)}catch(e){exbAlert('Erreur : '+(e.message||e))}},
 migrate:migrate,now:function(){meta.since='';cycle()},
 renew:async function(){try{meta.code=await rpc('renouveler_code',{p_org:meta.org});sm();panel(true)}catch(e){exbAlert(e.message||e)}},
 fonction:async function(u,f){try{await api('/rest/v1/membres?org_id=eq.'+meta.org+'&user_id=eq.'+u,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({fonction:f})});say('Fonction modifiée. Elle sera appliquée sur l\'appareil du membre dans les 5 minutes (ou à sa prochaine ouverture).','success',6000)}catch(e){exbAlert(e.message||e)}},
 journal:async function(){var b=$('exbdb_log');if(!b)return;b.textContent='Chargement…';try{var r=await api('/rest/v1/journal_entreprise?org_id=eq.'+meta.org+'&select=quand,user_id,collection,rec_id,action&order=n.desc&limit=40')||[];b.innerHTML='<table class="exb-table"><thead><tr><th>Quand</th><th>Utilisateur</th><th>Collection</th><th>Action</th></tr></thead><tbody>'+r.map(function(x){return '<tr><td>'+esc(new Date(x.quand).toLocaleString('fr-FR'))+'</td><td>'+esc(String(x.user_id||'').slice(0,8))+'</td><td>'+esc(x.collection)+'</td><td>'+esc(x.action)+'</td></tr>'}).join('')+'</tbody></table>'}catch(e){b.textContent='Journal indisponible : '+(e.message||e)}},
 org:function(){return meta.org||''},
 can:can,info:function(){return {on:!!meta.org,role:meta.role,fonction:meta.fonction||'polyvalent',label:flab()}},
 role:async function(u,r){try{await api('/rest/v1/membres?org_id=eq.'+meta.org+'&user_id=eq.'+u,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({role:r})})}catch(e){exbAlert(e.message||e)}},
 restore:function(i){var c=meta.conf[i];if(!c)return;var l=rd(c.k),j=l.findIndex(function(x){return x.id===c.id});if(j>=0)l[j]=c.loc;else l.push(c.loc);wr(c.k,l);meta.conf.splice(i,1);sm();refresh([c.k]);cycle()},
 drop:function(i){meta.conf.splice(i,1);sm();panel(true)},
 leave:async function(){if(!canLeave())return;if(!(await exbConfirm('Se délier de la base partagée ? Les données restent sur cet appareil.')))return;meta={org:null,role:null,nom:null,code:null,since:'',rec:{},conf:[]};sm();try{localStorage.removeItem('exb_db_on')}catch(e){}paint()},
 cycle:cycle,_meta:function(){return meta}};
/* V99zzj — rejoint l'entreprise : d'abord par l'e-mail invité, sinon avec le code d'invitation saisi sur l'écran de verrouillage. */
function savedInv(){try{return localStorage.getItem('exb_inv_code')}catch(e){return null}}
async function autoJoin(){try{try{await rpc('equipe_reclamer')}catch(e){}var o=await rpc('mon_organisation');
 if(!(o&&o.id)){var c=savedInv();if(c){try{o=await rpc('rejoindre_organisation',{p_code:c,p_nom_user:await userNom()})}catch(e){o=null}}}
 if(o&&o.id){setOrg(o);try{localStorage.removeItem('exb_inv_code')}catch(e){}}}catch(e){}}
function init(){if(!window.exbStorage&&typeof exbStorage==='undefined')return setTimeout(init,500);
 var o=exbStorage.setItem.bind(exbStorage);exbStorage.setItem=function(k,v){if(!applying&&meta.org&&COLS[k]&&!can(COLS[k],'ecrire')){deny(k);return}o(k,v);mark(k)};
 wrapDocs();chip();paint();setInterval(function(){if(!document.hidden){if(!meta.org&&on()&&savedInv())autoJoin();cycle()}},20000);document.addEventListener('visibilitychange',function(){if(!document.hidden)cycle()});window.addEventListener('online',cycle);setTimeout(async function(){
  if(on()&&!meta.org)await autoJoin();cycle()},3000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
