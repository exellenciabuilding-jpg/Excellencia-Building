# V142d — Reçu de paiement client : bandeau du titre, filets et signature

## Ce qui change (`site/exb-v142c-recu-client.js`)
- En-tête conservé tel quel (fond blanc : logo, nom, devise dorée, coordonnées à droite, filet doré).
- Bandeau du titre « REÇU DE PAIEMENT » : fond bleu clair avec barre bleue à gauche (comme le reçu d'inscription), nom du projet dessous.
- Deux filets autour du bandeau : doré au-dessus (celui de l'en-tête), bleu en dessous.
- Bas du reçu : nom du Directeur Général en italique bleu + « Directeur Général » à gauche, signature + sceau à côté avec « Signature / Sceau autorisé ». Le cadre de signature du client est supprimé.
- QR de vérification en bas à gauche avec « Scannez pour vérifier l'authenticité du reçu » ; mention « Important » à sa droite.
- Les champs (N°, date, agence, devise, sections 1 à 4) sont inchangés.

## Déploiement
Redéployer `site` sur Netlify, rouvrir le logiciel (cache v157).

## Vérifié
- `node tools/check.js` : 557 contrôles réussis, 0 échec.
- Reçu généré hors navigateur (signature/sceau factices) : 1 page, rendu contrôlé.

## Non testé
- Pas testé dans le logiciel ouvert, avec la vraie signature/le vrai sceau, ni sur téléphone.
