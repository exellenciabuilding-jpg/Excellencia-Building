# Excellencia Building — correctif issu de l'audit de stabilité (lots P0 et P2)

## P0 — Dialogues natifs
- `exb-ui-dialog.js` : ajout de `EXBUI.alert` (file d'attente, un message à la fois, Entrée/Échap) et des aides explicites `exbAlert`, `exbPrompt`, `exbConfirm` (repli natif seulement si EXBUI est absent).
- `exb-v77.js` : les 3 `prompt()` natifs (dont le bouton « Statuts réserve levée » `#v77lift`, 5,6 s dans le rapport) deviennent `await exbPrompt(...)`.
- `index.html` : 65 `alert()` sur 67 remplacés par `exbAlert()`. Les 2 conservés sont les alertes de session expirée suivies d'un `location.reload()` (un message non bloquant serait perdu).
- `index.html` : migration explicite (sans rejeu de clic) de : création/membre/tâche de chantier (prompt), annulation de certificat, suppression de participant, lot de devis, rejet d'entité.
  - `toggleCertStatus` ne modifie plus le statut avant la réponse de l'utilisateur.
- Migration automatique (outil + contrôle de syntaxe à chaque site) de ~100 confirm()/prompt() supplémentaires dans index.html et 27 modules : seules les fonctions nommées sans valeur de retour utilisée, les gestionnaires d'actions et les handlers de clic sont passés en async. Exclus volontairement : fonctions dont la valeur de retour est lue par un appelant (readSpecs, exbPhoneIntl, eqUrl, restore, aiRun, hooks beforeSave de exb-devis-unique), callbacks et gestionnaires qui appellent preventDefault, exb-brand.js et exb-paiement.js (chargés dans des pages sans exb-ui-dialog.js), pages autonomes. Les appels restants (voir ci-dessous) continuent d'être pris en charge par l'ancien rejeu de clic.

- 110 `alert()` supplémentaires des modules remplacés par `exbAlert()` (la lecture vocale du guide reste active via `__exbAlertHook`). Il reste en natif : 2 alertes de session expirée avec rechargement.
- Appels natifs restants après migration : index.html 14 confirm / 16 prompt ; modules 30 confirm / 15 prompt (fonctions dont la valeur de retour est lue, callbacks, repli copier-coller).

## P2 — Observateurs DOM
- `exb-v77.js` : l'observateur ne retient que les éléments ajoutés ; `fixImgs` ne cherche les images `sb:` que dans ces éléments (plus de `querySelectorAll` global à chaque mutation) ; traitement en période d'inactivité.
- `exb-bigstore.js` : les deux observateurs sont regroupés par image d'écran (`requestAnimationFrame`) et ignorés si aucun élément n'est ajouté.

## Vérifications
- `node --check` : tous les .js de `site/` + tous les blocs `<script>` inline de index.html : 0 erreur.
- Essai navigateur (Chromium) : file d'alertes, bouton v77lift → formulaire intégré → enregistrement, image `sb:` ajoutée dynamiquement : OK, aucune erreur console.
- Non fait : tests interactifs sur Windows/Android et sur données réelles (P1 profil du blocage de 4,8 s, P3 à P5 non traités).

## Correctif supplémentaire — avalanche d'erreurs réseau (constaté sur la console : 268 puis 448 erreurs)
- Cause : `refresh()` (index.html) relançait un POST `/auth/v1/token?grant_type=refresh_token` à CHAQUE appel `api()` quand le jeton était proche de l'expiration. Hors connexion (`ERR_INTERNET_DISCONNECTED`), chaque appel (minuteries de synchronisation, etc.) produisait une nouvelle requête en échec.
- Correction : un seul renouvellement à la fois (promesse partagée) ; pas de requête si le navigateur est hors ligne ; après un échec réseau, délai croissant 30 s → 5 min ; remise à zéro dès le retour en ligne. La session n'est pas effacée par une simple coupure réseau.

## P3 / P4 — constats et correctif ciblé
- P3 : dans cette archive, `exb-fab.js`, `exb-metre.js` et `exb-android-nav.js` reportent déjà leur démarrage (`__later` : repos du navigateur après chargement). Les lignes « DOMContentLoaded 1 214 / 1 162 ms » de la capture venaient donc d'une version plus ancienne installée, ou sont à revérifier avec cette version.
- P3 : le bloc `auto` d'index.html (≈ 1 s) exécute `boot()` : premier affichage de l'application (tableau de bord, formateurs, plannings, finances). Il est enchaîné à travers de nombreux `window.boot = …` ; le différer à l'aveugle risque de casser l'ordre d'initialisation. À traiter seulement après trace Performance.
- Aucun `defer` global ajouté (déconseillé par l'audit sans test d'ordre).
- P4 : `exb-bigstore.js` — le compactage automatique (parcours synchrone de localStorage) ne démarre plus 2,5 s après le chargement quel que soit l'état ; il attend 5 s sans frappe ni clic et un moment de repos du navigateur (20 essais max). Le calcul d'espace libéré n'est fait que s'il y a du travail. Compactage forcé (quota plein, bouton) inchangé.

## Diagnostic images « exbidb: » (ERR_UNKNOWN_URL_SCHEME dans la console)
- Deux causes possibles : (1) course au démarrage — l'écran affiche des jetons `exbidb:` avant la fin du chargement d'IndexedDB (corrigé ensuite par `patchDom`, mais le navigateur a déjà journalisé l'erreur) ; (2) jeton dont l'image n'existe plus dans IndexedDB (image définitivement illisible).
- Nouveau : `EXBBIG.audit()` (à taper dans la console) liste les jetons sans image ; un avertissement `EXBBIG : N image(s)… absente(s)` est aussi journalisé une fois, au repos, après le démarrage. Lecture seule.

## P5 — Métré : brouillon moins coûteux
- Revue statique : la saisie met déjà à jour l'état en mémoire immédiatement et regroupe les recalculs par image (`queueRefresh`). Le point coûteux restant était l'enregistrement du brouillon 700 ms après chaque pause (JSON.stringify + compactage des images éventuelles du logo, de façon synchrone).
- `exb-metre.js` : délai porté à 1,2 s, exécution au repos du navigateur, et vidage IMMÉDIAT quand la page se masque ou se ferme (`visibilitychange`, `pagehide`). Les enregistrements manuels (« Enregistrer », « Nouveau ») restent immédiats et annulent le brouillon différé. Aucune donnée, format ou champ modifié.
- À tester : saisir 100 lignes, fermer l'onglet/l'application sans cliquer « Enregistrer », rouvrir : le brouillon doit être complet.
