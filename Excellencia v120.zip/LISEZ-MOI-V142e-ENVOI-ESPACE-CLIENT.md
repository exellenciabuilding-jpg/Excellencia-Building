# V142e — Envoyer une pièce écrite / un document de chantier à l'espace du client

## Ce qui change
- **Pièces écrites et documents de chantier** (CCTP, CCAP, lettres, comptes rendus, ordres de service, **page de garde du dossier de chantier**, tous les modèles) : dans la fenêtre « ✅ PDF prêt », nouveau bouton **📨 Envoyer à l'espace client**.
- Le bouton ouvre une fenêtre : client (le portail du projet est présélectionné), type de document (CCAP → Contrat, compte rendu → Rapport, le reste → Autre document ; modifiable), titre et numéro repris de la pièce, note facultative.
- **📤 Envoyer** : le PDF généré (avec son QR de vérification) arrive dans l'espace du client, rubrique Plans & Documents, et un message l'en informe. Même titre + même type = nouvelle version « modifiée ».
- Après l'envoi : boutons « Prévenir par WhatsApp » et « Prévenir par e-mail » (message prêt, avec le lien de l'espace client).
- Fonctionne aussi depuis l'éditeur Word des pièces (même bouton « PDF officiel » → « PDF prêt »).

## Conditions (identiques à « 📎 Envoyer un document »)
Connexion au compte en ligne, organisation, au moins un portail **client** publié (🔗 Portails & signatures), PDF de 6 Mo maximum, migration `supabase/migration-v142a-documents-client.sql` déjà exécutée. Aucun nouveau SQL.

## Fichiers
`site/exb-v99zy-portails.js` (nouvelle fonction `EXB_PORTAILS.envoyerDocument`), `site/exb-v81-pieces.js` (bouton), `site/sw.js` (cache v158), `site/tools/e2e-envoi-client-pieces.py` (test).

## Déploiement
Redéployer `site` sur Netlify, rouvrir le logiciel (cache v158).

## Vérifié
- `node tools/check.js` : 557 contrôles réussis, 0 échec.
- `python3 tools/e2e-envoi-client-pieces.py` : 21 contrôles réussis (navigateur, serveur simulé) : liste des portails client, présélection, envoi du vrai PDF d'une pièce, nouvelle version, titre obligatoire, fichier > 6 Mo refusé, hors connexion, aucun portail.

## Non testé / limites
- Pas testé avec ton vrai Supabase ni sur téléphone réel ; l'affichage côté client du document reçu repose sur la migration v142a déjà en place.
- Le « Centre documentaire » (docengine/centre.js) et l'envoi **au chantier** (équipe) ne sont pas modifiés.
