# Excellencia Building — V120x STABILITÉ ENGINE

## Objet de cette étape
Durcir le dispositif de diagnostic des ralentissements sans modifier le comportement des fonctions métier.

## Correction apportée
- Le diagnostic chronomètre toujours les callbacks des minuteries et les tâches longues du navigateur.
- Il ne suspend plus globalement les `setInterval` lorsque le curseur est dans un champ. Cette suspension globale pouvait retarder des traitements légitimes (session, notifications, synchronisation ou rafraîchissements d'interface).
- Il ne remplace plus `MutationObserver` par un ordonnanceur personnalisé. Les observateurs DOM conservent donc leur cadence native et leur ordre de traitement.
- Les temporisations ciblées déjà présentes dans les modules concernés restent en place, notamment la recherche globale temporisée et les gardes de saisie de la synchronisation cloud.

## Vérifications réalisées
- Vérification syntaxique du script de diagnostic avec Node.js.
- Vérification syntaxique du JavaScript principal et des scripts JavaScript autonomes du site.
- Vérification de la présence des fichiers de l'archive source et conservation de l'arborescence.

## À tester sur l'environnement réel
1. Ouvrir la recherche globale et saisir une expression longue.
2. Créer puis modifier une fiche client et une fiche apprenant.
3. Laisser un champ actif pendant plusieurs minutes et vérifier que la session reste valide.
4. Vérifier que la synchronisation reprend après la saisie.
5. En cas de ralentissement, lancer `Ctrl + Alt + L` et transmettre le rapport.

Cette version est une version de test. Les essais sur les données réelles et les différents appareils restent nécessaires avant déploiement.
