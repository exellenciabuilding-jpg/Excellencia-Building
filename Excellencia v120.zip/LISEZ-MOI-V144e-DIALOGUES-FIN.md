# Excellencia Building — V144e : fin de la migration des dialogues (suite de l'audit P0)

## Ce qui reste du lot P0 et qui est maintenant traité
- **Suppression du rejeu de clic** dans `exb-ui-dialog.js` (cause de double exécution signalée par l'audit : un gestionnaire qui avait déjà agi avant le `confirm()`/`prompt()` était rejoué).
- **~55 appels `confirm()`/`prompt()` natifs restants migrés** vers `await exbConfirm()` / `await exbPrompt()` dans `index.html` et 17 modules (v68, v74-facility, v76-reception, v99zy-portails, vitrine, tfl, sync, biometrie, sauvegarde-auto, proprietaire, metre, terrain, …). Les fonctions concernées sont passées en `async` uniquement quand aucun appelant ne lit leur valeur de retour de façon synchrone.
- Fonctions dont la valeur de retour était lue, adaptées explicitement : `readSpecs`/`saveTrainer`, `exbPhoneIntl`/`btpSend`, `eqUrl`, `restore` (+ appelants `exbRestoreFile`, `exbFsRestore`), `aiRun`/`aiDo`/`handleAct` (assistant IA), `exb-terrain.js › rec` (boucle `forEach` → `for…of` pour pouvoir attendre chaque saisie).
- **Devis unique (`exb-devis-unique.js`, `exb-metre.js`)** : `beforeSaveMetre(ST, decision)` / `beforeSaveForm(decision)` renvoient `{ask: message}` sans rien modifier ; l'appelant affiche la boîte intégrée (« Mettre à jour » / « Nouveau devis ») puis relance l'enregistrement avec la décision. Aucune opération n'est exécutée deux fois.
- Replis sûrs dans les pages sans `exb-ui-dialog.js` : `exb-brand.js`, `exb-paiement.js`, `exb-verif.js`, `exb-print.js` (avant : `exbAlert` absent → message perdu silencieusement).

## Ce qui reste volontairement natif
- Pages autonomes (formulaires publics, plan-editeur, calcul-structure, modèle d'export « espace apprenant » dans index.html).
- Repli si `EXBUI` est absent (`exbConfirm`/`exbPrompt`).
- Les 2 alertes de session expirée suivies d'un rechargement.

## Vérifications
- Analyse syntaxique de tous les blocs `<script>` et fichiers `.js` : 0 erreur (338 blocs).
- Chromium : chargement de index.html sans erreur ni boîte native ; `exbConfirm`/`exbPrompt` OK ; `beforeSaveForm` : demande → mise à jour (même N°) / nouveau devis (nouveau N°), rien de modifié avant la réponse.
- **Non fait** (reste de l'audit) : P1 (profil Performance du blocage de 4,8 s — nécessite le poste Windows), P3 (`boot()`/defer), mesures IndexedDB (P4), tests de réception sur Windows/Android et données réelles.
- À tester à la main : enregistrer un métré/devis du même client+projet (boîte « Mettre à jour / Nouveau devis »), supprimer une réception, restaurer une sauvegarde, réception de bon de commande (saisie quantité par ligne).

## Suite — P1/P3/P4 : mesures et instrumentation (sans poste Windows)
- **Mesure du démarrage (Chromium, profil CPU)** : aucune tâche > 130 ms au chargement d'index.html ; ≈ 0,5 s de JavaScript au total, réparti sur brand, fab, v127-exemples, enterprise-v51. `boot()` n'apparaît pas comme goulot sur cette machine : pas de `defer` ni de report forcé (risque d'ordre d'initialisation). La ligne « blocage de 4,8 s source inconnue » reste à profiler sur le poste concerné : utiliser **Ctrl + Alt + T** (essai de 10 min, boîtes de dialogue exclues) puis le rapport.
- **exb-bigstore.js (P4)** : la lecture initiale d'IndexedDB utilise un curseur (un enregistrement par tâche) au lieu de `getAll()` (tout d'un bloc). Mesure avec 172 Mo d'images : lecture 465 ms répartie, tâches longues 144/110/90 ms → 112/87 ms.
- **Instrumentation IndexedDB** : `EXBBIG.perf()` (console) donne les 60 dernières opérations (lecture au démarrage, écriture, compactage : durée, nombre, Mo). Toute opération ≥ 300 ms est ajoutée au rapport de lenteur (`EXBDiag.note`). Aucune donnée n'est modifiée.

## Passage complet sur la performance (jeu de données réaliste : 800 clients, 400 chantiers, 300 devis, 1 500 écritures de caisse, 172 Mo d'images)
Banc d'essai Chromium (profil CPU + tâches longues). Avant → après :
- **Démarrage** : 16 tâches longues (jusqu'à 289 ms, chargement 3,5 s) → 9 tâches (maximum 150 ms, chargement 2,0 s).
- **exb-liaison.js** : le registre financier (`ledger`) était recalculé pour chaque chantier (400 fois au démarrage) et comparait chaque écriture de caisse à toutes les autres (O(n²)). Index facture|date + résultat gardé le temps d'une séquence synchrone, invalidé dès qu'une liste est réécrite ou change de taille (≈ 1 s économisée).
- **Normalisation de texte** (`norm`) mise en cache dans intelligence, liaison, doublons, ux-v100, recherche globale, devis-unique, tfl (≈ 0,5 s de CPU au démarrage).
- **Listes** (clients, chantiers, devis, stock, caisse) : 150 lignes affichées + bouton « Afficher plus », comptage des chantiers par client en O(n), recherche client retardée de 160 ms. Ouverture de l'onglet Clients : 719 ms → ≈ 180 ms ; frappe dans la recherche client : 248 ms → 48 ms.
- **Métré** : formateurs de nombres réutilisés (`Intl.NumberFormat`) ; une quantité modifiée dans un métré de 100 lignes coûte ≈ 5 ms au lieu de ≈ 12 ms de formatage seul.
- **Nouveau `exb-perf-base.js`** (chargé avant tout) : `Number.prototype.toLocaleString(langue, options)` réutilise un formateur par (langue + options) ; sortie identique (9 cas vérifiés), 30× plus rapide. Enregistré dans sw.js (cache `v144e-perf-…`).
- Les données ne sont pas modifiées par ces changements (affichage et calcul uniquement).
- Limites : mesures sur Chromium sans licence active (écran de verrouillage masqué pour le test) et sans réseau ; à confirmer sur le PC Windows avec Ctrl + Alt + T / Ctrl + Alt + L.
