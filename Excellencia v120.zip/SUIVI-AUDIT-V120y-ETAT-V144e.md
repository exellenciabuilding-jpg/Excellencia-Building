# Suivi de l'audit V120y — état dans la V144e

Légende : ✅ fait et vérifié en banc d'essai Chromium · 🟡 fait, à confirmer sur votre poste · ⏳ dépend d'une mesure chez vous

| Point de l'audit | État | Détail / preuve |
|---|---|---|
| 4.1 / P0 Dialogues natifs, rejeu de clic | ✅ | ≈ 55 appels migrés vers `await exbConfirm/exbPrompt`, rejeu supprimé. 2 `alert()` natifs volontaires (session expirée). Devis en double : « demande → réponse → enregistrement » sans exécution double (testé). |
| 4.2 Bouton `v77lift` (prompt 5,6 s) | ✅ | Plus de `prompt` dans `exb-v77.js` (formulaire intégré). |
| 4.3 / P2 Observateurs DOM | ✅ | v77 : ne traite que les nœuds ajoutés ; bigstore : idem, **et** ne se déconnecte plus (correction d'un défaut : photos affichées après le chargement gardaient un jeton `exbidb:`). Aucun balayage global. |
| 4.4 / P3 Démarrage | 🟡 | Mesuré : 16 tâches longues (max 289 ms, 3,5 s) → 8 (max 130 ms, 1,8 s) sur 800 clients / 400 chantiers / 1 500 écritures. `defer` en masse **non** appliqué (l'audit le déconseille : ordre des scripts). Chargement à la demande des modules secondaires : non fait, risque d'ordre ; à décider après vos mesures. |
| 4.5 / P4 IndexedDB | 🟡 | Lecture par curseur ; compaction seulement après 5 s sans saisie et au repos ; `EXBBIG.perf()` journalise lecture/écriture/compactage (≥ 300 ms → rapport de lenteur). Test stockage : photo 430 Ko compactée, plus de `data:` dans localStorage, restituée à l'écran après rechargement. |
| 4.6 / P5 Métré, FAB, listes | ✅ / 🟡 | Formateurs de nombres réutilisés ; listes limitées à 150 lignes + « Afficher plus » ; recherche client retardée. Métré : 10 lignes saisies → enregistrées → rechargement = valeurs identiques (testé). 100 lignes : ≈ 100 à 150 ms par modification (seuil audit 200 ms). |
| P1 Blocage « source inconnue » 4,8 s | ⏳ | Non reproduit ici. Diagnostic prêt (Ctrl + Alt + T puis Ctrl + Alt + L). |
| Seuil recherche < 300 ms | ✅ | 20 recherches successives : 280–292 ms anti-rebond compris. |
| Seuil tâche > 1 000 ms | ✅ | Aucune pendant le parcours testé. |
| Tests de réception Windows / Android, endurance 60 min, PDF avec photos | ⏳ | À faire chez vous (voir ci-dessous). |

## Après installation — ce qu'il faut m'envoyer
1. **Essai de 10 minutes** : Ctrl + Alt + T, travailler normalement (recherche, fiche client, devis, Métré), puis Ctrl + Alt + L → capture(s) du rapport.
2. **IndexedDB** : F12 → Console → `EXBBIG.perf()` → copier le résultat ; ajouter `EXBBIG.usage()`.
3. **Si un blocage persiste** : onglet Performance (F12), enregistrer pendant le blocage, exporter le profil (.json) ou capture.
4. **Matrice de réception** (cocher OK / KO + remarque) :
   - Recherche : client, projet, devis, apprenant, 20 fois de suite.
   - Fiche client : créer / modifier / annuler / enregistrer, saisie rapide puis lente, changement d'onglet.
   - Chantier : création (une seule), membres, étapes, notifications non bloquantes.
   - Équipement : QR, code manuel, annulation puis validation (caméra libérée).
   - Suppression : annuler (aucun effet), puis confirmer sur une copie.
   - Devis déjà existant (même client + projet) : « Mettre à jour » puis « Nouveau devis ».
   - Réception d'un bon de commande : saisie des quantités par ligne.
   - Métré : 100 lignes, modifier quantités/prix, enregistrer, fermer, rouvrir.
   - Images / plans : importer, attendre la compaction, fermer/rouvrir, **générer un PDF avec photo (fiche client, reçu)**, exporter et restaurer sur une copie.
   - Endurance 60 min, réseau coupé puis rétabli.
5. **Avant déploiement** : sauvegarde complète exportée, version précédente conservée (retour arrière).

## Point d'attention connu (non bloquant)
Les listes en mémoire (`exbClients`, etc.) peuvent contenir un jeton `exbidb:` tant qu'elles n'ont pas été relues ; l'affichage à l'écran est maintenant résolu automatiquement, mais **la génération de PDF/export directement depuis ces listes n'a pas pu être testée ici** : c'est le premier point à vérifier (photo sur fiche/reçu PDF).

## Consommation du forfait internet (signalée après l'audit)
Causes identifiées dans le code :
1. **Synchronisation en ligne (`exb-sync.js`)** : toutes les 60 s, 2 requêtes (licence + liste des clés du compte), en permanence, y compris application en arrière-plan ou rien de modifié. → V144e : aucune requête en arrière-plan ; vérification du serveur au plus toutes les 5 min quand rien n'a changé localement ; envoi dans la minute quand une donnée locale change ; reprise immédiate au retour au premier plan, au retour du réseau et via « Synchroniser ».
2. **Mises à jour de l'application** : chaque nouvelle version change le cache hors-ligne (`sw.js`, 282 fichiers, 13,6 Mo au total) ; le téléchargement dépend des fichiers modifiés (jusqu'à plusieurs Mo par appareil et par version). → Éviter d'installer chaque petite version sur les téléphones sur forfait ; regrouper les mises à jour.
3. **Envoi de données volumineuses** : toute clé modifiée est renvoyée en entier (ex. liste clients avec photos). Les photos lourdes augmentent le volume à chaque modification.
4. Météo de l'accueil : mise en cache, au plus 1 appel par période de rafraîchissement ; faible volume.
À vérifier chez vous : Paramètres Android / Windows → consommation de données par application, avant et après installation, pour confirmer le gain.

## Notification « Hors connexion — le renouvellement de session sera réessayé automatiquement » qui revient chaque minute
Cause : `exb-memoire.js` (alertes sonores des demandes en ligne) interroge la boîte de réception toutes les 60 s ; sans réseau, chaque échec de renouvellement de session créait une nouvelle notification identique (et la cloche se remplissait). Les requêtes de la boîte (4 listes + licence) partaient aussi chaque minute.
Correction V144e :
- aucune interrogation de la boîte de réception quand l'appareil est hors connexion (`exb-memoire.js`) ;
- erreur « hors connexion » de la boîte de réception : affichée dans le panneau seulement, sans notification flottante ;
- tout avertissement identique n'est notifié qu'une fois par 10 min (`say` dans index.html).
La pastille « Hors connexion · Dernière synchronisation » et l'unique notification de changement de réseau restent affichées normalement.
À vérifier chez vous : couper le Wi-Fi 3 minutes puis le rétablir → une seule notification « Hors connexion », puis « Connexion rétablie », sans répétition.
(Remarque : la capture indique « Version : V120 » en bas à gauche — vérifier que la V144e est bien celle qui s'exécute, après rechargement complet Ctrl + Maj + R.)

## Forfait internet — vérification approfondie (V144e v13)
Essai de blocages reçu (10 min) : 0 blocage ≥ 200 ms hors boîtes de dialogue.

Banc d'essai : session connectée simulée (serveur factice), horloge accélérée, requêtes comptées par type.
| | Origine (V120y/v6) | V144e v13 |
|---|---|---|
| Écran visible, 6 min | 146 requêtes (≈ 1 460 / h) | 14 requêtes (≈ 140 / h) |
| Arrière-plan, 6 min | — | 8 requêtes (≈ 80 / h) |

Causes trouvées et corrigées :
1. **`exb-equipe.js`** : « mon_organisation » demandé au serveur **toutes les 4 s, sans fin**, tant que le compte n'est pas administrateur d'entreprise (≈ 900 requêtes / h = la plus grosse consommation). → une vérification, puis 30 min (non-admin) ou 2 min (erreur) ; rien en arrière-plan ni hors connexion.
2. **`exb-sync.js`** : 2 requêtes / min en permanence → 5 min quand rien n'a changé, rien en arrière-plan.
3. **`exb-license.js`** : demande de l'heure du serveur (`auth/v1/health`) chaque minute → au plus toutes les 15 min.
4. **`exb-memoire.js`** : boîte de réception (licence + 4 listes) chaque minute, même hors connexion → rien hors connexion, 3 min en arrière-plan.
5. **Météo d'accueil** : après un échec, nouvel essai chaque minute → 10 min ; rien hors connexion.
6. Rechargements de boîte (écran Inscriptions…, surveillance IA) : plus de requête hors connexion ni en arrière-plan.
Limites : mesure avec serveur factice (taille des réponses estimée) ; la consommation réelle dépend de vos données. Comparer dans Windows : Paramètres › Réseau et Internet › Utilisation des données, par application, avant / après.

## Lot « affiches / modèles de documents » (V156 + V157, archive V120-v17) appliqué sur la V144e
- Seul fichier concerné : `exb-affiches-studio.js` (Studio libre : **235 modèles**, dont 189 nouveaux — 76 en V156 + 113 en V157 : lettres, attestations, documents commerciaux, chantier/technique, RH, fêtes, avis, marketing, 4 nouveaux formats).
- Fusion : fichier v17 repris en entier ; les 3 boîtes de dialogue natives (supprimer une affiche, remplacer par un modèle, nouvelle affiche) y ont été remplacées par `await exbConfirm` comme dans le reste de la V144e. Aucune ligne de la version précédente n'a été retirée.
- Cache hors-ligne (`sw.js`) : nom de version changé pour que les appareils récupèrent le nouveau fichier.
- Ajoutés : `README-V156-…`, `README-V157-…`, `tools/e2e-affiches-modeles.py`.
- Vérifié (Chromium) : les 235 modèles s'appliquent sans erreur JavaScript, aucun élément hors cadre ; démarrage et tests de la V144e inchangés.
- Non repris volontairement : `exb-recu-client.js` (reçu client V142c de l'archive v17) — la V144e contient déjà la suite V142c-V142e (`exb-v142c-recu-client.js`). Les autres fichiers de l'archive v17 sont des versions antérieures aux corrections d'audit et n'ont pas été importés.
- Non testé : impression réelle, téléphone ; contrats / mises en demeure = trames générales à faire valider par un juriste.

## Affiches : QR code vers le site vitrine
- Bouton « ＋ QR site » (Studio libre) : ajoute en bas de l'affiche, au-dessus du bandeau de contact, un vrai QR code qui ouvre le site vitrine (adresse réglée dans 🌐 Site vitrine › Adresses ; à défaut l'adresse par défaut du site).
- Le modèle « Scannez le QR code (A4) » reçoit automatiquement ce QR (plus de cadre vide).
- Ce QR n'a aucun lien avec la vérification des documents (reçus, certificats, devis) : celle-ci est inchangée.
- Studio : 16 nouveaux formats (A6, DL, A3 paysage, A2, A1, A0, Instagram 4:5, Pinterest 2:3, couvertures X/Facebook, statut WhatsApp, carré 20 cm, badge, bâches 3×1 m et 2×1 m, kakemono 100×200) + bouton « 📐 Format libre » (largeur × hauteur en cm).
- Studio : « 🔳 Affiche QR seul » (QR géant + SCANNEZ-MOI, adresse modifiable), « ⬇ QR seul (PNG) », et 14 modèles « QR seul » (7 formats × fond bleu/blanc).
- Filigrane : (1) Studio › Fond : case « Filigrane : mon logo en transparence derrière l'affiche » (visibilité et taille réglables), incluse dans les exports PNG/PDF ; (2) le filigrane d'écran de l'application utilise maintenant le logo de l'entreprise (identité) au lieu de celui d'Excellencia Building.
- Lot affiches v18 (338 modèles, README-V158) importé ; mes ajouts (QR site, formats, QR seul, filigrane) conservés : 352 modèles au total, aucun débordement ni erreur JS.
