# V142c — Reçu de paiement client à la disposition du modèle Excellencia Building, avec QR de vérification

## Ce qui change
- Nouveau `site/exb-v142c-recu-client.js` : génère le reçu en **une page A4** exactement dans la disposition de ton modèle : en-tête (logo, ARCHITECTURE • INGÉNIERIE • RÉALISATION, « L'excellence au cœur de vos constructions »), N° du reçu, date, agence/site, devise (FC / USD / Autre), **1. Informations du client**, **2. Objet du paiement** (motif Acompte / Avancement / Solde / Autre, cadre MONTANT REÇU + montant en toutes lettres), **3. Mode de paiement et situation** (Espèces / Virement / Mobile Money / Chèque / Autre, référence de transaction, total convenu, total payé avant, solde), **4. Confirmation**, blocs signature Client / Caisse-Représentant (signature et cachet de l'entreprise si le visa est configuré), mention « Important », pied de page WhatsApp + e-mail.
- **QR de vérification** en bas à droite : même registre et même page `verification.html` que les autres documents (type « Reçu »). Le reçu est inscrit au registre au moment de la génération.
- `site/exb-v99zy-portails.js` : « 🧾 Générer et envoyer le reçu » utilise ce nouveau reçu (l'ancien moteur reste en repli si le module est absent).
- `site/index.html` (chargement du module), `site/sw.js` (cache v156).

## Remplissage automatique
- Client, projet, facture, montant confirmé, mode, référence + n° de transaction, date : repris du paiement déclaré et confirmé.
- Mode : caisse → Espèces, banque → Virement, Mobile Money → Mobile Money, autre → Autre.
- Montant total convenu = total TTC de la facture indiquée (même devise) ; total payé avant = paiements déjà confirmés du client pour cette facture ; solde = total − déjà payé − ce paiement. Si la facture n'est pas retrouvée, ces trois lignes restent vides (à compléter à la main après impression).
- Motif : Solde si le solde est nul, Avancement s'il y a eu un paiement avant, sinon Acompte.

## Parcours (inchangé)
Le client déclare sa référence → tu confirmes (🔗 Portails & signatures › 💳 Paiements) → 🧾 Générer et envoyer le reçu → le reçu apparaît dans l'espace du client (Plans & Documents › Reçus) et il le télécharge.

## Déploiement
Redéployer `site` sur Netlify, rouvrir le logiciel (cache v156). Aucun nouveau SQL (la migration v142b suffit ; le registre de vérification vient de migration-v99m).

## Vérifié
- `node tools/check.js` : 557 contrôles réussis, 0 échec.
- Reçu généré (USD et FC, noms longs, totaux vides) : 1 page, mise en page contrôlée à l'écran ; QR relu avec un décodeur et il donne bien le lien de vérification.
- Montant en lettres testé (21, 71, 80, 91, 280 000, 1 000 000, etc.).

## Non testé / limites
- Pas testé dans ton vrai logiciel ouvert dans le navigateur, ni avec ton Supabase, ni sur téléphone.
- Le champ « Agence / site » et le nom du caissier restent vides (à remplir à la main) ; aucune donnée source dans le logiciel.
- Le matricule client n'apparaît que si la fiche client en contient un.
