/* Excellencia Building V81 — socle commun des modules Architecture & Gestion (pièces écrites, plans CAO, autorisations, paie/RH).
 * Fournit : utilitaires, fenêtre modale, impression PDF, boutons du menu Administration. Chaque module garde son propre stockage (EXBS). */
(function(w,d){'use strict';
var C=w.EXB81={};
C.esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
C.say=function(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}};
C.can=function(col,a){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(col,a)}catch(e){return true}};
C.uid=function(p){return p+'-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6)};
C.today=function(){var t=new Date();return t.getFullYear()+'-'+('0'+(t.getMonth()+1)).slice(-2)+'-'+('0'+t.getDate()).slice(-2)};
C.frDate=function(s){var m=/^(\d{4})-(\d\d)-(\d\d)/.exec(s||'');return m?m[3]+'/'+m[2]+'/'+m[1]:(s||'')};
C.daysTo=function(s){if(!s)return null;var a=new Date(C.today()+'T00:00:00'),b=new Date(s+'T00:00:00');return Math.round((b-a)/864e5)};
C.num=function(v){var n=Number(String(v==null?'':v).replace(',','.'));return isNaN(n)?0:n};
C.projs=function(){try{return w.EXBS.projects()}catch(e){return[]}};
C.pn=function(id){var p=C.projs().find(function(x){return String(x.id)===String(id)});return p?(p.nom||p.name||p.titre||p.title||p.code||id):(id||'')};
C.firstProject=function(){var P=C.projs();return localStorage.getItem('exb_active_project')||(P[0]&&P[0].id)||''};
C.brand=function(){return (w.EXB_BRAND&&w.EXB_BRAND.name)||'Excellencia Building'};
C.cart=function(pid){var a=[];try{a=w.EXBS.get('exb_cartouches')}catch(e){}return a.find(function(x){return String(x.project)===String(pid)})||{}};
C.phase=function(pid){var P=[];try{P=w.EXBS.get('exb_phases').filter(function(x){return x.type==='phase'&&String(x.project)===String(pid)})}catch(e){}var e=P.find(function(x){return x.status==='en cours'})||P.slice().reverse().find(function(x){return x.status!=='à faire'});return e?e.name:''};
C.fx=function(){try{var t=(w.EXBS.get('exb_finance')||[]).filter(function(x){return x.type==='taux'&&x.rate>0}).sort(function(a,b){return a.date<b.date?-1:1});return t.length?t[t.length-1].rate:0}catch(e){return 0}};
C.money=function(n,c){var u=c==='FC';return new Intl.NumberFormat('fr-FR',{minimumFractionDigits:u?0:2,maximumFractionDigits:u?0:2}).format(n||0)+(u?' FC':' $')};
C.projSelect=function(fn,pid){return '<select onchange="'+fn+'(this.value)" style="padding:8px;max-width:100%">'+C.projs().map(function(p){return '<option value="'+C.esc(p.id)+'"'+(String(p.id)===String(pid)?' selected':'')+'>'+C.esc(C.pn(p.id))+'</option>'}).join('')+'</select>'};
C.overlay=function(id,title,body,maxw){var o=d.getElementById(id);if(!o){o=d.createElement('div');o.id=id;o.style.cssText='position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';o.onclick=function(e){if(e.target===o)o.remove()};d.body.appendChild(o)}
 o.innerHTML='<div style="background:#fff;border-radius:14px;padding:16px;max-width:'+(maxw||860)+'px;width:100%;font:14px Arial;color:#172033"><div style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:17px">'+title+'</b><button onclick="document.getElementById(\''+id+'\').remove()">✕</button></div>'+body+'</div>';return o};
C.kpis=function(a){return '<div style="display:flex;flex-wrap:wrap;gap:6px;margin:8px 0">'+a.map(function(x){return '<div style="flex:1 1 30%;background:'+(x[2]||'#f1f5fb')+';border-radius:10px;padding:8px"><div style="font-size:12px;color:#64748b">'+x[0]+'</div><b>'+x[1]+'</b></div>'}).join('')+'</div>'};
C.field=function(id,label,val,type,w2){return '<label style="flex:1 1 '+(w2||45)+'%;font-size:12px">'+label+'<br><input id="'+id+'" type="'+(type||'text')+'"'+(type==='number'?' step="any"':'')+' value="'+C.esc(val==null?'':val)+'" style="width:100%;padding:7px;box-sizing:border-box"></label>'};
C.val=function(id){var e=d.getElementById(id);return e?e.value.trim():''};
/* petit moteur de mise en forme : « # titre », « ## sous-titre », « - puce », « | a | b | » (tableau), sinon paragraphe */
C.render=function(txt){var out=[],tb=[],ul=0;function fl(){if(tb.length){out.push('<table>'+tb.map(function(r,i){return '<tr>'+r.map(function(c){return '<'+(i===0?'th':'td')+'>'+C.esc(c.trim())+'</'+(i===0?'th':'td')+'>'}).join('')+'</tr>'}).join('')+'</table>');tb=[]}if(ul){out.push('</ul>');ul=0}}
 String(txt||'').split(/\r?\n/).forEach(function(l){if(/^\s*\|/.test(l)){if(ul){out.push('</ul>');ul=0}tb.push(l.replace(/^\s*\||\|\s*$/g,'').split('|'));return}fl();
  if(/^##\s/.test(l))out.push('<h3>'+C.esc(l.slice(3))+'</h3>');else if(/^#\s/.test(l))out.push('<h2>'+C.esc(l.slice(2))+'</h2>');else if(/^\s*-\s/.test(l)){if(!ul){out.push('<ul>');ul=1}out.push('<li>'+C.esc(l.replace(/^\s*-\s/,''))+'</li>')}else if(l.trim()){out.push('<p>'+C.esc(l)+'</p>')}});fl();return out.join('')};
C.logo=function(){try{var l=localStorage.getItem('exb_logo')||localStorage.getItem('rdc_logo')||'';if(/^data:image/.test(l))return l}catch(e){}return new URL('icon-192.png',location.href).href};
C.printDoc=function(title,html,landscape){return w.EXBPrint.html(title,'<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>'+C.esc(title)+'</title><style>@page{size:A4'+(landscape?' landscape':'')+';margin:14mm}html,body{margin:0;font:11pt/1.45 Arial,sans-serif;color:#111}.pg{max-width:190mm;margin:0 auto;padding:6mm}h1{font-size:16pt;color:#173565;margin:0 0 4px}h2{font-size:13pt;color:#173565;border-bottom:1px solid #173565;margin:16px 0 6px;padding-bottom:2px}h3{font-size:11.5pt;margin:12px 0 4px}table{border-collapse:collapse;width:100%;margin:6px 0}td,th{border:1px solid #777;padding:4px 6px;font-size:10pt;vertical-align:top;text-align:left}th{background:#e8edf5}.hd{display:flex;align-items:center;gap:12px;border-bottom:2px solid #c49a38;padding-bottom:8px;margin-bottom:12px}.hd img{height:48px}.mut{color:#555;font-size:9.5pt}.sg{display:flex;gap:30px;margin-top:40px}.sg div{flex:1;border-top:1px solid #111;padding-top:4px;font-size:10pt}.r{text-align:right}.bar{position:fixed;top:8px;right:8px;background:#fff;padding:6px;box-shadow:0 2px 10px #777}@media print{.bar{display:none}}</style></head><body><div class="pg">'+html+'</div></body></html>',{landscape:!!landscape})};
C.header=function(sub){return '<div class="hd"><img src="'+C.esc(C.logo())+'" alt=""><div><b style="font-size:14pt;color:#173565">'+C.esc(C.brand())+'</b><div class="mut">'+C.esc(sub||'')+'</div></div></div>'};
/* ajoute un bouton dans le menu, à côté des autres boutons d'administration */
C.addButton=function(id,label,fn,col){function ui(){var b=d.getElementById('badm');if(!b||d.getElementById(id))return;var k=d.createElement('button');k.id=id;k.className='muted';k.textContent=label;k.onclick=fn;if(col&&!C.can(col,'lire'))k.setAttribute('data-exbrole','hide');b.parentNode.appendChild(k)}
 if(typeof MutationObserver==='undefined')return;new MutationObserver(ui).observe(d.documentElement,{childList:true,subtree:true});d.addEventListener('DOMContentLoaded',ui);ui()};
})(window,document);
