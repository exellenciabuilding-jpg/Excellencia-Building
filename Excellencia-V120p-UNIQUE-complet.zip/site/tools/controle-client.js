#!/usr/bin/env node
/* V120j — Contrôle avant livraison à un client : liste ce qui pointe encore vers VOS services (serveur de données, adresse publique, WhatsApp, vitrine).
 * Usage :  node tools/controle-client.js [dossier-du-site]   → code de sortie 1 s'il reste des points à traiter. */
const fs = require('fs'), path = require('path');
const root = path.resolve(process.argv[2] || path.join(__dirname, '..'));
const rd = f => { try { return fs.readFileSync(path.join(root, f), 'utf8'); } catch (e) { return null; } };
const V = { supabase: 'tqzqkejgkdvznivzsdnq', host: 'excellenciabuildingsarlu01', wa: '243810644554', mail: 'excellenciabuilding@gmail.com' };
const todo = [], ok = [];
const chk = (cond, okMsg, todoMsg) => (cond ? ok.push(okMsg) : todo.push(todoMsg));

let ent = null; try { ent = JSON.parse(rd('entreprise.json') || 'null'); } catch (e) {}
const name = ent && (ent.name || ent.nom || (ent.brand && ent.brand.name));
chk(!!name, 'entreprise.json : identité du client renseignée (' + name + ')', 'entreprise.json : vide → remplacez-le par le fichier téléchargé dans Paramètres › Identité de l’entreprise');

const sc = rd('supabase-config.js') || '';
const ownSb = !!(ent && (ent.supabaseUrl || (ent.brand && ent.brand.supabaseUrl)) && !String(ent.supabaseUrl || (ent.brand || {}).supabaseUrl).includes(V.supabase));
chk(!sc.includes(V.supabase) || ownSb, 'supabase-config.js : pas de serveur de données du fournisseur (ou serveur propre au client dans entreprise.json)',
  'supabase-config.js : contient VOTRE projet Supabase → les données en ligne du client iraient chez vous. Videz url/key (mode local) ou donnez au client son propre projet (entreprise.json).');

const bc = rd('brand-config.js') || '';
chk(!bc.toLowerCase().includes(V.host) || !!(ent && (ent.publicUrl || (ent.brand && ent.brand.publicUrl))), 'brand-config.js : adresse publique du fournisseur absente ou remplacée',
  'brand-config.js : EXB_PUBLIC_URL pointe vers votre site → renseignez l’adresse publique du client (Identité › Adresse publique). Sans elle, le logiciel n’envoie aucun lien vers votre site.');
chk(/setupRequired\s*:\s*false/.test(bc) || !name, 'brand-config.js : écran de configuration réglé', 'brand-config.js : mettez setupRequired:false une fois entreprise.json rempli, sinon le client voit l’écran de configuration');

let vc = null; try { vc = JSON.parse(rd('site-vitrine/config.json') || 'null'); } catch (e) {}
if (vc) {
  const s = JSON.stringify(vc).toLowerCase();
  chk(!(s.includes(V.host) || s.includes(V.wa) || s.includes(V.supabase)), 'site-vitrine/config.json : propre au client',
    'site-vitrine/config.json : contient VOTRE adresse, WhatsApp ou stockage (logiciel_url / whatsapp / remote) → remplacez par ceux du client avant de publier la vitrine.');
}
const man = rd('manifest.webmanifest') || rd('manifest.json') || '';
if (man) chk(!/excellencia/i.test(man) || !name, 'manifeste : nom neutre ou client', 'manifeste : porte encore « Excellencia » (nom de l’appli installée) → lancez `npm run brand` pour la version Android/Windows');

console.log('Contrôle livraison client —', root);
ok.forEach(m => console.log('  ✓', m)); todo.forEach(m => console.log('  ✗', m));
console.log(todo.length ? '\n' + todo.length + ' point(s) à traiter avant livraison.' : '\nPrêt à livrer.');
process.exit(todo.length ? 1 : 0);
