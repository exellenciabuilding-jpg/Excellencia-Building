# Serveur de licences Excellencia (V120o) — à installer une seule fois

Un seul serveur, dans **votre** compte Supabase, pour tous vos clients. Il enregistre les appareils (2 par client par défaut), vérifie les abonnements, signe les licences. Les clients n'y ont aucun accès direct.

## Installation (≈ 10 minutes)
1. Créez un projet Supabase **pour les licences** (distinct de ceux des clients). Notez sa *référence* (`abcdefgh` dans `https://abcdefgh.supabase.co`).
2. Sur votre PC (Node 20+) : `node licence-server/setup.js init --mdp "un mot de passe fort" --ref abcdefgh --contact "Excellencia · +243…"`
   - avec `SUPABASE_ACCESS_TOKEN` défini, le script crée les tables et dépose les secrets ; sinon il affiche les 3 commandes à lancer.
3. Déployez la fonction : `cd licence-server && npx supabase functions deploy licence --project-ref abcdefgh --no-verify-jwt`
4. Testez : `curl -s -X POST https://abcdefgh.supabase.co/functions/v1/licence -H "Content-Type: application/json" -d '{"action":"ping"}'` → `"ok":true`.
5. Commitez `licence-serveur.json` (adresse + clé **publique**, sans secret). Les workflows APK, EXE et Netlify le reprennent automatiquement.
6. Installez **Excellencia Licences** (workflow GitHub « Application propriétaire (EXE) ») et saisissez l'adresse + la clé de `ADMIN-KEY-LICENCES.txt`.

## À sauvegarder (2 supports) — ne jamais mettre sur GitHub
`SAUVEGARDE-CLE-SERVEUR-LICENCES.json` (+ son mot de passe) et `ADMIN-KEY-LICENCES.txt`. Perdre la clé du serveur obligerait à relivrer tous les clients. Clé d'administration perdue ou divulguée : `node licence-server/setup.js new-admin-key`.

## Fonctionnement
- Activation : le client saisit `EXC-XXXX-XXXX-XXXX` ; l'appareil s'inscrit (limite atomique) et reçoit une licence signée (échéance, 7 jours hors ligne).
- Vérification : toutes les 30 min en ligne ; renouvellement de l'échéance, suspension, révocation et appareil libéré s'appliquent à la vérification suivante.
- Brute-force : 10 codes faux / 15 min / adresse, puis blocage temporaire.
- Réglages (secrets Supabase facultatifs) : `LICENCE_OFFLINE_DAYS` (7), `LICENCE_DEFAULT_DEVICES` (2).

## Tests (sans Supabase)
`node licence-server/tests/core.test.mjs` · `node scripts/test-licence.js` · `node licence-server/tests/provisioning.test.mjs` · `NODE_PATH=$(npm root -g) node licence-server/tests/e2e-owner.mjs` (navigateur).
