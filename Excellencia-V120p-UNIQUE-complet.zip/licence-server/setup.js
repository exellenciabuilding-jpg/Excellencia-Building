#!/usr/bin/env node
/* Excellencia — installation du SERVEUR DE LICENCES (V120o), à faire une seule fois, sur VOTRE ordinateur.
 *
 *   node licence-server/setup.js init --mdp "mot de passe de sauvegarde" --ref <référence du projet Supabase> [--contact "Excellencia · +243…"]
 *   node licence-server/setup.js export-secrets --mdp "…"        (recrée supabase-secrets.env depuis la sauvegarde chiffrée)
 *
 * init :
 *   1. génère la paire de clés du serveur (ECDSA P-256) et la clé d'administration (celle de l'application propriétaire) ;
 *   2. écrit SAUVEGARDE-CLE-SERVEUR-LICENCES.json (clé privée chiffrée par votre mot de passe), ADMIN-KEY-LICENCES.txt et licence-server/supabase-secrets.env  → tous trois ignorés par git ;
 *   3. écrit licence-serveur.json (adresse du serveur + clé PUBLIQUE) : repris par les APK, EXE et sites des clients ;
 *   4. avec --ref et SUPABASE_ACCESS_TOKEN : crée les tables (schema.sql) et dépose les secrets dans le projet. Sinon, affiche les 3 commandes à lancer à la main.
 * La clé privée du serveur ne quitte jamais votre ordinateur et le secret Supabase du serveur ; elle n'est jamais livrée à un client. */
'use strict';
const fs = require('fs'), path = require('path'), { webcrypto: wc } = require('crypto');
const root = path.join(__dirname, '..'), here = __dirname;
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : d; };
const die = (m) => { console.error('\nERREUR : ' + m + '\n'); process.exit(1); };
const b64 = (b) => Buffer.from(b).toString('base64'), b64u = (b) => Buffer.from(b).toString('base64url');
const BACKUP = path.join(root, 'SAUVEGARDE-CLE-SERVEUR-LICENCES.json'), ADMIN_FILE = path.join(root, 'ADMIN-KEY-LICENCES.txt'), ENV_FILE = path.join(here, 'supabase-secrets.env');

async function encrypt(text, pass) {
  const salt = wc.getRandomValues(new Uint8Array(16)), iv = wc.getRandomValues(new Uint8Array(12)), iter = 250000;
  const m = await wc.subtle.importKey('raw', Buffer.from(pass), 'PBKDF2', false, ['deriveKey']);
  const k = await wc.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, m, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
  return { salt: b64(salt), iv: b64(iv), iter, data: b64(await wc.subtle.encrypt({ name: 'AES-GCM', iv }, k, Buffer.from(text))) };
}
async function decrypt(f, pass) {
  const u = (x) => Buffer.from(x, 'base64'), m = await wc.subtle.importKey('raw', Buffer.from(pass), 'PBKDF2', false, ['deriveKey']);
  const k = await wc.subtle.deriveKey({ name: 'PBKDF2', salt: u(f.salt), iterations: f.iter || 250000, hash: 'SHA-256' }, m, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  try { return Buffer.from(await wc.subtle.decrypt({ name: 'AES-GCM', iv: u(f.iv) }, k, u(f.data))).toString(); } catch (e) { die('Mot de passe incorrect ou sauvegarde modifiée.'); }
}
const sha256hex = async (t) => Buffer.from(await wc.subtle.digest('SHA-256', Buffer.from(t))).toString('hex');
const envFile = (jwk, hash) => '# Secrets du serveur de licences — NE JAMAIS METTRE SUR GITHUB\nLICENCE_SIGNING_JWK=\'' + JSON.stringify(jwk) + '\'\nLICENCE_ADMIN_KEY_HASH=' + hash + '\n';

async function init() {
  const pass = arg('mdp') || process.env.EXB_CLE_MDP; if (!pass || pass.length < 8) die('Choisissez un mot de passe de sauvegarde d\'au moins 8 caractères : --mdp "…"');
  if (fs.existsSync(BACKUP) && !process.argv.includes('--force')) die('Un serveur est déjà initialisé (' + path.basename(BACKUP) + '). Changer de clé rendrait TOUTES les licences déjà livrées invalides. Relancez avec --force seulement si c\'est voulu.');
  const kp = await wc.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const priv = await wc.subtle.exportKey('jwk', kp.privateKey), pub = await wc.subtle.exportKey('jwk', kp.publicKey);
  const adminKey = 'adm_' + b64u(wc.getRandomValues(new Uint8Array(32))), hash = await sha256hex(adminKey);
  fs.writeFileSync(BACKUP, JSON.stringify(Object.assign({ app: 'excellencia-licence-serveur', v: 1, pub: { kty: 'EC', crv: 'P-256', x: pub.x, y: pub.y } }, await encrypt(JSON.stringify(priv), pass)), null, 2));
  fs.writeFileSync(ADMIN_FILE, adminKey + '\n');
  fs.writeFileSync(ENV_FILE, envFile(priv, hash));
  const ref = arg('ref'), url = arg('url', ref ? 'https://' + ref + '.supabase.co/functions/v1/licence' : '');
  const jp = path.join(root, 'licence-serveur.json'); let j = {}; try { j = JSON.parse(fs.readFileSync(jp, 'utf8')); } catch (e) { /* neuf */ }
  j.url = url; j.pub = { kty: 'EC', crv: 'P-256', x: pub.x, y: pub.y }; if (arg('contact')) j.contact = arg('contact');
  fs.writeFileSync(jp, JSON.stringify(j, null, 2) + '\n');
  console.log('\n✔ Clés créées.\n  · SAUVEGARDE-CLE-SERVEUR-LICENCES.json  (clé privée chiffrée — GARDEZ-LA sur 2 supports ; sans elle et sans le projet Supabase, il faudrait relivrer tous les clients)\n  · ADMIN-KEY-LICENCES.txt                (clé à saisir dans l\'application propriétaire)\n  · licence-server/supabase-secrets.env   (à envoyer à Supabase puis à supprimer)\n  · licence-serveur.json                  (public : adresse + clé publique ; à commiter)');

  const tok = process.env.SUPABASE_ACCESS_TOKEN;
  if (ref && tok) {
    const api = async (m, p, b) => { const r = await fetch('https://api.supabase.com' + p, { method: m, headers: { Authorization: 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined }); const t = await r.text(); if (!r.ok) throw new Error(m + ' ' + p + ' → ' + r.status + ' ' + t.slice(0, 200)); return t; };
    try {
      await api('POST', '/v1/projects/' + ref + '/database/query', { query: fs.readFileSync(path.join(here, 'schema.sql'), 'utf8') }); console.log('  ✔ Tables créées dans le projet ' + ref + '.');
      await api('POST', '/v1/projects/' + ref + '/secrets', [{ name: 'LICENCE_SIGNING_JWK', value: JSON.stringify(priv) }, { name: 'LICENCE_ADMIN_KEY_HASH', value: hash }]); console.log('  ✔ Secrets déposés (vous pouvez supprimer licence-server/supabase-secrets.env).');
    } catch (e) { console.error('  ⚠ Étape automatique échouée : ' + e.message + '\n    Faites-la à la main (ci-dessous).'); }
  } else if (ref) console.log('\n  (SUPABASE_ACCESS_TOKEN absent : étapes manuelles ci-dessous.)');
  console.log('\nÀ lancer ensuite' + (ref ? '' : ' (remplacez <REF> par la référence de votre projet Supabase)') + ' :\n  1. Supabase › SQL Editor : coller licence-server/schema.sql › Run   (inutile si fait automatiquement)\n  2. cd licence-server && npx supabase secrets set --env-file supabase-secrets.env --project-ref ' + (ref || '<REF>') + '   (inutile si fait automatiquement)\n  3. cd licence-server && npx supabase functions deploy licence --project-ref ' + (ref || '<REF>') + ' --no-verify-jwt\n  4. Test : curl -s -X POST ' + (url || 'https://<REF>.supabase.co/functions/v1/licence') + ' -H "Content-Type: application/json" -d \'{"action":"ping"}\'');
}
async function exportSecrets() {
  const pass = arg('mdp') || process.env.EXB_CLE_MDP; if (!pass) die('--mdp "mot de passe" requis.');
  const f = JSON.parse(fs.readFileSync(BACKUP, 'utf8')); const priv = JSON.parse(await decrypt(f, pass));
  const adminKey = fs.existsSync(ADMIN_FILE) ? fs.readFileSync(ADMIN_FILE, 'utf8').trim() : null; if (!adminKey) die('ADMIN-KEY-LICENCES.txt introuvable : relancez « init » n\'est PAS nécessaire, mais il faut votre clé d\'administration (ou en créer une nouvelle : node licence-server/setup.js new-admin-key).');
  fs.writeFileSync(ENV_FILE, envFile(priv, await sha256hex(adminKey))); console.log('✔ ' + ENV_FILE + ' recréé.');
}
async function newAdminKey() {
  const adminKey = 'adm_' + b64u(wc.getRandomValues(new Uint8Array(32))), hash = await sha256hex(adminKey);
  fs.writeFileSync(ADMIN_FILE, adminKey + '\n');
  console.log('✔ Nouvelle clé d\'administration écrite dans ADMIN-KEY-LICENCES.txt.\n  Déclarez-la au serveur : npx supabase secrets set LICENCE_ADMIN_KEY_HASH=' + hash + ' --project-ref <REF>\n  (l\'ancienne clé cesse de fonctionner ; saisissez la nouvelle dans l\'application propriétaire)');
}
const cmd = process.argv[2];
(cmd === 'init' ? init() : cmd === 'export-secrets' ? exportSecrets() : cmd === 'new-admin-key' ? newAdminKey() : Promise.reject(new Error('Usage : node licence-server/setup.js init | export-secrets | new-admin-key')))
  .catch((e) => die(e.stack || e.message));
