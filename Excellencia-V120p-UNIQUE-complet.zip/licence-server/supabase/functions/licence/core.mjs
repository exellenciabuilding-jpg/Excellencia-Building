/* Excellencia — serveur de licences : logique métier (V120o).
 * Aucune dépendance : s'exécute dans une fonction Supabase (Deno) comme dans Node (tests).
 * La base de données et la signature sont injectées (voir index.ts, postgrest.mjs et les tests). */

const ALPHA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';           // 31 caractères, sans 0/O/1/I/L
const DAY = 864e5;
const b64u = (buf) => { let s = ''; const b = new Uint8Array(buf); for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const hex = (buf) => [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, '0')).join('');
export const sha256 = async (txt) => hex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(txt)));
const slugify = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);
const fmtDev = (d) => d.replace(/(.{4})(?=.)/g, '$1-');
export const normDevice = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const normCode = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const isCode = (v) => /^EXC[A-Z0-9]{12}$/.test(normCode(v));
const fmtCode = (n) => 'EXC-' + n.slice(3).replace(/(.{4})(?=.)/g, '$1-');
const same = (a, b) => { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; };

export function newCode(randomBytes = (n) => crypto.getRandomValues(new Uint8Array(n))) {
  const r = randomBytes(12); let s = '';
  for (let i = 0; i < 12; i++) s += ALPHA[r[i] % ALPHA.length];        // 31 ≈ biais négligeable pour un code aléatoire de 59 bits
  return fmtCode('EXC' + s);
}

/** Crée le gestionnaire. options : { db, sign(payloadObj)->token, adminKeyHash, now?, offlineDays?, defaultMax?, maxFailures? } */
export function createHandler(o) {
  const db = o.db, now = o.now || (() => new Date());
  const OFFLINE = o.offlineDays || 7, DEFMAX = o.defaultMax || 2, MAXFAIL = o.maxFailures || 10;
  const ok = (body, status = 200) => ({ status, body: Object.assign({ ok: true, now: now().toISOString() }, body) });
  const ko = (raison, msg, status = 200, extra = {}) => ({ status, body: Object.assign({ ok: false, raison, msg, now: now().toISOString() }, extra) });

  async function token(c, device) {
    const cfg = c.config || {};
    const p = { v: 2, cid: c.id, name: c.nom, exp: new Date(c.expire_le).toISOString(), grace: c.grace_jours, dev: [fmtDev(device)], iat: now().toISOString(), off: OFFLINE, id: String(c.id).slice(0, 7) };
    if (cfg.brand) p.brand = cfg.brand;
    if (cfg.srv && cfg.srv.url && cfg.srv.key) p.srv = cfg.srv;
    return o.sign(p);
  }
  const blocked = (c) => c.statut === 'suspendu'
    ? ko('suspendu', 'Votre licence est suspendue. Contactez l’administrateur du logiciel.')
    : c.statut === 'revoque' ? ko('revoque', 'Votre licence a été révoquée. Contactez l’administrateur du logiciel.') : null;

  /* ---------- public : activation par code ---------- */
  async function activate(b, ctx) {
    const ip = String(ctx.ip || 'inconnue').slice(0, 64);
    if ((await db.failures(ip, new Date(now().getTime() - 15 * 60000).toISOString())) >= MAXFAIL)
      return ko('trop_de_tentatives', 'Trop de tentatives. Réessayez dans 15 minutes.', 429);
    const device = normDevice(b.device);
    if (!/^[A-Z2-9]{12}$/.test(device)) return ko('appareil_invalide', 'Identifiant d’appareil invalide.', 400);
    if (!isCode(b.code)) { await db.addFailure(ip); return ko('code_invalide', 'Code d’activation invalide. Il ressemble à EXC-XXXX-XXXX-XXXX.'); }
    const c = await db.clientByHash(await sha256(normCode(b.code)));
    if (!c) { await db.addFailure(ip); return ko('code_invalide', 'Code d’activation inconnu. Vérifiez votre saisie.'); }
    const bl = blocked(c); if (bl) { await db.log(c.id, 'activation_refusee', { raison: c.statut, device }); return bl; }
    const exp = new Date(c.expire_le).getTime();
    if (exp + c.grace_jours * DAY <= now().getTime()) return ko('expire', 'Votre abonnement est expiré. Contactez l’administrateur pour le renouveler.', 200, { exp: new Date(exp).toISOString() });
    const r = await db.register(c.id, device, { libelle: String(b.label || '').slice(0, 80) || null, plateforme: String(b.platform || '').slice(0, 20) || null, version: String(b.version || '').slice(0, 20) || null });
    if (!r.ok && r.raison === 'limite') {
      await db.log(c.id, 'activation_refusee', { raison: 'limite', device, n: r.n, max: r.max });
      return ko('limite_appareils', 'Cette licence est déjà utilisée sur ' + r.max + ' appareil' + (r.max > 1 ? 's' : '') + '. Contactez l’administrateur pour libérer un appareil.', 200, { max: r.max });
    }
    if (!r.ok) return ko(r.raison || 'erreur', 'Activation impossible.');
    if (!r.deja) await db.log(c.id, 'appareil_enregistre', { device, n: r.n, max: r.max, plateforme: b.platform || null });
    return ok({ jeton: await token(c, device), exp: new Date(exp).toISOString(), appareils: { n: r.n, max: r.max }, nom: c.nom });
  }

  /* ---------- public : vérification périodique ---------- */
  async function check(b) {
    const device = normDevice(b.device);
    if (!/^[0-9a-f-]{36}$/i.test(String(b.cid || '')) || !/^[A-Z2-9]{12}$/.test(device)) return ko('requete_invalide', 'Requête invalide.', 400);
    const c = await db.client(b.cid);
    if (!c) return ko('inconnu', 'Licence introuvable. Saisissez à nouveau votre code d’activation.');
    const bl = blocked(c); if (bl) return bl;
    const r = await db.touch(c.id, device, String(b.version || '').slice(0, 20) || null);
    if (!r) return ko('appareil_inconnu', 'Cet appareil n’est plus enregistré sur votre licence. Saisissez votre code d’activation.');
    return ok({ jeton: await token(c, device), exp: new Date(c.expire_le).toISOString(), statut: c.statut });
  }

  /* ---------- propriétaire ---------- */
  const ADMIN = {
    async list() { return ok({ clients: await db.listClients() }); },
    async create(b) {
      const nom = String(b.nom || '').trim(); if (!nom) return ko('nom_requis', 'Le nom du client est obligatoire.', 400);
      const slug = slugify(b.slug || nom); if (!slug) return ko('nom_invalide', 'Nom invalide.', 400);
      if (await db.clientBySlug(slug)) return ko('slug_existe', 'Un client « ' + slug + ' » existe déjà.', 409);
      const max = b.max_appareils == null ? DEFMAX : Number(b.max_appareils); if (!(max >= 1 && max <= 10)) return ko('max_invalide', 'Appareils : entre 1 et 10.', 400);
      const grace = b.grace_jours == null ? 7 : Number(b.grace_jours); if (!(grace >= 0 && grace <= 365)) return ko('grace_invalide', 'Tolérance : 0 à 365 jours.', 400);
      let exp; if (b.expire_le) { exp = new Date(b.expire_le); } else { exp = new Date(now().getTime() + Number(b.jours || 365) * DAY); exp.setUTCHours(23, 59, 0, 0); }
      if (isNaN(exp)) return ko('date_invalide', 'Date d’échéance invalide.', 400);
      const code = newCode(o.randomBytes);
      const row = await db.insertClient({ slug, nom, statut: 'actif', expire_le: exp.toISOString(), grace_jours: grace, max_appareils: max, code_hash: await sha256(normCode(code)), code_fin: code.slice(-4), config: b.config && typeof b.config === 'object' ? b.config : {}, notes: b.notes || null });
      await db.log(row.id, 'cree', { expire_le: row.expire_le, max_appareils: max });
      return ok({ client: row, code }, 201);
    },
    async update(b) {
      const c = await db.client(b.id); if (!c) return ko('inconnu', 'Client introuvable.', 404);
      const p = b.patch || {}, patch = {};
      if (p.nom != null) patch.nom = String(p.nom).trim() || c.nom;
      if (p.notes !== undefined) patch.notes = p.notes;
      if (p.grace_jours != null) { const g = Number(p.grace_jours); if (!(g >= 0 && g <= 365)) return ko('grace_invalide', 'Tolérance : 0 à 365 jours.', 400); patch.grace_jours = g; }
      if (p.max_appareils != null) { const m = Number(p.max_appareils); if (!(m >= 1 && m <= 10)) return ko('max_invalide', 'Appareils : entre 1 et 10.', 400); patch.max_appareils = m; }
      if (p.statut != null) { if (!['actif', 'suspendu', 'revoque'].includes(p.statut)) return ko('statut_invalide', 'Statut invalide.', 400); patch.statut = p.statut; }
      if (p.expire_le != null) { const d = new Date(p.expire_le); if (isNaN(d)) return ko('date_invalide', 'Date invalide.', 400); patch.expire_le = d.toISOString(); }
      if (p.config && typeof p.config === 'object') patch.config = Object.assign({}, c.config || {}, p.config);
      if (!Object.keys(patch).length) return ko('rien', 'Rien à modifier.', 400);
      const row = await db.updateClient(c.id, patch);
      await db.log(c.id, patch.statut && patch.statut !== c.statut ? 'statut_' + patch.statut : 'modifie', patch);
      return ok({ client: row });
    },
    async renew(b) {
      const c = await db.client(b.id); if (!c) return ko('inconnu', 'Client introuvable.', 404);
      const j = Number(b.jours); if (!(j > 0 && j <= 3660)) return ko('duree_invalide', 'Durée invalide.', 400);
      const from = Math.max(now().getTime(), new Date(c.expire_le).getTime()); const d = new Date(from + j * DAY); d.setUTCHours(23, 59, 0, 0);
      const row = await db.updateClient(c.id, { expire_le: d.toISOString() });
      await db.log(c.id, 'renouvele', { de: c.expire_le, a: row.expire_le, jours: j });
      return ok({ client: row });
    },
    async release_device(b) {
      const c = await db.client(b.id); if (!c) return ko('inconnu', 'Client introuvable.', 404);
      const d = normDevice(b.device); const n = await db.deleteDevice(c.id, d);
      if (!n) return ko('appareil_inconnu', 'Appareil introuvable.', 404);
      await db.log(c.id, 'appareil_libere', { device: d });
      return ok({});
    },
    async new_code(b) {
      const c = await db.client(b.id); if (!c) return ko('inconnu', 'Client introuvable.', 404);
      const code = newCode(o.randomBytes);
      const row = await db.updateClient(c.id, { code_hash: await sha256(normCode(code)), code_fin: code.slice(-4) });
      await db.log(c.id, 'code_regenere', {});
      return ok({ client: row, code });
    },
    async journal(b) { return ok({ journal: await db.journal(b.id, 60) }); },
    async remove(b) {
      const c = await db.client(b.id); if (!c) return ko('inconnu', 'Client introuvable.', 404);
      if (c.statut !== 'revoque') return ko('revoquer_d_abord', 'Révoquez le client avant de le supprimer.', 400);
      await db.deleteClient(c.id); return ok({});
    },
  };

  return async function handle(body, ctx = {}) {
    try {
      if (!body || typeof body !== 'object') return ko('requete_invalide', 'Requête invalide.', 400);
      const a = String(body.action || '');
      if (a === 'ping') return ok({ service: 'excellencia-licences', version: 'V120o' });
      if (a === 'activate') return await activate(body, ctx);
      if (a === 'check') return await check(body);
      if (a.startsWith('admin.')) {
        const k = String(ctx.adminKey || '');
        if (!o.adminKeyHash || !k || !same(await sha256(k), o.adminKeyHash)) return ko('non_autorise', 'Clé administrateur invalide.', 401);
        const fn = ADMIN[a.slice(6)]; if (!fn) return ko('action_inconnue', 'Action inconnue.', 400);
        return await fn(body);
      }
      return ko('action_inconnue', 'Action inconnue.', 400);
    } catch (e) {
      return ko('erreur_serveur', 'Erreur du serveur de licences.', 500, { detail: String(e && e.message || e).slice(0, 200) });
    }
  };
}

/** Signature ECDSA P-256 / SHA-256, même format que le logiciel : base64url(JSON).base64url(signature brute r‖s). */
export async function makeSigner(jwk) {
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  return async (payload) => { const bytes = new TextEncoder().encode(JSON.stringify(payload)); const sg = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, bytes); return b64u(bytes) + '.' + b64u(sg); };
}
