/* V120o — fabrique les DEUX éditions du site, prêtes à déposer sur Netlify (glisser-déposer du dossier) :
 *   dist/public         → pour les clients / le public : AUCUN outil propriétaire, aucun accès à la génération de licences, licence obligatoire
 *   dist/proprietaire   → pour VOUS seul : logiciel + bouton « 🔑 Licences » (gestion des clients) + pas de blocage de licence ; à mettre sur un site Netlify PRIVÉ
 * Usage : node scripts/build-editions.js [clients/<client>/entreprise.json]
 * Le build ÉCHOUE si la moindre trace de la gestion des licences se retrouve dans l'édition publique. */
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), site = path.join(root, 'site'), out = path.join(root, 'dist');
const SKIP_DIR = new Set(['site-vitrine', 'tools', 'node_modules', '.git']);
const SKIP_FILE = /^(README.*|LISEZ-MOI.*|1-LISEZ-MOI.*|ETUDE-.*|EXCELLENCIA-ARCHITECTURE\.md|entreprise\.exemple\.json)$/i;
const SO = require('./strip-owner.js');
const die = (m) => { console.error('\nERREUR : ' + m + '\n'); process.exit(1); };

if (process.argv[2]) { const f = path.resolve(process.argv[2]); if (!fs.existsSync(f)) die('Fichier introuvable : ' + f); require('child_process').execFileSync('node', [path.join(__dirname, 'apply-brand.js'), f], { cwd: root, stdio: 'inherit' }); }
else require('./apply-licence.js').applyLicence(root);

function copy(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const e of fs.readdirSync(a, { withFileTypes: true })) {
    if (e.isDirectory()) { if (!SKIP_DIR.has(e.name)) copy(path.join(a, e.name), path.join(b, e.name)); }
    else if (!SKIP_FILE.test(e.name)) fs.copyFileSync(path.join(a, e.name), path.join(b, e.name));
  }
}
fs.rmSync(out, { recursive: true, force: true });
let lj = {}; try { lj = JSON.parse(fs.readFileSync(path.join(root, 'licence-serveur.json'), 'utf8')); } catch (e) { /* non configuré */ }

/* ---------- édition PUBLIQUE ---------- */
const pub = path.join(out, 'public'); copy(site, pub); SO.stripDir(pub);
const traces = [];
(function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { if (e.name === 'licences') traces.push(p); walk(p); continue; }
  if (/exb-licences-lien|owner-app|x-admin-key|admin\.create|admin\.renew/.test(e.name)) traces.push(p);
  if (/\.(js|html?)$/i.test(e.name)) { const t = fs.readFileSync(p, 'utf8'); if (/x-admin-key|admin\.create|admin\.release_device|exb-licences-lien/.test(t)) traces.push(p + ' (contenu)'); } } })(pub);
if (traces.length) die('Édition publique NON conforme (gestion des licences présente) :\n - ' + traces.join('\n - '));
fs.writeFileSync(path.join(pub, 'LISEZ-MOI-DEPLOIEMENT.txt'), 'ÉDITION PUBLIQUE — à déposer sur le site Netlify des clients (glisser-déposer de ce dossier).\nAucun outil de génération de licences. Le client saisit son code d\'activation.\n');

/* ---------- édition PROPRIÉTAIRE ---------- */
const own = path.join(out, 'proprietaire'); copy(site, own);
copy(path.join(root, 'owner-app', 'renderer'), path.join(own, 'licences'));
fs.writeFileSync(path.join(own, 'exb-licences-lien.js'), fs.readFileSync(path.join(root, 'owner-app', 'web', 'exb-licences-lien.js'), 'utf8').replace('__LICENCE_URL__', String(lj.url || '').replace(/[^\w:\/.\-]/g, '')));
const ip = path.join(own, 'index.html'); let h = fs.readFileSync(ip, 'utf8'); const at = h.toLowerCase().lastIndexOf('</body>');
if (at < 0) die('index.html : </body> introuvable.');
fs.writeFileSync(ip, h.slice(0, at) + '<script src="exb-licences-lien.js"></script>' + h.slice(at));
/* l'édition propriétaire reste VERROUILLÉE : vous y entrez avec votre clé privée (écran « 🔑 Accès administrateur » : sauvegarde chiffrée + mot de passe, ou CLE-PRIVEE-ADMIN.txt). Page non référencée par les moteurs de recherche. */
fs.writeFileSync(path.join(own, '_headers'), '/*\n  X-Robots-Tag: noindex, nofollow\n  Referrer-Policy: no-referrer\n');
fs.writeFileSync(path.join(own, 'robots.txt'), 'User-agent: *\nDisallow: /\n');
fs.writeFileSync(path.join(own, 'LISEZ-MOI-DEPLOIEMENT.txt'), 'ÉDITION PROPRIÉTAIRE — POUR VOUS SEUL.\nÀ déposer sur un site Netlify PRIVÉ (Site configuration › Access & security › Password protection, ou une adresse que vous ne communiquez jamais).\nNe jamais donner cette adresse ni ce dossier à un client : le logiciel s\'y ouvre avec une clé privée, mais l\'adresse ne doit pas circuler.\nOuverture : écran « Logiciel verrouillé » › « 🔑 Accès administrateur » › votre sauvegarde chiffrée (SAUVEGARDE-CLE-LICENCE-….json + mot de passe) ou CLE-PRIVEE-ADMIN.txt. Ensuite le bouton « 🔑 Licences » apparaît ; la gestion des clients demande en plus la clé d\'administration du serveur (ADMIN-KEY-LICENCES.txt).\n');
console.log('\n✔ Deux éditions prêtes :\n   dist/public        → clients / public (aucun accès aux licences)\n   dist/proprietaire  → vous seul (verrouillée : accès par votre clé privée, puis bouton « 🔑 Licences »)\n  Déposez chaque dossier sur SON site Netlify (jamais l\'inverse).');
