/* Excellencia — édition CLIENT du logiciel (V120n).
 * Retire, d'un dossier déjà copié (www/, electron/www/ ou une copie de site/), tout ce qui sert au PROPRIÉTAIRE :
 *   · exb-generator.html (générateur de licences), exb-admin.js (bouton 🔑), exb-proprietaire.js (espace propriétaire)
 *   · dans exb-license.js : saisie/stockage de la clé privée, signature de codes, accès administrateur
 * Le client garde uniquement : vérification de la licence (clé PUBLIQUE), code appareil, verrouillage, activation.
 * Usage :  node scripts/strip-owner.js <dossier>        (utilisé automatiquement par build-www.js et electron/scripts/prepare.js)
 * Pour garder l'édition propriétaire (votre propre appareil) : variable d'environnement EXB_OWNER=1.
 * Le build ÉCHOUE si un marqueur attendu est introuvable ou si du code propriétaire reste dans le résultat. */
const fs = require('fs'), path = require('path');

function cut(src, from, to, label) {
  const a = src.indexOf(from), b = src.indexOf(to);
  if (a < 0 || b < 0 || b <= a) throw new Error('strip-owner : marqueur introuvable (' + label + ') — exb-license.js a changé, adaptez scripts/strip-owner.js');
  return src.slice(0, a) + src.slice(b);
}
function sub(src, from, to, label) {
  if (src.split(from).length !== 2) throw new Error('strip-owner : motif absent ou multiple (' + label + ')');
  return src.replace(from, to);
}

function clientLicense(src) {
  /* 1) accès administrateur depuis l'écran verrouillé + déverrouillage par clé privée */
  src = cut(src, '/* V99zzzk — accès administrateur', 'function unlock(){', 'adminUI');
  src = sub(src, '  adminUI(d)}\n', '  }\n', 'appel adminUI');
  /* 2) génération de codes (clé privée) */
  src = cut(src, '/* ---- Administrateur : génération de codes ---- */', '/* V99zzj — activation par CODE', 'make/adminDialog');
  /* 3) rôle administrateur : n'existe pas dans l'édition client */
  src = sub(src, /var ADM_OK=null;[\s\S]*?async function vetAdmin\(\)\{[^\n]*\n/.exec(src)[0],
    'function isAdmin(){return false}\n', 'isAdmin/vetAdmin');
  src = sub(src, 'vetAdmin();check();', 'check();', 'appel vetAdmin');
  src = sub(src, 'adminDialog:adminDialog,isAdmin:isAdmin,make:make,',
    "adminDialog:async function(){},isAdmin:isAdmin,make:async function(){throw new Error('Génération de codes : réservé au propriétaire du logiciel.')},", 'export EXBLIC');
  src = sub(src, "var KT='exb_lic_token',KS='exb_lic_seen',KP='exb_lic_priv',", "var KT='exb_lic_token',KS='exb_lic_seen',", 'KP');
  return src.replace(/^\/\* Excellencia — licence à échéance[^\n]*\n/, '/* Excellencia — licence à échéance, ÉDITION CLIENT : vérifie un code signé (clé publique) ; ne peut ni signer ni générer de code. */\n');
}

const REMOVE_FILES = ['exb-generator.html', 'exb-admin.js', 'exb-proprietaire.js'];

function stripDir(dir) {
  if (!fs.existsSync(path.join(dir, 'index.html'))) throw new Error('strip-owner : ' + dir + '/index.html introuvable');
  for (const f of REMOVE_FILES) fs.rmSync(path.join(dir, f), { force: true });
  /* pages qui chargent ces scripts : on retire les balises */
  for (const e of fs.readdirSync(dir)) {
    if (!/\.html?$/i.test(e)) continue;
    const p = path.join(dir, e); let h = fs.readFileSync(p, 'utf8'), h0 = h;
    h = h.replace(/<script[^>]*src=["'](?:\.\/)?(?:exb-admin|exb-proprietaire)\.js["'][^>]*><\/script>/g, '');
    if (h !== h0) fs.writeFileSync(p, h);
  }
  /* exb-license.js → édition client */
  const lp = path.join(dir, 'exb-license.js');
  const cur = fs.readFileSync(lp, 'utf8');
  if (!/ÉDITION CLIENT/.test(cur.split('\n')[0])) fs.writeFileSync(lp, clientLicense(cur)); /* déjà édition client (dépôt client) : rien à refaire */
  /* service worker : ne plus pré-charger les fichiers retirés */
  const sp = path.join(dir, 'sw.js');
  if (fs.existsSync(sp)) {
    let s = fs.readFileSync(sp, 'utf8');
    for (const f of REMOVE_FILES) s = s.split("'./" + f + "',").join('');
    fs.writeFileSync(sp, s);
  }
  verify(dir);
}

/* contrôle final : rien de « propriétaire » ne doit subsister */
function verify(dir) {
  const bad = [];
  (function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { walk(p); continue; }
      if (REMOVE_FILES.includes(e.name)) bad.push(p + ' (fichier propriétaire)');
      if (!/\.(js|html?)$/i.test(e.name)) continue;
      const t = fs.readFileSync(p, 'utf8');
      if (e.name !== 'sw.js' && /src=["'](?:\.\/)?exb-(admin|proprietaire)\.js|exb-generator\.html/.test(t)) bad.push(p + ' (référence à un module propriétaire)');
      if (e.name === 'exb-license.js' && /exb_lic_priv|subtle\.sign|adminUI|PBKDF2/.test(t)) bad.push(p + ' (code de signature/clé privée)');
    }
  })(dir);
  if (bad.length) throw new Error('Édition client NON conforme :\n - ' + bad.join('\n - '));
  console.log('Édition client vérifiée : aucun générateur ni clé privée dans ' + dir);
}

module.exports = { stripDir, clientLicense, verify, owner: () => process.env.EXB_OWNER === '1' };
if (require.main === module) {
  const d = process.argv[2];
  if (!d) { console.error('Usage : node scripts/strip-owner.js <dossier>'); process.exit(1); }
  stripDir(path.resolve(d));
}
