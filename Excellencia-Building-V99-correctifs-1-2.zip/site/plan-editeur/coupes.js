/* Coupes et façades de l'éditeur de plan (V4.6, lot B).
 * Dessine, en projection orthogonale sur un plan vertical, les élévations Nord / Sud / Est / Ouest et une coupe verticale
 * à partir de la « scène » préparée par l'éditeur (la même que la vue 3D) : { levels[], slabs[], roofs[] } en mètres.
 *  levels[i] : { y0, H, name, walls:[{path,len,t,h,ops:[{pos,w,h,sill,kind}]}], furn:[{x,y,w,d,h,rot,parts}] }
 * Vues : { k:'N'|'S'|'E'|'O' } = façade vue depuis ce côté (nord vers le haut du plan) ; { k:'cut', cut:{a,b,flip} } = coupe.
 *  Coupe A→B : on regarde vers la gauche du sens A→B (flèches sur le plan) ; « flip » inverse le sens de vue.
 * Dessin : render(g, S, view, T, opt) avec T = { s: pixels par mètre, ox, oy } (écran = ox + X·s ; oy − Y·s, Y = altitude).
 * Aucune dépendance ; aucun accès au DOM autre que le contexte 2D reçu. */
(function(w){'use strict';
var INK='#1b1b1b',CREME=[235,230,218],DALLE='#d3d3d6',ACRO='#d9d5ca',POCHE='#2b2b2b';
function nf(x,d){d=d==null?2:d;var k=Math.pow(10,d);return (Math.round(x*k)/k).toFixed(d).replace('.',',')}
function alt(y){return Math.abs(y)<0.005?'±0,00':(y>0?'+':'−')+nf(Math.abs(y))}
function hexRGB(c){c=String(c||'#999999');if(c[0]==='#')c=c.slice(1);if(c.length===3)c=c[0]+c[0]+c[1]+c[1]+c[2]+c[2];return[parseInt(c.substr(0,2),16),parseInt(c.substr(2,2),16),parseInt(c.substr(4,2),16)]}
function rgb(a,k){k=k==null?1:k;return 'rgb('+Math.round(Math.min(255,a[0]*k))+','+Math.round(Math.min(255,a[1]*k))+','+Math.round(Math.min(255,a[2]*k))+')'}
function plen(P){var c=[0],i;for(i=0;i<P.length-1;i++)c.push(c[i]+Math.hypot(P[i+1][0]-P[i][0],P[i+1][1]-P[i][1]));return c}
function segD(p,a,b){var dx=b[0]-a[0],dy=b[1]-a[1],l2=dx*dx+dy*dy,t=l2?((p[0]-a[0])*dx+(p[1]-a[1])*dy)/l2:0;t=Math.max(0,Math.min(1,t));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)}
function pathD(p,P){var d=1e9,i;for(i=0;i<P.length-1;i++)d=Math.min(d,segD(p,P[i],P[i+1]));return d}
function inPoly(p,P){var c=false,i,j;for(i=0,j=P.length-1;i<P.length;j=i++){if(((P[i][1]>p[1])!==(P[j][1]>p[1]))&&(p[0]<(P[j][0]-P[i][0])*(p[1]-P[i][1])/(P[j][1]-P[i][1])+P[i][0]))c=!c}return c}

/* ---- projection ---- */
function proj(view){var k=view.k;
 if(k==='S')return{X:function(x,z){return x},N:function(x,z){return z},D:null};
 if(k==='N')return{X:function(x,z){return -x},N:function(x,z){return -z},D:null};
 if(k==='E')return{X:function(x,z){return -z},N:function(x,z){return x},D:null};
 if(k==='O')return{X:function(x,z){return z},N:function(x,z){return -x},D:null};
 var c=view.cut,ax=c.a[0],az=c.a[1],dx=c.b[0]-ax,dz=c.b[1]-az,L=Math.hypot(dx,dz)||1,ux=dx/L,uz=dz/L,fl=c.flip?-1:1,lx=uz*fl,lz=-ux*fl,rx=-lz,rz=lx;
 return{L:L,ax:ax,az:az,ux:ux,uz:uz,lx:lx,lz:lz,
  X:function(x,z){return (x-ax)*rx+(z-az)*rz},
  D:function(x,z){return (x-ax)*lx+(z-az)*lz},
  N:function(x,z){return -((x-ax)*lx+(z-az)*lz)}}}

/* ---- toiture : fonction de hauteur de la surface (toits à pentes) ---- */
function roofFn(R){if(R.poly||R.type==='plat')return null;
 var e=.35,tn=Math.tan((R.slope||30)*Math.PI/180),ww=R.x1-R.x0,dd=R.y1-R.y0,alongX=R.axis==='x'?true:R.axis==='y'?false:ww>=dd,span=alongX?dd:ww,rise=span/2*tn,ye=R.yE-e*tn,yR=R.yE+rise,qc=e+span/2;
 return{e:e,alongX:alongX,yR:yR,ye:ye,h:function(x,z){if(x<R.x0-e||x>R.x1+e||z<R.y0-e||z>R.y1+e)return null;var q;
  if(R.type==='2pans')q=alongX?Math.min(z-(R.y0-e),(R.y1+e)-z):Math.min(x-(R.x0-e),(R.x1+e)-x);
  else q=Math.min(x-(R.x0-e),(R.x1+e)-x,z-(R.y0-e),(R.y1+e)-z);
  return ye+tn*Math.min(q,qc)}}}
function roofTop(R){var f=roofFn(R);if(f)return f.yR;return R.yE+.5}

/* ---- étendue du dessin (mètres) ---- */
function bounds(S,view){var pr=proj(view),X0=1e9,X1=-1e9,top=0,any=false;
 if(view.k==='cut'){X0=Math.min(0,pr.X(view.cut.b[0],view.cut.b[1]));X1=Math.max(0,pr.X(view.cut.b[0],view.cut.b[1]));any=true}
 (S.levels||[]).forEach(function(L){top=Math.max(top,L.y0+L.H);(L.walls||[]).forEach(function(wl){wl.path.forEach(function(p){var x=pr.X(p[0],p[1]);if(view.k!=='cut'){X0=Math.min(X0,x-wl.t/2);X1=Math.max(X1,x+wl.t/2);any=true}})})});
 (S.roofs||[]).forEach(function(R){top=Math.max(top,roofTop(R));if(view.k!=='cut'){var cs=[[R.x0-.4,R.y0-.4],[R.x1+.4,R.y0-.4],[R.x1+.4,R.y1+.4],[R.x0-.4,R.y1+.4]];cs.forEach(function(c){var x=pr.X(c[0],c[1]);X0=Math.min(X0,x);X1=Math.max(X1,x);any=true})}});
 if(!any){X0=0;X1=5}return{X0:X0,X1:X1,top:Math.max(top,2.8)}}
function extent(S,view){if(view.k==='cha'&&w.EXBCHA)return w.EXBCHA.extent(S);var b=bounds(S,view);return{x0:b.X0-2.3,x1:b.X1+3.1,y0:-1.7,y1:b.top+1.5}}

/* ---- primitives de dessin ---- */
function mkT(g,T,k){var s=T.s;return{
 sx:function(X){return T.ox+X*s},sy:function(Y){return T.oy-Y*s},
 rect:function(x0,y0,x1,y1,fill,stroke,lw){var a=T.ox+Math.min(x0,x1)*s,b=T.oy-Math.max(y0,y1)*s,c=Math.abs(x1-x0)*s,d=Math.abs(y1-y0)*s;if(fill){g.fillStyle=fill;g.fillRect(a,b,c,d)}if(stroke){g.strokeStyle=stroke;g.lineWidth=(lw||1)*k;g.strokeRect(a,b,c,d)}},
 line:function(x0,y0,x1,y1,col,lw,dash){g.beginPath();g.moveTo(T.ox+x0*s,T.oy-y0*s);g.lineTo(T.ox+x1*s,T.oy-y1*s);g.strokeStyle=col||INK;g.lineWidth=(lw||1)*k;if(dash)g.setLineDash(dash.map(function(v){return v*k}));g.stroke();if(dash)g.setLineDash([])},
 poly:function(P,fill,stroke,lw){g.beginPath();P.forEach(function(p,i){var x=T.ox+p[0]*s,y=T.oy-p[1]*s;i?g.lineTo(x,y):g.moveTo(x,y)});g.closePath();if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=(lw||1)*k;g.lineJoin='round';g.stroke()}}}}

/* ---- ouvertures vues en élévation ---- */
function drawOpening(g,P,k,op,xa,xb,yb,full){ /* xa<xb en mètres de dessin ; yb = altitude du plancher */
 var y0=yb+(op.sill||0),y1=y0+op.h,W=xb-xa,fw=.05;
 if(op.kind==='porte'){
  P.rect(xa-.02,y0,xb+.02,y1+.02,'#f8fafc',INK,.8);P.rect(xa+fw,y0,xb-fw,y1-fw,'#a16207','#5b3a0a',.8);
  var dbl=W>1.5,ph=op.h*.34,pw=Math.max(.15,(dbl?W/2:W)-.3),cx=(xa+xb)/2;
  if(dbl){P.line(cx,y0,cx,y1-fw,'#5b3a0a',1);[xa+W/4,xb-W/4].forEach(function(c){P.rect(c-pw/2,y0+.2*op.h-ph/2*0+0.05,c+pw/2,y0+.2*op.h+ph*.5,null,'#7a4b0e',.6);P.rect(c-pw/2,y0+.6*op.h-ph*.3,c+pw/2,y0+.6*op.h+ph*.5,null,'#7a4b0e',.6)})}
  else{P.rect(cx-pw/2,y0+.08*op.h,cx+pw/2,y0+.08*op.h+ph,null,'#7a4b0e',.6);P.rect(cx-pw/2,y0+.52*op.h,cx+pw/2,y0+.52*op.h+ph,null,'#7a4b0e',.6)}
  var hx=dbl?cx-.1:xb-.14,hy=y0+Math.min(1.0,op.h*.48);P.rect(hx-.05,hy-.012,hx+.05,hy+.012,'#c4c8d0','#555',.5);
  P.rect(xa-.03,y0-.02,xb+.03,y0,'#9ca3af',null);
  return}
 /* fenêtre */
 P.rect(xa,y0,xb,y1,'#f8fafc',INK,.9);
 var gx0=xa+fw,gx1=xb-fw,gy0=y0+fw,gy1=y1-fw;
 if(gx1>gx0&&gy1>gy0){var gr=g.createLinearGradient(0,P.sy(gy1),0,P.sy(gy0));gr.addColorStop(0,'#cfe6f5');gr.addColorStop(1,'#7fb4dc');
  g.fillStyle=gr;g.fillRect(P.sx(gx0),P.sy(gy1),(gx1-gx0)*P.sx(1)-(gx1-gx0)*P.sx(0),(gy1-gy0)*(P.sy(0)-P.sy(1)));
  g.strokeStyle='#64748b';g.lineWidth=.6*k;g.strokeRect(P.sx(gx0),P.sy(gy1),(gx1-gx0)*(P.sx(1)-P.sx(0)),(gy1-gy0)*(P.sy(0)-P.sy(1)));
  P.poly([[gx0,gy0+(gy1-gy0)*.15],[gx0+(gx1-gx0)*.32,gy1],[gx0+(gx1-gx0)*.5,gy1],[gx0,gy0+(gy1-gy0)*.55]],'rgba(255,255,255,.35)',null);
  if(W>1.1)P.rect((xa+xb)/2-.02,gy0,(xa+xb)/2+.02,gy1,'#f8fafc','#64748b',.5);
  if(op.h>1.5&&W>.7)P.rect(gx0,y0+op.h*.78-.017,gx1,y0+op.h*.78+.017,'#f8fafc','#64748b',.5)}
 if((op.sill||0)>.25)P.rect(xa-.06,y0-.045,xb+.06,y0,'#eceae4','#6b6b66',.7)}

/* ---- dessin principal ---- */
function render(g,S,view,T,opt){opt=opt||{};if(view.k==='cha'&&w.EXBCHA)return w.EXBCHA.render(g,S,view,T,opt);var k=opt.k||1,P=mkT(g,T,k),pr=proj(view),isCut=view.k==='cut',bd=bounds(S,view),items=[],cuts=[],i;
 var nearMin=1e9,nearMax=-1e9;
 function touch(L,wl,p){for(var q=0;q<L.walls.length;q++){var o=L.walls[q];if(o===wl)continue;if(pathD(p,o.path)<=o.t/2+.03)return true}return false}
 function shade(n){var t=nearMax>nearMin?(nearMax-n)/(nearMax-nearMin):0;return 1-.07*Math.max(0,Math.min(1,t))}
 /* bornes de profondeur pour l'ombrage */
 (S.levels||[]).forEach(function(L){(L.walls||[]).forEach(function(wl){wl.path.forEach(function(p){var n=pr.N(p[0],p[1]);nearMin=Math.min(nearMin,n);nearMax=Math.max(nearMax,n)})})});
 var cutLevel0=[];
 (S.levels||[]).forEach(function(L,li){
  var yb=L.y0;
  (L.walls||[]).forEach(function(wl){
   var Pa=wl.path,cum=plen(Pa),sc=wl.len?cum[cum.length-1]/wl.len:1,curved=Pa.length>2,
    ops=(wl.ops||[]).map(function(o){return{s0:(o.pos-o.w/2)*sc,s1:(o.pos+o.w/2)*sc,h:o.h,sill:o.sill||0,kind:o.kind,id:o.id}}),t=wl.t,h=wl.h;
   for(var q=0;q<Pa.length-1;q++){
    var a=Pa[q],b=Pa[q+1],sl=cum[q+1]-cum[q];if(sl<1e-4)continue;
    var xa=pr.X(a[0],a[1]),xb=pr.X(b[0],b[1]),segInfo={a:a,b:b,sl:sl,g0:cum[q]};
    var mkFace=function(pa,pb,s0,s1,keyN){ /* face d'un tronçon [pa,pb] entre abscisses s0..s1 */
     var Xa=pr.X(pa[0],pa[1]),Xb=pr.X(pb[0],pb[1]);if(Math.abs(Xb-Xa)<.03)return;
     var x0=Math.min(Xa,Xb),x1=Math.max(Xa,Xb);
     if(!curved){var e0=touch(L,wl,Xa<Xb?pa:pb)?t/2:0,e1=touch(L,wl,Xa<Xb?pb:pa)?t/2:0;x0-=e0;x1+=e1}
     var kk=shade(keyN);
     items.push({key:keyN,kind:'w',li:li,x0:x0,x1:x1,fn:function(){
      var yTop=yb+h,yBot=li>0?yb-.2:yb;if(opt.hits)opt.hits.push({t:'w',id:wl.id,lv:li,x0:x0,x1:x1,y0:yb,y1:yTop});
      if(li>0)P.rect(x0,yBot,x1,yb,rgb(hexRGB(DALLE),kk),curved?null:INK,.8);
      P.rect(x0,yb,x1,yTop,rgb(CREME,kk),curved?null:INK,.9);
      if(opt.hatch!==false&&T.s>=70*k){g.strokeStyle='rgba(110,95,70,.22)';g.lineWidth=.35*k;var cr,jx,row=0;g.beginPath();for(cr=yb+.2;cr<yTop-.01;cr+=.2,row++){g.moveTo(P.sx(x0),P.sy(cr));g.lineTo(P.sx(x1),P.sy(cr));for(jx=x0+(row%2?.25:.5);jx<x1;jx+=.5){g.moveTo(P.sx(jx),P.sy(cr));g.lineTo(P.sx(jx),P.sy(cr-.2))}}g.stroke()}
      if(curved){P.line(x0,yTop,x1,yTop,INK,.8);P.line(x0,yb,x1,yb,INK,.8)}
      ops.forEach(function(o){var u0=Math.max(o.s0,s0),u1=Math.min(o.s1,s1);if(u1-u0<.02)return;
       var f0=(u0-s0)/(s1-s0),f1=(u1-s0)/(s1-s0),p0=Xa+(Xb-Xa)*f0,p1=Xa+(Xb-Xa)*f1;drawOpening(g,P,k,{kind:o.kind,h:Math.min(o.h,h-o.sill),sill:o.sill},Math.min(p0,p1),Math.max(p0,p1),yb,u1-u0>=o.s1-o.s0-.01);
       if(opt.hits&&o.id!=null)opt.hits.push({t:'o',id:o.id,lv:li,x0:Math.min(p0,p1),x1:Math.max(p0,p1),y0:yb+o.sill,y1:yb+o.sill+Math.min(o.h,h-o.sill)});
       if(opt.dims!==false&&(u1-u0)*T.s>34*k&&u1-u0>=o.s1-o.s0-.01){var tx=P.sx((p0+p1)/2),ty=P.sy(yb+o.sill+Math.min(o.h,h-o.sill))-3*k;g.fillStyle='#475569';g.font=(9*k)+'px Arial';g.textAlign='center';g.fillText(nf(o.s1-o.s0)+'×'+nf(o.h),tx,ty)}})}})};
    if(!isCut){
     if(Math.abs(xb-xa)<.03)continue;
     mkFace(a,b,cum[q],cum[q+1],(pr.N(a[0],a[1])+pr.N(b[0],b[1]))/2);continue}
    /* coupe : tronçons devant / derrière / traversés par le plan */
    var Da=pr.D(a[0],a[1]),Db=pr.D(b[0],b[1]),eps=.004,ux=(b[0]-a[0])/sl,uy=(b[1]-a[1])/sl,sinP=Math.abs(ux*pr.uz-uy*pr.ux);
    if(sinP<.12&&Math.abs((Da+Db)/2)<=t/2+.01){ /* mur dans le plan de coupe */
     cuts.push({x0:Math.min(xa,xb),x1:Math.max(xa,xb),y0:yb,y1:yb+h,li:li,wid:wl.id});if(li===0)cutLevel0.push([Math.min(xa,xb),Math.max(xa,xb)]);continue}
    if(Da>=-eps&&Db>=-eps){mkFace(a,b,cum[q],cum[q+1],-(Da+Db)/2);continue}
    if(Da<=eps&&Db<=eps)continue;
    var tq=Da/(Da-Db),qp=[a[0]+(b[0]-a[0])*tq,a[1]+(b[1]-a[1])*tq],sq=cum[q]+sl*tq;
    if(Da>0)mkFace(a,qp,cum[q],sq,pr.N(a[0],a[1])*.5+pr.N(qp[0],qp[1])*.5);else mkFace(qp,b,sq,cum[q+1],pr.N(b[0],b[1])*.5+pr.N(qp[0],qp[1])*.5);
    var Xq=pr.X(qp[0],qp[1]),hw=Math.min(1.5,(t/2)/Math.max(sinP,.2)),op=null;
    ops.forEach(function(o){if(sq>=o.s0&&sq<=o.s1)op=o});
    if(!op)cuts.push({x0:Xq-hw,x1:Xq+hw,y0:yb,y1:yb+h,li:li,wid:wl.id});
    else{var top=Math.min(h,op.sill+op.h);if(op.sill>.001)cuts.push({x0:Xq-hw,x1:Xq+hw,y0:yb,y1:yb+op.sill,li:li,wid:wl.id});if(top<h-.001)cuts.push({x0:Xq-hw,x1:Xq+hw,y0:yb+top,y1:yb+h,li:li,wid:wl.id});
     cuts.push({x0:Xq-hw,x1:Xq+hw,y0:yb+op.sill,y1:yb+top,li:li,glass:op.kind!=='porte',wid:wl.id,oid:op.id})}
    if(li===0)cutLevel0.push([Xq-hw,Xq+hw])}});
  /* mobilier (visible en coupe seulement) */
  if(isCut)(L.furn||[]).forEach(function(f){if(f.stair&&false)return;
   var ph=-(f.rot||0)*Math.PI/180,c=Math.cos(ph),s=Math.sin(ph);
   (f.parts||[]).forEach(function(p){
    var xs=[],ds=[],cs=[[p[0],p[1]],[p[3],p[1]],[p[3],p[4]],[p[0],p[4]]];
    cs.forEach(function(q){var lx=(q[0]-.5)*f.w,lz=(q[1]-.5)*f.d,wx=f.x+lx*c+lz*s,wz=f.y-lx*s+lz*c;xs.push(pr.X(wx,wz));ds.push(pr.D(wx,wz))});
    var dmin=Math.min.apply(0,ds),dmax=Math.max.apply(0,ds);if(dmax<=0)return;
    var x0=Math.min.apply(0,xs),x1=Math.max.apply(0,xs),z0=L.y0+p[2]*f.h+.012,z1=L.y0+p[5]*f.h+.012,crossing=dmin<0,col=hexRGB(p[6]);
    items.push({key:-(Math.max(dmin,0)+dmax)/2+.0001,kind:'f',li:li,x0:x0,x1:x1,fn:function(){if(opt.hits&&f.id!=null)opt.hits.push({t:'f',id:f.id,lv:li,x0:x0,x1:x1,y0:z0,y1:z1});var sh=p[7]||'b',fill=rgb(col,.92),stroke=crossing?INK:'#5b6270',lw=crossing?1.2:.6;
     if(sh==='e'||sh==='c'&&false){g.beginPath();g.ellipse(P.sx((x0+x1)/2),P.sy((z0+z1)/2),(x1-x0)/2*T.s,(z1-z0)/2*T.s,0,0,6.2832);g.fillStyle=fill;g.fill();g.strokeStyle=stroke;g.lineWidth=lw*k;g.stroke()}
     else P.rect(x0,z0,x1,z1,fill,stroke,lw)}})})});
  /* appuis de dalle vus en façade : traités dans les murs ; dalles coupées ci-dessous */
 });
 items.sort(function(A,B){return A.key-B.key});
 /* sortie vectorielle (CAO) : pas de remplissage pour masquer le fond → on retire ce qu'un mur plus proche cache entièrement */
 if(opt.vector){items=items.filter(function(it){if(!it.kind)return true;var cov=[];items.forEach(function(o){if(o!==it&&o.kind==='w'&&o.li===it.li&&o.key>it.key+.02)cov.push([o.x0,o.x1])});cov.sort(function(a,b){return a[0]-b[0]});
   var reach=it.x0-.03;cov.forEach(function(c){if(c[0]<=reach+.03&&c[1]>reach)reach=c[1]});return reach<it.x1-.03})}
 /* sol, terrain */
 var gx0=bd.X0-1.6,gx1=bd.X1+1.6;
 P.rect(gx0,-.7,gx1,0,'#f3f1ec',null);
 if(opt.hatch!==false){g.save();g.beginPath();g.rect(P.sx(gx0),P.sy(0),(gx1-gx0)*T.s,.7*T.s);g.clip();
 g.strokeStyle='#b8b8b8';g.lineWidth=.6*k;var step=.22,xx;for(xx=gx0-1;xx<gx1+1;xx+=step){g.beginPath();g.moveTo(P.sx(xx),P.sy(0));g.lineTo(P.sx(xx-.7),P.sy(-.7));g.stroke()}g.restore()}
 /* éléments en arrière-plan, puis toitures de façade */
 if(isCut)(S.roofs||[]).forEach(function(R){var f=roofFn(R);if(!f)return;var Ln=pr.L,NS=70,prof=[],n,m;
  for(n=0;n<=NS;n++){var tt=Ln*n/NS,bx=pr.ax+pr.ux*tt,bz=pr.az+pr.uz*tt,best=null;for(m=0;m<=80;m++){var dd=m*.5,hh=f.h(bx+pr.lx*dd,bz+pr.lz*dd);if(hh!=null&&(best==null||hh>best))best=hh}
   if(best!=null)prof.push([pr.X(bx,bz),best])}
  if(prof.length>1){prof.sort(function(A,B){return A[0]-B[0]});P.poly(prof.concat([[prof[prof.length-1][0],f.ye],[prof[0][0],f.ye]]),'rgba(180,95,60,.5)','rgba(120,50,25,.7)',.7)}});
 items.forEach(function(it){it.fn()});
 /* dalles et toits en coupe / toits en façade */
 var cutSlabs=[],extras=[];
 if(isCut){
  var Ln=pr.L,N=Math.max(60,Math.ceil(Ln/.04)),dt=Ln/N;
  function runs(pred){var out=[],st=null,n,t0;for(n=0;n<=N;n++){var tt=n*dt,x=pr.ax+pr.ux*tt,z=pr.az+pr.uz*tt,on=pred(x,z);if(on&&st==null)st=tt;if(!on&&st!=null){out.push([st,tt]);st=null}}if(st!=null)out.push([st,Ln]);return out}
  function toX(t){return pr.X(pr.ax+pr.ux*t,pr.az+pr.uz*t)}
  /* dalle sur terre-plein */
  var b0=null;(S.levels[0]&&S.levels[0].walls||[]).forEach(function(wl){wl.path.forEach(function(p){var t=wl.t/2;if(!b0)b0=[p[0]-t,p[0]+t,p[1]-t,p[1]+t];else{b0[0]=Math.min(b0[0],p[0]-t);b0[1]=Math.max(b0[1],p[0]+t);b0[2]=Math.min(b0[2],p[1]-t);b0[3]=Math.max(b0[3],p[1]+t)}})});
  if(b0)runs(function(x,z){return x>=b0[0]&&x<=b0[1]&&z>=b0[2]&&z<=b0[3]}).forEach(function(r){cutSlabs.push({x0:toX(r[0]),x1:toX(r[1]),y0:-.15,y1:0})});
  (S.slabs||[]).forEach(function(sl){runs(function(x,z){if(x<sl.x0||x>sl.x1||z<sl.y0||z>sl.y1)return false;for(var q=0;q<(sl.holes||[]).length;q++){var h=sl.holes[q];if(x>=h[0]&&x<=h[1]&&z>=h[2]&&z<=h[3])return false}return true}).forEach(function(r){cutSlabs.push({x0:toX(r[0]),x1:toX(r[1]),y0:sl.y-.2,y1:sl.y})})});
  (S.roofs||[]).forEach(function(R){var f=roofFn(R);
   if(f){var pts=[],n;for(n=0;n<=N;n++){var tt=n*dt,x=pr.ax+pr.ux*tt,z=pr.az+pr.uz*tt,hh=f.h(x,z);if(hh!=null)pts.push([toX(tt),hh])}
    if(pts.length>1){var top=pts.map(function(p){return[p[0],p[1]]}),bot=pts.slice().reverse().map(function(p){return[p[0],p[1]-.18]});P.poly(top.concat(bot),'#b45f3c',INK,.9);
     var hmax=-1e9,hmin=1e9,ia=0;pts.forEach(function(p,ii){if(p[1]>hmax){hmax=p[1];ia=ii}hmin=Math.min(hmin,p[1])});
     var xmn=Math.min(pts[0][0],pts[pts.length-1][0]),xmx=Math.max(pts[0][0],pts[pts.length-1][0]);
     if(hmax-hmin<.05){P.rect(xmn,hmax-.38,xmx,hmax-.18,'#8b6b4a',INK,.7);P.line(xmn,hmax-.28,xmx,hmax-.28,'rgba(40,25,10,.5)',.5)}
     else{var ax=pts[ia][0];P.rect(ax-.07,hmax-.42,ax+.07,hmax-.18,'#8b6b4a',INK,.7);
      var pa=runs(function(x,z){return x>=R.x0&&x<=R.x1&&z>=R.y0&&z<=R.y1});pa.forEach(function(r){var xa2=toX(r[0]),xb2=toX(r[1]);extras.push({x0:Math.min(xa2,xb2),x1:Math.max(xa2,xb2),y0:R.yE-.05,y1:R.yE});[xa2,xb2].forEach(function(xe){extras.push({x0:xe-.06,x1:xe+.06,y0:R.yE,y1:R.yE+.12,wood:1})})})}}}
   else{var rr=runs(function(x,z){return R.poly?inPoly([x,z],R.poly):(x>=R.x0&&x<=R.x1&&z>=R.y0&&z<=R.y1)});
    rr.forEach(function(r){var xa=toX(r[0]),xb=toX(r[1]);cutSlabs.push({x0:xa,x1:xb,y0:R.yE,y1:R.yE+.2});[xa,xb].forEach(function(xe,ii){var dir=(xa<xb)===(ii===0)?1:-1;cutSlabs.push({x0:xe,x1:xe+dir*.14,y0:R.yE+.2,y1:R.yE+.5})})})}})
 }else{
  (S.roofs||[]).forEach(function(R){var f=roofFn(R),Rc=[[R.x0,R.y0],[R.x1,R.y0],[R.x1,R.y1],[R.x0,R.y1]],xs=Rc.map(function(c){return pr.X(c[0],c[1])}),X0=Math.min.apply(0,xs),X1=Math.max.apply(0,xs);
   if(!f){ /* terrasse : dalle + acrotère */
    var bx0=X0,bx1=X1;if(R.poly){var px=R.poly.map(function(p){return pr.X(p[0],p[1])});bx0=Math.min.apply(0,px);bx1=Math.max.apply(0,px)}
    if(opt.hits&&R.id!=null)opt.hits.push({t:'T',id:R.id,lv:null,x0:bx0,x1:bx1,y0:R.yE,y1:R.yE+.5});P.rect(bx0,R.yE,bx1,R.yE+.2,'#b9b9bd',INK,.9);P.rect(bx0,R.yE+.2,bx1,R.yE+.5,rgb(hexRGB(ACRO)),INK,.9);P.line(bx0,R.yE+.5,bx1,R.yE+.5,INK,1.4);return}
   var e=f.e,viewAlongRidge=R.type==='2pans'&&(f.alongX?(view.k==='E'||view.k==='O'):(view.k==='S'||view.k==='N')),
    prof=[],n,NS=80,sx0=X0-e*.0,sx1=X1;
   var inv=function(Xs,tt){return view.k==='S'?[Xs,tt]:view.k==='N'?[-Xs,tt]:view.k==='E'?[tt,-Xs]:[tt,Xs]};
   var scanLo=(view.k==='S'||view.k==='N')?R.y0-e:R.x0-e,scanHi=(view.k==='S'||view.k==='N')?R.y1+e:R.x1+e;
   for(n=0;n<=NS;n++){var Xs=(X0-e)+(X1-X0+2*e)*n/NS,best=null,m;for(m=0;m<=24;m++){var tt=scanLo+(scanHi-scanLo)*m/24,wp=inv(Xs,tt),hh=f.h(wp[0],wp[1]);if(hh!=null&&(best==null||hh>best))best=hh}
    if(best!=null)prof.push([Xs,best])}
   if(prof.length<2)return;
   if(opt.hits&&R.id!=null)opt.hits.push({t:'T',id:R.id,lv:null,x0:X0-e,x1:X1+e,y0:f.ye,y1:f.yR});
   var base=[[prof[prof.length-1][0],f.ye],[prof[0][0],f.ye]];
   if(viewAlongRidge){ /* pignon : mur crème sous deux rives */
    P.poly([[prof[0][0]+e,R.yE]].concat(prof.filter(function(p){return p[1]>=R.yE-.001&&p[0]>=X0-.001&&p[0]<=X1+.001})).concat([[prof[prof.length-1][0]-e,R.yE]]),rgb(CREME,.97),INK,.9);
    var edge=prof.map(function(p){return[p[0],p[1]]}),edge2=prof.slice().reverse().map(function(p){return[p[0],p[1]-.13]});P.poly(edge.concat(edge2),'#9a4a2c',INK,.9)}
   else{P.poly(prof.concat(base),'#b45f3c',INK,1);
    if(opt.hatch!==false){var yy,row=0,cs=Math.max(.08,.34*Math.cos((R.slope||30)*Math.PI/180)),xj;g.save();g.beginPath();prof.concat(base).forEach(function(p,ii){var x=P.sx(p[0]),y=P.sy(p[1]);ii?g.lineTo(x,y):g.moveTo(x,y)});g.closePath();g.clip();
    g.strokeStyle='rgba(60,20,8,.38)';g.lineWidth=.5*k;g.beginPath();for(yy=f.ye;yy<f.yR;yy+=cs,row++){g.moveTo(P.sx(X0-e-1),P.sy(yy));g.lineTo(P.sx(X1+e+1),P.sy(yy));if(T.s>=40*k)for(xj=X0-e+(row%2?.13:0);xj<X1+e+.3;xj+=.26){g.moveTo(P.sx(xj),P.sy(yy));g.lineTo(P.sx(xj),P.sy(yy+cs))}}g.stroke();g.restore()}
    var cx2;for(cx2=X0-e+.1;cx2<X1+e;cx2+=.6)P.rect(cx2-.035,f.ye-.2,cx2+.035,f.ye-.1,'#8b6b4a',INK,.4);
    P.rect(X0-e,f.ye-.1,X1+e,f.ye,'#6b7280',INK,.6);P.rect(X0-e-.04,f.yR,X1+e+.04,f.yR+.07,'#7c2d12',INK,.6)}})}
 /* poché des éléments coupés */
 cuts.concat(cutSlabs).forEach(function(c){P.rect(c.x0,c.y0,c.x1,c.y1,POCHE,INK,.8);
  if(opt.hits&&c.wid!=null)opt.hits.push(c.oid!=null?{t:'o',id:c.oid,lv:c.li,x0:c.x0,x1:c.x1,y0:c.y0,y1:c.y1}:{t:'w',id:c.wid,lv:c.li,x0:c.x0,x1:c.x1,y0:c.y0,y1:c.y1});
  if(opt.hatch!==false&&c.li!=null&&T.s>=60*k&&c.y1-c.y0>.5){g.strokeStyle='rgba(235,235,235,.45)';g.lineWidth=.4*k;g.beginPath();var cr;for(cr=c.y0+.2;cr<c.y1-.01;cr+=.2){g.moveTo(P.sx(c.x0)+1,P.sy(cr));g.lineTo(P.sx(c.x1)-1,P.sy(cr))}g.stroke()}
  if(c.glass){var mx=(c.x0+c.x1)/2;P.rect(mx-.012,c.y0+.03,mx+.012,c.y1-.03,'#8fc1e3','#475569',.5)}});
 extras.forEach(function(c){P.rect(c.x0,c.y0,c.x1,c.y1,c.wood?'#8b6b4a':'#e5e7eb',INK,.6)});
 /* ligne de terrain */
 P.line(gx0,0,gx1,0,INK,2.2);
 /* annotations */
 annotate(g,P,S,view,pr,bd,cutLevel0,T,k,opt);
 if(opt.legend!==false)legend(g,T,k,opt)}

function dimH(g,P,x0,x1,y,txt,k,T){var a=P.sx(x0),b=P.sx(x1),Y=P.sy(y);g.strokeStyle='#444';g.lineWidth=.8*k;g.beginPath();g.moveTo(a,Y);g.lineTo(b,Y);g.stroke();
 [a,b].forEach(function(X){g.beginPath();g.moveTo(X-4*k,Y+4*k);g.lineTo(X+4*k,Y-4*k);g.stroke();g.beginPath();g.moveTo(X,Y-6*k);g.lineTo(X,Y+6*k);g.stroke()});
 if(txt&&Math.abs(b-a)>22*k){g.font='700 '+(10.5*k)+'px Arial';g.textAlign='center';g.lineWidth=3*k;g.strokeStyle='#fff';g.strokeText(txt,(a+b)/2,Y-5*k);g.fillStyle='#111';g.fillText(txt,(a+b)/2,Y-5*k)}}
function dimV(g,P,x,y0,y1,txt,k){var X=P.sx(x),a=P.sy(y0),b=P.sy(y1);g.strokeStyle='#444';g.lineWidth=.8*k;g.beginPath();g.moveTo(X,a);g.lineTo(X,b);g.stroke();
 [a,b].forEach(function(Y){g.beginPath();g.moveTo(X-4*k,Y+4*k);g.lineTo(X+4*k,Y-4*k);g.stroke();g.beginPath();g.moveTo(X-6*k,Y);g.lineTo(X+6*k,Y);g.stroke()});
 if(txt&&Math.abs(b-a)>18*k){g.save();g.translate(X-5*k,(a+b)/2);g.rotate(-Math.PI/2);g.font='700 '+(10*k)+'px Arial';g.textAlign='center';g.lineWidth=3*k;g.strokeStyle='#fff';g.strokeText(txt,0,0);g.fillStyle='#111';g.fillText(txt,0,0);g.restore()}}
function annotate(g,P,S,view,pr,bd,cut0,T,k,opt){
 var xl=bd.X0-.7,xr=bd.X1+.6,L=S.levels||[];
 /* cotes verticales à gauche : hauteur sous plafond et épaisseur de dalle de chaque niveau */
 L.forEach(function(Lv,i){dimV(g,P,xl,Lv.y0,Lv.y0+Lv.H,nf(Lv.H),k);if(i<L.length-1)dimV(g,P,xl,Lv.y0+Lv.H,L[i+1].y0,'',k)});
 var top=bd.top;dimV(g,P,xl-.7,0,top,'Hauteur totale '+nf(top),k);
 /* niveaux à droite */
 g.font='700 '+(10.5*k)+'px Arial';g.textAlign='left';
 var marks=L.map(function(Lv){return{y:Lv.y0,t:alt(Lv.y0)+'  '+(Lv.name||'')}});
 (S.roofs||[]).forEach(function(R){var f=roofFn(R);if(f){marks.push({y:R.yE,t:alt(R.yE)+'  Égout'});marks.push({y:f.yR,t:alt(f.yR)+'  Faîtage'})}else marks.push({y:R.yE+.5,t:alt(R.yE+.5)+'  Acrotère'})});
 marks.push({y:L.length?L[L.length-1].y0+L[L.length-1].H:2.8,t:alt(L.length?L[L.length-1].y0+L[L.length-1].H:2.8)+'  Plafond'});
 var seen={};marks.forEach(function(m){var key=Math.round(m.y*100);if(seen[key])return;seen[key]=1;var X=P.sx(xr+.1),Y=P.sy(m.y);
  g.strokeStyle='#888';g.lineWidth=.6*k;g.setLineDash([5*k,3*k]);g.beginPath();g.moveTo(P.sx(bd.X0-.3),Y);g.lineTo(X,Y);g.stroke();g.setLineDash([]);
  g.fillStyle='#111';g.beginPath();g.moveTo(X,Y);g.lineTo(X+5*k,Y-8*k);g.lineTo(X-5*k,Y-8*k);g.closePath();g.fill();
  g.lineWidth=3*k;g.strokeStyle='#fff';g.strokeText(m.t,X+9*k,Y-1*k);g.fillStyle='#111';g.fillText(m.t,X+9*k,Y-1*k)});
 /* largeur hors tout (façade) ou chaîne de cotes (coupe) */
 var yd=-1.05;
 if(view.k==='cut'&&cut0.length){
  var iv=cut0.slice().sort(function(a,b){return a[0]-b[0]}),mg=[];iv.forEach(function(q){var l=mg[mg.length-1];if(l&&q[0]<=l[1]+.01)l[1]=Math.max(l[1],q[1]);else mg.push([q[0],q[1]])});
  var yc=-.7,j;for(j=0;j<mg.length;j++){dimH(g,P,mg[j][0],mg[j][1],yc,nf(mg[j][1]-mg[j][0]),k,T);if(j<mg.length-1)dimH(g,P,mg[j][1],mg[j+1][0],yc,nf(mg[j+1][0]-mg[j][1]),k,T)}
  dimH(g,P,mg[0][0],mg[mg.length-1][1],yd-.2,'Hors tout '+nf(mg[mg.length-1][1]-mg[0][0]),k,T)}
 else if(view.k!=='cut'){dimH(g,P,bd.X0,bd.X1,yd,'Largeur hors tout '+nf(bd.X1-bd.X0),k,T)}
 if(view.k==='cut'){var xb=pr.X(view.cut.b[0],view.cut.b[1]),yL=top+.75;[[0,'A'],[xb,'B']].forEach(function(q){var cx=P.sx(q[0]),cy=P.sy(yL);g.beginPath();g.arc(cx,cy,10*k,0,6.2832);g.fillStyle='#fff';g.fill();g.strokeStyle='#111';g.lineWidth=1.4*k;g.stroke();g.fillStyle='#111';g.font='700 '+(12*k)+'px Arial';g.textAlign='center';g.fillText(q[1],cx,cy+4.3*k);g.strokeStyle='#111';g.setLineDash([8*k,4*k]);g.beginPath();g.moveTo(cx,cy+10*k);g.lineTo(cx,P.sy(-.1));g.stroke();g.setLineDash([])})}}
function legend(g,T,k,opt){if(!opt.w||!opt.h)return;var items=[['#ebe6da','Enduit'],['#b45f3c','Tuiles'],['#8fc1e3','Vitrage'],['#a16207','Menuiserie bois'],['#2b2b2b','Éléments coupés']],y=opt.h-12*k;
 g.font=(10*k)+'px Arial';g.textAlign='left';g.textBaseline='alphabetic';var tw=0;items.forEach(function(it){tw+=g.measureText(it[1]).width+30*k});var x=opt.w-tw-6*k;items.forEach(function(it){g.fillStyle=it[0];g.fillRect(x,y-8*k,10*k,10*k);g.strokeStyle='#555';g.lineWidth=.6*k;g.strokeRect(x,y-8*k,10*k,10*k);g.fillStyle='#222';g.fillText(it[1],x+14*k,y);x+=g.measureText(it[1]).width+30*k})}

/* repères de la ligne de coupe sur le plan (utilisé par l'éditeur) : retourne ses deux extrémités et la direction de vue */
function cutInfo(c){var dx=c.b[0]-c.a[0],dz=c.b[1]-c.a[1],L=Math.hypot(dx,dz)||1,ux=dx/L,uz=dz/L,fl=c.flip?-1:1;return{ux:ux,uz:uz,lx:uz*fl,lz:-ux*fl,L:L}}
/* ---- sortie vectorielle : un contexte 2D « enregistreur » récupère les tracés et les textes comme entités CAO ---- */
function recorder(){var E=[],stk=[],m=[1,0,0,1,0,0],path=[],cur=null,clipN=0;
 var o={fillStyle:'#000',strokeStyle:'#000',lineWidth:1,font:'10px Arial',textAlign:'left',textBaseline:'alphabetic',lineJoin:'miter'};
 function tp(x,y){return[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]]}
 function mul(n){m=[m[0]*n[0]+m[2]*n[1],m[1]*n[0]+m[3]*n[1],m[0]*n[2]+m[2]*n[3],m[1]*n[2]+m[3]*n[3],m[0]*n[4]+m[2]*n[5]+m[4],m[1]*n[4]+m[3]*n[5]+m[5]]}
 var CHL={'#8b5a2b':'CHEVRONS','#7c2d12':'FAITIERES','#4b5563':'PANNES','#b91c1c':'ARETIERS','#d4c9b5':'LITEAUX','#2a2a2a':'SABLIERES','#1d4ed8':'NOUES'};
 function lay(c){c=String(c).toLowerCase();if(CHL[c])return CHL[c];return c==='#444'?'COTES':(c==='#888'||c==='#999')?'NIVEAUX':(c==='#1b1b1b'||c==='#111'||c==='#000')?'CONTOURS':'DETAILS'}
 function sub(pts,closed){var a=pts.map(function(p){return tp(p[0],p[1])});a.closed=!!closed;return a}
 function rectSub(x,y,w,h){return sub([[x,y],[x+w,y],[x+w,y+h],[x,y+h]],true)}
 function emit(a,l){if(a.length>=2)E.push({t:'poly',l:l,pts:a,closed:a.closed})}
 function fs(){var mm=/([0-9.]+)px/.exec(o.font);return mm?parseFloat(mm[1]):10}
 o.beginPath=function(){path=[];cur=null};o.moveTo=function(x,y){cur=sub([[x,y]]);path.push(cur)};o.lineTo=function(x,y){if(!cur){cur=sub([[x,y]]);path.push(cur)}else cur.push(tp(x,y))};o.closePath=function(){if(cur)cur.closed=true};
 o.rect=function(x,y,w,h){path.push(rectSub(x,y,w,h));cur=null};
 o.arc=function(x,y,r,a0,a1){var c=tp(x,y);if(Math.abs((a1||0)-(a0||0))>6.2){path.push({circle:c,r:r*Math.hypot(m[0],m[1])})}else{var q=[],i;for(i=0;i<=16;i++){var a=a0+(a1-a0)*i/16;q.push([x+r*Math.cos(a),y+r*Math.sin(a)])}path.push(sub(q))}cur=null};
 o.ellipse=function(x,y,rx,ry,rot,a0,a1){var q=[],i;for(i=0;i<=32;i++){var a=a0+(a1-a0)*i/32;q.push([x+rx*Math.cos(a),y+ry*Math.sin(a)])}var s2=sub(q,true);path.push(s2);cur=null};
 o.stroke=function(){if(clipN)return;var l=lay(o.strokeStyle);path.forEach(function(p){if(p.circle)E.push({t:'circle',l:l,pts:[p.circle],r:p.r});else emit(p,l)})};
 o.fill=function(){if(clipN||o.fillStyle!=='#2b2b2b')return;path.forEach(function(p){if(!p.circle)emit(p,'POCHE')})};
 o.fillRect=function(x,y,w,h){if(clipN||o.fillStyle!=='#2b2b2b')return;emit(rectSub(x,y,w,h),'POCHE')};
 o.strokeRect=function(x,y,w,h){if(clipN)return;emit(rectSub(x,y,w,h),lay(o.strokeStyle))};
 o.fillText=function(s,x,y){if(clipN||s==null||s==='')return;var p=tp(x,y),h=fs()*Math.hypot(m[0],m[1]),w=String(s).length*h*.56,al='l',ang=Math.atan2(m[1],m[0])*180/Math.PI,dx=0;
  if(o.textAlign==='center')al='c';else if(o.textAlign==='right')dx=-w;p=[p[0]+dx*Math.cos(ang*Math.PI/180),p[1]+dx*Math.sin(ang*Math.PI/180)];
  E.push({t:'text',l:'COTES',pts:[p],h:h,s:String(s),al:al,rot:ang})};
 o.strokeText=function(){};o.measureText=function(s){return{width:String(s).length*fs()*.56}};
 o.save=function(){stk.push({m:m.slice(),c:clipN})};o.restore=function(){var q=stk.pop();if(q){m=q.m;clipN=q.c}};
 o.translate=function(x,y){mul([1,0,0,1,x,y])};o.rotate=function(a){mul([Math.cos(a),Math.sin(a),-Math.sin(a),Math.cos(a),0,0])};o.scale=function(x,y){mul([x,0,0,y,0,0])};o.setTransform=function(a,b,c,d,e,f){m=[a,b,c,d,e,f]};
 o.clip=function(){clipN++};o.setLineDash=function(){};o.createLinearGradient=function(){return{addColorStop:function(){}}};
 return{ctx:o,E:E}}
/* entités CAO d'une vue : map(X, altitude) → [x, y] du dessin CAO (x vers la droite, y vers le BAS comme le plan) */
function entities(S,view,o){o=o||{};var rec=recorder(),pre=o.prefix||'';render(rec.ctx,S,view,{s:100,ox:0,oy:0},{k:2,w:0,h:0,legend:false,hatch:false,dims:true,vector:true});
 function mp(p){return o.map(p[0]/100,-p[1]/100)}
 return rec.E.map(function(e){var r={t:e.t,l:pre+e.l};
  if(e.t==='poly')r.pts=e.pts.map(mp),r.closed=e.closed;
  else if(e.t==='circle'){var c=mp(e.pts[0]);r.x=c[0];r.y=c[1];r.r=e.r/100}
  else{var c2=mp(e.pts[0]);r.x=c2[0];r.y=c2[1];r.h=e.h/100;r.s=e.s;r.al=e.al;r.rot=e.rot}return r})}
var NAMES={N:'Façade Nord',S:'Façade Sud',E:'Façade Est',O:'Façade Ouest',cut:'Coupe A-A',cha:'Plan de charpente'};
w.EXBCOUPES={render:render,extent:extent,cutInfo:cutInfo,entities:entities,names:NAMES,nf:nf,_proj:proj,_roofFn:roofFn};
})(window);
