/* Excellencia Building — application Windows (Electron).
 * Le logiciel (dossier www/) est servi par un protocole interne « app://excellencia/ » :
 * adresse FIXE et sécurisée → IndexedDB, mots de passe/licences et sauvegardes locales restent toujours au même endroit
 * (avec un serveur à port aléatoire ou file://, les données « disparaîtraient » d'un lancement à l'autre). */
const { app, BrowserWindow, protocol, net, shell, session, Menu, ipcMain, dialog } = require('electron');
const path = require('path'), fs = require('fs'), { pathToFileURL } = require('url');

const ROOT = path.join(__dirname, 'www');
const HOST = 'excellencia';
protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win = null;
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function createWindow() {
  win = new BrowserWindow({
    width: 1366, height: 860, minWidth: 900, minHeight: 600, show: false, backgroundColor: '#ffffff',
    title: 'Excellencia Building',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, preload: path.join(__dirname, 'preload.js'), nodeIntegrationInSubFrames: true }
  });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  /* liens externes → navigateur ; pages internes (fiches, éditeur de plans…) → nouvelle fenêtre */
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (/^https?:/i.test(url)) { e.preventDefault(); shell.openExternal(url); }
  });
  /* F11 plein écran, F12 outils de développement (diagnostic) */
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    if (i.key === 'F12') { win.webContents.toggleDevTools(); e.preventDefault(); }
    /* Ctrl+P : même impression PDF avec aperçu que le bouton Imprimer (cadre actif : calcul, éditeur…) */
    if ((i.control || i.meta) && !i.alt && String(i.key).toLowerCase() === 'p') {
      e.preventDefault();
      try { (win.webContents.focusedFrame || win.webContents.mainFrame).executeJavaScript('window.print()'); } catch (x) {}
    }
  });
  win.on('closed', () => { win = null; });
  win.loadURL('app://' + HOST + '/index.html');
}

/* ---------- impression PDF (page copiée par preload.js → fenêtre cachée → PDF → enregistrement + ouverture) ---------- */
const PRINT_PAGES = new Map();
function safeName(t) { return String(t || 'Document').replace(/[\\/:*?"<>|\r\n]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120) || 'Document'; }
ipcMain.handle('exb:print', async (ev, o) => {
  let pw = null, token = null;
  try {
    if (!o || typeof o.html !== 'string' || o.html.length < 50) return { fallback: true };
    token = String(Date.now()) + Math.random().toString(36).slice(2);
    PRINT_PAGES.set(token, o.html);
    pw = new BrowserWindow({ show: false, width: 1100, height: 1400, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, javascript: false } });
    await pw.loadURL('app://' + HOST + '/__print/' + token + '.html');
    await new Promise((r) => setTimeout(r, 700)); /* laisse charger polices et images */
    const pdf = await pw.webContents.printToPDF({ printBackground: true, preferCSSPageSize: true, pageSize: 'A4', margins: { marginType: 'default' } });
    const parent = BrowserWindow.fromWebContents(ev.sender) || win;
    const r = await dialog.showSaveDialog(parent, { title: 'Enregistrer le PDF', defaultPath: path.join(app.getPath('documents'), safeName(o.title) + '.pdf'), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    fs.writeFileSync(r.filePath, pdf);
    shell.openPath(r.filePath); /* aperçu et impression papier depuis le lecteur PDF */
    return { ok: true, file: r.filePath };
  } catch (e) { return { fallback: true, error: String(e && e.message || e) }; }
  finally { if (token) PRINT_PAGES.delete(token); if (pw && !pw.isDestroyed()) pw.destroy(); }
});

/* ---------- Windows Hello (empreinte / visage / PIN) via PowerShell, sans module natif à compiler ---------- */
const { execFile } = require('child_process');
function helloScript(msg) {
  const m = String(msg || 'Excellencia Building').replace(/'/g, "''");
  return [
    "$ErrorActionPreference='Stop'",
    "Add-Type -AssemblyName System.Runtime.WindowsRuntime",
    "$null=[Windows.Security.Credentials.UI.UserConsentVerifier,Windows.Security.Credentials.UI,ContentType=WindowsRuntime]",
    "$at=([System.WindowsRuntimeSystemExtensions].GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'})[0]",
    "function Aw($op,$t){$k=$at.MakeGenericMethod($t).Invoke($null,@($op));$k.Wait(-1)|Out-Null;$k.Result}",
    "$a=Aw ([Windows.Security.Credentials.UI.UserConsentVerifier]::CheckAvailabilityAsync()) ([Windows.Security.Credentials.UI.UserConsentVerifierAvailability])",
    "if('" + '$MODE' + "' -eq 'check'){Write-Output ('AVAIL:'+$a);exit 0}",
    "if([string]$a -ne 'Available'){Write-Output ('UNAVAILABLE:'+$a);exit 0}",
    "$r=Aw ([Windows.Security.Credentials.UI.UserConsentVerifier]::RequestVerificationAsync('" + m + "')) ([Windows.Security.Credentials.UI.UserConsentVerificationResult])",
    "Write-Output ('RESULT:'+$r)"
  ].join(';');
}
function runHello(mode, msg) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve('UNAVAILABLE:NotWindows');
    const script = helloScript(msg).replace("'$MODE'", "'" + mode + "'");
    const enc = Buffer.from(script, 'utf16le').toString('base64');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', enc], { windowsHide: true, timeout: 120000 }, (err, out) => {
      resolve(err ? 'ERROR:' + (err.message || '') : String(out || '').trim().split(/\r?\n/).pop());
    });
  });
}
ipcMain.handle('exb:hello-available', async () => /^AVAIL:Available$/.test(await runHello('check')));
ipcMain.handle('exb:hello', async (ev, reason) => {
  const r = await runHello('verify', reason);
  if (r === 'RESULT:Verified') return { ok: true };
  if (/Canceled/.test(r)) return { ok: false, code: 'userCancel', msg: 'Vérification annulée.' };
  if (/NotConfigured|DeviceNotPresent|DisabledByPolicy|UNAVAILABLE/.test(r)) return { ok: false, code: 'biometryNotEnrolled', msg: 'Windows Hello indisponible.' };
  if (/RetriesExhausted/.test(r)) return { ok: false, code: 'lockout', msg: 'Trop d’essais.' };
  return { ok: false, code: 'error', msg: r || 'Échec de la vérification' };
});

app.whenReady().then(() => {
  protocol.handle('app', (req) => {
    try {
      const u = new URL(req.url);
      if (u.hostname !== HOST) return new Response('Not found', { status: 404 });
      let p = decodeURIComponent(u.pathname);
      const pm = /^\/__print\/([A-Za-z0-9]+)\.html$/.exec(p);
      if (pm) { const h = PRINT_PAGES.get(pm[1]); return h ? new Response(h, { headers: { 'content-type': 'text/html; charset=utf-8' } }) : new Response('Not found', { status: 404 }); }
      let f = path.normalize(path.join(ROOT, p));
      if (f !== ROOT && !f.startsWith(ROOT + path.sep)) return new Response('Forbidden', { status: 403 });
      if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
      if (!fs.existsSync(f)) return new Response('Not found', { status: 404 });
      return net.fetch(pathToFileURL(f).toString());
    } catch (e) { return new Response('Erreur : ' + e.message, { status: 500 }); }
  });
  /* caméra / micro (photos, signature, QR), presse-papiers, plein écran : autorisés pour le logiciel uniquement */
  const OK = new Set(['media', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen', 'notifications', 'geolocation']);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(OK.has(perm) && /^app:\/\//.test(wc.getURL())));
  createWindow();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
