/* Excellencia Building — barre du haut allégée (V119k)
 * Les boutons Plein écran ⛶, Intelligence 🧠, Aide ❓, Apparence 🎨 et Thème clair/sombre quittent la barre du haut
 * et rejoignent le menu flottant ⊞ (avec l'Assistant IA, les Licences clients, etc.).
 * Restent dans la barre : retour/avant, recherche, notifications 🔔 et profil de l'administrateur.
 * Aucun module existant n'est modifié : les boutons d'origine sont masqués et les nouvelles pastilles les déclenchent. */
(function (w, d) {
  'use strict';
  if (w.__exbTopbarHub) return; w.__exbTopbarHub = 1;
  var $ = function (i) { return d.getElementById(i); };
  /* [id du bouton d'origine, id de la pastille, libellé, action directe (facultative)] */
  var ITEMS = [
    ['xbIntel', 'tbhIntel', 'Excellencia Intelligence (BTP)', function () { return w.EXBI && w.EXBI.open && w.EXBI.open('ctl'); }],
    ['exbFocusBtn', 'tbhFocus', 'Plein écran', function () { return w.EXB_FOCUS && w.EXB_FOCUS.toggle(); }],
    ['xbAppear', 'tbhAppear', 'Apparence et couleurs', function () { return w.EXB_APPEAR && w.EXB_APPEAR.toggle(); }],
    ['xbTheme', 'tbhTheme', 'Thème clair / sombre', function () { return w.EXB_THEME && w.EXB_THEME.toggle(); }],
    ['xbHelp', 'tbhHelp', 'Aide rapide du logiciel', function () { return w.EXB_SHELL && w.EXB_SHELL.help(); }]
  ];
  function css() {
    if ($('exbTbhCss')) return;
    var s = d.createElement('style'); s.id = 'exbTbhCss';
    var hide = ITEMS.map(function (x) { return '#xbTop #' + x[0]; }).join(',');
    s.textContent = hide + '{display:none!important}' +
      /* le panneau « Apparence » s'ouvre sous la barre, à droite */
      '#xbTop .xbAp{position:fixed!important;top:62px;right:24px;width:0;height:0;display:block}#xbTop .xbAp #xbApPanel{top:0!important;right:0!important;z-index:100050}' +
      '.exb-tbh{position:fixed;right:14px;bottom:150px;z-index:100022;width:46px;height:46px;border-radius:50%;border:0;background:#173565;color:#fff;font:600 20px/1 system-ui,Arial,sans-serif;padding:0;box-shadow:0 4px 14px #0005;cursor:pointer;display:flex;align-items:center;justify-content:center}' +
      '.exb-tbh svg{width:22px;height:22px;display:block}.exb-tbh i{position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;border-radius:9px;background:#d32f2f;color:#fff;font:700 11px/18px system-ui,Arial,sans-serif;text-align:center;padding:0 4px;font-style:normal}.exb-tbh i:empty{display:none}' +
      '@media print{.exb-tbh{display:none!important}}';
    d.head.appendChild(s);
  }
  function make(it) {
    var b = d.createElement('button');
    b.id = it[1]; b.type = 'button'; b.className = 'exb-tbh no-print';
    b.setAttribute('data-exb-fab', it[1]); b.title = it[2]; b.setAttribute('aria-label', it[2]);
    b.addEventListener('click', function (e) {
      e.stopPropagation(); /* évite que le clic soit pris pour un « clic à l'extérieur » par le panneau qu'on ouvre */
      var o = $(it[0]), r;
      try { r = it[3](); } catch (x) {}
      if (r === undefined && o) try { o.click(); } catch (x) {}
    });
    d.body.appendChild(b);
    return b;
  }
  /* recopie l'icône et la pastille du bouton d'origine (🧠 avec compteur, lune/soleil selon le thème) */
  function sync() {
    if (d.hidden) return;                                   /* V141m : rien à faire quand la fenêtre est masquée */
    var ch = false;
    ITEMS.forEach(function (it) {
      var o = $(it[0]); if (!o) return;
      var b = $(it[1]); if (!b) { b = make(it); ch = true; }
      if (b.__src !== o.innerHTML) { b.__src = o.innerHTML; b.innerHTML = o.innerHTML; ch = true; }
    });
    /* le rendu du menu flottant force des mesures de mise en page (jusqu'à 500 ms) : seulement si quelque chose a changé, jamais pendant la saisie */
    var ae = d.activeElement, typing = ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName);
    if (ch && !typing && w.EXB_FAB && w.EXB_FAB.render) w.EXB_FAB.render();
  }
  function groupOnce() {
    /* une seule fois : on passe le menu flottant en mode « regroupé » (pastille ⊞) pour que ces boutons s'y rangent */
    try {
      if (w.localStorage.getItem('exb_tbh_v1')) return;
      if (w.EXB_FAB && w.EXB_FAB.setMode) { w.localStorage.setItem('exb_tbh_v1', '1'); if (w.EXB_FAB.state().mode !== 'group') w.EXB_FAB.setMode('group'); }
    } catch (e) {}
  }
  function start() { css(); sync(); groupOnce(); w.setInterval(sync, 1200); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
