/* Excellencia Building V128d — CALCUL → PLANS : « Envoyer vers Plans » après un export du calcul de structure.
 * Avant : exporter un DXF/IFC du calcul, l'enregistrer, ouvrir Plans, re-sélectionner le fichier (deux gestes manuels).
 * Maintenant : le téléchargement se fait comme avant (rien n'est retiré) ET un bandeau propose « Envoyer vers Plans » pour le chantier choisi.
 * Le fichier passe par le chemin habituel de Plans (EXBPLN.addFrom) : référence STR-… lue dans le fichier, indice suivant, liaison BIM/CDE.
 * Aucun chantier n'est deviné : il est présélectionné seulement s'il n'y en a qu'un, ou si c'est celui du dernier envoi. */
(function (w, d) {
  'use strict';
  var EXT = /\.(dxf|ifc|obj)$/i, LAST_KEY = 'exb_calc_plans_last', hooked = new WeakSet(), last = null;

  function store() { try { return w.exbStorage || w.localStorage; } catch (e) { return null; } }
  function projects() {
    try { if (typeof exbProjects !== 'undefined' && Array.isArray(exbProjects)) return exbProjects; } catch (e) {}
    try { var v = JSON.parse(store().getItem('exb_projects') || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function bar() {
    var b = d.getElementById('exbCalcPlansBar');
    if (!b) {
      b = d.createElement('div'); b.id = 'exbCalcPlansBar';
      b.style.cssText = 'position:fixed;left:8px;right:8px;bottom:8px;z-index:99990;background:#173565;color:#fff;border-radius:12px;padding:10px 12px;box-shadow:0 6px 24px #0005;display:none;font-size:13px;gap:8px;flex-wrap:wrap;align-items:center';
      (d.body || d.documentElement).appendChild(b);
    }
    return b;
  }
  function render() {
    var b = bar(); if (!last) { b.style.display = 'none'; return; }
    var P = projects().filter(function (p) { return p && p.id; }), pre = '';
    try { pre = store().getItem(LAST_KEY) || ''; } catch (e) {}
    if (!P.some(function (p) { return p.id === pre; })) pre = P.length === 1 ? P[0].id : '';
    b.innerHTML = '<span style="flex:1 1 200px">📐 <b>' + esc(last.name) + '</b> est prêt.</span>' +
      '<select id="exbCalcPlansSel" style="max-width:100%;padding:6px"><option value="">— Chantier —</option>' + P.map(function (p) { return '<option value="' + esc(p.id) + '"' + (p.id === pre ? ' selected' : '') + '>' + esc(p.name || p.id) + '</option>'; }).join('') + '</select>' +
      '<button type="button" id="exbCalcPlansGo" style="padding:7px 12px;border:0;border-radius:8px;background:#c49a38;color:#172033;font-weight:700;cursor:pointer">Envoyer vers Plans</button>' +
      '<button type="button" id="exbCalcPlansX" aria-label="Fermer" style="padding:7px 10px;border:0;border-radius:8px;background:#ffffff22;color:#fff;cursor:pointer">✕</button>';
    b.style.display = 'flex';
    d.getElementById('exbCalcPlansX').onclick = function () { last = null; render(); };
    d.getElementById('exbCalcPlansGo').onclick = send;
  }
  function say(m, t) { try { if (typeof w.notify === 'function') w.notify(m, t || 'info', 5000); } catch (e) {} }
  function send() {
    var s = d.getElementById('exbCalcPlansSel'), pid = s && s.value;
    if (!last) return;
    if (!pid) { say('Choisissez le chantier auquel rattacher ce plan.', 'warn'); return; }
    if (!w.EXBPLN || !w.EXBPLN.addFrom) { say('Le module Plans est indisponible.', 'error'); return; }
    var f; try { f = new File([last.blob], last.name, { type: last.blob.type || 'application/octet-stream' }); } catch (e) { say('Fichier illisible.', 'error'); return; }
    try { store().setItem(LAST_KEY, pid); } catch (e) {}
    var name = last.name; last = null; render();
    Promise.resolve(w.EXBPLN.addFrom(f, pid)).then(function () {
      try { if (w.EXBLIEN && w.EXBLIEN.log) w.EXBLIEN.log('calc_vers_plans', { file: name, project_id: pid }, 'Export du calcul envoyé vers Plans : ' + name); } catch (e) {}
    }).catch(function (e) { say('Envoi impossible : ' + (e && e.message || e), 'error'); });
  }
  function offer(name, blob) { if (!EXT.test(name || '') || !blob) return; last = { name: name, blob: blob }; render(); }

  /* branchement sur la fenêtre du calcul (même origine) : on observe ses téléchargements sans les empêcher */
  function hook(cw) {
    if (!cw || hooked.has(cw)) return; hooked.add(cw);
    try {
      var U = cw.URL, orig = U.createObjectURL, blobs = {};
      U.createObjectURL = function (b) { var u = orig.apply(this, arguments); try { blobs[u] = b; } catch (e) {} return u; };
      var A = cw.HTMLAnchorElement.prototype, oc = A.click;
      A.click = function () { try { if (this.download && EXT.test(this.download) && blobs[this.href]) offer(this.download, blobs[this.href]); } catch (e) {} return oc.apply(this, arguments); };
    } catch (e) {}
  }
  function scan() {
    try {
      var f = d.getElementById('exbCalcFrame'); if (!f) return;
      if (f.contentWindow && !hooked.has(f.contentWindow)) hook(f.contentWindow);
      if (!f.__exbCpl) { f.__exbCpl = 1; f.addEventListener('load', function () { try { hook(f.contentWindow); } catch (e) {} }); }
    } catch (e) {}
  }
  setInterval(scan, 1000); scan();
  w.EXBCALC2PLANS = { offer: offer, send: send, hook: hook, last: function () { return last; } };
})(window, document);
