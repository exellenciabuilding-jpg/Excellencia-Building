/* Centre documentaire — interface des 9 rubriques (V118). Aucune logique de rendu ici : tout passe par EXBDoc. */
(function (w, d) {
  'use strict';
  var D = w.EXBDoc, C = w.EXBDocCore, esc = C.esc, main = d.getElementById('main');
  var TABS = [['dash', 'Tableau de bord'], ['profil', 'Mon profil documentaire'], ['entreprise', 'Mon entreprise'], ['identite', 'Mon identité visuelle'], ['modeles', 'Mes modèles de documents'], ['gen', 'Générateur PDF'], ['public', 'Formulaires publics'], ['histo', 'Historique des documents'], ['params', 'Paramètres et permissions']];
  var CATS = { finance: 'Finance', technique: 'Technique & chantier', geotechnique: 'Géotechnique', administratif: 'Administratif', formation: 'Formation & séances', commercial: 'Commercial' };
  var ROLE = 'admin', cur = 'dash', gen = { type: null, model: '', data: {}, options: {}, interactive: false };
  var $ = function (s, r) { return (r || d).querySelector(s); }, $$ = function (s, r) { return [].slice.call((r || d).querySelectorAll(s)); };
  function el(html) { var t = d.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; }
  function msg(host, text, kind) { var m = $('.msg', host); if (m) m.remove(); host.insertBefore(el('<div class="msg ' + (kind || 'info') + '">' + esc(text) + '</div>'), host.firstChild.nextSibling); setTimeout(function () { var x = $('.msg', host); if (x) x.remove(); }, 9000); }
  function head(t, s) { return '<div class="hd"><h1>' + esc(t) + '</h1><p class="sub">' + esc(s) + '</p></div>'; }

  /* ---------- images : redimensionnées et converties en data: avant stockage ---------- */
  function readImage(file, max, keepAlpha) {
    return new Promise(function (ok, ko) {
      if (!file || !/^image\//.test(file.type)) return ko(new Error('Choisissez un fichier image (PNG, JPEG, WebP).'));
      var r = new FileReader(); r.onerror = function () { ko(new Error('Lecture impossible.')); };
      r.onload = function () { var im = new Image(); im.onerror = function () { ko(new Error('Image illisible.')); }; im.onload = function () {
        var k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
        var x = c.getContext('2d'); if (!keepAlpha) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); } x.drawImage(im, 0, 0, c.width, c.height); ok(keepAlpha ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', .9)); }; im.src = r.result; };
      r.readAsDataURL(file);
    });
  }
  function imgField(label, key, p, max, alpha) {
    return '<label>' + label + '</label><div class="img-box"><div class="th">' + (p[key] ? '<img src="' + esc(p[key]) + '" alt="">' : '<small>aucune</small>') + '</div><div><input type="file" accept="image/*" data-img="' + key + '" data-max="' + max + '" data-alpha="' + (alpha ? 1 : 0) + '">' + (p[key] ? '<button class="btn ghost sm" data-clear="' + key + '" style="margin-top:6px">Retirer</button>' : '') + '</div></div>';
  }
  function listEdit(id, items, ph) { return '<div class="list-edit" id="' + id + '">' + items.map(function (v) { return '<div class="it"><input value="' + esc(v) + '" placeholder="' + esc(ph) + '"><button class="btn ghost sm" data-rm>✕</button></div>'; }).join('') + '</div><button class="btn ghost sm" data-add="' + id + '" data-ph="' + esc(ph) + '">+ Ajouter</button>'; }
  function pairEdit(id, items, ph1, ph2) { return '<div class="list-edit" id="' + id + '">' + items.map(function (v) { return '<div class="it"><input value="' + esc(v.label) + '" placeholder="' + esc(ph1) + '" style="max-width:35%"><input value="' + esc(v.value) + '" placeholder="' + esc(ph2) + '"><button class="btn ghost sm" data-rm>✕</button></div>'; }).join('') + '</div><button class="btn ghost sm" data-addpair="' + id + '" data-ph1="' + esc(ph1) + '" data-ph2="' + esc(ph2) + '">+ Ajouter</button>'; }
  function wireLists(host) {
    host.addEventListener('click', function (e) {
      var t = e.target; if (t.matches('[data-rm]')) t.parentNode.remove();
      if (t.matches('[data-add]')) { $('#' + t.dataset.add, host).appendChild(el('<div class="it"><input placeholder="' + esc(t.dataset.ph) + '"><button class="btn ghost sm" data-rm>✕</button></div>')); }
      if (t.matches('[data-addpair]')) { $('#' + t.dataset.addpair, host).appendChild(el('<div class="it"><input placeholder="' + esc(t.dataset.ph1) + '" style="max-width:35%"><input placeholder="' + esc(t.dataset.ph2) + '"><button class="btn ghost sm" data-rm>✕</button></div>')); }
    });
  }
  var listVals = function (host, id) { return $$('#' + id + ' .it', host).map(function (r) { return $('input', r).value.trim(); }).filter(Boolean); };
  var pairVals = function (host, id) { return $$('#' + id + ' .it', host).map(function (r) { var i = $$('input', r); return { label: i[0].value.trim(), value: i[1].value.trim() }; }).filter(function (x) { return x.label || x.value; }); };

  /* ---------- 1. tableau de bord ---------- */
  async function dash() {
    var p = D.profile.get(), h = await D.history.list({ limit: 8 }), fields = [p.name, p.logo, p.address, p.phones.length, p.emails.length, p.ids.length, p.signature, p.stamp, p.signatory.name], pct = Math.round(fields.filter(Boolean).length / fields.length * 100);
    var tpls = D.templates(), top = ['devis', 'facture', 'recu', 'rapport-chantier', 'attestation', 'planning-seances'];
    main.innerHTML = head('Tableau de bord', 'Une seule configuration, tous les documents de la plateforme.') +
      '<div class="grid g3"><div class="kpi"><b>' + h.total + '</b><span>documents émis' + (h.remote ? '' : ' (cet appareil)') + '</span></div><div class="kpi"><b>' + tpls.length + '</b><span>modèles disponibles</span></div><div class="kpi"><b>' + pct + ' %</b><span>profil documentaire complet</span><div class="bar" style="margin-top:6px"><i style="width:' + pct + '%"></i></div></div></div>' +
      '<div class="card" style="margin-top:14px"><h3>Créer un document</h3><div class="grid g3">' + top.map(function (id) { var t = D.describe(id); return '<div class="tpl" data-new="' + id + '"><b>' + esc(t.label) + '</b><small>' + esc(t.description) + '</small></div>'; }).join('') + '</div></div>' +
      '<div class="card"><h3>Derniers documents</h3>' + (h.items.length ? '<table><tr><th>N°</th><th>Document</th><th>Date</th></tr>' + h.items.map(function (r) { return '<tr><td>' + esc(r.number || '—') + '</td><td>' + esc(r.title) + '</td><td>' + esc((r.created_at || '').slice(0, 10)) + '</td></tr>'; }).join('') + '</table>' : '<p class="sub">Aucun document pour l’instant.</p>') + '</div>' +
      (p.name ? '' : '<div class="msg info">Commencez par renseigner <b>Mon entreprise</b> : ces informations seront reprises automatiquement par tous les documents.</div>');
    $$('[data-new]').forEach(function (n) { n.onclick = function () { gen.type = n.dataset.new; gen.data = {}; show('gen'); }; });
  }

  /* ---------- 2. profil documentaire ---------- */
  function profil() {
    var p = D.profile.get(), mods = ['Devis', 'Facturation', 'Formations', 'Séances', 'Ressources', 'Géotechnique', 'Chantiers', 'Attestations', 'Certificats', 'Formulaires'];
    main.innerHTML = head('Mon profil documentaire', 'L’identité de votre organisation, réutilisée automatiquement par tous les modules.') +
      '<div class="card"><h3>Aperçu de l’en-tête</h3><iframe class="pv" id="pvHead" style="position:static;height:300px"></iframe></div>' +
      '<div class="card"><h3>Synchronisation automatique</h3><p>Toute modification enregistrée dans <b>Mon entreprise</b> ou <b>Mon identité visuelle</b> est appliquée aux <b>nouveaux</b> documents de chaque module, sans nouvelle saisie. Les documents déjà émis peuvent être <b>régénérés</b> avec le profil à jour depuis l’historique (même numéro).</p><div class="row">' + mods.map(function (m) { return '<span class="chip">' + m + '</span>'; }).join('') + '</div>' +
      '<p class="sub" style="margin-top:10px">Mode : <b>' + (D.config.connected() ? 'centralisé (par organisation)' : 'local (cet appareil)') + '</b>. Chaque organisation possède son propre profil, sans mélange avec les autres.</p></div>';
    D.preview('document-libre', { titre: 'Aperçu', blocs: [{ type: 'paragraphe', contenu: 'Voici l’en-tête de vos documents.' }] }, { lenient: true, local: true }).then(function (h) { $('#pvHead').srcdoc = h; });
  }

  /* ---------- 3. entreprise ---------- */
  function entreprise() {
    var p = D.profile.get(), ro = ROLE !== 'admin';
    main.innerHTML = head('Mon entreprise', 'Coordonnées et informations légales, modifiables à tout moment.') + '<div id="f"></div>';
    var f = $('#f');
    f.innerHTML = '<div class="grid g2"><div class="card"><h3>Identité</h3><label>Nom de l’organisation *</label><input id="name" value="' + esc(p.name) + '"><label>Raison sociale complète</label><input id="legal_name" value="' + esc(p.legal_name) + '"><label>Slogan / activité</label><input id="tagline" value="' + esc(p.tagline) + '"><label>Site web</label><input id="website" value="' + esc(p.website) + '"></div>' +
      '<div class="card"><h3>Adresse</h3><label>Adresse</label><input id="address" value="' + esc(p.address) + '"><label>Ville</label><input id="city" value="' + esc(p.city) + '"><label>Pays</label><input id="country" value="' + esc(p.country) + '"></div></div>' +
      '<div class="grid g2"><div class="card"><h3>Téléphones</h3>' + listEdit('phones', p.phones, '+243 …') + '</div><div class="card"><h3>Adresses e-mail</h3>' + listEdit('emails', p.emails, 'contact@…') + '</div></div>' +
      '<div class="card"><h3>Numéros d’identification et informations légales</h3>' + pairEdit('ids', p.ids, 'RCCM, Id. Nat., NIF…', 'Numéro') + '<label>Mentions légales (pied de page)</label><textarea id="legal">' + esc(p.legal) + '</textarea><label>Coordonnées bancaires (affichées sur les factures)</label><textarea id="bank">' + esc(p.bank) + '</textarea>' +
      '<div class="grid g3"><div><label>Devise par défaut</label><select id="currency">' + ['USD', 'EUR', 'CDF', 'XOF', 'XAF'].map(function (c) { return '<option' + (c === p.currency ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select></div><div><label>Signataire</label><input id="sg_name" value="' + esc(p.signatory.name) + '"></div><div><label>Fonction du signataire</label><input id="sg_role" value="' + esc(p.signatory.role) + '"></div></div><label>Texte de pied de page supplémentaire</label><input id="footer_text" value="' + esc(p.footer_text) + '"></div>' +
      '<div class="card"><h3>Informations complémentaires</h3>' + pairEdit('extra', p.extra, 'Intitulé', 'Valeur') + '</div>' +
      '<div class="row end"><button class="btn gold" id="save"' + (ro ? ' disabled title="Réservé aux administrateurs"' : '') + '>Enregistrer</button></div>';
    wireLists(f);
    $('#save').onclick = async function () {
      var np = Object.assign({}, D.profile.get(), { name: $('#name').value, legal_name: $('#legal_name').value, tagline: $('#tagline').value, website: $('#website').value, address: $('#address').value, city: $('#city').value, country: $('#country').value, phones: listVals(f, 'phones'), emails: listVals(f, 'emails'), ids: pairVals(f, 'ids'), legal: $('#legal').value, bank: $('#bank').value, currency: $('#currency').value, signatory: { name: $('#sg_name').value, role: $('#sg_role').value }, footer_text: $('#footer_text').value, extra: pairVals(f, 'extra') });
      try { var r = await D.profile.save(np); msg(f, r.remote ? 'Profil enregistré et synchronisé pour toute l’organisation.' : 'Profil enregistré sur cet appareil.', 'ok'); refreshSide(); } catch (e) { msg(f, e.message, 'err'); }
    };
  }

  /* ---------- 4. identité visuelle ---------- */
  function identite() {
    var p = D.profile.get(), ro = ROLE !== 'admin';
    main.innerHTML = head('Mon identité visuelle', 'Logo, couleurs institutionnelles, signature et cachet.') +
      '<div class="split"><div><div class="card"><h3>Logo</h3>' + imgField('Logo officiel (PNG/JPEG/WebP)', 'logo', p, 600, true) + '</div><div class="card"><h3>Couleurs institutionnelles</h3><div class="grid g3"><div><label>Principale</label><input type="color" id="c1" value="' + p.colors.primary + '"></div><div><label>Accent (or)</label><input type="color" id="c2" value="' + p.colors.accent + '"></div><div><label>Secondaire</label><input type="color" id="c3" value="' + p.colors.secondary + '"></div></div><p class="sub">Par défaut : bleu marine et détails dorés d’Excellencia Building.</p></div>' +
      '<div class="card"><h3>Signature et cachet</h3>' + imgField('Signature (fond transparent recommandé)', 'signature', p, 500, true) + imgField('Cachet', 'stamp', p, 400, true) + '</div>' +
      '<div class="row end"><button class="btn gold" id="save"' + (ro ? ' disabled title="Réservé aux administrateurs"' : '') + '>Enregistrer</button></div></div>' +
      '<div><iframe class="pv" id="pv"></iframe></div></div>';
    var work = Object.assign({}, p);
    function pv() { var c = { primary: $('#c1').value, accent: $('#c2').value, secondary: $('#c3').value }; work.colors = c; var core = C.render('attestation', { beneficiaire: 'Nom du bénéficiaire', qualite: 'Fonction', texte: 'Exemple de document avec votre en-tête, vos couleurs, votre signature et votre cachet.' }, { profile: work, number: 'ATT-APERÇU', mode: 'screen', lenient: true }); $('#pv').srcdoc = core.html; }
    $$('input[type=file][data-img]').forEach(function (i) { i.onchange = function () { readImage(i.files[0], +i.dataset.max, i.dataset.alpha === '1').then(function (u) { work[i.dataset.img] = u; var th = i.closest('.img-box').querySelector('.th'); th.innerHTML = '<img src="' + u + '" alt="">'; pv(); }).catch(function (e) { msg(main, e.message, 'err'); }); }; });
    $$('[data-clear]').forEach(function (b) { b.onclick = function () { work[b.dataset.clear] = ''; b.closest('.img-box').querySelector('.th').innerHTML = '<small>aucune</small>'; pv(); }; });
    ['c1', 'c2', 'c3'].forEach(function (i) { $('#' + i).oninput = pv; }); pv();
    $('#save').onclick = async function () { try { var r = await D.profile.save(Object.assign({}, D.profile.get(), { logo: work.logo, signature: work.signature, stamp: work.stamp, colors: work.colors })); msg(main, r.remote ? 'Identité enregistrée et synchronisée.' : 'Identité enregistrée sur cet appareil.', 'ok'); refreshSide(); } catch (e) { msg(main, e.message, 'err'); } };
  }

  /* ---------- 5. modèles ---------- */
  async function modeles() {
    var models = await D.models.list(), by = {};
    D.templates().forEach(function (t) { (by[t.category] = by[t.category] || []).push(t); });
    main.innerHTML = head('Mes modèles de documents', 'Catalogue des modèles et variantes personnalisées de votre organisation.') +
      Object.keys(by).map(function (c) { return '<div class="card"><h3>' + esc(CATS[c] || c) + '</h3><div class="grid g3">' + by[c].map(function (t) { return '<div class="tpl" data-new="' + t.id + '"><b>' + esc(t.label) + '</b><small>' + esc(t.description) + '</small>' + (t.interactive ? '<br><span class="chip">PDF interactif</span>' : '') + '</div>'; }).join('') + '</div></div>'; }).join('') +
      '<div class="card"><h3>Modèles personnalisés</h3>' + (models.length ? '<table><tr><th>Nom</th><th>Basé sur</th><th></th></tr>' + models.map(function (m) { return '<tr><td>' + esc(m.name) + '</td><td>' + esc((D.describe(m.type) || {}).label || m.type) + '</td><td class="row end"><button class="btn ghost sm" data-use="' + esc(m.id) + '" data-type="' + esc(m.type) + '">Utiliser</button><button class="btn ghost sm" data-edit="' + esc(m.id) + '">Modifier</button><button class="btn red sm" data-del="' + esc(m.id) + '">Supprimer</button></td></tr>'; }).join('') + '</table>' : '<p class="sub">Aucun modèle personnalisé.</p>') + '<button class="btn gold" id="newModel" style="margin-top:10px">+ Nouveau modèle personnalisé</button><div id="mf"></div></div>';
    $$('[data-new]').forEach(function (n) { n.onclick = function () { gen.type = n.dataset.new; gen.model = ''; gen.data = {}; show('gen'); }; });
    $$('[data-use]').forEach(function (b) { b.onclick = function () { gen.type = b.dataset.type; gen.model = b.dataset.use; gen.data = {}; show('gen'); }; });
    $$('[data-del]').forEach(function (b) { b.onclick = async function () { if (!confirm('Supprimer ce modèle ?')) return; try { await D.models.remove(b.dataset.del); modeles(); } catch (e) { msg(main, e.message, 'err'); } }; });
    $$('[data-edit]').forEach(function (b) { b.onclick = function () { modelForm(models.find(function (m) { return m.id === b.dataset.edit; })); }; });
    $('#newModel').onclick = function () { modelForm(null); };
  }
  function modelForm(m) {
    m = m || { type: 'devis', name: '', options: {} }; var o = m.options || {}, host = $('#mf');
    host.innerHTML = '<hr><div class="grid g2"><div><label>Nom du modèle *</label><input id="mn" value="' + esc(m.name) + '"><label>Type de document</label><select id="mt">' + D.templates().map(function (t) { return '<option value="' + t.id + '"' + (t.id === m.type ? ' selected' : '') + '>' + esc(t.label) + '</option>'; }).join('') + '</select><label>Mise en page</label><select id="ml">' + [['classique', 'Classique (en-tête et filet doré)'], ['bandeau', 'Bandeau bleu marine'], ['sobre', 'Sobre']].map(function (x) { return '<option value="' + x[0] + '"' + (o.layout === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select><label>Format de page</label><select id="mps">' + [['', 'Selon le document'], ['A4', 'A4'], ['A3', 'A3'], ['A5', 'A5'], ['Letter', 'Letter'], ['Legal', 'Legal']].map(function (x) { return '<option value="' + x[0] + '"' + ((o.page_size || '') === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select><label>Orientation</label><select id="mpo">' + [['', 'Selon le document'], ['portrait', 'Portrait'], ['landscape', 'Paysage']].map(function (x) { return '<option value="' + x[0] + '"' + ((o.page_orientation || '') === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select><label>Filigrane</label><select id="mw">' + [['', 'Selon le statut (brouillon, annulé…)'], ['none', 'Aucun'], ['name', 'Nom de l’organisation'], ['custom', 'Texte personnalisé']].map(function (x) { return '<option value="' + x[0] + '"' + ((o.watermark || '') === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select><label>Texte du filigrane</label><input id="mwt" value="' + esc(o.watermark_text || '') + '"></div>' +
      '<div><label>Introduction (en tête du contenu)</label><textarea id="mi">' + esc(o.intro || '') + '</textarea><label>Conclusion / mention finale</label><textarea id="mc">' + esc(o.conclusion || '') + '</textarea><label>Libellés de signatures (un par ligne, 4 max)</label><textarea id="ms" style="min-height:60px">' + esc((o.signature_labels || []).join('\n')) + '</textarea>' +
      ['show_logo:Afficher le logo', 'show_page_numbers:Numérotation des pages', 'show_signatures:Blocs de signature', 'use_signature:Apposer signature et cachet'].map(function (x) { var k = x.split(':')[0]; return '<label style="font-weight:400"><input type="checkbox" data-o="' + k + '"' + (o[k] === false ? '' : ' checked') + '> ' + x.split(':')[1] + '</label>'; }).join('') + '</div></div><div class="row end"><button class="btn ghost" id="mx">Annuler</button><button class="btn gold" id="ms2">Enregistrer le modèle</button></div>';
    $('#mx').onclick = function () { host.innerHTML = ''; };
    $('#ms2').onclick = async function () {
      var op = { layout: $('#ml').value, page_size: $('#mps').value || undefined, page_orientation: $('#mpo').value || undefined, watermark: $('#mw').value || undefined, watermark_text: $('#mwt').value, intro: $('#mi').value, conclusion: $('#mc').value, signature_labels: $('#ms').value.split('\n').map(function (x) { return x.trim(); }).filter(Boolean) };
      $$('[data-o]', host).forEach(function (c) { op[c.dataset.o] = c.checked; });
      try { await D.models.save({ id: m.id, type: $('#mt').value, name: $('#mn').value, options: op }); modeles(); } catch (e) { msg(host, e.message, 'err'); }
    };
  }

  /* ---------- 6. générateur ---------- */
  function fieldInput(f, v, id) {
    v = v == null ? '' : v;
    if (f.type === 'textarea') return '<textarea id="' + id + '">' + esc(v) + '</textarea>';
    if (f.type === 'select') return '<select id="' + id + '"><option value=""></option>' + f.options.map(function (o) { return '<option' + (o === v ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>';
    if (f.type === 'image') return '<input type="file" accept="image/*" id="' + id + '">';
    return '<input id="' + id + '" type="' + (f.type === 'number' ? 'number" step="any' : f.type === 'date' ? 'date' : 'text') + '" value="' + esc(v) + '">';
  }
  function gather(t, host) {
    var data = Object.assign({}, gen.data);
    t.fields.forEach(function (f) { if (f.type === 'image') return; var e = $('#g_' + f.k, host); if (e) data[f.k] = e.value; });
    t.tables.forEach(function (tb) { data[tb.k] = $$('#t_' + tb.k + ' tr.dr', host).map(function (tr) { var r = {}; tb.columns.forEach(function (c, i) { if (c.type === 'image') r[c.k] = tr.dataset['img' + i] || ''; else { var e = tr.children[i].firstChild; r[c.k] = e ? e.value : ''; } }); return r; }); });
    if ($('#g_status', host)) data.status = $('#g_status', host).value;
    if (!data.date && $('#g_date0', host)) data.date = $('#g_date0', host).value;
    return data;
  }
  function tableEditor(tb, rows) {
    var cols = tb.columns;
    function row(r, i) { return '<tr class="dr">' + cols.map(function (c, ci) { var v = r ? (r[c.k] == null ? '' : r[c.k]) : ''; return '<td>' + (c.type === 'textarea' ? '<textarea style="min-height:48px">' + esc(v) + '</textarea>' : c.type === 'select' ? '<select>' + c.options.map(function (o) { return '<option' + (o === v ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '</select>' : c.type === 'image' ? '<input type="file" accept="image/*" data-imgcol="' + ci + '">' : '<input ' + (c.type === 'number' ? 'type="number" step="any"' : c.type === 'date' ? 'type="date"' : '') + ' value="' + esc(v) + '">') + '</td>'; }).join('') + '<td><button class="btn ghost sm" data-rmrow>✕</button></td></tr>'; }
    return '<div class="card"><h3>' + esc(tb.label) + '</h3><div style="overflow:auto"><table id="t_' + tb.k + '"><tr>' + cols.map(function (c) { return '<th>' + esc(c.label.length > 30 ? c.label.slice(0, 28) + '…' : c.label) + '</th>'; }).join('') + '<th></th></tr>' + (rows && rows.length ? rows.map(row).join('') : row(null)) + '</table></div><button class="btn ghost sm" data-addrow="' + tb.k + '" style="margin-top:8px">+ Ligne</button></div>';
  }
  /* V144g : format / orientation choisis pour ce document (priment sur le modèle) */
  function pgOpt() { var o = {}, a = $('#g_psz'), b = $('#g_por'); if (a && a.value) o.page_size = a.value; if (b && b.value) o.page_orientation = b.value; gen.options = o; return o; }
  async function generateur() {
    var tpls = D.templates(), models = await D.models.list();
    if (!gen.type) gen.type = 'devis';
    var t = D.describe(gen.type), groups = {};
    t.fields.forEach(function (f) { (groups[f.group || 'Informations'] = groups[f.group || 'Informations'] || []).push(f); });
    main.innerHTML = head('Générateur PDF', 'Choisissez un modèle, saisissez le contenu : l’en-tête, la numérotation et les signatures viennent de votre profil.') +
      '<div class="split"><div id="gf"><div class="card"><div class="grid g2"><div><label>Modèle de document</label><select id="gt">' + Object.keys(CATS).map(function (c) { var l = tpls.filter(function (x) { return x.category === c; }); return l.length ? '<optgroup label="' + esc(CATS[c]) + '">' + l.map(function (x) { return '<option value="' + x.id + '"' + (x.id === gen.type ? ' selected' : '') + '>' + esc(x.label) + '</option>'; }).join('') + '</optgroup>' : ''; }).join('') + '</select></div>' +
      '<div><label>Variante personnalisée</label><select id="gm"><option value="">Standard</option>' + models.filter(function (m) { return m.type === gen.type; }).map(function (m) { return '<option value="' + esc(m.id) + '"' + (m.id === gen.model ? ' selected' : '') + '>' + esc(m.name) + '</option>'; }).join('') + '</select></div></div>' +
      '<div class="grid g2"><div><label>Format de page</label><select id="g_psz">' + [['', 'Selon le document'], ['A4', 'A4'], ['A3', 'A3'], ['A5', 'A5'], ['Letter', 'Letter'], ['Legal', 'Legal']].map(function (x) { return '<option value="' + x[0] + '"' + ((gen.options.page_size || '') === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div><div><label>Orientation</label><select id="g_por">' + [['', 'Selon le document'], ['portrait', 'Portrait'], ['landscape', 'Paysage']].map(function (x) { return '<option value="' + x[0] + '"' + ((gen.options.page_orientation || '') === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div></div>' +
      '<div class="grid g2"><div><label>Date du document</label><input type="date" id="g_date0" value="' + esc(gen.data.date || C.todayISO()) + '"></div><div><label>Statut / filigrane</label><select id="g_status"><option value="">Document définitif</option>' + [['brouillon', 'Brouillon'], ['duplicata', 'Duplicata'], ['copie', 'Copie'], ['annulé', 'Annulé']].map(function (x) { return '<option value="' + x[0] + '"' + (gen.data.status === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div></div>' +
      (t.interactive ? '<label style="font-weight:400"><input type="checkbox" id="gi"' + (gen.interactive ? ' checked' : '') + '> PDF interactif (champs remplissables à l’écran)' + (D.config.connected() ? '' : ' — nécessite le serveur documentaire') + '</label>' : '') + '</div>' +
      Object.keys(groups).map(function (g) { return '<div class="card"><h3>' + esc(g) + '</h3>' + groups[g].map(function (f) { return '<label>' + esc(f.label) + (f.required ? ' *' : '') + '</label>' + fieldInput(f, gen.data[f.k] != null ? gen.data[f.k] : (t.defaults || {})[f.k], 'g_' + f.k); }).join('') + '</div>'; }).join('') +
      t.tables.map(function (tb) { return tableEditor(tb, gen.data[tb.k] || (t.defaults || {})[tb.k]); }).join('') +
      '<div class="row end"><button class="btn ghost" id="gp">Actualiser l’aperçu</button><button class="btn gold" id="gg">Générer le PDF</button></div></div><div><iframe class="pv" id="pv"></iframe></div></div>';
    var host = $('#gf');
    $('#gt').onchange = function () { gen.type = this.value; gen.model = ''; gen.data = {}; generateur(); };
    $('#gm').onchange = function () { gen.model = this.value; preview(); };
    $('#g_psz').onchange = $('#g_por').onchange = function () { preview(); };
    host.addEventListener('click', function (e) {
      var b = e.target;
      if (b.matches('[data-rmrow]')) { var tb = b.closest('table'); if ($$('tr.dr', tb).length > 1) b.closest('tr').remove(); else $$('input,textarea', b.closest('tr')).forEach(function (i) { i.value = ''; }); }
      if (b.matches('[data-addrow]')) { var tab = $('#t_' + b.dataset.addrow, host), tr = $$('tr.dr', tab)[0].cloneNode(true); $$('input,textarea', tr).forEach(function (i) { if (i.type !== 'file') i.value = ''; }); delete tr.dataset.img2; tab.appendChild(tr); }
    });
    host.addEventListener('change', function (e) { var i = e.target; if (i.matches('[data-imgcol]')) readImage(i.files[0], 900, false).then(function (u) { i.closest('tr').dataset['img' + i.dataset.imgcol] = u; preview(); }).catch(function (er) { msg(host, er.message, 'err'); }); if (i.type === 'file' && i.id && i.id.indexOf('g_') === 0) readImage(i.files[0], 900, false).then(function (u) { gen.data[i.id.slice(2)] = u; preview(); }); });
    var timer; host.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(preview, 700); });
    async function preview() { var data = gather(t, host); gen.data = data; try { $('#pv').srcdoc = await D.preview(gen.type, data, { model_id: gen.model || undefined, options: pgOpt(), lenient: true }); } catch (e) { msg(host, e.message, 'err'); } }
    $('#gp').onclick = preview;
    $('#gg').onclick = async function () {
      var data = gather(t, host); gen.data = data; gen.interactive = !!($('#gi') && $('#gi').checked); var b = this; b.disabled = true;
      try { var r = await D.generate(gen.type, data, { model_id: gen.model || undefined, options: pgOpt(), interactive: gen.interactive, source: 'centre', action: 'download' }); msg(host, r.via === 'server' ? 'PDF généré : ' + (r.number || r.filename) : 'Document ' + (r.number || '') + ' envoyé à l’impression (mode local).', 'ok'); }
      catch (e) { msg(host, e.message + (e.details ? ' — ' + e.details.join(' ; ') : ''), 'err'); } finally { b.disabled = false; }
    };
    preview();
  }

  /* ---------- 7. formulaires publics ---------- */
  async function publics() {
    var forms = await D.publicForms.forms(), base = location.href.replace(/[^\/]*$/, '') + 'formulaires-publics.html', cats = {};
    forms.forEach(function (f) { f.categories.forEach(function (c) { (cats[c] = cats[c] || []).push(f); }); });
    var LAB = { apprenant: 'Apprenants', client: 'Clients', chantier: 'Chantiers', formateur: 'Formateurs', entreprise: 'Entreprises' };
    main.innerHTML = head('Formulaires publics', 'Liens à partager : chaque catégorie et chaque formulaire a son adresse. Aucun compte requis.') +
      '<div class="card"><h3>Tous les formulaires</h3><code class="url">' + esc(base) + '</code></div>' +
      Object.keys(cats).map(function (c) { return '<div class="card"><h3>' + esc(LAB[c] || c) + '</h3><p class="sub">Lien de la catégorie</p><code class="url">' + esc(base + '?cat=' + c) + '</code>' + cats[c].map(function (f) { return '<p style="margin:10px 0 2px"><b>' + esc(f.title) + '</b> ' + (f.interactive ? '<span class="chip">PDF interactif</span>' : '') + '</p><code class="url">' + esc(base + '?f=' + f.slug) + '</code>'; }).join('') + '</div>'; }).join('') +
      '<div class="msg info">Ces pages fonctionnent avec le serveur documentaire (génération Chromium). ' + (D.config.serverUrl() ? 'Serveur configuré : ' + esc(D.config.serverUrl()) : 'Serveur non configuré : voir « Paramètres et permissions ».') + '</div>';
  }

  /* ---------- 8. historique ---------- */
  async function histo() {
    var h = await D.history.list({ limit: 100 });
    main.innerHTML = head('Historique des documents', h.remote ? 'Documents émis par votre organisation.' : 'Documents émis depuis cet appareil.') +
      '<div class="card"><input id="hq" placeholder="Rechercher un numéro ou un titre…" style="max-width:340px;margin-bottom:10px">' + (h.items.length ? '<div style="overflow:auto"><table id="ht"><tr><th>N°</th><th>Document</th><th>Objet</th><th>Date</th><th>Origine</th><th></th></tr>' + h.items.map(function (r, i) { return '<tr data-i="' + i + '"><td>' + esc(r.number || '—') + '</td><td>' + esc(r.title) + '</td><td>' + esc(r.subject || '') + '</td><td>' + esc((r.created_at || '').slice(0, 10)) + '</td><td>' + esc(r.source || '') + '</td><td class="row end"><button class="btn ghost sm" data-o="' + i + '">Ouvrir</button>' + (r.local ? '' : '<button class="btn ghost sm" data-r="' + i + '" title="Régénérer avec le profil à jour">↻ Mettre à jour</button>') + '<button class="btn red sm" data-d="' + i + '">✕</button></td></tr>'; }).join('') + '</table></div>' : '<p class="sub">Aucun document.</p>') + '</div>';
    var q = $('#hq'); if (q) q.oninput = function () { var n = q.value.toLowerCase(); $$('#ht tr[data-i]').forEach(function (tr) { tr.style.display = tr.textContent.toLowerCase().indexOf(n) >= 0 ? '' : 'none'; }); };
    main.onclick = async function (e) { var b = e.target, i = b.dataset.o || b.dataset.r || b.dataset.d; if (i == null) return; var rec = h.items[+i];
      try { if (b.dataset.o) await D.history.open(rec, false); else if (b.dataset.r) { await D.history.open(rec, true); msg(main, 'Document régénéré avec le profil actuel (numéro conservé).', 'ok'); } else if (b.dataset.d && confirm('Supprimer ce document de l’historique ?')) { await D.history.remove(rec); histo(); } } catch (er) { msg(main, er.message, 'err'); } };
  }

  /* ---------- 9. paramètres ---------- */
  async function params() {
    var st = await D.settings.get(), conn = D.config.connected(), ro = ROLE !== 'admin', P = st.permissions, LAB = { profile_edit: 'Modifier le profil documentaire', models_edit: 'Créer / modifier les modèles', generate: 'Générer des documents', history_read: 'Consulter l’historique', history_delete: 'Supprimer de l’historique', settings_edit: 'Modifier ces paramètres' };
    main.innerHTML = head('Paramètres et permissions', 'Connexion au serveur, droits par rôle et numérotation.') +
      '<div class="card"><h3>Serveur documentaire</h3><label>Adresse du serveur (Chromium / PDF)</label><input id="su" placeholder="https://documents.exemple.com" value="' + esc(D.config.serverUrl()) + '"><div class="row" style="margin-top:8px"><button class="btn" id="sut">Enregistrer et tester</button><span id="sus"></span></div><p class="sub">Sans serveur, les documents sont préparés localement et imprimés via l’application (mode local). La connexion au compte en ligne est requise pour la gestion par organisation.</p></div>' +
      '<div class="card"><h3>En-tête de mon profil sur tous les PDF</h3><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="hab"' + (window.EXBDocHabillage && EXBDocHabillage() ? ' checked' : '') + '> Afficher automatiquement mon logo, mon nom et mes coordonnées en haut des documents du logiciel (pilotage, plans, formations, etc.)</label><p class="sub">Réglage propre à cet appareil. Les devis, factures et reçus gardent toujours leur en-tête complet.</p></div>' +
      '<div class="card"><h3>Permissions par rôle</h3><table class="perm"><tr><th>Action</th><th>Administrateur</th><th>Éditeur</th><th>Lecteur</th></tr>' + Object.keys(LAB).map(function (k) { return '<tr><td>' + LAB[k] + '</td>' + ['admin', 'editeur', 'lecteur'].map(function (r) { var locked = r === 'admin' && (k === 'profile_edit' || k === 'settings_edit'); return '<td><input type="checkbox" data-p="' + k + ':' + r + '"' + (P[k].indexOf(r) >= 0 ? ' checked' : '') + (locked || ro || !conn ? ' disabled' : '') + '></td>'; }).join('') + '</tr>'; }).join('') + '</table>' + (conn ? '' : '<p class="sub">Les permissions s’appliquent en mode centralisé (serveur + compte en ligne).</p>') + '</div>' +
      '<div class="card"><h3>Numérotation automatique</h3><div class="grid g3"><div><label>Format</label><input id="np" value="' + esc(st.numbering.pattern) + '"><small class="sub">{P} préfixe · {Y} année · {N} numéro</small></div><div><label>Chiffres du numéro</label><input id="nd" type="number" min="1" max="8" value="' + st.numbering.pad + '"></div><div><label>Mise en page par défaut</label><select id="nl">' + ['classique', 'bandeau', 'sobre'].map(function (x) { return '<option' + (x === st.default_layout ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div></div>' +
      '<label>Préfixes par type de document</label><div class="grid g3">' + D.templates().map(function (t) { return '<div><small>' + esc(t.label) + '</small><input data-pf="' + t.id + '" value="' + esc(st.numbering.prefixes[t.id] || t.prefix) + '" maxlength="8"></div>'; }).join('') + '</div></div>' +
      '<div class="row end"><button class="btn gold" id="ps"' + (ro ? ' disabled' : '') + '>Enregistrer les paramètres</button></div>';
    $('#hab').onchange = function () { if (window.EXBDocHabillage) EXBDocHabillage(this.checked); msg(main, this.checked ? 'En-tête du profil activé.' : 'En-tête du profil désactivé.', 'ok'); };
    $('#sut').onclick = async function () { D.config.setServerUrl($('#su').value); var s = $('#sus'); s.textContent = 'Test…'; try { var r = await fetch(D.config.serverUrl() + '/api/v1/health'); var j = await r.json(); s.innerHTML = '<span style="color:var(--ok)">✓ Serveur joignable (' + esc(j.storage) + ')</span>'; refreshSide(); } catch (e) { s.innerHTML = '<span style="color:var(--err)">✗ Serveur injoignable</span>'; } };
    $('#ps').onclick = async function () {
      var perm = {}; Object.keys(LAB).forEach(function (k) { perm[k] = ['admin', 'editeur', 'lecteur'].filter(function (r) { var c = $('[data-p="' + k + ':' + r + '"]'); return c ? c.checked : P[k].indexOf(r) >= 0; }); });
      var pf = {}; $$('[data-pf]').forEach(function (i) { pf[i.dataset.pf] = i.value; });
      try { await D.settings.save({ permissions: perm, numbering: { pattern: $('#np').value, pad: +$('#nd').value, prefixes: pf }, default_layout: $('#nl').value }); msg(main, 'Paramètres enregistrés.', 'ok'); } catch (e) { msg(main, e.message, 'err'); }
    };
  }

  var VIEWS = { dash: dash, profil: profil, entreprise: entreprise, identite: identite, modeles: modeles, gen: generateur, public: publics, histo: histo, params: params };
  function show(id) { cur = id; $$('#nav button').forEach(function (b) { b.classList.toggle('on', b.dataset.id === id); }); main.onclick = null; Promise.resolve(VIEWS[id]()).catch(function (e) { main.innerHTML = '<div class="msg err">' + esc(e.message) + '</div>'; }); try { history.replaceState(null, '', '#' + id); } catch (e) {} w.scrollTo(0, 0); }
  function refreshSide() { var p = D.profile.get(); $('#sbName').textContent = p.name || (w.EXB_BRAND && w.EXB_BRAND.name) || 'Excellencia Building'; if (p.logo) $('#sbLogo').src = p.logo; var c = D.config.connected(); $('#sbDot').className = 'dot' + (c ? ' ok' : ''); $('#sbState').textContent = c ? 'Connecté · ' + ROLE : (D.config.serverUrl() ? 'Serveur configuré · compte en ligne requis' : 'Mode local'); }

  $('#nav').innerHTML = TABS.map(function (t, i) { return '<button data-id="' + t[0] + '"><span class="n">' + (i + 1) + '</span>' + esc(t[1]) + '</button>'; }).join('');
  $('#nav').onclick = function (e) { var b = e.target.closest('button'); if (b) show(b.dataset.id); };
  /* API d'appel depuis les autres modules : centre-documentaire.html?type=devis#gen */
  var q = new URLSearchParams(location.search); if (q.get('type') && D.describe(q.get('type'))) gen.type = q.get('type');
  D.profile.load().then(function (r) { ROLE = r.role || 'admin'; refreshSide(); show(TABS.some(function (t) { return '#' + t[0] === location.hash; }) ? location.hash.slice(1) : (q.get('type') ? 'gen' : 'dash')); });
  D.profile.onChange(refreshSide);
})(window, document);
