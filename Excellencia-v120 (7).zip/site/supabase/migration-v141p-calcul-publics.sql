-- ===== Excellencia Building — V141p : portail public des NOTES DE CALCUL et des PLANS D'EXÉCUTION
-- (QR → référence + code d'accès → téléchargement du PDF), même principe que les plans (v129) et les devis (v141o).
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS v66, v99zn, v99zo (et v129 si vous utilisez déjà les plans publics).
-- Réexécutable sans danger. N'altère PAS les tables ni les fonctions des plans (v129) ni des devis (v141o).
--
-- Sécurité (identique aux plans) :
--  * le QR remis au client contient la référence ET un code d'accès (10 caractères aléatoires) ; le PDF n'y est jamais ;
--  * le PDF est dans un dossier au nom ALÉATOIRE (32 caractères) : son adresse n'est révélée par calcul_public_get()
--    que si la référence et le code sont corrects ;
--  * la table calcul_publics n'est lisible/modifiable que par les fonctions ci-dessous (aucune lecture directe) ;
--  * publier / retirer / lister exigent le droit « plans_fichiers » dans l'entreprise (et la licence pour écrire).
-- Références : EXN-AAAA-NNN (notes de calcul), EXE-AAAA-NNN (plans d'exécution) — distinctes des plans EXB-, des devis EXD-
-- et des numéros internes NCS-/PEX- imprimés sur les documents.
-- Un document = une seule publication : republier le même numéro (NCS-/PEX-) garde la même référence et le même code,
-- donc le QR déjà remis reste valable ; seul le PDF est remplacé par la version la plus récente (indice, statut…).

create table if not exists calcul_publics (
  id uuid primary key default gen_random_uuid(),
  org uuid not null,
  genre text not null check (genre in ('note','pex')),
  ref text not null unique,
  code text not null,
  token text not null,
  doc_no text not null,
  titre text,
  projet text,
  client text,
  etabli_par text,
  indice text,
  norme text,
  statut text,
  date_doc date,
  empreinte text,
  apercu text,
  docs jsonb not null default '[]'::jsonb,
  actif boolean not null default true,
  cree_par uuid default auth.uid(),
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now(),
  unique (org, doc_no)
);
create index if not exists calcul_publics_org_idx on calcul_publics(org, maj_le desc);
alter table calcul_publics enable row level security;
revoke all on calcul_publics from anon, authenticated;

-- ---------- espace de fichiers publics (lecture par adresse directe ; pas de liste publique) ----------
insert into storage.buckets(id,name,public,file_size_limit)
values ('exb-calcul-publics','exb-calcul-publics',true,52428800)
on conflict (id) do update set public=true, file_size_limit=excluded.file_size_limit;

create or replace function org_du_chemin(p_name text) returns uuid language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

drop policy if exists calcul_pub_lire on storage.objects;
create policy calcul_pub_lire on storage.objects for select to authenticated
  using (bucket_id='exb-calcul-publics' and peut(org_du_chemin(name),'plans_fichiers',false));
drop policy if exists calcul_pub_ajout on storage.objects;
create policy calcul_pub_ajout on storage.objects for insert to authenticated
  with check (bucket_id='exb-calcul-publics' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists calcul_pub_modif on storage.objects;
create policy calcul_pub_modif on storage.objects for update to authenticated
  using (bucket_id='exb-calcul-publics' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists calcul_pub_suppr on storage.objects;
create policy calcul_pub_suppr on storage.objects for delete to authenticated
  using (bucket_id='exb-calcul-publics' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));

-- ---------- PUBLIC : consulter un document (référence + code d'accès) ----------
create or replace function calcul_public_get(p_ref text, p_code text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r calcul_publics;
  c text := upper(regexp_replace(coalesce(p_code,''), '[^A-Za-z0-9]', '', 'g'));
begin
  if p_ref is null or length(p_ref) > 40 or length(c) < 4 then return null; end if;
  select * into r from calcul_publics where ref = upper(btrim(p_ref)) and code = c and actif;
  if not found then return null; end if;
  return jsonb_build_object(
    'genre', r.genre, 'ref', r.ref, 'titre', r.titre, 'date', coalesce(r.date_doc, r.maj_le::date),
    'doc_no', r.doc_no, 'projet', r.projet, 'client', r.client, 'etabli_par', r.etabli_par, 'indice', r.indice,
    'norme', r.norme, 'statut', r.statut, 'apercu', r.apercu, 'docs', r.docs);
end $$;
revoke all on function calcul_public_get(text,text) from public;
grant execute on function calcul_public_get(text,text) to anon, authenticated;

-- ---------- ÉQUIPE : publier (ou mettre à jour) un document ----------
create or replace function calcul_public_publier(
  p_org uuid, p_genre text, p_no text, p_titre text, p_projet text, p_client text, p_etabli text, p_indice text,
  p_norme text, p_statut text, p_date text, p_empreinte text, p_apercu text, p_docs jsonb, p_token text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_docs jsonb; v_ap text; v_row calcul_publics; v_ref text; v_code text; v_n int; v_yr text := to_char(now(),'YYYY');
  v_date date; v_pre text; e jsonb;
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  if p_genre is null or p_genre not in ('note','pex') then
    return jsonb_build_object('ok',false,'erreur','Type de document invalide.');
  end if;
  if length(btrim(coalesce(p_no,''))) < 1 or length(p_no) > 60 then
    return jsonb_build_object('ok',false,'erreur','Numéro de document invalide.');
  end if;
  if p_token is null or p_token !~ '^[a-f0-9]{32}$' then
    return jsonb_build_object('ok',false,'erreur','Jeton de dossier invalide.');
  end if;
  if p_docs is null or jsonb_typeof(p_docs) <> 'array' or jsonb_array_length(p_docs) not between 1 and 3 then
    return jsonb_build_object('ok',false,'erreur','Liste de documents invalide.');
  end if;
  for e in select value from jsonb_array_elements(p_docs) loop
    if jsonb_typeof(e) <> 'object' or coalesce(e->>'fichier','') !~ ('^' || p_org::text || '/' || p_token || '/[A-Za-z0-9._-]{1,80}$') then
      return jsonb_build_object('ok',false,'erreur','Chemin de document invalide.');
    end if;
  end loop;
  select jsonb_agg(jsonb_build_object(
      'nom', left(coalesce(x.value->>'nom', case when p_genre = 'pex' then 'Plan d''exécution' else 'Note de calcul' end),120),
      'fichier', x.value->>'fichier',
      'format', left(upper(coalesce(x.value->>'format','PDF')),8),
      'taille', left(coalesce(x.value->>'taille',''),30),
      'kind', p_genre))
    into v_docs from jsonb_array_elements(p_docs) as x;
  v_ap := case when p_apercu is not null and length(p_apercu) <= 500000
                and p_apercu ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' then p_apercu else null end;
  begin v_date := p_date::date; exception when others then v_date := null; end;
  v_pre := case when p_genre = 'pex' then 'EXE' else 'EXN' end;

  perform pg_advisory_xact_lock(hashtext('calcul_publics_ref'));
  select * into v_row from calcul_publics where org = p_org and doc_no = btrim(p_no) for update;
  if found then
    if v_row.genre <> p_genre then
      return jsonb_build_object('ok',false,'erreur','Ce numéro est déjà publié sous un autre type de document.');
    end if;
    update calcul_publics set
      titre = left(p_titre,160), projet = left(p_projet,160), client = left(p_client,120), etabli_par = left(p_etabli,120),
      indice = left(p_indice,12), norme = left(p_norme,120), statut = left(p_statut,30), date_doc = v_date,
      empreinte = left(p_empreinte,80), apercu = v_ap, docs = v_docs, token = p_token, actif = true, maj_le = now()
    where id = v_row.id;
    return jsonb_build_object('ok',true,'ref',v_row.ref,'code',v_row.code,'ancien_token',v_row.token,'mise_a_jour',true);
  end if;

  select coalesce(max(substring(ref from '([0-9]+)$')::int),0) + 1 into v_n from calcul_publics where ref like v_pre || '-' || v_yr || '-%';
  v_ref := v_pre || '-' || v_yr || '-' || lpad(v_n::text, 3, '0');
  v_code := upper(substr(replace(gen_random_uuid()::text,'-',''),1,10));
  insert into calcul_publics(org, genre, ref, code, token, doc_no, titre, projet, client, etabli_par, indice, norme, statut, date_doc, empreinte, apercu, docs)
  values (p_org, p_genre, v_ref, v_code, p_token, btrim(p_no), left(p_titre,160), left(p_projet,160), left(p_client,120), left(p_etabli,120),
          left(p_indice,12), left(p_norme,120), left(p_statut,30), v_date, left(p_empreinte,80), v_ap, v_docs);
  return jsonb_build_object('ok',true,'ref',v_ref,'code',v_code);
end $$;
revoke all on function calcul_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,text,text,jsonb,text) from public;
grant execute on function calcul_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,text,text,jsonb,text) to authenticated;

-- ---------- ÉQUIPE : retirer une publication (le client ne peut plus rien télécharger) ----------
create or replace function calcul_public_retirer(p_org uuid, p_ref text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_row calcul_publics;
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  update calcul_publics set actif = false, maj_le = now()
   where org = p_org and ref = upper(btrim(p_ref)) returning * into v_row;
  if not found then return jsonb_build_object('ok',false,'erreur','Référence inconnue.'); end if;
  return jsonb_build_object('ok',true,'token',v_row.token,'doc_no',v_row.doc_no);
end $$;
revoke all on function calcul_public_retirer(uuid,text) from public;
grant execute on function calcul_public_retirer(uuid,text) to authenticated;

-- ---------- ÉQUIPE : liste des documents publiés ----------
create or replace function calcul_public_lister(p_org uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',false) then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('genre',genre,'ref',ref,'code',code,'doc_no',doc_no,'titre',titre,'projet',projet,
             'client',client,'indice',indice,'statut',statut,'actif',actif,'maj_le',maj_le) order by maj_le desc)
      from calcul_publics where org = p_org), '[]'::jsonb);
end $$;
revoke all on function calcul_public_lister(uuid) from public;
grant execute on function calcul_public_lister(uuid) to authenticated;
