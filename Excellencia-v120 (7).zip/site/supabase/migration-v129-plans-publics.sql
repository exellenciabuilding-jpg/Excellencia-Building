-- ===== Excellencia Building — V129 : portail public des plans (QR → référence + code d'accès → téléchargement) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS v66, v99zn, v99zo et v99zw. Réexécutable sans danger.
--
-- Principe de sécurité :
--  * le QR imprimé contient la référence ET un code d'accès (10 caractères aléatoires) ; le PDF n'y est jamais ;
--  * les fichiers publics sont dans un dossier au nom ALÉATOIRE (32 caractères) : l'adresse d'un fichier n'est
--    révélée par plan_public_get() que si la référence et le code sont corrects ;
--  * la table plans_publics n'est lisible/modifiable que par les fonctions ci-dessous (aucune lecture directe) ;
--  * publier / retirer / lister exigent le droit « plans_fichiers » dans l'entreprise (et la licence pour écrire).

create table if not exists plans_publics (
  id uuid primary key default gen_random_uuid(),
  org uuid not null,
  ref text not null unique,
  code text not null,
  token text not null,
  plan_id text,
  ref_plan text,
  titre text not null,
  type_doc text,
  maitre_oeuvre text,
  maitre_ouvrage text,
  concepteur text,
  echelle text,
  indice text,
  apercu text,
  docs jsonb not null default '[]'::jsonb,
  actif boolean not null default true,
  cree_par uuid default auth.uid(),
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now()
);
create index if not exists plans_publics_org_idx on plans_publics(org, cree_le desc);
alter table plans_publics enable row level security;
revoke all on plans_publics from anon, authenticated;

-- ---------- espace de fichiers publics (lecture par adresse directe ; pas de liste publique) ----------
insert into storage.buckets(id,name,public,file_size_limit)
values ('exb-plans-publics','exb-plans-publics',true,104857600)
on conflict (id) do update set public=true, file_size_limit=excluded.file_size_limit;

create or replace function org_du_chemin(p_name text) returns uuid language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

drop policy if exists plans_pub_lire on storage.objects;
create policy plans_pub_lire on storage.objects for select to authenticated
  using (bucket_id='exb-plans-publics' and peut(org_du_chemin(name),'plans_fichiers',false));
drop policy if exists plans_pub_ajout on storage.objects;
create policy plans_pub_ajout on storage.objects for insert to authenticated
  with check (bucket_id='exb-plans-publics' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists plans_pub_modif on storage.objects;
create policy plans_pub_modif on storage.objects for update to authenticated
  using (bucket_id='exb-plans-publics' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists plans_pub_suppr on storage.objects;
create policy plans_pub_suppr on storage.objects for delete to authenticated
  using (bucket_id='exb-plans-publics' and peut(org_du_chemin(name),'plans_fichiers',true) and licence_ecriture_ok(org_du_chemin(name)));

-- ---------- PUBLIC : consulter un dossier (référence + code d'accès) ----------
create or replace function plan_public_get(p_ref text, p_code text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r plans_publics;
  c text := upper(regexp_replace(coalesce(p_code,''), '[^A-Za-z0-9]', '', 'g'));
begin
  if p_ref is null or length(p_ref) > 40 or length(c) < 4 then return null; end if;
  select * into r from plans_publics where ref = upper(btrim(p_ref)) and code = c and actif;
  if not found then return null; end if;
  return jsonb_build_object(
    'ref', r.ref, 'titre', r.titre, 'date', r.maj_le::date, 'type_doc', r.type_doc,
    'maitre_oeuvre', r.maitre_oeuvre, 'maitre_ouvrage', r.maitre_ouvrage, 'concepteur', r.concepteur,
    'echelle', r.echelle, 'indice', r.indice, 'apercu', r.apercu, 'docs', r.docs);
end $$;
revoke all on function plan_public_get(text,text) from public;
grant execute on function plan_public_get(text,text) to anon, authenticated;

-- ---------- ÉQUIPE : publier (ou mettre à jour) un plan ----------
create or replace function plan_public_publier(
  p_org uuid, p_plan_id text, p_ref_plan text, p_titre text, p_type text, p_moe text, p_mo text,
  p_concepteur text, p_echelle text, p_indice text, p_apercu text, p_docs jsonb, p_token text, p_ref text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_docs jsonb; v_ap text; v_row plans_publics; v_ref text; v_code text; v_n int; v_yr text := to_char(now(),'YYYY'); e jsonb;
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  if p_token is null or p_token !~ '^[a-f0-9]{32}$' then
    return jsonb_build_object('ok',false,'erreur','Jeton de dossier invalide.');
  end if;
  if length(btrim(coalesce(p_titre,''))) < 2 then
    return jsonb_build_object('ok',false,'erreur','Le titre du projet est obligatoire.');
  end if;
  if p_docs is null or jsonb_typeof(p_docs) <> 'array' or jsonb_array_length(p_docs) not between 1 and 8 then
    return jsonb_build_object('ok',false,'erreur','Liste de documents invalide.');
  end if;
  for e in select value from jsonb_array_elements(p_docs) loop
    if jsonb_typeof(e) <> 'object' or coalesce(e->>'fichier','') !~ ('^' || p_org::text || '/' || p_token || '/[A-Za-z0-9._-]{1,80}$') then
      return jsonb_build_object('ok',false,'erreur','Chemin de document invalide.');
    end if;
  end loop;
  select jsonb_agg(jsonb_build_object(
      'nom', left(coalesce(x.value->>'nom','Document'),120),
      'fichier', x.value->>'fichier',
      'format', left(upper(coalesce(x.value->>'format','PDF')),8),
      'taille', left(coalesce(x.value->>'taille',''),30),
      'kind', case when x.value->>'kind' = 'fiche' then 'fiche' else 'plan' end))
    into v_docs from jsonb_array_elements(p_docs) as x;
  v_ap := case when p_apercu is not null and length(p_apercu) <= 500000
                and p_apercu ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' then p_apercu else null end;

  if p_ref is not null then
    select * into v_row from plans_publics where org = p_org and ref = upper(btrim(p_ref)) for update;
    if not found then return jsonb_build_object('ok',false,'erreur','Référence inconnue.'); end if;
    update plans_publics set
      plan_id = left(p_plan_id,80), ref_plan = left(p_ref_plan,80), titre = left(btrim(p_titre),160), type_doc = left(p_type,160),
      maitre_oeuvre = left(p_moe,120), maitre_ouvrage = left(p_mo,120), concepteur = left(p_concepteur,120),
      echelle = left(p_echelle,40), indice = left(p_indice,60), apercu = v_ap, docs = v_docs,
      token = p_token, actif = true, maj_le = now()
    where id = v_row.id;
    return jsonb_build_object('ok',true,'ref',v_row.ref,'code',v_row.code,'ancien_token',v_row.token);
  end if;

  perform pg_advisory_xact_lock(hashtext('plans_publics_ref'));
  select coalesce(max(substring(ref from '([0-9]+)$')::int),0) + 1 into v_n from plans_publics where ref like 'EXB-' || v_yr || '-%';
  v_ref := 'EXB-' || v_yr || '-' || lpad(v_n::text, 3, '0');
  v_code := upper(substr(replace(gen_random_uuid()::text,'-',''),1,10));
  insert into plans_publics(org, ref, code, token, plan_id, ref_plan, titre, type_doc, maitre_oeuvre, maitre_ouvrage, concepteur, echelle, indice, apercu, docs)
  values (p_org, v_ref, v_code, p_token, left(p_plan_id,80), left(p_ref_plan,80), left(btrim(p_titre),160), left(p_type,160),
          left(p_moe,120), left(p_mo,120), left(p_concepteur,120), left(p_echelle,40), left(p_indice,60), v_ap, v_docs);
  return jsonb_build_object('ok',true,'ref',v_ref,'code',v_code);
end $$;
revoke all on function plan_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,jsonb,text,text) from public;
grant execute on function plan_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,jsonb,text,text) to authenticated;

-- ---------- ÉQUIPE : retirer une publication ----------
create or replace function plan_public_retirer(p_org uuid, p_ref text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_row plans_publics;
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  update plans_publics set actif = false, maj_le = now()
   where org = p_org and ref = upper(btrim(p_ref)) returning * into v_row;
  if not found then return jsonb_build_object('ok',false,'erreur','Référence inconnue.'); end if;
  return jsonb_build_object('ok',true,'token',v_row.token);
end $$;
revoke all on function plan_public_retirer(uuid,text) from public;
grant execute on function plan_public_retirer(uuid,text) to authenticated;

-- ---------- ÉQUIPE : liste des publications ----------
create or replace function plan_public_lister(p_org uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not peut(p_org,'plans_fichiers',false) then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('ref',ref,'code',code,'titre',titre,'ref_plan',ref_plan,'plan_id',plan_id,
             'actif',actif,'maj_le',maj_le,'nb_docs',jsonb_array_length(docs)) order by cree_le desc)
      from plans_publics where org = p_org), '[]'::jsonb);
end $$;
revoke all on function plan_public_lister(uuid) from public;
grant execute on function plan_public_lister(uuid) to authenticated;
