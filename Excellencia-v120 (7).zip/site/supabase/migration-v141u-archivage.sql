-- ===== Excellencia Building — V141u : 🗄 ESPACE SERVEUR (archiver en ZIP, libérer la place, restaurer) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS migration-v129-plans-publics.sql, migration-v141o-devis-publics.sql
-- et migration-v141p-calcul-publics.sql. Réexécutable sans danger.
-- (La version V141p « archivage » de l'autre branche n'est plus à exécuter : ce script la remplace. Ne touche pas aux
--  tables ni aux fonctions de publication/retrait/liste : seules les fonctions « get » des devis et des notes de calcul sont
--  redéfinies pour indiquer « archivé » au client.)
--
-- ARCHIVAGE (administrateur seulement) : le logiciel télécharge les fichiers publiés dans un ZIP sur votre ordinateur, puis les
-- supprime du serveur ET vide l'aperçu en base. La référence et le code restent valides ; la page client affiche « document
-- archivé ». Le ZIP permet de RESTAURER le document plus tard (mêmes référence et code).
-- Couvre : plans (plans_publics), devis (devis_publics), notes de calcul et plans d'exécution (calcul_publics).
-- NE concerne PAS les documents envoyés au chantier (espace privé exb-chantier-docs) : ils ne sont ni listés ni supprimés ici.
-- Note Supabase : supprimer des lignes ne baisse PAS tout de suite la jauge « Database size » (l'espace est récupéré par le
-- nettoyage automatique de Postgres) ; supprimer des fichiers par l'API de stockage libère la jauge « Storage ».

-- ---------- colonnes ----------
alter table plans_publics  add column if not exists archive_le timestamptz;
alter table devis_publics  add column if not exists archive_le timestamptz;
alter table calcul_publics add column if not exists archive_le timestamptz;

-- remettre « archive_le » à vide dès que des fichiers sont republiés sur la ligne (restauration par ZIP ou republication)
create or replace function docs_pub_archive_reset() returns trigger language plpgsql as $$
begin
  if new.archive_le is not null and jsonb_array_length(coalesce(new.docs,'[]'::jsonb)) > 0 and (old.docs is distinct from new.docs) then
    new.archive_le := null;
  end if;
  return new;
end $$;
drop trigger if exists plans_archive_reset_trg on plans_publics;
drop trigger if exists docs_pub_archive_reset_trg on plans_publics;
create trigger docs_pub_archive_reset_trg before update on plans_publics for each row execute function docs_pub_archive_reset();
drop trigger if exists docs_pub_archive_reset_trg on devis_publics;
create trigger docs_pub_archive_reset_trg before update on devis_publics for each row execute function docs_pub_archive_reset();
drop trigger if exists docs_pub_archive_reset_trg on calcul_publics;
create trigger docs_pub_archive_reset_trg before update on calcul_publics for each row execute function docs_pub_archive_reset();

create or replace function docs_pub_est_admin(p_org uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from membres m where m.org_id = p_org and m.user_id = auth.uid() and m.role = 'admin') $$;
revoke all on function docs_pub_est_admin(uuid) from public;
grant execute on function docs_pub_est_admin(uuid) to authenticated;

-- ---------- PUBLIC : consulter un devis (identique à v141o + indicateur « archivé ») ----------
create or replace function devis_public_get(p_ref text, p_code text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r devis_publics;
  c text := upper(regexp_replace(coalesce(p_code,''), '[^A-Za-z0-9]', '', 'g'));
begin
  if p_ref is null or length(p_ref) > 40 or length(c) < 4 then return null; end if;
  select * into r from devis_publics where ref = upper(btrim(p_ref)) and code = c and actif;
  if not found then return null; end if;
  return jsonb_build_object(
    'genre', 'devis', 'ref', r.ref, 'titre', r.projet, 'date', coalesce(r.date_devis, r.maj_le::date),
    'devis_no', r.devis_no, 'client', r.client, 'prestataire', r.prestataire, 'montant', r.montant,
    'validite', r.validite, 'statut', r.statut, 'apercu', r.apercu, 'docs', r.docs, 'archive', r.archive_le is not null);
end $$;
revoke all on function devis_public_get(text,text) from public;
grant execute on function devis_public_get(text,text) to anon, authenticated;

-- ---------- PUBLIC : consulter une note de calcul / un plan d'exécution (identique à v141p + indicateur « archivé ») ----------
create or replace function calcul_public_get(p_ref text, p_code text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r calcul_publics;
  c text := upper(regexp_replace(coalesce(p_code,''), '[^A-Za-z0-9]', '', 'g'));
begin
  if p_ref is null or length(p_ref) > 40 or length(c) < 4 then return null; end if;
  select * into r from calcul_publics where ref = upper(btrim(p_ref)) and code = c and actif;
  if not found then return null; end if;
  return jsonb_build_object(
    'genre', r.genre, 'ref', r.ref, 'titre', r.titre, 'date', coalesce(r.date_doc, r.maj_le::date),
    'doc_no', r.doc_no, 'projet', r.projet, 'client', r.client, 'etabli_par', r.etabli_par, 'indice', r.indice,
    'norme', r.norme, 'statut', r.statut, 'apercu', r.apercu, 'docs', r.docs, 'archive', r.archive_le is not null);
end $$;
revoke all on function calcul_public_get(text,text) from public;
grant execute on function calcul_public_get(text,text) to anon, authenticated;

-- ---------- ADMIN : jauges d'espace ----------
create or replace function espace_stats(p_org uuid)
returns jsonb language plpgsql stable security definer set search_path = public, storage as $$
begin
  if auth.uid() is null or not docs_pub_est_admin(p_org) then return jsonb_build_object('ok',false,'erreur','Réservé à l’administrateur.'); end if;
  return jsonb_build_object('ok',true,
    'db_bytes', pg_database_size(current_database()),
    'storage_bytes', coalesce((select sum((metadata->>'size')::bigint) from storage.objects),0),
    'buckets', coalesce((select jsonb_agg(jsonb_build_object('bucket',b,'n',n,'bytes',s)) from (
        select bucket_id b, count(*) n, coalesce(sum((metadata->>'size')::bigint),0) s from storage.objects group by bucket_id) t),'[]'::jsonb),
    'apercus_bytes', coalesce((select sum(length(apercu)) from devis_publics where org = p_org),0)
                   + coalesce((select sum(length(apercu)) from plans_publics where org = p_org),0)
                   + coalesce((select sum(length(apercu)) from calcul_publics where org = p_org),0),
    'n_publies', (select count(*) from devis_publics where org = p_org) + (select count(*) from plans_publics where org = p_org)
               + (select count(*) from calcul_publics where org = p_org),
    'n_archives', (select count(*) from devis_publics where org = p_org and archive_le is not null)
                + (select count(*) from plans_publics where org = p_org and archive_le is not null)
                + (select count(*) from calcul_publics where org = p_org and archive_le is not null));
end $$;
revoke all on function espace_stats(uuid) from public;
grant execute on function espace_stats(uuid) to authenticated;

-- ---------- ADMIN : toutes les publications (plans, devis, notes de calcul, plans d'exécution) pour choisir quoi archiver ----------
create or replace function docs_publics_pour_archivage(p_org uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not docs_pub_est_admin(p_org) then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(x order by x->>'maj_le' desc) from (
      select jsonb_build_object('table','plans','ref',ref,'code',code,'genre','plan','titre',titre,'sous_titre',coalesce(ref_plan,plan_id),'actif',actif,
               'maj_le',maj_le,'archive',archive_le is not null,'token',token,'docs',docs) x from plans_publics where org = p_org
      union all
      select jsonb_build_object('table','devis','ref',ref,'code',code,'genre','devis','titre',coalesce(projet,devis_no),'sous_titre',devis_no||coalesce(' · '||client,''),'actif',actif,
               'maj_le',maj_le,'archive',archive_le is not null,'token',token,'docs',docs) from devis_publics where org = p_org
      union all
      select jsonb_build_object('table','calcul','ref',ref,'code',code,'genre',genre,'titre',coalesce(projet,titre,doc_no),'sous_titre',doc_no||coalesce(' · '||client,''),'actif',actif,
               'maj_le',maj_le,'archive',archive_le is not null,'token',token,'docs',docs) from calcul_publics where org = p_org) t), '[]'::jsonb);
end $$;
revoke all on function docs_publics_pour_archivage(uuid) from public;
grant execute on function docs_publics_pour_archivage(uuid) to authenticated;

-- ---------- ADMIN : fiche complète d'une publication (pour la mettre dans le ZIP, aperçu compris) ----------
create or replace function docs_public_fiche(p_org uuid, p_table text, p_ref text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare j jsonb;
begin
  if auth.uid() is null or not docs_pub_est_admin(p_org) then return null; end if;
  if p_table = 'plans' then select to_jsonb(r) into j from plans_publics r where org = p_org and ref = upper(btrim(p_ref));
  elsif p_table = 'devis' then select to_jsonb(r) into j from devis_publics r where org = p_org and ref = upper(btrim(p_ref));
  elsif p_table = 'calcul' then select to_jsonb(r) into j from calcul_publics r where org = p_org and ref = upper(btrim(p_ref));
  end if;
  return j;
end $$;
revoke all on function docs_public_fiche(uuid,text,text) from public;
grant execute on function docs_public_fiche(uuid,text,text) to authenticated;

-- ---------- ADMIN : archiver (vide les fichiers déclarés et l'aperçu ; référence et code restent) ----------
create or replace function docs_public_archiver(p_org uuid, p_table text, p_ref text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_tok text;
begin
  if auth.uid() is null or not docs_pub_est_admin(p_org) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Réservé à l’administrateur.');
  end if;
  if p_table = 'plans' then
    update plans_publics set docs = '[]'::jsonb, apercu = null, archive_le = now(), maj_le = now()
     where org = p_org and ref = upper(btrim(p_ref)) and archive_le is null returning token into v_tok;
  elsif p_table = 'devis' then
    update devis_publics set docs = '[]'::jsonb, apercu = null, archive_le = now(), maj_le = now()
     where org = p_org and ref = upper(btrim(p_ref)) and archive_le is null returning token into v_tok;
  elsif p_table = 'calcul' then
    update calcul_publics set docs = '[]'::jsonb, apercu = null, archive_le = now(), maj_le = now()
     where org = p_org and ref = upper(btrim(p_ref)) and archive_le is null returning token into v_tok;
  else
    return jsonb_build_object('ok',false,'erreur','Table inconnue.');
  end if;
  if v_tok is null then return jsonb_build_object('ok',false,'erreur','Déjà archivé ou référence inconnue.'); end if;
  return jsonb_build_object('ok',true,'token',v_tok);
end $$;
revoke all on function docs_public_archiver(uuid,text,text) from public;
grant execute on function docs_public_archiver(uuid,text,text) to authenticated;
