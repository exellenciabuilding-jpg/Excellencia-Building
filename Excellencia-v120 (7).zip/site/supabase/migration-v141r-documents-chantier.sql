-- ===== Excellencia Building — V141r : plans, notes de calcul et plans d'exécution envoyés AU CHANTIER
-- Le logiciel central dépose le PDF dans un espace PRIVÉ ; seuls l'administrateur et les membres du chantier
-- (table exb_site_memberships) peuvent lister et ouvrir les documents de LEUR chantier. Aucun accès public.
-- PRÉREQUIS (déjà exécutés chez vous) : migration-chantier-comptes-sync-v67.sql (fonction exb_is_admin),
-- le script chantier-admin (tables exb_sites, exb_site_memberships) et migration-v115 (liaison projet ⇄ chantier).
-- Réexécutable sans danger. Ne touche NI aux plans (v129), NI aux devis (v141o), NI aux notes publiées (v141p).
--
-- Principe : un document = une ligne par chantier. Renvoyer le même numéro (EXB-…, NCS-…, PEX-…) au même chantier
-- REMPLACE le fichier et met à jour l'indice / le statut : l'équipe voit toujours la dernière version.

create table if not exists public.exb_site_documents (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null,
  genre text not null check (genre in ('plan','note','pex')),
  doc_no text not null,
  titre text,
  projet text,
  indice text,
  statut text,
  fichier text not null,            -- chemin dans le stockage : <site_id>/<jeton>/<nom>.pdf
  format text default 'PDF',
  taille text,
  empreinte text,
  actif boolean not null default true,
  note_equipe text,                 -- message facultatif pour l'équipe (ex. « version à appliquer dès demain »)
  envoye_par uuid default auth.uid(),
  envoye_le timestamptz not null default now(),
  maj_le timestamptz not null default now(),
  unique (site_id, doc_no)
);
create index if not exists exb_site_documents_site_idx on public.exb_site_documents(site_id, maj_le desc);
alter table public.exb_site_documents enable row level security;
revoke all on public.exb_site_documents from anon, authenticated;   -- aucune lecture directe : uniquement les fonctions ci-dessous

-- Membre du chantier (ou administrateur) ?
create or replace function public.exb_doc_acces(p_site uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and (
    public.exb_is_admin()
    or exists (select 1 from public.exb_site_memberships m where m.user_id = auth.uid() and m.site_id = p_site)
  );
$$;
revoke all on function public.exb_doc_acces(uuid) from public;
grant execute on function public.exb_doc_acces(uuid) to authenticated;

create or replace function public.exb_site_du_chemin(p_name text) returns uuid
language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

-- ---------- espace de fichiers PRIVÉ (public = false : ouverture par adresse signée seulement) ----------
insert into storage.buckets(id, name, public, file_size_limit)
values ('exb-chantier-docs', 'exb-chantier-docs', false, 52428800)
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit;

drop policy if exists chantier_docs_lire on storage.objects;
create policy chantier_docs_lire on storage.objects for select to authenticated
  using (bucket_id = 'exb-chantier-docs' and public.exb_doc_acces(public.exb_site_du_chemin(name)));
drop policy if exists chantier_docs_ajout on storage.objects;
create policy chantier_docs_ajout on storage.objects for insert to authenticated
  with check (bucket_id = 'exb-chantier-docs' and public.exb_is_admin());
drop policy if exists chantier_docs_modif on storage.objects;
create policy chantier_docs_modif on storage.objects for update to authenticated
  using (bucket_id = 'exb-chantier-docs' and public.exb_is_admin());
drop policy if exists chantier_docs_suppr on storage.objects;
create policy chantier_docs_suppr on storage.objects for delete to authenticated
  using (bucket_id = 'exb-chantier-docs' and public.exb_is_admin());

-- ---------- ADMINISTRATEUR (logiciel central) : envoyer / mettre à jour un document ----------
create or replace function public.chantier_doc_publier(
  p_site uuid, p_genre text, p_no text, p_titre text, p_projet text, p_indice text, p_statut text,
  p_fichier text, p_taille text, p_empreinte text, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_old text; v_id uuid;
begin
  if not public.exb_is_admin() then
    return jsonb_build_object('ok', false, 'erreur', 'Réservé aux administrateurs.');
  end if;
  if not exists (select 1 from exb_sites where id = p_site) then
    return jsonb_build_object('ok', false, 'erreur', 'Chantier introuvable.');
  end if;
  if p_genre is null or p_genre not in ('plan','note','pex') then
    return jsonb_build_object('ok', false, 'erreur', 'Type de document invalide.');
  end if;
  if length(btrim(coalesce(p_no,''))) < 1 or length(p_no) > 60 then
    return jsonb_build_object('ok', false, 'erreur', 'Numéro de document invalide.');
  end if;
  -- le fichier doit être rangé sous le dossier de CE chantier (empêche de pointer vers un autre chantier)
  if p_fichier is null or left(p_fichier, 37) <> (p_site::text || '/') or length(p_fichier) > 300 then
    return jsonb_build_object('ok', false, 'erreur', 'Chemin de fichier invalide.');
  end if;
  select fichier into v_old from exb_site_documents where site_id = p_site and doc_no = btrim(p_no);
  insert into exb_site_documents(site_id, genre, doc_no, titre, projet, indice, statut, fichier, taille, empreinte, note_equipe)
  values (p_site, p_genre, btrim(p_no), left(p_titre,160), left(p_projet,160), left(p_indice,30), left(p_statut,30),
          p_fichier, left(p_taille,20), left(p_empreinte,80), left(p_note,300))
  on conflict (site_id, doc_no) do update set
    genre = excluded.genre, titre = excluded.titre, projet = excluded.projet, indice = excluded.indice, statut = excluded.statut,
    fichier = excluded.fichier, taille = excluded.taille, empreinte = excluded.empreinte, note_equipe = excluded.note_equipe,
    actif = true, envoye_par = auth.uid(), maj_le = now()
  returning id into v_id;
  return jsonb_build_object('ok', true, 'id', v_id, 'ancien_fichier', case when v_old is distinct from p_fichier then v_old else null end);
end $$;

-- Administrateur : retirer un document du chantier (l'équipe ne le voit plus ; le fichier est à supprimer côté stockage).
create or replace function public.chantier_doc_retirer(p_site uuid, p_no text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_f text;
begin
  if not public.exb_is_admin() then
    return jsonb_build_object('ok', false, 'erreur', 'Réservé aux administrateurs.');
  end if;
  delete from exb_site_documents where site_id = p_site and doc_no = btrim(p_no) returning fichier into v_f;
  return jsonb_build_object('ok', v_f is not null, 'fichier', v_f);
end $$;

-- ---------- ÉQUIPE DU CHANTIER (et administrateur) : liste des documents d'un chantier ----------
create or replace function public.chantier_docs_liste(p_site uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.exb_doc_acces(p_site) then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'genre', d.genre, 'doc_no', d.doc_no, 'titre', d.titre, 'projet', d.projet, 'indice', d.indice, 'statut', d.statut,
      'fichier', d.fichier, 'taille', d.taille, 'note', d.note_equipe, 'maj_le', d.maj_le) order by d.maj_le desc)
    from exb_site_documents d where d.site_id = p_site and d.actif), '[]'::jsonb);
end $$;

revoke all on function
  public.chantier_doc_publier(uuid,text,text,text,text,text,text,text,text,text,text),
  public.chantier_doc_retirer(uuid,text),
  public.chantier_docs_liste(uuid) from public;
grant execute on function
  public.chantier_doc_publier(uuid,text,text,text,text,text,text,text,text,text,text),
  public.chantier_doc_retirer(uuid,text),
  public.chantier_docs_liste(uuid) to authenticated;

-- Contrôles :
--   select proname from pg_proc where proname in ('chantier_doc_publier','chantier_doc_retirer','chantier_docs_liste','exb_doc_acces'); → 4 lignes
--   select id, public from storage.buckets where id = 'exb-chantier-docs';                                                          → public = false
