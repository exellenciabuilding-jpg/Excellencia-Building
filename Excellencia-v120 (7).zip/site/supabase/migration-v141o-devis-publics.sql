-- ===== Excellencia Building — V141o : portail public des DEVIS (QR → référence + code d'accès → téléchargement du PDF) =====
-- À exécuter UNE FOIS (Supabase › SQL Editor › Run), APRÈS v66, v99zn, v99zo (et v129 si vous utilisez déjà les plans publics).
-- Réexécutable sans danger. N'altère PAS les tables ni les fonctions du portail des plans (v129).
--
-- Même principe de sécurité que les plans :
--  * le QR imprimé contient la référence ET un code d'accès (10 caractères aléatoires) ; le PDF n'y est jamais ;
--  * le PDF est dans un dossier au nom ALÉATOIRE (32 caractères) : son adresse n'est révélée par devis_public_get()
--    que si la référence et le code sont corrects ;
--  * la table devis_publics n'est lisible/modifiable que par les fonctions ci-dessous (aucune lecture directe) ;
--  * publier / retirer / lister exigent le droit « devis » dans l'entreprise (et la licence pour écrire).
-- Références des devis : EXD-AAAA-NNN (distinctes des plans EXB-AAAA-NNN et des numéros de devis DEV-AAAA-NNN).
-- Un devis = une seule publication : republier le même devis (même numéro) garde la même référence et le même code,
-- donc le QR déjà remis au client reste valable ; seul le PDF est remplacé par la version la plus récente.

create table if not exists devis_publics (
  id uuid primary key default gen_random_uuid(),
  org uuid not null,
  ref text not null unique,
  code text not null,
  token text not null,
  devis_no text not null,
  projet text,
  client text,
  prestataire text,
  montant text,
  validite text,
  date_devis date,
  statut text,
  empreinte text,
  apercu text,
  docs jsonb not null default '[]'::jsonb,
  actif boolean not null default true,
  cree_par uuid default auth.uid(),
  cree_le timestamptz not null default now(),
  maj_le timestamptz not null default now(),
  unique (org, devis_no)
);
create index if not exists devis_publics_org_idx on devis_publics(org, maj_le desc);
alter table devis_publics enable row level security;
revoke all on devis_publics from anon, authenticated;

-- ---------- espace de fichiers publics (lecture par adresse directe ; pas de liste publique) ----------
insert into storage.buckets(id,name,public,file_size_limit)
values ('exb-devis-publics','exb-devis-publics',true,52428800)
on conflict (id) do update set public=true, file_size_limit=excluded.file_size_limit;

create or replace function org_du_chemin(p_name text) returns uuid language plpgsql immutable as $$
begin return ((storage.foldername(p_name))[1])::uuid; exception when others then return null; end $$;

drop policy if exists devis_pub_lire on storage.objects;
create policy devis_pub_lire on storage.objects for select to authenticated
  using (bucket_id='exb-devis-publics' and peut(org_du_chemin(name),'devis',false));
drop policy if exists devis_pub_ajout on storage.objects;
create policy devis_pub_ajout on storage.objects for insert to authenticated
  with check (bucket_id='exb-devis-publics' and peut(org_du_chemin(name),'devis',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists devis_pub_modif on storage.objects;
create policy devis_pub_modif on storage.objects for update to authenticated
  using (bucket_id='exb-devis-publics' and peut(org_du_chemin(name),'devis',true) and licence_ecriture_ok(org_du_chemin(name)));
drop policy if exists devis_pub_suppr on storage.objects;
create policy devis_pub_suppr on storage.objects for delete to authenticated
  using (bucket_id='exb-devis-publics' and peut(org_du_chemin(name),'devis',true) and licence_ecriture_ok(org_du_chemin(name)));

-- ---------- PUBLIC : consulter un devis (référence + code d'accès) ----------
create or replace function devis_public_get(p_ref text, p_code text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  r devis_publics;
  c text := upper(regexp_replace(coalesce(p_code,''), '[^A-Za-z0-9]', '', 'g'));
begin
  if p_ref is null or length(p_ref) > 40 or length(c) < 4 then return null; end if;
  select * into r from devis_publics where ref = upper(btrim(p_ref)) and code = c and actif;
  if not found then return null; end if;
  return jsonb_build_object(
    'genre', 'devis', 'ref', r.ref, 'titre', r.projet, 'date', coalesce(r.date_devis, r.maj_le::date),
    'devis_no', r.devis_no, 'client', r.client, 'prestataire', r.prestataire, 'montant', r.montant,
    'validite', r.validite, 'statut', r.statut, 'apercu', r.apercu, 'docs', r.docs);
end $$;
revoke all on function devis_public_get(text,text) from public;
grant execute on function devis_public_get(text,text) to anon, authenticated;

-- ---------- ÉQUIPE : publier (ou mettre à jour) un devis ----------
create or replace function devis_public_publier(
  p_org uuid, p_no text, p_projet text, p_client text, p_prestataire text, p_montant text, p_validite text,
  p_date text, p_statut text, p_empreinte text, p_apercu text, p_docs jsonb, p_token text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_docs jsonb; v_ap text; v_row devis_publics; v_ref text; v_code text; v_n int; v_yr text := to_char(now(),'YYYY'); v_date date; e jsonb;
begin
  if auth.uid() is null or not peut(p_org,'devis',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  if length(btrim(coalesce(p_no,''))) < 1 or length(p_no) > 60 then
    return jsonb_build_object('ok',false,'erreur','Numéro de devis invalide.');
  end if;
  if p_token is null or p_token !~ '^[a-f0-9]{32}$' then
    return jsonb_build_object('ok',false,'erreur','Jeton de dossier invalide.');
  end if;
  if p_docs is null or jsonb_typeof(p_docs) <> 'array' or jsonb_array_length(p_docs) not between 1 and 3 then
    return jsonb_build_object('ok',false,'erreur','Liste de documents invalide.');
  end if;
  for e in select value from jsonb_array_elements(p_docs) loop
    if jsonb_typeof(e) <> 'object' or coalesce(e->>'fichier','') !~ ('^' || p_org::text || '/' || p_token || '/[A-Za-z0-9._-]{1,80}$') then
      return jsonb_build_object('ok',false,'erreur','Chemin de document invalide.');
    end if;
  end loop;
  select jsonb_agg(jsonb_build_object(
      'nom', left(coalesce(x.value->>'nom','Devis'),120),
      'fichier', x.value->>'fichier',
      'format', left(upper(coalesce(x.value->>'format','PDF')),8),
      'taille', left(coalesce(x.value->>'taille',''),30),
      'kind', 'devis'))
    into v_docs from jsonb_array_elements(p_docs) as x;
  v_ap := case when p_apercu is not null and length(p_apercu) <= 500000
                and p_apercu ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' then p_apercu else null end;
  begin v_date := p_date::date; exception when others then v_date := null; end;

  perform pg_advisory_xact_lock(hashtext('devis_publics_ref'));
  select * into v_row from devis_publics where org = p_org and devis_no = btrim(p_no) for update;
  if found then
    update devis_publics set
      projet = left(p_projet,160), client = left(p_client,120), prestataire = left(p_prestataire,120),
      montant = left(p_montant,60), validite = left(p_validite,80), date_devis = v_date, statut = left(p_statut,30),
      empreinte = left(p_empreinte,80), apercu = v_ap, docs = v_docs, token = p_token, actif = true, maj_le = now()
    where id = v_row.id;
    return jsonb_build_object('ok',true,'ref',v_row.ref,'code',v_row.code,'ancien_token',v_row.token,'mise_a_jour',true);
  end if;

  select coalesce(max(substring(ref from '([0-9]+)$')::int),0) + 1 into v_n from devis_publics where ref like 'EXD-' || v_yr || '-%';
  v_ref := 'EXD-' || v_yr || '-' || lpad(v_n::text, 3, '0');
  v_code := upper(substr(replace(gen_random_uuid()::text,'-',''),1,10));
  insert into devis_publics(org, ref, code, token, devis_no, projet, client, prestataire, montant, validite, date_devis, statut, empreinte, apercu, docs)
  values (p_org, v_ref, v_code, p_token, btrim(p_no), left(p_projet,160), left(p_client,120), left(p_prestataire,120),
          left(p_montant,60), left(p_validite,80), v_date, left(p_statut,30), left(p_empreinte,80), v_ap, v_docs);
  return jsonb_build_object('ok',true,'ref',v_ref,'code',v_code);
end $$;
revoke all on function devis_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,jsonb,text) from public;
grant execute on function devis_public_publier(uuid,text,text,text,text,text,text,text,text,text,text,jsonb,text) to authenticated;

-- ---------- ÉQUIPE : retirer une publication (le client ne peut plus rien télécharger) ----------
create or replace function devis_public_retirer(p_org uuid, p_ref text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_row devis_publics;
begin
  if auth.uid() is null or not peut(p_org,'devis',true) or not licence_ecriture_ok(p_org) then
    return jsonb_build_object('ok',false,'erreur','Accès refusé.');
  end if;
  update devis_publics set actif = false, maj_le = now()
   where org = p_org and ref = upper(btrim(p_ref)) returning * into v_row;
  if not found then return jsonb_build_object('ok',false,'erreur','Référence inconnue.'); end if;
  return jsonb_build_object('ok',true,'token',v_row.token,'devis_no',v_row.devis_no);
end $$;
revoke all on function devis_public_retirer(uuid,text) from public;
grant execute on function devis_public_retirer(uuid,text) to authenticated;

-- ---------- ÉQUIPE : liste des devis publiés ----------
create or replace function devis_public_lister(p_org uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not peut(p_org,'devis',false) then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('ref',ref,'code',code,'devis_no',devis_no,'client',client,'projet',projet,
             'montant',montant,'statut',statut,'actif',actif,'maj_le',maj_le) order by maj_le desc)
      from devis_publics where org = p_org), '[]'::jsonb);
end $$;
revoke all on function devis_public_lister(uuid) from public;
grant execute on function devis_public_lister(uuid) to authenticated;
