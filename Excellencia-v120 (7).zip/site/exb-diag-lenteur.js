/* V121c — diagnostic de lenteur : repère les tâches automatiques (minuteries) qui bloquent l'écran plus de 300 ms.
 * Garde les 30 dernières dans « exb_diag_lent » (sur l'appareil seulement, jamais synchronisé). Aucun contenu saisi n'est lu.
 * Rapport : Ctrl + Alt + L (ou EXBDiag.rapport() dans la console). À charger EN PREMIER (avant les autres scripts). */
(function(w){'use strict';
if(w.EXBDiag)return;
var KEY='exb_diag_lent',SEUIL=300,MAX=30,VER='V120';
try{if(w.localStorage.getItem(KEY+'_v')!==VER){w.localStorage.removeItem(KEY);w.localStorage.setItem(KEY+'_v',VER)}}catch(e){}
var ALERT0=w.alert,cache=0,cacheDe=0;
try{w.addEventListener('visibilitychange',function(){if(w.document.hidden)cache=Date.now();else cacheDe=Date.now()})}catch(e){}
/* Boîtes de dialogue natives (alert/confirm/prompt) : durée d'attente notée avec le début du message, pour distinguer « fenêtre restée ouverte » d'un vrai calcul. */
/* V144 : registre des boîtes de dialogue natives (alert/confirm/prompt), y compris dans les cadres (iframe) de même origine,
   et dernier contrôle cliqué : le rapport distingue « fenêtre restée ouverte » d'un vrai blocage et nomme le bouton en cause. */
var DLG=[],CLIC={t:0,d:''},REC=0,RECK=KEY+'_rec';
function desc(el){try{var s=(el.tagName||'?').toLowerCase();if(el.id)s+='#'+el.id;else if(el.className&&typeof el.className==='string')s+='.'+el.className.trim().split(/\s+/)[0];var tx=(el.innerText||el.value||el.title||'').replace(/\s+/g,' ').trim().slice(0,30);if(tx)s+=' « '+tx+' »';return s}catch(e){return '?'}}
function suivreClic(d){try{['pointerdown','keydown'].forEach(function(ev){d.addEventListener(ev,function(e){var t=e.target&&e.target.closest?(e.target.closest('button,a,[onclick],input,select,textarea,summary,[role=button]')||e.target):e.target;CLIC={t:Date.now(),d:(e.type==='keydown'?'touche '+e.key+' sur ':'clic sur ')+desc(t)+(d!==w.document?' (dans un cadre)':'')}},{capture:true,passive:true})})}catch(e){}}
function surDialogue(deb,fin){var o=0;DLG.forEach(function(x){o+=Math.max(0,Math.min(x.b,fin)-Math.max(x.a,deb))});return o>=0.5*(fin-deb)}
function apresClic(fin){return CLIC.t&&fin-CLIC.t<30000?' ← '+CLIC.d:''}
function emballerDlg(W){['alert','confirm','prompt'].forEach(function(n){try{var o=W[n];if(!o||o.__diag)return;var f=function(m){var t=Date.now(),r=o.apply(W,arguments),b=Date.now(),d=b-t;DLG.push({a:t,b:b});if(DLG.length>40)DLG.shift();if(d>=1000&&!w.__diagRapport)noter('(boîte de dialogue '+n+(W!==w?' dans un cadre':'')+' restée ouverte : « '+String(m==null?'':m).replace(/\s+/g,' ').slice(0,70)+' ») ['+(r===false||r===null?'annulé':r===true?'accepté':'répondu')+']'+apresClic(t),d);return r};f.__diag=1;W[n]=f}catch(e){}})}
emballerDlg(w);suivreClic(w.document);
function cadres(){try{Array.prototype.forEach.call(w.document.querySelectorAll('iframe'),function(fr){var go=function(){try{var W=fr.contentWindow;if(W&&W.document&&!W.__diagDlg){emballerDlg(W);suivreClic(W.document);W.__diagDlg=1}}catch(e){}};go();if(!fr.__diagL){fr.__diagL=1;fr.addEventListener('load',function(){try{fr.contentWindow.__diagDlg=0}catch(e){}go()})}})}catch(e){}}
try{w.document.addEventListener('DOMContentLoaded',cadres);w.addEventListener('load',cadres);setInterval(cadres,3000)}catch(e){}
function lire(){try{return JSON.parse(w.localStorage.getItem(KEY)||'[]')||[]}catch(e){return []}}
function noter(nom,ms){try{var L=lire();L.push({t:new Date().toISOString(),ms:Math.round(ms),job:nom});w.localStorage.setItem(KEY,JSON.stringify(L.slice(-MAX)))}catch(e){}}
function nom(f){try{return String(f).replace(/\s+/g,' ').slice(0,90)}catch(e){return '?'}}
/* V137 : pendant qu'on tape dans un champ (recherche, nom, saisie), les tâches automatiques répétées (≥ 1 s) sont reportées
   au prochain passage : la frappe n'est plus jamais ralentie par une tâche de fond. */
var derniere=0;
try{['keydown','input','compositionupdate'].forEach(function(ev){w.document.addEventListener(ev,function(){derniere=Date.now()},{capture:true,passive:true})})}catch(e){}
/* V155 GARDIEN DE SAISIE : si une frappe dans un champ met plus de 200 ms à s'afficher (Event Timing), le « mode protégé » s'active 20 s :
   tâches de fond reportées tant que le champ a le focus et rafales d'observateurs DOM regroupées. La cause (champ + script) est notée dans le rapport. */
var protegeJusqua=0,nbLent=0,dernierLent=0;
function protege(){return Date.now()<protegeJusqua}
function enSaisie(){try{if(Date.now()-derniere>(protege()?20000:1500))return false;var a=w.document.activeElement,t=a&&a.tagName;return t==='INPUT'||t==='TEXTAREA'||(a&&a.isContentEditable)||false}catch(e){return false}}
function emballer(f,periodique){
  if(typeof f!=='function'||f.__exbDiag)return f;
  var att=0;
  var g=function(){
    if(periodique&&enSaisie())return;
    /* V155 FLUIDITÉ : une tâche périodique (≥ 1 s) ne s'exécute plus au milieu d'une action de l'utilisateur : elle attend un moment
       de repos du navigateur (au plus 1,5 s), et jamais deux fois en attente (pas d'empilement si le poste est chargé). */
    if(periodique&&w.requestIdleCallback){if(att)return;att=1;var self=this,args=arguments;
      w.requestIdleCallback(function(){att=0;if(enSaisie())return;exec(self,args)},{timeout:1500});return}
    return exec(this,arguments)};
  function exec(th,args){var t0=Date.now();try{return f.apply(th,args)}finally{var d=Date.now()-t0;if(d>=SEUIL)noter(nom(f),d)}}
  g.__exbDiag=1;return g}
var si=w.setInterval,st=w.setTimeout;
w.setInterval=function(f,d){var a=Array.prototype.slice.call(arguments);a[0]=emballer(f,(d|0)>=1000);return si.apply(w,a)};
w.setTimeout=function(f,d){var a=Array.prototype.slice.call(arguments);if((d|0)>=1000)a[0]=emballer(f);return st.apply(w,a)};
/* V137b : observateurs de DOM (MutationObserver) — leurs rappels sont chronométrés et, s'ils se déclenchent en rafale
   (boucle d'un script qui modifie la page que l'autre surveille), regroupés : au plus 4 exécutions par seconde et par observateur. */
try{var MO=w.MutationObserver;if(MO&&!MO.__exbDiag){
  var MO2=function(cb){var last=0,pend=null,rec=[],self=null,tm=null;
    function run(){tm=null;var r=rec;rec=[];last=Date.now();var t0=last;try{cb.call(self,r,self)}catch(e){try{w.setTimeout(function(){throw e},0)}catch(e2){}}var d=Date.now()-t0;if(d>=SEUIL)noter('(observateur DOM) '+nom(cb),d)}
    var hist=[];
    var o=new MO(function(r){self=o;rec=rec.concat(r);var n=Date.now(),dt=n-last;hist.push(n);while(hist.length&&n-hist[0]>1000)hist.shift();
      /* en fonctionnement normal : exécution immédiate ; seulement en rafale (≥ 12 déclenchements en 1 s) : regroupement toutes les 250 ms */
      if(hist.length<12&&!(protege()&&enSaisie())){if(tm){w.clearTimeout(tm);tm=null}run()}else if(!tm){tm=st(run,Math.max(0,(protege()?400:250)-dt))}});
    var tr=o.takeRecords.bind(o);o.takeRecords=function(){var x=rec.concat(tr());rec=[];return x};
    return o};
  MO2.prototype=MO.prototype;MO2.__exbDiag=1;w.MutationObserver=MO2}}catch(e){}
try{if(w.PerformanceObserver&&(w.PerformanceObserver.supportedEntryTypes||[]).indexOf('event')>=0)
  new w.PerformanceObserver(function(l){l.getEntries().forEach(function(e){
    if(e.duration<200||!/^(keydown|keypress|keyup|beforeinput|input|compositionupdate)$/.test(e.name))return;
    var t=e.target,tg=t&&t.tagName;if(!(tg==='INPUT'||tg==='TEXTAREA'||(t&&t.isContentEditable)))return;
    var n=Date.now();protegeJusqua=n+20000;nbLent++;
    if(n-dernierLent<3000)return;dernierLent=n;
    /* jamais le contenu saisi : seulement la balise, l'identifiant et la classe du champ */
    var lb=(tg||'?').toLowerCase()+(t.id?'#'+t.id:(typeof t.className==='string'&&t.className.trim()?'.'+t.className.trim().split(/\s+/)[0]:''));
    noter('(saisie lente '+Math.round(e.duration)+' ms, '+e.name+') sur '+lb+' ['+(w.location.hash||'')+']',e.duration)})}).observe({type:'event',durationThreshold:104,buffered:false})}catch(e){}
/* V137b : images d'écran longues (Long Animation Frames, Chrome/Edge récents) : indiquent le script et la fonction responsables */
try{if(w.PerformanceObserver&&(w.PerformanceObserver.supportedEntryTypes||[]).indexOf('long-animation-frame')>=0)
  new w.PerformanceObserver(function(l){l.getEntries().forEach(function(e){var seuil=REC?200:1000;if(e.duration<seuil||w.__diagRapport)return;var f0=Date.now(),d0=f0-e.duration;if(surDialogue(d0,f0))return;var sc=(e.scripts||[]).slice().sort(function(a,b){return b.duration-a.duration})[0];
    noter('(image longue) '+(sc?(sc.invokerType+' '+(sc.invoker||'')+' '+String(sc.sourceURL||'').split('/').pop()+':'+(sc.sourceFunctionName||'?')+':'+(sc.sourceCharPosition||'')):'sans script (style/mise en page '+Math.round(e.styleAndLayoutStart?e.startTime+e.duration-e.styleAndLayoutStart:0)+' ms)')+' ['+(w.location.hash||w.location.pathname.split('/').pop()||'/')+']'+apresClic(d0),e.duration)})}).observe({type:'long-animation-frame',buffered:true})}catch(e){}
try{var raf=w.requestAnimationFrame;w.requestAnimationFrame=function(f){return raf.call(w,emballer(f))}}catch(e){}
try{if(w.PerformanceObserver&&(w.PerformanceObserver.supportedEntryTypes||[]).indexOf('longtask')>=0)
  new w.PerformanceObserver(function(l){l.getEntries().forEach(function(e){var seuil=REC?200:1000;if(e.duration<seuil||w.__diagRapport)return;var fin=Date.now(),deb=fin-e.duration;if(surDialogue(deb,fin))return;var veille=w.document.hidden||(cache&&cache>deb-1000&&cache<fin+1000)||(cacheDe&&cacheDe>deb&&cacheDe<fin+1000);noter(veille?'(onglet masqué ou ordinateur en veille ~'+Math.round(e.duration/1000)+' s — pas un calcul)':e.duration>=5000?'(arrêt de '+Math.round(e.duration/1000)+' s sans boîte de dialogue ni veille détectée : à signaler)'+apresClic(deb):'(blocage écran, source inconnue)'+apresClic(deb),e.duration)})}).observe({entryTypes:['longtask']})}catch(e){}
function rapport(){var L=lire();if(!L.length)return 'Aucun blocage de plus de '+SEUIL+' ms enregistré.';
  var par={};L.forEach(function(x){var p=par[x.job]||(par[x.job]={n:0,max:0,der:''});p.n++;p.max=Math.max(p.max,x.ms);p.der=x.t});
  return Object.keys(par).sort(function(a,b){return par[b].max-par[a].max}).map(function(k){return par[k].max+' ms max · '+par[k].n+' fois · '+k}).join('\n')}
function rec(){return lire().filter(function(x){return x.r})}
function finEssai(auto){REC=0;try{w.localStorage.removeItem(RECK)}catch(e){}var R=rec(),txt='Essai d’enregistrement terminé'+(auto?' (10 min)':'')+' — '+R.length+' blocage(s) ≥ 200 ms hors boîtes de dialogue.\n\n'+(R.length?R.map(function(x){return x.t.slice(11,19)+' · '+x.ms+' ms · '+x.job}).join('\n'):'Aucun vrai blocage : les attentes longues venaient de fenêtres de dialogue.');
  try{var a=w.document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'text/plain'}));a.download='essai-blocages-excellencia.txt';w.document.body.appendChild(a);a.click();setTimeout(function(){a.remove()},500)}catch(e){}
  w.__diagRapport=1;try{ALERT0.call(w,txt)}finally{setTimeout(function(){w.__diagRapport=0},400)}}
function debutEssai(fin){REC=fin;try{w.localStorage.setItem(RECK,String(fin))}catch(e){}st(function(){if(REC===fin)finEssai(1)},Math.max(1000,fin-Date.now()))}
try{var rk=+w.localStorage.getItem(RECK)||0;if(rk>Date.now())debutEssai(rk)}catch(e){}
var noter0=noter;noter=function(n,ms){try{var L=lire();L.push({t:new Date().toISOString(),ms:Math.round(ms),job:n,r:REC?1:0});w.localStorage.setItem(KEY,JSON.stringify(L.slice(-(REC?200:MAX))))}catch(e){}};
/* V155 : garde mémoire (Chrome/Edge). Au-delà de 85 % du plafond de mémoire de l'onglet : incident noté et avertissement unique,
   avant le plantage « Aw, Snap ». Recommande de sauvegarder puis recharger l'application. */
try{if(w.performance&&w.performance.memory){var memAvert=0;st(function m(){try{var M=w.performance.memory,r=M.usedJSHeapSize/M.jsHeapSizeLimit;
  if(r>0.85&&!memAvert){memAvert=1;noter('(mémoire '+Math.round(M.usedJSHeapSize/1048576)+' Mo sur '+Math.round(M.jsHeapSizeLimit/1048576)+' Mo)',0);
    try{if(typeof w.notify==='function')w.notify('⚠️ Mémoire presque saturée : enregistrez votre travail puis rechargez la page (F5) pour éviter un blocage.','warn',12000)}catch(e){}}
  else if(r<0.7)memAvert=0}catch(e){}st(m,30000)},30000)}}catch(e){}
w.EXBDiag={protege:protege,saisiesLentes:function(){return nbLent},rapport:rapport,effacer:function(){try{w.localStorage.removeItem(KEY)}catch(e){}},version:VER,essai:function(min){debutEssai(Date.now()+(min||10)*60000)},finEssai:finEssai};
w.addEventListener('keydown',function(e){if(e.ctrlKey&&e.altKey&&(e.key==='l'||e.key==='L')){e.preventDefault();w.__diagRapport=1;try{ALERT0.call(w,'Tâches qui ont bloqué l’écran :\n\n'+rapport()+'\n\n(Ctrl + Alt + T : essai de 10 minutes)')}finally{setTimeout(function(){w.__diagRapport=0},400)}}
  if(e.ctrlKey&&e.altKey&&(e.key==='t'||e.key==='T')){e.preventDefault();if(REC)finEssai(0);else{debutEssai(Date.now()+600000);w.__diagRapport=1;try{ALERT0.call(w,'Essai de 10 minutes démarré. Travaillez normalement ; à la fin (ou en refaisant Ctrl + Alt + T) le rapport s’affiche et un fichier est téléchargé.')}finally{setTimeout(function(){w.__diagRapport=0},400)}}}});
})(window);
