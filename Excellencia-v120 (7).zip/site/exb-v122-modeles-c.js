/* Excellencia Building V122 — Série C : rapports, procès-verbaux, clauses, fiches de contrôle, CCAP par type d’ouvrage, lots CCTP.
 * Objectif : au moins 50 modèles par onglet « Pièces écrites ». N’écrase jamais un modèle existant.
 * Ces textes sont des bases courantes : à faire valider par votre conseil juridique (clauses et CCAP surtout). */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA; if (!D) return;
  var FT = '\n\nFait à {{ville}}, le {{date}}';
  function merge(t, src) { var dst = D.models[t] || (D.models[t] = {}); Object.keys(src).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(dst, k)) dst[k] = src[k]; }); }
  var HD = function (t) { return '# ' + t + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}\nDate : {{date_effet}}\n'; };
  var PVHEAD = function (t) { return '# PROCÈS-VERBAL DE ' + t.toUpperCase() + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}\nDate : {{date_effet}}\n'; };

  /* ---------- RAPPORTS ---------- */
  var RPX = function (t, secs) {
    return HD('RAPPORT — ' + t.toUpperCase()) + secs.split('|').map(function (s) { return '## ' + s + '\n- ____________________'; }).join('\n') + FT;
  };
  var RPL = [
    ['Visite préalable du site', 'Accès et environnement|État du terrain|Réseaux existants|Contraintes particulières|Conclusion et recommandations'],
    ['État des lieux avant travaux', 'Description des ouvrages existants|Désordres constatés|Photos|Observations des parties'],
    ['Avancement des fondations', 'Fouilles et fond de fouille|Ferraillage|Bétonnage|Essais réalisés|Prévisions'],
    ['Avancement du gros œuvre', 'Structure réalisée|Maçonnerie|Dalles et toiture|Écart par rapport au planning|Prévisions'],
    ['Avancement du second œuvre', 'Corps d’état présents|Travaux réalisés|Coordination|Retards et causes|Prévisions'],
    ['Essais d’étanchéité', 'Ouvrage essayé|Méthode d’essai|Résultats|Conclusion'],
    ['Essais de plomberie', 'Réseaux essayés|Pressions relevées|Fuites constatées|Conclusion'],
    ['Essais électriques', 'Circuits contrôlés|Mesures d’isolement et de terre|Anomalies|Conclusion'],
    ['Contrôle des aciers livrés', 'Bons de livraison|Diamètres et longueurs|Certificats|État de surface|Décision'],
    ['Compactage et densité des remblais', 'Zone contrôlée|Épaisseur des couches|Densités mesurées|Conclusion'],
    ['Analyse des retards', 'Retards constatés|Causes (internes / externes)|Incidence sur la date d’achèvement|Plan de rattrapage'],
    ['Analyse des écarts de budget', 'Budget initial|Dépenses réelles|Écarts et causes|Mesures correctives'],
    ['Évaluation d’un fournisseur', 'Qualité des produits|Respect des délais|Prix|Service après-vente|Note globale'],
    ['Évaluation d’un sous-traitant', 'Qualité d’exécution|Respect des délais|Sécurité|Administratif|Note globale'],
    ['Formation à la sécurité', 'Thème et durée|Participants|Contenu|Évaluation|Suites'],
    ['Accident du travail', 'Victime et circonstances|Lieu et heure|Secours apportés|Causes|Mesures de prévention'],
    ['Inspection sécurité hebdomadaire', 'Équipements de protection|Échafaudages et protections|Engins|Électricité|Actions correctives'],
    ['Qualité mensuel', 'Contrôles réalisés|Non-conformités ouvertes|Non-conformités clôturées|Actions d’amélioration'],
    ['Suivi des non-conformités', 'Liste des non-conformités|Causes|Actions menées|Clôtures'],
    ['Levée des réserves', 'Réserves initiales|Réserves levées|Réserves restantes|Délai de levée'],
    ['Inspection de toiture', 'État de la couverture|Étanchéité|Évacuation des eaux|Réparations conseillées'],
    ['Diagnostic d’un bâtiment existant', 'Description|Structure|Second œuvre|Pathologies relevées|Travaux conseillés et estimation'],
    ['Relevé de fissures', 'Localisation|Largeur et longueur|Évolution|Cause probable|Traitement proposé'],
    ['Pointage et utilisation du matériel', 'Engins et outils présents|Heures d’utilisation|Pannes|Besoins complémentaires'],
    ['Consommation de carburant', 'Engins concernés|Quantités distribuées|Heures de travail|Écarts constatés'],
    ['Incident de matériel', 'Matériel concerné|Description de l’incident|Cause|Réparation et délai'],
    ['Visite de réception préalable', 'Locaux visités|Défauts relevés|Délai de correction|Date de la réception'],
    ['Comparaison d’offres', 'Offres reçues|Critères d’analyse|Classement|Proposition de choix'],
    ['Étude de faisabilité', 'Contexte|Contraintes techniques|Estimation du coût|Délai|Avis et recommandations'],
    ['Conformité réglementaire', 'Exigences applicables|Constats|Écarts|Actions de mise en conformité']
  ];
  var RP = {}; RPL.forEach(function (r) { RP['Rapport — ' + r[0]] = RPX(r[0], r[1]); });
  merge('rapport', RP);

  /* ---------- PROCÈS-VERBAUX ---------- */
  var PVX = function (t, pts) {
    return PVHEAD(t) + '\n| Point | Constat | Observation |\n' + pts.split('|').map(function (p) { return '| ' + p + ' | ____________ | ____________ |'; }).join('\n') + '\n## Décision\n____________________' + FT;
  };
  var PVL = [
    ['Réception des plans', 'Plans remis|Indice|Conformité à la demande'],
    ['Remise de site à l’entreprise', 'Limites du terrain|Accès|Réseaux existants|État des lieux'],
    ['Livraison d’un engin', 'Désignation|État à la livraison|Heures compteur|Accessoires'],
    ['Mise en service d’une installation électrique', 'Essais réalisés|Mesures|Anomalies|Mise sous tension'],
    ['Mise en service d’une installation de plomberie', 'Essais de pression|Fuites|Débits|Mise en eau'],
    ['Essai d’étanchéité', 'Ouvrage|Méthode|Durée|Résultat'],
    ['Essai de charge', 'Élément essayé|Charge appliquée|Flèche mesurée|Conclusion'],
    ['Décoffrage', 'Élément|Âge du béton|Aspect|Autorisation de décoffrer'],
    ['Contrôle d’implantation', 'Axes|Niveaux|Écarts mesurés|Validation'],
    ['Visite de chantier', 'Zones visitées|Constats|Remarques|Suites'],
    ['Désignation du chef de chantier', 'Identité|Pouvoirs|Contacts|Date de prise de fonction'],
    ['Remise des plans d’exécution', 'Plans remis|Indice|Destinataire|Date'],
    ['Constat de vol ou de dégradation', 'Nature|Matériel concerné|Estimation|Plainte déposée'],
    ['Dépôt de matériel sur le chantier', 'Désignation|Quantité|État|Gardien responsable'],
    ['Transfert de matériel entre chantiers', 'Matériel|Chantier d’origine|Chantier de destination|État'],
    ['Passation de chantier', 'État d’avancement|Documents remis|Matériel et stocks|Points sensibles'],
    ['Démarrage des travaux', 'Ordre de service|Installations|Personnel|Date de démarrage'],
    ['Réception des travaux de carrelage', 'Planéité|Joints|Adhérence|Propreté'],
    ['Réception des menuiseries', 'Dimensions|Fonctionnement|Étanchéité|Quincaillerie'],
    ['Réception de la toiture', 'Couverture|Étanchéité|Évacuation des eaux|Fixations'],
    ['Réception d’une clôture', 'Alignement|Solidité|Portail|Finitions'],
    ['Réception de voirie', 'Niveaux|Compactage|Revêtement|Évacuation des eaux'],
    ['Remise des garanties', 'Garanties remises|Durée|Contacts|Procédure de signalement'],
    ['Constat de non-conformité', 'Ouvrage|Écart|Référence non respectée|Correction demandée'],
    ['Accord amiable', 'Objet du désaccord|Solution convenue|Engagements|Échéances'],
    ['Conciliation', 'Parties|Positions|Propositions du conciliateur|Accord'],
    ['Décharge de responsabilité', 'Objet|Parties|Conditions|Date d’effet'],
    ['Prise de possession anticipée', 'Parties concernées|État des lieux|Conditions|Réserves'],
    ['Remise d’échantillons', 'Échantillons remis|Références|Destinataire|Délai de réponse'],
    ['Métré contradictoire', 'Poste|Quantité contrôlée|Écart|Accord'],
    ['Remise de documents administratifs', 'Documents remis|Date de validité|Destinataire|Observations']
  ];
  var PV = {}; PVL.forEach(function (r) { PV[r[0]] = PVX(r[0], r[1]); });
  merge('pv', PV);

  /* ---------- CLAUSES ---------- */
  var CLX = function (t, arts) {
    return '# CLAUSES ' + t.toUpperCase() + '\nProjet : {{projet}} — {{lieu}}\n' + arts.split('||').map(function (a, i) { var p = a.split('::'); return '## Article ' + (i + 1) + ' — ' + p[0] + '\n' + p[1]; }).join('\n');
  };
  var CLL = [
    ['de pénalités pour manquement à la sécurité', 'Principe::Tout manquement grave aux règles de sécurité peut donner lieu à une pénalité de ____________ par constat.||Constat::Le manquement est consigné par écrit, signé du maître d’œuvre.||Récidive::En cas de récidive, la pénalité est doublée et l’arrêt des travaux concernés peut être ordonné.'],
    ['de visite et de contrôle de chantier', 'Accès::Le maître d’ouvrage et la maîtrise d’œuvre accèdent librement au chantier.||Contrôles::Ils peuvent demander tout essai ou document utile.||Coopération::L’entreprise facilite les visites et corrige les observations.'],
    ['de variation des quantités', 'Marché à prix unitaires::Les quantités sont indicatives et payées selon les quantités réellement exécutées.||Seuil::Au-delà de ± ___ %, les prix peuvent être renégociés.||Accord::Tout changement important est constaté par avenant.'],
    ['d’approvisionnement et de stockage', 'Approvisionnement::L’entreprise approvisionne le chantier en temps utile.||Stockage::Les matériaux sont stockés à l’abri, en bon ordre, aux emplacements convenus.||Responsabilité::L’entreprise répond de la garde de ses matériaux.'],
    ['relatives aux découvertes fortuites', 'Principe::Toute découverte (vestiges, réseaux inconnus, pollution) est signalée immédiatement.||Arrêt::Les travaux concernés sont suspendus jusqu’à instruction du maître d’ouvrage.||Coûts::Les frais supplémentaires sont réglés par avenant.'],
    ['de protection des avoisinants', 'Constat::Un constat des avoisinants est dressé avant travaux.||Précautions::L’entreprise limite vibrations, poussières et bruit.||Dommages::L’entreprise répare les dommages dont elle est responsable.'],
    ['de langue et de communication', 'Langue::Les documents du marché sont rédigés en ____________.||Communications::Les communications importantes sont écrites et datées.||Accusé de réception::Chaque partie accuse réception des ordres de service.'],
    ['de notification et d’élection de domicile', 'Adresses::Chaque partie élit domicile à l’adresse indiquée au marché.||Notifications::Elles sont faites par écrit contre décharge ou par lettre recommandée.||Changement::Tout changement d’adresse est notifié sans délai.'],
    ['de pièces constitutives du marché', 'Ordre de priorité::Acte d’engagement, CCAP, CCTP, plans, devis ou bordereau.||Contradictions::En cas de contradiction, l’ordre ci-dessus prévaut.||Annexes::Les annexes font partie du marché.'],
    ['de modification du marché', 'Principe::Toute modification est constatée par avenant écrit.||Ordre de service::Elle peut être précédée d’un ordre de service urgent.||Limites::Les modifications ne peuvent changer l’objet du marché.'],
    ['de cession et de nantissement', 'Cession::Le marché ne peut être cédé sans l’accord écrit du maître d’ouvrage.||Créances::Les créances peuvent être cédées dans les limites prévues par la loi de {{pays}}.||Notification::Toute cession est notifiée au maître d’ouvrage.'],
    ['en cas d’incapacité ou de défaillance de l’entreprise', 'Incapacité::En cas de défaillance, le maître d’ouvrage peut faire achever les travaux aux frais de l’entreprise.||Constat::Un état des travaux exécutés est dressé.||Garanties::Les garanties du marché peuvent être mises en jeu.'],
    ['de remise en état des lieux', 'Obligation::À la fin des travaux, l’entreprise remet les lieux en état.||Inclus::Démontage des installations, évacuation des déchets, réparation des dégradations.||Contrôle::La remise en état est constatée par procès-verbal.'],
    ['de matériel fourni par le maître d’ouvrage', 'Liste::Le matériel et les fournitures du maître d’ouvrage sont listés en annexe.||Garde::L’entreprise les garde et les emploie avec soin.||Défauts::Elle signale immédiatement tout défaut.'],
    ['sociales et d’emploi local', 'Emploi local::L’entreprise privilégie l’embauche de main-d’œuvre locale qualifiée lorsque cela est possible.||Conditions::Salaires et conditions conformes à la législation de {{pays}}.||Formation::Elle favorise la formation des jeunes sur le chantier.'],
    ['de lutte contre la corruption', 'Engagement::Les parties s’interdisent toute offre ou acceptation d’avantage indu.||Signalement::Tout soupçon est signalé à la direction.||Sanctions::La violation peut entraîner la résiliation du marché.'],
    ['de contrôle des comptes et de transparence', 'Documents::L’entreprise conserve les justificatifs des dépenses.||Audit::Le maître d’ouvrage peut vérifier les comptes liés au marché.||Durée::Conservation pendant ___ ans.'],
    ['de repli de chantier', 'Délai::Le repli est achevé dans les ___ jours suivant la réception.||Contenu::Démontage, évacuation, nettoyage, remise en état.||Retenue::Une retenue peut être appliquée tant que le repli n’est pas terminé.'],
    ['de limitation de responsabilité', 'Plafond::La responsabilité de ____________ est limitée au montant de ____________, sauf faute lourde.||Exclusions::Les dommages indirects sont exclus.||Assurance::La responsabilité est couverte par l’assurance souscrite.'],
    ['de maintenance pendant la période de garantie', 'Intervention::L’entreprise intervient sous ___ jours après signalement d’un désordre.||Urgences::Les urgences sont traitées sous 48 heures.||Coût::Réparations à la charge de l’entreprise si le désordre est couvert.'],
    ['de formation à l’utilisation des ouvrages', 'Formation::L’entreprise forme le personnel du maître d’ouvrage à l’utilisation des équipements.||Documents::Notices d’utilisation remises en langue ____________.||Attestation::Une attestation de formation est signée.'],
    ['d’échantillons et de prototypes', 'Présentation::Échantillons et prototypes sont présentés avant commande.||Approbation::Aucune fourniture n’est commandée sans approbation écrite.||Conservation::Les échantillons approuvés servent de référence.'],
    ['de gardiennage et de sûreté', 'Surveillance::Le chantier est surveillé en dehors des heures de travail.||Accès::Seules les personnes autorisées entrent sur le chantier.||Vols::Les vols imputables à un défaut de surveillance sont à la charge de l’entreprise.'],
    ['de remise des documents numériques', 'Format::Plans en format ____________, documents en PDF.||Remise::Sur support numérique avec index.||Droits::L’entreprise garantit disposer des droits sur les documents remis.'],
    ['d’hygiène de la base de vie', 'Installations::Vestiaires, sanitaires et réfectoire propres et entretenus.||Eau::Eau potable en permanence.||Contrôle::Vérification par le responsable sécurité.']
  ];
  var CL = {}; CLL.forEach(function (r) { CL['Clauses ' + r[0]] = CLX(r[0], r[1]); });
  merge('clause', CL);

  /* ---------- FICHES DE CONTRÔLE ET FORMULAIRES ---------- */
  var CK = function (t, pts) {
    return HD('FICHE DE CONTRÔLE — ' + t) + '\n| Point à contrôler | Référence (plan / CCTP) | Conforme | Observation |\n' +
      pts.split('|').map(function (p) { return '| ' + p + ' | ____________ | oui / non | ____________ |'; }).join('\n') +
      '\n## Décision\nContrôle satisfaisant / à reprendre avant le ____________\nContrôlé par : ____________ — fonction : ____________' + FT;
  };
  var CKL = [
    ['MENUISERIE', 'Dimensions|Aplomb|Fonctionnement|Étanchéité|Quincaillerie'],
    ['TOITURE', 'Pentes|Fixations|Recouvrements|Faîtage|Gouttières'],
    ['FAUX PLAFONDS', 'Niveau|Fixation de l’ossature|Joints|Trappes de visite|Finitions'],
    ['FONDATIONS', 'Cotes et niveaux|Sol d’assise|Béton de propreté|Ferraillage|Coulage'],
    ['TERRASSEMENT', 'Implantation|Profondeur|Pentes de talus|Évacuation des déblais|Propreté'],
    ['REMBLAI ET COMPACTAGE', 'Matériau|Épaisseur des couches|Humidité|Densité|Planéité'],
    ['VOIRIE', 'Fond de forme|Épaisseur de chaussée|Pentes|Revêtement|Bordures'],
    ['PAVAGE', 'Lit de pose|Alignement|Joints|Pentes|Propreté'],
    ['CLÔTURE ET PORTAIL', 'Alignement|Fondations|Solidité|Fonctionnement du portail|Finitions'],
    ['CLIMATISATION ET VENTILATION', 'Implantation|Raccordements|Évacuation des condensats|Essai de fonctionnement|Notice remise'],
    ['SÉCURITÉ INCENDIE', 'Extincteurs|Signalisation|Issues de secours|Alarme|Éclairage de sécurité'],
    ['ASSAINISSEMENT', 'Pentes|Regards|Étanchéité|Fosse|Raccordement'],
    ['POTEAUX EN BÉTON ARMÉ', 'Implantation|Ferraillage|Coffrage|Coulage|Aplomb'],
    ['POUTRES ET DALLES', 'Étaiement|Ferraillage|Réservations|Coulage|Cure'],
    ['ÉCHAFAUDAGE', 'Stabilité|Garde-corps|Planchers|Accès|Vérification quotidienne']
  ];
  var FC = {}; CKL.forEach(function (r) { FC['Fiche de contrôle — ' + r[0].toLowerCase()] = CK(r[0], r[1]); });
  var FRM = {
'Fiche de pointage journalier': '# FICHE DE POINTAGE JOURNALIER\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}}\n| Nom | Fonction | Arrivée | Départ | Heures | Signature |\n| ____________ | ____________ | ____ | ____ | ____ | ____ |\n| ____________ | ____________ | ____ | ____ | ____ | ____ |\n| ____________ | ____________ | ____ | ____ | ____ | ____ |',
'Fiche de réception de fouille': '# FICHE DE RÉCEPTION DE FOUILLE\nProjet : {{projet}} — {{lieu}}\nOuvrage : {{objet}}\n| Point | Mesure | Conforme |\n| Profondeur | ____ | oui / non |\n| Largeur | ____ | oui / non |\n| Nature du sol | ____________ | oui / non |\n| Fond propre et sans eau | ____________ | oui / non |\nAutorisation de poursuivre : oui / non',
'Bon de livraison de chantier': '# BON DE LIVRAISON\nProjet : {{projet}} — {{lieu}}\nFournisseur : ____________ — date : {{date_effet}}\n| Désignation | Quantité | Unité |\n| ____________ | ____ | ____ |\n| ____________ | ____ | ____ |\nReçu par : ____________ — signature : ____________',
'Bon de commande interne': '# BON DE COMMANDE INTERNE N° {{no}}\nProjet : {{projet}} — {{lieu}}\nDate : {{date}} — fournisseur : ____________\n| Désignation | Quantité | Prix unitaire | Montant |\n| ____________ | ____ | ____ | ____ |\n| ____________ | ____ | ____ | ____ |\nApprouvé par : ____________',
'Fiche de suivi du matériel': '# FICHE DE SUIVI DU MATÉRIEL\nProjet : {{projet}} — {{lieu}}\n| Matériel | Date d’arrivée | État | Utilisateur | Date de retour |\n| ____________ | ____ | ____________ | ____________ | ____ |\n| ____________ | ____ | ____________ | ____________ | ____ |',
'Fiche de suivi des essais de béton': '# FICHE DE SUIVI DES ESSAIS DE BÉTON\nProjet : {{projet}} — {{lieu}}\n| Éprouvette n° | Ouvrage | Date de coulage | Résistance 7 j | Résistance 28 j | Conforme |\n| ____ | ____________ | ____ | ____ | ____ | oui / non |\n| ____ | ____________ | ____ | ____ | ____ | oui / non |',
'Fiche de demande d’intervention': '# FICHE DE DEMANDE D’INTERVENTION\nProjet : {{projet}} — {{lieu}}\nDemandeur : ____________ — date : {{date}}\nNature du problème : {{objet}}\nUrgence : faible / moyenne / forte\nIntervention réalisée le : ____________ par : ____________',
'Fiche de réclamation client': '# FICHE DE RÉCLAMATION CLIENT\nProjet : {{projet}} — {{lieu}}\nClient : {{moa}} — date : {{date}}\nObjet de la réclamation : {{objet}}\n| Action | Responsable | Échéance | Réalisée |\n| ____________ | ____________ | ____ | oui / non |',
'Fiche d’évaluation de fournisseur': '# FICHE D’ÉVALUATION DE FOURNISSEUR\nFournisseur : ____________ — période : ____________\n| Critère | Note (1 à 5) | Commentaire |\n| Qualité | ____ | ____________ |\n| Délais | ____ | ____________ |\n| Prix | ____ | ____________ |\n| Service | ____ | ____________ |\nDécision : maintenu / sous surveillance / écarté',
'Fiche d’évaluation de sous-traitant': '# FICHE D’ÉVALUATION DE SOUS-TRAITANT\nSous-traitant : ____________ — chantier : {{projet}}\n| Critère | Note (1 à 5) | Commentaire |\n| Qualité d’exécution | ____ | ____________ |\n| Délais | ____ | ____________ |\n| Sécurité | ____ | ____________ |\n| Administratif | ____ | ____________ |',
'Fiche d’observation sécurité': '# FICHE D’OBSERVATION SÉCURITÉ\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}} — observateur : ____________\n| Situation observée | Danger | Action immédiate | Suivi |\n| ____________ | ____________ | ____________ | ____________ |\n| ____________ | ____________ | ____________ | ____________ |',
'Permis de feu simplifié': '# PERMIS DE FEU\nProjet : {{projet}} — {{lieu}}\nZone : ____________ — date : {{date_effet}} — de ____ h à ____ h\n- Matériaux inflammables éloignés : oui / non\n- Extincteur à proximité : oui / non\n- Surveillance après travaux : ____ minutes\nDélivré par : ____________ — reçu par : ____________',
'Fiche de consignation électrique': '# FICHE DE CONSIGNATION ÉLECTRIQUE\nProjet : {{projet}} — {{lieu}}\nInstallation : ____________ — date : {{date_effet}}\n| Étape | Fait | Heure | Visa |\n| Séparation de la source | oui / non | ____ | ____ |\n| Condamnation | oui / non | ____ | ____ |\n| Vérification d’absence de tension | oui / non | ____ | ____ |\n| Mise à la terre | oui / non | ____ | ____ |',
'Autorisation de travail en hauteur': '# AUTORISATION DE TRAVAIL EN HAUTEUR\nProjet : {{projet}} — {{lieu}}\nTravail : {{objet}} — date : {{date_effet}}\n- Harnais et ancrages contrôlés : oui / non\n- Garde-corps ou filets en place : oui / non\n- Personnel formé : oui / non\nAutorisé par : ____________',
'Fiche de visite médicale du personnel': '# FICHE DE SUIVI DE LA VISITE MÉDICALE\nEntreprise : {{entreprise}}\n| Nom | Fonction | Date de la visite | Aptitude | Prochaine visite |\n| ____________ | ____________ | ____ | apte / inapte | ____ |',
'Fiche de distribution des équipements de protection': '# FICHE DE DISTRIBUTION DES ÉQUIPEMENTS DE PROTECTION\nProjet : {{projet}} — {{lieu}}\n| Nom | Casque | Chaussures | Gilet | Gants | Date | Signature |\n| ____________ | oui / non | oui / non | oui / non | oui / non | ____ | ____ |\n| ____________ | oui / non | oui / non | oui / non | oui / non | ____ | ____ |',
'Fiche de suivi des déchets': '# FICHE DE SUIVI DES DÉCHETS\nProjet : {{projet}} — {{lieu}}\n| Date | Type de déchet | Quantité | Transporteur | Destination |\n| ____ | ____________ | ____ | ____________ | ____________ |\n| ____ | ____________ | ____ | ____________ | ____________ |',
'Fiche de relevé de compteurs': '# FICHE DE RELEVÉ DE COMPTEURS\nProjet : {{projet}} — {{lieu}}\n| Date | Compteur d’eau | Compteur électrique | Relevé par |\n| ____ | ____ | ____ | ____________ |\n| ____ | ____ | ____ | ____________ |',
'Fiche de suivi des réserves': '# FICHE DE SUIVI DES RÉSERVES\nProjet : {{projet}} — {{lieu}}\n| N° | Réserve | Responsable | Délai | Levée le | Contrôlée par |\n| 1 | ____________ | ____________ | ____ | ____ | ____ |\n| 2 | ____________ | ____________ | ____ | ____ | ____ |',
'Fiche de validation d’échantillon': '# FICHE DE VALIDATION D’ÉCHANTILLON\nProjet : {{projet}} — {{lieu}}\nMatériau : ____________ — référence : ____________ — fournisseur : ____________\nAvis : validé / refusé / à compléter\nObservations : ____________________'
  };
  Object.keys(FRM).forEach(function (k) { FC[k] = FRM[k]; });
  merge('fiche', FC);

  /* ---------- CCAP PAR TYPE D’OUVRAGE (prix forfaitaire ou prix unitaires) ---------- */
  var CC = function (ouv, forfait, part) {
    return '# CAHIER DES CLAUSES ADMINISTRATIVES PARTICULIÈRES (CCAP)\nMarché : {{projet}} — {{lieu}} — ' + ouv + '\nMaître d’ouvrage : {{moa}} · Maître d’œuvre : {{societe_rep}} · Entreprise : {{entreprise}}\n' +
      '## Article 1 — Objet du marché\nLe présent marché a pour objet l’exécution des travaux de « ' + ouv + ' » du projet {{projet}} à {{lieu}}.\n' +
      '## Article 2 — Pièces contractuelles\nPar ordre de priorité : l’acte d’engagement, le présent CCAP, le CCTP, les plans d’exécution, ' + (forfait ? 'le devis descriptif.' : 'le bordereau des prix unitaires et le devis quantitatif.') + '\n' +
      '## Article 3 — Prix\n' + (forfait ? 'Prix global et forfaitaire, ferme et non révisable, hors taxes. Toute modification demandée par écrit fait l’objet d’un avenant.' : 'Prix unitaires du bordereau appliqués aux quantités réellement exécutées, mesurées contradictoirement.') + '\n' +
      '## Article 4 — Délai et pénalités\nDélai de ___ jours calendaires à compter de l’ordre de service de démarrage. Pénalité de ___ pour mille par jour de retard, plafonnée à ___ %.\n' +
      '## Article 5 — Paiement\nAvance de ___ % contre garantie ; situations mensuelles visées par la maîtrise d’œuvre ; paiement sous ___ jours ; retenue de garantie de ___ %.\n' +
      '## Article 6 — Particularités de l’ouvrage\n' + part.split('|').map(function (p) { return '- ' + p; }).join('\n') + '\n' +
      '## Article 7 — Assurances et garanties\nAssurance responsabilité civile et, le cas échéant, garantie décennale remises avant démarrage ; garantie de parfait achèvement de ___ mois.\n' +
      '## Article 8 — Sous-traitance\nSoumise à l’accord écrit préalable du maître d’ouvrage.\n' +
      '## Article 9 — Réception\nProcès-verbal de réception avec ou sans réserves ; dossier des ouvrages exécutés remis avant la réception.\n' +
      '## Article 10 — Résiliation et litiges\nMise en demeure de ___ jours avant résiliation ; règlement amiable, puis juridiction compétente de {{ville}} ({{pays}}).' + FT +
      '\n| Le maître d’ouvrage | L’entreprise | Le maître d’œuvre |\n| Lu et approuvé | Lu et approuvé | |';
  };
  var CCO = [
    ['Villa individuelle', 'Plans et descriptif de la villa validés par le client|Choix de finitions approuvés avant commande|Remise des clés après nettoyage final'],
    ['Maison à étage', 'Étude de structure remise avant le gros œuvre|Escalier et planchers contrôlés avant coulage|Étanchéité de la terrasse essayée'],
    ['Immeuble d’habitation', 'Autorisations remises avant démarrage|Phasage par niveaux validé par procès-verbal|Coordination des lots techniques obligatoire'],
    ['Immeuble de bureaux', 'Plateaux aménageables selon le programme|Installations techniques essayées avant réception|Contrôle d’accès et sécurité incendie conformes'],
    ['École', 'Salles de classe, sanitaires et cour selon le programme|Matériaux robustes et entretien facile|Réception avant la rentrée scolaire'],
    ['Centre de santé', 'Revêtements lavables et réseaux d’eau fiables|Locaux techniques et gestion des déchets médicaux|Réception par les autorités sanitaires'],
    ['Lieu de culte', 'Acoustique et ventilation étudiées|Accessibilité pour tous|Finitions et décoration validées par le maître d’ouvrage'],
    ['Hangar ou entrepôt', 'Charpente métallique et bardage|Dallage industriel résistant aux charges|Portes et quais de chargement'],
    ['Boutique ou local commercial', 'Vitrine et enseigne selon le plan|Installations électriques renforcées|Remise des clés après nettoyage'],
    ['Mur de clôture', 'Fondations selon plan|Hauteur et alignement contrôlés|Portail fourni et posé'],
    ['Route et voirie', 'Terrassement et fond de forme réceptionnés|Couches de chaussée contrôlées|Drainage des eaux de pluie'],
    ['Pont ou dalot', 'Étude hydraulique remise|Fondations et appuis contrôlés|Essai de charge avant mise en service'],
    ['Adduction d’eau', 'Tracé et profondeur des tranchées|Essais de pression|Désinfection avant mise en service'],
    ['Réseau électrique', 'Normes de sécurité et de mise à la terre|Mesures remises par écrit|Consignation lors des raccordements'],
    ['Château d’eau et forage', 'Étude hydrogéologique remise|Essai de pompage|Qualité de l’eau analysée'],
    ['Hôtel ou résidence', 'Prestations selon le standing convenu|Insonorisation et sécurité incendie|Réception par niveaux'],
    ['Restaurant', 'Cuisine, extraction et évacuation des eaux|Revêtements adaptés|Conformité sanitaire'],
    ['Salle polyvalente', 'Charpente et couverture grande portée|Sorties de secours|Acoustique'],
    ['Marché couvert', 'Étals, sanitaires et évacuation des eaux|Structure résistante et ventilée|Éclairage et sécurité'],
    ['Logements sociaux', 'Prix maîtrisé et matériaux locaux|Répétition des typologies|Réception par lots de logements'],
    ['Lotissement (VRD)', 'Voirie, assainissement et réseaux|Bornage des parcelles|Réception par réseau'],
    ['Réhabilitation', 'Diagnostic préalable|Constat des existants avant travaux|Travaux imprévus chiffrés avant exécution'],
    ['Extension de bâtiment', 'Raccord avec l’existant|Protection de l’existant|Continuité des activités'],
    ['Aménagement intérieur', 'Plans d’aménagement validés|Échantillons approuvés|Protection des sols et façades']
  ];
  var CCA = {};
  CCO.forEach(function (r) { CCA['CCAP — ' + r[0] + ' (prix forfaitaire)'] = CC(r[0], true, r[1]); CCA['CCAP — ' + r[0] + ' (prix unitaires)'] = CC(r[0], false, r[1]); });
  D.ccap = D.ccap || {};
  Object.keys(CCA).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(D.ccap, k)) D.ccap[k] = CCA[k]; });

  /* ---------- LOTS CCTP SUPPLÉMENTAIRES ---------- */
  var LOT = function (a, b, c, d) { return '- ' + a + '\n- ' + b + '\n- ' + c + '\n- ' + d; };
  var LOTS = {
'Démolition et dépose': LOT('Démolition des ouvrages désignés aux plans, par phases, avec étaiement des parties conservées.', 'Déconnexion préalable des réseaux d’eau, d’électricité et de télécommunications.', 'Tri des matériaux, évacuation des gravats vers un site autorisé.', 'Protection des avoisinants et arrosage contre les poussières.'),
'Terrassement général': LOT('Décapage, déblais et remblais selon les cotes du plan de terrassement.', 'Réglage et compactage du fond de forme avant tout ouvrage.', 'Gestion des eaux de ruissellement pendant les travaux.', 'Évacuation des terres excédentaires vers un site autorisé.'),
'Assainissement et fosses': LOT('Réseau d’évacuation en pente régulière avec regards à chaque changement de direction.', 'Fosse septique et puisard dimensionnés selon le nombre d’usagers.', 'Essai d’étanchéité avant remblaiement.', 'Ventilation haute des réseaux et accès de visite.'),
'Alimentation en eau potable': LOT('Réseau enterré en matériau agréé pour l’eau potable, posé en tranchée avec lit de sable.', 'Vannes d’arrêt, compteurs et robinets de purge.', 'Essai de pression et désinfection avant mise en service.', 'Protection contre le gel, la chaleur et les chocs.'),
'Réseaux électriques extérieurs': LOT('Câbles enterrés sous fourreaux avec grillage avertisseur.', 'Coffrets de raccordement et protections différentielles.', 'Mise à la terre des masses et mesures remises par écrit.', 'Plans de récolement des tracés.'),
'Éclairage extérieur': LOT('Candélabres ou bornes conformes au plan d’éclairement.', 'Luminaires économes, protégés contre l’eau et la poussière.', 'Commande automatique ou par horloge.', 'Mesures d’éclairement à la réception.'),
'Voirie et chaussées': LOT('Fond de forme compacté, couche de fondation et couche de base selon l’étude.', 'Pentes transversales pour l’évacuation des eaux.', 'Bordures, caniveaux et signalisation.', 'Contrôles de compactage et d’épaisseur.'),
'Carrelage et sols durs': LOT('Support plan et propre ; calepinage validé avant la pose.', 'Colle ou mortier adapté, joints réguliers.', 'Plinthes assorties, seuils et barres de seuil.', 'Réserve de carreaux pour les réparations futures.'),
'Sols souples et parquets': LOT('Support sec, plan et propre ; ragréage si nécessaire.', 'Pose collée ou flottante selon le produit.', 'Plinthes, joints de dilatation et seuils.', 'Protection des sols jusqu’à la réception.'),
'Isolation thermique et acoustique': LOT('Isolants conformes aux fiches techniques approuvées.', 'Continuité de l’isolation, sans ponts thermiques.', 'Protection contre l’humidité.', 'Contrôle visuel avant fermeture des parois.'),
'Menuiserie bois': LOT('Bois sec, traité contre insectes et humidité.', 'Assemblages soignés, finition vernis ou peinture.', 'Quincaillerie de qualité, réglée à la pose.', 'Protection des ouvrages jusqu’à la réception.'),
'Menuiserie aluminium et vitrerie': LOT('Profilés laqués ou anodisés, étanchéité périphérique soignée.', 'Vitrages d’épaisseur adaptée, vitrage de sécurité si exigé.', 'Calage, fixations et joints de mastic.', 'Essais d’ouverture et d’étanchéité.'),
'Serrurerie': LOT('Garde-corps, escaliers métalliques et portails selon plans.', 'Protection antirouille et peinture de finition.', 'Soudures soignées et fixations résistantes.', 'Contrôle des hauteurs et des sécurités.'),
'Ascenseurs et monte-charges': LOT('Fourniture et installation selon la charge et le nombre d’arrêts.', 'Gaine, local machine et alimentation électrique conformes.', 'Essais de mise en service et attestation de conformité.', 'Contrat d’entretien proposé.'),
'Plomberie eaux pluviales': LOT('Gouttières, descentes et collecteurs dimensionnés pour les fortes pluies.', 'Raccordement à l’exutoire désigné.', 'Pentes régulières et fixations solides.', 'Essai d’écoulement.'),
'Courants faibles (téléphonie, réseau, télévision)': LOT('Fourreaux et câblage structuré jusqu’aux prises.', 'Baie de brassage ou coffret de communication.', 'Repérage des câbles et plan de récolement.', 'Essais de continuité.'),
'Vidéosurveillance et contrôle d’accès': LOT('Caméras et enregistreur selon le plan de couverture.', 'Contrôle d’accès par badge, code ou lecteur.', 'Alimentation secourue.', 'Formation de l’utilisateur.'),
'Énergie solaire': LOT('Panneaux orientés et inclinés selon l’étude.', 'Onduleur, régulateur et batteries dimensionnés.', 'Protections, mise à la terre et câblage résistant aux UV.', 'Essais de production et notice.'),
'Groupe électrogène': LOT('Groupe de puissance adaptée, sur dalle avec silencieux.', 'Commutation automatique ou manuelle.', 'Réservoir et évacuation des gaz.', 'Essai en charge à la réception.'),
'Citerne, château d’eau et forage': LOT('Ouvrage dimensionné pour le besoin journalier.', 'Fondations adaptées au poids à pleine charge.', 'Étanchéité, trop-plein et ventilation.', 'Nettoyage et désinfection avant mise en service.'),
'Clôture et portail': LOT('Mur ou grillage sur fondations selon plans.', 'Poteaux d’angle et intermédiaires scellés.', 'Portail motorisé ou manuel, serrure de qualité.', 'Peinture antirouille.'),
'Aménagements paysagers': LOT('Terre végétale, plantations et gazon selon le plan.', 'Arrosage et entretien pendant la garantie de reprise.', 'Allées, bordures et mobilier extérieur.', 'Plantes adaptées au climat local.'),
'Signalétique': LOT('Panneaux d’identification, d’orientation et de sécurité.', 'Matériaux durables et lisibles.', 'Fixations discrètes et solides.', 'Plan d’implantation validé.'),
'Nettoyage de fin de chantier': LOT('Évacuation des gravats, emballages et outils.', 'Nettoyage des sols, vitres, sanitaires et façades.', 'Remise en état des abords.', 'Réception du nettoyage avant remise des clés.'),
'Charpente métallique et bardage': LOT('Profilés conformes à l’étude, assemblages boulonnés ou soudés.', 'Protection anticorrosion et peinture.', 'Bardage et couverture étanches.', 'Contrôle des fixations et du contreventement.'),
'Cuisine et équipements': LOT('Plans de travail, éviers et meubles selon plans.', 'Alimentations en eau et électricité prévues avant pose.', 'Hotte, évacuation des fumées et gaz si prévu.', 'Essais des appareils.'),
'Agencement et mobilier fixe': LOT('Menuiseries intérieures et placards sur mesure.', 'Matériaux et finitions approuvés par échantillon.', 'Pose soignée, quincaillerie réglée.', 'Protection pendant les travaux.'),
'Piscine': LOT('Terrassement, structure béton et étanchéité du bassin.', 'Local technique, filtration et traitement de l’eau.', 'Plage, margelles et sécurité (barrière, alarme).', 'Essai d’étanchéité et mise en eau.'),
'Mur de soutènement': LOT('Étude de stabilité et fondations adaptées.', 'Drainage derrière le mur avec barbacanes.', 'Armatures et béton selon plans.', 'Remblaiement par couches compactées.'),
'Peinture extérieure et ravalement': LOT('Nettoyage et traitement des fissures et moisissures.', 'Peinture façade résistante aux intempéries et aux UV.', 'Échafaudage sécurisé.', 'Teinte approuvée sur échantillon.'),
'Drainage et gestion des eaux': LOT('Drains périphériques et exutoire de rejet.', 'Géotextile, gravier et regards de visite.', 'Pentes régulières, absence de stagnation.', 'Essai d’écoulement.'),
'Essais et laboratoire': LOT('Programme d’essais (béton, sol, aciers) défini avant travaux.', 'Laboratoire agréé et indépendant de l’entreprise.', 'Résultats remis à la maîtrise d’œuvre sous ___ jours.', 'Reprise aux frais de l’entreprise en cas de non-conformité.'),
'Pavage et voies piétonnes': LOT('Lit de pose compacté et bordures calées.', 'Pose régulière, joints sablés, pentes d’évacuation.', 'Contrôle des niveaux et des raccords.', 'Nettoyage final.')
  };
  D.lots = D.lots || {};
  Object.keys(LOTS).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(D.lots, k)) D.lots[k] = LOTS[k]; });
})(window);
