/* Excellencia Building V122 — Série A : comptes rendus, ordres de service, attestations, lettres.
 * Objectif : au moins 50 modèles par onglet « Pièces écrites ». N’écrase jamais un modèle existant (même nom = l’ancien est gardé).
 * Mise en forme : « # Titre », « ## Sous-titre », « - puce », « 1. numéro », « | a | b | ». Variables : {{projet}} {{lieu}} {{moa}} {{entreprise}} {{lot}} {{objet}} {{date}} {{date_effet}} {{no}} {{societe}} {{dg}} {{dg_role}} {{ville}} {{pays}}… */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA; if (!D) return;
  var FT = '\n\nFait à {{ville}}, le {{date}}';
  var SAL = 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.';
  function merge(t, src) { var dst = D.models[t] || (D.models[t] = {}); Object.keys(src).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(dst, k)) dst[k] = src[k]; }); }

  /* ---------- COMPTES RENDUS ---------- */
  var CRH = function (t, pts) {
    return '# COMPTE RENDU — ' + t.toUpperCase() + '\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}} · Lieu : {{lieu}}\n## Participants\n| Nom | Fonction / entreprise | Présent |\n| ____________ | ____________ | oui / non |\n| ____________ | ____________ | oui / non |\n## Ordre du jour\n' +
      pts.split('|').map(function (p, i) { return (i + 1) + '. ' + p; }).join('\n') +
      '\n## Décisions et actions\n| N° | Décision / action | Responsable | Échéance |\n| 1 | ____________ | ____________ | ____ |\n| 2 | ____________ | ____________ | ____ |\nProchaine réunion : ____________' + FT;
  };
  var CRL = [
    ['Réunion de lancement du chantier', 'Présentation des intervenants|Planning et jalons|Installations de chantier|Assurances et sécurité'],
    ['Réunion de coordination technique', 'Interfaces entre corps d’état|Réservations et fourreaux|Planning des interventions|Points bloquants'],
    ['Réunion de cadrage du projet avec le client', 'Besoins et attentes du client|Budget et délai souhaités|Contraintes du site|Prochaines étapes'],
    ['Réunion de validation des plans', 'Plans présentés|Remarques du client|Modifications demandées|Validation et signature'],
    ['Réunion de choix des matériaux et finitions', 'Échantillons présentés|Choix du client|Incidence sur le budget|Délais de commande'],
    ['Réunion de suivi du planning', 'Avancement réel et prévu|Retards constatés|Mesures de rattrapage|Jalons à venir'],
    ['Réunion de gestion des retards', 'Causes des retards|Responsabilités|Plan de rattrapage|Pénalités éventuelles'],
    ['Réunion d’analyse des écarts de budget', 'Dépenses réalisées|Écarts constatés et causes|Travaux supplémentaires|Corrections proposées'],
    ['Réunion de trésorerie du chantier', 'Encaissements prévus|Décaissements à venir|Paiements fournisseurs et sous-traitants|Besoins de financement'],
    ['Réunion de négociation avec un fournisseur', 'Besoins en matériaux|Prix et remises|Délais et conditions de livraison|Modalités de paiement'],
    ['Réunion de négociation avec un sous-traitant', 'Périmètre des travaux|Prix et planning|Garanties et assurances|Conditions de paiement'],
    ['Réunion de dépouillement des offres', 'Offres reçues|Analyse technique|Analyse financière|Entreprise retenue'],
    ['Réunion de présentation des études (avant-projet)', 'Esquisse et plans|Estimation du coût|Remarques du client|Suite de l’étude'],
    ['Réunion de visite de site avant offre', 'État des lieux du terrain|Accès et réseaux existants|Contraintes particulières|Informations à compléter'],
    ['Réunion de préparation de la réception', 'Liste des réserves|Essais et documents à remettre|Date de la réception|Nettoyage et remise des clés'],
    ['Réunion de levée des réserves', 'Réserves levées|Réserves restantes|Délais de reprise|Date du contrôle final'],
    ['Réunion de résolution d’un litige', 'Exposé du désaccord|Positions des parties|Solutions envisagées|Accord et engagements'],
    ['Réunion d’urgence après incident', 'Faits et circonstances|Mesures immédiates|Causes probables|Actions préventives'],
    ['Réunion qualité et non-conformités', 'Non-conformités ouvertes|Causes et corrections|Contrôles à renforcer|Clôture des fiches'],
    ['Réunion de préparation du gros œuvre', 'Méthodes d’exécution|Moyens humains et matériels|Approvisionnements|Contrôles et essais'],
    ['Réunion de préparation du second œuvre', 'Coordination des lots|Choix des matériaux|Planning par local|Protection des ouvrages'],
    ['Réunion de préparation des fondations', 'Résultats de sol|Implantation|Ferraillage et béton|Sécurité des fouilles'],
    ['Réunion de préparation d’un coulage de béton', 'Volume et classe de béton|Centrale et livraisons|Moyens de mise en œuvre|Cure et décoffrage'],
    ['Réunion d’organisation des approvisionnements', 'Besoins des prochaines semaines|Commandes en cours|Stockage sur site|Risques de rupture'],
    ['Réunion de gestion du personnel de chantier', 'Effectifs et compétences|Horaires et présence|Sécurité et équipements|Besoins de renfort'],
    ['Réunion avec les riverains et autorités locales', 'Présentation du projet|Nuisances et horaires|Accès et circulation|Engagements de l’entreprise'],
    ['Réunion avec le bureau de contrôle', 'Documents à contrôler|Observations du bureau|Essais demandés|Suites à donner'],
    ['Réunion avec le bureau d’études', 'Notes de calcul et plans|Points techniques ouverts|Modifications|Délais de réponse'],
    ['Réunion avec le géomètre / topographe', 'Implantation et bornage|Niveaux de référence|Écarts constatés|Plan de récolement'],
    ['Réunion de suivi environnemental', 'Gestion des déchets|Pollutions éventuelles|Bruit et poussières|Remise en état'],
    ['Réunion de passation de chantier', 'État d’avancement|Documents et accès remis|Points sensibles|Contacts et responsabilités'],
    ['Réunion de clôture d’un lot', 'Travaux achevés|Réserves|Décompte du lot|Documents remis'],
    ['Réunion de préparation du dossier des ouvrages exécutés', 'Liste des pièces|Plans de récolement|Notices et garanties|Délai de remise'],
    ['Réunion de suivi des paiements et situations', 'Situations déposées|Situations validées|Retards de paiement|Prochaines échéances'],
    ['Réunion du comité de pilotage', 'Avancement général|Décisions stratégiques|Risques et arbitrages|Communication'],
    ['Réunion interne de direction (point hebdomadaire)', 'Chiffres de la semaine|Chantiers en cours|Problèmes à traiter|Priorités de la semaine'],
    ['Briefing d’équipe de chantier', 'Programme du jour|Consignes de sécurité|Répartition des tâches|Questions de l’équipe'],
    ['Réunion de revue mensuelle de projet', 'Bilan du mois|Budget et délai|Qualité et sécurité|Objectifs du mois suivant'],
    ['Réunion de formation du personnel', 'Thème de la formation|Points abordés|Exercices pratiques|Évaluation'],
    ['Réunion de démarrage de la période de garantie', 'Contacts de garantie|Procédure de signalement|Entretien préconisé|Visite de contrôle prévue'],
    ['Réunion avec le bailleur de fonds ou la banque', 'Avancement physique|Situation financière|Décaissements demandés|Rapports à fournir'],
    ['Réunion de remise du projet au client', 'Visite des ouvrages|Remise des clés et documents|Explications d’utilisation|Signature du procès-verbal']
  ];
  var CR = {}; CRL.forEach(function (r) { CR[r[0]] = CRH(r[0], r[1]); });
  merge('cr', CR);

  /* ---------- ORDRES DE SERVICE ---------- */
  var OSX = function (nature, txt) {
    return '# ORDRE DE SERVICE N° {{no}}\nNature : ' + nature.toUpperCase() + '\nProjet : {{projet}} — Lot : {{lot}}\nÀ l’attention de : {{entreprise}}\n\n' + txt + '\n\nFait à {{ville}}, le {{date}}';
  };
  var OSL = [
    ['Implantation des ouvrages', 'L’entreprise procède à l’implantation des ouvrages d’après les plans approuvés et fait vérifier les axes et niveaux par la maîtrise d’œuvre avant tout terrassement.'],
    ['Commande de matériaux', 'L’entreprise commande sans délai les matériaux suivants : {{objet}}, afin de respecter le planning. Les fiches techniques sont soumises à approbation avant commande.'],
    ['Repli de chantier', 'L’entreprise démonte ses installations, évacue matériel et déchets et remet les lieux en état avant le {{date_effet}}.'],
    ['Nettoyage du chantier', 'L’entreprise procède au nettoyage complet du chantier et de ses abords avant le {{date_effet}}.'],
    ['Reprise de travaux non conformes', 'Les travaux suivants sont non conformes : {{objet}}. L’entreprise les reprend à ses frais avant le {{date_effet}}.'],
    ['Réalisation d’essais', 'L’entreprise fait réaliser les essais suivants : {{objet}}, par un laboratoire agréé, et remet les résultats avant le {{date_effet}}.'],
    ['Remplacement d’un matériau', 'Le matériau prévu est remplacé par : {{objet}}. L’entreprise présente un devis chiffré et l’incidence sur le délai avant exécution.'],
    ['Prolongation de délai', 'Le délai contractuel est prolongé de ___ jours calendaires pour le motif suivant : {{objet}}. Nouvelle date d’achèvement : {{date_effet}}.'],
    ['Réduction de délai', 'Le délai d’exécution est réduit de ___ jours. L’entreprise adapte ses moyens pour achever les travaux le {{date_effet}}.'],
    ['Travaux en régie', 'Les travaux suivants sont exécutés en régie : {{objet}}. L’entreprise remet chaque jour un état du personnel, du matériel et des matériaux employés.'],
    ['Travaux de nuit ou en horaires décalés', 'Les travaux suivants sont autorisés de nuit ou en horaires décalés : {{objet}}, à compter du {{date_effet}}, sous réserve du respect du voisinage.'],
    ['Travaux le week-end ou jours fériés', 'Les travaux sont autorisés le week-end et les jours fériés du ____________ au ____________, pour rattraper le retard constaté.'],
    ['Évacuation de déblais', 'L’entreprise évacue les déblais vers un site autorisé avant le {{date_effet}} et remet les bordereaux d’évacuation.'],
    ['Protection des ouvrages existants', 'L’entreprise protège les ouvrages suivants contre les dégradations : {{objet}}, par des moyens adaptés, avant la reprise des travaux.'],
    ['Sécurisation du chantier', 'L’entreprise met en place sans délai les mesures de sécurisation suivantes : {{objet}} (clôture, signalisation, gardiennage).'],
    ['Renforcement de l’effectif', 'L’entreprise renforce son effectif de ___ personnes à compter du {{date_effet}} afin de tenir le planning.'],
    ['Désignation d’un responsable de chantier', 'L’entreprise désigne par écrit un responsable de chantier présent en permanence, avec ses coordonnées, avant le {{date_effet}}.'],
    ['Transmission de plans', 'Les plans suivants sont transmis à l’entreprise : {{objet}}. Ils annulent et remplacent les indices précédents ; l’entreprise accuse réception.'],
    ['Présentation d’échantillons', 'L’entreprise présente à la maîtrise d’œuvre les échantillons suivants : {{objet}}, avant le {{date_effet}}.'],
    ['Levée des réserves', 'L’entreprise lève les réserves de la liste jointe avant le {{date_effet}} et en informe la maîtrise d’œuvre pour contrôle.'],
    ['Interdiction d’accès à une zone', 'L’accès à la zone suivante est interdit à compter du {{date_effet}} : {{objet}}. L’entreprise la matérialise et la surveille.'],
    ['Mise en conformité sécurité', 'L’entreprise corrige sous 48 heures les non-conformités de sécurité suivantes : {{objet}}. À défaut, les travaux concernés sont arrêtés.'],
    ['Arrêt des travaux pour motif de sécurité', 'Les travaux sont arrêtés immédiatement pour motif de sécurité : {{objet}}. La reprise est subordonnée à l’accord écrit de la maîtrise d’œuvre.'],
    ['Modification des plans', 'Les plans sont modifiés comme suit : {{objet}}. L’entreprise chiffre l’incidence sur le prix et le délai avant exécution.'],
    ['Travaux complémentaires urgents', 'Les travaux urgents suivants sont ordonnés : {{objet}}. Ils sont exécutés sans attendre l’avenant, sur justificatifs.'],
    ['Reprise des travaux après suspension', 'Les travaux suspendus reprennent le {{date_effet}}. Le délai d’exécution recommence à courir à cette date.'],
    ['Vérification des réseaux existants', 'Avant toute fouille, l’entreprise localise et vérifie les réseaux existants (eau, électricité, télécommunications) et en rend compte.'],
    ['Pose de panneau de chantier', 'L’entreprise installe le panneau de chantier réglementaire (nom du projet, maître d’ouvrage, intervenants, autorisation) avant le {{date_effet}}.'],
    ['Mise à disposition d’un laboratoire', 'L’entreprise met à disposition du laboratoire les accès, le personnel et les moyens nécessaires aux essais prévus au marché.'],
    ['Constat contradictoire', 'Un constat contradictoire est organisé le {{date_effet}} sur : {{objet}}. L’entreprise y assiste ou s’y fait représenter.'],
    ['Remise du dossier d’exécution', 'L’entreprise remet les plans d’exécution et notes de calcul du lot « {{lot}} » avant le {{date_effet}} pour visa.'],
    ['Préparation de la réception', 'L’entreprise prépare la réception : achèvement des travaux, nettoyage, essais et dossier des ouvrages exécutés, avant le {{date_effet}}.'],
    ['Maintien en l’état des ouvrages', 'L’entreprise maintient en l’état l’ouvrage suivant jusqu’au passage de la maîtrise d’œuvre : {{objet}}.'],
    ['Changement de sous-traitant', 'Le changement de sous-traitant est accordé / refusé pour : {{objet}}. L’entreprise reste responsable de l’exécution.'],
    ['Réalisation d’un ouvrage provisoire', 'L’entreprise réalise l’ouvrage provisoire suivant : {{objet}}, et le démonte à la fin des travaux.'],
    ['Contrôle des quantités', 'Un métré contradictoire des quantités exécutées est organisé le {{date_effet}} pour l’établissement de la situation de travaux.'],
    ['Remplacement de personnel', 'Pour des raisons de compétence ou de sécurité, l’entreprise remplace le personnel suivant : {{objet}}, avant le {{date_effet}}.'],
    ['Consignes pendant la saison des pluies', 'L’entreprise prend les mesures de protection contre les pluies (drainage, bâchage, stockage surélevé) et les maintient jusqu’à la fin de la période.']
  ];
  var OS = {}; OSL.forEach(function (r) { OS[r[0]] = OSX(r[0], r[1]); });
  merge('os', OS);

  /* ---------- ATTESTATIONS ---------- */
  var ATX = function (t, txt) {
    return '# ' + t.toUpperCase() + '\nJe soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que ' + txt + '\nLa présente attestation est délivrée pour servir et valoir ce que de droit.' + FT;
  };
  var ATL = [
    ['Attestation de travail', 'M./Mme ____________ est employé(e) au sein de notre entreprise en qualité de ____________ depuis le ____________ et y exerce toujours ses fonctions.'],
    ['Attestation de stage', 'M./Mme ____________ a effectué un stage au sein de notre entreprise du ____________ au ____________, dans le domaine ____________.'],
    ['Attestation de fin de contrat', 'M./Mme ____________ a travaillé dans notre entreprise du ____________ au ____________ en qualité de ____________ et est libre de tout engagement à notre égard.'],
    ['Attestation de présence sur chantier', 'M./Mme ____________ a été présent(e) sur le chantier {{projet}}, à {{lieu}}, du ____________ au ____________.'],
    ['Attestation de formation interne', 'M./Mme ____________ a suivi la formation interne « ____________ » le ____________, d’une durée de ____ heures.'],
    ['Attestation de paiement reçu', 'nous avons reçu de {{moa}} la somme de ____________ au titre de ____________ pour le projet {{projet}}.'],
    ['Attestation de réception de matériaux', 'les matériaux suivants ont été reçus sur le chantier {{projet}} le {{date_effet}} : ____________.'],
    ['Attestation de livraison', 'la livraison de ____________ a été effectuée à {{lieu}} le {{date_effet}}, conformément à la commande.'],
    ['Attestation de non-sous-traitance', 'les travaux du lot « {{lot}} » du projet {{projet}} sont exécutés directement par nos équipes, sans sous-traitance.'],
    ['Attestation de visite de site', 'notre représentant a visité le site du projet {{projet}} à {{lieu}} le {{date_effet}} et en connaît les conditions d’accès et d’exécution.'],
    ['Attestation de conformité des travaux', 'les travaux réalisés pour le projet {{projet}} sont conformes aux plans et au cahier des charges, sous réserve des observations éventuelles ci-après : ____________.'],
    ['Attestation d’exécution de travaux (référence)', 'notre entreprise a exécuté pour {{moa}} les travaux suivants : ____________, d’un montant de ____________, achevés le ____________, à la satisfaction du maître d’ouvrage.'],
    ['Attestation de bonne fin des travaux', 'les travaux du projet {{projet}} ont été menés à leur terme conformément au marché.'],
    ['Attestation sur l’honneur', 'les informations transmises dans le dossier du projet {{projet}} sont exactes et complètes.'],
    ['Attestation de mission de maîtrise d’œuvre', 'notre société assure la mission de maîtrise d’œuvre du projet {{projet}} pour le compte de {{moa}}, depuis le ____________.'],
    ['Attestation de suivi de chantier', 'notre société assure le suivi du chantier {{projet}} à {{lieu}} depuis le ____________ et y effectue des visites régulières.'],
    ['Attestation d’implantation', 'l’implantation des ouvrages du projet {{projet}} a été réalisée le {{date_effet}} conformément aux plans approuvés.'],
    ['Attestation de remise de plans', 'les plans suivants ont été remis à {{moa}} le {{date_effet}} : ____________.'],
    ['Attestation d’accord du maître d’ouvrage', 'le maître d’ouvrage {{moa}} a donné son accord sur ____________ pour le projet {{projet}}.'],
    ['Attestation de prise en charge', 'les frais de ____________ liés au projet {{projet}} sont pris en charge par {{societe}} jusqu’au ____________.'],
    ['Attestation d’emploi sur le chantier', 'M./Mme ____________ est employé(e) sur le chantier {{projet}} en qualité de ____________ et est déclaré(e) à ce titre.'],
    ['Attestation de rémunération', 'M./Mme ____________ perçoit une rémunération mensuelle de ____________ en qualité de ____________.'],
    ['Attestation d’expérience professionnelle', 'M./Mme ____________ a exercé les fonctions de ____________ au sein de notre entreprise du ____________ au ____________ et y a donné entière satisfaction.'],
    ['Attestation de compétence', 'M./Mme ____________ possède les compétences nécessaires pour exécuter les travaux de ____________ et a travaillé sur nos chantiers.'],
    ['Attestation de prise de service', 'M./Mme ____________ a pris ses fonctions de ____________ le {{date_effet}} sur le chantier {{projet}}.'],
    ['Attestation de congé', 'M./Mme ____________ est en congé du ____________ au ____________ avec l’accord de la direction.'],
    ['Attestation de mise à disposition de matériel', 'le matériel suivant a été mis à disposition de ____________ sur le chantier {{projet}} : ____________, du ____________ au ____________.'],
    ['Attestation de capacité de l’entreprise', 'notre entreprise dispose des moyens humains et matériels nécessaires pour exécuter les travaux de ____________.'],
    ['Attestation d’assurance des travaux', 'les travaux du projet {{projet}} sont couverts par une assurance souscrite auprès de ____________, police n° ____________, valable jusqu’au ____________.'],
    ['Attestation de levée d’opposition', 'nous n’avons aucune opposition à la réalisation de ____________ sur le site du projet {{projet}}.'],
    ['Attestation de propriété du chantier', 'le terrain situé à {{lieu}} appartient à {{moa}}, qui nous a donné mandat d’y réaliser le projet {{projet}}.'],
    ['Attestation de déclaration du personnel', 'le personnel travaillant sur le chantier {{projet}} est déclaré conformément à la législation de {{pays}}.'],
    ['Attestation de port des équipements de protection', 'les équipements de protection individuelle ont été remis à M./Mme ____________ le {{date_effet}} et leur port obligatoire lui a été rappelé.'],
    ['Attestation de remise de clés', 'les clés de ____________ ont été remises à ____________ le {{date_effet}}.'],
    ['Attestation de fin de formation', 'M./Mme ____________ a suivi avec assiduité la formation « ____________ » du ____________ au ____________.'],
    ['Attestation de réalisation d’essais', 'les essais suivants ont été réalisés le {{date_effet}} sur le projet {{projet}} : ____________, avec les résultats joints.'],
    ['Attestation de dépôt de dossier', 'le dossier de ____________ a été déposé auprès de ____________ le {{date_effet}}.'],
    ['Attestation de conformité aux plans', 'l’ouvrage ____________ a été exécuté conformément aux plans d’exécution indice ____ du projet {{projet}}.'],
    ['Attestation de garantie de parfait achèvement', 'les travaux du lot « {{lot}} » sont garantis pendant ___ mois à compter du ____________ contre tout désordre signalé.'],
    ['Attestation de recommandation', 'M./Mme ____________ a travaillé avec nous du ____________ au ____________ ; nous le/la recommandons pour son sérieux et sa compétence.'],
    ['Attestation de non-redevance', 'M./Mme ____________ ne nous doit aucune somme au titre du projet {{projet}} à la date de ce jour.'],
    ['Attestation de réception provisoire des travaux', 'les travaux du lot « {{lot}} » du projet {{projet}} ont été réceptionnés à titre provisoire le {{date_effet}}.'],
    ['Attestation de domiciliation de chantier', 'le chantier du projet {{projet}} est situé à {{lieu}} et la société {{societe}} y est domiciliée pour la durée des travaux.'],
    ['Attestation de mission d’étude', 'notre société a réalisé pour {{moa}} l’étude de ____________ du projet {{projet}}, remise le {{date_effet}}.'],
    ['Attestation de remise d’équipements de protection collectifs', 'les équipements de protection collective (garde-corps, filets, signalisation) ont été installés sur le chantier {{projet}} le {{date_effet}}.'],
    ['Attestation de mise à jour du planning', 'le planning d’exécution du projet {{projet}} a été mis à jour le {{date_effet}} et transmis à {{moa}}.'],
    ['Attestation de participation à une réunion', 'M./Mme ____________ a participé à la réunion « ____________ » du projet {{projet}} le {{date_effet}}.'],
    ['Attestation d’aptitude au travail en hauteur', 'M./Mme ____________ a été formé(e) aux règles de sécurité du travail en hauteur et reconnu(e) apte à ces travaux sur nos chantiers.']
  ];
  var AT = {}; ATL.forEach(function (r) { AT[r[0]] = ATX(r[0], r[1]); });
  merge('attest', AT);

  /* ---------- LETTRES ---------- */
  var LTX = function (obj, corps) { return 'Objet : ' + obj + '\n\nMadame, Monsieur,\n\n' + corps + '\n\n' + SAL + '\n\n{{societe}}'; };
  var LTL = [
    ['Demande de devis', 'Demande de devis — {{objet}}', 'Pour le projet {{projet}}, nous vous prions de nous adresser votre meilleur devis détaillé pour : {{objet}}, avec vos délais et conditions de paiement, avant le {{date_effet}}.'],
    ['Bon de commande de matériaux', 'Commande de matériaux — {{projet}}', 'Suite à votre offre, nous vous confirmons la commande de : {{objet}}, à livrer à {{lieu}} avant le {{date_effet}}. Merci de nous retourner un accusé de réception.'],
    ['Relance de paiement (première relance)', 'Relance de paiement — facture n° ____', 'Sauf erreur de notre part, la facture n° ____ d’un montant de ____________, échue le ____________, n’a pas été réglée. Nous vous prions d’y procéder rapidement.'],
    ['Réclamation à un fournisseur', 'Réclamation — livraison non conforme', 'La livraison du {{date_effet}} présente les anomalies suivantes : {{objet}}. Nous vous demandons de la remplacer ou de la corriger dans un délai de ___ jours.'],
    ['Demande d’autorisation de travaux', 'Demande d’autorisation de travaux — {{lieu}}', 'Nous sollicitons l’autorisation d’exécuter les travaux suivants : {{objet}}, à {{lieu}}, à compter du {{date_effet}}. Les pièces justificatives sont jointes.'],
    ['Demande d’accès au site', 'Demande d’accès au site — {{projet}}', 'Nous vous demandons l’autorisation d’accéder au site {{lieu}} le {{date_effet}} avec : ____________ (personnel, véhicules, matériel).'],
    ['Information aux riverains', 'Information aux riverains — travaux à {{lieu}}', 'Nous vous informons que des travaux auront lieu à {{lieu}} à partir du {{date_effet}}, de ____ h à ____ h. Nous mettons tout en œuvre pour limiter les nuisances.'],
    ['Annonce d’une visite de contrôle', 'Visite de contrôle — {{projet}}', 'Nous vous informons qu’une visite de contrôle du chantier aura lieu le {{date_effet}}. Merci de prévoir la présence de votre responsable.'],
    ['Demande de documents administratifs', 'Demande de documents — {{projet}}', 'Pour constituer le dossier du projet {{projet}}, nous vous prions de nous transmettre : ____________, avant le {{date_effet}}.'],
    ['Demande d’attestation d’assurance', 'Demande d’attestation d’assurance', 'Avant le démarrage des travaux, nous vous demandons de nous remettre vos attestations d’assurance à jour (responsabilité civile, accidents du travail).'],
    ['Réponse à un appel d’offres', 'Offre pour {{objet}}', 'En réponse à votre consultation, nous avons le plaisir de vous remettre notre offre pour {{objet}}, comprenant notre proposition technique et financière, valable ___ jours.'],
    ['Offre de service', 'Proposition de services', '{{societe}} se tient à votre disposition pour réaliser vos projets de ____________. Vous trouverez ci-joint notre présentation et nos références.'],
    ['Remerciement au client', 'Remerciements — projet {{projet}}', 'Nous vous remercions de la confiance que vous nous avez accordée pour le projet {{projet}} et restons à votre disposition pour toute question.'],
    ['Demande de rendez-vous', 'Demande de rendez-vous', 'Nous souhaiterions vous rencontrer au sujet de {{objet}}. Seriez-vous disponible le ____________ ou à toute autre date qui vous conviendrait ?'],
    ['Convocation à une réunion de chantier', 'Convocation — réunion de chantier du {{date_effet}}', 'Vous êtes convoqué(e) à la réunion de chantier du projet {{projet}} le {{date_effet}} à ____ h, à {{lieu}}. Ordre du jour : ____________.'],
    ['Accusé de réception de plans', 'Accusé de réception — plans', 'Nous accusons réception des plans suivants : {{objet}}, indice ____, reçus le {{date_effet}}.'],
    ['Notification de non-conformité', 'Non-conformité constatée — {{objet}}', 'Nous avons constaté la non-conformité suivante : {{objet}}. Nous vous demandons de la corriger avant le {{date_effet}} et de nous en informer.'],
    ['Demande d’acompte', 'Demande d’acompte — {{projet}}', 'Conformément au marché, nous vous prions de bien vouloir régler un acompte de ____________ correspondant à l’avancement des travaux au {{date_effet}}.'],
    ['Notification de retard de livraison', 'Retard de livraison — commande du ____________', 'La livraison de {{objet}}, prévue le ____________, n’a pas été effectuée. Nous vous demandons de nous confirmer une date ferme sous 48 heures.'],
    ['Annulation de commande', 'Annulation de commande', 'Nous vous informons que nous annulons notre commande du ____________ relative à {{objet}}, pour le motif suivant : ____________.'],
    ['Demande de renseignements techniques', 'Demande de renseignements techniques — {{objet}}', 'Dans le cadre du projet {{projet}}, nous vous prions de nous communiquer les informations techniques suivantes : {{objet}}.'],
    ['Lettre de recommandation', 'Lettre de recommandation', 'Nous recommandons M./Mme ____________, qui a travaillé avec nous en qualité de ____________ du ____________ au ____________, pour son sérieux et ses compétences.'],
    ['Candidature spontanée', 'Candidature — poste de ____________', 'Intéressé(e) par votre entreprise, je vous propose ma candidature au poste de ____________. Mon CV est joint ; je me tiens à votre disposition pour un entretien.'],
    ['Lettre d’excuses pour retard', 'Excuses — retard sur {{objet}}', 'Nous vous prions d’excuser le retard constaté sur {{objet}}, dû à ____________. Nous mettons en œuvre les mesures suivantes pour le rattraper : ____________.'],
    ['Rappel des règles de sécurité', 'Rappel des règles de sécurité — {{projet}}', 'Nous rappelons à l’ensemble des intervenants le port obligatoire des équipements de protection et le respect du règlement intérieur du chantier.'],
    ['Demande de prolongation d’autorisation', 'Demande de prolongation — autorisation n° ____', 'Notre autorisation n° ____ arrivant à échéance le ____________, nous sollicitons sa prolongation jusqu’au ____________ pour achever les travaux.'],
    ['Confirmation de rendez-vous de chantier', 'Confirmation de rendez-vous — {{lieu}}', 'Nous confirmons notre rendez-vous sur le chantier {{projet}} le {{date_effet}} à ____ h. Merci de vous munir de vos équipements de protection.'],
    ['Transmission de documents', 'Transmission de documents — {{projet}}', 'Veuillez trouver ci-joint les documents suivants : {{objet}}. Nous vous remercions de nous en accuser réception.'],
    ['Résiliation amiable de contrat', 'Résiliation amiable — {{objet}}', 'Nous vous proposons de mettre fin d’un commun accord au contrat relatif à {{objet}} à compter du {{date_effet}}, selon les modalités suivantes : ____________.']
  ];
  var LT = {}; LTL.forEach(function (r) { LT[r[0]] = LTX(r[1], r[2]); });
  merge('lettre', LT);
})(window);
