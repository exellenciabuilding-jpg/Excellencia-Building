/* Excellencia Building V127 — Modèles de « Pièces écrites » remplis d'EXEMPLES CONCRETS.
 * Les modèles qui n'étaient que des trames vides (lignes « ____ ») reçoivent des valeurs d'exemple réalistes (dates, noms, quantités,
 * constats, décisions…) pour montrer comment les remplir. Les données du projet restent des variables {{projet}}, {{lieu}}, {{moa}}…
 * remplacées automatiquement ; les exemples (noms, chiffres, dates) sont à REMPLACER par les vôtres.
 * Chargé APRÈS tous les fichiers de modèles et AVANT exb-v81-pieces.js. Ne modifie que les modèles qui contiennent encore des blancs ;
 * les modèles déjà rédigés et les « Page blanche » restent tels quels. Désactivation : retirer la balise <script> de index.html. */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA; if (!D || !D.models || D.__v127) return; D.__v127 = 1;
  var n = 0, cnt = {};
  function pick(a, key) { key = key || 'g'; cnt[key] = cnt[key] || 0; return a[cnt[key]++ % a.length]; }
  /* tableaux d'essais : valeur selon la ligne (1re colonne) */
  /* lignes d'essais ou de contrôle : valeur « constat » selon le libellé de la ligne */
  var ROWC = [[/ouvrage|élément|zone|local/i, 'Toiture-terrasse du R+1 (120 m²)'], [/méthode|procédure/i, 'Mise en eau de 5 cm pendant 48 h'], [/durée/i, '48 heures'], [/résultat/i, 'Aucune fuite constatée'],
    [/pression/i, '6 bars maintenus 2 h'], [/fuite/i, 'Aucune fuite'], [/débit/i, '0,25 L/s au point le plus éloigné'], [/mise en eau|mise en service/i, 'Réalisée sans incident'], [/tension|isolement/i, '230 V ; isolement supérieur à 500 kΩ'],
    [/dimension|cote|niveau/i, 'Conformes aux plans (écart inférieur à 1 cm)'], [/propreté|état/i, 'Propre et dégagé'], [/documents?|plans?/i, 'Complets et à jour (indice B)'], [/sécurité|protection/i, 'Garde-corps et balisage en place'], [/stabilité|calage|ancrage/i, 'Stables et correctement calés']];
  var ROWV = [[/affaissement/i, ['9 cm', '10 ± 2 cm']], [/éprouvettes/i, ['6', '6']], [/7 jours/i, ['21 MPa', '≥ 18 MPa']], [/28 jours/i, ['31 MPa', '≥ 25 MPa']], [/densit|compact/i, ['97 %', '≥ 95 %']], [/température/i, ['27 °C', '≤ 32 °C']]];

  /* ---------- colonnes de tableau : [expression sur l'en-tête, valeurs d'exemple tournantes] ---------- */
  var COL = [
    [/^motif$|^objet de la visite/i, ['Réunion de chantier', 'Livraison de ciment', 'Visite de contrôle']],
    [/^livrable$/i, ['Plans d’esquisse', 'Plans d’avant-projet', 'Dossier de consultation', 'Plans d’exécution']],
    [/^taux/i, ['8', '12', '5']], [/^signature$/i, ['Signé', 'Signé', 'Signé']],
    [/^présent$|présent \/ excusé|^oui \/ non$/i, ['oui', 'oui', 'excusé']],
    [/^poste$|poste \/ ouvrage|^partie$|^espace$|^repère$|^position$|^usage$|^description$|^sols?$|^peinture$|^menuiseries$|^niveau$/i, ['Gros œuvre', 'Dalle R+1', 'Maçonnerie', 'Séjour', 'Façade nord']],
    [/^entreprise|^société|^organisme$|laboratoire|transporteur|^lot \/ société|^lot concerné|^interface/i, ['Kivu BTP', 'Électricité Kivu', 'Plomberie Goma', 'Great Lakes Bâtiment']],
    [/^point( contrôlé)?$|^sujet$|^problème$|^article concerné|^risque|^danger$|^modification$|^intervention$|^prescription$|^principe retenu|^option$|^note technique/i, ['Épaisseur de la dalle', 'Choix du carrelage', 'Protection des rives', 'Étanchéité de la toiture']],
    [/longueur|surface|largeur cumulée|espacement|^diamètre|enrobage|^base$|^cote|^tolérance|^mesuré/i, ['12,50', '45', '0,20', '3,00']],
    [/entretien|précautions|pièces manquantes|justification|avantages|inconvénients|incidence|solution retenue|suite donnée|mode de traitement|^légende|^suivi$|^escaliers|propriété|blessure|^classement|^projet$/i, ['Nettoyage hebdomadaire', 'Attestation d’assurance à fournir', 'Gain de 3 jours sur le planning', 'Aucune', 'Pris en compte']],
    [/^prix|^taux|^budget|^dépensé|reste à dépenser|^cumul|prix estimé|^prévu$|^réalisé$|^stock|^entrées|^sorties|^exemplaires|^absences|retard \(jours\)|^durée$/i, ['1 200', '850', '45', '3']],
    [/vérifié le|retour prévu|écrasement prévu|^arrivée|^départ|heure d.arrivée|heure de départ/i, ['12/11/2026', '14/11/2026', '19/11/2026']],
    [/^qualité \(a\/b\/c\)/i, ['A', 'B', 'A']], [/^photo n°/i, ['12', '13', '14']], [/type de déchet/i, ['Gravats', 'Bois de coffrage', 'Ferraille']],
    [/^utilisateur|^auteur|présenté par|contrôlée par|vérifié par|à reprendre par|^approbation|^le maître d’ouvrage|^le maître d’œuvre|^matériel \/ (engin|outil)|^matériau \/ échantillon|^essai$|prochaine visite|^pour \(/i, ['J.-P. Mbuyi', 'A. Ndaye', 'T. Kasongo']],
    [/^état à la sortie/i, ['Bon état']], [/^recouvrements|^diamètres? \/ nombre|^diamètres/i, ['HA 12 × 8', 'HA 10 × 12', 'HA 16 × 4']],
    [/^nature/i, ['Fissure horizontale', 'Infiltration d’eau', 'Flèche excessive', 'Éclatement du béton']], [/gravité/i, ['moyenne', 'faible', 'grave']],
    [/relevé par|^relevé par/i, ['J.-P. Mbuyi', 'A. Ndaye']],
    [/exigence|attendu|prescrit|seuil|^norme/i, ['Selon CCTP', 'Selon plans', 'Selon DTU']],
    [/compteur d.eau/i, ['1 245 m³', '1 262 m³']], [/compteur [ée]lectri/i, ['38 420 kWh', '38 910 kWh']],
    [/^n°$|^n° (plan|d)|^bon n°|^ref$/i, ['001', '002', '003']],
    [/éprouvette/i, ['E1', 'E2', 'E3']],
    [/^nom|vérificateur|^agent|^intervenant|^personne|^équipier|^ouvrier/i, ['J.-P. Mbuyi', 'A. Ndaye', 'T. Kasongo', 'R. Banza']],
    [/fonction.*entreprise|entreprise.*fonction/i, ['Conducteur de travaux — Excellencia Building', 'Chef de chantier — Entreprise Kivu BTP', 'Architecte — Cabinet Horizon', 'Ingénieur structure — Bureau Structura']],
    [/^fonction|^poste de travail|^qualification/i, ['Chef de chantier', 'Maçon', 'Ferrailleur', 'Électricien']],
    [/^téléphone|^tél|^contact/i, ['+243 990 000 001', '+243 810 000 002', '+243 970 000 003']],
    [/décision|action(?! corr)|^tâche|^travaux prévus|^livrable/i, ['Commander les aciers HA 12 et HA 16 avant jeudi', 'Reprendre l’enduit du pignon est', 'Transmettre les plans d’exécution indice B', 'Installer la protection collective en rive de dalle']],
    [/^responsable|responsabilité|^assuré par|^équipe|^pilote|^émetteur/i, ['Conducteur de travaux', 'Entreprise de gros œuvre', 'Bureau de contrôle', 'Chef de chantier']],
    [/échéance|à corriger avant|^fin prévue|^remise le|^corrigée le|^levée|^délai|^date limite|^début prévu|^date prévue/i, ['21/11/2026', '28/11/2026', '05/12/2026', '12/12/2026']],
    [/^date|^début|^fin( réelle.*)?$|^jour$|date de coulage|^le$/i, ['10/11/2026', '11/11/2026', '12/11/2026', '13/11/2026']],
    [/référence|plan|cctp/i, ['Plan A-03 ind. B', 'CCTP art. 4.2', 'Plan S-12 ind. A', 'DTU 21 § 3.1']],
    [/constat|défaut|désordre|anomalie|écart relevé|non-conformité|point relevé/i, ['Fissure de retrait de 0,3 mm sur le voile axe C', 'Épaisseur d’enrobage insuffisante sur 2 poutres', 'Garde-corps provisoire absent en rive de dalle', 'Flèche visible sur le coffrage de la poutre P4']],
    [/observation|remarque|commentaire|motif|^avis/i, ['Conforme aux plans', 'RAS', 'Vérifié en présence du bureau de contrôle', 'Conforme', 'À reprendre avant le 21/11/2026']],
    [/désignation|^élément|^ouvrage|local|emplacement|localisation|^zone|^article$|^matériau$|^produit/i, ['Dalle R+1 — travée A-B', 'Poteau P4 — axe C', 'Mur de façade nord', 'Fondation semelle S3']],
    [/^matériel$|^engin|^équipement/i, ['Bétonnière 350 L', 'Camion benne 10 t', 'Vibreur à béton', 'Échafaudage 12 m']],
    [/fournisseur/i, ['Ciments du Kivu', 'Quincaillerie Centrale', 'Aciers Great Lakes', 'Carrière Nyiragongo']],
    [/quantité (commandée|estimée|réalisée)|^quantité|^nombre|^effectif|^qté/i, ['25', '120', '8', '40']],
    [/^unité$|^u$/i, ['m³', 'kg', 'm²', 'u']],
    [/prix unitaire|^pu\b/i, ['85', '1,20', '12', '240']],
    [/montant|^total$|budget initial|^engagé|^payé|reste à engager|^coût/i, ['12 500', '3 400', '8 900', '1 250']],
    [/prévu \(%\)/i, ['40', '65', '90']], [/réalisé \(%\)|avancement/i, ['35', '60', '85']],
    [/écart \(jours\)|^écart$/i, ['+2', '0', '-1']],
    [/^indice$|^ind\.?$/i, ['A', 'B', 'C']], [/^échelle$/i, ['1/100', '1/50', '1/20']],
    [/^état$|^statut$|situation/i, ['En cours', 'Terminé', 'À reprendre', 'Validé']],
    [/^visa|validation|signature|vérifiée par/i, ['Visé le 10/11/2026', 'Bon pour exécution', 'Signé']],
    [/^réserve$|^point à lever/i, ['Fissures du carrelage de la cuisine', 'Porte du WC jouant', 'Peinture écaillée au plafond du séjour']],
    [/^météo/i, ['Ensoleillé, 27 °C', 'Averse matinale, 22 °C', 'Nuageux, 25 °C']],
    [/travaux exécutés|travaux réalisés|matériaux et mise en œuvre/i, ['Coulage de la dalle R+1 (18 m³)', 'Ferraillage des poteaux du R+2', 'Maçonnerie du pignon est']],
    [/visiteurs|instructions/i, ['Visite du bureau de contrôle à 10 h', 'Consigne : arrêt du coulage si pluie', 'Visite du maître d’ouvrage']],
    [/^(lun|mar|mer|jeu|ven|sam)$/i, ['8 h', '8 h', '8 h', '4 h']], [/total \(h\)|^heures/i, ['44', '40', '36']],
    [/affaissement|slump/i, ['9', '10', '8']], [/écrasement 7/i, ['21', '23', '22']], [/écrasement 28/i, ['31', '33', '30']],
    [/^valeur|^mesure|^résultat|^relevé/i, ['12,4', '12,6', '12,5']], [/^dimension/i, ['0,20 × 0,40 m', '3,00 × 2,50 m', '0,15 × 0,15 m']],
    [/dépendance|prédécesseur/i, ['Terrassement', 'Fondations', 'Gros œuvre R+1']], [/^fréquence/i, ['Quotidienne', 'Hebdomadaire', 'À chaque coulage']],
    [/note \(/i, ['4', '5', '3']], [/^destinataire|^diffusion/i, ['Maître d’ouvrage', 'Bureau de contrôle', 'Architecte']],
    [/^lot$/i, ['Gros œuvre', 'Électricité', 'Plomberie', 'Peinture']], [/^document$|^pièce$|^titre$/i, ['Plan de coffrage R+1', 'Note de calcul fondations', 'Fiche technique ciment CEM II 42,5']],
    [/^évacuation|^destination/i, ['Décharge communale', 'Remblai sur site', 'Recyclage']], [/^fonctionnement|^conforme$|^présent$/i, ['oui', 'oui', 'non']],
    [/^défaut relevé|corriger/i, ['Reprise de l’arase', 'Ragréage du seuil']], [/^contrôle$/i, ['Visuel et au niveau laser', 'Au mètre et au fil à plomb']]
  ];


  /* règles de phrase (testées en premier) : [expression sur le début de la ligne jusqu'au blanc, valeur d'exemple] */
  var TXT0 = [
    [/date de démarrage\s*:\s*$/i, ['03/11/2026']], [/(date de )?fin contractuelle\s*:\s*$/i, ['03/09/2027']], [/(date de )?clôture\s*:\s*$/i, ['18/12/2026']],
    [/(bénéficiaire|observateur|réclamant)\s*:\s*$/i, ['J.-P. Mbuyi']], [/dérives identifiées\s*:\s*$/i, ['hausse de l’acier de 8 %, compensée par une économie sur les engins']],
    [/(accéder au site|avec)[^:]*:\s*$/i, ['deux ingénieurs du bureau de contrôle et un géomètre']], [/qualité d.exécution\s*:\s*$/i, ['bonne ; deux reprises mineures de l’enduit']], [/hygiène et sécurité\s*:\s*$/i, ['équipements portés, base-vie propre, aucun accident']],
    [/matériaux suivants[^:]*:\s*$/i, ['120 sacs de ciment CEM II 42,5 et 1,5 t d’acier HA 12']], [/plans suivants[^:]*:\s*$/i, ['plans de coffrage et de ferraillage R+1 (indice B)']],
    [/dates?\b[^:\n]{0,45}:\s*$/i, ['21/11/2026', '28/11/2026', '05/12/2026']], [/date[^:\n]{0,40}(achèvement|réception|fin)[^:\n]{0,20}:\s*$/i, ['18/12/2026']],
    [/valables? du\s*$/i, ['01/01/2026']], [/valables? du [^ ]+ au\s*$/i, ['31/12/2026']], [/validité\s*:\s*du\s*$/i, ['12/11/2026']], [/validité\s*:\s*du [^ ]+ au\s*$/i, ['30/11/2026']],
    [/^du\s*$/i, ['03/11/2026']], [/^du [^ ]+ au\s*$/i, ['30/04/2027']], [/hauteur\s*$/i, ['2,20']],
    [/provenance[^:]*:\s*$/i, ['centrale Ciments du Kivu']], [/bons de livraison\s*:\s*$/i, ['n° 214 à 216']], [/ouvrages touchés[^:]*:\s*$/i, ['mur de clôture nord (6 m) et bâche de la dalle du R+1']],
    [/durée d.arrêt\s*:\s*$/i, ['2']], [/début\s*:\s*$/i, ['04/11/2026']], [/ — fin\s*:\s*$/i, ['06/11/2026']],
    [/^et\s*$/i, ['Entreprise Kivu BTP, société établie à Goma']], [/jusqu.à\s*$/i, ['31/03/2027']],
    [/implantation validée\s*\/\s*à reprendre\s*:\s*$/i, ['validée']], [/classeur n°\s*:?\s*$/i, ['07']],
    [/parcelle n°\s*:?\s*$/i, ['4572']], [/autorisation de bâtir n°\s*:?\s*$/i, ['AB-2026-0312']],
    [/_{3,}\/_{3,}\/$|\d{2}\/\d{2}\/\d{4}\/$/, null],
    [/règlement de\s*$/i, ['la facture n° 2026-087']], [/\(montant\s*:\s*$/i, ['12 500 USD']], [/échéance du\s*$/i, ['30/10/2026']],
    [/agrément de l.entreprise\s*$/i, ['Kivu Électricité']], [/accord pour\s*$/i, ['15']], [/refus motivé\s*:\s*$/i, ['le retard est imputable à l’entreprise']],
    [/modifié du fait de\s*$/i, ['la pluie et du retard de livraison du ciment']], [/date prévisionnelle de fin des travaux est le\s*$/i, ['19/12/2026']],
    [/sur instruction de\s*$/i, ['M. T. Kasongo, bureau de contrôle']], [/sur instruction de [^:]+:\s*$/i, ['pose d’un second chaînage sur le mur de clôture']],
    [/votre courrier du\s*$/i, ['03/11/2026']], [/éléments suivants\s*:\s*$/i, ['les travaux ont été exécutés conformément au marché ; le retard est lié aux pluies']],
    [/actions suivantes avant le\s*$/i, ['12/11/2026']], [/actions suivantes avant le [^:]+:\s*$/i, ['renfort de l’équipe et travail le samedi']],
    [/nous transmettre\s*:\s*$/i, ['l’attestation d’assurance, le registre de commerce et l’attestation fiscale']],
    [/projets de\s*$/i, ['construction de logements et de bâtiments publics']],
    [/dû à\s*$/i, ['la pluie et au retard de livraison du ciment']], [/pour le rattraper\s*:\s*$/i, ['renfort de 3 ouvriers et travail le samedi jusqu’au 05/12/2026']],
    [/modalités suivantes\s*:\s*$/i, ['remise du chantier le 30/11/2026, règlement du solde sous 15 jours']],
    [/responsable de chantier\s*:\s*$/i, ['M. R. Banza, chef de chantier']], [/réunions hebdomadaires\s*:\s*$/i, ['mardi à 9 h sur le chantier']],
    [/installations de chantier[^:]*:\s*$/i, ['base de vie près de l’entrée, stockage du ciment sur palettes à l’abri']],
    [/programme d.exécution est modifié comme suit\s*:\s*$/i, ['le coulage de la dalle R+2 est avancé au 28/11/2026']],
    [/débris stockés à\s*$/i, ['l’angle nord du terrain']], [/en état de propreté[^$]*$/i, null],
    [/suite à\s*$/i, ['l’accident du 11/11/2026']], [/met en œuvre immédiatement\s*:\s*$/i, ['le balisage des zones dangereuses et la vérification quotidienne des échafaudages']],
    [/pour le motif suivant\s*:\s*$/i, ['absences répétées et travail non conforme']], [/de remplacer\s*$/i, ['le chef d’équipe maçonnerie']],
    [/essais suivants par un laboratoire agréé\s*:\s*$/i, ['écrasement de 6 éprouvettes de béton et analyse granulométrique du sable']],
    [/plans indice\s*$/i, ['B']], [/ouvrages déjà exécutés seront vérifiés\s*:\s*$/i, ['fondations et poteaux du R+1, contrôle sous 8 jours']],
    [/accès et clôture\s*:\s*$/i, ['accès par l’avenue de la Paix ; clôture en tôles de 2 m posée']], [/branchements existants[^:]*:\s*$/i, ['compteur d’eau en place ; branchement électrique provisoire à demander']],
    [/arrêt constaté le\s*:\s*$/i, ['04/11/2026']], [/reprise le\s*:\s*$/i, ['07/11/2026']], [/durée\s*:\s*$/i, ['3']],
    [/ouvrages protégés[^:]*:\s*$/i, ['dalle bâchée, aciers protégés, matériaux couverts']],
    [/plans de récolement[^:]*:\s*$/i, ['remis le 12/11/2026 (12 plans, 5 notices, 4 certificats)']],
    [/sous-traitant\s*:\s*$/i, ['Électricité Kivu']], [/réseaux acceptés[^:]*:\s*$/i, ['réseau d’eau accepté ; réseau électrique à reprendre (prises du R+1)']],
    [/panneau de chantier[^:]*:\s*$/i, ['posés le 10/11/2026']], [/assurances et autorisations[^:]*:\s*$/i, ['attestations d’assurance et autorisation de bâtir remises']],
    [/plan d.hygiène et de sécurité remis\s*:\s*$/i, ['oui, remis le 10/11/2026']], [/superficie\s*:\s*$/i, ['600 m²']], [/accès\s*:\s*$/i, ['piste de 4 m depuis l’avenue de la Paix']],
    [/servitudes ou réseaux[^:]*:\s*$/i, ['canalisation d’eau à 4 m de la limite est']], [/local livré\s*:\s*$/i, ['villa R+1, lot 7']], [/acquéreur\s*\/\s*occupant\s*:\s*$/i, ['M. Jean-Pierre Mbuyi']],
    [/clés remises\s*:\s*$/i, ['3 jeux']], [/compteurs relevés\s*:\s*$/i, ['eau 0 012 m³ ; électricité 00 148 kWh']], [/défauts constatés\s*:\s*$/i, ['peinture écaillée au plafond du séjour']],
    [/fuites constatées à\s*:\s*$/i, ['aucune']], [/essai de pression\s*:\s*$/i, ['6']], [/chute de pression\s*:\s*$/i, ['0,1 bar']],
    [/écoulement correct\s*\/\s*défauts\s*:\s*$/i, ['écoulement correct']], [/accepté\s*\/\s*à reprendre\s*:\s*$/i, ['accepté après reprise du seuil de la porte']],
    [/fournisseur\s*:\s*$/i, ['Ciments du Kivu']], [/bon de livraison n°\s*$/i, ['214']], [/constaté que\s*$/i, ['M. A. Ndaye, maçon']], [/nom, fonction\)[^$]*depuis le\s*$/i, ['08/11/2026']],
    [/prend possession de\s*:\s*$/i, ['la villa du R+1 (séjour, 4 chambres)']],
    [/né\(e\) le\s*$/i, ['12/05/1985']], [/né\(e\) le [^,]*, à\s*$/i, ['Goma']], [/depuis le\s*$/i, ['03/03/2019']], [/en qualité de\s*$/i, ['conducteur de travaux']],
    [/dans le domaine\s*:\s*$/i, ['génie civil']], [/activités suivantes\s*:\s*$/i, ['suivi de chantier, métrés, rédaction de rapports et relevés topographiques']],
    [/observations éventuelles ci-après\s*:\s*$/i, ['reprise de l’enduit du pignon est avant le 21/11/2026']],
    [/travaux suivants\s*:\s*$/i, ['construction d’un immeuble R+3 de 12 logements']], [/d.un montant de\s*$/i, ['215 000 USD']], [/achevés le\s*$/i, ['30/09/2026']],
    [/accord sur\s*$/i, ['le choix du carrelage 60 × 60 gris']], [/les frais de\s*$/i, ['déplacement et de logement du stagiaire']], [/jusqu.au\s*$/i, ['31/12/2026']],
    [/rémunération mensuelle de\s*$/i, ['850 USD']], [/travaux de\s*$/i, ['gros œuvre et maçonnerie']], [/mis à disposition de\s*$/i, ['l’entreprise Kivu BTP']],
    [/matériel suivant[^:]*:\s*$/i, ['1 bétonnière 350 L et 2 vibreurs à béton']], [/assurance souscrite auprès de\s*$/i, ['la compagnie Sécurité Plus']], [/police n°\s*$/i, ['SP-2026-04571']],
    [/réalisation de\s*$/i, ['la clôture du terrain voisin']], [/les clés de\s*$/i, ['la villa du lot 7']], [/remises à\s*$/i, ['M. Jean-Pierre Mbuyi']],
    [/essais suivants[^:]*:\s*$/i, ['essai d’étanchéité de la toiture-terrasse et essai de pression des canalisations']],
    [/dossier de\s*$/i, ['M. Jean-Pierre Mbuyi']], [/déposé auprès de\s*$/i, ['la mairie de Goma']], [/l.étude de\s*$/i, ['la structure de l’immeuble R+3']],
    [/achevés en\s*$/i, ['90']], [/pénalité de retard\s*:\s*$/i, ['1']], [/remis en\s*$/i, ['3']], [/honoraires de\s*$/i, ['4 800 USD']],
    [/payables\s*:\s*$/i, ['30']], [/forfait global de\s*$/i, ['5 200 USD']], [/représenté\(e\) par\s*$/i, ['M. J.-P. Mbuyi, directeur']],
    [/conclue pour\s*$/i, ['12']], [/fourniture de\s*$/i, ['sable lavé et gravier 15/25']], [/le loueur\s*»?\s*$/i, null], [/^entre [^,]*,\s*«[^»]*»,\s*et\s*$/i, ['Location Kivu Engins']],
    [/désignation\s*:\s*$/i, ['bétonnière 350 L']], [/état à la remise\s*:\s*$/i, ['bon état, révisée']], [/loyer\s*:\s*$/i, ['25 USD']],
    [/entre \{\{societe\}\} et\s*$/i, ['M. Jean-Pierre Mbuyi']], [/engagé comme\s*$/i, ['maçon']], [/par jour de travail effectif, payé chaque\s*$/i, ['samedi']],
    [/^\s*$/, null], [/\(donneur d.ordre\) et\s*$/i, ['Transports Kivu']], [/transport de\s*:\s*$/i, ['sable et gravier']],
    [/mise à disposition de\s*$/i, ['un terrain de 300 m²']], [/redevance\s*:\s*$/i, ['150 USD par mois']], [/durée\s*:\s*du [^a]*au\s*$/i, ['31/12/2027']],
    [/carreaux de choix\s*$/i, ['1']], [/construction d.un immeuble de\s*$/i, ['4']], [/nombre et profondeur des sondages\s*:\s*$/i, ['6 sondages de 4 m']],
    [/tolérance de retard\s*$/i, ['30']], [/location de l.engin\s*$/i, ['pelle hydraulique 20 t']], [/minimum de\s*$/i, ['6']], [/tarif de\s*$/i, ['18 USD par heure']],
    [/montage et démontage par\s*$/i, ['l’entreprise de location']], [/nettoyage\s*$/i, ['2']], [/avantages éventuels\s*:\s*$/i, ['repas du midi']],
    [/stage de\s*$/i, ['3 mois']], [/tâches confiées\s*:\s*$/i, ['relevés de chantier et rapports hebdomadaires']], [/encadrement de\s*$/i, ['M. J.-P. Mbuyi']],
    [/prestation de conseil en\s*$/i, ['gestion de chantier']], [/forfait de\s*$/i, ['3 000 USD']], [/taux journalier de\s*$/i, ['120 USD']],
    [/local\/dépôt situé à\s*$/i, ['Goma, avenue de la Paix']], [/destiné à\s*$/i, ['stocker le ciment et l’outillage']], [/payable d.avance le\s*$/i, ['5']], [/dépôt de garantie de\s*$/i, ['300 USD']],
    [/payé comptant[^$]*$/i, null], [/vendu sans garantie\s*$/i, null], [/installations suivantes\s*:\s*$/i, ['groupe électrogène, pompes et ascenseur']],
    [/visites par an[^$]*$/i, null], [/dépannage sous\s*$/i, ['48']], [/selon les parts\s*:\s*$/i, ['60 % pour {{societe}}, 40 % pour le partenaire']],
    [/dans la limite de\s*$/i, ['5 000 USD par ordre']], [/reddition de comptes\s*$/i, ['2']], [/réservation du bien\s*$/i, ['villa n° 7']],
    [/cycles de corrections\s*$/i, null], [/système solaire de\s*$/i, ['5']], [/garantie matériel\s*$/i, ['5']], [/installation\s*$/i, ['2']],
    [/personnes de catégorie\s*$/i, ['12']],
    [/travaux réalisés\s*:\s*$/i, ['coulage de la dalle du R+1 (18 m³) et ferraillage des poteaux du R+2']], [/^[- ]*sécurité\s*:\s*$/i, ['casque et gilet vérifiés ; aucun accident']],
    [/premiers secours[^:]*:\s*$/i, ['trousse à la base-vie ; évacuation vers le centre de santé de Katindo']], [/conditions de paiement\s*:\s*$/i, ['30 % à la commande, solde sous 15 jours après réception']],
    [/accès et circulation des engins\s*:\s*$/i, ['entrée par la piste est, sens unique, vitesse limitée à 10 km/h']],
    [/base de vie[^:]*:\s*$/i, ['conteneur-bureau, vestiaires et 2 latrines près de l’entrée']], [/branchements provisoires[^:]*:\s*$/i, ['eau par la borne voisine, électricité par groupe de 20 kVA']],
    [/clôture, panneau, gardiennage\s*:\s*$/i, ['clôture en tôles, panneau posé, 2 gardiens de nuit']], [/hôpital[^:]*:\s*$/i, ['centre de santé de Katindo, à 1,5 km']],
    [/numéros d.urgence\s*:\s*$/i, ['pompiers 112 ; chef de chantier +243 990 000 001']],
    [/principaux événements\s*:\s*$/i, ['coulage de la dalle du R+1 et visite du maître d’ouvrage']], [/commande du béton\s*:\s*classe\s*$/i, ['C25/30']],
    [/méthode de mesure\s*:\s*$/i, ['mètre et niveau laser, relevés contradictoires']], [/consultation de\s*$/i, ['3']], [/plans examinés\s*:\s*$/i, ['plan de coffrage R+1']],
    [/chef de chantier\s*:\s*$/i, ['M. R. Banza']], [/responsable sécurité\s*:\s*$/i, ['M. T. Kasongo']], [/magasinier\s*:\s*$/i, ['Mme A. Ndaye']],
    [/stockage\s*:\s*$/i, ['conteneur fermé à clé']], [/base de vie\s*:\s*$/i, ['côté nord']], [/question posée\s*:\s*$/i, ['la profondeur d’ancrage des fondations est-elle bien de 1,20 m ?']],
    [/appeler les secours\s*:\s*$/i, ['112 puis le chef de chantier']], [/entreprise recommandée\s*:\s*$/i, ['Kivu BTP']],
    [/effectif moyen par jour\s*:\s*$/i, ['15']], [/jours d.intempéries\s*:\s*$/i, ['2']], [/montant du marché\s*:\s*$/i, ['96 000 USD']],
    [/travaux exécutés à ce jour\s*:\s*$/i, ['61 500 USD (64 %)']], [/facturé\s*:\s*$/i, ['58 000 USD']], [/payé\s*:\s*$/i, ['50 000 USD']],
    [/date contractuelle d.achèvement\s*:\s*$/i, ['03/09/2027']], [/prévision actuelle\s*:\s*$/i, ['10/09/2027']], [/thème\s*:\s*$/i, ['travail en hauteur']], [/personnes présentes\s*:\s*$/i, ['15']],
    [/aspect, marquage[^:]*:\s*$/i, ['marquage lisible, certificats fournis']], [/stockage prévu\s*:\s*$/i, ['sur palettes, à l’abri de l’humidité']],
    [/date de démarrage\s*:\s*$/i, ['03/11/2026']], [/achèvement réel\s*:\s*$/i, ['18/12/2026']], [/délai contractuel\s*:\s*$/i, ['10 mois']],
    [/dossier des ouvrages exécutés[^:]*:\s*$/i, ['remis le 12/11/2026']], [/axes et alignements[^:]*:\s*$/i, ['conformes au plan de masse']], [/écarts constatés\s*:\s*$/i, ['2 cm sur l’axe C, repris']],
    [/début\s*:\s*$/i, ['8']], [/ — fin\s*:\s*$/i, ['16']], [/volume coulé\s*:\s*$/i, ['18']], [/classe de béton\s*:\s*$/i, ['C25/30']], [/incidents\s*:\s*$/i, ['aucun']],
    [/éprouvettes prélevées\s*:\s*$/i, ['6']], [/décoffrage prévu le\s*:\s*$/i, ['25/11/2026']], [/recouvrements, ancrages[^:]*:\s*$/i, ['conformes aux plans']],
    [/accompagné\(s\) par\s*:\s*$/i, ['M. R. Banza, chef de chantier']], [/site d.évacuation autorisé\s*:\s*$/i, ['décharge communale de Goma']], [/pannes ayant arrêté[^:]*:\s*$/i, ['aucune']],
    [/indices publiés par\s*:\s*$/i, ['l’institut national de la statistique']], [/date de référence\s*:\s*$/i, ['01/10/2026']],
    [/est soumis à\s*$/i, ['la médiation du tribunal de Goma']], [/ces obligations durent\s*$/i, ['2']], [/mise en demeure de\s*$/i, ['15']], [/puis\s*$/i, ['le tribunal de Goma']],
    [/à la charge de\s*$/i, ['l’entreprise']], [/assuré par\s*$/i, ['l’entreprise de gardiennage Sécurité Plus']], [/rédigés en\s*$/i, ['français']],
    [/responsabilité de\s*$/i, ['l’entreprise']], [/limitée au montant de\s*$/i, ['la commande']], [/langue\s*$/i, ['française']], [/format\s*$/i, ['DWG et PDF']],
    [/écart constaté\s*:\s*$/i, ['épaisseur de dalle de 18 cm au lieu de 20 cm']], [/référence non respectée[^:]*:\s*$/i, ['plan S-12 indice A']], [/réceptionné par\s*:\s*$/i, ['M. J.-P. Mbuyi']],
    [/^de\s*:\s*\{\{[^}]+\}\}\s*—\s*à\s*:\s*$/i, ['M. Jean-Pierre Mbuyi']], [/^de\s*:\s*\{\{[^}]+\}\}\s*—\s*à\s*:\s*[^—]+—\s*date\s*:\s*$/i, ['12/11/2026']],
    [/à déduire\s*:\s*situations précédentes\s*$/i, ['45 000 USD']], [/avance à rembourser\s*$/i, ['10 000 USD']], [/retenue de garantie\s*$/i, ['2 500 USD']], [/net à payer\s*:\s*$/i, ['3 400 USD']],
    [/visa du chef de chantier\s*:\s*$/i, ['R. Banza']], [/visa du magasinier\s*:\s*$/i, ['A. Ndaye']], [/organisme\s*:\s*$/i, ['Bureau Veritas Goma']],
    [/je soussigné\(e\)\s*$/i, ['Jean-Pierre Mbuyi']], [/agissant pour\s*$/i, ['la société Kivu BTP']], [/approbation\s*:\s*$/i, ['approuvé le 12/11/2026']],
    [/accordée\s*\/\s*refusée[^:]*:\s*$/i, ['accordée sous réserve du port du harnais']], [/responsable\s*:\s*$/i, ['M. R. Banza']], [/exécutant\s*:\s*$/i, ['M. A. Ndaye']], [/validité\s*:\s*$/i, ['jusqu’au 30/11/2026']],
    [/emplacement\s*:\s*$/i, ['angle nord-est du terrain']], [/profondeur\s*:\s*$/i, ['1,5']], [/autorisé par\s*:\s*$/i, ['M. J.-P. Mbuyi']],
    [/charge à lever\s*:\s*$/i, ['850']], [/engin\s*:\s*$/i, ['grue mobile 20 t']], [/capacité à la portée\s*:\s*$/i, ['1 200']], [/responsable de l.opération\s*:\s*$/i, ['M. T. Kasongo']],
    [/installation concernée\s*:\s*$/i, ['tableau électrique général']], [/séparation de la source\s*:\s*$/i, ['disjoncteur général ouvert']], [/condamnation[^:]*:\s*$/i, ['cadenas posé, étiquette rouge']],
    [/vérification d.absence de tension\s*:\s*$/i, ['contrôlée au testeur']], [/mise à la terre[^:]*:\s*$/i, ['réalisée']], [/consigné par\s*:\s*$/i, ['T. Kasongo']], [/déconsigné par\s*:\s*$/i, ['T. Kasongo']],
    [/action proposée\s*:\s*$/i, ['remplacer le garde-corps de la dalle R+1']], [/délai\s*:\s*$/i, ['8 jours']], [/traitée par\s*:\s*$/i, ['R. Banza']], [/clôturée le\s*:\s*$/i, ['20/11/2026']],
    [/action corrective réalisée\s*:\s*$/i, ['garde-corps remplacé et contrôlé le 20/11/2026']], [/reçu par\s*:\s*$/i, ['A. Ndaye']], [/approuvé par\s*:\s*$/i, ['M. J.-P. Mbuyi']],
    [/intervention réalisée le\s*:\s*$/i, ['12/11/2026']], [/ par\s*:\s*$/i, ['T. Kasongo']], [/période\s*:\s*$/i, ['novembre 2026']], [/chantier\s*:\s*\{\{[^}]*\}\}\s*$/i, null],
    [/surveillance après travaux\s*:\s*$/i, ['60']], [/délivré par\s*:\s*$/i, ['J.-P. Mbuyi']], [/matériau\s*:\s*$/i, ['ciment CEM II 42,5']], [/référence\s*:\s*$/i, ['CEM-425-2026']],
    [/accusé de réception\s*:\s*$/i, ['reçu le 12/11/2026']], [/boîte\s*\/\s*classeur n°\s*$/i, ['07']], [/localisation\s*:\s*$/i, ['étagère B, bureau du chantier']], [/contenu\s*:\s*$/i, ['comptes rendus d’octobre 2026']],
    [/de\s*:\s*$/i, ['Cabinet Horizon']], [/ — à\s*:\s*$/i, ['M. Jean-Pierre Mbuyi']],
    [/superficie du terrain\s*:\s*$/i, ['600']], [/topographie\s*:\s*$/i, ['légère pente vers le sud']], [/voiries, réseaux[^:]*:\s*$/i, ['avenue goudronnée, eau et électricité en bordure de parcelle']],
    [/rapport avec l.environnement\s*:\s*$/i, ['bâtiment orienté nord-sud, retrait de 5 m sur rue, hauteur en harmonie avec le voisinage']],
    [/atouts\s*:\s*$/i, ['bonne orientation, terrain plat, accès facile']], [/contraintes \(climat[^:]*:\s*$/i, ['pluies fortes, sol argileux, retrait obligatoire de 5 m']],
    [/fonctionnement et circulations\s*:\s*$/i, ['entrée centrale, séjour au rez-de-chaussée, chambres à l’étage']], [/image et insertion[^:]*:\s*$/i, ['volumes simples, façade claire, toiture en tôles bac alu']],
    [/proximités obligatoires[^:]*:\s*$/i, ['cuisine proche du séjour ; chambres éloignées de la route']], [/usage\s*:\s*$/i, ['habitation']], [/hauteur\s*:\s*$/i, ['7,5']], [/niveaux\s*:\s*$/i, ['2']], [/effectif maximal\s*:\s*$/i, ['25']],
    [/résistance au feu de la structure\s*:\s*$/i, ['structure béton, stable au feu 1 heure']], [/compartimentage[^:]*:\s*$/i, ['escalier encloisonné et distances de 4 m avec les voisins']],
    [/matériaux de revêtement[^:]*:\s*$/i, ['carrelage et peinture classés M1']], [/extincteurs, alarme[^:]*:\s*$/i, ['extincteurs à chaque niveau, alarme sonore, éclairage de sécurité, accès pompiers par l’avenue']],
    [/pente\s*:\s*$/i, ['5']], [/largeur\s*:\s*$/i, ['1,20']], [/revêtement\s*:\s*$/i, ['béton balayé antidérapant']],
    [/éclairage naturel[^:]*:\s*$/i, ['grandes ouvertures au nord, ventilation traversante, chauffe-eau solaire']], [/origine locale[^:]*:\s*$/i, ['blocs et sable locaux, entretien annuel simple']],
    [/déchets, bruit[^:]*:\s*$/i, ['tri des gravats, travaux de 7 h à 17 h, arrosage contre la poussière']], [/étude de sol\s*:\s*$/i, ['réalisée le 03/11/2026']], [/contrainte admissible\s*:\s*$/i, ['180']], [/charges d.exploitation\s*:\s*$/i, ['2,5 kN/m²']],
    [/joints de dilatation[^:]*:\s*$/i, ['joint tous les 20 m, voiles de contreventement aux angles, enrobage de 3 cm']], [/normes et règles appliquées\s*:\s*$/i, ['Eurocode 2 et DTU 21']],
    [/honoraires\s*:\s*$/i, ['8']], [/soit\s*$/i, ['7 680']], [/échéancier suivant\s*:\s*$/i, ['30 % à la signature, 40 % à la remise du dossier de permis, 30 % à la réception']],
    [/remise des documents par phase\s*:\s*$/i, ['esquisse sous 3 semaines, avant-projet sous 6 semaines, dossier d’exécution sous 12 semaines']],
    [/mode de règlement\s*:\s*$/i, ['virement bancaire']], [/échéance\s*:\s*$/i, ['30 jours']], [/destinataire\s*:\s*$/i, ['M. Jean-Pierre Mbuyi']], [/mode d.envoi\s*:\s*$/i, ['remise en main propre']],
    [/accusé de réception : nom, date et signature\s*$/i, ['M. Mbuyi, 12/11/2026']], [/autres pièces\s*:\s*$/i, ['plan de situation et plan de masse']],
    [/parcelle n°\s*$/i, ['4572']], [/zone\s*:\s*$/i, ['résidentielle']], [/^eau\s*:\s*$/i, ['raccordée']], [/électricité\s*:\s*$/i, ['raccordée']], [/assainissement\s*:\s*$/i, ['fosse septique']],
    [/autorisation de bâtir n°\s*$/i, ['AB-2026-0312']], [/délivrée le\s*:\s*$/i, ['20/10/2026']], [/ont été achevés le\s*:\s*$/i, ['18/12/2026']],
    [/avant le\s*:\s*$/i, ['21/11/2026']], [/document examiné\s*:\s*$/i, ['plan de coffrage R+1']], [/indice\s*:\s*$/i, ['B']], [/émetteur\s*:\s*$/i, ['Bureau Structura']],
    [/date et heure\s*:\s*$/i, ['12/11/2026 à 10 h']], [/présents\s*:\s*$/i, ['M. Mbuyi, Mme Ndaye, M. Kasongo']],
    [/pénalité de\s*$/i, ['1']], [/‰ du montant du marché par jour[^$]*dans la limite de\s*$/i, ['5']], [/plafonnée à\s*$/i, ['5']], [/prime de\s*$/i, ['100 USD']],
    [/pénalité forfaitaire de\s*$/i, ['50 USD']], [/retenue de garantie de\s*$/i, ['5']], [/parfait achèvement de\s*$/i, ['12']], [/garantie de parfait achèvement\s*:\s*$/i, ['12']],
    [/délai d.exécution est de\s*$/i, ['120']], [/pour mille par jour\s*$/i, null]
  ];
  var TXT0_NULL = true;

  /* ---------- blancs dans une phrase : [expression sur le texte qui précède le blanc, valeurs] ---------- */
  var TXT = [
    [/(référence|réf\.?|n° de dossier|police|contrat)[^.\n]{0,15}:\s*$/i, ['ASS-2026-0457']],
    [/(^|[\s·—-])date\s*:\s*$/i, ['12/11/2026']],
    [/(nature|type|catégorie)[^.\n]{0,45}:\s*$/i, ['pluie violente']],
    [/(ancienneté)[^.\n]{0,5}:?\s*$/i, ['4 ans']],
    [/ci-après «[^»]+»,? et\s*$/i, ['Entreprise Kivu BTP, représentée par M. J.-P. Mbuyi, dont le siège est à Goma']],
    [/ci-après «[^»]+»\s*$/i, ['Entreprise Kivu BTP']],
    [/fabrication sur site\s*:?\s*$/i, ['centrale Ciments du Kivu']],
    [/ordre du jour\s*:?\s*$/i, ['1. Avancement des travaux ; 2. Planning ; 3. Sécurité ; 4. Questions diverses']],
    [/cure[^.\n]{0,25}:?\s*$/i, ['arrosage pendant 7 jours sous bâche']], [/vibration[^.\n]{0,25}:?\s*$/i, ['à l’aiguille vibrante']],
    [/instruction de\s*$/i, ['M. T. Kasongo, bureau de contrôle']], [/indice\s*$/i, ['B']],
    [/(plans?|documents?)[^.\n]{0,40}suivants?\s*:?\s*$/i, ['plans de coffrage R+1 et plans de ferraillage des poteaux']],
    [/(information|précision)[^.\n]{0,20}suivante?\s*:?\s*$/i, ['la nature du sol à l’emplacement de la fosse septique']],
    [/(informons|informe) que\s*:?\s*$/i, ['la livraison du ciment est reportée au 20/11/2026']],
    [/(sinistre est survenu[^:\n]*|accident[^:\n]*)\s*:\s*$/i, ['chute de matériel sans blessé, zone balisée aussitôt']],
    [/(délai de|sous|retard de|prolongation de|pendant|dans les|sous un délai de)\s*$/i, ['8']],
    [/prix\s*:?\s*$/i, ['45 000 USD hors taxes']], [/(acompte|règlement|situation|avenant)[^.\n]{0,20}(de|:)\s*$/i, ['15 000 USD']],
    [/(entre|et)\s*$/i, ['Entreprise Kivu BTP']],
    [/prochaine réunion\s*:\s*$/i, ['mardi 18/11/2026 à 9 h, sur le chantier']],
    [/(contrôlé|vérifié|établi|rédigé|relevé|dressé|préparé|visé) par\s*:?\s*$/i, ['J.-P. Mbuyi']],
    [/fonction\s*:\s*$/i, ['conducteur de travaux']],
    [/(à reprendre|à corriger|à lever|à terminer|à fournir|à remettre)[^.\n]{0,25}(avant le|pour le|au plus tard le)\s*$/i, ['21/11/2026']],
    [/du\s*$/i, ['03/11/2026']], [/\bau\s*$/i, ['14/11/2026']],
    [/(le|en date du|daté du|à compter du|jusqu.au)\s*$/i, ['12/11/2026']],
    [/(délai|durée)[^.\n:]{0,25}\s*:?\s*$/i, ['15 jours calendaires']],
    [/classe de résistance[^.\n]{0,25}:?\s*$/i, ['C25/30']],
    [/dosage[^.\n]{0,25}:?\s*$/i, ['350']], [/rapport eau\/ciment[^.\n]{0,8}:?\s*$/i, ['0,50']], [/volume[^.\n]{0,25}:?\s*$/i, ['18']],
    [/température[^.\n]{0,12}:?\s*$/i, ['27']], [/(vibration|cure)[^.\n]{0,25}:?\s*$/i, ['à l’aiguille vibrante, arrosage 7 jours']],
    [/décoffrage[^.\n]{0,12}:?\s*$/i, ['25/11/2026']],
    [/(personnel|effectif|main-d.œuvre)[^.\n]{0,15}:?\s*$/i, ['14 ouvriers']], [/matériel[^.\n]{0,15}:?\s*$/i, ['1 bétonnière, 1 vibreur']], [/matériaux[^.\n]{0,15}:?\s*$/i, ['25 sacs de ciment, 1,2 t d’acier']],
    [/(montant|somme|prix|coût|budget|total)[^.\n]{0,40}(de|:)?\s*$/i, ['12 500 USD']], [/(taux|pourcentage|avancement)[^.\n]{0,25}:?\s*$/i, ['65']],
    [/(n°|numéro)\s*$/i, ['07']], [/(nom|M\.\/Mme|monsieur|madame)[^.\n]{0,12}:?\s*$/i, ['Jean-Pierre Mbuyi']], [/(adresse|domicile)[^.\n]{0,12}:?\s*$/i, ['12 avenue de la Paix, Goma']],
    [/(téléphone|tél|contact)[^.\n]{0,12}:?\s*$/i, ['+243 990 000 001']], [/(e-?mail|courriel)[^.\n]{0,12}:?\s*$/i, ['contact@exemple.com']],
    [/(motif|raison|cause|objet|sujet)[^.\n]{0,20}:?\s*$/i, ['intempéries ayant empêché le coulage de la dalle']],
    [/(observation|remarque|commentaire)[^.\n]{0,15}:?\s*$/i, ['aucune réserve majeure ; reprise mineure de l’enduit à prévoir']],
    [/(réserve|réclamation|demande)[^.\n]{0,20}:?\s*$/i, ['fissures du carrelage de la cuisine à reprendre']],
    [/(décision|conclusion|avis)[^.\n]{0,12}:?\s*$/i, ['favorable, sous réserve de la levée des points ci-dessus']],
    [/(lieu|endroit|site|zone|localisation|ouvrage)[^.\n]{0,15}:?\s*$/i, ['dalle du R+1, travée A-B']],
    [/(entreprise|société|fournisseur|sous-traitant|prestataire|titulaire)[^.\n]{0,15}:?\s*$/i, ['Entreprise Kivu BTP']],
    [/(heure|horaire)[^.\n]{0,12}:?\s*$/i, ['9 h 00']], [/(quantité|nombre)[^.\n]{0,15}:?\s*$/i, ['25']], [/(longueur|largeur|hauteur|épaisseur|surface|dimension)[^.\n]{0,12}:?\s*$/i, ['4,50']],
    [/(fonction|qualité|titre)[^.\n]{0,8}\s*$/i, ['conducteur de travaux']], [/(mission|formation|poste)[^.\n]{0,15}[:«]?\s*$/i, ['conducteur de travaux']],
    [/(« )\s*$/, ['Sécurité sur chantier — travaux en hauteur']], [/\(\s*$/, ['exemple : 12']]
  ];
  /* unité qui suit le blanc : aide à choisir la valeur */
  var UNIT = [[/^\s*mois/, '12'], [/^\s*ans?\b/, '2'], [/^\s*‰/, '1'], [/^\s*kW/, '5'], [/^\s*kPa/, '180'], [/^\s*minutes/, '30'], [/^\s*fois/, '2'], [/^\s*niveaux/, '4'], [/^\s*exemplaires/, '3'], [/^\s*personnes/, '15'], [/^\s*bar/, '6'], [/^\s*kg\b/, '850'], [/^\s*visites/, '4'], [/^\s*cycles/, '2'], [/^\s*(heures|h\b)/, '8'], [/^\s*(MPa)/, '25'], [/^\s*(kg\/m³)/, '350'], [/^\s*(m³)/, '18'], [/^\s*(m²)/, '120'], [/^\s*(ml|m\b)/, '45'], [/^\s*(cm)/, '9'], [/^\s*(°C)/, '27'], [/^\s*%/, '65'], [/^\s*(jours?)/, '15'], [/^\s*(h\b|heures?)/, '8'], [/^\s*(USD|\$)/, '12 500'], [/^\s*(kN|kg|t\b)/, '120'], [/^\s*(mm)/, '12'], [/^\s*(nombre|u\b)/, '8']];

  /* ---------- paragraphes sous un titre dont le contenu est vide ---------- */
  /* rubriques précises (testées avant les rubriques générales) */
  var HEAD0 = [
    [/^causes?( probables?| identifiées| des écarts)?$|causes? \(internes|causes et mesures immédiates/i, 'Pluies exceptionnelles du 03 au 06/11/2026 et retard de livraison du ciment (5 jours) ; deux ouvriers absents pour maladie.'],
    [/points? de blocage|difficultés|problèmes rencontrés/i, 'Accès au chantier difficile après la pluie ; plan de ferraillage des poutres du R+2 non encore visé par le bureau d’études.'],
    [/prévisions|programme de la semaine|prévisions du lendemain/i, 'Coulage de la dalle du R+1 jeudi 13/11 ; ferraillage des poteaux du R+2 vendredi ; réception du sable lundi 17/11.'],
    [/faits constatés|description des faits|faits et dégâts|circonstances|description de l.incident/i, 'Le 11/11/2026 vers 14 h, une averse violente a provoqué l’effondrement d’un mur de clôture sur 6 mètres. Personne n’a été blessé ; la zone a été balisée aussitôt.'],
    [/constats|désordres constatés|défauts relevés|anomalies|non-conformités relevées|pathologies/i, 'Fissures de 0,3 mm sur le voile de l’axe C, enrobage insuffisant sur deux poutres, traces d’humidité au plafond du R+1 ; photos n° 12 à 18 jointes.'],
    [/recommandations|conclusion et recommandations|avis et recommandations/i, 'Reprendre les enrobages avant le coulage, traiter les fissures par injection de résine et surveiller leur évolution pendant 30 jours.'],
    [/mesures? (conservatoires|d.urgence)|mesures conservatoires prises/i, '- Zone balisée et accès interdit au public\n- Évacuation des gravats et sécurisation des abords\n- Information immédiate du maître d’ouvrage et de l’assurance'],
    [/réparations?( proposées| conseillées)?$|réparation et délai|^traitement proposé/i, 'Reconstruction du mur sur 6 m avec fondation de 40 cm et chaînage ; coût estimé à 1 200 USD ; délai de 5 jours après la fin des pluies.'],
    [/mesures? (correctives|compensatoires|préventives|de rattrapage|prises)|actions? (correctives|d.amélioration|menées|de mise en conformité)|plan de rattrapage|mesures prises pour éviter/i, '- Renforcer l’équipe de ferrailleurs (+3 personnes) pendant deux semaines\n- Travailler le samedi après-midi jusqu’au 05/12/2026\n- Commander le ciment avec une marge de sécurité de 10 %'],
    [/documents? (de référence|à produire|et accès remis|présentés)|^documents?$|bons de livraison|certificats/i, 'Plans d’architecture indice B, note de calcul des fondations, CCTP lot gros œuvre, fiches techniques du ciment et de l’acier, bons de livraison n° 214 à 220.'],
    [/travaux exécutés|travaux réalisés|avancement des travaux|état d.avancement|structure réalisée|maçonnerie|dalles et toiture|ferraillage|bétonnage|fouilles et fond/i, 'Poteaux et poutres du R+1 coulés (18 m³), maçonnerie du R+1 à 60 %, ferraillage du plancher haut du R+1 en cours.'],
    [/respect des délais|écart par rapport au planning|écarts? et explications|retards? (constatés|et causes)|incidence sur/i, 'Retard de 4 jours sur le planning contractuel, dû à la pluie et à la livraison tardive du ciment ; la date d’achèvement est maintenue grâce à un renfort d’équipe.'],
    [/note globale|appréciation générale|évaluation/i, 'Note globale : 4/5. Chantier propre, équipe réactive, documents bien tenus ; un point à améliorer sur la protection des rives de dalle.'],
    [/description|consistance des travaux|particularités|périmètre/i, 'Construction d’une villa R+1 de 180 m² : fondations superficielles, ossature en béton armé, murs en blocs de ciment, toiture en tôles bac alu, carrelage et peinture.'],
    [/objectifs|exigences|exigence concernée/i, 'Respecter le délai de 10 mois, garantir la qualité du béton (C25/30) et assurer la sécurité du personnel sans accident déclaré.'],
    [/intervenants|responsables|^responsable$|personnes concernées|participants|corps d.état présents/i, 'Maître d’ouvrage : M. J.-P. Mbuyi ; architecte : Mme A. Ndaye ; bureau de contrôle : M. T. Kasongo ; chef de chantier : M. R. Banza.'],
    [/points? (positifs)/i, 'Chantier propre et bien balisé, équipes ponctuelles, registre de chantier à jour, bon respect du port des équipements de protection.'],
    [/points? à corriger|points? sensibles|points de contrôle/i, 'Protection des rives de dalle, stockage du ciment sur palettes, signalisation de l’entrée des camions.'],
    [/commentaire|justification|analyse|solution proposée|choix retenu|réponse|proposition de choix/i, 'Compte tenu du planning et du prix, la solution A (blocs pleins de 15 cm) est retenue : elle réduit le délai de 3 jours pour un surcoût de 2 %.'],
    [/décision demandée|décisions? (attendues|demandées)/i, 'Valider le plan d’exécution indice B avant le 20/11/2026 et confirmer le choix du carrelage 60 × 60 gris.'],
    [/contrôles? (qualité|réalisés)|essais réalisés|méthode d.essai|ouvrage essayé|résultats|pressions relevées|mesures d.isolement|circuits contrôlés|réseaux essayés/i, 'Essai à 6 bars pendant 2 heures : aucune chute de pression ; résistance d’isolement supérieure à 500 kΩ sur tous les circuits.'],
    [/^fuites/i, 'Une fuite au raccord du compteur a été réparée le jour même ; aucune autre fuite constatée après remise en pression.'],
    [/qualité,? sécurité|sécurité|équipements de protection|échafaudages|engins|électricité|accidents|hygiène/i, 'Port du casque, du gilet et des chaussures de sécurité vérifié chaque matin ; échafaudage contrôlé le 11/11/2026 ; aucun accident ni presque-accident cette semaine.'],
    [/photos?( et pièces jointes)?$/i, 'Photos n° 12 à 18 prises le 11/11/2026 : dalle du R+1, ferraillage des poutres, fissure du voile axe C, mur de clôture effondré.'],
    [/budget initial|dépenses réelles|écarts et causes|estimation du coût|travaux conseillés/i, 'Budget initial : 96 000 USD ; dépenses à ce jour : 61 500 USD (64 %) ; dépassement de 1 800 USD sur l’acier, compensé par une économie sur la location d’engins.'],
    [/prix|qualité des produits|service après-vente|qualité d.exécution|administratif|délai$/i, 'Prix compétitif (note 4/5), produits conformes aux fiches techniques, livraison dans le délai convenu, interlocuteur disponible.'],
    [/thème et durée|contenu|suites/i, 'Causerie sécurité de 20 minutes sur le travail en hauteur : port du harnais, vérification des garde-corps et organisation des secours.'],
    [/lieu et heure/i, 'Dalle du R+1, côté est, mercredi 11/11/2026 vers 10 h 30.'],
    [/victime et circonstances|lésions et soins|secours apportés/i, 'Un maçon a glissé d’une échelle ; légère contusion au poignet, soins de première urgence au poste de secours puis consultation au centre de santé.'],
    [/non-conformités (ouvertes|clôturées)|liste des non-conformités|réserves (initiales|levées|restantes)|délai de levée|levée des réserves/i, '- Fissures du carrelage de la cuisine : levée le 05/12/2026\n- Porte du WC jouant : levée le 28/11/2026\n- Peinture écaillée au plafond du séjour : à reprendre avant le 12/12/2026'],
    [/état de la couverture|étanchéité|évacuation des eaux|état de surface|zone contrôlée|épaisseur des couches|densités mesurées|localisation|largeur et longueur|évolution/i, 'Toiture en tôles en bon état, trois fixations à resserrer ; gouttières obstruées côté nord à nettoyer ; évacuation des eaux conforme.'],
    [/nature du sol|état du terrain|réseaux existants|accès et environnement|contraintes particulières|eaux, blindages/i, 'Sol argilo-sableux stable, nappe à 3,5 m ; réseau d’eau de la Régie à 4 m de la limite ; accès par une piste de 4 m de large, praticable en saison sèche.'],
    [/engins et outils|heures d.utilisation|pannes|besoins complémentaires|engins concernés|quantités distribuées|heures de travail|matériel concerné/i, 'Bétonnière : 32 h d’utilisation ; vibreur n° 2 en panne depuis le 10/11, remplacé le 12/11 ; besoin d’un second échafaudage de 6 m.'],
    [/locaux visités|parties visitées|date de la réception|prochaine visite/i, 'Visite du R+1 (4 chambres, séjour, cuisine) et du R+2 le 11/11/2026 ; prochaine visite le 18/11/2026 à 9 h.'],
    [/offres reçues|critères d.analyse|classement/i, 'Trois offres reçues : Kivu BTP (96 000 USD), Horizon Construction (101 500 USD), Great Lakes Bâtiment (98 200 USD) ; critères : prix 50 %, délai 30 %, références 20 %.'],
    [/contraintes techniques|exigences applicables|principes constructifs|objectifs du maître|budget et calendrier|entretien et vérifications|dérogations/i, 'Structure en béton armé selon le cahier des charges, budget de 96 000 USD, durée de 10 mois ; vérification annuelle des garde-corps et de l’étanchéité de la toiture.'],
    [/instructions données|réponse de la maîtrise|action corrective demandée|remarques et conditions|observations des parties|observations du maître/i, 'L’entreprise reprend l’enduit du pignon est et fournit les fiches techniques manquantes avant le 21/11/2026 ; le maître d’ouvrage valide la suite des travaux.'],
    [/attestation de l.architecte/i, 'Je certifie que les ouvrages exécutés sont conformes au permis de bâtir et aux plans approuvés, sous réserve des observations ci-dessus.'],
    [/article \d+ — engagements de/i, '{{societe}} s’engage à exécuter les prestations selon le cahier des charges, dans les délais convenus, avec du personnel qualifié et assuré.'],
    [/article \d+ — engagements du partenaire/i, 'Le partenaire s’engage à fournir l’accès au site, les documents nécessaires et à régler les sommes dues dans un délai de 15 jours après facture.'],
    [/article \d+ — résiliation/i, 'Chaque partie peut résilier le contrat par lettre recommandée après un préavis de 30 jours ; les litiges sont d’abord réglés à l’amiable, puis portés devant le tribunal compétent de Goma.'],
    [/objet de l.avenant/i, 'Le présent avenant prolonge le délai d’exécution de 20 jours calendaires et augmente le montant du marché de 4 800 USD pour les travaux de reprise de l’étanchéité.'],
    [/à retenir|enseignements|bilan technique|résumé du mois|faits marquants|appréciation|décisions demandées à la direction|incidents, difficultés/i, 'Mois globalement conforme au planning : dalle du R+1 coulée, 118 m³ de béton posés, aucun accident. À retenir : sécuriser les approvisionnements en ciment.'],
    [/actions$|^suite à donner|plans et documents à modifier/i, '- Mettre à jour le plan de ferraillage des poutres (indice C)\n- Envoyer le plan modifié au bureau de contrôle avant le 20/11/2026\n- Informer le chef de chantier de la modification'],
    [/décisions prises|anomalies et décisions|^décision$/i, 'Il est décidé de poursuivre les travaux selon le planning révisé, d’engager la dépense de 3 400 USD pour les aciers et de fixer la prochaine réunion au 18/11/2026.'],
    [/contacts?$/i, 'Chef de chantier : M. R. Banza, +243 990 000 001 ; conducteur de travaux : M. J.-P. Mbuyi, +243 810 000 002.'],
    [/dispositions?$/i, 'Les dispositions du présent document s’appliquent à tous les intervenants du chantier à compter du 12/11/2026 et jusqu’à la réception définitive.'],
    [/matériaux principaux|diamètres et longueurs/i, 'Ciment CEM II 42,5, acier HA 12 et HA 16 en barres de 12 m, blocs de ciment de 15 cm, sable de rivière lavé, gravier 15/25.']
  ];
  var HEAD = [
    [/objet|but|sujet/i, 'Le présent document a pour objet de faire le point sur l’avancement du chantier {{projet}} et de préciser les actions à mener pour tenir le délai contractuel.'],
    [/contexte|rappel|préambule|situation|historique|constat/i, 'Les travaux de gros œuvre du R+1 sont achevés à 65 %. Les pluies de la semaine du 03/11/2026 ont retardé le coulage de la dalle de deux jours.'],
    [/consigne|instruction|mesure|dispositions?/i, 'Chaque chef d’équipe applique les consignes suivantes dès le 12/11/2026 : port obligatoire du casque et du gilet, balisage des zones de coulage, contrôle des échafaudages chaque matin avant la prise de poste.'],
    [/recette|ressources|financement/i, 'Avance du maître d’ouvrage : 25 000 USD ; deuxième acompte attendu fin novembre : 40 000 USD ; ventes de matériaux de récupération : 1 500 USD.'],
    [/dépense|charge|coûts?/i, 'Main-d’œuvre : 18 000 USD ; matériaux (ciment, acier, sable) : 22 500 USD ; location d’engins : 4 200 USD ; frais généraux : 2 300 USD.'],
    [/écart|risque|aléa|difficult|problème/i, 'Hausse possible du prix de l’acier de 8 % et retard de livraison du ciment de 5 jours en cas de blocage de la route. Une provision de 5 % est prévue.'],
    [/hypoth/i, 'Prix unitaires valables jusqu’au 31/12/2026 ; 22 jours travaillés par mois ; aucun arrêt prolongé pour intempéries.'],
    [/conclusion|synthèse|bilan|résumé/i, 'Les ouvrages contrôlés sont conformes aux plans et au CCTP. Deux reprises mineures sont à effectuer avant le 21/11/2026 ; elles ne remettent pas en cause le planning.'],
    [/recommandation|proposition|suite|prochaines? étapes?/i, 'Il est recommandé de commander les aciers dès maintenant, de reprendre l’enduit du pignon est et de planifier la réception provisoire pour la semaine du 07/12/2026.'],
    [/observation|remarque|commentaire|divers/i, 'Le site est propre et bien tenu. Il est rappelé que le stockage du ciment doit rester sur palette et à l’abri de l’humidité.'],
    [/décision|résolution|accord/i, 'Il est décidé de poursuivre les travaux selon le planning révisé, d’engager la dépense de 3 400 USD pour les aciers et de fixer la prochaine réunion au 18/11/2026.'],
    [/participant|présent|invité|convoqué/i, 'M. J.-P. Mbuyi (conducteur de travaux), Mme A. Ndaye (architecte), M. T. Kasongo (bureau de contrôle), M. R. Banza (chef de chantier).'],
    [/description|présentation|détail|nature/i, 'Construction d’une villa R+1 de 180 m² sur parcelle de 600 m², structure en béton armé, remplissage en blocs de ciment, toiture en tôles bac alu.'],
    [/matériel|équipement|moyen/i, '1 bétonnière de 350 L, 2 vibreurs à béton, 1 échafaudage de 12 m, 1 camionnette de 3 t.'],
    [/personnel|équipe|main/i, '1 chef de chantier, 4 maçons, 3 ferrailleurs, 2 coffreurs, 5 manœuvres, soit 15 personnes.'],
    [/sécurité|prévention|hygiène/i, 'Casque, chaussures de sécurité et gilet obligatoires ; garde-corps en rive de dalle ; extincteur et trousse de secours à la base-vie ; accueil sécurité de chaque nouvel arrivant.'],
    [/planning|calendrier|délai|échéance/i, 'Coulage dalle R+1 : 17/11/2026 ; maçonnerie R+1 : du 19/11 au 05/12/2026 ; réception provisoire prévue le 18/12/2026.'],
    [/besoin|demande|requête/i, 'Livraison de 120 sacs de ciment CEM II 42,5 et de 1,5 t d’acier HA 12 sur le chantier avant le 14/11/2026.'],
    [/engagement|garantie|obligation/i, 'L’entreprise s’engage à exécuter les travaux conformément aux plans, au CCTP et aux règles de l’art, et à lever les réserves dans le délai fixé.'],
    [/signature|validation|approbation/i, 'Lu et approuvé. Bon pour accord.'],
    [/introduction|présentation générale/i, 'Notre société {{societe}} intervient dans la construction, la rénovation et le suivi de chantiers depuis plus de dix ans.']
  ];
  var FALLBACK = 'Aucune observation particulière : les travaux sont conformes aux plans et au CCTP.';
  /* rubriques propres aux procès-verbaux et aux lettres (selon le type de pièce) */
  var HEADPV = [
    [/décision|conclusion|avis|suite/i, 'L’ouvrage est accepté ; l’entreprise est autorisée à poursuivre l’étape suivante, sous réserve de deux reprises mineures à lever avant le 21/11/2026.'],
    [/faits constatés|constat|description|observations?/i, 'Les parties constatent contradictoirement l’état des ouvrages : fissure de retrait de 0,3 mm sur le voile de l’axe C ; le reste est conforme aux plans. Photos n° 12 à 14 jointes.'],
    [/mesures|réserves/i, '- Reprise de l’enduit du pignon est avant le 21/11/2026\n- Nettoyage de la dalle avant le coulage']
  ];
  var LET_DOC = ['le plan de ferraillage des poutres du R+2 (indice C)', 'la note de calcul de la dalle du R+1', 'les fiches techniques du ciment et de l’acier'];
  var LET_NC = ['enrobage des aciers insuffisant sur deux poutres du R+1', 'garde-corps absent en rive de la dalle du R+1', 'épaisseur de dalle mesurée à 18 cm au lieu de 20 cm'];

  var curName = '';
  function cellFill(cell, hdr, rowLabel) {
    var h = String(hdr || '');
    if (/matériel|engin|outil|inventaire/i.test(curName)) {
      if (/^état$/i.test(h)) return pick(['Bon état', 'Bon état', 'À réviser'], 'inv4');
      if (/^désignation$/i.test(h)) return pick(['Bétonnière 350 L', 'Vibreur à béton', 'Échafaudage 12 m', 'Brouette'], 'inv1');
      if (/^référence$/i.test(h)) return pick(['BET-01', 'VIB-02', 'ECH-03', 'BRO-04'], 'inv2');
      if (/^emplacement$/i.test(h)) return pick(['Magasin du chantier', 'Zone de coulage', 'Façade nord', 'Base de vie'], 'inv3');
    }
    if (/^oui\s*\/\s*non$/i.test(cell.trim())) return pick(['oui', 'oui', 'oui', 'non'], 'yn');
    var i, k;
    if (/résultat|exigence/i.test(h) && rowLabel) for (i = 0; i < ROWV.length; i++) if (ROWV[i][0].test(rowLabel)) return /exigence/i.test(h) ? ROWV[i][1][1] : ROWV[i][1][0];
    if (/^constat|^valeur|^mesure|^relevé|^réalisé|^résultat/i.test(h) && rowLabel) for (i = 0; i < ROWC.length; i++) if (ROWC[i][0].test(rowLabel)) return ROWC[i][1];
    var u = ''; var m = /_+\s*([^\s_|]+)?/.exec(cell); if (m && m[1]) u = m[1];
    for (i = 0; i < COL.length; i++) if (COL[i][0].test(h)) { return pick(COL[i][1], 'c' + i) + (u && /^(MPa|cm|%|mm|kg|m|m²|m³|°C|USD|j|jours?|h)$/i.test(u) ? ' ' + u : ''); }
    if (w.__V127_LOG) w.__V127_LOG[h] = (w.__V127_LOG[h] || 0) + 1;
    return pick(['Conforme', 'Validé', 'En cours'], 'fb');
  }
  function inline(line, fb) {
    line = line.replace(/_{2,}\/_{2,}\/_{2,}/g, function (m, off, str) {
      var b = str.slice(0, off);
      if (/né\(e\) le\s*$/i.test(b)) return '12/05/1985';
      if (/depuis le\s*$/i.test(b)) return '03/03/2019';
      if (/stage[^.]*du\s*$/i.test(b)) return '03/08/2026';
      if (/\bau\s*$/i.test(b)) return '31/10/2026';
      if (/échéance du\s*$/i.test(b)) return '30/10/2026';
      return '12/11/2026';
    });
    return line.replace(/_{3,}/g, function (blank, off, str) {
      var before = str.slice(0, off), after = str.slice(off + blank.length), i;
      if (/^\s*h\b/.test(after)) return /fin\s*:\s*$/i.test(before) ? '16' : '8';
      for (i = 0; i < TXT0.length; i++) if (TXT0[i][1] && TXT0[i][0].test(before.replace(/^[-\s]+/, ''))) { var v0 = pick(TXT0[i][1], 'z' + i), um = /\s*(m²|m³|USD|%)$/.exec(v0); if (um && after.replace(/^\s+/, '').indexOf(um[1]) === 0) v0 = v0.slice(0, v0.length - um[0].length); if (/^\s*jours?/.test(after) && /mois$/.test(v0)) v0 = '300'; return v0; }
      for (i = 0; i < UNIT.length; i++) if (UNIT[i][0].test(after) && !/(le|du|au|avant le)\s*$/i.test(before)) return UNIT[i][1];
      for (i = 0; i < TXT.length; i++) if (TXT[i][0].test(before)) return pick(TXT[i][1], 't' + i);
      return fb(before);
    });
  }
  function fill(body, name, type) {
    n = 0; cnt = {}; curName = name || ''; var hand = (w.EXBPIE_V127_HAND || {})[type]; hand = hand && hand[name]; var hi = 0; var lines = String(body).split('\n'), out = [], hdr = null, head = '';
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i], m;
      if ((m = /^#{2,}\s*(.+)/.exec(l))) { head = m[1]; out.push(l); hdr = null; continue; }
      if (/^#\s/.test(l)) { head = l.replace(/^#\s*/, ''); out.push(l.replace(/n°\s*_{3,}/i, 'N° 07').replace(/mois de\s*_{3,}/i, 'MOIS DE NOVEMBRE 2026').replace(/_{3,}/g, '07')); continue; }
      if (/^\|/.test(l)) {
        var cells = l.split('|').slice(1, -1);
        if (!/_{2,}/.test(l) && (i === 0 || !/^\|/.test(lines[i - 1]) || hdr === null)) { hdr = cells.map(function (c) { return c.trim(); }); out.push(l); continue; }
        if (/_{2,}|^\s*oui\s*\/\s*non/i.test(l) || cells.some(function (c) { return /^\s*oui\s*\/\s*non\s*$/i.test(c); })) {
          var rl = /_{2,}/.test(cells[0]) ? '' : cells[0].trim();
          out.push('|' + cells.map(function (c, j) { return /_{2,}/.test(c) || /^\s*oui\s*\/\s*non\s*$/i.test(c) ? ' ' + cellFill(c, hdr && hdr[j], rl) + ' ' : c; }).join('|') + '|'); continue;
        }
        out.push(l); continue;
      }
      if (/^\s*(-\s*|\d+\.\s*)?_{3,}\s*$/.test(l)) {            /* ligne entièrement vide sous un titre */
        if (hand && hi < hand.length) { out.push(hand[hi++]); continue; }
        var t = null, hh0 = String(head).replace(/^\d+\.\s*/, '');
        if (type === 'lettre' && !hh0) t = '- ' + pick(/non-conformit/i.test(name) ? LET_NC : LET_DOC, 'let');
        if (t === null && type === 'pv') for (var kp = 0; kp < HEADPV.length && t === null; kp++) if (HEADPV[kp][0].test(hh0)) t = HEADPV[kp][1]; var hh = hh0, k; if (t === null) for (k = 0; k < HEAD0.length && t === null; k++) if (HEAD0[k][0].test(hh)) t = HEAD0[k][1]; for (k = 0; k < HEAD.length && t === null; k++) if (HEAD[k][0].test(hh)) t = HEAD[k][1];
        out.push((/^\s*-/.test(l) && !/^- /.test(t || '') ? '- ' : (/^\s*\d+\.\s/.test(l) ? l.match(/^\s*\d+\.\s/)[0] : '')) + (t || FALLBACK)); continue;
      }
      out.push(/_{3,}/.test(l) ? inline(l, function (before) { if (hand && hi < hand.length) return hand[hi++]; return /[:(]\s*$/.test(before) ? 'la reprise de l’enduit du pignon est, à terminer avant le 21/11/2026' : 'Entreprise Kivu BTP'; }) : l);
    }
    return out.join('\n');
  }
  /* longueur du « vrai » texte (hors titres, tableaux, blancs, variables) : un modèle déjà rédigé n'est pas touché */
  function prose(s) {
    return String(s).split('\n').filter(function (l) { l = l.trim(); return l && !/^#/.test(l) && !/^\|/.test(l); }).map(function (l) { return l.replace(/\{\{\w+\}\}/g, '').replace(/_+/g, '').replace(/^(Fait à|Projet|Maître d.ouvrage|Date|Objet|Réf)[^\n]*/, ''); }).join('').replace(/\s+/g, ' ').trim().length;
  }
  w.EXBPIE_V127 = { fill: fill, prose: prose };
  Object.keys(D.models).forEach(function (t) {
    var src = D.models[t]; if (!src || typeof src !== 'object') return;
    Object.keys(src).forEach(function (k) {
      var b = src[k]; if (typeof b !== 'string' || !/_{3,}/.test(b) || !b.trim()) return;
      src[k] = fill(b, k, t);
    });
  });
})(typeof window !== 'undefined' ? window : this);
