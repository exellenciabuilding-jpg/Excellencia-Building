/* V144c — boîtes de confirmation / saisie intégrées à la page (non bloquantes) : remplacent confirm()/prompt() natifs,
 * qui figent tout l'écran tant qu'on n'a pas répondu (et peuvent se perdre derrière la fenêtre).
 * EXBUI.confirm(msg,{ok,non,danger}) -> Promise<boolean> ; EXBUI.prompt(msg,defaut) -> Promise<string|null>. Échap = annuler, Entrée = valider. */
(function(w){'use strict';
if(w.EXBUI)return;
var d=w.document;
function el(t,c,x){var e=d.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
if(!d.getElementById('exbUiCss')){var st=d.createElement('style');st.id='exbUiCss';st.textContent='.exbui-bg{position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px}.exbui-box{background:#fff;color:#111;border-radius:12px;max-width:440px;width:100%;padding:18px 18px 14px;box-shadow:0 12px 40px rgba(0,0,0,.4);font:15px/1.45 system-ui,Arial,sans-serif}.exbui-msg{white-space:pre-line;margin:0 0 12px}.exbui-in{width:100%;box-sizing:border-box;padding:9px;font:inherit;border:1px solid #94a3b8;border-radius:8px;margin:0 0 12px}.exbui-btns{display:flex;gap:8px;justify-content:flex-end}.exbui-btns button{padding:9px 16px;border-radius:8px;border:1px solid #94a3b8;background:#f1f5f9;font:inherit;cursor:pointer}.exbui-btns .exbui-ok{background:#173565;color:#fff;border-color:#173565}.exbui-btns .exbui-dg{background:#b42318;border-color:#b42318}';(d.head||d.documentElement).appendChild(st)}
function boite(msg,champ,def,o){return new Promise(function(res){
  o=o||{};var prev=d.activeElement,bg=el('div','exbui-bg'),bx=el('div','exbui-box'),inp=null;
  bx.setAttribute('role','dialog');bx.setAttribute('aria-modal','true');bx.appendChild(el('p','exbui-msg',String(msg==null?'':msg)));
  if(champ){inp=el('input','exbui-in');inp.type='text';inp.value=def==null?'':def;bx.appendChild(inp)}
  var bt=el('div','exbui-btns'),non=el('button','',o.non||'Annuler'),ok=el('button','exbui-ok'+(o.danger?' exbui-dg':''),o.ok||'OK');non.type=ok.type='button';
  bt.appendChild(non);bt.appendChild(ok);bx.appendChild(bt);bg.appendChild(bx);
  function fin(v){d.removeEventListener('keydown',kd,true);bg.remove();try{prev&&prev.focus&&prev.focus()}catch(e){}res(v)}
  function kd(e){if(e.key==='Escape'){e.preventDefault();e.stopPropagation();fin(champ?null:false)}else if(e.key==='Enter'&&(champ||d.activeElement===ok)){e.preventDefault();e.stopPropagation();fin(champ?inp.value:true)}}
  ok.onclick=function(){fin(champ?inp.value:true)};non.onclick=function(){fin(champ?null:false)};
  bg.addEventListener('mousedown',function(e){if(e.target===bg)fin(champ?null:false)});
  d.addEventListener('keydown',kd,true);(d.body||d.documentElement).appendChild(bg);
  try{(inp||ok).focus();if(inp)inp.select()}catch(e){}})}
w.EXBUI={confirm:function(m,o){return boite(m,false,null,o)},prompt:function(m,def,o){return boite(m,true,def,o)}};

/* Tous les modules : confirm()/prompt() déclenchés par un CLIC deviennent non bloquants, sans réécrire chaque appel.
   Principe : l'appel interrompt le gestionnaire (exception interne), la boîte intégrée s'affiche, puis, si l'utilisateur valide,
   le même clic est rejoué et le(s) appel(s) reçoivent la réponse donnée. Hors clic (minuterie, après await…) : boîte native, comme avant. */
(function(){
var SENT={exbDialogue:1},chain=[],idx=0,replaying=false,aborted=false,ouverte=false,nat={confirm:w.confirm,prompt:w.prompt};
w.addEventListener('error',function(e){if(e.error===SENT){e.preventDefault();e.stopImmediatePropagation()}},true);
w.addEventListener('unhandledrejection',function(e){if(e.reason===SENT){e.preventDefault()}},true);
function ask(kind,args){
  var msg=args[0],def=args[1];
  if(replaying&&idx<chain.length)return chain[idx++];
  var ev=null;try{ev=w.event}catch(e){}
  if(!ev||ev.type!=='click'||!ev.target||!ev.target.isConnected||!ev.target.click){chain=[];return nat[kind].apply(w,args)}
  if(ouverte)return kind==='confirm'?false:null;
  ouverte=true;aborted=true;var cible=ev.target;try{ev.preventDefault()}catch(e){}
  var danger=/supprim|effac|retir|vider|r[ée]initialis|annul|perdu|irr[ée]versible/i.test(String(msg||''));
  var pr=kind==='confirm'?w.EXBUI.confirm(msg,{danger:danger,ok:danger?'Confirmer':'OK'}):w.EXBUI.prompt(msg,def);
  pr.then(function(v){ouverte=false;
    if(v===false||v===null){chain=[];return}
    chain.push(kind==='confirm'?true:v);
    if(!cible.isConnected){chain=[];return}
    replaying=true;idx=0;aborted=false;try{cible.click()}finally{replaying=false;if(!aborted)chain=[]}});
  throw SENT}
w.confirm=function(m){return ask('confirm',arguments)};
w.prompt=function(m,d){return ask('prompt',arguments)};
w.confirm.__exbui=w.prompt.__exbui=1;
})();
})(window);
