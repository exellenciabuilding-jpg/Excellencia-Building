# V129 — Portail public des plans (QR → référence + code → téléchargement)

Base : V128g. Renforce votre « Portail Public V2 » (qui était une démonstration avec un dossier fictif) et le branche sur le logiciel central.

## Pour les clients : page `plan.html` (adresse propre `/plan`)
- Interface de votre portail V2 (couleurs Excellencia), avec le bloc **Saisir la référence** de la maquette : référence + code d'accès. **Aucun scanner caméra** pour les clients : ils scannent le QR avec l'appareil photo de leur téléphone (le QR ouvre la page), ou saisissent la référence et le code.
- Affiche : titre, référence, date, maître d'œuvre, maître d'ouvrage, concepteur, échelle, indice, **aperçu du plan**, boutons **Télécharger** (plan, fiche/certificat PDF).
- Renforcements par rapport à V2 : données réelles (fonction serveur `plan_public_get`), code d'accès obligatoire (une référence « EXB-2026-002 » devinée ne donne rien), faille corrigée (V2 insérait la référence de l'adresse telle quelle dans le HTML : injection possible), adresses de fichiers contrôlées, page non indexée par les moteurs de recherche, mode démo seulement avec `?demo=1` (code DEMO).
- QR imprimé : `https://<votre-site>/plan?ref=EXB-2026-001&k=A1B2C3D4E5` (référence + code ; jamais le PDF).

## Dans le logiciel central : 🗂 Plans & fichiers CAO
- Bouton **🌐** sur chaque plan PDF ou image : titre du projet, type de document, maître d'œuvre, maître d'ouvrage, concepteur, échelle, indice + fiche PDF facultative → **Publier**.
- Le serveur attribue la **référence EXB-AAAA-NNN** et le **code d'accès**. Le logiciel crée l'aperçu (1re page du PDF), envoie les fichiers, puis affiche le **QR**, le lien, **⬇ QR (PNG)**, **🖨 Imprimer le QR** (avec référence et code), **💬 WhatsApp**.
- Republier le même plan = même référence et même code : **le QR déjà imprimé reste valable**.
- **🌐 Plans publiés aux clients** : liste, QR/lien, **Retirer** (le plan n'est plus consultable et les fichiers publics sont supprimés).
- Mise en page / cartouche : inchangées. Placez le QR (PNG) dans votre mise en page du plan avant l'export PDF.

## Dans le scanner (APK V1.4) : lien « Plans — portail clients » ajouté. Voir le LISEZ-MOI du scanner.

## À faire (dans l'ordre)
1. Supabase › SQL Editor : exécuter `supabase/migration-v129-plans-publics.sql` (une fois ; après v66, v99zn, v99zo, v99zw).
2. Redéployer `site` sur Netlify (la route `/plan` est dans `_redirects`).
3. Logiciel connecté (☁️) → Plans & fichiers CAO → 🌐 sur un plan PDF.
- Limite : 100 Mo par fichier (compte Supabase gratuit : 50 Mo ; plans plus lourds = passer au plan payant ou compresser le PDF).
- Sécurité : toute personne qui a le QR (donc le code) peut télécharger le plan ; le retrait coupe l'accès. Un client qui transmet le QR transmet l'accès.

## Vérifié
`node tools/check.js` : 543 contrôles, 0 échec. Tests navigateur (Playwright, serveur simulé) : `tools/e2e-plan-public.py` (15 contrôles : QR, saisie manuelle, mauvais code, injection, démo, mobile 390 px, téléchargement) et `tools/e2e-plans-publier.py` (15 contrôles : bouton 🌐, envoi, aperçu, QR, republication, liste, retrait).
**Non testé** : le script SQL (pas de base Postgres ici : relisez les messages à l'exécution), l'envoi réel vers votre Supabase, un vrai PDF de grand format, le téléphone.
