/* Excellencia Building V130 — export Word (.docx) de l'éditeur de texte, sans bibliothèque externe (fonctionne hors connexion).
 * window.EXBDocx.build(feuille, { name, tagline, fmt, ori }) → Blob .docx : titres, paragraphes, gras/italique/souligné/barré/indice/exposant,
 * couleur, surlignage, taille, police, alignement, interligne, retraits, listes à puces/numérotées à niveaux, tableaux, images, sauts de page,
 * bandeaux colorés (trame de fond), en-tête de la société et numéro de page.
 * Non repris : texte autour des images (l'image est placée en ligne), cellules fusionnées. */
(function (w, d) {
  'use strict';
  var PAGES = { A4: [11906, 16838], A3: [16838, 23811], A5: [8392, 11906], Letter: [12240, 15840], Legal: [12240, 20160] };
  function x(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ''); }
  function hex(c) {
    var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(c || ''); if (!m || (m[4] !== undefined && +m[4] === 0)) return '';
    return [m[1], m[2], m[3]].map(function (n) { return ('0' + (+n).toString(16)).slice(-2); }).join('').toUpperCase();
  }
  function lum(h) { var r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16); return 0.299 * r + 0.587 * g + 0.114 * b; }

  /* ---------- zip « stocké » ---------- */
  var CRC = (function () { var t = [], c, n, k; for (n = 0; n < 256; n++) { c = n; for (k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u) { var c = 0xFFFFFFFF; for (var i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zip(files) {
    var enc = new TextEncoder(), parts = [], cen = [], off = 0;
    function u16(v) { return [v & 255, (v >>> 8) & 255]; } function u32(v) { return [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]; }
    files.forEach(function (f) {
      var nm = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data, crc = crc32(data);
      var lh = new Uint8Array([0x50, 0x4b, 3, 4].concat(u16(20), u16(0x0800), u16(0), u16(0), u16(0x21), u32(crc), u32(data.length), u32(data.length), u16(nm.length), u16(0)));
      parts.push(lh, nm, data);
      cen.push(new Uint8Array([0x50, 0x4b, 1, 2].concat(u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0x21), u32(crc), u32(data.length), u32(data.length), u16(nm.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(off))), nm);
      off += lh.length + nm.length + data.length;
    });
    var cs = 0; cen.forEach(function (c) { cs += c.length; });
    var end = new Uint8Array([0x50, 0x4b, 5, 6].concat(u16(0), u16(0), u16(files.length), u16(files.length), u32(cs), u32(off), u16(0)));
    return new Blob(parts.concat(cen, [end]), { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  }

  /* ---------- corps du document ---------- */
  function build(root, o) {
    o = o || {};
    var media = [], nums = [], rels = [], rid = 1, bodyXml = '';
    function runProps(el, inheritBlock) {
      var cs = w.getComputedStyle(el), p = '';
      var f = String(cs.fontFamily || '').split(',')[0].replace(/["']/g, '').trim();
      if (f) p += '<w:rFonts w:ascii="' + x(f) + '" w:hAnsi="' + x(f) + '" w:cs="' + x(f) + '"/>';
      if (+cs.fontWeight >= 600 || cs.fontWeight === 'bold') p += '<w:b/>';
      if (cs.fontStyle === 'italic') p += '<w:i/>';
      var td = cs.textDecorationLine || cs.textDecoration || '';
      if (/line-through/.test(td)) p += '<w:strike/>';
      var c = hex(cs.color); if (c && c !== '111111') p += '<w:color w:val="' + c + '"/>';
      var px = parseFloat(cs.fontSize); if (px) p += '<w:sz w:val="' + Math.round(px * 1.5) + '"/>';
      var hl = !inheritBlock && hex(cs.backgroundColor); if (hl) p += '<w:shd w:val="clear" w:color="auto" w:fill="' + hl + '"/>';
      if (/underline/.test(td) || el.tagName === 'A') p += '<w:u w:val="single"/>';
      if (cs.verticalAlign === 'sub' || el.tagName === 'SUB') p += '<w:vertAlign w:val="subscript"/>';
      if (cs.verticalAlign === 'super' || el.tagName === 'SUP') p += '<w:vertAlign w:val="superscript"/>';
      return p ? '<w:rPr>' + p + '</w:rPr>' : '';
    }
    function imgXml(im) {
      try {
        var nw = im.naturalWidth || 300, nh = im.naturalHeight || 200, cv = d.createElement('canvas'); cv.width = nw; cv.height = nh;
        cv.getContext('2d').drawImage(im, 0, 0); var b64 = cv.toDataURL('image/png').split(',')[1], bin = atob(b64), u = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        var pct = parseInt(im.getAttribute('data-w') || (im.style && im.style.width) || '60', 10) || 60, cx = Math.round(5760000 * Math.min(100, pct) / 100), cy = Math.round(cx * nh / nw);
        var n = media.length + 1, id = 'rIdM' + n; media.push({ name: 'word/media/image' + n + '.png', data: u, id: id });
        return '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' + cx + '" cy="' + cy + '"/><wp:docPr id="' + n + '" name="Image ' + n + '"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="' + n + '" name="image' + n + '.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="' + id + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>';
      } catch (e) { return ''; }
    }
    function runs(el, blockBg) {
      var out = '';
      (function walk(n) {
        if (n.nodeType === 3) { var t = String(n.nodeValue).replace(/\u00a0/g, ' ').replace(/[\r\n]+/g, ' '); if (t) out += '<w:r>' + runProps(n.parentNode, blockBg) + '<w:t xml:space="preserve">' + x(t) + '</w:t></w:r>'; return; }
        if (n.nodeType !== 1) return;
        if (n.tagName === 'BR') { out += '<w:r><w:br/></w:r>'; return; }
        if (n.tagName === 'IMG') { out += imgXml(n); return; }
        if (n.tagName === 'UL' || n.tagName === 'OL' || n.tagName === 'TABLE') return;
        for (var c = n.firstChild; c; c = c.nextSibling) walk(c);
      })(el);
      return out;
    }
    function pPr(el, extra) {
      var cs = w.getComputedStyle(el), p = extra || '', bg = el.getAttribute && el.getAttribute('data-bg'), ta = cs.textAlign;
      var ind = parseInt(el.getAttribute('data-ind') || '0', 10);
      var lh = parseFloat(el.style && el.style.lineHeight) || 1.5;
      p += '<w:spacing w:before="0" w:after="120" w:line="' + Math.round(lh * 240) + '" w:lineRule="auto"/>';
      if (ind > 0) p += '<w:ind w:left="' + (ind * 567) + '"/>';
      if (bg && /^#[0-9a-f]{6}$/i.test(bg)) p += '<w:shd w:val="clear" w:color="auto" w:fill="' + bg.slice(1).toUpperCase() + '"/>';
      var jc = { center: 'center', right: 'right', end: 'right', justify: 'both' }[ta]; if (jc) p += '<w:jc w:val="' + jc + '"/>';
      return '<w:pPr>' + p + '</w:pPr>';
    }
    function para(el, style, numXml) {
      var bg = !!el.getAttribute('data-bg'), st = style ? '<w:pStyle w:val="' + style + '"/>' : '';
      return '<w:p>' + pPr(el, st + (numXml || '')) + runs(el, bg) + '</w:p>';
    }
    function list(n, lvl, numId) {
      var xml = '', tg = n.tagName;
      if (numId == null) { if (tg === 'UL') numId = 1; else { nums.push(1); numId = 10 + nums.length; } }
      [].forEach.call(n.children, function (li) {
        if (li.tagName === 'UL' || li.tagName === 'OL') { xml += list(li, lvl + 1, li.tagName === 'UL' ? 1 : (nums.push(1), 10 + nums.length)); return; }
        if (li.tagName !== 'LI') return;
        xml += para(li, 'ListParagraph', '<w:numPr><w:ilvl w:val="' + Math.min(lvl, 8) + '"/><w:numId w:val="' + numId + '"/></w:numPr>');
        [].forEach.call(li.children, function (c) { if (c.tagName === 'UL' || c.tagName === 'OL') xml += list(c, lvl + 1, c.tagName === 'UL' ? 1 : (nums.push(1), 10 + nums.length)); });
      });
      return xml;
    }
    function table(t) {
      var rows = [].slice.call(t.querySelectorAll('tr')); if (!rows.length) return '';
      var n = Math.max.apply(null, rows.map(function (r) { return r.children.length; })) || 1, cw = Math.floor(9500 / n);
      var bd = ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(function (s) { return '<w:' + s + ' w:val="single" w:sz="4" w:space="0" w:color="777777"/>'; }).join('');
      return '<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>' + bd + '</w:tblBorders><w:tblCellMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>' + new Array(n + 1).join('<w:gridCol w:w="' + cw + '"/>') + '</w:tblGrid>' +
        rows.map(function (r) {
          return '<w:tr>' + [].map.call(r.children, function (c) {
            var th = c.tagName === 'TH', inner = runs(c, th).replace(/<w:rPr>/g, th ? '<w:rPr><w:b/>' : '<w:rPr>');
            return '<w:tc><w:tcPr><w:tcW w:w="' + cw + '" w:type="dxa"/>' + (th ? '<w:shd w:val="clear" w:color="auto" w:fill="E8EDF5"/>' : '') + '</w:tcPr><w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>' + inner + '</w:p></w:tc>';
          }).join('') + '</w:tr>';
        }).join('') + '</w:tbl><w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr></w:p>';
    }
    function block(n) {
      if (n.nodeType === 3) { var t = String(n.nodeValue).trim(); return t ? '<w:p><w:r><w:t xml:space="preserve">' + x(t) + '</w:t></w:r></w:p>' : ''; }
      if (n.nodeType !== 1) return '';
      var tg = n.tagName;
      if (n.classList && n.classList.contains('pb')) return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
      if (tg === 'HR') return '<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="8" w:space="1" w:color="C49A38"/></w:pBdr></w:pPr></w:p>';
      if (tg === 'H1' || tg === 'H2') return para(n, 'Heading1');
      if (tg === 'H3') return para(n, 'Heading2');
      if (tg === 'H4' || tg === 'H5' || tg === 'H6') return para(n, 'Heading3');
      if (tg === 'UL' || tg === 'OL') return list(n, 0);
      if (tg === 'TABLE') return table(n);
      if (tg === 'DIV') { var hb = [].some.call(n.children, function (c) { return /^(P|DIV|H\d|UL|OL|TABLE|HR)$/.test(c.tagName); }); if (hb) { var s = ''; for (var c = n.firstChild; c; c = c.nextSibling) s += block(c); return s; } }
      return para(n, '');
    }
    for (var c = root.firstChild; c; c = c.nextSibling) bodyXml += block(c);
    if (!bodyXml) bodyXml = '<w:p/>';
    var pg = PAGES[o.fmt] || PAGES.A4, land = o.ori === 'landscape', W = land ? pg[1] : pg[0], H = land ? pg[0] : pg[1];
    var sect = '<w:sectPr><w:headerReference w:type="default" r:id="rIdH1"/><w:footerReference w:type="default" r:id="rIdF1"/><w:pgSz w:w="' + W + '" w:h="' + H + '"' + (land ? ' w:orient="landscape"' : '') + '/><w:pgMar w:top="1700" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr>';
    var NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"';
    var doc = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ' + NS + '><w:body>' + bodyXml + sect + '</w:body></w:document>';
    var hdr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr ' + NS + '><w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="18" w:space="4" w:color="C49A38"/></w:pBdr><w:spacing w:after="0"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="173565"/><w:sz w:val="36"/></w:rPr><w:t xml:space="preserve">' + x(o.name || '') + '</w:t></w:r>' + (o.tagline ? '<w:r><w:rPr><w:i/><w:color w:val="5B6B86"/></w:rPr><w:t xml:space="preserve">   ' + x(o.tagline) + '</w:t></w:r>' : '') + '</w:p></w:hdr>';
    var ftr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr ' + NS + '><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="16"/><w:color w:val="666666"/></w:rPr><w:t xml:space="preserve">Page </w:t></w:r><w:r><w:rPr><w:sz w:val="16"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:rPr><w:sz w:val="16"/></w:rPr><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:rPr><w:sz w:val="16"/></w:rPr><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:rPr><w:sz w:val="16"/></w:rPr><w:t>1</w:t></w:r><w:r><w:rPr><w:sz w:val="16"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>';
    function hs(id, name, sz, col) { return '<w:style w:type="paragraph" w:styleId="' + id + '"><w:name w:val="' + name + '"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/></w:pPr><w:rPr><w:b/><w:color w:val="' + col + '"/><w:sz w:val="' + sz + '"/></w:rPr></w:style>'; }
    var styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:lang w:val="fr-FR"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="360" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
      hs('Heading1', 'heading 1', 32, '173565') + hs('Heading2', 'heading 2', 28, '173565') + hs('Heading3', 'heading 3', 24, '173565') +
      '<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/></w:style></w:styles>';
    function lvls(bul) { var s = ''; for (var i = 0; i < 9; i++) s += '<w:lvl w:ilvl="' + i + '"><w:start w:val="1"/><w:numFmt w:val="' + (bul ? 'bullet' : (i % 3 === 0 ? 'decimal' : i % 3 === 1 ? 'lowerLetter' : 'lowerRoman')) + '"/><w:lvlText w:val="' + (bul ? '•' : '%' + (i + 1) + '.') + '"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="' + (720 + i * 360) + '" w:hanging="360"/></w:pPr></w:lvl>'; return s; }
    var numbering = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>' + lvls(true) + '</w:abstractNum><w:abstractNum w:abstractNumId="2"><w:multiLevelType w:val="hybridMultilevel"/>' + lvls(false) + '</w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="1"/></w:num>' +
      nums.map(function (_, i) { return '<w:num w:numId="' + (11 + i) + '"><w:abstractNumId w:val="2"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>'; }).join('') + '</w:numbering>';
    var R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    var docRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdS" Type="' + R + '/styles" Target="styles.xml"/><Relationship Id="rIdN" Type="' + R + '/numbering" Target="numbering.xml"/><Relationship Id="rIdH1" Type="' + R + '/header" Target="header1.xml"/><Relationship Id="rIdF1" Type="' + R + '/footer" Target="footer1.xml"/>' +
      media.map(function (m) { return '<Relationship Id="' + m.id + '" Type="' + R + '/image" Target="media/' + m.name.split('/').pop() + '"/>'; }).join('') + '</Relationships>';
    var ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>';
    var rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/officeDocument" Target="word/document.xml"/></Relationships>';
    var files = [{ name: '[Content_Types].xml', data: ct }, { name: '_rels/.rels', data: rootRels }, { name: 'word/document.xml', data: doc }, { name: 'word/_rels/document.xml.rels', data: docRels }, { name: 'word/styles.xml', data: styles }, { name: 'word/numbering.xml', data: numbering }, { name: 'word/header1.xml', data: hdr }, { name: 'word/footer1.xml', data: ftr }];
    media.forEach(function (m) { files.push({ name: m.name, data: m.data }); });
    return zip(files);
  }
  w.EXBDocx = { build: build };
})(window, document);
