/* Excellencia Building V125 — « 🏛️ Pièces d'architecture » : le même hub que « Documents de chantier », côté architecture.
 * Familles : notices et mémoires, mission de maîtrise d'œuvre, autorisations, visas et réception, comptes rendus, lettres, contrats,
 * attestations, notes, CCTP/CCAP, texte libre. Même stockage (exb_pieces), même éditeur à onglets, même PDF officiel.
 * Retrait : supprimer la balise <script> de ce fichier. */
(function (w, d) {
  'use strict';
  var C = w.EXB81, H = w.EXBDCH;
  if (!C || !H || !H.addScope) return;
  H.addScope('arch', {
    title: '🏛️ Pièces d’architecture',
    intro: 'toutes les pièces écrites de l’architecte au même endroit',
    somm: false,
    cats: [
      ['ndesc', '🏛️', 'Notices et mémoires d’architecture', ['ndesc']],
      ['moe', '🧭', 'Mission de maîtrise d’œuvre', ['moe']],
      ['autor', '📑', 'Autorisations et dossiers administratifs', ['autor']],
      ['visa', '✅', 'Visa, contrôle et réception', ['visa']],
      ['cr', '🗒️', 'Comptes rendus de réunion', ['cr']],
      ['lettre', '✉️', 'Lettres et correspondance', ['lettre']],
      ['contrat', '🤝', 'Contrats et avenants', ['contrat']],
      ['attest', '🏅', 'Attestations', ['attest']],
      ['note', '📋', 'Notes, plans et méthodes', ['note']],
      ['cctp', '📐', 'CCTP et CCAP', ['cctp', 'ccap']],
      ['libre', '✍️', 'Texte libre', ['libre']]
    ]
  });
  C.addButton('exbArcDocBtn', '🏛️ Pièces d’architecture', function () { H.open('arch'); }, 'pieces');
  function place() {
    var b = d.getElementById('exbArcDocBtn'), r = d.getElementById('barch');
    if (b && r && r.parentNode === b.parentNode && r.nextSibling !== b) r.parentNode.insertBefore(b, r.nextSibling);
  }
  try { new MutationObserver(place).observe(d.documentElement, { childList: true, subtree: true }); } catch (e) {}
  d.addEventListener('DOMContentLoaded', place); place();
})(window, document);
