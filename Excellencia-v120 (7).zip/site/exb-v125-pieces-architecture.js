/* Excellencia Building V125 — Pièces écrites du côté ARCHITECTURE.
 *  - 4 nouveaux types de pièces : NOTICES ET MÉMOIRES D'ARCHITECTURE, MISSION DE MAÎTRISE D'ŒUVRE,
 *    AUTORISATIONS ET DOSSIERS ADMINISTRATIFS, VISA / CONTRÔLE / RÉCEPTION ;
 *  - lettres et comptes rendus propres à la conception.
 * Fichier chargé APRÈS exb-v122-pieces-chantier.js et AVANT exb-v81-pieces.js : il ajoute ses modèles à EXBPIE_DATA sans jamais
 * remplacer un modèle existant. Les documents sont enregistrés avec les autres pièces écrites (même stockage, même éditeur à onglets,
 * même PDF officiel bleu et or, QR de vérification, signature) ; le hub « 🏛️ Pièces d'architecture » (bas de ce fichier) les regroupe par projet.
 * Variables : {{projet}} {{client}} {{moa}} {{lieu}} {{entreprise}} {{lot}} {{objet}} {{date}} {{date_effet}} {{no}} {{societe}} {{dg}} {{ville}} {{pays}}.
 * Ces textes sont des bases courantes : à adapter au projet et à faire valider (règles d'urbanisme, sécurité, honoraires, clauses) par les personnes compétentes. */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA;
  if (!D) return;

  var HD = function (t) {
    return '# ' + t + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Architecte / maître d’œuvre : {{societe}}\nDate : {{date_effet}}\n';
  };
  var FT = '\n\nFait à {{ville}}, le {{date}}';
  var SAL = 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.';

  /* ===================== NOTICES ET MÉMOIRES D'ARCHITECTURE ===================== */
  var NDA = {
'Notice descriptive du projet': HD('NOTICE DESCRIPTIVE DU PROJET') + `
## 1. Situation et terrain
- Adresse / parcelle : {{lieu}}
- Superficie du terrain : ____ m² · Topographie : ____________
- Voiries, réseaux et accès existants : ____________
## 2. Programme
| Niveau | Fonction | Surface (m²) |
| Rez-de-chaussée | ____________ | ____ |
| Étage 1 | ____________ | ____ |
| Total | | ____ |
## 3. Parti architectural
Implantation, volumétrie, orientation et rapport avec l’environnement : ____________________
## 4. Description des ouvrages
| Ouvrage | Matériaux et mise en œuvre |
| Fondations | ____________ |
| Structure (poteaux, poutres, dalles) | ____________ |
| Maçonnerie et façades | ____________ |
| Toiture et étanchéité | ____________ |
| Menuiseries | ____________ |
| Revêtements (sols, murs, plafonds) | ____________ |
| Électricité, plomberie, ventilation | ____________ |
## 5. Accès, stationnement et espaces extérieurs
____________________` + FT,

'Note de présentation et d’intention architecturale': HD('NOTE DE PRÉSENTATION ET D’INTENTION ARCHITECTURALE') + `
## Contexte
Le maître d’ouvrage {{moa}} souhaite réaliser : {{objet}}.
## Analyse du site
- Atouts : ____________
- Contraintes (climat, sol, réglementation, voisinage) : ____________
## Intentions
- Fonctionnement et circulations : ____________
- Image et insertion dans le quartier : ____________
- Confort (lumière, ventilation naturelle, protection solaire) : ____________
## Principes constructifs et matériaux
____________________
## Enveloppe budgétaire et délais indicatifs
Coût prévisionnel : ____________ · Durée estimée des travaux : ____ mois` + FT,

'Programme architectural et fonctionnel': HD('PROGRAMME ARCHITECTURAL ET FONCTIONNEL') + `
## Objectifs du maître d’ouvrage
____________________
## Besoins et usagers
| Espace | Usage | Effectif | Surface souhaitée (m²) | Exigences particulières |
| ____________ | ____________ | ___ | ____ | ____________ |
| ____________ | ____________ | ___ | ____ | ____________ |
## Relations fonctionnelles
Proximités obligatoires et incompatibilités : ____________
## Contraintes techniques et réglementaires
____________________
## Budget et calendrier
____________________` + FT,

'Notice de sécurité incendie': HD('NOTICE DE SÉCURITÉ INCENDIE') + `
## Description du bâtiment
Usage : ____________ · Hauteur : ____ m · Niveaux : ____ · Effectif maximal : ____
## Dispositions constructives
- Résistance au feu de la structure : ____________
- Compartimentage et distances de sécurité : ____________
- Matériaux de revêtement (classement de réaction au feu) : ____________
## Évacuation
| Niveau | Nombre d’issues | Largeur cumulée (m) | Escaliers de secours |
| ____________ | ___ | ____ | ____________ |
## Moyens de secours
Extincteurs, alarme, éclairage de sécurité, désenfumage, accès des secours : ____________
## Entretien et vérifications périodiques
____________________` + FT,

'Notice d’accessibilité (personnes à mobilité réduite)': HD('NOTICE D’ACCESSIBILITÉ') + `
## Cheminements extérieurs
Pente : ____ % · Largeur : ____ m · Revêtement : ____________
## Accès et circulations intérieures
| Élément | Dimension / dispositif prévu | Conforme |
| Porte d’entrée (passage libre) | ____ m | Oui / Non |
| Couloirs (largeur) | ____ m | Oui / Non |
| Rampe ou ascenseur | ____________ | Oui / Non |
| Sanitaires accessibles | ____________ | Oui / Non |
| Stationnement réservé | ____ place(s) | Oui / Non |
## Dérogations éventuelles et mesures de compensation
____________________` + FT,

'Notice de performance environnementale et de confort': HD('NOTICE DE PERFORMANCE ENVIRONNEMENTALE') + `
## Conception passive
Orientation, protections solaires, ventilation naturelle, inertie des matériaux : ____________
## Eau
Récupération des eaux de pluie, assainissement, économie d’eau : ____________
## Énergie
Éclairage naturel et artificiel, climatisation, énergie solaire : ____________
## Matériaux
Origine locale, durabilité, entretien : ____________
## Gestion du chantier
Déchets, bruit, poussières, voisinage : ____________` + FT,

'Mémoire justificatif des principes constructifs': HD('MÉMOIRE JUSTIFICATIF DES PRINCIPES CONSTRUCTIFS') + `
## Données d’entrée
Étude de sol : ____________ · Contrainte admissible : ____ kPa · Charges d’exploitation : ____________
## Choix structurels
| Élément | Principe retenu | Justification |
| Fondations | ____________ | ____________ |
| Ossature | ____________ | ____________ |
| Planchers | ____________ | ____________ |
| Charpente et couverture | ____________ | ____________ |
## Dispositions particulières
Joints de dilatation, contreventement, protection des armatures : ____________
## Références
Normes et règles appliquées : ____________` + FT
  };

  /* ===================== MISSION DE MAÎTRISE D'ŒUVRE ===================== */
  var MOE = {
'Contrat de maîtrise d’œuvre (architecte)': `# CONTRAT DE MAÎTRISE D’ŒUVRE
Entre : **{{moa}}**, ci-après « le maître d’ouvrage »,
Et : **{{societe}}**, représentée par {{dg}}, ci-après « le maître d’œuvre ».
Projet : {{projet}} — {{lieu}}
## Article 1 — Objet
Le maître d’ouvrage confie au maître d’œuvre une mission de conception et de suivi pour : {{objet}}.
## Article 2 — Contenu de la mission
| Phase | Contenu | Cochée |
| Esquisse | Principes d’implantation et de volumétrie | [ ] |
| Avant-projet sommaire (APS) | Plans, coupes, façades, estimation | [ ] |
| Avant-projet définitif (APD) | Plans arrêtés, estimation affinée | [ ] |
| Projet / dossier d’exécution | Plans d’exécution, CCTP, bordereau | [ ] |
| Assistance à la passation des marchés | Consultation, analyse des offres | [ ] |
| Direction de l’exécution des travaux | Suivi, visas, comptes rendus | [ ] |
| Réception et décompte | Réception, levée des réserves | [ ] |
## Article 3 — Honoraires
Honoraires : ____ % du coût des travaux, soit ____ USD, payables selon l’échéancier suivant : ____________
## Article 4 — Délais
Remise des documents par phase : ____________
## Article 5 — Obligations des parties
Le maître d’ouvrage fournit les données du terrain et valide chaque phase dans un délai de ____ jours. Le maître d’œuvre respecte la réglementation et assure la confidentialité des documents.
## Article 6 — Résiliation et litiges
____________________` + FT + `
| Le maître d’ouvrage | Le maître d’œuvre |
| ____________ | ____________ |`,

'Avenant au contrat de maîtrise d’œuvre': HD('AVENANT N° ___ AU CONTRAT DE MAÎTRISE D’ŒUVRE') + `
## Objet de l’avenant
____________________
## Modifications
| Article concerné | Ancienne rédaction | Nouvelle rédaction |
| ____________ | ____________ | ____________ |
## Incidence financière et sur les délais
Honoraires : ____ USD → ____ USD · Délai : ____ jours supplémentaires
## Autres clauses
Les autres clauses du contrat initial demeurent inchangées.` + FT,

'Note d’honoraires par phase': HD('NOTE D’HONORAIRES N° {{no}}') + `
| Phase | Base | Taux | Montant (USD) |
| Esquisse | ____ | ___ % | ____ |
| APS / APD | ____ | ___ % | ____ |
| Dossier d’exécution | ____ | ___ % | ____ |
| Direction des travaux | ____ | ___ % | ____ |
| Total hors taxes | | | ____ |
Mode de règlement : ____________ · Échéance : ____________` + FT,

'Compte rendu de validation de phase (esquisse, APS, APD)': HD('COMPTE RENDU DE VALIDATION DE PHASE') + `
Phase examinée : ☐ Esquisse ☐ APS ☐ APD ☐ Projet d’exécution
## Documents présentés
- ____________________
## Observations du maître d’ouvrage
____________________
## Décisions
| Point | Décision | Responsable | Échéance |
| ____________ | Validé / À modifier | ____________ | ____________ |
## Suite
Prochaine phase et date de remise : ____________` + FT,

'Planning de mission et jalons de validation': HD('PLANNING DE MISSION ET JALONS DE VALIDATION') + `
| Phase | Début | Fin | Livrable | Validation MOA |
| Esquisse | ____ | ____ | ____________ | ____ |
| APS | ____ | ____ | ____________ | ____ |
| APD | ____ | ____ | ____________ | ____ |
| Dossier d’exécution | ____ | ____ | ____________ | ____ |
| Consultation des entreprises | ____ | ____ | ____________ | ____ |
Hypothèses et risques sur les délais : ____________` + FT,

'Bordereau de remise de documents': HD('BORDEREAU DE REMISE DE DOCUMENTS') + `
Destinataire : ____________ · Mode d’envoi : ____________
| N° | Document | Indice | Format | Exemplaires |
| 1 | ____________ | A | A1 / A3 / PDF | ___ |
| 2 | ____________ | A | A1 / A3 / PDF | ___ |
Observations : ____________` + FT + `
Accusé de réception : nom, date et signature ____________`
  };

  /* ===================== AUTORISATIONS ET DOSSIERS ADMINISTRATIFS ===================== */
  var AUT = {
'Lettre de dépôt d’une demande d’autorisation de bâtir': `Objet : Dépôt d’une demande d’autorisation de bâtir — {{projet}}
Réf. projet : {{projet}} — {{lieu}}

Madame, Monsieur,

Au nom de {{moa}}, nous avons l’honneur de déposer auprès de vos services la demande d’autorisation de bâtir relative à : {{objet}}, sur la parcelle située à {{lieu}}.

Pièces jointes :
- Formulaire de demande dûment rempli
- Titre de propriété ou attestation de droit sur le terrain
- Plan de situation et plan de masse
- Plans, coupes et façades
- Notice descriptive du projet
- Autres pièces : ____________

Nous restons à votre disposition pour toute information complémentaire.

` + SAL + FT,

'Notice de demande d’autorisation de bâtir': HD('NOTICE JOINTE À LA DEMANDE D’AUTORISATION DE BÂTIR') + `
## Terrain
Adresse : {{lieu}} · Parcelle n° : ____ · Superficie : ____ m² · Zone : ____________
## Projet
Nature des travaux : ☐ Construction neuve ☐ Extension ☐ Rénovation ☐ Changement d’usage
Surface bâtie au sol : ____ m² · Surface de plancher totale : ____ m² · Hauteur maximale : ____ m
## Respect des règles d’urbanisme
| Règle | Prescription | Projet |
| Retrait par rapport à la voie | ____ m | ____ m |
| Retrait par rapport aux limites | ____ m | ____ m |
| Emprise au sol | ___ % | ___ % |
| Hauteur | ____ m | ____ m |
## Raccordements
Eau : ____________ · Électricité : ____________ · Assainissement : ____________` + FT,

'Attestation de l’architecte': `# ATTESTATION DE L’ARCHITECTE
Je soussigné(e), {{dg}}, représentant {{societe}}, architecte chargé du projet {{projet}} situé à {{lieu}} pour le compte de {{moa}},
atteste que :
- le projet a été conçu conformément au programme arrêté avec le maître d’ouvrage ;
- les plans déposés respectent, à ma connaissance, les règles d’urbanisme et de construction applicables ;
- ____________________
La présente attestation est délivrée pour servir et valoir ce que de droit.` + FT,

'Déclaration d’ouverture de chantier': HD('DÉCLARATION D’OUVERTURE DE CHANTIER') + `
Autorisation de bâtir n° : ____________ délivrée le : ____________
Date d’ouverture du chantier : ____________ · Durée prévisionnelle : ____ mois
| Intervenant | Nom | Contact |
| Maître d’ouvrage | {{moa}} | ____________ |
| Architecte / maître d’œuvre | {{societe}} | ____________ |
| Entreprise principale | {{entreprise}} | ____________ |
| Bureau de contrôle | ____________ | ____________ |
Un panneau d’information de chantier est affiché : ☐ Oui ☐ Non` + FT,

'Déclaration d’achèvement des travaux': HD('DÉCLARATION D’ACHÈVEMENT DES TRAVAUX') + `
Autorisation de bâtir n° : ____________
Les travaux relatifs à {{objet}} ont été achevés le : ____________
☐ Totalité des travaux ☐ Tranche : ____________
Les travaux sont conformes à l’autorisation : ☐ Oui ☐ Oui avec modifications mineures ☐ Non
Pièces jointes : procès-verbal de réception, plans de récolement, attestations de contrôle.` + FT,

'Demande d’avis ou d’accord (concessionnaire, voisinage, service technique)': `Objet : Demande d’avis — {{projet}}
Réf. projet : {{projet}} — {{lieu}}

Madame, Monsieur,

Dans le cadre du projet {{objet}} pour le compte de {{moa}}, nous sollicitons votre avis sur les points suivants :
- ____________________
- ____________________

Vous trouverez ci-joint les plans et documents nécessaires à votre examen. Nous vous remercions de nous faire part de votre réponse avant le : ____________.

` + SAL + FT
  };

  /* ===================== VISA, CONTRÔLE ET RÉCEPTION ===================== */
  var VIS = {
'Visa de plans d’exécution': HD('VISA DE PLANS D’EXÉCUTION N° {{no}}') + `
Entreprise : {{entreprise}} · Lot : {{lot}}
| Plan / document | Indice | Date | Avis |
| ____________ | ___ | ____ | ☐ Bon pour exécution ☐ Observations ☐ Refusé |
| ____________ | ___ | ____ | ☐ Bon pour exécution ☐ Observations ☐ Refusé |
## Observations
____________________
Le visa ne dégage pas l’entreprise de sa responsabilité sur l’exactitude des cotes et la conformité de l’exécution.` + FT,

'Fiche d’observations sur documents soumis': HD('FICHE D’OBSERVATIONS N° {{no}}') + `
Document examiné : ____________ · Indice : ___ · Émetteur : ____________
| N° | Observation | Gravité | Réponse attendue avant |
| 1 | ____________ | Majeure / Mineure | ____ |
| 2 | ____________ | Majeure / Mineure | ____ |
Avis général : ☐ Accepté ☐ Accepté avec observations ☐ À reprendre` + FT,

'Approbation de matériaux et d’échantillons': HD('APPROBATION DE MATÉRIAUX ET D’ÉCHANTILLONS') + `
Entreprise : {{entreprise}} · Lot : {{lot}}
| Matériau | Marque / référence | Fournisseur | Conformité au CCTP | Décision |
| ____________ | ____________ | ____________ | Oui / Non | Approuvé / Refusé |
## Remarques et conditions de mise en œuvre
____________________` + FT,

'Rapport de visite de l’architecte': HD('RAPPORT DE VISITE DE CHANTIER') + `
Date et heure : ____________ · Présents : ____________
## Avancement constaté
| Lot | Avancement (%) | Observation |
| ____________ | ___ | ____________ |
## Conformité aux plans et au CCTP
| Point contrôlé | Conforme | Observation |
| ____________ | Oui / Non | ____________ |
## Instructions données à l’entreprise
- ____________________
## Prochaine visite
____________` + FT,

'Liste des réserves à la réception': HD('LISTE DES RÉSERVES — OPÉRATIONS PRÉALABLES À LA RÉCEPTION') + `
| N° | Localisation | Défaut constaté | Entreprise | Délai de levée | Levée (date) |
| 1 | ____________ | ____________ | ____________ | ____ | ____ |
| 2 | ____________ | ____________ | ____________ | ____ | ____ |
Les réserves non levées dans le délai prévu peuvent être exécutées aux frais de l’entreprise défaillante, après mise en demeure.` + FT,

'Décision de levée des réserves': HD('LEVÉE DES RÉSERVES') + `
Entreprise : {{entreprise}} · Lot : {{lot}}
Après vérification sur place le ____________, l’architecte constate que les réserves suivantes sont levées :
- ____________________
Réserves maintenues : ____________________
La réception est : ☐ Prononcée sans réserve ☐ Maintenue avec réserves` + FT
  };

  /* ===================== LETTRES ET COMPTES RENDUS DE CONCEPTION ===================== */
  var LET = {
'Transmission de plans pour approbation': `Objet : Transmission de plans pour approbation — {{projet}}
Réf. projet : {{projet}} — {{lieu}}

Madame, Monsieur,

Nous vous prions de trouver ci-joint les documents suivants relatifs à {{projet}} :
| Document | Indice | Format |
| ____________ | A | PDF / A1 |
Nous vous remercions de nous retourner vos observations ou votre approbation avant le ____________ afin de ne pas retarder la suite de la mission.

` + SAL + FT,
'Demande de pièces et de données au maître d’ouvrage': `Objet : Demande de documents pour la poursuite des études — {{projet}}
Réf. projet : {{projet}} — {{lieu}}

Madame, Monsieur,

Pour poursuivre les études, nous avons besoin des éléments suivants :
- Titre de propriété et plan cadastral du terrain
- Levé topographique et étude de sol
- Programme et budget validés
- ____________________

Nous vous remercions de nous les transmettre avant le ____________.

` + SAL + FT
  };

  var CR = {
'Compte rendu de réunion de conception': HD('COMPTE RENDU DE RÉUNION DE CONCEPTION N° {{no}}') + `
Date : ____________ · Lieu : ____________ · Objet : {{objet}}
## Présents
| Nom | Fonction | Présent / Excusé |
| ____________ | ____________ | ____ |
## Points examinés
| N° | Sujet | Décision | Responsable | Échéance |
| 1 | ____________ | ____________ | ____________ | ____ |
## Documents à produire
- ____________________
Prochaine réunion : ____________` + FT
  };

  /* ===================== FUSION SANS ÉCRASEMENT ===================== */
  var NEW_TYPES = {
    ndesc: ['NDA', 'Notice et mémoire d’architecture', '🏛️'],
    moe:   ['MOE', 'Mission de maîtrise d’œuvre', '🧭'],
    autor: ['AUT', 'Autorisation et dossier administratif', '📑'],
    visa:  ['VIS', 'Visa, contrôle et réception (architecte)', '✅']
  };
  var NEW_MODELS = { ndesc: NDA, moe: MOE, autor: AUT, visa: VIS, lettre: LET, cr: CR };

  var T = D.types || (D.types = {}), libre = T.libre;
  if (libre) delete T.libre;
  Object.keys(NEW_TYPES).forEach(function (k) { if (!T[k]) T[k] = NEW_TYPES[k]; });
  if (libre) T.libre = libre;

  D.models = D.models || {};
  Object.keys(NEW_MODELS).forEach(function (t) {
    var dst = D.models[t] || (D.models[t] = {}), src = NEW_MODELS[t];
    Object.keys(src).forEach(function (n) { if (!Object.prototype.hasOwnProperty.call(dst, n)) dst[n] = src[n]; });
  });

  /* signature du PDF : notices, autorisations, visas = Directeur Général ; contrat de maîtrise d'œuvre = les parties */
  D.sign = D.sign || {};
  if (!D.sign.ndesc) D.sign.ndesc = 'dg';
  if (!D.sign.moe) D.sign.moe = 'two';
  if (!D.sign.autor) D.sign.autor = 'dg';
  if (!D.sign.visa) D.sign.visa = 'dg';

  w.EXBPIE_V125 = { types: Object.keys(NEW_TYPES), count: Object.keys(NEW_MODELS).reduce(function (n, t) { return n + Object.keys(NEW_MODELS[t]).length; }, 0) };
})(window);
