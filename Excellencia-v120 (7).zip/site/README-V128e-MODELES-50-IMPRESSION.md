# V128e — Documents de chantier : au moins 50 modèles par onglet + impression corrigée (QR toujours en bas)

Base : V128d-PARCOURS. Aucun correctif V122b…V128d n'a été retiré : `index.html`, `sw.js` et `tools/check.js` n'ont reçu que les lignes V128e.

## 1. Impression des pièces écrites (PDF officiel)
Constat sur un PDF reçu (CR-2026-001) : bandeau d'identité en double en haut de la page 1 + 2ᵉ page blanche (en-tête et QR sans texte).
Cause : le pont documentaire ajoutait son bandeau à l'impression et la hauteur fixe de la page débordait de quelques millimètres.
Correctif (`site/exb-v81-pieces.js`) : la pièce se déclare « mise en page propre » (plus de bandeau en double) ; le pied de page avec le **QR code est fixé en bas de chaque page** (texte court ou long) ; plus de hauteur fixe à l'impression.
Mesuré dans Chromium (A4) : compte rendu court = 1 page (2 avant) ; CCTP de 11 pages : QR en bas de toutes les pages, y compris la dernière presque vide.

## 2. Au moins 50 modèles dans chaque onglet
Trois séries ajoutées (`exb-v122-modeles-a.js`, `-b.js`, `-c.js`), chargées après V122e ; elles ne remplacent jamais un modèle existant (même nom = l'ancien est gardé).
Total maintenant : **796 modèles** (V122e inclus). Par onglet : CCTP 52 lots · CCAP 50+ (un par type d'ouvrage, forfait ou prix unitaires) · lettres 60 · comptes rendus 56 · ordres de service 57 · procès-verbaux 71 · attestations 57 · contrats 57 · notes/modes opératoires 68 · rapports 63 · clauses 62 + CCAP · fiches et contrôles 83 · dossier de chantier 56 · texte libre 56.
Le hub « 📂 Documents de chantier » (placé sous « Projet 360° ») gagne un **filtre dans chaque famille**.

## Fichiers
Nouveaux : `site/exb-v122-modeles-a.js`, `-b.js`, `-c.js`.
Modifiés : `site/exb-v81-pieces.js` (impression) · `site/exb-v122-docs-chantier.js` (filtre) · `site/index.html` (3 balises) · `site/sw.js` (cache v128e + hors ligne) · `site/tools/check.js` (+2 contrôles).
Retour en arrière : retirer les 3 balises `exb-v122-modeles-*` de `index.html` et remettre `exb-v81-pieces.js` de V128d.

## Tests
`node tools/check.js` : **542 réussis, 0 échec**.
Chromium (logiciel réel) : 796 modèles ouverts et prévisualisés sans erreur ; hub, filtre, CCTP à 52 lots ; PDF A4 produit par Chromium à partir de la même page (pages comptées, pied de page contrôlé).
Non vérifié : l'enregistrement du PDF par l'application Android/Windows ou le serveur PDF, le rendu sur téléphone, un vrai projet avec des données.
Les contrats, clauses et CCAP sont des bases courantes : à faire valider par votre conseil juridique.
