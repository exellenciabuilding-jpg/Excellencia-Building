/* V122 — Validation du moteur d'analyse « type Robot » (exb-robot-analyse.js) : node validation/valider-robot.js
   Chaque référence est une solution analytique écrite ici, indépendamment du moteur (RDM, pentes-déflexions, valeurs propres
   exactes, formules EN 1990 / EN 1998-1). Le moteur de poutre continue existant de index.html sert aussi de contre-exemple. */
const R = require("../exb-robot-analyse.js");
const rows = []; let fail = 0;
function chk(id, grandeur, ref, val, tol, ou) {
  const ecart = Math.abs(ref) < 1e-12 ? Math.abs(val) : (val - ref) / ref * 100, ok = Math.abs(ecart) <= tol && isFinite(val);
  if (!ok) fail++; rows.push({ id, grandeur, ref, val, ecart, tol, ok, ou });
}
const E = 30e6, A = .125, I = .125 * .5 ** 3 / 12, EI = E * I;
const mk = (nodes, members, supports) => R.frame({ nodes, members: members.map(m => ({ E, A, I, ...m })), supports });
const spec = (c) => [{ c, f: 1 }];
const ext = (d, k) => ({ M: d.M, V: d.V, v: d.v, N: d.N });

/* ===== R1. Poutre sur deux appuis, charge répartie ===== */
(() => {
  const L = 6, w = 20, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] }), d = R.effortsBarre(fr, 0, spec(c), 20);
  const im = d.M.indexOf(Math.max(...d.M)), iv = d.v.indexOf(Math.min(...d.v));
  chk("R1", "poutre isostatique : M max = wL²/8 (kN.m)", w * L * L / 8, Math.max(...d.M), .01, "RDM");
  chk("R1", "poutre isostatique : V appui = wL/2 (kN)", w * L / 2, d.V[0], .01, "RDM");
  chk("R1", "poutre isostatique : flèche = 5wL⁴/384EI (m)", -5 * w * L ** 4 / (384 * EI), Math.min(...d.v), .05, "RDM");
  chk("R1", "poutre isostatique : réaction A (kN)", w * L / 2, c.R[1], .01, "RDM"); chk("R1", "poutre isostatique : réaction B (kN)", w * L / 2, c.R[4], .01, "RDM");
})();

/* ===== R2. Poutre bi-encastrée et poutre console ===== */
(() => {
  const L = 5, w = 12, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] }), d = R.effortsBarre(fr, 0, spec(c), 20);
  chk("R2", "bi-encastrée : M appui = −wL²/12 (kN.m)", -w * L * L / 12, d.M[0], .01, "RDM");
  chk("R2", "bi-encastrée : M travée = wL²/24 (kN.m)", w * L * L / 24, Math.max(...d.M), .01, "RDM");
  const P = 40, fc = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }]), cc = fc.solveCase({ nodes: [{ n: 1, fy: -P }] }), dc = R.effortsBarre(fc, 0, spec(cc), 20);
  chk("R2", "console : flèche en tête = PL³/3EI (m)", -P * L ** 3 / (3 * EI), cc.u[4], .01, "RDM");
  chk("R2", "console : M d'encastrement = −PL (kN.m)", -P * L, dc.M[0], .01, "RDM");
  chk("R2", "console : flèche de la barre (double intégration) en tête (m)", -P * L ** 3 / (3 * EI), dc.v[dc.v.length - 1], .1, "RDM");
  /* charge ponctuelle à mi-portée d'une poutre bi-appuyée : M = PL/4, flèche PL³/48EI, tranchants ±P/2 de part et d'autre */
  const fp = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }]), cp = fp.solveCase({ members: [{ m: 0, type: "point", dir: "Y", P: -P, a: L / 2 }] }), dp = R.effortsBarre(fp, 0, spec(cp), 20);
  chk("R2", "charge centrée : M max = PL/4 (kN.m)", P * L / 4, Math.max(...dp.M), .01, "RDM");
  chk("R2", "charge centrée : flèche = PL³/48EI (m)", -P * L ** 3 / (48 * EI), Math.min(...dp.v), .1, "RDM");
  const i0 = dp.x.findIndex(x => Math.abs(x - L / 2) < 1e-9);
  chk("R2", "charge centrée : saut de V au point d'application = P (kN)", P, dp.V[i0] - dp.V[i0 + 1], .01, "RDM");
})();

/* ===== R3. Poutre continue à 3 appuis : comparaison avec le moteur existant de index.html (méthode des rotations) ===== */
(() => {
  const L = 5, w = 25, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }, { x: 2 * L, y: 0 }], [{ i: 0, j: 1 }, { i: 1, j: 2 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }, { n: 2, uy: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }, { m: 1, type: "dist", dir: "Y", q1: -w }] });
  const d0 = R.effortsBarre(fr, 0, spec(c), 16), d1 = R.effortsBarre(fr, 1, spec(c), 16);
  chk("R3", "continue 2 travées : M sur appui central = −wL²/8 (kN.m)", -w * L * L / 8, d0.M[d0.M.length - 1], .01, "RDM");
  chk("R3", "continue 2 travées : continuité du moment sur l'appui (kN.m)", d0.M[d0.M.length - 1], d1.M[0], .01, "RDM");
  chk("R3", "continue 2 travées : réaction centrale = 5wL/4 (kN)", 5 * w * L / 4, c.R[4], .01, "RDM");
  chk("R3", "continue 2 travées : M max en travée = 9wL²/128 (kN.m)", 9 * w * L * L / 128, Math.max(...d0.M), .05, "RDM");
  try {
    const H = require("./harness.js"), sol = H.get("solve"), res = sol([L, L], [[{ t: "u", w }], [{ t: "u", w }]]);
    chk("R3", "moteur existant (index.html) : M appui central identique (kN.m)", Math.min(...res.M[0]), d0.M[d0.M.length - 1], .05, "contre-exemple");
    chk("R3", "moteur existant (index.html) : réaction centrale identique (kN)", res.R[1], c.R[4], .05, "contre-exemple");
  } catch (e) { fail++; rows.push({ id: "R3", grandeur: "chargement du moteur existant : " + e.message, ref: 1, val: 0, ecart: 100, tol: 0, ok: false, ou: "" }); }
})();

/* ===== R4. Articulation (relâchement) : poutre encastrée-appuyée ===== */
(() => {
  const L = 6, w = 18;
  const fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1, relJ: true }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] }), d = R.effortsBarre(fr, 0, spec(c), 20);
  chk("R4", "relâchement en j : M d'encastrement = −wL²/8 (kN.m)", -w * L * L / 8, d.M[0], .01, "RDM");
  chk("R4", "relâchement en j : réaction d'appui = 3wL/8 (kN)", 3 * w * L / 8, c.R[4], .01, "RDM");
  chk("R4", "relâchement en j : M en j nul (kN.m)", 0, d.M[d.M.length - 1], .01, "RDM");
  /* même résultat avec un appui sans rotation bloquée et une articulation de barre à l'extrémité libre */
  const fr2 = mk([{ x: 0, y: 0 }, { x: L, y: 0 }, { x: 2 * L, y: 0 }], [{ i: 0, j: 1 }, { i: 1, j: 2, relI: true }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, uy: true }, { n: 2, uy: true }]);
  const c2 = fr2.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }, { m: 1, type: "dist", dir: "Y", q1: -w }] }), e1 = R.effortsBarre(fr2, 1, spec(c2), 20);
  chk("R4", "articulation à l'appui central : M en i de la 2e barre nul (kN.m)", 0, e1.M[0], .01, "RDM");
})();

/* ===== R5. Tassement d'appui et appui élastique ===== */
(() => {
  const L = 4, dl = .01;
  const fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true, dy: -dl }]);
  const c = fr.solveCase({}), d = R.effortsBarre(fr, 0, spec(c), 20);
  chk("R5", "bi-encastrée, tassement δ : |M| d'extrémité = 6EIδ/L² (kN.m)", 6 * EI * dl / L ** 2, Math.abs(d.M[0]), .01, "RDM");
  chk("R5", "bi-encastrée, tassement δ : |V| = 12EIδ/L³ (kN)", 12 * EI * dl / L ** 3, Math.abs(d.V[0]), .01, "RDM");
  const w = 15, k = 50000, fs = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: k }]);
  const cs = fs.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] });
  /* poutre sur appui rotulé (gauche) et ressort k (droite) : mécanisme corps rigide + flexion — ici l'appui gauche bloque ux et uy, le ressort reprend le reste ? (stable car rotation libre + ressort) */
  const Rr = cs.R[4], ur = cs.u[4];
  chk("R5", "ressort k : équilibre des moments → réaction = wL/2 (kN)", w * L / 2, Rr, .01, "RDM");
  chk("R5", "ressort k : déplacement = R/k (m)", -(w * L / 2) / k, ur, .01, "RDM");
})();

/* ===== R6. Portique à nœuds déplaçables : pentes-déflexions (poteaux encastrés, traverse à axe rigide) ===== */
(() => {
  const h = 4, L = 6, H = 50, Ic = I, Ib = 2 * I, Ar = 1e3;
  const fr = R.frame({ nodes: [{ x: 0, y: 0 }, { x: 0, y: h }, { x: L, y: h }, { x: L, y: 0 }], members: [{ i: 0, j: 1, E, A: Ar, I: Ic }, { i: 1, j: 2, E, A: Ar, I: Ib }, { i: 3, j: 2, E, A: Ar, I: Ic }],
    supports: [{ n: 0, ux: true, uy: true, rz: true }, { n: 3, ux: true, uy: true, rz: true }] });
  const c = fr.solveCase({ nodes: [{ n: 1, fx: H }] });
  /* pentes-déflexions : rotation θ identique aux 2 nœuds supérieurs, translation Δ de la traverse (axe rigide) ;
     nœud : (4EIc/h + 6EIb/L)·θ − (6EIc/h²)·Δ = 0 ; équilibre horizontal : 2·(6EIc/h²·θ − 12EIc/h³·Δ)·(−1) = −H  → V_col = (6EIc/h²)θ − (12EIc/h³)Δ  */
  const kn = 4 * E * Ic / h + 6 * E * Ib / L, th = (6 * E * Ic / h ** 2) / kn;          /* θ = (6EIc/h²)/kn · Δ */
  const kV = 12 * E * Ic / h ** 3 - (6 * E * Ic / h ** 2) * th;                          /* rigidité de sway d'un poteau */
  const Dsway = H / (2 * kV);
  chk("R6", "portique : déplacement horizontal de la traverse (pentes-déflexions) (m)", Dsway, c.u[3], .5, "pentes-déflexions");
  chk("R6", "portique : équilibre horizontal ΣRx = −H (kN)", -H, c.R[0] + c.R[9], .01, "équilibre");
  chk("R6", "portique : équilibre des moments autour de l'origine (résidu, kN.m)", 0, c.R[2] + c.R[11] + L * c.R[10] - H * h, .01, "équilibre");
  /* symétrie : les deux poteaux reprennent H/2 */
  chk("R6", "portique : poteau gauche reprend H/2 (kN)", -H / 2, c.R[0], 1, "symétrie");
})();

/* ===== R7. Équilibre global d'un portique quelconque (barre inclinée, charges mixtes, articulation, température) ===== */
(() => {
  const nodes = [{ x: 0, y: 0 }, { x: 0, y: 3 }, { x: 4, y: 5 }, { x: 8, y: 3 }, { x: 8, y: 0 }];
  const fr = R.frame({ nodes, members: [{ i: 0, j: 1, E, A, I }, { i: 1, j: 2, E, A, I }, { i: 2, j: 3, E, A, I, relJ: true }, { i: 3, j: 4, E, A, I }],
    supports: [{ n: 0, ux: true, uy: true, rz: true }, { n: 4, ux: true, uy: true }] });
  const loads = { nodes: [{ n: 2, fx: 10, fy: -15, m: 5 }], members: [{ m: 1, type: "dist", dir: "Y", q1: -12, proj: true }, { m: 2, type: "dist", dir: "L", q1: -8, q2: -3, a: .5, b: 3.5 }, { m: 0, type: "point", dir: "X", P: 20, a: 1.2 }, { m: 3, type: "temp", dT: 20 }] };
  const c = fr.solveCase(loads);
  /* équilibre de chaque nœud : Σ (efforts d'extrémité des barres, repère global) = charge nodale appliquée */
  const nr = Array.from({ length: 5 }, () => [0, 0, 0]);
  fr.geo.forEach((g, k) => {
    const e = c.fe[k], mm = fr.model.members[k], cs = g.c, sn = g.s;
    const gl = [cs * e[0] - sn * e[1], sn * e[0] + cs * e[1], e[2], cs * e[3] - sn * e[4], sn * e[3] + cs * e[4], e[5]];
    for (let q = 0; q < 3; q++) { nr[mm.i][q] += gl[q]; nr[mm.j][q] += gl[3 + q]; }
  });
  const P = [[0, 0, 0], [0, 0, 0], [10, -15, 5], [0, 0, 0], [0, 0, 0]];
  let res = 0; for (const n of [1, 2, 3]) for (let q = 0; q < 3; q++) res = Math.max(res, Math.abs(nr[n][q] - P[n][q]));
  res = Math.max(res, Math.abs(nr[4][2]));
  chk("R7", "portique quelconque : résidu d'équilibre aux nœuds libres (kN, kN.m)", 0, res, 1e-5, "équilibre");
  /* équilibre global : résultante des charges (calculée à la main) + réactions = 0 */
  const g2 = fr.geo[2], f2y = -(8 + 3) / 2 * 3;                         /* charge locale y sur la barre inclinée : −16,5 kN (composante locale) */
  const Fx = 10 + 20 + f2y * (-g2.s), Fy = -15 - 12 * 4 + f2y * g2.c;
  const Rx = c.R.reduce((s, v, i) => (i % 3 === 0 ? s + v : s), 0), Ry = c.R.reduce((s, v, i) => (i % 3 === 1 ? s + v : s), 0);
  chk("R7", "portique quelconque : ΣRx = −ΣFx (kN)", -Fx, Rx, .001, "équilibre");
  chk("R7", "portique quelconque : ΣRy = −ΣFy (kN)", -Fy, Ry, .001, "équilibre");
  /* barre encastrée aux deux bouts, échauffement uniforme : N = −E·A·α·ΔT (compression) */
  const ft = mk([{ x: 0, y: 0 }, { x: 5, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true }]);
  const ct = ft.solveCase({ members: [{ m: 0, type: "temp", dT: 30 }] }), dt = R.effortsBarre(ft, 0, spec(ct), 10);
  chk("R7", "température uniforme, barre bloquée : N = −EAαΔT (kN)", -E * A * 1e-5 * 30, dt.N[0], .01, "RDM");
})();

/* ===== R8. Combinaisons EN 1990 / BAEL ===== */
(() => {
  const act = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }];
  const cb = R.combinaisons(act, {}), ex = id => cb.find(c => c.id === id);
  chk("R8", "G + Q (cat. B) : nombre de combinaisons ELU (1,35G+1,5Q ; 1,0G+1,5Q)", 2, cb.filter(c => c.famille === "ELU").length, 0, "EN 1990");
  chk("R8", "ELU : 1,35 G + 1,5 Q → facteur de Q", 1.5, ex("ELU 1").f.Q, 0, "EN 1990 6.10");
  chk("R8", "ELS caractéristique : G + Q → facteur de Q", 1, cb.find(c => c.famille === "ELS-CAR").f.Q, 0, "EN 1990 6.14");
  chk("R8", "ELS fréquente : ψ1 = 0,5 (cat. B)", .5, cb.find(c => c.famille === "ELS-FREQ").f.Q, 0, "EN 1990 6.15");
  chk("R8", "ELS quasi-permanente : ψ2 = 0,3 (cat. B)", .3, cb.find(c => c.famille === "ELS-QP").f.Q, 0, "EN 1990 6.16");
  const act2 = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }, { n: "W+", type: "W", group: "W" }, { n: "W-", type: "W", group: "W" }, { n: "S", type: "S" }];
  const c2 = R.combinaisons(act2, {});
  chk("R8", "W+ et W− (même groupe) jamais combinés ensemble (1 = oui)", 1, c2.some(c => c.f["W+"] && c.f["W-"]) ? 0 : 1, 0, "groupe exclusif");
  const q1 = c2.find(c => c.famille === "ELU" && c.f.Q === 1.5 && c.f["W+"] > 0);
  chk("R8", "Q dominante : ψ0,W = 0,6 → 1,5 × 0,6 = 0,9", .9, q1.f["W+"], 1e-9, "EN 1990 6.10");
  const w1 = c2.find(c => c.famille === "ELU" && c.f["W+"] === 1.5 && c.f.G === 1.35);
  chk("R8", "W dominant : ψ0,Q = 0,7 → 1,5 × 0,7 = 1,05 (Q d'accompagnement)", 1.05, w1.f.Q, 1e-9, "EN 1990 6.10");
  const b1 = R.combinaisons([{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }, { n: "W", type: "W" }], { norme: "BAEL" }).find(c => c.famille === "ELU" && c.f.Q === 1.5 && c.f.W);
  chk("R8", "BAEL : 1,35G + 1,5Q + 1,3·ψ0·W (ψ0 = 0,6) → 0,78", .78, b1.f.W, 1e-9, "BAEL A.3.3,21");
  const ab = R.combinaisons(act, { sixab: true }).filter(c => c.tag);
  chk("R8", "6.10a et 6.10b générées (1 = oui)", 1, ab.some(c => c.tag === "6.10a") && ab.some(c => c.tag === "6.10b") ? 1 : 0, 0, "EN 1990 6.10a/b");
  const ac = R.combinaisons([{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }, { n: "A", type: "A" }], {}).find(c => c.famille === "ACC");
  chk("R8", "accidentelle : G + A + ψ1,1·Q (0,5)", .5, ac.f.Q, 0, "EN 1990 6.11b");
  const sm = R.combinaisons([{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "A" }, { n: "Ex", type: "E", dir: "x" }, { n: "Ey", type: "E", dir: "y" }], {}).filter(c => c.famille === "SISM");
  chk("R8", "séisme : 8 combinaisons ±Ex ± 0,3 Ey et ±0,3 Ex ± Ey (+ directions pures)", 1, sm.some(c => Math.abs(c.f.Ex) === 1 && Math.abs(Math.abs(c.f.Ey) - .3) < 1e-9) && sm.some(c => Math.abs(c.f.Ey) === 1 && Math.abs(Math.abs(c.f.Ex) - .3) < 1e-9) ? 1 : 0, 0, "EN 1998-1 4.3.3.5.1");
  chk("R8", "séisme : ψ2 appliqué à Q (0,3 en cat. A)", .3, sm[0].f.Q, 1e-9, "EN 1998-1 3.2.4");
})();

/* ===== R9. Enveloppes de combinaisons ===== */
(() => {
  const L = 5, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }, { x: 2 * L, y: 0 }], [{ i: 0, j: 1 }, { i: 1, j: 2 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }, { n: 2, uy: true }]);
  const g = 15, q = 10, cases = {
    G: fr.solveCase({ members: [0, 1].map(m => ({ m, type: "dist", dir: "Y", q1: -g })) }),
    Q1: fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -q }] }), Q2: fr.solveCase({ members: [{ m: 1, type: "dist", dir: "Y", q1: -q }] })
  };
  const cbs = [{ id: "a", f: { G: 1.35, Q1: 1.5 } }, { id: "b", f: { G: 1.35, Q2: 1.5 } }, { id: "c", f: { G: 1.35, Q1: 1.5, Q2: 1.5 } }, { id: "d", f: { G: 1 } }];
  const env = R.enveloppe(fr, cases, cbs, 20), e0 = env.barres[0];
  /* appui central : chargement des deux travées → M = −(1,35·15 + 1,5·10)·L²/8 */
  chk("R9", "enveloppe : M appui central min = −(1,35g+1,5q)·L²/8 (kN.m)", -(1.35 * g + 1.5 * q) * L * L / 8, Math.min(...e0.Mmin), .01, "RDM");
  chk("R9", "enveloppe : combinaison dominante sur appui = c (1 = oui)", 1, e0.cMmin[e0.cMmin.length - 1] === "c" ? 1 : 0, 0, "enveloppe");
  chk("R9", "enveloppe : Mmax ≥ Mmin en toute abscisse (1 = oui)", 1, e0.Mmax.every((v, i) => v >= e0.Mmin[i] - 1e-9) ? 1 : 0, 0, "enveloppe");
  chk("R9", "enveloppe : réaction d'appui d'extrémité max (kN)", 1.35 * g * L * 3 / 8 + 1.5 * q * L * 7 / 16, env.R[1].max, .5, "RDM");
})();

/* ===== R10. Analyse modale ===== */
(() => {
  /* console avec masse en tête : ω = √(3EI/(m L³)) */
  const L = 3.2, m = 25;
  const fr = mk([{ x: 0, y: 0 }, { x: 0, y: L }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }]);
  const md = R.modale(fr, [{ n: 1, mx: m, my: 0 }], 3);
  chk("R10", "console + masse : ω = √(3EI/mL³) (rad/s)", Math.sqrt(3 * EI / (m * L ** 3)), md.modes[0].omega, .01, "dynamique");
  chk("R10", "console + masse : masse modale effective = 100 % (kN·s²/m)", m, md.modes[0].mex, .01, "dynamique");
  /* portique 2 étages à traverses rigides (cisaillement) : k = 12EI/h³ par poteau ; valeurs propres exactes du système 2 ddl */
  const h = 3, nc = 2, kst = nc * 12 * EI / h ** 3, m1 = 40, m2 = 30, Ar = 1e6, Ib = 1e3 * I;
  const nodes = [{ x: 0, y: 0 }, { x: 5, y: 0 }, { x: 0, y: h }, { x: 5, y: h }, { x: 0, y: 2 * h }, { x: 5, y: 2 * h }];
  const members = [{ i: 0, j: 2, E, A: 1e6, I }, { i: 1, j: 3, E, A: 1e6, I }, { i: 2, j: 4, E, A: 1e6, I }, { i: 3, j: 5, E, A: 1e6, I }, { i: 2, j: 3, E, A: Ar, I: Ib }, { i: 4, j: 5, E, A: Ar, I: Ib }];
  const f2 = R.frame({ nodes, members, supports: [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true }] });
  const mm = R.modale(f2, [{ n: 2, mx: m1 / 2, my: 0 }, { n: 3, mx: m1 / 2, my: 0 }, { n: 4, mx: m2 / 2, my: 0 }, { n: 5, mx: m2 / 2, my: 0 }], 4);
  /* K = k [[2,−1],[−1,1]], M = diag(m1,m2) : det(K − λM) = 0 */
  const a = m1 * m2, b = -(kst * (2 * m2 + m1)), c0 = kst * kst, disc = Math.sqrt(b * b - 4 * a * c0), l1 = (-b - disc) / (2 * a), l2 = (-b + disc) / (2 * a);
  chk("R10", "cisaillement 2 niveaux (poteaux axialement rigides) : ω1 (rad/s)", Math.sqrt(l1), mm.modes[0].omega, .3, "valeurs propres");
  chk("R10", "cisaillement 2 niveaux (poteaux axialement rigides) : ω2 (rad/s)", Math.sqrt(l2), mm.modes[1].omega, .3, "valeurs propres");
  chk("R10", "masses modales effectives cumulées = masse totale (%)", 100, mm.modes[mm.modes.length - 1].rx * 100, .5, "participation");
  chk("R10", "périodes croissantes (1 = oui)", 1, mm.modes.every((x, i, t) => !i || x.T <= t[i - 1].T + 1e-12) ? 1 : 0, 0, "tri");
})();

/* ===== R11. Spectre de réponse EN 1998-1 ===== */
(() => {
  const s = R.spectre({ ag: 2, type: 1, sol: "B", q: 3.9 }), S = 1.2, TB = .15, TC = .5, TD = 2;
  chk("R11", "Sd(T=0) = ag·S·2/3 (m/s²)", 2 * S * 2 / 3, s.Sd(0), .001, "EN 1998-1 (3.13)");
  chk("R11", "Sd plateau = ag·S·2,5/q (m/s²)", 2 * S * 2.5 / 3.9, s.Sd(.3), .001, "EN 1998-1 (3.14)");
  chk("R11", "Sd(T = 1 s) = ag·S·2,5/q·TC/T (m/s²)", 2 * S * 2.5 / 3.9 * TC / 1, s.Sd(1), .001, "EN 1998-1 (3.15)");
  chk("R11", "Sd plancher β·ag pour T grand (m/s²)", .2 * 2, s.Sd(4), .001, "EN 1998-1 (3.16)");
  chk("R11", "Se plateau = ag·S·η·2,5 (m/s²)", 2 * S * 2.5, s.Se(.3), .001, "EN 1998-1 (3.2)");
  chk("R11", "Se continu en TC (m/s²)", s.Se(TC - 1e-9), s.Se(TC + 1e-9), .001, "continuité");
})();

/* ===== R12. Portique complet : statique, modale, spectrale ===== */
(() => {
  const pq = R.portique({ ns: 4, nb: 3, L: 5, h: 3.2, bc: 40, hc: 40, bp: 25, hp: 50, fc: 25, G: 15, Q: 8, pp: 1 });
  const fr = pq.fr, tot = pq.cases.G.R.reduce((s, v, i) => (i % 3 === 1 ? s + v : s), 0);
  const Gtot = (15 + 25 * pq.Ap) * 5 * 3 * 4 + 25 * pq.Ac * 3.2 * 4 * 4;
  chk("R12", "portique 4×3 : ΣRy sous G = poids total (kN)", Gtot, tot, .01, "équilibre");
  const act = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }], cbs = R.combinaisons(act, {});
  const env = R.enveloppe(fr, pq.cases, cbs.filter(c => c.famille === "ELU"), 10);
  chk("R12", "enveloppe ELU : toutes les valeurs finies (1 = oui)", 1, env.barres.every(b => b.Mmax.every(isFinite) && b.Mmin.every(isFinite) && b.Vmax.every(isFinite)) ? 1 : 0, 0, "contrôle");
  /* masses : (G + 0,3 Q) par étage réparti sur les nœuds */
  const W = (15 + 25 * pq.Ap + .3 * 8) * 5 * 3 + 25 * pq.Ac * 3.2 * 4;
  const masses = []; for (let j = 1; j <= 4; j++) for (let i = 0; i <= 3; i++) masses.push({ n: pq.idx(i, j), mx: W / 9.81 * (i === 0 || i === 3 ? .5 : 1) / 3, my: 0 });
  const md = R.modale(fr, masses, 8), s = R.spectre({ ag: 1.5, type: 1, sol: "B", q: 3 }), sp = R.spectrale(fr, md, s, "x");
  chk("R12", "modale : période fondamentale cohérente avec Ct·H^0,75 (ordre de grandeur, ratio ≤ 2)", 1, md.modes[0].T / (.075 * Math.pow(12.8, .75)) < 2 && md.modes[0].T / (.075 * Math.pow(12.8, .75)) > .5 ? 1 : 0, 0, "ordre de grandeur");
  chk("R12", "spectrale : masse modale cumulée ≥ 90 % (1 = oui)", 1, sp.cumul >= .9 ? 1 : 0, 0, "EN 1998-1 4.3.3.1(3)");
  const Vb = R.combinaisonModale(sp.per.map(p => p.Vb), sp.T, 5).v, Fb = s.Sd(md.modes[0].T) * md.Mx;
  chk("R12", "effort tranchant à la base (CQC) ≤ Sd(T1)·M (borne supérieure) (1 = oui)", 1, Vb <= Fb * 1.0001 ? 1 : 0, 0, "EN 1998-1 4.3.3.2");
  chk("R12", "effort tranchant à la base = Σ réactions horizontales du mode 1 (kN)", sp.per[0].Vb, -sp.per[0].res.R.reduce((s2, v, i) => (i % 3 === 0 ? s2 + v : s2), 0), .01, "équilibre modal");
})();

/* ===== R14. Poteau en flexion composée (diagramme d'interaction) ===== */
(() => {
  const o = { b: .3, h: .3, enr: .04, fc: 25, fe: 500, acc: .85, gb: 1.5, gs: 1.15 }, fbu = .85 * 25 / 1.5 * 1000, fed = 500 / 1.15 * 1000;
  const pts = R.courbeNM(o, 12), top = pts[pts.length - 1];
  /* flexion simple (N = 0), As/2 de chaque côté : comparaison à l'équilibre de la section à la main (bloc 0,8x, acier tendu plastifié) */
  const M0 = R.momentResistant(pts, 0), A = 6e-4;
  /* référence indépendante par bisection sur x : ΣN = 0 */
  let lo = .001, hi = .3, f = xx => { const e1 = 3.5e-3 * (xx - .04) / xx, e2 = 3.5e-3 * (xx - .26) / xx, s1 = Math.max(-fed, Math.min(fed, 2e8 * e1)), s2 = Math.max(-fed, Math.min(fed, 2e8 * e2)); return fbu * .3 * .8 * xx + A * s1 + A * s2; };
  for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if (f(m) > 0) hi = m; else lo = m; }
  const xx = lo, e1 = 3.5e-3 * (xx - .04) / xx, e2 = 3.5e-3 * (xx - .26) / xx, s1 = Math.max(-fed, Math.min(fed, 2e8 * e1)), s2 = Math.max(-fed, Math.min(fed, 2e8 * e2));
  const Mref = fbu * .3 * .8 * xx * (.15 - .4 * xx) + A * s1 * (.15 - .04) + A * s2 * (.15 - .26);
  chk("R14", "flexion simple (N = 0) : M résistant du diagramme (kN.m)", Mref, M0, 1.5, "équilibre de section");
  chk("R14", "N maximal du diagramme ≈ fbu·b·h + As·σs (kN)", fbu * .09 + 12e-4 * Math.min(fed, 2e8 * 2e-3), top.N, 8, "compression pure");
  const r = R.colonneNM({ ...o, N: 600, M: 70, l0: 3 });
  chk("R14", "dimensionnement : As trouvée assure M résistant ≥ Med (1 = oui)", 1, r.ok && R.momentResistant(R.courbeNM(o, r.As), 600) >= r.Med * .999 ? 1 : 0, 0, "contrôle");
  chk("R14", "dimensionnement : As croît avec le moment (1 = oui)", 1, R.colonneNM({ ...o, N: 600, M: 100, l0: 3 }).As > r.As ? 1 : 0, 0, "contrôle");
  chk("R14", "excentricité minimale : M = 0 donne Med = N·max(h/30 ; 2 cm) (kN.m)", 600 * .02, R.colonneNM({ ...o, N: 600, M: 0, l0: 3 }).Med, .01, "EN 1992-1-1 6.1(4)");
})();

/* ===== R15. Poutre continue EF (chargements alternés, tassements) vs moteur existant et RDM ===== */
(() => {
  const H = require("./harness.js"), g = H.get;
  H.setNorme("bael");
  const st = { cont: 1, n: 4, L: "4.5; 5; 4", b: .25, h: .5, enr: 3, G: 18, Q: 10, fc: 25, fe: 500, fis: 0, pp: 1, sec: "r", sp: [{ n: "Q", s: 1, t: "p", a: 2, v: 30 }, { n: "G", s: 0, t: "u", a: 1, c: 2, v: 5 }], psi2: .3, jr: .7, phiF: 2, ecs: .4, bf: .6, h0: .12 };
  const r = g("verifier")(Object.assign({ __nv: 1 }, st)), Ls = g("spans")(st), w = 18 + 25 * .25 * .5;
  const G = Ls.map(() => w), Q = Ls.map(() => 10);
  const fe = R.poutreContinueFE({ Ls, b: .25, h: .5, fc: 25, G, Q, sp: st.sp });
  const mu = r.res.map(x => x.Mu), nT = Ls.length;
  Ls.forEach((_, i) => chk("R15", `poutre continue, travée ${i + 1} : Mu EF = moteur existant (kN.m)`, mu[i], fe.Mt[i], 1, "contre-exemple"));
  for (let j = 0; j < nT - 1; j++) chk("R15", `poutre continue, appui ${j + 2} : Mu EF = moteur existant (kN.m)`, mu[nT + j], fe.Ma[j], 1, "contre-exemple");
  /* tassement de l'appui central d'une poutre à 2 travées égales, sans charge : M = 3EIδ/L² (RDM) */
  const L = 5, d = .01, b = .3, h = .6, E = R.Ecm(25) * 1000, I = b * h ** 3 / 12;
  const t = R.poutreContinueFE({ Ls: [L, L], b, h, fc: 25, G: [0, 0], Q: [0, 0], tass: [0, 10, 0] });
  const D = t.cases.D, dd = R.effortsBarre(t.fr, 0, [{ c: D, f: 1 }], 10);
  chk("R15", "2 travées, tassement δ de l'appui central : |M| = 3EIδ/L² (kN.m)", 3 * E * I * d / (L * L), Math.abs(dd.M[dd.M.length - 1]), .5, "RDM");
  /* appui élastique : une travée sur 2 appuis dont l'un sur ressort ; réaction = wL/2 (symétrie des moments) */
  const k = R.poutreContinueFE({ Ls: [L, L], b, h, fc: 25, G: [10, 10], Q: [0, 0], ksup: [0, 1e9, 0] });
  const r0 = R.poutreContinueFE({ Ls: [L, L], b, h, fc: 25, G: [10, 10], Q: [0, 0] });
  chk("R15", "ressort très raide ≈ appui rigide : réaction centrale (kN)", r0.R[1], k.R[1], .5, "limite k → ∞");
})();

/* ===== R16. Portique extrait d'un modèle de bâtiment = portique régulier équivalent ===== */
(() => {
  const c = { b: .3, h: .3 }, xs = [0, 5, 10], z = [0, 3.2, 6.4, 9.6];
  const a = R.analyseModele({ xs, z, col: [0, 1, 2].map(() => [c, c, c]), beams: [0, 1, 2].map(k => ({ k, t0: 0, t1: 2, b: .25, h: .5, Gs: [15, 15], Qs: [8, 8] })), fc: 25, Wx: 10, seis: { on: true, ag: 1.5, sol: 2, q: 3, tsp: 1 } });
  const q = R.analysePortique({ ns: 3, nb: 2, L: 5, h: 3.2, bc: 30, hc: 30, bp: 25, hp: 50, fc: 25, G: 15, Q: 8, pp: 1, Wx: 10, ag: 1.5, sol: 2, qf: 3 });
  chk("R16", "période fondamentale identique (s)", q.T1, a.T1, .01, "équivalence");
  chk("R16", "effort tranchant sismique à la base identique (kN)", q.spc.Vb, a.seis.Vb, .01, "équivalence");
  chk("R16", "réaction verticale totale ELU identique (kN)", q.reac.reduce((s, r) => s + r.Ry, 0), a.reac.reduce((s, r) => s + r.Ry, 0), .01, "équivalence");
  chk("R16", "moment max des poutres ELU identique (kN.m)", q.ext.poutre.Mt, Math.max(...a.elements.filter(e => e.type === "p").map(e => e.Mt)), .01, "équivalence");
})();

/* ===== R13. Mécanisme détecté ===== */
(() => {
  let ok = 0;
  try { R.frame({ nodes: [{ x: 0, y: 0 }, { x: 4, y: 0 }], members: [{ i: 0, j: 1, E, A, I }], supports: [{ n: 0, ux: true, uy: true }] }); } catch (e) { ok = e.code === "MECANISME" ? 1 : 0; }
  chk("R13", "poutre à un seul appui rotulé : mécanisme détecté (1 = oui)", 1, ok, 0, "stabilité");
})();


/* ===== R17. Fondations du bâtiment (dimensionnement automatique des semelles) ===== */
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{const b=batDef();b.res=batCalc(b);const f=b.res.fond;
    const b2=batDef();b2.xs=[2,2];b2.ys=[2,2];b2.sig=.03;b2.res=batCalc(b2);
    const b3=batDef();b3.sig=.1;b3.res=batCalc(b3);
    return JSON.stringify({n:f.list.length,nb:b.res.base.length,minSol:Math.min(...f.list.map(x=>x.sig-x.smax)),stat:f.list.every(x=>x.A*x.A*x.sig*1000>=x.Ns*0.999),mult:f.list.every(x=>Math.abs(x.A*20-Math.round(x.A*20))<1e-6),pun:Math.max(...f.list.map(x=>x.pun)),ok:f.ok?1:0,
      ov2:b2.res.fond.ov.length>0?1:0,A1:f.list[0].A,A3:b3.res.fond.list[0].A,vol:f.vol,sv:f.list.reduce((t,x)=>t+x.A*x.B*x.H,0)})})()`));
  chk("R17", "une semelle par poteau au pied (nombre)", o.nb, o.n, 0, "fondations");
  chk("R17", "contrainte au sol ≤ admissible pour toutes les semelles (1 = oui)", 1, o.minSol >= -1e-9 ? 1 : 0, 0, "fondations");
  chk("R17", "aire de semelle ≥ Nser/σ pour toutes (1 = oui)", 1, o.stat ? 1 : 0, 0, "fondations");
  chk("R17", "dimensions multiples de 5 cm (1 = oui)", 1, o.mult ? 1 : 0, 0, "fondations");
  chk("R17", "poinçonnement vérifié (taux ≤ 1)", 1, o.pun <= 1 ? 1 : 0, 0, "fondations");
  chk("R17", "béton total = Σ A·B·H (m³)", o.sv, o.vol, .001, "fondations");
  chk("R17", "travées de 2 m sur sol à 0,03 MPa : chevauchement détecté (1 = oui)", 1, o.ov2, 0, "fondations");
  chk("R17", "sol plus faible (0,10 MPa) : semelle plus grande (1 = oui)", 1, o.A3 > o.A1 ? 1 : 0, 0, "fondations");
})();


/* ===== R18. Poteau rectangulaire : diagramme N–M à aciers répartis, flexion déviée, intégration au module Poteau ===== */
(() => {
  const H = require("./harness.js"), o = { a: .4, b: .4, ds: .04, fc: 25, fe: 500, acc: 1, gb: 1.5, gs: 1.15, N: 1500, Ma: 0, Mb: 0, l0a: 0, l0b: 0, ec: true };
  const hh = { b: .4, h: .4, fc: 25, fe: 500, acc: 1, gb: 1.5, gs: 1.15 }, As = 24;
  const c2 = R.courbeNMc(hh, R.nappes(.4, .04, As / 1e4, 2)), c1 = R.courbeNM({ ...hh, enr: .04 }, As);
  chk("R18", "2 nappes : même moment résistant que le moteur historique (kN.m)", R.momentResistant(c1, 1500), R.momentResistant(c2, 1500), .01, "équivalence");
  const cN = R.courbeNMc(hh, R.nappes(.4, .04, As / 1e4, 4));
  chk("R18", "effort normal résistant maximal = Ac·fcd + As·σs à 2 ‰ (kN, à 1 %)", (.16 * 25 / 1.5 + As / 1e4 * 400) * 1000, cN[cN.length - 1].N, 1, "équilibre");
  const u = R.poteauNM({ ...o, Ma: 100 }), v = R.poteauNM({ ...o, Mb: 100 }), w = R.poteauNM({ ...o, Ma: 100, Mb: 100 });
  chk("R18", "symétrie a ↔ b : même acier (cm²)", u.As, v.As, .01, "symétrie");
  chk("R18", "flexion déviée : acier ≥ flexion simple (1 = oui)", 1, w.As >= u.As ? 1 : 0, 0, "monotonie");
  const lo = R.poteauNM({ ...o, Ma: 100, As: u.AsCalc * .95, k: 4 }), hi = R.poteauNM({ ...o, Ma: 100, As: u.AsCalc * 1.02, k: 4 });
  chk("R18", "acier calculé −5 % : vérification refusée (1 = oui)", 1, u.AsCalc > u.Amin * 1.05 ? (lo.ok ? 0 : 1) : 1, 0, "dichotomie");
  chk("R18", "acier calculé +2 % : vérification acceptée (1 = oui)", 1, hi.ok ? 1 : 0, 0, "dichotomie");
  const s2 = R.poteauNM({ ...o, Ma: 100, l0a: 4.5, l0b: 4.5 });
  chk("R18", "second ordre : excentricité e2 > 0 pour λ > λlim (1 = oui)", 1, s2.E[0].e2 > 0 ? 1 : 0, 0, "second ordre");
  chk("R18", "second ordre : acier ≥ sans second ordre (1 = oui)", 1, s2.As >= u.As ? 1 : 0, 0, "monotonie");
  ["ec2", "bael"].forEach(n => {
    H.setNorme(n);
    const r = JSON.parse(H.get(`(()=>{const st={sec:"r",b:.4,h:.4,H:3.2,k:.7,pp:1,fc:25,fe:500,enr:3,L:[{t:"G",l:"G",N:700,Mx:67,My:27},{t:"Q",l:"Q",N:300,Mx:20,My:8}]},r=poteauCalc(st);return JSON.stringify({ok:r.T&&!r.D.some(d=>d.g=="erreur")?1:0,nm:r.nm?r.nm.ratio:9,des:r.nmDesign?1:0})})()`));
    chk("R18", "module Poteau (" + n + ") : forte flexion déviée dimensionnée sans erreur (1 = oui)", 1, r.ok, 0, "intégration");
    chk("R18", "module Poteau (" + n + ") : taux N–M ≤ 1 (1 = oui)", 1, r.nm <= 1 ? 1 : 0, 0, "intégration");
  });
})();


/* ===== R19. Poteau bois : flexion composée EN 1995-1-1 6.3.2 (équations 6.23 / 6.24), recalcul indépendant ===== */
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{const [nm,fmk,ft,fc,fvk,E0,E05]=BOIS[0],km=KMOD[1][2],b=150,h=200,L=3000;
    const kc=d=>{const la=L/(d/Math.sqrt(12)),lr=la/Math.PI*Math.sqrt(fc/E05),k=.5*(1+.2*(lr-.3)+lr*lr);return Math.min(1,1/(k+Math.sqrt(Math.max(k*k-lr*lr,0))))};
    const fcd=km*fc/1.3,fm=km*fmk/1.3,sg=120e3/(b*h),smy=3e6/(b*h*h/6),smz=1e6/(h*b*b/6),kh=d=>d<150?Math.min(Math.pow(150/d,.2),1.3):1;
    const u1=sg/(kc(h)*fcd)+smy/(fm*kh(h))+.7*smz/(fm*kh(b)),u2=sg/(kc(b)*fcd)+.7*smy/(fm*kh(h))+smz/(fm*kh(b));
    const r=M.bpoteau.run({b,h,cl:0,sc:1,du:2,L:3,kk:1,N:120,My:3,Mz:1}),r0=M.bpoteau.run({b,h,cl:0,sc:1,du:2,L:3,kk:1,N:120,My:0,Mz:0}),r1=M.bpoteau.run({b,h,cl:0,sc:1,du:2,L:3,kk:1,N:120,My:15,Mz:5});
    return JSON.stringify({ref:Math.max(u1,u2)*100,eng:parseFloat(r.rows[5][1]),c0:parseFloat(r0.rows[5][1]),c0ref:sg/(Math.min(kc(h),kc(b))*fcd)*100,ko:r1.msgs.some(m=>m[0]=="erreur")?1:0})})()`));
  chk("R19", "taux de travail en flexion composée My = 3 / Mz = 1 kN.m (%)", o.ref, o.eng, 1, "EC5 6.3.2");
  chk("R19", "compression centrée inchangée (%)", o.c0ref, o.c0, 1, "EC5 6.3.2");
  chk("R19", "moments excessifs : erreur signalée (1 = oui)", 1, o.ko, 0, "EC5 6.3.2");
})();


/* ===== R20. Classe 4 (EN 1993-1-5), R21. Poteau circulaire N–M, R22. Bois : appui perpendiculaire et feu ===== */
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{
    const P=PRF[9],fy=355,e=Math.sqrt(235/fy),[nm,h,b,tw,tf,r,A]=P,c=(b-tw-2*r)/2,cw=h-2*tf-2*r;
    const lw=cw/tw/(28.4*e*2),rw=lw>.673?(lw-.055*4)/(lw*lw):1,Aref=A*100-(1-rw)*cw*tw;
    const col=M.apoteau.run({pr:9,fy,L:3.5,kk:1,Lz:3.5,N:400}),cl4=col.rows[0][1].endsWith("4")?1:0;
    const thin=["X",600,200,3,12,10,65.28,0,0,0,0,0,0];thin[7]=(200*Math.pow(600,3)-(200-3)*Math.pow(600-24,3))/12/1e4;
    const ef=effFlex(thin,355),c2=(200-3-20)/2,cw2=600-24-20,e2=Math.sqrt(235/355),lf=c2/12/(28.4*e2*Math.sqrt(.43)),rf=rhoOut(lf),lw2=cw2/3/(28.4*e2*Math.sqrt(23.9)),rw2=rhoInt(lw2,-1),bc=cw2/2,be=rw2*bc;
    /* intégration par fibres de 0,25 mm */
    let Ag=0,Sg=0,Ig=0;const dy=.25;for(let y=-300+dy/2;y<300;y+=dy){let w=0;const top=y>300-12,bot=y<-300+12;
      if(top)w=200-2*(1-rf)*c2;else if(bot)w=200;else{w=3;const yt=y-(300-12-10);if(yt>0){const d=yt;/* distance sous le haut de l'âme libre, mesurée depuis la jonction */ }}
      const ytopweb=300-12-10,dd=ytopweb-y; if(!top&&!bot&&dd>=.4*be&&dd<bc-.6*be) w=0; /* zone retirée */
      Ag+=w*dy;Sg+=w*dy*y;Ig+=w*dy*y*y;}
    const yg=Sg/Ag,Icg=Ig-Ag*yg*yg,Wref=Icg/(300-yg)/1e3;
    return JSON.stringify({Aref,Aeng:effComp(P,fy).Ae,cl4,out:rhoOut(1),inn:rhoInt(1,1),Wref,Weng:ef.Weff,We:Math.min(...[1]),Iref:Icg,Ieng:ef.Icg,rfc:rf,rwc:rw2})})()`));
  chk("R20", "ρ d'un élément externe à λp = 1 (EN 1993-1-5 : 0,812)", .812, o.out, .2, "EN 1993-1-5");
  chk("R20", "ρ d'un élément interne ψ = 1 à λp = 1 (0,78)", .78, o.inn, .1, "EN 1993-1-5");
  chk("R20", "IPE 300 S355 classée 4 en compression (1 = oui)", 1, o.cl4, 0, "classification");
  chk("R20", "aire efficace IPE 300 S355 (mm²)", o.Aref, o.Aeng, .01, "Aeff");
  chk("R20", "inertie efficace d'une section élancée, intégration par fibres (mm⁴)", o.Iref, o.Ieng, 1.0, "Ieff");
  chk("R20", "Weff,min d'une section élancée, intégration par fibres (cm³)", o.Wref, o.Weng, 1.0, "Weff");

  const R2 = R, base = { circ: 1, D: .4, ds: .04, fc: 25, fe: 500, acc: 1, gb: 1.5, gs: 1.15, N: 1500, Ma: 0, Mb: 0, l0a: 0, l0b: 0, ec: true };
  const cN = R2.courbeNMcirc(base, 12, 24e-4);
  chk("R21", "cercle : effort normal résistant maximal = Ac·fcd + As·σs (kN, à 1 %)", (Math.PI * .04 * 25 / 1.5 + 24e-4 * 400) * 1000 / 1, cN[cN.length - 1].N, 1, "équilibre");
  const u = R2.poteauNM({ ...base, Ma: 100, Mb: 0 }), v = R2.poteauNM({ ...base, Ma: 60, Mb: 80 });
  chk("R21", "cercle : invariance par rotation du moment (cm²)", u.As, v.As, .01, "symétrie");
  const lo = R2.poteauNM({ ...base, Ma: 160, As: R2.poteauNM({ ...base, Ma: 160 }).AsCalc * .95, k: 12 }), hi = R2.poteauNM({ ...base, Ma: 160, As: R2.poteauNM({ ...base, Ma: 160 }).AsCalc * 1.02, k: 12 });
  chk("R21", "cercle : acier −5 % refusé (1 = oui)", 1, lo.ok ? 0 : 1, 0, "dichotomie");
  chk("R21", "cercle : acier +2 % accepté (1 = oui)", 1, hi.ok ? 1 : 0, 0, "dichotomie");
  const m = JSON.parse(H.get(`(()=>{const st={sec:"c",b:.5,h:.5,H:3.2,k:.7,pp:1,fc:25,fe:500,enr:3,L:[{t:"G",l:"G",N:700,Mx:90,My:90},{t:"Q",l:"Q",N:300,Mx:30,My:30}]},r=poteauCalc(st);return JSON.stringify({ok:r.T&&!r.D.some(d=>d.g=="erreur")?1:0,nm:r.nm?r.nm.ratio:9})})()`));
  chk("R21", "module Poteau circulaire : forte flexion dimensionnée sans erreur (1 = oui)", 1, m.ok, 0, "intégration");
  chk("R21", "module Poteau circulaire : taux N–M ≤ 1 (1 = oui)", 1, m.nm <= 1 ? 1 : 0, 0, "intégration");

  const w = JSON.parse(H.get(`(()=>{const [nm,fmk,ft,fc,fvk,E0,E05]=BOIS[1],km=KMOD[1][2],b=150,h=200,N=120;
    const ap=M.bpoteau.run({b,h,cl:1,sc:1,du:2,L:3,kk:1,N,My:0,Mz:0,ap:1,ti:0}),ft30=M.bpoteau.run({b,h,cl:1,sc:1,du:2,L:3,kk:1,N,My:0,Mz:0,ap:0,ti:30});
    const sc=N*1000/((b+60)*h),fd=km*2.5/1.3*1.25,def=.8*30+7,bf=b-2*def,hf=h-2*def,Af=bf*hf;
    const kc=d=>{const la=3000/(d/Math.sqrt(12)),lr=la/Math.PI*Math.sqrt(fc/(1.25*E05)),k=.5*(1+.2*(lr-.3)+lr*lr);return Math.min(1,1/(k+Math.sqrt(Math.max(k*k-lr*lr,0))))};
    const uf=.6*N*1000/Af/(Math.min(kc(hf),kc(bf))*1.25*fc);
    const pa=ap.rows.find(r=>r[0].startsWith("Appui")),pf=ft30.rows.find(r=>r[0].startsWith("Au feu"));
    return JSON.stringify({u:sc/fd*100,ue:parseFloat(pa[1].match(/\\((\\d+) %\\)/)[1]),uf:uf*100,ufe:parseFloat(pf[1].match(/· (\\d+) %/)[1])})})()`));
  chk("R22", "bois : appui sur lisse, taux de compression perpendiculaire (%)", w.u, w.ue, 1.5, "EC5 6.1.5");
  chk("R22", "bois : taux au feu R30 sur section réduite (%)", w.uf, w.ufe, 1.5, "EC5-1-2");
})();

/* ===== R23. Semelle (V140c) : glacis, semelle filante dans le module Semelle ===== */
(() => {
  const H = require("./harness.js"), E = require("../exb-ouvrages.js"), fs = require("fs"), path = require("path");
  H.setNorme("ec2");
  const o = { ec: true, fc: 25, fe: 500, B: 1.2, H: .4, a: .2, enr: .05, G: 150, Q: 60, e0: 0, sig: .2 };
  const r0 = E.semelleFilante({ ...o, h0: 0 }), r1 = E.semelleFilante({ ...o, h0: .2 }), c1 = (o.B - o.a) / 2;
  const volRef = o.a * o.H + c1 * (o.H + .2);
  chk("R23", "filante glacis : volume = a·H + (B−a)/2·(H+h0) (m³/ml)", volRef, r1.vol, .01, "géométrie");
  chk("R23", "filante rectangulaire : volume = B·H (m³/ml)", o.B * o.H, r0.vol, .01, "géométrie");
  chk("R23", "filante glacis : poids propre = 25·volume (kN/m)", 25 * volRef, r1.pp, .01, "géométrie");
  chk("R23", "filante : Ns = G + pp + Q (kN/m)", o.G + 25 * volRef + o.Q, r1.Ns, .01, "descente de charges");
  chk("R23", "filante glacis : hauteur utile au tranchant réduite à d du nu (m)", o.H - (o.H - .2) * (o.H - o.enr - .01) / c1 - o.enr - .01, r1.dsh, .1, "BAEL A.5.2");
  const sg = r1.sol.smax, ref = r1.Ns / o.B / 1000;
  chk("R23", "filante : contrainte au sol centrée = Ns/B (MPa)", ref, sg, .01, "sol");
  const rt = E.semelleFilante({ ...o, h0: 0, hter: .8, gam: 18 });
  chk("R23", "filante : terres = γ·h·(B−a) (kN/m)", 18 * .8 * (o.B - o.a), rt.soil, .01, "descente de charges");
  const nb = E.semelleFilante({ ...o, ec: false, h0: .15, G: 100, Q: 30 });
  chk("R23", "filante BAEL bielles : As = Nu(B−a)/(8·d·fed) (cm²/m)", nb.Nu / 1000 * (o.B - o.a) / (8 * nb.d * 500 / 1.15) * 1e4, nb.Asb, .01, "BAEL A.8.2");
  // semelle isolée à glacis (moteur de index.html)
  const sd = H.get("semDef()"), g = H.get("(()=>{const st={...semDef(),geo:'g',h0:.2,A:1.2,B:1.2,H:.45,a:.25,b:.25};const r=semelleCalc(st);return JSON.stringify({vol:r.vol,pp:r.pp,gl:r.gl,ok:r.ok,pente:r.pente})})()");
  const gj = JSON.parse(g), A = 1.2, S1 = A * A, S2 = .0625, hh = .45 - .2, vtr = S1 * .2 + hh / 3 * (S1 + S2 + Math.sqrt(S1 * S2));
  chk("R23", "isolée glacis : volume du tronc de pyramide (m³)", vtr, gj.vol, .01, "géométrie");
  chk("R23", "isolée glacis : poids propre = 25·volume (kN)", 25 * vtr, gj.pp, .01, "géométrie");
  const rect = JSON.parse(H.get("(()=>{const r=semelleCalc({...semDef(),geo:'r',h0:.2,A:1.2,B:1.2,H:.45,a:.25,b:.25});return JSON.stringify({vol:r.vol,gl:r.gl})})()"));
  chk("R23", "isolée rectangulaire : h0 ignoré, volume = A·B·H (m³)", 1.2 * 1.2 * .45, rect.vol, .01, "géométrie");
  const ix = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  chk("R23", "module Semelle : boutons « filante » et « glacis » actifs (1 = oui)", 1, /function semelleFUI\(/.test(ix) && /data-sg="\$\{g\}"/.test(ix) && !/data-s="1"/.test(ix.slice(ix.indexOf("function semelleUI"), ix.indexOf("function escalierUI"))) ? 1 : 0, 0, "interface");
  chk("R23", "note de calcul de semelle filante présente (1 = oui)", 1, /function noteSemF\(/.test(ix) ? 1 : 0, 0, "documents");
})();

/* ===== Station Robot reportée de V137 dans V140 (V140d) : R24 vue 3D, R30 charges par dalle, R32-R33 station autonome et navigation, R36 documents ===== */
/* ===== R24. Vue 3D de la station (géométrie de la scène) ===== */
(() => {
  const H = require("./harness.js"), fs = require("fs"), src3d = fs.readFileSync(require("path").join(__dirname, "..", "exb-robot-3d.js"), "utf8");
  const t = JSON.parse(H.get(src3d + `;(()=>{const b=batDef();b.res=batCalc(b);const sc=EXB3.scene(b,{lv:0}),n=k=>sc.boxes.filter(x=>x.kind==k).length;
    const ncol=b.niv.reduce((t,v)=>t+v.cols.flat().filter(x=>x).length,0),nsl=b.niv.reduce((t,v)=>t+v.sl.flat().filter(x=>x).length,0);
    const cam={yaw:0,pit:Math.PI/2-.001,zoom:1,px:0,py:0},g=sc.g,top=EXB3.svg(b,cam,{lv:0,sel:"c:"+(b.niv.length-1)+":0:0"}),svg=EXB3.svg(b,{yaw:-.6,pit:.55,zoom:1,px:0,py:0},{lv:0});
    b.niv[0].cols[1][1]=0;const sc2=EXB3.scene(b,{lv:0});
    return JSON.stringify({col:n("col"),ncol,sl:n("slab"),nsl,ft:n("foot"),nft:b.res.fond.list.length,ghost:sc2.pts.length,sel:/b35c00/.test(top)?1:0,poly:(svg.match(/<polygon data-e3/g)||[]).length,H:g.H,Hz:b.niv.reduce((t,v)=>t+v.h,0),SX:g.SX,SXe:b.xs.reduce((t,x)=>t+x,0)})})()`));
  chk("R24", "scène 3D : un poteau par poteau du modèle", t.ncol, t.col, 0, "vue 3D");
  chk("R24", "scène 3D : une dalle par dalle du modèle", t.nsl, t.sl, 0, "vue 3D");
  chk("R24", "scène 3D : une semelle par semelle calculée", t.nft, t.ft, 0, "vue 3D");
  chk("R24", "scène 3D : poteau supprimé → repère fantôme au niveau courant (≥ 1)", 1, t.ghost >= 1 ? 1 : 0, 0, "vue 3D");
  chk("R24", "scène 3D : hauteur totale (m)", t.Hz, t.H, .0001, "vue 3D");
  chk("R24", "scène 3D : longueur totale en X (m)", t.SXe, t.SX, .0001, "vue 3D");
  chk("R24", "rendu 3D : faces cliquables produites (1 = oui)", 1, t.poly > 100 ? 1 : 0, 0, "vue 3D");
  chk("R24", "rendu 3D : élément sélectionné mis en évidence (1 = oui)", 1, t.sel, 0, "vue 3D");
})();

/* ===== R30. Charges surfaciques propres à chaque dalle (V139) : référence = calcul à la main de l'aire d'influence ===== */
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{
    const N=nrm(),base=batDef();base.res=batCalc(base);
    const b=batDef();const v=b.niv[1];v.sc={"0:0":{G:4.5,Q:5}};b.res=batCalc(b);
    const col=(r,i,j,k)=>r.cols.find(c=>c.i==i&&c.j==j).rows.find(x=>x.k==k).Nu;
    const bm=(r,d,l)=>r.beams.find(x=>x.k==1&&x.dir==d&&x.line==l);
    /* valeurs identiques à celles du niveau : aucun effet */
    const e=batDef();e.niv[1].sc={"0:0":{G:e.niv[1].G,Q:e.niv[1].Q}};e.res=batCalc(e);
    /* le niveau change : la dalle à charges propres reste, les autres suivent */
    const m=batDef();m.niv[1].sc={"0:0":{G:4.5,Q:5}};m.niv[1].G=3;m.niv[1].Q=2.5;m.res=batCalc(m);
    const lv3=batDef();lv3.niv[1].G=3;lv3.niv[1].Q=2.5;lv3.res=batCalc(lv3);
    const d=batDalles(b).filter(x=>x.k==1);
    const note=batNote(b),note0=batNote(base);
    const b2=JSON.parse(JSON.stringify(b));batAxIns(b2,"x",0);const k2=Object.keys(b2.niv[1].sc).sort();
    const b3=JSON.parse(JSON.stringify(b2));batAxDel(b3,"x",0);
    const b4=JSON.parse(JSON.stringify(b));batAxIns(b4,"y",0);const k4=Object.keys(b4.niv[1].sc).sort();
    return JSON.stringify({gG:N.gG,gQ:N.gQ,rho:N.rho,xs:b.xs,ys:b.ys,
      c00:col(b.res,0,0,1)-col(base.res,0,0,1),c22:col(b.res,2,2,1)-col(base.res,2,2,1),c10:col(b.res,1,0,1)-col(base.res,1,0,1),c11:col(b.res,1,1,1)-col(base.res,1,1,1),c00t:col(b.res,0,0,2)-col(base.res,0,0,2),
      bx0:bm(b.res,"X",0).Gs[0]-bm(base.res,"X",0).Gs[0],bq0:bm(b.res,"X",0).Qs[0]-bm(base.res,"X",0).Qs[0],by0:bm(b.res,"Y",0).Gs[0]-bm(base.res,"Y",0).Gs[0],bx2:bm(b.res,"X",2).Gs[0]-bm(base.res,"X",2).Gs[0],
      neutre:col(e.res,0,0,1)-col(base.res,0,0,1),neutreB:bm(e.res,"X",0).Gs[0]-bm(base.res,"X",0).Gs[0],
      mc:col(m.res,0,0,1)-col(lv3.res,0,0,1),mc2:col(m.res,2,2,1)-col(lv3.res,2,2,1),
      dG:d[0].st.G,dQ:d[0].st.Q,dG2:d[1].st.G,dQ2:d[1].st.Q,
      note:/Dalles à charges particulières/.test(note),note0:/Dalles à charges particulières/.test(note0),propre:!/NaN|undefined|Infinity/.test(note),
      k2,k3:Object.keys(b3.niv[1].sc),k4})})()`));
  const gG = o.gG, gQ = o.gQ, A = o.xs[0] * o.ys[0], dG = 4.5 - 2, dQ = 5 - 1.5, tr = A / 4;
  /* poteau d'angle A1 (0,0) : un quart de la dalle D(0:0) ; poteau B2 (1,1) au sommet de la dalle voisine : pas de variation sauf s'il touche la dalle */
  chk("R30", "poteau d'angle : ΔNu = (γG·ΔG + γQ·ΔQ)·A/4 (kN)", (gG * dG + gQ * dQ) * tr, o.c00, .01, "aire d'influence du poteau, dalle seule");
  /* poteaux B1 (1,0) et B2 (1,1) : intermédiaires dans le sens X (2 travées) → majoration forfaitaire de continuité 1,15 du modèle */
  chk("R30", "poteau B1 (1,0) : ΔNu = quart de dalle × 1,15 de continuité (kN)", (gG * dG + gQ * dQ) * tr * 1.15, o.c10, .01, "aire d'influence × majoration");
  chk("R30", "poteau B2 (1,1) : ΔNu = quart de dalle × 1,15 de continuité (kN)", (gG * dG + gQ * dQ) * tr * 1.15, o.c11, .01, "aire d'influence × majoration");
  chk("R30", "poteau éloigné de la dalle : aucune variation (kN)", 0, o.c22, 0, "les autres dalles gardent le niveau");
  chk("R30", "niveau supérieur (Terrasse) sans charge propre : ΔNu = 0 (kN)", 0, o.c00t, 0, "la charge ne remonte pas");
  /* poutre de rive axe 1, travée A–B : dalle 0:0, Lb = xs0 = 4,5 ; Lo = ys0 = 4 → Lb > Lo : c = Lo/2·(1 − (Lo/Lb)²/3) */
  const Lb = o.xs[0], Lo = o.ys[0], c = Lb <= Lo ? Lb / 3 : Lo / 2 * (1 - (Lo / Lb) ** 2 / 3);
  chk("R30", "poutre de rive : ΔG linéique = ΔG·c (kN/m), c = charge équivalente de la dalle", dG * c, o.bx0, .01, "répartition en trapèze / triangle");
  chk("R30", "poutre de rive : ΔQ linéique = ΔQ·c (kN/m)", dQ * c, o.bq0, .01, "répartition en trapèze / triangle");
  const Lb2 = o.ys[0], Lo2 = o.xs[0], c2 = Lb2 <= Lo2 ? Lb2 / 3 : Lo2 / 2 * (1 - (Lo2 / Lb2) ** 2 / 3);
  chk("R30", "poutre de rive axe A (sens Y) : ΔG linéique = ΔG·c' (kN/m)", dG * c2, o.by0, .01, "dalle vue depuis l'autre sens");
  chk("R30", "poutre éloignée (axe 3) : aucune variation (kN/m)", 0, o.bx2, 0, "dalles voisines inchangées");
  chk("R30", "valeurs égales à celles du niveau : poteau inchangé (kN)", 0, o.neutre, 0, "pas d'effet parasite");
  chk("R30", "valeurs égales à celles du niveau : poutre inchangée (kN/m)", 0, o.neutreB, 0, "pas d'effet parasite");
  chk("R30", "dalle D1 calculée avec G propre (kN/m²)", 4.5, o.dG, 0, "batDalles");
  chk("R30", "dalle D1 calculée avec Q propre (kN/m²)", 5, o.dQ, 0, "batDalles");
  chk("R30", "dalle voisine : G du niveau (kN/m²)", 2, o.dG2, 0, "batDalles");
  chk("R30", "dalle voisine : Q du niveau (kN/m²)", 1.5, o.dQ2, 0, "batDalles");
  chk("R30", "niveau G=3 / Q=2,5 : la dalle à charges propres garde 4,5 / 5 : ΔNu vs dalle au niveau (kN)", (gG * (4.5 - 3) + gQ * (5 - 2.5)) * tr, o.mc, .01, "priorité de la valeur propre");
  chk("R30", "niveau modifié : poteau éloigné suit le niveau (écart 0, kN)", 0, o.mc2, 0, "les autres dalles suivent le niveau");
  chk("R30", "note de calcul : tableau des dalles à charges particulières présent (1 = oui)", 1, o.note ? 1 : 0, 0, "note section 4");
  chk("R30", "note de calcul : tableau absent sans surcharge (1 = oui)", 1, o.note0 ? 0 : 1, 0, "note section 4");
  chk("R30", "note de calcul : aucune valeur NaN / undefined (1 = oui)", 1, o.propre ? 1 : 0, 0, "note section 4");
  chk("R30", "insertion d'un axe X : la dalle se scinde en deux, charges conservées (1 = oui)", 1, JSON.stringify(o.k2) === JSON.stringify(["0:0", "1:0"]) ? 1 : 0, 0, "scShift");
  chk("R30", "suppression de l'axe : retour à une seule dalle (1 = oui)", 1, JSON.stringify(o.k3) === JSON.stringify(["0:0"]) ? 1 : 0, 0, "scShift");
  chk("R30", "insertion d'un axe Y : la dalle se scinde en deux (1 = oui)", 1, JSON.stringify(o.k4) === JSON.stringify(["0:0", "0:1"]) ? 1 : 0, 0, "scShift");
})();

// R32 — Station Robot autonome, plein écran, navigation (V137)
(() => {
  const fs = require("fs"), path = require("path"), rd = f => fs.readFileSync(path.join(__dirname, "..", "..", f), "utf8");
  const idx = rd("calcul-structure/index.html"), stn = rd("calcul-structure/exb-robot-station.js"), menu = rd("exb-calcul-structure.js");
  chk("R32", "module « robot » déclaré dans le menu Ingénierie & Structure (1 = oui)", 1, /\['bcs_rob'[^\]]*'robot'\]/.test(menu) ? 1 : 0, 0, "intégration");
  chk("R32", "bouton de la station retiré du module Bâtiment (1 = oui)", 1, idx.includes('id="brs"') ? 0 : 1, 0, "intégration");
  const z = +(idx.match(/#v3\{position:fixed;inset:0;z-index:(\d+)/) || [])[1], zs = +(stn.match(/#exbs\{position:fixed;inset:0;z-index:(\d+)/) || [])[1];
  chk("R32", "visionneuse 3D plein écran au-dessus de la station (1 = oui)", 1, z > zs ? 1 : 0, 0, "plein écran");
  chk("R32", "bouton « Plein écran » dans la barre de la station (1 = oui)", 1, stn.includes('data-fs="1"') ? 1 : 0, 0, "plein écran");
  chk("R32", "la navigation entre modules ferme la station (1 = oui)", 1, /function closeOv\(\)\{try\{if\(window\.EXBS&&document\.getElementById\('exbs'\)\)EXBS\.close\(true\)/.test(idx) ? 1 : 0, 0, "navigation");
})();

// R33 — la vue 3D et la station se ferment à la navigation ; pas de reconstruction pendant la saisie (V137)
(() => {
  const fs = require("fs"), path = require("path"), rd = f => fs.readFileSync(path.join(__dirname, "..", "..", f), "utf8");
  const idx = rd("calcul-structure/index.html"), par = rd("exb-calcul-structure.js");
  chk("R33", "go() ferme la vue 3D et la station (1 = oui)", 1, /function go\(v\)\{closeOv\(\)/.test(idx) && /querySelectorAll\('#v3'\)/.test(idx) ? 1 : 0, 0, "navigation");
  chk("R33", "quitter l'écran Structure ferme les vues ouvertes (message « leave ») (1 = oui)", 1, par.includes("exbCalc:'leave'") && idx.includes("exbCalc==='leave'") ? 1 : 0, 0, "navigation");
})();

// R36 — station : note de calcul, plans d'exécution, coffrage, dalles, DXF/IFC (V137g)
(() => {
  const fs = require("fs"), path = require("path");
  const st = fs.readFileSync(path.join(__dirname, "..", "exb-robot-station.js"), "utf8"), ix = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  chk("R36", "station : boutons note / plans / coffrage / dalles / DXF-IFC (1 = oui)", 1, ["d:note", "d:plan", "d:coff", "d:dal", "d:exp"].every(k => st.includes(k)) && st.includes('G("stationNote")') && st.includes('G("planDocBatCoff")') ? 1 : 0, 0, "documents");
  chk("R36", "note de la station : fonction stationNote présente (1 = oui)", 1, /function stationNote\(b,a,dsg\)/.test(ix) ? 1 : 0, 0, "documents");
  chk("R36", "documents au-dessus de la station : z-index #doc/#sh (1 = oui)", 1, /#doc\{position:fixed;inset:0;z-index:2147483300/.test(ix) && /#sh\{position:fixed;inset:0;z-index:2147483300/.test(ix) ? 1 : 0, 0, "documents");
})();

/* ===== R37. V141n : diagrammes de semelle (M, V) et robustesse de la navigation entre modules ===== */
(() => {
  const H = require("./harness.js"), fs = require("fs"), path = require("path");
  const g = JSON.parse(H.get("(()=>{const r=fdnDiag({L:2,a:.4,off:0,e:0,p0:100,d:.3});return JSON.stringify({M1:r.M1,M2:r.M2,V1:r.V1,Vd1:r.Vd1,tri:r.tri})})()"));
  chk("R37", "diagramme semelle centrée : M au nu = p·c²/2 (kN.m/m)", 100 * .8 * .8 / 2, g.M1, 1, "RDM console");
  chk("R37", "diagramme semelle centrée : V au nu = p·c (kN/m)", 100 * .8, g.V1, 1, "RDM console");
  chk("R37", "diagramme semelle centrée : V à d du nu = p·(c − d) (kN/m)", 100 * (.8 - .3), g.Vd1, 1.5, "BAEL A.5.1");
  const t = JSON.parse(H.get("(()=>{const r=fdnDiag({L:2,a:.4,off:0,e:.5,p0:100,d:.3});return JSON.stringify({tri:r.tri,Lc:r.Lc,smax:r.smax})})()"));
  chk("R37", "résultante hors noyau : contact triangulaire, longueur 3(L/2 − e) (m)", 1.5, t.Lc, .1, "sol");
  chk("R37", "résultante hors noyau : σmax = 2·N/(contact) (kPa)", 2 * 100 * 2 / 1.5, t.smax, 1.5, "sol");
  const ix = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8"), par = fs.readFileSync(path.join(__dirname, "..", "..", "exb-calcul-structure.js"), "utf8");
  chk("R37", "ouverture du module « robot » depuis le menu (1 = oui)", 1, /k=='robot'\)\{go\('m:'\+k\)/.test(ix) ? 1 : 0, 0, "navigation");
  chk("R37", "carte de secours en cas d'erreur d'affichage (1 = oui)", 1, /function errCard\(/.test(ix) && /catch\(e\)\{errCard\(v,e\)\}/.test(ix) ? 1 : 0, 0, "robustesse");
  chk("R37", "accusé d'ouverture et nouvel essai côté logiciel central (1 = oui)", 1, /exbCalc:'opened'/.test(ix) && /e\.data\.exbCalc!=='opened'/.test(par) ? 1 : 0, 0, "robustesse");
  // chaque entrée du menu existe réellement dans le module (aucune entrée ignorée en silence)
  const keys = [...new Set([...par.matchAll(/,'([a-z0-9]+)'\]/g)].map(m => m[1]))];
  const MODS = (ix.match(/const MODS=\[([^\]]*)\]/) || [, ""])[1].replace(/'/g, "").split(",");
  const known = new Set([...MODS, "robot", "home", "calculs", "rapports", "plus", "devis", ...JSON.parse(H.get("JSON.stringify(Object.keys(M))"))]);
  const manq = keys.filter(k => !known.has(k));
  chk("R37", "entrées du menu inconnues du module (" + (manq.join(",") || "aucune") + ")", 0, manq.length, 0, "navigation");
})();

/* ===== R38. V141o : modules de quantités de matériaux (dosage, volume, coffrage, ferraillage, agglos, mortier, coût) ===== */
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{const r=(k,v)=>{const m=M[k],x={};m.f.forEach(f=>x[f[0]]=f[f.length-1]);Object.assign(x,v||{});return m.run(x).rows.map(a=>a[1]).join("|")};
  const num=(t)=>parseFloat((String(t).match(/^[0-9 \u00a0\u202f.,]+/)||["NaN"])[0].replace(/[ \u00a0\u202f]/g,"").replace(",","."));const rows=(k,v)=>{const m=M[k],x={};m.f.forEach(f=>x[f[0]]=f[f.length-1]);Object.assign(x,v||{});const o={};m.run(x).rows.forEach(a=>o[a[0]]=a[1]);return o};
  const d=rows("dosage",{V:2,dos:350,pt:0,ec:.5,rs:.4,rg:.8,sac:50}),vo=rows("volume",{t:2,L:3,l:.4,n:2,pt:0}),co=rows("coffrage",{t:2,b:30,h:40,L:3,n:2,pt:0,ou:0}),ag=rows("agglos",{L:10,H:3,o:0,fm:12.5,ep:20,pt:0,dos:350}),mo=rows("mortier",{S:10,e:3,dos:350,pt:0}),ct=rows("cout",{V:10,cf:0,fg:0,mo:0});
  const bad=["dosage","volume","coffrage","ferraillage","agglos","mortier","cout","moment"].map(k=>k+(/NaN|undefined|Infinity/.test(r(k))?"!":"")).filter(x=>x.slice(-1)=="!");const all=bad.length==0;
  return JSON.stringify({cim:num(d["Ciment"]),eau:num(d["Eau de gâchage"]),vol:num(vo["Volume net"]),sur:num(co["Surface totale de coffrage"]),ag:num(ag["Agglos (+0 % casse)"]),mor:num(mo["Volume de mortier (avec pertes)"]),cim2:num(mo["Ciment"]),ct:num(ct["Ciment"]),ok:all?1:0})})()`));
  chk("R38", "dosage 350 kg/m³ × 2 m³ = 700 kg de ciment", 700, o.cim, .1, "quantités");
  chk("R38", "dosage : eau = E/C × ciment = 350 L", 350, o.eau, .1, "quantités");
  chk("R38", "volume de 2 poteaux ronds Ø0,40 × 3 m = 0,754 m³", 2 * Math.PI * .04 * 3, o.vol, 1, "géométrie");
  chk("R38", "coffrage de 2 poteaux 30×40 × 3 m = 2·(0,3+0,4)·3·2 = 8,4 m²", 8.4, o.sur, .1, "géométrie");
  chk("R38", "agglos : 30 m² × 12,5 = 375 u (sans casse)", 375, o.ag, .1, "quantités");
  chk("R38", "mortier : 10 m² × 3 cm = 0,30 m³", .3, o.mor, .5, "quantités");
  chk("R38", "mortier : ciment = 0,30 × 350 = 105 kg", 105, o.cim2, .5, "quantités");
  chk("R38", "coût : 10 m³ × 350 kg = 70 sacs × 5000 = 350 000", 350000, o.ct, .1, "quantités");
  chk("R38", "aucune valeur NaN / undefined dans les modules de quantités", 1, o.ok, 0, "robustesse");
})();

/* ===== R39. V141s : notes d'escalier (diagrammes M/V et calcul pas à pas) ===== */
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{const st=Object.assign(escDef(),{typ:"d",H:3,W:1.2}),r=escCalc(st),N=nrm(),fbu=N.acc*st.fc/N.gb,fed=st.fe/N.gs,D=escDiag({L:r.L,pu:r.pu}),s=escFlexSteps(r.Mt,r.d,fbu,fed,r.asT,"T"),as=parseFloat(s[4][1]),h=noteEsc(st,r),hm=noteEscM(Object.assign(escDef(),{typ:"v",H:3,W:1.2}),escCalc(Object.assign(escDef(),{typ:"v",H:3,W:1.2})));
  return JSON.stringify({M0:D.M0,ref:r.pu*r.L*r.L/8,V0:D.V0,vref:r.pu*r.L/2,as:as,asT:r.asT,pg:(h.match(/class="pg"/g)||[]).length,pm:(hm.match(/class="pg"/g)||[]).length,bad:(h+hm).match(/NaN|undefined|Infinity/g)?1:0})})()`));
  chk("R39", "diagramme volée : M0 maximal = pu·L²/8", o.ref, o.M0, .1, "RDM poutre");
  chk("R39", "diagramme volée : V à l'appui = pu·L/2", o.vref, o.V0, .1, "RDM poutre");
  chk("R39", "calcul pas à pas : As(μ, α, z) = As du moteur (flexion simple)", o.asT, o.as, 1, "BAEL A.4.3");
  chk("R39", "note de volée droite : 6 pages (page « Modèle de calcul » ajoutée en V141v)", 6, o.pg, 0, "document");
  chk("R39", "note d'escalier à palier : 7 pages", 7, o.pm, 0, "document");
  chk("R39", "notes d'escalier : aucune valeur NaN / undefined", 0, o.bad, 0, "robustesse");
})();

/* ===== R40. V141s : recalcul automatique après changement de donnée / d'acier imposé ===== */
(() => {
  const ix = require("fs").readFileSync(require("path").join(__dirname, "..", "index.html"), "utf8");
  chk("R40", "recalcul automatique branché (input + change, résultat marqué obsolète)", 1, /recalcul automatique/.test(ix) && /addEventListener\("input",plan,true\)/.test(ix) && /window\.__auto/.test(ix) ? 1 : 0, 0, "ergonomie");
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{const k=a=>{P.ac=a;const b=barres(15.7,100,3,a.lp||undefined);return b?b.n+"|"+b.phi:"-"};const r=[k({}),k({lp:16}),k({lp:25})];P.ac={};return JSON.stringify(r)})()`));
  chk("R40", "acier imposé : 15,7 cm² : 5 HA20 en automatique, 8 HA16 imposé (nombre recalculé)", 1, parseInt(o[1]) > parseInt(o[0]) ? 1 : 0, 0, "acier imposé");
})();

// R41 — notes avec modèle de calcul : poteau, poutre, dalle, plancher multi-travées (reportées de V134-V137 vers V141v)
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{
    const cnt=(h,re)=>(h.match(re)||[]).length;
    const sp={sec:"r",b:.25,h:.25,H:2.8,k:.7,pp:1,fc:25,fe:500,enr:3,L:[{t:"G",l:"G",N:250,Mx:0,My:0},{t:"Q",l:"Q",N:150,Mx:0,My:0}]},rp=poteauCalc(sp),hp=potNote(sp,rp,potDetail(sp,rp));
    const sd=dalleDef(),rd=dalleCalc(sd),hd=noteD(sd,rd,detailD(sd,rd));
    const sm={...dalleDef(),multi:1},rm=dalleCalcM(sm),hm=noteDM(sm,rm,detailDM(sm,rm));
    const P0={cont:1,n:3,L:"4.5; 5",b:.2,h:.4,enr:2.5,G:15,Q:10,fc:25,fe:500,fis:0,pp:1,sp:[]},rb=verifier(P0),hb=noteHtml(P0,rb,detail(P0,rb));
    const pgOk=h=>{const m=[...h.matchAll(/Page (\\d+) \\/ (\\d+)/g)];return m.length>0&&m.every(x=>x[2]==m[m.length-1][2])&&+m[m.length-1][1]==+m[m.length-1][2]?1:0};
    const all=hp+hd+hm+hb;
    return JSON.stringify({pp:cnt(hp,/Modèle de calcul et diagrammes/g),pd:cnt(hd,/Modèle de calcul/g),pm:cnt(hm,/Modèle de calcul/g),pb:cnt(hb,/Modèle de calcul et cas de charges/g),
      env:cnt(hm,/enveloppe/gi)+cnt(hb,/enveloppe/gi),sv:cnt(all,/<svg/g),nan:cnt(all,/NaN|undefined/g),pg:pgOk(hp)&pgOk(hd)&pgOk(hm)&pgOk(hb)})})()`));
  chk("R41", "notes : section « Modèle de calcul » présente (poteau, poutre, dalle, plancher) (1 = oui)", 1, (o.pp > 0 && o.pd > 0 && o.pm > 0 && o.pb > 0) ? 1 : 0, 0, "contenu de note");
  chk("R41", "notes : enveloppes M/V présentes (poutre, plancher) (1 = oui)", 1, o.env > 0 ? 1 : 0, 0, "contenu de note");
  chk("R41", "notes : schémas SVG insérés (≥ 12) (1 = oui)", 1, o.sv >= 12 ? 1 : 0, 0, "contenu de note");
  chk("R41", "notes : pagination « Page i / N » cohérente (1 = oui)", 1, o.pg ? 1 : 0, 0, "numérotation des pages");
  chk("R41", "notes : aucune valeur NaN / undefined affichée (nombre)", 0, o.nan, 0, "qualité de note");
})();

// R42 — notes d'escalier : modèle de paillasse, combinaisons et diagrammes de la bande de 1 m (V137 reporté en V141v)
(() => {
  const H = require("./harness.js");
  const o = JSON.parse(H.get(`(()=>{
    const c=(h,re)=>(h.match(re)||[]).length,out=[];
    for(const typ of ["d","v","b","q"]){const st={...escDef(),typ},r=escCalc(st),h=typ=="v"||typ=="q"?noteEscM(st,r):noteEsc(st,r);
      out.push({svg:c(h,/<svg/g),mod:c(h,/modèle de calcul/gi),pas:c(h,/pas à pas/gi),bad:c(h,/NaN|undefined/g),M0:typ=="v"||typ=="q"?r.fl[0].M0:r.M0,pu:typ=="v"||typ=="q"?r.fl[0].pu:r.pu,L:typ=="v"||typ=="q"?r.fl[0].L:r.L})}
    return JSON.stringify(out)})()`));
  o.forEach((x, i) => {
    const n = ["volée droite", "à palier (va-et-vient)", "balancé", "à palier (quart tournant)"][i];
    chk("R42", "note d'escalier " + n + " : modèle de paillasse + diagrammes M/V présents (1 = oui)", 1, x.svg >= 3 && x.mod > 0 ? 1 : 0, 0, "contenu de note");
    chk("R42", "note d'escalier " + n + " : calcul pas à pas conservé (1 = oui)", 1, x.pas > 0 ? 1 : 0, 0, "contenu V141s");
    chk("R42", "note d'escalier " + n + " : aucune valeur NaN / undefined (nombre)", 0, x.bad, 0, "qualité de note");
    chk("R42", "note d'escalier " + n + " : M0 = pu·L²/8 (kN.m/m)", x.pu * x.L * x.L / 8, x.M0, 0.5, "moment isostatique");
  });
})();

// R43 — changer de module ferme aussi la note / l'aperçu de document ouvert (V141w)
(() => {
  const ix = require("fs").readFileSync(require("path").join(__dirname, "..", "index.html"), "utf8");
  const f = ix.match(/function closeOv\(\)\{[^\n]*/);
  chk("R43", "closeOv() ferme la note de calcul (#doc) et les feuilles (#sh) (1 = oui)", 1, f && /querySelectorAll\('#doc,#sh'\)/.test(f[0]) ? 1 : 0, 0, "navigation");
  chk("R43", "go() appelle closeOv() avant tout changement de module (1 = oui)", 1, /function go\(v\)\{closeOv\(\)/.test(ix) ? 1 : 0, 0, "navigation");
})();

/* ===== R41. V141x : recalcul automatique du module Bâtiment après modification ===== */
(() => {
  const ix = require("fs").readFileSync(require("path").join(__dirname, "..", "index.html"), "utf8");
  chk("R41", "Bâtiment : un changement relance le calcul déjà affiché (__batAuto)", 1, /window\.__batAuto=/.test(ix) && /if\(had&&window\.__batAuto\)/.test(ix) ? 1 : 0, 0, "ergonomie");
})();

module.exports = { rows, fail };
if (require.main === module) {
  let n = 0;
  for (const r of rows) { n++; console.log((r.ok ? "OK  " : "ÉCHEC ") + r.id + " " + r.grandeur + " : réf. " + (+r.ref).toPrecision(5) + " | moteur " + (+r.val).toPrecision(5) + " | écart " + r.ecart.toFixed(3) + " % (tol. " + r.tol + " %)"); }
  console.log("\n" + n + " contrôles, " + fail + " écart(s) hors tolérance");
  process.exit(fail ? 1 : 0);
}
