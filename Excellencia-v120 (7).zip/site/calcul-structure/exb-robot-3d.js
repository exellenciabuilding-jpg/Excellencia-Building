/* Vue 3D éditable de la Station d'analyse — projection orthographique logicielle, rendu SVG, sélection des éléments.
   window.EXB3 = { scene(b), svg(b, cam, opts), fit(b), CAM_IDS } ; aucune dépendance externe. */
(function (root) {
  "use strict";
  const G = n => (root[n] !== undefined ? root[n] : (0, eval)(n));
  const hex = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
  const mix = (c, f) => { const [r, g, b] = hex(c); const k = x => Math.max(0, Math.min(255, Math.round(x * f))); return `rgb(${k(r)},${k(g)},${k(b)})`; };
  const L = (() => { const v = [-.35, -.55, .75], n = Math.hypot(...v); return v.map(x => x / n); })();
  const FACES = [[[0, 0, -1], [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]]], [[0, 0, 1], [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]]], [[0, -1, 0], [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]]], [[0, 1, 0], [[0, 1, 0], [1, 1, 0], [1, 1, 1], [0, 1, 1]]], [[-1, 0, 0], [[0, 0, 0], [0, 1, 0], [0, 1, 1], [0, 0, 1]]], [[1, 0, 0], [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]]]];

  function geom(b) {
    const nx = b.xs.length, ny = b.ys.length, px = [0], py = [0], z = [0];
    b.xs.forEach(l => px.push(px[px.length - 1] + l)); b.ys.forEach(l => py.push(py[py.length - 1] + l)); b.niv.forEach(v => z.push(z[z.length - 1] + v.h));
    return { nx, ny, px, py, z, SX: px[nx], SY: py[ny], H: z[z.length - 1] };
  }
  /* éléments de la scène : boîtes {id, k, x0..z1, col, op, kind} + lignes (poutres retirées) + repères */
  function scene(b, o) {
    o = o || {}; const g = geom(b), r = b.res && b.res.ok ? b.res : null, out = { boxes: [], lines: [], pts: [], labels: [], g }, bc = G("batColA"), bsec = G("bsec"), bOn = G("bOn"), lvHs = G("lvHs");
    const pc = (b.pc > 0 ? b.pc : 30) / 100, ca = (k, i, j) => { const a = r ? bc(r, k, i, j) : 0; return (a > 0 ? a : pc * 100) / 100; };
    b.niv.forEach((v, k) => {
      const zb = g.z[k], zt = g.z[k + 1], hs = Math.min(lvHs(b, v) || .2, v.h * .5), dim = o.iso && o.lv != null && k !== o.lv, op = dim ? .18 : 1;
      for (let i = 0; i <= g.nx; i++) for (let j = 0; j <= g.ny; j++) {
        const a = ca(k, i, j);
        if (v.cols[i][j]) out.boxes.push({ id: `c:${k}:${i}:${j}`, k, kind: "col", x0: g.px[i] - a / 2, x1: g.px[i] + a / 2, y0: g.py[j] - a / 2, y1: g.py[j] + a / 2, z0: zb, z1: zt + .03, col: "#8d99ae", op });
        else if (o.lv === k) out.pts.push({ id: `g:${k}:${i}:${j}`, x: g.px[i], y: g.py[j], z: zb });
      }
      const seg = (d, i, j) => { const i2 = d === "X" ? i + 1 : i, j2 = d === "Y" ? j + 1 : j; if (!(v.cols[i][j] && v.cols[i2][j2])) return; const line = d === "X" ? j : i, sec = bsec(b, v, d, line), bw = sec[0], bh = sec[1], on = bOn(v, d, i, j);
        if (!on) { out.lines.push({ id: `b:${k}:${d}:${i}:${j}`, k, x0: g.px[i], y0: g.py[j], x1: g.px[i2], y1: g.py[j2], z: zt - bh / 2, op }); return; }
        const x0 = Math.min(g.px[i], g.px[i2]), x1 = Math.max(g.px[i], g.px[i2]), y0 = Math.min(g.py[j], g.py[j2]), y1 = Math.max(g.py[j], g.py[j2]);
        out.boxes.push({ id: `b:${k}:${d}:${i}:${j}`, k, kind: "beam", x0: d === "X" ? x0 : x0 - bw / 2, x1: d === "X" ? x1 : x1 + bw / 2, y0: d === "Y" ? y0 : y0 - bw / 2, y1: d === "Y" ? y1 : y1 + bw / 2, z0: zt - bh, z1: zt, col: "#4f86c6", op }); };
      for (let j = 0; j <= g.ny; j++) for (let i = 0; i < g.nx; i++) seg("X", i, j);
      for (let i = 0; i <= g.nx; i++) for (let j = 0; j < g.ny; j++) seg("Y", i, j);
      for (let i = 0; i < g.nx; i++) for (let j = 0; j < g.ny; j++) if (v.sl[i][j]) out.boxes.push({ id: `s:${k}:${i}:${j}`, k, kind: "slab", x0: g.px[i], x1: g.px[i + 1], y0: g.py[j], y1: g.py[j + 1], z0: zt - hs, z1: zt, col: "#a7c4a0", op: dim ? .1 : .5 });
    });
    if (r && r.fond && r.fond.list) r.fond.list.forEach(f => { const x = g.px[f.i], y = g.py[f.j]; out.boxes.push({ id: `f:${f.i}:${f.j}`, k: -1, kind: "foot", x0: x - f.A / 2, x1: x + f.A / 2, y0: y - f.B / 2, y1: y + f.B / 2, z0: -f.H, z1: 0, col: "#b08968", op: 1 }); });
    for (let i = 0; i <= g.nx; i++) out.labels.push({ t: String.fromCharCode(65 + i % 26), x: g.px[i], y: -.8, z: 0 });
    for (let j = 0; j <= g.ny; j++) out.labels.push({ t: String(j + 1), x: -.8, y: g.py[j], z: 0 });
    return out;
  }
  const rot = (cam, x, y, z, g) => {
    const cx = g.SX / 2, cy = g.SY / 2, cz = g.H / 2, cyw = Math.cos(cam.yaw), syw = Math.sin(cam.yaw), cp = Math.cos(cam.pit), sp = Math.sin(cam.pit),
      x1 = (x - cx) * cyw - (y - cy) * syw, y1 = (x - cx) * syw + (y - cy) * cyw, z1 = z - cz;
    return [x1, -(y1 * sp + z1 * cp), y1 * cp - z1 * sp];
  };
  function fit(b) { const g = geom(b), R = .5 * Math.hypot(g.SX, g.SY, g.H); return 1 / Math.max(R, 1); }
  function svg(b, cam, o) {
    o = o || {}; const sc = scene(b, { iso: o.iso, lv: o.lv }), g = sc.g, W = 760, H = 520, s = Math.min(W, H) * .46 * fit(b) * cam.zoom, ox = W / 2 + cam.px, oy = H / 2 + cam.py;
    const P = (x, y, z) => { const q = rot(cam, x, y, z, g); return [ox + q[0] * s, oy + q[1] * s, q[2]]; };
    const cyw = Math.cos(cam.yaw), syw = Math.sin(cam.yaw), cp = Math.cos(cam.pit), sp = Math.sin(cam.pit), D = [0, cp, -sp], polys = [];
    sc.boxes.forEach(bx => {
      const isel = id => Array.isArray(o.sel) ? o.sel.includes(id) : o.sel === id, sel = isel(bx.id), dx = bx.x1 - bx.x0, dy = bx.y1 - bx.y0, dz = bx.z1 - bx.z0, base = sel ? "#ff9f1c" : bx.col;
      FACES.forEach(([n, vs]) => {
        const n1 = [n[0] * cyw - n[1] * syw, n[0] * syw + n[1] * cyw, n[2]], vis = n1[1] * D[1] + n1[2] * D[2] < -1e-9; if (!vis) return;
        const lum = Math.max(0, n1[0] * L[0] + n1[1] * L[1] + n1[2] * L[2]) * .55 + .5, pts = vs.map(v => P(bx.x0 + v[0] * dx, bx.y0 + v[1] * dy, bx.z0 + v[2] * dz)), d = pts.reduce((t, p) => t + p[2], 0) / 4;
        polys.push({ d, id: bx.id, h: `<polygon data-e3="${bx.id}" points="${pts.map(p => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ")}" fill="${mix(base, lum)}" fill-opacity="${bx.op}" stroke="${sel ? "#b35c00" : "rgba(20,40,75,.55)"}" stroke-width="${sel ? 1.6 : .6}" stroke-opacity="${bx.op < 1 ? .5 : 1}" style="cursor:pointer"/>` });
      });
    });
    polys.sort((a, c) => c.d - a.d);
    const gr = [[0, 0, 0], [g.SX, 0, 0], [g.SX, g.SY, 0], [0, g.SY, 0]].map(v => P(v[0], v[1], v[2]));
    let h = `<polygon points="${gr.map(p => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ")}" fill="#f3efe6" stroke="#c8bfa8" stroke-dasharray="4 3"/>`;
    sc.lines.forEach(l => { const a = P(l.x0, l.y0, l.z), c = P(l.x1, l.y1, l.z); h += `<line data-e3="${l.id}" x1="${a[0].toFixed(1)}" y1="${a[1].toFixed(1)}" x2="${c[0].toFixed(1)}" y2="${c[1].toFixed(1)}" stroke="${(Array.isArray(o.sel) ? o.sel.includes(l.id) : o.sel === l.id) ? "#ff9f1c" : "#8a94a6"}" stroke-width="${o.sel === l.id ? 4 : 2.2}" stroke-dasharray="5 4" opacity="${l.op}" style="cursor:pointer"/>`; });
    h += polys.map(p => p.h).join("");
    sc.pts.forEach(p => { const a = P(p.x, p.y, p.z); h += `<circle data-e3="${p.id}" cx="${a[0].toFixed(1)}" cy="${a[1].toFixed(1)}" r="8" fill="rgba(255,255,255,.85)" stroke="#14284b" stroke-dasharray="2 2" style="cursor:pointer"/>`; });
    sc.labels.forEach(l => { const a = P(l.x, l.y, l.z); h += `<text x="${a[0].toFixed(1)}" y="${(a[1] + 4).toFixed(1)}" text-anchor="middle" font-size="12" font-weight="700" fill="#14284b" pointer-events="none">${l.t}</text>`; });
    return `<svg id="exbs-3d" viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;max-height:58vh;background:linear-gradient(#eef3fb,#fff);border:1px solid #d5dae1;touch-action:none;user-select:none">${h}</svg>`;
  }
  const PRE = { iso: { yaw: -.6, pit: .55 }, top: { yaw: 0, pit: Math.PI / 2 - .001 }, front: { yaw: 0, pit: .02 }, side: { yaw: Math.PI / 2, pit: .02 }, back: { yaw: Math.PI, pit: .3 } };
  root.EXB3 = { scene, svg, fit, PRE };
})(typeof window !== "undefined" ? window : globalThis);
