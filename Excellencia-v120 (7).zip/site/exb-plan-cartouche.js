/* Excellencia Building V140 — Plan Editor : mise en page des plans PDF dans le cartouche de l'entreprise,
 * avec QR de vérification et QR de téléchargement du PDF (en cas de perte du document).
 * Le module vit dans plan-cartouche/index.html (cadre de la page, même origine) : il lit l'identité (EXBId), les projets (exb_projects),
 * le registre de vérification (EXBVerif) et la connexion serveur (exbSb). Aucune fonction existante n'est modifiée.
 * Pour retirer le module : supprimer la balise <script src="exb-plan-cartouche.js"> de index.html. */
(function (w, d) {
  'use strict';
  var URL_ED = 'plan-cartouche/index.html', $ = function (i) { return d.getElementById(i); };
  /* V140+V129 : exbStorage est déclaré avec « const » dans index.html donc absent de window : le cadre (window.parent.exbStorage)
     ne voyait ni les projets ni le registre de l'application. On l'expose (même objet, aucune copie). */
  function exposeStorage() { try { if (!w.exbStorage && typeof exbStorage !== 'undefined') w.exbStorage = exbStorage; } catch (e) { /* inaccessible */ } }
  exposeStorage();
  function css() {
    if ($('exbPlanCartCss')) return; var s = d.createElement('style'); s.id = 'exbPlanCartCss';
    s.textContent = '#planCartouche .pe-wrap{border:1px solid #d5dbe5;border-radius:14px;overflow:hidden;background:#f4f4f4;box-shadow:0 6px 24px #0f2e6618}'
      + '#planCartouche iframe{display:block;width:100%;height:calc(100vh - 150px);min-height:620px;border:0;background:#fff}'
      + '@media(max-width:700px){#planCartouche iframe{height:calc(100vh - 130px);min-height:560px}}';
    d.head.appendChild(s);
  }
  function build() {
    var sec = d.createElement('section'); sec.id = 'planCartouche'; sec.style.display = 'none';
    sec.innerHTML = '<div class="card"><h2>🗂️ Mise en page des plans (Plan Editor)</h2><p class="hint">Importez un plan PDF : il est placé dans le cartouche Excellencia Building avec le QR de vérification et le QR de téléchargement du PDF.</p><div class="pe-wrap"><iframe id="exbPlanCartFrame" title="Plan Editor" loading="lazy" allow="fullscreen"></iframe></div></div>';
    return sec;
  }
  function mount() {
    exposeStorage();
    if ($('planCartouche')) return;
    var ref = $('planEditeur') || $('calcStructure') || $('metreDevis') || $('bureauEtudes') || $('projets'), host = d.querySelector('.wrap') || d.querySelector('main') || d.body, sec = build(); css();
    if (ref && ref.parentNode) ref.parentNode.insertBefore(sec, ref.nextSibling); else host.appendChild(sec);
    var anchor = $('bplanedit') || $('bbet') || $('bdev'), par = anchor && anchor.parentNode;
    if (par && !$('bplancart')) { var b = d.createElement('button'); b.id = 'bplancart'; b.type = 'button'; b.textContent = '🗂️ Mise en page des plans'; b.setAttribute('onclick', "show('planCartouche')"); par.insertBefore(b, anchor.nextSibling); }
    var os = w.show;
    if (typeof os === 'function' && !w.__exbPlanCartShow) {
      w.__exbPlanCartShow = 1;
      w.show = function (x) {
        var r = os.apply(this, arguments), e = $('planCartouche');
        if (e) {
          e.style.display = (x === 'planCartouche') ? '' : 'none';
          if (x === 'planCartouche') { var f = $('exbPlanCartFrame'); if (f && !f.getAttribute('src')) f.setAttribute('src', URL_ED); else if (f) { try { var E = f.contentWindow.EXBPLANCART; if (E && E.refresh) E.refresh(); } catch (er) {} } }
        }
        var b2 = $('bplancart'); if (b2) b2.classList.toggle('active', x === 'planCartouche'); return r;
      };
    }
  }
  w.EXBPLANCARTOUCHE = { open: function () { exposeStorage(); if (!$('planCartouche')) mount(); if (typeof w.show === 'function') w.show('planCartouche'); try { w.scrollTo(0, 0); } catch (e) {} }, version: 'V140' };
  function start() { setTimeout(mount, 900); }
  if (d.readyState === 'complete') start(); else w.addEventListener('load', start);
})(window, document);
