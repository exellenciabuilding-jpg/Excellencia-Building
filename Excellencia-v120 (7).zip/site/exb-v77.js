/* Excellencia Building V77 — limites V76 : adresse des QR, scanner intégré, récurrence au démarrage,
 * photos vers Supabase Storage, statuts de réserve levée configurables. Aucun fichier existant n'est réécrit. */
(function(w,d){'use strict';
var LS=w.localStorage,A='exb_v77_base',P='exb_v77_pending',S='exb_v77_lifted',U='exb_v77_printed';
function g(k,f){try{return LS.getItem(k)||f}catch(e){return f}}
function s(k,v){try{LS.setItem(k,v)}catch(e){}}
function norm(x){return String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()}
function say(m,t){try{if(w.toast)return w.toast(m,t)}catch(e){}console.log(m)}

/* 1) Adresse permanente des étiquettes : si définie, les QR pointent dessus (domaine fixe) et non sur l'adresse du moment. */
w.EXB77={
 base:function(){return g(A,'')},
 setBase:function(u){u=String(u||'').trim().split('#')[0];if(u&&!/^https:\/\//i.test(u)){say('L’adresse doit commencer par https://','warn');return false}s(A,u);return true},
 printedBase:function(){return g(U,'')},
 markPrinted:function(){s(U,this.base()||location.href.split('#')[0])},
 stale:function(){var p=g(U,'');return !!p&&p!==(this.base()||location.href.split('#')[0])},
 /* statuts « réserve levée » : liste modifiable, comparée sans accents ni casse */
 liftedWords:function(){return g(S,'clôtur,lev,solde,résolu,résolue,fermé').split(',').map(norm).filter(Boolean)},
 setLiftedWords:function(t){s(S,String(t||''))},
 isLifted:function(st){var n=norm(st);return this.liftedWords().some(function(k){return n.indexOf(k)>=0})}
};
/* Redirige les liens générés par V76 vers l'adresse permanente, et mémorise l'adresse utilisée à l'impression. */
var oHref=Object.getOwnPropertyDescriptor(Location.prototype,'href');
function patchLabels(){
 var btn=d.getElementById('v76pr');if(btn&&!btn.__v77){btn.__v77=1;var o=btn.onclick;btn.onclick=function(e){w.EXB77.markPrinted();return o&&o.call(this,e)}}
 var box=d.getElementById('exbV76Lab');if(box&&!box.__v77){box.__v77=1;
  var bar=box.querySelector('.noprint');if(bar){var b=d.createElement('button');b.className='muted';b.textContent='🔗 Adresse permanente';
   b.onclick=function(){var u=prompt('Adresse https:// FIXE du site (domaine personnalisé). Les QR l’utiliseront. Vide = adresse actuelle.',w.EXB77.base());if(u===null)return;if(w.EXB77.setBase(u))say('Enregistré : fermez puis rouvrez « Étiquettes QR ».')};bar.appendChild(b)}
  if(w.EXB77.stale()){var warn=d.createElement('div');warn.className='noprint';warn.style.cssText='background:#fde8e8;border:1px solid #c0392b;padding:8px;margin-bottom:8px;font:13px Arial';warn.textContent='⚠ Les étiquettes déjà imprimées pointent vers une autre adresse : réimprimez-les.';box.insertBefore(warn,box.children[1]||null)}}}

/* 2) Lien reçu avant connexion / synchronisation : on le garde et on l'ouvre dès que l'équipement est disponible. */
function keepHash(){var m=/#asset=([^&]+)/.exec(location.hash||'');if(m)s(P,m[1])}
function resume(){var c=g(P,'');if(!c)return;try{var code=decodeURIComponent(c);var a=JSON.parse(LS.getItem('exb_facility_assets')||'[]');
 if(Array.isArray(a)&&a.some(function(x){return x.code===code})){LS.removeItem(P);location.hash='asset='+c;w.dispatchEvent(new HashChangeEvent('hashchange'))}}catch(e){}}

/* 3) Scanner intégré (BarcodeDetector + caméra). Non disponible sur tous les navigateurs : repli = saisie du code. */
function openAsset(txt){var m=/#asset=([^&\s]+)/.exec(txt)||/EXB-ASSET:(\S+)/.exec(txt);if(!m){say('QR non reconnu','warn');return false}
 location.hash='asset='+(/^%/.test(m[1])||/#asset=/.test(txt)?m[1]:encodeURIComponent(m[1]));w.dispatchEvent(new HashChangeEvent('hashchange'));return true}
w.EXB77.scan=async function(){
 var box=d.createElement('div');box.style.cssText='position:fixed;inset:0;z-index:100001;background:#000;color:#fff;display:flex;flex-direction:column;align-items:center;padding:12px';
 box.innerHTML='<video playsinline muted style="width:100%;max-width:480px;border-radius:12px"></video><p id="v77m" style="font:14px Arial"></p><button class="muted" id="v77m1">Saisir le code</button> <button class="muted" id="v77x">✕ Fermer</button>';
 d.body.appendChild(box);var v=box.querySelector('video'),st=null,run=true,msg=box.querySelector('#v77m');
 function stop(){run=false;try{st&&st.getTracks().forEach(function(t){t.stop()})}catch(e){}box.remove()}
 box.querySelector('#v77x').onclick=stop;
 box.querySelector('#v77m1').onclick=function(){var c=prompt('Code de l’équipement :');if(c){stop();openAsset('EXB-ASSET:'+c.trim())}};
 if(!('BarcodeDetector' in w)){msg.textContent='Scanner non pris en charge par ce navigateur : utilisez l’appareil photo du téléphone ou saisissez le code.';return}
 try{var det=new w.BarcodeDetector({formats:['qr_code']});st=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}});v.srcObject=st;await v.play();msg.textContent='Visez le QR de l’équipement…';
  (function tick(){if(!run)return;det.detect(v).then(function(r){if(r&&r.length&&openAsset(r[0].rawValue)){stop();return}setTimeout(tick,250)}).catch(function(){setTimeout(tick,500)})})()}
 catch(e){msg.textContent='Caméra refusée ou indisponible : saisissez le code.'}};
function addScanBtn(){var p=d.getElementById('exbV74Panel');if(!p||p.querySelector('#v77scan'))return;var b=d.createElement('button');b.id='v77scan';b.className='primary smallbtn';b.textContent='📷 Scanner un QR';b.onclick=function(){w.EXB77.scan()};p.insertBefore(b,p.firstChild)}

/* 4) Récurrence de rattrapage : local (V76) + serveur (fonction SQL V77) à l'ouverture et au retour en ligne. */
function catchUp(){try{if(w.EXBFM)w.EXBFM.catchUp()}catch(e){}
 try{var m=w.EXBDB&&w.EXBDB._meta&&w.EXBDB._meta();if(m&&m.org&&w.exbSb&&navigator.onLine)w.exbSb.api('/rest/v1/rpc/exb_generer_recurrences',{method:'POST',body:JSON.stringify({p_org:m.org})}).catch(function(){})}catch(e){}}

/* 5) Photos : envoi vers le bucket « exb-photos » (appelé par exb-db.js avant chaque enregistrement), lecture par lien signé. */
function toBlob(u){return fetch(u).then(function(r){return r.blob()})}
w.EXB77.pushPhotos=async function(org,col,rec){
 if(!rec||!Array.isArray(rec.photos)||!navigator.onLine||!w.exbSb)return 0;var n=0;
 for(var i=0;i<rec.photos.length;i++){var p=rec.photos[i];if(typeof p!=='string'||p.indexOf('data:image')!==0)continue;
  try{var bl=await toBlob(p),path=org+'/'+col+'/'+String(rec.id||'x').replace(/[^\w.-]/g,'_')+'-'+i+'-'+Date.now().toString(36)+'.jpg';
   await w.exbSb.api('/storage/v1/object/exb-photos/'+path,{method:'POST',headers:{'Content-Type':'image/jpeg','x-upsert':'true'},body:bl});
   cache[path]=p;rec.photos[i]='sb:'+path;n++}catch(e){/* bucket absent ou hors ligne : la photo reste dans l'appareil */}}
 return n};
var cache={};
w.EXB77.resolve=async function(p){
 if(typeof p!=='string'||p.indexOf('sb:')!==0)return p;var path=p.slice(3);if(cache[path])return cache[path];
 var r=await w.exbSb.api('/storage/v1/object/sign/exb-photos/'+path,{method:'POST',body:JSON.stringify({expiresIn:600})});
 var bl=await toBlob(w.exbSb.cfg().url+'/storage/v1'+r.signedURL);
 return cache[path]=await new Promise(function(ok){var f=new FileReader();f.onload=function(){ok(f.result)};f.readAsDataURL(bl)})};
/* images affichées : <img src="sb:…"> est résolu automatiquement ; PDF : images résolues avant génération */
function fixImgs(){d.querySelectorAll('img[src^="sb:"]').forEach(function(im){var s=im.getAttribute('src');im.removeAttribute('src');w.EXB77.resolve(s).then(function(u){im.src=u}).catch(function(){im.alt='photo indisponible'})})}
function wrapPdf(){if(!w.EXBPdf||w.EXBPdf.__v77)return;w.EXBPdf.__v77=1;var o=w.EXBPdf.make;
 w.EXBPdf.make=async function(opt){if(opt&&Array.isArray(opt.images)){var out=[];for(var i=0;i<opt.images.length;i++){try{out.push(await w.EXB77.resolve(opt.images[i]))}catch(e){}}opt=Object.assign({},opt,{images:out})}return o.call(this,opt)}}
/* réglage des statuts de réserve levée (bouton ajouté au panneau Réception) */
function liftBtn(){var p=d.getElementById('exbV76RecPanel');if(!p||p.querySelector('#v77lift'))return;var b=d.createElement('button');b.id='v77lift';b.className='muted smallbtn';b.textContent='⚙ Statuts « réserve levée »';
 b.onclick=function(){var v=prompt('Mots-clés séparés par des virgules. Un statut les contenant = réserve levée (accents et majuscules ignorés).',w.EXB77.liftedWords().join(','));if(v!==null){w.EXB77.setLiftedWords(v);say('Enregistré.')}};
 var h=p.querySelector('div,h3')||p;h.appendChild(b)}
w.EXB77.quota=function(){try{var t=0;for(var k in LS)if(LS.hasOwnProperty(k))t+=(LS[k]||'').length*2;return Math.round(t/1048576*10)/10}catch(e){return 0}};
function quotaWarn(){var m=w.EXB77.quota();if(m>4&&!w.__v77q){w.__v77q=1;say('Stockage de l’appareil : '+m+' Mo sur ~5. Synchronisez pour libérer de la place.','warn')}}

function init(){keepHash();resume();catchUp();quotaWarn()}
w.addEventListener('hashchange',keepHash);
var __v77t=0;new MutationObserver(function(){if(__v77t)return;__v77t=setTimeout(function(){__v77t=0;patchLabels();addScanBtn();liftBtn();fixImgs();wrapPdf()},120)}).observe(d.documentElement,{childList:true,subtree:true});
w.addEventListener('online',function(){resume();catchUp()});
d.addEventListener('DOMContentLoaded',init);if(d.readyState!=='loading')setTimeout(init,800);
})(window,document);
