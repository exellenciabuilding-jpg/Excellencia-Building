# V128g — Participants : seulement la liste « ont payé / n'ont pas payé »

Base : V128f. Seul le logiciel central (dossier `site`) est modifié : exb-v99i-paiements-apprenants.js, sw.js (cache v128g). Aucun SQL.

## Ce qui change (👤 Participants › 💰 Paiements (qui a payé ?))
- Deux listes **côte à côte, en lecture seule** : **✅ Ont payé** (inscription ET formation payées) à gauche, **❌ N'ont pas payé** à droite.
- Dans la liste « N'ont pas payé », une étiquette indique pourquoi : « Aucun reçu », « Inscription non payée », « Formation : moitié payée » ou « Formation non payée ». Les compteurs sont dans les titres.
- Recherche, filtre par formation, export Excel (CSV) et impression PDF conservés.
- **Supprimés de cet écran** : le bouton « 🧾 Reçu » et les boutons de changement de statut (Inscr. payée, Moitié, Payé en totalité, Non payé, Historique). Les reçus se font **uniquement** dans 🧾 Reçus de paiement ; la liste se met à jour toute seule d'après les reçus enregistrés.
- Le statut se calcule comme avant : dernier reçu de l'apprenant (ou, pour les anciens, la saisie manuelle déjà enregistrée). Le paiement Mobile Money confirmé dans 🌐 Site vitrine met toujours le statut à jour.
- Les badges 💰 sous la formation dans la liste des participants sont inchangés.

## Vérifié
`node tools/check.js` : 542 contrôles, 0 échec. Test navigateur (écran de téléphone 390 px, `tools/e2e-paiements-listes.py`) : 4 apprenants répartis correctement (1 / 3), aucun bouton de reçu ni d'action, pas de débordement. Non testé avec vos vraies données.

## Après publication
Redéployer `site` sur Netlify ; fermer complètement l'application une fois (cache v128g). Retour en arrière : restaurer exb-v99i-paiements-apprenants.js et sw.js de la V128f.
