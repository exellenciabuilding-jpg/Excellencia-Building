# V140 — Plan Editor intégré à la V129 (portail clients) — un seul chemin

Base : **V129 (portail plans publics)**. Rien n'est retiré ni dupliqué : le QR de téléchargement utilise le portail V129 (`/plan`, référence + code d'accès, fonction serveur `plan_public_publier`, espace `exb-plans-publics`). **Aucune nouvelle migration SQL** (celle de V129 suffit ; ma première version avait son propre `plan.html` et son propre espace : supprimés).

## Ce que fait le module (menu « 🗂️ Mise en page des plans »)
1. Import d'un plan PDF → mise en page dans le cartouche Excellencia (3 modèles, A0–A4, auto ou ajusté), plan conservé en **vectoriel**.
2. Cartouche rempli depuis l'identité de l'entreprise et le projet choisi (projet + maître d'ouvrage).
3. **QR 1 – vérification** : registre de vérification existant (« Plan architectural », statut, ancienne version, annulé).
4. **QR 2 – téléchargement** = lien du portail V129 `/plan?ref=…&k=…` : le client voit la fiche + aperçu et télécharge le PDF.
5. À l'export (connecté ☁️, projet choisi) : le serveur attribue la **référence EXB-AAAA-NNN + code** → ce **même numéro** est imprimé dans le cartouche, utilisé par le portail, la vérification et le fichier ; le PDF final est envoyé au portail **et rangé dans 🗂 Plans & fichiers CAO** (même chemin que « Envoyer vers Plans », indices A, B… automatiques). Réexporter un nouvel indice avec la même référence garde le **même QR de téléchargement** (le portail montre la dernière version).
6. Registre des plans émis : liens, annulation (vérification « ANNULÉ » + retrait du portail). Retélécharger/republier : 🌐 dans Plans & fichiers CAO.
- Hors connexion : l'export propose de continuer **sans QR 2** (référence locale EXB-AAAA-NNN). Le QR 2 exige la connexion car le code est attribué par le serveur.

## Mise en service
1. Déposer le contenu de `site/` dans `site/` de la V129 (mêmes chemins). Modifiés : `index.html` (1 balise), `sw.js` (cache v140 + nouveaux fichiers), `exb-verif.js` et `verification.html` (libellé « Plan architectural »).
2. Si pas déjà fait : exécuter `supabase/migration-v129-plans-publics.sql`. Redéployer Netlify, rouvrir l'application une fois.
- Limites/sécurité : celles de V129 (100 Mo, 50 Mo en compte gratuit ; toute personne ayant le QR a l'accès ; le retrait le coupe).

## Vérifié
Chromium, serveur simulé : export réel d'un plan A1 (simple, /Rotate 90, CropBox décalé), PDF valide, texte du plan conservé, 2 QR décodés (QR 2 = `/plan?ref=EXB-2026-007&k=…`), séquence réservation → envoi → rangement dans Plans → finalisation avec la même référence ; `tools/check.js` sans échec sur la V129 + ce paquet.
**Non testé** : vrai Supabase / SQL V129 avec ce flux (réservation avant envoi du fichier), APK/Windows, téléphone, gros fichiers. Si l'envoi échoue après réservation, la référence réservée est retirée automatiquement.
