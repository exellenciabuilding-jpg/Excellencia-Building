# V141d — Message d'accueil du portail client (/plan)

Le portail de vérification et de téléchargement des plans affiche d'abord le message d'accueil du site vitrine : « Bienvenue chez EXCELLENCIA BUILDING », devise « Concevoir · Construire · Transmettre », « Architecture · Ingénierie · Réalisation », « Construire aujourd'hui un avenir meilleur. », puis le bouton « Accéder à mon plan » qui mène à la zone de scan et de saisie.

- Lien QR avec référence et code : l'accueil reste visible en version réduite et le plan s'affiche aussitôt.
- Fichiers modifiés : `site/plan.html`, `site/sw.js` (fermer complètement l'application une fois après le déploiement).
- Polices : Impact/Anton si présentes, sinon police système (aucune police externe chargée).

## V141e — logo officiel et slogan
Logo fidèle (immeuble, grue, vague bleue et or) dans l'en-tête et le pied du portail et de l'éditeur de plans : `site/assets/carte/logo-excellencia-icone.png` (emblème) et `site/assets/carte/logo-officiel.jpg` (logo complet, utilisé par défaut dans le cartouche et l'export PDF). Slogan partout : « L’excellence au cœur de vos constructions » (remplace « From Vision to Reality » et « Bâtir avec Excellence… »). Fichiers : `site/plan.html`, `site/plan-cartouche/app.js`, `site/plan-cartouche/index.html`, `site/exb-plans-publics.js`, `site/sw.js`.

## V141f — deux corrections
1. Portail `/plan` : le lien « Accueil » reste sur le message d'accueil du portail (ancre `#accueil`) au lieu d'ouvrir le logiciel.
2. Espace client « Le service n'est pas configuré » : l'édition client de `strip-owner.js` vide `supabase-config.js`. Pour le site d'Excellencia Building lui-même, le zip Netlify garde le projet Supabase d'Excellencia (clé publique seulement). Ne pas utiliser ce zip pour un autre client : lui donner son propre projet Supabase.

## V141g — site Netlify d'Excellencia Building = édition ADMINISTRATEUR
Le zip Netlify de votre propre site garde les outils administrateur (générateur de licences `exb-generator.html`, bouton 🔑, espace propriétaire, Déconnexion, panneau licences/comptes) et votre projet Supabase. Aucune clé privée n'est dans les fichiers : elle se saisit au moment de l'utilisation. Ne jamais déposer ce zip pour un autre client (pour lui : workflow « Site Netlify » = édition client).

## V141h — nouvelle adresse Netlify
Adresse publique : `https://excellenciabuildingsarlu001.netlify.app` (remplace `excellenciabuildingsarlu01`). Mise à jour dans le logiciel (`exb-brand.js`, `exb-verif.js`, `exb-vitrine.js`, `carte-visite.html`, `tfl-portail.html`), le site vitrine (`site-vitrine/config.json` et `index.html`), le scanner (`scanner-apk/www/index.html`), le serveur PDF (`docengine-server`) et les tests. L'ancienne adresse reste reconnue pour réécrire les anciens liens.
Penser aussi à : Identité de l'entreprise › Adresse en ligne ; Supabase › Authentication › URL Configuration (Site URL) ; redéployer le site vitrine.
