# V125 — Pièces écrites côté architecture (même éditeur, même PDF que le chantier)

## Où
Menu latéral : **🏛️ Pièces d'architecture**, juste sous « 🧩 Architecture & diagnostic ». Les « 📂 Documents de chantier » et les « ✍️ Pièces écrites » restent en place ; tout partage le même stockage et le même éditeur à onglets.

## Familles (11) et 25 nouveaux modèles
- 🏛️ Notices et mémoires d'architecture (7) : notice descriptive, note d'intention, programme, sécurité incendie, accessibilité, performance environnementale, principes constructifs.
- 🧭 Mission de maîtrise d'œuvre (6) : contrat, avenant, note d'honoraires, validation de phase, planning de mission, bordereau de remise.
- 📑 Autorisations et dossiers administratifs (6) : lettre de dépôt, notice de demande d'autorisation de bâtir, attestation de l'architecte, ouverture de chantier, achèvement des travaux, demande d'avis.
- ✅ Visa, contrôle et réception (6) : visa de plans, fiche d'observations, approbation de matériaux, rapport de visite, réserves, levée des réserves.
- Lettres (+2) et comptes rendus (+1) de conception ; les familles comptes rendus, lettres, contrats, attestations, notes, CCTP/CCAP et texte libre sont communes avec le chantier.
Un clic sur un modèle crée la pièce (numérotation NDA / MOE / AUT / VIS, données du projet pré-remplies) et l'ouvre dans l'éditeur. PDF officiel bleu et or, QR de vérification, signature (contrat de maîtrise d'œuvre : les parties ; autres : Directeur Général).

## Fichiers
Nouveaux : site/exb-v125-pieces-architecture.js (types et modèles), site/exb-v125-docs-architecture.js (hub).
Modifiés : site/exb-v122-docs-chantier.js (le hub accepte plusieurs « domaines » ; comportement chantier inchangé), site/index.html, site/sw.js.
Retour en arrière : retirer les 2 balises <script> exb-v125-* de index.html.

## Vérifié / non vérifié
Vérifié dans Chromium : bouton placé sous Architecture, hub chantier inchangé, 11 familles, création et ouverture dans l'éditeur, retour au hub architecture, 25 modèles rendus sans erreur, page PDF d'un contrat de maîtrise d'œuvre (titre, signatures, QR).
Non vérifié : fichier PDF final enregistré, Android, Windows, texte des modèles relu par un juriste / un architecte agréé (règles d'urbanisme, honoraires et sécurité propres à chaque pays à adapter).
