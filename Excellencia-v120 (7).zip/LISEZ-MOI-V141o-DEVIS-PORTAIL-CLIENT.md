# V141o — Devis sur le portail client (QR + référence + code → le client télécharge son PDF)

## Ce que ça fait
Comme pour les plans, mais pour les **devis** :
1. Vous générez le devis en PDF (Métré/Devis → « PDF », ou « Suivi / envoi »).
2. Le logiciel le **publie automatiquement** sur le portail client (même page `/plan`) : le serveur donne une **référence EXD-AAAA-NNN** et un **code d'accès**.
3. Au lieu d'envoyer le PDF, vous envoyez au client **le QR / le lien** : il scanne (ou saisit référence + code), voit son devis (client, projet, montant, validité, aperçu) et **télécharge son PDF**.

Dans la fiche **Suivi et envoi** d'un devis :
- **🌐 QR / lien client** : affiche le QR, la référence, le code, le lien ; boutons Copier, WhatsApp, E-mail, QR (PNG), **🖨 Imprimer la fiche QR** (fiche A4 « Votre devis », à remettre au client), liste des devis publiés.
- **WhatsApp (lien)** et **E-mail (lien)** envoient le lien du portail (au numéro / à l'adresse du client). Si le portail est indisponible, ils reviennent à l'ancien envoi du PDF.
- **Envoyer le PDF** : inchangé (envoi direct du fichier).
- **Suivi des devis → 🌐 Devis publiés** : liste, QR / lien, **Retirer** (le client ne peut plus rien télécharger), case « Publier automatiquement chaque devis ».

## Règles
- Un devis = une seule publication. Regénérer le même devis **garde la même référence et le même code** (le QR déjà remis reste valable) : seul le PDF est remplacé. Un PDF inchangé n'est pas renvoyé.
- Hors connexion : le PDF est gardé sur l'appareil et **publié tout seul** au retour de la connexion (comme les autres documents, V114).
- Il faut être connecté au serveur (☁️) et avoir le droit « devis » (écriture). Sinon le PDF se génère normalement, sans publication.
- Sécurité : le QR contient référence + code, jamais le PDF ; le PDF est dans un dossier au nom aléatoire (32 caractères), révélé seulement si référence + code sont corrects. Quiconque a le QR peut télécharger le devis : le retrait coupe l'accès.

## À faire de votre côté (dans l'ordre)
1. Supabase › SQL Editor : exécuter **`site/supabase/migration-v141o-devis-publics.sql`** (une fois ; réexécutable ; ne touche pas aux plans).
2. Déposer le ZIP sur GitHub / redéployer `site` sur Netlify (la page `/plan` sert les plans ET les devis).
3. Premier essai : générer un devis en PDF connecté (☁️) → message « Devis … publié sur le portail client » → fiche « Suivi et envoi » → 🌐 QR / lien client.
Si le SQL n'est pas exécuté, le logiciel l'indique (« Fonction serveur absente… ») et les PDF se génèrent quand même.

## Fichiers
Nouveaux : `site/exb-devis-publics.js`, `site/supabase/migration-v141o-devis-publics.sql`, `site/tools/e2e-devis-publier.py`, `site/tools/e2e-devis-portail.py`.
Modifiés : `site/exb-docs.js` (publication auto + boutons), `site/exb-plans-publics.js` (fiche QR réutilisable), `site/plan.html` (affiche un devis), `site/index.html`, `site/sw.js`.

## Vérifié ici
- `node tools/check.js` : 545 contrôles, 0 échec.
- `tools/e2e-devis-publier.py` : 26/26 (vrai PDF de devis généré, envoi, republication sans doublon, WhatsApp/e-mail avec lien, fiche QR, liste, retrait, publication auto désactivable, hors connexion → reprise, SQL absent → message clair, aucune erreur JS).
- `tools/e2e-devis-portail.py` : 13/13 (page client avec une référence EXD-, mauvais code, saisie manuelle, téléchargement, mobile 390 px).
- Tests des plans existants : 15/15 et 15/15 (aucune régression).
**Non testé** : le script SQL (pas de Postgres ici : relisez les messages à l'exécution), l'envoi réel vers votre Supabase, un vrai téléphone, l'application Windows/Android.
