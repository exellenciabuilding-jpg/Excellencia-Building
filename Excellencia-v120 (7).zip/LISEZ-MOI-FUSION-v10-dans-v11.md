# Fusion : dernières modifications de la v10 appliquées à la v11

La v10 contenait deux modifications absentes de la v11 :
- **V144i** — format de page et orientation pour les documents de l'entreprise (Centre documentaire : listes « Format de page » / « Orientation » dans le générateur et dans le formulaire de modèle ; lecture des options `page_size` / `page_orientation` dans docengine).
- **V144j** — serveur documentaire : `sanitizeOptions` conserve désormais `page_size` / `page_orientation` (le PDF serveur restait en A4 portrait) ; test ajouté.

## Fichiers repris de la v10
- site/docengine/centre.js, site/docengine/core.js
- docengine-server/lib/service.js, docengine-server/tests/engine.test.js
- site/calcul-structure/README-V122-ANALYSE-ROBOT.md (sections V144i et V144j)
- site/sw.js : V144j et V144i ajoutés à l'identifiant de cache (sans toucher à v153/v152/v151)

## Conservé de la v11 (non modifié)
V127 / V127b / V127c : templates-modules.js, exb-v127-exemples*.js, index.html (balises script V127), LISEZ-MOI-V127-….

Aucun doublon : chaque modification n'apparaît qu'une fois.
Non vérifié : tests serveur (dépendance pdfjs-dist absente ici) et rendu PDF réel ; contrôle de syntaxe JS effectué.
