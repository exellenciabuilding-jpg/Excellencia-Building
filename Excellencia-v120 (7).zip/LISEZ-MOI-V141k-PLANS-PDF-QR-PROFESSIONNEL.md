# V141k — Plans (module Architecture) : PDF qui sortent enfin sous Windows + fiche QR professionnelle

## Les problèmes
1. Éditeur de plans (🏗 CAO/DAO) : le bouton « Imprimer » (et, en cas d'échec, « PDF ») imprimait un cadre caché → boîte d'impression Windows avec page BLANCHE.
2. Plans publiés aux clients : « 🖨 Imprimer le QR » ouvrait une fenêtre pop-up vide (blanche sous Windows).
3. Étiquettes QR des équipements : même écran blanc (corrigé en V141i/j, conservé ici).

## Les corrections
- `plan-editeur/index.html` : dans l'application Windows, « Imprimer » ET « PDF » créent maintenant un PDF VECTORIEL direct
  (texte net, cartouche, légende, échelle graphique, quantités) → « Enregistrer sous » → ouvert dans le lecteur PDF.
  Si ce chemin échouait, l'ancienne méthode (PDF par images) prend le relais. Android et navigateur : inchangés.
- `exb-plans-publics.js` : « Imprimer le QR » produit une **fiche A4 à remettre au client** : bandeau marine + logo + nom de l'entreprise,
  filet doré, titre du dossier de plans, grand QR encadré, référence et code d'accès, 3 étapes « Comment télécharger vos plans »,
  pied de page avec contacts et date. Windows : PDF direct ; Android : impression native ; navigateur : aperçu.
- Étiquettes QR des équipements : PDF professionnel (V141j).
- `sw.js` : cache renouvelé (v141k).

## À faire de votre côté
Déposer le ZIP sur GitHub puis refaire l'installateur Windows. Aucun nouveau SQL.

## Tests effectués ici
- Fiche QR des plans : générée avec la vraie fonction, PDF A4 d'une page, rendu vérifié en image.
- Éditeur de plans : page chargée avec un pont Windows simulé ; les boutons Imprimer et PDF envoient bien le document au PDF direct ; document converti en PDF A3 (cartouche, flèche du nord) — essai sur un plan VIDE.
Non testé ici : application Electron réelle, plan avec murs dessinés, installateur Windows.
Premier essai conseillé sur Windows : Architecture › Éditeur de plans › Imprimer, puis Plans publiés › Imprimer le QR.
