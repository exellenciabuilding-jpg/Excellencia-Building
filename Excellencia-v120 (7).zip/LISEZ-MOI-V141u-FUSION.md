# V141u — FUSION des deux branches V141p / V141t en UNE seule version

Vous aviez deux ZIP qui venaient tous deux de V141o et avaient évolué chacun de leur côté :

| ZIP | Contenu propre |
|---|---|
| **V141p-notes-plans-archivage** | 🗄 **Espace serveur** (archiver en ZIP, libérer la place, restaurer) ; notes de calcul rangées dans la table des devis |
| **V141t** (dossier interne v141r) | Notes de calcul / plans d'exécution sur le **portail client** (table `calcul_publics`), V141q cartouche portrait + formats ARCH A/B, V141r **envoi au chantier**, V141s modules / quantités / accès chantier |

Les deux branches faisaient la même chose pour les notes de calcul (références EXN-/EXE-) mais de façon **incompatible** (deux tables, deux fonctions SQL). On ne pouvait pas simplement les superposer.

## Ce qui a été retenu
- **Base = V141t** (la plus récente et la plus complète) : portail des notes / plans d'exécution dans leur propre table `calcul_publics`, envoi au chantier, cartouche portrait, etc. — inchangés.
- **Ajouté de V141p : l'Espace serveur**, adapté pour couvrir **les 3 familles de publications** : plans, devis, **notes de calcul et plans d'exécution** (nouvelle table `calcul_publics` / espace `exb-calcul-publics`).
- **Abandonné de V141p** (remplacé par V141t) : la publication des notes dans `devis_publics` (genre `note_calcul` / `plan_execution`) et sa migration SQL. **Ne pas exécuter `migration-v141p-notes-plans-archivage.sql`** : elle n'est plus dans ce ZIP.

## Espace serveur (administrateur)
Ouvrir : 🌐 Devis publiés / Plans publiés / Notes de calcul et plans d'exécution publiés › **🗄 Espace serveur**.
- **Jauges** base de données et fichiers (quotas modifiables : 500 Mo / 1 024 Mo par défaut).
- **1. Choisir** : « modifiées il y a plus de 30 jours » + type (plans, devis, notes de calcul, plans d'exécution), ou cocher à la main.
- **2. ZIP** : le logiciel télécharge les fichiers, fabrique le(s) ZIP (parties de ~120 Mo) et **relit chaque ZIP octet pour octet**. Rien n'est supprimé à ce stade.
- **3. Libérer** : possible seulement après téléchargement de tous les ZIP ET confirmation. Le serveur supprime alors les fichiers et l'aperçu en base.
- **La référence, le code et le QR restent valides** : le client voit « document archivé, contactez-nous ».
- **Restaurer depuis un ZIP** : remet le document en ligne avec la même référence et le même code. Un ZIP d'une autre entreprise est refusé.
- Les **documents envoyés au chantier** (espace privé `exb-chantier-docs`) ne sont **pas** concernés : ils ne sont ni listés ni supprimés.
- Supabase : supprimer des *lignes* ne baisse pas tout de suite la jauge « Database size » (nettoyage automatique de Postgres plus tard) ; supprimer des *fichiers* par l'API baisse la jauge « Storage » aussitôt.

## À faire de votre côté (dans l'ordre)
1. Supabase › SQL Editor — exécuter, **dans cet ordre**, ceux que vous n'avez pas déjà exécutés :
   `migration-v141o-devis-publics.sql` → `migration-v141p-calcul-publics.sql` → `migration-v141r-documents-chantier.sql` → **`migration-v141u-archivage.sql`** (nouveau, réexécutable).
   > Si vous aviez déjà exécuté l'ancien `migration-v141p-notes-plans-archivage.sql` (branche archivage), prévenez-moi avant : il a modifié la table des devis.
2. Déposer ce ZIP sur GitHub / redéployer `site` sur Netlify. Fermer complètement l'application une fois (nouvelle version de cache).
3. Essai : se connecter (☁️) avec le **compte administrateur** › 🌐 … publiés › 🗄 Espace serveur.

## Correctif de menu
« 🛰️ Station d'analyse (Robot) » (module de calcul de structure) s'affichait dans **Entreprise** : elle est maintenant classée dans **Ingénierie & Structure** (`site/exb-v99r-shell.js`).

## Fichiers
Nouveaux : `site/exb-espace-serveur.js`, `site/supabase/migration-v141u-archivage.sql`, `site/tools/e2e-archivage.py`.
Modifiés : `site/exb-v99r-shell.js`, `site/index.html` (balise du module), `site/sw.js`, `site/plan.html` (message « document archivé »), `site/exb-plans-publics.js`, `site/exb-devis-publics.js`, `site/exb-calc-publics.js` (bouton 🗄).
Retour en arrière : retirer la balise `<script src="exb-espace-serveur.js">` de `index.html` (le reste fonctionne sans).

## Vérifié ici
- `node tools/check.js` : 548 contrôles, 0 échec.
- `tools/e2e-archivage.py` : 26/26 (jauges, filtre, ZIP vérifié, rien supprimé avant confirmation, suppression dans le bon espace public pour plans / devis / calcul, restauration des 3 familles, ZIP d'une autre entreprise refusé, non-administrateur).
- Non-régression V141t : `e2e-calcul-publier.py` 12/12, `e2e-calcul-portail.py` 19/19, `e2e-calcul-chantier.py` 8/8, `test-chantier-docs.js` 8/8.
**Non testé** : tous les scripts SQL (pas de Postgres ici — relisez les messages à l'exécution ; `migration-v141u-archivage.sql` suppose la table `membres` avec `org_id`, `user_id`, `role='admin'`, comme les droits existants), un vrai Supabase, un téléphone, Windows/Android, l'affichage côté **logiciel chantier** (toujours à faire, voir LISEZ-MOI-V141r). Le message « archivé » côté client est géré pour les devis et les notes / plans d'exécution ; pour un **plan** archivé, la page client affiche le message générique « aucun document disponible (il a peut-être été archivé) ».
