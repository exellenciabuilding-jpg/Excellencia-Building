# V120-4b — Mise en page des pièces écrites et documents de chantier

Valable pour TOUS les modèles (comptes rendus, PV, OS, lettres, rapports, clauses, fiches, contrats, attestations, page de garde du dossier de chantier…).

- Le bloc du Directeur Général (fonction, signature, nom) est toujours en bas de la page, juste au-dessus du QR code / pied de page.
- Texte court : il est centré verticalement au milieu de la page, entre l'en-tête et la signature.
- Le pied de page (barre bleue + QR code) reste collé en bas de CHAQUE page.
- La page 2 vide (en-tête + pied de page seuls) n'est plus produite.
- Texte long (plusieurs pages) : il coule normalement ; la signature suit le texte sur la dernière page (pied de page toujours en bas).

Fichiers modifiés : site/exb-v81-pieces.js (impression Windows/navigateur + PDF local Android), site/docengine/templates-modules.js (PDF serveur).
Après dépôt : fermer complètement l'application / Ctrl+Maj+R (nouvelle version de cache).
Vérifié : rendu Chromium (4 cas), tests docengine, 547 contrôles (1 échec déjà présent : licence-config). Non vérifié : PDF local Android (librairies html2canvas/jsPDF absentes ici) et Windows réel.
