const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs'),path=require('path');
(async()=>{
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:1500,height:1100}});
 p.on('console',m=>{if(m.type()==='error')console.log('console.error:',m.text())});p.on('pageerror',e=>console.log('PAGEERR',e.message));
 await p.goto('http://localhost:8099/hosttest.html');
 const fr=p.frameLocator('#f');await p.waitForTimeout(1200);
 await fr.locator('#fileIn').setInputFiles(path.resolve(__dirname,'plan_a1.pdf'));
 await p.waitForTimeout(1500);
 await fr.locator('#iProj').selectOption('P1');
 await fr.locator('#go').click();await p.waitForTimeout(800);
 await p.screenshot({path:path.resolve(__dirname,'ui.png')});
 await fr.locator('#exp').click();await p.waitForTimeout(3500);
 const r=await p.evaluate(async()=>{const s=window.__saved;let b64=null;if(s){const a=new Uint8Array(await s.b.arrayBuffer());let t='';for(let i=0;i<a.length;i+=8192)t+=String.fromCharCode.apply(null,a.subarray(i,i+8192));b64=btoa(t)}
   return {name:s&&s.n,b64,calls:window.__calls,reg:window.exbStorage.getItem('exb_plan_cartouche_registre'),map:localStorage.getItem('exb_pub_map')}});
 fs.writeFileSync(path.resolve(__dirname,'final.pdf'),Buffer.from(r.b64,'base64'));
 console.log(r.name);r.calls.forEach(c=>console.log(' ',c.p,c.body?JSON.stringify({ref:c.body.p_ref,plan_id:c.body.p_plan_id,ind:c.body.p_indice,ap:!!c.body.p_apercu,tok:c.body.p_token.length,docs:c.body.p_docs[0].taille}):c.size));console.log(r.map,r.reg.slice(0,260));
 await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
