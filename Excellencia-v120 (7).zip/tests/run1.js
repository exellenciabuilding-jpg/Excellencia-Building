const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs');const path=require('path');
(async()=>{
  const b=await chromium.launch();const p=await b.newPage();
  p.on('console',m=>console.log('console:',m.text()));p.on('pageerror',e=>console.log('PAGEERR',e.message));
  await p.goto('file://'+path.resolve(__dirname,'harness.html'));
  for(const [name,rot] of [['plan_a1',0],['plan_rot90',1],['plan_crop',0]]){
    const b64=fs.readFileSync(path.resolve(__dirname,name+'.pdf')).toString('base64');
    const r=await p.evaluate(([b,rot])=>window.run(b,rot),[b64,rot]);
    fs.writeFileSync(path.resolve(__dirname,'out_'+name+'.pdf'),Buffer.from(r.b64,'base64'));
    if(name==='plan_a1')fs.writeFileSync(path.resolve(__dirname,'canvas_preview.png'),Buffer.from(r.png,'base64'));
    console.log(name,'vector',r.vector,r.notes);
  }
  await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
