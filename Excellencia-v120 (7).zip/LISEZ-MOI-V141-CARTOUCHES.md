# V141 — Cartouches personnalisables (Plan Editor)

Base : V140d. Fichiers modifiés (mêmes chemins) :
`site/plan-cartouche/index.html`, `app.js`, `sheet.js`, `pdfout.js` et `site/sw.js` (nouvelle version de cache : fermez complètement l'application une fois après le déploiement).

## Ce qui est nouveau
- **Textes personnalisables** : texte avant le projet (« PROJET : »), sous-titre, slogan, textes sous les QR, texte du filigrane, objet de l'indice, et **tous les libellés** du cartouche (carte 7) : renommer, masquer, réordonner, cellule large ou non, **ajouter vos propres lignes** (Phase, Permis N°, Dessiné par…).
- **Vue 3D du plan** (zone entourée en rouge) : carte 6, image PNG/JPEG/WebP. Elle remplace le dessin d'immeubles, en petit format, avec réglage de taille, position et légende. Intégrée au PDF.
- **Logo ajustable** : taille et position (carte 6). Le logo est découpé au cadre de sa case.
- **Cartouche ajustable** : largeur de la colonne (ou hauteur du bandeau), largeur du bloc, hauteur de l'en-tête et du pied (carte 5).
- **Marques de cartouche** (carte 5, liste « Marque ») : Excellencia (Standard, Compact, Sobre), ISO 7200 (bloc bas-droite, bandeau bas), Architecte style Revit/ArchiCAD (bandeau vertical droit ou gauche, tableau des indices, grand n° de feuille), AutoCAD/ANSI (bandeau bas), **Cartouche libre** (position droite/gauche/bas, colonnes, en-tête, pied, décor).
  Ce sont des dispositions *inspirées* des usages et normes, pas des copies de gabarits officiels.
- **Formats** : ISO A0–A5, A0+, A1+, ISO B0–B4, ANSI A–E, ARCH C/E1/E, et **format personnalisé** (mm). Paysage / portrait / selon le plan, pour toutes les marques.
- Les réglages sont mémorisés (hors images).

## Inchangé
Le modèle « Excellencia Standard » est rendu comme avant. QR de vérification, QR de téléchargement, portail V129, référence serveur, registre : non modifiés.

## Vérifié (Chromium)
9 modèles en paysage, 4 en portrait, formats A0/A3/A4/B2/ANSI D/personnalisé, vue 3D, logo, ligne ajoutée, cartouche libre, export PDF réel (A1, plan vectoriel conservé, vue 3D et logo embarqués), mémorisation après rechargement : aucune erreur JavaScript.
**Non testé** : téléphone, Android/Windows, export avec connexion serveur (QR 2), très grands plans A0 réels.
Note : la phrase « Texte très fin vectoriel 1:100… » sous le plan vient de votre PDF d'essai, pas du cartouche.
Retour en arrière : restaurer les 5 fichiers de la V140d.
