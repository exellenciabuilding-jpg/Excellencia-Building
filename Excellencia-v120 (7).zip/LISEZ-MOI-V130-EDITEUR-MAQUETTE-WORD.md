# V130 — Éditeur de texte : conformité à la maquette + fonctions « vrai Word »

## Écart avec la maquette (constaté)
Déjà conforme (V124) : onglets Fichier/Accueil/Insertion/Mise en page/Références/Révision/Affichage/Aide, groupes Presse-papiers/Police/Paragraphe/Styles/Insertion, règle, feuille avec en-tête société, barre d'état (page, mots, langue, zoom).
Manquait et ajouté ici :
- **Bandeaux bleus** : titre centré sur fond bleu et sections « 1. Introduction » en barre bleue à texte blanc (Styles ▾ → Bandeau titre / Bandeau de section).
- **Image à droite avec texte autour** (boutons ◧ ◨ dans Insertion → Illustrations).
- **Barre d'état** : boutons Plan ☰ et Lecture 📖.
Non refait (hors éditeur) : barre latérale de l'application (Accueil, Formation, Entreprise…), barre de titre avec recherche/notifications/avatar, onglets de documents « Rapport.docx × + ».

## Fonctions Word ajoutées
Trame de fond de paragraphe (couleur au choix, texte blanc automatique sur fond foncé) et retrait · Casse (MAJUSCULES, minuscules, Première Lettre, inverser) · Plan du document (clic sur un titre pour y aller) · Mode lecture · **Exporter en Word (.docx)** (Fichier) : titres, listes à niveaux, tableaux, images, gras/italique/souligné/couleur/surlignage/taille/police, alignement, interligne, bandeaux, saut de page, en-tête société, numéro de page.

## Format de texte (compatible avec l'ancien)
`[bg=#0b4aa8]` en début de ligne = trame de fond ; `[img=35,r]` / `[img=35,l]` = image avec texte autour. Reconnus par l'éditeur, le PDF Windows/Android (exb-v81-pieces.js) et le PDF serveur (templates-modules.js).

## Fichiers
Nouveau : site/exb-v130-docx.js. Modifiés : site/exb-v123-editeur.js, site/exb-v81-pieces.js, site/docengine/templates-modules.js, site/index.html, site/sw.js (cache v154).
Retour en arrière : retirer la balise <script> exb-v130-docx.js (plus d'export Word) ; les autres ajouts sont compatibles avec les anciens textes.

## Vérifié / non vérifié
Vérifié dans Chromium : rendu des bandeaux et de l'image, aller-retour texte → feuille → texte sans repère parasite, casse, mode lecture, export .docx ouvert correctement par python-docx et LibreOffice (titres, listes, tableau, image, trame) ; HTML serveur (bandeau + image flottante).
Non vérifié : import d'un fichier Word (non fait), texte autour des images dans le .docx (image placée en ligne), rendu PDF final, Android, Windows réel. Les tests PDF du serveur (Chromium) ne tournent pas dans cet environnement.
