# V122b+V121j — une seule version
Base : v121j (Intelligence lots 7-8-9, en-têtes de sécurité Netlify, anti-blocage…)
Ajout : v122b (analyse de structure « type Robot » : Portique 2D EF, combinaisons d'actions, contrôle EF du module Poutre).
Fichiers repris de la v122b : site/calcul-structure/ (exb-robot-analyse.js, index.html, validation/), exb-calcul-structure.js, exb-v99r-shell.js, package.json (test:calcul).
Service worker : cache v122b-robot-analyse-v121i-… + exb-robot-analyse.js précaché.

## V124 — Station d'analyse (type Robot) reportée dans cette version
Ajout : moteur exb-robot-analyse.js étendu (modal, spectre EC8, enveloppes, dimensionnement N–M), station d'analyse `exb-robot-station.js` avec palettes fonctionnelles (poteau, poutre, dalle, axes, charges linéaires, annuler/rétablir) et table de configuration des axes. Bouton « Ouvrir la station d'analyse » dans Dimensionnement bâtiment.
Fichiers repris : site/calcul-structure/{index.html, exb-robot-analyse.js, exb-robot-station.js, README-V122-ANALYSE-ROBOT.md, validation/}. Service worker : station précachée, version v124-palettes-axes-…
