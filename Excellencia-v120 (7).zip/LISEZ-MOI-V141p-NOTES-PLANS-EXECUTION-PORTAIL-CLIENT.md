# V141p — Notes de calcul et plans d'exécution sur le portail client (QR + référence + code → le client télécharge son PDF)

## Ce que ça fait
Comme pour les plans (V129) et les devis (V141o), mêmes écrans, même page client `/plan` :
1. Dans **Calcul de structure**, ouvrez une **Note de calcul** (NCS-AAAA-NNN) ou un **Plan d'exécution** (PEX-AAAA-NNN).
2. Dans la fiche « Informations du document » apparaît le bloc **🌐 Portail client** :
   - **Publier — QR / lien client** : crée le PDF, le publie, affiche le QR, la référence (**EXN-AAAA-NNN** pour une note, **EXE-AAAA-NNN** pour un plan d'exécution), le code d'accès et le lien ; boutons Copier, WhatsApp, E-mail, QR (PNG), **🖨 Imprimer la fiche QR** (fiche A4 à remettre au client).
   - **Documents publiés** : liste, QR / lien, **Retirer**, case « Publier automatiquement ».
3. Le bouton **📄 PDF** habituel publie aussi automatiquement le PDF créé (désactivable).
4. Le client scanne le QR (ou saisit référence + code sur `/plan`), voit : projet, maître d'ouvrage, établi par, norme, statut, indice, aperçu, et **télécharge le PDF**.

## Règles
- Un document = une seule publication. Republier le même numéro (changement d'indice, de statut, de nom…) **garde la même référence et le même code** : le QR déjà remis reste valable, seul le PDF est remplacé. Un PDF inchangé n'est pas renvoyé.
- Hors connexion : le PDF est gardé sur l'appareil et publié tout seul au retour de la connexion.
- Il faut être connecté au serveur (☁️) et avoir le droit « plans_fichiers » (écriture) comme pour les plans. Sinon le PDF se génère normalement, sans publication.
- Sécurité identique aux plans/devis : le QR contient référence + code, jamais le PDF ; le PDF est dans un dossier au nom aléatoire (32 caractères) révélé seulement si référence + code sont corrects ; « Retirer » coupe l'accès.
- Le QR de **vérification d'authenticité** déjà imprimé sur la note / le plan (verification.html) est inchangé : c'est un autre QR.
- Le statut affiché au client (Émis / En vérification / Validé / Brouillon…) vient du circuit de validation par ingénieur.

## À faire de votre côté (dans l'ordre)
1. Supabase › SQL Editor : exécuter **`site/supabase/migration-v141p-calcul-publics.sql`** (une fois ; réexécutable ; ne touche ni aux plans ni aux devis).
2. Déposer le ZIP sur GitHub / redéployer `site` sur Netlify (la page `/plan` sert plans, devis, notes et plans d'exécution).
3. Premier essai : ouvrir une note de calcul → « 🌐 Publier — QR / lien client ». Si le SQL n'est pas exécuté, le logiciel l'indique (« Fonction serveur absente… »).

## Fichiers
Nouveaux : `site/exb-calc-publics.js`, `site/supabase/migration-v141p-calcul-publics.sql`, `site/tools/e2e-calcul-portail.py`, `site/tools/e2e-calcul-publier.py`.
Modifiés : `site/calcul-structure/exb-calcul-doc.js` (bloc portail + publication auto), `site/calcul-structure/exb-pdf-direct.js` (options `noSave` / `onBlob`), `site/plan.html` (affiche note / plan d'exécution), `site/index.html`, `site/sw.js`.

## Vérifié ici
- `node tools/check.js` : 546 contrôles, 0 échec.
- `tools/e2e-calcul-portail.py` : 19/19 (page client pour EXN- et EXE-, mauvais code, saisie manuelle, téléchargement, plans EXB- et devis EXD- inchangés, mobile 390 px).
- `tools/e2e-calcul-publier.py` : 12/12 avec le vrai module de calcul (vrai PDF de note de calcul de poutre et de plan d'exécution, serveur simulé : publication, republication sans doublon, nouvel indice = même référence, publication auto après « PDF »).
**Non testé** : le script SQL (pas de Postgres ici : relisez les messages à l'exécution), l'envoi réel vers votre Supabase, un vrai téléphone, l'application Windows/Android, les autres modules de calcul (poteau, dalle, semelle…, même code d'aperçu que la poutre).
**À savoir** : hors licence, le cartouche d'origine des plans affiche « EXCELLENCIA DÉMO » et n'est pas habillé par V99t (comportement existant) : le bloc portail n'apparaît alors pas sur les plans d'exécution.
