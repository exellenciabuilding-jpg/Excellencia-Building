# V128b — Licence : verrouillages à tort, diagnostic affiché, test de bout en bout

Base : V128 (Excellencia-V120c-v128). Ce correctif avait d’abord été préparé sur la V122e ; il est repris ici tel quel (le fichier exb-license.js était identique dans les deux versions). Le tag de cache « v122f » de votre lignée (fusion V121 accès immédiat) n’est pas le mien : cette note s’appelle donc V128b. Les lots 7 (sécurité), 8 (réception des demandes) et 9 étaient **déjà intégrés** dans la V128 : rien à réappliquer, leurs tests passent (33 / 33 / 70).

## Ce qui a été vérifié (nouveau test : `node scripts/test-licence-e2e.mjs`, aussi dans `npm run test:licences`)
Vrai client (`site/exb-license.js`) + vrai serveur (`licence-server/…/core.mjs`), réseau et horloges simulés. Comportements **conformes** : activation par code ; 5 jours hors ligne = ouvert ; 9 jours hors ligne = « vérification requise » (prévu) puis déverrouillage tout seul au retour du réseau, sans recharger ; échéance dépassée puis renouvellement par le propriétaire = déverrouillage automatique (≤ 1 min) ; suspension détectée en ≤ 30 min puis réactivation sans nouveau code. Testé aussi sur l'édition client fabriquée par `build-editions.js`.

## Ce qui a été corrigé (site/exb-license.js)
1. **Vérification jamais relancée après une date d'appareil avancée** : si la date de dernière vérification était dans le futur (date avancée par erreur puis corrigée), le logiciel ne contactait plus le serveur de licences pendant des jours. Il vérifie maintenant tout de suite.
2. **Cause du verrouillage invisible** : la dernière vérification est notée (nature seulement, aucun secret : clé `exb_lic_diag`) et affichée sur l'écran « Logiciel verrouillé », ligne « Diagnostic » : hors ligne ; serveur injoignable (réseau, pare-feu, CORS, fonction non déployée) ; HTTP 401/403 (fonction déployée **avec** contrôle JWT : redéployer avec `--no-verify-jwt`) ; HTTP 404 ; réponse non JSON ; jeton signé par une **autre clé** (clé publique du logiciel ≠ celle du serveur) ; refus du serveur (suspendu, révoqué, appareil inconnu).
3. **Messages d'activation précis** (HTTP 401/403/404/5xx) au lieu de « Activation refusée. » ; le texte « réservé à un autre appareil » (trompeur) devient « appareil non reconnu (données du navigateur effacées, réinstallation, autre adresse du site ?) ».
4. **Écart d'horloge** signalé sur l'écran verrouillé quand la date de l'appareil diffère d'au moins 2 jours de l'heure de confiance.

## Ce qui peut encore bloquer (non modifiable côté client)
- **Identifiant d'appareil perdu** (navigateur qui efface ses données, réinstallation, ouverture par une autre adresse du site : chaque adresse = un « appareil ») alors que les 2 places sont prises : le code est refusé (« limite d'appareils »). Remède actuel : application « Excellencia Licences » › client › libérer l'ancien appareil, ou augmenter le nombre d'appareils. Une libération automatique des appareils non vus depuis N jours est possible côté serveur, mais c'est un choix commercial et il faut redéployer la fonction : non fait.
- Sur votre serveur réel : fonction « licence » non déployée / avec JWT, clé publique différente, SQL non exécuté : non testable ici ; le diagnostic ci-dessus l'affichera.

## Vérifié
`node tools/check.js` (site) · `npm run test:licences` · tests intelligence 7, 8, 9 · `node scripts/build-editions.js` (édition client sans clé privée).
Après publication : fermer complètement l'application une fois (version v128b).
