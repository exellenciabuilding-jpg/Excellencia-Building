# V140d — Station Robot de la V137 reportée dans la V140

Base : V140c (semelle filante / glacis, Plan Editor) + Station Robot de la V137.

## Reporté depuis la V137
- `exb-robot-station.js`, `exb-robot-analyse.js` (diagrammes avec valeurs aux extrema, cadrage), `exb-robot-3d.js` (vue 3D éditable, nouveau fichier).
- Charges G/Q propres à chaque dalle (V139) : `slG`, `slQ`, `slOv`, `scShift` ; prises en compte dans la descente de charges, les poutres, les dalles, la note du bâtiment, le plan coté, le panneau Dalle du module Bâtiment.
- Note de calcul de la station (`stationNote`, V137g) et documents au-dessus de la station (z-index #v3 / #doc / #sh).
- Station Robot autonome : module `robot` (menu Ingénierie & Structure, tuile), plein écran, fermeture à la navigation (`closeOv`, message `leave`).
- `sw.js` : précache de `exb-robot-3d.js`, cache `v140d-station-robot-v137-…`.
- `validation/valider-robot.js` : sections R24 (3D), R30 (charges par dalle), R32, R33 (navigation), R36 (documents).

## Changement de comportement
- Le bouton « Ouvrir la station » du module Bâtiment est retiré (comme en V137) : la station s'ouvre depuis le menu.

## Conservé de la V140
- Glacis, semelle filante, notes de semelle (V140c), Plan Editor / portail des plans.

## Non reporté (hors Station)
Poteau avec vent (V138), béton au feu et rupture en bloc du bois (V139), notes avec modèle (poutre, dalle, semelle, escalier), modules acier/bois, correctifs d'accueil et diagnostic de lenteur.
Note : `exb-robot-analyse.js` contient aussi `poutrePortiqueFE` / `svgEnvPoutre` (V134), inutilisés tant que le module Poutre portique n'est pas reporté.

## Vérifié
`valider-robot.js` 178 contrôles, `valider.js` 111, `test-verif-els.js` 30, `tools/check.js` 544 : 0 écart. Chromium : station, charges par dalle, analyse, note, 3D, plein écran, fermeture à la navigation. Non testé : téléphone, Android/Windows.
Retour en arrière : restaurer la V140c d'origine.
