# V140b — Plan Editor (V140) fusionné dans la V129 : un seul parcours

Base : ma V129 (portail public des plans) + le paquet « V140 Plan Editor ». Un seul dépôt, un seul `site/`, un seul script SQL (`site/supabase/migration-v129-plans-publics.sql`, aucune nouvelle migration).

## Parcours (une seule référence du début à la fin)
1. 🗂️ **Mise en page des plans** : import du plan PDF → cartouche Excellencia (A0–A4), QR de vérification + QR de téléchargement.
2. À l'export (connecté ☁️, projet choisi) : le serveur attribue **EXB-AAAA-NNN + code d'accès** ; ce numéro est imprimé dans le cartouche, utilisé par le portail clients (`/plan?ref=…&k=…`), par le registre de vérification et par le nom du fichier.
3. Le PDF final est envoyé au portail et rangé dans **🗂 Plans & fichiers CAO** (indices A, B, C…).
4. Nouvel indice du même plan : saisir la même référence → même QR de téléchargement, le portail montre la dernière version.
5. Clients : page `/plan` (référence + code, ou QR) ; vous : scanner V1.4 (lien « Plans — portail clients »).
6. **🌐 Plans publiés aux clients** (Plans & fichiers CAO) : liste, QR/lien, retrait.

## Fusion (rien retiré, rien dupliqué)
- Ajoutés : `exb-plan-cartouche.js`, `plan-cartouche/` (éditeur, feuilles, export PDF vectoriel), `pdflib/`. Modifiés : `index.html` (1 balise), `sw.js` (cache v140b + fichiers), `exb-verif.js` et `verification.html` (libellé « Plan architectural »). Le module 🌐 de la V129 (`exb-plans-publics.js`) reste en place ; les deux utilisent la même fonction serveur, le même espace public et la même table de références (exb_pub_map).
- **Correction 1** (`exb-plan-cartouche.js`) : l'éditeur lit les projets et le registre par `window.parent.exbStorage`, qui n'existe pas dans le vrai logiciel (déclaré avec `const`) : la liste des projets restait vide, donc pas de QR de téléchargement possible. Il est maintenant exposé (même objet).
- **Correction 2** (`plan-cartouche/app.js`) : en réexportant un plan déjà publié, les fichiers de la version précédente restaient en ligne sous leur ancienne adresse ; ils sont maintenant supprimés après la finalisation.

## Mise en service
1. Si pas déjà fait : exécuter `supabase/migration-v129-plans-publics.sql` (Supabase › SQL Editor).
2. Redéployer `site` sur Netlify ; fermer complètement l'application une fois (cache v140b).
- Après un export, la liste « Plans & fichiers CAO » s'ouvre par-dessus l'éditeur : la fermer (✕) pour continuer.

## Vérifié
`node tools/check.js` : 544 contrôles, 0 échec. Tests navigateur (serveur simulé) : portail clients 15/15, publication 🌐 15/15, **parcours Plan Editor → réservation → envoi → rangement dans Plans → finalisation → réexport** (`tools/e2e-plan-cartouche-portail.py`) 15/15.
**Non testé** : vrai Supabase et script SQL, gros plans réels (A0, 50 Mo), Android/Windows, téléphone. Les tests de la V140 (`tests/`) dépendent de fichiers non fournis (plan_a1.pdf, hosttest.html) : non rejoués.
