# V123 — Éditeur « façon Word » pour les pièces écrites et les documents de chantier

Où : ✍️ Pièces écrites et 📂 Documents de chantier → ouvrir un document (lettre, compte rendu, PV, OS, rapport, clause, fiche, contrat, attestation, dossier…).

## Ce que vous voyez
Une feuille A4 que vous modifiez directement, avec un ruban :
- ↶ ↷ annuler / rétablir (aussi Ctrl+Z / Ctrl+Y) ; Ctrl+S enregistre
- Style (texte normal, titre, sous-titre, intertitre) · Police · Taille (8 à 72) · A+ / A−
- Gras, italique, souligné, couleur du texte
- Alignement : gauche, centré, droite, justifié
- Liste à puces / numérotée · ▦ Tableau (+ ligne, − ligne, + colonne, − colonne) · ― séparateur · ⤓ saut de page
- {{ }} Donnée : insère une donnée du chantier (projet, client, lieu, DG…) · Tx efface la mise en forme
- Zoom ajusté automatiquement à l'écran (téléphone compris) ; « ⌨ Mode texte » ramène l'ancienne zone de texte brute.
Sans texte sélectionné, police / taille / couleur s'appliquent au paragraphe courant.

## Compatibilité
Le texte reste enregistré dans le même champ qu'avant ; tous les anciens modèles s'ouvrent dans l'éditeur sans perte (aller-retour vérifié).
Nouveaux repères reconnus par les PDF (Windows, Android, serveur) : [i] [u] [t=14] [c=#b91c1c] [f=Georgia] ; alignement de ligne : >> centré, << droite, <= gauche, == justifié ; [~] ligne vide.
Le PDF garde : en-tête, pied de page et QR en bas de chaque page, signature du Directeur en bas.

## Fichiers
Nouveau : site/exb-v123-editeur.js. Modifiés : site/exb-v81-pieces.js, site/docengine/templates-modules.js, site/index.html, site/sw.js.
Retour en arrière : retirer la balise <script src="exb-v123-editeur.js"> de index.html.

## Vérifié / non vérifié
Vérifié dans Chromium : ouverture, aller-retour du balisage, gras / italique / souligné / police / taille / couleur / alignement, frappe, saut de page, mode texte, rendu PDF du résultat ; 548 contrôles (1 échec déjà présent : licence-config).
Non vérifié : Windows (Electron) réel, téléphone Android (clavier tactile, sélection), collage depuis Word (le collage est converti en texte simple), tableaux très complexes (cellules fusionnées non prises en charge).
