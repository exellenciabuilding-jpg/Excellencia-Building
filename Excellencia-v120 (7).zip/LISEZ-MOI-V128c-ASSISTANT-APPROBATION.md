# V128c — Assistant IA : importer ET approuver les demandes en ligne + autres tâches

## Pourquoi ça ne marchait pas
1. **L'assistant savait seulement « importer »** : la fiche était créée « EN ATTENTE », sans matricule. Aucune action « approuver » n'existait (ni en local, ni dans la fonction serveur `assistant`).
2. **Blocage de la page** (`exb-notify-pro.js`) : dès que 5 notifications s'affichaient en même temps, une boucle ne finissait jamais et l'application se figeait. Un import en lot en produit plusieurs. Corrigé.

## Ce qui est nouveau (Paramètres › 🤖 Assistant IA)
Chaque action a son niveau : 🔒 Interdit · ✋ Demander (défaut) · ✅ Automatique.
- **Importer ET approuver les demandes en ligne** : importe puis approuve les fiches (matricule attribué) pour Apprenants, Formateurs, Personnel. TP/TD et Clients sont importés (rien à approuver).
- **Approuver des dossiers en attente** (tous, ou un nom).
- **Marquer des demandes comme traitées**.
- **Rejeter un dossier** : motif obligatoire, validation toujours demandée (jamais automatique).
- **Case « Traiter automatiquement les nouvelles demandes en ligne »** : dès qu'une demande arrive, elle est importée et approuvée sans clic. Il faut mettre « Importer ET approuver » sur ✅ Automatique.

## Phrases utiles
« importe et approuve les demandes » · « importe et approuve les formateurs » · « approuve Jean Kasongo » · « approuve les apprenants » · « marque les demandes traitées ».

## Garde-fous
- Doublons possibles (même nom, téléphone, e-mail) : **non importés en mode automatique**, ils restent en attente.
- Demande incomplète (nom, téléphone ou formation manquant) : reste en attente, une seule tentative automatique par session.
- Chaque traitement automatique est noté dans le journal.
- Les demandes de logiciel (licences) et de projet BTP ne passent **pas** par cette approbation (compte en ligne, mot de passe : validation manuelle conservée).

## Mise en place
1. Déposer le ZIP sur Netlify comme d'habitude.
2. **Redéployer la fonction Supabase `assistant`** avec `site/supabase/functions/assistant/index.ts` (sinon l'IA en ligne ne connaît pas les nouvelles actions ; l'assistant local, lui, les connaît déjà).
3. Réglages des autorisations, puis case « Traiter automatiquement… ».

## Limites
- Le traitement automatique ne tourne que **application ouverte, déverrouillée et connectée au serveur (☁️)**. Il vérifie les nouvelles demandes toutes les 90 secondes.
- Testé : navigateur avec faux serveur (`tools/e2e-assistant-approbation.py`, 15 contrôles) et les 535 contrôles existants. **Non testé** avec votre vrai Supabase ni avec la fonction `assistant` déployée.

Fichiers modifiés : `index.html`, `exb-notify-pro.js`, `sw.js`, `supabase/functions/assistant/index.ts`, `tools/e2e-assistant-approbation.py` (nouveau). Aucun SQL.
Retour en arrière : restaurer ces fichiers de V128b.
