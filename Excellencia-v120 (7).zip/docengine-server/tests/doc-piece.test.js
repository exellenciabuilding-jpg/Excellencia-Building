const C=require('../../site/docengine/core.js');require('../../site/docengine/templates.js');require('../../site/docengine/templates-modules.js');
const prof=(C.normalizeProfile||C.normProfile||(x=>x))({name:'ACME BTP',city:'Goma',phones:['+243 1'],emails:['a@b.c'],signatory:{name:'J. Dupont',role:'Directeur'}});
const body='# CCTP lot gros œuvre\n\nObjet : béton armé\n\n## Article 1\n- point **un**\n- point deux\n\n| Col | Val |\n| a | <script>alert(1)</script> |\n\n[saut de page]\n\nFin.';
const r=C.render('doc-piece',{doc:{kind:'doc',titre:'CCTP',numero:'PIE-001',date:'2026-11-01',project:'Villa X',body,sign:'dg',dgRole:'Le Directeur',dgName:'J. Dupont'}},{profile:prof,options:{},number:'PIE-001',mode:'print'});
const h=r.html;
console.log(h.length,'ACME',h.includes('ACME BTP'),'h3',h.includes('<h3 class="pp">Article 1'),'ul',h.includes('<li>point <b>un</b>'),'table',h.includes('<table class="pt">'),'pgb',h.includes('pgb"></div>'),'script échappé',!h.includes('<script>alert'),'sig',h.includes('Le Directeur'));
const l=C.render('doc-piece',{doc:{kind:'lettre',titre:'Lettre',numero:'L1',date:'2026-11-01',dest:'M. X\nGoma',body:'Madame,\n\nBonjour.',sign:'dg'}},{profile:prof,options:{},number:'L1',mode:'print'});
console.log('lettre',l.html.includes('Réf. :')&&l.html.includes('M. X<br>Goma'));

if(!(h.includes('ACME BTP')&&h.includes('<li>point <b>un</b>')&&!h.includes('<script>alert')&&l.html.includes('M. X<br>Goma'))){console.log('KO');process.exit(1)}console.log('OK doc-piece');

/* V126b : une ligne vide centrée / justifiée (« >> [~] », « == [~] ») ne doit plus s'imprimer telle quelle */
const e=C.render('doc-piece',{doc:{kind:'doc',titre:'T',numero:'P2',date:'2026-11-01',body:'Avant\n>> [~]\n== [~]\n[~]\nAprès',sign:'dg'}},{profile:prof,options:{},number:'P2',mode:'print'});
if(/\[~\]/.test(e.html.replace(/<style[\s\S]*?<\/style>/g,''))){console.log('KO [~] imprimé');process.exit(1)}console.log('OK [~] vide');
