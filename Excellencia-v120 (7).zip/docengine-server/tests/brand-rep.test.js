/* V120j : le remplaçant de noms de exb-brand.js (extrait tel quel du fichier) */
const fs=require('fs');const src=fs.readFileSync(__dirname+'/../../site/exb-brand.js','utf8');
const body=src.slice(src.indexOf('/* REP-BEGIN'),src.indexOf('/* REP-END */'));
const ORIGIN={name:'Excellencia Building',chantier:'Excellencia Chantier',short:'Excellencia',primary:'#173565',accent:'#c49a38'};
const OX={phone:'+243 810 644 554',email:'Excellenciabuilding@gmail.com',dg:'Ir Ibwampere Ngwala Louis',tag:'Ingénierie & Construction',host:'excellenciabuildingsarlu001.netlify.app'};
const mk=(B,XI,changed)=>new Function('ORIGIN','OX','B','XI','changed','window',body+';return rep')(ORIGIN,OX,B,XI,changed,{EXB_PUBLIC_URL:'https://bp.example.com'});
const B={name:'Bâtiment Plus SARL',short:'Bâtiment Plus',chantier:'Bâtiment Plus Chantier',phone:'+243 000',email:'contact@bp.com',tagline:'Construire',primary:'#173565',accent:'#c49a38'};
const rep=mk(B,{dg:'M. Dupont'},true),bad=[];
const T=(i,o)=>{const r=rep(i);const ok=r===o;console.log(ok?'ok ':'KO ',JSON.stringify(i),'→',JSON.stringify(r));if(!ok)bad.push(i)};
T('Contact : Excellenciabuilding@gmail.com','Contact : contact@bp.com');
T('EXCELLENCIA BUILDING SARLU','BÂTIMENT PLUS SARL');
T('Excellencia Building SARLU','Bâtiment Plus SARL');
T('EXCELLENCIA','BÂTIMENT PLUS');
T('Excellencia-Building','Bâtiment Plus SARL');
T('Excellencia Chantier','Bâtiment Plus Chantier');
T('Bienvenue chez Excellencia !','Bienvenue chez Bâtiment Plus !');
T('https://excellenciabuildingsarlu001.netlify.app/x','https://bp.example.com/x');
T('Tél +243 810 644 554 / 0810 644 554','Tél +243 000 / +243 000');
T('Ingénierie &amp; Construction','Construire');
T('Ingénierie & Construction','Construire');
T('Direction : Ir Ibwampere Ngwala Louis','Direction : M. Dupont');
/* ne jamais toucher aux identifiants minuscules */
T('.excellencia-btn{color:red} id="excellencia building"','.excellencia-btn{color:red} id="excellencia building"');
T('exb_excellencia','exb_excellencia');
/* entreprise d'origine : aucun changement */
const keep=mk(Object.assign({},B,{name:ORIGIN.name,short:ORIGIN.short,chantier:ORIGIN.chantier}),{},false);
if(keep('Excellencia Building — Excellenciabuilding@gmail.com')!=='Excellencia Building — Excellenciabuilding@gmail.com')bad.push('origine');
/* structure entière (charge utile PDF) */
{const src2=fs.readFileSync(__dirname+'/../../site/exb-brand.js','utf8');const i=src2.indexOf('/* DEEP-BEGIN */'),j=src2.indexOf('/* DEEP-END */');
 const deep=new Function('rep','window',src2.slice(i,j)+';return window.exbRebrandDeep')(rep,{});
 const out=deep({titre:'Plan — Excellencia Building',rows:[['Client','Excellencia Chantier']],logo:'data:image/png;base64,Excellencia',n:3,footer:['Mission — EXCELLENCIA BUILDING']});
 const ok=out.titre==='Plan — Bâtiment Plus SARL'&&out.rows[0][1]==='Bâtiment Plus Chantier'&&out.logo.endsWith('Excellencia')&&out.n===3&&out.footer[0]==='Mission — BÂTIMENT PLUS SARL';
 console.log(ok?'ok ':'KO ','charge utile PDF profonde');if(!ok)bad.push('deep')}
if(bad.length){console.log('ÉCHECS',bad);process.exit(1)}console.log('OK brand-rep');
