# V127 — Même mise en page pour tous les modèles (suite de V120-4b)

## Changé
La mise en page des pièces écrites (en-tête, contenu, puis signature + QR + pied de page regroupés en bas de page, texte long qui coule sur plusieurs pages) s'applique maintenant aussi aux modèles du moteur documentaire :
- **doc-module** (documents produits par les modules : fiches client, décomptes, rapports, PV…) ;
- **doc-fiche** (fiches, épreuves, listes, présence, cotation, dossier participant).
Fichier modifié : site/docengine/templates-modules.js (règles `.xm .xpg / .xmid / .xsgw` communes), site/sw.js (cache v151).

## Documents de chantier / Pièces d'architecture
Le hub utilise déjà le même éditeur (V123/V124/V126b) et le même PDF (local + serveur) que les Pièces écrites : ces documents bénéficient donc des mêmes réglages sans autre modification.

## Vérifié / non vérifié
Vérifié : tests docengine (doc-piece, doc-fiche, fiche-adapter, brand-rep, bridge-habillage) ; HTML généré avec bloc signature/QR/pied en bas.
Non vérifié : rendu PDF réel (Chromium absent ici), Android, Windows. Devis/factures et PDF issus de exb-pdf.js (EXBPdf.make) non modifiés.
Retour en arrière : restaurer l'ancien templates-modules.js.

---
# V127b — Modèles de « Pièces écrites » remplis d'exemples concrets

## Changé
662 modèles sur 774 n'étaient que des trames vides (lignes « ____ »). Ils contiennent maintenant des EXEMPLES réalistes (noms, dates, quantités, constats, décisions, montants en USD, Goma) pour montrer comment les remplir. Les données du projet restent des variables ({{projet}}, {{lieu}}, {{moa}}, {{societe}}…) remplies automatiquement ; les exemples sont à remplacer par vos données.
- Familles concernées : lettres, comptes rendus, ordres de service, procès-verbaux, attestations, contrats, notes, texte libre, rapports, clauses, fiches, dossier, MOE, autorisations, notices.
- « Page blanche » reste volontairement vide. Aucune variable {{…}} n'est supprimée.

## Fichiers
- site/exb-v127-exemples-libre.js : textes rédigés à la main pour les 51 modèles « Texte libre ».
- site/exb-v127-exemples.js : moteur qui complète tous les autres modèles selon le sens de chaque colonne, libellé, unité et titre de rubrique.
- site/index.html : les 2 scripts sont chargés après les séries de modèles et avant exb-v81-pieces.js.
- site/sw.js : cache v152, fichiers ajoutés au mode hors connexion.
Retour en arrière : retirer les 2 balises <script> de index.html.

## Limites
Exemples générés à partir de la structure : relire les modèles très techniques (contrats, essais) avant usage réel. Les clauses restent à faire valider par votre conseil juridique.

---
# V127c — Les 111 modèles déjà rédigés mais courts reçoivent aussi des exemples
Ordres de service (42), clauses (25), lettres (18), attestations (17), notes (6), procès-verbal (1), dossier (2) : un bloc d'exemple concret (dates, délais, montants, consignes) est inséré avant la formule de fin ; le texte d'origine et ses variables sont conservés.
Résultat : 773 modèles sur 774 contiennent des exemples ; seule la « Page blanche » reste vide volontairement.
Fichier : site/exb-v127-exemples-suite.js (chargé après exb-v127-exemples.js ; cache v153). Retour en arrière : retirer sa balise <script>.
