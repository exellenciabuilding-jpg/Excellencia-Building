# V141r — V141q appliquée + plans, notes de calcul et plans d'exécution envoyés AU CHANTIER

Base : V141p. Inclus : correctif **V141q** (cartouche portrait lisible, formats ARCH A/B) + nouvel **envoi au chantier**.

## Ce que ça fait
Le logiciel central envoie le PDF à l'équipe du chantier, en plus (ou à la place) du portail client :
- **Note de calcul / Plan d'exécution** : dans l'aperçu (fiche « Informations du document »), nouveau bloc **🏗️ Chantier** → **Envoyer au chantier**. On choisit un ou plusieurs chantiers (le chantier qui porte le même nom que le projet est déjà coché), on peut ajouter un message pour l'équipe.
- **Plan** (liste des plans) : nouveau bouton **🏗️** à côté du 🌐.
- **Documents du chantier** : liste des documents envoyés par chantier, avec **Retirer**.
- Un document = une ligne par chantier. Renvoyer le même numéro **remplace** le fichier (nouvel indice, nouveau statut) : l'équipe voit toujours la dernière version, l'ancien PDF est supprimé.
- Mise à jour automatique : une note / un plan d'exécution déjà envoyé à un chantier est renvoyé tout seul à chaque nouveau « 📄 PDF » dont le contenu a changé (case désactivable dans la fenêtre d'envoi). Pour un plan, on renvoie avec le bouton 🏗️.

## Sécurité
- Espace de fichiers **privé** (`exb-chantier-docs`), pas de lien public. Lecture : administrateur + membres du chantier (table `exb_site_memberships`) pour LEUR chantier seulement. Envoi / retrait : compte administrateur (`exb_is_admin()`).
- Le portail client (QR + code) est inchangé ; l'envoi au chantier est indépendant.

## À faire de votre côté (dans l'ordre)
1. Supabase › SQL Editor : exécuter **`site/supabase/migration-v141r-documents-chantier.sql`** (une fois, réexécutable). Contrôle : 4 fonctions + le bucket `exb-chantier-docs` avec `public = false`.
2. Déposer ce ZIP sur GitHub / redéployer `site` sur Netlify. Fermer complètement l'application une fois (nouvelle version de cache).
3. Se connecter au serveur (☁️) avec le **compte administrateur**, ouvrir une note de calcul → « 🏗️ Envoyer au chantier ».

## ⚠ Ce qui reste à faire côté LOGICIEL CHANTIER (non inclus ici)
Le code source du logiciel chantier n'est pas dans ces ZIP : l'écran qui **affiche** ces documents à l'équipe n'est donc pas encore ajouté. Le serveur est prêt, il reste à ajouter dans le logiciel chantier un écran « Plans et notes » qui :
1. appelle `chantier_docs_liste(p_site)` → liste (genre, n°, titre, indice, statut, message, date, `fichier`) ;
2. ouvre un document avec une adresse signée : `storage.from('exb-chantier-docs').createSignedUrl(fichier, 3600)`.
Envoyez-moi le dernier ZIP du logiciel chantier (V81b ou plus récent, avec les sources) et je l'ajoute.

## Fichiers
Nouveaux : `site/exb-chantier-docs.js`, `site/supabase/migration-v141r-documents-chantier.sql`, `site/tools/test-chantier-docs.js`, `site/tools/e2e-calcul-chantier.py`.
Modifiés : `site/calcul-structure/exb-calcul-doc.js`, `site/exb-calc-publics.js`, `site/exb-plans-publics.js`, `site/index.html`, `site/sw.js`, `site/plan-cartouche/sheet.js` (V141q).
Retour en arrière : retirer la balise `<script src="exb-chantier-docs.js">` de `index.html` (le reste fonctionne sans).

## Vérifié ici
- `node tools/check.js` : 547 contrôles, 0 échec. `tools/e2e-calcul-publier.py` (portail client, non-régression) : 12/12.
- `node tools/test-chantier-docs.js` : 8/8 (envoi, remplacement, nettoyage si refus, hors connexion, mise à jour auto).
- `tools/e2e-calcul-chantier.py` : 8/8 avec le vrai module de calcul et un vrai PDF (serveur simulé).
**Non testé** : le script SQL (pas de Postgres ici : relisez les messages à l'exécution ; il suppose que `exb_site_memberships` a les colonnes `user_id` et `site_id`), le bouton 🏗️ de la liste des plans, un vrai Supabase, téléphone, Windows/Android, et la partie « affichage » du logiciel chantier (voir ci-dessus).
