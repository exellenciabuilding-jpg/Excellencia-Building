# V155 — Saisie qui se bloque dans l'éditeur de pièces (mode Word)

Cause trouvée (exb-v123-editeur.js) : à CHAQUE touche, l'éditeur reconvertissait tout le document en texte (toMd), recomptait les mots
(innerText), recalculait les pages (mesures de mise en page) puis, au relâchement de la touche, interrogeait ~10 états de mise en forme.
Coût proportionnel à la longueur : sur un CCTP / contrat de plusieurs pages, la frappe se figeait pendant que boutons et menus répondaient.

Correction : ces travaux sont regroupés après une courte pause de frappe (délai adaptatif selon le coût mesuré, 250 ms à 2 s).
Ils s'exécutent immédiatement avant tout clic, Ctrl+S, perte du focus, masquage ou fermeture de la page : aucune donnée perdue.
Test navigateur (document de 150 articles) : frappe moyenne 26 → 17 ms, pire cas 48 → 20 ms ; contenu synchronisé identique.
sw.js : version de cache changée pour forcer la mise à jour chez les utilisateurs.

Note sur votre rapport Ctrl+Alt+L : la plupart des « blocages » de 2 à 5 s sont des fenêtres prompt/confirm restées ouvertes (pas des calculs).
Restent à surveiller : exb-fab.js (démarrage, 1,2 s), exb-bigstore.js (IndexedDB, 1 s), observateur d'exb-v77.js (381 ms).

## Gardien de saisie (exb-diag-lenteur.js, chargé en premier)
- Mesure en continu le délai d'affichage de chaque frappe dans un champ (Event Timing). Au-delà de 200 ms : « mode protégé » 20 s —
  tâches de fond reportées tant que le champ a le focus, observateurs DOM regroupés.
- Chaque incident est noté dans le rapport (Ctrl + Alt + L) : champ, écran, durée. Jamais le contenu saisi. Max. 1 ligne / 3 s.
- Test : handler volontairement lent (350 ms) détecté, mode protégé activé, logiciel complet démarre sans erreur.
- Limite : le gardien protège et révèle la cause, il ne rend pas rapide un traitement lourd en lui-même (corrigé au cas par cas).

## Couche de fluidité générale (préventive, tous modules)
- Toute tâche périodique (≥ 1 s) attend un moment de repos du navigateur (requestIdleCallback, au plus 1,5 s) : elle ne s'exécute plus au milieu d'un clic ou d'une frappe, et ne s'empile jamais si le poste est chargé.
- Garde mémoire (Chrome/Edge) : à 85 % du plafond de mémoire de l'onglet, incident noté + avertissement unique « enregistrez puis rechargez » avant le plantage.
- Test : minuteries toujours exécutées au bon rythme, suspendues pendant la frappe, démarrage complet sans erreur.
- Chantier suivant (non fait) : ~50 minuteries « mount » de 0,4 à 1,5 s et ~20 observateurs DOM sur toute la page à remplacer par des déclencheurs sur événements ; à traiter module par module avec tests.
