# V126b — Correctifs de l'éditeur de texte et du PDF des pièces

## Corrigé
1. **« [~] » imprimé dans le PDF** : une ligne vide centrée / justifiée (`>> [~]`, `== [~]`, `<< [~]`, `<= [~]`) est maintenant reconnue comme ligne vide dans les deux moteurs
   (site/exb-v81-pieces.js, site/docengine/templates-modules.js). Test ajouté dans docengine-server/tests/doc-piece.test.js.
2. **Curseur qui saute après le bouton liste à puces** : l'éditeur retrouvait le curseur par nombre de caractères, et le début d'un bloc a le même décalage que la fin du bloc précédent.
   Il pose maintenant un repère invisible sur le curseur avant de réarranger le DOM et le retrouve ensuite (site/exb-v123-editeur.js, `normalizeRoot`). Vérifié dans Chromium : sur l'ancienne version la frappe partait dans la ligne précédente, plus maintenant.
3. **Paragraphe écrasé après un changement de taille** : sans sélection, la mise en forme s'applique à tout le paragraphe, mais celui-ci restait sélectionné et la frappe suivante le remplaçait.
   Le curseur est maintenant remis à sa place d'origine après la mise en forme (taille, A+/A−, police, couleur, surlignage). Vérifié dans Chromium : le texte tapé s'ajoute, rien ne disparaît.
4. **QR absent / mal placé dans le PDF local** : cause trouvée — index.html contient une règle globale `.qr{position:absolute;right:60px;bottom:26px;…}` (reçus, certificats) qui s'appliquait aussi au QR du pied de page des pièces.
   Il passait par-dessus l'adresse, et dans la capture hors-ligne il sortait du cadre du pied de page. La règle `.ft .qr` remet le QR dans le flux (site/exb-v81-pieces.js). Vérifié par mesure dans Chromium : QR à gauche, adresse décalée, plus de recouvrement.

5. **PDF local : lignes coupées entre deux pages et signature rognée** : les règles de police du moteur local étaient liées à un conteneur absent de la capture (texte mesuré en Arial, photographié en police par défaut, donc plus haut que prévu).
   Les blocs capturés portent maintenant eux-mêmes ces règles (classe `exbPieC`) et contiennent leurs marges (`display:flow-root`) (site/exb-v81-pieces.js). Vérifié sur un PDF de 5 pages : plus aucune ligne tranchée, signature complète au-dessus du pied de page.

## Fichiers modifiés
site/exb-v123-editeur.js, site/exb-v81-pieces.js, site/docengine/templates-modules.js, site/sw.js (version de cache v150), docengine-server/tests/doc-piece.test.js.
Aucun nouveau SQL.

## Non vérifié
Rendu PDF complet de bout en bout (je n'ai pas relancé la génération du PDF entier), Windows (Electron), Android, serveur Chromium, CCTP à la carte, document long, état « signé » avec visa.
