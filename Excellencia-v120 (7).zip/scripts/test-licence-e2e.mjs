/* Test de bout en bout de la licence : VRAI client (site/exb-license.js) + VRAI serveur (licence-server core.mjs), réseau et horloges simulés.
 * Usage : node scripts/test-licence-e2e.mjs   — cherche les situations où le logiciel reste verrouillé à tort. */
import fs from 'fs'; import vm from 'vm'; import path from 'path'; import { fileURLToPath } from 'url';
import { createHandler, makeSigner, sha256 } from '../licence-server/supabase/functions/licence/core.mjs';
import { postgrestDb } from '../licence-server/supabase/functions/licence/postgrest.mjs';
import { fakePostgrest } from '../licence-server/tests/fake-postgrest.mjs';
const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..'), DAY = 864e5;
let fail = 0; const ok = (c, m, d) => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (!c && d ? ' — ' + d : '')); if (!c) fail++; };
const realNow = Date.now.bind(Date), sim = { t: 0 };                       /* temps réel du serveur = réel + sim.t */
const serverNow = () => new Date(realNow() + sim.t);
const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const pub = await crypto.subtle.exportKey('jwk', kp.publicKey), priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
const pg = fakePostgrest({ now: serverNow }), ADMIN = 'cle-admin-' + 'x'.repeat(24);
const h = createHandler({ db: postgrestDb('https://x.supabase.co', 'k', pg.fetch), sign: await makeSigner(priv), adminKeyHash: await sha256(ADMIN), now: serverNow });
const adm = (a, o) => h(Object.assign({ action: 'admin.' + a }, o), { adminKey: ADMIN, ip: '1.1.1.1' }).then(r => r.body);
const net = { on: true, mode: 'normal' };
const SRC = fs.readFileSync(path.join(ROOT, process.env.LIC_FILE || 'site/exb-license.js'), 'utf8').replace(/var PUB=\{[^}]*\};/, 'var PUB=' + JSON.stringify({ kty: 'EC', crv: 'P-256', x: pub.x, y: pub.y }) + ';');

/* un « appareil » : stockage persistant + horloge propre ; chaque load() = un rechargement de la page */
function device(name) {
  const mem = {}, dev = { off: 0 }, o = { name, mem, dev };
  const mk = m => ({ getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: k => { delete m[k]; } });
  o.load = async () => {
    class D extends Date { constructor(...a) { if (a.length) super(...a); else super(realNow() + sim.t + dev.off); } static now() { return realNow() + sim.t + dev.off; } }
    const el = () => ({ style: {}, setAttribute() {}, getAttribute() { return null; }, appendChild() {}, remove() {}, firstChild: null, innerHTML: '', onclick: null, addEventListener() {} });
    const w = { crypto: globalThis.crypto, localStorage: mk(mem), sessionStorage: mk({}), addEventListener() {}, setTimeout: () => 0, setInterval: () => 0, alert() {}, prompt() {},
      location: { hash: '', search: '', pathname: '/', reload() {} }, history: { replaceState() {} },
      EXB_LICENSE_CONFIG: { requireToken: true, warnDays: 7, defaultGrace: 7, contact: 'Test', server: 'https://srv/licence', serverPub: { kty: 'EC', crv: 'P-256', x: pub.x, y: pub.y }, offlineDays: 7, checkEveryMin: 30 } };
    w.window = w;
    const ctx = vm.createContext(Object.assign(w, { document: { getElementById: () => el(), createElement: el, body: { appendChild() {} }, addEventListener() {}, hidden: false, readyState: 'complete' },
      navigator: { get onLine() { return net.on; }, platform: 'Test' }, setInterval: () => 0, TextEncoder, TextDecoder, atob, btoa, Uint8Array, Date: D, JSON, Math, console, Object, Array, Number, String, Promise,
      fetch: async (url, init) => { if (!net.on) throw new TypeError('offline');
        const H0 = { get: () => null }; if (net.mode === '401') return { ok: false, status: 401, json: async () => ({ code: 401, message: 'Missing authorization header' }), headers: H0 };
        if (net.mode === '404') return { ok: false, status: 404, json: async () => ({ message: 'Function not found' }), headers: H0 };
        if (net.mode === 'html') return { ok: false, status: 502, json: async () => { throw new SyntaxError('Unexpected token <'); }, headers: H0 };
        if (net.mode === 'wrongkey') { const r0 = await h(JSON.parse(init.body), { ip: '7.7.7.7' }); if (r0.body && r0.body.jeton) r0.body = Object.assign({}, r0.body, { jeton: r0.body.jeton.slice(0, -6) + 'AAAAAA' }); return { ok: true, status: 200, json: async () => r0.body, headers: H0 }; } const r = await h(JSON.parse(init.body), { ip: '7.7.7.7' }); return { ok: r.status < 400, status: r.status, json: async () => r.body, headers: { get: () => null } }; } }));
    vm.runInContext(SRC, ctx); await new Promise(r => setTimeout(r, 40)); o.w = w; return o;
  };
  o.check = async () => { await o.w.EXBLIC.check(); return o.w.EXBLIC.state(); };
  return o;
}
const later = (min = 2) => { sim.t += min * 60000; };   /* le logiciel espace ses vérifications (1 min si verrouillé, 30 min sinon) */
const reason = s => s.mode + (s.reason ? ':' + s.reason : '');

console.log('Mise en route');
const c1 = await adm('create', { nom: 'Client Test', jours: 365, max_appareils: 2 });
const PC = device('PC'); await PC.load();
let a = await PC.w.EXBLIC.activateCode(c1.code); ok(a.ok, 'activation par code', a.msg);
ok((await PC.check()).mode === 'ok', 'état : ok');

console.log('\nS1. Hors ligne puis retour du réseau');
net.on = false; sim.t = 5 * DAY; ok((await PC.check()).mode === 'ok', '5 jours hors ligne : toujours ouvert');
sim.t = 9 * DAY; let s = await PC.check(); ok(reason(s) === 'locked:verify', '9 jours hors ligne : verrouillé « vérification requise » (prévu)', reason(s));
net.on = true; s = await PC.check(); ok(s.mode === 'ok', 'retour du réseau, SANS recharger la page : se déverrouille tout seul', reason(s));

console.log('\nS2. Date de l\'appareil avancée par erreur (appareil EN LIGNE), puis corrigée');
const T = device('Tablette'); await T.load(); T.dev.off = 40 * DAY;                     /* date avancée de 40 jours */
a = await T.w.EXBLIC.activateCode(c1.code); ok(a.ok, 'tablette activée alors que sa date est avancée de 40 jours');
ok((await T.check()).mode === 'ok', 'date avancée, en ligne : le logiciel fonctionne');
T.dev.off = 0; sim.t = 18 * DAY; s = await T.check();                                   /* la date est corrigée ; 8 jours passent, la page reste ouverte */
ok(s.mode === 'ok', 'date corrigée, 8 jours plus tard, EN LIGNE, sans recharger : doit rester ouvert (avant correction : verrouillé « vérification requise » sans jamais se resynchroniser)', reason(s));
await T.load(); s = await T.check(); ok(s.mode === 'ok', 'après rechargement de la page : ok', reason(s));
console.log('  — variante hors ligne');
const U = device('Portable'); ok(true, '(non testé ici : 3e appareil)'); void U;
net.on = false; T.dev.off = 40 * DAY; s = await T.check(); ok(true, 'date avancée de 40 j, hors ligne : ' + reason(s));
T.dev.off = 0; net.on = true; later(); s = await T.check(); ok(s.mode === 'ok', 'date corrigée + réseau : se déverrouille tout seul, sans recharger', reason(s));

console.log('\nS3. Abonnement terminé puis renouvelé par le propriétaire');
sim.t = 400 * DAY; await PC.check(); later(); s = await PC.check(); ok(reason(s) === 'locked:expired', 'échéance + tolérance dépassées : verrouillé', reason(s));
await adm('renew', { id: c1.client.id, jours: 365 }); later(); s = await PC.check();
ok(s.mode === 'ok' || s.mode === 'warn', 'renouvelé côté serveur : déverrouillage automatique à la vérification suivante (≤ 1 min)', reason(s));

console.log('\nS4. Suspension puis réactivation');
await adm('update', { id: c1.client.id, patch: { statut: 'suspendu' } }); later(31); s = await PC.check(); ok(reason(s) === 'locked:suspended', 'suspendu : verrouillé', reason(s));
await adm('update', { id: c1.client.id, patch: { statut: 'actif' } }); later(); s = await PC.check(); ok(s.mode !== 'locked', 'réactivé : déverrouillé sans nouveau code', reason(s));

console.log('\nS5. Identifiant d\'appareil perdu (stockage effacé par le navigateur) alors que 2 appareils sont déjà enregistrés');
const lost = PC.mem.exb_dev_id; delete PC.mem.exb_dev_id; await PC.load(); s = await PC.check();
ok(reason(s) === 'locked:device', 'jeton gardé mais identifiant perdu : verrouillé « autre appareil »', reason(s));
delete PC.mem.exb_lic_token; await PC.load(); a = await PC.w.EXBLIC.activateCode(c1.code);
ok(!a.ok && /déjà utilisée sur 2/.test(a.msg || ''), 'ré-activation refusée : 2 places prises par des identifiants devenus inutiles', a.msg);
const list = await adm('list', {}); const devs = pg.tables.licence_appareils ? pg.tables.licence_appareils : [];
ok(true, 'appareils enregistrés côté serveur : ' + devs.length + ' (l\'ancien identifiant de ce poste y occupe toujours une place)');

console.log('\nS6. Diagnostic : le logiciel dit pourquoi la vérification échoue');
const D = device('Poste'); await D.load(); await adm('update', { id: c1.client.id, patch: { max_appareils: 5 } });
net.mode = '401'; a = await D.w.EXBLIC.activateCode(c1.code); ok(!a.ok && /HTTP 401/.test(a.msg) && /JWT/.test(a.msg), 'activation, serveur en HTTP 401 : message précis', a.msg);
net.mode = '404'; a = await D.w.EXBLIC.activateCode(c1.code); ok(!a.ok && /404/.test(a.msg), 'activation, serveur introuvable (404) : message précis', a.msg);
net.mode = 'normal'; a = await D.w.EXBLIC.activateCode(c1.code); ok(a.ok, 'activation normale ensuite');
const diagOf = async (mode) => { net.mode = mode; later(31); await D.check(); const t = D.w.EXBLIC.diagText(); net.mode = 'normal'; return t; };
let t = await diagOf('401'); ok(/HTTP 401/.test(t) && /no-verify-jwt/.test(t), 'vérification en HTTP 401 : cause indiquée', t);
t = await diagOf('html'); ok(/HTTP 502/.test(t), 'réponse non JSON (HTML 502) : cause indiquée', t);
t = await diagOf('wrongkey'); ok(/clé publique/.test(t), 'jeton signé par une autre clé : cause indiquée', t);
net.on = false; later(31); await D.check(); t = D.w.EXBLIC.diagText(); ok(/hors ligne/.test(t), 'hors ligne : cause indiquée', t); net.on = true;
const stub = D.w.EXBLIC; const saved = net.mode; net.mode = 'normal'; later(31); await D.check(); ok(/réussie/.test(D.w.EXBLIC.diagText()), 'vérification réussie : indiquée', D.w.EXBLIC.diagText());
ok(!/<script|onerror/i.test(D.w.EXBLIC.diagText()), 'le texte de diagnostic ne contient pas de HTML dangereux'); void stub; void saved;

console.log('\n' + (fail ? fail + ' échec(s)' : 'Tous les scénarios passent')); process.exit(fail ? 1 : 0);
