# Fusion : V99 (LOT 9 trou de toit / lucarne) + dossier de travail V104-106

Base : Excellencia-Building-V99-PLAN-EDITEUR-LOT9-TROU-TOIT-LUCARNE (emballage Android/Windows, tout le site, éditeur de plan).
Apporté depuis V104-106 : un seul fichier différait, `site/plan-editeur/index.html`.
Aucune ligne de la V99 n'a été supprimée ou modifiée : le dossier V104-106 ne fait qu'ajouter deux blocs à la fin du script de l'éditeur.

## Ce qui est ajouté dans l'éditeur de plan
- V100 (lots 10-13) : panneau « Dessin intelligent » (en bas à droite) — baguette (Espace + clic), choix de ce qu'elle crée, modes de pose, verrouillage de direction, application aux outils mur/pièce/toit/cote.
- V101 (lots 14-15) : panneau « Retouche et sélection » (en bas à gauche) — retouche géométrique sur la sélection courante (distances en mètres), groupes, sélection par critères (type, épaisseur).
- Les données V99 sont lues telles quelles (pas de migration) ; les groupes sont gardés dans `D.meta.v101groups`.

## Non fait / à tester (voir ETAT-V104-V106.md)
Aucun test interactif n'a été fait. Les critères V104 (import DXF/PDF vectoriel, dalle BIM indépendante), V105 (couches, profils, hachures) et V106 (mur-rideau, voûte, lucarne, fenêtre d'angle) ne sont pas validés.

## Correctifs de relecture (intégrés dans `site/plan-editeur/index.html`, un seul code)
- Fermeture des blocs : V100 était hors de la fonction principale (`snapPt is not defined`, panneau inerte). Il est maintenant dans la même fonction que V99 et V101.
- Division de mur : les portes/fenêtres de la seconde moitié suivent le nouveau mur ; murs courbes exclus.
- Recherche par épaisseur : utilise l'épaisseur réelle (`wT` : épaisseur du plan par défaut ou somme des couches).
- Groupes : relus dans le plan courant à chaque usage (plus perdus après annuler, changement de plan ou rechargement).
- Étirer / raccorder / retouches : ouvertures recalées sur le mur (`clampPos`) ; murs courbes exclus de ces deux outils.
- Baguette : ne recrée pas un mur déjà couvert par un mur existant.
- Tracker : le point saisi est posé exactement (pas d'accrochage parasite).
- Espace : n'est plus intercepté sur un bouton, un lien ou un résumé.
Testé en navigateur (Chromium) : 14 vérifications, aucune erreur JS. Toujours non fait : tests Android, import DXF/PDF, couches, mur-rideau (voir ETAT-V104-V106.md).
