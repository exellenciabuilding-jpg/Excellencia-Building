# V99 — Éditeur de plan, Priorité 2 / lot 1 : murs composites et matériaux

Fichiers modifiés : `plan-editeur/index.html`, `sw.js` (version du cache). Une seule clé facultative ajoutée au plan : `layers` sur un mur (liste `{m, t}`). Un plan sans couches s'ouvre et se calcule comme avant.

## Ce qui est ajouté
- **Fiche d'un mur droit › ▤ Composition…** : compositions types (extérieur isolé 24 cm, bloc 20 enduit, brique 22 enduite, béton 20 enduit, cloison 14 cm) ou 4 couches personnalisées (matériau + épaisseur). « Aucune » retire la composition. **⇄ Inverser** retourne l'ordre des couches (1re couche = côté droit du sens du tracé).
- **Épaisseur = somme des couches** (affichée « composé » dans la fiche). Mur 0,20 / Cloison 0,10 retirent la composition.
- **Hachure et teinte automatiques par matériau** en plan 2D : enduit, bloc, brique, béton, isolant, pierre, plâtre, bois.
- **Surfaces et volumes par matériau** (surface nette 1 face, déduction des ouvertures) dans le panneau Quantités, et lignes de devis « Mur composite — <matériau> » avec prix indicatifs modifiables dans Prix.
- Pour éviter le double comptage, les murs composites sont exclus des lignes « Maçonnerie » et « Enduit / peinture » globales.
- Nomenclatures › Murs : l'épaisseur d'un mur composé n'est plus modifiable depuis le tableau (message), seulement par ses couches.

## Suite : couches en 3D et en coupe, profil trapézoïdal, légende
Fichiers modifiés en plus : `plan-editeur/vue3d.js`, `plan-editeur/coupes.js`.
- **3D** : chaque couche d'un mur composite est un volume de sa teinte (enduit, bloc, isolant…), côte à côte sur l'épaisseur du mur, ouvertures comprises.
- **Coupes** : la section d'un mur composite traversé par le plan de coupe est découpée en bandes de couches, dans le bon sens de lecture. Façades : inchangées (une seule face visible).
- **Mur à profil trapézoïdal** : fiche d'un mur droit › **Hauteur côté fin** (0 = rectangle). Le sommet est incliné de la hauteur au point de départ à celle du point d'arrivée, en 3D, en façade et en coupe ; portes et fenêtres suivent (leur linteau est limité par le sommet). Quantités : surface calculée sur la hauteur moyenne.
- **Légende** : nouvelle rubrique « Matériaux des murs » (échantillon hachuré + surface par matériau).

## Angles et départs de murs composites
- **Plan 2D** : aux angles en L et aux départs en T, les couches sont raccordées. Le mur le plus épais (à égalité, celui dont l'identifiant est le plus petit) passe ; l'autre bute contre sa face et ses couches sont coupées net à cette face. Le mur qui passe est prolongé jusqu'à la face extérieure de l'autre. Calcul exact, pour tout angle (testé à 90° et à 60°).
- **3D** : les axes sont prolongés ou raccourcis aux mêmes jonctions (valeur exacte à 90°, approchée sinon), ce qui comble l'encoche extérieure des angles ; les portes et fenêtres gardent leur position réelle.
- **Mur simple en contact avec un mur composite** : il est raccourci en 3D aux mêmes jonctions pour ne pas se superposer.
- Un nœud où se rejoignent trois murs ou plus, ou deux murs presque alignés (< 12°), reste en bout plat.
- Les coupes et façades gardent leur gestion existante des murs qui se touchent.

## Limites
- Murs droits seulement (composition et profil) ; murs courbes non concernés.
- Profil limité au trapèze (hauteur linéaire de bout en bout) ; pas de pignon à sommet central ni de profil libre.
- Les hachures de façade ne suivent pas l'inclinaison du sommet.
- Testé : syntaxe de toutes les pages, logique des couches, orientation des faces 3D et découpage des tronçons sous Node. Non testé visuellement (WebGL, coupes) ni sur appareil réel.
