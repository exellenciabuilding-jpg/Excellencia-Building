/* Excellencia Building V144e — base de performance (audit P1/P3).
 * Number.prototype.toLocaleString(locale, options) recrée un formateur Intl à CHAQUE appel (plusieurs ms) :
 * les montants des listes, devis, caisse et métré en appellent des milliers. Ici le formateur est créé une fois par
 * (langue + options) puis réutilisé ; le texte produit est identique. Sans argument ou en cas d'erreur : comportement d'origine. */
(function (w) {
  'use strict';
  try {
    var orig = Number.prototype.toLocaleString, cache = new Map();
    if (!w.Intl || !w.Intl.NumberFormat || orig.__exbCached) return;
    var fn = function (loc, opt) {
      if (arguments.length === 0 || loc == null && opt == null) return orig.call(this);
      var k;
      try { k = (Array.isArray(loc) ? loc.join(',') : String(loc)) + '|' + (opt ? JSON.stringify(opt) : ''); } catch (e) { return orig.call(this, loc, opt); }
      var f = cache.get(k);
      if (!f) { try { f = new Intl.NumberFormat(loc, opt); } catch (e) { return orig.call(this, loc, opt); } if (cache.size > 200) cache.clear(); cache.set(k, f); }
      return f.format(Number(this));
    };
    fn.__exbCached = true;
    Object.defineProperty(Number.prototype, 'toLocaleString', { value: fn, writable: true, configurable: true });
  } catch (e) {}
})(window);
