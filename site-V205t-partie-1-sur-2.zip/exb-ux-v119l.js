/* Excellencia Building — V119l : confort de l'accueil et du menu de gauche
 * 1) Bannière bleue de l'accueil : le petit logo est retiré (le texte reste).
 * 2) Horloge et météo : plus compactes, et redimensionnables en tirant le coin en bas à droite (taille mémorisée).
 * 3) Menu de gauche : la molette défile toujours, et le menu reste ouvert après le choix d'une catégorie
 *    (il se ferme en cliquant ailleurs, avec Échap, ou avec ☰). Le défilement est conservé. */
(function (w, d) {
  'use strict';
  if (w.__exbUxV119l) return; w.__exbUxV119l = 1;
  var $ = function (i) { return d.getElementById(i); }, de = d.documentElement, SZ = 'exb_hw_sizes_v1';

  function css() {
    if ($('exbUxV119lCss')) return;
    var s = d.createElement('style'); s.id = 'exbUxV119lCss';
    s.textContent =
      '#xhLogo{display:none!important}' +
      '#exbSide{overflow-y:auto!important;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:#ffffff66 transparent}' +
      'html.exb-side-off.exb-side-keep #exbSide{display:flex!important;position:fixed!important;left:0;top:0;bottom:0;height:auto!important;width:280px;z-index:150;padding-top:64px!important;box-shadow:0 0 30px #0006}' +
      'html.exb-side-off.exb-side-peek #exbSide,html.exb-side-off.exb-side-keep #exbSide{align-self:stretch!important;height:100vh!important;max-height:100vh!important;box-sizing:border-box;overflow-y:auto!important}';
    d.head.appendChild(s);
  }

  /* ----- taille mémorisée des blocs horloge / météo ----- */
  function load() { try { return JSON.parse(w.localStorage.getItem(SZ) || '{}') || {}; } catch (e) { return {}; } }
  function save(o) { try { w.localStorage.setItem(SZ, JSON.stringify(o)); } catch (e) {} }
  function sizes() {
    return; /* V120l : l'horloge/météo font partie du bandeau compact (non redimensionnables) */
    var box = $('exbHomeWidgets'); if (!box || box.__sz) return;
    box.__sz = 1; var o = load(), kids = box.children;
    Array.prototype.forEach.call(kids, function (k, i) {
      var v = o['w' + i]; if (v && v.w && v.h) { k.style.width = v.w + 'px'; k.style.height = v.h + 'px'; }
    });
    if (!w.ResizeObserver) return;
    var t = 0, ro = new w.ResizeObserver(function () {
      clearTimeout(t); t = setTimeout(function () {
        var n = load(); Array.prototype.forEach.call(kids, function (k, i) { if (k.offsetWidth > 20) n['w' + i] = { w: Math.round(k.offsetWidth), h: Math.round(k.offsetHeight) }; }); save(n);
      }, 400);
    });
    Array.prototype.forEach.call(kids, function (k) { ro.observe(k); });
  }

  /* ----- menu de gauche ----- */
  var saved = null, obsOn = false;
  function watchSide() {
    var s = $('exbSide'); if (!s || obsOn || !w.MutationObserver) return; obsOn = true;
    new w.MutationObserver(function () { if (saved != null) { s.scrollTop = saved; saved = null; } }).observe(s, { childList: true });
  }
  d.addEventListener('wheel', function (e) {
    var sd = e.target && e.target.closest ? e.target.closest('#exbSide') : null;
    if (!sd || sd.scrollHeight <= sd.clientHeight + 1) return;
    var b = sd.scrollTop; sd.scrollTop += e.deltaMode === 1 ? e.deltaY * 32 : e.deltaY;
    if (sd.scrollTop !== b) e.preventDefault();
  }, { passive: false });
  d.addEventListener('click', function (e) {
    var t = e.target; if (!t || !t.closest) return;
    var xs = t.closest('#exbSide .xs'), inSide = t.closest('#exbSide'), burger = t.closest('#exbBurger');
    if (burger && de.classList.contains('exb-side-keep')) { de.classList.remove('exb-side-keep'); setTimeout(function () { de.classList.remove('exb-side-peek'); }, 0); return; }
    if (xs && de.classList.contains('exb-side-off') && (de.classList.contains('exb-side-peek') || de.classList.contains('exb-side-keep'))) {
      if (!xs.querySelector('.ch')) { de.classList.remove('exb-side-keep'); return; } /* « Accueil » : retour au menu fixe */
      saved = $('exbSide').scrollTop; de.classList.add('exb-side-keep');
      setTimeout(function () { if (!de.classList.contains('exb-side-off')) de.classList.remove('exb-side-keep'); saved = null; }, 400);
    } else if (!inSide && !burger) { de.classList.remove('exb-side-keep'); }
  }, true);
  d.addEventListener('keydown', function (e) { if (e.key === 'Escape') de.classList.remove('exb-side-keep'); });

  function start() { css(); watchSide(); sizes(); w.setInterval(function () { css(); watchSide(); sizes(); }, 1500); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
