/* Excellencia Building — Mise à jour automatique et silencieuse (V120m)
 * Objectif : quand une nouvelle version est disponible, elle se télécharge TOUTE SEULE en arrière-plan,
 * sans fermer l'écran, sans message qui gêne, sans plantage.
 *
 *  • Vérification : 20 s après l'ouverture, puis toutes les 20 min, au retour sur l'application et au retour de la connexion
 *    (jamais en mode économie de données / connexion 2G, jamais hors connexion).
 *  • La nouvelle version est installée à côté de l'ancienne (service worker). Rien n'est rechargé pendant que vous travaillez.
 *  • V120q : elle n'est JAMAIS appliquée pendant que le logiciel est ouvert : aucun rechargement, aucun redémarrage, aucun message,
 *    aucune ligne dans la cloche. Elle est utilisée automatiquement à la prochaine ouverture du logiciel.
 *  • La vérification et le téléchargement attendent que vous ne travailliez pas (20 s sans clic ni frappe) pour ne rien ralentir.
 * Ne s'applique qu'à la version installée par navigateur / PWA (https). Windows (installateur) et Android (APK) se mettent à jour
 * en installant la nouvelle version du fichier. */
(function (w, d) {
  'use strict';
  if (w.EXB_MAJ) return;
  var K_LAST = 'exb_maj_reload_at', K_APPLIED = 'exb_maj_applied';
  var IDLE_MS = 2 * 60 * 1000, HIDDEN_MS = 30 * 1000, CHECK_MS = 20 * 60 * 1000, MIN_GAP = 10 * 60 * 1000;
  var ready = false, lastAct = Date.now(), hiddenAt = 0, lastCheck = 0, reg = null, timerApply = 0, timerDefer = 0;
  function lget(k) { try { return w.localStorage.getItem(k); } catch (e) { return null; } }
  function lset(k, v) { try { w.localStorage.setItem(k, v); } catch (e) {} }
  function log(msg, type) { try { if (typeof w.exbLogNotification === 'function') w.exbLogNotification(msg, type || 'info'); } catch (e) {} }
  function supported() { return !!(w.navigator && navigator.serviceWorker && /^https?:$/.test(w.location.protocol) && w.isSecureContext && w.top === w.self); }
  function slowNet() { try { var n = navigator.connection; return !!(n && (n.saveData || /^(slow-)?2g$/.test(n.effectiveType || ''))); } catch (e) { return false; } }

  /* ----- activité de l'utilisateur ----- */
  ['pointerdown', 'keydown', 'wheel', 'touchstart', 'input'].forEach(function (ev) { d.addEventListener(ev, function () { lastAct = Date.now(); }, { passive: true, capture: true }); });
  d.addEventListener('visibilitychange', function () {
    if (d.hidden) { hiddenAt = Date.now(); schedApply(HIDDEN_MS + 500); }
    else { hiddenAt = 0; lastAct = Date.now(); check(false); }
  });

  /* ----- le moment est-il sûr ? ----- */
  function busy() {
    try {
      var a = d.activeElement;
      if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.type !== 'search' && a.type !== 'button' && !a.readOnly && !a.disabled) return true;
      if (a && a.isContentEditable) return true;
      var m = d.querySelector('.xm, .modal.on, .modal.open, dialog[open], [role="dialog"].on, #exbLicLock, #exbLock');
      if (m && m.offsetParent !== null) return true;
      if (w.__exbBusy && w.__exbBusy > 0) return true;                 /* tout module peut poser w.__exbBusy = nombre de tâches longues en cours */
      if (w.EXBSYNC && w.EXBSYNC.busy) return true;
    } catch (e) {}
    return false;
  }
  function safeNow() {
    var idle = Date.now() - lastAct, away = d.hidden && hiddenAt && Date.now() - hiddenAt >= HIDDEN_MS;
    if (busy()) return false;
    return away || idle >= IDLE_MS;
  }
  function schedApply(ms) { clearTimeout(timerApply); timerApply = setTimeout(tryApply, ms || 15000); }
  function tryApply() {
    return; /* V120q : plus jamais de rechargement automatique ; la nouvelle version sert à la prochaine ouverture */
    if (!ready) return;
    var last = Number(lget(K_LAST)) || 0;
    if (Date.now() - last < MIN_GAP) return schedApply(MIN_GAP - (Date.now() - last) + 1000);
    if (!safeNow()) return schedApply(15000);
    lset(K_LAST, String(Date.now())); lset(K_APPLIED, '1');
    try { w.location.reload(); } catch (e) {}
  }

  /* ----- vérification ----- */
  function check(force) {
    try {
      if (!reg || (w.navigator.onLine === false) || slowNet()) return;
      if (!force && Date.now() - lastCheck < 5 * 60 * 1000) return;
      if (Date.now() - lastAct < 20000) { clearTimeout(timerDefer); timerDefer = setTimeout(function () { check(force); }, 30000); return; }   /* on ne télécharge pas pendant que vous travaillez */
      lastCheck = Date.now();
      reg.update().catch(function () {});
    } catch (e) {}
  }
  function watch(r) {
    function track(nw) {
      if (!nw) return;
      nw.addEventListener('statechange', function () {
        /* « installed » avec un contrôleur déjà présent = vraie mise à jour (pas la première installation) */
        if (nw.state === 'installed' && navigator.serviceWorker.controller) markReady();
      });
    }
    if (r.waiting && navigator.serviceWorker.controller) markReady();
    if (r.installing) track(r.installing);
    r.addEventListener('updatefound', function () { track(r.installing); });
  }
  var announced = false;
  function markReady() {
    ready = true; announced = true;   /* silencieux : ni message, ni cloche, ni rechargement */
  }

  function start() {
    if (!supported()) return;
    var had = !!navigator.serviceWorker.controller;   /* faux à la toute première installation : rien à appliquer */
    navigator.serviceWorker.getRegistration().then(function (r) {
      if (!r) return; reg = r; watch(r);
      /* le service worker actuel prend la main tout seul (skipWaiting) : on ne recharge PAS ici, on attend le bon moment */
      navigator.serviceWorker.addEventListener('controllerchange', function () { if (had && navigator.serviceWorker.controller) markReady(); });
      setTimeout(function () { check(true); }, 20000);
      setInterval(function () { check(false); }, CHECK_MS);
      w.addEventListener('online', function () { setTimeout(function () { check(true); }, 3000); });
    }).catch(function () {});
    if (lget(K_APPLIED) === '1') lset(K_APPLIED, '0');
  }
  w.EXB_MAJ = { version: 'V120q', check: function () { check(true); }, ready: function () { return ready; }, busy: busy };
  if (d.readyState === 'complete') start(); else w.addEventListener('load', start);
})(window, document);
