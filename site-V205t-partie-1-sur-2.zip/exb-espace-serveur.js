/* Excellencia Building V141u — 🗄 Espace serveur : voir la place utilisée sur Supabase, ARCHIVER les documents publiés
 * (plans, devis, notes de calcul, plans d'exécution) dans un ZIP sur votre ordinateur, LIBÉRER la place sur le serveur, et
 * RESTAURER plus tard depuis le ZIP. Réservé à l'administrateur. Prérequis : supabase/migration-v141u-archivage.sql.
 *
 * Principe (aucune perte possible) :
 *   1. choisir les publications (par exemple celles de plus de 30 jours) ;
 *   2. le logiciel télécharge leurs fichiers, fabrique le(s) ZIP, RELIT chaque ZIP pour vérifier qu'il est complet ;
 *   3. vous enregistrez les ZIP, vous confirmez, et SEULEMENT alors le serveur supprime les fichiers (et l'aperçu en base) ;
 *   4. la référence, le code et le QR restent valides : le client voit « document archivé » ; « Restaurer depuis un ZIP » remet le document en ligne.
 * La jauge « Base de données » de Supabase ne baisse pas tout de suite après une suppression (Postgres récupère la place plus tard,
 * par son nettoyage automatique) ; la jauge « Fichiers » (Storage) baisse tout de suite. */
(function (w, d) {
  'use strict';
  if (w.EXBESPACE) return;
  var PART_MAX = 120 * 1048576, TODOK = 'exb_espace_todo', QDB = 'exb_espace_quota_db', QST = 'exb_espace_quota_st';
  var BUCKETS = { plans: 'exb-plans-publics', devis: 'exb-devis-publics', calcul: 'exb-calcul-publics' };
  var GL = { plan: 'Plan', devis: 'Devis', note: 'Note de calcul', pex: 'Plan d’exécution' };
  var state = { items: [], parts: null, done: {} };

  function ls(k, def) { try { return JSON.parse(localStorage.getItem(k)) || def; } catch (e) { return def; } }
  function ss(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* plein */ } }
  function org() { try { return (w.EXBDB && w.EXBDB.org && w.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function online() { return !!(org() && w.exbSb && w.exbSb.isIn && w.exbSb.isIn() && navigator.onLine); }
  function api(p, o) { return w.exbSb.api(p, o); }
  function rpc(n, b) { return api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t, ms) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'info', ms || 5000); } catch (e) { /* repli */ } try { console.log(m); } catch (e) { /* rien */ } }
  function fmtB(n) { n = Number(n) || 0; if (n >= 1073741824) return (n / 1073741824).toFixed(2).replace('.', ',') + ' Go'; if (n >= 1048576) return (n / 1048576).toFixed(1).replace('.', ',') + ' Mo'; return Math.max(0, Math.round(n / 1024)) + ' Ko'; }
  function frDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '/' + m[2] + '/' + m[1] : (s || ''); }
  function today() { return new Date().toISOString().slice(0, 10); }
  function rnd32() { var a = new Uint8Array(16); (w.crypto || w.msCrypto).getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function cfgUrl() { try { return (w.exbSb.cfg && w.exbSb.cfg().url) || (w.EXB_SUPABASE && w.EXB_SUPABASE.url) || ''; } catch (e) { return ''; } }
  function base(p) { return String(p || '').split('/').pop(); }
  function ctype(n) { var e = (/\.([a-z0-9]+)$/i.exec(n) || [])[1]; return ({ pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', dwg: 'application/acad', dxf: 'application/dxf', zip: 'application/zip' })[(e || '').toLowerCase()] || 'application/octet-stream'; }
  function fnv(b) { var h = 0x811c9dc5; for (var i = 0; i < b.length; i++) { h ^= b[i]; h = Math.imul(h, 16777619); } return h >>> 0; }
  function save(blob, name) {
    var DL = w.EXBNativeDownload;
    if (DL && DL.save) return Promise.resolve(DL.save(blob, name));
    var u = URL.createObjectURL(blob), a = d.createElement('a'); a.href = u; a.download = name; d.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 8000); return Promise.resolve();
  }

  /* ---------- fichiers du serveur ---------- */
  function getBytes(bucket, path) {
    var u = cfgUrl() + '/storage/v1/object/public/' + bucket + '/' + path.split('/').map(encodeURIComponent).join('/');
    return fetch(u).then(function (r) { if (!r.ok) throw new Error('Fichier introuvable sur le serveur (' + r.status + ') : ' + base(path)); return r.arrayBuffer(); }).then(function (b) { return new Uint8Array(b); });
  }
  function up(bucket, o, token, name, bytes) {
    return api('/storage/v1/object/' + bucket + '/' + o + '/' + token + '/' + name, { method: 'POST', headers: { 'Content-Type': ctype(name), 'x-upsert': 'true' }, body: new Blob([bytes], { type: ctype(name) }) });
  }
  function purge(bucket, o, token) {
    if (!/^[a-f0-9]{32}$/.test(String(token || ''))) return Promise.resolve();
    var pre = o + '/' + token + '/';
    return api('/storage/v1/object/list/' + bucket, { method: 'POST', body: JSON.stringify({ prefix: pre, limit: 100 }) }).then(function (L) {
      var n = (L || []).map(function (x) { return pre + x.name; }); if (!n.length) return null;
      return api('/storage/v1/object/' + bucket, { method: 'DELETE', body: JSON.stringify({ prefixes: n }) });
    });
  }
  /* dossiers dont la suppression a échoué : on réessaie à la prochaine ouverture */
  function retryTodo() {
    var t = ls(TODOK, []); if (!t.length || !online()) return Promise.resolve();
    var keep = [];
    return t.reduce(function (p, x) { return p.then(function () { return purge(x.bucket, x.org, x.token).catch(function () { keep.push(x); }); }); }, Promise.resolve()).then(function () { ss(TODOK, keep); });
  }

  /* ---------- fenêtre ---------- */
  var BT = 'border:1px solid #cbd5e1;border-radius:10px;padding:9px 12px;background:#f1f5f9;color:#173565;font-weight:700;font-size:13px;cursor:pointer;';
  function ov() {
    var old = d.getElementById('exbEspace'); if (old) return old.firstChild;
    var o = d.createElement('div'); o.id = 'exbEspace'; o.style.cssText = 'position:fixed;inset:0;z-index:100001;background:rgba(15,23,42,.6);display:flex;align-items:flex-start;justify-content:center;padding:12px;overflow:auto';
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;max-width:820px;width:100%;padding:16px;margin-top:16px;font-family:Arial,sans-serif;color:#172033';
    o.appendChild(c); d.body.appendChild(o); return c;
  }
  function gauge(label, used, quota) {
    var pc = quota ? Math.min(100, Math.round(used * 100 / quota)) : 0, col = pc >= 90 ? '#c0392b' : pc >= 70 ? '#d98c00' : '#1f8a4c';
    return '<div style="margin:8px 0"><div style="display:flex;justify-content:space-between;font-size:13px"><b>' + label + '</b><span>' + fmtB(used) + ' / ' + fmtB(quota) + ' (' + pc + ' %)</span></div>' +
      '<div style="height:12px;background:#e5eaf2;border-radius:8px;overflow:hidden"><div style="height:100%;width:' + pc + '%;background:' + col + '"></div></div></div>';
  }
  function sumTaille(docs) { return (docs || []).map(function (x) { return x.taille || ''; }).filter(Boolean).join(' + '); }

  function open() {
    if (!online()) { say('Connectez-vous au serveur (☁️) en tant qu’administrateur pour gérer l’espace.', 'warn'); return Promise.resolve(); }
    var c = ov(); c.innerHTML = '<p>Chargement…</p>'; state.parts = null; state.done = {};
    return retryTodo().then(function () { return Promise.all([rpc('espace_stats', { p_org: org() }), rpc('docs_publics_pour_archivage', { p_org: org() })]); }).then(function (r) {
      var st = r[0], L = Array.isArray(r[1]) ? r[1] : [];
      if (!st || !st.ok) { c.innerHTML = head() + '<p style="color:#c0392b">' + esc((st && st.erreur) || 'Fonction serveur absente : exécutez supabase/migration-v141u-archivage.sql (Supabase › SQL Editor).') + '</p>'; wireHead(c); return; }
      state.items = L; paint(c, st);
    }).catch(function (e) { c.innerHTML = head() + '<p style="color:#c0392b">' + esc((e && e.message) || 'Erreur') + (/function|schema cache|PGRST/i.test((e && e.message) || '') ? ' — exécutez supabase/migration-v141u-archivage.sql.' : '') + '</p>'; wireHead(c); });
  }
  function head() { return '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b style="font-size:17px;color:#173565">🗄 Espace serveur — archiver et libérer de la place</b><button id="esX" style="border:0;border-radius:10px;padding:9px 12px;background:#e8edf5;color:#173565;font-weight:700;cursor:pointer">✕</button></div>'; }
  function wireHead(c) { var x = c.querySelector('#esX'); if (x) x.onclick = function () { var o = d.getElementById('exbEspace'); if (o) o.remove(); }; }

  function paint(c, st) {
    var qdb = Number(localStorage.getItem(QDB)) || 500, qst = Number(localStorage.getItem(QST)) || 1024;
    var h = head() +
      gauge('Base de données', st.db_bytes, qdb * 1048576) + gauge('Fichiers (Storage)', st.storage_bytes, qst * 1048576) +
      '<div style="font-size:12px;color:#64748b;margin:4px 0 10px">Quotas de votre offre Supabase (Settings › Usage) : base <input id="esQd" type="number" min="1" value="' + qdb + '" style="width:70px"> Mo · fichiers <input id="esQs" type="number" min="1" value="' + qst + '" style="width:70px"> Mo. ' +
      'Publications : ' + st.n_publies + ' (dont ' + st.n_archives + ' archivées) · aperçus en base : ' + fmtB(st.apercus_bytes) + '.</div>' +
      '<p style="background:#fff8e6;border:1px solid #f0d78c;border-radius:10px;padding:8px 10px;font-size:12.5px;margin:6px 0">ℹ️ Après une suppression, la jauge <b>Fichiers</b> baisse tout de suite. La jauge <b>Base de données</b> de Supabase, elle, ne baisse pas immédiatement : Postgres récupère la place plus tard par son nettoyage automatique.</p>' +
      '<h3 style="margin:14px 0 4px;color:#173565;font-size:15px">1. Choisir ce qu’on archive</h3>' +
      '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;font-size:13px;margin-bottom:6px">Publications modifiées il y a plus de <input id="esDays" type="number" min="0" value="30" style="width:60px"> jours ' +
      '<select id="esType"><option value="">Tous les types</option><option value="plan">Plans</option><option value="devis">Devis</option><option value="note">Notes de calcul</option><option value="pex">Plans d’exécution</option></select>' +
      '<button id="esSel" style="' + BT + 'padding:6px 10px">Cocher selon ce filtre</button><button id="esNone" style="' + BT + 'padding:6px 10px">Tout décocher</button></div>' +
      '<div id="esList" style="max-height:300px;overflow:auto;border:1px solid #e2e8f0;border-radius:10px"></div>' +
      '<p style="margin:10px 0 4px"><button id="esZip" style="' + BT + 'background:#0f766e;color:#fff;border-color:#0f766e">📦 Télécharger le ZIP des publications cochées</button> <span id="esCount" style="font-size:12px;color:#64748b"></span></p>' +
      '<div id="esStep2"></div>' +
      '<h3 style="margin:16px 0 4px;color:#173565;font-size:15px">Restaurer depuis un ZIP</h3>' +
      '<p style="font-size:12.5px;color:#64748b;margin:0 0 6px">Remet en ligne des documents archivés (mêmes référence et code, donc les QR déjà remis refonctionnent).</p>' +
      '<input id="esFile" type="file" accept=".zip" multiple><div id="esRes" style="font-size:13px;margin-top:6px"></div>';
    c.innerHTML = h; wireHead(c);
    var $ = function (i) { return c.querySelector('#' + i); };
    $('esQd').onchange = function () { try { localStorage.setItem(QDB, String(Math.max(1, Number(this.value) || 500))); } catch (e) { /* rien */ } };
    $('esQs').onchange = function () { try { localStorage.setItem(QST, String(Math.max(1, Number(this.value) || 1024))); } catch (e) { /* rien */ } };
    drawList(c); $('esSel').onclick = function () { applyFilter(c); }; $('esNone').onclick = function () { c.querySelectorAll('.esCk').forEach(function (k) { k.checked = false; }); count(c); };
    $('esZip').onclick = function () { makeZip(c); };
    $('esFile').onchange = function () { restore(c, this.files); };
  }
  function drawList(c) {
    var rows = state.items.filter(function (x) { return !x.archive && (x.docs || []).length; });
    var box = c.querySelector('#esList');
    box.innerHTML = rows.length ? '<table style="width:100%;border-collapse:collapse;font-size:12.5px"><tr style="text-align:left;background:#f1f5fb"><th style="padding:5px"></th><th>Référence</th><th>Document</th><th>Modifié</th><th>Taille</th></tr>' +
      rows.map(function (x, i) { return '<tr style="border-bottom:1px solid #eef2f7"><td style="padding:5px"><input type="checkbox" class="esCk" data-i="' + i + '"></td><td><b>' + esc(x.ref) + '</b><br><small>' + esc(GL[x.genre] || x.genre) + '</small></td><td>' + esc(x.titre) + '<br><small>' + esc(x.sous_titre || '') + '</small></td><td>' + frDate(String(x.maj_le || '').slice(0, 10)) + '</td><td>' + esc(sumTaille(x.docs) || '—') + '</td></tr>'; }).join('') + '</table>'
      : '<p style="padding:10px;color:#64748b;margin:0">Rien à archiver : aucune publication avec des fichiers en ligne.</p>';
    state.rows = rows; box.querySelectorAll('.esCk').forEach(function (k) { k.onchange = function () { count(c); }; }); count(c);
  }
  function applyFilter(c) {
    var days = Number(c.querySelector('#esDays').value) || 0, tp = c.querySelector('#esType').value, lim = Date.now() - days * 86400000;
    c.querySelectorAll('.esCk').forEach(function (k) { var x = state.rows[Number(k.getAttribute('data-i'))]; k.checked = (!tp || x.genre === tp) && new Date(x.maj_le).getTime() <= lim; }); count(c);
  }
  function picked(c) { var out = []; c.querySelectorAll('.esCk').forEach(function (k) { if (k.checked) out.push(state.rows[Number(k.getAttribute('data-i'))]); }); return out; }
  function count(c) { var n = picked(c).length; c.querySelector('#esCount').textContent = n ? n + ' publication' + (n > 1 ? 's' : '') + ' cochée' + (n > 1 ? 's' : '') : 'Aucune publication cochée'; }

  /* ---------- 2. fabriquer et vérifier le(s) ZIP ---------- */
  function zipApi() { return w.EXB_ZIP || null; }
  function makeZip(c) {
    var items = picked(c), box = c.querySelector('#esStep2'), Z = zipApi();
    if (!Z) { say('Module ZIP indisponible.', 'error'); return; }
    if (!items.length) { say('Cochez au moins une publication.', 'warn'); return; }
    box.innerHTML = '<p id="esProg">Préparation…</p>'; var prog = function (t) { var e = box.querySelector('#esProg'); if (e) e.textContent = t; };
    var o = org(), parts = [], cur = { entries: [], bytes: 0, items: [] }, n = 0;
    items.reduce(function (p, it) {
      return p.then(function () {
        prog('Téléchargement ' + (++n) + ' / ' + items.length + ' : ' + it.ref + '…');
        return rpc('docs_public_fiche', { p_org: o, p_table: it.table, p_ref: it.ref }).then(function (fiche) {
          if (!fiche) throw new Error('Fiche introuvable : ' + it.ref);
          var bucket = BUCKETS[it.table], docs = Array.isArray(fiche.docs) ? fiche.docs : [], files = [], total = 0;
          return docs.reduce(function (pp, doc) { return pp.then(function () { return getBytes(bucket, doc.fichier).then(function (b) { files.push({ doc: doc, bytes: b }); total += b.length; }); }); }, Promise.resolve()).then(function () {
            if (cur.bytes > 0 && cur.bytes + total > PART_MAX) { parts.push(cur); cur = { entries: [], bytes: 0, items: [] }; }
            cur.entries.push({ name: it.ref + '/fiche.json', data: JSON.stringify(fiche) });
            files.forEach(function (f) { cur.entries.push({ name: it.ref + '/' + base(f.doc.fichier), data: f.bytes }); });
            cur.items.push({ table: it.table, ref: it.ref, code: it.code, genre: it.genre, token: it.token, files: files.map(function (f) { return { name: base(f.doc.fichier), size: f.bytes.length, nom: f.doc.nom, format: f.doc.format, taille: f.doc.taille, kind: f.doc.kind }; }) });
            cur.bytes += total;
          });
        });
      });
    }, Promise.resolve()).then(function () {
      parts.push(cur); var N = parts.length;
      prog('Fabrication et vérification des ZIP…');
      return parts.reduce(function (p, part, i) {
        return p.then(function () {
          var man = { version: 'V141u', cree_le: new Date().toISOString(), org: o, partie: i + 1, sur: N, items: part.items };
          var entries = [{ name: 'manifest.json', data: JSON.stringify(man, null, 1) }].concat(part.entries);
          part.zip = Z.store(entries); part.name = 'Excellencia-archive-publications-' + today() + '-partie' + (i + 1) + 'sur' + N + '.zip';
          return Z.unzip(part.zip).then(function (back) {
            var by = {}; back.forEach(function (e) { by[e.name] = e.data; });
            entries.forEach(function (e) {
              var src = typeof e.data === 'string' ? new TextEncoder().encode(e.data) : e.data, got = by[e.name];
              if (!got || got.length !== src.length || fnv(got) !== fnv(src)) throw new Error('Vérification du ZIP échouée pour ' + e.name + ' : rien n’a été supprimé du serveur.');
            });
            part.blob = new Blob([part.zip], { type: 'application/zip' }); part.zip = null; part.ok = true;
          });
        });
      }, Promise.resolve()).then(function () { state.parts = parts; state.done = {}; step2(c); });
    }).catch(function (e) { box.innerHTML = '<p style="color:#c0392b">❌ ' + esc((e && e.message) || e) + '</p>'; });
  }
  function step2(c) {
    var box = c.querySelector('#esStep2'), P = state.parts, tot = P.reduce(function (s, p) { return s + p.items.length; }, 0), by = P.reduce(function (s, p) { return s + p.bytes; }, 0);
    box.innerHTML = '<div style="border:1px solid #b5e1c5;background:#effaf3;border-radius:10px;padding:10px"><b>✅ ' + tot + ' publication' + (tot > 1 ? 's' : '') + ' (' + fmtB(by) + ') prête' + (tot > 1 ? 's' : '') + ' dans ' + P.length + ' fichier' + (P.length > 1 ? 's' : '') + ' ZIP, relu' + (P.length > 1 ? 's' : '') + ' et vérifié' + (P.length > 1 ? 's' : '') + '.</b>' +
      '<p style="margin:8px 0 4px;font-size:13px">Enregistrez chaque ZIP (puis copiez-les sur une clé USB ou un disque : c’est votre seule copie une fois le serveur vidé).</p>' +
      P.map(function (p, i) { return '<div style="margin:4px 0"><button class="esDl" data-i="' + i + '" style="' + BT + '">⬇ ' + esc(p.name) + ' (' + fmtB(p.blob.size) + ')</button> <span class="esTick" data-i="' + i + '"></span></div>'; }).join('') +
      '<h3 style="margin:14px 0 4px;color:#173565;font-size:15px">3. Libérer l’espace sur le serveur</h3>' +
      '<label style="display:flex;gap:8px;align-items:flex-start;font-size:13px"><input type="checkbox" id="esOk" disabled> <span>J’ai enregistré tous les ZIP ci-dessus en lieu sûr. Je comprends que les fichiers seront supprimés du serveur (les références et QR restent valides).</span></label>' +
      '<p style="margin:8px 0 0"><button id="esFree" disabled style="' + BT + 'background:#c0392b;color:#fff;border-color:#c0392b;opacity:.5">🗑 Libérer l’espace maintenant</button></p><div id="esFreeRes" style="font-size:13px;margin-top:6px"></div></div>';
    var $ = function (s) { return box.querySelector(s); }, ready = function () { var all = P.every(function (_, i) { return state.done[i]; }); $('#esOk').disabled = !all; if (!all) { $('#esOk').checked = false; } $('#esFree').disabled = !(all && $('#esOk').checked); $('#esFree').style.opacity = $('#esFree').disabled ? '.5' : '1'; };
    box.querySelectorAll('.esDl').forEach(function (b) { b.onclick = function () { var i = Number(b.getAttribute('data-i')); save(P[i].blob, P[i].name).then(function () { state.done[i] = true; box.querySelector('.esTick[data-i="' + i + '"]').textContent = '✓ téléchargé'; ready(); }); }; });
    $('#esOk').onchange = ready; $('#esFree').onclick = function () { free(c); };
  }

  /* ---------- 3. libérer ---------- */
  function free(c) {
    var P = state.parts, o = org(), res = c.querySelector('#esFreeRes'), btn = c.querySelector('#esFree'), all = [], ok = 0, ko = [];
    if (!P || !P.every(function (p) { return p.ok; })) return;
    btn.disabled = true; P.forEach(function (p) { p.items.forEach(function (it) { all.push(it); }); });
    all.reduce(function (pr, it, i) {
      return pr.then(function () {
        res.textContent = 'Libération ' + (i + 1) + ' / ' + all.length + ' : ' + it.ref + '…';
        return rpc('docs_public_archiver', { p_org: o, p_table: it.table, p_ref: it.ref }).then(function (r) {
          if (!r || !r.ok) { ko.push(it.ref + ' (' + ((r && r.erreur) || 'refusé') + ')'); return; }
          var bucket = BUCKETS[it.table], td = ls(TODOK, []); td.push({ bucket: bucket, org: o, token: r.token }); ss(TODOK, td);
          return purge(bucket, o, r.token).then(function () { ss(TODOK, ls(TODOK, []).filter(function (x) { return x.token !== r.token; })); ok++; }, function () { ko.push(it.ref + ' (fichiers à supprimer plus tard — nouvel essai automatique à la prochaine ouverture)'); });
        }, function (e) { ko.push(it.ref + ' (' + ((e && e.message) || 'erreur') + ')'); });
      });
    }, Promise.resolve()).then(function () {
      res.innerHTML = '<b style="color:#176b3d">✅ ' + ok + ' publication' + (ok > 1 ? 's' : '') + ' archivée' + (ok > 1 ? 's' : '') + ' : fichiers supprimés du serveur.</b>' + (ko.length ? '<br><span style="color:#c0392b">À revoir : ' + esc(ko.join(' ; ')) + '</span>' : '') +
        '<br><button id="esAgain" style="' + BT + 'margin-top:6px">↻ Actualiser les jauges</button>';
      var a = res.querySelector('#esAgain'); if (a) a.onclick = open; state.parts = null;
    });
  }

  /* ---------- restaurer ---------- */
  function readFile(f) { return new Promise(function (ok, ko) { var r = new FileReader(); r.onload = function () { ok(new Uint8Array(r.result)); }; r.onerror = function () { ko(r.error); }; r.readAsArrayBuffer(f); }); }
  function restore(c, files) {
    var res = c.querySelector('#esRes'), Z = zipApi(), o = org(), okN = 0, msgs = [];
    if (!files || !files.length || !Z) return;
    res.textContent = 'Lecture…';
    Array.prototype.slice.call(files).reduce(function (p, f) {
      return p.then(function () { return readFile(f).then(function (b) { return Z.unzip(b); }).then(function (entries) {
        var by = {}; entries.forEach(function (e) { by[e.name] = e.data; });
        if (!by['manifest.json']) throw new Error(f.name + ' : manifest.json absent (ce n’est pas un ZIP d’archive Excellencia).');
        var man = JSON.parse(new TextDecoder().decode(by['manifest.json']));
        if (man.org !== o) throw new Error(f.name + ' : ce ZIP appartient à une autre entreprise.');
        return (man.items || []).reduce(function (pp, it) { return pp.then(function () { res.textContent = 'Restauration de ' + it.ref + '…'; return restoreOne(it, by, o).then(function (m) { okN++; if (m) msgs.push(m); }, function (e) { msgs.push(it.ref + ' : ' + ((e && e.message) || e)); }); }); }, Promise.resolve());
      }); });
    }, Promise.resolve()).then(function () {
      res.innerHTML = '<b style="color:#176b3d">✅ ' + okN + ' publication' + (okN > 1 ? 's' : '') + ' restaurée' + (okN > 1 ? 's' : '') + '.</b>' + (msgs.length ? '<br><span style="color:#b45309">' + msgs.map(esc).join('<br>') + '</span>' : '') + '<br><button id="esAgain2" style="' + BT + 'margin-top:6px">↻ Actualiser</button>';
      res.querySelector('#esAgain2').onclick = open;
    }, function (e) { res.innerHTML = '<span style="color:#c0392b">❌ ' + esc((e && e.message) || e) + '</span>'; });
  }
  function restoreOne(it, by, o) {
    var fiche = JSON.parse(new TextDecoder().decode(by[it.ref + '/fiche.json'] || new Uint8Array())), bucket = BUCKETS[it.table], token = rnd32(), docs = [];
    if (!fiche || !fiche.ref) return Promise.reject(new Error('fiche.json absente ou illisible.'));
    return it.files.reduce(function (p, f) {
      return p.then(function () { var b = by[it.ref + '/' + f.name]; if (!b) throw new Error('fichier manquant dans le ZIP : ' + f.name); return up(bucket, o, token, f.name, b).then(function () { docs.push({ nom: f.nom, fichier: o + '/' + token + '/' + f.name, format: f.format, taille: f.taille, kind: f.kind }); }); });
    }, Promise.resolve()).then(function () {
      var call = it.table === 'devis'
        ? rpc('devis_public_publier', { p_org: o, p_no: fiche.devis_no, p_projet: fiche.projet, p_client: fiche.client, p_prestataire: fiche.prestataire, p_montant: fiche.montant, p_validite: fiche.validite, p_date: fiche.date_devis, p_statut: fiche.statut, p_empreinte: fiche.empreinte, p_apercu: fiche.apercu || null, p_docs: docs, p_token: token })
        : it.table === 'calcul'
          ? rpc('calcul_public_publier', { p_org: o, p_genre: fiche.genre, p_no: fiche.doc_no, p_titre: fiche.titre, p_projet: fiche.projet, p_client: fiche.client, p_etabli: fiche.etabli_par, p_indice: fiche.indice, p_norme: fiche.norme, p_statut: fiche.statut, p_date: fiche.date_doc, p_empreinte: fiche.empreinte, p_apercu: fiche.apercu || null, p_docs: docs, p_token: token })
          : rpc('plan_public_publier', { p_org: o, p_plan_id: fiche.plan_id, p_ref_plan: fiche.ref_plan, p_titre: fiche.titre, p_type: fiche.type_doc, p_moe: fiche.maitre_oeuvre, p_mo: fiche.maitre_ouvrage, p_concepteur: fiche.concepteur, p_echelle: fiche.echelle, p_indice: fiche.indice, p_apercu: fiche.apercu || null, p_docs: docs, p_token: token, p_ref: fiche.ref });
      return call.then(function (r) {
        if (!r || !r.ok) { purge(bucket, o, token).catch(function () { /* rien */ }); throw new Error((r && r.erreur) || 'refusé par le serveur'); }
        if (r.ancien_token) purge(bucket, o, r.ancien_token).catch(function () { /* rien */ });
        return r.ref !== it.ref ? it.ref + ' : remis en ligne sous une NOUVELLE référence ' + r.ref + ' (l’ancienne publication n’existait plus).' : '';
      });
    });
  }

  w.EXBESPACE = { open: open, _fnv: fnv, _buildState: state };
})(window, document);
