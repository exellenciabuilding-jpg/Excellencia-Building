/* Excellencia Building — CORE v1 · identifiant stable unique pour tout objet (V186)
 * Cahier des charges unifié V1.0 : « Identifiant stable unique pour tout objet » (🟡 en V185 : EXBCore.id existait, mais rien ne l'imposait).
 *
 * Règle : toute fiche (enregistrement de premier niveau d'une collection « exb_* ») porte un identifiant stable :
 *   · son champ « id » s'il existe (jamais modifié : les liens entre modules en dépendent) ;
 *   · sinon un champ « uid » attribué ici, une fois pour toutes, et conservé aux modifications suivantes.
 * Deux voies, toutes deux sur l'unique point d'écriture commun (exbStorage.setItem) :
 *   1. À CHAQUE écriture d'une collection : les fiches sans identifiant en reçoivent un (aléatoire : EXBCore.id) ;
 *      un module qui reconstruit une fiche en perdant son « uid » le retrouve par sa référence naturelle (no, ref, code…) ;
 *      deux fiches qui partagent un même « uid » (copie par recopie d'objet) : la seconde en reçoit un nouveau.
 *   2. Au démarrage (balayage unique, différé) : les fiches EXISTANTES reçoivent un identifiant DÉTERMINISTE (calculé depuis la
 *      collection et la référence naturelle de la fiche ou, à défaut, son contenu) → deux appareils qui balaient la même
 *      donnée synchronisée obtiennent le même identifiant, sans conflit.
 * Hors périmètre (signalé par l'audit) : lignes imbriquées dans une fiche (lignes de devis…), tables clé→valeur, journaux et
 * files techniques, collections de plus de 1 Mo écrites par l'écran (traitées par le balayage).
 * Consulter : EXBCore.ids.audit()  ·  Forcer : EXBCore.ids.sweep()  ·  Retirer : supprimer la balise <script src="exb-core-ids.js">.
 * Aucune donnée existante n'est supprimée ni renommée : seul le champ « uid » est AJOUTÉ. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root && root.window === root) api.install(root);
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this), function () {
  'use strict';

  /* ---------- paramètres ---------- */
  var NATURAL = ['participant_id', 'matricule', 'no', 'number', 'numero', 'invoice_no', 'ref', 'reference', 'code'];
  /* Collections techniques : journaux, files, caches, préférences — pas des « objets » métier. */
  var SKIP = /(^exb_core_)|(^exb_(audit|errlog|usagelog|logged|session|lock|user|pass|theme|brand|logo)(_|$))|(_(log|logs|queue|outbox|inbox|cache|seen|hist|histo|history|historique|pending|undo|prefs|cfg|config|settings|events|notifications|notif|done|diag|sizes)(_|$))|(^exb_(ai|intel|sc|wf|lic|db|bk|bkc|big|maj|nudge|install|home|fab|onglets|dock)_)/;
  var MAX_INLINE = 1000000; /* caractères : au-delà, l'écran n'est pas ralenti (balayage différé) */
  var SWEEP_DELAY = 4000;

  /* ---------- fonctions pures (testables sous Node) ---------- */
  function isRec(o) { return o !== null && typeof o === 'object' && !Array.isArray(o); }
  function has(v) { return v !== undefined && v !== null && v !== '' && v !== 0 && v !== false; }
  function idOf(o) { return isRec(o) ? (has(o.id) ? String(o.id) : (has(o.uid) ? String(o.uid) : null)) : null; }
  function eligible(key) { return typeof key === 'string' && /^exb_[a-z0-9_]+$/.test(key) && !SKIP.test(key); }
  function typeOfKey(key) { return String(key).replace(/^exb_(v\d+_)?/, '').replace(/[^a-z0-9_]/g, '').slice(0, 24) || 'obj'; }
  function natural(o) { for (var i = 0; i < NATURAL.length; i++) { var v = o[NATURAL[i]]; if (has(v) && (typeof v === 'string' || typeof v === 'number') && String(v).length <= 80) return NATURAL[i] + '=' + v; } return null; }

  function h32(s, seed) { var h = seed >>> 0; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
  function hash(s) { return h32(s, 2166136261).toString(36) + h32(s, 2654435761).toString(36); }
  function stable(o) { /* sérialisation à clés triées, sans « uid » */
    if (Array.isArray(o)) return '[' + o.map(stable).join(',') + ']';
    if (isRec(o)) return '{' + Object.keys(o).filter(function (k) { return k !== 'uid'; }).sort().map(function (k) { return JSON.stringify(k) + ':' + stable(o[k]); }).join(',') + '}';
    return JSON.stringify(o === undefined ? null : o);
  }

  var rndFallback = function (n) { var s = ''; while (s.length < n) s += Math.random().toString(36).slice(2); return s.slice(0, n); };
  var newId = function (type) { return String(type).replace(/[^a-z0-9_]/gi, '').toLowerCase() + '_' + Date.now().toString(36) + '_' + rndFallback(5); };

  /* Attribue les identifiants manquants à `list` (modifiée en place). opts : { prev: liste précédente, legacy: true (déterministe), mk: fabrique d'identifiant }.
   * Retourne { changed, added, restored, regenerated, missing, duplicates } — `duplicates` : identifiants « id » en double (signalés, jamais corrigés). */
  function ensure(key, list, opts) {
    opts = opts || {};
    var type = typeOfKey(key), mk = opts.mk || newId, r = { changed: false, added: 0, restored: 0, regenerated: 0, records: 0, duplicates: [] };
    if (!Array.isArray(list)) return r;
    var prevByNat = null, used = {}, i, o, id;
    function prevIndex() {
      if (prevByNat) return prevByNat; prevByNat = {};
      (opts.prev || []).forEach(function (p) { if (isRec(p)) { var n = natural(p), pid = idOf(p); if (n && pid && !(n in prevByNat)) prevByNat[n] = pid; } });
      return prevByNat;
    }
    /* passe 1 : identifiants déjà présents (ils sont réservés) et doublons */
    for (i = 0; i < list.length; i++) {
      o = list[i]; if (!isRec(o)) continue; r.records++;
      id = idOf(o); if (!id) continue;
      if (!used[id]) { used[id] = 1; continue; }
      if (has(o.id)) { if (r.duplicates.indexOf(id) < 0) r.duplicates.push(id); } /* « id » d'un module : signalé, jamais modifié */
      else { delete o.uid; r.regenerated++; r.changed = true; } /* « uid » à nous (fiche recopiée) : refait en passe 2 */
    }
    /* passe 2 : attribution */
    for (i = 0; i < list.length; i++) {
      o = list[i]; if (!isRec(o) || idOf(o)) continue;
      var nat = natural(o), cand = null;
      if (opts.prev && nat) { cand = prevIndex()[nat]; if (cand && used[cand]) cand = null; }
      if (cand) { o.uid = cand; r.restored++; }
      else if (opts.legacy) { var base = type + '_L_' + hash(key + '|' + (nat || stable(o))), n = 1; cand = base; while (used[cand]) cand = base + '_' + (++n); o.uid = cand; r.added++; }
      else { do { cand = mk(type); } while (used[cand]); o.uid = cand; r.added++; }
      used[o.uid] = 1; r.changed = true;
    }
    return r;
  }

  function scan(key, list) { /* lecture seule : état d'une collection */
    var r = { key: key, records: 0, withId: 0, withUid: 0, missing: 0, duplicates: [] }, seen = {};
    list.forEach(function (o) {
      if (!isRec(o)) return; r.records++;
      var id = idOf(o); if (!id) { r.missing++; return; }
      if (has(o.id)) r.withId++; else r.withUid++;
      if (seen[id]) { if (r.duplicates.indexOf(id) < 0) r.duplicates.push(id); } else seen[id] = 1;
    });
    return r;
  }

  /* ---------- branchement navigateur ---------- */
  function install(w) {
    if (!w || w.__EXBIdsInstalled) return; w.__EXBIdsInstalled = true;
    var stats = { writes: 0, assigned: 0, restored: 0, regenerated: 0, deferred: {}, sweeps: 0, lastSweep: null, errors: 0 }, last = {};

    function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
    function parse(s) { try { return JSON.parse(s); } catch (e) { return null; } }
    function mkId(type) { try { if (w.EXBCore && w.EXBCore.id) return w.EXBCore.id(type); } catch (e) {} return newId(type); }

    function process(S, k, v) {
      if (typeof v !== 'string' || v.charCodeAt(0) !== 91 || !eligible(k)) return v;
      if (last[k] === v) return v;
      if (v.length > MAX_INLINE) { stats.deferred[k] = v.length; return v; }
      var list = parse(v); if (!Array.isArray(list)) return v;
      stats.writes++;
      var need = false; for (var i = 0; i < list.length; i++) { var o = list[i]; if (isRec(o) && !idOf(o)) { need = true; break; } }
      var prev = need ? parse(S.getItem(k)) : null;
      var r = ensure(k, list, { prev: Array.isArray(prev) ? prev : null, mk: mkId });
      if (!r.changed) { last[k] = v; return v; }
      stats.assigned += r.added; stats.restored += r.restored; stats.regenerated += r.regenerated;
      var out = JSON.stringify(list); last[k] = out; return out;
    }

    function keys(S) { var a = []; try { for (var i = 0; i < S.length; i++) { var k = S.key(i); if (k && eligible(k)) a.push(k); } } catch (e) {} return a; }

    /* Balayage : identifiants déterministes pour les fiches existantes. Retourne le détail par collection. */
    function sweep() {
      var S = store(), out = { collections: 0, records: 0, assigned: 0, refused: [], skipped: [] };
      if (!S) return out;
      var ro = false; try { var inf = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); ro = !!(inf && inf.on && inf.role === 'lecteur'); } catch (e) {}
      keys(S).forEach(function (k) {
        var raw = S.getItem(k); if (typeof raw !== 'string' || raw.charCodeAt(0) !== 91) return;
        var list = parse(raw); if (!Array.isArray(list)) return;
        var r = ensure(k, list, { legacy: true }); out.collections++; out.records += r.records;
        if (!r.changed) return;
        if (ro) { out.skipped.push(k); return; }
        try { S.setItem(k, JSON.stringify(list)); } catch (e) { stats.errors++; out.refused.push(k); return; }
        var back = parse(S.getItem(k)); var ok = Array.isArray(back) && scan(k, back).missing === 0;
        if (ok) { out.assigned += r.added; stats.assigned += r.added; try { if (w.EXBDB && w.EXBDB.mark) w.EXBDB.mark(k); } catch (e) {} } else out.refused.push(k);
      });
      stats.sweeps++; stats.lastSweep = new Date().toISOString();
      try { if (out.assigned && w.EXBCore) { w.EXBCore.bus.emit('ids.sweep', { assigned: out.assigned, collections: out.collections }, 'ids'); w.EXBCore.audit.log('ids.balayage', 'exb_*', { assigned: out.assigned, collections: out.collections }); } } catch (e) {}
      return out;
    }

    /* Audit en lecture seule. */
    function audit() {
      var S = store(), rows = [], ignored = [], tot = { collections: 0, records: 0, withId: 0, withUid: 0, missing: 0, duplicates: 0 };
      if (!S) return { ok: false, error: 'stockage indisponible', rows: rows, ignored: ignored, totals: tot, stats: stats };
      try {
        for (var i = 0; i < S.length; i++) {
          var k = S.key(i); if (!k || !/^exb_/.test(k)) continue;
          if (!eligible(k)) { ignored.push({ key: k, why: 'technique' }); continue; }
          var raw = S.getItem(k); if (typeof raw !== 'string') continue;
          if (raw.charCodeAt(0) !== 91) { ignored.push({ key: k, why: 'pas une liste' }); continue; }
          var list = parse(raw); if (!Array.isArray(list)) { ignored.push({ key: k, why: 'illisible' }); continue; }
          var s = scan(k, list); if (!s.records) { ignored.push({ key: k, why: 'aucune fiche' }); continue; }
          rows.push(s); tot.collections++; tot.records += s.records; tot.withId += s.withId; tot.withUid += s.withUid; tot.missing += s.missing; tot.duplicates += s.duplicates.length;
        }
      } catch (e) { stats.errors++; }
      rows.sort(function (a, b) { return b.missing - a.missing || a.key.localeCompare(b.key); });
      return { ok: tot.missing === 0 && tot.duplicates === 0, rows: rows, ignored: ignored, totals: tot, stats: JSON.parse(JSON.stringify(stats)) };
    }

    function hook() {
      var S = store(); if (!S || S.__ids || typeof S.setItem !== 'function') return false;
      var orig = S.setItem; S.__ids = true;
      S.setItem = function (k, v) {
        var nv = v; try { nv = process(S, k, v); } catch (e) { stats.errors++; nv = v; }
        return orig.call(this, k, nv);
      };
      return true;
    }

    /* Installation APRÈS les adaptateurs du noyau (ils comparent la valeur stockée à celle qu'ils reçoivent : nous devons être
     * la couche extérieure pour que les deux voient la valeur définitive). */
    var tries = 0, t = setInterval(function () {
      tries++; var S = store(), adaptersReady = !!(S && S.__coreAd) || tries > 24;
      if (adaptersReady && hook()) { clearInterval(t); setTimeout(function () { try { sweep(); } catch (e) { stats.errors++; } }, SWEEP_DELAY); }
      else if (tries > 80) clearInterval(t);
    }, 500);

    var api = { audit: audit, sweep: sweep, idOf: idOf, stats: function () { return JSON.parse(JSON.stringify(stats)); }, eligible: eligible, ensure: ensure };
    w.EXBIds = api;
    var c = 0, t2 = setInterval(function () {
      if (w.EXBCore) {
        clearInterval(t2); w.EXBCore.ids = api; w.EXBCore.idOf = idOf;
        var h0 = w.EXBCore.health; if (typeof h0 === 'function') w.EXBCore.health = function () { return h0.apply(this, arguments).then(function (r) { try { var a = audit(); r.ids = { collections: a.totals.collections, records: a.totals.records, missing: a.totals.missing, duplicates: a.totals.duplicates }; } catch (e) {} return r; }); };
      } else if (++c > 60) clearInterval(t2);
    }, 250);
  }

  return { ensure: ensure, scan: scan, idOf: idOf, eligible: eligible, typeOfKey: typeOfKey, natural: natural, hash: hash, stable: stable, install: install, NATURAL: NATURAL };
});
