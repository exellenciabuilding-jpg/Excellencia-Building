/* Excellencia Building V99w — PANNEAU « 👥 ÉQUIPE » (réservé à l'administrateur de l'entreprise en ligne).
 * - Inviter un collègue : nom, e-mail, rôle (Administrateur / Éditeur / Lecteur) et fonction (Comptable, RH, Direction…).
 *   S'il a déjà un compte : ajouté tout de suite. Sinon : invitation enregistrée, appliquée dès qu'il se connecte avec cet e-mail.
 * - Message d'invitation prêt à copier ou à envoyer par WhatsApp (lien + e-mail + code d'invitation).
 * - Liste des membres : changer le rôle / la fonction, retirer. Invitations en attente : renvoyer / annuler.
 * Nécessite supabase/migration-v99w-equipe.sql. Ne modifie aucune donnée existante de l'application. */
(function(w,d){'use strict';
var $=function(i){return d.getElementById(i)};
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
var ROLES=[['admin','Administrateur'],['editeur','Éditeur'],['lecteur','Lecteur']];
var FONCS=[['polyvalent','Polyvalent'],['direction','Direction'],['chef_projet','Chef de projet'],['conducteur','Conducteur de travaux'],['bureau_etudes','Bureau d’études'],['architecte','Architecte'],['formateur','Formateur'],['comptable','Comptable'],['rh','Ressources humaines'],['magasinier','Magasinier']];
function lab(list,v){for(var i=0;i<list.length;i++)if(list[i][0]===v)return list[i][1];return v}
function opts(list,sel){return list.map(function(x){return '<option value="'+x[0]+'"'+(x[0]===sel?' selected':'')+'>'+esc(x[1])+'</option>'}).join('')}
function fr(t){if(!t)return '—';var x=new Date(t);return isNaN(x)?'—':x.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})}
function isIn(){return !!(w.exbSb&&w.exbSb.isIn&&w.exbSb.isIn())}
function rpc(n,b){return w.exbSb.api('/rest/v1/rpc/'+n,{method:'POST',body:JSON.stringify(b||{})})}
function srvErr(e){var m=String(e&&e.message||e);if(/equipe_|42883|404|function|schema cache/i.test(m)&&!/administrateur|invalide|maximal|introuvable|dernier/i.test(m))return 'Fonction non installée : exécutez supabase/migration-v99w-equipe.sql dans Supabase (SQL Editor). ('+m+')';return m}
var ORG=null,DATA={membres:[],invitations:[]},LOADING=false,ERR='',NOTE='',me='';

async function load(){
 if(!isIn()){ORG=null;render();return}
 LOADING=true;ERR='';render();
 try{ORG=await rpc('mon_organisation');me=String((w.exbSb.cfg&&w.exbSb.cfg().email)||'').toLowerCase();
  if(!ORG||!ORG.id)ERR='Aucune entreprise en ligne : créez-la ou rejoignez-la dans Paramètres › Base partagée.';
  else if(ORG.role!=='admin')ERR='Ce panneau est réservé à l’administrateur de l’entreprise.';
  else{DATA=await rpc('equipe_liste',{p_org:ORG.id});ensureToken()}}
 catch(e){ERR=srvErr(e)}
 LOADING=false;render()}

/* V99zzj — depuis l'appareil administrateur (clé privée présente), enregistre sur le serveur l'abonnement signé de l'entreprise :
   c'est lui qu'un invité reçoit quand il saisit son code d'invitation sur l'écran de verrouillage. Renouvelé tous les 30 jours (validité 400 jours). */
async function ensureToken(){
 try{if(!ORG||!ORG.id||ORG.role!=='admin'||!w.EXBLIC||!w.EXBLIC.isAdmin||!w.EXBLIC.isAdmin()||!w.EXBLIC.make)return;
  var k='exb_inv_tok_'+ORG.id,t=0;try{t=+localStorage.getItem(k)||0}catch(e){}
  if(Date.now()-t<30*864e5)return;
  var exp=new Date(Date.now()+400*864e5);exp.setHours(23,59,0,0);
  var tok=await w.EXBLIC.make({name:ORG.nom||'',exp:exp,grace:7});
  await rpc('equipe_definir_jeton',{p_org:ORG.id,p_jeton:tok});
  try{localStorage.setItem(k,String(Date.now()))}catch(e){}}catch(e){}}
function appUrl(){return (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,''))}
function espaceLien(f){return f==='comptable'?'comptable.html':f==='architecte'?'architecte.html':f==='direction'?'direction.html':f==='rh'?'administration.html':f==='magasinier'?'magasin.html':f==='formateur'?'espace-formation.html':(f==='chef_projet'||f==='conducteur')?'chantier.html':f==='bureau_etudes'?'ingenieur.html':''}
function message(i){var nom=i.nom?i.nom.split(' ')[0]:'';
 return 'Bonjour'+(nom?' '+nom:'')+',\n\nVous êtes invité(e) à rejoindre « '+(ORG&&ORG.nom||'notre entreprise')+' » sur Excellencia Building (rôle : '+lab(ROLES,i.role)+' · fonction : '+lab(FONCS,i.fonction)+').\n\n'+
 (i.fonction==='formateur'?'1) Ouvrez votre Espace Formation : '+appUrl()+'espace-formation.html\n2) Si un écran « code d’activation » s’affiche, saisissez UNIQUEMENT ce code d’invitation : '+(ORG&&ORG.code||'')+'\n3) Sur l’écran de connexion, touchez « Première connexion » et créez votre compte avec CETTE adresse e-mail : '+i.email+' (vous choisissez votre mot de passe)\n\nVous y gérez apprenants, formations, sessions, évaluations et certificats. Les reçus de paiement sont établis par le comptable.\n(Votre portail à matricule reste disponible : '+appUrl()+'espace-formateur.html)\n\nÀ bientôt.':'1) Ouvrez : '+appUrl()+espaceLien(i.fonction)+'\n2) Si un écran « code d’activation » s’affiche, saisissez UNIQUEMENT ce code d’invitation : '+(ORG&&ORG.code||'')+'\n3) Sur l’écran de connexion, touchez « Première connexion » et créez votre compte avec CETTE adresse e-mail : '+i.email+' (vous choisissez votre mot de passe)\n\nVous rejoignez l’entreprise automatiquement. À bientôt.')}
async function copy(t){try{await navigator.clipboard.writeText(t);return true}catch(e){return false}}
function modal(html,onOpen){var o=$('exbEqModal');if(o)o.remove();o=d.createElement('div');o.id='exbEqModal';o.className='no-print';
 o.style.cssText='position:fixed;inset:0;z-index:100005;background:#0009;display:grid;place-items:center;padding:14px';
 o.innerHTML='<div class="card" style="width:min(540px,100%);max-height:92vh;overflow:auto;margin:0">'+html+'</div>';
 o.addEventListener('click',function(e){if(e.target===o)o.remove()});d.body.appendChild(o);if(onOpen)onOpen(o);return o}
function closeM(){var o=$('exbEqModal');if(o)o.remove()}
function showMessage(i,titre){var txt=message(i);
 modal('<h2>'+esc(titre||'✉️ Message d’invitation')+'</h2><textarea id="eq_msg" readonly rows="11" style="width:100%">'+esc(txt)+'</textarea><div style="display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;margin-top:12px"><button class="muted" id="eq_x">Fermer</button><button class="muted" id="eq_cp">📋 Copier</button><button class="primary" id="eq_wa">💬 Envoyer par WhatsApp</button></div>',function(){
  $('eq_x').onclick=closeM;
  $('eq_cp').onclick=async function(){$('eq_cp').textContent=(await copy(txt))?'✓ Copié':'Sélectionnez le texte'};
  $('eq_wa').onclick=function(){w.open('https://wa.me/?text='+encodeURIComponent(txt),'_blank','noopener')}})}

async function invite(){
 var nom=$('eq_nom').value.trim(),em=$('eq_em').value.trim().toLowerCase(),role=$('eq_role').value,fn=$('eq_fn').value;
 if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)){NOTE='<span class="ann">Adresse e-mail invalide.</span>';return render(true)}
 var b=$('eq_go');b.disabled=true;
 try{var r=await rpc('equipe_inviter',{p_org:ORG.id,p_email:em,p_nom:nom||null,p_role:role,p_fonction:fn});
  await load();
  if(r&&r.statut==='ajoute'){NOTE='<span class="valid">✓ '+esc(em)+' a déjà un compte : il est ajouté à l’équipe.</span>'}
  else{NOTE='<span class="valid">✓ Invitation enregistrée pour '+esc(em)+'.</span>';showMessage({email:em,nom:nom,role:role,fonction:fn},'✉️ Invitation enregistrée — envoyez ce message')}
  render()}
 catch(e){NOTE='<span class="ann">'+esc(srvErr(e))+'</span>';b.disabled=false;render(true)}}

async function changeMember(uid,field,val,sel){var m=DATA.membres.filter(function(x){return x.user_id===uid})[0];if(!m)return;
 var role=field==='role'?val:m.role,fn=field==='fonction'?val:m.fonction;
 try{await rpc('equipe_modifier',{p_org:ORG.id,p_user:uid,p_role:role,p_fonction:fn});m.role=role;m.fonction=fn;NOTE='<span class="valid">✓ Enregistré.</span>';render(true)}
 catch(e){NOTE='<span class="ann">'+esc(srvErr(e))+'</span>';load()}}
async function remove(uid,okd){var m=DATA.membres.filter(function(x){return x.user_id===uid})[0];if(!m)return;
 if(!okd){(window.EXBUI?window.EXBUI.confirm:function(m){return Promise.resolve(window.confirm(m))})('Retirer '+(m.nom||m.email||'ce membre')+' de l’entreprise ?\nIl n’aura plus accès aux données. Son compte n’est pas supprimé.',{ok:'Retirer',danger:1}).then(function(y){if(y)remove(uid,1)});return}
 try{await rpc('equipe_retirer',{p_org:ORG.id,p_user:uid});NOTE='<span class="valid">✓ Membre retiré.</span>';load()}catch(e){NOTE='<span class="ann">'+esc(srvErr(e))+'</span>';render(true)}}
async function cancel(id,okd){if(!okd){(window.EXBUI?window.EXBUI.confirm:function(m){return Promise.resolve(window.confirm(m))})('Annuler cette invitation ?',{ok:'Annuler l’invitation',non:'Garder'}).then(function(y){if(y)cancel(id,1)});return}
 try{await rpc('equipe_annuler',{p_id:id});load()}catch(e){NOTE='<span class="ann">'+esc(srvErr(e))+'</span>';render(true)}}

function render(keep){var el=$('equipe');if(!el||el.style.display==='none')return;
 var head='<div class="card"><h2>👥 Équipe</h2><p class="hint">Invitez vos collègues, choisissez leur rôle et leur fonction. Chacun ne voit que ce que sa fonction autorise.'+(ORG&&ORG.nom?' Entreprise : <b>'+esc(ORG.nom)+'</b>.':'')+'</p></div>';
 if(!isIn()){el.innerHTML=head+'<div class="card"><p class="hint">Connectez-vous à votre compte en ligne (Paramètres › Synchronisation) pour gérer l’équipe.</p></div>';return}
 if(LOADING&&!keep){el.innerHTML=head+'<div class="card"><p class="hint">Chargement…</p></div>';return}
 if(ERR){el.innerHTML=head+'<div class="card"><p class="ann">'+esc(ERR)+'</p><button class="muted" id="eq_rf">↻ Réessayer</button></div>';var r0=$('eq_rf');if(r0)r0.onclick=load;return}
 var form='<div class="card"><h2>➕ Inviter un membre</h2><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px"><div><label>Nom et prénom</label><input id="eq_nom" placeholder="Ex. Marie Kabila"></div><div><label>Adresse e-mail</label><input id="eq_em" type="email" inputmode="email" autocapitalize="none" placeholder="prenom@exemple.com"></div><div><label>Rôle</label><select id="eq_role">'+opts(ROLES,'editeur')+'</select></div><div><label>Fonction</label><select id="eq_fn">'+opts(FONCS,'polyvalent')+'</select></div></div><p class="hint"><b>Administrateur</b> : tout voir et gérer · <b>Éditeur</b> : saisir et modifier selon sa fonction · <b>Lecteur</b> : consulter seulement. Les données du personnel, de la paie et de la banque sont réservées à l’administrateur et aux fonctions RH, comptable et direction.</p><div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap"><button class="primary" id="eq_go">✉️ Inviter</button><span id="eq_note">'+NOTE+'</span></div></div>';
 var mrows=(DATA.membres||[]).map(function(m){var self=m.email&&me&&String(m.email).toLowerCase()===me;
  return '<tr><td><b>'+esc(m.nom||'—')+'</b>'+(self?' <span class="pill">vous</span>':'')+'<br><span class="hint">'+esc(m.email||'')+'</span></td><td><select data-u="'+esc(m.user_id)+'" data-f="role">'+opts(ROLES,m.role)+'</select></td><td><select data-u="'+esc(m.user_id)+'" data-f="fonction">'+opts(FONCS,m.fonction)+'</select></td><td>'+esc(fr(m.depuis))+'</td><td style="white-space:nowrap"><button class="primary" data-ch="'+esc(m.email||'')+'" data-nm="'+esc(m.nom||'')+'" data-fn="'+esc(m.fonction||'')+'">🏗️ Chantiers</button> '+(self?'':'<button class="muted" data-rm="'+esc(m.user_id)+'">Retirer</button>')+'</td></tr>'}).join('');
 var members='<div class="card"><h2>👤 Membres ('+(DATA.membres||[]).length+')</h2><div class="tablewrap"><table class="tbl"><thead><tr><th>Membre</th><th>Rôle</th><th>Fonction</th><th>Depuis</th><th></th></tr></thead><tbody>'+mrows+'</tbody></table></div></div>';
 var irows=(DATA.invitations||[]).map(function(i,n){return '<tr><td><b>'+esc(i.nom||'—')+'</b><br><span class="hint">'+esc(i.email)+'</span></td><td>'+esc(lab(ROLES,i.role))+'</td><td>'+esc(lab(FONCS,i.fonction))+'</td><td>'+esc(fr(i.cree_le))+'</td><td style="white-space:nowrap"><button class="primary" data-msg="'+n+'">✉️ Message</button> <button class="muted" data-cx="'+esc(i.id)+'">Annuler</button></td></tr>'}).join('');
 var inv='<div class="card"><h2>⏳ Invitations en attente ('+(DATA.invitations||[]).length+')</h2>'+(irows?'<div class="tablewrap"><table class="tbl"><thead><tr><th>Personne</th><th>Rôle</th><th>Fonction</th><th>Envoyée</th><th></th></tr></thead><tbody>'+irows+'</tbody></table></div><p class="hint">Dès que la personne crée son compte avec cette adresse e-mail et se connecte, elle rejoint l’entreprise avec ce rôle et cette fonction.</p>':'<p class="hint">Aucune invitation en attente.</p>')+'</div>';
 var keepVals=keep&&$('eq_em')?{n:$('eq_nom').value,e:$('eq_em').value,r:$('eq_role').value,f:$('eq_fn').value}:null;
 el.innerHTML=head+form+members+inv;
 if(keepVals){$('eq_nom').value=keepVals.n;$('eq_em').value=keepVals.e;$('eq_role').value=keepVals.r;$('eq_fn').value=keepVals.f}
 $('eq_go').onclick=invite;
 el.querySelectorAll('select[data-u]').forEach(function(s){s.onchange=function(){changeMember(s.dataset.u,s.dataset.f,s.value,s)}});
 el.querySelectorAll('button[data-ch]').forEach(function(b){b.onclick=function(){chantiers(b.dataset.ch,b.dataset.nm,b.dataset.fn)}});
 el.querySelectorAll('button[data-rm]').forEach(function(b){b.onclick=function(){remove(b.dataset.rm)}});
 el.querySelectorAll('button[data-cx]').forEach(function(b){b.onclick=function(){cancel(b.dataset.cx)}});
 el.querySelectorAll('button[data-msg]').forEach(function(b){b.onclick=function(){showMessage(DATA.invitations[+b.dataset.msg])}})}

/* V116 — rattacher un membre de l'équipe à un ou plusieurs chantiers terrain (le compte existe déjà : aucun mot de passe à créer). */
var CHROLES=[['admin','Administrateur du chantier'],['conducteur','Conducteur / chef de chantier'],['ingenieur','Ingénieur / technicien'],['magasinier','Magasinier'],['terrain','Équipe terrain'],['lecture','Lecture seule']];
var F2C={direction:'admin',chef_projet:'conducteur',conducteur:'conducteur',bureau_etudes:'ingenieur',architecte:'ingenieur',formateur:'terrain',magasinier:'magasinier',comptable:'lecture',rh:'lecture',polyvalent:'terrain'};
async function chantiers(email,nom,fonc){
 if(!email){exbAlert('Ce membre n’a pas d’adresse e-mail enregistrée.');return}
 var L;try{L=await rpc('chantier_liste')||[]}catch(e){exbAlert('Liste des chantiers indisponible : '+(e.message||e)+'\n\nSi le message parle d’administrateur, ouvrez Demandes reçues › Chantiers terrain avec le compte administrateur du serveur.');return}
 if(!L.length){exbAlert('Aucun chantier terrain. Créez-en un dans Demandes reçues › Chantiers terrain.');return}
 var old=$('eq_ch_ov');if(old)old.remove();
 var ov=d.createElement('div');ov.id='eq_ch_ov';ov.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:99999;overflow:auto;padding:12px';
 ov.innerHTML='<div style="max-width:560px;margin:0 auto;background:#fff;border-radius:12px;padding:14px"><b style="font-size:16px">🏗️ Chantiers de '+esc(nom||email)+'</b><p class="hint">Cochez les chantiers où cette personne travaille. Elle se connecte au logiciel chantier avec son compte existant.</p><label>Rôle sur le chantier</label><select id="eq_chr" style="width:100%;padding:8px">'+opts(CHROLES,F2C[fonc]||'terrain')+'</select><div style="margin:10px 0">'+L.map(function(x,i){return '<label style="display:flex;gap:8px;align-items:center;padding:5px 0;border-top:1px solid #e5e9f0"><input type="checkbox" data-k="'+i+'"> <span><b>'+esc(x.name)+'</b> <span class="hint">'+esc(x.code||'')+' · '+(x.membres||0)+' membre(s)</span></span></label>'}).join('')+'</div><div id="eq_chm"></div><button class="primary" id="eq_chgo">✅ Rattacher</button> <button class="muted" id="eq_chx">Fermer</button></div>';
 d.body.appendChild(ov);$('eq_chx').onclick=function(){ov.remove()};
 $('eq_chgo').onclick=async function(){var sel=[].slice.call(ov.querySelectorAll('input[data-k]:checked')).map(function(c){return L[+c.dataset.k]});
  if(!sel.length){$('eq_chm').innerHTML='<p class="ann">Cochez au moins un chantier.</p>';return}
  var role=$('eq_chr').value,out=[];this.disabled=true;
  for(var i=0;i<sel.length;i++){try{await rpc('chantier_membre_ajouter',{p_site:sel[i].id,p_email:email,p_role:role,p_mdp:null});out.push('✓ '+esc(sel[i].name))}catch(e){var m=String(e&&e.message||e);out.push('✗ '+esc(sel[i].name)+' : '+esc(/compte|introuvable|exist/i.test(m)?m+' — la personne doit d’abord créer son compte (e-mail identique).':m))}}
  $('eq_chm').innerHTML='<p>'+out.join('<br>')+'</p>';this.disabled=false}}
/* ---------- montage : bouton + section (seulement si connecté en ligne et administrateur de l'entreprise) ---------- */
/* V144e (forfait internet) : avant, « mon_organisation » était demandé au serveur toutes les 4 s, indéfiniment, tant que le compte n'était pas administrateur de l'entreprise
   (≈ 900 requêtes par heure). Maintenant : une vérification, puis au plus une toutes les 30 min (non-administrateur) ou 2 min (erreur réseau) ;
   rien en arrière-plan ni hors connexion ; nouvelle vérification immédiate si le compte (e-mail) change. */
var tries=0,mounted=false,checking=false,lastChk=0,waitChk=0,lastMail='',admOk=false;
async function mount(){if(mounted||checking||!isIn())return;
 if(d.hidden||(w.navigator&&w.navigator.onLine===false))return;
 var mail='';try{mail=String((w.exbSb.cfg&&w.exbSb.cfg().email)||'').toLowerCase()}catch(e){}
 if(mail!==lastMail){lastMail=mail;lastChk=0;waitChk=0;admOk=false}
 if(Date.now()-lastChk<waitChk)return;
 checking=true;lastChk=Date.now();
 try{if(!admOk){var o=await rpc('mon_organisation');if(!o||o.role!=='admin'){checking=false;waitChk=30*60000;return}admOk=true}}catch(e){checking=false;waitChk=2*60000;return}
 waitChk=0;
 var adm=$('administration'),b=$('bprop')||$('badm');if(!adm||!b){checking=false;return}
 var anc=$('exbModBar')||$('exbCrumb');if(!anc&&++tries<12){checking=false;return}
 if(!$('equipe')){(anc||adm).insertAdjacentHTML('afterend','<section id="equipe" class="no-print" style="display:none"></section>');
  b.insertAdjacentHTML('afterend',' <button id="bequipe" onclick="show(\'equipe\')">👥 Équipe</button>');
  var os=w.show;w.show=function(x){var r=os.apply(this,arguments);var el=$('equipe');if(el)el.style.display=x==='equipe'?'':'none';if(x==='equipe'){render();load()}return r}}
 mounted=true;checking=false}
setInterval(mount,4000);setTimeout(mount,2500);
w.EXB_EQUIPE={reload:load,message:message,chantiers:chantiers,version:'V116'};
})(window,document);
