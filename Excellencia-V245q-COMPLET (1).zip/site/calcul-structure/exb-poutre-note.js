/* V245q — Note de calcul « poutre continue » + plan d'exécution : même présentation que les notes existantes du calculateur
   (bloc .ti + pages .pg avec en-tête .hd, tableaux, enveloppes hachurées orange = maximum / bleu = minimum de EXBR.svgEnvPoutre).
   Fonctions pures. Navigateur : window.EXBPNOTE ; Node : require.
   API : calc(o) → données de calcul ; note(o) → chaîne HTML (pages de calcul) ; plan(o) → chaîne HTML (feuille de plan d'exécution) ; doc(o) = note + plan.
   o : { res (EXBPCONT.analyse), ch (EXBPA.chapeaux, facultatif : recalculé sinon), s (section et matériaux, cm / MPa :
         b0, h, enr, dt, fc, fe, t, fiss, b, h0, colonnes, ecreter, plancherFace), p (identité : bureau, projet, moa, site, ing),
         norme, svg (EXBR.svgEnvPoutre, facultatif), date (facultatif) }
   Armatures de travée, cadres, flèche (dispense BAEL B.6.5,1), ancrages et métré : calculés ici avec les formules de EXBPA (BAEL 91 mod. 99).
   Calcul d'aide à l'étude : à faire vérifier par un ingénieur. */
(function (root) {
  "use strict";
  var PA = (typeof require === "function" && typeof module !== "undefined") ? require("./exb-poutre-appuis.js") : root.EXBPA;
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var f = function (v, n) { return isFinite(v) ? (+v).toFixed(n == null ? 2 : n).replace(".", ",") : "—"; };
  var tb = function (h, rows) { return "<table><tr>" + h.map(function (x) { return "<th>" + x + "</th>"; }).join("") + "</tr>" + rows.map(function (q) { return "<tr>" + q.map(function (x) { return "<td>" + x + "</td>"; }).join("") + "</tr>"; }).join("") + "</table>"; };
  var okc = function (b, t1, t0) { return '<span class="' + (b ? "exok" : "exko") + '" style="font-weight:700;color:' + (b ? "#166534" : "#b91c1c") + '">' + (b ? (t1 || "OK") : (t0 || "À revoir")) + "</span>"; };
  var CAQ = [7, 8, 9, 10, 11, 13, 16, 20, 25, 35, 40];
  var caq = function (v) { var r = 0; CAQ.forEach(function (x) { if (x <= v + 1e-9) r = x; }); return r; };
  var kgm = function (phi) { return 0.00617 * phi * phi; };

  /* ---------- calcul complet ---------- */
  function calc(o) {
    o = o || {};
    var res = o.res, s = o.s || {}, W = [];
    if (!res || !res.n || (res.erreurs && res.erreurs.length)) return { erreur: "Analyse de la poutre continue absente ou invalide." };
    var S = { b0: +s.b0, h: +s.h, enr: s.enr == null ? 3 : +s.enr, dt: s.dt == null ? 8 : +s.dt, fc: +s.fc, fe: +s.fe, t: s.t || "t > 24 h", fiss: s.fiss || "peu préjudiciable", b: +s.b || 0, h0: +s.h0 || 0 };
    if (!(S.b0 > 0 && S.h > 0 && S.fc > 0 && S.fe > 0)) return { erreur: "Section (b0, h) et matériaux (fc28, fe) à renseigner." };
    var n = res.n, Ls = res.Ls, r = res.resume, N = res.ns, th = PA.theta(S.t), ftj = 0.6 + 0.06 * S.fc, te = S.b > S.b0 && S.h0 > 0 && S.h0 < S.h, bw = te ? S.b : S.b0;
    var tau_su = 1.35 * ftj, ls = function (phi) { return phi / 10 * S.fe / (4 * tau_su); };
    var fbu = 0.85 * S.fc / 1.5, fed = S.fe / 1.15, d0 = Math.min(0.9 * S.h, S.h - S.enr - 3);
    var tot = Ls.reduce(function (a, b) { return a + b; }, 0);

    /* armatures de travée */
    var trav = [];
    for (var i = 0; i < n; i++) {
      var Mu = r.Mt[i], Ms = r.MtS[i], gam = Ms > 0 ? Mu / Ms : 1.4, d = d0, fl, Au, Amin, Ase, As, SS, conv = false, wv = [];
      for (var it = 0; it < 20; it++) {
        fl = PA.flex(Mu, bw, d, S.fc, S.fe, th, gam);
        if (!fl.ok) break;
        Au = fl.As; Amin = ftj / S.fe * 0.23 * d * S.b0;
        Ase = S.fiss !== "peu préjudiciable" ? PA.aserELS(Ms, bw, d, S.fc, S.fe, S.fiss) : 0;
        As = Math.max(Au, Ase, Amin); SS = PA.disposer(As, S.b0, S.h, S.enr, S.dt);
        if (!SS.L || SS.L.d >= d - 1e-6) { conv = true; break; }
        d = SS.L.d;
      }
      var tr = { i: i, L: Ls[i], Mu: Mu, Ms: Ms, d: d, f: fl, warn: wv, ok: false };
      if (!fl.ok) { wv.push("Travée " + (i + 1) + " : μ = " + f(fl.mu, 3) + " > μ critique " + f(fl.mc, 3) + " : augmenter la section."); trav.push(tr); continue; }
      var B = SS.B, L = SS.L, e = PA.els(Ms, bw, d, B.as, S.fc, S.fe, S.fiss), sbl = 0.6 * S.fc, ssl = PA.limAcier(S.fc, S.fe, S.fiss);
      if (te && 0.8 * fl.al * d > S.h0) wv.push("Travée " + (i + 1) + " : l'axe neutre descend dans l'âme, calcul en Té à vérifier (calcul fait en rectangle b = " + f(S.b, 0) + " cm).");
      if (!L) wv.push("Travée " + (i + 1) + " : les barres ne tiennent pas dans b0 = " + f(S.b0, 0) + " cm : augmenter b0.");
      else if (L.nb > 3) wv.push("Travée " + (i + 1) + " : plus de 3 lits, disposition refusée.");
      else if (L.nb > 1) wv.push("Travée " + (i + 1) + " : " + B.n + " HA" + B.d + " en " + L.nb + " lits (" + L.rep.join(" + ") + "), d réel = " + f(L.d, 1) + " cm.");
      if (e.sb > sbl) wv.push("Travée " + (i + 1) + " : ELS, contrainte du béton dépassée.");
      if (e.ss > ssl) wv.push("Travée " + (i + 1) + " : ELS, contrainte de l'acier dépassée.");
      Object.assign(tr, { Au: Au, Amin: Amin, Ase: Ase, As: As, B: B, L: L, sb: e.sb, ss: e.ss, sbl: sbl, ssl: ssl, ok: conv && !!L && L.nb <= 3 && e.sb <= sbl && e.ss <= ssl });
      trav.push(tr);
    }

    /* chapeaux */
    var ch = o.ch || PA.chapeaux({ res: res, b0: S.b0, h: S.h, enr: S.enr, dt: S.dt, fc: S.fc, fe: S.fe, t: S.t, fiss: S.fiss, colonnes: s.colonnes || [], ecreter: !!s.ecreter, plancherFace: +s.plancherFace || 0, b: S.b, h0: S.h0 });
    var aExt = [];
    for (var j = 1; j < n; j++) aExt[j] = Math.max(Ls[j - 1], Ls[j]) / ((res.Q[j - 1] <= res.G[j - 1] && res.Q[j] <= res.G[j]) ? 5 : 4);

    /* effort tranchant et cadres */
    var dmin = Math.min.apply(null, [d0].concat(trav.map(function (t) { return t.d; })).concat((ch.appuis || []).map(function (a) { return a.d; })).filter(isFinite));
    var tl = S.fiss === "peu préjudiciable" ? Math.min(0.2 * S.fc / 1.5, 5) : Math.min(0.15 * S.fc / 1.5, 4);
    var At = 2 * Math.PI * S.dt * S.dt / 400, ft = Math.min(ftj, 3.3);
    var stMax = Math.min(0.9 * dmin, 40, At * S.fe / (0.4 * S.b0));
    var phiLmin = Math.min.apply(null, trav.map(function (t) { return t.B ? t.B.d : 99; }).concat((ch.appuis || []).filter(function (a) { return a.barres; }).map(function (a) { return a.barres.d; })));
    var phiTmax = Math.min(S.h * 10 / 35, phiLmin, S.b0 * 10 / 10);
    var tauOf = function (V) { return V * 1e-3 / (S.b0 / 100 * dmin / 100); };
    var stOf = function (V) {
      var k = tauOf(V) - 0.3 * ft, c = k > 0 ? At * 0.9 * S.fe / (1.15 * S.b0 * k) : Infinity, v = Math.min(c, stMax), st = caq(v);
      return { st: st || 7, trop: st === 0, tau: tauOf(V), V: V };
    };
    var cad = [], tauMax = 0;
    for (i = 0; i < n; i++) {
      var Lc = Ls[i], ab = function (k) { return Math.max(Math.abs(res.U.vx[i][k]), Math.abs(res.U.vn[i][k])); };
      var Vl = ab(0), Vr = ab(N), Vm = 0, k;
      for (k = Math.floor(N / 4); k <= Math.ceil(3 * N / 4); k++) Vm = Math.max(Vm, ab(k));
      var zl = stOf(Vl), zr = stOf(Vr), zm = stOf(Vm), xs = [], LP = [], RP = [], x;
      for (x = zl.st / 200; x <= Lc / 4 + 1e-9; x += zl.st / 100) LP.push(x);
      for (x = Lc - zr.st / 200; x >= 3 * Lc / 4 - 1e-9; x -= zr.st / 100) RP.unshift(x);
      xs = LP.slice(); x = (LP.length ? LP[LP.length - 1] : 0) + zm.st / 100;
      while (x < (RP.length ? RP[0] : Lc) - zm.st / 200) { xs.push(x); x += zm.st / 100; }
      xs = xs.concat(RP);
      tauMax = Math.max(tauMax, zl.tau, zr.tau, zm.tau);
      cad.push({ i: i, L: Lc, zl: zl, zr: zr, zm: zm, xs: xs, nl: LP.length, nm: xs.length - LP.length - RP.length, nr: RP.length });
      if (zl.trop || zr.trop) W.push("Travée " + (i + 1) + " : espacement des cadres inférieur à 7 cm : augmenter le diamètre des cadres ou la section.");
    }
    var cadLen = 2 * (S.b0 - 2 * S.enr + S.h - 2 * S.enr) + 2 * S.dt, cadNb = cad.reduce(function (a, c) { return a + c.xs.length; }, 0);
    var cis = { tauMax: tauMax, tl: tl, At: At, stMax: stMax, phiTmax: phiTmax, ok: tauMax <= tl, phiOk: S.dt <= phiTmax + 1e-9, d: dmin, nb: cadNb, len: cadLen };
    if (!cis.ok) W.push("Contrainte de cisaillement τu = " + f(tauMax) + " MPa > " + f(tl) + " MPa : augmenter la section.");

    /* flèche : dispense BAEL B.6.5,1 (poutres continues) */
    var fleche = trav.map(function (t, i2) {
      var ps = res.G[i2] + res.Q[i2], M0 = ps * Ls[i2] * Ls[i2] / 8, c1 = Math.max(1 / 16, t.Ms / (10 * M0)), hL = S.h / 100 / Ls[i2], rho = t.B ? t.B.as / (S.b0 * t.d) : NaN;
      return { i: i2, M0: M0, hL: hL, lim: c1, rho: rho, rlim: 4.2 / S.fe, ok1: hL >= c1, ok2: rho <= 4.2 / S.fe, ok3: Ls[i2] <= 8, dispense: hL >= c1 && rho <= 4.2 / S.fe && Ls[i2] <= 8 };
    });

    /* métré indicatif */
    var l10 = ls(10), bars = [], rep = 1, add = function (nb, phi, len, des) { bars.push({ rep: rep++, nb: nb, phi: phi, len: len, des: des, kg: nb * len * kgm(phi) }); return rep - 1; };
    trav.forEach(function (t, i2) { if (t.B) t.rep = add(t.B.n, t.B.d, Ls[i2] + (i2 === 0 ? 0.6 : 0.4) * ls(t.B.d) / 100 + (i2 === n - 1 ? 0.6 : 0.4) * ls(t.B.d) / 100, "Travée " + (i2 + 1) + " — lit inférieur"); });
    (ch.appuis || []).forEach(function (a) { if (a.barres) a.rep = add(a.barres.n, a.barres.d, 2 * aExt[a.j], "Chapeaux appui " + a.j); });
    for (i = 0; i < n; i++) { var aL = i > 0 ? aExt[i] : 0, aR = i < n - 1 ? aExt[i + 1] : 0; add(2, 10, Math.max(0.5, Ls[i] - aL - aR) + (i > 0 ? l10 / 100 : 0.6 * l10 / 100) + (i < n - 1 ? l10 / 100 : 0.6 * l10 / 100), "Porte-cadres travée " + (i + 1)); }
    var repCad = add(cadNb, S.dt, cadLen / 100, "Cadres HA" + S.dt + " (1 cadre = 2 brins)");
    var vol = (S.b0 * S.h + (te ? (S.b - S.b0) * S.h0 : 0)) / 1e4 * tot, poids = bars.reduce(function (a, b) { return a + b.kg; }, 0);
    var warnAll = W.concat(ch.warn || []); trav.forEach(function (t) { t.warn.forEach(function (m) { warnAll.push(m); }); });
    var okAll = trav.every(function (t) { return t.ok; }) && (ch.appuis || []).every(function (a) { return a.ok !== false && a.barres || a.As === 0; }) && cis.ok && cis.phiOk;
    return { S: S, res: res, n: n, Ls: Ls, tot: tot, th: th, ftj: ftj, fbu: fbu, fed: fed, te: te, d0: d0, trav: trav, ch: ch, aExt: aExt, cis: cis, cad: cad, repCad: repCad, fleche: fleche, bars: bars, vol: vol, poids: poids, ratio: vol > 0 ? poids / vol : 0, ls: ls, tau_su: tau_su, warn: warnAll, ok: okAll };
  }

  /* ---------- note de calcul ---------- */
  function note(o) {
    o = o || {};
    var C = calc(o), p = o.p || {}, norme = o.norme || "BAEL 91 modifié 99";
    if (C.erreur) return '<div class="pg"><h2>Note de calcul de poutre continue</h2><p class="nt">' + esc(C.erreur) + "</p></div>";
    var res = C.res, r = res.resume, S = C.S, n = C.n, Ls = C.Ls, pages = [];
    var hd = function (i) { return '<div class="hd"><b>' + esc(p.bureau || "Excellencia Building") + "</b><span>" + esc(p.projet || "Projet") + " — " + esc(p.site || "") + "</span><span>Page " + i + " / " + pages.length + "</span></div>"; };
    var svg = function (A, B, kind, title) { return o.svg ? o.svg({ Ls: Ls, A: A, B: B, kind: kind, unit: kind === "M" ? "kN·m" : "kN", title: title }) : '<p class="nt">Diagramme indisponible.</p>'; };
    var rive = function (j) { return j === 0 || j === n; };
    var out = '<div class="ti" data-norme="' + esc(norme) + '"><h1>NOTE DE CALCUL DE POUTRE CONTINUE (' + esc(norme) + ")</h1><p><b>PROJET :</b> " + esc(p.projet || "—") + " · <b>MAÎTRE D'OUVRAGE :</b> " + esc(p.moa || "—") + " · <b>SITE :</b> " + esc(p.site || "—") + "<br><b>Date :</b> " + (o.date || new Date().toLocaleDateString("fr-FR")) + " · <b>Ingénieur :</b> " + esc(p.ing || "—") + "</p></div>";

    /* 1 — hypothèses, matériaux, géométrie */
    pages.push('<h2>1. Règlements et hypothèses générales</h2>' + tb(["Paramètre", "Valeur"], [
      ["Élément", "Poutre continue de " + n + " travée" + (n > 1 ? "s" : "") + " (longueur totale " + f(C.tot) + " m)"], ["Règlement", esc(norme)],
      ["Méthode", "Élastique linéaire, méthode des rotations ; appuis simples rigides, sans tassement"], ["Charges", "Uniformément réparties par travée (G permanente, Q exploitation)"],
      ["Combinaisons", "ELU : " + f(res.gG) + "·G + " + f(res.gQ) + "·Q ; ELS : G + Q ; Q en toutes dispositions (travées chargées / déchargées)"], ["Fissuration", esc(S.fiss)]]) +
      "<h2>2. Matériaux</h2>" + tb(["Grandeur", "Symbole", "Valeur"], [["Résistance du béton", "fc28", f(S.fc, 1) + " MPa"], ["Résistance en traction", "ft28", f(C.ftj) + " MPa"],
        ["Contrainte limite ELU", "fbu = 0,85·fc28/γb (γb = 1,5)", f(C.fbu) + " MPa"], ["Limite élastique des aciers HA", "fe", f(S.fe, 0) + " MPa"], ["Résistance de calcul", "fed = fe/γs (γs = 1,15)", f(C.fed) + " MPa"]]) +
      "<h2>3. Géométrie et enrobage</h2>" + tb(["Paramètre", "Valeur"], [["Portées (entre axes)", Ls.map(function (x) { return f(x) + " m"; }).join(" ; ")],
        ["Section b0 × h", C.te ? "âme " + f(S.b0, 0) + " × " + f(S.h, 0) + " cm ; table b × h0 = " + f(S.b, 0) + " × " + f(S.h0, 0) + " cm" : f(S.b0, 0) + " × " + f(S.h, 0) + " cm"],
        ["Enrobage nominal", f(S.enr, 1) + " cm"], ["Cadres", "HA" + S.dt], ["Hauteur utile d (départ)", f(C.d0, 1) + " cm (reprise après mise en lits des barres)"]]) +
      '<p class="nt">Calcul en flexion simple. Sur appui la table du té est tendue : section rectangulaire b0 × h. En travée la table est comprimée (largeur b si renseignée).</p>');

    /* 2 — charges et modèle */
    pages.push("<h2>4. Analyse des charges (kN/m)</h2>" + tb(["Travée", "L (m)", "G", "Q", "EI relatif", "ELU 1,35G+1,5Q", "ELS G+Q"], Ls.map(function (L, i) {
      return [i + 1, f(L), f(res.G[i]), f(res.Q[i]), f(res.EI[i]), f(res.gG * res.G[i] + res.gQ * res.Q[i]), f(res.G[i] + res.Q[i])];
    })) + '<p class="nt">G inclut le poids propre de la poutre. EI relatif : seule la proportion entre travées compte (1 partout si la section est constante).</p>' +
      "<h2>5. Modèle de calcul et cas de charges</h2><p class=\"nt\">Poutre continue sur appuis simples rigides (méthode des rotations, moments d'encastrement parfait). G est appliquée sur toutes les travées ; Q est placée en toutes dispositions utiles (une travée à la fois, superposition linéaire des contributions défavorables). Les enveloppes ELU et ELS en découlent. Aucune console de rive, aucun tassement d'appui.</p>" +
      (res.avert && res.avert.length ? res.avert.map(function (m) { return '<p class="nt">⚠ ' + esc(m) + "</p>"; }).join("") : ""));

    /* 3 — sollicitations */
    var rowsT = Ls.map(function (L, i) { return [i + 1, f(L), "<b>" + f(r.Mt[i], 1) + "</b>", f(r.xt[i]), f(r.MtS[i], 1)]; });
    var rowsA = []; for (var j = 0; j <= n; j++) rowsA.push([j + (rive(j) ? " (rive)" : ""), "<b>" + (rive(j) ? "0,0" : "−" + f(r.Ma[j], 1)) + "</b>", rive(j) ? "0,0" : "−" + f(r.MaS[j], 1), f(r.Vmax[j], 1), f(r.R[j], 1), f(r.Rmin[j], 1)]);
    pages.push("<h2>6. Sollicitations (ELU et ELS) — enveloppes</h2><h3>Moments en travée</h3>" + tb(["Travée", "L (m)", "Mt max ELU (kN.m)", "à x (m)", "Mt ELS (kN.m)"], rowsT) +
      "<h3>Appuis</h3>" + tb(["Appui", "Ma ELU (kN.m)", "Ma ELS (kN.m)", "V max (kN)", "R max (kN)", "R min (kN)"], rowsA) +
      '<p class="nt">Moments d\'appui négatifs (fibres supérieures tendues). Les moments sont pris à l\'axe des appuis.</p>');

    /* 4 — diagrammes */
    pages.push("<h2>7. Diagrammes des sollicitations</h2><h3>Moments fléchissants M ELU (kN.m)</h3>" + svg(res.U.mx, res.U.mn, "M", "Enveloppe des moments fléchissants — ELU") +
      '<p class="nt">Orange : maximum · Bleu : minimum — travée vers le bas.</p><h3>Efforts tranchants V ELU (kN)</h3>' + svg(res.U.vx, res.U.vn, "V", "Enveloppe des efforts tranchants — ELU") +
      "<h3>Moments fléchissants à l'ELS (kN.m)</h3>" + svg(res.E.mx, res.E.mn, "M", "Enveloppe des moments fléchissants — ELS") + '<p class="nt">Effort normal N = 0 : poutre soumise à une charge transversale uniquement.</p>');

    /* 5 — armatures de travée */
    pages.push("<h2>8. Armatures longitudinales en travée</h2>" + tb(["Travée", "Mu (kN.m)", "d (cm)", "As ELU", "As ELS", "As min", "Choix", "As choisi", "ELS σb / σs (MPa)", "Verdict"], C.trav.map(function (t) {
      if (!t.f || !t.f.ok) return [t.i + 1, f(t.Mu, 1), f(t.d, 1), "—", "—", "—", "—", "—", "—", okc(false)];
      return [t.i + 1, f(t.Mu, 1), f(t.d, 1), f(t.Au), f(t.Ase), f(t.Amin), "<b>" + t.B.n + " HA" + t.B.d + (t.L && t.L.nb > 1 ? " (" + t.L.rep.join("+") + ")" : "") + "</b>", f(t.B.as), f(t.sb, 1) + "/" + f(t.sbl, 1) + " · " + Math.round(t.ss) + "/" + Math.round(t.ssl), okc(t.ok)];
    })) + '<p class="nt">As (cm²) = max(ELU, ELS selon fissuration, non-fragilité 0,23·ft28/fe·b0·d). Mise en lits : espacement libre ≥ max(φ ; 2,5 cm), d ramené au centre de gravité réel.</p>' +
      (function () { var t = C.trav.reduce(function (a, b) { return (b.f && b.f.ok && (!a || b.Mu > a.Mu)) ? b : a; }, null); if (!t) return ""; var fl = t.f;
        return "<h3>Détail — travée " + (t.i + 1) + " (la plus sollicitée)</h3>" + tb(["μ", "α", "Z", "Pivot"], [[f(fl.mu, 4), f(fl.al, 4), f(fl.z / 100, 3) + " m", fl.piv]]) + tb(["Critère", "ELU", "ELS"], [["As théorique (cm²)", f(t.Au), f(t.Ase)], ["σbc / limite (MPa)", "—", f(t.sb, 1) + " / " + f(t.sbl, 1)]]); })());

    /* 6 — chapeaux */
    var ca = C.ch.appuis || [];
    pages.push("<h2>9. Chapeaux sur appuis intermédiaires</h2>" + (ca.length ? tb(["Appui", "Mu (kN.m)", "d (cm)", "As ELU", "As ELS", "As min", "Choix", "As choisi", "Verdict"], ca.map(function (a) {
      var ch2 = a.barres ? a.barres.n + " HA" + a.barres.d + (a.lits && a.lits.nb > 1 ? " (" + a.lits.rep.join("+") + ")" : "") : "—";
      return [a.j, f(a.Mu, 1), f(a.d, 1), isFinite(a.Au) ? f(a.Au) : "—", f(a.Ase), f(a.Amin), "<b>" + ch2 + "</b>", a.barres ? f(a.barres.as) : "—", okc(a.ok !== false && !!a.barres)];
    })) + '<p class="nt">Moment de calcul pris à l\'axe de l\'appui (prudent) sauf réduction à la face activée. Tranchant de calcul sur appuis intérieurs : ' + f(C.res.resume.VmaxAppui, 1) + " kN.</p>" : '<p class="nt">Une seule travée : pas d\'appui intermédiaire.</p>') +
      (C.ch.warn || []).map(function (m) { return '<p class="nt">⚠ ' + esc(m) + "</p>"; }).join(""));

    /* 7 — tranchant, cadres, flèche */
    var cz = C.cad;
    pages.push("<h2>10. Effort tranchant et cadres</h2><p>Contrainte de cisaillement maximale τu = <b>" + f(C.cis.tauMax) + " MPa</b> pour une limite de " + f(C.cis.tl) + " MPa : " + okc(C.cis.ok, "vérifié", "NON vérifié") + ". Cadres HA" + S.dt + " (At = " + f(C.cis.At) + " cm², 2 brins) : " + okc(C.cis.phiOk, "φt ≤ min(h/35 ; φl min ; b0/10) respecté", "φt supérieur à min(h/35 ; φl min ; b0/10)") + ".</p>" +
      tb(["Travée", "Appui gauche", "Courant", "Appui droit", "Nb cadres"], cz.map(function (c) { return [c.i + 1, c.nl + " × " + c.zl.st + " cm (Vu = " + f(c.zl.V, 1) + " kN)", c.nm + " × " + c.zm.st + " cm", c.nr + " × " + c.zr.st + " cm (Vu = " + f(c.zr.V, 1) + " kN)", c.xs.length]; })) +
      '<p class="nt">Espacements BAEL A.5.1,23 (K = 1, α = 90°) arrondis à la suite de Caquot ; zones d\'appui sur 1/4 de la portée, premier cadre à st/2 de l\'appui ; st ≤ min(0,9d ; 40 cm ; At·fe/(0,4·b0)) = ' + f(C.cis.stMax, 1) + " cm. Effort tranchant pris au droit de l'appui (sans réduction), d = " + f(C.cis.d, 1) + " cm.</p>" +
      "<h2>11. Flèche (dispense BAEL B.6.5,1)</h2>" + tb(["Travée", "h/L", "Limite max(1/16 ; Mts/10M0)", "As/(b0·d)", "Limite 4,2/fe", "L ≤ 8 m", "Verdict"], C.fleche.map(function (x) {
        return [x.i + 1, f(x.hL, 3), f(x.lim, 3), isFinite(x.rho) ? f(x.rho * 100, 2) + " %" : "—", f(x.rlim * 100, 2) + " %", x.ok3 ? "oui" : "non", okc(x.dispense, "dispensé", "calcul de flèche requis")];
      })) + '<p class="nt">M0 = (G+Q)·L²/8 ; Mts = moment de travée à l\'ELS. Si « calcul de flèche requis », mener la vérification complète (module Flèche).</p>');

    /* 8 — dispositions constructives */
    var tT = C.trav.filter(function (t) { return t.B; }).map(function (t) { return t.B.d; }), phiMax = tT.length ? Math.max.apply(null, tT) : 12;
    pages.push("<h2>12. Dispositions constructives</h2><ul><li>Ancrage droit ls = " + f(C.ls(phiMax) / (phiMax / 10), 0) + "φ = " + f(C.ls(phiMax), 0) + " cm pour HA" + phiMax + " (τsu = 0,6·ψs²·ft28 = " + f(C.tau_su) + " MPa, ψs = 1,5 ; BAEL A.6.1,22) ; recouvrement des barres tendues lr ≈ ls ; crochet normal si la largeur d'appui est inférieure à ls.</li>" +
      "<li>Chapeaux : prolongés de part et d'autre de l'axe de l'appui sur " + (n > 1 ? C.aExt.slice(1).map(function (a, k) { return "appui " + (k + 1) + " : " + f(a) + " m"; }).join(" ; ") : "—") + " (1/5 de la plus grande portée adjacente si Q ≤ G, 1/4 sinon). Décalage de la courbe des moments (0,8·h) et arrêts échelonnés : à préciser sur le plan d'atelier.</li>" +
      "<li>Barres inférieures de chaque travée filantes d'appui à appui ; au moins 2 barres prolongées sur les appuis de rive (ancrage par courbure) et sur appuis intermédiaires.</li>" +
      "<li>Porte-cadres supérieurs 2 HA10 entre les chapeaux, avec recouvrement ls.</li><li>" + (S.h <= 60 ? "h = " + f(S.h, 0) + " cm ≤ 60 cm : pas d'armatures de peau requises." : "h = " + f(S.h, 0) + " cm > 60 cm : prévoir des armatures de peau.") + "</li></ul>" +
      (C.warn.length ? "<h3>Points d'attention</h3><ul>" + C.warn.map(function (m) { return "<li>" + esc(m) + "</li>"; }).join("") + "</ul>" : ""));

    /* 9 — métré */
    pages.push("<h2>13. Métré et nomenclature estimative</h2>" + tb(["REP", "NB", "Type", "Ø", "Long. (m)", "Poids (kg)", "Désignation"], C.bars.map(function (q) { return [q.rep, q.nb, "HA", q.phi, f(q.len), f(q.kg, 1), q.des]; })) +
      "<h2>Récapitulatif quantitatif</h2>" + tb(["Volume de béton", "Poids total des aciers", "Ratio"], [[f(C.vol, 3) + " m³", f(C.poids, 1) + " kg", f(C.ratio, 0) + " kg/m³"]]) +
      '<p class="nt">Longueurs indicatives (ancrages 0,6·ls en rive, 0,4·ls sur appui intermédiaire), à ajuster sur le plan d\'atelier. Le plan d\'exécution suit cette note. Document d\'aide à l\'étude : à faire vérifier par un ingénieur avant exécution.</p>');

    pages.forEach(function (b, i) { out += '<div class="pg">' + hd(i + 1) + b + "</div>"; });
    return out;
  }

  /* ---------- plan d'exécution (coupe longitudinale + sections) ---------- */
  function plan(o) {
    o = o || {};
    var C = calc(o), p = o.p || {}, norme = o.norme || "BAEL 91 modifié 99";
    if (C.erreur) return '<div class="pg pl3"><h2>PLAN D\'EXÉCUTION — POUTRE CONTINUE</h2><p class="nt">' + esc(C.erreur) + "</p></div>";
    var S = C.S, n = C.n, Ls = C.Ls, W = 1400, pl = 70, pr = 50, sc = (W - pl - pr) / C.tot, cum = [0];
    Ls.forEach(function (L) { cum.push(cum[cum.length - 1] + L); });
    var X = function (m) { return pl + m * sc; }, hm = S.h / 100, H = Math.min(Math.max(hm * sc * 2, 80), 150), kv = H / S.h, yT = 160, yB = yT + H, cmv = function (c) { return c * kv; };
    var o2 = [], push = function (s) { o2.push(s); };
    var ORG = "#e8590c", BLU = "#1b6fb3", INK = "#14284b", GR = "#5b6779";
    var txt = function (x, y, t, a, sz, col, wt) { return '<text x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" text-anchor="' + (a || "middle") + '" font-size="' + (sz || 12) + '" fill="' + (col || INK) + '"' + (wt ? ' font-weight="700"' : "") + ">" + t + "</text>"; };
    var barY = function (L, k0) { var phi = L.phi || 16; return phi; };
    var hookR = function (x, y, dir, up) { return '<path d="M' + x.toFixed(1) + " " + y.toFixed(1) + "v" + (up ? -1 : 1) * 14 + '" stroke="' + ORG + '" stroke-width="3" fill="none"/>'; };
    /* hauteur totale du dessin : coupe + 2 sections */
    var s2 = Math.min(4.2, 230 / Math.max(S.h, S.b0 + 1)), ys = yB + 150, Ht = ys + S.h * s2 + 130;
    push('<svg viewBox="0 0 ' + W + " " + Ht.toFixed(0) + '" role="img" aria-label="Plan d\'exécution de la poutre continue" style="width:100%;height:auto;background:#fff;border:1px solid #d5dae1;border-radius:8px;font-family:Arial,Helvetica,sans-serif">');
    push(txt(pl, 22, "COUPE LONGITUDINALE — FERRAILLAGE (longueurs en m, hauteurs ×" + f(kv * 100 / sc, 1) + " pour la lisibilité)", "start", 14, INK, 1));
    /* cotes de portées */
    for (var s = 0; s < n; s++) { var a = X(cum[s]), b = X(cum[s + 1]); push('<line x1="' + (a + 4) + '" y1="62" x2="' + (b - 4) + '" y2="62" stroke="' + GR + '"/><path d="M' + (a + 4) + " 62l8-3v6zM" + (b - 4) + ' 62l-8-3v6z" fill="' + GR + '"/>' + txt((a + b) / 2, 56, "T" + (s + 1) + " · L = " + f(Ls[s]) + " m")); }
    for (var j = 0; j <= n; j++) push('<line x1="' + X(cum[j]) + '" y1="70" x2="' + X(cum[j]) + '" y2="' + (yB + 20) + '" stroke="#9aa6bb" stroke-dasharray="6 4"/><circle cx="' + X(cum[j]) + '" cy="84" r="10" fill="#fff" stroke="' + INK + '" stroke-width="1.4"/>' + txt(X(cum[j]), 88, j + 1, "middle", 11, INK, 1));
    /* béton */
    push('<rect x="' + (X(0) - 10) + '" y="' + yT + '" width="' + (C.tot * sc + 20) + '" height="' + H + '" fill="#f4f6fa" stroke="' + INK + '" stroke-width="1.8"/>');
    for (j = 0; j <= n; j++) push('<rect x="' + (X(cum[j]) - 16) + '" y="' + yB + '" width="32" height="38" fill="#e4e8f0" stroke="' + INK + '" stroke-dasharray="4 3"/>');
    /* cadres */
    C.cad.forEach(function (c) { c.xs.forEach(function (x) { push('<line x1="' + X(cum[c.i] + x).toFixed(1) + '" y1="' + (yT + cmv(S.enr)).toFixed(1) + '" x2="' + X(cum[c.i] + x).toFixed(1) + '" y2="' + (yB - cmv(S.enr)).toFixed(1) + '" stroke="#8a93a5" stroke-width="1"/>'); }); });
    /* lits inférieurs */
    C.trav.forEach(function (t) {
      if (!t.B) return; var i = t.i, e0 = (i === 0 ? 0.6 : 0.4) * C.ls(t.B.d) / 100, e1 = (i === n - 1 ? 0.6 : 0.4) * C.ls(t.B.d) / 100, y = yB - cmv(S.enr + S.dt / 10 + t.B.d / 20);
      var xa = X(cum[i] - e0), xb = X(cum[i + 1] + e1); if (i > 0) xa = Math.max(xa, X(cum[i]) - 40); if (i < n - 1) xb = Math.min(xb, X(cum[i + 1]) + 40);
      push('<line x1="' + xa.toFixed(1) + '" y1="' + y.toFixed(1) + '" x2="' + xb.toFixed(1) + '" y2="' + y.toFixed(1) + '" stroke="' + ORG + '" stroke-width="3.2"/>');
      if (t.L && t.L.nb > 1) push('<line x1="' + xa.toFixed(1) + '" y1="' + (y - cmv(t.B.d / 10 + t.L.e)).toFixed(1) + '" x2="' + xb.toFixed(1) + '" y2="' + (y - cmv(t.B.d / 10 + t.L.e)).toFixed(1) + '" stroke="' + ORG + '" stroke-width="3.2" stroke-dasharray="14 4"/>');
      if (i === 0) push(hookR(xa, y, 1, true)); if (i === n - 1) push(hookR(xb, y, 1, true));
      push(txt((X(cum[i]) + X(cum[i + 1])) / 2, yB + 58, "REP " + t.rep + " — " + t.B.n + " HA" + t.B.d + " (L = " + f(C.bars[t.rep - 1].len) + " m)", "middle", 12, ORG, 1));
    });
    /* chapeaux + porte-cadres */
    var yc = yT + cmv(S.enr + S.dt / 10 + 0.5);
    for (var i2 = 0; i2 < n; i2++) { var aL = i2 > 0 ? C.aExt[i2] : 0, aR = i2 < n - 1 ? C.aExt[i2 + 1] : 0; push('<line x1="' + X(cum[i2] + aL - (i2 > 0 ? C.ls(10) / 100 : -0.0)).toFixed(1) + '" y1="' + (yc + 7) + '" x2="' + X(cum[i2 + 1] - aR + (i2 < n - 1 ? C.ls(10) / 100 : 0)).toFixed(1) + '" y2="' + (yc + 7) + '" stroke="' + GR + '" stroke-width="2"/>'); }
    (C.ch.appuis || []).forEach(function (ap) {
      if (!ap.barres) return; var xa = X(cum[ap.j] - C.aExt[ap.j]), xb = X(cum[ap.j] + C.aExt[ap.j]);
      push('<line x1="' + xa.toFixed(1) + '" y1="' + yc + '" x2="' + xb.toFixed(1) + '" y2="' + yc + '" stroke="' + BLU + '" stroke-width="3.4"/>');
      if (ap.lits && ap.lits.nb > 1) push('<line x1="' + xa.toFixed(1) + '" y1="' + (yc + cmv(ap.barres.d / 10 + ap.lits.e)) + '" x2="' + xb.toFixed(1) + '" y2="' + (yc + cmv(ap.barres.d / 10 + ap.lits.e)) + '" stroke="' + BLU + '" stroke-width="3.4" stroke-dasharray="14 4"/>');
      push('<line x1="' + xa.toFixed(1) + '" y1="' + (yT - 4) + '" x2="' + xa.toFixed(1) + '" y2="' + (yT - 24) + '" stroke="' + BLU + '"/><line x1="' + xb.toFixed(1) + '" y1="' + (yT - 4) + '" x2="' + xb.toFixed(1) + '" y2="' + (yT - 24) + '" stroke="' + BLU + '"/><line x1="' + xa.toFixed(1) + '" y1="' + (yT - 18) + '" x2="' + xb.toFixed(1) + '" y2="' + (yT - 18) + '" stroke="' + BLU + '"/>');
      push(txt(X(cum[ap.j]), yT - 28, "REP " + ap.rep + " — " + ap.barres.n + " HA" + ap.barres.d + " (L = " + f(2 * C.aExt[ap.j]) + " m)", "middle", 12, BLU, 1));
    });
    /* cadres : texte par travée */
    C.cad.forEach(function (c) { push(txt((X(cum[c.i]) + X(cum[c.i + 1])) / 2, yB + 76, "Cadres HA" + S.dt + " (REP " + C.repCad + ") : " + c.nl + "×" + c.zl.st + " + " + c.nm + "×" + c.zm.st + " + " + c.nr + "×" + c.zr.st + " cm", "middle", 11, "#4b5565")); push(txt((X(cum[c.i]) + X(cum[c.i + 1])) / 2, yB + 92, "Porte-cadres 2 HA10", "middle", 11, GR)); });
    /* sections */
    var drawSec = function (x0, titre, top, bot) {
      var w = S.b0 * s2, h2 = S.h * s2, y0 = ys, c = S.enr * s2, ct = S.dt / 10 * s2;
      push(txt(x0 + w / 2, y0 - 18, titre, "middle", 13, INK, 1));
      push('<rect x="' + x0 + '" y="' + y0 + '" width="' + w + '" height="' + h2 + '" fill="#f4f6fa" stroke="' + INK + '" stroke-width="1.8"/>');
      push('<rect x="' + (x0 + c) + '" y="' + (y0 + c) + '" width="' + (w - 2 * c) + '" height="' + (h2 - 2 * c) + '" rx="' + (ct * 2) + '" fill="none" stroke="#8a93a5" stroke-width="' + Math.max(1.2, ct) + '"/>');
      var rows = function (spec, fromTop, col) {
        if (!spec) return; var y = 0;
        spec.rep.forEach(function (cnt, k) { var rr = spec.d / 20 * s2, yy = fromTop ? y0 + c + ct + rr + k * (spec.d / 10 + spec.e) * s2 : y0 + h2 - c - ct - rr - k * (spec.d / 10 + spec.e) * s2, xl = x0 + c + ct + rr, xr = x0 + w - c - ct - rr;
          for (var q = 0; q < cnt; q++) push('<circle cx="' + (cnt === 1 ? (xl + xr) / 2 : xl + q * (xr - xl) / (cnt - 1)).toFixed(1) + '" cy="' + yy.toFixed(1) + '" r="' + Math.max(rr, 2.4).toFixed(1) + '" fill="' + col + '"/>'); });
      };
      rows(top, true, BLU); rows(bot, false, ORG);
      push('<line x1="' + x0 + '" y1="' + (y0 + h2 + 14) + '" x2="' + (x0 + w) + '" y2="' + (y0 + h2 + 14) + '" stroke="' + GR + '"/>' + txt(x0 + w / 2, y0 + h2 + 30, f(S.b0, 0) + " cm", "middle", 11, GR) + txt(x0 + w + 10, y0 + h2 / 2, f(S.h, 0) + " cm", "start", 11, GR));
      return w;
    };
    var tbest = C.trav.reduce(function (a, b) { return (b.B && (!a || b.Mu > a.Mu)) ? b : a; }, null), abest = (C.ch.appuis || []).reduce(function (a, b) { return (b.barres && (!a || b.Mu > a.Mu)) ? b : a; }, null), x0 = pl + 20;
    if (tbest) { var pcs = { rep: [2], d: 10, e: 2.5 }; var w1 = drawSec(x0, "COUPE A-A — Travée " + (tbest.i + 1) + " (mi-travée)", pcs, { rep: tbest.L ? tbest.L.rep : [tbest.B.n], d: tbest.B.d, e: tbest.L ? tbest.L.e : 2.5 }); push(txt(x0 + w1 / 2, ys + S.h * s2 + 54, "Bas : " + tbest.B.n + " HA" + tbest.B.d + " · Haut : 2 HA10 · Cadres HA" + S.dt, "middle", 11, "#4b5565")); x0 += w1 + 150; }
    if (abest) { var w2 = drawSec(x0, "COUPE B-B — Appui " + abest.j, { rep: abest.lits ? abest.lits.rep : [abest.barres.n], d: abest.barres.d, e: abest.lits ? abest.lits.e : 2.5 }, { rep: [2], d: tbest ? tbest.B.d : 12, e: 2.5 }); push(txt(x0 + w2 / 2, ys + S.h * s2 + 54, "Haut : " + abest.barres.n + " HA" + abest.barres.d + " (chapeaux) · Bas : 2 HA" + (tbest ? tbest.B.d : 12) + " minimum", "middle", 11, "#4b5565")); x0 += w2 + 150; }
    /* légende + cartouche */
    var lx = Math.max(x0, 560), ly = ys;
    push('<rect x="' + lx + '" y="' + ly + '" width="' + (W - pr - lx) + '" height="150" fill="#fff" stroke="' + INK + '" stroke-width="1.4"/><rect x="' + lx + '" y="' + ly + '" width="' + (W - pr - lx) + '" height="26" fill="' + INK + '"/>' + txt(lx + 10, ly + 18, esc((p.bureau || "Excellencia Building").toUpperCase()), "start", 13, "#fff", 1));
    [["Projet : " + (p.projet || "—"), 46], ["Site : " + (p.site || "—") + " · MOA : " + (p.moa || "—"), 66], ["Ingénieur : " + (p.ing || "—") + " · " + (o.date || new Date().toLocaleDateString("fr-FR")), 86], ["Poutre continue " + n + " travée" + (n > 1 ? "s" : "") + " · " + f(S.b0, 0) + "×" + f(S.h, 0) + " cm · " + norme, 106], ["Béton fc28 = " + f(S.fc, 0) + " MPa · Acier HA fe = " + f(S.fe, 0) + " MPa · enrobage " + f(S.enr, 1) + " cm", 126], ["Plan d'aide à l'étude — à vérifier par un ingénieur", 144]].forEach(function (l) { push(txt(lx + 10, ly + l[1], esc(l[0]), "start", 11.5, "#172033")); });
    push('<line x1="' + (lx - 150 < x0 ? lx : lx) + '" y1="' + (ly - 8) + '" x2="' + lx + '" y2="' + (ly - 8) + '"/>');
    push('<rect x="' + pl + '" y="' + (Ht - 36) + '" width="14" height="8" fill="' + ORG + '"/>' + txt(pl + 20, Ht - 28, "Armatures inférieures", "start", 11, INK) + '<rect x="' + (pl + 180) + '" y="' + (Ht - 36) + '" width="14" height="8" fill="' + BLU + '"/>' + txt(pl + 200, Ht - 28, "Chapeaux (armatures supérieures sur appuis)", "start", 11, INK) + '<rect x="' + (pl + 470) + '" y="' + (Ht - 36) + '" width="14" height="8" fill="' + GR + '"/>' + txt(pl + 490, Ht - 28, "Porte-cadres", "start", 11, INK) + txt(pl + 600, Ht - 28, "Cadres : trait gris", "start", 11, INK));
    push("</svg>");
    var nom = tb(["REP", "NB", "Type", "Ø", "Long. unitaire (m)", "Désignation"], C.bars.map(function (q) { return [q.rep, q.nb, "HA", q.phi, f(q.len), q.des]; }));
    return '<div class="pg pl3"><h2>PLAN D\'EXÉCUTION — POUTRE CONTINUE (' + esc(norme) + ")</h2>" + o2.join("") + "<h3>Nomenclature des armatures</h3>" + nom + '<p class="nt">Poids total des aciers ' + f(C.poids, 1) + " kg · béton " + f(C.vol, 3) + " m³ (" + f(C.ratio, 0) + " kg/m³). Longueurs indicatives, à ajuster sur le plan d'atelier. Document d'aide à l'étude : à faire vérifier par un ingénieur avant exécution.</p></div>";
  }

  var API = { calc: calc, note: note, plan: plan, doc: function (o) { return note(o) + plan(o); } };
  if (typeof module !== "undefined" && module.exports) module.exports = API;
  if (root) root.EXBPNOTE = API;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
