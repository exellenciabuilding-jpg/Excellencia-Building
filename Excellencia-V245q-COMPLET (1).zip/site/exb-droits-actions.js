/* Excellencia Building — Droits d'ACTION (V166c) · cahier des charges unifié §5 et §7
 * Ajoute aux droits existants (lire / écrire par collection, exb-db.js) les actions : consulter, créer, modifier, soumettre,
 * approuver, rejeter, exporter, partager, archiver, administrer — par profil (administrateur, lecteur, 8 fonctions).
 *  · Matrice modifiable par l'administrateur (écran « 🔐 Droits d'action »), valeurs par défaut prudentes, retour aux défauts.
 *  · APPLIQUÉ à : décisions du Workflow (approuver / refuser / corriger), soumission au Workflow, et TOUT téléchargement de fichier
 *    (CSV, PDF, Excel, sauvegarde…) : l'export est refusé sans le droit « exporter », et chaque export autorisé est journalisé.
 *  · Chaque refus et chaque modification de la matrice entrent dans le journal d'audit chaîné (EXBCore).
 * Limites : contrôle côté écran (comme exb-roles.js) ; le serveur reste l'autorité pour les collections. Sans organisation
 * (mode local, propriétaire seul) tout est permis. La matrice est propre à l'appareil. Retirer : supprimer la balise du script. */
(function (w, d) {
  'use strict';
  if (w.EXBAction) return;
  var KEY = 'exb_action_rights';
  var ACTIONS = [['consulter', 'Consulter'], ['creer', 'Créer'], ['modifier', 'Modifier'], ['soumettre', 'Soumettre'], ['approuver', 'Approuver'], ['rejeter', 'Rejeter'], ['exporter', 'Exporter'], ['partager', 'Partager'], ['archiver', 'Archiver'], ['administrer', 'Administrer']];
  var PROFILES = [['admin', 'Administrateur'], ['lecteur', 'Lecteur seul'], ['direction', 'Direction'], ['chef_projet', 'Chef de projet'], ['conducteur', 'Conducteur de travaux'], ['bureau_etudes', 'Bureau d’études'], ['architecte', 'Architecte'], ['formateur', 'Formateur'], ['comptable', 'Comptable'], ['rh', 'Ressources humaines'], ['magasinier', 'Magasinier'], ['commercial', 'Commercial'], ['achats', 'Achats'], ['polyvalent', 'Polyvalent']];
  var DEF = {
    admin: 'consulter creer modifier soumettre approuver rejeter exporter partager archiver administrer',
    lecteur: 'consulter',
    direction: 'consulter creer modifier soumettre approuver rejeter exporter partager archiver',
    chef_projet: 'consulter creer modifier soumettre approuver rejeter exporter partager archiver',
    conducteur: 'consulter creer modifier soumettre partager',
    bureau_etudes: 'consulter creer modifier soumettre exporter partager',
    architecte: 'consulter creer modifier soumettre exporter partager',
    formateur: 'consulter creer modifier',
    comptable: 'consulter creer modifier soumettre exporter archiver',
    rh: 'consulter creer modifier soumettre exporter archiver',
    magasinier: 'consulter creer modifier soumettre',
    commercial: 'consulter creer modifier soumettre exporter partager',
    achats: 'consulter creer modifier soumettre exporter',
    polyvalent: 'consulter creer modifier soumettre'
  };
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function lsGet(k) { try { return JSON.parse(w.localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function lsSet(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function toast(m, t) { try { if (typeof w.notify === 'function') return w.notify(m, t || 'warn', 6000); } catch (e) {} try { w.alert(m); } catch (e) {} }
  function audit(a, o, det) { try { if (w.EXBCore) w.EXBCore.audit.log(a, o, det); } catch (e) {} }

  function defaults() { var m = {}; PROFILES.forEach(function (p) { m[p[0]] = {}; ACTIONS.forEach(function (a) { m[p[0]][a[0]] = DEF[p[0]].split(' ').indexOf(a[0]) >= 0; }); }); return m; }
  function matrix() {
    var m = defaults(), o = lsGet(KEY) || {};
    Object.keys(o).forEach(function (p) { if (!m[p] || p === 'admin') return; Object.keys(o[p] || {}).forEach(function (a) { if (a in m[p]) m[p][a] = !!o[p][a]; }); });
    return m;
  }
  function profile() {
    try {
      var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info();
      if (!i || !i.on) return 'admin';
      if (i.role === 'admin') return 'admin';
      if (i.role === 'lecteur') return 'lecteur';
      var f = i.fonction || 'polyvalent'; return DEF[f] ? f : 'polyvalent';
    } catch (e) { return 'admin'; }
  }
  function can(action) { var p = profile(); return !!(matrix()[p] || {})[action]; }
  function isAdmin() { return profile() === 'admin'; }
  function refuse(action, what) {
    var lab = (ACTIONS.filter(function (a) { return a[0] === action; })[0] || [0, action])[1].toLowerCase();
    audit('droits.refus', action, { action: action, profil: profile(), ref: String(what || '').slice(0, 60) });
    toast('Action refusée : votre profil (' + (PROFILES.filter(function (p) { return p[0] === profile(); })[0] || [0, profile()])[1] + ') n’a pas le droit de ' + lab + '. Demandez à l’administrateur.', 'warn');
  }
  function guard(action, what) { if (can(action)) return true; refuse(action, what); return false; }

  /* --- application 1 : Workflow --- */
  function hookWorkflow() {
    var W = w.EXBWF; if (!W || W.__act || typeof W.decide !== 'function') return !!(W && W.__act);
    W.__act = true;
    var od = W.decide, os = W.submit;
    W.decide = function (id, action) {
      var need = action === 'approuver' ? 'approuver' : (action === 'refuser' ? 'rejeter' : null);
      if (need && !can(need)) { refuse(need, 'workflow ' + id); return { ok: false, error: 'Votre profil n’a pas le droit de ' + (need === 'approuver' ? 'approuver' : 'rejeter') + ' un dossier.' }; }
      return od.apply(this, arguments);
    };
    if (typeof os === 'function') W.submit = function () {
      if (!can('soumettre')) { refuse('soumettre', 'workflow'); return { ok: false, error: 'Votre profil n’a pas le droit de soumettre un dossier.' }; }
      return os.apply(this, arguments);
    };
    return true;
  }

  /* --- application 2 : tout téléchargement de fichier passe par ce point --- */
  function hookDownloads() {
    var P = w.HTMLAnchorElement && w.HTMLAnchorElement.prototype; if (!P || P.__act) return;
    var oc = P.click; P.__act = true;
    P.click = function () {
      try {
        var n = this.getAttribute && this.getAttribute('download');
        if (n != null && n !== '') {
          var sec = /sauvegarde|backup|restaur|\.exbkey|\.exbbak/i.test(n), need = sec ? 'administrer' : 'exporter';
          if (!can(need)) { refuse(need, n); return; }
          audit('export.fichier', n.slice(0, 80), { type: sec ? 'sauvegarde' : 'export', ref: n.slice(0, 60) });
          /* V245 : trace côté SERVEUR (journal_entreprise) : qui a exporté quoi. Le blocage réel du téléchargement des documents générés est imposé par le stockage (droit d'export du membre). */
          try { var I = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); if (I && I.on && w.EXBDB.rpc && !sec) w.EXBDB.rpc('exporter_controle', { p_org: I.org, p_col: '', p_detail: n.slice(0, 100) }).catch(function () {}); } catch (e2) {}
        }
      } catch (e) {}
      return oc.apply(this, arguments);
    };
  }

  /* --- écran --- */
  function save(m) { var o = {}; Object.keys(m).forEach(function (p) { if (p !== 'admin') o[p] = m[p]; }); return lsSet(KEY, o); }
  function paint() {
    var o = d.getElementById('exbAct'); if (!o) return; var m = matrix(), me = profile();
    var th = ACTIONS.map(function (a) { return '<th style="padding:5px;font-size:11px">' + esc(a[1]) + '</th>'; }).join('');
    var tr = PROFILES.map(function (p) {
      return '<tr' + (p[0] === me ? ' style="background:#fef9c3"' : '') + '><td style="padding:5px;white-space:nowrap"><b>' + esc(p[1]) + '</b>' + (p[0] === me ? ' ◀ vous' : '') + '</td>' + ACTIONS.map(function (a) {
        return '<td style="text-align:center"><input type="checkbox" data-p="' + p[0] + '" data-a="' + a[0] + '"' + (m[p[0]][a[0]] ? ' checked' : '') + (p[0] === 'admin' ? ' disabled' : '') + ' onchange="EXBAction._set(this)"></td>';
      }).join('') + '</tr>';
    }).join('');
    var bt = 'padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;cursor:pointer';
    o.firstChild.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">🔐 Droits d’action</b><button onclick="document.getElementById(\'exbAct\').remove()" style="' + bt + '">✕</button></div>'
      + '<p style="font-size:12px;color:#64748b;margin:6px 0">Qui peut quoi, par profil. <b>Appliqué</b> : approuver / rejeter / soumettre dans le Workflow, et tout export de fichier (CSV, PDF, sauvegarde). Les autres colonnes complètent les droits lire/écrire par module. Le profil de l’administrateur n’est pas modifiable. Chaque refus et chaque changement est journalisé.</p>'
      + '<div style="overflow:auto"><table style="border-collapse:collapse;font-size:12px;width:100%"><thead><tr style="background:#f1f5f9"><th style="padding:5px;text-align:left">Profil</th>' + th + '</tr></thead><tbody>' + tr + '</tbody></table></div>'
      + '<p style="margin:10px 0 0"><button onclick="EXBAction._reset()" style="' + bt + '">↺ Valeurs par défaut</button> <button onclick="EXBAction.pdf()" style="' + bt + '">📄 PDF</button> <span style="font-size:12px;color:#64748b">Votre profil actuel : <b>' + esc((PROFILES.filter(function (p) { return p[0] === me; })[0] || [0, me])[1]) + '</b></span></p>';
  }
  function open() {
    if (!isAdmin()) { toast('Seul l’administrateur peut modifier les droits d’action.', 'warn'); return; }
    var o = d.getElementById('exbAct'); if (o) o.remove();
    o = d.createElement('div'); o.id = 'exbAct'; o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';
    o.onclick = function (e) { if (e.target === o) o.remove(); };
    var c = d.createElement('div'); c.style.cssText = 'background:#fff;border-radius:14px;padding:16px;max-width:1000px;width:100%;font:14px Arial;color:#172033'; o.appendChild(c); d.body.appendChild(o); paint();
  }
  function setBox(el) {
    var p = el.getAttribute('data-p'), a = el.getAttribute('data-a'), m = matrix(); if (p === 'admin' || !m[p]) return;
    m[p][a] = !!el.checked; save(m); audit('droits.modifie', p + '/' + a, { profil: p, action: a, valeur: m[p][a] ? 'oui' : 'non' });
  }
  function reset() { try { w.localStorage.removeItem(KEY); } catch (e) {} audit('droits.modifie', 'matrice', { ref: 'valeurs par défaut' }); paint(); }
  function pdf() {
    if (!w.EXBPdf) return toast('Module PDF indisponible.', 'warn');
    var m = matrix(), me = (PROFILES.filter(function (p) { return p[0] === profile(); })[0] || [0, profile()])[1];
    var r = PROFILES.map(function (p) {
      var ok = ACTIONS.filter(function (a) { return m[p[0]][a[0]]; }).map(function (a) { return a[1]; }), no = ACTIONS.filter(function (a) { return !m[p[0]][a[0]]; }).map(function (a) { return a[1]; });
      return [p[1], 'Autorisé : ' + (ok.join(', ') || 'rien') + (no.length ? '. Refusé : ' + no.join(', ') : '')];
    });
    var cust = lsGet(KEY) || {}; r.unshift(['Matrice', Object.keys(cust).length ? 'Personnalisée (' + Object.keys(cust).length + ' profil(s) modifié(s))' : 'Valeurs par défaut']);
    return EXBPdf.make({ titre: 'DROITS D’ACTION PAR PROFIL', sousTitre: 'Édité le ' + new Date().toLocaleDateString('fr-FR') + ' · profil de l’émetteur : ' + me, rows: r,
      notes: ['Appliqué : approuver, rejeter et soumettre dans le Workflow ; tout export de fichier (droit « exporter ») ; sauvegarde et restauration (droit « administrer »). Chaque refus et chaque modification de la matrice sont inscrits au journal d’audit. Contrôle côté écran ; le serveur reste l’autorité pour les données.'], footer: 'Droits d’action — Excellencia Building' })
      .then(function (b) { EXBPdf.save(b, 'DROITS-ACTION-EXB-' + new Date().toISOString().slice(0, 10) + '.pdf'); });
  }
  function ui() {
    var b = d.getElementById('exbSecBtn'); if (!b || d.getElementById('exbActBtn')) return;
    var k = d.createElement('button'); k.id = 'exbActBtn'; k.className = b.className; k.textContent = '🔐 Droits d’action'; k.onclick = open; b.parentNode.insertBefore(k, b.nextSibling);
  }
  hookDownloads();
  var tries = 0, t = setInterval(function () { if (hookWorkflow() || ++tries > 80) clearInterval(t); }, 500);
  if (typeof MutationObserver !== 'undefined') new MutationObserver(ui).observe(d.documentElement, { childList: true, subtree: true });
  d.addEventListener('DOMContentLoaded', ui);
  w.EXBAction = { can: can, guard: guard, profile: profile, matrix: matrix, actions: function () { return ACTIONS.map(function (a) { return a[0]; }); }, open: open, pdf: pdf, _set: setBox, _reset: reset };
})(window, document);
