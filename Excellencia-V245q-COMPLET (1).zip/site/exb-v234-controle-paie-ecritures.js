/* Excellencia Building V234 — 🧮 CONTRÔLE PAIE · ÉCRITURES PROPOSÉES · PARAMÈTRES COMPTABLES (points « non fait » du Lot 5 du cahier « Portail Comptable V229+ »).
 * Adaptateur : AUCUN fichier existant modifié, AUCUNE écriture dans le journal, la caisse ou exb_payroll (lecture seule des bulletins V81).
 *  1. Contrôle des bulletins V81 : le comptable contrôle (conforme / à corriger avec motif) avant comptabilisation. Un bulletin modifié après contrôle est signalé.
 *     L'état du pont « bulletins V81 → écritures » (exb-compta-paie-v81.js) est affiché ; ce module ne comptabilise pas les bulletins (pas de doublon avec ce pont).
 *  2. Écritures PROPOSÉES (cession d'immobilisation, notes de frais sur avance, paiements fiscaux) : jamais postées automatiquement ; validées une à une par le comptable,
 *     exportables en CSV. Une proposition n'est validable que si le plan de comptes est paramétré ET validé par un professionnel.
 *  3. Paramètres : plan de comptes (rôle → numéro) et taux/paramètres fiscaux, saisis par vous, datés, avec source. AUCUN numéro de compte ni taux n'est codé ici.
 *     Toute modification du plan ou des taux annule la validation en cours (nouvelle validation obligatoire).
 * Clés créées : exb_pc_controles, exb_pc_ecritures, exb_pc_params, exb_pc_audit. Retrait : supprimer la balise dans index.html (les données restent). */
(function (w, d) {
  'use strict';
  if (w.EXBPC) return;
  var K = { CT: 'exb_pc_controles', EC: 'exb_pc_ecritures', PA: 'exb_pc_params', AU: 'exb_pc_audit' };
  var ROLES = [['charges_frais', 'Charges – frais du personnel / missions'], ['avances_personnel', 'Personnel – avances'], ['immobilisation', 'Immobilisation (valeur brute)'], ['amortissements', 'Amortissements cumulés'], ['creance_cession', 'Créance sur cession'], ['produit_cession', 'Produit de cession (plus-value)'], ['charge_cession', 'Charge de cession (moins-value)'], ['dettes_fiscales', 'Dettes fiscales'], ['tresorerie_fiscale', 'Caisse / banque (paiement fiscal)'], ['tresorerie_avances', 'Caisse / banque (avances au personnel)']];
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nc(c) { c = String(c || 'USD').toUpperCase(); return /^(FC|CDF)$/.test(c) ? 'CDF' : c; }
  function nrm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
  function iso(x) { var s = String(x || '').slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ''; }
  function jour() { var n = new Date(); return n.getFullYear() + '-' + ('0' + (n.getMonth() + 1)).slice(-2) + '-' + ('0' + n.getDate()).slice(-2); }
  function nf(n, c) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: c === 'CDF' ? 0 : 2, maximumFractionDigits: c === 'CDF' ? 0 : 2 }).replace(/[\u202f\u00a0]/g, ' '); }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function raw(k) { var S = store(); try { return S ? S.getItem(k) : w.localStorage.getItem(k); } catch (e) { return null; } }
  function rdA(k) { try { var v = JSON.parse(raw(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function rdO(k) { try { var v = JSON.parse(raw(k) || '{}'); return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; } catch (e) { return {}; } }
  function wr(k, v) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(v)); else w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function qui() { try { var i = w.EXBDB && w.EXBDB.info && w.EXBDB.info(); return (i && (i.label || i.nom)) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function peutEcrire() { try { return !w.EXB_CORE || !w.EXB_CORE.can || w.EXB_CORE.can('comptabilite', 'ecrire') || w.EXB_CORE.can('paie', 'ecrire'); } catch (e) { return true; } }
  function audit(action, o) { var a = rdA(K.AU); a.push(Object.assign({ le: new Date().toISOString(), par: qui(), action: action }, o || {})); wr(K.AU, a); }
  function motifOk(m) { return String(m || '').trim().length >= 3; }

  /* ================= LOGIQUE PURE (testable) ================= */
  function empreinte(b) { var f = b.fin || {}; return [b.id, b.status, f.gross, f.inssE, f.ipr, f.avances, f.retDiv, f.net].join('|'); }
  function contratActif(c, per) { var s = per + '-31', e = per + '-01'; return (!c.start || c.start <= s) && (!c.end || c.end >= e); }
  /* ctx : { bulletins, contrats, rh:[{id}], avancesV233:[{employe,montant,devise,mouvements}], ... } */
  function controlerBulletin(b, ctx) {
    var e = [], a = [], f = b.fin;
    if (b.status === 'brouillon') return { etat: 'brouillon', e: [], a: ['Bulletin encore en brouillon dans Paie V81 : à valider dans Paie avant contrôle.'] };
    if (!f) e.push('Montants non figés sur ce bulletin validé.');
    else {
      if (!(f.gross > 0)) e.push('Brut nul ou négatif.');
      if (f.net < -0.005) e.push('Net à payer négatif.');
      if (Math.abs(r2(f.gross - f.inssE - f.ipr - f.avances - (f.retDiv || 0)) - f.net) > 0.011) e.push('Net incohérent : brut − INSS salarié − IPR − avances − retenues ≠ net.');
      if (Math.abs(r2(f.gross + f.inssP + f.inpp + f.onem) - f.cost) > 0.011) e.push('Coût employeur incohérent avec brut + charges patronales.');
    }
    if (!(b.rate > 0)) e.push('Taux USD/FC absent sur le bulletin.');
    var dbl = (ctx.bulletins || []).filter(function (x) { return x.id !== b.id && x.emp === b.emp && x.period === b.period && x.status !== 'brouillon'; });
    if (dbl.length) e.push('Doublon : un autre bulletin validé existe pour cet employé et cette période.');
    if (!(ctx.contrats || []).some(function (c) { return c.emp === b.emp && contratActif(c, b.period); })) a.push('Aucun contrat actif pour cette période.');
    if ((ctx.rh || []).length && !(ctx.rh || []).some(function (h) { return h.id === b.emp; })) a.push('Employé absent de la fiche Personnel.');
    var nom = nrm(b.name);
    if (nom && (ctx.avancesV233 || []).some(function (x) { return nrm(x.employe) === nom && !x.annule; }) && (b.av || []).length) a.push('Avances présentes à la fois dans Paie V81 (retenue) et dans le registre Avances & frais V233 : vérifier qu’elles ne sont pas comptées deux fois.');
    if (b.status === 'payé') a.push('Bulletin payé : le paiement n’est pas lié automatiquement à la caisse, vérifier la sortie correspondante.');
    return { etat: e.length ? 'erreur' : 'ok', e: e, a: a };
  }
  function proposer(D) {
    var out = [];
    (D.ce || []).forEach(function (c) {
      if (c.annule) return; var im = (D.im || []).filter(function (x) { return x.id === c.immo; })[0]; if (!im) return;
      var cost = r2(+im.cost || 0), vnc = r2(c.vnc), prix = r2(c.prix), L = [];
      L.push({ role: 'creance_cession', sens: 'D', montant: prix }); L.push({ role: 'amortissements', sens: 'D', montant: r2(cost - vnc) }); L.push({ role: 'immobilisation', sens: 'C', montant: cost });
      var res = r2(prix - vnc); if (res > 0.004) L.push({ role: 'produit_cession', sens: 'C', montant: res }); else if (res < -0.004) L.push({ role: 'charge_cession', sens: 'D', montant: -res });
      out.push({ src: 'cession:' + c.id, type: 'Cession d’immobilisation', date: iso(c.date), lib: 'Cession ' + (c.libelle || im.label || ''), devise: nc(c.devise), lignes: L.filter(function (l) { return l.montant > 0.004; }) });
    });
    (D.fr || []).forEach(function (f) {
      if (f.annule || !f.avance_id || !(f.montant > 0)) return;
      out.push({ src: 'frais:' + f.id, type: 'Note de frais sur avance', date: iso(f.date), lib: 'Frais ' + (f.employe || '') + ' – ' + (f.nature || '') + ' (pièce ' + (f.piece || '') + ')', devise: nc(f.devise), lignes: [{ role: 'charges_frais', sens: 'D', montant: r2(f.montant) }, { role: 'avances_personnel', sens: 'C', montant: r2(f.montant) }] });
    });
    (D.av || []).forEach(function (a) {
      if (a.annule || !(a.montant > 0)) return; var dv = nc(a.devise), av = 'Avance ' + (a.employe || '') + ' (à ne valider que si le décaissement n’est pas déjà comptabilisé via la Trésorerie)';
      out.push({ src: 'avance:' + a.id, type: 'Avance au personnel', date: iso(a.date), lib: av, devise: dv, lignes: [{ role: 'avances_personnel', sens: 'D', montant: r2(a.montant) }, { role: 'tresorerie_avances', sens: 'C', montant: r2(a.montant) }] });
      (a.mouvements || []).forEach(function (m) {
        if (m.annule || !(m.montant > 0)) return; var rb = m.type === 'remb_employe';
        out.push({ src: 'avmv:' + m.id, type: rb ? 'Remboursement d’avance' : 'Paiement à l’employé', date: iso(m.date), lib: (rb ? 'Remboursement ' : 'Paiement ') + (a.employe || '') + ' (réf. ' + (m.ref || '') + ')', devise: dv, lignes: [{ role: rb ? 'tresorerie_avances' : 'avances_personnel', sens: 'D', montant: r2(m.montant) }, { role: rb ? 'avances_personnel' : 'tresorerie_avances', sens: 'C', montant: r2(m.montant) }] });
      });
    });
    (D.dp || []).forEach(function (dep) {
      if (dep.annule) return; var ob = (D.ob || []).filter(function (o) { return o.id === dep.obligation; })[0];
      (dep.paiements || []).forEach(function (p) {
        if (p.annule || !(p.montant > 0)) return;
        out.push({ src: 'fisc:' + p.id, type: 'Paiement fiscal', date: iso(p.date), lib: 'Paiement ' + (ob ? ob.nom : 'obligation fiscale') + ' ' + (dep.periode || '') + ' (réf. ' + (p.reference || '') + ')', devise: nc(dep.devise), lignes: [{ role: 'dettes_fiscales', sens: 'D', montant: r2(p.montant) }, { role: 'tresorerie_fiscale', sens: 'C', montant: r2(p.montant) }] });
      });
    });
    return out;
  }
  function resoudre(prop, P) {
    var cm = {}; ((P && P.comptes) || []).forEach(function (c) { cm[c.role] = c; });
    var manque = [], deb = 0, cre = 0;
    var L = prop.lignes.map(function (l) { var c = cm[l.role]; if (!c) manque.push(l.role); if (l.sens === 'D') deb += l.montant; else cre += l.montant; return { role: l.role, sens: l.sens, montant: l.montant, numero: c ? c.numero : '', intitule: c ? c.intitule : '' }; });
    return { lignes: L, manque: manque.filter(function (x, i, t) { return t.indexOf(x) === i; }), equilibre: Math.abs(r2(deb) - r2(cre)) <= 0.011, debit: r2(deb), credit: r2(cre) };
  }
  function paramsValides(P) { var v = P && P.validation; return !!(v && String(v.par || '').trim() && iso(v.date) && String(v.ref || '').trim()); }
  function peutValider(prop, P) {
    var r = resoudre(prop, P), e = [];
    if (!paramsValides(P)) e.push('Plan de comptes non validé par un professionnel (onglet Paramètres).');
    if (r.manque.length) e.push('Comptes non paramétrés : ' + r.manque.join(', ') + '.');
    if (!r.equilibre) e.push('Écriture non équilibrée.');
    if (!prop.lignes.length) e.push('Aucune ligne.');
    if (!prop.date) e.push('Date manquante.');
    return e;
  }
  function csv(decisions) {
    var rows = [['Date', 'Pièce', 'Devise', 'Compte', 'Intitulé', 'Débit', 'Crédit', 'Libellé', 'Validé par', 'Validé le']];
    decisions.filter(function (x) { return x.statut === 'validee'; }).forEach(function (x) { x.lignes.forEach(function (l) { rows.push([x.date, x.src, x.devise, l.numero, l.intitule, l.sens === 'D' ? l.montant.toFixed(2) : '', l.sens === 'C' ? l.montant.toFixed(2) : '', x.lib, x.par, String(x.le || '').slice(0, 10)]); }); });
    return rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n');
  }

  var SRC = [['exb_pc_audit', 'Contrôle paie / écritures'], ['exb_pm_audit', 'Avances · Fiscalité · Immo'], ['exb_an_audit', 'Analytique chantier'], ['exb_fd_audit', 'Fournisseurs & dettes'], ['exb_tr_audit', 'Trésorerie']];
  function journalAudit(lect, dem) {
    var out = [];
    SRC.forEach(function (s) { (lect(s[0]) || []).forEach(function (x) { if (!x) return; var det = Object.keys(x).filter(function (k) { return ['le', 'par', 'action'].indexOf(k) < 0; }).map(function (k) { return k + ': ' + (typeof x[k] === 'object' ? JSON.stringify(x[k]) : x[k]); }).join(' · '); out.push({ le: x.le || x.at || '', par: x.par || '', source: s[1], action: x.action || '', detail: det }); }); });
    (dem || []).forEach(function (q) { (q.historique || []).forEach(function (h) { out.push({ le: h.at || '', par: h.par || '', source: 'Centre de réception', action: h.action || '', detail: (q.ref || q.id || '') + ' · ' + (h.de || '') + ' → ' + (h.vers || '') + (h.motif ? ' · motif: ' + h.motif : '') }); }); });
    return out.sort(function (a, b) { return String(b.le).localeCompare(String(a.le)); });
  }
  function csvAudit(L) { var rows = [['Date', 'Auteur', 'Source', 'Action', 'Détail']].concat(L.map(function (x) { return [x.le, x.par, x.source, x.action, x.detail]; })); return rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[;"\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(';'); }).join('\r\n'); }

  /* ================= DONNÉES ================= */
  function lire() {
    var P = rdO(K.PA); if (!Array.isArray(P.comptes)) P.comptes = []; if (!Array.isArray(P.taux)) P.taux = [];
    var cfg = rdO('exb_compta_cfg'), pay = rdA('exb_payroll'), hr = []; try { hr = (typeof w.exbHr !== 'undefined' ? w.exbHr : []) || []; } catch (e) {}
    return { P: P, pay: pay, bul: pay.filter(function (x) { return x && x.type === 'bulletin'; }), ctr: pay.filter(function (x) { return x && x.type === 'contrat'; }), rh: hr, av33: rdA('exb_pm_avances'), fr: rdA('exb_pm_frais'), av: rdA('exb_pm_avances'), dem: rdA('exb_cr_demandes'), ob: rdA('exb_pm_obligations'), dp: rdA('exb_pm_depots'), ce: rdA('exb_im_cessions'), im: rdA('exb_immo').filter(function (o) { return o && o.id; }), ct: rdA(K.CT), ec: rdA(K.EC), pont: (cfg && cfg.paiev81) || {} };
  }

  /* ================= INTERFACE ================= */
  var TAB = 'controle', PER = '', MSG = '', ERR = '';
  function css() {
    if ($('pc_css')) return; var s = d.createElement('style'); s.id = 'pc_css';
    s.textContent = '#pc_c{background:#f5f8fd;color:#1b2a41;border-radius:14px;max-width:1100px;width:100%;padding:14px;font-family:inherit;box-sizing:border-box}#pc_c *{box-sizing:border-box}#pc_c h3{margin:0;color:#0f2a5c}#pc_c .hd{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px}#pc_c .x{border:0;background:#0f2a5c;color:#fff;border-radius:8px;padding:7px 12px;cursor:pointer;font-weight:700}' +
      '#pc_c .tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}#pc_c .tabs button{border:1px solid #d5deee;background:#fff;border-radius:9px;padding:8px 12px;cursor:pointer;font-weight:600;color:#1b2a41}#pc_c .tabs button.on{background:#0f2a5c;color:#fff;border-color:#0f2a5c}' +
      '#pc_c .cd{background:#fff;border:1px solid #e3e9f3;border-radius:12px;padding:12px;margin-bottom:10px;overflow:hidden}#pc_c .tw{overflow-x:auto}#pc_c table{width:100%;border-collapse:collapse;font-size:13px}#pc_c th{text-align:left;color:#5b6b82;padding:7px 6px;border-bottom:1px solid #e3e9f3;white-space:nowrap}#pc_c td{padding:8px 6px;border-bottom:1px solid #eef2f9;vertical-align:top}#pc_c .r{text-align:right;white-space:nowrap}' +
      '#pc_c .pl{display:inline-block;border-radius:999px;padding:2px 9px;font-size:11.5px;font-weight:700;background:#fdecc8;color:#8a5200;margin:1px 2px 1px 0}#pc_c .pl.v{background:#dcfce7;color:#166534}#pc_c .pl.r{background:#fee4e2;color:#b42318}#pc_c .er{background:#fee4e2;border:1px solid #f3b7b1;color:#8a1c14;border-radius:8px;padding:8px 10px;margin-bottom:8px}#pc_c .ok{background:#dcfce7;border:1px solid #a7e3bb;color:#14532d;border-radius:8px;padding:8px 10px;margin-bottom:8px}#pc_c .wn{background:#fff7e6;border:1px solid #f3d9a4;color:#6b4300;border-radius:8px;padding:8px 10px;margin-bottom:8px}#pc_c .mu{color:#5b6b82;font-size:12.5px}' +
      '#pc_c label{display:block;font-size:12.5px;color:#5b6b82;margin-top:6px}#pc_c input,#pc_c select{width:100%;padding:8px;border:1px solid #d5deee;border-radius:8px;font-size:14px;background:#fff;color:#1b2a41}#pc_c .gr{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px}#pc_c .bt{background:#0f2a5c;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}#pc_c .bt.s{background:#e8edf6;color:#0f2a5c;margin:1px}' +
      '@media print{body>*:not(#pc_ov){display:none!important}#pc_ov{position:static!important;background:#fff!important}#pc_c .tabs,#pc_c .x,#pc_c .no-print{display:none!important}}';
    d.head.appendChild(s);
  }
  function badge(t, c) { return '<span class="pl ' + (c || '') + '">' + esc(t) + '</span>'; }
  function tbl(h, rows) { return '<div class="tw"><table><thead><tr>' + h.map(function (x) { return '<th>' + x + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>'; }
  function val(id) { var e = $(id); return e ? e.value : ''; }
  function msgs() { return (ERR ? '<div class="er">' + ERR + '</div>' : '') + (MSG ? '<div class="ok">' + esc(MSG) + '</div>' : ''); }
  function vControle(D) {
    if (!PER) PER = jour().slice(0, 7);
    var ctx = { bulletins: D.bul, contrats: D.ctr, rh: D.rh, avancesV233: D.av33 }, B = D.bul.filter(function (b) { return b.period === PER; });
    var pont = D.pont && D.pont.on ? badge('Pont écritures V81 actif depuis ' + (D.pont.from || '—'), 'v') : badge('Pont écritures V81 désactivé (Comptabilité › Paie)', '');
    var h = '<div class="cd"><div class="gr"><div><label>Période</label><input type="month" id="pc_per" value="' + esc(PER) + '"></div><div><label>Comptabilisation des bulletins</label><div style="margin-top:6px">' + pont + '</div></div></div><p class="mu" style="margin:8px 0 0">Lecture seule des bulletins de Paie V81. Les écritures des bulletins sont produites par le pont existant (pas ici) ; le contrôle ci-dessous est l’avis du comptable.</p></div>';
    if (!B.length) return h + '<div class="cd mu">Aucun bulletin pour cette période.</div>';
    h += '<div class="cd">' + tbl(['Employé', 'Brut', 'Net', 'Statut Paie', 'Contrôle automatique', 'Décision comptable', ''], B.map(function (b) {
      var c = controlerBulletin(b, ctx), f = b.fin || {}, dec = D.ct.filter(function (x) { return x.id === b.id; })[0], dd = '';
      if (dec) { var chg = dec.statut === 'controle' && dec.empreinte !== empreinte(b); dd = chg ? badge('Modifié depuis le contrôle', 'r') : badge(dec.statut === 'controle' ? 'Contrôlé' : 'À corriger', dec.statut === 'controle' ? 'v' : 'r') + '<div class="mu">' + esc(dec.par) + ' · ' + esc(String(dec.le || '').slice(0, 10)) + (dec.motif ? '<br>' + esc(dec.motif) : '') + '</div>'; }
      var auto = c.etat === 'brouillon' ? badge('Brouillon', '') : (c.e.length ? c.e.map(function (x) { return badge('Erreur', 'r') + esc(x); }).join('<br>') : badge('Cohérent', 'v')) + (c.a.length ? '<br>' + c.a.map(function (x) { return '<span class="mu">⚠ ' + esc(x) + '</span>'; }).join('<br>') : '');
      var act = c.etat === 'brouillon' ? '' : '<button class="bt s" data-a="ctl_ok" data-v="' + esc(b.id) + '">✔ Contrôlé</button><button class="bt s" data-a="ctl_ko" data-v="' + esc(b.id) + '">↩ À corriger</button>';
      return '<tr><td>' + esc(b.name || b.emp) + '</td><td class="r">' + nf(f.gross, 'USD') + '</td><td class="r">' + nf(f.net, 'USD') + '</td><td>' + esc(b.status) + '</td><td>' + auto + '</td><td>' + (dd || '<span class="mu">—</span>') + '</td><td class="no-print">' + act + '</td></tr>';
    })) + '</div>';
    return h;
  }
  function vEcritures(D) {
    var P = D.P, props = proposer(D), h = '';
    if (!paramsValides(P)) h += '<div class="wn">Le plan de comptes n’est pas validé par un professionnel : les écritures sont visibles mais ne peuvent pas être validées (onglet Paramètres).</div>';
    h += '<div class="cd"><b>Écritures proposées</b> <span class="mu">— jamais postées automatiquement dans le journal.</span>';
    if (!props.length) return h + '<p class="mu">Aucune cession, note de frais sur avance ni paiement fiscal à proposer.</p></div>';
    h += tbl(['Date', 'Type', 'Libellé', 'Lignes', 'Décision', ''], props.map(function (p) {
      var r = resoudre(p, P), dec = D.ec.filter(function (x) { return x.src === p.src; }).pop(), er = peutValider(p, P);
      var lg = r.lignes.map(function (l) { return (l.sens === 'D' ? 'D ' : 'C ') + esc(l.numero || '⚠ ' + l.role) + ' · ' + nf(l.montant, p.devise) + ' ' + esc(p.devise); }).join('<br>');
      var dd = dec ? badge(dec.statut === 'validee' ? 'Validée' : 'Rejetée', dec.statut === 'validee' ? 'v' : 'r') + '<div class="mu">' + esc(dec.par) + ' · ' + esc(String(dec.le || '').slice(0, 10)) + (dec.motif ? '<br>' + esc(dec.motif) : '') + '</div>' : (er.length ? '<span class="mu">' + er.map(esc).join('<br>') + '</span>' : badge('À valider', ''));
      var act = dec ? '' : '<button class="bt s" data-a="ec_ok" data-v="' + esc(p.src) + '"' + (er.length ? ' disabled style="opacity:.5"' : '') + '>✔ Valider</button><button class="bt s" data-a="ec_ko" data-v="' + esc(p.src) + '">✖ Rejeter</button>';
      return '<tr><td>' + esc(p.date) + '</td><td>' + esc(p.type) + '</td><td>' + esc(p.lib) + '</td><td>' + lg + '</td><td>' + dd + '</td><td class="no-print">' + act + '</td></tr>';
    })) + '<p class="no-print"><button class="bt" data-a="ec_csv">⬇ Exporter les écritures validées (CSV)</button></p></div>';
    return h;
  }
  var AFILT = '', ASRC = '';
  function auditList(D) { var L = journalAudit(function (k) { return rdA(k); }, D.dem), q = nrm(AFILT); return L.filter(function (x) { return (!ASRC || x.source === ASRC) && (!q || nrm([x.par, x.action, x.detail].join(' ')).indexOf(q) >= 0); }); }
  function vAudit(D) {
    var L = auditList(D), tot = journalAudit(function (k) { return rdA(k); }, D.dem).length;
    var h = '<div class="cd"><div class="gr"><div><label>Source</label><select id="au_s"><option value="">Toutes</option>' + SRC.map(function (s) { return '<option' + (ASRC === s[1] ? ' selected' : '') + '>' + esc(s[1]) + '</option>'; }).join('') + '<option' + (ASRC === 'Centre de réception' ? ' selected' : '') + '>Centre de réception</option></select></div><div><label>Recherche</label><input id="au_q" value="' + esc(AFILT) + '"></div></div><p class="mu">' + tot + ' événement(s) au total, ' + L.length + ' affiché(s) (300 plus récents). Ce journal est en lecture seule : aucune action de cet écran ne modifie ni n’efface un événement.</p></div>';
    h += '<div class="cd">' + (L.length ? tbl(['Date', 'Auteur', 'Source', 'Action', 'Détail'], L.slice(0, 300).map(function (x) { return '<tr><td>' + esc(String(x.le).replace('T', ' ').slice(0, 16)) + '</td><td>' + esc(x.par) + '</td><td>' + esc(x.source) + '</td><td>' + esc(x.action) + '</td><td class="mu">' + esc(x.detail) + '</td></tr>'; })) : '<p class="mu">Aucun événement.</p>') + '<p class="no-print"><button class="bt" data-a="aud_csv">⬇ Exporter (CSV)</button></p></div>';
    return h;
  }
  function vParams(D) {
    var P = D.P, v = P.validation, h = '';
    h += paramsValides(P) ? '<div class="ok">Validé par <b>' + esc(v.par) + '</b> le ' + esc(v.date) + ' (réf. ' + esc(v.ref) + '). Toute modification du plan ou des taux annule cette validation.</div>' : '<div class="wn">Non validé. Ces paramètres doivent être validés par un professionnel compétent en RDC (cahier § 12) avant toute validation d’écriture. Aucun numéro de compte ni taux n’est fourni par le logiciel.</div>';
    h += '<div class="cd"><b>Plan de comptes (rôle → numéro)</b>' + tbl(['Rôle', 'Numéro', 'Intitulé'], ROLES.map(function (r) { var c = P.comptes.filter(function (x) { return x.role === r[0]; })[0]; return '<tr><td>' + esc(r[1]) + '</td><td>' + (c ? esc(c.numero) : '<span class="pl r">non paramétré</span>') + '</td><td>' + (c ? esc(c.intitule) : '') + '</td></tr>'; })) +
      '<div class="gr"><div><label>Rôle</label><select id="pc_r">' + ROLES.map(function (r) { return '<option value="' + esc(r[0]) + '">' + esc(r[1]) + '</option>'; }).join('') + '</select></div><div><label>Numéro de compte</label><input id="pc_n"></div><div><label>Intitulé</label><input id="pc_i"></div></div><p><button class="bt" data-a="cpt_save">Enregistrer le compte</button></p></div>';
    h += '<div class="cd"><b>Taux et paramètres fiscaux (datés, sourcés)</b>' + (P.taux.length ? tbl(['Nom', 'Valeur', 'Effet', 'Source / texte', 'Saisi par'], P.taux.map(function (t) { return '<tr><td>' + esc(t.nom) + '</td><td>' + esc(t.valeur) + '</td><td>' + esc(t.effet) + '</td><td>' + esc(t.source) + '</td><td>' + esc(t.par) + '</td></tr>'; })) : '<p class="mu">Aucun taux saisi.</p>') +
      '<div class="gr"><div><label>Nom (ex. TVA)</label><input id="tx_n"></div><div><label>Valeur</label><input id="tx_v"></div><div><label>Date d’effet</label><input type="date" id="tx_d" value="' + jour() + '"></div><div><label>Source (texte légal, avis)</label><input id="tx_s"></div></div><p><button class="bt" data-a="tx_save">Ajouter le taux</button></p><p class="mu">Les barèmes de paie (INSS, IPR…) restent dans Paie › Barèmes.</p></div>';
    h += '<div class="cd"><b>Validation par un professionnel</b><div class="gr"><div><label>Nom du professionnel</label><input id="pv_p"></div><div><label>Date</label><input type="date" id="pv_d" value="' + jour() + '"></div><div><label>Référence (avis, courrier)</label><input id="pv_r"></div></div><p><button class="bt" data-a="pv_ok">Enregistrer la validation</button></p></div>';
    return h;
  }
  function paint() {
    var c = $('pc_c'); if (!c) return; var D = lire(), T = [['controle', '🧾 Contrôle paie'], ['ecritures', '📒 Écritures proposées'], ['audit', '🔎 Audit'], ['params', '⚙ Paramètres']];
    c.innerHTML = '<div class="hd"><h3>🧮 Contrôle paie · Écritures · Paramètres</h3><button class="x" data-a="close">✕ Fermer</button></div><div class="tabs">' + T.map(function (t) { return '<button data-a="tab" data-v="' + t[0] + '"' + (TAB === t[0] ? ' class="on"' : '') + '>' + t[1] + '</button>'; }).join('') + '</div>' + msgs() + (TAB === 'ecritures' ? vEcritures(D) : TAB === 'params' ? vParams(D) : TAB === 'audit' ? vAudit(D) : vControle(D));
    var as = $('au_s'); if (as) as.onchange = function () { ASRC = as.value; paint(); }; var aq = $('au_q'); if (aq) aq.onchange = function () { AFILT = aq.value; paint(); };
    var p = $('pc_per'); if (p) p.onchange = function () { PER = p.value; MSG = ''; ERR = ''; paint(); };
    ERR = ''; MSG = '';
  }
  function stop(m) { ERR = esc(m); paint(); }
  function sauver(k, v, act, o, msg) { if (!wr(k, v)) return stop('Enregistrement impossible (stockage).'); audit(act, o); MSG = msg; paint(); }
  function resetValid(P) { delete P.validation; }
  function agir(a, v) {
    var D = lire(), P = D.P;
    if (a === 'close') return close();
    if (a === 'tab') { TAB = v; return paint(); }
    if (a === 'aud_csv') { var La = auditList(D); if (!La.length) return stop('Aucun événement à exporter.'); return telecharger(csvAudit(La), 'journal-audit-' + jour() + '.csv'); }
    if (!peutEcrire()) return stop('Action réservée aux rôles comptabilité / paie.');
    if (a === 'ctl_ok' || a === 'ctl_ko') {
      var b = D.bul.filter(function (x) { return x.id === v; })[0]; if (!b) return; var c = controlerBulletin(b, { bulletins: D.bul, contrats: D.ctr, rh: D.rh, avancesV233: D.av33 }), mo = '';
      if (a === 'ctl_ok') { if (c.etat !== 'ok') return stop(c.etat === 'brouillon' ? 'Bulletin en brouillon.' : 'Contrôle impossible : ' + c.e.join(' ')); }
      else { mo = (w.prompt('Motif (obligatoire) :') || '').trim(); if (!motifOk(mo)) return stop('Un motif est obligatoire.'); }
      var all = D.ct.filter(function (x) { return x.id !== v; }); all.push({ id: v, period: b.period, emp: b.emp, statut: a === 'ctl_ok' ? 'controle' : 'a_corriger', motif: mo, empreinte: empreinte(b), par: qui(), le: new Date().toISOString() });
      return sauver(K.CT, all, a === 'ctl_ok' ? 'bulletin_controle' : 'bulletin_a_corriger', { bulletin: v, periode: b.period, motif: mo }, a === 'ctl_ok' ? 'Bulletin marqué contrôlé.' : 'Bulletin renvoyé pour correction.');
    }
    if (a === 'ec_ok' || a === 'ec_ko') {
      var p = proposer(D).filter(function (x) { return x.src === v; })[0]; if (!p) return;
      if (D.ec.some(function (x) { return x.src === v; })) return stop('Cette écriture a déjà fait l’objet d’une décision.');
      var m2 = '', rl = resoudre(p, P);
      if (a === 'ec_ok') { var er = peutValider(p, P); if (er.length) return stop(er.join(' ')); }
      else { m2 = (w.prompt('Motif du rejet (obligatoire) :') || '').trim(); if (!motifOk(m2)) return stop('Un motif est obligatoire.'); }
      var ea = D.ec.slice(); ea.push({ src: v, type: p.type, date: p.date, lib: p.lib, devise: p.devise, lignes: rl.lignes, statut: a === 'ec_ok' ? 'validee' : 'rejetee', motif: m2, par: qui(), le: new Date().toISOString() });
      return sauver(K.EC, ea, a === 'ec_ok' ? 'ecriture_validee' : 'ecriture_rejetee', { src: v, motif: m2 }, a === 'ec_ok' ? 'Écriture validée (non postée au journal : export CSV).' : 'Écriture rejetée.');
    }
    if (a === 'ec_csv') {
      var txt = csv(D.ec); if (txt.split('\r\n').length < 2) return stop('Aucune écriture validée à exporter.');
      if (telecharger(txt, 'ecritures-validees-' + jour() + '.csv')) audit('export_csv', {}); return;
    }
    if (a === 'cpt_save') {
      var rl2 = val('pc_r'), nu = val('pc_n').trim(), it = val('pc_i').trim(); if (!nu || !it) return stop('Numéro et intitulé obligatoires.');
      if (!ROLES.some(function (r) { return r[0] === rl2; })) return stop('Rôle invalide.');
      P.comptes = P.comptes.filter(function (x) { return x.role !== rl2; }).concat([{ role: rl2, numero: nu, intitule: it, par: qui(), le: new Date().toISOString() }]); resetValid(P);
      return sauver(K.PA, P, 'compte_parametre', { role: rl2, numero: nu }, 'Compte enregistré. La validation professionnelle est à renouveler.');
    }
    if (a === 'tx_save') {
      var t = { nom: val('tx_n').trim(), valeur: val('tx_v').trim(), effet: iso(val('tx_d')), source: val('tx_s').trim(), par: qui(), le: new Date().toISOString() };
      if (!t.nom || !t.valeur || !t.effet || t.source.length < 3) return stop('Nom, valeur, date d’effet et source sont obligatoires.');
      if (P.taux.some(function (x) { return nrm(x.nom) === nrm(t.nom) && x.effet === t.effet; })) return stop('Ce paramètre existe déjà à cette date d’effet.');
      P.taux.push(t); resetValid(P); return sauver(K.PA, P, 'taux_ajoute', { nom: t.nom, valeur: t.valeur, effet: t.effet }, 'Taux ajouté. La validation professionnelle est à renouveler.');
    }
    if (a === 'pv_ok') {
      var vv = { par: val('pv_p').trim(), date: iso(val('pv_d')), ref: val('pv_r').trim() }; if (!vv.par || !vv.date || !vv.ref) return stop('Nom, date et référence obligatoires.');
      if (!P.comptes.length) return stop('Aucun compte paramétré à valider.');
      P.validation = vv; return sauver(K.PA, P, 'parametres_valides', vv, 'Validation enregistrée.');
    }
  }
  function telecharger(txt, nom) { try { var bl = new Blob(['\ufeff' + txt], { type: 'text/csv;charset=utf-8' }), u = w.URL.createObjectURL(bl), l = d.createElement('a'); l.href = u; l.download = nom; d.body.appendChild(l); l.click(); setTimeout(function () { d.body.removeChild(l); w.URL.revokeObjectURL(u); }, 500); return true; } catch (e) { stop('Export impossible.'); return false; } }
  function close() { var o = $('pc_ov'); if (o && o.parentNode) o.parentNode.removeChild(o); }
  function open(tab) {
    close(); css(); TAB = tab || 'controle'; MSG = ''; ERR = ''; var o = d.createElement('div'); o.id = 'pc_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9990;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.onclick = function (e) { if (e.target === o) return close(); var t = e.target.closest ? e.target.closest('[data-a]') : null; if (t) agir(t.getAttribute('data-a'), t.getAttribute('data-v')); };
    o.innerHTML = '<div id="pc_c"></div>'; d.body.appendChild(o); paint();
  }
  function mount() { if ($('bpc')) return; var a = $('bpm') || $('ban') || $('btr') || $('bfd') || $('bcr') || $('bcompta'); if (!a || !a.parentNode) return; var b = d.createElement('button'); b.id = 'bpc'; b.textContent = '🧮 Contrôle paie · Écritures'; b.onclick = function () { open('controle'); }; a.parentNode.insertBefore(b, a.nextSibling); }
  function enregistrerModule() {
    try { if (w.EXB_MODULES && !w.EXB_MODULES.some(function (m) { return m.id === 'controlePaieEcritures'; })) w.EXB_MODULES.push({ id: 'controlePaieEcritures', name: 'Contrôle paie & écritures proposées', area: 'Finance', icon: '🧮', status: 'nouveau', deps: ['comptabilite', 'paie'] }); } catch (e) {}
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'controle-paie-ecritures', name: 'Contrôle paie & écritures proposées', version: '234.0.0', area: 'Finance', provides: ['compta.controle_paie', 'compta.ecritures_proposees'] }); } catch (e) {}
  }
  function start() { mount(); enregistrerModule(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000); }
  w.EXBPC = { open: open, pure: { controlerBulletin: controlerBulletin, proposer: proposer, resoudre: resoudre, peutValider: peutValider, paramsValides: paramsValides, csv: csv, journalAudit: journalAudit, csvAudit: csvAudit, empreinte: empreinte } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
