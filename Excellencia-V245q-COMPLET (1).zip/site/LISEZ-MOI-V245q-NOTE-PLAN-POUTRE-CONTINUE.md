# V245q — Note de calcul et plan d'exécution de la poutre continue

- `calcul-structure/exb-poutre-note.js` (NOUVEAU) : `calc`, `note`, `plan`, `doc`. Armatures de travée, chapeaux, cadres, flèche (dispense BAEL B.6.5,1), ancrages, métré, plan de ferraillage (coupe longitudinale, sections A-A et B-B, nomenclature).
- `calcul-structure/poutre-continue.html` : section « 5. Note de calcul et plan d'exécution » (aperçu, impression / PDF) ; champs projet, site, MOA, ingénieur ; chargement de `exb-robot-analyse.js` (diagrammes) et `exb-poutre-note.js`.
- `calcul-structure/test-poutre-note.js` (NOUVEAU) : `node site/calcul-structure/test-poutre-note.js`.
Calcul d'aide à l'étude : à faire vérifier par un ingénieur.
