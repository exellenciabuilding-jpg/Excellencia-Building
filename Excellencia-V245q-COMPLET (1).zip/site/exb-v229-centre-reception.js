/* Excellencia Building V229 — 📥 CENTRE DE RÉCEPTION COMPTABLE (Lot 1 du cahier des charges « Portail Comptable V229+ »).
 * Cycle de vie d'une demande : Brouillon → À contrôler → (Complément demandé | Rejetée) → En attente d'autorisation → Autorisée / Refusée
 *   → Paiement partiel / Payée → Comptabilisée → Clôturée.   Le comptable CONTRÔLE ; la Direction AUTORISE selon des seuils paramétrables.
 * Non-régression : ce module est un ADAPTATEUR. Il ne modifie ni ne remplace exb-compta*.js, exb-v78-finance.js, exb-budgetfin.js,
 *   exb-v81-paie.js, exb-decompte.js. Il ne touche PAS aux clés existantes (exb_cash, exb_invoices…) : une demande, même « Payée »,
 *   n'écrit rien en caisse tant que le raccord Trésorerie (Lot 3) n'est pas livré. Un paiement déclaré par un client reste « à vérifier ».
 * Clés créées (nouvelles, préfixe exb_cr_) : exb_cr_demandes, exb_cr_taux, exb_cr_params, exb_cr_pieces.
 * Devises : USD et CDF. Chaque demande fige son taux (source, date) à la soumission ; un nouveau taux ne réécrit jamais l'historique.
 * Aucun seuil, aucun taux fiscal n'est codé en dur : par défaut TOUT paiement exige la Direction (seuil du comptable = 0, délégation désactivée).
 * Retirer : supprimer la balise <script src="exb-v229-centre-reception.js"> de index.html (les données exb_cr_* restent intactes). */
(function (w, d) {
  'use strict';
  if (w.EXBCR) return;
  var KD = 'exb_cr_demandes', KT = 'exb_cr_taux', KP = 'exb_cr_params', KF = 'exb_cr_pieces';
  var TYPES = ['Facture fournisseur', 'Demande de dépense', 'Paiement déclaré par un client', 'Avance / note de frais', 'Élément de paie', 'Honoraires / prestation', 'Autre'];
  var T_FACT = 'Facture fournisseur', T_DECL = 'Paiement déclaré par un client';
  var SERVICES = ['Direction', 'Ingénieur / Chantier', 'Bureau d’études', 'Architecte', 'Achats / Magasin', 'RH', 'Commercial', 'Formation', 'Autre'];
  var DEVISES = ['USD', 'CDF'];
  var MODES = ['Espèces', 'Virement bancaire', 'Chèque', 'Mobile Money', 'Autre'];
  var ST = { BRO: 'Brouillon', CTRL: 'À contrôler', COMP: 'Complément demandé', REJ: 'Rejetée', CTR: 'Contrôlée', ATT: 'En attente d’autorisation', AUT: 'Autorisée', REF: 'Refusée', PPA: 'Paiement partiel', PAY: 'Payée', CPT: 'Comptabilisée', CLO: 'Clôturée' };
  var ORDRE = [ST.BRO, ST.CTRL, ST.COMP, ST.REJ, ST.CTR, ST.ATT, ST.AUT, ST.REF, ST.PPA, ST.PAY, ST.CPT, ST.CLO];
  var PARAMS_DEF = { seuil_comptable_usd: 0, delegation_comptable: false, separation_paiement: true, habilites: [], valide_par_direction: false };
  var MAX_PIECE = 400 * 1024, TYPES_PIECE = { 'application/pdf': 1, 'image/png': 1, 'image/jpeg': 1 };

  /* ================= fonctions pures (testées en Node : site/tools/test-centre-reception.js) ================= */
  function r2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }
  function isoOk(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && !isNaN(Date.parse(s + 'T00:00:00Z')) && new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s; }
  function norm(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ''); }
  function hash(s) { var h = 5381; s = String(s); for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  function nomSur(n) { return String(n || 'piece').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^\.+/, '').slice(0, 80) || 'piece'; }

  /* taux historisé : CDF pour 1 USD. On ne modifie jamais une entrée : on en ajoute une avec une date d'effet. */
  function tauxAu(taux, date) {
    var best = null;
    (taux || []).forEach(function (t) { if (t && t.cdf_par_usd > 0 && isoOk(t.date) && t.date <= date && (!best || t.date > best.date || (t.date === best.date && String(t.saisi_le) > String(best.saisi_le)))) best = t; });
    return best;
  }
  function convertir(m, de, vers, t) {
    m = Number(m); if (!isFinite(m)) return null;
    if (de === vers) return r2(m);
    if (!(t > 0)) return null;
    if (de === 'USD' && vers === 'CDF') return r2(m * t);
    if (de === 'CDF' && vers === 'USD') return r2(m / t);
    return null;
  }
  function figer(dem, taux) {
    var t = dem.taux_manuel > 0 ? { cdf_par_usd: dem.taux_manuel, date: dem.date_piece, source: 'Manuel autorisé' } : tauxAu(taux, dem.date_piece);
    if (!t) return { ok: false, err: 'Aucun taux USD/CDF n’est défini à la date de la pièce (' + dem.date_piece + '). Saisissez-le dans Paramètres.' };
    var u = convertir(dem.montant, dem.devise, 'USD', t.cdf_par_usd), c = convertir(dem.montant, dem.devise, 'CDF', t.cdf_par_usd);
    return { ok: true, taux_applique: t.cdf_par_usd, taux_source: t.source || '', taux_date: t.date, montant_usd: u, montant_cdf: c };
  }
  function empreinte(x) { return hash([norm(x.type), norm(x.tiers), norm(x.numero_piece), r2(x.montant).toFixed(2), x.devise].join('|')); }
  function doublon(list, x) {
    var e = empreinte(x);
    return (list || []).filter(function (o) { return o && o.id !== x.id && o.empreinte === e && o.statut !== ST.REJ && o.statut !== ST.REF; })[0] || null;
  }
  function valider(x) {
    var err = [];
    if (TYPES.indexOf(x.type) < 0) err.push('Type de demande inconnu.');
    if (SERVICES.indexOf(x.service) < 0) err.push('Service émetteur obligatoire.');
    if (!String(x.objet || '').trim()) err.push('L’objet est obligatoire.');
    if (!String(x.tiers || '').trim()) err.push('Le tiers (client, fournisseur ou employé) est obligatoire.');
    if (!(Number(x.montant) > 0) || !isFinite(Number(x.montant))) err.push('Le montant doit être un nombre supérieur à zéro.');
    if (DEVISES.indexOf(x.devise) < 0) err.push('Devise : USD ou CDF.');
    if (!isoOk(x.date_piece)) err.push('Date de la pièce invalide.');
    if (x.echeance && (!isoOk(x.echeance) || x.echeance < x.date_piece)) err.push('Échéance invalide (antérieure à la pièce).');
    if ((x.type === T_FACT || x.type === T_DECL) && !String(x.numero_piece || '').trim()) err.push('Le numéro de pièce (facture / référence de paiement) est obligatoire.');
    return err;
  }
  function reste(x) { var p = 0; (x.paiements || []).forEach(function (q) { p += Number(q.equiv) || 0; }); return r2((Number(x.montant) || 0) - p); }
  function exigeDirection(x, P) { P = Object.assign({}, PARAMS_DEF, P || {}); return !(P.delegation_comptable && P.seuil_comptable_usd > 0 && x.montant_usd <= P.seuil_comptable_usd); }
  function roleActeur(info, nom) {
    if (!info || !info.on) return { nom: nom || 'Utilisateur local', role: 'admin', solo: true };
    var r = info.role === 'admin' ? 'admin' : info.role === 'lecteur' ? 'lecteur' : (info.fonction === 'direction' ? 'direction' : info.fonction === 'comptable' ? 'comptable' : 'autre');
    return { nom: nom || info.label || '', role: r, solo: false };
  }

  /* droits par action (séparation des tâches du §6) */
  function peutAction(a, who, x, P) {
    P = Object.assign({}, PARAMS_DEF, P || {});
    var r = who.role, adm = r === 'admin', dir = r === 'direction', cpt = r === 'comptable';
    if (r === 'lecteur') return { ok: false, raison: 'Lecture seule.' };
    if (a === 'soumettre') return { ok: true };
    if (a === 'controler' || a === 'comptabiliser' || a === 'cloturer' || a === 'confirmer') return (adm || cpt) ? { ok: true } : { ok: false, raison: 'Réservé au comptable.' };
    if (a === 'complement' || a === 'rejeter') return (adm || cpt || dir) ? { ok: true } : { ok: false, raison: 'Réservé au comptable ou à la Direction.' };
    if (a === 'refuser' || a === 'retourner') return (adm || dir) ? { ok: true } : { ok: false, raison: 'Réservé à la Direction.' };
    if (a === 'autoriser') {
      if (adm || dir) return { ok: true };
      if (cpt && !exigeDirection(x, P)) return (!who.solo && x.controleur && norm(x.controleur) === norm(who.nom)) ? { ok: false, raison: 'Le comptable qui a contrôlé ne peut pas autoriser la même demande.' } : { ok: true };
      return { ok: false, raison: cpt ? 'Montant au-dessus du seuil délégué : autorisation de la Direction requise.' : 'Réservé à la Direction.' };
    }
    if (a === 'payer') {
      if (!(adm || cpt || dir)) return { ok: false, raison: 'Réservé au comptable ou au trésorier habilité.' };
      if (P.habilites && P.habilites.length && P.habilites.map(norm).indexOf(norm(who.nom)) < 0) return { ok: false, raison: 'Vous ne figurez pas dans la liste des personnes habilitées à exécuter les paiements.' };
      if (P.separation_paiement && !who.solo && x.autorisateur && norm(x.autorisateur) === norm(who.nom)) return { ok: false, raison: 'Séparation des tâches : la personne qui autorise ne peut pas exécuter le paiement.' };
      return { ok: true };
    }
    return { ok: false, raison: 'Action inconnue.' };
  }
  var DEPUIS = { soumettre: [ST.BRO, ST.COMP], controler: [ST.CTRL], complement: [ST.CTRL], rejeter: [ST.CTRL], autoriser: [ST.ATT], refuser: [ST.ATT], retourner: [ST.ATT], payer: [ST.AUT, ST.PPA], confirmer: [ST.CTR], comptabiliser: [ST.PAY], cloturer: [ST.CPT] };
  var MOTIF = { complement: 1, rejeter: 1, refuser: 1, retourner: 1 };
  function actionsPossibles(x) { return Object.keys(DEPUIS).filter(function (a) { return DEPUIS[a].indexOf(x.statut) >= 0 && !(a === 'confirmer' && x.type !== T_DECL) && !(a === 'controler' && false) && !(a === 'payer' && x.type === T_DECL) && !(a === 'comptabiliser' && x.type === T_DECL); }); }

  /* applique une action : renvoie une NOUVELLE copie (jamais de mutation), historique en ajout seulement */
  function appliquer(x, a, who, data, ctx) {
    data = data || {}; ctx = ctx || {}; var P = Object.assign({}, PARAMS_DEF, ctx.params || {}), now = ctx.now || new Date().toISOString();
    if (!DEPUIS[a] || DEPUIS[a].indexOf(x.statut) < 0 || actionsPossibles(x).indexOf(a) < 0) return { ok: false, err: 'Action impossible depuis le statut « ' + x.statut + ' ».' };
    var pa = peutAction(a, who, x, P); if (!pa.ok) return { ok: false, err: pa.raison };
    var motif = String(data.motif || '').trim();
    if (MOTIF[a] && motif.length < 3) return { ok: false, err: 'Un motif est obligatoire.' };
    var n = JSON.parse(JSON.stringify(x)), vers = null, extra = {};
    if (a === 'soumettre') {
      var e = valider(n); if (e.length) return { ok: false, err: e.join(' ') };
      var dbl = doublon(ctx.liste, n); if (dbl) return { ok: false, err: 'Doublon probable : la demande ' + dbl.ref + ' porte la même pièce, le même tiers et le même montant.' };
      if (!n.ref) { n.ref = ctx.ref; n.recu_le = now; }
      var f = n.taux_applique ? { ok: true } : figer(n, ctx.taux); if (!f.ok) return { ok: false, err: f.err };
      if (!n.taux_applique) Object.assign(n, f);
      n.empreinte = empreinte(n); vers = ST.CTRL;
    } else if (a === 'controler') {
      var c = data.checks || {};
      if (!(c.piece && c.montant && c.imputation && c.doublon)) return { ok: false, err: 'Cochez les quatre contrôles (pièce, montant/devise, imputation, absence de doublon) avant de valider.' };
      n.controleur = who.nom; n.controle_le = now; n.checks = { piece: true, montant: true, imputation: true, doublon: true };
      vers = n.type === T_DECL ? ST.CTR : ST.ATT;
    } else if (a === 'complement') { vers = ST.COMP; } else if (a === 'rejeter') { vers = ST.REJ; }
    else if (a === 'autoriser') { n.autorisateur = who.nom; n.autorise_le = now; vers = ST.AUT; }
    else if (a === 'refuser') { vers = ST.REF; } else if (a === 'retourner') { vers = ST.CTRL; }
    else if (a === 'confirmer') {
      if (!String(data.compte || '').trim() || !String(data.reference || '').trim() || !isoOk(data.date)) return { ok: false, err: 'Compte/caisse, référence de transaction et date sont obligatoires pour confirmer l’encaissement.' };
      n.encaissement = { confirme: true, compte: data.compte, reference: data.reference, date: data.date, par: who.nom, le: now };
      extra = { compte: data.compte, reference: data.reference }; vers = ST.CLO;
    } else if (a === 'payer') {
      var m = Number(data.montant), dv = data.devise || n.devise, rf = String(data.reference || '').trim();
      if (!(m > 0) || DEVISES.indexOf(dv) < 0) return { ok: false, err: 'Montant et devise du paiement invalides.' };
      if (!isoOk(data.date) || !String(data.compte || '').trim() || !String(data.mode || '').trim() || !rf) return { ok: false, err: 'Date, compte/caisse, mode et référence du paiement sont obligatoires.' };
      var ref0 = norm(rf), pris = (ctx.liste || []).some(function (o) { return o.id !== n.id && (o.paiements || []).some(function (q) { return norm(q.reference) === ref0; }); }) || (n.paiements || []).some(function (q) { return norm(q.reference) === ref0; });
      if (pris) return { ok: false, err: 'Cette référence de paiement existe déjà (doublon).' };
      var eq = m, tp = null, regle = 'meme_devise', ecart = 0;
      if (dv !== n.devise) {
        regle = data.regle;
        if (['taux_demande', 'taux_jour', 'manuel'].indexOf(regle) < 0) return { ok: false, err: 'Paiement dans une autre devise : choisissez explicitement la règle de conversion.' };
        tp = regle === 'taux_demande' ? n.taux_applique : Number(data.taux);
        if (!(tp > 0)) return { ok: false, err: 'Taux de conversion introuvable pour la règle choisie.' };
        eq = convertir(m, dv, n.devise, tp); ecart = r2(convertir(m, dv, n.devise, n.taux_applique) - eq);
      }
      if (eq > reste(n) + 0.005) return { ok: false, err: 'Le paiement (' + eq + ' ' + n.devise + ') dépasse le reste à payer (' + reste(n) + ' ' + n.devise + ').' };
      n.paiements = (n.paiements || []).concat([{ date: data.date, montant: r2(m), devise: dv, equiv: eq, devise_equiv: n.devise, regle: regle, taux: tp, ecart_change: ecart, compte: data.compte, mode: data.mode, reference: rf, preuve: data.preuve || '', par: who.nom, le: now }]);
      vers = reste(n) <= 0.005 ? ST.PAY : ST.PPA; extra = { montant: r2(m), devise: dv, reference: rf };
    } else if (a === 'comptabiliser') { n.ecriture_ref = String(data.ecriture_ref || '').trim(); n.comptabilise_par = who.nom; vers = ST.CPT; }
    else if (a === 'cloturer') { vers = ST.CLO; }
    n.historique = (n.historique || []).concat([Object.assign({ at: now, par: who.nom, role: who.role, action: a, de: x.statut, vers: vers, motif: motif }, extra)]);
    n.statut = vers; n.maj_le = now;
    return { ok: true, demande: n };
  }
  function ecartChange(x) { var s = 0; (x.paiements || []).forEach(function (q) { s += Number(q.ecart_change) || 0; }); return r2(s); }
  function stats(list) {
    var par = {}, attente = { USD: 0, CDF: 0 }; ORDRE.forEach(function (s) { par[s] = 0; });
    (list || []).forEach(function (x) { if (par[x.statut] != null) par[x.statut]++; if (x.statut === ST.ATT) attente[x.devise] = r2((attente[x.devise] || 0) + x.montant); });
    return { total: (list || []).length, parStatut: par, aControler: par[ST.CTRL], aAutoriser: par[ST.ATT], aPayer: par[ST.AUT] + par[ST.PPA], complements: par[ST.COMP], attenteParDevise: attente };
  }
  function prochaineRef(list, annee) {
    var mx = 0, re = new RegExp('^RC-' + annee + '-(\\d{4})$'); (list || []).forEach(function (x) { var m = re.exec(x && x.ref || ''); if (m) mx = Math.max(mx, parseInt(m[1], 10)); });
    return 'RC-' + annee + '-' + ('0000' + (mx + 1)).slice(-4);
  }
  function filtrer(list, f) {
    f = f || {}; var q = norm(f.q);
    return (list || []).filter(function (x) { return (!f.statut || x.statut === f.statut) && (!f.type || x.type === f.type) && (!f.service || x.service === f.service) && (!q || norm([x.ref, x.objet, x.tiers, x.numero_piece, x.chantier].join(' ')).indexOf(q) >= 0); })
      .sort(function (a, b) { return String(b.maj_le || b.cree_le).localeCompare(String(a.maj_le || a.cree_le)); });
  }

  /* ================= données ================= */
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function raw(k) { var S = store(); try { return (S ? S.getItem(k) : w.localStorage.getItem(k)); } catch (e) { return null; } }
  function rdA(k) { try { var v = JSON.parse(raw(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function rdO(k) { try { var v = JSON.parse(raw(k) || '{}'); return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; } catch (e) { return {}; } }
  function wr(k, v) { var S = store(); try { if (S) S.setItem(k, JSON.stringify(v)); else w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function params() { return Object.assign({}, PARAMS_DEF, rdO(KP)); }
  function info() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info()) || { on: false }; } catch (e) { return { on: false }; } }
  function qui() { try { return (w.EXBLIC && w.EXBLIC.who && w.EXBLIC.who()) || (info().label) || ''; } catch (e) { return ''; } }
  function acteur() { return roleActeur(info(), qui()); }
  function nowIso() { return new Date().toISOString(); }
  function jour() { return nowIso().slice(0, 10); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function say(m, t) { try { w.notify(m, t || 'info', 5000); } catch (e) { try { w.alert(m); } catch (x) {} } }
  function audit(a, b) { try { if (typeof w.audit === 'function') w.audit(a, b); } catch (e) {} }
  function fmt(n, dv) { return (Number(n) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + dv; }
  function uid() { return 'CR-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(); }

  /* ================= style (marine / or, comme la maquette V229+) ================= */
  var CSS = '#cr_c{background:#eef1f6;color:#202633;width:100%;max-width:1040px;border-radius:14px;overflow:hidden;font-family:Arial,sans-serif}' +
    '#cr_c .eh{background:linear-gradient(135deg,#0f2447,#1b3b6b);color:#fff;padding:13px 16px;border-bottom:3px solid #c49a38;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}' +
    '#cr_c .eh b{font-size:17px}#cr_c .eh small{display:block;color:#dce4f0;font-size:11px}#cr_c .eh button{border:0;border-radius:8px;padding:8px 11px;font-weight:bold;cursor:pointer;background:#fff;color:#173565}' +
    '#cr_c .eb{padding:14px}#cr_c .kp{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:12px}' +
    '#cr_c .k{background:#fff;border-radius:12px;padding:11px;box-shadow:0 3px 16px #0001;border-top:3px solid #c49a38;cursor:pointer}#cr_c .k small{color:#667085;font-size:11px}#cr_c .k b{display:block;font-size:24px;color:#173565;margin-top:3px}' +
    '#cr_c .cd{background:#fff;border-radius:12px;padding:13px;box-shadow:0 3px 16px #0001;margin-bottom:12px}#cr_c h4{margin:0 0 8px;color:#173565;font-size:15px}' +
    '#cr_c .fm{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px}#cr_c label{font-size:11px;color:#667085;display:block}' +
    '#cr_c input,#cr_c select,#cr_c textarea{width:100%;box-sizing:border-box;padding:7px;border:1px solid #c9d2e1;border-radius:7px;background:#fff;color:#202633;font-size:13px}#cr_c input[type=checkbox]{width:auto}' +
    '#cr_c .pb{border:0;border-radius:8px;padding:8px 12px;background:#173565;color:#fff;font-weight:bold;cursor:pointer;margin:6px 4px 0 0}#cr_c .pb.ok{background:#1f7a46}#cr_c .pb.no{background:#b3261e}#cr_c .pb.al{background:#a86b00}' +
    '#cr_c table{width:100%;border-collapse:collapse;font-size:12px}#cr_c th{background:#173565;color:#fff;text-align:left;padding:7px;font-size:11px}#cr_c td{padding:7px;border-bottom:1px solid #e2e7ef;vertical-align:top}#cr_c tr.rw{cursor:pointer}#cr_c tr.rw:hover td{background:#f3f6fb}' +
    '#cr_c .wr{background:#fff7e6;border:1px solid #e9d9a8;color:#7a5a12;border-radius:8px;padding:8px 10px;font-size:12px;margin-bottom:10px}#cr_c .er{background:#fff1f0;border:1px solid #f3b7b1;color:#7a1d16;border-radius:8px;padding:8px 10px;font-size:12px;margin-top:8px}#cr_c .mu{color:#667085;font-size:12px}#cr_c .tw{overflow:auto}' +
    '#cr_c .bd{display:inline-block;border-radius:12px;padding:2px 9px;font-size:11px;font-weight:bold;background:#dce4f0;color:#173565}#cr_c .bd.o{background:#fde9c8;color:#8a4b00}#cr_c .bd.g{background:#d8f2e1;color:#14663a}#cr_c .bd.r{background:#fbdad7;color:#8a1d16}#cr_c .bd.b{background:#d9e7ff;color:#1747a6}' +
    '#cr_c .tabs{display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap}#cr_c .tabs button{border:0;border-radius:8px;padding:9px 12px;background:#dce4f0;color:#173565;font-weight:bold;cursor:pointer}#cr_c .tabs button.on{background:#173565;color:#fff;box-shadow:inset 0 -3px #c49a38}' +
    'html[data-exb-theme="dark"] #cr_c{background:#0d1424;color:#e4e9f3}html[data-exb-theme="dark"] #cr_c .k,html[data-exb-theme="dark"] #cr_c .cd{background:#151f33;box-shadow:none}html[data-exb-theme="dark"] #cr_c .k b,html[data-exb-theme="dark"] #cr_c h4{color:#6ea8ff}' +
    'html[data-exb-theme="dark"] #cr_c input,html[data-exb-theme="dark"] #cr_c select,html[data-exb-theme="dark"] #cr_c textarea{background:#0d1424;color:#e4e9f3;border-color:#2a3a58}html[data-exb-theme="dark"] #cr_c td{border-color:#2a3a58}html[data-exb-theme="dark"] #cr_c tr.rw:hover td{background:#1b2740}' +
    'html[data-exb-theme="dark"] #cr_c .tabs button{background:#1b2740;color:#cdd8ef}html[data-exb-theme="dark"] #cr_c .tabs button.on{background:#2f6fdb;color:#fff}html[data-exb-theme="dark"] #cr_c th{background:#22314d}html[data-exb-theme="dark"] #cr_c .mu,html[data-exb-theme="dark"] #cr_c label,html[data-exb-theme="dark"] #cr_c .k small{color:#9fb0cf}' +
    'html[data-exb-theme="dark"] #cr_c .wr{background:#2b2412;border-color:#5b4a1c;color:#f0d98a}html[data-exb-theme="dark"] #cr_c .er{background:#2d1715;border-color:#6a2b26;color:#f3b7b1}html[data-exb-theme="dark"] #cr_c .bd{background:#22314d;color:#cdd8ef}';
  function css() { if (d.getElementById('cr_css')) return; var s = d.createElement('style'); s.id = 'cr_css'; s.textContent = CSS; d.head.appendChild(s); }

  /* ================= écran ================= */
  var TAB = 'accueil', SEL = null, ERR = '', AFF = 'USD', FIL = {}, PIECE = null;
  function opts(a, v, vide) { return (vide ? '<option value="">' + esc(vide) + '</option>' : '') + a.map(function (x) { return '<option' + (x === v ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join(''); }
  function badge(s) { var c = { 'À contrôler': 'o', 'En attente d’autorisation': 'o', 'Complément demandé': 'b', 'Rejetée': 'r', 'Refusée': 'r', 'Autorisée': 'g', 'Payée': 'g', 'Comptabilisée': 'g', 'Clôturée': 'g', 'Paiement partiel': 'b' }[s] || ''; return '<span class="bd ' + c + '">' + esc(s) + '</span>'; }
  function montant(x) { var nat = fmt(x.montant, x.devise); if (!x.taux_applique || AFF === x.devise) return nat; var c = convertir(x.montant, x.devise, AFF, x.taux_applique); return nat + '<br><span class="mu">≈ ' + fmt(c, AFF) + ' (taux figé ' + x.taux_applique + ')</span>'; }
  function liste() { return rdA(KD); }
  function save(x, maj) { var L = liste(), i = L.map(function (o) { return o.id; }).indexOf(x.id); if (i < 0) L.push(x); else L[i] = x; return wr(KD, L); }

  function vueAccueil() {
    var L = liste(), s = stats(L), tx = tauxAu(rdA(KT), jour()), h = '<div class="kp">' +
      '<div class="k" data-go="CTRL"><small>Demandes à contrôler</small><b>' + s.aControler + '</b></div>' +
      '<div class="k" data-go="ATT"><small>Paiements à autoriser</small><b>' + s.aAutoriser + '</b></div>' +
      '<div class="k" data-go="AUT"><small>Paiements à exécuter</small><b>' + s.aPayer + '</b></div>' +
      '<div class="k" data-go="COMP"><small>Compléments demandés</small><b>' + s.complements + '</b></div></div>' +
      '<div class="cd"><h4>En attente d’autorisation (non mélangé entre devises)</h4><b>' + fmt(s.attenteParDevise.USD, 'USD') + '</b> &nbsp;·&nbsp; <b>' + fmt(s.attenteParDevise.CDF, 'CDF') + '</b>' +
      '<div class="mu" style="margin-top:6px">' + (tx ? 'Taux en vigueur : 1 USD = ' + tx.cdf_par_usd + ' CDF (au ' + esc(tx.date) + ', ' + esc(tx.source || 'source non précisée') + ')' : '⚠ Aucun taux USD/CDF saisi : renseignez-le dans Paramètres avant de soumettre une demande.') + '</div></div>';
    var rec = filtrer(L, {}).slice(0, 8);
    h += '<div class="cd"><h4>Dernières opérations</h4><div class="tw"><table><tr><th>Référence</th><th>Service</th><th>Opération</th><th>Montant</th><th>État</th></tr>' +
      (rec.length ? rec.map(function (x) { return '<tr class="rw" data-id="' + esc(x.id) + '"><td>' + esc(x.ref || '—') + '</td><td>' + esc(x.service) + '</td><td>' + esc(x.objet) + '<br><span class="mu">' + esc(x.tiers) + '</span></td><td>' + montant(x) + '</td><td>' + badge(x.statut) + '</td></tr>'; }).join('') : '<tr><td colspan="5" class="mu">Aucune demande pour l’instant. Utilisez « Nouvelle demande ».</td></tr>') + '</table></div></div>';
    return h;
  }
  function vueListe() {
    var L = filtrer(liste(), FIL);
    var h = '<div class="cd"><div class="fm"><div><label>Recherche</label><input id="cr_q" value="' + esc(FIL.q || '') + '" placeholder="réf., tiers, pièce…"></div>' +
      '<div><label>Statut</label><select id="cr_fs">' + opts(ORDRE, FIL.statut, 'Tous') + '</select></div><div><label>Type</label><select id="cr_ft">' + opts(TYPES, FIL.type, 'Tous') + '</select></div>' +
      '<div><label>Service</label><select id="cr_fv">' + opts(SERVICES, FIL.service, 'Tous') + '</select></div></div></div>' +
      '<div class="cd"><div class="tw"><table><tr><th>Réf.</th><th>Date</th><th>Service</th><th>Opération</th><th>Montant</th><th>État</th></tr>' +
      (L.length ? L.map(function (x) { return '<tr class="rw" data-id="' + esc(x.id) + '"><td>' + esc(x.ref || '(brouillon)') + '</td><td>' + esc(x.date_piece) + '</td><td>' + esc(x.service) + '</td><td>' + esc(x.objet) + '<br><span class="mu">' + esc(x.tiers) + ' · ' + esc(x.type) + '</span></td><td>' + montant(x) + '</td><td>' + badge(x.statut) + '</td></tr>'; }).join('') : '<tr><td colspan="6" class="mu">Aucune demande ne correspond.</td></tr>') + '</table></div></div>';
    return h;
  }
  function vueDetail() {
    var x = liste().filter(function (o) { return o.id === SEL; })[0]; if (!x) { SEL = null; return vueListe(); }
    var P = params(), who = acteur(), ac = actionsPossibles(x).filter(function (a) { return peutAction(a, who, x, P).ok; }), pieces = rdO(KF)[x.id] || [];
    var h = '<div class="cd"><button class="mb pb" id="cr_back">← Retour</button><h4>' + esc(x.ref || 'Brouillon') + ' — ' + esc(x.objet) + ' ' + badge(x.statut) + '</h4>' +
      '<div class="fm"><div><label>Type</label>' + esc(x.type) + '</div><div><label>Service émetteur</label>' + esc(x.service) + '</div><div><label>Tiers</label>' + esc(x.tiers) + '</div><div><label>Chantier / projet</label>' + esc(x.chantier || '—') + '</div>' +
      '<div><label>N° de pièce</label>' + esc(x.numero_piece || '—') + '</div><div><label>Date pièce / échéance</label>' + esc(x.date_piece) + ' / ' + esc(x.echeance || '—') + '</div>' +
      '<div><label>Montant (devise native)</label><b>' + fmt(x.montant, x.devise) + '</b></div>' +
      '<div><label>Taux figé</label>' + (x.taux_applique ? '1 USD = ' + x.taux_applique + ' CDF<br><span class="mu">' + esc(x.taux_source) + ' · ' + esc(x.taux_date) + '</span>' : '—') + '</div>' +
      '<div><label>Équivalent USD / CDF (au taux figé)</label>' + (x.taux_applique ? fmt(x.montant_usd, 'USD') + '<br>' + fmt(x.montant_cdf, 'CDF') : '—') + '</div>' +
      '<div><label>Contrôlé par</label>' + esc(x.controleur || '—') + '</div><div><label>Autorisé par</label>' + esc(x.autorisateur || '—') + '</div>' +
      '<div><label>Reste à payer</label><b>' + (x.type === T_DECL ? '—' : fmt(reste(x), x.devise)) + '</b>' + (ecartChange(x) ? '<br><span class="mu">Écart de change : ' + fmt(ecartChange(x), x.devise) + ' (hors totaux)</span>' : '') + '</div></div>' +
      (x.description ? '<p class="mu">' + esc(x.description) + '</p>' : '') +
      '<div><label>Pièces jointes</label>' + (pieces.length ? pieces.map(function (p, i) { return '<a href="#" data-pj="' + i + '">📎 ' + esc(p.nom) + '</a> <span class="mu">(' + Math.round(p.taille / 1024) + ' Ko)</span>'; }).join('<br>') : '<span class="mu">Aucune pièce jointe</span>') + '</div></div>';
    if (x.statut === ST.ATT) h += '<div class="wr">' + (exigeDirection(x, P) ? '⚠ Cette demande exige l’autorisation de la Direction.' : 'Montant ≤ seuil délégué au comptable (' + fmt(P.seuil_comptable_usd, 'USD') + ').') + '</div>';
    if (ac.length) {
      h += '<div class="cd"><h4>Actions</h4>';
      if (ac.indexOf('controler') >= 0) h += '<label><input type="checkbox" id="cr_k1"> Pièce lisible et conforme</label><label><input type="checkbox" id="cr_k2"> Montant, devise et période cohérents</label><label><input type="checkbox" id="cr_k3"> Imputation (compte, chantier, centre de coût) correcte</label><label><input type="checkbox" id="cr_k4"> Aucun doublon constaté</label>';
      if (ac.some(function (a) { return MOTIF[a]; })) h += '<label>Motif (obligatoire pour compléter, rejeter, refuser ou retourner)</label><textarea id="cr_mot" rows="2"></textarea>';
      if (ac.indexOf('payer') >= 0) h += '<div class="fm"><div><label>Montant payé</label><input id="cr_pm" type="number" step="0.01" value="' + reste(x) + '"></div><div><label>Devise du paiement</label><select id="cr_pd">' + opts(DEVISES, x.devise) + '</select></div><div><label>Date</label><input id="cr_pt" type="date" value="' + jour() + '"></div><div><label>Compte / caisse</label><input id="cr_pc" placeholder="ex. Caisse USD"></div><div><label>Mode</label><select id="cr_pmo">' + opts(MODES, '') + '</select></div><div><label>Référence</label><input id="cr_pr"></div><div><label>Si devise différente : règle</label><select id="cr_pg"><option value="">—</option><option value="taux_demande">Taux figé de la demande</option><option value="taux_jour">Taux du jour de paiement</option><option value="manuel">Taux manuel</option></select></div><div><label>Taux manuel (CDF/USD)</label><input id="cr_ptm" type="number" step="0.01"></div></div>';
      if (ac.indexOf('confirmer') >= 0) h += '<div class="fm"><div><label>Compte / caisse crédité</label><input id="cr_ec"></div><div><label>Référence de transaction</label><input id="cr_er"></div><div><label>Date de réception</label><input id="cr_ed" type="date" value="' + jour() + '"></div></div><div class="mu">La confirmation n’écrit pas en caisse : le raccord Trésorerie arrive au Lot 3.</div>';
      if (ac.indexOf('comptabiliser') >= 0) h += '<label>Référence de l’écriture / pièce comptable (facultatif)</label><input id="cr_ew">';
      var BT = { soumettre: ['Soumettre', ''], controler: ['✔ Valider le contrôle', 'ok'], complement: ['Demander un complément', 'al'], rejeter: ['Rejeter', 'no'], autoriser: ['✔ Autoriser le paiement', 'ok'], refuser: ['Refuser', 'no'], retourner: ['Retourner au comptable', 'al'], payer: ['Enregistrer le paiement', 'ok'], confirmer: ['Confirmer l’encaissement', 'ok'], comptabiliser: ['Marquer comptabilisée', ''], cloturer: ['Clôturer', ''] };
      h += '<div>' + ac.map(function (a) { return '<button class="pb ' + BT[a][1] + '" data-a="' + a + '">' + BT[a][0] + '</button>'; }).join('') + '</div></div>';
    } else if (x.statut !== ST.CLO && x.statut !== ST.REJ && x.statut !== ST.REF) h += '<div class="wr">Aucune action disponible pour votre fonction à cette étape.</div>';
    h += '<div class="cd"><h4>Historique (non effaçable)</h4><div class="tw"><table><tr><th>Date</th><th>Par</th><th>Action</th><th>Statut</th><th>Motif</th></tr>' +
      (x.historique || []).slice().reverse().map(function (e) { return '<tr><td>' + esc(String(e.at).replace('T', ' ').slice(0, 16)) + '</td><td>' + esc(e.par) + ' <span class="mu">(' + esc(e.role) + ')</span></td><td>' + esc(e.action) + '</td><td>' + esc(e.de) + ' → ' + esc(e.vers) + '</td><td>' + esc(e.motif || '') + '</td></tr>'; }).join('') + '</table></div></div>';
    return h;
  }
  function vueNouvelle() {
    var tx = tauxAu(rdA(KT), jour());
    return '<div class="cd"><h4>Nouvelle demande</h4>' + (tx ? '' : '<div class="wr">Aucun taux USD/CDF défini : renseignez-le dans Paramètres.</div>') +
      '<div class="fm"><div><label>Type</label><select id="cr_t">' + opts(TYPES, '') + '</select></div><div><label>Service émetteur</label><select id="cr_s">' + opts(SERVICES, '', 'Choisir') + '</select></div>' +
      '<div><label>Tiers (client / fournisseur / employé)</label><input id="cr_ti"></div><div><label>Chantier / projet</label><input id="cr_ch"></div><div><label>N° de pièce</label><input id="cr_np"></div>' +
      '<div><label>Objet</label><input id="cr_o"></div><div><label>Montant</label><input id="cr_m" type="number" step="0.01"></div><div><label>Devise</label><select id="cr_dv">' + opts(DEVISES, 'USD') + '</select></div>' +
      '<div><label>Date de la pièce</label><input id="cr_dp" type="date" value="' + jour() + '"></div><div><label>Échéance</label><input id="cr_ec2" type="date"></div><div><label>Pièce jointe (PDF, PNG, JPEG, ≤ 400 Ko)</label><input id="cr_f" type="file" accept=".pdf,.png,.jpg,.jpeg"></div></div>' +
      '<label>Description</label><textarea id="cr_ds" rows="2"></textarea>' +
      '<button class="pb ok" id="cr_ok">Soumettre au comptable</button><button class="pb" id="cr_br">Enregistrer en brouillon</button></div>';
  }
  function vueParams() {
    var P = params(), T = rdA(KT).slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }), adm = ['admin', 'direction'].indexOf(acteur().role) >= 0, dis = adm ? '' : ' disabled';
    return '<div class="cd"><h4>Taux USD / CDF (historisé)</h4><div class="mu">Un nouveau taux s’applique aux nouvelles demandes ; les conversions déjà figées ne changent jamais.</div>' +
      '<div class="fm"><div><label>Date d’effet</label><input id="cr_xd" type="date" value="' + jour() + '"' + dis + '></div><div><label>1 USD = … CDF</label><input id="cr_xv" type="number" step="0.01"' + dis + '></div><div><label>Source</label><input id="cr_xs" placeholder="ex. Banque centrale, marché, manuel autorisé"' + dis + '></div></div>' +
      (adm ? '<button class="pb" id="cr_xa">Ajouter le taux</button>' : '<div class="mu">Réservé à la Direction et à l’administrateur.</div>') +
      '<div class="tw"><table><tr><th>Date</th><th>CDF / USD</th><th>Source</th><th>Saisi par</th></tr>' + (T.length ? T.map(function (t) { return '<tr><td>' + esc(t.date) + '</td><td>' + esc(t.cdf_par_usd) + '</td><td>' + esc(t.source) + '</td><td>' + esc(t.par) + '</td></tr>'; }).join('') : '<tr><td colspan="4" class="mu">Aucun taux.</td></tr>') + '</table></div></div>' +
      '<div class="cd"><h4>Seuils d’autorisation et habilitations</h4><div class="wr">À faire valider avec la Direction avant la mise en production. Par défaut : toute autorisation de paiement passe par la Direction.</div>' +
      '<div class="fm"><div><label><input type="checkbox" id="cr_pdl"' + (P.delegation_comptable ? ' checked' : '') + dis + '> Déléguer l’autorisation des petits montants au comptable</label></div>' +
      '<div><label>Seuil délégué au comptable (USD, inclus)</label><input id="cr_ps" type="number" step="0.01" value="' + P.seuil_comptable_usd + '"' + dis + '></div>' +
      '<div><label><input type="checkbox" id="cr_psp"' + (P.separation_paiement ? ' checked' : '') + dis + '> Celui qui autorise ne peut pas payer</label></div>' +
      '<div><label>Personnes habilitées à payer (noms séparés par des virgules ; vide = comptable, direction, administrateur)</label><input id="cr_ph" value="' + esc((P.habilites || []).join(', ')) + '"' + dis + '></div></div>' +
      (adm ? '<button class="pb" id="cr_ps_ok">Enregistrer les paramètres</button>' : '') + '</div>';
  }
  function paint() {
    var c = d.getElementById('cr_c'); if (!c) return;
    var T = [['accueil', 'À traiter'], ['liste', 'Demandes'], ['nouvelle', 'Nouvelle demande'], ['params', 'Paramètres']];
    var body = TAB === 'accueil' ? vueAccueil() : TAB === 'liste' ? (SEL ? vueDetail() : vueListe()) : TAB === 'nouvelle' ? vueNouvelle() : vueParams();
    c.innerHTML = '<div class="eh"><div><b>📥 Centre de réception comptable</b><small>Le comptable contrôle · la Direction autorise · USD / CDF</small></div><div><button id="cr_aff">Affichage : ' + AFF + '</button> <button id="cr_x">Fermer ✕</button></div></div>' +
      '<div class="eb"><div class="tabs">' + T.map(function (t) { return '<button data-t="' + t[0] + '"' + (TAB === t[0] ? ' class="on"' : '') + '>' + t[1] + '</button>'; }).join('') + '</div>' + body + (ERR ? '<div class="er">' + ERR + '</div>' : '') + '</div>';
    bind(c);
  }
  var GO = { CTRL: ST.CTRL, ATT: ST.ATT, AUT: ST.AUT, COMP: ST.COMP };
  function g(id) { var e = d.getElementById(id); return e ? String(e.value || '').trim() : ''; }
  function ck(id) { var e = d.getElementById(id); return !!(e && e.checked); }
  function bind(c) {
    c.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { TAB = b.getAttribute('data-t'); SEL = null; ERR = ''; paint(); }; });
    var x = d.getElementById('cr_x'); if (x) x.onclick = close;
    var af = d.getElementById('cr_aff'); if (af) af.onclick = function () { AFF = AFF === 'USD' ? 'CDF' : 'USD'; paint(); };
    c.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { FIL = { statut: GO[b.getAttribute('data-go')] }; TAB = 'liste'; SEL = null; paint(); }; });
    c.querySelectorAll('tr[data-id]').forEach(function (r) { r.onclick = function () { SEL = r.getAttribute('data-id'); TAB = 'liste'; ERR = ''; paint(); }; });
    var bk = d.getElementById('cr_back'); if (bk) bk.onclick = function () { SEL = null; ERR = ''; paint(); };
    [['cr_q', 'q'], ['cr_fs', 'statut'], ['cr_ft', 'type'], ['cr_fv', 'service']].forEach(function (p) { var e = d.getElementById(p[0]); if (e) e.onchange = function () { FIL[p[1]] = e.value; paint(); }; });
    c.querySelectorAll('[data-a]').forEach(function (b) { b.onclick = function () { agir(b.getAttribute('data-a')); }; });
    c.querySelectorAll('[data-pj]').forEach(function (a) { a.onclick = function (ev) { ev.preventDefault(); var p = (rdO(KF)[SEL] || [])[+a.getAttribute('data-pj')]; if (p) { var wn = w.open(); if (wn) { wn.document.write('<iframe src="' + p.data + '" style="border:0;width:100%;height:100%"></iframe>'); } } }; });
    var f = d.getElementById('cr_f'); if (f) f.onchange = lirePiece;
    var ok = d.getElementById('cr_ok'); if (ok) ok.onclick = function () { creer(true); };
    var br = d.getElementById('cr_br'); if (br) br.onclick = function () { creer(false); };
    var xa = d.getElementById('cr_xa'); if (xa) xa.onclick = ajouterTaux;
    var ps = d.getElementById('cr_ps_ok'); if (ps) ps.onclick = savePar;
  }
  function lirePiece() {
    var f = d.getElementById('cr_f'), fi = f && f.files && f.files[0]; PIECE = null; if (!fi) return;
    if (!TYPES_PIECE[fi.type]) { ERR = 'Type de pièce refusé (PDF, PNG ou JPEG seulement).'; f.value = ''; return paint(); }
    if (fi.size > MAX_PIECE) { ERR = 'Pièce trop volumineuse (400 Ko maximum).'; f.value = ''; return paint(); }
    var fr = new FileReader(); fr.onload = function () { PIECE = { nom: nomSur(fi.name), type: fi.type, taille: fi.size, data: String(fr.result), ajoute_le: nowIso() }; }; fr.readAsDataURL(fi);
  }
  function creer(soumettre) {
    var who = acteur(); if (!peutAction('soumettre', who, {}, params()).ok) { ERR = 'Lecture seule.'; return paint(); }
    var L = liste(), x = { id: uid(), type: g('cr_t'), service: g('cr_s'), tiers: g('cr_ti'), chantier: g('cr_ch'), numero_piece: g('cr_np'), objet: g('cr_o'), montant: parseFloat(g('cr_m')), devise: g('cr_dv'), date_piece: g('cr_dp'), echeance: g('cr_ec2'), description: g('cr_ds'), statut: ST.BRO, auteur: who.nom, cree_le: nowIso(), maj_le: nowIso(), paiements: [], historique: [] };
    if (isNaN(x.montant)) x.montant = 0;
    var r;
    if (soumettre) { r = appliquer(x, 'soumettre', who, {}, { liste: L, taux: rdA(KT), params: params(), ref: prochaineRef(L, new Date().getFullYear()) }); if (!r.ok) { ERR = esc(r.err); return paint(); } x = r.demande; }
    else x.historique.push({ at: nowIso(), par: who.nom, role: who.role, action: 'brouillon', de: '', vers: ST.BRO, motif: '' });
    if (!save(x)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); }
    if (PIECE) { var F = rdO(KF); F[x.id] = [PIECE]; wr(KF, F); PIECE = null; }
    audit('DEMANDE_COMPTABLE_' + (soumettre ? 'SOUMISE' : 'BROUILLON'), (x.ref || x.id) + ' ' + x.objet); say(soumettre ? 'Demande ' + x.ref + ' transmise au comptable.' : 'Brouillon enregistré.', 'success');
    ERR = ''; SEL = x.id; TAB = 'liste'; paint();
  }
  function agir(a) {
    var L = liste(), x = L.filter(function (o) { return o.id === SEL; })[0]; if (!x) return;
    var data = { motif: g('cr_mot'), checks: { piece: ck('cr_k1'), montant: ck('cr_k2'), imputation: ck('cr_k3'), doublon: ck('cr_k4') } };
    if (a === 'payer') { data.montant = g('cr_pm'); data.devise = g('cr_pd'); data.date = g('cr_pt'); data.compte = g('cr_pc'); data.mode = g('cr_pmo'); data.reference = g('cr_pr'); data.regle = g('cr_pg'); data.taux = data.regle === 'manuel' ? parseFloat(g('cr_ptm')) : (data.regle === 'taux_jour' ? (tauxAu(rdA(KT), data.date) || {}).cdf_par_usd : 0); }
    if (a === 'confirmer') { data.compte = g('cr_ec'); data.reference = g('cr_er'); data.date = g('cr_ed'); }
    if (a === 'comptabiliser') data.ecriture_ref = g('cr_ew');
    var r = appliquer(x, a, acteur(), data, { liste: L, taux: rdA(KT), params: params(), ref: prochaineRef(L, new Date().getFullYear()) });
    if (!r.ok) { ERR = esc(r.err); return paint(); }
    if (!save(r.demande)) { ERR = 'Enregistrement impossible (stockage).'; return paint(); }
    audit('DEMANDE_COMPTABLE_' + a.toUpperCase(), r.demande.ref + ' → ' + r.demande.statut + (data.motif ? ' — ' + data.motif : '')); ERR = ''; paint();
  }
  function ajouterTaux() {
    var p = acteur(); if (['admin', 'direction'].indexOf(p.role) < 0) { ERR = 'Réservé à la Direction et à l’administrateur.'; return paint(); }
    var v = parseFloat(g('cr_xv')), dt = g('cr_xd'); if (!(v > 0) || !isoOk(dt)) { ERR = 'Taux ou date invalide.'; return paint(); }
    var T = rdA(KT); T.push({ date: dt, cdf_par_usd: v, source: g('cr_xs'), par: p.nom, saisi_le: nowIso() }); wr(KT, T); audit('TAUX_USD_CDF', dt + ' : 1 USD = ' + v + ' CDF'); ERR = ''; paint();
  }
  function savePar() {
    var p = acteur(); if (['admin', 'direction'].indexOf(p.role) < 0) { ERR = 'Réservé à la Direction et à l’administrateur.'; return paint(); }
    var s = parseFloat(g('cr_ps')); if (isNaN(s) || s < 0) { ERR = 'Seuil invalide.'; return paint(); }
    var avant = params(), n = { seuil_comptable_usd: s, delegation_comptable: ck('cr_pdl'), separation_paiement: ck('cr_psp'), habilites: g('cr_ph').split(',').map(function (z) { return z.trim(); }).filter(Boolean), valide_par_direction: p.role === 'direction' };
    wr(KP, n); audit('PARAMETRES_CENTRE_RECEPTION', JSON.stringify({ avant: avant, apres: n })); say('Paramètres enregistrés.', 'success'); ERR = ''; paint();
  }
  function close() { var o = d.getElementById('cr_ov'); if (o) o.remove(); }
  function open(tab) {
    if (acteur().role === 'lecteur' && false) return;
    close(); css(); ERR = ''; TAB = tab || 'accueil'; SEL = null;
    var o = d.createElement('div'); o.id = 'cr_ov'; o.style.cssText = 'position:fixed;inset:0;z-index:9990;background:rgba(15,23,42,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:12px';
    o.onclick = function (e) { if (e.target === o) close(); };
    o.innerHTML = '<div id="cr_c"></div>'; d.body.appendChild(o); paint();
  }
  function mount() {
    if (d.getElementById('bcr')) return;
    var a = d.getElementById('bcompta'); if (!a || !a.parentNode) return;
    var b = d.createElement('button'); b.id = 'bcr'; b.textContent = '📥 Centre de réception'; b.onclick = function () { open('accueil'); };
    a.parentNode.insertBefore(b, a.nextSibling);
  }
  function enregistrer() {
    /* registre non destructif : on AJOUTE le module et les droits, on ne remplace rien */
    try {
      if (w.EXB_MODULES && !w.EXB_MODULES.some(function (m) { return m.id === 'centreReception'; })) w.EXB_MODULES.push({ id: 'centreReception', name: 'Centre de réception comptable', area: 'Finance', icon: '📥', status: 'nouveau', deps: ['comptabilite', 'clients', 'projets', 'documents'] });
      if (w.EXB_ROLES) ['comptable', 'direction'].forEach(function (r) { var a = w.EXB_ROLES[r]; if (a && a.indexOf('*') < 0 && a.indexOf('centreReception') < 0) a.push('centreReception'); });
    } catch (e) {}
    try { w.EXBCore && w.EXBCore.modules.register({ id: 'centre-reception', name: 'Centre de réception comptable', version: '229.0.0', area: 'Finance', provides: ['compta.reception', 'compta.autorisation'] }); } catch (e) {}
  }
  function start() { mount(); enregistrer(); setInterval(function () { try { if (!d.hidden) mount(); } catch (e) {} }, 3000); }
  w.EXBCR = { open: open, pure: { r2: r2, isoOk: isoOk, tauxAu: tauxAu, convertir: convertir, figer: figer, empreinte: empreinte, doublon: doublon, valider: valider, reste: reste, exigeDirection: exigeDirection, roleActeur: roleActeur, peutAction: peutAction, actionsPossibles: actionsPossibles, appliquer: appliquer, ecartChange: ecartChange, stats: stats, prochaineRef: prochaineRef, filtrer: filtrer, nomSur: nomSur, STATUTS: ST, PARAMS_DEF: PARAMS_DEF } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
