/* Excellencia Building V229b — ACCUEIL COMPTABLE : « Vue financière consolidée » (maquette Espace comptable V229+).
 * Section AJOUTÉE dans l’accueil (#exbHome) de l’Espace Comptable, JUSTE SOUS le bandeau (qui contient l’horloge et la météo).
 * Rien n’est remplacé : bandeau, horloge, météo, chiffres clés, graphique, activité et accès rapides restent tels quels.
 * Aucune double saisie : les chiffres sont LUS dans les modules existants (exb_cash, exb_invoices, bons de commande, budgets,
 *   Pilotage projets via EXBBI) et dans le Centre de réception (exb_cr_demandes). Aucune écriture dans les données comptables.
 * Devises : vue USD ou CDF. Un montant d’une autre devise n’est converti QUE si un taux existe (exb_cr_taux, sinon Finances) ;
 *   sinon il est affiché à part (« non converti ») et jamais mélangé au total.
 * Clés créées (préférences d’affichage seulement) : exb_cr_vue_devise, exb_cr_vue_exercice.
 * Retirer : supprimer la balise <script src="exb-v229b-accueil-comptable.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBFINHOME) return;
  var KV = 'exb_cr_vue_devise', KX = 'exb_cr_vue_exercice', KT = 'exb_cr_taux', KD = 'exb_cr_demandes';
  var MOIS = ['Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'];
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function nc(c) { c = String(c || 'USD').toUpperCase(); return /^(FC|CDF)$/.test(c) ? 'CDF' : c; }
  function store() { try { return typeof exbStorage !== 'undefined' ? exbStorage : (w.exbStorage || null); } catch (e) { return null; } }
  function raw(k) { var S = store(); try { return S ? S.getItem(k) : w.localStorage.getItem(k); } catch (e) { return null; } }
  function rdA(k) { try { var v = JSON.parse(raw(k) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function pref(k, df) { try { var v = w.localStorage.getItem(k); return v == null ? df : v; } catch (e) { return df; } }
  function setPref(k, v) { try { w.localStorage.setItem(k, v); } catch (e) {} }
  function isoJour(dt) { dt = dt || new Date(); return dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2) + '-' + ('0' + dt.getDate()).slice(-2); }
  function numfr(n, dec) { return Number(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: dec || 0, maximumFractionDigits: dec || 0 }).replace(/\u202f/g, ' '); }
  function montant(n, c) { return numfr(n, c === 'CDF' ? 0 : (Math.abs(n) >= 1000 ? 0 : 2)) + ' ' + c; }
  function court(n) { var a = Math.abs(n); return a >= 1e6 ? numfr(n / 1e6, 1) + ' M' : a >= 1e3 ? numfr(n / 1e3, 0) + 'k' : numfr(n, 0); }

  /* ---------- fonctions pures (testées) ---------- */
  /* dernier taux CDF par USD connu à la date (exb_cr_taux), sinon taux de Finances ; 0 si aucun */
  function tauxCourant(tauxCr, finance, jour) {
    var t = (tauxCr || []).filter(function (x) { return x && +x.cdf_par_usd > 0 && String(x.date || '') <= jour; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    if (t.length) return { taux: +t[t.length - 1].cdf_par_usd, source: 'Paramètres · ' + t[t.length - 1].date };
    var f = (finance || []).filter(function (x) { return x && x.type === 'taux' && +x.rate > 0; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    return f.length ? { taux: +f[f.length - 1].rate, source: 'Finances · ' + f[f.length - 1].date } : { taux: 0, source: '' };
  }
  /* total dans la devise de vue ; les devises sans taux restent à part (jamais additionnées) */
  function consolider(parDevise, vue, taux) {
    var tot = 0, hors = [];
    Object.keys(parDevise || {}).forEach(function (c0) {
      var c = nc(c0), a = +parDevise[c0] || 0; if (!a) return;
      if (c === vue) tot += a;
      else if (taux > 0 && ((c === 'USD' && vue === 'CDF') || (c === 'CDF' && vue === 'USD'))) tot += c === 'USD' ? a * taux : a / taux;
      else hors.push({ c: c, a: r2(a) });
    });
    return { total: r2(tot), hors: hors };
  }
  /* solde de trésorerie par devise : entrées − sorties de la caisse existante (lecture seule) */
  function soldes(cash) {
    var s = {}; (cash || []).forEach(function (x) { if (!x || !(+x.amount > 0)) return; var c = nc(x.currency); s[c] = (s[c] || 0) + (x.type === 'out' ? -x.amount : (x.type === 'in' ? +x.amount : 0)); });
    Object.keys(s).forEach(function (c) { s[c] = r2(s[c]); }); return s;
  }
  /* 6 mois se terminant au mois courant (exercice en cours) ou en décembre (exercice passé) */
  function mois6(exercice, auj) {
    var fin = (exercice === auj.getFullYear()) ? auj.getMonth() : 11, out = [], i;
    for (i = 5; i >= 0; i--) { var dt = new Date(exercice, fin - i, 1); out.push({ k: dt.getFullYear() + '-' + ('0' + (dt.getMonth() + 1)).slice(-2), lib: MOIS[dt.getMonth()] + ' ' + dt.getFullYear(), enc: {}, dep: {} }); }
    return out;
  }
  function serie(ms, encRows, depRows, vue, taux) {
    ms.forEach(function (m) { m.enc = {}; m.dep = {}; });
    function add(rows, f) { (rows || []).forEach(function (x) { var k = String(x && x.date || '').slice(0, 7), m = ms.filter(function (y) { return y.k === k; })[0]; if (!m || !(+x.amount > 0)) return; var c = nc(x.currency || x.cur); m[f][c] = (m[f][c] || 0) + (+x.amount); }); }
    add(encRows, 'enc'); add(depRows, 'dep');
    var hors = false;
    var res = ms.map(function (m) { var e = consolider(m.enc, vue, taux), p = consolider(m.dep, vue, taux); if (e.hors.length || p.hors.length) hors = true; return { lib: m.lib, enc: e.total, dep: p.total }; });
    return { points: res, horsConversion: hors };
  }
  function pourcent(ac, bac) { return bac > 0 ? Math.round(ac / bac * 1000) / 10 : null; }
  function variation(serieVals) { var n = serieVals.length; if (n < 2 || !(serieVals[n - 2] > 0)) return null; return Math.round((serieVals[n - 1] - serieVals[n - 2]) / serieVals[n - 2] * 1000) / 10; }

  /* ---------- lecture des données existantes ---------- */
  function lire(exercice, vue) {
    var B = w.EXBBI, src = null, K = {}, PJ = null, auj = new Date(), jour = isoJour(auj);
    try { src = B && B.gather ? B.gather() : null; } catch (e) { src = null; }
    var cash = src ? src.cash : rdA('exb_cash'); try { if (w.exbCash && w.exbCash.length != null) cash = w.exbCash; } catch (e) {}
    var ledger = src ? (src.ledger || []) : [];
    var rng = { a: exercice + '-01-01', b: exercice === auj.getFullYear() ? jour : exercice + '-12-31', lab: 'Exercice ' + exercice };
    try { if (B && src) K = B.compute(src, { range: rng, pid: '', dept: '' }).kpi || {}; } catch (e) { K = {}; }
    try { if (B && src && B.computeProjets) PJ = B.computeProjets(src, {}); } catch (e) { PJ = null; }
    var T = tauxCourant(rdA(KT), rdA('exb_finance'), jour);
    var par = function (k) { var o = {}; Object.keys(K).forEach(function (c) { o[c] = K[c][k]; }); return o; };
    var ms = mois6(exercice, auj), sr = serie(ms, ledger, (cash || []).filter(function (x) { return x && x.type === 'out'; }), vue, T.taux);
    var sdTr = null; try { sdTr = w.EXBTRESO && w.EXBTRESO.soldesParDevise ? w.EXBTRESO.soldesParDevise() : null; } catch (e) { sdTr = null; }
    var tr = consolider(sdTr || soldes(cash), vue, T.taux), cr = consolider(par('creances'), vue, T.taux), de = consolider(par('dettes'), vue, T.taux);
    var tot = PJ && PJ.tot, pc = tot ? pourcent(tot.ac, tot.bac) : null;
    var dem = rdA(KD), st = (w.EXBCR && w.EXBCR.pure) ? w.EXBCR.pure.stats(dem) : { aControler: 0, aAutoriser: 0, aPayer: 0 };
    var ops = [];
    dem.slice().sort(function (a, b) { return String(b.maj_le || b.cree_le || '').localeCompare(String(a.maj_le || a.cree_le || '')); }).slice(0, 4).forEach(function (x) {
      ops.push({ ref: x.ref, src: 'Centre de réception', ic: '📥', op: (x.type || 'Demande') + (x.objet ? ' — ' + x.objet : ''), m: x.montant, c: nc(x.devise), etat: x.statut, go: 'cr' });
    });
    if (ops.length < 4 && src) {
      (src.invoices || []).filter(function (i) { return i && !i.cancel && !i.cancelled; }).forEach(function (i) {
        var t = 0; (i.lines || i.items || []).forEach(function (l) { t += (+l.q || +l.qty || 0) * (+l.pu || +l.price || 0); });
        var pd = (i.payments || []).reduce(function (a, p) { return a + (+p.amount || 0); }, 0), tt = +i.total || +i.amount || t, solde = r2(tt - pd);
        if (solde > 0.004 && ops.length < 4) ops.push({ ref: i.no || i.id || '—', src: 'Clients & créances', ic: '👥', op: 'Facture client' + (i.client ? ' — ' + i.client : ''), m: solde, c: nc(i.currency), etat: i.due && String(i.due).slice(0, 10) < jour ? 'En retard' : 'À encaisser', go: 'finances' });
      });
    }
    var nbRap = null; try { nbRap = w.EXBTRESO && w.EXBTRESO.aRapprocher ? w.EXBTRESO.aRapprocher() : null; } catch (e) { nbRap = null; }
    return { nbRap: nbRap, tr: tr, cr: cr, de: de, pc: pc, sr: sr, st: st, ops: ops, taux: T, vue: vue, exercice: exercice, srcOk: !!src,
      varEnc: variation(sr.points.map(function (p) { return p.enc; })), varDep: variation(sr.points.map(function (p) { return p.dep; })) };
  }
  function exercices() {
    var y = {}, cy = new Date().getFullYear(); y[cy] = 1;
    function add(rows, f) { (rows || []).forEach(function (x) { var s = String(x && (x[f] || x.date) || '').slice(0, 4); if (/^\d{4}$/.test(s) && +s > 2000 && +s <= cy + 1) y[s] = 1; }); }
    add(rdA('exb_invoices'), 'date'); add(rdA('exb_cash'), 'date');
    return Object.keys(y).map(Number).sort(function (a, b) { return b - a; });
  }

  /* ---------- rendu ---------- */
  function css() {
    if ($('exbFinCss')) return; var s = d.createElement('style'); s.id = 'exbFinCss';
    s.textContent = '#exbFinHome{--fa:#0f2a5c;--fb:#1f6feb;--fc:#f59e0b;--fg:#16a34a;--fv:#5b3fd0;--fbg:#fff;--ft:#1b2a41;--fm:#5b6b82;--fl:#e3e9f3;margin:14px 0;color:var(--ft)}' +
      '#exbFinHome *{box-sizing:border-box}' +
      '#exbFinHome .fh{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;justify-content:space-between;margin-bottom:12px}' +
      '#exbFinHome h2{margin:0;font-size:21px;color:var(--fa)}#exbFinHome .fs{color:var(--fm);font-size:13px;margin-top:2px}' +
      '#exbFinHome .fc{display:flex;gap:8px;align-items:center;flex-wrap:wrap}' +
      '#exbFinHome select{padding:7px 10px;border:1px solid var(--fl);border-radius:8px;background:var(--fbg);color:var(--ft);font-size:14px}' +
      '#exbFinHome .tg{display:inline-flex;border:1px solid var(--fl);border-radius:9px;overflow:hidden}#exbFinHome .tg button{border:0;background:var(--fbg);color:var(--ft);padding:7px 14px;font-weight:700;cursor:pointer}#exbFinHome .tg button.on{background:var(--fa);color:#fff}' +
      '#exbFinHome .ok{background:#e6f6ec;color:#146c2e;border-radius:999px;padding:5px 12px;font-size:12.5px;font-weight:700}' +
      '#exbFinHome .kg{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}' +
      '#exbFinHome .k{background:var(--fbg);border:1px solid var(--fl);border-radius:14px;padding:14px;display:flex;gap:12px;align-items:center;box-shadow:0 1px 3px rgba(15,42,92,.06)}' +
      '#exbFinHome .k i{font-style:normal;width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;color:#fff;flex:none}' +
      '#exbFinHome .k small{display:block;color:var(--fm);font-size:12.5px}#exbFinHome .k b{display:block;font-size:21px;line-height:1.2;color:var(--ft)}#exbFinHome .k em{font-style:normal;font-size:12px;color:var(--fm)}#exbFinHome .up{color:#16a34a}#exbFinHome .dn{color:#d92d20}' +
      '#exbFinHome .bar{height:8px;background:#e8edf6;border-radius:6px;margin-top:6px;overflow:hidden}#exbFinHome .bar span{display:block;height:100%;background:var(--fb)}' +
      '#exbFinHome .g2{display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr);gap:12px;margin-top:12px}' +
      '#exbFinHome .cd{background:var(--fbg);border:1px solid var(--fl);border-radius:14px;padding:14px;overflow:hidden}#exbFinHome .cd h3{margin:0 0 8px;font-size:16px;color:var(--fa)}' +
      '#exbFinHome .lg{display:flex;gap:14px;justify-content:center;font-size:12.5px;color:var(--fm)}#exbFinHome .lg i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px}' +
      '#exbFinHome .tt{background:var(--fa);color:#fff;margin:-14px -14px 8px;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;font-weight:700}#exbFinHome .tt a{color:#fff;font-size:13px;cursor:pointer;text-decoration:none}' +
      '#exbFinHome .td{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--fl);cursor:pointer}#exbFinHome .td:last-child{border:0}#exbFinHome .td .n{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;flex:none}#exbFinHome .td span{flex:1}' +
      '#exbFinHome .tw{overflow-x:auto}#exbFinHome table{width:100%;border-collapse:collapse;font-size:13.5px}#exbFinHome th{text-align:left;color:var(--fm);font-weight:700;padding:8px 6px;border-bottom:1px solid var(--fl);white-space:nowrap}#exbFinHome td{padding:9px 6px;border-bottom:1px solid var(--fl);vertical-align:middle}' +
      '#exbFinHome .pl{display:inline-block;border-radius:999px;padding:3px 10px;font-size:12px;font-weight:700;background:#e8edf6;color:#2a3a58;white-space:nowrap}#exbFinHome .pl.w{background:#fdecc8;color:#8a5200}#exbFinHome .pl.b{background:#dbeafe;color:#1d4ed8}#exbFinHome .pl.v{background:#dcfce7;color:#166534}#exbFinHome .pl.r{background:#fee4e2;color:#b42318}' +
      '#exbFinHome .bt{background:var(--fa);color:#fff;border:0;border-radius:6px;padding:6px 14px;font-weight:700;cursor:pointer}' +
      '#exbFinHome .nt{margin-top:10px;font-size:12.5px;color:#8a5200;background:#fff7e0;border:1px solid #f1d98a;border-radius:8px;padding:8px 10px}#exbFinHome .mu{color:var(--fm);font-size:12.5px}' +
      '@media(max-width:1100px){#exbFinHome .kg{grid-template-columns:repeat(2,minmax(0,1fr))}#exbFinHome .g2{grid-template-columns:minmax(0,1fr)}}' +
      '@media(max-width:560px){#exbFinHome .kg{grid-template-columns:minmax(0,1fr)}#exbFinHome h2{font-size:18px}}' +
      'html[data-exb-theme="dark"] #exbFinHome{--fa:#8fb6ff;--fbg:#151f33;--ft:#e4e9f3;--fm:#9fb0cf;--fl:#2a3a58}html[data-exb-theme="dark"] #exbFinHome .tg button.on{background:#2f6fdb}html[data-exb-theme="dark"] #exbFinHome .tt{background:#22314d}html[data-exb-theme="dark"] #exbFinHome .bt{background:#2f6fdb}html[data-exb-theme="dark"] #exbFinHome .bar{background:#22314d}' +
      '@media print{#exbFinHome{display:none}}';
    d.head.appendChild(s);
  }
  function carte(ic, bg, lib, val, note, extra) { return '<div class="k"><i style="background:' + bg + '">' + ic + '</i><div style="flex:1;min-width:0"><small>' + lib + '</small><b>' + val + '</b>' + (note || '') + (extra || '') + '</div></div>'; }
  function varHtml(v, invers) { if (v == null) return '<em>Pas de comparaison disponible</em>'; var bon = invers ? v <= 0 : v >= 0; return '<em><span class="' + (bon ? 'up' : 'dn') + '">' + (v >= 0 ? '▲ +' : '▼ ') + numfr(v, 1) + ' %</span> vs mois précédent</em>'; }
  function horsHtml(h) { return h.length ? '<em style="display:block;color:#8a5200">+ non converti : ' + h.map(function (x) { return esc(montant(x.a, x.c)); }).join(', ') + '</em>' : ''; }
  function graphique(sr, vue) {
    var P = sr.points, W = 640, H = 230, mx = 1; P.forEach(function (p) { mx = Math.max(mx, p.enc, p.dep); });
    var top = 20, base = H - 34, hh = base - top, bw = (W - 50) / P.length, g = '', i, tk = 4;
    for (i = 0; i <= tk; i++) { var y = base - hh * i / tk; g += '<line x1="46" y1="' + y.toFixed(1) + '" x2="' + W + '" y2="' + y.toFixed(1) + '" stroke="currentColor" opacity=".12"/><text x="40" y="' + (y + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="currentColor" opacity=".7">' + court(mx * i / tk) + '</text>'; }
    P.forEach(function (p, j) {
      var x = 50 + j * bw, w1 = bw * .3, h1 = p.enc / mx * hh, h2 = p.dep / mx * hh, cx = x + bw / 2;
      g += '<rect x="' + (cx - w1 - 2).toFixed(1) + '" y="' + (base - h1).toFixed(1) + '" width="' + w1.toFixed(1) + '" height="' + h1.toFixed(1) + '" rx="2" fill="#1f6feb"><title>' + esc(p.lib + ' — encaissements : ' + montant(p.enc, vue)) + '</title></rect>' +
        '<rect x="' + (cx + 2).toFixed(1) + '" y="' + (base - h2).toFixed(1) + '" width="' + w1.toFixed(1) + '" height="' + h2.toFixed(1) + '" rx="2" fill="#f59e0b"><title>' + esc(p.lib + ' — décaissements : ' + montant(p.dep, vue)) + '</title></rect>' +
        (p.enc ? '<text x="' + (cx - w1 / 2 - 2).toFixed(1) + '" y="' + (base - h1 - 4).toFixed(1) + '" text-anchor="middle" font-size="10" fill="currentColor">' + court(p.enc) + '</text>' : '') +
        (p.dep ? '<text x="' + (cx + w1 / 2 + 2).toFixed(1) + '" y="' + (base - h2 - 4).toFixed(1) + '" text-anchor="middle" font-size="10" fill="currentColor">' + court(p.dep) + '</text>' : '') +
        '<text x="' + cx.toFixed(1) + '" y="' + (H - 12) + '" text-anchor="middle" font-size="11" fill="currentColor" opacity=".75">' + esc(p.lib.replace(/\s\d{4}$/, '')) + '</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Encaissements et décaissements sur 6 mois" style="max-width:100%;color:inherit">' + g + '</svg>';
  }
  function badge(etat) { var e = String(etat || ''); var c = /contr|attente d|vérif/i.test(e) ? 'w' : /retard|rejet|refus/i.test(e) ? 'r' : /encaiss|autoris|pay|compt|clôt/i.test(e) ? 'v' : 'b'; return '<span class="pl ' + c + '">' + esc(e) + '</span>'; }
  function html(D, ex) {
    var v = D.vue, nonConv = !D.taux.taux, tr = D.tr, a = '';
    var cons = (D.pc != null) ? '<div class="bar"><span style="width:' + Math.min(100, D.pc) + '%"></span></div>' : '';
    a += '<div class="fh"><div><h2>Vue financière consolidée</h2><div class="fs">Les données des modules existants sont centralisées sans double saisie</div></div>' +
      '<div class="fc"><label class="mu">Exercice : <select id="fhEx">' + ex.map(function (y) { return '<option value="' + y + '"' + (y === D.exercice ? ' selected' : '') + '>' + y + '</option>'; }).join('') + '</select></label>' +
      '<div class="tg" role="group" aria-label="Devise d’affichage"><button data-fv="USD" class="' + (v === 'USD' ? 'on' : '') + '">USD</button><button data-fv="CDF" class="' + (v === 'CDF' ? 'on' : '') + '">CDF</button></div>' +
      '<span class="ok">● ' + (D.srcOk ? 'Données à jour' : 'Données partielles') + '</span></div></div>';
    a += '<div class="kg">' +
      carte('🏛️', '#0f2a5c', 'Trésorerie disponible', esc(montant(tr.total, v)), '', horsHtml(tr.hors)) +
      carte('🤝', '#16a34a', 'Créances clients', esc(montant(D.cr.total, v)), '<em>Factures émises non soldées</em>', horsHtml(D.cr.hors)) +
      carte('🚚', '#f08a24', 'Dettes fournisseurs', esc(montant(D.de.total, v)), '<em>Reçu non payé</em>', horsHtml(D.de.hors)) +
      carte('📊', '#5b3fd0', 'Budget chantiers consommé', D.pc == null ? '—' : numfr(D.pc, 1) + ' %', D.pc == null ? '<em>Aucun budget de chantier renseigné</em>' : '', cons) + '</div>';
    a += '<div class="g2"><div class="cd"><h3>📈 Encaissements / Décaissements — 6 derniers mois</h3>' +
      '<div class="lg"><span><i style="background:#1f6feb"></i>Encaissements</span><span><i style="background:#f59e0b"></i>Décaissements</span></div>' + graphique(D.sr, v) +
      (D.sr.horsConversion ? '<div class="nt">Certains montants sont dans l’autre devise et n’ont pas pu être convertis : aucun taux USD/CDF n’est défini. Saisissez-le dans le Centre de réception → Paramètres.</div>' : '') + '</div>' +
      '<div class="cd"><div class="tt"><span>✔ À traiter</span><a data-go="cr">Voir tout →</a></div>' +
      '<div class="td" data-go="cr:liste"><b class="n" style="background:#dbeafe;color:#1d4ed8">' + D.st.aControler + '</b><span>Demandes à contrôler</span>›</div>' +
      '<div class="td" data-go="cr:liste"><b class="n" style="background:#fdecc8;color:#8a5200">' + D.st.aAutoriser + '</b><span>Paiements à autoriser</span>›</div>' +
      '<div class="td" data-go="cr:liste"><b class="n" style="background:#dcfce7;color:#166534">' + D.st.aPayer + '</b><span>Paiements autorisés à exécuter</span>›</div>' +
      (D.nbRap == null ? '<div class="mu" style="margin-top:6px">Rapprochements bancaires à terminer : disponible avec le module Trésorerie.</div>' : '<div class="td" data-go="tr"><b class="n" style="background:#dcfce7;color:#166534">' + D.nbRap + '</b><span>Rapprochements à terminer</span>›</div>') + '</div></div>';
    a += '<div class="cd" style="margin-top:12px"><h3>🧾 Opérations issues des modules existants</h3>' + (D.ops.length ?
      '<div class="tw"><table><thead><tr><th>Référence</th><th>Module source</th><th>Opération</th><th>Montant</th><th>État</th><th></th></tr></thead><tbody>' +
      D.ops.map(function (o) { return '<tr><td>' + esc(o.ref) + '</td><td>' + o.ic + ' ' + esc(o.src) + '</td><td>' + esc(o.op) + '</td><td style="white-space:nowrap">' + esc(montant(+o.m || 0, o.c)) + '</td><td>' + badge(o.etat) + '</td><td><button class="bt" data-go="' + (o.go === 'cr' ? 'cr:liste' : 'fin') + '">Consulter</button></td></tr>'; }).join('') + '</tbody></table></div>'
      : '<div class="mu">Aucune opération pour le moment. Les demandes du Centre de réception et les factures clients non soldées apparaîtront ici.</div>') + '</div>';
    if (nonConv) a += '<div class="nt">Aucun taux USD/CDF n’est défini : les montants dans la devise non affichée restent à part. Un taux daté se saisit dans le Centre de réception → Paramètres.</div>';
    return a;
  }

  var last = '';
  function paint(force) {
    var box = $('exbFinHome'); if (!box) return;
    var vue = pref(KV, 'USD') === 'CDF' ? 'CDF' : 'USD', ex = exercices(), exo = parseInt(pref(KX, ''), 10); if (ex.indexOf(exo) < 0) exo = ex[0];
    var D; try { D = lire(exo, vue); } catch (e) { box.innerHTML = '<div class="cd"><h3>Vue financière consolidée</h3><div class="mu">Calcul momentanément indisponible. Les données existantes ne sont pas touchées.</div></div>'; return; }
    var h = html(D, ex); if (!force && h === last) return; last = h; box.innerHTML = h;
    box.querySelector('#fhEx').onchange = function (e) { setPref(KX, e.target.value); paint(true); };
    box.querySelectorAll('[data-fv]').forEach(function (b) { b.onclick = function () { setPref(KV, b.getAttribute('data-fv')); paint(true); }; });
    box.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { var g = b.getAttribute('data-go'); try { if (g === 'tr') w.EXBTRESO && w.EXBTRESO.open('rapp'); else if (g.indexOf('cr') === 0) w.EXBCR && w.EXBCR.open(g.split(':')[1] || 'accueil'); else if (w.EXB_SHELL && w.EXB_SHELL.openKey) w.EXB_SHELL.openKey('finances'); else if (w.show) w.show('finances'); } catch (e) {} }; });
  }
  /* L’emplacement est TOUJOURS juste après le bandeau (horloge + météo) ; l’accueil personnalisable ne le déplace pas. */
  function ancrer() {
    var home = $('exbHome'), on = false; try { on = w.localStorage.getItem('exb_espace') === 'comptable'; } catch (e) {}
    var box = $('exbFinHome');
    if (!home || !on) { if (box && box.parentNode) box.parentNode.removeChild(box); last = ''; return; }
    var hero = home.querySelector('.xh-hero'); if (!hero || hero.parentNode !== home) return;
    css();
    if (!box) { box = d.createElement('section'); box.id = 'exbFinHome'; box.className = 'no-print'; box.setAttribute('aria-label', 'Vue financière consolidée'); }
    if (hero.nextElementSibling !== box) { home.insertBefore(box, hero.nextSibling); last = ''; }
    if (home.style.display !== 'none' && !d.hidden) paint(false);
  }
  function start() { ancrer(); setInterval(function () { try { ancrer(); } catch (e) {} }, 2500); w.addEventListener('storage', function () { try { paint(true); } catch (e) {} }); }
  w.EXBFINHOME = { pure: { tauxCourant: tauxCourant, consolider: consolider, soldes: soldes, mois6: mois6, serie: serie, pourcent: pourcent, variation: variation }, refresh: function () { paint(true); } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
})(window, document);
