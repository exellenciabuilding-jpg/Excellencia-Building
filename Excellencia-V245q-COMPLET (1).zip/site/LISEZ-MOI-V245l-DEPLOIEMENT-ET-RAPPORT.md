# V245l — Déploiement avec retour arrière, et rapport de tests par profil

> **Mise à jour du 27/11/2026 — essai réel sur PostgreSQL 16 local :** `run-complet.sh` a tourné : 120 migrations chargées, 0 en échec ; test V245 48/48 ; cahier §9 46/46 (le test 11/11b a été corrigé : comptage du journal fait avant l'écriture). Les mentions « jamais lancé » ci-dessous datent d'avant cet essai. L'essai sur un vrai projet Supabase de recette reste à faire (voir `LISEZ-MOI-V245l-EXECUTER-LES-MIGRATIONS.md`). La colonne « Obtenu (base) » est remplie dans `rapport-profils-V245l-base-locale.md`.


Un seul document, deux livrables du §10 de l'étude : **(A) procédure de déploiement avec retour arrière**, **(B) rapport de tests par profil**.
Date : 27 novembre 2026. Base : V245j + V245k (menus des espaces).

## 0. État réel — à lire d'abord

| Vérifié ici | NON vérifié ici |
|---|---|
| Syntaxe JavaScript de tous les fichiers modifiés (`node --check`) | **Aucune migration n'a été exécutée** : il n'y avait pas de PostgreSQL dans cet environnement. V242 à V245m restent « non exécuté » |
| `test-v242-scenarios.js` : 20 scénarios sur le modèle de la matrice, tous OK (magasinier et achats inclus) | `test-etude-s9.sql` (43 contrôles sur vraie base) est écrit mais **jamais lancé** : une erreur de syntaxe ou d'attente est possible |
| `test-circuits-s4.js` : 6 circuits valides pour le moteur, identiques entre le JS et le SQL | `run-complet.sh` modifié (restrictions confirmées, tests lancés) : **jamais lancé** |
| `check.js` : 105 contrôles OK avant et après (le script s'arrête sur le dossier `electron/`, absent du ZIP, avant et après) | Comportement réel de `wf_soumettre` / `wf_decider` avec les nouveaux types de dossier |

**Conséquence : ce lot est prêt à être essayé, pas prêt pour la production.** Le §A ci-dessous est la marche à suivre.

## 1. Contenu du lot

| Fichier | Rôle |
|---|---|
| `supabase/migration-v245l-magasinier-stock-seul.sql` | Exécute la partie B de V245d **sans condition** : le magasinier perd `engagements`, `bons_paiement`, `v92_factures_fournisseurs`, `planning_chantier`. Sauvegarde, aperçu, contrôle et retour arrière inclus. Refuse de s'exécuter si la fonction « achats » n'a pas déjà ces droits |
| `supabase/migration-v245m-circuits-interservices.sql` | Pose les **6 circuits du §4** dans `wf_circuits` de chaque organisation, sans écraser l'existant |
| `exb-workflow.js` (rév. 1.4) | Les mêmes 6 circuits côté application : posés une fois à la première ouverture par un administrateur ; bouton « circuits modèles » les ajoute aussi. 6 nouveaux types de dossier |
| `tools/test-circuits-s4.js` | Contrôle automatique JS ↔ SQL des 6 circuits |
| `tools/test-rls/test-etude-s9.sql` | Cahier §9 sur vraie base (comptes réels, `enregistrer()`, `wf_decider()`, RLS) + contrôles V245l + V245m |
| `tools/test-rls/run-complet.sh`, `ordre-migrations.txt` | Chaîne complète : ajoute v242b, v243b (restrictions), v245l, v245m ; lance les 3 fichiers de test ; code de sortie 0/1 |
| `tools/test-v242-scenarios.js` | Scénario 6b corrigé (le magasinier n'a plus les factures fournisseurs) + 6c (achats) |
| `tools/rapport-profils.js` | Génère le §B à partir de la sortie réelle des tests |
| V245k : `exb-v99r-shell.js`, `sw.js` | Menus : Ingénieur sans éditeur de plan ; Architecture sans modules du bureau d'études ; Chantier sans « Chantiers & finances ». Version du cache : `v245l-…` |

## 2. Trois choses que vous devez confirmer

1. **Les 6 circuits du §4.** Le texte de l'étude n'est pas dans les fichiers reçus. J'ai posé 3 étapes par circuit, avec des fonctions comme approbateurs. À comparer au §4 avant d'activer :
   - Projet : Ingénieur → Comptable → Directeur général
   - Paiement fournisseur : Magasinier (service fait) → Comptable → Directeur général (dès 1 000 USD)
   - Approvisionnement : Chef de projet → Comptable → Directeur général (dès 1 000 USD)
   - Personnel : Chef de projet → RH → Directeur général
   - Facturation : Conducteur → Comptable → Directeur général (dès 5 000 USD)
   - Formation : Formateur → Comptable → Directeur général
   Les seuils reprennent V245e. Une correction se fait en modifiant le tableau `INTERSERVICES` de `exb-workflow.js` **et** le SQL, puis `node tools/test-circuits-s4.js` vérifie qu'ils restent identiques.
2. **Portée du retrait au magasinier.** Vous citez planning et engagements. La partie B de V245d retire aussi `bons_paiement` (lecture) et `v92_factures_fournisseurs`. C'est cohérent avec « magasinier = colonne Stock », mais c'était l'inverse dans le modèle V242 (« Achats = magasinier »). Si l'étude lui laisse les factures fournisseurs, retirez cette collection des deux listes de V245l.
3. **Espace Achats.** Le menu `achats` de `exb-v99r-shell.js` accepte encore la fonction `magasinier`. Il garde demandes d'achat, commandes, réceptions et fournisseurs, mais plus les engagements. À arbitrer.

## A. Procédure de déploiement avec retour arrière

### A1. Deux environnements de recette, pas un
- **Base locale jetable** (PostgreSQL 14+, outil `psql`) : seule à pouvoir lancer `run-complet.sh`, car elle imite l'authentification Supabase (`stub-supabase.sql`). **Ne pointez jamais ce script vers un projet Supabase** : il supprime et recrée la base.
- **Projet Supabase de recette** (copie, jamais la production) : reçoit les mêmes migrations, puis `tests-securite-v242.sql` et la recette manuelle par profil (A3).

### A2. Essai sur la base locale
```
cd site
CONFIRMER=OUI tools/test-rls/run-complet.sh rls_complet     # état cible : restrictions appliquées
node tools/test-v242-scenarios.js && node tools/test-circuits-s4.js
node tools/rapport-profils.js /tmp/res_test-etude-s9.txt > rapport-profils.md
```
**Critère de passage : « RÉSULTAT : 0 échec(s) de test, 0 migration(s) en échec ».** Si `test-etude-s9` échoue, corrigez le test ou le code, ne contournez pas. Un échec sur les tests 1 à 4, 9c, 9d signifie qu'un droit plus large que la matrice subsiste : lisez le contrôle 3b de V242.
`CONFIRMER=NON` montre l'état sans restrictions : les tests §9 doivent alors échouer, c'est la preuve qu'ils détectent bien les droits trop larges.

### A3. Projet Supabase de recette
1. Sauvegarde du projet (Database → Backups) et noter l'heure.
2. SQL Editor, **dans l'ordre exact** de `tools/test-rls/ordre-migrations.txt`, de `schema-entreprise` jusqu'à `migration-v245m`. Un fichier à la fois, lire le résultat avant le suivant.
3. Fichiers à confirmation : dans `v242b`, `v243b`, `v244`, remplacez `'NON'` par `'OUI'` après lecture de l'aperçu. Dans `v245d`, laissez `'NON'` (la partie B est remplacée par `v245l`).
4. `supabase/tests-securite-v242.sql` : toutes les lignes `OK`.
5. Recette manuelle : un compte par profil (admin, lecteur, direction, chef de projet, conducteur, bureau d'études, architecte, formateur, comptable, RH, magasinier, achats, polyvalent). Rejouer dans l'application les scénarios du §B. `test-etude-s9.sql` peut aussi y tourner (il positionne `request.jwt.claim.sub`), mais ce n'est **pas vérifié** : il écrit dans `auth.users`.
6. Collez le résultat dans le §B (`rapport-profils.js`).

### A4. Production (seulement si A2 et A3 sont à 0 échec)
1. Annoncer une fenêtre d'une heure ; sauvegarde complète du projet. Exporter aussi : `droits_fonction`, `droits_matrice_v242`, `wf_circuits`, et la liste `select * from pg_policies where tablename = 'enregistrements'`.
2. Mêmes migrations, même ordre, mêmes confirmations qu'en A3.
3. Contrôles : `tests-securite-v242.sql` tout OK ; `select count(*) from wf_circuits where id like 'wfc_s4\_%' escape '\'` = 6 × nombre d'organisations ; le magasinier de test ne voit plus ni planning ni engagements.
4. Site : déployer l'archive V245l (le cache `sw.js` change de version, les appareils se mettent à jour seuls). Un appareil resté hors connexion garde l'ancienne version jusqu'à son prochain passage en ligne.
5. Surveiller `journal_entreprise` (actions « refus … ») pendant deux jours : un pic de refus chez un profil = droit oublié.

### A5. Retour arrière (dans l'ordre inverse de l'exécution)
| Étape annulée | Action |
|---|---|
| Site V245l | Redéployer l'archive V245j (ou V245k). Aucune donnée n'est touchée |
| V245m (circuits) | `delete from wf_circuits where id like 'wfc_s4\_%' escape '\';` — les dossiers déjà soumis gardent leur copie du circuit |
| V245l (magasinier) | Les deux `insert … select … from droits_*_sauv_v245l` en bas du fichier : rétablissent exactement les 4 droits |
| V245e (seuils) | Réexécuter `migration-v245-fonctions-export-perimetre.sql` (remet `enregistrer()` d'avant) |
| V245d partie A | `delete from droits_fonction where fonction='achats' and collection in ('engagements','bons_paiement','v93_paiements');` et idem dans `droits_matrice_v242` |
| V245c, V245 | Bloc « RETOUR ARRIÈRE » en bas de `migration-v245-fonctions-export-perimetre.sql` |
| V244 | Section 5 en bas du fichier (restaure les politiques d'écriture depuis `politiques_sauv_v244`) |
| V243b, V242b | Bloc « Retour arrière » en bas de chaque fichier (tables `droits_fonction_sauv_v243` et `_v242`) |
| Tout | Restauration de la sauvegarde complète du projet (A4.1) : seul retour garanti après un enchaînement ; les blocs ci-dessus sont les retours ciblés |

Règle : ne jamais lancer un retour arrière sans avoir relu l'en-tête du fichier concerné ; chaque bloc suppose que les migrations suivantes ont été annulées avant.

## B. Rapport de tests par profil
Section générée par `tools/rapport-profils.js`. Dans cette version, **seul le modèle est exécuté** (20 OK sur 20) ; la colonne « Obtenu (base) » reste à remplir par l'exécution de A2/A3 : relancez la commande pour la remplacer.

Modèle de la matrice (node tools/test-v242-scenarios.js) : 20 OK, 0 échec(s).

### Achats

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| M6 | achats : écrit les engagements de dépense | true | à exécuter | ⏳ |
| M7 | achats : lit les factures fournisseurs et le planning (lecture seule) | true\|false | à exécuter | ⏳ |
| C4a | soumission « paiement fournisseur » acceptée (500 USD) | true | à exécuter | ⏳ |
| C4 | sous le seuil (500 USD) : 2 étapes, la direction n'intervient pas | 2 | à exécuter | ⏳ |
| C5 | au-dessus du seuil (4 000 USD) : 3 étapes | 3 | à exécuter | ⏳ |

### Administrateur (circuits)

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| C1 | les six circuits sont présents dans l'organisation | 6 | à exécuter | ⏳ |
| C2 | couvrent les six types : projet, paiement fournisseur, approvisionnement, personnel, facturation, formation | 6 | à exécuter | ⏳ |
| C3 | réexécution de la migration : aucun doublon | 6 | à exécuter | ⏳ |

### Administrateur (matrice)

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| M8 | matrice : plus aucune des 4 collections pour le magasinier (droits_fonction ET droits_matrice_v242) | 0 | à exécuter | ⏳ |

### Administrateur (retour arrière)

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| M9 | retour arrière possible : la sauvegarde V245l existe | true | à exécuter | ⏳ |

### Architecte

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 2 | architecte : écritures comptables (caisse, engagements, paie, factures, paiements) | 0 | à exécuter | ⏳ |
| 5c | la demande n'est pas visible à l'architecte | 0 | à exécuter | ⏳ |

### Chef de projet

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 6 | l'initiateur approuve sa propre demande : refusé par wf_decider (Séparation des tâches) | Séparation | à exécuter | ⏳ |
| 6a | le chef de projet soumet une demande d'approvisionnement (circuit §4) | true | à exécuter | ⏳ |

### Chef de projet (second)

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 6c | un autre chef de projet peut approuver | true | à exécuter | ⏳ |

### Chef de projet · Conducteur · Formateur

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| C10 | les quatre autres circuits (projet, personnel, facturation, formation) acceptent une soumission | true\|true\|true\|true | à exécuter | ⏳ |

### Chef de projet → RH

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 8a | avant : le chef de projet écrit le planning chantier | true | à exécuter | ⏳ |
| 8b | après (rh) : plus d'écriture sur le planning chantier | false | à exécuter | ⏳ |
| 8c | après (rh) : écriture sur le personnel | true | à exécuter | ⏳ |

### Comptable

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 1 | comptable : éditeur de plans (lecture des plans) | 0 | à exécuter | ⏳ |
| 6b | un tiers non concerné (comptable) ne décide pas à l'étape « chef de projet » | false | à exécuter | ⏳ |
| 9c | comptable : notes de calcul inaccessibles | 0 | à exécuter | ⏳ |
| C6 | étape 1 « service fait » : le comptable ne décide pas à la place du magasinier | false | à exécuter | ⏳ |
| C8 | étape 2 « contrôle de la facture » : le comptable approuve | true | à exécuter | ⏳ |

### Conducteur

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 5 | conducteur : transmettre une demande d'achat | true | à exécuter | ⏳ |
| 11 | export refusé au conducteur (journalisé) | false\|1 | à exécuter | ⏳ |

### Direction

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 7 | direction : consulter les données globales (clients, factures, projets, stock) | 4 | à exécuter | ⏳ |
| 10 | deux utilisateurs, même fiche : le second reçoit un conflit, rien n'est écrasé | true\|1 | à exécuter | ⏳ |
| 7b | direction : valider (écrire un client) | true | à exécuter | ⏳ |
| 11b | export accepté à la direction (journalisé) | true\|1 | à exécuter | ⏳ |
| C9a | étape 3 : la direction approuve | true | à exécuter | ⏳ |
| C9 | le dossier est « valide » à la fin du circuit | valide | à exécuter | ⏳ |

### Formateur

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 4 | formateur : recettes globales (caisse, factures, paiements) | 0 | à exécuter | ⏳ |
| 9d | formateur : personnel et paie inaccessibles | 0 | à exécuter | ⏳ |

### Lecteur

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 9 | lecteur : écriture directe par l'API refusée | false | à exécuter | ⏳ |
| 9a | lecteur : écriture directe sur la table refusée | ERREUR | à exécuter | ⏳ |

### Magasinier

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 3 | magasinier : créer un paiement | false | à exécuter | ⏳ |
| 3b | magasinier : créer un bon de paiement | false | à exécuter | ⏳ |
| M1 | magasinier : ne lit plus le planning de chantier | 0 | à exécuter | ⏳ |
| M2 | magasinier : ne lit plus les engagements de dépense | 0 | à exécuter | ⏳ |
| M3 | magasinier : n'écrit plus d'engagement | false | à exécuter | ⏳ |
| M4 | magasinier : écrit toujours le stock | true | à exécuter | ⏳ |
| M5 | magasinier : conserve demandes d'achat, commandes et réceptions | true\|true\|true | à exécuter | ⏳ |
| C7 | étape 1 « service fait » : le magasinier approuve | true | à exécuter | ⏳ |

### Magasinier · Comptable · Direction

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 5b | la demande est visible aux services habilités (magasinier \| comptable \| direction) | 2\|2\|2 | à exécuter | ⏳ |

### Polyvalent

| Test | Description | Attendu | Obtenu (base) | Résultat |
|---|---|---|---|---|
| 9b | polyvalent : paie et personnel inaccessibles | 0 | à exécuter | ⏳ |

