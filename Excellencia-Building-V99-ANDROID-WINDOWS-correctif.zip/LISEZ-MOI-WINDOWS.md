# Excellencia Building — application Windows (Electron)

Même logiciel (`site/`) dans une vraie fenêtre Windows : installateur `.exe` + version portable (sans installation).

## Fabriquer le .exe
### Option A — GitHub (sans PC de développement)
1. Envoyez tout ce dossier sur votre dépôt GitHub (comme pour Android).
2. Onglet **Actions** → « Construire l'application Windows » → **Run workflow** (≈ 5 min).
3. Téléchargez l'artefact `excellencia-building-windows` : `…-nsis.exe` (installateur) et `…-portable.exe`.

### Option B — sur un PC Windows (Node 20)
```
cd electron
npm install
npm start          # lance l'application pour essai
npm run dist       # fabrique les .exe dans electron/dist
```

## À savoir
- Les données de travail restent sur la machine (IndexedDB), à l'adresse interne fixe `app://excellencia/` : elles ne changent pas d'un lancement à l'autre.
- **Les données Android et Windows sont séparées** : pour passer de l'une à l'autre, utilisez « Sauvegarde complète » puis « Restaurer ».
- Les PDF / images exportés ouvrent la fenêtre « Enregistrer sous » de Windows.
- **F11** : plein écran · **F12** : outils de diagnostic (utile si un souci apparaît ; envoyez-moi la capture de l'onglet « Console »).
- Windows SmartScreen affichera « éditeur inconnu » tant que l'exécutable n'est pas signé (certificat de signature payant) : « Informations complémentaires » → « Exécuter quand même ».
- Je n'ai pas pu lancer Electron ici (pas de réseau) : faites un premier essai et dites-moi ce qui se passe.
