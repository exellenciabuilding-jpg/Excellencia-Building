/* Catalogue de l'éditeur de plan : mobilier / équipements, points électriques, circuits.
 * Mobilier : dimensions par défaut (m) et « pièces » 3D = boîtes en fractions de (largeur, profondeur, hauteur) : [x0,y0,z0,x1,y1,z1,couleur].
 * Pour ajouter un meuble : une ligne dans FURN (cat « Cuisine » et « Sanitaire » = équipements, toujours comptés au métré). */
(function(w){'use strict';
function legs(z1,col,t){t=t||.07;return[[0,0,0,t,t,z1,col],[1-t,0,0,1,t,z1,col],[0,1-t,0,t,1,z1,col],[1-t,1-t,0,1,1,z1,col]]}
var BOIS='#a98467',BOIS2='#b08968';
var FURN=[
 {k:'lit2',n:'Lit double',e:'🛏',cat:'Chambre',w:1.6,d:2.0,h:1.0,p:[[0,0,0,1,1,.45,'#8b6b4a'],[.02,.05,.45,.98,.98,.62,'#f8fafc'],[.08,.07,.62,.46,.27,.7,'#fff'],[.54,.07,.62,.92,.27,.7,'#fff'],[0,0,.45,1,.04,1,'#8b6b4a']]},
 {k:'lit1',n:'Lit simple',e:'🛏',cat:'Chambre',w:0.9,d:2.0,h:0.9,p:[[0,0,0,1,1,.5,'#8b6b4a'],[.03,.05,.5,.97,.98,.68,'#f8fafc'],[.12,.07,.68,.88,.27,.76,'#fff'],[0,0,.5,1,.04,1,'#8b6b4a']]},
 {k:'armoire',n:'Armoire',e:'🚪',cat:'Chambre',w:1.2,d:0.6,h:2.0,p:[[0,0,0,1,1,1,BOIS],[.49,.98,0,.51,1,1,'#7c5e46']]},
 {k:'chevet',n:'Table de chevet',e:'▫',cat:'Chambre',w:0.45,d:0.4,h:0.5,p:[[0,0,0,1,1,1,BOIS]]},
 {k:'canape',n:'Canapé',e:'🛋',cat:'Salon',w:2.0,d:0.9,h:0.85,p:[[0,.25,0,1,1,.5,'#64748b'],[0,0,0,1,.25,1,'#64748b'],[0,.25,.5,.12,1,.75,'#55637a'],[.88,.25,.5,1,1,.75,'#55637a']]},
 {k:'fauteuil',n:'Fauteuil',e:'💺',cat:'Salon',w:0.85,d:0.85,h:0.85,p:[[0,.25,0,1,1,.5,'#64748b'],[0,0,0,1,.25,1,'#64748b'],[0,.25,.5,.15,1,.75,'#55637a'],[.85,.25,.5,1,1,.75,'#55637a']]},
 {k:'tablebasse',n:'Table basse',e:'▭',cat:'Salon',w:1.0,d:0.6,h:0.4,p:[[0,0,.82,1,1,1,BOIS2]].concat(legs(.82,'#7c5e46',.08))},
 {k:'tv',n:'Meuble TV',e:'📺',cat:'Salon',w:1.6,d:0.4,h:1.0,p:[[0,0,0,1,1,.45,'#475569'],[.15,.3,.45,.85,.5,1,'#111827']]},
 {k:'etagere',n:'Étagère',e:'📚',cat:'Salon',w:0.9,d:0.35,h:1.8,p:[[0,0,0,1,1,1,BOIS]]},
 {k:'table',n:'Table à manger',e:'🍽',cat:'Salle à manger',w:1.6,d:0.9,h:0.75,p:[[0,0,.93,1,1,1,BOIS2]].concat(legs(.93,'#7c5e46',.05))},
 {k:'chaise',n:'Chaise',e:'🪑',cat:'Salle à manger',w:0.45,d:0.45,h:0.9,p:[[0,0,.5,1,1,.58,BOIS],[0,0,.58,1,.1,1,BOIS]].concat(legs(.5,'#7c5e46',.1))},
 {k:'bureau',n:'Bureau',e:'🖥',cat:'Bureau',w:1.4,d:0.7,h:0.75,p:[[0,0,.92,1,1,1,BOIS2],[0,0,0,.06,1,.92,'#7c5e46'],[.94,0,0,1,1,.92,'#7c5e46']]},
 {k:'comptoir',n:'Plan de travail',e:'▬',cat:'Cuisine',w:1.2,d:0.6,h:0.9,p:[[0,0,0,1,1,.95,'#e2e8f0'],[0,0,.95,1,1,1,'#475569']]},
 {k:'evier',n:'Évier',e:'🚰',cat:'Cuisine',w:0.9,d:0.6,h:0.9,p:[[0,0,0,1,1,.95,'#e2e8f0'],[0,0,.95,1,1,1,'#475569'],[.15,.15,.98,.85,.85,1.0,'#94a3b8']]},
 {k:'cuisiniere',n:'Cuisinière',e:'🔥',cat:'Cuisine',w:0.6,d:0.6,h:0.9,p:[[0,0,0,1,1,.97,'#cbd5e1'],[.08,.08,.97,.46,.46,1,'#111827'],[.54,.08,.97,.92,.46,1,'#111827'],[.08,.54,.97,.46,.92,1,'#111827'],[.54,.54,.97,.92,.92,1,'#111827']]},
 {k:'frigo',n:'Réfrigérateur',e:'🧊',cat:'Cuisine',w:0.65,d:0.65,h:1.8,p:[[0,0,0,1,1,1,'#e5e7eb'],[0,.98,.62,1,1,.64,'#9ca3af']]},
 {k:'wc',n:'WC',e:'🚽',cat:'Sanitaire',w:0.4,d:0.7,h:0.8,p:[[0,.3,0,1,1,.5,'#f8fafc'],[.05,0,0,.95,.3,1,'#f8fafc']]},
 {k:'lavabo',n:'Lavabo',e:'🚿',cat:'Sanitaire',w:0.6,d:0.5,h:0.85,p:[[.3,.3,0,.7,.7,.8,'#f1f5f9'],[0,0,.8,1,1,1,'#f8fafc']]},
 {k:'douche',n:'Douche',e:'🚿',cat:'Sanitaire',w:0.9,d:0.9,h:0.12,p:[[0,0,0,1,1,1,'#bfdbfe']]},
 {k:'baignoire',n:'Baignoire',e:'🛁',cat:'Sanitaire',w:1.7,d:0.75,h:0.55,p:[[0,0,0,1,1,.97,'#f8fafc'],[.06,.1,.97,.94,.9,1,'#bae6fd']]},
 {k:'lavelinge',n:'Lave-linge',e:'🧺',cat:'Sanitaire',w:0.6,d:0.6,h:0.85,p:[[0,0,0,1,1,1,'#f1f5f9'],[.25,.97,.25,.75,1,.75,'#475569']]}
];
var EQUIP={Cuisine:1,Sanitaire:1};
FURN.forEach(function(f){f.equip=!!EQUIP[f.cat]});
var WALL={lit2:1,lit1:1,armoire:1,chevet:1,tv:1,etagere:1,comptoir:1,evier:1,cuisiniere:1,frigo:1,wc:1,lavabo:1,douche:1,baignoire:1,lavelinge:1,bureau:1};
FURN.forEach(function(f){f.wall=!!WALL[f.k]});

/* Points électriques : z = hauteur par défaut (m) ; null = au plafond */
var ELEC=[
 {k:'prise',n:'Prise 2P+T 16 A',s:'P',col:'#15803d',z:0.3,circ:'prises'},
 {k:'prise_pt',n:'Prise plan de travail',s:'PT',col:'#15803d',z:1.1,circ:'prises'},
 {k:'inter',n:'Interrupteur simple',s:'I',col:'#c2410c',z:1.1,circ:'eclairage'},
 {k:'va',n:'Va-et-vient',s:'V',col:'#c2410c',z:1.1,circ:'eclairage'},
 {k:'lum',n:'Point lumineux plafond',s:'☀',col:'#ca8a04',z:null,circ:'eclairage'},
 {k:'appl',n:'Applique murale',s:'A',col:'#ca8a04',z:2.0,circ:'eclairage'},
 {k:'tv',n:'Prise TV',s:'TV',col:'#0369a1',z:0.3,circ:'prises'},
 {k:'rj',n:'Prise RJ45',s:'RJ',col:'#0369a1',z:0.3,circ:'prises'},
 {k:'cuis',n:'Prise cuisinière 32 A',s:'C',col:'#b91c1c',z:0.3,circ:'cuisiniere'},
 {k:'clim',n:'Climatiseur',s:'❄',col:'#0e7490',z:2.2,circ:'clim'},
 {k:'chauffe',n:'Chauffe-eau',s:'CE',col:'#b91c1c',z:2.0,circ:'prises'},
 {k:'tab',n:'Tableau électrique',s:'TD',col:'#7f1d1d',z:1.5,circ:'tableau'}
];
var CIRC=[
 {k:'eclairage',n:'Éclairage (1,5 mm²)',col:'#ca8a04'},
 {k:'prises',n:'Prises (2,5 mm²)',col:'#15803d'},
 {k:'cuisiniere',n:'Cuisinière (6 mm²)',col:'#b91c1c'},
 {k:'clim',n:'Climatisation (4 mm²)',col:'#0e7490'},
 {k:'tableau',n:'Alimentation tableau (10 mm²)',col:'#7f1d1d'}
];
function by(a){var o={};a.forEach(function(x){o[x.k]=x});return o}
w.EXBCAT={furn:FURN,furnBy:by(FURN),elec:ELEC,elecBy:by(ELEC),circ:CIRC,circBy:by(CIRC)};
})(window);
