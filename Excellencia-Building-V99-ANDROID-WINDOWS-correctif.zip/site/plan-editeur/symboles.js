/* Symboles 2D « plan d'architecte » du mobilier. Chaque fonction dessine en vue de dessus, centrée sur (0,0),
 * largeur w et profondeur d en PIXELS ; u = pixels par mètre. Le « dos » du meuble est en haut (y négatif).
 * Le contexte g a déjà la bonne translation/rotation, et le trait (couleur, épaisseur) est réglé par l'appelant. */
(function(w){'use strict';
function rr(g,x,y,W,H,r){r=Math.max(0,Math.min(r,W/2,H/2));g.beginPath();g.moveTo(x+r,y);g.arcTo(x+W,y,x+W,y+H,r);g.arcTo(x+W,y+H,x,y+H,r);g.arcTo(x,y+H,x,y,r);g.arcTo(x,y,x+W,y,r);g.closePath()}
function body(g,W,H,r,fill){rr(g,-W/2,-H/2,W,H,r||0);g.fillStyle=fill||'#fff';g.fill();g.stroke()}
function ln(g,x1,y1,x2,y2){g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke()}
function circ(g,x,y,r,fill){g.beginPath();g.arc(x,y,Math.max(0.5,r),0,6.2832);if(fill){g.fillStyle=fill;g.fill()}g.stroke()}
function ell(g,x,y,rx,ry,fill){g.beginPath();g.ellipse(x,y,Math.max(0.5,rx),Math.max(0.5,ry),0,0,6.2832);if(fill){g.fillStyle=fill;g.fill()}g.stroke()}
function chair(g,x,y,s,dir){ /* chaise vue de dessus ; dir = direction du dossier : 0 haut, 1 droite, 2 bas, 3 gauche */
 g.save();g.translate(x,y);g.rotate(dir*Math.PI/2);rr(g,-s/2,-s/2,s,s,s*0.18);g.fillStyle='#fff';g.fill();g.stroke();rr(g,-s/2,-s/2,s,s*0.2,s*0.1);g.fillStyle='#e5e7eb';g.fill();g.stroke();g.restore()}

var S={};
S.lit=function(g,W,H,u){body(g,W,H,2);var m=Math.min(W,H)*0.04;rr(g,-W/2+m,-H/2+m,W-2*m,H-2*m,3);g.stroke();
 var n=W/u>1.2?2:1,pw=(W-2*m)/n,ph=Math.min(H*0.15,0.42*u),i;
 for(i=0;i<n;i++){rr(g,-W/2+m+i*pw+pw*0.08,-H/2+m*2,pw*0.84,ph,ph*0.3);g.fillStyle='#fff';g.fill();g.stroke()}
 var fy=-H/2+m*2+ph+H*0.1;g.beginPath();g.moveTo(-W/2+m,fy);g.lineTo(W/2-m,fy);g.stroke();
 g.beginPath();g.moveTo(-W/2+m,fy);g.lineTo(-W/2+m+W*0.16,fy+H*0.07);g.lineTo(W/2-m-W*0.16,fy+H*0.07);g.lineTo(W/2-m,fy);g.stroke()};
S.lit2=S.lit;S.lit1=S.lit;
S.armoire=function(g,W,H){body(g,W,H,0);ln(g,0,-H/2,0,H/2);ln(g,-W/2,-H/2,W/2,H/2);ln(g,W/2,-H/2,-W/2,H/2);g.fillStyle='#fff'};
S.chevet=function(g,W,H){body(g,W,H,2);circ(g,0,-H*0.05,Math.min(W,H)*0.22);ln(g,-W*0.3,H*0.3,W*0.3,H*0.3)};
S.canape=function(g,W,H,u){body(g,W,H,H*0.12);var back=H*0.26,arm=Math.min(W*0.1,0.16*u);rr(g,-W/2,-H/2,W,back,H*0.1);g.stroke();
 ln(g,-W/2+arm,-H/2+back,-W/2+arm,H/2);ln(g,W/2-arm,-H/2+back,W/2-arm,H/2);
 var n=Math.max(1,Math.round((W-2*arm)/(0.75*u))),cw=(W-2*arm)/n,i;for(i=1;i<n;i++)ln(g,-W/2+arm+i*cw,-H/2+back,-W/2+arm+i*cw,H/2)};
S.fauteuil=function(g,W,H,u){S.canape(g,W,H,u)};
S.tablebasse=function(g,W,H){body(g,W,H,H*0.12);var m=Math.min(W,H)*0.12;rr(g,-W/2+m,-H/2+m,W-2*m,H-2*m,3);g.stroke()};
S.tv=function(g,W,H){body(g,W,H,0);var m=H*0.2;g.beginPath();g.rect(-W*0.35,-H/2+m,W*0.7,H*0.25);g.fillStyle='#d1d5db';g.fill();g.stroke()};
S.etagere=function(g,W,H){body(g,W,H,0);var n=5,i;for(i=1;i<n;i++)ln(g,-W/2+W*i/n,-H/2,-W/2+W*i/n,H/2)};
S.table=function(g,W,H,u){
 var cs=Math.min(0.44*u,Math.min(W,H)*0.7),nLong=Math.max(2,Math.round(W/(0.6*u))),i,gap=nLong>0?W/nLong:0;
 for(i=0;i<nLong;i++){var x=-W/2+gap*(i+0.5);chair(g,x,-H/2-cs*0.28,cs,0);chair(g,x,H/2+cs*0.28,cs,2)}
 if(H>=0.8*u){chair(g,-W/2-cs*0.28,0,cs,3);chair(g,W/2+cs*0.28,0,cs,1)}
 body(g,W,H,H*0.06);var m=Math.min(W,H)*0.06;rr(g,-W/2+m,-H/2+m,W-2*m,H-2*m,2);g.stroke()};
S.chaise=function(g,W,H){chair(g,0,0,Math.min(W,H),0)};
S.bureau=function(g,W,H,u){body(g,W,H,0);g.beginPath();g.rect(-W*0.2,-H*0.4,W*0.4,H*0.22);g.fillStyle='#e5e7eb';g.fill();g.stroke();chair(g,0,H/2+0.25*u,0.45*u,2)};
S.comptoir=function(g,W,H){body(g,W,H,0);var m=Math.min(W,H)*0.1;g.beginPath();g.rect(-W/2+m,-H/2+m,W-2*m,H-2*m);g.stroke()};
S.evier=function(g,W,H,u){S.comptoir(g,W,H);var n=W/u>0.95?2:1,bw=(W*0.78)/n,i;
 for(i=0;i<n;i++){rr(g,-W*0.39+i*bw+bw*0.05,-H*0.25,bw*0.88,H*0.55,H*0.1);g.fillStyle='#f3f4f6';g.fill();g.stroke();circ(g,-W*0.39+i*bw+bw*0.49,H*0.02,Math.min(bw,H)*0.04)}
 circ(g,0,-H*0.36,Math.min(W,H)*0.045)};
S.cuisiniere=function(g,W,H){body(g,W,H,2);var r=Math.min(W,H)*0.15,xs=[-W*0.25,W*0.25],ys=[-H*0.25,H*0.15],i,j;
 for(i=0;i<2;i++)for(j=0;j<2;j++){circ(g,xs[i],ys[j],r);circ(g,xs[i],ys[j],r*0.5)}
 for(i=0;i<4;i++)circ(g,-W*0.3+i*W*0.2,H*0.43,Math.min(W,H)*0.03)};
S.frigo=function(g,W,H){body(g,W,H,2);var m=Math.min(W,H)*0.12;g.beginPath();g.rect(-W/2+m,-H/2+m,W-2*m,H-2*m);g.stroke();ln(g,-W*0.12,H*0.2,-W*0.12,H*0.38);ln(g,-W/2+m,-H*0.05,W/2-m,-H*0.05)};
S.wc=function(g,W,H){var th=H*0.3;rr(g,-W/2,-H/2,W,th,2);g.fillStyle='#fff';g.fill();g.stroke();
 ell(g,0,-H/2+th+(H-th)*0.5,W*0.45,(H-th)*0.5,'#fff');ell(g,0,-H/2+th+(H-th)*0.52,W*0.3,(H-th)*0.36,'#f3f4f6')};
S.lavabo=function(g,W,H){body(g,W,H,Math.min(W,H)*0.2);ell(g,0,H*0.05,W*0.36,H*0.32,'#f3f4f6');circ(g,0,-H*0.36,Math.min(W,H)*0.045);circ(g,0,H*0.05,Math.min(W,H)*0.04)};
S.douche=function(g,W,H){body(g,W,H,0);ln(g,-W/2,-H/2,W/2,H/2);circ(g,0,0,Math.min(W,H)*0.07);circ(g,-W*0.38,-H*0.38,Math.min(W,H)*0.06)};
S.baignoire=function(g,W,H){body(g,W,H,Math.min(W,H)*0.25);var m=Math.min(W,H)*0.1;rr(g,-W/2+m,-H/2+m,W-2*m,H-2*m,Math.min(W,H)*0.3);g.stroke();circ(g,W/2-m*2.2,0,Math.min(W,H)*0.05);circ(g,-W/2+m*1.8,-H*0.18,Math.min(W,H)*0.035);circ(g,-W/2+m*1.8,H*0.18,Math.min(W,H)*0.035)};
S.lavelinge=function(g,W,H){body(g,W,H,2);circ(g,0,H*0.08,Math.min(W,H)*0.32);circ(g,0,H*0.08,Math.min(W,H)*0.2);circ(g,-W*0.3,-H*0.38,Math.min(W,H)*0.04);circ(g,W*0.3,-H*0.38,Math.min(W,H)*0.04)};
w.EXBSYM={draw:function(g,k,W,H,u){var f=S[k];if(f){f(g,W,H,u);return true}body(g,W,H,0);return false},has:function(k){return !!S[k]}};
})(window);
