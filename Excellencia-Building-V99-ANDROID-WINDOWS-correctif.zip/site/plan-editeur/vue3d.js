/* Vue 3D de l'éditeur de plan — WebGL autonome (aucune bibliothèque externe, fonctionne hors connexion).
 * Reçoit une « scène » préparée par l'éditeur : { H, walls[], rooms[], furn[], elec[] } (mètres ; plan x,y -> monde X,Z ; hauteur -> Y).
 *  walls : { a,b,t,h,ops:[{pos,w,h,sill,kind}] } (mur droit avec ouvertures)  ou  { path:[[x,y]…],t,h } (mur courbe)
 *  rooms : { pts:[[x,y]…], hue }   furn : { x,y,w,d,h,rot,parts }   elec : { x,y,z,col }
 * Commandes : 1 doigt / clic gauche = tourner ; 2 doigts / clic droit / Maj = déplacer ; molette / pincement = zoom. */
(function(w){'use strict';
function hex(c){c=String(c||'#999999');if(c[0]==='#')c=c.slice(1);if(c.length===3)c=c[0]+c[0]+c[1]+c[1]+c[2]+c[2];return[parseInt(c.substr(0,2),16)/255,parseInt(c.substr(2,2),16)/255,parseInt(c.substr(4,2),16)/255]}
function hsl(h,s,l){h/=360;var a=s*Math.min(l,1-l);function f(n){var k=(n+h*12)%12;return l-a*Math.max(-1,Math.min(k-3,9-k,1))}return[f(0),f(8),f(4)]}

/* ---- géométrie : boîtes orientées autour de l'axe vertical (phi), 5 faces visibles ---- */
var YO=0;
function box(m,cx,cy,cz,sx,sy,sz,phi,col){
 if(!(sx>0&&sy>0&&sz>0))return;cy+=YO;
 var c=Math.cos(phi),s=Math.sin(phi),hx=sx/2,hy=sy/2,hz=sz/2;
 function P(lx,ly,lz){return[cx+lx*c+lz*s,cy+ly,cz-lx*s+lz*c]}
 function N(nx,ny,nz){return[nx*c+nz*s,ny,-nx*s+nz*c]}
 var F=[
  [[0,1,0],[[-hx,hy,-hz],[hx,hy,-hz],[hx,hy,hz],[-hx,hy,hz]]],
  [[1,0,0],[[hx,-hy,-hz],[hx,-hy,hz],[hx,hy,hz],[hx,hy,-hz]]],
  [[-1,0,0],[[-hx,-hy,-hz],[-hx,hy,-hz],[-hx,hy,hz],[-hx,-hy,hz]]],
  [[0,0,1],[[-hx,-hy,hz],[-hx,hy,hz],[hx,hy,hz],[hx,-hy,hz]]],
  [[0,0,-1],[[-hx,-hy,-hz],[hx,-hy,-hz],[hx,hy,-hz],[-hx,hy,-hz]]]];
 F.forEach(function(f){var n=N(f[0][0],f[0][1],f[0][2]),q=f[1].map(function(v){return P(v[0],v[1],v[2])});
  [0,1,2,0,2,3].forEach(function(i){m.push(q[i][0],q[i][1],q[i][2],n[0],n[1],n[2],col[0],col[1],col[2])})})}
function flat(m,P,i0,i1,i2,y,col){[i0,i1,i2].forEach(function(i){m.push(P[i][0],y+YO,P[i][1],0,1,0,col[0],col[1],col[2])})}
function inTri(p,a,b,c){function s(p1,p2,p3){return(p1[0]-p3[0])*(p2[1]-p3[1])-(p2[0]-p3[0])*(p1[1]-p3[1])}var d1=s(p,a,b),d2=s(p,b,c),d3=s(p,c,a);return!((d1<0||d2<0||d3<0)&&(d1>0||d2>0||d3>0))}
function earclip(P){var n=P.length,idx=[],i,A=0;for(i=0;i<n;i++)idx.push(i);
 for(i=0;i<n;i++){var a=P[i],b=P[(i+1)%n];A+=a[0]*b[1]-b[0]*a[1]}
 if(A<0)idx.reverse();var out=[],guard=0;
 while(idx.length>3&&guard++<1000){var ear=false;
  for(i=0;i<idx.length;i++){var i0=idx[(i+idx.length-1)%idx.length],i1=idx[i],i2=idx[(i+1)%idx.length],a2=P[i0],b2=P[i1],c2=P[i2];
   if((b2[0]-a2[0])*(c2[1]-a2[1])-(b2[1]-a2[1])*(c2[0]-a2[0])<=1e-12)continue;
   var ok=true;for(var j=0;j<idx.length;j++){var k=idx[j];if(k===i0||k===i1||k===i2)continue;if(inTri(P[k],a2,b2,c2)){ok=false;break}}
   if(ok){out.push([i0,i1,i2]);idx.splice(i,1);ear=true;break}}
  if(!ear)break}
 if(idx.length===3)out.push([idx[0],idx[1],idx[2]]);return out}

function tri(m,a,b,c,col,ctr){var ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2],nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,l=Math.hypot(nx,ny,nz);if(l<1e-9)return;nx/=l;ny/=l;nz/=l;
 var mx=(a[0]+b[0]+c[0])/3-ctr[0],my=(a[1]+b[1]+c[1])/3-ctr[1],mz=(a[2]+b[2]+c[2])/3-ctr[2];if(nx*mx+ny*my+nz*mz<0){nx=-nx;ny=-ny;nz=-nz}
 [a,b,c].forEach(function(v){m.push(v[0],v[1],v[2],nx,ny,nz,col[0],col[1],col[2])})}
function quad(m,a,b,c,d,col,ctr){tri(m,a,b,c,col,ctr);tri(m,a,c,d,col,ctr)}
var SLAB=hex('#cbd5e1'),ROOF=hex('#b45309'),ROOF2=hex('#9a3412');
function roofMesh(m,R){var X0=R.X0,X1=R.X1,Z0=R.Y0,Z1=R.Y1,b=R.base;
 if(R.type==='plat'){box(m,(X0+X1)/2,b+R.t/2,(Z0+Z1)/2,X1-X0,R.t,Z1-Z0,0,SLAB);return}
 var alongX=(X1-X0)>=(Z1-Z0),U0=alongX?X0:Z0,U1=alongX?X1:Z1,V0=alongX?Z0:X0,V1=alongX?Z1:X1,W=V1-V0,vc=(V0+V1)/2,h=W/2*Math.tan(R.p),top=b+h;
 function Pt(u,v,y){return alongX?[u,y,v]:[v,y,u]}
 var ctr=Pt((U0+U1)/2,vc,b+h/3),ua=R.type==='2p'?U0:U0+W/2,ub=R.type==='2p'?U1:U1-W/2;if(ub<ua){ua=ub=(U0+U1)/2}
 quad(m,Pt(U0,V0,b),Pt(U1,V0,b),Pt(ub,vc,top),Pt(ua,vc,top),ROOF,ctr);
 quad(m,Pt(U0,V1,b),Pt(U1,V1,b),Pt(ub,vc,top),Pt(ua,vc,top),ROOF,ctr);
 tri(m,Pt(U0,V0,b),Pt(U0,V1,b),Pt(ua,vc,top),ROOF2,ctr);
 tri(m,Pt(U1,V0,b),Pt(U1,V1,b),Pt(ub,vc,top),ROOF2,ctr)}
var CREME=hex('#e9e4d8'),BOISP=hex('#a16207'),VERRE=hex('#7dd3fc'),CADRE=hex('#f8fafc');
function wallPiece(m,ax,ay,ux,uy,s0,s1,y0,y1,t,col,extra){
 if(s1-s0<1e-3||y1-y0<1e-3)return;var mid=(s0+s1)/2;box(m,ax+ux*mid,(y0+y1)/2,ay+uy*mid,s1-s0+(extra||0),y1-y0,t,-Math.atan2(uy,ux),col)}

function build(S){var m=[],H=S.H||2.8,i,minx=1e9,maxx=-1e9,miny=1e9,maxy=-1e9;
 function bb(x,y){if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y}
 function addLevel(L){
 /* sols des pièces */
 (L.rooms||[]).forEach(function(r){var col=hsl(r.hue,.45,.8),T=earclip(r.pts);T.forEach(function(t){flat(m,r.pts,t[0],t[1],t[2],0.01,col)});r.pts.forEach(function(p){bb(p[0],p[1])})});
 /* murs */
 (L.walls||[]).forEach(function(wl){
  if(wl.path){for(var k=0;k<wl.path.length-1;k++){var a=wl.path[k],b=wl.path[k+1],dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy);if(L<1e-4)continue;wallPiece(m,a[0],a[1],dx/L,dy/L,0,L,0,wl.h,wl.t,CREME,Math.min(.04,wl.t*.2));bb(a[0],a[1]);bb(b[0],b[1])}return}
  var ax=wl.a[0],ay=wl.a[1],dx2=wl.b[0]-ax,dy2=wl.b[1]-ay,L2=Math.hypot(dx2,dy2);if(L2<1e-4)return;var ux=dx2/L2,uy=dy2/L2;bb(ax,ay);bb(wl.b[0],wl.b[1]);
  var EX=(wl.ext||0)/2,ops=(wl.ops||[]).slice().sort(function(p,q){return p.pos-q.pos}),cur=-EX;
  ops.forEach(function(o){var s0=Math.max(cur,o.pos-o.w/2),s1=Math.min(L2,o.pos+o.w/2),top=Math.min(wl.h,(o.sill||0)+o.h);
   wallPiece(m,ax,ay,ux,uy,cur,s0,0,wl.h,wl.t,CREME);
   if(o.sill>0.001)wallPiece(m,ax,ay,ux,uy,s0,s1,0,o.sill,wl.t,CREME);
   if(top<wl.h-0.001)wallPiece(m,ax,ay,ux,uy,s0,s1,top,wl.h,wl.t,CREME);
   var mid=(s0+s1)/2,cx=ax+ux*mid,cz=ay+uy*mid,phi=-Math.atan2(uy,ux);
   var kk=o.cont?0:1;
   if(o.kind==='porte')box(m,cx,((o.sill||0)+top)/2,cz,s1-s0-.04*kk+(o.cont?.012:0),top-(o.sill||0)-.02,.05,phi,BOISP);
   else{box(m,cx,((o.sill||0)+top)/2,cz,s1-s0-.06*kk+(o.cont?.012:0),top-(o.sill||0)-.06,.03,phi,VERRE);box(m,cx,((o.sill||0)+top)/2,cz,s1-s0,top-(o.sill||0),.015,phi,CADRE)}
   cur=Math.max(cur,s1)});
  wallPiece(m,ax,ay,ux,uy,cur,L2+EX,0,wl.h,wl.t,CREME)});
 /* mobilier */
 (L.furn||[]).forEach(function(f){var phi=-(f.rot||0)*Math.PI/180;bb(f.x,f.y);
  (f.parts||[]).forEach(function(p){var lx=((p[0]+p[3])/2-.5)*f.w,lz=((p[1]+p[4])/2-.5)*f.d,c=Math.cos(phi),s=Math.sin(phi);
   box(m,f.x+lx*c+lz*s,((p[2]+p[5])/2)*f.h+0.012,f.y-lx*s+lz*c,(p[3]-p[0])*f.w,(p[5]-p[2])*f.h,(p[4]-p[1])*f.d,phi,hex(p[6]))})});
 /* points électriques */
 (L.elec||[]).forEach(function(e){var z=e.z==null?H-.04:e.z;box(m,e.x,z,e.y,.11,.11,.11,0,hex(e.col));bb(e.x,e.y)});
 }
 (S.levels||[S]).forEach(function(L){YO=L.y0||0;addLevel(L)});YO=0;
 (S.slabs||[]).forEach(function(q){box(m,(q.x0+q.x1)/2,q.y1-q.t/2,(q.z0+q.z1)/2,q.x1-q.x0,q.t,q.z1-q.z0,0,SLAB);bb(q.x0,q.z0);bb(q.x1,q.z1)});
 if(S.roof){roofMesh(m,S.roof);bb(S.roof.X0,S.roof.Y0);bb(S.roof.X1,S.roof.Y1)}
 if(minx>maxx){minx=0;maxx=5;miny=0;maxy=5}
 /* sol général (sous le bâtiment) */
 var g=[hex('#e5e7eb'),hex('#dfe3e8')],gx=(minx+maxx)/2,gz=(miny+maxy)/2,R=Math.max(maxx-minx,maxy-miny)*2+20;
 var G=[];
 var gp=[[gx-R,gz-R],[gx+R,gz-R],[gx+R,gz+R],[gx-R,gz+R]];flat(G,gp,0,1,2,-0.02,g[0]);flat(G,gp,0,2,3,-0.02,g[0]);
 return{data:new Float32Array(G.concat(m)),bbox:[minx,maxx,miny,maxy,S.Htot||H]}}

/* ---- matrices ---- */
function persp(f,a,n,fa){var t=1/Math.tan(f/2),r=1/(n-fa);return[t/a,0,0,0,0,t,0,0,0,0,(n+fa)*r,-1,0,0,2*n*fa*r,0]}
function look(e,c,u){var zx=e[0]-c[0],zy=e[1]-c[1],zz=e[2]-c[2],l=Math.hypot(zx,zy,zz);zx/=l;zy/=l;zz/=l;
 var xx=u[1]*zz-u[2]*zy,xy=u[2]*zx-u[0]*zz,xz=u[0]*zy-u[1]*zx;l=Math.hypot(xx,xy,xz);xx/=l;xy/=l;xz/=l;
 var yx=zy*xz-zz*xy,yy=zz*xx-zx*xz,yz=zx*xy-zy*xx;
 return[xx,yx,zx,0,xy,yy,zy,0,xz,yz,zz,0,-(xx*e[0]+xy*e[1]+xz*e[2]),-(yx*e[0]+yy*e[1]+yz*e[2]),-(zx*e[0]+zy*e[1]+zz*e[2]),1]}
function mul(a,b){var o=new Array(16),i,j,k;for(i=0;i<4;i++)for(j=0;j<4;j++){var s=0;for(k=0;k<4;k++)s+=a[k*4+j]*b[i*4+k];o[i*4+j]=s}return o}

var VS='attribute vec3 p;attribute vec3 n;attribute vec3 c;uniform mat4 M;varying vec3 vc;varying float vl;void main(){gl_Position=M*vec4(p,1.0);vc=c;vec3 nn=normalize(n);vl=0.46+0.5*max(dot(nn,normalize(vec3(0.35,0.85,0.45))),0.0)+0.2*max(dot(nn,normalize(vec3(-0.6,0.25,-0.5))),0.0);}';
var FS='precision mediump float;varying vec3 vc;varying float vl;void main(){gl_FragColor=vec4(vc*vl,1.0);}';

function create(canvas){
 var gl=null;try{gl=canvas.getContext('webgl',{antialias:true})||canvas.getContext('experimental-webgl')}catch(e){}
 if(!gl)return null;
 function sh(t,s){var o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return o}
 var pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);
 if(!gl.getProgramParameter(pr,gl.LINK_STATUS))return null;
 gl.useProgram(pr);var buf=gl.createBuffer(),loc={p:gl.getAttribLocation(pr,'p'),n:gl.getAttribLocation(pr,'n'),c:gl.getAttribLocation(pr,'c'),M:gl.getUniformLocation(pr,'M')};
 var count=0,cam={az:0.7,el:0.75,dist:15,t:[2.5,1,2.5]},bbx=[0,5,0,5,2.8],ptrs={},last=null,raf=0;
 function resize(){var dp=window.devicePixelRatio||1,r=canvas.getBoundingClientRect(),W=Math.max(1,Math.round(r.width*dp)),H=Math.max(1,Math.round(r.height*dp));if(canvas.width!==W||canvas.height!==H){canvas.width=W;canvas.height=H}draw()}
 function eye(){var ce=Math.cos(cam.el);return[cam.t[0]+cam.dist*ce*Math.sin(cam.az),cam.t[1]+cam.dist*Math.sin(cam.el),cam.t[2]+cam.dist*ce*Math.cos(cam.az)]}
 function draw(){if(raf)return;raf=requestAnimationFrame(function(){raf=0;render()})}
 function render(){gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(.957,.965,.984,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);
  if(!count)return;var a=canvas.width/Math.max(1,canvas.height),M=mul(persp(0.8,a,0.1,400),look(eye(),cam.t,[0,1,0]));
  gl.uniformMatrix4fv(loc.M,false,new Float32Array(M));gl.bindBuffer(gl.ARRAY_BUFFER,buf);
  gl.enableVertexAttribArray(loc.p);gl.vertexAttribPointer(loc.p,3,gl.FLOAT,false,36,0);gl.enableVertexAttribArray(loc.n);gl.vertexAttribPointer(loc.n,3,gl.FLOAT,false,36,12);gl.enableVertexAttribArray(loc.c);gl.vertexAttribPointer(loc.c,3,gl.FLOAT,false,36,24);
  gl.drawArrays(gl.TRIANGLES,0,count)}
 function view(name){var cx=(bbx[0]+bbx[1])/2,cz=(bbx[2]+bbx[3])/2,r=Math.max(bbx[1]-bbx[0],bbx[3]-bbx[2],3);cam.t=[cx,bbx[4]/3,cz];
  if(name==='top'){cam.el=1.5;cam.az=0;cam.dist=r*1.5+2}else if(name==='face'){cam.el=0.18;cam.az=0;cam.dist=r*1.6+3}else{cam.el=0.75;cam.az=0.7;cam.dist=r*1.35+3}draw()}
 function set(S,refit){var b=build(S);count=b.data.length/9;bbx=b.bbox;gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,b.data,gl.STATIC_DRAW);if(refit)view('iso');else draw()}
 /* commandes */
 function pan(dx,dy){var k=cam.dist*0.0016,rx=Math.cos(cam.az),rz=-Math.sin(cam.az),fx=-Math.sin(cam.az),fz=-Math.cos(cam.az);cam.t[0]+=-dx*k*rx+dy*k*fx;cam.t[2]+=-dx*k*rz+dy*k*fz;draw()}
 function P(e){var r=canvas.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]}
 canvas.addEventListener('pointerdown',function(e){try{canvas.setPointerCapture(e.pointerId)}catch(_){}var p=P(e);ptrs[e.pointerId]={x:p[0],y:p[1],b:e.button,sh:e.shiftKey};last=null});
 canvas.addEventListener('pointermove',function(e){var q=ptrs[e.pointerId];if(!q)return;var p=P(e),ids=Object.keys(ptrs);
  if(ids.length>=2){var o=ptrs[ids[0]]===q?ptrs[ids[1]]:ptrs[ids[0]],d0=Math.hypot(q.x-o.x,q.y-o.y),mx0=(q.x+o.x)/2,my0=(q.y+o.y)/2;q.x=p[0];q.y=p[1];var d1=Math.hypot(q.x-o.x,q.y-o.y),mx1=(q.x+o.x)/2,my1=(q.y+o.y)/2;
   if(d0>0&&d1>0)cam.dist=Math.max(1.5,Math.min(250,cam.dist*d0/d1));pan(mx1-mx0,my1-my0);return}
  var dx=p[0]-q.x,dy=p[1]-q.y;q.x=p[0];q.y=p[1];
  if(q.b===2||q.sh)pan(dx,dy);else{cam.az-=dx*0.008;cam.el=Math.max(0.04,Math.min(1.55,cam.el+dy*0.008));draw()}});
 function up(e){delete ptrs[e.pointerId]}
 canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);canvas.addEventListener('contextmenu',function(e){e.preventDefault()});
 canvas.addEventListener('wheel',function(e){e.preventDefault();cam.dist=Math.max(1.5,Math.min(250,cam.dist*(e.deltaY>0?1.12:1/1.12)));draw()},{passive:false});
 return{set:set,view:view,resize:resize,render:render,_cam:cam}}
w.EXB3D={create:create,_earclip:earclip};
})(window);
