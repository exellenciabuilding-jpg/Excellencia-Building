# V99zzzzzzzzzzzzzzzzzzzzz — Éditeur de plan de maison 2D/3D (usage interne)

Fichiers ajoutés : `plan-editeur/index.html`, `plan-editeur/catalogue.js`, `plan-editeur/symboles.js`, `plan-editeur/vue3d.js`, `exb-plan-editeur.js`.
Fichiers modifiés : `index.html` (1 balise script), `exb-v99r-shell.js` (menu Architecture), `sw.js` (cache + hors connexion, version `plan-editeur-4`).
Pas de SQL : plans enregistrés sur l'appareil (clé `exbPlanEditeur.v1`) ; 💾 Exporter / 📂 Importer (.json) pour les partager. Aucune bibliothèque externe (2D canvas, 3D WebGL natif).

## Rendu « plan d'architecte » (V3)
- Murs pleins quasi noirs ; boutons « Mur 0,20 » et « Cloison 0,10 » dans la fiche d'un mur.
- Portes à battant avec arc d'ouverture et chambranles ; **⇋ Charnière**, **⇅ Sens d'ouverture**, **Porte double** dans la fiche. Fenêtres : châssis vitré à 3 traits dans l'épaisseur du mur.
- Mobilier dessiné en vue de dessus : lits (oreillers, drap replié), canapés, tables avec chaises, bureau, armoire, cuisinière (feux), évier, frigo, WC, lavabo, douche, baignoire, lave-linge… Les meubles « adossés » (lit, armoire, WC, lavabo, cuisine…) se collent et s'orientent seuls contre le mur le plus proche à la pose ; bouton **⇥ Coller au mur** dans la fiche.
- **⬚ Pièce : touchez l'intérieur d'un espace fermé** → la pièce est détectée avec son nom et sa **surface nette** (portes et fenêtres comptées comme fermées). Si l'espace n'est pas fermé, le tracé à la main reste possible. Noms proposés : Salon, Chambre, Douche, Couloir, Terrasse…
- Cotes extérieures automatiques (largeur × profondeur hors tout) ; bouton **📏 Cotes** : aucune / extérieures / toutes. Boutons **▦ Grille** (affichage), **🧲 Accroche** (aimantation), **🎨 Pièces** (couleurs). L'export PNG est sans grille.

## Utilisation (menu Architecture › ✏️ Plan de maison)
- **🧱 Mur** (double-touche pour finir ; revenir au départ ferme le contour) · **⌒ Arc** (départ, fin, point de l'arc ; losange pour courber un mur existant) · **🚪 Porte / 🪟 Fenêtre** (touchez un mur droit).
- **🛋 Mobilier** (22 éléments ; ajouter un meuble = 1 ligne dans `catalogue.js`, son symbole dans `symboles.js`) · **🔌 Électricité** (12 points) · **〰 Câble** (5 circuits).
- **🧊 3D** : murs avec ouvertures découpées, sols, mobilier, points électriques ; Dessus / Perspective / Face ; PNG.
- **➕ Envoyer au métré** : murs, maçonnerie, enduit/peinture, sols, plinthes, portes, fenêtres, équipements cuisine/sanitaire, points électriques, câbles par circuit (+10 %). Mobilier compté seulement si la case est cochée. Renvoyer met à jour les lignes (pas de doublon).

## Niveaux, toiture, murs courbes et piliers (V4)
- **Portes et fenêtres sur murs courbes** : posées et déplacées le long de l'arc (la position se mesure sur la longueur développée) ; courber un mur qui porte déjà des ouvertures est autorisé, elles suivent l'arc. En 3D l'ouverture est découpée dans le mur courbe.
- **Piliers et obstacles isolés** : la pièce détectée déduit les piliers entièrement entourés (surface nette et plinthes corrigées, trous visibles sur le plan).
- **Étages** : sélecteur de niveau dans la barre, bouton **＋ Étage** (copie les murs du niveau affiché) ou **Étage vide** ; le niveau du dessous apparaît en grisé et ses angles servent d'accroche. Réglages : nom du niveau, épaisseur du plancher (0,20 m par défaut). Chaque niveau garde ses propres murs, pièces, mobilier, électricité et câbles ; les quantités additionnent tous les niveaux (pièces préfixées par le nom du niveau).
- **Planchers (dalles)** : surface = rectangle englobant les murs du niveau du dessous ; volume béton = surface × épaisseur.
- **Toiture** : aucune / terrasse (dalle plate) / 2 pentes / 4 pentes, pente en degrés et débord réglables, posée sur le rectangle englobant le dernier niveau. Quantités : surface développée (surface au plan ÷ cos pente), faîtage, arêtiers, périmètre égouts + rives ; béton pour la terrasse. Vue 3D : étages, dalles et toit.
- Données enregistrées dans le plan : `levels`, `cur`, `store`, `slab`, `roof` (les anciens plans s'ouvrent sans changement).

## Limites
- Dalles et toiture calculées sur le rectangle englobant : plans en L ou en T, surfaces un peu majorées.
- Pas d'escalier ni de trémie dans les planchers ; sols plats.
- Câbles : longueur au plan +10 %, sans descentes verticales ; pas de schéma unifilaire.
- Quantités indicatives, à contrôler avant chiffrage.
- Ces limites sont aussi rappelées dans le panneau latéral de l'éditeur (« Ce qui reste limité »).
- Retirer le module : supprimer la balise `<script src="exb-plan-editeur.js">` de index.html.
