# Moteur OCR (Tesseract) — V227b
Contenu : `site/vendor/tesseract/` (tesseract.min.js, worker.min.js, 4 noyaux wasm, fra.traineddata.gz).
Installation : dézipper dans le dossier racine du logiciel (celui qui contient `site/`, `scripts/`, `electron/`), pour obtenir `site/vendor/tesseract/…`. Aucun autre fichier n'est concerné.
Il n'est jamais préchargé au démarrage ; mis en cache à la 1re utilisation (voir `sw.js`).
