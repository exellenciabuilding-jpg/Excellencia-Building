EXCELLENCIA BUILDING V81 — PILOTAGE DIRECTION + SÉCURITÉ ET SAUVEGARDES

INSTALLATION
1) Hébergez le dossier complet (cache hors ligne « exb-v81 » : les appareils se mettent à jour à la prochaine ouverture en ligne).
2) Supabase › SQL Editor : exécuter UNE fois supabase/migration-v81-securite.sql (quota de l'assistant IA). Réexécutable.
3) Si vous utilisez l'assistant IA en ligne : redéployer supabase/functions/assistant/index.ts (quota appliqué côté serveur).
   Réglage facultatif : secret ASSISTANT_DAILY_QUOTA (défaut 40 demandes/jour/utilisateur ; l'administrateur : 200).
4) Avant chaque livraison : node tools/check.js  (132 contrôles). Un échec = ne pas livrer.

NOUVEAUX BOUTONS (Administration)
· 📊 Pilotage direction — réservé aux fonctions qui lisent projets + factures + caisse.
· 🛡 Sécurité & sauvegardes.

1. PILOTAGE DIRECTION
· Tableau de bord : facturé TTC, encaissé, reste, impayés échus, dépenses, marge réelle ; tableau par chantier (budget, avancement, encaissé,
  dépenses, marge réelle, impayés) et alertes : date de fin dépassée, avancement en retard sur le calendrier (écart > 15 points),
  budget dépassé ou consommé à plus de 90 %, dépenses en avance sur le chantier, impayés échus.
· Vue consolidée des factures V61 (Chantiers & finances) + V78 (Finance USD/FC), en USD, LECTURE SEULE : rien n'est migré ni modifié.
  Conversion : taux inscrit sur chaque pièce V78 ; pour une facture V61 en FC, dernier taux du jour de la Finance. Sans taux : pièce signalée et non comptée.
· Rappels de paiement : message préparé, 📲 WhatsApp (numéro de la fiche client ; indicatif par défaut 243, modifiable : localStorage « exb_cc »)
  ou ✉ e-mail. Rien n'est envoyé automatiquement : vous vérifiez puis envoyez.
· Exports CSV (séparateur « ; », virgule décimale, UTF-8 avec BOM : s'ouvrent directement dans Excel) : synthèse projets, factures, caisse,
  pointages, situations, journal (sans photos), clients. Les cellules commençant par = + - @ sont protégées contre l'injection de formules.
· Rapport d'avancement client (impression / PDF) : avancement, période, facturé / réglé / reste, situations de travaux, 5 dernières activités,
  jusqu'à 6 photos, réserves ouvertes. Jamais de coûts ni de marges.

2. SÉCURITÉ ET SAUVEGARDES
· Clé privée administrateur : « Exporter la clé (chiffrée) » → fichier .exbkey (AES-GCM, clé dérivée du mot de passe par PBKDF2, 250 000 itérations).
  Mot de passe : 10 caractères minimum, à ne pas perdre (il n'existe aucun moyen de le récupérer). « Restaurer la clé » sur un autre appareil.
· Sauvegarde complète : toutes les données de l'appareil dans un fichier .json (ou .exbbak chiffré si un mot de passe est saisi), avec somme de contrôle SHA-256.
· Test de restauration : lit une sauvegarde, vérifie la somme de contrôle et la lisibilité de chaque jeu de données, compare avec les données actuelles.
  N'écrit RIEN. À faire régulièrement : une sauvegarde jamais testée n'est pas une sauvegarde.
· Restauration : proposée après un test réussi ; copie de sécurité téléchargée automatiquement avant ; confirmation ; réservée à l'administrateur
  quand la base partagée est active.
· Rappel : bandeau si la dernière sauvegarde a plus de 7 jours (réglable : localStorage « exb_backup_days »).
· Quota de l'assistant IA : compteur local (confort) + limite réelle côté serveur (migration SQL + fonction assistant).

CORRECTIONS
· licence-config.js : le commentaire contredisait la valeur (requireToken). Corrigé.
· tools/check.js : 56 contrôles ajoutés au total (76 → 132) : chargement V78 à V80, pilotage, chiffrement, sauvegarde, quota, devis rapide.

3. DEVIS RAPIDE = MÊME MISE EN PAGE QUE LE DEVIS MAÎTRE (V81-1)
· Devis rapide (Métré & devis › Devis rapide) : « 📄 PDF » et le nouveau « 🖨 Imprimer » utilisent maintenant le gabarit A4 du devis du métré béton armé :
  logo et en-tête société, bloc CLIENT / PROJET (coordonnées reprises de la fiche client si elle existe), tableau Désignation / Unité / Quantité / PU ($) /
  Montant ($) / Montant (FC), sous-total, TOTAL GÉNÉRAL en $ et FC, taux de change, « Fait à… le… », deux signatures, pied de page « Devis N° · Page x / y »,
  lignes jamais coupées, en-tête du tableau répété sur chaque page, totaux et signatures groupés sur la dernière page.
· Dans la liste « Devis enregistrés », chaque devis a un bouton « 📄 PDF » : pas besoin de l'ouvrir.
· Devis en CDF : les prix sont convertis en $ avec le taux du Métré (Paramètres) ou, à défaut, le dernier taux de la Finance USD / FC ; sans taux, le PDF est refusé avec un message.
· Le devis maître n'est pas modifié (ni ses données, ni son rendu) : le gabarit lit un contexte « devis rapide » uniquement le temps du rendu.
· Le logo affiché est celui réglé dans le devis maître (case « Afficher le logo »). Société, activité, e-mail, pays et validité de l'offre viennent aussi du devis maître.
· L'ancien gabarit simple est conservé en secours si le module Métré n'est pas chargé.
· Pas de SQL pour cette partie.

LIMITES CONNUES — À LIRE
· Non testé dans un navigateur ni sur un Supabase réel : seuls les calculs, le chiffrement, les sauvegardes et les exports ont été vérifiés par script.
  À valider sur le terrain : affichage sur téléphone, téléchargement des fichiers, ouverture WhatsApp / e-mail, impression du rapport, déploiement de la fonction assistant.
· La Finance n'est PAS fusionnée : V61 et V78 restent deux registres. V81 les consolide seulement pour la lecture. Les factures V78 n'ont pas d'échéance
  (jamais « en retard »). Les dépenses de la caisse sont supposées en USD, comme dans la V61.
· « Excel » = fichiers CSV ; pas de fichier .xlsx formaté.
· La sauvegarde couvre les données de CET appareil (celles que vos droits permettent de lire). Elle ne remplace pas une sauvegarde Supabase planifiée :
  activez les sauvegardes automatiques de votre projet Supabase (formules payantes) ou exportez la base régulièrement.
· Le quota local peut être contourné en vidant les données du navigateur ; seule la limite serveur fait foi.
· Les montants restent des nombres décimaux arrondis au centime (pas encore en centimes entiers).
· Photos du rapport client : seules celles stockées dans l'appareil sont reprises ; celles déjà envoyées en ligne (« sb: ») sont comptées mais non affichées.
· Devis rapide : la ligne « Divers & imprévus » n'est pas affichée à part (ajoutez-la comme ligne si besoin) ; pas de champ « note / conditions » dans le formulaire (vide dans le PDF).
· Non fait (proposé dans l'étude) : DQE / bordereau de prix, décomptes, sous-traitants, cautions, phases ACT / DET / AOR, permis, signatures, CNSS / IPR.
