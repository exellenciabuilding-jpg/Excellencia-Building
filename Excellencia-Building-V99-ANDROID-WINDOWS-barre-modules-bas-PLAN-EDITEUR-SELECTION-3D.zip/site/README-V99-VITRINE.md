# V99 — Site vitrine relié au logiciel

Onglet **🌐 Site vitrine** (menu Communication) : photos des travaux + adresses (site, logiciel, WhatsApp).

## Mise en place (une seule fois)
1. Supabase › SQL Editor : ouvrir `supabase/migration-v99-vitrine.sql`, remplacer l'e-mail par celui de votre compte administrateur, exécuter.
2. Redéployer ce logiciel sur Netlify (dossier complet).
3. Dans le logiciel : se connecter au serveur (Inscriptions › Demandes reçues), ouvrir 🌐 Site vitrine, saisir les adresses, **Enregistrer**, puis **🚀 Publier sur le site**.
4. **⬇ Site complet (ZIP)** → décompresser → déposer le dossier sur Netlify pour le site vitrine (cette fois seulement).

## Ensuite, au quotidien
Ajouter / légender / classer / supprimer des photos, changer une adresse → **Publier sur le site**. Aucun redéploiement.

## Si l'adresse Netlify change encore
Ouvrir 🌐 Site vitrine, corriger « Adresse du logiciel » (et du site), Enregistrer, Publier. Les boutons « Demander un devis » et « S'inscrire » du site suivent aussitôt.
Seule exception : si l'adresse du **site vitrine** lui-même change, rien à refaire côté site (il lit ses données dans Supabase), mais pensez à mettre à jour le lien que vous donnez aux clients.

## Limites
- Non testé contre votre Supabase : première publication à vérifier ; en cas d'erreur, le message indique la cause.
- Le site garde un `config.json` local de secours (adresse du logiciel) si Supabase est inaccessible.
- Dossier `site-vitrine/` : copie du site, utilisée pour le ZIP et comme galerie de départ.

## V99c — Pages publiques sans écran de configuration
Sur inscription.html, apprenant.html, epreuve.html et resultats.html, le visiteur ne voit plus jamais l'écran « Personnaliser » (nom, logo, couleurs, serveur).
L'identité enregistrée une fois chez vous (❓ › Personnaliser) est publiée avec « 🚀 Publier sur le site » (fichier brand.json du bucket « vitrine »).
Prérequis : renseigner l'URL et la clé PUBLIQUE (anon) Supabase dans supabase-config.js, sinon un téléphone neuf ne peut ni lire l'identité ni envoyer le formulaire.
Les liens de licence (#lic=…) ne changent pas : le client d'un logiciel loué garde son propre écran de configuration, sauf si vous remplissez « Identité de l'entreprise » dans le générateur 🔑.

## V99g — Paiement Mobile Money sur les formulaires
Onglet 🌐 Site vitrine › « 2. Paiement en ligne » : activer, devise, jusqu'à 3 numéros (M-Pesa, Airtel, Orange, Africell), montant par formulaire (apprenant, logiciel, BTP/Architecture), obligatoire ou non. Puis 🚀 Publier.
Sur inscription.html, le visiteur voit le montant et vos numéros (bouton Copier), envoie l'argent, puis saisit réseau, son numéro et la référence de la transaction.
Ces informations sont ajoutées à la note de la demande (« 💳 PAIEMENT DÉCLARÉ (à vérifier) … ») et sur la fiche PDF de l'apprenant.
Important : c'est une déclaration, pas une confirmation automatique. Vérifiez la référence dans votre relevé Mobile Money avant de valider.

## V99g — Tableau des paiements
Exécuter supabase/migration-v99g-paiements.sql. Chaque paiement déclaré est enregistré (statut « à vérifier », alerte si la référence a déjà servi).
Onglet 🌐 Site vitrine › « 4. Paiements reçus » : ✓ Confirmer / ✗ Rejeter après vérification dans votre relevé Mobile Money.
