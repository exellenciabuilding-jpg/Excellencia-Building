# TFL — Plans architecturaux (accès réservé) + esquisses

## Qui peut entrer
Seulement les étudiants qui ont un **accès au portail étudiant** (dossier accepté, matricule attribué, accès publié dans 🎓 TFL › 🔐 Portails). Ils se connectent sur `tfl-plans.html` (`/plans`) avec **le même matricule et le même mot de passe que le portail** (mot de passe de départ à changer à la première connexion, sur `/tfl-etudiant`). 5 mots de passe faux = blocage 15 minutes ; session fermée après 20 minutes d'inactivité ; mot de passe jamais gardé dans le navigateur. Page non indexée par les moteurs de recherche. **Aucune liste de plans n'est lisible sans connexion** (plus de fichier `tfl-plans.json` public).

## Ce que fait l'étudiant connecté
- **Choisir un plan** : liste filtrable (type, chambres) avec aperçu. Un seul plan à la fois ; un plan choisi disparaît de la liste des autres, et réapparaît si vous le libérez.
- **Mon plan** : fiche du plan réservé + **téléchargement du fichier**. Le fichier n'est rendu qu'à l'étudiant qui a réservé CE plan.
- **Mon esquisse** : envoi photo / capture / PDF (10 Mo). **Suivi** : statut (reçue, à corriger, validée, refusée) + votre commentaire.

## Ce que vous faites (🎓 TFL › 📐 Plans, ou `/plans-admin`)
Créer les plans (EXB-PLAN-0001…), aperçu image réduit automatiquement, choisir le **type de droits**, Publier, **🌐 Synchroniser** (connexion admin dans la page), **📎 Joindre le PDF** (4 Mo max, après la première synchronisation), libérer / attribuer / fermer, voir qui (nom + matricule) a choisi quoi, ouvrir les esquisses, décider + commenter.

## À faire UNE FOIS
1. Avoir exécuté `migration-v99zzt-tfl-portails.sql` (accès étudiants) — **obligatoire avant**.
2. Supabase › SQL Editor : exécuter `supabase/migration-v99zzzzzzzzzzzzzzzzzz-tfl-plans.sql` (réexécutable).
3. Sauvegarder puis remplacer `exb-tfl.js`, `sw.js`, `_redirects` par ceux du zip ; ajouter `tfl-plans.html`, `tfl-plans-admin.html` ; déployer.
4. Essai : un étudiant d'essai accepté avec matricule → publier son accès → plan d'essai (publié, synchronisé, PDF joint) → connexion `/plans` → choisir → télécharger ; depuis un 2ᵉ étudiant d'essai le plan ne doit plus apparaître.

## Droits d'auteur
Un plan ne se publie que si vous indiquez ses droits : dessiné par vous, autorisation écrite de l'auteur, ou licence libre. « Modern stilt house » (freecadfloorplans.com) interdit la republication en ligne : à ne pas mettre sans autorisation. L'accès réservé ne remplace pas l'autorisation.

## Limites
- SQL et pages **non testés** sur un vrai Supabase ni sur téléphone.
- Les fichiers de plans sont dans la base (base64, 4 Mo max chacun) : à surveiller si vous en mettez beaucoup. Leur garde-fou est le SQL ; ne les mettez jamais dans un dossier public du site.
- Un étudiant dont l'accès n'est pas publié, ou qui n'a pas changé son mot de passe de départ, ne peut pas entrer.
- Les colonnes `reserve_tel` / `telephone` contiennent ici le matricule.
- Pas de lien automatique plan ↔ dossier TFL (la référence du sujet est seulement enregistrée).

## Lot freecadfloorplans.com (20 plans) — BROUILLONS
`plans-import-freecadfloorplans.json` contient 20 plans (titre en français, type, chambres, niveaux, difficulté, aperçu de la 1re page). Ils sont importés **non publiés et sans droits renseignés** : la publication reste bloquée tant que vous n'avez pas l'autorisation écrite de l'auteur (conditions du site : pas de republication ni de redistribution sans accord). Les PDF gardent leur cartouche d'origine (nom de l'auteur, site) : ne la retirez pas.
1. 🎓 TFL › 📐 Plans › **📥 Importer un lot (.json)** → choisir ce fichier.
2. Connexion admin dans la page, puis **📎 Joindre plusieurs PDF** : sélectionner les PDF d'origine (ils sont reconnus par leur nom de fichier). Un PDF doublon (`…__1_.pdf`) est ignoré.
3. Quand l'autorisation écrite est reçue : ouvrir chaque plan › Modifier › droits = « Autorisation écrite de l'auteur » › enregistrer › Publier › 🌐 Synchroniser.
Plans peu adaptés au béton armé : « A-frame » et « cabane » (bois), « 27×25 » (ossature bois). Le plus adapté : « Maison R+1 4 chambres, 2 garages (25×45 ft) » (fondations, chaînages, dalle à poutrelles).

## Importer MES plans (les vôtres)
🎓 TFL › 📐 Plans › **➕ Importer mes plans** : choisir un ou plusieurs PDF ou images (JPG/PNG, plusieurs à la fois). Chaque fichier devient un plan en brouillon : titre tiré du nom du fichier, droits « dessiné par nous », aperçu fabriqué automatiquement (PDF : 1re page, nécessite Internet ; image : réduite). Le fichier reste sur l'appareil jusqu'à **🌐 Synchroniser** (connexion admin), qui l'envoie au serveur privé. Ensuite : ✏ Modifier (titre, type, chambres, niveaux, surface, description) → Publier → Synchroniser. Limite : 4 Mo par fichier (une image est réduite à 2200 px). N'importez ici que des plans dont vous êtes l'auteur ; pour ceux des autres, choisissez les droits correspondants dans ✏ Modifier.

## Convertisseur / alléger (`tfl-plans-convertir.html`, bouton 🗜 dans l'administration)
- **PDF** → chaque page est redessinée en image JPEG (résolution et qualité au choix, 12 pages max) et rangée dans un **JSON compact** ; le **PDF est reconstitué** à partir du JSON. Les tailles (original / JSON / PDF) sont affichées. ⚠ Un PDF de DAO purement vectoriel est déjà compact : redessiné en image il peut devenir PLUS lourd et moins net (les cotes fines). L'outil l'indique ; dans ce cas gardez l'original. Le gain est réel surtout pour les PDF contenant de grosses images (arbres, textures, ombres).
- **DXF** → lu en vectoriel (lignes, polylignes, cercles, arcs, textes, blocs et cotations), enregistré en JSON très léger (coordonnées entières) et ressorti en **PDF vectoriel** (net à toute échelle, noir sur blanc, tout sur une page A3). Non gérés : courbes d'arrondi des polylignes (bulge), splines, hachures, ellipses, couleurs et épaisseurs de calques.
- **DWG** : lecture impossible dans le navigateur. Enregistrer en DXF (AutoCAD › Enregistrer sous › DXF, ou ODA File Converter gratuit) puis importer le DXF.
- Un `.json` déjà converti peut être rechargé pour re-sortir le PDF. « ➕ Ajouter au catalogue » crée un brouillon prêt à synchroniser (limite 4 Mo).
- **Fonctionne SANS Internet** : le moteur de lecture des PDF (pdf.js, dossier `pdfjs/`, ≈ 1,8 Mo) est livré avec le logiciel et mémorisé par l'application. Ouvrez une fois l'application avec Internet après chaque mise à jour pour qu'elle le mémorise ; ensuite conversion, import de vos plans, aperçus et préparation du catalogue marchent hors connexion. Il faut Internet seulement pour **🌐 Synchroniser** (envoi au serveur) et pour la page étudiante `/plans` (connexion par matricule). Les fichiers préparés hors connexion restent sur l'appareil jusqu'à la synchronisation.
