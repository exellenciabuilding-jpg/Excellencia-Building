/* Excellencia Building — barre des modules en bas de l'écran (déplaçable)
 * Rôle : à l'entrée dans N'IMPORTE QUEL module (V99 : sans exception), une deuxième barre s'affiche EN BAS de l'écran :
 *   Accueil · (catégorie) · les modules de la même catégorie (Plan de maison, Plan PDF → éditeur, TP / TD…), ou le module seul s'il n'a pas de voisins.
 * Quand le module a des voisins, elle remplace la barre du haut : tout l'écran sous l'en-tête reste l'espace de travail.
 * - L'écran d'accueil et les pages de catégorie ne changent pas (la barre n'apparaît que dans un module).
 * - Détection par lecture de l'écran uniquement : aucune fonction du logiciel n'est enveloppée ni modifiée.
 * - Déplaçable comme les boutons flottants : glisser la poignée ⠿ ; position mémorisée. Double appui sur la poignée = remettre en bas.
 * - Bouton ▾ : réduit la barre en une petite pastille ; un appui la rouvre.
 * - La barre se cache pendant la saisie au clavier.
 * Aucune fonction existante n'est modifiée : le fichier lit les boutons de #exbModBar et leur transmet le clic.
 * Pour retirer : supprimer la balise <script src="exb-module-dock.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_DOCK) return;
  var KEY = 'exb_dock_v1', GAP = 8, dock = null, st = load(), drag = null, lastTap = 0, bound = false;
  function load() {
    try { var o = JSON.parse(w.localStorage.getItem(KEY) || 'null'); if (o && typeof o === 'object') return { free: !!o.free, x: +o.x || 0, y: +o.y || 0, mini: !!o.mini }; } catch (e) {}
    return { free: false, x: 0, y: 0, mini: false };
  }
  function save() { try { w.localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function css() {
    if (d.getElementById('exbDockCss')) return;
    var s = d.createElement('style'); s.id = 'exbDockCss';
    s.textContent =
      'html.exb-dock-sib #exbModBar{display:none!important}' +
      'html.exb-dock-on.exb-dock-bottom body{padding-bottom:calc(66px + env(safe-area-inset-bottom,0px))}' +
      '#exbDock{position:fixed;z-index:800;display:none;align-items:center;gap:6px;box-sizing:border-box;background:#12254a;border:1px solid #ffffff22;border-top:3px solid #c8962e;color:#fff;font-family:Arial,Helvetica,sans-serif;box-shadow:0 -4px 18px #0f2e6633;touch-action:none}' +
      '#exbDock.on{display:flex}' +
      '#exbDock.bottom{left:0;right:0;bottom:0;padding:6px 8px calc(6px + env(safe-area-inset-bottom,0px));border-radius:14px 14px 0 0}' +
      '#exbDock.free{padding:6px 8px;border-radius:14px;max-width:calc(100vw - 16px);border-top-color:#c8962e}' +
      '#exbDock.hide{display:none!important}' +
      '#exbDock .dk-grip{flex:none;width:30px;height:44px;display:flex;align-items:center;justify-content:center;color:#e3b85a;font-size:20px;cursor:grab;user-select:none;-webkit-user-select:none;touch-action:none}' +
      '#exbDock .dk-in{flex:1 1 auto;min-width:0;display:flex;gap:6px;overflow-x:auto;overflow-y:hidden;scrollbar-width:none;-webkit-overflow-scrolling:touch;touch-action:pan-x}' +
      '#exbDock .dk-in::-webkit-scrollbar{display:none}' +
      '#exbDock .dk-b{flex:none;min-height:44px;padding:0 14px;border-radius:10px;border:1px solid #ffffff55;background:transparent;color:#fff;font:700 13px Arial,sans-serif;white-space:nowrap;cursor:pointer;display:flex;align-items:center;gap:6px}' +
      '#exbDock .dk-b i{font-style:normal;font-size:16px;line-height:1}' +
      '#exbDock .dk-b.on{background:#fff;color:#12254a;border-color:#fff}' +
      '#exbDock .dk-b:focus-visible,#exbDock .dk-min:focus-visible{outline:3px solid #c8962e;outline-offset:2px}' +
      '#exbDock .dk-min{flex:none;width:36px;height:44px;border:0;border-radius:10px;background:transparent;color:#e3b85a;font-size:18px;cursor:pointer}' +
      '#exbDock.mini{padding:0;border:0;background:transparent;box-shadow:none;left:auto;right:auto}' +
      '#exbDock.mini.bottom{left:auto;right:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));border-radius:999px}' +
      '#exbDock .dk-pill{display:none;min-width:48px;height:48px;padding:0 14px;border-radius:999px;border:2px solid #c8962e;background:#12254a;color:#fff;font:700 14px Arial,sans-serif;align-items:center;gap:8px;cursor:pointer;box-shadow:0 4px 14px #0f2e6655}' +
      '#exbDock.mini .dk-pill{display:flex}#exbDock.mini .dk-grip,#exbDock.mini .dk-in,#exbDock.mini .dk-min{display:none}' +
      '@media print{#exbDock{display:none!important}}';
    d.head.appendChild(s);
  }

  function build() {
    if (dock) return dock;
    dock = d.createElement('nav'); dock.id = 'exbDock'; dock.className = 'no-print bottom'; dock.setAttribute('aria-label', 'Modules');
    dock.innerHTML = '<span class="dk-grip" role="button" aria-label="Déplacer la barre" title="Glisser pour déplacer — double appui : remettre en bas">⠿</span>' +
      '<div class="dk-in" role="tablist"></div>' +
      '<button class="dk-min" type="button" aria-label="Réduire la barre" title="Réduire">▾</button>' +
      '<button class="dk-pill" type="button" aria-label="Ouvrir la barre des modules"><span class="dk-pi">▦</span><span class="dk-pn"></span></button>';
    d.body.appendChild(dock);
    dock.querySelector('.dk-min').onclick = function () { st.mini = true; save(); place(); };
    dock.querySelector('.dk-pill').onclick = function () { if (dock.__moved) { dock.__moved = false; return; } st.mini = false; save(); place(); };
    var g = dock.querySelector('.dk-grip');
    g.addEventListener('pointerdown', down);
    dock.querySelector('.dk-pill').addEventListener('pointerdown', down);
    return dock;
  }

  /* ---------- position ---------- */
  function place() {
    if (!dock) return;
    dock.classList.toggle('mini', !!st.mini);
    dock.classList.toggle('free', !!st.free);
    dock.classList.toggle('bottom', !st.free);
    d.documentElement.classList.toggle('exb-dock-bottom', !st.free && !st.mini);
    if (st.free) {
      var vw = w.innerWidth, vh = w.innerHeight, r = dock.getBoundingClientRect();
      var x = clamp(st.x * vw, GAP, Math.max(GAP, vw - r.width - GAP)), y = clamp(st.y * vh, GAP, Math.max(GAP, vh - r.height - GAP));
      dock.style.left = x + 'px'; dock.style.top = y + 'px'; dock.style.right = 'auto'; dock.style.bottom = 'auto';
    } else { dock.style.left = dock.style.top = dock.style.right = dock.style.bottom = ''; }
  }
  function down(e) {
    if (e.button != null && e.button > 0) return;
    var t = e.currentTarget, r = dock.getBoundingClientRect();
    drag = { id: e.pointerId, dx: e.clientX - r.left, dy: e.clientY - r.top, sx: e.clientX, sy: e.clientY, moved: false, grip: t.classList.contains('dk-grip') };
    try { t.setPointerCapture(e.pointerId); } catch (x) {}
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up); t.addEventListener('pointercancel', up);
  }
  function move(e) {
    if (!drag || e.pointerId !== drag.id) return;
    if (!drag.moved && Math.abs(e.clientX - drag.sx) + Math.abs(e.clientY - drag.sy) < 6) return;
    drag.moved = true; dock.__moved = true; e.preventDefault();
    var vw = w.innerWidth, vh = w.innerHeight, r = dock.getBoundingClientRect();
    var x = clamp(e.clientX - drag.dx, GAP, Math.max(GAP, vw - r.width - GAP)), y = clamp(e.clientY - drag.dy, GAP, Math.max(GAP, vh - r.height - GAP));
    st.free = true; st.x = x / vw; st.y = y / vh;
    dock.classList.add('free'); dock.classList.remove('bottom');
    dock.style.left = x + 'px'; dock.style.top = y + 'px'; dock.style.right = 'auto'; dock.style.bottom = 'auto';
    d.documentElement.classList.remove('exb-dock-bottom');
  }
  function up(e) {
    var t = e.currentTarget;
    t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up); t.removeEventListener('pointercancel', up);
    try { t.releasePointerCapture(e.pointerId); } catch (x) {}
    var was = drag; drag = null;
    if (was && was.moved) { save(); place(); setTimeout(function () { if (dock) dock.__moved = false; }, 60); return; }
    if (was && was.grip) { var n = Date.now(); if (n - lastTap < 400) { st.free = false; save(); place(); } lastTap = n; }
  }

  /* ---------- contenu ---------- */
  function shown(el) { return !!el && el.style.display !== 'none' && (el.offsetParent !== null || w.getComputedStyle(el).position === 'fixed'); }
  function lastSeg(t) { var p = String(t || '').split('›'); return p[p.length - 1].replace(/\s+/g, ' ').trim(); }
  function read() {
    var app = d.getElementById('app'), home = d.getElementById('exbHome'), hub = d.getElementById('exbHub');
    if (!app || app.offsetParent === null && w.getComputedStyle(app).display === 'none') return null;
    if (home && home.style.display !== 'none') return null;           /* accueil : inchangé */
    if (hub && hub.style.display !== 'none') return null;             /* page de catégorie : inchangée */
    if (!home && !hub) return null;                                    /* tableau de bord d'origine : pas de navigation par module */
    var mb = d.getElementById('exbModBar'), crumb = d.getElementById('exbCrumb'), items = [], cur = '', ic = '▦', i, b, sib = false;
    var src = mb && mb.style.display !== 'none' ? mb.querySelectorAll('.mb') : [];
    if (src.length > 1) {
      sib = true;
      for (i = 0; i < src.length; i++) {
        b = src[i]; var ico = b.querySelector('i'), icoT = ico ? ico.textContent : '', lab = (b.textContent || '').trim();
        if (ico && lab.indexOf(icoT) === 0) lab = lab.slice(icoT.length).trim();
        var on = b.classList.contains('on'); if (on) { cur = lab; ic = icoT || ic; }
        items.push({ ic: icoT, label: lab, on: on, go: (function (n) { return function () { var q = d.querySelectorAll('#exbModBar .mb')[n]; if (q) q.click(); }; })(i) });
      }
    } else {
      var act = d.querySelector('#app .tabs button.active');
      cur = (crumb && crumb.style.display !== 'none' ? lastSeg(crumb.textContent) : '') || (act ? (act.textContent || '').replace(/^[^\wÀ-ÿ]+/u, '').trim() : '') || 'Module';
      items.push({ ic: '', label: cur, on: true, go: function () {} });
    }
    var cb = crumb && crumb.style.display !== 'none' ? crumb.querySelector('button') : null, cat = cb ? (cb.textContent || '').replace(/^[^\wÀ-ÿ]+/u, '').trim() : '';
    return { sib: sib, items: items, cur: cur, ic: ic, cat: cat, cb: cb };
  }
  var lastSig = '';
  function sync() {
    css();
    var r = read();
    if (!r) { d.documentElement.classList.remove('exb-dock-on', 'exb-dock-bottom', 'exb-dock-sib'); if (dock) dock.classList.remove('on'); lastSig = ''; return; }
    build();
    var fresh = false, sig = r.items.map(function (x) { return x.label + (x.on ? '*' : ''); }).join('|') + '#' + r.cat + '#' + r.sib;
    if (sig !== lastSig) {
      lastSig = sig;
      var box = dock.querySelector('.dk-in'), h = '<button type="button" class="dk-b dk-home" data-k="home" aria-label="Accueil"><i>⌂</i>Accueil</button>';
      if (r.cb && r.cat && r.cat !== 'Accueil') h += '<button type="button" class="dk-b dk-cat" data-k="cat"><i>‹</i>' + esc(r.cat) + '</button>';
      r.items.forEach(function (x, n) { h += '<button type="button" class="dk-b' + (x.on ? ' on' : '') + '" role="tab" aria-selected="' + x.on + '" data-k="i' + n + '">' + (x.ic ? '<i>' + esc(x.ic) + '</i>' : '') + esc(x.label) + '</button>'; });
      box.innerHTML = h;
      dock.querySelector('.dk-pi').textContent = r.ic; dock.querySelector('.dk-pn').textContent = r.cur;
      var btns = box.querySelectorAll('.dk-b');
      for (var j = 0; j < btns.length; j++) (function (el) {
        el.onclick = function () {
          var k = el.getAttribute('data-k'), rr;
          try {
            if (k === 'home') { if (typeof w.show === 'function') w.show('dashboard'); }
            else if (k === 'cat') { var c = d.querySelector('#exbCrumb button'); if (c) c.click(); }
            else { rr = read(); var it = rr && rr.items[+k.slice(1)]; if (it) it.go(); }
          } catch (e) {}
        };
      })(btns[j]);
      fresh = true;
    }
    d.documentElement.classList.toggle('exb-dock-sib', r.sib);
    d.documentElement.classList.add('exb-dock-on'); dock.classList.add('on'); place();
    if (fresh) { var bx = dock.querySelector('.dk-in'), onb = bx.querySelector('.dk-b.on'); if (onb) bx.scrollLeft = Math.max(0, onb.offsetLeft - (bx.clientWidth - onb.offsetWidth) / 2); }
  }

  /* ---------- clavier : la barre s'efface pendant la saisie ---------- */
  function editable(e) {
    if (!e || e === d.body) return false;
    var t = (e.tagName || '').toLowerCase();
    if (t === 'textarea' || t === 'select') return true;
    if (t === 'input') return !/^(button|submit|reset|checkbox|radio|range|color|file|image)$/i.test(e.type || 'text');
    return !!e.isContentEditable;
  }
  function bind() {
    if (bound) return; bound = true;
    d.addEventListener('focusin', function (e) { if (dock && !st.free && editable(e.target)) dock.classList.add('hide'); });
    d.addEventListener('focusout', function () { setTimeout(function () { if (dock && !editable(d.activeElement)) dock.classList.remove('hide'); }, 120); });
    w.addEventListener('resize', place);
    w.addEventListener('orientationchange', function () { setTimeout(place, 250); });
  }

  var timer = 0;
  function watch() {
    bind(); sync();
    if (!timer) timer = setInterval(function () { try { sync(); } catch (e) {} }, 400);
  }
  w.EXB_DOCK = { sync: sync, reset: function () { st = { free: false, x: 0, y: 0, mini: false }; save(); place(); }, version: 'V99-dock-2-tous-modules' };
  if (d.readyState === 'complete') setTimeout(watch, 800); else w.addEventListener('load', function () { setTimeout(watch, 800); });
})(window, document);
