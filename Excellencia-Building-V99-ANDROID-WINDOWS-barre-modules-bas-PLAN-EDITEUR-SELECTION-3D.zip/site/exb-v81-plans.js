/* Excellencia Building V81 — Plans CAO : DWG, DXF, IFC, Revit (RVT), PDF, images.
 * - DXF (texte) : visionneuse 2D complète (calques, blocs, zoom/déplacement), comparaison de versions, annotations.
 * - IFC : lecture de la structure (niveaux, éléments) et comparaison par identifiant d'élément .
 * - Images : visionneuse, comparaison par différence de pixels, annotations. PDF : lecture seule.
 * - DWG / RVT : formats propriétaires non lisibles dans un navigateur → archivés avec versions (exporter en DXF / IFC / PDF pour visualiser).
 * Fichiers : IndexedDB de cet appareil (non synchronisés). Fiches et annotations : exb_plan_files / exb_plan_annots (synchronisées). */
(function(w,d){'use strict';var C=w.EXB81,FK='exb_plan_files',AK='exb_plan_annots',COL='plans_fichiers',st={pid:'',sel:[]},V=null,MT={scale:1,dist:1,poly:1,area:1};
function F(){return w.EXBS.get(FK)}function A(){return w.EXBS.get(AK)}
function canW(){return C.can(COL,'ecrire')}
function ext(n){return(/\.([a-z0-9]+)$/i.exec(n||'')||[])[1]?(/\.([a-z0-9]+)$/i.exec(n)[1]).toLowerCase():''}
/* ---------- stockage local des fichiers ---------- */
function idb(){return new Promise(function(ok,ko){var r=indexedDB.open('exb81',1);r.onupgradeneeded=function(){r.result.createObjectStore('blobs')};r.onsuccess=function(){ok(r.result)};r.onerror=function(){ko(r.error)}})}
function bput(id,b){return idb().then(function(db){return new Promise(function(ok,ko){var t=db.transaction('blobs','readwrite');t.objectStore('blobs').put(b,id);t.oncomplete=ok;t.onerror=function(){ko(t.error)}})})}
function bget(id){return idb().then(function(db){return new Promise(function(ok,ko){var q=db.transaction('blobs').objectStore('blobs').get(id);q.onsuccess=function(){ok(q.result)};q.onerror=function(){ko(q.error)}})})}
function bdel(id){return idb().then(function(db){db.transaction('blobs','readwrite').objectStore('blobs').delete(id)})}
/* ---------- espace partagé (Supabase Storage, bucket « exb-plans », dossier = id de l'entreprise) ---------- */
var BK='exb-plans';
function org(){try{return w.EXBDB&&w.EXBDB.org&&w.EXBDB.org()||''}catch(e){return''}}
function sbOn(){return !!(org()&&w.exbSb&&w.exbSb.isIn()&&navigator.onLine)}
function safeN(n){return String(n||'fichier').replace(/[^A-Za-z0-9._-]+/g,'_').slice(-60)}
function cpath(m){return org()+'/plans/'+m.id+'-'+safeN(m.name)}
function cput(m,b){return w.exbSb.api('/storage/v1/object/'+BK+'/'+m.path,{method:'POST',headers:{'Content-Type':b.type||'application/octet-stream','x-upsert':'true'},body:b})}
function cget(m){return w.exbSb.api('/storage/v1/object/sign/'+BK+'/'+m.path,{method:'POST',body:JSON.stringify({expiresIn:300})}).then(function(r){return fetch(w.exbSb.cfg().url+'/storage/v1'+r.signedURL)}).then(function(r){if(!r.ok)throw new Error('Téléchargement impossible ('+r.status+')');return r.blob()})}
function syncUp(){if(!sbOn()||syncUp.b)return;syncUp.b=1;var L=F().filter(function(x){return !x.path&&x.id}),chain=Promise.resolve();
 L.forEach(function(m){chain=chain.then(function(){return bget(m.id).then(function(b){if(!b)return;var m2=Object.assign({},m,{path:cpath(m)});return cput(m2,b).then(function(){var a=F(),t=a.find(function(q){return q.id===m.id});if(t){t.path=m2.path;w.EXBS.set(FK,a)}})})}).catch(function(){})});
 chain.then(function(){syncUp.b=0})}
/* ---------- DXF ---------- */
var ACI={1:'#d00',2:'#b8a000',3:'#0a0',4:'#0aa',5:'#00d',6:'#a0a',7:'#111',8:'#777',9:'#aaa'};
function col(c,lc){var n=Math.abs(c==null||c===256?(lc||7):c);return ACI[n]||'hsl('+(n*37%360)+',70%,40%)'}
function parseDxf(txt){var Ln=txt.split(/\r?\n/),sec='',cur=null,poly=null,blk=null,blocks={},ents=[],lay={},i;
 function mt(s){return String(s||'').replace(/\\P/g,' ').replace(/\{?\\[A-Za-z][^;]*;/g,'').replace(/[{}]/g,'')}
 function push(e){var p=e.pts[0]||[0,0],t=e.t,o=null,l=e.l||'0';
  if(t==='LINE'&&e.p2)o={k:'L',p:[p[0],p[1],e.p2[0],e.p2[1]]};
  else if(t==='LWPOLYLINE')o={k:'P',pts:e.pts,closed:!!(e.f&1)};
  else if(t==='POLYLINE'){poly={k:'P',pts:[],closed:!!(e.f&1),l:l,c:e.c};(blk?blk.e:ents).push(poly);return}
  else if(t==='VERTEX'){if(poly)poly.pts.push(p);return}
  else if(t==='SEQEND'){poly=null;return}
  else if(t==='CIRCLE')o={k:'C',x:p[0],y:p[1],r:e.r};
  else if(t==='ARC')o={k:'A',x:p[0],y:p[1],r:e.r,a0:e.a0||0,a1:e.a1==null?360:e.a1};
  else if(t==='TEXT'||t==='MTEXT')o={k:'T',x:p[0],y:p[1],h:e.r||2.5,s:mt(e.s),rot:e.a0||0};
  else if(t==='INSERT')o={k:'I',n:e.n,x:p[0],y:p[1],sx:e.sx||1,sy:e.sy||e.sx||1,r:e.a0||0};
  if(o){o.l=l;o.c=e.c;(blk?blk.e:ents).push(o)}}
 function done(){if(!cur)return;var t=cur.t;
  if(sec==='TABLES'&&t==='LAYER'&&cur.n)lay[cur.n]=cur.c;
  else if(sec==='BLOCKS'&&t==='BLOCK'){blk={e:[],bx:(cur.pts[0]||[0,0])[0],by:(cur.pts[0]||[0,0])[1]};blocks[cur.n]=blk}
  else if(sec==='BLOCKS'&&t==='ENDBLK'){blk=null}
  else if(sec==='ENTITIES'||(sec==='BLOCKS'&&blk))push(cur);cur=null}
 for(i=0;i+1<Ln.length;i+=2){var code=parseInt(Ln[i],10),v=Ln[i+1].replace(/^\s+|\s+$/g,'');
  if(code===0){done();if(v==='SECTION'){sec='?'}else if(v==='ENDSEC'){sec='';blk=null}else if(v==='EOF')break;else cur={t:v,pts:[],l:'0'};continue}
  if(code===2&&sec==='?'&&!cur){sec=v;continue}if(!cur)continue;
  switch(code){case 8:cur.l=v;break;case 62:cur.c=parseInt(v,10);break;case 2:cur.n=v;break;case 1:cur.s=(cur.s||'')+Ln[i+1];break;
   case 10:cur.pts.push([parseFloat(v),0]);break;case 20:if(cur.pts.length)cur.pts[cur.pts.length-1][1]=parseFloat(v);break;
   case 11:cur.p2=[parseFloat(v),0];break;case 21:if(cur.p2)cur.p2[1]=parseFloat(v);break;
   case 40:cur.r=parseFloat(v);break;case 41:cur.sx=parseFloat(v);break;case 42:cur.sy=parseFloat(v);break;case 50:cur.a0=parseFloat(v);break;case 51:cur.a1=parseFloat(v);break;case 70:cur.f=parseInt(v,10)||0;break}}
 done();
 /* développement des blocs (INSERT), 3 niveaux au plus */
 function exp(list,m,dep,out){list.forEach(function(e){if(e.k==='I'){var b=blocks[e.n];if(b&&dep<3){var cr=Math.cos((e.r+m.r)*Math.PI/180),sr=Math.sin((e.r+m.r)*Math.PI/180);
   var px=m.x+(e.x*m.sx)*Math.cos(m.r*Math.PI/180)-(e.y*m.sy)*Math.sin(m.r*Math.PI/180),py=m.y+(e.x*m.sx)*Math.sin(m.r*Math.PI/180)+(e.y*m.sy)*Math.cos(m.r*Math.PI/180);
   exp(b.e,{x:px,y:py,sx:m.sx*e.sx,sy:m.sy*e.sy,r:m.r+e.r,bx:b.bx,by:b.by},dep+1,out)}return}
  out.push(tf(e,m))})}
 function T(m,x,y){x-=m.bx||0;y-=m.by||0;var a=m.r*Math.PI/180,X=x*m.sx,Y=y*m.sy;return[m.x+X*Math.cos(a)-Y*Math.sin(a),m.y+X*Math.sin(a)+Y*Math.cos(a)]}
 function tf(e,m){if(m.id)return e;var o=Object.assign({},e),q;
  if(e.k==='L'){var a=T(m,e.p[0],e.p[1]),b=T(m,e.p[2],e.p[3]);o.p=[a[0],a[1],b[0],b[1]]}
  else if(e.k==='P')o.pts=e.pts.map(function(p){return T(m,p[0],p[1])});
  else if(e.k==='C'||e.k==='A'||e.k==='T'){q=T(m,e.x,e.y);o.x=q[0];o.y=q[1];if(o.r)o.r=e.r*Math.abs(m.sx);if(e.k==='A'){o.a0=e.a0+m.r;o.a1=e.a1+m.r}if(e.k==='T'){o.h=e.h*Math.abs(m.sy);o.rot=(e.rot||0)+m.r}}
  return o}
 var out=[];exp(ents,{id:1,x:0,y:0,sx:1,sy:1,r:0},0,out);
 var bb=[1e18,1e18,-1e18,-1e18],n=0;function ex(x,y){if(x<bb[0])bb[0]=x;if(y<bb[1])bb[1]=y;if(x>bb[2])bb[2]=x;if(y>bb[3])bb[3]=y}
 out.forEach(function(e){n++;if(e.k==='L'){ex(e.p[0],e.p[1]);ex(e.p[2],e.p[3])}else if(e.k==='P')e.pts.forEach(function(p){ex(p[0],p[1])});else if(e.k==='C'||e.k==='A'){ex(e.x-e.r,e.y-e.r);ex(e.x+e.r,e.y+e.r)}else if(e.k==='T')ex(e.x,e.y)});
 if(!n||bb[0]>bb[2])throw new Error('Aucune entité dessinable trouvée (DXF vide ou binaire : enregistrez-le en DXF ASCII).');
 var layers={};out.forEach(function(e){layers[e.l]=(layers[e.l]||0)+1});
 return{kind:'dxf',ents:out,bbox:bb,layers:layers,layCol:lay,blocks:Object.keys(blocks).length}}
/* ---------- IFC ---------- */
function sargs(s){var a=[],dep=0,q=false,cur='';for(var i=0;i<s.length;i++){var c=s[i];if(c==="'"){if(q&&s[i+1]==="'"){cur+="''";i++;continue}q=!q;cur+=c;continue}if(!q){if(c==='(')dep++;else if(c===')')dep--;else if(c===','&&dep===0){a.push(cur.trim());cur='';continue}}cur+=c}a.push(cur.trim());return a}
function ustr(s){return String(s||'').replace(/^'|'$/g,'').replace(/''/g,"'")}
function parseIfc(txt){var i0=txt.indexOf('DATA;');if(txt.indexOf('ISO-10303-21')<0||i0<0)throw new Error('Fichier IFC non reconnu (attendu : IFC texte STEP).');
 var sch=(/FILE_SCHEMA\s*\(\s*\(\s*'([^']+)'/.exec(txt)||[])[1]||'?',data=txt.slice(i0+5),S=data.split(/;\s*[\r\n]/),types={},els=[],stor=[],proj='',n=0;
 var EL={IFCWALL:'Murs',IFCWALLSTANDARDCASE:'Murs',IFCSLAB:'Dalles',IFCCOLUMN:'Poteaux',IFCBEAM:'Poutres',IFCDOOR:'Portes',IFCWINDOW:'Fenêtres',IFCROOF:'Toitures',IFCSTAIR:'Escaliers',IFCFOOTING:'Fondations',IFCCOVERING:'Revêtements',IFCRAILING:'Garde-corps',IFCPLATE:'Plaques',IFCMEMBER:'Éléments linéaires',IFCPILE:'Pieux',IFCFURNISHINGELEMENT:'Mobilier',IFCBUILDINGELEMENTPROXY:'Éléments divers'};
 S.forEach(function(s){var m=/^\s*#(\d+)\s*=\s*([A-Z0-9_]+)\s*\(([\s\S]*)\)\s*$/.exec(s);if(!m)return;n++;var t=m[2];types[t]=(types[t]||0)+1;
  if(EL[t]||t==='IFCBUILDINGSTOREY'||t==='IFCPROJECT'){var g=sargs(m[3]);if(t==='IFCPROJECT')proj=ustr(g[2]);else if(t==='IFCBUILDINGSTOREY')stor.push({name:ustr(g[2]),elev:g[9]});else els.push({g:ustr(g[0]),t:t,name:ustr(g[2]),grp:EL[t]})}});
 var cnt={};els.forEach(function(e){cnt[e.grp]=(cnt[e.grp]||0)+1});
 return{kind:'ifc',schema:sch,project:proj,n:n,storeys:stor,els:els,cnt:cnt,types:types}}
/* ---------- métadonnées ---------- */
function readTag(f){var e=ext(f.name);if(e!=='dxf'&&e!=='ifc')return Promise.resolve(null);return f.slice(0,12000).text().then(function(t){var m=/EXB-REF=([^;\r\n']+)(?:;TITRE=([^;\r\n']*))?(?:;OUVRAGE=([^;\r\n']*))?(?:;DATE=([^;\r\n']*))?/.exec(t);return m?{ref:m[1].trim(),titre:(m[2]||'').trim(),ouvrage:(m[3]||'').trim(),date:(m[4]||'').trim()}:null}).catch(function(){return null})}
function refFromName(n){return String(n||'').replace(/\.[^.]+$/,'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)}
function nextVer(ref,pid){var k=F().filter(function(x){return String(x.project)===String(pid)&&x.ref===ref}).length;return String.fromCharCode(65+Math.min(k,25))}
function dwgVer(buf){var s=String.fromCharCode.apply(null,new Uint8Array(buf.slice(0,6))),M={AC1009:'R12',AC1012:'R13',AC1014:'R14',AC1015:'AutoCAD 2000',AC1018:'AutoCAD 2004',AC1021:'AutoCAD 2007',AC1024:'AutoCAD 2010',AC1027:'AutoCAD 2013',AC1032:'AutoCAD 2018 et +'};return/^AC/.test(s)?(M[s]||s):''}
function size(n){return n>1048576?(n/1048576).toFixed(1)+' Mo':Math.round(n/1024)+' Ko'}
function open(){if(!C.can(COL,'lire'))return C.say('Accès non autorisé.','error');if(!st.pid)st.pid=C.firstProject();st.sel=[];list()}
function list(){syncUp();var Fs=F().filter(function(x){return String(x.project)===String(st.pid)}).sort(function(a,b){return(a.ref+a.ver)<(b.ref+b.ver)?-1:1}),h='<p>'+C.projSelect('EXBPLN.proj',st.pid)+'</p>';
 if(canW())h+='<div style="background:#f1f5fb;border-radius:10px;padding:10px;margin-bottom:8px"><b>Ajouter un fichier</b> <small>(DXF, IFC, DWG, RVT, PDF, image)</small><div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">'+C.field('plRef','Référence du plan (ex. ARC-01)','','',45)+C.field('plNote','Note de version (facultatif)','','',45)+'</div><p><input type="file" id="plFile" accept=".dxf,.ifc,.dwg,.rvt,.rfa,.pdf,.png,.jpg,.jpeg,.webp" onchange="EXBPLN.fileSel(this)"> <button onclick="EXBPLN.add()">⬆ Ajouter</button></p><div id="plAuto" style="font-size:12.5px;color:#15803d"></div><div style="font-size:12px;color:#64748b">La référence est lue automatiquement dans le fichier exporté par le calcul (ou déduite du nom du fichier) : rien à ressaisir, et un nouvel export du même ouvrage reprend la même référence. Un fichier IFC s’ouvre ensuite en 3D. La version (A, B, C…) s’incrémente selon la référence. Les fichiers sont partagés avec l’équipe (espace sécurisé) dès que vous êtes connecté ; les fiches et annotations sont synchronisées.</div></div>';
 h+=Fs.length?'<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse"><tr style="text-align:left;background:#f1f5fb"><th style="padding:6px"></th><th>Plan</th><th>Ind.</th><th>Format</th><th>Date</th><th></th></tr>'+Fs.map(function(x){return '<tr style="border-bottom:1px solid #e2e8f0"><td style="padding:6px"><input type="checkbox" '+(st.sel.indexOf(x.id)>=0?'checked ':'')+'onchange="EXBPLN.pick(\''+x.id+'\',this.checked)"></td><td><b>'+C.esc(x.ref)+'</b><br><small>'+C.esc(x.name)+' · '+size(x.size)+(x.note?' · '+C.esc(x.note):'')+'</small></td><td>'+C.esc(x.ver)+'</td><td>'+C.esc(x.ext.toUpperCase())+(x.dwg?'<br><small>'+C.esc(x.dwg)+'</small>':'')+'</td><td>'+C.frDate(x.date)+'</td><td><button onclick="EXBPLN.view(\''+x.id+'\')">👁 Ouvrir</button>'+(canW()?' <button onclick="EXBPLN.del(\''+x.id+'\')">🗑</button>':'')+'</td></tr>'}).join('')+'</table></div><p><button onclick="EXBPLN.cmp()" style="padding:9px 14px">⇄ Comparer les 2 fichiers cochés</button></p>':'<p style="color:#64748b">Aucun fichier pour ce projet.</p>';
 C.overlay('exbPln','🗂 Plans & fichiers CAO',h,860)}
/* ---------- visionneuse ---------- */
function getBlob(x){return bget(x.id).then(function(b){if(b)return b;if(!x.path)return null;if(!sbOn())throw new Error('Fichier partagé : connectez-vous (en ligne) pour le télécharger.');return cget(x).then(function(bl){return bput(x.id,bl).then(function(){return bl},function(){return bl})})})}
function sceneOf(x){return getBlob(x).then(function(b){if(!b)throw new Error('Fichier absent de cet appareil et non partagé (ajouté avant la mise en place de l’espace partagé depuis un autre appareil : demandez à son auteur de le rouvrir en ligne).');
 if(x.ext==='dxf')return b.text().then(parseDxf);
 if(x.ext==='ifc')return b.text().then(parseIfc);
 if(/^(png|jpe?g|webp)$/.test(x.ext))return new Promise(function(ok,ko){var u=URL.createObjectURL(b),im=new Image();im.onload=function(){ok({kind:'img',img:im,bbox:[0,0,im.width,im.height],url:u})};im.onerror=function(){ko(new Error('Image illisible.'))};im.src=u});
 if(x.ext==='pdf')return{kind:'pdf',url:URL.createObjectURL(b)};
 return{kind:'opaque',ext:x.ext,dwg:x.dwg}})}
function view(id){var x=F().find(function(q){return q.id===id});if(!x)return;C.overlay('exbPlnV','📐 '+C.esc(x.ref)+' — ind. '+C.esc(x.ver),'<p style="color:#64748b">Chargement…</p>',1100);
 sceneOf(x).then(function(sc){show(x,sc)}).catch(function(e){C.overlay('exbPlnV','📐 '+C.esc(x.ref),'<p style="background:#fde8e8;padding:10px;border-radius:10px">'+C.esc(e.message||e)+'</p><p><button onclick="EXBPLN.back()">← Liste</button></p>')})}
function show(x,sc){
 if(sc.kind==='pdf'){C.overlay('exbPlnV','📄 '+C.esc(x.ref)+' — ind. '+C.esc(x.ver),'<iframe src="'+sc.url+'" style="width:100%;height:70vh;border:1px solid #cbd5e1"></iframe><p style="font-size:12px;color:#64748b">PDF en lecture seule : l’annotation sur plan est disponible pour les DXF et les images (exportez le plan en DXF ou en image pour l’annoter).</p><p><button onclick="EXBPLN.back()">← Liste</button></p>',1100);return}
 if(sc.kind==='opaque'){C.overlay('exbPlnV','🗂 '+C.esc(x.ref)+' — ind. '+C.esc(x.ver),'<div style="background:#fff7e6;border:1px solid #f0c36d;padding:12px;border-radius:10px"><b>Format '+C.esc(x.ext.toUpperCase())+(sc.dwg?' ('+C.esc(sc.dwg)+')':'')+' — non lisible dans le navigateur.</b><p>Ce format propriétaire est archivé et versionné ici, mais ne peut pas être affiché sans le logiciel d’origine. Pour le visualiser, le comparer et l’annoter dans Excellencia :</p><ul><li>depuis AutoCAD / Revit : <b>Enregistrer sous → DXF</b> (2D) ou <b>Exporter → IFC</b> (maquette) ;</li><li>ou exporter en <b>PDF</b> pour la diffusion.</li></ul>Ajoutez ensuite l’export avec la même référence : il prendra l’indice suivant.</div><p><button onclick="EXBPLN.back()">← Liste</button></p>');return}
 if(sc.kind==='ifc'){var rows=Object.keys(sc.cnt).sort().map(function(k){return '<tr><td>'+k+'</td><td class="r"><b>'+sc.cnt[k]+'</b></td></tr>'}).join(''),stor=sc.storeys.map(function(s){return '<tr><td>'+C.esc(s.name)+'</td><td>'+C.esc(s.elev)+'</td></tr>'}).join('');
  C.overlay('exbPlnV','🏢 '+C.esc(x.ref)+' — ind. '+C.esc(x.ver),C.kpis([['Schéma',C.esc(sc.schema)],['Projet IFC',C.esc(sc.project||'—')],['Entités',sc.n],['Éléments recensés',sc.els.length]])+'<div style="display:flex;gap:10px;flex-wrap:wrap"><div style="flex:1 1 260px"><b>Niveaux</b><table style="width:100%;border-collapse:collapse">'+(stor||'<tr><td>Aucun niveau</td></tr>')+'</table></div><div style="flex:1 1 260px"><b>Éléments par catégorie</b><table style="width:100%;border-collapse:collapse">'+(rows||'<tr><td>Aucun élément</td></tr>')+'</table></div></div><p><button onclick="EXBPLN.ifc3d('+JSON.stringify(x.id).replace(/"/g,'&quot;')+')" style="background:#0f4aa8;color:#fff">🧊 Ouvrir en 3D</button></p><p style="font-size:12px;color:#64748b">Maquette 3D : rotation, coupe, propriétés, filtres par catégorie. Pour suivre les évolutions entre deux indices, cochez deux fichiers IFC et utilisez « Comparer ».</p><p><button onclick="EXBPLN.back()">← Liste</button></p>',900);return}
 /* dxf / image : canvas interactif */
 V={x:x,sc:sc,tool:'pan',s:1,ox:0,oy:0,ptr:{},hide:{},cmp:null,drag:null,an:A().filter(function(a){return a.file===x.id}),mes:(x.mesures||[]).slice(),mp:[]};
 var tb=function(k,l){return '<button id="plT'+k+'" onclick="EXBPLN.tool(\''+k+'\')" style="padding:6px 9px;margin:1px">'+l+'</button>'};
 C.overlay('exbPlnV','📐 '+C.esc(x.ref)+' — ind. '+C.esc(x.ver),'<div>'+tb('pan','✋ Déplacer')+(canW()?tb('pin','📍 Repère')+tb('rect','▭ Zone')+tb('arrow','↗ Flèche'):'')+tb('scale','📏 Échelle')+tb('dist','↔ Distance')+tb('poly','〰 Longueur')+tb('area','▱ Surface')+'<button onclick="EXBPLN.fit()" style="padding:6px 9px;margin:1px">⤢ Ajuster</button>'+(sc.kind==='dxf'?'<button onclick="EXBPLN.layers()" style="padding:6px 9px;margin:1px">☰ Calques ('+Object.keys(sc.layers).length+')</button>':'')+'<button onclick="EXBPLN.png()" style="padding:6px 9px;margin:1px">🖼 Exporter</button><button onclick="EXBPLN.back()" style="padding:6px 9px;margin:1px">← Liste</button></div><div id="plLay"></div><div id="plMesBar" style="font-size:13px;margin-top:4px"></div><canvas id="plCv" style="width:100%;height:62vh;background:#fff;border:1px solid #cbd5e1;touch-action:none;margin-top:6px"></canvas><div id="plInfo" style="font-size:12px;color:#64748b">'+(sc.kind==='dxf'?sc.ents.length+' entités'+(sc.blocks?' · '+sc.blocks+' blocs développés':''):'Image '+sc.bbox[2]+'×'+sc.bbox[3])+' · molette / pincement pour zoomer</div><div id="plAn"></div><div id="plMes"></div>',1100);
 setup();anList();mbar();mlist()}
function cv(){return d.getElementById('plCv')}
function setup(){var c=cv();if(!c)return;c.width=c.clientWidth*(w.devicePixelRatio||1);c.height=c.clientHeight*(w.devicePixelRatio||1);fit();hl();
 function pos(e){var r=c.getBoundingClientRect(),k=c.width/r.width;return[(e.clientX-r.left)*k,(e.clientY-r.top)*k]}
 c.onpointerdown=function(e){c.setPointerCapture(e.pointerId);V.ptr[e.pointerId]=pos(e);if(Object.keys(V.ptr).length===1){var p=pos(e);V.drag={sx:p[0],sy:p[1],ox:V.ox,oy:V.oy,w:wp(p)}}};
 c.onpointermove=function(e){if(!V.ptr[e.pointerId])return;var p=pos(e),ids=Object.keys(V.ptr);
  if(ids.length===2){var o=ids.filter(function(i){return i!=e.pointerId})[0],q=V.ptr[o],a=V.ptr[e.pointerId],d0=Math.hypot(a[0]-q[0],a[1]-q[1]),d1=Math.hypot(p[0]-q[0],p[1]-q[1]);if(d0>0)zoom(d1/d0,[(p[0]+q[0])/2,(p[1]+q[1])/2]);V.ptr[e.pointerId]=p;return}
  V.ptr[e.pointerId]=p;if((V.tool==='pan'||MT[V.tool])&&V.drag){V.ox=V.drag.ox+p[0]-V.drag.sx;V.oy=V.drag.oy+p[1]-V.drag.sy;draw()}else if(V.drag){V.cur=wp(p);draw()}};
 c.onpointerup=function(e){var p=pos(e);delete V.ptr[e.pointerId];if(!V.drag)return;var a=V.drag.w,b=wp(p),t=V.tool,mv=Math.hypot(p[0]-V.drag.sx,p[1]-V.drag.sy);V.drag=null;V.cur=null;if(MT[t]){if(mv<10*(w.devicePixelRatio||1))mtap(snap(b));draw();return}
  if(t==='pin')mk({kind:'pin',x:a[0],y:a[1]});else if(t==='rect'||t==='arrow'){if(Math.abs(b[0]-a[0])+Math.abs(b[1]-a[1])>0)mk({kind:t,x:a[0],y:a[1],x2:b[0],y2:b[1]})}draw()};
 c.onwheel=function(e){e.preventDefault();zoom(e.deltaY<0?1.2:1/1.2,pos(e))}}
function wp(p){return[(p[0]-V.ox)/V.s,-(p[1]-V.oy)/V.s*(V.sc.kind==='img'?-1:1)]}
function sp(x,y){return[x*V.s+V.ox,(V.sc.kind==='img'?y:-y)*V.s+V.oy]}
function zoom(k,p){var w0=wp(p);V.s*=k;var q=sp(w0[0],w0[1]);V.ox+=p[0]-q[0];V.oy+=p[1]-q[1];draw()}
function fit(){var c=cv(),b=V.sc.bbox,W=b[2]-b[0]||1,H=b[3]-b[1]||1;V.s=Math.min(c.width/W,c.height/H)*.92;V.ox=(c.width-W*V.s)/2-b[0]*V.s;V.oy=V.sc.kind==='img'?(c.height-H*V.s)/2-b[1]*V.s:(c.height+H*V.s)/2+b[1]*V.s;draw()}
function hl(){['pan','pin','rect','arrow','scale','dist','poly','area'].forEach(function(k){var e=d.getElementById('plT'+k);if(e)e.style.background=k===V.tool?'#173565':'';if(e)e.style.color=k===V.tool?'#fff':''})}
function drawEnts(g,ents,mode){var lc=V.sc.layCol||{};ents.forEach(function(e){if(V.hide[e.l])return;g.strokeStyle=mode||col(e.c,lc[e.l]);g.fillStyle=g.strokeStyle;g.beginPath();var a;
  if(e.k==='L'){a=sp(e.p[0],e.p[1]);g.moveTo(a[0],a[1]);a=sp(e.p[2],e.p[3]);g.lineTo(a[0],a[1]);g.stroke()}
  else if(e.k==='P'){e.pts.forEach(function(p,i){a=sp(p[0],p[1]);i?g.lineTo(a[0],a[1]):g.moveTo(a[0],a[1])});if(e.closed)g.closePath();g.stroke()}
  else if(e.k==='C'){a=sp(e.x,e.y);g.arc(a[0],a[1],e.r*V.s,0,6.2832);g.stroke()}
  else if(e.k==='A'){a=sp(e.x,e.y);g.arc(a[0],a[1],e.r*V.s,-e.a0*Math.PI/180,-e.a1*Math.PI/180,true);g.stroke()}
  else if(e.k==='T'&&e.h*V.s>5){a=sp(e.x,e.y);g.save();g.translate(a[0],a[1]);g.rotate(-(e.rot||0)*Math.PI/180);g.font=Math.min(e.h*V.s,60)+'px Arial';g.fillText(e.s||'',0,0);g.restore()}})}
function draw(){var c=cv();if(!c||!V)return;var g=c.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);g.lineWidth=Math.max(1,(w.devicePixelRatio||1)*.9);
 if(V.sc.kind==='img'){var a=sp(0,0);g.globalAlpha=V.cmp?.35:1;g.drawImage(V.sc.img,a[0],a[1],V.sc.img.width*V.s,V.sc.img.height*V.s);g.globalAlpha=1;if(V.cmp&&V.cmp.diff){g.drawImage(V.cmp.diff,a[0],a[1],V.sc.img.width*V.s,V.sc.img.height*V.s)}}
 else if(V.cmp&&V.cmp.dxf){drawEnts(g,V.cmp.same,'#c3c9d4');drawEnts(g,V.cmp.rem,'#d00000');drawEnts(g,V.cmp.add,'#00a000')}
 else drawEnts(g,V.sc.ents);
 g.font=(13*(w.devicePixelRatio||1))+'px Arial';V.an.forEach(function(n,i){g.strokeStyle=g.fillStyle=n.status==='traitée'?'#2e8b57':'#e11d48';g.lineWidth=2*(w.devicePixelRatio||1);var p=sp(n.x,n.y);
  if(n.kind==='pin'){g.beginPath();g.arc(p[0],p[1],11*(w.devicePixelRatio||1),0,6.2832);g.fill();g.fillStyle='#fff';g.fillText(String(i+1),p[0]-4,p[1]+5)}
  else{var q=sp(n.x2,n.y2);if(n.kind==='rect'){g.setLineDash([8,4]);g.strokeRect(p[0],p[1],q[0]-p[0],q[1]-p[1]);g.setLineDash([])}else{g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(q[0],q[1]);g.stroke();var an=Math.atan2(q[1]-p[1],q[0]-p[0]);g.beginPath();g.moveTo(q[0],q[1]);g.lineTo(q[0]-14*Math.cos(an-.4),q[1]-14*Math.sin(an-.4));g.lineTo(q[0]-14*Math.cos(an+.4),q[1]-14*Math.sin(an+.4));g.fill()}
   g.fillStyle=g.strokeStyle;g.fillText(String(i+1),p[0]+4,p[1]-6)}});
 drawMes(g);if(V.drag&&V.cur&&V.tool!=='pan'&&!MT[V.tool]){var s0=sp(V.drag.w[0],V.drag.w[1]),s1=sp(V.cur[0],V.cur[1]);g.strokeStyle='#e11d48';g.setLineDash([4,4]);g.strokeRect(s0[0],s0[1],s1[0]-s0[0],s1[1]-s0[1]);g.setLineDash([])}}
/* ---------- V99zx : mesure sur plan avec échelle (distance, longueur cumulée, surface) ---------- */
function kk(){var e=V.x.echelle;return e&&e.k>0?e.k:0}
function nf(v){return(Math.round(v*100)/100).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})}
function snap(b){if(V.sc.kind!=='dxf')return b;var r=14*(w.devicePixelRatio||1)/V.s,best=null,bd=r;
 V.sc.ents.forEach(function(e){if(V.hide[e.l])return;var pts=e.k==='L'?[[e.p[0],e.p[1]],[e.p[2],e.p[3]]]:(e.k==='P'?e.pts:((e.k==='C'||e.k==='A')?[[e.x,e.y]]:[]));
  pts.forEach(function(q){var dd=Math.hypot(q[0]-b[0],q[1]-b[1]);if(dd<bd){bd=dd;best=q}})});return best?[best[0],best[1]]:b}
function parseM(s){var m=parseFloat(String(s).replace(',','.').replace(/\s/g,''));return m>0&&isFinite(m)?m:0}
function setEch(e){V.x.echelle=e;if(!canW())return;var a=F(),r=a.find(function(q){return q.id===V.x.id});if(r){r.echelle=e;w.EXBS.set(FK,a)}}
function persist(){if(!canW())return;var a=F(),r=a.find(function(q){return q.id===V.x.id});if(r){r.mesures=V.mes;w.EXBS.set(FK,a)}}
function mtap(b){var t=V.tool;V.mp.push(b);
 if(t==='scale'&&V.mp.length===2){var du=Math.hypot(V.mp[1][0]-V.mp[0][0],V.mp[1][1]-V.mp[0][1]);
  if(!(du>0)){V.mp=[];mbar();return C.say('Les deux points sont identiques.','warn')}
  var m=parseM(w.prompt('Distance réelle entre ces 2 points (en mètres) :',''));
  if(!m){V.mp=[];mbar();draw();return C.say('Échelle non définie : distance invalide.','warn')}
  setEch({k:m/du,ref:m,date:C.today()});V.mp=[];V.tool='pan';hl();mbar();mlist();draw();return C.say('Échelle enregistrée : 1 unité du dessin = '+(m/du).toPrecision(5)+' m.')}
 if(t==='dist'&&V.mp.length===2)return mfin();
 mbar();draw()}
function mfin(){var t=V.tool,P=V.mp.slice(),k=kk();
 if(!k){V.mp=[];mbar();draw();return C.say('Définissez d’abord l’échelle (📏 Échelle) ou l’unité du dessin (⚙ Unité).','warn')}
 if(t==='area'?P.length<3:P.length<2)return C.say(t==='area'?'Au moins 3 points pour une surface.':'Au moins 2 points.','warn');
 var o={id:C.uid('MES'),kind:t,pts:P,date:C.today()};
 if(t==='area'){var s2=0;P.forEach(function(q,i){var n=P[(i+1)%P.length];s2+=q[0]*n[1]-n[0]*q[1]});o.val=Math.abs(s2)/2*k*k;o.unit='m²'}
 else{var L=0;for(var i=1;i<P.length;i++)L+=Math.hypot(P[i][0]-P[i-1][0],P[i][1]-P[i-1][1]);o.val=L*k;o.unit='m'}
 var lb=w.prompt('Libellé de la mesure (ex. Mur façade nord) :','');if(lb===null){V.mp=[];mbar();draw();return}
 o.label=(lb||'').trim()||({dist:'Distance',poly:'Longueur',area:'Surface'}[t]+' '+(V.mes.length+1));
 V.mes.push(o);V.mp=[];persist();mbar();mlist();draw()}
function mundo(){V.mp.pop();mbar();draw()}
function mabort(){V.mp=[];mbar();draw()}
function unit(){var s=w.prompt('1 unité du dessin = combien de mètres ?\n(1 si le dessin est en mètres, 0,01 en centimètres, 0,001 en millimètres)',V.x.echelle&&V.x.echelle.k?String(V.x.echelle.k):'');if(s===null)return;var m=parseM(s);if(!m)return C.say('Valeur invalide.','warn');setEch({k:m,ref:0,date:C.today(),unite:1});mbar();mlist();draw();C.say('Unité enregistrée : 1 unité = '+m+' m.')}
function mbar(){var e=d.getElementById('plMesBar');if(!e)return;var k=kk(),t=V.tool,h='<span style="color:'+(k?'#0f766e':'#b45309')+'">'+(k?'Échelle : 1 unité du dessin = '+(+k.toPrecision(5))+' m':'⚠ Échelle non définie')+'</span> <button onclick="EXBPLN.unit()" style="padding:3px 8px">⚙ Unité</button> ';
 if(t==='scale')h+='<br><b>Touchez 2 points dont vous connaissez la distance réelle</b> ('+V.mp.length+'/2)';
 else if(t==='dist')h+='<br><b>Touchez 2 points</b> ('+V.mp.length+'/2) — l’accroche aux extrémités DXF est automatique';
 else if(t==='poly'||t==='area'){h+='<br><b>Touchez les points successifs</b> ('+V.mp.length+') ';if(V.mp.length)h+='<button onclick="EXBPLN.mfin()" style="padding:4px 9px;background:#15803d;color:#fff">✔ Terminer</button> <button onclick="EXBPLN.mundo()" style="padding:4px 9px">↩ Retirer le dernier</button> <button onclick="EXBPLN.mabort()" style="padding:4px 9px">✕ Abandonner</button>'}
 e.innerHTML=h}
function mlist(){var e=d.getElementById('plMes');if(!e)return;if(!V.mes.length){e.innerHTML='';return}
 var L=0,S=0;V.mes.forEach(function(m){if(m.unit==='m²')S+=m.val;else L+=m.val});
 e.innerHTML='<div style="margin-top:8px"><b>Mesures ('+V.mes.length+')</b>'+V.mes.map(function(m){return '<div style="border-bottom:1px solid #e2e8f0;padding:5px 0;font-size:13px"><b>'+C.esc(m.label)+'</b> — '+nf(m.val)+' '+m.unit+' <small style="color:#64748b">· '+C.frDate(m.date)+'</small> '+(canW()?'<button onclick="EXBPLN.mdel(\''+C.esc(m.id)+'\')">🗑</button>':'')+'</div>'}).join('')
  +'<div style="margin-top:6px;font-size:13px"><b>Total : '+(L?nf(L)+' m':'')+(L&&S?' · ':'')+(S?nf(S)+' m²':'')+'</b></div><div style="margin-top:6px"><button onclick="EXBPLN.mcsv()">⬇ CSV (Excel)</button> '+(w.EXBMetre&&w.EXBMetre.addLignes?'<button onclick="EXBPLN.mmet()" style="background:#15803d;color:#fff">➕ Envoyer au métré</button>':'')+'</div><small style="color:#64748b">Mesures indicatives : précision liée à l’échelle saisie ; à contrôler avant chiffrage.</small></div>'}
function mdel(id){V.mes=V.mes.filter(function(m){return m.id!==id});persist();mlist();draw()}
function mcsv(){var q=function(v){return '"'+String(v).replace(/"/g,'""')+'"'},rows=[['Libellé','Type','Valeur','Unité','Date']].concat(V.mes.map(function(m){return [m.label,({dist:'Distance',poly:'Longueur',area:'Surface'})[m.kind],String(Math.round(m.val*100)/100).replace('.',','),m.unit,m.date]}));
 var a=d.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+rows.map(function(r){return r.map(q).join(';')}).join('\n')],{type:'text/csv;charset=utf-8'}));a.download='mesures-'+String(V.x.ref||'plan').replace(/[^\w.-]+/g,'_')+'.csv';a.click()}
function mmet(){var M=w.EXBMetre;if(!M||!M.addLignes)return C.say('Le module Métré n’est pas disponible.','warn');
 var lines=V.mes.filter(function(m){return m.val>0}).map(function(m){return{d:m.label+' (plan '+V.x.ref+' ind. '+V.x.ver+', mesure sur plan)',u:m.unit==='m²'?'m²':'ml',q:Math.round(m.val*100)/100,src:'plan:'+V.x.id+':'+m.id}});
 var n=M.addLignes(lines);if(!n)return C.say('Aucune ligne envoyée.','warn');C.say(n+' ligne(s) envoyée(s) dans le métré (Matériaux ajoutés). Saisissez les prix unitaires.')}
function drawMes(g){var dp=w.devicePixelRatio||1,col='#0f766e';g.save();g.font=(13*dp)+'px Arial';g.lineWidth=2*dp;
 function path(P,closed,c,dash){g.strokeStyle=g.fillStyle=c;g.setLineDash(dash?[6*dp,4*dp]:[]);g.beginPath();P.forEach(function(q,i){var s=sp(q[0],q[1]);i?g.lineTo(s[0],s[1]):g.moveTo(s[0],s[1])});if(closed&&P.length>2)g.closePath();g.stroke();g.setLineDash([]);if(closed&&P.length>2){g.globalAlpha=.12;g.fill();g.globalAlpha=1}P.forEach(function(q){var s=sp(q[0],q[1]);g.beginPath();g.arc(s[0],s[1],3.5*dp,0,6.2832);g.fill()})}
 (V.mes||[]).forEach(function(m){path(m.pts,m.kind==='area',col);var P=m.pts,cx,cy;if(m.kind==='area'){cx=P.reduce(function(t,q){return t+q[0]},0)/P.length;cy=P.reduce(function(t,q){return t+q[1]},0)/P.length}else{var i=Math.floor((P.length-1)/2);cx=(P[i][0]+P[i+1][0])/2;cy=(P[i][1]+P[i+1][1])/2}var a=sp(cx,cy),t=nf(m.val)+' '+m.unit;g.lineJoin='round';g.lineWidth=4*dp;g.strokeStyle='#fff';g.strokeText(t,a[0]-g.measureText(t).width/2,a[1]-6*dp);g.fillStyle=col;g.fillText(t,a[0]-g.measureText(t).width/2,a[1]-6*dp);g.lineWidth=2*dp});
 if(V.mp&&V.mp.length)path(V.mp,false,'#ea580c',true);g.restore()}
function mk(o){var t=w.prompt('Texte de l’annotation :','');if(t===null||!t.trim())return;o.id=C.uid('ANN');o.file=V.x.id;o.text=t.trim();o.status='ouverte';o.date=C.today();o.by=(w.EXB_BRAND&&w.EXB_BRAND.user)||'';var a=A();a.push(o);w.EXBS.set(AK,a);V.an.push(o);anList()}
function anList(){var e=d.getElementById('plAn');if(!e)return;e.innerHTML=V.an.length?'<div style="margin-top:8px"><b>Annotations ('+V.an.length+')</b>'+V.an.map(function(n,i){return '<div style="border-bottom:1px solid #e2e8f0;padding:5px 0;font-size:13px"><b>'+(i+1)+'.</b> '+C.esc(n.text)+' <small style="color:#64748b">· '+C.frDate(n.date)+' · '+n.status+'</small> '+(canW()?'<button onclick="EXBPLN.anSt(\''+n.id+'\')">'+(n.status==='ouverte'?'✓ Traitée':'↺ Rouvrir')+'</button> <button onclick="EXBPLN.anDel(\''+n.id+'\')">🗑</button>':'')+'</div>'}).join('')+'</div>':''}
/* ---------- comparaison ---------- */
function sig(e,tol){var r=function(v){return Math.round(v/tol)};if(e.k==='L'){var a=[r(e.p[0]),r(e.p[1])].join(','),b=[r(e.p[2]),r(e.p[3])].join(',');return'L|'+e.l+'|'+(a<b?a+'|'+b:b+'|'+a)}
 if(e.k==='P')return'P|'+e.l+'|'+e.closed+'|'+e.pts.map(function(p){return r(p[0])+','+r(p[1])}).join(';');if(e.k==='C')return'C|'+e.l+'|'+r(e.x)+','+r(e.y)+','+r(e.r);if(e.k==='A')return'A|'+e.l+'|'+r(e.x)+','+r(e.y)+','+r(e.r)+','+Math.round(e.a0)+','+Math.round(e.a1);return'T|'+e.l+'|'+r(e.x)+','+r(e.y)+'|'+e.s}
function diffDxf(a,b){var bb=[Math.min(a.bbox[0],b.bbox[0]),Math.min(a.bbox[1],b.bbox[1]),Math.max(a.bbox[2],b.bbox[2]),Math.max(a.bbox[3],b.bbox[3])],tol=Math.max(1e-6,Math.hypot(bb[2]-bb[0],bb[3]-bb[1])/20000),m={},rem=[],add=[],same=[],lay={};
 a.ents.forEach(function(e){var k=sig(e,tol);(m[k]=m[k]||[]).push(e)});
 b.ents.forEach(function(e){var k=sig(e,tol);if(m[k]&&m[k].length){same.push(m[k].pop())}else{add.push(e);lay[e.l]=lay[e.l]||[0,0];lay[e.l][0]++}});
 Object.keys(m).forEach(function(k){m[k].forEach(function(e){rem.push(e);lay[e.l]=lay[e.l]||[0,0];lay[e.l][1]++})});
 return{dxf:1,rem:rem,add:add,same:same,lay:lay,bbox:bb}}
function diffImg(a,b){var W=Math.min(a.width,1600),k=W/a.width,H=Math.round(a.height*k),c1=d.createElement('canvas'),c2=d.createElement('canvas');c1.width=c2.width=W;c1.height=c2.height=H;var g1=c1.getContext('2d'),g2=c2.getContext('2d');g1.drawImage(a,0,0,W,H);g2.drawImage(b,0,0,W,H);
 var d1=g1.getImageData(0,0,W,H),d2=g2.getImageData(0,0,W,H),n=0,o=g1.createImageData(W,H);for(var i=0;i<d1.data.length;i+=4){var df=Math.abs(d1.data[i]-d2.data[i])+Math.abs(d1.data[i+1]-d2.data[i+1])+Math.abs(d1.data[i+2]-d2.data[i+2]);if(df>90){o.data[i]=225;o.data[i+1]=29;o.data[i+2]=72;o.data[i+3]=200;n++}}
 var oc=d.createElement('canvas');oc.width=W;oc.height=H;oc.getContext('2d').putImageData(o,0,0);return{diff:oc,pct:n/(W*H)*100}}
function diffIfc(a,b){var ma={},mb={},add=[],rem=[],mod=[];a.els.forEach(function(e){ma[e.g]=e});b.els.forEach(function(e){mb[e.g]=e;if(!ma[e.g])add.push(e);else if(ma[e.g].name!==e.name||ma[e.g].t!==e.t)mod.push([ma[e.g],e])});a.els.forEach(function(e){if(!mb[e.g])rem.push(e)});return{add:add,rem:rem,mod:mod}}
function cmp(){if(st.sel.length!==2)return C.say('Cochez exactement 2 fichiers.','warn');var X=st.sel.map(function(i){return F().find(function(q){return q.id===i})}).filter(Boolean).sort(function(a,b){return a.ver<b.ver?-1:1});if(X.length!==2)return;
 if(X[0].ext!==X[1].ext&&!(/^(png|jpe?g|webp)$/.test(X[0].ext)&&/^(png|jpe?g|webp)$/.test(X[1].ext)))return C.say('Comparez deux fichiers de même format.','warn');
 if(!/^(dxf|ifc|png|jpe?g|webp)$/.test(X[0].ext))return C.say('Comparaison possible pour DXF, IFC et images. Exportez vos DWG/RVT/PDF dans l’un de ces formats.','warn');
 C.overlay('exbPlnV','⇄ Comparaison','<p style="color:#64748b">Analyse…</p>',1100);
 Promise.all([sceneOf(X[0]),sceneOf(X[1])]).then(function(S){var a=S[0],b=S[1],hd='<p><b>'+C.esc(X[0].ref)+'</b> ind. '+X[0].ver+' → ind. '+X[1].ver+'</p>';
  if(a.kind==='ifc'){var r=diffIfc(a,b),row=function(l,L,f){return L.length?'<h4 style="margin:8px 0 2px">'+l+' ('+L.length+')</h4><div style="max-height:22vh;overflow:auto;font-size:13px">'+L.slice(0,200).map(f).join('<br>')+(L.length>200?'<br>…':'')+'</div>':''};
   C.overlay('exbPlnV','⇄ Comparaison IFC',hd+C.kpis([['Ajoutés',r.add.length,'#e6f6ea'],['Supprimés',r.rem.length,'#fde8e8'],['Modifiés (nom/type)',r.mod.length,'#fff7e6']])+row('Ajoutés',r.add,function(e){return '+ '+C.esc(e.grp)+' — '+C.esc(e.name||e.g)})+row('Supprimés',r.rem,function(e){return '− '+C.esc(e.grp)+' — '+C.esc(e.name||e.g)})+row('Modifiés',r.mod,function(p){return '≠ '+C.esc(p[0].name)+' → '+C.esc(p[1].name)})+(r.add.length+r.rem.length+r.mod.length?'':'<p>✅ Aucune différence d’éléments détectée.</p>')+'<p style="font-size:12px;color:#64748b">Comparaison par identifiant d’élément ; les déplacements ou changements de géométrie ne sont pas détectés.</p><p><button onclick="EXBPLN.back()">← Liste</button></p>',900);return}
  if(a.kind==='dxf'){var r2=diffDxf(a,b),lr=Object.keys(r2.lay).sort(function(p,q){return(r2.lay[q][0]+r2.lay[q][1])-(r2.lay[p][0]+r2.lay[p][1])}).slice(0,10);
   show(X[1],{kind:'dxf',ents:b.ents,bbox:r2.bbox,layers:b.layers,layCol:b.layCol,blocks:b.blocks});V.cmp=r2;V.an=[];draw();var i=d.getElementById('plInfo');if(i)i.innerHTML='<b style="color:#d00000">Rouge : supprimé</b> · <b style="color:#00a000">Vert : ajouté</b> · gris : inchangé — '+r2.rem.length+' supprimé(s), '+r2.add.length+' ajouté(s), '+r2.same.length+' inchangé(s)'+(lr.length?'<br>Par calque (+ajoutés / −supprimés) : '+lr.map(function(k){return C.esc(k)+' +'+r2.lay[k][0]+' −'+r2.lay[k][1]}).join(' · '):'');return}
  var r3=diffImg(a.img,b.img);show(X[1],b);V.cmp=r3;V.an=[];draw();var j=d.getElementById('plInfo');if(j)j.innerHTML='<b style="color:#e11d48">Rouge : zones différentes</b> — '+r3.pct.toFixed(1)+' % de la surface ; les deux images doivent avoir le même cadrage et la même taille.'}).catch(function(e){C.overlay('exbPlnV','⇄ Comparaison','<p style="background:#fde8e8;padding:10px;border-radius:10px">'+C.esc(e.message||e)+'</p><p><button onclick="EXBPLN.back()">← Liste</button></p>')})}
w.EXBPLN={mfin:mfin,mundo:mundo,mabort:mabort,unit:unit,mdel:mdel,mcsv:mcsv,mmet:mmet,open:open,back:list,view:view,cmp:cmp,parseDxf:parseDxf,parseIfc:parseIfc,diffDxf:diffDxf,
 proj:function(v){st.pid=v;st.sel=[];list()},
 pick:function(id,on){var i=st.sel.indexOf(id);if(on&&i<0)st.sel.push(id);if(!on&&i>=0)st.sel.splice(i,1)},
 fileSel:function(inp){var f=inp.files&&inp.files[0];if(!f)return;readTag(f).then(function(t){var r=d.getElementById('plRef'),n=d.getElementById('plNote'),a=d.getElementById('plAuto'),ref=t?t.ref:refFromName(f.name);
   if(r&&(!r.value||r.dataset.auto==='1')){r.value=ref;r.dataset.auto='1'}if(n&&t&&(!n.value||n.dataset.auto==='1')){n.value=(t.titre||'')+(t.date?' · '+t.date:'');n.dataset.auto='1'}
   if(a)a.textContent=t?'✔ Référence reconnue : '+t.ref+(t.titre?' — '+t.titre:'')+(t.ouvrage?' ('+t.ouvrage+')':'')+'. Indice suivant : '+nextVer(t.ref,st.pid)+'.':'Référence déduite du nom du fichier : '+ref+' (modifiable).'})},
 add:function(){if(!canW())return C.say('Écriture non autorisée.','error');var f=d.getElementById('plFile').files[0];if(!f)return C.say('Choisissez un fichier.','warn');var e=ext(f.name);
  return readTag(f).then(function(t){var ref=C.val('plRef')||(t?t.ref:'')||refFromName(f.name);if(!ref)return C.say('Indiquez la référence du plan.','warn');return EXBPLN._add(f,ref,t,e)})},
 _add:function(f,ref,tag,e){
  if(!/^(dxf|ifc|dwg|rvt|rfa|pdf|png|jpe?g|webp)$/.test(e))return C.say('Format non pris en charge.','error');if(f.size>80*1048576)return C.say('Fichier trop volumineux (80 Mo maximum).','error');
  f.arrayBuffer().then(function(buf){var m={id:C.uid('PLF'),project:st.pid,ref:ref,ver:nextVer(ref,st.pid),name:f.name,ext:e==='jpeg'?'jpg':e,size:f.size,date:C.today(),note:C.val('plNote')||(tag?(tag.titre||''):''),dwg:e==='dwg'?dwgVer(buf):''};
   var bl=new Blob([buf],{type:f.type||'application/octet-stream'});return bput(m.id,bl).then(function(){if(!sbOn())return;m.path=cpath(m);return cput(m,bl).catch(function(){delete m.path})}).then(function(){try{if(w.EXB_ARCH)w.EXB_ARCH.linkPlanFile(m)}catch(e){}var a=F();a.push(m);w.EXBS.set(FK,a);C.say(m.path?'Fichier ajouté et partagé avec l’équipe (indice '+m.ver+').':'Fichier ajouté sur cet appareil (indice '+m.ver+') ; il sera partagé dès la connexion.');list();if(m.ext==='ifc'&&w.EXB_IFC3D){try{w.EXB_IFC3D.openText(new TextDecoder().decode(buf),m.ref+' ind. '+m.ver)}catch(x){}}})}).catch(function(x){C.say('Échec : '+(x&&x.message||x),'error')})},
 del:function(id){if(!canW())return;if(!w.confirm('Supprimer ce fichier et ses annotations ?'))return;var dx=F().find(function(q){return q.id===id});if(dx&&dx.path&&sbOn())w.exbSb.api('/storage/v1/object/'+BK+'/'+dx.path,{method:'DELETE'}).catch(function(){});bdel(id);try{if(w.EXB_ARCH)w.EXB_ARCH.unlinkPlanFile(id)}catch(e){}w.EXBS.set(FK,F().filter(function(x){return x.id!==id}));w.EXBS.set(AK,A().filter(function(x){return x.file!==id}));st.sel=st.sel.filter(function(i){return i!==id});list()},
 ifc3d:function(id){var x=F().find(function(q){return q.id===id});if(!x)return;if(!w.EXB_IFC3D)return C.say('Lecteur 3D indisponible.','error');getBlob(x).then(function(b){if(!b)throw new Error('Fichier absent.');return b.text()}).then(function(t){w.EXB_IFC3D.openText(t,x.ref+' ind. '+x.ver)}).catch(function(e){C.say(e.message||String(e),'error')})},
 tool:function(k){V.tool=k;V.mp=[];hl();mbar();draw()},fit:function(){fit()},
 layers:function(){var e=d.getElementById('plLay');if(e.innerHTML){e.innerHTML='';return}e.innerHTML='<div style="max-height:18vh;overflow:auto;background:#f8fafc;padding:6px;border-radius:8px">'+Object.keys(V.sc.layers).sort().map(function(l){return '<label style="display:inline-block;margin:2px 8px 2px 0;font-size:12px"><input type="checkbox" '+(V.hide[l]?'':'checked ')+'onchange="EXBPLN.lay(this.dataset.l,this.checked)" data-l="'+C.esc(l)+'"> '+C.esc(l)+' ('+V.sc.layers[l]+')</label>'}).join('')+'</div>'},
 lay:function(l,on){V.hide[l]=!on;draw()},
 anSt:function(id){var a=A(),n=a.find(function(x){return x.id===id});if(!n)return;n.status=n.status==='ouverte'?'traitée':'ouverte';w.EXBS.set(AK,a);V.an=a.filter(function(x){return x.file===V.x.id});draw();anList()},
 anDel:function(id){w.EXBS.set(AK,A().filter(function(x){return x.id!==id}));V.an=V.an.filter(function(x){return x.id!==id});draw();anList()},
 png:function(){var c=cv();if(!c)return;var u=c.toDataURL('image/png'),w2=w.open('','_blank');if(!w2)return C.say('Autorisez les fenêtres pop-up.','error');w2.document.write('<title>'+C.esc(V.x.ref)+'</title><body style="margin:0"><img src="'+u+'" style="max-width:100%"><p style="font:13px Arial;padding:8px">'+C.esc(V.x.ref)+' ind. '+C.esc(V.x.ver)+' — '+C.frDate(C.today())+'. Appui long / clic droit pour enregistrer, ou Ctrl+P pour imprimer.</p>');w2.document.close()}};
C.addButton('exbPlnBtn','🗂 Plans & fichiers CAO',open,COL);
})(window,document);
