# Accès encadreur : identifiant = matricule, ouvert dès la validation

- L'identifiant de connexion du portail encadreur est désormais son **matricule** (000-000-000), attribué automatiquement s'il n'en a pas (formulaire, validation, ou publication des portails). Page de connexion : « Matricule encadreur ».
- L'accès s'ouvre **dès que l'encadreur est validé** (TFL › Encadreurs › Formulaire › « ✔ Valider cet encadreur »), sans attendre d'affectation : il y voit ses sujets proposés (Reçu / Retenu / Refusé / Complément + motif).
- Mise en place : valider l'encadreur → TFL › Portails › **Publier** → envoyer le lien puis le mot de passe de départ (6 chiffres) dans deux messages séparés ; il le remplace à sa première connexion.
- Les encadreurs qui avaient un ancien code `ENC-xxxx` passent au matricule : l'ancien accès est désactivé à la publication et un **nouveau mot de passe de départ** est à leur communiquer (« 🔑 Nouveau mot de passe »).
- Un encadreur non validé n'a aucun accès ; le validation d'un sujet d'étudiant reste possible une fois un dossier accepté et affecté.
