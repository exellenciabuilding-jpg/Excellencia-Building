/* Excellencia Building — application Windows (Electron).
 * Le logiciel (dossier www/) est servi par un protocole interne « app://excellencia/ » :
 * adresse FIXE et sécurisée → IndexedDB, mots de passe/licences et sauvegardes locales restent toujours au même endroit
 * (avec un serveur à port aléatoire ou file://, les données « disparaîtraient » d'un lancement à l'autre). */
const { app, BrowserWindow, protocol, net, shell, session, Menu } = require('electron');
const path = require('path'), fs = require('fs'), { pathToFileURL } = require('url');

const ROOT = path.join(__dirname, 'www');
const HOST = 'excellencia';
protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);

if (!app.requestSingleInstanceLock()) { app.quit(); }
let win = null;
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

function createWindow() {
  win = new BrowserWindow({
    width: 1366, height: 860, minWidth: 900, minHeight: 600, show: false, backgroundColor: '#ffffff',
    title: 'Excellencia Building',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false }
  });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  /* liens externes → navigateur ; pages internes (fiches, éditeur de plans…) → nouvelle fenêtre */
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (/^https?:/i.test(url)) { e.preventDefault(); shell.openExternal(url); }
  });
  /* F11 plein écran, F12 outils de développement (diagnostic) */
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    if (i.key === 'F12') { win.webContents.toggleDevTools(); e.preventDefault(); }
  });
  win.on('closed', () => { win = null; });
  win.loadURL('app://' + HOST + '/index.html');
}

app.whenReady().then(() => {
  protocol.handle('app', (req) => {
    try {
      const u = new URL(req.url);
      if (u.hostname !== HOST) return new Response('Not found', { status: 404 });
      let p = decodeURIComponent(u.pathname);
      let f = path.normalize(path.join(ROOT, p));
      if (f !== ROOT && !f.startsWith(ROOT + path.sep)) return new Response('Forbidden', { status: 403 });
      if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
      if (!fs.existsSync(f)) return new Response('Not found', { status: 404 });
      return net.fetch(pathToFileURL(f).toString());
    } catch (e) { return new Response('Erreur : ' + e.message, { status: 500 }); }
  });
  /* caméra / micro (photos, signature, QR), presse-papiers, plein écran : autorisés pour le logiciel uniquement */
  const OK = new Set(['media', 'clipboard-read', 'clipboard-sanitized-write', 'fullscreen', 'notifications', 'geolocation']);
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(OK.has(perm) && /^app:\/\//.test(wc.getURL())));
  createWindow();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
