# Excellencia Building — application Windows (Electron)

Même logiciel (`site/`) dans une vraie fenêtre Windows : installateur `.exe` + version portable (sans installation).

## Fabriquer le .exe
### Option A — GitHub (sans PC de développement)
1. Envoyez tout ce dossier sur votre dépôt GitHub (comme pour Android).
2. Onglet **Actions** → « Construire l'application Windows » → **Run workflow** (≈ 5 min).
3. Téléchargez l'artefact `excellencia-building-windows` : `…-nsis.exe` (installateur) et `…-portable.exe`.

### Option B — sur un PC Windows (Node 20)
```
cd electron
npm install
npm start          # lance l'application pour essai
npm run dist       # fabrique les .exe dans electron/dist
```

## À savoir
- Les données de travail restent sur la machine (IndexedDB), à l'adresse interne fixe `app://excellencia/` : elles ne changent pas d'un lancement à l'autre.
- **Les données Android et Windows sont séparées** : pour passer de l'une à l'autre, utilisez « Sauvegarde complète » puis « Restaurer ».
- Les PDF / images exportés ouvrent la fenêtre « Enregistrer sous » de Windows.
- **F11** : plein écran · **F12** : outils de diagnostic (utile si un souci apparaît ; envoyez-moi la capture de l'onglet « Console »).
- Windows SmartScreen affichera « éditeur inconnu » tant que l'exécutable n'est pas signé (certificat de signature payant) : « Informations complémentaires » → « Exécuter quand même ».
- Je n'ai pas pu lancer Electron ici (pas de réseau) : faites un premier essai et dites-moi ce qui se passe.

---
## Mise à jour — éditeur de plan V4.4
Cette version embarque l'éditeur de plan V4.4 (cartouche professionnel, impression à l'échelle, escaliers quart tournant / en U, trémies, toits multiples et toit libre, synchronisation des plans avec le compte). L'icône et le nom « Excellencia Building » sont inchangés.

## Mise à jour — rendu réaliste (V4.5)
La vue 3D de l'éditeur de plan gagne : soleil réglable avec ombres, ciel, matériaux (carrelage, parquet, enduit, tuiles), fenêtres et portes détaillées, toit avec gouttières, extérieur (pelouse, clôture, portail, arbres, route). Boutons ☀ / ◐ Ombres / 🌳 Extérieur dans la barre 3D.


---
## Mise à jour — boutons flottants (V99 mobile-ux)
Les boutons flottants (🤖 🔑 ❓ 🔔 🗄) se déplacent par glisser ; clic droit ou maintien pour les regrouper, les réduire ou les remettre en place (Paramètres > « Boutons flottants »). Détails : LISEZ-MOI-MOBILE-UX.md.
