# V121f — Vérification des cartes d'apprenant + APK scanner (pour vous seul)

Tout est dans CE dépôt : vous le déposez une seule fois, rien d'autre à envoyer.

## 1. Déposer
Remplacez le contenu de votre dépôt GitHub privé par ce dossier (ou glissez les fichiers modifiés : site/verification.html, site/sw.js, scanner-apk/, .github/workflows/apk-scanner.yml).
Le site Netlify se republie par le flux habituel (site-netlify).

## 2. Ce qui est corrigé (site/verification.html, site/sw.js)
Le QR de la carte d'apprenant (verification.html?m=MATRICULE) restait sur « Recherche dans le registre… » car seule la carte TFL était cherchée.
Maintenant, si le matricule n'est pas TFL, la page regarde les documents enregistrés à ce matricule :
- au moins un document valide : « ✅ Carte authentique — apprenant enregistré » (nom, matricule, formation) ;
- tous annulés : avertissement orange ;
- aucun : « ❌ Matricule non reconnu ».
sw.js : version de cache v121f (force le rechargement de la page sur les téléphones).
Aucune modification Supabase.
Test : après republication, rouvrez le QR d'une carte ; si l'ancienne page s'affiche, fermez complètement Chrome et rouvrez.

## 3. Excellencia Building Scanner (APK, pour vous seul) — dossier scanner-apk/
Application de numérisation de documents selon votre maquette : écran de chargement, Accueil (Nouveau Scan, Importer des fichiers, Mes documents, Mes dossiers, Recherche avancée, Paramètres), barre Accueil/Récents/Favoris/Corbeille.
- Nouveau Scan : appareil photo du téléphone › éditeur (Recadrer, Rotation, filtres Original / N&B / Gris / Contraste, Améliorer) › « Ajouter une page » › enregistrement en PDF multipages.
- Importer des fichiers : images de la galerie, converties en PDF.
- Mes documents : filtres Tous / PDF / Images / Plans (un nom contenant « plan »), menu ⋮ (favori, renommer, déplacer, partager, corbeille).
- Mes dossiers, Recherche par nom, Paramètres (espace utilisé, code à 4 chiffres).
- « Vérifier le QR d'une carte / d'un document » (page d'accueil) : scanne le QR et affiche la vérification dans l'application.
Construire l'APK : GitHub › Actions › « APK Scanner QR (pour vous seul) » › Run workflow › télécharger EXB-Scanner-apk › installer EXB-Scanner.apk.
Identité : logo Excellencia Building du logiciel (scanner-apk/www/logo.png), bleu #173565 et doré #c49a38, image d'en-tête d'accueil (scanner-apk/www/banniere.jpg), icône de l'application = logo Excellencia.
Personnalisation (Paramètres › 🎨 Personnalisation) : nom, slogan, message de bienvenue, adresse du site pour les QR, couleurs bleu/doré, image d'en-tête et logo (choisis dans la galerie), bouton « Rétablir Excellencia Building ». Les réglages sont conservés sur le téléphone.
Limites de cette première version : pas de détection automatique des bords (recadrage manuel au doigt), pas de flash dédié, pas d'import de PDF existants, thème = réglage du téléphone.
⚠ Ne donnez pas cet APK aux clients/apprenants.

## 4. Notifications (comme le logiciel central)
- Cloche 🔔 en haut à droite de chaque écran, avec pastille rouge du nombre de notifications non lues (99+ au maximum). Elle sonne à chaque nouvelle notification.
- Touchez la cloche : liste des dernières notifications (non lues surlignées), « Tout marquer comme lu », « Vider ».
- Messages en haut de l'écran : carte avec barre de couleur — vert = réussi (PDF généré, lien enregistré), jaune = attention (corbeille, hors connexion), rouge = échec (QR non reconnu, caméra refusée), bleu = information. Messages identiques regroupés (×2, ×3), 4 cartes maximum.
- Hors connexion : pastille rouge « Hors connexion » + notification avec l'heure de la dernière synchronisation ; « Connexion rétablie » au retour du réseau.
- Les notifications sont conservées sur le téléphone (100 dernières).

## 5. Onglet « Vérifier » (liens de vérification)
Cinquième onglet de la barre du bas : Accueil, Récents, Favoris, **Vérifier**, Corbeille.
- Deux liens au départ : « Documents — logiciel central » (déjà rempli) et « Licences » (à renseigner : collez l'adresse du site des licences).
- Pour chaque lien : 📷 Scanner (QR), ⌨ Saisir un code (matricule ou numéro), ✏️ Modifier.
- « ＋ Ajouter un lien » : autant de liens que nécessaire.
- Adresse : collez l'adresse du site. Si la page attend un code, écrivez {code} là où il doit apparaître (ex. https://site/licence?c={code}). Sans {code}, une adresse terminée par / utilise verification.html?m=…
- Un QR qui contient une adresse est accepté seulement si son site correspond à un des liens enregistrés ; l'application ouvre alors le bon lien. Un QR qui ne contient qu'un code utilise le lien choisi (ou le premier lien renseigné depuis l'accueil).
