# V121i — Dossier de différences (lots 7, 8 intégrés + lot 9 « charge »)

Base : votre dépôt v121f. Ce dossier ne contient QUE ce qui change, avec les mêmes chemins que le dépôt : copiez-le par-dessus votre dépôt (les fichiers identiques sont écrasés, rien n'est supprimé), puis publiez comme d'habitude.

## Contenu
Modifiés : site/exb-intelligence.js, site/index.html, site/sw.js, site/tools/check.js
Ajoutés : site/exb-intelligence-7.js, -8.js, -9.js ; site/tools/test-intelligence-7.js, -8.js, -9.js ; 3 README (lots 7, 8, 9) ; ce fichier.

## Vérifications faites
test-intelligence-7 : 33/33 · -8 : 33/33 · -9 : 70/70 · check.js : 518 réussis, 0 échec.
Non testé avec votre vrai Supabase ni sur téléphone : commencez avec la réception en « Demander ».
Après publication, fermez complètement l'application une fois (version v121i).
