# V122b+V121j — une seule version
Base : v121j (Intelligence lots 7-8-9, en-têtes de sécurité Netlify, anti-blocage…)
Ajout : v122b (analyse de structure « type Robot » : Portique 2D EF, combinaisons d'actions, contrôle EF du module Poutre).
Fichiers repris de la v122b : site/calcul-structure/ (exb-robot-analyse.js, index.html, validation/), exb-calcul-structure.js, exb-v99r-shell.js, package.json (test:calcul).
Service worker : cache v122b-robot-analyse-v121i-… + exb-robot-analyse.js précaché.
