# V117d — Impression / PDF : fin de l'écran blanc

## Le problème
Les boutons « Imprimer / PDF » (liste des paiements des apprenants, planning de chantier, devis rapide, pièces écrites,
plans, QCM, cartes, reçus TFL…) ouvraient une **fenêtre pop-up vide** puis y écrivaient le document.
Dans l'application Android, ces pop-up n'existent pas ; sous Windows la fenêtre restait blanche ; dans le navigateur elle était bloquée.

## La correction
Nouveau fichier `site/exb-print.js` (chargé dans `index.html`, `tfl-portail.html`, `portail.html`) : **plus aucune fenêtre pop-up**.

| Où vous êtes | Ce qui se passe au clic sur « Imprimer / PDF » |
|---|---|
| Windows (application) | le PDF est créé directement → « Enregistrer sous » → ouvert dans le lecteur PDF |
| Android (nouvel APK) | la boîte d'impression d'Android s'ouvre → « Enregistrer au format PDF » ou imprimante |
| Navigateur (PC / téléphone) | aperçu plein écran dans le logiciel + impression automatique sur ordinateur ; boutons Imprimer / Enregistrer / Fermer |
| Android, ancien APK | aperçu plein écran + bouton « Enregistrer » (le document est enregistré dans Documents puis partageable) |

`window.print()` fonctionne aussi dans l'application Android (il ne faisait rien avant) : métré, devis, étiquettes QR d'équipements…

## Modules corrigés
Paiements des apprenants · Planning de Gantt · Devis rapide / Pièces écrites / rapports (noyau V81) · Rapport de pilotage ·
Feuilles de plans (V72) · Cartouche des plans (V80) · Image d'un plan (V81) · Résultat QCM · Cartes de travail ·
Documents signés (portails) · Reçu TFL (administrateur) · Prévisualisation du formulaire d'inscription ·
Impression d'un document de la bibliothèque · « Imprimer » le dernier PDF · reçu et bordereau TFL (tfl-portail.html) ·
attestation de signature (portail.html).

Les exports **Budget** (Planning › Budget, Finance › Budget & pilotage : mensuel, annuel, comparatif, fiche client) et le
métré/devis maître utilisaient déjà un vrai PDF : testés, ils produisent bien un fichier PDF valide.

## À faire de votre côté
1. Déposer ce ZIP sur GitHub comme d'habitude (le nom du ZIP est conservé : `Excellencia-V117d-POUR-GITHUB`).
2. Lancer la construction de l'APK : `scripts/patch-android.js` ajoute tout seul la classe `ExbPrint.java` et la branche dans `MainActivity.java`
   (c'est ce qui active la boîte d'impression d'Android). **Réinstaller le nouvel APK** pour en profiter.
3. Windows : refaire l'installateur (le fichier `exb-print.js` est copié automatiquement dans `www/`).
4. Netlify : le logiciel en ligne prend `exb-print.js` automatiquement (le cache hors connexion est renouvelé : `sw.js` v117d).

## Tests effectués ici (Chromium sans tête, application complète)
- Paiements des apprenants, planning de Gantt et devis rapide : document complet reçu et sans script dans les 3 cas
  (navigateur → aperçu ; Windows → PDF direct ; Android → impression native), aucune erreur JavaScript ;
- 4 exports PDF de budget : fichiers PDF valides ;
- Syntaxe de tous les fichiers modifiés vérifiée, et du script Android simulé sur un projet de test.

## Limite à connaître
Je n'ai pas pu compiler l'APK ni l'installateur Windows, ni imprimer sur un vrai téléphone ou une vraie imprimante ici.
Premier essai conseillé : Participants › Paiements › « 📄 Imprimer / PDF », puis Planning › « 🖨 Imprimer / PDF ».
