/* ÉDITION PROPRIÉTAIRE UNIQUEMENT — bouton « 🔑 Licences » : ouvre la gestion des licences (licences/index.html) par-dessus le logiciel.
 * Ce fichier et le dossier licences/ n'existent que dans dist/proprietaire (scripts/build-editions.js) ; l'édition publique n'en contient aucune trace. */
(function () {
  'use strict';
  var SERVER = '__LICENCE_URL__';
  function open() {
    if (document.getElementById('exbLicOv')) return;
    var src = 'licences/index.html' + (SERVER ? '?url=' + encodeURIComponent(SERVER) : '');
    var d = document.createElement('div'); d.id = 'exbLicOv'; d.style.cssText = 'position:fixed;inset:0;z-index:100003;background:#f4f6fa;display:flex;flex-direction:column';
    d.innerHTML = '<div style="display:flex;gap:8px;justify-content:flex-end;padding:6px 10px;background:#173565"><a href="' + src + '" target="_blank" rel="noopener" style="color:#fff;font:14px system-ui;padding:6px 10px">↗ Nouvel onglet</a><button id="exbLicX" style="border:0;border-radius:8px;padding:6px 12px;background:#f5a623;font:700 14px system-ui;cursor:pointer">✕ Fermer</button></div><iframe src="' + src + '" style="border:0;flex:1;width:100%" title="Licences clients"></iframe>';
    document.body.appendChild(d); document.getElementById('exbLicX').onclick = function () { d.remove(); };
  }
  window.exbOpenLicences = open;
  function btn() {
    if (document.getElementById('exbLicBtn')) return;
    var b = document.createElement('button'); b.id = 'exbLicBtn'; b.textContent = '🔑 Licences'; b.title = 'Gérer les licences des clients (propriétaire)';
    b.style.cssText = 'position:fixed;right:14px;bottom:70px;z-index:100001;border:0;border-radius:99px;padding:10px 16px;background:#173565;color:#fff;font:700 14px system-ui;box-shadow:0 4px 14px #0004;cursor:pointer';
    b.onclick = open; document.body.appendChild(b);
  }
  /* le bouton n'apparaît que pour l'administrateur (clé privée acceptée) ; il disparaît si la clé est retirée */
  function sync() { var adm = false; try { adm = !!(window.EXBLIC && window.EXBLIC.isAdmin()); } catch (e) {} var b = document.getElementById('exbLicBtn'); if (adm && !b) btn(); else if (!adm && b) b.remove(); }
  setInterval(sync, 1000); if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sync); else sync();
})();
