const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('ownerApp', {
  defaults: () => ipcRenderer.invoke('own:defaults'),
  load: () => ipcRenderer.invoke('own:load'),
  save: (cfg) => ipcRenderer.invoke('own:save', cfg),
  clear: () => ipcRenderer.invoke('own:clear'),
  saveFile: (name, text) => ipcRenderer.invoke('own:save-file', name, text)
});
