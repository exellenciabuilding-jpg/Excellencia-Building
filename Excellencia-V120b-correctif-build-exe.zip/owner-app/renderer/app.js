/* Excellencia Licences — interface propriétaire (V120o). Parle au serveur de licences (fonction Supabase « licence ») avec la clé d'administration. */
(function () {
  'use strict';
  var DAY = 864e5, $ = function (id) { return document.getElementById(id); };
  var S = { url: '', key: '', clients: [], sel: null, filter: 'all', q: '', timer: null };
  var dlg = $('dlg'), resolver = null;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmtD(iso) { try { return new Date(iso).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return iso; } }
  function fmtDT(iso) { try { return new Date(iso).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch (e) { return iso; } }
  function toast(m) { var t = $('toast'); t.textContent = m; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(function () { t.hidden = true; }, 3200); }
  function copy(txt, ok) { (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { toast(ok || 'Copié.'); }, function () { toast('Copie impossible : sélectionnez le texte.'); }); }
  function ago(iso) {
    if (!iso) return null; var m = Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 60000));
    if (m < 2) return 'à l’instant'; if (m < 60) return 'il y a ' + m + ' min'; var h = Math.round(m / 60); if (h < 36) return 'il y a ' + h + ' h'; return 'il y a ' + Math.round(h / 24) + ' j';
  }

  /* ---------- serveur ---------- */
  async function api(action, data) {
    if (!S.url || !S.key) throw new Error('Non connecté.');
    var r;
    try { r = await fetch(S.url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-key': S.key }, body: JSON.stringify(Object.assign({ action: 'admin.' + action }, data || {})), signal: AbortSignal.timeout ? AbortSignal.timeout(20000) : undefined }); }
    catch (e) { setNet(false); throw new Error('Serveur injoignable. Vérifiez la connexion internet et l’adresse du serveur.'); }
    var j = null; try { j = await r.json(); } catch (e) { /* non JSON */ }
    setNet(true);
    if (!j) throw new Error('Réponse inattendue du serveur (' + r.status + ').');
    if (!j.ok) throw new Error(j.msg || 'Erreur ' + r.status);
    return j;
  }
  function setNet(on) { var n = $('net'); n.className = 'net ' + (on ? 'on' : 'off'); n.textContent = on ? '● serveur connecté' : '● serveur injoignable'; }

  /* ---------- état d'un client ---------- */
  function info(c) {
    var exp = Date.parse(c.expire_le), g = c.grace_jours * DAY, left = exp - Date.now(), days = Math.ceil(left / DAY);
    if (c.statut === 'revoque') return { k: 'rev', t: 'Révoqué', cls: 'p-gy', days: days };
    if (c.statut === 'suspendu') return { k: 'sus', t: 'Suspendu', cls: 'p-wn', days: days };
    if (left <= -g) return { k: 'exp', t: 'Expiré', cls: 'p-er', days: days };
    if (left <= 0) return { k: 'grace', t: 'Tolérance', cls: 'p-er', days: days };
    if (days <= 30) return { k: 'renew', t: 'À renouveler', cls: 'p-wn', days: days };
    return { k: 'ok', t: 'Actif', cls: 'p-ok', days: days };
  }
  function lastSeen(c) { var m = null; (c.appareils || []).forEach(function (a) { if (!m || a.dernier_vu > m) m = a.dernier_vu; }); return m; }
  function expTxt(i) { return i.days > 0 ? 'dans ' + i.days + ' j' : i.days === 0 ? 'aujourd’hui' : 'dépassée de ' + (-i.days) + ' j'; }

  /* ---------- liste ---------- */
  function visible() {
    var q = S.q.trim().toLowerCase();
    return S.clients.filter(function (c) {
      var i = info(c);
      if (q && (c.nom + ' ' + c.slug + ' ' + (c.notes || '')).toLowerCase().indexOf(q) < 0) return false;
      if (S.filter === 'renew') return i.k === 'renew' || i.k === 'grace';
      if (S.filter === 'expired') return i.k === 'exp';
      if (S.filter === 'suspended') return i.k === 'sus' || i.k === 'rev';
      return true;
    }).sort(function (a, b) { return Date.parse(a.expire_le) - Date.parse(b.expire_le); });
  }
  function render() {
    var n = { ok: 0, renew: 0, exp: 0, sus: 0 };
    S.clients.forEach(function (c) { var k = info(c).k; if (k === 'ok') n.ok++; else if (k === 'renew' || k === 'grace') n.renew++; else if (k === 'exp') n.exp++; else n.sus++; });
    $('tiles').innerHTML = '<div class="tile g"><b>' + (n.ok + n.renew) + '</b><span>clients actifs</span></div><div class="tile w"><b>' + n.renew + '</b><span>à renouveler (30 j)</span></div><div class="tile e"><b>' + n.exp + '</b><span>expirés</span></div><div class="tile"><b>' + n.sus + '</b><span>suspendus / révoqués</span></div>';
    var rows = visible();
    $('rows').innerHTML = rows.map(function (c) {
      var i = info(c), ls = lastSeen(c), old = ls && Date.now() - Date.parse(ls) > 7 * DAY, nb = (c.appareils || []).length;
      return '<tr data-id="' + esc(c.id) + '"' + (S.sel === c.id ? ' class="sel"' : '') + '><td class="nm"><b>' + esc(c.nom) + '</b><small>' + esc(c.slug) + '</small></td>'
        + '<td><span class="pill ' + i.cls + '">' + i.t + '</span></td>'
        + '<td>' + esc(fmtD(c.expire_le)) + '<br><small class="' + (i.days <= 30 ? 'warn-txt' : 'muted') + '">' + expTxt(i) + '</small></td>'
        + '<td>' + nb + ' / ' + c.max_appareils + '</td>'
        + '<td>' + (ls ? (old ? '<span class="warn-txt">⚠ ' + ago(ls) + '</span>' : ago(ls)) : '<span class="muted">jamais activé</span>') + '</td></tr>';
    }).join('');
    $('empty').hidden = rows.length > 0; $('empty').textContent = S.clients.length ? 'Aucun client ne correspond.' : 'Aucun client pour le moment. Cliquez sur « Nouveau client ».';
    if (S.sel) drawer();
  }

  /* ---------- fiche client ---------- */
  function drawer() {
    var c = S.clients.filter(function (x) { return x.id === S.sel; })[0], d = $('drawer');
    if (!c) { d.hidden = true; S.sel = null; document.body.classList.remove('has-drawer'); return; }
    document.body.classList.add('has-drawer');
    var i = info(c), devs = (c.appareils || []).slice().sort(function (a, b) { return a.premier_vu < b.premier_vu ? -1 : 1; });
    d.hidden = false;
    d.innerHTML = '<button class="x" data-act="close" aria-label="Fermer">×</button><h2>' + esc(c.nom) + '</h2><span class="pill ' + i.cls + '">' + i.t + '</span>'
      + '<dl class="kv"><dt>Échéance</dt><dd>' + esc(fmtD(c.expire_le)) + ' <span class="muted">(' + expTxt(i) + ')</span></dd>'
      + '<dt>Tolérance</dt><dd>' + c.grace_jours + ' jour(s) après l’échéance</dd>'
      + '<dt>Appareils</dt><dd>' + devs.length + ' sur ' + c.max_appareils + ' autorisés</dd>'
      + '<dt>Code</dt><dd>EXC-••••-••••-' + esc(c.code_fin || '••••') + '</dd>'
      + '<dt>Créé le</dt><dd>' + esc(fmtD(c.cree_le)) + '</dd>'
      + (c.notes ? '<dt>Notes</dt><dd>' + esc(c.notes) + '</dd>' : '') + '</dl>'
      + '<div class="sec"><h3>Actions</h3><div class="acts">'
      + '<button class="btn" data-act="renew">🔄 Renouveler</button>'
      + (c.statut === 'actif' ? '<button class="btn warn" data-act="suspend">⏸ Suspendre</button>' : c.statut === 'suspendu' ? '<button class="btn" data-act="resume">▶ Réactiver</button>' : '<button class="btn" data-act="resume">▶ Réactiver</button>')
      + '<button class="btn soft" data-act="edit">✎ Modifier</button><button class="btn soft" data-act="newcode">🔑 Nouveau code</button>'
      + (c.statut !== 'revoque' ? '<button class="btn danger" data-act="revoke">⛔ Révoquer</button>' : '<button class="btn danger" data-act="remove">🗑 Supprimer</button>') + '</div></div>'
      + '<div class="sec"><h3>Appareils enregistrés</h3>' + (devs.length ? devs.map(function (a) {
        return '<div class="dev"><div><code>' + esc(a.device_id.replace(/(.{4})(?=.)/g, '$1-')) + '</code> <span class="muted small">' + esc([a.plateforme, a.libelle].filter(Boolean).join(' · ')) + '</span><br><span class="small muted">vu ' + esc(ago(a.dernier_vu)) + ' · depuis le ' + esc(fmtD(a.premier_vu)) + '</span></div><button class="btn sm ghost" data-act="release" data-dev="' + esc(a.device_id) + '">Libérer</button></div>';
      }).join('') : '<p class="muted small">Aucun appareil : le client n’a pas encore saisi son code.</p>') + '</div>'
      + '<div class="sec"><h3>Journal</h3><div id="jr" class="muted small">Chargement…</div></div>';
    api('journal', { id: c.id }).then(function (r) {
      var e = $('jr'); if (!e || S.sel !== c.id) return;
      var L = { cree: 'Client créé', appareil_enregistre: 'Appareil enregistré', appareil_libere: 'Appareil libéré', renouvele: 'Renouvelé', modifie: 'Modifié', statut_suspendu: 'Suspendu', statut_actif: 'Réactivé', statut_revoque: 'Révoqué', code_regenere: 'Nouveau code généré', activation_refusee: 'Activation refusée' };
      e.innerHTML = r.journal.length ? r.journal.map(function (j) { return '<div class="jr"><time>' + esc(fmtDT(j.quand)) + '</time>' + esc(L[j.evenement] || j.evenement) + (j.detail && j.detail.raison ? ' (' + esc(j.detail.raison) + ')' : '') + '</div>'; }).join('') : 'Rien pour le moment.';
    }, function () { var e = $('jr'); if (e) e.textContent = 'Journal indisponible.'; });
  }

  /* ---------- boîtes de dialogue ---------- */
  function openDlg(html) { dlg.innerHTML = '<div class="dl">' + html + '</div>'; if (!dlg.open) dlg.showModal(); }
  dlg.addEventListener('close', function () { if (resolver) { var r = resolver; resolver = null; r(false); } });
  function closeDlg(v) { var r = resolver; resolver = null; if (dlg.open) dlg.close(); if (r) r(v); }
  function ask(title, body, okLabel, kind) {
    return new Promise(function (res) {
      resolver = res;
      openDlg('<h2>' + esc(title) + '</h2><p>' + body + '</p><div class="foot"><button class="btn ghost" data-r="0">Annuler</button><button class="btn ' + (kind || '') + '" data-r="1" id="okb">' + esc(okLabel || 'Confirmer') + '</button></div>');
      dlg.querySelector('[data-r="0"]').onclick = function () { closeDlg(false); }; dlg.querySelector('[data-r="1"]').onclick = function () { closeDlg(true); };
    });
  }
  function form(title, html, okLabel, onOk) {
    openDlg('<h2>' + esc(title) + '</h2>' + html + '<div class="err" id="ferr"></div><div class="foot"><button class="btn ghost" id="fno">Annuler</button><button class="btn" id="fok">' + esc(okLabel) + '</button></div>');
    $('fno').onclick = function () { closeDlg(false); };
    $('fok').onclick = async function () { var b = this; b.disabled = true; $('ferr').textContent = ''; try { await onOk(); } catch (e) { $('ferr').textContent = e.message || String(e); } b.disabled = false; };
    var f = dlg.querySelector('input,select,textarea'); if (f) f.focus();
  }
  var DUR = '<option value="30">1 mois (30 jours)</option><option value="90">3 mois (90 jours)</option><option value="180">6 mois (180 jours)</option><option value="365" selected>1 an (365 jours)</option><option value="730">2 ans (730 jours)</option>';
  var dateInput = function (iso) { var d = new Date(iso); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

  function showCode(c, code, exp, max) {
    var msg = 'Bonjour,\n\nVoici votre accès au logiciel ' + c.nom + ' :\n1. Installez l’application (APK sur Android, EXE sur Windows) ou ouvrez le lien que nous vous avons envoyé.\n2. Sur l’écran « Logiciel verrouillé », saisissez votre code d’activation :\n\n    ' + code + '\n\n3. Validez. L’appareil s’enregistre tout seul (jusqu’à ' + max + ' appareil' + (max > 1 ? 's' : '') + ').\n\nAbonnement valable jusqu’au ' + fmtD(exp) + '. Pensez à connecter l’application à internet au moins une fois par semaine.';
    openDlg('<h2>Code d’activation de ' + esc(c.nom) + '</h2><div class="codebox" id="cbx">' + esc(code) + '</div>'
      + '<p class="small warn-txt">Ce code n’est affiché qu’une seule fois. Si vous le perdez, utilisez « Nouveau code » (les appareils déjà enregistrés continuent de fonctionner).</p>'
      + '<label>Message à envoyer au client</label><textarea id="cmsg" rows="9" readonly>' + esc(msg) + '</textarea>'
      + '<div class="foot"><button class="btn ghost" id="cc1">Copier le code</button><button class="btn" id="cc2">Copier le message</button><button class="btn soft" id="cc3">Fermer</button></div>');
    $('cc1').onclick = function () { copy(code, 'Code copié.'); }; $('cc2').onclick = function () { copy(msg, 'Message copié.'); }; $('cc3').onclick = function () { closeDlg(); };
  }

  function newClient() {
    form('Nouveau client', '<label>Nom du client</label><input id="fn" placeholder="Ex. Bâtiment Plus SARL" autocomplete="off">'
      + '<div class="row"><div><label>Durée</label><select id="fd">' + DUR + '</select></div><div><label>Appareils autorisés</label><input id="fm" type="number" min="1" max="10" value="2"></div></div>'
      + '<label>Jours de tolérance après l’échéance</label><input id="fg" type="number" min="0" max="365" value="7">'
      + '<label>Notes (facultatif)</label><input id="ft" placeholder="Ex. a payé le 12/10 — contact : +243…" autocomplete="off">', 'Créer le client', async function () {
        var nom = $('fn').value.trim(); if (!nom) throw new Error('Saisissez le nom du client.');
        var r = await api('create', { nom: nom, jours: Number($('fd').value), max_appareils: Number($('fm').value), grace_jours: Number($('fg').value), notes: $('ft').value.trim() || null });
        await load(); S.sel = r.client.id; render(); showCode(r.client, r.code, r.client.expire_le, r.client.max_appareils);
      });
  }
  function renew(c) {
    var base = function () { return Math.max(Date.now(), Date.parse(c.expire_le)); };
    form('Renouveler ' + c.nom, '<label>Prolonger de</label><select id="rj">' + DUR + '</select><p class="muted small" id="rp"></p><p class="small muted">La prolongation s’ajoute à la fin de l’abonnement (ou part d’aujourd’hui s’il est dépassé). Le logiciel du client reçoit la nouvelle échéance <b>tout seul</b>, sans nouveau code.</p>', 'Renouveler', async function () {
      await api('renew', { id: c.id, jours: Number($('rj').value) }); closeDlg(); await load(); toast('Abonnement renouvelé.');
    });
    var upd = function () { $('rp').innerHTML = 'Nouvelle échéance : <b>' + esc(fmtD(new Date(base() + Number($('rj').value) * DAY).toISOString())) + '</b>'; };
    $('rj').onchange = upd; upd();
  }
  function edit(c) {
    form('Modifier ' + c.nom, '<label>Nom</label><input id="en" value="' + esc(c.nom) + '">'
      + '<div class="row"><div><label>Échéance exacte</label><input id="ee" type="date" value="' + dateInput(c.expire_le) + '"></div><div><label>Appareils autorisés</label><input id="em" type="number" min="1" max="10" value="' + c.max_appareils + '"></div></div>'
      + '<label>Jours de tolérance</label><input id="eg" type="number" min="0" max="365" value="' + c.grace_jours + '">'
      + '<label>Notes</label><input id="et" value="' + esc(c.notes || '') + '">', 'Enregistrer', async function () {
        var p = { nom: $('en').value.trim(), max_appareils: Number($('em').value), grace_jours: Number($('eg').value), notes: $('et').value.trim() || null };
        if ($('ee').value && $('ee').value !== dateInput(c.expire_le)) p.expire_le = new Date($('ee').value + 'T23:59:00').toISOString();
        await api('update', { id: c.id, patch: p }); closeDlg(); await load(); toast('Modifications enregistrées.');
      });
  }
  function connexion() {
    form('Connexion au serveur de licences', '<label>Adresse du serveur</label><input id="cu" placeholder="https://xxxx.supabase.co/functions/v1/licence" value="' + esc(S.url) + '" autocomplete="off">'
      + '<label>Clé d’administration</label><input id="ck" type="password" placeholder="adm_…" value="' + esc(S.key) + '" autocomplete="off">'
      + '<p class="small muted">La clé est dans <code>ADMIN-KEY-LICENCES.txt</code>. Elle est mémorisée sur cet ordinateur, chiffrée par Windows.</p>', 'Se connecter', async function () {
        var u = $('cu').value.trim(), k = $('ck').value.trim();
        if (!/^https?:\/\//.test(u)) throw new Error('L’adresse doit commencer par https://');
        if (!k) throw new Error('Saisissez la clé d’administration.');
        var oldU = S.url, oldK = S.key; S.url = u; S.key = k;
        try { await api('list'); } catch (e) { S.url = oldU; S.key = oldK; throw e; }
        await persist(); closeDlg(); await load(); toast('Connecté.');
      });
  }

  /* ---------- actions ---------- */
  async function act(a, dev) {
    var c = S.clients.filter(function (x) { return x.id === S.sel; })[0]; if (!c) return;
    try {
      if (a === 'close') { S.sel = null; $('drawer').hidden = true; document.body.classList.remove('has-drawer'); render(); return; }
      if (a === 'renew') return renew(c);
      if (a === 'edit') return edit(c);
      if (a === 'suspend') { if (await ask('Suspendre ' + c.nom + ' ?', 'Son logiciel se bloquera <b>à la prochaine vérification en ligne</b> (hors ligne : au plus tard 7 jours après sa dernière vérification). Vous pourrez le réactiver à tout moment.', 'Suspendre', 'warn')) { await api('update', { id: c.id, patch: { statut: 'suspendu' } }); await load(); toast('Client suspendu.'); } return; }
      if (a === 'resume') { await api('update', { id: c.id, patch: { statut: 'actif' } }); await load(); toast('Client réactivé : son logiciel se débloquera à sa prochaine vérification.'); return; }
      if (a === 'revoke') { if (await ask('Révoquer ' + c.nom + ' ?', 'La licence est retirée définitivement : le logiciel se bloque à la prochaine vérification et le code ne fonctionne plus. (Vous pourrez encore la réactiver.)', 'Révoquer', 'danger')) { await api('update', { id: c.id, patch: { statut: 'revoque' } }); await load(); toast('Licence révoquée.'); } return; }
      if (a === 'remove') { if (await ask('Supprimer ' + c.nom + ' ?', 'Le client, ses appareils et son journal seront effacés. Action irréversible.', 'Supprimer', 'danger')) { await api('remove', { id: c.id }); S.sel = null; $('drawer').hidden = true; document.body.classList.remove('has-drawer'); await load(); toast('Client supprimé.'); } return; }
      if (a === 'newcode') { if (await ask('Nouveau code pour ' + c.nom + ' ?', 'L’ancien code ne permettra plus d’enregistrer de <b>nouvel</b> appareil. Les appareils déjà enregistrés continuent de fonctionner.', 'Générer')) { var r = await api('new_code', { id: c.id }); await load(); showCode(c, r.code, c.expire_le, c.max_appareils); } return; }
      if (a === 'release') { var short = dev.replace(/(.{4})(?=.)/g, '$1-'); if (await ask('Libérer cet appareil ?', 'L’appareil <code>' + esc(short) + '</code> sera bloqué à sa prochaine vérification et la place sera disponible pour un autre appareil.', 'Libérer')) { await api('release_device', { id: c.id, device: dev }); await load(); toast('Appareil libéré.'); } return; }
    } catch (e) { toast(e.message || String(e)); }
  }

  /* ---------- chargement, mémorisation ---------- */
  async function load() {
    var r = await api('list'); S.clients = r.clients || []; $('main').hidden = false; $('welcome').hidden = true; render();
  }
  async function persist() {
    try { if (window.ownerApp) { var r = await window.ownerApp.save({ url: S.url, adminKey: S.key }); if (!r.ok) toast(r.msg); } else sessionStorage.setItem('exb_own', JSON.stringify({ url: S.url, key: S.key })); } catch (e) { /* non mémorisé */ }
  }
  async function start() {
    var saved = null;
    try { if (window.ownerApp) { saved = await window.ownerApp.load(); if (saved) saved = { url: saved.url, key: saved.adminKey }; if (!saved) { var d = await window.ownerApp.defaults(); if (d && d.url) S.url = d.url; } } else saved = JSON.parse(sessionStorage.getItem('exb_own') || 'null'); } catch (e) { saved = null; }
    var qs = new URLSearchParams(location.search); if (!saved && qs.get('url')) saved = { url: qs.get('url'), key: qs.get('key') || '' };
    if (saved && saved.url && saved.key) { S.url = saved.url; S.key = saved.key; try { await load(); } catch (e) { $('welcome').hidden = false; toast(e.message); } }
    else $('welcome').hidden = false;
    clearInterval(S.timer); S.timer = setInterval(function () { if (!document.hidden && S.key && !dlg.open) load().catch(function () {}); }, 60000);
  }

  /* ---------- événements ---------- */
  $('bNew').onclick = function () { if (!S.key) return connexion(); newClient(); };
  $('bConn').onclick = connexion; $('bWelcome').onclick = connexion;
  $('q').oninput = function () { S.q = this.value; render(); };
  $('chips').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; S.filter = b.getAttribute('data-f'); [].forEach.call(this.children, function (x) { x.classList.toggle('on', x === b); }); render(); };
  $('rows').onclick = function (e) { var tr = e.target.closest('tr'); if (!tr) return; S.sel = tr.getAttribute('data-id'); render(); };
  $('drawer').onclick = function (e) { var b = e.target.closest('[data-act]'); if (b) act(b.getAttribute('data-act'), b.getAttribute('data-dev')); };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !dlg.open && S.sel) act('close'); });
  $('bExport').onclick = async function () {
    var q = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var csv = '﻿' + ['Client', 'Identifiant', 'État', 'Échéance', 'Tolérance (j)', 'Appareils', 'Appareils max', 'Dernière vérification', 'Notes'].map(q).join(';') + '\r\n'
      + S.clients.map(function (c) { var ls = lastSeen(c); return [c.nom, c.slug, info(c).t, c.expire_le.slice(0, 10), c.grace_jours, (c.appareils || []).length, c.max_appareils, ls ? ls.slice(0, 16).replace('T', ' ') : '', c.notes || ''].map(q).join(';'); }).join('\r\n');
    var name = 'clients-excellencia-' + new Date().toISOString().slice(0, 10) + '.csv';
    if (window.ownerApp) { var r = await window.ownerApp.saveFile(name, csv); if (r.ok) toast('Exporté : ' + r.path); }
    else { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = name; a.click(); }
  };
  start();
})();
