/* Excellencia Licences — application propriétaire (Windows, Electron). V120o.
 * La clé d'administration est chiffrée par Windows (DPAPI, via safeStorage) dans le dossier de l'utilisateur ; elle n'est jamais écrite en clair. */
const { app, BrowserWindow, ipcMain, dialog, safeStorage, shell, Menu } = require('electron');
const path = require('path'), fs = require('fs');

if (!app.requestSingleInstanceLock()) app.quit();
let win = null;
const CFG = () => path.join(app.getPath('userData'), 'connexion.bin');

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 900, minHeight: 600, show: false, backgroundColor: '#f4f6fa', title: 'Excellencia Licences',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, preload: path.join(__dirname, 'preload.js') }
  });
  Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); } });
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F12') { win.webContents.toggleDevTools(); e.preventDefault(); } });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

/* adresse du serveur fournie à la fabrication (licence-serveur.json) : évite de la retaper */
ipcMain.handle('own:defaults', () => {
  for (const p of [path.join(process.resourcesPath || '', 'licence-serveur.json'), path.join(__dirname, '..', 'licence-serveur.json')]) {
    try { const j = JSON.parse(fs.readFileSync(p, 'utf8')); if (j.url) return { url: j.url }; } catch (e) { /* suivant */ }
  }
  return {};
});
ipcMain.handle('own:load', () => {
  try {
    if (!fs.existsSync(CFG())) return null;
    if (!safeStorage.isEncryptionAvailable()) return null;
    return JSON.parse(safeStorage.decryptString(fs.readFileSync(CFG())));
  } catch (e) { return null; }
});
ipcMain.handle('own:save', (e, cfg) => {
  if (!safeStorage.isEncryptionAvailable()) return { ok: false, msg: 'Le chiffrement Windows n’est pas disponible : la clé ne sera pas mémorisée (vous la saisirez à chaque ouverture).' };
  fs.writeFileSync(CFG(), safeStorage.encryptString(JSON.stringify({ url: String(cfg.url || ''), adminKey: String(cfg.adminKey || '') })));
  return { ok: true };
});
ipcMain.handle('own:clear', () => { try { fs.rmSync(CFG(), { force: true }); } catch (e) { /* rien */ } return true; });
ipcMain.handle('own:save-file', async (e, name, text) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: String(name || 'export.txt') });
  if (r.canceled || !r.filePath) return { ok: false };
  fs.writeFileSync(r.filePath, String(text), 'utf8'); return { ok: true, path: r.filePath };
});
