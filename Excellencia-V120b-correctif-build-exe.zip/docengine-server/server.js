'use strict';
/* Excellencia Building — serveur du moteur documentaire universel.
 * Démarrage :  node server.js   (voir ../DOCENGINE-LISEZ-MOI.md)                                          */
const http = require('http');
const loadConfig = require('./lib/config');
const createHttp = require('./lib/http');
const createAuth = require('./lib/auth');
const createRenderer = require('./lib/render');
const createService = require('./lib/service');
const createLimiter = require('./lib/ratelimit');

function build(over, deps) {
  deps = deps || {};
  const cfg = loadConfig(over);
  const storage = deps.storage || (cfg.storage === 'supabase' ? require('./lib/storage-supabase')(cfg, deps.fetch) : require('./lib/storage-file')(cfg));
  const renderer = deps.renderer || createRenderer(cfg);
  const svc = createService({ storage, renderer, cfg });
  const auth = createAuth(cfg, deps.fetch), limiter = createLimiter(), app = createHttp(cfg);
  const R = '/api/v1';

  const authed = (fn) => async (c, h) => {
    const ctx = await auth.authenticate(c.req);
    const rl = limiter('a:' + ctx.userId, cfg.rateAuthPerMin); if (!rl.ok) throw Object.assign(new Error('Trop de requêtes.'), { status: 429, retryAfter: rl.retryAfter });
    return fn(c, h, ctx);
  };
  const pdfReply = (h, r, inline) => h.send(200, r.pdf, { 'Content-Type': 'application/pdf', 'Content-Disposition': (inline ? 'inline' : 'attachment') + '; filename="' + r.filename.replace(/[^A-Za-z0-9._-]/g, '_') + '"', 'X-Doc-Number': r.number || '', 'X-Doc-Id': r.id || '' });

  app.add('GET', R + '/health', (c, h) => h.send(200, { ok: true, service: 'excellencia-docengine', version: svc.core.VERSION, storage: storage.kind, renderer: renderer.stats ? renderer.stats() : null }));
  app.add('GET', R + '/templates', (c, h) => h.send(200, { templates: svc.templates() }));

  app.add('GET', R + '/me', authed((c, h, ctx) => h.send(200, { org_id: ctx.orgId, role: ctx.role, user_id: ctx.userId })));
  app.add('GET', R + '/profile', authed(async (c, h, ctx) => h.send(200, { profile: await svc.getProfile(ctx), role: ctx.role })));
  app.add('PUT', R + '/profile', authed(async (c, h, ctx) => h.send(200, { profile: await svc.putProfile(ctx, c.body && c.body.profile) })));
  app.add('GET', R + '/settings', authed(async (c, h, ctx) => h.send(200, { settings: await svc.settings(ctx) })));
  app.add('PUT', R + '/settings', authed(async (c, h, ctx) => { await svc.putSettings(ctx, c.body && c.body.settings); return h.send(200, { settings: await svc.settings(ctx) }); }));
  app.add('GET', R + '/models', authed(async (c, h, ctx) => h.send(200, { models: await svc.listModels(ctx) })));
  app.add('PUT', R + '/models', authed(async (c, h, ctx) => h.send(200, { model: await svc.putModel(ctx, c.body && c.body.model) })));
  app.add('DELETE', R + '/models/:id', authed(async (c, h, ctx) => h.send(200, await svc.deleteModel(ctx, c.params.id))));

  app.add('POST', R + '/render', authed(async (c, h, ctx) => {
    const r = await svc.render(ctx, c.body);
    if (r.html !== undefined) return h.send(200, { html: r.html, number: r.number, title: r.title, filename: r.filename });
    return pdfReply(h, r, c.query.inline === '1');
  }));
  app.add('GET', R + '/documents', authed(async (c, h, ctx) => h.send(200, await svc.listDocuments(ctx, c.query))));
  app.add('GET', R + '/documents/:id/pdf', authed(async (c, h, ctx) => { const r = await svc.getDocumentPdf(ctx, c.params.id); return pdfReply(h, Object.assign({ number: r.record.number, id: r.record.id }, r), c.query.inline === '1'); }));
  app.add('POST', R + '/documents/:id/regenerate', authed(async (c, h, ctx) => pdfReply(h, await svc.regenerate(ctx, c.params.id), false)));
  app.add('DELETE', R + '/documents/:id', authed(async (c, h, ctx) => h.send(200, await svc.deleteDocument(ctx, c.params.id))));

  /* formulaires publics : sans compte, limités par adresse IP, aucune donnée conservée */
  const pub = (fn) => async (c, h) => {
    if (!cfg.publicForms) throw Object.assign(new Error('Formulaires publics désactivés.'), { status: 404 });
    const rl = limiter('p:' + c.ip, cfg.ratePublicPerMin); if (!rl.ok) throw Object.assign(new Error('Trop de requêtes, réessayez dans un instant.'), { status: 429, retryAfter: rl.retryAfter });
    return fn(c, h);
  };
  app.add('GET', R + '/public/categories', pub((c, h) => h.send(200, { categories: svc.publicCategories() })));
  app.add('GET', R + '/public/forms', pub((c, h) => h.send(200, { forms: svc.publicForms(c.query.cat) })));
  app.add('GET', R + '/public/forms/:slug', pub((c, h) => { const f = svc.publicForms().find((x) => x.slug === c.params.slug); if (!f) throw Object.assign(new Error('Formulaire introuvable.'), { status: 404 }); return h.send(200, { form: f }); }));
  app.add('POST', R + '/public/forms/:slug/render', pub(async (c, h) => pdfReply(h, await svc.publicRender(c.body, c.params.slug), false)));

  const server = http.createServer((req, res) => app.handle(req, res));
  server.requestTimeout = 60000; server.headersTimeout = 20000;
  return { server, cfg, svc, renderer, storage, close: async () => { await new Promise((r) => server.close(r)); await renderer.close(); } };
}
module.exports = build;

if (require.main === module) {
  const app = build();
  if (app.cfg.dev) console.warn('⚠ MODE DÉVELOPPEMENT : les jetons « dev:… » sont acceptés. Ne jamais utiliser en production.');
  if (!app.cfg.dev && app.cfg.storage === 'file') console.warn('ℹ Stockage sur disque (DATA_DIR) sans comptes : définissez SUPABASE_URL et SUPABASE_ANON_KEY pour la production.');
  app.server.listen(app.cfg.port, app.cfg.host, () => console.log('Moteur documentaire Excellencia prêt sur http://' + app.cfg.host + ':' + app.cfg.port + '/api/v1/health  (stockage : ' + app.storage.kind + ')'));
  const stop = () => app.close().finally(() => process.exit(0)); process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
