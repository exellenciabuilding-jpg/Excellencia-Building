'use strict';
/* Test navigateur réel (Chromium) : Centre documentaire, formulaires publics, module Séances.  Lancer : node tests/e2e-ui.js */
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os'), assert = require('node:assert/strict');
const { chromium } = require('playwright');
const build = require('../server');
const SITE = path.resolve(__dirname, '..', '..', 'site');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.json': 'application/json', '.jpg': 'image/jpeg', '.webmanifest': 'application/json' };
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FABJADveWkH6oAAAAAElFTkSuQmCC';
(async () => {
  const web = http.createServer((q, s) => { let f = path.join(SITE, decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html'; if (!f.startsWith(SITE) || !fs.existsSync(f)) { s.writeHead(404); return s.end(); } s.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(s); });
  await new Promise((r) => web.listen(0, '127.0.0.1', r)); const W = 'http://127.0.0.1:' + web.address().port;
  const app = build({ dev: true, port: 0, dataDir: fs.mkdtempSync(path.join(os.tmpdir(), 'ui-')) }); await new Promise((r) => app.server.listen(0, '127.0.0.1', r)); const API = 'http://127.0.0.1:' + app.server.address().port;
  const browser = await chromium.launch({ args: ['--no-sandbox'] }); const errors = [];
  const ctx = await browser.newContext({ acceptDownloads: true, viewport: { width: 1280, height: 900 } });
  await ctx.addInitScript(({ API }) => { try { if (!localStorage.getItem('EXB_DOCENGINE_URL')) { localStorage.setItem('EXB_DOCENGINE_URL', JSON.stringify(API)); localStorage.setItem('EXB_SB_TOKEN', JSON.stringify({ access_token: 'dev:orgUI:ui:admin', exp: Date.now() + 3600e3 })); } } catch (e) {} }, { API });
  const page = await ctx.newPage(); page.on('pageerror', (e) => errors.push('pageerror ' + e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/favicon|404/.test(m.text())) errors.push('console ' + m.text()); });
  const ok = (m) => console.log('  OK  ' + m);

  await page.goto(W + '/centre-documentaire.html'); await page.waitForSelector('.nav button');
  assert.equal(await page.locator('.nav button').count(), 9); ok('9 rubriques affichées');
  assert.match(await page.textContent('#sbState'), /Connecté/); ok('connecté au serveur (jeton de développement)');

  await page.click('[data-id=entreprise]'); await page.fill('#name', 'Gamma Bâtiment'); await page.fill('#address', '5 avenue Test'); await page.fill('#city', 'Goma');
  await page.click('[data-add=phones]'); await page.fill('#phones .it input', '+243 800 111 222'); await page.click('[data-addpair=ids]'); const idIn = page.locator('#ids .it input'); await idIn.nth(0).fill('RCCM'); await idIn.nth(1).fill('CD/GOM/42');
  await page.click('#save'); await page.waitForSelector('.msg.ok'); assert.match(await page.textContent('.msg.ok'), /synchronisé/); ok('profil entreprise enregistré sur le serveur');

  await page.click('[data-id=identite]'); await page.setInputFiles('input[data-img=logo]', { name: 'logo.png', mimeType: 'image/png', buffer: Buffer.from(PNG.split(',')[1], 'base64') });
  await page.waitForFunction(() => document.querySelector('.th img')); await page.fill('#c1', '#aa0000').catch(() => {}); await page.evaluate(() => { const c = document.getElementById('c1'); c.value = '#7a1f2b'; c.dispatchEvent(new Event('input')); });
  await page.click('#save'); await page.waitForSelector('.msg.ok'); ok('logo et couleurs enregistrés');

  const legacy = await page.evaluate(() => ({ id: EXBId.get(), brand: JSON.parse(localStorage.getItem('EXB_BRAND_V1')).brand }));
  assert.equal(legacy.id.address, '5 avenue Test'); assert.equal(legacy.id.phone, '+243 800 111 222'); assert.equal(legacy.brand.primary, '#7a1f2b'); ok('synchronisation vers l’identité existante (EXBId / EXB_BRAND) : les anciens modules la reprennent');

  await page.click('[data-id=gen]'); await page.selectOption('#gt', 'devis'); await page.fill('#g_client_nom', 'Client UI'); await page.fill('#g_objet', 'Test UI'); await page.fill('#t_lignes tr.dr input >> nth=0', 'Ligne 1'); await page.fill('#t_lignes tr.dr input >> nth=2', '3'); await page.fill('#t_lignes tr.dr input >> nth=3', '50');
  await page.click('#gp'); await page.waitForTimeout(1500);
  const pvHtml = await page.evaluate(() => document.getElementById('pv').srcdoc); assert.ok(pvHtml.includes('Gamma Bâtiment') && pvHtml.includes('150,00') && pvHtml.includes('#7a1f2b')); ok('aperçu fidèle (profil, totaux, couleurs)');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#gg')]); const f = path.join(os.tmpdir(), 'ui-devis.pdf'); await dl.saveAs(f); const b = fs.readFileSync(f); assert.equal(b.subarray(0, 5).toString(), '%PDF-'); ok('PDF téléchargé : ' + dl.suggestedFilename() + ' (' + b.length + ' o)');

  await page.click('[data-id=histo]'); await page.waitForSelector('#ht'); assert.match(await page.textContent('#ht'), /DEV-\d{4}-0001/); ok('historique : document archivé avec son numéro');
  await page.click('[data-id=params]'); await page.waitForSelector('.perm'); ok('paramètres et permissions affichés');
  await page.click('[data-id=public]'); await page.waitForSelector('code.url'); assert.ok((await page.locator('code.url').count()) >= 6); ok('liens publics par catégorie et par formulaire');
  await page.click('[data-id=modeles]'); await page.click('#newModel'); await page.fill('#mn', 'Devis marine'); await page.selectOption('#ml', 'bandeau'); await page.click('#ms2'); await page.waitForSelector('[data-use]'); ok('modèle personnalisé créé');
  await page.click('[data-id=dash]'); await page.waitForSelector('.kpi'); ok('tableau de bord');

  /* formulaires publics */
  const pub = await ctx.newPage(); pub.on('pageerror', (e) => errors.push('public pageerror ' + e.message));
  await pub.goto(W + '/formulaires-publics.html?cat=apprenant'); await pub.waitForSelector('.tpl'); assert.equal(await pub.locator('.tpl').count(), 1);
  await pub.goto(W + '/formulaires-publics.html?f=inscription-formation'); await pub.waitForSelector('#f_nom'); await pub.fill('#p_name', 'Centre Public'); await pub.fill('#f_nom', 'Marie Z'); await pub.fill('#f_formation', 'Revit');
  const [dl2] = await Promise.all([pub.waitForEvent('download'), pub.click('#dl')]); const f2 = path.join(os.tmpdir(), 'ui-insc.pdf'); await dl2.saveAs(f2);
  const { PDFDocument } = require('pdf-lib'); const doc = await PDFDocument.load(fs.readFileSync(f2)); assert.equal(doc.getForm().getTextField('f_nom').getText(), 'Marie Z'); ok('formulaire public : PDF interactif prérempli, sans compte');
  assert.ok(await pub.evaluate(() => JSON.parse(localStorage.getItem('EXB_DOCPUBLIC_V1')).answers['inscription-formation'].nom === 'Marie Z')); ok('informations enregistrées sur l’appareil pour la prochaine fois');

  /* module Séances (index.html) : appelle le moteur commun */
  const idx = await ctx.newPage(); idx.on('pageerror', (e) => errors.push('index pageerror ' + e.message)); await idx.goto(W + '/index.html'); await idx.waitForFunction(() => window.EXBDoc && typeof exportPlanningPdf === 'function', null, { timeout: 30000 });
  const used = await idx.evaluate(async () => { schedules.length = 0; schedules.push({ schedule_id: 'S1', training: 'AutoCAD', module: 'Dessin 2D', trainer_id: '', date: '2026-11-03', start: '08:00', end: '12:00', room: 'A1' }); window.__gen = null; const o = EXBDoc.generate; EXBDoc.generate = async (t, d, op) => { window.__gen = { t, d, op }; return { number: 'SEA-TEST', via: 'test' }; }; await exportPlanningPdf(); EXBDoc.generate = o; return window.__gen; });
  assert.equal(used.t, 'planning-seances'); assert.equal(used.d.seances[0].module, 'Dessin 2D'); assert.equal(used.op.source, 'seances'); ok('module Séances : exportPlanningPdf passe par le moteur commun');

  /* mode local : sans serveur, le moteur prépare le document et l'envoie à l'impression de l'application */
  const loc = await (await browser.newContext()).newPage(); await loc.goto(W + '/centre-documentaire.html'); await loc.waitForSelector('.nav button'); assert.match(await loc.textContent('#sbState'), /Mode local/);
  const r = await loc.evaluate(async () => { const x = await EXBDoc.generate('recu', { payeur: 'A', montant: 12, motif: 'x' }, { action: 'none' }); return { via: x.via, n: x.number, html: x.html.includes('Reçu de paiement') || x.html.toUpperCase().includes('REÇU') }; });
  assert.equal(r.via, 'local'); assert.match(r.n, /^REC-\d{4}-0001$/); ok('mode local : numérotation et document sans serveur');
  await browser.close(); await app.close(); web.close();
  assert.deepEqual(errors, [], 'erreurs JavaScript : ' + errors.join(' | ')); ok('aucune erreur JavaScript dans les pages'); console.log('\nTous les parcours navigateur ont réussi.');
})().catch((e) => { console.error('\nÉCHEC :', e.message); process.exit(1); });
