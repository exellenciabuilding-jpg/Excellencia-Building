const vm=require('vm'),fs=require('fs');
const calls=[];
const w={localStorage:{getItem:()=>null,setItem(){}},
 EXBPrint:{html(t,b,o){calls.push([t,b]);return 1},full(){}},
 EXBDoc:{profile:{get:()=>({name:'ACME BTP',logo:'',colors:{},phones:['1'],emails:[]})},core:{esc:s=>String(s)}},
 EXBDocEngine:{noteHistory(){}}, setInterval:(f)=>{f();return 1}, clearInterval(){}};
w.exbRebrand=v=>v.split('Excellencia Building').join('ACME BTP');w.window=w; vm.createContext(w); vm.runInContext(fs.readFileSync(require('path').join(__dirname,'../../site/docengine/bridge.js'),'utf8'),w);
const P=w.EXBPrint;
const T=(t,b)=>{calls.length=0;P.html(t,b);return calls[0][1].indexOf('data-exb-habillage')>=0};
const r=[
 ['Reçu R4 nom d\'origine rebrandé','<body><h1>Excellencia Building</h1><p>x</p></body>',false],
 ['Reçu R1 sans nom','<body><table><tr><td>Montant</td></tr></table></body>',true],
 ['Reçu R2 avec nom','<body><h1>ACME BTP</h1><table></table></body>',false],
 ['Reçu R3 nom d\'origine','<body><h1>Excellencia Building</h1><p>x</p></body>',false],
 ['Bordereau B1 sans nom','<body><p>armatures</p></body>',true],
 ['Carte — Jean','<body><img src="data:x"></body>',false],
 ['Plans — cartouche','<body><p>x</p></body>',false],
 ['Planning de Gantt','<body><table></table></body>',true],
 ['Image doc','<body style="margin:0"><img src="u"></body>',false],
];
let bad=0;for(const [t,b,exp] of r){const got=T(t,b);const ok=got===exp;if(!ok)bad++;console.log(ok?'OK ':'KO ',t,'→ en-tête ajouté =',got)}
calls.length=0;P.html('Reçu X','<body><h1>Excellencia Building</h1></body>');if(calls[0][1].indexOf('Excellencia')>=0){console.log('KO rebrand');bad++}else console.log('OK  nom d\'origine remplacé par celui du client');
process.exit(bad?1:0);
