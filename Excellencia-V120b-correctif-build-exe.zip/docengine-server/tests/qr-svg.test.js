// Sans dépendance : node --test tests/qr-svg.test.js
const test = require('node:test'), assert = require('node:assert'), path = require('path');
const dir = path.join(__dirname, '..', '..', 'site', 'docengine');
const C = require(path.join(dir, 'core.js')); require(path.join(dir, 'templates.js')); require(path.join(dir, 'templates-modules.js'));
const svg = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"/>').toString('base64');
const ctx = { profile: { name: 'Org', colors: {} }, options: {}, number: 'D-001', mode: 'print' };
test('doc-devis : page de garde, CGV et QR SVG', () => {
  const h = C.render('doc-devis', { doc: { kind: 'devis', no: 'D-001', title: 'T', cover: true, cgv: 'Article 1. Test', qr: svg, qrCode: 'abc', client: { name: 'C' }, lots: [] } }, ctx).html;
  assert.match(h, /class="cov"/); assert.match(h, /Conditions générales/); assert.match(h, /QR de vérification/); assert.match(h, /ABC/);
});
test('doc-module : QR SVG affiché', () => {
  assert.match(C.render('doc-module', { doc: { titre: 'R', rows: [['a', 'b']], qr: svg } }, ctx).html, /QR de vérification/);
});
test('QR non base64 / injecté : refusé', () => {
  const bad = 'data:image/svg+xml;base64,AAA"onerror="x';
  assert.doesNotMatch(C.render('doc-module', { doc: { titre: 'R', rows: [['a', 'b']], qr: bad } }, ctx).html, /QR de vérification/);
});
