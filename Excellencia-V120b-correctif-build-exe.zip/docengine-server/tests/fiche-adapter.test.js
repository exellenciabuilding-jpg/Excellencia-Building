/* V120i : logique de repli de EXBDocEngine.fichePdf (sans navigateur) */
const calls=[];const store={};
global.window=global;global.self=global;
global.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v}};
global.document={createElement:()=>({click(){}})};
let connected=true,renderFails=false,saveOk=true;
global.EXBDoc={config:{connected:()=>connected},api:async()=>{if(renderFails)throw new Error('503');return{blob:async()=>'PDFBLOB'}}};
global.saveFile=async(n,b)=>{calls.push(['save',n,b]);return saveOk};
require('../../site/docengine/legacy-adapters.js');
const E=window.EXBDocEngine;const bad=[];const t=(n,c)=>{console.log(c?'ok ':'KO ',n);if(!c)bad.push(n)};
(async()=>{
 let fb=0;const fallback=()=>{fb++;return true};
 let r=await E.fichePdf({titre:'x'},'a.pdf',fallback);t('serveur OK → fichier du moteur, pas de repli',r===true&&fb===0&&calls.length===1&&calls[0][2]==='PDFBLOB');
 renderFails=true;r=await E.fichePdf({titre:'x'},'a.pdf',fallback);t('échec serveur → repli une seule fois',fb===1&&r===true);
 renderFails=false;connected=false;fb=0;r=await E.fichePdf({titre:'x'},'a.pdf',fallback);t('pas de serveur → repli direct',fb===1);
 connected=true;saveOk=false;fb=0;r=await E.fichePdf({titre:'x'},'a.pdf',fallback);t('enregistrement refusé → pas de second fichier',fb===0&&r===false);
 const e=await E.fichePdf({titre:'x'},'a.pdf',()=>false);
 if(bad.length){console.log('ÉCHECS',bad);process.exit(1)}console.log('OK fiche-adapter');
})();
