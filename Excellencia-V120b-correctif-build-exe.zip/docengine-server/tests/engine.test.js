'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { PDFDocument } = require('pdf-lib');
const { start, pdfText, SVG } = require('./helpers');

const A = { admin: 'dev:orgA:alice:admin', editeur: 'dev:orgA:bob:editeur', lecteur: 'dev:orgA:carl:lecteur' };
const B = 'dev:orgB:dora:admin';
const PROFILE_A = { name: 'Alpha Construction', legal_name: 'Alpha Construction SARL', logo: SVG, address: '1 rue A', city: 'Kinshasa', phones: ['+243 1'], emails: ['a@alpha.test'], ids: [{ label: 'RCCM', value: 'AAA-111' }], colors: { primary: '#112233', accent: '#c49a38' }, signatory: { name: 'Alice A', role: 'DG' } };
const PROFILE_B = { name: 'Beta Ingénierie', phones: ['+243 2'], ids: [{ label: 'RCCM', value: 'BBB-222' }] };
const DEVIS = { client_nom: 'Client Test', objet: 'Mur', tva_pct: 16, lignes: [{ designation: 'Béton', unite: 'm3', qte: 2, pu: 100 }] };

let S;
test.before(async () => { S = await start(); });
test.after(async () => { await S.close(); });

test('santé et catalogue des modèles (public)', async () => {
  const h = await S.call('GET', '/health'); assert.equal(h.status, 200); assert.equal(h.body.ok, true);
  const t = await S.call('GET', '/templates'); assert.equal(t.status, 200);
  const ids = t.body.templates.map((x) => x.id);
  for (const id of ['devis', 'facture', 'recu', 'bon-commande', 'rapport-technique', 'rapport-chantier', 'fiche-technique', 'rapport-geotechnique', 'attestation', 'certificat', 'formulaire-inscription', 'planning-seances']) assert.ok(ids.includes(id), 'modèle manquant : ' + id);
});

test('authentification et droits par rôle', async () => {
  assert.equal((await S.call('GET', '/profile')).status, 401);
  assert.equal((await S.call('GET', '/profile', { token: 'dev:../etc:x:admin' })).status, 401);
  assert.equal((await S.call('PUT', '/profile', { token: A.editeur, body: { profile: PROFILE_A } })).status, 403, 'un éditeur ne modifie pas le profil');
  assert.equal((await S.call('PUT', '/profile', { token: A.lecteur, body: { profile: PROFILE_A } })).status, 403);
  assert.equal((await S.call('PUT', '/profile', { token: A.admin, body: { profile: { name: '' } } })).status, 422, 'nom obligatoire');
  const ok = await S.call('PUT', '/profile', { token: A.admin, body: { profile: PROFILE_A } }); assert.equal(ok.status, 200); assert.equal(ok.body.profile.name, 'Alpha Construction');
  assert.equal((await S.call('POST', '/render', { token: A.lecteur, body: { type: 'devis', data: DEVIS } })).status, 403, 'un lecteur ne génère pas');
});

test('génération PDF : contenu, numérotation automatique, historique', async () => {
  const r1 = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', data: DEVIS, source: 'test' } });
  assert.equal(r1.status, 200); assert.equal(r1.body.subarray(0, 5).toString(), '%PDF-');
  const y = new Date().getFullYear();
  assert.equal(r1.headers.get('x-doc-number'), 'DEV-' + y + '-0001');
  const r2 = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', data: DEVIS } });
  assert.equal(r2.headers.get('x-doc-number'), 'DEV-' + y + '-0002');
  const f = await S.call('POST', '/render', { token: A.editeur, body: { type: 'facture', data: Object.assign({}, DEVIS, { acompte: 50 }) } });
  assert.equal(f.headers.get('x-doc-number'), 'FAC-' + y + '-0001', 'compteur indépendant par type');
  const { text } = await pdfText(r1.body);
  for (const s of ['Alpha Construction', 'DEV-' + y + '-0001', 'Client Test', 'RCCM', 'AAA-111', '232,00', 'Page 1 / 1']) assert.ok(text.includes(s), 'absent du PDF : ' + s + '\n' + text);
  assert.match(String(text), /deux cent trente deux dollars/i, 'montant en lettres');
  const hist = await S.call('GET', '/documents', { token: A.lecteur }); assert.equal(hist.status, 200); assert.equal(hist.body.total, 3);
  assert.equal(hist.body.items[0].type, 'facture'); assert.equal(hist.body.items[0].number, 'FAC-' + y + '-0001');
  const again = await S.call('GET', '/documents/' + r1.headers.get('x-doc-id') + '/pdf', { token: A.lecteur });
  assert.equal(again.status, 200); assert.ok(again.body.equals(r1.body), 'le PDF archivé est identique');
});

test('validation : champs obligatoires et type inconnu', async () => {
  const bad = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', data: { objet: 'x' } } }); assert.equal(bad.status, 422); assert.ok(bad.body.details.length >= 1);
  assert.equal((await S.call('POST', '/render', { token: A.editeur, body: { type: 'inconnu', data: {} } })).status, 422);
});

test('synchronisation : le profil modifié se retrouve dans les nouveaux documents ET dans les documents régénérés (même numéro)', async () => {
  const list = await S.call('GET', '/documents?type=devis', { token: A.admin }); const first = list.body.items[list.body.items.length - 1];
  const before = await S.call('GET', '/documents/' + first.id + '/pdf', { token: A.admin }); assert.ok((await pdfText(before.body)).text.includes('+243 1'));
  const upd = await S.call('PUT', '/profile', { token: A.admin, body: { profile: Object.assign({}, PROFILE_A, { name: 'Alpha Nouveau Nom', phones: ['+243 999 NOUVEAU'], address: 'Nouvelle adresse 9' }) } }); assert.equal(upd.status, 200);
  const fresh = await S.call('POST', '/render', { token: A.editeur, body: { type: 'recu', data: { payeur: 'Z', montant: 10, motif: 'm' } } });
  const t1 = (await pdfText(fresh.body)).text; assert.ok(t1.includes('Alpha Nouveau Nom') && t1.includes('+243 999 NOUVEAU') && t1.includes('Nouvelle adresse 9'));
  const reg = await S.call('POST', '/documents/' + first.id + '/regenerate', { token: A.editeur });
  assert.equal(reg.status, 200); assert.equal(reg.headers.get('x-doc-number'), first.number, 'numéro conservé');
  const t2 = (await pdfText(reg.body)).text; assert.ok(t2.includes('Alpha Nouveau Nom') && t2.includes('+243 999 NOUVEAU'), 'le document régénéré reprend le nouveau profil');
  const stored = await S.call('GET', '/documents/' + first.id + '/pdf', { token: A.admin }); assert.ok((await pdfText(stored.body)).text.includes('Alpha Nouveau Nom'), 'archive mise à jour');
});

test('isolation entre organisations : profil, historique, modèles, compteurs', async () => {
  const pb0 = await S.call('GET', '/profile', { token: B }); assert.equal(pb0.body.profile.name, '', 'B ne voit pas le profil de A');
  assert.equal((await S.call('POST', '/render', { token: B, body: { type: 'devis', data: DEVIS } })).status, 422, 'B doit d’abord créer son profil');
  await S.call('PUT', '/profile', { token: B, body: { profile: PROFILE_B } });
  const rb = await S.call('POST', '/render', { token: B, body: { type: 'devis', data: DEVIS } });
  assert.equal(rb.headers.get('x-doc-number'), 'DEV-' + new Date().getFullYear() + '-0001', 'compteur de B indépendant de A');
  const tb = (await pdfText(rb.body)).text; assert.ok(tb.includes('Beta Ingénierie') && tb.includes('BBB-222')); assert.ok(!tb.includes('Alpha') && !tb.includes('AAA-111'), 'aucune donnée de A dans le PDF de B');
  const ha = await S.call('GET', '/documents', { token: A.admin }), hb = await S.call('GET', '/documents', { token: B });
  assert.equal(hb.body.total, 1); assert.ok(ha.body.total >= 4);
  const idA = ha.body.items[0].id;
  assert.equal((await S.call('GET', '/documents/' + idA + '/pdf', { token: B })).status, 404, 'B ne peut pas lire un document de A');
  assert.equal((await S.call('POST', '/documents/' + idA + '/regenerate', { token: B })).status, 404);
  assert.equal((await S.call('DELETE', '/documents/' + idA, { token: B })).status, 404);
});

test('modèles personnalisés par organisation', async () => {
  const bad = await S.call('PUT', '/models', { token: A.lecteur, body: { model: { type: 'devis', name: 'x' } } }); assert.equal(bad.status, 403);
  const m = await S.call('PUT', '/models', { token: A.editeur, body: { model: { type: 'devis', name: 'Devis bandeau', options: { layout: 'bandeau', watermark: 'custom', watermark_text: 'CONFIDENTIEL', intro: 'Offre soumise à validation.', signature_labels: ['Client', 'Direction'], evil: '<script>' } } } });
  assert.equal(m.status, 200); assert.equal(m.body.model.options.layout, 'bandeau'); assert.equal(m.body.model.options.evil, undefined, 'options filtrées');
  const r = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', data: DEVIS, model_id: m.body.model.id } });
  const tx = (await pdfText(r.body)).text; assert.ok(tx.includes('Offre soumise à validation.') && tx.includes('Direction'));
  assert.equal((await S.call('GET', '/models', { token: B })).body.models.length, 0, 'modèles isolés par organisation');
  assert.equal((await S.call('POST', '/render', { token: B, body: { type: 'devis', data: DEVIS, model_id: m.body.model.id } })).status, 404);
  assert.equal((await S.call('DELETE', '/models/' + m.body.model.id, { token: A.editeur })).status, 200);
});

test('permissions configurables par l’administrateur', async () => {
  assert.equal((await S.call('PUT', '/settings', { token: A.editeur, body: { settings: {} } })).status, 403);
  const r = await S.call('PUT', '/settings', { token: A.admin, body: { settings: { permissions: { history_delete: ['admin', 'editeur'], profile_edit: ['editeur'] }, numbering: { pattern: '{P}/{Y}/{N}', pad: 3, prefixes: { devis: 'OFR' } } } } });
  assert.equal(r.status, 200); assert.ok(r.body.settings.permissions.profile_edit.includes('admin'), 'l’admin garde toujours la main sur le profil');
  const d = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', data: DEVIS } }); assert.match(d.headers.get('x-doc-number'), /^OFR\/\d{4}\/\d{3}$/);
  assert.equal((await S.call('DELETE', '/documents/' + d.headers.get('x-doc-id'), { token: A.editeur })).status, 200, 'permission accordée à l’éditeur');
});

test('PDF interactif : vrais champs remplissables à la bonne place', async () => {
  const r = await S.call('POST', '/render', { token: A.editeur, body: { type: 'formulaire-inscription', interactive: true, data: { nom: 'Jean Test', formation: 'AutoCAD', fieldValues: { f_tel: '0810' } } } });
  assert.equal(r.status, 200);
  const pdf = await PDFDocument.load(r.body), fields = pdf.getForm().getFields();
  assert.equal(fields.length, 12); const names = fields.map((f) => f.getName());
  assert.ok(names.includes('f_nom') && names.includes('f_email') && names.includes('f_observations'));
  assert.equal(pdf.getForm().getTextField('f_nom').getText(), 'Jean Test'); assert.equal(pdf.getForm().getTextField('f_tel').getText(), '0810');
  const w = pdf.getForm().getTextField('f_nom').acroField.getWidgets()[0].getRectangle(); assert.ok(w.width > 250 && w.height > 15 && w.y > 100, JSON.stringify(w));
  const ch = await S.call('POST', '/render', { token: A.editeur, body: { type: 'feuille-presence', interactive: true, data: { formation: 'X', participants: [{ nom: 'A' }, { nom: 'B' }, { nom: 'C' }] } } });
  const fp = await PDFDocument.load(ch.body); assert.equal(fp.getForm().getFields().length, 3); assert.ok(fp.getForm().getCheckBox('present_2'));
  const flat = await S.call('POST', '/render', { token: A.editeur, body: { type: 'formulaire-inscription', data: { nom: 'Jean Test' } } });
  assert.equal((await PDFDocument.load(flat.body)).getForm().getFields().length, 0, 'sans interactive : PDF imprimable simple');
});

test('plusieurs pages : numérotation « Page n / N » et en-têtes répétés', async () => {
  const lignes = Array.from({ length: 70 }, (_, i) => ({ designation: 'Poste de travaux numéro ' + (i + 1), unite: 'u', qte: 1, pu: 10 }));
  const r = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', data: Object.assign({}, DEVIS, { lignes }), save: false } });
  const p = await pdfText(r.body); assert.ok(p.pages >= 2, 'pages : ' + p.pages);
  assert.ok(p.text.includes('Page 1 / ' + p.pages) && p.text.includes('Page ' + p.pages + ' / ' + p.pages));
  assert.ok((String(p.text).match(/D.SIGNATION/gi) || []).length >= p.pages - 1, 'en-tête de tableau répété sur chaque page');
});

test('sécurité du rendu : HTML échappé, images externes refusées, aucune requête réseau', async () => {
  let hits = 0; const http = require('http'); const trap = http.createServer((q, s) => { hits++; s.end('x'); }); await new Promise((r) => trap.listen(0, '127.0.0.1', r));
  const url = 'http://127.0.0.1:' + trap.address().port + '/logo.png';
  await S.call('PUT', '/profile', { token: A.admin, body: { profile: Object.assign({}, PROFILE_A, { logo: url, signature: 'javascript:alert(1)', colors: { primary: 'red;}body{display:none', accent: '#c49a38' } }) } });
  const p = await S.call('GET', '/profile', { token: A.admin }); assert.equal(p.body.profile.logo, ''); assert.equal(p.body.profile.signature, ''); assert.equal(p.body.profile.colors.primary, '#173565');
  const r = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', save: false, data: Object.assign({}, DEVIS, { client_nom: '<script>alert(1)</script><img src="' + url + '">', objet: '"><style>*{display:none}</style>' }) } });
  const tx = (await pdfText(r.body)).text; assert.ok(tx.includes('<script>alert(1)</script>'), 'affiché littéralement, pas exécuté'); assert.ok(tx.includes('Client'));
  const h = await S.call('POST', '/render', { token: A.editeur, body: { type: 'devis', format: 'html', data: Object.assign({}, DEVIS, { client_nom: '<img src=x onerror=alert(1)>' }) } });
  assert.ok(!/<img src=x/i.test(h.body.html) && h.body.html.includes('&lt;img src=x'), 'balises échappées');
  assert.equal(hits, 0, 'aucune requête sortante déclenchée par le contenu'); trap.close();
});

test('formulaires publics : sans compte, avec logo et coordonnées de l’utilisateur', async () => {
  const cats = await S.call('GET', '/public/categories'); assert.equal(cats.status, 200); assert.ok(cats.body.categories.find((c) => c.id === 'apprenant') && cats.body.categories.find((c) => c.id === 'client') && cats.body.categories.find((c) => c.id === 'chantier'));
  const list = await S.call('GET', '/public/forms?cat=client'); assert.deepEqual(list.body.forms.map((f) => f.slug), ['demande-devis']);
  assert.equal((await S.call('GET', '/public/forms/inexistant')).status, 404);
  const r = await S.call('POST', '/public/forms/inscription-formation/render', { body: { interactive: true, profile: { name: 'Centre Public X', logo: SVG, phones: ['+243 5'], address: 'Ma rue', colors: { primary: '#aa2200' } }, data: { nom: 'Marie Z', formation: 'Revit' } } });
  assert.equal(r.status, 200); const t = (await pdfText(r.body)).text; assert.ok(t.includes('Centre Public X') && t.includes('Ma rue'));
  assert.equal((await PDFDocument.load(r.body)).getForm().getFields().length, 12);
  assert.equal((await S.call('GET', '/documents', { token: A.admin })).body.items.some((d) => /Inscription/i.test(d.title) && d.source === ''), false, 'rien n’est conservé côté serveur');
});

test('limitation de débit sur les formulaires publics', async () => {
  const L = await start({ ratePublicPerMin: 3 }); try {
    for (let i = 0; i < 3; i++) assert.equal((await L.call('GET', '/public/forms')).status, 200);
    const x = await L.call('GET', '/public/forms'); assert.equal(x.status, 429); assert.ok(+x.headers.get('retry-after') >= 1);
  } finally { await L.close(); }
});

test('taille de requête bornée', async () => {
  const L = await start({ maxBody: 2000 }); try { const r = await L.call('POST', '/public/forms/demande-devis/render', { body: { data: { description: 'x'.repeat(5000) } } }); assert.equal(r.status, 413); } finally { await L.close(); }
});

test('CORS : seules les origines autorisées', async () => {
  const L = await start({ dev: false, corsOrigins: ['https://app.example'] }); try {
    const ok = await fetch(L.base + '/health', { headers: { Origin: 'https://app.example' } }), no = await fetch(L.base + '/health', { headers: { Origin: 'https://evil.example' } });
    assert.equal(ok.headers.get('access-control-allow-origin'), 'https://app.example'); assert.equal(no.headers.get('access-control-allow-origin'), null);
    const r = await L.call('GET', '/profile', { token: 'dev:orgA:x:admin' }); assert.equal(r.status, 503, 'jetons de développement refusés hors mode développement');
  } finally { await L.close(); }
});

test('les 19 modèles produisent un PDF valide à partir de leurs valeurs par défaut', async () => {
  const types = (await S.call('GET', '/templates')).body.templates;
  assert.ok(types.length >= 17);
  for (const t of types) {
    const data = {}; t.fields.forEach((f) => { if (f.required) data[f.k] = f.type === 'number' ? 5 : 'Test ' + f.k; });
    t.tables.forEach((tb) => { if (tb.required) { const row = {}; tb.columns.forEach((c) => { row[c.k] = c.type === 'number' ? 3 : 'v'; }); data[tb.k] = [row]; } });
    const r = await S.call('POST', '/render', { token: A.editeur, body: { type: t.id, data, save: false, interactive: !!t.interactive } });
    assert.equal(r.status, 200, t.id + ' : ' + (r.body.error || '')); assert.equal(r.body.subarray(0, 5).toString(), '%PDF-', t.id);
  }
});
