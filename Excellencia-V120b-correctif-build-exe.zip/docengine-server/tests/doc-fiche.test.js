const C=require('../../site/docengine/core.js');require('../../site/docengine/templates.js');require('../../site/docengine/templates-modules.js');
const prof=(C.normalizeProfile||C.normProfile||(x=>x))({name:'ACME BTP',city:'Goma',phones:['+243 1'],emails:['a@b.c']});
const ctx={profile:prof,options:{},number:'FCH-001',mode:'print'};
const fail=[];const ok=(n,c)=>{if(!c)fail.push(n);console.log(c?'ok ':'KO ',n)};
// épreuve vierge
let h=C.render('doc-fiche',{doc:{titre:'TP — Béton armé',meta:[['Référence','EP-1'],['Matricule','____'],['Nom','<img src=x onerror=alert(1)>']],consignes:'Calculatrice <b>interdite</b>',questions:[{number:1,points:2,text:'Définir le <script>x</script> béton',lines:5},{number:2,text:'Q2',lines:99}],closing:'Note : ____ / ____'}},ctx).html;
ok('identité du profil',h.includes('ACME BTP'));
ok('titre',h.includes('TP — Béton armé'));
ok('XSS échappé',!h.includes('<script>x')&&!h.includes('<img src=x')&&!h.includes('<b>interdite'));
ok('5 lignes Q1 + 12 max Q2',(h.match(/class="ln"/g)||[]).length===17);
// copie corrigée + résultats + dossier
h=C.render('doc-fiche',{doc:{titre:'Copie',questions:[{number:1,text:'Q',answer:'',result:'Note : 2 / 2'},{number:2,text:'Q',answer:'réponse'}],totals:[['Total','2 / 4']]}},ctx).html;
ok('réponse vide signalée',h.includes('aucune réponse'));
ok('totaux',h.includes('2 / 4'));
h=C.render('doc-fiche',{doc:{titre:'Liste',sections:[{table:{heads:['A','B'],align:['','r'],rows:[['x','<i>y</i>'],['z',3]]}}],sign:['Le formateur'],photo:'javascript:alert(1)',photoSlot:true}},ctx).html;
ok('tableau',h.includes('<th>A</th>')&&h.includes('class="r">3'));
ok('cellule échappée',!h.includes('<i>y</i>'));
ok('photo non sûre refusée',!h.includes('javascript:'));
ok('signature',h.includes('Le formateur'));
// robustesse : charge utile vide / malformée
try{h=C.render('doc-fiche',{doc:{sections:'x',questions:{},meta:[null,[1]],totals:5}},ctx).html;ok('charge malformée sans plantage',h.includes('ACME BTP'))}catch(e){ok('charge malformée sans plantage: '+e.message,false)}
if(fail.length){console.log('ÉCHECS',fail);process.exit(1)}console.log('OK doc-fiche');
