'use strict';
const fs = require('fs'), os = require('os'), path = require('path');
const build = require('../server');
const SVG = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><rect width="10" height="10" fill="#173565"/></svg>').toString('base64');
async function start(over, deps) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'docengine-'));
  const app = build(Object.assign({ dev: true, port: 0, dataDir: dir, ratePublicPerMin: 1000 }, over || {}), deps);
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + app.server.address().port + '/api/v1';
  async function call(method, p, o) {
    o = o || {}; const headers = { Accept: 'application/json' };
    if (o.token) headers.Authorization = 'Bearer ' + o.token;
    if (o.body !== undefined) headers['Content-Type'] = 'application/json';
    const r = await fetch(base + p, { method, headers: Object.assign(headers, o.headers || {}), body: o.body === undefined ? undefined : JSON.stringify(o.body) });
    const ct = r.headers.get('content-type') || '';
    const body = ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer());
    return { status: r.status, headers: r.headers, body };
  }
  return { app, base, call, dir, close: async () => { await app.close(); fs.rmSync(dir, { recursive: true, force: true }); } };
}
/* pdf.js restitue certains signes (tiret, +, _) comme des espaces : on compare donc sur le texte « normalisé » (lettres et chiffres).
 * Le texte réel des PDF a été vérifié séparément avec pdftotext. */
const norm = (s) => String(s).normalize('NFC').replace(/[^\p{L}\p{N},<>]+/gu, ' ').trim();
class Norm extends String { includes(x) { return norm(this).toLowerCase().includes(norm(x).toLowerCase()); } }
async function pdfText(buf) {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const task = pdfjs.getDocument({ data: new Uint8Array(buf), useSystemFonts: true, verbosity: 0 }), doc = await task.promise; let out = '';
  for (let i = 1; i <= doc.numPages; i++) { const tc = await (await doc.getPage(i)).getTextContent(); out += tc.items.map((x) => x.str).join(' ') + '\n'; }
  const pages = doc.numPages; await task.destroy(); return { text: new Norm(norm(out)), pages };
}
module.exports = { start, pdfText, SVG };
