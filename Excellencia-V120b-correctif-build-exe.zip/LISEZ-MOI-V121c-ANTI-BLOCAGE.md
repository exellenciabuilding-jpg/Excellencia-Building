# V121c — Anti-blocage (champs et recherche figés 1 à 2 minutes)

Cause probable : tâches automatiques lourdes qui tournent à intervalle régulier pendant que l'utilisateur écrit.
- Publication automatique de l'espace apprenant (toutes les 30 s) : recalcul de tous les apprenants avec une normalisation de texte répétée des milliers de fois, aggravée par le calcul des notes TP/TD ajouté en V120v.
- Publication automatique de l'espace formateur (30 s) et synchronisation cloud (60 s : lecture et empreinte de toutes les données locales).

Corrections :
1. espBuild (index.html) : cache de normalisation + index des notes TP/TD ; pause de l'écran tous les 20 apprenants.
2. Espace apprenant, espace formateur : reportés tant qu'un champ de saisie a le focus (reprise 30 s plus tard).
3. Synchronisation cloud (exb-sync.js) : reportée pendant la saisie, au plus 5 minutes.
4. Nouveau exb-diag-lenteur.js : enregistre sur l'appareil les tâches qui bloquent l'écran plus de 300 ms. Rapport : Ctrl + Alt + L.

Non testé sur vos vraies données : si le blocage persiste, ouvrir le rapport (Ctrl + Alt + L) juste après un blocage et me l'envoyer.
