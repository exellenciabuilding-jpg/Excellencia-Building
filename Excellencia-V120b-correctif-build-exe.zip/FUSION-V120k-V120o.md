# Fusion V120k (dépôt « complet ») + V120o (dépôt « propriétaire ») → V120p unique

## 1. Les deux versions comparées
| | A — `Excellencia-V120k-GITHUB-complet` | B — `1-PROPRIETAIRE-GITHUB-depot-prive` |
|---|---|---|
| Fichiers | 836 | 892 |
| Dernière étape | V120k (contrôle client, rebranding profond) | V120o (serveur de licences, 2 appareils) |
| Rôle | site + apps, sans licences serveur | tout, y compris propriétaire |

Résultat du comparatif : 47 écarts. **B n'est pas un simple sur-ensemble de A** : B apporte V120l → V120o, mais A contient des correctifs V120j/k absents de B.

## 2. Ce qui n'existe que dans B (conservé)
- Licences : `licence-server/`, `owner-app/`, `owner-licences/`, `provisioning/`, `clients/`, `licence-serveur.json`, scripts `apply-licence`, `build-editions`, `make-livrables`, `strip-owner`, `test-licence`.
- Workflows GitHub (`.github/`), guides V120n/V120o, `GUIDE-PROVISIONNEMENT`, `LISEZ-MOI-DEPOT-PROPRIETAIRE`.
- Site : `exb-notify-pro.js`, `exb-maj-auto.js` (V120l/m), accueil compact horloge + météo, recherche globale robuste, fond neutre `splash-fond-neutre.webp`, protection des champs « code de licence » contre l'autocorrection, identifiants légaux → pied de page des documents, notification de connexion unique.
- `.gitignore` renforcé (clés et secrets de licence).

## 3. Ce qui n'existait que dans A (réintégré)
- `site/tools/controle-client.js` et `site/tools/e2e-marque.py` (contrôle avant livraison).
- `exb-brand.js` : garde « pas d'adresse publique d'origine chez un autre client », domaine historique dans le remplacement d'hôte, libellés d'accessibilité (`aria-label`, `data-title`), correction des liens (site, WhatsApp, e-mail), balises de partage `og:`/`twitter:`, surveillance des changements de `href`.
- `exb-docs.js` et `exb-pdf.js` (génération locale) : rebranding profond des documents avant création.
- Notes : section V120j de l'audit PDF, section 8 du guide « Nouveau client ».

## 4. Fichiers modifiés des deux côtés : choix retenu
| Fichier | Choix |
|---|---|
| `exb-brand.js` | **Fusion manuelle** : base B + durcissements A |
| `exb-docs.js`, `exb-pdf.js` | B + ligne de rebranding de A |
| `exb-entreprise.js`, `exb-identite.js`, `exb-vitrine.js` | B (plus complet : aucune coordonnée d'origine proposée à un client) |
| `exb-license.js`, `exb-recherche-globale.js`, `exb-home-widgets.js`, `exb-ux-v119l.js`, `core/index.js`, `index.html`, `exb-v97-integration.js`, `exb-v99r-shell.js`, `exb-menu-contextuel.js`, `docengine/client.js` | B (versions plus récentes) |
| `GUIDE-NOUVEAU-CLIENT.md` | B + section 8 de A |
| `sw.js` | B, version de cache `v120p-fusion-…` (force le rafraîchissement) |
| `package.json` | B + script `npm run controle:client` |

## 5. Vérifications
- Syntaxe de tous les fichiers JS : OK.
- `npm run test:licences` (client, serveur, provisionnement) : OK.
- Fabrication de l'édition client (`strip-owner`, `build-www`) : OK, aucun générateur ni clé privée dans le résultat.
- `controle-client.js` sur `site/` propriétaire : 4 alertes attendues (il sert à contrôler un dossier client avant livraison).
- Non lancés : tests `docengine-server` (dépendances npm non installées ici) et parcours navigateur `e2e-marque.py`. À exécuter une fois : `cd docengine-server && npm i && npm test`, puis `python3 site/tools/e2e-marque.py`.

## 6. Attention
Cette version unique contient les outils propriétaires : **dépôt privé uniquement**, ne jamais le donner à un client. Les versions clients se fabriquent avec `node scripts/make-livrables.js nom-du-client`.
