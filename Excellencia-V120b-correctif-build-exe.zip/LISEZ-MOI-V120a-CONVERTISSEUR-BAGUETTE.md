# V120a — Convertisseur de plan PDF, devis automatique, baguette magique

Causes trouvées (test avec un plan fictif 10 x 8 m, murs pleins puis murs en double trait) :
1. Murs en DOUBLE TRAIT (cas le plus courant des plans d'architecte) : 0 mur détecté. Corrigé : appariement de deux traits fins parallèles distants de l'épaisseur d'un mur (plan-editeur/import-pdf.html). Résultat du test : 6 murs / 3 ouvertures, dimensions exactes (10 x 8 m, murs 0,20 et 0,10).
2. Murs pleins fins (cloisons 0,10 m) manqués : épaisseur minimale par défaut passée de 0,10 à 0,07 m.
3. Devis automatique : le calcul fonctionnait, mais sans mur détecté le devis restait vide. Avec les murs détectés : devis chiffré (maçonnerie, enduit, dalle, portes, fenêtres).
4. Baguette magique : (a) ne faisait rien avec l'outil Flèche (outil par défaut) ; (b) ne marchait jamais sur un plan PDF converti, car il n'y a pas de tracé vectoriel. Corrigé : la baguette marche avec Flèche, et lit la pièce touchée sur l'image du PDF (création de zone ou de murs). Message clair si la pièce n'est pas fermée.

Après dépôt : vider le cache / Ctrl+Maj+R (service worker v120a).
Limites : un plan scanné de mauvaise qualité reste à vérifier à la main ; la baguette sur image demande une pièce fermée (portes dessinées avec leurs montants).
