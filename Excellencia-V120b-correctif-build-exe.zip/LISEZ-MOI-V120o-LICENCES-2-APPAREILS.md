# V120o — Serveur de licences unique, 2 appareils automatiques, vérification en ligne

## Ce qui est nouveau
| | V120n | V120o |
|---|---|---|
| Activation | code signé à la main, lié à un code appareil à demander au client | **le client saisit `EXC-XXXX-XXXX-XXXX`** ; ses appareils s'enregistrent seuls (2 par défaut, 1 à 10) |
| Contrôle | hors ligne uniquement | **en ligne** (toutes les 30 min) ; hors ligne : jusqu'à l'échéance ou 7 jours sans vérification |
| Suspendre / révoquer | impossible avant l'échéance | **bloqué à la prochaine vérification** ; réactivation sans nouveau code |
| Renouveler | nouveau code à envoyer | **automatique** : le logiciel reçoit la nouvelle échéance |
| 3e appareil | — | refusé ; vous libérez un appareil dans l'application propriétaire |
| Vue d'ensemble | registre JSON | **application Windows « Excellencia Licences »** : clients, échéances, appareils, journal, export CSV |

Les codes V120n (`--cle`) restent acceptés (compatibilité).

## Nouveaux dossiers
- `licence-server/` — SQL, fonction Supabase, installation (`LISEZ-MOI.md`), tests.
- `owner-app/` — application propriétaire (Electron) ; workflow « Application propriétaire (EXE) ».
- `licence-serveur.json` — adresse + clé publique (rempli par `setup.js init`).
- `provisioning/nouveau-client.js` — crée le client sur le serveur de licences et donne son code ; `--publier` lance Netlify, APK, EXE.

## Parcours d'un nouveau client
1. Fiche JSON (`provisioning/fiche-client.exemple.json`).
2. `node provisioning/nouveau-client.js --fiche provisioning/<client>.json --publier`
3. Remettez `REMISE-<client>.html` (lien, APK/EXE, code). Le client saisit son code : terminé.
4. Suivez tout dans « Excellencia Licences ».

## Sécurité
Le serveur signe avec **sa** clé (secret Supabase, sauvegarde chiffrée chez vous) ; les clients n'ont que la clé publique. La clé d'administration n'est jamais dans une édition client (testé). Horloge : l'heure de confiance ne recule jamais, même après une réponse du serveur (corrigé en V120o).

## Limites honnêtes
- **Non testé sur un vrai Supabase** ni en compilation APK/EXE/Electron (pas de réseau ici) : `schema.sql` n'a jamais été exécuté sur PostgreSQL (la logique est testée via un faux PostgREST), le déploiement de la fonction Deno non plus. Faites un premier essai avec un client de test.
- Le code d'une application reste lisible : un informaticien déterminé peut retirer la vérification. Le contrat de vente complète.
- Effacer les données de l'application donne un nouvel identifiant d'appareil : il consomme une place ; libérez l'ancien.
- Une licence copiée vers un 3e appareil échoue (liée à l'appareil). Hors ligne, un client suspendu garde l'accès jusqu'à 7 jours après sa dernière vérification.

## Deux éditions du site, prêtes à déposer (ajout)
`node scripts/build-editions.js [clients/<client>/entreprise.json]` fabrique, dans `dist/` :
- **`dist/public`** → pour le public et les clients (Netlify « glisser-déposer »). Aucun outil ni lien de génération de licences (le build échoue s'il en reste une trace) ; licence obligatoire.
- **`dist/proprietaire`** → pour vous seul. Même logiciel + bouton **🔑 Licences** (gestion des clients : créer, renouveler, suspendre, appareils) verrouillé : **vous y entrez avec votre clé privée** (écran « Logiciel verrouillé » › « 🔑 Accès administrateur » › sauvegarde chiffrée `SAUVEGARDE-CLE-LICENCE-….json` + mot de passe, ou `CLE-PRIVEE-ADMIN.txt`). Le bouton « 🔑 Licences » n'apparaît qu'une fois la clé acceptée. À déposer sur **un autre site Netlify, privé** (mot de passe Netlify conseillé) ; ne jamais donner cette adresse. La gestion exige votre clé d'administration.
Faites d'abord `node licence-server/setup.js init …` : sans `licence-serveur.json` rempli, l'édition publique ne sait pas activer un code.
Testé en navigateur : édition propriétaire verrouillée, une fausse clé est refusée, la bonne clé déverrouille et fait apparaître le bouton ; côté public, ni bouton, ni dossier `licences/` (404), logiciel verrouillé sans code.
