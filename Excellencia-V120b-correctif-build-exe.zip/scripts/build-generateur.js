/* V120p — fabrique le générateur de licences en UN SEUL FICHIER HTML : owner-licences/Excellencia-Licences-Generateur.html
 * (à partir de owner-app/renderer ; s'ouvre dans Chrome sur téléphone ou PC ; exige l'adresse du serveur de licences + la clé d'administration).
 * PROPRIÉTAIRE uniquement : jamais dans une édition client. Relancer après toute modification de owner-app/renderer. */
const fs = require('fs'), path = require('path');
const r = path.join(__dirname, '..', 'owner-app', 'renderer'), out = path.join(__dirname, '..', 'owner-licences', 'Excellencia-Licences-Generateur.html');
let h = fs.readFileSync(path.join(r, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(r, 'style.css'), 'utf8'), js = fs.readFileSync(path.join(r, 'app.js'), 'utf8');
h = h.replace("script-src 'self'; style-src 'self';", "script-src 'unsafe-inline'; style-src 'unsafe-inline';")
  .replace('<link rel="stylesheet" href="style.css">', () => '<style>' + css + '</style>')
  .replace('<script src="app.js"></script>', () => '<script>' + js.replace(/<\/script>/g, '<\\/script>') + '</script>')
  .replace('<meta charset="utf-8">', '<meta charset="utf-8"><meta name="robots" content="noindex">');
if (/src="app\.js"|style\.css/.test(h)) throw new Error('Assemblage incomplet.');
fs.writeFileSync(out, h); console.log('✔ ' + path.relative(process.cwd(), out) + ' (' + Math.round(h.length / 1024) + ' Ko)');
