/* Prépare l'exemplaire d'une entreprise AVANT de compiler l'APK / Windows (ou de déposer le site sur Netlify).
 *
 *   1. Paramètres › Identité de l'entreprise › « Télécharger entreprise.json »
 *   2. Placez ce fichier dans  site/entreprise.json  (à côté de index.html)
 *   3. npm run brand            (ou automatiquement avec android:sync / dist)
 *
 * Met à jour : nom et couleurs de l'appli installée (manifeste), nom + identifiant Android, nom Windows,
 * adresse publique, icônes du site, de l'APK (mipmaps) et de l'installateur Windows (si le module « sharp » est installé).
 * Le contenu de l'écran (noms, logos, documents) est lu au démarrage par exb-brand.js directement dans entreprise.json. */
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
/* V120o : adresse + clé publique du serveur de licences (même si ce client n'a pas d'entreprise.json) */
require('./apply-licence.js').applyLicence(root);
const file = process.argv[2] || path.join(root, 'site', 'entreprise.json');
if (!fs.existsSync(file)) { console.log('Aucun entreprise.json (' + file + ') : exemplaire d\'origine conservé.'); process.exit(0); }
const j = JSON.parse(fs.readFileSync(file, 'utf8')), b = j.data || j;
if (!b.name) { console.log('entreprise.json sans « name » : exemplaire d\'origine conservé.'); process.exit(0); }
const slug = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const short = b.short || b.name.split(/\s+/)[0];
const wr = (p, o) => fs.writeFileSync(p, JSON.stringify(o, null, 2));
const site = path.join(root, 'site');

/* si le fichier est ailleurs, on le range au bon endroit pour que le site et les applications l'embarquent */
const dest = path.join(site, 'entreprise.json');
if (path.resolve(file) !== path.resolve(dest)) fs.copyFileSync(file, dest);

/* manifeste de l'appli installée */
const mp = path.join(site, 'manifest.webmanifest'), m = JSON.parse(fs.readFileSync(mp, 'utf8'));
m.name = b.name; m.short_name = short; m.theme_color = b.primary || m.theme_color; fs.writeFileSync(mp, JSON.stringify(m, null, 1));

/* adresse publique (liens envoyés) */
if (b.publicUrl) {
  const bc = path.join(site, 'brand-config.js'); let t = fs.readFileSync(bc, 'utf8');
  t = t.replace(/window\.EXB_PUBLIC_URL = '[^']*';/, "window.EXB_PUBLIC_URL = '" + String(b.publicUrl).replace(/\/+$/, '').replace(/'/g, '') + "';");
  fs.writeFileSync(bc, t);
}

/* Android */
const cp = path.join(root, 'capacitor.config.json'), c = JSON.parse(fs.readFileSync(cp, 'utf8'));
c.appName = b.name; if (b.appId) c.appId = b.appId; wr(cp, c);

/* Windows */
const ep = path.join(root, 'electron', 'package.json');
if (fs.existsSync(ep)) {
  const e = JSON.parse(fs.readFileSync(ep, 'utf8')); e.name = slug(b.name) || e.name; e.productName = b.name;
  if (e.build) { e.build.productName = b.name; if (b.appId) e.build.appId = b.appId; }
  wr(ep, e);
}

/* dossier de documents de l'APK : Documents/<Nom> */
const nat = path.join(root, 'native', 'exb-native.js');
if (fs.existsSync(nat)) {
  let t = fs.readFileSync(nat, 'utf8'); const folder = (b.name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9]+/g, '')) || 'Entreprise';
  t = t.replace(/ROOT = '[^']*'/, "ROOT = '" + folder + "'");
  fs.writeFileSync(nat, t);
}

/* icônes à partir du logo (PNG/JPEG/WebP en data: URL, ou fichier placé à côté d'entreprise.json) */
(async () => {
  let buf = null;
  const mm = /^data:image\/(png|jpe?g|webp);base64,(.+)$/i.exec(b.logo || '');
  if (mm) buf = Buffer.from(mm[2], 'base64');
  else if (b.logo && !/^(data:|https?:)/.test(b.logo) && fs.existsSync(path.join(site, b.logo))) buf = fs.readFileSync(path.join(site, b.logo));
  if (!buf) { console.log('Pas de logo raster dans entreprise.json : icônes inchangées.'); return fin(); }
  let sharp = null; try { sharp = require('sharp'); } catch (e) {}
  if (!sharp) {
    fs.writeFileSync(path.join(site, 'brand-logo.png'), buf);
    console.log('Module « sharp » absent : logo écrit dans site/brand-logo.png. Pour générer toutes les icônes : npm install --save-dev sharp puis npm run brand.');
    return fin();
  }
  const sq = (size, bg) => sharp(buf).resize(size, size, { fit: 'contain', background: bg || { r: 255, g: 255, b: 255, alpha: 1 } }).png();
  /* site : icônes de l'appli installée */
  await sq(192).toFile(path.join(site, 'icon-192.png'));
  await sq(512).toFile(path.join(site, 'icon-512.png'));
  const inner = await sharp(buf).resize(360, 360, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
  await sharp({ create: { width: 512, height: 512, channels: 4, background: b.primary || '#173565' } }).composite([{ input: inner, gravity: 'center' }]).png().toFile(path.join(site, 'icon-maskable-512.png'));
  /* APK : mêmes dimensions que les fichiers existants */
  const res = path.join(root, 'resources', 'android-res');
  if (fs.existsSync(res)) for (const d of fs.readdirSync(res)) {
    const dir = path.join(res, d); if (!fs.statSync(dir).isDirectory()) continue;
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f), size = (await sharp(p).metadata()).width;
      if (/foreground/.test(f)) {
        const lg = await sharp(buf).resize(Math.round(size * 0.6), Math.round(size * 0.6), { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
        await sharp({ create: { width: size, height: size, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } }).composite([{ input: lg, gravity: 'center' }]).png().toFile(p + '.tmp');
      } else if (/round/.test(f)) {
        const mask = Buffer.from('<svg width="' + size + '" height="' + size + '"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + size / 2 + '"/></svg>');
        await sq(size).composite([{ input: mask, blend: 'dest-in' }]).toFile(p + '.tmp');
      } else await sq(size).toFile(p + '.tmp');
      fs.renameSync(p + '.tmp', p);
    }
  }
  console.log('Icônes régénérées (site, APK).');
  fin();
})().catch(e => { console.error('Icônes : ' + e.message); fin(); });
function fin() { console.log('Exemplaire préparé pour « ' + b.name + ' ». Lancez maintenant la compilation (npm run android:debug / cd electron && npm run dist).'); }
