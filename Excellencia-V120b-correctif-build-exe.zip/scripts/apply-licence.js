/* V120o — écrit site/licence-config.js à partir de licence-serveur.json (adresse du serveur de licences + clé PUBLIQUE).
 * Appelé par apply-brand.js (donc par les workflows APK, EXE et Netlify). Si le serveur n'est pas encore configuré, site/licence-config.js reste inchangé
 * et le logiciel n'accepte que les anciens codes signés (V120n). */
const fs = require('fs'), path = require('path');
function applyLicence(root) {
  const jp = path.join(root, 'licence-serveur.json');
  if (!fs.existsSync(jp)) return false;
  let j; try { j = JSON.parse(fs.readFileSync(jp, 'utf8')); } catch (e) { throw new Error('licence-serveur.json illisible : ' + e.message); }
  if (!j.url) { console.log('Serveur de licences non configuré (licence-serveur.json) : licence-config.js inchangé.'); return false; }
  if (!/^https:\/\/[^\s'"]+$/.test(j.url)) throw new Error('licence-serveur.json : « url » doit commencer par https://');
  if (!j.pub || j.pub.kty !== 'EC' || j.pub.crv !== 'P-256' || !j.pub.x || !j.pub.y || j.pub.d) throw new Error('licence-serveur.json : « pub » doit être la clé PUBLIQUE (kty, crv, x, y — sans « d »).');
  const cfg = { requireToken: true, warnDays: 7, defaultGrace: 7, contact: j.contact || 'l’administrateur du logiciel', server: j.url, serverPub: { kty: 'EC', crv: 'P-256', x: j.pub.x, y: j.pub.y }, offlineDays: Number(j.offlineDays) || 7, checkEveryMin: 30 };
  const out = '/* Réglages de la licence — généré par scripts/apply-licence.js à partir de licence-serveur.json (V120o). Ne contient que des informations publiques.\n   requireToken:true → sans licence valide, le logiciel reste verrouillé. */\nwindow.EXB_LICENSE_CONFIG = ' + JSON.stringify(cfg, null, 2) + ';\n';
  fs.writeFileSync(path.join(root, 'site', 'licence-config.js'), out);
  console.log('Serveur de licences : ' + j.url + ' (site/licence-config.js mis à jour).');
  return true;
}
module.exports = { applyLicence };
if (require.main === module) applyLicence(path.join(__dirname, '..'));
