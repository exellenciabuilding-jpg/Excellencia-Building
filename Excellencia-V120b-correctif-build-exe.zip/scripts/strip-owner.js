/* Excellencia — édition CLIENT du logiciel (V120n).
 * Retire, d'un dossier déjà copié (www/, electron/www/ ou une copie de site/), tout ce qui sert au PROPRIÉTAIRE :
 *   · exb-generator.html (générateur de licences), exb-admin.js (bouton 🔑), exb-proprietaire.js (espace propriétaire)
 *   · dans exb-license.js : saisie/stockage de la clé privée, signature de codes, accès administrateur
 * Le client garde uniquement : vérification de la licence (clé PUBLIQUE), code appareil, verrouillage, activation.
 * Usage :  node scripts/strip-owner.js <dossier>        (utilisé automatiquement par build-www.js et electron/scripts/prepare.js)
 * Pour garder l'édition propriétaire (votre propre appareil) : variable d'environnement EXB_OWNER=1.
 * Le build ÉCHOUE si un marqueur attendu est introuvable ou si du code propriétaire reste dans le résultat. */
const fs = require('fs'), path = require('path');

function cut(src, from, to, label) {
  const a = src.indexOf(from), b = src.indexOf(to);
  if (a < 0 || b < 0 || b <= a) throw new Error('strip-owner : marqueur introuvable (' + label + ') — exb-license.js a changé, adaptez scripts/strip-owner.js');
  return src.slice(0, a) + src.slice(b);
}
function sub(src, from, to, label) {
  if (src.split(from).length !== 2) throw new Error('strip-owner : motif absent ou multiple (' + label + ')');
  return src.replace(from, to);
}

function clientLicense(src) {
  /* 1) accès administrateur depuis l'écran verrouillé + déverrouillage par clé privée */
  src = cut(src, '/* V99zzzk — accès administrateur', 'function unlock(){', 'adminUI');
  src = sub(src, '  adminUI(d)}\n', '  }\n', 'appel adminUI');
  /* 2) génération de codes (clé privée) */
  src = cut(src, '/* ---- Administrateur : génération de codes ---- */', '/* V99zzj — activation par CODE', 'make/adminDialog');
  /* 3) rôle administrateur : n'existe pas dans l'édition client */
  src = sub(src, /var ADM_OK=null;[\s\S]*?async function vetAdmin\(\)\{[^\n]*\n/.exec(src)[0],
    'function isAdmin(){return false}\n', 'isAdmin/vetAdmin');
  src = sub(src, 'vetAdmin();check();', 'check();', 'appel vetAdmin');
  src = sub(src, 'adminDialog:adminDialog,isAdmin:isAdmin,make:make,',
    "adminDialog:async function(){},isAdmin:isAdmin,make:async function(){throw new Error('Génération de codes : réservé au propriétaire du logiciel.')},", 'export EXBLIC');
  src = sub(src, "var KT='exb_lic_token',KS='exb_lic_seen',KP='exb_lic_priv',", "var KT='exb_lic_token',KS='exb_lic_seen',", 'KP');
  return src.replace(/^\/\* Excellencia — licence à échéance[^\n]*\n/, '/* Excellencia — licence à échéance, ÉDITION CLIENT : vérifie un code signé (clé publique) ; ne peut ni signer ni générer de code. */\n');
}

const REMOVE_FILES = ['exb-generator.html', 'exb-admin.js', 'exb-proprietaire.js'];

function stripDir(dir) {
  if (!fs.existsSync(path.join(dir, 'index.html'))) throw new Error('strip-owner : ' + dir + '/index.html introuvable');
  for (const f of REMOVE_FILES) fs.rmSync(path.join(dir, f), { force: true });
  /* pages qui chargent ces scripts : on retire les balises */
  for (const e of fs.readdirSync(dir)) {
    if (!/\.html?$/i.test(e)) continue;
    const p = path.join(dir, e); let h = fs.readFileSync(p, 'utf8'), h0 = h;
    h = h.replace(/<script[^>]*src=["'](?:\.\/)?(?:exb-admin|exb-proprietaire)\.js["'][^>]*><\/script>/g, '');
    if (h !== h0) fs.writeFileSync(p, h);
  }
  /* exb-license.js → édition client */
  const lp = path.join(dir, 'exb-license.js');
  const cur = fs.readFileSync(lp, 'utf8');
  if (!/ÉDITION CLIENT/.test(cur.split('\n')[0])) fs.writeFileSync(lp, clientLicense(cur)); /* déjà édition client (dépôt client) : rien à refaire */
  /* service worker : ne plus pré-charger les fichiers retirés */
  const sp = path.join(dir, 'sw.js');
  if (fs.existsSync(sp)) {
    let s = fs.readFileSync(sp, 'utf8');
    for (const f of REMOVE_FILES) s = s.split("'./" + f + "',").join('');
    fs.writeFileSync(sp, s);
  }
  clientUI(dir);
  verify(dir);
  verifyClientUI(dir);
}


/* ───────── V120t — ÉDITION CLIENT : interface sans déconnexion, sans gestion des licences/comptes, sans outils du propriétaire ───────── */
const MARK = '<!--EXB-CLIENT-UI-->';
const REMOVE_DIRS = ['site-vitrine', 'tools', 'supabase'];                 /* vitrine + admin, tests/outils, scripts SQL du propriétaire */
const DOC_FILE = /^(README.*|LISEZ-MOI.*|1-LISEZ-MOI.*|ETUDE-.*|EXCELLENCIA-ARCHITECTURE\.md|entreprise\.exemple\.json)$/i;
const GUARD = `/* Excellencia — ÉDITION CLIENT : neutralise les actions réservées au propriétaire du logiciel. Rien ne peut être réactivé depuis l'interface. */
(function () {
  'use strict';
  var NO = function () { return Promise.resolve(); };
  ['logout', 'changeCreds', 'exbLogout', 'licPanel', 'licShare', 'licDiag', 'importSoft'].forEach(function (f) { try { window[f] = NO; } catch (e) {} });
  try { if (window.EXB_SHELL) window.EXB_SHELL.logout = function () {}; } catch (e) {}
  var st = document.createElement('style');
  st.textContent = '.logout,#ol_out,#ol_lic,#ol_softbox,button[onclick*="logout"],button[onclick*="exbLogout"],button[onclick*="changeCreds"],button[data-go="out"],[data-t="lic"],[data-t="soft"]{display:none!important}';
  (document.head || document.documentElement).appendChild(st);
})();
`;

function rmTree(p) { fs.rmSync(p, { recursive: true, force: true }); }
function exact(src, from, to, label) {
  if (src.split(from).length !== 2) throw new Error('strip-owner (édition client) : motif absent ou multiple — ' + label + ' — adaptez scripts/strip-owner.js');
  return src.replace(from, () => to);
}

function clientUI(dir) {
  /* 1) dossiers et documents internes */
  for (const d of REMOVE_DIRS) rmTree(path.join(dir, d));
  for (const e of fs.readdirSync(dir)) if (DOC_FILE.test(e)) fs.rmSync(path.join(dir, e), { force: true });
  /* 2) configuration Supabase du propriétaire : vidée (mode local) — le client y met SON projet via son identité */
  const sc = path.join(dir, 'supabase-config.js');
  if (fs.existsSync(sc) && /supabase\.co/.test(fs.readFileSync(sc, 'utf8')))
    fs.writeFileSync(sc, '/* Édition client : aucun projet Supabase du propriétaire. Vide = mode local ; le projet du client se renseigne dans « Identité de l\'entreprise ». */\nwindow.EXB_SUPABASE = { url: "", key: "" };\n');
  /* 3) index.html : déconnexion + panneau licences/comptes + import des demandes de logiciel */
  const ip = path.join(dir, 'index.html'); let h = fs.readFileSync(ip, 'utf8');
  if (!h.includes(MARK)) {
    h = exact(h, '<button class="logout" onclick="logout()">Déconnexion</button>', '', 'bouton Déconnexion (en-tête)');
    h = exact(h, "PANEL_TABS=['lic','cht']", "PANEL_TABS=['cht']", 'onglets du panneau administrateur');
    h = exact(h, "if(!PANEL_TABS.includes(CUR))CUR='lic';", "if(!PANEL_TABS.includes(CUR))CUR='cht';", 'onglet par défaut');
    h = exact(h, 'async function licPanel(){', 'async function licPanel(){return;', 'licPanel');
    h = exact(h, 'function licShare(x){', 'function licShare(x){return;', 'licShare');
    h = exact(h, 'async function licDiag(){', 'async function licDiag(){return;', 'licDiag');
    h = exact(h, 'async function importSoft(list){', 'async function importSoft(list){return;', 'importSoft');
    const at = h.toLowerCase().lastIndexOf('</body>');   /* la DERNIÈRE balise : les précédentes sont dans des chaînes JS */
    if (at < 0) throw new Error('strip-owner : </body> introuvable dans index.html');
    h = h.slice(0, at) + MARK + '<script src="exb-client-guard.js"></script>' + h.slice(at);
    fs.writeFileSync(ip, h);
  }
  fs.writeFileSync(path.join(dir, 'exb-client-guard.js'), GUARD);
  /* 3b) modules « Équipe » (invitations, rôles, liens de licence) et « Espace propriétaire » : absents de l'édition client */
  fs.rmSync(path.join(dir, 'exb-equipe.js'), { force: true });
  let h2 = fs.readFileSync(ip, 'utf8'); h2 = h2.split('<script src="exb-equipe.js"></script>').join(''); fs.writeFileSync(ip, h2);
  const sp0 = path.join(dir, 'sw.js'); if (fs.existsSync(sp0)) { let s0 = fs.readFileSync(sp0, 'utf8'); s0 = s0.split("'./exb-equipe.js',").join(''); fs.writeFileSync(sp0, s0); }
  const sh0 = path.join(dir, 'exb-v99r-shell.js'); if (fs.existsSync(sh0)) { let t0 = fs.readFileSync(sh0, 'utf8'); t0 = t0.split("equipe:'Invitations, rôles et fonctions',").join('').split("proprietaire:'Clients, licences et essais',").join(''); fs.writeFileSync(sh0, t0); }
  /* 4) menu du profil (barre haute) */
  const shp = path.join(dir, 'exb-v99r-shell.js');
  if (fs.existsSync(shp)) { let t = fs.readFileSync(shp, 'utf8'); t = t.split('<button onclick="EXB_SHELL.logout()">🚪 Déconnexion</button>').join(''); fs.writeFileSync(shp, t); }
  /* 5) espaces apprenant / formateur : plus de bouton ni d'entrée de menu « Déconnexion » (la fermeture automatique de session expirée reste) */
  for (const f of ['espace-apprenant.html', 'espace-formateur.html']) {
    const p = path.join(dir, f); if (!fs.existsSync(p)) continue; let t = fs.readFileSync(p, 'utf8');
    t = t.split(',{id:"out",t:"Déconnexion",ic:"↩"}').join('').replace(/\s*<button class="out" data-go="out" type="button">[^<]*<\/button>/g, '');
    fs.writeFileSync(p, t);
  }
  /* 6) service worker : charger le garde hors-ligne */
  const sp = path.join(dir, 'sw.js');
  if (fs.existsSync(sp)) { let s = fs.readFileSync(sp, 'utf8'); if (!s.includes('exb-client-guard.js') && s.includes("'./exb-license.js',")) { s = s.replace("'./exb-license.js',", "'./exb-license.js','./exb-client-guard.js',"); fs.writeFileSync(sp, s); } }
}

function verifyClientUI(dir) {
  const bad = [];
  for (const d of REMOVE_DIRS) if (fs.existsSync(path.join(dir, d))) bad.push(d + '/ (dossier du propriétaire)');
  const rd = (f) => { const p = path.join(dir, f); return fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : ''; };
  const ix = rd('index.html');
  if (!ix.includes(MARK) || !ix.includes('exb-client-guard.js')) bad.push('index.html : garde édition client absent');
  if (/<button class="logout"/.test(ix)) bad.push('index.html : bouton Déconnexion présent');
  if (/PANEL_TABS=\['lic'/.test(ix)) bad.push('index.html : onglet « Licences & clients » présent');
  if (/EXB_SHELL\.logout\(\)">🚪/.test(rd('exb-v99r-shell.js'))) bad.push('exb-v99r-shell.js : entrée Déconnexion du menu profil');
  for (const f of ['espace-apprenant.html', 'espace-formateur.html']) if (/id:"out"|data-go="out"/.test(rd(f))) bad.push(f + ' : entrée Déconnexion');
  if (fs.existsSync(path.join(dir, 'exb-equipe.js')) || /exb-equipe\.js/.test(ix) || /exb-equipe\.js/.test(rd('sw.js'))) bad.push('module Équipe présent');
  if (fs.existsSync(path.join(dir, 'exb-proprietaire.js')) || /id="proprietaire"/.test(ix)) bad.push('Espace propriétaire présent');
  if (/"?(equipe|proprietaire)"?:'(Invitations|Clients, licences)/.test(rd('exb-v99r-shell.js'))) bad.push('exb-v99r-shell.js : libellés Équipe / Espace propriétaire');
  if (/tqzqkejgkdvznivzsdnq/.test(rd('supabase-config.js'))) bad.push('supabase-config.js : projet Supabase du propriétaire');
  if (bad.length) throw new Error('Édition client NON conforme (interface propriétaire) :\n - ' + bad.join('\n - '));
  console.log('Interface client vérifiée : ni déconnexion, ni gestion des licences/comptes, ni outils du propriétaire.');
}

/* contrôle final : rien de « propriétaire » ne doit subsister */
function verify(dir) {
  const bad = [];
  (function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { walk(p); continue; }
      if (REMOVE_FILES.includes(e.name)) bad.push(p + ' (fichier propriétaire)');
      if (!/\.(js|html?)$/i.test(e.name)) continue;
      const t = fs.readFileSync(p, 'utf8');
      if (e.name !== 'sw.js' && /src=["'](?:\.\/)?exb-(admin|proprietaire)\.js|exb-generator\.html/.test(t)) bad.push(p + ' (référence à un module propriétaire)');
      if (e.name === 'exb-license.js' && /exb_lic_priv|subtle\.sign|adminUI|PBKDF2/.test(t)) bad.push(p + ' (code de signature/clé privée)');
    }
  })(dir);
  if (bad.length) throw new Error('Édition client NON conforme :\n - ' + bad.join('\n - '));
  console.log('Édition client vérifiée : aucun générateur ni clé privée dans ' + dir);
}

module.exports = { stripDir, clientLicense, clientUI, verifyClientUI, verify, owner: () => process.env.EXB_OWNER === '1' };
if (require.main === module) {
  const d = process.argv[2];
  if (!d) { console.error('Usage : node scripts/strip-owner.js <dossier>'); process.exit(1); }
  stripDir(path.resolve(d));
}
