/* Test automatique de la licence (V120n) — node scripts/test-licence.js
 * Génère une paire de clés DE TEST, remplace la clé publique dans le code, puis vérifie :
 *   édition propriétaire : une fausse clé admin ne déverrouille plus
 *   édition client       : code valide / modifié / expiré / signé par un tiers / lié à un autre appareil / lié à CET appareil
 * La vraie clé privée n'est jamais utilisée ici. */
const fs = require('fs'), path = require('path'), vm = require('vm');
const { clientLicense } = require('./strip-owner.js');
const ROOT = path.join(__dirname, '..');
const subtle = globalThis.crypto.subtle;
const b64u = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
let fail = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) fail++; };

async function newKey() {
  const kp = await subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  return { pub: await subtle.exportKey('jwk', kp.publicKey), priv: await subtle.exportKey('jwk', kp.privateKey), kp };
}
async function sign(k, p) {
  const bytes = new TextEncoder().encode(JSON.stringify(p));
  const sg = await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, k.kp.privateKey, bytes);
  return b64u(bytes) + '.' + b64u(sg);
}
function load(src, pub, store, opts) {
  opts = opts || {};
  const clock = opts.clock || { off: 0 };
  class D extends Date { constructor(...a) { if (a.length) super(...a); else super(Date.now() + clock.off); } static now() { return Date.now() + clock.off; } }
  src = src.replace(/var PUB=\{[^}]*\};/, 'var PUB=' + JSON.stringify({ kty: 'EC', crv: 'P-256', x: pub.x, y: pub.y }) + ';');
  const mem = Object.assign({}, store || {}), ses = Object.assign({}, opts.session || {});
  const mk = o => ({ getItem: k => (k in o ? o[k] : null), setItem: (k, v) => { o[k] = String(v); }, removeItem: k => { delete o[k]; } });
  const el = () => ({ style: {}, setAttribute() {}, getAttribute() { return null; }, appendChild() {}, remove() {}, firstChild: null, innerHTML: '', onclick: null, addEventListener() {} });
  const w = { crypto: globalThis.crypto, localStorage: mk(mem), sessionStorage: mk(ses), EXB_LICENSE_CONFIG: Object.assign({ requireToken: true, warnDays: 7, defaultGrace: 0, contact: 'le propriétaire' }, opts.cfg || {}),
    addEventListener() {}, setTimeout: () => 0, location: { hash: '', search: '', pathname: '/', reload() { w.__reloaded = true; } }, history: { replaceState() {} }, alert() {}, prompt() {} };
  w.window = w;
  const ctx = vm.createContext(Object.assign(w, { document: { getElementById: () => el(), createElement: el, body: { appendChild() {} }, addEventListener() {}, hidden: false, readyState: 'complete' },
    navigator: { onLine: !!opts.online, platform: 'Test' }, setInterval: () => 0, setTimeout: () => 0, TextEncoder, TextDecoder, atob, btoa, Uint8Array, Date: D, JSON, Math, console, fetch: opts.fetch || (async () => { throw 0; }) }));
  vm.runInContext(src, ctx);
  return { w, mem, clock, ctx };
}
const day = 864e5, iso = ms => new Date(Date.now() + ms).toISOString();

(async () => {
  const K = await newKey(), OTHER = await newKey();
  const ownerSrc = fs.readFileSync(path.join(ROOT, 'site', 'exb-license.js'), 'utf8');
  const clientSrc = clientLicense(ownerSrc);

  console.log('Édition propriétaire — fausses clés administrateur');
  let o = load(ownerSrc, K.pub, { exb_lic_priv: JSON.stringify({ d: 'x', x: K.pub.x }) });
  ok(o.w.EXBLIC.isAdmin() === false, 'clé forgée {"d":"x","x":…} (l\'ancien contournement) refusée');
  o = load(ownerSrc, K.pub, { exb_lic_priv: JSON.stringify({ kty: 'EC', crv: 'P-256', x: K.pub.x, y: K.pub.y, d: 'A'.repeat(43) }) });
  ok(o.w.EXBLIC.isAdmin() === true, 'clé de bonne forme acceptée un instant…');
  await new Promise(r => setTimeout(r, 300));
  ok(o.w.EXBLIC.isAdmin() === false && !o.mem.exb_lic_priv, '…puis révoquée et effacée dès que la signature de contrôle échoue');
  o = load(ownerSrc, K.pub, { exb_lic_priv: JSON.stringify(K.priv) });
  await new Promise(r => setTimeout(r, 300));
  ok(o.w.EXBLIC.isAdmin() === true, 'la vraie clé du propriétaire reste acceptée');

  console.log('Édition client');
  const c0 = load(clientSrc, K.pub);
  ok(c0.w.EXBLIC.isAdmin() === false, 'aucun rôle administrateur');
  ok(typeof c0.w.EXBLIC.make === 'function' && await c0.w.EXBLIC.make({}).then(() => false, () => true), 'impossible de générer un code');
  ok(!/exb_lic_priv|subtle\.sign/.test(clientSrc), 'aucun code de signature ni clé privée dans le fichier');
  const me = c0.w.EXBLIC.deviceId().replace(/-/g, '');
  ok(/^[A-Z2-9]{12}$/.test(me), 'code appareil généré : ' + c0.w.EXBLIC.deviceId());

  const base = { v: 1, name: 'Client A', exp: iso(30 * day), grace: 0, iat: iso(0), id: 'abc' };
  const run = async (p, key, tweak) => {
    let t = await sign(key || K, p); if (tweak) t = tweak(t);
    const c = load(clientSrc, K.pub, { exb_dev_id: me });
    const a = await c.w.EXBLIC.apply(t); c.w.EXBLIC; const st = await c.w.EXBLIC.state();
    return { a, st };
  };
  let r = await run(base);                                   ok(r.a.ok && r.st.mode === 'ok', 'code valide, sans appareil lié : accepté');
  r = await run(base, OTHER);                                ok(!r.a.ok, 'code signé par une autre clé : refusé');
  r = await run(base, K, t => { const [p, s] = t.split('.'); const j = JSON.parse(Buffer.from(p, 'base64')); j.exp = iso(999 * day); return b64u(Buffer.from(JSON.stringify(j))) + '.' + s; });
  ok(!r.a.ok, 'date d\'expiration modifiée par le client : refusé');
  r = await run(Object.assign({}, base, { exp: iso(-2 * day) })); ok(!r.a.ok, 'code déjà expiré : refusé');
  r = await run(Object.assign({}, base, { dev: ['ZZZZ-ZZZZ-ZZZZ'] })); ok(!r.a.ok && /autre appareil/.test(r.a.msg) && r.a.msg.includes(c0.w.EXBLIC.deviceId()), 'code lié à un AUTRE appareil : refusé, avec rappel du code appareil');
  r = await run(Object.assign({}, base, { dev: [me.slice(0, 4) + '-' + me.slice(4, 8) + '-' + me.slice(8)] })); ok(r.a.ok && r.st.mode === 'ok', 'code lié à CET appareil : accepté');
  r = await run(Object.assign({}, base, { dev: ['ZZZZ-ZZZZ-ZZZZ', me] }));    ok(r.a.ok, 'liste de plusieurs appareils contenant celui-ci : accepté');
  /* code accepté puis copié sur un autre appareil (stockage recopié sans le code appareil) */
  const t = await sign(K, Object.assign({}, base, { dev: [me] }));
  const clone = load(clientSrc, K.pub, { exb_lic_token: t, exb_dev_id: 'QQQQQQQQQQQQ' });
  ok((await clone.w.EXBLIC.state()).mode === 'locked' && (await clone.w.EXBLIC.state()).reason === 'device', 'jeton recopié sur un autre appareil : verrouillé');
  const none = load(clientSrc, K.pub);
  ok((await none.w.EXBLIC.state()).mode === 'locked', 'sans code : verrouillé');

  /* ───────── V120o : activation par code, 2 appareils, vérification en ligne (client ↔ serveur de licences) ───────── */
  console.log('Serveur de licences (V120o) — activation et vérification en ligne');
  const SRV = await newKey();                                   // clé du SERVEUR (différente de la clé propriétaire)
  const { createHandler, makeSigner, sha256 } = await import(require('url').pathToFileURL(path.join(ROOT, 'licence-server/supabase/functions/licence/core.mjs')));
  const { postgrestDb } = await import(require('url').pathToFileURL(path.join(ROOT, 'licence-server/supabase/functions/licence/postgrest.mjs')));
  const { fakePostgrest } = await import(require('url').pathToFileURL(path.join(ROOT, 'licence-server/tests/fake-postgrest.mjs')));
  const clock = { off: 0 }, nowS = () => new Date(Date.now() + clock.off);
  const pg = fakePostgrest({ now: nowS }), ADM = 'cle-admin-test-' + 'z'.repeat(20);
  const srv = createHandler({ db: postgrestDb('https://x.supabase.co', 'k', pg.fetch), sign: await makeSigner(SRV.priv), adminKeyHash: await sha256(ADM), now: nowS });
  const admin = (action, o) => srv(Object.assign({ action: 'admin.' + action }, o), { adminKey: ADM, ip: '1.1.1.1' }).then(r => r.body);
  let up = true;                                                  // false = serveur injoignable
  const netfetch = async (url, init) => { if (!up) throw new Error('réseau coupé'); const r = await srv(JSON.parse(init.body), { ip: '5.5.5.5', adminKey: (init.headers || {})['x-admin-key'] || '' }); return { ok: r.status < 400, status: r.status, json: async () => r.body }; };
  const cfg = { server: 'https://x.functions.supabase.co/licence', serverPub: { kty: 'EC', crv: 'P-256', x: SRV.pub.x, y: SRV.pub.y }, offlineDays: 7 };
  const dev = (id) => id;
  const app = (id, extra) => load(clientSrc, K.pub, Object.assign({ exb_dev_id: id }, extra || {}), { cfg, online: true, fetch: netfetch, clock });
  const cl = await admin('create', { nom: 'Client Test', jours: 90, max_appareils: 2, config: { brand: { name: 'Client Test' } } });
  const PCid = 'AAAAAAAAAAA2', TELid = 'BBBBBBBBBBB2', TABid = 'CCCCCCCCCCC2';

  const pc = app(PCid), tel = app(TELid), tab = app(TABid);
  ok((await pc.w.EXBLIC.state()).mode === 'locked', 'avant activation : verrouillé');
  ok(pc.w.EXBLIC.isActCode(cl.code) && pc.w.EXBLIC.isActCode(cl.code.toLowerCase().replace(/-/g, '')) && !pc.w.EXBLIC.isActCode('ab12cd34'), 'le code EXC-… est reconnu (et distinct d\'un code d\'invitation à 8 caractères)');
  let a = await pc.w.EXBLIC.activateCode(cl.code);
  ok(a.ok && a.appareils.n === 1 && (await pc.w.EXBLIC.state()).mode === 'ok', 'PC : activé tout seul, 1/2 appareils (aucun code appareil à demander)');
  a = await tel.w.EXBLIC.activateCode(cl.code);
  ok(a.ok && a.appareils.n === 2 && (await tel.w.EXBLIC.state()).mode === 'ok', 'téléphone : activé, 2/2');
  a = await tab.w.EXBLIC.activateCode(cl.code);
  ok(!a.ok && /2 appareils/.test(a.msg) && (await tab.w.EXBLIC.state()).mode === 'locked', 'tablette (3e appareil) : refusée, reste verrouillée');
  a = await app('DDDDDDDDDDD2').w.EXBLIC.activateCode('EXC-AAAA-BBBB-CCCC');
  ok(!a.ok && /invalide|inconnu/i.test(a.msg), 'code inexistant : refusé');

  /* licence copiée sur un autre appareil */
  const stolen = load(clientSrc, K.pub, { exb_lic_token: pc.mem.exb_lic_token, exb_dev_id: TABid }, { cfg, online: false, clock });
  ok((await stolen.w.EXBLIC.state()).reason === 'device', 'licence du PC recopiée sur la tablette : verrouillée (liée à l\'appareil)');

  /* fausses licences */
  const tokP = pc.mem.exb_lic_token, payP = JSON.parse(Buffer.from(tokP.split('.')[0], 'base64url'));
  const forge = async (key, tweak) => { const p = Object.assign({}, payP, tweak || {}); return sign({ kp: key.kp }, p); };
  const tryTok = async (t) => { const c = load(clientSrc, K.pub, { exb_dev_id: PCid }, { cfg, online: false, clock }); return c.w.EXBLIC.apply(t); };
  ok(!(await tryTok(await forge(OTHER))).ok, 'licence serveur signée par un tiers : refusée');
  ok(!(await tryTok(await forge(SRV, { v: 1 }))).ok, 'la clé du serveur ne peut pas émettre une licence ancien format');
  { const [pp, ss] = tokP.split('.'); const j = JSON.parse(Buffer.from(pp, 'base64url')); j.exp = iso(9999 * day); ok(!(await tryTok(b64u(Buffer.from(JSON.stringify(j))) + '.' + ss)).ok, 'échéance modifiée dans la licence du serveur : refusée'); }
  ok((await tryTok(tokP)).ok, 'la vraie licence du serveur est acceptée');
  const noPub = load(clientSrc, K.pub, { exb_dev_id: PCid }, { cfg: { server: cfg.server }, online: false, clock });
  ok(!(await noPub.w.EXBLIC.apply(tokP)).ok, 'sans clé publique du serveur configurée : licence serveur refusée');

  /* hors ligne */
  up = false; clock.off = 3 * day;
  let s = await pc.w.EXBLIC.check();
  ok(s.mode === 'ok' && !s.verifyBy, 'serveur injoignable, 3 jours : le logiciel continue à fonctionner');
  clock.off = 6 * day + 3600e3 * 5;
  s = await pc.w.EXBLIC.check(); ok(s.mode === 'ok' && !!s.verifyBy, 'serveur injoignable, 6 j 5 h : fonctionne, avec avertissement « connectez-vous à internet »');
  clock.off = 8 * day;
  s = await pc.w.EXBLIC.check(); ok(s.mode === 'locked' && s.reason === 'verify', 'serveur injoignable, 8 jours : verrouillé (7 jours sans vérification)');
  up = true; clock.off += 2 * 60000;                             // 2 minutes plus tard : nouvelle tentative de vérification
  s = await pc.w.EXBLIC.check(); ok(s.mode === 'ok', 'internet revenu : vérification, déverrouillage automatique');
  const iat2 = JSON.parse(Buffer.from(pc.mem.exb_lic_token.split('.')[0], 'base64url')).iat;
  ok(Date.parse(iat2) > Date.now() + 7 * day, 'nouvelle licence reçue (date de vérification renouvelée)');

  /* suspension */
  await admin('update', { id: cl.client.id, patch: { statut: 'suspendu' } });
  clock.off += 40 * 60000;                                        // > 30 min : vérification due
  s = await tel.w.EXBLIC.check(); ok(s.mode === 'locked' && s.reason === 'suspended', 'client suspendu : le téléphone se bloque à la prochaine vérification');
  s = await pc.w.EXBLIC.check(); ok(s.mode === 'locked' && s.reason === 'suspended', 'client suspendu : le PC aussi');
  up = false; s = await pc.w.EXBLIC.check(); ok(s.mode === 'locked', 'suspendu puis hors ligne : reste bloqué (pas de contournement en coupant internet)');
  up = true;
  await admin('update', { id: cl.client.id, patch: { statut: 'actif' } });
  clock.off += 2 * 60000;
  s = await pc.w.EXBLIC.check(); ok(s.mode === 'ok', 'réactivé : le PC se débloque tout seul, sans nouveau code');

  /* appareil libéré */
  await admin('release_device', { id: cl.client.id, device: TELid });
  clock.off += 40 * 60000;
  s = await tel.w.EXBLIC.check(); ok(s.mode === 'locked' && s.reason === 'released', 'appareil libéré par le propriétaire : le téléphone est bloqué');
  a = await tab.w.EXBLIC.activateCode(cl.code); ok(a.ok && (await tab.w.EXBLIC.state()).mode === 'ok', 'la tablette peut prendre la place libérée');
  a = await tel.w.EXBLIC.activateCode(cl.code); ok(!a.ok, 'le téléphone libéré ne peut pas se ré-enregistrer (2/2 déjà pris)');

  /* renouvellement transparent */
  const exp0 = (await pc.w.EXBLIC.state()).exp;
  await admin('renew', { id: cl.client.id, jours: 365 });
  clock.off += 40 * 60000;
  s = await pc.w.EXBLIC.check(); ok(Date.parse(s.exp) > Date.parse(exp0) + 300 * day && s.mode === 'ok', 'renouvellement : le PC reçoit la nouvelle échéance sans rien saisir');

  /* échéance : avertissement puis blocage */
  const cx = await admin('create', { nom: 'Expire bientôt', jours: 10, grace_jours: 3 });
  const px = app('EEEEEEEEEEE2'); await px.w.EXBLIC.activateCode(cx.code);
  clock.off += 5 * day + 1; s = await px.w.EXBLIC.check(); ok(s.mode === 'warn', 'à 5 jours de l\'échéance : avertissement');
  clock.off += 6 * day;     s = await px.w.EXBLIC.check(); ok(s.mode === 'grace', 'après l\'échéance : tolérance, avertissement de blocage');
  clock.off += 4 * day;     s = await px.w.EXBLIC.check(); ok(s.mode === 'locked' && s.reason === 'expired', 'tolérance terminée : bloqué');

  /* date du PC reculée */
  const cy = await admin('create', { nom: 'Horloge', jours: 20 }); const py = app('FFFFFFFFFFF2'); await py.w.EXBLIC.activateCode(cy.code);
  up = false; clock.off += 25 * day; s = await py.w.EXBLIC.check(); const before = s.mode;
  clock.off -= 24 * day; s = await py.w.EXBLIC.check(); ok(before !== 'ok' && s.mode === before, 'date du PC reculée hors ligne : sans effet (l\'échéance reste dépassée)');
  up = true;

  /* V120q — UN SEUL MOTEUR : l'édition propriétaire émet ses licences « organisation » par le serveur (plus de signature dans le navigateur) */
  console.log('Moteur unique — licences organisation émises par le serveur');
  const ownSrc = ownerSrc;
  const offline = load(ownSrc, K.pub, {}, { cfg, online: true, fetch: netfetch, clock });
  ok(await offline.w.EXBLIC.make({ name: 'X', exp: new Date(Date.now() + day) }).then(() => false, (e) => /non connecté/.test(e.message)), 'propriétaire non connecté au serveur : aucune licence ne peut être émise');
  const wired = load(ownSrc, K.pub, {}, { cfg, online: true, fetch: netfetch, clock, session: { exb_own: JSON.stringify({ url: cfg.server, key: ADM }) } });
  const orgTok = await wired.w.EXBLIC.make({ name: 'Bureau Kasa', exp: new Date(Date.now() + clock.off + 30 * day), grace: 3 });
  const orgP = JSON.parse(Buffer.from(orgTok.split('.')[0], 'base64url'));
  ok(orgP.org === 1 && orgP.name === 'Bureau Kasa' && !orgP.dev, 'propriétaire connecté : licence organisation émise par le serveur');
  const wrongKey = load(ownSrc, K.pub, {}, { cfg, online: true, fetch: netfetch, clock, session: { exb_own: JSON.stringify({ url: cfg.server, key: 'fausse' }) } });
  ok(await wrongKey.w.EXBLIC.make({ name: 'X', exp: new Date(Date.now() + day) }).then(() => false, () => true), 'mauvaise clé d\'administration : refusé');
  for (const id of ['GGGGGGGGGGG2', 'HHHHHHHHHHH2']) { const c = app(id); const r = await c.w.EXBLIC.apply(orgTok); ok(r.ok && (await c.w.EXBLIC.state()).mode === 'ok', 'licence organisation acceptée sur l\'appareil ' + id.slice(0, 4)); }
  clock.off += 40 * day; { const c = app('IIIIIIIIIII2'); await c.w.EXBLIC.apply(orgTok).catch(() => 0); ok((await c.w.EXBLIC.state()).mode === 'locked', 'licence organisation expirée : bloquée'); }

  /* UNE SEULE CLÉ : le serveur signe avec la clé privée admin historique (option setup.js --cle) */
  console.log('Une seule clé (serveur signant avec la clé privée admin historique)');
  { const pg1 = fakePostgrest({ now: nowS }), s1 = createHandler({ db: postgrestDb('https://x.supabase.co', 'k', pg1.fetch), sign: await makeSigner(K.priv), adminKeyHash: await sha256(ADM), now: nowS });
    const f1 = async (url, init) => { const r = await s1(JSON.parse(init.body), { ip: '6.6.6.6', adminKey: (init.headers || {})['x-admin-key'] || '' }); return { ok: r.status < 400, status: r.status, json: async () => r.body }; };
    const c1 = (await s1({ action: 'admin.create', nom: 'Une clé', jours: 30 }, { adminKey: ADM })).body;
    const one = load(clientSrc, K.pub, { exb_dev_id: 'JJJJJJJJJJJ2' }, { cfg: { server: cfg.server, serverPub: { kty: 'EC', crv: 'P-256', x: K.pub.x, y: K.pub.y } }, online: true, fetch: f1, clock });
    const r1 = await one.w.EXBLIC.activateCode(c1.code); ok(r1.ok && (await one.w.EXBLIC.state()).mode === 'ok', 'activation par code avec une licence signée par la clé admin historique'); }

  /* édition client : aucun outil propriétaire */
  ok(!/exb_lic_priv|subtle\.sign|PBKDF2|adminUI/.test(clientSrc) && !/ADMIN|x-admin-key|admin\./.test(clientSrc.replace(/isAdmin|adminDialog/g, '')), 'l\'édition client ne contient ni signature, ni clé administrateur, ni appel d\'administration du serveur');

  console.log(fail ? '\n' + fail + ' ÉCHEC(S)' : '\nTous les tests de licence passent.');
  process.exit(fail ? 1 : 0);
})();
