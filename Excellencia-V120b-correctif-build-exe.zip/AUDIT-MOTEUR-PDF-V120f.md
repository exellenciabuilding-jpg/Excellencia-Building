# V120f — Audit du moteur PDF unique (état réel du code)

| Chemin PDF | Où | Passe par le moteur ? | Reste à faire |
|---|---|---|---|
| `EXBPdf.make` (~22 appels : rapports, pages de garde…) | exb-pdf.js → `EXBDocEngine` | Oui (modèle `doc-module`, repli local) | — |
| `EXBDocs.build` (devis, factures, reçus) | exb-docs.js → `EXBDocEngine` | Oui (modèle `doc-devis`, repli local) | — |
| `EXBPrint.html` (impressions des modules) | exb-print.js + docengine/bridge.js | Oui : en-tête du profil + historique | — |
| Reçus, bordereaux, suivi des paiements, attestations de signature | via `EXBPrint.html` | **V120f** : en-tête ajouté seulement si la pièce n'affiche pas déjà l'identité (avant : jamais) | — |
| Cartes, plans, cartouches, pièces-images | via `EXBPrint.html` | Volontairement sans en-tête (la pièce est l'image ou porte son cartouche) | — |
| Métré : devis maître et devis rapide | exb-metre.js | Oui via `vecPdf` quand `EXBDocs` est chargé ; capture d'écran seulement en repli | — |
| Pièces écrites | exb-v81-pieces.js (html2canvas + jsPDF) | Non : PDF-image fabriqué sur l'appareil (nécessaire sur Android/PWA où l'impression ne fait rien) | modèle texte sélectionnable + PDF natif Android |
| Affiches | exb-affiches-studio.js | Non (visuel graphique) | à garder en image ou refaire en modèle |
| Carte de travail | exb-carte-travail.js | Non (carte-image) | idem |
| Planning des séances / dossier participant | index.html `elementToPdf` | Planning : oui (`planning-seances`) ; dossier participant : non | modèle `dossier-participant` |
| Épreuves, certificats groupés | index.html (html2canvas + jsPDF) | Non | modèles `epreuve`, `certificat` (existe) à brancher |
| « Thème » | exb-theme.js | Aucun export PDF trouvé dans ce fichier | à confirmer avec vous quel écran |

Tous les PDF-images passent par `savePdf` : ils sont inscrits à l'historique commun mais restent des images.
Test ajouté : harnais Node (8 cas) de la décision d'en-tête dans `docengine/bridge.js`.

## V120g — identité d'origine dans les impressions
Constat : `EXBPrint` affiche les pièces dans une iframe (`srcdoc`) ou un blob, hors de portée du remplacement `innerHTML` de exb-brand.js. Les textes codés en dur (ex. 32 occurrences « Excellencia Building » dans les reçus TFL) restaient donc ceux de l'origine chez un autre client.
Correctif : `window.exbRebrand` (exb-brand.js) est appliqué à chaque `EXBPrint.html` (docengine/bridge.js).

## V120h — Pièces écrites sur le moteur
Nouveau modèle `doc-piece` (texte sélectionnable, identité du profil, QR, signature/visa). Quand le serveur PDF est configuré, « 📄 PDF officiel » l'utilise ; sinon (ou en cas d'échec) le chemin d'origine est conservé tel quel (Android / PWA inclus). Test : `docengine-server/tests/doc-piece.test.js`.
Non fait : épreuves et dossier participant (`index.html`) ; certificats, affiches et carte de travail gardés en images (décision de l'utilisateur).

## V120i — Épreuves, dossier participant et fiches du module Formations sur le moteur
Nouveau modèle générique `doc-fiche` (texte sélectionnable, identité du profil de l'organisation, pied légal, signatures, anti-injection : tout est échappé, images `data:` validées). Une seule API : `EXBDocEngine.fichePdf(doc, nom, repli)` ; sans serveur PDF, ou en cas d'échec du rendu, l'ancien chemin (image) s'exécute une seule fois : jamais de blocage, jamais deux fichiers.

| Export | Avant | Maintenant |
|---|---|---|
| Épreuve (TP/TD/examen) vierge, avec lignes de réponse | PDF-image | `doc-fiche` |
| Copie corrigée, Résultats TP/TD/examens | PDF-image | `doc-fiche` |
| Dossier participant, fiche participant, liste des participants | PDF-image | `doc-fiche` |
| Feuille de présence, fiche de cotation, rapport d'activité | PDF-image (nom d'origine codé en dur) | `doc-fiche` |

Autres points traités :
- Les replis locaux n'affichent plus « Excellencia Building » codé en dur : ils prennent le nom du profil client (`exbOrg()`).
- Dossier participant : le participant ouvert est mémorisé par son identifiant (plus de recherche par nom, qui se trompait en cas d'homonymes).
- Cache hors ligne : version du service worker incrémentée (`v120i`) pour que les appareils reprennent les nouveaux fichiers.
- Tests ajoutés : `tests/doc-fiche.test.js` (rendu, échappement, photos non sûres, charges malformées), `tests/fiche-adapter.test.js` (repli sans double sortie).

Reste volontairement en images (décision de l'utilisateur) : certificats groupés, affiches, carte de travail, cartes/plans. Reste à confirmer : l'écran « Thème » (aucun export PDF dans exb-theme.js).
Non vérifié ici : rendu Chromium réel et essai sur téléphone (pas de navigateur dans cet environnement) ; à tester avec votre serveur : ouvrir chaque export et contrôler la mise en page.

## V120j — Une seule configuration d'entreprise, reprise partout
Étude : l'écran « Identité de l'entreprise » existe déjà (`exb-entreprise.js`) et `exb-brand.js` remplace le nom d'origine dans tout l'affichage. Les défauts trouvés (et corrigés) :
| Défaut constaté | Effet chez un autre client | Correction |
|---|---|---|
| Le remplacement traitait « Excellencia » avant l'e-mail d'origine | e-mail affiché « <NomCourt>building@gmail.com » | e-mail, téléphone, direction, slogan, adresse du site traités d'abord |
| MAJUSCULES, tirets, « SARLU » collé, « & » écrit `&amp;` non gérés | « EXCELLENCIA » ou « … SARL SARLU » restait | expressions tolérantes ; les identifiants tout en minuscules (classes CSS, clés) ne sont jamais touchés |
| Téléphone écrit sans espaces ou avec 0 | numéro d'origine conservé | plusieurs écritures reconnues |
| Pieds de page et titres passés à `EXBPdf.make` / moteur (ex. « Plan … — Excellencia Building ») | nom d'origine dans les PDF | `exbRebrandDeep` appliqué à toute la charge utile (local et serveur) |
| Centre documentaire et formulaires publics sans `exb-brand.js` | écran et titre d'origine | script ajouté, jamais d'écran de configuration pour le visiteur |
| Profil documentaire non mis à jour si l'identité vient du premier lancement, de entreprise.json ou d'un autre onglet | en-tête des PDF ancien | le profil suit au chargement et à chaque changement (`storage`) |
| Cartes de travail et affiches : nom d'origine si « Identité » vide | nom d'origine | repli sur le nom configuré |

Tests : `tests/brand-rep.test.js` (17 cas, dont e-mail, MAJUSCULES, `&amp;`, identifiants minuscules intacts, charge utile PDF).
Limites : textes en dur dans des images déjà dessinées (affiches pré-existantes) et dans les libellés natifs Android (invite biométrique) ne passent pas par le remplacement ; à vérifier chez un client test.

## V120j (suite) — Parcours complet dans un navigateur réel
Méthode : Chromium, fausse entreprise « Bâtiment Plus SARL », 37 pages + les 64 sections de l'application + PDF produits. Premier passage : résidus dans la page de connexion, les champs préremplis (directeur, distinction, affiches), les libellés d'accessibilité, les liens de la vitrine publique (site et WhatsApp d'origine), l'aperçu de partage (balise description) et plusieurs adresses « excellenciabuilding… ». Tous corrigés ; dernier passage : 0 résidu (`tools/e2e-marque.py`).
Points qui ne se règlent pas par du texte (décision de livraison, voir `tools/controle-client.js`) : projet Supabase du fournisseur livré par défaut dans `supabase-config.js`, adresse publique par défaut, `site-vitrine/config.json`.
