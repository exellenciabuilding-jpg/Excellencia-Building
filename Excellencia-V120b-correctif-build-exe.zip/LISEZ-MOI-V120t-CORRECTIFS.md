# V120t — correctifs appliqués au logiciel central

- Icône (favicon + apple-touch-icon) ajoutée sur toutes les pages publiques / TFL / vitrine (`icon-192.png`, `favicon.ico`).
- `index.html` : `say(h, cls, quiet)` — le paramètre `quiet` évite les notifications en double sur l'écran des formulaires.
- `espace-apprenant.html`, `apprenant.html` : message de connexion plus clair (matricule 9 chiffres, accès à activer par l'administration).
- `sw.js` : version de cache `v120t-…` (force la mise à jour chez les clients).

# V120u — copies d'épreuves en ligne

- `index.html` : à la réception des copies depuis le serveur (« Recevoir les copies en ligne »), le contrôle « Épreuve inconnue » ne bloque plus les copies d'épreuves publiées en ligne (leur identifiant vient du serveur, pas de la liste locale). Les copies s'importent et apparaissent dans la correction.
- `sw.js` : version de cache `v120u-…`.
