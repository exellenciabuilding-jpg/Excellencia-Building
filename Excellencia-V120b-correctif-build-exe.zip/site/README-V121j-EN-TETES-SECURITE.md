# V121j — En-têtes de sécurité HTTP (site et site vitrine)

Modifiés : `site/_headers`, `site/site-vitrine/_headers`, `site/tools/check.js` (5 contrôles ajoutés : 523 réussis, 0 échec).
Aucun SQL, aucun changement de code applicatif.

## Ce que ça apporte
- `X-Content-Type-Options: nosniff` : le navigateur n'interprète pas un fichier autrement que son type déclaré.
- `X-Frame-Options: SAMEORIGIN` : le logiciel et les pages publiques ne peuvent plus être affichés dans le cadre d'un autre site (clickjacking). Les cadres internes (aperçu PDF) restent possibles.
- `Referrer-Policy: strict-origin-when-cross-origin` : les adresses complètes (matricules dans les liens de vérification) ne partent pas vers des sites tiers.
- `Permissions-Policy` : caméra, micro et position gardés pour le logiciel (scan QR, assistance vocale, météo) ; paiement, USB, série, Bluetooth coupés (jamais utilisés par l'application).
- `Strict-Transport-Security` : HTTPS imposé pendant 1 an.

## Non fait volontairement
Une politique CSP stricte (`script-src`) : index.html contient de nombreux scripts intégrés, elle casserait le logiciel. À faire plus tard par étapes si vous le voulez.

## Retour en arrière
Retirer le bloc `/*` en tête des deux fichiers `_headers`.
