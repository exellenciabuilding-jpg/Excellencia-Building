/* ===== V47 : synchronisation Supabase, administration des clients, sauvegarde ZIP, restauration ===== */
(function(){
'use strict';
const g=id=>document.getElementById(id),LS='EXB_SYNC_META';
const SKIPK=new Set(['exb_db_on','EXB_DB_META','exb_ai_log','exb_diag_lent'].concat((function(){try{return localStorage.getItem('exb_db_on')==='1'?['exb_clients','exb_projects','exb_quotes','exb_stock','exb_stock_moves','exb_hr','exb_cash','exb_studies','exb_communication','exb_documents','exb_metre','exb_invoices','exb_suppliers','exb_purchase_orders','exb_site_journal','exb_timesheets','exb_situations','exb_calc_notes','exb_plans','exb_be_missions','exb_be_time','exb_gantt','exb_budgets']:[]}catch(e){return[]}})(),['exb_pass','exb_pass_h','exb_session','exb_lock','exb_sb','exb_fs_auto','exb_fs_last','exb_last_active','exb_lock_notice','exb_notifications','exb_notif_seen']));
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const api=(p,o)=>window.exbSb.api(p,o),rpc=(n,b)=>api('/rest/v1/rpc/'+n,{method:'POST',body:JSON.stringify(b||{})});
const isIn=()=>!!(window.exbSb&&window.exbSb.isIn());
const tell=(m,t)=>{try{notify(m,t||'info',6000)}catch(e){alert(m)}};
const enc=s=>new TextEncoder().encode(s),san=s=>String(s||'x').replace(/[^A-Za-z0-9._@-]+/g,'_').slice(0,80);
const hs=s=>{let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return s.length+':'+h};
const jr=(a,d)=>{try{if(isIn())rpc('journaliser',{p_action:a,p_detail:d||''}).catch(()=>{})}catch(e){}};
let meta={};try{meta=JSON.parse(localStorage.getItem(LS)||'{}')||{}}catch(e){meta={}}
const saveMeta=()=>{try{localStorage.setItem(LS,JSON.stringify(meta))}catch(e){}};
const _set=exbStorage.setItem.bind(exbStorage),_rm=exbStorage.removeItem.bind(exbStorage);
let applying=false,busy=false,tm=null,uidC=null,lastOk=null,dismissed=false;
/* ---------- détection des modifications ---------- */
/* V99 : quand la base partagée est active, toute clé qu'elle gère fiche par fiche (EXBDB.handles) est exclue de la copie par compte :
   sinon deux circuits synchronisaient la même donnée (85 collections sur 108, dont plans, CDE, BIM) et l'ancien instantané pouvait écraser les fiches récentes. */
const skip=k=>{if(SKIPK.has(k))return true;try{return localStorage.getItem('exb_db_on')==='1'&&!!(window.EXBDB&&window.EXBDB.handles&&window.EXBDB.handles(k))}catch(e){return false}};
const mark=k=>{if(applying||skip(k)||!isIn())return;clearTimeout(tm);tm=setTimeout(()=>run(),4000)};
exbStorage.setItem=function(k,v){_set(k,v);mark(k)};
exbStorage.removeItem=function(k){_rm(k);mark(k)};
const lk=()=>{const o={};for(let i=0,n=exbStorage.length;i<n;i++){const k=exbStorage.key(i);if(k&&!skip(k)){const v=exbStorage.getItem(k);if(v!=null)o[k]=v}}return o};
const st=m=>{const e=g('cs_status');if(e)e.innerHTML=m};
/* ---------- verrouillage (licence suspendue / expirée) ---------- */
function lock(l){let d=g('exbLock');if(!d){d=document.createElement('div');d.id='exbLock';d.style.cssText='position:fixed;inset:0;z-index:99999;background:#173565;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;font:18px system-ui';document.body.appendChild(d)}
 d.innerHTML='<div><h2>Accès suspendu</h2><p>'+(l.statut==='expire'?'Abonnement expiré.':l.statut==='suspendu'?'Abonnement suspendu.':'Aucune licence associée à ce compte.')+' Contactez l’administrateur.</p></div>'}
const unlock=()=>{const d=g('exbLock');if(d)d.remove()};
async function getUid(){if(uidC)return uidC;const u=await api('/auth/v1/user');uidC=u&&u.id;return uidC}
/* ---------- V112 : plus de rechargement forcé en arrière-plan ----------
   Avant : dès que la synchro (toutes les 60 s, au retour sur l'application, à la reconnexion) recevait des données,
   la page se rechargeait toute seule après 1,5 s : l'application « se fermait » en plein travail.
   Maintenant : une bannière discrète propose « Actualiser » ; le rechargement automatique n'a lieu que si l'utilisateur
   est inactif depuis 3 minutes, sans champ de saisie actif ni fenêtre ouverte. */
let pendingR=false,lastAct=Date.now();
['pointerdown','keydown','input','touchstart'].forEach(ev=>document.addEventListener(ev,()=>{lastAct=Date.now()},{passive:true,capture:true}));
function busyUI(){const a=document.activeElement,t=a&&a.tagName;if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT'||(a&&a.isContentEditable))return true;return !!document.querySelector('dialog[open],.modal.open,.modal.show,[role="dialog"]:not([hidden])')}
function pendingReload(){
 pendingR=true;if(g('exbSyncBan'))return;
 const b=document.createElement('div');b.id='exbSyncBan';b.className='no-print';
 b.style.cssText='position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:9600;background:#173565;color:#fff;padding:10px 14px;border-radius:10px;font:13px system-ui;box-shadow:0 2px 10px rgba(0,0,0,.4);max-width:92vw';
 b.innerHTML='☁️ Nouvelles données reçues. <button id="exbSyncNow" class="primary" style="margin-left:8px">Actualiser</button> <button id="exbSyncLater" class="muted">Plus tard</button>';
 document.body.appendChild(b);
 g('exbSyncNow').onclick=()=>location.reload();
 g('exbSyncLater').onclick=()=>b.remove()}
setInterval(()=>{if(pendingR&&Date.now()-lastAct>180000&&!busyUI())location.reload()},30000);
/* ---------- synchronisation ---------- */
async function run(force){if(window.EXBBIG&&!window.EXBBIG.isReady())return;
 if(busy||!isIn())return;
 /* V121c : pas de synchronisation lourde pendant la saisie (reportée à la minute suivante ; au plus 5 min de report) */
 if(!force&&busyUI()&&lastOk&&Date.now()-lastOk.getTime()<300000)return;busy=true;st('⏳ Synchronisation…');
 try{
  const l=await rpc('ma_licence');
  if(l.statut!=='actif'){lock(l);st('⛔ Accès suspendu');return}
  unlock();window.__exbAdmin=!!l.admin;
  if(l.admin&&!window.__exbQ0){window.__exbQ0=1;setTimeout(quotaWatch,1500)}
  const uid=await getUid(),rows=await api('/rest/v1/client_donnees?select=cle,maj,par_admin&limit=5000'),
   srv=new Map((rows||[]).map(r=>[r.cle,r]));
  let loc=lk(),M=JSON.parse(JSON.stringify(meta)),mode=force==='push'?'push':null;
  if(M.__u!==uid){
   if(M.__u){if(!confirm('Cet appareil contient les données d’un autre compte.\nLes remplacer par celles de ce compte ?')){window.exbSb.set(null);return}
    applying=true;try{Object.keys(loc).forEach(k=>_rm(k))}finally{applying=false}loc={};M={}}
   M.__u=uid;
   mode=srv.size&&Object.keys(loc).length?(confirm('Des données existent déjà sur le serveur pour ce compte.\n\nOK = récupérer les données du serveur (remplace celles de cet appareil)\nAnnuler = envoyer les données de cet appareil vers le serveur')?'pull':'push'):(srv.size?'pull':'push')}
  const pull=[],push=[],del=[];
  new Set([...Object.keys(loc),...srv.keys()]).forEach(k=>{if(skip(k))return;/* V99 : clé gérée par la base partagée : ni envoyée, ni récupérée, ni effacée côté copie par compte */const L=loc[k],S=srv.get(k),m=M[k];
   if(mode==='pull'){if(S)pull.push(k);else if(L!==undefined)push.push(k);return}
   if(mode==='push'){if(L!==undefined)push.push(k);return}
   if(L!==undefined&&S){if(!m){push.push(k);return}const sc=m.m!==S.maj,lc=hs(L)!==m.h;if(sc&&(!lc||S.par_admin))pull.push(k);else if(lc||sc)push.push(k)}
   else if(L!==undefined)push.push(k);
   else if(S){if(m&&m.m===S.maj)del.push(k);else pull.push(k)}});
  const toPush=push.filter(k=>force==='push'||mode||!M[k]||hs(loc[k])!==M[k].h||!srv.get(k)||M[k].m!==srv.get(k).maj);
  for(let i=0;i<toPush.length;){const b=[];let sz=0;while(i<toPush.length&&(!b.length||sz+loc[toPush[i]].length<1.5e6)){const k=toPush[i++];b.push({user_id:uid,cle:k,valeur:loc[k],par_admin:false});sz+=loc[k].length}
   const r=await api('/rest/v1/client_donnees?on_conflict=user_id,cle&select=cle,maj',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify(b)});
   (r||[]).forEach(x=>{const o=b.find(y=>y.cle===x.cle);if(o)M[x.cle]={h:hs(o.valeur),m:x.maj}})}
  for(const k of del){await api('/rest/v1/client_donnees?cle=eq.'+encodeURIComponent(k),{method:'DELETE',headers:{Prefer:'return=minimal'}});delete M[k]}
  let got=0;
  for(let i=0;i<pull.length;i+=4){const ks=pull.slice(i,i+4),r=await api('/rest/v1/client_donnees?select=cle,valeur,maj&cle=in.('+encodeURIComponent(ks.map(k=>'"'+k+'"').join(','))+')');
   applying=true;try{(r||[]).forEach(x=>{_set(x.cle,x.valeur);M[x.cle]={h:hs(x.valeur),m:x.maj};got++})}finally{applying=false}}
  meta=M;saveMeta();lastOk=new Date();
  st('<span class="valid">✓ Synchronisé à '+lastOk.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})+'</span> — envoyé : '+toPush.length+', reçu : '+got);
  if(got){pendingReload()}
 }catch(e){st('<span class="ann">Hors connexion ou erreur : '+esc(e.message||e)+' — réessai automatique.</span>')}
 finally{busy=false}
}
/* ---------- connexion au compte en ligne ---------- */
async function signIn(email,pass){
 const c=window.exbSb.cfg();if(!c.url||!c.key)throw new Error('Connexion serveur non configurée.');
 const r=await fetch(c.url+'/auth/v1/token?grant_type=password',{method:'POST',headers:{apikey:c.key,'Content-Type':'application/json'},body:JSON.stringify({email,password:pass})}),
  d=await r.json().catch(()=>({}));
 if(!r.ok||!d.access_token)throw new Error(d.error_description||d.msg||'E-mail ou mot de passe incorrect.');
 uidC=null;window.exbSb.set({access_token:d.access_token,refresh_token:d.refresh_token,exp:Date.now()+(d.expires_in||3600)*1000});
 save('exb_sb',Object.assign(load('exb_sb',{}),{email}))}
async function recover(){
 const em=prompt('E-mail de votre compte en ligne :',(window.exbSb.cfg().email||''));if(!em)return;
 const code=prompt('Code de restauration donné par l’administrateur :');if(!code)return;
 try{
  await signIn(em.trim(),code.trim());
  if(!await rpc('ma_reinit')){alert('Connexion réussie. Aucune restauration n’a été demandée par l’administrateur.');return}
  let n1;for(;;){n1=prompt('Choisissez votre nouveau mot de passe (8 caractères minimum) :');if(n1===null)return;const n2=prompt('Confirmez le nouveau mot de passe :');if(n2===null)return;
   if(n1.length>=8&&n1===n2&&n1!==code.trim())break;alert('Les deux mots de passe doivent être identiques, différents du code, et contenir 8 caractères minimum.')}
  await api('/auth/v1/user',{method:'PUT',body:JSON.stringify({password:n1})});
  if(typeof window.__exbSetPass==='function')await window.__exbSetPass(n1);else throw new Error('Module de sécurité local indisponible.');save('exb_lock',{n:0,until:0});
  await rpc('reinit_fait');jr('restauration_mdp','mot de passe restauré');
  alert('✓ Mot de passe restauré.\nIdentifiant : '+load('exb_user','admin')+'\nUtilisez le nouveau mot de passe pour ouvrir l’application.');location.reload()
 }catch(e){alert('Restauration impossible : '+(e.message||e))}
}
/* ---------- interface client ---------- */
function panel(){
 const on=isIn(),em=(window.exbSb.cfg().email||'');
 g('cloudBody').innerHTML=on
  ?'<p>Compte en ligne : <b>'+esc(em)+'</b> — <span class="valid">connecté</span></p><div id="cs_status" class="localhint">'+(lastOk?'✓ Dernière synchronisation : '+lastOk.toLocaleTimeString('fr-FR'):'En attente…')+'</div><div style="margin:10px 0;display:flex;gap:8px;flex-wrap:wrap"><button id="cs_now">↻ Synchroniser maintenant</button><button id="cs_all">⬆ Envoyer toutes mes données (reprise)</button><button id="cs_pw2">🔑 Changer mon mot de passe en ligne</button><button id="cs_out">Se déconnecter</button></div>'
  :'<label>E-mail du compte</label><input id="cs_em" type="email" autocomplete="username" value="'+esc(em)+'"><label>Mot de passe</label><input id="cs_pw" type="password" autocomplete="current-password"><div style="margin-top:10px"><button id="cs_go">🔐 Se connecter</button></div><div id="cs_status" style="margin-top:8px"></div>';
 const b=(i,f)=>{const e=g(i);if(e)e.onclick=f};
 b('cs_now',()=>run());
 b('cs_all',()=>{if(confirm('Envoyer toutes les données de cet appareil vers le serveur (elles remplacent celles du serveur) ?'))run('push')});
 b('cs_pw2',async()=>{const a=prompt('Nouveau mot de passe en ligne (8 caractères minimum) :');if(!a)return;if(a.length<8){alert('8 caractères minimum.');return}if(prompt('Confirmez le nouveau mot de passe :')!==a){alert('Les deux mots de passe ne correspondent pas.');return}try{await api('/auth/v1/user',{method:'PUT',body:JSON.stringify({password:a})});tell('✓ Mot de passe en ligne modifié.','success')}catch(e){alert('Impossible : '+(e.message||e))}});
 b('cs_out',()=>{window.exbSb.set(null);uidC=null;panel()});
 b('cs_go',async()=>{try{st('Connexion…');await signIn(g('cs_em').value.trim(),g('cs_pw').value);panel();run()}catch(e){st('<span class="ann">'+esc(e.message||e)+'</span>')}})}
function boot(){
 if(g('cloudSync'))return;const adm=g('administration'),b=g('badm');if(!adm||!b||!window.exbSb||!window.exbSb.cfg)return;
 adm.insertAdjacentHTML('afterend','<section id="cloudSync" class="no-print" style="display:none"><div class="card"><h2>☁️ Synchronisation en ligne</h2><p class="localhint">Vos données sont enregistrées automatiquement sur le serveur à chaque modification. Une copie reste sur cet appareil pour travailler sans connexion.</p><div id="cloudBody"></div></div></section>');
 b.insertAdjacentHTML('afterend',' <button id="bcloud" onclick="show(\'cloudSync\')">☁️ Synchronisation</button>');
 const os=window.show;window.show=function(x){os.apply(this,arguments);const el=g('cloudSync');if(el)el.style.display=x==='cloudSync'?'':'none';if(x==='cloudSync')panel()};
 const lm=g('li_msg');if(lm&&!g('exbForgot'))lm.insertAdjacentHTML('afterend','<div style="text-align:center;margin-top:8px"><a href="#" id="exbForgot" style="font-size:13px">🔑 Mot de passe oublié / code de restauration</a></div>');
 const f=g('exbForgot');if(f)f.onclick=e=>{e.preventDefault();recover()};
 const nudgeDue=()=>{try{if(navigator.onLine===false)return false;const k='exb_nudge_at',t=Number(localStorage.getItem(k))||0;if(Date.now()-t<3*864e5)return false;localStorage.setItem(k,String(Date.now()));return true}catch(e){return false}};/* V120q : au plus une invitation tous les 3 jours, visible 15 s */
 setInterval(()=>{const a=g('app');if(a&&a.style.display!=='none'&&!isIn()&&!dismissed&&!g('exbNudge')&&nudgeDue()){const d=document.createElement('div');d.id='exbNudge';d.style.cssText='position:fixed;left:8px;right:8px;bottom:8px;z-index:9000;background:#173565;color:#fff;border-radius:10px;padding:10px 12px;font:14px system-ui;display:flex;gap:8px;align-items:center';d.innerHTML='<span style="flex:1">☁️ Connectez votre compte en ligne pour sauvegarder vos données.</span><button id="nd_go">Se connecter</button><button id="nd_x">✕</button>';document.body.appendChild(d);setTimeout(()=>{try{d.remove()}catch(e){}},15000);g('nd_go').onclick=()=>{d.remove();show('cloudSync')};g('nd_x').onclick=()=>{dismissed=true;d.remove()}}
  else if(isIn()&&g('exbNudge'))g('exbNudge').remove()},4000);
 setInterval(()=>run(),60000);setInterval(quotaWatch,30*60000);window.addEventListener('online',()=>run());document.addEventListener('visibilitychange',()=>{if(!document.hidden)run()});
 setTimeout(()=>run(),12000)}
/* ---------- ZIP : lecture ---------- */
async function readZip(buf){
 const v=new DataView(buf),u=new Uint8Array(buf);let e=-1;for(let i=u.length-22;i>=Math.max(0,u.length-70000);i--)if(v.getUint32(i,true)===0x06054b50){e=i;break}
 if(e<0)throw new Error('ZIP invalide.');
 const n=v.getUint16(e+10,true);let p=v.getUint32(e+16,true);const out=[];
 for(let i=0;i<n;i++){if(v.getUint32(p,true)!==0x02014b50)break;
  const meth=v.getUint16(p+10,true),cs=v.getUint32(p+20,true),nl=v.getUint16(p+28,true),xl=v.getUint16(p+30,true),cl=v.getUint16(p+32,true),off=v.getUint32(p+42,true),
   name=new TextDecoder().decode(u.subarray(p+46,p+46+nl)),ds=off+30+v.getUint16(off+26,true)+v.getUint16(off+28,true);let b=u.subarray(ds,ds+cs);
  if(meth===8){const s=new Blob([b]).stream().pipeThrough(new DecompressionStream('deflate-raw'));b=new Uint8Array(await new Response(s).arrayBuffer())}
  else if(meth!==0){p+=46+nl+xl+cl;continue}
  out.push({name,bytes:b});p+=46+nl+xl+cl}
 return out}
/* ---------- administration ---------- */
const LABEL={exb_participants:'Apprenants',exb_payments:'Paiements',exb_evaluations:'Évaluations',exb_cotations:'Cotations',exb_attendance:'Présences',exb_formations:'Formations',exb_trainers:'Formateurs',exb_certificates:'Certificats',exb_receipts:'Reçus',exb_schedules:'Planning',exb_audit:'Journal local',exb_dossiers:'Dossiers',exb_tp_td_requests:'Demandes TP/TD',exb_tp_td_docs:'Documents TP/TD'};
const mask=s=>{const P=[];return{t:s.replace(/data:image\/[a-z+]+;base64,[A-Za-z0-9+\/=]+/g,m=>{P.push(m);return '@@PHOTO'+(P.length-1)+'@@'}),P}};
const unmask=(t,P)=>t.replace(/@@PHOTO(\d+)@@/g,(m,i)=>P[i]!==undefined?P[i]:m);
const mo=x=>(x/1048576).toFixed(1),dt=s=>s?new Date(s).toLocaleString('fr-FR'):'—';
const clientJson=(c,D)=>{const data={};Object.keys(D).forEach(k=>data[k]=D[k].v);return enc(JSON.stringify({format:'EXB_CLOUD_CLIENT',version:1,exporte_le:new Date().toISOString(),client:{email:c.email,nom:c.nom||'',statut:c.statut||'',echeance:c.echeance||null},data}))};
const zipDl=(name,F)=>saveFile(name,window.__exbData.zip(F));
async function exportAll(){
 try{tell('Préparation de l’export…');const L=await rpc('admin_stats'),LIM=60*1048576,d=todayISO();let F=[],sz=0,part=0,nc=0;
  const flush=async()=>{if(!F.length)return;part++;await zipDl('Excellencia-clients-'+d+'-partie'+part+'.zip',F.concat([{name:'liste-clients.json',data:enc(JSON.stringify(L,null,1))}]));F=[];sz=0};
  for(const c of L){if(!c.cles)continue;const b=clientJson(c,await rpc('admin_lire',{p_email:c.email}));
   if(F.length&&sz+b.length>LIM)await flush();
   F.push({name:'clients/'+san(c.email)+'/sauvegarde-complete.json',data:b});sz+=b.length;nc++}
  if(!nc){tell('Aucune donnée client à exporter.','warn');return}
  await flush();jr('export_zip',nc+' client(s), '+part+' fichier(s)');
  tell('✓ Export terminé : '+nc+' client(s) en '+part+' fichier(s) ZIP. Conservez-les, puis libérez de l’espace avec « 🗑 Supprimer du serveur » (fiche du client).','success')
 }catch(e){alert('Export impossible : '+(e.message||e))}}
let FILEC=[];
async function importFile(f){
 try{const out=/\.zip$/i.test(f.name)?await readZip(await f.arrayBuffer()):[{name:f.name,bytes:new Uint8Array(await f.arrayBuffer())}];FILEC=[];
  for(const x of out){if(!/\.json$/i.test(x.name)||/liste-clients/.test(x.name))continue;let o;try{o=JSON.parse(new TextDecoder().decode(x.bytes))}catch(e){continue}
   if(o&&o.format==='EXB_CLOUD_CLIENT'){const D={};Object.keys(o.data).forEach(k=>D[k]={v:o.data[k],t:o.data[k].length,m:o.exporte_le});FILEC.push({email:o.client.email,nom:o.client.nom,D})}
   else if(o&&o.format==='EXB_FULL_BACKUP'){const D={};Object.keys(o.data).forEach(k=>{const v=o.data[k],s=v&&v.__raw!==undefined?v.__raw:JSON.stringify(v);D[k]={v:s,t:s.length,m:o.exported_at}});FILEC.push({email:'',nom:x.name,D})}}
  const l=g('ea_list');if(!l)return;if(!FILEC.length){l.innerHTML='<p class="ann">Aucune sauvegarde reconnue dans ce fichier.</p>';return}
  l.innerHTML='<h4>Fichier importé</h4>'+FILEC.map((c,i)=>'<div style="border:1px solid #d5dbe5;border-radius:8px;padding:8px;margin:6px 0"><b>'+esc(c.nom||c.email)+'</b> '+esc(c.email)+' · '+Object.keys(c.D).length+' jeux de données<br><button data-fa="v" data-i="'+i+'">👁 Consulter</button> <button data-fa="r" data-i="'+i+'">♻️ Restaurer sur le serveur</button></div>').join('');
  l.onclick=async e=>{const b=e.target.closest('button[data-fa]');if(!b)return;const c=FILEC[b.dataset.i];
   if(b.dataset.fa==='v')viewer({email:c.email,nom:c.nom,D:c.D,server:false});
   else{const em=prompt('Restaurer sur le compte client (e-mail) :',c.email||'');if(!em)return;if(!confirm('Écrire ces données sur le serveur pour '+em+' ? Les jeux de données du même nom seront remplacés.'))return;
    try{const d={};Object.keys(c.D).forEach(k=>d[k]=c.D[k].v);const n=await rpc('admin_importer',{p_email:em.trim(),p_data:d});jr('import_zip',em+' '+n);tell('✓ '+n+' jeux de données restaurés pour '+em,'success')}catch(er){alert('Restauration impossible : '+(er.message||er))}}}
 }catch(e){alert('Fichier illisible : '+(e.message||e))}}
async function quotaWatch(){
 if(!window.__exbAdmin||!isIn())return;
 try{const s=await rpc('admin_stockage'),pct=Math.round(s.octets/s.limite*100);let b=g('exbQuota');
  if(pct<80){if(b)b.remove();return}
  if(!b){b=document.createElement('div');b.id='exbQuota';b.style.cssText='position:fixed;left:8px;right:8px;top:8px;z-index:9400;background:#c0392b;color:#fff;border-radius:10px;padding:10px 12px;font:14px system-ui;display:flex;gap:8px;align-items:center';document.body.appendChild(b)}
  b.innerHTML='<span style="flex:1">⚠️ Base Supabase remplie à '+pct+' % ('+mo(s.octets)+' / '+mo(s.limite)+' Mo). Exportez les données en ZIP.</span><button id="qz_go">📦 Exporter</button><button id="qz_x">✕</button>';
  if(!window.__exbQuota){window.__exbQuota=1;tell('⚠️ Base Supabase à '+pct+' % : exportez les données en ZIP.','warn')}
  g('qz_go').onclick=()=>exportAll();g('qz_x').onclick=()=>b.remove();
 }catch(e){}}
async function adminBar(){
 const d=g('exbAdminBar');if(!d)return;
 try{const s=await rpc('admin_stockage'),pct=Math.round(s.octets/s.limite*100);
  d.innerHTML='<div style="background:#fff;border:1px solid #d5dbe5;border-radius:8px;padding:10px;margin:8px 0">💽 Base Supabase : <b>'+mo(s.octets)+' / '+mo(s.limite)+' Mo</b> ('+pct+'%) · données clients : '+mo(s.donnees)+' Mo'+(pct>=80?'<br><b style="color:#c0392b">⚠️ Espace presque plein : exportez les données en ZIP, puis supprimez du serveur les clients inactifs.</b>':'')+'<div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap"><button id="ea_zip">📦 Exporter tous les clients (ZIP)</button><button id="ea_imp">📥 Importer un ZIP</button></div><input type="file" id="ea_file" accept=".zip,.json" style="display:none"><div id="ea_list"></div></div>';
  g('ea_zip').onclick=exportAll;g('ea_imp').onclick=()=>g('ea_file').click();g('ea_file').onchange=e=>{if(e.target.files[0])importFile(e.target.files[0]);e.target.value=''};
  if(pct>=80&&!window.__exbQuota){window.__exbQuota=1;tell('⚠️ Base Supabase à '+pct+' % : exportez les données en ZIP.','warn')}
 }catch(e){d.innerHTML='<p class="ann">Administration des données indisponible : exécutez supabase-excellencia-complet.sql dans Supabase. ('+esc(e.message||e)+')</p>'}}
async function viewClient(x){
 try{tell('Chargement des données…');viewer({email:x.email,nom:x.nom,D:await rpc('admin_lire',{p_email:x.email}),server:true,c:x})}
 catch(e){alert('Lecture impossible : '+(e.message||e)+(/fonction|function|404/i.test(e.message||'')?'\nExécutez supabase-excellencia-complet.sql dans Supabase.':''))}}
function viewer(S){
 const old=g('exbViewer');if(old)old.remove();
 const o=document.createElement('div');o.id='exbViewer';o.style.cssText='position:fixed;inset:0;z-index:9500;background:#f4f6fa;overflow:auto;padding:12px;font:15px system-ui;color:#1b2533';document.body.appendChild(o);
 const D=S.D,keys=Object.keys(D).sort(),cnt=k=>{try{const a=JSON.parse(D[k].v);return Array.isArray(a)?a.length:0}catch(e){return 0}},tot=keys.reduce((a,k)=>a+(D[k].t||0),0),last=keys.reduce((a,k)=>D[k].m&&(!a||D[k].m>a)?D[k].m:a,'');
 o.innerHTML='<div style="max-width:760px;margin:0 auto"><button id="vw_x">✕ Fermer</button><h2 style="margin:10px 0 2px">'+esc(S.nom||S.email)+'</h2><div>'+esc(S.email)+(S.server?'':' · <i>(lecture depuis un fichier)</i>')+'</div>'
  +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0"><div class="card">👥 Apprenants<br><b style="font-size:22px">'+cnt('exb_participants')+'</b></div><div class="card">💰 Paiements<br><b style="font-size:22px">'+cnt('exb_payments')+'</b></div><div class="card">📝 Évaluations<br><b style="font-size:22px">'+cnt('exb_evaluations')+'</b></div><div class="card">💾 Volume<br><b style="font-size:22px">'+mo(tot)+' Mo</b></div></div>'
  +'<div>Dernière activité : <b>'+dt(last)+'</b> · '+keys.length+' jeux de données</div>'
  +'<div style="margin:10px 0;display:flex;gap:8px;flex-wrap:wrap"><button id="vw_zip">⬇ Sauvegarde ZIP</button>'+(S.server?'<button id="vw_code">🔑 Code de restauration</button><button id="vw_del">🗑 Supprimer du serveur</button>':'')+'</div>'
  +'<div id="vw_ed"></div>'+(keys.length?keys.map(k=>'<div style="background:#fff;border:1px solid #d5dbe5;border-radius:8px;padding:8px;margin:6px 0;display:flex;justify-content:space-between;align-items:center;gap:8px"><span><b>'+esc(LABEL[k]||k)+'</b><br><small>'+esc(k)+' · '+((D[k].t||0)/1024).toFixed(0)+' Ko · '+dt(D[k].m)+'</small></span><button data-k="'+esc(k)+'">'+(S.server?'✏️ Ouvrir':'👁 Voir')+'</button></div>').join(''):'<p>Aucune donnée enregistrée pour ce client.</p>')+'</div>';
 g('vw_x').onclick=()=>o.remove();
 g('vw_zip').onclick=()=>zipDl('client-'+san(S.email||S.nom)+'-'+todayISO()+'.zip',[{name:'sauvegarde-complete.json',data:clientJson(S.c||{email:S.email,nom:S.nom},D)}]);
 if(S.server){
  g('vw_code').onclick=async()=>{const def='EXB-'+String(Math.floor(100000+Math.random()*900000)),c=prompt('Code de restauration à donner au client (6 caractères minimum) :',def);if(!c)return;
   try{await rpc('admin_reinit_mdp',{p_email:S.email,p_code:c.trim()});jr('code_restauration',S.email);const t='Bonjour '+(S.nom||'')+',\nvotre code de restauration Excellencia Building : '+c.trim()+'\nSur l’écran de connexion, touchez « Mot de passe oublié / code de restauration », saisissez votre e-mail ('+S.email+') et ce code, puis choisissez un nouveau mot de passe.';
    try{navigator.clipboard.writeText(t).catch(function(){})}catch(e){}alert('✓ Code activé : '+c.trim()+'\nLe message pour le client est copié.');if(navigator.share)navigator.share({text:t}).catch(()=>{})}catch(e){alert('Impossible : '+(e.message||e))}};
  g('vw_del').onclick=async()=>{if(!confirm('Supprimer du serveur TOUTES les données de '+(S.nom||S.email)+' ?\nExportez d’abord la sauvegarde ZIP. Si le client se reconnecte, son appareil renverra ses données (sauf s’il est suspendu).'))return;if(prompt('Tapez SUPPRIMER pour confirmer :')!=='SUPPRIMER')return;
   try{const n=await rpc('admin_purger',{p_email:S.email});jr('purge',S.email+' '+n);tell('✓ '+n+' jeux de données supprimés du serveur.','success');o.remove()}catch(e){alert('Impossible : '+(e.message||e))}}}
 o.onclick=e=>{const b=e.target.closest('button[data-k]');if(!b)return;const k=b.dataset.k,raw=D[k].v,mk=mask(raw);let txt=mk.t,js=true;try{txt=JSON.stringify(JSON.parse(mk.t),null,1)}catch(er){js=false}
  const ed=g('vw_ed');ed.innerHTML='<div class="card"><b>'+esc(LABEL[k]||k)+'</b> <small>(photos masquées : @@PHOTOn@@, à laisser tel quel)</small><textarea id="vw_ta" style="width:100%;height:50vh;font:12px monospace;margin-top:6px"'+(S.server?'':' readonly')+'></textarea><div style="margin-top:6px;display:flex;gap:8px">'+(S.server?'<button id="vw_save">💾 Enregistrer sur le serveur</button>':'')+'<button id="vw_close">Fermer</button></div></div>';
  g('vw_ta').value=txt;ed.scrollIntoView();g('vw_close').onclick=()=>{ed.innerHTML=''};
  if(S.server)g('vw_save').onclick=async()=>{let v=g('vw_ta').value;try{if(js)v=JSON.stringify(JSON.parse(v));v=unmask(v,mk.P);await rpc('admin_ecrire',{p_email:S.email,p_cle:k,p_valeur:v});D[k].v=v;D[k].t=v.length;jr('modif_donnees',S.email+' '+k);tell('✓ Enregistré. Le client recevra la modification à sa prochaine synchronisation.','success');ed.innerHTML=''}catch(er){alert('Enregistrement refusé : '+(er.message||er)+(js?'\n(Vérifiez que le JSON est valide.)':''))}}}}
window.exbSync={run,signIn,recover,viewClient,adminBar,skips:skip};
const t=setInterval(()=>{if(g('cloudSync')){clearInterval(t);return}boot()},900);
})();
